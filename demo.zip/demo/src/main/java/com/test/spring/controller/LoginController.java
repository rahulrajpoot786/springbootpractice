package com.test.spring.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.test.spring.model.LoginVO;
import com.test.spring.model.UserManagementVO;

@Controller
public class LoginController {

	@RequestMapping(value = {"/"})
	public String defaultLogin() {
		System.out.println("defaultLogin");
		return "login";
	}
	
	
	@ModelAttribute("loginmodel")
	public LoginVO setLoginVo() {
		System.out.println("loginmodel");
		return new LoginVO();
	}
	
	@ModelAttribute("usermanagement")
	public UserManagementVO setUser() {
		System.out.println("usermanagement");
		return new UserManagementVO();
	}
	
	@RequestMapping(value = {"/userlogin1"})
	public String doLogin(@ModelAttribute("loginmodel") LoginVO login) {
		System.out.println("userlogin1");
		if(login.getUsername().equalsIgnoreCase("rahul") && login.getPassword().equalsIgnoreCase("rahul1")) {
			
			return "welcome";
		}else {
			return "failure";
		}
	}
}

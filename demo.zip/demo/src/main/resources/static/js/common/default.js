function onlogin(){
	
	document.forms['loginuser'].action="userlogin1";
	document.forms['loginuser'].submit();
}
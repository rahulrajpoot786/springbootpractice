--------------------------------------------------------
--  DDL for Synonymn GROUP_BRANCH_SEQ_ID
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."GROUP_BRANCH_SEQ_ID" FOR "APP"."GROUP_BRANCH_SEQ_ID";

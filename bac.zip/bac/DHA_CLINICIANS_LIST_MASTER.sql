--------------------------------------------------------
--  DDL for Synonymn DHA_CLINICIANS_LIST_MASTER
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."DHA_CLINICIANS_LIST_MASTER" FOR "APP"."DHA_CLINICIANS_LIST_MASTER";

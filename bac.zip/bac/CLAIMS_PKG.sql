--------------------------------------------------------
--  DDL for Package Body CLAIMS_PKG
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "VENUBABU"."CLAIMS_PKG" IS
 --==============================================================================================
 --   Name       : save_HOSPITAL_ADDITIONAL_DTL
 --   Created on : -11-JUL-06
 --   Created By : - S.V.SREERAJ
 --   Comments   :
 --==============================================================================================
  PROCEDURE save_clm_inward_entry (
    v_claims_inward_seq_id            IN OUT CLM_INWARD.claims_inward_seq_id%TYPE,
    v_tpa_office_seq_id               IN CLM_INWARD.tpa_office_seq_id%TYPE,
    v_barcode_no                      IN CLM_INWARD.barcode_no%TYPE,
    v_document_general_type_id        IN CLM_INWARD.document_general_type_id%TYPE,
    v_rcvd_date                       IN CLM_INWARD.rcvd_date%TYPE,
    v_source_general_type_id          IN CLM_INWARD.source_general_type_id%TYPE,
    v_claim_general_type_id           IN CLM_INWARD.claim_general_type_id%TYPE,
    v_requested_amount                IN CLM_GENERAL_DETAILS.Requested_Amount%TYPE,
    v_member_seq_id                   IN CLM_ENROLL_DETAILS.member_seq_id%TYPE,
    v_tpa_enrollment_id               IN CLM_ENROLL_DETAILS.tpa_enrollment_id%TYPE,
    v_claimant_name                   IN CLM_ENROLL_DETAILS.claimant_name%TYPE,
    v_policy_seq_id                   IN CLM_ENROLL_DETAILS.policy_seq_id%TYPE,
    v_policy_number                   IN CLM_ENROLL_DETAILS.policy_number%TYPE,
    v_inward_ins_seq_id               IN CLM_INWARD.inward_ins_seq_id%TYPE,
    v_corporate_name                  IN CLM_INWARD.corporate_name%TYPE,
    v_policy_holder_name              IN CLM_ENROLL_DETAILS.policy_holder_name%TYPE,
    v_employee_no                     IN CLM_ENROLL_DETAILS.employee_no%TYPE,
    v_employee_name                   IN CLM_ENROLL_DETAILS.employee_name%TYPE,
    v_inward_stat_general_type_id     IN CLM_INWARD.inward_status_general_type_id%TYPE,
    v_remarks                         IN CLM_INWARD.remarks%TYPE,
    v_courier_seq_id                  IN CLM_INWARD.courier_seq_id%TYPE,
    v_parent_claim_seq_id             IN OUT CLM_INWARD.claim_seq_id%TYPE,
    v_claim_number                    IN CLM_INWARD.claim_number%TYPE,
    v_shortfall_id                    IN CLM_INWARD.shortfall_id%TYPE,
    v_clm_seq_id                      IN OUT CLM_GENERAL_DETAILS.claim_seq_id%TYPE,  -- CLAIM_SEQ_ID from list grid ( For Edit Only)
    v_clm_enroll_detail_seq_id        IN OUT CLM_ENROLL_DETAILS.clm_enroll_detail_seq_id%TYPE, -- CLM_ENROLL_DETAIL_SEQ_ID from list grid ( For Edit Only)
    v_email_id                        IN CLM_ENROLL_DETAILS.email_id%TYPE,
    v_notification_phone_number       IN CLM_ENROLL_DETAILS.notification_phone_number%TYPE,
    v_ins_scheme                      IN CLM_ENROLL_DETAILS.ins_scheme%TYPE,
    v_certificate_no                  IN CLM_ENROLL_DETAILS.certificate_no%TYPE,
    v_ins_customer_code               IN CLM_ENROLL_DETAILS.ins_customer_code%TYPE,
    v_added_by                        IN CLM_INWARD.added_by%TYPE,
    v_rows_processed                  OUT NUMBER
  )
  IS

    v_mode_general_type_id           clm_general_details.mode_general_type_id%TYPE;
    v_prev_status                    clm_inward.inward_status_general_type_id%TYPE;
    v_prev_document_type_id          clm_inward.document_general_type_id%TYPE;
    v_prev_claim_number              clm_inward.claim_number%TYPE;
    v_prev_claim_seq_id              clm_inward.claim_seq_id%TYPE;
    v_prev_shortfall_id              clm_inward.shortfall_id%TYPE;
    v_prev_tpa_office_seq_id         tpa_office_info.tpa_office_seq_id%TYPE;
    v_claims_inward_no               clm_inward.claims_inward_no%TYPE;
    v_dest_msg_seq_id                VARCHAR2(250);
    v_shortfall_seq_id               shortfall_details.shortfall_seq_id%TYPE;
    v_shortfall_clm_seq_id           clm_general_details.claim_seq_id%TYPE;
    v_log_remarks                    pat_log.remarks%type;
    v_clm_completed_yn               clm_general_details.completed_yn%TYPE;
    v_shortfall_status_type_id       tpa_general_code.description%TYPE;
   -------------------- ADDED FOR CR KOC1137
    v_DEST_MSG_SEQ_ID1  VARCHAR2(250);
    V_VIP_YN            varchar2(5);
    V_CLM_IW_SEQ_ID CLM_INWARD.claims_inward_seq_id%TYPE;
    v_notify_typ_id     VARCHAR2(3);--koc_ins_mail
    V_INS_COMP_NAME     TPA_INS_INFO.INS_COMP_NAME%TYPE;--koc_ins_mail
    V_CIGNA_YN          VARCHAR2(1);--koc_ins_mail

    CURSOR  GET_CLM_IW_SEQ_ID(V_CLM_IW_SEQ_ID CLM_INWARD.claims_inward_seq_id%TYPE)  IS SELECT CLM_IW_SEQ_ID FROM CLM_REMINDER A
       JOIN CLM_INWARD B ON (A.CLM_IW_SEQ_ID=B.claims_inward_seq_id) WHERE A.CLM_IW_SEQ_ID=V_CLM_IW_SEQ_ID;
   -------------------   ABOVE VARIABLE AND CURSORS ADDED FOR CR KOC1137
    CURSOR shortfall_cur IS SELECT A.shortfall_seq_id,A.claim_seq_id,B.completed_yn,C.description
       FROM shortfall_details A JOIN clm_general_details b ON (a.claim_seq_id = b.claim_seq_id)
       JOIN tpa_general_code C ON (A.srtfll_status_general_type_id=C.general_type_id)
       WHERE b.claim_number = v_claim_number AND  a.shortfall_id = v_shortfall_id;

  CURSOR CIGNA_NOTIFY_CUR (V_TPA_ENROLL_ID  tpa_enr_policy_member.tpa_enrollment_id%TYPE) IS--koc_ins_mail
   select nvl(i.notify_type_id,'NIG'),i.ins_comp_name /*into v_notify_typ_id,V_INS_COMP_NAME*/
   from tpa_enr_policy ep join tpa_ins_info i on (ep.ins_seq_id=i.ins_seq_id)
   join tpa_enr_policy_group g on (g.policy_seq_id=ep.policy_seq_id)
   join tpa_enr_policy_member pm on (pm.policy_group_seq_id=g.policy_group_seq_id)
   where  ep.deleted_yn='N' and pm.tpa_enrollment_id=V_TPA_ENROLL_ID;

  BEGIN

    IF v_tpa_enrollment_id IS NOT NULL THEN
      v_mode_general_type_id := 'CLR' ;
    ELSE
      v_mode_general_type_id := 'CML';
    END IF;
  IF NVL(v_claims_inward_seq_id,0) = 0 THEN
    v_claims_inward_no      := PRE_AUTH_PKG.generate_id_numbers('INW', v_tpa_office_seq_id , NULL, v_added_by);

    /*IF v_document_general_type_id = 'DTS' THEN  --short fall
      save_inward_shortfall ( v_shortfall_id, v_claim_number , v_added_by ,'UPD',v_shortfall_seq_id );
    END IF;*/

    INSERT INTO clm_inward (
        claims_inward_seq_id,
        tpa_office_seq_id,
        claims_inward_no,
        barcode_no,
        document_general_type_id,
        rcvd_date,
        source_general_type_id,
        courier_seq_id,
        claim_general_type_id,
        inward_ins_seq_id,
        corporate_name,
        claim_seq_id,
        claim_number,
        shortfall_id ,
        inward_status_general_type_id,
        remarks,
        added_by,
        added_date )
      VALUES (
        clm_inward_seq.NEXTVAL ,
        v_tpa_office_seq_id,
        v_claims_inward_no ,
        v_barcode_no,
        v_document_general_type_id,
        v_rcvd_date,
        v_source_general_type_id,
        v_courier_seq_id,
        v_claim_general_type_id,
        v_inward_ins_seq_id,
        v_corporate_name,
        v_parent_claim_seq_id,
        v_claim_number,
        v_shortfall_id ,
        v_inward_stat_general_type_id,
        v_remarks,
        v_added_by,
        SYSDATE ) RETURNING claims_inward_seq_id INTO v_claims_inward_seq_id;

 --KOC_INS_MAIL
      OPEN CIGNA_NOTIFY_CUR(v_tpa_enrollment_id);
      FETCH CIGNA_NOTIFY_CUR INTO v_notify_typ_id,V_INS_COMP_NAME;
      CLOSE CIGNA_NOTIFY_CUR;

       IF V_INS_COMP_NAME LIKE 'CIGNA%' AND v_notify_typ_id='NIC' THEN
         V_CIGNA_YN:='Y';
        ELSE
          V_CIGNA_YN:='N';
       END IF;
        --KOC_INS_MAIL
    IF ( v_inward_stat_general_type_id = 'IWC' ) AND v_document_general_type_id = 'DTS' THEN

        OPEN shortfall_cur;
        FETCH shortfall_cur INTO v_shortfall_seq_id,v_shortfall_clm_seq_id,v_clm_completed_yn,v_shortfall_status_type_id;
        CLOSE shortfall_cur;


        IF v_clm_completed_yn = 'Y' THEN
          raise_application_error(-20152 ,' Modification Not Allowed , Reviews are Completed ');
        END IF;
        --SELECT A.claim_seq_id INTO v_shortfall_clm_seq_id FROM clm_general_details A WHERE A.claim_number=v_claim_number;
        --IF v_document_general_type_id = 'DTS' THEN  --short fall
           save_inward_shortfall ( v_shortfall_id, v_claim_number , v_added_by ,'UPD',v_shortfall_seq_id );

           v_log_remarks:='System Remarks:-Shortfall: '||v_shortfall_id||' status has been modified from '||v_shortfall_status_type_id||' to Responded through Inward: '||v_claims_inward_no||'.';
           insert into pat_log(pat_log_seq_id,system_gen_yn,pat_log_general_type_id,reference_date,remarks,added_by,added_date,claim_seq_id)
             values (pat_log_seq.nextval,'N','SYS',sysdate,v_log_remarks,v_added_by,sysdate,v_shortfall_clm_seq_id);
        --END IF;
    END IF;
    IF v_document_general_type_id != 'DTS' THEN

       IF v_document_general_type_id = 'DTA' THEN
         do_copy_previous_claim ( v_clm_seq_id , v_clm_enroll_detail_seq_id ,  v_parent_claim_seq_id  , v_claims_inward_seq_id , v_requested_amount, v_added_by );
       ELSE
         save_inward_claim(
              v_clm_seq_id ,
              v_claims_inward_seq_id ,
              v_mode_general_type_id ,
              v_requested_amount ,
              v_clm_enroll_detail_seq_id ,
              v_member_seq_id ,
              v_tpa_enrollment_id,
              v_claimant_name,
              v_policy_holder_name,
              v_employee_name,
              v_employee_no ,
              v_policy_number ,
              v_policy_seq_id,
              v_tpa_office_seq_id ,
              v_document_general_type_id ,
              v_email_id ,
              v_notification_phone_number ,
              v_ins_scheme ,
              v_certificate_no ,
              v_ins_customer_code ,
              v_added_by,
              v_rows_processed );
       END IF;
    END IF;
  ELSE
     SELECT a.inward_status_general_type_id, a.document_general_type_id  , a.claim_number , a.claim_seq_id , a.shortfall_id ,a.tpa_office_seq_id ,a.claims_inward_no
       INTO v_prev_status ,v_prev_document_type_id , v_prev_claim_number , v_prev_claim_seq_id ,v_prev_shortfall_id , v_prev_tpa_office_seq_id , v_claims_inward_no
       FROM clm_inward a WHERE a.claims_inward_seq_id = v_claims_inward_seq_id;

     IF v_prev_tpa_office_seq_id != v_tpa_office_seq_id THEN
       v_claims_inward_no      := PRE_AUTH_PKG.generate_id_numbers('INW', v_tpa_office_seq_id , NULL, v_added_by);
     END IF;

     IF v_prev_status = 'IWC' THEN
       RAISE_APPLICATION_ERROR (-20153,'Inward Entry is Completed');
     END IF;

     UPDATE clm_inward SET
        claims_inward_no                        = v_claims_inward_no,
        tpa_office_seq_id                       = v_tpa_office_seq_id,
        barcode_no                              = v_barcode_no,
        document_general_type_id                = v_document_general_type_id,
        rcvd_date                               = v_rcvd_date,
        source_general_type_id                  = v_source_general_type_id,
        courier_seq_id                          = v_courier_seq_id,
        claim_general_type_id                   = v_claim_general_type_id,
        inward_ins_seq_id                       = v_inward_ins_seq_id,
        corporate_name                          = v_corporate_name,
        claim_seq_id                            = v_parent_claim_seq_id,
        claim_number                            = v_claim_number,
        shortfall_id                            = v_shortfall_id ,
        inward_status_general_type_id           = v_inward_stat_general_type_id,
        remarks                                 = v_remarks,
        updated_by                              = v_added_by,
        updated_date                            = SYSDATE
       WHERE claims_inward_seq_id = v_claims_inward_seq_id;

       IF v_parent_claim_seq_id != v_prev_claim_seq_id THEN        
         delete_claim_records ( v_clm_seq_id );
         v_clm_enroll_detail_seq_id := NULL;
       END IF;

       IF v_document_general_type_id = 'DTA' THEN    -- AMMENDMENT
         do_copy_previous_claim ( v_clm_seq_id , v_clm_enroll_detail_seq_id ,  v_parent_claim_seq_id  , v_claims_inward_seq_id , v_requested_amount,  v_added_by );
       ELSIF v_document_general_type_id = 'DTC' THEN  -- CLAIM
         save_inward_claim(
            v_clm_seq_id ,
            v_claims_inward_seq_id ,
            v_mode_general_type_id ,
            v_requested_amount ,
            v_clm_enroll_detail_seq_id ,
            v_member_seq_id ,
            v_tpa_enrollment_id,
            v_claimant_name,
            v_policy_holder_name,
            v_employee_name,
            v_employee_no ,
            v_policy_number ,
            v_policy_seq_id,
            v_tpa_office_seq_id ,
            v_document_general_type_id ,
            v_email_id ,
            v_notification_phone_number ,
            v_ins_scheme   ,
            v_certificate_no ,
            v_ins_customer_code ,
            v_added_by,
            v_rows_processed );

       ELSE -- SHORTFALL
         IF v_claim_number != v_prev_claim_number OR v_shortfall_id != v_prev_shortfall_id THEN
           IF ( v_inward_stat_general_type_id = 'IWC' ) THEN

              --SELECT A.claim_seq_id,A.completed_yn INTO v_shortfall_clm_seq_id,v_clm_completed_yn FROM clm_general_details A WHERE A.claim_number=v_claim_number;
              OPEN shortfall_cur;
              FETCH shortfall_cur INTO v_shortfall_seq_id,v_shortfall_clm_seq_id,v_clm_completed_yn,v_shortfall_status_type_id;
              CLOSE shortfall_cur;


              IF v_clm_completed_yn = 'Y' THEN
                 raise_application_error(-20152 ,' Modification Not Allowed , Reviews are Completed ');
              ELSE

                 save_inward_shortfall ( v_prev_shortfall_id,  v_prev_claim_number , v_added_by ,'DEL',v_shortfall_seq_id ); -- CLEAR PREVIOUS SHORTFALL
                 save_inward_shortfall ( v_shortfall_id,  v_claim_number , v_added_by ,'UPD' ,v_shortfall_seq_id); -- UPDATE CURRENT SHORTFALL
                 v_log_remarks:='System Remarks:-Shortfall: '||v_shortfall_id||' status has been modified from '||v_shortfall_status_type_id||' to Responded through Inward: '||v_claims_inward_no||'.';
                 insert into pat_log(pat_log_seq_id,system_gen_yn,pat_log_general_type_id,reference_date,remarks,added_by,added_date,claim_seq_id)
                 values (pat_log_seq.nextval,'N','SYS',sysdate,v_log_remarks,v_added_by,sysdate,v_shortfall_clm_seq_id);
              END IF;
           END IF;
         ELSE
           OPEN shortfall_cur;
           FETCH shortfall_cur INTO v_shortfall_seq_id,v_shortfall_clm_seq_id,v_clm_completed_yn,v_shortfall_status_type_id;
           CLOSE shortfall_cur;



           IF ( v_inward_stat_general_type_id = 'IWC' ) THEN
              IF v_clm_completed_yn = 'Y' THEN
                 raise_application_error(-20152 ,' Modification Not Allowed , Reviews are Completed ');
              ELSE
                 save_inward_shortfall ( v_shortfall_id, v_claim_number , v_added_by ,'UPD',v_shortfall_seq_id );
                 v_log_remarks:='System Remarks:-Shortfall: '||v_shortfall_id||' status has been modified from '||v_shortfall_status_type_id||' to Responded through Inward: '||v_claims_inward_no||'.';
                 insert into pat_log(pat_log_seq_id,system_gen_yn,pat_log_general_type_id,reference_date,remarks,added_by,added_date,claim_seq_id)
                 values (pat_log_seq.nextval,'N','SYS',sysdate,v_log_remarks,v_added_by,sysdate,v_shortfall_clm_seq_id);
               END IF;
           END IF;
         END IF;
       END IF;
    END IF;
    IF ( v_inward_stat_general_type_id = 'IWC' ) THEN
          -------------------------ADDED FOR KOC1137

      BEGIN
        SELECT VIP_YN INTO V_VIP_YN FROM TPA_ENR_POLICY_MEMBER WHERE MEMBER_SEQ_ID=V_MEMBER_SEQ_ID;
      EXCEPTION
       WHEN no_data_found THEN
         V_VIP_YN:=null;
     END;
    IF V_VIP_YN='Y' THEN
           app.GENERATE_MAIL_PKG.proc_form_message ( 'VIP_CLAIM_INTIMATION', v_claims_inward_seq_id,v_added_by , v_dest_msg_seq_id1);--KOC1137
      OPEN GET_CLM_IW_SEQ_ID(v_claims_inward_seq_id);
      FETCH  GET_CLM_IW_SEQ_ID INTO V_CLM_IW_SEQ_ID;
      CLOSE GET_CLM_IW_SEQ_ID;
       IF V_CLM_IW_SEQ_ID IS  NULL THEN
         INSERT INTO CLM_REMINDER(CLM_IW_SEQ_ID,INTIMATED_YN,ADDED_DATE) VALUES (v_claims_inward_seq_id,'N',SYSDATE);
       ELSE
        UPDATE CLM_REMINDER SET ADDED_DATE=SYSDATE WHERE CLM_IW_SEQ_ID=V_CLM_IW_SEQ_ID;
       END IF;
    END IF;
   ------------------------ ABOVE CODE/CODITON FROM KOC1137 ADDED FOR KOC1137
      IF ( v_claim_general_type_id = 'CTM' ) AND V_CIGNA_YN!='Y' THEN -- Member Claim
        app.GENERATE_MAIL_PKG.proc_form_message ( 'CLAIM_INWARD_MR', v_claims_inward_seq_id,v_added_by , v_dest_msg_seq_id);
      ELSIF ( v_claim_general_type_id = 'CNH' ) AND V_CIGNA_YN!='Y' THEN -- Network Claim
        app.GENERATE_MAIL_PKG.proc_form_message ( 'CLAIM_INWARD_NHCP', v_claims_inward_seq_id,v_added_by , v_dest_msg_seq_id);
      ELSIF v_shortfall_seq_id IS NOT NULL AND V_CIGNA_YN!='Y' THEN
        app.GENERATE_MAIL_PKG.proc_form_message ( 'CLAIM_SHORTFALL_RECEIVED',  v_shortfall_seq_id, v_added_by,  v_dest_msg_seq_id);
      END IF;

    END IF;

    IF v_source_general_type_id != 'CPN' THEN
      COMMIT;
    END IF;
  END save_clm_inward_entry;
 --==============================================================================================
 --   Name       : 1
 --   Created on : -23-JUL-06
 --   Created By : - S.V.SREERAJ
 --   Comments   :
 --==============================================================================================
  PROCEDURE save_clm_enroll(
    v_clm_enroll_detail_seq_id           IN  OUT CLM_ENROLL_DETAILS.clm_enroll_detail_seq_id%TYPE,
    v_claim_seq_id                       IN  CLM_ENROLL_DETAILS.claim_seq_id%TYPE,
    v_gender_general_type_id             IN  CLM_ENROLL_DETAILS.gender_general_type_id%TYPE,
    v_member_seq_id                      IN  CLM_ENROLL_DETAILS.member_seq_id%TYPE,
    v_tpa_enrollment_id                  IN  CLM_ENROLL_DETAILS.tpa_enrollment_id%TYPE,
    v_policy_seq_id                      IN  CLM_ENROLL_DETAILS.policy_seq_id%TYPE,
    v_policy_holder_name                 IN  CLM_ENROLL_DETAILS.policy_holder_name%TYPE,
    v_employee_no                        IN  CLM_ENROLL_DETAILS.employee_no%TYPE,
    v_employee_name                      IN  CLM_ENROLL_DETAILS.employee_name%TYPE,
    v_mem_age                            IN  CLM_ENROLL_DETAILS.mem_age%TYPE,
    v_claimant_name                      IN  CLM_ENROLL_DETAILS.claimant_name%TYPE,
    v_date_of_inception                  IN  CLM_ENROLL_DETAILS.date_of_inception%TYPE,
    v_date_of_exit                       IN  CLM_ENROLL_DETAILS.date_of_exit%TYPE,
    v_relship_type_id                    IN  CLM_ENROLL_DETAILS.relship_type_id%TYPE,
    v_policy_number                      IN  CLM_ENROLL_DETAILS.policy_number%TYPE,
    v_claimant_phone_number              IN  CLM_ENROLL_DETAILS.claimant_phone_number%TYPE,
    v_mem_total_sum_insured              IN  CLM_ENROLL_DETAILS.mem_total_sum_insured%TYPE,
    v_enrol_type_id                      IN  CLM_ENROLL_DETAILS.enrol_type_id%TYPE,
    v_policy_sub_general_type_id         IN  CLM_ENROLL_DETAILS.policy_sub_general_type_id%TYPE,
    v_phone_1                            IN  CLM_ENROLL_DETAILS.phone_1%TYPE,
    v_policy_effective_from              IN  CLM_ENROLL_DETAILS.policy_effective_from%TYPE,
    v_policy_effective_to                IN  CLM_ENROLL_DETAILS.policy_effective_to%TYPE,
    v_ins_status_general_type_id         IN  CLM_ENROLL_DETAILS.ins_status_general_type_id%TYPE,
    v_ins_seq_id                         IN  CLM_ENROLL_DETAILS.ins_seq_id%TYPE,
    v_group_reg_seq_id                   IN  CLM_ENROLL_DETAILS.group_reg_seq_id%TYPE,
    v_email_id                           IN  CLM_ENROLL_DETAILS.email_id%TYPE,  --//ED
    v_notification_phone_number          IN  CLM_ENROLL_DETAILS.notification_phone_number%TYPE, --//ED
    v_ins_scheme                         IN  PAT_ENROLL_DETAILS.ins_scheme%TYPE,
    v_certificate_no                     IN  PAT_ENROLL_DETAILS.certificate_no%TYPE,
    v_ins_customer_code                  IN  PAT_ENROLL_DETAILS.ins_customer_code%TYPE,
    v_added_by                           IN  CLM_ENROLL_DETAILS.added_by%TYPE,
    v_rows_processed                     IN  OUT NUMBER,
    v_modification_mode_value            IN  pat_enroll_details.modification_mode_value%TYPE := NULL,
    v_parent_modif_mode_value            IN  CLM_ENROLL_DETAILS.modification_mode_value%TYPE := NULL
  )
  IS

    v_decision_date                      CLM_ENROLL_DETAILS.decision_date%TYPE;
    v_rson_general_type_id               CLM_ENROLL_DETAILS.rson_general_type_id%TYPE;
    v_policy_group_seq_id                tpa_enr_policy_member.policy_group_seq_id%type; --koc1142
  BEGIN
       SELECT sum(a.policy_group_seq_id) INTO v_policy_group_seq_id  --koc1142
        FROM tpa_enr_policy_member a
       WHERE a.member_seq_id = v_member_seq_id;
     pre_auth_pkg.rest_buff_amt_chng(v_policy_group_seq_id);

    IF NVL(v_clm_enroll_detail_seq_id,0) = 0  THEN
      INSERT INTO clm_enroll_details(
        clm_enroll_detail_seq_id,
        claim_seq_id,
        gender_general_type_id,
        member_seq_id,
        tpa_enrollment_id,
        policy_seq_id,
        policy_holder_name,
        employee_no,
        employee_name,
        mem_age,
        claimant_name,
        date_of_inception,
        date_of_exit,
        relship_type_id,
        policy_number,
        claimant_phone_number,
        mem_total_sum_insured,
        clm_status_general_type_id,
        decision_date,
        rson_general_type_id,
        enrol_type_id,
        policy_sub_general_type_id,
        phone_1,
        policy_effective_from,
        policy_effective_to,
        ins_status_general_type_id,
        ins_seq_id,
        group_reg_seq_id,
        email_id, --//ED
        notification_phone_number, --//ED
        ins_scheme,
        certificate_no,
        ins_customer_code,
        modification_mode_value,
        added_by,
        added_date )
      VALUES (
        clm_enroll_detail_seq.NEXTVAL ,
        v_claim_seq_id,
        v_gender_general_type_id,
        v_member_seq_id,
        v_tpa_enrollment_id,
        v_policy_seq_id,
        v_policy_holder_name,
        v_employee_no,
        v_employee_name,
        v_mem_age,
        v_claimant_name,
        v_date_of_inception,
        v_date_of_exit,
        v_relship_type_id,
        v_policy_number,
        v_claimant_phone_number,
        v_mem_total_sum_insured,
        'INP',
        v_decision_date,
        v_rson_general_type_id,
        v_enrol_type_id,
        v_policy_sub_general_type_id,
        v_phone_1,
        v_policy_effective_from,
        v_policy_effective_to,
        v_ins_status_general_type_id,
        v_ins_seq_id,
        v_group_reg_seq_id,
        ttk_util_pkg.fn_encrypt(v_email_id), --/ED
        v_notification_phone_number, --//ED need to verify
        v_ins_scheme,
        v_certificate_no,
        v_ins_customer_code,
        v_parent_modif_mode_value,
        v_added_by,
        SYSDATE) RETURNING clm_enroll_detail_seq_id INTO v_clm_enroll_detail_seq_id;

      --koc decoupling
      for rec in (select i.claim_seq_id
                    from app.clm_general_details g, app.clm_inward i
                   where i.claims_inward_seq_id = g.claims_inward_seq_id
                     and g.claim_seq_id = v_claim_seq_id
                     and i.document_general_type_id != 'DTA') loop

        insert into app.clm_data_entry_complete (claim_seq_id)
        values (v_claim_seq_id); --koc decoupling
      end loop;
      --koc decoupling


    ELSE
      UPDATE clm_enroll_details SET
        gender_general_type_id                  = v_gender_general_type_id,
        member_seq_id                           = v_member_seq_id,
        tpa_enrollment_id                       = v_tpa_enrollment_id,
        policy_seq_id                           = v_policy_seq_id,
        policy_holder_name                      = v_policy_holder_name,
        employee_no                             = v_employee_no,
        employee_name                           = v_employee_name,
        mem_age                                 = v_mem_age,
        claimant_name                           = v_claimant_name,
        date_of_inception                       = v_date_of_inception,
        date_of_exit                            = v_date_of_exit,
        relship_type_id                         = v_relship_type_id,
        policy_number                           = v_policy_number,
        claimant_phone_number                   = v_claimant_phone_number,
        mem_total_sum_insured                   = v_mem_total_sum_insured,
        decision_date                           = v_decision_date,
        rson_general_type_id                    = v_rson_general_type_id,
        enrol_type_id                           = v_enrol_type_id,
        policy_sub_general_type_id              = v_policy_sub_general_type_id,
        phone_1                                 = v_phone_1,
        policy_effective_from                   = v_policy_effective_from,
        policy_effective_to                     = v_policy_effective_to,
        ins_status_general_type_id              = v_ins_status_general_type_id,
        ins_seq_id                              = v_ins_seq_id,
        group_reg_seq_id                        = v_group_reg_seq_id,
        modification_mode_value                 = CASE WHEN v_modification_mode_value > 0 THEN modification_mode_value - v_modification_mode_value ELSE modification_mode_value END,
        email_id                                = ttk_util_pkg.fn_encrypt(v_email_id), --//ED
        notification_phone_number               = v_notification_phone_number, --//ED need to verify
        ins_scheme                              = v_ins_scheme,
        certificate_no                          = v_certificate_no,
        ins_customer_code                       = v_ins_customer_code,
        updated_by                              = v_added_by,
        updated_date                            = SYSDATE
        WHERE claim_seq_id = v_claim_seq_id;
    END IF;
    v_rows_processed := SQL%ROWCOUNT;
  END save_clm_enroll;
 --=======================================================================================================
PROCEDURE set_save_enroll(
    v_clm_enroll_detail_seq_id          IN OUT CLM_ENROLL_DETAILS.clm_enroll_detail_seq_id%TYPE,
    v_claim_seq_id                      IN CLM_GENERAL_DETAILS.Claim_Seq_Id%TYPE,
    v_member_seq_id                     IN CLM_ENROLL_DETAILS.MEMBER_SEQ_ID%TYPE,
    v_tpa_enrollment_id                 IN CLM_ENROLL_DETAILS.Tpa_Enrollment_Id%TYPE,
    v_claimant_name                     IN CLM_ENROLL_DETAILS.Claimant_Name%TYPE,
    v_policy_holder_name                IN CLM_ENROLL_DETAILS.Policy_Holder_Name%TYPE,
    v_employee_name                     IN CLM_ENROLL_DETAILS.Employee_Name%TYPE,
    v_employee_no                       IN CLM_ENROLL_DETAILS.Employee_No%TYPE ,
    v_policy_number                     IN CLM_ENROLL_DETAILS.Policy_Number%TYPE ,
    v_policy_seq_id                     IN CLM_ENROLL_DETAILS.Policy_Seq_Id%TYPE,
    v_email_id                          IN CLM_ENROLL_DETAILS.email_id%TYPE, --//ED
    v_notification_phone_number         IN CLM_ENROLL_DETAILS.notification_phone_number%TYPE, --//ED
    v_ins_scheme                        IN CLM_ENROLL_DETAILS.ins_scheme%TYPE,
    v_certificate_no                    IN CLM_ENROLL_DETAILS.certificate_no%TYPE,
    v_ins_customer_code                 IN CLM_ENROLL_DETAILS.ins_customer_code%TYPE,
    v_added_by                          IN NUMBER,
    v_rows_processed                    OUT NUMBER
  )

  IS
     CURSOR member_cur IS
     SELECT
        A.member_seq_id,
        A.policy_group_seq_id,
        A.tpa_enrollment_id,
        A.mem_name,
        A.relship_type_id,
        B.insured_name ,
        B.employee_no,
        A.gender_general_type_id,
        D.description gender,
        A.mem_age,
        C.policy_number,
        C.ins_seq_id,
        C.group_reg_seq_id,
        A.date_of_inception,
        A.date_of_exit,
        nvl(a.mem_tot_sum_insured,b.family_tot_sum_insured) AS mem_tot_sum_insured,
        NULL AS avail_sum_insured ,
        C.enrol_type_id,
        C.product_seq_id,
        C.policy_sub_general_type_id,
        C.ins_status_general_type_id,
        C.tpa_status_general_type_id,
        NVL(ttk_util_pkg.fn_decrypt(H.mobile_no), H.res_phone_no) phone, --//ED
        H.off_phone_no_1,
        C.effective_from_date,
        C.effective_to_date,
        C.policy_seq_id ,
        c.ins_scheme,
        b.certificate_no,
        a.ins_customer_code
       FROM tpa_enr_policy_member A JOIN tpa_enr_policy_group B ON (A.policy_group_seq_id = B.policy_group_seq_id AND A.deleted_yn = 'N' AND B.deleted_yn = 'N')
       JOIN tpa_enr_policy  C ON (B.policy_seq_id = C.policy_seq_id AND C.deleted_yn = 'N')
       JOIN tpa_general_code D ON (A.gender_general_type_id = D.general_type_id)
       JOIN tpa_ins_info E ON (C.ins_seq_id = E.ins_seq_id)
       LEFT OUTER JOIN tpa_group_registration F ON (C.group_reg_seq_id = F.group_reg_seq_id)
       LEFT OUTER JOIN tpa_general_code G ON (A.category_general_type_id = G.general_type_id)
       LEFT OUTER JOIN tpa_enr_mem_address H ON (A.enr_address_seq_id = H.enr_address_seq_id)
       WHERE  A.member_seq_id = v_member_seq_id;

      member_rec                   member_cur%ROWTYPE;
      CURSOR enroll_cur IS SELECT clm_enroll_detail_seq_id
        FROM clm_enroll_details a WHERE a.claim_seq_id = v_claim_seq_id ;

  BEGIN

     OPEN member_cur ;
     FETCH member_cur INTO member_rec;
     CLOSE member_cur;

     OPEN enroll_cur;
     FETCH enroll_cur INTO v_clm_enroll_detail_seq_id;
     CLOSE enroll_cur;


    save_clm_enroll (
        v_clm_enroll_detail_seq_id ,
        v_claim_seq_id ,
        member_rec.gender_general_type_id,
        v_member_seq_id ,
        v_tpa_enrollment_id   ,
        member_rec.policy_seq_id  ,
        v_policy_holder_name ,
        v_employee_no  ,
        v_employee_name  ,
        member_rec.mem_age   ,
        v_claimant_name ,
        member_rec.date_of_inception  ,
        member_rec.date_of_exit    ,
        member_rec.relship_type_id  ,
        v_policy_number  ,
        member_rec.phone        ,
        member_rec.mem_tot_sum_insured ,
        member_rec.enrol_type_id ,
        member_rec.policy_sub_general_type_id   ,
        member_rec.off_phone_no_1 , --v_phone_1    ,
        member_rec.effective_from_date ,
        member_rec.effective_to_date ,
        member_rec.ins_status_general_type_id  ,
        member_rec.ins_seq_id  ,
        member_rec.group_reg_seq_id  ,
        v_email_id , --//ED do it in main procedure
        v_notification_phone_number , --//ED need to verify
        v_ins_scheme,
        v_certificate_no,
        v_ins_customer_code,
        v_added_by ,
        v_rows_processed
    );
  END set_save_enroll;
-- =================================================================================================================
PROCEDURE select_clm_inward_list(
    v_claims_inward_no               IN  CLM_INWARD.claims_inward_no%TYPE,
    v_claim_general_type_id          IN  CLM_INWARD.claim_general_type_id%TYPE,
    v_start_date                     IN  VARCHAR2,
    v_end_date                       IN  VARCHAR2,
    v_tpa_enrollment_id              IN  CLM_ENROLL_DETAILS.tpa_enrollment_id%TYPE,
    v_corporate_name                 IN  CLM_INWARD.corporate_name%TYPE,
    v_inward_stat_general_type_id     IN  CLM_INWARD.inward_status_general_type_id%TYPE,
    v_tpa_office_seq_id              IN  CLM_INWARD.tpa_office_seq_id%TYPE,
    v_inward_claim_number            IN  CLM_GENERAL_DETAILS.claim_number%TYPE,
    v_ins_scheme                         IN  PAT_ENROLL_DETAILS.ins_scheme%TYPE,
    v_certificate_no                     IN  PAT_ENROLL_DETAILS.certificate_no%TYPE,
    v_sort_var                       IN  VARCHAR2 ,
    v_sort_order                     IN  VARCHAR2 ,
    v_start_num                      IN  NUMBER,
    v_end_num                        IN  NUMBER ,
    v_added_by                       IN  NUMBER,
    result_set                       OUT SYS_REFCURSOR
  )
  IS

    TYPE bind_tab_type IS TABLE OF VARCHAR2(250) INDEX BY BINARY_INTEGER ;
    v_rcvd_start_date              DATE :=  TO_DATE(v_start_date,'dd/mm/yyyy');
    v_rcvd_end_date                DATE :=  TO_DATE(v_end_date,'dd/mm/yyyy');
    v_sql_str                      VARCHAR2(4000);
    v_where                              VARCHAR2(2000);
    bind_tab                             bind_tab_type;
    i                                    NUMBER(2) := 0;

  BEGIN
    v_sql_str :=
     'SELECT
         A.claims_inward_seq_id,
         A.claims_inward_no,
         A.rcvd_date,
         C.claim_seq_id,
         D.clm_enroll_detail_seq_id,
         D.tpa_enrollment_id,
         D.claimant_name,
         A.corporate_name,
         A.claim_general_type_id,
         B.description,
         A.document_general_type_id
         FROM clm_inward A LEFT OUTER JOIN tpa_general_code B ON ( A.claim_general_type_id = B.general_type_id )
         LEFT OUTER JOIN clm_general_details C ON (A.claims_inward_seq_id = c.claims_inward_seq_id )
         LEFT OUTER JOIN clm_enroll_details D ON ( c.claim_seq_id = d.claim_seq_id)
         ';

    IF v_claims_inward_no IS NOT NULL THEN
       v_where := v_where || ' AND a.claims_inward_no = :v_claims_inward_no ';
       i := i+1;
       bind_tab(i) := UPPER(v_claims_inward_no) ;
    END IF;
    IF v_claim_general_type_id IS NOT NULL THEN
       v_where := v_where || ' AND a.claim_general_type_id = :v_claim_general_type_id ';
       i := i+1;
       bind_tab(i) := v_claim_general_type_id;
    END IF;
    IF v_tpa_enrollment_id IS NOT NULL THEN
       -- like changed to =
       v_where := v_where || ' AND d.tpa_enrollment_id = :v_tpa_enrollment_id';
       i := i+1;
       bind_tab(i) := UPPER(v_tpa_enrollment_id);
    END IF;

    IF v_corporate_name IS NOT NULL THEN
       v_where := v_where || ' AND corporate_name LIKE :v_corporate_name ';
       i := i+1;
       bind_tab(i) := v_corporate_name||'%';
    END IF;
    IF v_tpa_office_seq_id IS NOT NULL THEN
       v_where := v_where || ' AND tpa_office_seq_id = :v_tpa_office_seq_id ';
       i := i+1;
       bind_tab(i) := v_tpa_office_seq_id;
    END IF;
    IF v_rcvd_start_date IS NOT NULL THEN
       v_where := v_where || ' AND rcvd_date >= :v_rcvd_start_date ';
       i := i+1;
       bind_tab(i) := v_rcvd_start_date;
    END IF;
    IF v_rcvd_end_date IS NOT NULL THEN
       v_where := v_where || ' AND rcvd_date <= :v_rcvd_end_date ';
       i := i+1;
       bind_tab(i) := v_rcvd_end_date;
    END IF;
    IF v_inward_claim_number IS NOT NULL THEN
        -- like changed to =
       v_where := v_where || ' AND c.claim_number = :v_inward_claim_number';
       i := i+1;
       bind_tab(i) := UPPER(v_inward_claim_number);
    END IF;

    IF v_ins_scheme IS NOT NULL THEN
      v_where := v_where  ||' AND  d.ins_scheme = :v_ins_scheme  ';
       i := i+1;
       bind_tab(i) := v_ins_scheme;
    END IF;
    IF v_certificate_no IS NOT NULL THEN
      v_where := v_where  ||' AND d.certificate_no = :v_certificate_no ';
       i := i+1;
       bind_tab(i) := v_certificate_no;
    END IF;

--KOC_Cigna_insurance_resriction
    if v_added_by IS NOT NULL THEN
        v_where := v_where ||' AND ( D.ins_seq_id  in (SELECT inf.ins_seq_id FROM APP.TPA_GROUP_USER_ASSOC UA
      JOIN APP.TPA_GROUP_BRANCH GB ON (GB.GROUP_BRANCH_SEQ_ID = UA.GROUP_BRANCH_SEQ_ID)
      join APP.TPA_INS_INFO INF ON (inf.user_group = gb.group_branch_seq_id)
      WHERE GB.USER_TYPE=''NIC'' AND  UA.CONTACT_SEQ_ID = '||v_added_by||') OR (SELECT count(inf.ins_seq_id) FROM APP.TPA_GROUP_USER_ASSOC UA
      JOIN APP.TPA_GROUP_BRANCH GB ON (GB.GROUP_BRANCH_SEQ_ID = UA.GROUP_BRANCH_SEQ_ID)
      join APP.TPA_INS_INFO INF ON (inf.user_group = gb.group_branch_seq_id)
      WHERE GB.USER_TYPE=''NIC'' AND  UA.CONTACT_SEQ_ID = '||v_added_by||') = 0 )';
    end if;
--KOC_Cigna_insurance_resriction


    v_where := v_where ||' AND A.inward_status_general_type_id = :v_inward_stat_general_type_id ';
    v_where := ' WHERE '|| SUBSTR(v_where,5);
    v_sql_str := v_sql_str ||v_where;

    v_sql_str := 'SELECT * FROM
            (SELECT A.*,DENSE_RANK() OVER (ORDER BY '||v_sort_var||' '||v_sort_order||',ROWNUM) Q FROM (' ||v_sql_str|| ') A )
             WHERE  Q>= :v_start_num AND Q<= :v_end_num ';



    IF bind_tab.FIRST IS NOT NULL THEN
       CASE bind_tab.COUNT
         WHEN 1 THEN OPEN result_set FOR v_sql_str USING bind_tab(1) ,v_inward_stat_general_type_id, v_start_num , v_end_num ;
         WHEN 2 THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),v_inward_stat_general_type_id, v_start_num , v_end_num ;
         WHEN 3 THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3),v_inward_stat_general_type_id , v_start_num , v_end_num ;
         WHEN 4 THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4),v_inward_stat_general_type_id ,v_start_num ,v_end_num ;
         WHEN 5 THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),v_inward_stat_general_type_id ,v_start_num , v_end_num ;
         WHEN 6 THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5) ,bind_tab(6) ,v_inward_stat_general_type_id ,v_start_num , v_end_num ;
         WHEN 7 THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5) ,bind_tab(6) ,bind_tab(7) ,v_inward_stat_general_type_id ,v_start_num , v_end_num ;
         WHEN 8 THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5) ,bind_tab(6) ,bind_tab(7) ,bind_tab(8),v_inward_stat_general_type_id ,v_start_num , v_end_num ;
         WHEN 9 THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5) ,bind_tab(6) ,bind_tab(7) ,bind_tab(8),bind_tab(9),v_inward_stat_general_type_id ,v_start_num , v_end_num ;
         WHEN 10 THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5) ,bind_tab(6) ,bind_tab(7) ,bind_tab(8),bind_tab(9),bind_tab(10),v_inward_stat_general_type_id ,v_start_num , v_end_num ;
         WHEN 11 THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5) ,bind_tab(6) ,bind_tab(7) ,bind_tab(8),bind_tab(9),bind_tab(10),bind_tab(11),v_inward_stat_general_type_id ,v_start_num , v_end_num ;

       END CASE;
    ELSE
      OPEN result_set FOR v_sql_str USING v_inward_stat_general_type_id, v_start_num , v_end_num ;
    END IF;
  END select_clm_inward_list;
-- =================================================================================================================
PROCEDURE select_claim (
    v_claim_seq_id                  IN clm_general_details.claim_seq_id%TYPE,
    v_clm_enroll_detail_seq_id      IN clm_enroll_details.clm_enroll_detail_seq_id%TYPE,
    v_member_seq_id                 IN clm_enroll_details.member_seq_id%TYPE,
    v_added_by                      IN NUMBER,
    v_result_set                    OUT SYS_REFCURSOR
  )
  IS
    v_sum_enhanced_yn                    CHAR(1);
    dis_name_yn                          CHAR(1);
    dis_gend_yn                          CHAR(1);
    dis_age_yn                           CHAR(1);
    dis_policy_num_yn                    CHAR(1);
    dis_policy_holder_yn                 CHAR(1);
    v_curr_event_seq_id                  tpa_event.event_seq_id%TYPE;

    CURSOR event_cur IS SELECT a.event_seq_id
         FROM tpa_event a JOIN tpa_workflow b ON ( a.workflow_seq_id = b.workflow_seq_id )
         WHERE b.sub_general_type_id = 'CLM' AND a.event_owner = 'C';
  v_buff                        SYS_REFCURSOR;
type buff_rec is record
    (buff_count            number,
     buff_amt         buffer_header.pre_auth_buffer_app_amount%type);

buff_tab          buff_rec;
  FUNCTION buff_exist_yn 
  RETURN SYS_REFCURSOR 
  IS
  
  v_result                   SYS_REFCURSOR;
  
  BEGIN
    
    OPEN v_result FOR SELECT COUNT(1) AS buff_count,nvl(NVL(e.pre_auth_buffer_app_amount,O.pre_auth_buffer_app_amount),0)+nvl(nvl(e.claim_app_buffer_amount,o.claim_app_buffer_amount),0) buff_amt 
       FROM clm_general_details A 
        LEFT OUTER JOIN buffer_details D ON ( a.last_buffer_detail_seq_id = d.buff_detail_seq_id )
        LEFT OUTER JOIN buffer_header E ON ( D.buffer_hdr_seq_id = E.buffer_hdr_seq_id )
        LEFT OUTER JOIN pat_general_details I ON (a.pat_enroll_detail_seq_id = I.pat_enroll_detail_seq_id AND I.pat_enhanced_yn = 'N')
        LEFT OUTER JOIN buffer_details N ON ( I.last_buffer_detail_seq_id = N.buff_detail_seq_id )
        LEFT OUTER JOIN buffer_header O ON ( N.buffer_hdr_seq_id = O.buffer_hdr_seq_id )
        WHERE A.claim_seq_id = v_claim_seq_id
        
        GROUP BY nvl(NVL(e.pre_auth_buffer_app_amount,O.pre_auth_buffer_app_amount),0)+nvl(nvl(e.claim_app_buffer_amount,o.claim_app_buffer_amount),0);
  
  RETURN v_result;
    
  END;         

  BEGIN
    IF v_member_seq_id IS NOT NULL THEN
        -- Check whether SUM_INSURED is enhanced or not
      v_sum_enhanced_yn := pre_auth_pkg.check_sum_enhanced(v_member_seq_id);
        -- CHECKING DATA DISCREPANCY
      pre_auth_pkg.check_discrepancy( v_member_seq_id , NULL , v_clm_enroll_detail_seq_id, dis_name_yn , dis_gend_yn , dis_age_yn ,  dis_policy_num_yn , dis_policy_holder_yn );
    END IF;
    OPEN event_cur;
    FETCH event_cur INTO v_curr_event_seq_id;
    CLOSE event_cur;
    
    v_buff:=buff_exist_yn;
    FETCH v_buff INTO buff_tab;
    CLOSE v_buff;
    
    OPEN v_result_set FOR
     SELECT
       A.claim_seq_id,
       B.tpa_enrollment_id,
       dis_name_yn  AS dis_name_yn,
       dis_gend_yn  AS  dis_gend_yn ,
       dis_age_yn   AS dis_age_yn,
       dis_policy_num_yn   AS dis_policy_num_yn,
       dis_policy_holder_yn   AS dis_policy_holder_yn,
       B.claimant_name ,
       B.gender_general_type_id ,
       B.mem_age ,
       B.date_of_inception ,
       B.date_of_exit ,
       B.mem_total_sum_insured ,
       nvl(a.ava_buff_amount,0)   AS buffer_ava_amount , -- to be changed
       NVL(A.ava_sum_insured ,0)   AS ava_sum_insured,
       NVL(A.ava_cum_bonus,0)  AS ava_cum_bonus,
       B.employee_no ,
       B.employee_name ,
       NVL( B.relship_type_id ,XX.relship_type_id ) AS relship_type_id ,
       B.claimant_phone_number ,
       A.claim_number ,
       A.claim_file_number ,
       A.parent_claim_seq_id ,
       c.document_general_type_id AS request_general_type_id ,
       R.description AS request_type ,
       C.claim_general_type_id ,
       d.description AS claim_type,
       A.claim_sub_general_type_id ,
       A.DOM_REASON_GEN_TYPE_ID,---koc1285
       nvl(A.DOC_CERT_DOM_YN,'N')as DOC_CERT_DOM_YN ,---koc1285
       ww.call_recorded_date AS intimation_date,
       A.mode_general_type_id,
       E.Description AS mode_type,
       C.rcvd_date,
       A.treating_dr_name ,
       A.in_patient_no ,
       f.office_name AS ttk_branch,
       c.source_general_type_id,
       g.description AS source_type,
       h.assign_users_seq_id,
       i.contact_name,
       j.office_name AS processing_branch,
       /*nvl(*/a.auth_number/*,k.auth_number)*/ AS auth_number,
       L.pat_general_type_id ,
--       M.Description AS preauth_type ,
       CASE WHEN l.pat_general_type_id = 'REG' THEN 'Regular'
         WHEN l.pat_general_type_id = 'MAN' THEN 'Manual'
         ELSE 'Manual-Regular' END AS preauth_type,
       L.pat_received_date ,
       L.total_app_amount ,
       a.date_of_admission ,
       a.date_of_discharge ,
       b.policy_number ,
       b.enrol_type_id ,
       b.ins_status_general_type_id ,
       b.policy_sub_general_type_id ,
       b.policy_holder_name ,
       b.phone_1 ,
       b.policy_effective_from ,
       b.policy_effective_to ,
       n.ins_comp_name,
       n.ins_comp_code_number AS company_code ,
       O.clm_hosp_assoc_seq_id,
       U.Empanel_Status_Type_Id AS  empanel_type_id,
       T.hosp_seq_id AS hosp_seq_id,
       NVL( T.empanel_number,O.empanel_number ) AS empanel_number,
       NVL( T.hosp_name,O.hosp_name ) AS hosp_name,
       T.serv_tax_rgn_number,
       NVL( SS.address_1,O.address_1 ) AS address_1,
       NVL( SS.address_2,O.address_2 ) AS address_2,
       NVL( SS.address_3,O.address_3 ) AS address_3,
       NVL( TT.state_name,O.state_name ) AS state_name,
       NVL( UU.city_description, O.city_name  ) AS city_name,
       NVL( SS.pin_code,O.pin_code )AS pin_code,
       NVL( T.off_phone_no_1,O.off_phone_no_1 ) AS off_phone_no_1,
       NVL( T.off_phone_no_2,O.off_phone_no_2 ) AS off_phone_no_2,
       NVL( T.office_fax_no,O.office_fax_no ) AS office_fax_no,
       NVL( T.remarks ,O.remarks ) AS remarks,
       ttk_util_pkg.fn_decrypt(T.Primary_Email_Id) as Primary_Email_Id,  --//ED HOSP
       n.ins_seq_id,
       b.clm_enroll_detail_seq_id,
       c.claims_inward_seq_id ,
       l.pat_enroll_detail_seq_id,
       l.pat_gen_detail_seq_id ,
       B.member_seq_id,
       B.policy_seq_id ,
       A.Claims_Remarks ,
       b.group_reg_seq_id,
       s.group_name,
       s.group_id ,
       t.rating,
       v.empanel_description,
       a.requested_amount,
       NULL AS buff_detail_seq_id,
       v_sum_enhanced_yn AS v_sum_enhanced_yn ,
       A.event_seq_id,
       A.required_review_count   ,
       A.review_count ,
       TO_CHAR(A.review_count)||'('||TO_CHAR(A.required_review_count)||')' review ,
       'Event : '||W.event_name AS event_name ,
       A.completed_yn ,
       A.prev_hosp_claim_seq_id ,
       a.discrepancy_present_yn ,
       vv.buffer_allowed_yn ,
       a.claim_dms_reference_id,
       CASE WHEN a.parent_claim_seq_id IS NOT NULL THEN 'Y' ELSE 'N' END ammendment_yn ,
       CASE WHEN a.re_open_type = 'ORC' OR a.re_open_type IS NULL THEN NULL
         WHEN a.re_open_type = 'AMC' THEN 'Ammendment'
         WHEN a.re_open_type = 'CDD' THEN 'Re-open Closed'
         ELSE 'Re-open Rejected'  END AS re_open_type_description,
      a.re_open_type,
      a.doctor_registration_no  ,
      c.claim_number AS prev_claim_number,
      CASE WHEN A.event_seq_id > v_curr_event_seq_id AND c.document_general_type_id != 'DTA'
                 THEN 'Y' ELSE 'N' END AS show_coding_override,
      ttk_util_pkg.fn_decrypt(nvl(b.email_id,bb.email_id)) AS email_id, --//ED
      nvl(b.notification_phone_number,ttk_util_pkg.fn_decrypt(bb.mobile_no)) AS mobile_no, --//ED  -- check for notification number
      CASE WHEN b.modification_mode_value > 0 THEN policy_enrollment_pkg.get_enrl_change_errmsg(b.modification_mode_value) ELSE NULL END AS enrollment_change_msg ,
      CASE WHEN a.parent_claim_seq_id IS NOT NULL AND b.modification_mode_value > 0 AND a.completed_yn != 'Y' THEN 'Y' ELSE 'N' END AS show_reassign_id_yn,
      b.ins_scheme,
      b.certificate_no,
      b.ins_customer_code,
      a.insur_ref_number,
      XX.VIP_YN,--ADD FOR CR KOC1136
--koc1267
    (select  max(l.user_id) from tpa_login_info l where l.contact_seq_id = v_added_by) as User_Id,
  --koc1267
--koc1273
    case when nvl(aa.critical_cash_benefit_yn,'N') = 'N' and a.claim_sub_general_type_id = 'CTL' then
      'Cannot process claim, employee has not opted for critical benefit' else null end as v_critical_msg ,
--koc1273

     case when cii.clm_ins_status is not null and  (cii.clm_ins_status in ('APR','REQ','REJ') OR (CII.CLM_INS_STATUS IN ('INP','REQ') AND CII.INS_INT_RSON_TYPE_ID IS NOT NULL)) AND A.COMPLETED_YN='N' THEN 'Y' ELSE 'N' END AS clm_ins_status,  --koc1247a
    case when b.mem_age >= 60

      then 'Y' else 'N' end as senior_citizen_yn, --koc_griavance
      case when B.clm_status_general_type_id NOT IN ('INP','REQ') 
        THEN CASE WHEN a.event_seq_id BETWEEN 18 AND 19 THEN CASE WHEN buff_tab.buff_count>0 AND ((C.document_general_type_id = 'DTC' AND buff_tab.buff_amt > nvl(a.utilised_buff_amt,0)) OR (C.document_general_type_id = 'DTA' AND  nvl(zz.claim_app_buffer_amount,0)>  nvl(a.utilised_buff_amt,0) )) THEN 'Y'   ELSE 'N' END 
       ELSE 'N' END
         ELSE  'N' END AS BUFF_NOTE_YN,
      case when C.Claim_General_Type_Id='CNH' THEN 
        CASE WHEN  B.clm_status_general_type_id = 'APR' AND ((C.document_general_type_id = 'DTC' AND buff_tab.buff_amt> NVL(a.utilised_buff_amt,0)) OR (C.document_general_type_id = 'DTA' AND  nvl(zz.claim_app_buffer_amount,0)>  nvl(a.utilised_buff_amt,0) ))  AND a.event_seq_id BETWEEN 18 AND 19 then 'Y' 
        ELSE 'N' END 
      ELSE 'N' END AS buffer_restrict_yn,
      CASE WHEN (case when c.claim_general_type_id='CNH' then NVL(tipp.Ins_clm_cl_Apr_Rej_Yn,'N') else NVL(tipp.Ins_clm_cm_Apr_Rej_Yn,'N') end) = 'Y' 
      AND CII.CLM_INS_STATUS in ('INP','REQ')  AND A.COMPLETED_YN='N' THEN 'Y' ELSE 'N' END AS ins_decision_yn,
      a.PAY_TO_GENERAL_TYPE_ID ---opdforhs
      FROM clm_general_details A JOIN clm_enroll_details B ON ( A.claim_seq_id = b.claim_seq_id )
      JOIN clm_inward C ON ( a.claims_inward_seq_id = c.claims_inward_seq_id )
      left outer join app.clm_ins_intimation_details cii on (b.claim_seq_id=cii.claim_seq_id)
      LEFT OUTER JOIN tpa_general_code D ON (c.claim_general_type_id = d.general_type_id)
      LEFT OUTER JOIN tpa_general_code E ON (a.mode_general_type_id = e.general_type_id )
      LEFT OUTER JOIN tpa_office_info F ON ( c.tpa_office_seq_id = f.tpa_office_seq_id )
      LEFT OUTER JOIN tpa_general_code G ON ( C.source_general_type_id = g.general_type_id )
      LEFT OUTER JOIN assign_users H ON (A.last_assign_user_seq_id  = H.assign_users_seq_id)
      LEFT OUTER JOIN tpa_user_contacts i ON (h.assigned_to_user = i.contact_seq_id)
      LEFT OUTER JOIN tpa_office_info j ON ( h.tpa_office_seq_id = j.tpa_office_seq_id )
      LEFT OUTER JOIN pat_general_details L ON (a.Pat_Enroll_Detail_Seq_Id = l.pat_enroll_detail_seq_id AND L.Pat_Enhanced_Yn = 'N' )
      LEFT OUTER JOIN tpa_ins_info N ON (B.ins_seq_id = n.ins_seq_id)
      LEFT OUTER JOIN clm_hospital_association O ON (A.claim_seq_id = O.claim_seq_id)
      LEFT OUTER JOIN tpa_general_code R ON (C.Document_General_Type_Id = R.General_Type_Id )
      LEFT OUTER JOIN tpa_group_registration S ON ( b.group_reg_seq_id = s.group_reg_seq_id )
      LEFT OUTER JOIN tpa_hosp_info t ON ( o.hosp_seq_id = t.hosp_seq_id )
      LEFT OUTER JOIN tpa_hosp_empanel_status U ON (T.hosp_seq_id = U.hosp_seq_id AND U.active_yn = 'Y')
      LEFT OUTER JOIN tpa_hosp_empanel_status_code V ON (U.empanel_status_type_id = V.empanel_status_type_id)
      LEFT OUTER JOIN tpa_event W ON (A.event_seq_id = W.event_seq_id)
      LEFT OUTER JOIN tpa_hosp_address SS ON ( t.hosp_seq_id = SS.hosp_seq_id)
      LEFT OUTER JOIN tpa_state_code TT ON (SS.state_type_id = tt.state_type_id )
      LEFT OUTER JOIN tpa_city_code UU ON ( SS.city_type_id = UU.city_type_id )
      LEFT OUTER JOIN tpa_enr_policy VV ON ( b.policy_seq_id = vv.policy_seq_id )
      LEFT OUTER JOIN tpa_call_log WW ON ( a.call_log_seq_id = ww.call_log_seq_id )
      LEFT OUTER JOIN tpa_enr_policy_member XX ON ( b.member_seq_id = xx.member_seq_id )
      LEFT OUTER JOIN buffer_details yy ON (a.last_buffer_detail_seq_id = yy.buff_detail_seq_id)
      LEFT OUTER JOIN buffer_header zz ON (yy.buffer_hdr_seq_id = zz.buffer_hdr_seq_id)
      LEFT OUTER JOIN tpa_enr_policy_group aa ON (xx.policy_group_seq_id = aa.policy_group_seq_id)
      LEFT OUTER JOIN tpa_enr_mem_address bb ON (aa.enr_address_seq_id = bb.enr_address_seq_id)
      left outer join tpa_ins_prod_policy tipp on (pre_auth_pkg.get_prod_pol_seq_id(a.Claim_Seq_Id,'CLM')=tipp.prod_policy_seq_id)
      WHERE A.claim_seq_id = v_claim_seq_id ;

  END select_claim;
  -- =================================================================================================================
 --   Name       : save_clm_bill_header
 --   Created on : -11-JUL-06
 --   Created By : - S.V.SREERAJ
 --   Comments   :
 --==============================================================================================

  PROCEDURE save_clm_bill_header (
    v_clm_bill_seq_id            IN OUT  clm_bill_header.clm_bill_seq_id%TYPE,
    v_claim_seq_id               IN clm_bill_header.claim_seq_id%TYPE,
    v_bill_no                    IN clm_bill_header.bill_no%TYPE,
    v_bill_date                  IN clm_bill_header.bill_date%TYPE,
    v_bill_issued_by             IN clm_bill_header.bill_issued_by%TYPE,
    v_bills_with_prescription_yn IN clm_bill_header.bills_with_prescription_yn%TYPE,
    v_bill_included_yn           IN clm_bill_header.bill_included_yn%TYPE,
    v_added_by                   IN clm_bill_header.added_by%TYPE,
    v_DONOR_BILL_YN              IN CLM_BILL_HEADER.DONOR_BILL_YN%TYPE,  --KOC DONOR
    v_rows_processed             OUT NUMBER
  )
  IS
  BEGIN
     claims_freeze(v_claim_seq_id,NULL,'S'); --KOCBJJ
    --reassigning user
    pre_auth_pkg.reassign_user (  NULL , v_claim_seq_id ,NULL , v_added_by , 'AUT');

    -- CHECKING WHETHER THE CLAIM IS COMPLETED OR NOT.
    PRE_AUTH_PKG.check_clm_completed ( v_claim_seq_id , NULL ,'REC' ,v_added_by);
    -- Check billdate between member validity period.
--    validate_bill_date ( v_claim_seq_id , v_bill_date );

    IF v_clm_bill_seq_id = 0 THEN
      INSERT INTO clm_bill_header(clm_bill_seq_id, claim_seq_id, bill_no, bill_date, bill_issued_by,
                                  bills_with_prescription_yn ,bill_included_yn , added_by , added_date,
                                  DONOR_BILL_YN ) --koc donor
      VALUES( clm_bill_seq.NEXTVAL, v_claim_seq_id, v_bill_no, v_bill_date, v_bill_issued_by,
             v_bills_with_prescription_yn,v_bill_included_yn , v_added_by, SYSDATE,
             V_DONOR_BILL_YN)  --KOC DONOR
              RETURNING clm_bill_seq_id INTO v_clm_bill_seq_id;

    ELSE
      UPDATE clm_bill_header
        SET  bill_no         = v_bill_no,
             bill_date       = v_bill_date,
             bill_issued_by  = v_bill_issued_by,
             bills_with_prescription_yn = v_bills_with_prescription_yn,
             bill_included_yn = v_bill_included_yn,
             updated_by      = v_added_by,
             updated_date    = SYSDATE,
             DONOR_BILL_YN   = V_DONOR_BILL_YN  --KOC DONOR
             WHERE  clm_bill_seq_id =  v_clm_bill_seq_id;

    END IF;
    v_rows_processed := SQL%ROWCOUNT;
    PRE_AUTH_PKG.set_validation_status('C', v_claim_seq_id ,'U',v_added_by );
   claims_freeze(v_claim_seq_id,NULL,'S'); --KOCBJJ
    --reassigning user
    pre_auth_pkg.reassign_user (  NULL , v_claim_seq_id ,NULL , v_added_by , 'AUT');

    COMMIT;
  END save_clm_bill_header;

 --==============================================================================================
 --   Name       : save_clm_bill_details
 --   Created on : -11-JUL-06
 --   Created By : - S.V.SREERAJ
 --   Comments   :
 --==============================================================================================

  PROCEDURE save_clm_bill_details (
       v_clm_bill_dtl_seq_id IN OUT clm_bill_details.clm_bill_dtl_seq_id%TYPE,
       v_clm_bill_seq_id     IN clm_bill_details.clm_bill_seq_id%TYPE,
       v_description         IN clm_bill_details.description%TYPE,
       v_ward_type_id        IN clm_bill_details.ward_type_id%TYPE,
       v_room_type_id        IN clm_bill_details.room_type_id%TYPE,
       v_number_of_days      IN clm_bill_details.number_of_days%TYPE,
       v_requested_amount    IN clm_bill_details.requested_amount%TYPE,
       v_allow_yn            IN clm_bill_details.allow_yn%TYPE,
       v_allowed_amount      IN clm_bill_details.allowed_amount%TYPE,
       v_remarks             IN clm_bill_details.remarks%TYPE,
       v_added_by            IN clm_bill_details.added_by%TYPE,
       v_vaccination_type_id IN CLM_BILL_DETAILS.VACCINATION_TYPE_ID%TYPE, --KOC1164
       v_Child_Immnunization  IN  CLM_BILL_DETAILS.Child_Immnunization%TYPE,  --KOC1315
       v_well_child_test_type IN  CLM_BILL_DETAILS.well_child_test_type%type,  --koc1316
       v_rout_adult_phys_exam IN  CLM_BILL_DETAILS.Rout_Adult_Phys_Exam%type,
       v_no_of_visits        IN clm_bill_details.no_of_visits%TYPE, --Added for koc1320  --koc1308
       v_rows_processed      OUT NUMBER
  )
  IS
    v_claim_seq_id           clm_general_details.claim_seq_id%TYPE;
    CURSOR claim_cur IS
    SELECT A.date_of_admission,B.hosp_seq_id,d.policy_seq_id,d.product_seq_id , A.claim_seq_id , a.completed_yn
      FROM clm_general_details A INNER JOIN clm_hospital_association B ON A.claim_seq_id = B.claim_seq_id
           INNER JOIN clm_enroll_details C ON A.claim_seq_id = C.claim_seq_id
           INNER JOIN tpa_enr_policy D ON C.policy_seq_id = D.policy_seq_id
    WHERE A.claim_seq_id = v_claim_seq_id;

     rec_claim                claim_cur%ROWTYPE;
     v_ward_max_amt           NUMBER(20,5);
     v_ward_disc_perc         NUMBER(10);

  BEGIN
    SELECT claim_seq_id INTO v_claim_seq_id
       FROM clm_bill_header C WHERE C.clm_bill_seq_id = v_clm_bill_seq_id ;

    OPEN claim_cur;
    FETCH claim_cur INTO rec_claim;
    CLOSE claim_cur;

   claims_freeze(v_claim_seq_id,NULL,'S'); --KOCBJJ


    --reassigning user
    pre_auth_pkg.reassign_user (  NULL , v_claim_seq_id ,NULL , v_added_by , 'AUT');

    --Checking Claim completed or Not
    pre_auth_pkg.check_clm_completed ( v_claim_seq_id , NULL ,'REC' ,v_added_by);

    IF rec_claim.hosp_seq_id IS NOT NULL AND rec_claim.date_of_admission IS NOT NULL THEN
       get_account_limits( rec_claim.hosp_seq_id, rec_claim.policy_seq_id, rec_claim.product_seq_id, rec_claim.date_of_admission, v_ward_type_id, v_room_type_id, v_ward_max_amt, v_ward_disc_perc);
    END IF;


    claims_pkg.service_tax_validation(v_claim_seq_id,v_ward_type_id,v_clm_bill_dtl_seq_id);

    IF v_clm_bill_dtl_seq_id = 0 THEN

      INSERT INTO clm_bill_details(clm_bill_dtl_seq_id,clm_bill_seq_id,description,ward_type_id,
                                   room_type_id,number_of_days,requested_amount,allow_yn,allowed_amount,
                                   rejected_amount,remarks,ward_max_amount,discount_percnt,added_by,added_date,no_of_visits,
                                   vaccination_type_id,Child_Immnunization,rout_adult_phys_exam,well_child_test_type)  --KOC1164)  --KOC1164
      VALUES( clm_bill_dtl_seq.NEXTVAL, v_clm_bill_seq_id, v_description, v_ward_type_id, v_room_type_id,
             v_number_of_days, v_requested_amount , NVL(v_allow_yn,'N'), v_allowed_amount , (v_requested_amount - NVL(v_allowed_amount,0)), CASE WHEN v_ward_type_id='STX' THEN 'AUTOMATICALLY CALCULATED BY THE SYSTEM' ELSE v_remarks END, v_ward_max_amt * NVL( v_number_of_days, 1 ) , v_ward_disc_perc,v_added_by,SYSDATE,
              NVL(v_no_of_visits,''), --Added for koc1320
              v_vaccination_type_id,v_Child_Immnunization,v_rout_adult_phys_exam,v_well_child_test_type) --KOC1164) --KOC1164
             RETURNING clm_bill_dtl_seq_id INTO v_clm_bill_dtl_seq_id;
    ELSE


      UPDATE clm_bill_details
        SET clm_bill_seq_id  = v_clm_bill_seq_id,
            description      = v_description,
            ward_type_id     = v_ward_type_id,
            room_type_id     = v_room_type_id,
             number_of_days   = v_number_of_days,
            requested_amount = v_requested_amount,
            allow_yn         = NVL(v_allow_yn,'N'),
            allowed_amount   = v_allowed_amount,
            rejected_amount  = ( v_requested_amount - NVL(v_allowed_amount,0)),
            remarks          = CASE WHEN v_ward_type_id='STX' THEN 'AUTOMATICALLY CALCULATED BY THE SYSTEM' ELSE v_remarks END,
            ward_max_amount  = v_ward_max_amt * NVL(v_number_of_days,1) ,
            discount_percnt  = v_ward_disc_perc,
            updated_by       = v_added_by,
            updated_date     = SYSDATE,
			no_of_visits     = NVL(v_no_of_visits,''), --Added for koc1320
            vaccination_type_id = v_vaccination_type_id,  --KOC1164
            Child_Immnunization  = v_Child_Immnunization,   --KOC1315
            rout_adult_phys_exam = v_rout_adult_phys_exam ,  --KOC1308
            well_child_test_type =v_well_child_test_type     --KOC1316
            WHERE clm_bill_dtl_seq_id = v_clm_bill_dtl_seq_id;
         UPDATE clm_general_details cg
           SET -- KOC1164 copay with age
                 cg.copay_rest_amt = null ,
               cg.co_payment_amount = 0,
         updated_by       = v_added_by,
               updated_date     = SYSDATE
         WHERE cg.claim_seq_id = v_claim_seq_id;

   END IF;
   PRE_AUTH_PKG.set_validation_status('C', v_claim_seq_id ,'U', v_added_by );
   claims_freeze(v_claim_seq_id,NULL,'S'); --KOCBJJ
   v_rows_processed := SQL%ROWCOUNT;
   COMMIT;
  END save_clm_bill_details;
--==============================================================================================
 --   Name       : claims_bill_details_list
 --   Created on : -11-JUL-06
 --   Created By : - S.V.SREERAJ
 --   Comments   :
 --==============================================================================================
  PROCEDURE claims_bill_details_list (
      v_clm_bill_seq_id IN clm_bill_details.clm_bill_seq_id%TYPE,
      v_sort_var        IN VARCHAR2,
      v_sort_order      IN VARCHAR2 ,
      v_start_num       IN NUMBER ,
      v_end_num         IN NUMBER ,
      v_added_by        IN NUMBER,
      result_set        OUT SYS_REFCURSOR
  )
  IS
    v_sql_str           VARCHAR2(4000);
  BEGIN
    v_sql_str :=   'SELECT A.clm_bill_dtl_seq_id,A.description,A.ward_type_id||''#''|| TO_CHAR(capture_number_of_days_yn) AS ward_type_id , b.ward_description,
                         A.requested_amount , A.Allowed_Amount, A.room_type_id, A.number_of_days ,
                         A.allow_yn , A.rejected_amount , A.remarks,
						 A.no_of_visits,e.claim_sub_general_type_id --Added for koc1320
                    FROM clm_bill_details A JOIN tpa_hosp_ward_code b ON (a.ward_type_id = b.ward_type_id )
					INNER JOIN clm_bill_header d ON (a.clm_bill_seq_id = d.clm_bill_seq_id)--Added for koc1320
                    INNER JOIN clm_general_details e ON (d.claim_seq_id = e.claim_seq_id)--Added for koc1320
                    WHERE A.clm_bill_seq_id = :v_clm_bill_seq_id ';
    v_sql_str := 'SELECT * FROM
          (SELECT A.*, DENSE_RANK() OVER (ORDER BY '||v_sort_var||' '||v_sort_order||',ROWNUM)
          Q FROM (' ||v_sql_str|| ') A ) WHERE Q>= :v_start_num  AND Q<= :v_end_num ';

    OPEN result_set FOR v_sql_str USING v_clm_bill_seq_id , v_start_num , v_end_num;
  END claims_bill_details_list;
--==============================================================================================
 --   Name       : claims_bill_header_list
 --   Created on : -11-JUL-06
 --   Created By : - S.V.SREERAJ
 --   Comments   :
 --==============================================================================================
  PROCEDURE claims_bill_header_list (
      v_claim_seq_id    IN clm_bill_header.claim_seq_id%TYPE,
      v_bill_no         IN clm_bill_header.bill_no%TYPE,
      v_bill_amount     IN clm_bill_details.requested_amount%TYPE,
      v_bill_date       IN VARCHAR2,
      v_sort_var        IN VARCHAR2,
      v_sort_order      IN VARCHAR2 ,
      v_start_num       IN NUMBER ,
      v_end_num         IN NUMBER ,
      v_added_by        IN NUMBER,
      result_set        OUT SYS_REFCURSOR
  )
  IS
    v_bill_dt               DATE := to_date (v_bill_date,'dd/mm/yyyy');
    v_sql_str               VARCHAR2(4000);
--    v_ctr                   NUMBER(2);
    TYPE bind_tab_type IS TABLE OF VARCHAR2(250) INDEX BY BINARY_INTEGER ;
    bind_tab                bind_tab_type;
    i                       NUMBER(2) := 0;

  BEGIN

    v_sql_str := ' SELECT A.clm_bill_seq_id, A.bill_no,A.bill_date,SUM(B.requested_amount) AS bill_amount, SUM(B.allowed_amount ) AS allowed_amount ,
                     CASE WHEN TRUNC(A.bill_date) < TRUNC(C.date_of_admission) THEN ''Pre-Hospitalization''
                          WHEN TRUNC(A.bill_date) > TRUNC(C.date_of_discharge) THEN ''Post-Hospitalization'' ELSE ''Hospitalization'' END AS bill_type ,
                     CASE WHEN C.parent_claim_seq_id IS NULL THEN ''N'' ELSE ''Y'' END AS ammendment_yn ,
                     CASE WHEN a.bill_date >= NVL(D.date_of_inception, a.bill_date ) AND a.bill_date <= NVL( d.date_of_exit,a.bill_date )
                          THEN ''Y'' ELSE ''N'' END valid_yn ,
                          DECODE(A.bill_included_yn,''Y'',''Yes'',''No'') as bill_included_yn
                       FROM clm_bill_header A LEFT OUTER JOIN clm_bill_details B ON A.clm_bill_seq_id = B.clm_bill_seq_id
                         INNER JOIN clm_general_details C ON A.claim_seq_id = C.claim_seq_id
                         INNER JOIN clm_enroll_details D ON ( a.claim_seq_id = d.claim_seq_id )
                          WHERE C.claim_seq_id = :v_claim_seq_id ';

     IF v_bill_no IS NOT NULL THEN
       v_sql_str := v_sql_str ||' AND A.bill_no LIKE  :v_bill_no';
       i := i+1;
       bind_tab(i) := v_bill_no||'%';
     END IF;
     IF v_bill_dt IS NOT NULL THEN
       v_sql_str := v_sql_str ||' AND TRUNC( A.bill_date ) = :v_bill_dt ';
       i := i+1;
       bind_tab(i) := v_bill_dt;
     END IF;

     v_sql_str := v_sql_str ||' GROUP BY A.clm_bill_seq_id, A.bill_no, A.bill_date,
                      CASE WHEN TRUNC(A.bill_date) < TRUNC(C.date_of_admission) THEN ''Pre-Hospitalization''
                           WHEN TRUNC(A.bill_date) > TRUNC(C.date_of_discharge) THEN ''Post-Hospitalization'' ELSE ''Hospitalization'' END ,
                      CASE WHEN C.parent_claim_seq_id IS NULL THEN ''N'' ELSE ''Y'' END ,
                      CASE WHEN a.bill_date >= NVL(D.date_of_inception, a.bill_date ) AND a.bill_date <= NVL( d.date_of_exit, a.bill_date )
                          THEN ''Y'' ELSE ''N'' END , DECODE(A.bill_included_yn,''Y'',''Yes'',''No'')' ;
    IF v_bill_amount IS NOT NULL THEN
      v_sql_str := v_sql_str ||' HAVING SUM(B.allowed_amount) = :v_bill_amount ';
      i := i+1;
      bind_tab(i) := v_bill_amount;
    END IF;

    v_sql_str := 'SELECT * FROM
            (SELECT A.*, DENSE_RANK() OVER (ORDER BY '||v_sort_var||' '||v_sort_order||',ROWNUM )
            Q FROM (' ||v_sql_str|| ') A ) WHERE Q>= :v_start_num  AND Q<= :v_end_num ';

    IF bind_tab.FIRST IS NOT NULL THEN
       CASE bind_tab.COUNT
         WHEN 1 THEN OPEN result_set FOR v_sql_str USING v_claim_seq_id, bind_tab(1) , v_start_num , v_end_num ;
         WHEN 2 THEN OPEN result_set FOR v_sql_str USING v_claim_seq_id, bind_tab(1),bind_tab(2), v_start_num , v_end_num ;
         WHEN 3 THEN OPEN result_set FOR v_sql_str USING v_claim_seq_id, bind_tab(1),bind_tab(2),bind_tab(3), v_start_num , v_end_num ;
       END CASE;
    ELSE
      OPEN result_set FOR  v_sql_str  USING v_claim_seq_id, v_start_num , v_end_num ;
    END IF;
  END claims_bill_header_list;
--=================================================================================================================
  PROCEDURE select_hosp_additional_dtl (
    v_clm_hosp_assoc_seq_id                IN CLM_HOSPITAL_ADDITIONAL_DTL.clm_hosp_assoc_seq_id%TYPE,
    v_added_by                             IN NUMBER,
    v_result_set                           OUT SYS_REFCURSOR
  )
  IS
  BEGIN
    OPEN v_result_set FOR
     SELECT
      A.add_hosp_dtl_seq_id ,
      A.clm_hosp_assoc_seq_id ,
      A.hosp_regist_number ,
      A.contact_name ,
      A.off_phone_no_1 ,
      A.number_of_beds ,
      A.fully_equipped_yn
     FROM clm_hospital_additional_dtl A  WHERE clm_hosp_assoc_seq_id = v_clm_hosp_assoc_seq_id;
  END select_hosp_additional_dtl;
-- =================================================================================================================
  PROCEDURE select_medical_details (
    v_claim_seq_id                        IN  AILMENT_DETAILS.claim_seq_id%TYPE,  -- pat_general_detail_seq_id or Claim_seq_id
    v_added_by                            IN  NUMBER,
    v_show_ailment                        OUT CHAR,
    v_ailment_cur                         OUT SYS_REFCURSOR,
    v_hosp_cur                            OUT SYS_REFCURSOR,
    v_icd_pcs_cur                         OUT SYS_REFCURSOR,
    v_coding_review_yn                    OUT CHAR,
    v_show_diagnosis                      OUT CHAR,--koc1273
    v_certificate                         OUT CHAR--koc1273
  )
  IS
    v_show_flag                          CHAR(1);
    v_assoc_illness                      VARCHAR2(1000);
    v_counter                            INTEGER;
    v_claim_sub_general_type_id          clm_general_details.claim_sub_general_type_id%TYPE;

    CURSOR clm_cur IS SELECT a.claim_sub_general_type_id ,
      CASE WHEN b.event_owner = 'C' THEN 'Y' ELSE 'N' END    -- changed from C to D to allow for coding also for --koc1356 phase 1.
       FROM clm_general_details a JOIN tpa_event b ON (a.event_seq_id = b.event_seq_id)
       WHERE claim_seq_id = v_claim_seq_id;

  BEGIN
    v_counter := 0;

    OPEN clm_cur;
    FETCH clm_cur INTO v_claim_sub_general_type_id , v_coding_review_yn ;
    CLOSE clm_cur;

    IF v_claim_sub_general_type_id != 'HCU' THEN  -- ie. Not Health Check Up
      v_show_ailment := 'Y';
      FOR i IN (SELECT B.description
                  FROM associated_illness A JOIN tpa_general_code B ON (a.assoc_ill_general_type_id = b.general_type_id)
                 WHERE a.claim_seq_id =  v_claim_seq_id AND A.assoc_ill_duration  > 0 )
      LOOP
          IF ( v_counter = 0 ) THEN
             v_assoc_illness := i.description;
             v_counter := v_counter + 1;
          ELSE
             v_assoc_illness := v_assoc_illness ||', '||i.description;
          END IF;
      END LOOP;

      OPEN v_ailment_cur FOR
       SELECT  /*+ optimizer_features_enable('11.2.0.1') */
        A.ailment_details_seq_id,
        A.claim_seq_id,
        A.ailment_description,
        A.specialty_general_type_id ,
        E.description AS speciality,
        A.duration_of_hospitalization ,
        A.ailment_duration ,
        A.pat_duration_general_type_id ,
        B.description AS duration_description,
        A.provisional_diagnosis ,
        A.trtmnt_plan_general_type_id ,
        C.description AS treatment ,
        A.line_of_treatment ,
        A.investigation_reports ,
        A.history ,
        A.family_history ,
        A.date_of_surgery ,
        A.discharge_cond_general_type_id ,
        D.description AS condition ,
        A.advice_to_patient ,
        v_show_flag AS v_show_flag,
        v_assoc_illness AS associated_illness,
        a.doctor_opinion,
        g.contact_name AS doctor_name,
        F.description AS disability_type,
        h.description AS medicine_type_descr,
        i.description AS ailment_claim_type_descr,
        a.surgery_general_type_id,--Added on 21-Sep-2010 for KOC1017
        j.description, --Added on 21-Sep-2010 for KOC1017
        K.description maternity_description,--Added on 28-Jun-2011 for KOC1062A
        a.children_during_mat,--Added on 28-Jun-2011 for KOC1062A
		nvl(a.cancer_wit_ayurveda_yn,'N') as cancer_wit_ayurveda_yn,--koc1310
   --========Added for koc1075==================
        CASE WHEN l.ailment_general_type_id = 'PED' AND (b.description||'/'||LPAD(l.duration_years,4,0))!='/' THEN
              'Please do Coding for PED'
              ELSE NULL END AS ped_msg,
                l.ailment_general_type_id,
        a.Diagnosis_Dt,--koc1273
        a.date_of_certificate as certificate_date,--koc1273
        a.physio_chargeable_yn, --Added for koc1320
        a.physio_applicable_id, --Added for koc1320
        a.number_of_visits, --Added for koc1320
        m.claim_sub_general_type_id, --Added for koc1320
        case when en.mem_age >= 60
          then 'Y' else 'N' end as senior_citizen_yn -- koc_griavance

        FROM ailment_details A LEFT OUTER JOIN tpa_general_code B ON (A.pat_duration_general_type_id = B.general_type_id )
        JOIN clm_general_details ge ON (ge.claim_seq_id = a.claim_seq_id)  -- koc_griavance
        JOIN clm_enroll_details en ON  (en.claim_seq_id = a.claim_seq_id)  -- koc_griavance
        LEFT OUTER JOIN tpa_general_code C ON ( A.trtmnt_plan_general_type_id = C.general_type_id  )
        LEFT OUTER JOIN tpa_general_code D ON ( A.discharge_cond_general_type_id  = D.general_type_id  )
        LEFT OUTER JOIN tpa_general_code E ON ( A.specialty_general_type_id  = E.general_type_id  )
        LEFT OUTER JOIN tpa_general_code F ON ( A.disability_general_type_id  = F.general_type_id  )
        LEFT OUTER JOIN tpa_user_contacts g ON (a.doctor_opinion_by = g.contact_seq_id)
        LEFT OUTER JOIN tpa_general_code h ON (a.medicine_general_type_id = h.general_type_id)
        LEFT OUTER JOIN tpa_general_code i ON (a.ailment_clm_general_type_id = i.general_type_id)
        LEFT OUTER JOIN tpa_general_code j ON (a.surgery_general_type_id=j.general_type_id AND j.header_type='SURGERY_TYPE')--Added on 21-Sep-2010 for KOC-1017
        LEFT OUTER JOIN tpa_general_code k ON (a.mat_general_type_id=k.general_type_id)--Added on 28-Jun-2011 for KOC1062A
        LEFT OUTER JOIN tpa_enr_mem_ped L ON (L.Enr_Duration_General_Type_Id = b.general_type_id) --Added for koc1075
		LEFT OUTER JOIN CLM_GENERAL_DETAILS M ON (A.CLAIM_SEQ_ID = m.CLAIM_SEQ_ID) --Added for koc1320
        WHERE a.claim_seq_id = v_claim_seq_id ;
    ELSE
      v_show_ailment := 'N';
      OPEN v_ailment_cur FOR SELECT NULL FROM dual WHERE 1=2;
    END IF;

    OPEN v_hosp_cur FOR
     SELECT
      A.add_hosp_dtl_seq_id ,
      A.clm_hosp_assoc_seq_id ,
      A.hosp_regist_number ,
      A.contact_name ,
      A.off_phone_no_1 ,
      A.number_of_beds ,
      DECODE(A.fully_equipped_yn,'Y','Yes','No') AS fully_equipped_yn ,
      CASE WHEN c.prev_hosp_claim_seq_id IS NOT NULL THEN 'N' ELSE 'Y' END AS edit_yn -- patchtogo
       FROM clm_general_details c
       JOIN clm_hospital_association B on (b.claim_seq_id=c.claim_seq_id)
       left outer join clm_hospital_additional_dtl A  ON (A.clm_hosp_assoc_seq_id = B.clm_hosp_assoc_seq_id )
      WHERE B.claim_seq_id = v_claim_seq_id ;

    OPEN v_icd_pcs_cur FOR
       SELECT
        A.icd_pcs_seq_id ,
        A.ped_code_id ,
        NVL(F.ped_description,'Others - '||A.other_desc) AS ailment_desc ,
        A.trtmnt_plan_general_type_id  ,
        C.Description AS treatment_desc ,
        A.icd_code ,
        A.primary_ailment_yn ,
        DECODE( B.pkg_seq_id , NULL, NULL, D.name||'(Pkg)' ) description ,
        b.pat_proc_seq_id,
        b.pkg_seq_id ,
        E.proc_code,
       case --koc decoupling
         when a.primary_ailment_yn = 'Y' then 'PRIMARY AILMENT' 
           else case when a.secondary_ailment_yn = 'Y' then 'SECONDARY AILMENT' 
             else case when a.comorb_ailment_yn = 'Y' then 'CO-MORBIDITITES'
               else '' end end end as diag_type --koc decoupling
        FROM icd_pcs_detail A LEFT OUTER JOIN pat_package_procedures B ON (A.icd_pcs_seq_id = B.icd_pcs_seq_id)
        LEFT OUTER JOIN tpa_general_code C ON (A.trtmnt_plan_general_type_id = C.general_type_id)
        LEFT OUTER JOIN tpa_hosp_tariff_item D ON (B.pkg_seq_id = D.pkg_seq_id)
        LEFT OUTER JOIN tpa_hosp_procedure_code E ON (b.proc_seq_id = e.proc_seq_id)
        LEFT OUTER JOIN tpa_ped_code F ON (A.ped_code_id = F.ped_code_id)
        WHERE A.claim_seq_id = v_claim_seq_id  ORDER BY A.icd_pcs_seq_id;


--koc1273
for rec in (select case when gen.claim_sub_general_type_id='CTL' then 'Y' else 'N' end as show_diagnosis,
  gen.claim_sub_general_type_id,p.enrol_type_id,nvl(p.survival_prd,'N') survival_policy,
  nvl(ip.survival_prd,'N') survival_product
from clm_general_details gen
join clm_enroll_details en on ( en.claim_seq_id = gen.claim_seq_id )
LEFT OUTER join tpa_enr_policy P ON (p.policy_seq_id=en.Policy_Seq_Id)
LEFT OUTER join tpa_ins_product IP ON (IP.product_seq_id=P.Product_Seq_Id)
where gen.claim_seq_id = v_claim_seq_id)  loop
  v_show_diagnosis := rec.show_diagnosis;

if rec.claim_sub_general_type_id = 'CTL' and rec.enrol_type_id = 'COR' then
 v_certificate := rec.survival_policy;
 elsif rec.claim_sub_general_type_id = 'CTL' and rec.enrol_type_id <> 'COR' then
 v_certificate := rec.survival_product;
 else
   v_certificate := 'N';
end if;

  end loop;
--koc1273


  END select_medical_details;
-- =================================================================================================================
  PROCEDURE claims_support_doc_list (
    v_claim_seq_id                       IN  NUMBER,
    v_sort_var                           IN  VARCHAR2,
    v_sort_order                         IN  VARCHAR2,
    v_start_num                          IN  NUMBER  ,
    v_end_num                            IN  NUMBER ,
    v_added_by                           IN  NUMBER,
    result_set                           OUT SYS_REFCURSOR
  )
  IS
    v_sql_str                            VARCHAR2(4000);
  BEGIN
     v_sql_str :=
      'SELECT
        A.disch_vouch_seq_id AS seq_id,
        A.dv_id ID,
        B.description AS status,
        A.dv_sent_date AS sent_date,
        A.dv_received_date  AS rcvd_date,
        ''Y'' AS edit_yn
        FROM clm_discharge_voucher A LEFT OUTER JOIN tpa_general_code B ON (a.dv_status_general_type_id  = b.general_type_id)
        WHERE A.claim_seq_id  = :v_claim_seq_id ';

    v_sql_str := 'SELECT * FROM
        (SELECT A.*,DENSE_RANK() OVER (ORDER BY '||v_sort_var||' '||v_sort_order||',ROWNUM)
        Q FROM (' ||v_sql_str|| ') A ) WHERE  Q>= :v_start_num AND Q<= :v_end_num ';

    OPEN result_set FOR v_sql_str USING v_claim_seq_id, v_start_num, v_end_num;
  END claims_support_doc_list;
 --==============================================================================================
 --   Name       : save_DISCHARGE_VOUCHER
 --   Created on : -11-JUL-06
 --   Created By : - S.V.SREERAJ
 --   Comments   :
 --==============================================================================================
--claims
----------------
--DVS  Sent
--DVR  Received
--DVT  Optional

--product
--------------
--DRQ  Required
--DVN   Not Required
--DVO   Optional

  PROCEDURE save_discharge_voucher(
    v_disch_vouch_seq_id                 IN  OUT CLM_DISCHARGE_VOUCHER.disch_vouch_seq_id%TYPE,
    v_claim_seq_id                       IN  CLM_DISCHARGE_VOUCHER.claim_seq_id%TYPE,
    v_dv_sent_date                       IN  CLM_DISCHARGE_VOUCHER.dv_sent_date%TYPE,
    v_dv_received_date                   IN  CLM_DISCHARGE_VOUCHER.dv_received_date%TYPE ,
    v_dv_status_general_type_id          IN  CLM_DISCHARGE_VOUCHER.dv_status_general_type_id%TYPE,
    v_remarks                            IN  CLM_DISCHARGE_VOUCHER.remarks%TYPE,
    v_added_by                           IN  CLM_DISCHARGE_VOUCHER.added_by%TYPE,
    v_rows_processed                     IN  OUT NUMBER
  )
  IS
--    v_ctr                                NUMBER(1);

    CURSOR clm_cur IS SELECT a.completed_yn , b.clm_status_general_type_id , c.claim_general_type_id ,
       b.policy_seq_id , h.claim_payment_status , j.dv_status_general_type_id , j.dv_sent_date,
      CASE WHEN b.enrol_type_id = 'COR' THEN f.dv_reqd_general_type_id ELSE g.dv_reqd_general_type_id END AS dv_reqd_general_type_id
      FROM clm_general_details a JOIN clm_enroll_details b ON ( a.claim_seq_id = b.claim_seq_id )
      JOIN clm_inward c ON (a.claims_inward_seq_id = c.claims_inward_seq_id)
      LEFT OUTER JOIN tpa_enr_policy e ON (b.policy_seq_id = e.policy_seq_id)
      LEFT OUTER JOIN tpa_ins_prod_policy f ON (b.policy_seq_id = f.policy_seq_id)
      LEFT OUTER JOIN tpa_ins_prod_policy g ON (e.product_seq_id = g.product_seq_id)
      LEFT OUTER JOIN tpa_claims_payment h ON (a.claim_seq_id = h.claim_seq_id)
      LEFT OUTER JOIN clm_discharge_voucher j ON (a.claim_seq_id = j.claim_seq_id)
      WHERE a.claim_seq_id = v_claim_seq_id;

    clm_rec                       clm_cur%ROWTYPE;

  BEGIN
    OPEN clm_cur;
    FETCH clm_cur INTO clm_rec;
    CLOSE clm_cur;

    claims_freeze(v_claim_seq_id,NULL,'S'); --KOCBJJ

    IF clm_rec.dv_reqd_general_type_id = 'DVN' AND v_dv_status_general_type_id != 'DVR' THEN
      RAISE_APPLICATION_ERROR(-20193,'Discharge voucher not allowed.');
    END IF;

    IF clm_rec.dv_status_general_type_id = v_dv_status_general_type_id AND clm_rec.claim_payment_status NOT IN ('PENDING','VOUCHER PENDING') THEN
      RAISE_APPLICATION_ERROR(-20195,'Modification not allowed, Claim processing started in Finance.');
    END IF;

    IF v_disch_vouch_seq_id = 0 THEN
      IF clm_rec.dv_reqd_general_type_id = 'DVO' AND v_dv_status_general_type_id != 'DVT'  THEN -- product/policy level
        IF clm_rec.claim_payment_status = 'PENDING' THEN
          UPDATE tpa_claims_payment a SET
            a.claim_payment_status = 'VOUCHER PENDING',
            a.updated_by           = v_added_by,
            a.added_date           = SYSDATE
            WHERE a.claim_seq_id   = v_claim_seq_id AND a.claim_payment_status = 'PENDING';
            IF SQL%ROWCOUNT = 0 THEN
              RAISE_APPLICATION_ERROR(-20194,'Discharge voucher not allowed , Claim processing started in Finance.');
            END IF;
        ELSE
          RAISE_APPLICATION_ERROR(-20194,'Discharge voucher not allowed , Claim processing started in Finance.');
        END IF;
      END IF;
      IF v_dv_status_general_type_id IN ( 'DVR' ) THEN
        raise_application_error(-20707,' Please send the DV before changing the status to received.');
      END IF;
    END IF;

    IF v_disch_vouch_seq_id = 0  THEN
      INSERT INTO clm_discharge_voucher(
        disch_vouch_seq_id,
        claim_seq_id,
        dv_id,
        dv_sent_date,
        dv_status_general_type_id,
        dv_received_date,
        remarks,
        added_by,
        added_date)
      VALUES (
        clm_discharge_voucher_seq.NEXTVAL ,
        v_claim_seq_id,
        voucher_id_seq.NEXTVAL ,
        v_dv_sent_date,
        v_dv_status_general_type_id,
        v_dv_received_date,
        v_remarks,
        v_added_by,
        SYSDATE ) RETURNING disch_vouch_seq_id INTO v_disch_vouch_seq_id;
    ELSE
      IF v_dv_status_general_type_id = 'DVR' THEN
        IF clm_rec.dv_sent_date IS NOT NULL THEN
          UPDATE tpa_claims_payment a SET
            a.claim_payment_status = 'PENDING',
            a.updated_date         = SYSDATE,
            a.updated_by           = v_added_by
            WHERE a.claim_seq_id   = v_claim_seq_id AND a.claim_payment_status IN ('VOUCHER PENDING');
        ELSE
          raise_application_error(-20707,' Please send the DV before changing the status to received.');
        END IF;
      ELSIF v_dv_status_general_type_id = 'DVT' THEN
        IF clm_rec.dv_status_general_type_id = 'DVS' THEN
          UPDATE tpa_claims_payment a SET
            a.claim_payment_status = 'PENDING',
            a.updated_by           = v_added_by,
            a.added_date           = SYSDATE
            WHERE a.claim_seq_id   = v_claim_seq_id AND a.claim_payment_status = 'VOUCHER PENDING';
        END IF;
      END IF;


      IF v_dv_status_general_type_id = 'DVS' THEN
        IF clm_rec.claim_payment_status NOT IN ('PENDING','VOUCHER PENDING') THEN
          raise_application_error(-20195,'You Cannot change the status, Claim already processed in finance ');
        ELSIF clm_rec.claim_payment_status = 'PENDING' THEN
          UPDATE tpa_claims_payment a SET
            a.claim_payment_status = 'VOUCHER PENDING',
            a.updated_by           = v_added_by,
            a.added_date           = SYSDATE
            WHERE a.claim_seq_id   = v_claim_seq_id AND a.claim_payment_status = 'PENDING';
            IF SQL%ROWCOUNT = 0 THEN
              raise_application_error(-20195,'You Cannot change the status, Claim already processed in finance ');
            END IF;
        END IF;
      END IF;

      UPDATE clm_discharge_voucher SET
        dv_sent_date                            = v_dv_sent_date,
        dv_status_general_type_id               = v_dv_status_general_type_id,
        dv_received_date                        = v_dv_received_date,
        remarks                                 = v_remarks,
        updated_by                              = v_added_by,
        updated_date                            = SYSDATE
        WHERE disch_vouch_seq_id                = v_disch_vouch_seq_id;
    END IF;
    v_rows_processed := SQL%ROWCOUNT;
    COMMIT;
  END save_discharge_voucher;
-- =================================================================================================================
  PROCEDURE select_discharge_voucher (
    v_disch_vouch_seq_id                 IN  CLM_DISCHARGE_VOUCHER.disch_vouch_seq_id%TYPE,
    v_added_by                           IN  CLM_DISCHARGE_VOUCHER.added_by%TYPE,
    v_result_set                         OUT SYS_REFCURSOR
  )
  IS
  BEGIN
    OPEN v_result_set FOR
     SELECT
     A.disch_vouch_seq_id,
     A.dv_id ,
     A.dv_sent_date  ,
     A.dv_received_date ,
     A.dv_status_general_type_id ,
     A.remarks
     FROM clm_discharge_voucher A WHERE disch_vouch_seq_id = v_disch_vouch_seq_id;
  END select_discharge_voucher;
-- =================================================================================================================
  PROCEDURE select_srtfll_missing_docs (
    v_claim_seq_id                      IN  NUMBER,
    v_doc_xml                           OUT XMLTYPE ,
    v_added_by                          IN  NUMBER
  )
  IS
    CURSOR doc_cur IS
     SELECT
      A.docu_list_type_id ,
      A.docu_name
      FROM clm_document_list_code A LEFT OUTER JOIN clm_documents_rcvd B ON (a.docu_list_type_id = b.docu_list_type_id AND b.claim_seq_id = v_claim_seq_id )
      WHERE b.docu_rcvd_seq_id IS NULL /*AND a.document_general_type_id = 'DTS' */
      ORDER BY a.docu_categ_general_type_id , a.sort_no;

      v_srtfll_doc         DBMS_XMLDOM.DOMDocument;
      v_srtfll_root_node   DBMS_XMLDOM.DOMNode;
      v_elem               DBMS_XMLDOM.DOMElement;
      v_node               DBMS_XMLDOM.DOMNode;
      v_parent_node        DBMS_XMLDOM.DOMNODE;

      v_ctr                NUMBER(3);
    BEGIN
      v_srtfll_doc := dbms_xmldom.newDOMDocument;
      dbms_xmldom.setVersion( v_srtfll_doc, '1.0' );
      v_srtfll_root_node := dbms_xmldom.makeNode(v_srtfll_doc);

      v_elem := dbms_xmldom.createElement( v_srtfll_doc, 'shortfall' );
      v_node := dbms_xmldom.makeNode( v_elem );
      v_srtfll_root_node := dbms_xmldom.appendChild( v_srtfll_root_node, v_node );

      v_elem := dbms_xmldom.createElement(v_srtfll_doc, 'section');
      dbms_xmldom.setAttribute(v_elem,'name','Missing Documents');
      v_node := dbms_xmldom.makeNode(v_elem);
      v_parent_node := dbms_xmldom.appendChild( v_srtfll_root_node, v_node);

      v_elem := dbms_xmldom.createElement(v_srtfll_doc, 'subsection');
      dbms_xmldom.setAttribute(v_elem,'name','Missing Documents');
      v_node := dbms_xmldom.makeNode(v_elem);
      v_parent_node := dbms_xmldom.appendChild( v_parent_node, v_node);

     v_ctr := 1;
     FOR i IN doc_cur
     LOOP
      v_elem := dbms_xmldom.createElement(v_srtfll_doc, 'query');
      dbms_xmldom.setAttribute(v_elem,'id','Missing Documents.'||v_ctr);
      dbms_xmldom.setAttribute(v_elem,'postlabel',i.docu_name);
      dbms_xmldom.setAttribute(v_elem,'control','input');
      dbms_xmldom.setAttribute(v_elem,'type','checkbox');
      dbms_xmldom.setAttribute(v_elem,'value','Yes');
      v_node := dbms_xmldom.makeNode(v_elem);
      v_node := dbms_xmldom.appendChild( v_parent_node, v_node);
      v_ctr := v_ctr +1;
--------
    END LOOP;

    v_elem := dbms_xmldom.createElement(v_srtfll_doc, 'section');
    dbms_xmldom.setAttribute(v_elem,'name','Others');
    v_node := dbms_xmldom.makeNode(v_elem);
    v_parent_node := dbms_xmldom.appendChild( v_srtfll_root_node, v_node);

    v_elem := dbms_xmldom.createElement(v_srtfll_doc, 'subsection');
    dbms_xmldom.setAttribute(v_elem,'name','Other Queries');
    v_node := dbms_xmldom.makeNode(v_elem);
    v_parent_node := dbms_xmldom.appendChild( v_parent_node, v_node);

    v_ctr := 1;

    v_elem := dbms_xmldom.createElement(v_srtfll_doc, 'query');
    dbms_xmldom.setAttribute(v_elem,'id','Others.'||v_ctr);
    dbms_xmldom.setAttribute(v_elem,'postlabel','');
    dbms_xmldom.setAttribute(v_elem,'control','textArea');
    dbms_xmldom.setAttribute(v_elem,'type','text');
    dbms_xmldom.setAttribute(v_elem,'value','Yes');
    v_node := dbms_xmldom.makeNode(v_elem);
    v_parent_node := dbms_xmldom.appendChild( v_parent_node, v_node);
    v_doc_xml := dbms_xmldom.getxmltype(v_srtfll_doc);

    dbms_xmldom.freeDocument(v_srtfll_doc);

  END select_srtfll_missing_docs;
-- =================================================================================================================
  PROCEDURE select_clm_inward_document(
    v_claim_type                      IN CLM_INWARD.claim_general_type_id%TYPE,
    v_result_set                      OUT SYS_REFCURSOR
  )
  IS
  BEGIN
    IF v_claim_type IS NOT NULL THEN
     OPEN v_result_set FOR
      SELECT  docu_list_type_id,  docu_name
       FROM clm_document_list_code a
       WHERE a.show_in_inward_entry_yn = 'Y'AND ( a.claim_type = v_claim_type OR a.claim_type = 'ALL');
    ELSE
     OPEN v_result_set FOR
      SELECT  docu_list_type_id,  docu_name
       FROM clm_document_list_code a
       WHERE a.show_in_inward_entry_yn = 'Y';
    END IF;
  END select_clm_inward_document;
-- =================================================================================================================
  PROCEDURE save_clm_document(
    v_docu_rcvd_seq_id             IN CLM_DOCUMENTS_RCVD.docu_rcvd_seq_id%TYPE,
    v_document_rcvd_yn             IN VARCHAR2,
    v_docu_list_type_id             IN CLM_DOCUMENTS_RCVD.docu_list_type_id%TYPE,
    v_sheets_count                  IN CLM_DOCUMENTS_RCVD.sheets_count%TYPE,
    v_doc_general_type_id          IN CLM_DOCUMENTS_RCVD.doc_general_type_id%TYPE,
    v_reason_general_type_id        IN CLM_DOCUMENTS_RCVD.reason_general_type_id%TYPE,
    v_claim_seq_id                  IN CLM_DOCUMENTS_RCVD.claim_seq_id%TYPE,
    v_claims_inward_seq_id         IN CLM_DOCUMENTS_RCVD.claims_inward_seq_id%TYPE,
    v_remarks                      IN CLM_DOCUMENTS_RCVD.remarks%TYPE,
    v_added_by                      IN CLM_DOCUMENTS_RCVD.added_by%TYPE
  )
  IS
      intCount NUMBER(1);
  BEGIN
    claims_freeze(v_claim_seq_id,NULL,'S'); --KOCBJJ

    IF v_docu_rcvd_seq_id = 0 THEN
      IF v_document_rcvd_yn = 'Y' THEN
        INSERT INTO clm_documents_rcvd (
          docu_rcvd_seq_id,
          claim_seq_id,
          docu_list_type_id,
          sheets_count,
          doc_general_type_id,
          reason_general_type_id,
          claims_inward_seq_id,
          remarks,
          added_by,
          added_date)
        VALUES (
          clm_documents_rcvd_seq.NEXTVAL ,
          v_claim_seq_id,
          v_docu_list_type_id,
          v_sheets_count,
          v_doc_general_type_id,
          v_reason_general_type_id,
          v_claims_inward_seq_id,
          v_remarks,
          v_added_by,
          SYSDATE );
      END IF;
    ELSE
      IF v_claim_seq_id IS NOT NULL THEN
        pre_auth_pkg.check_clm_completed(v_claim_seq_id ,NULL,'APR' ,v_added_by );
      END IF;

      SELECT COUNT(docu_rcvd_seq_id) INTO intCount
        FROM clm_documents_rcvd
         WHERE docu_rcvd_seq_id = v_docu_rcvd_seq_id;

      IF intCount>0 THEN
         IF v_document_rcvd_yn='Y' THEN
             UPDATE clm_documents_rcvd SET
             sheets_count                            = v_sheets_count,
            doc_general_type_id                     = v_doc_general_type_id,
             reason_general_type_id                  = v_reason_general_type_id,
             remarks                                 = v_remarks,
            updated_by                              = v_added_by,
            updated_date                            = SYSDATE
            WHERE docu_rcvd_seq_id = v_docu_rcvd_seq_id;
         ELSE
            DELETE FROM clm_documents_rcvd
              WHERE docu_rcvd_seq_id = v_docu_rcvd_seq_id;
         END IF;
      END IF;
    END IF;
   claims_freeze(v_claim_seq_id,NULL,'S'); --KOCBJJ

  END save_clm_document;
-- =================================================================================================================
  PROCEDURE select_clm_inward_dtl(
    v_claims_inward_seq_id           IN  CLM_INWARD.claims_inward_seq_id%TYPE,
    v_claim_type                     IN CLM_INWARD.claim_general_type_id%TYPE,
    v_added_by                       IN  CLM_INWARD.added_by%TYPE,
    v_claim_cur                      OUT SYS_REFCURSOR,
    v_document_cur                   OUT SYS_REFCURSOR
  )
  IS
  BEGIN
    OPEN v_claim_cur FOR
      SELECT  /*+ optimizer_features_enable('11.2.0.1') */
       A.claims_inward_seq_id,
       A.claims_inward_no,
       A.barcode_no,
       A.document_general_type_id,
       A.rcvd_date,
       A.source_general_type_id,
       A.courier_seq_id,
       A.claim_general_type_id,
       B.requested_amount,
       NVL(C.tpa_enrollment_id, j.Tpa_Enrollment_Id ) AS tpa_enrollment_id,
       NVL(C.claimant_name, j.claimant_name ) AS claimant_name,
       C.policy_number,
       A.inward_ins_seq_id,
       A.tpa_office_seq_id,
       F.office_name ,
       A.corporate_name,
       C.policy_holder_name,
       C.employee_no,
       C.employee_name,
       A.inward_status_general_type_id,
       A.remarks,
       g.claim_seq_id AS shortfall_claim_seq_id,
       A.claim_number,
       g.shortfall_seq_id ,
       A.shortfall_id ,
       B.claim_seq_id,
       c.clm_enroll_detail_seq_id,
       c.policy_seq_id ,
       C.member_seq_id ,
       D.Description AS doc_type,
       E.courier_id ,
       B.parent_claim_seq_id ,
       B.claim_number AS current_claim_number,
       ttk_util_pkg.fn_decrypt(c.email_id) as email_id,--//ED
       c.notification_phone_number,
       c.ins_scheme,
       c.certificate_no,
       c.ins_customer_code
      FROM clm_inward A LEFT OUTER JOIN clm_general_details B ON (A.claims_inward_seq_id = b.claims_inward_seq_id )
      LEFT OUTER JOIN clm_enroll_details C ON ( b.claim_seq_id = c.claim_seq_id )
      LEFT OUTER JOIN tpa_general_code D ON (A.document_general_type_id = D.general_type_id )
      LEFT OUTER JOIN courier_details E ON ( A.courier_seq_id = E.courier_seq_id )
      LEFT OUTER JOIN tpa_office_info F ON ( a.tpa_office_seq_id = F.tpa_office_seq_id )
      LEFT OUTER JOIN shortfall_details g ON ( a.shortfall_id = g.shortfall_id )
      LEFT OUTER JOIN clm_enroll_details j ON (g.claim_seq_id = j.claim_seq_id)
      WHERE A.claims_inward_seq_id = v_claims_inward_seq_id;

    IF v_claim_type IS NOT NULL THEN
      OPEN v_document_cur FOR
        SELECT  /*+ optimizer_features_enable('11.2.0.1') */
           b.docu_rcvd_seq_id ,
           a.docu_list_type_id ,
           b.sheets_count,
           b.doc_general_type_id ,
           b.reason_general_type_id,
           b.remarks,
           a.docu_name,
           DECODE(b.docu_rcvd_seq_id,NULL,'N','Y') AS document_rcvd_yn
           FROM clm_document_list_code A LEFT OUTER JOIN clm_documents_rcvd B ON ( a.docu_list_type_id = b.docu_list_type_id  AND b.claims_inward_seq_id = v_claims_inward_seq_id)
           WHERE a.show_in_inward_entry_yn = 'Y' AND ( a.claim_type = v_claim_type OR a.claim_type = 'ALL' ) ;
    ELSE
      OPEN v_document_cur FOR
        SELECT  /*+ optimizer_features_enable('11.2.0.1') */
           b.docu_rcvd_seq_id ,
           a.docu_list_type_id ,
           b.sheets_count,
           b.doc_general_type_id ,
           b.reason_general_type_id,
           b.remarks,
           a.docu_name,
           DECODE(b.docu_rcvd_seq_id,NULL,'N','Y') AS document_rcvd_yn
           FROM clm_document_list_code A LEFT OUTER JOIN clm_documents_rcvd B ON ( a.docu_list_type_id = b.docu_list_type_id  AND b.claims_inward_seq_id = v_claims_inward_seq_id)
           WHERE a.show_in_inward_entry_yn = 'Y' ;
    END IF;
  END select_clm_inward_dtl;

-- =================================================================================================================
  PROCEDURE select_preauth_list (
    v_tpa_enrollment_id              IN  pat_enroll_details.tpa_enrollment_id%TYPE,
    v_claimant_name                  IN  pat_enroll_details.claimant_name%TYPE,
    v_auth_number                    IN  pat_enroll_details.auth_number%TYPE,
    v_hosp_name                      IN  tpa_hosp_info.hosp_name%TYPE,
    v_pat_general_type_id            IN  pat_general_details.pat_general_type_id%TYPE,
    v_start_date                     IN  VARCHAR2,
    v_end_date                       IN  VARCHAR2,
    v_tpa_office_seq_id              IN  tpa_office_info.tpa_office_seq_id%TYPE,
    v_sort_var                       IN  VARCHAR2 ,
    v_sort_order                     IN  VARCHAR2,
    v_start_num                      IN  NUMBER,
    v_end_num                        IN  NUMBER,
    v_added_by                       IN  NUMBER,
    result_set                       OUT SYS_REFCURSOR,
    v_claim_seq_id                   IN NUMBER := NULL
  )
  IS
    TYPE bind_tab_type IS TABLE OF VARCHAR2(250) INDEX BY BINARY_INTEGER ;
    bind_tab                         bind_tab_type;
    i                                NUMBER(2) := 0;
    v_sql_str                        VARCHAR2(4000);
    v_where                          VARCHAR2(2000);
    v_from_date                      DATE := to_date(v_start_date,'dd/mm/yyyy');
    v_to_date                        DATE := to_date(v_end_date,'dd/mm/yyyy');
  BEGIN

    v_sql_str :=
       'SELECT
        A.pat_enroll_detail_seq_id,
        null member_seq_id ,
        null tpa_enrollment_id ,
        null policy_number ,
        null ins_seq_id ,
        null policy_seq_id ,
        null gender_general_type_id ,
        A.claimant_name ,
        null mem_age ,
        null date_of_inception ,
        null date_of_exit ,
        null mem_total_sum_insured ,
        null category_general_type_id ,
        null insured_name ,
        null phone_1,
        A.auth_number,
        null policy_sub_general_type_id,
        A.date_of_hospitalization ,
        C.pat_gen_detail_seq_id,
        null pat_registration_number,
        null pat_enhanced_yn,
        null likely_date_of_hospitalization,
        null treating_dr_name,
        null pat_rcvd_thru_general_type_id,
        null phone_no_in_hospitalisation,
        null as ava_sum_insured  ,
        null as ava_cum_bonus ,
        null as buffer_ava_amount ,
        null relship_type_id,
        B.hosp_seq_id,
        B.hosp_name ,
        i.address_1,
        i.address_2,
        i.address_3,
        J.state_name,
        K.city_description,
        i.pin_code,
        h.off_phone_no_1,
        h.off_phone_no_2,
        h.rating,
        ttk_util_pkg.fn_decrypt(h.primary_email_id) as primary_email_id,  --//ED,
        g.description AS pat_type,
        c.pat_received_date,
        C.total_app_amount ,
        null policy_effective_from,
        null policy_effective_to ,
        null ins_status_general_type_id,
        null ins_comp_name,
        null ins_comp_code_number ,
        null group_reg_seq_id ,
        null group_name ,
        null group_id ,
        null policy_type_id,
        n.empanel_description ,
        O.country_name,
        a.ins_scheme,
        a.certificate_no,
        H.empanel_number,
        H.serv_tax_rgn_number
       FROM pat_enroll_details A JOIN tpa_hosp_info B ON (a.hosp_seq_id = b.hosp_seq_id AND a.pat_status_general_type_id = ''APR'' )
       JOIN pat_general_details C ON ( a.pat_enroll_detail_seq_id = c.pat_enroll_detail_seq_id AND c.pat_enhanced_yn = ''N'' AND C.completed_yn = ''Y'' )
       LEFT OUTER JOIN tpa_enr_policy_member D ON ( a.member_seq_id = d.member_seq_id )
      LEFT OUTER JOIN tpa_general_code g ON (c.pat_general_type_id = g.general_type_id )
      LEFT OUTER JOIN tpa_hosp_info H ON (a.hosp_seq_id = h.hosp_seq_id)
      LEFT OUTER JOIN tpa_hosp_address I ON ( h.hosp_seq_id = i.hosp_seq_id )
      LEFT OUTER JOIN tpa_state_code J ON (I.state_type_id = J.state_type_id)
      LEFT OUTER JOIN tpa_city_code K ON (I.city_type_id = K.city_type_id )
      LEFT OUTER JOIN tpa_ins_info L ON (a.ins_seq_id = l.ins_seq_id )
      LEFT OUTER JOIN tpa_group_registration M ON (a.group_reg_seq_id = m.group_reg_seq_id )
      LEFT OUTER JOIN tpa_country_code O ON (I.country_id = O.country_id)
      LEFT OUTER JOIN tpa_hosp_empanel_status P ON (H.hosp_seq_id = P.hosp_seq_id)
      LEFT OUTER JOIN tpa_hosp_empanel_status_code N ON (P.empanel_status_type_id = n.empanel_status_type_id )';

    IF v_tpa_enrollment_id IS NOT NULL THEN
      -- like changed to =
      v_where := v_where ||' AND A.tpa_enrollment_id  = :v_tpa_enrollment_id';
      i := i+1;
--      bind_tab(i) := UPPER(v_tpa_enrollment_id)||'%';
      bind_tab(i) := UPPER(v_tpa_enrollment_id);
    ELSIF v_claimant_name IS NOT NULL THEN
      v_where := v_where ||' AND A.claimant_name  LIKE :v_claimant_name';
      i := i+1;
      bind_tab(i) := UPPER(v_claimant_name)||'%';
    END IF;
    IF v_auth_number IS NOT NULL THEN
      v_where := v_where ||' AND A.auth_number  = :v_auth_number';
      i := i+1;
      bind_tab(i) := upper(v_auth_number);
    END IF;
    IF v_hosp_name IS NOT NULL THEN
      v_where := v_where ||' AND B.hosp_name  LIKE :v_hosp_name';
      i := i+1;
      bind_tab(i) := UPPER(v_hosp_name)||'%';
    END IF;
    IF v_pat_general_type_id IS NOT NULL THEN
      v_where := v_where ||' AND C.pat_general_type_id  = :v_pat_general_type_id';
      i := i+1;
      bind_tab(i) := v_pat_general_type_id ;
    END IF;
    IF v_from_date IS NOT NULL THEN
      v_where := v_where ||' AND A.date_of_hospitalization >= :v_from_date ';
      i := i+1;
      bind_tab(i) := v_from_date;
    END IF;
    IF v_to_date IS NOT NULL THEN
      v_where := v_where ||' AND TRUNC(A.date_of_hospitalization) <= :v_to_date ';
      i := i+1;
      bind_tab(i) := v_to_date;
    END IF;

    v_where := v_where ||' AND ( A.claim_id IS NULL and 0 = ( SELECT COUNT(1) FROM clm_general_details CGD JOIN clm_enroll_details CED ON (CGD.claim_seq_id = CED.claim_seq_id)
                      WHERE CGD.pat_enroll_detail_seq_id = a.pat_enroll_detail_seq_id
                       AND ( CGD.completed_yn = ''N'' OR CED.clm_status_general_type_id NOT IN (''REJ'',''PCO'')))
    OR A.claim_id = :v_claim_seq_id ) ';
    v_where := ' WHERE '|| SUBSTR(v_where,5);
    v_sql_str := v_sql_str ||v_where;

    v_sql_str := 'SELECT * FROM
          (SELECT A.*, DENSE_RANK() OVER (ORDER BY '||v_sort_var||' '||v_sort_order||',ROWNUM)
          Q FROM (' ||v_sql_str|| ') A ) WHERE Q>= :v_start_num  AND Q<= :v_end_num ';
    IF bind_tab.FIRST IS NOT NULL THEN
       CASE bind_tab.COUNT
         WHEN 1 THEN OPEN result_set FOR v_sql_str USING bind_tab(1),v_claim_seq_id,v_start_num, v_end_num ;
         WHEN 2 THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),v_claim_seq_id, v_start_num , v_end_num ;
         WHEN 3 THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,v_claim_seq_id, v_start_num , v_end_num ;
         WHEN 4 THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,v_claim_seq_id,v_start_num ,v_end_num ;
         WHEN 5 THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5) ,v_claim_seq_id,v_start_num , v_end_num ;
         WHEN 6 THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5) ,bind_tab(6),v_claim_seq_id,v_start_num , v_end_num ;
         WHEN 7 THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5) ,bind_tab(6),bind_tab(7),v_claim_seq_id ,v_start_num , v_end_num ;
       END CASE;
    ELSE
      OPEN result_set FOR v_sql_str USING v_start_num , v_end_num ;
    END IF;

  END select_preauth_list;
-- =================================================================================================================

  PROCEDURE select_claims_list (
    v_claims_inward_no               IN  clm_inward.claims_inward_no%TYPE,
    v_claim_number                   IN  clm_general_details.claim_number%TYPE,
    v_claim_general_type_id          IN  clm_inward.claim_general_type_id%TYPE,
    v_claim_settlement_number        IN  clm_general_details.claim_settlement_number%TYPE,
    v_claim_file_number              IN  clm_general_details.claim_file_number%TYPE,
    v_claimant_name                  IN  clm_enroll_details.claimant_name %TYPE,
    v_tpa_enrollment_id              IN  clm_enroll_details.tpa_enrollment_id%TYPE,
    v_policy_number                  IN  clm_enroll_details.policy_number%TYPE,
    v_corporate_name                 IN  clm_inward.corporate_name%TYPE,
    v_employee_no                    IN  clm_enroll_details.employee_no%TYPE,
    v_employee_name                  IN  clm_enroll_details.employee_name%TYPE,
    v_policy_holder_name             IN  clm_enroll_details.policy_holder_name%TYPE,
    v_assigned_to_user               IN  VARCHAR2,
    v_contact_name                   IN  tpa_user_contacts.contact_name%TYPE,
    v_clm_status_general_type_id     IN  clm_enroll_details.clm_status_general_type_id%TYPE,
    v_mode_general_type_id           IN  clm_general_details.mode_general_type_id%TYPE,
    v_tpa_office_seq_id              IN  tpa_office_info.tpa_office_seq_id%TYPE ,
    v_event_seq_id                   IN  clm_general_details.event_seq_id%TYPE,
    v_ins_scheme                     IN  PAT_ENROLL_DETAILS.ins_scheme%TYPE,
    v_certificate_no                 IN  PAT_ENROLL_DETAILS.certificate_no%TYPE,
    v_ins_status                     IN  app.clm_ins_intimation_details.clm_ins_status%TYPE,
    v_policy_holder_code             IN  tpa_enr_policy.policy_holder_code%type,
    v_clm_intimation_id              IN  TPA_CALL_LOG.Call_Log_Number%type,
    v_sort_var                       IN  VARCHAR2,
    v_sort_order                     IN  VARCHAR2,
    v_start_num                      IN  NUMBER ,
    v_end_num                        IN  NUMBER ,
    v_added_by                       IN  NUMBER,
    result_set                       OUT SYS_REFCURSOR
  )
  IS


CURSOR USER_ASS_INFO IS
SELECT count(1) FROM APP.TPA_GROUP_USER_ASSOC UA
JOIN APP.TPA_GROUP_BRANCH GB ON (GB.GROUP_BRANCH_SEQ_ID = UA.GROUP_BRANCH_SEQ_ID)
join APP.TPA_INS_INFO INF ON (inf.user_group = gb.group_branch_seq_id)
WHERE GB.USER_TYPE='NIC' AND  UA.CONTACT_SEQ_ID = v_added_by;




    TYPE bind_tab_type IS TABLE OF VARCHAR2(250) INDEX BY BINARY_INTEGER ;
    bind_tab                             bind_tab_type;
    i                                    NUMBER(2) := 0;
    v_where                              VARCHAR2(2000);
    v_sql_str                            VARCHAR2(6000);
    v_cnt                                NUMBER(5);

  BEGIN
    v_sql_str :=
       'SELECT
       A.claim_number ,
       B.tpa_enrollment_id ,
       H.hosp_name ,
       b.claimant_name,
       F.contact_name,
       A.date_of_admission ,
       G.auth_number ,
       A.claim_seq_id,
       B.clm_enroll_detail_seq_id,
       G.pat_enroll_detail_seq_id ,
       H.clm_hosp_assoc_seq_id ,
       B.policy_seq_id,
       B.member_seq_id,
       C.tpa_office_seq_id,
       I.buffer_allowed_yn ,
       E.assign_users_seq_id,
       CASE WHEN E.pat_status_general_type_id = ''REQ'' THEN
          CASE WHEN ( SELECT COUNT(1) FROM shortfall_details S  WHERE S.claim_seq_id = a.claim_seq_id
           AND (s.srtfll_status_general_type_id = ''CLS'' OR s.srtfll_status_general_type_id = ''ORD'')) > 1 THEN ''Y'' ELSE ''N'' END
          ELSE ''N'' END AS shrtfall_yn,
       CASE WHEN a.parent_claim_seq_id IS NULL THEN ''N'' ELSE ''Y'' END ammendment_yn ,
       I.Group_Branch_Seq_Id ,
       replace(replace(nvl(d.gen_complete_yn,''N''),''Y'',''G'')||'' ''||replace(nvl(d.med_complete_yn,''N''),''Y'',''M'')||'' ''||replace(nvl(d.cod_complete_yn,''N''),''Y'',''C'')
       ||'' ''||replace(nvl(d.bill_complete_yn,''N''),''Y'',''B''),''N'','' '') as STATUS,
       CASE WHEN j.event_owner = ''C'' THEN ''Y'' ELSE ''N'' END AS coding_review_yn,
       CASE WHEN ( SELECT COUNT(1) FROM investigation_details I  WHERE a.Claim_Seq_Id  = i.Claim_Seq_Id
           AND (i.invst_status_general_type_id IN (''ISN''))) > 0 THEN ''Y'' ELSE ''N'' END
            AS clm_invest_lock_yn, --Added for koc_investigation
       CASE WHEN ( SELECT COUNT(1) FROM investigation_details I  WHERE a.Claim_Seq_Id  = i.Claim_Seq_Id
           AND (i.invst_status_general_type_id IN (''GNU''))) > 0 THEN ''Y'' ELSE ''N'' END
           AS clm_inv_yn, --Added for koc_investigation
       CASE WHEN ( SELECT COUNT(1) FROM investigation_details I  WHERE a.Claim_Seq_Id  = i.Claim_Seq_Id
           AND (i.invst_status_general_type_id IN (''FDL''))) > 0 THEN ''Y'' ELSE ''N'' END
           AS clm_investigation_yn, --Added for koc_investigation
       CASE WHEN ( SELECT COUNT(1) FROM investigation_details I  WHERE a.Claim_Seq_Id  = i.Claim_Seq_Id
           AND (i.invst_status_general_type_id IN (''RNR''))) > 0 THEN ''Y'' ELSE ''N'' END
           AS clm_invest_yn --Added for koc_investigation
      FROM clm_general_details A JOIN clm_enroll_details B ON (A.claim_seq_id = b.claim_seq_id)
      JOIN clm_inward C ON ( a.claims_inward_seq_id = c.claims_inward_seq_id)
      left outer join app.clm_ins_intimation_details cii on (b.claim_seq_id=cii.claim_seq_id)
      LEFT OUTER JOIN assign_users E ON (A.last_assign_user_seq_id   = E.assign_users_seq_id)
      LEFT OUTER JOIN tpa_user_contacts F ON (E.assigned_to_user = F.contact_seq_id)
      LEFT OUTER JOIN pat_enroll_details G ON (A.pat_enroll_detail_seq_id  = G.pat_enroll_detail_seq_id)
      LEFT OUTER JOIN clm_hospital_association H ON (A.claim_seq_id = H.claim_seq_id)
      LEFT OUTER JOIN tpa_enr_policy I ON ( B.policy_seq_id = I.policy_seq_id  )
      LEFT OUTER JOIN tpa_event j ON (a.event_seq_id = j.event_seq_id)
      LEFT OUTER JOIN clm_data_entry_complete d on (d.claim_seq_id=a.claim_seq_id)
      ';


-- LEFT OUTER JOIN TPA_CALL_CLAIM_INTIMATION cj ON (cj.claim_seq_id = a.claim_seq_id and l.claim_seq_id is not null )
    IF v_claims_inward_no IS NOT NULL THEN
      v_where := v_where   ||' AND C.claims_inward_no = :v_claims_inward_no';
       i := i+1;
       bind_tab(i) := UPPER(v_claims_inward_no) ;
    END IF;
    IF v_claim_number IS NOT NULL THEN
      v_where := v_where   ||' AND A.claim_number = :v_claim_number';
       i := i+1;
       bind_tab(i) := UPPER(v_claim_number);
    END IF;
    IF v_employee_name IS NOT NULL THEN
      v_where := v_where   ||' AND B.employee_name  LIKE :v_employee_name ';
       i := i+1;
       bind_tab(i) := UPPER(v_employee_name)||'%';
    END IF;

    IF v_assigned_to_user = 'SLF' THEN
      v_where := v_where  ||' AND E.assigned_to_user  = :v_added_by ';
       i := i+1;
       bind_tab(i) := v_added_by;
    ELSIF v_assigned_to_user = 'OTH' THEN
      v_where := v_where  ||' AND E.assigned_to_user  != :v_added_by ';
       i := i+1;
       bind_tab(i) := v_added_by;
    ELSIF v_assigned_to_user = 'UAS' THEN
      v_where := v_where  ||' AND E.assigned_to_user IS NULL ';
    END IF;

    IF v_claim_general_type_id IS NOT NULL THEN
       v_where := v_where   ||' AND C.claim_general_type_id  = :v_claim_general_type_id ';
       i := i+1;
       bind_tab(i) := v_claim_general_type_id;
    END IF;
    IF v_claim_settlement_number IS NOT NULL THEN

       v_where := v_where   ||' AND A.claim_settlement_number = :v_claim_settlement_number';
       i := i+1;
       bind_tab(i) := UPPER(v_claim_settlement_number);
    END IF;
    IF v_claim_file_number IS NOT NULL THEN

       v_where := v_where   ||' AND A.claim_file_number = :v_claim_file_number';
       i := i+1;
       bind_tab(i) := UPPER(v_claim_file_number);
    END IF;
    IF v_claimant_name IS NOT NULL THEN
       v_where := v_where   ||' AND B.claimant_name LIKE :v_claimant_name';
       i := i+1;
       bind_tab(i) := UPPER(v_claimant_name)||'%';
    END IF;
    IF v_tpa_enrollment_id IS NOT NULL THEN

       v_where := v_where   ||' AND B.tpa_enrollment_id = :v_tpa_enrollment_id';
       i := i+1;
       bind_tab(i) := UPPER(v_tpa_enrollment_id);
    END IF;
    IF v_policy_number IS NOT NULL THEN

       v_where := v_where   ||' AND B.policy_number  = :v_policy_number';
       i := i+1;
       bind_tab(i) := UPPER(v_policy_number);
    END IF;
    IF v_corporate_name IS NOT NULL THEN
       v_where := v_where   ||' AND C.corporate_name  LIKE :v_corporate_name';
       i := i+1;
       bind_tab(i) := UPPER(v_corporate_name)||'%';
    END IF;
    IF v_employee_no IS NOT NULL THEN
       v_where := v_where   ||' AND B.employee_no  = :v_employee_no';
       i := i+1;
       bind_tab(i) := v_employee_no ;
    END IF;
    IF v_policy_holder_name IS NOT NULL THEN
      v_where := v_where   ||' AND B.policy_holder_name  LIKE :v_policy_holder_name';
       i := i+1;
       bind_tab(i) := UPPER(v_policy_holder_name)||'%';
    END IF;
    IF v_contact_name IS NOT NULL THEN
       v_where := v_where   ||' AND F.contact_name  LIKE :v_contact_name';
       i := i+1;
       bind_tab(i) := UPPER(v_contact_name)||'%';
    END IF;
    IF v_clm_status_general_type_id IS NOT NULL THEN
       v_where := v_where   ||' AND B.clm_status_general_type_id  = :v_clm_status_general_type_id ';
       i := i+1;
       bind_tab(i) := v_clm_status_general_type_id;
    END IF;
    IF v_mode_general_type_id IS NOT NULL THEN
       v_where := v_where   ||' AND A.mode_general_type_id  = :v_mode_general_type_id  ';
       i := i+1;
       bind_tab(i) := v_mode_general_type_id;
    END IF;
    IF v_tpa_office_seq_id IS NOT NULL THEN
       v_where := v_where   ||' AND C.tpa_office_seq_id = :v_tpa_office_seq_id ';
       i := i+1;
       bind_tab(i) := v_tpa_office_seq_id;
    END IF;
    IF v_event_seq_id IS NOT NULL THEN
       v_where := v_where   ||' AND A.event_seq_id = :v_event_seq_id ';
       i := i+1;
       bind_tab(i) := v_event_seq_id;
    END IF;
    IF v_ins_scheme IS NOT NULL THEN
      v_where := v_where  ||' AND b.ins_scheme = :v_ins_scheme ';
       i := i+1;
       bind_tab(i) := v_ins_scheme;
    END IF;
    IF v_certificate_no IS NOT NULL THEN
      v_where := v_where  ||' AND b.certificate_no = :v_certificate_no ';
       i := i+1;
       bind_tab(i) := v_certificate_no;
    END IF;

    IF v_ins_status IS NOT NULL THEN
      v_where := v_where  ||' AND cii.clm_ins_status = :v_ins_status';
       i := i+1;
       bind_tab(i) := v_ins_status;
    END IF;
--KOC_Cigna_insurance_resriction
    if v_added_by IS NOT NULL THEN

        v_where := v_where ||' AND ( b.ins_seq_id  in (SELECT inf.ins_seq_id FROM APP.TPA_GROUP_USER_ASSOC UA
      JOIN APP.TPA_GROUP_BRANCH GB ON (GB.GROUP_BRANCH_SEQ_ID = UA.GROUP_BRANCH_SEQ_ID)
      join APP.TPA_INS_INFO INF ON (inf.user_group = gb.group_branch_seq_id)
      WHERE GB.USER_TYPE=''NIC'' AND  UA.CONTACT_SEQ_ID = '||v_added_by||') OR (SELECT count(inf.ins_seq_id) FROM APP.TPA_GROUP_USER_ASSOC UA
      JOIN APP.TPA_GROUP_BRANCH GB ON (GB.GROUP_BRANCH_SEQ_ID = UA.GROUP_BRANCH_SEQ_ID)
      join APP.TPA_INS_INFO INF ON (inf.user_group = gb.group_branch_seq_id)
      WHERE GB.USER_TYPE=''NIC'' AND  UA.CONTACT_SEQ_ID = '||v_added_by||') = 0 )';

    end if;
--KOC_Cigna_insurance_resriction
--koc_griavance
    IF v_policy_holder_code IS NOT NULL THEN
      v_where := v_where  ||' AND I.policy_holder_code = :v_policy_holder_code';
       i := i+1;
       bind_tab(i) := v_policy_holder_code;
    END IF;

    IF v_clm_intimation_id IS NOT NULL THEN

             
       for rec in ( select ci.claim_seq_id,l.* from tpa_call_log l
         left outer join TPA_CALL_CLAIM_INTIMATION ci on ( ci.call_log_seq_id=l.call_log_seq_id )
        where (ci.clm_intimation_id = v_clm_intimation_id or l.call_log_number = v_clm_intimation_id) )
       loop
         if rec.claim_seq_id is null then
    v_sql_str := v_sql_str||' LEFT OUTER JOIN TPA_CALL_LOG l ON (l.member_seq_id = b.member_seq_id)
      LEFT OUTER JOIN TPA_CALL_CLAIM_INTIMATION ci ON ( ci.call_log_seq_id = l.call_log_seq_id and ci.claim_seq_id is null ) ';
     v_where := v_where  ||' AND ( l.call_log_number = :v_clm_intimation_id ) ';
       i := i+1;
       bind_tab(i) := rec.call_log_number;
         else
    v_sql_str := v_sql_str||' LEFT OUTER JOIN TPA_CALL_CLAIM_INTIMATION cj ON ( cj.claim_seq_id = a.claim_seq_id and cj.claim_seq_id is not null )
      LEFT OUTER JOIN TPA_CALL_LOG l ON (cj.call_log_seq_id = l.call_log_seq_id) ';
     v_where := v_where  ||' AND ( l.call_log_number = :v_clm_intimation_id ) ';
       i := i+1;
       bind_tab(i) := rec.call_log_number;
           end if;

       end loop;
    END IF;
--koc_griavance

    v_where := v_where   ||' AND C.inward_status_general_type_id = ''IWC''';

    IF v_where IS NOT NULL THEN
      v_where   := ' WHERE '|| SUBSTR(v_where,5);
    END IF;
    v_sql_str := v_sql_str ||v_where;

    v_sql_str := 'SELECT * FROM
          (SELECT A.*, DENSE_RANK() OVER (ORDER BY '||v_sort_var||' '||v_sort_order||',ROWNUM)
          Q FROM (' ||v_sql_str|| ') A ) WHERE Q>= :v_start_num  AND Q<=  :v_end_num ';

    IF bind_tab.FIRST IS NOT NULL THEN
       CASE bind_tab.COUNT
         WHEN 1  THEN OPEN result_set FOR v_sql_str USING bind_tab(1) , v_start_num , v_end_num ;
         WHEN 2  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2), v_start_num , v_end_num ;
         WHEN 3  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2) ,bind_tab(3) , v_start_num , v_end_num ;
         WHEN 4  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) , v_start_num , v_end_num ;
         WHEN 5  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5), v_start_num , v_end_num ;
         WHEN 6  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6), v_start_num , v_end_num ;
         WHEN 7  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6),bind_tab(7), v_start_num , v_end_num ;
         WHEN 8  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6),bind_tab(7),bind_tab(8), v_start_num , v_end_num ;
         WHEN 9  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6),bind_tab(7),bind_tab(8),bind_tab(9), v_start_num , v_end_num ;
         WHEN 10 THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6),bind_tab(7),bind_tab(8),bind_tab(9),bind_tab(10), v_start_num , v_end_num ;
         WHEN 11 THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6),bind_tab(7),bind_tab(8),bind_tab(9),bind_tab(10),bind_tab(11), v_start_num , v_end_num ;
         WHEN 12 THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6),bind_tab(7),bind_tab(8),bind_tab(9),bind_tab(10),bind_tab(11),bind_tab(12), v_start_num , v_end_num ;
         WHEN 13 THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6),bind_tab(7),bind_tab(8),bind_tab(9),bind_tab(10),bind_tab(11),bind_tab(12),bind_tab(13), v_start_num , v_end_num ;
         WHEN 14 THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6),bind_tab(7),bind_tab(8),bind_tab(9),bind_tab(10),bind_tab(11),bind_tab(12),bind_tab(13),bind_tab(14), v_start_num , v_end_num ;
         WHEN 15 THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6),bind_tab(7),bind_tab(8),bind_tab(9),bind_tab(10),bind_tab(11),bind_tab(12),bind_tab(13),bind_tab(14),bind_tab(15), v_start_num , v_end_num ;
         WHEN 16 THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6),bind_tab(7),bind_tab(8),bind_tab(9),bind_tab(10),bind_tab(11),bind_tab(12),bind_tab(13),bind_tab(14),bind_tab(15),bind_tab(16), v_start_num , v_end_num ;
         WHEN 17 THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6),bind_tab(7),bind_tab(8),bind_tab(9),bind_tab(10),bind_tab(11),bind_tab(12),bind_tab(13),bind_tab(14),bind_tab(15),bind_tab(16),bind_tab(17), v_start_num , v_end_num ;
         WHEN 18 THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6),bind_tab(7),bind_tab(8),bind_tab(9),bind_tab(10),bind_tab(11),bind_tab(12),bind_tab(13),bind_tab(14),bind_tab(15),bind_tab(16),bind_tab(17),bind_tab(18), v_start_num , v_end_num ;
         WHEN 19 THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6),bind_tab(7),bind_tab(8),bind_tab(9),bind_tab(10),bind_tab(11),bind_tab(12),bind_tab(13),bind_tab(14),bind_tab(15),bind_tab(16),bind_tab(17),bind_tab(18),bind_tab(19), v_start_num , v_end_num ;
         WHEN 20 THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6),bind_tab(7),bind_tab(8),bind_tab(9),bind_tab(10),bind_tab(11),bind_tab(12),bind_tab(13),bind_tab(14),bind_tab(15),bind_tab(16),bind_tab(17),bind_tab(18),bind_tab(19),bind_tab(20), v_start_num , v_end_num ;
       END CASE;
     ELSE
       OPEN result_set FOR v_sql_str USING v_start_num , v_end_num ;
     END IF;

  END select_claims_list;
 --==============================================================================================
 --   Name       : save_hospital_association
 --   Created on : -24-JUL-06
 --   Created By : - S.V.SREERAJ
 --   Comments   :
 --==============================================================================================
  PROCEDURE save_hospital_association(
    v_clm_hosp_assoc_seq_id              IN  OUT CLM_HOSPITAL_ASSOCIATION.clm_hosp_assoc_seq_id%TYPE,
    v_claim_seq_id                       IN  CLM_HOSPITAL_ASSOCIATION.claim_seq_id%TYPE,
    v_hosp_seq_id                        IN  CLM_HOSPITAL_ASSOCIATION.hosp_seq_id%TYPE,
    v_empanel_number                     IN  CLM_HOSPITAL_ASSOCIATION.empanel_number%TYPE,
    v_hosp_name                          IN  OUT CLM_HOSPITAL_ASSOCIATION.hosp_name%TYPE,
    v_address_1                          IN  OUT CLM_HOSPITAL_ASSOCIATION.address_1%TYPE,
    v_address_2                          IN  OUT CLM_HOSPITAL_ASSOCIATION.address_2%TYPE,
    v_address_3                          IN  OUT CLM_HOSPITAL_ASSOCIATION.address_3%TYPE,
    v_state_name                         IN  OUT CLM_HOSPITAL_ASSOCIATION.state_name%TYPE,
    v_city_name                          IN  OUT CLM_HOSPITAL_ASSOCIATION.city_name%TYPE,
    v_pin_code                           IN  OUT CLM_HOSPITAL_ASSOCIATION.pin_code%TYPE,
    v_off_phone_no_1                     IN  OUT CLM_HOSPITAL_ASSOCIATION.off_phone_no_1%TYPE,
    v_off_phone_no_2                     IN  OUT CLM_HOSPITAL_ASSOCIATION.off_phone_no_2%TYPE,
    v_office_fax_no                      IN  OUT CLM_HOSPITAL_ASSOCIATION.office_fax_no%TYPE,
    v_remarks                            IN  CLM_HOSPITAL_ASSOCIATION.remarks%TYPE,
    v_serv_tax_rgn_number                IN  CLM_HOSPITAL_ASSOCIATION.serv_tax_rgn_number%TYPE,
    v_added_by                           IN  CLM_HOSPITAL_ASSOCIATION.added_by%TYPE,
    v_rows_processed                     IN  OUT NUMBER
  )
  IS
    CURSOR prev_hosp_cur IS SELECT hosp_seq_id
       FROM clm_hospital_association
      WHERE clm_hosp_assoc_seq_id = v_clm_hosp_assoc_seq_id ;

    v_prev_hosp_rec                       prev_hosp_cur%ROWTYPE;

  BEGIN
    claims_freeze(v_claim_seq_id,NULL,'S'); --KOCBJJ

    IF v_clm_hosp_assoc_seq_id IS NULL  THEN
      INSERT INTO clm_hospital_association(
        clm_hosp_assoc_seq_id,
        claim_seq_id,
        hosp_seq_id,
        empanel_number,
        hosp_name,
        address_1,
        address_2,
        address_3,
        state_name,
        city_name,
        pin_code,
        off_phone_no_1,
        off_phone_no_2,
        office_fax_no,
        remarks,
        serv_tax_rgn_number,
        added_by,
        added_date )
      VALUES (
        clm_clm_hosp_assoc_seq_id.NEXTVAL,
        v_claim_seq_id,
        v_hosp_seq_id,
        v_empanel_number,
        v_hosp_name,
        v_address_1,
        v_address_2,
        v_address_3,
        v_state_name,
        v_city_name,
        v_pin_code,
        v_off_phone_no_1,
        v_off_phone_no_2,
        v_office_fax_no,
        v_remarks,
        v_serv_tax_rgn_number,
        v_added_by,
        SYSDATE ) RETURNING clm_hosp_assoc_seq_id INTO v_clm_hosp_assoc_seq_id;

        IF v_hosp_seq_id IS NULL THEN
           INSERT INTO clm_hospital_additional_dtl ( add_hosp_dtl_seq_id , clm_hosp_assoc_seq_id ,added_by, added_date)
                       VALUES ( clm_add_hosp_dtl_seq_id.NEXTVAL , v_clm_hosp_assoc_seq_id , v_added_by ,SYSDATE );
        END IF;
   ELSE

      OPEN prev_hosp_cur;
      FETCH prev_hosp_cur INTO v_prev_hosp_rec;
      CLOSE prev_hosp_cur;

      IF v_hosp_seq_id IS NOT NULL THEN
        IF v_prev_hosp_rec.hosp_seq_id IS NULL THEN
          DELETE FROM clm_hospital_additional_dtl
            WHERE clm_hosp_assoc_seq_id = v_clm_hosp_assoc_seq_id ;
          -- to remove the previous entered data.
          v_address_1                          := NULL;
          v_address_2                          := NULL;
          v_address_3                          := NULL;
          v_state_name                         := NULL;
          v_city_name                          := NULL;
          v_pin_code                           := NULL;
          v_off_phone_no_1                     := NULL;
          v_off_phone_no_2                     := NULL;
          v_office_fax_no                      := NULL;

        END IF ;
      ELSE
        IF v_prev_hosp_rec.hosp_seq_id IS NOT NULL THEN
           INSERT INTO clm_hospital_additional_dtl ( add_hosp_dtl_seq_id , clm_hosp_assoc_seq_id ,added_by, added_date)
                       VALUES (  clm_add_hosp_dtl_seq_id.NEXTVAL , v_clm_hosp_assoc_seq_id , v_added_by ,SYSDATE );
        END  IF;
      END IF;

      UPDATE clm_hospital_association SET
        hosp_seq_id                             = v_hosp_seq_id,
        empanel_number                          = v_empanel_number,
        hosp_name                               = v_hosp_name,
        address_1                               = v_address_1,
        address_2                               = v_address_2,
        address_3                               = v_address_3,
        state_name                              = v_state_name,
        city_name                               = v_city_name,
        pin_code                                = v_pin_code,
        off_phone_no_1                          = v_off_phone_no_1,
        off_phone_no_2                          = v_off_phone_no_2,
        office_fax_no                           = v_office_fax_no,
        remarks                                 = v_remarks,
        serv_tax_rgn_number                     = v_serv_tax_rgn_number,
        updated_by                              = v_added_by,
        updated_date                            = SYSDATE
        WHERE clm_hosp_assoc_seq_id = v_clm_hosp_assoc_seq_id;

    END IF;
    v_rows_processed := SQL%ROWCOUNT;
  END save_hospital_association;

-- =================================================================================================================
 --==============================================================================================
 --   Name       : SAVE_HOSP_ADDITIONAL_DTL
 --   Created on : -24-JUL-06
 --   Created By : - S.V.SREERAJ
 --   Comments   :
 --==============================================================================================
  PROCEDURE save_hosp_additional_dtl(
    v_add_hosp_dtl_seq_id                IN  OUT CLM_HOSPITAL_ADDITIONAL_DTL.add_hosp_dtl_seq_id%TYPE,
    v_clm_hosp_assoc_seq_id              IN  CLM_HOSPITAL_ADDITIONAL_DTL.clm_hosp_assoc_seq_id%TYPE,
    v_hosp_regist_number                 IN  CLM_HOSPITAL_ADDITIONAL_DTL.hosp_regist_number%TYPE,
    v_contact_name                       IN  CLM_HOSPITAL_ADDITIONAL_DTL.contact_name%TYPE,
    v_off_phone_no_1                     IN  CLM_HOSPITAL_ADDITIONAL_DTL.off_phone_no_1%TYPE,
    v_number_of_beds                     IN  CLM_HOSPITAL_ADDITIONAL_DTL.number_of_beds%TYPE,
    v_fully_equipped_yn                  IN  CLM_HOSPITAL_ADDITIONAL_DTL.fully_equipped_yn%TYPE,
    v_added_by                           IN  CLM_HOSPITAL_ADDITIONAL_DTL.added_by%TYPE,
    v_rows_processed                     IN  OUT NUMBER
  )
  IS

  BEGIN
    IF v_add_hosp_dtl_seq_id IS NULL  THEN
      INSERT INTO clm_hospital_additional_dtl(
        add_hosp_dtl_seq_id,
        clm_hosp_assoc_seq_id,
        hosp_regist_number,
        contact_name,
        off_phone_no_1,
        number_of_beds,
        fully_equipped_yn,
        added_by,
        added_date)
      VALUES (
        clm_add_hosp_dtl_seq_id.NEXTVAL ,
        v_clm_hosp_assoc_seq_id,
        v_hosp_regist_number,
        v_contact_name,
        v_off_phone_no_1,
        v_number_of_beds,
        v_fully_equipped_yn,
        v_added_by,
        SYSDATE ) RETURNING add_hosp_dtl_seq_id  INTO v_add_hosp_dtl_seq_id;

    ELSE
      UPDATE clm_hospital_additional_dtl SET
        clm_hosp_assoc_seq_id                   = v_clm_hosp_assoc_seq_id,
        hosp_regist_number                      = v_hosp_regist_number,
        contact_name                            = v_contact_name,
        off_phone_no_1                          = v_off_phone_no_1,
        number_of_beds                          = v_number_of_beds,
        fully_equipped_yn                       = v_fully_equipped_yn,
        updated_by                              = v_added_by,
        updated_date                            = SYSDATE
        WHERE add_hosp_dtl_seq_id  = v_add_hosp_dtl_seq_id ;
    END IF;
    v_rows_processed := SQL%ROWCOUNT;
  END save_hosp_additional_dtl;
 --==============================================================================================
 --   Name       : SAVE_GENERAL_DETAILS
 --   Created on : -24-JUL-06
 --   Created By : - S.V.SREERAJ
 --   Comments   :
 --==============================================================================================
  PROCEDURE save_general_details(
    v_claim_seq_id                       IN  OUT CLM_GENERAL_DETAILS.claim_seq_id%TYPE,
    v_claims_inward_seq_id               IN  CLM_GENERAL_DETAILS.claims_inward_seq_id%TYPE,
    v_member_seq_id                      IN  CLM_ENROLL_DETAILS.member_seq_id%TYPE,
    v_requested_amount                   IN  CLM_GENERAL_DETAILS.requested_amount%TYPE,
    v_pat_enroll_detail_seq_id           IN  CLM_GENERAL_DETAILS.pat_enroll_detail_seq_id%TYPE,
    v_auth_number                        IN  CLM_GENERAL_DETAILS.auth_number%TYPE,
    v_pat_approved_amount                IN  CLM_GENERAL_DETAILS.pat_approved_amount%TYPE,
    v_request_general_type_id            IN  CLM_GENERAL_DETAILS.request_general_type_id%TYPE,
    v_claim_sub_general_type_id          IN  CLM_GENERAL_DETAILS.claim_sub_general_type_id%TYPE,
    v_reason_for_dom                     IN  clm_general_details.DOM_REASON_GEN_TYPE_ID%type,--KOC1285
    v_doctor_certified_YN                IN  CLM_GENERAL_DETAILS.DOC_CERT_DOM_YN%type,--KOC1285
    v_call_log_seq_id                    IN  CLM_GENERAL_DETAILS.call_log_seq_id%TYPE,
    v_mode_general_type_id               IN  CLM_GENERAL_DETAILS.mode_general_type_id%TYPE,
    v_treating_dr_name                   IN  CLM_GENERAL_DETAILS.treating_dr_name%TYPE,
    v_in_patient_no                      IN  CLM_GENERAL_DETAILS.in_patient_no%TYPE,
    v_claims_remarks                     IN  CLM_GENERAL_DETAILS.claims_remarks%TYPE,
    v_ava_sum_insured                    IN  CLM_GENERAL_DETAILS.ava_sum_insured%TYPE,
    v_ava_cum_bonus                      IN  CLM_GENERAL_DETAILS.ava_cum_bonus%TYPE,
    v_ava_buff_amount                    IN  CLM_GENERAL_DETAILS.ava_buff_amount%TYPE,
    v_discrepancy_present_yn             IN  CLM_GENERAL_DETAILS.discrepancy_present_yn%TYPE,
    v_date_of_admission                  IN  CLM_GENERAL_DETAILS.date_of_admission%TYPE,
    v_date_of_discharge                  IN  CLM_GENERAL_DETAILS.date_of_discharge%TYPE,
    v_parent_claim_seq_id                IN  OUT CLM_GENERAL_DETAILS.parent_claim_seq_id%TYPE,
    v_claim_settlement_number            IN  CLM_GENERAL_DETAILS.claim_settlement_number%TYPE,
    v_prev_hosp_claim_seq_id             IN  OUT CLM_GENERAL_DETAILS.Prev_Hosp_Claim_Seq_Id%TYPE,
    v_hosp_seq_id                        IN  CLM_HOSPITAL_ASSOCIATION.hosp_seq_id%TYPE,
    v_claim_dms_reference_id             IN  CLM_GENERAL_DETAILS.claim_dms_reference_id%TYPE,
    v_policy_seq_id                      IN  CLM_ENROLL_DETAILS.Policy_Seq_Id%TYPE,
    v_re_open_type                       IN  CLM_GENERAL_DETAILS.re_open_type%TYPE,
    v_doctor_registration_no             IN  CLM_GENERAL_DETAILS.doctor_registration_no%TYPE,
    v_insur_ref_number                   IN  CLM_GENERAL_DETAILS.Insur_Ref_Number%TYPE, --insur-ref-number
    v_last_buffer_detail_seq_id          IN  OUT CLM_GENERAL_DETAILS.Last_Buffer_Detail_Seq_Id%TYPE,
	  v_pay_to_general_type_id             IN  CLM_GENERAL_DETAILS.PAY_TO_GENERAL_TYPE_ID%TYPE,--opdforhs
    v_added_by                           IN  CLM_GENERAL_DETAILS.added_by%TYPE,
    v_rows_processed                     IN  OUT NUMBER
  )
  IS
    v_clm_cash_benefit_seq_id            CLM_CASH_BENEFIT.clm_cash_benefit_seq_id%TYPE;
    v_claim_number                       CLM_GENERAL_DETAILS.claim_number%TYPE;
    v_event_seq_id                       CLM_GENERAL_DETAILS.event_seq_id %TYPE;
    v_required_review_count              CLM_GENERAL_DETAILS.required_review_count%TYPE;
    v_tpa_office_seq_id                  CLM_INWARD.tpa_office_seq_id%TYPE;
    v_old_prev_hosp_claim_seq_id         CLM_GENERAL_DETAILS.prev_hosp_claim_seq_id%TYPE;
    v_prev_sub_general_type_id           CLM_GENERAL_DETAILS.claim_sub_general_type_id%TYPE;
    v_document_general_type_id           CLM_INWARD.document_general_type_id%TYPE;
    v_ctr                                NUMBER(3);
    v_original_yn                        CLM_GENERAL_DETAILS.original_yn%TYPE := 'Y';
    v_claim_file_number                  CLM_GENERAL_DETAILS.claim_file_number%TYPE;
    v_claim_general_type_id              CLM_INWARD.claim_general_type_id%TYPE;
    v_prev_member_seq_id                 TPA_ENR_POLICY_MEMBER.member_seq_id%TYPE;
    v_prev_pat_enroll_seq_id             pat_general_details.pat_enroll_detail_seq_id%TYPE;
    v_prev_hosp_seq_id                   clm_hospital_association.hosp_seq_id%TYPE;     --patchtogo
--    v_first_event_seq_id                 clm_general_details.event_seq_id%TYPE;
    v_policy_sub_general_type_id         tpa_enr_policy.policy_sub_general_type_id%TYPE;
    v_old_claim_file_number              clm_general_details.claim_file_number%TYPE;
    v_prev_date_of_admission             DATE;
    v_prev_date_of_discharge             DATE;
    v_coding_event_seq_id                tpa_event.event_seq_id%TYPE;

    CURSOR prev_clm_cur IS SELECT
      a.prev_hosp_claim_seq_id , a.claim_sub_general_type_id , b.document_general_type_id , a.claim_number , a.claim_file_number , b.claim_general_type_id ,a.original_yn ,
      c.member_seq_id , a.last_buffer_detail_seq_id , a.pat_enroll_detail_seq_id , d.hosp_seq_id, a.event_seq_id,c.policy_sub_general_type_id, a.clm_cash_benefit_seq_id,
      a.date_of_admission,a.date_of_discharge
      FROM clm_general_details a JOIN clm_inward b ON (a.claims_inward_seq_id = b.claims_inward_seq_id)
      JOIN clm_enroll_details c ON (a.claim_seq_id = c.claim_seq_id)
      LEFT OUTER JOIN clm_hospital_association d ON (a.claim_seq_id = d.claim_seq_id)
       WHERE a.claim_seq_id = v_claim_seq_id;

    CURSOR file_no_cur IS SELECT b.claim_file_number , b.claim_seq_id/*, b.date_of_admission,
      b.date_of_discharge,a.member_seq_id,c.hosp_seq_id*/
      FROM clm_enroll_details A JOIN clm_general_details b ON (a.claim_seq_id = b.claim_seq_id)
      JOIN clm_hospital_association C ON (b.claim_seq_id = c.claim_seq_id)
       WHERE a.member_seq_id   = v_member_seq_id
       AND TRUNC(b.date_of_admission) = TRUNC(v_date_of_admission)
       AND TRUNC(b.date_of_discharge) = TRUNC(v_date_of_discharge)
       AND c.hosp_seq_id  = v_hosp_seq_id AND b.original_yn = 'Y';
--   file_no_rec           file_no_cur%ROWTYPE;
   CURSOR pat_cur IS SELECT COUNT(1)
     FROM pat_enroll_details a JOIN pat_general_details b ON (a.pat_enroll_detail_seq_id = b.pat_enroll_detail_seq_id AND b.pat_enhanced_yn = 'N')
     WHERE A.pat_enroll_detail_seq_id = v_pat_enroll_detail_seq_id AND b.completed_yn = 'Y' ;

   CURSOR inpatient_cur IS SELECT COUNT(1)
     FROM clm_general_details a LEFT OUTER JOIN clm_hospital_association b ON (a.claim_seq_id = b.claim_seq_id)
     WHERE a.in_patient_no = v_in_patient_no AND b.hosp_seq_id = v_hosp_seq_id
     AND a.claim_seq_id != nvl(v_claim_seq_id,0) ;

  BEGIN
    IF v_in_patient_no IS NOT NULL AND v_parent_claim_seq_id IS NULL THEN
      OPEN  inpatient_cur;
      FETCH inpatient_cur INTO v_ctr;
      CLOSE inpatient_cur;
      IF v_ctr > 0 THEN
        raise_application_error(-20701,'Duplicate In-patient Number');
      END IF;
    END IF;
    claims_freeze(v_claim_seq_id,NULL,'S'); --KOCBJJ
    IF NVL(v_claim_seq_id,0) = 0  THEN

      SELECT a.event_seq_id , a.simple_review_count INTO v_event_seq_id, v_required_review_count
        FROM tpa_event A JOIN tpa_workflow B ON (a.workflow_seq_id = b.workflow_seq_id )
        WHERE b.sub_general_type_id = 'CLM' AND A.order_number = 1;


      IF v_policy_seq_id IS NOT NULL THEN -- Getting tpa_officeseq_id  of the policy
        SELECT a.tpa_office_seq_id INTO v_tpa_office_seq_id
           FROM tpa_enr_policy a WHERE a.policy_seq_id = v_policy_seq_id ;
      ELSE
        SELECT a.tpa_office_seq_id INTO v_tpa_office_seq_id
           FROM clm_inward a WHERE a.claims_inward_seq_id = v_claims_inward_seq_id;
      END IF;

      IF v_parent_claim_seq_id IS NOT NULL THEN
        SELECT a.claim_file_number  INTO v_claim_file_number
          FROM clm_general_details a WHERE a.claim_seq_id = v_parent_claim_seq_id ;
          v_original_yn  := 'N';
      END IF;

      IF v_parent_claim_seq_id IS NULL THEN
        v_claim_number      := PRE_AUTH_PKG.generate_id_numbers('CL', v_tpa_office_seq_id , NULL, v_added_by);
      ELSE
        v_claim_number      := PRE_AUTH_PKG.generate_id_numbers('AM', v_tpa_office_seq_id , NULL, v_added_by);
      END IF;


      INSERT INTO clm_general_details(
        claim_seq_id,
        claims_inward_seq_id,
        claim_number,
        claim_file_number,
        requested_amount,
        original_yn,
        pat_enroll_detail_seq_id,
        auth_number,
        pat_approved_amount ,
        request_general_type_id,
        claim_sub_general_type_id,
        call_log_seq_id,
        mode_general_type_id,
        treating_dr_name,
        in_patient_no,
        claims_remarks,
        required_review_count,
        review_count,
        completed_yn,
        entered_date,
        discrepancy_present_yn,
        date_of_admission,
        date_of_discharge,
        parent_claim_seq_id,
        event_seq_id,
        prev_hosp_claim_seq_id ,
        validation_status,
        re_open_type ,
        doctor_registration_no,
        last_buffer_detail_seq_id,
        added_by,
        added_date,
        DOM_REASON_GEN_TYPE_ID,----koc1285
        doc_cert_dom_yn ,---koc1285
        insur_ref_number,
        pay_to_general_type_id--opdforhs
  )
      VALUES (
        clm_claim_seq.NEXTVAL ,
        v_claims_inward_seq_id,
        v_claim_number,
        v_claim_file_number,
        v_requested_amount,
        v_original_yn,
        v_pat_enroll_detail_seq_id,
        v_auth_number,
        v_pat_approved_amount ,
        v_request_general_type_id,
        v_claim_sub_general_type_id,
        v_call_log_seq_id,
        v_mode_general_type_id,
        v_treating_dr_name,
        v_in_patient_no,
        v_claims_remarks,
        v_required_review_count,
        1,
        'N',
        SYSDATE,
        NVL(v_discrepancy_present_yn,'N'),
        v_date_of_admission,
        v_date_of_discharge,
        v_parent_claim_seq_id,
        v_event_seq_id,
        v_prev_hosp_claim_seq_id ,
        'U',
        v_re_open_type ,
        v_doctor_registration_no,
        v_last_buffer_detail_seq_id,
        v_added_by,
        SYSDATE,
        v_reason_for_dom,
        nvl(v_doctor_certified_YN,'N'),
        v_insur_ref_number,
        v_pay_to_general_type_id--opdforhs
        ) RETURNING claim_seq_id INTO v_claim_seq_id;
      IF v_claim_sub_general_type_id = 'HCU' THEN
        DELETE FROM associated_illness a WHERE a.claim_seq_id = v_claim_seq_id;
      END IF;

   ELSE

      OPEN prev_clm_cur;
      FETCH prev_clm_cur INTO v_old_prev_hosp_claim_seq_id ,v_prev_sub_general_type_id ,
                               v_document_general_type_id , v_claim_number ,v_claim_file_number , v_claim_general_type_id ,v_original_yn ,
                               v_prev_member_seq_id ,v_last_buffer_detail_seq_id , v_prev_pat_enroll_seq_id,
                               v_prev_hosp_seq_id,v_event_seq_id,v_policy_sub_general_type_id,v_clm_cash_benefit_seq_id,
                               v_prev_date_of_admission,v_prev_date_of_discharge;
      CLOSE prev_clm_cur;

      IF nvl(v_pat_enroll_detail_seq_id,0) != nvl(v_prev_pat_enroll_seq_id,0) THEN

         SELECT COUNT(1) INTO v_ctr
           FROM clm_general_details a JOIN clm_enroll_details b ON (a.claim_seq_id = b.claim_seq_id)
           WHERE a.pat_enroll_detail_seq_id = v_pat_enroll_detail_seq_id
           AND ( a.completed_yn = 'N' OR b.clm_status_general_type_id NOT IN ('REJ','PCO'));
        IF v_ctr > 0 THEN
          raise_application_error(-20182,'Associated Preauth is overridden/re-associated to another claim, please re-associate preauth.');
        END IF;

        IF v_last_buffer_detail_seq_id IS NOT NULL THEN
          pre_auth_pkg.delete_buffer_record(NULL ,v_claim_seq_id,v_prev_member_seq_id ,v_policy_sub_general_type_id ,v_added_by);
        END IF;
        -- if current preauth was previously associated to another claim,
        -- this part is to delete buffer records of the previous claim
        FOR rec IN ( SELECT a.claim_seq_id  FROM clm_general_details a
                        WHERE a.pat_enroll_detail_seq_id = v_pat_enroll_detail_seq_id
                        ORDER BY a.claim_seq_id DESC )
        LOOP
          pre_auth_pkg.delete_claim_buffer(rec.claim_seq_id);
        END LOOP;

        IF v_prev_pat_enroll_seq_id IS NOT NULL THEN
          UPDATE pat_enroll_details a SET
              a.claim_id   = NULL
              WHERE a.pat_enroll_detail_seq_id = v_prev_pat_enroll_seq_id;
        END IF;
      END IF;

      v_old_claim_file_number := v_claim_file_number;

      /*IF NVL(v_old_prev_hosp_claim_seq_id,0) != NVL(v_prev_hosp_claim_seq_id,0) AND v_document_general_type_id != 'DTA' THEN
        IF v_claim_file_number IS NOT NULL THEN
          DELETE FROM ailment_details a WHERE a.claim_seq_id = v_claim_seq_id;
          DELETE FROM associated_illness a WHERE a.claim_seq_id = v_claim_seq_id;
          DELETE FROM pat_package_procedures a WHERE a.icd_pcs_seq_id IN ( SELECT b.icd_pcs_seq_id
                                                                             FROM icd_pcs_detail b
                                                                             WHERE b.claim_seq_id = v_claim_seq_id);
          DELETE FROM ailment_caps a WHERE a.icd_pcs_seq_id IN ( SELECT b.icd_pcs_seq_id
                                                                             FROM icd_pcs_detail b
                                                                             WHERE b.claim_seq_id = v_claim_seq_id);
          DELETE FROM icd_pcs_detail a WHERE a.claim_seq_id = v_claim_seq_id;
		  

          IF v_prev_hosp_seq_id IS NULL THEN
            DELETE FROM clm_hospital_additional_dtl a WHERE a.clm_hosp_assoc_seq_id =
                     (SELECT b.clm_hosp_assoc_seq_id FROM clm_hospital_association b WHERE b.claim_seq_id = v_claim_seq_id);
          END IF;

        ELSE
          DELETE FROM associated_illness a WHERE a.claim_seq_id = v_claim_seq_id;
        END IF;
        do_insert_ailments( v_claim_seq_id , v_prev_hosp_claim_seq_id , v_added_by );
        v_claim_file_number := NULL;
      END IF; */

      IF v_document_general_type_id != 'DTA' AND
      ( v_old_prev_hosp_claim_seq_id IS NOT NULL OR v_prev_hosp_claim_seq_id IS NOT NULL) AND
      ( NVL(v_old_prev_hosp_claim_seq_id,0) != NVL(v_prev_hosp_claim_seq_id,0) OR
        NVL(v_hosp_seq_id,0) != NVL(v_prev_hosp_seq_id,0) OR TRUNC(v_date_of_admission) != TRUNC(v_prev_date_of_admission)
        OR TRUNC(v_date_of_discharge) != TRUNC(v_prev_date_of_discharge) OR nvl(v_prev_member_seq_id,0) != v_member_seq_id)  THEN

        --IF v_old_prev_hosp_claim_seq_id IS NOT NULL OR v_prev_hosp_claim_seq_id IS NOT NULL THEN
          IF v_claim_file_number IS NOT NULL THEN
            DELETE FROM ailment_details a WHERE a.claim_seq_id = v_claim_seq_id;
            DELETE FROM associated_illness a WHERE a.claim_seq_id = v_claim_seq_id;
            DELETE FROM pat_package_procedures a WHERE a.icd_pcs_seq_id IN ( SELECT b.icd_pcs_seq_id
                                                                               FROM icd_pcs_detail b
                                                                               WHERE b.claim_seq_id = v_claim_seq_id);
            DELETE FROM ailment_caps a WHERE a.icd_pcs_seq_id IN ( SELECT b.icd_pcs_seq_id
                                                                               FROM icd_pcs_detail b
                                                                               WHERE b.claim_seq_id = v_claim_seq_id);
            DELETE FROM icd_pcs_detail a WHERE a.claim_seq_id = v_claim_seq_id;

			
			DELETE FROM tpa_diagnosys_details d WHERE d.claim_seq_id = v_claim_seq_id;--koc decoupling
			
            IF v_prev_hosp_seq_id IS NULL THEN
              DELETE FROM clm_hospital_additional_dtl a WHERE a.clm_hosp_assoc_seq_id =
                       (SELECT b.clm_hosp_assoc_seq_id FROM clm_hospital_association b WHERE b.claim_seq_id = v_claim_seq_id);
            END IF;

          ELSE
            DELETE FROM associated_illness a WHERE a.claim_seq_id = v_claim_seq_id;
          END IF;
          -- --------------
          v_ctr := 0;
          IF v_prev_hosp_claim_seq_id IS NOT NULL THEN
            SELECT COUNT(1) INTO v_ctr
              FROM clm_general_details a JOIN clm_enroll_details b ON (a.claim_seq_id = b.claim_seq_id)
              JOIN clm_hospital_association c ON (a.claim_seq_id = c.claim_seq_id)
              WHERE a.claim_seq_id = v_prev_hosp_claim_seq_id AND
               b.member_seq_id = v_member_seq_id
               AND ( c.hosp_seq_id = v_hosp_seq_id  OR c.hosp_seq_id IS NULL AND v_hosp_seq_id IS NULL)
               AND a.date_of_admission = v_date_of_admission AND a.date_of_discharge = v_date_of_discharge;
            IF v_ctr > 0 THEN
              do_insert_ailments( v_claim_seq_id , v_prev_hosp_claim_seq_id , v_added_by );
            ELSE
              v_prev_hosp_claim_seq_id := NULL;
            END IF;
          END IF;
          SELECT a.event_seq_id INTO v_coding_event_seq_id
             FROM tpa_event a JOIN tpa_workflow b ON (a.workflow_seq_id = b.workflow_seq_id)
             WHERE b.sub_general_type_id = 'CLM' AND a.event_owner = 'C';
--        END IF;
        IF v_coding_event_seq_id < v_event_seq_id THEN
          return_clm_to_coding(v_claim_seq_id,v_event_seq_id);
        END IF;
        v_claim_file_number := NULL;
      END IF;


      IF v_claim_file_number IS NULL THEN
        IF v_parent_claim_seq_id IS NOT NULL THEN
          SELECT a.claim_file_number  INTO v_claim_file_number
            FROM clm_general_details a WHERE a.claim_seq_id = v_parent_claim_seq_id ;
        ELSIF v_prev_hosp_claim_seq_id IS NOT NULL THEN
          SELECT a.claim_file_number  INTO v_claim_file_number
            FROM clm_general_details a WHERE a.claim_seq_id = v_prev_hosp_claim_seq_id ;
        ELSIF v_claim_general_type_id = 'CTM' THEN
           OPEN file_no_cur;
           FETCH file_no_cur INTO v_claim_file_number,v_prev_hosp_claim_seq_id;
           CLOSE file_no_cur;
        END IF;
        IF v_claim_file_number IS NOT NULL THEN
          v_original_yn  := 'N';
        END IF;
      END IF;


      IF v_claim_file_number IS NULL THEN
        IF v_policy_seq_id IS NOT NULL THEN -- Getting tpa_officeseq_id  of the policy
          SELECT a.tpa_office_seq_id INTO v_tpa_office_seq_id
             FROM tpa_enr_policy a WHERE a.policy_seq_id = v_policy_seq_id ;
        ELSE
          SELECT a.tpa_office_seq_id INTO v_tpa_office_seq_id
             FROM clm_inward a WHERE a.claims_inward_seq_id = v_claims_inward_seq_id;
        END IF;
        v_claim_file_number := pre_auth_pkg.generate_id_numbers('FL', v_tpa_office_seq_id , NULL, v_added_by );
        v_original_yn := 'Y';
      END IF;

      IF v_member_seq_id != v_prev_member_seq_id OR v_claim_file_number != nvl(v_old_claim_file_number,'NON')
        OR v_date_of_admission != v_prev_date_of_admission OR v_date_of_discharge != v_prev_date_of_discharge THEN

/*         SELECT A.event_seq_id INTO v_first_event_seq_id
           FROM tpa_event a JOIN tpa_workflow b ON (a.workflow_seq_id = b.workflow_seq_id)
           WHERE b.sub_general_type_id = 'CLM' AND a.order_number = 1;*/

        --IF  v_event_seq_id > v_first_event_seq_id THEN
          IF  v_last_buffer_detail_seq_id IS NOT NULL THEN
            pre_auth_pkg.delete_buffer_record(NULL ,v_claim_seq_id,v_prev_member_seq_id ,v_policy_sub_general_type_id,v_added_by );
          END IF;
          -- checking and resetting the cash benefit info for the claim
          IF v_clm_cash_benefit_seq_id IS NOT NULL THEN
            DELETE FROM clm_cash_benefit a WHERE a.clm_cash_benefit_seq_id = v_clm_cash_benefit_seq_id;
            v_clm_cash_benefit_seq_id := NULL;
            check_cash_benefit(v_clm_cash_benefit_seq_id,v_claim_seq_id,v_member_seq_id,v_claim_file_number,v_date_of_admission,v_date_of_discharge, v_added_by );
          END IF;
        --END IF;
      END IF;


      IF v_prev_sub_general_type_id != 'CSD' AND v_claim_sub_general_type_id = 'CSD' OR
         v_prev_sub_general_type_id != 'HCU' AND v_claim_sub_general_type_id = 'HCU' THEN

        DELETE FROM clm_hospital_additional_dtl a WHERE a.clm_hosp_assoc_seq_id =
          (SELECT b.clm_hosp_assoc_seq_id FROM clm_hospital_association b WHERE b.claim_seq_id = v_claim_seq_id );
        DELETE FROM clm_hospital_association a WHERE a.claim_seq_id = v_claim_seq_id ;
        unassoc_claim_intimation(v_claim_seq_id,null,v_added_by,v_rows_processed);--KOC1349
      ELSIF v_prev_sub_general_type_id != 'HCU' AND v_claim_sub_general_type_id = 'HCU' THEN
        DELETE FROM associated_illness a WHERE a.claim_seq_id = v_claim_seq_id;
        DELETE FROM ailment_details a WHERE a.claim_seq_id = v_claim_seq_id;
      END IF;
      --REASSIGN CLAIM
      pre_auth_pkg.reassign_user (  NULL , v_claim_seq_id ,NULL , v_added_by , 'AUT');

      UPDATE clm_general_details SET
        claim_file_number                       = v_claim_file_number,
        requested_amount                        = v_requested_amount,
        original_yn                             = v_original_yn,
        pat_enroll_detail_seq_id                = v_pat_enroll_detail_seq_id,
        auth_number                             = v_auth_number,
        pat_approved_amount                     = v_pat_approved_amount,
        request_general_type_id                 = v_request_general_type_id,
        claim_sub_general_type_id               = v_claim_sub_general_type_id,
        DOM_REASON_GEN_TYPE_ID                  = v_reason_for_dom,--koc1285
        DOC_CERT_DOM_YN                         = v_doctor_certified_yn,--koc1285
        call_log_seq_id                         = v_call_log_seq_id,
        mode_general_type_id                    = v_mode_general_type_id,
        treating_dr_name                        = v_treating_dr_name,
        in_patient_no                           = v_in_patient_no,
        claims_remarks                          = v_claims_remarks,
        discrepancy_present_yn                  = NVL(v_discrepancy_present_yn , NVL(discrepancy_present_yn,'N')),
        date_of_admission                       = v_date_of_admission,
        date_of_discharge                       = v_date_of_discharge,
        prev_hosp_claim_seq_id                  = v_prev_hosp_claim_seq_id,
        claim_dms_reference_id                  = NVL( v_claim_dms_reference_id, v_claim_number ),
        validation_status                       = 'U',
        re_open_type                            = v_re_open_type,
        rule_execution_flag                     = NULL,
        clm_cash_benefit_seq_id                 = v_clm_cash_benefit_seq_id ,
        doctor_registration_no                  = v_doctor_registration_no ,
        updated_by                              = v_added_by,
        updated_date                            = SYSDATE,
        co_payment_amount                       = 0, --for IBM copay
        co_payment_buffer_amount                = 0, ---KOCIBM
        copay_rest_amt                          = null,
        insur_ref_number                        = v_insur_ref_number,
		    pay_to_general_type_id                  = CASE WHEN v_claim_sub_general_type_id ='OPD' THEN v_pay_to_general_type_id ELSE 'MBR' END--opdforhs
        WHERE claim_seq_id = v_claim_seq_id;
    END IF;

    IF v_pat_enroll_detail_seq_id IS NOT NULL AND v_parent_claim_seq_id IS NULL THEN
      UPDATE pat_enroll_details A SET
        a.claim_id  = v_claim_seq_id
        WHERE a.pat_enroll_detail_seq_id = v_pat_enroll_detail_seq_id
         AND (a.claim_id IS NULL OR a.claim_id = v_claim_seq_id )
         AND 1 =
          ( SELECT COUNT(1)
             FROM pat_general_details b
                 WHERE b.pat_enroll_detail_seq_id = v_pat_enroll_detail_seq_id
                 AND b.completed_yn = 'Y' AND b.pat_enhanced_yn = 'N') ;

      IF SQL%ROWCOUNT = 0 THEN
        raise_application_error(-20182,'Associated Preauth is overridden/re-associated to another claim, please re-associate preauth.');
      END IF ;
    END IF;
  END save_general_details;

-- =================================================================================================================
  PROCEDURE save_claim (
    -- CLM_ENROLL_DETAILS
    v_clm_enroll_detail_seq_id           IN  OUT CLM_ENROLL_DETAILS.clm_enroll_detail_seq_id%TYPE,
    v_claim_seq_id                       IN  OUT CLM_ENROLL_DETAILS.claim_seq_id%TYPE,
    v_gender_general_type_id             IN  CLM_ENROLL_DETAILS.gender_general_type_id%TYPE,
    v_member_seq_id                      IN  CLM_ENROLL_DETAILS.member_seq_id%TYPE,
    v_tpa_enrollment_id                  IN  CLM_ENROLL_DETAILS.tpa_enrollment_id%TYPE,
    v_policy_seq_id                      IN  CLM_ENROLL_DETAILS.policy_seq_id%TYPE,
    v_policy_holder_name                 IN  CLM_ENROLL_DETAILS.policy_holder_name%TYPE,
    v_employee_no                        IN  CLM_ENROLL_DETAILS.employee_no%TYPE,
    v_employee_name                      IN  CLM_ENROLL_DETAILS.employee_name%TYPE,
    v_mem_age                            IN  CLM_ENROLL_DETAILS.mem_age%TYPE,
    v_claimant_name                      IN  CLM_ENROLL_DETAILS.claimant_name%TYPE,
    v_date_of_inception                  IN  CLM_ENROLL_DETAILS.date_of_inception%TYPE,
    v_date_of_exit                       IN  CLM_ENROLL_DETAILS.date_of_exit%TYPE,
    v_relship_type_id                    IN  CLM_ENROLL_DETAILS.relship_type_id%TYPE,
    v_policy_number                      IN  CLM_ENROLL_DETAILS.policy_number%TYPE,
    v_claimant_phone_number              IN  CLM_ENROLL_DETAILS.claimant_phone_number%TYPE,
    v_mem_total_sum_insured              IN  CLM_ENROLL_DETAILS.mem_total_sum_insured%TYPE,
    v_enrol_type_id                      IN  CLM_ENROLL_DETAILS.enrol_type_id%TYPE,
    v_policy_sub_general_type_id         IN  CLM_ENROLL_DETAILS.policy_sub_general_type_id%TYPE,
    v_phone_1                            IN  CLM_ENROLL_DETAILS.phone_1%TYPE,
    v_policy_effective_from              IN  CLM_ENROLL_DETAILS.policy_effective_from%TYPE,
    v_policy_effective_to                IN  CLM_ENROLL_DETAILS.policy_effective_to%TYPE,
    v_ins_status_general_type_id         IN  CLM_ENROLL_DETAILS.ins_status_general_type_id%TYPE,
    v_ins_seq_id                         IN  CLM_ENROLL_DETAILS.ins_seq_id%TYPE,
    v_group_reg_seq_id                   IN  CLM_ENROLL_DETAILS.group_reg_seq_id%TYPE,
-----CLM_GENERAL_DETAILS
    v_claims_inward_seq_id               IN  CLM_GENERAL_DETAILS.claims_inward_seq_id%TYPE,
    v_requested_amount                   IN  CLM_GENERAL_DETAILS.requested_amount%TYPE,
    v_pat_enroll_detail_seq_id           IN  CLM_GENERAL_DETAILS.pat_enroll_detail_seq_id%TYPE,
    v_auth_number                        IN  CLM_GENERAL_DETAILS.auth_number%TYPE,
    v_request_general_type_id            IN  CLM_GENERAL_DETAILS.request_general_type_id%TYPE,
    v_claim_sub_general_type_id          IN  CLM_GENERAL_DETAILS.claim_sub_general_type_id%TYPE,
    v_reason_for_dom                     IN  clm_general_details.DOM_REASON_GEN_TYPE_ID%type,--KOC1285
    v_doctor_certified_YN                IN  CLM_GENERAL_DETAILS.DOC_CERT_DOM_YN%type,--KOC1285
    v_mode_general_type_id               IN  CLM_GENERAL_DETAILS.mode_general_type_id%TYPE,
    v_treating_dr_name                   IN  CLM_GENERAL_DETAILS.treating_dr_name%TYPE,
    v_in_patient_no                      IN  CLM_GENERAL_DETAILS.in_patient_no%TYPE,
    v_claims_remarks                     IN  CLM_GENERAL_DETAILS.claims_remarks%TYPE,
    v_ava_sum_insured                    IN  OUT CLM_GENERAL_DETAILS.ava_sum_insured%TYPE,
    v_ava_cum_bonus                      IN  OUT CLM_GENERAL_DETAILS.ava_cum_bonus%TYPE,
    v_date_of_admission                  IN  CLM_GENERAL_DETAILS.date_of_admission%TYPE,
    v_date_of_discharge                  IN  CLM_GENERAL_DETAILS.date_of_discharge%TYPE,
    v_parent_claim_seq_id                IN  OUT CLM_GENERAL_DETAILS.parent_claim_seq_id%TYPE,
----CLM_HOSPITAL_ASSOCIATION
    v_clm_hosp_assoc_seq_id              IN  OUT CLM_HOSPITAL_ASSOCIATION.clm_hosp_assoc_seq_id%TYPE,
    v_hosp_seq_id                        IN  CLM_HOSPITAL_ASSOCIATION.hosp_seq_id%TYPE,
    v_empanel_number                     IN  CLM_HOSPITAL_ASSOCIATION.empanel_number%TYPE,
    v_hosp_name                          IN  OUT CLM_HOSPITAL_ASSOCIATION.hosp_name%TYPE,
    v_address_1                          IN  OUT CLM_HOSPITAL_ASSOCIATION.address_1%TYPE,
    v_address_2                          IN  OUT CLM_HOSPITAL_ASSOCIATION.address_2%TYPE,
    v_address_3                          IN  OUT CLM_HOSPITAL_ASSOCIATION.address_3%TYPE,
    v_state_name                         IN  OUT CLM_HOSPITAL_ASSOCIATION.state_name%TYPE,
    v_city_name                          IN  OUT CLM_HOSPITAL_ASSOCIATION.city_name%TYPE,
    v_pin_code                           IN  OUT CLM_HOSPITAL_ASSOCIATION.pin_code%TYPE,
    v_off_phone_no_1                     IN  OUT CLM_HOSPITAL_ASSOCIATION.off_phone_no_1%TYPE,
    v_off_phone_no_2                     IN  OUT CLM_HOSPITAL_ASSOCIATION.off_phone_no_2%TYPE,
    v_office_fax_no                      IN  OUT CLM_HOSPITAL_ASSOCIATION.office_fax_no%TYPE,
    v_remarks                            IN  CLM_HOSPITAL_ASSOCIATION.remarks%TYPE,
    v_serv_tax_rgn_number                IN  CLM_HOSPITAL_ASSOCIATION.serv_tax_rgn_number%TYPE,
-----CLM_HOSPITAL_ADDITIONAL_DTL
    v_prev_hosp_claim_seq_id             IN  OUT CLM_GENERAL_DETAILS.prev_hosp_claim_seq_id%TYPE,
    v_claim_dms_reference_id             IN  CLM_GENERAL_DETAILS.claim_dms_reference_id%TYPE,
    v_pat_approved_amount                IN  CLM_GENERAL_DETAILS.pat_approved_amount%TYPE,
    v_re_open_type                       IN  CLM_GENERAL_DETAILS.re_open_type%TYPE,
    v_doctor_registration_no             IN  CLM_GENERAL_DETAILS.doctor_registration_no%TYPE,
    v_email_id                           IN  CLM_ENROLL_DETAILS.email_id%TYPE,
    v_notification_phone_number          IN  CLM_ENROLL_DETAILS.notification_phone_number%TYPE,
    v_ins_scheme                         IN  PAT_ENROLL_DETAILS.ins_scheme%TYPE,
    v_certificate_no                     IN  PAT_ENROLL_DETAILS.certificate_no%TYPE,
    v_ins_customer_code                  IN  PAT_ENROLL_DETAILS.ins_customer_code%TYPE,
    v_insur_ref_number                   IN  CLM_GENERAL_DETAILS.Insur_Ref_Number%TYPE, --insur-ref-number
	v_pay_to_general_type_id             IN  CLM_GENERAL_DETAILS.PAY_TO_GENERAL_TYPE_ID%TYPE,--opdforhs
    v_added_by                           IN  CLM_HOSPITAL_ADDITIONAL_DTL.added_by%TYPE,
    v_rows_processed                     IN  OUT NUMBER,
    v_last_buffer_detail_seq_id          IN  buffer_details.buff_detail_seq_id%TYPE := NULL,
    v_parent_modif_mode_value            IN  CLM_ENROLL_DETAILS.modification_mode_value%TYPE := NULL
  )
  IS
    v_last_buff_detail_seq_id            buffer_details.buff_detail_seq_id%TYPE := v_last_buffer_detail_seq_id;
    v_discrepancy_present_yn             CLM_GENERAL_DETAILS.discrepancy_present_yn%TYPE;
    v_claim_settlement_number            CLM_GENERAL_DETAILS.claim_settlement_number%TYPE;
    v_call_log_seq_id                    CLM_GENERAL_DETAILS.call_log_seq_id%TYPE;
    v_data_discrepancy_present_yn        CHAR(1) := 'N';

    dis_name_yn                          CHAR(1);
    dis_gend_yn                          CHAR(1);
    dis_age_yn                           CHAR(1);
    dis_policy_num_yn                    CHAR(1);
    dis_policy_holder_yn                 CHAR(1);
    v_call_type                          VARCHAR2(3):= 'EXT';
    v_document_general_type_id           clm_inward.document_general_type_id%TYPE;
    v_tpa_office_seq_id                  clm_inward.tpa_office_seq_id%TYPE;
    v_claim_general_type_id              clm_inward.claim_general_type_id%TYPE;
    v_prev_member_seq_id                 clm_enroll_details.member_seq_id%TYPE;
    v_check_member_seq_id                tpa_enr_policy_member.member_seq_id%TYPE;
    v_modification_mode_value            pat_enroll_details.modification_mode_value%TYPE;
    v_change_mode_value                  pat_enroll_details.modification_mode_value%TYPE;
    v_effective_from_date                tpa_enr_policy.effective_from_date%TYPE;
    v_effective_to_date                  tpa_enr_policy.effective_to_date%TYPE;
    v_prev_policy_number                 tpa_enr_policy.policy_number%TYPE;
    v_prev_date_of_exit                  tpa_enr_policy_member.date_of_exit%TYPE;
    v_old_prev_hosp_claim_seq_id         CLM_GENERAL_DETAILS.prev_hosp_claim_seq_id%TYPE; -- patchtogo
    v_event_seq_id                       CLM_GENERAL_DETAILS.event_seq_id%TYPE;
    CURSOR pat_cur IS SELECT a.member_seq_id
      FROM pat_enroll_details a WHERE a.pat_enroll_detail_seq_id = v_pat_enroll_detail_seq_id ;

    CURSOR prev_claim_cur (v_claim_seq_id NUMBER ) IS SELECT a.member_seq_id
      FROM clm_enroll_details a WHERE a.claim_seq_id = v_claim_seq_id ;

    CURSOR prev_hosp_cur IS
       SELECT hosp_regist_number, contact_name,  off_phone_no_1,
          number_of_beds,     fully_equipped_yn,  v_added_by,   SYSDATE
          FROM clm_hospital_additional_dtl a
          WHERE a.clm_hosp_assoc_seq_id = ( SELECT b.clm_hosp_assoc_seq_id FROM clm_hospital_association b
                                            WHERE b.claim_seq_id = v_prev_hosp_claim_seq_id );

    CURSOR hosp_additional_dtl_cur IS
      SELECT a.add_hosp_dtl_seq_id FROM clm_hospital_additional_dtl a
        WHERE a.clm_hosp_assoc_seq_id = v_clm_hosp_assoc_seq_id ;

    CURSOR mem_info_cur IS SELECT a.date_of_inception,a.date_of_exit,c.effective_from_date
      ,c.effective_to_date, c.policy_number ,nvl(a.mem_tot_sum_insured,b.floater_sum_insured) AS mem_tot_sum_insured,
      c.policy_sub_general_type_id
      FROM tpa_enr_policy_member a JOIN tpa_enr_policy_group b ON (a.policy_group_seq_id = b.policy_group_seq_id)
      JOIN tpa_enr_policy c ON (b.policy_seq_id = c.policy_seq_id)
      WHERE a.member_seq_id = v_member_seq_id;

    mem_info_rec                            mem_info_cur%ROWTYPE;
    prev_hosp_rec                           prev_hosp_cur%ROWTYPE;
    v_add_hosp_dtl_seq_id                   clm_hospital_additional_dtl.add_hosp_dtl_seq_id%TYPE;
    v_rcvd_date                             clm_inward.rcvd_date%TYPE;
    v_ctr                                   PLS_INTEGER;
  BEGIN

  claims_freeze(v_claim_seq_id,NULL,'S'); --KOCBJJ
    IF NVL( v_claim_seq_id ,0) != 0  THEN
       SELECT CASE WHEN nvl(ce.member_seq_id,0) = nvl(v_member_seq_id,0) THEN cg.call_log_seq_id
              ELSE NULL END INTO v_call_log_seq_id
       FROM clm_enroll_details ce INNER JOIN clm_general_details cg ON ce.claim_seq_id = cg.claim_seq_id
       AND ce.claim_seq_id = v_claim_seq_id;
         IF v_call_log_seq_id IS NULL THEN
            unassoc_claim_intimation(v_claim_seq_id,v_call_log_seq_id,v_added_by,v_rows_processed);--KOC1349
         END IF;
    END IF;


    IF NVL( v_claim_seq_id ,0) = 0  THEN
      SELECT a.document_general_type_id, A.tpa_office_seq_id , a.claim_general_type_id ,a.rcvd_date
        INTO v_document_general_type_id , v_tpa_office_seq_id , v_claim_general_type_id ,v_rcvd_date
        FROM clm_inward a WHERE a.claims_inward_seq_id = v_claims_inward_seq_id ;

      IF v_document_general_type_id = 'DTA' THEN
        v_call_type := 'INT';
      END IF;
    ELSE
      --locking CLAIM
      TTK_UTIL_PKG.reset_id_flag(v_claim_seq_id||'-CLM','Y');
      --reassigning user
      pre_auth_pkg.reassign_user (  NULL , v_claim_seq_id ,NULL , v_added_by , 'AUT');

      SELECT a.parent_claim_seq_id, b.member_seq_id, a.last_buffer_detail_seq_id , b.modification_mode_value ,
        c.effective_from_date, c.effective_to_date,c.policy_number , A.prev_hosp_claim_seq_id , d.date_of_exit, e.rcvd_date ,
        a.event_seq_id
        INTO v_parent_claim_seq_id, v_prev_member_seq_id , v_last_buff_detail_seq_id  , v_modification_mode_value,
        v_effective_from_date,v_effective_to_date,v_prev_policy_number , v_old_prev_hosp_claim_seq_id ,v_prev_date_of_exit ,v_rcvd_date ,
        v_event_seq_id
        FROM clm_general_details a JOIN clm_enroll_details b ON (a.claim_seq_id = b.claim_seq_id)
        LEFT OUTER JOIN tpa_enr_policy c ON (b.policy_seq_id = c.policy_seq_id)
        LEFT OUTER JOIN tpa_enr_policy_member d ON ( b.member_seq_id = d.member_seq_id )
        JOIN clm_inward e ON (a.claims_inward_seq_id = e.claims_inward_seq_id)
        WHERE a.claim_seq_id = v_claim_seq_id ;
    END IF;

    IF v_modification_mode_value > 0 THEN

      OPEN mem_info_cur;
      FETCH mem_info_cur INTO mem_info_rec;
      CLOSE mem_info_cur;

      IF v_policy_effective_from = mem_info_rec.effective_from_date
            AND v_policy_effective_to = mem_info_rec.effective_to_date
            AND v_policy_number = mem_info_rec.policy_number
            AND v_date_of_exit = mem_info_rec.date_of_exit
            AND nvl(v_mem_total_sum_insured,0) = nvl(mem_info_rec.mem_tot_sum_insured,0)
            AND v_policy_sub_general_type_id = mem_info_rec.policy_sub_general_type_id THEN

        IF policy_enrollment_pkg.check_enrollment_change ( v_modification_mode_value,  2)> 0 THEN
            v_change_mode_value := nvl(v_change_mode_value,0) + 2 ;
        END IF;
        IF policy_enrollment_pkg.check_enrollment_change ( v_modification_mode_value,  8) > 0 THEN
           v_change_mode_value := nvl(v_change_mode_value,0) + 8 ;
        END IF;

        IF policy_enrollment_pkg.check_enrollment_change ( v_modification_mode_value,  32)> 0 THEN
            v_change_mode_value := nvl(v_change_mode_value,0) + 32 ;
        END IF;

        IF policy_enrollment_pkg.check_enrollment_change ( v_modification_mode_value,  64) > 0 THEN
           v_change_mode_value := nvl(v_change_mode_value,0) + 64 ;
        END IF;

        IF trunc(v_date_of_admission) BETWEEN greatest(v_policy_effective_from, v_date_of_inception) AND v_date_of_exit THEN

          IF policy_enrollment_pkg.check_enrollment_change ( v_modification_mode_value, 1) > 0 THEN
            v_change_mode_value := nvl(v_change_mode_value,0) + 1 ;
          END IF;
          IF policy_enrollment_pkg.check_enrollment_change ( v_modification_mode_value, 4) > 0 THEN
            v_change_mode_value := nvl(v_change_mode_value,0) + 4 ;
          END IF;
        END IF;
      END IF;
    END IF;

    IF NVL( v_claim_seq_id ,0) != 0  THEN
      pre_auth_pkg.check_clm_completed ( v_claim_seq_id , NULL,'APP', v_added_by );
    END IF;
    IF v_pat_enroll_detail_seq_id IS NOT NULL THEN
      OPEN pat_cur;
      FETCH pat_cur INTO v_check_member_seq_id;
      CLOSE pat_cur;
      IF nvl(v_member_seq_id,0) != nvl(v_check_member_seq_id,0) THEN
        raise_application_error(-20197,'Member selected for Preauth and that of Claim are different');
      END IF;
      -- if preauth was previously associated to another claim,
      -- this part is to delete buffer records of the previous claim
      IF NVL( v_claim_seq_id ,0) = 0 AND v_parent_claim_seq_id IS NULL THEN

        SELECT COUNT(1) INTO v_ctr
           FROM clm_general_details a JOIN clm_enroll_details b ON (a.claim_seq_id = b.claim_seq_id)
           WHERE a.pat_enroll_detail_seq_id = v_pat_enroll_detail_seq_id
           AND ( a.completed_yn = 'N' OR b.clm_status_general_type_id NOT IN ('REJ','PCO'));
        IF v_ctr > 0 THEN
          raise_application_error(-20182,'Associated Preauth is overridden/re-associated to another claim, please re-associate preauth.');
        END IF;

        FOR rec IN (SELECT a.claim_seq_id FROM clm_general_details a
                     WHERE a.pat_enroll_detail_seq_id = v_pat_enroll_detail_seq_id
                     ORDER BY a.claim_seq_id DESC)
        LOOP
          pre_auth_pkg.delete_claim_buffer(rec.claim_seq_id);
        END LOOP;
      END IF;
    END IF;

    IF v_parent_claim_seq_id IS NULL THEN
      IF v_member_seq_id IS NOT NULL THEN
          pre_auth_pkg.check_discrepancy(
                  v_member_seq_id ,
                  v_claimant_name,
                  v_mem_age  ,
                  v_gender_general_type_id  ,
                  v_policy_holder_name  ,
                  v_policy_number  ,
                  dis_name_yn ,
                  dis_gend_yn ,
                  dis_age_yn ,
                  dis_policy_num_yn ,
                  dis_policy_holder_yn );
        IF dis_name_yn = 'Y' OR  dis_gend_yn = 'Y' OR  dis_age_yn = 'Y' OR   dis_policy_num_yn = 'Y' OR  dis_policy_holder_yn = 'Y' THEN
          v_data_discrepancy_present_yn := 'Y';
        END IF;
      END IF;

      check_conflict (
              v_claim_seq_id ,
              v_clm_enroll_detail_seq_id ,
              v_policy_seq_id ,
              v_enrol_type_id  ,
              v_tpa_enrollment_id  ,
              v_group_reg_seq_id  ,
              v_employee_no  ,
              v_hosp_seq_id  ,
              v_policy_effective_from ,
              v_policy_effective_to ,
              v_date_of_admission  ,
              v_requested_amount  ,
              v_date_of_discharge,
              v_rcvd_date,
              v_data_discrepancy_present_yn ,
              v_discrepancy_present_yn ,
              v_added_by  ,
              v_member_seq_id
            );
    ELSE
      OPEN prev_claim_cur(v_parent_claim_seq_id);
      FETCH prev_claim_cur INTO v_check_member_seq_id;
      CLOSE prev_claim_cur;
      IF v_member_seq_id != v_check_member_seq_id THEN
        raise_application_error(-20198,'Member selected for this ammendment and previous claim are different');
      END IF;
      IF NVL(v_claim_seq_id,0) = 0 THEN
        SELECT discrepancy_present_yn INTO v_discrepancy_present_yn
           FROM clm_general_details a
          WHERE a.claim_seq_id = v_parent_claim_seq_id ;
      END IF;
    END IF;
    IF v_prev_hosp_claim_seq_id IS NOT NULL THEN
      OPEN prev_claim_cur(v_prev_hosp_claim_seq_id);
      FETCH prev_claim_cur INTO v_check_member_seq_id;
      CLOSE prev_claim_cur;
      IF v_member_seq_id != v_check_member_seq_id THEN
        raise_application_error(-20199,'Member selected for this claim and previous hospitalisation are different');
      END IF;
    END IF;

    save_general_details(
        v_claim_seq_id  ,
        v_claims_inward_seq_id  ,
        v_member_seq_id ,
        v_requested_amount  ,
        v_pat_enroll_detail_seq_id ,
        v_auth_number     ,
        v_pat_approved_amount ,
        v_request_general_type_id  ,
        v_claim_sub_general_type_id ,
        v_reason_for_dom,--KOC1285
        v_doctor_certified_YN,--KOC1285
        v_call_log_seq_id   ,
        v_mode_general_type_id  ,
        v_treating_dr_name   ,
        v_in_patient_no    ,
        v_claims_remarks   ,
        NULL  ,
        NULL  ,
        NULL  ,
        v_discrepancy_present_yn  ,
        v_date_of_admission   ,
        v_date_of_discharge    ,
        v_parent_claim_seq_id   ,
        v_claim_settlement_number  ,
        v_prev_hosp_claim_seq_id ,
        v_hosp_seq_id,
        v_claim_dms_reference_id ,
        v_policy_seq_id ,
        v_re_open_type ,
        v_doctor_registration_no,
        v_insur_ref_number, --insur-ref-number
        v_last_buff_detail_seq_id,
		    v_pay_to_general_type_id,--opdforhs
        v_added_by        ,
        v_rows_processed
      );

     save_clm_enroll(
        v_clm_enroll_detail_seq_id  ,
        v_claim_seq_id   ,
        v_gender_general_type_id ,
        v_member_seq_id ,
        v_tpa_enrollment_id ,
        v_policy_seq_id  ,
        v_policy_holder_name ,
        v_employee_no  ,
        v_employee_name  ,
        v_mem_age  ,
        v_claimant_name ,
        v_date_of_inception  ,
        v_date_of_exit  ,
        v_relship_type_id  ,
        v_policy_number  ,
        v_claimant_phone_number ,
        v_mem_total_sum_insured ,
        v_enrol_type_id  ,
        v_policy_sub_general_type_id ,
        v_phone_1   ,
        v_policy_effective_from  ,
        v_policy_effective_to  ,
        v_ins_status_general_type_id ,
        v_ins_seq_id     ,
        v_group_reg_seq_id ,
        v_email_id ,
        v_notification_phone_number,
        v_ins_scheme,
        v_certificate_no,
        v_ins_customer_code,
        v_added_by        ,
        v_rows_processed  ,
        v_change_mode_value,
        v_parent_modif_mode_value
        );

    IF v_claim_sub_general_type_id NOT IN ('CSD','HCU') THEN -- ie No hospital details for Domociliary
      save_hospital_association (
          v_clm_hosp_assoc_seq_id ,
          v_claim_seq_id ,
          v_hosp_seq_id  ,
          v_empanel_number  ,
          v_hosp_name  ,
          v_address_1 ,
          v_address_2  ,
          v_address_3  ,
          v_state_name ,
          v_city_name ,
          v_pin_code  ,
          v_off_phone_no_1 ,
          v_off_phone_no_2 ,
          v_office_fax_no  ,
          v_remarks   ,
          v_serv_tax_rgn_number,
          v_added_by  ,
          v_rows_processed
        );

      IF v_prev_hosp_claim_seq_id IS NOT NULL AND v_hosp_seq_id IS NULL
        AND ( v_old_prev_hosp_claim_seq_id IS NULL OR v_old_prev_hosp_claim_seq_id !=  v_prev_hosp_claim_seq_id ) THEN

         OPEN hosp_additional_dtl_cur;
         FETCH hosp_additional_dtl_cur INTO v_add_hosp_dtl_seq_id;
         CLOSE hosp_additional_dtl_cur;

         OPEN  prev_hosp_cur;
         FETCH prev_hosp_cur INTO prev_hosp_rec;
         CLOSE prev_hosp_cur;

         v_add_hosp_dtl_seq_id := NVL(v_add_hosp_dtl_seq_id,0);

         save_hosp_additional_dtl(
            v_add_hosp_dtl_seq_id,
            v_clm_hosp_assoc_seq_id ,
            prev_hosp_rec.hosp_regist_number ,
            prev_hosp_rec.contact_name  ,
            prev_hosp_rec.off_phone_no_1 ,
            prev_hosp_rec.number_of_beds ,
            prev_hosp_rec.fully_equipped_yn ,
            v_added_by ,
            v_rows_processed
          );
      END IF;

    END IF;
    IF v_call_type = 'EXT' THEN
      COMMIT;
    END IF;
  END save_claim;

--=================================================================================================================
  PROCEDURE select_courier_list (
    v_courier_id                         IN  COURIER_DETAILS.courier_id %TYPE ,
    v_docket_number                      IN  COURIER_DETAILS.docket_number%TYPE ,
    v_courier_comp_seq_id                IN  COURIER_DETAILS.courier_comp_seq_id%TYPE ,
    v_start_date                         IN  VARCHAR2,
    v_end_date                           IN  VARCHAR2,
    v_sort_var                           IN  VARCHAR2  ,
    v_sort_order                         IN  VARCHAR2 := 'ASC',
    v_start_num                          IN  NUMBER   := 1,
    v_end_num                            IN  NUMBER   := 25,
    v_added_by                           IN  NUMBER,
    result_set                           OUT SYS_REFCURSOR
  )
  IS
    v_sql_str                            VARCHAR2(4000);
    v_from_date                          DATE := TO_DATE(v_start_date,'DD/MM/YYYY');
    v_to_date                            DATE := TO_DATE(v_end_date,'DD/MM/YYYY');
    v_where                              VARCHAR2(2000);
    TYPE bind_tab_type IS TABLE OF VARCHAR2(250) INDEX BY BINARY_INTEGER ;
    bind_tab                             bind_tab_type;
    i                                    NUMBER(2) := 0;
  BEGIN
    v_sql_str :=
     'SELECT
      A.courier_seq_id ,
      B.courier_comp_name ,
      A.courier_id ,
      A.doc_dispatch_rcvd_date,
      a.docket_number
      FROM courier_details A JOIN courier_company B ON (A.courier_comp_seq_id = B.courier_comp_seq_id) ';
      IF v_courier_id IS NOT NULL THEN
        v_where := v_where ||' AND A.courier_id  LIKE :v_courier_id';
        i := i+1;
        bind_tab(i) := UPPER(v_courier_id)||'%';
      END IF;
      IF v_courier_comp_seq_id IS NOT NULL THEN
        v_where := v_where ||' AND A.courier_comp_seq_id  = :v_courier_comp_seq_id ';
        i := i+1;
        bind_tab(i) := v_courier_comp_seq_id;
      END IF;
      IF v_start_date IS NOT NULL THEN
        v_where := v_where ||' AND A.doc_dispatch_rcvd_date >= :v_from_date ';
        i := i+1;
        bind_tab(i) := v_from_date;
      END IF;
      IF v_end_date IS NOT NULL THEN
        v_where := v_where ||' AND TRUNC(A.doc_dispatch_rcvd_date) <= :v_to_date ';
        i := i+1;
        bind_tab(i) := v_to_date;
      END IF;

       IF v_docket_number IS NOT NULL THEN
          v_where := v_where ||' AND A.docket_number  LIKE :v_docket_number ';
          i := i+1;
          bind_tab(i) := v_docket_number||'%';
      END IF;

      IF v_where IS NOT NULL THEN
        v_where := ' WHERE '|| SUBSTR(v_where,5);
        v_sql_str := v_sql_str ||v_where;
      END IF;

      v_sql_str := 'SELECT * FROM
          (SELECT A.*,DENSE_RANK() OVER (ORDER BY '||v_sort_var||' '||v_sort_order||',ROWNUM)
          Q FROM (' ||v_sql_str|| ') A ) WHERE  Q>= :v_start_num  AND Q<= :v_end_num ';

      IF bind_tab.FIRST IS NOT NULL THEN
        CASE bind_tab.COUNT
          WHEN 1  THEN OPEN result_set FOR v_sql_str USING bind_tab(1) , v_start_num , v_end_num ;
          WHEN 2  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2), v_start_num , v_end_num ;
          WHEN 3  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2) ,bind_tab(3) , v_start_num , v_end_num ;
          WHEN 4  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) , v_start_num , v_end_num ;
          WHEN 5  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5), v_start_num , v_end_num ;
        END CASE;
      ELSE
        OPEN result_set FOR v_sql_str USING v_start_num , v_end_num ;
      END IF;
  END select_courier_list;
--==============================================================================================
 --   Name       : select_bill_summary
 --   Created on : -11-JUL-06
 --   Created By : - S.V.SREERAJ
 --   Comments   :
 --==============================================================================================
  PROCEDURE select_bill_summary (
    v_claim_seq_id               IN  clm_bill_header.claim_seq_id%TYPE,
    v_added_by                   IN  NUMBER,
    summary_result_set           OUT SYS_REFCURSOR,
    bill_split                   OUT SYS_REFCURSOR,
    ailment_cur                  OUT SYS_REFCURSOR,
    v_req_amt_mismatch           OUT NUMBER  -- 0 -- matching , 1-- pat requested is > the bill requested. 2-- pat requested is < the bill requested.
  )
  IS
   CURSOR ail_cur IS SELECT COUNT(1) FROM icd_pcs_detail b
     WHERE b.claim_seq_id = v_claim_seq_id  AND trtmnt_plan_general_type_id IS NOT NULL;

   CURSOR request_amt_cur IS SELECT  CASE WHEN  a.requested_amount >  b.requested_amount THEN 1
             WHEN  a.requested_amount <  b.requested_amount THEN 2
             ELSE 0 END
     FROM clm_general_details a JOIN
     (SELECT b.claim_seq_id , SUM(c.requested_amount) AS requested_amount
      FROM  clm_bill_header b JOIN clm_bill_details c ON (b.clm_bill_seq_id = c.clm_bill_seq_id )
     WHERE b.claim_seq_id = v_claim_seq_id  AND nvl(b.bill_included_yn,'Y') = 'Y'  GROUP BY b.claim_seq_id) B ON ( a.claim_seq_id = b.claim_seq_id )
      WHERE b.claim_seq_id =  v_claim_seq_id ;

   v_ctr                         NUMBER(5);
  BEGIN
    OPEN request_amt_cur;
    FETCH request_amt_cur INTO v_req_amt_mismatch;
    CLOSE request_amt_cur;

    v_req_amt_mismatch := nvl(v_req_amt_mismatch,0);

    OPEN ail_cur;
    FETCH ail_cur INTO v_ctr;
    CLOSE ail_cur;

    IF v_ctr = 0 THEN
      raise_application_error( -20116, 'Enter Medical Details First');
    ELSE
      SELECT COUNT(1) INTO v_ctr
         FROM  clm_general_details a LEFT OUTER JOIN ailment_details B ON (a.claim_seq_id = b.claim_seq_id)
         WHERE a.claim_seq_id = v_claim_seq_id AND ( a.claim_sub_general_type_id != 'HCU' AND b.ailment_details_seq_id IS NOT NULL OR a.claim_sub_general_type_id = 'HCU');

      IF v_ctr = 0 THEN
         raise_application_error( -20191,'  Please enter Ailment information.');
      END IF;
    END IF;

    OPEN summary_result_set FOR
       SELECT ward_acc_group_seq_id, acc_group_name, ward_type_id , ward_description,
              CASE WHEN ward_type_id='STX' THEN NULL
              ELSE bill_amount END AS bill_amount,
              discount_percent, discount_apply,
              CASE WHEN ward_type_id='STX' THEN NULL
              ELSE net_amount END AS net_amount,
              CASE WHEN ward_type_id = 'ICU' THEN max_amount * line_ctr ELSE max_amount END AS max_amount,
              CASE WHEN net_amount >  max_amount THEN 'Invalid'
                   WHEN net_amount <=  max_amount THEN 'valid'
                   WHEN max_amount IS NULL THEN  'Not Calculated'  END AS NOTES
       FROM ( SELECT ward_acc_group_seq_id, acc_group_name, ward_type_id, ward_description, bill_amount,discount_percent,
                  CASE discount_apply WHEN 1 THEN 'Y' ELSE 'N' END AS discount_apply, line_ctr ,
                  CASE discount_apply WHEN 1 THEN ( bill_amount * discount_percent )/100 ELSE bill_amount END  AS net_amount,  max_amount
                     FROM (  SELECT D.acc_group_name, D.ward_acc_group_seq_id, E.ward_type_id,E.ward_description, sum(b.allowed_amount) AS bill_amount , SUM( discount_percnt)/COUNT(*) AS discount_percent,
                               SUM( CASE WHEN apply_discount_yn = 'Y' THEN 1 ELSE 0 END )/COUNT(*) discount_apply , COUNT(*) AS line_ctr ,
                               SUM( b.ward_max_amount )/COUNT(*) AS max_amount
                                 FROM clm_bill_header A INNER JOIN clm_bill_details B ON ( A.clm_bill_seq_id = b.clm_bill_seq_id )
                                 INNER JOIN prod_ward_groupings C ON ( B.ward_type_id = C.ward_type_id )
                                 INNER JOIN ward_account_group D ON ( C.ward_acc_group_seq_id = D.ward_acc_group_seq_id AND D.group_show_type = 'IRD')
                                 INNER JOIN tpa_hosp_ward_code E ON ( C.ward_type_id = E.ward_type_id )
                                 INNER JOIN clm_enroll_details F ON (a.claim_seq_id = f.claim_seq_id)
                          WHERE A.claim_seq_id =  v_claim_seq_id AND a.bill_included_yn = 'Y' -- AND a.bill_date >= NVL(f.date_of_inception , a.bill_date ) AND a.bill_date <= NVL(f.date_of_exit, a.bill_date )
                          GROUP BY D.acc_group_name,D.ward_acc_group_seq_id,E.ward_type_id,E.ward_description
                          ORDER BY D.acc_group_name,E.ward_description
                          )
              );

    OPEN bill_split FOR
       SELECT SUM ( CASE WHEN TRUNC(A.bill_date) < TRUNC(C.date_of_admission) AND B.Ward_Type_Id!='STX' THEN B.ALLOWED_AMOUNT END ) AS  PreHospitalisation ,
               SUM ( CASE WHEN TRUNC(A.bill_date) BETWEEN TRUNC(C.date_of_admission) AND TRUNC(C.date_of_discharge) AND B.Ward_Type_Id!='STX' THEN B.allowed_amount END) AS Hospitalisation,
               SUM ( CASE WHEN TRUNC(A.bill_date) > TRUNC(C.date_of_discharge)AND B.Ward_Type_Id!='STX' THEN B.allowed_amount END) AS PostHospitalisation
            FROM clm_bill_header A LEFT OUTER JOIN clm_bill_details B ON ( A.clm_bill_seq_id = B.clm_bill_seq_id )
                 INNER JOIN clm_general_details C ON ( A.claim_seq_id = C.claim_seq_id )
                 INNER JOIN clm_enroll_details F ON ( a.claim_seq_id = f.claim_seq_id)
           WHERE A.claim_seq_id = v_claim_seq_id  AND a.bill_included_yn = 'Y' ;-- a.bill_date >= NVL(f.date_of_inception , a.bill_date ) AND a.bill_date <= NVL(f.date_of_exit, a.bill_date ) ;

    OPEN ailment_cur FOR
      SELECT  b.ailment_caps_seq_id ,
         A.icd_pcs_seq_id,
         CASE WHEN C.ped_description IS NULL THEN 'Others - '||A.other_desc ELSE A.icd_code ||' - '||C.ped_description END AS ailment_desc ,
         a.primary_ailment_yn,
         b.maximum_allowed_amount ,
         b.approved_amount ,
         NVL(b.notes,'Not Calculated') notes
         FROM icd_pcs_detail a LEFT OUTER JOIN ailment_caps b ON (a.icd_pcs_seq_id = b.icd_pcs_seq_id)
         LEFT OUTER JOIN tpa_ped_code c ON (a.ped_code_id = c.ped_code_id )
         WHERE a.claim_seq_id = v_claim_seq_id;

  END select_bill_summary;
-- =================================================================================================================
  PROCEDURE select_clm_document (
    v_claim_seq_id                      IN CLM_DOCUMENTS_RCVD.claim_seq_id%TYPE,
    v_added_by                          IN NUMBER,
    v_result_set                        OUT SYS_REFCURSOR
  )
  IS

  BEGIN
    OPEN v_result_set FOR SELECT a.docu_list_type_id, a.docu_name, a.docu_categ_general_type_id, c.docu_rcvd_seq_id,
        c.sheets_count, C.doc_general_type_id, c.reason_general_type_id, c.remarks,
        CASE WHEN C.DOCU_RCVD_SEQ_ID IS NULL THEN 'N' ELSE 'Y' END  AS rcvd_yn  , B.description AS category
        FROM clm_document_list_code a JOIN  tpa_general_code B ON (a.docu_categ_general_type_id = B.general_type_id)
        LEFT OUTER JOIN clm_documents_rcvd c ON (a.docu_list_type_id = c.docu_list_type_id AND c.claim_seq_id = v_claim_seq_id )
        ORDER BY  3 ;
  END select_clm_document;
-- =================================================================================================================
  PROCEDURE get_account_limits(
    v_hosp_seq_id                              IN  NUMBER,
    v_policy_seq_id                            IN  NUMBER,
    v_product_seq_id                           IN  NUMBER,
    v_date_of_hospitalization                  IN  DATE,
    v_ward_type_id                             IN  VARCHAR2,
    v_room_type_id                             IN  VARCHAR2,
    v_cost                                     OUT NUMBER,
    v_discount                                 OUT NUMBER
  )
  IS

    v_prod_hosp_seq_id               TPA_INS_ASSOC_PROD_HOSP.prod_hosp_seq_id%TYPE;
    v_revised_plan_seq_id            TPA_HOSP_REVISED_PLAN.revised_plan_seq_id%TYPE;
    v_plan_seq_id                    TPA_HOSP_REVISED_PLAN.plan_seq_id%TYPE;


    CURSOR cor_policy_cur IS  -- Checking hospital association for the Corporate Policy
       SELECT B.prod_hosp_seq_id  FROM tpa_ins_prod_policy A JOIN tpa_ins_assoc_prod_hosp B ON (a.prod_policy_seq_id = b.prod_policy_seq_id)
       WHERE a.policy_seq_id = v_policy_seq_id  AND b.hosp_seq_id = v_hosp_seq_id ;

    CURSOR all_product_cur IS -- Checking hospital association for the Product
       SELECT B.prod_hosp_seq_id  FROM tpa_ins_prod_policy A JOIN tpa_ins_assoc_prod_hosp B ON (a.prod_policy_seq_id = b.prod_policy_seq_id)
       WHERE a.product_seq_id = v_product_seq_id  AND  b.hosp_seq_id = v_hosp_seq_id ;

   CURSOR hosp_cur IS  -- To get the informations of hospital if policy and product are not associated
       SELECT A.prod_hosp_seq_id  FROM tpa_ins_assoc_prod_hosp A
         WHERE  A.hosp_seq_id = v_hosp_seq_id AND A.prod_policy_seq_id IS NULL AND general_type_id = 'ART';

   CURSOR hosp_plan_pkg_cur IS -- To find out any plan exist for the hospital
       SELECT revised_plan_seq_id , plan_seq_id ,a.discount_offered_ttk  FROM tpa_hosp_revised_plan a
         WHERE prod_hosp_seq_id = v_prod_hosp_seq_id
         AND plan_from_date <= v_date_of_hospitalization ORDER BY plan_from_date DESC;

 BEGIN

   OPEN cor_policy_cur;
   FETCH cor_policy_cur INTO v_prod_hosp_seq_id ;  -- 2 Checking hospital association for the Corporate Policy
   CLOSE cor_policy_cur;

   IF v_prod_hosp_seq_id IS NULL THEN
     OPEN all_product_cur;
     FETCH all_product_cur INTO v_prod_hosp_seq_id ; -- 3 Checking hospital association for the Product
     CLOSE all_product_cur;
   END IF;

   IF v_prod_hosp_seq_id IS NULL THEN
     OPEN hosp_cur;
     FETCH hosp_cur INTO v_prod_hosp_seq_id ; -- 4 For Getting the Agreed rate of this hospital since not associated to policy or product
     CLOSE hosp_cur;
   END IF;

   OPEN hosp_plan_pkg_cur;
   FETCH hosp_plan_pkg_cur INTO v_revised_plan_seq_id , v_plan_seq_id , v_discount;
   CLOSE hosp_plan_pkg_cur;

   IF v_revised_plan_seq_id IS NOT NULL THEN
      calculate_cost (
          v_plan_seq_id,
          v_revised_plan_seq_id ,
          v_prod_hosp_seq_id  ,
          v_date_of_hospitalization,
          v_room_type_id,
          v_ward_type_id ,
          v_cost
        );
    END IF;

  END get_account_limits;
 --==============================================================================================
  PROCEDURE calculate_cost (
    v_plan_seq_id                       IN  TPA_HOSP_REVISED_PLAN.Plan_Seq_Id%TYPE,
    v_revised_plan_seq_id               IN  OUT TPA_HOSP_REVISED_PLAN.plan_seq_id%TYPE,
    v_prod_hosp_seq_id                  IN  TPA_HOSP_REVISED_PLAN.prod_hosp_seq_id%TYPE,
    v_date_of_hospitalization           IN  PAT_GENERAL_DETAILS.likely_date_of_hospitalization%TYPE,
    v_room_type_id                      IN  VARCHAR2,
    v_ward_type_id                      IN  VARCHAR2,
    v_cost                              OUT NUMBER
  )
  IS
    v_room_type                          VARCHAR2(3) := v_room_type_id;

    CURSOR pkg_cur IS
      SELECT pkg_seq_id
         FROM tpa_hosp_tariff_item A WHERE general_type_id = 'NPK' AND medical_package_yn = 'Y';

    CURSOR npk_cost IS  SELECT maximum_allowed_amount
         FROM npk_cost_temp  WHERE ward_type_id = v_ward_type_id AND room_type_id = v_room_type;

    v_pkg_seq_id                         tpa_hosp_tariff_item.pkg_seq_id%TYPE;

  BEGIN
     IF v_room_type IS NULL THEN
       v_room_type := 'GNW'; -- General Ward
     END IF;

     OPEN pkg_cur;
     FETCH pkg_cur INTO v_pkg_seq_id;
     CLOSE pkg_cur;

     get_pkg_cost (
         v_plan_seq_id ,
         v_revised_plan_seq_id ,
         v_prod_hosp_seq_id ,
         v_pkg_seq_id ,
         v_date_of_hospitalization ,
         v_room_type_id ,
         v_ward_type_id
      );

    OPEN npk_cost ;
    FETCH npk_cost INTO v_cost;
    CLOSE npk_cost;

    DELETE FROM npk_cost_temp;
  END calculate_cost;
 --==============================================================================================
   PROCEDURE get_pkg_cost (
     v_plan_seq_id               IN  INTEGER,
     v_revised_plan_seq_id       IN  OUT INTEGER,
     v_prod_hosp_seq_id          IN  INTEGER,
     v_pkg_seq_id                IN  INTEGER,
     v_date_of_hosp              IN  DATE,
     v_room_type                 IN  VARCHAR2,
     v_ward_type_id              IN  VARCHAR2
  )
  IS
    v_count                     INTEGER;

    CURSOR nill_cur IS SELECT  tpa_hosp_revised_plan.revised_plan_seq_id
         FROM tpa_hosp_revised_plan,    tpa_hosp_revised_packages
     WHERE ( tpa_hosp_revised_packages.revised_plan_seq_id = tpa_hosp_revised_plan.revised_plan_seq_id ) and
           ( tpa_hosp_revised_plan.plan_seq_id = v_plan_seq_id ) AND
           ( ( tpa_hosp_revised_plan.plan_from_date <= v_date_of_hosp ) AND
            ( tpa_hosp_revised_plan.plan_to_date >= v_date_of_hosp ) OR ( tpa_hosp_revised_plan.plan_to_date IS NULL )
           ) AND
           ( tpa_hosp_revised_packages.pkg_seq_id = v_pkg_seq_id );


    CURSOR yes_cur IS SELECT tpa_hosp_revised_plan.revised_plan_seq_id
      INTO v_revised_plan_seq_id
      FROM tpa_hosp_revised_plan,
           tpa_hosp_revised_packages
     WHERE ( tpa_hosp_revised_packages.revised_plan_seq_id = tpa_hosp_revised_plan.revised_plan_seq_id) and
           ( tpa_hosp_revised_plan.prod_hosp_seq_id = v_prod_hosp_seq_id ) AND
           ( ( tpa_hosp_revised_plan.plan_from_date <= v_date_of_hosp ) AND
             ( tpa_hosp_revised_plan.plan_to_date >= v_date_of_hosp ) OR ( tpa_hosp_revised_plan.plan_to_date IS NULL )
           ) AND
           ( tpa_hosp_revised_packages.pkg_seq_id = v_pkg_seq_id );

  BEGIN

    SELECT COUNT(1)
      INTO v_count
      FROM tpa_hosp_revised_plan,
           tpa_hosp_revised_packages
     WHERE ( tpa_hosp_revised_packages.revised_plan_seq_id = tpa_hosp_revised_plan.revised_plan_seq_id) and
           ( tpa_hosp_revised_plan.prod_hosp_seq_id = v_prod_hosp_seq_id ) AND
           ( ( tpa_hosp_revised_plan.plan_from_date <= v_date_of_hosp ) AND
             ( tpa_hosp_revised_plan.plan_to_date >= v_date_of_hosp ) OR ( tpa_hosp_revised_plan.plan_to_date IS NULL )
           ) AND
           ( tpa_hosp_revised_packages.pkg_seq_id = v_pkg_seq_id );


   IF ( v_count = 0 ) THEN

      OPEN nill_cur;
      FETCH nill_cur INTO v_revised_plan_seq_id ;
      CLOSE nill_cur;
   ELSE
      OPEN yes_cur;
      FETCH yes_cur INTO v_revised_plan_seq_id ;
      CLOSE yes_cur;
   END IF;


   INSERT INTO npk_cost_temp ( pkg_seq_id ,maximum_allowed_amount , room_type_id, ward_type_id , duration_of_stay ,duration_general_type_id ,discount )
        SELECT   C.pkg_seq_id,
                 B.cost  ,
                 C.room_type_id,
                 C.ward_type_id,
                 D.duration_of_stay,
                 D.duration_general_type_id ,
                 A.discount_offered_ttk
            FROM tpa_hosp_revised_plan A,
                 tpa_hosp_package_cost B ,
                 tpa_hosp_package_detail  C,
                 tpa_hosp_tariff_item D
           WHERE ( B.revised_plan_seq_id = A.revised_plan_seq_id ) and
                 ( C.pkg_detail_seq_id = B.pkg_detail_seq_id ) and
                 ( C.pkg_seq_id =  D.pkg_seq_id ) AND
                 ( ( A.revised_plan_seq_id = v_revised_plan_seq_id ) AND
                 ( A.plan_seq_id = v_plan_seq_id ) AND
                 ( C.pkg_seq_id = v_pkg_seq_id ));
  END get_pkg_cost;
-- =================================================================================================================
  PROCEDURE save_clm_summary (
    v_claim_seq_id        IN  clm_general_details.claim_seq_id%TYPE,
    v_ward_type_id        IN clm_bill_details.ward_type_id%TYPE,
    v_apply_discount_yn   IN clm_bill_details.apply_discount_yn%TYPE,
    v_added_by            IN clm_bill_details.added_by%TYPE
  )
  IS
  BEGIN
     claims_freeze(v_claim_seq_id,NULL,'S'); --KOCBJJ
    --reassigning user
    pre_auth_pkg.reassign_user (  NULL , v_claim_seq_id ,NULL , v_added_by , 'AUT');

    --Checking Claim completed or Not
    pre_auth_pkg.check_clm_completed ( v_claim_seq_id , NULL ,'REC' ,v_added_by);

    UPDATE clm_bill_details
       SET apply_discount_yn = v_apply_discount_yn,
           updated_by        = v_added_by,
           updated_date      = SYSDATE
           WHERE ward_type_id = v_ward_type_id AND  clm_bill_seq_id IN ( SELECT x.clm_bill_seq_id
                               FROM clm_bill_header x
                               WHERE x.claim_seq_id = v_claim_seq_id );

    pre_auth_pkg.set_validation_status('C',v_claim_seq_id,'U',v_added_by );
  END save_clm_summary;
-- =================================================================================================================
  PROCEDURE check_claim (
    v_claim_seq_id        IN  clm_general_details.claim_seq_id%TYPE,
    v_added_by            IN clm_bill_details.added_by%TYPE
  )
  IS
  BEGIN
   UPDATE clm_general_details cg
      SET -- KOC1164 copay with age
            cg.copay_rest_amt = NULL,
          cg.co_payment_amount = 0,
      updated_by       = v_added_by,
            updated_date     = SYSDATE
    WHERE cg.claim_seq_id = v_claim_seq_id;
   COMMIT;

    claims_freeze(v_claim_seq_id,NULL,'S'); --KOCBJJ
    --reassigning user
    pre_auth_pkg.reassign_user (  NULL , v_claim_seq_id ,NULL , v_added_by , 'AUT');

    --Checking Claim completed or Not
    pre_auth_pkg.check_clm_completed ( v_claim_seq_id , NULL ,'REC' ,v_added_by);

    pre_auth_pkg.set_validation_status('C',v_claim_seq_id,'U',v_added_by );
  END check_claim;
-- =================================================================================================================
  PROCEDURE select_bill_header (
      v_clm_bill_seq_id                 IN  clm_bill_header.clm_bill_seq_id%TYPE,
      v_added_by                        IN  clm_bill_header.added_by%TYPE,
      v_result_set                      OUT SYS_REFCURSOR
  )
  IS
      --v_app_amt         clm_bill_details.allowed_amount%TYPE;
      --v_rej_amt         clm_bill_details.rejected_amount%TYPE;
  BEGIN

    /*SELECT A.allowed_amount,A.rejected_amount INTO v_app_amt,v_rej_amt
    FROM clm_bill_details A
    WHERE A.CLM_BILL_SEQ_ID=v_clm_bill_seq_id
    AND A.ward_type_id='STX';*/

    OPEN v_result_set FOR
       SELECT A.clm_bill_seq_id, A.bill_no, A.bill_date,A.Bill_Issued_By,c.claim_sub_general_type_id, c.completed_yn, DECODE(A.bills_with_prescription_yn,'Y','Yes','No') AS bills_with_prescription_yn,
             SUM(B.requested_amount) AS requested_amt,
             /*CASE WHEN B.Ward_Type_Id='STX' THEN SUM(B.rejected_amount)-v_rej_amt
             ELSE SUM(B.rejected_amount) END AS disallowed_amount,
             CASE WHEN B.ward_type_id='STX' THEN SUM(B.allowed_amount)-v_app_amt
             ELSE SUM(B.allowed_amount) END AS allowed_amount,*/
             SUM(B.REJECTED_AMOUNT) AS disallowed_amount,
             SUM(B.Allowed_Amount) AS allowed_amount,
             CASE WHEN TRUNC(A.bill_date) < TRUNC(C.date_of_admission) THEN 'Pre-Hospitalization'
                  WHEN TRUNC(A.bill_date) > TRUNC(C.DATE_OF_DISCHARGE) THEN 'Post-Hospitalization'
                   ELSE 'Hospitalization' END AS bill_type , DECODE(a.bill_included_yn,'Y','Yes','No') AS bill_included_yn,
             DECODE(A.DONOR_BILL_YN,'Y' ,'Yes','No') as DONOR_BILL_YN --KOC DONOR

        FROM clm_bill_header A LEFT OUTER JOIN clm_bill_details B ON A.clm_bill_seq_id = B.clm_bill_seq_id
             INNER JOIN clm_general_details C ON A.claim_seq_id = C.claim_seq_id
       WHERE A.clm_bill_seq_id = v_clm_bill_seq_id
       GROUP BY A.clm_bill_seq_id,A.bill_no,A.bill_date,A.Bill_Issued_By, c.completed_yn ,A.bills_with_prescription_yn,c.claim_sub_general_type_id, --Added for koc1320
               CASE WHEN TRUNC(A.bill_date) < TRUNC(C.date_of_admission) THEN 'Pre-Hospitalization'
                    WHEN TRUNC(A.bill_date) > TRUNC(C.DATE_OF_DISCHARGE) THEN 'Post-Hospitalization'
                     ELSE 'Hospitalization' END, a.bill_included_yn,/*B.rejected_amount,*/B.ward_type_id,/*,B.allowed_amount*/A.DONOR_BILL_YN; --koc donor

  END select_bill_header;

     ---========================================================================================
  function claims_ref_ins ( --KOCBJJ
              v_claim_seq_id                   IN clm_enroll_details.claim_seq_id%TYPE,
              v_prod_policy_seq_id             IN tpa_ins_prod_policy.prod_policy_seq_id%TYPE
              )  RETURN CHAR
    as 

  CURSOR cur_awc IS
  SELECT
       cg.claim_number,
       cg.claim_sub_general_type_id,
       ce.ins_seq_id,
       ce.claimant_name,
       ce.clm_status_general_type_id AS clm_status,
       cii.clm_ins_status,
       cii.clm_ins_remarks,
       tii.abbrevation_code,
       cg.updated_by,
       cg.requested_amount as total_app_amount,
       cii.override_yn,
       cii.ins_intimation_req_yn
  FROM clm_general_details cg
  JOIN clm_enroll_details ce ON (cg.claim_seq_id=ce.claim_seq_id)
  left outer join app.clm_ins_intimation_details cii on (ce.claim_seq_id=cii.claim_seq_id)
  JOIN tpa_ins_info tii      ON (tii.ins_seq_id=ce.ins_seq_id)
  WHERE cg.claim_seq_id=v_claim_seq_id;

 awc_rec                    cur_awc%ROWTYPE;


  CURSOR cur_relation (v_prod_policy_seq_id VARCHAR2) IS
    SELECT tps.copay_yn,tps.copay_approved_amt,tps.copay_fixed_amt,tps.copay_perc,
           tps.si_restrict_yn,tps.si_relation,tps.si_restrict_amt,tps.si_restrict_perc,tps.si_type,
           tps.rest_age,tps.rest_age_amt,
           tps.Ins_Clm_Allow_Yn,tps.Ins_Clm_Operator,tps.Ins_Clm_Apr_Limit ,TPS.INS_REJ_ALLOW_YN,TPS.INS_CLM_APR_REJ_YN,
--new
           ins_clm_cl_rej_allow_yn,ins_clm_cm_rej_allow_yn,ins_clm_cl_apr_rej_yn,ins_clm_cm_apr_rej_yn,
           clm_cl_mail_flag,clm_cm_mail_flag,ins_clm_cl_allow_yn,ins_clm_cm_allow_yn,ins_clm_cl_operator,
           ins_clm_cm_operator,ins_clm_cl_apr_limit,ins_clm_cm_apr_limit,clm_mail_freq_hours,pat_mail_freq_hours,
           clm_mail_freq_mins,pat_mail_freq_mins
     FROM  Tpa_ins_prod_policy tps
     WHERE tps.prod_policy_seq_id=v_prod_policy_seq_id;

   CURSOR cur_pol IS
     SELECT pe.policy_number,pe.policy_seq_id,pe.enrol_type_id,PG.COMPLETED_YN,c.claim_general_type_id
     FROM clm_enroll_details pe
     JOIN clm_general_details pg ON (pe.claim_seq_id=pg.claim_seq_id)
     JOIN clm_inward C ON (pg.claims_inward_seq_id = c.claims_inward_seq_id )
     WHERE pg.claim_seq_id=v_claim_seq_id;

   pat_rec          cur_pol%ROWTYPE;
   relt_cur         cur_relation%ROWTYPE;
 
  v_den_ban_yn char(1):='N';

    begin
    
    OPEN cur_pol;
    FETCH cur_pol INTO pat_rec;
    CLOSE cur_pol;

    OPEN  cur_relation (v_prod_policy_seq_id);
    FETCH cur_relation INTO relt_cur;
    CLOSE cur_relation;

    OPEN cur_awc;
    FETCH cur_awc INTO awc_rec;
    CLOSE cur_awc;
 
     IF   (case when pat_rec.claim_general_type_id = 'CNH' then relt_cur.ins_clm_cl_apr_rej_yn else relt_cur.ins_clm_cm_apr_rej_yn end) ='Y' THEN
       IF (case when pat_rec.claim_general_type_id = 'CNH' then relt_cur.Ins_Clm_Cl_Allow_Yn else relt_cur.Ins_Clm_Cm_Allow_Yn end ) ='Y' AND awc_rec.clm_status IN ('APR') THEN

          IF  ((awc_rec.clm_ins_status IS NULL  or awc_rec.clm_ins_status='REQ')) THEN
              IF (case when pat_rec.claim_general_type_id = 'CNH' then relt_cur.Ins_Clm_cl_Operator else relt_cur.Ins_Clm_cm_Operator end )='GT' THEN
                 IF  awc_rec.total_app_amount>= (case when pat_rec.claim_general_type_id = 'CNH' then relt_cur.Ins_Clm_cl_Apr_Limit else relt_cur.Ins_Clm_cm_Apr_Limit end ) THEN  -----KOCBJJ
                 Raise_application_error(-20866,'The claims requires insurance decision please intimate claim');
                 END IF;
              ELSIF (case when pat_rec.claim_general_type_id = 'CNH' then relt_cur.Ins_Clm_cl_Operator else relt_cur.Ins_Clm_cm_Operator end ) ='LT' THEN
                    IF awc_rec.total_app_amount<= (case when pat_rec.claim_general_type_id = 'CNH' then relt_cur.Ins_Clm_cl_Apr_Limit else relt_cur.Ins_Clm_cm_Apr_Limit end )  THEN  -----KOCBJJ
                    Raise_application_error(-20866,'The claims requires insurance decision please intimate claim');
                    END IF;
              ELSIF (case when pat_rec.claim_general_type_id = 'CNH' then relt_cur.Ins_Clm_cl_Operator else relt_cur.Ins_Clm_cm_Operator end ) ='EQ' THEN
                    IF  awc_rec.total_app_amount= (case when pat_rec.claim_general_type_id = 'CNH' then relt_cur.Ins_Clm_cl_Apr_Limit else relt_cur.Ins_Clm_cm_Apr_Limit end )  THEN  -----KOCBJJ
                    Raise_application_error(-20866,'The claims requires insurance decision please intimate claim');
                    END IF;
              END IF;
              
            end if;

        ELSIF  (case when pat_rec.claim_general_type_id = 'CNH' then relt_cur.ins_clm_cl_rej_allow_yn else relt_cur.ins_clm_cm_rej_allow_yn end ) ='Y' and awc_rec.clm_status IN ('REJ')  THEN

          IF ((awc_rec.clm_ins_status IS NULL or awc_rec.clm_ins_status ='REQ'))  THEN
              Raise_application_error(-20866,'The claims requires insurance decision please intimate claim');
          END IF;

        END IF;
    END IF;
    
    
 return v_den_ban_yn; 

 exception 
       
  when others  then 
    
  if (sqlcode) = '-20866' then 
  v_den_ban_yn := 'Y';
   return v_den_ban_yn;      
  end if;
  
    END claims_ref_ins;

-- =================================================================================================================
   PROCEDURE select_settlement (
    v_claim_seq_id                         IN  clm_general_details.claim_seq_id%TYPE,
    v_clm_enroll_detail_seq_id             IN  clm_enroll_details.clm_enroll_detail_seq_id%TYPE,
    v_result_set                           OUT SYS_REFCURSOR
  )
  IS
    v_ctr                               NUMBER;
    v_unusable_sum                      NUMBER(12,2):= 0;
    v_unusable_bonus                    NUMBER(12,2):= 0;
    v_appr_amt                          NUMBER(12,2);
    v_max_allowed_amount                NUMBER(12,2);
    v_appr_count                        NUMBER(2);
    v_amd_buffer                        NUMBER:= 0;
    v_discount_amount                   clm_general_details.discount_amount%TYPE;
    v_co_payment_amount                 clm_general_details.co_payment_amount%TYPE;
    v_final_app_amt                     clm_general_details.Total_App_Amount%TYPE;
    v_service_tax_calc_amt              clm_general_details.serv_tax_calc_amount%TYPE;
    v_serv_tax_calc_percentage          clm_general_details.serv_tax_calc_percentage%TYPE;

    CURSOR clm_cur IS SELECT a.auth_number,b.tpa_enrollment_id , c.claim_general_type_id , a.completed_yn , b.member_seq_id ,a.date_of_admission,
        a.claim_sub_general_type_id , c.document_general_type_id, a.last_buffer_detail_seq_id,
        d.buffer_alloc_general_type_id, d.enrol_type_id,b.clm_status_general_type_id,a.serv_tax_calc_amount,a.pat_enroll_detail_seq_id--koc1277
        FROM clm_general_details a JOIN clm_enroll_details b ON (a.claim_seq_id = b.claim_seq_id)
        JOIN clm_inward c ON (a.claims_inward_seq_id = c.claims_inward_seq_id)
        LEFT OUTER JOIN tpa_enr_policy d ON (b.policy_seq_id = d.policy_seq_id)
        WHERE a.claim_seq_id = v_claim_seq_id ;

    clm_rec   clm_cur%ROWTYPE;

    CURSOR amt_cur IS SELECT SUM(approved_amount) AS appr_amt, SUM(maximum_allowed_amount) AS max_allowed_amount
                           FROM ailment_caps X JOIN icd_pcs_detail Y ON ( X.icd_pcs_seq_id = Y.icd_pcs_seq_id )
                           WHERE y.claim_seq_id = v_claim_seq_id;

   CURSOR prev_appr_cur IS  SELECT COUNT(1) FROM ( SELECT a.claim_seq_id, a.parent_claim_seq_id
      FROM clm_general_details a
      START WITH a.claim_seq_id = v_claim_seq_id CONNECT BY a.claim_seq_id = PRIOR a.parent_claim_seq_id ) aa
      JOIN clm_enroll_details bb ON (aa.claim_seq_id = bb.claim_seq_id )
      WHERE bb.clm_status_general_type_id = 'APR' AND aa.claim_seq_id != v_claim_seq_id ;

   CURSOR dom_cur IS
     SELECT a.domicilary_seq_id, a.domicilary_limit, a.utilised_dom_amount,
       nvl (b.domicilary_general_type_id,c.domicilary_general_type_id) AS domicilary_general_type_id,
       additional_domicilary_yn--Added for KOC1216C
       FROM tpa_enr_domicilary a JOIN tpa_enr_policy_member b ON (a.policy_group_seq_id = b.policy_group_seq_id)
       JOIN tpa_enr_policy C ON (a.policy_seq_id = c.policy_seq_id)
       WHERE (nvl(b.domicilary_general_type_id,c.domicilary_general_type_id) = 'PNF' AND a.member_seq_id = clm_rec.member_seq_id OR
              nvl(b.domicilary_general_type_id,c.domicilary_general_type_id) = 'PFL' AND b.member_seq_id = clm_rec.member_seq_id);
    dom_rec                              dom_cur%ROWTYPE;

   CURSOR ward_type_cur IS
     SELECT A.ward_type_id,A.requested_amount
     FROM clm_bill_details A LEFT OUTER JOIN clm_bill_header B ON (A.clm_bill_seq_id=B.clm_bill_seq_id)
     WHERE B.Claim_Seq_Id=v_claim_seq_id
     AND A.Ward_Type_Id='STX';
     ward_type_rec                       ward_type_cur%ROWTYPE;

   cursor cur_rest is   --koc1142
     select tipp.si_restrict_yn,tipp.si_relation
     from tpa_ins_prod_policy  tipp
     join tpa_enr_policy tep on (tipp.policy_seq_id=tep.policy_seq_id)
     join clm_enroll_details ped on (tep.policy_seq_id=ped.policy_seq_id)
     where ped.claim_seq_id=v_claim_seq_id;

 --koc1277
  cursor pre_cur is
      select sum(gen.policy_deductable_amt) policy_deductable_amt,sum(gen.total_app_amount) clm_tot
    FROM pat_general_details A JOIN pat_enroll_details B ON ( a.pat_enroll_detail_seq_id = b.pat_enroll_detail_seq_id AND A.PAT_ENHANCED_YN='N')
       JOIN clm_general_details gen on (gen.pat_enroll_detail_seq_id=a.pat_enroll_detail_seq_id)
       JOIN clm_enroll_details en on (en.claim_seq_id=gen.claim_seq_id)
    where a.pat_enroll_detail_seq_id=clm_rec.pat_enroll_detail_seq_id
    and en.clm_status_general_type_id='APR';

pre_rec  pre_cur%rowtype;

cursor pat_mon_cur is
  select a.policy_deductable_amt,a.total_app_amount
    FROM pat_general_details A JOIN pat_enroll_details B ON ( a.pat_enroll_detail_seq_id = b.pat_enroll_detail_seq_id AND A.PAT_ENHANCED_YN='N' )
    where a.pat_enroll_detail_seq_id=clm_rec.pat_enroll_detail_seq_id
    and b.pat_status_general_type_id='APR';

pat_mon_rec  pat_mon_cur%rowtype;

--koc1277

      rest_cur                cur_rest%ROWTYPE;
      v_str_char              VARCHAR2(4000);
      v_ctr2                  NUMBER(10);
      v_config_amt            tpa_enr_balance.sum_insured%TYPE;
      v_used_amt              tpa_enr_balance.utilised_sum_insured%TYPE;
      v_age_flag              VARCHAR2(3);

      v_policy_group_seq_id   tpa_enr_balance.policy_group_seq_id%TYPE;
    v_notify_tipe_id                     varchar2(3);--koc_ins_mail
      v_ins_name                           varchar2(100);--koc_ins_mail

  BEGIN
    OPEN clm_cur;
    FETCH clm_cur INTO clm_rec;
    CLOSE clm_cur;
--koc1277
    OPEN pre_cur;
    FETCH pre_cur INTO pre_rec;
    CLOSE pre_cur;

    OPEN pat_mon_cur;
    FETCH pat_mon_cur INTO pat_mon_rec;
    CLOSE pat_mon_cur;
--koc1277

   -- IF clm_rec.claim_sub_general_type_id = 'OPD' THEN  --Removed for KOC1216C
      OPEN dom_cur;
      FETCH dom_cur INTO dom_rec;
      CLOSE dom_cur;
  --  END IF;
  p_rest_si(v_clm_enroll_detail_seq_id,clm_rec.member_seq_id,v_policy_group_seq_id,v_ctr2,'C');

    OPEN ward_type_cur;
    FETCH ward_type_cur INTO ward_type_rec;
    CLOSE ward_type_cur;

    IF clm_rec.auth_number IS NULL AND clm_rec.claim_general_type_id = 'CNH' THEN
      raise_application_error(-20163,'You cannot approve and NHCP claim which is not associated to an approved pre-auth.');
    ELSIF clm_rec.tpa_enrollment_id IS NULL THEN
      raise_application_error(-20164,'Please associate enrollment id.');
    END IF;

    IF clm_rec.completed_yn = 'N' THEN
      pre_auth_pkg.get_unusable_amounts( trunc(clm_rec.date_of_admission), clm_rec.member_seq_id, v_unusable_sum , v_unusable_bonus );
    END IF;

  --koc_ins_mail
    IF v_claim_seq_id IS NOT NULL THEN
      select ii.ins_comp_name,ii.notify_type_id into v_ins_name,v_notify_tipe_id from clm_enroll_details ed join clm_general_details gd on(ed.claim_seq_id=gd.claim_seq_id)
      join tpa_ins_info ii on(ii.ins_seq_id=ed.ins_seq_id)
      where gd.claim_seq_id=v_claim_seq_id;
     end if;
     --koc_ins_mail

    SELECT COUNT(1) INTO v_ctr
      FROM discrepancy_information
      WHERE claim_seq_id = v_claim_seq_id AND resolved_yn = 'N';

    OPEN amt_cur;
    FETCH amt_cur INTO v_appr_amt, v_max_allowed_amount;
    CLOSE amt_cur;

    OPEN prev_appr_cur;
    FETCH prev_appr_cur INTO v_appr_count;
    CLOSE prev_appr_cur;

    SELECT cg.discount_amount,cg.co_payment_amount,cg.serv_tax_calc_amount INTO v_discount_amount,v_co_payment_amount,v_service_tax_calc_amt FROM clm_general_details cg WHERE cg.claim_seq_id=v_claim_seq_id;--For KOC1015 to get final amt after service tax

    IF ward_type_rec.requested_amount IS NOT NULL /*and clm_rec.clm_status_general_type_id='APR'*/ THEN
      claims_pkg.calc_service_tax(v_claim_seq_id,v_co_payment_amount,v_discount_amount,v_service_tax_calc_amt, v_final_app_amt,v_serv_tax_calc_percentage);--For KOC1015
    END IF;

     IF v_ctr2>0 THEN
       age_amount_rest(v_claim_seq_id ,'C', v_config_amt,v_used_amt,v_age_flag);
    END IF;

    OPEN v_result_set FOR
       SELECT
      a.inv_disallowed_amt,--Added for koc_investigation
        a.claim_seq_id,
        b.clm_enroll_detail_seq_id,
        d.buff_detail_seq_id,
        e.buffer_hdr_seq_id ,
        q.sum_insured AS tot_sum_insured ,
        e.claim_app_buffer_amount AS buffer_app_amount, -- interchanged the column names
        e.pre_auth_buffer_app_amount,
        CASE WHEN  a.completed_yn='Y' THEN CASE WHEN e.buffer_hdr_seq_id IS NOT NULL THEN
               NVL( E.claim_app_buffer_amount,0) + nvl( e.pre_auth_buffer_app_amount,0 )  - nvl(e.utilised_amount,0)  - nvl(e.Utilised_Med_Amount,0) - nvl(e.Utilised_Crit_Amount,0) - nvl(e.Utilised_Crit_Corp_Amount,0) - nvl(e.Utilised_Crit_Med_Amount,0) 
             WHEN o.buffer_hdr_seq_id IS NOT NULL THEN
               NVL( o.claim_app_buffer_amount,0) + nvl( o.pre_auth_buffer_app_amount,0 )  - nvl(o.utilised_amount,0) - nvl(o.Utilised_Med_Amount,0) - nvl(o.Utilised_Crit_Amount,0) - nvl(o.Utilised_Crit_Corp_Amount,0) - nvl(o.Utilised_Crit_Med_Amount,0)
             ELSE 0 END +  nvl(a.utilised_buff_amt,0)  + 0
        ELSE 
         CASE WHEN  cn.claim_general_type_id='CNH' AND cn.document_general_type_id ='DTA'  THEN
             NVL( E.claim_app_buffer_amount,0) + nvl( e.pre_auth_buffer_app_amount,0 ) 
          ELSE
             CASE WHEN e.buffer_hdr_seq_id IS NOT NULL THEN 
               NVL( E.claim_app_buffer_amount,0) + nvl( e.pre_auth_buffer_app_amount,0 ) 
             WHEN  o.buffer_hdr_seq_id IS NOT NULL THEN
               NVL( o.claim_app_buffer_amount,0) + nvl( o.pre_auth_buffer_app_amount,0 ) 
        END END END AS claim_app_buffer_amount,
        
        CASE WHEN a.completed_yn = 'Y' THEN Q.sum_insured - Q.utilised_sum_insured
             WHEN ( clm_rec.document_general_type_id != 'DTA' OR clm_rec.document_general_type_id  = 'DTA' AND v_appr_count = 0 )
                   AND Q.sum_insured >= (Q.sum_insured - Q.utilised_sum_insured + NVL( DECODE(a.app_sum_insured,0,NULL,a.app_sum_insured),NVL(i.app_sum_insured,0))) THEN  (Q.sum_insured - Q.utilised_sum_insured + NVL( DECODE(a.app_sum_insured,0,NULL,a.app_sum_insured), NVL(i.app_sum_insured,0)))
             WHEN ( clm_rec.document_general_type_id != 'DTA' OR clm_rec.document_general_type_id  = 'DTA' AND v_appr_count = 0 )
             AND Q.sum_insured < (Q.sum_insured - Q.utilised_sum_insured + NVL( DECODE(a.app_sum_insured,0,NULL,a.app_sum_insured),NVL(i.app_sum_insured,0))) THEN Q.sum_insured
             WHEN clm_rec.document_general_type_id  = 'DTA' AND Q.sum_insured >= ( Q.sum_insured - Q.utilised_sum_insured + NVL(a.app_sum_insured,0)) THEN Q.sum_insured - Q.utilised_sum_insured + NVL(a.app_sum_insured,0)
             WHEN clm_rec.document_general_type_id  = 'DTA' AND Q.sum_insured < ( Q.sum_insured - Q.utilised_sum_insured + NVL(a.app_sum_insured,0)) THEN Q.sum_insured
             END - NVL(v_unusable_sum,0) AS ava_sum_insured,

        CASE WHEN a.completed_yn = 'Y' THEN Q.bonus - Q.utilised_cum_bonus
            WHEN ( clm_rec.document_general_type_id != 'DTA' OR clm_rec.document_general_type_id = 'DTA'  AND v_appr_count = 0)
              AND  Q.Bonus >= (Q.Bonus - Q.Utilised_Cum_Bonus  + NVL( NVL (DECODE(a.app_cum_bonus,0,NULL,a.app_cum_bonus ), i.app_cum_bonus),0)) THEN  Q.Bonus - Q.Utilised_Cum_Bonus  + NVL( NVL (DECODE(a.app_cum_bonus,0,NULL,a.app_cum_bonus ), i.app_cum_bonus),0)
            WHEN ( clm_rec.document_general_type_id != 'DTA' OR clm_rec.document_general_type_id = 'DTA'  AND v_appr_count = 0 )
              AND  Q.Bonus < (Q.Bonus - Q.Utilised_Cum_Bonus  + NVL( NVL (DECODE(a.app_cum_bonus,0,NULL,a.app_cum_bonus ), i.app_cum_bonus),0)) THEN  Q.Bonus
            WHEN clm_rec.document_general_type_id = 'DTA'  AND  Q.Bonus >= (Q.Bonus - Q.Utilised_Cum_Bonus  + NVL (a.app_cum_bonus,0)) THEN Q.Bonus - Q.Utilised_Cum_Bonus  + NVL (a.app_cum_bonus,0)
            WHEN clm_rec.document_general_type_id = 'DTA'  AND  Q.Bonus < (Q.Bonus - Q.Utilised_Cum_Bonus  + NVL (a.app_cum_bonus,0)) THEN Q.Bonus
            END - NVL(v_unusable_bonus,0) AS ava_cum_bonus,
        CASE WHEN v_age_flag='N' THEN q.restrict_amt ELSE v_config_amt END as mem_rest_sum_insured, --koc1142

         CASE WHEN v_age_flag ='N' THEN -- for relation restriction

        LEAST(CASE WHEN a.completed_yn = 'Y' THEN Q.sum_insured - Q.utilised_sum_insured
             WHEN ( clm_rec.document_general_type_id != 'DTA' OR clm_rec.document_general_type_id  = 'DTA' AND v_appr_count = 0 )
                   AND Q.sum_insured >= (Q.sum_insured - Q.utilised_sum_insured + NVL( DECODE(a.app_sum_insured,0,NULL,a.app_sum_insured),NVL(i.app_sum_insured,0))) THEN  (Q.sum_insured - Q.utilised_sum_insured + NVL( DECODE(a.app_sum_insured,0,NULL,a.app_sum_insured), NVL(i.app_sum_insured,0)))
             WHEN ( clm_rec.document_general_type_id != 'DTA' OR clm_rec.document_general_type_id  = 'DTA' AND v_appr_count = 0 )
             AND Q.sum_insured < (Q.sum_insured - Q.utilised_sum_insured + NVL( DECODE(a.app_sum_insured,0,NULL,a.app_sum_insured),NVL(i.app_sum_insured,0))) THEN Q.sum_insured
             WHEN clm_rec.document_general_type_id  = 'DTA' AND Q.sum_insured >= ( Q.sum_insured - Q.utilised_sum_insured + NVL(a.app_sum_insured,0)) THEN Q.sum_insured - Q.utilised_sum_insured + NVL(a.app_sum_insured,0)
             WHEN clm_rec.document_general_type_id  = 'DTA' AND Q.sum_insured < ( Q.sum_insured - Q.utilised_sum_insured + NVL(a.app_sum_insured,0)) THEN Q.sum_insured
             END - NVL(v_unusable_sum,0),

           CASE WHEN a.completed_yn = 'Y' THEN (Q.restrict_amt - nvl(Q.Used_Restrict_Amt,0))
             WHEN ( clm_rec.document_general_type_id != 'DTA' OR clm_rec.document_general_type_id  = 'DTA' AND v_appr_count = 0 )
             AND Q.restrict_amt >= ((Q.restrict_amt - nvl(Q.Used_Restrict_Amt,0)) + NVL( DECODE(a.app_sum_insured,0,NULL,a.app_sum_insured),NVL(i.app_sum_insured,0))) THEN  ((Q.restrict_amt - nvl(Q.Used_Restrict_Amt,0)) + NVL( DECODE(a.app_sum_insured,0,NULL,a.app_sum_insured), NVL(i.app_sum_insured,0)))
             WHEN ( clm_rec.document_general_type_id != 'DTA' OR clm_rec.document_general_type_id  = 'DTA' AND v_appr_count = 0 )
             AND Q.restrict_amt < ((Q.restrict_amt - nvl(Q.Used_Restrict_Amt,0)) + NVL( DECODE(a.app_sum_insured,0,NULL,a.app_sum_insured),NVL(i.app_sum_insured,0))) THEN Q.restrict_amt
             WHEN clm_rec.document_general_type_id  = 'DTA' AND Q.restrict_amt >= ( (Q.restrict_amt - nvl(Q.Used_Restrict_Amt,0)) + NVL(a.app_sum_insured,0)) THEN (Q.restrict_amt - nvl(Q.Used_Restrict_Amt,0)) + NVL(a.app_sum_insured,0)
             WHEN clm_rec.document_general_type_id  = 'DTA' AND Q.restrict_amt < ( (Q.restrict_amt - nvl(Q.Used_Restrict_Amt,0)) + NVL(a.app_sum_insured,0)) THEN Q.restrict_amt
             END - NVL(v_unusable_sum,0))

         ELSE  -- for age restriction
        LEAST(CASE WHEN a.completed_yn = 'Y' THEN Q.sum_insured - Q.utilised_sum_insured
             WHEN ( clm_rec.document_general_type_id != 'DTA' OR clm_rec.document_general_type_id  = 'DTA' AND v_appr_count = 0 )
                   AND Q.sum_insured >= (Q.sum_insured - Q.utilised_sum_insured + NVL( DECODE(a.app_sum_insured,0,NULL,a.app_sum_insured),NVL(i.app_sum_insured,0))) THEN  (Q.sum_insured - Q.utilised_sum_insured + NVL( DECODE(a.app_sum_insured,0,NULL,a.app_sum_insured), NVL(i.app_sum_insured,0)))
             WHEN ( clm_rec.document_general_type_id != 'DTA' OR clm_rec.document_general_type_id  = 'DTA' AND v_appr_count = 0 )
             AND Q.sum_insured < (Q.sum_insured - Q.utilised_sum_insured + NVL( DECODE(a.app_sum_insured,0,NULL,a.app_sum_insured),NVL(i.app_sum_insured,0))) THEN Q.sum_insured
             WHEN clm_rec.document_general_type_id  = 'DTA' AND Q.sum_insured >= ( Q.sum_insured - Q.utilised_sum_insured + NVL(a.app_sum_insured,0)) THEN Q.sum_insured - Q.utilised_sum_insured + NVL(a.app_sum_insured,0)
             WHEN clm_rec.document_general_type_id  = 'DTA' AND Q.sum_insured < ( Q.sum_insured - Q.utilised_sum_insured + NVL(a.app_sum_insured,0)) THEN Q.sum_insured
             END - NVL(v_unusable_sum,0),

           CASE WHEN a.completed_yn = 'Y' THEN (Q.restrict_amt - nvl(Q.Used_Restrict_Amt,0))
             WHEN ( clm_rec.document_general_type_id != 'DTA' OR clm_rec.document_general_type_id  = 'DTA' AND v_appr_count = 0 )
             AND Q.restrict_amt >= ((Q.restrict_amt - nvl(Q.Used_Restrict_Amt,0)) + NVL( DECODE(a.app_sum_insured,0,NULL,a.app_sum_insured),NVL(i.app_sum_insured,0))) THEN  ((Q.restrict_amt - nvl(Q.Used_Restrict_Amt,0)) + NVL( DECODE(a.app_sum_insured,0,NULL,a.app_sum_insured), NVL(i.app_sum_insured,0)))
             WHEN ( clm_rec.document_general_type_id != 'DTA' OR clm_rec.document_general_type_id  = 'DTA' AND v_appr_count = 0 )
             AND Q.restrict_amt < ((Q.restrict_amt - nvl(Q.Used_Restrict_Amt,0)) + NVL( DECODE(a.app_sum_insured,0,NULL,a.app_sum_insured),NVL(i.app_sum_insured,0))) THEN Q.restrict_amt
             WHEN clm_rec.document_general_type_id  = 'DTA' AND Q.restrict_amt >= ( (Q.restrict_amt - nvl(Q.Used_Restrict_Amt,0)) + NVL(a.app_sum_insured,0)) THEN (Q.restrict_amt - nvl(Q.Used_Restrict_Amt,0)) + NVL(a.app_sum_insured,0)
             WHEN clm_rec.document_general_type_id  = 'DTA' AND Q.restrict_amt < ( (Q.restrict_amt - nvl(Q.Used_Restrict_Amt,0)) + NVL(a.app_sum_insured,0)) THEN Q.restrict_amt
             END - NVL(v_unusable_sum,0),

           CASE WHEN a.completed_yn = 'Y' THEN (v_config_amt - nvl(v_used_amt,0))
             WHEN ( clm_rec.document_general_type_id != 'DTA' OR clm_rec.document_general_type_id  = 'DTA' AND v_appr_count = 0 )
             AND v_config_amt >= ((v_config_amt - nvl(v_used_amt,0)) + NVL( DECODE(a.app_sum_insured,0,NULL,a.app_sum_insured),NVL(i.app_sum_insured,0))) THEN  ((v_config_amt - nvl(v_used_amt,0)) + NVL( DECODE(a.app_sum_insured,0,NULL,a.app_sum_insured), NVL(i.app_sum_insured,0)))
             WHEN ( clm_rec.document_general_type_id != 'DTA' OR clm_rec.document_general_type_id  = 'DTA' AND v_appr_count = 0 )
             AND v_config_amt < ((v_config_amt - nvl(v_used_amt,0)) + NVL( DECODE(a.app_sum_insured,0,NULL,a.app_sum_insured),NVL(i.app_sum_insured,0))) THEN v_config_amt
             WHEN clm_rec.document_general_type_id  = 'DTA' AND v_config_amt >= ( (v_config_amt - nvl(v_used_amt,0)) + NVL(a.app_sum_insured,0)) THEN (v_config_amt - nvl(v_used_amt,0)) + NVL(a.app_sum_insured,0)
             WHEN clm_rec.document_general_type_id  = 'DTA' AND v_config_amt < ( (v_config_amt - nvl(v_used_amt,0)) + NVL(a.app_sum_insured,0)) THEN v_config_amt
             END - NVL(v_unusable_sum,0)) END  AS ava_rest_sum_insured, --koc1142

           (case when v_ctr2=0 then 'N' else 'Y' end) as fam_rest_yn, --koc1142

        a.requested_amount,
        v_appr_amt AS max_allowed_amount, -- For   Max. Allowed Amt
        --round(v_appr_amt - NVL(a.discount_amount,0) - NVL(a.co_payment_amount,0) - NVL(a.deposit_amount,0) + NVL(a.serv_tax_calc_amount,0))  AS total_app_amount ,  -- For   Settlement Amt     (Calculate and display , This is the one to be passed to SAVE_SETTLEMENT procedure as V_MAX_APP_AMOUNT)
--koc1277
        case when (case T.policy_sub_general_type_id when 'PNF' then nvl(g.policy_deductable_yn,'N')
         when 'PFL' then nvl(h.policy_deductable_yn,'N') end) = 'Y' then nvl(a.total_app_amount,0) else
        case when v_appr_amt >= (NVL(a.discount_amount,0) + NVL(a.co_payment_amount,0)+ NVL(a.co_payment_buffer_amount,0) + nvl(a.policy_deductable_amt,0)) then round(v_appr_amt - NVL(a.discount_amount,0) - NVL(a.co_payment_amount,0)-NVL(a.co_payment_buffer_amount,0) - NVL(a.deposit_amount,0) + NVL(a.serv_tax_calc_amount,0)- nvl(a.policy_deductable_amt,0))   -- For   Settlement Amt     (Calculate and display , This is the one to be passed to SAVE_SETTLEMENT procedure as V_MAX_APP_AMOUNT)
        else 0 end end AS total_app_amount,
--koc1277
--        case when v_appr_amt >= (NVL(a.discount_amount,0) + NVL(a.co_payment_amount,0)+ NVL(a.co_payment_buffer_amount,0)) then round(v_appr_amt - NVL(a.discount_amount,0) - NVL(a.co_payment_amount,0)-NVL(a.co_payment_buffer_amount,0) - NVL(a.deposit_amount,0) + NVL(a.serv_tax_calc_amount,0))   -- For   Settlement Amt     (Calculate and display , This is the one to be passed to SAVE_SETTLEMENT procedure as V_MAX_APP_AMOUNT)
--        else 0 end AS total_app_amount,
        a.claim_settlement_number,
        b.clm_status_general_type_id  AS pat_status_general_type_id ,
        a.permission_sought_from ,
        m.contact_name,
        nvL(L.completed_date,b.decision_date) AS completed_date,
        L.remarks,
        L.assign_users_seq_id,
        L.rson_general_type_id ,
        i.total_app_amount AS  pat_approved_amount ,
        CASE WHEN v_ctr > 0 THEN 'Y' ELSE 'N' END AS discripency_presenet_yn,
        a.claim_dms_reference_id ,
        a.claim_sub_general_type_id, -- if 'HCU'  then show max allowed amount as approval_limit
        q.balance_seq_id,
        NVL(a.discount_amount,0) AS discount_amount,
        NVL(a.co_payment_amount,0) AS co_payment_amount,
        NVL(a.co_payment_buffer_amount,0) AS co_payment_buffer_amount, --KOCIBM
        a.completed_yn ,
        b.member_seq_id,
        b.policy_seq_id,
        CASE WHEN B.ENROL_TYPE_ID='COR' THEN NVL(POL.OPD_BENEFITS_YN,'N') ELSE NVL(U.OPD_BENEFITS_YN,'N') END AS OPD_BENEFITS_YN, --KOC1286
        b.enrol_type_id,
        a.date_of_admission AS date_of_hospitalization ,
        CASE WHEN a.completed_yn = 'Y' AND B.clm_status_general_type_id = 'APR' THEN check_dv_required(v_claim_seq_id)
          ELSE 'N' END AS dv_message_yn,

CASE WHEN A.claim_sub_general_type_id = 'OPD' AND  dom_rec.additional_domicilary_yn='N'  THEN --Changes done for KOC1216C
           (CASE WHEN a.completed_yn = 'N' AND B.clm_status_general_type_id = 'APR' THEN
               ( dom_rec.domicilary_limit - dom_rec.utilised_dom_amount + nvl(A.total_app_amount,0))
           ELSE dom_rec.domicilary_limit - dom_rec.utilised_dom_amount  END)
             WHEN A.claim_sub_general_type_id = 'OPD' AND  dom_rec.additional_domicilary_yn='Y'  THEN
           (CASE WHEN a.completed_yn = 'N' AND B.clm_status_general_type_id = 'APR' THEN
            ( dom_rec.domicilary_limit - dom_rec.utilised_dom_amount + (nvl(A.total_app_amount,0) - NVL(A.utilised_buff_amt,0)))
           ELSE dom_rec.domicilary_limit - dom_rec.utilised_dom_amount  END)
           ELSE dom_rec.domicilary_limit - dom_rec.utilised_dom_amount  END AS ava_domicilary_amount ,  --Changes done for KOC1216C
           dom_rec.additional_domicilary_yn as additional_domicilary_yn,
        NVL(v_unusable_sum,0) AS un_available_suminsured ,
        clm_rec.claim_general_type_id  AS claim_general_type_id ,
        I.co_payment_amount AS preauth_co_payment_amount,
        I.Co_Payment_Buffer_Amount as preauth_co_pay_buffer_amount, --KOCIBM
        i.discount_amount AS preauth_discount_amount,
        a.deposit_amount,
        g.policy_group_seq_id,
        nvl(ward_type_rec.requested_amount,0) AS ser_tax_req_amt,
        CASE WHEN B.clm_status_general_type_id = 'APR' THEN A.serv_tax_calc_amount
             ELSE NULL END AS serv_tax_calc_amount,
        --A.serv_tax_calc_amount,
        A.serv_tax_calc_percentage,
        CASE WHEN S.serv_tax_rgn_number IS NOT NULL AND ward_type_rec.requested_amount IS NOT NULL THEN 'Y'
             WHEN S.serv_tax_rgn_number IS NULL AND ward_type_rec.requested_amount IS NOT NULL THEN 'Y'
             WHEN S.serv_tax_rgn_number IS NULL AND ward_type_rec.requested_amount IS NULL THEN 'N'
             ELSE 'N' END AS calc_button_disp_yn,
       CASE WHEN S.serv_tax_rgn_number IS NOT NULL AND ward_type_rec.requested_amount IS NOT NULL THEN 'Y'
             WHEN S.serv_tax_rgn_number IS NULL AND ward_type_rec.requested_amount IS NOT NULL THEN 'N'
             END AS press_button_man_yn,
        /*CASE WHEN A.SERV_TAX_CALC_AMOUNT IS NULL THEN v_appr_amt - NVL(a.discount_amount,0) - NVL(a.co_payment_amount,0)
             ELSE v_final_app_amt END AS final_app_amount   -- For final approved amount field*/
        CASE WHEN A.SERV_TAX_CALC_AMOUNT IS NULL then case when v_appr_amt >= (NVL(a.discount_amount,0) + NVL(a.co_payment_amount,0)+NVL(a.co_payment_buffer_amount,0))
                  THEN nvl(v_appr_amt - NVL(a.discount_amount,0) - NVL(a.co_payment_amount,0)-NVL(a.co_payment_buffer_amount,0),0)
                  else 0.00 end
             ELSE nvl(v_final_app_amt,0) END AS final_app_amount,   -- For final approved amount field
                 cii.clm_ins_status, --KOCBJJ

        nvl(a.final_app_yn,'N') final_app_yn, --koc_ins_mail
          CASE WHEN v_ins_name like 'CIGNA%' AND CN.CLAIM_GENERAL_TYPE_ID='CTM' AND v_notify_tipe_id = 'NIC' then 'Y' else 'N' end as CIGNA_YN,-- koc_ins_mail

                 CII.clm_ins_remarks, --KOCBJJ
          v.clm_apr_amt, --Added for koc_investigation
--koc1277
        case when (nvl(G.POLICY_DEDUCTABLE_YN,'N')='Y' and T.policy_sub_general_type_id = 'PNF')
          or (nvl(h.policy_deductable_yn,'N')='Y' and T.policy_sub_general_type_id = 'PFL')
          then case when (nvl(a.POLICY_DEDUCTABLE_AMT_SET,0) > 0 ) then nvl(a.POLICY_DEDUCTABLE_AMT_SET,0)
           else nvl(q.policy_deductable_amt,0) - nvl(q.utilised_policy_deductable_amt,0) end else 0 end as bal_deductable_amt,

         case T.policy_sub_general_type_id when 'PNF' then nvl(g.policy_deductable_yn,'N')
           when 'PFL' then nvl(h.policy_deductable_yn,'N') end as policy_deductable_yn,

          case when I.PAT_GEN_DETAIL_SEQ_ID is not null and cn.document_general_type_id!='DTA' then ROUND(v_appr_amt - nvl(I.POLICY_DEDUCTABLE_AMT,0))
           else case when cn.document_general_type_id='DTA' and I.PAT_GEN_DETAIL_SEQ_ID is not null
                 and pat_mon_rec.total_app_amount-pre_rec.clm_tot - nvl(v_appr_amt,0) > 0 then nvl(v_appr_amt,0)
           else case when cn.document_general_type_id='DTA' and I.PAT_GEN_DETAIL_SEQ_ID is not null
                 and pat_mon_rec.total_app_amount-pre_rec.clm_tot - nvl(v_appr_amt,0) <= 0
             then  nvl(v_appr_amt,0) else 0 end end  end as pat_diff,

             case when I.PAT_GEN_DETAIL_SEQ_ID is not null then 'Y' else 'N' end as pat_yn,
--koc1277
        
        case when b.mem_age >= 60
          then 'Y' else 'N' end as senior_citizen_yn ,--koc_griavance
    CASE WHEN (case when cn.claim_general_type_id='CNH' then NVL(tipp.Ins_clm_cl_Apr_Rej_Yn,'N') else NVL(tipp.Ins_clm_cm_Apr_Rej_Yn,'N') end )='Y'
        AND CII.CLM_INS_STATUS in ('INP','REQ') AND A.COMPLETED_YN='N' THEN 'Y' ELSE 'N' END AS ins_decision_yn,
        Claims_pkg.claims_ref_ins(a.claim_seq_id,pre_auth_pkg.get_prod_pol_seq_id(a.Claim_Seq_Id,'CLM')) DEN_BAN_YN
        FROM clm_general_details A JOIN clm_enroll_details B ON (A.claim_seq_id = b.claim_seq_id)
        JOIN clm_inward cn on (cn.claims_inward_seq_id=a.claims_inward_seq_id)  --koc1277
  
        left outer join clm_ins_intimation_details cii on (b.claim_seq_id=cii.claim_seq_id)
        LEFT OUTER JOIN buffer_details D ON ( a.last_buffer_detail_seq_id = d.buff_detail_seq_id )
        LEFT OUTER JOIN buffer_header E ON ( D.buffer_hdr_seq_id = E.buffer_hdr_seq_id )
        LEFT OUTER JOIN tpa_enr_policy_member G ON (b.member_seq_id = g.member_seq_id )
        LEFT OUTER JOIN tpa_enr_policy_group H ON (G.policy_group_seq_id = H.policy_group_seq_id )
        LEFT OUTER JOIN pat_general_details I ON (a.pat_enroll_detail_seq_id = I.pat_enroll_detail_seq_id AND I.pat_enhanced_yn = 'N')
        LEFT OUTER JOIN assign_users L ON (A.last_assign_user_seq_id  = L.assign_users_seq_id )
        LEFT OUTER JOIN tpa_user_contacts M ON (L.assigned_to_user = M.contact_seq_id)
        LEFT OUTER JOIN buffer_details N ON ( I.last_buffer_detail_seq_id = N.buff_detail_seq_id )
        LEFT OUTER JOIN buffer_header O ON ( N.buffer_hdr_seq_id = O.buffer_hdr_seq_id )
        LEFT OUTER JOIN tpa_enr_balance Q ON (G.policy_group_seq_id = Q.policy_group_seq_id)
        LEFT OUTER JOIN clm_hospital_association R ON (A.claim_seq_id = R.claim_seq_id)
        LEFT OUTER JOIN tpa_hosp_info S ON ( R.hosp_seq_id = S.hosp_seq_id )
        LEFT OUTER JOIN TPA_ENR_POLICY T ON (T.POLICY_SEQ_ID=B.POLICY_SEQ_ID) --KOC1286
        LEFT OUTER JOIN TPA_INS_PROD_POLICY U ON(U.PRODUCT_SEQ_ID=T.PRODUCT_SEQ_ID) --KOC1286
		LEFT OUTER JOIN TPA_INS_PROD_POLICY pol ON(pol.policy_seq_id=T.policy_seq_id)--added for opd limit bug fix
    LEFT OUTER JOIN Investigation_Details V ON (a.claim_seq_id = v.claim_seq_id)--Added for koc_investigation
    LEFT OUTER JOIN tpa_ins_prod_policy tipp on (pre_auth_pkg.get_prod_pol_seq_id(a.Claim_Seq_Id,'CLM')=tipp.prod_policy_seq_id)
        WHERE A.claim_seq_id = v_claim_seq_id
                AND ( G.mem_general_type_id = 'PFL' AND Q.member_seq_id IS NULL OR b.member_seq_id = Q.member_seq_id OR b.member_seq_id IS NULL);

  END select_settlement;
--- =================================================================================================================
-- Comments : ravi 17jan13 for copay buffer amount against request amount
-- ==================================================================================================================
 PROCEDURE select_prev_claim (
    v_member_seq_id              IN  clm_enroll_details.member_seq_id%TYPE,
    v_result_set                 OUT SYS_REFCURSOR
  )
  IS
    v_max_event                  clm_general_details.event_seq_id%TYPE;
    CURSOR clm_max_event_cur IS SELECT MAX(a.event_seq_id) FROM tpa_event a JOIN tpa_workflow b ON (a.workflow_seq_id = b.workflow_seq_id)
       WHERE b.sub_general_type_id = 'CLM';
  BEGIN

    OPEN  clm_max_event_cur;
    FETCH clm_max_event_cur INTO v_max_event ;
    CLOSE clm_max_event_cur;

    OPEN v_result_set FOR
      WITH claims AS
       ( SELECT X.claim_file_number, X.claim_seq_id , yy.claim_general_type_id
             FROM clm_general_details X JOIN clm_enroll_details Y ON ( x.claim_seq_id = y.claim_seq_id )
             LEFT OUTER JOIN clm_general_details z ON ( x.claim_seq_id = z.parent_claim_seq_id )
             LEFT OUTER JOIN clm_inward zz ON (x.claim_seq_id = zz.claim_seq_id)
             JOIN clm_inward yy ON (x.claims_inward_seq_id = yy.claims_inward_seq_id)
             LEFT OUTER JOIN pat_event_history xx ON (x.claim_seq_id = xx.claim_seq_id)
             WHERE y.member_seq_id = v_member_seq_id AND x.claim_sub_general_type_id != 'CBN'
             AND ( y.clm_status_general_type_id = 'APR' OR ( y.clm_status_general_type_id IN ('REJ','PCO')  AND ( xx.event_seq_id = 20 - 1 AND xx.event_exec_date > y.decision_date OR XX.pat_event_seq_id IS NULL )))  AND x.completed_yn = 'Y'
             AND ( x.requested_amount - NVL(x.total_app_amount,0) - nvl(x.discount_amount,0) - nvl(x.co_payment_amount,0)-nvl(x.co_payment_buffer_amount,0)) > 0  AND ( z.claim_seq_id IS NULL OR zz.inward_status_general_type_id = 'IIP')) --KOCIBM

      SELECT aa.*
              FROM (
             SELECT DISTINCT claim_seq_id,a.pat_enroll_detail_seq_id,  claim_number
             FROM clm_general_details a WHERE claim_seq_id IN
             (SELECT MAX(claim_seq_id) AS claim_seq_id FROM claims WHERE claim_general_type_id = 'CNH'  GROUP BY claim_file_number )
             UNION
             SELECT DISTINCT claim_seq_id,a.pat_enroll_detail_seq_id,  claim_number
             FROM clm_general_details a WHERE claim_seq_id IN
             (SELECT claim_seq_id FROM claims WHERE claim_general_type_id = 'CTM' )
             ) AA
             LEFT OUTER JOIN pat_enroll_details b ON (aA.pat_enroll_detail_seq_id = b.pat_enroll_detail_seq_id)
             LEFT OUTER JOIN pat_general_details c ON (b.pat_enroll_detail_seq_id = c.pat_enroll_detail_seq_id AND c.pat_enhanced_yn = 'N')
             WHERE b.pat_enroll_detail_seq_id IS NULL
                 OR ( b.pat_status_general_type_id = 'APR' AND c.completed_yn = 'Y' AND
                    ( b.claim_id IN ( SELECT cc.claim_seq_id FROM clm_general_details cc
                        WHERE cc.parent_claim_seq_id IS NULL
                          START WITH cc.claim_seq_id = b.claim_id
                          CONNECT BY cc.claim_seq_id = PRIOR parent_claim_seq_id)
                     OR b.claim_id IS NULL)
                     );

  END select_prev_claim;
--=================================================================================================================

  PROCEDURE select_prev_hosps(
    v_claim_type                 IN  CLM_INWARD.claim_general_type_id%TYPE, --CTM -> MR OR CNH -> NHCP
    v_member_seq_id              IN  CLM_ENROLL_DETAILS.member_seq_id%TYPE,
    v_result_set                 OUT SYS_REFCURSOR ,
    v_claim_seq_id               IN  clm_general_details.claim_seq_id%TYPE := 0
  )
  IS
  BEGIN
    IF v_claim_type = 'CTM' THEN -- MR CLAIM
      OPEN v_result_set FOR
        SELECT b.claim_seq_id,
              NVL(E.hosp_name,d.hosp_name )||'-'||TO_CHAR(C.date_of_admission,'DD/MM/YYYY')|| '/' ||TO_CHAR(C.date_of_discharge ,'DD/MM/YYYY') prev_hosp FROM
              ( SELECT MIN(X.claim_seq_id) AS claim_seq_id, y.claim_file_number  FROM clm_enroll_details X JOIN clm_general_details Y ON ( X.claim_seq_id = Y.claim_seq_id )
                 WHERE x.member_seq_id = v_member_seq_id AND X.claim_seq_id != nvl(v_claim_seq_id,0)
                 GROUP BY y.claim_file_number ) a
              JOIN clm_enroll_details b ON ( a.claim_seq_id = b.claim_seq_id )
              JOIN clm_general_details c ON ( b.claim_seq_id = c.claim_seq_id )
              LEFT OUTER JOIN clm_hospital_association d  ON (a.claim_seq_id = d.claim_seq_id )
              LEFT OUTER JOIN tpa_hosp_info e ON (d.hosp_seq_id = e.hosp_seq_id)
              WHERE b.member_seq_id = v_member_seq_id  ;

    ELSE  -- NHCP CLAIM
      OPEN v_result_set FOR
         SELECT a.claim_seq_id,
           NVL( D.hosp_name, C.hosp_name )||'-'||TO_CHAR(date_of_admission,'DD/MM/YYYY')|| '/' ||TO_CHAR(date_of_discharge ,'DD/MM/YYYY') prev_hosp
           FROM clm_general_details a JOIN clm_enroll_details b ON ( a.claim_seq_id = b.claim_seq_id )
           JOIN clm_hospital_association c  ON (a.claim_seq_id = c.claim_seq_id )
           LEFT OUTER JOIN tpa_hosp_info d ON ( c.hosp_seq_id = d.hosp_seq_id )
           JOIN clm_inward E ON (A.claims_inward_SEQ_ID = E.claims_inward_seq_id )
           WHERE b.member_seq_id = v_member_seq_id AND E.claim_general_type_id = 'CTM' AND prev_hosp_claim_seq_id IS NULL;
    END IF;
  END select_prev_hosps;
-- =================================================================================================================

  PROCEDURE select_hosp_all(
    v_prev_hosp_claim_seq_id     IN  CLM_GENERAL_DETAILS.claim_seq_id%TYPE,
    v_result_set                 OUT SYS_REFCURSOR
  )
  IS
  BEGIN
    OPEN v_result_set FOR
      SELECT b.claim_seq_id,
         NVL(D.hosp_name, C.hosp_name )||'-'||TO_CHAR(date_of_admission,'DD/MM/YYYY')|| '/' ||TO_CHAR(date_of_discharge ,'DD/MM/YYYY') prev_hosp ,
         d.hosp_seq_id,
         NVL(D.hosp_name, C.hosp_name ) AS hosp_name ,
         NVL(D.empanel_number,c.empanel_number) AS empanel_number ,
         NVL(E.address_1,c.address_1 ) AS address_1 ,
         NVL(E.Address_2,c.address_2 ) AS address_2 ,
         NVL(E.Address_3,c.address_3 ) AS address_3 ,
         NVL(f.state_name,c.state_name)AS state_name,
         NVL(g.city_description,c.city_name ) AS city_description,
         NVL(e.pin_code,c.pin_code ) AS pin_code,
        ttk_util_pkg.fn_decrypt(d.primary_email_id) as primary_email_id,  --//ED
         NVL(d.off_phone_no_1,c.off_phone_no_1) AS off_phone_no_1,
         NVL(d.off_phone_no_2,c.off_phone_no_2) AS off_phone_no_2 ,
         NVL(d.office_fax_no,c.office_fax_no ) AS office_fax_no,
         i.empanel_description ,
         d.rating,
         b.date_of_admission,
         b.date_of_discharge
         FROM clm_enroll_details a JOIN clm_general_details b ON ( a.claim_seq_id = b.claim_seq_id)
         JOIN clm_hospital_association c  ON (a.claim_seq_id = c.claim_seq_id )
         LEFT OUTER JOIN tpa_hosp_info d ON ( c.hosp_seq_id = d.hosp_seq_id )
         LEFT OUTER JOIN tpa_hosp_address E ON (d.hosp_seq_id = e.hosp_seq_id )
         LEFT OUTER JOIN tpa_state_code F ON (e.state_type_id = f.state_type_id )
         LEFT OUTER JOIN tpa_city_code G ON (E.City_Type_Id = g.city_type_id )
         LEFT OUTER JOIN tpa_hosp_empanel_status h ON ( d.hosp_seq_id = h.hosp_seq_id AND H.Active_Yn = 'Y')
         LEFT OUTER JOIN tpa_hosp_empanel_status_code i ON (h.empanel_status_type_id = i.empanel_status_type_id )
         LEFT OUTER JOIN clm_hospital_additional_dtl j ON (c.clm_hosp_assoc_seq_id = j.clm_hosp_assoc_seq_id)
         WHERE  B.claim_seq_id = v_prev_hosp_claim_seq_id ;
  END select_hosp_all;
-- =================================================================================================================
PROCEDURE set_review (
    v_claim_seq_id                    IN  CLM_GENERAL_DETAILS.claim_seq_id%TYPE,
    v_event_seq_id                    IN  OUT CLM_GENERAL_DETAILS.event_seq_id%TYPE,
    v_review_count                    IN  OUT CLM_GENERAL_DETAILS.review_count%TYPE,
    v_required_review_count           IN  OUT CLM_GENERAL_DETAILS.required_review_count%TYPE,
    v_mode                            IN  CHAR, -- Put it to 'CLM'
    v_type                            IN  CHAR, -- Dummy
    v_added_by                        IN  NUMBER ,
    v_event_name                      OUT VARCHAR2,
    v_review                          OUT VARCHAR2,
    v_coding_review_yn                OUT VARCHAR2,
    v_show_coding_override            OUT VARCHAR2
  )
  IS

    CURSOR clm_info_cur IS SELECT a.completed_yn , b.clm_status_general_type_id  ,a.date_of_admission,a.date_of_discharge,
      a.event_seq_id ,  a.review_count , a.required_review_count, a.rule_execution_flag ,d.claim_general_type_id ,
      e.disch_vouch_seq_id , b.modification_mode_value ,d.document_general_type_id ,f.ailment_details_seq_id
      ,A.claim_sub_general_type_id, b.policy_seq_id,b.member_seq_id,b.enrol_type_id, a.claim_file_number,
      b.policy_number,b.ins_seq_id,b.group_reg_seq_id,a.pat_enroll_detail_seq_id,
      g.total_app_amount AS preauth_approved_amt, a.pat_approved_amount,m.claim_id--,b.clm_ins_status
      FROM clm_general_details a JOIN clm_enroll_details b ON ( a.claim_seq_id =  b.claim_seq_id )
      JOIN clm_inward d ON(a.claims_inward_seq_id = d.claims_inward_seq_id)
      LEFT OUTER JOIN clm_discharge_voucher e ON (a.claim_seq_id = e.claim_seq_id)
      LEFT OUTER JOIN ailment_details f ON ( a.claim_seq_id = f.claim_seq_id )
      LEFT OUTER JOIN pat_general_details g ON (a.pat_enroll_detail_seq_id = g.pat_enroll_detail_seq_id  AND g.pat_enhanced_yn = 'N')
      LEFT OUTER JOIN pat_enroll_details m ON (g.pat_enroll_detail_seq_id = m.pat_enroll_detail_seq_id)
      WHERE a.claim_seq_id = v_claim_seq_id;

    CURSOR bal_cur IS SELECT A.CLAIM_SEQ_ID,b.member_seq_id , NVL(d.utilised_amount,h.utilised_amount) AS utilised_amount , I.mem_general_type_id ,
      NVL(d.claim_app_buffer_amount,h.claim_app_buffer_amount) AS claim_app_buffer_amount,
      nvl(d.pre_auth_buffer_app_amount, h.pre_auth_buffer_app_amount) AS pre_auth_buffer_app_amount,
      I.policy_group_seq_id ,j.balance_seq_id , j.sum_insured , j.bonus , j.buffer_amount , j.utilised_sum_insured ,
      j.utilised_cum_bonus , j.utilised_buff_amount , k.buffer_alloc_general_type_id ,
      f.pat_enroll_detail_seq_id , l.mem_buffer_seq_id ,k.tpa_office_seq_id,
      a.utilised_buff_amt AS current_claim_app_buff,
      nvl(d.buffer_hdr_seq_id , h.buffer_hdr_seq_id) AS buffer_hdr_seq_id,
--policy_deductable
case k.policy_sub_general_type_id when 'PNF' then nvl(i.policy_deductable_yn,'N')
           when 'PFL' then nvl(gr.policy_deductable_yn,'N') end as policy_deductable_yn ,a.total_app_amount,
--policy_deductable
      nvl(g.claim_type,c.claim_type) as claim_type,nvl(g.buffer_type,c.buffer_type) as buffer_type,j.med_buffer_amount,j.critical_buff_amount,j.critical_corp_buff_amount,j.critical_med_buff_amount,
      j.utilised_med_buff_amount,j.utilised_crit_buff_amount,j.utilised_crit_corp_buff_amt,j.utilised_crit_med_buff_amt,
      A.UTILISED_BUFF_AMT AS curr_claim_utilised_buff,
      ci.document_general_type_id,ci.claim_general_type_id,
      b.clm_status_general_type_id as clm_status
      FROM clm_general_details a JOIN clm_enroll_details b ON (a.claim_seq_id = b.claim_seq_id)
      JOIN clm_inward ci on (a.claims_inward_seq_id= ci.claims_inward_seq_id)
      LEFT OUTER JOIN buffer_details c ON (a.last_buffer_detail_seq_id = c.buff_detail_seq_id)
      LEFT OUTER JOIN buffer_header d ON (c.buffer_hdr_seq_id = d.buffer_hdr_seq_id)
      LEFT OUTER JOIN pat_general_details f ON (a.pat_enroll_detail_seq_id = f.pat_enroll_detail_seq_id)
      LEFT OUTER JOIN buffer_details g ON (f.last_buffer_detail_seq_id = g.buff_detail_seq_id)
      LEFT OUTER JOIN buffer_header h ON (g.buffer_hdr_seq_id = h.buffer_hdr_seq_id)
      LEFT OUTER JOIN tpa_enr_policy_member I ON (b.member_seq_id = I.member_seq_id)
      LEFT OUTER JOIN tpa_enr_policy_group gr on (gr.policy_group_seq_id=i.policy_group_seq_id) --policy_deductable
      LEFT OUTER JOIN tpa_enr_balance j ON (i.policy_group_seq_id = j.policy_group_seq_id)
      LEFT OUTER JOIN tpa_enr_policy k ON (b.policy_seq_id = k.policy_seq_id)
      LEFT OUTER JOIN tpa_enr_mem_buffer L ON ( i.member_seq_id = l.member_seq_id )
      WHERE a.claim_seq_id = v_claim_seq_id AND NVL( f.pat_enhanced_yn,'N' ) = 'N'
         AND (I.mem_general_type_id = 'PFL' AND j.member_seq_id IS NULL OR b.member_seq_id = j.member_seq_id OR b.member_seq_id IS NULL );

    CURSOR prod_policy_cur IS
      SELECT CASE WHEN b.prod_policy_seq_id IS NOT NULL THEN b.dv_reqd_general_type_id
        ELSE c.dv_reqd_general_type_id END AS dv_reqd_general_type_id
      FROM tpa_enr_policy a LEFT OUTER JOIN tpa_ins_prod_policy b ON (a.policy_seq_id = b.policy_seq_id)
      LEFT OUTER JOIN tpa_ins_prod_policy c ON (a.product_seq_id = c.product_seq_id)
      JOIN clm_enroll_details d ON (a.policy_seq_id = d.policy_seq_id)
      WHERE d.claim_seq_id = v_claim_seq_id;

    balance_rec                          bal_cur%ROWTYPE;
    v_max_event_seq_id                   TPA_ENR_POLICY.event_seq_id%TYPE;
    v_completed_yn                       CLM_GENERAL_DETAILS.completed_yn%TYPE := 'N';
    v_override_restrict_yn               CLM_GENERAL_DETAILS.OVERRIDE_RESTRICT_YN%TYPE;
    v_clm_status                         CLM_ENROLL_DETAILS.clm_status_general_type_id%TYPE;
    v_assign_users_seq_id                ASSIGN_USERS.assign_users_seq_id%TYPE;
    v_rule_execution_flag                CLM_GENERAL_DETAILS.rule_execution_flag%TYPE;
    v_unused_buff                        NUMBER(20);
    v_date_of_admission                  DATE;
    v_date_of_discharge                  DATE;
    v_rule_exec_mandatory_yn             tpa_system_parameters.rule_exec_mandatory_yn%TYPE;
    v_dv_reqd_general_type_id            tpa_ins_prod_policy.dv_reqd_general_type_id%TYPE;
    v_status                             VARCHAR2(60):= 'PENDING';
    v_claim_general_type_id              clm_inward.claim_general_type_id%TYPE;
    v_disch_vouch_seq_id                 clm_discharge_voucher.disch_vouch_seq_id%TYPE;
    v_modification_mode_value            clm_enroll_details.modification_mode_value%TYPE;
    v_ctr                                NUMBER(5);
    v_second_event                       tpa_event.event_seq_id%TYPE;
    v_dest_msg_seq_id                    VARCHAR2(250);
    v_doc_general_type_id                clm_inward.document_general_type_id%TYPE;
    v_max_code_event                     tpa_event.event_seq_id%TYPE;
    v_ailment_details_seq_id             ailment_details.ailment_details_seq_id%TYPE;
    v_claim_sub_general_type_id          clm_general_details.claim_sub_general_type_id%TYPE;
    v_policy_seq_id                      clm_enroll_details.policy_seq_id%TYPE;
    v_enrol_type_id                      clm_enroll_details.enrol_type_id%TYPE;
    v_member_seq_id                      clm_enroll_details.member_seq_id%TYPE;
    v_claim_id                           pat_enroll_details.claim_id%TYPE;
    v_prev_event_seq_id                  clm_general_details.event_seq_id%TYPE;
    v_prev_review_count                  clm_general_details.review_count%TYPE;
    v_prev_required_review_count         clm_general_details.required_review_count%TYPE;
    v_clm_cash_benefit_seq_id            clm_cash_benefit.clm_cash_benefit_seq_id%TYPE;
    v_claim_file_number                  clm_general_details.claim_file_number%TYPE;
    v_policy_number                      clm_enroll_details.policy_number%TYPE;
    v_ins_seq_id                         clm_enroll_details.ins_seq_id%TYPE;
    v_group_reg_seq_id                   clm_enroll_details.group_reg_seq_id%TYPE;
    v_prev_appr_count                    PLS_INTEGER := 0;
    v_pat_enroll_detail_seq_id           pat_enroll_details.pat_enroll_detail_seq_id%TYPE;
    v_pat_total_app_amount               clm_general_details.pat_approved_amount%TYPE;
    v_pat_approved_amount                clm_general_details.pat_approved_amount%TYPE;
    v_notify_typ_id                      tpa_ins_info.notify_type_id%type;--koc_ins_mail
    v_ins_name                           tpa_ins_info.ins_comp_name%type;--koc_ins_mail
    v_cigna_yn                           varchar2(1);--koc_ins_mail
    V_CLAIMS_CHK_SEQ_ID                  tpa_claims_check.claims_chk_seq_id%TYPE;    --koc1277
--  v_clm_ins_status                     clm_enroll_details.clm_ins_status%type;


   CURSOR event_cur IS SELECT a.event_seq_id
      FROM tpa_event a JOIN tpa_workflow b ON (a.workflow_seq_id = b.workflow_seq_id)
        AND b.sub_general_type_id = v_mode AND a.event_owner NOT IN ('C','M')
        AND a.event_seq_id >= v_second_event ORDER BY a.event_seq_id;

    CURSOR icd_cur IS SELECT COUNT(1)
            FROM  icd_pcs_detail a WHERE a.claim_seq_id = v_claim_seq_id;

   CURSOR prev_appr_cur IS  SELECT COUNT(1) FROM
    ( SELECT a.claim_seq_id, a.parent_claim_seq_id
      FROM clm_general_details a START WITH a.claim_seq_id = v_claim_seq_id CONNECT BY a.claim_seq_id = PRIOR a.parent_claim_seq_id ) aa
      JOIN clm_enroll_details bb ON (aa.claim_seq_id = bb.claim_seq_id )
      WHERE bb.clm_status_general_type_id = 'APR' AND aa.claim_seq_id != v_claim_seq_id ;

--koc1277
 CURSOR fin_cur is
   select au.assigned_date,pay.approved_amount,pay.claim_aprv_date,pay.payee_name,pay.payment_seq_id from fin_app.tpa_claims_payment pay
   left outer join clm_general_details ge on (ge.claim_seq_id=pay.claim_seq_id)
   left outer join clm_enroll_details bb ON (ge.claim_seq_id = bb.claim_seq_id )
   left outer join assign_users au on (au.claim_seq_id=ge.claim_seq_id and au.pat_status_general_type_id= 'APR')
    where bb.clm_status_general_type_id = 'APR' and ge.claim_seq_id= v_claim_seq_id;

    fin_rec  fin_cur%rowtype; --koc1277
    v_diag_cnt number(5);   --koc decoupling
    v_icd_cnt number(5);
    v_new_clm number(1); --remove v_new_clm condition after existing claims is taken care   --koc decoupling


  BEGIN


    -- Getting the Maximum Event Seq id for Enrollment OR Enrollment
    SELECT MAX(event_seq_id) INTO v_max_event_seq_id
      FROM tpa_event A JOIN tpa_workflow B ON ( A.workflow_seq_id = B.workflow_seq_id )
     WHERE B.sub_general_type_id = v_mode ;

    SELECT A.event_seq_id INTO v_second_event
      FROM tpa_event A JOIN tpa_workflow B ON ( A.workflow_seq_id = B.workflow_seq_id )
     WHERE B.sub_general_type_id = v_mode AND A.order_number = 2;

    SELECT MAX(AA.event_seq_id) INTO v_max_code_event
      FROM tpa_event aa JOIN tpa_workflow bb ON (aa.workflow_seq_id = bb.workflow_seq_id)
               AND bb.sub_general_type_id = v_mode AND aa.event_owner = 'C';

    OPEN clm_info_cur ;
    FETCH clm_info_cur INTO v_completed_yn , v_clm_status  , v_date_of_admission ,v_date_of_discharge, v_event_seq_id , v_review_count ,
        v_required_review_count, v_rule_execution_flag , v_claim_general_type_id , v_disch_vouch_seq_id,
        v_modification_mode_value ,v_doc_general_type_id,v_ailment_details_seq_id, v_claim_sub_general_type_id,
        v_policy_seq_id, v_member_seq_id,v_enrol_type_id,v_claim_file_number,
        v_policy_number,v_ins_seq_id,v_group_reg_seq_id,v_pat_enroll_detail_seq_id,
        v_pat_total_app_amount,v_pat_approved_amount,v_claim_id;--,v_clm_ins_status;
    CLOSE clm_info_cur ;

  --claims_freeze(v_claim_seq_id,v_clm_ins_status,'R'); --KOCBJJ TO PROMOTE AT CODING LEVEL FOR INS STATUS AS 'REQUIRED INFORMATION'

  claims_freeze(v_claim_seq_id,v_clm_status,'S'); --KOCBJJ

    IF nvl(v_pat_total_app_amount,0) != nvl(v_pat_approved_amount,0) THEN
      raise_application_error(-20182,'Associated Preauth is overridden/re-associated to another claim, please re-associate preauth.');
    END IF;

    IF v_pat_enroll_detail_seq_id IS NOT NULL THEN
      SELECT COUNT(1) INTO v_ctr FROM
      (
      SELECT a.claim_seq_id FROM clm_general_details a JOIN clm_enroll_details b ON (a.claim_seq_id = b.claim_seq_id)
           WHERE a.pat_enroll_detail_seq_id = v_pat_enroll_detail_seq_id
             AND ( a.completed_yn = 'N' OR b.clm_status_general_type_id NOT IN ('REJ','PCO'))
      MINUS
      SELECT a.claim_seq_id FROM clm_general_details a
        START WITH a.claim_seq_id = v_claim_seq_id
        CONNECT BY PRIOR a.parent_claim_seq_id = a.claim_seq_id);

      IF v_ctr > 1 THEN
        raise_application_error(-20182,'Associated Preauth is overridden/re-associated to another claim, please re-associate preauth.');
      END IF;
    END IF;

  --koc decoupling
  select count(1) into v_new_clm from clm_data_entry_complete dc where dc.claim_seq_id=v_claim_seq_id;  --remove v_new_clm condition after existing claims is taken care
  
 select count(1) into v_diag_cnt from tpa_diagnosys_details d
      where d.claim_seq_id = v_claim_seq_id;

 select count(1) into v_icd_cnt  from icd_pcs_detail i
      where i.claim_seq_id = v_claim_seq_id;    
  
  if v_event_seq_id=17 and  v_diag_cnt != v_icd_cnt and nvl(v_claim_sub_general_type_id,'CSH') !='HCU'
    and v_new_clm > 0 then  --remove v_new_clm condition after existing claims is taken care
      Raise_application_error(-20883,'Mismatch beteween No of Diagnosis Entered, and No of Ailments Entered'); 
  end if;
  
   if  v_event_seq_id=16 and  v_diag_cnt = 0  and nvl(v_claim_sub_general_type_id,'CSH') !='HCU'
     and v_new_clm > 0 then  --remove v_new_clm condition after existing claims is taken care
      Raise_application_error(-20884,'Please Add Diagnosis Deatils, Before Promoting'); 
  end if;

   if v_event_seq_id=17 and nvl(v_claim_sub_general_type_id,'CSH') !='HCU' then 
    pre_auth_pkg.save_icd_pkg(v_seq_id => v_claim_seq_id,
                                         v_scr_mode => 'CLM',
                                         v_added_by => v_added_by);
   end if;
  
 --koc decoupling 

    v_ctr:= NULL;

    v_prev_event_seq_id          :=  v_event_seq_id;
    v_prev_review_count          :=  v_review_count;
    v_prev_required_review_count :=  v_required_review_count;



    IF v_review_count = v_required_review_count THEN
      IF v_claim_sub_general_type_id != 'HCU'  THEN
        IF v_ailment_details_seq_id IS NULL AND v_event_seq_id = v_max_code_event-1 THEN
          raise_application_error(-20146,'Please enter medical informations.');
        ELSIF v_event_seq_id = v_max_code_event THEN
          OPEN icd_cur;
          FETCH icd_cur INTO v_ctr;
          CLOSE icd_cur;

          IF v_ctr = 0 THEN
            raise_application_error(-20147,' Please complete coding. ');
          END IF;
        END IF;
      END IF;
      IF /*v_event_seq_id = v_second_event - 1  AND*/ v_member_seq_id IS NOT NULL  THEN
          -- hospital cash benefit.
          -- check for cash benefit exists for this member and if so save reocrd in clm_cash_benefit table
          check_cash_benefit(
              v_clm_cash_benefit_seq_id,
              v_claim_seq_id ,
              v_member_seq_id,
              v_claim_file_number,
              v_date_of_admission,
              v_date_of_discharge,
              v_added_by
            );
      END IF;
    END IF;


    IF v_max_event_seq_id != v_event_seq_id THEN
      --==============================================================================
      --locking CLAIM
      TTK_UTIL_PKG.reset_id_flag(v_claim_seq_id||'-CLM','Y');
      --Reassigning Claim
      pre_auth_pkg.reassign_user (  NULL , v_claim_seq_id ,NULL , v_added_by , 'REV');

      IF ( v_event_seq_id = v_max_event_seq_id - 1 ) AND v_review_count = v_required_review_count  THEN

             claims_freeze(v_claim_seq_id,NULL,'R'); --KOCBJJ


         IF v_disch_vouch_seq_id IS NOT NULL THEN
           raise_application_error(-20196,'Delete the discharge voucher, which was generated before the overriding of the Claim');
         END IF;
         IF v_claim_general_type_id != 'CNH' THEN -- Discharge voucher only for member claims.
           OPEN prod_policy_cur;
           FETCH prod_policy_cur INTO v_dv_reqd_general_type_id;
           CLOSE prod_policy_cur;

           IF v_dv_reqd_general_type_id = 'DRQ' THEN
               v_status := 'VOUCHER PENDING';
           END IF;
         END IF;

         OPEN bal_cur;
         FETCH bal_cur INTO balance_rec;
         CLOSE bal_cur;

         IF v_clm_status = 'INP' OR v_clm_status = 'REQ' THEN
           raise_application_error (-20158, ' Please complete the settlement ');
         ELSIF v_clm_status = 'APR' THEN
           IF v_modification_mode_value > 0 THEN
              v_ctr:= NULL;
              policy_enrollment_pkg.check_enrollment_change ( v_modification_mode_value , v_ctr );
           END IF;

           IF nvl(v_rule_execution_flag,0) != 2 THEN
             -- Checking rule execution check is mandatory for completion or not.
             SELECT a.rule_exec_mandatory_yn INTO v_rule_exec_mandatory_yn
                FROM tpa_system_parameters a ;
             IF  NVL(v_rule_exec_mandatory_yn,'Y') = 'Y' THEN
               raise_application_error (-20188,' Do Rule Initiate Check, before completing Reviews ');
             END IF;
           END IF;

           -- Writing to Finance table TPA_CLAIMS_PAYMENT  -- Written by PRAKASH
           -----------------------------------------------

           SELECT COUNT(1) INTO v_ctr
            FROM tpa_enr_policy a
            WHERE a.policy_seq_id = v_policy_seq_id
              AND a.policy_number = v_policy_number
              AND a.ins_seq_id    = v_ins_seq_id
              AND ( v_group_reg_seq_id IS NULL OR a.group_reg_seq_id = v_group_reg_seq_id );

           IF v_ctr != 1 THEN
             raise_application_error(-20696, 'Data mismatch exist between Claim and Enrollment.');
           END IF;

            save_claims_payment (
              v_claim_seq_id   ,
              v_status ,
              v_enrol_type_id ,
              v_policy_seq_id ,
              v_member_seq_id ,
              v_claim_general_type_id  ,
              v_added_by
            );
     --koc1277
           if balance_rec.policy_deductable_yn = 'Y' and nvl(balance_rec.total_app_amount,0) = 0 then

         OPEN fin_cur;
         FETCH fin_cur INTO fin_rec;
         CLOSE fin_cur;

          insert into fin_app.tpa_claims_check(CLAIMS_CHK_SEQ_ID,CHECK_NUM,check_date,check_status,check_amount,added_by,added_date,payment_type,courier_number,courier_delivery_date,comments)
          values (fin_app.claims_chk_seq.NEXTVAL,'NA',trunc(fin_rec.assigned_date),'CSI',nvl(balance_rec.total_app_amount,0),v_added_by,sysdate,null,'NA',trunc(fin_rec.assigned_date),'CHECK ISSUED WITH ZERO, FOR POLICY DEDUCTABLE CASES') returning CLAIMS_CHK_SEQ_ID into V_CLAIMS_CHK_SEQ_ID;

          insert into  fin_app.tpa_payment_checks_details(payment_check_seq_id,payment_seq_id,claims_chk_seq_id,added_by,added_date,deleted_yn,v_csr_flag)
          values (fin_app.claims_payment_check_seq.NEXTVAL,fin_rec.payment_seq_id,V_CLAIMS_CHK_SEQ_ID,v_added_by,sysdate,'N',null);

          update fin_app.tpa_claims_payment pay
          set pay.paid_amount = nvl(balance_rec.total_app_amount,0),
          pay.claim_payment_status = 'PAID'
          where pay.payment_seq_id = fin_rec.payment_seq_id;

          end if;
--koc1277

         ELSIF v_clm_status = 'REJ' OR v_clm_status = 'PCO' THEN

           UPDATE clm_bill_details a SET
             a.allowed_amount = NULL,
             a.rejected_amount = a.requested_amount
             WHERE a.clm_bill_seq_id IN ( SELECT x.clm_bill_seq_id
                                        FROM clm_bill_header x WHERE x.claim_seq_id = v_claim_seq_id );

           IF v_pat_enroll_detail_seq_id IS NOT NULL AND app.maintenance_pkg.get_prev_approve_count(v_claim_seq_id) = 0  THEN
              UPDATE pat_enroll_details a
                 SET a.claim_id = NULL
                 WHERE a.pat_enroll_detail_seq_id = v_pat_enroll_detail_seq_id ;
           END IF;

         END IF;

         IF ( v_clm_status = 'APR' OR v_clm_status = 'REJ' OR v_clm_status = 'PCO' ) AND balance_rec.buffer_hdr_seq_id IS NOT NULL THEN
        
           IF (NVL(balance_rec.Pre_Auth_Buffer_App_Amount,0)+NVL(balance_rec.Claim_App_Buffer_Amount,0))>0 OR  balance_rec.curr_claim_utilised_buff > 0 THEN
             check_buff_approved(balance_rec.claim_seq_id,balance_rec.balance_seq_id,balance_rec.curr_claim_utilised_buff,'FINPROMOTE',v_added_by);
             IF balance_rec.claim_general_type_id='CTM' AND  (v_clm_status = 'REJ' OR v_clm_status = 'PCO') THEN
               delete from buffer_details a where a.buffer_hdr_seq_id = balance_rec.buffer_hdr_seq_id;
               delete from buffer_header a where a.buffer_hdr_seq_id = balance_rec.buffer_hdr_seq_id;
             END IF;
           END IF;
         END IF;

         IF v_clm_status IN ('REJ','PCO')  THEN
           IF v_pat_enroll_detail_seq_id IS NOT NULL AND v_claim_id IS NULL THEN
            -- deleting buffer records of claims for which the preauth was associated
              SELECT COUNT(1) INTO v_ctr
                             FROM clm_general_details a WHERE a.pat_enroll_detail_seq_id = v_pat_enroll_detail_seq_id
                              AND a.claim_seq_id NOT IN ( SELECT b.claim_seq_id FROM clm_general_details b
                                  START WITH b.claim_seq_id = v_claim_seq_id CONNECT BY PRIOR b.parent_claim_seq_id = b.claim_seq_id );
             IF v_ctr > 0 THEN
               FOR rec IN ( SELECT b.claim_seq_id,b.last_buffer_detail_seq_id FROM clm_general_details b
                                  START WITH b.claim_seq_id = v_claim_seq_id CONNECT BY PRIOR b.parent_claim_seq_id = b.claim_seq_id
                            ORDER BY b.claim_seq_id DESC)
               LOOP
                 IF rec.last_buffer_detail_seq_id IS NOT NULL THEN
                   pre_auth_pkg.delete_claim_buffer(rec.claim_seq_id) ;
                 END IF;
               END LOOP;
             END IF;
           END IF;
         END IF;
         -- Saving EVENT HISTORY Information
         pre_auth_pkg.save_event_history( 0, NULL, v_claim_seq_id , v_event_seq_id , v_review_count, v_added_by, v_added_by );

         v_completed_yn := 'Y';
         v_override_restrict_yn :=CASE WHEN balance_rec.claim_general_type_id='CNH' THEN
                                       CASE WHEN  balance_rec.clm_status = 'APR' AND  ((balance_rec.pre_auth_buffer_app_amount+NVL( balance_rec.Claim_App_Buffer_Amount,0)>NVL(balance_rec.curr_claim_utilised_buff,0) AND balance_rec.Document_General_Type_Id='DTC') OR (balance_rec.Document_General_Type_Id='DTA' AND NVL( balance_rec.Claim_App_Buffer_Amount,0)>NVL(balance_rec.curr_claim_utilised_buff,0) )) then 
                                         'Y' 
                                       ELSE 'N' END
                                  ELSE 'N' END;
         v_review_count :=  0;
         v_event_seq_id :=  v_event_seq_id + 1;
      ELSE
        -- Saving EVENT HISTORY Information
        pre_auth_pkg.save_event_history( 0, NULL, v_claim_seq_id , v_event_seq_id , v_review_count, v_added_by, v_added_by );

        -- The below if condition is added for CR - KOC10144.
        IF v_event_seq_id = v_max_code_event-1 THEN
           app.coding_pkg.save_coding_search('CLM',v_claim_seq_id,'INSERT');
        ELSE
           app.coding_pkg.save_coding_search('CLM',v_claim_seq_id,'DELETE');
        END IF;

        IF v_review_count < v_required_review_count THEN
            v_review_count := v_review_count + 1;
        ELSIF v_event_seq_id < v_max_event_seq_id THEN
            v_review_count := 1;
            v_event_seq_id := v_event_seq_id + 1;
        END IF;
      END IF;

      IF v_event_seq_id = v_second_event AND v_review_count = 1 AND v_doc_general_type_id = 'DTA' THEN
        OPEN event_cur;
        FETCH event_cur INTO v_event_seq_id;
        CLOSE event_cur;
      END IF;

      -- Getting the REQUIRED_REVIEW_COUNT for the EVENT_SEQ_ID.
      SELECT simple_review_count INTO  v_required_review_count
        FROM tpa_event A JOIN tpa_workflow B ON (A.workflow_seq_id = B.workflow_seq_id)
       WHERE B.sub_general_type_id  = v_mode  AND A.event_seq_id = v_event_seq_id ;

      UPDATE clm_general_details a SET
          review_count          = v_review_count,
          event_seq_id          = v_event_seq_id,
          required_review_count = v_required_review_count,
          completed_yn          = v_completed_yn,
          updated_by            = v_added_by,
          last_assign_user_seq_id = nvl(v_assign_users_seq_id,last_assign_user_seq_id ),
          updated_date          = SYSDATE,
          clm_cash_benefit_seq_id =  nvl(v_clm_cash_benefit_seq_id,clm_cash_benefit_seq_id),
          A.override_restrict_yn  = v_override_restrict_yn
          WHERE claim_seq_id    = v_claim_seq_id
            AND a.event_seq_id = v_prev_event_seq_id
            AND a.review_count = v_prev_review_count
          RETURNING last_assign_user_seq_id INTO v_assign_users_seq_id;



      IF SQL%ROWCOUNT != 0 THEN

        IF v_event_seq_id = v_second_event AND v_review_count = 1 THEN
    --koc_ins_mail
   SELECT NVL(I.NOTIFY_TYPE_ID,'NIG'),i.ins_comp_name INTO v_notify_typ_id,v_ins_name FROM CLM_ENROLL_DETAILS ED 
   LEFT OUTER JOIN TPA_INS_INFO I ON (ED.INS_SEQ_ID=I.INS_SEQ_ID)
   WHERE ED.CLAIM_SEQ_ID=v_claim_seq_id;

   if v_ins_name like 'CIGNA%' AND v_notify_typ_id='NIC' THEN
     v_cigna_yn:='Y';
    ELSE
      v_cigna_yn:='N';
   END IF;
  --koc_ins_mail
  IF v_cigna_yn!='Y' THEN--koc_ins_mail
          IF v_claim_general_type_id = 'CTM' THEN
            app.GENERATE_MAIL_PKG.proc_form_message ( 'CLAIM_STATUS_MR', v_claim_seq_id,v_added_by , v_dest_msg_seq_id);
          ELSE
            app.GENERATE_MAIL_PKG.proc_form_message ( 'CLAIM_STATUS_NHCP', v_claim_seq_id,v_added_by , v_dest_msg_seq_id);
          END IF;
      END IF;--koc_ins_mail
        END IF;
        COMMIT;
      ELSE
        v_event_seq_id := v_prev_event_seq_id;
        v_review_count := v_prev_review_count;
        v_required_review_count := v_prev_required_review_count;
        ROLLBACK;
      END IF;
    END IF;

    SELECT event_name, CASE WHEN event_owner = 'C' THEN 'Y' ELSE 'N' END ,
       CASE WHEN v_event_seq_id > v_max_code_event AND v_completed_yn = 'N' THEN 'Y' ELSE 'N' END
    INTO v_event_name, v_coding_review_yn , v_show_coding_override
      FROM tpa_event  WHERE event_seq_id = v_event_seq_id;

    v_event_name   := 'Event :'|| v_event_name ;
    v_review := TO_CHAR(v_review_count)||'('||TO_CHAR(v_required_review_count)||')';

  END set_review;

-- =================================================================================================================
  -- author      : s.v sreeraj
  -- modified by : ravi on 06dec12
  -- purpose     : for cr koc1107,koc1109 to check all rule remarks entered or not
  -- Comments    : for segregation of copay amounts KOCIBM
-- =========================================================================
  PROCEDURE save_settlement (
    v_assign_users_seq_id                IN  OUT ASSIGN_USERS.assign_users_seq_id%TYPE,
    v_claim_seq_id                       IN  ASSIGN_USERS.claim_seq_id%TYPE,
    v_mem_total_sum_insured              IN  PAT_ENROLL_DETAILS.mem_total_sum_insured %TYPE,
    v_remarks                            IN  ASSIGN_USERS.remarks%TYPE,
    v_claim_settlement_number            IN  OUT CLM_GENERAL_DETAILS.claim_settlement_number%TYPE,
    v_pat_status_general_type_id         IN  ASSIGN_USERS.pat_status_general_type_id%TYPE,
    v_permission_sought_from             IN  CLM_GENERAL_DETAILS.permission_sought_from%TYPE,
    v_balance_seq_id                     IN  tpa_enr_balance.balance_seq_id%TYPE,
    v_max_app_amount                     IN  OUT ASSIGN_USERS.total_app_amount%TYPE,
    v_added_by                           IN  ASSIGN_USERS.added_by%TYPE,
    v_rson_general_type_id               IN  ASSIGN_USERS.rson_general_type_id%TYPE,
    v_discount_amount                    IN  OUT clm_general_details.discount_amount%TYPE,
    v_co_payment_amount                  IN  OUT clm_general_details.co_payment_amount%TYPE,
    v_deposit_amount                     IN  OUT clm_general_details.deposit_amount%TYPE,
    v_service_tax_calc_amt               IN  clm_general_details.serv_tax_calc_amount%TYPE,
    v_serv_tax_calc_percentage           IN  clm_general_details.serv_tax_calc_percentage%TYPE,
    v_co_pay_buff_amount                 IN  OUT clm_general_details.co_payment_buffer_amount%TYPE, --KOCIBM
    v_rest_amt                           in  tpa_enr_balance.restrict_amt%type:=null, --koc1142
    v_used_rest_si                       in  tpa_enr_balance.used_restrict_amt%type:=0, --koc1142
    v_restrict_yn                        in  varchar2:=null, --koc1142
    v_pd                                 IN OUT tpa_enr_balance.policy_deductable_amt%TYPE,--koc1277
    v_FINAL_APP_YN                       IN  clm_general_details.final_app_yn%type,--koc_ins_mail
    v_Inv_Disallowed_Amt                 IN  clm_general_details.Inv_Disallowed_Amt%TYPE:=null, --Added for koc_investigation
    v_rows_processed                     IN  OUT NUMBER
  )
  IS
    CURSOR clm_state_cur IS
      SELECT A.completed_yn , c.tpa_office_seq_id , A.claim_number, A.claim_settlement_number ,a.inv_disallowed_amt, --Added for koc_investigation
         B.clm_enroll_detail_seq_id  , NVL(d.buffer_hdr_seq_id,J.buffer_hdr_seq_id) AS buffer_hdr_seq_id , c.claim_general_type_id , b.clm_status_general_type_id ,
         e.member_seq_id, e.mem_general_type_id ,a.total_app_amount , a.app_sum_insured ,
         a.app_cum_bonus ,NVL( f.claim_app_buffer_amount,J.claim_app_buffer_amount) AS claim_app_buffer_amount ,
         NVL(F.pre_auth_buffer_app_amount, J.pre_auth_buffer_app_amount) AS pre_auth_buffer_app_amount,
         NVL(f.utilised_amount,J.utilised_amount) utilised_amount ,e.policy_group_seq_id,
         h.app_sum_insured AS pat_app_sum, h.app_cum_bonus AS pat_app_bonus  ,
         (k.sum_insured - k.utilised_sum_insured) AS ava_sum_insured ,
         (k.bonus - k.utilised_cum_bonus) AS ava_cum_bonus ,
         k.balance_seq_id , c.document_general_type_id , a.pat_approved_amount ,
         k.utilised_sum_insured, k.utilised_cum_bonus , 
         k.sum_insured, k.bonus ,
         l.buffer_alloc_general_type_id ,a.claim_sub_general_type_id ,
         m.mem_buffer_seq_id,m.used_buff_amount, l.tpa_office_seq_id AS policy_tpa_office_seq_id ,l.endorsement_seq_id ,
         a.date_of_admission , b.policy_effective_from , L.enrol_type_id , a.requested_amount ,
         a.pat_enroll_detail_seq_id ,a.discount_amount, a.co_payment_amount,a.co_payment_buffer_amount, --KOCIBM
         a.serv_tax_calc_amount,a.serv_tax_calc_percentage,a.total_app_vst, --Added for koc1320
         a.utilised_buff_amt AS curr_claim_buff_utilised,a.rule_execution_flag,
         o.trtmnt_plan_general_type_id,p.clm_cash_benefit_seq_id,a.deposit_amount,
         CASE WHEN l.enrol_type_id = 'COR' THEN l.admin_status_general_type_id ELSE n.prod_status_general_type_id END AS rule_execution_status,
         L.policy_sub_general_type_id,
         q.rson_general_type_id, q.remarks,b.modification_mode_value ,
         ail.SPECIALTY_GENERAL_TYPE_ID,   --KOC1164
         h.total_app_amount AS preauth_approved_amt,A.DOC_CERT_DOM_YN,a.date_of_discharge,A.OPD_UTILSED_AMOUNT,A.OPD_FLAG_YN, --KOC1286 koc1285
         h.pat_gen_detail_seq_id,k.restrict_amt,k.used_restrict_amt,(k.restrict_amt-k.used_restrict_amt) as ava_res_amt, ---koc1142
         l.policy_seq_id,
         --policy_deductable
         case l.policy_sub_general_type_id when 'PNF' then nvl(e.policy_deductable_yn,'N')
           when 'PFL' then nvl(gr.policy_deductable_yn,'N') end as policy_deductable_yn,a.policy_deductable_amt,
         h.policy_deductable_amt as pat_policy_deductable_amt,
         k.policy_deductable_amt-k.utilised_policy_deductable_amt as bal_pd_amt,hs.hosp_seq_id, r.pat_status_general_type_id ,e.tpa_enrollment_id,
         --policy_deductable
         --koc1273
         n.product_seq_id,e.mem_age,
         ail.diagnosis_dt,ail.date_of_certificate ,nvl(gr.critical_cash_benefit_yn,'N') critical_cash_benefit_yn,e.date_of_inception,
         --koc1273
         nvl(i.claim_type,d.claim_type) as claim_type,nvl(i.buffer_type,d.buffer_type) as buffer_type,m.used_med_buff_amt,m.used_crit_buff_amt,m.used_crit_corp_buff_amt,m.used_crit_med_buff_amt
      
         FROM clm_general_details A JOIN clm_enroll_details B ON ( a.claim_seq_id  = b.claim_seq_id )
         JOIN clm_inward C ON (A.claims_inward_seq_id = C.claims_inward_seq_id)
         LEFT OUTER JOIN clm_hospital_association hs ON (A.claim_seq_id = hs.claim_seq_id) --koc1277
         LEFT OUTER JOIN ailment_details ail ON (a.claim_seq_id = ail.claim_seq_id)         --koc 1164
         LEFT OUTER JOIN buffer_details D ON (a.last_buffer_detail_seq_id = d.buff_detail_seq_id )
         LEFT OUTER JOIN tpa_enr_policy_member E ON (b.member_seq_id = e.member_seq_id)
         LEFT OUTER JOIN tpa_enr_policy_group gr ON (gr.policy_group_seq_id = e.policy_group_seq_id)    --koc1273 1277
         LEFT OUTER JOIN buffer_header f ON (d.buffer_hdr_seq_id = f.buffer_hdr_seq_id)
         LEFT OUTER JOIN pat_general_details h ON (a.pat_enroll_detail_seq_id = h.pat_enroll_detail_seq_id)
         LEFT OUTER JOIN buffer_details I ON (H.last_buffer_detail_seq_id = I.buff_detail_seq_id)
         LEFT OUTER JOIN buffer_header J ON ( I.buffer_hdr_seq_id = J.buffer_hdr_seq_id )
         LEFT OUTER JOIN tpa_enr_balance k ON (e.policy_group_seq_id = k.policy_group_seq_id AND k.balance_seq_id = v_balance_seq_id )
         LEFT OUTER JOIN tpa_enr_policy  L ON (b.policy_seq_id = l.policy_seq_id )
         LEFT OUTER JOIN tpa_enr_mem_buffer M ON (e.member_seq_id = m.member_seq_id)
         LEFT OUTER JOIN tpa_ins_product n ON (l.product_seq_id = n.product_seq_id)
         LEFT OUTER JOIN icd_pcs_detail O ON (A.claim_seq_id = O.claim_seq_id)
         LEFT OUTER JOIN clm_cash_benefit P ON (a.claim_seq_id = p.claim_seq_id)
         LEFT OUTER JOIN assign_users q ON (a.last_assign_user_seq_id = q.assign_users_seq_id)
         LEFT OUTER JOIN pat_enroll_details r ON (a.pat_enroll_detail_seq_id = r.pat_enroll_detail_seq_id)
         WHERE a.claim_seq_id  = v_claim_seq_id AND NVL( h.pat_enhanced_yn,'N' ) = 'N'
           AND o.trtmnt_plan_general_type_id IS NOT NULL;

    clm_rec                              clm_state_cur%ROWTYPE;
    v_completed_date                     DATE;
    v_app_sum_insured                    PAT_GENERAL_DETAILS.app_sum_insured%TYPE;
    v_app_cum_bonus                      PAT_GENERAL_DETAILS.app_cum_bonus%TYPE := 0;
    v_utilised_amount                    buffer_header.utilised_amount%TYPE;

    v_utilised_sum                       TPA_ENR_BALANCE.Utilised_Sum_Insured%TYPE;
    v_utilised_cum                       TPA_ENR_BALANCE.utilised_cum_bonus%TYPE;
  
    v_sum                                clm_general_details.ava_sum_insured%TYPE;
    v_bonus                              clm_general_details.ava_cum_bonus%TYPE;
    v_buff                               clm_general_details.ava_buff_amount%TYPE;
    v_sumr                               clm_general_details.ava_sum_insured%TYPE; --koc1142

    v_current_ava_sum_insured            clm_general_details.ava_sum_insured%TYPE;
    v_ava_cum_bonus                      PAT_GENERAL_DETAILS.ava_cum_bonus%TYPE;

    v_ctr                                NUMBER(5);
    v_perc_increase                      NUMBER(3);
    v_max_amount                         NUMBER(12,2);
    v_total_app_amount                   NUMBER(12,2) := v_max_app_amount;
    v_unusable_sum                       NUMBER(12,2) := 0;
    v_unusable_bonus                     NUMBER(12,2) := 0;
    v_total_claim_app_amount             NUMBER(12,2) ;
    v_appr_count                         NUMBER(2);
    v_ava_dom_amount                     NUMBER(12,2):= 0;
    v_discount_differ_yn                 CHAR(1) := 'N';
    v_cancel_reject_yn                  VARCHAR2(1) := 'N';
    v_policy_group_seq_id               tpa_enr_policy_group.policy_group_seq_id%TYPE;
    v_date_of_admission                 clm_general_details.date_of_admission%TYPE;
    v_date_of_discharge                 clm_general_details.date_of_discharge%TYPE;
    v_applicable_rate_percent           service_tax_config.applicable_rate_percent%TYPE;
    v_opd_benefit_flag                   VARCHAR2(3);  --KOC1286
    v_pd1                                tpa_enr_balance.policy_deductable_amt%TYPE;--koc1277
	v_med_vst                            number; --Added for koc1320
    v_total_app_vst                      number; --Added for koc1320
   --- v_co_pay_buff_amount                clm_general_details.co_payment_buffer_amount%TYPE; --KOCIBM remove later

    v_msg_str                            varchar2(2000); --koc_ins_mail
    v_notify_typ_id                      tpa_ins_info.notify_type_id%type; --koc_ins_mail
    v_dest_msg_seq_id                    destination_message.dest_msg_seq_id%type; --koc_ins_mail


    CURSOR amd_cur IS SELECT COUNT(1)
       FROM  clm_inward a JOIN clm_general_details b ON (a.claims_inward_seq_id = b.claims_inward_seq_id )
       JOIN clm_enroll_details c ON ( b.claim_seq_id = c.claim_seq_id )
       WHERE A.claim_seq_id = v_claim_seq_id  AND  ( c.clm_status_general_type_id NOT IN ('PCO','REJ') OR b.completed_yn = 'N' );

    CURSOR perc_cur IS SELECT a.claim_pcnt_for_preauth
       FROM tpa_system_parameters A WHERE a.system_param_seq_id = 1;

    CURSOR bill_cur IS SELECT COUNT(1) FROM clm_bill_header a JOIN clm_bill_details b ON (a.clm_bill_seq_id = b.clm_bill_seq_id)
      WHERE a.claim_seq_id = v_claim_seq_id;

    CURSOR cheque_cur IS SELECT a.payment_seq_id, a.claim_payment_status, c.check_status , b.claims_chk_seq_id
      FROM tpa_claims_payment a LEFT OUTER JOIN tpa_payment_checks_details b ON (a.payment_seq_id = b.payment_seq_id)
      LEFT OUTER JOIN tpa_claims_check c ON (c.claims_chk_seq_id = b.claims_chk_seq_id)
      WHERE a.claim_seq_id = v_claim_seq_id ORDER BY c.claims_chk_seq_id DESC;
    cheque_rec                   cheque_cur%ROWTYPE;

   CURSOR prev_appr_cur IS  SELECT COUNT(1) FROM ( SELECT a.claim_seq_id, a.parent_claim_seq_id
      FROM clm_general_details a START WITH a.claim_seq_id = v_claim_seq_id CONNECT BY a.claim_seq_id = PRIOR a.parent_claim_seq_id ) aa
      JOIN clm_enroll_details bb ON (aa.claim_seq_id = bb.claim_seq_id )
      WHERE bb.clm_status_general_type_id = 'APR' AND aa.claim_seq_id != v_claim_seq_id ;

   CURSOR dom_cur IS SELECT a.domicilary_seq_id, a.domicilary_limit, a.utilised_dom_amount,
      nvl (b.domicilary_general_type_id,c.domicilary_general_type_id) AS domicilary_general_type_id , a.additional_domicilary_yn
      FROM tpa_enr_domicilary a JOIN tpa_enr_policy_member b ON (a.policy_group_seq_id = b.policy_group_seq_id)
      JOIN tpa_enr_policy C ON (a.policy_seq_id = c.policy_seq_id)
      WHERE ( nvl(b.domicilary_general_type_id,c.domicilary_general_type_id) = 'PNF' AND a.member_seq_id = clm_rec.member_seq_id OR
              nvl(b.domicilary_general_type_id,c.domicilary_general_type_id) = 'PFL' AND b.member_seq_id = clm_rec.member_seq_id);

    dom_rec                              dom_cur%ROWTYPE;

   CURSOR max_amt_cur IS SELECT SUM(c.approved_amount) FROM clm_general_details a JOIN icd_pcs_detail b ON (a.claim_seq_id = b.claim_seq_id)
     JOIN ailment_caps c ON (b.icd_pcs_seq_id = c.icd_pcs_seq_id)
     WHERE a.claim_seq_id = v_claim_seq_id ;

   CURSOR policy_group_cur IS SELECT b.policy_group_seq_id
      FROM clm_enroll_details a JOIN tpa_enr_policy_member b ON (a.member_seq_id = b.member_seq_id)
      WHERE a.claim_seq_id = v_claim_seq_id;

   CURSOR stx_cur IS SELECT A.clm_bill_dtl_seq_id,A.allowed_amount,A.ward_type_id,A.requested_amount
     FROM clm_bill_details A LEFT OUTER JOIN clm_bill_header B ON (A.clm_bill_seq_id=B.clm_bill_seq_id)
     WHERE B.Claim_Seq_Id=v_claim_seq_id
     AND A.Ward_Type_Id='STX';

   CURSOR icd_primary_cur IS
                SELECT count(1) primary_count
                    FROM ICD_PCS_DETAIL P
                 WHERE P.claim_seq_id=v_claim_seq_id
                    AND P.primary_ailment_yn='Y';--FOR KOC1082 CR

   CURSOR cur_ser_tx IS SELECT sc.rev_date_from,sc.rev_date_to,sc.applicable_rate_percent FROM service_tax_config sc ORDER BY sc.serv_tax_seq_id;--For KOC1090
   stx_rec                              stx_cur%ROWTYPE;
   icd_primary_rec                      icd_primary_cur%ROWTYPE;--FOR KOC1082 CR
   cur_ser_tx_rec                       cur_ser_tx%ROWTYPE;--For KOC1090

  -----KOC1107 TO CHECK WHETHER THE ICD_CODE IS CANCELLED
    CURSOR code_icd IS
    SELECT D.icd_code,D.Ped_Code_Id,P.Ped_Description,D.Icd_Pcs_Seq_Id
    FROM icd_pcs_detail D,tpa_ped_code P
    WHERE D.Icd_Code=P.Icd_Code AND D.Ped_Code_Id=P.Ped_Code_Id
    AND D.claim_seq_id=v_claim_seq_id;
    cur_icd code_icd%ROWTYPE;

  CURSOR cur_ovrde IS SELECT over_ride_yn FROM rule_Data hj
    WHERE hj.claim_seq_id=v_claim_seq_id;
   ovrde_yn cur_ovrde%ROWTYPE;

 CURSOR icd_mat_cur IS   --KOC1164
      SELECT P.ICD_CODE
          FROM ICD_PCS_DETAIL D , tpa_ped_code P
       WHERE D.Icd_Code=P.Icd_Code AND D.Ped_Code_Id=P.Ped_Code_Id
       AND D.claim_seq_id=v_claim_seq_id
       AND D.primary_ailment_yn='Y';
    v_icd_code  TPA_PED_CODE.ICD_CODE%type; --koc1164
    v_mat_icd_count NUMBER(3);  --KOC1164


CURSOR opd_benefit_cur_COR IS  --koc1286
     SELECT A.Opd_Benefits_Yn ---COR
       FROM TPA_INS_PROD_POLICY A,
        TPA_ENR_POLICY      B,
        CLM_ENROLL_DETAILS  C
     WHERE C.POLICY_SEQ_ID = B.POLICY_SEQ_ID
    AND B.POLICY_SEQ_ID = A.POLICY_SEQ_ID
    AND C.CLAIM_SEQ_ID = v_claim_seq_id;

     CURSOR opd_benefit_cur_oth  IS  --koc1286
      SELECT A.Opd_Benefits_Yn ---OTHERS
       FROM TPA_INS_PROD_POLICY A,
        TPA_ENR_POLICY      B,
        CLM_ENROLL_DETAILS  C
      WHERE C.POLICY_SEQ_ID = B.POLICY_SEQ_ID
     AND B.PRODUCT_SEQ_ID = A.PRODUCT_SEQ_ID
     AND C.CLAIM_SEQ_ID = v_claim_seq_id;

  CURSOR cur_relation (v_prod_policy_seq_id VARCHAR2) IS --koc1142
    SELECT tps.copay_yn,tps.copay_approved_amt,tps.copay_fixed_amt,tps.copay_perc,
     tps.si_restrict_yn,tps.si_relation,tps.si_restrict_amt,tps.si_restrict_perc,tps.si_type,
     tps.ins_pat_allow_yn,tps.ins_pat_operator,tps.ins_pat_apr_limit --KOCBJJ
     FROM tpa_ins_prod_policy tps
     WHERE tps.prod_policy_seq_id=v_prod_policy_seq_id;

    relt_cur                  cur_relation%ROWTYPE;

     v_result_set              SYS_REFCURSOR;
     v_prod_policy_seq_id      Tpa_ins_prod_policy.prod_policy_seq_id%TYPE;
     v_dub                     NUMBER(16,2);
     v_rest_sum                NUMBER(16,2);    --koc1142
     v_utilised_sumr           NUMBER(16,2);

     v_config_amt               Tpa_enr_balance.Sum_Insured%TYPE;
     v_used_amt                 Tpa_enr_balance.Utilised_Sum_Insured%TYPE;
     v_age_flag                 VARCHAR2(3);

--koc1277
  cursor pre_cur is
      select sum(gen.policy_deductable_amt) policy_deductable_amt,sum(gen.total_app_amount) clm_tot
    FROM pat_general_details A JOIN pat_enroll_details B ON ( a.pat_enroll_detail_seq_id = b.pat_enroll_detail_seq_id AND A.PAT_ENHANCED_YN='N')
       JOIN clm_general_details gen on (gen.pat_enroll_detail_seq_id=a.pat_enroll_detail_seq_id)
       JOIN clm_enroll_details en on (en.claim_seq_id=gen.claim_seq_id)
    where a.pat_enroll_detail_seq_id=clm_rec.pat_enroll_detail_seq_id
    and en.clm_status_general_type_id='APR';

pre_rec  pre_cur%rowtype;

cursor pat_mon_cur is
  select a.policy_deductable_amt,a.total_app_amount
    FROM pat_general_details A JOIN pat_enroll_details B ON ( a.pat_enroll_detail_seq_id = b.pat_enroll_detail_seq_id AND A.PAT_ENHANCED_YN='N' )
    where a.pat_enroll_detail_seq_id=clm_rec.pat_enroll_detail_seq_id
    and b.pat_status_general_type_id='APR';

pat_mon_rec  pat_mon_cur%rowtype;

cursor pre_auth_det_cur is
  select    count(1) as cnt,b.pat_status_general_type_id
    FROM pat_general_details A JOIN pat_enroll_details B ON ( a.pat_enroll_detail_seq_id = b.pat_enroll_detail_seq_id AND A.PAT_ENHANCED_YN='N')
       LEFT OUTER JOIN tpa_enr_policy_member D ON (b.member_seq_id = d.member_seq_id)
       LEFT OUTER JOIN tpa_enr_policy_group gr ON (gr.policy_group_seq_id = d.policy_group_seq_id)
       LEFT OUTER JOIN tpa_enr_policy G ON (b.policy_seq_id = g.policy_seq_id)
       WHERE trunc(b.date_of_hospitalization) = trunc(clm_rec.date_of_admission)
       and b.tpa_enrollment_id= clm_rec.tpa_enrollment_id
       and b.hosp_seq_id= clm_rec.hosp_seq_id
       group by b.pat_status_general_type_id;

pre_auth_det_rec  pre_auth_det_cur%rowtype;


--koc1277
--===========================Added for koc1320==================
CURSOR med_vst_cur IS (SELECT SUM(c.number_of_visits) FROM
           clm_enroll_details A JOIN clm_general_details B ON ( A.claim_seq_id = B.claim_seq_id AND A.clm_status_general_type_id NOT IN ('REJ','PCO'))
               JOIN ailment_details c ON (b.claim_seq_id = c.claim_seq_id)
               WHERE /*A.member_seq_id = (select member_seq_id from clm_enroll_details where claim_seq_id = v_claim_seq_id\*1957086*\) and*/ NVL(c.claim_seq_id,0) = v_claim_seq_id/*1957404*/
                AND a.clm_status_general_type_id = 'APR' );


--koc1273
cursor prod_info_cur is
select case when clm_rec.enrol_type_id='COR' then nvl(pol.critical_sumins_yn,'N')
else nvl(prd.critical_sumins_yn,'N') end as critical_benefit_yn
  from tpa_ins_product prd
join tpa_enr_policy pol on (pol.product_seq_id=prd.product_seq_id)
join clm_enroll_details en on (en.policy_seq_id=pol.policy_seq_id)
where  en.claim_seq_id = v_claim_seq_id;

prod_info_rec   prod_info_cur%rowtype;
--koc1273


  BEGIN
    

     claims_freeze(v_claim_seq_id,v_pat_status_general_type_id,'S'); --KOCBJJ
  
   IF v_pat_status_general_type_id='APR' THEN
    FOR icd in code_icd LOOP
      IF icd.icd_code='CANL' THEN 
        raise_application_error(-20814,'Preauth cannot be approved since the icd/pcd code is cancelled');
      END IF;
    END LOOP;
   END IF;

  OPEN clm_state_cur;
  FETCH clm_state_cur INTO clm_rec;
  CLOSE clm_state_cur;

  IF clm_rec.Completed_Yn='Y' AND (clm_rec.Pre_Auth_Buffer_App_Amount>0 OR clm_rec.Claim_App_Buffer_Amount>0 OR clm_rec.Curr_Claim_Buff_Utilised>0) THEN
       RAISE_APPLICATION_ERROR(-20107,' You cannot modify  this Pre-Auth/claim , Reviews are Completed');
  END IF;
  
if nvl(clm_rec.policy_deductable_yn,'N')='N'  OR (clm_rec.clm_status_general_type_id != v_pat_status_general_type_id and nvl(clm_rec.policy_deductable_yn,'N')='Y' )  then  --koc1277 provided to avoid resave of same status like APR APR for policy deductable cases

IF clm_rec.enrol_type_id ='COR' AND  clm_rec.claim_sub_general_type_id='OPD' THEN   --KOC1286
    OPEN opd_benefit_cur_COR;
      FETCH opd_benefit_cur_COR INTO v_opd_benefit_flag;
    CLOSE opd_benefit_cur_COR;
   ELSE
     OPEN opd_benefit_cur_oth;
      FETCH opd_benefit_cur_oth INTO v_opd_benefit_flag;
    CLOSE opd_benefit_cur_oth;
  END IF;

--koc1273
  if clm_rec.claim_sub_general_type_id='CTL' then


  if v_pat_status_general_type_id='APR'
    and clm_rec.clm_status_general_type_id!='APR' then

    IF clm_rec.requested_amount < v_max_app_amount THEN
        raise_application_error(-20174,'Approved amount is greater than the requested amount');
    END IF;

    critical_benefit_check(v_claim_seq_id,
                              clm_rec.product_seq_id,
                              clm_rec.policy_seq_id,
                              clm_rec.enrol_type_id,
                              clm_rec.mem_age,
                              clm_rec.tpa_enrollment_id,
                              clm_rec.diagnosis_dt,
                              clm_rec.date_of_certificate,
                              clm_rec.date_of_inception,
                              clm_rec.member_seq_id,
                              clm_rec.claim_sub_general_type_id);
  end if;

  OPEN  prod_info_cur;
  FETCH prod_info_cur INTO prod_info_rec;
  CLOSE prod_info_cur;


  end if;
--koc1273
    IF clm_rec.rule_execution_status='PRD' AND v_pat_status_general_type_id='APR'  THEN

 app.define_rule_pkg.pr_rule_xml_validation(v_claim_seq_id,'C');

 OPEN cur_ovrde;
 FETCH cur_ovrde INTO ovrde_yn;
 CLOSE cur_ovrde;

 IF ovrde_yn.over_ride_yn='N'
 THEN raise_application_error(-20813,'please complete entering the remarks in RULE DATA');
 END IF;
 END IF;
  -----------------------------------------------------------KOC1099

  ---koc1140 and koc1142
  IF  clm_rec.enrol_type_id='COR' and v_pat_status_general_type_id='APR' THEN
    OPEN v_result_set FOR
       'SELECT gt.prod_policy_seq_id
        FROM tpa_enr_policy GH
        LEFT OUTER JOIN tpa_ins_prod_policy GT ON (GH.policy_seq_id=GT.policy_seq_id)
        LEFT OUTER JOIN tpa_ins_prod_policy_rules GM ON (GT.prod_policy_seq_id=GM.prod_policy_seq_id)
        WHERE GH.policy_seq_id=:v_policy_seq_id'
     USING clm_rec.policy_seq_id;

     FETCH v_result_set INTO v_prod_policy_seq_id;
     CLOSE v_result_set;
  ELSE
     OPEN v_result_set FOR
      'select tipp.prod_policy_seq_id
      from tpa_enr_policy tep
      left outer join tpa_ins_product tip on (tip.product_seq_id=tep.product_seq_id)
      left outer join tpa_ins_prod_policy tipp on (tipp.product_seq_id=tip.product_seq_id)
      where tep.policy_seq_id=:v_policy_seq_id'
      USING clm_rec.policy_seq_id;

     FETCH v_result_set INTO v_prod_policy_seq_id;
     CLOSE v_result_set;
   END IF;

   IF  clm_rec.enrol_type_id='COR' and v_pat_status_general_type_id='APR' THEN
   OPEN cur_relation (v_prod_policy_seq_id);
   FETCH cur_relation INTO relt_cur;
   CLOSE cur_relation;

   IF clm_rec.enrol_type_id ='COR' AND  clm_rec.claim_sub_general_type_id='OPD' and v_opd_benefit_flag='Y' THEN
     relt_cur.copay_yn :='N';
     relt_cur.si_restrict_yn :='N';
   end IF;


   IF nvl(relt_cur.copay_yn,'N')!='N' OR nvl(relt_cur.si_restrict_yn,'N')!='N' THEN

 /*v_dub:= copay_restrict_check( clm_rec.member_seq_id,
    'app', v_prod_policy_seq_id, v_claim_seq_id,  clm_rec.pat_app_sum \*pat_approved_amount*\, clm_rec.total_app_amount, v_mem_total_sum_insured, clm_rec.utilised_sum_insured,  v_rest_amt, nvl(clm_rec.used_restrict_amt,0),
    v_max_app_amount, nvl(clm_rec.claim_app_buffer_amount,clm_rec.pre_auth_buffer_app_amount),
    v_co_payment_amount, v_restrict_yn );*/
   age_amount_rest(v_claim_seq_id ,'C', v_config_amt,v_used_amt, v_age_flag);

   IF v_age_flag='N' THEN
     v_dub := buffer_changes_pkg.copay_restrict_check
                         (v_prod_policy_seq_id ,
                          v_claim_seq_id ,
                          clm_rec.total_app_amount,
                          v_mem_total_sum_insured,
                          clm_rec.utilised_sum_insured,
                          nvl(v_rest_amt,0) ,
                          nvl(clm_rec.used_restrict_amt,0),
                          v_max_app_amount,
                          NVL(nvl(clm_rec.claim_app_buffer_amount,clm_rec.pre_auth_buffer_app_amount),0),
                          v_restrict_yn,
                          'C');
    ELSE
      v_dub :=buffer_changes_pkg.age_restrict_check
                         (v_prod_policy_seq_id ,
                          v_claim_seq_id ,
                          clm_rec.total_app_amount,
                          v_mem_total_sum_insured,
                          clm_rec.utilised_sum_insured,
                          clm_rec.restrict_amt,
                          clm_rec.used_restrict_amt,
                          nvl(v_config_amt,0) ,
                          nvl(v_used_amt,0),
                          v_max_app_amount,
                          NVL(nvl(clm_rec.claim_app_buffer_amount,clm_rec.pre_auth_buffer_app_amount),0),
                          v_restrict_yn,
                          'C');
    END IF;

    IF v_dub=0 THEN clm_rec.ava_sum_insured:=0;
                    clm_rec.ava_res_amt:=0 ;
            ELSE    clm_rec.ava_sum_insured :=v_dub;
                    clm_rec.ava_res_amt:=v_dub;
            END IF;

    END IF;
   ----
   END IF;


    OPEN bill_cur;
    FETCH bill_cur INTO v_ctr;
    CLOSE bill_cur;

    IF v_ctr = 0 THEN
      raise_application_error(-20175,'Bills not entered for this Claim');
    END IF;

    -- LOCKING CLAIM
    TTK_UTIL_PKG.reset_id_flag(v_claim_seq_id||'-CLM','Y');
    -- LOCKING Family
    OPEN policy_group_cur;
    FETCH policy_group_cur INTO v_policy_group_seq_id;
    CLOSE policy_group_cur;

    TTK_UTIL_PKG.reset_id_flag(v_policy_group_seq_id||'-FAMILY','Y');

   /* OPEN clm_state_cur;
    FETCH clm_state_cur INTO clm_rec;
    CLOSE clm_state_cur;*/

    IF clm_rec.claim_general_type_id != 'CTM' THEN
      OPEN stx_cur;
      FETCH stx_cur INTO stx_rec;
      CLOSE stx_cur;
    END IF;

    IF nvl(clm_rec.pat_approved_amount,0) != nvl(clm_rec.preauth_approved_amt,0) THEN
      raise_application_error(-20182,'Associated Preauth is overridden/re-associated to another claim, please re-associate preauth.');
    END IF;

    IF clm_rec.modification_mode_value > 0 AND v_pat_status_general_type_id = 'APR' THEN
      v_ctr := NULL;
      policy_enrollment_pkg.check_enrollment_change ( clm_rec.modification_mode_value,v_ctr );
    END IF;

    IF clm_rec.completed_yn = 'N' THEN
      --reassigning user
      pre_auth_pkg.reassign_user (  NULL , v_claim_seq_id , NULL , v_added_by , 'AUT');
    ELSE
      pre_auth_pkg.reassign_user (  NULL , v_claim_seq_id , NULL , v_added_by , 'CMP');
    END IF;

    IF clm_rec.trtmnt_plan_general_type_id  IS NULL THEN
      raise_application_error( -20116, 'Enter Medical Details First');
    END IF;
    IF v_pat_status_general_type_id IN ('APR','REJ') THEN
      IF NVL(clm_rec.rule_execution_flag,0) != 2 AND clm_rec.rule_execution_status = 'PRD' THEN
        raise_application_error(-20148,'Please do rule validation before approval.');
      END IF;
    END IF;
 --=====================koc1285
  IF v_pat_status_general_type_id='APR' THEN
     IF clm_rec.doc_cert_dom_yn='N' and clm_rec.claim_sub_general_type_id='CSD'
     then  raise_application_error(-20862,'please specify treetment certified ');
     end if;
   END IF;
  --==========================koc1285
    IF v_pat_status_general_type_id IN ('APR','REJ') THEN--FOR KOC1082 CR
       OPEN icd_primary_cur;
          FETCH ICD_PRIMARY_CUR INTO  ICD_PRIMARY_REC;
       CLOSE icd_primary_cur;

       IF ICD_PRIMARY_REC.PRIMARY_COUNT<=0 THEN
           raise_application_error(-20788,' Please select the Primary Ailment in medical. ');
       END IF;

    END IF;

 IF v_pat_status_general_type_id ='APR' AND clm_rec.SPECIALTY_GENERAL_TYPE_ID!='SUR' THEN  --KOC1164
      open  icd_mat_cur;
      fetch icd_mat_cur into v_icd_code;
      close icd_mat_cur;
      select count(1) into v_mat_icd_count from app.TPA_MAT_ICD_CODE a where A.ECTOPIC_YN='Y' AND a.MAT_ICD_CODE=v_icd_code;
      IF v_mat_icd_count>0 THEN
        raise_application_error(-20888,' Please change the Speciality as  surgical in Medical Screen.  ');
      END IF;
    END IF;

    SELECT cg.date_of_discharge INTO v_date_of_discharge
    FROM clm_general_details cg
    WHERE cg.claim_seq_id=v_claim_seq_id;

   FOR i IN cur_ser_tx LOOP

        /*v_applicable_rate_percent:= CASE WHEN trunc(v_date_of_admission) BETWEEN trunc(i.rev_date_from) AND nvl(trunc(i.rev_date_to),SYSDATE) THEN
                                   i.applicable_rate_percent ELSE 0 END;*/
         v_applicable_rate_percent:= CASE WHEN trunc(v_date_of_discharge) BETWEEN trunc(i.rev_date_from) AND nvl(trunc(i.rev_date_to),SYSDATE) THEN
                                   i.applicable_rate_percent ELSE 0 END;
        IF v_applicable_rate_percent <> 0 THEN EXIT; END IF;

    END LOOP;

    IF nvl(v_applicable_rate_percent,0) = 0 AND nvl(v_service_tax_calc_amt,0) > 0 THEN
           raise_application_error(-20811,'Tax Amt. Paid should be zero, since Service Tax configured percentage is zero.');
    END IF;

    OPEN max_amt_cur;
    FETCH max_amt_cur INTO v_max_app_amount;
    CLOSE max_amt_cur;
     --KOC1286
   IF clm_rec.claim_sub_general_type_id='OPD' AND clm_rec.clm_status_general_type_id = 'APR' AND v_pat_status_general_type_id = 'APR' THEN
     IF (v_opd_benefit_flag='Y' AND CLM_REC.OPD_FLAG_YN='N') OR (v_opd_benefit_flag='N' AND CLM_REC.OPD_FLAG_YN='Y') THEN
      RAISE_APPLICATION_ERROR(-20889,'Enrollment changes has happened,Please change the status as In-Progress In Settlement');
     END IF;
   END IF; --KOC1286

    v_max_app_amount     := v_max_app_amount - NVL(v_discount_amount,0) - NVL(v_co_payment_amount,0) - NVL(v_deposit_amount,0) + NVL(v_service_tax_calc_amt,0)-nvl(v_co_pay_buff_amount,0); --KOCIBM
    v_total_app_amount   := v_max_app_amount ;
    v_total_app_vst      := v_med_vst ; --Added for koc1320
--koc1277
    if clm_rec.policy_deductable_yn = 'Y' and clm_rec.claim_sub_general_type_id!='OPD'
      and v_pat_status_general_type_id = 'APR' /*and clm_rec.pat_status_general_type_id='APR'*/ and clm_rec.claim_general_type_id='CTM' then


  OPEN pre_auth_det_cur;
  FETCH pre_auth_det_cur INTO pre_auth_det_rec;
  CLOSE pre_auth_det_cur;


   if pre_auth_det_rec.cnt >=1 and pre_auth_det_rec.pat_status_general_type_id='APR' then
     raise_application_error(-20897,'Cannot process a member claim, since pre-Auth exists for the same Date of Admission,Reject the claim');
   end if;

    end if;

    if nvl(v_max_app_amount,0) <= nvl(v_pd,0) and  clm_rec.policy_deductable_yn = 'Y'
      and clm_rec.clm_status_general_type_id != v_pat_status_general_type_id
      and clm_rec.claim_sub_general_type_id!='OPD' and clm_rec.pat_enroll_detail_seq_id is null then

       if v_pat_status_general_type_id='APR' and clm_rec.clm_status_general_type_id in ('INP','REQ') then

      UPDATE tpa_enr_balance a SET
            a.utilised_policy_deductable_amt = nvl(a.utilised_policy_deductable_amt,0) + nvl(v_max_app_amount,0),
            a.updated_by             = v_added_by,
            a.updated_date           = SYSDATE
            WHERE a.balance_seq_id = clm_rec.balance_seq_id;

               v_pd1 :=  nvl(v_max_app_amount,0);

       UPDATE clm_general_details SET
              policy_deductable_amt                   =  v_pd1,--policy_deductable
              POLICY_DEDUCTABLE_AMT_SET               =  v_pd--policy_deductable
          WHERE claim_seq_id = v_claim_seq_id;

         end if;
       v_max_app_amount := 0;
    end if;


    --policy_deductable
  if clm_rec.policy_deductable_yn = 'Y' and clm_rec.clm_status_general_type_id != v_pat_status_general_type_id
    and clm_rec.claim_sub_general_type_id!='OPD' then

  if clm_rec.pat_enroll_detail_seq_id is null then

 if nvl(v_max_app_amount,0) > nvl(v_pd,0) and (v_pat_status_general_type_id='APR')
     and clm_rec.clm_status_general_type_id in ('INP','REQ') then
   v_max_app_amount := nvl(v_max_app_amount,0) - nvl(v_pd,0);

              UPDATE tpa_enr_balance a SET
                    a.utilised_policy_deductable_amt = nvl(a.utilised_policy_deductable_amt,0) + nvl(v_pd,0),
                    a.updated_by             = v_added_by,
                    a.updated_date           = SYSDATE
                    WHERE a.balance_seq_id = clm_rec.balance_seq_id;

               v_pd1 := nvl(v_pd,0);

       UPDATE clm_general_details SET
              policy_deductable_amt                   =  v_pd1,--policy_deductable
              POLICY_DEDUCTABLE_AMT_SET               =  v_pd--policy_deductable
          WHERE claim_seq_id = v_claim_seq_id;

   elsif v_pat_status_general_type_id in ('INP','REQ','REJ','PCO')
   and clm_rec.clm_status_general_type_id in ('APR') then

     UPDATE tpa_enr_balance a SET
        a.utilised_policy_deductable_amt = nvl(a.utilised_policy_deductable_amt,0) - nvl(clm_rec.policy_deductable_amt,0),
        a.updated_by             = v_added_by,
        a.updated_date           = SYSDATE
        WHERE a.balance_seq_id = clm_rec.balance_seq_id;

               v_pd1 := null;
               v_pd  := null;

       UPDATE clm_general_details SET
              policy_deductable_amt                   =  v_pd1,--policy_deductable
              POLICY_DEDUCTABLE_AMT_SET               =  v_pd--policy_deductable
          WHERE claim_seq_id = v_claim_seq_id;


    elsif v_pat_status_general_type_id in ('INP','REQ','REJ','PCO')
      and clm_rec.clm_status_general_type_id in ('INP','REQ','PCO') then
      v_pd  := null;

       UPDATE clm_general_details SET
              policy_deductable_amt                   =  v_pd1,--policy_deductable
              POLICY_DEDUCTABLE_AMT_SET               =  v_pd--policy_deductable
          WHERE claim_seq_id = v_claim_seq_id;

   end if;

  elsif clm_rec.pat_enroll_detail_seq_id is not null then

open  pat_mon_cur;
fetch pat_mon_cur into pat_mon_rec;
close pat_mon_cur;


 if nvl(v_max_app_amount,0) >= nvl(v_pd,0) and  v_pat_status_general_type_id='APR'
     and clm_rec.clm_status_general_type_id in ('INP','REQ') and clm_rec.document_general_type_id!='DTA' then

   if  nvl(v_max_app_amount,0)-nvl( clm_rec.pat_policy_deductable_amt ,0) <= 0 then

     UPDATE tpa_enr_balance a SET
                    a.utilised_policy_deductable_amt = nvl(a.utilised_policy_deductable_amt,0) /*+ nvl(v_pd,0) */- nvl(clm_rec.pat_policy_deductable_amt,0) + nvl(v_max_app_amount,0)
                    WHERE a.balance_seq_id = clm_rec.balance_seq_id;

        v_pd1 :=  - nvl(clm_rec.pat_policy_deductable_amt,0) + nvl(v_max_app_amount,0);

       UPDATE clm_general_details SET
              policy_deductable_amt                   =  v_pd1, --policy_deductable
              POLICY_DEDUCTABLE_AMT_SET               =  v_pd --policy_deductable
          WHERE claim_seq_id = v_claim_seq_id;

          v_max_app_amount := 0;


   elsif nvl(v_max_app_amount,0) - nvl(clm_rec.pat_policy_deductable_amt,0) > 0 then

        v_pd1 := least(nvl(v_pd,0),nvl(v_max_app_amount,0) - nvl(clm_rec.pat_policy_deductable_amt,0));

     UPDATE tpa_enr_balance a SET
                    a.utilised_policy_deductable_amt = nvl(a.utilised_policy_deductable_amt,0) + nvl(v_pd1,0)
                    WHERE a.balance_seq_id = clm_rec.balance_seq_id;

       UPDATE clm_general_details SET
              policy_deductable_amt                   =  v_pd1, --policy_deductable
              POLICY_DEDUCTABLE_AMT_SET               =  v_pd --policy_deductable
          WHERE claim_seq_id = v_claim_seq_id;

         v_max_app_amount := nvl(v_max_app_amount,0) - nvl(clm_rec.pat_policy_deductable_amt,0)-nvl(v_pd1,0);

    end if;

    elsif nvl(v_max_app_amount,0) < nvl(v_pd,0) and  v_pat_status_general_type_id='APR'
     and clm_rec.clm_status_general_type_id in ('INP','REQ') and clm_rec.document_general_type_id!='DTA' then

   if  nvl(v_max_app_amount,0)-nvl( clm_rec.pat_policy_deductable_amt ,0) <= 0 then

     UPDATE tpa_enr_balance a SET
                    a.utilised_policy_deductable_amt = nvl(a.utilised_policy_deductable_amt,0) /*+ nvl(v_pd,0) */- nvl(clm_rec.pat_policy_deductable_amt,0) + nvl(v_max_app_amount,0)
                    WHERE a.balance_seq_id = clm_rec.balance_seq_id;

        v_pd1 :=  - nvl(clm_rec.pat_policy_deductable_amt,0) + nvl(v_max_app_amount,0);

       UPDATE clm_general_details SET
              policy_deductable_amt                   =  v_pd1, --policy_deductable
              POLICY_DEDUCTABLE_AMT_SET               =  v_pd --policy_deductable
          WHERE claim_seq_id = v_claim_seq_id;

          v_max_app_amount := 0;


    elsif nvl(v_max_app_amount,0) - nvl(clm_rec.pat_policy_deductable_amt,0) > 0 then

        v_pd1 := least(nvl(v_pd,0),nvl(v_max_app_amount,0) - nvl(clm_rec.pat_policy_deductable_amt,0));

     UPDATE tpa_enr_balance a SET
                    a.utilised_policy_deductable_amt = nvl(a.utilised_policy_deductable_amt,0) + nvl(v_pd1,0)
                    WHERE a.balance_seq_id = clm_rec.balance_seq_id;

       UPDATE clm_general_details SET
              policy_deductable_amt                   =  v_pd1, --policy_deductable
              POLICY_DEDUCTABLE_AMT_SET               =  v_pd --policy_deductable
          WHERE claim_seq_id = v_claim_seq_id;

         v_max_app_amount :=0;

    end if;

elsif nvl(v_max_app_amount,0) < nvl(v_pd,0) and  v_pat_status_general_type_id='APR'
     and clm_rec.clm_status_general_type_id in ('INP','REQ') and clm_rec.document_general_type_id!='DTA' then

  if  nvl(v_max_app_amount,0)-nvl( clm_rec.pat_policy_deductable_amt ,0) <= 0 then

     UPDATE tpa_enr_balance a SET
                    a.utilised_policy_deductable_amt = nvl(a.utilised_policy_deductable_amt,0) /*+ nvl(v_pd,0) */- nvl(clm_rec.pat_policy_deductable_amt,0) + nvl(v_max_app_amount,0)
                    WHERE a.balance_seq_id = clm_rec.balance_seq_id;

        v_pd1 :=  - nvl(clm_rec.pat_policy_deductable_amt,0) + nvl(v_max_app_amount,0);

       UPDATE clm_general_details SET
              policy_deductable_amt                   =  v_pd1, --policy_deductable
              POLICY_DEDUCTABLE_AMT_SET               =  v_pd --policy_deductable
          WHERE claim_seq_id = v_claim_seq_id;

          v_max_app_amount := 0;


    elsif nvl(v_max_app_amount,0) - nvl(clm_rec.pat_policy_deductable_amt,0) > 0 then

        v_pd1 := least(nvl(v_pd,0),nvl(v_max_app_amount,0) - nvl(clm_rec.pat_policy_deductable_amt,0));

     UPDATE tpa_enr_balance a SET
                    a.utilised_policy_deductable_amt = nvl(a.utilised_policy_deductable_amt,0) + nvl(v_pd1,0)
                    WHERE a.balance_seq_id = clm_rec.balance_seq_id;

       UPDATE clm_general_details SET
              policy_deductable_amt                   =  v_pd1, --policy_deductable
              POLICY_DEDUCTABLE_AMT_SET               =  v_pd --policy_deductable
          WHERE claim_seq_id = v_claim_seq_id;

         v_max_app_amount := nvl(v_max_app_amount,0) - nvl(clm_rec.pat_policy_deductable_amt,0)-nvl(v_pd,0);

    end if;


   elsif v_pat_status_general_type_id in ('INP','REQ','REJ','PCO')
   and clm_rec.clm_status_general_type_id in ('APR') then


           UPDATE tpa_enr_balance a SET
              a.utilised_policy_deductable_amt = nvl(a.utilised_policy_deductable_amt,0) - nvl(clm_rec.policy_deductable_amt,0),
              a.updated_by             = v_added_by,
              a.updated_date           = SYSDATE
              WHERE a.balance_seq_id = clm_rec.balance_seq_id;

               v_pd1 := null;
               v_pd  := null;

       UPDATE clm_general_details SET
              policy_deductable_amt                   =  v_pd1,--policy_deductable
              POLICY_DEDUCTABLE_AMT_SET               =  v_pd--policy_deductable
          WHERE claim_seq_id = v_claim_seq_id;




    elsif v_pat_status_general_type_id in ('INP','REQ','REJ','PCO')
      and clm_rec.clm_status_general_type_id in ('INP','REQ','PCO') then
      v_pd  := null;

           UPDATE clm_general_details SET
                  policy_deductable_amt                   =  v_pd1,--policy_deductable
                  POLICY_DEDUCTABLE_AMT_SET               =  v_pd--policy_deductable
              WHERE claim_seq_id = v_claim_seq_id;

    end if;

  --amment ment case
   if clm_rec.document_general_type_id='DTA' and  v_pat_status_general_type_id='APR'
     and clm_rec.clm_status_general_type_id in ('INP','REQ')
     and nvl(pat_mon_rec.total_app_amount,0) - nvl(pre_rec.clm_tot,0) < 0 and nvl(v_pd,0) > 0 then

open pre_cur;
fetch pre_cur into pre_rec;
close pre_cur;

   v_pd1:= least(case when nvl(v_pd,0) <= 0 then (nvl(v_max_app_amount,0) - nvl(clm_rec.pat_policy_deductable_amt,0) + nvl(clm_rec.pat_policy_deductable_amt,0) + nvl(pre_rec.policy_deductable_amt,0))
   else nvl(v_pd,0) end ,nvl(v_max_app_amount,0) - nvl(clm_rec.pat_policy_deductable_amt,0) + nvl(clm_rec.pat_policy_deductable_amt,0) + nvl(pre_rec.policy_deductable_amt,0));

     UPDATE tpa_enr_balance a SET
                    a.utilised_policy_deductable_amt = nvl(a.utilised_policy_deductable_amt,0) + nvl(v_pd1,0)
                    WHERE a.balance_seq_id = clm_rec.balance_seq_id;

       UPDATE clm_general_details SET
              policy_deductable_amt                   =  v_pd1, --policy_deductable
              POLICY_DEDUCTABLE_AMT_SET               =  v_pd --policy_deductable
          WHERE claim_seq_id = v_claim_seq_id;

--          if nvl(v_pd1,0) > 0 then
         v_max_app_amount := nvl(v_max_app_amount,0) - nvl(v_pd1,0) - nvl(clm_rec.pat_policy_deductable_amt,0) - nvl(v_pd,0);
--         else
 --        v_max_app_amount := nvl(v_max_app_amount,0) - nvl(clm_rec.pat_policy_deductable_amt,0) - nvl(v_pd,0);
  --       end if;

   if nvl(v_max_app_amount,0) < 0 then
     v_max_app_amount := 0;
   end if;


   elsif clm_rec.document_general_type_id='DTA' and  v_pat_status_general_type_id='APR'
     and clm_rec.clm_status_general_type_id in ('INP','REQ')
     and nvl(pat_mon_rec.total_app_amount,0) - nvl(pre_rec.clm_tot,0) = 0 and nvl(v_pd,0) > 0 then

        open pre_cur;
        fetch pre_cur into pre_rec;
        close pre_cur;

   v_pd1:= least(nvl(v_max_app_amount,0));

     UPDATE tpa_enr_balance a SET
                    a.utilised_policy_deductable_amt = nvl(a.utilised_policy_deductable_amt,0) + nvl(v_pd1,0)
                    WHERE a.balance_seq_id = clm_rec.balance_seq_id;

       UPDATE clm_general_details SET
              policy_deductable_amt                   =  v_pd1, --policy_deductable
              POLICY_DEDUCTABLE_AMT_SET               =  v_pd --policy_deductable
          WHERE claim_seq_id = v_claim_seq_id;

--          if nvl(v_pd1,0) > 0 then
         v_max_app_amount := nvl(v_max_app_amount,0) - nvl(v_pd1,0) - nvl(clm_rec.pat_policy_deductable_amt,0) - nvl(v_pd,0);
--         else
 --        v_max_app_amount := nvl(v_max_app_amount,0) - nvl(clm_rec.pat_policy_deductable_amt,0) - nvl(v_pd,0);
  --       end if;

   if nvl(v_max_app_amount,0) < 0 then
     v_max_app_amount := 0;
   end if;

      elsif clm_rec.document_general_type_id='DTA' and  v_pat_status_general_type_id='APR'
     and clm_rec.clm_status_general_type_id in ('INP','REQ')
     and nvl(pat_mon_rec.total_app_amount,0) - nvl(pre_rec.clm_tot,0) > 0 and nvl(v_pd,0) > 0 then

        open pre_cur;
        fetch pre_cur into pre_rec;
        close pre_cur;
--commented for error
/*   v_pd1:= least(nvl(v_pd,0) <= 0,nvl(v_max_app_amount,0) - nvl(clm_rec.pat_policy_deductable_amt,0) + nvl(clm_rec.pat_policy_deductable_amt,0) + nvl(pre_rec.policy_deductable_amt,0));
*/

   v_pd1:= least(nvl(v_pd,0),nvl(v_max_app_amount,0));

     UPDATE tpa_enr_balance a SET
                    a.utilised_policy_deductable_amt = nvl(a.utilised_policy_deductable_amt,0) + nvl(v_pd1,0)
                    WHERE a.balance_seq_id = clm_rec.balance_seq_id;


       UPDATE clm_general_details SET
              policy_deductable_amt                   =  v_pd1, --policy_deductable
              POLICY_DEDUCTABLE_AMT_SET               =  v_pd --policy_deductable
          WHERE claim_seq_id = v_claim_seq_id;

         v_max_app_amount := nvl(v_max_app_amount,0) - nvl(v_pd,0);

   if nvl(v_max_app_amount,0) < 0 then
     v_max_app_amount := 0;
   end if;


 elsif clm_rec.document_general_type_id='DTA' and  v_pat_status_general_type_id='APR'
     and clm_rec.clm_status_general_type_id in ('INP','REQ')
     and nvl(pat_mon_rec.total_app_amount,0) - nvl(pre_rec.clm_tot,0) > 0  and nvl(v_pd,0) = 0 then


  v_pd1:= nvl(clm_rec.pat_policy_deductable_amt,0) - (nvl(clm_rec.pat_policy_deductable_amt,0) + nvl(pre_rec.policy_deductable_amt,0));

     UPDATE tpa_enr_balance a SET
                    a.utilised_policy_deductable_amt = nvl(a.utilised_policy_deductable_amt,0) + nvl(v_pd1,0)
                    WHERE a.balance_seq_id = clm_rec.balance_seq_id;

       UPDATE clm_general_details SET
              policy_deductable_amt                   =  v_pd1, --policy_deductable
              POLICY_DEDUCTABLE_AMT_SET               =  v_pd --policy_deductable
          WHERE claim_seq_id = v_claim_seq_id;

--          if nvl(v_pd1,0) > 0 then
           v_max_app_amount := nvl(v_max_app_amount,0)-nvl(v_pd,0);
--         else
 --        v_max_app_amount := nvl(v_max_app_amount,0) - nvl(clm_rec.pat_policy_deductable_amt,0) - nvl(v_pd,0);
  --       end if;

   if nvl(v_max_app_amount,0) < 0 then
     v_max_app_amount := 0;
   end if;


    end if;
    --amment ment case

   end if;

  end if;
    --koc1277



    v_total_app_amount   := v_max_app_amount ;

    IF ( clm_rec.clm_status_general_type_id = v_pat_status_general_type_id OR
         clm_rec.clm_status_general_type_id IN ('REJ','PCO') AND v_pat_status_general_type_id IN ('REJ','PCO')) AND
       nvl(v_max_app_amount,0) = nvl(clm_rec.total_app_amount,0) AND
       nvl(v_discount_amount,0)  = nvl(clm_rec.discount_amount,0) AND
       nvl(v_co_payment_amount,0) = nvl(clm_rec.co_payment_amount,0) AND
       nvl(v_deposit_amount,0)   = nvl(clm_rec.deposit_amount,0) AND
       nvl(v_service_tax_calc_amt,0) = nvl(clm_rec.serv_tax_calc_amount,0) AND
       nvl(v_co_pay_buff_amount,0)   = nvl(clm_rec.co_payment_buffer_amount,0) THEN --KOCIBM

       IF clm_rec.clm_status_general_type_id IN ('REJ','PCO') AND v_pat_status_general_type_id IN ('REJ','PCO')
        AND clm_rec.clm_status_general_type_id != v_pat_status_general_type_id THEN
         v_cancel_reject_yn := 'Y';
       END IF;

       IF clm_rec.completed_yn = 'Y' AND v_cancel_reject_yn = 'N' THEN
         RAISE_APPLICATION_ERROR(-20107,' You cannot modify  this Pre-Auth/claim , Reviews are Completed');
       END IF;

       IF v_cancel_reject_yn = 'N' THEN
         pre_auth_pkg.check_clm_completed ( v_claim_seq_id , NULL,'ASN', v_added_by );
       ELSE
         UPDATE clm_enroll_details a SET
          a.clm_status_general_type_id = v_pat_status_general_type_id,
          a.updated_by                 = v_added_by,
          a.updated_date               = SYSDATE
          WHERE a.claim_seq_id = v_claim_seq_id;
       END IF;

       IF nvl(v_rson_general_type_id,'NON') != nvl(clm_rec.rson_general_type_id,'NON') OR nvl(v_remarks,'NON') != nvl(clm_rec.remarks,'NON') THEN
         UPDATE assign_users SET
            remarks                                 = v_remarks ,
            completed_date                          = CASE WHEN v_pat_status_general_type_id IN ('APR','REJ','PCO') THEN SYSDATE ELSE completed_date END,
            pat_status_general_type_id              = v_pat_status_general_type_id,
            rson_general_type_id                    = v_rson_general_type_id,
            total_app_amount                        = v_max_app_amount,
            updated_by                              = v_added_by,
            updated_date                            = SYSDATE
            WHERE assign_users_seq_id = (SELECT b.last_assign_user_seq_id
                                          FROM clm_general_details b WHERE b.claim_seq_id = v_claim_seq_id);

      END IF;
    
    ELSE
      IF clm_rec.clm_status_general_type_id = 'APR' AND v_pat_status_general_type_id = 'APR'
         AND (NVL(v_discount_amount,0) != NVL(clm_rec.discount_amount,0)
         OR NVL(v_co_payment_amount,0) != NVL(clm_rec.co_payment_amount,0)
         OR nvl(v_co_pay_buff_amount,0)!= nvl(clm_rec.co_payment_buffer_amount,0)   --KOCIBM
         OR NVL(v_deposit_amount,0)!= NVL(clm_rec.deposit_amount,0)) THEN
        v_discount_differ_yn := 'Y';
      END IF;

      IF v_pat_status_general_type_id IN ('APR','REJ','PCO') THEN
        v_completed_date := SYSDATE;
      END IF;

      IF clm_rec.claim_sub_general_type_id = 'OPD'  THEN
        OPEN dom_cur;
        FETCH dom_cur INTO dom_rec;
        CLOSE dom_cur;
        IF v_pat_status_general_type_id NOT IN ('REJ','PCO') THEN
          IF dom_rec.domicilary_seq_id IS NULL OR nvl(dom_rec.domicilary_limit,0) = 0 THEN
            raise_application_error(-20189,'Domocilary Information is not entered for this claimant');
          END IF;
        END IF;
      END IF;

      OPEN prev_appr_cur;
      FETCH prev_appr_cur INTO v_appr_count;
      CLOSE prev_appr_cur;

      v_claim_settlement_number := clm_rec.claim_settlement_number;

      IF clm_rec.endorsement_seq_id IS NOT NULL AND clm_rec.enrol_type_id != 'COR' THEN
        raise_application_error(-20131,'Currently the policy is under endorsement, Please complete the endorsement before proceeding.');
      END IF;

      IF clm_rec.completed_yn = 'N' AND ( clm_rec.claim_sub_general_type_id != 'OPD' OR clm_rec.claim_sub_general_type_id = 'OPD' AND NVL(dom_rec.additional_domicilary_yn,'Y') = 'N')
        AND clm_rec.claim_sub_general_type_id  not in ('HCU','CTL') THEN  --koc1273 added CTL for HCU
        pre_auth_pkg.get_unusable_amounts( trunc( clm_rec.date_of_admission ), clm_rec.member_seq_id, v_unusable_sum , v_unusable_bonus );
        clm_rec.ava_sum_insured := clm_rec.ava_sum_insured - nvl(v_unusable_sum,0);
        clm_rec.ava_cum_bonus   := clm_rec.ava_cum_bonus   - nvl(v_unusable_bonus,0);
        clm_rec.sum_insured     := clm_rec.sum_insured - nvl(v_unusable_sum,0);
        clm_rec.bonus           := clm_rec.bonus - nvl(v_unusable_bonus,0);
      END IF;
      -- Rejection or Cancellation part
      IF ( v_pat_status_general_type_id IN ('PCO','REJ') AND clm_rec.completed_yn = 'N' )
        OR (v_pat_status_general_type_id IN ('PCO','REJ') AND clm_rec.completed_yn = 'Y' AND v_pat_status_general_type_id != clm_rec.clm_status_general_type_id ) THEN
        IF clm_rec.completed_yn = 'Y' AND v_pat_status_general_type_id IN ('PCO','REJ') THEN
          OPEN cheque_cur;
          FETCH cheque_cur INTO cheque_rec;
          CLOSE cheque_cur;

          IF cheque_rec.payment_seq_id IS NOT NULL AND cheque_rec.check_status != 'CSV' THEN
            RAISE_APPLICATION_ERROR(-20180,'Active cheque info exists in finance, cant reject the claim');
          ELSIF cheque_rec.payment_seq_id IS NOT NULL AND cheque_rec.claims_chk_seq_id IS NULL THEN
            DELETE FROM tpa_payment_checks_details a WHERE a.payment_seq_id = cheque_rec.payment_seq_id ;
            DELETE FROM tpa_claims_check a WHERE a.claims_chk_seq_id = cheque_rec.claims_chk_seq_id ;
            DELETE FROM tpa_claims_payment a WHERE a.payment_seq_id = cheque_rec.payment_seq_id ;
          END IF;
          IF clm_rec.clm_cash_benefit_seq_id IS NOT NULL THEN
            UPDATE clm_cash_benefit a SET
              a.clm_status_general_type_id = v_pat_status_general_type_id
              WHERE a.clm_cash_benefit_seq_id = clm_rec.clm_cash_benefit_seq_id;
          END IF;
          IF clm_rec.pat_enroll_detail_seq_id IS NOT NULL AND app.maintenance_pkg.get_prev_approve_count(v_claim_seq_id) = 0 THEN
            UPDATE pat_enroll_details a
                 SET a.claim_id = NULL
                 WHERE a.pat_enroll_detail_seq_id = clm_rec.pat_enroll_detail_seq_id;
          END IF;
        END IF;

        OPEN amd_cur;
        FETCH amd_cur INTO v_ctr;
        CLOSE amd_cur;

        IF v_ctr > 0  THEN
          RAISE_APPLICATION_ERROR(-20168,'Uncompleted/Approved Ammendment Exists');
        END IF;

        IF v_claim_settlement_number IS NULL THEN
          IF clm_rec.document_general_type_id != 'DTA' THEN
            v_claim_settlement_number := pre_auth_pkg.generate_id_numbers ('STC', nvl( clm_rec.policy_tpa_office_seq_id,clm_rec.tpa_office_seq_id ) , clm_rec.claim_number , v_added_by , clm_rec.claim_general_type_id );
          ELSE
            v_claim_settlement_number := pre_auth_pkg.generate_id_numbers ('STA', nvl( clm_rec.policy_tpa_office_seq_id,clm_rec.tpa_office_seq_id ) , clm_rec.claim_number , v_added_by , clm_rec.claim_general_type_id );
          END IF;
        END IF;

        UPDATE clm_general_details SET
              claim_settlement_number                 =  v_claim_settlement_number ,
              total_app_amount                        =  NULL,
              app_sum_insured                         =  NULL,
              app_cum_bonus                           =  NULL,
              ava_sum_insured                         =  NULL,
              ava_cum_bonus                           =  NULL,
              ava_buff_amount                         =  NULL,
              discount_amount                         =  NULL,
              deposit_amount                          =  NULL,
              co_payment_amount                       =  NULL,
              co_payment_buffer_amount                =  NULL, --KOCIBM
              utilised_buff_amt                       =  NULL,
              serv_tax_calc_amount                    =  NULL,
              serv_tax_calc_percentage                =  NULL,
              updated_by                              =  v_added_by,
              updated_date                            =  SYSDATE,
              permission_sought_from                  =  NULL
          WHERE claim_seq_id = v_claim_seq_id
            RETURNING last_assign_user_seq_id INTO v_assign_users_seq_id ;

        UPDATE clm_enroll_details SET
            clm_status_general_type_id                = v_pat_status_general_type_id ,
            rson_general_type_id                      = v_rson_general_type_id ,
            decision_date                             = v_completed_date ,
            updated_by                                = v_added_by ,
            updated_date                              = SYSDATE
            WHERE clm_enroll_detail_seq_id = clm_rec.clm_enroll_detail_seq_id ;

        UPDATE assign_users SET
              remarks                                 = v_remarks ,
              completed_date                          = v_completed_date,
              pat_status_general_type_id              = v_pat_status_general_type_id,
              rson_general_type_id                    = v_rson_general_type_id ,
              total_app_amount                        = NULL,
              updated_by                              = v_added_by,
              updated_date                            = SYSDATE
              WHERE assign_users_seq_id = v_assign_users_seq_id;

        UPDATE ailment_caps a SET
             a.approved_amount                        = NULL,
             a.updated_by                             = v_added_by,
             a.updated_date                           = SYSDATE
             WHERE a.icd_pcs_seq_id IN ( SELECT b.icd_pcs_seq_id FROM icd_pcs_detail b WHERE b.claim_seq_id = v_claim_seq_id );

        UPDATE pat_package_procedures a SET
             a.procedure_amount = NULL,
             a.updated_by       = v_added_by,
             a.updated_date     = SYSDATE
             WHERE a.icd_pcs_seq_id IN ( SELECT b.icd_pcs_seq_id
                FROM icd_pcs_detail b WHERE b.claim_seq_id = v_claim_seq_id );

        IF clm_rec.clm_status_general_type_id = 'APR' AND clm_rec.claim_sub_general_type_id != 'CBN' AND
                  (  clm_rec.claim_sub_general_type_id != 'OPD' OR  clm_rec.claim_sub_general_type_id = 'OPD' AND NVL(dom_rec.additional_domicilary_yn,'Y') = 'N') THEN
          IF clm_rec.claim_sub_general_type_id != 'HCU' THEN --  HCU  -->  HEALTH CHECK UP
            IF clm_rec.completed_yn = 'Y' THEN

              v_utilised_amount := NVL(clm_rec.curr_claim_buff_utilised,0);

              IF clm_rec.document_general_type_id != 'DTA' OR (clm_rec.document_general_type_id = 'DTA' AND v_appr_count = 0 ) THEN
                v_sum   :=  NVL(clm_rec.app_sum_insured,0) - NVL(clm_rec.pat_app_sum,0)    ;
                v_bonus :=  NVL(clm_rec.app_cum_bonus,0) - NVL(clm_rec.pat_app_bonus,0)    ;
                v_buff  :=  NVL(v_utilised_amount,0) - NVL(clm_rec.pre_auth_buffer_app_amount,0);
              ELSE
                v_sum   :=  NVL(clm_rec.app_sum_insured,0);
                v_bonus :=  NVL(clm_rec.app_cum_bonus,0);
                v_buff  :=  v_utilised_amount;
              END IF;
        IF CLM_REC.CLAIM_SUB_GENERAL_TYPE_ID='OPD' AND v_opd_benefit_flag='Y' THEN  --KOC1286

               UPDATE clm_general_details a
                 SET a.opd_utilsed_amount=v_sum,a.opd_flag_yn='Y'
                    WHERE A.CLAIM_SEQ_ID=v_claim_seq_id;
            ELSE
              UPDATE tpa_enr_balance a SET
                    a.utilised_sum_insured = a.utilised_sum_insured - v_sum,
                    a.utilised_cum_bonus   = a.utilised_cum_bonus - v_bonus,
                --    a.utilised_buff_amount = a.utilised_buff_amount - v_buff,
                    a.utilised_buff_amount = case when CLM_REC.claim_type='NRML' AND CLM_REC.Buffer_Type='CORB' THEN  a.utilised_buff_amount - v_buff ELSE a.utilised_buff_amount END,
                    a.utilised_med_buff_amount =case when CLM_REC.claim_type='NRML' AND CLM_REC.Buffer_Type='MEDB' THEN  a.utilised_med_buff_amount - v_buff ELSE a.utilised_med_buff_amount END,
                    a.utilised_crit_buff_amount =case when CLM_REC.claim_type='CRTL' AND CLM_REC.Buffer_Type='CRTB' THEN  a.utilised_crit_buff_amount - v_buff ELSE a.utilised_crit_buff_amount END,
                    a.utilised_crit_corp_buff_amt =case when CLM_REC.claim_type='CRTL' AND CLM_REC.Buffer_Type='CORB' THEN  a.utilised_crit_corp_buff_amt - v_buff ELSE a.utilised_crit_corp_buff_amt END,
                    a.utilised_crit_med_buff_amt = case when CLM_REC.claim_type='CRTL' AND CLM_REC.Buffer_Type='MEDB' THEN  a.utilised_crit_med_buff_amt  - v_buff ELSE a.utilised_crit_med_buff_amt  END,
                    a.updated_by             = v_added_by,
                    a.updated_date           = SYSDATE,
                    a.used_restrict_amt    = (case when v_restrict_yn='Y' then (a.used_restrict_amt-v_sum) else v_sum end) --koc1142
                    WHERE a.balance_seq_id = clm_rec.balance_seq_id;
                    update clm_general_details a
                    set a.opd_utilsed_amount=v_sum,a.opd_flag_yn='N'
                    WHERE A.CLAIM_SEQ_ID=v_claim_seq_id;
             END IF;

              IF v_buff != 0 THEN
                IF clm_rec.buffer_alloc_general_type_id = 'BAF' AND clm_rec.policy_sub_general_type_id != 'PFL' THEN  -- Buffer allocation per Individual
                    UPDATE tpa_enr_balance a SET
                --    a.utilised_buff_amount = a.utilised_buff_amount - v_buff,
                      a.utilised_buff_amount = case when CLM_REC.claim_type='NRML' AND CLM_REC.Buffer_Type='CORB' THEN  a.utilised_buff_amount - v_buff ELSE a.utilised_buff_amount  END,
                      a.utilised_med_buff_amount =case when CLM_REC.claim_type='NRML' AND CLM_REC.Buffer_Type='MEDB' THEN  a.utilised_med_buff_amount - v_buff ELSE a.utilised_med_buff_amount  END,
                      a.utilised_crit_buff_amount =case when CLM_REC.claim_type='CRTL' AND CLM_REC.Buffer_Type='CRTB' THEN  a.utilised_crit_buff_amount - v_buff ELSE a.utilised_crit_buff_amount END,
                      a.utilised_crit_corp_buff_amt =case when CLM_REC.claim_type='CRTL' AND CLM_REC.Buffer_Type='CORB' THEN  a.utilised_crit_corp_buff_amt - v_buff ELSE a.utilised_crit_corp_buff_amt END,
                      a.utilised_crit_med_buff_amt = case when CLM_REC.claim_type='CRTL' AND CLM_REC.Buffer_Type='MEDB' THEN  a.utilised_crit_med_buff_amt  - v_buff ELSE a.utilised_crit_med_buff_amt  END,
                      a.updated_by             = v_added_by,
                      a.updated_date           = SYSDATE
                      WHERE a.policy_group_seq_id = clm_rec.policy_group_seq_id AND
                        a.balance_seq_id != clm_rec.balance_seq_id;
                END IF;

                IF clm_rec.mem_buffer_seq_id IS NOT NULL THEN
                  UPDATE tpa_enr_mem_buffer a SET
               --   a.used_buff_amount = a.used_buff_amount - v_buff,
                    a.used_buff_amount = case when clm_rec.claim_type='NRML' AND clm_rec.Buffer_Type='CORB' THEN a.used_buff_amount - v_buff ELSE a.used_buff_amount END ,
                    a.Used_Med_Buff_Amt =case when clm_rec.claim_type='NRML' AND clm_rec.Buffer_Type='MEDB' THEN  a.Used_Med_Buff_Amt - v_buff ELSE a.Used_Med_Buff_Amt END,
                    a.Used_Crit_Buff_Amt =case when clm_rec.claim_type='CRTL' AND clm_rec.Buffer_Type='CRTB' THEN  a.Used_Crit_Buff_Amt - v_buff ELSE a.Used_Crit_Buff_Amt END,
                    a.Used_Crit_Corp_Buff_Amt =case when clm_rec.claim_type='CRTL' AND clm_rec.Buffer_Type='CORB' THEN  a.Used_Crit_Corp_Buff_Amt - v_buff ELSE a.Used_Crit_Corp_Buff_Amt   END,
                    a.Used_Crit_Med_Buff_Amt = case when clm_rec.claim_type='CRTL' AND clm_rec.Buffer_Type='MEDB' THEN  a.Used_Crit_Med_Buff_Amt - v_buff ELSE a.Used_Crit_Med_Buff_Amt END,
                    a.updated_by             = v_added_by,
                    a.updated_date           = SYSDATE
                    WHERE a.mem_buffer_seq_id = clm_rec.mem_buffer_seq_id;
                END IF;
              END IF;

            ELSE

              IF clm_rec.document_general_type_id != 'DTA' OR (clm_rec.document_general_type_id = 'DTA' AND v_appr_count = 0 ) THEN
                v_sum   :=  NVL(clm_rec.app_sum_insured,0) - NVL(clm_rec.pat_app_sum,0)    ;
                v_bonus :=  NVL(clm_rec.app_cum_bonus,0) - NVL(clm_rec.pat_app_bonus,0)    ;
              ELSE
                v_sum   :=  NVL(clm_rec.app_sum_insured,0);
                v_bonus :=  NVL(clm_rec.app_cum_bonus,0);
              END IF;

              UPDATE tpa_enr_balance a SET
                  a.utilised_sum_insured = a.utilised_sum_insured - v_sum,
                  a.utilised_cum_bonus   = a.utilised_cum_bonus - v_bonus,
                  a.updated_by             = v_added_by,
                  a.updated_date           = SYSDATE,
                  a.used_restrict_amt      = (case when v_restrict_yn='Y' then (a.used_restrict_amt-v_sum) else used_restrict_amt end) --koc1142
                  WHERE a.balance_seq_id = clm_rec.balance_seq_id;
            END IF;
          END IF;
        END IF;
        
        IF clm_rec.clm_status_general_type_id = 'APR' AND clm_rec.claim_sub_general_type_id = 'OPD' THEN
        --  dom_rec.utilised_dom_amount := dom_rec.utilised_dom_amount - ( clm_rec.total_app_amount - NVL(clm_rec.curr_claim_buff_utilised,0));
          IF  NVL(dom_rec.additional_domicilary_yn,'Y') = 'N' THEN  --Added for KOC1216C
          /*IF v_opd_benefit_flag='Y' THEN  --KOC1286
                dom_rec.utilised_dom_amount:=clm_rec.total_app_amount;
           ELSE*/
           dom_rec.utilised_dom_amount := dom_rec.utilised_dom_amount - ( clm_rec.total_app_amount );
         -- END IF;
          ELSE
             dom_rec.utilised_dom_amount := dom_rec.utilised_dom_amount - ( clm_rec.total_app_amount - NVL(clm_rec.curr_claim_buff_utilised,0));
          END IF;
          IF dom_rec.utilised_dom_amount > NVL(dom_rec.domicilary_limit,0) THEN
            RAISE_APPLICATION_ERROR(-20737,'Sufficient balance does not exist');
          END IF;
          UPDATE tpa_enr_domicilary a SET
            a.utilised_dom_amount = dom_rec.utilised_dom_amount
            WHERE a.domicilary_seq_id = dom_rec.domicilary_seq_id ;
        END IF;

        v_total_app_amount := NULL;
        IF clm_rec.completed_yn = 'Y' THEN
          IF clm_rec.pat_enroll_detail_seq_id IS NOT NULL AND v_appr_count = 0 THEN
              -- deleting buffer records of claims for which the preauth was associated
             SELECT COUNT(1) INTO v_ctr
                             FROM clm_general_details a WHERE a.pat_enroll_detail_seq_id = clm_rec.pat_enroll_detail_seq_id
                              AND a.claim_seq_id NOT IN ( SELECT b.claim_seq_id FROM clm_general_details b
                                  START WITH b.claim_seq_id = v_claim_seq_id CONNECT BY PRIOR b.parent_claim_seq_id = b.claim_seq_id );
             IF v_ctr > 0 THEN
               FOR rec IN ( SELECT b.claim_seq_id,b.last_buffer_detail_seq_id FROM clm_general_details b
                                  START WITH b.claim_seq_id = v_claim_seq_id CONNECT BY PRIOR b.parent_claim_seq_id = b.claim_seq_id
                            ORDER BY b.claim_seq_id DESC)
               LOOP
                 IF rec.last_buffer_detail_seq_id IS NOT NULL THEN
                   pre_auth_pkg.delete_claim_buffer(rec.claim_seq_id) ;
                 END IF;
               END LOOP;
             END IF;
          END IF;
        END IF;
      ELSIF clm_rec.completed_yn = 'Y' THEN
        RAISE_APPLICATION_ERROR(-20107,' You cannot modify  this Pre-Auth/claim , Reviews are Completed');
      ELSE -- OTHER THAN REJECTION OR CANCELLATION
          -- CHECKING WHETHER THE CLAIM IS COMPLETED OR NOT.
        pre_auth_pkg.check_clm_completed ( v_claim_seq_id , NULL,'ASN', v_added_by );

        IF v_pat_status_general_type_id = 'APR' THEN

          --Check for approval limits of user and branch.
          pre_auth_pkg.check_approval_limit(v_added_by, v_max_app_amount,'CLM');

          IF v_claim_settlement_number IS NULL THEN
            IF clm_rec.document_general_type_id != 'DTA' THEN
              v_claim_settlement_number := pre_auth_pkg.generate_id_numbers ('STC', nvl( clm_rec.policy_tpa_office_seq_id,clm_rec.tpa_office_seq_id ) , clm_rec.claim_number , v_added_by , clm_rec.claim_general_type_id );
            ELSE
              v_claim_settlement_number := pre_auth_pkg.generate_id_numbers ('STA', nvl( clm_rec.policy_tpa_office_seq_id,clm_rec.tpa_office_seq_id ) , clm_rec.claim_number , v_added_by , clm_rec.claim_general_type_id );
            END IF;
          END IF;
        END IF;
        -- APPROVAL PART
        IF v_pat_status_general_type_id = 'APR' AND clm_rec.claim_sub_general_type_id not in ('HCU','CTL') THEN --koc1273 added CTL for HCU
          IF clm_rec.date_of_admission < clm_rec.policy_effective_from THEN
            raise_application_error(-20171,'Date of Hospitalization is earlier than policy start date');
          END IF;

--          IF clm_rec.clm_status_general_type_id != v_pat_status_general_type_id OR v_discount_differ_yn = 'Y' THEN
            IF clm_rec.requested_amount < v_max_app_amount THEN
              raise_application_error(-20174,'Approved amount is greater than the requested amount');
            END IF;
            IF clm_rec.claim_general_type_id != 'CTM' THEN
              OPEN perc_cur;
              FETCH perc_cur INTO v_perc_increase;
              CLOSE perc_cur;

              IF clm_rec.document_general_type_id = 'DTA' THEN
                -- Getting the total approved amount for the ammendment
                SELECT SUM(A.TOTAL_APP_AMOUNT) INTO v_total_claim_app_amount
                    FROM clm_general_details A
                    WHERE a.claim_seq_id != v_claim_seq_id START WITH a.claim_seq_id = v_claim_seq_id
                    CONNECT BY  a.claim_seq_id = PRIOR a.parent_claim_seq_id;

                v_max_amount := NVL(v_total_claim_app_amount,0) + NVL(v_max_app_amount,0);
              ELSE
                v_max_amount := v_max_app_amount;
              END IF;

--koc1277
              IF v_perc_increase IS NOT NULL AND v_max_amount > ( clm_rec.pat_approved_amount * ( 100 + v_perc_increase ) / 100 ) THEN
                 IF NVL(v_perc_increase,0)=0 THEN
                    raise_application_error(-20809,'Claim Cannot be Approved more than the Final Pre-auth Approved Amount. ');
                   ELSE
                    raise_application_error(-20169,'Claim cannot be approved above the considerable percentage limit of approved preauth ');
                 END IF;
              END IF;
--koc1277

              IF v_perc_increase IS NOT NULL AND v_max_amount > ( clm_rec.pat_approved_amount * ( 100 + v_perc_increase ) / 100 ) THEN
                 IF NVL(v_perc_increase,0)=0 THEN
                    raise_application_error(-20809,'Claim Cannot be Approved more than the Final Pre-auth Approved Amount. ');
                   ELSE
                    raise_application_error(-20169,'Claim cannot be approved above the considerable percentage limit of approved preauth ');
                 END IF;
              END IF;
            END IF;

/*            IF v_max_app_amount > ( nvl(clm_rec.ava_sum_insured,0) + CASE WHEN v_appr_count = 0 THEN nvl(nvl(clm_rec.total_app_amount,clm_rec.pat_approved_amount),0) ELSE nvl(clm_rec.total_app_amount,0) END + nvl(clm_rec.ava_cum_bonus,0) + nvl(clm_rec.claim_app_buffer_amount,0) + nvl(clm_rec.pre_auth_buffer_app_amount,0) - nvl(clm_rec.utilised_amount,0)) THEN
              raise_application_error(-20737,'Sufficient balance does not exist. '); --Removed for  KOC1216C
            END IF;*/

          IF  clm_rec.claim_sub_general_type_id != 'OPD' OR ( clm_rec.claim_sub_general_type_id = 'OPD' AND  NVL(dom_rec.additional_domicilary_yn,'Y')='N')THEN --Added for KOC1216C
            IF v_opd_benefit_flag='Y' AND v_max_app_amount> DOM_REC.DOMICILARY_LIMIT-DOM_REC.UTILISED_DOM_AMOUNT THEN --KOC1286
              raise_application_error(-20737,'Sufficient balance does not exist. ');
             ELSIF NVL(v_opd_benefit_flag,'N')='N' AND v_max_app_amount > ( nvl(clm_rec.ava_sum_insured,0) + CASE WHEN v_appr_count = 0 THEN nvl(nvl(clm_rec.total_app_amount,clm_rec.pat_approved_amount),0) ELSE nvl(clm_rec.total_app_amount,0) END + nvl(clm_rec.ava_cum_bonus,0) + nvl(clm_rec.claim_app_buffer_amount,0) + nvl(clm_rec.pre_auth_buffer_app_amount,0) - nvl(clm_rec.utilised_amount,0)) THEN
              raise_application_error(-20737,'Sufficient balance does not exist. ');
            END IF;
            IF clm_rec.claim_sub_general_type_id = 'OPD'  THEN
            IF  NVL(dom_rec.domicilary_limit,0) <(NVL(dom_rec.utilised_dom_amount,0)+NVL(v_max_app_amount,0)) THEN
              raise_application_error(-20737,'Sufficient balance does not exist. ');

            END IF;
            END IF;
          ELSIF  clm_rec.claim_sub_general_type_id = 'OPD' AND  NVL(dom_rec.additional_domicilary_yn,'Y')='N' THEN
            IF  NVL(dom_rec.domicilary_limit,0)<(NVL(dom_rec.utilised_dom_amount,0)+NVL(v_max_app_amount,0)) THEN
              raise_application_error(-20737,'Sufficient balance does not exist. ');
            END IF;
          END IF;


          IF clm_rec.clm_status_general_type_id != v_pat_status_general_type_id OR v_discount_differ_yn = 'Y' THEN
            -- CHECKING WHETHER THE CLAIM CAN BE APPROVED OR NOT.
            check_clm_approved ( v_claim_seq_id );

            PRE_AUTH_PKG.check_approval_limit( v_added_by, v_max_app_amount,'CLM');

            IF clm_rec.claim_sub_general_type_id != 'OPD' OR clm_rec.claim_sub_general_type_id = 'OPD' AND NVL(dom_rec.additional_domicilary_yn,'Y') = 'N' THEN
              IF clm_rec.document_general_type_id != 'DTA' OR (clm_rec.document_general_type_id = 'DTA'  AND v_appr_count = 0 ) THEN  -- not ammendment
                IF clm_rec.app_sum_insured = 0 THEN
                  clm_rec.app_sum_insured := NULL;
                END IF;

                IF clm_rec.app_cum_bonus = 0 THEN
                  clm_rec.app_cum_bonus := NULL;
                END IF;
                -- in the case of co-payment amount or doscount amount is changed with out changing the status

                v_current_ava_sum_insured := clm_rec.ava_sum_insured + NVL(clm_rec.app_sum_insured , NVL(clm_rec.pat_app_sum,0));-- CASE WHEN v_discount_differ_yn = 'Y' THEN NVL(clm_rec.app_sum_insured,0) ELSE 0 END  ;

                IF NVL(clm_rec.ava_cum_bonus,0) + NVL(NVL( clm_rec.app_cum_bonus , clm_rec.pat_app_bonus ),0) <=  clm_rec.bonus  THEN
                  v_ava_cum_bonus := clm_rec.ava_cum_bonus + NVL( clm_rec.app_cum_bonus , NVL(clm_rec.pat_app_bonus,0)) ;
                ELSE
                  v_ava_cum_bonus := clm_rec.bonus ;
                END IF;
              ELSE
                v_current_ava_sum_insured := clm_rec.ava_sum_insured + NVL( clm_rec.app_sum_insured ,0) ; -- CASE WHEN v_discount_differ_yn = 'Y' THEN NVL(clm_rec.app_sum_insured,0) ELSE 0 END ;
                IF NVL(clm_rec.ava_cum_bonus,0) + NVL( clm_rec.app_cum_bonus ,0) <=  clm_rec.bonus  THEN
                  v_ava_cum_bonus := clm_rec.ava_cum_bonus + NVL( clm_rec.app_cum_bonus /*, NVL(clm_rec.pat_app_bonus,0)*/,0);
                ELSE
                  v_ava_cum_bonus := clm_rec.bonus ;
                END IF;
              END IF;

              IF v_max_app_amount  >= v_current_ava_sum_insured THEN -- to check whether cumulative bonus or buffer is used
                 v_app_sum_insured := v_current_ava_sum_insured;
                 IF v_max_app_amount >= ( v_current_ava_sum_insured + v_ava_cum_bonus ) THEN
                   v_app_cum_bonus   := v_ava_cum_bonus ;
                   v_utilised_amount := v_max_app_amount - ( v_current_ava_sum_insured + v_ava_cum_bonus );

                 ELSE
                   v_app_cum_bonus  := v_max_app_amount - v_current_ava_sum_insured  ;
                 END IF;
              ELSE
                v_app_sum_insured := v_max_app_amount;
              END IF;

--koc1277 Or condition added, to effect for approved  amount Zero cases
             IF NVL(clm_rec.total_app_amount,0) != v_max_app_amount
                or ( NVL(clm_rec.total_app_amount,0) = v_max_app_amount and  clm_rec.policy_deductable_yn = 'Y'  and clm_rec.pat_enroll_detail_seq_id is not null
  and clm_rec.clm_status_general_type_id != v_pat_status_general_type_id
  and clm_rec.claim_sub_general_type_id != 'OPD' and  v_pat_status_general_type_id='APR'
     and clm_rec.clm_status_general_type_id in ('INP','REQ') )  THEN
--koc1277 Or condition added, to effect for approved  amount Zero cases

--              IF NVL(clm_rec.total_app_amount,0) != v_max_app_amount THEN  ---commented for koc1277 to effect for approved  amount Zero cases
                IF ( clm_rec.document_general_type_id != 'DTA' OR (clm_rec.document_general_type_id = 'DTA'  AND v_appr_count = 0 )) THEN
                  v_utilised_sum             := clm_rec.utilised_sum_insured + ( NVL( v_app_sum_insured,0)  - NVL(clm_rec.pat_app_sum,0));
                  v_utilised_sumr            := clm_rec.used_restrict_amt    + ( NVL( v_app_sum_insured,0)  - NVL(clm_rec.pat_app_sum,0)); --koc1142
                  IF v_discount_differ_yn = 'N' THEN
                    v_utilised_cum             := clm_rec.utilised_cum_bonus  + ( NVL( v_app_cum_bonus,0)  - NVL(clm_rec.pat_app_bonus,0));
                  ELSE
                    v_utilised_cum             := clm_rec.utilised_cum_bonus  +  ( NVL( v_app_cum_bonus,0)  - NVL(clm_rec.app_cum_bonus,0));
                  END IF;
                    ELSE
                  v_utilised_sum             := clm_rec.utilised_sum_insured + ( NVL( v_app_sum_insured,0) );
                  v_utilised_sumr            := clm_rec.used_restrict_amt +    ( NVL( v_app_sum_insured,0) ); --koc1142
                  IF v_discount_differ_yn = 'N' THEN
                    v_utilised_cum             := clm_rec.utilised_cum_bonus  + ( NVL( v_app_cum_bonus,0));
                  ELSE
                    v_utilised_cum             := clm_rec.utilised_cum_bonus  + ( NVL( v_app_cum_bonus,0) - NVL(clm_rec.app_cum_bonus,0));
                  END IF;
                  END IF;

               IF clm_rec.buffer_alloc_general_type_id = 'BAI' AND clm_rec.mem_buffer_seq_id IS NOT NULL THEN
                  IF ( clm_rec.sum_insured + clm_rec.bonus  ) < ( v_utilised_sum + v_utilised_cum ) THEN
                    raise_application_error(-20167,'  You have to Re-approve the Claim , Member/policy information changed.');
                  END IF;
                ELSE 
                 
                  IF ( clm_rec.sum_insured + clm_rec.bonus ) < ( v_utilised_sum + v_utilised_cum ) THEN
                    raise_application_error(-20167,'  You have to Re-approve the Claim , Member/policy information changed.');
                  END IF;
                END IF;

                IF ( v_utilised_sum + v_utilised_cum ) >=  clm_rec.sum_insured  THEN
                  v_bonus     := ( v_utilised_sum + v_utilised_cum  ) - clm_rec.sum_insured ;
                  v_sum       := clm_rec.sum_insured ;
                ELSE
                  v_sum       := ( v_utilised_sum + v_utilised_cum );
                  v_bonus     := 0;
                END IF;
                --koc1142
               if (v_utilised_sumr+v_utilised_cum ) >=  clm_rec.restrict_amt then
                 -- v_bonus     := ( v_utilised_sumr + v_utilised_cum  ) - clm_rec.restrict_amt ;
                  v_sumr       := clm_rec.restrict_amt ;
                ELSE
                  v_sumr       := ( v_utilised_sumr + v_utilised_cum );
                --  v_bonus     := 0;
                END IF; --koc1142


              IF CLM_REC.CLAIM_SUB_GENERAL_TYPE_ID='OPD' AND v_opd_benefit_flag='Y' THEN  --KOC1286
                   UPDATE clm_general_details a
                    SET a.opd_utilsed_amount=v_sum,a.opd_flag_yn='Y'
                    WHERE A.CLAIM_SEQ_ID=v_claim_seq_id;
                 ELSE
                UPDATE tpa_enr_balance a SET
                    a.utilised_sum_insured = v_sum,
                    a.utilised_cum_bonus   = v_bonus,
                    a.updated_by             = v_added_by,
                    a.updated_date           = SYSDATE,
                    a.used_restrict_amt      = (case when v_restrict_yn ='Y' then v_sumr else a.used_restrict_amt end) --koc1142
                    WHERE a.balance_seq_id = clm_rec.balance_seq_id ;

                    UPDATE clm_general_details a
                     SET a.opd_utilsed_amount=v_sum,a.opd_flag_yn='N'
                     WHERE A.CLAIM_SEQ_ID=v_claim_seq_id;
              END IF;
           END IF;
           END IF;

           IF clm_rec.claim_sub_general_type_id = 'OPD' THEN --Changed for KOC1216C
             v_ava_dom_amount := dom_rec.domicilary_limit - ( nvl(dom_rec.utilised_dom_amount,0) + nvl(clm_rec.total_app_amount,0) - nvl(clm_rec.curr_claim_buff_utilised,0));
             IF v_ava_dom_amount < v_max_app_amount THEN
               dom_rec.utilised_dom_amount := dom_rec.domicilary_limit;
               v_utilised_amount := v_max_app_amount - v_ava_dom_amount;
             ELSE
               dom_rec.utilised_dom_amount := dom_rec.utilised_dom_amount + v_max_app_amount ;
             END IF;
            IF  NVL(dom_rec.additional_domicilary_yn,'Y') = 'Y'  THEN --Changed for  KOC1216C
              v_app_sum_insured := NULL;
             v_app_cum_bonus   := NULL;
             v_sum             := NULL;
             v_bonus           := NULL;
           END IF;
          END IF;
         ELSE
           v_app_sum_insured    := clm_rec.app_sum_insured;
           v_app_cum_bonus      := clm_rec.app_cum_bonus;
           v_discount_amount    := clm_rec.discount_amount;
           v_co_payment_amount  := clm_rec.co_payment_amount;
           v_co_pay_buff_amount := nvl(clm_rec.co_payment_buffer_amount,0); --KOCIBM
         END IF;

       ELSIF clm_rec.clm_status_general_type_id = 'APR' AND clm_rec.claim_sub_general_type_id not in ('HCU','CTL') THEN --koc1273 added CTL for HCU
         IF clm_rec.claim_sub_general_type_id != 'OPD' OR clm_rec.claim_sub_general_type_id = 'OPD' AND NVL(dom_rec.additional_domicilary_yn,'Y') = 'N' THEN
            IF ( clm_rec.document_general_type_id != 'DTA' OR ( clm_rec.document_general_type_id = 'DTA' AND v_appr_count = 0 )) THEN
              v_sum   :=  clm_rec.utilised_sum_insured -  NVL(clm_rec.app_sum_insured,0) + NVL(clm_rec.pat_app_sum,0);
              v_bonus :=  clm_rec.utilised_cum_bonus   -  NVL(clm_rec.app_cum_bonus,0) + NVL(clm_rec.pat_app_bonus,0);
              v_sumr   :=  clm_rec.used_restrict_amt -  NVL(clm_rec.app_sum_insured,0) + NVL(clm_rec.pat_app_sum,0); --koc1142
            ELSE
              v_sum   :=  clm_rec.utilised_sum_insured - ( NVL(clm_rec.app_sum_insured,0));
              v_bonus :=  clm_rec.utilised_cum_bonus   - ( NVL(clm_rec.app_cum_bonus,0));
              v_sumr   :=  clm_rec.used_restrict_amt - ( NVL(clm_rec.app_sum_insured,0)); --koc1142
            END IF;

            IF v_bonus != 0  THEN
              if v_restrict_yn ='N' then --koc1142
              IF (v_sum + v_bonus  ) >=  clm_rec.sum_insured  THEN
                v_sum := clm_rec.sum_insured ;
                v_bonus := ( v_sum + v_bonus  ) - clm_rec.sum_insured;
              ELSE
                v_sum   := ( v_sum + v_bonus  );
                v_bonus := 0;
              END IF;
            END IF;

            else  --koc1142
                IF (v_sumr + v_bonus  ) >=  clm_rec.restrict_amt  THEN
                v_sumr := clm_rec.restrict_amt ;
                v_bonus := ( v_sumr + v_bonus  ) - clm_rec.restrict_amt;
              ELSE
                v_sumr   := ( v_sumr + v_bonus  );
                v_bonus := 0;
              END IF;
              end if;  -- koc1142

            UPDATE tpa_enr_balance a SET
                a.utilised_sum_insured = v_sum,
                a.utilised_cum_bonus   = v_bonus,
                a.updated_by             = v_added_by,
                a.updated_date           = SYSDATE,
                a.used_restrict_amt     = (case when v_restrict_yn = 'Y' then v_sumr else a.used_restrict_amt end) --koc1142
                WHERE a.balance_seq_id = clm_rec.balance_seq_id;

            v_app_sum_insured  := NULL;
            v_app_cum_bonus    := NULL;
            v_total_app_amount := NULL;
         END IF;
        

          --Changes done for KOC1216C
         IF clm_rec.clm_status_general_type_id = 'APR' AND (clm_rec.claim_sub_general_type_id = 'OPD' AND  NVL(dom_rec.additional_domicilary_yn,'Y') = 'N') THEN
           dom_rec.utilised_dom_amount := dom_rec.utilised_dom_amount - NVL(clm_rec.total_app_amount,0);
           v_utilised_amount := NULL;
         ELSIF clm_rec.clm_status_general_type_id = 'APR' AND clm_rec.claim_sub_general_type_id = 'OPD' THEN
           dom_rec.utilised_dom_amount := dom_rec.utilised_dom_amount - ( NVL(clm_rec.total_app_amount,0) - nvl(clm_rec.curr_claim_buff_utilised,0));
           v_utilised_amount := NULL;
         END IF;
         --Changes done for KOC1216C
       ELSIF v_pat_status_general_type_id != 'APR'  THEN
         v_total_app_amount := NULL;
       END IF;

--koc1273

if clm_rec.claim_sub_general_type_id ='CTL'  THEN

  IF  prod_info_rec.critical_benefit_yn='Y' then

         if v_pat_status_general_type_id = 'APR' and clm_rec.clm_status_general_type_id in ('INP','REQ') then

check_clm_approved(v_claim_seq_id);

             v_app_sum_insured := least(nvl(clm_rec.sum_insured,0)- nvl(clm_rec.utilised_sum_insured,0),nvl(v_total_app_amount,0));
             v_app_cum_bonus   := least(nvl(clm_rec.bonus,0)- nvl(clm_rec.utilised_cum_bonus,0),nvl(v_total_app_amount,0)-nvl(v_app_sum_insured,0));

             update tpa_enr_balance bal
             set bal.utilised_sum_insured = nvl(bal.utilised_sum_insured,0) + nvl(v_app_sum_insured,0),
                 bal.utilised_cum_bonus   = nvl(bal.utilised_cum_bonus,0) + nvl(v_app_cum_bonus,0)
             where bal.balance_seq_id = clm_rec.balance_seq_id;

                 v_total_app_amount := nvl(v_app_sum_insured,0) + nvl(v_app_cum_bonus,0);

if v_total_app_amount <= 0 then
  RAISE_APPLICATION_ERROR(-20737,'Sufficient balance does not exist');
end if;



            ELSIF v_pat_status_general_type_id in ('INP','REQ','REJ','PCO')
                                               and clm_rec.clm_status_general_type_id='APR' then

             update tpa_enr_balance bal
             set bal.utilised_sum_insured = nvl(bal.utilised_sum_insured,0) - nvl(clm_rec.app_sum_insured,0),
                 bal.utilised_cum_bonus   = nvl(bal.utilised_cum_bonus,0) - nvl(clm_rec.app_cum_bonus,0)
             where bal.balance_seq_id = clm_rec.balance_seq_id;

                     v_total_app_amount := NULL;
                     v_app_sum_insured  := NULL;
                     v_app_cum_bonus    := NULL;
                     v_sum              := NULL;
                     v_bonus            := NULL;
                     v_buff             := NULL;

            end if;

else

--                     v_total_app_amount := NULL;
                     v_app_sum_insured  := NULL;
                     v_app_cum_bonus    := NULL;
                     v_sum              := NULL;
                     v_bonus            := NULL;
                     v_buff             := NULL;

end if;

END IF;


       IF clm_rec.claim_sub_general_type_id ='HCU' OR (clm_rec.claim_sub_general_type_id='OPD' AND  NVL(dom_rec.additional_domicilary_yn,'Y') = 'Y') THEN  -- HEALTH CHECK UP
         IF v_pat_status_general_type_id = 'APR' THEN
           IF clm_rec.claim_sub_general_type_id ='HCU' THEN
             v_app_sum_insured := 0;
             v_app_cum_bonus   := 0;
             v_sum             := clm_rec.ava_sum_insured;
             v_bonus           := clm_rec.ava_cum_bonus;
             v_buff            := NULL ;
           END IF;
         ELSE
           v_total_app_amount := NULL;
           v_app_sum_insured := NULL;
           v_app_cum_bonus   := NULL;
           v_sum             := NULL;
           v_bonus           := NULL;
           v_buff            := NULL;
         END IF;
       END IF;
 --Changes done for KOC1216C

       UPDATE clm_general_details SET
            total_app_amount                        =  v_total_app_amount,
            app_sum_insured                         =  CASE WHEN (CLM_REC.CLAIM_SUB_GENERAL_TYPE_ID='OPD' AND v_opd_benefit_flag = 'Y') THEN 0 ELSE v_app_sum_insured END ,--KOC1286
            claim_settlement_number                 =  v_claim_settlement_number ,
            app_cum_bonus                           =  v_app_cum_bonus,
--          ava_sum_insured                         =  CASE WHEN v_pat_status_general_type_id = 'APR' AND v_sum IS NULL THEN ava_sum_insured ELSE clm_rec.sum_insured - v_sum END,
--          ava_cum_bonus                           =  CASE WHEN v_pat_status_general_type_id = 'APR' AND v_bonus IS NULL THEN ava_cum_bonus ELSE clm_rec.bonus - v_bonus END ,
--          ava_buff_amount                         =  CASE WHEN v_pat_status_general_type_id = 'APR' AND v_buff IS NULL THEN ava_buff_amount ELSE clm_rec.buffer_amount - v_buff END,
            discount_amount                         =  v_discount_amount,
            co_payment_amount                       =  v_co_payment_amount,
            co_payment_buffer_amount                =  v_co_pay_buff_amount, --KOCIBM
            utilised_buff_amt                       =  CASE WHEN (CLM_REC.CLAIM_SUB_GENERAL_TYPE_ID='OPD' AND v_opd_benefit_flag = 'Y') THEN 0 ELSE v_utilised_amount END ,--KOC1286
            deposit_amount                          =  v_deposit_amount,
            serv_tax_calc_amount                    =  v_service_tax_calc_amt,
            serv_tax_calc_percentage                =  v_serv_tax_calc_percentage,
            updated_by                              =  v_added_by,
            updated_date                            =  SYSDATE,
            permission_sought_from                  =  v_permission_sought_from,
      FINAL_APP_YN                            =  v_FINAL_APP_YN--koc_ins_mail
            WHERE claim_seq_id  = v_claim_seq_id
            RETURNING last_assign_user_seq_id INTO v_assign_users_seq_id ;

  

        UPDATE clm_enroll_details SET
          mem_total_sum_insured                     = clm_rec.sum_insured ,
          clm_status_general_type_id                = v_pat_status_general_type_id ,
          rson_general_type_id                      = v_rson_general_type_id ,
          decision_date                             = v_completed_date ,
          updated_by                                = v_added_by ,
          updated_date                              = SYSDATE
          WHERE clm_enroll_detail_seq_id = clm_rec.clm_enroll_detail_seq_id ;
    -- Check the status of the pre-auth

        UPDATE assign_users SET
              remarks                                 = v_remarks ,
              completed_date                          = v_completed_date,
              pat_status_general_type_id              = v_pat_status_general_type_id,
              rson_general_type_id                    = v_rson_general_type_id,
              total_app_amount                        = v_total_app_amount,
              updated_by                              = v_added_by,
              updated_date                            = SYSDATE
              WHERE assign_users_seq_id = v_assign_users_seq_id;
      END IF;
      IF clm_rec.claim_sub_general_type_id = 'OPD' THEN
        UPDATE tpa_enr_domicilary a
           SET a.utilised_dom_amount = nvl(dom_rec.utilised_dom_amount,0)
          WHERE a.domicilary_seq_id = dom_rec.domicilary_seq_id ;
      END IF;

      IF v_pat_status_general_type_id != 'APR' AND v_service_tax_calc_amt is not null then
         UPDATE clm_general_details SET
           serv_tax_calc_amount                    =  NULL,
           serv_tax_calc_percentage                =  NULL,
           updated_by                              =  v_added_by,
           updated_date                            =  SYSDATE
         WHERE claim_seq_id  = v_claim_seq_id;
      END IF;

      IF v_pat_status_general_type_id = 'APR' AND v_service_tax_calc_amt IS NOT NULL THEN
         UPDATE clm_bill_details cb
           SET cb.allowed_amount = v_service_tax_calc_amt /*CASE WHEN v_service_tax_calc_amt < stx_rec.requested_amount THEN v_service_tax_calc_amt END*/,
               cb.rejected_amount = CASE WHEN v_service_tax_calc_amt < stx_rec.requested_amount THEN stx_rec.requested_amount-v_service_tax_calc_amt END
          WHERE cb.clm_bill_dtl_seq_id=stx_rec.clm_bill_dtl_seq_id;
      ELSE
         UPDATE clm_bill_details cb
           SET cb.allowed_amount = NULL,
               cb.rejected_amount = stx_rec.requested_amount
          WHERE cb.clm_bill_dtl_seq_id=stx_rec.clm_bill_dtl_seq_id;
      END IF;
    END IF;
    update clm_general_details set Inv_Disallowed_Amt = v_Inv_Disallowed_Amt where claim_seq_id = v_claim_seq_id; --Added for Koc_investigation

	--KOC1320
    OPEN med_vst_cur;
    FETCH med_vst_cur INTO v_med_vst;
    CLOSE med_vst_cur;
  --Added for koc1320
      IF v_pat_status_general_type_id = 'APR' THEN
         update app.clm_general_details set total_app_vst = v_med_vst where claim_seq_id = v_claim_seq_id;
         ELSE
           update app.clm_general_details set total_app_vst = NULL where claim_seq_id = v_claim_seq_id;
            END IF;
	v_rows_processed  := 1;
    end if; --koc1277 provided to avoid resave of same status like from APR to APR, from REJ to REJ
    COMMIT;
  END save_settlement ;
--=========================================================================================================
  PROCEDURE check_conflict (
    v_claim_seq_id                                     IN DISCREPANCY_INFORMATION.claim_seq_id%TYPE,
    v_clm_enroll_detail_seq_id                         IN CLM_ENROLL_DETAILS.clm_enroll_detail_seq_id%TYPE,
    v_policy_seq_id                                    IN CLM_ENROLL_DETAILS.Policy_Seq_Id%TYPE,
    v_enrol_type_id                                    IN CLM_ENROLL_DETAILS.enrol_type_id%TYPE,
    v_tpa_enrollment_id                                IN CLM_ENROLL_DETAILS.tpa_enrollment_id%TYPE,
    v_group_reg_seq_id                                 IN CLM_ENROLL_DETAILS.group_reg_seq_id%TYPE,
    v_employee_no                                      IN CLM_ENROLL_DETAILS.employee_no%TYPE,
    v_hosp_seq_id                                      IN CLM_HOSPITAL_ASSOCIATION.Hosp_Seq_Id%TYPE,
    v_effective_from_date                              IN CLM_ENROLL_DETAILS.Policy_Effective_From%TYPE,
    v_effective_to_date                                IN CLM_ENROLL_DETAILS.policy_effective_to%TYPE ,
    v_date_of_admission                                IN CLM_GENERAL_DETAILS.date_of_admission%TYPE,
    v_requested_amount                                 IN CLM_GENERAL_DETAILS.requested_amount%TYPE,
    v_date_of_discharge                                IN CLM_GENERAL_DETAILS.Date_Of_Discharge%TYPE,
    v_rcvd_date                                        IN clm_inward.rcvd_date%TYPE,
    v_data_discrepancy_present_yn                      IN VARCHAR2,
    v_discrepancy_present_yn                           IN OUT VARCHAR2,
    v_added_by                                         IN NUMBER,
    v_member_seq_id                                    IN clm_enroll_details.member_seq_id%TYPE
  )
  IS

    CURSOR policy_cur IS SELECT a.product_seq_id, a.endorsement_seq_id,
       d.stop_claim_yn AS pol_stop_claim_yn, e.stop_claim_yn AS prod_stop_claim_yn
       FROM tpa_enr_policy A LEFT OUTER JOIN tpa_ins_prod_policy d ON (A.policy_seq_id = d.policy_seq_id)
       LEFT OUTER JOIN tpa_ins_prod_policy e ON (A.product_seq_id = e.product_seq_id)
       WHERE A.policy_seq_id = v_policy_seq_id ;

    policy_rec              policy_cur%ROWTYPE;

    CURSOR conflict_id_cur IS SELECT a.tpa_enrollment_id, c.hosp_seq_id, b.date_of_admission ,b.requested_amount
                             FROM clm_enroll_details A JOIN clm_general_details b ON ( a.claim_seq_id = b.claim_seq_id AND b.date_of_admission IS NOT NULL )
                             LEFT OUTER JOIN clm_hospital_association c ON ( b.claim_seq_id = c.claim_seq_id )
                            WHERE tpa_enrollment_id = v_tpa_enrollment_id
                            AND B.claim_seq_id != v_claim_seq_id
                            ORDER BY date_of_admission  DESC ;


    CURSOR conflict_employee_no_cur IS SELECT a.tpa_enrollment_id, c.hosp_seq_id, b.date_of_admission , b.requested_amount , a.employee_no
                             FROM clm_enroll_details A JOIN clm_general_details b ON ( a.claim_seq_id = b.claim_seq_id AND b.date_of_admission IS NOT NULL)
                             LEFT OUTER JOIN clm_hospital_association c ON ( b.claim_seq_id = c.claim_seq_id )
                            WHERE a.group_reg_seq_id = v_group_reg_seq_id AND a.employee_no = v_employee_no
                            AND b.claim_seq_id != v_claim_seq_id
                            ORDER BY b.date_of_admission DESC;


    CURSOR cor_hosp_cur IS SELECT COUNT(1) FROM tpa_hosp_info a JOIN tpa_ins_assoc_prod_hosp b ON (a.hosp_seq_id = b.hosp_seq_id )
      JOIN tpa_ins_prod_policy C ON (b.prod_policy_seq_id = c.prod_policy_seq_id AND b.status_general_type_id = 'EXL')
      WHERE  a.hosp_seq_id = v_hosp_seq_id  AND c.policy_seq_id = v_policy_seq_id;

    CURSOR other_hosp_cur IS SELECT COUNT(1) FROM tpa_hosp_info a JOIN tpa_ins_assoc_prod_hosp b ON (a.hosp_seq_id = b.hosp_seq_id)
      JOIN tpa_ins_prod_policy C ON (b.prod_policy_seq_id = c.prod_policy_seq_id AND b.status_general_type_id = 'EXL')
      WHERE  a.hosp_seq_id = v_hosp_seq_id  AND c.product_seq_id = policy_rec.product_seq_id ;

    CURSOR stop_hosp_cur IS SELECT  a.stop_claim_yn
      FROM tpa_hosp_info a WHERE a.hosp_seq_id = v_hosp_seq_id;


    v_ctr                              NUMBER(1);
    v_proximity                        NUMBER(2) := 15;
    v_close_proximity_duration         NUMBER(2);
    v_hosp_rec                         stop_hosp_cur%ROWTYPE;
    v_stop_hosp_claim_yn               VARCHAR2(1) := 'N';
    j                                  NUMBER(2) := 1;
    CURSOR prx_cur IS  SELECT close_proximity_duration
      FROM tpa_system_parameters WHERE system_param_seq_id = 1;

    TYPE discrepancy_type IS TABLE OF discrepancy_information.discrepancy_general_type_id%TYPE INDEX BY BINARY_INTEGER ;
    discrepancy_tab                 discrepancy_type;
-- YDD  --  Data Discrepancy
-- YPD  --  Possible Duplication
-- YCP  -- Close Proximity
-- NHX  -- The Selected Hospital is Excluded from this Policy / Product
-- YEN  -- Endorsement Review.
-- YBD  -- Previous policy has a Claim. Check current Bonus validity.
-- YCX  -- Claim Recieved After the Allowed Processing Period.
-- The Code Start N cannot be resolved.

    CURSOR bonus_grace_period_cur IS
      SELECT b.bonus,d.bonus_check_grace_period ,c.prev_policy_seq_id
       FROM tpa_enr_policy_member a JOIN tpa_enr_balance b ON (a.policy_group_seq_id = b.policy_group_seq_id)
       JOIN tpa_enr_policy c ON (b.policy_seq_id = c.policy_seq_id)
       CROSS JOIN tpa_system_parameters d
       WHERE a.member_seq_id = v_member_seq_id
      AND ( a.mem_general_type_id = 'PFL' AND b.member_seq_id IS NULL
              OR a.mem_general_type_id != 'PFL' AND b.member_seq_id = v_member_seq_id);

    bonus_grace_period_rec          bonus_grace_period_cur%ROWTYPE;

    CURSOR mem_bonus_cur (v_policy_seq_id NUMBER) IS SELECT  c.likely_date_of_hospitalization,b.policy_effective_to
        FROM tpa_enr_policy a JOIN pat_enroll_details b ON (a.policy_seq_id = b.policy_seq_id AND b.pat_status_general_type_id NOT IN ('REJ','PCN'))
        JOIN pat_general_details c ON (b.pat_enroll_detail_seq_id = c.pat_enroll_detail_seq_id AND c.pat_enhanced_yn = 'N')
        WHERE a.policy_seq_id = v_policy_seq_id AND c.likely_date_of_hospitalization IS NOT NULL
      UNION ALL
        SELECT  c.date_of_admission,b.policy_effective_to
        FROM tpa_enr_policy a JOIN clm_enroll_details b ON (a.policy_seq_id = b.policy_seq_id AND b.clm_status_general_type_id NOT IN ('REJ','PCO'))
        JOIN clm_general_details c ON (b.claim_seq_id = c.claim_seq_id)
        WHERE a.policy_seq_id = v_policy_seq_id AND c.date_of_admission IS NOT NULL
        ORDER BY 2 DESC ;

    mem_bonus_rec                   mem_bonus_cur%ROWTYPE;

  BEGIN
    DELETE FROM discrepancy_information  WHERE claim_seq_id = v_claim_seq_id;

    OPEN policy_cur;
    FETCH policy_cur INTO policy_rec;
    CLOSE policy_cur;

    OPEN bonus_grace_period_cur;
    FETCH bonus_grace_period_cur INTO bonus_grace_period_rec;
    CLOSE bonus_grace_period_cur;

    IF bonus_grace_period_rec.bonus > 0 AND bonus_grace_period_rec.bonus_check_grace_period > 0
      AND bonus_grace_period_rec.prev_policy_seq_id IS NOT NULL THEN
      OPEN  mem_bonus_cur ( bonus_grace_period_rec.prev_policy_seq_id );
      FETCH mem_bonus_cur INTO mem_bonus_rec;
      CLOSE mem_bonus_cur;

      IF ( mem_bonus_rec.likely_date_of_hospitalization BETWEEN mem_bonus_rec.policy_effective_to - bonus_grace_period_rec.bonus_check_grace_period AND mem_bonus_rec.policy_effective_to) THEN
        discrepancy_tab(j) := 'YBD';
        j := j + 1;
      END IF;
    END IF;

    IF v_enrol_type_id = 'COR' THEN
      OPEN cor_hosp_cur ;
      FETCH cor_hosp_cur INTO v_ctr ;
      CLOSE cor_hosp_cur;
    END IF;

    IF nvl(v_ctr,0) = 0 THEN
      OPEN other_hosp_cur ;
      FETCH other_hosp_cur INTO v_ctr ;
      CLOSE other_hosp_cur;
    END IF;

    IF  v_ctr > 0 THEN
      discrepancy_tab(j) := 'NHX';
      j := j + 1;
    END IF;

    OPEN stop_hosp_cur;
    FETCH stop_hosp_cur INTO v_hosp_rec;
    CLOSE stop_hosp_cur;

    IF v_hosp_rec.stop_claim_yn = 'Y' THEN
      discrepancy_tab(j) := 'NHC';
      j := j + 1;
    END IF;

    IF policy_rec.pol_stop_claim_yn  = 'Y' THEN
      discrepancy_tab(j) := 'NLC';
      j := j + 1;
    END IF;

    IF policy_rec.prod_stop_claim_yn = 'Y' THEN
      discrepancy_tab(j) := 'NPC';
      j := j + 1;
    END IF;

    IF v_tpa_enrollment_id IS NOT NULL THEN
      FOR i IN conflict_id_cur
      LOOP
        IF (i.hosp_seq_id = v_hosp_seq_id AND v_date_of_admission - i.date_of_admission <= v_proximity )
          OR (i.hosp_seq_id != v_hosp_seq_id AND v_date_of_admission - i.date_of_admission <= v_proximity ) THEN
             discrepancy_tab(j) := 'YPD';
             j := j + 1;
          EXIT;
        END IF;
      END LOOP;
    ELSE
      FOR i IN conflict_employee_no_cur
      LOOP
        IF (i.hosp_seq_id = v_hosp_seq_id AND v_date_of_admission - i.date_of_admission <= v_proximity )
          OR (i.hosp_seq_id != v_hosp_seq_id AND v_date_of_admission - i.date_of_admission <= v_proximity ) THEN
          discrepancy_tab(j) := 'YPD';
          j := j + 1;
          EXIT;
        END IF;
      END LOOP;
    END IF;

    OPEN prx_cur;
    FETCH prx_cur INTO v_close_proximity_duration ;
    CLOSE prx_cur ;

    IF ( v_date_of_admission - v_effective_from_date ) <= v_close_proximity_duration THEN
      discrepancy_tab(j) := 'YCP';
      j := j + 1;
    END IF;

    IF v_data_discrepancy_present_yn = 'Y' THEN
      discrepancy_tab(j) := 'YDD';
      j := j + 1;
    END IF;

/*    OPEN policy_endorse_cur ;
    FETCH policy_endorse_cur INTO v_endorsement_seq_id ;
    CLOSE policy_endorse_cur ;*/

    IF policy_rec.endorsement_seq_id  IS NOT NULL THEN
      discrepancy_tab(j) := 'YEN';
      j := j + 1;
    END IF;

    IF v_date_of_discharge < v_rcvd_date - ttk_util_pkg.get_tpa_parameter('clm_process_allowed_days')  THEN
      discrepancy_tab(j) := 'YCX';
      j := j + 1;
    END IF;

    IF j > 1 THEN
      FOR I IN discrepancy_tab.FIRST .. discrepancy_tab.LAST
      LOOP
         INSERT INTO discrepancy_information ( discrepancy_seq_id , claim_seq_id , discrepancy_general_type_id ,
             resolved_yn , added_by ,added_date )
         VALUES ( discrepancy_information_seq.NEXTVAL , v_claim_seq_id , discrepancy_tab(i),
               'N', v_added_by, SYSDATE);
      END LOOP;
    END IF;

    IF discrepancy_tab.COUNT > 0 THEN
      v_discrepancy_present_yn := 'Y';
    ELSE
      DELETE FROM discrepancy_information WHERE claim_seq_id = v_claim_seq_id ;
      v_discrepancy_present_yn := 'N';
    END IF;
  END check_conflict;
--============================================================================================================
  PROCEDURE select_assign_to(
    v_assign_users_seq_id         IN ASSIGN_USERS.assign_users_seq_id%TYPE,
    v_added_by                    IN NUMBER,
    result_set                    OUT SYS_REFCURSOR
  )
  IS
  BEGIN
   OPEN result_set FOR
     SELECT
       a.assign_users_seq_id ,
       A.assigned_to_user ,
       A.tpa_office_seq_id ,
       A.remarks,
       B.claim_seq_id,
       b.claim_number ,
       C.policy_seq_id
       FROM assign_users A JOIN clm_general_details B ON ( A.claim_seq_id = B.claim_seq_id )
       JOIN clm_enroll_details C ON ( B.claim_seq_id = C.claim_seq_id )
       WHERE A.assign_users_seq_id = v_assign_users_seq_id ;
  END select_assign_to;
--============================================================================================================
  PROCEDURE check_clm_approved(
    v_claim_seq_id                        IN clm_general_details.claim_seq_id%TYPE
  )
  IS

     CURSOR clm_cur IS SELECT A.clm_status_general_type_id , B.completed_yn , c.resolved_yn , d.shortfall_ctr , f.invest_ctr ,f.inv_duration,--Added for koc_investigation
        g.policy_status_general_type_id , h.status_general_type_id ,
        nvl(h.date_of_inception, a.date_of_inception) AS date_of_inception,
        nvl(h.date_of_exit,a.date_of_exit) AS date_of_exit, k.rcvd_date ,
        nvl(g.effective_from_date,a.policy_effective_from) AS  policy_effective_from,
        nvl(g.effective_to_date, a.policy_effective_to) AS policy_effective_to,
        b.date_of_admission, h.member_seq_id , a.modification_mode_value,
        a.enrol_type_id , i.ailment_details_seq_id, h.stop_pat_clm_process_yn AS mem_stop_pat_clm_process_yn , h.recieved_after AS mem_recieved_after,
        j.stop_pat_clm_process_yn AS group_stop_pat_clm_process_yn, j.recieved_after AS group_recieved_after,
        I.MAT_GENERAL_TYPE_ID,I.SPECIALTY_GENERAL_TYPE_ID,i.CHILD_DATE_OF_BIRTH --KOC 1164
        FROM clm_enroll_details A JOIN clm_general_details B ON ( A.claim_seq_id = B.claim_seq_id )
        LEFT OUTER JOIN discrepancy_information C ON ( b.claim_seq_id = c.claim_seq_id AND c.resolved_yn = 'N' )
        LEFT OUTER JOIN (SELECT COUNT(1) AS shortfall_ctr , claim_seq_id
                         FROM shortfall_details WHERE claim_seq_id = v_claim_seq_id
                         AND srtfll_status_general_type_id  != 'CLS'  AND  srtfll_status_general_type_id  != 'ORD'
                         GROUP BY claim_seq_id ) D ON (B.claim_seq_id = D.claim_seq_id )
        LEFT OUTER JOIN ( SELECT COUNT(1) AS invest_ctr , claim_seq_id,inv_duration --Added for koc_investigation
                          FROM investigation_details WHERE claim_seq_id =  v_claim_seq_id
                          AND invest_mandatory_yn = 'Y' AND ( invst_status_general_type_id IN ('FDL','ISN') OR invst_status_general_type_id IS NULL )
                          GROUP BY claim_seq_id,inv_duration ) F ON (B.claim_seq_id = F.claim_seq_id )
        LEFT OUTER JOIN tpa_enr_policy G ON (a.policy_seq_id = g.policy_seq_id )
        LEFT OUTER JOIN tpa_enr_policy_member H ON ( a.member_seq_id = h.member_seq_id )
        LEFT OUTER JOIN ailment_details I ON (b.claim_seq_id = i.claim_seq_id)
        LEFT OUTER JOIN tpa_enr_policy_group j ON (h.policy_group_seq_id = j.policy_group_seq_id)
        JOIN clm_inward k ON (B.claims_inward_seq_id = k.claims_inward_seq_id )
        WHERE B.claim_seq_id =  v_claim_seq_id ;

     clm_rec                              clm_cur%ROWTYPE;
     v_stop_yn                            CHAR(1) := 'N';
     v_ctr                                NUMBER(2);
   v_inv_time                           DATE; --Added for koc_investigation
     v_delay_auto_release                 VARCHAR2(5); --Added for koc_investigation

   CURSOR invest_cur IS SELECT a.delay_auto_release,a.inv_duration FROM investigation_details a
         WHERE a.claim_seq_id =  v_claim_seq_id;       --Added for koc_investigation

    CURSOR suspend_cur IS SELECT COUNT(1) FROM tpa_enr_mem_suspend_hist a
         WHERE a.member_seq_id = clm_rec.member_seq_id
         AND clm_rec.date_of_admission BETWEEN a.mem_suspend_from AND a.mem_suspend_to ;

 CURSOR VACCINATION_CUR IS  --KOC 1164
     SELECT COUNT(1) FROM CLM_BILL_HEADER A
                  JOIN CLM_BILL_DETAILS B
     ON (A.CLM_BILL_SEQ_ID=B.CLM_BILL_SEQ_ID AND B.WARD_TYPE_ID='VCE' AND B.ALLOWED_AMOUNT>0)
     WHERE A.CLAIM_SEQ_ID=v_claim_seq_id;
    V_VCE_COUNT  NUMBER(5):=0;

   CURSOR NEW_BORN_CUR IS  --KOC 1164
     SELECT COUNT(1) FROM CLM_BILL_HEADER A
                  JOIN CLM_BILL_DETAILS B
     ON (A.CLM_BILL_SEQ_ID=B.CLM_BILL_SEQ_ID AND B.WARD_TYPE_ID='BAB' AND B.ALLOWED_AMOUNT>0)
     WHERE A.CLAIM_SEQ_ID=v_claim_seq_id;
    V_NBB_COUNT  NUMBER(5):=0;
    v_NBB_VALUE NUMBER(3):=0;


  BEGIN
    OPEN clm_cur;
    FETCH clm_cur INTO clm_rec;
    CLOSE clm_cur;
--==================================Added for koc_investigation=================================================
   OPEN invest_cur;
    FETCH invest_cur INTO v_delay_auto_release,v_inv_time;
    CLOSE invest_cur;

    IF clm_rec.completed_yn = 'Y' THEN
      RAISE_APPLICATION_ERROR(-20107,' You cannot modify  this Pre-Auth , Reviews are Completed');
    ELSIF NVL(clm_rec.resolved_yn,'Y') = 'N' THEN
      raise_application_error(-20113,' Please Resolve Discrepancy ');
    ELSIF clm_rec.shortfall_ctr > 0 THEN
      raise_application_error(-20114,' Shortfall Exist');
    ELSIF clm_rec.ailment_details_seq_id IS NULL THEN
      raise_application_error(-20191,' Please enter Ailment information. ');
    ELSIF (clm_rec.invest_ctr > 0 OR v_delay_auto_release = 'Y')THEN --modified for koc_investigation
      raise_application_error(-20115,'Processing prevented / suspended by Investigation ');
    ELSIF /*clm_rec.policy_status_general_type_id = 'POC' OR*/ clm_rec.status_general_type_id = 'POC' AND clm_rec.enrol_type_id != 'COR' THEN
      raise_application_error( -20166,'Policy or Member is Cancelled, You cannot approve the Claim');
    ELSE
     --KOC 1164
      IF CLM_REC.SPECIALTY_GENERAL_TYPE_ID='MAS' THEN
         OPEN  VACCINATION_CUR;
         FETCH VACCINATION_CUR INTO V_VCE_COUNT;
         CLOSE VACCINATION_CUR;

         OPEN  NEW_BORN_CUR;
         FETCH NEW_BORN_CUR INTO V_NBB_COUNT;
         CLOSE NEW_BORN_CUR;

     if V_VCE_COUNT <1 AND V_NBB_COUNT>0 and clm_rec.MAT_GENERAL_TYPE_ID='NBB' then
         if (clm_rec.date_of_admission>clm_rec.policy_effective_to) OR  (clm_rec.date_of_admission>clm_rec.date_of_exit) then
           v_NBB_VALUE:=(clm_rec.CHILD_DATE_OF_BIRTH+89)-clm_rec.policy_effective_to;
         END IF;
     elsif  V_VCE_COUNT >0  AND V_NBB_COUNT<1 AND CLM_REC.MAT_GENERAL_TYPE_ID='NBB'  then
         if (clm_rec.date_of_admission>clm_rec.policy_effective_to) OR  (clm_rec.date_of_admission>clm_rec.date_of_exit) then
           v_NBB_VALUE:=(clm_rec.CHILD_DATE_OF_BIRTH+364)-clm_rec.policy_effective_to;
         END IF;
     end if;


       IF  V_VCE_COUNT <1 AND V_NBB_COUNT>0 and CLM_REC.MAT_GENERAL_TYPE_ID='NBB' AND
      ( ( clm_rec.date_of_admission < clm_rec.date_of_inception ) OR
      ( clm_rec.date_of_admission <  clm_rec.policy_effective_from ) OR
      ( clm_rec.date_of_admission >= clm_rec.date_of_exit +1+v_NBB_VALUE ) OR
      ( clm_rec.date_of_admission >= clm_rec.policy_effective_to +1+v_NBB_VALUE )) THEN

       raise_application_error ( -20173,'Date of Admission is beyond policy period. You cannot approve the claim' );
      ELSIF  V_VCE_COUNT >0  AND V_NBB_COUNT<1 AND CLM_REC.MAT_GENERAL_TYPE_ID='NBB' AND
      ( ( clm_rec.date_of_admission < clm_rec.date_of_inception ) OR
      ( clm_rec.date_of_admission <  clm_rec.policy_effective_from ) OR
      ( clm_rec.date_of_admission >= clm_rec.date_of_exit +1+v_NBB_VALUE ) OR
      ( clm_rec.date_of_admission >= clm_rec.policy_effective_to +1+v_NBB_VALUE )) THEN

       raise_application_error ( -20173,'Date of Admission is beyond policy period. You cannot approve the claim' );
     ELSIF   CLM_REC.MAT_GENERAL_TYPE_ID!='NBB' AND ( ( clm_rec.date_of_admission < clm_rec.date_of_inception ) OR
      ( clm_rec.date_of_admission <  clm_rec.policy_effective_from ) OR
      ( clm_rec.date_of_admission >= clm_rec.date_of_exit +1 ) OR
      ( clm_rec.date_of_admission >= clm_rec.policy_effective_to +1 )) THEN
        raise_application_error ( -20173,'Date of Admission is beyond policy period. You cannot approve the claim' );
       END IF;
--KOC 1164
      ELSE
        IF  ( ( clm_rec.date_of_admission < clm_rec.date_of_inception ) OR
      ( clm_rec.date_of_admission <  clm_rec.policy_effective_from ) OR
      ( clm_rec.date_of_admission >= clm_rec.date_of_exit +1 ) OR
      ( clm_rec.date_of_admission >= clm_rec.policy_effective_to +1 )) THEN
        raise_application_error ( -20173,'Date of Admission is beyond policy period. You cannot approve the claim' );
    END IF;
  END IF;
 END IF;
    /*IF clm_rec.modification_mode_value > 0 THEN
      v_ctr := NULL;
      policy_enrollment_pkg.check_enrollment_change ( clm_rec.modification_mode_value,v_ctr );
    END IF;*/

    IF clm_rec.mem_stop_pat_clm_process_yn = 'Y' OR clm_rec.group_stop_pat_clm_process_yn = 'Y' THEN
      IF clm_rec.mem_recieved_after IS NULL AND clm_rec.group_recieved_after IS NULL THEN
        v_stop_yn := 'Y';
      END IF;
      IF clm_rec.enrol_type_id = 'COR' THEN
        IF clm_rec.status_general_type_id = 'POC' AND ( clm_rec.rcvd_date > NVL(clm_rec.mem_recieved_after,clm_rec.group_recieved_after )) THEN
          v_stop_yn := 'Y';
        END IF;
      ELSIF clm_rec.rcvd_date > NVL(clm_rec.mem_recieved_after,clm_rec.group_recieved_after ) THEN
        v_stop_yn := 'Y';
      END IF;
      IF v_stop_yn = 'Y' THEN
        raise_application_error(-20138,'Preauth/Claim processing is prevented.');
      END IF;
    END IF;

    IF clm_rec.policy_status_general_type_id IN ('PEX','PSU') THEN
      OPEN suspend_cur;
      FETCH suspend_cur INTO v_ctr;
      CLOSE suspend_cur;
      IF v_ctr > 0  THEN
        raise_application_error( -20139,'Member is suspended. ');
      END IF;
    END IF;
  END check_clm_approved;
--============================================================================================================
  --==============================================================================================
--  TO LOAD THE CACHE IN THE ASSIGN USER SCREEN. THOSE PAT USERS WHO HAVE THE RIGHT TO PROCESS THE PRE-AUTH
--  WITHIN THE POLICY GROUP OR PRODUCT GROUP
  PROCEDURE manual_assign_preauth (
    v_claim_seq_id                         IN  ASSIGN_USERS.claim_seq_id%TYPE,
    v_policy_seq_id                        IN  pat_enroll_details.policy_seq_id%TYPE,
    v_tpa_office_seq_id                    IN  pat_enroll_details.tpa_office_seq_id%TYPE,
    v_result_set                           OUT SYS_REFCURSOR
  )
  IS

    CURSOR clm_gen_cur IS                                    -- GETTING PAT INFORMATIONS
     SELECT  A.requested_amount ,  A.event_seq_id , C.product_seq_id , b.enrol_type_id , d.event_owner , e.assigned_to_user
      FROM clm_general_details A JOIN clm_enroll_details B ON (a.claim_seq_id = b.claim_seq_id)
      LEFT OUTER JOIN tpa_enr_policy C ON ( b.policy_seq_id = c.policy_seq_id )
      JOIN tpa_event d ON (a.event_seq_id = d.event_seq_id)
      LEFT OUTER JOIN assign_users e ON (a.last_assign_user_seq_id = e.assign_users_seq_id)
       WHERE A.claim_seq_id = v_claim_seq_id;

    clm_rec                               clm_gen_cur%ROWTYPE;

    CURSOR cor_cur IS
     SELECT a.contact_seq_id FROM user_assoc_temp A          -- POLICY GROUP
        WHERE policy_seq_id = v_policy_seq_id  AND tpa_office_seq_id = v_tpa_office_seq_id ;

    CURSOR ind_cur IS
     SELECT A.Contact_Seq_Id FROM user_assoc_temp A          -- PRODUCT GROUPS
         WHERE a.product_seq_id = clm_rec.product_seq_id AND a.tpa_office_seq_id = v_tpa_office_seq_id ;
    user_rec                              cor_cur%ROWTYPE;

  BEGIN

    OPEN clm_gen_cur;
    FETCH clm_gen_cur INTO clm_rec;
    CLOSE clm_gen_cur;

    IF clm_rec.event_owner != 'C' THEN
    --claims_freeze(v_claim_seq_id,NULL,'S'); --KOCBJJ

      --STORING THE DETAILS OF ALL THE MEMBERS TO THE TEMPORARY TABLE
      DELETE FROM user_assign_manual_temp;

      INSERT INTO user_assign_manual_temp SELECT
         a.prod_policy_seq_id,
         a.policy_seq_id,
         h.tpa_office_seq_id,
         a.product_seq_id,
         b.default_group_yn ,
         d.contact_seq_id,
         h.contact_name ,
         d.group_user_seq_id,
         e.user_role_seq_id,
         e.role_seq_id,
         f.event_role_seq_id,
         f.event_seq_id ,
         h.employee_number
         FROM tpa_ins_prod_policy A RIGHT OUTER JOIN tpa_groups B ON (A.prod_policy_seq_id = B.prod_policy_seq_id )
         JOIN tpa_group_branch C ON ( B.group_seq_id = C.group_seq_id )
         JOIN tpa_group_user_assoc D ON ( c.group_branch_seq_id = d.group_branch_seq_id )
         JOIN tpa_user_roles E ON ( d.contact_seq_id = e.contact_seq_id )
         JOIN tpa_event_role_assoc F ON ( e.role_seq_id = f.role_seq_id )
         JOIN tpa_office_info  G ON ( c.tpa_office_seq_id = g.tpa_office_seq_id AND g.claim_allowed_yn = 'Y'
                                          AND g.claim_limit >= clm_rec.requested_amount AND G.active_yn = 'Y')
         JOIN tpa_user_contacts H ON (d.contact_seq_id = H.contact_seq_id AND h.user_general_type_id = 'TTK'
                                       AND h.contact_claim_limit >= clm_rec.requested_amount AND h.active_yn = 'Y' AND h.dept_general_type_id = 'CLM')
         JOIN tpa_event I ON (F.event_seq_id = I.event_seq_id AND i.event_seq_id = clm_rec.event_seq_id )
         JOIN tpa_workflow J ON (I.workflow_seq_id = J.workflow_seq_id AND J.sub_general_type_id = 'CLM')
         WHERE ( a.product_seq_id = clm_rec.product_seq_id OR a.policy_seq_id = v_policy_seq_id OR B.prod_policy_seq_id IS NULL );

      -- STORING THE ASSIGNMENT DETAILS ( count of current assignments ) OF ALL USERS TO TEMPORARY TABLE

      IF clm_rec.enrol_type_id = 'COR' THEN   -- IN THE CASE OF CORPORATE POLICIES ONLY

        IF v_policy_seq_id IS NOT NULL THEN
          OPEN cor_cur ;
          FETCH cor_cur INTO user_rec ;       -- Getting Users in The Specific Policy Group in the current Branch
          CLOSE cor_cur ;

          IF user_rec.contact_seq_id IS NOT NULL THEN
             OPEN v_result_set FOR SELECT DISTINCT A.contact_seq_id , a.contact_name FROM user_assign_manual_temp A          -- POLICY GROUP
              WHERE a.policy_seq_id = v_policy_seq_id  AND a.tpa_office_seq_id = v_tpa_office_seq_id ORDER BY a.contact_name;
          END IF;
        END IF;
      END IF;

      IF user_rec.contact_seq_id IS NULL THEN
        OPEN ind_cur ;
        FETCH ind_cur INTO user_rec ;   -- Getting Users in The Specific Product Groups
        CLOSE ind_cur ;

        IF user_rec.contact_seq_id IS NOT NULL THEN
          OPEN v_result_set FOR SELECT DISTINCT A.contact_seq_id , a.contact_name FROM user_assign_manual_temp A          -- POLICY GROUP
            WHERE a.product_seq_id = clm_rec.product_seq_id  AND tpa_office_seq_id = v_tpa_office_seq_id ORDER BY a.contact_name;
        ELSE  --getting users in default groups
          OPEN v_result_set FOR SELECT DISTINCT A.contact_seq_id , a.contact_name FROM user_assign_manual_temp A          -- POLICY GROUP
            WHERE prod_policy_seq_id IS NULL AND tpa_office_seq_id = v_tpa_office_seq_id ORDER BY a.contact_name;
        END IF;
      END IF;
    ELSE
      OPEN v_result_set FOR
        SELECT A.contact_seq_id , a.contact_name
        FROM tpa_user_contacts a JOIN tpa_user_roles b ON (a.contact_seq_id = b.contact_seq_id)
        JOIN tpa_event_role_assoc c ON ( b.role_seq_id = c.role_seq_id )
        WHERE a.tpa_office_seq_id = v_tpa_office_seq_id
        AND c.event_seq_id = clm_rec.event_seq_id AND a.user_general_type_id = 'TTK'
        AND a.active_yn = 'Y' AND a.contact_seq_id != clm_rec.assigned_to_user;
    END IF;
  END manual_assign_preauth;
--============================================================================================================
   PROCEDURE delete_clm_general (
    v_delete_flag                        IN  VARCHAR2,
    v_seq_ids                            IN  VARCHAR2,
    v_clm_enroll_detail_seq_id           IN  clm_enroll_details.clm_enroll_detail_seq_id%TYPE,  -- MANDATORY
    v_claim_seq_id                       IN  clm_general_details.claim_seq_id%TYPE,    -- MANDATORY
    v_added_by                           IN  NUMBER,
    v_rows_processed                     IN  OUT NUMBER
  )
  IS
    v_ctr                      NUMBER(3);
    sys_cur                    SYS_REFCURSOR ;
    str_tab                    ttk_util_pkg.str_table_type;
    v_complete_ctr             NUMBER(3):=0;
    v_buff_ctr                 NUMBER (3):=0;
    v_inv_count                NUMBER(10); --Investigation Delete

    CURSOR inw_claim_cur (v_claims_inward_seq_id NUMBER) IS
      SELECT a.document_general_type_id, a.inward_status_general_type_id , a.shortfall_id , b.claim_seq_id , b.completed_yn , b.parent_claim_seq_id,a.claim_number
        FROM clm_inward a LEFT OUTER JOIN clm_general_details b ON (a.claims_inward_seq_id = b.claims_inward_seq_id)
       WHERE a.claims_inward_seq_id = v_claims_inward_seq_id;
    inw_claim_rec               inw_claim_cur%ROWTYPE;

    CURSOR buffer_cur IS SELECT a.last_buffer_detail_seq_id, b.buffer_hdr_seq_id
      FROM clm_general_details a JOIN buffer_details b ON (a.last_buffer_detail_seq_id = b.buff_detail_seq_id)
       WHERE a.claim_seq_id = v_claim_seq_id;

    cursor clm_audit_cur(v_claims_inward_seq_id number) is   --koc1260
         select e.claims_inward_no,j.policy_number,a.tpa_enrollment_id,d.claim_number,f.description claim_status,e.rcvd_date,e.added_date,
         i.event_description,e.shortfall_id,e.claim_number srtfll_claim_number,h.description inward_status,
         g.description claim_type,d.date_of_admission,nvl(k.hosp_name,l.hosp_name) as hosp_name,nvl(k.empanel_number,l.empanel_number) as empanel_number,
         d.requested_amount
         from clm_inward e
         left outer join clm_general_details d on ( d.claims_inward_seq_id=e.claims_inward_seq_id)
         left outer join  clm_enroll_details c on (c.claim_seq_id=d.claim_seq_id)
         left outer join clm_hospital_association k on (d.claim_seq_id=k.claim_seq_id)
         left outer join tpa_enr_policy_member a on (c.member_seq_id=a.member_seq_id)
         left outer join tpa_enr_policy_group b on (a.policy_group_seq_id=b.policy_group_seq_id)
         left outer join tpa_enr_policy j on (b.policy_seq_id=j.policy_seq_id)
         left outer join tpa_general_code h on (e.inward_status_general_type_id=h.general_type_id)
         left outer join tpa_event i      on (d.event_seq_id=i.event_seq_id)
         left outer join tpa_general_code f on (c.clm_status_general_type_id=f.general_type_id)
         left outer join tpa_general_code g on (e.document_general_type_id=g.general_type_id)
         left outer join tpa_hosp_info l on (k.hosp_seq_id=l.hosp_seq_id)
           where  (e.claims_inward_seq_id = v_claims_inward_seq_id);



    clm_audit_rec                clm_audit_cur%rowtype;  --KOC1260

    buffer_rec                         buffer_cur%ROWTYPE;
    v_update_last_buff_seq_id_yn       VARCHAR2(1):= 'N';
    v_clm_seq_id                       clm_general_details.claim_seq_id%TYPE;
    v_clm_completed_yn                 clm_general_details.completed_yn%TYPE;
    v_user_id                          tpa_login_info.user_id%type;  --KOC1260


  BEGIN
   
    claims_freeze(v_claim_seq_id,NULL,'S'); --KOCBJJ
    str_tab      := ttk_util_pkg.parse_str ( v_seq_ids );
    IF v_delete_flag = 'AIL' THEN

      FORALL  i IN str_tab.FIRST .. str_tab.LAST
        DELETE FROM pat_package_procedures WHERE icd_pcs_seq_id   = str_tab(i);
      FORALL  i IN str_tab.FIRST .. str_tab.LAST
        DELETE FROM icd_pcs_detail WHERE icd_pcs_seq_id   = str_tab(i);
      pre_auth_pkg.reassign_user (  NULL , v_claim_seq_id , NULL , v_added_by , 'AUT');
      pre_auth_pkg.check_clm_completed (v_claim_seq_id ,NULL,'REC',v_added_by);
    ELSIF v_delete_flag = 'SFL' THEN
      pre_auth_pkg.reassign_user (  NULL , v_claim_seq_id , NULL , v_added_by , 'AUT');

      pre_auth_pkg.check_clm_completed (v_claim_seq_id ,NULL,'APP',v_added_by);

      FORALL i IN str_tab.FIRST .. str_tab.LAST
        DELETE FROM shortfall_details a WHERE a.shortfall_seq_id = str_tab(i)
          AND A.srtfll_status_general_type_id ='OPN' AND a.srtfll_sent_date IS NULL;

      IF str_tab.COUNT != SQL%ROWCOUNT THEN
        raise_application_error(-20121,'You cannot delete sent/completed Shortfalls');
      END IF;

    ELSIF v_delete_flag = 'INV' THEN
      pre_auth_pkg.reassign_user (  NULL , v_claim_seq_id , NULL , v_added_by , 'AUT');
      pre_auth_pkg.check_clm_completed (v_claim_seq_id ,NULL,'APP',v_added_by);

      FORALL i IN str_tab.FIRST .. str_tab.LAST
        DELETE FROM investigation_details WHERE invest_seq_id = str_tab(i);


    ELSIF v_delete_flag = 'PED' THEN
      pre_auth_pkg.reassign_user (  NULL , v_claim_seq_id , NULL , v_added_by , 'AUT');
      pre_auth_pkg.check_clm_completed (v_claim_seq_id ,NULL,'REC',v_added_by);

      FOR i IN str_tab.FIRST .. str_tab.COUNT /2
      LOOP
        IF str_tab(i*2) = 'N' THEN
          RAISE_APPLICATION_ERROR(-20102,' You cannot Delete , The Prvious Diceases ');
        END IF;
        DELETE FROM claimant_ped
          WHERE claimant_ped_seq_id  = str_tab(i*2-1) ;
      END LOOP;


    ELSIF v_delete_flag = 'BUFFER' THEN
      pre_auth_pkg.reassign_user (  NULL , v_claim_seq_id , NULL , v_added_by , 'AUT');
      pre_auth_pkg.check_clm_completed (v_claim_seq_id ,NULL,'APP',v_added_by);

      OPEN buffer_cur;
      FETCH buffer_cur INTO buffer_rec;
      CLOSE buffer_cur;

      FOR i IN str_tab.FIRST .. str_tab.LAST
      LOOP
        DELETE FROM buffer_details WHERE buff_detail_seq_id    = str_tab(i) AND buffer_status_general_type_id IS NULL;
        IF buffer_rec.last_buffer_detail_seq_id = str_tab(i) THEN
          v_update_last_buff_seq_id_yn := 'Y';
        END IF;
      END LOOP;

      IF str_tab.COUNT != SQL%ROWCOUNT THEN
        raise_application_error(-20111,'Buffer is request is already sent');
      END IF;

      SELECT COUNT(1) INTO v_ctr
        FROM buffer_details a WHERE a.buffer_hdr_seq_id = buffer_rec.buffer_hdr_seq_id;

      IF v_ctr = 0 THEN
        DELETE FROM buffer_header a WHERE a.buffer_hdr_seq_id =  buffer_rec.buffer_hdr_seq_id;
        UPDATE clm_general_details A SET
          A.last_buffer_detail_seq_id = NULL
          WHERE a.claim_seq_id = v_claim_seq_id;
      ELSIF v_update_last_buff_seq_id_yn = 'Y' THEN
        UPDATE clm_general_details A SET
          A.last_buffer_detail_seq_id = (SELECT bb.buff_detail_seq_id FROM
                    (SELECT b.buff_detail_seq_id FROM buffer_details b
                       WHERE b.claim_seq_id = v_claim_seq_id
                       ORDER BY nvl(b.buffer_approved_date,b.buffer_req_date) DESC) bb WHERE rownum = 1 )
          WHERE a.claim_seq_id = v_claim_seq_id;
      END IF;

    ELSIF v_delete_flag = 'INWARD' THEN

      FOR i IN str_tab.FIRST .. str_tab.LAST
      LOOP
        OPEN inw_claim_cur (str_tab(i));
        FETCH inw_claim_cur INTO inw_claim_rec;
        CLOSE inw_claim_cur;

        open  clm_audit_cur(str_tab(i));  --KOC1260
        fetch clm_audit_cur into clm_audit_rec;
        close clm_audit_cur;

        IF inw_claim_rec.document_general_type_id != 'DTS'  THEN
          --locking CLAIM
          TTK_UTIL_PKG.reset_id_flag(inw_claim_rec.claim_seq_id||'-CLM','Y');
          
           select count(*) into v_inv_count
          from investigation_details s where s.claim_seq_id = inw_claim_rec.claim_seq_id;
          IF v_inv_count > 0 THEN 
             RAISE_APPLICATION_ERROR (-20510,'Investigation Details Are exists');
           END IF; 


          DELETE FROM clm_documents_rcvd WHERE CLAIM_SEQ_ID = inw_claim_rec.claim_seq_id;
          delete_claims( inw_claim_rec.claim_seq_id,v_added_by  );
          DELETE FROM clm_documents_rcvd WHERE claims_inward_seq_id  = TO_NUMBER(str_tab(i));
          p_clm_inw_del_log(TO_NUMBER(str_tab(i))); -- for dms
          DELETE FROM clm_inward a WHERE a.claims_inward_seq_id = TO_NUMBER(str_tab(i));
        ELSE

          SELECT A.claim_seq_id,A.completed_yn INTO v_clm_seq_id,v_clm_completed_yn FROM clm_general_details A WHERE A.CLAIM_NUMBER=inw_claim_rec.claim_number;
          --pre_auth_pkg.reassign_user (  NULL , v_clm_seq_id , NULL , v_added_by , 'AUT');
          --pre_auth_pkg.check_clm_completed (v_clm_seq_id ,NULL,'APP',v_added_by);
          IF inw_claim_rec.inward_status_general_type_id = 'IWC' THEN
             RAISE_APPLICATION_ERROR (-20154,'Inward Entry is Completed');
          ELSE

            --IF v_clm_completed_yn = 'Y' THEN
               p_clm_inw_del_log(TO_NUMBER(str_tab(i))); -- for dms
               DELETE FROM clm_inward a WHERE a.claims_inward_seq_id = TO_NUMBER(str_tab(i));
            /*ELSE
               UPDATE shortfall_details a SET
               a.srtfll_received_date          = NULL ,
               a.srtfll_status_general_type_id = 'OPN',
               a.updated_by                    = v_added_by,
               a.updated_date                  = SYSDATE
               WHERE a.shortfall_id  = inw_claim_rec.shortfall_id;*/
            --END IF;
          END IF;
        END IF;

     select user_id into v_user_id from tpa_login_info a  --KOC1260
     where a.contact_seq_id=v_added_by;

            insert into clm_audit_log(audit_seq_id,claim_number,tpa_enrollment_id,claim_type,remarks)  --KOC1260
           values(app.clm_audit_seq.nextval,nvl(clm_audit_rec.claim_number,clm_audit_rec.srtfll_claim_number),clm_audit_rec.tpa_enrollment_id,
           clm_audit_rec.claim_type,
           'Claim_Received_Date: '||clm_audit_rec.rcvd_date||
           ' | Claim_Status: '||clm_audit_rec.claim_status||
           ' | Claim_inward_date: '||clm_audit_rec.added_date||
           ' | Inward_No: '||clm_audit_rec.claims_inward_no||
           ' | Date of Admission: '||clm_audit_rec.date_of_admission||
           ' | Hospital Name: '||clm_audit_rec.hosp_name||
           ' | Empanel Number: '||clm_audit_rec.empanel_number||
           ' | Requested Amount: '||clm_audit_rec.requested_amount||
           ' | Policy_Number: '||clm_audit_rec.policy_number||
           ' | Shortfal_Id: '||clm_audit_rec.shortfall_id||
           ' | Inward_Entry_Status: '||clm_audit_rec.inward_status||
           ' | Event_Status: '||clm_audit_rec.event_description||
           ' | Deleted_By: '||v_user_id||
           ' | Deleted_Date: '||sysdate);

      END LOOP;

    ELSIF v_delete_flag = 'CLAIMS' THEN
    
      OPEN sys_cur FOR 'SELECT COUNT(1) FROM clm_general_details a JOIN tpa_event b ON (a.event_seq_id = b.event_seq_id)
       WHERE a.claim_seq_id IN ('||REPLACE(substr(v_seq_ids,2,length(v_seq_ids)-2),'|',',')||')
         AND b.order_number = 1';
      FETCH sys_cur INTO v_ctr;
      CLOSE sys_cur;      
  
     IF v_ctr != str_tab.COUNT  THEN
        raise_application_error( -20155,' You Cannot Delete Completed Claims ');
      END IF;
 

      FORALL i IN str_tab.FIRST .. str_tab.LAST
        DELETE FROM clm_bill_details WHERE clm_bill_seq_id IN ( SELECT clm_bill_seq_id
                                                                FROM clm_bill_header
                                                                WHERE claim_seq_id = str_tab(i));
      FORALL i IN str_tab.FIRST .. str_tab.LAST
        DELETE FROM clm_bill_header WHERE claim_seq_id = str_tab(i);

      FORALL i IN str_tab.FIRST .. str_tab.LAST
        DELETE FROM clm_hospital_additional_dtl WHERE clm_hosp_assoc_seq_id IN
                               ( SELECT clm_hosp_assoc_seq_id
                                   FROM clm_hospital_association WHERE  claim_seq_id = str_tab(i));

      FORALL i IN str_tab.FIRST .. str_tab.LAST
        DELETE FROM clm_hospital_association WHERE claim_seq_id = str_tab(i);

      FORALL i IN str_tab.FIRST .. str_tab.LAST
        DELETE FROM discrepancy_information WHERE claim_seq_id  = str_tab(i);

      FORALL i IN str_tab.FIRST .. str_tab.LAST
        DELETE FROM ailment_details WHERE claim_seq_id = str_tab(i);

      FORALL i IN str_tab.FIRST .. str_tab.LAST
        DELETE FROM ailment_details WHERE claim_seq_id = str_tab(i);

      FORALL i IN str_tab.FIRST .. str_tab.LAST
        DELETE FROM associated_illness WHERE claim_seq_id  = str_tab(i);

      FORALL i IN str_tab.FIRST .. str_tab.LAST
        DELETE FROM icd_pcs_detail WHERE claim_seq_id  = str_tab(i);

      FORALL i IN str_tab.FIRST .. str_tab.LAST
        DELETE FROM tpa_diagnosys_details d WHERE d.claim_seq_id = str_tab(i);--koc decoupling
		
      FORALL i IN str_tab.FIRST .. str_tab.LAST
        DELETE FROM clm_enroll_details WHERE claim_seq_id  = str_tab(i);

      FORALL i IN str_tab.FIRST .. str_tab.LAST
        DELETE FROM clm_general_details WHERE claim_seq_id  = str_tab(i);

      FORALL i IN str_tab.FIRST .. str_tab.LAST
      UPDATE tpa_call_claim_intimation b SET --to override the old intimation
              b.claim_seq_id    = NULL
        WHERE b.claim_seq_id    = str_tab(i); --ravi
      --unassoc_claim_intimation( str_tab(i),null,1,v_added_by,v_rows_processed);  --KOC1349

    ELSIF v_delete_flag = 'BILL' THEN
      pre_auth_pkg.reassign_user (  NULL , v_claim_seq_id , NULL , v_added_by , 'AUT');
      pre_auth_pkg.check_clm_completed (v_claim_seq_id ,NULL,'REC',v_added_by);


      FORALL i IN str_tab.FIRST .. str_tab.LAST
        DELETE FROM clm_bill_details A WHERE a.clm_bill_seq_id = str_tab(i);
      FORALL i IN str_tab.FIRST .. str_tab.LAST
        DELETE FROM clm_bill_header A WHERE a.clm_bill_seq_id = str_tab(i);

      IF SQL%ROWCOUNT != STR_TAB.COUNT THEN
        raise_application_error(-20156,'These Bills Cannot be deleted ');
      END IF;

    ELSIF v_delete_flag = 'LINEITEM' THEN
      pre_auth_pkg.reassign_user (  NULL , v_claim_seq_id , NULL , v_added_by , 'AUT');
      pre_auth_pkg.check_clm_completed (v_claim_seq_id ,NULL,'REC',v_added_by);


      FORALL i IN str_tab.FIRST .. str_tab.LAST
        DELETE FROM clm_bill_details WHERE clm_bill_dtl_seq_id   = str_tab(i);

      IF SQL%ROWCOUNT != STR_TAB.COUNT THEN
        raise_application_error(-20156,'These Bills Cannot be deleted ');
      END IF;

    ELSIF v_delete_flag = 'VOUCHER' THEN

      pre_auth_pkg.reassign_user (  NULL , v_claim_seq_id , NULL , v_added_by , 'AUT');

      DELETE FROM clm_discharge_voucher a
         WHERE A.disch_vouch_seq_id  = str_tab(1)
           AND ( a.dv_status_general_type_id NOT IN ('DVS','DVR') OR
                EXISTS ( SELECT 1 FROM clm_general_details b WHERE b.claim_seq_id = a.claim_seq_id
                                AND b.completed_yn = 'N'));

      IF SQL%ROWCOUNT = 0 THEN
        raise_application_error(-20134,'These Voucher Cannot be deleted ');
      END IF;
    END IF;
    v_rows_processed := SQL%ROWCOUNT;
    COMMIT;
  END delete_clm_general;
--============================================================================================================
  PROCEDURE create_claim_xml (
    v_claim_seq_id                          IN clm_general_details.claim_seq_id%TYPE,
    v_clm_enroll_detail_seq_id              IN clm_enroll_details.clm_enroll_detail_seq_id%TYPE,
    v_claim_history_doc                     OUT XMLTYPE
   )
   IS
     CURSOR pre_post_cur IS
       WITH bill_det AS ( SELECT b.bill_date, c.date_of_admission, c.date_of_discharge
         FROM clm_bill_header b JOIN clm_general_details c ON (b.claim_seq_id = c.claim_seq_id)
         WHERE b.claim_seq_id = v_claim_seq_id )
       SELECT (SELECT COUNT(1) FROM bill_det a WHERE trunc(a.bill_date) < trunc(a.date_of_admission)) AS pre_count,
              (SELECT COUNT(1) FROM bill_det a WHERE trunc(a.bill_date) > trunc(a.date_of_discharge)) AS post_count,
              (SELECT COUNT(1) FROM bill_det a WHERE trunc(a.bill_date) BETWEEN trunc(a.date_of_admission) AND trunc(a.date_of_discharge)) AS hosp_count
              FROM dual;

   v_buff_app_amt                           buffer_header.buff_app_amt%type:=pre_auth_pkg.get_buff_apr_amt(v_claim_seq_id,'CLM','CORP_BUFF') ;
   v_med_buff_app_amt                       buffer_header.buff_app_amt%type:=pre_auth_pkg.get_buff_apr_amt(v_claim_seq_id,'CLM','MED_BUFF') ;	
   v_crit_buff_app_amt                      buffer_header.buff_app_amt%type:=pre_auth_pkg.get_buff_apr_amt(v_claim_seq_id,'CLM','CRIT_BUFF') ;
   v_crit_corp_buff_app_amt                 buffer_header.buff_app_amt%type:=pre_auth_pkg.get_buff_apr_amt(v_claim_seq_id,'CLM','CRIT_CORP_BUFF') ;
   v_crit_med_buff_app_amt                  buffer_header.buff_app_amt%type:=pre_auth_pkg.get_buff_apr_amt(v_claim_seq_id,'CLM','CRIT_MED_BUFF') ;
	              
     CURSOR claim_cur IS
       SELECT
         A.claim_seq_id,
         b.tpa_enrollment_id,
         b.claimant_name,
         ab.description AS gender,
         b.mem_age,
         TO_CHAR(b.date_of_inception,'DD/MM/YYYY') AS date_of_inception ,
         TO_CHAR(b.date_of_exit,'DD/MM/YYYY') AS date_of_exit,
         TO_CHAR(al.ACTUAL_POLICY_START_DATE,'DD/MM/YYYY') AS actual_date_of_inception , --policy renewal
         TO_CHAR(al.ACTUAL_POLICY_END_DATE,'DD/MM/YYYY') AS actual_date_of_exit,   --policy renewal
         b.mem_total_sum_insured ,
         --a.ava_sum_insured ,
         pre_auth_pkg.get_available_sum(NULL,a.claim_seq_id,'SUM') AS ava_sum_insured,
         --o.buffer_ava_amount ,
		 (SELECT * FROM (select buffer_ava_amount from  buffer_details b
         where b.claim_seq_id=v_claim_seq_id
         ORDER BY b.buff_detail_seq_id ASC)
         WHERE ROWNUM=1) AS buffer_ava_amounT,
         AR.pre_auth_buffer_app_amount ,
         p.claim_app_buffer_amount ,
         TO_CHAR( NVL(o.buffer_approved_date ,aq.buffer_approved_date), 'dd/mm/yyyy hh:mi AM' ) AS buffer_approved_date,
         --a.ava_cum_bonus,
         pre_auth_pkg.get_available_sum(NULL,a.claim_seq_id,'BONUS') AS ava_cum_bonus,
         b.employee_no,
         b.policy_holder_name,
         ac.relship_description ,
         b.claimant_phone_number ,
         a.claim_number,
         a.claim_file_number,
         ad.description AS request_type,
         d.description AS claim_type,
         ae.description AS claim_sub_type,
         TO_CHAR(ak.call_recorded_date,'dd/mm/yyyy hh:mi AM' ) AS intimation_date,
         af.description AS mode_type,
         TO_CHAR(c.rcvd_date,'dd/mm/yyyy hh:mi AM' ) AS rcvd_date,
         a.requested_amount,
         a.treating_dr_name,
         a.in_patient_no,
         e.office_name,
--         ag.description AS source_type,
         z.contact_name,
         ah.office_name AS processing_branch,
         a.claims_remarks ,
         b.policy_number,
         i.ins_comp_name,
         b.phone_1 ,
         CASE WHEN b.ins_status_general_type_id = 'TPR' THEN 'Renewal' ELSE 'Fresh' END AS term_status,
         CASE WHEN b.enrol_type_id = 'IND' THEN 'Individual'
              WHEN b.enrol_type_id = 'ING' THEN 'Individual As Group'
              WHEN b.enrol_type_id = 'COR' THEN 'Corporate'
              WHEN b.enrol_type_id = 'NCR' THEN 'Non-Corporate' END AS policy_type,
         CASE WHEN b.policy_sub_general_type_id = 'PNF' THEN 'Non-Floater'
              WHEN b.policy_sub_general_type_id = 'PFL' THEN 'Floater'
              WHEN b.policy_sub_general_type_id = 'PFN' THEN 'Floater + Non-Floater'
              WHEN b.policy_sub_general_type_id = 'PFL' THEN 'Floater with Restriction' END AS policy_sub_type,
         TO_CHAR(b.policy_effective_from,'DD/MM/YYYY') AS policy_effective_from,
         TO_CHAR(b.policy_effective_to,'DD/MM/YYYY') AS policy_effective_to,
         NVL(s.hosp_name,q.hosp_name ) AS hosp_name ,
         s.empanel_number ,
         NVL(U.city_description , q.city_name ) AS city_name ,
         NVL(v.state_name , q.state_name ) AS state_name ,
         s.rating ,
         a.claim_settlement_number ,
         a.total_app_amount,
         ai.max_allowed_amount ,
         a.pat_approved_amount ,
         case when clm_status_general_type_id ='REJ' AND A.COMPLETED_YN='N' AND cii.CLM_INS_STATUS='INP' THEN app.ACCOUNT_INFO_PKG.get_gen_desc('INSR','G') ELSE k.description end AS status,
         a.permission_sought_from,
         TO_CHAR(b.decision_date,'dd/mm/yyyy hh:mi AM' ) AS decision_date,
         aj.description AS reason_type,
         x.remarks ,
         am.product_name,
         AN.provisional_diagnosis,
         TO_CHAR(a.date_of_admission,'dd/mm/yyyy HH:MI AM') AS date_of_admission,
         TO_CHAR(a.date_of_discharge,'dd/mm/yyyy HH:MI AM') AS date_of_discharge,
         (SELECT COUNT(1) FROM shortfall_details ss WHERE ss.claim_seq_id = a.claim_seq_id ) AS shortfall_count,
         al.zone_code, --For KOC1010
         DECODE(G.diabetes_cover_yn ,'Y','Yes','No') AS diabetes_cover_yn, --For KOC1010
         CASE WHEN I.INS_COMP_NAME LIKE 'CIGNA%' AND I.NOTIFY_TYPE_ID='NIC' AND C.CLAIM_GENERAL_TYPE_ID='CTM'  THEN 'Y' ELSE 'N' END AS CIGNA_YN, --koc_ins_mail
         DECODE(G.hypertension_cover_yn ,'Y','Yes','No') AS hypertension_cover_yn, --For KOC1010
		     tgc.description as pay_to,--opdforhs
         v_buff_app_amt Buff_App_Amt,
         v_med_buff_app_amt Med_Buff_App_Amt,
         v_crit_buff_app_amt Crit_Buff_App_Amt,
         v_crit_corp_buff_app_amt Crit_Corp_Buff_App_Amt,
         v_crit_med_buff_app_amt Crit_Med_Buff_App_Amt,   
         nvl(nvl(p.Utilised_Amount,ar.Utilised_Amount),0) AS Utilised_Amount,
         nvl(nvl(p.Utilised_Med_Amount,ar.Utilised_Med_Amount),0) AS Utilised_Med_Amount,
         nvl(nvl(p.Utilised_Crit_Amount,ar.Utilised_Crit_Amount),0) AS Utilised_Crit_Amount,
         nvl(nvl(p.Utilised_Crit_Corp_Amount,ar.Utilised_Crit_Corp_Amount),0) AS Utilised_Crit_Corp_Amount,
         nvl(nvl(p.Utilised_Crit_Med_Amount,ar.Utilised_Crit_Med_Amount),0) AS Utilised_Crit_Med_Amount,
         v_buff_app_amt + v_med_buff_app_amt + v_crit_buff_app_amt + v_crit_corp_buff_app_amt + v_crit_med_buff_app_amt AS apr_buff_amount,
         nvl(nvl(p.Utilised_Amount,ar.Utilised_Amount),0)+nvl(nvl(p.Utilised_Med_Amount,ar.Utilised_Med_Amount),0)+nvl(nvl(p.Utilised_Crit_Amount,ar.Utilised_Crit_Amount),0)+
         nvl(nvl(p.Utilised_Crit_Corp_Amount,ar.Utilised_Crit_Corp_Amount),0)+nvl( nvl(p.Utilised_Crit_Med_Amount,ar.Utilised_Crit_Med_Amount),0) AS util_buff_amount

         
         FROM clm_general_details A JOIN clm_enroll_details B ON ( A.claim_seq_id = b.claim_seq_id )
         JOIN clm_inward C ON ( a.claims_inward_seq_id = c.claims_inward_seq_id )
         left outer join app.clm_ins_intimation_details cii on (b.claim_seq_id=cii.claim_seq_id)
         LEFT OUTER JOIN tpa_general_code D ON ( C.claim_general_type_id = D.general_type_id )
         LEFT OUTER JOIN tpa_office_info E ON (C.tpa_office_seq_id = e.tpa_office_seq_id)
         LEFT OUTER JOIN tpa_enr_policy_member G ON (B.member_seq_id = G.member_seq_id)
         LEFT OUTER JOIN tpa_ins_info I ON (B.ins_seq_id = I.ins_seq_id)
         LEFT OUTER JOIN tpa_general_code K ON (b.clm_status_general_type_id = k.general_type_id)
         LEFT OUTER JOIN buffer_details O ON (a.last_buffer_detail_seq_id = o.buff_detail_seq_id )
         LEFT OUTER JOIN buffer_header P ON (o.buffer_hdr_seq_id  = p.buffer_hdr_seq_id )
         LEFT OUTER JOIN clm_hospital_association Q ON ( A.claim_seq_id = Q.claim_seq_id )
         LEFT OUTER JOIN tpa_hosp_info S ON (Q.hosp_seq_id = S.hosp_seq_id)
         LEFT OUTER JOIN tpa_hosp_address T ON (S.hosp_seq_id = T.hosp_seq_id)
         LEFT OUTER JOIN tpa_city_code U ON (T.city_type_id = U.city_type_id)
         LEFT OUTER JOIN tpa_state_code V ON (T.state_type_id = V.state_type_id)
         LEFT OUTER JOIN assign_users X ON (a.last_assign_user_seq_id  = X.assign_users_seq_id)
         LEFT OUTER JOIN tpa_general_code Y ON (B.clm_status_general_type_id = Y.general_type_id)
         LEFT OUTER JOIN tpa_user_contacts Z ON (X.assigned_to_user = Z.contact_seq_id)
         LEFT OUTER JOIN tpa_general_code AA ON (B.Rson_General_Type_Id = AA.general_type_id)
         LEFT OUTER JOIN tpa_general_code AB ON (b.gender_general_type_id = ab.general_type_id )
         LEFT OUTER JOIN tpa_relationship_code AC ON (b.relship_type_id = AC.relship_type_id )
         LEFT OUTER JOIN tpa_general_code AD ON ( C.document_general_type_id = ad.general_type_id )
         LEFT OUTER JOIN tpa_general_code AE ON ( A.claim_sub_general_type_id = AE.general_type_id )
         LEFT OUTER JOIN tpa_general_code AF ON ( A.mode_general_type_id  = AF.general_type_id )
         LEFT OUTER JOIN tpa_office_info ah ON ( z.tpa_office_seq_id = ah.tpa_office_seq_id )
         LEFT OUTER JOIN ( SELECT SUM(approved_amount) AS appr_amt, SUM(maximum_allowed_amount) AS max_allowed_amount , claim_seq_id
                           FROM ailment_caps XXX JOIN icd_pcs_detail YYY ON ( XXX.icd_pcs_seq_id = YYY.icd_pcs_seq_id ) WHERE YYY.claim_seq_id = v_claim_seq_id
                           GROUP BY claim_seq_id ) AI
                           ON ( A.claim_seq_id = AI.claim_seq_id )
         LEFT OUTER JOIN tpa_general_code aj ON ( b.rson_general_type_id = aj.general_type_id )
         LEFT OUTER JOIN tpa_call_log AK ON (a.call_log_seq_id = ak.call_log_seq_id )
         LEFT OUTER JOIN tpa_enr_policy AL ON (b.policy_seq_id = al.policy_seq_id)
         LEFT OUTER JOIN tpa_ins_product AM ON ( al.product_seq_id = am.product_seq_id )
         LEFT OUTER JOIN ailment_details AN ON (A.claim_seq_id = AN.claim_seq_id)
         LEFT OUTER JOIN pat_general_details AP ON (A.pat_enroll_detail_seq_id = AP.pat_enroll_detail_seq_id)
         LEFT OUTER JOIN buffer_details AQ ON (AP.last_buffer_detail_seq_id = AQ.buff_detail_seq_id )
         LEFT OUTER JOIN buffer_header AR ON (AQ.buffer_hdr_seq_id  = AR.buffer_hdr_seq_id )
         LEFT OUTER JOIN tpa_claims_payment AT ON (a.claim_seq_id = AT.claim_seq_id)
         LEFT OUTER JOIN tpa_payment_checks_details AU ON (AT.payment_seq_id = AU.payment_seq_id)
         LEFT OUTER JOIN tpa_claims_check AV ON (AU.claims_chk_seq_id = AV.claims_chk_seq_id)
         LEFT OUTER JOIN tpa_general_code AW ON (AV.check_status = AW.general_type_id)
		 LEFT OUTER JOIN tpa_general_code tgc ON (tgc.general_type_id = a.pay_to_general_type_id)--opdforhs
      LEFT OUTER JOIN tpa_general_code tg ON (nvl(o.claim_type,aq.claim_type) = tg.general_type_id)
         LEFT OUTER JOIN tpa_general_code tc ON (nvl(o.buffer_type,aq.buffer_type) = tc.general_type_id)

         WHERE A.claim_seq_id  = v_claim_seq_id  ;

    CURSOR cheque_cur IS
         SELECT AW.description AS cheque_status,
         TO_CHAR(AV.check_date,'dd/mm/yyyy hh:mi AM') AS check_date,
         CASE WHEN AT.PAYEE_TYPE='EFT' THEN 'EFT-'||TO_CHAR(AV.check_num) ELSE TO_CHAR(AV.check_num) END AS check_num,--KOC1103
         CASE WHEN AT.CLAIM_PAYMENT_STATUS='PAID' THEN AV.check_amount ELSE NULL END AS check_amount ,--ADDED FOR KOC1103
/*For eft when do print cheque that time only amount insert into cheque info table,if NH Claim it is inserting without tax deduction but tax deduction will
be done in next step payment advice. after cheque uploading it will show exact cheque data in claim,cheque_info,account_info modules else it will show null.
--(else before it will show wrong data for NG claims_*/
         (td.approved_amount - td.check_amount) AS tds_amount,
         ttk_util_pkg.fn_decrypt( AT.payee_name) as payee_name, --//ED
         av.consignment_no,
         av.provider_name,
         TO_CHAR(av.Despatch_Date,'dd/mm/yyyy hh:mi AM') AS Despatch_Date
         FROM tpa_claims_payment AT LEFT OUTER JOIN tpa_payment_checks_details AU ON (AT.payment_seq_id = AU.payment_seq_id)
         LEFT OUTER JOIN tpa_claims_check AV ON (AU.claims_chk_seq_id = AV.claims_chk_seq_id)
         LEFT OUTER JOIN tpa_general_code AW ON (AV.check_status = AW.general_type_id)
         LEFT OUTER JOIN tpa_clm_tds_details td ON (td.claim_seq_id=AT.claim_seq_id)
         WHERE AT.claim_seq_id  = v_claim_seq_id  ;
    cheque_rec              cheque_cur%ROWTYPE;
    CURSOR icd_pcs_cur IS SELECT
      A.icd_pcs_seq_id,
      A.ped_code_id,
      NVL(c.ped_description,'Others - '||A.other_desc) AS ailment_desc ,
      A.icd_code,
      A.primary_ailment_yn,
      NULL AS pkg_rate ,
      G.maximum_allowed_amount AS validated_amt,
      G.approved_amount AS itemized_app_amount,
      D.proc_seq_id,
      D.pkg_seq_id,
      a.hospital_general_type_id ,
      H.description AS hospitalization_type ,
      A.frequency_of_visit ,
      A.no_of_visits ,
      DECODE (a.pat_duration_general_type_id,'DTD','Days','DTW','Weeks','DTM','Months','Years') AS duration,
      NVL(E.NAME ,F.proc_description) AS NAME
      FROM icd_pcs_detail A LEFT OUTER JOIN tpa_ped_code C ON (A.ped_code_id = C.ped_code_id)
      LEFT OUTER JOIN pat_package_procedures D ON ( A.icd_pcs_seq_id = D.icd_pcs_seq_id )
      LEFT OUTER JOIN tpa_hosp_tariff_item E ON (d.pkg_seq_id = e.pkg_seq_id)
      LEFT OUTER JOIN tpa_hosp_procedure_code F ON (D.proc_seq_id = F.proc_seq_id)
      LEFT OUTER JOIN ailment_caps G ON ( a.icd_pcs_seq_id = G.icd_pcs_seq_id )
      LEFT OUTER JOIN tpa_general_code H ON (a.hospital_general_type_id = h.general_type_id)
      WHERE A.claim_seq_id  = v_claim_seq_id  ORDER BY A.icd_pcs_seq_id ;

    CURSOR narration_cur IS SELECT
      A.reference_date,
      A.remarks,
      B.contact_name
      FROM pat_log A JOIN tpa_user_contacts B ON (a.added_by = b.contact_seq_id)
      WHERE A.claim_seq_id = v_claim_seq_id AND pat_log_general_type_id = 'NAR';


      v_rec_user                   claim_cur%ROWTYPE;
      v_prev_icd_rec               icd_pcs_cur%ROWTYPE;
      rec                          icd_pcs_cur%ROWTYPE;


      v_preauth_doc        DBMS_XMLDOM.DOMDocument;
      v_preauth_root_node  DBMS_XMLDOM.DOMNode;
      v_elem               DBMS_XMLDOM.DOMElement;
      v_node               DBMS_XMLDOM.DOMNode;
      v_parent_node        DBMS_XMLDOM.DOMNODE;
      v_root_node          DBMS_XMLDOM.DOMNode;
      v_ctr                NUMBER := 1 ;
      v_name               VARCHAR2(2000);
      v_flag               CHAR(1) := 'N';
      pre_post_rec         pre_post_cur%ROWTYPE;
   BEGIN
      OPEN pre_post_cur;
      FETCH pre_post_cur INTO pre_post_rec;
      CLOSE pre_post_cur;

      OPEN claim_cur;
      FETCH claim_cur INTO v_rec_user;
      CLOSE claim_cur;

      v_preauth_doc := dbms_xmldom.newDOMDocument;
      dbms_xmldom.setVersion( v_preauth_doc, '1.0' );
      v_preauth_root_node := dbms_xmldom.makeNode(v_preauth_doc);

      v_elem := dbms_xmldom.createElement( v_preauth_doc, 'claimshistory' );
      v_node := dbms_xmldom.makeNode( v_elem );
      v_preauth_root_node := dbms_xmldom.appendChild( v_preauth_root_node, v_node );
---
      v_elem := dbms_xmldom.createElement(v_preauth_doc, 'claimantdetails');
      dbms_xmldom.setAttribute(v_elem,'enrollmentid',v_rec_user.tpa_enrollment_id);
      dbms_xmldom.setAttribute(v_elem,'claimantname',v_rec_user.claimant_name);
      dbms_xmldom.setAttribute(v_elem,'gender',v_rec_user.gender);
      dbms_xmldom.setAttribute(v_elem,'age',v_rec_user.mem_age);
      dbms_xmldom.setAttribute(v_elem,'dateofinception',v_rec_user.date_of_inception);
      dbms_xmldom.setAttribute(v_elem,'dateofexit',v_rec_user.date_of_exit);
      dbms_xmldom.setAttribute(v_elem,'totalsuminsured',v_rec_user.mem_total_sum_insured);
      dbms_xmldom.setAttribute(v_elem,'totalappbufferamount',v_rec_user.apr_buff_amount );
      dbms_xmldom.setAttribute(v_elem,'totalutilbufferamount',v_rec_user.util_buff_amount );
      dbms_xmldom.setAttribute(v_elem,'availablesum',v_rec_user.ava_sum_insured);
      dbms_xmldom.setAttribute(v_elem,'availablebonus',v_rec_user.ava_cum_bonus);
      dbms_xmldom.setAttribute(v_elem,'employeeno',v_rec_user.employee_no);
      dbms_xmldom.setAttribute(v_elem,'employeename',v_rec_user.policy_holder_name);
      dbms_xmldom.setAttribute(v_elem,'relationship',v_rec_user.relship_description);
      dbms_xmldom.setAttribute(v_elem,'claimantphone',v_rec_user.claimant_phone_number);
      dbms_xmldom.setAttribute(v_elem,'diabetes_cover_yn',v_rec_user.diabetes_cover_yn); --For KOC1010
      dbms_xmldom.setAttribute(v_elem,'hypertension_cover_yn',v_rec_user.hypertension_cover_yn);--For KOC1010
      v_node := dbms_xmldom.makeNode(v_elem);
      v_parent_node := dbms_xmldom.appendChild( v_preauth_root_node, v_node);
--------

      v_elem := dbms_xmldom.createElement(v_preauth_doc, 'claimdetails');
      dbms_xmldom.setAttribute(v_elem,'claimnumber', v_rec_user.claim_number);
      dbms_xmldom.setAttribute(v_elem,'claimfileno', v_rec_user.claim_file_number);
      dbms_xmldom.setAttribute(v_elem,'requesttype', v_rec_user.request_type);
      dbms_xmldom.setAttribute(v_elem,'claimtype', v_rec_user.claim_type);
      dbms_xmldom.setAttribute(v_elem,'claimsubtype',v_rec_user.claim_sub_type);
	  dbms_xmldom.setAttribute(v_elem,'paymentto',v_rec_user.pay_to);--opdforhs
      dbms_xmldom.setAttribute(v_elem,'intimationdate',v_rec_user.intimation_date);
      dbms_xmldom.setAttribute(v_elem,'mode',v_rec_user.mode_type);
      dbms_xmldom.setAttribute(v_elem,'rcvddate',v_rec_user.rcvd_date);
      dbms_xmldom.setAttribute(v_elem,'requestedamount',v_rec_user.requested_amount);
      dbms_xmldom.setAttribute(v_elem,'doctorname',v_rec_user.treating_dr_name);
      dbms_xmldom.setAttribute(v_elem,'inpatiantname',v_rec_user.in_patient_no);
      dbms_xmldom.setAttribute(v_elem,'ttkbranch',v_rec_user.office_name);
      dbms_xmldom.setAttribute(v_elem,'assignedto',v_rec_user.contact_name);
      dbms_xmldom.setAttribute(v_elem,'processingbranch',v_rec_user.processing_branch);
      dbms_xmldom.setAttribute(v_elem,'dateofadmission',v_rec_user.date_of_admission);
      dbms_xmldom.setAttribute(v_elem,'dateofdischarge',v_rec_user.date_of_discharge);
      dbms_xmldom.setAttribute(v_elem,'claimsremarks',v_rec_user.claims_remarks);

      dbms_xmldom.setAttribute(v_elem,'prehospitalization',pre_post_rec.pre_count); -- if > 0 means Yes Else No.
      dbms_xmldom.setAttribute(v_elem,'posthospitalization',pre_post_rec.post_count);-- if > 0 means Yes Else No.
      dbms_xmldom.setAttribute(v_elem,'hospitalization',pre_post_rec.hosp_count );-- if > 0 means Yes Else No.
      v_node := dbms_xmldom.makeNode(v_elem);
      v_parent_node := dbms_xmldom.appendChild( v_preauth_root_node, v_node);

      v_elem := dbms_xmldom.createElement(v_preauth_doc, 'chequeinformation');
      v_node := dbms_xmldom.makeNode(v_elem);
      v_root_node := dbms_xmldom.appendChild( v_preauth_root_node, v_node);

--------
      v_elem := dbms_xmldom.createElement(v_preauth_doc, 'shortfall');
      dbms_xmldom.setAttribute( v_elem,'shortfall',CASE WHEN v_rec_user.shortfall_count > 0 THEN 'Y' ELSE 'N' END);
      dbms_xmldom.setAttribute( v_elem, 'seq_id', v_claim_seq_id);
      dbms_xmldom.setAttribute(v_elem,'cigna_yn',v_rec_user.cigna_yn);  --koc_ins_mail
      v_node := dbms_xmldom.makeNode(v_elem);
      v_parent_node := dbms_xmldom.appendChild( v_preauth_root_node, v_node);
--------



      OPEN cheque_cur;
      FETCH cheque_cur INTO cheque_rec;
      WHILE cheque_cur%FOUND
      LOOP
        v_elem := dbms_xmldom.createElement(v_preauth_doc, 'record');
        dbms_xmldom.setAttribute(v_elem,'id', v_ctr);
        dbms_xmldom.setAttribute(v_elem,'checknumber',cheque_rec.check_num);
        dbms_xmldom.setAttribute(v_elem,'checkdate',cheque_rec.check_date);
        dbms_xmldom.setAttribute(v_elem,'checkamount',cheque_rec.check_amount);
        dbms_xmldom.setAttribute(v_elem,'tdsamount',cheque_rec.tds_amount);
        dbms_xmldom.setAttribute(v_elem,'chequestatus',cheque_rec.cheque_status);
        dbms_xmldom.setAttribute(v_elem,'payeename',cheque_rec.payee_name);
        dbms_xmldom.setAttribute(v_elem,'consignmentno',cheque_rec.consignment_no);
        dbms_xmldom.setAttribute(v_elem,'providername',cheque_rec.provider_name);
        dbms_xmldom.setAttribute(v_elem,'despatchdate',cheque_rec.Despatch_Date);
        v_node := dbms_xmldom.makeNode(v_elem);
        v_parent_node := dbms_xmldom.appendChild( v_root_node, v_node);
        FETCH cheque_cur INTO cheque_rec;
        v_ctr := v_ctr + 1;
      END LOOP;
-------------

      v_elem := dbms_xmldom.createElement(v_preauth_doc, 'policydetails');
      dbms_xmldom.setAttribute(v_elem,'policynumber',v_rec_user.policy_number);
      dbms_xmldom.setAttribute(v_elem,'zonecode',v_rec_user.zone_code); --For KOC1010
      dbms_xmldom.setAttribute(v_elem,'inscompname',v_rec_user.ins_comp_name);
      dbms_xmldom.setAttribute(v_elem,'policyholder',v_rec_user.policy_holder_name);
      dbms_xmldom.setAttribute(v_elem,'phone',v_rec_user.phone_1);
      dbms_xmldom.setAttribute(v_elem,'termstatus',v_rec_user.term_status);
      dbms_xmldom.setAttribute(v_elem,'policytype',v_rec_user.policy_type);
      dbms_xmldom.setAttribute(v_elem,'policysubtype',v_rec_user.policy_sub_type);
      dbms_xmldom.setAttribute(v_elem,'startdate',v_rec_user.policy_effective_from);
      dbms_xmldom.setAttribute(v_elem,'enddate',v_rec_user.policy_effective_to);
      dbms_xmldom.setAttribute(v_elem,'actualstartdate',v_rec_user.ACTUAL_DATE_OF_INCEPTION);  --policy renewal
      dbms_xmldom.setAttribute(v_elem,'actualenddate',v_rec_user.ACTUAL_DATE_OF_EXIT);  --policy renewal      
      dbms_xmldom.setAttribute(v_elem,'availablebonus',v_rec_user.ava_cum_bonus);
      dbms_xmldom.setAttribute(v_elem,'productname',v_rec_user.product_name);
      v_node := dbms_xmldom.makeNode(v_elem);
      v_parent_node := dbms_xmldom.appendChild( v_preauth_root_node, v_node);

-----------
      v_elem := dbms_xmldom.createElement(v_preauth_doc, 'icdpcscodingdetails');
      v_node := dbms_xmldom.makeNode(v_elem);
      v_root_node := dbms_xmldom.appendChild( v_preauth_root_node, v_node);

      v_elem := dbms_xmldom.createElement(v_preauth_doc, 'provisionaldiagnosis');
      dbms_xmldom.setAttribute(v_elem,'description',v_rec_user.Provisional_Diagnosis);
      v_node := dbms_xmldom.makeNode(v_elem);
      v_parent_node := dbms_xmldom.appendChild( v_root_node, v_node);

     v_ctr := 1;
     OPEN icd_pcs_cur;
     FETCH icd_pcs_cur INTO rec;
     WHILE icd_pcs_cur%FOUND
     LOOP
        IF v_prev_icd_rec.icd_pcs_seq_id IS NULL THEN
           v_prev_icd_rec := rec;
           v_name := rec.NAME;
           v_flag := 'Y';
        ELSE
          IF rec.icd_pcs_seq_id = v_prev_icd_rec.icd_pcs_seq_id THEN
            v_name := v_name ||','|| rec.NAME;
          ELSE
            v_elem := dbms_xmldom.createElement(v_preauth_doc, 'record');
            dbms_xmldom.setAttribute(v_elem,'id',v_ctr);
            dbms_xmldom.setAttribute(v_elem,'ailment',v_prev_icd_rec.ailment_desc);
            dbms_xmldom.setAttribute(v_elem,'icdcode',v_prev_icd_rec.icd_code);
            dbms_xmldom.setAttribute(v_elem,'pckageorprocedure',v_name);
            dbms_xmldom.setAttribute(v_elem,'packagerate',v_prev_icd_rec.pkg_rate);
            dbms_xmldom.setAttribute(v_elem,'validatedamount',v_prev_icd_rec.validated_amt);
            dbms_xmldom.setAttribute(v_elem,'approvedamount',v_prev_icd_rec.itemized_app_amount);
            dbms_xmldom.setAttribute(v_elem,'hospitalizationtype',v_prev_icd_rec.hospital_general_type_id);
            dbms_xmldom.setAttribute(v_elem,'hospitalizationdescription',v_prev_icd_rec.hospitalization_type);
            dbms_xmldom.setAttribute(v_elem,'frequency','(Freq:'||v_prev_icd_rec.frequency_of_visit||' '||v_prev_icd_rec.duration ||') (No.:'||v_prev_icd_rec.no_of_visits||')');
            v_node := dbms_xmldom.makeNode(v_elem);
            v_parent_node := dbms_xmldom.appendChild( v_root_node, v_node);
            v_prev_icd_rec := rec;
            v_name := rec.NAME;
            v_ctr := v_ctr + 1;
          END IF;
        END IF;
        FETCH icd_pcs_cur INTO rec;
      END LOOP;
      IF v_flag = 'Y' THEN
        v_elem := dbms_xmldom.createElement(v_preauth_doc, 'record');
        dbms_xmldom.setAttribute(v_elem,'id',v_ctr);
        dbms_xmldom.setAttribute(v_elem,'ailment',rec.ailment_desc);
        dbms_xmldom.setAttribute(v_elem,'icdcode',rec.icd_code);
        dbms_xmldom.setAttribute(v_elem,'pckageorprocedure',v_name);
        dbms_xmldom.setAttribute(v_elem,'packagerate',rec.pkg_rate);
        dbms_xmldom.setAttribute(v_elem,'validatedamount',rec.validated_amt);
        dbms_xmldom.setAttribute(v_elem,'approvedamount',rec.itemized_app_amount);
        dbms_xmldom.setAttribute(v_elem,'hospitalizationtype',rec.hospital_general_type_id);
        dbms_xmldom.setAttribute(v_elem,'hospitalizationdescription',rec.hospitalization_type);
        dbms_xmldom.setAttribute(v_elem,'frequency','(Freq:'||rec.frequency_of_visit||' '||rec.duration ||') (No.:'||rec.no_of_visits||')');
        v_node := dbms_xmldom.makeNode(v_elem);
        v_parent_node := dbms_xmldom.appendChild( v_root_node, v_node);
      END IF;
      CLOSE icd_pcs_cur;
------------
      v_elem := dbms_xmldom.createElement(v_preauth_doc, 'hospitaldetails');
      dbms_xmldom.setAttribute(v_elem,'hospitalname',v_rec_user.hosp_name);
      dbms_xmldom.setAttribute(v_elem,'hospitalgrade',v_rec_user.rating);
      dbms_xmldom.setAttribute(v_elem,'empanelnumber',v_rec_user.empanel_number);
      dbms_xmldom.setAttribute(v_elem,'city',v_rec_user.city_name);
      dbms_xmldom.setAttribute(v_elem,'state',v_rec_user.state_name);
      v_node := dbms_xmldom.makeNode(v_elem);
      v_parent_node := dbms_xmldom.appendChild( v_preauth_root_node, v_node);
------------

      v_elem := dbms_xmldom.createElement(v_preauth_doc, 'settlementdetails');
      dbms_xmldom.setAttribute(v_elem,'settlementnumber',v_rec_user.claim_settlement_number);
      dbms_xmldom.setAttribute(v_elem,'totalsuminsured',v_rec_user.mem_total_sum_insured);
      dbms_xmldom.setAttribute(v_elem,'availablesuminsured',v_rec_user.ava_sum_insured);
      dbms_xmldom.setAttribute(v_elem,'availablebonus',v_rec_user.ava_cum_bonus);
      dbms_xmldom.setAttribute(v_elem,'requestedamount',v_rec_user.requested_amount);

      dbms_xmldom.setAttribute(v_elem,'preauthapprovedamount',v_rec_user.pat_approved_amount);
      dbms_xmldom.setAttribute(v_elem,'approvedamount',v_rec_user.total_app_amount );

      v_node := dbms_xmldom.makeNode(v_elem);
      v_parent_node := dbms_xmldom.appendChild( v_preauth_root_node, v_node);
-----------
      v_elem := dbms_xmldom.createElement(v_preauth_doc, 'bufferamount');
      dbms_xmldom.setAttribute(v_elem,'nrmlbufferamount',v_rec_user.buff_app_amt );
      dbms_xmldom.setAttribute(v_elem,'medbufferamount',v_rec_user.med_buff_app_amt );
      dbms_xmldom.setAttribute(v_elem,'critbufferamount',v_rec_user.crit_buff_app_amt );
      dbms_xmldom.setAttribute(v_elem,'critcorpbufferamount',v_rec_user.crit_corp_buff_app_amt );
      dbms_xmldom.setAttribute(v_elem,'critmedbufferamount',v_rec_user.crit_med_buff_app_amt );
      dbms_xmldom.setAttribute(v_elem,'utilbufferamount',v_rec_user.utilised_amount );
      dbms_xmldom.setAttribute(v_elem,'utilmedbufferamount',v_rec_user.utilised_med_amount );
      dbms_xmldom.setAttribute(v_elem,'utilcritbufferamount',v_rec_user.utilised_crit_amount );
      dbms_xmldom.setAttribute(v_elem,'utilcritcorpbufferamount',v_rec_user.utilised_crit_corp_amount );
      dbms_xmldom.setAttribute(v_elem,'utilcritmedbufferamount',v_rec_user.utilised_crit_med_amount );
      
      v_node := dbms_xmldom.makeNode(v_elem);
      v_parent_node := dbms_xmldom.appendChild( v_preauth_root_node, v_node);
---------
      v_elem := dbms_xmldom.createElement(v_preauth_doc, 'approvalstatus');
      dbms_xmldom.setAttribute(v_elem,'status',v_rec_user.status);
      dbms_xmldom.setAttribute(v_elem,'approvedby',v_rec_user.contact_name);
      dbms_xmldom.setAttribute(v_elem,'approveddate',v_rec_user.decision_date);
      dbms_xmldom.setAttribute(v_elem,'remarks',v_rec_user.remarks);
      dbms_xmldom.setAttribute(v_elem,'reason',v_rec_user.reason_type);

      v_node := dbms_xmldom.makeNode(v_elem);
      v_parent_node := dbms_xmldom.appendChild( v_preauth_root_node, v_node);
-------
      v_elem := dbms_xmldom.createElement(v_preauth_doc, 'narrationdetails');
      v_node := dbms_xmldom.makeNode(v_elem);
      v_root_node := dbms_xmldom.appendChild( v_preauth_root_node, v_node);

     v_ctr := 1;
     FOR nar_rec IN narration_cur
     LOOP
        v_elem := dbms_xmldom.createElement(v_preauth_doc, 'record');
        dbms_xmldom.setAttribute(v_elem,'id', v_ctr);
        dbms_xmldom.setAttribute(v_elem,'referencedate',nar_rec.reference_date);
        dbms_xmldom.setAttribute(v_elem,'remarks',nar_rec.remarks);
        dbms_xmldom.setAttribute(v_elem,'user',nar_rec.contact_name);
        v_node := dbms_xmldom.makeNode(v_elem);
        v_parent_node := dbms_xmldom.appendChild( v_root_node, v_node);
        v_ctr := v_ctr + 1;
      END LOOP;
--------
--      dbms_xmldom.writeToBuffer( v_preauth_root_node, v_buf);
--      dbms_output.put_line('First :'||v_buf);

      v_claim_history_doc := dbms_xmldom.getxmltype( v_preauth_doc );
      
     dbms_xmldom.freeDocument(v_preauth_doc);
   END create_claim_xml;
--================================================================================================================
  PROCEDURE do_copy_previous_claim (
    v_claim_seq_id                    IN OUT clm_general_details.claim_seq_id%TYPE,
    v_clm_enroll_detail_seq_id        IN OUT clm_enroll_details.clm_enroll_detail_seq_id%TYPE,
    v_parent_claim_seq_id             IN OUT clm_general_details.parent_claim_seq_id%TYPE,
    v_claims_inward_seq_id            IN clm_inward.claims_inward_seq_id%TYPE ,
    v_requested_amount                IN clm_general_details.requested_amount%TYPE,
    v_added_by                        IN NUMBER
  )
  IS
    CURSOR prev_amd_cur IS SELECT COUNT(1)
      FROM clm_general_details A JOIN clm_enroll_details B ON ( a.claim_seq_id = b.claim_seq_id )
      WHERE a.parent_claim_seq_id = v_parent_claim_seq_id
      AND a.claim_seq_id != NVL( v_claim_seq_id , 0 )
      AND ( b.clm_status_general_type_id = 'INP' OR  b.clm_status_general_type_id = 'REQ' OR a.completed_yn = 'N' );

    CURSOR claim_cur IS SELECT
      A.claims_inward_seq_id ,   A.claim_number ,      A.claim_file_number ,       A.pat_enroll_detail_seq_id ,
      A.auth_number ,     A.request_general_type_id ,     A.claim_sub_general_type_id ,
      A.call_log_seq_id ,    A.mode_general_type_id ,     A.treating_dr_name ,      A.in_patient_no ,
      A.claims_remarks ,   A.discrepancy_present_yn ,    A.date_of_admission ,    A.date_of_discharge ,
      A.claim_settlement_number ,  A.prev_hosp_claim_seq_id  , a.pat_approved_amount, B.gender_general_type_id ,
      B.member_seq_id ,    B.tpa_enrollment_id ,       B.policy_seq_id ,       B.policy_holder_name ,
      B.employee_no ,     B.employee_name ,      B.mem_age ,      B.claimant_name ,      B.date_of_inception ,
      B.date_of_exit ,   B.relship_type_id ,   B.policy_number ,   B.claimant_phone_number , nvl(n.mem_tot_sum_insured,o.floater_sum_insured) AS mem_total_sum_insured ,
      B.enrol_type_id  ,    B.policy_sub_general_type_id  ,   B.phone_1 ,   B.policy_effective_from ,
      B.policy_effective_to ,    B.ins_status_general_type_id ,    B.ins_seq_id ,    B.group_reg_seq_id,
      C.claim_general_type_id ,    D.hosp_seq_id ,       D.empanel_number ,       D.hosp_name ,        D.address_1,
      D.address_2 ,       D.address_3 ,       D.state_name ,       D.city_name ,       D.pin_code ,       D.off_phone_no_1,
      D.off_phone_no_2 ,     D.office_fax_no,    D.remarks ,   E.hosp_regist_number ,     E.contact_name  ,
      E.off_phone_no_1 addl_phone,    E.number_of_beds ,       E.fully_equipped_yn , F.buffer_allowed_yn , b.clm_status_general_type_id ,
      a.doctor_registration_no, ttk_util_pkg.fn_decrypt(B.email_id) as email_id, --//ED
       B.notification_phone_number,f.buffer_alloc_general_type_id,
      b.ins_scheme,b.certificate_no,b.ins_customer_code, b.modification_mode_value,
      a.last_buffer_detail_seq_id,
      NVL(i.pre_auth_buffer_app_amount,m.pre_auth_buffer_app_amount) AS pat_buff_app_amount,
      NVL(i.claim_app_buffer_amount,m.claim_app_buffer_amount) AS clm_buff_app_amount,
      NVL(i.utilised_amount,m.utilised_amount) AS buff_utilised_amount,
      NVL(i.buffer_hdr_seq_id,m.buffer_hdr_seq_id) AS buffer_hdr_seq_id,
      f.total_buffer_amount, n.mem_general_type_id,D.serv_tax_rgn_number,A.Dom_Reason_Gen_Type_Id,A.Doc_Cert_Dom_Yn,--KOC1285
      a.insur_ref_number, --- insur-ref-number
	    a.pay_to_general_type_id ,--opdforhs
      nvl(l.claim_type,g.claim_type) claim_type,nvl(l.buffer_type,g.buffer_type) as buffer_type
      FROM clm_general_details A JOIN clm_enroll_details B ON (A.claim_seq_id = B.claim_seq_id )
      JOIN clm_inward C ON (a.claims_inward_seq_id = c.claims_inward_seq_id )
      LEFT OUTER JOIN clm_hospital_association D ON ( a.claim_seq_id = d.claim_seq_id )
      LEFT OUTER JOIN clm_hospital_additional_dtl E ON ( d.clm_hosp_assoc_seq_id = e.clm_hosp_assoc_seq_id )
      LEFT OUTER JOIN tpa_enr_policy f ON ( b.policy_seq_id = f.policy_seq_id )
      LEFT OUTER JOIN buffer_details g ON (a.last_buffer_detail_seq_id = g.buff_detail_seq_id)
      LEFT OUTER JOIN buffer_header i ON (g.buffer_hdr_seq_id = i.buffer_hdr_seq_id)
      LEFT OUTER JOIN pat_enroll_details j ON (a.pat_enroll_detail_seq_id = j.pat_enroll_detail_seq_id)
      LEFT OUTER JOIN pat_general_details k ON (j.pat_enroll_detail_seq_id = k.pat_enroll_detail_seq_id AND k.pat_enhanced_yn = 'N')
      LEFT OUTER JOIN buffer_details L ON (K.last_buffer_detail_seq_id = L.buff_detail_seq_id)
      LEFT OUTER JOIN buffer_header M ON (L.buffer_hdr_seq_id = M.buffer_hdr_seq_id)
      LEFT OUTER JOIN tpa_enr_policy_member n ON (b.member_seq_id = n.member_seq_id)
      LEFT OUTER JOIN tpa_enr_policy_group o ON (n.policy_group_seq_id = o.policy_group_seq_id)
      WHERE a.claim_seq_id = v_parent_claim_seq_id AND a.completed_yn = 'Y';

     CURSOR bill_cur IS SELECT DISTINCT b.clm_bill_seq_id  , B.bill_included_yn
       FROM clm_bill_details a JOIN clm_bill_header b ON ( a.clm_bill_seq_id = b.clm_bill_seq_id )
       WHERE b.claim_seq_id = v_parent_claim_seq_id AND ( NVL(a.rejected_amount,0) > 0 OR b.bill_included_yn = 'N' OR ( a.requested_amount - nvl(a.allowed_amount,0)) >0 );
     claim_rec                     claim_cur%ROWTYPE;

    CURSOR balance_cur IS SELECT B.balance_seq_id,b.policy_group_seq_id, b.buffer_amount,b.utilised_buff_amount,a.mem_general_type_id , c.mem_buffer_seq_id ,c.used_buff_amount,
           b.utilised_med_buff_amount,b.utilised_crit_buff_amount,b.utilised_crit_corp_buff_amt,b.utilised_crit_med_buff_amt,
           c.used_med_buff_amt,c.used_crit_buff_amt,c.used_crit_corp_buff_amt,c.used_crit_med_buff_amt
      FROM tpa_enr_policy_member a JOIN tpa_enr_balance b ON (a.policy_group_seq_id = b.policy_group_seq_id)
      LEFT OUTER JOIN tpa_enr_mem_buffer c ON (a.member_seq_id = c.member_seq_id)
      WHERE a.member_seq_id = claim_rec.member_seq_id  AND ( a.mem_general_type_id = 'PNF' AND b.member_seq_id = claim_rec.member_seq_id OR
                                         a.mem_general_type_id != 'PNF' AND b.member_seq_id IS NULL );

   CURSOR prev_appr_cur IS  SELECT COUNT(1) FROM
     ( SELECT a.claim_seq_id, a.parent_claim_seq_id
      FROM clm_general_details a START WITH a.claim_seq_id = v_parent_claim_seq_id CONNECT BY a.claim_seq_id = PRIOR a.parent_claim_seq_id ) aa
      JOIN clm_enroll_details bb ON (aa.claim_seq_id = bb.claim_seq_id )
      WHERE bb.clm_status_general_type_id = 'APR'  ;

    balance_rec                   balance_cur%ROWTYPE;

    v_prev_parent_seq_id          clm_general_details.parent_claim_seq_id%TYPE;
    v_copy_flag                   CHAR(1) := 'N';
    v_rows_processed              NUMBER(2);
    v_clm_hosp_assoc_seq_id       clm_hospital_association.clm_hosp_assoc_seq_id%TYPE;
    v_add_hosp_dtl_seq_id         clm_hospital_additional_dtl.add_hosp_dtl_seq_id%TYPE;
    v_ava_sum_insured             NUMBER(12,2);
    v_ava_cum_bonus               NUMBER(12,2);
    v_clm_bill_seq_id             clm_bill_header.clm_bill_seq_id%TYPE;
    v_ctr                         NUMBER(2);
    v_re_open_type                clm_general_details.re_open_type%TYPE := 'AMC';
    v_reqd_buff_amt               NUMBER(16,2);
    v_prev_appr_count             PLS_INTEGER := 0;
    v_flag                        VARCHAR2(3);
    v_balance_buffer              NUMBER(16,2);
    v_balance_med_buffer              NUMBER(16,2);
    v_balance_crit_buffer              NUMBER(16,2);
    v_balance_crit_corp_buffer              NUMBER(16,2);
    v_balance_crit_med_buffer              NUMBER(16,2);
    v_buffer_deleted_yn           VARCHAR2(1) := 'N';
  BEGIN
    OPEN prev_amd_cur ;
    FETCH prev_amd_cur INTO v_ctr;
    CLOSE prev_amd_cur ;

    IF v_ctr > 0 THEN
      raise_application_error (-20160, 'New Ammendment cannot be entered before completing Existing Ammendment ');
    END IF;

    IF NVL(v_claim_seq_id,0) = 0 THEN
      v_copy_flag := 'Y';
    ELSE
      SELECT a.parent_claim_seq_id , b.clm_enroll_detail_seq_id , c.clm_hosp_assoc_seq_id , d.add_hosp_dtl_seq_id
         INTO v_prev_parent_seq_id , v_clm_enroll_detail_seq_id , v_clm_hosp_assoc_seq_id , v_add_hosp_dtl_seq_id
         FROM clm_general_details a JOIN clm_enroll_details b ON ( a.claim_seq_id = b.claim_seq_id )
         LEFT OUTER JOIN clm_hospital_association c ON ( a.claim_seq_id = c.claim_seq_id )
         LEFT OUTER JOIN clm_hospital_additional_dtl d ON (c.clm_hosp_assoc_seq_id = d.clm_hosp_assoc_seq_id )
         WHERE a.claim_seq_id = v_claim_seq_id ;
    END IF;

    IF v_copy_flag = 'Y' THEN
      -- LOCKING Parent Claim
      TTK_UTIL_PKG.reset_id_flag(v_parent_claim_seq_id||'-CLM','Y');

      OPEN claim_cur;
      FETCH claim_cur INTO claim_rec;
      CLOSE claim_cur;

      IF claim_rec.claim_number IS NULL THEN
        raise_application_error(-20187,' Cannot create Ammendment , Parent Claim is set back to confirmation state. ');
      END IF;
  

      UPDATE clm_inward A SET
        a.claim_general_type_id = claim_rec.claim_general_type_id
        WHERE a.claims_inward_seq_id = v_claims_inward_seq_id ;

      IF claim_rec.clm_status_general_type_id = 'REJ' THEN
        v_re_open_type := 'RJC';  -- RE-OPEN REJECTED
      ELSIF claim_rec.clm_status_general_type_id = 'PCO' THEN
        v_re_open_type := 'CDD';  -- RE-OPEN CLOSED
      ELSE
        v_re_open_type := 'AMC';  -- RE-OPEN CLOSED
      END IF;

      save_claim (
          v_clm_enroll_detail_seq_id  ,
          v_claim_seq_id              ,
          claim_rec.gender_general_type_id    ,
          claim_rec.member_seq_id             ,
          claim_rec.tpa_enrollment_id         ,
          claim_rec.policy_seq_id             ,
          claim_rec.policy_holder_name        ,
          claim_rec.employee_no               ,
          claim_rec.employee_name             ,
          claim_rec.mem_age                   ,
          claim_rec.claimant_name             ,
          claim_rec.date_of_inception         ,
          claim_rec.date_of_exit              ,
          claim_rec.relship_type_id           ,
          claim_rec.policy_number             ,
          claim_rec.claimant_phone_number     ,
          NULL , -- mem_total_sum_insured     ,
          claim_rec.enrol_type_id             ,
          claim_rec.policy_sub_general_type_id,
          claim_rec.phone_1                   ,
          claim_rec.policy_effective_from     ,
          claim_rec.policy_effective_to       ,
          claim_rec.ins_status_general_type_id,
          claim_rec.ins_seq_id                ,
          claim_rec.group_reg_seq_id          ,
          v_claims_inward_seq_id    ,
          v_requested_amount,
          claim_rec.pat_enroll_detail_seq_id  ,
          claim_rec.auth_number               ,
          claim_rec.request_general_type_id   ,
          claim_rec.claim_sub_general_type_id ,
          claim_rec.dom_reason_gen_type_id,----koc1285
          claim_rec.doc_cert_dom_yn,----koc1285
          claim_rec.mode_general_type_id      ,
          claim_rec.treating_dr_name          ,
          claim_rec.in_patient_no             ,
          claim_rec.claims_remarks            ,
          v_ava_sum_insured           ,
          v_ava_cum_bonus             ,
          claim_rec.date_of_admission         ,
          claim_rec.date_of_discharge         ,
          v_parent_claim_seq_id       ,
          v_clm_hosp_assoc_seq_id     ,
          claim_rec.hosp_seq_id               ,
          claim_rec.empanel_number            ,
          claim_rec.hosp_name                 ,
          claim_rec.address_1                 ,
          claim_rec.address_2                 ,
          claim_rec.address_3                 ,
          claim_rec.state_name                ,
          claim_rec.city_name                 ,
          claim_rec.pin_code                  ,
          claim_rec.off_phone_no_1            ,
          claim_rec.off_phone_no_2            ,
          claim_rec.office_fax_no             ,
          claim_rec.remarks                   ,
          claim_rec.serv_tax_rgn_number       ,
          claim_rec.prev_hosp_claim_seq_id ,
          NULL,
          claim_rec.pat_approved_amount    ,
          v_re_open_type,
          claim_rec.doctor_registration_no,
          claim_rec.email_id,
          claim_rec.notification_phone_number,
          claim_rec.ins_scheme,
          claim_rec.certificate_no,
          claim_rec.ins_customer_code,
          claim_rec.insur_ref_number ,--- insur-ref-number
		      claim_rec.pay_to_general_type_id,---opdforhs
          v_added_by                  ,
          v_rows_processed   ,
          NULL,--claim_rec.last_buffer_detail_seq_id,
          claim_rec.modification_mode_value
      );
         -- Copying rejested bills for the ammendment

         v_ctr := 0;
         FOR i IN bill_cur
         LOOP
           SELECT clm_bill_seq.NEXTVAL
             INTO v_clm_bill_seq_id FROM dual;

           INSERT INTO clm_bill_header ( clm_bill_seq_id , claim_seq_id , bill_no , bill_date  , bill_issued_by , bills_with_prescription_yn , bill_included_yn ,
             added_by , added_date )
           SELECT  v_clm_bill_seq_id , v_claim_seq_id , bill_no ,bill_date  , bill_issued_by , bills_with_prescription_yn , 'Y', -- bill_included_yn ,
             v_added_by , SYSDATE  FROM clm_bill_header WHERE clm_bill_seq_id = i.clm_bill_seq_id ;

           INSERT INTO clm_bill_details ( clm_bill_dtl_seq_id , clm_bill_seq_id , description ,
              ward_type_id ,room_type_id , number_of_days , requested_amount , allow_yn , allowed_amount , rejected_amount ,
              remarks  , discount_percnt, apply_discount_yn, ward_max_amount ,  added_by ,added_date )

           SELECT clm_bill_dtl_seq.NEXTVAL, v_clm_bill_seq_id , description ,
              ward_type_id , room_type_id , number_of_days , CASE WHEN I.bill_included_yn = 'Y' AND NVL(rejected_amount,0) > 0 THEN rejected_amount ELSE requested_amount  END , NVL(allow_yn,'N') ,
              0, CASE WHEN I.bill_included_yn = 'Y' AND NVL(rejected_amount,0) > 0 THEN rejected_amount ELSE requested_amount  END ,
              remarks  , discount_percnt, apply_discount_yn, ward_max_amount , v_added_by, SYSDATE FROM clm_bill_details
               WHERE clm_bill_seq_id = i.clm_bill_seq_id AND ( rejected_amount > 0 OR i.bill_included_yn = 'N' OR requested_amount - NVL(allowed_amount,0) > 0 );

           -- To reject ammendment for a claim which is not having any rejected amount.
           v_ctr := v_ctr + 1;
         END LOOP ;

         IF v_ctr = 0 THEN
           raise_application_error (-20161,'You cannot create an ammendment for this claim ');
         END IF;

         -- copying previous discrepency

         INSERT INTO discrepancy_information (discrepancy_seq_id ,claim_seq_id ,discrepancy_general_type_id ,resolved_yn ,remarks ,added_by ,added_date )
         SELECT discrepancy_information_seq.NEXTVAL ,v_claim_seq_id , discrepancy_general_type_id ,resolved_yn ,remarks , v_added_by , SYSDATE
           FROM discrepancy_information   WHERE claim_seq_id = v_parent_claim_seq_id ;

       --- changed to procedure do_insert_ailments
         do_insert_ailments( v_claim_seq_id , v_parent_claim_seq_id , v_added_by );
         IF claim_rec.pat_enroll_detail_seq_id IS NOT NULL THEN
           UPDATE pat_enroll_details a SET
             a.claim_id =
                 ( SELECT cc.claim_seq_id FROM clm_general_details cc
                                    WHERE cc.parent_claim_seq_id IS NULL
                                      START WITH cc.claim_seq_id = v_claim_seq_id
                                      CONNECT BY cc.claim_seq_id = PRIOR parent_claim_seq_id ),
             a.updated_by = v_added_by,
             a.updated_date = SYSDATE
             WHERE a.pat_enroll_detail_seq_id = claim_rec.pat_enroll_detail_seq_id AND
               a.claim_id IS NULL;
        END IF;
      END IF;
  END do_copy_previous_claim;
--================================================================================================================
  PROCEDURE save_inward_shortfall (
    v_shortfall_id                 IN clm_inward.shortfall_id%TYPE,
    v_claim_number                 IN clm_inward.claim_number%TYPE,
    v_added_by                     IN NUMBER,
    v_flag                         IN VARCHAR2,
    v_shortfall_seq_id             OUT shortfall_details.shortfall_seq_id%TYPE
  )
  IS

    v_rcvd_date                    DATE;
    v_status                       VARCHAR2(3);
    v_clm_status                   VARCHAR2(3);
    v_clm_seq_id                   clm_general_details.claim_seq_id%TYPE;

    CURSOR shortfall_cur (v_shortfall_id VARCHAR2, v_claim_number VARCHAR2) IS
      SELECT a.shortfall_seq_id,b.claim_seq_id,c.clm_status_general_type_id
      FROM shortfall_details a
      JOIN clm_general_details b ON (a.claim_seq_id = b.claim_seq_id )
      JOIN clm_enroll_details c ON (b.claim_seq_id = c.claim_seq_id)
      WHERE a.shortfall_id = v_shortfall_id AND b.claim_number = v_claim_number ;

  BEGIN
    OPEN shortfall_cur( v_shortfall_id, v_claim_number );
    FETCH shortfall_cur INTO v_shortfall_seq_id,v_clm_seq_id,v_clm_status ;
    CLOSE shortfall_cur;
    IF v_flag = 'UPD' THEN
      v_rcvd_date           := SYSDATE;
      v_status              := 'RES';
      v_clm_status          := 'REQ';
    ELSE
      v_status              := 'OPN';
    END IF;

    IF v_shortfall_seq_id IS NULL THEN
      raise_application_error(-20150,'Shortfall not found ');
    END IF;

  claims_freeze(v_clm_seq_id,null,'S');

    UPDATE shortfall_details a SET
          a.srtfll_status_general_type_id = v_status ,
          a.srtfll_received_date   = v_rcvd_date,
          a.updated_by             = v_added_by,
          a.updated_date           = SYSDATE
          WHERE a.shortfall_seq_id = v_shortfall_seq_id;

     IF v_clm_status='REQ' THEN
       UPDATE clm_enroll_details CE SET
        CE.clm_status_general_type_id = v_clm_status,
        CE.updated_by                 = v_added_by,
        CE.updated_date               = SYSDATE
        WHERE CE.claim_seq_id = v_clm_seq_id;
     END IF;

  END save_inward_shortfall;
--================================================================================================================
  PROCEDURE delete_claim_records (
    v_claim_seq_id                  IN OUT clm_general_details.claim_seq_id%TYPE
  )
  IS
  v_rows number(10);

  BEGIN

    DELETE FROM clm_hospital_additional_dtl a WHERE a.clm_hosp_assoc_seq_id =
               ( SELECT b.clm_hosp_assoc_seq_id  FROM clm_hospital_association b
                  WHERE b.claim_seq_id = v_claim_seq_id )  ;
    DELETE FROM clm_hospital_association b
                  WHERE b.claim_seq_id = v_claim_seq_id ;
    DELETE FROM pat_package_procedures a WHERE a.icd_pcs_seq_id IN
              ( SELECT b.icd_pcs_seq_id FROM icd_pcs_detail b  WHERE b.claim_seq_id = v_claim_seq_id );
    DELETE FROM ailment_caps a WHERE a.icd_pcs_seq_id IN
              ( SELECT b.icd_pcs_seq_id FROM icd_pcs_detail b  WHERE b.claim_seq_id = v_claim_seq_id );
    DELETE FROM icd_pcs_detail b  WHERE b.claim_seq_id = v_claim_seq_id ;
	DELETE FROM tpa_diagnosys_details d WHERE d.claim_seq_id = v_claim_seq_id;--koc decoupling    
    DELETE FROM ailment_details a WHERE a.claim_seq_id = v_claim_seq_id ;
    DELETE FROM clm_bill_details a WHERE a.clm_bill_seq_id IN ( SELECT b.clm_bill_seq_id
                                                                  FROM clm_bill_header b
                                                                 WHERE b.claim_seq_id = v_claim_seq_id );
    DELETE FROM clm_bill_header b WHERE b.claim_seq_id = v_claim_seq_id ;
    DELETE FROM discrepancy_information WHERE claim_seq_id = v_claim_seq_id ;
    DELETE FROM clm_discharge_voucher a WHERE a.claim_seq_id = v_claim_seq_id;
    DELETE FROM associated_illness  a WHERE a.claim_seq_id = v_claim_seq_id ;
    DELETE FROM clm_enroll_details a WHERE a.claim_seq_id = v_claim_seq_id ;
    DELETE FROM clm_general_details a WHERE a.claim_seq_id = v_claim_seq_id ;
    unassoc_claim_intimation(v_claim_seq_id,null,1,v_rows); --KOC1349

    v_claim_seq_id := NULL;

  END delete_claim_records;

--================================================================================================================
  PROCEDURE save_inward_claim (
    v_claim_seq_id                       IN OUT clm_general_details.claim_seq_id%TYPE,
    v_claims_inward_seq_id               IN clm_general_details.claims_inward_seq_id%TYPE,
    v_mode_general_type_id               IN clm_general_details.mode_general_type_id%TYPE,
    v_requested_amount                   IN clm_general_details.requested_amount%TYPE  ,
    v_clm_enroll_detail_seq_id           IN OUT clm_enroll_details.clm_enroll_detail_seq_id%TYPE,
    v_member_seq_id                      IN clm_enroll_details.member_seq_id%TYPE,
    v_tpa_enrollment_id                  IN clm_enroll_details.tpa_enrollment_id%TYPE ,
    v_claimant_name                      IN clm_enroll_details.claimant_name%TYPE,
    v_policy_holder_name                 IN clm_enroll_details.policy_holder_name%TYPE,
    v_employee_name                      IN clm_enroll_details.employee_name%TYPE,
    v_employee_no                        IN clm_enroll_details.employee_no%TYPE,
    v_policy_number                      IN clm_enroll_details.policy_number%TYPE,
    v_policy_seq_id                      IN clm_enroll_details.policy_seq_id%TYPE,
    v_tpa_office_seq_id                   IN CLM_INWARD.tpa_office_seq_id%TYPE,
    v_document_general_type_id           IN CLM_INWARD.document_general_type_id%TYPE,
    v_email_id                           IN CLM_ENROLL_DETAILS.email_id%TYPE,
    v_notification_phone_number          IN CLM_ENROLL_DETAILS.notification_phone_number%TYPE,
    v_ins_scheme                     IN CLM_ENROLL_DETAILS.ins_scheme%TYPE,
    v_certificate_no                 IN CLM_ENROLL_DETAILS.certificate_no%TYPE,
    v_ins_customer_code              IN CLM_ENROLL_DETAILS.ins_customer_code%TYPE,
    v_added_by                           IN NUMBER,
    v_rows_processed                     OUT NUMBER
  )
  IS

    CURSOR event_cur IS SELECT a.event_seq_id , a.simple_review_count
      FROM tpa_event A JOIN tpa_workflow B ON (a.workflow_seq_id = b.workflow_seq_id )
      WHERE b.sub_general_type_id = 'CLM' AND A.order_number = 1;
    v_event_seq_id                   clm_general_details.event_seq_id%TYPE;
    v_required_review_count          clm_general_details.required_review_count%TYPE;
    v_claim_number                   clm_general_details.claim_number%TYPE;

    v_policy_tpa_office_seq_id       tpa_enr_policy.tpa_office_seq_id%TYPE;

  BEGIN

    IF NVL(v_claim_seq_id,0) = 0 THEN
      OPEN event_cur;
      FETCH event_cur INTO v_event_seq_id , v_required_review_count;
      CLOSE event_cur;

      IF v_policy_seq_id IS NOT NULL THEN -- Getting tpa_officeseq_id  of the policy
        SELECT a.tpa_office_seq_id INTO v_policy_tpa_office_seq_id
           FROM tpa_enr_policy a WHERE a.policy_seq_id = v_policy_seq_id ;
      ELSE
        v_policy_tpa_office_seq_id   := v_tpa_office_seq_id ;
      END IF;

      v_claim_number      := PRE_AUTH_PKG.generate_id_numbers('CL', v_policy_tpa_office_seq_id , NULL, v_added_by);

      INSERT INTO clm_general_details (
            claim_seq_id , claims_inward_seq_id , claim_number ,  requested_amount , mode_general_type_id,
            completed_yn , event_seq_id, review_count, required_review_count ,  entered_date , discrepancy_present_yn , re_open_type ,co_payment_amount,  added_by , added_date )
      VALUES(
            clm_claim_seq.NEXTVAL ,   v_claims_inward_seq_id ,  v_claim_number , v_requested_amount , v_mode_general_type_id ,
            'N', v_event_seq_id, 1, v_required_review_count , SYSDATE, 'N','ORC',0, v_added_by,  SYSDATE ) RETURNING claim_seq_id INTO v_claim_seq_id;


      INSERT INTO associated_illness (
            assoc_seq_id , claim_seq_id  , assoc_ill_general_type_id ,  assoc_ill_present_yn ,
            assoc_duration_general_type_id , added_by , added_date )
      SELECT associated_illness_seq.NEXTVAL , v_claim_seq_id , assoc_ill_general_type_id , 'N' ,
            'DTD' ,v_added_by ,SYSDATE FROM (SELECT  general_type_id assoc_ill_general_type_id
                                       FROM tpa_general_code
                                      WHERE header_type = 'ASSOCIATED_ILLNESS' ORDER BY sort_no);
    ELSE
             UPDATE clm_general_details SET
               mode_general_type_id = v_mode_general_type_id,
               requested_amount     = v_requested_amount,
               updated_by           = v_added_by,
               updated_date         = SYSDATE
               WHERE claim_seq_id   = v_claim_seq_id;

    END IF;
             -- Saving enroll details
    set_save_enroll(   v_clm_enroll_detail_seq_id ,
                        v_claim_seq_id,
                        v_member_seq_id ,
                        v_tpa_enrollment_id,
                        v_claimant_name,
                        v_policy_holder_name,
                        v_employee_name,
                        v_employee_no ,
                        v_policy_number ,
                        v_policy_seq_id,
                        v_email_id ,
                        v_notification_phone_number ,
                        v_ins_scheme ,
                        v_certificate_no,
                        v_ins_customer_code,
                        v_added_by,
                        v_rows_processed );

  END save_inward_claim;
 --==============================================================================================
 --   Name       : SAVE_CLAIMS_PAYMENT
 --   Created on : -18-AUG-06
 --   Created By : - CSPRAKASH
 --   Modified by : S.V.Sreeraj ON 25-JAN2007
 --   Comments   :
 --==============================================================================================

  -- called from set_review.
  PROCEDURE save_claims_payment (
    v_claim_seq_id                       IN  TPA_CLAIMS_PAYMENT.claim_seq_id%TYPE,
    v_status                             IN  TPA_CLAIMS_PAYMENT.claim_payment_status%TYPE,
    v_enrol_type_id                      IN  TPA_ENR_POLICY.enrol_type_id%TYPE,
    v_policy_seq_id                      IN  TPA_ENR_POLICY.Policy_Seq_Id%TYPE,
    v_member_seq_id                      IN  TPA_ENR_POLICY_MEMBER.Member_Seq_Id%TYPE,
    v_claim_general_type_id              IN  clm_inward.claim_general_type_id%TYPE,
    v_added_by                           IN  TPA_CLAIMS_PAYMENT.added_by%TYPE
  )
  IS

  -- If the Claim is NHCP
   CURSOR cur_get_nhcp ( v_claim_seq_id NUMBER ) IS
    SELECT CASE WHEN a.issue_cheques_type_id = 'HOS' THEN b.hosp_name ELSE a.management_name END AS payee_name,
         P.address_1,
         P.address_2,
         P.address_3,
         d.state_name,
         e.city_description,
         f.country_name AS country,
         P.pin_code,
         b.off_phone_no_1,
         b.office_fax_no fax_no,
         a.issue_cheques_type_id AS issue_cheques_type_id ,
         b.hosp_seq_id
    FROM tpa_hosp_account_details a JOIN tpa_hosp_info b ON (a.hosp_seq_id = b.hosp_seq_id)
         JOIN clm_hospital_association c ON (b.hosp_seq_id = c.hosp_seq_id)
         JOIN tpa_hosp_address P ON (b.hosp_seq_id = p.hosp_seq_id)
         LEFT OUTER JOIN tpa_state_code d ON ( p.state_type_id = d.state_type_id )
         LEFT OUTER JOIN tpa_city_code e ON ( p.city_type_id = e.city_type_id )
         LEFT OUTER JOIN tpa_country_code f ON (p.country_id = f.country_id)
         WHERE c.claim_seq_id = v_claim_seq_id;

 --opdforhs
   CURSOR cur_get_hcu ( v_claim_seq_id NUMBER ) IS
    SELECT CASE WHEN a.hcu_pay_to_general_type = 'TPA' THEN a.tpa_name  END AS payee_name,
         P.address_1,
         P.address_2,
         P.address_3,
         d.state_name,
         e.city_description,
         f.country_name AS country,
         P.pin_code,
         i.off_phone_no_1,
         i.office_fax_no_1 fax_no,
         a.hcu_pay_to_general_type AS issue_cheques_type_id ,
         null as hosp_seq_id
    FROM tpa_enr_policy a JOIN clm_enroll_details b ON (a.policy_seq_id = b.policy_seq_id)
         JOIN clm_general_details c ON (b.claim_seq_id = c.claim_seq_id)
         JOIN tpa_office_info i ON (i.tpa_office_seq_id=a.tpa_office_seq_id)
         JOIN tpa_address P ON (i.tpa_office_seq_id = p.tpa_office_seq_id)
         LEFT OUTER JOIN tpa_state_code d ON ( p.state_type_id = d.state_type_id )
         LEFT OUTER JOIN tpa_city_code e ON ( p.city_type_id = e.city_type_id )
         LEFT OUTER JOIN tpa_country_code f ON (p.country_id = f.country_id)
         WHERE c.claim_seq_id = v_claim_seq_id;

   CURSOR clm_subtype_cur( v_claim_seq_id NUMBER ) IS SELECT
   gd.claim_sub_general_type_id,gd.pay_to_general_type_id as pay_to,ha.hosp_seq_id,
   ep.hcu_pay_to_general_type as hcu_pay_to_type
   FROM clm_general_details gd
   JOIN clm_enroll_details ed on (ed.claim_seq_id=gd.claim_seq_id)
   JOIN tpa_enr_policy ep on (ep.policy_seq_id=ed.policy_seq_id)
   LEFT OUTER JOIN clm_hospital_association ha on (gd.claim_seq_id=ha.claim_seq_id)
   WHERE gd.claim_seq_id = v_claim_seq_id;
   sub_type_rec   clm_subtype_cur%rowtype;
 --opdforhs
  -- If the Claim is MR Individual, Individual as Group, Non-Corporate
  CURSOR cur_get_mr_individual IS
    SELECT b.insured_name payee_name, P.address_1, P.address_2,  P.address_3, F.state_name, P.city_type_id city_description,
         g.country_name AS country,   P.pin_code,   P.off_phone_no_1,   P.fax_no ,
         NULL AS issue_cheques_type_id , NULL AS hosp_seq_id
         FROM tpa_enr_policy a JOIN tpa_enr_policy_group b ON (a.policy_seq_id = b.policy_seq_id)
         JOIN tpa_enr_policy_member c ON (b.policy_group_seq_id = c.policy_group_seq_id)
         JOIN tpa_enr_mem_address P ON (b.enr_address_seq_id = p.enr_address_seq_id)
         LEFT OUTER JOIN tpa_state_code F ON ( P.state_type_id = f.state_type_id )
         LEFT OUTER JOIN tpa_country_code g ON ( p.country_id = g.country_id )
         WHERE a.policy_seq_id = v_policy_seq_id  AND c.member_seq_id  = v_member_seq_id ;

  CURSOR cur_get_mr_location IS
    SELECT CASE WHEN g.group_reg_seq_id IS NULL THEN B.group_name ELSE r.group_name END AS payee_name ,
         CASE WHEN g.group_reg_seq_id IS NULL THEN P.address_1 ELSE m.address_1 END AS address_1 ,
         CASE WHEN g.group_reg_seq_id IS NULL THEN P.address_2 ELSE m.address_2 END AS address_2 ,
         CASE WHEN g.group_reg_seq_id IS NULL THEN P.address_3 ELSE m.address_3 END AS address_3 ,
         CASE WHEN g.group_reg_seq_id IS NULL THEN F.state_name ELSE n.state_name END AS state_name ,
         CASE WHEN g.group_reg_seq_id IS NULL THEN C.city_description ELSE o.city_description END AS city_description ,
         CASE WHEN g.group_reg_seq_id IS NULL THEN aa.country_name ELSE bb.country_name END AS country ,
         CASE WHEN g.group_reg_seq_id IS NULL THEN P.pin_code ELSE m.pin_code END AS pin_code ,
         CASE WHEN g.group_reg_seq_id IS NULL THEN B.office_number ELSE r.office_number END AS off_phone_no_1 ,
         NULL fax_no,
         NULL AS issue_cheques_type_id , NULL AS hosp_seq_id
         FROM tpa_enr_policy a JOIN tpa_enr_policy_group g ON (a.policy_seq_id = g.policy_seq_id)
         JOIN tpa_enr_policy_member H ON (g.policy_group_seq_id = h.policy_group_seq_id)
         LEFT OUTER JOIN tpa_group_registration r ON ( g.group_reg_seq_id = r.group_reg_seq_id )
         LEFT OUTER JOIN tpa_group_registration b ON ( a.group_reg_seq_id = b.group_reg_seq_id )
         LEFT OUTER JOIN tpa_address P ON (b.group_reg_seq_id = p.group_reg_seq_id)
         LEFT OUTER JOIN tpa_state_code F ON ( P.state_type_id = f.state_type_id )
         LEFT OUTER JOIN tpa_city_code C ON ( C.city_type_id = P.city_type_id )
         LEFT OUTER JOIN tpa_country_code aa ON ( p.country_id = aa.country_id )
         LEFT OUTER JOIN tpa_address m ON (r.group_reg_seq_id = m.group_reg_seq_id)
         LEFT OUTER JOIN tpa_state_code n ON ( m.state_type_id = n.state_type_id )
         LEFT OUTER JOIN tpa_city_code o ON ( m.city_type_id = o.city_type_id )
         LEFT OUTER JOIN tpa_country_code bb ON ( m.country_id = bb.country_id )
         WHERE h.member_seq_id = v_member_seq_id;


   -- If the claim is from the corporate
    CURSOR cur_get_policy_cheque IS
     SELECT a.tpa_cheque_issued_general_type
      FROM tpa_enr_policy a  WHERE  a.policy_seq_id = v_policy_seq_id  ;

     -- Cheque to be issued in the name of the corporate
     CURSOR cur_get_corporate_info IS
         SELECT B.group_name AS payee_name,  P.address_1,  P.address_2,   P.address_3,  F.state_name,  C.city_description,
           aa.country_name AS country,     P.pin_code,   B.office_number off_phone_no_1,  NULL fax_no,
           NULL AS issue_cheques_type_id , NULL AS hosp_seq_id
           FROM tpa_enr_policy a JOIN tpa_group_registration b ON (a.group_reg_seq_id = b.group_reg_seq_id)
           JOIN tpa_address P ON (b.group_reg_seq_id = p.group_reg_seq_id)
           LEFT OUTER JOIN tpa_state_code F ON ( P.state_type_id = f.state_type_id )
           LEFT OUTER JOIN tpa_city_code C ON ( C.city_type_id = P.city_type_id )
           LEFT OUTER JOIN tpa_country_code aa ON ( p.country_id = aa.country_id )
           WHERE a.policy_seq_id  = v_policy_seq_id ;


       rule_rec_payee  cur_get_nhcp%ROWTYPE;
       v_cheque_issue  VARCHAR2( 3 );

  BEGIN

	    OPEN clm_subtype_cur(v_claim_seq_id);
        FETCH clm_subtype_cur INTO sub_type_rec;
        CLOSE clm_subtype_cur;
      IF  v_claim_general_type_id = 'CNH'  THEN  -- NETWORK CLAIM
          OPEN   cur_get_nhcp ( v_claim_seq_id );
          FETCH  cur_get_nhcp INTO rule_rec_payee ;
          CLOSE  cur_get_nhcp;
          IF rule_rec_payee.payee_name IS NULL OR rule_rec_payee.address_1 IS NULL THEN
            raise_application_error(-20176, 'Please correct hospital address before completing the Claim ');
          END IF;
       ELSIF  v_claim_general_type_id = 'CTM'  THEN -- MEMBER CLAIM
          IF sub_type_rec.claim_sub_general_type_id='OPD' AND sub_type_rec.pay_to='HSL' THEN
            OPEN   cur_get_nhcp ( v_claim_seq_id );
            FETCH  cur_get_nhcp INTO rule_rec_payee ;
            CLOSE  cur_get_nhcp;
            IF rule_rec_payee.payee_name IS NULL OR rule_rec_payee.address_1 IS NULL THEN
            raise_application_error(-20176, 'Please correct hospital address before completing the Claim ');
            END IF;
          ELSIF sub_type_rec.claim_sub_general_type_id='HCU' AND sub_type_rec.hcu_pay_to_type='TPA' THEN
            OPEN   cur_get_hcu ( v_claim_seq_id );
            FETCH  cur_get_hcu INTO rule_rec_payee ;
            CLOSE  cur_get_hcu;
          ELSIF v_enrol_type_id IN  ('IND','ING','NCR') THEN
            OPEN  cur_get_mr_individual ;
            FETCH cur_get_mr_individual INTO rule_rec_payee ;
            CLOSE cur_get_mr_individual;

            IF rule_rec_payee.payee_name IS NULL OR rule_rec_payee.address_1 IS NULL THEN
              raise_application_error(-20177, 'Please correct payee address before completing the Claim ');
            END IF;

          ELSIF  v_enrol_type_id = 'COR' THEN
            OPEN cur_get_policy_cheque;
            FETCH cur_get_policy_cheque INTO v_cheque_issue;
            CLOSE cur_get_policy_cheque;

            -- issue cheques to Corporate
            IF v_cheque_issue = 'IQC' THEN
              OPEN cur_get_corporate_info;
              FETCH  cur_get_corporate_info INTO rule_rec_payee ;
              CLOSE cur_get_corporate_info;
              IF rule_rec_payee.payee_name IS NULL OR rule_rec_payee.address_1 IS NULL THEN
                raise_application_error(-20178, 'Please correct corporate address before completing the Claim ');
              END IF;
            ELSIF  v_cheque_issue = 'IQI'  THEN -- issue cheques to Individual
              OPEN cur_get_mr_individual ;
              FETCH  cur_get_mr_individual INTO rule_rec_payee ;
              CLOSE cur_get_mr_individual;
              IF rule_rec_payee.payee_name IS NULL OR rule_rec_payee.address_1 IS NULL THEN
                raise_application_error(-20177, 'Please correct payee address before completing the Claim ');
              END IF;
            ELSIF  v_cheque_issue = 'IQL'  THEN -- issue cheques to Individual
              OPEN cur_get_mr_location ;
              FETCH  cur_get_mr_location INTO rule_rec_payee ;
              CLOSE cur_get_mr_location;
              IF rule_rec_payee.payee_name IS NULL OR rule_rec_payee.address_1 IS NULL THEN
                raise_application_error(-20177, 'Please correct payee address before completing the Claim ');
              END IF;
            END IF;
          END IF;
       END IF;

      INSERT INTO tpa_claims_payment (
        payment_seq_id,
        claim_settlement_no,
        claim_payment_status,
        claim_amount,
        claim_type,
        claim_aprv_date,
        approved_amount,
        ins_seq_id,
        deleted_yn,
        policy_seq_id,
        member_seq_id,
        group_reg_seq_id,
        address1,
        address2,
        address3,
        state ,
        city ,
        pincode ,
        country,
        email_id ,
        phone1,
        phone2,
        home_phone,
        mob_num,
        fax_no,
        enrol_type_id,
        claim_seq_id,
        claim_file_number,
        added_by,
        added_date,
        payee_name ,
        tpa_cheque_issued_general_type,
        hosp_seq_id,
        tpa_nhcp_cheques_issued_to  )
    SELECT
      tpa_claims_payment_seq.NEXTVAL ,
      a.claim_settlement_number ,
      v_status,
      a.requested_amount,
      C.claim_general_type_id,
      b.decision_date,
      a.total_app_amount,
      b.ins_seq_id,
      'N',
      b.policy_seq_id,
      b.member_seq_id,
      CASE WHEN v_cheque_issue = 'IQL' THEN NVL(X.group_reg_seq_id,b.group_reg_seq_id) ELSE b.group_reg_seq_id END,
      rule_rec_payee.Address_1,
      rule_rec_PAYEE.Address_2,
      rule_rec_payee.Address_3,
      rule_rec_payee.State_Name,
      rule_rec_payee.CITY_DESCRIPTION,
      rule_rec_payee.Pin_Code,
      rule_rec_payee.country,
      NULL email_id ,
      rule_rec_payee.Off_Phone_No_1,
      NULL off_phone_no_2,
      NULL res_phone_no,
      NULL mobile_no,
      rule_rec_payee.Fax_No,
      b.enrol_type_id ,
      a.claim_seq_id,
      a.claim_file_number,
      v_added_by,
      SYSDATE,
     -- rule_rec_payee.Payee_Name,
     ttk_util_pkg.fn_encrypt(rule_rec_payee.Payee_Name), --//ED
      v_cheque_issue,
      CASE WHEN sub_type_rec.claim_sub_general_type_id='OPD' AND sub_type_rec.pay_to='HSL' THEN--opdforhs
         sub_type_rec.hosp_seq_id ELSE rule_rec_payee.hosp_seq_id end,
      rule_rec_payee.issue_cheques_type_id
      FROM clm_general_details A JOIN clm_enroll_details b ON ( a.claim_seq_id = b.claim_seq_id )
      JOIN clm_inward C ON ( a.claims_inward_seq_id = c.claims_inward_seq_id )
      JOIN tpa_enr_policy_member D ON ( b.member_seq_id = d.member_seq_id )
      JOIN tpa_enr_policy_group X ON (d.policy_group_seq_id = X.policy_group_seq_id )
      LEFT OUTER JOIN tpa_general_code K ON ( C.claim_general_type_id = K.general_type_id )
   WHERE a.claim_seq_id = v_claim_seq_id ;

  END save_claims_payment;
-- =================================================================================================================
   PROCEDURE select_intimation_list ( --KOC1349
    v_member_seq_id                      IN  tpa_call_log.member_seq_id%TYPE,
    v_hosp_name                          IN  tpa_hosp_info.hosp_name%TYPE,
    v_start_date                         IN  VARCHAR2,
    v_end_date                           IN  VARCHAR2,
    v_added_by                           IN  NUMBER,
    v_sort_var                           IN  VARCHAR2,
    v_sort_order                         IN  VARCHAR2,
    v_start_num                          IN  NUMBER  ,
    v_end_num                            IN  NUMBER ,
    v_resultset                          OUT SYS_REFCURSOR
  )
  IS
    v_sql_str                         VARCHAR2(4000);
    v_ctr                             NUMBER(10);
    v_pol_seq_id                      tpa_enr_policy.policy_seq_id%TYPE;

  BEGIN

     SELECT COUNT(1) INTO v_ctr
     FROM tpa_enr_policy_member f
     JOIN tpa_enr_policy_group g ON (f.policy_group_seq_id=g.policy_group_seq_id)
     JOIN tpa_enr_policy h ON (g.policy_seq_id=h.policy_seq_id)
     WHERE f.member_seq_id= v_member_seq_id and h.enrol_type_id='IND';

     IF v_ctr=0 THEN
    v_sql_str :=
     ' SELECT
       a.call_log_seq_id,
       a.claim_intimation_seq_id,
       a.estimated_amount,
       a.intimation_generated_date as intimation_date,
       a.ailment_description ,
       a.hospital_name AS hosp_name ,
       a.hospital_address AS hosp_address,
       a.likely_date_of_hospitalisation,
       account_info_pkg.get_gen_desc(b.call_rcvd_thru_general_type_id,''G'') as source_from, --for sms
       CASE WHEN b.call_rcvd_thru_general_type_id=''CSM'' THEN NVL(A.patient_name,b.claimant_name) ELSE b.claimant_name END patient_name --for sms
       FROM tpa_call_claim_intimation A JOIN tpa_call_log B ON ( a.call_log_seq_id = b.call_log_seq_id )
       WHERE b.member_seq_id = :v_member_seq_id AND b.call_recorded_date >= NVL(:v_start_date, b.call_recorded_date )
       AND b.call_recorded_date <= NVL( :v_end_date,b.call_recorded_date ) and A.intimation_submitted_yn=''Y'' ';

    v_sql_str := ' SELECT * FROM
        (SELECT A.*,DENSE_RANK() OVER (ORDER BY '||v_sort_var||' '||v_sort_order||',ROWNUM)
        Q FROM (' ||v_sql_str|| ') A ) WHERE  Q>= :v_start_num AND Q<= :v_end_num ';

    OPEN v_resultset FOR v_sql_str USING v_member_seq_id, TO_DATE(v_start_date,'DD/MM/YYYY'), TO_DATE(v_end_date,'DD/MM/YYYY'),v_start_num, v_end_num ;

   ELSE
     SELECT h.policy_seq_id INTO v_pol_seq_id
     FROM tpa_enr_policy_member f
     JOIN tpa_enr_policy_group g ON (f.policy_group_seq_id=g.policy_group_seq_id)
     JOIN tpa_enr_policy h ON (g.policy_seq_id=h.policy_seq_id)
     WHERE f.member_seq_id= v_member_seq_id and h.enrol_type_id='IND';

    v_sql_str :=
     ' SELECT
       a.call_log_seq_id,
       a.claim_intimation_seq_id,
       a.estimated_amount,
       a.intimation_generated_date as intimation_date,
       a.ailment_description ,
       a.hospital_name AS hosp_name ,
       a.hospital_address AS hosp_address,
       a.likely_date_of_hospitalisation,
       account_info_pkg.get_gen_desc(b.call_rcvd_thru_general_type_id,''G'') as source_from, --for sms
       CASE WHEN b.call_rcvd_thru_general_type_id=''CSM'' THEN NVL(A.patient_name,b.claimant_name) ELSE b.claimant_name END patient_name --for sms
       FROM tpa_call_claim_intimation A JOIN tpa_call_log B ON ( a.call_log_seq_id = b.call_log_seq_id )
       WHERE b.policy_seq_id = :v_pol_seq_id AND a.claim_seq_id IS NULL AND b.call_recorded_date >= NVL(:v_start_date, b.call_recorded_date )
       AND b.call_recorded_date <= NVL( :v_end_date,b.call_recorded_date ) and A.intimation_submitted_yn=''Y'' ';

    v_sql_str := ' SELECT * FROM
        (SELECT A.*,DENSE_RANK() OVER (ORDER BY '||v_sort_var||' '||v_sort_order||',ROWNUM)
        Q FROM (' ||v_sql_str|| ') A ) WHERE  Q>= :v_start_num AND Q<= :v_end_num ';
    OPEN v_resultset FOR v_sql_str USING v_pol_seq_id, TO_DATE(v_start_date,'DD/MM/YYYY'), TO_DATE(v_end_date,'DD/MM/YYYY'),v_start_num, v_end_num ;
  END IF;

  END select_intimation_list ;
-- =================================================================================================================
  PROCEDURE select_intimation (--KOC1349
    v_claim_seq_id                    IN  clm_general_details.claim_seq_id%TYPE,
    v_added_by                        IN  NUMBER,
    v_resultset                       OUT SYS_REFCURSOR
  )
  IS
  BEGIN
    OPEN v_resultset FOR
     SELECT
     a.claim_seq_id,
     b.call_log_seq_id,
     c.claim_intimation_seq_id,
     c.estimated_amount,
     c.ailment_description,
     c.hospital_name AS hosp_name ,
     c.hospital_address AS hosp_address,
     b.call_recorded_date AS intimation_date,
     c.likely_date_of_hospitalisation,
     app.account_info_pkg.get_gen_desc(b.call_rcvd_thru_general_type_id,'G') as source_from, --for sms
     CASE WHEN b.call_rcvd_thru_general_type_id='CSM' THEN NVL(c.patient_name,b.claimant_name) ELSE b.claimant_name END patient_name --for sms
     FROM clm_general_details A JOIN tpa_call_log b ON ( a.call_log_seq_id = b.call_log_seq_id )
     JOIN tpa_call_claim_intimation C ON (b.call_log_seq_id = c.call_log_seq_id )
     LEFT OUTER JOIN tpa_hosp_info d ON ( b.hosp_seq_id = d.hosp_seq_id )
     LEFT OUTER JOIN tpa_hosp_address E ON ( d.hosp_seq_id = e.hosp_seq_id )
     LEFT OUTER JOIN tpa_city_code F ON (e.city_type_id = f.city_type_id )
     LEFT OUTER JOIN tpa_state_code G ON (e.state_type_id = g.state_type_id )
     WHERE a.claim_seq_id = v_claim_seq_id ;

  END select_intimation ;
-- =================================================================================================================
  PROCEDURE assoc_claim_intimation (--KOC1349
    v_claim_seq_id                       IN  clm_general_details.claim_seq_id%TYPE,
    v_call_log_seq_id                    IN  tpa_call_log.call_log_seq_id%TYPE,
    v_added_by                           IN  CLM_GENERAL_DETAILS.added_by%TYPE,
    v_rows_processed                     IN  OUT NUMBER
  )
  IS
  BEGIN
    claims_freeze(v_claim_seq_id,NULL,'S');--KOCBJJ

    pre_auth_pkg.reassign_user (  NULL , v_claim_seq_id , NULL , v_added_by , 'AUT');
    pre_auth_pkg.check_clm_completed(v_claim_seq_id ,NULL,'APR',v_added_by );
    UPDATE clm_general_details a SET
       a.call_log_seq_id  = v_call_log_seq_id ,
       a.updated_by       = v_added_by ,
       a.updated_date     = SYSDATE
       WHERE a.claim_seq_id  = v_claim_seq_id ;

    UPDATE tpa_call_claim_intimation b SET --to override the old intimation
              b.claim_seq_id    = NULL
        WHERE b.claim_seq_id    = v_claim_seq_id ;

    UPDATE tpa_call_claim_intimation b SET
        b.claim_seq_id    = v_claim_seq_id
        WHERE b.call_log_seq_id=v_call_log_seq_id;
    v_rows_processed := SQL%ROWCOUNT;
    claims_freeze(v_claim_seq_id,NULL,'S');--KOCBJJ

    COMMIT;
  END assoc_claim_intimation;
-- =================================================================================================================
  PROCEDURE do_insert_ailments(
    v_claim_seq_id               IN clm_general_details.claim_seq_id%TYPE,
    v_parent_claim_seq_id        IN clm_general_details.claim_seq_id%TYPE,
    v_added_by                   IN NUMBER
  )
  IS
    v_icd_pcs_seq_id             icd_pcs_detail.icd_pcs_seq_id%TYPE;
  BEGIN
    IF v_parent_claim_seq_id IS NOT NULL THEN

      INSERT INTO associated_illness (
        assoc_seq_id , claim_seq_id  , assoc_ill_general_type_id ,  assoc_ill_present_yn ,
        assoc_duration_general_type_id , added_by , added_date )
      SELECT associated_illness_seq.NEXTVAL , v_claim_seq_id , assoc_ill_general_type_id ,
        assoc_ill_present_yn , assoc_duration_general_type_id ,v_added_by, SYSDATE
        FROM associated_illness WHERE claim_seq_id  = v_parent_claim_seq_id  ;

       INSERT INTO ailment_details (ailment_details_seq_id , claim_seq_id ,ailment_description ,specialty_general_type_id ,surgery_general_type_id,
                                   ailment_duration , pat_duration_general_type_id , clinical_findings , provisional_diagnosis ,
                                   related_to_previous_illness_yn , trtmnt_plan_general_type_id  , investigation_reports , line_of_treatment ,
                                   duration_of_hospitalization , doctor_opinion ,disability_general_type_id ,discharge_cond_general_type_id ,doctor_opinion_by ,
                                   claim_file_number, advice_to_patient,medicine_general_type_id ,ailment_clm_general_type_id ,mat_general_type_id,children_during_mat,  added_by , added_date )
         SELECT  ailment_details_seq.NEXTVAL , v_claim_seq_id ,ailment_description ,specialty_general_type_id ,surgery_general_type_id,
                                   ailment_duration , pat_duration_general_type_id , clinical_findings , provisional_diagnosis ,
                                   related_to_previous_illness_yn , trtmnt_plan_general_type_id  , investigation_reports , line_of_treatment ,
                                   duration_of_hospitalization , doctor_opinion , disability_general_type_id ,discharge_cond_general_type_id ,doctor_opinion_by ,
                                   claim_file_number, advice_to_patient ,medicine_general_type_id ,ailment_clm_general_type_id,mat_general_type_id,children_during_mat, v_added_by , SYSDATE
          FROM ailment_details WHERE claim_seq_id  = v_parent_claim_seq_id  ;

--koc decoupling
    INSERT INTO TPA_DIAGNOSYS_DETAILS (diagnosys_seq_id,diagnosys_name,claim_seq_id,added_by,added_date,primary_ailment_yn,
         secondary_ailment_yn,comorb_ailment_yn,hospital_general_type_id,trtmnt_plan_general_type_id,
         tariff_general_type_id,frequency_of_visit,pat_duration_general_type_id,no_of_visits,pkg_seq_id)
         SELECT tpa_clm_diag_seq.NEXTVAL,d.diagnosys_name,v_claim_seq_id,v_added_by,sysdate,d.primary_ailment_yn,
         d.secondary_ailment_yn,d.comorb_ailment_yn,d.hospital_general_type_id,d.trtmnt_plan_general_type_id,
         d.tariff_general_type_id,d.frequency_of_visit,d.pat_duration_general_type_id,d.no_of_visits,d.pkg_seq_id
          FROM app.tpa_diagnosys_details d WHERE d.claim_seq_id = v_parent_claim_seq_id;
--koc decoupling

      --Copying ICD_PCS_DETAIL
      FOR I IN (SELECT d.diagnosys_seq_id  diag_seq_id,i.*
           FROM icd_pcs_detail i LEFT OUTER JOIN tpa_diagnosys_details dd on ( dd.diagnosys_seq_id = i.diagnosys_seq_id )
          LEFT OUTER join tpa_diagnosys_details d on ( d.diagnosys_name = dd.diagnosys_name and d.claim_seq_id = v_claim_seq_id )
                 WHERE i.claim_seq_id = v_parent_claim_seq_id)
      LOOP
            INSERT INTO icd_pcs_detail (icd_pcs_seq_id, claim_seq_id,ped_code_id,other_desc,icd_code,
                 primary_ailment_yn,hospital_general_type_id ,trtmnt_plan_general_type_id ,tariff_general_type_id ,
                 frequency_of_visit , pat_duration_general_type_id ,no_of_visits ,claim_file_number,
                 added_by, added_date,diagnosys_seq_id,secondary_ailment_yn,comorb_ailment_yn)  --koc decoupling
             VALUES( icd_pcs_detail_seq.NEXTVAL , v_claim_seq_id, I.ped_code_id, I.other_desc, I.icd_code,
                 I.primary_ailment_yn, I.hospital_general_type_id ,I.trtmnt_plan_general_type_id , I.tariff_general_type_id ,
                 I.frequency_of_visit , I.pat_duration_general_type_id , I.no_of_visits ,I.claim_file_number,
                  v_added_by, SYSDATE,i.diag_seq_id,i.secondary_ailment_yn,i.comorb_ailment_yn) --koc decoupling
                 RETURNING icd_pcs_seq_id INTO v_icd_pcs_seq_id;

            INSERT INTO pat_package_procedures ( pat_proc_seq_id , icd_pcs_seq_id , pkg_seq_id , proc_seq_id ,
              procedure_amount,  added_by , added_date )
            SELECT pat_package_procedures_seq.NEXTVAL , v_icd_pcs_seq_id , pkg_seq_id , proc_seq_id ,
              /*procedure_amount*/NULL,  v_added_by , SYSDATE
                 FROM pat_package_procedures WHERE icd_pcs_seq_id = i.icd_pcs_seq_id ;

      END LOOP;
    ELSE
      INSERT INTO associated_illness (
            assoc_seq_id , claim_seq_id  , assoc_ill_general_type_id ,  assoc_ill_present_yn ,
            assoc_duration_general_type_id , added_by , added_date )
      SELECT associated_illness_seq.NEXTVAL , v_claim_seq_id , assoc_ill_general_type_id , 'N' ,
            'DTD' ,v_added_by ,SYSDATE FROM (SELECT  general_type_id assoc_ill_general_type_id
                                       FROM tpa_general_code
                                      WHERE header_type = 'ASSOCIATED_ILLNESS' ORDER BY sort_no);
    END IF;
  END do_insert_ailments;
-- =================================================================================================================
  PROCEDURE validate_bill_date (
    v_claim_seq_id               IN clm_general_details.claim_seq_id%TYPE,
    v_bill_date                  IN clm_bill_header.bill_date%TYPE
  )
  IS
    CURSOR pol_cur IS SELECT a.date_of_inception , a.date_of_exit
      FROM clm_enroll_details a  WHERE a.claim_seq_id = v_claim_seq_id;

    v_date_of_inception          tpa_enr_policy_member.date_of_inception%TYPE;
    v_date_of_exit               tpa_enr_policy_member.date_of_exit%TYPE;

  BEGIN
    OPEN pol_cur;
    FETCH pol_cur INTO v_date_of_inception, v_date_of_exit ;
    CLOSE pol_cur;

    IF v_date_of_inception IS NOT NULL AND v_date_of_inception IS NOT NULL THEN
      IF v_bill_date < v_date_of_inception OR v_bill_date > v_date_of_exit THEN
        raise_application_error(-20165,  'Bill date should be within member validity period');
      END IF;
    END IF;
  END validate_bill_date;
-- ===================================================================================================================
-- PROCEDURE for displaying Manual preauths linked to policy / not linked to policy

--- PARAMETERS

-- 1. null
-- 2. tpa_office_seq_id
-- 3. 'Y' - Policy Linked  / 'N' - Policy not linked
-- 4. from_date
-- 5. to_date

  PROCEDURE manual_claim_rpt (
    where_clause              IN VARCHAR2, -- Pipe concatenated string of values
    cur                       OUT SYS_REFCURSOR
  )
  IS
    str_tab                             ttk_util_pkg.str_table_type;
    v_str                               VARCHAR2(4000);
    v_start_date                        DATE;
    v_end_date                          DATE;
  BEGIN
    str_tab                            := ttk_util_pkg.parse_str ( where_clause );
    v_start_date                       := TO_DATE(str_tab(4),'dd/mm/yyyy');
    v_end_date                         := TO_DATE(str_tab(5),'dd/mm/yyyy');

    v_str :=
    ' SELECT
    a.claim_number,
    A.claim_settlement_number ,
    b.ins_seq_id,
    c.ins_comp_name,
    c.ins_comp_code_number,
    b.claimant_name,
    B.employee_no,
    B.employee_name,
    G.group_id,
    to_char(A.date_of_admission,''dd/mm/yyyy HH:MI AM'') AS date_of_admission ,
    CASE WHEN D.policy_seq_id IS NOT NULL AND E.member_seq_id IS NOT NULL THEN ''Y'' ELSE ''N'' END AS policy_available_yn ,
    CASE WHEN b.policy_seq_id IS NOT NULL AND b.member_seq_id IS NOT NULL THEN ''Y'' ELSE ''N'' END AS policy_linked_yn
    FROM clm_general_details a JOIN clm_enroll_details b ON ( a.claim_seq_id = b.claim_seq_id AND ( B.clm_status_general_type_id  != ''PCO'' OR B.clm_status_general_type_id  != ''REJ''  ) AND a.mode_general_type_id = ''CML'')
    LEFT OUTER JOIN tpa_ins_info C ON (b.ins_seq_id = c.ins_seq_id)
    LEFT OUTER JOIN tpa_enr_policy D ON (  B.policy_number = D.policy_number)
    LEFT OUTER JOIN tpa_enr_policy_member E on (B.tpa_enrollment_id = E.tpa_enrollment_id )
    LEFT OUTER JOIN tpa_group_registration G ON (B.group_reg_seq_id = G.group_reg_seq_id)
    WHERE ( :str_tab_2 IS NULL OR d.tpa_office_seq_id = :str_tab_2 )
    AND NVL(E.renew_yn,''N'') = ''N'' AND ( :str_tab_4 IS NULL OR TRUNC(A.date_of_admission ) >= :str_tab_4 )
            AND ( :str_tab_5 IS NULL OR TRUNC(A.date_of_admission ) <= :str_tab_5 ) ';

    IF str_tab(3) = 'Y' THEN
      v_str :=  v_str ||' AND B.policy_seq_id IS NOT NULL AND B.member_seq_id IS NOT NULL ';
    ELSIF str_tab(3) = 'N' THEN
      v_str :=  v_str ||' AND ( B.policy_seq_id IS NULL OR B.member_seq_id IS NULL ) ';
    END IF;

    OPEN cur FOR v_str USING str_tab(2), str_tab(2), v_start_date,v_start_date,v_end_date,v_end_date ;

  END manual_claim_rpt;
--========================================================================================================
  PROCEDURE pick_claim_to_quality_check  IS
    num_tab      ttk_util_pkg.str_table_type;
    v_ctr        NUMBER(20);
    v_perc       NUMBER(3);
    CURSOR perc_cur IS SELECT a.qc_limit , a.qc_perc_above_limit, a.qc_perc_below_limit
             FROM tpa_system_parameters a ;
    perc_rec     perc_cur%ROWTYPE;

  BEGIN
    INSERT INTO quality_temp ( serial_no , seq_id , added_by , added_date )
       SELECT ROWNUM , b.claim_seq_id , b.added_by , b.added_date
          FROM  ( SELECT X.claim_seq_id, MAX(X.review_num) FROM pat_event_history x WHERE x.event_seq_id = 15
          AND x.event_exec_date BETWEEN trunc(SYSDATE) AND trunc( SYSDATE+1 )
          AND x.claim_seq_id IS NOT NULL GROUP BY x.claim_seq_id ) a JOIN clm_general_details b ON (a.claim_seq_id = b.claim_seq_id AND b.completed_yn ='Y')
          JOIN clm_enroll_details c ON (b.claim_seq_id = c.claim_seq_id);

    v_ctr      := SQL%ROWCOUNT;
    IF v_ctr != 0 THEN

      OPEN perc_cur;
      FETCH perc_cur INTO perc_rec;
      CLOSE perc_cur;
      IF v_ctr <= perc_rec.qc_limit THEN
        v_perc := perc_rec.qc_perc_below_limit;
      ELSE
        v_perc := perc_rec.qc_perc_above_limit;
      END IF;
      IF v_ctr * v_perc/100 < 1 THEN
        v_perc := 100;
      END IF;

      num_tab    := ttk_util_pkg.get_random(1,v_ctr,v_perc);
      IF num_tab.FIRST IS NOT NULL THEN
        FORALL i IN num_tab.FIRST .. num_tab.LAST
         INSERT INTO quality_control (qc_seq_id, claim_seq_id,qc_marked_date, added_by , added_date )
           SELECT quality_control_seq.NEXTVAL, a.seq_id ,SYSDATE, a.added_by , a.added_date
                            FROM quality_temp a  WHERE a.serial_no = num_tab(i);
      END IF;
    END IF;
    COMMIT;
  END pick_claim_to_quality_check;
--========================================================================================================
    PROCEDURE delete_claims (
    v_claim_seq_id                  IN OUT clm_general_details.claim_seq_id%TYPE,
    v_added_by                      IN NUMBER
  )
  IS

   CURSOR clm_state_cur IS
      SELECT A.completed_yn , NVL(d.buffer_hdr_seq_id,O.buffer_hdr_seq_id) AS buffer_hdr_seq_id ,
         c.claim_general_type_id , b.clm_status_general_type_id ,d.buffer_hdr_seq_id AS clm_buffer_hdr_seq_id,
         e.member_seq_id, e.mem_general_type_id ,
         NVL(f.claim_app_buffer_amount,o.claim_app_buffer_amount) AS claim_app_buffer_amount,
         nvl(f.pre_auth_buffer_app_amount,o.pre_auth_buffer_app_amount) AS pre_auth_buffer_app_amount,
         nvl(f.utilised_amount,o.utilised_amount) AS utilised_amount,
          e.policy_group_seq_id,f.claim_app_buffer_amount AS curr_clm_app_buffer_amount,
         k.balance_seq_id , c.document_general_type_id ,
         k.utilised_buff_amount , l.buffer_alloc_general_type_id , a.claim_sub_general_type_id ,
         m.mem_buffer_seq_id, l.tpa_office_seq_id AS policy_tpa_office_seq_id ,l.endorsement_seq_id ,
         L.enrol_type_id , a.claim_seq_id , a.pat_enroll_detail_seq_id,
         l.policy_sub_general_type_id AS policy_sub_type,
         nvl(n.claim_type,d.claim_type) as claim_type,nvl(n.buffer_type ,d.buffer_type) as buffer_type
         FROM clm_general_details A JOIN clm_enroll_details B ON (a.claim_seq_id  = b.claim_seq_id  )
         JOIN clm_inward C ON (A.claims_inward_seq_id = C.claims_inward_seq_id)
         LEFT OUTER JOIN buffer_details D ON (a.last_buffer_detail_seq_id = d.buff_detail_seq_id )
         LEFT OUTER JOIN tpa_enr_policy_member E ON (b.member_seq_id = e.member_seq_id)
         LEFT OUTER JOIN buffer_header f ON (d.buffer_hdr_seq_id = f.buffer_hdr_seq_id)
         LEFT OUTER JOIN pat_general_details h ON (a.pat_enroll_detail_seq_id = h.pat_enroll_detail_seq_id)
         LEFT OUTER JOIN tpa_enr_balance k ON (e.policy_group_seq_id = k.policy_group_seq_id)
         LEFT OUTER JOIN tpa_enr_policy  L ON (b.policy_seq_id = l.policy_seq_id )
         LEFT OUTER JOIN tpa_enr_mem_buffer M ON (e.member_seq_id = m.member_seq_id)
         LEFT OUTER JOIN buffer_details N ON (H.last_buffer_detail_seq_id = N.buff_detail_seq_id )
         LEFT OUTER JOIN buffer_header O ON (N.buffer_hdr_seq_id = O.buffer_hdr_seq_id)
         WHERE a.claim_seq_id  = v_claim_seq_id AND NVL( h.pat_enhanced_yn,'N' ) = 'N'
              AND ( e.mem_general_type_id = 'PFL' AND k.member_seq_id IS NULL OR b.member_seq_id = k.member_seq_id OR b.member_seq_id IS NULL);

   CURSOR prev_appr_cur IS  SELECT COUNT(1) FROM ( SELECT a.claim_seq_id, a.parent_claim_seq_id
      FROM clm_general_details a START WITH a.claim_seq_id = v_claim_seq_id CONNECT BY a.claim_seq_id = PRIOR a.parent_claim_seq_id ) aa
      JOIN clm_enroll_details bb ON (aa.claim_seq_id = bb.claim_seq_id )
      WHERE bb.clm_status_general_type_id = 'APR' AND aa.claim_seq_id != v_claim_seq_id ;

   CURSOR curr_claim_buff_amount IS SELECT SUM(a.buffer_app_amount)
    FROM buffer_details a WHERE a.claim_seq_id = v_claim_seq_id;
    v_curr_claim_buff_amount      NUMBER;
    v_prev_appr_count             PLS_INTEGER := 0;
    clm_rec                       clm_state_cur%ROWTYPE;
    v_balance_buffer              NUMBER(16,2);
  v_rows   number(10);

  BEGIN
     claims_freeze(v_claim_seq_id,NULL,'S'); --KOCBJJ

    OPEN clm_state_cur;
    FETCH clm_state_cur INTO clm_rec;
    CLOSE clm_state_cur; 
      
    IF clm_rec.completed_yn = 'N' AND clm_rec.claim_type is not null then 
         raise_application_error(-20756,'Buffer records exists, try deletion after rejection/cancellation and completion of the Claims.');
    ELSIF clm_rec.completed_yn = 'Y'  AND clm_rec.claim_type is NOT NULL AND  clm_rec.clm_status_general_type_id NOT IN ('REJ','PCO')  THEN
         raise_application_error(-20756,'Buffer records exists, try deletion after rejection/cancellation and completion of the Claims.');
    ELSIF clm_rec.completed_yn = 'Y'  AND clm_rec.claim_type is NULL THEN
          RAISE_APPLICATION_ERROR(-20155,'You Cannot Delete Completed Claims.');
    ELSIF clm_rec.completed_yn = 'N' AND clm_rec.clm_status_general_type_id != 'INP' THEN
          RAISE_APPLICATION_ERROR(-20179,'Only Claims in state In-Progress can be deleted.');
    END IF;

     
    IF clm_rec.pat_enroll_detail_seq_id IS NOT NULL AND app.maintenance_pkg.get_prev_approve_count(v_claim_seq_id) = 0 THEN
      UPDATE pat_enroll_details a SET
        a.claim_id = NULL
        WHERE a.pat_enroll_detail_seq_id = clm_rec.pat_enroll_detail_seq_id ;
    END IF;

    DELETE FROM clm_hospital_additional_dtl a WHERE a.clm_hosp_assoc_seq_id =
               ( SELECT b.clm_hosp_assoc_seq_id  FROM clm_hospital_association b
                  WHERE b.claim_seq_id = v_claim_seq_id )  ;
    DELETE FROM clm_hospital_association b
                  WHERE b.claim_seq_id = v_claim_seq_id ;
    DELETE FROM pat_package_procedures a WHERE a.icd_pcs_seq_id IN
              ( SELECT b.icd_pcs_seq_id FROM icd_pcs_detail b  WHERE b.claim_seq_id = v_claim_seq_id );
    DELETE FROM ailment_caps a WHERE a.icd_pcs_seq_id IN
              ( SELECT b.icd_pcs_seq_id FROM icd_pcs_detail b  WHERE b.claim_seq_id = v_claim_seq_id );
    DELETE FROM icd_pcs_detail b  WHERE b.claim_seq_id = v_claim_seq_id ;
	DELETE FROM tpa_diagnosys_details d WHERE d.claim_seq_id = v_claim_seq_id;--koc decoupling    
    DELETE FROM ailment_details a WHERE a.claim_seq_id = v_claim_seq_id ;
    DELETE FROM clm_bill_details a WHERE a.clm_bill_seq_id IN ( SELECT b.clm_bill_seq_id
                                                                  FROM clm_bill_header b
                                                                 WHERE b.claim_seq_id = v_claim_seq_id );
    DELETE FROM clm_bill_header b WHERE b.claim_seq_id = v_claim_seq_id ;
    DELETE FROM discrepancy_information WHERE claim_seq_id = v_claim_seq_id ;
    DELETE FROM associated_illness  a WHERE a.claim_seq_id = v_claim_seq_id ;
    UPDATE clm_general_details A SET A.last_assign_user_seq_id = NULL WHERE a.claim_seq_id = v_claim_seq_id ;
    DELETE FROM assign_users a WHERE a.claim_seq_id = v_claim_seq_id ;
    DELETE FROM clm_discharge_voucher a WHERE a.claim_seq_id = v_claim_seq_id;
    DELETE FROM clm_documents_rcvd a WHERE a.claim_seq_id = v_claim_seq_id;

    UPDATE shortfall_details A SET A.last_reminder_log_seq_id = NULL WHERE A.claim_seq_id =  v_claim_seq_id;
    DELETE FROM shortfall_reminder_log b WHERE b.shortfall_seq_id IN
      (SELECT a.shortfall_seq_id FROM shortfall_details A WHERE A.claim_seq_id =  v_claim_seq_id);
    DELETE FROM shortfall_details A WHERE A.claim_seq_id =  v_claim_seq_id;

    DELETE FROM investigation_details A WHERE A.claim_seq_id = v_claim_seq_id;
    DELETE FROM rule_data a WHERE a.claim_seq_id = v_claim_seq_id;
    DELETE FROM pat_log a WHERE a.claim_seq_id = v_claim_seq_id;
    DELETE FROM pat_event_history a WHERE a.claim_seq_id = v_claim_seq_id ;
    DELETE FROM quality_control a WHERE a.claim_seq_id = v_claim_seq_id;
    DELETE FROM code_cleanup_event_history a WHERE a.claim_seq_id = v_claim_seq_id ;
    DELETE FROM code_cleanup_workflow a WHERE a.claim_seq_id = v_claim_seq_id ;

    DELETE FROM clm_enroll_details a WHERE a.claim_seq_id = v_claim_seq_id ;
    DELETE FROM clm_general_details a WHERE a.claim_seq_id = v_claim_seq_id ;
    unassoc_claim_intimation(v_claim_seq_id,null,v_added_by,v_rows); --KOC1349

  END delete_claims;
--========================================================================================================
  PROCEDURE override_claims(
    v_claim_seq_id                        IN clm_general_details.claim_seq_id%TYPE ,
    v_added_by                            IN NUMBER,
    v_event_seq_id                        IN OUT CLM_GENERAL_DETAILS.event_seq_id%TYPE,
    v_review_count                        IN OUT CLM_GENERAL_DETAILS.review_count%TYPE,
    v_required_review_count               IN OUT CLM_GENERAL_DETAILS.required_review_count%TYPE,
    v_event_name                          OUT VARCHAR2,
    v_review                              OUT VARCHAR2
  )
  IS

    CURSOR mem_cur IS SELECT b.member_seq_id , d.balance_seq_id ,b.policy_seq_id,
      NVL(f.claim_app_buffer_amount,M.claim_app_buffer_amount ) AS claim_app_buffer_amount
      , NVL(f.pre_auth_buffer_app_amount, m.pre_auth_buffer_app_amount) AS pre_auth_buffer_app_amount  ,
      nvl(nvl(f.utilised_amount,m.utilised_amount),0) AS utilised_amount ,
      nvl(m.buffer_hdr_seq_id,f.buffer_hdr_seq_id) AS buffer_hdr_seq_id,
      g.mem_buffer_seq_id , x.buffer_alloc_amount,b.clm_status_general_type_id ,
      c.mem_general_type_id , c.policy_group_seq_id ,  x.buffer_allowed_yn , x.buffer_alloc_general_type_id , d.utilised_buff_amount ,
      a.required_review_count,a.review_count, a.event_seq_id, o.event_name  , i.claim_seq_id AS child_claim_seq_id , j.claim_id ,
      j.pat_enroll_detail_seq_id , j.pat_status_general_type_id , a.last_assign_user_seq_id  ,a.completed_yn ,p.document_general_type_id,
      a.utilised_buff_amt AS curr_clm_utilised_buff_amt ,e.buffer_app_amount AS current_clm_app_amount ,
      a.clm_cash_benefit_seq_id ,a.claim_sub_general_type_id , q.rson_general_type_id,
      j.pat_status_general_type_id AS pat_status,k.completed_yn AS pat_completed_yn,
--koc1277
case x.policy_sub_general_type_id when 'PNF' then nvl(c.policy_deductable_yn,'N')
           when 'PFL' then nvl(gr.policy_deductable_yn,'N') end as policy_deductable_yn,a.total_app_amount,
--koc1277
      nvl(l.claim_type,e.claim_type) as claim_type ,nvl(l.buffer_type,e.buffer_type) as buffer_type,
      a.utilised_buff_amt as curr_claim_utilised_buff,
      A.OVERRIDE_RESTRICT_YN

      FROM clm_general_details a JOIN clm_enroll_details b ON ( a.claim_seq_id = b.claim_seq_id )
      JOIN tpa_enr_policy_member c ON (b.member_seq_id = c.member_seq_id)
      JOIN tpa_enr_balance d ON (c.policy_group_seq_id = d.policy_group_seq_id)
      JOIN tpa_enr_policy  x ON (b.policy_seq_id = x.policy_seq_id)
      LEFT OUTER JOIN tpa_enr_policy_group gr ON (gr.policy_group_seq_id = c.policy_group_seq_id) --koc1277
      LEFT OUTER JOIN buffer_details e ON (a.last_buffer_detail_seq_id = e.buff_detail_seq_id)
      LEFT OUTER JOIN buffer_header f ON (e.buffer_hdr_seq_id = f.buffer_hdr_seq_id)
      LEFT OUTER JOIN tpa_enr_mem_buffer G ON ( b.member_seq_id = g.member_seq_id )
      LEFT OUTER JOIN clm_general_details i ON (a.claim_seq_id = i.parent_claim_seq_id)
      LEFT OUTER JOIN pat_enroll_details j ON (a.pat_enroll_detail_seq_id = j.pat_enroll_detail_seq_id)
      LEFT OUTER JOIN pat_general_details k ON (a.pat_enroll_detail_seq_id = k.pat_enroll_detail_seq_id AND k.pat_enhanced_yn = 'N')
      LEFT OUTER JOIN buffer_details l ON (k.last_buffer_detail_seq_id = l.buff_detail_seq_id)
      LEFT OUTER JOIN buffer_header m ON (l.buffer_hdr_seq_id = m.buffer_hdr_seq_id)
      LEFT OUTER JOIN tpa_event o ON (a.event_seq_id = o.event_seq_id)
      JOIN clm_inward p ON (a.claims_inward_seq_id = p.claims_inward_seq_id)
      LEFT OUTER JOIN assign_users q ON (a.last_assign_user_seq_id = q.assign_users_seq_id)
      WHERE a.claim_seq_id = v_claim_seq_id
        AND ( c.mem_general_type_id = 'PFL' AND d.member_seq_id IS NULL OR b.member_seq_id = d.member_seq_id OR b.member_seq_id IS NULL );
----koc1277 uncommented payment_check_seq_id,claims_chk_seq_id from cheque_cur
    CURSOR cheque_cur IS SELECT a.payment_seq_id,b.payment_check_seq_id,c.claims_chk_seq_id,c.check_status , a.claim_payment_status
          FROM tpa_claims_payment a LEFT OUTER JOIN tpa_payment_checks_details b ON (a.payment_seq_id = b.payment_seq_id)
          LEFT OUTER JOIN tpa_claims_check c ON (b.claims_chk_seq_id = c.claims_chk_seq_id)
          WHERE a.claim_seq_id = v_claim_seq_id ORDER BY  c.claims_chk_seq_id  DESC;

    mem_rec                          mem_cur%ROWTYPE;

    CURSOR cash_benefit_cur IS SELECT cb.claim_seq_id, a.claim_payment_status, a.payment_seq_id,c.check_status, cb.completed_yn,
        b.payment_check_seq_id,c.claims_chk_seq_id, d.claims_inward_seq_id,nvl(cb.new_cash_benefit_yn,'N') as new_cash_benefit_yn --KOC1270
        FROM clm_cash_benefit cb JOIN tpa_claims_payment a ON (cb.claim_seq_id = a.claim_seq_id)
        LEFT OUTER JOIN tpa_payment_checks_details b ON (a.payment_seq_id = b.payment_seq_id)
        LEFT OUTER JOIN tpa_claims_check c ON (b.claims_chk_seq_id = c.claims_chk_seq_id)
        LEFT OUTER JOIN clm_general_details d ON (cb.claim_seq_id = d.claim_seq_id)
        WHERE cb.clm_cash_benefit_seq_id = mem_rec.clm_cash_benefit_seq_id
        ORDER BY  c.claims_chk_seq_id  DESC;

    CURSOR prev_appr_cur IS  SELECT COUNT(1) FROM
     ( SELECT a.claim_seq_id, a.parent_claim_seq_id
      FROM clm_general_details a START WITH a.claim_seq_id = v_claim_seq_id CONNECT BY a.claim_seq_id = PRIOR a.parent_claim_seq_id ) aa
      JOIN clm_enroll_details bb ON (aa.claim_seq_id = bb.claim_seq_id )
      WHERE bb.clm_status_general_type_id = 'APR' ;


    cash_benefit_rec                 cash_benefit_cur%ROWTYPE;
    v_reject_buffer                  CHAR(1) := 'N';
    v_tot_buffer_app_amount          NUMBER (12,2);
    v_reject_override                CHAR(1) := 'N';
    cheque_rec                       cheque_cur%ROWTYPE;
    v_cash_benefit_update_yn         VARCHAR2(1) := 'Y';
    v_balance_buffer                 NUMBER := 0;
    v_buff_available                 BOOLEAN := TRUE;
    v_prev_appr_count                PLS_INTEGER := 0;
    v_ctr                            PLS_INTEGER := 0;
    v_buffer_deleted_yn              VARCHAR2(1) := 'N';
  BEGIN

    --locking CLAIM
    TTK_UTIL_PKG.reset_id_flag(v_claim_seq_id||'-CLM','Y');

    OPEN  mem_cur;
    FETCH mem_cur INTO mem_rec;
    CLOSE mem_cur;

  claims_freeze(v_claim_seq_id,mem_rec.clm_status_general_type_id,'O'); --KOCBJJ
    
    IF mem_rec.override_restrict_yn='Y' THEN 
      RAISE_APPLICATION_ERROR(-20136,'You cannot Override the claim,Claim buff amt is less than the preauth apr buff amt.');
    END IF;
    
    IF mem_rec.pat_enroll_detail_seq_id IS NOT NULL AND mem_rec.claim_id IS NULL THEN
      -- deleting buffer records of claims for which the preauth was associated
      FOR rec IN (SELECT a.claim_seq_id,a.last_buffer_detail_seq_id FROM clm_general_details a
                      WHERE a.pat_enroll_detail_seq_id = mem_rec.pat_enroll_detail_seq_id
                        AND a.claim_seq_id NOT IN ( SELECT b.claim_seq_id FROM clm_general_details b
                            START WITH b.claim_seq_id = v_claim_seq_id CONNECT BY PRIOR b.parent_claim_seq_id = b.claim_seq_id )
                                 ORDER BY a.claim_seq_id DESC)
      LOOP
        IF rec.last_buffer_detail_seq_id IS NOT NULL THEN
          pre_auth_pkg.delete_claim_buffer(rec.claim_seq_id);
          v_buffer_deleted_yn := 'Y';
        END IF;
      END LOOP;
      IF v_buffer_deleted_yn = 'Y' THEN
        OPEN  mem_cur;
        FETCH mem_cur INTO mem_rec;
        CLOSE mem_cur;
      END IF;
    END IF;

    IF mem_rec.document_general_type_id = 'DTA' THEN
      SELECT count(1) INTO v_ctr FROM
          (SELECT a.claim_seq_id
           FROM clm_enroll_details A JOIN pat_event_history B ON (A.claim_seq_id = B.claim_seq_id )
           WHERE a.claim_seq_id IN
           ( SELECT a.claim_seq_id
             FROM clm_general_details a WHERE a.claim_seq_id != v_claim_seq_id
                START WITH a.claim_seq_id = v_claim_seq_id
                CONNECT BY PRIOR a.parent_claim_seq_id = a.claim_seq_id)
             GROUP BY a.claim_seq_id, a.decision_date HAVING a.decision_date > MAX(b.event_exec_date));

      IF v_ctr > 0 THEN
        raise_application_error(-20727,'Ammendment cannot be overridden, since previous claim rejected/closed after completion.');
      END IF;
    END IF;

    v_ctr := NULL;
    IF mem_rec.clm_status_general_type_id != 'APR' THEN
      IF mem_rec.pat_enroll_detail_seq_id IS NOT NULL THEN
        IF  mem_rec.pat_status_general_type_id != 'APR' OR mem_rec.pat_completed_yn = 'N' THEN
          raise_application_error(-20186,'Associated preauth is not in approved/completed state.');
        ELSIF mem_rec.claim_id IS NULL THEN
          UPDATE pat_enroll_details a SET
            a.claim_id = ( SELECT cc.claim_seq_id FROM clm_general_details cc
                            WHERE cc.parent_claim_seq_id IS NULL
                              START WITH cc.claim_seq_id = v_claim_seq_id
                              CONNECT BY cc.claim_seq_id = PRIOR parent_claim_seq_id )
            WHERE a.pat_enroll_detail_seq_id = mem_rec.pat_enroll_detail_seq_id
              AND a.claim_id IS NULL;

        ELSIF mem_rec.claim_id IS NOT NULL THEN
          IF mem_rec.document_general_type_id = 'DTA' THEN
            SELECT COUNT(1) INTO v_ctr FROM dual WHERE mem_rec.claim_id IN
              ( SELECT a.claim_seq_id FROM clm_general_details a
                  START WITH a.claim_seq_id = v_claim_seq_id
                  CONNECT BY PRIOR a.parent_claim_seq_id = a.claim_seq_id );

          ELSIF mem_rec.claim_id != v_claim_seq_id THEN
            v_ctr := 0;
          END IF;
          IF v_ctr = 0 THEN
            raise_application_error(-20185,' Preauth is currently associated to another claim ');
          END IF;
        END IF;
      END IF;
    END IF;

    IF mem_rec.child_claim_seq_id IS NOT NULL THEN
      raise_application_error(-20184,' Ammendment Exist , Cannot override');
    ELSIF mem_rec.completed_yn = 'N' THEN
      raise_application_error(-20159,  'Please Settle and Complete the reviews');
    END IF;


    IF mem_rec.completed_yn = 'Y' THEN
         --LOCKING BUFFER INFO
        TTK_UTIL_PKG.reset_id_flag(mem_rec.policy_seq_id||'-POLICYBUFFER','Y');
        IF mem_rec.buffer_alloc_general_type_id = 'BAI' THEN
          TTK_UTIL_PKG.reset_id_flag(mem_rec.member_seq_id||'-MEMBUFFER','Y');
        ELSE
          TTK_UTIL_PKG.reset_id_flag(mem_rec.policy_group_seq_id||'-FAMBUFFER','Y');
        END IF;

        v_buff_available := mem_buff_availaility( v_balance_buffer , mem_rec.policy_seq_id,mem_rec.policy_group_seq_id, mem_rec.member_seq_id,mem_rec.mem_general_type_id,mem_rec.claim_type,mem_rec.buffer_type );
        IF v_buff_available THEN
          v_buff_available := pol_buff_availability(v_balance_buffer, mem_rec.policy_seq_id,mem_rec.claim_type,mem_rec.buffer_type);
        END IF;
        


      pre_auth_pkg.reassign_user (  NULL , v_claim_seq_id ,NULL , v_added_by , 'OVR');

      IF mem_rec.claim_sub_general_type_id = 'CBN' THEN
        raise_application_error(-20710,'Overriding option is not allowed for hospital cash benefit claims.');
      END IF;

      OPEN cheque_cur;
      FETCH cheque_cur INTO cheque_rec;
      CLOSE cheque_cur;

      IF cheque_rec.check_status = 'CSV' THEN
          -- making the claim_seq_id to null by moving
          -- claim_seq_id to overridden_claim_seq_id column in the case of claims with cheque made void.
          UPDATE tpa_claims_payment a SET
             a.overridden_claim_seq_id = a.claim_seq_id ,
             a.claim_seq_id            = NULL,
             a.updated_date            = SYSDATE,
             a.updated_by              = v_added_by
             WHERE a.claim_seq_id = v_claim_seq_id ;

      ELSE
--koc1277
        if mem_rec.policy_deductable_yn = 'Y' and nvl(mem_rec.total_app_amount,0) = 0
          and cheque_rec.claim_payment_status = 'PAID' then

    delete from fin_app.tpa_payment_checks_details cd where cd.payment_check_seq_id = cheque_rec.payment_check_seq_id;

    delete from fin_app.tpa_claims_check cc where cc.claims_chk_seq_id = cheque_rec.claims_chk_seq_id;

        update fin_app.tpa_claims_payment pay
          set pay.paid_amount = null,
          pay.claim_payment_status = 'PENDING'
          where pay.payment_seq_id = cheque_rec.payment_seq_id;

        end if;


        DELETE tpa_claims_payment a WHERE a.payment_seq_id = cheque_rec.payment_seq_id
                   AND a.claim_payment_status IN  ('PENDING','VOUCHER PENDING');
        IF SQL%ROWCOUNT = 0 AND mem_rec.clm_status_general_type_id = 'APR' THEN
          raise_application_error(-20183,'Claim forwarded to finance, Cannot override');
        END IF;
      END IF;
      -- checking cash benefit exist for this claim then removing entries if check is not released.
      IF mem_rec.clm_cash_benefit_seq_id IS NOT NULL THEN
        OPEN cash_benefit_cur;
        FETCH cash_benefit_cur INTO cash_benefit_rec;
        CLOSE cash_benefit_cur;

        IF cash_benefit_rec.completed_yn = 'Y' THEN
          IF cash_benefit_rec.check_status = 'CSV' THEN
            -- deleting from check payment intermediate table
            DELETE FROM tpa_payment_checks_details a WHERE a.payment_check_seq_id = cash_benefit_rec.payment_check_seq_id;
            -- deleting from check table
            DELETE FROM tpa_claims_check a WHERE a.claims_chk_seq_id = cash_benefit_rec.claims_chk_seq_id;
            -- deleting from check table
            DELETE FROM tpa_claims_payment a WHERE a.payment_seq_id = cash_benefit_rec.payment_seq_id;
          ELSE
            DELETE tpa_claims_payment a WHERE a.payment_seq_id = cash_benefit_rec.payment_seq_id
                       AND a.claim_payment_status IN  ('PENDING','VOUCHER PENDING');
            IF SQL%ROWCOUNT = 0 AND mem_rec.clm_status_general_type_id = 'APR' THEN
              v_cash_benefit_update_yn := 'N';
            END IF;
          END IF;
          IF v_cash_benefit_update_yn = 'Y' THEN
            -- UPDATION AND DELETION HAPPENS ONLY CHEQUE IS NOT ISSUED FOR CASH BENEFIT
            -- Else Cash benefit is left as it is.
            UPDATE clm_cash_benefit a SET
                 a.claim_seq_id = NULL,
                 a.completed_yn = 'N',
                 a.cb_claim_number = NULL,
                 a.clm_status_general_type_id = 'INP'
                 WHERE a.claim_seq_id = cash_benefit_rec.claim_seq_id and nvl(a.new_cash_benefit_yn,'N')!='Y'; --KOC1270
            -- DELETING ALL CASH BENEFIT CLAIM AND ASSOCIATED RECORDS.
            delete_clm_cash_benefit ( cash_benefit_rec.Claims_Inward_Seq_Id,cash_benefit_rec.Claim_Seq_Id,  v_added_by  );
          END IF;
        END IF;
--KOC1270
        ELSE
             DELETE FROM CLM_CASH_BENEFIT cb
               WHERE cb.parent_claim_seq_id = v_claim_seq_id
               and cb.new_cash_benefit_yn='Y' and cb.completed_yn='N'
               and cb.clm_status_general_type_id='INP';

            DELETE FROM app.CLM_CASH_BENEFIT_BILLS BL
            WHERE BL.PARENT_CLAIM_SEQ_ID = v_claim_seq_id
            AND BL.MEMBER_SEQ_ID = mem_rec.member_seq_id;

      END IF;
--KOC1270


      v_tot_buffer_app_amount := nvl(mem_rec.pre_auth_buffer_app_amount,0) + nvl(mem_rec.claim_app_buffer_amount,0) ;

      IF v_reject_override = 'N' THEN
          SELECT a.event_seq_id, a.simple_review_count, a.event_name INTO v_event_seq_id , v_required_review_count , v_event_name
             FROM tpa_event a JOIN tpa_workflow b ON (a.workflow_seq_id = b.workflow_seq_id)
             WHERE b.sub_general_type_id = 'CLM' AND a.order_number = 5;

          UPDATE clm_general_details a SET
            a.event_seq_id           = v_event_seq_id ,
            a.review_count           = 1,
            a.required_review_count  = v_required_review_count,
            a.completed_yn           = 'N',
            a.updated_by             = v_added_by,
            a.updated_date           = SYSDATE
            WHERE a.claim_seq_id = v_claim_seq_id AND a.event_seq_id = v_event_seq_id + 1;
          IF SQL%ROWCOUNT > 0 THEN
            pre_auth_pkg.save_event_history( 0, NULL, v_claim_seq_id , v_event_seq_id , v_review_count, v_added_by, v_added_by );
            v_review_count := 1;
            v_event_name   := 'Event :'|| v_event_name ;
            v_review := '1('||TO_CHAR( v_required_review_count )||')';
          ELSE
            v_review_count := mem_rec.review_count;
            v_event_name   := 'Event :'|| mem_rec.event_name ;
            v_review := '1('||TO_CHAR( mem_rec.required_review_count )||')';
          END IF;
        -- Assigning the preauth to the user who is overriding the completed preauth.
      ELSIF v_reject_override = 'Y' THEN
        raise_application_error(-20702,'Preauth Buffer approved amount exceeds current available amount');
      END IF;
    ELSE
      v_review_count := mem_rec.review_count;
      v_event_name   := 'Event :'|| mem_rec.event_name ;
      v_review := '1('||TO_CHAR( mem_rec.required_review_count )||')';
    END IF;
    COMMIT;
  END override_claims;
  -- =================================================================================================================
  PROCEDURE select_bills_list(
    v_claim_seq_id                        IN clm_general_details.claim_seq_id%TYPE,
    v_added_by                            IN NUMBER,
    bills_cur                             OUT SYS_REFCURSOR
  )
  IS
--koc1273
  v_clm_bill_seq_id   clm_bill_header.clm_bill_seq_id%type;
  v_ctr number;
 v_acc_type                     char(20);

   cursor clm_cur is
      select gen.claim_seq_id,
             gen.claim_number,
             en.member_seq_id,
             en.tpa_enrollment_id,
             EN.POLICY_SEQ_ID,
             MEM.POLICY_GROUP_SEQ_ID,
             POL.PRODUCT_SEQ_ID,
             POL.ENROL_TYPE_ID,
             POL.POLICY_SUB_GENERAL_TYPE_ID,
             EN.MEM_AGE,
             ap.icd_pcs_seq_id,
             (case when  POL.ENROL_TYPE_ID = 'COR' then nvl(pol.critical_sumins_yn,'N')
                else nvl(prd.critical_sumins_yn,'N') end) as  critical_sumins_yn,
             NVL(GR.CRITICAL_CASH_BENEFIT_YN,'N')  CRITICAL_CASH_BENEFIT_YN,
             EN.MEM_TOTAL_SUM_INSURED,
             en.clm_status_general_type_id

        from clm_general_details gen
        join clm_enroll_details en  on (en.claim_seq_id = gen.claim_seq_id)
        join clm_inward inw  on (inw.claims_inward_seq_id = gen.claims_inward_seq_id)
        LEFT OUTER JOIN TPA_ENR_POLICY_MEMBER MEM ON (MEM.MEMBER_SEQ_ID = EN.MEMBER_SEQ_ID)
        JOIN TPA_ENR_POLICY_GROUP GR ON (GR.POLICY_GROUP_SEQ_ID = MEM.POLICY_GROUP_SEQ_ID)
        LEFT OUTER JOIN TPA_ENR_POLICY POL ON (POL.POLICY_SEQ_ID = EN.POLICY_SEQ_ID)
        LEFT OUTER JOIN ICD_PCS_DETAIL ap ON (ap.claim_seq_id=gen.claim_seq_id)
        LEFT OUTER JOIN Tpa_Ins_Product Prd ON (Prd.Product_Seq_Id = pol.product_seq_id)
        where gen.claim_seq_id = v_claim_seq_id;

    clm_rec    clm_cur%ROWTYPE;

    cursor cb_cur is
      select CB.CRITICAL_ILLNESS_CONFIG_SEQ_ID,
             nvl(CB.AMOUNT,0) AMOUNT,
             nvl(CB.NO_OF_TIMES,0) NO_OF_TIMES,
             nvl(CB.SUM_INS_PER,0) SUM_INS_PER

             from app.critical_illness_config cb
       where ((cb.product_seq_id = clm_rec.product_seq_id and clm_rec.enrol_type_id <> 'COR') OR
             (cb.policy_seq_id = clm_rec.policy_seq_id and clm_rec.enrol_type_id = 'COR'))
         and clm_rec.Mem_Age between cb.frm_age and cb.To_Age;

    cb_rec cb_cur%ROWTYPE;


  CURSOR mem_cur IS
    SELECT pol.policy_sub_general_type_id,
             a.policy_group_seq_id,
             a.mem_age,
             pol.product_seq_id,
             pol.enrol_type_id,
             pol.policy_seq_id,
             bal.sum_insured,
             bal.bonus,
             bal.balance_seq_id,
         (nvl(bal.sum_insured,0) + nvl(bal.bonus,0) -  nvl(bal.utilised_sum_insured,0) - nvl(bal.utilised_cum_bonus,0)) bal

        FROM tpa_enr_policy_member a
        join tpa_enr_policy_group gr
          on (a.policy_group_seq_id = gr.policy_group_seq_id)
        join tpa_enr_policy pol on (pol.policy_seq_id = gr.policy_seq_id)
        join tpa_enr_balance bal on ((bal.member_seq_id = a.member_seq_id and
             pol.policy_sub_general_type_id = 'PNF') OR
             (bal.policy_group_seq_id = a.policy_group_seq_id and
             pol.policy_sub_general_type_id = 'PFL'))
       WHERE a.member_seq_id = clm_rec.member_seq_id;

           mem_rec    mem_cur%ROWTYPE;


v_cnt number(5);
--koc1273
  BEGIN

  --koc1273

select count(1)  into v_ctr
from (SELECT A.clm_bill_seq_id, A.bill_no, A.bill_date,A.Bill_Issued_By,C.Claim_Sub_General_Type_Id, --Added for koc1320
             DECODE(A.bills_with_prescription_yn,'Y','Yes','No') as bills_with_prescription_yn,
             CASE WHEN TRUNC(A.bill_date) < TRUNC(C.date_of_admission) THEN 'Pre-Hospitalization'
                  WHEN TRUNC(A.bill_date) > TRUNC(C.DATE_OF_DISCHARGE) THEN 'Post-Hospitalization'
                   ELSE 'Hospitalization' END AS bill_type , C.Completed_Yn,
             CASE WHEN A.bill_included_yn = 'Y' THEN 'Yes' ELSE 'No' END as bill_included_yn
        FROM clm_bill_header A INNER JOIN clm_general_details C ON A.claim_seq_id = C.claim_seq_id
       WHERE A.claim_seq_id = v_claim_seq_id );


  for rec in (select case when gen.claim_sub_general_type_id='CTL' then 'CTL' else 'ALL' end  as v_flag
from clm_general_details gen where gen.claim_seq_id=v_claim_seq_id)
  loop

  v_acc_type := rec.v_flag;

 end loop;

    OPEN  clm_cur;
    FETCH clm_cur INTO clm_rec;
    CLOSE clm_cur;

if v_acc_type = 'CTL'
  and clm_rec.clm_status_general_type_id !='APR'  then

--CHECKING THERE IS NO ENTRY IN BILLS

 if v_ctr = 0 then

    OPEN  cb_cur;
    FETCH cb_cur INTO cb_rec;
    v_cnt := cb_cur%rowcount;
    CLOSE cb_cur;

--dbms_output.put_line(' count : '||v_cnt);

--CHECKING IF ONE PLAN IS DEFINED OR NOT

if v_cnt = 1 AND clm_rec.CRITICAL_CASH_BENEFIT_YN = 'Y'  then
---WITHIN SUMINSURED
if clm_rec.critical_sumins_yn = 'Y' then

    OPEN  mem_cur;
    FETCH mem_cur INTO mem_rec;
    CLOSE mem_cur;

cb_rec.Amount := least( case when mem_rec.bal < 0 then 0 else mem_rec.bal end,
case when cb_rec.Amount > 0  then cb_rec.Amount else (clm_rec.Mem_Total_Sum_Insured * cb_rec.sum_ins_per)/100  end ,
CASE WHEN cb_rec.sum_ins_per > 0 THEN (clm_rec.Mem_Total_Sum_Insured * cb_rec.sum_ins_per)/100
  ELSE cb_rec.Amount END );

if nvl(cb_rec.Amount,0)=0 then
  cb_rec.Amount:=1;
end if;

ELSE
---OUTSIDE SUMINSURED

cb_rec.Amount := least(case when cb_rec.Amount > 0 then cb_rec.Amount else (clm_rec.Mem_Total_Sum_Insured * cb_rec.sum_ins_per)/100  end
,CASE WHEN cb_rec.sum_ins_per > 0 THEN (clm_rec.Mem_Total_Sum_Insured * cb_rec.sum_ins_per)/100 ELSE cb_rec.Amount END );

end if;

cb_rec.Amount := round(cb_rec.Amount);

          INSERT INTO clm_bill_header(clm_bill_seq_id, claim_seq_id, bill_no, bill_date, bill_issued_by,
                                      bills_with_prescription_yn ,bill_included_yn , added_by , added_date)
          VALUES( clm_bill_seq.NEXTVAL, v_claim_seq_id,1 , SYSDATE, NULL,
                 'N','Y' , v_added_by, SYSDATE)
                  RETURNING clm_bill_seq_id INTO v_clm_bill_seq_id;

          INSERT INTO clm_bill_details(clm_bill_dtl_seq_id,clm_bill_seq_id,description,ward_type_id,room_type_id,
                 number_of_days,requested_amount,allow_yn,allowed_amount, rejected_amount,
                 remarks,ward_max_amount,discount_percnt,added_by,added_date)
          VALUES( clm_bill_dtl_seq.NEXTVAL, v_clm_bill_seq_id, 'CRITICAL CASH BENEFIT', 'CIB', NULL,
                 0, cb_rec.Amount , 'Y', cb_rec.Amount , 0,
                 'CRITICAL CASH BENEFIT', NULL , NULL,v_added_by,SYSDATE);

            update clm_general_details gen
            set gen.requested_amount = cb_rec.Amount
            where gen.claim_seq_id = v_claim_seq_id;

update ailment_caps ac
set ac.approved_amount = cb_rec.Amount
where ac.icd_pcs_seq_id= clm_rec.icd_pcs_seq_id;

else
--dbms_output.put_line(' else : '||v_cnt);
          INSERT INTO clm_bill_header(clm_bill_seq_id, claim_seq_id, bill_no, bill_date, bill_issued_by,
                                      bills_with_prescription_yn ,bill_included_yn , added_by , added_date)
          VALUES( clm_bill_seq.NEXTVAL, v_claim_seq_id,1 , SYSDATE, NULL,
                 'N','Y' , v_added_by, SYSDATE)
                  RETURNING clm_bill_seq_id INTO v_clm_bill_seq_id;

          INSERT INTO clm_bill_details(clm_bill_dtl_seq_id,clm_bill_seq_id,description,ward_type_id,room_type_id,
                 number_of_days,requested_amount,allow_yn,allowed_amount, rejected_amount,
                 remarks,ward_max_amount,discount_percnt,added_by,added_date)
          VALUES( clm_bill_dtl_seq.NEXTVAL, v_clm_bill_seq_id, 'CRITICAL CASH BENEFIT', 'CIB', NULL,
                 0, 1 , 'Y', 1 , 0,
                 'CRITICAL CASH BENEFIT', NULL , NULL,v_added_by,SYSDATE);

            update clm_general_details gen
            set gen.requested_amount = 1
            where gen.claim_seq_id = v_claim_seq_id;

            update ailment_caps ac
            set ac.approved_amount = 1
            where ac.icd_pcs_seq_id= clm_rec.icd_pcs_seq_id;

end if;

end if;

end if;

  COMMIT;
  --koc1273



    OPEN bills_cur FOR
       SELECT A.clm_bill_seq_id, A.bill_no, A.bill_date,A.Bill_Issued_By,
             DECODE(A.bills_with_prescription_yn,'Y','Yes','No') as bills_with_prescription_yn,C.Claim_Sub_General_Type_Id, --Added for koc1320
             CASE WHEN TRUNC(A.bill_date) < TRUNC(C.date_of_admission) THEN 'Pre-Hospitalization'
                  WHEN TRUNC(A.bill_date) > TRUNC(C.DATE_OF_DISCHARGE) THEN 'Post-Hospitalization'
                   ELSE 'Hospitalization' END AS bill_type , C.Completed_Yn,
             CASE WHEN A.bill_included_yn = 'Y' THEN 'Yes' ELSE 'No' END as bill_included_yn,
             decode(a.DONOR_BILL_YN,'Y','Yes','No') as DONOR_BILL_YN --KOC DONOR
        FROM clm_bill_header A INNER JOIN clm_general_details C ON A.claim_seq_id = C.claim_seq_id
       WHERE A.claim_seq_id = v_claim_seq_id order by A.clm_bill_seq_id;

  END select_bills_list;
  -- =================================================================================================================
  PROCEDURE select_lineitems_list(
    v_claim_bill_seq_id                   IN clm_bill_header.clm_bill_seq_id%TYPE,
    lineitem_cur                          OUT SYS_REFCURSOR
  )
  IS
  BEGIN
    OPEN lineitem_cur FOR SELECT
             a.clm_bill_dtl_seq_id,a.description,a.ward_type_id||'#'|| TO_CHAR(capture_number_of_days_yn) AS ward_type_id ,b.ward_description,
             a.requested_amount , a.Allowed_Amount, a.room_type_id, a.number_of_days ,
             a.allow_yn , a.rejected_amount , a.remarks , c.room_description,a.no_of_visits,i.claim_sub_general_type_id, --Added for koc1320
             a.VACCINATION_TYPE_ID,D.VACCINATION_DESCRIPTION,  --KOC1164
             E.IMMUNIZATION_TYPE_ID,e.immunization_description,f.rout_adult_vacc_type_id,f.rout_adult_vacc_description,
             g.well_child_test_type_id,g.well_child_test_description

        FROM clm_bill_details a INNER JOIN tpa_hosp_ward_code b ON ( a.ward_type_id = b.ward_type_id )
             LEFT OUTER JOIN tpa_hosp_rooms_code C ON (a.room_type_id = c.room_type_id)
             INNER JOIN clm_bill_header h ON (a.clm_bill_seq_id = h.clm_bill_seq_id)--Added for koc1320
             INNER JOIN clm_general_details i ON (h.claim_seq_id = i.claim_seq_id)--Added for koc1320
             LEFT OUTER JOIN app.tpa_vaccination_code D ON (A.vaccination_type_id=D.vaccination_id)  --KOC1164
             LEFT OUTER JOIN app.child_vaccination_code E ON (A.child_immnunization=e.immunization_type_id) --KOC1315
             LEFT OUTER JOIN app.rout_adult_vaccination_code F ON (A.Rout_Adult_Phys_Exam=f.rout_adult_vacc_type_id) --KOC1308
             LEFT OUTER JOIN app.well_child_tests G ON (A.Well_Child_Test_Type=g.well_child_test_type_id) --KOC1316
        WHERE a.clm_bill_seq_id = v_claim_bill_seq_id ORDER BY a.clm_bill_dtl_seq_id ;
  END select_lineitems_list;

  -- =================================================================================================================
  PROCEDURE select_lineitem(
    v_clm_bill_dtl_seq_id                 IN clm_bill_details.clm_bill_dtl_seq_id%TYPE,
    lineitem_cur                          OUT SYS_REFCURSOR
  )
  IS
  BEGIN
    OPEN lineitem_cur FOR SELECT
             a.clm_bill_dtl_seq_id, a.clm_bill_seq_id, a.description,a.ward_type_id||'#'|| TO_CHAR(capture_number_of_days_yn) AS ward_type_id ,b.ward_description,
             a.requested_amount , a.Allowed_Amount, a.room_type_id, a.number_of_days ,
             a.allow_yn , a.rejected_amount , a.remarks , c.room_description,a.no_of_visits,i.claim_sub_general_type_id, --Added for koc1320
             a.vaccination_type_id,d.vaccination_description,  --KOC1164
             e.immunization_type_id,e.immunization_description,
             f.rout_adult_vacc_type_id,f.rout_adult_vacc_description,
             g.well_child_test_type_id,g.well_child_test_description
        FROM clm_bill_details a INNER JOIN tpa_hosp_ward_code b ON ( a.ward_type_id = b.ward_type_id )
             LEFT OUTER JOIN tpa_hosp_rooms_code C ON (a.room_type_id = c.room_type_id)
             INNER JOIN clm_bill_header h ON (a.clm_bill_seq_id = h.clm_bill_seq_id)--Added for koc1320
             INNER JOIN clm_general_details i ON (h.claim_seq_id = i.claim_seq_id)--Added for koc1320
             LEFT OUTER JOIN app.tpa_vaccination_code D ON (a.vaccination_type_id=d.vaccination_id)  --KOC1164
             LEFT OUTER JOIN app.child_vaccination_code E ON (a.child_immnunization=e.immunization_type_id) --KOC1315
             LEFT OUTER JOIN app.rout_adult_vaccination_code F ON (A.Rout_Adult_Phys_Exam=f.rout_adult_vacc_type_id) --KOC1308
             LEFT OUTER JOIN app.well_child_tests G ON (A.Well_Child_Test_Type=g.well_child_test_type_id) --KOC1316
       WHERE a.clm_bill_dtl_seq_id = v_clm_bill_dtl_seq_id ORDER BY a.clm_bill_dtl_seq_id ;
  END select_lineitem;
  -- =================================================================================================================
  PROCEDURE select_clm_shortfall_list(
    v_tpa_enrollment_id              IN  CLM_ENROLL_DETAILS.tpa_enrollment_id%TYPE,
    v_claimant_name                  IN  CLM_ENROLL_DETAILS.claimant_name%TYPE,
    v_claim_number                   IN  CLM_GENERAL_DETAILS.claim_number%TYPE,
    v_sort_var                       IN  VARCHAR2 ,
    v_sort_order                     IN  VARCHAR2 ,
    v_start_num                      IN  NUMBER,
    v_end_num                        IN  NUMBER ,
    v_added_by                       IN  NUMBER,
    result_set                       OUT SYS_REFCURSOR
  )
  IS
    TYPE bind_tab_type IS TABLE OF VARCHAR2(250) INDEX BY BINARY_INTEGER ;
    v_sql_str                      VARCHAR2(4000);
    v_where                              VARCHAR2(2000);
    bind_tab                             bind_tab_type;
    i                                    NUMBER(2) := 0;
  BEGIN
    v_sql_str :=
      ' SELECT
       A.Claim_Seq_Id,
       a.claim_number,
       b.member_seq_id,
       b.tpa_enrollment_id,
       b.claimant_name,
       decode(b.gender_general_type_id,''MAL'',''Male'',''FEM'',''Female'',''Eunuch'') AS gender,
       b.mem_age
       FROM clm_general_details A JOIN clm_enroll_details B ON ( A.claim_seq_id = B.claim_seq_id) ';

    IF v_tpa_enrollment_id IS NOT NULL THEN
       -- like changed to =
       v_where := v_where || ' AND b.tpa_enrollment_id = :v_tpa_enrollment_id ';
       i := i+1;
       bind_tab(i) := UPPER(v_tpa_enrollment_id);
    END IF;

    IF v_claim_number IS NOT NULL THEN
       v_where := v_where || ' AND a.claim_number = :v_claim_number ';
       i := i+1;
       bind_tab(i) := v_claim_number;
    END IF;

    IF v_claimant_name IS NOT NULL THEN
       v_where := v_where || ' AND b.claimant_name LIKE :v_claimant_name ';
       i := i+1;
       bind_tab(i) := UPPER(v_claimant_name)||'%';
    END IF;
    IF v_where IS NOT NULL THEN
      v_where := ' WHERE '|| SUBSTR(v_where,5);
      v_sql_str := v_sql_str ||v_where;
    END IF;

    v_sql_str := 'SELECT * FROM
            (SELECT A.*,DENSE_RANK() OVER (ORDER BY '||v_sort_var||' '||v_sort_order||',ROWNUM) Q FROM (' ||v_sql_str|| ') A )
             WHERE  Q>= :v_start_num AND Q<= :v_end_num ';
    IF bind_tab.FIRST IS NOT NULL THEN
       CASE bind_tab.COUNT
         WHEN 1 THEN OPEN result_set FOR v_sql_str USING bind_tab(1) , v_start_num , v_end_num ;
         WHEN 2 THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2), v_start_num , v_end_num ;
         WHEN 3 THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2), bind_tab(3), v_start_num , v_end_num ;
       END CASE;
    ELSE
      OPEN result_set FOR v_sql_str USING  v_start_num , v_end_num ;
    END IF;
  END select_clm_shortfall_list;
--========================================================================================================================================
  PROCEDURE select_open_shortfall_list (
    v_claim_seq_id               IN clm_general_details.claim_seq_id%TYPE,
    v_shortfall_id               IN clm_inward.shortfall_id%TYPE,
    result_set                   OUT SYS_REFCURSOR
  )
  IS
  BEGIN
    OPEN result_set FOR
      SELECT
       a.shortfall_seq_id,
       a.shortfall_id
       FROM shortfall_details a
       WHERE a.claim_seq_id = v_claim_seq_id AND
         ( a.srtfll_status_general_type_id = 'OPN' OR a.shortfall_id = v_shortfall_id );
  END select_open_shortfall_list;
 --==============================================================================================
 --   Name       : SAVE_REJECTION_CLAUSES
 --   Created on-09-JUL-07
 --   Created By-
 --   Comments   :
 --==============================================================================================
  PROCEDURE save_rejection_clauses(
    v_claim_seq_id                       IN  TPA_REJECTION_CLAUSES.claim_seq_id%TYPE,
    v_pat_enroll_detail_seq_id           IN  TPA_REJECTION_CLAUSES.pat_enroll_detail_seq_id%TYPE,
    v_clause_seq_ids                     IN  VARCHAR2, -- '|' concatenated string of select clause seq_ids
    v_rej_header_info                    IN  clm_general_details.rej_header_info%TYPE,
    v_rej_footer_info                    IN  clm_general_details.rej_footer_info%TYPE,
    v_ltr_general_type_id                IN  clm_general_details.ltr_general_type_id%TYPE,
    v_added_by                           IN  TPA_REJECTION_CLAUSES.added_by%TYPE,
    v_rejection_remarks                  OUT VARCHAR2,
    v_rows_processed                     IN  OUT NUMBER
  )
  IS
    PRAGMA AUTONOMOUS_TRANSACTION ;
    v_rej_clause_seq_id                  TPA_REJECTION_CLAUSES.rej_clause_seq_id%TYPE;
    str_tab                              ttk_util_pkg.str_table_type;
    v_str                                VARCHAR2(2000);
    v_cur                                SYS_REFCURSOR;
    v_flag                               VARCHAR2(3);

    v_completed_yn                       clm_general_details.completed_yn%TYPE;

    CURSOR rej_clause_cur (v_flag VARCHAR2, v_clause_seq_id  NUMBER )IS
      SELECT a.rej_clause_seq_id  FROM tpa_rejection_clauses a
     WHERE ( v_flag = 'CLM' AND a.claim_seq_id = v_claim_seq_id
                 OR v_flag = 'PAT' AND a.pat_enroll_detail_seq_id = v_pat_enroll_detail_seq_id )
              AND a.clause_seq_id = v_clause_seq_id ;

  BEGIN
     claims_freeze(v_claim_seq_id,NULL,'S'); --KOCBJJ

    IF v_claim_seq_id IS NOT NULL THEN
      SELECT completed_yn INTO v_completed_yn
        FROM clm_general_details a WHERE a.claim_seq_id = v_claim_seq_id;
    ELSE
      SELECT completed_yn  INTO v_completed_yn
        FROM pat_general_details a JOIN pat_enroll_details b ON (b.pat_enroll_detail_seq_id = a.pat_enroll_detail_seq_id AND a.pat_enhanced_yn = 'N' )
         WHERE b.pat_enroll_detail_seq_id = v_pat_enroll_detail_seq_id ;
    END IF;
    IF v_completed_yn = 'Y' THEN
      RAISE_APPLICATION_ERROR(-20107,' You cannot modify this Pre-Auth , Reviews are Completed');
    END IF;

    IF LENGTH(v_clause_seq_ids) > 2 THEN
      IF v_claim_seq_id IS NOT NULL THEN
        EXECUTE IMMEDIATE ' DELETE FROM TPA_REJECTION_CLAUSES A WHERE a.claim_seq_id = '||v_claim_seq_id ||' AND a.clause_seq_id NOT IN ('|| REPLACE(substr(v_clause_seq_ids,2,length(v_clause_seq_ids)-2),'|',',')||')' ;
      ELSE
        EXECUTE IMMEDIATE ' DELETE FROM TPA_REJECTION_CLAUSES A WHERE a.pat_enroll_detail_seq_id = '||v_pat_enroll_detail_seq_id ||' AND  a.clause_seq_id NOT IN ('|| REPLACE(substr(v_clause_seq_ids,2,length(v_clause_seq_ids)-2),'|',',')||')' ;
      END IF;

      IF v_pat_enroll_detail_seq_id IS NOT NULL THEN
        v_str :=   ' SELECT substr(sys_connect_by_path(clause_description,'',''),2)
            FROM ( SELECT a.clause_description, rownum AS rnum , COUNT(1) over (ORDER BY ''1'') AS cnt  FROM tpa_prod_policy_clauses a WHERE a.clause_seq_id IN ('|| REPLACE(substr(v_clause_seq_ids,2,length(v_clause_seq_ids)-2),'|',',')||'))
                   WHERE rnum = cnt  START WITH rnum = 1 CONNECT BY PRIOR rnum+1 = rnum ' ;
        OPEN  v_cur FOR v_str;
        FETCH v_cur INTO v_rejection_remarks;
        CLOSE v_cur;
        v_rejection_remarks := SUBSTR(v_rejection_remarks,1,2000);
      END IF;
    ELSE
      IF v_claim_seq_id IS NOT NULL THEN
        DELETE FROM tpa_rejection_clauses a WHERE a.claim_seq_id = v_claim_seq_id ;
      ELSE
        DELETE FROM tpa_rejection_clauses a WHERE a.pat_enroll_detail_seq_id = v_pat_enroll_detail_seq_id;
      END IF;
    END IF;

    IF v_claim_seq_id IS NOT NULL THEN
      v_flag := 'CLM';
    ELSE
      v_flag := 'PAT';
    END IF;

    str_tab := ttk_util_pkg.parse_str( v_clause_seq_ids );

    IF str_tab.FIRST IS NOT NULL THEN
      FOR i IN str_tab.FIRST .. str_tab.LAST
      LOOP
        v_rej_clause_seq_id := NULL;

        OPEN rej_clause_cur(v_flag,str_tab(i));
        FETCH rej_clause_cur INTO v_rej_clause_seq_id;
        CLOSE rej_clause_cur;

        IF NVL(v_rej_clause_seq_id,0) = 0  THEN
          INSERT INTO tpa_rejection_clauses(
            rej_clause_seq_id,
            pat_enroll_detail_seq_id,
            claim_seq_id,
            clause_seq_id,
            added_by,
            added_date )
          VALUES (
            tpa_rejection_clauses_seq.NEXTVAL ,
            v_pat_enroll_detail_seq_id,
            v_claim_seq_id,
            str_tab(i),
            v_added_by,
            SYSDATE );
        END IF;
      END LOOP;
    END IF;
    IF v_claim_seq_id IS NOT NULL THEN
      UPDATE clm_general_details a SET
        a.rej_header_info = v_rej_header_info ,
        a.rej_footer_info = v_rej_footer_info ,
        a.ltr_general_type_id = v_ltr_general_type_id,
        a.updated_by      = v_added_by,
        a.updated_date    = SYSDATE
        WHERE a.claim_seq_id = v_claim_seq_id;

    END IF;
    v_rows_processed := SQL%ROWCOUNT;
    COMMIT;
  END save_rejection_clauses;

--=============================================================================================
  PROCEDURE select_rejection_clauses (
     v_claim_seq_id               IN clm_general_details.claim_seq_id%TYPE,
     v_pat_enroll_detail_seq_id   IN pat_enroll_details.pat_enroll_detail_seq_id%TYPE,
     v_policy_seq_id              IN clm_enroll_details.policy_seq_id%TYPE,
     v_enrol_type_id              IN clm_enroll_details.enrol_type_id%TYPE,
     v_date_of_hospitalization    IN DATE,
     v_resultset                  OUT SYS_REFCURSOR,
     v_rej_remarks                OUT SYS_REFCURSOR -- USE THIS ONLY IN THE CASE OF CLAIMS.
   )
   IS
     CURSOR policy_cur IS SELECT a.prod_policy_seq_id
       FROM tpa_ins_prod_policy a  WHERE a.policy_seq_id = v_policy_seq_id ;

     CURSOR product_cur IS SELECT b.prod_policy_seq_id
       FROM tpa_enr_policy a JOIN tpa_ins_prod_policy b ON (a.product_seq_id = b.product_seq_id)
       WHERE a.policy_seq_id = v_policy_seq_id ;

     v_cur_rec                    policy_cur%ROWTYPE;
   BEGIN
     IF v_enrol_type_id = 'COR' THEN
       OPEN policy_cur;
       FETCH policy_cur INTO v_cur_rec;
       CLOSE policy_cur;
     ELSE
       OPEN product_cur;
       FETCH product_cur INTO v_cur_rec;
       CLOSE product_cur;
     END IF;


     IF v_claim_seq_id IS NOT NULL THEN
       OPEN v_resultset FOR
         SELECT
         a.clause_seq_id,
         a.clause_number,
         a.clause_description,
         CASE WHEN b.rej_clause_seq_id IS NULL THEN 'N' ELSE 'Y' END AS selected_yn,
         a.prod_policy_seq_id
         FROM tpa_prod_policy_clauses a LEFT OUTER JOIN tpa_rejection_clauses b ON (a.clause_seq_id = b.clause_seq_id AND b.claim_seq_id = v_claim_seq_id )
         WHERE a.prod_policy_seq_id = v_cur_rec.prod_policy_seq_id
         AND ( a.active_yn = 'Y' OR b.clause_seq_id IS NOT NULL )
         ORDER BY a.clause_number ;

       OPEN v_rej_remarks FOR
         SELECT
          a.rej_header_info ,
          a.rej_footer_info ,
          a.ltr_general_type_id,
          b.claim_general_type_id ,
          d.ins_head_office_seq_id AS ins_seq_id
          FROM clm_general_details a JOIN clm_inward b ON (a.claims_inward_seq_id = b.claims_inward_seq_id)
          JOIN clm_enroll_details C ON (a.claim_seq_id = c.claim_seq_id)
          LEFT OUTER JOIN tpa_ins_info d ON (c.ins_seq_id = d.ins_seq_id)
          WHERE a.claim_seq_id = v_claim_seq_id  ;
     ELSE
        OPEN v_resultset FOR
         SELECT
           a.clause_seq_id,
           a.clause_number,
           a.clause_description,
           CASE WHEN b.rej_clause_seq_id IS NULL THEN 'N' ELSE 'Y' END AS selected_yn,
           a.prod_policy_seq_id
           FROM tpa_prod_policy_clauses a LEFT OUTER JOIN tpa_rejection_clauses b ON (a.clause_seq_id = b.clause_seq_id AND b.pat_enroll_detail_seq_id  = v_pat_enroll_detail_seq_id )
           WHERE a.prod_policy_seq_id = v_cur_rec.prod_policy_seq_id
           AND ( a.active_yn = 'Y' OR b.clause_seq_id IS NOT NULL )
           ORDER BY a.clause_number ;
     END IF;

   END select_rejection_clauses;
--==============================================================================================
  FUNCTION check_dv_required(v_claim_seq_id   IN clm_general_details.claim_seq_id%TYPE ) RETURN CHAR
  IS

   v_message                            CHAR(1) := 'N';

    CURSOR clm_cur IS SELECT c.claim_general_type_id ,
      CASE WHEN b.enrol_type_id = 'COR' THEN f.dv_reqd_general_type_id ELSE g.dv_reqd_general_type_id END AS dv_reqd_general_type_id
      FROM clm_general_details a JOIN clm_enroll_details b ON ( a.claim_seq_id = b.claim_seq_id )
      JOIN clm_inward c ON (a.claims_inward_seq_id = c.claims_inward_seq_id)
      LEFT OUTER JOIN tpa_enr_policy e ON (b.policy_seq_id = e.policy_seq_id)
      LEFT OUTER JOIN tpa_ins_prod_policy f ON (b.policy_seq_id = f.policy_seq_id)
      LEFT OUTER JOIN tpa_ins_prod_policy g ON (e.product_seq_id = g.product_seq_id)
      WHERE a.claim_seq_id = v_claim_seq_id;

    clm_rec                       clm_cur%ROWTYPE;
  BEGIN
    OPEN  clm_cur;
    FETCH clm_cur INTO clm_rec;
    CLOSE clm_cur;

    IF clm_rec.claim_general_type_id != 'CNH' THEN
      IF clm_rec.dv_reqd_general_type_id = 'DRQ' THEN
        v_message := 'Y';
      ELSIF clm_rec.dv_reqd_general_type_id = 'DVN' THEN
        v_message := 'N';
      ELSE
        v_message := 'O';
      END IF;
    END IF;
    RETURN v_message;
  END check_dv_required;
--==============================================================================================
  PROCEDURE check_dv_required(v_claim_seq_id   IN clm_general_details.claim_seq_id%TYPE )
  IS

    CURSOR clm_cur IS SELECT a.completed_yn , b.clm_status_general_type_id , c.claim_general_type_id ,
       b.policy_seq_id , h.claim_payment_status ,
      CASE WHEN b.enrol_type_id = 'COR' THEN f.dv_reqd_general_type_id ELSE g.dv_reqd_general_type_id END AS dv_reqd_general_type_id
      FROM clm_general_details a JOIN clm_enroll_details b ON ( a.claim_seq_id = b.claim_seq_id )
      JOIN clm_inward c ON (a.claims_inward_seq_id = c.claims_inward_seq_id)
      LEFT OUTER JOIN tpa_enr_policy e ON (b.policy_seq_id = e.policy_seq_id)
      LEFT OUTER JOIN tpa_ins_prod_policy f ON (b.policy_seq_id = f.policy_seq_id)
      LEFT OUTER JOIN tpa_ins_prod_policy g ON (e.product_seq_id = g.product_seq_id)
      LEFT OUTER JOIN tpa_claims_payment h ON (a.claim_seq_id = h.claim_seq_id)
      WHERE a.claim_seq_id = v_claim_seq_id;
    clm_rec                       clm_cur%ROWTYPE;
  BEGIN
    OPEN clm_cur;
    FETCH clm_cur INTO clm_rec;
    CLOSE clm_cur;

    IF clm_rec.clm_status_general_type_id != 'APR' OR clm_rec.completed_yn = 'N' THEN
      RAISE_APPLICATION_ERROR(-20159,' Please complete the settlement ');
    END IF;

    IF clm_rec.claim_general_type_id = 'CNH' THEN
      RAISE_APPLICATION_ERROR(-20181,'Discharge voucher is not required for Network Claim.');
    END IF;

    IF clm_rec.dv_reqd_general_type_id = 'DVN' THEN
      RAISE_APPLICATION_ERROR(-20193,'Discharge voucher not allowed.');
    ELSIF clm_rec.dv_reqd_general_type_id = 'DVO' AND clm_rec.claim_payment_status != 'PENDING' THEN
      RAISE_APPLICATION_ERROR(-20194,'Discharge voucher not allowed , Claim processing started in Finance.');
    END IF;

  END check_dv_required;
  --===================================================================================
  PROCEDURE get_letter_to (
    v_claim_general_type_id             IN VARCHAR2,
    v_ins_seq_id                        IN NUMBER,
    v_resultset                         OUT SYS_REFCURSOR
  )
  IS
  BEGIN
   OPEN v_resultset FOR SELECT B.general_type_id, B.description
      FROM tpa_ins_rejection_ltr_info A JOIN tpa_general_code B ON (A.ltr_to_general_type_id = B.general_type_id)
       AND B.header_type='REJECTION_LETTER_TYPE' AND A.claim_general_type_id = v_claim_general_type_id
         AND NVL(A.ins_seq_id,0) = NVL(v_ins_seq_id,0);
  END get_letter_to;
  --===================================================================================
   PROCEDURE select_doctor_opinion(
     v_claim_seq_id                               IN ailment_details.claim_seq_id%TYPE,
     v_result_set                                 OUT SYS_REFCURSOR
   )
   IS
   BEGIN
     OPEN v_result_set FOR
       SELECT
       a.doctor_opinion,
       a.doctor_opinion_by,
       b.contact_name
       FROM ailment_details a JOIN tpa_user_contacts b ON (a.doctor_opinion_by = b.contact_seq_id)
       WHERE a.claim_seq_id = v_claim_seq_id;

   END select_doctor_opinion;
  --===================================================================================
  PROCEDURE save_doctor_opinion(
     v_claim_seq_id                               IN ailment_details.claim_seq_id%TYPE,
     v_doctor_opinion                             IN ailment_details.doctor_opinion%TYPE,
     v_added_by                                   IN NUMBER,
     v_rows_processed                             OUT NUMBER
   )
   IS
     PRAGMA AUTONOMOUS_TRANSACTION;
     v_completed_yn                               clm_general_details.completed_yn%TYPE;

   BEGIN
     SELECT completed_yn INTO v_completed_yn
       FROM clm_general_details WHERE claim_seq_id= v_claim_seq_id;

     IF v_completed_yn = 'Y' THEN
       raise_application_error(-20152 ,' Modification Not Allowed , Reviews are Completed ');
     END IF;
    claims_pkg.claims_freeze(v_claim_seq_id,NULL,'S');--KOCBJJ

     UPDATE ailment_details a SET
       a.doctor_opinion      = v_doctor_opinion,
       a.doctor_opinion_by   = v_added_by,
       a.updated_by          = v_added_by,
       a.updated_date        = SYSDATE
       WHERE a.claim_seq_id = v_claim_seq_id;
     v_rows_processed := SQL%ROWCOUNT;
     COMMIT;
   END save_doctor_opinion;
  --===================================================================================
  PROCEDURE correct_clm_buff_header(
     v_claim_seq_id                IN CLM_GENERAL_DETAILS.claim_seq_id%TYPE,
     v_pat_enroll_detail_seq_id    IN PAT_ENROLL_DETAILS.PAT_ENROLL_DETAIL_SEQ_ID%TYPE,
     v_buffer_hdr_seq_id           IN BUFFER_HEADER.buffer_hdr_seq_id%TYPE,
     v_deduct_amt                  IN NUMBER,
     v_flag                        IN VARCHAR2  --     'BTH' for both preauth and claim , 'CLM' for claim alone
  )
  IS
    v_buff_amount                  NUMBER(16,2) := v_deduct_amt;
    v_update_amt                   NUMBER(16,2);
    v_clm_deduct_amt               NUMBER(16,2);
    v_pat_deduct_amt               NUMBER(16,2);
  BEGIN

    FOR i IN (SELECT a.buff_detail_seq_id, a.buffer_app_amount
                   FROM buffer_details a WHERE a.buffer_hdr_seq_id = v_buffer_hdr_seq_id
                  AND a.claim_seq_id IS NOT NULL ORDER BY a.buffer_approved_date DESC)
    LOOP
      v_update_amt := 0;
      IF i.buffer_app_amount >= v_buff_amount THEN
        v_update_amt := i.buffer_app_amount - v_buff_amount;
        v_buff_amount := 0;
      ELSE
        v_update_amt  := 0;
        v_buff_amount := v_buff_amount - i.buffer_app_amount;
      END IF;
      UPDATE buffer_details a SET
        a.buffer_app_amount = v_update_amt,
        a.approver_remarks  = a.approver_remarks||' Approved amount reduced after completion,for override/amendment.' ,
        a.updated_by        = 1,
        a.updated_date      = SYSDATE
        WHERE a.buff_detail_seq_id = i.buff_detail_seq_id;

      EXIT WHEN v_buff_amount = 0;
    END LOOP;

    v_clm_deduct_amt := CASE WHEN v_deduct_amt != v_buff_amount THEN v_deduct_amt - v_buff_amount ELSE v_deduct_amt END;

    IF v_flag = 'BTH' AND v_buff_amount != 0 THEN
      FOR i IN (SELECT a.buff_detail_seq_id, a.buffer_app_amount
                     FROM buffer_details a WHERE a.buffer_hdr_seq_id = v_buffer_hdr_seq_id
                    AND a.pat_gen_detail_seq_id IS NOT NULL ORDER BY a.buffer_approved_date DESC)
      LOOP
        v_update_amt := 0;
        IF i.buffer_app_amount >= v_buff_amount THEN
          v_update_amt := i.buffer_app_amount - v_buff_amount;
          v_buff_amount := 0;
        ELSE
          v_update_amt  := 0;
          v_buff_amount := v_buff_amount - i.buffer_app_amount;
        END IF;
        UPDATE buffer_details a SET
          a.buffer_app_amount = v_update_amt,
          a.approver_remarks  = a.approver_remarks||' Approved amount reduced after completion,for override/amendment.' ,
          a.updated_by        = 1,
          a.updated_date      = SYSDATE
          WHERE a.buff_detail_seq_id = i.buff_detail_seq_id;

        EXIT WHEN v_buff_amount = 0;
      END LOOP;
      v_pat_deduct_amt  := v_deduct_amt - v_clm_deduct_amt;
    END IF;
    UPDATE buffer_header a SET
      a.pre_auth_buffer_app_amount = CASE WHEN nvl(a.pre_auth_buffer_app_amount,0) != 0 THEN a.pre_auth_buffer_app_amount - nvl(v_pat_deduct_amt,0) ELSE a.pre_auth_buffer_app_amount END,
      a.claim_app_buffer_amount = CASE WHEN nvl(a.claim_app_buffer_amount,0) != 0 THEN a.claim_app_buffer_amount - nvl(v_clm_deduct_amt,0) ELSE a.claim_app_buffer_amount END,
      a.updated_by = 1 ,
      a.updated_date = SYSDATE
      WHERE a.buffer_hdr_seq_id = v_buffer_hdr_seq_id;

  END correct_clm_buff_header;
-- =================================================================================================================
  PROCEDURE check_revert_buffer(
    v_claim_seq_id                   IN clm_general_details.claim_seq_id%TYPE,
    v_added_by                       IN NUMBER
  )
  IS
    CURSOR claim_cur IS SELECT a.enrol_type_id , b.pat_enroll_detail_seq_id,a.member_seq_id,a.policy_seq_id, c.buffer_alloc_general_type_id,
       NVL(e.buffer_hdr_seq_id,i.buffer_hdr_seq_id) AS buffer_hdr_seq_id,
       NVL(e.pre_auth_buffer_app_amount,i.pre_auth_buffer_app_amount) AS pre_auth_buffer_app_amount,
       NVL(e.claim_app_buffer_amount,i.claim_app_buffer_amount) AS claim_app_buffer_amount,
       NVL(e.utilised_amount,i.utilised_amount) AS utilised_amount,
       nvl(h.claim_type,d.claim_type) as claim_type,nvl(h.buffer_type,d.buffer_type) as buffer_type
       FROM clm_enroll_details a JOIN clm_general_details b ON (a.claim_seq_id = b.claim_seq_id)
       JOIN tpa_enr_policy c ON (a.policy_seq_id = c.policy_seq_id)
       LEFT OUTER JOIN buffer_details d ON (b.last_buffer_detail_seq_id = d.buff_detail_seq_id)
       LEFT OUTER JOIN buffer_header e ON (d.buffer_hdr_seq_id = e.buffer_hdr_seq_id)
       LEFT OUTER JOIN pat_enroll_details f ON (b.pat_enroll_detail_seq_id = f.pat_enroll_detail_seq_id)
       LEFT OUTER JOIN pat_general_details g ON (f.pat_enroll_detail_seq_id = g.pat_enroll_detail_seq_id AND g.pat_enhanced_yn = 'N')
       LEFT OUTER JOIN buffer_details H ON (G.last_buffer_detail_seq_id = H.buff_detail_seq_id)
       LEFT OUTER JOIN buffer_header I ON (H.buffer_hdr_seq_id = I.buffer_hdr_seq_id)
       WHERE a.claim_seq_id = v_claim_seq_id;
    claim_rec                     claim_cur%ROWTYPE;

    CURSOR balance_cur IS SELECT B.balance_seq_id,b.policy_group_seq_id, b.buffer_amount,b.utilised_buff_amount,a.mem_general_type_id , c.mem_buffer_seq_id ,c.used_buff_amount,
      b.med_buffer_amount,b.critical_buff_amount,b.critical_corp_buff_amount,b.critical_med_buff_amount,
      c.used_med_buff_amt,c.used_crit_buff_amt,c.used_crit_corp_buff_amt,c.used_crit_med_buff_amt
      FROM tpa_enr_policy_member a JOIN tpa_enr_balance b ON (a.policy_group_seq_id = b.policy_group_seq_id)
      LEFT OUTER JOIN tpa_enr_mem_buffer c ON (a.member_seq_id = c.member_seq_id)
      WHERE a.member_seq_id = claim_rec.member_seq_id  AND ( a.mem_general_type_id = 'PNF' AND b.member_seq_id = claim_rec.member_seq_id OR
                                         a.mem_general_type_id != 'PNF' AND b.member_seq_id IS NULL );

    balance_rec                   balance_cur%ROWTYPE;
    v_reqd_buff_amt               NUMBER(16,2);
  BEGIN
    OPEN claim_cur;
    FETCH claim_cur INTO claim_rec;
    CLOSE claim_cur;

    IF claim_rec.enrol_type_id = 'COR' THEN

      v_reqd_buff_amt := NVL(claim_rec.pre_auth_buffer_app_amount,0) + NVL(claim_rec.claim_app_buffer_amount,0) - NVL(claim_rec.utilised_amount,0);
      IF claim_rec.buffer_hdr_seq_id IS NOT NULL AND NVL(v_reqd_buff_amt,0) > 0 THEN
        OPEN balance_cur;
        FETCH balance_cur INTO balance_rec;
        CLOSE balance_cur;
        
        /* This variable is for getting the remaining buffer approved amount , put back to pool at the time of completion of the parent claim  */
        IF claim_rec.buffer_alloc_general_type_id = 'BAI' THEN
          UPDATE tpa_enr_balance a SET
       --       a.utilised_buff_amount = a.utilised_buff_amount - v_reqd_buff_amt,
              a.utilised_buff_amount = case when claim_rec.claim_type='NRML' AND claim_rec.Buffer_Type='CORB' THEN  a.utilised_buff_amount - v_reqd_buff_amt ELSE  utilised_buff_amount END,
              a.utilised_med_buff_amount =case when claim_rec.claim_type='NRML' AND claim_rec.Buffer_Type='MEDB' THEN  a.utilised_med_buff_amount - v_reqd_buff_amt ELSE  utilised_med_buff_amount END,
              a.utilised_crit_buff_amount =case when claim_rec.claim_type='CRTL' AND claim_rec.Buffer_Type='CRTB' THEN  a.utilised_crit_buff_amount - v_reqd_buff_amt ELSE  utilised_crit_buff_amount END,
              a.utilised_crit_corp_buff_amt =case when claim_rec.claim_type='CRTL' AND claim_rec.Buffer_Type='CORB' THEN  a.utilised_crit_corp_buff_amt - v_reqd_buff_amt ELSE  utilised_crit_corp_buff_amt END,
              a.utilised_crit_med_buff_amt = case when claim_rec.claim_type='CRTL' AND claim_rec.Buffer_Type='MEDB' THEN  a.utilised_crit_med_buff_amt  - v_reqd_buff_amt ELSE  utilised_crit_med_buff_amt END,
              a.updated_by             = v_added_by,
              a.updated_date           = SYSDATE
              WHERE a.balance_seq_id = balance_rec.balance_seq_id ;
        ELSIF claim_rec.buffer_alloc_general_type_id = 'BAF' THEN
          UPDATE tpa_enr_balance a SET
      --        a.utilised_buff_amount = a.utilised_buff_amount - v_reqd_buff_amt,
              a.utilised_buff_amount = case when claim_rec.claim_type='NRML' AND claim_rec.Buffer_Type='CORB' THEN  a.utilised_buff_amount - v_reqd_buff_amt ELSE  utilised_buff_amount END,
              a.utilised_med_buff_amount =case when claim_rec.claim_type='NRML' AND claim_rec.Buffer_Type='MEDB' THEN  a.utilised_med_buff_amount - v_reqd_buff_amt ELSE  utilised_med_buff_amount END,
              a.utilised_crit_buff_amount =case when claim_rec.claim_type='CRTL' AND claim_rec.Buffer_Type='CRTB' THEN  a.utilised_crit_buff_amount - v_reqd_buff_amt ELSE  utilised_crit_buff_amount END,
              a.utilised_crit_corp_buff_amt =case when claim_rec.claim_type='CRTL' AND claim_rec.Buffer_Type='CORB' THEN  a.utilised_crit_corp_buff_amt - v_reqd_buff_amt ELSE  utilised_crit_corp_buff_amt END,
              a.utilised_crit_med_buff_amt = case when claim_rec.claim_type='CRTL' AND claim_rec.Buffer_Type='MEDB' THEN  a.utilised_crit_med_buff_amt  - v_reqd_buff_amt ELSE  utilised_crit_med_buff_amt END,
              a.updated_by             = v_added_by,
              a.updated_date           = SYSDATE
              WHERE a.policy_group_seq_id = balance_rec.policy_group_seq_id ;
        END IF;

        IF balance_rec.mem_buffer_seq_id IS NOT NULL THEN
          pre_auth_pkg.save_mem_buffer( balance_rec.mem_buffer_seq_id, claim_rec.policy_seq_id, balance_rec.policy_group_seq_id, claim_rec.member_seq_id , v_reqd_buff_amt * -1 ,v_added_by,claim_rec.claim_type,claim_rec.buffer_type);
        END IF;
      END IF;
    END IF;
  END check_revert_buffer;
-- =================================================================================================================
  PROCEDURE check_cash_benefit(
    v_clm_cash_benefit_seq_id  IN OUT clm_cash_benefit.clm_cash_benefit_seq_id%TYPE,
    v_claim_seq_id             IN clm_general_details.claim_seq_id%TYPE,
    v_member_seq_id            IN tpa_enr_policy_member.member_seq_id%TYPE,
    v_claim_file_number        IN clm_general_details.claim_file_number%TYPE,
    v_date_of_admission        IN clm_general_details.date_of_admission%TYPE,
    v_date_of_discharge        IN clm_general_details.date_of_discharge%TYPE,
    v_added_by                 IN NUMBER
  )
  IS
    CURSOR mem_cur IS SELECT c.cash_benefit_amt,c.benefit_allowed_days, c.benefit_general_type_id, a.policy_group_seq_id
      FROM tpa_enr_policy_member a JOIN tpa_enr_mem_insured b ON (a.policy_group_seq_id = b.policy_group_seq_id)
      JOIN tpa_ins_product_plan c ON (b.prod_plan_seq_id = c.prod_plan_seq_id)
      WHERE a.member_seq_id = v_member_seq_id
        AND (a.mem_general_type_id = 'PFL' AND b.member_seq_id IS NULL
              OR a.mem_general_type_id != 'PFL' AND b.member_seq_id = v_member_seq_id );

    mem_rec                    mem_cur%ROWTYPE;
    CURSOR mem_days_cur IS SELECT SUM(a.cb_days)
      FROM clm_cash_benefit a WHERE a.member_seq_id = v_member_seq_id AND a.clm_status_general_type_id !='REJ';

    CURSOR family_days_cur IS SELECT SUM(b.cb_days)
      FROM tpa_enr_policy_member a JOIN clm_cash_benefit b ON (a.member_seq_id = b.member_seq_id)
      WHERE a.policy_group_seq_id = mem_rec.policy_group_seq_id AND b.clm_status_general_type_id != 'REJ';

    v_used_days                    NUMBER(5);
    v_available_days               NUMBER(5);
    v_cb_days                      clm_cash_benefit.cb_days%TYPE;
    v_ctr                          NUMBER(3);
--KOC1270
  v_cb_amt                       clm_cash_benefit.cb_approved_amount%TYPE:=0;
  v_tot_amt                       clm_cash_benefit.cb_approved_amount%TYPE:=0;
  v_tot_days                      clm_cash_benefit.cb_days%TYPE:=0;
  v_utilised_sum_ins              clm_cash_benefit.Utilised_Sumins%TYPE:=0;
  v_utilised_bonus                clm_cash_benefit.utilised_bonus%TYPE:=0;
  v_hcb_amt                       clm_cash_benefit.cb_approved_amount%TYPE:=0;
  v_hcb_days                      clm_cash_benefit.cb_days%TYPE:=0;
  v_conv_amt                      clm_cash_benefit.cb_approved_amount%TYPE:=0;
  v_conv_days                     clm_cash_benefit.cb_days%TYPE:=0;
--KOC1270
    CURSOR hcb_count_cur IS SELECT COUNT(1)
      FROM clm_cash_benefit a JOIN clm_general_details b ON (a.parent_claim_seq_id = b.claim_seq_id)
      WHERE b.claim_file_number = v_claim_file_number
      AND a.clm_status_general_type_id != 'REJ';

/*    CURSOR hcb_count_cur IS SELECT COUNT(1)
      FROM clm_general_details a
      JOIN clm_enroll_details b ON (a.claim_seq_id=b.claim_seq_id)
      JOIN clm_cash_benefit c ON (b.member_seq_id=c.member_seq_id)
      WHERE a.claim_file_number = v_claim_file_number
      AND c.clm_status_general_type_id != 'REJ';
*/
--KOC1270
cursor mem_info_cur is
  select pol.cbh_sumins_yn,pol.enrol_type_id,pol.product_seq_id,
  pol.policy_seq_id,gr.policy_group_seq_id,
  nvl(gr.hosp_cash_benefit_yn,'N') as hosp_cash_benefit_yn,
  nvl(gr.conv_cash_benefit_yn,'N') as conv_cash_benefit_yn,
   nvl(bal.sum_insured,0) sum_insured, nvl(bal.bonus,0) bonus,nvl(bal.utilised_sum_insured,0) utilised_sum_insured,
   nvl(bal.utilised_cum_bonus,0) utilised_cum_bonus
from tpa_enr_policy_group gr
join tpa_enr_policy_member mem on (mem.policy_group_seq_id = gr.policy_group_seq_id)
join tpa_enr_policy pol on (pol.policy_seq_id = gr.policy_seq_id)
join tpa_enr_balance bal on ((bal.member_seq_id = mem.member_seq_id and
             pol.policy_sub_general_type_id = 'PNF') OR
             (bal.policy_group_seq_id = gr.policy_group_seq_id and
             pol.policy_sub_general_type_id = 'PFL'))
where mem.member_seq_id = v_member_seq_id;

  mem_info_rec                 mem_info_cur%ROWTYPE;

cursor prod_info_cur is
select case when mem_info_rec.enrol_type_id='COR' then nvl(pol.cbh_sumins_yn,'N')
else nvl(prd.cbh_sumins_yn,'N') end as cbh_sumins_yn,pol.product_seq_id,case when mem_info_rec.enrol_type_id='COR' then nvl(pol.conv_sumins_yn,'N')
else nvl(prd.conv_sumins_yn,'N') end as conv_sumins_yn
  from tpa_ins_product prd
join tpa_enr_policy pol on (pol.product_seq_id=prd.product_seq_id)
where pol.policy_seq_id = mem_info_rec.policy_seq_id;

prod_info_rec   prod_info_cur%rowtype;
--KOC1270
  BEGIN
    OPEN mem_cur;
    FETCH mem_cur INTO mem_rec;
    CLOSE mem_cur;

    OPEN hcb_count_cur;
    FETCH hcb_count_cur INTO v_ctr;
    CLOSE hcb_count_cur;
--KOC1270
        OPEN mem_info_cur;
        FETCH mem_info_cur INTO mem_info_rec;
        CLOSE mem_info_cur;
--KOC1270
    IF v_ctr = 0 THEN
--KOC1270
     if mem_info_rec.hosp_cash_benefit_yn = 'N'
       and mem_info_rec.conv_cash_benefit_yn = 'N'  then      ---cash benefit hospital
--KOC1270
      IF mem_rec.benefit_allowed_days > 0 AND mem_rec.cash_benefit_amt > 0 THEN
        IF mem_rec.benefit_general_type_id = 'CBI' THEN
          OPEN mem_days_cur;
          FETCH mem_days_cur INTO v_used_days;
          CLOSE mem_days_cur;
        ELSE
          OPEN family_days_cur;
          FETCH family_days_cur INTO v_used_days;
          CLOSE family_days_cur;
        END IF;
        v_available_days := mem_rec.benefit_allowed_days - NVL(v_used_days,0);
        v_cb_days := trunc(v_date_of_discharge - v_date_of_admission);

        IF v_cb_days > 0 THEN
          IF v_available_days > 0 THEN
            IF  v_cb_days > v_available_days THEN
              v_cb_days := v_available_days;
            END IF;
            INSERT INTO clm_cash_benefit(clm_cash_benefit_seq_id,member_seq_id,parent_claim_seq_id,cb_days,cb_approved_amount,completed_yn,clm_status_general_type_id,added_date,added_by)
            VALUES(clm_cash_benefit_seq.NEXTVAL,v_member_seq_id, v_claim_seq_id,v_cb_days,v_cb_days * mem_rec.cash_benefit_amt,'N','INP',SYSDATE,v_added_by)
            RETURNING clm_cash_benefit_seq_id INTO v_clm_cash_benefit_seq_id;
          END IF;
        END IF;
      END IF;
--KOC1270
 elsif  (mem_info_rec.hosp_cash_benefit_yn = 'Y' or
 mem_info_rec.conv_cash_benefit_yn = 'Y') then

 INSERT INTO clm_cash_benefit(clm_cash_benefit_seq_id,member_seq_id,parent_claim_seq_id,cb_days,cb_approved_amount,completed_yn,clm_status_general_type_id,added_date,added_by,NEW_CASH_BENEFIT_YN,utilised_sumins,utilised_bonus)
       VALUES(clm_cash_benefit_seq.NEXTVAL,v_member_seq_id, v_claim_seq_id,v_tot_days,v_tot_amt,'N','INP',SYSDATE,v_added_by,'Y',0,0)
       RETURNING clm_cash_benefit_seq_id INTO v_clm_cash_benefit_seq_id;


              OPEN prod_info_cur;
              FETCH prod_info_cur INTO prod_info_rec;
              CLOSE prod_info_cur;

if mem_info_rec.hosp_cash_benefit_yn = 'Y' then

      cash_benefit_details(v_claim_seq_id,
                                  v_member_seq_id ,
                                  v_hcb_amt,
                                  v_hcb_days);

v_hcb_amt:= NVL(v_hcb_amt,0);
v_hcb_days:= NVL(v_hcb_days,0);

  if v_hcb_amt > 0 and v_hcb_days > 0 then

v_cb_amt := v_cb_amt + v_hcb_amt;
v_cb_days := v_cb_days + v_hcb_days;

      INSERT INTO app.CLM_CASH_BENEFIT_BILLS(CLM_CASH_BENEFIT_BILL_SEQ_ID,clm_cash_benefit_seq_id,
      member_seq_id,parent_claim_seq_id,WARD_ID,CB_DAYS,CB_APPROVED_AMOUNT,
      added_date,ADDED_BY)
      VALUES(app.CLM_CASH_BENEFIT_BILLS_seq.nextval,v_clm_cash_benefit_seq_id,v_member_seq_id,v_claim_seq_id,'HCB',
      v_hcb_days,v_hcb_amt,SYSDATE,v_added_by);

 end if;

end if;

if mem_info_rec.conv_cash_benefit_yn = 'Y' then

  conv_cash_benefit(v_claim_seq_id,
                        v_member_seq_id,
                        v_conv_amt,
                        v_conv_days);

v_conv_amt:= NVL(v_conv_amt,0);
v_conv_days:= NVL(v_conv_days,0);


if v_conv_amt > 0 and v_conv_days > 0 then

v_cb_amt := nvl(v_cb_amt,0) + v_conv_amt;
v_cb_days :=nvl(v_cb_days,0) + v_conv_days;

      INSERT INTO app.CLM_CASH_BENEFIT_BILLS(CLM_CASH_BENEFIT_BILL_SEQ_ID,clm_cash_benefit_seq_id,
      member_seq_id,parent_claim_seq_id,WARD_ID,CB_DAYS,CB_APPROVED_AMOUNT,
      added_date,ADDED_BY)
      VALUES(app.CLM_CASH_BENEFIT_BILLS_seq.nextval,v_clm_cash_benefit_seq_id,v_member_seq_id,v_claim_seq_id,'COB',
      v_conv_days,v_conv_amt,SYSDATE,v_added_by);

end if;


end if;

if ( prod_info_rec.cbh_sumins_yn = 'Y'
  or prod_info_rec.conv_sumins_yn = 'Y' ) then

  v_tot_amt:= nvl(v_conv_amt,0) + v_hcb_amt;
  v_tot_days:= nvl(v_conv_days,0) + v_hcb_days;

  elsif(( prod_info_rec.cbh_sumins_yn = 'Y'
  or prod_info_rec.conv_sumins_yn = 'Y' )) then

  v_tot_amt:= 0;
  v_tot_days:= 0;


end if;

v_utilised_sum_ins:=0;
v_utilised_bonus:=0;

if nvl(v_tot_amt,0) > 0 and nvl(v_tot_days,0) > 0 then

if ( prod_info_rec.cbh_sumins_yn = 'Y'
  or prod_info_rec.conv_sumins_yn = 'Y' ) then

    v_utilised_sum_ins :=  least(mem_info_rec.sum_insured - mem_info_rec.utilised_sum_insured,v_tot_amt);
    v_utilised_bonus   :=  least(v_tot_amt - least(mem_info_rec.sum_insured - mem_info_rec.utilised_sum_insured, v_tot_amt),mem_info_rec.bonus-mem_info_rec.utilised_cum_bonus);

  end if;

 end if;


update clm_cash_benefit cb
 set   cb.member_seq_id              = v_member_seq_id,
       cb.parent_claim_seq_id        = v_claim_seq_id,
       cb.cb_days                    = v_cb_days,
       cb.cb_approved_amount         = v_cb_amt,
       cb.completed_yn               = 'N',
       cb.clm_status_general_type_id = 'INP',
       cb.added_date                 = sysdate,
       cb.added_by                   = v_added_by,
       cb.NEW_CASH_BENEFIT_YN        = 'Y',
       cb.utilised_sumins            = v_utilised_sum_ins,
       cb.utilised_bonus             = v_utilised_bonus,
       CB.HCB_DAYS                   = v_hcb_days,
       CB.CONV_DAYS                  = v_conv_days
 where cb.clm_cash_benefit_seq_id    = v_clm_cash_benefit_seq_id;


 delete from  clm_cash_benefit cb
 where cb.clm_cash_benefit_seq_id=v_clm_cash_benefit_seq_id
 and nvl(cb.cb_days,0)=0 and nvl(cb.cb_approved_amount,0)=0;

 end if;
--KOC1270
    END IF;
  END check_cash_benefit;
  --===========================================================================================
  PROCEDURE create_cash_benefit_claim (
    v_prev_claim_seq_id                    IN OUT clm_general_details.claim_seq_id%TYPE,
    v_added_by                             IN NUMBER,
    v_clm_status_general_type_id           IN clm_enroll_details.clm_status_general_type_id%TYPE ,
    v_rows_processed                       OUT NUMBER
    -- for the above column ON Approve Button Press pass 'APR' else on Reject Button Press pass 'REJ'
  )
  IS

    CURSOR claim_cur IS SELECT
      A.claims_inward_seq_id ,  A.claim_number ,  A.claim_file_number ,       A.pat_enroll_detail_seq_id ,
      A.auth_number ,     A.request_general_type_id , A.treating_dr_name ,      A.in_patient_no ,
      A.claims_remarks ,   A.discrepancy_present_yn ,    A.date_of_admission ,    A.date_of_discharge ,
      A.claim_settlement_number ,  A.prev_hosp_claim_seq_id  , a.pat_approved_amount, a.ava_sum_insured,
      a.ava_cum_bonus,B.gender_general_type_id ,
      B.member_seq_id ,    B.tpa_enrollment_id ,       B.policy_seq_id ,       B.policy_holder_name ,
      B.employee_no ,     B.employee_name ,      B.mem_age ,      B.claimant_name ,      B.date_of_inception ,
      B.date_of_exit ,   B.relship_type_id ,   B.policy_number ,   B.claimant_phone_number ,
      B.enrol_type_id  ,    B.policy_sub_general_type_id  ,   B.phone_1 ,   B.policy_effective_from ,
      B.policy_effective_to ,    B.ins_status_general_type_id ,    B.ins_seq_id ,    B.group_reg_seq_id,b.mem_total_sum_insured,
      C.claim_general_type_id ,    D.hosp_seq_id ,       D.empanel_number ,       D.hosp_name ,        D.address_1,
      D.address_2 ,       D.address_3 ,       D.state_name ,       D.city_name ,       D.pin_code ,       D.off_phone_no_1,
      D.off_phone_no_2 ,     D.office_fax_no,    D.remarks ,   E.hosp_regist_number ,     E.contact_name  ,
      E.off_phone_no_1 addl_phone,    E.number_of_beds ,       E.fully_equipped_yn , F.buffer_allowed_yn , b.clm_status_general_type_id ,
      a.doctor_registration_no, --B.email_id,
      ttk_util_pkg.fn_decrypt(B.email_id) as email_id, --//ED
      B.notification_phone_number,f.buffer_alloc_general_type_id,
      b.ins_scheme,b.certificate_no, b.ins_customer_code , c.tpa_office_seq_id,c.barcode_no,c.document_general_type_id,
      c.source_general_type_id,c.courier_seq_id,c.corporate_name,C.inward_ins_seq_id,a.clm_cash_benefit_seq_id,
      g.cb_approved_amount,
--KOC1270
      NVL(G.NEW_CASH_BENEFIT_YN,'N') NEW_CASH_BENEFIT_YN,G.PARENT_CLAIM_SEQ_ID,
      nvl(g.utilised_sumins,0) utilised_sumins,nvl(g.utilised_bonus,0) utilised_bonus
--KOC1270
      FROM clm_general_details A JOIN clm_enroll_details B ON (A.claim_seq_id = B.claim_seq_id )
      JOIN clm_inward C ON (a.claims_inward_seq_id = c.claims_inward_seq_id )
      LEFT OUTER JOIN clm_hospital_association D ON ( a.claim_seq_id = d.claim_seq_id )
      LEFT OUTER JOIN clm_hospital_additional_dtl E ON ( d.clm_hosp_assoc_seq_id = e.clm_hosp_assoc_seq_id )
      LEFT OUTER JOIN tpa_enr_policy f ON ( b.policy_seq_id = f.policy_seq_id )
      JOIN clm_cash_benefit g ON (a.clm_cash_benefit_seq_id = g.clm_cash_benefit_seq_id)
      WHERE a.claim_seq_id = v_prev_claim_seq_id;

    claim_rec                     claim_cur%ROWTYPE;
    v_ped_code_id                 icd_pcs_detail.ped_code_id%TYPE;
    v_icd_code                    icd_pcs_detail.icd_code%TYPE := 'Z73.9' ;
    v_clm_bill_seq_id             clm_bill_header.clm_bill_seq_id%TYPE;

    CURSOR icd_cur IS SELECT A.ped_code_id
       FROM tpa_ped_code a WHERE a.icd_code = v_icd_code;

    v_claims_inward_seq_id        clm_inward.claims_inward_seq_id%TYPE;
    v_clm_enroll_detail_seq_id    clm_enroll_details.clm_enroll_detail_seq_id%TYPE;
    v_claim_seq_id                clm_general_details.claim_seq_id%TYPE;
    v_claims_inward_no            clm_inward.claims_inward_no%TYPE;
    v_claim_number                clm_general_details.claim_number%TYPE;
    v_event_seq_id                clm_general_details.event_seq_id%TYPE;
    v_review_num                  pat_event_history.review_num%TYPE;
    v_claim_settlement_number     clm_general_details.Claim_Settlement_Number%TYPE;
    v_assign_users_seq_id         ASSIGN_USERS.assign_users_seq_id%TYPE;
    v_icd_pcs_seq_id              ICD_PCS_DETAIL.icd_pcs_seq_id%TYPE;
    v_approved_amount             clm_cash_benefit.cb_approved_amount%TYPE;
    v_rejected_amount             clm_bill_details.rejected_amount%TYPE;
    v_allow_yn                    clm_bill_details.allow_yn%TYPE;
V_BILL_DESC                   clm_bill_details.remarks%TYPE;  --KOC1270

  --KOC1270
cursor prod_info_cur
is
select case when claim_rec.enrol_type_id='COR' then nvl(pol.cbh_sumins_yn,'N')
else nvl(prd.cbh_sumins_yn,'N') end as cbh_sumins_yn,pol.product_seq_id,case when claim_rec.enrol_type_id='COR' then nvl(pol.conv_sumins_yn,'N')
else nvl(prd.conv_sumins_yn,'N') end as conv_sumins_yn
  from tpa_ins_product prd
join tpa_enr_policy pol on (pol.product_seq_id=prd.product_seq_id)
where pol.policy_seq_id = claim_rec.policy_seq_id;

prod_info_rec   prod_info_cur%rowtype;

  CURSOR mem_cur IS
    SELECT pol.policy_sub_general_type_id,
             a.policy_group_seq_id,
             a.mem_age,
             pol.product_seq_id,
             pol.enrol_type_id,
             pol.policy_seq_id,
             bal.sum_insured,
             bal.bonus,
             bal.balance_seq_id,
             bal.utilised_sum_insured,
             bal.utilised_cum_bonus,
             nvl(gr.hosp_cash_benefit_yn,'N') hosp_cash_benefit_yn,
             nvl(gr.conv_cash_benefit_yn,'N') conv_cash_benefit_yn

        FROM tpa_enr_policy_member a
        join tpa_enr_policy_group gr
          on (a.policy_group_seq_id = gr.policy_group_seq_id)
        join tpa_enr_policy pol on (pol.policy_seq_id = gr.policy_seq_id)
        join tpa_enr_balance bal on ((bal.member_seq_id = a.member_seq_id and
             pol.policy_sub_general_type_id = 'PNF') OR
             (bal.policy_group_seq_id = a.policy_group_seq_id and
             pol.policy_sub_general_type_id = 'PFL'))
       WHERE a.member_seq_id = claim_rec.member_seq_id;

           mem_rec    mem_cur%ROWTYPE;
--KOC1270

  BEGIN

      OPEN claim_cur;
      FETCH claim_cur INTO claim_rec;
      CLOSE claim_cur;
--KOC1270
      OPEN prod_info_cur;
      FETCH prod_info_cur INTO prod_info_rec;
      CLOSE prod_info_cur;

      OPEN mem_cur;
      FETCH mem_cur INTO mem_rec;
      CLOSE mem_cur;
--KOC1270
      IF v_clm_status_general_type_id = 'APR' THEN
        v_approved_amount := claim_rec.cb_approved_amount;
        v_rejected_amount := 0;
        v_allow_yn        := 'Y';
      ELSE
        v_approved_amount := 0;
        v_rejected_amount := claim_rec.cb_approved_amount;
        v_allow_yn        := 'N';
      END IF;
--KOC1270
if ( mem_rec.hosp_cash_benefit_yn='Y' OR mem_rec.conv_cash_benefit_yn = 'Y')
  and claim_rec.NEW_CASH_BENEFIT_YN='Y' then

   if (prod_info_rec.cbh_sumins_yn='Y' or prod_info_rec.conv_sumins_yn = 'Y')
      and v_approved_amount > 0  and v_clm_status_general_type_id = 'APR' then

     if (mem_rec.sum_insured + mem_rec.bonus - mem_rec.utilised_sum_insured
       - mem_rec.utilised_cum_bonus-claim_rec.utilised_sumins-claim_rec.utilised_bonus) >= 0 then

     update tpa_enr_balance bal
        set bal.utilised_sum_insured = nvl(bal.utilised_sum_insured,0) + claim_rec.utilised_sumins,
            bal.utilised_cum_bonus = nvl(bal.utilised_cum_bonus,0) + claim_rec.utilised_bonus
      where bal.balance_seq_id = mem_rec.balance_seq_id;

  IF SQL%ROWCOUNT > 0 THEN

   IF v_clm_status_general_type_id = 'APR' THEN
        v_approved_amount := claim_rec.utilised_sumins+claim_rec.utilised_bonus;
        v_rejected_amount := 0;
        v_allow_yn        := 'Y';
   ELSE
        v_approved_amount := 0;
        v_rejected_amount := claim_rec.utilised_sumins+claim_rec.utilised_bonus;
        v_allow_yn        := 'N';
   END IF;

  END IF;

    ELSE
       RAISE_APPLICATION_ERROR(-20737,'Sufficient balance does not exist');
   end if;

   end if;

 end if;
--KOC1270

      SELECT event_seq_id, simple_review_count  INTO v_event_seq_id, v_review_num
           FROM ( SELECT A.event_seq_id, a.simple_review_count ,row_number() over (ORDER BY A.event_seq_id DESC) AS pos
              FROM tpa_event a JOIN tpa_workflow b ON (a.workflow_seq_id = b.workflow_seq_id)
              WHERE b.sub_general_type_id = 'CLM' ) WHERE pos =2  ;

      v_claims_inward_no      := PRE_AUTH_PKG.generate_id_numbers('INW', claim_rec.tpa_office_seq_id , NULL, v_added_by);

      INSERT INTO clm_inward (
        claims_inward_seq_id,  tpa_office_seq_id,   claims_inward_no,    barcode_no,
        document_general_type_id,     rcvd_date,  source_general_type_id,    courier_seq_id,
        claim_general_type_id,  inward_ins_seq_id,  corporate_name,   claim_number,
        inward_status_general_type_id,   remarks,    added_by,    added_date )
      VALUES (
        clm_inward_seq.NEXTVAL ,  claim_rec.tpa_office_seq_id,   v_claims_inward_no ,   claim_rec.barcode_no,
        claim_rec.document_general_type_id,  SYSDATE,   claim_rec.source_general_type_id,    claim_rec.courier_seq_id,
        'CTM',   claim_rec.inward_ins_seq_id,   claim_rec.corporate_name,    claim_rec.claim_number,
        'IWC',  'Cash benefit, original claim '||claim_rec.claim_number,   v_added_by,   SYSDATE )
         RETURNING claims_inward_seq_id INTO v_claims_inward_seq_id;

        v_claim_number := PRE_AUTH_PKG.generate_id_numbers('CL', claim_rec.tpa_office_seq_id, NULL, v_added_by);
        v_claim_settlement_number := pre_auth_pkg.generate_id_numbers ('STC', claim_rec.tpa_office_seq_id , claim_rec.claim_number , v_added_by , claim_rec.claim_general_type_id );

      INSERT INTO clm_general_details(
        claim_seq_id,  claims_inward_seq_id,  claim_number,  claim_file_number,
        requested_amount, total_app_amount ,  original_yn,  request_general_type_id, claim_sub_general_type_id,  mode_general_type_id,
        treating_dr_name,  in_patient_no,   claims_remarks,
        required_review_count,  review_count, completed_yn,   entered_date,   discrepancy_present_yn,
        date_of_admission,  date_of_discharge,claim_settlement_number ,  event_seq_id,  validation_status,
        doctor_registration_no,     rule_execution_flag,    added_by,   added_date )
      VALUES (
        clm_claim_seq.NEXTVAL ,  v_claims_inward_seq_id,  v_claim_number,  claim_rec.claim_file_number,
        claim_rec.cb_approved_amount,v_approved_amount,   'Y',  claim_rec.request_general_type_id,  'CBN',  'CLR',
        claim_rec.treating_dr_name, claim_rec.in_patient_no,  'Cash benefit,for original claim '||claim_rec.claim_number,
        0,   0,   'Y',   SYSDATE,   'N',
        claim_rec.date_of_admission,  claim_rec.date_of_discharge,v_claim_settlement_number, v_event_seq_id + 1,   'P',
        claim_rec.doctor_registration_no,  2,  v_added_by, SYSDATE
        ) RETURNING claim_seq_id INTO v_claim_seq_id;

      INSERT INTO clm_enroll_details(
        clm_enroll_detail_seq_id,  claim_seq_id,  gender_general_type_id,   member_seq_id,
        tpa_enrollment_id, policy_seq_id, policy_holder_name,     employee_no,
        employee_name,    mem_age,   claimant_name,    date_of_inception,
        date_of_exit,    relship_type_id,    policy_number,  claimant_phone_number,
        mem_total_sum_insured, clm_status_general_type_id,    decision_date,
        enrol_type_id,   policy_sub_general_type_id,
        phone_1,  policy_effective_from, policy_effective_to, ins_status_general_type_id,
        ins_seq_id,  group_reg_seq_id,  email_id, notification_phone_number,
        ins_scheme,   certificate_no,  ins_customer_code , added_by, added_date )
      VALUES (
        clm_enroll_detail_seq.NEXTVAL ,  v_claim_seq_id, claim_rec.gender_general_type_id,  claim_rec.member_seq_id,
        claim_rec.tpa_enrollment_id,claim_rec.policy_seq_id,claim_rec.policy_holder_name,claim_rec.employee_no,
        claim_rec.employee_name,claim_rec.mem_age,claim_rec.claimant_name,claim_rec.date_of_inception,
        claim_rec.date_of_exit,claim_rec.relship_type_id,claim_rec.policy_number,claim_rec.claimant_phone_number,
        claim_rec.mem_total_sum_insured,v_clm_status_general_type_id,SYSDATE,
        claim_rec.enrol_type_id,claim_rec.policy_sub_general_type_id,
        claim_rec.phone_1,claim_rec.policy_effective_from,claim_rec.policy_effective_to,claim_rec.ins_status_general_type_id,
        claim_rec.ins_seq_id,claim_rec.group_reg_seq_id,ttk_util_pkg.fn_encrypt(claim_rec.email_id),claim_rec.notification_phone_number,
        claim_rec.ins_scheme,claim_rec.certificate_no,claim_rec.ins_customer_code,v_added_by, SYSDATE)
        RETURNING clm_enroll_detail_seq_id INTO v_clm_enroll_detail_seq_id;

      INSERT INTO clm_hospital_association (clm_hosp_assoc_seq_id,claim_seq_id
       ,hosp_seq_id,empanel_number,hosp_name,address_1,address_2,address_3,state_name
       ,city_name,pin_code,off_phone_no_1,off_phone_no_2,office_fax_no,remarks,added_by,added_date)
       VALUES ( clm_clm_hosp_assoc_seq_id.NEXTVAL, v_claim_seq_id  ,
       claim_rec.hosp_seq_id,claim_rec.empanel_number,claim_rec.hosp_name,claim_rec.address_1,claim_rec.address_2,claim_rec.address_3,claim_rec.state_name,
       claim_rec.city_name,claim_rec.pin_code,claim_rec.off_phone_no_1,claim_rec.off_phone_no_2,claim_rec.office_fax_no,claim_rec.remarks,v_added_by,SYSDATE);

      UPDATE clm_cash_benefit a SET
         a.claim_seq_id        = v_claim_seq_id,
         a.cb_claim_number     = v_claim_number,
         a.completed_yn        = 'Y',
         a.clm_status_general_type_id = v_clm_status_general_type_id,
         a.updated_date        = SYSDATE,
         a.updated_by          = v_added_by
         WHERE a.clm_cash_benefit_seq_id = claim_rec.clm_cash_benefit_seq_id AND a.completed_yn = 'N';
         IF SQL%ROWCOUNT = 0 THEN
           RAISE_APPLICATION_ERROR(-20708,'This claim is already processed.');
         END IF;

      INSERT INTO associated_illness (
        assoc_seq_id , claim_seq_id  , assoc_ill_general_type_id ,  assoc_ill_present_yn ,
        assoc_duration_general_type_id , added_by , added_date )
      SELECT associated_illness_seq.NEXTVAL , v_claim_seq_id , assoc_ill_general_type_id ,
        assoc_ill_present_yn , assoc_duration_general_type_id ,v_added_by, SYSDATE
        FROM associated_illness WHERE claim_seq_id  = v_prev_claim_seq_id  ;

      INSERT INTO ailment_details (ailment_details_seq_id , claim_seq_id ,ailment_description ,specialty_general_type_id ,surgery_general_type_id,
                                   ailment_duration , pat_duration_general_type_id , clinical_findings , provisional_diagnosis ,
                                   related_to_previous_illness_yn , trtmnt_plan_general_type_id  , investigation_reports , line_of_treatment ,
                                   duration_of_hospitalization , doctor_opinion ,disability_general_type_id ,discharge_cond_general_type_id ,doctor_opinion_by ,
                                   claim_file_number, advice_to_patient,medicine_general_type_id ,ailment_clm_general_type_id ,mat_general_type_id,children_during_mat,  added_by , added_date )
      SELECT  ailment_details_seq.NEXTVAL , v_claim_seq_id ,ailment_description ,specialty_general_type_id ,surgery_general_type_id,
                                   ailment_duration , pat_duration_general_type_id , clinical_findings , provisional_diagnosis ,
                                   related_to_previous_illness_yn , trtmnt_plan_general_type_id  , investigation_reports , line_of_treatment ,
                                   duration_of_hospitalization , doctor_opinion , disability_general_type_id ,discharge_cond_general_type_id ,doctor_opinion_by ,
                                   claim_file_number, advice_to_patient ,medicine_general_type_id ,ailment_clm_general_type_id,mat_general_type_id,children_during_mat, v_added_by , SYSDATE
      FROM ailment_details WHERE claim_seq_id  = v_prev_claim_seq_id  ;

      --Copying ICD_PCS_DETAIL
      OPEN icd_cur;
      FETCH icd_cur INTO v_ped_code_id;
      CLOSE icd_cur;

      INSERT INTO icd_pcs_detail (icd_pcs_seq_id, claim_seq_id,ped_code_id,icd_code,
               primary_ailment_yn,hospital_general_type_id ,trtmnt_plan_general_type_id ,tariff_general_type_id ,
               frequency_of_visit , pat_duration_general_type_id ,no_of_visits ,claim_file_number,
               added_by, added_date)
      VALUES( icd_pcs_detail_seq.NEXTVAL , v_claim_seq_id, v_ped_code_id, v_icd_code,
               'N', 'REL' ,'MDC' , 'NPK' ,
               NULL , NULL , NULL ,claim_rec.claim_file_number,
                v_added_by, SYSDATE ) RETURNING icd_pcs_seq_id INTO v_icd_pcs_seq_id;



if ( mem_rec.hosp_cash_benefit_yn='Y' OR mem_rec.conv_cash_benefit_yn = 'Y')
  and claim_rec.NEW_CASH_BENEFIT_YN='Y' then


FOR REC IN (SELECT * FROM app.CLM_CASH_BENEFIT_BILLS BL
  WHERE BL.PARENT_CLAIM_SEQ_ID = claim_rec.Parent_Claim_Seq_Id
  AND BL.MEMBER_SEQ_ID = claim_rec.member_seq_id)
LOOP

  CASE REC.WARD_ID
    WHEN 'HCB' THEN
      V_BILL_DESC := 'HOSPITAL CASH BENEFIT';
    WHEN 'COB' THEN
     V_BILL_DESC := 'COVALALESCENCE BENEFIT';
    ELSE
      V_BILL_DESC := 'CASH BENEFIT CLAIM';
    END CASE;


      INSERT INTO clm_bill_header(clm_bill_seq_id, claim_seq_id, bill_no, bill_date, bill_issued_by,
                                  bills_with_prescription_yn ,bill_included_yn , added_by , added_date)
      VALUES( clm_bill_seq.NEXTVAL, v_claim_seq_id,1 , SYSDATE, NULL,
             'N','Y' , v_added_by, SYSDATE)
              RETURNING clm_bill_seq_id INTO v_clm_bill_seq_id;

      INSERT INTO clm_bill_details(clm_bill_dtl_seq_id,clm_bill_seq_id,description,ward_type_id,room_type_id,
             number_of_days,requested_amount,allow_yn,allowed_amount, rejected_amount,
             remarks,ward_max_amount,discount_percnt,added_by,added_date)
      VALUES( clm_bill_dtl_seq.NEXTVAL, v_clm_bill_seq_id, V_BILL_DESC, REC.WARD_ID, NULL,
             REC.CB_DAYS, REC.CB_APPROVED_AMOUNT , v_allow_yn, v_approved_amount , v_rejected_amount,
            V_BILL_DESC, NULL , NULL,v_added_by,SYSDATE);
END LOOP;
ELSE
      INSERT INTO clm_bill_header(clm_bill_seq_id, claim_seq_id, bill_no, bill_date, bill_issued_by,
                                  bills_with_prescription_yn ,bill_included_yn , added_by , added_date)
      VALUES( clm_bill_seq.NEXTVAL, v_claim_seq_id, 1 , SYSDATE, NULL,
             'N','Y' , v_added_by, SYSDATE)
              RETURNING clm_bill_seq_id INTO v_clm_bill_seq_id;

      INSERT INTO clm_bill_details(clm_bill_dtl_seq_id,clm_bill_seq_id,description,ward_type_id,room_type_id,
             number_of_days,requested_amount,allow_yn,allowed_amount, rejected_amount,
             remarks,ward_max_amount,discount_percnt,added_by,added_date)
      VALUES( clm_bill_dtl_seq.NEXTVAL, v_clm_bill_seq_id, 'CASH BENEFIT CLAIM BILL', 'CBN', NULL,
             NULL, claim_rec.cb_approved_amount , v_allow_yn, v_approved_amount , v_rejected_amount,
            'CASH BENEFIT CLAIM ', NULL , NULL,v_added_by,SYSDATE);
END IF;
--KOC1270
      INSERT INTO ailment_caps(ailment_caps_seq_id,icd_pcs_seq_id,maximum_allowed_amount,approved_amount,notes,added_by,added_date)
      VALUES(ailment_caps_seq.nextval,v_icd_pcs_seq_id,claim_rec.cb_approved_amount,v_approved_amount,'Cash Benefit Approvel',v_added_by,SYSDATE);

      INSERT INTO assign_users (
          assign_users_seq_id,    claim_seq_id, tpa_office_seq_id, assigned_to_user , assigned_date,
          remarks, review_completed_yn ,
           added_by,  added_date)
        VALUES ( pat_assign_users_seq.NEXTVAL , v_claim_seq_id ,  claim_rec.tpa_office_seq_id, v_added_by , SYSDATE,
                 'Cash Benefit Claim Automatic Approval' ,'Y',
                  v_added_by,   SYSDATE)
                  RETURNING assign_users_seq_id INTO v_assign_users_seq_id ;

      UPDATE clm_general_details a SET
         a.last_assign_user_seq_id = v_assign_users_seq_id
         WHERE a.claim_seq_id = v_claim_seq_id ;

      v_rows_processed := SQL%ROWCOUNT;

      -- SAVE RECORD TO FINANCE.
      IF v_clm_status_general_type_id = 'APR' THEN
         save_claims_payment ( v_claim_seq_id  , claim_rec.Enrol_Type_Id, claim_rec.Policy_Seq_Id ,claim_rec.Member_Seq_Id ,'CTM', v_added_by   );
      END IF;
--KOC1270
DELETE FROM app.CLM_CASH_BENEFIT_BILLS BL
  WHERE BL.PARENT_CLAIM_SEQ_ID = CLAIM_REC.PARENT_CLAIM_SEQ_ID
  AND BL.MEMBER_SEQ_ID = claim_rec.member_seq_id;
--KOC1270
      COMMIT;
  END create_cash_benefit_claim;
  --==============================================================================================
  PROCEDURE select_cb_claim_list (
    v_claim_number                     clm_general_details.claim_number%TYPE,
    v_claim_settlement_number          clm_general_details.claim_settlement_number%TYPE,
    v_start_date                       VARCHAR2,
    v_end_date                         VARCHAR2,
    v_completed_yn                     VARCHAR2, -- 'Y' PROCESSED, 'N' - PENDING
    v_sort_var                         IN VARCHAR2 ,
    v_sort_order                       IN VARCHAR2 ,
    v_start_num                        IN NUMBER ,
    v_end_num                          IN NUMBER,
    result_set                         OUT SYS_REFCURSOR
  )
  IS
    v_sql_str  VARCHAR2(2000);
    v_where    VARCHAR2(2000);

    TYPE search_tab_type IS TABLE OF VARCHAR2(250) INDEX BY BINARY_INTEGER ;
    search_tab                           search_tab_type;
    i                                    NUMBER(2) := 0;

  BEGIN

    v_sql_str:= ' SELECT
         a.claim_seq_id,
         c.claimant_name,
         a.parent_claim_seq_id,  -- original claim
         a.clm_cash_benefit_seq_id,
         b.claim_number,  -- original claim
         b.claim_settlement_number, -- original claim
         b.claim_file_number, -- original as well as cash benefit claim
         a.cb_claim_number, -- cash benefit claim
         c.decision_date AS parent_claim_appr_date, -- original claim
         a.updated_date AS cb_approved_date ,
         ''Hospital'' AS benefit_type
         FROM clm_cash_benefit a JOIN clm_general_details b ON (a.parent_claim_seq_id = b.claim_seq_id)
         JOIN clm_enroll_details c ON (b.claim_seq_id = c.claim_seq_id)
         WHERE ';

    IF v_claim_number IS NOT NULL THEN
      v_where := v_where||' AND  b.claim_number = :v_claim_number ';
      i := i + 1;
      search_tab(I) := UPPER(v_claim_number);
    END IF;
    IF v_claim_settlement_number IS NOT NULL THEN
      v_where := v_where||' AND  b.claim_settlement_number = :v_claim_settlement_number ';
      i := i + 1;
      search_tab(I) := UPPER(v_claim_settlement_number);
    END IF;
    IF v_start_date IS NOT NULL THEN
      v_where := v_where||' AND  A.added_date  > :v_start_date ';
      i := i + 1;
      search_tab(I) := to_date(v_start_date,'dd/mm/yyyy') -1;
    END IF;
    IF v_end_date IS NOT NULL THEN
      v_where := v_where||' AND  A.added_date  < :v_end_date ';
      i := i + 1;
      search_tab(I) := to_date(v_end_date,'dd/mm/yyyy') + 1;
    END IF;
    v_where  := v_where||' AND a.completed_yn = :v_completed_yn AND B.completed_yn = ''Y''' ;

    v_sql_str := v_sql_str||SUBSTR(v_where,5);

    v_sql_str := 'SELECT * FROM
            (SELECT A.*,DENSE_RANK() OVER (ORDER BY '||v_sort_var||' '||v_sort_order||',ROWNUM)
            Q FROM (' ||v_sql_str|| ') A ) WHERE  Q>= :v_start_num AND Q<= :v_end_num ';

    IF search_tab.FIRST IS NOT NULL THEN
       CASE search_tab.COUNT
         WHEN 1 THEN OPEN result_set FOR v_sql_str USING  search_tab(1),v_completed_yn, v_start_num , v_end_num ;
         WHEN 2 THEN OPEN result_set FOR v_sql_str USING  search_tab(1),search_tab(2),v_completed_yn, v_start_num , v_end_num ;
         WHEN 3 THEN OPEN result_set FOR v_sql_str USING  search_tab(1),search_tab(2) ,search_tab(3) ,v_completed_yn, v_start_num , v_end_num ;
         WHEN 4 THEN OPEN result_set FOR v_sql_str USING  search_tab(1),search_tab(2) ,search_tab(3) ,search_tab(4),v_completed_yn, v_start_num , v_end_num ;
       END CASE;
    ELSE
       OPEN result_set FOR v_sql_str USING  v_completed_yn, v_start_num , v_end_num ;
    END IF;
  END select_cb_claim_list;
  --==============================================================================================
   -- called from create_cash_benefit_claim
  PROCEDURE save_claims_payment (
    v_claim_seq_id                       IN  TPA_CLAIMS_PAYMENT.claim_seq_id%TYPE,
    v_enrol_type_id                      IN  TPA_ENR_POLICY.enrol_type_id%TYPE,
    v_policy_seq_id                      IN  TPA_ENR_POLICY.Policy_Seq_Id%TYPE,
    v_member_seq_id                      IN  TPA_ENR_POLICY_MEMBER.Member_Seq_Id%TYPE,
    v_claim_general_type_id              IN  clm_inward.claim_general_type_id%TYPE,
    v_added_by                           IN  TPA_CLAIMS_PAYMENT.added_by%TYPE
  )
  IS

--    v_status                             TPA_CLAIMS_PAYMENT.claim_payment_status%TYPE;

  -- If the Claim is MR Individual, Individual as Group, Non-Corporate
  CURSOR cur_get_mr_individual IS
    SELECT b.insured_name payee_name, P.address_1, P.address_2,  P.address_3, F.state_name, P.city_type_id city_description,
         g.country_name AS country,   P.pin_code,   P.off_phone_no_1,   P.fax_no ,
         NULL AS issue_cheques_type_id , NULL AS hosp_seq_id
         FROM tpa_enr_policy a JOIN tpa_enr_policy_group b ON (a.policy_seq_id = b.policy_seq_id)
         JOIN tpa_enr_policy_member c ON (b.policy_group_seq_id = c.policy_group_seq_id)
         JOIN tpa_enr_mem_address P ON (b.enr_address_seq_id = p.enr_address_seq_id)
         LEFT OUTER JOIN tpa_state_code F ON ( P.state_type_id = f.state_type_id )
         LEFT OUTER JOIN tpa_country_code g ON ( p.country_id = g.country_id )
         WHERE a.policy_seq_id = v_policy_seq_id  AND c.member_seq_id  = v_member_seq_id ;

  CURSOR cur_get_mr_location IS
    SELECT CASE WHEN g.group_reg_seq_id IS NULL THEN B.group_name ELSE r.group_name END AS payee_name ,
         CASE WHEN g.group_reg_seq_id IS NULL THEN P.address_1 ELSE m.address_1 END AS address_1 ,
         CASE WHEN g.group_reg_seq_id IS NULL THEN P.address_2 ELSE m.address_2 END AS address_2 ,
         CASE WHEN g.group_reg_seq_id IS NULL THEN P.address_3 ELSE m.address_3 END AS address_3 ,
         CASE WHEN g.group_reg_seq_id IS NULL THEN F.state_name ELSE n.state_name END AS state_name ,
         CASE WHEN g.group_reg_seq_id IS NULL THEN C.city_description ELSE o.city_description END AS city_description ,
         CASE WHEN g.group_reg_seq_id IS NULL THEN aa.country_name ELSE bb.country_name END AS country ,
         CASE WHEN g.group_reg_seq_id IS NULL THEN P.pin_code ELSE m.pin_code END AS pin_code ,
         CASE WHEN g.group_reg_seq_id IS NULL THEN B.office_number ELSE r.office_number END AS off_phone_no_1 ,
         NULL fax_no,
         NULL AS issue_cheques_type_id , NULL AS hosp_seq_id
         FROM tpa_enr_policy a JOIN tpa_enr_policy_group g ON (a.policy_seq_id = g.policy_seq_id)
         JOIN tpa_enr_policy_member H ON (g.policy_group_seq_id = h.policy_group_seq_id)
         LEFT OUTER JOIN tpa_group_registration r ON ( g.group_reg_seq_id = r.group_reg_seq_id )
         LEFT OUTER JOIN tpa_group_registration b ON ( a.group_reg_seq_id = b.group_reg_seq_id )
         LEFT OUTER JOIN tpa_address P ON (b.group_reg_seq_id = p.group_reg_seq_id)
         LEFT OUTER JOIN tpa_state_code F ON ( P.state_type_id = f.state_type_id )
         LEFT OUTER JOIN tpa_city_code C ON ( C.city_type_id = P.city_type_id )
         LEFT OUTER JOIN tpa_country_code aa ON ( p.country_id = aa.country_id )
         LEFT OUTER JOIN tpa_address m ON (r.group_reg_seq_id = m.group_reg_seq_id)
         LEFT OUTER JOIN tpa_state_code n ON ( m.state_type_id = n.state_type_id )
         LEFT OUTER JOIN tpa_city_code o ON ( m.city_type_id = o.city_type_id )
         LEFT OUTER JOIN tpa_country_code bb ON ( m.country_id = bb.country_id )
         WHERE h.member_seq_id = v_member_seq_id;


   -- If the claim is from the corporate
    CURSOR cur_get_policy_cheque IS
     SELECT a.tpa_cheque_issued_general_type
      FROM tpa_enr_policy a  WHERE  a.policy_seq_id = v_policy_seq_id  ;

     -- Cheque to be issued in the name of the corporate
     CURSOR cur_get_corporate_info IS
         SELECT B.group_name AS payee_name,  P.address_1,  P.address_2,   P.address_3,  F.state_name,  C.city_description,
           aa.country_name AS country,     P.pin_code,   B.office_number off_phone_no_1,  NULL fax_no,
           NULL AS issue_cheques_type_id , NULL AS hosp_seq_id
           FROM tpa_enr_policy a JOIN tpa_group_registration b ON (a.group_reg_seq_id = b.group_reg_seq_id)
           JOIN tpa_address P ON (b.group_reg_seq_id = p.group_reg_seq_id)
           LEFT OUTER JOIN tpa_state_code F ON ( P.state_type_id = f.state_type_id )
           LEFT OUTER JOIN tpa_city_code C ON ( C.city_type_id = P.city_type_id )
           LEFT OUTER JOIN tpa_country_code aa ON ( p.country_id = aa.country_id )
           WHERE a.policy_seq_id  = v_policy_seq_id ;

       rule_rec_payee  cur_get_mr_individual%ROWTYPE;


       v_cheque_issue  VARCHAR2( 3 );

  BEGIN

      IF   v_claim_general_type_id = 'CTM'  THEN -- MEMBER CLAIM
          IF v_enrol_type_id IN  ('IND','ING','NCR') THEN
            OPEN cur_get_mr_individual ;
            FETCH  cur_get_mr_individual INTO rule_rec_payee ;
            CLOSE cur_get_mr_individual;

            IF rule_rec_payee.payee_name IS NULL OR rule_rec_payee.address_1 IS NULL THEN
              raise_application_error(-20177, 'Please correct payee address before completing the Claim ');
            END IF;

          ELSIF  v_enrol_type_id = 'COR' THEN
            OPEN cur_get_policy_cheque;
            FETCH cur_get_policy_cheque INTO v_cheque_issue;
            CLOSE cur_get_policy_cheque;

            -- issue cheques to Corporate
            IF v_cheque_issue = 'IQC' THEN
              OPEN cur_get_corporate_info;
              FETCH  cur_get_corporate_info INTO rule_rec_payee ;
              CLOSE cur_get_corporate_info;
              IF rule_rec_payee.payee_name IS NULL OR rule_rec_payee.address_1 IS NULL THEN
                raise_application_error(-20178, 'Please correct corporate address before completing the Claim ');
              END IF;
            ELSIF  v_cheque_issue = 'IQI'  THEN -- issue cheques to Individual
              OPEN cur_get_mr_individual ;
              FETCH  cur_get_mr_individual INTO rule_rec_payee ;
              CLOSE cur_get_mr_individual;
              IF rule_rec_payee.payee_name IS NULL OR rule_rec_payee.address_1 IS NULL THEN
                raise_application_error(-20177, 'Please correct payee address before completing the Claim ');
              END IF;
            ELSIF  v_cheque_issue = 'IQL'  THEN -- issue cheques to Individual
              OPEN cur_get_mr_location ;
              FETCH  cur_get_mr_location INTO rule_rec_payee ;
              CLOSE cur_get_mr_location;
              IF rule_rec_payee.payee_name IS NULL OR rule_rec_payee.address_1 IS NULL THEN
                raise_application_error(-20177, 'Please correct payee address before completing the Claim ');
              END IF;
            END IF;
          END IF;
       END IF;

      INSERT INTO tpa_claims_payment (
        payment_seq_id,
        claim_settlement_no,
        claim_payment_status,
        claim_amount,
        claim_type,
        claim_aprv_date,
        approved_amount,
        ins_seq_id,
        deleted_yn,
        policy_seq_id,
        member_seq_id,
        group_reg_seq_id,
        address1,
        address2,
        address3,
        state ,
        city ,
        pincode ,
        country,
        email_id ,
        phone1,
        phone2,
        home_phone,
        mob_num,
        fax_no,
        enrol_type_id,
        claim_seq_id,
        claim_file_number,
        added_by,
        added_date,
        payee_name ,
        tpa_cheque_issued_general_type,
        hosp_seq_id,
        tpa_nhcp_cheques_issued_to  )
    SELECT
      tpa_claims_payment_seq.NEXTVAL ,
      a.claim_settlement_number ,
      'PENDING',
      a.requested_amount,
      C.claim_general_type_id,
      b.decision_date,
      a.total_app_amount,
      b.ins_seq_id,
      'N',
      b.policy_seq_id,
      b.member_seq_id,
      CASE WHEN v_cheque_issue = 'IQL' THEN NVL(X.group_reg_seq_id,b.group_reg_seq_id) ELSE b.group_reg_seq_id END,
      rule_rec_payee.Address_1,
      rule_rec_PAYEE.Address_2,
--      'TO BE REMOVED',
      rule_rec_payee.Address_3,
      rule_rec_payee.State_Name,
      rule_rec_payee.CITY_DESCRIPTION,
      rule_rec_payee.Pin_Code,
--      'TO BE REMOVED',
      rule_rec_payee.country,
      NULL email_id ,
      rule_rec_payee.Off_Phone_No_1,
      NULL off_phone_no_2,
      NULL res_phone_no,
      NULL mobile_no,
      rule_rec_payee.Fax_No,
      b.enrol_type_id ,
      a.claim_seq_id,
      a.claim_file_number,
      v_added_by,
      SYSDATE,
     -- rule_rec_payee.Payee_Name,
      ttk_util_pkg.fn_encrypt(rule_rec_payee.Payee_Name), --//ED
      v_cheque_issue,
      rule_rec_payee.hosp_seq_id,
      rule_rec_payee.issue_cheques_type_id
      FROM clm_general_details A JOIN clm_enroll_details b ON ( a.claim_seq_id = b.claim_seq_id )
      JOIN clm_inward C ON ( a.claims_inward_seq_id = c.claims_inward_seq_id )
      JOIN tpa_enr_policy_member D ON ( b.member_seq_id = d.member_seq_id )
      JOIN tpa_enr_policy_group X ON (d.policy_group_seq_id = X.policy_group_seq_id )
      LEFT OUTER JOIN tpa_general_code K ON ( C.claim_general_type_id = K.general_type_id )
   WHERE a.claim_seq_id = v_claim_seq_id ;

  END save_claims_payment;
--====================================================================================
  PROCEDURE delete_clm_cash_benefit (
    v_seq_id                             IN  clm_general_details.claims_inward_seq_id%TYPE,
    v_claim_seq_id                       IN  clm_general_details.claim_seq_id%TYPE,
    v_added_by                           IN  NUMBER
  )
  IS
--KOC1270
  v_utilised_sum_ins              clm_cash_benefit.Utilised_Sumins%TYPE;
  v_utilised_bonus                clm_cash_benefit.utilised_bonus%TYPE;

cursor mem_info_cur is
  select pol.cbh_sumins_yn,pol.enrol_type_id,pol.product_seq_id,
  pol.policy_seq_id,gr.policy_group_seq_id,
  nvl(gr.hosp_cash_benefit_yn,'N') as hosp_cash_benefit_yn,
   bal.sum_insured, bal.bonus,bal.utilised_sum_insured,
   bal.utilised_cum_bonus,bal.balance_seq_id
from tpa_enr_policy_group gr
join tpa_enr_policy_member mem on (mem.policy_group_seq_id = gr.policy_group_seq_id)
join tpa_enr_policy pol on (pol.policy_seq_id = gr.policy_seq_id)
join tpa_enr_balance bal on ((bal.member_seq_id = mem.member_seq_id and
             pol.policy_sub_general_type_id = 'PNF') OR
             (bal.policy_group_seq_id = gr.policy_group_seq_id and
             pol.policy_sub_general_type_id = 'PFL'))
where mem.member_seq_id in (select en.member_seq_id
from clm_enroll_details en where en.claim_seq_id = v_claim_seq_id);

  mem_info_rec                 mem_info_cur%ROWTYPE;

 cursor prod_info_cur is
select case when mem_info_rec.enrol_type_id = 'COR' then nvl(pol.cbh_sumins_yn,'N')
else nvl(prd.cbh_sumins_yn,'N') end as cbh_sumins_yn,pol.product_seq_id,
  case when mem_info_rec.enrol_type_id = 'COR' then nvl(pol.conv_sumins_yn,'N')
else nvl(prd.conv_sumins_yn,'N') end as conv_sumins_yn
  from tpa_ins_product prd
join tpa_enr_policy pol on (pol.product_seq_id=prd.product_seq_id)
where pol.policy_seq_id = mem_info_rec.policy_seq_id;

prod_info_rec   prod_info_cur%rowtype;
--KOC1270

  BEGIN
--KOC1270
open  mem_info_cur;
fetch mem_info_cur into mem_info_rec;
close mem_info_cur;

open  prod_info_cur;
fetch prod_info_cur into prod_info_rec;
close prod_info_cur;


    DELETE FROM CLM_CASH_BENEFIT cb
     WHERE cb.claim_seq_id = v_claim_seq_id
     and cb.new_cash_benefit_yn='Y' and cb.completed_yn='Y'
     returning nvl(cb.utilised_sumins,0),nvl(cb.utilised_bonus,0) into v_utilised_sum_ins,v_utilised_bonus;

if (prod_info_rec.cbh_sumins_yn = 'Y' or prod_info_rec.conv_sumins_yn = 'Y')
   and ( v_utilised_sum_ins > 0 or v_utilised_bonus > 0 ) then

    update tpa_enr_balance bal
    set bal.utilised_sum_insured = nvl(bal.utilised_sum_insured,0) - v_utilised_sum_ins,
    bal.utilised_cum_bonus = nvl(bal.utilised_cum_bonus,0) - v_utilised_bonus
    where bal.balance_seq_id = mem_info_rec.balance_seq_id;

end if;
--KOC1270

    DELETE FROM clm_hospital_association b
                  WHERE b.claim_seq_id = v_claim_seq_id ;
    DELETE FROM pat_package_procedures a WHERE a.icd_pcs_seq_id IN
              ( SELECT b.icd_pcs_seq_id FROM icd_pcs_detail b  WHERE b.claim_seq_id = v_claim_seq_id );
    DELETE FROM ailment_caps a WHERE a.icd_pcs_seq_id IN
              ( SELECT b.icd_pcs_seq_id FROM icd_pcs_detail b  WHERE b.claim_seq_id = v_claim_seq_id );
    DELETE FROM icd_pcs_detail b  WHERE b.claim_seq_id = v_claim_seq_id ;
    DELETE FROM tpa_diagnosys_details d WHERE d.claim_seq_id = v_claim_seq_id;--koc decoupling    
	DELETE FROM ailment_details a WHERE a.claim_seq_id = v_claim_seq_id ;
    DELETE FROM clm_bill_details a WHERE a.clm_bill_seq_id IN ( SELECT b.clm_bill_seq_id
                                                                  FROM clm_bill_header b
                                                                 WHERE b.claim_seq_id = v_claim_seq_id );
    DELETE FROM clm_bill_header b WHERE b.claim_seq_id = v_claim_seq_id ;
    DELETE FROM associated_illness  a WHERE a.claim_seq_id = v_claim_seq_id ;
    UPDATE clm_general_details A SET A.last_assign_user_seq_id = NULL WHERE a.claim_seq_id = v_claim_seq_id ;
    DELETE FROM assign_users a WHERE a.claim_seq_id = v_claim_seq_id ;

    DELETE FROM quality_control a WHERE a.claim_seq_id = v_claim_seq_id;
    DELETE FROM code_cleanup_event_history a WHERE a.claim_seq_id = v_claim_seq_id ;
    DELETE FROM code_cleanup_workflow a WHERE a.claim_seq_id = v_claim_seq_id ;
    DELETE FROM clm_enroll_details a WHERE a.claim_seq_id = v_claim_seq_id ;
    DELETE FROM clm_general_details a WHERE a.claim_seq_id = v_claim_seq_id ;
    p_clm_inw_del_log(TO_NUMBER(v_seq_id)); --for dms
    DELETE FROM clm_inward a WHERE a.claims_inward_seq_id = TO_NUMBER(v_seq_id);

  END delete_clm_cash_benefit;
  --=====================================================================================
  -- CREATED BY : S.V.SREERAJ
  -- ON         : 01-10-2008
  -- PURPOSE    : To re-fetch emrollment details of the member in ammendments,
  --              if any enrollment change happened in between.
  --=====================================================================================
    PROCEDURE re_assign_enrl_id (
    v_claim_seq_id               IN  clm_general_details.claim_seq_id%TYPE,
    v_clm_status_general_type_id IN  clm_enroll_details.clm_status_general_type_id%TYPE,
    v_member_seq_id              IN  clm_enroll_details.member_seq_id%TYPE,
    v_added_by                   IN  NUMBER,
    v_rows_pocessed              OUT NUMBER
  )
  IS
    CURSOR member_cur IS SELECT c.group_reg_seq_id , c.ins_seq_id , b.employee_no ,b.insured_name,
      c.ins_status_general_type_id, c.policy_sub_general_type_id , a.date_of_inception , a.date_of_exit ,
      c.effective_from_date, c.effective_to_date , c.policy_number
      FROM tpa_enr_policy_member a JOIN tpa_enr_policy_group b ON (a.policy_group_seq_id = b.policy_group_seq_id)
      JOIN tpa_enr_policy c ON (b.policy_seq_id = c.policy_seq_id)
      WHERE a.member_seq_id = v_member_seq_id ;

    member_rec   member_cur%ROWTYPE;
  BEGIN
     claims_freeze(v_claim_seq_id,NULL,'S'); --KOCBJJ

    OPEN member_cur;
    FETCH member_cur INTO member_rec;
    CLOSE member_cur;

    IF v_clm_status_general_type_id = 'APR' THEN
      /* Changing the preauth to calculate*/
      pre_auth_pkg.reassign_user(NULL,v_claim_seq_id ,NULL,v_added_by ,'AUT');
      PRE_AUTH_PKG.check_clm_completed ( v_claim_seq_id , NULL ,'REC' ,v_added_by);
    END IF;

    UPDATE clm_enroll_details a SET
        a.ins_status_general_type_id = member_rec.ins_status_general_type_id,
        a.policy_sub_general_type_id = member_rec.policy_sub_general_type_id,
        a.date_of_inception          = member_rec.date_of_inception,
        a.date_of_exit               = member_rec.date_of_exit,
        a.policy_effective_from      = member_rec.effective_from_date,
        a.policy_effective_to        = member_rec.effective_to_date,
        a.policy_number              = member_rec.policy_number,
        a.updated_by                 = v_added_by,
        a.updated_date               = SYSDATE,
        a.modification_mode_value    = NULL
        WHERE a.claim_seq_id = v_claim_seq_id ;

       unassoc_claim_intimation(v_claim_seq_id,null,v_added_by,v_rows_pocessed);--KOC1349

    v_rows_pocessed  := SQL%ROWCOUNT;
    COMMIT;
  END re_assign_enrl_id;
 --==========================================================================================================
 -- Modified by : Ravi
 -- Date        : 17JAN13
 -- Comments    : for IBM as the buffer is handled at member level
 --===========================================================================================================
 FUNCTION mem_buff_availaility(
    v_required_buffer              IN tpa_enr_balance.buffer_amount%TYPE,
    v_policy_seq_id                IN tpa_enr_policy.policy_seq_id%TYPE ,
    v_policy_group_seq_id          IN tpa_enr_policy_member.policy_group_seq_id%TYPE ,
    v_member_seq_id                IN tpa_enr_policy_member.member_seq_id%TYPE  ,
    v_mem_general_type_id          IN tpa_enr_policy_member.mem_general_type_id%TYPE,
    v_claim_type                   IN VARCHAR2,
    v_buffer_type                  IN VARCHAR2
  )RETURN BOOLEAN
  IS

    v_used_buffer             tpa_enr_balance.buffer_amount%TYPE;

    v_buffer_alloc_amount             tpa_enr_policy.buffer_alloc_amount%TYPE;
    v_buffer_med_alloc_amount          tpa_enr_policy.buffer_alloc_amount%TYPE;
    v_buff_crit_alloc_amt         tpa_enr_policy.buffer_alloc_amount%TYPE;
    v_buff_crit_corp_alloc_amt         tpa_enr_policy.buffer_alloc_amount%TYPE;
    v_buff_crit_med_alloc_amt     tpa_enr_policy.buffer_alloc_amount%TYPE;

    v_buffer_allowed_yn            tpa_enr_policy.buffer_allowed_yn%TYPE;
    v_buffer_alloc_general_type_id tpa_enr_policy.buffer_alloc_general_type_id%TYPE;
    v_total_buffer_amount          tpa_enr_policy.Total_Buffer_Amount%TYPE;
    v_total_med_buffer_amount      tpa_enr_policy.total_buffer_amount%TYPE ;
    v_total_crit_buffer_amount     tpa_enr_policy.total_buffer_amount%TYPE ;
    v_total_crit_corp_buff_amt     tpa_enr_policy.total_buffer_amount%TYPE ;
    v_total_crit_med_buff_amt      tpa_enr_policy.total_buffer_amount%TYPE ;
    v_used_med_buffer              tpa_enr_balance.buffer_amount%TYPE;
    v_used_crit_buffer             tpa_enr_balance.buffer_amount%TYPE;
    v_used_crit_corp_buffer        tpa_enr_balance.buffer_amount%TYPE;
    v_used_crit_med_buffer         tpa_enr_balance.buffer_amount%TYPE;


    v_member_buffer                tpa_enr_policy_member.mem_buffer_alloc%TYPE;
    v_member_med_buffer            tpa_enr_policy_member.mem_buffer_alloc%TYPE;
    v_member_crit_buffer           tpa_enr_policy_member.mem_buffer_alloc%TYPE;
    v_member_crit_corp_buffer      tpa_enr_policy_member.mem_buffer_alloc%TYPE;
    v_member_crit_med_buffer       tpa_enr_policy_member.mem_buffer_alloc%TYPE;
    v_member_buffer_yn             tpa_enr_policy.member_buffer_yn%TYPE;

    CURSOR pfl_ind_buff_cur IS
      select a.used_buff_amount,a.used_med_buff_amt,a.used_crit_buff_amt,a.used_crit_corp_buff_amt,a.used_crit_med_buff_amt
         FROM tpa_enr_mem_buffer a JOIN tpa_enr_policy b ON (a.policy_seq_id = b.policy_seq_id)
         WHERE a.member_seq_id = v_member_seq_id;

    CURSOR fam_buff_cur IS
      select a.utilised_buff_amount,a.utilised_med_buff_amount,a.utilised_crit_buff_amount,a.utilised_crit_corp_buff_amt,a.utilised_crit_med_buff_amt
         FROM tpa_enr_balance a JOIN tpa_enr_policy b ON (a.policy_seq_id = b.policy_seq_id)
         WHERE a.policy_group_seq_id = v_policy_group_seq_id;

    CURSOR pnf_ind_buff_cur IS
      SELECT a.utilised_buff_amount,a.utilised_med_buff_amount,a.utilised_crit_buff_amount,a.utilised_crit_corp_buff_amt,a.utilised_crit_med_buff_amt
         FROM tpa_enr_balance a JOIN tpa_enr_policy b ON (a.policy_seq_id = b.policy_seq_id)
         WHERE a.member_seq_id = v_member_seq_id;

    CURSOR policy_cur IS SELECT a.buffer_allowed_yn,a.buffer_alloc_general_type_id,  a.total_buffer_amount,a.member_buffer_yn ,--KOCIBM
      a.tot_med_buff_amount,a.tot_crit_buff_amount,a.tot_crit_corp_buff_amount,a.tot_crit_med_buff_amount,
      case when pre_auth_pkg.get_buff_level_limit(a.policy_seq_id,v_claim_type,v_buffer_type,b.level_type)!=0 then pre_auth_pkg.get_buff_level_limit(a.policy_seq_id,v_claim_type,v_buffer_type,b.level_type) else a.buffer_alloc_amount end buffer_alloc_amount,
      case when pre_auth_pkg.get_buff_level_limit(a.policy_seq_id,v_claim_type,v_buffer_type,b.level_type)!=0 then pre_auth_pkg.get_buff_level_limit(a.policy_seq_id,v_claim_type,v_buffer_type,b.level_type) else a.med_buff_alloc_amount end med_buff_alloc_amount,
      case when pre_auth_pkg.get_buff_level_limit(a.policy_seq_id,v_claim_type,v_buffer_type,b.level_type)!=0 then pre_auth_pkg.get_buff_level_limit(a.policy_seq_id,v_claim_type,v_buffer_type,b.level_type) else a.crit_buff_alloc_amount end crit_buff_alloc_amount,
      case when pre_auth_pkg.get_buff_level_limit(a.policy_seq_id,v_claim_type,v_buffer_type,b.level_type)!=0 then pre_auth_pkg.get_buff_level_limit(a.policy_seq_id,v_claim_type,v_buffer_type,b.level_type) else a.crit_corp_buff_alloc_amount end crit_corp_buff_alloc_amount,
      case when pre_auth_pkg.get_buff_level_limit(a.policy_seq_id,v_claim_type,v_buffer_type,b.level_type)!=0 then pre_auth_pkg.get_buff_level_limit(a.policy_seq_id,v_claim_type,v_buffer_type,b.level_type) else a.crit_med_buff_alloc_amount end crit_med_buff_alloc_amount  
      FROM tpa_enr_policy a 
      JOIN tpa_enr_policy_group b on (a.policy_seq_id=b.policy_seq_id)
      WHERE a.policy_seq_id = v_policy_seq_id
      and b.policy_group_seq_id=v_policy_group_seq_id;
      

    CURSOR mem_buff_cur IS SELECT h.mem_buffer_alloc,h.mem_med_buffer_alloc,h.mem_crit_buff_alloc,h.mem_crit_corp_buff_alloc,h.mem_crit_med_buff_alloc
     FROM tpa_enr_policy_member h
      WHERE policy_group_seq_id=v_policy_group_seq_id AND member_seq_id=v_member_seq_id;

     CURSOR mem_used_cur IS
      SELECT sum(a.used_buff_amount),sum(a.used_med_buff_amt),sum(a.used_crit_buff_amt),sum(a.used_crit_corp_buff_amt),sum(a.used_crit_med_buff_amt)
         FROM tpa_enr_mem_buffer a
         WHERE member_seq_id=v_member_seq_id;
  BEGIN

    OPEN  policy_cur;
    FETCH policy_cur INTO v_buffer_allowed_yn,v_buffer_alloc_general_type_id, v_total_buffer_amount,v_member_buffer_yn,v_total_med_buffer_amount,v_total_crit_buffer_amount,v_total_crit_corp_buff_amt,v_total_crit_med_buff_amt,v_buffer_alloc_amount,v_buffer_med_alloc_amount,v_buff_crit_alloc_amt,v_buff_crit_corp_alloc_amt,v_buff_crit_med_alloc_amt;
    CLOSE policy_cur;

    OPEN  mem_buff_cur;
    FETCH mem_buff_cur INTO v_member_buffer, v_member_med_buffer ,v_member_crit_buffer, v_member_crit_corp_buffer,v_member_crit_med_buffer;
    CLOSE mem_buff_cur;

    IF v_mem_general_type_id = 'PFL' THEN
      IF v_buffer_alloc_general_type_id = 'BAI' THEN
        OPEN  pfl_ind_buff_cur;
        FETCH pfl_ind_buff_cur INTO v_used_buffer,v_used_med_buffer,v_used_crit_buffer,v_used_crit_corp_buffer,v_used_crit_med_buffer ;
        CLOSE pfl_ind_buff_cur;
      ELSE
        OPEN  fam_buff_cur;
        FETCH fam_buff_cur INTO v_used_buffer,v_used_med_buffer,v_used_crit_buffer,v_used_crit_corp_buffer,v_used_crit_med_buffer ;
        CLOSE fam_buff_cur;
      END IF;
    ELSE
      IF v_buffer_alloc_general_type_id = 'BAI' THEN
        OPEN  pnf_ind_buff_cur;
        FETCH pnf_ind_buff_cur INTO v_used_buffer,v_used_med_buffer,v_used_crit_buffer,v_used_crit_corp_buffer,v_used_crit_med_buffer ;
        CLOSE pnf_ind_buff_cur;
      ELSE
        OPEN  fam_buff_cur;
        FETCH fam_buff_cur INTO v_used_buffer,v_used_med_buffer,v_used_crit_buffer,v_used_crit_corp_buffer,v_used_crit_med_buffer ;
        CLOSE fam_buff_cur;
      END IF;
    END IF;

  IF v_member_buffer_yn='Y' THEN  --KOCIBM
     IF v_mem_general_type_id != 'PFL' THEN
         OPEN  pnf_ind_buff_cur;
         FETCH pnf_ind_buff_cur INTO v_used_buffer,v_used_med_buffer,v_used_crit_buffer,v_used_crit_corp_buffer,v_used_crit_med_buffer ;
         CLOSE pnf_ind_buff_cur;
     ELSE
        OPEN  mem_used_cur;
        FETCH mem_used_cur INTO v_used_buffer,v_used_med_buffer,v_used_crit_buffer,v_used_crit_corp_buffer,v_used_crit_med_buffer ;
        CLOSE mem_used_cur;
    END if;

      IF ( v_claim_type='NRML' AND v_Buffer_Type='CORB' AND (nvl(v_member_buffer,0)-nvl(v_used_buffer,0)) >= v_required_buffer )OR
        ( v_claim_type='NRML' AND v_Buffer_Type='MEDB' AND (nvl(v_member_med_buffer,0)-nvl(v_used_med_buffer,0)) >= v_required_buffer )OR
        ( v_claim_type='CRTL' AND v_Buffer_Type='CRTB' AND (nvl(v_member_crit_buffer,0)-nvl(v_used_crit_buffer,0)) >= v_required_buffer) OR
        ( v_claim_type='CRTL' AND v_Buffer_Type='CORB' AND (nvl(v_member_crit_corp_buffer,0)-nvl(v_used_crit_corp_buffer,0)) >= v_required_buffer) OR
        ( v_claim_type='CRTL' AND v_Buffer_Type='MEDB' AND (nvl(v_member_crit_med_buffer,0)-nvl(v_used_crit_med_buffer,0)) >= v_required_buffer )THEN
         RETURN TRUE;
      ELSE
         RETURN FALSE;
      END IF;
  ELSE   --KOCIBM
    IF --v_buffer_alloc_amount - nvl(v_used_buffer,0) >=  v_required_buffer THEN
      ( v_claim_type='NRML' AND v_Buffer_Type='CORB' AND (nvl(v_buffer_alloc_amount,0)-nvl(v_used_buffer,0)) >= v_required_buffer )OR
        ( v_claim_type='NRML' AND v_Buffer_Type='MEDB' AND (nvl(v_buffer_med_alloc_amount,0)-nvl(v_used_med_buffer,0)) >= v_required_buffer )OR
        ( v_claim_type='CRTL' AND v_Buffer_Type='CRTB' AND (nvl(v_buff_crit_alloc_amt,0)-nvl(v_used_crit_buffer,0)) >= v_required_buffer) OR
        ( v_claim_type='CRTL' AND v_Buffer_Type='CORB' AND (nvl(v_buff_crit_corp_alloc_amt,0)-nvl(v_used_crit_corp_buffer,0)) >= v_required_buffer) OR
        ( v_claim_type='CRTL' AND v_Buffer_Type='MEDB' AND (nvl(v_buff_crit_med_alloc_amt,0)-nvl(v_used_crit_med_buffer,0)) >= v_required_buffer ) THEN
      RETURN TRUE;
    ELSE
      RETURN FALSE;
    END IF;
   END IF;
  END  mem_buff_availaility;
  --===================================================================================
  FUNCTION pol_buff_availability(
    v_required_buffer              IN tpa_enr_balance.buffer_amount%TYPE,
    v_policy_seq_id                IN tpa_enr_policy.policy_seq_id%TYPE,
    v_claim_type                   IN VARCHAR2,
    v_buffer_type                  IN VARCHAR2
  )RETURN BOOLEAN
  IS
    v_buffer_allowed_yn            tpa_enr_policy.buffer_allowed_yn%TYPE;
    v_buffer_alloc_general_type_id tpa_enr_policy.buffer_alloc_general_type_id%TYPE;
    v_total_buffer_amount          tpa_enr_policy.total_buffer_amount%TYPE ;
    v_total_med_buffer_amount       tpa_enr_policy.total_buffer_amount%TYPE ;
    v_total_crit_buffer_amount      tpa_enr_policy.total_buffer_amount%TYPE ;
    v_total_crit_corp_buff_amt tpa_enr_policy.total_buffer_amount%TYPE ;
    v_total_crit_med_buff_amt  tpa_enr_policy.total_buffer_amount%TYPE ;
    v_policy_sub_general_type_id   tpa_enr_policy.policy_sub_general_type_id%TYPE ;
    v_used_buffer                  tpa_enr_balance.buffer_amount%TYPE;
    v_used_med_buffer              tpa_enr_balance.buffer_amount%TYPE;
    v_used_crit_buffer             tpa_enr_balance.buffer_amount%TYPE;
    v_used_crit_corp_buffer        tpa_enr_balance.buffer_amount%TYPE;
    v_used_crit_med_buffer         tpa_enr_balance.buffer_amount%TYPE;

    CURSOR policy_cur IS SELECT a.buffer_allowed_yn,a.buffer_alloc_general_type_id,
      a.total_buffer_amount, a.policy_sub_general_type_id,a.tot_med_buff_amount,a.tot_crit_buff_amount,a.tot_crit_corp_buff_amount,a.tot_crit_med_buff_amount
      FROM tpa_enr_policy a WHERE a.policy_seq_id = v_policy_seq_id;
     
 
    CURSOR pfl_buff_cur IS
      SELECT SUM(NVL(a.utilised_buff_amount,0)),sum(NVL(a.utilised_med_buff_amount,0)),
      sum(NVL(a.utilised_crit_buff_amount,0)),sum(NVL(a.utilised_crit_corp_buff_amt,0)),sum(NVL(a.utilised_crit_med_buff_amt,0))
         FROM tpa_enr_balance a WHERE a.policy_seq_id = v_policy_seq_id;

    CURSOR pnf_ind_buff_cur IS
      SELECT sum(NVL(a.utilised_buff_amount,0)),sum(NVL(a.utilised_med_buff_amount,0)),
      sum(NVL(a.utilised_crit_buff_amount,0)),sum(NVL(a.utilised_crit_corp_buff_amt,0)),sum(NVL(a.utilised_crit_med_buff_amt,0))
         FROM tpa_enr_balance a WHERE a.policy_seq_id = v_policy_seq_id;

    CURSOR pnf_fam_buff_cur IS
      SELECT SUM(util_buff_amount),SUM(util_med_buff_amount),SUM(util_crit_buff_amount),SUM(util_crit_corp_buff_amount),SUM(util_crit_med_buff_amount) FROM
       ( SELECT a.policy_group_seq_id , MAX(NVL(a.utilised_buff_amount,0)) AS util_buff_amount,MAX(NVL(a.Utilised_Med_Buff_Amount,0)) AS util_med_buff_amount,
       MAX(NVL(a.utilised_crit_buff_amount,0)) AS util_crit_buff_amount,MAX(NVL(a.utilised_crit_corp_buff_amt,0)) AS util_crit_corp_buff_amount,
       MAX(NVL(a.utilised_crit_med_buff_amt,0)) AS util_crit_med_buff_amount
         FROM tpa_enr_balance a WHERE a.policy_seq_id = v_policy_seq_id
         GROUP BY a.policy_group_seq_id);
  BEGIN
    OPEN  policy_cur;
    FETCH policy_cur INTO v_buffer_allowed_yn,v_buffer_alloc_general_type_id, v_total_buffer_amount, v_policy_sub_general_type_id,v_total_med_buffer_amount,v_total_crit_buffer_amount,v_total_crit_corp_buff_amt,v_total_crit_med_buff_amt;
    CLOSE policy_cur;

    IF v_policy_sub_general_type_id = 'PFL' THEN
      OPEN  pfl_buff_cur;
      FETCH pfl_buff_cur INTO v_used_buffer,v_used_med_buffer,v_used_crit_buffer,v_used_crit_corp_buffer,v_used_crit_med_buffer;
      CLOSE pfl_buff_cur;
    ELSE
      IF v_buffer_alloc_general_type_id = 'BAI' THEN
        OPEN  pnf_ind_buff_cur;
        FETCH pnf_ind_buff_cur INTO v_used_buffer,v_used_med_buffer,v_used_crit_buffer,v_used_crit_corp_buffer,v_used_crit_med_buffer;
        CLOSE pnf_ind_buff_cur;
      ELSE
        OPEN  pnf_fam_buff_cur;
        FETCH pnf_fam_buff_cur INTO v_used_buffer,v_used_med_buffer,v_used_crit_buffer,v_used_crit_corp_buffer,v_used_crit_med_buffer;
        CLOSE pnf_fam_buff_cur;
      END IF;
    END IF;
    IF ( v_claim_type='NRML' AND v_Buffer_Type='CORB' AND  v_total_buffer_amount - v_used_buffer >=  v_required_buffer) OR
      ( v_claim_type='NRML' AND v_Buffer_Type='MEDB' AND v_total_med_buffer_amount - v_used_med_buffer >=  v_required_buffer) OR
      ( v_claim_type='CRTL' AND v_Buffer_Type='CRTB' AND v_total_crit_buffer_amount - v_used_crit_buffer >=  v_required_buffer) OR
      ( v_claim_type='CRTL' AND v_Buffer_Type='CORB' AND v_total_crit_corp_buff_amt - v_used_crit_corp_buffer >=  v_required_buffer) OR
      ( v_claim_type='CRTL' AND v_Buffer_Type='MEDB' AND v_total_crit_med_buff_amt - v_used_crit_med_buffer >=  v_required_buffer) THEN
      RETURN TRUE;
    ELSE
      RETURN FALSE;
    END IF;
  END pol_buff_availability;
  --===================================================================================
  PROCEDURE return_clm_to_coding (
    v_seq_id                              IN NUMBER,
    v_event_seq_id                        IN tpa_event.event_seq_id%TYPE
  )
  IS

    CURSOR event_cur IS SELECT a.event_name, a.simple_review_count,a.event_seq_id
       FROM tpa_event a JOIN tpa_workflow b ON (a.workflow_seq_id = b.workflow_seq_id)
       WHERE b.sub_general_type_id = 'CLM' AND a.order_number = 1;
    event_rec                 event_cur%ROWTYPE;

  BEGIN

    OPEN  event_cur;
    FETCH event_cur INTO event_rec;
    CLOSE event_cur;

    UPDATE clm_general_details a SET
          a.event_seq_id = event_rec.event_seq_id ,
          a.review_count = event_rec.simple_review_count,
          a.required_review_count = event_rec.simple_review_count
          WHERE a.claim_seq_id = v_seq_id;

  END  return_clm_to_coding;
  --=====================================================================================
  -- CREATED BY : Ramakrishna K M
  -- ON         : 19-08-2010
  -- PURPOSE    : To display the Service Tax Calculate icon based on the conditions.
  --=====================================================================================
  PROCEDURE service_tax_validation (
    v_claim_seq_id               IN  clm_general_details.claim_seq_id%TYPE,
    v_ward_type_id               IN  clm_bill_details.ward_type_id%TYPE,
    v_clm_bill_dtl_seq_id        IN  clm_bill_details.clm_bill_dtl_seq_id%TYPE
  )
  IS
    CURSOR claim_type_cur IS
    SELECT B.CLAIM_GENERAL_TYPE_ID FROM clm_general_details A JOIN clm_inward B ON (A.CLAIMS_INWARD_SEQ_ID=B.CLAIMS_INWARD_SEQ_ID)
    WHERE A.claim_seq_id = v_claim_seq_id;

    CURSOR ward_type_cur IS
    SELECT allow_duplicate_yn,service_tax_applicable_yn
    FROM tpa_hosp_ward_code WHERE ward_type_id=v_ward_type_id;

    CURSOR claim_bill_st_cur IS
    SELECT COUNT(1),b.clm_bill_dtl_seq_id FROM clm_bill_details B
    WHERE B.Ward_Type_Id='STX'
    AND B.CLM_BILL_SEQ_ID IN (SELECT A.CLM_BILL_SEQ_ID
                              FROM clm_bill_header A
                              WHERE A.CLAIM_SEQ_ID=v_claim_seq_id)
    GROUP BY b.clm_bill_dtl_seq_id;

    rec_claim_type           claim_type_cur%ROWTYPE;
    rec_ward_type            ward_type_cur%ROWTYPE;
    v_ctr                    NUMBER(3);
    v_claim_bill_dtl_seq_id  clm_bill_details.clm_bill_dtl_seq_id%TYPE;

  BEGIN
    OPEN claim_type_cur;
    FETCH claim_type_cur INTO rec_claim_type;
    CLOSE claim_type_cur;

    OPEN ward_type_cur;
    FETCH ward_type_cur INTO rec_ward_type;
    CLOSE ward_type_cur;

    IF rec_claim_type.claim_general_type_id='CTM' AND v_ward_type_id='STX' THEN  --rec_ward_type.allow_duplicate_yn='N'
       raise_application_error(-20776,'Selected AccountHead is not allowed for Member Claim.');
    END IF;

    IF rec_claim_type.claim_general_type_id='CNH' AND v_ward_type_id='STX' THEN
       OPEN claim_bill_st_cur;
       FETCH claim_bill_st_cur INTO v_ctr,v_claim_bill_dtl_seq_id;
       CLOSE claim_bill_st_cur;

       IF v_clm_bill_dtl_seq_id IS NULL OR v_clm_bill_dtl_seq_id!=v_claim_bill_dtl_seq_id THEN
         IF v_ctr = 1  THEN
            raise_application_error( -20777,'Selected AccountHead already exists.');
          END IF;
       END IF;
    END IF;
  END service_tax_validation;
--=====================================================================================
  --=====================================================================================
  -- CREATED BY : Anil M K
  -- ON         : 24-08-2010
  -- PURPOSE    : To calculate the Service Tax Amount.
  -- Comments   : Ravi added copay buffer for service tax 17jan
  --=====================================================================================
  PROCEDURE calc_service_tax(
    v_claim_seq_id              IN clm_general_details.claim_seq_id%TYPE,
    v_co_pay_amt                IN clm_general_details.co_payment_amount%TYPE,
    v_discount_amt              IN clm_general_details.discount_amount%TYPE,
    v_service_tax_calc_amt      IN OUT clm_general_details.serv_tax_calc_amount%TYPE,
    v_final_appr_amt            IN OUT clm_general_details.Total_App_Amount%TYPE,
    v_serv_tax_calc_percentage  IN OUT clm_general_details.serv_tax_calc_percentage%TYPE
  )
  IS
    v_total_bills_app_amt         clm_bill_details.allowed_amount%TYPE;
    v_total_claim_amt             clm_general_details.Total_App_Amount%TYPE;
    v_total_bills_after_med_amt   clm_general_details.Total_App_Amount%TYPE;
    v_total_medical_app_amt       clm_general_details.Total_App_Amount%TYPE;
    v_taxable_amount              clm_general_details.Total_App_Amount%TYPE;
    v_date_of_admission           clm_general_details.date_of_admission%TYPE;
    v_applicable_rate_percent     service_tax_config.applicable_rate_percent%TYPE;
    v_requested_amount            clm_bill_details.requested_amount%TYPE;
    v_disCopayAmt                 clm_general_details.Total_App_Amount%TYPE;
    v_date_of_discharge           clm_general_details.date_of_discharge%TYPE;
    v_copay_buffer                clm_general_details.co_payment_buffer_amount%TYPE; --KOCIBM

    CURSOR cur_ser_tx IS SELECT sc.rev_date_from,sc.rev_date_to,sc.applicable_rate_percent FROM service_tax_config sc ORDER BY sc.serv_tax_seq_id;

    CURSOR cur_copay_buff IS SELECT h.co_payment_buffer_amount FROM Clm_General_Details H where claim_seq_id=v_claim_seq_id; --KOCIBM

  BEGIN

    /*SELECT SUM(bd.allowed_amount) INTO v_total_bills_app_amt
    FROM clm_bill_header bh
    JOIN clm_bill_details bd ON (bd.clm_bill_seq_id=bh.clm_bill_seq_id)
    WHERE bh.claim_seq_id=v_claim_seq_id;*/

    OPEN  cur_copay_buff; --KOCIBM
    FETCH cur_copay_buff INTO v_copay_buffer;
    CLOSE cur_copay_buff;

    SELECT SUM(approved_amount) INTO v_total_bills_app_amt
    FROM ailment_caps X JOIN icd_pcs_detail Y ON ( X.icd_pcs_seq_id = Y.icd_pcs_seq_id )
    WHERE y.claim_seq_id = v_claim_seq_id;

    SELECT A.requested_amount INTO v_requested_amount
     FROM clm_bill_details A LEFT OUTER JOIN clm_bill_header B ON (A.clm_bill_seq_id=B.clm_bill_seq_id)
     WHERE B.Claim_Seq_Id=v_claim_seq_id
     AND A.Ward_Type_Id='STX';

    /*SELECT cg.date_of_admission INTO v_date_of_admission
    FROM clm_general_details cg
    WHERE cg.claim_seq_id=v_claim_seq_id;*/

    SELECT cg.date_of_discharge INTO v_date_of_discharge
    FROM clm_general_details cg
    WHERE cg.claim_seq_id=v_claim_seq_id;

     v_disCopayAmt:= NVL(v_discount_amt,0)+NVL(v_co_pay_amt,0)+NVL(v_copay_buffer,0); --KOCIBM

     IF v_discount_amt > v_total_bills_app_amt THEN
        raise_application_error( -20778,'Discount Amount is exceeding Bills Approved Amtount');
     END IF;

     IF v_co_pay_amt + NVL(v_copay_buffer,0) > v_total_bills_app_amt THEN
        raise_application_error( -20779,'Copay Amount is exceeding Bills Approved Amtount');
     END IF;

     IF v_disCopayAmt > v_total_bills_app_amt THEN
        raise_application_error( -20780,'Sum of Discount and Copay Amount should not be greater than Bills Approved Amtount');
     END IF;

    --SELECT INTO FROM clm_general_details cg WHERE cg.claim_seq_id=v_claim_seq_id;
    v_total_claim_amt := v_total_bills_app_amt-nvl(v_co_pay_amt,0)-nvl(v_discount_amt,0)-NVL(v_copay_buffer,0); --KOCIBM

    SELECT SUM(bd.allowed_amount) INTO v_total_medical_app_amt
    FROM clm_bill_header bh
    JOIN clm_bill_details bd ON (bd.clm_bill_seq_id=bh.clm_bill_seq_id)
    WHERE bh.claim_seq_id=v_claim_seq_id
    AND EXISTS (SELECT 1 FROM tpa_hosp_ward_code wc
                         WHERE wc.service_tax_applicable_yn='N'
                         AND wc.ward_type_id=bd.ward_type_id);

    IF v_total_medical_app_amt IS NULL OR v_total_medical_app_amt=0 THEN
     v_total_bills_after_med_amt :=0;
    ELSE
     --v_total_bills_after_med_amt := /*v_total_bills_app_amt-nvl(*/v_total_medical_app_amt/*,0)*/-v_co_pay_amt;
     v_total_bills_after_med_amt := nvl(v_total_medical_app_amt,0)/*-nvl(v_co_pay_amt,0)*/;

    END IF;

    FOR i IN cur_ser_tx LOOP

        /*v_applicable_rate_percent:= CASE WHEN trunc(v_date_of_admission) BETWEEN trunc(i.rev_date_from) AND nvl(trunc(i.rev_date_to),SYSDATE) THEN
                                   i.applicable_rate_percent ELSE 0 END;*/
         v_applicable_rate_percent:= CASE WHEN trunc(v_date_of_discharge) BETWEEN trunc(i.rev_date_from) AND nvl(trunc(i.rev_date_to),SYSDATE) THEN
                                   i.applicable_rate_percent ELSE 0 END;
        IF v_applicable_rate_percent <> 0 THEN EXIT; END IF;

    END LOOP;
    v_taxable_amount:=(v_total_claim_amt-nvl(v_total_bills_after_med_amt,0));

    IF v_service_tax_calc_amt is null then
       v_service_tax_calc_amt := ROUND((v_taxable_amount*v_applicable_rate_percent)/100);
    END IF;

    IF v_service_tax_calc_amt > v_requested_amount THEN
       v_service_tax_calc_amt := ROUND(v_requested_amount);
    ELSIF v_service_tax_calc_amt < 0 THEN
       v_service_tax_calc_amt := 0;
    END IF;

    v_final_appr_amt := nvl(v_total_bills_after_med_amt,0)+v_taxable_amount+v_service_tax_calc_amt;

    v_serv_tax_calc_percentage := v_applicable_rate_percent;
  END calc_service_tax;
--======================================================================================
 PROCEDURE p_clm_inw_del_log (v_clm_inw_seq_id    clm_inward.claims_inward_seq_id%TYPE) IS

   BEGIN
     DELETE FROM clm_inward_del_log WHERE claims_inward_seq_id=v_clm_inw_seq_id;
     INSERT INTO clm_inward_del_log (SELECT * FROM clm_inward WHERE claims_inward_seq_id=v_clm_inw_seq_id);
   EXCEPTION WHEN OTHERS THEN
     NULL;
  END;
---========================================================================================
procedure cash_benefit_details(
    v_claim_seq_id  IN clm_general_details.claim_seq_id%TYPE,
    v_member_seq_id IN tpa_enr_policy_member.member_seq_id%TYPE,
    v_final_amt     OUT clm_cash_benefit.cb_approved_amount%TYPE,
    v_final_days    OUT clm_cash_benefit.cb_approved_amount%TYPE)
is

    cursor ward_cur is
      select b.ward_type_id, sum(b.number_of_days) number_of_days
        from clm_bill_header c
        left outer join clm_bill_details b
          on (b.clm_bill_seq_id = c.clm_bill_seq_id)
       where c.claim_seq_id = v_claim_seq_id
         and b.allow_yn = 'N'
         and c.bill_included_yn = 'Y'
         and b.ward_type_id in ('ROO', 'ICR')
       group by b.ward_type_id
       order by b.ward_type_id asc;

    ward_rec ward_cur%ROWTYPE;

    CURSOR mem_cur IS
      SELECT pol.policy_sub_general_type_id,
             a.policy_group_seq_id,
             a.mem_age,
             pol.product_seq_id,
             pol.enrol_type_id,
             pol.policy_seq_id,
             bal.sum_insured

        FROM tpa_enr_policy_member a
        join tpa_enr_policy_group gr
          on (a.policy_group_seq_id = gr.policy_group_seq_id)
        join tpa_enr_policy pol
          on (pol.policy_seq_id = gr.policy_seq_id)
        join tpa_enr_balance bal
          on ((bal.member_seq_id = a.member_seq_id and
             pol.policy_sub_general_type_id = 'PNF') OR
             (bal.policy_group_seq_id = a.policy_group_seq_id and
             pol.policy_sub_general_type_id = 'PFL'))
       WHERE a.member_seq_id = v_member_seq_id;

    mem_rec mem_cur%ROWTYPE;

    cursor cb_cur is

      select cb.ins_cash_benefit_seq_id,
             nvl(cb.room_amt, 0) room_amt,
             nvl(cb.acc_amt, 0) acc_amt,
             nvl(cb.icu_amt, 0) icu_amt,
             nvl(cb.conv_amt, 0) conv_amt,
             nvl(cb.room_days_claim, 0) room_days_claim,
             nvl(cb.acc_days_claim, 0) acc_days_claim,
             nvl(cb.icu_days_claim, 0) icu_days_claim,
             nvl(cb.conv_days_claim, 0) conv_days_claim,
             nvl(cb.room_per_si, 0) room_per_si,
             nvl(cb.acc_per_si, 0) acc_per_si,
             nvl(cb.icu_per_si, 0) icu_per_si,
             nvl(cb.conv_per_si, 0) conv_per_si,
             nvl(cb.policy_days, 0) policy_days
        from app.tpa_ins_cash_benefit cb
       where ((cb.product_seq_id = mem_rec.product_seq_id and mem_rec.enrol_type_id <> 'COR') OR
             (cb.policy_seq_id = mem_rec.policy_seq_id and mem_rec.enrol_type_id = 'COR'))
         and mem_rec.mem_age between cb.from_age and cb.to_age;

    cb_rec cb_cur%ROWTYPE;

    cursor clm_cur is

      select ail.specialty_general_type_id,
             gen.claim_seq_id,
             gen.claim_number,
             en.member_seq_id,
             en.tpa_enrollment_id
        from clm_general_details gen
        join clm_enroll_details en
          on (en.claim_seq_id = gen.claim_seq_id)
        join clm_inward inw
          on (inw.claims_inward_seq_id = gen.claims_inward_seq_id)
        left outer join ailment_details ail
          on (ail.claim_seq_id = gen.claim_seq_id)
       where gen.claim_seq_id = v_claim_seq_id;

    clm_rec clm_cur%ROWTYPE;

    CURSOR mem_days_cur IS /*SELECT 120 from dual;*/
   select nvl(sum(a.Hcb_Days),0)  FROM clm_cash_benefit a
       WHERE a.member_seq_id = v_member_seq_id
          AND a.clm_status_general_type_id !='REJ'
          and a.Hcb_Days > 0;

   CURSOR family_days_cur IS /*SELECT 190 from dual;*/
    SELECT nvl(SUM(b.Hcb_Days),0)
      FROM tpa_enr_policy_member a JOIN clm_cash_benefit b ON (a.member_seq_id = b.member_seq_id)
      WHERE a.policy_group_seq_id = mem_rec.policy_group_seq_id AND b.clm_status_general_type_id != 'REJ'
      and b.Hcb_Days > 0;


    v_used_days      NUMBER(5);
    v_available_days NUMBER(5);
    v_cb_days        clm_cash_benefit.cb_days%TYPE;
    v_ctr            NUMBER(3);

    v_room_amt clm_cash_benefit.cb_approved_amount%TYPE := 0;
    v_acc_amt  clm_cash_benefit.cb_approved_amount%TYPE := 0;
    v_icu_amt  clm_cash_benefit.cb_approved_amount%TYPE := 0;
    v_conv_amt clm_cash_benefit.cb_approved_amount%TYPE := 0;

    v_room_days      clm_cash_benefit.cb_days%TYPE := 0;
    v_acc_days       clm_cash_benefit.cb_days%TYPE := 0;
    v_icu_days       clm_cash_benefit.cb_days%TYPE := 0;
    v_conv_days      clm_cash_benefit.cb_days%TYPE := 0;
    v_conv_tot       clm_cash_benefit.cb_days%TYPE := 0;
    v_mem_age        tpa_enr_policy_member.mem_age%type := 0;
    v_product_seq_id tpa_ins_product.product_seq_id%type := 0;

  begin

    OPEN mem_cur;
    FETCH mem_cur INTO mem_rec;
    CLOSE mem_cur;

    OPEN clm_cur;
    FETCH clm_cur INTO clm_rec;
    CLOSE clm_cur;

    OPEN cb_cur;
    FETCH cb_cur  INTO cb_rec;
    CLOSE cb_cur;

if mem_rec.policy_sub_general_type_id = 'PNF' then

    OPEN mem_days_cur;
    FETCH mem_days_cur  INTO v_used_days;
    CLOSE mem_days_cur;

elsif mem_rec.policy_sub_general_type_id = 'PFL' then

    OPEN family_days_cur;
    FETCH family_days_cur  INTO v_used_days;
    CLOSE family_days_cur;

end if;


 if (cb_rec.policy_days - v_used_days ) >= 0 then

    open ward_cur;
    loop
      fetch ward_cur into ward_rec;
      exit when ward_cur%notfound;

      if ward_rec.ward_type_id = 'ROO'  then
        v_final_days := nvl(v_final_days, 0) + ward_rec.number_of_days;
      elsif ward_rec.ward_type_id = 'ICR' then
        v_final_days := nvl(v_final_days, 0) + ward_rec.number_of_days;
      end if;


      if ward_rec.ward_type_id = 'ICR' then
        if (cb_rec.policy_days - v_used_days ) >= 0 then

          v_icu_amt  := least(cb_rec.policy_days - v_used_days,
                                ward_rec.number_of_days,cb_rec.icu_days_claim) *
                        least(cb_rec.icu_amt,case when cb_rec.icu_per_si > 0
            then (cb_rec.icu_per_si * mem_rec.sum_insured )/ 100  else cb_rec.icu_amt end);

          v_icu_days := least(cb_rec.policy_days - v_used_days,
                              ward_rec.number_of_days,
                              cb_rec.icu_days_claim);
        end if;

      elsif ward_rec.ward_type_id = 'ROO' then

        if (cb_rec.policy_days - v_used_days - v_icu_days) >= 0 then

          v_room_amt  := least(cb_rec.policy_days - v_used_days - v_icu_days,
                               ward_rec.number_of_days,
                               cb_rec.room_days_claim) *
                               least(cb_rec.room_amt,case when cb_rec.room_per_si > 0
            then (cb_rec.room_per_si * mem_rec.sum_insured )/ 100  else cb_rec.room_amt end);

          v_room_days := least(cb_rec.policy_days - v_used_days - v_icu_days,
                               ward_rec.number_of_days,
                               cb_rec.room_days_claim);
        end if;


      end if;

    end loop;
    close ward_cur;

    v_conv_tot := v_final_days;

    if clm_rec.specialty_general_type_id = 'TRA' then

      v_final_days := least(v_final_days, cb_rec.policy_days - v_used_days,cb_rec.acc_days_claim + cb_rec.room_days_claim);

    elsif  clm_rec.specialty_general_type_id != 'TRA'   then

      v_final_days := v_icu_days + v_room_days;

    end if;

    if clm_rec.specialty_general_type_id = 'TRA' then

      v_acc_amt := least(v_final_days, cb_rec.acc_days_claim) *
                   least(cb_rec.acc_amt,case when cb_rec.acc_per_si > 0
                            then (cb_rec.acc_per_si * mem_rec.sum_insured) / 100 else cb_rec.acc_amt end )
                                                     +
                 (least(case when v_final_days-cb_rec.acc_days_claim > 0
                 then v_final_days-cb_rec.acc_days_claim else 0 end , cb_rec.room_days_claim) *
                    least(cb_rec.room_amt,case when cb_rec.room_per_si > 0
            then (cb_rec.room_per_si * mem_rec.sum_insured )/ 100  else cb_rec.room_amt end));

    end if;


    v_final_amt := case when v_acc_amt > 0 then v_acc_amt
                   else  v_icu_amt + v_room_amt end;



 if (cb_rec.conv_amt > 0 or cb_rec.conv_per_si > 0)
   and cb_rec.conv_days_claim > 0
     then

  v_final_days := least(cb_rec.policy_days - v_used_days,v_conv_tot,cb_rec.conv_days_claim);

  v_final_amt := v_final_days * least(cb_rec.conv_amt,case when cb_rec.conv_per_si > 0
  then (cb_rec.conv_per_si * mem_rec.sum_insured )/ 100 else cb_rec.conv_amt end );

 end if;

 end if;

end cash_benefit_details;
---================================================================================================
procedure conv_cash_benefit(
  v_claim_seq_id  IN clm_general_details.claim_seq_id%TYPE,
  v_member_seq_id IN tpa_enr_policy_member.member_seq_id%TYPE,
  v_final_amt     OUT clm_cash_benefit.cb_approved_amount%TYPE,
  v_final_days    OUT clm_cash_benefit.cb_approved_amount%TYPE)
  is

    cursor ward_cur is
      select b.ward_type_id, sum(b.number_of_days) number_of_days
        from clm_bill_header c
        left outer join clm_bill_details b
          on (b.clm_bill_seq_id = c.clm_bill_seq_id)
       where c.claim_seq_id = v_claim_seq_id
         and b.allow_yn = 'N'
         and c.bill_included_yn = 'Y'
         and b.ward_type_id in ('ROO', 'ICR')
       group by b.ward_type_id
       order by b.ward_type_id asc;

    ward_rec ward_cur%ROWTYPE;

    CURSOR mem_cur IS
      SELECT pol.policy_sub_general_type_id,
             a.policy_group_seq_id,
             a.mem_age,
             pol.product_seq_id,
             pol.enrol_type_id,
             pol.policy_seq_id,
             bal.sum_insured

        FROM tpa_enr_policy_member a
        join tpa_enr_policy_group gr
          on (a.policy_group_seq_id = gr.policy_group_seq_id)
        join tpa_enr_policy pol
          on (pol.policy_seq_id = gr.policy_seq_id)
        join tpa_enr_balance bal
          on ((bal.member_seq_id = a.member_seq_id and
             pol.policy_sub_general_type_id = 'PNF') OR
             (bal.policy_group_seq_id = a.policy_group_seq_id and
             pol.policy_sub_general_type_id = 'PFL'))
       WHERE a.member_seq_id = v_member_seq_id;

    mem_rec mem_cur%ROWTYPE;

    cursor cb_cur is

     select cb.ins_conv_benf_seq_id,
             nvl(cb.conv_amt, 0) conv_amt,
             nvl(cb.conv_days_claim, 0) conv_days_claim,
             nvl(cb.conv_per_si, 0) conv_per_si,
             nvl(cb.policy_days, 0) policy_days
        from app.tpa_ins_canvalescence_benefit cb
       where ((cb.product_seq_id = mem_rec.product_seq_id and mem_rec.enrol_type_id <> 'COR') OR
             (cb.policy_seq_id = mem_rec.policy_seq_id and mem_rec.enrol_type_id = 'COR'))
         and mem_rec.mem_age between cb.from_age and cb.to_age;

    cb_rec cb_cur%ROWTYPE;

    cursor clm_cur is

      select ail.specialty_general_type_id,
             gen.claim_seq_id,
             gen.claim_number,
             en.member_seq_id,
             en.tpa_enrollment_id
        from clm_general_details gen
        join clm_enroll_details en
          on (en.claim_seq_id = gen.claim_seq_id)
        join clm_inward inw
          on (inw.claims_inward_seq_id = gen.claims_inward_seq_id)
        left outer join ailment_details ail
          on (ail.claim_seq_id = gen.claim_seq_id)
       where gen.claim_seq_id = v_claim_seq_id;

    clm_rec clm_cur%ROWTYPE;

 CURSOR mem_days_cur IS
   select count(a.clm_cash_benefit_seq_id)  FROM clm_cash_benefit a
       WHERE a.member_seq_id = v_member_seq_id
          AND a.clm_status_general_type_id !='REJ'
          and a.conv_days>0;

 CURSOR family_days_cur IS
    SELECT count(b.clm_cash_benefit_seq_id)
      FROM tpa_enr_policy_member a JOIN clm_cash_benefit b ON (a.member_seq_id = b.member_seq_id)
      WHERE a.policy_group_seq_id = mem_rec.policy_group_seq_id
      AND b.clm_status_general_type_id != 'REJ'
      and b.conv_days>0;

    v_used_days      NUMBER(5):=0;

  begin

    OPEN mem_cur;
    FETCH mem_cur INTO mem_rec;
    CLOSE mem_cur;

    OPEN clm_cur;
    FETCH clm_cur INTO clm_rec;
    CLOSE clm_cur;

    OPEN cb_cur;
    FETCH cb_cur  INTO cb_rec;
    CLOSE cb_cur;

if mem_rec.policy_sub_general_type_id = 'PNF' then

    OPEN mem_days_cur;
    FETCH mem_days_cur  INTO v_used_days;
    CLOSE mem_days_cur;

elsif mem_rec.policy_sub_general_type_id = 'PFL' then

    OPEN family_days_cur;
    FETCH family_days_cur  INTO v_used_days;
    CLOSE family_days_cur;
end if;

 if (cb_rec.policy_days - v_used_days ) > 0 then
    open ward_cur;
    loop
      fetch ward_cur into ward_rec;
      exit when ward_cur%notfound;

      if ward_rec.ward_type_id = 'ROO'  then
        v_final_days := nvl(v_final_days, 0) + ward_rec.number_of_days;
      elsif ward_rec.ward_type_id = 'ICR' then
        v_final_days := nvl(v_final_days, 0) + ward_rec.number_of_days;
      end if;
    end loop;
    close ward_cur;
if v_final_days > cb_rec.conv_days_claim then
  v_final_amt := least(cb_rec.conv_amt,case when cb_rec.conv_per_si > 0 then
  (mem_rec.sum_insured*cb_rec.conv_per_si)/100 else cb_rec.conv_amt end);
end if;
end if;
end conv_cash_benefit;

---===========================================================================================
PROCEDURE unassoc_claim_intimation (--KOC1349
    v_claim_seq_id                       IN  clm_general_details.claim_seq_id%TYPE,
    v_call_log_seq_id                    IN  tpa_call_log.call_log_seq_id%TYPE,
    v_added_by                           IN  CLM_GENERAL_DETAILS.added_by%TYPE,
    v_rows_processed                     IN  OUT NUMBER
  )
  IS
  BEGIN
    --pre_auth_pkg.reassign_user (  NULL , v_claim_seq_id , NULL , v_added_by , 'AUT');
    --pre_auth_pkg.check_clm_completed(v_claim_seq_id ,NULL,'APR',v_added_by );
    UPDATE clm_general_details a SET
       a.call_log_seq_id  = NULL ,
       a.updated_by       = v_added_by ,
       a.updated_date     = SYSDATE
       WHERE a.claim_seq_id  = v_claim_seq_id ;

    UPDATE tpa_call_claim_intimation b SET --to override the old intimation
              b.claim_seq_id    = NULL
        WHERE b.claim_seq_id    = v_claim_seq_id ;

    v_rows_processed := SQL%ROWCOUNT;
    COMMIT;
  END unassoc_claim_intimation;
---===========================================================================================



---============================================================================================================
-- procedure copay_adviced
-- cr koc1142 
-- author ravi
-- used in settlement * screen
--======================================================================================
PROCEDURE copay_adviced(
       v_mem_seq_id           IN  Pat_enroll_details.member_seq_id%TYPE,
       v_pol_grp_seq_id       IN  Tpa_enr_policy_group.policy_group_seq_id%TYPE,
       v_balance_seq_id       IN  Tpa_enr_balance.balance_seq_id%TYPE,
       v_clm_pat_seq_id       IN  Pat_general_details.pat_gen_detail_seq_id%TYPE,
       v_appr_amt             OUT Tpa_enr_balance.sum_insured%TYPE,
       v_max_copay            OUT Tpa_enr_balance.sum_insured%TYPE )  is

   v_pat_enr_seq_id          Pat_enroll_details.pat_enroll_detail_seq_id%TYPE;
   v_prod_policy_seq_id      Tpa_ins_prod_policy.prod_policy_seq_id%TYPE;
   v_poll_grp_seq_id         Tpa_enr_policy_group.policy_group_seq_id%TYPE;
   v_rest_ctr                NUMBER(3);

   CURSOR cur_pol(v_pol_grp_seq_id NUMBER) IS
      SELECT pg.policy_sub_general_type_id AS policy_type,pg.enrol_type_id, pg.policy_number,pg.policy_seq_id
      FROM Tpa_enr_policy pg
      INNER JOIN tpa_enr_policy_group epg ON (pg.policy_seq_id=epg.policy_seq_id)
      WHERE epg.policy_group_seq_id=v_pol_grp_seq_id;

    poll_cur cur_pol%ROWTYPE;

   CURSOR cur_cop_rest(v_prod_policy_seq_id NUMBER) IS
     SELECT ipp.copay_yn,ipp.copay_approved_amt,ipp.copay_fixed_amt,ipp.copay_perc,ipp.copay_level,
            ipp.si_restrict_yn,ipp.si_relation,ipp.si_restrict_amt,ipp.si_restrict_perc,ipp.si_type,
            ipp.si_rest_level
     FROM tpa_ins_prod_policy  ipp
     WHERE ipp.prod_policy_seq_id=v_prod_policy_seq_id;

   CURSOR cur_si IS
      SELECT teb.sum_insured,teb.utilised_sum_insured,teb.restrict_amt,teb.used_restrict_amt
      FROM Tpa_enr_balance teb
      WHERE teb.balance_seq_id=v_balance_seq_id;

   CURSOR cur_polc(v_policy_seq_id NUMBER) IS
       SELECT gt.prod_policy_seq_id
       FROM Tpa_enr_policy GH
       LEFT OUTER JOIN Tpa_ins_prod_policy GT ON (GH.policy_seq_id=GT.policy_seq_id)
       LEFT OUTER JOIN Tpa_ins_prod_policy_rules GM ON (GT.prod_policy_seq_id=GM.prod_policy_seq_id)
       WHERE GH.policy_seq_id=v_policy_seq_id;

   CURSOR cur_prod(v_policy_seq_id NUMBER) IS
        SELECT tipp.prod_policy_seq_id
        FROM tpa_enr_policy tep
        LEFT OUTER JOIN tpa_ins_product tip ON (tip.product_seq_id=tep.product_seq_id)
        LEFT OUTER JOIN tpa_ins_prod_policy tipp ON (tipp.product_seq_id=tip.product_seq_id)
        WHERE tep.policy_seq_id=v_policy_seq_id;

    cop_rest_cur        cur_cop_rest%ROWTYPE;
    si_cur              cur_si%ROWTYPE;
    prod_pol            cur_polc%ROWTYPE;
    v_config_amt        tpa_enr_balance.sum_insured%TYPE;
    v_used_amt          tpa_enr_balance.utilised_sum_insured%TYPE;
    v_age_flag          varchar2(3);

    v_sum_ins_ava         tpa_enr_balance.sum_insured%TYPE;
    v_rfm_ins_ava         tpa_enr_balance.sum_insured%TYPE;
    v_age_ins_ava         tpa_enr_balance.sum_insured%TYPE;

 BEGIN

      OPEN  cur_pol(v_pol_grp_seq_id);
      FETCH cur_pol INTO poll_cur;
      CLOSE cur_pol;

    IF poll_cur.enrol_type_id ='COR' THEN
       OPEN  cur_polc(poll_cur.policy_seq_id);
       FETCH cur_polc INTO prod_pol;
       CLOSE cur_polc;
    ELSE
       OPEN  cur_prod(poll_cur.policy_seq_id);
       FETCH cur_prod INTO prod_pol;
       CLOSE cur_prod;
    END IF;

       OPEN cur_cop_rest(prod_pol.prod_policy_seq_id);
       FETCH cur_cop_rest INTO cop_rest_cur;
       CLOSE cur_cop_rest;

       OPEN  cur_si;
       FETCH cur_si INTO si_cur;
       CLOSE cur_si;

   SELECT clm_enroll_detail_seq_id INTO v_pat_enr_seq_id
    FROM clm_enroll_details
    WHERE claim_seq_id=v_clm_pat_seq_id;

     Pre_auth_pkg.p_rest_si(v_pat_enr_seq_id,v_mem_seq_id,v_poll_grp_seq_id,v_rest_ctr,'C');

    IF v_rest_ctr>0 THEN
       age_amount_rest(v_clm_pat_seq_id, 'C', v_config_amt , v_used_amt ,v_age_flag );

       IF v_age_flag ='N' THEN
         v_max_copay:= si_cur.restrict_amt*(1-nvl(cop_rest_cur.copay_perc,0)/100);
        IF (si_cur.restrict_amt*(1-nvl(cop_rest_cur.copay_perc,0)/100)-nvl(si_cur.used_restrict_amt,0))/(1-nvl(cop_rest_cur.copay_perc,0)/100)<
           (si_cur.sum_insured*(1-nvl(cop_rest_cur.copay_perc,0)/100)-nvl(si_cur.utilised_sum_insured,0))/(1-nvl(cop_rest_cur.copay_perc,0)/100)
        THEN
        v_appr_amt :=(si_cur.restrict_amt*(1-nvl(cop_rest_cur.copay_perc,0)/100)-nvl(si_cur.used_restrict_amt,0))/(1-nvl(cop_rest_cur.copay_perc,0)/100);
        ELSE
        v_appr_amt := (si_cur.sum_insured*(1-nvl(cop_rest_cur.copay_perc,0)/100)-nvl(si_cur.utilised_sum_insured,0))/(1-nvl(cop_rest_cur.copay_perc,0)/100);
        END IF;

       ELSIF v_age_flag = 'Y' THEN
            v_max_copay:= v_config_amt*(1-nvl(cop_rest_cur.copay_perc,0)/100);
        IF (v_config_amt*(1-nvl(cop_rest_cur.copay_perc,0)/100)-nvl(v_used_amt,0))/(1-nvl(cop_rest_cur.copay_perc,0)/100)<
           (si_cur.sum_insured*(1-nvl(cop_rest_cur.copay_perc,0)/100)-nvl(si_cur.utilised_sum_insured,0))/(1-nvl(cop_rest_cur.copay_perc,0)/100)

        THEN
        v_sum_ins_ava := (si_cur.sum_insured*(1-nvl(cop_rest_cur.copay_perc,0)/100)-nvl(si_cur.utilised_sum_insured,0))/(1-nvl(cop_rest_cur.copay_perc,0)/100);
        v_rfm_ins_ava := (si_cur.restrict_amt*(1-nvl(cop_rest_cur.copay_perc,0)/100)-nvl(si_cur.used_restrict_amt,0))/(1-nvl(cop_rest_cur.copay_perc,0)/100);
        v_appr_amt := (v_config_amt*(1-nvl(cop_rest_cur.copay_perc,0)/100)-nvl(v_used_amt,0))/(1-nvl(cop_rest_cur.copay_perc,0)/100);
        v_appr_amt := least(v_sum_ins_ava,v_rfm_ins_ava,v_appr_amt);
        ELSE
        v_appr_amt := (si_cur.sum_insured*(1-nvl(cop_rest_cur.copay_perc,0)/100)-nvl(si_cur.utilised_sum_insured,0))/(1-nvl(cop_rest_cur.copay_perc,0)/100);
        v_rfm_ins_ava := (si_cur.restrict_amt*(1-nvl(cop_rest_cur.copay_perc,0)/100)-nvl(si_cur.used_restrict_amt,0))/(1-nvl(cop_rest_cur.copay_perc,0)/100);
        v_appr_amt := least(v_appr_amt,v_rfm_ins_ava);
        END IF;
       END IF;

    ELSE
       v_max_copay:= si_cur.sum_insured*(1-nvl(cop_rest_cur.copay_perc,0)/100);
       v_appr_amt := (si_cur.sum_insured*(1-nvl(cop_rest_cur.copay_perc,0)/100)-nvl(si_cur.utilised_sum_insured,0))/(1-nvl(cop_rest_cur.copay_perc,0)/100);
     END IF;

    END;
--=======================================================================================================
-- procedure copay_restrict_check
-- cr koc1142 
-- author ravi
-- used in settlement * screen
--=======================================================================================================
 FUNCTION copay_restrict_check( v_mem_seq_id           IN Pat_enroll_details.member_seq_id%TYPE,
                                v_si_type              IN Tpa_ins_prod_policy.si_type%TYPE,
                                v_prod_policy_seq_id   IN Tpa_ins_prod_policy.prod_policy_seq_id%TYPE,
                                v_pat_gen_seq_id       IN pat_general_details.pat_gen_detail_seq_id%TYPE,
                                v_pat_app_amount       IN Tpa_enr_balance.sum_insured%TYPE,
                                v_clm_app_amount       IN Tpa_enr_balance.sum_insured%TYPE,
                                v_tot_sum_insured      IN Tpa_enr_balance.sum_insured%TYPE,
                                v_used_sum_insured     IN Tpa_enr_balance.utilised_sum_insured%TYPE,
                                v_rest_sum_insured     IN Tpa_enr_balance.restrict_amt%TYPE,
                                v_used_rest_si         IN Tpa_enr_balance.used_restrict_amt%TYPE,
                                v_max_app_amount       IN Tpa_enr_balance.sum_insured%Type,
                                v_pat_buff_amount      IN Buffer_header.pre_auth_buffer_app_amount%TYPE,
                                v_co_payment_amount    IN Pat_general_details.co_payment_amount%TYPE,
                                v_restrict_yn          IN Tpa_ins_prod_policy.si_restrict_yn%TYPE)

    RETURN NUMBER IS v_out NUMBER(15,2);

    v_copay_amt            Tpa_enr_balance.sum_insured%TYPE;
    v_out_sum              Tpa_enr_balance.sum_insured%TYPE;
    v_rest_value           Tpa_enr_balance.sum_insured%TYPE;
    v_ava_si               Tpa_enr_balance.sum_insured%TYPE;
    v_ava_rsi              Tpa_enr_balance.sum_insured%TYPE;

 CURSOR cur_cop_rest(v_prod_policy_seq_id NUMBER) IS
      SELECT ipp.copay_yn,ipp.copay_approved_amt,ipp.copay_fixed_amt,ipp.copay_perc,ipp.copay_level,
             ipp.si_restrict_yn,ipp.si_relation,ipp.si_restrict_amt,ipp.si_restrict_perc,ipp.si_type,
             ipp.si_rest_level
      FROM Tpa_ins_prod_policy  ipp
      WHERE ipp.prod_policy_seq_id=v_prod_policy_seq_id;

     cop_rest_cur cur_cop_rest%ROWTYPE;

 BEGIN

     OPEN  cur_cop_rest(v_prod_policy_seq_id);
     FETCH cur_cop_rest INTO cop_rest_cur;
     CLOSE cur_cop_rest;

  if cop_rest_cur.copay_yn='Y' and v_restrict_yn='N' then
      if cop_rest_cur.copay_fixed_amt is not null and cop_rest_cur.copay_perc is null then
         v_out_sum :=cop_rest_cur.copay_fixed_amt;
      elsif cop_rest_cur.copay_fixed_amt is null and cop_rest_cur.copay_perc is not null then
         v_out_sum :=v_tot_sum_insured *(1-nvl(cop_rest_cur.copay_perc,0)/100);
      elsif cop_rest_cur.copay_fixed_amt is not null and cop_rest_cur.copay_perc is not null and cop_rest_cur.si_rest_level='LL'  then
         v_out_sum := least(cop_rest_cur.si_restrict_amt,v_tot_sum_insured *(1-nvl(cop_rest_cur.copay_perc,0)/100));
   end if;

  elsif v_restrict_yn='Y'  then
      if cop_rest_cur.copay_perc is null then
         v_out_sum :=v_rest_sum_insured-cop_rest_cur.copay_fixed_amt;
      elsif nvl(cop_rest_cur.si_restrict_amt,0)>0 and cop_rest_cur.copay_perc is not null and cop_rest_cur.si_rest_level='LL' then
         v_out_sum := least(cop_rest_cur.si_restrict_amt,v_rest_sum_insured *(1-nvl(cop_rest_cur.copay_perc,0)/100));
    end if;
    end if;

    IF v_restrict_yn='N' then
      if v_max_app_amount>(v_out_sum-(v_used_sum_insured-(nvl(v_pat_app_amount,0)-nvl(v_clm_app_amount,0)))+nvl(v_pat_buff_amount,0)) then
         raise_application_error(-20815,'amount exceeds the family restricted amount');
         elsif v_max_app_amount<=(v_out_sum-(v_used_sum_insured-(nvl(v_pat_app_amount,0)-nvl(v_clm_app_amount,0)))+nvl(v_pat_buff_amount,0)) then
          v_out:=(v_out_sum-(v_used_sum_insured-(nvl(v_pat_app_amount,0)-nvl(v_clm_app_amount,0)))); /*end if;*/
         elsif v_max_app_amount=v_out_sum then
         v_out :=v_max_app_amount;
         else v_out :=0;
         end if;

       else
         if v_out_sum<(v_tot_sum_insured *(1-nvl(cop_rest_cur.copay_perc,0)/100)-(v_used_sum_insured-v_used_rest_si))
          then  v_rest_value:= v_out_sum;
            else v_rest_value:= (v_tot_sum_insured *(1-nvl(cop_rest_cur.copay_perc,0)/100)-(v_used_sum_insured-v_used_rest_si));
            end if;

      if v_max_app_amount>(v_rest_value-(v_used_rest_si-(nvl(v_pat_app_amount,0)-nvl(v_clm_app_amount,0)))+nvl(v_pat_buff_amount,0)) then
         raise_application_error(-20815,'amount exceeds the family restricted amount');
         elsif v_max_app_amount<=(v_rest_value-(v_used_rest_si-(nvl(v_pat_app_amount,0)-nvl(v_clm_app_amount,0)))+nvl(v_pat_buff_amount,0)) then
            if nvl(v_pat_buff_amount,0)>0 or (v_out_sum-v_used_rest_si)=0  then
                v_out :=0;
         else v_out:=(v_rest_value-(v_used_rest_si-(nvl(v_pat_app_amount,0)-nvl(v_clm_app_amount,0)))); end if;
         elsif v_max_app_amount=v_rest_value then
         v_out :=v_max_app_amount;
         else v_out :=0;
         end if;
     end if;
     return v_out;

 end;

--==========================================================================================================
-- procedure p_rest_si
-- cr koc1142 
-- author ravi
-- used for relation restriction
--=======================================================================================================
PROCEDURE p_rest_si(v_clm_enroll_detail_seq_id   IN Clm_enroll_details.clm_enroll_detail_seq_id%TYPE,
                      v_member_seq_id            IN Pat_enroll_details.member_seq_id%TYPE,
                      v_policy_group_seq_id      IN OUT Tpa_enr_policy_group.policy_group_seq_id%TYPE,
                      v_ctr2                     OUT NUMBER,
                      v_pat_typr                 IN VARCHAR2:=NULL)
     IS

    CURSOR cur_rest IS
      SELECT ped.policy_seq_id,ped.enrol_type_id
      from Pat_enroll_details ped
      WHERE ped.pat_enroll_detail_seq_id=v_clm_enroll_detail_seq_id;

    CURSOR cur_restc is
      SELECT ped.policy_seq_id,ped.enrol_type_id
      FROM  Clm_enroll_details ped
      WHERE ped.clm_enroll_detail_seq_id=v_clm_enroll_detail_seq_id;

      rest_cur            cur_rest%ROWTYPE;
      v_str_char          VARCHAR2(1000);
      v_result_set        SYS_REFCURSOR;

    v_prod_policy_seq_id  Tpa_ins_prod_policy.Prod_Policy_Seq_Id%TYPE;


    CURSOR cur_relation (v_prod_policy_seq_id    VARCHAR2) IS
    SELECT tps.copay_yn,tps.copay_approved_amt,tps.copay_fixed_amt,tps.copay_perc,
           tps.si_restrict_yn,tps.si_relation,tps.si_restrict_amt,tps.si_restrict_perc,tps.si_type,
           tps.rest_age,tps.rest_age_amt
     FROM  Tpa_ins_prod_policy tps
     WHERE tps.prod_policy_seq_id=v_prod_policy_seq_id;

     rel_cur      cur_relation%ROWTYPE;


    BEGIN

    IF v_pat_typr !='P' THEN
        OPEN  cur_restc;
        FETCH cur_restc INTO rest_cur;
        CLOSE cur_restc;
    ELSE
        OPEN cur_rest;
        FETCH cur_rest INTO rest_cur;
        CLOSE cur_rest;
    END IF;

   IF rest_cur.enrol_type_id='COR' THEN
   OPEN v_result_set FOR
       'SELECT gt.prod_policy_seq_id
        FROM tpa_enr_policy GH
        LEFT OUTER JOIN tpa_ins_prod_policy GT ON (GH.policy_seq_id=GT.policy_seq_id)
        LEFT OUTER JOIN tpa_ins_prod_policy_rules GM ON (GT.prod_policy_seq_id=GM.prod_policy_seq_id)
        WHERE GH.policy_seq_id=:v_policy_seq_id'
     USING rest_cur.policy_seq_id;

     FETCH v_result_set INTO v_prod_policy_seq_id;
     CLOSE v_result_set;
  ELSE
     OPEN v_result_set FOR
      'select tipp.prod_policy_seq_id
       from tpa_enr_policy tep
       left outer join tpa_ins_product tip on (tip.product_seq_id=tep.product_seq_id)
       left outer join tpa_ins_prod_policy tipp on (tipp.product_seq_id=tip.product_seq_id)
       where tep.policy_seq_id=:v_policy_seq_id'
      USING rest_cur.policy_seq_id;

     FETCH v_result_set INTO v_prod_policy_seq_id;
     CLOSE v_result_set;
   END IF;

    OPEN  cur_relation(v_prod_policy_seq_id);
    FETCH cur_relation INTO rel_cur;
    CLOSE cur_relation;

  IF nvl(rel_cur.si_restrict_yn,'N')='Y' THEN
        v_str_char := ''''||REPLACE(rel_cur.si_relation,'|',''',''')||'''';

     OPEN v_result_set FOR
      'select count(relship_type_id) from tpa_enr_policy_member where member_seq_id= '||v_member_seq_id||
      ' and relship_type_id in ('||v_str_char||')';
    FETCH v_result_set INTO v_ctr2;
    CLOSE v_result_set;

      ELSE v_ctr2:=0;
     END IF;

  END p_rest_si;
  --========================================================================================================
  PROCEDURE age_amount_rest(v_pat_clm_seq_id   IN Pat_General_Details.pat_gen_detail_seq_id%TYPE,
                            v_type             IN VARCHAR2,
                            v_config_amt       OUT TPA_ENR_BALANCE.Sum_Insured%TYPE,
                            v_used_amt         OUT TPA_ENR_BALANCE.Sum_Insured%TYPE,
                            v_age_flag         OUT VARCHAR2 )IS
     CURSOR cur_pat IS
      SELECT f.pat_enroll_detail_seq_id AS seq_id,f.member_seq_id,f.mem_age,policy_seq_id,enrol_type_id
      FROM pat_enroll_details f
      JOIN pat_general_details g ON (g.pat_enroll_detail_seq_id=f.pat_enroll_detail_seq_id)
      WHERE g.pat_gen_detail_seq_id=v_pat_clm_seq_id;

    CURSOR cur_clm IS
      SELECT f.clm_enroll_detail_seq_id AS seq_id,f.member_seq_id,f.mem_age,policy_seq_id,enrol_type_id
      FROM clm_enroll_details f
      JOIN clm_general_details g ON (g.claim_seq_id=f.claim_seq_id)
      WHERE g.claim_seq_id=v_pat_clm_seq_id;

    CURSOR cur_relation (v_prod_policy_seq_id VARCHAR2) IS
    SELECT nvl(rest_age,0) as rest_age, nvl(rest_age_amt,0) as rest_age_amt
     FROM  Tpa_ins_prod_policy tps
     WHERE tps.prod_policy_seq_id=v_prod_policy_seq_id and rest_age >0;

     relt_cur                   cur_relation%ROWTYPE;


      cur_rec                 cur_clm%rowtype;
      v_ctr                   NUMBER(5);
      v_alert                 VARCHAR2(45);
      v_pol_grp_seq_id        TPA_ENR_BALANCE.POLICY_GROUP_SEQ_ID%TYPE:=NULL;
      v_prod_policy_seq_id    tpa_ins_prod_policy.prod_policy_seq_id%TYPE;
      v_result_set            SYS_REFCURSOR;
      v_appr_si               TPA_ENR_BALANCE.Sum_Insured%TYPE;

    BEGIN

    IF v_type ='P' THEN
       OPEN cur_pat;
       FETCH cur_pat INTO cur_rec;
       CLOSE cur_pat;
    ELSE
       OPEN cur_clm;
       FETCH cur_clm INTO cur_rec;
       CLOSE cur_clm;
    END IF;

   p_rest_si (cur_rec.seq_id,cur_rec.member_seq_id ,v_pol_grp_seq_id,v_ctr ,v_type);

  IF  cur_rec.enrol_type_id='COR'  THEN
    OPEN v_result_set FOR
       'SELECT gt.prod_policy_seq_id
        FROM tpa_enr_policy GH
        LEFT OUTER JOIN tpa_ins_prod_policy GT ON (GH.policy_seq_id=GT.policy_seq_id)
        LEFT OUTER JOIN tpa_ins_prod_policy_rules GM ON (GT.prod_policy_seq_id=GM.prod_policy_seq_id)
     WHERE GH.policy_seq_id=:v_policy_seq_id' USING cur_rec.policy_seq_id;

     FETCH v_result_set INTO v_prod_policy_seq_id;
     CLOSE v_result_set;
 ELSE
     OPEN v_result_set FOR
    'SELECT tipp.prod_policy_seq_id
     FROM tpa_enr_policy tep
     LEFT OUTER JOIN tpa_ins_product tip on (tip.product_seq_id=tep.product_seq_id)
     LEFT OUTER JOIN tpa_ins_prod_policy tipp on (tipp.product_seq_id=tip.product_seq_id)
     WHERE tep.policy_seq_id=:v_policy_seq_id'  USING cur_rec.policy_seq_id;

     FETCH v_result_set INTO v_prod_policy_seq_id;
     CLOSE v_result_set;
   END IF;

   OPEN cur_relation (v_prod_policy_seq_id);
   FETCH cur_relation INTO relt_cur;
   CLOSe cur_relation;

    IF cur_rec.mem_age>=relt_cur.rest_age and relt_cur.rest_age>0  THEN

       v_age_flag := 'Y';

      

       SELECT SUM(appr_amt) INTO v_appr_si FROM (
       SELECT SUM(nvl(g.App_Sum_Insured,0)) appr_amt
       FROM pat_general_details g
       JOIN pat_enroll_details h on (g.pat_enroll_detail_seq_id=h.pat_enroll_detail_seq_id)
       WHERE h.member_seq_id=cur_rec.member_seq_id AND h.claim_id IS NULL AND h.pat_status_general_type_id='APR'
     UNION ALL
       SELECT sum(nvl(k.App_Sum_Insured,0)) appr_amt
        FROM clm_general_details k
        JOIN clm_enroll_details p ON (p.claim_seq_id=k.claim_seq_id)
        WHERE p.member_seq_id=cur_rec.member_seq_id AND p.clm_status_general_type_id='APR');

     v_config_amt  :=relt_cur.rest_age_amt;
     v_used_amt    :=nvl(v_appr_si,0);
   ELSE
     v_age_flag := 'N';
   END IF;
   END;
---=====================================================================================
PROCEDURE claims_freeze ( --KOCBJJ
          v_claim_seq_id                   IN clm_enroll_details.claim_seq_id%TYPE,
          v_clm_status_gen_type_id         IN clm_enroll_details.clm_status_general_type_id%TYPE,
          v_flag                           IN VARCHAR2,
          v_added_by                       IN NUMBER DEFAULT NULL)
   AS

 v_awc_yn                         VARCHAR2(10);

  CURSOR cur_awc IS
  SELECT
       cg.claim_number,
       cg.claim_sub_general_type_id,
       ce.ins_seq_id,
       ce.claimant_name,
       ce.clm_status_general_type_id AS clm_status,
       cii.clm_ins_status,
       cii.clm_ins_remarks,
       tii.abbrevation_code,
       cg.updated_by,
       cg.requested_amount as total_app_amount,
       cii.override_yn,
       cii.ins_intimation_req_yn
  FROM clm_general_details cg
  JOIN clm_enroll_details ce ON (cg.claim_seq_id=ce.claim_seq_id)
  left outer join app.clm_ins_intimation_details cii on (ce.claim_seq_id=cii.claim_seq_id)
  JOIN tpa_ins_info tii      ON (tii.ins_seq_id=ce.ins_seq_id)
  WHERE cg.claim_seq_id=v_claim_seq_id;

 awc_rec                    cur_awc%ROWTYPE;
 v_dest_msg_seq_id          destination_message.dest_msg_seq_id%TYPE;

  CURSOR cur_relation (v_prod_policy_seq_id VARCHAR2) IS
    SELECT tps.copay_yn,tps.copay_approved_amt,tps.copay_fixed_amt,tps.copay_perc,
           tps.si_restrict_yn,tps.si_relation,tps.si_restrict_amt,tps.si_restrict_perc,tps.si_type,
           tps.rest_age,tps.rest_age_amt,
           tps.Ins_Clm_Allow_Yn,tps.Ins_Clm_Operator,tps.Ins_Clm_Apr_Limit ,TPS.INS_REJ_ALLOW_YN,TPS.INS_CLM_APR_REJ_YN,
--new
           ins_clm_cl_rej_allow_yn,ins_clm_cm_rej_allow_yn,ins_clm_cl_apr_rej_yn,ins_clm_cm_apr_rej_yn,
           clm_cl_mail_flag,clm_cm_mail_flag,ins_clm_cl_allow_yn,ins_clm_cm_allow_yn,ins_clm_cl_operator,
           ins_clm_cm_operator,ins_clm_cl_apr_limit,ins_clm_cm_apr_limit,clm_mail_freq_hours,pat_mail_freq_hours,
           clm_mail_freq_mins,pat_mail_freq_mins
     FROM  Tpa_ins_prod_policy tps
     WHERE tps.prod_policy_seq_id=v_prod_policy_seq_id;

   CURSOR cur_pol IS
     SELECT pe.policy_number,pe.policy_seq_id,pe.enrol_type_id,PG.COMPLETED_YN,c.claim_general_type_id
     FROM clm_enroll_details pe
     JOIN clm_general_details pg ON (pe.claim_seq_id=pg.claim_seq_id)
     JOIN clm_inward C ON (pg.claims_inward_seq_id = c.claims_inward_seq_id )
     WHERE pg.claim_seq_id=v_claim_seq_id;

   pat_rec          cur_pol%ROWTYPE;
   relt_cur         cur_relation%ROWTYPE;


   v_prod_policy_seq_id        tpa_ins_prod_policy.prod_policy_seq_id%TYPE;
   v_result_set                SYS_REFCURSOR;
   v_count                     NUMBER(10);

 BEGIN
 
 /*insert into app.temp_rem values(v_claim_seq_id||','||
          v_clm_status_gen_type_id||','||
          v_flag||','||v_added_by);*/
 
    OPEN cur_pol;
    FETCH cur_pol INTO pat_rec;
    CLOSE cur_pol;
 IF pat_rec.enrol_type_id='COR' THEN
    OPEN v_result_set FOR
       'SELECT gt.prod_policy_seq_id
        FROM tpa_enr_policy GH
        LEFT OUTER JOIN tpa_ins_prod_policy GT ON (GH.policy_seq_id=GT.policy_seq_id)
        LEFT OUTER JOIN tpa_ins_prod_policy_rules GM ON (GT.prod_policy_seq_id=GM.prod_policy_seq_id)
     WHERE GH.policy_seq_id=:v_policy_seq_id' USING pat_rec.policy_seq_id;

     FETCH v_result_set INTO v_prod_policy_seq_id;
     CLOSE v_result_set;
 ELSE
     OPEN v_result_set FOR
    'SELECT tipp.prod_policy_seq_id
     FROM tpa_enr_policy tep
     LEFT OUTER JOIN tpa_ins_product tip on (tip.product_seq_id=tep.product_seq_id)
     LEFT OUTER JOIN tpa_ins_prod_policy tipp on (tipp.product_seq_id=tip.product_seq_id)
     WHERE tep.policy_seq_id=:v_policy_seq_id'  USING pat_rec.policy_seq_id;

     FETCH v_result_set into v_prod_policy_seq_id;
     CLOSE v_result_set;
   END IF;

      OPEN  cur_relation (v_prod_policy_seq_id);
       FETCH cur_relation INTO relt_cur;
       CLOSE cur_relation;

     OPEN cur_awc;
     FETCH cur_awc INTO awc_rec;
     CLOSE cur_awc;


    IF NVL(awc_rec.ins_intimation_req_yn,'N')!='Y'  
      AND  (case when pat_rec.claim_general_type_id = 'CNH' then relt_cur.ins_clm_cl_apr_rej_yn else relt_cur.ins_clm_cm_apr_rej_yn end) = 'Y' 
      AND ((case when pat_rec.claim_general_type_id = 'CNH' then relt_cur.Ins_Clm_Cl_Allow_Yn else relt_cur.Ins_Clm_Cm_Allow_Yn end )  = 'Y' 
      or (case when pat_rec.claim_general_type_id = 'CNH' then relt_cur.ins_clm_cl_rej_allow_yn else relt_cur.ins_clm_cm_rej_allow_yn end) ='Y') 
      AND v_flag!='O' THEN
      
      IF v_flag ='M' THEN

        select count(1) into v_count from app.clm_ins_intimation_details a
        where a.claim_seq_id=v_claim_seq_id;

       IF v_count=0 then
        insert into app.clm_ins_intimation_details
               (clm_ins_int_seq_id,
                claim_seq_id,
                clm_ins_status,
                clm_ins_send_date,
                added_by,
                added_date)
        values (app.clm_ins_intimation_seq.nextval,
                v_claim_seq_id,
                'INP',
                SYSDATE,
                v_added_by,
                sysdate);
       ELSE

         UPDATE app.clm_ins_intimation_details g SET
             g.clm_ins_status ='INP',
             g.clm_ins_send_date=SYSDATE,
             G.OVERRIDE_YN='N',
             g.ins_intimation_req_yn='N',
             G.UPDATED_BY=V_ADDED_BY,
             G.UPDATED_DATE=SYSDATE
         WHERE g.claim_seq_id=v_claim_seq_id;

       END IF;

      ELSE


              
     IF   (case when pat_rec.claim_general_type_id = 'CNH' then relt_cur.ins_clm_cl_apr_rej_yn else relt_cur.ins_clm_cm_apr_rej_yn end) ='Y' THEN
       IF (case when pat_rec.claim_general_type_id = 'CNH' then relt_cur.Ins_Clm_Cl_Allow_Yn else relt_cur.Ins_Clm_Cm_Allow_Yn end ) ='Y' AND awc_rec.clm_status IN ('APR') THEN


         if v_flag!='O' AND pat_rec.completed_yn='Y' THEN
         RAISE_APPLICATION_ERROR(-20107,' You cannot modify  this Pre-Auth/claim , Reviews are Completed');
         END IF;

          IF  ((awc_rec.clm_ins_status IS NULL  or awc_rec.clm_ins_status='REQ') AND NVL(v_clm_status_gen_type_id,'NA')!='REQ') AND  v_flag ='R'  THEN
              IF (case when pat_rec.claim_general_type_id = 'CNH' then relt_cur.Ins_Clm_cl_Operator else relt_cur.Ins_Clm_cm_Operator end )='GT' THEN
                 IF  awc_rec.total_app_amount>= (case when pat_rec.claim_general_type_id = 'CNH' then relt_cur.Ins_Clm_cl_Apr_Limit else relt_cur.Ins_Clm_cm_Apr_Limit end ) THEN  -----KOCBJJ
                 Raise_application_error(-20866,'The claims requires insurance decision please intimate claim');
                 END IF;
              ELSIF (case when pat_rec.claim_general_type_id = 'CNH' then relt_cur.Ins_Clm_cl_Operator else relt_cur.Ins_Clm_cm_Operator end ) ='LT' THEN
                    IF awc_rec.total_app_amount<= (case when pat_rec.claim_general_type_id = 'CNH' then relt_cur.Ins_Clm_cl_Apr_Limit else relt_cur.Ins_Clm_cm_Apr_Limit end )  THEN  -----KOCBJJ
                    Raise_application_error(-20866,'The claims requires insurance decision please intimate claim');
                    END IF;
              ELSIF (case when pat_rec.claim_general_type_id = 'CNH' then relt_cur.Ins_Clm_cl_Operator else relt_cur.Ins_Clm_cm_Operator end ) ='EQ' THEN
                    IF  awc_rec.total_app_amount= (case when pat_rec.claim_general_type_id = 'CNH' then relt_cur.Ins_Clm_cl_Apr_Limit else relt_cur.Ins_Clm_cm_Apr_Limit end )  THEN  -----KOCBJJ
                    Raise_application_error(-20866,'The claims requires insurance decision please intimate claim');
                    END IF;
              END IF;

            ELSIF  awc_rec.clm_ins_status ='INP' AND V_FLAG='S' THEN
                 Raise_application_error(-20863,'No Modifications Are Allowed, Claim Needs Insurance company Response');

            ELSIF awc_rec.clm_ins_status IS NOT NULL  and nvl(awc_rec.Override_Yn,'N')='N' AND awc_rec.clm_ins_status!='REQ' AND nvl(v_clm_status_gen_type_id,awc_rec.clm_status)!=awc_rec.clm_ins_status THEN
                Raise_application_error(-20865,'Overriding Insurance Company Descision is Not Allowed');

            ELSIF awc_rec.clm_ins_status ='APR' AND nvl(v_clm_status_gen_type_id,'NA')!='APR' AND  v_flag ='S' THEN
                Raise_application_error(-20865,'Overriding Insurance Company Descision is Not Allowed');

          END IF;

        ELSIF   (case when pat_rec.claim_general_type_id = 'CNH' then relt_cur.ins_clm_cl_rej_allow_yn else relt_cur.ins_clm_cm_rej_allow_yn end ) ='Y' and awc_rec.clm_status IN ('REJ')  THEN

        if v_flag!='O' AND pat_rec.completed_yn='Y' THEN
         RAISE_APPLICATION_ERROR(-20107,' You cannot modify  this Pre-Auth/claim , Reviews are Completed');
        END IF;

          IF ((awc_rec.clm_ins_status IS NULL or awc_rec.clm_ins_status ='REQ') AND NVL(v_clm_status_gen_type_id,'NA')!='REQ') AND v_flag ='R'  THEN
              Raise_application_error(-20866,'The claims requires insurance decision please intimate claim');
          END IF;

          IF  awc_rec.clm_ins_status ='INP' THEN
             Raise_application_error(-20863,'No Modifications Are Allowed, Claim Needs Insurance company Response');
          END IF;

          IF  awc_rec.clm_ins_status ='REJ' AND NVL(v_clm_status_gen_type_id,'NA')!='REJ' AND  v_flag ='S'   THEN
             Raise_application_error(-20865,'Overriding Insurance Company Descision is Not Allowed');
          END IF;

          IF awc_rec.clm_ins_status IS NOT NULL  and nvl(awc_rec.Override_Yn,'N')='N' AND awc_rec.clm_ins_status!='REQ' AND nvl(v_clm_status_gen_type_id,awc_rec.clm_status)!=awc_rec.clm_ins_status THEN
                Raise_application_error(-20865,'Overriding Insurance Company Descision is Not Allowed');
          END IF;

        END IF;
    END IF;

    v_awc_yn  :='N';

    END IF;

 ELSIF NVL(awc_rec.ins_intimation_req_yn,'N')='Y' 
      AND  (case when pat_rec.claim_general_type_id = 'CNH' then relt_cur.ins_clm_cl_apr_rej_yn else relt_cur.ins_clm_cm_apr_rej_yn end ) = 'Y' 
      AND ((case when pat_rec.claim_general_type_id = 'CNH' then relt_cur.Ins_Clm_Cl_Allow_Yn else relt_cur.Ins_Clm_Cm_Allow_Yn end )  = 'Y' 
      or (case when pat_rec.claim_general_type_id = 'CNH' then relt_cur.ins_clm_cl_rej_allow_yn else relt_cur.ins_clm_cm_rej_allow_yn end ) ='Y') 
      AND v_flag='O' THEN

	UPDATE clm_ins_intimation_details g SET
                   G.OVERRIDE_YN='N',
                   g.ins_intimation_req_yn='N',
                   G.UPDATED_BY=V_ADDED_BY,
                   G.UPDATED_DATE=SYSDATE
    WHERE G.CLAIM_SEQ_ID=v_claim_seq_id;


 END IF;

END claims_freeze;
 ---========================================================================================
PROCEDURE clm_ins_intimate(v_claim_seq_id                  IN clm_general_details.claim_seq_id%TYPE,
                            v_clm_status_general_type_id    IN clm_enroll_details.clm_status_general_type_id%TYPE,
                            v_max_app_amount                IN clm_general_details.total_app_amount%TYPE,
                            v_flag                          IN VARCHAR2,
                            v_added_by                      in number )
                         IS

    CURSOR cur_relation (v_prod_policy_seq_id VARCHAR2) IS
    SELECT tps.copay_yn,tps.copay_approved_amt,tps.copay_fixed_amt,tps.copay_perc,
           tps.si_restrict_yn,tps.si_relation,tps.si_restrict_amt,tps.si_restrict_perc,tps.si_type,
           tps.rest_age,tps.rest_age_amt,tps.Ins_Clm_Allow_Yn,tps.Ins_Clm_Operator,tps.Ins_Clm_Apr_Limit ,TPS.INS_REJ_ALLOW_YN,TPS.INS_CLM_APR_REJ_YN,
--preauth
          ins_pat_apr_rej_yn,ins_pat_allow_yn,ins_pat_operator,ins_pat_apr_limit,
          ins_pat_rej_allow_yn,pat_mail_flag,pat_mail_freq_hours,pat_mail_freq_mins,
--cash less claims                  
          ins_clm_cl_apr_rej_yn,ins_clm_cl_allow_yn,ins_clm_cl_operator,ins_clm_cl_apr_limit,
          ins_clm_cl_rej_allow_yn,clm_cl_mail_flag,
--member claim
          ins_clm_cm_apr_rej_yn,ins_clm_cm_allow_yn,ins_clm_cm_operator,ins_clm_cm_apr_limit,
          ins_clm_cm_rej_allow_yn,clm_cm_mail_flag,clm_mail_freq_hours,clm_mail_freq_mins
     FROM  Tpa_ins_prod_policy tps
     WHERE tps.prod_policy_seq_id = v_prod_policy_seq_id;

   CURSOR cur_pol IS
     SELECT PE.CLM_STATUS_GENERAL_TYPE_ID,pe.policy_number,pe.policy_seq_id,pe.enrol_type_id,pg.requested_amount as  total_app_amount,cii.clm_ins_status,pg.completed_yn,CII.ins_intimation_req_yn,
     c.CLAIM_GENERAL_TYPE_ID
     FROM clm_enroll_details pe
     JOIN clm_general_details pg ON (pe.claim_seq_id=pg.claim_seq_id)
     JOIN clm_inward C ON (pg.claims_inward_seq_id = c.claims_inward_seq_id )
     left outer join app.clm_ins_intimation_details cii on (pg.claim_seq_id=cii.claim_seq_id)
     WHERE pg.claim_seq_id = v_claim_seq_id;

   pat_rec          cur_pol%ROWTYPE;
   relt_cur         cur_relation%ROWTYPE;


   v_prod_policy_seq_id        tpa_ins_prod_policy.prod_policy_seq_id%TYPE;
   v_result_set                SYS_REFCURSOR;



 BEGIN

    OPEN cur_pol;
    FETCH cur_pol INTO pat_rec;
    CLOSE cur_pol;
/*insert into app.temp_rem values(v_claim_seq_id ||','||
                            v_clm_status_general_type_id ||','||
                            v_max_app_amount||','||
                            v_flag||','||v_added_by);*/
IF pat_rec.Completed_Yn='Y' THEN
    RAISE_APPLICATION_ERROR(-20107,'You cannot perform this action for completed Preauth/Claim');
END IF;

 IF pat_rec.clm_status_general_type_id NOT IN ('APR','REJ') THEN
     RAISE_APPLICATION_ERROR(-20867,'Claims/Preauth cannot be intimated with current status, claim should be approved or rejected') ;
 END IF;  --modified.


 IF pat_rec.enrol_type_id='COR' THEN
    OPEN v_result_set FOR
       'SELECT gt.prod_policy_seq_id
        FROM tpa_enr_policy GH
        LEFT OUTER JOIN tpa_ins_prod_policy GT ON (GH.policy_seq_id=GT.policy_seq_id)
        LEFT OUTER JOIN tpa_ins_prod_policy_rules GM ON (GT.prod_policy_seq_id=GM.prod_policy_seq_id)
     WHERE GH.policy_seq_id=:v_policy_seq_id' USING pat_rec.policy_seq_id;

     FETCH v_result_set INTO v_prod_policy_seq_id;
     CLOSE v_result_set;
 ELSE
     OPEN v_result_set FOR
    'SELECT tipp.prod_policy_seq_id
     FROM tpa_enr_policy tep
     LEFT OUTER JOIN tpa_ins_product tip on (tip.product_seq_id=tep.product_seq_id)
     LEFT OUTER JOIN tpa_ins_prod_policy tipp on (tipp.product_seq_id=tip.product_seq_id)
     WHERE tep.policy_seq_id=:v_policy_seq_id'  USING pat_rec.policy_seq_id;

     FETCH v_result_set into v_prod_policy_seq_id;
     CLOSE v_result_set;

   END IF;

       OPEN  cur_relation (v_prod_policy_seq_id);
       FETCH cur_relation INTO relt_cur;
       CLOSE cur_relation;

  IF  NVL(pat_rec.ins_intimation_req_yn,'N')!='Y' 
    AND  ( relt_cur.ins_clm_cl_apr_rej_yn='Y' OR relt_cur.ins_clm_cm_apr_rej_yn='Y' ) 
    AND ( relt_cur.ins_clm_cl_allow_yn='Y' OR relt_cur.ins_clm_cm_allow_yn='Y'
     OR  relt_cur.ins_clm_cl_rej_allow_yn='Y' OR relt_cur.ins_clm_cm_rej_allow_yn='Y' ) THEN --KOCBJJ

     if pat_rec.clm_ins_status='INP' THEN
        RAISE_APPLICATION_ERROR(-20953,'Preauth/Claim Already intimated to Insurance Company.') ;
     ELSIF pat_rec.clm_ins_status IN ('APR','REJ') THEN
         RAISE_APPLICATION_ERROR(-20952,'Insurance company Already responded for this Preauth/Claim') ;
     END IF;
     
     if relt_cur.ins_clm_cl_apr_rej_yn='Y' and pat_rec.claim_general_type_id='CNH' then --for cash_less

       if relt_cur.ins_clm_cl_allow_yn='Y' AND pat_rec.clm_status_general_type_id ='APR' then 
         
        IF relt_cur.ins_clm_cl_operator='GT' THEN
           IF  pat_rec.total_app_amount>=relt_cur.ins_clm_cl_apr_limit  THEN  -----KOCBJJ
              claims_freeze(v_claim_seq_id,pat_rec.clm_status_general_type_id,'M',v_added_by);
           END IF;
        ELSIF relt_cur.ins_clm_cl_operator='LT' THEN
           IF pat_rec.total_app_amount<=relt_cur.ins_clm_cl_apr_limit  THEN  -----KOCBJJ
               claims_freeze(v_claim_seq_id,pat_rec.clm_status_general_type_id,'M',v_added_by);
           END IF;
        ELSIF relt_cur.ins_clm_cl_operator='EQ' THEN
           IF  pat_rec.total_app_amount=relt_cur.ins_clm_cl_apr_limit  THEN  -----KOCBJJ
               claims_freeze(v_claim_seq_id,pat_rec.clm_status_general_type_id,'M',v_added_by);
           END IF;
        END IF;            
         
         elsif relt_cur.ins_clm_cl_rej_allow_yn='Y' then

            claims_freeze(v_claim_seq_id,pat_rec.clm_status_general_type_id,'M',v_added_by);
         end if;      

      IF relt_cur.clm_cl_mail_flag ='MAIL'  THEN
           generate_mail_pkg.proc_generate_mail('CLM_INS_INTIMATION',v_claim_seq_id,v_prod_policy_seq_id,v_added_by);
      ELSIF  relt_cur.clm_cl_mail_flag ='ADOBE' THEN
            generate_mail_pkg.proc_generate_mail('CLM_INS_XFDF_PICKUP',v_claim_seq_id,v_prod_policy_seq_id,v_added_by);
      END IF;


     elsif relt_cur.ins_clm_cm_apr_rej_yn='Y' and pat_rec.claim_general_type_id='CTM' then --for member

    if relt_cur.ins_clm_cm_allow_yn='Y' AND pat_rec.clm_status_general_type_id ='APR' then 
     
        IF relt_cur.ins_clm_cm_operator='GT' THEN
           IF  pat_rec.total_app_amount>=relt_cur.ins_clm_cm_apr_limit  THEN  -----KOCBJJ
              claims_freeze(v_claim_seq_id,pat_rec.clm_status_general_type_id,'M',v_added_by);
           END IF;
        ELSIF relt_cur.ins_clm_cm_operator='LT' THEN
           IF pat_rec.total_app_amount<=relt_cur.ins_clm_cm_apr_limit  THEN  -----KOCBJJ
               claims_freeze(v_claim_seq_id,pat_rec.clm_status_general_type_id,'M',v_added_by);
           END IF;
        ELSIF relt_cur.ins_clm_cm_operator='EQ' THEN
           IF  pat_rec.total_app_amount=relt_cur.ins_clm_cm_apr_limit  THEN  -----KOCBJJ
               claims_freeze(v_claim_seq_id,pat_rec.clm_status_general_type_id,'M',v_added_by);
           END IF;
        END IF;


         elsif relt_cur.ins_clm_cm_rej_allow_yn='Y' then
         
          claims_freeze(v_claim_seq_id,pat_rec.clm_status_general_type_id,'M',v_added_by);

         end if;

      IF relt_cur.clm_cm_mail_flag ='MAIL'  THEN
           generate_mail_pkg.proc_generate_mail('CLM_INS_INTIMATION',v_claim_seq_id,v_prod_policy_seq_id,v_added_by);
      ELSIF  relt_cur.clm_cm_mail_flag ='ADOBE' THEN
           generate_mail_pkg.proc_generate_mail('CLM_INS_XFDF_PICKUP',v_claim_seq_id,v_prod_policy_seq_id,v_added_by);
      END IF;
         
     end if;
 
 end if;

   COMMIT;
 END clm_ins_intimate;
 ---========================================================================================
PROCEDURE claims_freeze_set_review (
          v_claim_seq_id                   IN clm_enroll_details.claim_seq_id%TYPE)
   AS

 v_awc_yn                         VARCHAR2(10);

  CURSOR cur_awc IS
  SELECT /*+ index(cg idxp_clm_general_details)
             index(ce idx_clmgen_clmnum)
             index(tii idxp_tpa_ins_info) */
       cg.claim_number,
       cg.claim_sub_general_type_id,
       ce.ins_seq_id,
       ce.claimant_name,
       ce.clm_status_general_type_id AS clm_status,
       cii.clm_ins_status,
       cii.clm_ins_remarks,
       tii.abbrevation_code,
       cg.updated_by,
       cg.total_app_amount
  FROM clm_general_details cg
  JOIN clm_enroll_details ce ON (cg.claim_seq_id=ce.claim_seq_id)
  left outer join app.clm_ins_intimation_details cii on (ce.claim_seq_id=cii.claim_seq_id)
  JOIN tpa_ins_info tii      ON (tii.ins_seq_id=ce.ins_seq_id)
  WHERE cg.claim_seq_id=v_claim_seq_id;

 awc_rec                    cur_awc%ROWTYPE;
 v_dest_msg_seq_id          destination_message.dest_msg_seq_id%TYPE;

  CURSOR cur_relation (v_prod_policy_seq_id VARCHAR2) IS
    SELECT tps.copay_yn,tps.copay_approved_amt,tps.copay_fixed_amt,tps.copay_perc,
           tps.si_restrict_yn,tps.si_relation,tps.si_restrict_amt,tps.si_restrict_perc,tps.si_type,
           tps.rest_age,tps.rest_age_amt,
           tps.ins_pat_allow_yn,tps.ins_pat_operator,tps.ins_pat_apr_limit --KOCBJJ
     FROM  Tpa_ins_prod_policy tps
     WHERE tps.prod_policy_seq_id=v_prod_policy_seq_id;

   CURSOR cur_pol IS
     SELECT pe.policy_number,pe.policy_seq_id,pe.enrol_type_id
     FROM clm_enroll_details pe
     JOIN clm_general_details pg ON (pe.claim_seq_id=pg.claim_seq_id)
     WHERE pg.claim_seq_id=v_claim_seq_id;

   pat_rec          cur_pol%ROWTYPE;
   relt_cur         cur_relation%ROWTYPE;


   v_prod_policy_seq_id        tpa_ins_prod_policy.prod_policy_seq_id%TYPE;
   v_result_set                SYS_REFCURSOR;

 BEGIN

    OPEN cur_pol;
    FETCH cur_pol INTO pat_rec;
    CLOSE cur_pol;


 IF pat_rec.enrol_type_id='COR' THEN
    OPEN v_result_set FOR
       'SELECT gt.prod_policy_seq_id
        FROM tpa_enr_policy GH
        LEFT OUTER JOIN tpa_ins_prod_policy GT ON (GH.policy_seq_id=GT.policy_seq_id)
        LEFT OUTER JOIN tpa_ins_prod_policy_rules GM ON (GT.prod_policy_seq_id=GM.prod_policy_seq_id)
     WHERE GH.policy_seq_id=:v_policy_seq_id' USING pat_rec.policy_seq_id;

     FETCH v_result_set INTO v_prod_policy_seq_id;
     CLOSE v_result_set;
 ELSE
     OPEN v_result_set FOR
    'SELECT tipp.prod_policy_seq_id
     FROM tpa_enr_policy tep
     LEFT OUTER JOIN tpa_ins_product tip on (tip.product_seq_id=tep.product_seq_id)
     LEFT OUTER JOIN tpa_ins_prod_policy tipp on (tipp.product_seq_id=tip.product_seq_id)
     WHERE tep.policy_seq_id=:v_policy_seq_id'  USING pat_rec.policy_seq_id;

     FETCH v_result_set into v_prod_policy_seq_id;
     CLOSE v_result_set;
   END IF;

      OPEN  cur_relation (v_prod_policy_seq_id);
       FETCH cur_relation INTO relt_cur;
       CLOSE cur_relation;

     OPEN cur_awc;
     FETCH cur_awc INTO awc_rec;
     CLOSE cur_awc;
IF awc_rec.clm_status IN ('APR') AND awc_rec.clm_ins_status IS NULL THEN
         IF relt_cur.ins_pat_operator='GT' AND awc_rec.total_app_amount>=relt_cur.ins_pat_apr_limit  THEN  -----KOCBJJ
            Raise_application_error(-20060,'No Modifications Are Allowed,Claims is Under Insurance Limit');
        ELSIF  relt_cur.ins_pat_operator='LT' AND awc_rec.total_app_amount<=relt_cur.ins_pat_apr_limit  THEN  -----KOCBJJ
            Raise_application_error(-20061,'No Modifications Are Allowed,Claims is Under Insurance Limit');
        ELSIF  relt_cur.ins_pat_operator='EQ' AND awc_rec.total_app_amount=relt_cur.ins_pat_apr_limit  THEN  -----KOCBJJ
            Raise_application_error(-20062,'No Modifications Are Allowed,Claims is Under Insurance Limit');
        END IF;
     END IF;

     IF awc_rec.clm_status IN ('REJ') AND awc_rec.clm_ins_status IS NULL THEN
        Raise_application_error(-20059,'No Modifications Are Allowed, Rejected Claims must Intimated to Insurance company');
     END IF;

  END claims_freeze_set_review;
 ---========================================================================================

--koc1273
procedure critical_benefit_check(v_claim_seq_id      IN ASSIGN_USERS.claim_seq_id%TYPE,
                                                   v_product_seq_id    in tpa_enr_policy.product_seq_id%type,
                                                   v_policy_seq_id     in tpa_enr_policy.policy_seq_id%type,
                                                   v_enrol_type_id     in tpa_enr_policy.enrol_type_id%type,
                                                   v_Mem_Age           in tpa_enr_policy_member.mem_age%type,
                                                   v_tpa_enrollment_id in tpa_enr_policy_member.tpa_enrollment_id%type,
                                                   v_diagnosis_dt      in ailment_details.diagnosis_dt%type,
                                                   v_certificate_dt    in ailment_details.date_of_certificate%type,
                                                   v_date_of_inception in tpa_enr_policy_member.date_of_inception%type,
                                                   v_member_seq_id     in tpa_enr_policy_member.member_seq_id%type,
                                                   v_claim_sub_general_type_id in clm_general_details.claim_sub_general_type_id%type)
is

v_cnt number(2):=0;
v_icd number(2):=0;
v_pcs  number(2):=0;
v_mem_cnt number(2):=0;
v_mem_tot number(2):=0;
v_icd_pcs_tot number(2):=0;

    cursor cb_cur is
      select CB.CRITICAL_ILLNESS_CONFIG_SEQ_ID,
             nvl(CB.AMOUNT,0) AMOUNT,
             nvl(CB.NO_OF_TIMES,0) NO_OF_TIMES,
             cb.critical_grp,nvl(cb.surv_prd,0) surv_prd,nvl(cb.waiting_period,0) waiting_period
             from app.critical_illness_config cb
       where ((cb.product_seq_id = v_product_seq_id and v_enrol_type_id <> 'COR') OR
             (cb.policy_seq_id = v_policy_seq_id and v_enrol_type_id = 'COR'))
         and v_Mem_Age between cb.frm_age and cb.To_Age;

    cb_rec cb_cur%ROWTYPE;



cursor prod_info_cur is
select case when v_enrol_type_id='COR' then nvl(pol.survival_prd,'N')
else nvl(prd.survival_prd,'N') end as survival_prd_yn
  from tpa_ins_product prd
join tpa_enr_policy pol on (pol.product_seq_id=prd.product_seq_id)
join clm_enroll_details en on (en.policy_seq_id=pol.policy_seq_id)
where  en.claim_seq_id = v_claim_seq_id;

prod_info_rec   prod_info_cur%rowtype;

begin

  OPEN cb_cur;
  FETCH cb_cur INTO cb_rec;
  v_cnt:=cb_cur%rowcount;
  CLOSE cb_cur;

  for rec in (SELECT nvl(b.critical_cash_benefit_yn,'N') critical_cash_benefit_yn
 FROM tpa_enr_policy_member a JOIN tpa_enr_policy_group b ON (a.policy_group_seq_id = b.policy_group_seq_id)
 WHERE a.member_seq_id = v_member_seq_id)
 loop

if v_claim_sub_general_type_id = 'CTL' and rec.critical_cash_benefit_yn='N' then
raise_application_error(-20894,'Cannot process claim, employee has not opted for critical benefit');
end if;

end loop;

if v_diagnosis_dt is null  then
raise_application_error(-20895,'Cannot Process a calim inside the waiting period of the policy');
end if;

if (v_diagnosis_dt - v_date_of_inception +1) <= cb_rec.waiting_period then
raise_application_error(-20895,'Cannot Process a calim inside the waiting period of the policy');
end if;

if v_cnt != 1 then
raise_application_error(-20890,'Cannot Approve the claim since critical benefit is not declared for this age, please Reject the claim');
end if;


   for rec1 in ( select pat.proc_seq_id from pat_package_procedures pat,icd_pcs_detail D
    where pat.icd_pcs_seq_id=d.icd_pcs_seq_id and d.claim_seq_id = v_claim_seq_id )
   loop

        select count(cp.proc_seq_id) into v_pcs
          from app.tpa_critical_procedure cp where cp.critical_group_id = cb_rec.critical_grp
           and cp.proc_seq_id = rec1.proc_seq_id;

        v_icd_pcs_tot := v_icd_pcs_tot + v_pcs;

   end loop;

for rec2 in (SELECT D.icd_code,D.Ped_Code_Id,P.Ped_Description,D.Icd_Pcs_Seq_Id
        FROM icd_pcs_detail D,tpa_ped_code P
        WHERE D.Icd_Code=P.Icd_Code AND D.Ped_Code_Id=P.Ped_Code_Id
        AND D.claim_seq_id = v_claim_seq_id)
loop

select count(cp.icd_seq_id) into v_icd
from app.tpa_critical_procedure cp
where cp.critical_group_id = cb_rec.critical_grp
and cp.icd_seq_id=rec2.ped_code_id;

v_icd_pcs_tot := v_icd_pcs_tot + v_icd;

end loop;

if v_icd_pcs_tot = 0 then
raise_application_error(-20891,'Ailment does not belong to critical illness group selected, please Reject the claim');
end if;


for rec in ( select gr.policy_seq_id,gr.policy_number,gr.prev_policy_seq_id from tpa_enr_policy gr
start with gr.policy_seq_id = (select min(gr.policy_seq_id)
from tpa_enr_policy gr start with gr.policy_seq_id = v_policy_seq_id
connect by PRIOR gr.prev_policy_seq_id = gr.policy_seq_id)
connect by PRIOR gr.policy_seq_id = gr.prev_policy_seq_id )
loop

select count(1) into v_mem_cnt from clm_enroll_details en
      join clm_general_details ge on (en.claim_seq_id=ge.claim_seq_id)
       where en.tpa_enrollment_id = v_tpa_enrollment_id
and en.policy_seq_id = rec.policy_seq_id and ge.claim_sub_general_type_id='CTL' and en.clm_status_general_type_id='APR';

v_mem_tot := v_mem_tot + v_mem_cnt;

end loop;

if (cb_rec.no_of_times - v_mem_tot) <= 0 then
raise_application_error(-20892,'User has Exceeded Maximum no of times in caliming critical benefit, Please Reject the claim');
end if;

  OPEN  prod_info_cur;
  FETCH prod_info_cur INTO prod_info_rec;
  CLOSE prod_info_cur;


if v_certificate_dt is null and  prod_info_rec.survival_prd_yn='Y' then
raise_application_error(-20893,'Cannot process the Critical Calim within survival for the member');
end if;

if ((v_certificate_dt - v_diagnosis_dt+1) <= cb_rec.surv_prd) and prod_info_rec.survival_prd_yn='Y' then
raise_application_error(-20893,'Cannot process the Critical Calim within survival for the member');
end if;


end critical_benefit_check;
--koc1273
--===============================================================================
procedure close_claim(v_shortfal_email_seq_id in app.shortfall_email_dtl.shortfal_email_seq_id%type)
  is

cursor clm_cur is
select D.assigned_to_user,b.event_seq_id,a.claim_seq_id,b.last_assign_user_seq_id,b.claim_settlement_number,b.updated_by
from shortfall_email_dtl a
join clm_general_details b on (a.claim_seq_id=b.claim_seq_id)
join clm_enroll_details c on (b.claim_seq_id=c.claim_seq_id)
LEFT OUTER JOIN assign_users D ON ( B.last_assign_user_seq_id = D.assign_users_seq_id )
where a.shortfal_email_seq_id=v_shortfal_email_seq_id;

v_claim_seq_id clm_general_details.claim_seq_id%type;
v_rows_processed number;

clm_rec clm_cur%rowtype;
v_claim_settlement_number             CLM_GENERAL_DETAILS.claim_settlement_number%TYPE;
v_max_app_amount                      ASSIGN_USERS.total_app_amount%TYPE;
v_discount_amount                     clm_general_details.discount_amount%TYPE;
v_co_payment_amount                   clm_general_details.co_payment_amount%TYPE;
v_deposit_amount                      clm_general_details.deposit_amount%TYPE;
v_co_pay_buff_amount                  clm_general_details.co_payment_buffer_amount%TYPE;

v_event_seq_id                     CLM_GENERAL_DETAILS.event_seq_id%TYPE;
v_review_count                     CLM_GENERAL_DETAILS.review_count%TYPE;
v_required_review_count            CLM_GENERAL_DETAILS.required_review_count%TYPE;
v_event_name                       VARCHAR2(20);
v_review                           VARCHAR2(20);
v_coding_review_yn                 VARCHAR2(20);
v_show_coding_override             VARCHAR2(20);
v_mode                              VARCHAR2(5):='CLM'; -- Put it to 'CLM'
v_type                             CHAR;
V_ADDED_BY                         NUMBER(20);

begin

open clm_cur;
fetch clm_cur into clm_rec;
close clm_cur;

V_ADDED_BY:=clm_rec.assigned_to_user;

update clm_general_details a set a.completed_yn='Y',
A.REQUIRED_REVIEW_COUNT=0,A.REVIEW_COUNT=0,
a.event_seq_id=20,
A.UPDATED_BY=V_ADDED_BY,A.UPDATED_DATE=SYSDATE
WHERE A.CLAIM_SEQ_ID=CLM_REC.CLAIM_SEQ_ID;

UPDATE CLM_ENROLL_DETAILS B SET B.CLM_STATUS_GENERAL_TYPE_ID='PCO',
B.RSON_GENERAL_TYPE_ID='PA2',
B.UPDATED_BY=V_ADDED_BY,B.UPDATED_DATE=SYSDATE
WHERE B.CLAIM_SEQ_ID=CLM_REC.CLAIM_SEQ_ID;

UPDATE ASSIGN_USERS C SET C.REMARKS='Claim closure letter sent and  closed by Schedular.',
C.ASSIGNED_TO_USER=V_ADDED_BY,C.RSON_GENERAL_TYPE_ID='PA1',
C.COMPLETED_DATE=SYSDATE,C.UPDATED_BY=V_ADDED_BY,C.UPDATED_DATE=SYSDATE,
C.PAT_STATUS_GENERAL_TYPE_ID='PCO'
WHERE C.CLAIM_SEQ_ID=CLM_REC.CLAIM_SEQ_ID;

end close_claim;

--COMMIT;
/*save_settlement( clm_rec.assigned_to_user,
                 clm_rec.claim_seq_id,
                 null,
                 'Claim closure letter sent and  closed by Schedular.',
                 clm_rec.claim_settlement_number,
                 'PCO',
                 NULL,
                 NULL,
                 v_max_app_amount ,
                 clm_rec.assigned_to_user,
                 'RNC',
                 v_discount_amount ,
                 v_co_payment_amount ,
                 v_deposit_amount ,
                 NULL,
                 NULL,
                 v_co_pay_buff_amount,
                 NULL,
                 NULL,
                 NULL,
                 v_rows_processed);

COMMIT;
FOR I IN CLM_REC.EVENT_SEQ_ID..20 LOOP
claims_pkg.set_review(clm_rec.claim_seq_id,
                                 v_event_seq_id ,
                                 v_review_count ,
                                 v_required_review_count,
                                 v_mode,
                                 v_type,
                                 V_ADDED_BY,
                                 v_event_name ,
                                 v_review ,
                                 v_coding_review_yn ,
                                 v_show_coding_override );

END LOOP;
*/


--=======================================================================
FUNCTION get_buff_type_amt(v_claim_seq_id               IN clm_general_details.claim_seq_id%type,
                           v_mode                       IN CHAR ) 
  RETURN SYS_REFCURSOR
IS

v_result_set           sys_refcursor;
BEGIN

IF v_mode = 'CLM' THEN 
  OPEN v_result_set for 
  
 select * from (SELECT  CASE WHEN d.claim_type='NRML' AND  d.buffer_type='CORB'
       THEN 'CORP_BUFF' 
   WHEN d.claim_type='NRML' AND  d.buffer_type='MEDB'
        THEN 'MED_BUFF' 
   WHEN d.claim_type='CRTL' AND  d.buffer_type='CRTB'
        THEN 'CRIT_BUFF' 
   WHEN d.claim_type='CRTL' AND  d.buffer_type='CORB'
        THEN 'CRIT_CORP_BUFF' 
   WHEN d.claim_type='CRTL' AND  d.buffer_type='MEDB'
        THEN 'CRIT_MED_BUFF'  END AS BUFF_TYPE,
        nvl(d.buffer_app_amount,0) as apr_amt
          FROM clm_general_details A
          LEFT OUTER JOIN buffer_details D
            ON (a.claim_seq_id = d.claim_seq_id)
          LEFT OUTER JOIN buffer_header f
            ON (d.buffer_hdr_seq_id = f.buffer_hdr_seq_id)     
         WHERE a.claim_seq_id = v_claim_seq_id
           AND (D.BUFFER_STATUS_GENERAL_TYPE_ID) = 'BAP'
           
           
union all
SELECT CASE WHEN d.claim_type='NRML' AND  d.buffer_type='CORB'
       THEN 'CORP_BUFF' 
   WHEN d.claim_type='NRML' AND  d.buffer_type='MEDB'
        THEN 'MED_BUFF' 
   WHEN d.claim_type='CRTL' AND  d.buffer_type='CRTB'
        THEN 'CRIT_BUFF' 
   WHEN d.claim_type='CRTL' AND  d.buffer_type='CORB'
        THEN 'CRIT_CORP_BUFF' 
   WHEN d.claim_type='CRTL' AND  d.buffer_type='MEDB'
        THEN 'CRIT_MED_BUFF'  END AS BUFF_TYPE,
        nvl(d.buffer_app_amount,0) as apr_amt

          FROM clm_general_details A
     LEFT OUTER JOIN pat_general_details h
            ON (a.pat_enroll_detail_seq_id = h.pat_enroll_detail_seq_id)
          LEFT OUTER JOIN buffer_details d
            ON (H.Pat_Gen_Detail_Seq_Id = d.Pat_Gen_Detail_Seq_Id)
          LEFT OUTER JOIN buffer_header J
            ON (d.buffer_hdr_seq_id = J.buffer_hdr_seq_id)  
    WHERE a.claim_seq_id = v_claim_seq_id
           AND (d.BUFFER_STATUS_GENERAL_TYPE_ID) = 'BAP'                            
           AND NVL(h.pat_enhanced_yn, 'N') = 'N' 
           )
           pivot ( SUM(APR_AMT)
  FOR BUFF_TYPE IN ('CORP_BUFF' AS CORP_BUFF ,'MED_BUFF' AS MED_BUFF,'CRIT_BUFF' AS CRIT_BUFF, 'CRIT_CORP_BUFF' AS CRIT_CORP_BUFF, 'CRIT_MED_BUFF' AS CRIT_MED_BUFF) );

ELSIF v_mode='PAT' THEN

 OPEN v_result_set for 
  
 select * from (SELECT  CASE WHEN d.claim_type='NRML' AND  d.buffer_type='CORB'
       THEN 'CORP_BUFF' 
   WHEN d.claim_type='NRML' AND  d.buffer_type='MEDB'
        THEN 'MED_BUFF' 
   WHEN d.claim_type='CRTL' AND  d.buffer_type='CRTB'
        THEN 'CRIT_BUFF' 
   WHEN d.claim_type='CRTL' AND  d.buffer_type='CORB'
        THEN 'CRIT_CORP_BUFF' 
   WHEN d.claim_type='CRTL' AND  d.buffer_type='MEDB'
        THEN 'CRIT_MED_BUFF'  END AS BUFF_TYPE,
        nvl(d.buffer_app_amount,0) as apr_amt
  FROM clm_general_details A
  LEFT OUTER JOIN buffer_details D    ON (a.claim_seq_id = d.claim_seq_id)
  WHERE a.claim_seq_id = v_claim_seq_id  
   AND D.BUFFER_STATUS_GENERAL_TYPE_ID='BAP' 
     )
  pivot ( SUM(APR_AMT)
  FOR BUFF_TYPE IN ('CORP_BUFF' AS CORP_BUFF ,'MED_BUFF' AS MED_BUFF,'CRIT_BUFF' AS CRIT_BUFF, 'CRIT_CORP_BUFF' AS CRIT_CORP_BUFF, 'CRIT_MED_BUFF' AS CRIT_MED_BUFF) );

END IF;  
  RETURN v_result_set;

END  get_buff_type_amt;
--=======================================================================================
PROCEDURE check_buff_approved(v_claim_seq_id            IN clm_general_details.claim_seq_id%type,
                              v_balance_seq_id          IN tpa_enr_balance.balance_seq_id%type,
                              v_curr_util_buff_amt      IN clm_general_details.total_app_amount%type,
                              v_type                    IN CHAR,
                              v_added_by                IN NUMBER)
IS

CURSOR get_buff_amts_cur IS
SELECT  b.document_general_type_id,nvl(f.buffer_hdr_seq_id,j.buffer_hdr_seq_id) as buffer_hdr_seq_id,
  nvl(f.utilised_amount, j.utilised_amount) utilised_amount,
  nvl(f.utilised_med_amount, j.utilised_med_amount) utilised_med_amount,
  nvl(f.utilised_crit_amount, j.utilised_crit_amount) utilised_crit_amount,
  nvl(f.utilised_crit_corp_amount, j.utilised_crit_corp_amount) utilised_crit_corp_amount,
  nvl(f.utilised_crit_med_amount, j.utilised_crit_med_amount) utilised_crit_med_amount,
  a.utilised_buff_amt as curr_claim_buff_utilised,
  nvl(d.buffer_mode,i.buffer_mode) as buffer_type,
  nvl(f.adjust_remarks,j.adjust_remarks) as remarks,
  nvl(f.adjust_yn,j.adjust_yn) as adjust_yn,
  nvl(f.pre_auth_buffer_app_amount,j.pre_auth_buffer_app_amount) as preauth_amt,
  nvl(f.claim_app_buffer_amount,j.claim_app_buffer_amount) as claim_amt,
  nvl(f.buff_app_amt,j.buff_app_amt) as buff_app_amt,
  nvl(f.med_buff_app_amt,j.med_buff_app_amt) as med_buff_app_amt,
  nvl(f.crit_buff_app_amt,j.crit_buff_app_amt) as crit_buff_app_amt,
  nvl(f.crit_corp_buff_app_amt,j.crit_corp_buff_app_amt) as crit_corp_buff_app_amt,
  nvl(f.crit_med_buff_app_amt,j.crit_med_buff_app_amt) as crit_med_buff_app_amt,
  k.clm_status_general_type_id as clm_status,
  c.mem_buffer_seq_id,
  b.claim_general_type_id as claim_type,
  A.pat_enroll_detail_seq_id,
  o.buffer_alloc_general_type_id,
  m.policy_group_seq_id,
  k.member_seq_id
  

  FROM clm_general_details A
  JOIN clm_enroll_details k on (a.claim_seq_id=k.claim_seq_id)
  JOIN clm_inward b on (a.claims_inward_seq_id=b.claims_inward_seq_id)
  LEFT OUTER JOIN tpa_enr_mem_buffer c on (k.member_seq_id=c.member_seq_id)
  LEFT OUTER JOIN tpa_enr_policy_member n on (k.member_seq_id=n.member_seq_id)
  LEFT OUTER JOIN tpa_enr_policy_group m on (n.policy_group_seq_id=m.policy_group_seq_id)
  LEFT OUTER JOIN tpa_enr_policy o on (m.policy_seq_id=o.policy_seq_id)
  LEFT OUTER JOIN buffer_details D
    ON (a.claim_seq_id = d.claim_seq_id)
  LEFT OUTER JOIN buffer_header f
    ON (d.buffer_hdr_seq_id = f.buffer_hdr_seq_id)
  LEFT OUTER JOIN pat_general_details h
    ON (a.pat_enroll_detail_seq_id = h.pat_enroll_detail_seq_id)
  LEFT OUTER JOIN buffer_details I
    ON (H.Pat_Gen_Detail_Seq_Id = I.Pat_Gen_Detail_Seq_Id)
  LEFT OUTER JOIN buffer_header J
    ON (I.buffer_hdr_seq_id = J.buffer_hdr_seq_id)
 WHERE a.claim_seq_id = v_claim_seq_id
   AND NVL(h.pat_enhanced_yn, 'N') = 'N'
   AND ROWNUM=1;

buff_rec                      get_buff_amts_cur%rowtype;

v_utilised_amount             clm_general_details.total_app_amount%type;
v_utilised_med_amount         clm_general_details.total_app_amount%type;
v_utilised_crit_amount        clm_general_details.total_app_amount%type;
v_utilised_crit_corp_amount   clm_general_details.total_app_amount%type;
v_utilised_crit_med_amount    clm_general_details.total_app_amount%type;

v_unused_buff_amt             clm_general_details.total_app_amount%type;
v_unused_med_buff_amt         clm_general_details.total_app_amount%type;
v_unused_crit_buff_amt        clm_general_details.total_app_amount%type;
v_unused_crit_corp_buff_amt   clm_general_details.total_app_amount%type;
v_unused_crit_med_buff_amt    clm_general_details.total_app_amount%type;

v_clm_curr_util_buff_amt      clm_general_details.total_app_amount%type:=nvl(v_curr_util_buff_amt,0);
v_result_set                  sys_refcursor;
v_app_util_amt                clm_general_details.total_app_amount%type;

v_preauth_buff_amt            buffer_header.pre_auth_buffer_app_amount%type:=0;
v_preauth_amt            buffer_header.pre_auth_buffer_app_amount%type:=0;
v_claim_amt            buffer_header.pre_auth_buffer_app_amount%type:=0;
BEGIN

 OPEN  get_buff_amts_cur;
 FETCH get_buff_amts_cur INTO buff_rec;
 CLOSE get_buff_amts_cur;

IF v_type = 'DELETEBUFF' THEN
v_result_set:=get_buff_type_amt(v_claim_seq_id,'PAT');
ELSE 
  v_result_set:=get_buff_type_amt(v_claim_seq_id,'CLM');
END IF;
fetch v_result_set into buff_amts_rec;
close v_result_set;


IF  buff_rec.buffer_hdr_seq_id IS NOT NULL THEN

 IF v_type='FINPROMOTE'    THEN  
 
    IF buff_rec.claim_type = 'CNH' AND buff_rec.clm_status  IN ( 'REJ','PCO') THEN      
      SELECT D.Claim_App_Buffer_Amount INTO v_preauth_buff_amt  FROM pat_general_details a
      JOIN buffer_details c on (a.last_buffer_detail_seq_id = c.buff_detail_seq_id)
      JOIN buffer_header d on (c.buffer_hdr_seq_id=d.buffer_hdr_seq_id)
      where a.pat_enroll_detail_seq_id= buff_rec.pat_enroll_detail_seq_id
      and a.pat_enhanced_yn='N';
      
     IF v_preauth_buff_amt>0 THEN
        RAISE_APPLICATION_ERROR(-20135,'You cannot Complete the Rejected or Closed Claim,Until you delete Claim buffer records! .');
     END IF;  
        
    END IF;
    
  IF buff_rec.clm_status = 'APR'  OR (buff_rec.clm_status IN ( 'REJ','PCO') AND buff_rec.Claim_Type = 'CTM' )   THEN
    
    IF  buff_amts_rec.crit_buff_amt IS NOT NULL OR buff_amts_rec.Crit_Corp_Buff_Amt IS NOT NULL
      OR buff_amts_rec.Crit_Med_Buff_Amt IS NOT NULL THEN
      
       v_utilised_crit_amount:=case when v_clm_curr_util_buff_amt<=buff_amts_rec.crit_buff_amt then v_clm_curr_util_buff_amt
                                    when v_clm_curr_util_buff_amt>buff_amts_rec.crit_buff_amt then buff_amts_rec.crit_buff_amt end;

       v_utilised_crit_med_amount:=case when v_clm_curr_util_buff_amt-NVL(v_utilised_crit_amount,0)<=buff_amts_rec.crit_med_buff_amt then v_clm_curr_util_buff_amt-NVL(v_utilised_crit_amount,0)
                                    when v_clm_curr_util_buff_amt-NVL(v_utilised_crit_amount,0)>buff_amts_rec.crit_med_buff_amt then buff_amts_rec.crit_med_buff_amt end;
                                    

       v_utilised_crit_corp_amount:=case when v_clm_curr_util_buff_amt-NVL(v_utilised_crit_amount,0)-NVL(v_utilised_crit_med_amount,0)<=buff_amts_rec.crit_corp_buff_amt then v_clm_curr_util_buff_amt-NVL(v_utilised_crit_amount,0)-NVL(v_utilised_crit_med_amount,0)
                                    when v_clm_curr_util_buff_amt-NVL(v_utilised_crit_amount,0)+NVL(v_utilised_crit_med_amount,0)>buff_amts_rec.crit_corp_buff_amt then buff_amts_rec.crit_corp_buff_amt end;    
     
       v_unused_crit_buff_amt:= CASE WHEN buff_rec.adjust_yn='Y' THEN nvl(buff_rec.crit_buff_app_amt,0)-nvl(v_utilised_crit_amount,0) else  buff_amts_rec.crit_buff_amt-NVL(v_utilised_crit_amount,0) END ;
       v_unused_crit_med_buff_amt :=CASE WHEN buff_rec.adjust_yn='Y' THEN nvl(buff_rec.crit_med_buff_app_amt,0)-nvl(v_utilised_crit_med_amount,0) else  buff_amts_rec.crit_med_buff_amt -NVL(v_utilised_crit_med_amount,0) END;
       v_unused_crit_corp_buff_amt:=CASE WHEN buff_rec.adjust_yn='Y' THEN nvl(buff_rec.crit_corp_buff_app_amt,0)-nvl(v_utilised_crit_corp_amount,0) else  buff_amts_rec.crit_corp_buff_amt-NVL(v_utilised_crit_corp_amount,0) END;


    ELSIF buff_amts_rec.buff_amt IS NOT NULL OR buff_amts_rec.Med_Buff_Amt IS NOT NULL THEN

        v_utilised_amount:=case when v_clm_curr_util_buff_amt<=buff_amts_rec.buff_amt then v_clm_curr_util_buff_amt
                                    when v_clm_curr_util_buff_amt>buff_amts_rec.buff_amt then buff_amts_rec.buff_amt end;                                   

       v_utilised_med_amount:=case when v_clm_curr_util_buff_amt-NVL(v_utilised_amount,0)<=buff_amts_rec.med_buff_amt then v_clm_curr_util_buff_amt-NVL(v_utilised_amount,0)
                                    when v_clm_curr_util_buff_amt-NVL(v_utilised_amounT,0)>buff_amts_rec.med_buff_amt then buff_amts_rec.med_buff_amt end;
       
       v_unused_buff_amt:=CASE WHEN buff_rec.adjust_yn='Y' THEN nvl(buff_rec.buff_app_amt,0)-nvl(v_utilised_amount,0) else  buff_amts_rec.buff_amt-NVL(v_utilised_amount,0) END;                                    
       v_unused_med_buff_amt:=CASE WHEN buff_rec.adjust_yn='Y' THEN nvl(buff_rec.med_buff_app_amt,0)-nvl(v_utilised_med_amount,0) else  buff_amts_rec.med_buff_amt -NVL(v_utilised_med_amount,0) END;
     
     END IF;

     v_app_util_amt:=NVL(v_utilised_amount,0)+NVL(v_utilised_med_amount,0)+NVL(v_utilised_crit_amount,0)+NVL(v_utilised_crit_corp_amount,0)+NVL(v_utilised_crit_med_amount,0)   ;

     IF buff_rec.claim_amt > 0 then
          v_claim_amt:= CASE WHEN  buff_rec.claim_amt> v_app_util_amt THEN  buff_rec.claim_amt-v_app_util_amt ELSE 0 END;
          buff_rec.claim_amt:=CASE WHEN v_claim_amt =0 THEN v_app_util_amt -  buff_rec.claim_amt ELSE 0 END;
          IF buff_rec.claim_amt <= 0 THEN              
	              v_preauth_amt:= case when buff_rec.preauth_amt > 0 then  buff_rec.preauth_amt + buff_rec.claim_amt ELSE buff_rec.preauth_amt END;
          ELSIF  buff_rec.claim_amt > 0 THEN
             v_preauth_amt:=buff_rec.preauth_amt-buff_rec.claim_amt;
          END IF;
     ELSIF buff_rec.preauth_amt > 0 THEN
           v_preauth_amt:=buff_rec.preauth_amt-v_app_util_amt;
     END IF;

         UPDATE buffer_header a
         SET a.utilised_amount =  CASE WHEN  v_utilised_amount IS NOT NULL  THEN v_utilised_amount  ELSE a.utilised_amount END  ,
            a.Utilised_Med_Amount =  CASE WHEN  v_utilised_med_amount IS NOT NULL  THEN    v_utilised_med_amount ELSE a.Utilised_Med_Amount END  ,
            a.Utilised_Crit_Amount = CASE WHEN  v_utilised_crit_amount IS NOT NULL  THEN     v_utilised_crit_amount  ELSE a.Utilised_Crit_Amount END  ,
            a.Utilised_Crit_Corp_Amount =CASE WHEN  v_utilised_crit_corp_amount IS NOT NULL  THEN  v_utilised_crit_corp_amount  ELSE a.Utilised_Crit_CORP_Amount END  ,
            a.Utilised_Crit_Med_Amount = CASE WHEN  v_utilised_crit_med_amount IS NOT NULL  THEN  v_utilised_crit_med_amount   ELSE a.Utilised_Crit_Med_Amount END,
            a.pre_auth_buffer_app_amount=CASE WHEN pre_auth_buffer_app_amount>0 then  pre_auth_buffer_app_amount-v_preauth_amt else pre_auth_buffer_app_amount end,
            a.claim_app_buffer_amount=CASE WHEN claim_app_buffer_amount>0 THEN claim_app_buffer_amount-v_claim_amt ELSE claim_app_buffer_amount END,
            A.unused_buff_amt = v_unused_buff_amt,
            A.Unused_Med_Buff_Amt = v_unused_med_buff_amt,
            A.Unused_Crit_Buff_Amt = v_unused_crit_buff_amt,
            A.Unused_Crit_Corp_Buff_Amt = v_unused_crit_corp_buff_amt,
            A.Unused_Crit_Med_Buff_Amt = v_unused_crit_med_buff_amt,
            a.buff_app_amt =  v_utilised_amount ,
            a.med_buff_app_amt = v_utilised_med_amount ,
            a.crit_buff_app_amt = v_utilised_crit_amount ,
            a.crit_corp_buff_app_amt =  v_utilised_crit_corp_amount ,
            a.crit_med_buff_app_amt =  v_utilised_crit_med_amount,
            a.adjust_yn                = 'Y',
            A.UPDATED_BY= v_added_by,
            a.updated_date = sysdate,
            A.ADJUST_REMARKS = A.ADJUST_REMARKS||CHR(13)||case when nvl(a.utilised_amount,0)!=0  then ' Utilised Buff Amount : '||a.utilised_amount||' changed to :'||v_utilised_amount else null end
            ||case when nvl(a.utilised_med_amount,0)!=0 then '  Utilised Med Buff Amount : '||a.utilised_med_amount||' changed to :'||v_utilised_med_amount else null end
            ||case when nvl(a.utilised_crit_amount,0)!=0  then '  Utilised Crit Buff Amount : '||a.utilised_crit_amount||' changed to :'||v_utilised_crit_amount else null end
            ||case when nvl(a.utilised_crit_corp_amount,0)!=0  then '  Utilised Crit Corp Buff Amount : '||a.utilised_crit_corp_amount||' changed to :'||v_utilised_crit_corp_amount else null end
            ||case when nvl(a.utilised_crit_med_amount,0)!=0  then '  Utilised Crit Med Buff Amount : '||a.utilised_crit_med_amount||' changed to :'||v_utilised_crit_med_amount else null end
            ||case when nvl(a.buff_app_amt,0)!=0  then '  Apr Buff Amount : '||a.buff_app_amt||' changed to :'||v_utilised_amount else null end
            ||case when nvl(a.med_buff_app_amt,0)!=0  then '  Apr Med Buff Amount : '||a.med_buff_app_amt||' changed to :'||v_utilised_med_amount else null end
            ||case when nvl(a.crit_buff_app_amt,0)!=0  then '  Apr Crit Buff Amount : '||a.crit_buff_app_amt||' changed to :'||v_utilised_crit_amount else null end
            ||case when nvl(a.crit_corp_buff_app_amt,0)!=0  then '  Apr Crit Corp Buff Amount : '||a.crit_corp_buff_app_amt||' changed to :'||v_utilised_crit_corp_amount else null end
            ||case when nvl(a.crit_med_buff_app_amt,0)!=0  then '  Apr Crit Med Buff Amount : '||a.crit_med_buff_app_amt||' changed to :'||v_utilised_crit_med_amount else null end
            ||to_char(sysdate,'dd-mon-yyyy hh12:mi:ss am')
      WHERE A.Buffer_Hdr_Seq_Id=buff_rec.buffer_hdr_seq_id;
     
      IF buff_rec.mem_buffer_seq_id IS NOT NULL THEN
            UPDATE tpa_enr_mem_buffer a SET
              a.used_buff_amount = a.used_buff_amount - nvl(v_unused_buff_amt,0),
              a.Used_Med_Buff_Amt = a.Used_Med_Buff_Amt - nvl(v_unused_med_buff_amt,0),
              a.Used_Crit_Buff_Amt = a.Used_Crit_Buff_Amt - nvl(v_unused_crit_buff_amt,0),
              a.Used_Crit_Corp_Buff_Amt = a.Used_Crit_Corp_Buff_Amt - nvl(v_unused_crit_corp_buff_amt,0),
              a.Used_Crit_Med_Buff_Amt = a.Used_Crit_Med_Buff_Amt - nvl(v_unused_crit_med_buff_amt,0),         
              a.updated_by                   = v_added_by,
              a.updated_date                 = SYSDATE
              WHERE a.mem_buffer_seq_id = buff_rec.mem_buffer_seq_id ;
      END IF;
      
        
   IF buff_rec.Buffer_Alloc_General_Type_Id = 'BAF' THEN    
 
     update tpa_enr_balance b 
      set  b.utilised_buff_amount = CASE WHEN v_unused_buff_amt!=0 then b.utilised_buff_amount-v_unused_buff_amt else b.utilised_buff_amount end,
           b.utilised_med_buff_amount = CASE WHEN v_unused_med_buff_amt!=0 then b.utilised_med_buff_amount-v_unused_med_buff_amt else b.utilised_med_buff_amount end,
           b.utilised_crit_buff_amount = CASE WHEN v_unused_crit_buff_amt!=0 then b.utilised_crit_buff_amount-v_unused_crit_buff_amt else b.utilised_crit_buff_amount end,
           b.utilised_crit_corp_buff_amt = CASE WHEN v_unused_crit_corp_buff_amt!=0 then b.utilised_crit_corp_buff_amt-v_unused_crit_corp_buff_amt else b.utilised_crit_corp_buff_amt end,
           b.utilised_crit_med_buff_amt = CASE WHEN v_unused_crit_med_buff_amt!=0 then b.utilised_crit_med_buff_amt-v_unused_crit_med_buff_amt else b.utilised_crit_med_buff_amt end,
           b.UPDATED_BY= v_added_by,
           b.updated_date = sysdate
      where b.policy_group_seq_id=buff_rec.policy_group_seq_id;    
    ELSE
       update tpa_enr_balance b 
      set  b.utilised_buff_amount = CASE WHEN v_unused_buff_amt!=0 then b.utilised_buff_amount-v_unused_buff_amt else b.utilised_buff_amount end,
           b.utilised_med_buff_amount = CASE WHEN v_unused_med_buff_amt!=0 then b.utilised_med_buff_amount-v_unused_med_buff_amt else b.utilised_med_buff_amount end,
           b.utilised_crit_buff_amount = CASE WHEN v_unused_crit_buff_amt!=0 then b.utilised_crit_buff_amount-v_unused_crit_buff_amt else b.utilised_crit_buff_amount end,
           b.utilised_crit_corp_buff_amt = CASE WHEN v_unused_crit_corp_buff_amt!=0 then b.utilised_crit_corp_buff_amt-v_unused_crit_corp_buff_amt else b.utilised_crit_corp_buff_amt end,
           b.utilised_crit_med_buff_amt = CASE WHEN v_unused_crit_med_buff_amt!=0 then b.utilised_crit_med_buff_amt-v_unused_crit_med_buff_amt else b.utilised_crit_med_buff_amt end,
           b.UPDATED_BY= v_added_by,
           b.updated_date = sysdate
      where b.balance_seq_id=v_balance_seq_id;   
    END IF;  
   
   END IF;
   
 ELSIF v_type = 'DELETEBUFF' THEN       
   
  IF buff_rec.Buffer_Alloc_General_Type_Id = 'BAF' THEN    
    update tpa_enr_balance b 
      set  b.utilised_buff_amount         = b.utilised_buff_amount -  NVL(buff_amts_rec.buff_amt,0),
           b.utilised_med_buff_amount     = b.utilised_med_buff_amount -  NVL(buff_amts_rec.med_buff_amt,0),
           b.utilised_crit_buff_amount    = b.utilised_crit_buff_amount -  NVL(buff_amts_rec.crit_buff_amt,0),
           b.utilised_crit_corp_buff_amt =  b.utilised_crit_corp_buff_amt - NVL(buff_amts_rec.crit_corp_buff_amt,0),
           b.utilised_crit_med_buff_amt  =  b.utilised_crit_med_buff_amt -  NVL(buff_amts_rec.crit_med_buff_amt,0),
           b.UPDATED_BY= v_added_by,
           b.updated_date = sysdate
      where b.policy_group_seq_id=buff_rec.policy_group_seq_id ;
   else 
     update tpa_enr_balance b 
      set  b.utilised_buff_amount         = b.utilised_buff_amount -  NVL(buff_amts_rec.buff_amt,0),
           b.utilised_med_buff_amount     = b.utilised_med_buff_amount -  NVL(buff_amts_rec.med_buff_amt,0),
           b.utilised_crit_buff_amount    = b.utilised_crit_buff_amount -  NVL(buff_amts_rec.crit_buff_amt,0),
           b.utilised_crit_corp_buff_amt =  b.utilised_crit_corp_buff_amt - NVL(buff_amts_rec.crit_corp_buff_amt,0),
           b.utilised_crit_med_buff_amt  =  b.utilised_crit_med_buff_amt -  NVL(buff_amts_rec.crit_med_buff_amt,0),
           b.UPDATED_BY= v_added_by,
           b.updated_date = sysdate
      where b.balance_seq_id=v_balance_seq_id ;
   END IF;
    
    IF buff_rec.mem_buffer_seq_id IS NOT NULL THEN
            UPDATE tpa_enr_mem_buffer a SET
              a.used_buff_amount = a.used_buff_amount - nvl(buff_amts_rec.buff_amt,0),
              a.Used_Med_Buff_Amt = a.Used_Med_Buff_Amt - nvl(buff_amts_rec.med_buff_amt,0),
              a.Used_Crit_Buff_Amt = a.Used_Crit_Buff_Amt - nvl(buff_amts_rec.crit_buff_amt,0),
              a.Used_Crit_Corp_Buff_Amt = a.Used_Crit_Corp_Buff_Amt - nvl(buff_amts_rec.crit_corp_buff_amt,0),
              a.Used_Crit_Med_Buff_Amt = a.Used_Crit_Med_Buff_Amt - nvl(buff_amts_rec.crit_med_buff_amt,0),         
              a.updated_by                   = v_added_by,
              a.updated_date                 = SYSDATE
              WHERE a.mem_buffer_seq_id = buff_rec.mem_buffer_seq_id ;
      END IF;
  
  
 END IF;
END IF;
END check_buff_approved;

--===============================================================================
PROCEDURE claims_ins_error_check ( --KOCBJJ
          v_claim_seq_id                   IN clm_enroll_details.claim_seq_id%TYPE,
          v_clm_status_gen_type_id         IN clm_enroll_details.clm_status_general_type_id%TYPE,
          v_added_by                       IN NUMBER DEFAULT NULL)
   AS

 v_awc_yn                         VARCHAR2(10);

  CURSOR cur_awc IS
  SELECT
       cg.claim_number,
       cg.claim_sub_general_type_id,
       ce.ins_seq_id,
       ce.claimant_name,
       ce.clm_status_general_type_id AS clm_status,
       cii.clm_ins_status,
       cii.clm_ins_remarks,
       tii.abbrevation_code,
       cg.updated_by,
       cg.requested_amount as total_app_amount,
       cii.override_yn,
       cii.ins_intimation_req_yn
  FROM clm_general_details cg
  JOIN clm_enroll_details ce ON (cg.claim_seq_id=ce.claim_seq_id)
  left outer join app.clm_ins_intimation_details cii on (ce.claim_seq_id=cii.claim_seq_id)
  JOIN tpa_ins_info tii      ON (tii.ins_seq_id=ce.ins_seq_id)
  WHERE cg.claim_seq_id=v_claim_seq_id;
  
   awc_rec                    cur_awc%ROWTYPE;
 v_dest_msg_seq_id          destination_message.dest_msg_seq_id%TYPE;

  CURSOR cur_relation (v_prod_policy_seq_id VARCHAR2) IS
    SELECT tps.copay_yn,tps.copay_approved_amt,tps.copay_fixed_amt,tps.copay_perc,
           tps.si_restrict_yn,tps.si_relation,tps.si_restrict_amt,tps.si_restrict_perc,tps.si_type,
           tps.rest_age,tps.rest_age_amt,
           tps.Ins_Clm_Allow_Yn,tps.Ins_Clm_Operator,tps.Ins_Clm_Apr_Limit ,TPS.INS_REJ_ALLOW_YN,TPS.INS_CLM_APR_REJ_YN,
--new
           ins_clm_cl_rej_allow_yn,ins_clm_cm_rej_allow_yn,ins_clm_cl_apr_rej_yn,ins_clm_cm_apr_rej_yn,
           clm_cl_mail_flag,clm_cm_mail_flag,ins_clm_cl_allow_yn,ins_clm_cm_allow_yn,ins_clm_cl_operator,
           ins_clm_cm_operator,ins_clm_cl_apr_limit,ins_clm_cm_apr_limit,clm_mail_freq_hours,pat_mail_freq_hours,
           clm_mail_freq_mins,pat_mail_freq_mins
     FROM  Tpa_ins_prod_policy tps
     WHERE tps.prod_policy_seq_id=v_prod_policy_seq_id;

   CURSOR cur_pol IS
     SELECT pe.policy_number,pe.policy_seq_id,pe.enrol_type_id,PG.COMPLETED_YN,c.claim_general_type_id
     FROM clm_enroll_details pe
     JOIN clm_general_details pg ON (pe.claim_seq_id=pg.claim_seq_id)
     JOIN clm_inward C ON (pg.claims_inward_seq_id = c.claims_inward_seq_id )
     WHERE pg.claim_seq_id=v_claim_seq_id;

   pat_rec          cur_pol%ROWTYPE;
   relt_cur         cur_relation%ROWTYPE;


   v_prod_policy_seq_id        tpa_ins_prod_policy.prod_policy_seq_id%TYPE;
   v_result_set                SYS_REFCURSOR;
   v_count                     NUMBER(10);

 BEGIN
 

    OPEN cur_pol;
    FETCH cur_pol INTO pat_rec;
    CLOSE cur_pol;

 IF pat_rec.enrol_type_id='COR' THEN
    OPEN v_result_set FOR
       'SELECT gt.prod_policy_seq_id
        FROM tpa_enr_policy GH
        LEFT OUTER JOIN tpa_ins_prod_policy GT ON (GH.policy_seq_id=GT.policy_seq_id)
        LEFT OUTER JOIN tpa_ins_prod_policy_rules GM ON (GT.prod_policy_seq_id=GM.prod_policy_seq_id)
     WHERE GH.policy_seq_id=:v_policy_seq_id' USING pat_rec.policy_seq_id;

     FETCH v_result_set INTO v_prod_policy_seq_id;
     CLOSE v_result_set;
 ELSE
     OPEN v_result_set FOR
    'SELECT tipp.prod_policy_seq_id
     FROM tpa_enr_policy tep
     LEFT OUTER JOIN tpa_ins_product tip on (tip.product_seq_id=tep.product_seq_id)
     LEFT OUTER JOIN tpa_ins_prod_policy tipp on (tipp.product_seq_id=tip.product_seq_id)
     WHERE tep.policy_seq_id=:v_policy_seq_id'  USING pat_rec.policy_seq_id;

     FETCH v_result_set into v_prod_policy_seq_id;
     CLOSE v_result_set;
   END IF;

    OPEN  cur_relation (v_prod_policy_seq_id);
     FETCH cur_relation INTO relt_cur;
     CLOSE cur_relation;

     OPEN cur_awc;
     FETCH cur_awc INTO awc_rec;
     CLOSE cur_awc;


    IF NVL(awc_rec.ins_intimation_req_yn,'N')!='Y'  
      AND  (case when pat_rec.claim_general_type_id = 'CNH' then relt_cur.ins_clm_cl_apr_rej_yn else relt_cur.ins_clm_cm_apr_rej_yn end) = 'Y' 
      AND ((case when pat_rec.claim_general_type_id = 'CNH' then relt_cur.Ins_Clm_Cl_Allow_Yn else relt_cur.Ins_Clm_Cm_Allow_Yn end )  = 'Y' 
      or (case when pat_rec.claim_general_type_id = 'CNH' then relt_cur.ins_clm_cl_rej_allow_yn else relt_cur.ins_clm_cm_rej_allow_yn end) ='Y')
      THEN

     IF   (case when pat_rec.claim_general_type_id = 'CNH' then relt_cur.ins_clm_cl_apr_rej_yn else relt_cur.ins_clm_cm_apr_rej_yn end) ='Y' THEN
       IF (case when pat_rec.claim_general_type_id = 'CNH' then relt_cur.Ins_Clm_Cl_Allow_Yn else relt_cur.Ins_Clm_Cm_Allow_Yn end ) ='Y' 
         AND awc_rec.clm_status IN ('APR') THEN

              IF (case when pat_rec.claim_general_type_id = 'CNH' then relt_cur.Ins_Clm_cl_Operator else relt_cur.Ins_Clm_cm_Operator end )='GT' THEN
                 IF  awc_rec.total_app_amount>= (case when pat_rec.claim_general_type_id = 'CNH' then relt_cur.Ins_Clm_cl_Apr_Limit else relt_cur.Ins_Clm_cm_Apr_Limit end ) THEN  -----KOCBJJ
                 Raise_application_error(-20866,'The claims requires insurance decision please intimate claim');
                 END IF;
              ELSIF (case when pat_rec.claim_general_type_id = 'CNH' then relt_cur.Ins_Clm_cl_Operator else relt_cur.Ins_Clm_cm_Operator end ) ='LT' THEN
                    IF awc_rec.total_app_amount<= (case when pat_rec.claim_general_type_id = 'CNH' then relt_cur.Ins_Clm_cl_Apr_Limit else relt_cur.Ins_Clm_cm_Apr_Limit end )  THEN  -----KOCBJJ
                    Raise_application_error(-20866,'The claims requires insurance decision please intimate claim');
                    END IF;
              ELSIF (case when pat_rec.claim_general_type_id = 'CNH' then relt_cur.Ins_Clm_cl_Operator else relt_cur.Ins_Clm_cm_Operator end ) ='EQ' THEN
                    IF  awc_rec.total_app_amount= (case when pat_rec.claim_general_type_id = 'CNH' then relt_cur.Ins_Clm_cl_Apr_Limit else relt_cur.Ins_Clm_cm_Apr_Limit end )  THEN  -----KOCBJJ
                    Raise_application_error(-20866,'The claims requires insurance decision please intimate claim');
                    END IF;
              END IF;


        ELSIF   (case when pat_rec.claim_general_type_id = 'CNH' then relt_cur.ins_clm_cl_rej_allow_yn else relt_cur.ins_clm_cm_rej_allow_yn end ) ='Y' 
        and awc_rec.clm_status IN ('REJ')  THEN

        if pat_rec.completed_yn='Y' THEN
         RAISE_APPLICATION_ERROR(-20107,' You cannot modify  this Pre-Auth/claim , Reviews are Completed');
        END IF;

          IF ((awc_rec.clm_ins_status IS NULL or awc_rec.clm_ins_status ='REQ')) THEN
              Raise_application_error(-20866,'The claims requires insurance decision please intimate claim');
          END IF;


        END IF;
    END IF;

     v_awc_yn  :='N';

 END IF;

END claims_ins_error_check;
--===============================================================================

  --koc decoupling
  
  --==============================================================================================
  --   Name       : select_bills_save_next
  --   Created on : 29/11/2013
  --   Created By : - sree krishna
  --   Comments   :

  --===============================================================================
  --koc1356 phase 1
  PROCEDURE select_bills_save_next(v_claim_seq_id        IN clm_general_details.claim_seq_id%TYPE,
                                   v_clm_bill_dtl_seq_id IN OUT clm_bill_details.clm_bill_dtl_seq_id%TYPE,
                                   v_clm_bill_seq_id     IN clm_bill_details.clm_bill_seq_id%TYPE,
                                   v_description         IN clm_bill_details.description%TYPE,
                                   v_ward_type_id        IN clm_bill_details.ward_type_id%TYPE,
                                   v_room_type_id        IN clm_bill_details.room_type_id%TYPE,
                                   v_number_of_days      IN clm_bill_details.number_of_days%TYPE,
                                   v_requested_amount    IN clm_bill_details.requested_amount%TYPE,
                                   v_allow_yn            IN clm_bill_details.allow_yn%TYPE,
                                   v_allowed_amount      IN clm_bill_details.allowed_amount%TYPE,
                                   v_remarks             IN clm_bill_details.remarks%TYPE,
                                   v_vaccination_type_id IN CLM_BILL_DETAILS.VACCINATION_TYPE_ID%TYPE, --KOC1164
                                   v_added_by            IN NUMBER,
                                   bills_cur             OUT SYS_REFCURSOR) IS
    v_rows_processed number(5);
  
    v_clm_dtl_seq_id clm_bill_details.clm_bill_dtl_seq_id%TYPE;
    v_flag           varchar2(1) := 'N';
  
  BEGIN
  
    if nvl(v_claim_seq_id, 0) != 0 or nvl(v_clm_bill_dtl_seq_id, 0) != 0 then
    
      for rec in (select srno, clm_bill_dtl_seq_id
                    from ((SELECT ROW_NUMBER() OVER(ORDER BY a.clm_bill_seq_id, b.clm_bill_dtl_seq_id) As SrNo,
                                  A.clm_bill_seq_id,
                                  b.clm_bill_dtl_seq_id
                             FROM clm_bill_header A
                             LEFT OUTER JOIN clm_bill_details B
                               ON A.clm_bill_seq_id = B.clm_bill_seq_id
                            INNER JOIN clm_general_details C
                               ON A.claim_seq_id = C.claim_seq_id
                            WHERE A.Claim_Seq_Id = v_claim_seq_id))
                   where clm_bill_dtl_seq_id = v_clm_bill_dtl_seq_id) loop
      
        begin
        
          select clm_bill_dtl_seq_id
            into v_clm_dtl_seq_id
            from ((SELECT ROW_NUMBER() OVER(ORDER BY a.clm_bill_seq_id, b.clm_bill_dtl_seq_id) As SrNo,
                          A.clm_bill_seq_id,
                          b.clm_bill_dtl_seq_id
                     FROM clm_bill_header A
                     LEFT OUTER JOIN clm_bill_details B
                       ON A.clm_bill_seq_id = B.clm_bill_seq_id
                    INNER JOIN clm_general_details C
                       ON A.claim_seq_id = C.claim_seq_id
                    WHERE A.Claim_Seq_Id = v_claim_seq_id))
           where srno = rec.srno + 1;
        
        exception
          when others then
          
            v_flag := 'Y';
          
        end;
      
      end loop;
    
      save_clm_bill_details(v_clm_bill_dtl_seq_id => v_clm_bill_dtl_seq_id,
                            v_clm_bill_seq_id     => v_clm_bill_seq_id,
                            v_description         => v_description,
                            v_ward_type_id        => v_ward_type_id,
                            v_room_type_id        => v_room_type_id,
                            v_number_of_days      => v_number_of_days,
                            v_requested_amount    => v_requested_amount,
                            v_allow_yn            => v_allow_yn,
                            v_allowed_amount      => v_allowed_amount,
                            v_remarks             => v_remarks,
                            v_added_by            => v_added_by,
                            v_vaccination_type_id => v_vaccination_type_id,
							v_child_immnunization => null,
                            v_well_child_test_type => null,
                            v_rout_adult_phys_exam => null,
							v_no_of_visits         => null, --Added for koc1320  --koc1308
                            v_rows_processed      => v_rows_processed);
    
      if v_rows_processed >= 1 then
      
        OPEN bills_cur FOR
          SELECT a.clm_bill_dtl_seq_id,
                 a.clm_bill_seq_id,
                 a.description,
                 a.ward_type_id || '#' ||
                 TO_CHAR(capture_number_of_days_yn) AS ward_type_id,
                 b.ward_description,
                 a.requested_amount,
                 a.Allowed_Amount,
                 a.room_type_id,
                 a.number_of_days,
                 a.allow_yn,
                 a.rejected_amount,
                 a.remarks,
                 c.room_description,
                 a.VACCINATION_TYPE_ID,
                 D.VACCINATION_DESCRIPTION,
                 h.bill_no,
                 a.allow_yn --KOC1164
          
            FROM clm_bill_details a
           INNER JOIN tpa_hosp_ward_code b
              ON (a.ward_type_id = b.ward_type_id)
            join clm_bill_header h
              on (h.clm_bill_seq_id = a.clm_bill_seq_id)
            LEFT OUTER JOIN tpa_hosp_rooms_code C
              ON (a.room_type_id = c.room_type_id)
            LEFT OUTER JOIN APP.TPA_VACCINATION_CODE D
              ON (A.VACCINATION_TYPE_ID = D.VACCINATION_ID) --KOC1164
           WHERE a.clm_bill_dtl_seq_id = v_clm_dtl_seq_id
           ORDER BY a.clm_bill_dtl_seq_id;
      
      else
      
        OPEN bills_cur FOR
          SELECT a.clm_bill_dtl_seq_id,
                 a.clm_bill_seq_id,
                 a.description,
                 a.ward_type_id || '#' ||
                 TO_CHAR(capture_number_of_days_yn) AS ward_type_id,
                 b.ward_description,
                 a.requested_amount,
                 a.Allowed_Amount,
                 a.room_type_id,
                 a.number_of_days,
                 a.allow_yn,
                 a.rejected_amount,
                 a.remarks,
                 c.room_description,
                 a.VACCINATION_TYPE_ID,
                 D.VACCINATION_DESCRIPTION,
                 h.bill_no,
                 a.allow_yn --KOC1164
          
            FROM clm_bill_details a
           INNER JOIN tpa_hosp_ward_code b
              ON (a.ward_type_id = b.ward_type_id)
            join clm_bill_header h
              on (h.clm_bill_seq_id = a.clm_bill_seq_id)
            LEFT OUTER JOIN tpa_hosp_rooms_code C
              ON (a.room_type_id = c.room_type_id)
            LEFT OUTER JOIN APP.TPA_VACCINATION_CODE D
              ON (A.VACCINATION_TYPE_ID = D.VACCINATION_ID) --KOC1164
           WHERE a.clm_bill_dtl_seq_id = v_clm_bill_dtl_seq_id
           ORDER BY a.clm_bill_dtl_seq_id;
      
      end if;
    
    end if;
  
    if v_flag = 'Y' then
    
      OPEN bills_cur FOR
        SELECT a.clm_bill_dtl_seq_id,
               a.clm_bill_seq_id,
               a.description,
               a.ward_type_id || '#' || TO_CHAR(capture_number_of_days_yn) AS ward_type_id,
               b.ward_description,
               a.requested_amount,
               a.Allowed_Amount,
               a.room_type_id,
               a.number_of_days,
               a.allow_yn,
               a.rejected_amount,
               a.remarks,
               c.room_description,
               a.VACCINATION_TYPE_ID,
               D.VACCINATION_DESCRIPTION,
               h.bill_no,
               a.allow_yn --KOC1164
        
          FROM clm_bill_details a
         INNER JOIN tpa_hosp_ward_code b
            ON (a.ward_type_id = b.ward_type_id)
          join clm_bill_header h
            on (h.clm_bill_seq_id = a.clm_bill_seq_id)
          LEFT OUTER JOIN tpa_hosp_rooms_code C
            ON (a.room_type_id = c.room_type_id)
          LEFT OUTER JOIN APP.TPA_VACCINATION_CODE D
            ON (A.VACCINATION_TYPE_ID = D.VACCINATION_ID) --KOC1164
         WHERE a.clm_bill_dtl_seq_id = v_clm_bill_dtl_seq_id
         ORDER BY a.clm_bill_dtl_seq_id;
    
    end if;
  
  END select_bills_save_next;
  --koc1356 phase 1
--===========================
--====================================================================

PROCEDURE save_clm_diagnosys ( v_diagnosys_seq_id              IN OUT tpa_diagnosys_details.diagnosys_seq_id%type,
                                 v_claim_seq_id                  IN clm_bill_header.claim_seq_id%type,
                                 v_diagnosys_name                IN tpa_diagnosys_details.diagnosys_name%type,
                                 v_diag_type_id                  IN varchar2,
                                 v_added_by                      IN clm_bill_header.added_by%type,
                                 v_hospital_general_type_id      IN ICD_PCS_DETAIL.hospital_general_type_id%TYPE,
                                 v_trtmnt_plan_general_type_id   IN ICD_PCS_DETAIL.trtmnt_plan_general_type_id%TYPE,
                                 v_frequency_of_visit            IN ICD_PCS_DETAIL.frequency_of_visit%TYPE,
                                 v_pat_duration_general_type_id  IN AILMENT_DETAILS.pat_duration_general_type_id%TYPE,
                                 v_no_of_visits                  IN ICD_PCS_DETAIL.no_of_visits%TYPE,
                                 v_tariff_general_type_id        IN ICD_PCS_DETAIL.tariff_general_type_id%TYPE,                            
                                 v_pkg_seq_id                    IN PAT_PACKAGE_PROCEDURES.PKG_SEQ_ID%TYPE,
                                 v_rows_processed             OUT NUMBER) IS

     cursor diag_info_cur is
     select d.diagnosys_seq_id,d.diagnosys_name,d.primary_ailment_yn,d.secondary_ailment_yn,d.comorb_ailment_yn,
     d.hospital_general_type_id,d.trtmnt_plan_general_type_id,d.tariff_general_type_id,d.frequency_of_visit,
     d.pat_duration_general_type_id,d.no_of_visits,d.pkg_seq_id,i.icd_pcs_seq_id,i.ped_code_id,i.other_desc,
     i.icd_code
      from tpa_diagnosys_details d
      join icd_pcs_detail i on (i.diagnosys_seq_id = d.diagnosys_seq_id)
     where d.diagnosys_seq_id = v_diagnosys_seq_id and d.claim_seq_id = v_claim_seq_id;

  v_proc_seq_ids varchar2(2000);
  v_cnt varchar2(2000);
  v_final_diag   ailment_details.provisional_diagnosis%type;

  BEGIN
    

 select count(1) into v_cnt
      from tpa_diagnosys_details d  where d.claim_seq_id = v_claim_seq_id
      and d.diagnosys_seq_id != v_diagnosys_seq_id and nvl(d.primary_ailment_yn,'N')='Y'; 
 
  if v_cnt > 0  and v_diag_type_id='PRE' then 
 raise_application_error(-20100,'Primary Ailment Already Selected ');
  end if; 
  
 select count(1) into v_cnt from ailment_details ail  where ail.claim_seq_id = v_claim_seq_id;
       
  if v_cnt = 0 then 
   raise_application_error(-20882,'Please Add Ailment details First, Before adding Diagnosys details');
  end if; 
 
  for cod_yn in (select * from app.clm_data_entry_complete dc where dc.claim_seq_id = v_claim_seq_id
   and dc.cod_complete_yn='Y')
   loop

     update clm_data_entry_complete dc
     set dc.cod_complete_yn='N'
     where dc.claim_seq_id = cod_yn.claim_seq_id;

     update clm_general_details g
     set g.last_assign_user_seq_id = null
     where g.claim_seq_id = cod_yn.claim_seq_id;

   end loop;
 
    IF nvl(v_diagnosys_seq_id,0) = 0 THEN
      INSERT INTO tpa_diagnosys_details
        (diagnosys_seq_id,
         claim_seq_id,
         diagnosys_name,
       --  diag_type_id,
         added_by,
         added_date,
         PRIMARY_AILMENT_YN,
         SECONDARY_AILMENT_YN,
         COMORB_AILMENT_YN,
         hospital_general_type_id,
         trtmnt_plan_general_type_id,
         tariff_general_type_id,
         frequency_of_visit,
         pat_duration_general_type_id,
         no_of_visits,
         PKG_SEQ_ID)
      VALUES
        (clm_bill_seq.NEXTVAL,
         v_claim_seq_id,
         v_diagnosys_name,
         v_added_by,
         SYSDATE,
         case v_diag_type_id when 'PRE' then 'Y' 
          else 'N' end,
         case v_diag_type_id when 'SEC' then 'Y' 
          else 'N' end,
          case v_diag_type_id when 'COM' then 'Y' 
          else 'N' end,
         v_hospital_general_type_id,
         v_trtmnt_plan_general_type_id,
         v_tariff_general_type_id,
         v_frequency_of_visit,
         v_pat_duration_general_type_id,
         v_no_of_visits,
         v_pkg_seq_id) 
         RETURNING diagnosys_seq_id INTO v_diagnosys_seq_id;
           
    ELSE
      
      UPDATE tpa_diagnosys_details
         SET diagnosys_name               = v_diagnosys_name,
             updated_by                   = v_added_by,
             updated_date                 = SYSDATE,
             PRIMARY_AILMENT_YN           = case v_diag_type_id when 'PRE' then 'Y' else 'N' end,
             SECONDARY_AILMENT_YN         = case v_diag_type_id when 'SEC' then 'Y' else 'N' end,
             COMORB_AILMENT_YN            = case v_diag_type_id when 'COM' then 'Y' else 'N' end,
             hospital_general_type_id     = v_hospital_general_type_id,
             trtmnt_plan_general_type_id  = v_trtmnt_plan_general_type_id,
             tariff_general_type_id       = v_tariff_general_type_id,
             frequency_of_visit           = v_frequency_of_visit,
             pat_duration_general_type_id = v_pat_duration_general_type_id,
             no_of_visits                 = v_no_of_visits,
             PKG_SEQ_ID                   = v_pkg_seq_id
       WHERE diagnosys_seq_id = v_diagnosys_seq_id;
       
       
  if nvl(v_diagnosys_seq_id,0) != 0 then 

  for diag_info_rec in diag_info_cur 
    loop
     v_proc_seq_ids:=null;
       for prc_rec in (select * from app.pat_package_procedures p where p.icd_pcs_seq_id = diag_info_rec.icd_pcs_seq_id
	   and  p.proc_seq_id is not null )
         loop
         v_proc_seq_ids := v_proc_seq_ids||'|'||prc_rec.proc_seq_id;  
       end loop;
         
         if v_proc_seq_ids is not null then
           v_proc_seq_ids := v_proc_seq_ids||'|';   
         end if;

  pre_auth_pkg.save_icd_pcs_detail_update(v_icd_pcs_seq_id => diag_info_rec.icd_pcs_seq_id,
                                                  v_seq_id => v_claim_seq_id,
                                                  v_ped_code_id => diag_info_rec.ped_code_id,
                                                  v_other_desc => diag_info_rec.other_desc,
                                                  v_icd_code => diag_info_rec.icd_code,
                                                  v_primary_ailment_yn => diag_info_rec.primary_ailment_yn,
                                                  v_hospital_general_type_id => diag_info_rec.hospital_general_type_id,
                                                  v_trtmnt_plan_general_type_id => diag_info_rec.trtmnt_plan_general_type_id,
                                                  v_frequency_of_visit => diag_info_rec.frequency_of_visit,
                                                  v_pat_duration_general_type_id => diag_info_rec.pat_duration_general_type_id,
                                                  v_no_of_visits => diag_info_rec.no_of_visits,
                                                  v_tariff_general_type_id => diag_info_rec.tariff_general_type_id,
                                                  v_pkg_seq_id => diag_info_rec.pkg_seq_id,
                                                  v_proc_seq_ids => v_proc_seq_ids,
                                                  v_proc_delete_seq_ids => null,
                                                  v_scr_mode => 'CLM',
                                                  v_added_by => v_added_by,
                                                  v_diagnosys_seq_id => diag_info_rec.diagnosys_seq_id,
                                                  v_secondary_ailment_yn => diag_info_rec.secondary_ailment_yn,
                                                  v_comorb_ailment_yn => diag_info_rec.comorb_ailment_yn,
                                                  v_rows_processed => v_rows_processed);

   end loop;
  end if;

    END IF;

  for rec in ( select d.diagnosys_seq_id,d.diagnosys_name
      from tpa_diagnosys_details d where  d.claim_seq_id = v_claim_seq_id  order by d.added_date asc) 
    loop
    v_final_diag := v_final_diag||', '||rec.diagnosys_name;     
    end loop;   

    v_final_diag := ltrim(v_final_diag,',');

  update ailment_details ail
  set ail.provisional_diagnosis = v_final_diag
  where ail.claim_seq_id = v_claim_seq_id;
    COMMIT;

    v_rows_processed := SQL%ROWCOUNT;

    pre_auth_pkg.set_validation_status('C',v_claim_seq_id,'U',v_added_by);
  
  END save_clm_diagnosys;


--====================================================================

  PROCEDURE select_clm_diagnosys_list (v_claim_seq_id      IN clm_bill_header.claim_seq_id%type,
                                       v_resultset         OUT SYS_REFCURSOR) 
  IS

  BEGIN

    OPEN v_resultset FOR
    select d.diagnosys_seq_id,d.diagnosys_name,case when d.primary_ailment_yn='Y' then 'Primary' 
                                                     else case when d.secondary_ailment_yn='Y' then 'Secondary'
                                                     else case when d.comorb_ailment_yn='Y' then 'Co-Morbidities'
                                                       end end end as diag_type, 
                                                      case d.hospital_general_type_id  when 'REL' then 'Regular'
                                                          when 'REP' then 'Repeated' end as hospital_general_type_id,
                                                       case d.trtmnt_plan_general_type_id when 'SUR' then 'Surgical'
                                                          when 'MDC' then 'Medical' end as trtmnt_plan_general_type_id

    from tpa_diagnosys_details d
    JOIN clm_general_details g on (g.claim_seq_id=d.claim_seq_id)
    where d.claim_seq_id = v_claim_seq_id order by d.added_date asc;

  END select_clm_diagnosys_list;

--====================================================================

  PROCEDURE select_clm_diagnosys (v_diagnosys_seq_id  IN OUT tpa_diagnosys_details.diagnosys_seq_id%type,
                                  v_resultset         OUT SYS_REFCURSOR) 
  IS

  BEGIN

    OPEN v_resultset FOR
    select d.diagnosys_seq_id,d.diagnosys_name,case when d.primary_ailment_yn='Y' then 'PRE' 
    else case when d.secondary_ailment_yn='Y' then 'SEC' else case when d.comorb_ailment_yn='Y' then 'COM'  end end end as diag_type,
    d.hospital_general_type_id,d.trtmnt_plan_general_type_id,d.tariff_general_type_id,d.frequency_of_visit,
    d.pat_duration_general_type_id,d.no_of_visits,d.pkg_seq_id
    from tpa_diagnosys_details d
    JOIN clm_general_details g on (g.claim_seq_id=d.claim_seq_id)
    where d.diagnosys_seq_id = v_diagnosys_seq_id;

  END select_clm_diagnosys;

--====================================================================

  PROCEDURE delete_clm_diagnosys (v_diagnosys_seq_id  IN tpa_diagnosys_details.diagnosys_seq_id%type,
                                  v_rows_processed    OUT NUMBER) 
  IS
  
  v_final_diag    ailment_details.provisional_diagnosis%type;
  v_claim_seq_id  clm_general_details.claim_seq_id%type;
  
  BEGIN

 delete from tpa_diagnosys_details d where d.diagnosys_seq_id = v_diagnosys_seq_id
 returning d.claim_seq_id into v_claim_seq_id;
 
 for rec in (select d.diagnosys_seq_id, d.diagnosys_name
               from tpa_diagnosys_details d
              where d.claim_seq_id = v_claim_seq_id order by d.added_date asc) loop
   v_final_diag := v_final_diag || ', ' || rec.diagnosys_name;
 end loop;
 
 v_final_diag := ltrim(v_final_diag, ',');
 
 update ailment_details ail
    set ail.provisional_diagnosis = v_final_diag
  where ail.claim_seq_id = v_claim_seq_id;
 
 v_rows_processed := SQL%ROWCOUNT;

  END delete_clm_diagnosys;

--====================================================================
 END CLAIMS_PKG;

/

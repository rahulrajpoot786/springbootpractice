--------------------------------------------------------
--  DDL for Synonymn GROUP_INCEPTION_TEMP_IDX
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."GROUP_INCEPTION_TEMP_IDX" FOR "APP"."GROUP_INCEPTION_TEMP_IDX";

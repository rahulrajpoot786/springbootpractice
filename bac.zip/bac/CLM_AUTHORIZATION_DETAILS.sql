--------------------------------------------------------
--  DDL for Synonymn CLM_AUTHORIZATION_DETAILS
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."CLM_AUTHORIZATION_DETAILS" FOR "APP"."CLM_AUTHORIZATION_DETAILS";

--------------------------------------------------------
--  DDL for Package Body HOSPITAL_MOU
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "VENUBABU"."HOSPITAL_MOU" 
IS

  PROCEDURE pr_mou_save(v_hosp_seq_id tpa_hosp_empanel_status.hosp_seq_id%TYPE,
                        v_mou  IN XMLTYPE,
                        v_added_by tpa_hosp_mou.added_by%TYPE
                        )
  IS
    v_empanel_seq_id tpa_hosp_mou.empanel_seq_id%TYPE;
    V_CTR NUMBER:= 0;
  BEGIN
    SELECT empanel_seq_id INTO v_empanel_seq_id
      FROM tpa_hosp_empanel_status
      WHERE hosp_seq_id = v_hosp_seq_id AND active_yn = 'Y';

    SELECT COUNT(1) INTO v_ctr FROM tpa_hosp_mou WHERE EMPANEL_SEQ_ID = V_EMPANEL_SEQ_ID;
    IF v_ctr = 0 THEN
        INSERT INTO tpa_hosp_mou(empanel_seq_id,hosp_mou,added_by,added_date)
          VALUES(v_empanel_seq_id,v_mou,v_added_by,SYSDATE);
    ELSE
        UPDATE tpa_hosp_mou SET
                      hosp_mou      = v_mou,
                      updated_by    = v_added_by,
                      updated_date  = SYSDATE WHERE empanel_seq_id = v_empanel_seq_id;
    END IF;

    COMMIT;
  END pr_mou_save;
end HOSPITAL_MOU;

/

--------------------------------------------------------
--  DDL for Synonymn HOSPITALIZATION_PROC
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."HOSPITALIZATION_PROC" FOR "APP"."HOSPITALIZATION_PROC";

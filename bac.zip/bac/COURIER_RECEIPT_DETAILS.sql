--------------------------------------------------------
--  DDL for Synonymn COURIER_RECEIPT_DETAILS
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."COURIER_RECEIPT_DETAILS" FOR "INTX"."COURIER_RECEIPT_DETAILS";

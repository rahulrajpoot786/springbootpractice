--------------------------------------------------------
--  DDL for Synonymn EMP_COR_SEQ
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."EMP_COR_SEQ" FOR "APP"."EMP_COR_SEQ";

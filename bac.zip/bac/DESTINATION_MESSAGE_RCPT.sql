--------------------------------------------------------
--  DDL for Synonymn DESTINATION_MESSAGE_RCPT
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."DESTINATION_MESSAGE_RCPT" FOR "APP"."DESTINATION_MESSAGE_RCPT";

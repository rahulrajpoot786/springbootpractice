--------------------------------------------------------
--  DDL for Synonymn IDX_CALLPATINT_HOSPLIST
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."IDX_CALLPATINT_HOSPLIST" FOR "APP"."IDX_CALLPATINT_HOSPLIST";

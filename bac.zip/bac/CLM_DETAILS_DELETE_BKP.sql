--------------------------------------------------------
--  DDL for Synonymn CLM_DETAILS_DELETE_BKP
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."CLM_DETAILS_DELETE_BKP" FOR "APP"."CLM_DETAILS_DELETE_BKP";

--------------------------------------------------------
--  DDL for Synonymn HR_UPLOAD_DETAILS
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."HR_UPLOAD_DETAILS" FOR "APP"."HR_UPLOAD_DETAILS";

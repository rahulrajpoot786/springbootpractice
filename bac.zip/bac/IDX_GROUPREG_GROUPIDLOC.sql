--------------------------------------------------------
--  DDL for Synonymn IDX_GROUPREG_GROUPIDLOC
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."IDX_GROUPREG_GROUPIDLOC" FOR "APP"."IDX_GROUPREG_GROUPIDLOC";

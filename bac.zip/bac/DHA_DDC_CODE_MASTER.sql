--------------------------------------------------------
--  DDL for Synonymn DHA_DDC_CODE_MASTER
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."DHA_DDC_CODE_MASTER" FOR "APP"."DHA_DDC_CODE_MASTER";

--------------------------------------------------------
--  DDL for Synonymn CLM_HOSPITAL_DETAILS_HOSP_SE
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."CLM_HOSPITAL_DETAILS_HOSP_SE" FOR "APP"."CLM_HOSPITAL_DETAILS_HOSP_SE";

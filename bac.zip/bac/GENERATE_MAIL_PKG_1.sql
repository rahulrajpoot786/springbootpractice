--------------------------------------------------------
--  DDL for Package GENERATE_MAIL_PKG
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "VENUBABU"."GENERATE_MAIL_PKG" IS

  -- Author  : PRAKASH_CS
  -- Created : 11/15/2006 4:05:55 PM
  -- Purpose : Purpose is to generate the message

  -- Public type declarations
  TYPE v_array IS VArray(30) OF VARCHAR2(4000);
  v_params     v_array := v_array(1,
                                  2,
                                  3,
                                  4,
                                  5,
                                  6,
                                  7,
                                  8,
                                  9,
                                  10,
                                  11,
                                  12,
                                  13,
                                  14,
                                  15,
                                  16,
                                  17,
                                  18,
                                  19);
  v_SMS_params v_array := v_array(1, 2, 3, 4, 5, 6, 7, 8, 9, 10);
  
  TYPE res_object_rec_type IS RECORD(  PBM_BLKEXLCNT         NUMBER
                                      ,PBM_BLKPRCCNT         NUMBER
                                      ,PBM_RCVCLMCNT         NUMBER
                                      ,PBM_RCVACTCNT         NUMBER
                                      ,PBM_PRCCLMCNT         NUMBER 
                                      ,PBM_PRCACTCNT         NUMBER
                                      ,PROVIDER_BLKEXLCNT    NUMBER
                                      ,PROVIDER_BLKPRCCNT    NUMBER
                                      ,PROVIDER_RCVCLMCNT    NUMBER
                                      ,PROVIDER_RCVACTCNT    NUMBER
                                      ,PROVIDER_PRCCLMCNT    NUMBER
                                      ,PROVIDER_PRCACTCNT    NUMBER
                                      ,VINGS_BLKEXLCNT       NUMBER
                                      ,VINGS_BLKPRCCNT       NUMBER
                                      ,VINGS_RCVCLMCNT       NUMBER
                                      ,VINGS_RCVACTCNT       NUMBER
                                      ,VINGS_PRCCLMCNT       NUMBER
                                      ,VINGS_PRCACTCNT       NUMBER 
                                     );
  TYPE res_type IS TABLE OF res_object_rec_type;
  v_res_type  res_type;
       
  PROCEDURE proc_send_message_scheduled(v_msg_type  destination_message_rcpt.msg_type%TYPE,
                                        v_resultset OUT SYS_REFCURSOR
                                        
                                        );

  PROCEDURE proc_send_msg_sched_preauth(v_msg_type  destination_message_rcpt.msg_type%TYPE,
                                        v_resultset OUT SYS_REFCURSOR);
  
  PROCEDURE proc_send_scheduled_otp(v_msg_type  destination_message_rcpt.msg_type%TYPE,
                                    v_resultset OUT SYS_REFCURSOR
                                   );
                                   
  PROCEDURE proc_get_pending_fax(v_resultset OUT SYS_REFCURSOR);
  

  --PROCEDURE proc_schedule_message;

  PROCEDURE proc_get_mail_details(v_policy_seq_id  tpa_enr_policy.policy_seq_id%TYPE,
                                  v_seq_id         tpa_enr_policy_member.member_seq_id%TYPE,
                                  v_tpa_code       OUT tpa_office_info.office_code%TYPE,
                                  v_tpa_toll_phone OUT tpa_office_info.toll_free_no%TYPE);

  PROCEDURE proc_form_message(v_message_type_id    VARCHAR2,
                              v_parameters         VARCHAR2,
                              v_added_by           Destination_message.added_by%TYPE DEFAULT 0,
                              v_DEST_MSG_SEQ_ID    OUT VARCHAR2,
                              v_additional_param   VARCHAR2 DEFAULT 0,
                              v_additional_param_2 VARCHAR2 DEFAULT 0,
                              v_additional_param_3 VARCHAR2 DEFAULT 0,
                              v_doc                VARCHAR2 DEFAULT null --added by chiranjibi
                              );

  PROCEDURE proc_generate_message(v_message_type_id    VARCHAR2,
                                  v_parameters         VARCHAR2,
                                  v_added_by           Destination_message.added_by%TYPE,
                                  v_DEST_MSG_SEQ_ID    OUT VARCHAR2,
                                  v_additional_param   VARCHAR2 DEFAULT 0,
                                  v_additional_param_2 VARCHAR2 DEFAULT 0,
                                  v_additional_param_3 VARCHAR2 DEFAULT 0,
                                  v_doc                VARCHAR2 DEFAULT null --added by chiranjibi
                                  );

  PROCEDURE proc_mail_merge(v_message_type_id VARCHAR2,
                            v_option          VARCHAR2,
                            v_clean_up        VARCHAR2,
                            v_merged_message  OUT VARCHAR2);

  PROCEDURE proc_verify_communication(v_message_type_id VARCHAR2,
                                      v_data            VARCHAR2);

  PROCEDURE proc_enr_numbers(v_batch_seq NUMBER);

  PROCEDURE update_message_rcpt_status(v_dest_msg_rcpt_seq_id   IN NUMBER,
                                       v_mail_status            IN VARCHAR2,
                                       v_message_job_id         IN VARCHAR2,
                                       v_message_remarks        IN VARCHAR2,
                                       v_status_general_type_id IN VARCHAR2);

  PROCEDURE validate_process_mail(v_message_type_id      VARCHAR2, -- The Actual Message id generated by the application
                                  v_parameters           VARCHAR2,
                                  v_mail_category        VARCHAR2, -- The send message id is of what type in Database
                                  v_process_yn           OUT VARCHAR2, -- Can the process be done or not
                                  v_general_mail         OUT VARCHAR2, -- Generic mail id created at the group
                                  v_cc_mail              OUT VARCHAR2,
                                  v_group_name           OUT VARCHAR2,
                                  v_customise_allowed_YN VARCHAR2);
  --=============================================================================================

  PROCEDURE generate_clm_shortfal_mails(v_message_type    IN VARCHAR2,
                                        v_seq_id          IN VARCHAR2,
                                        v_request_type    IN VARCHAR2,
                                        v_dest_msg_seq_id OUT VARCHAR2,
                                        v_added_by        IN Destination_message.added_by%TYPE,
                                        v_rows_processed  OUT NUMBER);

  --=============================================================================================
  PROCEDURE proc_get_ccemail_dtls(v_message_type_id      VARCHAR2, -- The Actual Message id generated by the application
                                  v_parameters           VARCHAR2,
                                  v_mail_category        VARCHAR2, -- The send message id is of what type in Database
                                  v_process_yn           OUT VARCHAR2, -- Can the process be done or not
                                  v_general_mail         OUT VARCHAR2, -- Generic TO Email id created at the group
                                  v_cc_mail              OUT VARCHAR2, -- Generic CC Email id created at the group
                                  v_customise_allowed_YN VARCHAR2);
  --=============================================================================================

  procedure proc_generate_mail(v_msg_id             IN varchar2,
                               v_pat_clm_seq_id     IN clm_general_details.claim_seq_id%type,
                               v_prod_policy_seq_id IN tpa_ins_prod_policy.prod_policy_seq_id%type,
                               v_added_by           IN number);
  ------==========================================koc cigna mails ====================================
  PROCEDURE proc_form_message_cigna(v_message_type_id    VARCHAR2,
                                    v_parameters         VARCHAR2,
                                    v_added_by           Destination_message.added_by%TYPE,
                                    v_DEST_MSG_SEQ_ID    OUT VARCHAR2,
                                    v_additional_param   VARCHAR2 DEFAULT 0,
                                    v_additional_param_2 VARCHAR2 DEFAULT 0,
                                    v_additional_param_3 VARCHAR2 DEFAULT 0);
  --------------------------------------------
  PROCEDURE proc_generate_message_cigna(v_message_type_id    VARCHAR2,
                                        v_parameters         VARCHAR2,
                                        v_added_by           Destination_message.added_by%TYPE,
                                        v_DEST_MSG_SEQ_ID    OUT VARCHAR2,
                                        v_additional_param   VARCHAR2 DEFAULT 0,
                                        v_additional_param_2 VARCHAR2 DEFAULT 0,
                                        v_additional_param_3 VARCHAR2 DEFAULT 0);
  -----------------------------------------------------
  PROCEDURE validate_process_mail_cigna(v_message_type_id      VARCHAR2, -- The Actual Message id generated by the application
                                        v_parameters           VARCHAR2,
                                        v_mail_category        VARCHAR2, -- The send message id is of what type in Database
                                        v_process_yn           OUT VARCHAR2, -- Can the process be done or not
                                        v_general_mail         OUT VARCHAR2, -- Generic TO Email id created at the group
                                        v_cc_mail              OUT VARCHAR2, -- Generic CC Email id created at the group
                                        v_group_name           OUT VARCHAR2,
                                        v_customise_allowed_YN VARCHAR2);

-------------------------------------------------------------------
PROCEDURE proc_dashboard_mail(v_message_type_id    VARCHAR2,
                              v_parameters         VARCHAR2,
                              v_added_by           Destination_message.added_by%TYPE,
                              v_DEST_MSG_SEQ_ID    OUT VARCHAR2,
                              v_result             OUT SYS_REFCURSOR
                              );
---------------------------------------------------------------------                              
END GENERATE_MAIL_PKG;

 

/

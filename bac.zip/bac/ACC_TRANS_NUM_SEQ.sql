--------------------------------------------------------
--  DDL for Synonymn ACC_TRANS_NUM_SEQ
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."ACC_TRANS_NUM_SEQ" FOR "APP"."ACC_TRANS_NUM_SEQ";

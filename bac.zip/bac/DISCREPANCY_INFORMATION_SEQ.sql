--------------------------------------------------------
--  DDL for Synonymn DISCREPANCY_INFORMATION_SEQ
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."DISCREPANCY_INFORMATION_SEQ" FOR "APP"."DISCREPANCY_INFORMATION_SEQ";

--------------------------------------------------------
--  DDL for Synonymn CLM_LIABILITY_REPORT
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."CLM_LIABILITY_REPORT" FOR "APP"."CLM_LIABILITY_REPORT";

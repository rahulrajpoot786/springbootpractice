--------------------------------------------------------
--  DDL for Synonymn GET_MR_AMD_BUFFER
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."GET_MR_AMD_BUFFER" FOR "APP"."GET_MR_AMD_BUFFER";

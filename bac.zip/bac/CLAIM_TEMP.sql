--------------------------------------------------------
--  DDL for Synonymn CLAIM_TEMP
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."CLAIM_TEMP" FOR "APP"."CLAIM_TEMP";

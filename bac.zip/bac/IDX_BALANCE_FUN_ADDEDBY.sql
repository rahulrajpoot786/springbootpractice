--------------------------------------------------------
--  DDL for Synonymn IDX_BALANCE_FUN_ADDEDBY
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."IDX_BALANCE_FUN_ADDEDBY" FOR "APP"."IDX_BALANCE_FUN_ADDEDBY";

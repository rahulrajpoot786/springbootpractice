--------------------------------------------------------
--  DDL for Synonymn CLAIMANT_PED_SEQ
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."CLAIMANT_PED_SEQ" FOR "APP"."CLAIMANT_PED_SEQ";

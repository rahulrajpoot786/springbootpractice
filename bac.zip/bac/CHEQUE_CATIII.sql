--------------------------------------------------------
--  DDL for Synonymn CHEQUE_CATIII
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."CHEQUE_CATIII" FOR "APP"."CHEQUE_CATIII";

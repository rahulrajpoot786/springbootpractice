--------------------------------------------------------
--  DDL for Synonymn HOSPITALIZATION
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."HOSPITALIZATION" FOR "APP"."HOSPITALIZATION";

--------------------------------------------------------
--  DDL for Synonymn FINANCE_LOGS
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."FINANCE_LOGS" FOR "INTX"."FINANCE_LOGS";

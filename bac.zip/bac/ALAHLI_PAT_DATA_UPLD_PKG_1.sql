--------------------------------------------------------
--  DDL for Package ALAHLI_PAT_DATA_UPLD_PKG
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "VENUBABU"."ALAHLI_PAT_DATA_UPLD_PKG" 
AS

  -- Author  : LALATENDU.PRADHAN
  -- Created : 4/12/2018 6:57:14 PM
  -- Purpose : ALAHALI WEB INTEGRATION(PRE AUTH CREATION FROM READING XML FOR ALAHLI PROVIDER)

------*******SAVE XML TO TABLE*********---------- 

PROCEDURE SAVE_PRE_AUTH_XML(
                            
                             v_pat_in_xl             IN  XMLTYPE,
                             v_result_set            OUT SYS_REFCURSOR 
                       
      					   );
                            
------*******PARSE AND VALIDATION AND SAVE*******-------

 PROCEDURE   PARSE_PAT_XML_DTLS  (
                                  
                                 V_XML_SEQ_ID        IN PAT_XML_UPLD_DTA.XML_SEQ_ID%TYPE 
                                 
                                 );
-----**********ERROR LOG TRACKING************

PROCEDURE create_exception_log(
                              v_xml_seq_id            IN NUMBER,                             
                              v_sql_code              IN VARCHAR2,
                              v_sql_msg               IN VARCHAR2,
                              V_USER_DEFNED_MSG       IN CLOB,
                              v_added_by              IN NUMBER,
                              V_ERR_MSG               IN VARCHAR2
                               );
							   
-----**********LEAP YEAR*********--------------

FUNCTION FN_LEAP_YEAR (
                              p_year IN VARCHAR2
                       ) 
   RETURN VARCHAR2 ;   
   
----------****NEED TO CHECK WHEATHER ERROR EXIST OR NOT *****-------

FUNCTION  ERROR_EXIST_YN(
                         v_xml_seq_id         IN NUMBER
						             )
 RETURN VARCHAR2;
 
---------*******PREAUTH INFORMATION SAVE***********----------------

PROCEDURE SAVE_AUTHORIZATION_DETAILS(
                                     v_disposition                       IN   VARCHAR2,
                                     v_pat_ath_seq_id                  IN OUT APP.pat_authorization_details.pat_auth_seq_id%type,
                                     v_event_no                          IN   APP.pat_authorization_details.event_no%TYPE,
									                   v_med_type                          IN   APP.pat_authorization_details.system_of_medicine_type_id%TYPE,
									                   v_accid_rel_case                    IN   APP.pat_authorization_details.accident_related_type_id%TYPE,
									                   v_tpa_enroll_id                     IN   APP.pat_authorization_details.tpa_enrollment_id%TYPE,
									                   v_requested_amnt                    IN   APP.pat_authorization_details.requested_amount%TYPE,
									                   v_clinician_id                      IN   APP.pat_authorization_details.clinician_id%TYPE,
									                   v_clinicianname                     IN   APP.tpa_hosp_professionals.contact_name%TYPE,
									                   v_benefitType                       IN   APP.pat_authorization_details.benifit_type%TYPE,
									                   v_encounterType                     IN   APP.pat_authorization_details.encounter_type_id%TYPE,
                                     v_encterStrtType                    IN   APP.pat_authorization_details.encounter_start_type%TYPE,
 									                   v_encterEndType                     IN   APP.pat_authorization_details.encounter_end_type%TYPE,
									                   v_date_of_hosp                      IN   VARCHAR2,
								                  	 v_date_hosp_time                    IN   VARCHAR2,
                                     v_hosp_time_am                      IN   VARCHAR2,
                                     v_date_of_exit                      IN   VARCHAR2,--pat_authorization_details.discharge_date%TYPE;
                                     v_date_dis_time                     IN   VARCHAR2,
                                     v_dish_time_pm                      IN   VARCHAR2,
                                     v_den_encnt_type                    IN   APP.pat_authorization_details.treatment_type%TYPE,
                                     v_lmp                               IN   VARCHAR2,
                                     v_mode_of_delvry                    IN   APP.pat_authorization_details.delvry_mod_type%TYPE,
                                     v_nat_conception                    IN   APP.pat_authorization_details.conception_type%TYPE,
                                     v_pre_auth_number                 IN OUT APP.pat_authorization_details.pre_auth_number%TYPE,
                                     v_presenting_complaints             IN   APP.pat_authorization_details.presenting_complaints%TYPE,
                                     v_clinician_mail                    IN   APP.pat_authorization_details.clinician_mail%type,
                                     v_xml_seq_id                        IN   NUMBER,
									                   v_rows_processed                    OUT  NUMBER
								                 	 ); 
                                   
----------*************SAVE DENTAL INFORMATION***********------------------------
PROCEDURE  SAVE_ORTHO_DETAILS(
                                 v_xml_seq_id                      IN   NUMBER,
                                 v_disposition                     IN  VARCHAR2,
                                 v_pat_ath_seq_id                  IN  APP.pat_authorization_details.pat_auth_seq_id%type,                     
                                 p_dento_class_i                   IN  APP.orthodontic_details_tab.dento_class_i%TYPE,
                                 p_dento_class_ii                  IN  APP.orthodontic_details_tab.dento_class_ii%TYPE,
                                 p_dento_class_ii_text             IN  APP.orthodontic_details_tab.dento_class_ii_text%TYPE,
                                 p_dento_class_iii                 IN  APP.orthodontic_details_tab.dento_class_iii%TYPE,
                                 p_dento_class_iii_text            IN  APP.orthodontic_details_tab.dento_class_iii_text%TYPE,
                                 p_skele_class_i                   IN  APP.orthodontic_details_tab.skele_class_i%TYPE,
                                 p_skele_class_ii                  IN  APP.orthodontic_details_tab.skele_class_ii%TYPE,
                                 p_skele_class_iii                 IN  APP.orthodontic_details_tab.skele_class_iii%TYPE,
                                 p_overjet_mm                      IN  APP.orthodontic_details_tab.overjet_mm%TYPE,
                                 p_rev_overjet_mm                  IN  APP.orthodontic_details_tab.rev_overjet_mm%TYPE,
                                 p_rev_overjet_yn                  IN  APP.orthodontic_details_tab.rev_overjet_yn%TYPE,
                                 p_crossbite_ant                   IN  APP.orthodontic_details_tab.crossbite_ant%TYPE,
                                 p_crossbite_post                  IN  APP.orthodontic_details_tab.crossbite_post%TYPE,
                                 p_crossbite_betw                  IN  APP.orthodontic_details_tab.crossbite_betw%TYPE,
                                 p_openbit_ant                     IN  APP.orthodontic_details_tab.openbit_ant%TYPE,
                                 p_openbit_post                    IN  APP.orthodontic_details_tab.openbit_post%TYPE,
                                 p_openbit_late                    IN  APP.orthodontic_details_tab.openbit_late%TYPE,
                                 p_cont_point_disp                 IN  APP.orthodontic_details_tab.cont_point_disp%TYPE,
                                 p_overbit                         IN  APP.orthodontic_details_tab.overbit_deep%TYPE,
                                 p_overbit_pata                    IN  APP.orthodontic_details_tab.overbit_pata%TYPE,
                                 p_overbit_ging                    IN  APP.orthodontic_details_tab.overbit_ging%TYPE,
                                 p_hypo_quad1                      IN  APP.orthodontic_details_tab.hypo_quad1%TYPE,
                                 p_hypo_quad2                      IN  APP.orthodontic_details_tab.hypo_quad2%TYPE,
                                 p_hypo_quad3                      IN  APP.orthodontic_details_tab.hypo_quad3%TYPE,
                                 p_hypo_quad4                      IN  APP.orthodontic_details_tab.hypo_quad4%TYPE,
                                 p_others_impeded                  IN  APP.orthodontic_details_tab.others_impeded%TYPE,
                                 p_others_impact                   IN  APP.orthodontic_details_tab.others_impact%TYPE,
                                 p_others_submerg                  IN  APP.orthodontic_details_tab.others_submerg%TYPE,
                                 p_others_supernum                 IN  APP.orthodontic_details_tab.others_supernum%TYPE,
                                 p_others_retaine                  IN  APP.orthodontic_details_tab.others_retaine%TYPE,
                                 p_others_ectopic                  IN  APP.orthodontic_details_tab.others_ectopic%TYPE,
                                 p_others_cranio                   IN  APP.orthodontic_details_tab.others_cranio%TYPE,
                                 p_ac_marks                        IN  APP.orthodontic_details_tab.ac_marks%TYPE,
                                 p_crossbite_ant_mm	               IN  APP.orthodontic_details_tab.crossbite_ant_mm%TYPE,
                                 p_crossbite_prst_mm	             IN  APP.orthodontic_details_tab.crossbite_prst_mm%TYPE,
	                               p_crossbite_betw_mm	             IN  APP.orthodontic_details_tab.crossbite_betw_mm%TYPE,
                                 p_cont_point_disp_mm	             IN  APP.orthodontic_details_tab.cont_point_disp_mm%TYPE
							                );
                           
--------********SAVE ICD/DIAGNOSYS DETAILS*********

 PROCEDURE SAVE_DIAGNOSYS_DETAILS (	
                                    V_XML_SEQ_ID             IN  PAT_XML_UPLD_DTA.XML_SEQ_ID%TYPE ,					                   
					                          v_pat_ath_seq_id         IN  APP.diagnosys_details.pat_auth_seq_id%TYPE,						                          
						                        v_diag_code_prim         IN  APP.diagnosys_details.diagnosys_code%TYPE,
                                    v_priamry_yn             IN  APP.diagnosys_details.Primary_Ailment_Yn%TYPE,							               
						                        v_duration_ailment       IN  APP.pat_authorization_details.dur_ailment%TYPE,
					                          v_duration_flag          IN  APP.pat_authorization_details.duration_flag%TYPE
					                         );  
 
------*********SAVE ACTIVITY DETAILS INFORMATION**********---------------                               

PROCEDURE  SAVE_ACTIVITY_DETAILS  
                                (
                                V_XML_SEQ_ID              IN  APP.PAT_XML_UPLD_DTA.XML_SEQ_ID%TYPE,                                   
                                v_pat_ath_seq_id          IN  APP.pat_activity_details.pat_auth_seq_id%TYPE,  
                                v_activity_type           IN  pat_activity_details.activity_type%TYPE,
                               	v_service_type            IN  pat_activity_details.service_type%TYPE,
            	                  v_start_date              IN  VARCHAR2,
            	                  v_modifier                IN  pat_activity_details.modifier%TYPE,
            	                  v_internal_code           IN  pat_activity_details.internal_code%TYPE,
                                v_unit_type               IN  pat_activity_details.unit_type%TYPE,
	                              v_duration_days           IN  pat_activity_details.posology_duration%TYPE,
                                v_quantity                IN  pat_activity_details.quantity%TYPE,
                              	v_posology                IN  pat_activity_details.posology%TYPE,
                               	v_unit_price              IN  pat_activity_details.unit_price%type,
                                v_discount_amount         IN  pat_activity_details.discount_amount%TYPE,
                                v_allow_yn                IN  pat_activity_details.allow_yn%TYPE,
                                v_benefitType             IN   APP.pat_authorization_details.benifit_type%TYPE,
                                v_clinician_id            IN   APP.pat_authorization_details.clinician_id%TYPE,
                                v_tpa_enroll_id                   IN     APP.pat_authorization_details.tpa_enrollment_id%TYPE                             
                                 );

----------------------------------------------------------------  
------********INTERNAL CODE VALIDATION*********************

 PROCEDURE  CHECK_INTERNAL_CODE(  
                                  v_pat_ath_seq_id        IN  APP.pat_authorization_details.pat_auth_seq_id%type,
                                  v_tpa_enroll_id         IN   APP.pat_authorization_details.tpa_enrollment_id%TYPE,
                                  V_XML_SEQ_ID            IN  PAT_XML_UPLD_DTA.XML_SEQ_ID%TYPE ,
                                  v_int_code              IN  pat_activity_details.internal_code%TYPE,
                                  v_start_date            IN  VARCHAR2,
                                  v_yn                    OUT  VARCHAR2
                                  ); 
                                  
------******DENTAL VALIDATION*****************

  PROCEDURE CHECK_DENTAL_VALIDATION
                                   (
                                 V_XML_SEQ_ID              IN  app.PAT_XML_UPLD_DTA.XML_SEQ_ID%TYPE ,
                                 p_dento_class_i           IN  APP.orthodontic_details_tab.dento_class_i%TYPE,
                                 p_dento_class_ii          IN  APP.orthodontic_details_tab.dento_class_ii%TYPE,
                                 p_dento_class_ii_text     IN  APP.orthodontic_details_tab.dento_class_ii_text%TYPE,
                                 p_dento_class_iii         IN  APP.orthodontic_details_tab.dento_class_iii%TYPE,
                                 p_dento_class_iii_text    IN  APP.orthodontic_details_tab.dento_class_iii_text%TYPE,
                                 p_skele_class_i           IN  APP.orthodontic_details_tab.skele_class_i%TYPE,
                                 p_skele_class_ii          IN  APP.orthodontic_details_tab.skele_class_ii%TYPE,
                                 p_skele_class_iii         IN  APP.orthodontic_details_tab.skele_class_iii%TYPE,
                                 p_overjet_mm              IN  APP.orthodontic_details_tab.overjet_mm%TYPE,
                                 p_rev_overjet_mm          IN  APP.orthodontic_details_tab.rev_overjet_mm%TYPE,
                                 p_rev_overjet_yn          IN  APP.orthodontic_details_tab.rev_overjet_yn%TYPE,
                                 p_crossbite_ant           IN  APP.orthodontic_details_tab.crossbite_ant%TYPE,
                                 p_crossbite_post          IN  APP.orthodontic_details_tab.crossbite_post%TYPE,
                                 p_crossbite_betw          IN  APP.orthodontic_details_tab.crossbite_betw%TYPE,
                                 p_openbit_ant             IN  APP.orthodontic_details_tab.openbit_ant%TYPE,
                                 p_openbit_post            IN  APP.orthodontic_details_tab.openbit_post%TYPE,
                                 p_openbit_late            IN  APP.orthodontic_details_tab.openbit_late%TYPE,
                                 p_cont_point_disp         IN  APP.orthodontic_details_tab.cont_point_disp%TYPE,
                                 p_overbit                 IN  APP.orthodontic_details_tab.overbit_deep%TYPE,
                                 p_overbit_pata            IN  APP.orthodontic_details_tab.overbit_pata%TYPE,
                                 p_overbit_ging            IN  APP.orthodontic_details_tab.overbit_ging%TYPE,
                                 p_hypo_quad1              IN  APP.orthodontic_details_tab.hypo_quad1%TYPE,
                                 p_hypo_quad2              IN  APP.orthodontic_details_tab.hypo_quad2%TYPE,
                                 p_hypo_quad3              IN  APP.orthodontic_details_tab.hypo_quad3%TYPE,
                                 p_hypo_quad4              IN  APP.orthodontic_details_tab.hypo_quad4%TYPE,
                                 p_others_impeded          IN  APP.orthodontic_details_tab.others_impeded%TYPE,
                                 p_others_impact           IN  APP.orthodontic_details_tab.others_impact%TYPE,
                                 p_others_submerg          IN  APP.orthodontic_details_tab.others_submerg%TYPE,
                                 p_others_supernum         IN  APP.orthodontic_details_tab.others_supernum%TYPE,
                                 p_others_retaine          IN  APP.orthodontic_details_tab.others_retaine%TYPE,
                                 p_others_ectopic          IN  APP.orthodontic_details_tab.others_ectopic%TYPE,
                                 p_others_cranio           IN  APP.orthodontic_details_tab.others_cranio%TYPE,
                                 p_ac_marks                IN  APP.orthodontic_details_tab.ac_marks%TYPE,
                                 p_crossbite_ant_mm	       IN  APP.orthodontic_details_tab.crossbite_ant_mm%TYPE,
                                 p_crossbite_prst_mm	     IN  APP.orthodontic_details_tab.crossbite_prst_mm%TYPE,
                                 p_crossbite_betw_mm	     IN  APP.orthodontic_details_tab.crossbite_betw_mm%TYPE,
                                 p_cont_point_disp_mm	     IN  APP.orthodontic_details_tab.cont_point_disp_mm%TYPE
                               ); 


---------------***********DUPLICATE ICD CODE VALIDATION*******------

PROCEDURE  CHECK_ICD_CODE_DUP (
                                 V_XML_SEQ_ID              IN  APP.PAT_XML_UPLD_DTA.XML_SEQ_ID%TYPE, 
                                 v_pat_ath_seq_id          IN  APP.pat_authorization_details.pat_auth_seq_id%TYPE,
                                 v_diag_code_scnd          IN  APP.diagnosys_details.diagnosys_code%TYPE
                               ); 
                               
-----*******CHECK DENTAL PRIMARY ICD FOR BENEFIT TYPE  DENTAL**********---------------------
PROCEDURE  CHECK_DNTL_ICD_PRIM(
                               v_xml_seq_id                 IN  PAT_XML_UPLD_DTA.XML_SEQ_ID%TYPE,
                               v_pat_ath_seq_id             IN  APP.diagnosys_details.pat_auth_seq_id%TYPE,	
                               v_diag_code_prim             IN  APP.diagnosys_details.diagnosys_code%TYPE,
                               v_benefitType                IN   APP.pat_authorization_details.benifit_type%TYPE
                               );
                               
------**********DENTAL TOOTH NO VALIDATION*****------------

PROCEDURE     CHECK_DNTL_YN(
                            v_xml_seq_id                      IN     PAT_XML_UPLD_DTA.XML_SEQ_ID%TYPE,
                            v_tooth_tag                       IN     VARCHAR2,
                            v_tooth_name                      IN     VARCHAR2,
                            v_tooth_no                        IN     VARCHAR2,
                            v_yn                              OUT    VARCHAR2
                           ) ;  
                           
------**********DENTAL TOOTH NO DUPLICATE*****------------

PROCEDURE     CHECK_TOOTHNO_DUP(
                              v_xml_seq_id                      IN     PAT_XML_UPLD_DTA.XML_SEQ_ID%TYPE,
                              v_tooth_tag                       IN     VARCHAR2,
                              v_tooth_name                      IN     VARCHAR2,
                              v_tooth_no                        IN     VARCHAR2
                               ) ;  
----------****************FOR ACTIVITY TYPE INTERNAL CODE VALID OR NOT********------
PROCEDURE  CHK_ACT_INT_CODE_VALID(
                                   v_xml_seq_id                      IN     PAT_XML_UPLD_DTA.XML_SEQ_ID%TYPE,
                                   v_tpa_enroll_id                   IN     APP.pat_authorization_details.tpa_enrollment_id%TYPE,
                                   v_activity_type                   IN     pat_activity_details.activity_type%TYPE,
                                   v_internal_code                   IN     pat_activity_details.internal_code%TYPE,
                                   v_start_date                      IN     VARCHAR2
                                  );                                                            
                                                                                                                  
------********PREAUTH ACTIVITY AND PREAUTH DETAILS*********------
PROCEDURE    SELECT_PAT_AUTH(
                              v_pre_auth_number                  IN    APP.pat_authorization_details.PRE_AUTH_NUMBER%TYPE,
                              v_auth_result_set                  OUT   SYS_REFCURSOR ,
                              v_activity_result_set              OUT   SYS_REFCURSOR ---,
                         ---- v_observ_result_set                OUT   SYS_REFCURSOR ,
                             );
                                                                                              							               							                               
------------===================================================      
PROCEDURE SAVE_PREAUTH_DOCUMENT (v_pre_Auth_number IN VARCHAR2,
                                 v_doc_val_null    IN VARCHAR2,
                                 v_document        IN BLOB,
                                 v_row_processed   OUT NUMBER);
--=====================================================================                                                                                     
               
END ALAHLI_PAT_DATA_UPLD_PKG;

/

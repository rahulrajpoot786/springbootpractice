--------------------------------------------------------
--  DDL for Synonymn CLM_HOSPITAL_DELETE_BKP
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."CLM_HOSPITAL_DELETE_BKP" FOR "APP"."CLM_HOSPITAL_DELETE_BKP";

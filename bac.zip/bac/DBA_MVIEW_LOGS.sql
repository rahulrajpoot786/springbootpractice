--------------------------------------------------------
--  DDL for Synonymn DBA_MVIEW_LOGS
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."DBA_MVIEW_LOGS" FOR "SYS"."DBA_MVIEW_LOGS";

--------------------------------------------------------
--  DDL for Synonymn IDX_CLMGENERALDET_PARENTCLMSEQ
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."IDX_CLMGENERALDET_PARENTCLMSEQ" FOR "APP"."IDX_CLMGENERALDET_PARENTCLMSEQ";

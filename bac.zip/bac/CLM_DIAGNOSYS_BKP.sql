--------------------------------------------------------
--  DDL for Synonymn CLM_DIAGNOSYS_BKP
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."CLM_DIAGNOSYS_BKP" FOR "APP"."CLM_DIAGNOSYS_BKP";

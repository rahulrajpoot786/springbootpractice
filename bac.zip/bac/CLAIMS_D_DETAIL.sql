--------------------------------------------------------
--  DDL for Synonymn CLAIMS_D_DETAIL
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."CLAIMS_D_DETAIL" FOR "APP"."CLAIMS_D_DETAIL";

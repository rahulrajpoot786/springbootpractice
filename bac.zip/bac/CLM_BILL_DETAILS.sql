--------------------------------------------------------
--  DDL for Synonymn CLM_BILL_DETAILS
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."CLM_BILL_DETAILS" FOR "APP"."CLM_BILL_DETAILS";

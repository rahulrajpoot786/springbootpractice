--------------------------------------------------------
--  DDL for Package Body CLAIMS_APPROVAL_PKG
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "VENUBABU"."CLAIMS_APPROVAL_PKG" AS
/*
 Package : claims_approval_pkg
 Author  : Ravi Kumar
 Date    : 09-SEP-2013
 Purpose : To Provide the claims and pre_auth approval For Insurance Company
 Remarks : Insurance company holds the Final approval of a claim/preauth bulk or Unique
*/
---=============================================================================================
/*a.  Claim Status
b.  Claim Window period
c.  Claim number
d.  Location
e.  Policy number
f.  Enrolment id.
g.  Insurer RO/DO
h.  Claim Recommended Amount with the option to search more than, equal to, less than value.*/
---=====================================================================================================
 PROCEDURE save_ins_approval_limit(
--preauth
          v_prod_policy_seq_id      IN tpa_ins_prod_policy.prod_policy_seq_id%TYPE,
          v_ins_pat_apr_rej_yn      IN tpa_ins_prod_policy.ins_pat_apr_rej_yn%TYPE,
          v_ins_pat_allow_yn        IN tpa_ins_prod_policy.ins_pat_allow_yn%TYPE,
          v_ins_pat_operator        IN tpa_ins_prod_policy.ins_pat_operator%TYPE,
          v_ins_pat_apr_limit       IN tpa_ins_prod_policy.ins_pat_apr_limit%TYPE,
          v_ins_pat_rej_allow_yn    IN tpa_ins_prod_policy.ins_pat_rej_allow_yn%TYPE,
          v_pat_mail_flag           IN tpa_ins_prod_policy.pat_mail_flag%TYPE,
          v_pat_mail_freq_hours     IN tpa_ins_prod_policy.pat_mail_freq_hours%TYPE,
          v_pat_mail_freq_mins      IN tpa_ins_prod_policy.pat_mail_freq_mins%TYPE,
--cash less claims                  
          v_ins_clm_cl_apr_rej_yn   IN tpa_ins_prod_policy.ins_clm_cl_apr_rej_yn%TYPE,
          v_ins_clm_cl_allow_yn     IN tpa_ins_prod_policy.ins_clm_cl_allow_yn%TYPE,
          v_ins_clm_cl_operator     IN tpa_ins_prod_policy.ins_clm_cl_operator%TYPE,
          v_ins_clm_cl_apr_limit    IN tpa_ins_prod_policy.ins_clm_cl_apr_limit%TYPE,
          v_ins_clm_cl_rej_allow_yn IN tpa_ins_prod_policy.ins_clm_cl_rej_allow_yn%TYPE,
          v_clm_cl_mail_flag        IN tpa_ins_prod_policy.clm_cl_mail_flag%TYPE,
--member claim
          v_ins_clm_cm_apr_rej_yn   IN tpa_ins_prod_policy.ins_clm_cm_apr_rej_yn%TYPE,
          v_ins_clm_cm_allow_yn     IN tpa_ins_prod_policy.ins_clm_cm_allow_yn%TYPE,
          v_ins_clm_cm_operator     IN tpa_ins_prod_policy.ins_clm_cm_operator%TYPE,
          v_ins_clm_cm_apr_limit    IN tpa_ins_prod_policy.ins_clm_cm_apr_limit%TYPE,
          v_ins_clm_cm_rej_allow_yn IN tpa_ins_prod_policy.ins_clm_cm_rej_allow_yn%TYPE,
          v_clm_cm_mail_flag        IN tpa_ins_prod_policy.clm_cm_mail_flag%TYPE,
          v_clm_mail_freq_hours     IN tpa_ins_prod_policy.clm_mail_freq_hours%TYPE,
          v_clm_mail_freq_mins      IN tpa_ins_prod_policy.clm_mail_freq_mins%TYPE,
          v_added_by                IN tpa_ins_prod_policy.added_by%TYPE,
          v_rows_processed          OUT NUMBER) IS
          
          
          v_prod_policy_seq_ids varchar2(32767);
BEGIN


  if (v_ins_pat_allow_yn = 'Y' AND NVL(v_ins_pat_apr_limit, 0) = 0) THEN
    RAISE_APPLICATION_ERROR(-20896,
                            'Please Enter the Preauth/Claims Approval Limit');
  end if;

  IF ((v_ins_clm_cl_allow_yn = 'Y' AND NVL(v_ins_clm_cl_apr_limit, 0) = 0) OR
     (v_ins_clm_cm_allow_yn = 'Y' AND NVL(v_ins_clm_cm_apr_limit, 0) = 0)) THEN
    RAISE_APPLICATION_ERROR(-20896,
                            'Please Enter the Preauth/Claims Approval Limit');
  END IF;

  UPDATE tpa_ins_prod_policy k
     SET ins_pat_apr_rej_yn   = v_ins_pat_apr_rej_yn,
         ins_pat_allow_yn     = v_ins_pat_allow_yn,
         ins_pat_operator     = v_ins_pat_operator,
         ins_pat_apr_limit    = v_ins_pat_apr_limit,
         ins_pat_rej_allow_yn = v_ins_pat_rej_allow_yn,
         pat_mail_flag        = v_pat_mail_flag,
         pat_mail_freq_hours  = v_pat_mail_freq_hours,
         pat_mail_freq_mins   = v_pat_mail_freq_mins,
         --cash less claims                  
         ins_clm_cl_apr_rej_yn   = v_ins_clm_cl_apr_rej_yn,
         ins_clm_cl_allow_yn     = v_ins_clm_cl_allow_yn,
         ins_clm_cl_operator     = v_ins_clm_cl_operator,
         ins_clm_cl_apr_limit    = v_ins_clm_cl_apr_limit,
         ins_clm_cl_rej_allow_yn = v_ins_clm_cl_rej_allow_yn,
         clm_cl_mail_flag        = v_clm_cl_mail_flag,
         --member claim
         ins_clm_cm_apr_rej_yn   = v_ins_clm_cm_apr_rej_yn,
         ins_clm_cm_allow_yn     = v_ins_clm_cm_allow_yn,
         ins_clm_cm_operator     = v_ins_clm_cm_operator,
         ins_clm_cm_apr_limit    = v_ins_clm_cm_apr_limit,
         ins_clm_cm_rej_allow_yn = v_ins_clm_cm_rej_allow_yn,
         clm_cm_mail_flag        = v_clm_cm_mail_flag,
         clm_mail_freq_hours     = v_clm_mail_freq_hours,
         clm_mail_freq_mins      = v_clm_mail_freq_mins
   WHERE k.prod_policy_seq_id = v_prod_policy_seq_id;

   /*
   if sql%rowcount > 0  then 
  
      SELECT   '|'||listagg(c.prod_policy_seq_id,'|') WITHIN GROUP (ORDER BY a.added_date desc)||'|'
          into v_prod_policy_seq_ids
          FROM tpa_enr_policy a JOIN tpa_group_registration b ON (a.group_reg_seq_id = b.group_reg_seq_id)
          JOIN tpa_ins_prod_policy c ON (a.policy_seq_id = c.policy_seq_id)
          join tpa_ins_prod_policy d ON (a.product_seq_id = d.product_seq_id )
          WHERE d.prod_policy_seq_id = v_prod_policy_seq_id
          AND a.enrol_type_id = 'COR' AND a.deleted_yn = 'N' AND a.policy_status_general_type_id != 'POC'
         and a.den_sync_date is not null;

    end if;
         
    product_admin_pkg.synchronize_rule(v_prod_policy_seq_ids,v_prod_policy_seq_id,
    'DEN',v_rows_processed);
      */

  v_rows_processed := sql%rowcount;
  COMMIT;
END save_ins_approval_limit;
---=====================================================================================================
 PROCEDURE select_ins_approval_limit(v_prod_policy_seq_id     IN tpa_ins_prod_policy.prod_policy_seq_id%TYPE,
                                     v_result_set             OUT SYS_REFCURSOR) IS
  BEGIN
      OPEN v_result_set FOR
 SELECT prod_policy_seq_id,
--preauth
                  a.ins_pat_apr_rej_yn,
                  a.ins_pat_allow_yn,
                  a.ins_pat_operator,
                  a.ins_pat_apr_limit,
                  a.ins_pat_rej_allow_yn,
                  nvl(a.pat_mail_flag,'MAIL') pat_mail_flag,
                  a.pat_mail_freq_hours,
                  a.pat_mail_freq_mins,
--cash less claims                  
                  a.ins_clm_cl_apr_rej_yn,
                  a.ins_clm_cl_allow_yn,
                  a.ins_clm_cl_operator,
                  a.ins_clm_cl_apr_limit,
                  a.ins_clm_cl_rej_allow_yn,
                  nvl(a.clm_cl_mail_flag,'MAIL') clm_cl_mail_flag,
--member claim
                  a.ins_clm_cm_apr_rej_yn,
                  a.ins_clm_cm_allow_yn,
                  a.ins_clm_cm_operator,
                  a.ins_clm_cm_apr_limit,
                  a.ins_clm_cm_rej_allow_yn,
                  nvL(a.clm_cm_mail_flag,'MAIL') clm_cm_mail_flag,
                  a.clm_mail_freq_hours,
                  a.clm_mail_freq_mins
                  
                       FROM tpa_ins_prod_policy a
           WHERE prod_policy_seq_id = v_prod_policy_seq_id;

   END select_ins_approval_limit;
---========================================================================================================
 PROCEDURE select_claims_list (
    v_user_seq_id                    IN  tpa_user_contacts.contact_seq_id%TYPE,
    v_tpa_enrollment_id              IN  clm_enroll_details.tpa_enrollment_id%TYPE,
    v_policy_number                  IN  clm_enroll_details.policy_number%TYPE,
    v_claim_number                   IN  clm_general_details.claim_number%TYPE,
    v_from_date                      IN  VARCHAR2,
    v_to_date                        IN  VARCHAR2,
    v_clm_status_general_type_id     IN  clm_enroll_details.clm_status_general_type_id%TYPE,
    v_tpa_office_seq_id              IN  tpa_office_info.tpa_office_seq_id%TYPE ,
    v_ro_do_code                     IN  tpa_ins_info.ins_comp_code_number%TYPE,
    v_operator                       IN  tpa_ins_prod_policy.ins_pat_operator%TYPE,
    v_recomm_amt                     IN  clm_general_details.requested_amount%TYPE,
    v_clm_status_id                  IN  clm_enroll_details.clm_status_general_type_id%TYPE,
    v_sort_var                       IN  VARCHAR2,
    v_sort_order                     IN  VARCHAR2,
    v_start_num                      IN  NUMBER ,
    v_end_num                        IN  NUMBER ,
    result_set                       OUT SYS_REFCURSOR )
  IS

    TYPE bind_tab_type IS TABLE OF VARCHAR2(250) INDEX BY BINARY_INTEGER ;
    bind_tab                             bind_tab_type;
    i                                    NUMBER(2) := 0;
    v_where                              VARCHAR2(2000);
    v_sql_str                            VARCHAR2(4000);
    v_cnt                                NUMBER(12);
    v_ins_seq_id                         tpa_ins_info.ins_seq_id%TYPE;
    v_oper_val                           tpa_ins_prod_policy.ins_pat_operator%TYPE;
    v_ins_ro_seq_id                      tpa_ins_info.ins_seq_id%TYPE;
    v_user_ins_seq_id                    tpa_ins_info.ins_seq_id%TYPE;
    v_ins_code                           tpa_ins_info.abbrevation_code%TYPE;
  BEGIN
    v_sql_str :=
       'SELECT
       A.claim_number ,
       B.tpa_enrollment_id ,
       B.claimant_name,
       NVL(A.requested_amount,0) requested_amount,
       NVL(A.total_app_amount,0) total_app_amount,
      B.decision_date recommend_date,
       H.hosp_name ,
       A.date_of_admission,
       G.description claim_status,
       (CASE WHEN cii.clm_ins_status =''INP'' then ''Y'' ELSE ''N'' END) as allow_yn,
       A.claim_seq_id,
       B.clm_enroll_detail_seq_id

      FROM clm_general_details A
      JOIN clm_enroll_details B ON (A.claim_seq_id = b.claim_seq_id  and A.completed_yn=''N'')
      left outer join clm_ins_intimation_details cii on (b.claim_seq_id=cii.claim_seq_id)
      JOIN clm_inward C ON ( a.claims_inward_seq_id = c.claims_inward_seq_id)
      LEFT OUTER JOIN clm_hospital_association H ON (A.claim_seq_id = H.claim_seq_id)
      LEFT OUTER JOIN tpa_enr_policy I ON ( B.policy_seq_id = I.policy_seq_id)
      LEFT OUTER JOIN tpa_general_code G ON (B.clm_status_general_type_id=G.general_type_id) ';

    IF v_tpa_enrollment_id IS NOT NULL THEN
       v_where := v_where   ||' AND B.tpa_enrollment_id = :v_tpa_enrollment_id';
       i := i+1;
       bind_tab(i) := UPPER(v_tpa_enrollment_id);
    END IF;

    IF v_policy_number IS NOT NULL THEN
       v_where := v_where   ||' AND B.policy_number  = :v_policy_number';
       i := i+1;
       bind_tab(i) := UPPER(v_policy_number);
    END IF;

    IF v_claim_number IS NOT NULL THEN
      v_where := v_where   ||' AND A.claim_number = :v_claim_number';
       i := i+1;
       bind_tab(i) := UPPER(v_claim_number);
    END IF;

    IF v_from_date IS NOT NULL THEN
       v_where := v_where   ||' AND B.decision_date >= :v_from_date';

       i := i+1;
       bind_tab(i) := to_date(v_from_date,'dd/mm/yyyy');
    END IF;

    IF v_to_date IS NOT NULL THEN
       v_where := v_where   ||' AND B.decision_date <= :v_to_date';

       i := i+1;
       bind_tab(i) := to_date(v_to_date,'dd/mm/yyyy')+1;
    END IF;

    IF v_clm_status_general_type_id IS NOT NULL THEN
       v_where := v_where   ||' AND cii.clm_ins_status  = (CASE  WHEN :v_clm_status_general_type_id=''INP'' THEN ''INP''
                                                                 WHEN :v_clm_status_general_type_id=''TRAD'' AND B.clm_status_general_type_id=''APR'' THEN ''APR''
                                                                 WHEN :v_clm_status_general_type_id=''TRAD'' AND B.clm_status_general_type_id=''REJ'' THEN ''REJ''
                                                                 WHEN :v_clm_status_general_type_id=''TRND'' THEN ''REQ'' END)';
       i := i+1;
       bind_tab(i) :=  v_clm_status_general_type_id ;
       i := i+1;
       bind_tab(i) :=  v_clm_status_general_type_id ;
       i := i+1;
       bind_tab(i) :=  v_clm_status_general_type_id ;
       i := i+1;
       bind_tab(i) :=  v_clm_status_general_type_id ;
    END IF;

    IF v_tpa_office_seq_id IS NOT NULL THEN
       v_where := v_where   ||' AND c.tpa_office_seq_id = :v_tpa_office_seq_id ';
       i := i+1;
       bind_tab(i) := v_tpa_office_seq_id;
    END IF;
    
    IF v_clm_status_id IS NOT NULL THEN
       v_where := v_where   ||' AND b.clm_status_general_type_id = :v_clm_status_id ';
       i := i+1;
       bind_tab(i) := v_clm_status_id;
    END IF;    

    IF v_ro_do_code IS NOT NULL THEN

       SELECT COUNT(1) INTO v_cnt FROM tpa_ins_info where ins_comp_code_number=upper(v_ro_do_code);

        IF v_cnt=0 THEN
         SELECT u.ins_seq_id INTO v_ins_seq_id FROM tpa_user_contacts u WHERE u.contact_seq_id = v_user_seq_id;
        ELSE
          SELECT u.ins_seq_id INTO v_user_ins_seq_id FROM tpa_user_contacts u WHERE u.contact_seq_id = v_user_seq_id;
          SELECT abbrevation_code INTO v_ins_code FROM tpa_ins_info u WHERE u.ins_seq_id=v_user_ins_seq_id;
          SELECT u.ins_seq_id INTO v_ins_ro_seq_id FROM tpa_ins_info u WHERE ins_comp_code_number=upper(v_ro_do_code) and u.abbrevation_code=v_ins_code;
           v_ins_seq_id := greatest(v_user_ins_seq_id,v_ins_ro_seq_id);

       v_where := v_where ||' AND i.ins_seq_id IN (SELECT ins_seq_id FROM tpa_ins_info
                                            START WITH ins_seq_id  = :v_ins_seq_id
                                               CONNECT BY PRIOR ins_seq_id  = ins_parent_seq_id)';
       i := i+1;
       bind_tab(i) := v_ins_seq_id;


        END IF;

    ELSIF v_ro_do_code IS NULL THEN
        SELECT u.ins_seq_id INTO v_ins_seq_id FROM tpa_user_contacts u WHERE u.contact_seq_id = v_user_seq_id;

        v_where := v_where ||' AND i.ins_seq_id IN (SELECT ins_seq_id FROM tpa_ins_info
                                            START WITH ins_seq_id  = :v_ins_seq_id
                                               CONNECT BY PRIOR ins_seq_id  = ins_parent_seq_id)';
       i := i+1;
       bind_tab(i) := v_ins_seq_id;
    END IF;

    IF v_recomm_amt IS NOT NULL AND v_operator IS NOT NULL THEN
      SELECT DECODE(v_operator,'EQ','=','LT','<=','GT','>=') INTO v_oper_val FROM dual;

       v_where := v_where   ||' AND A.total_app_amount '||v_oper_val||':v_recomm_amt';
       i := i+1;
       bind_tab(i) := v_recomm_amt;
    END IF;

    IF v_where IS NOT NULL THEN
      v_where   := ' WHERE '|| SUBSTR(v_where,5);
    END IF;
    v_sql_str := v_sql_str ||v_where;

    v_sql_str := 'SELECT * FROM
          (SELECT A.*, DENSE_RANK() OVER (ORDER BY '||v_sort_var||' '||v_sort_order||',ROWNUM)
          Q FROM (' ||v_sql_str|| ') A ) WHERE Q>= :v_start_num  AND Q<=  :v_end_num ';

    IF bind_tab.FIRST IS NOT NULL THEN
       CASE bind_tab.COUNT
         WHEN 5  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5), v_start_num , v_end_num ;
         WHEN 6  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6), v_start_num , v_end_num ;
         WHEN 7  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6),bind_tab(7), v_start_num , v_end_num ;
         WHEN 8  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6),bind_tab(7),bind_tab(8), v_start_num , v_end_num ;
         WHEN 9  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6),bind_tab(7),bind_tab(8),bind_tab(9), v_start_num , v_end_num ;
         WHEN 10  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6),bind_tab(7),bind_tab(8),bind_tab(9),bind_tab(10), v_start_num , v_end_num ;
         WHEN 11  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6),bind_tab(7),bind_tab(8),bind_tab(9),bind_tab(10),bind_tab(11), v_start_num , v_end_num ;
         WHEN 12  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6),bind_tab(7),bind_tab(8),bind_tab(9),bind_tab(10),bind_tab(11),bind_tab(12), v_start_num , v_end_num ;
         WHEN 13  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6),bind_tab(7),bind_tab(8),bind_tab(9),bind_tab(10),bind_tab(11),bind_tab(12),bind_tab(13), v_start_num , v_end_num ;
         WHEN 14  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6),bind_tab(7),bind_tab(8),bind_tab(9),bind_tab(10),bind_tab(11),bind_tab(12),bind_tab(13),bind_tab(14), v_start_num , v_end_num ;
         WHEN 15  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6),bind_tab(7),bind_tab(8),bind_tab(9),bind_tab(10),bind_tab(11),bind_tab(12),bind_tab(13),bind_tab(14),bind_tab(15), v_start_num , v_end_num ;
         WHEN 16  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6),bind_tab(7),bind_tab(8),bind_tab(9),bind_tab(10),bind_tab(11),bind_tab(12),bind_tab(13),bind_tab(14),bind_tab(15),bind_tab(16), v_start_num , v_end_num ;
       END CASE;
     END IF;

  END select_claims_list;
--===================================================================================================================
---================================================================================================
PROCEDURE select_claims_web (v_claim_seq_id   IN clm_general_details.claim_number%TYPE,
                             v_claim_xml      OUT XMLTYPE,
                             v_ins_status     OUT clm_ins_intimation_details.clm_ins_status%TYPE ,
                             v_ins_remarks    out clm_ins_intimation_details.clm_ins_remarks%type) IS


 v_doc              dbms_xmldom.DOMDocument;
 v_main_node        dbms_xmldom.DOMNode;
 v_clm_node         dbms_xmldom.DOMNode;
 v_ins_node         dbms_xmldom.DOMNode;
 v_root_node        dbms_xmldom.DOMNode;
 v_chld_node        dbms_xmldom.DOMNode;
 v_chld_node2       dbms_xmldom.DOMNode;
 v_chld_node3       dbms_xmldom.DOMNode;
 v_node             dbms_xmldom.domnode;
 v_elem             dbms_xmldom.DOMElement;
 v_out_xml          sys.xmltype;

 v_clob            CLOB;
/* i                 PLS_INTEGER:=1;
 j                 PLS_INTEGER:=1;
 p                 PLS_INTEGER:=1;
 t                 PLS_INTEGER:=1;
 v_room_col        VARCHAR2(20);
 v_room_charge     VARCHAR2(20);*/

/*  TYPE tab IS VARRAY(5) OF VARCHAR2(10);
  rec_tab      tab:=tab('ROOM','PROF','OTHER','NA');*/

   v_buff_app_amt                           buffer_header.buff_app_amt%type:=pre_auth_pkg.get_buff_apr_amt(v_claim_seq_id,'CLM','CORP_BUFF') ;
   v_med_buff_app_amt                       buffer_header.buff_app_amt%type:=pre_auth_pkg.get_buff_apr_amt(v_claim_seq_id,'CLM','MED_BUFF') ;  
   v_crit_buff_app_amt                      buffer_header.buff_app_amt%type:=pre_auth_pkg.get_buff_apr_amt(v_claim_seq_id,'CLM','CRIT_BUFF') ;
   v_crit_corp_buff_app_amt                 buffer_header.buff_app_amt%type:=pre_auth_pkg.get_buff_apr_amt(v_claim_seq_id,'CLM','CRIT_CORP_BUFF') ;
   v_crit_med_buff_app_amt                  buffer_header.buff_app_amt%type:=pre_auth_pkg.get_buff_apr_amt(v_claim_seq_id,'CLM','CRIT_MED_BUFF') ;
  
 CURSOR cur_clm IS
 SELECT   cg.claim_seq_id,
          cg.claim_number claim_no,
          grp.insured_name proposer_name,
          ce.claimant_name patient_name,
          ce.employee_no employee_customer_id,
          ce.tpa_enrollment_id tpa_id,
          round(ce.mem_age) patient_age,
          app.account_info_pkg.get_gen_desc(mem.relship_type_id,'R') Relation,
          app.account_info_pkg.get_gen_desc(mem.gender_general_type_id,'G') Gender,
          pol.policy_number policy_no,
          to_char(pol.effective_from_date,'DD-MON-YYYY')  policy_form,
          to_char(pol.effective_to_date,'DD-MON-YYYY')    policy_upto,
          tgr.group_name||'--'||tip.product_name  product_name,
          q.sum_insured,
         -- nvl(q.bonus,0) bonus,
          --mem.mem_tot_bonus as bonus,-- taken as cumulative bonus
          CASE WHEN POL.POLICY_SUB_GENERAL_TYPE_ID ='PFL' THEN grp.FLOATER_TOT_BONUS ELSE mem.mem_tot_bonus END as bonus,
          ma.address_1||' '||ma.address_2||' '||ma.address_3 address,
          to_char(tcl.call_recorded_date,'DD-MON-YYYY') intimation_date,
          to_char(v.rcvd_date,'DD-MON-YYYY') date_of_doc_rec,
          to_char(cg.date_of_admission,'DD-MON-YYYY') loss_date,
          nvl(thi.hosp_name,ha.hosp_name) hospital_name,
          NVL(app.account_info_pkg.get_gen_desc(tha.city_type_id,'CT') , ha.city_name) hospital_city,
          NVL(app.account_info_pkg.get_gen_desc(THA.STATE_TYPE_ID,'S'), ha.state_name) hospital_state,
          NVL(THA.PIN_CODE ,ha.pin_code) as hospital_pincode,
          substr(REPLACE(REPLACE(al.provisional_diagnosis,chr(13),''),chr(10),' '),1,500) diagnosis,
          f_icd_code_desc(cg.claim_seq_id,'IC','IC1') diagnosis_code_level_1,
          f_icd_code_desc(cg.claim_seq_id,'IC','IC2') diagnosis_code_level_2,
          f_icd_code_desc(cg.claim_seq_id,'IC','ID1') diagnosis_description_level_1,
          f_icd_code_desc(cg.claim_seq_id,'IC','ID2') diagnosis_description_level_2,

          f_icd_code_desc(cg.claim_seq_id,'PC','PC1') procedure_codes_level_1,
          f_icd_code_desc(cg.claim_seq_id,'PC','PC2') procedure_codes_level_2,
          f_icd_code_desc(cg.claim_seq_id,'PC','PD1') procedure_description_level_1,
          f_icd_code_desc(cg.claim_seq_id,'PC','PD2') procedure_description_level_2,

          to_char(cg.date_of_admission,'DD-MON-YYYY') doa,
          to_char(cg.date_of_discharge,'DD-MON-YYYY') dod,

          CASE v.claim_general_type_id WHEN 'CNH' THEN 'CASHLESS' ELSE 'REIMBURSEMENT' END claim_type,
          app.account_info_pkg.get_gen_desc(v.claim_general_type_id,'G') claim_category,
          app.account_info_pkg.get_gen_desc(pol.enrol_type_id,'E') policy_type,
          cg.requested_amount estimate_amt,
          round(nvl(cg.total_app_amount,0)-nvl(cg.serv_tax_calc_amount,0)) claim_amount,

          nvl(round((SELECT SUM(approved_amount)
              FROM ailment_caps x JOIN icd_pcs_detail y ON ( x.icd_pcs_seq_id = y.icd_pcs_seq_id )
              WHERE y.claim_seq_id = cg.claim_seq_id)),0) recommend_amount,
          nvl(cg.co_payment_amount,0)+nvl(cg.co_payment_buffer_amount,0) co_pay_amount,

          nvl(round((SELECT SUM(approved_amount)
              FROM ailment_caps x JOIN icd_pcs_detail y ON ( x.icd_pcs_seq_id = y.icd_pcs_seq_id )
              WHERE y.claim_seq_id = cg.claim_seq_id)),0) AS approved_amount,
          f_rej_amt_rem(cg.claim_seq_id,'AMT') deducted_amount,
          f_rej_amt_rem(cg.claim_seq_id,'REM') deduction_reason,
          '0' compulsary_deduction,
          nvl(cg.serv_tax_calc_amount,'0') service_tax_amount,
          ha.serv_tax_rgn_number service_tax_no,
          nvl(cg.total_app_amount,'0') payble_amount,
          round(nvl(tds.approved_amount-tds.check_amount,'0')) tds_amount,
          round(nvl(tcc.check_amount,'0')) net_payble_amt,
          to_char( CII.CLM_INS_SEND_DATE,'DD-MON-YYYY') recommend_on,
          to_char( ce.decision_date,'DD-MON-YYYY') approved_on,

          CASE v.claim_general_type_id WHEN 'CNH' THEN 0 ELSE round(nvl(nvl(tcc.check_amount,cg.total_app_amount),0)) END pay_to_insured,
          CASE v.claim_general_type_id WHEN 'CNH' THEN round(nvl(nvl(tcc.check_amount,cg.total_app_amount),0)) ELSE 0 END pay_to_hospital,
          v_buff_app_amt Buff_App_Amt,
          v_med_buff_app_amt Med_Buff_App_Amt,
          v_crit_buff_app_amt Crit_Buff_App_Amt,
          v_crit_corp_buff_app_amt Crit_Corp_Buff_App_Amt,
          v_crit_med_buff_app_amt Crit_Med_Buff_App_Amt,
          nvl(nvl(bh.Utilised_Amount,ar.Utilised_Amount),0) AS Utilised_Amount,
          nvl(nvl(bh.Utilised_Med_Amount,ar.Utilised_Med_Amount),0) AS Utilised_Med_Amount,
          nvl(nvl(bh.Utilised_Crit_Amount,ar.Utilised_Crit_Amount),0) AS Utilised_Crit_Amount,
          nvl(nvl(bh.Utilised_Crit_Corp_Amount,ar.Utilised_Crit_Corp_Amount),0) AS Utilised_Crit_Corp_Amount,
          nvl(nvl(bh.Utilised_Crit_Med_Amount,ar.Utilised_Crit_Med_Amount),0) AS Utilised_Crit_Med_Amount,
          to_char(tcc.check_num) cheque_no,
          to_char(tcc.check_date,'DD-MON-YYYY') cheque_date,
          ttk_util_pkg.fn_decrypt(tcp.payee_name)  clm_pay_to_beneficiary_name,
          --fn_sfremarks(cg.claim_seq_id) disc_datails,
          get_srtfall_remarks('CHECKBOX','CLM',CG.CLAIM_SEQ_ID)||case when get_srtfall_remarks('OTHERS','CLM',CG.CLAIM_SEQ_ID) is not null then ' ******* Other Queries: '||get_srtfall_remarks('OTHERS','CLM',CG.CLAIM_SEQ_ID) end AS  disc_datails,
          case when v.claim_general_type_id='CTM' THEN to_char(SED.INTL_SHORTFAL_SNT_DATE,'DD-MON-YYYY') ELSE NULL END AS  insured_disc_date,
          case when v.claim_general_type_id='CTM' THEN to_char(SED.RMDR_REQ_SNT_DATE,'DD-MON-YYYY') ELSE NULL END AS   insured_reminder_date,
          case when v.claim_general_type_id='CTM' THEN to_char(SED.CLSR_NOTICE_SNT_DATE,'DD-MON-YYYY') ELSE NULL END AS  insured_final_reminder_date,
          case when v.claim_general_type_id='CTM' THEN to_char(SF_Responded_Dt,'DD-MON-YYYY') ELSE NULL END AS  insured_reply_recieved_date,
          case when v.claim_general_type_id='CTM' THEN NULL ELSE to_char(SED.INTL_SHORTFAL_SNT_DATE,'DD-MON-YYYY') END AS hospital_disc_date,
          case when v.claim_general_type_id='CTM' THEN NULL ELSE to_char(SED.RMDR_REQ_SNT_DATE,'DD-MON-YYYY') END AS  hospital_reminder_date,
          case when v.claim_general_type_id='CTM' THEN NULL ELSE to_char(SED.CLSR_NOTICE_SNT_DATE,'DD-MON-YYYY') END AS  hospital_final_reminder_date,
          case when v.claim_general_type_id='CTM' THEN NULL ELSE  to_char(SF_Responded_Dt,'DD-MON-YYYY') END AS hospital_reply_recieved_date,
          CASE WHEN tii.Email_Id IS NOT NULL THEN to_char(SED.RMDR_REQ_SNT_DATE,'DD-MON-YYYY') ELSE NULL END  AS insurer_disc_date,
          CASE WHEN tii.Email_Id IS NOT NULL THEN to_char(SED.CLSR_NOTICE_SNT_DATE,'DD-MON-YYYY') ELSE NULL END  AS insurer_reminder_date,
          CASE WHEN tii.Email_Id IS NOT NULL THEN to_char(SED.CLM_CLSR_LETTER_SNT_DATE,'DD-MON-YYYY') ELSE NULL END  AS insurer_final_reminder_date,
          NULL insurer_reply_recieved_date,
          to_char(V.RCVD_DATE,'DD-MON-YYYY') pre_auth_received_on,
          pee.pre_auth_number  pre_auth_letter_no,
          app.account_info_pkg.get_gen_desc(pee.pat_status_general_type_id,'G') pre_auth_status,
          nvl(pgd.total_app_amount,'0') pre_auth_amount,
          to_char(pee.decision_date,'DD-MON-YYYY') pre_auth_approved_on,
          nvl(tfa.float_account_number,'NA') float_no,
          to_char(tfa.effective_date,'DD-MON-YYYY') float_date,
          to_char(tcc.check_date,'DD-MON-YYYY') payment_date,
          '0' agent_code,
          pol.dev_officer_code development_code,
          tii.ins_comp_name  operating_office,
          tii.ins_comp_code_number  operating_code,
          NVL(app.account_info_pkg.get_gen_desc(tas.City_Type_Id,'CT'),TAS.CITY)  ins_city,
          NVL(app.account_info_pkg.get_gen_desc(tas.State_Type_Id,'S'),TAS.STATE)  ins_state,
          tas.pin_code ins_pincode,
          NULL controlling_office,
          tii.ins_comp_name  insurance_company,
          app.account_info_pkg.get_gen_desc(tcp.payee_type,'G') settelement_type,
          to_char(ce.decision_date,'DD-MON-YYYY') settelement_date,
          regexp_replace(au.remarks, '[[:space:]]',' ') as repudiation_rejection_reason,
          app.account_info_pkg.get_gen_desc(ce.clm_status_general_type_id,'G') AS clm_status,
          NULL benefit_type,
          NULL bill_entered_by,
          NULL bill_entry_location,
          NVL2(ha.empanel_number,ha.empanel_number,nvl(thi.empanel_number,'')) hospital_code,
          ce.member_seq_id,
          grp.tpa_enrollment_number enr_num,
          'Bangalore' as premium_zone,
          regexp_replace(au.remarks, '[[:space:]]',' ') claims_remarks,
          CII.clm_ins_remarks,
          CII.clm_ins_status,
          ce.clm_status_general_type_id,
          idd.investigation_id,
          idd.investigated_by,
          idd.investigated_date,
          idd.general_remarks||'--'||idd.invst_remarks as invst_remarks

     FROM clm_general_details cg  --on (bdv.claim_seq_id=cg.claim_seq_id)
          INNER JOIN clm_enroll_details ce on (ce.claim_seq_id=cg.claim_seq_id)
          left outer join clm_ins_intimation_details cii on (cg.claim_seq_id=cii.claim_seq_id)
          INNER JOIN assign_users au ON (au.ASSIGN_USERS_SEQ_ID=cg.last_assign_user_seq_id)
          INNER JOIN tpa_enr_policy pol on (ce.policy_seq_id=pol.policy_seq_id)
          INNER JOIN tpa_enr_policy_member mem on (mem.member_seq_id=ce.member_seq_id)
          INNER JOIN tpa_enr_policy_group grp on (grp.policy_group_seq_id=mem.policy_group_seq_id)
          INNER JOIN tpa_ins_product tip on (tip.product_seq_id=pol.product_seq_id)
          INNER JOIN tpa_enr_balance q on (q.policy_group_seq_id=grp.policy_group_seq_id)
          INNER JOIN tpa_enr_mem_address ma on (ma.enr_address_seq_id=grp.enr_address_seq_id)
          LEFT OUTER JOIN clm_hospital_association ha on (ha.claim_seq_id=cg.claim_seq_id)
          LEFT OUTER JOIN tpa_hosp_info thi on (ha.hosp_seq_id =thi.hosp_seq_id)
          LEFT OUTER JOIN tpa_hosp_address tha on (thi.hosp_seq_id=tha.hosp_seq_id)
          INNER JOIN clm_inward v on (v.claims_inward_seq_id=cg.claims_inward_seq_id)
          LEFT OUTER JOIN tpa_claims_payment tcp on (tcp.claim_seq_id=cg.claim_seq_id)
          LEFT OUTER JOIN tpa_clm_tds_details tds  on (tds.claim_seq_id=cg.claim_seq_id and tds.payment_seq_id=tcp.payment_seq_id)
          LEFT OUTER JOIN tpa_payment_checks_details tpcd on (tpcd.payment_seq_id=tcp.payment_seq_id and tpcd.v_csr_flag=1)
          LEFT OUTER JOIN tpa_claims_check tcc on (tcc.claims_chk_seq_id=tpcd.claims_chk_seq_id and tcc.v_csr_flag=1 and tcc.check_status IN ('CSI','CSC'))
          LEFT OUTER JOIN pat_enroll_details pee on (pee.claim_id=cg.claim_seq_id)
          LEFT OUTER JOIN pat_general_details pgd on (pgd.pat_enroll_detail_seq_id=pee.pat_enroll_detail_seq_id and pgd.pat_enhanced_yn='N')
          LEFT OUTER JOIN tpa_float_account tfa on (tfa.float_seq_id=tcp.float_seq_id)
          JOIN tpa_ins_info tii on (tii.ins_seq_id= ce.ins_seq_id)
          JOIN tpa_address tas on (tas.ins_seq_id=tii.ins_seq_id)
          LEFT OUTER JOIN tpa_group_registration tgr on (tgr.group_reg_seq_id=pol.group_reg_seq_id)
          LEFT OUTER JOIN ailment_details al on (al.claim_seq_id=cg.claim_seq_id)
          LEFT OUTER JOIN investigation_details idd on (idd.claim_seq_id=cg.claim_seq_id)
          LEFT OUTER JOIN tpa_call_log tcl ON (tcl.call_log_seq_id=cg.call_log_seq_id)
          LEFT OUTER JOIN (SELECT claim_seq_id clm_id, MIN (added_date) min_sfdt, MAX(added_date) max_sfdt, MAX(closed_date) sf_closeddt, MAX(srtfll_received_date) SF_Responded_Dt
                 FROM shortfall_details
                 GROUP BY claim_seq_id) sf ON (sf.clm_id = cg.claim_seq_id)
          left outer join (select max(sd.shortfall_seq_id) as srt_seq_id,sd.claim_seq_id from shortfall_details sd group by sd.claim_seq_id) sfd  on (cg.claim_seq_id=sfd.claim_seq_id)
          left outer join  shortfall_email_dtl sed on (sfd.srt_seq_id=sed.shortfall_seq_id)
          left outer join buffer_details bd on (cg.last_buffer_detail_seq_id=bd.buff_detail_seq_id)
          left outer join buffer_header bh on (bd.buffer_hdr_seq_id=bh.buffer_hdr_seq_id)
          LEFT OUTER JOIN pat_general_details AP ON (cg.pat_enroll_detail_seq_id = AP.pat_enroll_detail_seq_id)
          LEFT OUTER JOIN buffer_details AQ ON (AP.last_buffer_detail_seq_id = AQ.buff_detail_seq_id )
          LEFT OUTER JOIN buffer_header AR ON (AQ.buffer_hdr_seq_id  = AR.buffer_hdr_seq_id )
   
   WHERE cg.claim_seq_id=v_claim_seq_id AND (mem.mem_general_type_id = 'PFL' AND q.member_seq_id IS NULL OR mem.member_seq_id = Q.member_seq_id OR mem.member_seq_id IS NULL);
   --and tii.abbrevation_code='BA';

  clm_rec   cur_clm%ROWTYPE;

 /* CURSOR cur_bills(v_seq_id           clm_general_details.claim_seq_id%TYPE,
                   v_charges_type     tpa_hosp_ward_code.ward_type_id%TYPE) IS
  WITH bv AS(
  SELECT  g.claim_seq_id,
          d.ward_type_id,
          CASE WHEN d.ward_type_id IN('BED','DMO','DRC','ICN','ICR','IJC','NUC','RMO','ROO') THEN 'ROOM'
               WHEN d.ward_type_id IN('ANC','ASC','CDL','CON','DLC','EME','ICU','ICC','NDL','OPC','PYC','POC','PRO','SPE','SUF') THEN 'PROF'
               WHEN d.ward_type_id IN('ADC','ADM','ATN','BIC','CTL','COB','DIS','DEC','DSC','DOB','FDC','HAA','HVC','MLC','MIS','PDC','REF','SEC','STC','SUR','WCW','WCC') THEN 'NA'
               ELSE 'OTHER' END charges_type,
          ji.ward_description AS charges,
          SUM(d.allowed_amount) AS amt
        FROM clm_general_details g
           INNER JOIN clm_enroll_details e ON (e.claim_seq_id=g.claim_seq_id)
           LEFT OUTER JOIN clm_bill_header h ON (g.claim_seq_id=h.claim_seq_id)
           LEFT OUTER JOIN clm_bill_details d ON (h.clm_bill_seq_id=d.clm_bill_seq_id and d.ward_type_id!='STX')
           LEFT OUTER JOIN tpa_hosp_ward_code ji ON (ji.ward_type_id=d.ward_type_id)
           WHERE g.claim_seq_id=v_seq_id and d.allowed_amount>0
           GROUP BY g.claim_seq_id,d.ward_type_id,ji.ward_description)
      SELECT * FROM bv WHERE charges_type =v_charges_type;*/

  CURSOR cur_pol(v_tpa_enr_no   tpa_enr_policy_group.tpa_enrollment_number%TYPE,
                 v_pol_no       tpa_enr_policy.policy_number%TYPE ) IS
  WITH tab_bal AS (
     SELECT rank() over(PARTITION BY pg.tpa_enrollment_number ORDER BY pg.policy_group_seq_id DESC) AS rnk,
         pg.policy_group_seq_id,
         ep.policy_number,
         ep.renewal_policy_number,
         ep.effective_from_date,
         ep.effective_to_date,
         ep.policy_rcvd_date,
         (CASE WHEN ep.policy_sub_general_type_id='PFL' THEN pg.family_tot_sum_insured ELSE pm.mem_tot_sum_insured END) sum_insured,
         ep.renew_count as policy_renew_count,
         ep.policy_seq_id,
         app.account_info_pkg.get_gen_desc(ep.policy_sub_general_type_id,'G') as policy_subtype,
         ip.product_name,
         DECODE(ep.enrol_type_id,'COR','Corporate','IND','Individual','ING','Individual As Group','NCR','Non-Corporate')as enrol_type

    FROM tpa_enr_policy ep
    JOIN tpa_ins_product ip on (ep.product_seq_id=ip.product_seq_id)
    JOIN tpa_enr_policy_group pg on (pg.policy_seq_id=ep.policy_seq_id )
    JOIN tpa_enr_policy_member pm on (pg.policy_group_seq_id=pm.policy_group_seq_id and pm.tpa_enrollment_id=v_tpa_enr_no)
   START WITH ep.policy_number = v_pol_no
   CONNECT BY nocycle PRIOR ep.renewal_policy_number = ep.policy_number )
 SELECT ht.* FROM tab_bal ht WHERE rnk<6;

  CURSOR cur_hist(v_enr_id    clm_enroll_details.tpa_enrollment_id%TYPE) IS
  WITH clm_tab AS (
     SELECT rank() over(partition by a.tpa_enrollment_id order by a.claim_seq_id desc) as rnk,
        a.claim_seq_id,
        b.claim_number,
        to_char(b.date_of_admission,'DD-MON-YYYY') as doa,
        to_char(b.date_of_discharge,'DD-MON-YYYY') as dod,
        c.hosp_name,
        substr(replace(replace(f.provisional_diagnosis,chr(13),''),chr(10),' '),1,500) diagnosis,
        e.pre_auth_number,
        b.requested_amount as req_amt,
        b.total_app_amount as appr_amt,
        app.account_info_pkg.get_gen_desc(a.clm_status_general_type_id,'G') as  Claim_Status,
        regexp_replace(g.remarks, '[[:space:]]',' ') as rej_reason

  FROM  clm_enroll_details a
        JOIN clm_general_details b ON (a.claim_seq_id = b.claim_seq_id)
        LEFT OUTER JOIN clm_hospital_association c ON (c.claim_seq_id=b.claim_seq_id)
        LEFT OUTER JOIN pat_enroll_details e ON (e.claim_id=b.claim_seq_id)
        LEFT OUTER JOIN ailment_details f on (f.claim_seq_id=b.claim_seq_id)
        LEFT OUTER JOIN assign_users g On (g.assign_users_seq_id=b.last_assign_user_seq_id)
        WHERE a.tpa_enrollment_id=v_enr_id)
      SELECT * FROM clm_tab t WHERE rnk<=5;


 /* v_pat_req_amt      pat_general_details.pat_requested_amount%TYPE;
  v_clm_remarks      clm_general_details.claims_remarks%TYPE;*/

  CURSOR cur_bill_list(v_clm_bill_seq_id   clm_bill_header.clm_bill_seq_id%TYPE) IS
  SELECT a.clm_bill_dtl_seq_id,a.description,a.ward_type_id||'#'|| TO_CHAR(capture_number_of_days_yn) AS ward_type_id ,b.ward_description,
         a.requested_amount , a.Allowed_Amount, a.room_type_id, a.number_of_days ,
         a.allow_yn , a.rejected_amount , substr(a.remarks,1,30) remarks , c.room_description
    FROM clm_bill_details a
    INNER JOIN tpa_hosp_ward_code b ON ( a.ward_type_id = b.ward_type_id )
    LEFT OUTER JOIN tpa_hosp_rooms_code C ON (a.room_type_id = c.room_type_id)
    WHERE a.clm_bill_seq_id = v_clm_bill_seq_id ORDER BY a.clm_bill_dtl_seq_id ;

  CURSOR bill_head(bill_clm_seqid   clm_bill_header.claim_seq_id%TYPE) IS
   SELECT k.bill_date,k.bill_included_yn,k.bill_issued_by,k.bill_no,k.bills_with_prescription_yn,k.clm_bill_seq_id
   FROM clm_bill_header k WHERE claim_seq_id =bill_clm_seqid;

  /*bill_rec        bill_head%ROWTYPE;*/

 BEGIN
     OPEN cur_clm;
     FETCH cur_clm INTO clm_rec;
     CLOSE cur_clm;

    /* IF clm_rec.pre_auth_letter_no!='O1B' THEN
       SELECT gd.pat_requested_amount INTO v_pat_req_amt
       FROM Pat_Enroll_Details ed
       JOIN Pat_General_Details gd ON ed.pat_enroll_detail_seq_id=gd.pat_enroll_detail_seq_id
       WHERE ed.pre_auth_number=clm_rec.pre_auth_letter_no AND gd.pat_enhanced_yn='N';
    END IF;*/
/*
    SELECT NVL(F.Claims_Remarks,'NA') INTO v_clm_remarks FROM clm_general_details F WHERE F.claim_number=v_claim_number;
*/
    v_doc     := dbms_xmldom.newDOMDocument;
    dbms_xmldom.setVersion(v_doc,'1.0" encoding="UTF-8' );
    v_root_node := dbms_xmldom.makeNode(v_doc);

    v_elem   := dbms_xmldom.createElement(v_doc,'CLAIMSAPPOVALFORM');
    v_node   := dbms_xmldom.makeNode(v_elem);
    v_main_node := dbms_xmldom.appendChild(v_root_node,v_node);

    v_elem := dbms_xmldom.createElement(v_doc,'CLAIMDETAILS');
    v_node := dbms_xmldom.makeNode(v_elem);
    v_chld_node := dbms_xmldom.appendChild(v_main_node,v_node);

    v_elem  := dbms_xmldom.createElement(v_doc,'CLAIM_DATA');  --claims data
    v_clm_node := dbms_xmldom.makeNode(v_elem);
    dbms_xmldom.SetAttribute(v_elem,'claimnumber',clm_rec.Claim_No);
    dbms_xmldom.setAttribute(v_elem,'preauthnumber',clm_rec.pre_auth_letter_no);
    dbms_xmldom.setAttribute(v_elem,'vidalhealthttkid',clm_rec.tpa_id);
    dbms_xmldom.setAttribute(v_elem,'claimtype',clm_rec.claim_type);
    dbms_xmldom.setAttribute(v_elem,'claimcategory',clm_rec.claim_category);
    dbms_xmldom.setAttribute(v_elem,'receivedon',clm_rec.date_of_doc_rec);
    dbms_xmldom.setAttribute(v_elem,'recommededon',clm_rec.recommend_on);
    dbms_xmldom.setAttribute(v_elem,'req_claim_amt',clm_rec.estimate_amt);
    dbms_xmldom.setAttribute(v_elem,'recommended',clm_rec.recommend_amount);
    dbms_xmldom.setAttribute(v_elem,'nonadmissable',0); --rework
    dbms_xmldom.setAttribute(v_elem,'copay',clm_rec.co_pay_amount);
    dbms_xmldom.setAttribute(v_elem,'voluntary_copay',0);
    dbms_xmldom.setAttribute(v_elem,'payable',clm_rec.payble_amount);
    dbms_xmldom.setAttribute(v_elem,'tds',clm_rec.tds_amount);
    dbms_xmldom.setAttribute(v_elem,'notpayable',clm_rec.deducted_amount);
    dbms_xmldom.setAttribute(v_elem,'deduction_reason',clm_rec.deduction_reason);
    dbms_xmldom.setAttribute(v_elem,'enr_number',clm_rec.enr_num);
    v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_clm_node);

    v_elem := dbms_xmldom.createElement(v_doc,'INSURANCEDETAILS');--inscomp details
    v_node := dbms_xmldom.makeNode(v_elem);
    v_chld_node := dbms_xmldom.appendChild(v_main_node,v_node);

    v_elem := dbms_xmldom.createElement(v_doc,'INSCOMP');
    v_ins_node :=dbms_xmldom.makenode(v_elem);
    dbms_xmldom.setAttribute(v_elem,'insurancecompany',clm_rec.insurance_company);
    dbms_xmldom.setAttribute(v_elem,'controllingoffice',clm_rec.controlling_office);
    dbms_xmldom.setAttribute(v_elem,'city',clm_rec.ins_city);
    dbms_xmldom.setAttribute(v_elem,'state',clm_rec.ins_state);
    dbms_xmldom.setAttribute(v_elem,'pincode',clm_rec.ins_pincode);
    v_chld_node2 := dbms_xmldom.appendChild(v_chld_node,v_ins_node);


    v_elem := dbms_xmldom.createElement(v_doc,'POLICYDETAILS'); --policy details
    v_node := dbms_xmldom.makeNode(v_elem);
    v_chld_node := dbms_xmldom.appendChild(v_main_node,v_node);

    v_elem := dbms_xmldom.createElement(v_doc,'POLICYDATA');
    v_ins_node :=dbms_xmldom.makenode(v_elem);
    dbms_xmldom.setAttribute(v_elem,'prm_insured',clm_rec.proposer_name);
    dbms_xmldom.setAttribute(v_elem,'customerid',clm_rec.employee_customer_id);
    dbms_xmldom.setAttribute(v_elem,'policynumber',clm_rec.policy_no);
    dbms_xmldom.setAttribute(v_elem,'policystart',clm_rec.policy_form);
    dbms_xmldom.setAttribute(v_elem,'policyend',clm_rec.policy_upto);
    dbms_xmldom.setAttribute(v_elem,'policytype',clm_rec.policy_type);
    dbms_xmldom.setAttribute(v_elem,'productname',clm_rec.product_name);
    dbms_xmldom.setAttribute(v_elem,'agentcode',clm_rec.agent_code);
    dbms_xmldom.setAttribute(v_elem,'devoffcode',clm_rec.development_code);
    dbms_xmldom.setAttribute(v_elem,'operoffcode',clm_rec.operating_code);
    dbms_xmldom.setAttribute(v_elem,'operoffice',clm_rec.operating_office);
    dbms_xmldom.setAttribute(v_elem,'suminsured',clm_rec.sum_insured);
    dbms_xmldom.setAttribute(v_elem,'cummbonus',clm_rec.bonus);
    dbms_xmldom.setAttribute(v_elem,'corbuffer',clm_rec.buff_app_amt);
    dbms_xmldom.setAttribute(v_elem,'medbuffer',clm_rec.med_buff_app_amt);
    dbms_xmldom.setAttribute(v_elem,'critbuffer',clm_rec.crit_buff_app_amt);
    dbms_xmldom.setAttribute(v_elem,'critcorbuffer',clm_rec.crit_corp_buff_app_amt);
    dbms_xmldom.setAttribute(v_elem,'critmedbuffer',clm_rec.crit_med_buff_app_amt);
    dbms_xmldom.setAttribute(v_elem,'premzone',clm_rec.premium_zone);
    dbms_xmldom.setAttribute(v_elem,'payblefrom','');
    v_chld_node2 := dbms_xmldom.appendChild(v_chld_node,v_ins_node);

    v_elem := dbms_xmldom.createElement(v_doc,'POLICYHISTORY');--POLICY HISTORY
    v_node := dbms_xmldom.makeNode(v_elem);
    v_chld_node := dbms_xmldom.appendChild(v_main_node,v_node);

   FOR rk IN cur_pol(clm_rec.tpa_id,clm_rec.policy_no) LOOP

    v_elem := dbms_xmldom.createElement(v_doc,'POLHISTORY');
    v_ins_node :=dbms_xmldom.makenode(v_elem);
    dbms_xmldom.setAttribute(v_elem,'policynumber',rk.policy_number);
    dbms_xmldom.setAttribute(v_elem,'policytype',rk.enrol_type);
    dbms_xmldom.setAttribute(v_elem,'productname',rk.product_name);
    dbms_xmldom.setAttribute(v_elem,'from',rk.effective_from_date);
    dbms_xmldom.setAttribute(v_elem,'to',rk.effective_to_date);
    dbms_xmldom.setAttribute(v_elem,'suminsured',rk.sum_insured);
    v_chld_node2 := dbms_xmldom.appendChild(v_chld_node,v_ins_node);

    END LOOP;

    v_elem := dbms_xmldom.createElement(v_doc,'CLAIMANTDETAILS');--claimant details
    v_node := dbms_xmldom.makeNode(v_elem);
    v_chld_node := dbms_xmldom.appendChild(v_main_node,v_node);

    v_elem := dbms_xmldom.createElement(v_doc,'CLAIMANT');
    v_ins_node :=dbms_xmldom.makenode(v_elem);
    dbms_xmldom.setAttribute(v_elem,'claimantname',clm_rec.patient_name);
    dbms_xmldom.setAttribute(v_elem,'age',clm_rec.patient_age);
    dbms_xmldom.setAttribute(v_elem,'sex',clm_rec.gender);
    dbms_xmldom.setAttribute(v_elem,'relation',clm_rec.relation);
    dbms_xmldom.setAttribute(v_elem,'address',clm_rec.address);
    dbms_xmldom.setAttribute(v_elem,'vidal_ttkid',clm_rec.tpa_id);
    v_chld_node2 := dbms_xmldom.appendChild(v_chld_node,v_ins_node);

    v_elem := dbms_xmldom.createElement(v_doc,'CLAIMHISTORY');--CLAIM HISTORY
    v_node := dbms_xmldom.makeNode(v_elem);
    v_chld_node := dbms_xmldom.appendChild(v_main_node,v_node);

   FOR rk IN cur_hist(clm_rec.tpa_id) LOOP  --for claim history
      v_elem := dbms_xmldom.createElement(v_doc,'CLMHISTORY');
      v_ins_node :=dbms_xmldom.makenode(v_elem);
      dbms_xmldom.setAttribute(v_elem,'claimnumber',rk.claim_number);
      dbms_xmldom.setAttribute(v_elem,'doa',rk.doa);
      dbms_xmldom.setAttribute(v_elem,'dod',rk.dod);
      dbms_xmldom.setAttribute(v_elem,'hospname',rk.hosp_name);
      dbms_xmldom.setAttribute(v_elem,'prenumber',rk.pre_auth_number);
      dbms_xmldom.setAttribute(v_elem,'claimed',rk.req_amt);
      dbms_xmldom.setAttribute(v_elem,'approved',rk.appr_amt);
      dbms_xmldom.setAttribute(v_elem,'status',rk.claim_status);
      dbms_xmldom.setAttribute(v_elem,'ailment',rk.diagnosis);
      dbms_xmldom.setAttribute(v_elem,'rejreason',rk.rej_reason);
      v_chld_node2 := dbms_xmldom.appendChild(v_chld_node,v_ins_node);
   END LOOP;

 --->   HOSPITLIZATIONDETAILS

    v_elem := dbms_xmldom.createElement(v_doc,'HOSPITLIZATIONDETAILS');--claimant details
    v_node := dbms_xmldom.makeNode(v_elem);
    v_chld_node := dbms_xmldom.appendChild(v_main_node,v_node);

    v_elem := dbms_xmldom.createElement(v_doc,'HOSPDET');
    v_ins_node :=dbms_xmldom.makenode(v_elem);
    dbms_xmldom.setAttribute(v_elem,'intdate',clm_rec.intimation_date);
    dbms_xmldom.setAttribute(v_elem,'datediag',clm_rec.loss_date);
    dbms_xmldom.setAttribute(v_elem,'admssion',clm_rec.doa);
    dbms_xmldom.setAttribute(v_elem,'discharge',clm_rec.dod);
    dbms_xmldom.setAttribute(v_elem,'hospname',clm_rec.hospital_name);
    dbms_xmldom.setAttribute(v_elem,'hospcode',clm_rec.hospital_code);
    dbms_xmldom.setAttribute(v_elem,'city',clm_rec.hospital_city);
    dbms_xmldom.setAttribute(v_elem,'state',clm_rec.hospital_state);
    dbms_xmldom.setAttribute(v_elem,'pincode',clm_rec.hospital_pincode);
    dbms_xmldom.setAttribute(v_elem,'diagnosis',clm_rec.diagnosis);
    dbms_xmldom.setAttribute(v_elem,'diagclvl1',clm_rec.diagnosis_code_level_1);
    dbms_xmldom.setAttribute(v_elem,'diagclvl2',clm_rec.diagnosis_code_level_2);
    dbms_xmldom.setAttribute(v_elem,'procclvl1',clm_rec.procedure_codes_level_1);
    dbms_xmldom.setAttribute(v_elem,'procclvl2',clm_rec.procedure_codes_level_2);

    dbms_xmldom.setAttribute(v_elem,'diagdlvl1',clm_rec.diagnosis_description_level_1);
    dbms_xmldom.setAttribute(v_elem,'diagdlvl2',clm_rec.diagnosis_description_level_2);
    dbms_xmldom.setAttribute(v_elem,'procdlvl1',clm_rec.procedure_description_level_1);
    dbms_xmldom.setAttribute(v_elem,'procdlvl2',clm_rec.procedure_description_level_2);
    v_chld_node2 := dbms_xmldom.appendChild(v_chld_node,v_ins_node);

 --->>> Billing Details
    v_elem := dbms_xmldom.createElement(v_doc,'BILLINGDETAILS');--claimant details
    v_node := dbms_xmldom.makeNode(v_elem);
    v_chld_node := dbms_xmldom.appendChild(v_main_node,v_node);

    FOR bh IN bill_head(clm_rec.claim_seq_id) LOOP
    v_elem := dbms_xmldom.createElement(v_doc,'BILLHEADER');
    v_ins_node :=dbms_xmldom.makenode(v_elem);
    dbms_xmldom.setattribute(v_elem,'billno',bh.bill_no);
    dbms_xmldom.setAttribute(v_elem,'billdate',bh.bill_date);
    dbms_xmldom.setAttribute(v_elem,'bill_inc_yn',bh.bill_included_yn);
    dbms_xmldom.setAttribute(v_elem,'bill_iss_by',bh.bill_issued_by);
    dbms_xmldom.setattribute(v_elem,'bill_pres_yn',bh.bills_with_prescription_yn);
    v_chld_node2 := dbms_xmldom.appendChild(v_chld_node,v_ins_node);

    ----Description  Acc. Head   Room Type Days Req. Amt.(Rs) Rejd. Amt.(Rs) Allwd. Amt.(Rs) Remarks Delete
    FOR lv IN cur_bill_list(bh.clm_bill_seq_id) LOOP
     v_elem := dbms_xmldom.createElement(v_doc,'BILLS');
     v_ins_node := dbms_xmldom.makeNode(v_elem);
     dbms_xmldom.setAttribute(v_elem,'description',lv.description);
     dbms_xmldom.setattribute(v_elem,'acchead',lv.ward_description);
     dbms_xmldom.setattribute(v_elem,'reqamt',lv.requested_amount);
     dbms_xmldom.setattribute(v_elem,'allowamt',lv.allowed_amount);
     dbms_xmldom.setAttribute(v_elem,'roomtype',lv.room_description);
     dbms_xmldom.setAttribute(v_elem,'nodays',lv.number_of_days);
     dbms_xmldom.setAttribute(v_elem,'rejamt',lv.rejected_amount);
     dbms_xmldom.setAttribute(v_elem,'remarks',lv.remarks);

     v_chld_node3 := dbms_xmldom.appendChild(v_chld_node2,v_ins_node);

    END LOOP;
    END LOOP;

  --ShortFall details
    v_elem := dbms_xmldom.createElement(v_doc,'SHORTFALLDETAILS');--claimant details
    v_node := dbms_xmldom.makeNode(v_elem);
    dbms_xmldom.setAttribute(v_elem,'description',clm_rec.disc_datails);
    v_chld_node := dbms_xmldom.appendChild(v_main_node,v_node);

    v_elem := dbms_xmldom.createElement(v_doc,'INSURED');
    v_ins_node :=dbms_xmldom.makenode(v_elem);
    dbms_xmldom.setAttribute(v_elem,'shortfalldate',clm_rec.insured_disc_date);
    dbms_xmldom.setattribute(v_elem,'reminderdate',clm_rec.insured_reminder_date);
    dbms_xmldom.setAttribute(v_elem,'finalremdate',clm_rec.insured_final_reminder_date);
    dbms_xmldom.setAttribute(v_elem,'replyrecdate',clm_rec.insured_reply_recieved_date);
    v_chld_node2 := dbms_xmldom.appendChild(v_chld_node,v_ins_node);

    v_elem := dbms_xmldom.createElement(v_doc,'HOSPITAL');
    v_ins_node :=dbms_xmldom.makenode(v_elem);
    dbms_xmldom.setAttribute(v_elem,'shortfalldate',clm_rec.hospital_disc_date);
    dbms_xmldom.setattribute(v_elem,'reminderdate',clm_rec.hospital_reminder_date);
    dbms_xmldom.setAttribute(v_elem,'finalremdate',clm_rec.hospital_final_reminder_date);
    dbms_xmldom.setAttribute(v_elem,'replyrecdate',clm_rec.hospital_reply_recieved_date);
    v_chld_node2 := dbms_xmldom.appendChild(v_chld_node,v_ins_node);

    v_elem := dbms_xmldom.createElement(v_doc,'INSURER');
    v_ins_node :=dbms_xmldom.makenode(v_elem);
    dbms_xmldom.setAttribute(v_elem,'shortfalldate',clm_rec.Insurer_Disc_Date);
    dbms_xmldom.setattribute(v_elem,'reminderdate',clm_rec.Insurer_Reminder_Date);
    dbms_xmldom.setAttribute(v_elem,'finalremdate',clm_rec.insurer_final_reminder_date);
    dbms_xmldom.setAttribute(v_elem,'replyrecdate',clm_rec.insurer_reply_recieved_date);
    v_chld_node2 := dbms_xmldom.appendChild(v_chld_node,v_ins_node);

    --- Investigation details
    v_elem := dbms_xmldom.createElement(v_doc,'INVESTIGATIONDETAILS');--claimant details
    v_node := dbms_xmldom.makeNode(v_elem);
    v_chld_node := dbms_xmldom.appendChild(v_main_node,v_node);

    v_elem := dbms_xmldom.createElement(v_doc,'INVESTIGATION');
    v_ins_node :=dbms_xmldom.makenode(v_elem);
    dbms_xmldom.setAttribute(v_elem,'invname',clm_rec.investigated_by);
    dbms_xmldom.setAttribute(v_elem,'invdate',clm_rec.investigated_date);
    dbms_xmldom.setAttribute(v_elem,'recommendation',clm_rec.invst_remarks);
    dbms_xmldom.setAttribute(v_elem,'tpa_recommendation',clm_rec.Clm_Status);
    dbms_xmldom.setattribute(v_elem,'tparemarks',clm_rec.claims_remarks);
    dbms_xmldom.setAttribute(v_elem,'insremarks',clm_rec.clm_ins_remarks);

    v_chld_node2 := dbms_xmldom.appendChild(v_chld_node,v_ins_node);


    v_out_xml:=dbms_xmldom.getxmltype(v_doc);
    v_clob := REPLACE(REPLACE(v_out_xml.getclobval(),'&','and'),'andamp;','and');

    v_claim_xml :=v_out_xml ;-- dbms_xmlgen.getXMLType(v_out_xml);
    v_ins_status := case when clm_rec.clm_status_general_type_id='APR' AND clm_rec.clm_ins_status='APR' THEN 'TRAD'
                         WHEN clm_rec.clm_status_general_type_id='REJ' AND clm_rec.clm_ins_status='REJ' THEN 'TRAD'
                         WHEN clm_rec.clm_ins_status ='INP' THEN NULL
                      ELSE 'TRND' END;
    v_ins_remarks:=clm_rec.clm_ins_remarks;
    dbms_xmldom.freeDocument(v_doc);

    END select_claims_web;
---=========================================================================================================================
FUNCTION fn_sfremarks (v_claim_seq_id IN NUMBER)
  RETURN VARCHAR2
  IS
        CURSOR cur IS
        WITH AB AS (
        SELECT shortfall_questions,s.claim_seq_id,c.claim_number
        FROM shortfall_details s, clm_general_details c
        WHERE c.claim_seq_id =s.claim_seq_id
        AND s.claim_seq_id=v_claim_seq_id
        )
        SELECT extractValue(value(C), '/query/@value') as otherquery
             FROM  AB, table(XMLSequence(extract(SHORTFALL_QUESTIONS ,'shortfall/section/subsection/query')))C
             WHERE upper(extractValue(value(C), '/query/@type'))='TEXT';

        otherquery           VARCHAR2(32000);
        /*claim_number1        VARCHAR2(100);
        tpa_enrollment_id1   VARCHAR2(100);*/
        str                  VARCHAR2(32767):=NULL;
        v_str                clob:=null;
        comma                CHAR:=NULL;
  BEGIN

        OPEN cur;
        LOOP
            --FETCH cur INTO claim_number1,tpa_enrollment_id1,otherquery;
            FETCH cur INTO otherquery;
            EXIT WHEN cur%NOTFOUND;
            IF length(otherquery)>1   THEN

                v_str:=v_str||comma||otherquery;
            END IF;
            comma:=',';
        END LOOP;
        CLOSE cur;
        str:=dbms_lob.substr(v_str,3000,1);
        str := REPLACE(str,'&','AND');
        RETURN str;
  END fn_sfremarks;
--===============================================================================
FUNCTION f_rej_amt_rem (v_claim_seq_id     IN clm_general_details.claim_seq_id%TYPE,
                         v_flag             IN VARCHAR2)
   RETURN VARCHAR2 IS
      v_out   VARCHAR2(2000);

    CURSOR cur_rej IS
      SELECT claim_seq_id,SUM(rejected_amount) as rej_amt,
             RTRIM(XMLAGG(XMLELEMENT(E,rejected_amount||'-'||remarks||' ; ')).EXTRACT('//text()'),' , ') Remarks
             FROM clm_bill_details cbd
             JOIN clm_bill_header cbh ON (cbh.clm_bill_seq_id =cbd.clm_bill_seq_id)
             WHERE cbh.claim_seq_id=v_claim_seq_id AND rejected_amount>0
             GROUP BY claim_seq_id;
      rej_rec   cur_rej%ROWTYPE;

   BEGIN
     OPEN cur_rej;
     FETCH cur_rej INTO rej_rec;
     CLOSE cur_rej;
    IF v_flag ='AMT' THEN
       v_out := nvl(rej_rec.rej_amt,0);
    ELSIF v_flag ='REM' THEN
        v_out := REPLACE(nvl(rej_rec.remarks,'NA'),'&','AND');
    END IF;

    RETURN v_out;

     END f_rej_amt_rem;
---=======================================================================================
FUNCTION f_icd_code_desc(v_claim_seq_id IN icd_pcs_detail.icd_pcs_seq_id%TYPE, -- to precide ICD CODES
                          v_flag         IN VARCHAR2,
                          v_type         IN VARCHAR2)
         RETURN  VARCHAR2 AS
         v_out   VARCHAR2(4000);

 CURSOR cur_icd IS
        SELECT claim_seq_id,
                  nvl(MAX(CASE WHEN icd_rank=1 THEN icd_code ELSE NULL END),'NA') icd_code_1,
                  nvl(MAX(CASE WHEN icd_rank=2 THEN icd_code ELSE NULL END),'NA') icd_code_2,
                  nvl(MAX(CASE WHEN icd_rank=1 THEN ped_description ELSE NULL END),'NA') icd_desc_1,
                  nvl(MAX(CASE WHEN icd_rank=2 THEN ped_description ELSE NULL END),'NA') icd_desc_2
                  FROM
                  (SELECT g.claim_seq_id,
                          i.icd_code,
                          k.ped_description,
                          rank()over (ORDER BY i.icd_pcs_seq_id desc,i.primary_ailment_yn asc) icd_rank
                  FROM clm_general_details g
                  LEFT OUTER JOIN icd_pcs_detail i ON (i.claim_seq_id=g.claim_seq_id)
                  LEFT OUTER JOIN tpa_ped_code k ON (k.icd_code=i.icd_code)
                  WHERE g.claim_seq_id=v_claim_seq_id)
                  GROUP BY claim_seq_id ;

      icd_cur     cur_icd%ROWTYPE;

  CURSOR cur_pcd IS
         SELECT claim_seq_id,
                  nvl(MAX(CASE WHEN RANK=1 THEN proc_code ELSE NULL END),'NA') pcs_code_1,
                  nvl(MAX(CASE WHEN RANK=2 THEN proc_code ELSE NULL END),'NA') pcs_code_2,
                  nvl(MAX(CASE WHEN RANK=1 THEN proc_description ELSE NULL END),'NA') pcs_desc_1,
                  nvl(MAX(CASE WHEN RANK=2 THEN proc_description ELSE NULL END),'NA') pcs_desc_2
           FROM (SELECT p.proc_seq_id,
                        g.claim_seq_id,
                        i.icd_code,
                        i.primary_ailment_yn,
                        c.proc_code,
                        nvl(substr(REPLACE(REPLACE(c.proc_description,chr(13),''),CHR(10),' '),1,240),'NA') proc_description,
                        rank()over (ORDER BY p.pat_proc_seq_id DESC) RANK
                  FROM clm_general_details G
                  INNER JOIN icd_pcs_detail I ON (i.claim_seq_id=g.claim_seq_id)
                  INNER JOIN pat_package_procedures P ON (p.icd_pcs_seq_id=i.icd_pcs_seq_id)
                  INNER JOIN tpa_hosp_procedure_code C ON (c.proc_seq_id=p.proc_seq_id)
                  WHERE g.claim_seq_id=v_claim_seq_id) group by claim_seq_id;


      pcd_cur         cur_pcd%ROWTYPE;

 BEGIN

  IF v_flag ='IC' THEN

  OPEN cur_icd;
  FETCH cur_icd INTO icd_cur;
  CLOSE cur_icd;

  IF v_type ='IC1' THEN
       v_out := icd_cur.icd_code_1;
  ELSIF v_type ='IC2' THEN
       v_out := icd_cur.icd_code_2;
  ELSIF v_type ='ID1' THEN
       v_out := icd_cur.icd_desc_1;
  ELSIF v_type ='ID2' THEN
       v_out := icd_cur.icd_desc_2;
  END IF;

 ELSIF v_flag ='PC' THEN
     OPEN cur_pcd;
     FETCH cur_pcd INTO pcd_cur;
     CLOSE cur_pcd;

    IF v_type ='PC1' THEN
       v_out := pcd_cur.pcs_code_1;
    ELSIF v_type ='PC2' THEN
          v_out := pcd_cur.pcs_code_2;
    ELSIF v_type ='PD1' THEN
          v_out := pcd_cur.pcs_desc_1;
    ELSIF v_type ='PD2' THEN
          v_out := pcd_cur.pcs_desc_2;
    END IF;

  END IF;

  RETURN nvl(v_out,'NA');
 END f_icd_code_desc;
---=============================================================================================================
PROCEDURE claim_ins_appr_save (v_seq_ids              IN VARCHAR2,
                                v_appr_rej_status      IN clm_enroll_details.Clm_Status_General_Type_Id%TYPE,
                                v_remarks              IN clm_ins_intimation_details.clm_ins_remarks%TYPE,
                                v_added_by             IN NUMBER,
                                v_rows_processed       OUT NUMBER) IS

  seq_tab                ttk_util_pkg.str_table_type;
  v_cnt                  NUMBER(10);
  v_prod_policy_seq_id        tpa_ins_prod_policy.prod_policy_seq_id%TYPE;

  cursor clm_cur(v_seq_id clm_enroll_details.claim_seq_id%type) is
  select cii.Clm_Ins_Status AS prev_ins_status,CII.CLM_INS_REMARKS AS prev_ins_remarks,
  a.clm_status_general_type_id as clm_status
  from clm_enroll_details  a
  left outer join clm_ins_intimation_details cii on (a.claim_seq_id=cii.claim_seq_id)
  where a.claim_seq_id=v_seq_id
  and cii.clm_ins_status is not null;
  --and cii.clm_ins_status!='INP';

  clm_rec clm_cur%rowtype;
  v_status               clm_ins_intimation_details.clm_ins_status%type;

  BEGIN
  seq_tab         := ttk_util_pkg.parse_str(v_seq_ids);


  FOR i IN seq_tab.first..seq_tab.last LOOP
    SELECT COUNT(1) INTO v_cnt FROM clm_general_details cg WHERE cg.claim_seq_id=seq_tab(i) and cg.completed_yn='Y';
      IF v_cnt>0 THEN
        Raise_application_error(-20868,'No Modifications Are Allowed, Claim Needs Insurance company Response');
      END IF;

    open clm_cur(seq_tab(i));
    fetch clm_cur into clm_rec;
    close clm_cur;

    v_status:=CASE WHEN clm_rec.clm_status='APR' AND  v_appr_rej_status='TRAD' THEN 'APR'
                                              WHEN clm_rec.clm_status='REJ' AND  v_appr_rej_status='TRAD' THEN 'REJ'
                                              ELSE 'REQ' END;

    if clm_rec.clm_status not in ('APR','REJ') AND v_status IS NOT NULL THEN
       Raise_application_error(-20868,'No Modifications Are Allowed, Preauth/Claim Already intimated to TPA.');
    end if;

    if clm_rec.prev_ins_status=v_status and clm_rec.prev_ins_remarks=v_remarks then
      raise_application_error(-20836,'Preauth/Claim Already intimated to TPA, Please change the Status/Remarks.');
    end if;


     UPDATE clm_ins_intimation_details ce
       SET ce.clm_ins_status           = v_status,
           ce.clm_ins_decision_date    = SYSDATE,
           ce.clm_ins_remarks          = substr(app.account_info_pkg.get_gen_desc(v_appr_rej_status,'G')||'--'||TO_CHAR(SYSDATE,'DD-MON-YYYY HH:MI:SS AM')||'--'||app.account_info_pkg.get_gen_desc(v_added_by,'U')||'--'||v_remarks,1,1000),
           CE.UPDATED_BY               = V_ADDED_BY,
           CE.UPDATED_DATE             = SYSDATE
      WHERE claim_seq_id               = seq_tab(i);


      v_rows_processed := sql%rowcount;

  COMMIT;

    v_prod_policy_seq_id:=pre_auth_pkg.get_prod_pol_seq_id(seq_tab(i),'CLM');
    generate_mail_pkg.proc_generate_mail('TTK_SPOC_CLM_RESP',seq_tab(i),v_prod_policy_seq_id,v_added_by);

  END LOOP;
 END claim_ins_appr_save;
---============================================================================================================
-- PROCEDURE     : claims_intimate_send ,pre_auth_intimated_send
-- comments      : Need to call from Front end on a scheduled_basis generate excel or txt file
---=======================================================================================================
 PROCEDURE claims_intimate_send(v_ins_code           IN tpa_ins_info.abbrevation_code%TYPE,
                                v_result_set         OUT sys_refcursor) IS

    v_sql_str                     VARCHAR2(32760);

   BEGIN

      v_sql_str :=  'SELECT
                        cg.claim_number,
                        ce.decision_date,
                        gc.description
                    FROM clm_general_details cg
                    JOIN clm_enroll_details ce ON (cg.claim_seq_id=ce.claim_seq_id)
                    left outer join clm_ins_intimation_details cii on (cg.claim_seq_id=cii.claim_seq_id)
                    JOIN tpa_ins_info tii ON (tii.ins_seq_id=ce.ins_seq_id)
                    JOIN tpa_general_code gc ON (gc.general_type_id=ce.clm_status_general_type_id)
                    WHERE cii.clm_ins_status=''INP'' AND CG.COMPLETED_YN=''N'' AND  tii.abbrevation_code=:v_ins_code
                    ORDER BY ce.decision_date ASC';

         OPEN v_result_set FOR v_sql_str USING v_ins_code;

    END claims_intimate_send;
---=======================================================================================================
 PROCEDURE clm_generate_letter (v_claim_seq_id                 IN clm_enroll_details.claim_seq_id%TYPE,
                                v_clm_result                   OUT SYS_REFCURSOR) IS


    CURSOR cur_clm IS
    SELECT h.claim_seq_id,h.claim_number,c.tpa_enrollment_id, c.policy_number,c.member_seq_id
    FROM clm_general_details h
    JOIN clm_enroll_details c ON (h.claim_seq_id=c.claim_seq_id)
    WHERE h.claim_seq_id=v_claim_seq_id;

    clm_rec                       cur_clm%ROWTYPE;
    
   v_buff_app_amt                           buffer_header.buff_app_amt%type:=pre_auth_pkg.get_buff_apr_amt(v_claim_seq_id,'CLM','CORP_BUFF') ;
   v_med_buff_app_amt                       buffer_header.buff_app_amt%type:=pre_auth_pkg.get_buff_apr_amt(v_claim_seq_id,'CLM','MED_BUFF') ;	
   v_crit_buff_app_amt                      buffer_header.buff_app_amt%type:=pre_auth_pkg.get_buff_apr_amt(v_claim_seq_id,'CLM','CRIT_BUFF') ;
   v_crit_corp_buff_app_amt                 buffer_header.buff_app_amt%type:=pre_auth_pkg.get_buff_apr_amt(v_claim_seq_id,'CLM','CRIT_CORP_BUFF') ;
   v_crit_med_buff_app_amt                  buffer_header.buff_app_amt%type:=pre_auth_pkg.get_buff_apr_amt(v_claim_seq_id,'CLM','CRIT_MED_BUFF') ;
	

    BEGIN
     OPEN cur_clm;
     FETCH cur_clm INTO clm_rec;
     CLOSE cur_clm;

  ----=========================================================/claim details list /=====================
   OPEN v_clm_result FOR -- gets claims details
   SELECT cg.claim_seq_id,
          cg.claim_number claim_no,
          grp.insured_name proposer_name,
          ce.claimant_name patient_name,
          ce.employee_no employee_customer_id,
          ce.tpa_enrollment_id tpa_id,
          round(ce.mem_age) patient_age,
          app.account_info_pkg.get_gen_desc(mem.relship_type_id,'R') Relation,
          app.account_info_pkg.get_gen_desc(mem.gender_general_type_id,'G') Gender,
          pol.policy_number policy_no,
          to_char(pol.effective_from_date,'DD-MON-YYYY')  policy_form,
          to_char(pol.effective_to_date,'DD-MON-YYYY')    policy_upto,
          tgr.group_name||'--'||tip.product_name  product_name,
          q.sum_insured,
         -- nvl(q.bonus,0) bonus,
          --mem.mem_tot_bonus as bonus,-- taken as cumulative bonus
          CASE WHEN POL.POLICY_SUB_GENERAL_TYPE_ID ='PFL' THEN grp.FLOATER_TOT_BONUS ELSE mem.mem_tot_bonus END as bonus,
          ma.address_1||' '||ma.address_2||' '||ma.address_3 address,
          to_char(tcl.call_recorded_date,'DD-MON-YYYY') intimation_date,
          to_char(v.rcvd_date,'DD-MON-YYYY') date_of_doc_rec,
          to_char(cg.date_of_admission,'DD-MON-YYYY') loss_date,
          nvl(thi.hosp_name,ha.hosp_name) hospital_name,
          NVL(app.account_info_pkg.get_gen_desc(tha.city_type_id,'CT') , ha.city_name) hospital_city,
          NVL(app.account_info_pkg.get_gen_desc(THA.STATE_TYPE_ID,'S'), ha.state_name) hospital_state,
          NVL(THA.PIN_CODE ,ha.pin_code) as hospital_pincode,
          substr(REPLACE(REPLACE(al.provisional_diagnosis,chr(13),''),chr(10),' '),1,500) diagnosis,
          f_icd_code_desc(cg.claim_seq_id,'IC','IC1') diagnosis_code_level_1,
          f_icd_code_desc(cg.claim_seq_id,'IC','IC2') diagnosis_code_level_2,
          f_icd_code_desc(cg.claim_seq_id,'IC','ID1') diagnosis_description_level_1,
          f_icd_code_desc(cg.claim_seq_id,'IC','ID2') diagnosis_description_level_2,

          f_icd_code_desc(cg.claim_seq_id,'PC','PC1') procedure_codes_level_1,
          f_icd_code_desc(cg.claim_seq_id,'PC','PC2') procedure_codes_level_2,
          f_icd_code_desc(cg.claim_seq_id,'PC','PD1') procedure_description_level_1,
          f_icd_code_desc(cg.claim_seq_id,'PC','PD2') procedure_description_level_2,

          to_char(cg.date_of_admission,'DD-MON-YYYY') doa,
          to_char(cg.date_of_discharge,'DD-MON-YYYY') dod,

          CASE v.claim_general_type_id WHEN 'CNH' THEN 'CASHLESS' ELSE 'REIMBURSEMENT' END claim_type,
          app.account_info_pkg.get_gen_desc(v.claim_general_type_id,'G') claim_category,
          app.account_info_pkg.get_gen_desc(pol.enrol_type_id,'E') policy_type,
          cg.requested_amount estimate_amt,
          round(nvl(cg.total_app_amount,0)-nvl(cg.serv_tax_calc_amount,0)) claim_amount,

          nvl(round((SELECT SUM(approved_amount)
              FROM ailment_caps x JOIN icd_pcs_detail y ON ( x.icd_pcs_seq_id = y.icd_pcs_seq_id )
              WHERE y.claim_seq_id = cg.claim_seq_id)),0) recommend_amount,
          nvl(cg.co_payment_amount,0)+nvl(cg.co_payment_buffer_amount,0) co_pay_amount,

          nvl(round((SELECT SUM(approved_amount)
              FROM ailment_caps x JOIN icd_pcs_detail y ON ( x.icd_pcs_seq_id = y.icd_pcs_seq_id )
              WHERE y.claim_seq_id = cg.claim_seq_id)),0) AS approved_amount,
          f_rej_amt_rem(cg.claim_seq_id,'AMT') deducted_amount,
          f_rej_amt_rem(cg.claim_seq_id,'REM') deduction_reason,
          '0' compulsary_deduction,
          nvl(cg.serv_tax_calc_amount,'0') service_tax_amount,
          ha.serv_tax_rgn_number service_tax_no,
          nvl(tcp.approved_amount,'0') payble_amount,
          round(nvl(tds.approved_amount-tds.check_amount,'0')) tds_amount,
          round(nvl(tcc.check_amount,'0')) net_payble_amt,
          to_char(CII.CLM_INS_SEND_DATE,'DD-MON-YYYY') recommend_on,
          to_char( ce.decision_date,'DD-MON-YYYY') approved_on,

          CASE v.claim_general_type_id WHEN 'CNH' THEN 0 ELSE round(nvl(nvl(tcc.check_amount,cg.total_app_amount),0)) END pay_to_insured,
          CASE v.claim_general_type_id WHEN 'CNH' THEN round(nvl(nvl(tcc.check_amount,cg.total_app_amount),0)) ELSE 0 END pay_to_hospital,
          v_buff_app_amt Buff_App_Amt,
          v_med_buff_app_amt Med_Buff_App_Amt,
          v_crit_buff_app_amt Crit_Buff_App_Amt,
          v_crit_corp_buff_app_amt Crit_Corp_Buff_App_Amt,
          v_crit_med_buff_app_amt Crit_Med_Buff_App_Amt,
           nvl(nvl(bh.Utilised_Amount,ar.Utilised_Amount),0) AS Utilised_Amount,
           nvl(nvl(bh.Utilised_Med_Amount,ar.Utilised_Med_Amount),0) AS Utilised_Med_Amount,
           nvl(nvl(bh.Utilised_Crit_Amount,ar.Utilised_Crit_Amount),0) AS Utilised_Crit_Amount,
           nvl(nvl(bh.Utilised_Crit_Corp_Amount,ar.Utilised_Crit_Corp_Amount),0) AS Utilised_Crit_Corp_Amount,
           nvl(nvl(bh.Utilised_Crit_Med_Amount,ar.Utilised_Crit_Med_Amount),0) AS Utilised_Crit_Med_Amount,
          to_char(tcc.check_num) cheque_no,
          to_char(tcc.check_date,'DD-MON-YYYY') cheque_date,
          ttk_util_pkg.fn_decrypt(tcp.payee_name)  clm_pay_to_beneficiary_name,
          --fn_sfremarks(cg.claim_seq_id) disc_datails,
          get_srtfall_remarks('CHECKBOX','CLM',CG.CLAIM_SEQ_ID)||case when get_srtfall_remarks('OTHERS','CLM',CG.CLAIM_SEQ_ID) is not null then ' ******* Other Queries: '||get_srtfall_remarks('OTHERS','CLM',CG.CLAIM_SEQ_ID)  end AS  disc_datails,
          case when v.claim_general_type_id='CTM' THEN to_char(SED.INTL_SHORTFAL_SNT_DATE,'DD-MON-YYYY') ELSE NULL END AS  insured_disc_date,
          case when v.claim_general_type_id='CTM' THEN to_char(SED.RMDR_REQ_SNT_DATE,'DD-MON-YYYY') ELSE NULL END AS   insured_reminder_date,
          case when v.claim_general_type_id='CTM' THEN to_char(SED.CLSR_NOTICE_SNT_DATE,'DD-MON-YYYY') ELSE NULL END AS  insured_final_reminder_date,
          case when v.claim_general_type_id='CTM' THEN to_char(SF_Responded_Dt,'DD-MON-YYYY') ELSE NULL END AS  insured_reply_recieved_date,
          case when v.claim_general_type_id='CTM' THEN NULL ELSE to_char(SED.INTL_SHORTFAL_SNT_DATE,'DD-MON-YYYY') END AS hospital_disc_date,
          case when v.claim_general_type_id='CTM' THEN NULL ELSE to_char(SED.RMDR_REQ_SNT_DATE,'DD-MON-YYYY') END AS  hospital_reminder_date,
          case when v.claim_general_type_id='CTM' THEN NULL ELSE to_char(SED.CLSR_NOTICE_SNT_DATE,'DD-MON-YYYY') END AS  hospital_final_reminder_date,
          case when v.claim_general_type_id='CTM' THEN NULL ELSE  to_char(SF_Responded_Dt,'DD-MON-YYYY') END AS hospital_reply_recieved_date,
          CASE WHEN tii.Email_Id IS NOT NULL THEN to_char(SED.RMDR_REQ_SNT_DATE,'DD-MON-YYYY') ELSE NULL END  AS insurer_disc_date,
          CASE WHEN tii.Email_Id IS NOT NULL THEN to_char(SED.CLSR_NOTICE_SNT_DATE,'DD-MON-YYYY') ELSE NULL END  AS insurer_reminder_date,
          CASE WHEN tii.Email_Id IS NOT NULL THEN to_char(SED.CLM_CLSR_LETTER_SNT_DATE,'DD-MON-YYYY') ELSE NULL END  AS insurer_final_reminder_date,
          NULL insurer_reply_recieved_date,
          to_char(V.RCVD_DATE,'DD-MON-YYYY') pre_auth_received_on,
          pee.pre_auth_number  pre_auth_letter_no,
          app.account_info_pkg.get_gen_desc(pee.pat_status_general_type_id,'G') pre_auth_status,
          nvl(pgd.total_app_amount,'0') pre_auth_amount,
          to_char(pee.decision_date,'DD-MON-YYYY') pre_auth_approved_on,
          nvl(tfa.float_account_number,'NA') float_no,
          to_char(tfa.effective_date,'DD-MON-YYYY') float_date,
          to_char(tcc.check_date,'DD-MON-YYYY') payment_date,
          '0' agent_code,
          pol.dev_officer_code development_code,
          tii.ins_comp_name  operating_office,
          tii.ins_comp_code_number  operating_code,
          NVL(app.account_info_pkg.get_gen_desc(tas.City_Type_Id,'CT'),TAS.CITY)  ins_city,
          NVL(app.account_info_pkg.get_gen_desc(tas.State_Type_Id,'S'),TAS.STATE)  ins_state,
          tas.pin_code ins_pincode,
          NULL controlling_office,
          tii.ins_comp_name  insurance_company,
          app.account_info_pkg.get_gen_desc(tcp.payee_type,'G') settelement_type,
          to_char(ce.decision_date,'DD-MON-YYYY') settelement_date,
          regexp_replace(au.remarks, '[[:space:]]',' ') as repudiation_rejection_reason,
          app.account_info_pkg.get_gen_desc(ce.clm_status_general_type_id,'G')  AS STATUS,
          NULL benefit_type,
          NULL bill_entered_by,
          NULL bill_entry_location,
          NVL2(ha.empanel_number,ha.empanel_number,nvl(thi.empanel_number,'')) hospital_code,
          ce.member_seq_id,
          grp.tpa_enrollment_number enr_num,
          'Bangalore' as premium_zone,
          regexp_replace(au.remarks, '[[:space:]]',' ') claims_remarks,
          cII.clm_ins_remarks as ins_remarks


     FROM clm_general_details cg  --on (bdv.claim_seq_id=cg.claim_seq_id)
          INNER JOIN clm_enroll_details ce on (ce.claim_seq_id=cg.claim_seq_id)
          left outer join clm_ins_intimation_details cii on (CE.claim_seq_id=cii.claim_seq_id)
          INNER JOIN assign_users au ON (au.ASSIGN_USERS_SEQ_ID=cg.last_assign_user_seq_id)
          INNER JOIN tpa_enr_policy pol on (ce.policy_seq_id=pol.policy_seq_id)
          INNER JOIN tpa_enr_policy_member mem on (mem.member_seq_id=ce.member_seq_id)
          INNER JOIN tpa_enr_policy_group grp on (grp.policy_group_seq_id=mem.policy_group_seq_id)
          INNER JOIN tpa_ins_product tip on (tip.product_seq_id=pol.product_seq_id)
          INNER JOIN tpa_enr_balance q on (q.policy_group_seq_id=grp.policy_group_seq_id)
          INNER JOIN tpa_enr_mem_address ma on (ma.enr_address_seq_id=grp.enr_address_seq_id)
          LEFT OUTER JOIN clm_hospital_association ha on (ha.claim_seq_id=cg.claim_seq_id)
          LEFT OUTER JOIN tpa_hosp_info thi on (ha.hosp_seq_id =thi.hosp_seq_id)
          LEFT OUTER JOIN tpa_hosp_address tha on (thi.hosp_seq_id=tha.hosp_seq_id)
          INNER JOIN clm_inward v on (v.claims_inward_seq_id=cg.claims_inward_seq_id)
          LEFT OUTER JOIN tpa_claims_payment tcp on (tcp.claim_seq_id=cg.claim_seq_id)
          LEFT OUTER JOIN tpa_clm_tds_details tds  on (tds.claim_seq_id=cg.claim_seq_id and tds.payment_seq_id=tcp.payment_seq_id)
          LEFT OUTER JOIN tpa_payment_checks_details tpcd on (tpcd.payment_seq_id=tcp.payment_seq_id and tpcd.v_csr_flag=1)
          LEFT OUTER JOIN tpa_claims_check tcc on (tcc.claims_chk_seq_id=tpcd.claims_chk_seq_id and tcc.v_csr_flag=1 and tcc.check_status IN ('CSI','CSC'))
          LEFT OUTER JOIN pat_enroll_details pee on (pee.claim_id=cg.claim_seq_id)
          LEFT OUTER JOIN pat_general_details pgd on (pgd.pat_enroll_detail_seq_id=pee.pat_enroll_detail_seq_id and pgd.pat_enhanced_yn='N')
          LEFT OUTER JOIN tpa_float_account tfa on (tfa.float_seq_id=tcp.float_seq_id)
          JOIN tpa_ins_info tii on (tii.ins_seq_id= ce.ins_seq_id)
          JOIN tpa_address tas on (tas.ins_seq_id=tii.ins_seq_id)
          LEFT OUTER JOIN tpa_group_registration tgr on (tgr.group_reg_seq_id=pol.group_reg_seq_id)
          LEFT OUTER JOIN ailment_details al on (al.claim_seq_id=cg.claim_seq_id)
          LEFT OUTER JOIN tpa_call_log tcl ON (tcl.call_log_seq_id=cg.call_log_seq_id)
          LEFT OUTER JOIN (SELECT claim_seq_id clm_id, MIN (added_date) min_sfdt, MAX(added_date) max_sfdt, MAX(closed_date) sf_closeddt, MAX(srtfll_received_date) SF_Responded_Dt
                 FROM shortfall_details
                 GROUP BY claim_seq_id) sf ON (sf.clm_id = cg.claim_seq_id)
          left outer join (select max(sd.shortfall_seq_id) as srt_seq_id,sd.claim_seq_id from shortfall_details sd group by sd.claim_seq_id) sfd  on (cg.claim_seq_id=sfd.claim_seq_id)
          left outer join  shortfall_email_dtl sed on (sfd.srt_seq_id=sed.shortfall_seq_id)
          left outer join buffer_details bd on (cg.last_buffer_detail_seq_id=bd.buff_detail_seq_id)
          left outer join buffer_header bh on (bd.buffer_hdr_seq_id=bh.buffer_hdr_seq_id)
          LEFT OUTER JOIN pat_general_details AP ON (cg.pat_enroll_detail_seq_id = AP.pat_enroll_detail_seq_id)
          LEFT OUTER JOIN buffer_details AQ ON (AP.last_buffer_detail_seq_id = AQ.buff_detail_seq_id )
          LEFT OUTER JOIN buffer_header AR ON (AQ.buffer_hdr_seq_id  = AR.buffer_hdr_seq_id )
    WHERE cg.claim_seq_id=v_claim_seq_id
          AND (mem.mem_general_type_id = 'PFL' AND q.member_seq_id IS NULL OR mem.member_seq_id = Q.member_seq_id OR mem.member_seq_id IS NULL);

 END clm_generate_letter;
----===================================/policy history/=======================
 PROCEDURE clm_gen_policy_hist(v_policy_number       IN tpa_enr_policy.policy_number%TYPE,
                               v_tpa_enr_id          IN tpa_enr_policy_member.tpa_enrollment_id%TYPE,
                               v_pol_hist_result     OUT SYS_REFCURSOR ) IS

   BEGIN

  OPEN v_pol_hist_result FOR

  WITH tab_bal AS (
     SELECT rank() over(PARTITION BY pg.tpa_enrollment_number ORDER BY pg.policy_group_seq_id DESC) AS rnk,
         pg.policy_group_seq_id,
         ep.policy_number,
         ep.renewal_policy_number,
         to_char(ep.effective_from_date,'DD-MON-YYYY') as effective_from_date,
         to_char(ep.effective_to_date,'DD-MON-YYYY') as effective_to_date,
         ep.policy_rcvd_date,
         (CASE WHEN ep.policy_sub_general_type_id='PFL' THEN pg.family_tot_sum_insured ELSE pm.mem_tot_sum_insured END) sum_insured,
         ep.renew_count as policy_renew_count,
         ep.policy_seq_id,
         app.account_info_pkg.get_gen_desc(ep.policy_sub_general_type_id,'G') as policy_subtype,
         ip.product_name,
         DECODE(ep.enrol_type_id,'COR','Corporate','IND','Individual','ING','Individual As Group','NCR','Non-Corporate')as enrol_type

    FROM tpa_enr_policy ep
    JOIN tpa_ins_product ip ON (ep.product_seq_id=ip.product_seq_id)
    JOIN tpa_enr_policy_group pg ON (pg.policy_seq_id=ep.policy_seq_id )
    JOIN tpa_enr_policy_member pm ON (pg.policy_group_seq_id=pm.policy_group_seq_id AND pm.tpa_enrollment_id=v_tpa_enr_id)
   START WITH ep.policy_number = v_policy_number
   CONNECT BY nocycle PRIOR ep.renewal_policy_number = ep.policy_number )
   SELECT ht.* FROM tab_bal ht WHERE rnk<6;
   END clm_gen_policy_hist;

   ---====================================================/claim history/=======================
PROCEDURE clm_prev_history(v_tpa_enrollment_id   IN tpa_enr_policy_member.tpa_customer_id%TYPE,
                           v_clm_hist_result     OUT SYS_REFCURSOR ) IS

   BEGIN

  OPEN v_clm_hist_result FOR
  WITH clm_tab AS (
     SELECT rank() over(partition by a.tpa_enrollment_id order by a.claim_seq_id desc) as rnk,
        a.claim_seq_id,
        b.claim_number,
        to_char(b.date_of_admission,'DD-MON-YYYY') as doa,
        to_char(b.date_of_discharge,'DD-MON-YYYY') as dod,
        c.hosp_name,
        substr(replace(replace(f.provisional_diagnosis,chr(13),''),chr(10),' '),1,500) diagnosis,
        e.pre_auth_number,
        b.requested_amount as req_amt,
        b.total_app_amount as appr_amt,
        app.account_info_pkg.get_gen_desc(a.clm_status_general_type_id,'G') as  Claim_Status,
        regexp_replace(g.remarks, '[[:space:]]',' ') as rej_reason

  FROM  clm_enroll_details a
        JOIN clm_general_details b ON (a.claim_seq_id = b.claim_seq_id)
        LEFT OUTER JOIN clm_hospital_association c ON (c.claim_seq_id=b.claim_seq_id)
        LEFT OUTER JOIN pat_enroll_details e ON (e.claim_id=b.claim_seq_id)
        LEFT OUTER JOIN ailment_details f on (f.claim_seq_id=b.claim_seq_id)
        LEFT OUTER JOIN assign_users g On (g.assign_users_seq_id=b.last_assign_user_seq_id)
        WHERE a.tpa_enrollment_id=v_tpa_enrollment_id)
      SELECT * FROM clm_tab t WHERE rnk<=5;

     END;
  ---============================================================//bill details list//==================
  PROCEDURE clm_bill_details(v_claim_seq_id   IN clm_general_details.claim_seq_id%TYPE,
                             v_bill_result    OUT SYS_REFCURSOR ) IS

   BEGIN
   OPEN v_bill_result FOR

   SELECT k.bill_date,k.bill_included_yn,k.bill_issued_by,k.bill_no,k.bills_with_prescription_yn,
          a.description,a.ward_type_id||'#'|| TO_CHAR(capture_number_of_days_yn) AS ward_type_id ,b.ward_description,
          a.requested_amount , a.Allowed_Amount, a.room_type_id, a.number_of_days ,
          a.allow_yn , a.rejected_amount , a.remarks , c.room_description
   FROM clm_bill_header k
   JOIN clm_bill_details a ON (k.clm_bill_seq_id=a.clm_bill_seq_id)
   LEFT OUTER JOIN tpa_hosp_ward_code b ON (a.ward_type_id=b.ward_type_id)
   LEFT OUTER JOIN tpa_hosp_rooms_code c ON (a.room_type_id=c.room_type_id)
   WHERE k.claim_seq_id=v_claim_seq_id;

   END clm_bill_details;
---==============================================================================================
PROCEDURE select_preauth_list (
    v_user_seq_id                    IN  tpa_user_contacts.contact_seq_id%TYPE,
    v_tpa_enrollment_id              IN  clm_enroll_details.tpa_enrollment_id%TYPE,
    v_policy_number                  IN  clm_enroll_details.policy_number%TYPE,
    v_preauth_number                 IN  pat_enroll_details.pre_auth_number%TYPE,
    v_from_date                      IN  VARCHAR2,
    v_to_date                        IN  VARCHAR2,
    v_pat_status_general_type_id     IN  pat_enroll_details.pat_status_general_type_id%TYPE,
    v_tpa_office_seq_id              IN  tpa_office_info.tpa_office_seq_id%TYPE ,
    v_ro_do_code                     IN  tpa_ins_info.ins_comp_code_number%TYPE,
    v_operator                       IN  tpa_ins_prod_policy.ins_pat_operator%TYPE,
    v_recomm_amt                     IN  clm_general_details.requested_amount%TYPE,
    v_pat_status_id                  IN  pat_enroll_details.pat_status_general_type_id%TYPE,    
    v_sort_var                       IN  VARCHAR2,
    v_sort_order                     IN  VARCHAR2,
    v_start_num                      IN  NUMBER ,
    v_end_num                        IN  NUMBER ,
    result_set                       OUT SYS_REFCURSOR )
  IS

    TYPE bind_tab_type IS TABLE OF VARCHAR2(250) INDEX BY BINARY_INTEGER ;
    bind_tab                             bind_tab_type;
    i                                    NUMBER(2) := 0;
    v_where                              VARCHAR2(2000);
    v_sql_str                            VARCHAR2(4000);
    v_cnt                                NUMBER(12);
    v_ins_seq_id                         tpa_ins_info.ins_seq_id%TYPE;
    v_oper_val                           tpa_ins_prod_policy.ins_pat_operator%TYPE;
    v_ins_ro_seq_id                      tpa_ins_info.ins_seq_id%TYPE;
    v_user_ins_seq_id                    tpa_ins_info.ins_seq_id%TYPE;
    v_ins_code                           tpa_ins_info.abbrevation_code%TYPE;
  BEGIN

    v_sql_str :=
       'SELECT
       A.pre_auth_number ,
       A.tpa_enrollment_id ,
       A.claimant_name,
       a.decision_date,
       NVL(B.pat_requested_amount,0) pat_requested_amount,
       NVL(B.total_app_amount,0) total_app_amount,
       H.hosp_name ,
       A.date_of_hospitalization,
       G.description pat_status,
       B.pat_enhanced_yn,
       (CASE WHEN pii.pat_ins_status is null or pii.pat_ins_status =''INP'' then ''Y'' ELSE ''N'' END) as allow_yn,
       B.pat_gen_detail_seq_id,
       B.pat_enroll_detail_seq_id

      FROM pat_enroll_details A
      JOIN pat_general_details B ON (A.pat_enroll_detail_seq_id = b.pat_enroll_detail_seq_id AND b.pat_enhanced_yn=''N'' and b.completed_yn=''N'')
      left outer join pat_ins_intimation_details pii on (a.PAT_ENROLL_DETAIL_SEQ_ID= pii.PAT_ENROLL_DETAIL_SEQ_ID)
      LEFT OUTER JOIN tpa_hosp_info H ON (A.hosp_seq_id = H.hosp_seq_id)
      LEFT OUTER JOIN tpa_enr_policy I ON ( A.policy_seq_id = I.policy_seq_id)
      LEFT OUTER JOIN tpa_general_code G ON (A.pat_status_general_type_id=G.general_type_id) ';
--or A.pat_ins_status =''INP'' modified by purna.
--AND b.pat_enhanced_yn=''N'' modified.
    IF v_tpa_enrollment_id IS NOT NULL THEN
       v_where := v_where   ||' AND A.tpa_enrollment_id = :v_tpa_enrollment_id';
       i := i+1;
       bind_tab(i) := UPPER(v_tpa_enrollment_id);
    END IF;

    IF v_policy_number IS NOT NULL THEN
       v_where := v_where   ||' AND A.policy_number  = :v_policy_number';
       i := i+1;
       bind_tab(i) := UPPER(v_policy_number);
    END IF;

    IF v_preauth_number IS NOT NULL THEN
      v_where := v_where   ||' AND A.pre_auth_number = :v_preauth_number';
       i := i+1;
       bind_tab(i) := UPPER(v_preauth_number);
    END IF;

    IF v_from_date IS NOT NULL THEN
       v_where := v_where   ||' AND A.decision_date >= :v_from_date';
      -- v_where := v_where   ||' AND A.pat_ins_decision_date = :v_from_date';
       i := i+1;
       bind_tab(i) := to_date(v_from_date,'dd/mm/yyyy');
    END IF;

    IF v_to_date IS NOT NULL THEN
       v_where := v_where   ||' AND A.decision_date <= :v_to_date';
       --v_where := v_where   ||' AND A.pat_ins_decision_date <= :v_to_date';
       i := i+1;
       bind_tab(i) := to_date(v_to_date,'dd/mm/yyyy')+1;
    END IF;

    IF v_pat_status_general_type_id IS NOT NULL THEN
       v_where := v_where   ||' AND pii.pat_ins_status  = (CASE  WHEN :v_pat_status_general_type_id=''INP'' THEN ''INP''
                                                                 WHEN :v_pat_status_general_type_id=''TRAD'' AND A.pat_status_general_type_id=''APR'' THEN ''APR''
                                                                 WHEN :v_pat_status_general_type_id=''TRAD'' AND A.pat_status_general_type_id=''REJ'' THEN ''REJ''
                                                                 WHEN :v_pat_status_general_type_id=''TRND'' THEN ''REQ'' END)';
       i := i+1;
       bind_tab(i) :=  v_pat_status_general_type_id ;
       i := i+1;
       bind_tab(i) :=  v_pat_status_general_type_id ;
       i := i+1;
       bind_tab(i) :=  v_pat_status_general_type_id ;
       i := i+1;
       bind_tab(i) :=  v_pat_status_general_type_id ;
    END IF;


    IF v_tpa_office_seq_id IS NOT NULL THEN
       v_where := v_where   ||' AND A.tpa_office_seq_id = :v_tpa_office_seq_id ';
       i := i+1;
       bind_tab(i) := v_tpa_office_seq_id;
    END IF;

    IF v_pat_status_id IS NOT NULL THEN
       v_where := v_where   ||' AND A.pat_status_general_type_id = :v_pat_status_id ';
       i := i+1;
       bind_tab(i) := v_pat_status_id;
    END IF;

     IF v_ro_do_code IS NOT NULL THEN
       SELECT COUNT(1) INTO v_cnt FROM tpa_ins_info where ins_comp_code_number=upper(v_ro_do_code);

        IF v_cnt=0 THEN
         SELECT u.ins_seq_id INTO v_ins_seq_id FROM tpa_user_contacts u WHERE u.contact_seq_id = v_user_seq_id;
        ELSE
          SELECT u.ins_seq_id INTO v_user_ins_seq_id FROM tpa_user_contacts u WHERE u.contact_seq_id = v_user_seq_id;
          SELECT abbrevation_code INTO v_ins_code FROM tpa_ins_info u WHERE u.ins_seq_id=v_user_ins_seq_id;
          SELECT u.ins_seq_id INTO v_ins_ro_seq_id FROM tpa_ins_info u WHERE ins_comp_code_number=upper(v_ro_do_code) and u.abbrevation_code=v_ins_code;
           v_ins_seq_id := greatest(v_user_ins_seq_id,v_ins_ro_seq_id);

       v_where := v_where ||' AND i.ins_seq_id IN (SELECT ins_seq_id FROM tpa_ins_info
                                            START WITH ins_seq_id  = :v_ins_seq_id
                                               CONNECT BY PRIOR ins_seq_id  = ins_parent_seq_id)';
       i := i+1;
       bind_tab(i) := v_ins_seq_id;

        END IF;
      ELSIF v_ro_do_code IS NULL THEN
        SELECT u.ins_seq_id INTO v_ins_seq_id FROM tpa_user_contacts u WHERE u.contact_seq_id = v_user_seq_id;
        --modified.
       v_where := v_where ||' AND i.ins_seq_id IN (SELECT ins_seq_id FROM tpa_ins_info
                                            START WITH ins_seq_id  = :v_ins_seq_id
                                               CONNECT BY PRIOR ins_seq_id  = ins_parent_seq_id)';
       i := i+1;
       bind_tab(i) := v_ins_seq_id;
    END IF;

    IF v_recomm_amt IS NOT NULL  and v_operator is not null THEN
      SELECT DECODE(v_operator,'EQ','=','LT','<=','GT','>=') INTO v_oper_val FROM dual;

       v_where := v_where   ||' AND B.total_app_amount '||v_oper_val||':v_recomm_amt';
       i := i+1;
       bind_tab(i) := v_recomm_amt;
    END IF;

    IF v_where IS NOT NULL THEN
      v_where   := ' WHERE '|| SUBSTR(v_where,5)||' AND A.claim_id IS NULL ';
    END IF;
    v_sql_str := v_sql_str ||v_where;

    v_sql_str := 'SELECT * FROM
          (SELECT A.*, DENSE_RANK() OVER (ORDER BY '||v_sort_var||' '||v_sort_order||',ROWNUM)
          Q FROM (' ||v_sql_str|| ') A ) WHERE Q>= :v_start_num  AND Q<=  :v_end_num ';


    IF bind_tab.FIRST IS NOT NULL THEN
       CASE bind_tab.COUNT
         WHEN 5  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5), v_start_num , v_end_num ;
         WHEN 6  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6), v_start_num , v_end_num ;
         WHEN 7  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6),bind_tab(7), v_start_num , v_end_num ;
         WHEN 8  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6),bind_tab(7),bind_tab(8), v_start_num , v_end_num ;
         WHEN 9  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6),bind_tab(7),bind_tab(8),bind_tab(9), v_start_num , v_end_num ;
         WHEN 10  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6),bind_tab(7),bind_tab(8),bind_tab(9),bind_tab(10), v_start_num , v_end_num ;
         WHEN 11  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6),bind_tab(7),bind_tab(8),bind_tab(9),bind_tab(10),bind_tab(11), v_start_num , v_end_num ;
         WHEN 12  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6),bind_tab(7),bind_tab(8),bind_tab(9),bind_tab(10),bind_tab(11),bind_tab(12), v_start_num , v_end_num ;
         WHEN 13  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6),bind_tab(7),bind_tab(8),bind_tab(9),bind_tab(10),bind_tab(11),bind_tab(12),bind_tab(13), v_start_num , v_end_num ;
         WHEN 14  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6),bind_tab(7),bind_tab(8),bind_tab(9),bind_tab(10),bind_tab(11),bind_tab(12),bind_tab(13),bind_tab(14), v_start_num , v_end_num ;
         WHEN 15  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6),bind_tab(7),bind_tab(8),bind_tab(9),bind_tab(10),bind_tab(11),bind_tab(12),bind_tab(13),bind_tab(14),bind_tab(15), v_start_num , v_end_num ;
         WHEN 16  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6),bind_tab(7),bind_tab(8),bind_tab(9),bind_tab(10),bind_tab(11),bind_tab(12),bind_tab(13),bind_tab(14),bind_tab(15),bind_tab(16), v_start_num , v_end_num ;

       END CASE;
     END IF;

  END select_preauth_list;
---============================================================================================================
---        START FOR PRE_AUTH APPROVAL DETAILS
---===========================================================================================================
PROCEDURE select_preauth_web (v_pat_gen_detail_seq_id    IN  pat_general_details.pat_gen_detail_seq_id%TYPE,
                              v_pat_xml                  OUT XMLTYPE,
                              v_ins_status               OUT pat_ins_intimation_details.pat_ins_status%TYPE,
                              v_ins_remarks              out pat_ins_intimation_details.pat_ins_remarks%type) IS

 v_doc              dbms_xmldom.DOMDocument;
 v_main_node        dbms_xmldom.DOMNode;
 v_clm_node         dbms_xmldom.DOMNode;
 v_ins_node         dbms_xmldom.DOMNode;
 v_root_node        dbms_xmldom.DOMNode;
 v_chld_node        dbms_xmldom.DOMNode;
 v_chld_node2       dbms_xmldom.DOMNode;
 v_chld_node3       dbms_xmldom.DOMNode;
 v_node             dbms_xmldom.domnode;
 v_elem             dbms_xmldom.DOMElement;
 v_out_xml          sys.xmltype;

 v_clob            CLOB;

  TYPE tab IS VARRAY(5) OF VARCHAR2(10);
  rec_tab      tab:=tab('ROOM','PROF','OTHER','NA');

   v_buff_app_amt                           buffer_header.buff_app_amt%type:=pre_auth_pkg.get_buff_apr_amt(v_pat_gen_detail_seq_id,'PAT','CORP_BUFF') ;
   v_med_buff_app_amt                       buffer_header.buff_app_amt%type:=pre_auth_pkg.get_buff_apr_amt(v_pat_gen_detail_seq_id,'PAT','MED_BUFF') ;	
   v_crit_buff_app_amt                      buffer_header.buff_app_amt%type:=pre_auth_pkg.get_buff_apr_amt(v_pat_gen_detail_seq_id,'PAT','CRIT_BUFF') ;
   v_crit_corp_buff_app_amt                 buffer_header.buff_app_amt%type:=pre_auth_pkg.get_buff_apr_amt(v_pat_gen_detail_seq_id,'PAT','CRIT_CORP_BUFF') ;
   v_crit_med_buff_app_amt                  buffer_header.buff_app_amt%type:=pre_auth_pkg.get_buff_apr_amt(v_pat_gen_detail_seq_id,'PAT','CRIT_MED_BUFF') ;

 CURSOR cur_clm IS
SELECT   pg.pat_gen_detail_seq_id,
         pe.pre_auth_number         claim_no,
         peg.insured_name           proposer_name,
         pe.claimant_name           patient_name,
         peg.employee_no            employee_customer_id,
         pe.tpa_enrollment_id       tpa_id,
         round(pe.mem_age)          patient_age,
         app.account_info_pkg.get_gen_desc(pem.relship_type_id,'R')        Relation,
         app.account_info_pkg.get_gen_desc(pem.gender_general_type_id,'G') Gender,
         pol.policy_number          policy_no,
         tgr.group_name||'--'||tip.product_name  product_name,
         to_char(pol.effective_from_date,'DD-MON-YYYY')  policy_form,
         to_char(pol.effective_to_date,'DD-MON-YYYY')    policy_upto,
         eb.sum_insured,
         --pem.mem_tot_bonus as bonus,
         CASE WHEN POL.POLICY_SUB_GENERAL_TYPE_ID ='PFL' THEN peg.FLOATER_TOT_BONUS ELSE pem.mem_tot_bonus END as bonus,
         nvl(pol.buffer_alloc_amount,pem.mem_tot_bonus)   buffer_bonus,
         ma.address_1||' '||ma.address_2||' '||ma.address_3 address,
         to_char(pg.pat_received_date,'DD-MON-YYYY') intimation_date,
         to_char(pg.pat_received_date,'DD-MON-YYYY') date_of_doc_rec,
         to_char(pe.date_of_hospitalization,'DD-MON-YYYY') loss_date,
         hi.hosp_name hospital_name,
         NVL(app.account_info_pkg.get_gen_desc(HA.CITY_TYPE_ID,'CT') , ha.city )     hospital_city,
         NVL(app.account_info_pkg.get_gen_desc(HA.STATE_TYPE_ID,'S'), ha.state)     hospital_state,
         ha.pin_code  hospital_pincode,
         substr(replace(replace(al.provisional_diagnosis,chr(13),''),chr(10),' '),1,500) diagnosis,
         f_icd_code_desc_pat(pg.pat_gen_detail_seq_id,'IC','IC1') diagnosis_code_level_1,
         f_icd_code_desc_pat(pg.pat_gen_detail_seq_id,'IC','IC2') diagnosis_code_level_2,
         f_icd_code_desc_pat(pg.pat_gen_detail_seq_id,'IC','ID1') diagnosis_description_level_1,
         f_icd_code_desc_pat(pg.pat_gen_detail_seq_id,'IC','ID2') diagnosis_description_level_2,

         f_icd_code_desc_pat(pg.pat_gen_detail_seq_id,'PC','PC1') procedure_codes_level_1,
         f_icd_code_desc_pat(pg.pat_gen_detail_seq_id,'PC','PC2') procedure_codes_level_2,
         f_icd_code_desc_pat(pg.pat_gen_detail_seq_id,'PC','PD1') procedure_description_level_1,
         f_icd_code_desc_pat(pg.pat_gen_detail_seq_id,'PC','PD2') procedure_description_level_2,
         to_char(pg.likely_date_of_hospitalization,'DD-MON-YYYY') doa,
         to_char((pg.likely_date_of_hospitalization+al.duration_of_hospitalization),'DD-MON-YYYY') dod,
         'CASHLESS' claim_type,
         app.account_info_pkg.get_gen_desc(pg.pat_general_type_id,'G') claim_category,
         app.account_info_pkg.get_gen_desc(pol.enrol_type_id,'E') policy_type,
         pg.pat_requested_amount estimate_amt,
         pg.total_app_amount claim_amount,
         NVL(ROUND((SELECT SUM(approved_amount)
              FROM ailment_caps x JOIN icd_pcs_detail y ON ( x.icd_pcs_seq_id = y.icd_pcs_seq_id )
              WHERE y.pat_gen_detail_seq_id= pg.pat_gen_detail_seq_id)),0) recommend_amount,
         NVL(pg.co_payment_amount,0)+nvl(pg.co_payment_buffer_amount,0) co_pay_amount,
         NVL(ROUND((SELECT SUM(approved_amount)
              FROM ailment_caps x JOIN icd_pcs_detail y ON ( x.icd_pcs_seq_id = y.icd_pcs_seq_id )
              WHERE y.pat_gen_detail_seq_id= pg.pat_gen_detail_seq_id)),0) AS approved_amount,
         pg.pat_requested_amount-nvl(pg.total_app_amount,0) deducted_amount,
         '' deduction_reason,
         '0' compulsary_deduction,
         '0' service_tax_amount,
         hi.serv_tax_rgn_number service_tax_no,
         nvl(pg.total_app_amount,'0') payble_amount,
         0 tds_amount,
         0 net_payble_amt,
         to_char(PII.PAT_INS_SEND_DATE,'DD-MON-YYYY') recommend_on,
         to_char(pe.decision_date,'DD-MON-YYYY') approved_on,
         0 pay_to_insured,
         nvl(pg.total_app_amount,0) pay_to_hospital,
         v_buff_app_amt Buff_App_Amt,
         v_med_buff_app_amt Med_Buff_App_Amt,
         v_crit_buff_app_amt Crit_Buff_App_Amt,
         v_crit_corp_buff_app_amt Crit_Corp_Buff_App_Amt,
         v_crit_med_buff_app_amt Crit_Med_Buff_App_Amt,        
         nvl(CASE WHEN nvl(pe.claim_id,0)=0 then v_buff_app_amt else CASE WHEN nn2.pre_auth_buffer_app_amount>0 then CASE WHEN nvl(NN2.Utilised_Amount,0)< 0 THEN v_Buff_App_Amt + nvl(NN2.Utilised_Amount,0) ELSE NN2.Utilised_Amount end   else 0 end end,0) as Utilised_Amount,
         nvl(CASE WHEN nvl(pe.claim_id,0)=0 then v_med_buff_app_amt else CASE WHEN nn2.pre_auth_buffer_app_amount>0 then CASE WHEN nvl(NN2.Utilised_Med_Amount,0)< 0 THEN v_Med_Buff_App_Amt + nvl(NN2.Utilised_Med_Amount,0) ELSE NN2.Utilised_Med_Amount end   else 0 end  end,0) as Utilised_Med_Amount,
         nvl(CASE WHEN nvl(pe.claim_id,0)=0 then v_crit_buff_app_amt else CASE WHEN nn2.pre_auth_buffer_app_amount>0 then CASE WHEN nvl(NN2.Utilised_Crit_Amount,0)< 0 THEN v_Crit_Buff_App_Amt + nvl(NN2.Utilised_Crit_Amount,0) ELSE  NN2.Utilised_Crit_Amount end   else 0 end  end,0) as Utilised_Crit_Amount,
         nvl(CASE WHEN nvl(pe.claim_id,0)=0 then v_crit_corp_buff_app_amt else CASE WHEN nn2.pre_auth_buffer_app_amount>0 then CASE WHEN nvl(NN2.Utilised_Crit_Corp_Amount,0)< 0 THEN v_Crit_Corp_Buff_App_Amt + nvl(NN2.Utilised_Crit_Corp_Amount,0) ELSE NN2.Utilised_Crit_Corp_Amount end   else 0 end  end,0) as Utilised_Crit_Corp_Amount,
         nvl(CASE WHEN nvl(pe.claim_id,0)=0 then v_crit_med_buff_app_amt else CASE WHEN nn2.pre_auth_buffer_app_amount>0 then CASE WHEN nvl(NN2.Utilised_Crit_Med_Amount,0)< 0 THEN v_Crit_Med_Buff_App_Amt + nvl(NN2.Utilised_Crit_Med_Amount,0) ELSE NN2.Utilised_Crit_Med_Amount end   else 0 end  end,0) as Utilised_Crit_Med_Amount,
         NULL cheque_no,
         NULL cheque_date,
         hi.hosp_name clm_pay_to_beneficiary_name,
         fn_sfremarks_pat(pg.pat_gen_detail_seq_id) disc_datails,
        -- get_srtfall_remarks('CHECKBOX','PAT',PG.PAT_GEN_DETAIL_SEQ_ID)||case when get_srtfall_remarks('OTHERS','PAT',PG.PAT_GEN_DETAIL_SEQ_ID)  is not null then ' ******* Other Queries: '||get_srtfall_remarks('OTHERS','PAT',PG.PAT_GEN_DETAIL_SEQ_ID) end AS  disc_datails,

         to_char(sf.min_sfdt,'DD-MON-YYYY') insured_disc_date,
         to_char(sf.max_sfdt,'DD-MON-YYYY') insured_reminder_date,
         to_char(sf.max_sfdt,'DD-MON-YYYY') insured_final_reminder_date,
         to_char(sf.sf_responded_dt,'DD-MON-YYYY') insured_reply_recieved_date,
         NULL hospital_disc_date,
         NULL hospital_reminder_date,
         NULL hospital_final_reminder_date,
         NULL hospital_reply_recieved_date,
         NULL insurer_disc_date,
         NULL insurer_reminder_date,
         NULL insurer_final_reminder_date,
         NULL insurer_reply_recieved_date,
         to_char(pg.pat_received_date,'DD-MON-YYYY') pre_auth_received_on,
         pe.pre_auth_number  pre_auth_letter_no,
         app.account_info_pkg.get_gen_desc(pe.pat_status_general_type_id,'G') pre_auth_status,
         nvl(pg.total_app_amount,'0') pre_auth_amount,
         to_char(pe.decision_date,'DD-MON-YYYY') pre_auth_approved_on,
         NULL float_no,
         NULL float_date,
         NULL payment_date,
         '0' agent_code,
         pol.dev_officer_code development_code,
         tii.ins_comp_name  operating_office,
         tii.ins_comp_code_number  operating_code,
         NVL(app.account_info_pkg.get_gen_desc(tas.City_Type_Id,'CT'),TAS.CITY)  ins_city,
         NVL(app.account_info_pkg.get_gen_desc(tas.State_Type_Id,'S'),TAS.STATE)  ins_state,
          tas.pin_code ins_pincode,
         NULL controlling_office,
         tii.ins_comp_name  insurance_company,
         NULL settelement_type,
         NULL settelement_date,
         regexp_replace(au.remarks, '[[:space:]]',' ') as repudiation_rejection_reason,
         pe.pat_status_general_type_id AS status,
         NULL benefit_type,
         NULL bill_entered_by,
         NULL bill_entry_location,
         hi.empanel_number hospital_code,
         pe.member_seq_id,
         peg.tpa_enrollment_number enr_num,
         'Bangalore' as premium_zone,
         regexp_replace(au.remarks, '[[:space:]]',' ') remarks,
         al.added_date,
         pII.pat_ins_remarks,
         PII.PAT_ins_status,
         pe.PAT_status_general_type_id,
         idd.investigation_id,
         idd.investigated_by investigated_by ,
         idd.investigated_date,
         idd.general_remarks||'--'||idd.invst_remarks as invst_remarks

     FROM pat_general_details pg
          JOIN pat_enroll_details pe ON (pe.pat_enroll_detail_seq_id=pg.pat_enroll_detail_seq_id)
          left outer join pat_ins_intimation_details pii on (pe.PAT_ENROLL_DETAIL_SEQ_ID= pii.pat_auth_seq_id)
          JOIN assign_users au ON (au.assign_users_seq_id=pg.last_assign_user_seq_id)
          JOIN tpa_enr_policy pol ON (pol.policy_seq_id=pe.policy_seq_id)
          JOIN tpa_enr_policy_member pem ON (pem.member_seq_id=pe.member_seq_id)
          JOIN tpa_enr_policy_group peg  ON (peg.policy_group_seq_id=pem.policy_group_seq_id)
          JOIN tpa_ins_product tip ON (tip.product_seq_id=pol.product_seq_id)
          JOIN tpa_enr_mem_address ma ON (peg.enr_address_seq_id=ma.enr_address_seq_id)
          JOIN tpa_enr_balance eb ON (eb.policy_group_seq_id=peg.policy_group_seq_id)
          JOIN tpa_hosp_info  hi ON (pe.hosp_seq_id=hi.hosp_seq_id)
          JOIn tpa_hosp_address ha ON (ha.hosp_seq_id=hi.hosp_seq_id)
          LEFT OUTER JOIN tpa_city_code tcc ON (tcc.city_type_id=ha.city_type_id)
          LEFT OUTER JOIN tpa_state_code tsc ON (tsc.state_type_id=ha.state_type_id)
          JOIN tpa_ins_info tii ON (tii.ins_seq_id=pe.ins_seq_id)
          JOIN tpa_address tas on (tas.ins_seq_id=tii.ins_seq_id)
          LEFT OUTER JOIN tpa_group_registration tgr on (tgr.group_reg_seq_id=pol.group_reg_seq_id)
          LEFT OUTER JOIN ailment_details al ON (al.pat_gen_detail_seq_id=pg.pat_gen_detail_seq_id)
          LEFT OUTER JOIN investigation_details idd ON(idd.pat_gen_detail_seq_id=pg.pat_gen_detail_seq_id)
          LEFT OUTER JOIN (SELECT  sd.pat_gen_detail_seq_id pat_id, MIN (sd.added_date) min_sfdt,
                                   MAX(sd.added_date) max_sfdt, MAX(sd.closed_date) sf_closeddt,
                                   MAX(sd.srtfll_received_date) SF_Responded_Dt
                           FROM shortfall_details sd
                           GROUP BY sd.pat_gen_detail_seq_id) sf ON (sf.pat_id = pg.pat_gen_detail_seq_id)
          left outer join buffer_details bd on (pg.last_buffer_detail_seq_id=bd.buff_detail_seq_id)
          left outer join buffer_header NN2 on (bd.buffer_hdr_seq_id=NN2.buffer_hdr_seq_id)    
    WHERE pg.pat_gen_detail_seq_id=v_pat_gen_detail_seq_id--'6213480'
    AND (pem.mem_general_type_id = 'PFL'
    AND eb.member_seq_id IS NULL OR pem.member_seq_id = eb.member_seq_id OR pem.member_seq_id IS NULL);

  clm_rec   cur_clm%ROWTYPE;

  /*CURSOR cur_bills(v_seq_id           clm_general_details.claim_seq_id%TYPE,
                   v_charges_type     tpa_hosp_ward_code.ward_type_id%TYPE) IS
  WITH bv AS(
  SELECT  g.pat_gen_detail_seq_id,
          d.ward_type_id,
          CASE WHEN d.ward_type_id IN('BED','DMO','DRC','ICN','ICR','IJC','NUC','RMO','ROO') THEN 'ROOM'
               WHEN d.ward_type_id IN('ANC','ASC','CDL','CON','DLC','EME','ICU','ICC','NDL','OPC','PYC','POC','PRO','SPE','SUF') THEN 'PROF'
               WHEN d.ward_type_id IN('ADC','ADM','ATN','BIC','CTL','COB','DIS','DEC','DSC','DOB','FDC','HAA','HVC','MLC','MIS','PDC','REF','SEC','STC','SUR','WCW','WCC') THEN 'NA'
               ELSE 'OTHER' END charges_type,
          ji.ward_description AS charges,
          SUM(d.approved_amount) AS amt
        FROM pat_general_details g
           INNER JOIN pat_enroll_details e ON (e.pat_enroll_detail_seq_id=g.pat_enroll_detail_seq_id)
           LEFT OUTER JOIN pat_tariff_details d ON (d.pat_gen_detail_seq_id=g.pat_gen_detail_seq_id)
           LEFT OUTER JOIN tpa_hosp_ward_code ji ON (ji.ward_type_id=d.ward_type_id)
           WHERE g.pat_gen_detail_seq_id=v_seq_id and d.approved_amount>0
           GROUP BY g.pat_gen_detail_seq_id,d.ward_type_id,ji.ward_description)
      SELECT * FROM bv WHERE charges_type =v_charges_type;*/

  CURSOR cur_pol(v_tpa_enr_no   tpa_enr_policy_group.tpa_enrollment_number%TYPE,
                 v_pol_no       tpa_enr_policy.policy_number%TYPE ) IS
  WITH tab_bal AS (
     SELECT rank() over(PARTITION BY pg.tpa_enrollment_number ORDER BY pg.policy_group_seq_id DESC) AS rnk,
         pg.policy_group_seq_id,
         ep.policy_number,
         ep.renewal_policy_number,
         ep.effective_from_date,
         ep.effective_to_date,
         ep.policy_rcvd_date,
         (CASE WHEN ep.policy_sub_general_type_id='PFL' THEN pg.family_tot_sum_insured ELSE pm.mem_tot_sum_insured END) sum_insured,
         ep.renew_count as policy_renew_count,
         ep.policy_seq_id,
         app.account_info_pkg.get_gen_desc(ep.policy_sub_general_type_id,'G') as policy_subtype,
         ip.product_name,
         DECODE(ep.enrol_type_id,'COR','Corporate','IND','Individual','ING','Individual As Group','NCR','Non-Corporate')as enrol_type

    FROM tpa_enr_policy ep
    JOIN tpa_ins_product ip on (ep.product_seq_id=ip.product_seq_id)
    JOIN tpa_enr_policy_group pg on (pg.policy_seq_id=ep.policy_seq_id )
    JOIN tpa_enr_policy_member pm on (pg.policy_group_seq_id=pm.policy_group_seq_id and pm.tpa_enrollment_id=v_tpa_enr_no)
   START WITH ep.policy_number = v_pol_no
   CONNECT BY nocycle PRIOR ep.renewal_policy_number = ep.policy_number )
 SELECT ht.* FROM tab_bal ht WHERE rnk<6;

  CURSOR cur_hist(v_enr_id    clm_enroll_details.tpa_enrollment_id%TYPE) IS
  WITH clm_tab AS (
     SELECT rank() over(partition by a.tpa_enrollment_id order by b.pat_gen_detail_seq_id desc) as rnk,
        b.pat_gen_detail_seq_id,
        a.pre_auth_number claim_number,
        a.pre_auth_number,
        to_char(a.date_of_hospitalization,'DD-MON-YYYY') as doa,
        to_char((a.date_of_hospitalization+f.duration_of_hospitalization),'DD-MON-YYYY') as dod,
        hi.hosp_name,
        substr(replace(replace(f.provisional_diagnosis,chr(13),''),chr(10),' '),1,500) diagnosis,
        b.pat_requested_amount as req_amt,
        b.total_app_amount as appr_amt,
        app.account_info_pkg.get_gen_desc(a.pat_status_general_type_id,'G') as  Claim_Status,
        regexp_replace(g.remarks, '[[:space:]]',' ') as rej_reason

  FROM  pat_enroll_details a
        JOIN pat_general_details b ON (a.pat_enroll_detail_seq_id = b.pat_enroll_detail_seq_id and b.pat_enhanced_yn='N')
        JOIN tpa_hosp_info hi ON (hi.hosp_seq_id=a.hosp_seq_id)
        LEFT OUTER JOIN ailment_details f on (f.pat_gen_detail_seq_id=b.pat_gen_detail_seq_id)
        LEFT OUTER JOIN assign_users g On (g.assign_users_seq_id=b.last_assign_user_seq_id)
        WHERE a.tpa_enrollment_id=v_enr_id)
       SELECT * FROM clm_tab t WHERE rnk<=5;


  CURSOR cur_bills(v_seq_id           clm_general_details.claim_seq_id%TYPE)  IS

  SELECT  g.pat_gen_detail_seq_id,
          d.ward_type_id,
          ji.ward_description AS description,
          d.requested_amount As req_amt,
          d.approved_amount AS allow_amt,
          d.maximum_allowed_amount,
          d.room_type_id,
          rc.room_description,
          d.days_of_stay
        FROM pat_general_details g
           INNER JOIN pat_enroll_details e ON (e.pat_enroll_detail_seq_id=g.pat_enroll_detail_seq_id)
           LEFT OUTER JOIN pat_tariff_details d ON (d.pat_gen_detail_seq_id=g.pat_gen_detail_seq_id)
           LEFT OUTER JOIN tpa_hosp_ward_code ji ON (ji.ward_type_id=d.ward_type_id)
           LEFT OUTER JOIN tpa_hosp_rooms_code rc ON (rc.room_type_id=d.room_type_id)
        WHERE g.pat_gen_detail_seq_id=v_seq_id ;--and d.approved_amount>0;


  v_pat_req_amt      pat_general_details.pat_requested_amount%TYPE;
  v_clm_remarks      clm_general_details.claims_remarks%TYPE;
  v_out              VARCHAR2(128);
  i                  Pls_Integer :=1;


 BEGIN
     OPEN cur_clm;
     FETCH cur_clm INTO clm_rec;
     CLOSE cur_clm;

     IF clm_rec.pre_auth_letter_no!='O1B' THEN
       SELECT gd.pat_requested_amount INTO v_pat_req_amt
       FROM Pat_Enroll_Details ed
       JOIN Pat_General_Details gd ON ed.pat_enroll_detail_seq_id=gd.pat_enroll_detail_seq_id
       WHERE ed.pre_auth_number=clm_rec.pre_auth_letter_no AND gd.pat_enhanced_yn='N';
    END IF;

    SELECT NVL(hy.remarks,'')INTO v_clm_remarks FROM pat_general_details hy WHERE pat_gen_detail_seq_id=v_pat_gen_detail_seq_id;

     v_doc     := dbms_xmldom.newDOMDocument;
    dbms_xmldom.setVersion(v_doc,'1.0" encoding="UTF-8' );
    v_root_node := dbms_xmldom.makeNode(v_doc);

    v_elem   := dbms_xmldom.createElement(v_doc,'CLAIMSAPPOVALFORM');
    v_node   := dbms_xmldom.makeNode(v_elem);
    v_main_node := dbms_xmldom.appendChild(v_root_node,v_node);

    v_elem := dbms_xmldom.createElement(v_doc,'CLAIMDETAILS');
    v_node := dbms_xmldom.makeNode(v_elem);
    v_chld_node := dbms_xmldom.appendChild(v_main_node,v_node);

    v_elem  := dbms_xmldom.createElement(v_doc,'CLAIM_DATA');  --claims data
    v_clm_node := dbms_xmldom.makeNode(v_elem);
    dbms_xmldom.SetAttribute(v_elem,'claimnumber',clm_rec.Claim_No);
    dbms_xmldom.setAttribute(v_elem,'preauthnumber',clm_rec.pre_auth_letter_no);
    dbms_xmldom.setAttribute(v_elem,'vidalhealthttkid',clm_rec.tpa_id);
    dbms_xmldom.setAttribute(v_elem,'claimtype',clm_rec.claim_type);
    dbms_xmldom.setAttribute(v_elem,'claimcategory',clm_rec.claim_category);
    dbms_xmldom.setAttribute(v_elem,'receivedon',clm_rec.date_of_doc_rec);
    dbms_xmldom.setAttribute(v_elem,'recommededon',clm_rec.recommend_on);
    dbms_xmldom.setAttribute(v_elem,'req_claim_amt',clm_rec.estimate_amt);
    dbms_xmldom.setAttribute(v_elem,'recommended',clm_rec.recommend_amount);
    dbms_xmldom.setAttribute(v_elem,'nonadmissable',0); --rework
    dbms_xmldom.setAttribute(v_elem,'copay',clm_rec.co_pay_amount);
    dbms_xmldom.setAttribute(v_elem,'voluntary_copay',0);
    dbms_xmldom.setAttribute(v_elem,'payable',clm_rec.payble_amount);
    dbms_xmldom.setAttribute(v_elem,'tds',clm_rec.tds_amount);
    dbms_xmldom.setAttribute(v_elem,'notpayable',clm_rec.deducted_amount);
    dbms_xmldom.setAttribute(v_elem,'deduction_reason',clm_rec.deduction_reason);
    dbms_xmldom.setAttribute(v_elem,'enr_number',clm_rec.enr_num);
    v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_clm_node);

    v_elem := dbms_xmldom.createElement(v_doc,'INSURANCEDETAILS');--inscomp details
    v_node := dbms_xmldom.makeNode(v_elem);
    v_chld_node := dbms_xmldom.appendChild(v_main_node,v_node);

    v_elem := dbms_xmldom.createElement(v_doc,'INSCOMP');
    v_ins_node :=dbms_xmldom.makenode(v_elem);
    dbms_xmldom.setAttribute(v_elem,'insurancecompany',clm_rec.insurance_company);
    dbms_xmldom.setAttribute(v_elem,'controllingoffice',clm_rec.controlling_office);
    dbms_xmldom.setAttribute(v_elem,'city',clm_rec.ins_city);
    dbms_xmldom.setAttribute(v_elem,'state',clm_rec.ins_state);
    dbms_xmldom.setAttribute(v_elem,'pincode',clm_rec.ins_pincode);
    v_chld_node2 := dbms_xmldom.appendChild(v_chld_node,v_ins_node);


    v_elem := dbms_xmldom.createElement(v_doc,'POLICYDETAILS'); --policy details
    v_node := dbms_xmldom.makeNode(v_elem);
    v_chld_node := dbms_xmldom.appendChild(v_main_node,v_node);

    v_elem := dbms_xmldom.createElement(v_doc,'POLICYDATA');
    v_ins_node :=dbms_xmldom.makenode(v_elem);
    dbms_xmldom.setAttribute(v_elem,'prm_insured',clm_rec.proposer_name);
    dbms_xmldom.setAttribute(v_elem,'customerid',clm_rec.employee_customer_id);
    dbms_xmldom.setAttribute(v_elem,'policynumber',clm_rec.policy_no);
    dbms_xmldom.setAttribute(v_elem,'policystart',clm_rec.policy_form);
    dbms_xmldom.setAttribute(v_elem,'policyend',clm_rec.policy_upto);
    dbms_xmldom.setAttribute(v_elem,'policytype',clm_rec.policy_type);
    dbms_xmldom.setAttribute(v_elem,'productname',clm_rec.product_name);
    dbms_xmldom.setAttribute(v_elem,'agentcode',clm_rec.agent_code);
    dbms_xmldom.setAttribute(v_elem,'devoffcode',clm_rec.development_code);
    dbms_xmldom.setAttribute(v_elem,'operoffcode',clm_rec.operating_code);
    dbms_xmldom.setAttribute(v_elem,'operoffice',clm_rec.operating_office);
    dbms_xmldom.setAttribute(v_elem,'suminsured',clm_rec.sum_insured);
    dbms_xmldom.setAttribute(v_elem,'cummbonus',clm_rec.bonus);
    dbms_xmldom.setAttribute(v_elem,'corbuffer',clm_rec.buff_app_amt);
    dbms_xmldom.setAttribute(v_elem,'medbuffer',clm_rec.med_buff_app_amt);
    dbms_xmldom.setAttribute(v_elem,'critbuffer',clm_rec.crit_buff_app_amt);
    dbms_xmldom.setAttribute(v_elem,'critcorbuffer',clm_rec.crit_corp_buff_app_amt);
    dbms_xmldom.setAttribute(v_elem,'critmedbuffer',clm_rec.crit_med_buff_app_amt);
   
    dbms_xmldom.setAttribute(v_elem,'premzone',clm_rec.premium_zone);
    dbms_xmldom.setAttribute(v_elem,'payblefrom','');
    v_chld_node2 := dbms_xmldom.appendChild(v_chld_node,v_ins_node);

    v_elem := dbms_xmldom.createElement(v_doc,'POLICYHISTORY');--POLICY HISTORY
    v_node := dbms_xmldom.makeNode(v_elem);
    v_chld_node := dbms_xmldom.appendChild(v_main_node,v_node);

   FOR rk IN cur_pol(clm_rec.tpa_id,clm_rec.policy_no) LOOP

    v_elem := dbms_xmldom.createElement(v_doc,'POLHISTORY');
    v_ins_node :=dbms_xmldom.makenode(v_elem);
    dbms_xmldom.setAttribute(v_elem,'policynumber',rk.policy_number);
    dbms_xmldom.setAttribute(v_elem,'policytype',rk.enrol_type);
    dbms_xmldom.setAttribute(v_elem,'productname',rk.product_name);
    dbms_xmldom.setAttribute(v_elem,'from',rk.effective_from_date);
    dbms_xmldom.setAttribute(v_elem,'to',rk.effective_to_date);
    dbms_xmldom.setAttribute(v_elem,'suminsured',rk.sum_insured);
    v_chld_node2 := dbms_xmldom.appendChild(v_chld_node,v_ins_node);

    END LOOP;

    v_elem := dbms_xmldom.createElement(v_doc,'CLAIMANTDETAILS');--claimant details
    v_node := dbms_xmldom.makeNode(v_elem);
    v_chld_node := dbms_xmldom.appendChild(v_main_node,v_node);

    v_elem := dbms_xmldom.createElement(v_doc,'CLAIMANT');
    v_ins_node :=dbms_xmldom.makenode(v_elem);
    dbms_xmldom.setAttribute(v_elem,'claimantname',clm_rec.patient_name);
    dbms_xmldom.setAttribute(v_elem,'age',clm_rec.patient_age);
    dbms_xmldom.setAttribute(v_elem,'sex',clm_rec.gender);
    dbms_xmldom.setAttribute(v_elem,'relation',clm_rec.relation);
    dbms_xmldom.setAttribute(v_elem,'address',clm_rec.address);
    dbms_xmldom.setAttribute(v_elem,'vidal_ttkid',clm_rec.tpa_id);
    v_chld_node2 := dbms_xmldom.appendChild(v_chld_node,v_ins_node);

    v_elem := dbms_xmldom.createElement(v_doc,'CLAIMHISTORY');--CLAIM HISTORY
    v_node := dbms_xmldom.makeNode(v_elem);
    v_chld_node := dbms_xmldom.appendChild(v_main_node,v_node);

   FOR rk IN cur_hist(clm_rec.tpa_id) LOOP  --for claim history
      v_elem := dbms_xmldom.createElement(v_doc,'CLMHISTORY');
      v_ins_node :=dbms_xmldom.makenode(v_elem);
      dbms_xmldom.setAttribute(v_elem,'claimnumber',rk.claim_number);
      dbms_xmldom.setAttribute(v_elem,'doa',rk.doa);
      dbms_xmldom.setAttribute(v_elem,'dod',rk.dod);
      dbms_xmldom.setAttribute(v_elem,'hospname',rk.hosp_name);
      dbms_xmldom.setAttribute(v_elem,'prenumber',rk.pre_auth_number);
      dbms_xmldom.setAttribute(v_elem,'claimed',rk.req_amt);
      dbms_xmldom.setAttribute(v_elem,'approved',rk.appr_amt);
      dbms_xmldom.setAttribute(v_elem,'status',rk.claim_status);
      dbms_xmldom.setAttribute(v_elem,'ailment',rk.diagnosis);
      dbms_xmldom.setAttribute(v_elem,'rejreason',rk.rej_reason);
      v_chld_node2 := dbms_xmldom.appendChild(v_chld_node,v_ins_node);
   END LOOP;

 --->   HOSPITLIZATIONDETAILS

    v_elem := dbms_xmldom.createElement(v_doc,'HOSPITLIZATIONDETAILS');--claimant details
    v_node := dbms_xmldom.makeNode(v_elem);
    v_chld_node := dbms_xmldom.appendChild(v_main_node,v_node);

    v_elem := dbms_xmldom.createElement(v_doc,'HOSPDET');
    v_ins_node :=dbms_xmldom.makenode(v_elem);
    dbms_xmldom.setAttribute(v_elem,'intdate',clm_rec.intimation_date);
    dbms_xmldom.setAttribute(v_elem,'datediag',clm_rec.loss_date);
    dbms_xmldom.setAttribute(v_elem,'admssion',clm_rec.doa);
    dbms_xmldom.setAttribute(v_elem,'discharge',clm_rec.dod);
    dbms_xmldom.setAttribute(v_elem,'hospname',clm_rec.hospital_name);
    dbms_xmldom.setAttribute(v_elem,'hospcode',clm_rec.hospital_code);
    dbms_xmldom.setAttribute(v_elem,'city',clm_rec.hospital_city);
    dbms_xmldom.setAttribute(v_elem,'state',clm_rec.hospital_state);
    dbms_xmldom.setAttribute(v_elem,'pincode',clm_rec.hospital_pincode);
    dbms_xmldom.setAttribute(v_elem,'diagnosis',clm_rec.diagnosis);
    dbms_xmldom.setAttribute(v_elem,'diagclvl1',clm_rec.diagnosis_code_level_1);
    dbms_xmldom.setAttribute(v_elem,'diagclvl2',clm_rec.diagnosis_code_level_2);
    dbms_xmldom.setAttribute(v_elem,'procclvl1',clm_rec.procedure_codes_level_1);
    dbms_xmldom.setAttribute(v_elem,'procclvl2',clm_rec.procedure_codes_level_2);

    dbms_xmldom.setAttribute(v_elem,'diagdlvl1',clm_rec.diagnosis_description_level_1);
    dbms_xmldom.setAttribute(v_elem,'diagdlvl2',clm_rec.diagnosis_description_level_2);
    dbms_xmldom.setAttribute(v_elem,'procdlvl1',clm_rec.procedure_description_level_1);
    dbms_xmldom.setAttribute(v_elem,'procdlvl2',clm_rec.procedure_description_level_2);
    v_chld_node2 := dbms_xmldom.appendChild(v_chld_node,v_ins_node);

 --->>> Billing Details
     v_elem := dbms_xmldom.createElement(v_doc,'BILLINGDETAILS');
     v_node := dbms_xmldom.makenode(v_elem);
     v_chld_node :=  dbms_xmldom.appendChild(v_main_node,v_node);

     v_elem  := dbms_xmldom.createElement(v_doc, 'BILLHEADER');
     v_ins_node := dbms_xmldom.makeNode(v_elem);
     dbms_xmldom.setAttribute(v_elem,'billno','');
     dbms_xmldom.setAttribute(v_elem,'bill_date',clm_rec.added_date);
     dbms_xmldom.setAttribute(v_elem,'bill_inc_yn','N');
     dbms_xmldom.setAttribute(v_elem,'bill_iss_by','');
     dbms_xmldom.setattribute(v_elem,'bill_pres_yn','N');
     v_chld_node2 := dbms_xmldom.appendChild(v_chld_node, v_ins_node);

    FOR bh IN cur_bills(clm_rec.pat_gen_detail_seq_id) LOOP
     v_elem := dbms_xmldom.createElement(v_doc,'BILLS');
     v_ins_node := dbms_xmldom.makeNode(v_elem);
     dbms_xmldom.setAttribute(v_elem,'description',i||'.');
     dbms_xmldom.setattribute(v_elem,'acchead',bh.description);
     dbms_xmldom.setattribute(v_elem,'reqamt',bh.req_amt);
     dbms_xmldom.setattribute(v_elem,'allowamt',bh.allow_amt);
     dbms_xmldom.setAttribute(v_elem,'roomtype',bh.room_description);
     dbms_xmldom.setAttribute(v_elem,'nodays',bh.days_of_stay);
     dbms_xmldom.setAttribute(v_elem,'rejamt',(bh.req_amt-bh.allow_amt));
     dbms_xmldom.setAttribute(v_elem,'remarks','NA');

     v_chld_node3 := dbms_xmldom.appendChild(v_chld_node2,v_ins_node);
     i := i+1;
    END LOOP;


  --ShortFall details
    v_elem := dbms_xmldom.createElement(v_doc,'SHORTFALLDETAILS');--claimant details
    v_node := dbms_xmldom.makeNode(v_elem);
    dbms_xmldom.setAttribute(v_elem,'description',clm_rec.disc_datails);
    v_chld_node := dbms_xmldom.appendChild(v_main_node,v_node);

    v_elem := dbms_xmldom.createElement(v_doc,'INSURED');
    v_ins_node :=dbms_xmldom.makenode(v_elem);
    dbms_xmldom.setAttribute(v_elem,'shortfalldate',clm_rec.insured_disc_date);
    dbms_xmldom.setattribute(v_elem,'reminderdate',clm_rec.insured_reminder_date);
    dbms_xmldom.setAttribute(v_elem,'finalremdate',clm_rec.insured_final_reminder_date);
    dbms_xmldom.setAttribute(v_elem,'replyrecdate',clm_rec.insured_reply_recieved_date);
    v_chld_node2 := dbms_xmldom.appendChild(v_chld_node,v_ins_node);

    v_elem := dbms_xmldom.createElement(v_doc,'HOSPITAL');
    v_ins_node :=dbms_xmldom.makenode(v_elem);
    dbms_xmldom.setAttribute(v_elem,'shortfalldate',clm_rec.hospital_disc_date);
    dbms_xmldom.setattribute(v_elem,'reminderdate',clm_rec.hospital_reminder_date);
    dbms_xmldom.setAttribute(v_elem,'finalremdate',clm_rec.hospital_final_reminder_date);
    dbms_xmldom.setAttribute(v_elem,'replyrecdate',clm_rec.hospital_reply_recieved_date);
    v_chld_node2 := dbms_xmldom.appendChild(v_chld_node,v_ins_node);

    v_elem := dbms_xmldom.createElement(v_doc,'INSURER');
    v_ins_node :=dbms_xmldom.makenode(v_elem);
    dbms_xmldom.setAttribute(v_elem,'shortfalldate',clm_rec.Insurer_Disc_Date);
    dbms_xmldom.setattribute(v_elem,'reminderdate',clm_rec.Insurer_Reminder_Date);
    dbms_xmldom.setAttribute(v_elem,'finalremdate',clm_rec.insurer_final_reminder_date);
    dbms_xmldom.setAttribute(v_elem,'replyrecdate',clm_rec.insurer_reply_recieved_date);
    v_chld_node2 := dbms_xmldom.appendChild(v_chld_node,v_ins_node);

    --- Investigation details
    v_elem := dbms_xmldom.createElement(v_doc,'INVESTIGATIONDETAILS');--claimant details
    v_node := dbms_xmldom.makeNode(v_elem);
    v_chld_node := dbms_xmldom.appendChild(v_main_node,v_node);

    v_elem := dbms_xmldom.createElement(v_doc,'INVESTIGATION');
    v_ins_node :=dbms_xmldom.makenode(v_elem);
    dbms_xmldom.setAttribute(v_elem,'invname',clm_rec.investigated_by);
    dbms_xmldom.setAttribute(v_elem,'invdate',clm_rec.investigated_date);
    dbms_xmldom.setAttribute(v_elem,'recommendation',clm_rec.invst_remarks);
    dbms_xmldom.setAttribute(v_elem,'tpa_recommendation',clm_rec.Pre_Auth_Status);
    dbms_xmldom.setattribute(v_elem,'tparemarks',clm_rec.remarks);
    dbms_xmldom.setAttribute(v_elem,'insremarks',clm_rec.pat_ins_remarks);


    v_chld_node2 := dbms_xmldom.appendChild(v_chld_node,v_ins_node);

    v_out_xml:=dbms_xmldom.getxmltype(v_doc);
    v_pat_xml := v_out_xml;
    v_ins_status := case when clm_rec.PAT_status_general_type_id='APR' AND clm_rec.PAT_ins_status='APR' THEN 'TRAD'
                         WHEN clm_rec.PAT_status_general_type_id='REJ' AND clm_rec.PAT_ins_status='REJ' THEN 'TRAD'
                         WHEN clm_rec.PAT_ins_status ='INP' THEN NULL
                    ELSE 'TRND' END;
    v_ins_remarks:=clm_rec.pat_ins_remarks;


    dbms_xmldom.freeDocument(v_doc);

    END   select_preauth_web;
---========================================================================================
---- icd_code details
  FUNCTION f_icd_code_desc_pat(v_pat_gen_detail_seq_id  IN icd_pcs_detail.pat_gen_detail_seq_id%TYPE, -- to precide ICD CODES
                           v_flag                   IN VARCHAR2,
                           v_type                   IN VARCHAR2)
         RETURN  VARCHAR2 AS
         v_out   VARCHAR2(4000);

 CURSOR cur_icd IS
        SELECT pat_gen_detail_seq_id,
                  nvl(MAX(CASE WHEN icd_rank=1 THEN icd_code ELSE NULL END),'NA') icd_code_1,
                  nvl(MAX(CASE WHEN icd_rank=2 THEN icd_code ELSE NULL END),'NA') icd_code_2,
                  nvl(MAX(CASE WHEN icd_rank=1 THEN ped_description ELSE NULL END),'NA') icd_desc_1,
                  nvl(MAX(CASE WHEN icd_rank=2 THEN ped_description ELSE NULL END),'NA') icd_desc_2
                  FROM
                  (SELECT g.pat_gen_detail_seq_id,
                          i.icd_code,
                          k.ped_description,
                           rank()over (ORDER BY i.icd_pcs_seq_id desc ,i.primary_ailment_yn asc) icd_rank
                  FROM pat_general_details g
                  LEFT OUTER JOIN icd_pcs_detail i ON (i.pat_gen_detail_seq_id=g.pat_gen_detail_seq_id)
                  LEFT OUTER JOIN tpa_ped_code k ON (k.icd_code=i.icd_code)
                  WHERE g.pat_gen_detail_seq_id=v_pat_gen_detail_seq_id)
                  GROUP BY pat_gen_detail_seq_id ;

      icd_cur     cur_icd%ROWTYPE;

  CURSOR cur_pcd IS
         SELECT pat_gen_detail_seq_id,
                  nvl(MAX(CASE WHEN RANK=1 THEN proc_code ELSE NULL END),'NA') pcs_code_1,
                  nvl(MAX(CASE WHEN RANK=2 THEN proc_code ELSE NULL END),'NA') pcs_code_2,
                  nvl(MAX(CASE WHEN RANK=1 THEN proc_description ELSE NULL END),'NA') pcs_desc_1,
                  nvl(MAX(CASE WHEN RANK=2 THEN proc_description ELSE NULL END),'NA') pcs_desc_2
           FROM (SELECT p.proc_seq_id,
                        g.pat_gen_detail_seq_id,
                        i.icd_code,
                        i.primary_ailment_yn,
                        c.proc_code,
                        nvl(substr(REPLACE(REPLACE(c.proc_description,chr(13),''),CHR(10),' '),1,240),'NA') proc_description,
                        rank()over (ORDER BY p.pat_proc_seq_id DESC) RANK
                  FROM pat_general_details G
                  INNER JOIN icd_pcs_detail I ON (i.pat_gen_detail_seq_id=g.pat_gen_detail_seq_id)
                  INNER JOIN pat_package_procedures P ON (p.icd_pcs_seq_id=i.icd_pcs_seq_id)
                  INNER JOIN tpa_hosp_procedure_code C ON (c.proc_seq_id=p.proc_seq_id)
                  WHERE g.pat_gen_detail_seq_id=v_pat_gen_detail_seq_id) group by pat_gen_detail_seq_id;


      pcd_cur         cur_pcd%ROWTYPE;

 BEGIN

  IF v_flag ='IC' THEN

  OPEN cur_icd;
  FETCH cur_icd INTO icd_cur;
  CLOSE cur_icd;

  IF v_type ='IC1' THEN
       v_out := icd_cur.icd_code_1;
  ELSIF v_type ='IC2' THEN
       v_out := icd_cur.icd_code_2;
  ELSIF v_type ='ID1' THEN
       v_out := icd_cur.icd_desc_1;
  ELSIF v_type ='ID2' THEN
       v_out := icd_cur.icd_desc_2;
  END IF;

 ELSIF v_flag ='PC' THEN
     OPEN cur_pcd;
     FETCH cur_pcd INTO pcd_cur;
     CLOSE cur_pcd;

    IF v_type ='PC1' THEN
       v_out := pcd_cur.pcs_code_1;
    ELSIF v_type ='PC2' THEN
          v_out := pcd_cur.pcs_code_2;
    ELSIF v_type ='PD1' THEN
          v_out := pcd_cur.pcs_desc_1;
    ELSIF v_type ='PD2' THEN
          v_out := pcd_cur.pcs_desc_2;
    END IF;

  END IF;

  RETURN nvl(v_out,'NA');
 END f_icd_code_desc_pat;
---==================================================================================
FUNCTION fn_sfremarks_pat (v_pat_gen_detail_seq_id IN pat_general_details.pat_gen_detail_seq_id%TYPE)
  RETURN VARCHAR2
  IS
        CURSOR cur IS
        WITH AB AS (
        SELECT shortfall_questions,s.claim_seq_id,c.pre_auth_dms_reference_id
        FROM shortfall_details s, pat_general_details c
        WHERE c.pat_gen_detail_seq_id =s.pat_gen_detail_seq_id
        AND s.pat_gen_detail_seq_id=v_pat_gen_detail_seq_id
        )
        SELECT extractValue(value(C), '/query/@value') as otherquery
             FROM  AB, table(XMLSequence(extract(SHORTFALL_QUESTIONS ,'shortfall/section/subsection/query')))C
             WHERE upper(extractValue(value(C), '/query/@type'))='TEXT';

        otherquery                VARCHAR2(32000);
        claim_number1             VARCHAR2(100);
        tpa_enrollment_id1        VARCHAR2(100);
        str                       VARCHAR2(32767):=NULL;
        v_str                     CLOB:=null;
        comma                     CHAR:=NULL;
  BEGIN

        OPEN cur;
        LOOP
        FETCH cur INTO otherquery;
        EXIT WHEN cur%NOTFOUND;
        IF length(otherquery)>1   THEN
           v_str:=v_str||comma||otherquery;
            END IF;
            comma:=',';
        END LOOP;
        CLOSE cur;
        str:=dbms_lob.substr(v_str,3000,1);
        str := REPLACE(str,'&','AND');
        RETURN str;
  END fn_sfremarks_pat;
---=============================================================================================================
PROCEDURE pat_ins_appr_save (v_seq_ids              IN VARCHAR2,
                               v_appr_rej_status      IN pat_ins_intimation_details.pat_ins_status%TYPE,
                               v_remarks              IN pat_ins_intimation_details.pat_ins_remarks%TYPE,
                               V_added_by             IN NUMBER,
                               v_rows_processed       OUT NUMBER) IS

  seq_tab                             ttk_util_pkg.str_table_type;
  v_pat_enroll_detail_seq_id          pat_enroll_details.pat_enroll_detail_seq_id%TYPE;
  v_pat_completed                     pat_general_details.completed_yn%TYPE;
  v_prod_policy_seq_id        tpa_ins_prod_policy.prod_policy_seq_id%TYPE;

  cursor pat_cur(v_seq_id pat_general_details.pat_gen_detail_seq_id%type) is
  select pii.pat_ins_status AS prev_ins_status,PII.Pat_Ins_Remarks AS prev_ins_remarks,
  a.pat_status_general_type_id as pat_status
  from pat_enroll_details  a
  join pat_general_details b on (a.pat_enroll_detail_seq_id=b.pat_enroll_detail_seq_id AND B.PAT_ENHANCED_YN='N')
  left outer join pat_ins_intimation_details pii on (a.PAT_ENROLL_DETAIL_SEQ_ID= pii.pat_auth_seq_id)
  where b.pat_gen_detail_seq_id=v_seq_id
  and pii.pat_ins_status is not null;
  --and pii.pat_ins_status!='INP';

  pat_rec pat_cur%rowtype;
  v_status clm_ins_intimation_details.clm_ins_status%type;

  BEGIN

  seq_tab         := ttk_util_pkg.parse_str(v_seq_ids);

  FOR i IN seq_tab.first..seq_tab.last LOOP
    SELECT g.pat_enroll_detail_seq_id,g.completed_yn INTO v_pat_enroll_detail_seq_id,v_pat_completed FROM pat_general_details g WHERE g.pat_gen_detail_seq_id=seq_tab(i);
        IF v_pat_completed='Y' THEN
        Raise_application_error(-20868,'No Modifications Are Allowed, Claim Needs Insurance company Response');
      END IF;

    open pat_cur(seq_tab(i));
    fetch pat_cur into pat_rec;
    close pat_cur;

    v_status:=CASE WHEN pat_rec.Pat_Status='APR' AND  v_appr_rej_status='TRAD' THEN 'APR'
                                              WHEN pat_rec.Pat_Status='REJ' AND  v_appr_rej_status='TRAD' THEN 'REJ'
                                              ELSE 'REQ' END;

   if pat_rec.pat_status not in ('APR','REJ') AND v_status IS NOT NULL THEN
       Raise_application_error(-20868,'No Modifications Are Allowed, Preauth/Claim Already intimated to TPA.');
   end if;

    if pat_rec.prev_ins_status=v_status and pat_rec.prev_ins_remarks=v_remarks then
      raise_application_error(-20836,'Preauth/Claim Already intimated to TPA, Please change the Status/Remarks.');
    end if;



     UPDATE pat_ins_intimation_details pe
       SET pe.pat_ins_status              =v_status ,
           pe.pat_ins_decision_date       = SYSDATE,
           pe.pat_ins_remarks             = substr(app.account_info_pkg.get_gen_desc(v_appr_rej_status,'G')||'--'||TO_CHAR(SYSDATE,'DD-MON-YYYY HH:MI:SS AM')||'--'||app.account_info_pkg.get_gen_desc(v_added_by,'U')||'--'||v_remarks,1,1000),
           PE.UPDATED_BY                  = V_ADDED_BY,
           PE.UPDATED_DATE                = SYSDATE
      WHERE pe.pat_auth_seq_id   = v_pat_enroll_detail_seq_id;

      v_rows_processed := sql%rowcount;
      COMMIT;
     v_prod_policy_seq_id:=pre_auth_pkg.get_prod_pol_seq_id(seq_tab(i),'PAT');
     generate_mail_pkg.proc_generate_mail('TTK_SPOC_PAT_RESP',seq_tab(i),v_prod_policy_seq_id,V_added_by);

  END LOOP;
 END pat_ins_appr_save;
---========================================================================================================
 PROCEDURE pat_intimate_send (v_ins_code    IN tpa_ins_info.abbrevation_code%TYPE,
                              v_result_set  OUT sys_refcursor) IS

     v_sql_str                 VARCHAR2(32760);

  BEGIN

     v_sql_str := 'SELECT
               pe.pre_auth_number,
               pe.decision_date,
               gc.description,
               pg.pat_enhanced_yn

        FROM pat_enroll_details pe
        JOIN pat_general_details pg (pe.pat_enroll_detail_seq_id=pg.pat_enroll_detail_seq_id)
        left outer join pat_ins_intimation_details pii on (pe.PAT_ENROLL_DETAIL_SEQ_ID= pii.PAT_ENROLL_DETAIL_SEQ_ID)
        JOIN tpa_ins_info tii ON (tii.ins_seq_id=pe.ins_seq_id)
        JOIN tpa_general_code gc ON (gc.general_type_id=pe.pat_status_general_type_id)
        WHERE pii.pat_ins_status=''INP'' AND PG.COMPLETED_YN=''N'' AND tii.abbrevation_code =:v_ins_code
        ORDER BY pe.decision_date ASC';

     OPEN v_result_set FOR v_sql_str USING v_ins_code;

  END pat_intimate_send;
--===================================================================================================
 PROCEDURE pat_generate_letter (v_pat_gen_detail_seq_id        IN pat_general_details.pat_gen_detail_seq_id%TYPE,
                                v_pat_result                   OUT SYS_REFCURSOR ) IS
   CURSOR cur_pat IS

       SELECT p.pre_auth_number,p.policy_number,p.tpa_enrollment_id,p.member_seq_id
       FROM pat_enroll_details p
       JOIN pat_general_details g ON (p.pat_enroll_detail_seq_id=g.pat_enroll_detail_seq_id)
       WHERE g.pat_gen_detail_seq_id=v_pat_gen_detail_seq_id;

  pat_rec    cur_pat%ROWTYPE;
   
   v_buff_app_amt                           buffer_header.buff_app_amt%type:=pre_auth_pkg.get_buff_apr_amt(v_pat_gen_detail_seq_id,'PAT','CORP_BUFF') ;
   v_med_buff_app_amt                       buffer_header.buff_app_amt%type:=pre_auth_pkg.get_buff_apr_amt(v_pat_gen_detail_seq_id,'PAT','MED_BUFF') ;	
   v_crit_buff_app_amt                      buffer_header.buff_app_amt%type:=pre_auth_pkg.get_buff_apr_amt(v_pat_gen_detail_seq_id,'PAT','CRIT_BUFF') ;
   v_crit_corp_buff_app_amt                 buffer_header.buff_app_amt%type:=pre_auth_pkg.get_buff_apr_amt(v_pat_gen_detail_seq_id,'PAT','CRIT_CORP_BUFF') ;
   v_crit_med_buff_app_amt                  buffer_header.buff_app_amt%type:=pre_auth_pkg.get_buff_apr_amt(v_pat_gen_detail_seq_id,'PAT','CRIT_MED_BUFF') ;


 BEGIN

   OPEN cur_pat;
   FETCH cur_pat INTO pat_rec;
   CLOSE cur_pat;

   OPEN v_pat_result FOR
        SELECT
         pg.pat_gen_detail_seq_id,
         pe.pre_auth_number         claim_no,
         peg.insured_name           proposer_name,
         pe.claimant_name           patient_name,
         peg.employee_no            employee_customer_id,
         pe.tpa_enrollment_id       tpa_id,
         round(pe.mem_age)          patient_age,
         app.account_info_pkg.get_gen_desc(pem.relship_type_id,'R')        Relation,
         app.account_info_pkg.get_gen_desc(pem.gender_general_type_id,'G') Gender,
         pol.policy_number          policy_no,
         tgr.group_name||'--'||tip.product_name  product_name,
         to_char(pol.effective_from_date,'DD-MON-YYYY')  policy_form,
         to_char(pol.effective_to_date,'DD-MON-YYYY')    policy_upto,
         eb.sum_insured,
        -- pem.mem_tot_bonus as bonus,
         CASE WHEN POL.POLICY_SUB_GENERAL_TYPE_ID ='PFL' THEN peg.FLOATER_TOT_BONUS ELSE pem.mem_tot_bonus END as bonus,
         nvl(pol.buffer_alloc_amount,pem.mem_tot_bonus)   buffer_bonus,
         ma.address_1||' '||ma.address_2||' '||ma.address_3 address,
         to_char(pg.pat_received_date,'DD-MON-YYYY') intimation_date,
         to_char(pg.pat_received_date,'DD-MON-YYYY') date_of_doc_rec,
         to_char(pe.date_of_hospitalization,'DD-MON-YYYY') loss_date,
         hi.hosp_name hospital_name,
         NVL(app.account_info_pkg.get_gen_desc(HA.CITY_TYPE_ID,'CT') , ha.city )     hospital_city,
         NVL(app.account_info_pkg.get_gen_desc(HA.STATE_TYPE_ID,'S'), ha.state)     hospital_state,
         ha.pin_code  hospital_pincode,
         substr(replace(replace(al.provisional_diagnosis,chr(13),''),chr(10),' '),1,500) diagnosis,
         f_icd_code_desc_pat(pg.pat_gen_detail_seq_id,'IC','IC1') diagnosis_code_level_1,
         f_icd_code_desc_pat(pg.pat_gen_detail_seq_id,'IC','IC2') diagnosis_code_level_2,
         f_icd_code_desc_pat(pg.pat_gen_detail_seq_id,'IC','ID1') diagnosis_description_level_1,
         f_icd_code_desc_pat(pg.pat_gen_detail_seq_id,'IC','ID2') diagnosis_description_level_2,

         f_icd_code_desc_pat(pg.pat_gen_detail_seq_id,'PC','PC1') procedure_codes_level_1,
         f_icd_code_desc_pat(pg.pat_gen_detail_seq_id,'PC','PC2') procedure_codes_level_2,
         f_icd_code_desc_pat(pg.pat_gen_detail_seq_id,'PC','PD1') procedure_description_level_1,
         f_icd_code_desc_pat(pg.pat_gen_detail_seq_id,'PC','PD2') procedure_description_level_2,
         to_char(pg.likely_date_of_hospitalization,'DD-MON-YYYY') doa,
         to_char((pg.likely_date_of_hospitalization+al.duration_of_hospitalization),'DD-MON-YYYY') dod,
         'CASHLESS' claim_type,
         app.account_info_pkg.get_gen_desc(pg.pat_general_type_id,'G') claim_category,
         app.account_info_pkg.get_gen_desc(pol.enrol_type_id,'E') policy_type,
         pg.pat_requested_amount estimate_amt,
         pg.total_app_amount claim_amount,
         NVL(ROUND((SELECT SUM(approved_amount)
              FROM ailment_caps x JOIN icd_pcs_detail y ON ( x.icd_pcs_seq_id = y.icd_pcs_seq_id )
              WHERE y.pat_gen_detail_seq_id= pg.pat_gen_detail_seq_id)),0) recommend_amount,
         NVL(pg.co_payment_amount,0)+nvl(pg.co_payment_buffer_amount,0) co_pay_amount,
         NVL(ROUND((SELECT SUM(approved_amount)
              FROM ailment_caps x JOIN icd_pcs_detail y ON ( x.icd_pcs_seq_id = y.icd_pcs_seq_id )
              WHERE y.pat_gen_detail_seq_id= pg.pat_gen_detail_seq_id)),0) AS approved_amount,
         pg.pat_requested_amount-nvl(pg.total_app_amount,0) deducted_amount,
         '' deduction_reason,
         '0' compulsary_deduction,
         '0' service_tax_amount,
         hi.serv_tax_rgn_number service_tax_no,
         nvl(pg.total_app_amount,'0') payble_amount,
         0 tds_amount,
         0 net_payble_amt,
         to_char(PII.PAT_INS_SEND_DATE,'DD-MON-YYYY') recommend_on,
         to_char(pe.decision_date,'DD-MON-YYYY') approved_on,
         0 pay_to_insured,
         nvl(pg.total_app_amount,0) pay_to_hospital,
         nvl(pol.buffer_alloc_amount,0) corporate_buffer,
          nvl(pol.med_buff_alloc_amount,0) medical_buffer,
          nvl(pol.crit_buff_alloc_amount,0) critical_buffer,
          nvl(pol.crit_corp_buff_alloc_amount,0) critical_corporate_buffer,
          nvl(pol.crit_med_buff_alloc_amount,0) critical_medical_buffer,
         NULL cheque_no,
         NULL cheque_date,
         hi.hosp_name clm_pay_to_beneficiary_name,
         fn_sfremarks_pat(pg.pat_gen_detail_seq_id) disc_datails,

         to_char(sf.min_sfdt,'DD-MON-YYYY') insured_disc_date,
         to_char(sf.max_sfdt,'DD-MON-YYYY') insured_reminder_date,
         to_char(sf.max_sfdt,'DD-MON-YYYY') insured_final_reminder_date,
         to_char(sf.sf_responded_dt,'DD-MON-YYYY') insured_reply_recieved_date,
         NULL hospital_disc_date,
         NULL hospital_reminder_date,
         NULL hospital_final_reminder_date,
         NULL hospital_reply_recieved_date,
         NULL insurer_disc_date,
         NULL insurer_reminder_date,
         NULL insurer_final_reminder_date,
         NULL insurer_reply_recieved_date,
         to_char(pg.pat_received_date,'DD-MON-YYYY') pre_auth_received_on,
         pe.pre_auth_number  pre_auth_letter_no,
         app.account_info_pkg.get_gen_desc(pe.pat_status_general_type_id,'G') pre_auth_status,
         nvl(pg.total_app_amount,'0') pre_auth_amount,
         to_char(pe.decision_date,'DD-MON-YYYY') pre_auth_approved_on,
         NULL float_no,
         NULL float_date,
         NULL payment_date,
         '0' agent_code,
         pol.dev_officer_code development_code,
         tii.ins_comp_name  operating_office,
         tii.ins_comp_code_number  operating_code,
         NVL(app.account_info_pkg.get_gen_desc(tas.City_Type_Id,'CT'),TAS.CITY)  ins_city,
         NVL(app.account_info_pkg.get_gen_desc(tas.State_Type_Id,'S'),TAS.STATE)  ins_state,
          tas.pin_code ins_pincode,
         NULL controlling_office,
         tii.ins_comp_name  insurance_company,
         NULL settelement_type,
         NULL settelement_date,
         regexp_replace(au.remarks, '[[:space:]]',' ') as repudiation_rejection_reason,
         pe.pat_status_general_type_id AS status,
         NULL benefit_type,
         NULL bill_entered_by,
         NULL bill_entry_location,
         hi.empanel_number hospital_code,
         pe.member_seq_id,
         peg.tpa_enrollment_number enr_num,
         'Bangalore' as premium_zone,
         regexp_replace(au.remarks, '[[:space:]]',' ') remarks,
         al.added_date,
         pII.pat_ins_remarks as ins_remarks,
         v_buff_app_amt Buff_App_Amt,
         v_med_buff_app_amt Med_Buff_App_Amt,
         v_crit_buff_app_amt Crit_Buff_App_Amt,
         v_crit_corp_buff_app_amt Crit_Corp_Buff_App_Amt,
         v_crit_med_buff_app_amt Crit_Med_Buff_App_Amt,        
         nvl(CASE WHEN nvl(pe.claim_id,0)=0 then v_buff_app_amt else CASE WHEN nn2.pre_auth_buffer_app_amount>0 then CASE WHEN nvl(NN2.Utilised_Amount,0)< 0 THEN v_Buff_App_Amt + nvl(NN2.Utilised_Amount,0) ELSE NN2.Utilised_Amount end   else 0 end end,0) as Utilised_Amount,
         nvl(CASE WHEN nvl(pe.claim_id,0)=0 then v_med_buff_app_amt else CASE WHEN nn2.pre_auth_buffer_app_amount>0 then CASE WHEN nvl(NN2.Utilised_Med_Amount,0)< 0 THEN v_Med_Buff_App_Amt + nvl(NN2.Utilised_Med_Amount,0) ELSE NN2.Utilised_Med_Amount end   else 0 end  end,0) as Utilised_Med_Amount,
         nvl(CASE WHEN nvl(pe.claim_id,0)=0 then v_crit_buff_app_amt else CASE WHEN nn2.pre_auth_buffer_app_amount>0 then CASE WHEN nvl(NN2.Utilised_Crit_Amount,0)< 0 THEN v_Crit_Buff_App_Amt + nvl(NN2.Utilised_Crit_Amount,0) ELSE  NN2.Utilised_Crit_Amount end   else 0 end  end,0) as Utilised_Crit_Amount,
         nvl(CASE WHEN nvl(pe.claim_id,0)=0 then v_crit_corp_buff_app_amt else CASE WHEN nn2.pre_auth_buffer_app_amount>0 then CASE WHEN nvl(NN2.Utilised_Crit_Corp_Amount,0)< 0 THEN v_Crit_Corp_Buff_App_Amt + nvl(NN2.Utilised_Crit_Corp_Amount,0) ELSE NN2.Utilised_Crit_Corp_Amount end   else 0 end  end,0) as Utilised_Crit_Corp_Amount,
         nvl(CASE WHEN nvl(pe.claim_id,0)=0 then v_crit_med_buff_app_amt else CASE WHEN nn2.pre_auth_buffer_app_amount>0 then CASE WHEN nvl(NN2.Utilised_Crit_Med_Amount,0)< 0 THEN v_Crit_Med_Buff_App_Amt + nvl(NN2.Utilised_Crit_Med_Amount,0) ELSE NN2.Utilised_Crit_Med_Amount end   else 0 end  end,0) as Utilised_Crit_Med_Amount
   
		 

     FROM pat_general_details pg
          JOIN pat_enroll_details pe ON (pe.pat_enroll_detail_seq_id=pg.pat_enroll_detail_seq_id)
          left outer join PAT_ins_intimation_details PII on (PE.PAT_ENROLL_DETAIL_SEQ_ID=Pii.pat_auth_seq_id)
          JOIN assign_users au ON (au.assign_users_seq_id=pg.last_assign_user_seq_id)
          JOIN tpa_enr_policy pol ON (pol.policy_seq_id=pe.policy_seq_id)
          JOIN tpa_enr_policy_member pem ON (pem.member_seq_id=pe.member_seq_id)
          JOIN tpa_enr_policy_group peg  ON (peg.policy_group_seq_id=pem.policy_group_seq_id)
          JOIN tpa_ins_product tip ON (tip.product_seq_id=pol.product_seq_id)
          JOIN tpa_enr_mem_address ma ON (peg.enr_address_seq_id=ma.enr_address_seq_id)
          JOIN tpa_enr_balance eb ON (eb.policy_group_seq_id=peg.policy_group_seq_id)
          JOIN tpa_hosp_info  hi ON (pe.hosp_seq_id=hi.hosp_seq_id)
          JOIn tpa_hosp_address ha ON (ha.hosp_seq_id=hi.hosp_seq_id)
          LEFT OUTER JOIN tpa_city_code tcc ON (tcc.city_type_id=ha.city_type_id)
          LEFT OUTER JOIN tpa_state_code tsc ON (tsc.state_type_id=ha.state_type_id)
          JOIN tpa_ins_info tii ON (tii.ins_seq_id=pe.ins_seq_id)
          JOIN tpa_address tas on (tas.ins_seq_id=tii.ins_seq_id)
          LEFT OUTER JOIN tpa_group_registration tgr on (tgr.group_reg_seq_id=pol.group_reg_seq_id)
          LEFT OUTER JOIN ailment_details al ON (al.pat_gen_detail_seq_id=pg.pat_gen_detail_seq_id)
          LEFT OUTER JOIN (SELECT  sd.pat_gen_detail_seq_id pat_id, MIN (sd.added_date) min_sfdt,
                                   MAX(sd.added_date) max_sfdt, MAX(sd.closed_date) sf_closeddt,
                                   MAX(sd.srtfll_received_date) SF_Responded_Dt
                           FROM shortfall_details sd
                           GROUP BY sd.pat_gen_detail_seq_id) sf ON (sf.pat_id = pg.pat_gen_detail_seq_id)
          left outer join buffer_details bd on (pg.last_buffer_detail_seq_id=bd.buff_detail_seq_id)
          left outer join buffer_header nn2 on (bd.buffer_hdr_seq_id=nn2.buffer_hdr_seq_id)                           
    WHERE pg.pat_gen_detail_seq_id=v_pat_gen_detail_seq_id--'6213480'
    AND (pem.mem_general_type_id = 'PFL'
    AND eb.member_seq_id IS NULL OR pem.member_seq_id = eb.member_seq_id OR pem.member_seq_id IS NULL);

 END pat_generate_letter;
 ---=======================================//policy history//=========================================
 PROCEDURE pat_gen_policy_hist(v_policy_number       IN tpa_enr_policy.policy_number%TYPE,
                               v_tpa_enr_id          IN tpa_enr_policy_member.tpa_enrollment_id%TYPE,
                               v_pol_hist_result     OUT SYS_REFCURSOR ) IS

 BEGIN

 OPEN v_pol_hist_result FOR
  WITH tab_bal AS (
     SELECT rank() over(PARTITION BY pg.tpa_enrollment_number ORDER BY pg.policy_group_seq_id DESC) AS rnk,
         pg.policy_group_seq_id,
         ep.policy_number,
         ep.renewal_policy_number,
         to_char(ep.effective_from_date,'DD-MON-YYYY') AS effective_from_date,
         TO_CHAR(ep.effective_to_date,'DD-MON-YYYY') AS effective_to_date,
         ep.policy_rcvd_date,
         (CASE WHEN ep.policy_sub_general_type_id='PFL' THEN pg.family_tot_sum_insured ELSE pm.mem_tot_sum_insured END) sum_insured,
         ep.renew_count as policy_renew_count,
         ep.policy_seq_id,
         app.account_info_pkg.get_gen_desc(ep.policy_sub_general_type_id,'G') as policy_subtype,
         ip.product_name,
         DECODE(ep.enrol_type_id,'COR','Corporate','IND','Individual','ING','Individual As Group','NCR','Non-Corporate')as enrol_type

    FROM tpa_enr_policy ep
    JOIN tpa_ins_product ip on (ep.product_seq_id=ip.product_seq_id)
    JOIN tpa_enr_policy_group pg on (pg.policy_seq_id=ep.policy_seq_id )
    JOIN tpa_enr_policy_member pm on (pg.policy_group_seq_id=pm.policy_group_seq_id and pm.tpa_enrollment_id=v_tpa_enr_id)
   START WITH ep.policy_number = v_policy_number
   CONNECT BY nocycle PRIOR ep.renewal_policy_number = ep.policy_number )
 SELECT ht.* FROM tab_bal ht WHERE rnk<6;

 END pat_gen_policy_hist;
 ---=======================================//policy history//=========================================
PROCEDURE pat_prev_history (v_tpa_enrollment_id     IN pat_enroll_details.tpa_enrollment_id%TYPE,
                            v_pat_hist_result       OUT SYS_REFCURSOR) IS


  BEGIN

  OPEN v_pat_hist_result FOR
  WITH clm_tab AS (
     SELECT rank() over(partition by a.tpa_enrollment_id order by b.pat_gen_detail_seq_id desc) as rnk,
        b.pat_gen_detail_seq_id,
        a.pre_auth_number claim_number,
        a.pre_auth_number,
        to_char(a.date_of_hospitalization,'DD-MON-YYYY') as doa,
        to_char((a.date_of_hospitalization+f.duration_of_hospitalization),'DD-MON-YYYY') as dod,
        hi.hosp_name,
        substr(replace(replace(f.provisional_diagnosis,chr(13),''),chr(10),' '),1,500) diagnosis,
        b.pat_requested_amount as req_amt,
        b.total_app_amount as appr_amt,
        app.account_info_pkg.get_gen_desc(a.pat_status_general_type_id,'G') as  Claim_Status,
        regexp_replace(g.remarks, '[[:space:]]',' ') as rej_reason

  FROM  pat_enroll_details a
        JOIN pat_general_details b ON (a.pat_enroll_detail_seq_id = b.pat_enroll_detail_seq_id)
        JOIN tpa_hosp_info hi ON (hi.hosp_seq_id=a.hosp_seq_id)
        LEFT OUTER JOIN ailment_details f on (f.pat_gen_detail_seq_id=b.pat_gen_detail_seq_id)
        LEFT OUTER JOIN assign_users g On (g.assign_users_seq_id=b.last_assign_user_seq_id)
        WHERE a.tpa_enrollment_id=v_tpa_enrollment_id)
       SELECT * FROM clm_tab t WHERE rnk<=5;

 END pat_prev_history;
  ---=======================================//Tariff history//=========================================
PROCEDURE pat_bill_details(v_pat_gen_detail_seq_id        pat_general_details.pat_gen_detail_seq_id%TYPE,
                           v_bill_result                  OUT SYS_REFCURSOR) IS

  BEGIN

  OPEN v_bill_result FOR
  SELECT  g.pat_gen_detail_seq_id,
          d.ward_type_id,
          ji.ward_description AS description,
          d.requested_amount As req_amt,
          d.approved_amount AS allow_amt,
          d.maximum_allowed_amount,
          d.room_type_id,
          rc.room_description,
          d.days_of_stay
        FROM pat_general_details g
           INNER JOIN pat_enroll_details e ON (e.pat_enroll_detail_seq_id=g.pat_enroll_detail_seq_id)
           LEFT OUTER JOIN pat_tariff_details d ON (d.pat_gen_detail_seq_id=g.pat_gen_detail_seq_id)
           LEFT OUTER JOIN tpa_hosp_ward_code ji ON (ji.ward_type_id=d.ward_type_id)
           LEFT OUTER JOIN tpa_hosp_rooms_code rc ON (rc.room_type_id=d.room_type_id)
        WHERE g.pat_gen_detail_seq_id=v_pat_gen_detail_seq_id and d.approved_amount>0;

   END pat_bill_details;
---=====================================================================================================
---=====================================================================================================
PROCEDURE claims_intimate_send_iar(v_ins_code           IN tpa_ins_info.abbrevation_code%TYPE,
                                   v_result_set_i         OUT sys_refcursor,
                                   v_result_set_a         OUT sys_refcursor,
                                   v_result_set_r         OUT sys_refcursor) IS

    v_sql_str_i                     VARCHAR2(32760);
    v_sql_str_a                     VARCHAR2(32760);
    v_sql_str_r                     VARCHAR2(32760);

   BEGIN


      v_sql_str_i :=  'SELECT
                        cg.claim_number,
                        ce.decision_date,
                        gc.description
                    FROM clm_general_details cg
                    JOIN clm_enroll_details ce ON (cg.claim_seq_id=ce.claim_seq_id)
                    left outer join clm_ins_intimation_details cii on (ce.claim_seq_id=cii.claim_seq_id)
                    JOIN tpa_ins_info tii ON (tii.ins_seq_id=ce.ins_seq_id)
                    JOIN tpa_general_code gc ON (gc.general_type_id=ce.clm_status_general_type_id)
                    WHERE cii.clm_ins_status=''INP'' AND CG.COMPLETED_YN=''N'' AND  tii.abbrevation_code=:v_ins_code
                    ORDER BY ce.decision_date ASC';

      v_sql_str_a :=  'SELECT
                        cg.claim_number,
                        ce.decision_date,
                        gc.description
                    FROM clm_general_details cg
                    JOIN clm_enroll_details ce ON (cg.claim_seq_id=ce.claim_seq_id)
                    left outer join clm_ins_intimation_details cii on (ce.claim_seq_id=cii.claim_seq_id)
                    JOIN tpa_ins_info tii ON (tii.ins_seq_id=ce.ins_seq_id)
                    JOIN tpa_general_code gc ON (gc.general_type_id=ce.clm_status_general_type_id)
                    WHERE cii.clm_ins_status=''APR'' AND cg.completed_yn=''N'' AND  tii.abbrevation_code=:v_ins_code
                    ORDER BY ce.decision_date ASC';

      v_sql_str_r :=  'SELECT
                        cg.claim_number,
                        ce.decision_date,
                        gc.description
                    FROM clm_general_details cg
                    JOIN clm_enroll_details ce ON (cg.claim_seq_id=ce.claim_seq_id)
                    left outer join clm_ins_intimation_details cii on (ce.claim_seq_id=cii.claim_seq_id)
                    JOIN tpa_ins_info tii ON (tii.ins_seq_id=ce.ins_seq_id)
                    JOIN tpa_general_code gc ON (gc.general_type_id=ce.clm_status_general_type_id)
                    WHERE cii.clm_ins_status=''REQ'' AND cg.completed_yn=''N'' AND  tii.abbrevation_code=:v_ins_code
                    ORDER BY ce.decision_date ASC';

         OPEN v_result_set_i FOR v_sql_str_i USING v_ins_code;
         OPEN v_result_set_a FOR v_sql_str_a USING v_ins_code;
         OPEN v_result_set_r FOR v_sql_str_r USING v_ins_code;

END claims_intimate_send_iar;
--====================================================================
 PROCEDURE pat_intimate_send_iar (v_ins_code    IN tpa_ins_info.abbrevation_code%TYPE,
                              v_result_set_i  OUT sys_refcursor,
                              v_result_set_a  OUT sys_refcursor,
                              v_result_set_r  OUT sys_refcursor) IS

     v_sql_str_i                 VARCHAR2(32760);
     v_sql_str_a                 VARCHAR2(32760);
     v_sql_str_r                 VARCHAR2(32760);

  BEGIN

     v_sql_str_i := 'SELECT
               pe.pre_auth_number,
               pe.decision_date,
               gc.description,
               pg.pat_enhanced_yn

        FROM pat_enroll_details pe
        JOIN pat_general_details pg ON (pe.pat_enroll_detail_seq_id=pg.pat_enroll_detail_seq_id AND pg.pat_enhanced_yn=''N'')
        left outer join pat_ins_intimation_details pii on (pe.PAT_ENROLL_DETAIL_SEQ_ID= pii.PAT_ENROLL_DETAIL_SEQ_ID)
        JOIN tpa_ins_info tii ON (tii.ins_seq_id=pe.ins_seq_id)
        JOIN tpa_general_code gc ON (gc.general_type_id=pe.pat_status_general_type_id)
        WHERE pii.pat_ins_status=''INP'' AND PG.COMPLETED_YN=''N'' AND tii.abbrevation_code =:v_ins_code
        ORDER BY pe.decision_date ASC';

     v_sql_str_a := 'SELECT
               pe.pre_auth_number,
               pe.decision_date,
               gc.description,
               pg.pat_enhanced_yn

        FROM pat_enroll_details pe
        JOIN pat_general_details pg ON (pe.pat_enroll_detail_seq_id=pg.pat_enroll_detail_seq_id AND pg.pat_enhanced_yn=''N'')
        left outer join pat_ins_intimation_details pii on (pe.PAT_ENROLL_DETAIL_SEQ_ID= pii.PAT_ENROLL_DETAIL_SEQ_ID)
        JOIN tpa_ins_info tii ON (tii.ins_seq_id=pe.ins_seq_id)
        JOIN tpa_general_code gc ON (gc.general_type_id=pe.pat_status_general_type_id)
        WHERE pii.pat_ins_status=''APR'' AND pg.completed_yn=''N'' AND tii.abbrevation_code =:v_ins_code
        ORDER BY pe.decision_date ASC';

      v_sql_str_r := 'SELECT
               pe.pre_auth_number,
               pe.decision_date,
               gc.description,
               pg.pat_enhanced_yn

        FROM pat_enroll_details pe
        JOIN pat_general_details pg ON (pe.pat_enroll_detail_seq_id=pg.pat_enroll_detail_seq_id AND pg.pat_enhanced_yn=''N'')
        left outer join pat_ins_intimation_details pii on (pe.PAT_ENROLL_DETAIL_SEQ_ID= pii.PAT_ENROLL_DETAIL_SEQ_ID)
        JOIN tpa_ins_info tii ON (tii.ins_seq_id=pe.ins_seq_id)
        JOIN tpa_general_code gc ON (gc.general_type_id=pe.pat_status_general_type_id)
        WHERE pii.pat_ins_status=''REQ''AND pg.completed_yn=''N'' AND tii.abbrevation_code =:v_ins_code
        ORDER BY pe.decision_date ASC';

--AND pg.pat_enhanced_yn=''N'' modified.

     OPEN v_result_set_i FOR v_sql_str_i USING v_ins_code;
     OPEN v_result_set_a FOR v_sql_str_a USING v_ins_code;
     OPEN v_result_set_r FOR v_sql_str_r USING v_ins_code;


  END pat_intimate_send_iar;
--===================================================================================
PROCEDURE send_mail_intimation (v_ins_code             IN tpa_ins_info.ins_comp_code_number%TYPE,
                                v_msg_id               IN source_message.msg_id%TYPE,
                                v_file_name            IN destination_message.file_path_name%TYPE,
                                v_dest_msg_seq_id      OUT destination_message.dest_msg_seq_id%TYPE,
                                v_rows_processed       OUT NUMBER) IS

     CURSOR cur_ins_mail IS
      SELECT UNIQUE gt.abbrevation_code,
                    gt.ins_comp_name,
                    uc.ins_seq_id,gt.ins_office_general_type_id,
                    uc.contact_name,
                    uc.mobile_no,
                    uc.primary_email_id,
                    uc.active_yn
       FROM tpa_ins_info gt
       JOIN tpa_user_contacts uc ON (uc.ins_seq_id=gt.ins_seq_id)
       JOIN tpa_login_info li ON (uc.contact_seq_id=li.contact_seq_id)
       JOIN tpa_user_roles ur ON (ur.contact_seq_id=li.contact_seq_id)
       JOIN tpa_roles_code ro ON (ur.role_seq_id=ro.role_seq_id)
       WHERE gt.abbrevation_code=v_ins_code
       AND ro.role_name IN ('INSCLAIMSAPPROVER','INSCLAIMSVIEW');

      CURSOR cur_raw IS
      SELECT msg_id,message_title,msg_description,module_name,msg_sent_from,sec_rcpt_email_list
      FROM source_message
      WHERE msg_id=v_msg_id;
      raw_rec                 cur_raw%ROWTYPE;

      v_prm_rcpt_email_list            destination_message_rcpt.prm_rcpt_email_list%TYPE;
      v_limiter                        VARCHAR2(4):=NULL;


 BEGIN
     OPEN cur_raw;
     FETCH cur_raw INTO raw_rec;
     CLOSE cur_raw;

   IF v_msg_id IN ('CLM_INT_INSURANCE','PAT_INT_INSURANCE') THEN
     FOR rk IN cur_ins_mail LOOP
         v_prm_rcpt_email_list := v_prm_rcpt_email_list||v_limiter||rk.primary_email_id;
         v_limiter := ',';
     EXIT WHEN cur_ins_mail%NOTFOUND;
     END LOOP;
  ELSE
     v_prm_rcpt_email_list := 'chandana.bala@ttkhealthcareservices.com,sankhadeep.d@ttkhealthcareservices.com,yagdeep.c@ttkhealthcareservices.com';
  END IF;


   IF v_prm_rcpt_email_list IS NOT NUll THEN

     INSERT INTO destination_message
        (dest_msg_seq_id,msg_id,source_id,source_seq_id,msg_sent_from,message_title,
         message,sms_description,added_by,added_date,file_path_name )
      VALUES
        (destination_message_seq.nextval, v_msg_id,
        raw_rec.module_name, null, raw_rec.msg_sent_from, raw_rec.message_title,
         raw_rec.msg_description, NULL, 1, SYSDATE,
         CASE WHEN v_file_name IS NOT NULL THEN
         v_file_name || '.xls' ELSE NULL END)
      RETURNING dest_msg_seq_id INTO v_dest_msg_seq_id;


     INSERT INTO destination_message_rcpt
            (dest_msg_rcpt_seq_id,dest_msg_seq_id,prm_rcpt_email_list,
             prm_rcpt_sms,prm_rcpt_fax_nos,sec_rcpt_email_list,
             remarks,added_by,added_date,msg_type,present_yn,
             mail_status,msg_status_general_type_id,sent_date)
      VALUES
            (destination_message_rcpt_seq.nextval, v_dest_msg_seq_id,
             v_prm_rcpt_email_list, NULL, NULL, raw_rec.sec_rcpt_email_list, 'Refer claims_approval_pkg.send_mail_intimate',
             1,SYSDATE, 'EMAIL', 'Y', 'INP',
             'MIQ',SYSDATE) ;

     v_rows_processed := SQL%ROWCOUNT;

    COMMIT;
    END IF;

   END send_mail_intimation;

--=======================================================================================================
procedure gen_pat_apr_rej_rpt (v_where varchar2,
                               v_result_set out sys_refcursor) is

  str_tab ttk_util_pkg.str_table_type;
  v_ins_seq_id tpa_ins_info.ins_seq_id%type;

begin

  str_tab:=ttk_util_pkg.parse_str(v_where);

  SELECT ins_seq_id into v_ins_seq_id FROM TPA_USER_CONTACTS A
  WHERE A.CONTACT_SEQ_ID=str_tab(1);

IF str_tab(2) IS NULL  then

   OPEN V_RESULT_SET FOR
     SELECT
       A.pre_auth_number ,
       A.tpa_enrollment_id ,
       A.claimant_name,
       to_char(PII.Pat_Ins_Send_Date,'DD-MON-YYYY') as recommend_date,
       B.pat_requested_amount as requested_amount,
       nvl(round((SELECT SUM(approved_amount)
              FROM ailment_caps x JOIN icd_pcs_detail y ON ( x.icd_pcs_seq_id = y.icd_pcs_seq_id )
              WHERE y.Pat_Gen_Detail_Seq_Id = B.PAT_GEN_DETAIL_SEQ_ID)),0) as total_app_amount,
       B.total_app_amount as payble_amount,
        H.hosp_name ,
       to_char(A.date_of_hospitalization,'DD-MON-YYYY') as date_of_admission,
       G.description pat_status,
       to_char(PII.pat_ins_decision_date,'DD-MON-YYYY') AS pat_ins_decision_date,
       f.description as tpa_status,
       nvl(B.co_payment_amount,0)+nvl(B.co_payment_buffer_amount,0) co_pay_amount



      FROM pat_enroll_details A
      JOIN pat_general_details B ON (A.pat_enroll_detail_seq_id = b.pat_enroll_detail_seq_id AND b.pat_enhanced_yn='N' )
      left outer join pat_ins_intimation_details pii on (a.PAT_ENROLL_DETAIL_SEQ_ID= pii.pat_auth_seq_id)
      LEFT OUTER JOIN tpa_hosp_info H ON (A.hosp_seq_id = H.hosp_seq_id)
      LEFT OUTER JOIN tpa_enr_policy I ON ( A.policy_seq_id = I.policy_seq_id)
      LEFT OUTER JOIN tpa_general_code G ON (pii.Pat_Ins_Status=G.general_type_id)
      LEFT OUTER JOIN tpa_general_code f ON (a.pat_status_general_type_id=f.general_type_id)
      WHERE   PII.Pat_Ins_Decision_Date >= to_date(str_tab(3),'dd/mm/yyyy')
      AND  PII.Pat_Ins_Decision_Date <= to_date(str_tab(4),'dd/mm/yyyy')+1
      AND i.ins_seq_id IN (SELECT ins_seq_id FROM tpa_ins_info
                                            START WITH ins_seq_id  = v_ins_seq_id
                                               CONNECT BY PRIOR ins_seq_id  = ins_parent_seq_id)
      AND pii.pat_ins_status in ('APR','REJ')
      ORDER BY PII.PAT_INS_DECISION_DATE ASC;
else

  OPEN V_RESULT_SET FOR
     SELECT
       A.pre_auth_number ,
       A.tpa_enrollment_id ,
       A.claimant_name,
       to_char(PII.Pat_Ins_Send_Date,'DD-MON-YYYY') as recommend_date,
       B.pat_requested_amount as requested_amount,
       nvl(round((SELECT SUM(approved_amount)
              FROM ailment_caps x JOIN icd_pcs_detail y ON ( x.icd_pcs_seq_id = y.icd_pcs_seq_id )
              WHERE y.Pat_Gen_Detail_Seq_Id = B.PAT_GEN_DETAIL_SEQ_ID)),0) as total_app_amount,
       B.total_app_amount as payble_amount,
       H.hosp_name ,
       to_char(A.date_of_hospitalization,'DD-MON-YYYY') as date_of_admission,
       G.description pat_status,
       to_char(PII.pat_ins_decision_date,'DD-MON-YYYY') AS pat_ins_decision_date,
       f.description as tpa_status,
       nvl(B.co_payment_amount,0)+nvl(B.co_payment_buffer_amount,0) co_pay_amount


      FROM pat_enroll_details A
      JOIN pat_general_details B ON (A.pat_enroll_detail_seq_id = b.pat_enroll_detail_seq_id AND b.pat_enhanced_yn='N')
      left outer join pat_ins_intimation_details pii on (a.PAT_ENROLL_DETAIL_SEQ_ID= pii.pat_auth_seq_id)
      LEFT OUTER JOIN tpa_hosp_info H ON (A.hosp_seq_id = H.hosp_seq_id)
      LEFT OUTER JOIN tpa_enr_policy I ON ( A.policy_seq_id = I.policy_seq_id)
      LEFT OUTER JOIN tpa_general_code G ON (pii.Pat_Ins_Status=G.general_type_id)
      LEFT OUTER JOIN tpa_general_code f ON (a.pat_status_general_type_id=f.general_type_id)
      left outer join tpa_ins_info j on (i.ins_seq_id=j.ins_seq_id)
      WHERE PII.Pat_Ins_Decision_Date >= to_date(str_tab(3),'dd/mm/yyyy')
      AND  PII.Pat_Ins_Decision_Date <= to_date(str_tab(4),'dd/mm/yyyy')+1
      AND i.ins_seq_id IN (SELECT ins_seq_id FROM tpa_ins_info
                                            START WITH ins_seq_id  = v_ins_seq_id
                                               CONNECT BY PRIOR ins_seq_id  = ins_parent_seq_id)
      AND  pii.pat_ins_status in ('APR','REJ')
      and j.ins_comp_code_number=str_tab(2)
      ORDER BY PII.PAT_INS_DECISION_DATE ASC;
  end if;

end   gen_pat_apr_rej_rpt;
--=======================================================================================================
procedure gen_clm_apr_rej_rpt (v_where varchar2,
                               v_result_set out sys_refcursor) is

   str_tab ttk_util_pkg.str_table_type;
  v_ins_seq_id tpa_ins_info.ins_seq_id%type;

BEGIN

  str_tab:=ttk_util_pkg.parse_str(v_where);

  SELECT ins_seq_id into v_ins_seq_id FROM TPA_USER_CONTACTS A
  WHERE A.CONTACT_SEQ_ID=str_tab(1);

IF str_tab(2) IS NULL  THEN

  OPEN V_RESULT_SET FOR
     SELECT
       A.claim_number ,
       B.tpa_enrollment_id ,
       B.claimant_name,
       A.requested_amount,
       nvl(round((SELECT SUM(approved_amount)
              FROM ailment_caps x JOIN icd_pcs_detail y ON ( x.icd_pcs_seq_id = y.icd_pcs_seq_id )
              WHERE y.claim_seq_id = a.claim_seq_id)),0) as total_app_amount,
       A.total_app_amount as payble_amount,
       to_char(CII.CLM_INS_SEND_DATE,'DD-MON-YYYY') recommend_date,
       H.hosp_name ,
       to_char(A.date_of_admission,'DD-MON-YYYY') AS date_of_admission,
       G.description claim_status,
       to_char(CII.clm_ins_decision_date,'DD-MON-YYYY') AS clm_ins_decision_date,
       f.description as tpa_status,
       nvl(a.co_payment_amount,0)+nvl(a.co_payment_buffer_amount,0) co_pay_amount

      FROM clm_general_details A
      JOIN clm_enroll_details B ON (A.claim_seq_id = b.claim_seq_id )
      JOIN clm_inward C ON ( a.claims_inward_seq_id = c.claims_inward_seq_id)
      left outer join clm_ins_intimation_details cii on (b.claim_seq_id=cii.claim_seq_id)
      LEFT OUTER JOIN clm_hospital_association H ON (A.claim_seq_id = H.claim_seq_id)
      LEFT OUTER JOIN tpa_enr_policy I ON ( B.policy_seq_id = I.policy_seq_id)
      LEFT OUTER JOIN tpa_general_code G ON (cii.Clm_Ins_Status=G.general_type_id)
      LEFT OUTER JOIN tpa_general_code f ON (b.clm_status_general_type_id=f.general_type_id)
      left outer join tpa_ins_info j on (i.ins_seq_id=j.ins_seq_id)
      WHERE   CII.CLM_INS_DECISION_DATE >= to_date(str_tab(3),'dd/mm/yyyy')
      AND  CII.CLM_INS_DECISION_DATE <= to_date(str_tab(4),'dd/mm/yyyy')+1
      AND i.ins_seq_id IN (SELECT ins_seq_id FROM tpa_ins_info
                                            START WITH ins_seq_id  = v_ins_seq_id
                                               CONNECT BY PRIOR ins_seq_id  = ins_parent_seq_id)
      AND  cii.CLM_INS_STATUS in ('APR','REJ')
      ORDER BY CII.CLM_INS_DECISION_DATE ASC;
ELSE

  OPEN V_RESULT_SET FOR
     SELECT
       A.claim_number ,
       B.tpa_enrollment_id ,
       B.claimant_name,
       A.requested_amount,
        nvl(round((SELECT SUM(approved_amount)
              FROM ailment_caps x JOIN icd_pcs_detail y ON ( x.icd_pcs_seq_id = y.icd_pcs_seq_id )
              WHERE y.claim_seq_id = a.claim_seq_id)),0) as total_app_amount,
       A.total_app_amount as payble_amount,
       to_char(CII.CLM_INS_SEND_DATE,'DD-MON-YYYY') recommend_date,
       H.hosp_name ,
       to_char(A.date_of_admission,'DD-MON-YYYY') AS date_of_admission,
       G.description claim_status,
       to_char(CII.clm_ins_decision_date,'DD-MON-YYYY') AS clm_ins_decision_date,
       f.description as tpa_status,
       nvl(a.co_payment_amount,0)+nvl(a.co_payment_buffer_amount,0) co_pay_amount


      FROM clm_general_details A
      JOIN clm_enroll_details B ON (A.claim_seq_id = b.claim_seq_id)
      JOIN clm_inward C ON ( a.claims_inward_seq_id = c.claims_inward_seq_id)
      left outer join clm_ins_intimation_details cii on (b.claim_seq_id=cii.claim_seq_id)
      LEFT OUTER JOIN clm_hospital_association H ON (A.claim_seq_id = H.claim_seq_id)
      LEFT OUTER JOIN tpa_enr_policy I ON ( B.policy_seq_id = I.policy_seq_id)
      LEFT OUTER JOIN tpa_general_code G ON (cii.Clm_Ins_Status=G.general_type_id)
      LEFT OUTER JOIN tpa_general_code f ON (b.clm_status_general_type_id=f.general_type_id)
      left outer join tpa_ins_info j on (i.ins_seq_id=j.ins_seq_id)
      WHERE CII.CLM_INS_DECISION_DATE >= to_date(str_tab(3),'dd/mm/yyyy')
      AND  CII.CLM_INS_DECISION_DATE <= to_date(str_tab(4),'dd/mm/yyyy')+1
      AND i.ins_seq_id IN (SELECT ins_seq_id FROM tpa_ins_info
                                            START WITH ins_seq_id  = v_ins_seq_id
                                               CONNECT BY PRIOR ins_seq_id  = ins_parent_seq_id)
      AND  cii.CLM_INS_STATUS in ('APR','REJ')
      and j.ins_comp_code_number=str_tab(2)
      ORDER BY CII.CLM_INS_DECISION_DATE ASC;
 end if;

end gen_clm_apr_rej_rpt;
--=======================================================================================================
procedure pat_clm_doc_upload(v_pat_seq_id in pat_general_details.pat_gen_detail_seq_id%type,
                            v_clm_seq_id in clm_general_details.claim_seq_id%type,
                            v_file_name  in varchar2,
                            V_remarks    in varchar2,
                            v_added_by   in pat_general_details.added_by%type,
                            v_rows_processed out number) is

v_pat_enrol_seq_id  pat_enroll_details.pat_enroll_detail_seq_id%type;
v_status clm_general_details.completed_yn%type;
begin

 if v_pat_seq_id is not null then

       select pat_enroll_detail_seq_id,a.completed_yn into v_pat_enrol_seq_id,v_status
       from pat_general_details a
       where a.pat_gen_detail_seq_id=v_pat_seq_id;
       if v_status='N' THEN

    update PAT_ins_intimation_details b
    set b.file_name=v_file_name,
        b.file_upload_remarks=substr(v_remarks||' - '||v_file_name||' - '||app.account_info_pkg.get_gen_desc(v_added_by,'U')||' - '||TO_CHAR(SYSDATE,'DD-MON-YYYY HH:MI:SS AM')||chr(13),1,1000),
        b.file_uploaded_by=v_added_by,
        b.updated_by=v_added_by,
        b.updated_date=sysdate
    WHERE B.pat_auth_seq_id=v_pat_enrol_seq_id;
        ELSE
  RAISE_APPLICATION_ERROR(-20107,'You cannot perform this action for completed Preauth/Claim');
        end if;
else
select a.completed_yn into v_status from clm_general_details a
where a.claim_seq_id=v_clm_seq_id;

      if v_status='N' THEN
      update clm_ins_intimation_details a
      set a.file_name=v_file_name,
          a.file_upload_remarks=substr(v_remarks||' - '||v_file_name||' - '||app.account_info_pkg.get_gen_desc(v_added_by,'U')||' - '||TO_CHAR(SYSDATE,'DD-MON-YYYY HH:MI:SS AM')||chr(13),1,1000),
          a.file_uploaded_by=v_added_by,
          a.updated_by=v_added_by,
          a.updated_date=sysdate
      WHERE A.claim_seq_id=v_clm_seq_id;
      ELSE
  RAISE_APPLICATION_ERROR(-20107,'You cannot perform this action for completed Preauth/Claim');
      end if;

 END IF;
   v_rows_processed:=sql%rowcount;
     commit;


end pat_clm_doc_upload;
--======================================================================================================
procedure pat_clm_override (v_pat_seq_id in pat_general_details.pat_gen_detail_seq_id%type,
                            v_clm_seq_id in clm_general_details.claim_seq_id%type,
                            v_added_by   in pat_general_details.added_by%type,
                            V_rows_processed out number) is

v_pat_enrol_seq_id          pat_enroll_details.pat_enroll_detail_seq_id%type;
v_status                    pat_enroll_details.pat_status_general_type_id%type;
v_ins_status                pat_ins_intimation_details.pat_ins_status%type;

begin

   if v_pat_seq_id is not null then

       select a.pat_enroll_detail_seq_id,pii.pat_ins_status,b.pat_status_general_type_id into v_pat_enrol_seq_id,v_ins_status,v_status
       from pat_general_details a
       join pat_enroll_details b on (a.pat_enroll_detail_seq_id=b.pat_enroll_detail_seq_id)
       left outer join pat_ins_intimation_details pii on (b.PAT_ENROLL_DETAIL_SEQ_ID= pii.pat_auth_seq_id)
       where a.pat_gen_detail_seq_id=v_pat_seq_id;

    update pat_ins_intimation_details b
    set b.override_yn='Y',
        b.override_done_by=v_added_by,
        B.OVERRIDDEN_DATE=SYSDATE,
        b.pat_ins_status=null,--case when v_status='REJ' AND v_ins_status='APR' THEN b.pat_ins_status ELSE NULL end,
        b.updated_by=v_added_by,
        b.updated_date=sysdate
    WHERE B.pat_auth_seq_id=v_pat_enrol_seq_id;

   else

   select cii.clm_ins_status,a.clm_status_general_type_id into v_ins_status,v_status
    from clm_enroll_details a
    left outer join clm_ins_intimation_details cii on (a.claim_seq_id=cii.claim_seq_id)
   where a.claim_seq_id=v_clm_seq_id;

      update clm_ins_intimation_details a
      set a.override_yn='Y',
          a.override_done_by=v_added_by,
          A.OVERRIDDEN_DATE=SYSDATE,
          a.clm_ins_status=null,--case when v_status='REJ' AND v_ins_status='APR' THEN a.clm_ins_status ELSE NULL end,
          a.updated_by=v_added_by,
          a.updated_date=sysdate
      WHERE A.claim_seq_id=v_clm_seq_id;

   END IF;

   v_rows_processed:=sql%rowcount;

   commit;

end pat_clm_override;
--=====================================================================================
PROCEDURE clm_ins_apr_save_xfdf(v_clm_numbers          IN varchar2,
                                v_appr_rej_status      IN clm_ins_intimation_details.clm_ins_status%TYPE,
                                v_remarks              IN clm_ins_intimation_details.clm_ins_remarks%TYPE) IS

  v_flag                  clm_general_details.completed_yn%type;
  v_clm_seq_id            clm_general_details.claim_seq_id%type;
  v_clm_ins_status        clm_ins_intimation_details.clm_ins_status%type;

  seq_tab                ttk_util_pkg.str_table_type;

  v_prod_policy_seq_id        tpa_ins_prod_policy.prod_policy_seq_id%TYPE;

  cursor clm_cur(v_seq_id clm_enroll_details.claim_seq_id%type) is
  select cii.Clm_Ins_Status AS prev_ins_status,CII.CLM_INS_REMARKS AS prev_ins_remarks,
  a.clm_status_general_type_id as clm_status
  from clm_enroll_details  a
  left outer join clm_ins_intimation_details cii on (a.claim_seq_id=cii.claim_seq_id)
  where a.claim_seq_id=v_seq_id
  and cii.clm_ins_status is not null
  and cii.clm_ins_status!='INP';

  clm_rec clm_cur%rowtype;

  v_status               clm_ins_intimation_details.clm_ins_status%type;


  BEGIN


    SELECT cg.completed_yn,cg.claim_seq_id,cii.clm_ins_status INTO v_flag,v_clm_seq_id,v_clm_ins_status
    FROM clm_general_details cg
    join clm_enroll_details ce on (cg.claim_seq_id=ce.claim_seq_id)
    left outer join clm_ins_intimation_details cii on (ce.claim_seq_id=cii.claim_seq_id)
    WHERE cg.claim_number=v_clm_numbers  ;

      IF v_flag='Y' or v_clm_ins_status is null THEN
        Raise_application_error(-20868,'No Modifications Are Allowed, Claim Needs Insurance company Response');
      END IF;

    open clm_cur(v_clm_seq_id);
    fetch clm_cur into clm_rec;
    close clm_cur;

      v_status:=CASE WHEN clm_rec.clm_status='APR' AND  v_appr_rej_status='TRAD' THEN 'APR'
                                              WHEN clm_rec.clm_status='REJ' AND  v_appr_rej_status='TRAD' THEN 'REJ'
                                              ELSE 'REQ' END;


    if clm_rec.clm_status not in ('APR','REJ') AND v_appr_rej_status IS NOT NULL THEN
       Raise_application_error(-20868,'No Modifications Are Allowed, Preauth/Claim Already intimated to TPA.');
    end if;

    if clm_rec.prev_ins_status=v_appr_rej_status and clm_rec.prev_ins_remarks=substr(v_appr_rej_status||'--'||SYSDATE||'--'||v_remarks,1,1000) then
      raise_application_error(-20836,'Preauth/Claim Already intimated to TPA, Please change the Status/Remarks.');
    end if;



     UPDATE clm_ins_intimation_details ce
       SET ce.clm_ins_status           = v_status,
           ce.clm_ins_decision_date    = SYSDATE,
           ce.clm_ins_remarks          = substr(app.account_info_pkg.get_gen_desc(v_appr_rej_status,'G')||'--'||TO_CHAR(SYSDATE,'DD-MON-YYYY HH:MI:SS AM')||'--'||v_remarks,1,1000),
           CE.UPDATED_BY               = 1,
           CE.UPDATED_DATE             = SYSDATE
      WHERE  ce.claim_seq_id           = v_clm_seq_id;

  COMMIT;

    v_prod_policy_seq_id:=pre_auth_pkg.get_prod_pol_seq_id(v_clm_seq_id,'CLM');
    generate_mail_pkg.proc_generate_mail('TTK_SPOC_CLM_RESP',v_clm_seq_id,v_prod_policy_seq_id,1);


 END clm_ins_apr_save_xfdf;
 --=====================================================================================
PROCEDURE pat_ins_apr_save_xfdf(v_pat_numbers          IN  varchar2,
                               v_appr_rej_status      IN pat_ins_intimation_details.pat_ins_status%TYPE,
                               v_remarks              IN pat_ins_intimation_details.pat_ins_remarks%TYPE) IS

  v_pat_enroll_detail_seq_id          pat_enroll_details.pat_enroll_detail_seq_id%TYPE;
  v_pat_completed                     pat_general_details.completed_yn%TYPE;
  v_pat_ins_status                    pat_ins_intimation_details.pat_ins_status%type;
  seq_tab                ttk_util_pkg.str_table_type;
  v_prod_policy_seq_id        tpa_ins_prod_policy.prod_policy_seq_id%TYPE;

  cursor pat_cur(v_seq_id pat_enroll_details.PAT_ENROLL_DETAIL_SEQ_ID%type) is
  select pii.pat_ins_status AS prev_ins_status,PII.Pat_Ins_Remarks AS prev_ins_remarks,
  a.pat_status_general_type_id as pat_status,B.PAT_GEN_DETAIL_SEQ_ID
  from pat_enroll_details  a
  join pat_general_details b on (a.pat_enroll_detail_seq_id=b.pat_enroll_detail_seq_id AND B.PAT_ENHANCED_YN='N')
  left outer join pat_ins_intimation_details pii on (a.PAT_ENROLL_DETAIL_SEQ_ID= pii.pat_auth_seq_id)
  where A.PAT_ENROLL_DETAIL_SEQ_ID=v_seq_id
  and pii.pat_ins_status is not null
  and pii.pat_ins_status!='INP';

  pat_rec pat_cur%rowtype;
    v_status               clm_ins_intimation_details.clm_ins_status%type;

  BEGIN
    SELECT g.pat_enroll_detail_seq_id,g.completed_yn,pii.pat_ins_status INTO v_pat_enroll_detail_seq_id,v_pat_completed,v_pat_ins_status FROM pat_general_details g
    join pat_enroll_details h on (g.pat_enroll_detail_seq_id=h.pat_enroll_detail_seq_id AND  G.PAT_ENHANCED_YN='N')
    left outer join pat_ins_intimation_details pii on (h.PAT_ENROLL_DETAIL_SEQ_ID= pii.pat_auth_seq_id)
    WHERE h.pre_auth_number=v_pat_numbers;

    open pat_cur(v_pat_enroll_detail_seq_id);
    fetch pat_cur into pat_rec;
    close pat_cur;

    v_status:=CASE WHEN pat_rec.Pat_Status='APR' AND  v_appr_rej_status='TRAD' THEN 'APR'
                                              WHEN pat_rec.Pat_Status='REJ' AND  v_appr_rej_status='TRAD' THEN 'REJ'
                                              ELSE 'REQ' END;


     if pat_rec.pat_status not in ('APR','REJ') AND v_appr_rej_status IS NOT NULL THEN
       Raise_application_error(-20868,'No Modifications Are Allowed, Preauth/Claim Already intimated to TPA.');
     end if;

     IF v_pat_completed='Y' or v_pat_ins_status is null THEN
        Raise_application_error(-20868,'No Modifications Are Allowed, Claim Needs Insurance company Response');
     END IF;

     if pat_rec.prev_ins_status=v_appr_rej_status and pat_rec.prev_ins_remarks=substr(v_appr_rej_status||'--'||SYSDATE||'--'||v_remarks,1,1000) then
      raise_application_error(-20836,'Preauth/Claim Already intimated to TPA, Please change the Status/Remarks.');
     end if;




     UPDATE pat_ins_intimation_details pe
       SET pe.pat_ins_status              = v_status,
           pe.pat_ins_decision_date       = SYSDATE,
           pe.pat_ins_remarks             = substr(app.account_info_pkg.get_gen_desc(v_appr_rej_status,'G')||'--'||TO_CHAR(SYSDATE,'DD-MON-YYYY HH:MI:SS AM')||'--'||v_remarks,1,1000),
           PE.UPDATED_BY                  = 1,
           PE.UPDATED_DATE                = SYSDATE
      WHERE pe.pat_auth_seq_id   = v_pat_enroll_detail_seq_id;


  COMMIT;
  v_prod_policy_seq_id:=pre_auth_pkg.get_prod_pol_seq_id(pat_rec.Pat_Gen_Detail_Seq_Id,'PAT');
  generate_mail_pkg.proc_generate_mail('TTK_SPOC_PAT_RESP',pat_rec.Pat_Gen_Detail_Seq_Id,v_prod_policy_seq_id,1);

 END pat_ins_apr_save_xfdf;

--=====================================================================================


 function get_srtfall_remarks(v_flag         IN CHAR, -- OTHERS FOR OTHERS QUERY, CHCEKBOX FOR CHECKBOXES
                             v_mode         IN CHAR , --"PAT" FOR PREAUTH, "CLM" FOR CLAIMS
                             v_seq_id       IN CLM_GENERAL_DETAILS.CLAIM_SEQ_ID%TYPE)   RETURN clob

is
cursor clm_srtfll_other_queries is
SELECT
        extractValue(value(lm), '/query/@value') as question
   FROM shortfall_details bb,
        table(XMLSequence(extract(bb.shortfall_questions,
                                  '/shortfall/section/subsection/query[@type="text"]'))) LM
  WHERE bb.shortfall_seq_id = (select max(a.shortfall_seq_id) as seq_id
                                 from shortfall_details a
                                 where a.claim_seq_id=v_seq_id);

cursor pat_srtfll_other_queries is
SELECT
        extractValue(value(lm), '/query/@value') as question
   FROM shortfall_details bb,
        table(XMLSequence(extract(bb.shortfall_questions,
                                  '/shortfall/section/subsection/query[@type="text"]'))) LM
  WHERE bb.shortfall_seq_id = (select max(a.shortfall_seq_id) as seq_id
                              from shortfall_details a
                              where a.pat_gen_detail_seq_id=v_seq_id);

cursor clm_srtfll_queries is
 SELECT  (wm_concat(B.RNK||'.'||B.QUESTION)) AS QUESTIONS
                  FROM (SELECT extractValue(value(ll), '/query/@postlabel') as question,
                       DENSE_RANK() OVER (ORDER BY extractValue(value(ll), '/query/@postlabel')) AS RNK
                       FROM shortfall_details Aa,
                       table(XMLSequence(extract(Aa.shortfall_questions ,'/shortfall/section/subsection/query[@type="checkbox"]'))) LL
                       WHERE Aa.shortfall_seq_id = (select max(a.shortfall_seq_id) as seq_id from shortfall_details a
                       where a.claim_seq_id=v_seq_id) ) B;

cursor pat_srtfll_queries is
 SELECT  wm_concat(B.RNK||'.'||B.QUESTION) AS QUESTIONS
                  FROM (SELECT extractValue(value(ll), '/query/@postlabel') as question,
                       DENSE_RANK() OVER (ORDER BY extractValue(value(ll), '/query/@postlabel')) AS RNK
                       FROM shortfall_details Aa,
                       table(XMLSequence(extract(Aa.shortfall_questions ,'/shortfall/section/subsection/query[@type="checkbox"]'))) LL
                       WHERE Aa.shortfall_seq_id = (select max(a.shortfall_seq_id) as seq_id from shortfall_details a
                       where a.pat_gen_detail_seq_id=v_seq_id)) B;

v_shortfall_remarks    clob;
begin
if v_mode='PAT' THEN
  IF v_flag='OTHERS' THEN
    for pat_srtfll_rec in  pat_srtfll_other_queries loop
      v_shortfall_remarks:=v_shortfall_remarks||pat_srtfll_rec.question;
    end loop;
  ELSIF v_flag='CHECKBOX' THEN
    for pat_srtfll_rec in  pat_srtfll_queries loop
      v_shortfall_remarks:=v_shortfall_remarks||pat_srtfll_rec.questions;
    end loop;
  END IF;
ELSIF v_mode='CLM' THEN
 IF v_flag='OTHERS' THEN
    for clm_srtfll_rec in  clm_srtfll_other_queries loop
      v_shortfall_remarks:=v_shortfall_remarks||clm_srtfll_rec.question;
    end loop;
  ELSIF v_flag='CHECKBOX' THEN
    for clm_srtfll_rec in  clm_srtfll_queries loop
      v_shortfall_remarks:=v_shortfall_remarks||clm_srtfll_rec.questions;
    end loop;
  END IF;
END IF;

RETURN replace(v_shortfall_remarks,'?','');
END get_srtfall_remarks;

--==============================================================================================

PROCEDURE preauth_xfdf_report (v_pat_gen_detail_seq_id    pat_general_details.pat_gen_detail_seq_id%TYPE,
                               v_file_name out varchar2,
                               v_generate_yn out char) IS

 v_doc              dbms_xmldom.DOMDocument;
 v_main_node        dbms_xmldom.DOMNode;
 v_root_node        dbms_xmldom.DOMNode;
 v_chld_node        dbms_xmldom.DOMNode;
 v_chld_node2       dbms_xmldom.DOMNode;
 v_chld_node3       dbms_xmldom.DOMNode;
 v_node             dbms_xmldom.domnode;
 v_elem             dbms_xmldom.DOMElement;
 v_out_xml          sys.xmltype;
 v_elem2            dbms_xmldom.DOMElement;
 v_text             dbms_xmldom.DOMText;

 v_file            UTL_FILE.FILE_TYPE;
 v_clob            CLOB;
 i                 PLS_INTEGER:=1;
 j                 PLS_INTEGER:=1;
 p                 PLS_INTEGER:=1;
 t                 PLS_INTEGER:=1;
 v_room_col        VARCHAR2(20);
 v_room_charge     VARCHAR2(20);

  TYPE tab IS VARRAY(5) OF VARCHAR2(10);
  rec_tab      tab:=tab('ROOM','PROF','OTHER','NA');

 CURSOR cur_clm IS
SELECT   pg.pat_gen_detail_seq_id,
         NULL AS  claim_no,--pe.pre_auth_number         claim_no,
         peg.insured_name           proposer_name,
         pe.claimant_name           patient_name,
         peg.employee_no            employee_customer_id,
         pe.tpa_enrollment_id       tpa_id,
         round(pe.mem_age)          patient_age,
         app.account_info_pkg.get_gen_desc(pem.relship_type_id,'R')        Relation,
         app.account_info_pkg.get_gen_desc(pem.gender_general_type_id,'G') Gender,
         pol.policy_number          policy_no,
         tip.product_name,
         to_char(pol.effective_from_date,'DD-MON-YYYY')  policy_form,
         to_char(pol.effective_to_date,'DD-MON-YYYY')    policy_upto,
         eb.sum_insured,
         CASE WHEN POL.POLICY_SUB_GENERAL_TYPE_ID ='PFL' THEN PEG.FLOATER_TOT_BONUS ELSE pem.mem_tot_bonus END  buffer_bonus,
         ma.address_1||' '||ma.address_2||' '||ma.address_3 address,
         to_char(pg.pat_received_date,'DD-MON-YYYY') intimation_date,
         to_char(pg.pat_received_date,'DD-MON-YYYY') date_of_doc_rec,
         to_char(pe.date_of_hospitalization,'DD-MON-YYYY') loss_date,
         hi.hosp_name hospital_name,
         NVL(app.account_info_pkg.get_gen_desc(HA.CITY_TYPE_ID,'CT') , ha.city )     hospital_city,
         NVL(app.account_info_pkg.get_gen_desc(HA.STATE_TYPE_ID,'S'), ha.state)     hospital_state,
         ha.pin_code  hospital_pincode,
         substr(replace(replace(al.provisional_diagnosis,chr(13),''),chr(10),' '),1,500) diagnosis,
         buffer_changes_pkg.f_icd_code_desc_pat(pg.pat_gen_detail_seq_id,'IC','IC1') diagnosis_code_level_1,
         buffer_changes_pkg.f_icd_code_desc_pat(pg.pat_gen_detail_seq_id,'IC','IC2') diagnosis_code_level_2,
         buffer_changes_pkg.f_icd_code_desc_pat(pg.pat_gen_detail_seq_id,'IC','ID1') diagnosis_description_level_1,
         buffer_changes_pkg.f_icd_code_desc_pat(pg.pat_gen_detail_seq_id,'IC','ID2') diagnosis_description_level_2,

         buffer_changes_pkg.f_icd_code_desc_pat(pg.pat_gen_detail_seq_id,'PC','PC1') procedure_codes_level_1,
         buffer_changes_pkg.f_icd_code_desc_pat(pg.pat_gen_detail_seq_id,'PC','PC2') procedure_codes_level_2,
         buffer_changes_pkg.f_icd_code_desc_pat(pg.pat_gen_detail_seq_id,'PC','PD1') procedure_description_level_1,
         buffer_changes_pkg.f_icd_code_desc_pat(pg.pat_gen_detail_seq_id,'PC','PD2') procedure_description_level_2,
         to_char(pg.likely_date_of_hospitalization,'DD-MON-YYYY') doa,
         to_char((pg.likely_date_of_hospitalization+al.duration_of_hospitalization),'DD-MON-YYYY') dod,
         'CASHLESS' claim_type,
         app.account_info_pkg.get_gen_desc(pg.pat_general_type_id,'G') claim_category,
         app.account_info_pkg.get_gen_desc(pol.enrol_type_id,'E') policy_type,
         pg.pat_requested_amount estimate_amt,
         pg.total_app_amount claim_amount,
         NVL(ROUND((SELECT SUM(approved_amount)
              FROM ailment_caps x JOIN icd_pcs_detail y ON ( x.icd_pcs_seq_id = y.icd_pcs_seq_id )
              WHERE y.pat_gen_detail_seq_id= pg.pat_gen_detail_seq_id)),0) recommend_amount,
         NVL(pg.co_payment_amount,0)+nvl(pg.co_payment_buffer_amount,0) co_pay_amount,
         NVL(ROUND((SELECT SUM(approved_amount)
              FROM ailment_caps x JOIN icd_pcs_detail y ON ( x.icd_pcs_seq_id = y.icd_pcs_seq_id )
              WHERE y.pat_gen_detail_seq_id= pg.pat_gen_detail_seq_id)),0) AS approved_amount,
         pg.pat_requested_amount-nvl(pg.total_app_amount,0) deducted_amount,
         '' deduction_reason,
         '0' compulsary_deduction,
         '0' service_tax_amount,
         hi.serv_tax_rgn_number service_tax_no,
         nvl(pg.total_app_amount,'0') payble_amount,
         0 tds_amount,
         0 net_payble_amt,
         to_char(PII.PAT_INS_SEND_DATE,'DD-MON-YYYY') recommend_on,
         to_char(pe.decision_date,'DD-MON-YYYY') approved_on,
         0 pay_to_insured,
         nvl(pg.total_app_amount,0) pay_to_hospital,
         nvl(pol.buffer_alloc_amount,0) corporate_buffer,
          nvl(pol.med_buff_alloc_amount,0) medical_buffer,
          nvl(pol.crit_buff_alloc_amount,0) critical_buffer,
          nvl(pol.crit_corp_buff_alloc_amount,0) critical_corporate_buffer,
          nvl(pol.crit_med_buff_alloc_amount,0) critical_medical_buffer,
         NULL cheque_no,
         NULL cheque_date,
         hi.hosp_name clm_pay_to_beneficiary_name,
         buffer_changes_pkg.fn_sfremarks_pat(pg.pat_gen_detail_seq_id) as disc_datails,
         --CLAIMS_APPROVAL_PKG.get_srtfall_remarks('CHECKBOX','PAT',PG.PAT_GEN_DETAIL_SEQ_ID)||' ******* Other Queries: '||CLAIMS_APPROVAL_PKG.get_srtfall_remarks('OTHERS','PAT',PG.PAT_GEN_DETAIL_SEQ_ID) AS  disc_datails,
         to_char(sf.min_sfdt,'DD-MON-YYYY') insured_disc_date,
         to_char(sf.max_sfdt,'DD-MON-YYYY') insured_reminder_date,
         to_char(sf.max_sfdt,'DD-MON-YYYY') insured_final_reminder_date,
         to_char(sf.sf_responded_dt,'DD-MON-YYYY') insured_reply_recieved_date,
         NULL hospital_disc_date,
         NULL hospital_reminder_date,
         NULL hospital_final_reminder_date,
         NULL hospital_reply_recieved_date,
         NULL insurer_disc_date,
         NULL insurer_reminder_date,
         NULL insurer_final_reminder_date,
         NULL insurer_reply_recieved_date,
         to_char(pg.pat_received_date,'DD-MON-YYYY') pre_auth_received_on,
         pe.pre_auth_number  pre_auth_letter_no,
         app.account_info_pkg.get_gen_desc(pe.pat_status_general_type_id,'G') pre_auth_status,
         nvl(pg.total_app_amount,'0') pre_auth_amount,
         to_char(pe.decision_date,'DD-MON-YYYY') pre_auth_approved_on,
         NULL float_no,
         NULL float_date,
         NULL payment_date,
         '0' agent_code,
         pol.dev_officer_code development_code,
         tii.ins_comp_name  operating_office,
         tii.ins_comp_code_number  operating_code,
         NVL(app.account_info_pkg.get_gen_desc(tas.City_Type_Id,'CT'),TAS.CITY)  ins_city,
         NVL(app.account_info_pkg.get_gen_desc(tas.State_Type_Id,'S'),TAS.STATE)  ins_state,
           tas.pin_code ins_pincode,
         NULL controlling_office,
         tii.ins_comp_name  insurance_company,
         NULL settelement_type,
         NULL settelement_date,
         regexp_replace(au.remarks, '[[:space:]]',' ') as repudiation_rejection_reason,
         pe.pat_status_general_type_id AS status,
         NULL benefit_type,
         NULL bill_entered_by,
         NULL bill_entry_location,
         hi.empanel_number hospital_code,
         pe.member_seq_id,
         peg.tpa_enrollment_number enr_num,
         'Bangalore' as premium_zone,
         regexp_replace(au.remarks, '[[:space:]]',' ') as remarks

     FROM pat_general_details pg
          JOIN pat_enroll_details pe ON (pe.pat_enroll_detail_seq_id=pg.pat_enroll_detail_seq_id and pg.pat_enhanced_yn='N')
          left outer join PAT_ins_intimation_details PII on (PE.PAT_ENROLL_DETAIL_SEQ_ID=Pii.Pat_Auth_Seq_Id)
          JOIN assign_users au ON (au.assign_users_seq_id=pg.last_assign_user_seq_id)
          JOIN tpa_enr_policy pol ON (pol.policy_seq_id=pe.policy_seq_id)
          JOIN tpa_enr_policy_member pem ON (pem.member_seq_id=pe.member_seq_id)
          JOIN tpa_enr_policy_group peg  ON (peg.policy_group_seq_id=pem.policy_group_seq_id)
          JOIN tpa_ins_product tip ON (tip.product_seq_id=pol.product_seq_id)
          JOIN tpa_enr_mem_address ma ON (peg.enr_address_seq_id=ma.enr_address_seq_id)
          JOIN tpa_enr_balance eb ON (eb.policy_group_seq_id=peg.policy_group_seq_id)
          JOIN tpa_hosp_info  hi ON (pe.hosp_seq_id=hi.hosp_seq_id)
          JOIn tpa_hosp_address ha ON (ha.hosp_seq_id=hi.hosp_seq_id)
          JOIN tpa_ins_info tii ON (tii.ins_seq_id=pe.ins_seq_id)
          JOIN tpa_address tas on (tas.ins_seq_id=tii.ins_seq_id)
          LEFT OUTER JOIN tpa_group_registration tgr on (tgr.group_reg_seq_id=pol.group_reg_seq_id)
          LEFT OUTER JOIN ailment_details al ON (al.pat_gen_detail_seq_id=pg.pat_gen_detail_seq_id)
          LEFT OUTER JOIN (SELECT  sd.pat_gen_detail_seq_id pat_id, MIN (sd.added_date) min_sfdt,
                                   MAX(sd.added_date) max_sfdt, MAX(sd.closed_date) sf_closeddt,
                                   MAX(sd.srtfll_received_date) SF_Responded_Dt
                           FROM shortfall_details sd
                           GROUP BY sd.pat_gen_detail_seq_id) sf ON (sf.pat_id = pg.pat_gen_detail_seq_id)
    WHERE pg.pat_gen_detail_seq_id=v_pat_gen_detail_seq_id
    AND (pem.mem_general_type_id = 'PFL'
    AND eb.member_seq_id IS NULL OR pem.member_seq_id = eb.member_seq_id OR pem.member_seq_id IS NULL);

  clm_rec   cur_clm%ROWTYPE;

  CURSOR cur_bills(v_seq_id           clm_general_details.claim_seq_id%TYPE,
                   v_charges_type     tpa_hosp_ward_code.ward_type_id%TYPE) IS
    WITH bv AS( SELECT B.PAT_GEN_DETAIL_SEQ_ID AS claim_seq_id,A.WARD_TYPE_ID,

        CASE WHEN A.ward_type_id IN('BED','DMO','DRC','ICN','ICR','IJC','NUC','RMO','ROO') THEN 'ROOM'
               WHEN A.ward_type_id IN('ANC','ASC','CDL','CON','DLC','EME','ICU','ICC','NDL','OPC','PYC','POC','PRO','SPE','SUF') THEN 'PROF'
               WHEN A.ward_type_id IN('ADC','ADM','ATN','BIC','CTL','COB','DIS','DEC','DSC','DOB','FDC','HAA','HVC','MLC','MIS','PDC','REF','SEC','STC','SUR','WCW','WCC') THEN 'NA'
               ELSE 'OTHER' END charges_type,
                  A.ward_description AS charges,
          SUM(B.REQUESTED_AMOUNT) AS amt
       FROM tpa_hosp_ward_code a LEFT OUTER JOIN pat_tariff_details B ON ( a.ward_type_id = b.ward_type_id )
       LEFT OUTER JOIN app.TPA_VACCINATION_CODE C ON (B.VACCINATION_TYPE_ID=C.VACCINATION_ID)  --KOC1164
       WHERE b.pat_gen_detail_seq_id = v_pat_gen_detail_seq_id  --and B.APPROVED_AMOUNT>0
       GROUP BY  B.PAT_GEN_DETAIL_SEQ_ID,A.WARD_TYPE_ID, A.WARD_DESCRIPTION )
      SELECT * FROM bv WHERE charges_type =v_charges_type;

  CURSOR cur_pol(v_tpa_enr_no   tpa_enr_policy_group.tpa_enrollment_number%TYPE,
                 v_pol_no       tpa_enr_policy.policy_number%TYPE ) IS
  WITH tab_bal AS (
     SELECT rank() over(PARTITION BY pg.tpa_enrollment_number ORDER BY pg.policy_group_seq_id DESC) AS rnk,
         pg.policy_group_seq_id,
         ep.policy_number,
         ep.renewal_policy_number,
         ep.effective_from_date,
         ep.effective_to_date,
         ep.policy_rcvd_date,
         (CASE WHEN ep.policy_sub_general_type_id='PFL' THEN pg.family_tot_sum_insured ELSE pm.mem_tot_sum_insured END) sum_insured,
         ep.renew_count as policy_renew_count,
         ep.policy_seq_id,
         app.account_info_pkg.get_gen_desc(ep.policy_sub_general_type_id,'G') as policy_subtype,
         ip.product_name,
         DECODE(ep.enrol_type_id,'COR','Corporate','IND','Individual','ING','Individual As Group','NCR','Non-Corporate')as enrol_type

    FROM tpa_enr_policy ep
    JOIN tpa_ins_product ip on (ep.product_seq_id=ip.product_seq_id)
    JOIN tpa_enr_policy_group pg on (pg.policy_seq_id=ep.policy_seq_id )
    JOIN tpa_enr_policy_member pm on (pg.policy_group_seq_id=pm.policy_group_seq_id and pm.tpa_enrollment_id=v_tpa_enr_no)
   START WITH ep.policy_number = v_pol_no
   CONNECT BY nocycle PRIOR ep.renewal_policy_number = ep.policy_number )
 SELECT ht.* FROM tab_bal ht WHERE rnk<6;

  CURSOR cur_hist(v_enr_id    clm_enroll_details.tpa_enrollment_id%TYPE) IS
  WITH clm_tab AS (
     SELECT rank() over(partition by a.tpa_enrollment_id order by a.claim_seq_id desc) as rnk,
        a.claim_seq_id,
        b.claim_number,
        to_char(b.date_of_admission,'DD-MON-YYYY') as doa,
        to_char(b.date_of_discharge,'DD-MON-YYYY') as dod,
        c.hosp_name,
        substr(replace(replace(f.provisional_diagnosis,chr(13),''),chr(10),' '),1,500) diagnosis,
        e.pre_auth_number,
        b.requested_amount as req_amt,
        b.total_app_amount as appr_amt,
        app.account_info_pkg.get_gen_desc(a.clm_status_general_type_id,'G') as  Claim_Status,
        regexp_replace(g.remarks, '[[:space:]]',' ') as rej_reason

  FROM  clm_enroll_details a
        JOIN clm_general_details b ON (a.claim_seq_id = b.claim_seq_id)
        LEFT OUTER JOIN clm_hospital_association c ON (c.claim_seq_id=b.claim_seq_id)
        LEFT OUTER JOIN pat_enroll_details e ON (e.claim_id=b.claim_seq_id)
        LEFT OUTER JOIN ailment_details f on (f.claim_seq_id=b.claim_seq_id)
        LEFT OUTER JOIN assign_users g On (g.assign_users_seq_id=b.last_assign_user_seq_id)
        WHERE a.tpa_enrollment_id=v_enr_id)
      SELECT * FROM clm_tab t WHERE rnk<=5;

 ---======================
 --FUNCTION f_pat_req_amt ()
  v_pat_req_amt      pat_general_details.pat_requested_amount%TYPE;
  v_clm_remarks      clm_general_details.claims_remarks%TYPE;

 ---- icd_code details
  FUNCTION f_icd_code_desc(v_pat_gen_detail_seq_id  IN icd_pcs_detail.pat_gen_detail_seq_id%TYPE, -- to precide ICD CODES
                           v_flag                   IN VARCHAR2,
                           v_type                   IN VARCHAR2)
         RETURN  VARCHAR2 AS
         v_out   VARCHAR2(4000);

 CURSOR cur_icd IS
        SELECT pat_gen_detail_seq_id,
                  nvl(MAX(CASE WHEN icd_rank=1 THEN icd_code ELSE NULL END),'NA') icd_code_1,
                  nvl(MAX(CASE WHEN icd_rank=2 THEN icd_code ELSE NULL END),'NA') icd_code_2,
                  nvl(MAX(CASE WHEN icd_rank=1 THEN ped_description ELSE NULL END),'NA') icd_desc_1,
                  nvl(MAX(CASE WHEN icd_rank=2 THEN ped_description ELSE NULL END),'NA') icd_desc_2
                  FROM
                  (SELECT g.pat_gen_detail_seq_id,
                          i.icd_code,
                          k.ped_description,
                          rank()over (ORDER BY i.icd_pcs_seq_id,i.primary_ailment_yn DESC) icd_rank
                  FROM pat_general_details g
                  LEFT OUTER JOIN icd_pcs_detail i ON (i.pat_gen_detail_seq_id=g.pat_gen_detail_seq_id)
                  LEFT OUTER JOIN tpa_ped_code k ON (k.icd_code=i.icd_code)
                  WHERE g.pat_gen_detail_seq_id=v_pat_gen_detail_seq_id)
                  GROUP BY pat_gen_detail_seq_id ;

      icd_cur     cur_icd%ROWTYPE;

  CURSOR cur_pcd IS
         SELECT pat_gen_detail_seq_id,
                  nvl(MAX(CASE WHEN RANK=1 THEN proc_code ELSE NULL END),'NA') pcs_code_1,
                  nvl(MAX(CASE WHEN RANK=2 THEN proc_code ELSE NULL END),'NA') pcs_code_2,
                  nvl(MAX(CASE WHEN RANK=1 THEN proc_description ELSE NULL END),'NA') pcs_desc_1,
                  nvl(MAX(CASE WHEN RANK=2 THEN proc_description ELSE NULL END),'NA') pcs_desc_2
           FROM (SELECT p.proc_seq_id,
                        g.pat_gen_detail_seq_id,
                        i.icd_code,
                        i.primary_ailment_yn,
                        c.proc_code,
                        nvl(substr(REPLACE(REPLACE(c.proc_description,chr(13),''),CHR(10),' '),1,240),'NA') proc_description,
                        rank()over (ORDER BY p.pat_proc_seq_id DESC) RANK
                  FROM pat_general_details G
                  INNER JOIN icd_pcs_detail I ON (i.pat_gen_detail_seq_id=g.pat_gen_detail_seq_id)
                  INNER JOIN pat_package_procedures P ON (p.icd_pcs_seq_id=i.icd_pcs_seq_id)
                  INNER JOIN tpa_hosp_procedure_code C ON (c.proc_seq_id=p.proc_seq_id)
                  WHERE g.pat_gen_detail_seq_id=v_pat_gen_detail_seq_id) group by pat_gen_detail_seq_id;


      pcd_cur         cur_pcd%ROWTYPE;

 BEGIN

  IF v_flag ='IC' THEN

  OPEN cur_icd;
  FETCH cur_icd INTO icd_cur;
  CLOSE cur_icd;

  IF v_type ='IC1' THEN
       v_out := icd_cur.icd_code_1;
  ELSIF v_type ='IC2' THEN
       v_out := icd_cur.icd_code_2;
  ELSIF v_type ='ID1' THEN
       v_out := icd_cur.icd_desc_1;
  ELSIF v_type ='ID2' THEN
       v_out := icd_cur.icd_desc_2;
  END IF;

 ELSIF v_flag ='PC' THEN
     OPEN cur_pcd;
     FETCH cur_pcd INTO pcd_cur;
     CLOSE cur_pcd;

    IF v_type ='PC1' THEN
       v_out := pcd_cur.pcs_code_1;
    ELSIF v_type ='PC2' THEN
          v_out := pcd_cur.pcs_code_2;
    ELSIF v_type ='PD1' THEN
          v_out := pcd_cur.pcs_desc_1;
    ELSIF v_type ='PD2' THEN
          v_out := pcd_cur.pcs_desc_2;
    END IF;

  END IF;

  RETURN nvl(v_out,'NA');
 END;
------------ end of icd pcs details
------------ fn_sfremarks_pat
FUNCTION fn_sfremarks_pat (v_pat_gen_detail_seq_id IN pat_general_details.pat_gen_detail_seq_id%TYPE)
  RETURN VARCHAR2
  IS
        CURSOR cur IS
        WITH AB AS (
        SELECT shortfall_questions,s.claim_seq_id,c.pre_auth_dms_reference_id
        FROM shortfall_details s, pat_general_details c
        WHERE c.pat_gen_detail_seq_id =s.pat_gen_detail_seq_id
        AND s.pat_gen_detail_seq_id=v_pat_gen_detail_seq_id
        )
        SELECT extractValue(value(C), '/query/@value') as otherquery
             FROM  AB, table(XMLSequence(extract(SHORTFALL_QUESTIONS ,'shortfall/section/subsection/query')))C
             WHERE upper(extractValue(value(C), '/query/@type'))='TEXT';

        otherquery                VARCHAR2(32000);
        claim_number1             VARCHAR2(100);
        tpa_enrollment_id1        VARCHAR2(100);
        str                       VARCHAR2(32767):=NULL;
        v_str                     CLOB:=null;
        comma                     CHAR:=NULL;
  BEGIN

        OPEN cur;
        LOOP
        FETCH cur INTO otherquery;
        EXIT WHEN cur%NOTFOUND;
        IF length(otherquery)>1   THEN
           v_str:=v_str||comma||otherquery;
            END IF;
            comma:=',';
        END LOOP;
        CLOSE cur;
        str:=dbms_lob.substr(v_str,3000,1);
        str := REPLACE(str,'&','AND');
        RETURN str;
  END;

  ------------- end of sf remarks





 BEGIN
     OPEN cur_clm;
     FETCH cur_clm INTO clm_rec;
     CLOSE cur_clm;

     IF clm_rec.pre_auth_letter_no!='O1B' THEN
       SELECT gd.pat_requested_amount INTO v_pat_req_amt
       FROM Pat_Enroll_Details ed
       JOIN Pat_General_Details gd ON ed.pat_enroll_detail_seq_id=gd.pat_enroll_detail_seq_id
       WHERE ed.pre_auth_number=clm_rec.pre_auth_letter_no AND gd.pat_enhanced_yn='N';
    END IF;

    SELECT NVL(hy.remarks,'')INTO v_clm_remarks FROM pat_general_details hy WHERE pat_gen_detail_seq_id=v_pat_gen_detail_seq_id;
    --SELECT NVL(F.Claims_Remarks,'NA') INTO v_clm_remarks FROM clm_general_details F WHERE F.claim_number=v_claim_number;
    v_file_name:=clm_rec.pre_auth_letter_no||to_char(SYSDATE,'_dd_mm_rrrr_hh24_mi')||'.xfdf';

    v_file := UTL_FILE.FOPEN(LOCATION      => 'XFDF_FILES',
                             filename      => v_file_name,
                             open_mode     => 'w',
                             max_linesize  => 32760);

    v_doc     := dbms_xmldom.newDOMDocument;
    dbms_xmldom.setVersion(v_doc,'1.0" encoding="UTF-8' );
    v_root_node := dbms_xmldom.makeNode(v_doc);

    v_elem   := dbms_xmldom.createElement(v_doc,'xfdf');
    v_node   := dbms_xmldom.makeNode(v_elem);
    dbms_xmldom.setAttribute(v_elem,'xmlns','http://ns.adobe.com/xfdf/');
    dbms_xmldom.setAttribute(v_elem,'xml:space','preserve');
    v_main_node := dbms_xmldom.appendChild(v_root_node,v_node);

    v_elem := dbms_xmldom.createElement(v_doc,'fields');
    v_node := dbms_xmldom.makeNode(v_elem);
    v_chld_node := dbms_xmldom.appendChild(v_main_node,v_node);

    -- FOR PREAUTH NUMBER
    v_elem  := dbms_xmldom.createElement(v_doc,'field');
    v_main_node := dbms_xmldom.makeNode(v_elem);
    DBMS_XMLDOM.SetAttribute(v_elem,'name','PRE_AUTH_NUMBER');
    v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

    v_elem2 := dbms_xmldom.createElement(v_doc,'value');
    v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
    v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.Pre_Auth_Letter_No);
    v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));


     ---============insurance details
        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','INSURANCE_COMPANY');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.insurance_company);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','CONTROLLING_OFFICE');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.controlling_office);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','INS_CITY');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.ins_city);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));


        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','INS_STATE');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.ins_state);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','INS_PINCODE');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.ins_pincode);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','RECEIVED_ON');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.Pre_Auth_Received_On);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));


    ---policy details
        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','CLAIM_NO');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.claim_no);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','TPA_ID');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.tpa_id);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','PROPOSER_NAME');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.proposer_name);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','EMPLOYEE_CUSTOMER_ID');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.employee_customer_id);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

         v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','POLICY_NO');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.policy_no);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','POLICY_FORM');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.policy_form);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','POLICY_UPTO');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.policy_upto);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','POLICY_TYPE');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.policy_type);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','PRODUCT_NAME');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.product_name);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

       v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','AGENT_CODE');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.agent_code);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','DEVELOPMENT_CODE');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.development_code);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','OPERATING_CODE');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.operating_code);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','OPERATING_OFFICE');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.operating_office);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

         v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','SUM_INSURED');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.sum_insured);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','BONUS');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.buffer_bonus);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','CORPORATE_BUFFER');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.corporate_buffer);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));
        
        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','MEDICAL_BUFFER');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.Medical_Buffer);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));
        
        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','CRITICAL_BUFFER');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.Critical_Buffer);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));
        
        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','CRITICAL_COR_BUFFER');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.Critical_Corporate_Buffer);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));
        
        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','CRITICAL_MED_BUFFER');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.Critical_Medical_Buffer);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));





        v_elem  := dbms_xmldom.createElement(v_doc,'field'); -- to be added
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','PREMIUM_ZONE');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.premium_zone);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

 ---===================Policy History
   FOR rk IN cur_pol(clm_rec.tpa_id,clm_rec.policy_no) LOOP --for policy history policy

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','POLICY_NUMBER'||i);
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,rk.policy_number);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        --enrol_type
        v_elem  := dbms_xmldom.createElement(v_doc,'field');--POLICY TYPE
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','POLICY_TYPE'||i);
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,rk.enrol_type);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');--product name
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','PRODUCT_TYPE'||i);
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,rk.product_name);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field'); --from date
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','FROM'||i);
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,rk.effective_from_date);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field'); --to date
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','TO'||i);
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,rk.effective_to_date);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');--sum insured
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','SUM_INSURED'||i);
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,rk.sum_insured);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        i := i+1;
        EXIT WHEN i=5;
  END LOOP;
   ----------============Claimant details
        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','PATIENT_NAME');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.patient_name);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','PATIENT_AGE');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.patient_age);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','GENDER');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.gender);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','RELATION');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.relation);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','ADDRESS');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.address);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

    ---================clm_history
   FOR rk IN cur_hist(clm_rec.tpa_id) LOOP  --for claim history
        v_elem  := dbms_xmldom.createElement(v_doc,'field'); --for claims
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','CLAIM_NO'||j);
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,rk.claim_number);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');  --for DOA
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','DOA'||j);
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,rk.doa);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field'); --for DOD
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','DOD'||j);
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,rk.dod);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field'); --for hospital
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','HOSPITAL_NAME'||j);
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,rk.hosp_name);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field'); --for preauth
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','PAN'||j);
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,rk.pre_auth_number);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field'); --for request amt
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','AMT_CLM'||j);
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,rk.req_amt);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

         v_elem  := dbms_xmldom.createElement(v_doc,'field'); --for approved amt
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','AMT_APP'||j);
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,rk.appr_amt);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field'); --for claim status
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','CLAIM_STATUS'||j);
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,rk.claim_status);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');  --for ailment
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','AILMENT'||j);
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,rk.diagnosis);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');  --for ailment
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','REJECTION_REASON'||j);
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,rk.rej_reason);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        j := j+1;
        EXIT WHEN j=5;
  END LOOP;
 ---Hospitalization Details
        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','INTIMATION_DATE');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.intimation_date);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','DATE_OF_DOC_REC');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.date_of_doc_rec);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','LOSS_DATE');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.loss_date);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','DOA');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.doa);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','DOD');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.dod);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));


        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','HOSPITAL_NAME');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.hospital_name);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','HOSPITAL_CODE');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.hospital_code);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','HOSPITAL_CITY');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.hospital_city);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','HOSPITAL_STATE');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.hospital_state);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));


        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','HOSPITAL_PINCODE');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.hospital_pincode);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','DIAGNOSIS');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.diagnosis);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','DIAGNOSIS_CODE_LEVEL_1');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.diagnosis_code_level_1);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','DIAGNOSIS_CODE_LEVEL_2');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.diagnosis_code_level_2);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','DIAGNOSIS_DESCRIPTION_LEVEL_1');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.diagnosis_description_level_1);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','DIAGNOSIS_DESCRIPTION_LEVEL_2');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.diagnosis_description_level_2);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','PROCEDURE_CODES_LEVEL_1');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.procedure_codes_level_1);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','PROCEDURE_CODES_LEVEL_2');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.procedure_codes_level_2);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','PROCEDURE_DESCRIPTION_LEVEL_1');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.procedure_description_level_1);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','PROCEDURE_DESCRIPTION_LEVEL_2');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.procedure_description_level_2);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        ---Claim Details

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','CLAIM_TYPE');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.claim_type);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','CLAIM_CATEGORY');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.claim_category);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','PRE_AUTH_LETTER_NO');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.pre_auth_letter_no);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','PRE_AUTH_RECEIVED_ON');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.pre_auth_received_on);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','PRE_AUTH_APPROVED_ON');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.pre_auth_approved_on);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        /*extra*/
        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','TPA_RECOMMENDATION');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.pre_auth_status);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field'); -- this extra for adobe form
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','PRE_AUTH_REQ_AMT');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,v_pat_req_amt);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','PRE_AUTH_AMOUNT');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.pre_auth_amount);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));
       /*end extra preauth*/

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','ESTIMATE_AMT');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.estimate_amt);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','CLAIM_AMOUNT');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.claim_amount);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','RECOMMEND_AMOUNT');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.recommend_amount);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','CO_PAY_AMOUNT');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.co_pay_amount);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','DEDUCTED_AMOUNT');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.deducted_amount);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','APPROVED_AMOUNT');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.approved_amount);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','TDS_AMOUNT');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.tds_amount);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','NET_PAYBLE_AMT');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.net_payble_amt);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','DEDUCTION_REASON');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.deduction_reason);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        /*extra claim details*/
        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','COMPULSARY_DEDUCTION');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.compulsary_deduction);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','SERVICE_TAX_AMOUNT');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.service_tax_amount);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','SERVICE_TAX_NO');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.service_tax_no);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','PAYBLE_AMOUNT');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.payble_amount);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));
       /*end of extra claim details*/

        /**extra**/
        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','RECOMMEND_ON');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.recommend_on);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','APPROVED_ON');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.approved_on);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','PAY_TO_INSURED');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.pay_to_insured);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','PAY_TO_HOSPITAL');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.pay_to_hospital);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','CHEQUE_NO');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.cheque_no);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','CHEQUE_DATE');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.cheque_date);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','CLM_PAY_TO_BENEFICIARY_NAME');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.clm_pay_to_beneficiary_name);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));
      /**extra**/

      --========= Shortfall Details
        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','DISC_DATAILS');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.disc_datails);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','INSURED_DISC_DATE');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.insured_disc_date);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','INSURED_REMINDER_DATE');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.insured_reminder_date);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','INSURED_FINAL_REMINDER_DATE');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.insured_final_reminder_date);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','INSURED_REPLY_RECIEVED_DATE');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.insured_reply_recieved_date);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','HOSPITAL_DISC_DATE');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.hospital_disc_date);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','HOSPITAL_REMINDER_DATE');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.hospital_reminder_date);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','HOSPITAL_FINAL_REMINDER_DATE');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.hospital_final_reminder_date);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','HOSPITAL_REPLY_RECIEVED_DATE');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.hospital_reply_recieved_date);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','INSURER_DISC_DATE');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.insurer_disc_date);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','INSURER_REMINDER_DATE');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.insurer_reminder_date);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','INSURER_FINAL_REMINDER_DATE');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.insurer_final_reminder_date);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','INSURER_REPLY_RECIEVED_DATE');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.insurer_reply_recieved_date);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

       /*extraa */
        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','FLOAT_NO');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.float_no);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','FLOAT_DATE');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.float_date);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','PAYMENT_DATE');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.payment_date);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','SETTELEMENT_TYPE');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.settelement_type);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','SETTELEMENT_DATE');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.settelement_date);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','REPUDIATION_REJECTION_REASON');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.repudiation_rejection_reason);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','STATUS');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.status);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','BENEFIT_TYPE');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.benefit_type);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','BILL_ENTERED_BY');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.bill_entered_by);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','BILL_ENTRY_LOCATION');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.bill_entry_location);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        ----billing details
   FOR Rx IN rec_tab.first..rec_tab.last LOOP
       p:= 1;
   FOR bd IN cur_bills(v_pat_gen_detail_seq_id,rec_tab(t)) LOOP
         v_room_col    := rec_tab(t)||'_COL'||P;
         v_room_charge := rec_tab(t)||'_CHRG_'||P;

        v_elem  := dbms_xmldom.createElement(v_doc,'field'); --ADDED FOR EXTRA REMARKS
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name',v_room_col);
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,bd.charges);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field'); --ADDED FOR EXTRA REMARKS
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name',v_room_charge);
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,bd.amt);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

         EXIT WHEN cur_bills%NOTFOUND;
         p :=p+1;
   END LOOP;
       t:= t+1;
   END LOOP;

        v_elem  := dbms_xmldom.createElement(v_doc,'field'); --ADDED FOR EXTRA REMARKS
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','TPA_REMARKS');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,v_clm_remarks);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

    v_out_xml:=dbms_xmldom.getxmltype(v_doc);
    v_clob := REPLACE(REPLACE(v_out_xml.getclobval(),'&','and'),'andamp;','and');
    dbms_xmldom.freeDocument(v_doc);

    UTL_FILE.PUT(v_file,DBMS_LOB.SUBSTR(v_clob,32767));
    UTL_FILE.FFLUSH(v_file);
    UTL_FILE.FCLOSE(v_file);

   v_generate_yn:='Y';

  exception when others then
    v_generate_yn:='N';
    END preauth_xfdf_report;

--==============================================================================================
PROCEDURE claims_xfdf_report (v_claim_seq_id    clm_general_details.claim_seq_id%TYPE,
                              v_file_name out varchar2,
                              v_generate_yn   out char) IS

 v_doc              dbms_xmldom.DOMDocument;
 v_main_node        dbms_xmldom.DOMNode;
 v_root_node        dbms_xmldom.DOMNode;
 v_chld_node        dbms_xmldom.DOMNode;
 v_chld_node2       dbms_xmldom.DOMNode;
 v_chld_node3       dbms_xmldom.DOMNode;
 v_node             dbms_xmldom.domnode;
 v_elem             dbms_xmldom.DOMElement;
 v_out_xml          sys.xmltype;
 v_elem2            dbms_xmldom.DOMElement;
 v_text             dbms_xmldom.DOMText;

 v_file            UTL_FILE.FILE_TYPE;
 v_clob            CLOB;
 i                 PLS_INTEGER:=1;
 j                 PLS_INTEGER:=1;
 p                 PLS_INTEGER:=1;
 t                 PLS_INTEGER:=1;
 v_room_col        VARCHAR2(20);
 v_room_charge     VARCHAR2(20);

  TYPE tab IS VARRAY(5) OF VARCHAR2(10);
  rec_tab      tab:=tab('ROOM','PROF','OTHER','NA');

 CURSOR cur_clm IS
 SELECT   cg.claim_seq_id,
          cg.claim_number claim_no,
          grp.insured_name proposer_name,
          ce.claimant_name patient_name,
          ce.employee_no employee_customer_id,
          ce.tpa_enrollment_id tpa_id,
          round(ce.mem_age) patient_age,
          app.account_info_pkg.get_gen_desc(mem.relship_type_id,'R') Relation,
          app.account_info_pkg.get_gen_desc(mem.gender_general_type_id,'G') Gender,
          pol.policy_number policy_no,
          to_char(pol.effective_from_date,'DD-MON-YYYY')  policy_form,
          to_char(pol.effective_to_date,'DD-MON-YYYY')    policy_upto,
          tgr.group_name||'--'||tip.product_name  product_name,
          q.sum_insured,
         -- nvl(q.bonus,0) bonus,
         -- mem.mem_tot_bonus as bonus,-- taken as cumulative bonus
         CASE WHEN POL.POLICY_SUB_GENERAL_TYPE_ID ='PFL' THEN grp.FLOATER_TOT_BONUS ELSE mem.mem_tot_bonus END  bonus,
          ma.address_1||' '||ma.address_2||' '||ma.address_3 address,
          to_char(v.rcvd_date,'DD-MON-YYYY') intimation_date,
          to_char(v.rcvd_date,'DD-MON-YYYY') date_of_doc_rec,
          to_char(cg.date_of_admission,'DD-MON-YYYY') loss_date,
          nvl(thi.hosp_name,ha.hosp_name) hospital_name,
          NVL(app.account_info_pkg.get_gen_desc(tha.city_type_id,'CT') , ha.city_name) hospital_city,
          NVL(app.account_info_pkg.get_gen_desc(THA.STATE_TYPE_ID,'S'), ha.state_name) hospital_state,
          NVL(THA.PIN_CODE ,ha.pin_code) as hospital_pincode,
          substr(REPLACE(REPLACE(al.provisional_diagnosis,chr(13),''),chr(10),' '),1,500) diagnosis,
          f_icd_code_desc(cg.claim_seq_id,'IC','IC1') diagnosis_code_level_1,
          f_icd_code_desc(cg.claim_seq_id,'IC','IC2') diagnosis_code_level_2,
          f_icd_code_desc(cg.claim_seq_id,'IC','ID1') diagnosis_description_level_1,
          f_icd_code_desc(cg.claim_seq_id,'IC','ID2') diagnosis_description_level_2,

          f_icd_code_desc(cg.claim_seq_id,'PC','PC1') procedure_codes_level_1,
          f_icd_code_desc(cg.claim_seq_id,'PC','PC2') procedure_codes_level_2,
          f_icd_code_desc(cg.claim_seq_id,'PC','PD1') procedure_description_level_1,
          f_icd_code_desc(cg.claim_seq_id,'PC','PD2') procedure_description_level_2,

          to_char(cg.date_of_admission,'DD-MON-YYYY') doa,
          to_char(cg.date_of_discharge,'DD-MON-YYYY') dod,

          CASE v.claim_general_type_id WHEN 'CNH' THEN 'CASHLESS' ELSE 'REIMBURSEMENT' END claim_type,
          app.account_info_pkg.get_gen_desc(v.claim_general_type_id,'G') claim_category,
          app.account_info_pkg.get_gen_desc(pol.enrol_type_id,'E') policy_type,
          cg.requested_amount estimate_amt,
          round(nvl(cg.total_app_amount,0)-nvl(cg.serv_tax_calc_amount,0)) claim_amount,

          nvl(round((SELECT SUM(approved_amount)
              FROM ailment_caps x JOIN icd_pcs_detail y ON ( x.icd_pcs_seq_id = y.icd_pcs_seq_id )
              WHERE y.claim_seq_id = cg.claim_seq_id)),0) recommend_amount,
          nvl(cg.co_payment_amount,0)+nvl(cg.co_payment_buffer_amount,0) co_pay_amount,

          nvl(round((SELECT SUM(approved_amount)
              FROM ailment_caps x JOIN icd_pcs_detail y ON ( x.icd_pcs_seq_id = y.icd_pcs_seq_id )
              WHERE y.claim_seq_id = cg.claim_seq_id)),0) AS approved_amount,
          f_rej_amt_rem(cg.claim_seq_id,'AMT') deducted_amount,
          f_rej_amt_rem(cg.claim_seq_id,'REM') deduction_reason,
          '0' compulsary_deduction,
          nvl(cg.serv_tax_calc_amount,'0') service_tax_amount,
          ha.serv_tax_rgn_number service_tax_no,
          nvl(tcp.approved_amount,'0') payble_amount,
          round(nvl(tds.approved_amount-tds.check_amount,'0')) tds_amount,
          round(nvl(tcc.check_amount,'0')) net_payble_amt,
          to_char(CII.clm_ins_send_date,'DD-MON-YYYY') recommend_on,
          to_char( ce.decision_date,'DD-MON-YYYY') approved_on,

          CASE v.claim_general_type_id WHEN 'CNH' THEN 0 ELSE round(nvl(nvl(tcc.check_amount,cg.total_app_amount),0)) END pay_to_insured,
          CASE v.claim_general_type_id WHEN 'CNH' THEN round(nvl(nvl(tcc.check_amount,cg.total_app_amount),0)) ELSE 0 END pay_to_hospital,
          nvl(pol.buffer_alloc_amount,0) corporate_buffer,
          nvl(pol.med_buff_alloc_amount,0) medical_buffer,
          nvl(pol.crit_buff_alloc_amount,0) critical_buffer,
          nvl(pol.crit_corp_buff_alloc_amount,0) critical_corporate_buffer,
          nvl(pol.crit_med_buff_alloc_amount,0) critical_medical_buffer,
          to_char(tcc.check_num) cheque_no,
          to_char(tcc.check_date,'DD-MON-YYYY') cheque_date,
          ttk_util_pkg.fn_decrypt(tcp.payee_name)  clm_pay_to_beneficiary_name,
          --fn_sfremarks(cg.claim_seq_id) disc_datails,
          CLAIMS_APPROVAL_PKG.get_srtfall_remarks('CHECKBOX','CLM',CG.CLAIM_SEQ_ID)||case when CLAIMS_APPROVAL_PKG.get_srtfall_remarks('OTHERS','CLM',CG.CLAIM_SEQ_ID) is not null then ' ******* Other Queries: '||CLAIMS_APPROVAL_PKG.get_srtfall_remarks('OTHERS','CLM',CG.CLAIM_SEQ_ID) end AS  disc_datails,
          case when v.claim_general_type_id='CTM' THEN to_char(SED.INTL_SHORTFAL_SNT_DATE,'DD-MON-YYYY') ELSE NULL END AS  insured_disc_date,
          case when v.claim_general_type_id='CTM' THEN to_char(SED.RMDR_REQ_SNT_DATE,'DD-MON-YYYY') ELSE NULL END AS   insured_reminder_date,
          case when v.claim_general_type_id='CTM' THEN to_char(SED.CLSR_NOTICE_SNT_DATE,'DD-MON-YYYY') ELSE NULL END AS  insured_final_reminder_date,
          case when v.claim_general_type_id='CTM' THEN to_char(SF_Responded_Dt,'DD-MON-YYYY') ELSE NULL END AS  insured_reply_recieved_date,
          case when v.claim_general_type_id='CTM' THEN NULL ELSE to_char(SED.INTL_SHORTFAL_SNT_DATE,'DD-MON-YYYY') END AS hospital_disc_date,
          case when v.claim_general_type_id='CTM' THEN NULL ELSE to_char(SED.RMDR_REQ_SNT_DATE,'DD-MON-YYYY') END AS  hospital_reminder_date,
          case when v.claim_general_type_id='CTM' THEN NULL ELSE to_char(SED.CLSR_NOTICE_SNT_DATE,'DD-MON-YYYY') END AS  hospital_final_reminder_date,
          case when v.claim_general_type_id='CTM' THEN NULL ELSE  to_char(SF_Responded_Dt,'DD-MON-YYYY') END AS hospital_reply_recieved_date,
          CASE WHEN tii.Email_Id IS NOT NULL THEN to_char(SED.RMDR_REQ_SNT_DATE,'DD-MON-YYYY') ELSE NULL END  AS insurer_disc_date,
          CASE WHEN tii.Email_Id IS NOT NULL THEN to_char(SED.CLSR_NOTICE_SNT_DATE,'DD-MON-YYYY') ELSE NULL END  AS insurer_reminder_date,
          CASE WHEN tii.Email_Id IS NOT NULL THEN to_char(SED.CLM_CLSR_LETTER_SNT_DATE,'DD-MON-YYYY') ELSE NULL END  AS insurer_final_reminder_date,
          NULL insurer_reply_recieved_date,
          to_char(V.RCVD_DATE,'DD-MON-YYYY') pre_auth_received_on,
          pee.pre_auth_number  pre_auth_letter_no,
          app.account_info_pkg.get_gen_desc(pee.pat_status_general_type_id,'G') pre_auth_status,
          nvl(pgd.total_app_amount,'0') pre_auth_amount,
          to_char(pee.decision_date,'DD-MON-YYYY') pre_auth_approved_on,
          nvl(tfa.float_account_number,'NA') float_no,
          to_char(tfa.effective_date,'DD-MON-YYYY') float_date,
          to_char(tcc.check_date,'DD-MON-YYYY') payment_date,
          '0' agent_code,
          pol.dev_officer_code development_code,
          tii.ins_comp_name  operating_office,
          tii.ins_comp_code_number  operating_code,
          NVL(app.account_info_pkg.get_gen_desc(tas.City_Type_Id,'CT'),TAS.CITY)  ins_city,
          NVL(app.account_info_pkg.get_gen_desc(tas.State_Type_Id,'S'),TAS.STATE)  ins_state,
          tas.pin_code ins_pincode,
          NULL controlling_office,
          tii.ins_comp_name  insurance_company,
          app.account_info_pkg.get_gen_desc(tcp.payee_type,'G') settelement_type,
          to_char(ce.decision_date,'DD-MON-YYYY') settelement_date,
          regexp_replace(au.remarks, '[[:space:]]',' ') as repudiation_rejection_reason,
          app.account_info_pkg.get_gen_desc(ce.clm_status_general_type_id ,'G') AS CLM_status,
          NULL benefit_type,
          NULL bill_entered_by,
          NULL bill_entry_location,
          NVL2(ha.empanel_number,ha.empanel_number,nvl(thi.empanel_number,'')) hospital_code,
          ce.member_seq_id,
          grp.tpa_enrollment_number enr_num,
          'Bangalore' as premium_zone,
          regexp_replace(au.remarks, '[[:space:]]',' ') as claims_remarks

     FROM clm_general_details cg  --on (bdv.claim_seq_id=cg.claim_seq_id)
          INNER JOIN clm_enroll_details ce on (ce.claim_seq_id=cg.claim_seq_id)
          left outer join clm_ins_intimation_details cii on (CG.claim_seq_id=cii.claim_seq_id)
          INNER JOIN assign_users au ON (au.ASSIGN_USERS_SEQ_ID=cg.last_assign_user_seq_id)
          INNER JOIN tpa_enr_policy pol on (ce.policy_seq_id=pol.policy_seq_id)
          INNER JOIN tpa_enr_policy_member mem on (mem.member_seq_id=ce.member_seq_id)
          INNER JOIN tpa_enr_policy_group grp on (grp.policy_group_seq_id=mem.policy_group_seq_id)
          INNER JOIN tpa_ins_product tip on (tip.product_seq_id=pol.product_seq_id)
          INNER JOIN tpa_enr_balance q on (q.policy_group_seq_id=grp.policy_group_seq_id)
          INNER JOIN tpa_enr_mem_address ma on (ma.enr_address_seq_id=grp.enr_address_seq_id)
          LEFT OUTER JOIN clm_hospital_association ha on (ha.claim_seq_id=cg.claim_seq_id)
          LEFT OUTER JOIN tpa_hosp_info thi on (ha.hosp_seq_id =thi.hosp_seq_id)
          LEFT OUTER JOIN tpa_hosp_address tha on (thi.hosp_seq_id=tha.hosp_seq_id)
          INNER JOIN clm_inward v on (v.claims_inward_seq_id=cg.claims_inward_seq_id)
          LEFT OUTER JOIN tpa_claims_payment tcp on (tcp.claim_seq_id=cg.claim_seq_id)
          LEFT OUTER JOIN tpa_clm_tds_details tds  on (tds.claim_seq_id=cg.claim_seq_id and tds.payment_seq_id=tcp.payment_seq_id)
          LEFT OUTER JOIN tpa_payment_checks_details tpcd on (tpcd.payment_seq_id=tcp.payment_seq_id and tpcd.v_csr_flag=1)
          LEFT OUTER JOIN tpa_claims_check tcc on (tcc.claims_chk_seq_id=tpcd.claims_chk_seq_id and tcc.v_csr_flag=1 and tcc.check_status IN ('CSI','CSC'))
          LEFT OUTER JOIN pat_enroll_details pee on (pee.claim_id=cg.claim_seq_id)
          LEFT OUTER JOIN pat_general_details pgd on (pgd.pat_enroll_detail_seq_id=pee.pat_enroll_detail_seq_id and pgd.pat_enhanced_yn='N')
          LEFT OUTER JOIN tpa_float_account tfa on (tfa.float_seq_id=tcp.float_seq_id)
          JOIN tpa_ins_info tii on (tii.ins_seq_id= ce.ins_seq_id)
          JOIN tpa_address tas on (tas.ins_seq_id=tii.ins_seq_id)
          LEFT OUTER JOIN tpa_group_registration tgr on (tgr.group_reg_seq_id=pol.group_reg_seq_id)
          LEFT OUTER JOIN ailment_details al on (al.claim_seq_id=cg.claim_seq_id)
          LEFT OUTER JOIN (SELECT claim_seq_id clm_id, MIN (added_date) min_sfdt, MAX(added_date) max_sfdt, MAX(closed_date) sf_closeddt, MAX(srtfll_received_date) SF_Responded_Dt
                 FROM shortfall_details
                 GROUP BY claim_seq_id) sf ON (sf.clm_id = cg.claim_seq_id)
          left outer join (select max(sd.shortfall_seq_id) as srt_seq_id,sd.claim_seq_id from shortfall_details sd group by sd.claim_seq_id) sfd  on (cg.claim_seq_id=sfd.claim_seq_id)
          left outer join  shortfall_email_dtl sed on (sfd.srt_seq_id=sed.shortfall_seq_id)

   WHERE cg.claim_seq_id=v_claim_seq_id AND (mem.mem_general_type_id = 'PFL' AND q.member_seq_id IS NULL OR mem.member_seq_id = Q.member_seq_id OR mem.member_seq_id IS NULL);
   --and tii.abbrevation_code='BA';

  clm_rec   cur_clm%ROWTYPE;

  CURSOR cur_bills(v_seq_id           clm_general_details.claim_seq_id%TYPE,
                   v_charges_type     tpa_hosp_ward_code.ward_type_id%TYPE) IS
  WITH bv AS(
  SELECT  g.claim_seq_id,
          d.ward_type_id,
          CASE WHEN d.ward_type_id IN('BED','DMO','DRC','ICN','ICR','IJC','NUC','RMO','ROO') THEN 'ROOM'
               WHEN d.ward_type_id IN('ANC','ASC','CDL','CON','DLC','EME','ICU','ICC','NDL','OPC','PYC','POC','PRO','SPE','SUF') THEN 'PROF'
               WHEN d.ward_type_id IN('ADC','ADM','ATN','BIC','CTL','COB','DIS','DEC','DSC','DOB','FDC','HAA','HVC','MLC','MIS','PDC','REF','SEC','STC','SUR','WCW','WCC') THEN 'NA'
               ELSE 'OTHER' END charges_type,
          ji.ward_description AS charges,
          SUM(d.Requested_Amount) AS amt
        FROM clm_general_details g
           INNER JOIN clm_enroll_details e ON (e.claim_seq_id=g.claim_seq_id)
           LEFT OUTER JOIN clm_bill_header h ON (g.claim_seq_id=h.claim_seq_id)
           LEFT OUTER JOIN clm_bill_details d ON (h.clm_bill_seq_id=d.clm_bill_seq_id and d.ward_type_id!='STX')
           LEFT OUTER JOIN tpa_hosp_ward_code ji ON (ji.ward_type_id=d.ward_type_id)
           WHERE g.claim_seq_id=v_seq_id --and d.allowed_amount>0
           GROUP BY g.claim_seq_id,d.ward_type_id,ji.ward_description)
      SELECT * FROM bv WHERE charges_type =v_charges_type;

  CURSOR cur_pol(v_tpa_enr_no   tpa_enr_policy_group.tpa_enrollment_number%TYPE,
                 v_pol_no       tpa_enr_policy.policy_number%TYPE ) IS
  WITH tab_bal AS (
     SELECT rank() over(PARTITION BY pg.tpa_enrollment_number ORDER BY pg.policy_group_seq_id DESC) AS rnk,
         pg.policy_group_seq_id,
         ep.policy_number,
         ep.renewal_policy_number,
         ep.effective_from_date,
         ep.effective_to_date,
         ep.policy_rcvd_date,
         (CASE WHEN ep.policy_sub_general_type_id='PFL' THEN pg.family_tot_sum_insured ELSE pm.mem_tot_sum_insured END) sum_insured,
         ep.renew_count as policy_renew_count,
         ep.policy_seq_id,
         app.account_info_pkg.get_gen_desc(ep.policy_sub_general_type_id,'G') as policy_subtype,
         ip.product_name,
         DECODE(ep.enrol_type_id,'COR','Corporate','IND','Individual','ING','Individual As Group','NCR','Non-Corporate')as enrol_type

    FROM tpa_enr_policy ep
    JOIN tpa_ins_product ip on (ep.product_seq_id=ip.product_seq_id)
    JOIN tpa_enr_policy_group pg on (pg.policy_seq_id=ep.policy_seq_id )
    JOIN tpa_enr_policy_member pm on (pg.policy_group_seq_id=pm.policy_group_seq_id and pm.tpa_enrollment_id=v_tpa_enr_no)
   START WITH ep.policy_number = v_pol_no
   CONNECT BY nocycle PRIOR ep.renewal_policy_number = ep.policy_number )
 SELECT ht.* FROM tab_bal ht WHERE rnk<6;

  CURSOR cur_hist(v_enr_id    clm_enroll_details.tpa_enrollment_id%TYPE) IS
  WITH clm_tab AS (
     SELECT rank() over(partition by a.tpa_enrollment_id order by a.claim_seq_id desc) as rnk,
        a.claim_seq_id,
        b.claim_number,
        to_char(b.date_of_admission,'DD-MON-YYYY') as doa,
        to_char(b.date_of_discharge,'DD-MON-YYYY') as dod,
        c.hosp_name,
        substr(replace(replace(f.provisional_diagnosis,chr(13),''),chr(10),' '),1,500) diagnosis,
        e.pre_auth_number,
        b.requested_amount as req_amt,
        b.total_app_amount as appr_amt,
        app.account_info_pkg.get_gen_desc(a.clm_status_general_type_id,'G') as  Claim_Status,
        regexp_replace(g.remarks, '[[:space:]]',' ') as rej_reason

  FROM  clm_enroll_details a
        JOIN clm_general_details b ON (a.claim_seq_id = b.claim_seq_id)
        LEFT OUTER JOIN clm_hospital_association c ON (c.claim_seq_id=b.claim_seq_id)
        LEFT OUTER JOIN pat_enroll_details e ON (e.claim_id=b.claim_seq_id)
        LEFT OUTER JOIN ailment_details f on (f.claim_seq_id=b.claim_seq_id)
        LEFT OUTER JOIN assign_users g On (g.assign_users_seq_id=b.last_assign_user_seq_id)
        WHERE a.tpa_enrollment_id=v_enr_id)
      SELECT * FROM clm_tab t WHERE rnk<=5;

 ---======================
 --FUNCTION f_pat_req_amt ()
  v_pat_req_amt      pat_general_details.pat_requested_amount%TYPE;
  v_clm_remarks      clm_general_details.claims_remarks%TYPE;

 BEGIN
     OPEN cur_clm;
     FETCH cur_clm INTO clm_rec;
     CLOSE cur_clm;

     IF clm_rec.pre_auth_letter_no!='O1B' THEN
       SELECT gd.pat_requested_amount INTO v_pat_req_amt
       FROM Pat_Enroll_Details ed
       JOIN Pat_General_Details gd ON ed.pat_enroll_detail_seq_id=gd.pat_enroll_detail_seq_id
       WHERE ed.pre_auth_number=clm_rec.pre_auth_letter_no AND gd.pat_enhanced_yn='N';
    END IF;

    SELECT NVL(F.Claims_Remarks,'NA') INTO v_clm_remarks FROM clm_general_details F WHERE F.Claim_Seq_Id=v_claim_seq_id;

    v_file_name:=clm_rec.claim_no||to_char(SYSDATE,'_dd_mm_rrrr_hh24_mi')||'.xfdf';
    v_file := UTL_FILE.FOPEN(LOCATION      => 'XFDF_FILES',
                             filename      => v_file_name,
                             open_mode     => 'w',
                             max_linesize  => 32760);

    v_doc     := dbms_xmldom.newDOMDocument;
    dbms_xmldom.setVersion(v_doc,'1.0" encoding="UTF-8' );
    v_root_node := dbms_xmldom.makeNode(v_doc);

    v_elem   := dbms_xmldom.createElement(v_doc,'xfdf');
    v_node   := dbms_xmldom.makeNode(v_elem);
    dbms_xmldom.setAttribute(v_elem,'xmlns','http://ns.adobe.com/xfdf/');
    dbms_xmldom.setAttribute(v_elem,'xml:space','preserve');
    v_main_node := dbms_xmldom.appendChild(v_root_node,v_node);

    v_elem := dbms_xmldom.createElement(v_doc,'fields');
    v_node := dbms_xmldom.makeNode(v_elem);
    v_chld_node := dbms_xmldom.appendChild(v_main_node,v_node);

     ---============insurance details
        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','INSURANCE_COMPANY');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.insurance_company);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','CONTROLLING_OFFICE');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.controlling_office);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','INS_CITY');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.ins_city);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));


        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','INS_STATE');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.ins_state);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','INS_PINCODE');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.ins_pincode);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','RECEIVED_ON');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.Pre_Auth_Received_On);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

    ---policy details
        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','CLAIM_NO');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.claim_no);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','PRE_AUTH_NUMBER');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.Pre_Auth_Letter_No);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));


        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','TPA_ID');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.tpa_id);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','PROPOSER_NAME');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.proposer_name);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','EMPLOYEE_CUSTOMER_ID');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.employee_customer_id);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

         v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','POLICY_NO');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.policy_no);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','POLICY_FORM');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.policy_form);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','POLICY_UPTO');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.policy_upto);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','POLICY_TYPE');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.policy_type);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','PRODUCT_NAME');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.product_name);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

       v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','AGENT_CODE');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.agent_code);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','DEVELOPMENT_CODE');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.development_code);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','OPERATING_CODE');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.operating_code);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','OPERATING_OFFICE');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.operating_office);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

         v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','SUM_INSURED');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.sum_insured);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','BONUS');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.bonus);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','CORPORATE_BUFFER');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.corporate_buffer);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));
        
         v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','MEDICAL_BUFFER');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.Medical_Buffer);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));
        
        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','CRITICAL_BUFFER');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.Critical_Buffer);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));
        
        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','CRITICAL_COR_BUFFER');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.Critical_Corporate_Buffer);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));
        
        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','CRITICAL_MED_BUFFER');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.Critical_Medical_Buffer);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));


        v_elem  := dbms_xmldom.createElement(v_doc,'field'); -- to be added
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','PREMIUM_ZONE');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.premium_zone);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

 ---===================Policy History
   FOR rk IN cur_pol(clm_rec.tpa_id,clm_rec.policy_no) LOOP --for policy history policy

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','POLICY_NUMBER'||i);
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,rk.policy_number);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        --enrol_type
        v_elem  := dbms_xmldom.createElement(v_doc,'field');--POLICY TYPE
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','POLICY_TYPE'||i);
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,rk.enrol_type);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');--product name
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','PRODUCT_TYPE'||i);
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,rk.product_name);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field'); --from date
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','FROM'||i);
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,rk.effective_from_date);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field'); --to date
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','TO'||i);
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,rk.effective_to_date);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');--sum insured
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','SUM_INSURED'||i);
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,rk.sum_insured);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        i := i+1;
        EXIT WHEN i=5;
  END LOOP;
   ----------============Claimant details
        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','PATIENT_NAME');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.patient_name);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','PATIENT_AGE');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.patient_age);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','GENDER');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.gender);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','RELATION');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.relation);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','ADDRESS');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.address);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

    ---================clm_history
   FOR rk IN cur_hist(clm_rec.tpa_id) LOOP  --for claim history
        v_elem  := dbms_xmldom.createElement(v_doc,'field'); --for claims
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','CLAIM_NO'||j);
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,rk.claim_number);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');  --for DOA
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','DOA'||j);
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,rk.doa);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field'); --for DOD
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','DOD'||j);
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,rk.dod);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field'); --for hospital
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','HOSPITAL_NAME'||j);
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,rk.hosp_name);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field'); --for preauth
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','PAN'||j);
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,rk.pre_auth_number);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field'); --for request amt
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','AMT_CLM'||j);
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,rk.req_amt);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

         v_elem  := dbms_xmldom.createElement(v_doc,'field'); --for approved amt
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','AMT_APP'||j);
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,rk.appr_amt);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field'); --for claim status
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','CLAIM_STATUS'||j);
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,rk.claim_status);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');  --for ailment
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','AILMENT'||j);
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,rk.diagnosis);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');  --for ailment
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','REJECTION_REASON'||j);
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,rk.rej_reason);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        j := j+1;
        EXIT WHEN j=5;
  END LOOP;
 ---Hospitalization Details
        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','INTIMATION_DATE');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.intimation_date);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','DATE_OF_DOC_REC');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.date_of_doc_rec);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','LOSS_DATE');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.loss_date);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','DOA');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.doa);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','DOD');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.dod);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));


        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','HOSPITAL_NAME');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.hospital_name);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','HOSPITAL_CODE');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.hospital_code);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','HOSPITAL_CITY');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.hospital_city);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','HOSPITAL_STATE');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.hospital_state);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));


        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','HOSPITAL_PINCODE');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.hospital_pincode);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','DIAGNOSIS');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.diagnosis);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','DIAGNOSIS_CODE_LEVEL_1');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.diagnosis_code_level_1);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','DIAGNOSIS_CODE_LEVEL_2');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.diagnosis_code_level_2);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','DIAGNOSIS_DESCRIPTION_LEVEL_1');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.diagnosis_description_level_1);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','DIAGNOSIS_DESCRIPTION_LEVEL_2');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.diagnosis_description_level_2);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','PROCEDURE_CODES_LEVEL_1');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.procedure_codes_level_1);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','PROCEDURE_CODES_LEVEL_2');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.procedure_codes_level_2);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','PROCEDURE_DESCRIPTION_LEVEL_1');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.procedure_description_level_1);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','PROCEDURE_DESCRIPTION_LEVEL_2');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.procedure_description_level_2);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        ---Claim Details

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','CLAIM_TYPE');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.claim_type);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','CLAIM_CATEGORY');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.claim_category);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','PRE_AUTH_LETTER_NO');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.pre_auth_letter_no);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','PRE_AUTH_RECEIVED_ON');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.pre_auth_received_on);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','PRE_AUTH_APPROVED_ON');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.pre_auth_approved_on);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        /*extra*/
        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','PRE_AUTH_STATUS');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.pre_auth_status);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field'); -- this extra for adobe form
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','PRE_AUTH_REQ_AMT');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,v_pat_req_amt);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','PRE_AUTH_AMOUNT');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.pre_auth_amount);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));
       /*end extra preauth*/

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','ESTIMATE_AMT');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.estimate_amt);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','CLAIM_AMOUNT');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.claim_amount);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','RECOMMEND_AMOUNT');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.recommend_amount);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','CO_PAY_AMOUNT');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.co_pay_amount);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','DEDUCTED_AMOUNT');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.deducted_amount);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','APPROVED_AMOUNT');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.approved_amount);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','TDS_AMOUNT');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.tds_amount);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','NET_PAYBLE_AMT');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.net_payble_amt);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','DEDUCTION_REASON');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.deduction_reason);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        /*extra claim details*/
        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','COMPULSARY_DEDUCTION');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.compulsary_deduction);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','SERVICE_TAX_AMOUNT');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.service_tax_amount);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','SERVICE_TAX_NO');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.service_tax_no);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','PAYBLE_AMOUNT');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.payble_amount);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));
       /*end of extra claim details*/

        /**extra**/
        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','RECOMMEND_ON');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.recommend_on);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','APPROVED_ON');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.approved_on);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','PAY_TO_INSURED');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.pay_to_insured);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','PAY_TO_HOSPITAL');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.pay_to_hospital);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','CHEQUE_NO');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.cheque_no);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','CHEQUE_DATE');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.cheque_date);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','CLM_PAY_TO_BENEFICIARY_NAME');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.clm_pay_to_beneficiary_name);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));
      /**extra**/

      --========= Shortfall Details
        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','DISC_DATAILS');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.disc_datails);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','INSURED_DISC_DATE');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.insured_disc_date);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','INSURED_REMINDER_DATE');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.insured_reminder_date);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','INSURED_FINAL_REMINDER_DATE');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.insured_final_reminder_date);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','INSURED_REPLY_RECIEVED_DATE');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.insured_reply_recieved_date);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','HOSPITAL_DISC_DATE');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.hospital_disc_date);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','HOSPITAL_REMINDER_DATE');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.hospital_reminder_date);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','HOSPITAL_FINAL_REMINDER_DATE');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.hospital_final_reminder_date);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','HOSPITAL_REPLY_RECIEVED_DATE');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.hospital_reply_recieved_date);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','INSURER_DISC_DATE');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.insurer_disc_date);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','INSURER_REMINDER_DATE');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.insurer_reminder_date);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','INSURER_FINAL_REMINDER_DATE');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.insurer_final_reminder_date);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','INSURER_REPLY_RECIEVED_DATE');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.insurer_reply_recieved_date);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

       /*extraa */
        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','FLOAT_NO');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.float_no);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','FLOAT_DATE');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.float_date);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','PAYMENT_DATE');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.payment_date);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','SETTELEMENT_TYPE');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.settelement_type);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','SETTELEMENT_DATE');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.settelement_date);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','REPUDIATION_REJECTION_REASON');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.repudiation_rejection_reason);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','TPA_RECOMMENDATION');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.Clm_Status);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','BENEFIT_TYPE');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.benefit_type);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','BILL_ENTERED_BY');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.bill_entered_by);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field');
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','BILL_ENTRY_LOCATION');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,clm_rec.bill_entry_location);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        ----billing details
   FOR Rx IN rec_tab.first..rec_tab.last LOOP
       p:= 1;
   FOR bd IN cur_bills(clm_rec.claim_seq_id,rec_tab(t)) LOOP
         v_room_col    := rec_tab(t)||'_COL'||P;
         v_room_charge := rec_tab(t)||'_CHRG_'||P;

        v_elem  := dbms_xmldom.createElement(v_doc,'field'); --ADDED FOR EXTRA REMARKS
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name',v_room_col);
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,bd.charges);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

        v_elem  := dbms_xmldom.createElement(v_doc,'field'); --ADDED FOR EXTRA REMARKS
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name',v_room_charge);
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,bd.amt);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

         EXIT WHEN cur_bills%NOTFOUND;
         p :=p+1;
   END LOOP;
       t:= t+1;
   END LOOP;

        v_elem  := dbms_xmldom.createElement(v_doc,'field'); --ADDED FOR EXTRA REMARKS
        v_main_node := dbms_xmldom.makeNode(v_elem);
        DBMS_XMLDOM.SetAttribute(v_elem,'name','TPA_REMARKS');
        v_chld_node2 :=dbms_xmldom.AppendChild(v_chld_node,v_main_node);

        v_elem2 := dbms_xmldom.createElement(v_doc,'value');
        v_elem2 := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem),dbms_xmldom.makeNode(v_elem2)));
        v_text  := DBMS_XMLDOM.createTextNode(v_doc,v_clm_remarks);
        v_text  := DBMS_XMLDOM.makeText(DBMS_XMLDOM.appendChild(dbms_xmldom.makeNode(v_elem2),dbms_xmldom.makeNode(v_text)));

    v_out_xml:=dbms_xmldom.getxmltype(v_doc);
    v_clob := REPLACE(REPLACE(v_out_xml.getclobval(),'&','and'),'andamp;','and');
    dbms_xmldom.freeDocument(v_doc);

    UTL_FILE.PUT(v_file,DBMS_LOB.SUBSTR(v_clob,32767));
    UTL_FILE.FFLUSH(v_file);
    UTL_FILE.FCLOSE(v_file);
    v_generate_yn:='Y';

  exception when others then
    v_generate_yn:='N';
    END claims_xfdf_report;
--==============================================================================================

PROCEDURE save_prod_pol_escalation(
    v_prod_policy_seq_id                 IN  TPA_INS_PROD_POLICY_LIMITS.prod_policy_seq_id%TYPE,
    v_string                             IN  VARCHAR2, --  |prod_pol_esc_seq_id|pat_clm_type|freq_flag|remainder_type|remainder_value|
    v_added_by                           IN  NUMBER,
    v_rows_processed                     OUT NUMBER
  )
  IS
    str_tab                              ttk_util_pkg.str_table_type := ttk_util_pkg.parse_str (v_string);
  BEGIN
    IF str_tab.FIRST IS NOT NULL THEN
      FOR i IN 1..6
      LOOP

        IF str_tab(i*5-4) IS null THEN
          INSERT INTO app.tpa_prod_pol_pat_clm_esc_cfg
          (prod_pol_esc_seq_id,
          prod_policy_seq_id,
          pat_clm_type,
          freq_flag,
          remainder_type,
          remainder_value,
          added_date,
          added_by)
          values

          (prod_pol_escalation_seq.nextval,
           v_prod_policy_seq_id,
           str_tab(i*5-3),
           str_tab(i*5-2),
           str_tab(i*5-1),
           str_tab(i*5),
           sysdate,
           v_added_by);


        ELSE
          UPDATE app.tpa_prod_pol_pat_clm_esc_cfg
             SET pat_clm_type    = str_tab(i * 5 - 3),
                 freq_flag       = str_tab(i * 5 - 2),
                 remainder_type  = str_tab(i * 5 - 1),
                 remainder_value = str_tab(i * 5 ),
                 updated_date    = sysdate ,
                 updated_by      = v_added_by,
                 prod_policy_seq_id = v_prod_policy_seq_id
            WHERE prod_pol_esc_seq_id  = str_tab(i*5-4) ;
        END IF;
      END LOOP;
      v_rows_processed := SQL%ROWCOUNT;
      COMMIT;
    END IF;
  END save_prod_pol_escalation;
--==============================================================================================

PROCEDURE select_prod_pol_escalation(
    v_prod_policy_seq_id                 IN   TPA_INS_PROD_POLICY_LIMITS.prod_policy_seq_id%TYPE,
    v_pat_result_set                         OUT  SYS_REFCURSOR,
    v_clm_result_set                         OUT  SYS_REFCURSOR
  )
  IS
    v_ctr                 NUMBER(1);

  BEGIN
    SELECT COUNT(1) INTO v_ctr
      FROM app.tpa_prod_pol_pat_clm_esc_cfg a WHERE a.prod_policy_seq_id = v_prod_policy_seq_id;

    IF v_ctr > 0 THEN
     OPEN v_pat_result_set FOR
       SELECT A.prod_policy_seq_id,
         a.prod_pol_esc_seq_id,
         a.pat_clm_type,
         a.freq_flag,
         a.remainder_type,
         a.remainder_value
         FROM app.tpa_prod_pol_pat_clm_esc_cfg A
         WHERE a.prod_policy_seq_id = v_prod_policy_seq_id
         AND A.PAT_CLM_TYPE='PAT';

   OPEN v_clm_result_set FOR
     SELECT A.prod_policy_seq_id,
         a.prod_pol_esc_seq_id,
         a.pat_clm_type,
         a.freq_flag,
         a.remainder_type,
         a.remainder_value
         FROM app.tpa_prod_pol_pat_clm_esc_cfg A
         WHERE a.prod_policy_seq_id = v_prod_policy_seq_id
         and a.pat_clm_type='CLM' ;

    ELSE
   OPEN v_pat_result_set FOR
     select
       v_prod_policy_seq_id AS prod_policy_seq_id,
       a.general_type_id freq_flag ,
       a.description ,
       null as remainder_type,
       'PAT' AS pat_clm_type,
       NULL AS remainder_value ,
       null as prod_pol_esc_seq_id

      from app.tpa_general_code a
      where a.header_type like 'DURATION_TYPE'
      and a.general_type_id!='DTY';

  OPEN v_clm_result_set FOR
      select
      v_prod_policy_seq_id AS prod_policy_seq_id,
       a.general_type_id freq_flag ,
       a.description ,
       null as remainder_type,
       'CLM' AS pat_clm_type,
       NULL AS remainder_value ,
       null as prod_pol_esc_seq_id
      from app.tpa_general_code a
      where a.header_type like 'DURATION_TYPE'
      and a.general_type_id!='DTY';
     END IF;
   END select_prod_pol_escalation;
--==============================================================================================

PROCEDURE override_ins_intimation(
    v_pat_clm_seq_id                     IN  clm_general_details.claim_seq_id%TYPE,
    v_mode                               IN  VARCHAR2, --  'PAT' FOR PREAUTH, 'CLM' FOR CLAIMS
    v_ins_intimation_req_yn              in  clm_ins_intimation_details.ins_intimation_req_yn%type,
    v_ins_int_rson_type                  IN  clm_ins_intimation_details.INS_INT_RSON_TYPE_ID%TYPE,
    v_override_remarks                   in  clm_ins_intimation_details.ins_int_override_remarks%type,
    v_added_by                           in  number,
    v_rows_processed                     out number
  )   is

v_seq_id                                 pat_enroll_details.pat_enroll_detail_seq_id%type;

begin
  
 --insert into app.temp_rem values(v_mode||',,,,'||v_ins_int_rson_type);

  IF  v_mode='CLM' THEN

      update clm_ins_intimation_details a set
          a.ins_intimation_req_yn              =   CASE WHEN v_ins_int_rson_type IS NOT NULL THEN 'Y'  ELSE 'N' END ,
          a.ins_int_overriden_date             =   sysdate,
          a.ins_int_override_remarks           =   substr(v_override_remarks||' - '||TO_CHAR(SYSDATE,'DD-MON-YYYY HH:MI:SS AM')||' - '||app.account_info_pkg.get_gen_desc(v_added_by,'U')||' - '||app.account_info_pkg.get_gen_desc(v_ins_int_rson_type,'G') ||chr(13),1,1000),
          a.ins_int_overriden_by               =   v_added_by,
          a.ins_int_rson_type_id               =   v_ins_int_rson_type,
          a.updated_date                       =   sysdate,
          a.updated_by                         =   v_added_by
      where a.claim_seq_id =v_pat_clm_seq_id;
   else
      select pat_enroll_detail_seq_id into v_seq_id
      from pat_general_details b
      where b.pat_gen_detail_seq_id=v_pat_clm_seq_id;

        update PAT_ins_intimation_details a
        set a.ins_intimation_req_yn       =    CASE WHEN v_ins_int_rson_type IS NOT NULL THEN 'Y'  ELSE 'N' END ,
            a.ins_int_overriden_date      =    sysdate,
            a.ins_int_override_remarks    =    substr( v_override_remarks||' - '||TO_CHAR(SYSDATE,'DD-MON-YYYY HH:MI:SS AM')||' - '||app.account_info_pkg.get_gen_desc(v_added_by,'U')||' - '||app.account_info_pkg.get_gen_desc(v_ins_int_rson_type,'G') ||chr(13),1,1000),
            a.ins_int_overriden_by        =    v_added_by,
            a.ins_int_rson_type_id        =    v_ins_int_rson_type,
            a.updated_date                =    sysdate,
            a.updated_by                  =    v_added_by
        where a.Pat_Auth_Seq_Id = v_seq_id;

   END IF;

 v_rows_processed:=SQL%ROWCOUNT;

 COMMIT;

end override_ins_intimation;
--==============================================================================================
PROCEDURE select_ins_intimation(
    v_pat_clm_seq_id                     IN  clm_general_details.claim_seq_id%TYPE,
    v_mode                               IN  VARCHAR2, --  'PAT' FOR PREAUTH, 'CLM' FOR CLAIMS
    v_result_set                         out sys_refcursor
  )   is
v_pat_seq_id                             pat_enroll_details.pat_enroll_detail_seq_id%type;

begin
 IF v_mode='CLM' THEN

   OPEN v_result_set FOR
   select
       a.claim_seq_id as seq_id,
       CII.ins_intimation_req_yn,
       TO_CHAR(CII.ins_int_overriden_date,'DD/MM/YYYY') AS ins_int_overriden_date,
       CII.ins_int_override_remarks,
       CII.ins_int_overriden_by,
       CII.ins_int_rson_type_id
    from clm_enroll_details a
    left outer join clm_ins_intimation_details cii on (A.claim_seq_id=cii.claim_seq_id)

   where a.claim_seq_id=v_pat_clm_seq_id;

 ELSE

   select b.pat_enroll_detail_seq_id into v_pat_seq_id
    from app.pat_general_details b
   where b.pat_gen_detail_seq_id=v_pat_clm_seq_id;

  OPEN v_result_set FOR
   select
       v_pat_clm_seq_id as seq_id,
       PII.ins_intimation_req_yn,
       TO_CHAR(PII.ins_int_overriden_date,'DD/MM/YYYY') AS ins_int_overriden_date,   PII.ins_int_override_remarks,
       PII.ins_int_overriden_by,
       PII.ins_int_rson_type_id
   from pat_enroll_details a
   left outer join PAT_ins_intimation_details PII on (A.PAT_ENROLL_DETAIL_SEQ_ID=Pii.Pat_Auth_Seq_Id)
   where a.pat_enroll_detail_seq_id= v_pat_seq_id;

 END IF;

end select_ins_intimation;

END claims_approval_pkg;

/

--------------------------------------------------------
--  DDL for Synonymn CLM_HOSPITAL_DETAILS
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."CLM_HOSPITAL_DETAILS" FOR "APP"."CLM_HOSPITAL_DETAILS";

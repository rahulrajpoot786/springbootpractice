--------------------------------------------------------
--  DDL for Synonymn DISCREPANCY_INFORMATION
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."DISCREPANCY_INFORMATION" FOR "APP"."DISCREPANCY_INFORMATION";

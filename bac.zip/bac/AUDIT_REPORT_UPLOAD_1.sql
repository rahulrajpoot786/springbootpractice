--------------------------------------------------------
--  DDL for Package AUDIT_REPORT_UPLOAD
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "VENUBABU"."AUDIT_REPORT_UPLOAD" 
AS
  -- Procedure to store Uploadded XML File
  PROCEDURE SAVE_AUDIT_XML(v_xml_seq_id   IN  OUT NUMBER,
                           v_xml_file     IN  XMLTYPE,
                           v_file_name    IN  VARCHAR2,
                           v_added_by     IN  VARCHAR2,
                           v_success_yn   OUT  VARCHAR2
                          );
  
  -- Procedure to Capture Error Log                       
  PROCEDURE SAVE_AUDIT_EXCEPTION(v_log_seq_id  IN NUMBER,
                                 v_xml_seq_id  IN NUMBER,
                                 v_error_code  IN VARCHAR2,
                                 v_error_msg   IN VARCHAR2,
                                 v_error_proc  IN VARCHAR2,
                                 v_added_by    IN NUMBER
                                );
  -- Extract Audit XML
  PROCEDURE EXTRACT_AUDIT_XML(v_xml_seq_id  IN NUMBER,
                              v_added_by    IN NUMBER
                             );
                             
  -- Validate Claim Audit File
  PROCEDURE VALIDATE_CLAIM_AUDIT(v_xml_seq_id IN NUMBER,
                                 v_added_by   IN NUMBER);
                                 
  -- Get Error Log List
  PROCEDURE GET_AUDIT_LOG(v_start_dt          IN VARCHAR2,
                          v_end_dt            IN VARCHAR2,
                          v_result_set        OUT SYS_REFCURSOR
                         );
  -- Update Claim Status
  PROCEDURE UPDATE_CLM_STATUS(v_xml_seq_id  IN NUMBER,
                              v_added_by    IN NUMBER
                             );
  -- Check Number Datatype
  FUNCTION CHECK_DATA(v_value IN VARCHAR2) RETURN VARCHAR2;
END AUDIT_REPORT_UPLOAD;

/

--------------------------------------------------------
--  DDL for Synonymn IDX_END_NUM_INS_PROD
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."IDX_END_NUM_INS_PROD" FOR "APP"."IDX_END_NUM_INS_PROD";

--------------------------------------------------------
--  DDL for Synonymn ERROR_LOG
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."ERROR_LOG" FOR "APP"."ERROR_LOG";

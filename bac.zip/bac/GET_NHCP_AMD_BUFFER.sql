--------------------------------------------------------
--  DDL for Synonymn GET_NHCP_AMD_BUFFER
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."GET_NHCP_AMD_BUFFER" FOR "APP"."GET_NHCP_AMD_BUFFER";

--------------------------------------------------------
--  DDL for Synonymn CLM_CLAIM_SEQ
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."CLM_CLAIM_SEQ" FOR "APP"."CLM_CLAIM_SEQ";

--------------------------------------------------------
--  DDL for Synonymn COURIER_COMPANY
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."COURIER_COMPANY" FOR "APP"."COURIER_COMPANY";

--------------------------------------------------------
--  DDL for Synonymn CLM_CASH_BENEFIT
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."CLM_CASH_BENEFIT" FOR "APP"."CLM_CASH_BENEFIT";

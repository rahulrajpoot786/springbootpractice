--------------------------------------------------------
--  DDL for Synonymn IDX_BALANCEMISMATCH_GROUPSEQ
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."IDX_BALANCEMISMATCH_GROUPSEQ" FOR "APP"."IDX_BALANCEMISMATCH_GROUPSEQ";

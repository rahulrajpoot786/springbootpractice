--------------------------------------------------------
--  DDL for Synonymn ID_GENERATION_FLAGS
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."ID_GENERATION_FLAGS" FOR "APP"."ID_GENERATION_FLAGS";

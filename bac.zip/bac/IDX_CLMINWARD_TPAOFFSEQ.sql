--------------------------------------------------------
--  DDL for Synonymn IDX_CLMINWARD_TPAOFFSEQ
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."IDX_CLMINWARD_TPAOFFSEQ" FOR "APP"."IDX_CLMINWARD_TPAOFFSEQ";

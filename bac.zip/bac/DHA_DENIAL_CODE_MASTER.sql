--------------------------------------------------------
--  DDL for Synonymn DHA_DENIAL_CODE_MASTER
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."DHA_DENIAL_CODE_MASTER" FOR "APP"."DHA_DENIAL_CODE_MASTER";

--------------------------------------------------------
--  DDL for Synonymn DHA_SELF_PAID_MASTER
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."DHA_SELF_PAID_MASTER" FOR "APP"."DHA_SELF_PAID_MASTER";

--------------------------------------------------------
--  DDL for Synonymn HOSP_GROUP_INFO
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."HOSP_GROUP_INFO" FOR "APP"."HOSP_GROUP_INFO";

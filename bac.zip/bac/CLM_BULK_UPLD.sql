--------------------------------------------------------
--  DDL for Synonymn CLM_BULK_UPLD
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."CLM_BULK_UPLD" FOR "APP"."CLM_BULK_UPLD";

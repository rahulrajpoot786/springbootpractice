--------------------------------------------------------
--  DDL for Package Body ACCOUNT_INFO_PKG
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "VENUBABU"."ACCOUNT_INFO_PKG" IS
--======================================================================================================
  PROCEDURE select_member_list(
    search_tab      IN account_info_pkg.filter_tab_type,
    v_sort_var      IN VARCHAR2 ,
    v_sort_order    IN VARCHAR2,
    v_start_num     IN NUMBER ,
    v_end_num       IN NUMBER ,
    v_added_by      IN  NUMBER,            
    result_set      OUT SYS_REFCURSOR
  )
  IS
-- Order of arguments in search tab = OLD
------------------------------------

--1.  Search by enrolment ID.
--2.  Customer code
--3.  policy_number
--4.  Certificate no.
--5.  Scheme no.
--6.  Bank Account No.
--7.  Group ID
--8.  Emp.no.
--9.  mem_name
--10. Policy Type
--11. ins_head_office_seq_id
--12. tpa_office_seq_id



    TYPE bind_tab_type IS TABLE OF VARCHAR2(250) INDEX BY BINARY_INTEGER ;
    v_sql_str                VARCHAR2(3000);
    v_where                  VARCHAR2(2000);
    bind_tab                 bind_tab_type;
    i                        NUMBER(1) := 0;
  BEGIN
         v_sql_str :=
           'SELECT A.member_seq_id,
              c.policy_number,
              c.renewal_policy_number AS prev_policy_number,
              c.enrol_batch_seq_id,
              f.batch_number,
              A.tpa_enrollment_id,
              C.policy_seq_id,
              C.prev_policy_seq_id,
              B.policy_group_seq_id  ,
              a.mem_name,
              d.group_name,
              B.prev_policy_group_seq_id,
              CASE WHEN c.policy_status_general_type_id = ''POC'' THEN ''POC'' ELSE  c.ins_status_general_type_id END ins_status_general_type_id,
              g.enrol_description AS  policy_type,
              c.enrol_type_id ,
              CASE WHEN (SELECT count(1) FROM PAT_ENROLL_DETAILS AA WHERE AA.MEMBER_SEQ_ID = A.MEMBER_SEQ_ID) > 0 then ''Y'' ELSE ''N'' END AS preauth_made,
              CASE WHEN (SELECT count(1) FROM CLM_ENROLL_DETAILS BB WHERE BB.MEMBER_SEQ_ID = A.MEMBER_SEQ_ID)  > 0 then ''Y'' ELSE ''N'' END AS claim_made  ,
              b.tpa_enrollment_number||'' - ''|| b.insured_name as enrollment,
              c.effective_from_date, c.effective_to_date
              FROM tpa_enr_policy_member a JOIN tpa_enr_policy_group B ON (A.policy_group_seq_id = B.policy_group_seq_id )
              JOIN tpa_enr_policy c ON (b.policy_seq_id = c.policy_seq_id)
              LEFT OUTER JOIN tpa_group_registration d ON (c.group_reg_seq_id = d.group_reg_seq_id)
              JOIN tpa_ins_info e ON (c.ins_seq_id = e.ins_seq_id)
              JOIN tpa_batch_enrol f ON (c.enrol_batch_seq_id = f.enrol_batch_seq_id )
              JOIN tpa_enrolment_type_code g ON (c.enrol_type_id = g.enrol_type_id)
              LEFT OUTER JOIN tpa_enr_bank_dtls h ON (b.bank_seq_id = h.bank_seq_id)
              LEFT OUTER JOIN tpa_enr_bank_dtls I ON (C.bank_seq_id = I.bank_seq_id) ';

      IF search_tab(1) IS NOT NULL THEN
         v_where := v_where || ' AND A.tpa_enrollment_id  LIKE :search_tab_1';
         i := i+1;
         bind_tab(i) := UPPER(search_tab(1))||'%';
      END IF;
      IF search_tab(2) IS NOT NULL THEN
         v_where := v_where || ' AND a.ins_customer_code = :search_tab_2';
         i := i+1;
         bind_tab(i) := UPPER(search_tab(2));
      END IF;
      IF search_tab(3) IS NOT NULL THEN
         v_where := v_where || ' AND c.policy_number like :search_tab_3';
         i := i+1;
         bind_tab(i) := UPPER(search_tab(3))||'%';
      END IF;
      IF search_tab(4) IS NOT NULL THEN
         v_where := v_where || ' AND b.certificate_no = :search_tab_4 ';
         i := i+1;
         bind_tab(i) := search_tab(4);
      END IF;
      IF search_tab(5) IS NOT NULL THEN
         v_where := v_where || ' AND c.ins_scheme  = :search_tab_5 ' ;
         i := i+1;
         bind_tab(i) := UPPER(search_tab(5));
      END IF;
      IF search_tab(6) IS NOT NULL THEN
        IF search_tab(10) IN ('COR','NCR') THEN
           v_where := v_where || ' AND h.bank_account_no =  :search_tab_6 ';
        ELSE
          v_where := v_where || ' AND I.bank_account_no =  :search_tab_6 ';
        END IF;
        i := i+1;
        bind_tab(i) := search_tab(6);
      END IF;

      IF search_tab(7) IS NOT NULL THEN
         v_where := v_where || ' AND d.group_id = :search_tab_7';
         i := i+1;
         bind_tab(i) := upper(search_tab(7));
      END IF;
      IF search_tab(8) IS NOT NULL THEN
         v_where := v_where || ' AND B.employee_no = :search_tab_8';
         i := i+1;
         bind_tab(i) := search_tab(8);
      END IF;
      IF search_tab(9) IS NOT NULL THEN
        v_where := v_where || ' AND a.mem_name LIKE :search_tab_9 ';
        i := i+1;
        bind_tab(i) := UPPER(search_tab(9))||'%';
      END IF;

      IF search_tab(10) IS NOT NULL THEN
        v_where := v_where || ' AND c.enrol_type_id = :search_tab_11 ';
        i := i+1;
        bind_tab(i) := search_tab(10);
      END IF;
      IF search_tab(11) IS NOT NULL THEN
         v_where := v_where || ' AND c.ins_head_office_seq_id  = :search_tab_11';
         i := i+1;
         bind_tab(i) := search_tab(11);
      END IF;
      IF search_tab(12) IS NOT NULL THEN
         v_where := v_where || ' AND c.tpa_office_seq_id  = :search_tab_12';
         i := i+1;
         bind_tab(i) := search_tab(12);
      END IF;
      
--KOC_Cigna_insurance_resriction
    if v_added_by IS NOT NULL THEN
        v_where := v_where ||' AND ( c.ins_seq_id  in (SELECT inf.ins_seq_id FROM APP.TPA_GROUP_USER_ASSOC UA
      JOIN APP.TPA_GROUP_BRANCH GB ON (GB.GROUP_BRANCH_SEQ_ID = UA.GROUP_BRANCH_SEQ_ID)
      join APP.TPA_INS_INFO INF ON (inf.user_group = gb.group_branch_seq_id)
      WHERE GB.USER_TYPE=''NIC'' AND  UA.CONTACT_SEQ_ID = '||v_added_by||') OR (SELECT count(inf.ins_seq_id) FROM APP.TPA_GROUP_USER_ASSOC UA
      JOIN APP.TPA_GROUP_BRANCH GB ON (GB.GROUP_BRANCH_SEQ_ID = UA.GROUP_BRANCH_SEQ_ID)
      join APP.TPA_INS_INFO INF ON (inf.user_group = gb.group_branch_seq_id)
      WHERE GB.USER_TYPE=''NIC'' AND  UA.CONTACT_SEQ_ID = '||v_added_by||') = 0 )';
    end if;
--KOC_Cigna_insurance_resriction

      IF v_where IS NOT NULL THEN
        v_sql_str := v_sql_str ||' WHERE '||substr(v_where,5);
      END IF;
      v_sql_str := v_sql_str ||' AND f.batch_entry_complete_yn = ''Y'' AND c.completed_yn = ''Y'' AND a.deleted_yn = ''N''
       and b.deleted_yn = ''N'' and c.deleted_yn = ''N''';

      v_sql_str := 'SELECT * FROM
        (SELECT A.*, DENSE_RANK() OVER (ORDER BY '||v_sort_var||' '||v_sort_order||',ROWNUM) Q FROM (' ||v_sql_str|| ') A )
         WHERE  Q>= :v_start_num  AND Q<= :v_end_num ';

     CASE bind_tab.COUNT
       WHEN 1 THEN OPEN result_set FOR v_sql_str USING  bind_tab(1), v_start_num, v_end_num ;
       WHEN 2 THEN OPEN result_set FOR v_sql_str USING  bind_tab(1),bind_tab(2), v_start_num, v_end_num ;
       WHEN 3 THEN OPEN result_set FOR v_sql_str USING  bind_tab(1),bind_tab(2),bind_tab(3) , v_start_num, v_end_num ;
       WHEN 4 THEN OPEN result_set FOR v_sql_str USING  bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) , v_start_num, v_end_num ;
       WHEN 5 THEN OPEN result_set FOR v_sql_str USING  bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5), v_start_num, v_end_num ;
       WHEN 6 THEN OPEN result_set FOR v_sql_str USING  bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6), v_start_num, v_end_num ;
       WHEN 7 THEN OPEN result_set FOR v_sql_str USING  bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6),bind_tab(7), v_start_num, v_end_num ;
       WHEN 8 THEN OPEN result_set FOR v_sql_str USING  bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6),bind_tab(7),bind_tab(8), v_start_num, v_end_num ;
       WHEN 9 THEN OPEN result_set FOR v_sql_str USING  bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6),bind_tab(7),bind_tab(8),bind_tab(9), v_start_num, v_end_num ;
       WHEN 10 THEN OPEN result_set FOR v_sql_str USING  bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6),bind_tab(7),bind_tab(8),bind_tab(9),bind_tab(10), v_start_num, v_end_num ;
       WHEN 11 THEN OPEN result_set FOR v_sql_str USING  bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6),bind_tab(7),bind_tab(8),bind_tab(9),bind_tab(10),bind_tab(11), v_start_num, v_end_num ;
       WHEN 12 THEN OPEN result_set FOR v_sql_str USING  bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6),bind_tab(7),bind_tab(8),bind_tab(9),bind_tab(10),bind_tab(11),bind_tab(12), v_start_num, v_end_num ;
       WHEN 13 THEN OPEN result_set FOR v_sql_str USING  bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6),bind_tab(7),bind_tab(8),bind_tab(9),bind_tab(10),bind_tab(11),bind_tab(12),bind_tab(13), v_start_num, v_end_num ;
     END CASE;

  END select_member_list;
--======================================================================================================
  PROCEDURE select_enrollment_list (
    v_policy_group_seq_id      IN tpa_enr_policy_group.policy_group_seq_id%TYPE,
    result_set                 OUT SYS_REFCURSOR
  )
  IS
  BEGIN
    OPEN result_set FOR SELECT
         A.policy_group_seq_id ,
         A.tpa_enrollment_number ,
         A.insured_name ,
         A.tpa_enrollment_number||' - '|| A.insured_name enrollment,
         A.policy_seq_id
         FROM tpa_enr_policy_group A WHERE A.policy_group_seq_id = v_policy_group_seq_id;
  END select_enrollment_list;
--======================================================================================================
  PROCEDURE select_member_list(
    v_policy_group_seq_id   IN tpa_enr_policy_group.policy_group_seq_id%TYPE,
    result_set              OUT SYS_REFCURSOR
  )
  IS
  BEGIN
    OPEN result_set FOR
     SELECT
      A.tpa_enrollment_id,
      A.tpa_enrollment_id||' / '|| A.mem_name||' / '||C.relship_description||' / Pre-Auth('||
         CASE WHEN (SELECT count(1) FROM PAT_ENROLL_DETAILS AA WHERE AA.MEMBER_SEQ_ID = A.MEMBER_SEQ_ID) > 0 then 'Yes' ELSE 'No' END
         ||')  Claim('||
         CASE WHEN (SELECT count(1) FROM CLM_ENROLL_DETAILS BB WHERE BB.MEMBER_SEQ_ID = A.MEMBER_SEQ_ID)  > 0 then 'Yes' ELSE 'No' END||')' AS MEMBER,
      A.member_seq_id,
      CASE WHEN A.status_general_type_id = 'POC' THEN 'Y' ELSE 'N' END cancel_yn
      FROM  tpa_enr_policy_member a JOIN tpa_relationship_code C ON (a.relship_type_id = C.relship_type_id)
      WHERE a.policy_group_seq_id = v_policy_group_seq_id AND a.deleted_yn = 'N'
      ORDER BY A.tpa_enrollment_id;
  END select_member_list;
--======================================================================================================
  PROCEDURE select_endorsement_list (
    v_policy_seq_id                      IN  tpa_enr_endorsements.policy_seq_id%TYPE,
    v_result_set                         OUT SYS_REFCURSOR
  )
  IS
  BEGIN
    OPEN v_result_set FOR
      SELECT
       a.endorsement_seq_id,
       a.endorsement_number,
       a.cust_endorsement_number,
       b.description AS endorse_general_type_id,
       a.del_policy_yn,
       a.del_no_of_groups,
       a.del_no_of_members,
       a.add_no_of_groups,
       a.add_no_of_members,
       a.add_sum_insured,
       a.add_premium,
       a.mod_no_of_members,
       a.mod_premium_raise,
       a.mod_insured_raise,
       a.mod_premium_deduct,
       a.mod_insured_deduct,
       a.effective_date,
       a.received_date,
       a.completed_yn
       FROM tpa_enr_endorsements a JOIN tpa_general_code B ON (a.endorse_general_type_id = b.general_type_id)
       WHERE a.policy_seq_id = v_policy_seq_id
          AND a.deleted_yn = 'N';

  END select_endorsement_list;
--=============================================================================================
  PROCEDURE select_history_list (
    v_history_type                        IN VARCHAR2, --  HPR-> Pre-Authorization , POL->Policy , HCL-> Claims,CEH->CitiEnrolHistory,CCH-<CitiClaimHistory
    v_tpa_enrollment_id                   IN PAT_ENROLL_DETAILS.tpa_enrollment_id%TYPE,
    v_start_date                          IN VARCHAR2,
    v_end_date                            IN VARCHAR2,
    v_sort_var                            IN VARCHAR2,
    v_sort_order                          IN VARCHAR2 ,
    v_start_num                           IN NUMBER ,
    v_end_num                             IN NUMBER ,
    result_set                            OUT SYS_REFCURSOR
  )
  IS
    TYPE bind_tab_type IS TABLE OF VARCHAR2(250) INDEX BY BINARY_INTEGER ;
    bind_tab                           bind_tab_type;
    i                                  NUMBER(1) := 0;
    v_sql_str               VARCHAR2(4000);
    v_from_date             DATE  :=  TO_DATE(v_start_date,'dd/mm/yyyy');
    v_to_date               DATE  :=  TO_DATE(v_end_date,'dd/mm/yyyy');
    v_cust_code             CITIBANK_ENR_HISTORY.Custcode%TYPE;

    CURSOR mem_cur IS SELECT * FROM ( SELECT a.ins_customer_code , c.enrol_type_id
      FROM tpa_enr_policy_member a JOIN tpa_enr_policy_group b ON (a.policy_group_seq_id = b.policy_group_seq_id)
      JOIN tpa_enr_policy c ON (b.policy_seq_id = c.policy_seq_id)
      WHERE a.tpa_enrollment_id = v_tpa_enrollment_id
        ORDER BY a.member_seq_id DESC ) WHERE rownum = 1;

   mem_rec                  mem_cur%ROWTYPE;

-- Policy History - POL
-- Preauth -      HPR
-- Claim -      HCL

  BEGIN
   IF v_history_type = 'HPR' THEN
       i := 1;
       OPEN  mem_cur;
       FETCH mem_cur INTO mem_rec ;
       CLOSE mem_cur;

       v_sql_str :=
         'SELECT
          A.pat_enroll_detail_seq_id ,
          A.pre_auth_number ,
          A.auth_number ,
          A.hosp_seq_id ,
          B.hosp_name,
          C.total_app_amount,
          NVL( d.pat_status_general_type_id, A.pat_status_general_type_id ) AS pat_status_general_type_id ,
          C.pat_received_date ,
          NVL(case when a.pat_status_general_type_id =''REJ''  AND C.COMPLETED_YN=''N'' AND pii.pat_ins_status=''INP'' THEN ACCOUNT_INFO_PKG.get_gen_desc(''INSR'',''G'') ELSE E.Description END , F.Description) as Description ,
          C.pat_gen_detail_seq_id ,
          C.likely_date_of_hospitalization ,
          CASE WHEN C.pat_enhanced_yn = ''N'' AND C.parent_gen_detail_seq_id IS NOT NULL THEN ''Y'' ELSE ''N'' END  as pat_enhanced_yn
          FROM pat_enroll_details A LEFT OUTER JOIN tpa_hosp_info B ON ( A.hosp_seq_id = B. hosp_seq_id )
          JOIN pat_general_details C ON ( a.pat_enroll_detail_seq_id = c.pat_enroll_detail_seq_id )
          left outer join pat_ins_intimation_details pii on (a.PAT_ENROLL_DETAIL_SEQ_ID= pii.PAT_ENROLL_DETAIL_SEQ_ID)
          LEFT OUTER JOIN assign_users D ON ( C.last_assign_user_seq_id = d.assign_users_seq_id )
          LEFT OUTER JOIN tpa_general_code E ON ( D.pat_status_general_type_id  = E.general_type_id )
          LEFT OUTER JOIN tpa_general_code F ON ( A.pat_status_general_type_id = F.general_type_id ) ';

       IF mem_rec.enrol_type_id = 'NCR' THEN
         v_sql_str := v_sql_str ||' WHERE  A.ins_customer_code = :ins_customer_code ';
         bind_tab(1) := mem_rec.ins_customer_code;
       ELSE
         v_sql_str   := v_sql_str ||' WHERE A.tpa_enrollment_id = :v_tpa_enrollment_id ';
         bind_tab(1) := v_tpa_enrollment_id;
       END IF;

       IF v_from_date IS NOT NULL THEN
           v_sql_str := v_sql_str || ' AND C.likely_date_of_hospitalization  >= :v_from_date ';
           i := i+1;
           bind_tab(i) := v_from_date;
       END IF;
       IF v_to_date IS NOT NULL THEN
           v_sql_str := v_sql_str || ' AND C.likely_date_of_hospitalization  <= :v_to_date ';
           i := i+1;
           bind_tab(i) := v_to_date;
       END IF;

       v_sql_str := 'SELECT * FROM
          (SELECT A.*, DENSE_RANK() OVER (ORDER BY '||v_sort_var||' '||v_sort_order||', ROWNUM)
          Q FROM (' ||v_sql_str|| ') A ) WHERE Q >= :v_start_num AND Q <= :v_end_num ';


       CASE bind_tab.COUNT
             WHEN 1 THEN OPEN result_set FOR v_sql_str USING  bind_tab(1),  v_start_num , v_end_num ;
             WHEN 2 THEN OPEN result_set FOR v_sql_str USING  bind_tab(1),  bind_tab(2), v_start_num , v_end_num ;
             WHEN 3 THEN OPEN result_set FOR v_sql_str USING  bind_tab(1),  bind_tab(2), bind_tab(3), v_start_num , v_end_num ;
             WHEN 4 THEN OPEN result_set FOR v_sql_str USING  bind_tab(1),  bind_tab(2), bind_tab(3),bind_tab(4), v_start_num , v_end_num ;
             WHEN 5 THEN OPEN result_set FOR v_sql_str USING  bind_tab(1),  bind_tab(2), bind_tab(3),bind_tab(4),bind_tab(5), v_start_num , v_end_num ;
       END CASE;

    ELSIF v_history_type = 'POL' THEN
      i := 1;
      OPEN  mem_cur;
      FETCH mem_cur INTO mem_rec ;
      CLOSE mem_cur;

     v_sql_str :=
    ' SELECT
      A.policy_seq_id ,
      A.policy_number ,
      A.effective_from_date ,
      A.effective_to_date ,
      C.member_seq_id ,
      c.date_of_inception,
      c.date_of_exit
      FROM tpa_enr_policy A JOIN tpa_enr_policy_group B ON (A.policy_seq_id = B.policy_seq_id AND A.deleted_yn = ''N'')
      JOIN tpa_enr_policy_member C ON (b.policy_group_seq_id = c.policy_group_seq_id AND C.deleted_yn = ''N'' )';

      IF mem_rec.enrol_type_id != 'NCR' THEN
         v_sql_str := v_sql_str ||' WHERE  C.tpa_enrollment_id = :v_tpa_enrollment_id ';
         bind_tab(1) := v_tpa_enrollment_id;
      ELSE
         v_sql_str   := v_sql_str ||' WHERE C.ins_customer_code  = :ins_customer_code  ';
         bind_tab(1) := mem_rec.ins_customer_code;
      END IF;

      IF v_from_date IS NOT NULL THEN
           v_sql_str := v_sql_str || ' AND A.effective_from_date  >= :v_from_date ';
           i := i+1;
           bind_tab(i) := v_from_date;
      END IF;

      IF v_to_date IS NOT NULL THEN
           v_sql_str := v_sql_str || ' AND A.effective_from_date  <= :v_to_date ';
           i := i+1;
           bind_tab(i) := v_to_date;
      END IF;


      v_sql_str := ' SELECT * FROM
          (SELECT A.*, DENSE_RANK() OVER (ORDER BY '||v_sort_var||' '||v_sort_order||', ROWNUM)
          Q FROM (' ||v_sql_str|| ') A ) WHERE Q>= :v_start_num AND Q<= :v_end_num ';

      CASE bind_tab.COUNT
             WHEN 1 THEN OPEN result_set FOR v_sql_str USING  bind_tab(1),  v_start_num , v_end_num ;
             WHEN 2 THEN OPEN result_set FOR v_sql_str USING  bind_tab(1),  bind_tab(2), v_start_num , v_end_num ;
             WHEN 3 THEN OPEN result_set FOR v_sql_str USING  bind_tab(1),  bind_tab(2), bind_tab(3), v_start_num , v_end_num ;
       END CASE;

    ELSIF v_history_type = 'HCL' THEN
       OPEN mem_cur;
       FETCH mem_cur INTO mem_rec ;
       CLOSE mem_cur;

       v_sql_str :=
        'SELECT a.claim_seq_id,
        B.claim_number,
        A.claimant_name,
        c.rcvd_date,
        B.requested_amount,
        case when clm_status_general_type_id =''REJ'' AND B.COMPLETED_YN=''N'' AND CII.CLM_INS_STATUS=''INP'' THEN ACCOUNT_INFO_PKG.get_gen_desc(''INSR'',''G'') ELSE d.description end as description,
        B.total_app_amount ,
        b.date_of_admission,
        b.date_of_discharge,
        a.policy_number
        FROM clm_enroll_details a JOIN clm_general_details b ON (a.claim_seq_id = b.claim_seq_id)
        JOIN clm_inward C ON (B.claims_inward_seq_id = C.claims_inward_seq_id )
        LEFT OUTER JOIN clm_ins_intimation_details cii on (a.claim_seq_id=cii.claim_seq_id)
        LEFT OUTER JOIN tpa_general_code D ON (a.clm_status_general_type_id = D.general_type_id) ';

       IF mem_rec.enrol_type_id = 'NCR' THEN
         v_sql_str := v_sql_str ||' WHERE A.ins_customer_code   = :ins_customer_code ';
         bind_tab(1) := mem_rec.ins_customer_code;
       ELSE
         v_sql_str   := v_sql_str ||'WHERE A.tpa_enrollment_id = :v_tpa_enrollment_id ';
         bind_tab(1) := v_tpa_enrollment_id;
       END IF;

       IF v_from_date IS NOT NULL THEN
           v_sql_str := v_sql_str || ' AND b.date_of_admission >= :v_from_date ';
           i := i+1;
           bind_tab(i) := v_from_date;
       END IF;
       IF v_to_date IS NOT NULL THEN
           v_sql_str := v_sql_str || ' AND b.date_of_admission < :v_to_date';
           i := i+1;
           bind_tab(i) := v_to_date + 1;
        END IF;
        v_sql_str := 'SELECT * FROM
            (SELECT A.*, DENSE_RANK() OVER (ORDER BY '||v_sort_var||' '||v_sort_order||', ROWNUM)
            Q FROM (' ||v_sql_str|| ') A ) WHERE Q>= :v_start_num AND Q<= :v_end_num ';

        CASE bind_tab.COUNT
             WHEN 1 THEN OPEN result_set FOR v_sql_str USING  bind_tab(1),  v_start_num , v_end_num ;
             WHEN 2 THEN OPEN result_set FOR v_sql_str USING  bind_tab(1),  bind_tab(2), v_start_num , v_end_num ;
             WHEN 3 THEN OPEN result_set FOR v_sql_str USING  bind_tab(1),  bind_tab(2), bind_tab(3), v_start_num , v_end_num ;
        END CASE;
    ELSIF v_history_type = 'CEH' THEN
          OPEN  mem_cur;
          FETCH mem_cur INTO mem_rec ;
          CLOSE mem_cur;

          v_sql_str := 'SELECT citibank_enr_seq_id, custcode, ord_num
                          FROM Citibank_Enr_History
                            WHERE custcode = :v_cust_code';

          v_sql_str := 'SELECT * FROM
          (SELECT A.*, DENSE_RANK() OVER (ORDER BY '||v_sort_var||' '||v_sort_order||', ROWNUM)
          Q FROM (' ||v_sql_str|| ') A ) WHERE Q>= :v_start_num AND Q<= :v_end_num ';

          OPEN result_set FOR v_sql_str USING mem_rec.ins_customer_code, v_start_num, v_end_num ;
    ELSIF v_history_type = 'CCH' THEN
          OPEN  mem_cur;
          FETCH mem_cur INTO mem_rec ;
          CLOSE mem_cur;

          v_sql_str := 'SELECT citibank_clm_seq_id, custcode, claimno, claimyear
                          FROM Citibank_Clm_History
                            WHERE custcode = :v_cust_code';

          v_sql_str := 'SELECT * FROM
          (SELECT A.*, DENSE_RANK() OVER (ORDER BY '||v_sort_var||' '||v_sort_order||', ROWNUM)
          Q FROM (' ||v_sql_str|| ') A ) WHERE Q>= :v_start_num AND Q<= :v_end_num ';

          OPEN result_set FOR v_sql_str USING mem_rec.ins_customer_code, v_start_num, v_end_num ;
    END IF;

  END select_history_list;
--======================================================================================================
  PROCEDURE select_policy (
    v_policy_seq_id                IN  tpa_enr_policy_member.member_seq_id%TYPE,
    v_policy_group_seq_id          IN  tpa_enr_policy_group.policy_group_seq_id%TYPE,
    v_enrol_type_id                IN  tpa_enr_policy.enrol_type_id%TYPE,
    v_result_set                   OUT SYS_REFCURSOR
  )
  IS

  BEGIN
    IF v_policy_group_seq_id IS NOT NULL THEN
     OPEN v_result_set FOR
       SELECT
       c.policy_number,
       c.policy_seq_id,
       d.product_name,
       b.insured_name , -- for IND and ING policy_holder is this column
       K.group_name,    -- for COR and NCR policy_holder is this column
       K.group_id,      -- for COR and NCR only
       g.ins_comp_name,

       g.ins_comp_code_number,
       e.enrol_description AS policy_type,
       f.description AS policy_sub_type,
       c.effective_from_date,
       c.effective_to_date,
       c.total_sum_insured,
       h.res_phone_no, -- for IND and ING only
       ttk_util_pkg.fn_decrypt(h.mobile_no) as mobile_no, --/ED   -- for IND and ING only
       c.remarks,

       i.description AS term_status  ,
       c.enrol_type_id  ,
       h.address_1 AS family_address_1,
       h.address_2 AS family_address_2,
       h.address_3 AS family_address_3,
       l.state_name AS family_state,
       h.city_type_id AS family_city,
       h.pin_code AS family_pincode,
       m.address_1 AS group_address_1,
       m.address_2 AS group_address_2,
       m.address_3 AS group_address_3,
       n.state_name AS group_state_name,
       o.city_description AS group_city,
       m.pin_code AS group_pin_code,

       p.address_1 AS ins_address_1,
       p.address_2 AS ins_address_2,
       p.address_3 AS ins_address_3,
       q.state_name AS ins_state_name,
       r.city_description AS ins_city,
       p.pin_code AS ins_pin_code,
       c.zone_code, --For KOC1010
       (SELECT COUNT(1) FROM tpa_enr_endorsements aa WHERE aa.policy_seq_id = c.policy_seq_id) AS endorsement_count,
       b.declaration_date AS proposal_date  ---This date added as per KOC857
       FROM tpa_enr_policy_group b JOIN tpa_enr_policy c ON (b.policy_seq_id = c.policy_seq_id)
       JOIN tpa_ins_product d ON (c.product_seq_id = d.product_seq_id)
       JOIN tpa_enrolment_type_code e ON (c.enrol_type_id = e.enrol_type_id)
       LEFT OUTER JOIN tpa_general_code f ON (c.policy_sub_general_type_id = f.general_type_id)
       JOIN tpa_ins_info g ON (c.ins_head_office_seq_id = g.ins_seq_id)
       LEFT OUTER JOIN tpa_enr_mem_address h ON (b.enr_address_seq_id = h.enr_address_seq_id)
       LEFT OUTER JOIN tpa_general_code i ON (c.ins_status_general_type_id = i.general_type_id)
       LEFT OUTER JOIN tpa_address j ON (c.group_reg_seq_id = j.group_reg_seq_id)
       LEFT OUTER JOIN tpa_group_registration k ON (c.group_reg_seq_id = k.group_reg_seq_id)
       LEFT OUTER JOIN tpa_state_code l ON (h.state_type_id = l.state_type_id)
       LEFT OUTER JOIN tpa_address m ON(k.group_reg_seq_id = m.group_reg_seq_id)
       LEFT OUTER JOIN tpa_state_code n ON (m.state_type_id = n.state_type_id)
       LEFT OUTER JOIN tpa_city_code o ON (m.city_type_id = o.city_type_id)
       LEFT OUTER JOIN tpa_address p ON(g.ins_seq_id =p.ins_seq_id)
       LEFT OUTER JOIN tpa_state_code q ON (p.state_type_id = q.state_type_id)
       LEFT OUTER JOIN tpa_city_code r ON (p.city_type_id = r.city_type_id)
       WHERE b.policy_group_seq_id = v_policy_group_seq_id ;
    ELSE
      OPEN v_result_set FOR
       SELECT
       c.policy_number,
       c.policy_seq_id,
       d.product_name,
       NULL insured_name , -- for IND and ING policy_holder is this column
       K.group_name,    -- for COR and NCR policy_holder is this column
       K.group_id,      -- for COR and NCR only
       g.ins_comp_name,

       g.ins_comp_code_number,
       e.enrol_description AS policy_type,
       f.description AS policy_sub_type,
       c.effective_from_date,
       c.effective_to_date,
       c.total_sum_insured,

       NULL res_phone_no, -- for IND and ING only
       NULL mobile_no, --/ED   -- for IND and ING only
       c.remarks,

       i.description AS term_status  ,
       c.enrol_type_id  ,
       NULL  family_address_1,
       NULL  family_address_2,
       NULL  family_address_3,
       NULL AS family_state,
       NULL  AS family_city,
       NULL  AS family_pincode,
       m.address_1 AS group_address_1,
       m.address_2 AS group_address_2,
       m.address_3 AS group_address_3,
       n.state_name AS group_state_name,
       o.city_description AS group_city,
       m.pin_code AS group_pin_code,

       p.address_1 AS ins_address_1,
       p.address_2 AS ins_address_2,
       p.address_3 AS ins_address_3,
       q.state_name AS ins_state_name,
       r.city_description AS ins_city,
       p.pin_code AS ins_pin_code,
       c.zone_code, --For KOC1010
       (SELECT COUNT(1) FROM tpa_enr_endorsements aa WHERE aa.policy_seq_id = c.policy_seq_id) AS endorsement_count
       FROM tpa_enr_policy c JOIN tpa_ins_product d ON (c.product_seq_id = d.product_seq_id)
       JOIN tpa_enrolment_type_code e ON (c.enrol_type_id = e.enrol_type_id)
       LEFT OUTER JOIN tpa_general_code f ON (c.policy_sub_general_type_id = f.general_type_id)
       JOIN tpa_ins_info g ON (c.ins_head_office_seq_id = g.ins_seq_id)
       LEFT OUTER JOIN tpa_general_code i ON (c.ins_status_general_type_id = i.general_type_id)
       LEFT OUTER JOIN tpa_address j ON (c.group_reg_seq_id = j.group_reg_seq_id)
       LEFT OUTER JOIN tpa_group_registration k ON (c.group_reg_seq_id = k.group_reg_seq_id)
       LEFT OUTER JOIN tpa_address m ON(k.group_reg_seq_id = m.group_reg_seq_id)
       LEFT OUTER JOIN tpa_state_code n ON (m.state_type_id = n.state_type_id)
       LEFT OUTER JOIN tpa_city_code o ON (m.city_type_id = o.city_type_id)
       LEFT OUTER JOIN tpa_address p ON(g.ins_seq_id =p.ins_seq_id)
       LEFT OUTER JOIN tpa_state_code q ON (p.state_type_id = q.state_type_id)
       LEFT OUTER JOIN tpa_city_code r ON (p.city_type_id = r.city_type_id)
       WHERE c.policy_seq_id = v_policy_seq_id ;
    END IF;
  END select_policy;
--======================================================================================================
  PROCEDURE create_policy_xml (
    v_member_seq_id                IN  tpa_enr_policy_member.member_seq_id%TYPE,
    v_policy_history_doc           OUT XMLTYPE
  )
  IS
     CURSOR card_cur IS SELECT c.batch_no, c.batch_date  , d.courier_id , D.doc_dispatch_rcvd_date
          FROM tpa_enr_policy_member a JOIN tpa_enr_mem_card_dtl b ON (a.tpa_enrollment_id = b.tpa_enrollment_id)
          JOIN tpa_card_batch c ON (b.card_batch_seq_id = c.card_batch_seq_id)
          LEFT OUTER JOIN courier_details d ON (b.courier_seq_id = d.courier_seq_id)
          WHERE a.member_seq_id = v_member_seq_id
          ORDER BY b.card_mem_seq_id DESC;
     card_rec    card_cur%ROWTYPE;

     CURSOR policy_cur IS
       SELECT
          a.member_seq_id ,
          a.tpa_enrollment_id,
          a.mem_name,
          d.description AS gender,
          TO_CHAR(a.mem_dob,'DD/MM/YYYY') AS mem_dob,
          a.mem_age,
          TO_CHAR(a.date_of_inception,'DD/MM/YYYY') AS date_of_inception,
          TO_CHAR(a.date_of_exit,'DD/MM/YYYY') AS date_of_exit,
          NVL(e.res_phone_no,E.off_phone_no_1) AS phone,
          f.description AS category,
          c.policy_number,
          g.product_name,
          b.Insured_Name,
          h.ins_comp_name,
          i.enrol_description AS policy_type,
          i.enrol_type_id ,
          J.description AS policy_sub_type,
          TO_CHAR(C.effective_from_date,'DD/MM/YYYY') AS start_date,
          TO_CHAR(c.effective_to_date,'DD/MM/YYYY') AS end_date,
          NVL(A.mem_tot_sum_insured,B.floater_sum_insured) AS sum_insured,
          c.total_sum_insured ,
          K.description AS term_status,
          L.res_phone_no,
         ttk_util_pkg.fn_decrypt(L.mobile_no) AS mobile_no, --/ED
          --C.remarks, commented by Ramakrishna K M KOC833
          C.policy_remarks AS remarks,
          a.member_remarks AS member_remarks,  -- new column added as of KOC616
          m.group_name ,
          N.description AS member_type, --  FLOATER, NON-FLOATER etc.
          o.bonus,
          o.sum_insured + o.bonus - o.utilised_sum_insured - o.utilised_cum_bonus AS available_sum_insured,
          a.card_prn_date,
          mod(a.card_prn_count,2) AS card_prn_count,
          -- folllowing address columns added by Prasanna.
          L.address_1 AS add_1,
          L.address_2 AS add_2,
          L.address_3 AS add_3,
          L.city_type_id AS add_4,
          L.pin_code AS add_5,
          P.state_name AS add_state,
          q.remarks AS buffer_remarks,
          a.ins_customer_code,
          b.certificate_no,
          c.ins_scheme,
          TO_CHAR(B.declaration_date,'DD/MM/YYYY') AS proposal_date,  ---This date added as per KOC857
          c.zone_code, --For KOC1010
          DECODE(A.diabetes_cover_yn ,'Y','Yes','No') AS diabetes_cover_yn, --For KOC1010
          DECODE(A.hypertension_cover_yn ,'Y','Yes','No') AS hypertension_cover_yn, --For KOC1010
          a.VIP_YN -- ADDED FOR KOC1136
         FROM tpa_enr_policy_member A JOIN tpa_enr_policy_group B ON (a.policy_group_seq_id = b.policy_group_seq_id)
         JOIN tpa_enr_policy C ON (b.policy_seq_id = c.policy_seq_id)
         JOIN tpa_general_code D ON (a.gender_general_type_id = d.general_type_id)
         LEFT OUTER JOIN tpa_enr_mem_address E ON (A.enr_address_seq_id = E.enr_address_seq_id)
         LEFT OUTER JOIN tpa_general_code F ON (a.category_general_type_id = F.general_type_id)
         JOIN tpa_ins_product G ON (C.product_seq_id = G.product_seq_id)
         JOIN tpa_ins_info H ON (c.ins_seq_id = h.ins_seq_id)
         JOIN tpa_enrolment_type_code I ON (C.enrol_type_id = I.enrol_type_id)
         JOIN tpa_general_code J ON (C.policy_sub_general_type_id = J.general_type_id)
         LEFT OUTER JOIN tpa_general_code K ON (C.policy_status_general_type_id = K.general_type_id)
         LEFT OUTER JOIN tpa_enr_mem_address L ON (B.enr_address_seq_id = L.enr_address_seq_id)
         LEFT OUTER JOIN tpa_group_registration M ON (c.group_reg_seq_id = m.group_reg_seq_id)
         LEFT OUTER JOIN tpa_general_code n ON (a.mem_general_type_id = n.general_type_id)
         LEFT OUTER JOIN tpa_enr_balance o ON (a.policy_group_seq_id = o.policy_group_seq_id)
         LEFT OUTER JOIN tpa_state_code P ON (L.state_type_id = P.state_type_id)
         LEFT OUTER JOIN tpa_enr_buffer_details q ON (c.policy_seq_id = q.policy_seq_id)
         WHERE a.member_seq_id = v_member_seq_id
         AND (a.mem_general_type_id != 'PFL' AND o.member_seq_id = v_member_seq_id OR b.policy_group_seq_id = o.policy_group_seq_id AND o.member_seq_id IS NULL)
          ORDER BY q.buffer_added_date DESC;

      CURSOR sum_insured_cur IS
        SELECT
         b.mem_insured_seq_id,
         b.mem_sum_insured,
         b.mem_bonus_amount,
         b.policy_date   ,
         c.prod_plan_name
         FROM tpa_enr_policy_member a JOIN tpa_enr_mem_insured b ON (a.policy_group_seq_id = b.policy_group_seq_id)
         LEFT OUTER JOIN tpa_ins_product_plan c ON (b.prod_plan_seq_id = c.prod_plan_seq_id)
         WHERE a.member_seq_id = v_member_seq_id AND B.deleted_yn = 'N'
         AND (a.mem_general_type_id != 'PFL' AND a.member_seq_id = b.member_seq_id
               OR b.member_seq_id IS NULL);

      v_rec_user           policy_cur%ROWTYPE;

      CURSOR ped_cur IS SELECT r.ped_code_id , r.icd_code , s.ped_description ,r.mem_duration ,r.remarks FROM
        ( SELECT ped_code_id, icd_code , a.mem_duration ,a.remarks FROM tpa_enr_mem_ped a JOIN tpa_enr_policy_member b ON (a.member_seq_id = b.member_seq_id)
        WHERE b.tpa_enrollment_id = v_rec_user.tpa_enrollment_id
           UNION
         SELECT ped_code_id,icd_code,a.mem_duration ,a.remarks FROM claimant_ped  a JOIN tpa_enr_policy_member b ON (a.member_seq_id = b.member_seq_id)
        WHERE b.tpa_enrollment_id = v_rec_user.tpa_enrollment_id) r JOIN tpa_ped_code s ON (r.ped_code_id = s.ped_code_id) ;

      v_policy_doc         DBMS_XMLDOM.DOMDocument;
      v_policy_root_node   DBMS_XMLDOM.DOMNode;
      v_elem               DBMS_XMLDOM.DOMElement;
      v_elem1              DBMS_XMLDOM.DOMElement;
      v_node               DBMS_XMLDOM.DOMNode;
      v_parent_node        DBMS_XMLDOM.DOMNODE;
      v_child_node         DBMS_XMLDOM.DOMNODE;
      v_root_node          DBMS_XMLDOM.DOMNode;
      v_buf                VARCHAR2(4000);

    BEGIN
      OPEN policy_cur;
      FETCH policy_cur INTO v_rec_user;
      CLOSE policy_cur;

      OPEN card_cur;
      FETCH card_cur INTO card_rec;
      CLOSE card_cur;


      v_policy_doc := dbms_xmldom.newDOMDocument;
      dbms_xmldom.setVersion( v_policy_doc, '1.0' );
      v_policy_root_node := dbms_xmldom.makeNode(v_policy_doc);

      v_elem := dbms_xmldom.createElement( v_policy_doc, 'memberpolicyhistory' );
      v_node := dbms_xmldom.makeNode( v_elem );
      v_policy_root_node := dbms_xmldom.appendChild( v_policy_root_node, v_node );
---
      v_elem := dbms_xmldom.createElement(v_policy_doc, 'member');
      dbms_xmldom.setAttribute(v_elem,'enrollmentid',v_rec_user.tpa_enrollment_id);
      dbms_xmldom.setAttribute(v_elem,'customercode',v_rec_user.ins_customer_code);
      dbms_xmldom.setAttribute(v_elem,'certificateno',v_rec_user.certificate_no);
      dbms_xmldom.setAttribute(v_elem,'memname',v_rec_user.mem_name);
      dbms_xmldom.setAttribute(v_elem,'gender',v_rec_user.gender);
      dbms_xmldom.setAttribute(v_elem,'memdob',v_rec_user.mem_dob);
      dbms_xmldom.setAttribute(v_elem,'age',v_rec_user.mem_age);
      dbms_xmldom.setAttribute(v_elem,'dateofinception',v_rec_user.date_of_inception);
      dbms_xmldom.setAttribute(v_elem,'dateofexit',v_rec_user.date_of_exit);
      dbms_xmldom.setAttribute(v_elem,'phone',v_rec_user.phone);
      dbms_xmldom.setAttribute(v_elem,'category',v_rec_user.category);
      dbms_xmldom.setAttribute(v_elem,'membersubtype',v_rec_user.member_type);
      dbms_xmldom.setAttribute(v_elem,'suminsured',v_rec_user.sum_insured);
      dbms_xmldom.setAttribute(v_elem,'availablesuminsured',v_rec_user.available_sum_insured);
      dbms_xmldom.setAttribute(v_elem,'cumulativebonus',v_rec_user.bonus);
      dbms_xmldom.setAttribute(v_elem,'memberremarks',v_rec_user.member_remarks); -- new attribute added for KOC616
      dbms_xmldom.setAttribute(v_elem,'diabetes_cover_yn',v_rec_user.diabetes_cover_yn); --For KOC1010
      dbms_xmldom.setAttribute(v_elem,'hypertension_cover_yn',v_rec_user.hypertension_cover_yn); --For KOC1010
      dbms_xmldom.setAttribute(v_elem,'add_1',v_rec_user.add_1);
      dbms_xmldom.setAttribute(v_elem,'add_2',v_rec_user.add_2);
      dbms_xmldom.setAttribute(v_elem,'add_3',v_rec_user.add_3);
      dbms_xmldom.setAttribute(v_elem,'add_4',v_rec_user.add_4);
      dbms_xmldom.setAttribute(v_elem,'add_5',v_rec_user.add_5);
      dbms_xmldom.setAttribute(v_elem,'add_state',v_rec_user.add_state);
      dbms_xmldom.setAttribute(v_elem,'VIP_YN',v_rec_user.VIP_YN); --ADDED FOR KOC1136

      v_node := dbms_xmldom.makeNode(v_elem);
      v_parent_node := dbms_xmldom.appendChild( v_policy_root_node, v_node);
--------
      v_elem := dbms_xmldom.createElement( v_policy_doc, 'suminsureddetails' );
      v_node := dbms_xmldom.makeNode(v_elem);
      v_parent_node := dbms_xmldom.appendChild( v_parent_node, v_node);

      FOR rec IN sum_insured_cur
      LOOP
        v_elem := dbms_xmldom.createElement( v_policy_doc, 'breakup');
        dbms_xmldom.setAttribute(v_elem,'suminsured',rec.mem_sum_insured);
        dbms_xmldom.setAttribute(v_elem,'prodplanname',rec.prod_plan_name);  -- new attribute added for KOC616
        dbms_xmldom.setAttribute(v_elem,'bonus',rec.mem_bonus_amount);
        dbms_xmldom.setAttribute(v_elem,'effectivedate',TO_CHAR(rec.policy_date,'dd/mm/yyyy'));
        v_node := dbms_xmldom.makeNode(v_elem);
        v_child_node := dbms_xmldom.appendChild( v_parent_node, v_node);
      END LOOP;
--------
      v_elem := dbms_xmldom.createElement(v_policy_doc, 'policy');
      dbms_xmldom.setAttribute(v_elem,'policynumber',v_rec_user.policy_number);
      dbms_xmldom.setAttribute(v_elem,'schemename',v_rec_user.ins_scheme);
      dbms_xmldom.setAttribute(v_elem,'productname',v_rec_user.product_name);
      dbms_xmldom.setAttribute(v_elem,'insuredname',v_rec_user.Insured_Name);
      dbms_xmldom.setAttribute(v_elem,'inscompname',v_rec_user.ins_comp_name);
      dbms_xmldom.setAttribute(v_elem,'policytype',v_rec_user.policy_type);
      dbms_xmldom.setAttribute(v_elem,'policysubtype',v_rec_user.policy_sub_type);
      dbms_xmldom.setAttribute(v_elem,'startdate',v_rec_user.start_date);
      dbms_xmldom.setAttribute(v_elem,'enddate',v_rec_user.end_date);
      dbms_xmldom.setAttribute(v_elem,'suminsured',v_rec_user.total_sum_insured);
      dbms_xmldom.setAttribute(v_elem,'termstatus',v_rec_user.term_status);
      dbms_xmldom.setAttribute(v_elem,'resphoneno',v_rec_user.res_phone_no);
      dbms_xmldom.setAttribute(v_elem,'mobileno',v_rec_user.mobile_no); --/ED --cursor decrypted
      dbms_xmldom.setAttribute(v_elem,'remarks',v_rec_user.remarks);
      dbms_xmldom.setAttribute(v_elem,'groupname',v_rec_user.group_name);
      dbms_xmldom.setAttribute(v_elem,'enroltype',v_rec_user.enrol_type_id);
      dbms_xmldom.setAttribute(v_elem,'bufferremarks',v_rec_user.buffer_remarks);
      dbms_xmldom.setAttribute(v_elem,'proposaldate',v_rec_user.proposal_date);
      dbms_xmldom.setAttribute(v_elem,'zonecode',v_rec_user.zone_code);--For KOC1010

      v_node := dbms_xmldom.makeNode(v_elem);
      v_parent_node := dbms_xmldom.appendChild( v_policy_root_node, v_node);

      v_elem := dbms_xmldom.createElement(v_policy_doc, 'carddetails');
      dbms_xmldom.setAttribute(v_elem,'noofcardsprinted',v_rec_user.card_prn_count);
      dbms_xmldom.setAttribute(v_elem,'cardprintdate',v_rec_user.card_prn_date);
      dbms_xmldom.setAttribute(v_elem,'cardbatchno',card_rec.batch_no);
      dbms_xmldom.setAttribute(v_elem,'courierno',card_rec.courier_id);
      dbms_xmldom.setAttribute(v_elem,'courierdate',card_rec.doc_dispatch_rcvd_date);
      v_node := dbms_xmldom.makeNode(v_elem);
      v_parent_node := dbms_xmldom.appendChild( v_policy_root_node, v_node);

      v_elem := dbms_xmldom.createElement( v_policy_doc, 'peddetails' );
      v_node := dbms_xmldom.makeNode(v_elem);
      v_parent_node := dbms_xmldom.appendChild( v_policy_root_node, v_node);

      FOR rec IN ped_cur
      LOOP
        v_elem := dbms_xmldom.createElement( v_policy_doc, 'ped');
        dbms_xmldom.setAttribute(v_elem,'icdcode',rec.icd_code);
        dbms_xmldom.setAttribute(v_elem,'peddescription',rec.ped_description);
        dbms_xmldom.setAttribute(v_elem,'duration',rec.mem_duration);
        dbms_xmldom.setAttribute(v_elem,'remarks',rec.remarks);
        v_node := dbms_xmldom.makeNode(v_elem);
        v_child_node := dbms_xmldom.appendChild( v_parent_node, v_node);
      END LOOP;

    v_policy_history_doc := dbms_xmldom.getxmltype(v_policy_doc);
    dbms_xmldom.freeDocument(v_policy_doc);
  END create_policy_xml;
--======================================================================================================
  PROCEDURE create_preauth_xml (
    v_pat_gen_detail_seq_id                 IN  pat_general_details.pat_gen_detail_seq_id%TYPE,
    v_pat_enroll_detail_seq_id              IN pat_enroll_details.pat_enroll_detail_seq_id%TYPE,
    v_preauth_history_doc                   OUT XMLTYPE
   )
   IS
   v_buff_app_amt                           buffer_header.buff_app_amt%type:=pre_auth_pkg.get_buff_apr_amt(v_pat_gen_detail_seq_id,'PAT','CORP_BUFF') ;
   v_med_buff_app_amt                       buffer_header.buff_app_amt%type:=pre_auth_pkg.get_buff_apr_amt(v_pat_gen_detail_seq_id,'PAT','MED_BUFF') ;	
   v_crit_buff_app_amt                      buffer_header.buff_app_amt%type:=pre_auth_pkg.get_buff_apr_amt(v_pat_gen_detail_seq_id,'PAT','CRIT_BUFF') ;
   v_crit_corp_buff_app_amt                 buffer_header.buff_app_amt%type:=pre_auth_pkg.get_buff_apr_amt(v_pat_gen_detail_seq_id,'PAT','CRIT_CORP_BUFF') ;
   v_crit_med_buff_app_amt                  buffer_header.buff_app_amt%type:=pre_auth_pkg.get_buff_apr_amt(v_pat_gen_detail_seq_id,'PAT','CRIT_MED_BUFF') ;

     CURSOR preauth_cur IS
       SELECT
         B.pre_auth_number,
         D.description AS preauth_type,
         to_char(A.pat_received_date,'dd/mm/yyyy hh:mi AM') AS pat_received_date ,
         to_char(A.likely_date_of_hospitalization ,'dd/mm/yyyy hh:mi AM')  AS likely_date_of_hospitalization,
         A.prev_approved_amount ,
         A.pat_requested_amount ,
         A.treating_dr_name ,
         E.office_name,
         A.remarks ,
         G.tpa_enrollment_id,
         G.mem_name ,
         B.policy_number,
         I.ins_comp_name,
         J.product_name,
         B.insured_name,
         B.Phone_1,
         a.phone_no_in_hospitalisation ,
         k.description AS ins_term_status,
         L.enrol_description,
         M.Description AS policy_sub_type,
         TO_CHAR(b.policy_effective_from ,'DD/MM/YYYY') AS policy_effective_from,
         TO_CHAR(b.policy_effective_to ,'DD/MM/YYYY') AS policy_effective_to,
         pre_auth_pkg.get_available_sum(A.PAT_GEN_DETAIL_SEQ_ID,NULL,'SUM') AS ava_sum_insured,
--         a.ava_sum_insured ,
         pre_auth_pkg.get_available_sum(A.PAT_GEN_DETAIL_SEQ_ID,NULL,'BONUS') AS ava_cum_bonus,
--         a.ava_cum_bonus ,
         A.app_cum_bonus ,
         --N.buffer_ava_amount ,
		 (SELECT * FROM (select buffer_ava_amount from  buffer_details b 
         where b.pat_gen_detail_seq_id=v_pat_gen_detail_seq_id
         ORDER BY b.buff_detail_seq_id ASC)
         WHERE ROWNUM=1) AS buffer_ava_amount,  
         NN2.pre_auth_buffer_app_amount AS buffer_app_amount ,
         to_char(N.buffer_approved_date ,'dd/mm/yyyy hh:mi AM') AS buffer_approved_date,
         O.hosp_name,
         O.rating ,
         O.empanel_number,
         Q.city_description,
         R.state_name,
         B.auth_number,
         b.mem_total_sum_insured ,
         A.total_app_amount,
         NVL(case when b.pat_status_general_type_id ='REJ' AND A.COMPLETED_YN='N' AND pii.pat_ins_status='INP' THEN ACCOUNT_INFO_PKG.get_gen_desc('INSR','G') ELSE v.description end , 'In-Progress') AS app_status,
         to_char( B.decision_date ,'dd/mm/yyyy hh:mi AM') AS completed_date ,
         W.contact_name,
         a.authorization_remarks AS app_remarks,
         X.description AS reason ,
         AN.provisional_diagnosis ,
         A.Pat_Enhanced_Yn ,
         a.likely_date_of_hospitalization + nvl(an.duration_of_hospitalization,0) AS probable_date_of_discharge              ,
         ev.event_name,
         (SELECT COUNT(1) FROM shortfall_details ss WHERE ss.pat_gen_detail_seq_id = a.pat_gen_detail_seq_id ) AS shortfall_count,
         DECODE(G.diabetes_cover_yn ,'Y','Yes','No') AS diabetes_cover_yn, --For KOC1010
         DECODE(G.hypertension_cover_yn ,'Y','Yes','No') AS hypertension_cover_yn, --For KOC1010
         F.zone_code, --For KOC1010
         v_buff_app_amt Buff_App_Amt,
         v_med_buff_app_amt Med_Buff_App_Amt,
         v_crit_buff_app_amt Crit_Buff_App_Amt,
         v_crit_corp_buff_app_amt Crit_Corp_Buff_App_Amt,
         v_crit_med_buff_app_amt Crit_Med_Buff_App_Amt,
          nvl(CASE WHEN nvl(b.claim_id,0)=0 then v_buff_app_amt else CASE WHEN nn2.pre_auth_buffer_app_amount>0 then CASE WHEN nvl(NN2.Utilised_Amount,0)< 0 THEN v_Buff_App_Amt + nvl(NN2.Utilised_Amount,0) ELSE NN2.Utilised_Amount end   else null end end,0) as Utilised_Amount,
         nvl(CASE WHEN nvl(b.claim_id,0)=0 then v_med_buff_app_amt else CASE WHEN nn2.pre_auth_buffer_app_amount>0 then CASE WHEN nvl(NN2.Utilised_Med_Amount,0)< 0 THEN v_Med_Buff_App_Amt + nvl(NN2.Utilised_Med_Amount,0) ELSE NN2.Utilised_Med_Amount end   else null end  end,0) as Utilised_Med_Amount,
         nvl(CASE WHEN nvl(b.claim_id,0)=0 then v_crit_buff_app_amt else CASE WHEN nn2.pre_auth_buffer_app_amount>0 then CASE WHEN nvl(NN2.Utilised_Crit_Amount,0)< 0 THEN v_Crit_Buff_App_Amt + nvl(NN2.Utilised_Crit_Amount,0) ELSE  NN2.Utilised_Crit_Amount end   else null end  end,0) as Utilised_Crit_Amount,
         nvl(CASE WHEN nvl(b.claim_id,0)=0 then v_crit_corp_buff_app_amt else CASE WHEN nn2.pre_auth_buffer_app_amount>0 then CASE WHEN nvl(NN2.Utilised_Crit_Corp_Amount,0)< 0 THEN v_Crit_Corp_Buff_App_Amt + nvl(NN2.Utilised_Crit_Corp_Amount,0) ELSE NN2.Utilised_Crit_Corp_Amount end   else null end  end,0) as Utilised_Crit_Corp_Amount,
         nvl(CASE WHEN nvl(b.claim_id,0)=0 then v_crit_med_buff_app_amt else CASE WHEN nn2.pre_auth_buffer_app_amount>0 then CASE WHEN nvl(NN2.Utilised_Crit_Med_Amount,0)< 0 THEN v_Crit_Med_Buff_App_Amt + nvl(NN2.Utilised_Crit_Med_Amount,0) ELSE NN2.Utilised_Crit_Med_Amount end   else null end  end,0) as Utilised_Crit_Med_Amount,
         v_buff_app_amt + v_med_buff_app_amt + v_crit_buff_app_amt + v_crit_corp_buff_app_amt + v_crit_med_buff_app_amt as apr_buff_amount,
         CASE WHEN nvl(b.claim_id,0)=0 
           then v_Buff_App_Amt+v_Med_Buff_App_Amt+v_Crit_Buff_App_Amt+
                v_Crit_Corp_Buff_App_Amt+v_Crit_Med_Buff_App_Amt 
           else CASE WHEN nn2.pre_auth_buffer_app_amount>0 then CASE WHEN nvl(NN2.Utilised_Amount,0)< 0 THEN nvl(NN2.Buff_App_Amt,0) + nvl(NN2.Utilised_Amount,0) ELSE nvl(NN2.Utilised_Amount,0) END  else 0 end +
                CASE WHEN nn2.pre_auth_buffer_app_amount>0 then CASE WHEN nvl(NN2.Utilised_Med_Amount,0)< 0 THEN nvl(NN2.Med_Buff_App_Amt,0) + nvl(NN2.Utilised_Med_Amount,0) ELSE  nvl(NN2.Utilised_Med_Amount,0) end else 0 end+ 
                CASE WHEN nn2.pre_auth_buffer_app_amount>0 then CASE WHEN nvl(NN2.Utilised_Crit_Amount,0)< 0 THEN nvl(NN2.Crit_Buff_App_Amt,0) + nvl(NN2.Utilised_Crit_Amount,0) ELSE  nvl(NN2.Utilised_Crit_Amount,0) end else 0 end+
                CASE WHEN nn2.pre_auth_buffer_app_amount>0 then CASE WHEN nvl(NN2.Utilised_Crit_Corp_Amount,0)< 0 THEN nvl(NN2.Crit_Corp_Buff_App_Amt,0) + nvl(NN2.Utilised_Crit_Corp_Amount,0) ELSE  nvl(NN2.Utilised_Crit_Corp_Amount,0) end else 0 end+ 
                CASE WHEN nn2.pre_auth_buffer_app_amount>0 then CASE WHEN nvl(NN2.Utilised_Crit_Med_Amount,0)< 0 THEN nvl(NN2.Crit_Med_Buff_App_Amt,0) + nvl(NN2.Utilised_Crit_Med_Amount,0) ELSE  nvl(NN2.Utilised_Crit_Med_Amount,0) end  else 0 end end as util_buffer_amount
    
  
	  
         FROM pat_general_details A JOIN pat_enroll_details B ON (A.pat_enroll_detail_seq_id = b.pat_enroll_detail_seq_id)
         left outer join pat_ins_intimation_details pii on (b.PAT_ENROLL_DETAIL_SEQ_ID= pii.pat_auth_seq_id)
         LEFT OUTER JOIN tpa_general_code D ON (A.pat_general_type_id = D.general_type_id)
         LEFT OUTER JOIN tpa_office_info E ON (b.tpa_office_seq_id = e.tpa_office_seq_id)
         LEFT OUTER JOIN tpa_enr_policy F ON (B.policy_seq_id=F.policy_seq_id) --For KOC1010
         LEFT OUTER JOIN tpa_enr_policy_member G ON (B.member_seq_id = G.member_seq_id)
         LEFT OUTER JOIN tpa_ins_info I ON (B.ins_seq_id = I.ins_seq_id)
         LEFT OUTER JOIN tpa_ins_product J ON (B.product_seq_id = J.product_seq_id)
         LEFT OUTER JOIN tpa_general_code K ON (b.ins_status_general_type_id = k.general_type_id)
         LEFT OUTER JOIN tpa_enrolment_type_code L ON (b.enrol_type_id = L.enrol_type_id)
         LEFT OUTER JOIN tpa_general_code M ON (b.policy_sub_general_type_id = M.general_type_id)
         LEFT OUTER JOIN buffer_details N ON (a.last_buffer_detail_seq_id = N.buff_detail_seq_id )
         LEFT OUTER JOIN buffer_header NN2 ON ( N.buffer_hdr_seq_id  = NN2.buffer_hdr_seq_id )
         LEFT OUTER JOIN tpa_hosp_info O ON (B.hosp_seq_id = O.hosp_seq_id)
         LEFT OUTER JOIN tpa_hosp_address P ON (O.hosp_seq_id = P.hosp_seq_id)
         LEFT OUTER JOIN tpa_city_code Q ON (P.city_type_id = Q.city_type_id)
         LEFT OUTER JOIN tpa_state_code R ON (P.state_type_id = R.state_type_id)
         LEFT OUTER JOIN assign_users T ON (a.last_assign_user_seq_id = T.assign_users_seq_id)
         LEFT OUTER JOIN tpa_general_code V ON (T.pat_status_general_type_id = V.general_type_id)
         LEFT OUTER JOIN tpa_user_contacts W ON (T.assigned_to_user = W.contact_seq_id)
         LEFT OUTER JOIN tpa_general_code X ON (T.rson_general_type_id = X.general_type_id)
         LEFT OUTER JOIN ailment_details AN ON (A.pat_gen_detail_seq_id = AN.pat_gen_detail_seq_id)
         LEFT OUTER JOIN tpa_event ev ON (A.event_seq_id = ev.event_seq_id)
         LEFT OUTER JOIN tpa_general_code tg on (n.claim_type=tg.general_type_id)
         LEFT OUTER JOIN tpa_general_code tc on (n.buffer_type=tc.general_type_id)
         WHERE A.pat_gen_detail_seq_id = v_pat_gen_detail_seq_id ;

    CURSOR icd_pcs_cur IS SELECT
      A.icd_pcs_seq_id,
      A.ped_code_id,
      NVL(c.ped_description,'Others - '||A.other_desc) AS ailment_desc ,
      A.icd_code,
      A.primary_ailment_yn,
      NULL AS pkg_rate ,
      G.maximum_allowed_amount AS validated_amt,
      G.approved_amount AS itemized_app_amount,
      D.proc_seq_id,
      D.pkg_seq_id,
      a.hospital_general_type_id ,
      H.description AS hospitalization_type ,
      A.frequency_of_visit ,
      A.no_of_visits ,
      DECODE (a.pat_duration_general_type_id,'DTD','Days','DTW','Weeks','DTM','Months','Years') AS duration,
      NVL(E.NAME ,F.proc_description) AS NAME
      FROM icd_pcs_detail A LEFT OUTER JOIN tpa_ped_code C ON (A.ped_code_id = C.ped_code_id)
      LEFT OUTER JOIN pat_package_procedures D ON ( A.icd_pcs_seq_id = D.icd_pcs_seq_id )
      LEFT OUTER JOIN tpa_hosp_tariff_item E ON (d.pkg_seq_id = e.pkg_seq_id)
      LEFT OUTER JOIN tpa_hosp_procedure_code F ON (D.proc_seq_id = F.proc_seq_id)
      LEFT OUTER JOIN ailment_caps G ON ( a.icd_pcs_seq_id = G.icd_pcs_seq_id )
      LEFT OUTER JOIN tpa_general_code H ON (a.hospital_general_type_id = h.general_type_id)
      WHERE A.pat_gen_detail_seq_id  = v_pat_gen_detail_seq_id  ORDER BY A.icd_pcs_seq_id ;

    CURSOR narration_cur IS SELECT
     A.reference_date,
     A.remarks,
     B.contact_name
     FROM pat_log A JOIN tpa_user_contacts B ON (a.added_by = b.contact_seq_id)
     WHERE pat_gen_detail_seq_id = v_pat_gen_detail_seq_id AND pat_log_general_type_id = 'NAR';

      v_rec_user                   preauth_cur%ROWTYPE;
      v_prev_icd_rec               icd_pcs_cur%ROWTYPE;
      rec                          icd_pcs_cur%ROWTYPE;
      v_preauth_doc        DBMS_XMLDOM.DOMDocument;
      v_preauth_root_node  DBMS_XMLDOM.DOMNode;
      v_elem               DBMS_XMLDOM.DOMElement;
      v_elem1              DBMS_XMLDOM.DOMElement;
      v_node               DBMS_XMLDOM.DOMNode;
      v_parent_node        DBMS_XMLDOM.DOMNODE;
      v_root_node          DBMS_XMLDOM.DOMNode;
      v_ctr                NUMBER := 1 ;
      v_flag               CHAR(1) := 'N';
      v_name               VARCHAR2(2000);
--      v_buf                VARCHAR2(10000);
   BEGIN
      OPEN preauth_cur;
      FETCH preauth_cur INTO v_rec_user;
      CLOSE preauth_cur;

      v_preauth_doc := dbms_xmldom.newDOMDocument;
      dbms_xmldom.setVersion( v_preauth_doc, '1.0' );
      v_preauth_root_node := dbms_xmldom.makeNode(v_preauth_doc);

      v_elem := dbms_xmldom.createElement( v_preauth_doc, 'preauthorizationhistory' );
      v_node := dbms_xmldom.makeNode( v_elem );
      v_preauth_root_node := dbms_xmldom.appendChild( v_preauth_root_node, v_node );
---
      v_elem := dbms_xmldom.createElement(v_preauth_doc, 'preauthorizationdetails');
      dbms_xmldom.setAttribute(v_elem,'preauthnumber',v_rec_user.pre_auth_number);
      dbms_xmldom.setAttribute(v_elem,'preauthtype',v_rec_user.preauth_type);
      dbms_xmldom.setAttribute(v_elem,'recieveddate',v_rec_user.pat_received_date);
      dbms_xmldom.setAttribute(v_elem,'admissiondate',v_rec_user.likely_date_of_hospitalization);
      dbms_xmldom.setAttribute(v_elem,'prevapprovedamount',v_rec_user.prev_approved_amount);
      dbms_xmldom.setAttribute(v_elem,'requestedamount',v_rec_user.pat_requested_amount);
      dbms_xmldom.setAttribute(v_elem,'treatingdoctorname',v_rec_user.treating_dr_name);
      dbms_xmldom.setAttribute(v_elem,'ttkbranch',v_rec_user.office_name);
      dbms_xmldom.setAttribute(v_elem,'remarks',v_rec_user.Remarks);
      dbms_xmldom.setAttribute(v_elem,'enhanced',CASE WHEN v_rec_user.pat_enhanced_yn = 'Y' THEN 'Yes' ELSE 'No' END);
      dbms_xmldom.setAttribute(v_elem,'dateofdischarge', TO_CHAR(v_rec_user.probable_date_of_discharge,'DD/MM/YYYY'));
      dbms_xmldom.setAttribute(v_elem,'workflow', v_rec_user.event_name);

      v_node := dbms_xmldom.makeNode(v_elem);
      v_parent_node := dbms_xmldom.appendChild( v_preauth_root_node, v_node);
--------
      v_elem := dbms_xmldom.createElement(v_preauth_doc, 'shortfall');
      dbms_xmldom.setAttribute( v_elem,'shortfall',CASE WHEN v_rec_user.shortfall_count > 0 THEN 'Y' ELSE 'N' END);
      dbms_xmldom.setAttribute( v_elem, 'seq_id', v_pat_gen_detail_seq_id);
      v_node := dbms_xmldom.makeNode(v_elem);
      v_parent_node := dbms_xmldom.appendChild( v_preauth_root_node, v_node);
--------

      v_elem := dbms_xmldom.createElement(v_preauth_doc, 'claimantdetails');
      dbms_xmldom.setAttribute(v_elem,'enrollmentid',v_rec_user.tpa_enrollment_id);
      dbms_xmldom.setAttribute(v_elem,'claimantname',v_rec_user.mem_name);
      dbms_xmldom.setAttribute(v_elem,'diabetes_cover_yn',v_rec_user.diabetes_cover_yn); --For KOC1010
      dbms_xmldom.setAttribute(v_elem,'hypertension_cover_yn',v_rec_user.hypertension_cover_yn); --For KOC1010
      dbms_xmldom.setAttribute(v_elem,'totalappbufferamount',v_rec_user.apr_buff_amount );
      dbms_xmldom.setAttribute(v_elem,'totalutilbufferamount',v_rec_user.util_buffer_amount );
      v_node := dbms_xmldom.makeNode(v_elem);
      v_parent_node := dbms_xmldom.appendChild( v_preauth_root_node, v_node);
-------------

      v_elem := dbms_xmldom.createElement(v_preauth_doc, 'policydetails');
      dbms_xmldom.setAttribute(v_elem,'policynumber',v_rec_user.policy_number);
      dbms_xmldom.setAttribute(v_elem,'inscompname',v_rec_user.ins_comp_name);
      dbms_xmldom.setAttribute(v_elem,'policyholder',v_rec_user.insured_name);
      dbms_xmldom.setAttribute(v_elem,'phone',v_rec_user.phone_1);
      dbms_xmldom.setAttribute(v_elem,'productname',v_rec_user.product_name);
      dbms_xmldom.setAttribute(v_elem,'termstatus',v_rec_user.ins_term_status);
      dbms_xmldom.setAttribute(v_elem,'policytype',v_rec_user.enrol_description);
      dbms_xmldom.setAttribute(v_elem,'policysubtype',v_rec_user.policy_sub_type);
      dbms_xmldom.setAttribute(v_elem,'startdate',v_rec_user.policy_effective_from);
      dbms_xmldom.setAttribute(v_elem,'enddate',v_rec_user.policy_effective_to);      
      dbms_xmldom.setAttribute(v_elem,'availablebonus',v_rec_user.ava_cum_bonus);
      dbms_xmldom.setAttribute(v_elem,'zonecode',v_rec_user.zone_code);

      v_node := dbms_xmldom.makeNode(v_elem);
      v_parent_node := dbms_xmldom.appendChild( v_preauth_root_node, v_node);

-----------
      v_elem := dbms_xmldom.createElement(v_preauth_doc, 'icdpcscodingdetails');
      v_node := dbms_xmldom.makeNode(v_elem);
      v_root_node := dbms_xmldom.appendChild( v_preauth_root_node, v_node);

      v_elem := dbms_xmldom.createElement(v_preauth_doc, 'provisionaldiagnosis');
      dbms_xmldom.setAttribute(v_elem,'description',v_rec_user.Provisional_Diagnosis);
      v_node := dbms_xmldom.makeNode(v_elem);
      v_parent_node := dbms_xmldom.appendChild( v_root_node, v_node);

     OPEN icd_pcs_cur;
     FETCH icd_pcs_cur INTO rec;
     WHILE icd_pcs_cur%FOUND
     LOOP
        IF v_prev_icd_rec.icd_pcs_seq_id IS NULL THEN
           v_prev_icd_rec := rec;
           v_name := rec.NAME;
           v_flag := 'Y';
        ELSE
          IF rec.icd_pcs_seq_id = v_prev_icd_rec.icd_pcs_seq_id THEN
            v_name := v_name ||','|| rec.NAME;
          ELSE
            v_elem := dbms_xmldom.createElement(v_preauth_doc, 'record');
            dbms_xmldom.setAttribute(v_elem,'id',v_ctr);
            dbms_xmldom.setAttribute(v_elem,'ailment',v_prev_icd_rec.ailment_desc);
            dbms_xmldom.setAttribute(v_elem,'icdcode',v_prev_icd_rec.icd_code);
            dbms_xmldom.setAttribute(v_elem,'pckageorprocedure',v_name);
            dbms_xmldom.setAttribute(v_elem,'packagerate',v_prev_icd_rec.pkg_rate);
            dbms_xmldom.setAttribute(v_elem,'validatedamount',v_prev_icd_rec.validated_amt);
            dbms_xmldom.setAttribute(v_elem,'approvedamount',v_prev_icd_rec.itemized_app_amount);
            dbms_xmldom.setAttribute(v_elem,'hospitalizationtype',v_prev_icd_rec.hospital_general_type_id);
            dbms_xmldom.setAttribute(v_elem,'hospitalizationdescription',v_prev_icd_rec.hospitalization_type);
            dbms_xmldom.setAttribute(v_elem,'frequency','(Freq :'||v_prev_icd_rec.frequency_of_visit||' '||v_prev_icd_rec.duration ||') (No.:'||v_prev_icd_rec.no_of_visits||')');
            v_node := dbms_xmldom.makeNode(v_elem);
            v_parent_node := dbms_xmldom.appendChild( v_root_node, v_node);
            v_prev_icd_rec := rec;
            v_name := rec.NAME;
            v_ctr := v_ctr + 1;
          END IF;
        END IF;
        FETCH icd_pcs_cur INTO rec;
      END LOOP;
      IF v_flag = 'Y' THEN
        v_elem := dbms_xmldom.createElement(v_preauth_doc, 'record');
        dbms_xmldom.setAttribute(v_elem,'id',v_ctr);
        dbms_xmldom.setAttribute(v_elem,'ailment',rec.ailment_desc);
        dbms_xmldom.setAttribute(v_elem,'icdcode',rec.icd_code);
        dbms_xmldom.setAttribute(v_elem,'pckageorprocedure',v_name);
        dbms_xmldom.setAttribute(v_elem,'packagerate',rec.pkg_rate);
        dbms_xmldom.setAttribute(v_elem,'validatedamount',rec.validated_amt);
        dbms_xmldom.setAttribute(v_elem,'approvedamount',rec.itemized_app_amount);
        dbms_xmldom.setAttribute(v_elem,'hospitalizationtype',rec.hospital_general_type_id);
        dbms_xmldom.setAttribute(v_elem,'hospitalizationdescription',rec.hospitalization_type);
        dbms_xmldom.setAttribute(v_elem,'frequency','(Freq :'||rec.frequency_of_visit||' '||rec.duration ||') (No.:'||rec.no_of_visits||')');
        v_node := dbms_xmldom.makeNode(v_elem);
        v_parent_node := dbms_xmldom.appendChild( v_root_node, v_node);
      END IF;
      CLOSE icd_pcs_cur;
------------
      v_elem := dbms_xmldom.createElement(v_preauth_doc, 'hospitaldetails');
      dbms_xmldom.setAttribute(v_elem,'hospitalname',v_rec_user.hosp_name);
      dbms_xmldom.setAttribute(v_elem,'hospitalgrade',v_rec_user.rating);
      dbms_xmldom.setAttribute(v_elem,'empanelnumber',v_rec_user.empanel_number);
      dbms_xmldom.setAttribute(v_elem,'city',v_rec_user.city_description);
      dbms_xmldom.setAttribute(v_elem,'state',v_rec_user.state_name);
      v_node := dbms_xmldom.makeNode(v_elem);
      v_parent_node := dbms_xmldom.appendChild( v_preauth_root_node, v_node);
------------

      v_elem := dbms_xmldom.createElement(v_preauth_doc, 'authorizationdetails');
      dbms_xmldom.setAttribute(v_elem,'authoriztionnumber',v_rec_user.auth_number);
      dbms_xmldom.setAttribute(v_elem,'totalsuminsured',v_rec_user.mem_total_sum_insured);
      dbms_xmldom.setAttribute(v_elem,'availablesuminsured',v_rec_user.ava_sum_insured);
      dbms_xmldom.setAttribute(v_elem,'availablebonus',v_rec_user.ava_cum_bonus);
      dbms_xmldom.setAttribute(v_elem,'requestedamount',v_rec_user.pat_requested_amount);
      dbms_xmldom.setAttribute(v_elem,'prevapprovedamount',v_rec_user.prev_approved_amount);
      dbms_xmldom.setAttribute(v_elem,'approvedamount',v_rec_user.total_app_amount);

      v_node := dbms_xmldom.makeNode(v_elem);
      v_parent_node := dbms_xmldom.appendChild( v_preauth_root_node, v_node);
-----------
      v_elem := dbms_xmldom.createElement(v_preauth_doc, 'bufferamount');
      dbms_xmldom.setAttribute(v_elem,'nrmlbufferamount',v_rec_user.buff_app_amt );
      dbms_xmldom.setAttribute(v_elem,'medbufferamount',v_rec_user.med_buff_app_amt );
      dbms_xmldom.setAttribute(v_elem,'critbufferamount',v_rec_user.crit_buff_app_amt );
      dbms_xmldom.setAttribute(v_elem,'critcorpbufferamount',v_rec_user.crit_corp_buff_app_amt );
      dbms_xmldom.setAttribute(v_elem,'critmedbufferamount',v_rec_user.crit_med_buff_app_amt );
      dbms_xmldom.setAttribute(v_elem,'utilbufferamount',v_rec_user.utilised_amount );
      dbms_xmldom.setAttribute(v_elem,'utilmedbufferamount',v_rec_user.utilised_med_amount );
      dbms_xmldom.setAttribute(v_elem,'utilcritbufferamount',v_rec_user.utilised_crit_amount );
      dbms_xmldom.setAttribute(v_elem,'utilcritcorpbufferamount',v_rec_user.utilised_crit_corp_amount );
      dbms_xmldom.setAttribute(v_elem,'utilcritmedbufferamount',v_rec_user.utilised_crit_med_amount );
     
      v_node := dbms_xmldom.makeNode(v_elem);
      v_parent_node := dbms_xmldom.appendChild( v_preauth_root_node, v_node);
---------
      v_elem := dbms_xmldom.createElement(v_preauth_doc, 'approvalstatus');
      dbms_xmldom.setAttribute(v_elem,'status',v_rec_user.app_status);
      dbms_xmldom.setAttribute(v_elem,'approvedby',v_rec_user.contact_name);
      dbms_xmldom.setAttribute(v_elem,'approveddate',v_rec_user.completed_date);
      dbms_xmldom.setAttribute(v_elem,'remarks',v_rec_user.app_remarks);
      dbms_xmldom.setAttribute(v_elem,'reason',v_rec_user.reason);

      v_node := dbms_xmldom.makeNode(v_elem);
      v_parent_node := dbms_xmldom.appendChild( v_preauth_root_node, v_node);
-------
      v_elem := dbms_xmldom.createElement(v_preauth_doc, 'narrationdetails');
      v_node := dbms_xmldom.makeNode(v_elem);
      v_root_node := dbms_xmldom.appendChild( v_preauth_root_node, v_node);

     v_ctr := 1;

     FOR nar_rec IN narration_cur
     LOOP
        v_elem := dbms_xmldom.createElement(v_preauth_doc, 'record');
        dbms_xmldom.setAttribute(v_elem,'id',v_ctr);
        dbms_xmldom.setAttribute(v_elem,'referencedate',nar_rec.reference_date);
        dbms_xmldom.setAttribute(v_elem,'remarks',nar_rec.remarks);
        dbms_xmldom.setAttribute(v_elem,'user',nar_rec.contact_name);
        v_node := dbms_xmldom.makeNode(v_elem);
        v_parent_node := dbms_xmldom.appendChild( v_root_node, v_node);
        v_ctr := v_ctr + 1;
      END LOOP;
      v_preauth_history_doc := dbms_xmldom.getxmltype(v_preauth_doc);

     dbms_xmldom.freeDocument(v_preauth_doc);
   END create_preauth_xml;
--======================================================================================================
  PROCEDURE create_claim_xml (
    v_claim_seq_id                          IN clm_general_details.claim_seq_id%TYPE,
    v_clm_enroll_detail_seq_id              IN clm_enroll_details.clm_enroll_detail_seq_id%TYPE,
    v_claim_history_doc                     OUT XMLTYPE
   )
   IS
     CURSOR pre_post_cur IS
       WITH bill_det AS ( SELECT b.bill_date, c.date_of_admission, c.date_of_discharge
         FROM clm_bill_header b JOIN clm_general_details c ON (b.claim_seq_id = c.claim_seq_id)
         WHERE b.claim_seq_id = v_claim_seq_id )
       SELECT (SELECT COUNT(1) FROM bill_det a WHERE trunc(a.bill_date) < trunc(a.date_of_admission)) AS pre_count,
              (SELECT COUNT(1) FROM bill_det a WHERE trunc(a.bill_date) > trunc(a.date_of_discharge)) AS post_count,
              (SELECT COUNT(1) FROM bill_det a WHERE trunc(a.bill_date) BETWEEN trunc(a.date_of_admission) AND trunc(a.date_of_discharge)) AS hosp_count
              FROM dual;
   v_buff_app_amt                           buffer_header.buff_app_amt%type:=pre_auth_pkg.get_buff_apr_amt(v_claim_seq_id,'CLM','CORP_BUFF') ;
   v_med_buff_app_amt                       buffer_header.buff_app_amt%type:=pre_auth_pkg.get_buff_apr_amt(v_claim_seq_id,'CLM','MED_BUFF') ;	
   v_crit_buff_app_amt                      buffer_header.buff_app_amt%type:=pre_auth_pkg.get_buff_apr_amt(v_claim_seq_id,'CLM','CRIT_BUFF') ;
   v_crit_corp_buff_app_amt                 buffer_header.buff_app_amt%type:=pre_auth_pkg.get_buff_apr_amt(v_claim_seq_id,'CLM','CRIT_CORP_BUFF') ;
   v_crit_med_buff_app_amt                  buffer_header.buff_app_amt%type:=pre_auth_pkg.get_buff_apr_amt(v_claim_seq_id,'CLM','CRIT_MED_BUFF') ;
	              


     CURSOR claim_cur IS
       SELECT
         A.claim_seq_id,
         b.tpa_enrollment_id,
         b.claimant_name,
         ab.description AS gender,
         b.mem_age,
         TO_CHAR(b.date_of_inception,'DD/MM/YYYY') AS date_of_inception ,
         TO_CHAR(b.date_of_exit,'DD/MM/YYYY') AS date_of_exit,
         b.mem_total_sum_insured ,
         --a.ava_sum_insured ,
         pre_auth_pkg.get_available_sum(NULL,A.CLAIM_SEQ_ID,'SUM') AS ava_sum_insured,
         --o.buffer_ava_amount ,
		 (SELECT * FROM (select buffer_ava_amount from  buffer_details b 
         where b.claim_seq_id=v_claim_seq_id
         ORDER BY b.buff_detail_seq_id ASC)
         WHERE ROWNUM=1) AS buffer_ava_amount,
         AR.pre_auth_buffer_app_amount ,
         p.claim_app_buffer_amount ,
         TO_CHAR( NVL(o.buffer_approved_date ,aq.buffer_approved_date), 'dd/mm/yyyy hh:mi AM' ) AS buffer_approved_date,
         --a.ava_cum_bonus,
         pre_auth_pkg.get_available_sum(NULL,A.CLAIM_SEQ_ID,'BONUS') AS ava_cum_bonus,
         b.employee_no,
         b.policy_holder_name,
         ac.relship_description ,
         b.claimant_phone_number ,
         a.claim_number,
         a.claim_file_number,
         ad.description AS request_type,
         d.description AS claim_type,
         ae.description AS claim_sub_type,
         TO_CHAR(ak.call_recorded_date,'dd/mm/yyyy hh:mi AM' ) AS intimation_date,
         af.description AS mode_type,
         TO_CHAR(c.rcvd_date,'dd/mm/yyyy hh:mi AM' ) AS rcvd_date,
         a.requested_amount,
         a.treating_dr_name,
         a.in_patient_no,
         e.office_name,
--         ag.description AS source_type,
         z.contact_name,
         ah.office_name AS processing_branch,
         a.claims_remarks ,
         b.policy_number,
         i.ins_comp_name,
         b.phone_1 ,
         CASE WHEN b.ins_status_general_type_id = 'TPR' THEN 'Renewal' ELSE 'Fresh' END AS term_status,
         CASE WHEN b.enrol_type_id = 'IND' THEN 'Individual'
              WHEN b.enrol_type_id = 'ING' THEN 'Individual As Group'
              WHEN b.enrol_type_id = 'COR' THEN 'Corporate'
              WHEN b.enrol_type_id = 'NCR' THEN 'Non-Corporate' END AS policy_type,
         CASE WHEN b.policy_sub_general_type_id = 'PNF' THEN 'Non-Floater'
              WHEN b.policy_sub_general_type_id = 'PFL' THEN 'Floater'
              WHEN b.policy_sub_general_type_id = 'PFN' THEN 'Floater + Non-Floater'
              WHEN b.policy_sub_general_type_id = 'PFL' THEN 'Floater with Restriction' END AS policy_sub_type,
         TO_CHAR(b.policy_effective_from,'DD/MM/YYYY') AS policy_effective_from,
         TO_CHAR(b.policy_effective_to,'DD/MM/YYYY') AS policy_effective_to,
         NVL(s.hosp_name,q.hosp_name ) AS hosp_name ,
         s.empanel_number ,
         NVL(U.city_description , q.city_name ) AS city_name ,
         NVL(v.state_name , q.state_name ) AS state_name ,
         s.rating ,
         a.claim_settlement_number ,
         a.total_app_amount,
         ai.max_allowed_amount ,
         a.pat_approved_amount ,
         case when clm_status_general_type_id ='REJ'  AND A.COMPLETED_YN='N' AND cii.CLM_INS_STATUS='INP' THEN ACCOUNT_INFO_PKG.get_gen_desc('INSR','G') ELSE k.description end AS status,
         a.permission_sought_from,
         TO_CHAR(b.decision_date,'dd/mm/yyyy hh:mi AM' ) AS decision_date,
         aj.description AS reason_type,
         x.remarks ,
         am.product_name,
         AN.provisional_diagnosis,
         TO_CHAR(a.date_of_admission,'dd/mm/yyyy HH:MI AM') AS date_of_admission,
         TO_CHAR(a.date_of_discharge,'dd/mm/yyyy HH:MI AM') AS date_of_discharge,
         (SELECT COUNT(1) FROM shortfall_details ss WHERE ss.claim_seq_id = a.claim_seq_id ) AS shortfall_count,
         AL.Zone_Code, --For KOC1010
         DECODE(G.diabetes_cover_yn ,'Y','Yes','No') AS diabetes_cover_yn, --For KOC1010
         CASE WHEN I.INS_COMP_NAME LIKE 'CIGNA%' AND I.NOTIFY_TYPE_ID='NIC' AND C.CLAIM_GENERAL_TYPE_ID='CTM'  THEN 'Y' ELSE 'N' END AS CIGNA_YN, --koc_ins_mail
         tgc.description as pay_to, --opdforhs
         DECODE(G.hypertension_cover_yn ,'Y','Yes','No') AS hypertension_cover_yn, --For KOC1010,
         v_buff_app_amt Buff_App_Amt,
         v_med_buff_app_amt Med_Buff_App_Amt,
         v_crit_buff_app_amt Crit_Buff_App_Amt,
         v_crit_corp_buff_app_amt Crit_Corp_Buff_App_Amt,
         v_crit_med_buff_app_amt Crit_Med_Buff_App_Amt,   
         nvl(nvl(p.Utilised_Amount,ar.Utilised_Amount),0) AS Utilised_Amount,
         nvl(nvl(p.Utilised_Med_Amount,ar.Utilised_Med_Amount),0) AS Utilised_Med_Amount,
         nvl(nvl(p.Utilised_Crit_Amount,ar.Utilised_Crit_Amount),0) AS Utilised_Crit_Amount,
         nvl(nvl(p.Utilised_Crit_Corp_Amount,ar.Utilised_Crit_Corp_Amount),0) AS Utilised_Crit_Corp_Amount,
         nvl(nvl(p.Utilised_Crit_Med_Amount,ar.Utilised_Crit_Med_Amount),0) AS Utilised_Crit_Med_Amount,
         v_buff_app_amt + v_med_buff_app_amt + v_crit_buff_app_amt + v_crit_corp_buff_app_amt + v_crit_med_buff_app_amt AS apr_buff_amount,
         nvl(nvl(p.Utilised_Amount,ar.Utilised_Amount),0)+nvl(nvl(p.Utilised_Med_Amount,ar.Utilised_Med_Amount),0)+nvl(nvl(p.Utilised_Crit_Amount,ar.Utilised_Crit_Amount),0)+
         nvl(nvl(p.Utilised_Crit_Corp_Amount,ar.Utilised_Crit_Corp_Amount),0)+nvl( nvl(p.Utilised_Crit_Med_Amount,ar.Utilised_Crit_Med_Amount),0) AS util_buff_amount


         FROM clm_general_details A JOIN clm_enroll_details B ON ( A.claim_seq_id = b.claim_seq_id )
         JOIN clm_inward C ON ( a.claims_inward_seq_id = c.claims_inward_seq_id )
         LEFT OUTER JOIN clm_ins_intimation_details cii on (a.claim_seq_id=cii.claim_seq_id)
         LEFT OUTER JOIN tpa_general_code D ON ( C.claim_general_type_id = D.general_type_id )
         LEFT OUTER JOIN tpa_office_info E ON (C.tpa_office_seq_id = e.tpa_office_seq_id)
         LEFT OUTER JOIN tpa_enr_policy_member G ON (B.member_seq_id = G.member_seq_id)
         LEFT OUTER JOIN tpa_ins_info I ON (B.ins_seq_id = I.ins_seq_id)
         LEFT OUTER JOIN tpa_general_code K ON (b.clm_status_general_type_id = k.general_type_id)
         LEFT OUTER JOIN buffer_details O ON (a.last_buffer_detail_seq_id = o.buff_detail_seq_id )
         LEFT OUTER JOIN buffer_header P ON (o.buffer_hdr_seq_id  = p.buffer_hdr_seq_id )
         LEFT OUTER JOIN clm_hospital_association Q ON ( A.claim_seq_id = Q.claim_seq_id )
         LEFT OUTER JOIN tpa_hosp_info S ON (Q.hosp_seq_id = S.hosp_seq_id)
         LEFT OUTER JOIN tpa_hosp_address T ON (S.hosp_seq_id = T.hosp_seq_id)
         LEFT OUTER JOIN tpa_city_code U ON (T.city_type_id = U.city_type_id)
         LEFT OUTER JOIN tpa_state_code V ON (T.state_type_id = V.state_type_id)
         LEFT OUTER JOIN assign_users X ON (a.last_assign_user_seq_id  = X.assign_users_seq_id)
         LEFT OUTER JOIN tpa_general_code Y ON (X.pat_status_general_type_id = Y.general_type_id)
         LEFT OUTER JOIN tpa_user_contacts Z ON (X.assigned_to_user = Z.contact_seq_id)
         LEFT OUTER JOIN tpa_general_code AA ON (X.Rson_General_Type_Id = AA.general_type_id)
         LEFT OUTER JOIN tpa_general_code AB ON (b.gender_general_type_id = ab.general_type_id )
         LEFT OUTER JOIN tpa_relationship_code AC ON (b.relship_type_id = AC.relship_type_id )
         LEFT OUTER JOIN tpa_general_code AD ON ( C.document_general_type_id = ad.general_type_id )
         LEFT OUTER JOIN tpa_general_code AE ON ( A.claim_sub_general_type_id = AE.general_type_id )
         LEFT OUTER JOIN tpa_general_code AF ON ( A.mode_general_type_id  = AF.general_type_id )
         LEFT OUTER JOIN tpa_office_info ah ON ( z.tpa_office_seq_id = ah.tpa_office_seq_id )
         LEFT OUTER JOIN ( SELECT SUM(approved_amount) AS appr_amt, SUM(maximum_allowed_amount) AS max_allowed_amount , claim_seq_id
                           FROM ailment_caps XXX JOIN icd_pcs_detail YYY ON ( XXX.icd_pcs_seq_id = YYY.icd_pcs_seq_id ) WHERE YYY.claim_seq_id = v_claim_seq_id
                           GROUP BY claim_seq_id ) AI
                           ON ( A.claim_seq_id = AI.claim_seq_id )
         LEFT OUTER JOIN tpa_general_code aj ON ( x.rson_general_type_id = aj.general_type_id )
         LEFT OUTER JOIN tpa_call_log AK ON (a.call_log_seq_id = ak.call_log_seq_id )
         LEFT OUTER JOIN tpa_enr_policy AL ON (b.policy_seq_id = al.policy_seq_id)
         LEFT OUTER JOIN tpa_ins_product AM ON ( al.product_seq_id = am.product_seq_id )
         LEFT OUTER JOIN ailment_details AN ON (A.claim_seq_id = AN.claim_seq_id)
         LEFT OUTER JOIN pat_enroll_details AO ON (a.pat_enroll_detail_seq_id = AO.pat_enroll_detail_seq_id)
         LEFT OUTER JOIN pat_general_details AP ON (AO.pat_enroll_detail_seq_id = AP.pat_enroll_detail_seq_id)
         LEFT OUTER JOIN buffer_details AQ ON (AP.last_buffer_detail_seq_id = AQ.buff_detail_seq_id )
         LEFT OUTER JOIN buffer_header AR ON (AQ.buffer_hdr_seq_id  = AR.buffer_hdr_seq_id )
         LEFT OUTER JOIN tpa_claims_payment AT ON (a.claim_seq_id = AT.claim_seq_id)
         LEFT OUTER JOIN tpa_payment_checks_details AU ON (AT.payment_seq_id = AU.payment_seq_id)
         LEFT OUTER JOIN tpa_claims_check AV ON (AU.claims_chk_seq_id = AV.claims_chk_seq_id)
         LEFT OUTER JOIN tpa_general_code AW ON (AV.check_status = AW.general_type_id)
		     LEFT OUTER JOIN tpa_general_code tgc ON (tgc.general_type_id = a.pay_to_general_type_id)--opdforhs
         LEFT OUTER JOIN tpa_general_code tg ON (nvl(o.claim_type,aq.claim_type) = tg.general_type_id)
         LEFT OUTER JOIN tpa_general_code tc ON (nvl(o.buffer_type,aq.buffer_type) = tc.general_type_id)
         WHERE A.claim_seq_id  = v_claim_seq_id  ;

    CURSOR cheque_cur IS
         SELECT AW.description AS cheque_status,
         TO_CHAR(AV.check_date,'dd/mm/yyyy hh:mi AM') AS check_date,
         CASE WHEN AT.PAYEE_TYPE='EFT' THEN 'EFT-'||TO_CHAR(AV.check_num) ELSE TO_CHAR(AV.check_num)END AS check_num,--ADDED FOR KOC1103
         CASE WHEN AT.CLAIM_PAYMENT_STATUS='PAID' THEN AV.check_amount ELSE NULL END AS check_amount ,--ADDED FOR KOC1103
         (td.approved_amount - td.check_amount) AS tds_amount,
          ttk_util_pkg.fn_decrypt(AT.payee_name) as payee_name, --//ED
         TO_CHAR(av.despatch_date,'dd/mm/yyyy hh:mi AM') AS despatch_date ,
         av.consignment_no,
         av.provider_name
         FROM tpa_claims_payment AT LEFT OUTER JOIN tpa_payment_checks_details AU ON (AT.payment_seq_id = AU.payment_seq_id)
         LEFT OUTER JOIN tpa_claims_check AV ON (AU.claims_chk_seq_id = AV.claims_chk_seq_id)
         LEFT OUTER JOIN tpa_general_code AW ON (AV.check_status = AW.general_type_id)
         LEFT OUTER JOIN tpa_clm_tds_details td ON (td.claim_seq_id=AT.claim_seq_id)
         WHERE AT.claim_seq_id  = v_claim_seq_id  ;
    cheque_rec              cheque_cur%ROWTYPE;
    CURSOR icd_pcs_cur IS SELECT
      A.icd_pcs_seq_id,
      A.ped_code_id,
      NVL(c.ped_description,'Others - '||A.other_desc) AS ailment_desc ,
      A.icd_code,
      A.primary_ailment_yn,
      NULL AS pkg_rate ,
      G.maximum_allowed_amount AS validated_amt,
      G.approved_amount AS itemized_app_amount,
      D.proc_seq_id,
      D.pkg_seq_id,
      a.hospital_general_type_id ,
      H.description AS hospitalization_type ,
      A.frequency_of_visit ,
      A.no_of_visits ,
      DECODE (a.pat_duration_general_type_id,'DTD','Days','DTW','Weeks','DTM','Months','Years') AS duration,
      NVL(E.NAME ,F.proc_description) AS NAME
      FROM icd_pcs_detail A LEFT OUTER JOIN tpa_ped_code C ON (A.ped_code_id = C.ped_code_id)
      LEFT OUTER JOIN pat_package_procedures D ON ( A.icd_pcs_seq_id = D.icd_pcs_seq_id )
      LEFT OUTER JOIN tpa_hosp_tariff_item E ON (d.pkg_seq_id = e.pkg_seq_id)
      LEFT OUTER JOIN tpa_hosp_procedure_code F ON (D.proc_seq_id = F.proc_seq_id)
      LEFT OUTER JOIN ailment_caps G ON ( a.icd_pcs_seq_id = G.icd_pcs_seq_id )
      LEFT OUTER JOIN tpa_general_code H ON (a.hospital_general_type_id = h.general_type_id)
      WHERE A.claim_seq_id  = v_claim_seq_id  ORDER BY A.icd_pcs_seq_id ;

    CURSOR narration_cur IS SELECT
      A.reference_date,
      A.remarks,
      B.contact_name
      FROM pat_log A JOIN tpa_user_contacts B ON (a.added_by = b.contact_seq_id)
      WHERE A.claim_seq_id = v_claim_seq_id AND pat_log_general_type_id = 'NAR';


      v_rec_user                   claim_cur%ROWTYPE;
      v_prev_icd_rec               icd_pcs_cur%ROWTYPE;
      rec                          icd_pcs_cur%ROWTYPE;


      v_preauth_doc        DBMS_XMLDOM.DOMDocument;
      v_preauth_root_node  DBMS_XMLDOM.DOMNode;
      v_elem               DBMS_XMLDOM.DOMElement;
      v_node               DBMS_XMLDOM.DOMNode;
      v_parent_node        DBMS_XMLDOM.DOMNODE;
      v_root_node          DBMS_XMLDOM.DOMNode;
      v_ctr                NUMBER := 1 ;
      v_name               VARCHAR2(2000);
      v_flag               CHAR(1) := 'N';
      pre_post_rec         pre_post_cur%ROWTYPE;
      v_rej_amt_exist_YN   CHAR(1) :='N';
      v_chq_ctr            NUMBER := 1 ;

   BEGIN
      OPEN pre_post_cur;
      FETCH pre_post_cur INTO pre_post_rec;
      CLOSE pre_post_cur;

      OPEN claim_cur;
      FETCH claim_cur INTO v_rec_user;
      CLOSE claim_cur;

      -- To check for existance of disallow/rejected amount for a claim.
        SELECT COUNT(1) INTO v_chq_ctr
          FROM (SELECT sum(nvl(CBD.rejected_amount,0)) rejected_amt
                  FROM clm_bill_header CBH
                       JOIN clm_bill_details CBD ON (CBH.clm_bill_seq_id = CBD.clm_bill_seq_id)
                       JOIN clm_enroll_details CGD ON (CBH.Claim_seq_id = CGD.claim_seq_id)
                    WHERE CGD.clm_status_general_type_id != 'REJ'
                      AND CGD.Claim_seq_id =  v_claim_seq_id )
              WHERE nvl(rejected_amt,0) > 0 ;

        IF v_chq_ctr > 0 THEN v_rej_amt_exist_YN := 'Y'; ELSE v_rej_amt_exist_YN := 'N';  END IF;

      v_preauth_doc := dbms_xmldom.newDOMDocument;
      dbms_xmldom.setVersion( v_preauth_doc, '1.0' );
      v_preauth_root_node := dbms_xmldom.makeNode(v_preauth_doc);

      v_elem := dbms_xmldom.createElement( v_preauth_doc, 'claimshistory' );
      v_node := dbms_xmldom.makeNode( v_elem );
      v_preauth_root_node := dbms_xmldom.appendChild( v_preauth_root_node, v_node );
---
      v_elem := dbms_xmldom.createElement(v_preauth_doc, 'claimantdetails');
      dbms_xmldom.setAttribute(v_elem,'enrollmentid',v_rec_user.tpa_enrollment_id);
      dbms_xmldom.setAttribute(v_elem,'claimantname',v_rec_user.claimant_name);
      dbms_xmldom.setAttribute(v_elem,'gender',v_rec_user.gender);
      dbms_xmldom.setAttribute(v_elem,'age',v_rec_user.mem_age);
      dbms_xmldom.setAttribute(v_elem,'dateofinception',v_rec_user.date_of_inception);
      dbms_xmldom.setAttribute(v_elem,'dateofexit',v_rec_user.date_of_exit);
      dbms_xmldom.setAttribute(v_elem,'totalsuminsured',v_rec_user.mem_total_sum_insured);
      dbms_xmldom.setAttribute(v_elem,'totalappbufferamount',v_rec_user.apr_buff_amount );
      dbms_xmldom.setAttribute(v_elem,'totalutilbufferamount',v_rec_user.util_buff_amount );
      dbms_xmldom.setAttribute(v_elem,'availablesum',v_rec_user.ava_sum_insured);
      dbms_xmldom.setAttribute(v_elem,'availablebonus',v_rec_user.ava_cum_bonus);
      dbms_xmldom.setAttribute(v_elem,'employeeno',v_rec_user.employee_no);
      dbms_xmldom.setAttribute(v_elem,'employeename',v_rec_user.policy_holder_name);
      dbms_xmldom.setAttribute(v_elem,'relationship',v_rec_user.relship_description);
      dbms_xmldom.setAttribute(v_elem,'claimantphone',v_rec_user.claimant_phone_number);
      dbms_xmldom.setAttribute(v_elem,'rejectamtexist',v_rej_amt_exist_YN);   -- added for KOC702
      dbms_xmldom.setAttribute(v_elem,'diabetes_cover_yn',v_rec_user.diabetes_cover_yn);  --For KOC1010
      dbms_xmldom.setAttribute(v_elem,'hypertension_cover_yn',v_rec_user.hypertension_cover_yn);  --For KOC1010
	  dbms_xmldom.setAttribute(v_elem,'cigna_yn',v_rec_user.cigna_yn);  --koc_ins_mail
      v_node := dbms_xmldom.makeNode(v_elem);
      v_parent_node := dbms_xmldom.appendChild( v_preauth_root_node, v_node);
--------

      v_elem := dbms_xmldom.createElement(v_preauth_doc, 'claimdetails');
      dbms_xmldom.setAttribute(v_elem,'claimnumber', v_rec_user.claim_number);
      dbms_xmldom.setAttribute(v_elem,'claimfileno', v_rec_user.claim_file_number);
      dbms_xmldom.setAttribute(v_elem,'requesttype', v_rec_user.request_type);
      dbms_xmldom.setAttribute(v_elem,'claimtype', v_rec_user.claim_type);
      dbms_xmldom.setAttribute(v_elem,'claimsubtype',v_rec_user.claim_sub_type);
	  dbms_xmldom.setAttribute(v_elem,'paymentto',v_rec_user.pay_to);--opdforhs
      dbms_xmldom.setAttribute(v_elem,'intimationdate',v_rec_user.intimation_date);
      dbms_xmldom.setAttribute(v_elem,'mode',v_rec_user.mode_type);
      dbms_xmldom.setAttribute(v_elem,'rcvddate',v_rec_user.rcvd_date);
      dbms_xmldom.setAttribute(v_elem,'requestedamount',v_rec_user.requested_amount);
      dbms_xmldom.setAttribute(v_elem,'doctorname',v_rec_user.treating_dr_name);
      dbms_xmldom.setAttribute(v_elem,'inpatiantname',v_rec_user.in_patient_no);
      dbms_xmldom.setAttribute(v_elem,'ttkbranch',v_rec_user.office_name);
      dbms_xmldom.setAttribute(v_elem,'assignedto',v_rec_user.contact_name);
      dbms_xmldom.setAttribute(v_elem,'processingbranch',v_rec_user.processing_branch);
      dbms_xmldom.setAttribute(v_elem,'dateofadmission',v_rec_user.date_of_admission);
      dbms_xmldom.setAttribute(v_elem,'dateofdischarge',v_rec_user.date_of_discharge);
      dbms_xmldom.setAttribute(v_elem,'claimsremarks',v_rec_user.claims_remarks);
      dbms_xmldom.setAttribute(v_elem,'prehospitalization',pre_post_rec.pre_count); -- if > 0 means Yes Else No.
      dbms_xmldom.setAttribute(v_elem,'posthospitalization',pre_post_rec.post_count);-- if > 0 means Yes Else No.
      dbms_xmldom.setAttribute(v_elem,'hospitalization',pre_post_rec.hosp_count );-- if > 0 means Yes Else No.
      dbms_xmldom.setAttribute(v_elem,'settlementnumber',v_rec_user.claim_settlement_number);
      dbms_xmldom.setAttribute( v_elem, 'claimseqid', v_claim_seq_id);

      v_node := dbms_xmldom.makeNode(v_elem);
      v_parent_node := dbms_xmldom.appendChild( v_preauth_root_node, v_node);

      v_elem := dbms_xmldom.createElement(v_preauth_doc, 'chequeinformation');
      v_node := dbms_xmldom.makeNode(v_elem);
      v_root_node := dbms_xmldom.appendChild( v_preauth_root_node, v_node);

      v_elem := dbms_xmldom.createElement(v_preauth_doc, 'shortfall');
      dbms_xmldom.setAttribute( v_elem,'shortfall',CASE WHEN v_rec_user.shortfall_count > 0 THEN 'Y' ELSE 'N' END); -- added for KOC702
      dbms_xmldom.setAttribute( v_elem, 'seq_id', v_claim_seq_id);
      v_node := dbms_xmldom.makeNode(v_elem);
      v_parent_node := dbms_xmldom.appendChild( v_preauth_root_node, v_node);
--------

      OPEN cheque_cur;
      FETCH cheque_cur INTO cheque_rec;
      WHILE cheque_cur%FOUND
      LOOP
        v_elem := dbms_xmldom.createElement(v_preauth_doc, 'record');
        dbms_xmldom.setAttribute(v_elem,'id', v_ctr);
        dbms_xmldom.setAttribute(v_elem,'checknumber',cheque_rec.check_num);
        dbms_xmldom.setAttribute(v_elem,'checkdate',cheque_rec.check_date);
        dbms_xmldom.setAttribute(v_elem,'checkamount',cheque_rec.check_amount);
        dbms_xmldom.setAttribute(v_elem,'tdsamount',cheque_rec.tds_amount);
        dbms_xmldom.setAttribute(v_elem,'chequestatus',cheque_rec.cheque_status);
        dbms_xmldom.setAttribute(v_elem,'payeename',cheque_rec.payee_name);
        dbms_xmldom.setAttribute(v_elem,'consignmentno',cheque_rec.consignment_no);
        dbms_xmldom.setAttribute(v_elem,'providername',cheque_rec.provider_name);
        dbms_xmldom.setAttribute(v_elem,'despatchdate',cheque_rec.despatch_date);    
        v_node := dbms_xmldom.makeNode(v_elem);
        v_parent_node := dbms_xmldom.appendChild( v_root_node, v_node);
        FETCH cheque_cur INTO cheque_rec;
        v_ctr := v_ctr + 1;
      END LOOP;
-------------

      v_elem := dbms_xmldom.createElement(v_preauth_doc, 'policydetails');
      dbms_xmldom.setAttribute(v_elem,'policynumber',v_rec_user.policy_number);
      dbms_xmldom.setAttribute(v_elem,'inscompname',v_rec_user.ins_comp_name);
      dbms_xmldom.setAttribute(v_elem,'policyholder',v_rec_user.policy_holder_name);
      dbms_xmldom.setAttribute(v_elem,'phone',v_rec_user.phone_1);
      dbms_xmldom.setAttribute(v_elem,'termstatus',v_rec_user.term_status);
      dbms_xmldom.setAttribute(v_elem,'policytype',v_rec_user.policy_type);
      dbms_xmldom.setAttribute(v_elem,'policysubtype',v_rec_user.policy_sub_type);
      dbms_xmldom.setAttribute(v_elem,'startdate',v_rec_user.policy_effective_from);
      dbms_xmldom.setAttribute(v_elem,'enddate',v_rec_user.policy_effective_to);      
      dbms_xmldom.setAttribute(v_elem,'availablebonus',v_rec_user.ava_cum_bonus);
      dbms_xmldom.setAttribute(v_elem,'productname',v_rec_user.product_name);
      dbms_xmldom.setAttribute(v_elem,'zonecode',v_rec_user.zone_code);  --For KOC1010
      v_node := dbms_xmldom.makeNode(v_elem);
      v_parent_node := dbms_xmldom.appendChild( v_preauth_root_node, v_node);

-----------
      v_elem := dbms_xmldom.createElement(v_preauth_doc, 'icdpcscodingdetails');
      v_node := dbms_xmldom.makeNode(v_elem);
      v_root_node := dbms_xmldom.appendChild( v_preauth_root_node, v_node);

      v_elem := dbms_xmldom.createElement(v_preauth_doc, 'provisionaldiagnosis');
      dbms_xmldom.setAttribute(v_elem,'description',v_rec_user.Provisional_Diagnosis);
      v_node := dbms_xmldom.makeNode(v_elem);
      v_parent_node := dbms_xmldom.appendChild( v_root_node, v_node);

     v_ctr := 1;
     OPEN icd_pcs_cur;
     FETCH icd_pcs_cur INTO rec;
     WHILE icd_pcs_cur%FOUND
     LOOP
        IF v_prev_icd_rec.icd_pcs_seq_id IS NULL THEN
           v_prev_icd_rec := rec;
           v_name := rec.NAME;
           v_flag := 'Y';
        ELSE
          IF rec.icd_pcs_seq_id = v_prev_icd_rec.icd_pcs_seq_id THEN
            v_name := v_name ||','|| rec.NAME;
          ELSE
            v_elem := dbms_xmldom.createElement(v_preauth_doc, 'record');
            dbms_xmldom.setAttribute(v_elem,'id',v_ctr);
            dbms_xmldom.setAttribute(v_elem,'ailment',v_prev_icd_rec.ailment_desc);
            dbms_xmldom.setAttribute(v_elem,'icdcode',v_prev_icd_rec.icd_code);
            dbms_xmldom.setAttribute(v_elem,'pckageorprocedure',v_name);
            dbms_xmldom.setAttribute(v_elem,'packagerate',v_prev_icd_rec.pkg_rate);
            dbms_xmldom.setAttribute(v_elem,'validatedamount',v_prev_icd_rec.validated_amt);
            dbms_xmldom.setAttribute(v_elem,'approvedamount',v_prev_icd_rec.itemized_app_amount);
            dbms_xmldom.setAttribute(v_elem,'hospitalizationtype',v_prev_icd_rec.hospital_general_type_id);
            dbms_xmldom.setAttribute(v_elem,'hospitalizationdescription',v_prev_icd_rec.hospitalization_type);
            dbms_xmldom.setAttribute(v_elem,'frequency','(Freq:'||v_prev_icd_rec.frequency_of_visit||' '||v_prev_icd_rec.duration ||') (No.:'||v_prev_icd_rec.no_of_visits||')');
            v_node := dbms_xmldom.makeNode(v_elem);
            v_parent_node := dbms_xmldom.appendChild( v_root_node, v_node);
            v_prev_icd_rec := rec;
            v_name := rec.NAME;
            v_ctr := v_ctr + 1;
          END IF;
        END IF;
        FETCH icd_pcs_cur INTO rec;
      END LOOP;
      IF v_flag = 'Y' THEN
        v_elem := dbms_xmldom.createElement(v_preauth_doc, 'record');
        dbms_xmldom.setAttribute(v_elem,'id',v_ctr);
        dbms_xmldom.setAttribute(v_elem,'ailment',rec.ailment_desc);
        dbms_xmldom.setAttribute(v_elem,'icdcode',rec.icd_code);
        dbms_xmldom.setAttribute(v_elem,'pckageorprocedure',v_name);
        dbms_xmldom.setAttribute(v_elem,'packagerate',rec.pkg_rate);
        dbms_xmldom.setAttribute(v_elem,'validatedamount',rec.validated_amt);
        dbms_xmldom.setAttribute(v_elem,'approvedamount',rec.itemized_app_amount);
        dbms_xmldom.setAttribute(v_elem,'hospitalizationtype',rec.hospital_general_type_id);
        dbms_xmldom.setAttribute(v_elem,'hospitalizationdescription',rec.hospitalization_type);
        dbms_xmldom.setAttribute(v_elem,'frequency','(Freq:'||rec.frequency_of_visit||' '||rec.duration ||') (No.:'||rec.no_of_visits||')');
        v_node := dbms_xmldom.makeNode(v_elem);
        v_parent_node := dbms_xmldom.appendChild( v_root_node, v_node);
      END IF;
      CLOSE icd_pcs_cur;
------------
      v_elem := dbms_xmldom.createElement(v_preauth_doc, 'hospitaldetails');
      dbms_xmldom.setAttribute(v_elem,'hospitalname',v_rec_user.hosp_name);
      dbms_xmldom.setAttribute(v_elem,'hospitalgrade',v_rec_user.rating);
      dbms_xmldom.setAttribute(v_elem,'empanelnumber',v_rec_user.empanel_number);
      dbms_xmldom.setAttribute(v_elem,'city',v_rec_user.city_name);
      dbms_xmldom.setAttribute(v_elem,'state',v_rec_user.state_name);
      v_node := dbms_xmldom.makeNode(v_elem);
      v_parent_node := dbms_xmldom.appendChild( v_preauth_root_node, v_node);
------------

      v_elem := dbms_xmldom.createElement(v_preauth_doc, 'settlementdetails');
      dbms_xmldom.setAttribute(v_elem,'settlementnumber',v_rec_user.claim_settlement_number);
      dbms_xmldom.setAttribute(v_elem,'totalsuminsured',v_rec_user.mem_total_sum_insured);
      dbms_xmldom.setAttribute(v_elem,'availablesuminsured',v_rec_user.ava_sum_insured);
      dbms_xmldom.setAttribute(v_elem,'availablebonus',v_rec_user.ava_cum_bonus);
      dbms_xmldom.setAttribute(v_elem,'requestedamount',v_rec_user.requested_amount);

      dbms_xmldom.setAttribute(v_elem,'preauthapprovedamount',v_rec_user.pat_approved_amount);
      dbms_xmldom.setAttribute(v_elem,'approvedamount',v_rec_user.total_app_amount );

      v_node := dbms_xmldom.makeNode(v_elem);
      v_parent_node := dbms_xmldom.appendChild( v_preauth_root_node, v_node);
-----------
      v_elem := dbms_xmldom.createElement(v_preauth_doc, 'bufferamount');
      dbms_xmldom.setAttribute(v_elem,'nrmlbufferamount',v_rec_user.buff_app_amt );
      dbms_xmldom.setAttribute(v_elem,'medbufferamount',v_rec_user.med_buff_app_amt );
      dbms_xmldom.setAttribute(v_elem,'critbufferamount',v_rec_user.crit_buff_app_amt );
      dbms_xmldom.setAttribute(v_elem,'critcorpbufferamount',v_rec_user.crit_corp_buff_app_amt );
      dbms_xmldom.setAttribute(v_elem,'critmedbufferamount',v_rec_user.crit_med_buff_app_amt );
      dbms_xmldom.setAttribute(v_elem,'utilbufferamount',v_rec_user.utilised_amount );
      dbms_xmldom.setAttribute(v_elem,'utilmedbufferamount',v_rec_user.utilised_med_amount );
      dbms_xmldom.setAttribute(v_elem,'utilcritbufferamount',v_rec_user.utilised_crit_amount );
      dbms_xmldom.setAttribute(v_elem,'utilcritcorpbufferamount',v_rec_user.utilised_crit_corp_amount );
      dbms_xmldom.setAttribute(v_elem,'utilcritmedbufferamount',v_rec_user.utilised_crit_med_amount );
   
      v_node := dbms_xmldom.makeNode(v_elem);
      v_parent_node := dbms_xmldom.appendChild( v_preauth_root_node, v_node);
---------
      v_elem := dbms_xmldom.createElement(v_preauth_doc, 'approvalstatus');
      dbms_xmldom.setAttribute(v_elem,'status',v_rec_user.status);
      dbms_xmldom.setAttribute(v_elem,'approvedby',v_rec_user.contact_name);
      dbms_xmldom.setAttribute(v_elem,'approveddate',v_rec_user.decision_date);
      dbms_xmldom.setAttribute(v_elem,'remarks',v_rec_user.remarks);
      dbms_xmldom.setAttribute(v_elem,'reason',v_rec_user.reason_type);

      v_node := dbms_xmldom.makeNode(v_elem);
      v_parent_node := dbms_xmldom.appendChild( v_preauth_root_node, v_node);
-------
      v_elem := dbms_xmldom.createElement(v_preauth_doc, 'narrationdetails');
      v_node := dbms_xmldom.makeNode(v_elem);
      v_root_node := dbms_xmldom.appendChild( v_preauth_root_node, v_node);

     v_ctr := 1;
     FOR nar_rec IN narration_cur
     LOOP
        v_elem := dbms_xmldom.createElement(v_preauth_doc, 'record');
        dbms_xmldom.setAttribute(v_elem,'id', v_ctr);
        dbms_xmldom.setAttribute(v_elem,'referencedate',nar_rec.reference_date);
        dbms_xmldom.setAttribute(v_elem,'remarks',nar_rec.remarks);
        dbms_xmldom.setAttribute(v_elem,'user',nar_rec.contact_name);
        v_node := dbms_xmldom.makeNode(v_elem);
        v_parent_node := dbms_xmldom.appendChild( v_root_node, v_node);
        v_ctr := v_ctr + 1;
      END LOOP;
      v_claim_history_doc := dbms_xmldom.getxmltype( v_preauth_doc );

     dbms_xmldom.freeDocument(v_preauth_doc);
   END create_claim_xml;
--======================================================================================================
  PROCEDURE select_enrollment(
    v_policy_group_seq_id      IN tpa_enr_policy_group.policy_group_seq_id%TYPE,
    result_set                 OUT SYS_REFCURSOR
  )
  IS
  BEGIN
    OPEN result_set FOR SELECT
    A.policy_group_seq_id ,
    A.policy_seq_id ,
    A.enr_address_seq_id ,
    A.order_number ,
    A.employee_no ,
    A.insured_name ,
    A.department ,
    A.designation ,
    A.date_of_joining ,
    A.date_of_resignation ,
    B.address_1 ,
    B.address_2 ,
    B.address_3 ,
    B.city_type_id ,
    d.state_name AS state_type_id ,
    e.country_name AS country_id ,
    B.pin_code ,
    B.res_phone_no ,
    B.off_phone_no_1,
    B.off_phone_no_2  ,
    ttk_util_pkg.fn_decrypt(B.mobile_no) AS  mobile_no , --/ED
    B.fax_no ,
    ttk_util_pkg.fn_decrypt(B.email_id) AS email_id, --/ED
    A.beneficiary_name ,
    f.relship_description AS relship_type_id ,
    A.customer_no,
    decode (A.proposal_form_yn ,'Y' ,'Yes','No') AS proposal_form_yn,
    A.declaration_date ,
    C.bank_seq_id,
    ttk_util_pkg.fn_decrypt(C.bank_name) as bank_name, --/ED
    ttk_util_pkg.fn_decrypt(C.bank_account_no) as bank_account_no,--/ED
    C.bank_phone_no,
    ttk_util_pkg.fn_decrypt(C.bank_branch) as bank_branch, --/ED
    ttk_util_pkg.fn_decrypt(C.bank_micr) as bank_micr,--/ED
    A.group_reg_seq_id ,
    h.group_name,
    A.certificate_no,
    ttk_util_pkg.fn_decrypt(A.creditcard_no) as creditcard_no,
    decode ( A.stop_pat_clm_process_yn ,'Y' ,'Yes','No' ) AS stop_pat_clm_process_yn,
    A.recieved_after
    FROM tpa_enr_policy_group A LEFT OUTER JOIN tpa_enr_mem_address B ON (A.enr_address_seq_id = B.enr_address_seq_id )
    LEFT OUTER JOIN tpa_enr_bank_dtls C ON (A.bank_seq_id = C.bank_seq_id)
    LEFT OUTER JOIN tpa_state_code d ON (b.state_type_id = d.state_type_id)
    LEFT OUTER JOIN tpa_country_code e ON (b.country_id = e.country_id)
    LEFT OUTER JOIN tpa_relationship_code f ON (a.relship_type_id = f.relship_type_id)
    LEFT OUTER JOIN tpa_enr_policy g ON (a.policy_seq_id = g.policy_seq_id)
    LEFT OUTER JOIN tpa_group_registration h ON (g.group_reg_seq_id = h.group_reg_seq_id)
    WHERE a.policy_group_seq_id = v_policy_group_seq_id AND a.deleted_yn = 'N';
  END select_enrollment;
--======================================================================================================
--==============================================================================================
 /*
  Author: Ramakrishna K M SPAN Infotech.
  Description: This procedure gives citibank enrollment history data
*/
--==============================================================================================
  PROCEDURE create_citi_enrol_hist_xml (
    v_citibank_enr_seq_id             IN  citibank_enr_history.citibank_enr_seq_id %TYPE,
    v_citienrol_history_doc           OUT XMLTYPE
  )
  IS

     CURSOR enrol_cur IS
       SELECT A.citibank_enr_seq_id,
              A.oldordnum,
              A.ord_num,
              A.acno,
              A.cm_name,
              A.appl_name,
              A.dob,
              A.relat,
              A.sex,
              A.mc_plan,
              A.mc_premium,
              A.add1,
              A.add2,
              A.add3,
              A.add4,
              A.city,
              A.pin_code,
              A.res_tel,
              A.off_tel,
              A.cert_sno,
              A.mcpolicy,
              A.appl_dob,
              A.card_num,
              A.ped,
              A.change,
              A.changedate,
              A.mccancel,
              A.canspers,
              A.canclsours,
              A.cansdate,
              A.mcrefnd,
              A.cansnumber,
              A.custcode,
              A.fileno,
              A.newordnum,
              A.pa_plan,
              A.pa_premium,
              A.papolicy,
              A.pa_sumassu,
              A.taxdeduct,
              A.amtinchar,
              A.file_ref,
              A.note,
              A.pacancel,
              A.ltr2clnt,
              A.dsa,
              A.renewal,
              A.medi_cert,
              A.old_certno,
              A.parefnd
         FROM citibank_enr_history A
         WHERE A.citibank_enr_seq_id = v_citibank_enr_seq_id;


      v_enrol_doc         DBMS_XMLDOM.DOMDocument;
      v_enrol_root_node   DBMS_XMLDOM.DOMNode;
      v_elem               DBMS_XMLDOM.DOMElement;
      v_elem1              DBMS_XMLDOM.DOMElement;
      v_node               DBMS_XMLDOM.DOMNode;
      v_parent_node        DBMS_XMLDOM.DOMNODE;
      v_child_node         DBMS_XMLDOM.DOMNODE;
      v_root_node          DBMS_XMLDOM.DOMNode;
      v_rec_user           enrol_cur%ROWTYPE;

    BEGIN
      OPEN enrol_cur;
      FETCH enrol_cur INTO v_rec_user;
      CLOSE enrol_cur;

      v_enrol_doc := dbms_xmldom.newDOMDocument;
      dbms_xmldom.setVersion( v_enrol_doc, '1.0' );
      v_enrol_root_node := dbms_xmldom.makeNode(v_enrol_doc);

      v_elem := dbms_xmldom.createElement( v_enrol_doc, 'enrollhistory' );
      v_node := dbms_xmldom.makeNode( v_elem );
      v_enrol_root_node := dbms_xmldom.appendChild( v_enrol_root_node, v_node );
---
      v_elem := dbms_xmldom.createElement(v_enrol_doc, 'enrolldetails');
      dbms_xmldom.setAttribute(v_elem,'ordnum',v_rec_user.ord_num);
      dbms_xmldom.setAttribute(v_elem,'oldordnum',v_rec_user.oldordnum);
      dbms_xmldom.setAttribute(v_elem,'acctno',v_rec_user.acno);
      dbms_xmldom.setAttribute(v_elem,'claimantname',v_rec_user.cm_name);
      dbms_xmldom.setAttribute(v_elem,'applicantname',v_rec_user.appl_name);
      dbms_xmldom.setAttribute(v_elem,'claimantdob',v_rec_user.dob);
      dbms_xmldom.setAttribute(v_elem,'relationship',v_rec_user.relat);
      dbms_xmldom.setAttribute(v_elem,'gender',v_rec_user.sex);
      dbms_xmldom.setAttribute(v_elem,'mcplan',v_rec_user.mc_plan);
      dbms_xmldom.setAttribute(v_elem,'mcpremium',v_rec_user.mc_premium);
      dbms_xmldom.setAttribute(v_elem,'add1',v_rec_user.add1);
      dbms_xmldom.setAttribute(v_elem,'add2',v_rec_user.add2);
      dbms_xmldom.setAttribute(v_elem,'add3',v_rec_user.add3);
      dbms_xmldom.setAttribute(v_elem,'add4',v_rec_user.add4);
      dbms_xmldom.setAttribute(v_elem,'city',v_rec_user.city);
      dbms_xmldom.setAttribute(v_elem,'pincode',v_rec_user.pin_code);
      dbms_xmldom.setAttribute(v_elem,'restel',v_rec_user.res_tel);
      dbms_xmldom.setAttribute(v_elem,'offtel',v_rec_user.off_tel);
      dbms_xmldom.setAttribute(v_elem,'certificateno',v_rec_user.cert_sno);
      dbms_xmldom.setAttribute(v_elem,'mcpolicy',v_rec_user.mcpolicy);
      dbms_xmldom.setAttribute(v_elem,'applicantdob',v_rec_user.appl_dob);

      dbms_xmldom.setAttribute(v_elem,'cardnum',v_rec_user.card_num);
      dbms_xmldom.setAttribute(v_elem,'ped',v_rec_user.ped);
      dbms_xmldom.setAttribute(v_elem,'change',v_rec_user.change);
      dbms_xmldom.setAttribute(v_elem,'changedate',v_rec_user.changedate);
      dbms_xmldom.setAttribute(v_elem,'mccancel',v_rec_user.mccancel);
      dbms_xmldom.setAttribute(v_elem,'canspers',v_rec_user.canspers);
      dbms_xmldom.setAttribute(v_elem,'canclsours',v_rec_user.canclsours);
      dbms_xmldom.setAttribute(v_elem,'cansdate',v_rec_user.cansdate);
      dbms_xmldom.setAttribute(v_elem,'mcrefnd',v_rec_user.mcrefnd);
      dbms_xmldom.setAttribute(v_elem,'cansnumber',v_rec_user.cansnumber);
      dbms_xmldom.setAttribute(v_elem,'custcode',v_rec_user.custcode);
      dbms_xmldom.setAttribute(v_elem,'fileno',v_rec_user.fileno);
      dbms_xmldom.setAttribute(v_elem,'newordnum',v_rec_user.newordnum);
      dbms_xmldom.setAttribute(v_elem,'paplan',v_rec_user.pa_plan);
      dbms_xmldom.setAttribute(v_elem,'papremium',v_rec_user.pa_premium);
      dbms_xmldom.setAttribute(v_elem,'papolicy',v_rec_user.papolicy);
      dbms_xmldom.setAttribute(v_elem,'pasumassured',v_rec_user.pa_sumassu);
      dbms_xmldom.setAttribute(v_elem,'taxdeduct',v_rec_user.taxdeduct);
      dbms_xmldom.setAttribute(v_elem,'amtinchar',v_rec_user.amtinchar);
      dbms_xmldom.setAttribute(v_elem,'fileref',v_rec_user.file_ref);
      dbms_xmldom.setAttribute(v_elem,'applicantdob',v_rec_user.note);
      dbms_xmldom.setAttribute(v_elem,'pacancel',v_rec_user.pacancel);
      dbms_xmldom.setAttribute(v_elem,'ltr2clnt',v_rec_user.ltr2clnt);
      dbms_xmldom.setAttribute(v_elem,'dsa',v_rec_user.dsa);
      dbms_xmldom.setAttribute(v_elem,'renewal',v_rec_user.renewal);
      dbms_xmldom.setAttribute(v_elem,'medicert',v_rec_user.medi_cert);
      dbms_xmldom.setAttribute(v_elem,'oldcertno',v_rec_user.old_certno);
      dbms_xmldom.setAttribute(v_elem,'parefnd',v_rec_user.parefnd);
      v_node := dbms_xmldom.makeNode(v_elem);
      v_parent_node := dbms_xmldom.appendChild( v_enrol_root_node, v_node);

    v_citienrol_history_doc := dbms_xmldom.getxmltype(v_enrol_doc);
    dbms_xmldom.freeDocument(v_enrol_doc);
  END create_citi_enrol_hist_xml;
  --==============================================================================================
  /*
  Author: Ramakrishna K M SPAN Infotech.
  Description: This procedure gives citibank enrollment history data
*/
--==============================================================================================
  PROCEDURE create_citi_clm_hist_xml (
    v_citibank_clm_seq_id           IN  citibank_clm_history.citibank_clm_seq_id %TYPE,
    v_citiclm_history_doc           OUT XMLTYPE
  )
  IS

     CURSOR clm_cur IS
       SELECT A.citibank_clm_seq_id,
              A.fileno,
              A.filerefno,
              A.insurename,
              A.certno,
              A.claimno,
              A.claimyear,
              A.disease,
              A.dateofloss,
              A.amtsettled,
              A.remarks,
              A.enrno,
              A.scheme,
              A.custcode
         FROM citibank_clm_history A
         WHERE A.citibank_clm_seq_id = v_citibank_clm_seq_id;


      v_clm_doc         DBMS_XMLDOM.DOMDocument;
      v_clm_root_node   DBMS_XMLDOM.DOMNode;
      v_elem            DBMS_XMLDOM.DOMElement;
      v_elem1           DBMS_XMLDOM.DOMElement;
      v_node            DBMS_XMLDOM.DOMNode;
      v_parent_node     DBMS_XMLDOM.DOMNODE;
      v_child_node      DBMS_XMLDOM.DOMNODE;
      v_root_node       DBMS_XMLDOM.DOMNode;
      v_rec_user        clm_cur%ROWTYPE;

    BEGIN
      OPEN clm_cur;
      FETCH clm_cur INTO v_rec_user;
      CLOSE clm_cur;

      v_clm_doc := dbms_xmldom.newDOMDocument;
      dbms_xmldom.setVersion( v_clm_doc, '1.0' );
      v_clm_root_node := dbms_xmldom.makeNode(v_clm_doc);

      v_elem := dbms_xmldom.createElement( v_clm_doc, 'citiclmhistory' );
      v_node := dbms_xmldom.makeNode( v_elem );
      v_clm_root_node := dbms_xmldom.appendChild( v_clm_root_node, v_node );
---
      v_elem := dbms_xmldom.createElement(v_clm_doc, 'claimdetails');
      dbms_xmldom.setAttribute(v_elem,'citibankclmseqid',v_rec_user.citibank_clm_seq_id);
      dbms_xmldom.setAttribute(v_elem,'fileno',v_rec_user.fileno);
      dbms_xmldom.setAttribute(v_elem,'filerefno',v_rec_user.filerefno);
      dbms_xmldom.setAttribute(v_elem,'insurename',v_rec_user.insurename);
      dbms_xmldom.setAttribute(v_elem,'certno',v_rec_user.certno);
      dbms_xmldom.setAttribute(v_elem,'claimno',v_rec_user.claimno);
      dbms_xmldom.setAttribute(v_elem,'claimyear',v_rec_user.claimyear);
      dbms_xmldom.setAttribute(v_elem,'disease',v_rec_user.disease);
      dbms_xmldom.setAttribute(v_elem,'dateofloss',v_rec_user.dateofloss);
      dbms_xmldom.setAttribute(v_elem,'amtsettled',v_rec_user.amtsettled);
      dbms_xmldom.setAttribute(v_elem,'remarks',v_rec_user.remarks);
      dbms_xmldom.setAttribute(v_elem,'enrno',v_rec_user.enrno);
      dbms_xmldom.setAttribute(v_elem,'scheme',v_rec_user.scheme);
      dbms_xmldom.setAttribute(v_elem,'custcode',v_rec_user.custcode);
      v_node := dbms_xmldom.makeNode(v_elem);
      v_parent_node := dbms_xmldom.appendChild( v_clm_root_node, v_node);
    v_citiclm_history_doc := dbms_xmldom.getxmltype(v_clm_doc);
    dbms_xmldom.freeDocument(v_clm_doc);
  END create_citi_clm_hist_xml;

 --==============================================================================================
  -- start for IBM copay and buffer flow by Ravi
  --==============================================================================================
  -- FUNCTION : get_gen_desc
  -- Date     : 07Jan13
  -- Author   : Ravi
  -- Purpose  : To get the descriptions
 --===============================================================================================
  FUNCTION get_gen_desc(v_type_id IN varchar2, v_code IN VARCHAR2)
         RETURN VARCHAR2 IS
         v_out VARCHAR2(250BYTE);
         cursor network_check is 
         select count(*) from tpa_general_code gc where gc.general_type_id=v_type_id;
         v_count number;
       

  BEGIN
    IF    v_code ='R' THEN
    SELECT relship_description INTO v_out FROM tpa_relationship_code WHERE relship_type_id=v_type_id;

    ELSIF v_code ='G' THEN
    open network_check;
      fetch network_check into v_count;
      close network_check;
        if v_count>0 then 
    SELECT gc.description INTO v_out FROM tpa_general_code gc WHERE gc.general_type_id=v_type_id;
   end if;
    ELSIF v_code ='S' THEN
    SELECT state_name INTO v_out FROM tpa_state_code WHERE state_type_id=v_type_id;

	ELSIF v_code = 'CT' THEN
    SELECT CITY_DESCRIPTION INTO v_out from TPA_CITY_CODE where CITY_TYPE_ID=v_type_id;

	ELSIF v_code = 'E' THEN
    SELECT A.ENROL_DESCRIPTION INTO v_out from TPA_ENROLMENT_TYPE_CODE A where A.ENROL_TYPE_ID=v_type_id;


    ELSIF v_code = 'C' THEN
    SELECT decode(v_type_id,1,'INDIA',2,'NEPAL',3,'BHUTAN') INTO v_out FROM dual;

    ELSIF v_code = 'U' THEN
    SELECT user_id INTO v_out from tpa_login_info where contact_seq_id=v_type_id;

    END IF;
    RETURN v_out;

    EXCEPTION WHEN OTHERS THEN
    RETURN v_type_id;
  END get_gen_desc;
 --====================================================================================================
 -- Procedure : Select_member_buffer_list
 -- Date      : 07Jan13
 -- Author    : Ravi
 -- Purpose   : To get the descriptions
 --====================================================================================================
Procedure select_member_buffer_list(v_policy_number    IN Tpa_enr_policy.Policy_Number%TYPE,
                                    v_enrollment_no    IN Tpa_enr_policy_group.Tpa_Enrollment_Number%TYPE,
                                    v_emp_name         IN Tpa_enr_policy_member.Mem_Name%TYPE,
                                    v_enrollment_id    IN Tpa_enr_policy_member.Tpa_Enrollment_Id%TYPE,
                                    v_mem_name         IN Tpa_enr_policy_member.Mem_Name%TYPE,
                                    v_group_id         IN Tpa_enr_policy.Groupid%TYPE,
                                    v_sort_var         IN VARCHAR2,
                                    v_sort_order       IN VARCHAR2,
                                    v_start_num        IN NUMBER ,
                                    v_end_num          IN NUMBER ,
                                    v_result_set       OUT SYS_REFCURSOR) IS

 TYPE str_tab IS TABLE OF VARCHAR2(500) INDEX by BINARY_INTEGER;

 v_sql_str        VARCHAR2(4000);
 v_where          VARCHAR2(500);
 tab_str          str_tab;
 i                NUMBER(4):=0;


  CURSOR pol_buffer_cur IS SELECT h.total_buffer_amount,h.buffer_allowed_yn,h.buffer_alloc_amount,h.member_buffer_yn,h.currently_uploading_yn
        FROM Tpa_enr_policy h
        WHERE h.policy_number=upper(v_policy_number);

  pol_buffer_rec         pol_buffer_cur%ROWTYPE;

 BEGIN

   OPEN  pol_buffer_cur;
   FETCH pol_buffer_cur INTO pol_buffer_rec;
   CLOSE pol_buffer_cur;

   IF pol_buffer_rec.member_buffer_yn='N' THEN
     Raise_application_error(-20851,'Please configure buffer details at policy level');
   END IF;

 v_sql_str := 'SELECT  A.policy_seq_id,
        B.Policy_Group_Seq_Id,
        C.Member_Seq_Id,
        D.Group_Reg_Seq_Id,
        A.Policy_Number,
        D.Group_id,
        DECODE(A.Enrol_Type_Id,''COR'',''Corporate'',''IND'',''Individual'',''ING'',''Individual as group'',''NON-Corporate'') as Enrol_type,
        A.Effective_From_Date,
        A.Effective_To_Date,
        B.tpa_enrollment_number,
        B.insured_name,
        C.tpa_enrollment_id,
        C.mem_name,
        account_info_pkg.get_gen_desc(C.relship_type_id,''R'') as Relation,
        account_info_pkg.get_gen_desc(C.gender_general_type_id,''G'') as Gender,
        nvl(C.Mem_Buffer_Alloc,0) as Member_buffer,
        nvl(c.Mem_Med_Buffer_Alloc,0) as Mem_Med_Buffer_Alloc,
        nvl(c.Mem_Crit_Buff_Alloc,0) as Mem_Crit_Buff_Alloc,
        nvl(c.Mem_Crit_Corp_Buff_Alloc,0) as Mem_Crit_Corp_Buff_Alloc,
        nvl(c.Mem_Crit_Med_Buff_Alloc,0) as Mem_Crit_Med_Buff_Alloc,
        nvl(C.Mem_Buffer_Alloc,0)+nvl(c.Mem_Med_Buffer_Alloc,0)+nvl(c.Mem_Crit_Buff_Alloc,0)+nvl(c.Mem_Crit_Corp_Buff_Alloc,0)+nvl(c.Mem_Crit_Med_Buff_Alloc,0) AS total_member_buffer
        FROM Tpa_enr_policy A
        JOIN Tpa_enr_policy_group B on (A.policy_seq_id=b.policy_seq_id)
        JOIN Tpa_enr_policy_member C on (B.policy_group_seq_id=C.policy_group_seq_id)
        JOIN Tpa_group_registration D on (D.Group_Reg_Seq_Id=A.Group_Reg_Seq_Id)       
        WHERE A.Buffer_Allowed_Yn=''Y'' and C.Deleted_Yn=''N''  and B.Deleted_Yn=''N''';

 IF v_policy_number IS NOT NULL THEN
   v_where := v_where ||' AND A.policy_number = :v_policy_number';
   i := i+1;
   tab_str(i):= UPPER(v_policy_number);
 END IF;

 IF v_enrollment_no IS NOT NULL THEN
   v_where := v_where ||' AND B.Tpa_Enrollment_Number = :v_enrollment_no ';
   i := i+1;
   tab_str(i):= UPPER(v_enrollment_no);
 END IF;

 IF v_emp_name IS NOT NULL THEN
   v_where := v_where ||' AND B.insured_name = :v_emp_name ';
   i := i+1;
   tab_str(i):= UPPER(v_emp_name);
 END IF;

 IF v_enrollment_id IS NOT NULL THEN
   v_where := v_where ||' AND C.tpa_enrollment_id = :v_enrollment_id ';
   i := i+1;
   tab_str(i):= UPPER(v_enrollment_id);
 END IF;

 IF v_mem_name IS NOT NULL THEN
   v_where := v_where ||' AND C.mem_name = :v_mem_name ';
   i := i+1;
   tab_str(i):= UPPER(v_mem_name);
  END IF;

 IF v_group_id IS NOT NULL THEN
   v_where := v_where ||' AND D.group_id= :v_group_id';
   i := i+1 ;
   tab_str(i):= UPPER(v_group_id);
  END IF;

    v_sql_str := v_sql_str||v_where;
    v_sql_str := 'SELECT * FROM
            (SELECT A.*,DENSE_RANK() OVER (ORDER BY '||v_sort_var||' '||v_sort_order||',ROWNUM) Q FROM (' ||v_sql_str|| ') A )
             WHERE  Q>= :v_start_num AND Q<= :v_end_num ';

    IF tab_str.FIRST IS NOT NULL THEN
       CASE tab_str.COUNT
         WHEN 1 THEN OPEN v_result_set FOR v_sql_str USING tab_str(1) , v_start_num , v_end_num ;
         WHEN 2 THEN OPEN v_result_set FOR v_sql_str USING tab_str(1),tab_str(2), v_start_num , v_end_num ;
         WHEN 3 THEN OPEN v_result_set FOR v_sql_str USING tab_str(1),tab_str(2),tab_str(3) , v_start_num , v_end_num ;
         WHEN 4 THEN OPEN V_result_set FOR v_sql_str USING tab_str(1),tab_str(2),tab_str(3) ,tab_str(4) ,v_start_num ,v_end_num ;
         WHEN 5 THEN OPEN V_result_set FOR v_sql_str USING tab_str(1),tab_str(2),tab_str(3) ,tab_str(4) ,tab_str(5) ,v_start_num ,v_end_num ;
         WHEN 6 THEN OPEN V_result_set FOR v_sql_str USING tab_str(1),tab_str(2),tab_str(3) ,tab_str(4) ,tab_str(5) ,tab_str(6) ,v_start_num ,v_end_num ;

      END CASE;
    ELSE
      OPEN v_result_set FOR v_sql_str USING  v_start_num , v_end_num ;
   END IF;

 END select_member_buffer_list;
--==========================================================================================================================
-- procedure : save_mem_buffer_details
-- Date      : 08jan2013
-- Author    : Ravi
-- Remarks   : Save the individual member buffer details
--========================================================================================================================
PROCEDURE save_mem_buffer_details(v_mem_buff_seqid           IN OUT Tpa_enr_mem_buff_dtls.MEM_BUFF_SEQID%TYPE ,
                                  v_policy_seq_id            IN  Tpa_enr_mem_buff_dtls.POLICY_SEQ_ID%TYPE ,
                                  v_policy_group_seq_id      IN  Tpa_enr_mem_buff_dtls.POLICY_GROUP_SEQ_ID%TYPE ,
                                  v_member_seq_id            IN  Tpa_enr_mem_buff_dtls.MEMBER_SEQ_ID%TYPE ,
                                  v_reference_no             IN  Tpa_enr_mem_buff_dtls.REFERENCE_NO%TYPE ,
                                  v_buffer_added_date        IN  Tpa_enr_mem_buff_dtls.BUFFER_ADDED_DATE%TYPE ,
                                  v_buffer_mode              IN  Tpa_enr_mem_buff_dtls.BUFFER_MODE%TYPE ,
                                  v_hr_appr_buffer           IN  Tpa_enr_mem_buff_dtls.Hr_Appr_Buffer%TYPE,
                                  v_buffer_amt               IN  Tpa_enr_mem_buff_dtls.BUFFER_AMT%TYPE ,
                                  v_approved_by              IN  Tpa_enr_mem_buff_dtls.APPROVED_BY%TYPE ,
                                  v_remarks                  IN  Tpa_enr_mem_buff_dtls.REMARKS%TYPE ,
                                  v_added_by                 IN  Tpa_enr_mem_buff_dtls.ADDED_BY%TYPE ,
                                  v_ava_cor_buffer           IN  Tpa_enr_mem_buff_dtls.Ava_Cor_Buffer%TYPE,
                                  v_ava_fam_buffer           IN  tpa_enr_mem_buff_dtls.ava_fam_buffer%TYPE,
                                  v_ava_mem_buffer           IN  tpa_enr_mem_buff_dtls.ava_mem_buffer%TYPE,
                                  v_claim_type               IN  tpa_enr_mem_buff_dtls.claim_type%TYPE,
                                  v_buffer_type              IN  tpa_enr_mem_buff_dtls.Buffer_Type%TYPE,
                                  v_alert                    OUT VARCHAR2,
                                  v_rows_processed           OUT Number) is

 CURSOR pol_buff_date_cur IS SELECT MAX(a.buffer_added_date)
       FROM Tpa_enr_buffer_details a WHERE a.policy_seq_id = v_policy_seq_id;

 CURSOR mem_buff_date_cur IS SELECT MAX(b.buffer_added_date)
        FROM Tpa_Enr_Mem_Buff_Dtls B where b.member_seq_id=v_member_seq_id
        AND b.policy_group_seq_id=v_policy_group_seq_id
        AND b.mem_buff_seqid!=v_mem_buff_seqid;

 CURSOR fam_buffer_alloc IS SELECT SUM(nvl(k.mem_buffer_alloc,0)),SUM(NVL(n.used_buff_amount,0)) 
        FROM tpa_enr_policy_member K
        LEFT OUTER JOIN tpa_enr_mem_buffer n ON k.policy_group_seq_id=n.policy_group_seq_id
        WHERE K.Deleted_Yn='N' and K.Policy_Group_Seq_Id=v_policy_group_seq_id;

 CURSOR total_fam_buff_alloc IS select SUM(nvl(J.mem_buffer_alloc,0))
        FROM tpa_enr_policy_member J
        JOIN tpa_enr_policy_group F ON (F.Policy_Group_Seq_Id=j.policy_group_seq_id)
        WHERE F.Deleted_Yn='N' and J.Deleted_Yn='N' and F.Policy_Seq_Id=v_policy_seq_id;

 CURSOR pol_buffer_cur IS
        SELECT h.tot_crit_med_buff_amount total_buffer_amount,h.buffer_allowed_yn,
         case when pre_auth_pkg.get_buff_level_limit(h.policy_seq_id,'NRML','CORB',i.level_type)!=0 then 
                  pre_auth_pkg.get_buff_level_limit(h.policy_seq_id,'NRML','CORB',i.level_type)  else  h.Buffer_Alloc_Amount 
                  end as buffer_alloc_amount,
        h.member_buffer_yn,h.currently_uploading_yn,h.buffer_alloc_general_type_id,h.policy_sub_general_type_id AS policy_type
        FROM Tpa_enr_policy h
        JOIN tpa_enr_policy_group i on (h.policy_seq_id=i.policy_group_seq_id)
        WHERE i.policy_group_seq_id=v_policy_group_seq_id;

 CURSOR fam_used_buff IS SELECT k.buffer_amount,k.utilised_buff_amount,(k.buffer_amount-nvl(k.utilised_buff_amount,0)) ava_fam_buff
        FROM tpa_enr_balance K
        WHERE k.policy_group_seq_id=v_policy_group_seq_id;

 CURSOR mem_used_buff IS SELECT sum(nvl(m.mem_buffer_alloc,0)) as mem_buff, SUM(nvl(n.used_buff_amount,0)) as used_buffer
        FROM tpa_enr_policy_member m
        LEFT OUTER JOIN tpa_enr_mem_buffer n ON m.member_seq_id=n.member_seq_id
        WHERE m.Deleted_Yn='N' and m.member_seq_id=v_member_seq_id AND m.policy_group_seq_id=v_policy_group_seq_id;

 CURSOR cor_used_buff IS SELECT SUM(p.utilised_buff_amount) as cor_used_buff
        FROM tpa_enr_balance p
        WHERE P.Policy_Seq_Id=v_policy_seq_id;

 CURSOR nfl_used_buff IS SELECT lk.buffer_amount,lk.utilised_buff_amount
        FROM tpa_enr_balance lk
        WHERE lk.member_seq_id=v_member_seq_id;

 CURSOR hr_appr_buffer is
   SELECT SUM(decode(df.buffer_mode,'DED',-1*nvl(df.hr_appr_buffer,0),nvl(df.hr_appr_buffer,0))) as total_hr_buffer FROM tpa_enr_mem_buff_dtls df
       WHERE df.member_seq_id=v_member_seq_id;

    pol_buffer_rec         pol_buffer_cur%ROWTYPE;
    fam_used_rec           fam_used_buff%ROWTYPE;
    mem_used_rec           mem_used_buff%ROWTYPE;
    cor_used_rec           cor_used_buff%ROWTYPE;
    nfl_used_rec           nfl_used_buff%ROWTYPE;
    hr_buffer              Tpa_enr_mem_buff_dtls.Hr_Appr_Buffer%TYPE;

    v_pol_last_date        DATE;
    v_mem_last_date        DATE;
    v_fam_buff_alloc       Tpa_enr_policy_member.mem_buffer_alloc%TYPE;
    v_tot_fam_buff_alloc   Tpa_enr_policy_member.mem_buffer_alloc%TYPE;
    v_pa_clm_yn            Number(3);
    v_currently_uploading_yn             TPA_ENR_POLICY.currently_uploading_yn%TYPE;
    v_fam_used_mem_buffer                tpa_enr_mem_buffer.used_buff_amount%type;

Begin
/* delete from temp_ram;
  insert into temp_ram(remarks) values ('v_mem_buff_seqid'||v_mem_buff_seqid||chr(13)||
'v_policy_seq_id'||v_policy_seq_id||chr(13)||
'v_policy_group_seq_id'||v_policy_group_seq_id||chr(13)||
'v_member_seq_id'||v_member_seq_id||chr(13)||
'v_reference_no'||v_reference_no||chr(13)||
'v_buffer_added_date'||v_buffer_added_date||chr(13)||
'v_buffer_mode'||v_buffer_mode||chr(13)||
'v_hr_appr_buffer'||v_hr_appr_buffer||chr(13)||
'v_buffer_amt'||v_buffer_amt||chr(13)||
'v_approved_by'||v_approved_by||chr(13)||
'v_remarks'||v_remarks||chr(13)||
'v_added_by'||v_added_by||chr(13)||
'v_ava_cor_buffer'||v_ava_cor_buffer||chr(13)||
'v_ava_fam_buffer'||v_ava_fam_buffer||chr(13)||
'v_ava_mem_buffer'||v_ava_mem_buffer||chr(13)||
'v_claim_type'||v_claim_type||chr(13)||
'v_buffer_type'||v_buffer_type);
COMMIT;*/

 IF v_claim_type='NRML' AND v_buffer_type ='MEDB' THEN
   
                  save_medical_mem_buff_dtls(v_mem_buff_seqid,
                                              v_policy_seq_id,
                                              v_policy_group_seq_id,
                                              v_member_seq_id,
                                              v_reference_no,
                                              v_buffer_added_date,
                                              v_buffer_mode,
                                              v_hr_appr_buffer,
                                              v_buffer_amt,
                                              v_approved_by,
                                              v_remarks,
                                              v_added_by,
                                              v_ava_cor_buffer,
                                              v_ava_fam_buffer,
                                              v_ava_mem_buffer,
                                              v_claim_type,
                                              v_buffer_type,
                                              v_alert,
                                              v_rows_processed);
                                              
ELSIF v_claim_type='CRTL' AND v_buffer_type ='MEDB' THEN
   
                  save_crit_med_mem_buff_dtls(v_mem_buff_seqid,
                                              v_policy_seq_id,
                                              v_policy_group_seq_id,
                                              v_member_seq_id,
                                              v_reference_no,
                                              v_buffer_added_date,
                                              v_buffer_mode,
                                              v_hr_appr_buffer,
                                              v_buffer_amt,
                                              v_approved_by,
                                              v_remarks,
                                              v_added_by,
                                              v_ava_cor_buffer,
                                              v_ava_fam_buffer,
                                              v_ava_mem_buffer,
                                              v_claim_type,
                                              v_buffer_type,
                                              v_alert,
                                              v_rows_processed);                                              

ELSIF v_claim_type='CRTL' AND v_buffer_type ='CRTB' THEN
   
                  save_crit_mem_buff_dtls(v_mem_buff_seqid,
                                              v_policy_seq_id,
                                              v_policy_group_seq_id,
                                              v_member_seq_id,
                                              v_reference_no,
                                              v_buffer_added_date,
                                              v_buffer_mode,
                                              v_hr_appr_buffer,
                                              v_buffer_amt,
                                              v_approved_by,
                                              v_remarks,
                                              v_added_by,
                                              v_ava_cor_buffer,
                                              v_ava_fam_buffer,
                                              v_ava_mem_buffer,
                                              v_claim_type,
                                              v_buffer_type,
                                              v_alert,
                                              v_rows_processed);                                              

                  
 ELSIF v_claim_type='CRTL' and  v_buffer_type ='CORB' THEN
 
                  save_crit_corp_mem_buff_dtls(v_mem_buff_seqid,
                                              v_policy_seq_id,
                                              v_policy_group_seq_id,
                                              v_member_seq_id,
                                              v_reference_no,
                                              v_buffer_added_date,
                                              v_buffer_mode,
                                              v_hr_appr_buffer,
                                              v_buffer_amt,
                                              v_approved_by,
                                              v_remarks,
                                              v_added_by,
                                              v_ava_cor_buffer,
                                              v_ava_fam_buffer,
                                              v_ava_mem_buffer,
                                              v_claim_type,
                                              v_buffer_type,
                                              v_alert,
                                              v_rows_processed);
                  
 ELSIF  v_claim_type='NRML' AND v_buffer_type ='CORB' THEN
   
   OPEN  pol_buff_date_cur;
   FETCH pol_buff_date_cur INTO v_pol_last_date;
   CLOSE pol_buff_date_cur;

   OPEN  mem_buff_date_cur;
   FETCH mem_buff_date_cur into v_mem_last_date;
   CLOSE mem_buff_date_cur;



   OPEN  pol_buffer_cur;
   FETCH pol_buffer_cur INTO pol_buffer_rec;
   CLOSE pol_buffer_cur;

   IF pol_buffer_rec.member_buffer_yn='N' THEN
     Raise_application_error(-20851,'Please configure buffer details at policy level');
   END IF;

  policy_enrollment_pkg.check_uploading(pol_buffer_rec.currently_uploading_yn);

  IF v_Buffer_Amt<=0 or  v_hr_appr_buffer<=0 THEN
    raise_application_error(-20855,' Buffer Amount cannot be less than or equal to Zero');
  END IF;

  IF v_buffer_added_date < v_pol_last_date or v_buffer_added_date <v_mem_last_date THEN
    Raise_application_error(-20850,'Buffer added date cannot be less than policy buffer date or member buffer date');
  END IF;

  IF nvl(v_mem_buff_seqid,0)=0 Then
    INSERT INTO Tpa_enr_mem_buff_dtls(
                Mem_Buff_Seqid,
                Policy_Seq_Id,
                Policy_Group_Seq_Id,
                Member_Seq_Id,
                Reference_No,
                Buffer_Added_Date,
                Hr_Appr_Buffer,
                Buffer_Mode,
                Buffer_Amt,
                Approved_By,
                Remarks,
                Added_By,
                Added_Date,
                Ava_Cor_Buffer,
                Ava_Fam_Buffer,
                Ava_Mem_Buffer,
                User_Config,
                claim_type,
                buffer_type) VALUES
               (tpa_enr_mem_buff_dtls_seq.nextval,
                v_policy_seq_id,
                v_policy_group_seq_id,
                v_Member_Seq_Id,
                v_Reference_No,
                v_Buffer_Added_Date,
                v_hr_appr_buffer,
                v_Buffer_Mode,
                v_Buffer_Amt,
                v_Approved_By,
                v_Remarks,
                v_Added_By,
                sysdate,
                v_ava_cor_buffer,
                v_ava_fam_buffer,
                v_ava_mem_buffer,
                get_gen_desc(v_Added_By,'U'),
                v_claim_type,
                v_buffer_type
                )RETURNING Mem_Buff_Seqid INTO v_mem_buff_seqid;
 END IF;

  IF v_buffer_mode ='ADD' THEN
    OPEN  fam_buffer_alloc;
    FETCH fam_buffer_alloc INTO v_fam_buff_alloc,v_fam_used_mem_buffer;
    CLOSE fam_buffer_alloc;

    OPEN  total_fam_buff_alloc;
    FETCH total_fam_buff_alloc INTO v_tot_fam_buff_alloc;
    CLOSE total_fam_buff_alloc;

    OPEN  mem_used_buff;
    FETCH mem_used_buff into mem_used_rec;
    CLOSE mem_used_buff;

    IF pol_buffer_rec.buffer_alloc_general_type_id='BAF' Then
      IF v_buffer_amt>v_ava_fam_buffer OR
       v_buffer_amt>pol_buffer_rec.total_buffer_amount THEN
     raise_application_error(-20852,'Amount approved exceeds the Family or Corporate buffer amount');
    END IF;

    ELSE
      IF v_buffer_amt>v_ava_fam_buffer OR
         v_buffer_amt>pol_buffer_rec.total_buffer_amount Then
      raise_application_error(-20852,'Amount approved exceeds the Family or Corporate buffer amount');
       END IF;
    END IF;

     UPDATE Tpa_enr_policy_member SET
            mem_buffer_alloc= nvl(mem_buffer_alloc,0)+v_buffer_amt
     WHERE member_seq_id=v_member_seq_id
     AND policy_group_seq_id=v_policy_group_seq_id;

  END IF;

  IF v_buffer_mode ='DED' THEN
     OPEN  fam_used_buff;
     FETCH fam_used_buff INTO fam_used_rec;
     CLOSE fam_used_buff;

     OPEN  mem_used_buff;
     FETCH mem_used_buff INTO mem_used_rec;
     CLOSE mem_used_buff;

     OPEN  cor_used_buff;
     FETCH cor_used_buff INTO cor_used_rec;
     CLOSE cor_used_buff;

     OPEN  nfl_used_buff;
     FETCH nfl_used_buff INTO nfl_used_rec;
     CLOSE nfl_used_buff;

    OPEN hr_appr_buffer;
    FETCH hr_appr_buffer INTO hr_buffer;
    CLOSE hr_appr_buffer;


     v_pa_clm_yn:=buffer_pa_clm_yn(v_member_seq_id,v_policy_group_seq_id,v_policy_seq_id);

    /*IF v_Buffer_Amt < mem_used_rec.mem_buff THEN
       raise_application_error(-20853,'Buffer cannot be reduced less than utilised buffer');
    END IF;*/

  IF pol_buffer_rec.policy_type='PFL' THEN
    IF (mem_used_rec.mem_buff-v_Buffer_Amt) < nvl(mem_used_rec.used_buffer,0) or (mem_used_rec.mem_buff-v_Buffer_Amt)<0 THEN
       raise_application_error(-20853,'Buffer cannot be reduced less than utilised buffer');
    END IF;
  ELSE
     IF (mem_used_rec.mem_buff-v_Buffer_Amt) < nvl(nfl_used_rec.utilised_buff_amount,0) or (mem_used_rec.mem_buff-v_Buffer_Amt)<0 THEN
       raise_application_error(-20853,'Buffer cannot be reduced less than utilised buffer');
    END IF;
  END IF;

   IF (hr_buffer-v_hr_appr_buffer)<0 THEN
      Raise_application_error(-20856,'HR buffer deduction cannot be less than Total buffer approved');
    END IF;

    UPDATE tpa_enr_policy_member gt SET
           gt.mem_buffer_alloc=nvl(gt.mem_buffer_alloc,0)-v_Buffer_Amt
    WHERE member_seq_id=v_member_seq_id
    AND policy_group_seq_id=v_policy_group_seq_id;

  END IF;
  v_rows_processed := sql%rowcount;
  commit;
 END IF;
  end save_mem_buffer_details;
--=================================================================================================================
-- Procedure : buffer_pa_clm_yn
-- Date      : 08Jan13
-- Author    : Ravi
-- Remarks   : To check any active preauth or claims exist for deducting the buffer
--=================================================================================================================
FUNCTION buffer_pa_clm_yn(v_member_seq_id           IN tpa_enr_mem_buff_dtls.member_seq_id%TYPE,
                          v_policy_grp_seq_id       IN tpa_enr_mem_buff_dtls.policy_group_seq_id%TYPE,
                          v_policy_seq_id           IN tpa_enr_mem_buff_dtls.policy_seq_id%TYPE)
      RETURN NUMBER IS v_pa_clm_yn number(3);

  CURSOR cur_pat IS SELECT COUNT(1) FROM pat_enroll_details Q
         JOIN pat_general_details W ON (W.pat_enroll_detail_seq_id=Q.pat_enroll_detail_seq_id)
         JOIN buffer_details E ON (E.pat_gen_detail_seq_id=W.Pat_Gen_Detail_Seq_Id)
         JOIN buffer_header R ON (R.buffer_hdr_seq_id=E.Buffer_Hdr_Seq_Id)
         WHERE W.Completed_Yn='N' AND E.buffer_status_general_type_id IS NOT NULL
         AND Q.Member_Seq_Id=v_member_seq_id;

  CURSOR cur_clm IS SELECT COUNT(1) FROM clm_enroll_details T
         JOIN clm_general_details Y ON (Y.claim_seq_id=T.claim_seq_id)
         JOIN buffer_details U ON (U.Claim_Seq_Id=Y.Claim_Seq_Id)
         JOIN buffer_header I ON (I.Buffer_Hdr_Seq_Id=U.Buffer_Hdr_Seq_Id)
         WHERE Y.Completed_Yn='N' AND U.buffer_status_general_type_id IS NOT NULL
         AND T.Member_Seq_Id=v_member_seq_id;

  v_pat_ctr    number(2);
  v_clm_ctr    number(2);

BEGIN
   OPEN  cur_pat;
   FETCH cur_pat INTO v_pat_ctr;
   CLOSE cur_pat;

   OPEN  cur_clm;
   FETCH cur_clm INTO v_clm_ctr;
   CLOSE cur_clm;

    IF v_pat_ctr>0 OR v_clm_ctr>0 THEN
       Raise_application_error(-20854,'Active pre-auth/Claims exists buffer cannot be reduced');
    ELSE RETURN 0;
    END IF;

  END buffer_pa_clm_yn;
--===============================================================================================================
-- Procedure : select_add_buffer
-- Date      : 08Jan13
-- Author    : Ravi
-- Comments  : called when ADD button is executed
---=========================================================================================================
PROCEDURE select_add_buffer    (v_policy_seq_id          IN Tpa_enr_mem_buff_dtls.policy_seq_id%TYPE,
                                v_policy_group_seq_id    IN Tpa_enr_mem_buff_dtls.policy_group_seq_id%TYPE,
                                v_member_seq_id          IN Tpa_enr_mem_buff_dtls.member_seq_id%TYPE,
                                v_claim_type             IN  OUT tpa_enr_mem_buff_dtls.claim_type%TYPE,	
                                v_buffer_type            IN  OUT tpa_enr_mem_buff_dtls.Buffer_Type%TYPE,
                                v_enrollment_id          OUT VARCHAR2,
                                v_ava_cor_buffer         OUT NUMBER,
                                v_ava_fam_buffer         OUT NUMBER,
                                v_mem_buffer             OUT NUMBER) is
/*
 CURSOR fam_buffer_alloc IS 
   SELECT SUM(nvl(CASE WHEN NVL(Mem_Buffer_Alloc,0)=0 THEN NULL ELSE Mem_Buffer_Alloc END ,UTILISED_BUFF_AMOUNT)) AS mem_buffer_alloc 
         FROM ( SELECT DISTINCT K.POLICY_GROUP_SEQ_ID,L.BALANCE_SEQ_ID,k.Mem_Buffer_Alloc,0,L.UTILISED_BUFF_AMOUNT
        FROM tpa_enr_policy_member K
        JOIN TPA_ENR_BALANCE L ON (K.POLICY_GROUP_SEQ_ID=L.POLICY_GROUP_SEQ_ID)
        WHERE K.Deleted_Yn='N' and K.Policy_Group_Seq_Id=v_policy_group_seq_id);
*/
 
 CURSOR fam_buffer_alloc IS SELECT SUM(nvl(k.mem_buffer_alloc,0)) AS mem_buffer_alloc
        FROM tpa_enr_policy_member K
        WHERE K.Deleted_Yn='N' and K.Policy_Group_Seq_Id=v_policy_group_seq_id;


 CURSOR total_fam_buff_alloc IS
    select SUM(nvl(nvl(case when nvl(mem_buffer_alloc,0)=0 then NULL else mem_buffer_alloc end,CASE WHEN CONSIDER_YN='Y' THEN utilised_buff_amount ELSE 0 END ),0)) as tot_mem_buffer_alloc
        from (SELECT   g.balance_seq_id,j.mem_buffer_alloc,g.utilised_buff_amount,CASE WHEN nvl(j.mem_buffer_alloc,0)<nvl(g.utilised_buff_amount,0) then 'N' ELSE 'Y' END AS CONSIDER_YN
        FROM tpa_enr_policy_member J
        JOIN tpa_enr_policy_group F ON (F.Policy_Group_Seq_Id=j.policy_group_seq_id)
        JOIN tpa_enr_balance g on (f.policy_group_seq_id=g.policy_group_seq_id)
        WHERE F.Deleted_Yn='N' and J.Deleted_Yn='N' and F.Policy_Seq_Id=v_policy_seq_id);

 CURSOR total_nfl_buff_alloc IS
    select SUM(nvl(nvl(case when nvl(mem_buffer_alloc,0)=0 then NULL else mem_buffer_alloc end,CASE WHEN CONSIDER_YN='Y' THEN utilised_buff_amount ELSE 0 END ),0)) as tot_mem_buffer_alloc
        from (SELECT   g.balance_seq_id,j.mem_buffer_alloc,g.utilised_buff_amount,CASE WHEN nvl(j.mem_buffer_alloc,0)<nvl(g.utilised_buff_amount,0) then 'N' ELSE 'Y' END AS CONSIDER_YN
        FROM tpa_enr_policy_member J
        JOIN tpa_enr_balance g on (j.Member_Seq_Id=g.Member_Seq_Id)
        WHERE  J.Deleted_Yn='N' and g.Policy_Seq_Id=v_policy_seq_id);

               
 CURSOR pol_buffer_cur IS SELECT h.total_buffer_amount,h.buffer_allowed_yn,h.buffer_alloc_amount,h.buffer_alloc_general_type_id,h.member_buffer_yn,
        pre_auth_pkg.get_buff_level_limit(v_policy_seq_id,v_claim_type,v_buffer_type ,i.level_type) as lev_limit,h.policy_sub_general_type_id as policy_type
        FROM Tpa_enr_policy h
        join tpa_enr_policy_group i on (h.policy_seq_id=i.policy_seq_id)
        WHERE h.policy_seq_id=v_policy_seq_id
        and i.policy_group_seq_id=v_policy_group_seq_id;

 CURSOR fam_used_buff IS SELECT k.buffer_amount,k.utilised_buff_amount,(k.buffer_amount-nvl(k.utilised_buff_amount,0)) ava_fam_buff
        FROM tpa_enr_balance K
        WHERE k.policy_group_seq_id=v_policy_group_seq_id;

 CURSOR mem_used_buff IS SELECT sum(nvl(M.MEM_BUFFER_ALLOC,0)) as mem_buff, SUM(nvl(n.used_buff_amount,0)) as used_buffer
        FROM tpa_enr_policy_member m
        LEFT OUTER JOIN tpa_enr_mem_buffer n ON m.member_seq_id=n.member_seq_id
        LEFT OUTER JOIN TPA_ENR_BALANCE o on (m.member_seq_id=o.member_seq_id)
        WHERE m.Deleted_Yn='N' and m.member_seq_id=v_member_seq_id AND m.policy_group_seq_id=v_policy_group_seq_id;

 CURSOR cor_used_buff IS SELECT SUM(p.utilised_buff_amount) as cor_used_buff
        FROM tpa_enr_balance p
        WHERE P.Policy_Seq_Id=v_policy_seq_id;

 CURSOR Cur_enr_id IS SELECT Y.Tpa_Enrollment_Id FROM tpa_enr_policy_member Y
        WHERE Y.Member_Seq_Id=v_member_seq_id
        AND Y.Policy_Group_Seq_Id=v_policy_group_seq_id AND Y.Deleted_Yn='N';


     pol_buffer_rec          pol_buffer_cur%ROWTYPE;
     mem_used_rec            mem_used_buff%ROWTYPE;
     total_fam_buff_rec      total_fam_buff_alloc%ROWTYPE;
     total_nfl_buff_rec      total_fam_buff_alloc%ROWTYPE;
     fam_buffer_rec          fam_buffer_alloc%ROWTYPE;


BEGIN

IF v_claim_type='NRML' AND v_buffer_type='MEDB' THEN
 select_medical_add_buffer (v_policy_seq_id,
                            v_policy_group_seq_id,
                            v_member_seq_id,
                            v_claim_type,
                            v_buffer_type,
                            v_enrollment_id,
                            v_ava_cor_buffer,
                            v_ava_fam_buffer,
                            v_mem_buffer);


ELSIF v_claim_type='CRTL' AND v_buffer_type='CORB' THEN

select_crit_corp_add_buffer (v_policy_seq_id,
                            v_policy_group_seq_id,
                            v_member_seq_id,
                            v_claim_type,
                            v_buffer_type,
                            v_enrollment_id,
                            v_ava_cor_buffer,
                            v_ava_fam_buffer,
                            v_mem_buffer);
ELSIF v_claim_type='CRTL' AND v_buffer_type='CRTB' THEN

select_critical_add_buffer (v_policy_seq_id,
                            v_policy_group_seq_id,
                            v_member_seq_id,
                            v_claim_type,
                            v_buffer_type,
                            v_enrollment_id,
                            v_ava_cor_buffer,
                            v_ava_fam_buffer,
                            v_mem_buffer);
                            
ELSIF v_claim_type='CRTL' AND v_buffer_type='MEDB' THEN

select_crit_med_add_buffer (v_policy_seq_id,
                            v_policy_group_seq_id,
                            v_member_seq_id,
                            v_claim_type,
                            v_buffer_type,
                            v_enrollment_id,
                            v_ava_cor_buffer,
                            v_ava_fam_buffer,
                            v_mem_buffer);

ELSIF v_claim_type='NRML' AND v_buffer_type='CORB' THEN


 OPEN  pol_buffer_cur;
 FETCH pol_buffer_cur INTO pol_buffer_rec;
 CLOSE pol_buffer_cur;

 OPEN  mem_used_buff;
 FETCH mem_used_buff into mem_used_rec;
 CLOSE mem_used_buff;

IF pol_buffer_rec.Policy_Type='PFL' THEN
  
 OPEN  total_fam_buff_alloc;
 FETCH total_fam_buff_alloc INTO total_fam_buff_rec; 
 CLOSE total_fam_buff_alloc;
 
ELSIF  pol_buffer_rec.Policy_Type='PNF' THEN

 OPEN  total_nfl_buff_alloc;
 FETCH total_nfl_buff_alloc INTO total_fam_buff_rec;
 CLOSE total_nfl_buff_alloc;
 
END IF;

 OPEN  fam_buffer_alloc;
 FETCH fam_buffer_alloc into fam_buffer_rec;
 close fam_buffer_alloc;

 OPEN  Cur_enr_id;
 FETCH Cur_enr_id into v_enrollment_id;
 CLOSE Cur_enr_id;

/*  IF nvl(pol_buffer_rec.member_buffer_yn,'N')='N' OR nvl(pol_buffer_rec.total_buffer_amount,0)=0
    OR NVL(pol_buffer_rec.buffer_alloc_amount,0)=0 THEN
     Raise_application_error(-20851,'Please configure buffer details at policy level');
   END IF;
*/
 if pol_buffer_rec.buffer_alloc_general_type_id='BAF' then  
 
 v_ava_cor_buffer := pol_buffer_rec.total_buffer_amount-total_fam_buff_rec.tot_mem_buffer_alloc;
 v_ava_fam_buffer := case when pol_buffer_rec.lev_limit=0 then pol_buffer_rec.buffer_alloc_amount-fam_buffer_rec.mem_buffer_alloc else pol_buffer_rec.lev_limit-fam_buffer_rec.mem_buffer_alloc end;
 v_mem_buffer     := mem_used_rec.mem_buff;

 else
   
  v_ava_cor_buffer := pol_buffer_rec.total_buffer_amount-total_fam_buff_rec.tot_mem_buffer_alloc;
  
  v_ava_fam_buffer := case when pol_buffer_rec.lev_limit=0 then pol_buffer_rec.buffer_alloc_amount-mem_used_rec.mem_buff else pol_buffer_rec.lev_limit-mem_used_rec.mem_buff end;
  v_mem_buffer     := mem_used_rec.mem_buff;
 end if;
 
 v_ava_cor_buffer:=case when v_ava_cor_buffer<0 then 0 else v_ava_cor_buffer end;
 v_ava_fam_buffer:=case when v_ava_fam_buffer<0 then 0 else v_ava_fam_buffer end;
 
 END IF;
 END select_add_buffer;
---==================================================================================================
PROCEDURE select_buff_mem_list (v_policy_seq_id           IN tpa_enr_mem_buff_dtls.policy_seq_id%TYPE:=NULL,
                                 v_policy_group_seq_id    IN tpa_enr_mem_buff_dtls.policy_group_seq_id%TYPE:=NULL,
                                 v_member_seq_id          IN tpa_enr_mem_buff_dtls.member_seq_id%TYPE:= NULL,
                                 v_mem_buff_seq_id        IN tpa_enr_mem_buff_dtls.mem_buff_seqid%TYPE,
                                 v_sort_var               IN VARCHAR2,
                                 v_sort_order             IN VARCHAR2,
                                 v_start_num              IN NUMBER,
                                 v_end_num                IN NUMBER,
                                 v_result_set             OUT SYS_REFCURSOR) IS


     v_sql_str               VARCHAR2(4000);
     v_where                 VARCHAR2(400);

     TYPE bind_tab IS TABLE OF NUMBER index by pls_integer;

     tab_str                 bind_tab;
     i                       NUMBER(5):=0;
     v_num                   NUMBER(10);
     v_srt_var               VARCHAR2(15):='MEM_BUFF_SEQID';
     v_srt_order             VARCHAR2(3):='ASC';
     v_srt_num               NUMBER(1):=1;
     v_en_num                NUMBER(10):=100000;

BEGIN
 
 v_sql_str := 'select z.policy_seq_id,
                      z.policy_group_seq_id,
                      z.member_seq_id,
                      z.mem_buff_seqid,
                      z.reference_no,
                      z.buffer_added_date,
                      z.buffer_mode,
                      z.hr_appr_buffer,
                      z.buffer_amt,
                      z.approved_by,
                      z.remarks,
                      z.added_date,
                      x.tpa_enrollment_id,
                      v.user_id,
                      z.ava_cor_buffer,
                      z.ava_fam_buffer,
                      z.ava_mem_buffer,
                      nvl(x.mem_buffer_alloc,0) as member_buffer_alloc,
                      nvl(x.Mem_Med_Buffer_Alloc,0) as Mem_Med_Buffer_Alloc,
                      nvl(x.Mem_Crit_Buff_Alloc,0) as Mem_Crit_Buff_Alloc,
                      nvl(x.Mem_Crit_Corp_Buff_Alloc,0) as Mem_Crit_Corp_Buff_Alloc,
                      nvl(x.Mem_Crit_Med_Buff_Alloc,0) as Mem_Crit_Med_Buff_Alloc,
                      ''N'' as edit_yn,
                      Z.claim_type,
                      Z.buffer_type,
                      S.DESCRIPTION AS claim_type_desc,
                      r.description as buffer_type_desc,
                      t.description as buffer_mode_desc
                      
             FROM Tpa_enr_policy_member x
             JOIN tpa_enr_mem_buff_dtls z on (z.member_seq_id=x.member_seq_id)
             JOIN Tpa_User_Contacts c on (c.contact_seq_id=z.added_by)
             JOIN Tpa_Login_Info v on (v.contact_seq_id=c.contact_seq_id)
             LEFT OUTER JOIN TPA_GENERAL_CODE S ON (Z.CLAIM_TYPE=S.GENERAL_TYPE_ID)
             LEFT OUTER JOIN TPA_GENERAL_CODE R ON (Z.BUFFER_TYPE=R.GENERAL_TYPE_ID)
             LEFT OUTER JOIN TPA_GENERAL_CODE t ON (Z.buffer_mode=t.GENERAL_TYPE_ID)
              WHERE x.deleted_yn =''N'' ';

   IF  v_policy_seq_id IS NOT NULL THEN
       v_where := v_where ||' AND z.policy_seq_id = :v_policy_seq_id';
       i := i+1;
       tab_str(i):= v_policy_seq_id;
   END IF;

   IF  v_policy_group_seq_id IS NOT NULL THEN
       v_where := v_where ||' AND z.policy_group_seq_id = :v_policy_group_seq_id';
       i := i+1;
       tab_str(i):= v_policy_group_seq_id;
   END IF;

   IF  v_member_seq_id IS NOT NULL THEN
       v_where := v_where ||' AND z.member_seq_id = :v_member_seq_id';
       i := i+1;
       tab_str(i):= v_member_seq_id;
   END IF;

   IF  v_mem_buff_seq_id IS NOT NULL THEN
       v_where := v_where ||' AND z.mem_buff_seqid = :v_mem_buff_seq_id';
       i := i+1;
       tab_str(i):= v_mem_buff_seq_id;
   END IF;

   v_sql_str := v_sql_str||v_where;

   v_sql_str := 'SELECT * FROM
                (SELECT A.*,DENSE_RANK() OVER (ORDER BY '||v_srt_var||' '||nvl(v_sort_order,v_srt_order)||', ROWNUM) Q FROM (' ||v_sql_str|| ') A )
                 WHERE  Q>= :v_srt_num AND Q<= :v_en_num ';

    IF v_mem_buff_seq_id IS NOT NULL THEN
         OPEN v_result_set FOR v_sql_str USING tab_str(1) , v_srt_num , v_en_num ;
         v_num :=tab_str(1);
    ELSE
         OPEN v_result_set FOR v_sql_str USING tab_str(1),tab_str(2),tab_str(3) , v_srt_num , v_en_num ;
    END IF;
 END select_buff_mem_list;
--=================================================================================================================
-- Procedure : get_buffer_utilised_rpt
-- Author    : Ravi
-- Date      : 11Jan13
-- Comments  : To get the buffer utilized report for Corporate, Family, Member Levels
--=================================================================================================================
 PROCEDURE get_buffer_utilised_rpt(v_policy_seq_id          IN Tpa_enr_mem_buff_dtls.policy_seq_id%TYPE,
                                   v_policy_group_seq_id    IN Tpa_enr_mem_buff_dtls.policy_group_seq_id%TYPE,
                                   v_member_seq_id          IN Tpa_enr_mem_buff_dtls.member_seq_id%TYPE,
                                   v_sort_var               IN VARCHAR2,
                                   v_sort_order             IN VARCHAR2,
                                   v_start_num              IN NUMBER,
                                   v_end_num                IN NUMBER,
                                   v_result_set             OUT SYS_REFCURSOR)
                                   IS

  Type bind_tab IS TABLE OF NUMBER INDEX BY PLS_INTEGER;

   str_tab                  bind_tab;
   i                        NUMBER(3):=0;
   v_cor_sql_str            VARCHAR2(4000);
   v_fam_sql_str            VARCHAR2(4000);
   v_mem_sql_str            VARCHAR2(4000);
   v_where                  VARCHAR2(120);


  BEGIN

  IF v_policy_seq_id IS NOT NULL THEN
     v_where := 'AND A.policy_seq_id = :v_policy_seq_id';
     i := i+1;
     str_tab(i):= v_policy_seq_id;
  END IF;

  IF v_policy_group_seq_id IS NOT NULL THEN
     v_where := 'AND B.policy_group_seq_id = :v_policy_group_seq_id';
     i := i+1;
     str_tab(i):= v_policy_group_seq_id;
  END IF;

  IF v_member_seq_id IS NOT NULL THEN
     v_where := 'AND C.member_seq_id= :v_member_seq_id';
     i := i+1;
     str_tab(i):= v_member_seq_id;
  END IF;

   v_cor_sql_str := 'SELECT A.policy_number,A.policy_seq_id,A.enrol_type_id,A.effective_from_date,A.effective_to_date,
                            A.Buffer_Allowed_Yn,get_gen_desc(a.buffer_alloc_general_type_id,''G'') as buffer_type,
                            A.Buffer_Alloc_Amount,
                            A.Total_Buffer_Amount,SUM(nvl(C.Mem_Buffer_Alloc,0)) AS Total_buffer_allocated,
                            SUM(d.utilised_buff_amount) as Total_utilized_buffer
                     FROM tpa_enr_policy A
                     JOIN tpa_enr_policy_group B ON (B.Policy_Seq_Id=A.Policy_Seq_Id)
                     JOIN tpa_enr_policy_member C ON (C.Policy_Group_Seq_Id=B.Policy_Group_Seq_Id)
                     JOIN tpa_enr_balance D ON (D.policy_seq_id=A.policy_seq_id)
                     WHERE A.Deleted_Yn=''N''
                     AND A.Policy_Seq_Id=:v_policy_seq_id
                     GROUP BY A.policy_number,A.policy_seq_id,A.enrol_type_id,A.effective_from_date,A.effective_to_date,
                              A.Buffer_Allowed_Yn,a.buffer_alloc_general_type_id,A.Buffer_Alloc_Amount,
                              A.Total_Buffer_Amount';

   v_fam_sql_str := 'WITH buffer_alloc AS
                    (SELECT A.policy_number,A.effective_from_date,A.Effective_To_Date,A.total_buffer_amount,
                     A.buffer_alloc_general_type_id,
                     B.tpa_enrollment_number,B.employee_no,B.insured_name,
                     D.buffer_amount AS family_buffer,SUM(nvl(c.mem_buffer_alloc,0)) AS members_buffer_alloc,
                     D.utilised_buff_amount
               FROM tpa_enr_policy A
               JOIN tpa_enr_policy_group B  ON (B.policy_seq_id=A.policy_seq_id)
               JOIN tpa_enr_policy_member C ON (C.Policy_Group_Seq_Id=B.Policy_Group_Seq_Id)
               JOIN tpa_enr_balance D       ON (D.policy_group_seq_id=B.policy_group_seq_id)
               WHERE A.Deleted_Yn=''N'' AND B.deleted_yn=''N'' AND A.policy_seq_id=''2458570''
               GROUP BY A.policy_number,A.effective_from_date,A.Effective_To_Date,A.total_buffer_amount,A.buffer_alloc_general_type_id,A.Buffer_Alloc_Amount,
                        B.tpa_enrollment_number,B.employee_no,B.insured_name,
                        D.buffer_amount,D.utilised_buff_amount)
               SELECT   policy_number,tpa_enrollment_number,employee_no,insured_name,effective_from_date,Effective_To_Date,total_buffer_amount,account_info_pkg.get_gen_desc(buffer_alloc_general_type_id,''G'') as buffer_type,
                       family_buffer,members_buffer_alloc,(family_buffer-members_buffer_alloc) as unused_fam_buffer,utilised_buff_amount,
                       (decode(members_buffer_alloc,0,family_buffer,members_buffer_alloc)-utilised_buff_amount) as ava_family_buffer
               FROM buffer_alloc ';

   v_mem_sql_str := 'SELECT A.policy_number,A.effective_from_date,A.Effective_To_Date,
                     account_info_pkg.get_gen_desc(A.buffer_alloc_general_type_id,''G'') as buffer_type,
                     C.Tpa_Enrollment_Id,c.mem_name,
                     Decode(C.gender_general_type_id,''MAL'',''Male'',''FEM'',''Female'') as gender,
                     account_info_pkg.get_gen_desc(C.relship_type_id,''R'') as Relation,
                     A.total_buffer_amount AS family_buffer,nvl(c.mem_buffer_alloc,0) AS members_buffer_alloc,
                     NVL(D.Used_Buff_Amount,0) AS used_member_buffer,
                    (nvl(C.mem_buffer_alloc,0)- NVL(D.Used_Buff_Amount,0)) AS ava_mem_buffer
               FROM tpa_enr_policy A
               JOIN tpa_enr_policy_group B          ON (B.policy_seq_id=A.policy_seq_id)
               JOIN tpa_enr_policy_member C         ON (C.Policy_Group_Seq_Id=B.Policy_Group_Seq_Id)
               LEFT OUTER JOIN tpa_enr_mem_buffer D ON (D.member_seq_id= C.Member_Seq_Id)
               WHERE A.Deleted_Yn=''N'' AND B.deleted_yn=''N'' AND C.Deleted_Yn=''N'' AND A.policy_seq_id=''2458570''';

   v_cor_sql_str := 'SELECT * FROM
                (SELECT A.*,DENSE_RANK() OVER (ORDER BY '||v_sort_var||' '||v_sort_order||', ROWNUM) Q FROM (' ||v_cor_sql_str|| ') A )
                 WHERE  Q>= :v_start_num AND Q<= :v_end_num ';



   IF v_policy_seq_id IS NOT NULL AND v_policy_group_seq_id IS NULL AND v_member_seq_id IS NULL THEN

      OPEN v_result_set FOR v_cor_sql_str USING str_tab(i),v_start_num,v_end_num;

/*   ELSIF v_policy_seq_id IS NOT NULL AND v_policy_group_seq_id IS NOT NULL AND v_member_seq_id IS NULL THEN

     OPEN v_result_set FOR */

   END IF;

END get_buffer_utilised_rpt;

---======================================================================================================================
/*PROCEDURE select_buff_mem_list (v_policy_seq_id          IN tpa_enr_mem_buff_dtls.policy_seq_id%TYPE,
                                 v_policy_group_seq_id    IN tpa_enr_mem_buff_dtls.policy_group_seq_id%TYPE,
                                 v_member_seq_id          IN tpa_enr_mem_buff_dtls.member_seq_id%TYPE,
                                 v_mem_buff_seq_id        IN tpa_enr_mem_buff_dtls.mem_buff_seqid%TYPE,
                                 v_sort_var               IN VARCHAR2,
                                 v_sort_order             IN VARCHAR2,
                                 v_start_num              IN NUMBER ,
                                 v_end_num                IN NUMBER ,
                                 v_result_set             OUT SYS_REFCURSOR) IS

 CURSOR fam_buffer_alloc IS SELECT SUM(k.mem_buffer_alloc) AS mem_buffer_alloc
        FROM tpa_enr_policy_member K
        WHERE K.Deleted_Yn='N' and K.Policy_Group_Seq_Id=v_policy_group_seq_id;

 CURSOR total_fam_buff_alloc IS select SUM(J.mem_buffer_alloc) as tot_mem_buffer_alloc
        FROM tpa_enr_policy_member J
        JOIN tpa_enr_policy_group F ON (F.Policy_Group_Seq_Id=j.policy_group_seq_id)
        WHERE F.Deleted_Yn='N' and J.Deleted_Yn='N' and F.Policy_Seq_Id=v_policy_seq_id;

 CURSOR pol_buffer_cur IS SELECT h.total_buffer_amount,h.buffer_allowed_yn,h.buffer_alloc_amount
        FROM Tpa_enr_policy h
        WHERE h.policy_seq_id=v_policy_seq_id;

 CURSOR fam_used_buff IS SELECT k.buffer_amount,k.utilised_buff_amount,(k.buffer_amount-nvl(k.utilised_buff_amount,0)) ava_fam_buff
        FROM tpa_enr_balance K
        WHERE k.policy_group_seq_id=v_policy_group_seq_id;

 CURSOR mem_used_buff IS SELECT sum(m.mem_buffer_alloc) as mem_buff, SUM(nvl(n.used_buff_amount,0)) as used_buffer
        FROM tpa_enr_policy_member m
        LEFT OUTER JOIN tpa_enr_mem_buffer n ON m.member_seq_id=n.member_seq_id
        WHERE m.Deleted_Yn='N' and m.member_seq_id=v_member_seq_id AND m.policy_group_seq_id=v_policy_group_seq_id;

 CURSOR cor_used_buff IS SELECT SUM(p.utilised_buff_amount) as cor_used_buff
        FROM tpa_enr_balance p
        WHERE P.Policy_Seq_Id=v_policy_seq_id;

     pol_buffer_rec          pol_buffer_cur%ROWTYPE;
     mem_used_rec            mem_used_buff%ROWTYPE;
     total_fam_buff_rec      total_fam_buff_alloc%ROWTYPE;
     fam_buffer_rec          fam_buffer_alloc%ROWTYPE;

     v_ava_cor_buff          tpa_enr_mem_buff_dtls.buffer_amt%TYPE;
     v_ava_fam_buff          tpa_enr_mem_buff_dtls.buffer_amt%TYPE;
     v_ava_mem_buff          tpa_enr_mem_buff_dtls.buffer_amt%TYPE;

     v_sql_str               varchar2(4000);
     v_where                 varchar2(400);

     tab_str                 ttk_util_pkg.str_table_type;
     i                       number(5);

BEGIN

 OPEN  pol_buffer_cur;
 FETCH pol_buffer_cur INTO pol_buffer_rec;
 CLOSE pol_buffer_cur;

 OPEN  mem_used_buff;
 FETCH mem_used_buff into mem_used_rec;
 CLOSE mem_used_buff;

 OPEN  total_fam_buff_alloc;
 FETCH total_fam_buff_alloc INTO total_fam_buff_rec;
 CLOSE total_fam_buff_alloc;

 OPEN  fam_buffer_alloc;
 FETCH fam_buffer_alloc into fam_buffer_rec;
 close fam_buffer_alloc;

 v_ava_cor_buff :=pol_buffer_rec.total_buffer_amount-total_fam_buff_rec.tot_mem_buffer_alloc;
 v_ava_fam_buff :=pol_buffer_rec.buffer_alloc_amount-fam_buffer_rec.mem_buffer_alloc;
 v_ava_mem_buff :=mem_used_rec.mem_buff;

 v_sql_str := 'select z.policy_seq_id,
                     z.policy_group_seq_id,
                     z.member_seq_id,
                     z.mem_buff_seqid,
                     z.reference_no,
                     z.buffer_added_date,
                     z.buffer_mode,
                     z.buffer_amt,
                     z.approved_by,
                     z.remarks,
                     z.added_date,
                     x.tpa_enrollment_id,
                     v.user_id,'
                     ||v_ava_cor_buff||'as ava_cor_buffer,'
                     ||v_ava_fam_buff||'as ava_fam_buffer,'
                     ||v_ava_mem_buff||'as member_buffer_alloc
             from Tpa_enr_policy_member x
             join tpa_enr_mem_buff_dtls z on (z.member_seq_id=x.member_seq_id)
             join Tpa_User_Contacts c on (c.contact_seq_id=z.added_by)
             join Tpa_Login_Info v on (v.contact_seq_id=c.contact_seq_id)
             where x.member_seq_id=:v_member_seq_id and x.policy_group_seq_id=:v_policy_group_seq_id';

 v_sql_str := 'SELECT * FROM
            (SELECT A.*,DENSE_RANK() OVER (ORDER BY '||v_sort_var||' '||v_sort_order||',ROWNUM) Q FROM (' ||v_sql_str|| ') A )
             WHERE  Q>= :v_start_num AND Q<= :v_end_num ';

  OPEN v_result_set FOR v_sql_str USING v_member_seq_id,v_policy_group_seq_id,v_start_num , v_end_num ;

 END select_buff_mem_list;*/
 ---========================================================================================================
PROCEDURE select_medical_add_buffer(v_policy_seq_id          IN Tpa_enr_mem_buff_dtls.policy_seq_id%TYPE,
                                v_policy_group_seq_id    IN Tpa_enr_mem_buff_dtls.policy_group_seq_id%TYPE,
                                v_member_seq_id          IN Tpa_enr_mem_buff_dtls.member_seq_id%TYPE,
                                v_claim_type             IN  tpa_enr_mem_buff_dtls.claim_type%TYPE,
                                v_buffer_type            IN  tpa_enr_mem_buff_dtls.Buffer_Type%TYPE,
                                v_enrollment_id          OUT VARCHAR2,
                                v_ava_cor_buffer         OUT NUMBER,
                                v_ava_fam_buffer         OUT NUMBER,
                                v_mem_buffer             OUT NUMBER) is

 /*CURSOR fam_buffer_alloc IS 
   SELECT SUM(nvl(CASE WHEN NVL(Mem_Med_Buffer_Alloc,0)=0 THEN NULL ELSE Mem_Med_Buffer_Alloc END ,UTILISED_MED_BUFF_AMOUNT)) AS mem_buffer_alloc 
         FROM ( SELECT DISTINCT K.POLICY_GROUP_SEQ_ID,L.BALANCE_SEQ_ID,k.Mem_Med_Buffer_Alloc,0,L.UTILISED_MED_BUFF_AMOUNT
        FROM tpa_enr_policy_member K
        JOIN TPA_ENR_BALANCE L ON (K.POLICY_GROUP_SEQ_ID=L.POLICY_GROUP_SEQ_ID)
        WHERE K.Deleted_Yn='N' and K.Policy_Group_Seq_Id=v_policy_group_seq_id);
*/
CURSOR fam_buffer_alloc IS SELECT SUM(nvl(k.mem_med_buffer_alloc,0)) AS mem_buffer_alloc
        FROM tpa_enr_policy_member K
        WHERE K.Deleted_Yn='N' and K.Policy_Group_Seq_Id=v_policy_group_seq_id;


 CURSOR total_fam_buff_alloc IS
     select SUM(nvl(nvl(case when nvl(mem_med_buffer_alloc,0)=0 then NULL else mem_med_buffer_alloc end,CASE WHEN CONSIDER_YN='Y' THEN utilised_med_buff_amount ELSE 0 END ),0)) as tot_mem_buffer_alloc
        from (SELECT   g.balance_seq_id,j.mem_med_buffer_alloc,g.utilised_med_buff_amount,CASE WHEN nvl(j.mem_med_buffer_alloc,0)<nvl(g.utilised_med_buff_amount,0) then 'N' ELSE 'Y' END AS CONSIDER_YN
        FROM tpa_enr_policy_member J
        JOIN tpa_enr_policy_group F ON (F.Policy_Group_Seq_Id=j.policy_group_seq_id)
        JOIN tpa_enr_balance g on (f.policy_group_seq_id=g.policy_group_seq_id)
        WHERE F.Deleted_Yn='N' and J.Deleted_Yn='N' and F.Policy_Seq_Id=v_policy_seq_id);

CURSOR total_nfl_buff_alloc IS
     select SUM(nvl(nvl(case when nvl(mem_med_buffer_alloc,0)=0 then NULL else mem_med_buffer_alloc end,CASE WHEN CONSIDER_YN='Y' THEN utilised_med_buff_amount ELSE 0 END ),0)) as tot_mem_buffer_alloc
        from (SELECT   g.balance_seq_id,j.mem_med_buffer_alloc,g.utilised_med_buff_amount,CASE WHEN nvl(j.mem_med_buffer_alloc,0)<nvl(g.utilised_med_buff_amount,0) then 'N' ELSE 'Y' END AS CONSIDER_YN
        FROM tpa_enr_policy_member J
        JOIN tpa_enr_balance g on (j.Member_Seq_Id=g.Member_Seq_Id)
        WHERE  J.Deleted_Yn='N' and g.Policy_Seq_Id=v_policy_seq_id);

 CURSOR pol_buffer_cur IS SELECT h.tot_med_buff_amount as total_buffer_amount,h.buffer_allowed_yn,h.med_buff_alloc_amount as buffer_alloc_amount,h.buffer_alloc_general_type_id,h.member_buffer_yn,
         pre_auth_pkg.get_buff_level_limit(v_policy_seq_id,v_claim_type,v_buffer_type ,i.level_type) as lev_limit,h.policy_sub_general_type_id as policy_type
        FROM Tpa_enr_policy h
        join tpa_enr_policy_group i on (h.policy_seq_id=i.policy_seq_id)
        WHERE h.policy_seq_id=v_policy_seq_id
        and i.policy_group_seq_id=v_policy_group_seq_id;
        
 CURSOR fam_used_buff IS SELECT k.med_buffer_amount,k.utilised_med_buff_amount,(k.med_buffer_amount-nvl(k.utilised_med_buff_amount,0)) ava_fam_buff
        FROM tpa_enr_balance K
        WHERE k.policy_group_seq_id=v_policy_group_seq_id;

 CURSOR mem_used_buff IS SELECT sum(nvl(M.MEM_MED_BUFFER_ALLOC,0)) as mem_buff, SUM(nvl(n.used_med_buff_amt,0)) as used_buffer
        FROM tpa_enr_policy_member m
        LEFT OUTER JOIN tpa_enr_mem_buffer n ON m.member_seq_id=n.member_seq_id
        LEFT OUTER JOIN TPA_ENR_BALANCE o on (m.member_seq_id=o.member_seq_id)
        WHERE m.Deleted_Yn='N' and m.member_seq_id=v_member_seq_id AND m.policy_group_seq_id=v_policy_group_seq_id;

 CURSOR cor_used_buff IS SELECT SUM(p.utilised_med_buff_amount) as cor_used_buff
        FROM tpa_enr_balance p
        WHERE P.Policy_Seq_Id=v_policy_seq_id;

 CURSOR Cur_enr_id IS SELECT Y.Tpa_Enrollment_Id FROM tpa_enr_policy_member Y
        WHERE Y.Member_Seq_Id=v_member_seq_id
        AND Y.Policy_Group_Seq_Id=v_policy_group_seq_id AND Y.Deleted_Yn='N';


     pol_buffer_rec          pol_buffer_cur%ROWTYPE;
     mem_used_rec            mem_used_buff%ROWTYPE;
     total_fam_buff_rec      total_fam_buff_alloc%ROWTYPE;
     fam_buffer_rec          fam_buffer_alloc%ROWTYPE;


BEGIN

 OPEN  pol_buffer_cur;
 FETCH pol_buffer_cur INTO pol_buffer_rec;
 CLOSE pol_buffer_cur;

 OPEN  mem_used_buff;
 FETCH mem_used_buff into mem_used_rec;
 CLOSE mem_used_buff;

IF pol_buffer_rec.Policy_Type='PFL' THEN
  
 OPEN  total_fam_buff_alloc;
 FETCH total_fam_buff_alloc INTO total_fam_buff_rec; 
 CLOSE total_fam_buff_alloc;
 
ELSIF  pol_buffer_rec.Policy_Type='PNF' THEN

 OPEN  total_nfl_buff_alloc;
 FETCH total_nfl_buff_alloc INTO total_fam_buff_rec;
 CLOSE total_nfl_buff_alloc;
 
END IF;


 OPEN  fam_buffer_alloc;
 FETCH fam_buffer_alloc into fam_buffer_rec;
 close fam_buffer_alloc;

 OPEN  Cur_enr_id;
 FETCH Cur_enr_id into v_enrollment_id;
 CLOSE Cur_enr_id;

 /* IF nvl(pol_buffer_rec.member_buffer_yn,'N')='N' OR nvl(pol_buffer_rec.total_buffer_amount,0)=0
    OR NVL(pol_buffer_rec.buffer_alloc_amount,0)=0 THEN
     Raise_application_error(-20851,'Please configure buffer details at policy level');
   END IF;*/

 if pol_buffer_rec.buffer_alloc_general_type_id='BAF' then
   
 v_ava_cor_buffer := pol_buffer_rec.total_buffer_amount-total_fam_buff_rec.tot_mem_buffer_alloc;

 v_ava_fam_buffer := case when pol_buffer_rec.lev_limit=0 then pol_buffer_rec.buffer_alloc_amount-fam_buffer_rec.mem_buffer_alloc else pol_buffer_rec.lev_limit-fam_buffer_rec.mem_buffer_alloc end;
 v_mem_buffer     := mem_used_rec.mem_buff;

 else
   
  v_ava_cor_buffer := pol_buffer_rec.total_buffer_amount-total_fam_buff_rec.tot_mem_buffer_alloc;
  v_ava_fam_buffer := case when pol_buffer_rec.lev_limit=0 then pol_buffer_rec.buffer_alloc_amount-mem_used_rec.mem_buff else pol_buffer_rec.lev_limit-mem_used_rec.mem_buff end;
  v_mem_buffer     := mem_used_rec.mem_buff;
 end if;
 
 v_ava_cor_buffer:=case when v_ava_cor_buffer<0 then 0 else v_ava_cor_buffer end;
 v_ava_fam_buffer:=case when v_ava_fam_buffer<0 then 0 else v_ava_fam_buffer end;
 
 
 END select_medical_add_buffer;
 ---========================================================================================================
PROCEDURE select_critical_add_buffer(v_policy_seq_id          IN Tpa_enr_mem_buff_dtls.policy_seq_id%TYPE,
                                v_policy_group_seq_id    IN Tpa_enr_mem_buff_dtls.policy_group_seq_id%TYPE,
                                v_member_seq_id          IN Tpa_enr_mem_buff_dtls.member_seq_id%TYPE,
                                v_claim_type             IN  tpa_enr_mem_buff_dtls.claim_type%TYPE,
                                v_buffer_type            IN  tpa_enr_mem_buff_dtls.Buffer_Type%TYPE,
                                v_enrollment_id          OUT VARCHAR2,
                                v_ava_cor_buffer         OUT NUMBER,
                                v_ava_fam_buffer         OUT NUMBER,
                                v_mem_buffer             OUT NUMBER) is

/* CURSOR fam_buffer_alloc IS 
   SELECT SUM(nvl(CASE WHEN NVL(Mem_Crit_Buff_Alloc,0)=0 THEN NULL ELSE Mem_Crit_Buff_Alloc END ,UTILISED_CRIT_BUFF_AMOUNT)) AS mem_buffer_alloc 
         FROM ( SELECT DISTINCT K.POLICY_GROUP_SEQ_ID,L.BALANCE_SEQ_ID,k.Mem_Crit_Buff_Alloc,0,L.UTILISED_CRIT_BUFF_AMOUNT
        FROM tpa_enr_policy_member K
        JOIN TPA_ENR_BALANCE L ON (K.POLICY_GROUP_SEQ_ID=L.POLICY_GROUP_SEQ_ID)
        WHERE K.Deleted_Yn='N' and K.Policy_Group_Seq_Id=v_policy_group_seq_id);
*/
CURSOR fam_buffer_alloc IS SELECT SUM(nvl(k.mem_crit_buff_alloc,0)) AS mem_buffer_alloc
        FROM tpa_enr_policy_member K
        WHERE K.Deleted_Yn='N' and K.Policy_Group_Seq_Id=v_policy_group_seq_id;

 
 CURSOR total_fam_buff_alloc IS
    select SUM(nvl(nvl(case when nvl(mem_crit_buff_alloc,0)=0 then NULL else mem_crit_buff_alloc end,CASE WHEN CONSIDER_YN='Y' THEN utilised_crit_buff_amount ELSE 0 END ),0)) as tot_mem_buffer_alloc
        from (SELECT   g.balance_seq_id,j.mem_crit_buff_alloc,g.utilised_crit_buff_amount,CASE WHEN nvl(j.mem_crit_buff_alloc,0)<nvl(g.utilised_crit_buff_amount,0) then 'N' ELSE 'Y' END AS CONSIDER_YN
        FROM tpa_enr_policy_member J
        JOIN tpa_enr_policy_group F ON (F.Policy_Group_Seq_Id=j.policy_group_seq_id)
        JOIN tpa_enr_balance g on (f.policy_group_seq_id=g.policy_group_seq_id)
        WHERE F.Deleted_Yn='N' and J.Deleted_Yn='N' and F.Policy_Seq_Id=v_policy_seq_id);
 
 CURSOR total_nfl_buff_alloc IS
    select SUM(nvl(nvl(case when nvl(mem_crit_buff_alloc,0)=0 then NULL else mem_crit_buff_alloc end,CASE WHEN CONSIDER_YN='Y' THEN utilised_crit_buff_amount ELSE 0 END ),0)) as tot_mem_buffer_alloc
        from (SELECT   g.balance_seq_id,j.mem_crit_buff_alloc,g.utilised_crit_buff_amount,CASE WHEN nvl(j.mem_crit_buff_alloc,0)<nvl(g.utilised_crit_buff_amount,0) then 'N' ELSE 'Y' END AS CONSIDER_YN
        FROM tpa_enr_policy_member J
        JOIN tpa_enr_balance g on (j.Member_Seq_Id=g.Member_Seq_Id)
        WHERE  J.Deleted_Yn='N' and g.Policy_Seq_Id=v_policy_seq_id);


 CURSOR pol_buffer_cur IS SELECT h.tot_crit_buff_amount as total_buffer_amount,h.buffer_allowed_yn,h.crit_buff_alloc_amount as buffer_alloc_amount,h.buffer_alloc_general_type_id,h.member_buffer_yn,
        pre_auth_pkg.get_buff_level_limit(v_policy_seq_id,v_claim_type,v_buffer_type ,i.level_type) as lev_limit,h.policy_sub_general_type_id as policy_type
        FROM Tpa_enr_policy h
         join tpa_enr_policy_group i on (h.policy_seq_id=i.policy_seq_id)
        WHERE h.policy_seq_id=v_policy_seq_id
        and i.policy_group_seq_id=v_policy_group_seq_id;
        
 CURSOR fam_used_buff IS SELECT k.critical_buff_amount,k.utilised_crit_buff_amount,(k.critical_buff_amount-nvl(k.utilised_crit_buff_amount,0)) ava_fam_buff
        FROM tpa_enr_balance K
        WHERE k.policy_group_seq_id=v_policy_group_seq_id;

 CURSOR mem_used_buff IS SELECT sum(nvl(M.MEM_CRIT_BUFF_ALLOC,0)) as mem_buff, SUM(nvl(n.used_crit_buff_amt,0)) as used_buffer
        FROM tpa_enr_policy_member m
        LEFT OUTER JOIN tpa_enr_mem_buffer n ON m.member_seq_id=n.member_seq_id
        LEFT OUTER JOIN TPA_ENR_BALANCE o on (m.member_seq_id=o.member_seq_id)
        WHERE m.Deleted_Yn='N' and m.member_seq_id=v_member_seq_id AND m.policy_group_seq_id=v_policy_group_seq_id;

 CURSOR cor_used_buff IS SELECT SUM(p.utilised_crit_buff_amount) as cor_used_buff
        FROM tpa_enr_balance p
        WHERE P.Policy_Seq_Id=v_policy_seq_id;

 CURSOR Cur_enr_id IS SELECT Y.Tpa_Enrollment_Id FROM tpa_enr_policy_member Y
        WHERE Y.Member_Seq_Id=v_member_seq_id
        AND Y.Policy_Group_Seq_Id=v_policy_group_seq_id AND Y.Deleted_Yn='N';


     pol_buffer_rec          pol_buffer_cur%ROWTYPE;
     mem_used_rec            mem_used_buff%ROWTYPE;
     total_fam_buff_rec      total_fam_buff_alloc%ROWTYPE;
     fam_buffer_rec          fam_buffer_alloc%ROWTYPE;


BEGIN

 OPEN  pol_buffer_cur;
 FETCH pol_buffer_cur INTO pol_buffer_rec;
 CLOSE pol_buffer_cur;

 OPEN  mem_used_buff;
 FETCH mem_used_buff into mem_used_rec;
 CLOSE mem_used_buff;

 IF pol_buffer_rec.Policy_Type='PFL' THEN
  
 OPEN  total_fam_buff_alloc;
 FETCH total_fam_buff_alloc INTO total_fam_buff_rec; 
 CLOSE total_fam_buff_alloc;
 
ELSIF  pol_buffer_rec.Policy_Type='PNF' THEN

 OPEN  total_nfl_buff_alloc;
 FETCH total_nfl_buff_alloc INTO total_fam_buff_rec;
 CLOSE total_nfl_buff_alloc;
 
END IF;


 OPEN  fam_buffer_alloc;
 FETCH fam_buffer_alloc into fam_buffer_rec;
 close fam_buffer_alloc;

 OPEN  Cur_enr_id;
 FETCH Cur_enr_id into v_enrollment_id;
 CLOSE Cur_enr_id;

 /* IF nvl(pol_buffer_rec.member_buffer_yn,'N')='N' OR nvl(pol_buffer_rec.total_buffer_amount,0)=0
    OR NVL(pol_buffer_rec.buffer_alloc_amount,0)=0 THEN
     Raise_application_error(-20851,'Please configure buffer details at policy level');
   END IF;
*/
  if pol_buffer_rec.buffer_alloc_general_type_id='BAF' then
    
 v_ava_cor_buffer := pol_buffer_rec.total_buffer_amount-total_fam_buff_rec.tot_mem_buffer_alloc;
 v_ava_fam_buffer := case when pol_buffer_rec.lev_limit=0 then pol_buffer_rec.buffer_alloc_amount-fam_buffer_rec.mem_buffer_alloc else pol_buffer_rec.lev_limit-fam_buffer_rec.mem_buffer_alloc end;
 v_mem_buffer     := mem_used_rec.mem_buff;

 else
   
 v_ava_cor_buffer := pol_buffer_rec.total_buffer_amount-total_fam_buff_rec.tot_mem_buffer_alloc;  v_ava_fam_buffer := case when pol_buffer_rec.lev_limit=0 then pol_buffer_rec.buffer_alloc_amount-mem_used_rec.mem_buff else pol_buffer_rec.lev_limit-mem_used_rec.mem_buff end;
  v_mem_buffer     := mem_used_rec.mem_buff;
 end if;
 
 v_ava_cor_buffer:=case when v_ava_cor_buffer<0 then 0 else v_ava_cor_buffer end;
 v_ava_fam_buffer:=case when v_ava_fam_buffer<0 then 0 else v_ava_fam_buffer end;
 
 
 END select_critical_add_buffer;
 ---========================================================================================================
  
 PROCEDURE select_crit_corp_add_buffer    (v_policy_seq_id          IN Tpa_enr_mem_buff_dtls.policy_seq_id%TYPE,
                                v_policy_group_seq_id    IN Tpa_enr_mem_buff_dtls.policy_group_seq_id%TYPE,
                                v_member_seq_id          IN Tpa_enr_mem_buff_dtls.member_seq_id%TYPE,
                                v_claim_type             IN  tpa_enr_mem_buff_dtls.claim_type%TYPE,
                                v_buffer_type            IN  tpa_enr_mem_buff_dtls.Buffer_Type%TYPE,
                                v_enrollment_id          OUT VARCHAR2,
                                v_ava_cor_buffer         OUT NUMBER,
                                v_ava_fam_buffer         OUT NUMBER,
                                v_mem_buffer             OUT NUMBER) is

 /*CURSOR fam_buffer_alloc IS 
   SELECT SUM(nvl(CASE WHEN NVL(Mem_Crit_Corp_Buff_Alloc,0)=0 THEN NULL ELSE Mem_Crit_Corp_Buff_Alloc END ,UTILISED_CRIT_CORP_BUFF_AMT)) AS mem_buffer_alloc 
         FROM ( SELECT DISTINCT K.POLICY_GROUP_SEQ_ID,L.BALANCE_SEQ_ID,k.Mem_Crit_Corp_Buff_Alloc,0,L.UTILISED_CRIT_CORP_BUFF_AMT
        FROM tpa_enr_policy_member K
        JOIN TPA_ENR_BALANCE L ON (K.POLICY_GROUP_SEQ_ID=L.POLICY_GROUP_SEQ_ID)
        WHERE K.Deleted_Yn='N' and K.Policy_Group_Seq_Id=v_policy_group_seq_id);
*/
CURSOR fam_buffer_alloc IS SELECT SUM(nvl(k.mem_crit_corp_buff_alloc,0)) AS mem_buffer_alloc
        FROM tpa_enr_policy_member K
        WHERE K.Deleted_Yn='N' and K.Policy_Group_Seq_Id=v_policy_group_seq_id;

 
CURSOR total_fam_buff_alloc IS
   select SUM(nvl(nvl(case when nvl(mem_crit_corp_buff_alloc,0)=0 then NULL else mem_crit_corp_buff_alloc end,CASE WHEN CONSIDER_YN='Y' THEN utilised_crit_corp_buff_amt ELSE 0 END ),0)) as tot_mem_buffer_alloc
        from (SELECT   g.balance_seq_id,j.mem_crit_corp_buff_alloc,g.utilised_crit_corp_buff_amt,CASE WHEN nvl(j.mem_crit_corp_buff_alloc,0)<nvl(g.utilised_crit_corp_buff_amt,0) then 'N' ELSE 'Y' END AS CONSIDER_YN
        FROM tpa_enr_policy_member J
        JOIN tpa_enr_policy_group F ON (F.Policy_Group_Seq_Id=j.policy_group_seq_id)
        JOIN tpa_enr_balance g on (f.policy_group_seq_id=g.policy_group_seq_id)
        WHERE F.Deleted_Yn='N' and J.Deleted_Yn='N' and F.Policy_Seq_Id=v_policy_seq_id);

CURSOR total_nfl_buff_alloc IS
   select SUM(nvl(nvl(case when nvl(mem_crit_corp_buff_alloc,0)=0 then NULL else mem_crit_corp_buff_alloc end,CASE WHEN CONSIDER_YN='Y' THEN utilised_crit_corp_buff_amt ELSE 0 END ),0)) as tot_mem_buffer_alloc
        from (SELECT   g.balance_seq_id,j.mem_crit_corp_buff_alloc,g.utilised_crit_corp_buff_amt,CASE WHEN nvl(j.mem_crit_corp_buff_alloc,0)<nvl(g.utilised_crit_corp_buff_amt,0) then 'N' ELSE 'Y' END AS CONSIDER_YN
        FROM tpa_enr_policy_member J
        JOIN tpa_enr_balance g on (j.Member_Seq_Id=g.Member_Seq_Id)
        WHERE  J.Deleted_Yn='N' and g.Policy_Seq_Id=v_policy_seq_id);


 CURSOR pol_buffer_cur IS SELECT h.tot_crit_corp_buff_amount total_buffer_amount,h.buffer_allowed_yn,h.crit_corp_buff_alloc_amount buffer_alloc_amount,h.buffer_alloc_general_type_id,h.member_buffer_yn,
        pre_auth_pkg.get_buff_level_limit(v_policy_seq_id,v_claim_type,v_buffer_type ,i.level_type) as lev_limit,h.policy_sub_general_type_id as policy_type
        FROM Tpa_enr_policy h
         join tpa_enr_policy_group i on (h.policy_seq_id=i.policy_seq_id)
        WHERE h.policy_seq_id=v_policy_seq_id
        and i.policy_group_seq_id=v_policy_group_seq_id;
        
 CURSOR fam_used_buff IS SELECT k.critical_corp_buff_amount,k.utilised_crit_corp_buff_amt,(k.critical_corp_buff_amount-nvl(k.utilised_crit_corp_buff_amt,0)) ava_fam_buff
        FROM tpa_enr_balance K
        WHERE k.policy_group_seq_id=v_policy_group_seq_id;

 CURSOR mem_used_buff IS SELECT sum(nvl(M.MEM_CRIT_CORP_BUFF_ALLOC,0)) as mem_buff, SUM(nvl(n.used_crit_corp_buff_amt,0)) as used_buffer
        FROM tpa_enr_policy_member m
        LEFT OUTER JOIN tpa_enr_mem_buffer n ON m.member_seq_id=n.member_seq_id
        LEFT OUTER JOIN TPA_ENR_BALANCE o on (m.member_seq_id=o.member_seq_id)
        WHERE m.Deleted_Yn='N' and m.member_seq_id=v_member_seq_id AND m.policy_group_seq_id=v_policy_group_seq_id;

 CURSOR cor_used_buff IS SELECT SUM(p.utilised_crit_corp_buff_amt) as cor_used_buff
        FROM tpa_enr_balance p
        WHERE P.Policy_Seq_Id=v_policy_seq_id;

 CURSOR Cur_enr_id IS SELECT Y.Tpa_Enrollment_Id FROM tpa_enr_policy_member Y
        WHERE Y.Member_Seq_Id=v_member_seq_id
        AND Y.Policy_Group_Seq_Id=v_policy_group_seq_id AND Y.Deleted_Yn='N';


     pol_buffer_rec          pol_buffer_cur%ROWTYPE;
     mem_used_rec            mem_used_buff%ROWTYPE;
     total_fam_buff_rec      total_fam_buff_alloc%ROWTYPE;
     fam_buffer_rec          fam_buffer_alloc%ROWTYPE;


BEGIN

 OPEN  pol_buffer_cur;
 FETCH pol_buffer_cur INTO pol_buffer_rec;
 CLOSE pol_buffer_cur;

 OPEN  mem_used_buff;
 FETCH mem_used_buff into mem_used_rec;
 CLOSE mem_used_buff;

 IF pol_buffer_rec.Policy_Type='PFL' THEN
  
 OPEN  total_fam_buff_alloc;
 FETCH total_fam_buff_alloc INTO total_fam_buff_rec; 
 CLOSE total_fam_buff_alloc;
 
ELSIF  pol_buffer_rec.Policy_Type='PNF' THEN

 OPEN  total_nfl_buff_alloc;
 FETCH total_nfl_buff_alloc INTO total_fam_buff_rec;
 CLOSE total_nfl_buff_alloc;
 
 END IF;


 OPEN  fam_buffer_alloc;
 FETCH fam_buffer_alloc into fam_buffer_rec;
 close fam_buffer_alloc;

 OPEN  Cur_enr_id;
 FETCH Cur_enr_id into v_enrollment_id;
 CLOSE Cur_enr_id;

  /*IF nvl(pol_buffer_rec.member_buffer_yn,'N')='N' OR nvl(pol_buffer_rec.total_buffer_amount,0)=0
    OR NVL(pol_buffer_rec.buffer_alloc_amount,0)=0 THEN
     Raise_application_error(-20851,'Please configure buffer details at policy level');
   END IF;
*/

  if pol_buffer_rec.buffer_alloc_general_type_id='BAF' then

 v_ava_cor_buffer := pol_buffer_rec.total_buffer_amount-total_fam_buff_rec.tot_mem_buffer_alloc;
  v_ava_fam_buffer := case when pol_buffer_rec.lev_limit=0 then pol_buffer_rec.buffer_alloc_amount-fam_buffer_rec.mem_buffer_alloc else pol_buffer_rec.lev_limit-fam_buffer_rec.mem_buffer_alloc end;
 v_mem_buffer     := mem_used_rec.mem_buff;

 else
 v_ava_cor_buffer := pol_buffer_rec.total_buffer_amount-total_fam_buff_rec.tot_mem_buffer_alloc;
  v_ava_fam_buffer := case when pol_buffer_rec.lev_limit=0 then pol_buffer_rec.buffer_alloc_amount-mem_used_rec.mem_buff else pol_buffer_rec.lev_limit-mem_used_rec.mem_buff end;
  v_mem_buffer     := mem_used_rec.mem_buff;
 end if;
 
 v_ava_cor_buffer:=case when v_ava_cor_buffer<0 then 0 else v_ava_cor_buffer end;
 v_ava_fam_buffer:=case when v_ava_fam_buffer<0 then 0 else v_ava_fam_buffer end;
 
 
 END select_crit_corp_add_buffer;
 ---========================================================================================================
 PROCEDURE select_crit_med_add_buffer    (v_policy_seq_id          IN Tpa_enr_mem_buff_dtls.policy_seq_id%TYPE,
                                v_policy_group_seq_id    IN Tpa_enr_mem_buff_dtls.policy_group_seq_id%TYPE,
                                v_member_seq_id          IN Tpa_enr_mem_buff_dtls.member_seq_id%TYPE,
                                v_claim_type             IN  tpa_enr_mem_buff_dtls.claim_type%TYPE,
                                v_buffer_type            IN  tpa_enr_mem_buff_dtls.Buffer_Type%TYPE,
                                v_enrollment_id          OUT VARCHAR2,
                                v_ava_cor_buffer         OUT NUMBER,
                                v_ava_fam_buffer         OUT NUMBER,
                                v_mem_buffer             OUT NUMBER) is

 /*CURSOR fam_buffer_alloc IS 
   SELECT SUM(nvl(CASE WHEN NVL(Mem_Crit_Med_Buff_Alloc,0)=0 THEN NULL ELSE Mem_Crit_Med_Buff_Alloc END ,UTILISED_CRIT_MED_BUFF_AMT)) AS mem_buffer_alloc 
         FROM ( SELECT DISTINCT K.POLICY_GROUP_SEQ_ID,L.BALANCE_SEQ_ID,k.Mem_Crit_Med_Buff_Alloc,0,L.UTILISED_CRIT_MED_BUFF_AMT
        FROM tpa_enr_policy_member K
        JOIN TPA_ENR_BALANCE L ON (K.POLICY_GROUP_SEQ_ID=L.POLICY_GROUP_SEQ_ID)
        WHERE K.Deleted_Yn='N' and K.Policy_Group_Seq_Id=v_policy_group_seq_id);
*/ 
CURSOR fam_buffer_alloc IS SELECT SUM(nvl(k.mem_crit_med_buff_alloc,0)) AS mem_buffer_alloc
        FROM tpa_enr_policy_member K
        WHERE K.Deleted_Yn='N' and K.Policy_Group_Seq_Id=v_policy_group_seq_id;

 CURSOR total_fam_buff_alloc IS
     select SUM(nvl(nvl(case when nvl(mem_crit_med_buff_alloc,0)=0 then NULL else mem_crit_med_buff_alloc end,CASE WHEN CONSIDER_YN='Y' THEN utilised_crit_med_buff_amt ELSE 0 END ),0)) as tot_mem_buffer_alloc
        from (SELECT   g.balance_seq_id,j.mem_crit_med_buff_alloc,g.utilised_crit_med_buff_amt,CASE WHEN nvl(j.mem_crit_med_buff_alloc,0)<nvl(g.utilised_crit_med_buff_amt,0) then 'N' ELSE 'Y' END AS CONSIDER_YN
        FROM tpa_enr_policy_member J
        JOIN tpa_enr_policy_group F ON (F.Policy_Group_Seq_Id=j.policy_group_seq_id)
        JOIN tpa_enr_balance g on (f.policy_group_seq_id=g.policy_group_seq_id)
        WHERE F.Deleted_Yn='N' and J.Deleted_Yn='N' and F.Policy_Seq_Id=v_policy_seq_id);
        
CURSOR total_nfl_buff_alloc IS
     select SUM(nvl(nvl(case when nvl(mem_crit_med_buff_alloc,0)=0 then NULL else mem_crit_med_buff_alloc end,CASE WHEN CONSIDER_YN='Y' THEN utilised_crit_med_buff_amt ELSE 0 END ),0)) as tot_mem_buffer_alloc
        from (SELECT   g.balance_seq_id,j.mem_crit_med_buff_alloc,g.utilised_crit_med_buff_amt,CASE WHEN nvl(j.mem_crit_med_buff_alloc,0)<nvl(g.utilised_crit_med_buff_amt,0) then 'N' ELSE 'Y' END AS CONSIDER_YN
        FROM tpa_enr_policy_member J
        JOIN tpa_enr_balance g on (j.Member_Seq_Id=g.Member_Seq_Id)
        WHERE  J.Deleted_Yn='N' and g.Policy_Seq_Id=v_policy_seq_id);

 CURSOR pol_buffer_cur IS SELECT h.tot_crit_med_buff_amount total_buffer_amount,h.buffer_allowed_yn,h.crit_med_buff_alloc_amount buffer_alloc_amount,h.buffer_alloc_general_type_id,h.member_buffer_yn,
         pre_auth_pkg.get_buff_level_limit(v_policy_seq_id,v_claim_type,v_buffer_type ,i.level_type) as lev_limit,h.policy_sub_general_type_id as policy_type
        FROM Tpa_enr_policy h
        join tpa_enr_policy_group i on (h.policy_seq_id=i.policy_seq_id)
        WHERE h.policy_seq_id=v_policy_seq_id
        and i.policy_group_seq_id=v_policy_group_seq_id;
        
 CURSOR fam_used_buff IS SELECT k.critical_med_buff_amount buffer_amount,k.utilised_crit_med_buff_amt utilised_buff_amount,(k.critical_med_buff_amount-nvl(k.utilised_crit_med_buff_amt,0)) ava_fam_buff
        FROM tpa_enr_balance K
        WHERE k.policy_group_seq_id=v_policy_group_seq_id;

 CURSOR mem_used_buff IS SELECT sum(nvl(M.MEM_CRIT_MED_BUFF_ALLOC,0)) as mem_buff, SUM(nvl(n.used_crit_med_buff_amt,0)) as used_buffer
        FROM tpa_enr_policy_member m
        LEFT OUTER JOIN tpa_enr_mem_buffer n ON m.member_seq_id=n.member_seq_id
        LEFT OUTER JOIN TPA_ENR_BALANCE o on (m.member_seq_id=o.member_seq_id)
        WHERE m.Deleted_Yn='N' and m.member_seq_id=v_member_seq_id AND m.policy_group_seq_id=v_policy_group_seq_id;

 CURSOR cor_used_buff IS SELECT SUM(p.utilised_crit_med_buff_amt) as cor_used_buff
        FROM tpa_enr_balance p
        WHERE P.Policy_Seq_Id=v_policy_seq_id;

 CURSOR Cur_enr_id IS SELECT Y.Tpa_Enrollment_Id FROM tpa_enr_policy_member Y
        WHERE Y.Member_Seq_Id=v_member_seq_id
        AND Y.Policy_Group_Seq_Id=v_policy_group_seq_id AND Y.Deleted_Yn='N';


     pol_buffer_rec          pol_buffer_cur%ROWTYPE;
     mem_used_rec            mem_used_buff%ROWTYPE;
     total_fam_buff_rec      total_fam_buff_alloc%ROWTYPE;
     fam_buffer_rec          fam_buffer_alloc%ROWTYPE;


BEGIN

 OPEN  pol_buffer_cur;
 FETCH pol_buffer_cur INTO pol_buffer_rec;
 CLOSE pol_buffer_cur;

 OPEN  mem_used_buff;
 FETCH mem_used_buff into mem_used_rec;
 CLOSE mem_used_buff;

 IF pol_buffer_rec.Policy_Type='PFL' THEN
  
 OPEN  total_fam_buff_alloc;
 FETCH total_fam_buff_alloc INTO total_fam_buff_rec; 
 CLOSE total_fam_buff_alloc;
 
ELSIF  pol_buffer_rec.Policy_Type='PNF' THEN

 OPEN  total_nfl_buff_alloc;
 FETCH total_nfl_buff_alloc INTO total_fam_buff_rec;
 CLOSE total_nfl_buff_alloc;
 
 END IF;


 OPEN  fam_buffer_alloc;
 FETCH fam_buffer_alloc into fam_buffer_rec;
 close fam_buffer_alloc;

 OPEN  Cur_enr_id;
 FETCH Cur_enr_id into v_enrollment_id;
 CLOSE Cur_enr_id;

 /* IF nvl(pol_buffer_rec.member_buffer_yn,'N')='N' OR nvl(pol_buffer_rec.total_buffer_amount,0)=0
    OR NVL(pol_buffer_rec.buffer_alloc_amount,0)=0 THEN
     Raise_application_error(-20851,'Please configure buffer details at policy level');
   END IF;*/

 if pol_buffer_rec.buffer_alloc_general_type_id='BAF' then

 v_ava_cor_buffer := pol_buffer_rec.total_buffer_amount-total_fam_buff_rec.tot_mem_buffer_alloc;
 v_ava_fam_buffer := case when pol_buffer_rec.lev_limit=0 then pol_buffer_rec.buffer_alloc_amount-fam_buffer_rec.mem_buffer_alloc else pol_buffer_rec.lev_limit-fam_buffer_rec.mem_buffer_alloc end;
 v_mem_buffer     := mem_used_rec.mem_buff;

 else

 v_ava_cor_buffer := pol_buffer_rec.total_buffer_amount-total_fam_buff_rec.tot_mem_buffer_alloc;
  v_ava_fam_buffer := case when pol_buffer_rec.lev_limit=0 then pol_buffer_rec.buffer_alloc_amount-mem_used_rec.mem_buff else pol_buffer_rec.lev_limit-mem_used_rec.mem_buff end;
  v_mem_buffer     := mem_used_rec.mem_buff;
 end if;
 
 v_ava_cor_buffer:=case when v_ava_cor_buffer<0 then 0 else v_ava_cor_buffer end;
 v_ava_fam_buffer:=case when v_ava_fam_buffer<0 then 0 else v_ava_fam_buffer end;
 
 
 END select_crit_med_add_buffer;
 ---========================================================================================================
PROCEDURE save_medical_mem_buff_dtls(v_mem_buff_seqid        IN OUT Tpa_enr_mem_buff_dtls.MEM_BUFF_SEQID%TYPE ,
                                  v_policy_seq_id            IN  Tpa_enr_mem_buff_dtls.POLICY_SEQ_ID%TYPE ,
                                  v_policy_group_seq_id      IN  Tpa_enr_mem_buff_dtls.POLICY_GROUP_SEQ_ID%TYPE ,
                                  v_member_seq_id            IN  Tpa_enr_mem_buff_dtls.MEMBER_SEQ_ID%TYPE ,
                                  v_reference_no             IN  Tpa_enr_mem_buff_dtls.REFERENCE_NO%TYPE ,
                                  v_buffer_added_date        IN  Tpa_enr_mem_buff_dtls.BUFFER_ADDED_DATE%TYPE ,
                                  v_buffer_mode              IN  Tpa_enr_mem_buff_dtls.BUFFER_MODE%TYPE ,
                                  v_hr_appr_buffer           IN  Tpa_enr_mem_buff_dtls.Hr_Appr_Buffer%TYPE,
                                  v_buffer_amt               IN  Tpa_enr_mem_buff_dtls.BUFFER_AMT%TYPE ,
                                  v_approved_by              IN  Tpa_enr_mem_buff_dtls.APPROVED_BY%TYPE ,
                                  v_remarks                  IN  Tpa_enr_mem_buff_dtls.REMARKS%TYPE ,
                                  v_added_by                 IN  Tpa_enr_mem_buff_dtls.ADDED_BY%TYPE ,
                                  v_ava_cor_buffer           IN  Tpa_enr_mem_buff_dtls.Ava_Cor_Buffer%TYPE,
                                  v_ava_fam_buffer           IN  tpa_enr_mem_buff_dtls.ava_fam_buffer%TYPE,
                                  v_ava_mem_buffer           IN  tpa_enr_mem_buff_dtls.ava_mem_buffer%TYPE,
                                  v_claim_type               IN  tpa_enr_mem_buff_dtls.claim_type%TYPE,
                                  v_buffer_type              IN  tpa_enr_mem_buff_dtls.Buffer_Type%TYPE,
                                  v_alert                    OUT VARCHAR2,
                                  v_rows_processed           OUT Number) is

 CURSOR pol_buff_date_cur IS SELECT MAX(a.buffer_added_date)
       FROM Tpa_enr_buffer_details a WHERE a.policy_seq_id = v_policy_seq_id;

 CURSOR mem_buff_date_cur IS SELECT MAX(b.buffer_added_date)
        FROM Tpa_Enr_Mem_Buff_Dtls B where b.member_seq_id=v_member_seq_id
        AND b.policy_group_seq_id=v_policy_group_seq_id
        AND b.mem_buff_seqid!=v_mem_buff_seqid
        and b.buffer_type = v_buffer_type;

 CURSOR fam_buffer_alloc IS SELECT SUM(nvl(k.mem_med_buffer_alloc,0)),sum(nvl(n.used_med_buff_amt,0))
        FROM tpa_enr_policy_member K
        LEFT OUTER JOIN tpa_enr_mem_buffer n ON k.policy_group_seq_id=n.policy_group_seq_id
        WHERE K.Deleted_Yn='N' and K.Policy_Group_Seq_Id=v_policy_group_seq_id;

 CURSOR total_fam_buff_alloc IS select SUM(nvl(J.mem_med_buffer_alloc,0))
        FROM tpa_enr_policy_member J
        JOIN tpa_enr_policy_group F ON (F.Policy_Group_Seq_Id=j.policy_group_seq_id)
        WHERE F.Deleted_Yn='N' and J.Deleted_Yn='N' and F.Policy_Seq_Id=v_policy_seq_id;

 CURSOR pol_buffer_cur IS
        SELECT h.tot_crit_med_buff_amount total_buffer_amount,h.buffer_allowed_yn,
         case when pre_auth_pkg.get_buff_level_limit(h.policy_seq_id,'NRML','MEDB',i.level_type)!=0 then 
                  pre_auth_pkg.get_buff_level_limit(h.policy_seq_id,'NRML','MEDB',i.level_type)  else  h.Med_Buff_Alloc_Amount 
                  end as buffer_alloc_amount,
        h.member_buffer_yn,h.currently_uploading_yn,h.buffer_alloc_general_type_id,h.policy_sub_general_type_id AS policy_type
        FROM Tpa_enr_policy h
        JOIN tpa_enr_policy_group i on (h.policy_seq_id=i.policy_group_seq_id)
        WHERE i.policy_group_seq_id=v_policy_group_seq_id;

 CURSOR fam_used_buff IS SELECT k.med_buffer_amount,k.utilised_med_buff_amount,(k.med_buffer_amount-nvl(k.utilised_med_buff_amount,0)) ava_fam_buff
        FROM tpa_enr_balance K
        WHERE k.policy_group_seq_id=v_policy_group_seq_id;

 CURSOR mem_used_buff IS SELECT sum(nvl(m.mem_med_buffer_alloc,0)) as mem_buff, SUM(nvl(n.used_med_buff_amt,0)) as used_buffer
        FROM tpa_enr_policy_member m
        LEFT OUTER JOIN tpa_enr_mem_buffer n ON (m.member_seq_id=n.member_seq_id )
        WHERE m.Deleted_Yn='N' and m.member_seq_id=v_member_seq_id AND m.policy_group_seq_id=v_policy_group_seq_id;

 CURSOR cor_used_buff IS SELECT SUM(p.Utilised_Med_Buff_Amount) as cor_used_buff
        FROM tpa_enr_balance p
        WHERE P.Policy_Seq_Id=v_policy_seq_id;

 CURSOR nfl_used_buff IS SELECT lk.Med_Buffer_Amount,lk.Utilised_Med_Buff_Amount utilised_buff_amount
        FROM tpa_enr_balance lk
        WHERE lk.member_seq_id=v_member_seq_id;

 CURSOR hr_appr_buffer is
   SELECT SUM(decode(df.buffer_mode,'DED',-1*nvl(df.hr_appr_buffer,0),nvl(df.hr_appr_buffer,0))) as total_hr_buffer FROM tpa_enr_mem_buff_dtls df
       WHERE df.member_seq_id=v_member_seq_id
       AND df.buffer_type=v_buffer_type;

    pol_buffer_rec         pol_buffer_cur%ROWTYPE;
    fam_used_rec           fam_used_buff%ROWTYPE;
    mem_used_rec           mem_used_buff%ROWTYPE;
    cor_used_rec           cor_used_buff%ROWTYPE;
    nfl_used_rec           nfl_used_buff%ROWTYPE;
    hr_buffer              Tpa_enr_mem_buff_dtls.Hr_Appr_Buffer%TYPE;

    v_pol_last_date        DATE;
    v_mem_last_date        DATE;
    v_fam_buff_alloc       Tpa_enr_policy_member.mem_buffer_alloc%TYPE;
    v_tot_fam_buff_alloc   Tpa_enr_policy_member.mem_buffer_alloc%TYPE;
    v_pa_clm_yn            Number(3);
    v_currently_uploading_yn             TPA_ENR_POLICY.currently_uploading_yn%TYPE;
    v_fam_used_mem_buffer                tpa_enr_mem_buffer.used_buff_amount%type;

Begin

   OPEN  pol_buff_date_cur;
   FETCH pol_buff_date_cur INTO v_pol_last_date;
   CLOSE pol_buff_date_cur;

   OPEN  mem_buff_date_cur;
   FETCH mem_buff_date_cur into v_mem_last_date;
   CLOSE mem_buff_date_cur;



   OPEN  pol_buffer_cur;
   FETCH pol_buffer_cur INTO pol_buffer_rec;
   CLOSE pol_buffer_cur;

   IF pol_buffer_rec.member_buffer_yn='N' THEN
     Raise_application_error(-20851,'Please configure buffer details at policy level');
   END IF;

  policy_enrollment_pkg.check_uploading(pol_buffer_rec.currently_uploading_yn);

  IF v_Buffer_Amt<=0 or  v_hr_appr_buffer<=0 THEN
    raise_application_error(-20855,' Buffer Amount cannot be less than or equal to Zero');
  END IF;

  IF v_buffer_added_date < v_pol_last_date or v_buffer_added_date <v_mem_last_date THEN
    Raise_application_error(-20850,'Buffer added date cannot be less than policy buffer date or member buffer date');
  END IF;

  IF nvl(v_mem_buff_seqid,0)=0 Then
    INSERT INTO Tpa_enr_mem_buff_dtls(
                Mem_Buff_Seqid,
                Policy_Seq_Id,
                Policy_Group_Seq_Id,
                Member_Seq_Id,
                Reference_No,
                Buffer_Added_Date,
                Hr_Appr_Buffer,
                Buffer_Mode,
                Buffer_Amt,
                Approved_By,
                Remarks,
                Added_By,
                Added_Date,
                Ava_Cor_Buffer,
                Ava_Fam_Buffer,
                Ava_Mem_Buffer,
                User_Config,
                claim_type,
                buffer_type) VALUES
               (tpa_enr_mem_buff_dtls_seq.nextval,
                v_policy_seq_id,
                v_policy_group_seq_id,
                v_Member_Seq_Id,
                v_Reference_No,
                v_Buffer_Added_Date,
                v_hr_appr_buffer,
                v_Buffer_Mode,
                v_Buffer_Amt,
                v_Approved_By,
                v_Remarks,
                v_Added_By,
                sysdate,
                v_ava_cor_buffer,
                v_ava_fam_buffer,
                v_ava_mem_buffer,
                get_gen_desc(v_Added_By,'U'),
                v_claim_type,
                v_buffer_type
                )RETURNING Mem_Buff_Seqid INTO v_mem_buff_seqid;
 END IF;

  IF v_buffer_mode ='ADD' THEN
    OPEN  fam_buffer_alloc;
    FETCH fam_buffer_alloc INTO v_fam_buff_alloc,v_fam_used_mem_buffer;
    CLOSE fam_buffer_alloc;

    OPEN  total_fam_buff_alloc;
    FETCH total_fam_buff_alloc INTO v_tot_fam_buff_alloc;
    CLOSE total_fam_buff_alloc;

    OPEN  mem_used_buff;
    FETCH mem_used_buff into mem_used_rec;
    CLOSE mem_used_buff;

    IF pol_buffer_rec.buffer_alloc_general_type_id='BAF' Then
      IF v_buffer_amt>v_ava_fam_buffer OR
       v_buffer_amt>pol_buffer_rec.total_buffer_amount THEN
     raise_application_error(-20852,'Amount approved exceeds the Family or Corporate buffer amount');
    END IF;

    ELSE
      IF v_buffer_amt>v_ava_fam_buffer OR
         v_buffer_amt>pol_buffer_rec.total_buffer_amount Then
      raise_application_error(-20852,'Amount approved exceeds the Family or Corporate buffer amount');
       END IF;
    END IF;

     UPDATE Tpa_enr_policy_member a SET
            a.mem_med_buffer_alloc= nvl(mem_med_buffer_alloc,0)+v_buffer_amt
     WHERE member_seq_id=v_member_seq_id
     AND policy_group_seq_id=v_policy_group_seq_id;

  END IF;

  IF v_buffer_mode ='DED' THEN
     OPEN  fam_used_buff;
     FETCH fam_used_buff INTO fam_used_rec;
     CLOSE fam_used_buff;

     OPEN  mem_used_buff;
     FETCH mem_used_buff INTO mem_used_rec;
     CLOSE mem_used_buff;

     OPEN  cor_used_buff;
     FETCH cor_used_buff INTO cor_used_rec;
     CLOSE cor_used_buff;

     OPEN  nfl_used_buff;
     FETCH nfl_used_buff INTO nfl_used_rec;
     CLOSE nfl_used_buff;

    OPEN hr_appr_buffer;
    FETCH hr_appr_buffer INTO hr_buffer;
    CLOSE hr_appr_buffer;


     v_pa_clm_yn:=buffer_pa_clm_yn(v_member_seq_id,v_policy_group_seq_id,v_policy_seq_id);

    /*IF v_Buffer_Amt < mem_used_rec.mem_buff THEN
       raise_application_error(-20853,'Buffer cannot be reduced less than utilised buffer');
    END IF;*/

  IF pol_buffer_rec.policy_type='PFL' THEN
    IF (mem_used_rec.mem_buff-v_Buffer_Amt) < nvl(mem_used_rec.used_buffer,0) or (mem_used_rec.mem_buff-v_Buffer_Amt)<0 THEN
       raise_application_error(-20853,'Buffer cannot be reduced less than utilised buffer');
    END IF;
  ELSE
     IF (mem_used_rec.mem_buff-v_Buffer_Amt) < nvl(nfl_used_rec.utilised_buff_amount,0) or (mem_used_rec.mem_buff-v_Buffer_Amt)<0 THEN
       raise_application_error(-20853,'Buffer cannot be reduced less than utilised buffer');
    END IF;
  END IF;

   IF (hr_buffer-v_hr_appr_buffer)<0 THEN
      Raise_application_error(-20856,'HR buffer deduction cannot be less than Total buffer approved');
    END IF;

    UPDATE tpa_enr_policy_member gt SET
           gt.mem_med_buffer_alloc=nvl(gt.mem_med_buffer_alloc,0)-v_Buffer_Amt
    WHERE member_seq_id=v_member_seq_id
    AND policy_group_seq_id=v_policy_group_seq_id;

  END IF;
  v_rows_processed := sql%rowcount;
  commit;
  end save_medical_mem_buff_dtls;
 ---========================================================================================================
 PROCEDURE save_crit_mem_buff_dtls(v_mem_buff_seqid        IN OUT Tpa_enr_mem_buff_dtls.MEM_BUFF_SEQID%TYPE ,
                                  v_policy_seq_id            IN  Tpa_enr_mem_buff_dtls.POLICY_SEQ_ID%TYPE ,
                                  v_policy_group_seq_id      IN  Tpa_enr_mem_buff_dtls.POLICY_GROUP_SEQ_ID%TYPE ,
                                  v_member_seq_id            IN  Tpa_enr_mem_buff_dtls.MEMBER_SEQ_ID%TYPE ,
                                  v_reference_no             IN  Tpa_enr_mem_buff_dtls.REFERENCE_NO%TYPE ,
                                  v_buffer_added_date        IN  Tpa_enr_mem_buff_dtls.BUFFER_ADDED_DATE%TYPE ,
                                  v_buffer_mode              IN  Tpa_enr_mem_buff_dtls.BUFFER_MODE%TYPE ,
                                  v_hr_appr_buffer           IN  Tpa_enr_mem_buff_dtls.Hr_Appr_Buffer%TYPE,
                                  v_buffer_amt               IN  Tpa_enr_mem_buff_dtls.BUFFER_AMT%TYPE ,
                                  v_approved_by              IN  Tpa_enr_mem_buff_dtls.APPROVED_BY%TYPE ,
                                  v_remarks                  IN  Tpa_enr_mem_buff_dtls.REMARKS%TYPE ,
                                  v_added_by                 IN  Tpa_enr_mem_buff_dtls.ADDED_BY%TYPE ,
                                  v_ava_cor_buffer           IN  Tpa_enr_mem_buff_dtls.Ava_Cor_Buffer%TYPE,
                                  v_ava_fam_buffer           IN  tpa_enr_mem_buff_dtls.ava_fam_buffer%TYPE,
                                  v_ava_mem_buffer           IN  tpa_enr_mem_buff_dtls.ava_mem_buffer%TYPE,
                                  v_claim_type               IN  tpa_enr_mem_buff_dtls.claim_type%TYPE,
                                  v_buffer_type              IN  tpa_enr_mem_buff_dtls.Buffer_Type%TYPE,
                                  v_alert                    OUT VARCHAR2,
                                  v_rows_processed           OUT Number) is

 CURSOR pol_buff_date_cur IS SELECT MAX(a.buffer_added_date)
       FROM Tpa_enr_buffer_details a WHERE a.policy_seq_id = v_policy_seq_id;

 CURSOR mem_buff_date_cur IS SELECT MAX(b.buffer_added_date)
        FROM Tpa_Enr_Mem_Buff_Dtls B where b.member_seq_id=v_member_seq_id
        AND b.policy_group_seq_id=v_policy_group_seq_id
        AND b.mem_buff_seqid!=v_mem_buff_seqid
        and b.buffer_type = v_buffer_type;

 CURSOR fam_buffer_alloc IS SELECT SUM(nvl(k.mem_crit_buff_alloc,0)),sum(nvl(n.used_crit_buff_amt,0))
        FROM tpa_enr_policy_member K
        LEFT OUTER JOIN tpa_enr_mem_buffer n ON k.policy_group_seq_id=n.policy_group_seq_id
        WHERE K.Deleted_Yn='N' and K.Policy_Group_Seq_Id=v_policy_group_seq_id;

 CURSOR total_fam_buff_alloc IS select SUM(nvl(J.mem_crit_buff_alloc,0))
        FROM tpa_enr_policy_member J
        JOIN tpa_enr_policy_group F ON (F.Policy_Group_Seq_Id=j.policy_group_seq_id)
        WHERE F.Deleted_Yn='N' and J.Deleted_Yn='N' and F.Policy_Seq_Id=v_policy_seq_id;

 CURSOR pol_buffer_cur IS
        SELECT h.tot_crit_med_buff_amount total_buffer_amount,h.buffer_allowed_yn,
         case when pre_auth_pkg.get_buff_level_limit(h.policy_seq_id,'CRTL','CRTB',i.level_type)!=0 then 
                  pre_auth_pkg.get_buff_level_limit(h.policy_seq_id,'CRTL','CRTB',i.level_type)  else  h.Crit_Buff_Alloc_Amount 
                  end as buffer_alloc_amount,
        h.member_buffer_yn,h.currently_uploading_yn,h.buffer_alloc_general_type_id,h.policy_sub_general_type_id AS policy_type
        FROM Tpa_enr_policy h
        JOIN tpa_enr_policy_group i on (h.policy_seq_id=i.policy_group_seq_id)
        WHERE i.policy_group_seq_id=v_policy_group_seq_id;

 CURSOR fam_used_buff IS SELECT k.critical_buff_amount,k.utilised_crit_buff_amount,(k.critical_buff_amount-nvl(k.utilised_crit_buff_amount,0)) ava_fam_buff
        FROM tpa_enr_balance K
        WHERE k.policy_group_seq_id=v_policy_group_seq_id;

 CURSOR mem_used_buff IS SELECT sum(nvl(m.mem_crit_buff_alloc,0)) as mem_buff, SUM(nvl(n.used_crit_buff_amt,0)) as used_buffer
        FROM tpa_enr_policy_member m
        LEFT OUTER JOIN tpa_enr_mem_buffer n ON (m.member_seq_id=n.member_seq_id )
        WHERE m.Deleted_Yn='N' and m.member_seq_id=v_member_seq_id AND m.policy_group_seq_id=v_policy_group_seq_id;

 CURSOR cor_used_buff IS SELECT SUM(p.utilised_crit_buff_amount) as cor_used_buff
        FROM tpa_enr_balance p
        WHERE P.Policy_Seq_Id=v_policy_seq_id;

 CURSOR nfl_used_buff IS SELECT lk.critical_buff_amount,lk.utilised_crit_buff_amount utilised_buff_amount
        FROM tpa_enr_balance lk
        WHERE lk.member_seq_id=v_member_seq_id;

 CURSOR hr_appr_buffer is
   SELECT SUM(decode(df.buffer_mode,'DED',-1*nvl(df.hr_appr_buffer,0),nvl(df.hr_appr_buffer,0))) as total_hr_buffer FROM tpa_enr_mem_buff_dtls df
       WHERE df.member_seq_id=v_member_seq_id
       AND df.buffer_type=v_buffer_type;

    pol_buffer_rec         pol_buffer_cur%ROWTYPE;
    fam_used_rec           fam_used_buff%ROWTYPE;
    mem_used_rec           mem_used_buff%ROWTYPE;
    cor_used_rec           cor_used_buff%ROWTYPE;
    nfl_used_rec           nfl_used_buff%ROWTYPE;
    hr_buffer              Tpa_enr_mem_buff_dtls.Hr_Appr_Buffer%TYPE;

    v_pol_last_date        DATE;
    v_mem_last_date        DATE;
    v_fam_buff_alloc       Tpa_enr_policy_member.mem_buffer_alloc%TYPE;
    v_tot_fam_buff_alloc   Tpa_enr_policy_member.mem_buffer_alloc%TYPE;
    v_pa_clm_yn            Number(3);
    v_currently_uploading_yn             TPA_ENR_POLICY.currently_uploading_yn%TYPE;
    v_fam_used_mem_buffer                tpa_enr_mem_buffer.used_buff_amount%type;

Begin

   OPEN  pol_buff_date_cur;
   FETCH pol_buff_date_cur INTO v_pol_last_date;
   CLOSE pol_buff_date_cur;

   OPEN  mem_buff_date_cur;
   FETCH mem_buff_date_cur into v_mem_last_date;
   CLOSE mem_buff_date_cur;



   OPEN  pol_buffer_cur;
   FETCH pol_buffer_cur INTO pol_buffer_rec;
   CLOSE pol_buffer_cur;

   IF pol_buffer_rec.member_buffer_yn='N' THEN
     Raise_application_error(-20851,'Please configure buffer details at policy level');
   END IF;

  policy_enrollment_pkg.check_uploading(pol_buffer_rec.currently_uploading_yn);

  IF v_Buffer_Amt<=0 or  v_hr_appr_buffer<=0 THEN
    raise_application_error(-20855,' Buffer Amount cannot be less than or equal to Zero');
  END IF;

  IF v_buffer_added_date < v_pol_last_date or v_buffer_added_date <v_mem_last_date THEN
    Raise_application_error(-20850,'Buffer added date cannot be less than policy buffer date or member buffer date');
  END IF;

  IF nvl(v_mem_buff_seqid,0)=0 Then
    INSERT INTO Tpa_enr_mem_buff_dtls(
                Mem_Buff_Seqid,
                Policy_Seq_Id,
                Policy_Group_Seq_Id,
                Member_Seq_Id,
                Reference_No,
                Buffer_Added_Date,
                Hr_Appr_Buffer,
                Buffer_Mode,
                Buffer_Amt,
                Approved_By,
                Remarks,
                Added_By,
                Added_Date,
                Ava_Cor_Buffer,
                Ava_Fam_Buffer,
                Ava_Mem_Buffer,
                User_Config,
                claim_type,
                buffer_type) VALUES
               (tpa_enr_mem_buff_dtls_seq.nextval,
                v_policy_seq_id,
                v_policy_group_seq_id,
                v_Member_Seq_Id,
                v_Reference_No,
                v_Buffer_Added_Date,
                v_hr_appr_buffer,
                v_Buffer_Mode,
                v_Buffer_Amt,
                v_Approved_By,
                v_Remarks,
                v_Added_By,
                sysdate,
                v_ava_cor_buffer,
                v_ava_fam_buffer,
                v_ava_mem_buffer,
                get_gen_desc(v_Added_By,'U'),
                v_claim_type,
                v_buffer_type
                )RETURNING Mem_Buff_Seqid INTO v_mem_buff_seqid;
 END IF;

  IF v_buffer_mode ='ADD' THEN
    OPEN  fam_buffer_alloc;
    FETCH fam_buffer_alloc INTO v_fam_buff_alloc,v_fam_used_mem_buffer;
    CLOSE fam_buffer_alloc;

    OPEN  total_fam_buff_alloc;
    FETCH total_fam_buff_alloc INTO v_tot_fam_buff_alloc;
    CLOSE total_fam_buff_alloc;

    OPEN  mem_used_buff;
    FETCH mem_used_buff into mem_used_rec;
    CLOSE mem_used_buff;

    IF pol_buffer_rec.buffer_alloc_general_type_id='BAF' Then
      IF v_buffer_amt>v_ava_fam_buffer OR
       v_buffer_amt>pol_buffer_rec.total_buffer_amount THEN
     raise_application_error(-20852,'Amount approved exceeds the Family or Corporate buffer amount');
    END IF;

    ELSE
      IF v_buffer_amt>v_ava_fam_buffer OR
         v_buffer_amt>pol_buffer_rec.total_buffer_amount Then
      raise_application_error(-20852,'Amount approved exceeds the Family or Corporate buffer amount');
       END IF;
    END IF;

     UPDATE Tpa_enr_policy_member a SET
            a.mem_crit_buff_alloc= nvl(mem_crit_buff_alloc,0)+v_buffer_amt
     WHERE member_seq_id=v_member_seq_id
     AND policy_group_seq_id=v_policy_group_seq_id;

  END IF;

  IF v_buffer_mode ='DED' THEN
     OPEN  fam_used_buff;
     FETCH fam_used_buff INTO fam_used_rec;
     CLOSE fam_used_buff;

     OPEN  mem_used_buff;
     FETCH mem_used_buff INTO mem_used_rec;
     CLOSE mem_used_buff;

     OPEN  cor_used_buff;
     FETCH cor_used_buff INTO cor_used_rec;
     CLOSE cor_used_buff;

     OPEN  nfl_used_buff;
     FETCH nfl_used_buff INTO nfl_used_rec;
     CLOSE nfl_used_buff;

    OPEN hr_appr_buffer;
    FETCH hr_appr_buffer INTO hr_buffer;
    CLOSE hr_appr_buffer;


     v_pa_clm_yn:=buffer_pa_clm_yn(v_member_seq_id,v_policy_group_seq_id,v_policy_seq_id);

    /*IF v_Buffer_Amt < mem_used_rec.mem_buff THEN
       raise_application_error(-20853,'Buffer cannot be reduced less than utilised buffer');
    END IF;*/

  IF pol_buffer_rec.policy_type='PFL' THEN
    IF (mem_used_rec.mem_buff-v_Buffer_Amt) < nvl(mem_used_rec.used_buffer,0) or (mem_used_rec.mem_buff-v_Buffer_Amt)<0 THEN
       raise_application_error(-20853,'Buffer cannot be reduced less than utilised buffer');
    END IF;
  ELSE
     IF (mem_used_rec.mem_buff-v_Buffer_Amt) < nvl(nfl_used_rec.utilised_buff_amount,0) or (mem_used_rec.mem_buff-v_Buffer_Amt)<0 THEN
       raise_application_error(-20853,'Buffer cannot be reduced less than utilised buffer');
    END IF;
  END IF;

   IF (hr_buffer-v_hr_appr_buffer)<0 THEN
      Raise_application_error(-20856,'HR buffer deduction cannot be less than Total buffer approved');
    END IF;

    UPDATE tpa_enr_policy_member gt SET
           gt.mem_crit_buff_alloc=nvl(gt.mem_crit_buff_alloc,0)-v_Buffer_Amt
    WHERE member_seq_id=v_member_seq_id
    AND policy_group_seq_id=v_policy_group_seq_id;

  END IF;
  v_rows_processed := sql%rowcount;
  commit;
  end save_crit_mem_buff_dtls;
 ---========================================================================================================
  
PROCEDURE save_crit_corp_mem_buff_dtls(v_mem_buff_seqid       IN OUT Tpa_enr_mem_buff_dtls.MEM_BUFF_SEQID%TYPE ,
                                  v_policy_seq_id            IN  Tpa_enr_mem_buff_dtls.POLICY_SEQ_ID%TYPE ,
                                  v_policy_group_seq_id      IN  Tpa_enr_mem_buff_dtls.POLICY_GROUP_SEQ_ID%TYPE ,
                                  v_member_seq_id            IN  Tpa_enr_mem_buff_dtls.MEMBER_SEQ_ID%TYPE ,
                                  v_reference_no             IN  Tpa_enr_mem_buff_dtls.REFERENCE_NO%TYPE ,
                                  v_buffer_added_date        IN  Tpa_enr_mem_buff_dtls.BUFFER_ADDED_DATE%TYPE ,
                                  v_buffer_mode              IN  Tpa_enr_mem_buff_dtls.BUFFER_MODE%TYPE ,
                                  v_hr_appr_buffer           IN  Tpa_enr_mem_buff_dtls.Hr_Appr_Buffer%TYPE,
                                  v_buffer_amt               IN  Tpa_enr_mem_buff_dtls.BUFFER_AMT%TYPE ,
                                  v_approved_by              IN  Tpa_enr_mem_buff_dtls.APPROVED_BY%TYPE ,
                                  v_remarks                  IN  Tpa_enr_mem_buff_dtls.REMARKS%TYPE ,
                                  v_added_by                 IN  Tpa_enr_mem_buff_dtls.ADDED_BY%TYPE ,
                                  v_ava_cor_buffer           IN  Tpa_enr_mem_buff_dtls.Ava_Cor_Buffer%TYPE,
                                  v_ava_fam_buffer           IN  tpa_enr_mem_buff_dtls.ava_fam_buffer%TYPE,
                                  v_ava_mem_buffer           IN  tpa_enr_mem_buff_dtls.ava_mem_buffer%TYPE,
                                  v_claim_type               IN  tpa_enr_mem_buff_dtls.claim_type%TYPE,
                                  v_buffer_type              IN  tpa_enr_mem_buff_dtls.Buffer_Type%TYPE,
                                  v_alert                    OUT VARCHAR2,
                                  v_rows_processed           OUT Number) is

 CURSOR pol_buff_date_cur IS SELECT MAX(a.buffer_added_date)
       FROM Tpa_enr_buffer_details a WHERE a.policy_seq_id = v_policy_seq_id;

 CURSOR mem_buff_date_cur IS SELECT MAX(b.buffer_added_date)
        FROM Tpa_Enr_Mem_Buff_Dtls B where b.member_seq_id=v_member_seq_id
        AND b.policy_group_seq_id=v_policy_group_seq_id
        and b.buffer_type=v_buffer_type
        AND b.mem_buff_seqid!=v_mem_buff_seqid;

 CURSOR fam_buffer_alloc IS SELECT SUM(nvl(k.mem_crit_corp_buff_alloc,0)),sum(nvl(n.used_crit_corp_buff_amt,0))
        FROM tpa_enr_policy_member K
        LEFT OUTER JOIN tpa_enr_mem_buffer n ON k.policy_group_seq_id=n.policy_group_seq_id
        WHERE K.Deleted_Yn='N' and K.Policy_Group_Seq_Id=v_policy_group_seq_id;

 CURSOR total_fam_buff_alloc IS select SUM(nvl(J.mem_crit_corp_buff_alloc,0))
        FROM tpa_enr_policy_member J
        JOIN tpa_enr_policy_group F ON (F.Policy_Group_Seq_Id=j.policy_group_seq_id)
        WHERE F.Deleted_Yn='N' and J.Deleted_Yn='N' and F.Policy_Seq_Id=v_policy_seq_id;

  CURSOR pol_buffer_cur IS
        SELECT h.tot_crit_med_buff_amount total_buffer_amount,h.buffer_allowed_yn,
         case when pre_auth_pkg.get_buff_level_limit(h.policy_seq_id,'CRTL','CORB',i.level_type)!=0 then 
                  pre_auth_pkg.get_buff_level_limit(h.policy_seq_id,'CRTL','CORB',i.level_type)  else  h.crit_corp_buff_alloc_amount 
                  end as buffer_alloc_amount,
        h.member_buffer_yn,h.currently_uploading_yn,h.buffer_alloc_general_type_id,h.policy_sub_general_type_id AS policy_type
        FROM Tpa_enr_policy h
        JOIN tpa_enr_policy_group i on (h.policy_seq_id=i.policy_group_seq_id)
        WHERE i.policy_group_seq_id=v_policy_group_seq_id;

 CURSOR fam_used_buff IS SELECT k.critical_corp_buff_amount buffer_amount,k.utilised_crit_corp_buff_amt utilised_buff_amount,(k.critical_corp_buff_amount-nvl(k.utilised_crit_corp_buff_amt,0)) ava_fam_buff
        FROM tpa_enr_balance K
        WHERE k.policy_group_seq_id=v_policy_group_seq_id;

 CURSOR mem_used_buff IS SELECT sum(nvl(m.mem_crit_corp_buff_alloc,0)) as mem_buff, SUM(nvl(n.used_crit_corp_buff_amt,0)) as used_buffer
        FROM tpa_enr_policy_member m
        LEFT OUTER JOIN tpa_enr_mem_buffer n ON m.member_seq_id=n.member_seq_id
        WHERE m.Deleted_Yn='N' and m.member_seq_id=v_member_seq_id AND m.policy_group_seq_id=v_policy_group_seq_id;

 CURSOR cor_used_buff IS SELECT SUM(p.utilised_crit_corp_buff_amt) as cor_used_buff
        FROM tpa_enr_balance p
        WHERE P.Policy_Seq_Id=v_policy_seq_id;

 CURSOR nfl_used_buff IS SELECT lk.critical_corp_buff_amount buffer_amount,lk.utilised_crit_corp_buff_amt utilised_buff_amount
        FROM tpa_enr_balance lk
        WHERE lk.member_seq_id=v_member_seq_id;

 CURSOR hr_appr_buffer is
   SELECT SUM(decode(df.buffer_mode,'DED',-1*nvl(df.hr_appr_buffer,0),nvl(df.hr_appr_buffer,0))) as total_hr_buffer FROM tpa_enr_mem_buff_dtls df
       WHERE df.member_seq_id=v_member_seq_id
       AND df.buffer_type=v_buffer_type;

    pol_buffer_rec         pol_buffer_cur%ROWTYPE;
    fam_used_rec           fam_used_buff%ROWTYPE;
    mem_used_rec           mem_used_buff%ROWTYPE;
    cor_used_rec           cor_used_buff%ROWTYPE;
    nfl_used_rec           nfl_used_buff%ROWTYPE;
    hr_buffer              Tpa_enr_mem_buff_dtls.Hr_Appr_Buffer%TYPE;

    v_pol_last_date        DATE;
    v_mem_last_date        DATE;
    v_fam_buff_alloc       Tpa_enr_policy_member.mem_buffer_alloc%TYPE;
    v_tot_fam_buff_alloc   Tpa_enr_policy_member.mem_buffer_alloc%TYPE;
    v_pa_clm_yn            Number(3);
    v_currently_uploading_yn             TPA_ENR_POLICY.currently_uploading_yn%TYPE;
    v_fam_used_mem_buffer                tpa_enr_mem_buffer.used_buff_amount%type;

Begin

   OPEN  pol_buff_date_cur;
   FETCH pol_buff_date_cur INTO v_pol_last_date;
   CLOSE pol_buff_date_cur;

   OPEN  mem_buff_date_cur;
   FETCH mem_buff_date_cur into v_mem_last_date;
   CLOSE mem_buff_date_cur;



   OPEN  pol_buffer_cur;
   FETCH pol_buffer_cur INTO pol_buffer_rec;
   CLOSE pol_buffer_cur;

   IF pol_buffer_rec.member_buffer_yn='N' THEN
     Raise_application_error(-20851,'Please configure buffer details at policy level');
   END IF;

  policy_enrollment_pkg.check_uploading(pol_buffer_rec.currently_uploading_yn);

  IF v_Buffer_Amt<=0 or  v_hr_appr_buffer<=0 THEN
    raise_application_error(-20855,' Buffer Amount cannot be less than or equal to Zero');
  END IF;

  IF v_buffer_added_date < v_pol_last_date or v_buffer_added_date <v_mem_last_date THEN
    Raise_application_error(-20850,'Buffer added date cannot be less than policy buffer date or member buffer date');
  END IF;

  IF nvl(v_mem_buff_seqid,0)=0 Then
    INSERT INTO Tpa_enr_mem_buff_dtls(
                Mem_Buff_Seqid,
                Policy_Seq_Id,
                Policy_Group_Seq_Id,
                Member_Seq_Id,
                Reference_No,
                Buffer_Added_Date,
                Hr_Appr_Buffer,
                Buffer_Mode,
                Buffer_Amt,
                Approved_By,
                Remarks,
                Added_By,
                Added_Date,
                Ava_Cor_Buffer,
                Ava_Fam_Buffer,
                Ava_Mem_Buffer,
                User_Config,
                claim_type,
                buffer_type) VALUES
               (tpa_enr_mem_buff_dtls_seq.nextval,
                v_policy_seq_id,
                v_policy_group_seq_id,
                v_Member_Seq_Id,
                v_Reference_No,
                v_Buffer_Added_Date,
                v_hr_appr_buffer,
                v_Buffer_Mode,
                v_Buffer_Amt,
                v_Approved_By,
                v_Remarks,
                v_Added_By,
                sysdate,
                v_ava_cor_buffer,
                v_ava_fam_buffer,
                v_ava_mem_buffer,
                get_gen_desc(v_Added_By,'U'),
                v_claim_type,
                v_buffer_type
                )RETURNING Mem_Buff_Seqid INTO v_mem_buff_seqid;
 END IF;

  IF v_buffer_mode ='ADD' THEN
    OPEN  fam_buffer_alloc;
    FETCH fam_buffer_alloc INTO v_fam_buff_alloc,v_fam_used_mem_buffer;
    CLOSE fam_buffer_alloc;

    OPEN  total_fam_buff_alloc;
    FETCH total_fam_buff_alloc INTO v_tot_fam_buff_alloc;
    CLOSE total_fam_buff_alloc;

    OPEN  mem_used_buff;
    FETCH mem_used_buff into mem_used_rec;
    CLOSE mem_used_buff;

    IF pol_buffer_rec.buffer_alloc_general_type_id='BAF' Then
      IF v_buffer_amt>v_ava_fam_buffer OR
      v_buffer_amt>pol_buffer_rec.total_buffer_amount THEN
     raise_application_error(-20852,'Amount approved exceeds the Family or Corporate buffer amount');
    END IF;

    ELSE
      IF v_buffer_amt>v_ava_fam_buffer OR
         v_buffer_amt>pol_buffer_rec.total_buffer_amount Then
      raise_application_error(-20852,'Amount approved exceeds the Family or Corporate buffer amount');
       END IF;
    END IF;

     UPDATE Tpa_enr_policy_member a SET
            a.mem_crit_corp_buff_alloc= nvl(mem_crit_corp_buff_alloc,0)+v_buffer_amt
     WHERE member_seq_id=v_member_seq_id
     AND policy_group_seq_id=v_policy_group_seq_id;

  END IF;

  IF v_buffer_mode ='DED' THEN
     OPEN  fam_used_buff;
     FETCH fam_used_buff INTO fam_used_rec;
     CLOSE fam_used_buff;

     OPEN  mem_used_buff;
     FETCH mem_used_buff INTO mem_used_rec;
     CLOSE mem_used_buff;

     OPEN  cor_used_buff;
     FETCH cor_used_buff INTO cor_used_rec;
     CLOSE cor_used_buff;

     OPEN  nfl_used_buff;
     FETCH nfl_used_buff INTO nfl_used_rec;
     CLOSE nfl_used_buff;

    OPEN hr_appr_buffer;
    FETCH hr_appr_buffer INTO hr_buffer;
    CLOSE hr_appr_buffer;


     v_pa_clm_yn:=buffer_pa_clm_yn(v_member_seq_id,v_policy_group_seq_id,v_policy_seq_id);

    /*IF v_Buffer_Amt < mem_used_rec.mem_buff THEN
       raise_application_error(-20853,'Buffer cannot be reduced less than utilised buffer');
    END IF;*/

  IF pol_buffer_rec.policy_type='PFL' THEN
    IF (mem_used_rec.mem_buff-v_Buffer_Amt) < nvl(mem_used_rec.used_buffer,0) or (mem_used_rec.mem_buff-v_Buffer_Amt)<0 THEN
       raise_application_error(-20853,'Buffer cannot be reduced less than utilised buffer');
    END IF;
  ELSE
     IF (mem_used_rec.mem_buff-v_Buffer_Amt) < nvl(nfl_used_rec.utilised_buff_amount,0) or (mem_used_rec.mem_buff-v_Buffer_Amt)<0 THEN
       raise_application_error(-20853,'Buffer cannot be reduced less than utilised buffer');
    END IF;
  END IF;

   IF (hr_buffer-v_hr_appr_buffer)<0 THEN
      Raise_application_error(-20856,'HR buffer deduction cannot be less than Total buffer approved');
    END IF;

    UPDATE tpa_enr_policy_member gt SET
           gt.mem_crit_corp_buff_alloc=nvl(gt.mem_crit_corp_buff_alloc,0)-v_Buffer_Amt
    WHERE member_seq_id=v_member_seq_id
    AND policy_group_seq_id=v_policy_group_seq_id;

  END IF;
  v_rows_processed := sql%rowcount;
  commit;
  end save_crit_corp_mem_buff_dtls;
 ---========================================================================================================
PROCEDURE save_crit_med_mem_buff_dtls(v_mem_buff_seqid       IN OUT Tpa_enr_mem_buff_dtls.MEM_BUFF_SEQID%TYPE ,
                                  v_policy_seq_id            IN  Tpa_enr_mem_buff_dtls.POLICY_SEQ_ID%TYPE ,
                                  v_policy_group_seq_id      IN  Tpa_enr_mem_buff_dtls.POLICY_GROUP_SEQ_ID%TYPE ,
                                  v_member_seq_id            IN  Tpa_enr_mem_buff_dtls.MEMBER_SEQ_ID%TYPE ,
                                  v_reference_no             IN  Tpa_enr_mem_buff_dtls.REFERENCE_NO%TYPE ,
                                  v_buffer_added_date        IN  Tpa_enr_mem_buff_dtls.BUFFER_ADDED_DATE%TYPE ,
                                  v_buffer_mode              IN  Tpa_enr_mem_buff_dtls.BUFFER_MODE%TYPE ,
                                  v_hr_appr_buffer           IN  Tpa_enr_mem_buff_dtls.Hr_Appr_Buffer%TYPE,
                                  v_buffer_amt               IN  Tpa_enr_mem_buff_dtls.BUFFER_AMT%TYPE ,
                                  v_approved_by              IN  Tpa_enr_mem_buff_dtls.APPROVED_BY%TYPE ,
                                  v_remarks                  IN  Tpa_enr_mem_buff_dtls.REMARKS%TYPE ,
                                  v_added_by                 IN  Tpa_enr_mem_buff_dtls.ADDED_BY%TYPE ,
                                  v_ava_cor_buffer           IN  Tpa_enr_mem_buff_dtls.Ava_Cor_Buffer%TYPE,
                                  v_ava_fam_buffer           IN  tpa_enr_mem_buff_dtls.ava_fam_buffer%TYPE,
                                  v_ava_mem_buffer           IN  tpa_enr_mem_buff_dtls.ava_mem_buffer%TYPE,
                                  v_claim_type               IN  tpa_enr_mem_buff_dtls.claim_type%TYPE,
                                  v_buffer_type              IN  tpa_enr_mem_buff_dtls.Buffer_Type%TYPE,
                                  v_alert                    OUT VARCHAR2,
                                  v_rows_processed           OUT Number) is

 CURSOR pol_buff_date_cur IS SELECT MAX(a.buffer_added_date)
       FROM Tpa_enr_buffer_details a WHERE a.policy_seq_id = v_policy_seq_id;

 CURSOR mem_buff_date_cur IS SELECT MAX(b.buffer_added_date)
        FROM Tpa_Enr_Mem_Buff_Dtls B where b.member_seq_id=v_member_seq_id
        AND b.policy_group_seq_id=v_policy_group_seq_id
        and b.buffer_type=v_buffer_type
        AND b.mem_buff_seqid!=v_mem_buff_seqid;

 CURSOR fam_buffer_alloc IS SELECT SUM(nvl(k.mem_crit_med_buff_alloc,0)),sum(nvl(n.used_crit_med_buff_amt,0))
        FROM tpa_enr_policy_member K
        LEFT OUTER JOIN tpa_enr_mem_buffer n ON k.policy_group_seq_id=n.policy_group_seq_id
        WHERE K.Deleted_Yn='N' and K.Policy_Group_Seq_Id=v_policy_group_seq_id;

 CURSOR total_fam_buff_alloc IS select SUM(nvl(J.mem_crit_med_buff_alloc,0))
        FROM tpa_enr_policy_member J
        JOIN tpa_enr_policy_group F ON (F.Policy_Group_Seq_Id=j.policy_group_seq_id)
        WHERE F.Deleted_Yn='N' and J.Deleted_Yn='N' and F.Policy_Seq_Id=v_policy_seq_id;

 CURSOR pol_buffer_cur IS
        SELECT h.tot_crit_med_buff_amount total_buffer_amount,h.buffer_allowed_yn,
         case when pre_auth_pkg.get_buff_level_limit(h.policy_seq_id,'CRTL','MEDB',i.level_type)!=0 then 
                  pre_auth_pkg.get_buff_level_limit(h.policy_seq_id,'CRTL','MEDB',i.level_type)  else  h.crit_med_buff_alloc_amount 
                  end as buffer_alloc_amount,
        h.member_buffer_yn,h.currently_uploading_yn,h.buffer_alloc_general_type_id,h.policy_sub_general_type_id AS policy_type
        FROM Tpa_enr_policy h
        JOIN tpa_enr_policy_group i on (h.policy_seq_id=i.policy_group_seq_id)
        WHERE i.policy_group_seq_id=v_policy_group_seq_id;

 CURSOR fam_used_buff IS SELECT k.critical_med_buff_amount buffer_amount,k.utilised_crit_med_buff_amt utilised_buff_amount,(k.critical_med_buff_amount-nvl(k.utilised_crit_med_buff_amt,0)) ava_fam_buff
        FROM tpa_enr_balance K
        WHERE k.policy_group_seq_id=v_policy_group_seq_id;

 CURSOR mem_used_buff IS SELECT sum(nvl(m.mem_crit_med_buff_alloc,0)) as mem_buff, SUM(nvl(n.used_crit_med_buff_amt,0)) as used_buffer
        FROM tpa_enr_policy_member m
        LEFT OUTER JOIN tpa_enr_mem_buffer n ON m.member_seq_id=n.member_seq_id
        WHERE m.Deleted_Yn='N' and m.member_seq_id=v_member_seq_id AND m.policy_group_seq_id=v_policy_group_seq_id;

 CURSOR cor_used_buff IS SELECT SUM(p.utilised_crit_med_buff_amt) as cor_used_buff
        FROM tpa_enr_balance p
        WHERE P.Policy_Seq_Id=v_policy_seq_id;

 CURSOR nfl_used_buff IS SELECT lk.critical_med_buff_amount buffer_amount,lk.utilised_crit_med_buff_amt utilised_buff_amount
        FROM tpa_enr_balance lk
        WHERE lk.member_seq_id=v_member_seq_id;

 CURSOR hr_appr_buffer is
   SELECT SUM(decode(df.buffer_mode,'DED',-1*nvl(df.hr_appr_buffer,0),nvl(df.hr_appr_buffer,0))) as total_hr_buffer FROM tpa_enr_mem_buff_dtls df
       WHERE df.member_seq_id=v_member_seq_id
       AND df.buffer_type=v_buffer_type;

    pol_buffer_rec         pol_buffer_cur%ROWTYPE;
    fam_used_rec           fam_used_buff%ROWTYPE;
    mem_used_rec           mem_used_buff%ROWTYPE;
    cor_used_rec           cor_used_buff%ROWTYPE;
    nfl_used_rec           nfl_used_buff%ROWTYPE;
    hr_buffer              Tpa_enr_mem_buff_dtls.Hr_Appr_Buffer%TYPE;

    v_pol_last_date        DATE;
    v_mem_last_date        DATE;
    v_fam_buff_alloc       Tpa_enr_policy_member.mem_buffer_alloc%TYPE;
    v_tot_fam_buff_alloc   Tpa_enr_policy_member.mem_buffer_alloc%TYPE;
    v_pa_clm_yn            Number(3);
    v_currently_uploading_yn             TPA_ENR_POLICY.currently_uploading_yn%TYPE;
    v_fam_used_mem_buffer                tpa_enr_mem_buffer.used_buff_amount%type;

Begin

   OPEN  pol_buff_date_cur;
   FETCH pol_buff_date_cur INTO v_pol_last_date;
   CLOSE pol_buff_date_cur;

   OPEN  mem_buff_date_cur;
   FETCH mem_buff_date_cur into v_mem_last_date;
   CLOSE mem_buff_date_cur;



   OPEN  pol_buffer_cur;
   FETCH pol_buffer_cur INTO pol_buffer_rec;
   CLOSE pol_buffer_cur;

   IF pol_buffer_rec.member_buffer_yn='N' THEN
     Raise_application_error(-20851,'Please configure buffer details at policy level');
   END IF;

  policy_enrollment_pkg.check_uploading(pol_buffer_rec.currently_uploading_yn);

  IF v_Buffer_Amt<=0 or  v_hr_appr_buffer<=0 THEN
    raise_application_error(-20855,' Buffer Amount cannot be less than or equal to Zero');
  END IF;

  IF v_buffer_added_date < v_pol_last_date or v_buffer_added_date <v_mem_last_date THEN
    Raise_application_error(-20850,'Buffer added date cannot be less than policy buffer date or member buffer date');
  END IF;

  IF nvl(v_mem_buff_seqid,0)=0 Then
    INSERT INTO Tpa_enr_mem_buff_dtls(
                Mem_Buff_Seqid,
                Policy_Seq_Id,
                Policy_Group_Seq_Id,
                Member_Seq_Id,
                Reference_No,
                Buffer_Added_Date,
                Hr_Appr_Buffer,
                Buffer_Mode,
                Buffer_Amt,
                Approved_By,
                Remarks,
                Added_By,
                Added_Date,
                Ava_Cor_Buffer,
                Ava_Fam_Buffer,
                Ava_Mem_Buffer,
                User_Config,
                claim_type,
                buffer_type) VALUES
               (tpa_enr_mem_buff_dtls_seq.nextval,
                v_policy_seq_id,
                v_policy_group_seq_id,
                v_Member_Seq_Id,
                v_Reference_No,
                v_Buffer_Added_Date,
                v_hr_appr_buffer,
                v_Buffer_Mode,
                v_Buffer_Amt,
                v_Approved_By,
                v_Remarks,
                v_Added_By,
                sysdate,
                v_ava_cor_buffer,
                v_ava_fam_buffer,
                v_ava_mem_buffer,
                get_gen_desc(v_Added_By,'U'),
                v_claim_type,
                v_buffer_type
                )RETURNING Mem_Buff_Seqid INTO v_mem_buff_seqid;
 END IF;

  IF v_buffer_mode ='ADD' THEN
    OPEN  fam_buffer_alloc;
    FETCH fam_buffer_alloc INTO v_fam_buff_alloc,v_fam_used_mem_buffer;
    CLOSE fam_buffer_alloc;

    OPEN  total_fam_buff_alloc;
    FETCH total_fam_buff_alloc INTO v_tot_fam_buff_alloc;
    CLOSE total_fam_buff_alloc;

    OPEN  mem_used_buff;
    FETCH mem_used_buff into mem_used_rec;
    CLOSE mem_used_buff;

    IF pol_buffer_rec.buffer_alloc_general_type_id='BAF' Then
      IF v_buffer_amt>v_ava_fam_buffer OR
       v_buffer_amt>pol_buffer_rec.total_buffer_amount THEN
     raise_application_error(-20852,'Amount approved exceeds the Family or Corporate buffer amount');
    END IF;

    ELSE
      IF v_buffer_amt>pol_buffer_rec.buffer_alloc_amount OR
         v_buffer_amt>v_ava_fam_buffer Then
      raise_application_error(-20852,'Amount approved exceeds the Family or Corporate buffer amount');
       END IF;
    END IF;

     UPDATE Tpa_enr_policy_member a SET
            a.mem_crit_med_buff_alloc= nvl(mem_crit_med_buff_alloc,0)+v_buffer_amt
     WHERE member_seq_id=v_member_seq_id
     AND policy_group_seq_id=v_policy_group_seq_id;

  END IF;

  IF v_buffer_mode ='DED' THEN
     OPEN  fam_used_buff;
     FETCH fam_used_buff INTO fam_used_rec;
     CLOSE fam_used_buff;

     OPEN  mem_used_buff;
     FETCH mem_used_buff INTO mem_used_rec;
     CLOSE mem_used_buff;

     OPEN  cor_used_buff;
     FETCH cor_used_buff INTO cor_used_rec;
     CLOSE cor_used_buff;

     OPEN  nfl_used_buff;
     FETCH nfl_used_buff INTO nfl_used_rec;
     CLOSE nfl_used_buff;

    OPEN hr_appr_buffer;
    FETCH hr_appr_buffer INTO hr_buffer;
    CLOSE hr_appr_buffer;


     v_pa_clm_yn:=buffer_pa_clm_yn(v_member_seq_id,v_policy_group_seq_id,v_policy_seq_id);

    /*IF v_Buffer_Amt < mem_used_rec.mem_buff THEN
       raise_application_error(-20853,'Buffer cannot be reduced less than utilised buffer');
    END IF;*/

  IF pol_buffer_rec.policy_type='PFL' THEN
    IF (mem_used_rec.mem_buff-v_Buffer_Amt) < nvl(mem_used_rec.used_buffer,0) or (mem_used_rec.mem_buff-v_Buffer_Amt)<0 THEN
       raise_application_error(-20853,'Buffer cannot be reduced less than utilised buffer');
    END IF;
  ELSE
     IF (mem_used_rec.mem_buff-v_Buffer_Amt) < nvl(nfl_used_rec.utilised_buff_amount,0) or (mem_used_rec.mem_buff-v_Buffer_Amt)<0 THEN
       raise_application_error(-20853,'Buffer cannot be reduced less than utilised buffer');
    END IF;
  END IF;

   IF (hr_buffer-v_hr_appr_buffer)<0 THEN
      Raise_application_error(-20856,'HR buffer deduction cannot be less than Total buffer approved');
    END IF;

    UPDATE tpa_enr_policy_member gt SET
           gt.mem_crit_med_buff_alloc=nvl(gt.mem_crit_med_buff_alloc,0)-v_Buffer_Amt
    WHERE member_seq_id=v_member_seq_id
    AND policy_group_seq_id=v_policy_group_seq_id;

  END IF;
  v_rows_processed := sql%rowcount;
  commit;
  end save_crit_med_mem_buff_dtls;
 ---========================================================================================================
      
END account_info_pkg;

/

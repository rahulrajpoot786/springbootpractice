--------------------------------------------------------
--  DDL for Synonymn CLM_BULK_UPLD_CLM_DETAILS
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."CLM_BULK_UPLD_CLM_DETAILS" FOR "APP"."CLM_BULK_UPLD_CLM_DETAILS";

--------------------------------------------------------
--  DDL for Synonymn CLM_LOG_SEQ
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."CLM_LOG_SEQ" FOR "APP"."CLM_LOG_SEQ";

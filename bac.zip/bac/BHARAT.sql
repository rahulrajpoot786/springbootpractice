--------------------------------------------------------
--  DDL for Synonymn BHARAT
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."BHARAT" FOR "APP"."BHARAT";

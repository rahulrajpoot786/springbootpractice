--------------------------------------------------------
--  DDL for Synonymn IDX_BALANCEMISMATCH_POLSEQ
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."IDX_BALANCEMISMATCH_POLSEQ" FOR "APP"."IDX_BALANCEMISMATCH_POLSEQ";

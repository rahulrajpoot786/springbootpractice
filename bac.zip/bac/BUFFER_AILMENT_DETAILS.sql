--------------------------------------------------------
--  DDL for Synonymn BUFFER_AILMENT_DETAILS
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."BUFFER_AILMENT_DETAILS" FOR "APP"."BUFFER_AILMENT_DETAILS";

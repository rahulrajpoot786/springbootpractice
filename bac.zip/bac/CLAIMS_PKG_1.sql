--------------------------------------------------------
--  DDL for Package CLAIMS_PKG
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "VENUBABU"."CLAIMS_PKG" IS

  -- Author  : SREERAJ_SV
  -- Created : 7/15/2006 12:29:06 PM
  -- Purpose : contains procedures and function for claim processing
  -- Public function and procedure declarations

type buff_type is record
(buff_amt            tpa_enr_balance.buffer_amount%type,
med_buff_amt         tpa_enr_balance.buffer_amount%type,
crit_buff_amt        tpa_enr_balance.buffer_amount%type,
crit_corp_buff_amt   tpa_enr_balance.buffer_amount%type,
crit_med_buff_amt    tpa_enr_balance.buffer_amount%type);

buff_amts_rec          buff_type;

  PROCEDURE save_clm_inward_entry (
    v_claims_inward_seq_id             IN OUT CLM_INWARD.claims_inward_seq_id%TYPE,
    v_tpa_office_seq_id                IN CLM_INWARD.tpa_office_seq_id%TYPE,
    v_barcode_no                       IN CLM_INWARD.barcode_no%TYPE,
    v_document_general_type_id         IN CLM_INWARD.document_general_type_id%TYPE,
    v_rcvd_date                        IN CLM_INWARD.rcvd_date%TYPE,
    v_source_general_type_id           IN CLM_INWARD.source_general_type_id%TYPE,
    v_claim_general_type_id            IN CLM_INWARD.claim_general_type_id%TYPE,
    v_requested_amount                 IN CLM_GENERAL_DETAILS.Requested_Amount%TYPE,
    v_member_seq_id                    IN CLM_ENROLL_DETAILS.member_seq_id%TYPE,
    v_tpa_enrollment_id                IN CLM_ENROLL_DETAILS.tpa_enrollment_id%TYPE,
    v_claimant_name                    IN CLM_ENROLL_DETAILS.claimant_name%TYPE,
    v_policy_seq_id                    IN CLM_ENROLL_DETAILS.policy_seq_id%TYPE,
    v_policy_number                    IN CLM_ENROLL_DETAILS.policy_number%TYPE,
    v_inward_ins_seq_id                IN CLM_INWARD.inward_ins_seq_id%TYPE,
    v_corporate_name                   IN CLM_INWARD.corporate_name%TYPE,
    v_policy_holder_name               IN CLM_ENROLL_DETAILS.policy_holder_name%TYPE,
    v_employee_no                      IN CLM_ENROLL_DETAILS.employee_no%TYPE,
    v_employee_name                    IN CLM_ENROLL_DETAILS.employee_name%TYPE,
    v_inward_stat_general_type_id      IN CLM_INWARD.inward_status_general_type_id%TYPE,
    v_remarks                          IN CLM_INWARD.remarks%TYPE,
    v_courier_seq_id                   IN CLM_INWARD.courier_seq_id%TYPE,
    v_parent_claim_seq_id              IN OUT CLM_INWARD.claim_seq_id%TYPE,
    v_claim_number                     IN CLM_INWARD.claim_number%TYPE,
    v_shortfall_id                     IN CLM_INWARD.shortfall_id%TYPE,
    v_clm_seq_id                       IN OUT CLM_GENERAL_DETAILS.claim_seq_id%TYPE,  -- CLAIM_SEQ_ID from list grid ( For Edit Only)
    v_clm_enroll_detail_seq_id         IN OUT CLM_ENROLL_DETAILS.clm_enroll_detail_seq_id%TYPE, -- CLM_ENROLL_DETAIL_SEQ_ID from list grid ( For Edit Only)
    v_email_id                         IN  CLM_ENROLL_DETAILS.email_id%TYPE,
    v_notification_phone_number        IN  CLM_ENROLL_DETAILS.notification_phone_number%TYPE,
    v_ins_scheme                       IN CLM_ENROLL_DETAILS.ins_scheme%TYPE,
    v_certificate_no                   IN CLM_ENROLL_DETAILS.certificate_no%TYPE,
    v_ins_customer_code                IN CLM_ENROLL_DETAILS.ins_customer_code%TYPE,
    v_added_by                         IN CLM_INWARD.added_by%TYPE,
    v_rows_processed                   OUT NUMBER
  );
-- =================================================================================================================
  PROCEDURE save_clm_enroll(
    v_clm_enroll_detail_seq_id           IN  OUT CLM_ENROLL_DETAILS.clm_enroll_detail_seq_id%TYPE,
    v_claim_seq_id                       IN  CLM_ENROLL_DETAILS.claim_seq_id%TYPE,
    v_gender_general_type_id             IN  CLM_ENROLL_DETAILS.gender_general_type_id%TYPE,
    v_member_seq_id                      IN  CLM_ENROLL_DETAILS.member_seq_id%TYPE,
    v_tpa_enrollment_id                  IN  CLM_ENROLL_DETAILS.tpa_enrollment_id%TYPE,
    v_policy_seq_id                      IN  CLM_ENROLL_DETAILS.policy_seq_id%TYPE,
    v_policy_holder_name                 IN  CLM_ENROLL_DETAILS.policy_holder_name%TYPE,
    v_employee_no                        IN  CLM_ENROLL_DETAILS.employee_no%TYPE,
    v_employee_name                      IN  CLM_ENROLL_DETAILS.employee_name%TYPE,
    v_mem_age                            IN  CLM_ENROLL_DETAILS.mem_age%TYPE,
    v_claimant_name                      IN  CLM_ENROLL_DETAILS.claimant_name%TYPE,
    v_date_of_inception                  IN  CLM_ENROLL_DETAILS.date_of_inception%TYPE,
    v_date_of_exit                       IN  CLM_ENROLL_DETAILS.date_of_exit%TYPE,
    v_relship_type_id                    IN  CLM_ENROLL_DETAILS.relship_type_id%TYPE,
    v_policy_number                      IN  CLM_ENROLL_DETAILS.policy_number%TYPE,
    v_claimant_phone_number              IN  CLM_ENROLL_DETAILS.claimant_phone_number%TYPE,
    v_mem_total_sum_insured              IN  CLM_ENROLL_DETAILS.mem_total_sum_insured%TYPE,
    v_enrol_type_id                      IN  CLM_ENROLL_DETAILS.enrol_type_id%TYPE,
    v_policy_sub_general_type_id         IN  CLM_ENROLL_DETAILS.policy_sub_general_type_id%TYPE,
    v_phone_1                            IN  CLM_ENROLL_DETAILS.phone_1%TYPE,
    v_policy_effective_from              IN  CLM_ENROLL_DETAILS.policy_effective_from%TYPE,
    v_policy_effective_to                IN  CLM_ENROLL_DETAILS.policy_effective_to%TYPE,
    v_ins_status_general_type_id         IN  CLM_ENROLL_DETAILS.ins_status_general_type_id%TYPE,
    v_ins_seq_id                         IN  CLM_ENROLL_DETAILS.ins_seq_id%TYPE,
    v_group_reg_seq_id                   IN  CLM_ENROLL_DETAILS.group_reg_seq_id%TYPE,
    v_email_id                           IN  CLM_ENROLL_DETAILS.email_id%TYPE,
    v_notification_phone_number          IN  CLM_ENROLL_DETAILS.notification_phone_number%TYPE,
    v_ins_scheme                         IN  PAT_ENROLL_DETAILS.ins_scheme%TYPE,
    v_certificate_no                     IN  PAT_ENROLL_DETAILS.certificate_no%TYPE,
    v_ins_customer_code                  IN  PAT_ENROLL_DETAILS.ins_customer_code%TYPE,
    v_added_by                           IN  CLM_ENROLL_DETAILS.added_by%TYPE,
    v_rows_processed                     IN  OUT NUMBER,
    v_modification_mode_value            IN pat_enroll_details.modification_mode_value%TYPE := NULL,
    v_parent_modif_mode_value            IN  CLM_ENROLL_DETAILS.modification_mode_value%TYPE := NULL
  );
-- =================================================================================================================
  PROCEDURE set_save_enroll(
    v_clm_enroll_detail_seq_id          IN OUT CLM_ENROLL_DETAILS.clm_enroll_detail_seq_id%TYPE,
    v_claim_seq_id                      IN CLM_GENERAL_DETAILS.Claim_Seq_Id%TYPE,
    v_member_seq_id                     IN CLM_ENROLL_DETAILS.MEMBER_SEQ_ID%TYPE,
    v_tpa_enrollment_id                 IN CLM_ENROLL_DETAILS.Tpa_Enrollment_Id%TYPE,
    v_claimant_name                     IN CLM_ENROLL_DETAILS.Claimant_Name%TYPE,
    v_policy_holder_name                IN CLM_ENROLL_DETAILS.Policy_Holder_Name%TYPE,
    v_employee_name                     IN CLM_ENROLL_DETAILS.Employee_Name%TYPE,
    v_employee_no                       IN CLM_ENROLL_DETAILS.Employee_No%TYPE ,
    v_policy_number                     IN CLM_ENROLL_DETAILS.Policy_Number%TYPE ,
    v_policy_seq_id                     IN CLM_ENROLL_DETAILS.Policy_Seq_Id%TYPE,
    v_email_id                          IN CLM_ENROLL_DETAILS.email_id%TYPE,
    v_notification_phone_number         IN CLM_ENROLL_DETAILS.notification_phone_number%TYPE,
    v_ins_scheme                     IN CLM_ENROLL_DETAILS.ins_scheme%TYPE,
    v_certificate_no                 IN CLM_ENROLL_DETAILS.certificate_no%TYPE,
    v_ins_customer_code              IN CLM_ENROLL_DETAILS.ins_customer_code%TYPE,
    v_added_by                          IN NUMBER,
    v_rows_processed                    OUT NUMBER
  );
-- =================================================================================================================
  PROCEDURE select_clm_inward_list(
    v_claims_inward_no               IN  CLM_INWARD.claims_inward_no%TYPE,
    v_claim_general_type_id          IN  CLM_INWARD.claim_general_type_id%TYPE,
    v_start_date                     IN  VARCHAR2,
    v_end_date                       IN  VARCHAR2,
    v_tpa_enrollment_id              IN  CLM_ENROLL_DETAILS.tpa_enrollment_id%TYPE,
    v_corporate_name                 IN  CLM_INWARD.corporate_name%TYPE,
    v_inward_stat_general_type_id     IN  CLM_INWARD.inward_status_general_type_id%TYPE,
    v_tpa_office_seq_id              IN  CLM_INWARD.tpa_office_seq_id%TYPE,
    v_inward_claim_number            IN  CLM_GENERAL_DETAILS.claim_number%TYPE,
    v_ins_scheme                         IN  PAT_ENROLL_DETAILS.ins_scheme%TYPE,
    v_certificate_no                     IN  PAT_ENROLL_DETAILS.certificate_no%TYPE,
    v_sort_var                       IN  VARCHAR2 ,
    v_sort_order                     IN  VARCHAR2 ,
    v_start_num                      IN  NUMBER ,
    v_end_num                        IN  NUMBER ,
    v_added_by                       IN  NUMBER,
    result_set                       OUT SYS_REFCURSOR
  );
-- =================================================================================================================
  PROCEDURE select_claim (
    v_claim_seq_id                  IN clm_general_details.claim_seq_id%TYPE,
    v_clm_enroll_detail_seq_id      IN clm_enroll_details.clm_enroll_detail_seq_id%TYPE,
    v_member_seq_id                 IN clm_enroll_details.member_seq_id%TYPE,
    v_added_by                      IN NUMBER,
    v_result_set                    OUT SYS_REFCURSOR
  );
-- =================================================================================================================
  PROCEDURE save_clm_bill_header (
     v_clm_bill_seq_id            IN OUT  clm_bill_header.clm_bill_seq_id%TYPE,
     v_claim_seq_id               IN clm_bill_header.claim_seq_id%TYPE,
     v_bill_no                    IN clm_bill_header.bill_no%TYPE,
     v_bill_date                  IN clm_bill_header.bill_date%TYPE,
     v_bill_issued_by             IN clm_bill_header.bill_issued_by%TYPE,
     v_bills_with_prescription_yn IN clm_bill_header.bills_with_prescription_yn%TYPE,
     v_bill_included_yn           IN clm_bill_header.bill_included_yn%TYPE,
     v_added_by                   IN clm_bill_header.added_by%TYPE,
     v_DONOR_BILL_YN              IN CLM_BILL_HEADER.DONOR_BILL_YN%TYPE,  --KOC DONOR
     v_rows_processed             OUT NUMBER
  );

 --==============================================================================================
 --   Name       : save_clm_bill_details
 --   Created on : -11-JUL-06
 --   Created By : - S.V.SREERAJ
 --   Comments   :
 --==============================================================================================

  PROCEDURE save_clm_bill_details (
     v_clm_bill_dtl_seq_id IN OUT clm_bill_details.clm_bill_dtl_seq_id%TYPE,
     v_clm_bill_seq_id     IN clm_bill_details.clm_bill_seq_id%TYPE,
     v_description         IN clm_bill_details.description%TYPE,
     v_ward_type_id        IN clm_bill_details.ward_type_id%TYPE,
     v_room_type_id        IN clm_bill_details.room_type_id%TYPE,
     v_number_of_days      IN clm_bill_details.number_of_days%TYPE,
     v_requested_amount    IN clm_bill_details.requested_amount%TYPE,
     v_allow_yn            IN clm_bill_details.allow_yn%TYPE,
     v_allowed_amount      IN clm_bill_details.allowed_amount%TYPE,
--       v_rejected_amount     IN clm_bill_details.rejected_amount%TYPE,
     v_remarks             IN clm_bill_details.remarks%TYPE,
     v_added_by            IN clm_bill_details.added_by%TYPE,
     v_vaccination_type_id IN CLM_BILL_DETAILS.VACCINATION_TYPE_ID%TYPE, --KOC1164
     v_Child_Immnunization  IN  CLM_BILL_DETAILS.Child_Immnunization%TYPE,  --KOC1315
     v_well_child_test_type IN  CLM_BILL_DETAILS.well_child_test_type%type,  --koc1316
     v_rout_adult_phys_exam IN  CLM_BILL_DETAILS.Rout_Adult_Phys_Exam%type,  --koc1308
     v_no_of_visits        IN clm_bill_details.no_of_visits%TYPE, --Added for koc1320
     v_rows_processed                 OUT NUMBER
  );

 --==============================================================================================
 --   Name       : claims_bill_details_list
 --   Created on : -11-JUL-06
 --   Created By : - S.V.SREERAJ
 --   Comments   :
 --==============================================================================================

  PROCEDURE claims_bill_details_list (
    v_clm_bill_seq_id IN clm_bill_details.clm_bill_seq_id%TYPE,
    v_sort_var        IN VARCHAR2,
    v_sort_order      IN VARCHAR2 ,
    v_start_num       IN NUMBER ,
    v_end_num         IN NUMBER ,
    v_added_by        IN NUMBER,
    result_set        OUT SYS_REFCURSOR
  );

--==============================================================================================
 --   Name       : claims_bill_header_list
 --   Created on : -11-JUL-06
 --   Created By : - S.V.SREERAJ
 --   Comments   :
 --==============================================================================================

  PROCEDURE claims_bill_header_list (
    v_claim_seq_id    IN clm_bill_header.claim_seq_id%TYPE,
    v_bill_no         IN clm_bill_header.bill_no%TYPE,
    v_bill_amount     IN clm_bill_details.requested_amount%TYPE,
    v_bill_date       IN VARCHAR2,
    v_sort_var        IN VARCHAR2,
    v_sort_order      IN VARCHAR2 ,
    v_start_num       IN NUMBER ,
    v_end_num         IN NUMBER ,
    v_added_by        IN NUMBER,
    result_set        OUT SYS_REFCURSOR
  );

-- =================================================================================================================
  PROCEDURE select_hosp_additional_dtl (
    v_clm_hosp_assoc_seq_id                IN CLM_HOSPITAL_ADDITIONAL_DTL.clm_hosp_assoc_seq_id%TYPE,
    v_added_by                             IN NUMBER,
    v_result_set                           OUT SYS_REFCURSOR
  );
-- =================================================================================================================
  PROCEDURE select_medical_details (
    v_claim_seq_id                        IN  AILMENT_DETAILS.claim_seq_id%TYPE,  -- pat_general_detail_seq_id or Claim_seq_id
    v_added_by                            IN  NUMBER,
    v_show_ailment                        OUT CHAR,
    v_ailment_cur                         OUT SYS_REFCURSOR,
    v_hosp_cur                            OUT SYS_REFCURSOR,
    v_icd_pcs_cur                         OUT SYS_REFCURSOR,
    v_coding_review_yn                    OUT CHAR,
    v_show_diagnosis                      OUT CHAR,--koc1273
    v_certificate                         OUT CHAR--koc1273
  );
-- =================================================================================================================
  PROCEDURE claims_support_doc_list (
    v_claim_seq_id                       IN  NUMBER,
    v_sort_var                           IN  VARCHAR2,
    v_sort_order                         IN  VARCHAR2,
    v_start_num                          IN  NUMBER  ,
    v_end_num                            IN  NUMBER ,
    v_added_by                           IN  NUMBER,
    result_set                           OUT SYS_REFCURSOR
  );
-- =================================================================================================================
  PROCEDURE save_discharge_voucher(
    v_disch_vouch_seq_id                 IN  OUT CLM_DISCHARGE_VOUCHER.disch_vouch_seq_id%TYPE,
    v_claim_seq_id                       IN  CLM_DISCHARGE_VOUCHER.claim_seq_id%TYPE,
--    v_dv_id                              IN  CLM_DISCHARGE_VOUCHER.dv_id%TYPE,
    v_dv_sent_date                       IN  CLM_DISCHARGE_VOUCHER.dv_sent_date%TYPE,
    v_dv_received_date                   IN  CLM_DISCHARGE_VOUCHER.dv_received_date%TYPE ,
    v_dv_status_general_type_id          IN  CLM_DISCHARGE_VOUCHER.dv_status_general_type_id%TYPE,
    v_remarks                            IN  CLM_DISCHARGE_VOUCHER.remarks%TYPE,
    v_added_by                           IN  CLM_DISCHARGE_VOUCHER.added_by%TYPE,
    v_rows_processed                     IN  OUT NUMBER
  );
-- =================================================================================================================
  PROCEDURE select_discharge_voucher (
    v_disch_vouch_seq_id                 IN  CLM_DISCHARGE_VOUCHER.disch_vouch_seq_id%TYPE,
    v_added_by                           IN  CLM_DISCHARGE_VOUCHER.added_by%TYPE,
    v_result_set                         OUT SYS_REFCURSOR
  );
-- =================================================================================================================
  PROCEDURE select_srtfll_missing_docs (
    v_claim_seq_id                      IN  NUMBER,
    v_doc_xml                           OUT XMLTYPE ,
    v_added_by                          IN  NUMBER
  );
-- =================================================================================================================
  PROCEDURE select_clm_inward_document(
    v_claim_type                      IN CLM_INWARD.claim_general_type_id%TYPE,
    v_result_set                      OUT SYS_REFCURSOR
  );
-- =================================================================================================================
  PROCEDURE save_clm_document(
    v_docu_rcvd_seq_id             IN CLM_DOCUMENTS_RCVD.docu_rcvd_seq_id%TYPE,
    v_document_rcvd_yn             IN VARCHAR2,
    v_docu_list_type_id             IN CLM_DOCUMENTS_RCVD.docu_list_type_id%TYPE,
    v_sheets_count                  IN CLM_DOCUMENTS_RCVD.sheets_count%TYPE,
    v_doc_general_type_id          IN CLM_DOCUMENTS_RCVD.doc_general_type_id%TYPE,
    v_reason_general_type_id        IN CLM_DOCUMENTS_RCVD.reason_general_type_id%TYPE,
    v_claim_seq_id                  IN CLM_DOCUMENTS_RCVD.claim_seq_id%TYPE,
    v_claims_inward_seq_id         IN CLM_DOCUMENTS_RCVD.claims_inward_seq_id%TYPE,
    v_remarks                      IN CLM_DOCUMENTS_RCVD.remarks%TYPE,
    v_added_by                      IN CLM_DOCUMENTS_RCVD.added_by%TYPE
  );
-- =================================================================================================================
  PROCEDURE select_clm_inward_dtl(
    v_claims_inward_seq_id           IN  CLM_INWARD.claims_inward_seq_id%TYPE,
    v_claim_type                     IN CLM_INWARD.claim_general_type_id%TYPE,
    v_added_by                       IN  CLM_INWARD.added_by%TYPE,
    v_claim_cur                      OUT SYS_REFCURSOR,
    v_document_cur                   OUT SYS_REFCURSOR
  );
-- =================================================================================================================
  PROCEDURE select_preauth_list (
    v_tpa_enrollment_id              IN  pat_enroll_details.tpa_enrollment_id%TYPE,
    v_claimant_name                  IN  pat_enroll_details.claimant_name%TYPE,
    v_auth_number                    IN  pat_enroll_details.auth_number%TYPE,
    v_hosp_name                      IN  tpa_hosp_info.hosp_name%TYPE,
    v_pat_general_type_id            IN  pat_general_details.pat_general_type_id%TYPE,
    v_start_date                     IN  VARCHAR2,
    v_end_date                       IN  VARCHAR2,
    v_tpa_office_seq_id              IN  tpa_office_info.tpa_office_seq_id%TYPE,
    v_sort_var                       IN  VARCHAR2 ,
    v_sort_order                     IN  VARCHAR2,
    v_start_num                      IN  NUMBER,
    v_end_num                        IN  NUMBER,
    v_added_by                       IN  NUMBER,
    result_set                       OUT SYS_REFCURSOR,
    v_claim_seq_id                   IN NUMBER := NULL
  );
-- =================================================================================================================
  PROCEDURE select_claims_list (
    v_claims_inward_no               IN  clm_inward.claims_inward_no%TYPE,
    v_claim_number                   IN  clm_general_details.claim_number%TYPE,
    v_claim_general_type_id          IN  clm_inward.claim_general_type_id%TYPE,
    v_claim_settlement_number        IN  clm_general_details.claim_settlement_number%TYPE,
    v_claim_file_number              IN  clm_general_details.claim_file_number%TYPE,
    v_claimant_name                  IN  clm_enroll_details.claimant_name %TYPE,
    v_tpa_enrollment_id              IN  clm_enroll_details.tpa_enrollment_id%TYPE,
    v_policy_number                  IN  clm_enroll_details.policy_number%TYPE,
    v_corporate_name                 IN  clm_inward.corporate_name%TYPE,
    v_employee_no                    IN  clm_enroll_details.employee_no%TYPE,
    v_employee_name                  IN  clm_enroll_details.employee_name%TYPE,
    v_policy_holder_name             IN  clm_enroll_details.policy_holder_name%TYPE,
    v_assigned_to_user               IN  VARCHAR2,
    v_contact_name                   IN  tpa_user_contacts.contact_name%TYPE,
    v_clm_status_general_type_id     IN  clm_enroll_details.clm_status_general_type_id%TYPE,
    v_mode_general_type_id           IN  clm_general_details.mode_general_type_id%TYPE,
    v_tpa_office_seq_id              IN  tpa_office_info.tpa_office_seq_id%TYPE ,
    v_event_seq_id                   IN  clm_general_details.event_seq_id%TYPE,
    v_ins_scheme                     IN  PAT_ENROLL_DETAILS.ins_scheme%TYPE,
    v_certificate_no                 IN  PAT_ENROLL_DETAILS.certificate_no%TYPE,
    v_ins_status                     IN  app.clm_ins_intimation_details.clm_ins_status%TYPE,
    v_policy_holder_code             IN  tpa_enr_policy.policy_holder_code%type,
    v_clm_intimation_id              IN  TPA_CALL_LOG.Call_Log_Number%type,
    v_sort_var                       IN  VARCHAR2,
    v_sort_order                     IN  VARCHAR2,
    v_start_num                      IN  NUMBER ,
    v_end_num                        IN  NUMBER ,
    v_added_by                       IN  NUMBER,
    result_set                       OUT SYS_REFCURSOR
  );
-- =================================================================================================================

  PROCEDURE save_claim (
    -- CLM_ENROLL_DETAILS
    v_clm_enroll_detail_seq_id           IN  OUT CLM_ENROLL_DETAILS.clm_enroll_detail_seq_id%TYPE,
    v_claim_seq_id                       IN  OUT CLM_ENROLL_DETAILS.claim_seq_id%TYPE,
    v_gender_general_type_id             IN  CLM_ENROLL_DETAILS.gender_general_type_id%TYPE,
    v_member_seq_id                      IN  CLM_ENROLL_DETAILS.member_seq_id%TYPE,
    v_tpa_enrollment_id                  IN  CLM_ENROLL_DETAILS.tpa_enrollment_id%TYPE,
    v_policy_seq_id                      IN  CLM_ENROLL_DETAILS.policy_seq_id%TYPE,
    v_policy_holder_name                 IN  CLM_ENROLL_DETAILS.policy_holder_name%TYPE,
    v_employee_no                        IN  CLM_ENROLL_DETAILS.employee_no%TYPE,
    v_employee_name                      IN  CLM_ENROLL_DETAILS.employee_name%TYPE,
    v_mem_age                            IN  CLM_ENROLL_DETAILS.mem_age%TYPE,
    v_claimant_name                      IN  CLM_ENROLL_DETAILS.claimant_name%TYPE,
    v_date_of_inception                  IN  CLM_ENROLL_DETAILS.date_of_inception%TYPE,
    v_date_of_exit                       IN  CLM_ENROLL_DETAILS.date_of_exit%TYPE,
    v_relship_type_id                    IN  CLM_ENROLL_DETAILS.relship_type_id%TYPE,
    v_policy_number                      IN  CLM_ENROLL_DETAILS.policy_number%TYPE,
    v_claimant_phone_number              IN  CLM_ENROLL_DETAILS.claimant_phone_number%TYPE,
    v_mem_total_sum_insured              IN  CLM_ENROLL_DETAILS.mem_total_sum_insured%TYPE,
    v_enrol_type_id                      IN  CLM_ENROLL_DETAILS.enrol_type_id%TYPE,
    v_policy_sub_general_type_id         IN  CLM_ENROLL_DETAILS.policy_sub_general_type_id%TYPE,
    v_phone_1                            IN  CLM_ENROLL_DETAILS.phone_1%TYPE,
    v_policy_effective_from              IN  CLM_ENROLL_DETAILS.policy_effective_from%TYPE,
    v_policy_effective_to                IN  CLM_ENROLL_DETAILS.policy_effective_to%TYPE,
    v_ins_status_general_type_id         IN  CLM_ENROLL_DETAILS.ins_status_general_type_id%TYPE,
    v_ins_seq_id                         IN  CLM_ENROLL_DETAILS.ins_seq_id%TYPE,
    v_group_reg_seq_id                   IN  CLM_ENROLL_DETAILS.group_reg_seq_id%TYPE,
-----CLM_GENERAL_DETAILS
    v_claims_inward_seq_id               IN  CLM_GENERAL_DETAILS.claims_inward_seq_id%TYPE,
    v_requested_amount                   IN  CLM_GENERAL_DETAILS.requested_amount%TYPE,
    v_pat_enroll_detail_seq_id           IN  CLM_GENERAL_DETAILS.pat_enroll_detail_seq_id%TYPE,
    v_auth_number                        IN  CLM_GENERAL_DETAILS.auth_number%TYPE,
    v_request_general_type_id            IN  CLM_GENERAL_DETAILS.request_general_type_id%TYPE,
    v_claim_sub_general_type_id          IN  CLM_GENERAL_DETAILS.claim_sub_general_type_id%TYPE,
    v_reason_for_dom                     IN  clm_general_details.DOM_REASON_GEN_TYPE_ID%type,--KOC1285
    v_doctor_certified_YN                IN  CLM_GENERAL_DETAILS.DOC_CERT_DOM_YN%type,--KOC1285
    v_mode_general_type_id               IN  CLM_GENERAL_DETAILS.mode_general_type_id%TYPE,
    v_treating_dr_name                   IN  CLM_GENERAL_DETAILS.treating_dr_name%TYPE,
    v_in_patient_no                      IN  CLM_GENERAL_DETAILS.in_patient_no%TYPE,
    v_claims_remarks                     IN  CLM_GENERAL_DETAILS.claims_remarks%TYPE,
    v_ava_sum_insured                    IN  OUT CLM_GENERAL_DETAILS.ava_sum_insured%TYPE,
    v_ava_cum_bonus                      IN  OUT CLM_GENERAL_DETAILS.ava_cum_bonus%TYPE,
    v_date_of_admission                  IN  CLM_GENERAL_DETAILS.date_of_admission%TYPE,
    v_date_of_discharge                  IN  CLM_GENERAL_DETAILS.date_of_discharge%TYPE,
    v_parent_claim_seq_id                IN  OUT CLM_GENERAL_DETAILS.parent_claim_seq_id%TYPE,
----CLM_HOSPITAL_ASSOCIATION
    v_clm_hosp_assoc_seq_id              IN  OUT CLM_HOSPITAL_ASSOCIATION.clm_hosp_assoc_seq_id%TYPE,
    v_hosp_seq_id                        IN  CLM_HOSPITAL_ASSOCIATION.hosp_seq_id%TYPE,
    v_empanel_number                     IN  CLM_HOSPITAL_ASSOCIATION.empanel_number%TYPE,
    v_hosp_name                          IN  OUT CLM_HOSPITAL_ASSOCIATION.hosp_name%TYPE,
    v_address_1                          IN  OUT CLM_HOSPITAL_ASSOCIATION.address_1%TYPE,
    v_address_2                          IN  OUT CLM_HOSPITAL_ASSOCIATION.address_2%TYPE,
    v_address_3                          IN  OUT CLM_HOSPITAL_ASSOCIATION.address_3%TYPE,
    v_state_name                         IN  OUT CLM_HOSPITAL_ASSOCIATION.state_name%TYPE,
    v_city_name                          IN  OUT CLM_HOSPITAL_ASSOCIATION.city_name%TYPE,
    v_pin_code                           IN  OUT CLM_HOSPITAL_ASSOCIATION.pin_code%TYPE,
    v_off_phone_no_1                     IN  OUT CLM_HOSPITAL_ASSOCIATION.off_phone_no_1%TYPE,
    v_off_phone_no_2                     IN  OUT CLM_HOSPITAL_ASSOCIATION.off_phone_no_2%TYPE,
    v_office_fax_no                      IN  OUT CLM_HOSPITAL_ASSOCIATION.office_fax_no%TYPE,
    v_remarks                            IN  CLM_HOSPITAL_ASSOCIATION.remarks%TYPE,
    v_serv_tax_rgn_number                IN  CLM_HOSPITAL_ASSOCIATION.serv_tax_rgn_number%TYPE,
-----CLM_HOSPITAL_ADDITIONAL_DTL
    v_prev_hosp_claim_seq_id             IN  OUT CLM_GENERAL_DETAILS.prev_hosp_claim_seq_id%TYPE,
    v_claim_dms_reference_id             IN CLM_GENERAL_DETAILS.claim_dms_reference_id%TYPE,
    v_pat_approved_amount                IN  CLM_GENERAL_DETAILS.pat_approved_amount%TYPE,
    v_re_open_type                       IN  CLM_GENERAL_DETAILS.re_open_type%TYPE,
    v_doctor_registration_no             IN  CLM_GENERAL_DETAILS.doctor_registration_no%TYPE,
    v_email_id                           IN  CLM_ENROLL_DETAILS.email_id%TYPE,
    v_notification_phone_number          IN  CLM_ENROLL_DETAILS.notification_phone_number%TYPE,
    v_ins_scheme                         IN  PAT_ENROLL_DETAILS.ins_scheme%TYPE,
    v_certificate_no                     IN  PAT_ENROLL_DETAILS.certificate_no%TYPE,
    v_ins_customer_code                  IN  PAT_ENROLL_DETAILS.ins_customer_code%TYPE,
    v_insur_ref_number                   IN  CLM_GENERAL_DETAILS.Insur_Ref_Number%TYPE,
	v_pay_to_general_type_id             IN  CLM_GENERAL_DETAILS.PAY_TO_GENERAL_TYPE_ID%TYPE,--opdforhs
    v_added_by                           IN  CLM_HOSPITAL_ADDITIONAL_DTL.added_by%TYPE,
    v_rows_processed                     IN  OUT NUMBER,
    v_last_buffer_detail_seq_id          IN  buffer_details.buff_detail_seq_id%TYPE := NULL,
    v_parent_modif_mode_value            IN  CLM_ENROLL_DETAILS.modification_mode_value%TYPE := NULL
  );
-- =================================================================================================================
  PROCEDURE save_general_details(
    v_claim_seq_id                       IN  OUT CLM_GENERAL_DETAILS.claim_seq_id%TYPE,
    v_claims_inward_seq_id               IN  CLM_GENERAL_DETAILS.claims_inward_seq_id%TYPE,
    v_member_seq_id                      IN  CLM_ENROLL_DETAILS.member_seq_id%TYPE,
    v_requested_amount                   IN  CLM_GENERAL_DETAILS.requested_amount%TYPE,
    v_pat_enroll_detail_seq_id           IN  CLM_GENERAL_DETAILS.pat_enroll_detail_seq_id%TYPE,
    v_auth_number                        IN  CLM_GENERAL_DETAILS.auth_number%TYPE,
    v_pat_approved_amount                IN  CLM_GENERAL_DETAILS.pat_approved_amount%TYPE,
    v_request_general_type_id            IN  CLM_GENERAL_DETAILS.request_general_type_id%TYPE,
    v_claim_sub_general_type_id          IN  CLM_GENERAL_DETAILS.claim_sub_general_type_id%TYPE,
    v_reason_for_dom                     IN  clm_general_details.DOM_REASON_GEN_TYPE_ID%type,--KOC1285
    v_doctor_certified_YN                IN  CLM_GENERAL_DETAILS.DOC_CERT_DOM_YN%type,--KOC1285
    v_call_log_seq_id                    IN  CLM_GENERAL_DETAILS.call_log_seq_id%TYPE,
    v_mode_general_type_id               IN  CLM_GENERAL_DETAILS.mode_general_type_id%TYPE,
    v_treating_dr_name                   IN  CLM_GENERAL_DETAILS.treating_dr_name%TYPE,
    v_in_patient_no                      IN  CLM_GENERAL_DETAILS.in_patient_no%TYPE,
    v_claims_remarks                     IN  CLM_GENERAL_DETAILS.claims_remarks%TYPE,
    v_ava_sum_insured                    IN  CLM_GENERAL_DETAILS.ava_sum_insured%TYPE,
    v_ava_cum_bonus                      IN  CLM_GENERAL_DETAILS.ava_cum_bonus%TYPE,
    v_ava_buff_amount                    IN  clm_general_details.ava_buff_amount%TYPE,
    v_discrepancy_present_yn             IN  CLM_GENERAL_DETAILS.discrepancy_present_yn%TYPE,
    v_date_of_admission                  IN  CLM_GENERAL_DETAILS.date_of_admission%TYPE,
    v_date_of_discharge                  IN  CLM_GENERAL_DETAILS.date_of_discharge%TYPE,
    v_parent_claim_seq_id                IN  OUT CLM_GENERAL_DETAILS.parent_claim_seq_id%TYPE,
    v_claim_settlement_number            IN  CLM_GENERAL_DETAILS.claim_settlement_number%TYPE,
    v_prev_hosp_claim_seq_id             IN  OUT CLM_GENERAL_DETAILS.Prev_Hosp_Claim_Seq_Id%TYPE,
    v_hosp_seq_id                        IN  CLM_HOSPITAL_ASSOCIATION.hosp_seq_id%TYPE,
    v_claim_dms_reference_id             IN  CLM_GENERAL_DETAILS.claim_dms_reference_id%TYPE,
    v_policy_seq_id                      IN  CLM_ENROLL_DETAILS.Policy_Seq_Id%TYPE,
    v_re_open_type                       IN  CLM_GENERAL_DETAILS.re_open_type%TYPE,
    v_doctor_registration_no             IN  CLM_GENERAL_DETAILS.doctor_registration_no%TYPE,
    v_insur_ref_number                   IN  CLM_GENERAL_DETAILS.Insur_Ref_Number%TYPE,
    v_last_buffer_detail_seq_id          IN  OUT CLM_GENERAL_DETAILS.Last_Buffer_Detail_Seq_Id%TYPE,
	v_pay_to_general_type_id             IN  CLM_GENERAL_DETAILS.PAY_TO_GENERAL_TYPE_ID%TYPE,--opdforhs
    v_added_by                           IN  CLM_GENERAL_DETAILS.added_by%TYPE,
    v_rows_processed                     IN  OUT NUMBER
  );
-- =================================================================================================================
  PROCEDURE save_hosp_additional_dtl(
    v_add_hosp_dtl_seq_id                IN  OUT CLM_HOSPITAL_ADDITIONAL_DTL.add_hosp_dtl_seq_id%TYPE,
    v_clm_hosp_assoc_seq_id              IN  CLM_HOSPITAL_ADDITIONAL_DTL.clm_hosp_assoc_seq_id%TYPE,
    v_hosp_regist_number                 IN  CLM_HOSPITAL_ADDITIONAL_DTL.hosp_regist_number%TYPE,
    v_contact_name                       IN  CLM_HOSPITAL_ADDITIONAL_DTL.contact_name%TYPE,
    v_off_phone_no_1                     IN  CLM_HOSPITAL_ADDITIONAL_DTL.off_phone_no_1%TYPE,
    v_number_of_beds                     IN  CLM_HOSPITAL_ADDITIONAL_DTL.number_of_beds%TYPE,
    v_fully_equipped_yn                  IN  CLM_HOSPITAL_ADDITIONAL_DTL.fully_equipped_yn%TYPE,
    v_added_by                           IN  CLM_HOSPITAL_ADDITIONAL_DTL.added_by%TYPE,
    v_rows_processed                     IN  OUT NUMBER
  );
-- =================================================================================================================
  PROCEDURE save_hospital_association(
    v_clm_hosp_assoc_seq_id              IN  OUT CLM_HOSPITAL_ASSOCIATION.clm_hosp_assoc_seq_id%TYPE,
    v_claim_seq_id                       IN  CLM_HOSPITAL_ASSOCIATION.claim_seq_id%TYPE,
    v_hosp_seq_id                        IN  CLM_HOSPITAL_ASSOCIATION.hosp_seq_id%TYPE,
    v_empanel_number                     IN  CLM_HOSPITAL_ASSOCIATION.empanel_number%TYPE,
    v_hosp_name                          IN  OUT CLM_HOSPITAL_ASSOCIATION.hosp_name%TYPE,
    v_address_1                          IN  OUT CLM_HOSPITAL_ASSOCIATION.address_1%TYPE,
    v_address_2                          IN  OUT CLM_HOSPITAL_ASSOCIATION.address_2%TYPE,
    v_address_3                          IN  OUT CLM_HOSPITAL_ASSOCIATION.address_3%TYPE,
    v_state_name                         IN  OUT CLM_HOSPITAL_ASSOCIATION.state_name%TYPE,
    v_city_name                          IN  OUT CLM_HOSPITAL_ASSOCIATION.city_name%TYPE,
    v_pin_code                           IN  OUT CLM_HOSPITAL_ASSOCIATION.pin_code%TYPE,
    v_off_phone_no_1                     IN  OUT CLM_HOSPITAL_ASSOCIATION.off_phone_no_1%TYPE,
    v_off_phone_no_2                     IN  OUT CLM_HOSPITAL_ASSOCIATION.off_phone_no_2%TYPE,
    v_office_fax_no                      IN  OUT CLM_HOSPITAL_ASSOCIATION.office_fax_no%TYPE,
    v_remarks                            IN  CLM_HOSPITAL_ASSOCIATION.remarks%TYPE,
    v_serv_tax_rgn_number                IN  CLM_HOSPITAL_ASSOCIATION.serv_tax_rgn_number%TYPE,
    v_added_by                           IN  CLM_HOSPITAL_ASSOCIATION.added_by%TYPE,
    v_rows_processed                     IN  OUT NUMBER
  );
-- =================================================================================================================
    PROCEDURE select_courier_list (
    v_courier_id                         IN  COURIER_DETAILS.courier_id %TYPE ,
    v_docket_number                      IN  COURIER_DETAILS.docket_number%TYPE ,
    v_courier_comp_seq_id                IN  COURIER_DETAILS.courier_comp_seq_id%TYPE ,
    v_start_date                         IN  VARCHAR2,
    v_end_date                           IN  VARCHAR2,
    v_sort_var                           IN  VARCHAR2  ,
    v_sort_order                         IN  VARCHAR2 := 'ASC',
    v_start_num                          IN  NUMBER   := 1,
    v_end_num                            IN  NUMBER   := 25,
    v_added_by                           IN  NUMBER,
    result_set                           OUT SYS_REFCURSOR
  );
-- =================================================================================================================
  PROCEDURE select_bill_summary (
    v_claim_seq_id    IN clm_bill_header.claim_seq_id%TYPE,
    v_added_by        IN NUMBER,
    summary_result_set OUT SYS_REFCURSOR,
    bill_split  OUT SYS_REFCURSOR,
    ailment_cur OUT SYS_REFCURSOR ,
    v_req_amt_mismatch           OUT NUMBER
  );
-- =================================================================================================================
  PROCEDURE select_clm_document (
    v_claim_seq_id                      IN CLM_DOCUMENTS_RCVD.claim_seq_id%TYPE,
    v_added_by                          IN NUMBER,
    v_result_set                        OUT SYS_REFCURSOR
  );
-- =================================================================================================================
 PROCEDURE get_account_limits(
    v_hosp_seq_id                              IN  NUMBER,
    v_policy_seq_id                            IN  NUMBER,
    v_product_seq_id                           IN  NUMBER,
    v_date_of_hospitalization                  IN  DATE,
    v_ward_type_id                             IN  VARCHAR2,
    v_room_type_id                             IN  VARCHAR2,
    v_cost                                     OUT NUMBER,
    v_discount                                 OUT NUMBER
  );
-- =================================================================================================================
  PROCEDURE calculate_cost (
    v_plan_seq_id                       IN  TPA_HOSP_REVISED_PLAN.Plan_Seq_Id%TYPE,
    v_revised_plan_seq_id               IN  OUT TPA_HOSP_REVISED_PLAN.plan_seq_id%TYPE,
    v_prod_hosp_seq_id                  IN  TPA_HOSP_REVISED_PLAN.prod_hosp_seq_id%TYPE,
    v_date_of_hospitalization           IN  PAT_GENERAL_DETAILS.likely_date_of_hospitalization%TYPE,
    v_room_type_id                      IN  VARCHAR2,
    v_ward_type_id                      IN  VARCHAR2,
    v_cost                              OUT NUMBER
  );
-- =================================================================================================================
  PROCEDURE get_pkg_cost (
     v_plan_seq_id               IN  INTEGER,
     v_revised_plan_seq_id       IN  OUT INTEGER,
     v_prod_hosp_seq_id          IN  INTEGER,
     v_pkg_seq_id                IN  INTEGER,
     v_date_of_hosp              IN  DATE,
     v_room_type                 IN  VARCHAR2,
     v_ward_type_id              IN  VARCHAR2
  );
-- =================================================================================================================
  PROCEDURE save_clm_summary (
       v_claim_seq_id        IN  clm_general_details.claim_seq_id%TYPE,
       v_ward_type_id        IN clm_bill_details.ward_type_id%TYPE,
       v_apply_discount_yn   IN clm_bill_details.apply_discount_yn%TYPE,
       v_added_by            IN clm_bill_details.added_by%TYPE
  );
-- =================================================================================================================
  PROCEDURE check_claim (
    v_claim_seq_id        IN  clm_general_details.claim_seq_id%TYPE,
    v_added_by            IN clm_bill_details.added_by%TYPE
  );
-- =================================================================================================================
PROCEDURE select_bill_header (
    v_clm_bill_seq_id                 IN  clm_bill_header.clm_bill_seq_id%TYPE,
    v_added_by                        IN  clm_bill_header.added_by%TYPE,
    v_result_set                      OUT SYS_REFCURSOR
);

-- =================================================================================================================
 function claims_ref_ins ( --KOCBJJ
              v_claim_seq_id                   IN clm_enroll_details.claim_seq_id%TYPE,
              v_prod_policy_seq_id             IN tpa_ins_prod_policy.prod_policy_seq_id%TYPE
              )  RETURN CHAR;

-- =================================================================================================================
  PROCEDURE select_settlement (
    v_claim_seq_id                         IN  clm_general_details.claim_seq_id%TYPE,
    v_clm_enroll_detail_seq_id             IN  clm_enroll_details.clm_enroll_detail_seq_id%TYPE,
    v_result_set                           OUT SYS_REFCURSOR
  );
-- =================================================================================================================
  PROCEDURE select_prev_claim(
    v_member_seq_id              IN  clm_enroll_details.member_seq_id%TYPE,
    v_result_set                 OUT SYS_REFCURSOR
  );
-- =================================================================================================================
  PROCEDURE select_prev_hosps(
    v_claim_type                 IN  CLM_INWARD.claim_general_type_id%TYPE, --CTM -> MR OR CNH -> NHCP
    v_member_seq_id              IN  CLM_ENROLL_DETAILS.member_seq_id%TYPE,
    v_result_set                 OUT SYS_REFCURSOR ,
    v_claim_seq_id               IN  clm_general_details.claim_seq_id%TYPE := 0
  );
-- =================================================================================================================
  PROCEDURE select_hosp_all(
    v_prev_hosp_claim_seq_id     IN  CLM_GENERAL_DETAILS.claim_seq_id%TYPE,
    v_result_set                 OUT SYS_REFCURSOR
  );
-- =================================================================================================================
-- =================================================================================================================
  PROCEDURE set_review(
    v_claim_seq_id                    IN CLM_GENERAL_DETAILS.claim_seq_id%TYPE,
    v_event_seq_id                    IN OUT CLM_GENERAL_DETAILS.event_seq_id%TYPE,
    v_review_count                    IN OUT CLM_GENERAL_DETAILS.review_count%TYPE,
    v_required_review_count           IN OUT CLM_GENERAL_DETAILS.required_review_count%TYPE,
    v_mode                            IN CHAR, -- Put it to 'PAT'
    v_type                            IN CHAR, -- Dummy
    v_added_by                        IN NUMBER ,
    v_event_name                      OUT VARCHAR2,
    v_review                          OUT VARCHAR2,
    v_coding_review_yn                OUT VARCHAR2,
    v_show_coding_override            OUT VARCHAR2
  );
-- =================================================================================================================
  PROCEDURE save_settlement(
    v_assign_users_seq_id                IN  OUT ASSIGN_USERS.assign_users_seq_id%TYPE,
    v_claim_seq_id                       IN  ASSIGN_USERS.claim_seq_id%TYPE,
    v_mem_total_sum_insured              IN  PAT_ENROLL_DETAILS.mem_total_sum_insured %TYPE,
    v_remarks                            IN  ASSIGN_USERS.remarks%TYPE,
    v_claim_settlement_number            IN  OUT CLM_GENERAL_DETAILS.claim_settlement_number%TYPE,
    v_pat_status_general_type_id         IN  ASSIGN_USERS.pat_status_general_type_id%TYPE,
    v_permission_sought_from             IN  CLM_GENERAL_DETAILS.permission_sought_from%TYPE,
    v_balance_seq_id                     IN  tpa_enr_balance.balance_seq_id%TYPE,
    v_max_app_amount                     IN  OUT ASSIGN_USERS.total_app_amount%TYPE,
    v_added_by                           IN  ASSIGN_USERS.added_by%TYPE,
    v_rson_general_type_id               IN  ASSIGN_USERS.rson_general_type_id%TYPE,
    v_discount_amount                    IN  OUT clm_general_details.discount_amount%TYPE,
    v_co_payment_amount                  IN  OUT clm_general_details.co_payment_amount%TYPE,
    v_deposit_amount                     IN  OUT clm_general_details.deposit_amount%TYPE,
    v_service_tax_calc_amt               IN  clm_general_details.serv_tax_calc_amount%TYPE,
    v_serv_tax_calc_percentage           IN  clm_general_details.serv_tax_calc_percentage%TYPE,
    v_co_pay_buff_amount                 IN  OUT clm_general_details.co_payment_buffer_amount%TYPE, --KOCIBM
    v_rest_amt                           in  tpa_enr_balance.restrict_amt%type:=null, --koc1142
    v_used_rest_si                       in  tpa_enr_balance.used_restrict_amt%type:=0, --koc1142
    v_restrict_yn                        in  varchar2:=null, --koc1142
    v_pd                                 IN OUT tpa_enr_balance.policy_deductable_amt%TYPE,--koc1277
    v_FINAL_APP_YN                       IN  clm_general_details.final_app_yn%type,--koc_ins_mail
    v_Inv_Disallowed_Amt                 IN  clm_general_details.Inv_Disallowed_Amt%TYPE:=null, --Added for koc_investigation
    v_rows_processed                     IN  OUT NUMBER
  );
-- =================================================================================================================
  PROCEDURE  check_conflict (
    v_claim_seq_id                                     IN DISCREPANCY_INFORMATION.claim_seq_id%TYPE,
    v_clm_enroll_detail_seq_id                         IN CLM_ENROLL_DETAILS.clm_enroll_detail_seq_id%TYPE,
    v_policy_seq_id                                    IN CLM_ENROLL_DETAILS.Policy_Seq_Id%TYPE,
    v_enrol_type_id                                    IN CLM_ENROLL_DETAILS.enrol_type_id%TYPE,
    v_tpa_enrollment_id                                IN CLM_ENROLL_DETAILS.tpa_enrollment_id%TYPE,
    v_group_reg_seq_id                                 IN CLM_ENROLL_DETAILS.group_reg_seq_id%TYPE,
    v_employee_no                                      IN CLM_ENROLL_DETAILS.employee_no%TYPE,
    v_hosp_seq_id                                      IN CLM_HOSPITAL_ASSOCIATION.Hosp_Seq_Id%TYPE,
    v_effective_from_date                              IN CLM_ENROLL_DETAILS.Policy_Effective_From%TYPE,
    v_effective_to_date                                IN CLM_ENROLL_DETAILS.policy_effective_to%TYPE ,
    v_date_of_admission                                IN CLM_GENERAL_DETAILS.date_of_admission%TYPE,
    v_requested_amount                                 IN CLM_GENERAL_DETAILS.requested_amount%TYPE,
    v_date_of_discharge                                IN CLM_GENERAL_DETAILS.Date_Of_Discharge%TYPE,
    v_rcvd_date                                        IN clm_inward.rcvd_date%TYPE,
    v_data_discrepancy_present_yn                      IN VARCHAR2,
    v_discrepancy_present_yn                           IN OUT VARCHAR2,
    v_added_by                                         IN NUMBER,
    v_member_seq_id                                    IN clm_enroll_details.member_seq_id%TYPE
  );
-- =================================================================================================================
  PROCEDURE check_clm_approved(
    v_claim_seq_id                        IN clm_general_details.claim_seq_id%TYPE
  );
-- =================================================================================================================
  PROCEDURE manual_assign_preauth (
    v_claim_seq_id                         IN  ASSIGN_USERS.claim_seq_id%TYPE,
    v_policy_seq_id                        IN  pat_enroll_details.policy_seq_id%TYPE,
    v_tpa_office_seq_id                    IN  pat_enroll_details.tpa_office_seq_id%TYPE,
    v_result_set                           OUT SYS_REFCURSOR
  );
-- =================================================================================================================
  PROCEDURE delete_clm_general (
    v_delete_flag                        IN  VARCHAR2,
    v_seq_ids                            IN  VARCHAR2,
    v_clm_enroll_detail_seq_id           IN  clm_enroll_details.clm_enroll_detail_seq_id%TYPE,  -- MANDATORY
    v_claim_seq_id                       IN  clm_general_details.claim_seq_id%TYPE,    -- MANDATORY
    v_added_by                           IN  NUMBER,
    v_rows_processed                     IN  OUT NUMBER
  );
-- =================================================================================================================
  PROCEDURE create_claim_xml (
    v_claim_seq_id                          IN clm_general_details.claim_seq_id%TYPE,
    v_clm_enroll_detail_seq_id              IN clm_enroll_details.clm_enroll_detail_seq_id%TYPE,
    v_claim_history_doc                     OUT XMLTYPE
  );
-- =================================================================================================================
  PROCEDURE do_copy_previous_claim (
    v_claim_seq_id                    IN OUT clm_general_details.claim_seq_id%TYPE,
    v_clm_enroll_detail_seq_id        IN OUT clm_enroll_details.clm_enroll_detail_seq_id%TYPE,
    v_parent_claim_seq_id             IN OUT clm_general_details.parent_claim_seq_id%TYPE,
    v_claims_inward_seq_id            IN clm_inward.claims_inward_seq_id%TYPE,
    v_requested_amount                IN clm_general_details.requested_amount%TYPE,
    v_added_by                        IN NUMBER
  );
-- =================================================================================================================
  PROCEDURE save_inward_shortfall (
    v_shortfall_id                 IN clm_inward.shortfall_id%TYPE,
    v_claim_number                 IN clm_inward.claim_number%TYPE,
    v_added_by                     IN NUMBER,
    v_flag                         IN VARCHAR2,
    v_shortfall_seq_id             OUT shortfall_details.shortfall_seq_id%TYPE
  );
-- =================================================================================================================
  PROCEDURE delete_claim_records (
    v_claim_seq_id                  IN OUT clm_general_details.claim_seq_id%TYPE
  );
-- =================================================================================================================
  PROCEDURE save_inward_claim (
    v_claim_seq_id                       IN OUT clm_general_details.claim_seq_id%TYPE,
    v_claims_inward_seq_id               IN clm_general_details.claims_inward_seq_id%TYPE,
    v_mode_general_type_id               IN clm_general_details.mode_general_type_id%TYPE,
    v_requested_amount                   IN clm_general_details.requested_amount%TYPE  ,
    v_clm_enroll_detail_seq_id           IN OUT clm_enroll_details.clm_enroll_detail_seq_id%TYPE,
    v_member_seq_id                      IN clm_enroll_details.member_seq_id%TYPE,
    v_tpa_enrollment_id                  IN clm_enroll_details.tpa_enrollment_id%TYPE ,
    v_claimant_name                      IN clm_enroll_details.claimant_name%TYPE,
    v_policy_holder_name                 IN clm_enroll_details.policy_holder_name%TYPE,
    v_employee_name                      IN clm_enroll_details.employee_name%TYPE,
    v_employee_no                        IN clm_enroll_details.employee_no%TYPE,
    v_policy_number                      IN clm_enroll_details.policy_number%TYPE,
    v_policy_seq_id                      IN clm_enroll_details.policy_seq_id%TYPE,
    v_tpa_office_seq_id                   IN CLM_INWARD.tpa_office_seq_id%TYPE,
    v_document_general_type_id           IN CLM_INWARD.document_general_type_id%TYPE,
    v_email_id                           IN CLM_ENROLL_DETAILS.email_id%TYPE,
    v_notification_phone_number          IN CLM_ENROLL_DETAILS.notification_phone_number%TYPE,
    v_ins_scheme                     IN CLM_ENROLL_DETAILS.ins_scheme%TYPE,
    v_certificate_no                 IN CLM_ENROLL_DETAILS.certificate_no%TYPE,
    v_ins_customer_code              IN CLM_ENROLL_DETAILS.ins_customer_code%TYPE,
    v_added_by                           IN NUMBER,
    v_rows_processed                     OUT NUMBER
  );
-- =================================================================================================================
  PROCEDURE save_claims_payment (
    v_claim_seq_id                       IN  TPA_CLAIMS_PAYMENT.claim_seq_id%TYPE,
    v_status                             IN  TPA_CLAIMS_PAYMENT.claim_payment_status%TYPE,
    v_enrol_type_id                      IN  TPA_ENR_POLICY.enrol_type_id%TYPE,
    v_policy_seq_id                      IN  TPA_ENR_POLICY.Policy_Seq_Id%TYPE,
    v_member_seq_id                      IN  TPA_ENR_POLICY_MEMBER.Member_Seq_Id%TYPE,
    v_claim_general_type_id              IN  clm_inward.claim_general_type_id%TYPE,
    v_added_by                           IN  TPA_CLAIMS_PAYMENT.added_by%TYPE
  );
-- =================================================================================================================
  PROCEDURE select_intimation_list (
    v_member_seq_id                      IN  tpa_call_log.member_seq_id%TYPE,
    v_hosp_name                          IN  tpa_hosp_info.hosp_name%TYPE,
    v_start_date                         IN  VARCHAR2,
    v_end_date                           IN  VARCHAR2,
    v_added_by                           IN  NUMBER,
    v_sort_var                           IN  VARCHAR2,
    v_sort_order                         IN  VARCHAR2,
    v_start_num                          IN  NUMBER  ,
    v_end_num                            IN  NUMBER ,
    v_resultset                          OUT SYS_REFCURSOR
  );
-- =================================================================================================================
  PROCEDURE select_intimation (
    v_claim_seq_id                    IN  clm_general_details.claim_seq_id%TYPE,
    v_added_by                        IN  NUMBER,
    v_resultset                       OUT SYS_REFCURSOR
  );
-- =================================================================================================================
  PROCEDURE assoc_claim_intimation (
    v_claim_seq_id                       IN  clm_general_details.claim_seq_id%TYPE,
    v_call_log_seq_id                    IN  tpa_call_log.call_log_seq_id%TYPE,
    v_added_by                           IN  CLM_GENERAL_DETAILS.added_by%TYPE,
    v_rows_processed                     IN  OUT NUMBER
  );
-- =================================================================================================================
  PROCEDURE do_insert_ailments(
    v_claim_seq_id               IN clm_general_details.claim_seq_id%TYPE,
    v_parent_claim_seq_id        IN clm_general_details.claim_seq_id%TYPE,
    v_added_by                   IN NUMBER
  );
-- =================================================================================================================
  PROCEDURE validate_bill_date (
    v_claim_seq_id               IN clm_general_details.claim_seq_id%TYPE,
    v_bill_date                  IN clm_bill_header.bill_date%TYPE
  );
-- =================================================================================================================
  PROCEDURE manual_claim_rpt (
    where_clause              IN VARCHAR2, -- Pipe concatenated string of values
    cur                       OUT SYS_REFCURSOR
  );
-- =================================================================================================================
  PROCEDURE delete_claims (
    v_claim_seq_id                  IN OUT clm_general_details.claim_seq_id%TYPE,
    v_added_by                      IN NUMBER
  );
-- =================================================================================================================
  PROCEDURE pick_claim_to_quality_check;
-- =================================================================================================================
  PROCEDURE override_claims(
    v_claim_seq_id                        IN clm_general_details.claim_seq_id%TYPE ,
    v_added_by                            IN NUMBER,
    v_event_seq_id                        IN OUT CLM_GENERAL_DETAILS.event_seq_id%TYPE,
    v_review_count                        IN OUT CLM_GENERAL_DETAILS.review_count%TYPE,
    v_required_review_count               IN OUT CLM_GENERAL_DETAILS.required_review_count%TYPE,
    v_event_name                          OUT VARCHAR2,
    v_review                              OUT VARCHAR2
  );
  -- =================================================================================================================
  PROCEDURE select_bills_list(
    v_claim_seq_id                        IN clm_general_details.claim_seq_id%TYPE,
    v_added_by                            IN NUMBER,
    bills_cur                             OUT SYS_REFCURSOR
  );
  -- =================================================================================================================
  PROCEDURE select_lineitems_list(
    v_claim_bill_seq_id                   IN clm_bill_header.clm_bill_seq_id%TYPE,
    lineitem_cur                          OUT SYS_REFCURSOR
  );
  -- =================================================================================================================
    PROCEDURE select_lineitem(
    v_clm_bill_dtl_seq_id                 IN clm_bill_details.clm_bill_dtl_seq_id%TYPE,
    lineitem_cur                          OUT SYS_REFCURSOR
  );
  -- =================================================================================================================
  PROCEDURE select_clm_shortfall_list(
    v_tpa_enrollment_id              IN  CLM_ENROLL_DETAILS.tpa_enrollment_id%TYPE,
    v_claimant_name                  IN  CLM_ENROLL_DETAILS.claimant_name%TYPE,
    v_claim_number                   IN  CLM_GENERAL_DETAILS.claim_number%TYPE,
    v_sort_var                       IN  VARCHAR2 ,
    v_sort_order                     IN  VARCHAR2 ,
    v_start_num                      IN  NUMBER,
    v_end_num                        IN  NUMBER ,
    v_added_by                       IN  NUMBER,
    result_set                       OUT SYS_REFCURSOR
  );
  -- =================================================================================================================
    PROCEDURE select_open_shortfall_list (
    v_claim_seq_id               IN clm_general_details.claim_seq_id%TYPE,
    v_shortfall_id               IN clm_inward.shortfall_id%TYPE,
    result_set                   OUT SYS_REFCURSOR
  );
 --==============================================================================================
  PROCEDURE save_rejection_clauses(
    v_claim_seq_id                       IN  TPA_REJECTION_CLAUSES.claim_seq_id%TYPE,
    v_pat_enroll_detail_seq_id           IN  TPA_REJECTION_CLAUSES.pat_enroll_detail_seq_id%TYPE,
    v_clause_seq_ids                     IN  VARCHAR2, -- '|' concatenated string of select clause seq_ids
    v_rej_header_info                    IN  clm_general_details.rej_header_info%TYPE,
    v_rej_footer_info                    IN  clm_general_details.rej_footer_info%TYPE,
    v_ltr_general_type_id                IN  clm_general_details.ltr_general_type_id%TYPE,
    v_added_by                           IN  TPA_REJECTION_CLAUSES.added_by%TYPE,
    v_rejection_remarks                  OUT VARCHAR2,
    v_rows_processed                     IN  OUT NUMBER
  );
--=============================================================================================
  PROCEDURE select_rejection_clauses (
     v_claim_seq_id               IN clm_general_details.claim_seq_id%TYPE,
     v_pat_enroll_detail_seq_id   IN pat_enroll_details.pat_enroll_detail_seq_id%TYPE,
     v_policy_seq_id              IN clm_enroll_details.policy_seq_id%TYPE,
     v_enrol_type_id              IN clm_enroll_details.enrol_type_id%TYPE,
     v_date_of_hospitalization    IN DATE,
     v_resultset                  OUT SYS_REFCURSOR,
     v_rej_remarks                OUT SYS_REFCURSOR -- USE THIS ONLY IN THE CASE OF CLAIMS.
   );
-- =================================================================================================================
  FUNCTION check_dv_required(v_claim_seq_id   IN clm_general_details.claim_seq_id%TYPE ) RETURN CHAR;
-- =================================================================================================================
  PROCEDURE check_dv_required(v_claim_seq_id   IN clm_general_details.claim_seq_id%TYPE );
-- =================================================================================================================
  PROCEDURE get_letter_to (
    v_claim_general_type_id             IN VARCHAR2,
    v_ins_seq_id                        IN NUMBER,
    v_resultset                         OUT SYS_REFCURSOR
  );
-- =================================================================================================================
  PROCEDURE select_doctor_opinion(
     v_claim_seq_id                               IN ailment_details.claim_seq_id%TYPE,
     v_result_set                                 OUT SYS_REFCURSOR
  );
-- =================================================================================================================
  PROCEDURE save_doctor_opinion(
     v_claim_seq_id                               IN ailment_details.claim_seq_id%TYPE,
     v_doctor_opinion                             IN ailment_details.doctor_opinion%TYPE,
     v_added_by                                   IN NUMBER,
     v_rows_processed                             OUT NUMBER
  );
-- =================================================================================================================
  PROCEDURE correct_clm_buff_header(
     v_claim_seq_id                IN CLM_GENERAL_DETAILS.claim_seq_id%TYPE,
     v_pat_enroll_detail_seq_id    IN PAT_ENROLL_DETAILS.PAT_ENROLL_DETAIL_SEQ_ID%TYPE,
     v_buffer_hdr_seq_id           IN BUFFER_HEADER.buffer_hdr_seq_id%TYPE,
     v_deduct_amt                  IN NUMBER,
     v_flag                        IN VARCHAR2  --     'BTH' for both preauth and claim , 'CLM' for claim alone
  );
-- =================================================================================================================
  PROCEDURE check_revert_buffer(
    v_claim_seq_id                   IN clm_general_details.claim_seq_id%TYPE,
    v_added_by                       IN NUMBER
  );
-- =================================================================================================================
  PROCEDURE check_cash_benefit(
    v_clm_cash_benefit_seq_id  IN OUT clm_cash_benefit.clm_cash_benefit_seq_id%TYPE,
    v_claim_seq_id             IN clm_general_details.claim_seq_id%TYPE,
    v_member_seq_id            IN tpa_enr_policy_member.member_seq_id%TYPE,
    v_claim_file_number        IN clm_general_details.claim_file_number%TYPE,
    v_date_of_admission        IN clm_general_details.date_of_admission%TYPE,
    v_date_of_discharge        IN clm_general_details.date_of_discharge%TYPE,
    v_added_by                 IN NUMBER
  );
-- =================================================================================================================
  PROCEDURE create_cash_benefit_claim (
    v_prev_claim_seq_id                    IN OUT clm_general_details.claim_seq_id%TYPE,
    v_added_by                             IN NUMBER,
    v_clm_status_general_type_id           IN clm_enroll_details.clm_status_general_type_id%TYPE,
    v_rows_processed                       OUT NUMBER
  );
-- =================================================================================================================
  PROCEDURE select_cb_claim_list (
    v_claim_number                     clm_general_details.claim_number%TYPE,
    v_claim_settlement_number          clm_general_details.claim_settlement_number%TYPE,
    v_start_date                       VARCHAR2,
    v_end_date                         VARCHAR2,
    v_completed_yn                     VARCHAR2, -- 'Y' for completed, 'N' - not completed
    v_sort_var                         IN VARCHAR2 ,
    v_sort_order                       IN VARCHAR2 ,
    v_start_num                        IN NUMBER ,
    v_end_num                          IN NUMBER,
    result_set                         OUT SYS_REFCURSOR
  );
--========================================================================================================
  PROCEDURE save_claims_payment (
    v_claim_seq_id                       IN  TPA_CLAIMS_PAYMENT.claim_seq_id%TYPE,
    v_enrol_type_id                      IN  TPA_ENR_POLICY.enrol_type_id%TYPE,
    v_policy_seq_id                      IN  TPA_ENR_POLICY.Policy_Seq_Id%TYPE,
    v_member_seq_id                      IN  TPA_ENR_POLICY_MEMBER.Member_Seq_Id%TYPE,
    v_claim_general_type_id              IN  clm_inward.claim_general_type_id%TYPE,
    v_added_by                           IN  TPA_CLAIMS_PAYMENT.added_by%TYPE
  );
--========================================================================================================
  PROCEDURE delete_clm_cash_benefit (
    v_seq_id                             IN  clm_general_details.claims_inward_seq_id%TYPE,
    v_claim_seq_id                       IN  clm_general_details.claim_seq_id%TYPE,
    v_added_by                           IN  NUMBER
  );
--========================================================================================================
  PROCEDURE re_assign_enrl_id (
    v_claim_seq_id               IN  clm_general_details.claim_seq_id%TYPE,
    v_clm_status_general_type_id IN  clm_enroll_details.clm_status_general_type_id%TYPE,
    v_member_seq_id              IN  clm_enroll_details.member_seq_id%TYPE,
    v_added_by                   IN  NUMBER,
    v_rows_pocessed              OUT NUMBER
  );
--========================================================================================================
 FUNCTION mem_buff_availaility(
    v_required_buffer              IN tpa_enr_balance.buffer_amount%TYPE,
    v_policy_seq_id                IN tpa_enr_policy.policy_seq_id%TYPE ,
    v_policy_group_seq_id          IN tpa_enr_policy_member.policy_group_seq_id%TYPE ,
    v_member_seq_id                IN tpa_enr_policy_member.member_seq_id%TYPE  ,
    v_mem_general_type_id          IN tpa_enr_policy_member.mem_general_type_id%TYPE,
    v_claim_type                   IN VARCHAR2,
    v_buffer_type                  IN VARCHAR2
  ) RETURN BOOLEAN;
--========================================================================================================
  FUNCTION pol_buff_availability(
    v_required_buffer              IN tpa_enr_balance.buffer_amount%TYPE,
    v_policy_seq_id                IN tpa_enr_policy.policy_seq_id%TYPE,
    v_claim_type                   IN VARCHAR2,
    v_buffer_type                  IN VARCHAR2
  )RETURN BOOLEAN;
--========================================================================================================
  PROCEDURE return_clm_to_coding (
    v_seq_id                              IN NUMBER,
    v_event_seq_id                        IN tpa_event.event_seq_id%TYPE
  );
--========================================================================================================
  PROCEDURE service_tax_validation (
    v_claim_seq_id               IN  clm_general_details.claim_seq_id%TYPE,
    v_ward_type_id               IN  clm_bill_details.ward_type_id%TYPE,
    v_clm_bill_dtl_seq_id        IN  clm_bill_details.clm_bill_dtl_seq_id%TYPE
  );
--========================================================================================================
  PROCEDURE calc_service_tax(
    v_claim_seq_id     IN clm_general_details.claim_seq_id%TYPE,
    v_co_pay_amt       IN clm_general_details.co_payment_amount%TYPE,
    v_discount_amt     IN clm_general_details.discount_amount%TYPE,
    v_service_tax_calc_amt  IN OUT clm_general_details.serv_tax_calc_amount%TYPE,
    v_final_appr_amt   IN OUT clm_general_details.Total_App_Amount%TYPE,
    v_serv_tax_calc_percentage  IN OUT clm_general_details.serv_tax_calc_percentage%TYPE
  );
--========================================================================================================
 PROCEDURE p_clm_inw_del_log (v_clm_inw_seq_id    clm_inward.claims_inward_seq_id%TYPE);

--========================================================================================================

  PROCEDURE copay_adviced(
         v_mem_seq_id           IN   pat_enroll_details.member_seq_id%TYPE,
         v_pol_grp_seq_id       IN   Tpa_enr_policy_group.policy_group_seq_id%TYPE,
         v_balance_seq_id       IN   Tpa_enr_balance.balance_seq_id%TYPE,
         v_clm_pat_seq_id       IN   pat_general_details.pat_gen_detail_seq_id%TYPE,
         v_appr_amt             OUT  Tpa_enr_balance.sum_insured%TYPE,
         v_max_copay            OUT  Tpa_enr_balance.sum_insured%TYPE);
 --===============================================================================================
 FUNCTION copay_restrict_check( v_mem_seq_id           IN Pat_enroll_details.member_seq_id%TYPE,
                                v_si_type              IN Tpa_ins_prod_policy.si_type%TYPE,
                                v_prod_policy_seq_id   IN Tpa_ins_prod_policy.prod_policy_seq_id%TYPE,
                                v_pat_gen_seq_id       IN pat_general_details.pat_gen_detail_seq_id%TYPE,
                                v_pat_app_amount       IN Tpa_enr_balance.sum_insured%TYPE,
                                v_clm_app_amount       IN Tpa_enr_balance.sum_insured%TYPE,
                                v_tot_sum_insured      IN Tpa_enr_balance.sum_insured%TYPE,
                                v_used_sum_insured     IN Tpa_enr_balance.utilised_sum_insured%TYPE,
                                v_rest_sum_insured     IN Tpa_enr_balance.restrict_amt%TYPE,
                                v_used_rest_si         IN Tpa_enr_balance.used_restrict_amt%TYPE,
                                v_max_app_amount       IN Tpa_enr_balance.sum_insured%Type,
                                v_pat_buff_amount      IN Buffer_header.pre_auth_buffer_app_amount%TYPE,
                                v_co_payment_amount    IN Pat_general_details.co_payment_amount%TYPE,
                                v_restrict_yn          IN Tpa_ins_prod_policy.si_restrict_yn%TYPE)
    RETURN NUMBER;
--======================================================================================================
   PROCEDURE  p_rest_si(v_clm_enroll_detail_seq_id  IN  clm_enroll_details.clm_enroll_detail_seq_id%type,
                       v_member_seq_id             IN  pat_enroll_details.member_seq_id%type,
                       v_policy_group_seq_id       IN OUT Tpa_enr_policy_group.policy_group_seq_id%type,
                       v_ctr2                      OUT NUMBER,
                       v_pat_typr                  IN VARCHAR2:=NULL);
 --==========================================================================================
  PROCEDURE age_amount_rest(v_pat_clm_seq_id   IN Pat_General_Details.pat_gen_detail_seq_id%TYPE,
                            v_type             IN VARCHAR2,
                            v_config_amt       OUT TPA_ENR_BALANCE.Sum_Insured%TYPE,
                            v_used_amt         OUT TPA_ENR_BALANCE.Sum_Insured%TYPE,
                            v_age_flag         OUT VARCHAR2 );
 --==========================================================================================
procedure cash_benefit_details(
    v_claim_seq_id  IN clm_general_details.claim_seq_id%TYPE,
    v_member_seq_id IN tpa_enr_policy_member.member_seq_id%TYPE,
    v_final_amt     OUT clm_cash_benefit.cb_approved_amount%TYPE,
    v_final_days    OUT clm_cash_benefit.cb_approved_amount%TYPE);
---=================================================================
procedure conv_cash_benefit(
  v_claim_seq_id  IN clm_general_details.claim_seq_id%TYPE,
  v_member_seq_id IN tpa_enr_policy_member.member_seq_id%TYPE,
  v_final_amt     OUT clm_cash_benefit.cb_approved_amount%TYPE,
  v_final_days    OUT clm_cash_benefit.cb_approved_amount%TYPE);
--=========================================================================================
 PROCEDURE unassoc_claim_intimation (--KOC1349
    v_claim_seq_id                       IN  clm_general_details.claim_seq_id%TYPE,
    v_call_log_seq_id                    IN  tpa_call_log.call_log_seq_id%TYPE,
    v_added_by                           IN  CLM_GENERAL_DETAILS.added_by%TYPE,
    v_rows_processed                     IN  OUT NUMBER);
--=========================================================================================
PROCEDURE claims_freeze ( --KOCBJJ
          v_claim_seq_id                   IN clm_enroll_details.claim_seq_id%TYPE,
          v_clm_status_gen_type_id         IN clm_enroll_details.clm_status_general_type_id%TYPE,
          v_flag                           IN VARCHAR2,
          v_added_by                       IN NUMBER DEFAULT NULL);
--=========================================================================================
 PROCEDURE clm_ins_intimate(v_claim_seq_id                  IN clm_general_details.claim_seq_id%TYPE,
                            v_clm_status_general_type_id    IN clm_enroll_details.clm_status_general_type_id%TYPE,
                            v_max_app_amount                IN clm_general_details.total_app_amount%TYPE,
                            v_flag                          IN VARCHAR2,
                            v_added_by                      in number );
--=========================================================================================
PROCEDURE claims_freeze_set_review (
          v_claim_seq_id                   IN clm_enroll_details.claim_seq_id%TYPE);
procedure close_claim(v_shortfal_email_seq_id in app.shortfall_email_dtl.shortfal_email_seq_id%type);

----=================================================================================================
procedure critical_benefit_check(v_claim_seq_id      IN ASSIGN_USERS.claim_seq_id%TYPE,
                                                   v_product_seq_id    in tpa_enr_policy.product_seq_id%type,
                                                   v_policy_seq_id     in tpa_enr_policy.policy_seq_id%type,
                                                   v_enrol_type_id     in tpa_enr_policy.enrol_type_id%type,
                                                   v_Mem_Age           in tpa_enr_policy_member.mem_age%type,
                                                   v_tpa_enrollment_id in tpa_enr_policy_member.tpa_enrollment_id%type,
                                                   v_diagnosis_dt      in ailment_details.diagnosis_dt%type,
                                                   v_certificate_dt    in ailment_details.date_of_certificate%type,
                                                   v_date_of_inception in tpa_enr_policy_member.date_of_inception%type,
                                                   v_member_seq_id     in tpa_enr_policy_member.member_seq_id%type,
                                                   v_claim_sub_general_type_id in clm_general_details.claim_sub_general_type_id%type);
---=============================================================================================
 FUNCTION get_buff_type_amt(v_claim_seq_id               IN clm_general_details.claim_seq_id%type,
                           v_mode                       IN CHAR ) RETURN SYS_REFCURSOR;
---=============================================================================================
PROCEDURE check_buff_approved(v_claim_seq_id            IN clm_general_details.claim_seq_id%type,
                              v_balance_seq_id          IN tpa_enr_balance.balance_seq_id%type,
                              v_curr_util_buff_amt      IN clm_general_details.total_app_amount%type,
                              v_type                    IN CHAR,
                              v_added_by                IN NUMBER);
 ---=============================================================================================
PROCEDURE claims_ins_error_check ( --KOCBJJ
          v_claim_seq_id                   IN clm_enroll_details.claim_seq_id%TYPE,
          v_clm_status_gen_type_id         IN clm_enroll_details.clm_status_general_type_id%TYPE,
          v_added_by                       IN NUMBER DEFAULT NULL);
 ---=============================================================================================

 PROCEDURE select_bills_save_next(
     v_claim_seq_id                        IN clm_general_details.claim_seq_id%TYPE,
     v_clm_bill_dtl_seq_id                 IN OUT clm_bill_details.clm_bill_dtl_seq_id%TYPE,
     v_clm_bill_seq_id                     IN clm_bill_details.clm_bill_seq_id%TYPE,
     v_description                         IN clm_bill_details.description%TYPE,
     v_ward_type_id                        IN clm_bill_details.ward_type_id%TYPE,
     v_room_type_id                        IN clm_bill_details.room_type_id%TYPE,
     v_number_of_days                      IN clm_bill_details.number_of_days%TYPE,
     v_requested_amount                    IN clm_bill_details.requested_amount%TYPE,
     v_allow_yn                            IN clm_bill_details.allow_yn%TYPE,
     v_allowed_amount                      IN clm_bill_details.allowed_amount%TYPE,
     v_remarks                             IN clm_bill_details.remarks%TYPE,
     v_vaccination_type_id                 IN CLM_BILL_DETAILS.VACCINATION_TYPE_ID%TYPE, --KOC1164
     v_added_by                            IN NUMBER,
     bills_cur                             OUT SYS_REFCURSOR );
 ---=============================================================================================
  PROCEDURE save_clm_diagnosys ( v_diagnosys_seq_id              IN OUT tpa_diagnosys_details.diagnosys_seq_id%type,
                                 v_claim_seq_id                  IN clm_bill_header.claim_seq_id%type,
                                 v_diagnosys_name                IN tpa_diagnosys_details.diagnosys_name%type,
                                 v_diag_type_id                  IN varchar2,
                                 v_added_by                      IN clm_bill_header.added_by%type,
                                 v_hospital_general_type_id      IN ICD_PCS_DETAIL.hospital_general_type_id%TYPE,
                                 v_trtmnt_plan_general_type_id   IN ICD_PCS_DETAIL.trtmnt_plan_general_type_id%TYPE,
                                 v_frequency_of_visit            IN ICD_PCS_DETAIL.frequency_of_visit%TYPE,
                                 v_pat_duration_general_type_id  IN AILMENT_DETAILS.pat_duration_general_type_id%TYPE,
                                 v_no_of_visits                  IN ICD_PCS_DETAIL.no_of_visits%TYPE,
                                 v_tariff_general_type_id        IN ICD_PCS_DETAIL.tariff_general_type_id%TYPE,                            
                                 v_pkg_seq_id                    IN PAT_PACKAGE_PROCEDURES.PKG_SEQ_ID%TYPE,
                                 v_rows_processed             OUT NUMBER);
 --=========================================================================================

  PROCEDURE select_clm_diagnosys_list (v_claim_seq_id      IN clm_bill_header.claim_seq_id%type,
                                       v_resultset         OUT SYS_REFCURSOR);

 --=========================================================================================
   PROCEDURE select_clm_diagnosys (v_diagnosys_seq_id  IN OUT tpa_diagnosys_details.diagnosys_seq_id%type,
                                  v_resultset         OUT SYS_REFCURSOR);
 --=========================================================================================
   PROCEDURE delete_clm_diagnosys (v_diagnosys_seq_id  IN tpa_diagnosys_details.diagnosys_seq_id%type,
                                  v_rows_processed    OUT NUMBER);
 --========================================================================================= 
END CLAIMS_PKG;

/

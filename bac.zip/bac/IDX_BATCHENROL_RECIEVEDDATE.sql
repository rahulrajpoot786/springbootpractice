--------------------------------------------------------
--  DDL for Synonymn IDX_BATCHENROL_RECIEVEDDATE
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."IDX_BATCHENROL_RECIEVEDDATE" FOR "APP"."IDX_BATCHENROL_RECIEVEDDATE";

--------------------------------------------------------
--  DDL for Package CHEQUE_INFO_PKG
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "VENUBABU"."CHEQUE_INFO_PKG" IS

  -- Author  : GOVARDHANA_RG
  -- Created : 5/12/2006 5:53:30 PM
  -- Purpose : List Of Cheques And Status of Payments.
--=====================================================================================
  PROCEDURE select_chq_list(
    v_check_num             IN    TPA_CLAIMS_CHECK.check_num%TYPE,
    v_float_acc_number      IN    TPA_FLOAT_ACCOUNT.float_account_number%TYPE,
    v_check_status          IN    TPA_CLAIMS_CHECK.check_status%TYPE,
    v_start_date            IN    VARCHAR2,
    v_end_date              IN    VARCHAR2,
    v_claim_settlement_no   IN    TPA_CLAIMS_PAYMENT.claim_settlement_no%TYPE,
    v_claim_type            IN    TPA_CLAIMS_PAYMENT.claim_type%TYPE,
    v_ins_seq_id            IN    TPA_INS_INFO.ins_seq_id%TYPE,
    v_ins_comp_code_number  IN    TPA_INS_INFO.ins_comp_code_number%TYPE,
    v_batch_number          IN    TPA_CLAIMS_CHECK.batch_number%TYPE,
    v_policy_number         IN    TPA_ENR_POLICY.policy_number%TYPE,
    v_enrollment_id         IN    TPA_ENR_POLICY_MEMBER.tpa_enrollment_id%TYPE,
    v_payee_method          IN    TPA_CLAIMS_PAYMENT.payee_type%TYPE,
    v_sort_var              IN    VARCHAR2,
    v_sort_order            IN    VARCHAR2 := 'ASC',
    v_start_num             IN    NUMBER   := 1,
    v_end_num               IN    NUMBER   := 25,
    v_added_by              IN    NUMBER,
    v_qatar_id              IN    TPA_ENR_POLICY_MEMBER.Emirate_Id%type,
    result_set              OUT    SYS_REFCURSOR
  );
--=======================================================================================
  PROCEDURE chq_details_save(
    v_claims_chq_seq_id      IN OUT  TPA_CLAIMS_CHECK.claims_chk_seq_id%TYPE,
    v_cheque_status          IN      TPA_CLAIMS_CHECK.check_status%TYPE,
    v_cleared_date           IN      TPA_CLAIMS_CHECK.cleared_date%TYPE,
    v_comments               IN      TPA_FLOAT_ACCOUNT.comments%TYPE,
    v_added_by               IN      NUMBER,
    v_rows_processed         OUT     INTEGER
  );
--=======================================================================================
  PROCEDURE select_chq_detail(
    v_seq_id                IN OUT tpa_claims_check.claims_chk_seq_id%TYPE,
    v_payment_seq_id        IN     TPA_CLAIMS_PAYMENT.payment_seq_id%TYPE,--only in case of cheque detail info
    v_float_seq_id          IN     TPA_CLAIMS_PAYMENT.float_seq_id%TYPE,
    v_added_by              IN     NUMBER,
    result_set              OUT     SYS_REFCURSOR
  );

 --=========================================================================================
END cheque_info_pkg;

/

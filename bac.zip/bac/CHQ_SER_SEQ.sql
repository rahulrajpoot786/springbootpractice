--------------------------------------------------------
--  DDL for Synonymn CHQ_SER_SEQ
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."CHQ_SER_SEQ" FOR "APP"."CHQ_SER_SEQ";

--------------------------------------------------------
--  DDL for Package HOSPITAL_PKG
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "VENUBABU"."HOSPITAL_PKG" 
is

PROCEDURE create_preauth_xml (
    v_pat_gen_detail_seq_id                 IN  pat_general_details.pat_gen_detail_seq_id%TYPE,
    v_hosp_seq_id                           IN Tpa_Hosp_Info.Hosp_Seq_Id%type,
    v_preauth_history_doc                   OUT XMLTYPE
)  ;

PROCEDURE create_claim_xml (
    v_claim_seq_id                          IN clm_general_details.claim_seq_id%TYPE,
    v_hosp_seq_id                           IN  tpa_hosp_info.hosp_seq_id%type,
    v_claim_history_doc                     OUT XMLTYPE
   );


/*PROCEDURE select_claims_list (
    v_claim_number                   IN  clm_general_details.claim_number%TYPE,
    v_auth_number                    IN  CLM_GENERAL_DETAILS.CLAIM_SETTLEMENT_NUMBER%TYPE,    v_tpa_enrollment_id              IN  clm_enroll_details.tpa_enrollment_id%TYPE,
    v_clm_status_general_type_id     IN  clm_enroll_details.clm_status_general_type_id%TYPE,
    v_policy_number                  IN  clm_enroll_details.policy_number%TYPE,
    v_date_of_admission                  IN  VARCHAR2,
    v_clm_rcvd_date                      IN  VARCHAR2,
    v_start_date                         IN  VARCHAR2,
    v_end_date                           IN  VARCHAR2,
    v_hosp_seq_id                    IN  TPA_HOSP_INFO.Hosp_Seq_Id%type,
    v_patient_name                   IN clm_enroll_details.claimant_name%type,--kocnewHosp
    v_discharge_date                 IN  VARCHAR2,--kocnewHosp
    v_sort_var                       IN  VARCHAR2,
    v_sort_order                     IN  VARCHAR2,
    v_start_num                      IN  NUMBER ,
    v_end_num                        IN  NUMBER ,
    result_set                       OUT SYS_REFCURSOR
  );
PROCEDURE select_pre_auth_list (
    v_pre_auth_number                    IN  PAT_ENROLL_DETAILS.pre_auth_number%TYPE,
    v_auth_number                        IN  PAT_ENROLL_DETAILS.AUTH_NUMBER%TYPE,
    v_tpa_enrollment_id                  IN  PAT_ENROLL_DETAILS.tpa_enrollment_id%TYPE,
    v_pat_status_general_type_id         IN  PAT_ENROLL_DETAILS.pat_status_general_type_id%TYPE,
    v_policy_number                      IN  PAT_ENROLL_DETAILS.Policy_Number%TYPE,
    v_date_of_admission                  IN  VARCHAR2,
    v_pat_rcvd_date                      IN  VARCHAR2,
    v_start_date                         IN  VARCHAR2,
    v_end_date                           IN  VARCHAR2,
    v_hosp_seq_id                        IN  TPA_HOSP_INFO.HOSP_SEQ_ID%TYPE,
    v_pateint_name                       IN pat_enroll_details.claimant_name%TYPE,
    v_sort_var                           IN  VARCHAR2,
    v_sort_order                         IN  VARCHAR2 ,
    v_start_num                          IN  NUMBER ,
    v_end_num                            IN  NUMBER ,
    result_set                           OUT SYS_REFCURSOR
  );
*/
PROCEDURE select_enrollment_id_list (
    v_tpa_enrollment_id                  IN  PAT_ENROLL_DETAILS.tpa_enrollment_id%TYPE,
    v_policy_number                      IN  PAT_ENROLL_DETAILS.policy_number%TYPE,
    v_sort_var                           IN VARCHAR2,
    v_sort_order                         IN VARCHAR2,
    v_start_num                          IN NUMBER ,
    v_end_num                            IN NUMBER,
    v_current_record_yn                  IN CHAR  ,
    result_set                           OUT SYS_REFCURSOR
  );

PROCEDURE select_enrollment_id (
    v_member_seq_id                      IN  PAT_ENROLL_DETAILS.tpa_enrollment_id%TYPE,
    result_set                           OUT SYS_REFCURSOR
  ) ;

/*PROCEDURE save_claim (
    -- CLM_ENROLL_DETAILS
    v_clm_enroll_detail_seq_id           IN  OUT CLM_ENROLL_DETAILS.clm_enroll_detail_seq_id%TYPE,
    v_claim_seq_id                       IN  OUT CLM_ENROLL_DETAILS.claim_seq_id%TYPE,
    v_gender_general_type_id             IN  CLM_ENROLL_DETAILS.gender_general_type_id%TYPE,
    v_member_seq_id                      IN  CLM_ENROLL_DETAILS.member_seq_id%TYPE,
    v_tpa_enrollment_id                  IN  CLM_ENROLL_DETAILS.tpa_enrollment_id%TYPE,
    v_policy_seq_id                      IN  CLM_ENROLL_DETAILS.policy_seq_id%TYPE,
    v_policy_holder_name                 IN  CLM_ENROLL_DETAILS.policy_holder_name%TYPE,
    v_employee_no                        IN  CLM_ENROLL_DETAILS.employee_no%TYPE,
    v_employee_name                      IN  CLM_ENROLL_DETAILS.employee_name%TYPE,
    v_mem_age                            IN  CLM_ENROLL_DETAILS.mem_age%TYPE,
    v_claimant_name                      IN  CLM_ENROLL_DETAILS.claimant_name%TYPE,
    v_date_of_inception                  IN  CLM_ENROLL_DETAILS.date_of_inception%TYPE,
    v_date_of_exit                       IN  CLM_ENROLL_DETAILS.date_of_exit%TYPE,
    v_relship_type_id                    IN  CLM_ENROLL_DETAILS.relship_type_id%TYPE,
    v_policy_number                      IN  CLM_ENROLL_DETAILS.policy_number%TYPE,
    v_claimant_phone_number              IN  CLM_ENROLL_DETAILS.claimant_phone_number%TYPE,
    v_mem_total_sum_insured              IN  CLM_ENROLL_DETAILS.mem_total_sum_insured%TYPE,
    v_enrol_type_id                      IN  CLM_ENROLL_DETAILS.enrol_type_id%TYPE,
    v_policy_sub_general_type_id         IN  CLM_ENROLL_DETAILS.policy_sub_general_type_id%TYPE,
    v_phone_1                            IN  CLM_ENROLL_DETAILS.phone_1%TYPE,
    v_policy_effective_from              IN  CLM_ENROLL_DETAILS.policy_effective_from%TYPE,
    v_policy_effective_to                IN  CLM_ENROLL_DETAILS.policy_effective_to%TYPE,
    v_ins_status_general_type_id         IN  CLM_ENROLL_DETAILS.ins_status_general_type_id%TYPE,
    v_ins_seq_id                         IN  CLM_ENROLL_DETAILS.ins_seq_id%TYPE,
    v_group_reg_seq_id                   IN  CLM_ENROLL_DETAILS.group_reg_seq_id%TYPE,
-----CLM_GENERAL_DETAILS
    v_claims_inward_seq_id               IN  out CLM_GENERAL_DETAILS.claims_inward_seq_id%TYPE,
    v_requested_amount                   IN  CLM_GENERAL_DETAILS.requested_amount%TYPE,
    v_pat_enroll_detail_seq_id           IN  CLM_GENERAL_DETAILS.pat_enroll_detail_seq_id%TYPE,
    v_auth_number                        IN  CLM_GENERAL_DETAILS.auth_number%TYPE,
    v_request_general_type_id            IN  CLM_GENERAL_DETAILS.request_general_type_id%TYPE,
    v_claim_sub_general_type_id          IN  CLM_GENERAL_DETAILS.claim_sub_general_type_id%TYPE,
    v_reason_for_dom                     IN  clm_general_details.DOM_REASON_GEN_TYPE_ID%type,--KOC1285
    v_doctor_certified_YN                IN  CLM_GENERAL_DETAILS.DOC_CERT_DOM_YN%type,--KOC1285
    v_mode_general_type_id               IN  CLM_GENERAL_DETAILS.mode_general_type_id%TYPE,
    v_treating_dr_name                   IN  CLM_GENERAL_DETAILS.treating_dr_name%TYPE,
    v_in_patient_no                      IN  CLM_GENERAL_DETAILS.in_patient_no%TYPE,
    v_claims_remarks                     IN  CLM_GENERAL_DETAILS.claims_remarks%TYPE,
    v_ava_sum_insured                    IN  OUT CLM_GENERAL_DETAILS.ava_sum_insured%TYPE,
    v_ava_cum_bonus                      IN  OUT CLM_GENERAL_DETAILS.ava_cum_bonus%TYPE,
    v_date_of_admission                  IN  CLM_GENERAL_DETAILS.date_of_admission%TYPE,
    v_date_of_discharge                  IN  CLM_GENERAL_DETAILS.date_of_discharge%TYPE,
    v_parent_claim_seq_id                IN  OUT CLM_GENERAL_DETAILS.parent_claim_seq_id%TYPE,
----CLM_HOSPITAL_ASSOCIATION
    v_clm_hosp_assoc_seq_id              IN  OUT CLM_HOSPITAL_ASSOCIATION.clm_hosp_assoc_seq_id%TYPE,
    v_hosp_seq_id                        IN  CLM_HOSPITAL_ASSOCIATION.hosp_seq_id%TYPE,
    v_empanel_number                     IN  CLM_HOSPITAL_ASSOCIATION.empanel_number%TYPE,
    v_hosp_name                          IN  OUT CLM_HOSPITAL_ASSOCIATION.hosp_name%TYPE,
    v_address_1                          IN  OUT CLM_HOSPITAL_ASSOCIATION.address_1%TYPE,
    v_address_2                          IN  OUT CLM_HOSPITAL_ASSOCIATION.address_2%TYPE,
    v_address_3                          IN  OUT CLM_HOSPITAL_ASSOCIATION.address_3%TYPE,
    v_state_name                         IN  OUT CLM_HOSPITAL_ASSOCIATION.state_name%TYPE,
    v_city_name                          IN  OUT CLM_HOSPITAL_ASSOCIATION.city_name%TYPE,
    v_pin_code                           IN  OUT CLM_HOSPITAL_ASSOCIATION.pin_code%TYPE,
    v_off_phone_no_1                     IN  OUT CLM_HOSPITAL_ASSOCIATION.off_phone_no_1%TYPE,
    v_off_phone_no_2                     IN  OUT CLM_HOSPITAL_ASSOCIATION.off_phone_no_2%TYPE,
    v_office_fax_no                      IN  OUT CLM_HOSPITAL_ASSOCIATION.office_fax_no%TYPE,
    v_remarks                            IN  CLM_HOSPITAL_ASSOCIATION.remarks%TYPE,
    v_serv_tax_rgn_number                IN  CLM_HOSPITAL_ASSOCIATION.serv_tax_rgn_number%TYPE,
-----CLM_HOSPITAL_ADDITIONAL_DTL
    v_prev_hosp_claim_seq_id             IN  OUT CLM_GENERAL_DETAILS.prev_hosp_claim_seq_id%TYPE,
    v_claim_dms_reference_id             IN  CLM_GENERAL_DETAILS.claim_dms_reference_id%TYPE,
    v_pat_approved_amount                IN  CLM_GENERAL_DETAILS.pat_approved_amount%TYPE,
    v_re_open_type                       IN  CLM_GENERAL_DETAILS.re_open_type%TYPE,
    v_doctor_registration_no             IN  CLM_GENERAL_DETAILS.doctor_registration_no%TYPE,
    v_email_id                           IN  CLM_ENROLL_DETAILS.email_id%TYPE,
    v_notification_phone_number          IN  CLM_ENROLL_DETAILS.notification_phone_number%TYPE,
    v_ins_scheme                         IN  PAT_ENROLL_DETAILS.ins_scheme%TYPE,
    v_certificate_no                     IN  PAT_ENROLL_DETAILS.certificate_no%TYPE,
    v_ins_customer_code                  IN  PAT_ENROLL_DETAILS.ins_customer_code%TYPE,
    v_insur_ref_number                   IN  CLM_GENERAL_DETAILS.Insur_Ref_Number%TYPE, --insur-ref-number
    v_added_by                           IN  CLM_HOSPITAL_ADDITIONAL_DTL.added_by%TYPE,
    v_rows_processed                     IN  OUT NUMBER,
    v_last_buffer_detail_seq_id          IN  buffer_details.buff_detail_seq_id%TYPE := NULL,
    v_parent_modif_mode_value            IN  CLM_ENROLL_DETAILS.modification_mode_value%TYPE := NULL,
    v_tpa_office_seq_id                  IN OUT CLM_INWARD.tpa_office_seq_id%TYPE  ,
    v_received_date                      IN clm_inward.rcvd_date%type);*/






PROCEDURE pat_clm_file_upload (
    v_tpa_enrollment_id       IN TPA_ENR_POLICY_MEMBER.TPA_ENROLLMENT_ID%TYPE,
    v_policy_number           IN TPA_ENR_POLICY.POLICY_NUMBER%TYPE,
    v_file_name               IN VARCHAR2,
    v_mode                    IN CHAR , --  'PAT','CLM'
    v_document_type           IN CHAR,
    v_remarks                 IN VARCHAR2,
    v_hosp_seq_id             IN tpa_hosp_info.hosp_seq_id%type,
    v_rows_processed          OUT number
  );
PROCEDURE select_pat_clm_file_upload (
    v_tpa_enrollment_id       IN VARCHAR2,
    v_mode                    IN CHAR , --  'PAT','CLM'
    v_hosp_seq_id             IN tpa_hosp_info.hosp_seq_id%type,
    v_start_date              IN VARCHAR2,
    v_end_date                IN VARCHAR2,
    v_sort_var                IN VARCHAR2,
    v_sort_order              IN VARCHAR2,
    v_start_num               IN NUMBER ,
    v_end_num                 IN NUMBER ,
    v_result_set              OUT sys_refcursor
  );


PROCEDURE bills_pending_rpt(
    v_input_list        IN  VARCHAR2,
    v_result_set      OUT SYS_REFCURSOR
  );

PROCEDURE Claims_Summary_Rpt(
    v_input_list        IN  VARCHAR2,
    v_clm_rslt_set      OUT SYS_REFCURSOR
  );

PROCEDURE  Claims_Detailed_Rpt (
    v_input_list IN  VARCHAR2,
    v_result_set  OUT SYS_REFCURSOR
  );

PROCEDURE forgot_password(
    v_empanel_id       IN       tpa_hosp_info.empanel_number%type,
    v_userid           IN       tpa_user_contacts.employee_number%TYPE,
    v_result           OUT VARCHAR2 );

procedure Dashboard_preauth(
    v_input_list        IN  VARCHAR2,
    v_result_set       OUT SYS_REFCURSOR);

procedure Dashboard_claims(
    v_input_list        IN  VARCHAR2,
    v_result_set       OUT SYS_REFCURSOR);

procedure dash_board_claims (v_hosp_seq_id tpa_hosp_info.hosp_seq_id%type,
                             v_frm_date IN VARCHAR2,
                             v_todate   IN VARCHAR2,
                             v_out_xml     out xmltype);

procedure dash_board_preauth (v_hosp_seq_id tpa_hosp_info.hosp_seq_id%type,
                              v_frm_date IN VARCHAR2,
                              v_todate   IN VARCHAR2,
                              v_out_xml     out xmltype);

procedure dash_board_pat_clm (v_hosp_seq_id tpa_hosp_info.hosp_seq_id%type,
                              v_out_xml     out xmltype) ;

procedure select_hosp_details(
    v_input_list        IN  VARCHAR2,
    v_flag              IN  VARCHAR2,
    v_result_set       OUT SYS_REFCURSOR);
--=============================================================================
  PROCEDURE select_pre_auth_list (
    v_hosp_empanel_no                    IN  TPA_HOSP_INFO.EMPANEL_NUMBER%TYPE,
    v_pre_auth_number                    IN  pat_authorization_details.pre_auth_number%TYPE,
    v_from_date                          IN  VARCHAR2,
    v_to_date                            IN  VARCHAR2,
    v_claimant_name                      IN  pat_authorization_details.mem_name%TYPE,
    v_authorization_no                   IN  pat_authorization_details.auth_number%type,
    v_docs_name                          IN  tpa_hosp_professionals.contact_name%TYPE,
    v_tpa_enrollment_id                  IN  pat_authorization_details.tpa_enrollment_id%TYPE,
    v_benefit_type                       IN  VARCHAR2,
    v_pat_status_general_type_id         IN  pat_authorization_details.pat_status_type_id%TYPE,
    v_pl_preauth_refno                   in  pat_authorization_details.pl_preauth_refno%type,
    v_emirate_id                         IN  app.tpa_enr_policy_member.emirate_id%type,
    v_event_no                           IN  pat_authorization_details.event_no%TYPE,
    v_sort_var                           IN  VARCHAR2,
    v_sort_order                         IN  VARCHAR2 ,
    v_start_num                          IN  VARCHAR2 ,
    v_end_num                            IN  VARCHAR2 ,
    v_srtfll_status_type                 IN  Shortfall_Details.Srtfll_Status_General_Type_Id%TYPE,
    v_inp_status                         IN  VARCHAR2,
    result_set                           OUT SYS_REFCURSOR
  );
--=============================================================================
PROCEDURE select_preauth_details ( v_hosp_empanel_no          tpa_hosp_info.empanel_number%type,
                                   v_pat_auth_seq_id          pat_authorization_details.pat_auth_seq_id%type,
                                   result_set                 OUT SYS_REFCURSOR 
                                 );  
--================================================================================================
PROCEDURE select_claims_list (
    v_hosp_empanel_no                    IN  TPA_HOSP_INFO.EMPANEL_NUMBER%TYPE,
    v_from_date                          IN  VARCHAR2,
    v_to_date                            IN  VARCHAR2,
    v_mem_name                           IN  clm_authorization_details.mem_name%type,
    v_tpa_enrollment_id                  IN  clm_authorization_details.tpa_enrollment_id%type,
    v_claim_number                       IN  clm_authorization_details.claim_number%type,
    v_invoice_number                     IN  clm_authorization_details.invoice_number%type,
    v_claim_type                         IN  clm_batch_upload_details.clm_type_gen_type_id%type,
    v_batch_no                           IN  clm_batch_upload_details.batch_no%type,
    v_benefit_type                       IN  VARCHAR2,
    v_clm_status_type_id                 IN  clm_authorization_details.clm_status_type_id%type,
    v_check_num                          IN  tpa_claims_check.check_num%TYPE,
    v_emirate_id                         IN  app.tpa_enr_policy_member.emirate_id%type,
    v_sort_var                           IN  VARCHAR2,
    v_sort_order                         IN  VARCHAR2 ,
    v_start_num                          IN  NUMBER ,
    v_end_num                            IN  NUMBER ,
    result_set                           OUT SYS_REFCURSOR
  );
--====================================================================================
PROCEDURE select_shortfall_details ( v_pat_auth_seq_id          pat_authorization_details.pat_auth_seq_id%type,
                                     result_set                 OUT SYS_REFCURSOR 
                                   );
--============================================================================================================
PROCEDURE select_chkwise_report(v_check_num             IN VARCHAR2,
                                result_set              OUT SYS_REFCURSOR 
                                );                                     
--===================================================================================================    
PROCEDURE select_invoicewise_report(v_invoice_no       IN VARCHAR2,
                                    v_hosp_empanel_no  IN  TPA_HOSP_INFO.EMPANEL_NUMBER%TYPE,
                                    result_set         OUT SYS_REFCURSOR 
                                    );
--========================================================================================================
PROCEDURE select_batch_recon_summary (
    v_hosp_empanel_no                    IN  TPA_HOSP_INFO.EMPANEL_NUMBER%TYPE,
    v_from_date                          IN  VARCHAR2,
    v_to_date                            IN  VARCHAR2,
    v_batch_no                           IN  clm_batch_upload_details.batch_no%TYPE,
    v_sort_var                           IN  VARCHAR2,
    v_sort_order                         IN  VARCHAR2 ,
    v_start_num                          IN  NUMBER ,
    v_end_num                            IN  NUMBER ,
    result_set                           OUT SYS_REFCURSOR
  );
--=============================================================================================  
PROCEDURE select_batch_invoice_list (
    v_hosp_empanel_no                    IN  TPA_HOSP_INFO.EMPANEL_NUMBER%TYPE,
    v_from_date                          IN  VARCHAR2,
    v_to_date                            IN  VARCHAR2,
    v_batch_no                           IN  clm_batch_upload_details.batch_no%TYPE,
    v_sort_var                           IN  VARCHAR2,
    v_sort_order                         IN  VARCHAR2 ,
    v_start_num                          IN  NUMBER ,
    v_end_num                            IN  NUMBER ,
    result_set                           OUT SYS_REFCURSOR
  );
--==============================================================================
PROCEDURE select_batch_invoice_rpt (
    v_hosp_empanel_no                    IN  TPA_HOSP_INFO.EMPANEL_NUMBER%TYPE,                         
    v_invoice_no                         IN  clm_authorization_details.invoice_number%TYPE,
    result_set                           OUT SYS_REFCURSOR
  );  
--==============================================================================================  
PROCEDURE select_overdue_rpt (
    v_hosp_empanel_no                    IN  TPA_HOSP_INFO.EMPANEL_NUMBER%TYPE,
    v_from_date                          IN  VARCHAR2,
    v_to_date                            IN  VARCHAR2,
    v_invoice_no                         IN  clm_authorization_details.invoice_number%TYPE,
    result_set                           OUT SYS_REFCURSOR,
    v_sort_var                           IN  VARCHAR2 default null,
    v_sort_order                         IN  VARCHAR2 default null,
    v_start_num                          IN  NUMBER default null,
    v_end_num                            IN  NUMBER default null
  );
--==================================================================================================  
PROCEDURE select_batch_recon_smry_rpt (
    v_clm_batch_seq_id                   IN  clm_batch_upload_details.clm_batch_seq_id%TYPE,
    v_flag                               IN  VARCHAR2,
    v_hosp_empanel_no                    IN  TPA_HOSP_INFO.EMPANEL_NUMBER%TYPE,
    result_set                           OUT SYS_REFCURSOR
  );
--=============================================================================================  
PROCEDURE dashboard_account (
    v_hosp_empanel_no                    IN  TPA_HOSP_INFO.EMPANEL_NUMBER%TYPE,
    v_from_date                          IN  VARCHAR2,
    v_to_date                            IN  VARCHAR2,
    result_set                           OUT SYS_REFCURSOR
  );
--======================================================================================================
PROCEDURE Prov_rpt_dwnl_history (
 v_hosp_empanel_no          IN tpa_hosp_info.empanel_number%type,
 v_prov_rpt_downl_name 			IN provider_repot_history.prov_rpt_downl_name%type,
 v_prov_rpt_downl_status 		IN provider_repot_history.prov_rpt_downl_status%type,
 v_prov_rpt_downl_by 		  	IN provider_repot_history.prov_rpt_downl_by%type,
 v_prov_rpt_downl_data 			IN provider_repot_history.prov_rpt_downl_data%type default null,
 v_rows_processed           OUT number
);
--=========================================================================================================================
PROCEDURE select_prov_dwnl_rpt_details ( v_hosp_empanel_no          IN tpa_hosp_info.empanel_number%type,
                                         v_added_by                 IN provider_repot_history.prov_rpt_downl_by%type,
                                         result_set                 OUT SYS_REFCURSOR 
                                       );
--=========================================================================================================================  
FUNCTION get_associated_id(v_flag           VARCHAR2,
                           v_value          VARCHAR2) RETURN VARCHAR2;
--===================================================================================
PROCEDURE select_clinician_list (
    v_clinician_id             IN OUT tpa_hosp_professionals.professional_id%TYPE,
    v_clinician_name           IN OUT tpa_hosp_professionals.contact_name%TYPE,
    v_provider_id              IN OUT tpa_hosp_info.hosp_licenc_numb%TYPE,
    v_hosp_name                IN OUT tpa_hosp_info.hosp_name%TYPE,
    v_sort_var                 IN OUT VARCHAR2 ,
    v_sort_order               IN OUT VARCHAR2,
    v_start_num                IN OUT NUMBER  ,
    v_end_num                  IN OUT NUMBER  ,
    v_added_by                 IN NUMBER,
    v_hosp_seq_id              IN NUMBER,
    v_result_set               OUT SYS_REFCURSOR
  );
--=================================================================================== 
procedure Dashboard_batch_no(
    v_input_list        IN  VARCHAR2,
    v_result_set       OUT SYS_REFCURSOR);
--=========================================================================================
procedure dash_board_batch_no (v_hosp_seq_id tpa_hosp_info.hosp_seq_id%type,
                              v_group_id IN VARCHAR2,
                              v_out_xml     out xmltype);
--======================================================================================
PROCEDURE select_clm_rpt_list(
  --V_HOSP_SEQ_ID                         IN  pat_authorization_details.hosp_seq_id%type,
  v_fromdate                            IN   VARCHAR2 ,
  v_toDate                              IN   VARCHAR2 ,
  v_fromdate1                           IN   VARCHAR2 ,
  v_toDate1                             IN   VARCHAR2 ,
  v_patientName                         IN  clm_authorization_details.mem_name%type,
  v_status                              IN  tpa_general_code.description%type,
  v_invoice_number                      IN  clm_authorization_details.invoice_number%type,
  v_batch_no                        in  varchar2,
  v_memberId                            IN  clm_authorization_details.tpa_enrollment_id%type,
  v_claim_number                        IN  clm_authorization_details.claim_number%type,
  v_benifit_type                      in varchar2,
  v_ref_no                              IN  clm_authorization_details.EVENT_NO%type,
  v_qatar_id                        IN  varchar2,
  v_pay_ref_no                      IN VARCHAR2,
  v_sort_var                            IN  VARCHAR2,
  v_sort_order                          IN  VARCHAR2 ,
  v_start_num                           IN  NUMBER ,
  v_end_num                             IN  NUMBER ,
  V_HOSP_SEQ_ID                         IN  pat_authorization_details.hosp_seq_id%type,
  v_rpt_id                              IN  VARCHAR2,
  --v_added_by                            IN  NUMBER,
  result_set                            OUT SYS_REFCURSOR
  );
  --=====================================================================
  PROCEDURE select_PAT_rpt_list(
  v_pre_auth_number                     IN  pat_authorization_details.pre_auth_number%type ,
  v_fromdate                            IN   VARCHAR2 ,
  v_toDate                              IN   VARCHAR2 ,
  v_patientName                         IN  clm_authorization_details.mem_name%type,
  v_auth_number                         IN  clm_authorization_details.auth_number%type,
  V_DR_NAME               IN VARCHAR2,
  v_memberId                            IN  clm_authorization_details.tpa_enrollment_id%type,
  V_BENIFIT_TYPE              IN VARCHAR2,
  v_status                              IN  tpa_general_code.description%type,
  v_ref_no                              IN  PAT_authorization_details.EVENT_NO%type,
  V_QATAR_ID                            IN VARCHAR2,
  V_PL_REF_NO                              IN VARCHAR2,
  v_sort_var                            IN  VARCHAR2,
  v_sort_order                          IN  VARCHAR2 ,
  v_start_num                           IN  NUMBER ,
  v_end_num                             IN  NUMBER ,
  V_HOSP_SEQ_ID                         IN  pat_authorization_details.hosp_seq_id%type,
  v_rpt_id                              IN  VARCHAR2,
  --v_added_by                            IN  NUMBER,
  result_set                            OUT SYS_REFCURSOR
  );
  --================================================================== 
  PROCEDURE PRVDR_PAT_RPT (
    v_input_list IN  VARCHAR2,
    v_result_set  OUT SYS_REFCURSOR
  );
  --=====================================================================
  PROCEDURE PRVDR_CLM_RPT (
    v_input_list IN  VARCHAR2,
    v_result_set  OUT SYS_REFCURSOR
  );
  --====================================================================

end hospital_pkg;

/

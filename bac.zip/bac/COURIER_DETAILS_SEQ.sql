--------------------------------------------------------
--  DDL for Synonymn COURIER_DETAILS_SEQ
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."COURIER_DETAILS_SEQ" FOR "APP"."COURIER_DETAILS_SEQ";

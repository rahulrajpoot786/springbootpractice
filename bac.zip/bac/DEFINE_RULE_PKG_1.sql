--------------------------------------------------------
--  DDL for Package DEFINE_RULE_PKG
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "VENUBABU"."DEFINE_RULE_PKG" 
IS

  -- Author  : SHARMILAN_C
  -- Created : 3/6/2006 9:17:00 PM
  -- Purpose : chagne owner

  PROCEDURE save_prod_policy_rules(
    v_id                  IN OUT NUMBER,
    v_flag                CHAR, -- 'P' product_policy_seq_id -- 'R' rule_seq_id -- I or C policy_seq_id -- PI(preauth_gener_seq_id) PU preauth(rule_data_seq_id) -- L for claim  -- M for meberer(member_seq_id)
    v_prod_policy_rule    IN  TPA_INS_PROD_POLICY_RULES.prod_policy_rule%TYPE,
    v_valid_from          IN  TPA_INS_PROD_POLICY_RULES.valid_from%TYPE,
    v_added_by            IN  TPA_INS_PROD_POLICY_RULES.added_by%TYPE,
    v_ovride_yn        IN RULE_DATA.OVER_RIDE_YN%TYPE := 'N' --FOR KOC1099 RULE_DATA_REMARKS
  );

  PROCEDURE select_prod_policy_rules (
    v_id           IN  NUMBER,
    v_flag         CHAR, -- 'P' product_policy_seq_id -- 'R' rule_seq_id -- I or C policy_seq_id   -- PI preauth
    result_set     OUT SYS_REFCURSOR
  );

  PROCEDURE prod_policy_rules_list (
    v_prod_policy_seq_id      IN  tpa_ins_prod_policy.prod_policy_seq_id%TYPE,
    result_set                OUT SYS_REFCURSOR
  );

 PROCEDURE select_pa_claims_rules (
    v_id           IN  NUMBER,
    v_flag         CHAR,  -- P preauth
    result_set     OUT SYS_REFCURSOR
  );

  PROCEDURE select_prod_policy_vaidation (
    v_product_seq_id    IN tpa_ins_product.product_seq_id%TYPE,
    v_ins_seq_id        IN tpa_ins_info.ins_seq_id%TYPE,
    v_policy_number     IN tpa_enr_policy.policy_number%TYPE,
    v_scr_policy_type   IN CHAR, -- 'IP',IG,CP,NC
    v_policy_start_date IN DATE, --- by CSP
    v_valid_from_date   OUT DATE, --- by CSP
    v_valid_to_date     OUT DATE, --- by CSP
    result_set          OUT XMLTYPE
  );
  FUNCTION exec_field_fun(v_fn_name VARCHAR2) RETURN VARCHAR;

  PROCEDURE pr_auto_select(  v_merge_xml IN OUT XMLTYPE);

  PROCEDURE pr_rule_xml_validation(V_ID in NUMBER, v_type in varchar2);----koc 1109

  PROCEDURE pr_whitespc_matprm(v_rule_xml IN OUT XMLTYPE); --remove white spaces

 PROCEDURE pr_wsp_shortfall(v_ip_xml IN OUT rule_data.rule_data%TYPE); --koc 1179

END define_rule_pkg;

/

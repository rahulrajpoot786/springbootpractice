--------------------------------------------------------
--  DDL for Synonymn ACT_FOLLOW_PERIOD
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."ACT_FOLLOW_PERIOD" FOR "APP"."ACT_FOLLOW_PERIOD";

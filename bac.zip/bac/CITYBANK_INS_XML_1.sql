--------------------------------------------------------
--  DDL for Synonymn CITYBANK_INS_XML_1
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."CITYBANK_INS_XML_1" FOR "APP"."CITYBANK_INS_XML_1";

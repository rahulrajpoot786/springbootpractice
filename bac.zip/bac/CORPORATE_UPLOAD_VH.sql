--------------------------------------------------------
--  DDL for Synonymn CORPORATE_UPLOAD_VH
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."CORPORATE_UPLOAD_VH" FOR "INTX"."CORPORATE_UPLOAD_VH";

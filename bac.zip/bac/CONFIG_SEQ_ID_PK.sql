--------------------------------------------------------
--  DDL for Synonymn CONFIG_SEQ_ID_PK
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."CONFIG_SEQ_ID_PK" FOR "APP"."CONFIG_SEQ_ID_PK";

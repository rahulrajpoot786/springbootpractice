--------------------------------------------------------
--  DDL for Synonymn IDX_NCCI_PHY_SECOND_COL
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."IDX_NCCI_PHY_SECOND_COL" FOR "APP"."IDX_NCCI_PHY_SECOND_COL";

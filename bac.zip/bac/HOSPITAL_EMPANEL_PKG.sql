--------------------------------------------------------
--  DDL for Package Body HOSPITAL_EMPANEL_PKG
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "VENUBABU"."HOSPITAL_EMPANEL_PKG" 
IS

--=====================================================================================================
  -- for Insert & update details of Hospital information.
--=====================================================================================================
  PROCEDURE pr_hospital_info_save (
    -- Key Fields
    v_hosp_seq_id                      IN OUT tpa_hosp_info.hosp_seq_id%TYPE,
    v_hosp_gnrl_seq_id                 IN OUT tpa_hosp_general_dtl.hosp_gnrl_seq_id%TYPE,
    v_addr_seq_id                      IN OUT tpa_hosp_address.addr_seq_id%TYPE,
    v_discrepancy_status               OUT VARCHAR2,
    -- SECTION: General
    v_empanel_number                   IN tpa_hosp_info.empanel_number%TYPE,
    v_empanel_type_id                  IN tpa_hosp_info.empanel_type_id%TYPE,
    v_tpa_office_seq_id                IN tpa_hosp_info.tpa_office_seq_id%TYPE,
    v_provider_general_type_id         IN tpa_hosp_info.provider_general_type_id%TYPE,
    v_tpa_regist_date                  IN tpa_hosp_info.tpa_regist_date%TYPE,
    ---------------------
    -- SECTION: Document Received Dates
    v_mou_type_id                      IN tpa_hosp_general_dtl.mou_type_id%TYPE,
    v_mou_rcvd_date                    IN tpa_hosp_general_dtl.mou_rcvd_date%TYPE,
    v_credit_period                    IN tpa_hosp_general_dtl.credit_period%TYPE,
    v_interest                         IN tpa_hosp_general_dtl.interest%TYPE,
    v_signed_date                      IN tpa_hosp_general_dtl.signed_date%TYPE,
    v_mou_sent_date                    IN tpa_hosp_general_dtl.mou_sent_date%TYPE,
    v_tariff_rcvd_date                 IN tpa_hosp_general_dtl.tariff_rcvd_date%TYPE,
    v_hosp_info_rcvd_date              IN tpa_hosp_general_dtl.hosp_info_rcvd_date%TYPE,
    v_hosp_verify_form_rcvd_date       IN tpa_hosp_general_dtl.hosp_verify_form_rcvd_date%TYPE,
    v_reg_crt_rcvd_date                IN tpa_hosp_general_dtl.reg_crt_rcvd_date%TYPE,
    ---------------------
    -- SECTION: Hospital Details
    v_hosp_name                        IN tpa_hosp_info.hosp_name%TYPE,
    v_hosp_type_id                     IN tpa_hosp_info.hosp_type_id%TYPE,
    v_hosp_regist_number               IN tpa_hosp_info.hosp_regist_number%TYPE,
    v_regist_authority                 IN tpa_hosp_info.regist_authority%TYPE,
    v_pan_number                       IN tpa_hosp_info.trade_licenc_numb%TYPE,
    v_irda_number                      IN tpa_hosp_info.hosp_licenc_numb%TYPE,
    v_rating                           IN tpa_hosp_info.rating%TYPE,
    v_int_ext_application_yn           IN tpa_hosp_info.int_ext_application_yn%TYPE,
    ---------------------
    -- SECTION: Address details
    v_address_1                        IN tpa_hosp_address.address_1%TYPE,
    v_address_2                        IN tpa_hosp_address.address_2%TYPE,
    v_address_3                        IN tpa_hosp_address.address_3%TYPE,
    v_city_type_id                     IN tpa_hosp_address.city_type_id%TYPE,
    v_state_type_id                    IN tpa_hosp_address.state_type_id%TYPE,
    v_pin_code                         IN tpa_hosp_address.pin_code%TYPE,
    v_country_id                       IN tpa_hosp_address.country_id%TYPE,
    v_std_code                         IN tpa_hosp_info.std_code%TYPE,
    v_off_phone_no_1                   IN tpa_hosp_info.off_phone_no_1%TYPE,
    v_off_phone_no_2                   IN tpa_hosp_info.off_phone_no_2%TYPE,
    v_off_fax_no                       IN tpa_hosp_info.office_fax_no%TYPE,
    v_landmarks                        IN tpa_hosp_address.landmarks%TYPE,
    v_primary_email_id                 IN tpa_hosp_info.primary_email_id%TYPE, --/ED
    v_comm_type_id                     IN tpa_hosp_info.comm_type_id%TYPE,
    v_website                          IN tpa_hosp_info.website%TYPE,
    v_internet_connect_yn              IN tpa_hosp_info.internet_connect_yn%TYPE,
    v_remarks                          IN tpa_hosp_info.remarks%TYPE,
    -- SECTION: Associated/excluded hospitals
    v_prod_policy_seq_id               IN tpa_ins_assoc_prod_hosp.prod_policy_seq_id%TYPE,
    v_status_general_type_id           IN tpa_ins_assoc_prod_hosp.status_general_type_id%TYPE,
    -- SECTION: PR_USER_LOG
    v_log_seq_id                       IN OUT tpa_hosp_log.log_seq_id%TYPE,
    v_mod_reason_type_id               IN tpa_hosp_log.mod_reason_type_id%TYPE,
    v_reference_date                   IN tpa_hosp_log.reference_date%TYPE,
    v_reference_no                     IN tpa_hosp_log.reference_no%TYPE,
    v_remarks_log                      IN tpa_hosp_log.remarks%TYPE,
    v_hosp_regist_date                 IN tpa_hosp_info.hosp_regist_date%TYPE,-- added for issue no. 285
    v_notification_general_type_id     IN tpa_hosp_info.notification_general_type_id%TYPE, --added for KOC840
    v_tan_number                       IN tpa_hosp_info.tan_number%TYPE,
    v_hosp_owner_general_type_id       IN tpa_hosp_info.hosp_owner_general_type_id%TYPE,
    v_tds_subcat_type_id               IN tpa_hosp_info.tds_subcat_type_id%TYPE,
    v_stop_preauth_yn                  IN tpa_hosp_info.stop_preauth_yn%TYPE,
    v_stop_claim_yn                    IN tpa_hosp_info.stop_claim_yn%TYPE,
    v_serv_tax_rgn_number              IN tpa_hosp_info.serv_tax_rgn_number%TYPE,
     -- SECTION: Common arguments:
    v_gipsa_ppnyn                      IN tpa_hosp_info.gipsa_ppnyn%TYPE,
    v_user_id                          IN NUMBER,
    V_CN                               IN VARCHAR2,
    V_GN                               IN VARCHAR2,
    V_SN                               IN VARCHAR2,
    V_BN                               IN VARCHAR2,
    v_provider_type_id                 IN DHA_PROVIDER_TYPE.PROVIDER_TYPE_ID%TYPE,
    v_primary_network                  IN tpa_hosp_info.primary_network%TYPE,
    v_isd_code                         IN tpa_hosp_info.isd_code%TYPE,
    v_clm_submission                   IN tpa_hosp_info.claim_submission_type%TYPE,
    v_prov_ho_yn                       IN tpa_hosp_info.provider_ho_yn%TYPE,
    v_review_yn                        IN tpa_hosp_info.review_yn%type,
    V_WN                               IN VARCHAR2,
    v_hosp_catagory                    IN tpa_hosp_info.hosp_catagory%type, --added by chiranjibi 
    --v_prov_ho_id                       IN tpa_hosp_info.provider_ho_id%TYPE,
    -- SECTION: Hospital Group:
    v_hosp_group_seq_id                IN OUT hosp_group_info.hosp_group_seq_id%TYPE, 
    v_group_name                       IN hosp_group_info.group_name%TYPE, 
    v_contact_person                   IN hosp_group_info.contact_person%TYPE,                                           
    v_contact_no                       IN hosp_group_info.contact_no%TYPE,
    v_email_ID                         IN hosp_group_info.email_id%TYPE,
    v_address                          IN hosp_group_info.address%TYPE,
    v_asso_payer                       IN tpa_hosp_info.asso_payer%TYPE,
    v_trade_licence_name               IN tpa_hosp_info.trade_licence_name%TYPE,
    v_bio_metric_ena_dis               IN VARCHAR2,
    v_rows_processed                   OUT NUMBER,
    ---Adding the Network types 
    v_network_type                     IN VARCHAR2,  --concatenate values example",|1|GN|tttttt|10|,|1|GN|kkkkkkk|30|,|1|BN|eee|20|,"
    v_prov_limit_amt                   IN tpa_hosp_info.amount_limit%TYPE,
    V_OPTS_LIMIT                       IN tpa_hosp_info.OPTS_LIMIT%TYPE,                         
    V_OPTC_LIMIT                       IN tpa_hosp_info.OPTC_LIMIT%TYPE,
    V_DNTL_LIMIT                       IN tpa_hosp_info.DNTL_LIMIT%TYPE,
    V_OMTI_LIMIT                       IN tpa_hosp_info.OMTI_LIMIT%TYPE,
    V_CONS_FOLLOWUP_PERIOD             IN tpa_hosp_info.Cons_Followup_Period%TYPE,  --- added in Free Follwup Period Cr
    v_payment_dur                      IN NUMBER,
    v_clm_sub_days                     IN tpa_hosp_info.clm_sub_days%type,
    v_clm_rsub_days                    IN tpa_hosp_info.clm_rsub_days%type,
    v_clm_sub_flag                     IN tpa_hosp_info.clm_sub_flag%type,
    v_opts_pat_limit                   IN tpa_hosp_info.opts_pat_limit%type,
    v_stop_clm_date                    IN tpa_hosp_info.stop_clm_date%TYPE,
    v_stop_pat_date                    IN tpa_hosp_info.stop_preauth_date%TYPE
)
  IS 
     
    -- for tpa_ins_assoc_hosp_prod
    v_concat_hosp_seq_id VARCHAR2(100);       --concatenate generated hosp_seq_id;
    -- for empanel status table
    v_empanel_seq_id   tpa_hosp_empanel_status.empanel_seq_id%TYPE;
    -- log screen variables
    v_screen_name              VARCHAR2(100):='Add General Detail Screen ';
    v_column_name              VARCHAR2(100):=' Hospital Name ';
    v_system_gen_yn            tpa_hosp_log.system_gen_yn%TYPE :='Y';
    v_log_type_id              tpa_hosp_log.log_type_id%TYPE := 'HNC';  --hospital name changes type id
    v_old_hosp_name            tpa_hosp_info.hosp_name%TYPE;
    v_remarks_concat           VARCHAR2(1000);
    v_hosp_name_upper          tpa_hosp_info.hosp_name%TYPE:=upper(v_hosp_name);
    v_empanel_status_type_id   tpa_hosp_empanel_status.empanel_status_type_id%TYPE;
    v_tpa_ref_number           tpa_hosp_info.tpa_ref_number%TYPE;
    v_old_serv_tax_rgn_number  tpa_hosp_info.serv_tax_rgn_number%TYPE;
    v_st_regnnbr_column_name   VARCHAR2(100):='Service Tax Regn. No. ';
    v_st_regnnbr_log_type_id   tpa_hosp_log.log_type_id%TYPE := 'GEN';  --General changes type id
    v_cnt                      number(10);
    
    cursor asso_cur (v_ins_comp_code_number       app.tpa_ins_info.ins_comp_code_number%type)is
    select * from app.tpa_ins_info ii
    where ii.ins_comp_code_number = v_ins_comp_code_number;
    
    ---added for Network type check
    cursor hosp_net_check is 
    select count(1) from app.tpa_hosp_network thn where thn.hosp_seq_id=v_hosp_seq_id;
    cursor hosp_new_newt_check(v_network_type app.tpa_hosp_network.network_type%type) is 
    select count(1) from  app.tpa_hosp_network j  where j.hosp_seq_id=v_hosp_seq_id 
    and j.network_type=v_network_type;
    
    cursor prev_stop_cur is
    select a.stop_claim_yn,a.stop_clm_date,a.stop_preauth_yn,a.stop_preauth_date from app.tpa_hosp_info a 
                                                                                 where a.hosp_seq_id = v_hosp_seq_id;
    
    ------ added for consulation followup period cr
    cursor hosp_follw_up_cur is
    select thi.Cons_Followup_Period from app.tpa_hosp_info thi where thi.hosp_seq_id = v_hosp_seq_id;
    v_old_follwup tpa_hosp_info.cons_followup_period%type; 
     
    
    asso_rec  asso_cur%rowtype;
    TYPE str_table_type IS TABLE OF VARCHAR2(250) INDEX BY BINARY_INTEGER; 
    payer_list     ttk_util_pkg.str_table_type;  
    v_ins_list                 varchar2(32767):= v_asso_payer||'|';
    v_comp_code                varchar2(2000);
    v_chk_yn                   varchar2(2000);
    v_ins_seq_id               number;
    str_tab_all   Ttk_Util_Pkg.str_table_type;
    str_tab_sing  ttk_util_pkg.str_table_type;
    v_network_type_cnt number;
    v_hosp_new_newt_cnt number;
    v_authority_code           VARCHAR2(4);
    v_prov_id                  number;
    v_licence                  VARCHAR2(250);
    stop_rec prev_stop_cur%rowtype;
  BEGIN
   IF v_regist_authority= 'DHA' THEN  ------added for autority validation
    IF v_irda_number is not null then 
     SELECT COUNT(1) INTO v_cnt from app.dha_providers_master lm where lm.provider_id=v_irda_number;
     IF v_cnt=0 THEN
     raise_application_error(-20996,'Provider is not registered with DHA .');
     END IF;
     ELSE
      raise_application_error(-20996,'Provider is not registered with DHA .');
    END IF;
    
   ELSIF v_regist_authority = 'HAAD' THEN
      IF v_irda_number IS NOT NULL THEN
        SELECT COUNT(1) INTO v_cnt
        from app.dha_providers_master lm
        where lm.provider_id = v_irda_number
          AND lm.health_authority IN ('DHA', 'MOH');
        IF v_cnt >= 1 THEN
            raise_application_error(-20996,'Provider is not registered with HAAD .');
        END IF;
      END IF;
      
   ELSIF v_regist_authority = 'MOH' THEN
      IF v_irda_number IS NOT NULL THEN
        SELECT COUNT(1) INTO v_cnt
        from app.dha_providers_master lm
        where lm.provider_id = v_irda_number
          AND lm.health_authority IN ('DHA', 'HAAD');
        IF v_cnt >= 1 THEN
            raise_application_error(-20996,'Provider is not registered with HAAD .');
        END IF;
      END IF;
   END IF;
   
  IF ( v_hosp_group_seq_id = 0 and v_hosp_catagory = 'GRP') THEN
    -- Provider Licence ID Validation
    IF v_irda_number IS NOT NULL THEN
      select count(1) into v_cnt from tpa_hosp_info t where t.hosp_licenc_numb = TRIM(v_irda_number);
      
      IF v_cnt > 0 THEN
        raise_application_error(-20432,'Provider Licence ID already exist in database .');
      END IF;
    END IF;
  
      INSERT INTO app.Hosp_group_info(hosp_group_seq_id,group_name,contact_person,contact_no,email_id,address,added_by,added_date)
      VALUES (app.hosp_group_seq.nextval,v_group_name,v_contact_person,v_contact_no,v_email_id,v_address,v_user_id,SYSDATE)
      RETURNING hosp_group_seq_id INTO v_hosp_group_seq_id;
    END IF;
    
    open hosp_follw_up_cur;
    fetch hosp_follw_up_cur into v_old_follwup;
    close hosp_follw_up_cur;
    
    ---- for  stop clm log capture
     OPEN prev_stop_cur;
     FETCH prev_stop_cur INTO stop_rec;
     CLOSE Prev_stop_cur;
    
    IF ( v_hosp_seq_id = 0 ) THEN    -- add details to TPA_HOSP_INFO,TPA_HOSP_EMPANEL_STATUS,TPA_HOSP_DISCREPANCY,TPA_HOSP_GENERAL_DTL,TPA_INS_ASSOC_PROD_HOSP,ADDRESS_PKG.PR_HOSPITAL_ADDRESS_SAVE
      IF v_irda_number IS NOT NULL THEN
         select count(1) into v_cnt from tpa_hosp_info t where t.hosp_licenc_numb = TRIM(v_irda_number);
      
         IF v_cnt > 0 THEN
           raise_application_error(-20432,'Provider Licence ID already exist in database .');
         END IF;
      END IF;
      
      INSERT INTO tpa_hosp_info(hosp_seq_id,tpa_office_seq_id,hosp_type_id,hosp_name,
                  tpa_ref_number,provider_general_type_id,tpa_regist_date,empanel_number,
                  empanel_type_id,hosp_regist_number,regist_authority,primary_email_id, --/ED
                  website,internet_connect_yn,hosp_licenc_numb,trade_licenc_numb,std_code,off_phone_no_1,
                  off_phone_no_2,office_fax_no,rating,comm_type_id,int_ext_application_yn,
                  remarks,hosp_regist_date,notification_general_type_id,
                  tan_number,hosp_owner_general_type_id,tds_subcat_type_id,tds_process_yn,stop_preauth_yn,stop_claim_yn,serv_tax_rgn_number,
                  added_by,added_date,gipsa_ppnyn,cn_yn,gn_yn,sn_yn,bn_yn,provider_type_id,primary_network,isd_code,claim_submission_type,provider_ho_yn/*,provider_ho_id*/,review_yn,wn_yn,hosp_catagory,asso_payer,trade_licence_name,amount_limit,biometric_yn,
                  opts_limit,optc_limit,dntl_limit,omti_limit,cons_followup_period,payment_dur_agr,
                  clm_sub_days,clm_rsub_days,clm_sub_flag,opts_pat_limit,stop_clm_date,stop_preauth_date)
           VALUES (tpa_hosp_sequence.nextval,v_tpa_office_seq_id,v_hosp_type_id,v_hosp_name_upper,
                  to_char(SYSDATE,'ddmmyy-hh24miss'),v_provider_general_type_id,trunc(v_tpa_regist_date),
                  v_empanel_number,v_empanel_type_id,v_hosp_regist_number,v_regist_authority, ttk_util_pkg.fn_encrypt(v_primary_email_id),--/ED
                  v_website,v_internet_connect_yn,v_irda_number,v_pan_number,v_std_code,v_off_phone_no_1,
                  v_off_phone_no_2,v_off_fax_no,v_rating,v_comm_type_id,v_int_ext_application_yn,
                  v_remarks,v_hosp_regist_date,v_notification_general_type_id,
                  v_tan_number,v_hosp_owner_general_type_id,NVL(v_tds_subcat_type_id,'RE1'),
                  CASE WHEN v_pan_number IS NOT NULL THEN 'Y' ELSE 'N' END,v_stop_preauth_yn,v_stop_claim_yn,v_serv_tax_rgn_number,v_user_id,SYSDATE,v_gipsa_ppnyn,v_cn,V_GN,V_SN,V_BN,v_provider_type_id,v_primary_network,v_isd_code,v_clm_submission,v_prov_ho_yn,/*v_prov_ho_id,*/
                   v_review_yn,V_wN,v_hosp_catagory,v_asso_payer,v_trade_licence_name, v_prov_limit_amt,v_bio_metric_ena_dis,
                   V_OPTS_LIMIT,V_OPTC_LIMIT,V_DNTL_LIMIT,V_OMTI_LIMIT,V_CONS_FOLLOWUP_PERIOD,v_payment_dur,
                   v_clm_sub_days,v_clm_rsub_days,v_clm_sub_flag,v_opts_pat_limit,v_stop_clm_date,v_stop_pat_date)
        RETURNING hosp_seq_id INTO v_hosp_seq_id;
        
        ---Inserting the network types
      
        str_tab_all := ttk_util_pkg.parse_string( v_network_type );
        for rec in str_tab_all.first..str_tab_all.last
        loop
          str_tab_sing := ttk_util_pkg.parse_str( str_tab_all(rec) ); 
        INSERT INTO app.tpa_hosp_network (HOSP_NETWORK_SEQ_ID,
                                          HOSP_SEQ_ID,
                                          NETWORK_TYPE,
                                          NETWORK_YN,
                                          ADDED_BY,
                                          ADDED_DATE
                                          )  
                  values (app.tpa_hosp_network_seq.nextval,
                          v_HOSP_SEQ_ID,
                          str_tab_sing(1),
                          str_tab_sing(2),
                          v_user_id,
                          sysdate
                        );
        
        end loop;
        ---end of the insearting the network types;
         payer_list := ttk_util_pkg.parse_strng(v_ins_list);
         for i in payer_list.first..payer_list.last loop
           
          v_comp_code := substr(payer_list(i),2,instr(payer_list(i),'|',1,2)-2);
          v_chk_yn := substr(payer_list(i),instr(payer_list(i),'|',1,2)+1,1);
          v_ins_seq_id := FN_PAYEER_ID(v_comp_code);
        INSERT INTO prov_payer_association (asso_seq_id,ins_seq_id,payer_asso_YN,ins_comp_code,hosp_seq_id)
           VALUES (asso_seq.nextval,v_ins_seq_id,v_chk_yn,v_comp_code,v_hosp_seq_id);
       END LOOP;
       
      INSERT INTO tpa_hosp_empanel_status (empanel_seq_id,hosp_seq_id,empanel_status_type_id,empanel_rson_type_id,
                  from_date,to_date,notified_to_tpa_acc,date_of_notification,remarks,active_yn,added_by,added_date)
           VALUES (tpa_hosp_empanel_status_seq.NEXTVAL,v_hosp_seq_id,'INP','FOL',
                  NULL, NULL, NULL, NULL, v_remarks,'Y', v_user_id, SYSDATE)
        RETURNING empanel_seq_id INTO v_empanel_seq_id;

      INSERT INTO tpa_hosp_bank_guarantee (bank_guant_seq_id,empanel_seq_id,added_by,added_date)
           VALUES (tpa_hosp_bank_guarantee_seq.NEXTVAL,v_empanel_seq_id,v_user_id,SYSDATE);

      INSERT INTO tpa_hosp_general_dtl (hosp_gnrl_seq_id,empanel_seq_id,hosp_seq_id,mou_type_id,
                  mou_rcvd_date,tariff_rcvd_date,hosp_info_rcvd_date,credit_period,
                  interest,signed_date,mou_sent_date,hosp_verify_form_rcvd_date,reg_crt_rcvd_date,
                  added_by,added_date)
           VALUES (tpa_hosp_general_dtl_seq.NEXTVAL ,v_empanel_seq_id,v_hosp_seq_id,v_mou_type_id,
                  trunc(v_mou_rcvd_date),trunc(v_tariff_rcvd_date),trunc(v_hosp_info_rcvd_date),
                  v_credit_period, v_interest,trunc(v_signed_date),trunc(v_mou_sent_date),
                  trunc(v_hosp_verify_form_rcvd_date),trunc(v_reg_crt_rcvd_date),v_user_id,SYSDATE)
        RETURNING hosp_gnrl_seq_id INTO v_hosp_gnrl_seq_id;

      INSERT INTO tpa_hosp_discrepancy (hosp_seq_id,disc_check_done_yn,disc_present_yn,
                  disc_action_taken,added_by,added_date)
           VALUES (v_hosp_seq_id,'N' ,NULL,NULL,v_user_id,SYSDATE);

      INSERT INTO tpa_ins_assoc_prod_hosp (prod_hosp_seq_id,hosp_seq_id,general_type_id,added_by,added_date)
           SELECT tpa_ins_assoc_prod_hosp_seq.NEXTVAL,v_hosp_seq_id,general_type_id,v_user_id,SYSDATE
             FROM tpa_general_code
            WHERE ( header_type = 'NHCP' ) ;

      address_pkg.pr_hospital_address_save (v_addr_seq_id,v_hosp_seq_id,v_address_1,v_address_2,
                                            v_address_3,v_city_type_id,v_state_type_id,v_pin_code,
                                            v_country_id,v_landmarks,v_user_id,v_rows_processed);

      -- hospital is associated to prod_policy then call pr_product_associate_save proc
      IF ( v_prod_policy_seq_id IS NOT NULL ) THEN
         v_concat_hosp_seq_id := '|'||v_hosp_seq_id||'|';
         product_admin_pkg.pr_product_associate_save ( v_concat_hosp_seq_id, -- concatenated hospital sequence ids.
                                                       v_prod_policy_seq_id,
                                                       v_status_general_type_id,
                                                       v_user_id,
                                                       v_rows_processed );
      END IF;

    ELSE              -- add log details for ttk_util_pkg.pr_user_log and  update tables TPA_HOSP_INFO,TPA_HOSP_GENERAL_DTL,TPA_HOSP_ADDRESS,TPA_HOSP_EMPANEL_STATUS
      --for log
      SELECT empanel_seq_id, empanel_status_type_id
        INTO v_empanel_seq_id, v_empanel_status_type_id
        FROM tpa_hosp_empanel_status
       WHERE hosp_seq_id = v_hosp_seq_id AND active_yn = 'Y';

      IF ( v_mod_reason_type_id IS NOT NULL ) OR ( v_remarks_log IS NOT NULL ) THEN
        --do concat the details for log
        SELECT hosp_name , tpa_ref_number INTO v_old_hosp_name , v_tpa_ref_number
           FROM tpa_hosp_info WHERE hosp_seq_id = v_hosp_seq_id;

        IF ( v_old_hosp_name != v_hosp_name_upper ) THEN
          ttk_util_pkg.pr_log_concat (v_column_name,v_old_hosp_name,v_hosp_name_upper,v_remarks_concat);
          /*IF v_empanel_status_type_id = 'EMP' THEN
            dms_interface_pkg.hospital_xml_gen( v_hosp_seq_id, v_hosp_name, v_tpa_ref_number, v_empanel_number ,'U');
          END IF;*/
        END IF;

        v_remarks_concat := 'Reference Date   : '||to_char(v_reference_date,'dd/mm/yyyy')||chr(10)||
                            ' For :'||v_screen_name||chr(10)||v_remarks_concat||' Remarks  : '|| v_remarks_log;

        ttk_util_pkg.pr_user_log ( v_log_seq_id ,v_hosp_seq_id,
                                   V_System_Gen_Yn,V_Log_Type_id ,
                                   v_mod_reason_type_id,nvl(v_reference_date,SYSDATE),v_reference_no,
                                   v_remarks_concat,v_user_id,v_rows_processed );
      END IF;
      ----------------------------------------------------------------
      --get empanel_seq_id for given hosp_seq_id

      SELECT A.serv_tax_rgn_number INTO v_old_serv_tax_rgn_number
      FROM tpa_hosp_info A WHERE A.hosp_seq_id = v_hosp_seq_id;

      IF nvl(trim(v_old_serv_tax_rgn_number),'a') = nvl(trim(v_serv_tax_rgn_number),'a') THEN
         --v_old_serv_tax_rgn_number := v_serv_tax_rgn_number;
         NULL;
      ELSE
       ttk_util_pkg.pr_log_concat (v_st_regnnbr_column_name,v_old_serv_tax_rgn_number,v_serv_tax_rgn_number,v_remarks_concat);

         v_remarks_concat := 'Reference Date   : '||to_char(SYSDATE,'dd/mm/yyyy')||chr(10)||
                            ' For :'||v_screen_name||chr(10)||v_remarks_concat;

        ttk_util_pkg.pr_user_log ( v_log_seq_id ,v_hosp_seq_id,
                                   V_System_Gen_Yn,v_st_regnnbr_log_type_id ,
                                   NULL,SYSDATE,NULL,
                                   v_remarks_concat,v_user_id,v_rows_processed );
      END IF;
      
      IF v_irda_number IS NOT NULL THEN
         
         select count(1) into v_cnt 
         from tpa_hosp_info t 
         where t.hosp_seq_id != nvl(v_hosp_seq_id, 0)
         and t.hosp_licenc_numb = trim(v_irda_number);
      
         IF v_cnt > 0 THEN
           select t.hosp_licenc_numb into v_licence from tpa_hosp_info t where t.hosp_seq_id = v_hosp_seq_id;
           raise_application_error(-20432,'Provider Licence ID already exist in database .');
         END IF;
      END IF;
      
      UPDATE tpa_hosp_info
         SET tpa_office_seq_id               = v_tpa_office_seq_id,
             hosp_type_id                    = v_hosp_type_id,
             hosp_name                       = v_hosp_name_upper,
             provider_general_type_id        = v_provider_general_type_id,
             tpa_regist_date                 = trunc(v_tpa_regist_date),
             empanel_type_id                 = v_empanel_type_id,
             hosp_regist_number              = v_hosp_regist_number,
             regist_authority                = v_regist_authority,
             primary_email_id                = ttk_util_pkg.fn_encrypt(v_primary_email_id), --/ED
             website                         = v_website,
             internet_connect_yn             = v_internet_connect_yn,
             hosp_licenc_numb                = v_irda_number,
             trade_licenc_numb               = v_pan_number,
             std_code                        = v_std_code,
             off_phone_no_1                  = v_off_phone_no_1,
             off_phone_no_2                  = v_off_phone_no_2,
             office_fax_no                   = v_off_fax_no,
             rating                          = v_rating,
             comm_type_id                    = v_comm_type_id,
             int_ext_application_yn          = v_int_ext_application_yn,
             remarks                         = v_remarks,
             hosp_regist_date                = v_hosp_regist_date,
             notification_general_type_id    = v_notification_general_type_id,
             tan_number                      = v_tan_number,
             hosp_owner_general_type_id      = v_hosp_owner_general_type_id,
             tds_subcat_type_id              = NVL(v_tds_subcat_type_id,'RE1'),
             tds_process_yn                  = CASE WHEN v_pan_number IS NOT NULL THEN 'Y' ELSE 'N' END,
             stop_preauth_yn                 = v_stop_preauth_yn,
             stop_claim_yn                   = v_stop_claim_yn ,
             serv_tax_rgn_number             = v_serv_tax_rgn_number,
             updated_by                      = v_user_id,
             updated_date                    = SYSDATE,
             gipsa_ppnyn                     = v_gipsa_ppnyn,
             CN_YN                           = V_CN,
             GN_YN                           = V_GN,
             SN_YN                           = V_SN,
             BN_YN                           = V_BN,
             PROVIDER_TYPE_ID                = v_provider_type_id,
             primary_network                 = v_primary_network,
             ISD_CODE                        = v_isd_code,
             CLAIM_SUBMISSION_TYPE           = v_clm_submission,
             PROVIDER_HO_YN                  = v_prov_ho_yn,
             --PROVIDER_HO_ID                  = v_prov_ho_id,
             REVIEW_YN                       = v_review_yn,
             WN_YN                           = V_WN,
             hosp_catagory                   = v_hosp_catagory, 
             asso_payer                      = v_asso_payer, 
             trade_licence_name              = v_trade_licence_name,
             amount_limit                    = v_prov_limit_amt,
             biometric_yn                    = v_bio_metric_ena_dis,
             opts_limit                      = V_OPTS_LIMIT,
             optc_limit                      = V_OPTC_LIMIT,
             dntl_limit                      = V_DNTL_LIMIT,
             omti_limit                      = V_OMTI_LIMIT,
             Cons_Followup_Period            = V_CONS_FOLLOWUP_PERIOD,
             payment_dur_agr                 =v_payment_dur,
             clm_sub_days                    = v_clm_sub_days,
             clm_rsub_days                   = v_clm_rsub_days,
             clm_sub_flag                    = v_clm_sub_flag,
             opts_pat_limit                  = v_opts_pat_limit,
             stop_clm_date                   = v_stop_clm_date,
             stop_preauth_date               = v_stop_pat_date
       WHERE hosp_seq_id = v_hosp_seq_id;
       
       ------- follwup period log capture
       if nvl(v_old_follwup,V_CONS_FOLLOWUP_PERIOD + 1)<> nvl(V_CONS_FOLLOWUP_PERIOD,v_old_follwup+1) then
            insert into  APP.hosp_follow_up_log (follwup_seq_id,hosp_seq_id,old_follow_up,new_follow_up,updated_by,updated_date)
                         values  (APP.hosp_follow_seq.NEXTVAL,v_hosp_seq_id,v_old_follwup,V_CONS_FOLLOWUP_PERIOD,v_user_id,sysdate);
       end if;
         ---Inserting the network types
       open hosp_net_check;
       fetch hosp_net_check into v_network_type_cnt;
       close hosp_net_check;
       if v_network_type is not null then 
       str_tab_all := ttk_util_pkg.parse_string( v_network_type );
       for rec in str_tab_all.first..str_tab_all.last
        loop
          --str_tab_sing:=str_tab_all();
          str_tab_sing := ttk_util_pkg.parse_str( str_tab_all(rec) ); 
           
          if v_network_type_cnt=0 then 
            
             INSERT INTO app.tpa_hosp_network (HOSP_NETWORK_SEQ_ID,
                                          HOSP_SEQ_ID,
                                          NETWORK_TYPE,
                                          NETWORK_YN,
                                          ADDED_BY,
                                          ADDED_DATE
                                          )  
                  values (app.tpa_hosp_network_seq.nextval,
                          v_HOSP_SEQ_ID,
                          str_tab_sing(1),
                          str_tab_sing(2),
                          v_user_id,
                          sysdate
                          );
          
          else
            
          
       open hosp_new_newt_check(str_tab_sing(1));
       fetch hosp_new_newt_check into v_hosp_new_newt_cnt;
       close hosp_new_newt_check;
        if  v_hosp_new_newt_cnt =0 then 
         
         INSERT INTO app.tpa_hosp_network (HOSP_NETWORK_SEQ_ID,
                                          HOSP_SEQ_ID,
                                          NETWORK_TYPE,
                                          NETWORK_YN,
                                          ADDED_BY,
                                          ADDED_DATE
                                          )  
                  values (app.tpa_hosp_network_seq.nextval,
                          v_HOSP_SEQ_ID,
                          str_tab_sing(1),
                          str_tab_sing(2),
                          v_user_id,
                          sysdate
                          );
          
          
          else  
             update app.tpa_hosp_network 
                set NETWORK_YN   =   str_tab_sing(2),
                    updated_by   =   v_user_id,
                    updated_date =   sysdate
              WHERE hosp_seq_id = v_hosp_seq_id and NETWORK_TYPE=str_tab_sing(1);
          end if;
          end if ;         
       end loop;
       end if;--end of the updating the network types

      UPDATE tpa_hosp_general_dtl
         SET hosp_seq_id                     = v_hosp_seq_id,
             mou_type_id                     = v_mou_type_id,
             mou_rcvd_date                   = trunc(v_mou_rcvd_date),
             tariff_rcvd_date                = trunc(v_tariff_rcvd_date),
             hosp_info_rcvd_date             = trunc(v_hosp_info_rcvd_date),
             credit_period                   = v_credit_period,
             interest                        = v_interest,
             signed_date                     = trunc(v_signed_date),
             mou_sent_date                   = trunc(v_mou_sent_date),
             hosp_verify_form_rcvd_date      = trunc(v_hosp_verify_form_rcvd_date),
             reg_crt_rcvd_date               = trunc(v_reg_crt_rcvd_date),
             updated_by                      = v_user_id,
             updated_date                    = SYSDATE
       WHERE hosp_gnrl_seq_id = v_hosp_gnrl_seq_id
         AND hosp_seq_id      = v_hosp_seq_id
         AND empanel_seq_id   = v_empanel_seq_id;

      UPDATE tpa_hosp_address
         SET address_1                       = v_address_1,
             address_2                       = v_address_2,
             address_3                       = v_address_3,
             city_type_id                    = v_city_type_id,
             state_type_id                   = v_state_type_id,
             country_id                      = v_country_id,
             pin_code                        = v_pin_code,
             landmarks                       = v_landmarks,
             updated_by                      = v_user_id,
             updated_date                    = SYSDATE
       WHERE addr_seq_id = v_addr_seq_id
         AND hosp_seq_id = v_hosp_seq_id ;
    IF v_hosp_catagory = 'GRP' then
       UPDATE tpa_hosp_info
       set hosp_group_seq_id   = v_hosp_group_seq_id --added by chiranjibi
       WHERE hosp_seq_id = v_hosp_seq_id; 
    END IF;
      
    /*   UPDATE prov_payer_association 
        SET   ins_seq_id       = null,
              ins_comp_code    = null
       WHERE  hosp_seq_id      = v_hosp_seq_id ; */
       
       payer_list := ttk_util_pkg.parse_strng(v_ins_list);
         for i in payer_list.first..payer_list.last loop
           
          v_comp_code := substr(payer_list(i),2,instr(payer_list(i),'|',1,2)-2);
          v_chk_yn := substr(payer_list(i),instr(payer_list(i),'|',1,2)+1,1);
          v_ins_seq_id := FN_PAYEER_ID(v_comp_code);
       UPDATE prov_payer_association 
       SET    payer_asso_YN      = v_chk_yn,
              ins_comp_code      = v_comp_code
       WHERE  ins_seq_id         = v_ins_seq_id and hosp_seq_id = v_hosp_seq_id;
       END LOOP;
    
      ----- for stop pat and clm log
       IF nvl(stop_rec.stop_claim_yn,v_stop_claim_yn||'a') <> nvl(v_stop_claim_yn,stop_rec.stop_claim_yn||'a') OR nvl(trunc(v_stop_clm_date),trunc(stop_rec.stop_clm_date)+1)<>nvl(trunc(stop_rec.stop_clm_date),trunc(v_stop_clm_date+1)) OR
          nvl(stop_rec.stop_preauth_yn,v_stop_preauth_yn||'a') <> nvl(v_stop_preauth_yn,stop_rec.stop_preauth_yn||'a') OR nvl(trunc(v_stop_pat_date),trunc(stop_rec.stop_preauth_date)+1)<>nvl(trunc(stop_rec.stop_preauth_date),trunc(v_stop_pat_date+1)) THEN

          INSERT INTO app.stop_pre_clm_log (
                  stop_pat_clm_seq_id,
                  hosp_seq_id,
                  old_stop_clm_yn,
                  old_stop_clm_date,
                  stop_clm_yn,
                  stop_clm_date,
                  old_stop_pat_yn,
                  old_stop_pat_date,
                  stop_pat_yn,
                  stop_pat_date,
                  screen_mode,
                  updated_by,
                  updated_date)
               VALUES  (
                  stop_pat_clm_seq.nextval,
                  v_hosp_seq_id,
                  stop_rec.stop_claim_yn,
                  stop_rec.stop_clm_date,
                  v_stop_claim_yn, 
                  v_stop_clm_date,
                  stop_rec.stop_preauth_yn,
                  stop_rec.stop_preauth_date,
                  v_stop_preauth_yn,
                  v_stop_pat_date,
                  'HOS',
                  v_user_id,
                  SYSDATE) ;
                      
  END IF;

  END IF;

    v_rows_processed := SQL%ROWCOUNT;
    COMMIT;
    pr_discrepancy_status(v_hosp_seq_id, v_discrepancy_status);

  END pr_hospital_info_save;

--=====================================================================================================
  --  to delete the hospitals.
  -- The hospital IDs of the hospitals to be deleted has to be sent concatenated with "|".
  -- Deletion of hospital is allowed only if there are no child records. In real world, there is no option for deletion of hospital.
--=====================================================================================================
  PROCEDURE pr_hospital_info_delete (
    v_hosp_seq_ids                     IN  VARCHAR2 , -- Concatenated Hospital Sequence IDs.
    v_rows_processed                   OUT  NUMBER
  )
  IS
    str_tab                 ttk_util_pkg.str_table_type;
  BEGIN
    -- IF Hospital is Empaneled, it should not be allowed to delete .
    -- Validation has to be done first.  Not done yet.
    str_tab := ttk_util_pkg.parse_str ( v_hosp_seq_ids );

    FOR  v_hosp_seq_id  IN str_tab.First..str_tab.Last
    LOOP
/*    DELETE FROM TPA_HOSP_ASSOC_PLAN WHERE HOSP_SEQ_ID = str_tab(V_Hosp_Seq_Id) ;

    DELETE FROM TPA_HOSP_ADDRESS WHERE HOSP_SEQ_ID = str_tab(V_Hosp_Seq_Id) ;

    DELETE FROM TPA_HOSP_ADDRESS
        WHERE HOSP_BANK_SEQ_ID IN
        ( SELECT HOSP_Bank_Seq_Id from tpa_hosp_account_details
          where hosp_seq_id=  (str_tab(V_Hosp_Seq_Id)) );

    DELETE FROM TPA_HOSP_ADDRESS
        WHERE hosp_gnrl_seq_id IN
        ( SELECT hosp_gnrl_seq_id from tpa_hosp_general_dtl
          where hosp_seq_id=  (str_tab(V_Hosp_Seq_Id)) );

    DELETE FROM TPA_HOSP_COURIER WHERE HOSP_SEQ_ID = str_tab(V_Hosp_Seq_Id) ;

    DELETE FROM TPA_HOSP_GRADING WHERE HOSP_SEQ_ID = str_tab(V_Hosp_Seq_Id) ;

    DELETE FROM TPA_HOSP_INFRASTR_INFO WHERE HOSP_SEQ_ID = str_tab(V_Hosp_Seq_Id) ;

    DELETE FROM TPA_HOSP_LOG WHERE HOSP_SEQ_ID = str_tab(V_Hosp_Seq_Id) ;

        DELETE FROM TPA_HOSP_DISCREPANCY_LIST WHERE HOSP_SEQ_ID = str_tab(V_Hosp_Seq_Id) ;

    DELETE FROM TPA_HOSP_DISCREPANCY WHERE HOSP_SEQ_ID = str_tab(V_Hosp_Seq_Id) ;

    DELETE FROM TPA_HOSP_CONTACTS WHERE HOSP_SEQ_ID = str_tab(V_Hosp_Seq_Id) ;

    DELETE FROM TPA_HOSP_VALIDATION WHERE HOSP_SEQ_ID = str_tab(V_Hosp_Seq_Id) ;

    DELETE FROM TPA_HOSP_FEEDBACK_details
        WHERE FEEDBACK_SEQ_ID IN
        ( SELECT FEEDBACK_SEQ_ID FROM TPA_HOSP_FEEDBACK WHERE HOSP_SEQ_ID = str_tab(V_Hosp_Seq_Id) );

    DELETE FROM TPA_HOSP_FEEDBACK WHERE HOSP_SEQ_ID = str_tab(V_Hosp_Seq_Id) ;

    DELETE FROM TPA_HOSP_ACCOUNT_DETAILS WHERE HOSP_SEQ_ID = str_tab(V_Hosp_Seq_Id) ;

    DELETE FROM TPA_HOSP_GENERAL_DTL WHERE HOSP_SEQ_ID = str_tab(V_Hosp_Seq_Id) ;

    DELETE FROM TPA_HOSP_EMPANEL_STATUS WHERE HOSP_SEQ_ID = str_tab(V_Hosp_Seq_Id) ;

--    DELETE FROM TPA_HOSP_PACKAGE_COST WHERE HOSP_SEQ_ID = str_tab(V_Hosp_Seq_Id) ;

    DELETE FROM TPA_HOSP_MEDICAL_DETAILS WHERE HOSP_SEQ_ID = str_tab(V_Hosp_Seq_Id) ;
*/
    DELETE FROM tpa_hosp_info WHERE hosp_seq_id = str_tab(v_hosp_seq_id) ;

    END LOOP;
      v_rows_processed  := sql%rowcount;
    COMMIT;
  END pr_hospital_info_delete;

--=====================================================================================================
  --  to update the DISCREPANCY information.
--=====================================================================================================
  PROCEDURE pr_discrepancy_info_save (
    v_hosp_seq_id                      IN tpa_hosp_discrepancy.hosp_seq_id%TYPE,
    v_action                           IN VARCHAR2,
    v_user_id                          IN NUMBER,
    v_rows_processed                   OUT  NUMBER
  )
  IS
  BEGIN
    UPDATE tpa_hosp_discrepancy
       SET disc_action_taken = v_action,
           updated_by        = v_user_id ,
           updated_date      = SYSDATE
     WHERE hosp_seq_id = v_hosp_seq_id;

      v_rows_processed := sql%rowcount;
    COMMIT;
  END pr_discrepancy_info_save;

--=====================================================================================================
  --  for the screen ACCOUNTS.
  --  IMP:  There are two address sequence IDs passed here.
  --  One for PO address and another for Hospital address.
--=====================================================================================================
  PROCEDURE pr_account_info_save (
    v_hosp_bank_seq_id                 IN OUT tpa_hosp_account_details.hosp_bank_seq_id%TYPE,
    v_addr_seq_id                      IN OUT tpa_hosp_address.addr_seq_id%TYPE,
    v_po_addr_seq_id                   IN OUT tpa_hosp_address.addr_seq_id%TYPE,
    v_hosp_seq_id                      IN tpa_hosp_account_details.hosp_seq_id%TYPE,
    -- SECTION: Hospital Bank Account Details
    v_bank_name                        IN tpa_hosp_account_details.bank_name%TYPE, --/ED
    v_account_number                   IN tpa_hosp_account_details.account_number%TYPE, --/ED
    v_account_in_name_of               IN tpa_hosp_account_details.account_in_name_of%TYPE,
    -- SECTION: Branch Details
    v_branch_seq_id                    IN tpa_hosp_account_details.branch_name%TYPE,
    v_address_1                        IN tpa_hosp_address.address_1%TYPE,
    v_address_2                        IN tpa_hosp_address.address_2%TYPE,
    v_address_3                        IN tpa_hosp_address.address_3%TYPE,
    v_city_type_id                     IN tpa_hosp_address.city_type_id%TYPE,
    v_state_type_id                    IN tpa_hosp_address.state_type_id%TYPE,
    v_pin_code                         IN tpa_hosp_address.pin_code%TYPE,
    v_country_id                       IN tpa_hosp_address.country_id%TYPE,
    -- SECTION: Hospital Management Details
    v_management_name                  IN tpa_hosp_account_details.management_name%TYPE,
    v_issue_cheques_type_id            IN tpa_hosp_account_details.issue_cheques_type_id%TYPE,
    -- SECTION: Pay Order details.  -- This section is going to be an Update as some of the fields were populated in Hospital screen.
    v_hosp_gnrl_seq_id                 IN tpa_hosp_general_dtl.hosp_gnrl_seq_id%TYPE,
    v_empanel_fees_chrg_yn             IN tpa_hosp_general_dtl.empanel_fees_chrg_yn%TYPE,
    v_pay_order_type_id                IN tpa_hosp_general_dtl.pay_order_type_id%TYPE,
    v_pay_order_number                 IN tpa_hosp_general_dtl.pay_order_number%TYPE,
    v_pay_order_amount                 IN tpa_hosp_general_dtl.pay_order_amount%TYPE,
    v_pay_order_received_date          IN tpa_hosp_general_dtl.pay_order_received_date%TYPE,
    v_po_bank_name                     IN tpa_hosp_general_dtl.bank_name%TYPE, --/ED
    v_check_issued_date                IN tpa_hosp_general_dtl.check_issued_date%TYPE,
    -- SECTION: Bank Guarantee Details
    v_bank_guant_seq_id                IN tpa_hosp_bank_guarantee.bank_guant_seq_id%TYPE,
    v_empanel_seq_id                   IN tpa_hosp_bank_guarantee.empanel_seq_id%TYPE,
    v_bank_guant_req_yn                IN tpa_hosp_bank_guarantee.bank_guant_req_yn%TYPE,
    -- SECTION: PO address details
    v_po_address_1                     IN tpa_hosp_address.address_1%TYPE,
    v_po_address_2                     IN tpa_hosp_address.address_2%TYPE,
    v_po_address_3                     IN tpa_hosp_address.address_3%TYPE,
    v_po_city_type_id                  IN tpa_hosp_address.city_type_id%TYPE,
    v_po_state_type_id                 IN tpa_hosp_address.state_type_id%TYPE,
    v_po_pin_code                      IN tpa_hosp_address.pin_code%TYPE,
    v_po_country_id                    IN tpa_hosp_address.country_id%TYPE,
    -- SECTION: PR_USER_LOG
    v_log_seq_id                       IN OUT tpa_hosp_log.log_seq_id%TYPE,
    v_mod_reason_type_id               IN tpa_hosp_log.mod_reason_type_id%TYPE,
    v_reference_date                   IN tpa_hosp_log.reference_date%TYPE,
    v_reference_no                     IN tpa_hosp_log.reference_no%TYPE,
    v_remarks_log                      IN tpa_hosp_log.remarks%TYPE,
    -- Auditing fields.
    v_user_id                          IN NUMBER,
    V_START_DATE                       IN DATE,
    V_END_DATE                         IN DATE,
    v_IBAN_NUM                         IN tpa_hosp_account_details.Bank_Ifsc%TYPE,
    v_SWIFT_CODE                       IN tpa_hosp_account_details.bank_micr%TYPE,
    v_mode_of_payment                  IN tpa_hosp_account_details.mode_of_payment%TYPE,
    V_ACCOUNT_IN_QATAR_YN              IN VARCHAR2,          --CR0226
    V_OUTQTR_BANK_BRANCH               IN VARCHAR2 := NULL,  --CR0226
    v_account_type                     IN varchar2 :='SB',   --CR0226
    v_rows_processed                   OUT NUMBER
  )
  IS
    --to convert to upper case
    v_bank_name_upper               tpa_hosp_account_details.bank_name%TYPE:=upper(v_bank_name); --/ED
    --v_branch_name_upper             tpa_hosp_account_details.branch_name%TYPE:=upper(v_branch_name);
    v_management_name_upper         tpa_hosp_account_details.management_name%TYPE:=upper(v_management_name);
    v_po_bank_name_upper            tpa_hosp_general_dtl.bank_name%TYPE:=upper(v_po_bank_name); --/ED

    --to concatenate log information
    v_screen_name                   VARCHAR2(100):='Add Account Detail Screen ';
    v_column_name                   VARCHAR2(100);
    v_system_gen_yn                 tpa_hosp_log.system_gen_yn%TYPE := 'Y';
    v_log_type_id                   tpa_hosp_log.log_type_id%TYPE;
    v_old_bank_name                 tpa_hosp_account_details.bank_name%TYPE; --/ED
    v_old_account_number            tpa_hosp_account_details.account_number%TYPE; --/ED
    v_old_branch_name               tpa_hosp_account_details.account_in_name_of%TYPE;
    v_old_management_name           tpa_hosp_account_details.management_name%TYPE;
    v_remarks_concat                VARCHAR2(10000):= NULL;
    v_bank_name_mstr                NUMBER;
    v_bank_seq_id_mstr              NUMBER;
    
    CURSOR chk_bank_name IS
      SELECT count(b.bank_name), b.bank_seq_id
      FROM app.Tpa_Bank_Master b
      WHERE upper(b.bank_name) = upper(v_bank_name)
      GROUP BY b.bank_seq_id;
      
    cursor get_branch_name is
      select i.branch_name from tpa_ifsc_code_details i
      where i.branch_seq_id=v_branch_seq_id;
      
       v_branch_name                   VARCHAR2(500);
       v_branch_name_upper             tpa_hosp_account_details.branch_name%TYPE:=upper(v_branch_name);
  
  ---- To get previous bank details
   CURSOR old_hosp_bank_dtls IS
      SELECT account_in_qatar_yn as Qatar_yn ,
      decode(nvl(account_in_qatar_yn,'Y'),'Y','Within Qatar','N','Outside Qatar') as Qatar_desc ,
      ttk_util_pkg.fn_decrypt(a.bank_name)  bank_name,
      ttk_util_pkg.fn_decrypt(a.account_number)  act_no,
      a.account_in_name_of ,
      a.bank_micr as iban,
      a.bank_IFSC as swift_code,
      a.start_date,
      a.end_date,
      a.management_name,
      a.issue_cheques_type_id,
      decode(a.issue_cheques_type_id,'HOS','PROVIDER','MAN','MANAGEMENT') issue_desc,
      decode(nvl(account_in_qatar_yn,'Y'),'Y',c.state_name,b.state_type_id) as city,
      decode(nvl(account_in_qatar_yn,'Y'),'Y',d.city_description,b.city_type_id) as area,
      e.country_name,
      decode(account_in_qatar_yn,'Y',f.branch_name,ttk_util_pkg.fn_decrypt(a.branch_name)) as branch,
      a.account_type,
      decode(a.account_type,'SB','Savings','CA','Current account','CC','Cash Credit Account')as act_type,
      b.address_1,
      b.address_2,
      b.address_3,
      b.pin_code
      FROM tpa_hosp_account_details a left join tpa_hosp_address b on (a.hosp_bank_seq_id = b.hosp_bank_seq_id)
                                     left join tpa_state_code c on (c.state_type_id = b.state_type_id)
                                     left join tpa_city_code d on (d.city_type_id = b.city_type_id)
                                     left join tpa_country_code e on (e.country_id = b.country_id)
                                     left join tpa_branch_code f on (f.branch_seq_id = b.branch_seq_id)
       WHERE a.hosp_seq_id = v_hosp_seq_id
       AND a.hosp_bank_seq_id = v_hosp_bank_seq_id;
       
   old_bank_rec old_hosp_bank_dtls%ROWTYPE;
    
    CURSOR area IS select decode(nvl(V_ACCOUNT_IN_QATAR_YN,'Y'),'Y',city_description,'N',v_city_type_id) 
                         FROM tpa_city_code where case when nvl(V_ACCOUNT_IN_QATAR_YN,'Y') = 'Y'
                                                       then city_type_id  else 'Y' end = case when nvl(V_ACCOUNT_IN_QATAR_YN,'Y') = 'Y'
                                                       then v_city_type_id else 'Y' end;
  
   CURSOR city IS select decode(nvl(V_ACCOUNT_IN_QATAR_YN,'Y'),'Y',state_name,'N',v_state_type_id) 
                       FROM tpa_state_code where case when nvl(V_ACCOUNT_IN_QATAR_YN,'Y') = 'Y'
                                                      then state_type_id  else 'Y' end = case when nvl(V_ACCOUNT_IN_QATAR_YN,'Y') = 'Y'
                                                      then v_state_type_id else 'Y' end;
  
   CURSOR branch (v_branch varchar2) IS select decode(nvl(V_ACCOUNT_IN_QATAR_YN,'Y'),'Y',branch_name,'N',v_branch) 
                       FROM tpa_branch_code where case when nvl(V_ACCOUNT_IN_QATAR_YN,'Y') = 'Y'
                                                       then branch_seq_id  else 1 end = case when nvl(V_ACCOUNT_IN_QATAR_YN,'Y') = 'Y'
                                                       then v_branch_seq_id else to_char(1) end; 
  
   CURSOR country IS select country_name from tpa_country_code where country_id = v_country_id;
   v_country tpa_country_code.country_name%TYPE;
   v_city tpa_state_code.state_name%TYPE;
   v_area tpa_city_code.city_description%TYPE;
   v_branch1 tpa_branch_code.branch_name%TYPE;
   v_remarks varchar2(2000);
  BEGIN
    IF V_ACCOUNT_IN_QATAR_YN = 'Y' THEN 
      OPEN chk_bank_name;
      FETCH chk_bank_name INTO v_bank_name_mstr, v_bank_seq_id_mstr;
      CLOSE chk_bank_name;
      
      OPEN get_branch_name;
      FETCH get_branch_name INTO v_branch_name;
      CLOSE get_branch_name;
    ELSIF V_ACCOUNT_IN_QATAR_YN = 'N' THEN --CR0226
      v_bank_seq_id_mstr := NULL;
      v_branch_name      := TRIM(V_OUTQTR_BANK_BRANCH);  
	  END IF; ----
      v_branch_name_upper := upper(v_branch_name);

      IF v_bank_name_mstr = 0 AND V_ACCOUNT_IN_QATAR_YN = 'Y'THEN
        RAISE_APPLICATION_ERROR (-20361, 'Bank Does not Exist');
      END IF;
      
      OPEN old_hosp_bank_dtls;
      FETCH old_hosp_bank_dtls INTO old_bank_rec;
      CLOSE old_hosp_bank_dtls;
      
      OPEN area;
      FETCH area INTO v_area;
      CLOSE area;
      
      OPEN city;
      FETCH city INTO v_city;
      CLOSE city;
      
      OPEN country;
      FETCH country INTO v_country;
      CLOSE country;
      
      OPEN branch(v_branch_name_upper);
      FETCH branch INTO v_branch1;
      CLOSE branch;
      
    IF ( v_hosp_bank_seq_id = 0 ) THEN     --add account details into tables TPA_HOSP_ACCOUNT_DETAILS and ADDRESS_PKG.PR_HOSPITAL_BANK_ADDRESS_SAVE and ADDRESS_PKG.PR_HOSPITAL_PO_ADDRESS_SAVE
        INSERT INTO tpa_hosp_account_details
          (hosp_bank_seq_id,
           hosp_seq_id,
           bank_name,
           account_number, --/ED
           account_in_name_of,
           branch_name,
           management_name,
           issue_cheques_type_id,
           added_by,
           added_date,
           start_date,
           end_date,
           Bank_Micr,
           Bank_Ifsc,
           mode_of_payment,
           bank_seq_id,
           review_yn,
           account_in_qatar_yn,
           account_type)
        VALUES
          (tpa_hosp_account_details_seq.NEXTVAL,
           v_hosp_seq_id,
           ttk_util_pkg.fn_encrypt(v_bank_name_upper),
           ttk_util_pkg.fn_encrypt(v_account_number), --/ED
           v_account_in_name_of,
           ttk_util_pkg.fn_encrypt(v_branch_name_upper),
           v_management_name_upper,
           v_issue_cheques_type_id,
           v_user_id,
           SYSDATE,
           V_START_DATE,
           V_END_DATE,
           v_SWIFT_CODE,
           v_IBAN_NUM,
           v_mode_of_payment,
           v_bank_seq_id_mstr,
           'N',
           V_ACCOUNT_IN_QATAR_YN,
           v_account_type)
        RETURNING hosp_bank_seq_id INTO v_hosp_bank_seq_id;
      --added for intx project 
        --added for intx project
        v_rows_processed  := SQL%ROWCOUNT;

        -- BANK ADDRESS.
        ADDRESS_PKG.PR_HOSPITAL_BANK_ADDRESS_SAVE (v_addr_seq_id,v_hosp_bank_seq_id,v_address_1,
                                                   v_address_2,v_address_3,v_city_type_id,
                                                   v_state_type_id, v_pin_code,v_country_id,v_branch_seq_id,
                                                   v_user_id,v_rows_processed);
        -- Pay Order  ADDRESS.
        ADDRESS_PKG.PR_HOSPITAL_PO_ADDRESS_SAVE (v_po_addr_seq_id,v_hosp_gnrl_seq_id,v_po_address_1,
                                                 v_po_address_2,v_po_address_3,v_po_city_type_id,
                                                 v_po_state_type_id,v_po_pin_code, v_po_country_id,
                                                 v_user_id, v_rows_processed);

      ELSE                  -- add log details to Tpa_hosp_log and updated tables TPA_HOSP_ACCOUNT_DETAILS,ADDRESS_PKG.PR_HOSPITAL_BANK_ADDRESS_SAVE,ADDRESS_PKG.PR_HOSPITAL_PO_ADDRESS_SAVE
        -- save the modified deails of accounts
        UPDATE tpa_hosp_account_details
           SET bank_name                       = ttk_util_pkg.fn_encrypt(v_bank_name_upper), --/ED
               account_number                  = ttk_util_pkg.fn_encrypt(v_account_number),
               account_in_name_of              = v_account_in_name_of,
               branch_name                     = ttk_util_pkg.fn_encrypt(v_branch_name_upper),
               management_name                 = v_management_name_upper,
               issue_cheques_type_id           = v_issue_cheques_type_id,
               updated_by                      = v_user_id,
               updated_date                    = SYSDATE,
               start_date                      = v_start_date,
               end_date                        = v_end_date,
               bank_micr                       = v_SWIFT_CODE,
               Bank_Ifsc                       = v_IBAN_NUM,
               mode_of_payment                 = v_mode_of_payment,
               bank_seq_id                     = v_bank_seq_id_mstr,
               review_yn                       = 'N',
               account_in_qatar_yn             = v_account_in_qatar_yn,
               account_type                    = v_account_type
         WHERE hosp_bank_seq_id   = v_hosp_bank_seq_id
           AND hosp_seq_id        = v_hosp_seq_id ;

        v_rows_processed  := SQL%ROWCOUNT;

        -- save modified BANK ADDRESS.
        address_pkg.pr_hospital_bank_address_save (v_addr_seq_id,v_hosp_bank_seq_id,v_address_1,
                                                   v_address_2, v_address_3, v_city_type_id,v_state_type_id,
                                                   v_pin_code,v_country_id,v_branch_seq_id,v_user_id,v_rows_processed);

        -- save modified Pay Order ADDRESS.
        address_pkg.pr_hospital_po_address_save (v_po_addr_seq_id,v_hosp_gnrl_seq_id,v_po_address_1,
                                                 v_po_address_2,v_po_address_3,v_po_city_type_id,v_po_state_type_id,
                                                 v_po_pin_code,v_po_country_id,v_user_id,v_rows_processed);
  END IF;
        ---- Added in Bank log capture including first time also...
             -- for Log screen.
 IF (nvl(old_bank_rec.bank_name,v_bank_name_upper||'A')!=nvl(v_bank_name_upper,old_bank_rec.bank_name||'A')) OR ( nvl(old_bank_rec.act_no,v_account_number||'A') != nvl(v_account_number,old_bank_rec.act_no||'A'))  OR (NVL(old_bank_rec.branch,v_branch1||'A') != NVL(v_branch1,old_bank_rec.branch||'A')) OR
       (nvl(old_bank_rec.account_in_name_of,v_account_in_name_of||'A')!=NVL(v_account_in_name_of,old_bank_rec.account_in_name_of||'A')) OR (nvl(old_bank_rec.iban,v_SWIFT_CODE||'A') != nvl(v_SWIFT_CODE,old_bank_rec.iban||'A')) OR (nvl(old_bank_rec.account_type,v_account_type||'A') != nvl(v_account_type,old_bank_rec.account_type||'A'))  OR
      (NVL(old_bank_rec.swift_code,v_IBAN_NUM||'A')!=NVL(v_IBAN_NUM,old_bank_rec.swift_code||'A')) OR (NVL(old_bank_rec.start_date,V_START_DATE+2)!= NVL(V_START_DATE,old_bank_rec.start_date+2)) OR (NVL(old_bank_rec.end_date,V_END_DATE+2) != NVL(V_END_DATE,old_bank_rec.end_date+2))  OR (NVL(old_bank_rec.pin_code ,v_pin_code+1) != NVL(v_pin_code, old_bank_rec.pin_code+1)) OR
	   ( NVL(old_bank_rec.issue_cheques_type_id,v_issue_cheques_type_id||'A') != NVL(v_issue_cheques_type_id,old_bank_rec.issue_cheques_type_id||'A')) OR ( NVL(old_bank_rec.address_1,V_ADDRESS_1||'A')!= NVL(V_ADDRESS_1,old_bank_rec.address_1||'A')) OR ( NVL(old_bank_rec.address_2,V_ADDRESS_2||'A')!= NVL(V_ADDRESS_2,old_bank_rec.address_2||'A')) OR ( NVL(old_bank_rec.address_3,V_ADDRESS_3||'A')!= NVL(V_ADDRESS_3,old_bank_rec.address_3||'A')) OR
	   (NVL(old_bank_rec.country_name,v_country||'A') != NVL(v_country,old_bank_rec.country_name||'A') ) OR (NVL(old_bank_rec.city,v_city||'A') != NVL(v_city,old_bank_rec.city||'A')) OR (NVL(old_bank_rec.area,v_area||'A') != NVL(v_area,old_bank_rec.area||'A'))  OR 
	   (NVL(old_bank_rec.Qatar_yn,v_account_in_qatar_yn||'A') != NVL(v_account_in_qatar_yn,old_bank_rec.Qatar_yn||'A')) OR (NVL(old_bank_rec.management_name,v_management_name_upper||'A') != NVL(v_management_name_upper,old_bank_rec.management_name||'A'))  THEN
             --check for bank_name changed or not
         IF (nvl(old_bank_rec.bank_name,v_bank_name_upper||'A')!=nvl(v_bank_name_upper,old_bank_rec.bank_name||'A')) THEN
           v_column_name:='Bank Name';
           ttk_util_pkg.pr_log_concat(v_column_name,old_bank_rec.bank_name,v_bank_name_upper,v_remarks);
           v_remarks_concat:=v_remarks_concat||v_remarks||chr(10);
         END IF;
          --check for account_number changed or not
         IF ( nvl(old_bank_rec.act_no,v_account_number||'A') != nvl(v_account_number,old_bank_rec.act_no||'A')) THEN
            v_column_name:= 'Account No';
            ttk_util_pkg.pr_log_concat (v_column_name,old_bank_rec.act_no,v_account_number,v_remarks);
            v_remarks_concat:=v_remarks_concat||v_remarks||chr(10);
         END IF;
          --check for branch changed or not
          IF (NVL(old_bank_rec.branch,v_branch1||'A') != NVL(v_branch1,old_bank_rec.branch||'A')) THEN
            v_column_name:= 'Branch Name';
            ttk_util_pkg.pr_log_concat (v_column_name,old_bank_rec.branch,v_branch1,v_remarks);
            v_remarks_concat:=v_remarks_concat||v_remarks||chr(10);
          END IF;
           --check for account name changed or not
         IF  (nvl(old_bank_rec.account_in_name_of,v_account_in_name_of||'A')!=NVL(v_account_in_name_of,old_bank_rec.account_in_name_of||'A'))  THEN
           v_column_name:='account_name';
           ttk_util_pkg.pr_log_concat(v_column_name,old_bank_rec.account_in_name_of,v_account_in_name_of,v_remarks);
           v_remarks_concat:=v_remarks_concat||v_remarks||chr(10);
         END IF;
          --check for account type changed or not
         IF (nvl(old_bank_rec.account_type,v_account_type||'A') != nvl(v_account_type,old_bank_rec.account_type||'A')) THEN
            v_column_name:= 'Account Type';
            ttk_util_pkg.pr_log_concat (v_column_name,old_bank_rec.act_type,replace(replace(replace(v_account_type,'SB','Savings'),'CA','Current account'),'CC','Cash Credit Account'),v_remarks);
            v_remarks_concat:=v_remarks_concat||v_remarks||chr(10);
         END IF;
          --check for iban number changed or not
          IF (nvl(old_bank_rec.iban,v_SWIFT_CODE||'A') != nvl(v_SWIFT_CODE,old_bank_rec.iban||'A')) THEN
            v_column_name:= 'IBAN Number';
            ttk_util_pkg.pr_log_concat (v_column_name,old_bank_rec.iban,v_SWIFT_CODE,v_remarks);
            v_remarks_concat:=v_remarks_concat||v_remarks||chr(10);
          END IF;
          ---- check for swift code changed or not
          IF (NVL(old_bank_rec.swift_code,v_IBAN_NUM||'A')!=NVL(v_IBAN_NUM,old_bank_rec.swift_code||'A')) THEN
           v_column_name:='Swift Code';
           ttk_util_pkg.pr_log_concat(v_column_name,old_bank_rec.swift_code,v_IBAN_NUM,v_remarks);
           v_remarks_concat:=v_remarks_concat||v_remarks||chr(10);
         END IF;
          --check for start date changed or not
         IF ( NVL(old_bank_rec.start_date,V_START_DATE+2) != NVL(V_START_DATE,old_bank_rec.start_date+2)) THEN
            v_column_name:= 'Start Date';
            ttk_util_pkg.pr_log_concat (v_column_name,old_bank_rec.start_date,V_START_DATE,v_remarks);
            v_remarks_concat:=v_remarks_concat||v_remarks||chr(10);
         END IF;
          --check for end date changed or not
          IF ( NVL(old_bank_rec.end_date,V_END_DATE+2) != NVL(V_END_DATE,old_bank_rec.end_date+2) ) THEN
            v_column_name:= 'End Date';
            ttk_util_pkg.pr_log_concat (v_column_name,old_bank_rec.end_date,V_END_DATE,v_remarks);
            v_remarks_concat:=v_remarks_concat||v_remarks||chr(10);
          END IF;
         --check for review changed or not
         IF  (NVL(old_bank_rec.management_name,v_management_name_upper||'A') != NVL(v_management_name_upper,old_bank_rec.management_name||'A')) THEN
           v_column_name:='management_name';
           ttk_util_pkg.pr_log_concat(v_column_name,old_bank_rec.management_name,v_management_name_upper,v_remarks);
           v_remarks_concat:=v_remarks_concat||v_remarks||chr(10);
         END IF;
          --check for issue cheques changed or not
         IF ( NVL(old_bank_rec.issue_cheques_type_id,v_issue_cheques_type_id||'A') != NVL(v_issue_cheques_type_id,old_bank_rec.issue_cheques_type_id||'A')) THEN
            v_column_name:= 'Issue Cheques To';
            ttk_util_pkg.pr_log_concat (v_column_name,old_bank_rec.issue_desc,replace(replace(v_issue_cheques_type_id,'MAN','MANAGEMENT'),'HOS','PROVIDER'),v_remarks);
            v_remarks_concat:=v_remarks_concat||v_remarks||chr(10);
         END IF;
          --check for address 1 changed or not
          IF ( NVL(old_bank_rec.address_1,V_ADDRESS_1||'A') != NVL(V_ADDRESS_1,old_bank_rec.address_1||'A')) THEN
            v_column_name:= 'Address 1';
            ttk_util_pkg.pr_log_concat (v_column_name,old_bank_rec.address_1,V_ADDRESS_1,v_remarks);
            v_remarks_concat:=v_remarks_concat||v_remarks||chr(10);
          END IF;
          
          --check for address 2 changed or not
          IF ( NVL(old_bank_rec.address_2,V_ADDRESS_2||'A')!= NVL(V_ADDRESS_2,old_bank_rec.address_2||'A') ) THEN
            v_column_name:= 'Address 2';
            ttk_util_pkg.pr_log_concat (v_column_name,old_bank_rec.address_2,V_ADDRESS_2,v_remarks);
            v_remarks_concat:=v_remarks_concat||v_remarks||chr(10);
          END IF;
              --check for address 3 changed or not
          IF ( NVL(old_bank_rec.address_3,V_ADDRESS_3||'A')!= NVL(V_ADDRESS_3,old_bank_rec.address_3||'A')) THEN
            v_column_name:= 'Address 3';
            ttk_util_pkg.pr_log_concat (v_column_name,old_bank_rec.address_3,V_ADDRESS_3,v_remarks);
            v_remarks_concat:=v_remarks_concat||v_remarks||chr(10);
          END IF;
          --check for pincode changed or not
          IF (NVL(old_bank_rec.pin_code ,v_pin_code+1) != NVL(v_pin_code, old_bank_rec.pin_code+1)) THEN
            v_column_name:= 'Pincode';
            ttk_util_pkg.pr_log_concat (v_column_name,old_bank_rec.pin_code,v_pin_code,v_remarks);
            v_remarks_concat:=v_remarks_concat||v_remarks||chr(10);
          END IF;
          --check for bank city changed or not
          IF (NVL(old_bank_rec.city,v_city||'A') != NVL(v_city,old_bank_rec.city||'A'))  THEN
            v_column_name:= 'City';
            ttk_util_pkg.pr_log_concat (v_column_name,old_bank_rec.city ,v_city,v_remarks);
            v_remarks_concat:=v_remarks_concat||v_remarks||chr(10);
          END IF;
               --check for branch_area changed or not
          IF (NVL(old_bank_rec.area,v_area||'A') != NVL(v_area,old_bank_rec.area||'A')) THEN
            v_column_name:= 'Area';
            ttk_util_pkg.pr_log_concat (v_column_name,old_bank_rec.area,v_area,v_remarks);
            v_remarks_concat:=v_remarks_concat||v_remarks||chr(10);
          END IF;
               --check for country name changed or not
          IF (NVL(old_bank_rec.country_name,v_country||'A') != NVL(v_country,old_bank_rec.country_name||'A') ) THEN
            v_column_name:= 'Country';
            ttk_util_pkg.pr_log_concat (v_column_name,old_bank_rec.country_name,v_country,v_remarks);
            v_remarks_concat:=v_remarks_concat||v_remarks||chr(10);
          END IF;
          
                       ---- CR0226 -----------
                      -- IF ACCOUNT REGION CHANGE
           IF (NVL(old_bank_rec.Qatar_yn,v_account_in_qatar_yn||'A') != NVL(v_account_in_qatar_yn,old_bank_rec.Qatar_yn||'A')) THEN
              v_column_name:= 'Bank Location';
              ttk_util_pkg.pr_log_concat (v_column_name,old_bank_rec.Qatar_desc,replace(replace(nvl(V_ACCOUNT_IN_QATAR_YN,'Y'),'Y','Within Qatar'),'N','Outside Qatar'),v_remarks);
              v_remarks_concat:=v_remarks_concat||v_remarks||chr(10);
           END IF;
                     ----------------------------          
          --concate the infn. abt value changed in particular cols.
          v_remarks_concat := 'Reference Date   : '||to_char(v_reference_date,'dd/mm/yyyy')||CHR(10)||
                              ' For: '||v_screen_name||CHR(10)||v_remarks_concat||chr(10)||'Remarks: '|| v_remarks_log;

          --assign log_type_id to account changes
          v_log_type_id := 'ACC';

          -- insert into log table for account changes
          ttk_util_pkg.pr_user_log (v_log_seq_id ,v_hosp_seq_id,
                                    v_system_gen_yn,v_log_type_id ,
                                    v_mod_reason_type_id, nvl(v_reference_date,sysdate),v_reference_no,
                                    v_remarks_concat,v_user_id,v_rows_processed );
         END IF;
   INSERT INTO tpa_hosp_account_history (hosp_bank_seq_id,hosp_seq_id,bank_name,account_number,
                account_in_name_of,branch_name,issue_cheques_type_id,added_by,added_date,start_date,end_date,Bank_Micr,Bank_Ifsc,mode_of_payment,account_in_qatar_yn)                
        VALUES  (TPA_HOSP_ACCOUNT_HISTORY_SEQ.NEXTVAL,v_hosp_seq_id,ttk_util_pkg.fn_encrypt(v_bank_name_upper), --//ED
                ttk_util_pkg.fn_encrypt(v_account_number),v_account_in_name_of,ttk_util_pkg.fn_encrypt(v_branch_name_upper), --//ED
                v_issue_cheques_type_id,v_user_id,sysdate,V_START_DATE, V_END_DATE,ttk_util_pkg.fn_encrypt(v_SWIFT_CODE),ttk_util_pkg.fn_encrypt(v_IBAN_NUM),v_mode_of_payment,v_account_in_qatar_yn);

    -- This is update only table from account screen.
    -- The record to this table is inserted from Hospital screen.
    UPDATE tpa_hosp_general_dtl
       SET empanel_fees_chrg_yn            = v_empanel_fees_chrg_yn,
           pay_order_type_id               = v_pay_order_type_id,
           pay_order_number                = v_pay_order_number,
           pay_order_amount                = v_pay_order_amount,
           pay_order_received_date         = trunc(v_pay_order_received_date),
           bank_name                       = v_po_bank_name_upper, --/ED
           check_issued_date               = trunc(v_check_issued_date),
           updated_by                      = v_user_id,
           updated_date                    = SYSDATE
     WHERE hosp_gnrl_seq_id   = v_hosp_gnrl_seq_id
       AND hosp_seq_id        = v_hosp_seq_id
       AND empanel_seq_id     = v_empanel_seq_id;

    UPDATE tpa_hosp_bank_guarantee
       SET bank_guant_req_yn               = v_bank_guant_req_yn,
           updated_by                      = v_user_id,
           updated_date                    = SYSDATE
     WHERE bank_guant_seq_id = v_bank_guant_seq_id
       AND empanel_seq_id    = v_empanel_seq_id;

   COMMIT;
 END pr_account_info_save;

--=====================================================================================================
  -- for Insert and Updation of  Validation Information.
--=====================================================================================================
  PROCEDURE pr_validation_save (
    v_validate_seq_id                  IN OUT tpa_hosp_validation.validate_seq_id%TYPE,
    v_hosp_seq_id                      IN tpa_hosp_validation.hosp_seq_id%TYPE,
    v_validation_req_yn                IN tpa_hosp_validation.validation_req_yn%TYPE,
    v_marked_date                      IN tpa_hosp_validation.marked_date%TYPE,
    v_visit_done_yn                    IN tpa_hosp_validation.visit_done_yn%TYPE,
    v_validated_by                     IN tpa_hosp_validation.validated_by%TYPE,
    v_validated_date                   IN tpa_hosp_validation.validated_date%TYPE,
    v_report_rcvd_yn                   IN tpa_hosp_validation.report_rcvd_yn%TYPE,
    v_remarks                          IN tpa_hosp_validation.remarks%TYPE,
    v_val_status_general_type_id       IN tpa_hosp_validation.val_status_general_type_id%TYPE,
    v_user_id                          IN NUMBER,
    v_rows_processed                   OUT NUMBER
  )
  IS
    v_empanel_status_type_id           tpa_hosp_empanel_status.empanel_status_type_id%TYPE;
    v_from_date                        tpa_hosp_empanel_status.from_date%TYPE;
    v_to_date                          tpa_hosp_empanel_status.to_date%TYPE;
    v_tpa_regist_date                  tpa_hosp_info.tpa_regist_date%TYPE;
 /*   v_old_marked_date                  tpa_hosp_validation.marked_date%TYPE;
    v_old_validated_date               tpa_hosp_validation.validated_date%TYPE;
    v_cnt_marked_date                  NUMBER;
    v_cnt_validated_date               NUMBER;
 */
  BEGIN
     --get status for hospital
     SELECT empanel_status_type_id,s.from_date,s.to_date
       INTO v_empanel_status_type_id,v_from_date,v_to_date
       FROM tpa_hosp_empanel_status s WHERE hosp_seq_id = v_hosp_seq_id AND active_yn = 'Y';

     --compare tpa registration date with marked date and validated date
     SELECT tpa_regist_date INTO v_tpa_regist_date FROM tpa_hosp_info WHERE hosp_seq_id = v_hosp_seq_id;

/*
     --check for marked date exists or not
     SELECT count(1) INTO v_cnt_marked_date
       FROM tpa_hosp_validation WHERE hosp_seq_id = v_hosp_seq_id AND trunc(marked_date) = trunc(v_marked_date) ;

     --check for validated date exists or not
     SELECT count(1) INTO v_cnt_validated_date
       FROM tpa_hosp_validation WHERE hosp_seq_id = v_hosp_seq_id AND trunc(validated_date) = trunc(v_validated_date) ;
*/
     IF (( v_val_status_general_type_id = 'STE' ) AND ( v_empanel_status_type_id = 'EMP' )) THEN
        RAISE_APPLICATION_ERROR(-20016, 'Stop Empanelment cannot be done after empanelment');
     ELSIF (( v_validated_date BETWEEN v_from_date AND v_to_date ) AND ( v_empanel_status_type_id = 'EMP' )) THEN
        RAISE_APPLICATION_ERROR(-20023,'Validation date for the hospital should not be within empanel period');
     ELSIF ( v_validated_date IS NOT NULL ) AND ( v_tpa_regist_date > v_validated_date ) THEN
        RAISE_APPLICATION_ERROR(-20024,'Validated date cannot be prior to tpa registration date');
     ELSIF ( v_tpa_regist_date > v_marked_date ) THEN
        RAISE_APPLICATION_ERROR(-20025,'Marked date cannot be prior to tpa registration date');
     ELSIF ( v_validate_seq_id = 0 ) THEN  -- add new validation
/*      IF ( v_cnt_marked_date > 0 ) THEN
           RAISE_APPLICATION_ERROR(-20023,'Validation marked date for the hospital cannot be duplicated');
        ELSIF ( v_cnt_validated_date > 0 ) THEN
           RAISE_APPLICATION_ERROR(-20024,'Validated date for the hospital cannot be duplicated');
        ELSE  */
           INSERT INTO tpa_hosp_validation (validate_seq_id,hosp_seq_id,validation_req_yn,marked_date,
                       visit_done_yn,validated_by,validated_date,report_rcvd_yn,remarks,val_status_general_type_id,
                       added_by, added_date)
                VALUES (tpa_hosp_validation_seq.NEXTVAL,v_hosp_seq_id,v_validation_req_yn,trunc(v_marked_date),
                       v_visit_done_yn,v_validated_by,v_validated_date,v_report_rcvd_yn,v_remarks,
                       v_val_status_general_type_id,v_user_id,SYSDATE)
             RETURNING validate_seq_id INTO v_validate_seq_id;
--        END IF;
     ELSE
/*        --check for marked date and validated date exists or not
        SELECT trunc(marked_date),trunc(validated_date)
          INTO v_old_marked_date,v_old_validated_date
          FROM tpa_hosp_validation
         WHERE validate_seq_id = v_validate_seq_id;

        IF (( v_old_marked_date != trunc(v_marked_date)) AND v_cnt_marked_date > 0 ) THEN
           RAISE_APPLICATION_ERROR(-20023,'Validation marked date for the hospital cannot be duplicated');
        ELSIF (( v_old_validated_date != trunc(v_validated_date)) AND v_cnt_validated_date > 0 )
              OR (( v_old_validated_date IS NULL ) AND ( v_cnt_validated_date > 0 )) THEN
           RAISE_APPLICATION_ERROR(-20024,'Validated date for the hospital cannot be duplicated');
        ELSE
*/
           -- save modified validation details
           UPDATE tpa_hosp_validation
              SET hosp_seq_id                     = v_hosp_seq_id,
                  validation_req_yn               = v_validation_req_yn,
                  marked_date                     = trunc(v_marked_date),
                  visit_done_yn                   = v_visit_done_yn,
                  validated_by                    = v_validated_by,
                  validated_date                  = v_validated_date,
                  report_rcvd_yn                  = v_report_rcvd_yn,
                  remarks                         = v_remarks,
                  val_status_general_type_id      = v_val_status_general_type_id,
                  updated_by                      = v_user_id,
                  updated_date                    = SYSDATE
            WHERE validate_seq_id = v_validate_seq_id;
--        END IF;
     END IF;

      v_rows_processed  := SQL%ROWCOUNT;
    COMMIT;
  END pr_validation_save;

--=====================================================================================================
  -- for deleting one or set of validations selected.
  -- The validation IDs should be concatenated. Delimiter is "|"
--=====================================================================================================
  PROCEDURE pr_validation_delete (
    v_validate_seq_ids                 IN VARCHAR2,        --  Concatenated IDS. Delimiter is "|".
    v_rows_processed                   OUT NUMBER
  )
  IS
    str_tab   ttk_util_pkg.str_table_type;
  BEGIN
    -- get validation ids
    str_tab := ttk_util_pkg.parse_str ( v_validate_seq_ids );
    -- delete validation for given ids
    FORALL i  IN str_tab.First..str_tab.Last
       DELETE tpa_hosp_validation
      WHERE validate_seq_id = to_number(str_tab(i));

      v_rows_processed  := sql%rowcount;
    COMMIT;
  END pr_validation_delete;

--=====================================================================================================
  -- Create and Updation of feedback and Feedback details.
  -- The Question Id adn Anawer Ids should be sent concatenated. Delimiter is "|"
--=====================================================================================================
  PROCEDURE pr_hospital_feedback_save (
    v_feedback_seq_id                  IN OUT tpa_hosp_feedback.feedback_seq_id%TYPE,
    v_hosp_seq_id                      IN tpa_hosp_feedback.hosp_seq_id%TYPE,
    v_feedback_date                    IN tpa_hosp_feedback.feedback_date%TYPE,
    v_suggestions                      IN tpa_hosp_feedback.suggestions%TYPE,
    v_qid_aid                          IN VARCHAR2,
    v_user_id                          IN NUMBER,
    v_rows_processed                   OUT NUMBER
  )
  IS
    str_tab                            ttk_util_pkg.str_table_type;
    v_parm_cnt                         INTEGER := 2;
    v_quest_type_id                    tpa_hosp_feedback_details.quest_type_id%TYPE;
    v_ans_type_id                      tpa_hosp_feedback_details.ans_type_id%TYPE;
  BEGIN
    str_tab := ttk_util_pkg.parse_str ( v_qid_aid );

    IF ( str_tab.count = 0 ) THEN
      return;  -- no feedback question and answer is given
    END IF;

    -- add new feedback
    IF ( v_feedback_seq_id = 0 ) THEN
      INSERT INTO tpa_hosp_feedback (feedback_seq_id,hosp_seq_id,feedback_date,suggestions,added_by,added_date)
           VALUES (tpa_hosp_feedback_seq.NEXTVAL,v_hosp_seq_id,trunc(v_feedback_date),v_suggestions,v_user_id,SYSDATE)
           RETURN feedback_seq_id INTO v_feedback_seq_id;

      FOR i IN 1..(str_tab.count() / v_parm_cnt)
      LOOP
        v_quest_type_id := str_tab( (i* v_parm_cnt) - 1 ) ;  -- 1.
        v_ans_type_id   := str_tab( (i* v_parm_cnt)  ) ;  -- 2.

        INSERT INTO tpa_hosp_feedback_details(feedback_det_seq_id,feedback_seq_id,quest_type_id,ans_type_id,added_by,added_date)
             VALUES (tpa_hosp_feedback_details_seq.NEXTVAL,v_feedback_seq_id,v_quest_type_id,v_ans_type_id,v_user_id,SYSDATE);
      END LOOP;
    ELSE
      -- save modified data of feedback
      UPDATE tpa_hosp_feedback
         SET feedback_date                   = v_feedback_date,
             suggestions                     = v_suggestions,
             updated_by                      = v_user_id,
             updated_date                    = SYSDATE
       WHERE feedback_seq_id = v_feedback_seq_id;

         -- associate question with answer in details table
         FOR i IN 1..(str_tab.count() / v_parm_cnt)
         LOOP

           v_quest_type_id := str_tab( (i* v_parm_cnt) - 1 ) ;  -- 1.
           v_ans_type_id   := str_tab( (i* v_parm_cnt)  ) ;  -- 2.

           UPDATE TPA_HOSP_FEEDBACK_DETAILS
              SET ans_type_id                     = v_ans_type_id,
                  updated_by                      = v_user_id,
                  updated_date                    = SYSDATE
            WHERE feedback_seq_id  = v_feedback_seq_id
              AND quest_type_id    = to_number(v_quest_type_id);
         END LOOP;
    END IF;

      v_rows_processed  := SQL%ROWCOUNT;
    COMMIT;
  END pr_hospital_feedback_save;

--=====================================================================================================
  -- for Feedback delete.
  -- Feedback Ids should be sent concatenated. Delimiter is "|"
--=====================================================================================================
  PROCEDURE pr_hospital_feedback_delete (
    v_feedback_seq_ids                 IN VARCHAR2,  --  Concatenated IDS. Delimiter is "|".
    v_rows_processed                   OUT NUMBER
  )
  IS
     str_tab                 ttk_util_pkg.str_table_type;
  BEGIN
    str_tab := ttk_util_pkg.parse_str ( v_feedback_seq_ids );


    FORALL i  IN str_tab.First..str_tab.Last
       DELETE tpa_hosp_feedback_details
      WHERE feedback_seq_id = to_number(str_tab(i));

    FORALL i  IN str_tab.First..str_tab.Last
       DELETE tpa_hosp_feedback
      WHERE feedback_seq_id = to_number(str_tab(i));

     v_rows_processed  := sql%rowcount;
   COMMIT;
 END pr_hospital_feedback_delete;

--=====================================================================================================
  -- to change/update the Hospital Empanelment Status.
--=====================================================================================================
  PROCEDURE pr_hospital_status_save (
    v_empanel_seq_id                   IN tpa_hosp_empanel_status.empanel_seq_id%TYPE,
    v_empanel_status_type_id           IN tpa_hosp_empanel_status.empanel_status_type_id%TYPE,
    v_empanel_rson_type_id             IN tpa_hosp_empanel_status.empanel_rson_type_id%TYPE,
    v_from_date                        IN tpa_hosp_empanel_status.from_date%TYPE,
    v_to_date                          IN tpa_hosp_empanel_status.to_date%TYPE,
    v_notified_to_tpa_acc              IN tpa_hosp_empanel_status.notified_to_tpa_acc%TYPE,
    v_date_of_notification             IN tpa_hosp_empanel_status.date_of_notification%TYPE,
    v_remarks                          IN tpa_hosp_empanel_status.remarks%TYPE,
    v_user_id                          IN NUMBER,
    v_rows_processed                   OUT NUMBER
  )
  IS
    v_dest_msg_seq_id                 destination_message.dest_msg_seq_id%TYPE;                
    v_hosp_seq_id                      tpa_hosp_empanel_status.hosp_seq_id%TYPE;
    v_new_empanel_seq_id               tpa_hosp_empanel_status.empanel_seq_id%TYPE;  -- if renewed
    v_old_from_date                    tpa_hosp_empanel_status.from_date%TYPE;
    v_old_to_date                      tpa_hosp_empanel_status.to_date%TYPE;
    v_empanel_number                   tpa_hosp_info.empanel_number%TYPE;
    v_validation_req_yn                tpa_hosp_validation.validation_req_yn%TYPE;
    v_validation_status                tpa_hosp_validation.val_status_general_type_id%TYPE;
    v_old_tariff_rcvd_date             tpa_hosp_general_dtl.tariff_rcvd_date%TYPE;
    v_old_hosp_info_rcvd_date          tpa_hosp_general_dtl.hosp_info_rcvd_date%TYPE;
    v_old_hosp_form_rcvd_date          tpa_hosp_general_dtl.hosp_verify_form_rcvd_date%TYPE;
    v_old_reg_crt_rcvd_date            tpa_hosp_general_dtl.reg_crt_rcvd_date%TYPE;
    v_signed_date                      tpa_hosp_general_dtl.signed_date%TYPE;
    v_pay_order_received_date          tpa_hosp_general_dtl.pay_order_received_date%TYPE;
    v_empanel_fees_chrg_yn             tpa_hosp_general_dtl.empanel_fees_chrg_yn%TYPE;
    v_tpa_regist_date                  DATE;
    v_count                            INTEGER;
    v_tpa_ref_number                   tpa_hosp_info.tpa_ref_number%TYPE;
    v_hosp_name                        tpa_hosp_info.hosp_name%TYPE;

    --for log screen
    v_log_seq_id                       tpa_hosp_log.log_seq_id%TYPE :=0 ;
    v_screen_name                      VARCHAR2(100):='Status Save Screen ';
    v_system_gen_yn                    tpa_hosp_log.system_gen_yn%TYPE := 'Y';
    v_log_type_id                      tpa_hosp_log.log_type_id%TYPE := 'STA';
    v_mod_reason_type_id               tpa_hosp_log.mod_reason_type_id%TYPE := NULL;
    v_reference_date                   tpa_hosp_log.reference_date%TYPE := SYSDATE;
    v_reference_no                     tpa_hosp_log.reference_no%TYPE := NULL;

    v_old_empanel_status_type          tpa_hosp_empanel_status.empanel_status_type_id%TYPE;
    v_old_empanel_rson_type            tpa_hosp_empanel_status.empanel_rson_type_id%TYPE;
    v_empanel_description              tpa_hosp_empanel_status_code.empanel_description%TYPE;
    v_rson_description                 tpa_hosp_empanel_rson_code.rson_description%TYPE;
    v_old_empanel_description          tpa_hosp_empanel_status_code.empanel_description%TYPE;
    v_old_rson_description             tpa_hosp_empanel_rson_code.rson_description%TYPE;
    v_remarks_empanel_status_type      VARCHAR2(1000):=NULL;
    v_remarks_empanel_rson_type        VARCHAR2(1000):=NULL;
    v_remarks_from_date                VARCHAR2(1000):=NULL;
    v_remarks_to_date                  VARCHAR2(1000):=NULL;
    v_remarks_concat                   VARCHAR2(1000):=NULL;

    v_pan_number                       tpa_hosp_info.trade_licenc_numb%TYPE;
    v_hosp_owner_general_type_id       tpa_hosp_info.hosp_owner_general_type_id%TYPE;
    v_tan_number                       tpa_hosp_info.tan_number%TYPE;
    v_tds_subcat_type_id               tpa_hosp_info.tds_subcat_type_id%TYPE;
    v_review_yn                       varchar2(1);

  BEGIN
    v_count := 0;
    v_empanel_number := NULL;
    --get old data
    SELECT hosp_seq_id,empanel_status_type_id,empanel_rson_type_id,from_date,to_date
      INTO v_hosp_seq_id,v_old_empanel_status_type,v_old_empanel_rson_type,v_old_from_date,v_old_to_date
      FROM tpa_hosp_empanel_status
     WHERE empanel_seq_id = v_empanel_seq_id;
    --get tpa_regist_date to compare
    SELECT tpa_regist_date, tpa_ref_number , hosp_name ,a.trade_licenc_numb,a.tan_number,a.hosp_owner_general_type_id,a.tds_subcat_type_id
      INTO v_tpa_regist_date , v_tpa_ref_number , v_hosp_name ,v_pan_number,v_tan_number,v_hosp_owner_general_type_id,v_tds_subcat_type_id
      FROM tpa_hosp_info a
     WHERE hosp_seq_id = v_hosp_seq_id;
     --Commented for Qatar
    /*IF v_empanel_status_type_id IN ('REN','EMP') AND
        (\*v_pan_number IS NULL OR v_tan_number IS NULL OR*\ v_hosp_owner_general_type_id  IS NULL OR v_tds_subcat_type_id IS NULL ) THEN
      raise_application_error(-20735,'Hospital Status and Category are mandatory for TDS processing ');
    END IF;*/
    --Renew Empanelment
    IF ( v_empanel_status_type_id = 'REN' ) AND ( v_old_empanel_status_type ='EMP') THEN
       IF (trunc(nvl(v_from_date,SYSDATE)) BETWEEN v_old_from_date AND v_old_to_date ) THEN
         -- get old data from general_dtl table
         SELECT tariff_rcvd_date,hosp_info_rcvd_date,hosp_verify_form_rcvd_date,reg_crt_rcvd_date
           INTO v_old_tariff_rcvd_date,v_old_hosp_info_rcvd_date,v_old_hosp_form_rcvd_date,v_old_reg_crt_rcvd_date
           FROM tpa_hosp_general_dtl
          WHERE empanel_seq_id = v_empanel_seq_id;

         INSERT INTO tpa_hosp_empanel_status (empanel_seq_id,Hosp_seq_id,empanel_status_type_id,
                     empanel_rson_type_id,notified_to_tpa_acc,date_of_notification,
                     remarks,active_yn,added_by,added_date)
              VALUES (tpa_hosp_empanel_status_seq.NEXTVAL,v_hosp_seq_id,v_empanel_status_type_id,
                     v_empanel_rson_type_id,v_notified_to_tpa_acc,v_date_of_notification,
                     v_remarks,'Y', v_user_id,SYSDATE)
           RETURNING empanel_seq_id INTO v_new_empanel_seq_id;

         --change old rows to inactive for given hospital
         UPDATE tpa_hosp_empanel_status
           SET active_yn            = 'N',
               updated_by           = v_user_id,
               updated_date         = SYSDATE
         WHERE empanel_seq_id = v_empanel_seq_id;

         INSERT INTO tpa_hosp_bank_guarantee(bank_guant_seq_id,empanel_seq_id,added_by,added_date)
            VALUES (tpa_hosp_bank_guarantee_seq.NEXTVAL,v_new_empanel_seq_id,v_user_id,SYSDATE);

         -- new record for renewed empanelment of Hospital in general_dtl table
         INSERT INTO tpa_hosp_general_dtl ( hosp_gnrl_seq_id,empanel_seq_id,hosp_seq_id,
                                            tariff_rcvd_date,hosp_info_rcvd_date,hosp_verify_form_rcvd_date,
                                            reg_crt_rcvd_date,added_by,added_date)
           VALUES ( tpa_hosp_general_dtl_seq.NEXTVAL,v_new_empanel_seq_id,v_hosp_seq_id,
                    v_old_tariff_rcvd_date,v_old_hosp_info_rcvd_date,v_old_hosp_form_rcvd_date,
                    v_old_reg_crt_rcvd_date,v_user_id,SYSDATE);
       ELSE
         RAISE_APPLICATION_ERROR(-20007, 'Empanelment Cannot be renewed after empanelment period ');
       END IF;

    ELSE
       --Empanelment
       IF ( v_empanel_status_type_id = 'EMP' ) AND ( v_old_empanel_status_type IN('EMP','INP','REN','DIS')) THEN
         IF ( trunc(nvl(v_from_date,SYSDATE)) >= v_tpa_regist_date ) THEN

           --to check for contacts exist or not
           SELECT COUNT(1) INTO v_count FROM tpa_user_contacts WHERE hosp_seq_id = v_hosp_seq_id AND designation_type_id ='CRP';
           IF ( v_count = 0 ) THEN
              RAISE_APPLICATION_ERROR(-20002, 'Please add a contact information before empaneling');
           END IF;

           ---------------------------------------------------------------------
           --to check for validation
           SELECT COUNT(1) INTO v_count FROM tpa_hosp_validation WHERE hosp_seq_id = v_hosp_seq_id;
           IF ( v_count > 0 ) THEN
             SELECT validation_req_yn,val_status_general_type_id
               INTO v_validation_req_yn,v_validation_status
               FROM (SELECT validation_req_yn,val_status_general_type_id
                       FROM tpa_hosp_validation
                       WHERE hosp_seq_id = v_hosp_seq_id ORDER BY validate_SEQ_ID DESC) A
               WHERE ROWNUM = 1;

             IF ( v_validation_req_yn = 'Y' ) AND ( v_validation_status ='STE' ) THEN    --is stop empanelment
               RAISE_APPLICATION_ERROR(-20004, 'Hospital cannot be empanelled due to validation reasons performed during validation process.');
             END IF;

           END IF;
           ---------------------------------------------------------------------
           --to check for Pay Order amount paid or not ( from account screen )
           SELECT empanel_fees_chrg_yn, pay_order_received_date,signed_date
             INTO v_empanel_fees_chrg_yn, v_pay_order_received_date,v_signed_date
             FROM tpa_hosp_general_dtl
            WHERE empanel_seq_id = v_empanel_seq_id ;

           IF ( v_empanel_fees_chrg_yn = 'Y' ) AND ( v_pay_order_received_date IS NULL ) THEN
              RAISE_APPLICATION_ERROR(-20006, 'Pay Order Amount is not paid');
           END IF;

          /* IF ( v_signed_date IS NULL ) THEN
              RAISE_APPLICATION_ERROR(-20014, 'MOU signed date is required');
           END IF;*/
         ---commented for mou is not mandatory in general
           ----------------------------------------------------------------------
           --check for account details
           SELECT COUNT(1) INTO v_count FROM tpa_hosp_account_details WHERE hosp_seq_id = v_hosp_seq_id;
           IF v_count = 0 THEN
             RAISE_APPLICATION_ERROR(-20015, 'Hospital account details required');
           END IF;
           SELECT nvl(d.review_yn,'N') INTO v_review_yn FROM tpa_hosp_account_details d WHERE hosp_seq_id = v_hosp_seq_id;
           IF ( v_count = 0 ) THEN
              RAISE_APPLICATION_ERROR(-20015, 'Hospital account details required');
           END IF;
           IF ( v_review_yn = 'N' ) THEN
              RAISE_APPLICATION_ERROR(-20995, 'Hospital account details should be reviewed by Finance department before Empaneling');
           END IF;
           

           ----------------------------------------------------------------------
           --to generate empanel_number
           v_empanel_number := NULL;
           SELECT empanel_number INTO v_empanel_number FROM tpa_hosp_info WHERE hosp_seq_id = v_hosp_seq_id;
           IF ( v_empanel_number IS NULL) THEN
              -- Call the procedure
              PR_GENERATE_EMPANEL_NUMBER ( v_hosp_seq_id, v_empanel_number);
              UPDATE tpa_hosp_info
                SET empanel_number = v_empanel_number
              WHERE hosp_seq_id = v_hosp_seq_id ;
           END IF;
          ---------------------------------------------------------------------
         ELSE
           RAISE_APPLICATION_ERROR(-20008, ' Hospital cannot be empanelled before TPA Registration Date '||to_char(v_tpa_regist_date));
         END IF;
         -- Generating XML when the hospital is empanelled.
         ------------------------------------------------------- TODO
--         dms_interface_pkg.hospital_xml_gen(v_hosp_seq_id,v_hosp_name, v_tpa_ref_number, v_empanel_number ,'I');
         -------------------------------------------------------

       ELSIF (( v_old_empanel_status_type = 'EMP' ) AND ( v_empanel_status_type_id NOT IN ('EMP','DFC','DEM','DNC','DPW','DOR','TDE','TDO','EXP'))) OR
             (( v_old_empanel_status_type = 'INP' ) AND ( v_empanel_status_type_id NOT IN ('INP','EMP','ONH'))) OR
             (( v_old_empanel_status_type = 'ONH' ) AND ( v_empanel_status_type_id NOT IN ('ONH','INP'))) OR
             (( v_old_empanel_status_type IN('DFC','DEM','DNC','DPW','DOR','TDE','TDO')) AND ( v_empanel_status_type_id NOT IN ('DFC','DEM','DNC','DPW','DOR','TDE','TDO','EMP'))) OR
             (( v_old_empanel_status_type ='EXP') AND (v_empanel_status_type_id IN('EMP','DFC','TDE','ONH','EXP','INP','DEM','DNC','DPW','DOR','TDO'))) THEN


             --get description
               SELECT Empanel_description INTO v_empanel_description
                 FROM tpa_hosp_empanel_status_code
                WHERE empanel_status_type_id = v_old_empanel_status_type;
                  RAISE_APPLICATION_ERROR(-20005, ' Hospital cannot get this status for '||v_empanel_description);
       ELSIF (( v_old_empanel_status_type = 'EMP') AND ( v_empanel_status_type_id IN ('DFC','DEM','DNC','DPW','DOR','TDE','TDO'))   --Disempanelment
          AND (trunc(nvl(v_from_date,SYSDATE)) NOT BETWEEN v_old_from_date AND v_old_to_date)) THEN
               RAISE_APPLICATION_ERROR(-20009, ' Hospital cannot be Disempanelled after the empanel period ');
      ELSIF (( v_old_empanel_status_type  = 'EMP' ) AND (v_empanel_status_type_id = 'EXP')      --Empanelment expiry
          AND (trunc(nvl(v_from_date,SYSDATE)) BETWEEN v_old_from_date AND v_old_to_date)) THEN
               RAISE_APPLICATION_ERROR(-20010, ' Empanelment cannot be expired within the empanel period ');
      /* ELSIF (( v_old_empanel_status_type  = 'INP'  AND  v_empanel_status_type_id = 'CLS') OR
              ( v_old_empanel_status_type  = 'CLS'  AND  v_empanel_status_type_id = 'CLS'))
              AND (trunc(nvl(v_from_date,SYSDATE)) < v_tpa_regist_date) THEN
                RAISE_APPLICATION_ERROR(-20013, ' Closed date should be greater than registration date ');
*/
       END IF;

       UPDATE tpa_hosp_empanel_status
          SET empanel_status_type_id          = v_empanel_status_type_id,
              empanel_rson_type_id            = v_empanel_rson_type_id,
              from_date                       = trunc(v_from_date),
              to_date                         = trunc(v_to_date),
              notified_to_tpa_acc             = v_notified_to_tpa_acc,
              date_of_notification            = v_date_of_notification,
              remarks                         = v_remarks,
              updated_by                      = v_user_id,
              updated_date                    = SYSDATE
        WHERE hosp_seq_id    = v_hosp_seq_id
          AND empanel_seq_id = v_empanel_seq_id;
    END IF;

    v_rows_processed  := sql%rowcount;

    --for log screen
    IF ( v_old_empanel_status_type != v_empanel_status_type_id ) OR
         ( v_old_empanel_rson_type != v_empanel_rson_type_id ) OR
         ( v_old_from_date != v_from_date ) OR ( v_old_to_date != v_to_date ) THEN
           --check for empanel_status_type changes
           IF ( v_old_empanel_status_type != v_empanel_status_type_id ) THEN
             --get descripton for id
             SELECT empanel_description INTO v_empanel_description FROM tpa_hosp_empanel_status_code WHERE empanel_status_type_id = v_empanel_status_type_id ;
             --get old descripton for id
             SELECT empanel_description INTO v_old_empanel_description FROM tpa_hosp_empanel_status_code WHERE empanel_status_type_id = v_old_empanel_status_type;
             --concatenate the remarks column
             ttk_util_pkg.pr_log_concat(' Status ', v_old_empanel_description,v_empanel_description,v_remarks_empanel_status_type);
           END IF;

           --check for empanel_rson_type changes
           IF ( v_old_empanel_rson_type != v_empanel_rson_type_id ) THEN
             --get reason descripton for id
             SELECT rson_description INTO v_rson_description FROM tpa_hosp_empanel_rson_code WHERE empanel_rson_type_id = v_empanel_rson_type_id;
             --get old reason descripton for id
             SELECT rson_description INTO v_old_rson_description FROM tpa_hosp_empanel_rson_code WHERE empanel_rson_type_id = v_old_empanel_rson_type;

             ttk_util_pkg.pr_log_concat (' Reason Descripton ',v_old_rson_description,v_rson_description,v_remarks_empanel_rson_type);
           END IF;

           --check for from_date changes
           IF ( v_old_from_date != v_from_date ) THEN
             ttk_util_pkg.pr_log_concat (' From Date ',v_old_from_date,v_from_date,v_remarks_from_date);
           END IF;

           --check for to_date changes
           IF ( v_old_to_date != v_to_date ) THEN
             ttk_util_pkg.pr_log_concat (' To Date ',v_old_to_date,v_to_date,v_remarks_to_date);
           END IF;
           --assign concatenated information of changed column to another variable.
           v_remarks_concat := ' Reference Date   : '||to_char(SYSDATE,'dd/mm/yyyy')||CHR(10)||
                               ' For : '||v_screen_name||CHR(10)||
                               v_remarks_empanel_status_type||CHR(10)||
                               v_remarks_empanel_rson_type||CHR(10)||
                               v_remarks_from_date||CHR(10)||
                               v_remarks_to_date||CHR(10)||
                               ' Remarks   : '||V_Remarks;
           -- insert into log table
           ttk_util_pkg.pr_user_log (v_log_seq_id , v_hosp_seq_id, v_system_gen_yn, v_log_type_id ,
                                      v_mod_reason_type_id, v_reference_date,
                                      v_reference_no, v_remarks_concat, v_user_id, v_rows_processed);
         END IF;

    -- add details to history table
    IF ( v_old_empanel_status_type = 'EMP' ) AND ( v_empanel_status_type_id = 'DIS' ) THEN
      UPDATE tpa_hosp_empanel_history
         SET to_date = trunc(v_from_date)
       WHERE empanel_seq_id = v_empanel_seq_id;
    ELSIF ( v_empanel_status_type_id = 'EMP' ) THEN
      INSERT INTO tpa_hosp_empanel_history (empanel_history_seq_id,empanel_seq_id,empanel_status_type_id,
                  from_date,to_date,added_by,added_date)
           VALUES ( tpa_hosp_empanel_history_seq.NEXTVAL,v_empanel_seq_id,v_empanel_status_type_id,
                  trunc(v_from_date),trunc(v_to_date),v_user_id,SYSDATE);
    END IF;
    
    --Call Generate Mail Pkg
    for i in (select uc.contact_seq_id
      from tpa_user_contacts uc, tpa_designation_code td
      where uc.designation_type_id = td.designation_type_id
      and uc.hosp_seq_id = v_hosp_seq_id
      and nvl(empnl_mail_trigr_yn,'N') = 'N') loop
        
        generate_mail_pkg.proc_generate_message('PROVIDER_USER_ID', i.contact_seq_id, v_user_id, v_dest_msg_seq_id);
        
        UPDATE app.tpa_user_contacts c
          SET c.empnl_mail_trigr_yn = CASE WHEN v_dest_msg_seq_id IS NOT NULL THEN 'Y' ELSE NULL END
        WHERE c.contact_seq_id = i.contact_seq_id;
          
    end loop;

   COMMIT;
 END pr_hospital_status_save;

--=====================================================================================================
  -- to know whether DISCREPANCY check is done
  -- If done, whether DISCREPANCY check is required or not.
  -- If this procedure returns "Y", means, discrepancy check is required.
--=====================================================================================================
  PROCEDURE pr_discrepancy_status (
    v_hosp_seq_id                      IN tpa_hosp_empanel_status.hosp_seq_id%TYPE,
    v_disc_present_yn                  OUT VARCHAR2
  )
 IS
 BEGIN
   SELECT decode( COUNT(1), 0, 'N', 'Y' )   -- NVL( disc_present_yn, 'N')
     INTO v_disc_present_yn
     FROM tpa_hosp_discrepancy
    WHERE hosp_seq_id = v_hosp_seq_id
      AND nvl( disc_present_yn, 'N') = 'Y'
      AND disc_action_taken IS NULL;
 END;

--=====================================================================================================
  -- for the screen GRADING GENERAL SAVE
  -- written by mamatha
--=====================================================================================================
  PROCEDURE pr_grading_general_save(
    v_hosp_seq_id                      IN tpa_hosp_grading.hosp_seq_id%TYPE,
    v_location_type_id                 IN tpa_hosp_grading.location_type_id%TYPE,
    v_category_type_id                 IN tpa_hosp_grading.category_type_id%TYPE,
    v_user_id                          IN  NUMBER,
    v_rows_processed                   OUT  NUMBER
  )
  IS
    v_cnt NUMBER;
  BEGIN
    --check for hospital exists or not in grading
    SELECT count(1) INTO v_cnt FROM tpa_hosp_grading WHERE hosp_seq_id=v_hosp_seq_id;

    -- add general details of grading
    IF ( v_cnt = 0 ) THEN
      INSERT INTO tpa_hosp_grading(hosp_seq_id,location_type_id,category_type_id,added_by,added_date)
           VALUES (v_hosp_seq_id,v_location_type_id,v_category_type_id,v_user_id,SYSDATE) ;
    ELSE
      -- save modified general details of grading
      UPDATE tpa_hosp_grading
         SET location_type_id              = v_location_type_id,
             category_type_id              = v_category_type_id,
             updated_by                    = v_user_id,
             updated_date                  = SYSDATE
       WHERE hosp_seq_id     = v_hosp_seq_id;
    END IF;

      v_rows_processed :=sql%ROWCOUNT;
    COMMIT;
  END pr_grading_general_save;

--=====================================================================================================
  -- to save GRADING MEDICAL SERVICES
  -- written by mamatha
--=====================================================================================================
  PROCEDURE pr_grading_medical_save(
    v_medical_seq_id                   IN tpa_hosp_medical_details.medical_seq_id%TYPE,
    v_hosp_seq_id                      IN tpa_hosp_medical_details.hosp_seq_id%TYPE,
    v_medical_type_id                  IN tpa_hosp_medical_details.medical_type_id%TYPE,
    v_value1                           IN tpa_hosp_medical_details.value_1%TYPE,
    v_value2                           IN tpa_hosp_medical_details.value_2%TYPE,
    v_user_id                          IN NUMBER
  )
  IS
  BEGIN
    -- add medical details for grading
    IF ( v_medical_seq_id = 0 ) THEN
      INSERT INTO tpa_hosp_medical_details (medical_seq_id,hosp_seq_id,medical_type_id,
                  value_1,value_2,added_by,added_date)
           VALUES (tpa_hosp_medical_details_seq.NEXTVAL,v_hosp_seq_id,v_medical_type_id,
                  v_value1,v_value2,v_user_id,SYSDATE);
    ELSE
      -- save modified medical details for grading
      UPDATE tpa_hosp_medical_details
         SET hosp_seq_id                   = v_hosp_seq_id,
             medical_type_id               = v_medical_type_id,
             value_1                       = v_value1,
             value_2                       = v_value2,
             updated_by                    = v_user_id,
             updated_date                  = SYSDATE
       WHERE MEDICAL_SEQ_ID     = v_Medical_Seq_Id;

    END IF;
  END PR_GRADING_MEDICAL_SAVE;

--=====================================================================================================
  -- save/update infrastru for hospital
  -- written by mamatha
--=====================================================================================================
  PROCEDURE pr_grading_infrastr_save(
    v_infrastr_seq_id                  IN tpa_hosp_infrastr_info.infrastr_seq_id%TYPE,
    v_hosp_seq_id                      IN tpa_hosp_infrastr_info.hosp_seq_id%TYPE,
    v_whole_premises_yn                IN tpa_hosp_infrastr_info.whole_premises_yn%TYPE,
    v_other_occupants                  IN tpa_hosp_infrastr_info.other_occupants%TYPE,
    v_floor_details                    IN tpa_hosp_infrastr_info.floor_details%TYPE,
    v_built_up_area                    IN tpa_hosp_infrastr_info.built_up_area%TYPE,
    v_open_area                        IN tpa_hosp_infrastr_info.open_area%TYPE,
    v_cost_of_area                     IN tpa_hosp_infrastr_info.cost_of_area%TYPE,
    v_infra_remarks                    IN tpa_hosp_infrastr_info.infra_remarks%TYPE, --added for issue 306
    v_user_id                          IN NUMBER,
    v_location_type_id                 IN tpa_hosp_grading.location_type_id%TYPE,
    v_category_type_id                 IN tpa_hosp_grading.category_type_id%TYPE, 
    v_rows_processed                   OUT NUMBER
  )
  IS
  BEGIN
    pr_grading_general_save(v_hosp_seq_id,v_location_type_id,v_category_type_id,v_user_id,v_rows_processed);
    -- add infrastructure details for grading the hospital
      IF ( v_infrastr_seq_id = 0 ) THEN
      INSERT INTO tpa_hosp_infrastr_info(infrastr_seq_id,hosp_seq_id,whole_premises_yn,
                  other_occupants,floor_details,built_up_area,open_area,
                  cost_of_area,infra_remarks,added_by,added_date)
           VALUES (tpa_hosp_infrastr_seq.NEXTVAL,v_hosp_seq_id,v_whole_premises_yn,
                  v_other_occupants,v_floor_details,v_built_up_area,v_open_area,
                  v_cost_of_area,v_infra_remarks,v_user_id,SYSDATE);
                  
    ELSE
      -- save the modified infrastructure details for grading the hospital
      UPDATE tpa_hosp_infrastr_info
         SET hosp_seq_id                   = v_hosp_seq_id,
             whole_premises_yn             = v_whole_premises_yn,
             other_occupants               = v_other_occupants,
             floor_details                 = v_floor_details,
             built_up_area                 = v_built_up_area,
             open_area                     = v_open_area,
             cost_of_area                  = v_cost_of_area,
             infra_remarks                 = v_infra_remarks,
             updated_by                    = v_user_id,
             updated_date                  = SYSDATE
       WHERE infrastr_seq_id     = v_infrastr_seq_id;
    END IF;
      v_rows_processed :=sql%ROWCOUNT;
    COMMIT;
  END pr_grading_infrastr_save;

--=====================================================================================================
  -- save/update overriding for hospital
  -- written by mamatha
--=====================================================================================================
  PROCEDURE pr_grading_overriding_save(
    v_hosp_seq_id                      IN tpa_hosp_grading.hosp_seq_id%TYPE,
    v_grade_type_id                    IN tpa_hosp_grading.grade_type_id%TYPE,
    v_approved_by                      IN tpa_hosp_grading.approved_by%TYPE,
    v_approved_grade_type_id           IN tpa_hosp_grading.approved_grade_type_id%TYPE,
    v_remarks                          IN tpa_hosp_grading.remarks%TYPE,
    v_user_id                          IN NUMBER,
    v_rows_processed                   OUT NUMBER
  )
  IS
    v_cnt NUMBER;
  BEGIN
    -- to check grading for given hospital is exists or not
    SELECT count(1) INTO v_cnt FROM tpa_hosp_grading WHERE hosp_seq_id = v_hosp_seq_id;

      -- grading is not present then add
      IF v_cnt=0 THEN
        INSERT INTO tpa_hosp_grading(hosp_seq_id,grade_type_id,approved_by,
                    approved_grade_type_id,approved_date,remarks,
                    added_by,added_date)
             VALUES (v_hosp_seq_id,v_grade_type_id,v_approved_by,
                    v_approved_grade_type_id,trunc(SYSDATE),v_remarks,
                    v_user_id,SYSDATE);
      ELSE
        -- save modified details of grading
        IF ( v_approved_by IS NULL ) THEN
          UPDATE tpa_hosp_grading                    --update for other users
             SET grade_type_id                 = v_grade_type_id,
                 remarks                       = v_remarks,
                 updated_by                    = v_user_id,
                 updated_date                  = SYSDATE
           WHERE hosp_seq_id = v_hosp_seq_id;
        ELSE
          UPDATE tpa_hosp_grading                     --update for admin user
             SET approved_by                   = v_approved_by,
                 approved_grade_type_id        = v_approved_grade_type_id,
                 approved_date                 = trunc(SYSDATE),
                 remarks                       = v_remarks,
                 updated_by                    = v_approved_by,
                 updated_date                  = SYSDATE
           WHERE hosp_seq_id = v_hosp_seq_id;
        END IF;
      END IF;

      v_rows_processed :=sql%ROWCOUNT;
    COMMIT;
  END pr_grading_overriding_save;

--=====================================================================================================
  -- for the screen GRADING HOSPITAL SAVE
  -- written by mamatha
--=====================================================================================================
  PROCEDURE pr_grading_hospital_save(
    v_hosp_seq_id                      IN tpa_hosp_grading.hosp_seq_id%TYPE,
    v_user_id                          IN NUMBER,
    v_rows_processed                   OUT NUMBER
  )
  IS
    v_cnt NUMBER;
  BEGIN

  -- check for the given hospital is exists for grading or not
  SELECT count(1) INTO v_cnt FROM tpa_hosp_grading WHERE hosp_seq_id = v_hosp_seq_id;

    -- hospital not exists in grading then add
    IF v_cnt=0 THEN
      INSERT INTO tpa_hosp_grading(hosp_seq_id,process_grading_yn,added_by,added_date)
           VALUES (v_hosp_seq_id,'Y',v_user_id,SYSDATE);
    ELSE
      -- save the modified details of grading
      UPDATE tpa_hosp_grading
         SET process_grading_yn            = 'Y',
             updated_by                    = v_user_id,
             updated_date                  = SYSDATE
       WHERE hosp_seq_id = v_hosp_seq_id;
    END IF;

      v_rows_processed :=sql%ROWCOUNT;
    COMMIT;
  END PR_GRADING_HOSPITAL_SAVE;

--=====================================================================================================
  -- to generate empanel number for hospital
--=====================================================================================================
  PROCEDURE pr_generate_empanel_number(
    v_hosp_seq_id                      IN tpa_hosp_info.hosp_seq_id%TYPE,
    v_empanelment_number               OUT tpa_hosp_info.empanel_number%TYPE
  )
  IS
    v_hosp_abbrevation_code            VARCHAR2( 10 );
    v_capital_code                     VARCHAR2( 10 );
    v_COUNTRY_SHORT                    VARCHAR2(5);--INTX
    v_tpa_hosp_empanel_number          NUMBER;

  BEGIN
    SELECT --tpa_hosp_code.hosp_abbrevation_code,
           dha_provider_type.provider_type_id,
           tpa_state_code.state_type_id,---changed capital to state for dha purpose
           TPA_COUNTRY_CODE.SHORT_NAME
      INTO v_hosp_abbrevation_code,
           v_capital_code,
           v_COUNTRY_SHORT
      FROM tpa_hosp_address,
           tpa_hosp_info,
           tpa_state_code,
           dha_provider_type,--tpa_hosp_code,
           TPA_COUNTRY_CODE
      WHERE ( tpa_hosp_info.hosp_seq_id         = tpa_hosp_address.hosp_seq_id )
        AND ( tpa_state_code.state_type_id      = tpa_hosp_address.state_type_id )
        AND ( dha_provider_type.provider_type_id = tpa_hosp_info.provider_type_id )
        AND ( tpa_hosp_address.country_id                  = tpa_country_code.country_id)
        AND ( tpa_hosp_address.hosp_seq_id      = v_hosp_seq_id )
        AND ( tpa_hosp_address.hosp_bank_seq_id    IS NULL )
        AND ( tpa_hosp_address.hosp_gnrl_seq_id    IS NULL )  ;

    UPDATE TPA_SYSTEM_PARAMETERS a SET a.last_hosp_empanel_number = a.last_hosp_empanel_number + 1
       RETURNING a.last_hosp_empanel_number INTO v_tpa_hosp_empanel_number;

    v_empanelment_number := v_COUNTRY_SHORT|| '-' || v_capital_code || '-' ||v_hosp_abbrevation_code|| '-' ||
                            TRIM(to_char(v_tpa_hosp_empanel_number,'0999'));  -- format changed to 4 digits as per CR KOC808

  END PR_GENERATE_EMPANEL_NUMBER;
---------------------------------------------------------------------------------------------
-- Procedure to find out the value for Medical_type_id 'TQN', 'TFD','TNB'.
-- Author : S V Sreeraj
-- Internal procedure called from HOSP_GRADE_CALCULATION
---------------------------------------------------------------------------------------------
  PROCEDURE find_grade_value
  (
     v_val_2            IN NUMBER,                         --  Either Number of Beds or RATIO(Dr : Beds or Nurses : Beds)
     v_para_val_1       IN tpa_hosp_grade_param.value_1%TYPE,  --  TPA_HOSP_GRADE_PARAM value_1(For TNB )OR value_2 (For TFD &TQN)
     v_para_val_2       IN tpa_hosp_grade_param.value_2%TYPE,  --  TPA_HOSP_GRADE_PARAM value_2(For TNB )OR value_3 (For TFD &TQN)
     v_point            OUT NUMBER,                        --  To store the Points of the Parameter.
     v_allocated_points IN tpa_hosp_grade_param.allocated_points%TYPE, -- Prameter Point from Master Tabe.
     v_get              OUT BOOLEAN                             -- Flag
  ) IS
  BEGIN
    v_point := 0;
    v_get   := FALSE;
    IF v_val_2 >= v_para_val_1 AND v_val_2 <= nvl(v_para_val_2,v_val_2+1) THEN
      v_point := v_allocated_points;
      v_get := TRUE;
    END IF;
  END find_grade_value;
---------------------------------------------------------------------------------------------
    -- Name            : HOSP_GRADE_CALCULATION
    -- Project         : TTK
    -- Author          : S.V.SREERAJ
    -- Date Created    : 12/11/2005
    -- Purpose         : This Procedure will Calculate the GRADE of Hospital
---------------------------------------------------------------------------------------------
  PROCEDURE hosp_grade_calculation
  (
   v_hosp_seq_id          IN  tpa_hosp_grading.hosp_seq_id%TYPE,
   v_grade                OUT tpa_hosp_grade_code.grade_type_id%TYPE
  )
  IS

----------------------------------------------------------------------------------------------------------
--  Cursor to Store the rows grade parameter values (From TPA_HOSP_MEDICAL_DETAILS) and
--  Their grade points (From TPA_HOSP_PARAM) corresponding to The Hospital.
----------------------------------------------------------------------------------------------------------
    v_accredition_flag     CHAR(1) := 'N';
    CURSOR medical_details_cursor IS
      SELECT p.medical_type_id,
           p.value_1 para_val_1,
           p.value_2 para_val_2,
           p.value_3 para_val_3,
           p.allocated_points,
           d.value_1 det_val_1,
           d.value_2 det_val_2
      FROM   tpa_hosp_medical_details d,
             tpa_hosp_grade_param p
      WHERE  p.medical_type_id = d.medical_type_id AND
           d.hosp_seq_id = v_hosp_seq_id
      ORDER BY p.medical_type_id,para_val_1 DESC,para_val_2 DESC;
----------------------------------------------------------------------------------------------------------
-- Cursor for getting the grade From TPA_HOSP_GRADE_CODE.
----------------------------------------------------------------------------------------------------------
    CURSOR grade_code_cursor(v_cur_sum_points NUMBER) IS
      SELECT grade_type_id FROM tpa_hosp_grade_code
      WHERE v_cur_sum_points BETWEEN from_points and NVL(to_points,v_cur_sum_points+1);
----------------------------------------------------------------------
-- Cursor To Get the NUMBER OF BEDS to Calculate the Ratio NURSES:BEDS & DOCTORS:BEDS.
----------------------------------------------------------------------
    CURSOR get_bed_cursor (v_hosp_id tpa_hosp_grading.hosp_seq_id%TYPE,v_med_type_id tpa_hosp_medical_details.medical_type_id%TYPE )IS
      SELECT  value_1
        FROM  tpa_hosp_medical_details
        WHERE hosp_seq_id = v_hosp_id and medical_type_id = v_med_type_id;
----------------------------------------------------------------------------------------------------------
-- Cursor To Get the ALLOCATED POINTS of CATEGORY_TYPE_ID
----------------------------------------------------------------------------------------------------------
    CURSOR get_category_type_id_cursor(p_category_type_id  tpa_hosp_grading.category_type_id%TYPE) IS
      SELECT  allocated_points
        FROM  tpa_hosp_grade_param
        WHERE category_type_id = p_category_type_id;
----------------------------------------------------------------------------------------------------------
-- Cursor To Get the ALLOCATED POINTS of LOCATION_TYPE_ID
----------------------------------------------------------------------------------------------------------
    CURSOR get_location_type_id_cursor(p_location_type_id  tpa_hosp_grading.location_type_id%TYPE) IS
      SELECT  allocated_points
        FROM  tpa_hosp_grade_param
        WHERE location_type_id = p_location_type_id;
----------------------------------------------------------------------------------------------------------
-- Cursor To Get the LOCATION_TYPE_ID & CATEGORY_TYPE_ID of the HOSPITAL
----------------------------------------------------------------------------------------------------------
    CURSOR get_category_location_cursor(p_hosp_seq_id tpa_hosp_grading.hosp_seq_id%TYPE) IS
    SELECT  location_type_id, category_type_id
      FROM  tpa_hosp_grading
      WHERE hosp_seq_id = p_hosp_seq_id;

    v_medical_rec medical_details_cursor%ROWTYPE;      -- For Cursor medical_details_cursor
    v_grading_rec get_category_location_cursor%ROWTYPE;-- For Storing LOCATION_TYPE_ID & CETEGORY_TYPE_ID
    v_point  NUMBER  := 0;                             -- Calculated pointed for one Grading Parameter.
    v_val_1  NUMBER  := 0;                             -- VALUE_1 column value From  TPA_HOSP_MEDICAL_DETAILS
    v_val_2  NUMBER  := 0;                             -- VALUE_2 column value From  TPA_HOSP_MEDICAL_DETAILS
    v_get    BOOLEAN := FALSE;                         -- Flag to Multiple Rows of medical_details_cursor
                                                     -- for the same MEDICAL_TYPE_ID.
    v_sum_points  NUMBER := 0;
    v_med_id tpa_hosp_medical_details.medical_type_id%TYPE;  -- Used to store the previous rows MEDICAL_TYPE_ID.
    v_num_beds get_bed_cursor%ROWTYPE;    -- Storing the Number of Beds For Calculationg the Ratio.

  BEGIN
  -- Initialization
    v_sum_points:= 0;
    v_val_1 := 0;
    v_val_2 := 0;
    -- Getting the LOCATION_TYPE_ID & CTEGORY_TYPE_ID from TPA_HOSP_GRADING.
    OPEN get_category_location_cursor(v_hosp_seq_id);
    FETCH get_category_location_cursor INTO v_grading_rec;
    CLOSE get_category_location_cursor;
    -- Commented for Qatar--------------------
    /*IF v_grading_rec.location_type_id IS NULL OR v_grading_rec.category_type_id IS NULL THEN
      RAISE_APPLICATION_ERROR(-20011,'Hospital Category or Location Column Not Entered');
    END IF;*/

    -- Getting the ALLOCATED_POINTS corresponding to LOCATION_TYPE_ID.

    OPEN get_location_type_id_cursor(v_grading_rec.location_type_id);
    FETCH get_location_type_id_cursor INTO v_point;
    CLOSE get_location_type_id_cursor;
    v_sum_points := v_sum_points + v_point;

    -- Getting the ALLOCATED_POINTS corresponding to CTEGORY_TYPE_ID.
    OPEN get_category_type_id_cursor(v_grading_rec.category_type_id);
    FETCH get_category_type_id_cursor INTO v_point;
    CLOSE get_category_type_id_cursor;
    v_sum_points := v_sum_points + v_point;

    -- Finding out the NUMBER OF BEDS for the Specified Hospital.
    OPEN get_bed_cursor(v_hosp_seq_id,'TNB');
    FETCH get_bed_cursor into v_num_beds;   --  Finds out the Number of Beds in The Hospital for RATIO Calculation.
    CLOSE get_bed_cursor;
    -- LOOP for Processing all Grading Parameters (in TPA_HOSP_MEDICAL_DETAILS) for the Specified Hospital.
    OPEN medical_details_cursor;
    LOOP
      IF NOT v_get THEN
        FETCH medical_details_cursor
          INTO v_medical_rec;
      END IF;
      EXIT WHEN medical_details_cursor%NOTFOUND OR medical_details_cursor%NOTFOUND IS NULL;
      v_get    := FALSE;
      v_point  := 0;
      v_med_id := v_medical_rec.medical_type_id;
      IF v_medical_rec.det_val_1 IS NOT NULL OR v_medical_rec.det_val_2 IS NOT NULL THEN
        IF UPPER(v_medical_rec.det_val_1) = 'Y' THEN
           IF v_medical_rec.medical_type_id IN ('IQR','CRI','ISO')  THEN
              IF v_accredition_flag = 'N' THEN
                v_point := v_medical_rec.allocated_points;
                v_accredition_flag := 'Y';
              END IF;
           ELSE
             v_point := v_medical_rec.allocated_points;           -- For Simple Parameters (Check Box Inputs).
           END IF;
        ELSIF UPPER(v_medical_rec.det_val_1) != 'N' THEN       -- Make Sure Value Entered is Number.
          v_val_1 := to_number(nvl(v_medical_rec.det_val_1,'0'));
          v_val_2 := to_number(nvl(v_medical_rec.det_val_2,'0'));
          IF v_val_1 > 0 THEN                                  -- For Valid Numerical Prameters.
            IF v_medical_rec.medical_type_id IN('TQN','TFD','TNB') THEN
              -- Find out the RATIO outside the LOOP.
              IF v_medical_rec.medical_type_id = 'TQN' OR v_medical_rec.medical_type_id = 'TFD' THEN
                v_val_2 := to_number(NVL(v_num_beds.value_1,'0')); -- Number of beds in that Hospital.
                IF v_val_2 != 0 THEN
                  IF v_val_1 > v_val_2 THEN  -- IF number of Doctors > Number of Beds Then the RATIO is 1:1
                    v_val_1 := 1;
                    v_val_2 := 1;
                  ELSE
                    v_val_2 := ROUND(v_val_2/v_val_1);               -- The Ratio.
                  END IF;
                ELSE
                  v_get := TRUE;
                END IF;
              END IF;
              -------------------------------------------------------------------------------------------------------------------
              -- This loop is to get the value from the cursor for the particular parameter
              -- according to the values in value_1,value_2,value_3 from the Prameter Maaster Table and skip
              -- other rows having the same MEDICAL_TYPE_ID values.
              -------------------------------------------------------------------------------------------------------------------
              WHILE v_medical_rec.medical_type_id = v_med_id AND medical_details_cursor%FOUND
              LOOP
                IF NOT v_get THEN  -- SKIP checking after the point obtained.
                  IF v_medical_rec.medical_type_id = 'TQN' OR v_medical_rec.medical_type_id = 'TFD' THEN
                    -- Finding out the value according to the RATIO using Procedure find_value().
                    find_grade_value(v_val_2,v_medical_rec.para_val_2,v_medical_rec.para_val_3,v_point,v_medical_rec.allocated_points,v_get);
                  ELSIF v_medical_rec.medical_type_id = 'TNB' THEN
                    find_grade_value(v_val_1,v_medical_rec.para_val_1,v_medical_rec.para_val_2,v_point,v_medical_rec.allocated_points,v_get);
                  END IF;
                END IF;
                FETCH medical_details_cursor INTO v_medical_rec;
              END LOOP;
              IF v_med_id IN('TQN','TFD','TNB') THEN
                v_get := TRUE;
              END IF;
            ELSIF v_medical_rec.medical_type_id IN('ICU','ICC','NIC','MAJ','MIN','PHA','ESR','LBR') THEN
              v_point := v_medical_rec.allocated_points * v_val_1;
            ELSE
              v_point := v_medical_rec.allocated_points;
            END IF;
          END IF;
        END IF;
      END IF;
      v_sum_points := v_sum_points + v_point;
   END LOOP;
    CLOSE medical_details_cursor;

    OPEN grade_code_cursor(v_sum_points);
    FETCH grade_code_cursor INTO v_grade;
    CLOSE grade_code_cursor;

    UPDATE tpa_hosp_grading
      SET system_graded_id = v_grade
      WHERE hosp_seq_id = v_hosp_seq_id;
    COMMIT;
  END hosp_grade_calculation;

--=======================================================================================================
-- for testing purpose only
  PROCEDURE show_hosp (
    result_set       OUT SYS_REFCURSOR
  )
  IS
  BEGIN
    OPEN result_set FOR SELECT hosp_seq_id,hosp_name FROM tpa_hosp_info;
  END show_hosp;
 --===========================================
 --for uploading hosp mou docs
 PROCEDURE save_mou_docs_info(v_docs_seq_id    IN MOU_DOCS_INFO.MOU_DOC_SEQ_ID%TYPE,
                              v_hosp_seq_id    IN MOU_DOCS_INFO.hosp_seq_id%TYPE,
                              v_doc_gen_type   IN MOU_DOCS_INFO.DOCS_GENTYPE_ID%TYPE,
                              v_docs_path      IN MOU_DOCS_INFO.docs_PATH%TYPE,
                              v_file_name      IN MOU_DOCS_INFO.FILE_NAME%TYPE,
                              v_added_by       IN MOU_DOCS_INFO.added_by%TYPE,
                              v_image_file     IN MOU_DOCS_INFO.IMAGE_FILE%type,
                              v_rows_processed OUT NUMBER) IS
 BEGIN
   IF v_docs_seq_id = 0 THEN
     INSERT INTO app.MOU_DOCS_INFO
       (MOU_DOC_SEQ_ID,
        hosp_seq_id,
        DOCS_GENTYPE_ID,
        docs_path,
        added_by,
        added_date,
        FILE_NAME,
        IMAGE_FILE)
     VALUES
       (MOU_DOCS_INFO_SEQ.nextval,
        v_hosp_seq_id,
        v_doc_gen_type,
        v_docs_path,
        v_added_by,
        SYSDATE,
        v_file_name,
        v_image_file);
   ELSE
   
     UPDATE MOU_DOCS_INFO a
        SET docs_gentype_id = v_doc_gen_type,
            docs_path       = v_docs_path,
            updated_by      = v_added_by,
            updated_date    = SYSDATE,
            FILE_NAME       = v_file_name,
            IMAGE_FILE      = v_image_file
      WHERE a.mou_doc_seq_id = v_docs_seq_id;
   
   END IF;
   v_rows_processed := SQL%ROWCOUNT;
   COMMIT;
 END save_mou_docs_info;
 -----added fro demo 
 PROCEDURE save_mou_docs_info1(v_docs_seq_id    IN MOU_DOCS_INFO.MOU_DOC_SEQ_ID%TYPE,
                               v_pat_seq_id     IN MOU_DOCS_INFO1.PAT_SEQ_ID%TYPE,
                               v_doc_gen_type   IN MOU_DOCS_INFO.DOCS_GENTYPE_ID%TYPE,
                               v_docs_path      IN MOU_DOCS_INFO.docs_PATH%TYPE,
                               v_file_name      IN MOU_DOCS_INFO.FILE_NAME%TYPE,
                               v_added_by       IN MOU_DOCS_INFO.added_by%TYPE,
                               v_image_file     IN MOU_DOCS_INFO.IMAGE_FILE%type,
                               v_hosp_seq_id     IN MOU_DOCS_INFO1.hosp_seq_id%TYPE,
                               v_rows_processed OUT NUMBER) IS
                               
  
 BEGIN
   
   --IF v_docs_seq_id = 0 THEN
     INSERT INTO app.MOU_DOCS_INFO1
       (MOU_DOC_SEQ_ID,
        PAT_SEQ_ID,
        DOCS_GENTYPE_ID,
        docs_path,
        added_by,
        added_date,
        FILE_NAME,
        IMAGE_FILE,
        hosp_seq_id)
     VALUES
       (MOU_DOCS_INFO_SEQ.nextval,
        v_pat_seq_id,
        v_doc_gen_type,
        v_docs_path,
        v_added_by,
        SYSDATE,
        v_file_name,
        v_image_file,
        v_hosp_seq_id);
   /*ELSE
   
     UPDATE app.MOU_DOCS_INFO1 a
        SET docs_gentype_id = v_doc_gen_type,
            docs_path       = v_docs_path,
            updated_by      = v_added_by,
            updated_date    = SYSDATE,
            FILE_NAME       = v_file_name,
            IMAGE_FILE      = v_image_file,
            PAT_SEQ_ID      = v_pat_seq_id
      WHERE a.mou_doc_seq_id = v_docs_seq_id;
   
   END IF;*/
   v_rows_processed := SQL%ROWCOUNT;
   COMMIT;
 END save_mou_docs_info1;
 
 ----------------------------------------------------------
 
--=========================================================
 /* 
  Procedure  : save_provider_register
  Author     : Mohan RCS Technologies.
  Created On : 23/01/2015
  Description: This procedure saves Provider(hospital) Register details .
*/
--=========================================================
 PROCEDURE save_provider_register (
    v_hosp_seq_id                      IN OUT tpa_hosp_info.hosp_seq_id%TYPE,--0
    v_hosp_gnrl_seq_id                 IN OUT tpa_hosp_general_dtl.hosp_gnrl_seq_id%TYPE,
    v_addr_seq_id                      IN OUT tpa_hosp_address.addr_seq_id%TYPE,--0
    v_discrepancy_status               OUT VARCHAR2,
   -- Provider General Details
    v_hosp_name                        IN tpa_hosp_info.hosp_name%TYPE,
    v_hosp_speciality_type             IN tpa_hosp_info.hosp_type_id%TYPE,
    v_trade_lice_number                IN tpa_hosp_info.trade_licenc_numb%TYPE,
    v_provider_type_id                 IN DHA_PROVIDER_TYPE.PROVIDER_TYPE_ID%TYPE,
    v_regist_authority                 IN tpa_hosp_info.regist_authority%TYPE,
    v_hosp_licence_number              IN tpa_hosp_info.hosp_licenc_numb%TYPE,
    ---------------------
    -- Provider Address details
    v_address_1                        IN tpa_hosp_address.address_1%TYPE,
    v_address_2                        IN tpa_hosp_address.address_2%TYPE,
    v_address_3                        IN tpa_hosp_address.address_3%TYPE,
    v_city_type_id                     IN tpa_hosp_address.city_type_id%TYPE,
    v_state_type_id                    IN tpa_hosp_address.state_type_id%TYPE,
    v_pin_code                         IN tpa_hosp_address.pin_code%TYPE,
    v_country_id                       IN tpa_hosp_address.country_id%TYPE,
    v_isd_code                         IN tpa_hosp_info.isd_code%TYPE,
    v_std_code                         IN tpa_hosp_info.std_code%TYPE,
    v_off_phone_no_1                   IN tpa_hosp_info.off_phone_no_1%TYPE,
    v_off_phone_no_2                   IN tpa_hosp_info.off_phone_no_2%TYPE,
    v_off_fax_no                       IN tpa_hosp_info.office_fax_no%TYPE,
    v_landmarks                        IN tpa_hosp_address.landmarks%TYPE,
    v_hosp_primary_email_id            IN tpa_hosp_info.primary_email_id%TYPE, --/ED
    v_website                          IN tpa_hosp_info.website%TYPE,
    v_user_id                          IN NUMBER,
    v_rows_processed                   OUT NUMBER
  )
  IS
    
    -- for empanel status table
    v_empanel_seq_id           tpa_hosp_empanel_status.empanel_seq_id%TYPE;
    v_hosp_name_upper          tpa_hosp_info.hosp_name%TYPE:=upper(v_hosp_name);
    v_login_user_id            tpa_login_info.user_id%type;
    v_contact_rows_processed   NUMBER(10);
   
  BEGIN
    IF ( v_hosp_seq_id = 0 ) THEN    -- add details to TPA_HOSP_INFO,TPA_HOSP_EMPANEL_STATUS,TPA_HOSP_DISCREPANCY,TPA_HOSP_GENERAL_DTL,TPA_INS_ASSOC_PROD_HOSP,ADDRESS_PKG.PR_HOSPITAL_ADDRESS_SAVE
      INSERT INTO tpa_hosp_info(hosp_seq_id,hosp_type_id,hosp_name,regist_authority,
                  primary_email_id, --/ED
                  website,hosp_licenc_numb,trade_licenc_numb,std_code,off_phone_no_1,
                  off_phone_no_2,office_fax_no,
                  added_by,added_date,provider_type_id,isd_code )
           VALUES (tpa_hosp_sequence.nextval,v_hosp_speciality_type,v_hosp_name_upper,v_regist_authority,
                  ttk_util_pkg.fn_encrypt(v_hosp_primary_email_id),--/ED
                  v_website,v_hosp_licence_number,v_trade_lice_number,v_std_code,v_off_phone_no_1,
                  v_off_phone_no_2,v_off_fax_no,
                  v_user_id,SYSDATE,v_provider_type_id,v_isd_code )
        RETURNING hosp_seq_id INTO v_hosp_seq_id;

      INSERT INTO tpa_hosp_empanel_status (empanel_seq_id,hosp_seq_id,empanel_status_type_id,empanel_rson_type_id,
                  from_date,to_date,notified_to_tpa_acc,date_of_notification,active_yn,added_by,added_date)
           VALUES (tpa_hosp_empanel_status_seq.NEXTVAL,v_hosp_seq_id,'INP','FOL',
                  NULL, NULL, NULL, NULL,'Y', v_user_id, SYSDATE)
        RETURNING empanel_seq_id INTO v_empanel_seq_id;

      INSERT INTO tpa_hosp_bank_guarantee (bank_guant_seq_id,empanel_seq_id,added_by,added_date)
           VALUES (tpa_hosp_bank_guarantee_seq.NEXTVAL,v_empanel_seq_id,v_user_id,SYSDATE);

      INSERT INTO tpa_hosp_general_dtl (hosp_gnrl_seq_id,empanel_seq_id,hosp_seq_id,
                  added_by,added_date)
           VALUES (tpa_hosp_general_dtl_seq.NEXTVAL ,v_empanel_seq_id,v_hosp_seq_id,v_user_id,SYSDATE)
        RETURNING hosp_gnrl_seq_id INTO v_hosp_gnrl_seq_id;

      INSERT INTO tpa_hosp_discrepancy (hosp_seq_id,disc_check_done_yn,disc_present_yn,
                  disc_action_taken,added_by,added_date)
           VALUES (v_hosp_seq_id,'N' ,NULL,NULL,v_user_id,SYSDATE);

      address_pkg.pr_hospital_address_save (v_addr_seq_id,v_hosp_seq_id,v_address_1,v_address_2,
                                            v_address_3,v_city_type_id,v_state_type_id,v_pin_code,
                                            v_country_id,v_landmarks,v_user_id,v_rows_processed);

   /* contact_pkg.save_contacts(v_contact_seq_id,v_user_general_type_id,v_hosp_seq_id,
                          null,null,null,v_prefix_general_type_id,v_contact_name,v_designation_type_id,
                          v_primary_email_id,v_secondary_email_id,v_active_yn,null,null,null,null,null,
                          null,null,null,null,null,null,v_mobile_no,null,null,null,v_user_id,v_login_user_id,null,
                          null,null,null,null,null,v_contact_rows_processed,null,null,null,null,null,null,null,null,
                          null,null,null);*/
    /*  UPDATE tpa_user_contacts
         SET hosp_seq_id=v_hosp_seq_id,
             updated_by =v_user_id,
             updated_date=SYSDATE 
       WHERE provider_id=v_hosp_licence_number;*/
    
    
    ELSE              
      
      UPDATE tpa_hosp_info i
         SET hosp_type_id                    = v_hosp_speciality_type,
             hosp_name                       = v_hosp_name_upper,
             regist_authority                = v_regist_authority,
             primary_email_id                = ttk_util_pkg.fn_encrypt(v_hosp_primary_email_id), --/ED
             website                         = v_website,
             hosp_licenc_numb                = v_hosp_licence_number,
             trade_licenc_numb               = v_trade_lice_number,
             std_code                        = v_std_code,
             off_phone_no_1                  = v_off_phone_no_1,
             off_phone_no_2                  = v_off_phone_no_2,
             office_fax_no                   = v_off_fax_no,
             updated_by                      = v_user_id,
             updated_date                    = SYSDATE,
             PROVIDER_TYPE_ID                = v_provider_type_id,
             ISD_CODE                        = v_isd_code 
       WHERE hosp_seq_id = v_hosp_seq_id;

      UPDATE tpa_hosp_general_dtl
         SET hosp_seq_id                     = v_hosp_seq_id,
             updated_date                    = SYSDATE
       WHERE hosp_gnrl_seq_id = v_hosp_gnrl_seq_id
         AND hosp_seq_id      = v_hosp_seq_id
         AND empanel_seq_id   = v_empanel_seq_id;

      UPDATE tpa_hosp_address
         SET address_1                       = v_address_1,
             address_2                       = v_address_2,
             address_3                       = v_address_3,
             city_type_id                    = v_city_type_id,
             state_type_id                   = v_state_type_id,
             country_id                      = v_country_id,
             pin_code                        = v_pin_code,
             landmarks                       = v_landmarks,
             updated_by                      = v_user_id,
             updated_date                    = SYSDATE
       WHERE addr_seq_id = v_addr_seq_id
         AND hosp_seq_id = v_hosp_seq_id ;

      END IF;

    v_rows_processed := SQL%ROWCOUNT;
    COMMIT;
    pr_discrepancy_status(v_hosp_seq_id, v_discrepancy_status);

  END save_provider_register;
  -------------------------------------------------------------------------- 
---=======================================================
/* 
  Procedure  : add_provider_facilities
  Author     : Mohan RCS Technologies.
  Created On : 23/01/2015
  Description: This procedure adds Provider(hospital) new facility details .
*/
---=============================================
 PROCEDURE add_provider_facilities(
    v_facility             IN TPA_HOSP_MEDICAL_CODE.FACILITY_TYPE_ID%TYPE,
    v_medical_abb_type     IN TPA_HOSP_MEDICAL_CODE.MEDICAL_TYPE_ID%TYPE,
    v_description          IN TPA_HOSP_MEDICAL_CODE.MEDICAL_DESCRIPTION%TYPE,
    v_added_by             IN TPA_HOSP_MEDICAL_CODE.added_by%TYPE,
    v_rows_processed       OUT NUMBER
  )
  IS
  v_cnt    number(10);
  v_facility_id   TPA_HOSP_MEDICAL_CODE.FACILITY_TYPE_ID%TYPE;
  BEGIN
       SELECT COUNT(1) INTO v_cnt FROM TPA_HOSP_MEDICAL_CODE M WHERE M.MEDICAL_TYPE_ID=UPPER(v_medical_abb_type);  
       SELECT fc.facility_type_id INTO v_facility_id  FROM app.tpa_hosp_facility_code fc WHERE 
       fc.description= v_facility;
       IF v_cnt =0 THEN
         INSERT INTO TPA_HOSP_MEDICAL_CODE(MEDICAL_TYPE_ID,
                                           FACILITY_TYPE_ID,
                                           MEDICAL_DESCRIPTION,
                                           ADDED_DATE,
                                           ADDED_BY)
                                  VALUES  (upper(v_medical_abb_type),
                                           v_facility_id,
                                           v_description,
                                           SYSDATE,
                                           v_added_by);
       
       ELSE
        raise_application_error(-20870,'Medical abbreviation code is already exist,please enter new one'); 
      END IF;
       v_rows_processed := SQL%ROWCOUNT;
       COMMIT;
  END add_provider_facilities; 
--================================================================ 
procedure Dashboard_provider(
v_result_set       OUT SYS_REFCURSOR
)
is

begin

open v_result_set for

SELECT "Empanelment_Events", 
       "Total_Providers",
       "Completed_Providers",
       "Pending_Providers",
       "Remarks"

from (

  SELECT 'Login_Credential_Generation' as "Empanelment_Events",
         (SELECT COUNT(1) AS Total_Providers
         FROM app.dha_providers_master a )
         as "Total_Providers",
  (SELECT COUNT(1) AS Completed_Providers from app.tpa_user_contacts c JOIN app.tpa_login_info li on (c.contact_seq_id=li.contact_seq_id)
WHERE c.provider_id IS NOT NULL)  AS "Completed_Providers" ,
(SELECT COUNT(1) AS Pending_Providers
         FROM app.dha_providers_master a where a.provider_id not in      
(select li.user_id  from app.tpa_user_contacts c join app.tpa_login_info li on (c.contact_seq_id=li.contact_seq_id)
where c.provider_id is not null))  as "Pending_Providers",
null as "Remarks" 
from dual )

union ALL

(select 'Login_Credential_Sharing_to_Provider' as "Empanelment_Events",
(SELECT COUNT(1) AS Total_Providers
         FROM app.dha_providers_master a )
         as "Total_Providers",
(select count(1) as Completed_Providers from app.tpa_user_contacts c join app.tpa_login_info li on (c.contact_seq_id=li.contact_seq_id)
where c.provider_id is not null)  as "Completed_Providers" ,
(SELECT COUNT(1) as Pending_Providers
         FROM app.dha_providers_master a where a.provider_id not in      
(select li.user_id  from app.tpa_user_contacts c join app.tpa_login_info li on (c.contact_seq_id=li.contact_seq_id)
where c.provider_id is not null))  as "Pending_Providers",
null as "Remarks"  from dual)

union ALL
(select 'Provider_Facility_Details_Update' as "Empanelment_Events",
(SELECT COUNT(1) AS Total_Providers
         FROM app.dha_providers_master a )
         as "Total_Providers",
(select count(1) as Completed_Providers from app.tpa_hosp_info i 
join (select distinct u.hosp_seq_id from app.tpa_user_contacts u) uc on (i.hosp_seq_id=uc.hosp_seq_id)join (select distinct md.hosp_seq_id from app.tpa_hosp_medical_details md) j on (i.hosp_seq_id=j.hosp_seq_id)
join (select distinct ii.hosp_seq_id from app.tpa_hosp_infrastr_info ii) k on i.hosp_seq_id=k.hosp_seq_id
)  as "Completed_Providers" ,

(SELECT COUNT(1) as Pending_Providers
         FROM app.dha_providers_master a where a.provider_id not in      
(select i.hosp_licenc_numb from app.tpa_hosp_info i 
join (select distinct u.hosp_seq_id from app.tpa_user_contacts u) uc on (i.hosp_seq_id=uc.hosp_seq_id)
join (select distinct md.hosp_seq_id from app.tpa_hosp_medical_details md) j on (i.hosp_seq_id=j.hosp_seq_id)
join (select distinct ii.hosp_seq_id from app.tpa_hosp_infrastr_info ii) k on i.hosp_seq_id=k.hosp_seq_id))  as "Pending_Providers",
null as "Remarks"  from dual)

UNION ALL

(select 'Acknowledment_in_Email_to_Provider' as "Empanelment_Events",
(SELECT COUNT(1) AS Total_Providers
         FROM app.dha_providers_master a )
         as "Total_Providers",
(select count(1) as Completed_Providers from app.tpa_user_contacts c join app.tpa_login_info li on (c.contact_seq_id=li.contact_seq_id)
where c.provider_id is not null)  as "Completed_Providers" ,
(SELECT COUNT(1) as Pending_Providers
         FROM app.dha_providers_master a where a.provider_id not in      
(select li.user_id  from app.tpa_user_contacts c join app.tpa_login_info li on (c.contact_seq_id=li.contact_seq_id)
where c.provider_id is not null))  as "Pending_Providers",
null as "Remarks"  from dual)

UNION ALL

(select 'Review_of_Provider_Facility_Details ' as "Empanelment_Events",
(SELECT COUNT(1) AS Total_Providers
         FROM app.dha_providers_master a )
         as "Total_Providers",
(select count(1) as Completed_Providers from app.tpa_hosp_info i where i.review_yn='Y')  as "Completed_Providers" ,
(SELECT COUNT(1) as Pending_Providers
         FROM app.dha_providers_master a where a.provider_id not in      
(select hi.hosp_licenc_numb from app.tpa_hosp_info hi where hi.review_yn='Y' ))  as "Pending_Providers",
null as "Remarks"  from dual)

UNION ALL

(select 'MOU_Signing ' as "Empanelment_Events",
(SELECT COUNT(1) AS Total_Providers
         FROM app.dha_providers_master a )
         as "Total_Providers",
(select count(1) as Completed_Providers from app.tpa_hosp_info hi 
join app.tpa_hosp_general_dtl gd on (hi.hosp_seq_id=gd.hosp_seq_id)
where gd.signed_date is not null)  as "Completed_Providers" ,
(SELECT COUNT(1) as Pending_Providers
         FROM app.dha_providers_master a where a.provider_id not in      
(select hi.hosp_licenc_numb from app.tpa_hosp_info hi 
join app.tpa_hosp_general_dtl gd on (hi.hosp_seq_id=gd.hosp_seq_id)
where gd.signed_date is not null) )  as "Pending_Providers",
null as "Remarks"  from dual)

UNION ALL

(select 'Sharing_of_Network_Procedure_and _formats_(by Emapanelment)' as "Empanelment_Events",
(SELECT COUNT(1) AS Total_Providers
         FROM app.dha_providers_master a )
         as "Total_Providers",
(select count(1) as Completed_Providers from app.tpa_user_contacts c join app.tpa_login_info li on (c.contact_seq_id=li.contact_seq_id)
where c.provider_id is not null)  as "Completed_Providers" ,
(SELECT COUNT(1) as Pending_Providers
         FROM app.dha_providers_master a where a.provider_id not in      
(select li.user_id  from app.tpa_user_contacts c join app.tpa_login_info li on (c.contact_seq_id=li.contact_seq_id)
where c.provider_id is not null))  as "Pending_Providers",
null as "Remarks"  from dual)

UNION ALL

(select 'Provider_Tariff_Proposal_Submission  ' as "Empanelment_Events",
(SELECT COUNT(1) AS Total_Providers
         FROM app.dha_providers_master a )
         as "Total_Providers",
(select count(1) as Completed_Providers from app.tpa_user_contacts c join app.tpa_login_info li on (c.contact_seq_id=li.contact_seq_id)
where c.provider_id is not null)  as "Completed_Providers" ,
(SELECT COUNT(1) as Pending_Providers
         FROM app.dha_providers_master a where a.provider_id not in      
(select li.user_id  from app.tpa_user_contacts c join app.tpa_login_info li on (c.contact_seq_id=li.contact_seq_id)
where c.provider_id is not null))  as "Pending_Providers",
null as "Remarks"  from dual)

UNION ALL

(select 'Payer_Tariff_Proposal' as "Empanelment_Events",
(SELECT COUNT(1) AS Total_Providers
         FROM app.dha_providers_master a )
         as "Total_Providers",
(select count(1) as Completed_Providers from app.tpa_user_contacts c join app.tpa_login_info li on (c.contact_seq_id=li.contact_seq_id)
where c.provider_id is not null)  as "Completed_Providers" ,
(SELECT COUNT(1) as Pending_Providers
         FROM app.dha_providers_master a where a.provider_id not in      
(select li.user_id  from app.tpa_user_contacts c join app.tpa_login_info li on (c.contact_seq_id=li.contact_seq_id)
where c.provider_id is not null))  as "Pending_Providers",
null as "Remarks"  from dual)

UNION ALL

(select 'Tariff_Negotiation' as "Empanelment_Events",
(SELECT COUNT(1) AS Total_Providers
         FROM app.dha_providers_master a )
         as "Total_Providers",
(select count(1) as Completed_Providers from app.tpa_user_contacts c join app.tpa_login_info li on (c.contact_seq_id=li.contact_seq_id)
where c.provider_id is not null)  as "Completed_Providers" ,
(SELECT COUNT(1) as Pending_Providers
         FROM app.dha_providers_master a where a.provider_id not in      
(select li.user_id  from app.tpa_user_contacts c join app.tpa_login_info li on (c.contact_seq_id=li.contact_seq_id)
where c.provider_id is not null))  as "Pending_Providers",
null as "Remarks"  from dual)

UNION ALL

(select 'Tariff_Approval ' as "Empanelment_Events",
(SELECT COUNT(1) AS Total_Providers
         FROM app.dha_providers_master a )
         as "Total_Providers",
(select count(1) as Completed_Providers from app.tpa_user_contacts c join app.tpa_login_info li on (c.contact_seq_id=li.contact_seq_id)
where c.provider_id is not null)  as "Completed_Providers" ,
(SELECT COUNT(1) as Pending_Providers
         FROM app.dha_providers_master a where a.provider_id not in      
(select li.user_id  from app.tpa_user_contacts c join app.tpa_login_info li on (c.contact_seq_id=li.contact_seq_id)
where c.provider_id is not null))  as "Pending_Providers",
null as "Remarks"  from dual)

UNION ALL

(select 'Tariff_Upload_at_Tips  ' as "Empanelment_Events",
(SELECT COUNT(1) AS Total_Providers
         FROM app.dha_providers_master a )
         as "Total_Providers",
(select count(1) as Completed_Providers from app.tpa_user_contacts c join app.tpa_login_info li on (c.contact_seq_id=li.contact_seq_id)
where c.provider_id is not null)  as "Completed_Providers" ,
(SELECT COUNT(1) as Pending_Providers
         FROM app.dha_providers_master a where a.provider_id not in      
(select li.user_id  from app.tpa_user_contacts c join app.tpa_login_info li on (c.contact_seq_id=li.contact_seq_id)
where c.provider_id is not null))  as "Pending_Providers",
null as "Remarks"  from dual)

UNION ALL

(select 'Provider Module Training (Software)' as "Empanelment_Events",
(SELECT COUNT(1) AS Total_Providers
         FROM app.dha_providers_master a )
         as "Total_Providers",
(select count(1) as Completed_Providers from app.tpa_user_contacts c join app.tpa_login_info li on (c.contact_seq_id=li.contact_seq_id)
where c.provider_id is not null)  as "Completed_Providers" ,
(SELECT COUNT(1) as Pending_Providers
         FROM app.dha_providers_master a where a.provider_id not in      
(select li.user_id  from app.tpa_user_contacts c join app.tpa_login_info li on (c.contact_seq_id=li.contact_seq_id)
where c.provider_id is not null))  as "Pending_Providers",
null as "Remarks"  from dual)

UNION ALL

(select 'Empanelment_Signoff_for_Admission_of_Pre-Auth_and_Claims' as "Empanelment_Events",
(SELECT COUNT(1) AS Total_Providers
         FROM app.dha_providers_master a )
         as "Total_Providers",
(select count(1) as Completed_Providers FROM app.tpa_hosp_info hi join
app.tpa_hosp_empanel_status es on (hi.hosp_seq_id=es.hosp_seq_id) where es.empanel_status_type_id='EMP')  as "Completed_Providers" ,

(SELECT COUNT(1) as Pending_Providers
         FROM app.dha_providers_master a where a.provider_id not in      
(select Hi.Hosp_Licenc_Numb  from app.tpa_hosp_info hi join
app.tpa_hosp_empanel_status es on (hi.hosp_seq_id=es.hosp_seq_id) where es.empanel_status_type_id='EMP'))  as "Pending_Providers",
null as "Remarks"  from dual);
end Dashboard_provider;
---=========================================
PROCEDURE save_tariff_details(V_TARIFF_SEQ_ID         IN OUT TPA_HOSP_TARIFF_DETAILS.HOSP_TARIFF_SEQ_ID%Type, --HOSP_TARIFF_SEQ_ID,INS_TARIFF_SEQ_ID,CORP_TARIFF_SEQ_ID
                              V_HOSP_licence_num      IN varchar2,
                              V_INS_ID                IN varchar2,
                              V_corp_ID               IN varchar2,
                              V_TARIFF_FLAG           IN VARCHAR2, ---HOSP,INS,CORP
                              V_PRICE_REF_NUMBER      IN OUT TPA_HOSP_TARIFF_DETAILS.Price_Ref_Number%Type,
                              V_ACTIVITY_SEQ_ID       IN TPA_HOSP_TARIFF_DETAILS.ACTIVITY_SEQ_ID%Type,
                              V_ACITIVITY_TYPE_SEQ_ID IN TPA_HOSP_TARIFF_DETAILS.ACITIVITY_TYPE_SEQ_ID%Type,
                              V_GROSS_AMOUNT          IN TPA_HOSP_TARIFF_DETAILS.GROSS_AMOUNT%Type,
                              V_DISC_AMOUNT           IN TPA_HOSP_TARIFF_DETAILS.DISC_AMOUNT%Type,
                              V_DRG_WEIGHT            IN TPA_HOSP_TARIFF_DETAILS.DRG_WEIGHT%Type,
                              V_SERVICE_SEQ_ID        IN TPA_HOSP_TARIFF_DETAILS.SERVICE_SEQ_ID%Type,
                              V_BUNDLE_ID             IN TPA_HOSP_TARIFF_DETAILS.BUNDLE_ID%Type,
                              V_PKG_ID                IN TPA_HOSP_TARIFF_DETAILS.Package_Id%Type,
                              V_START_DATE            IN TPA_HOSP_TARIFF_DETAILS.START_DATE%Type,
                              V_END_DATE              IN TPA_HOSP_TARIFF_DETAILS.END_DATE%Type,
                              V_REMARKS               IN TPA_HOSP_TARIFF_DETAILS.REMARKS%Type,
                              V_ADDED_BY              IN TPA_HOSP_TARIFF_DETAILS.ADDED_BY%Type,
                              V_INTERNAL_CODE         IN TPA_HOSP_TARIFF_DETAILS.INTERNAL_CODE%TYPE,
                              V_HOSP_ACT_DESC         IN TPA_HOSP_TARIFF_DETAILS.HOSP_ACT_DESC%Type,
                              V_NETWORK_TYPE          IN VARCHAR2,
                              V_DISC_PERCENT          IN TPA_HOSP_TARIFF_DETAILS.DISC_PERCENT%Type,
                              V_INTERNAL_DESC         IN TPA_HOSP_TARIFF_DETAILS.INTERNAL_DESC%TYPE,
                              V_PKG_SIZE              IN TPA_HOSP_TARIFF_DETAILS.PACKAGE_SIZE%TYPE,
                              V_PKG_PRICE             IN TPA_HOSP_TARIFF_DETAILS.PACKAGE_PRICE%TYPE,
                              V_ROWS_PROCESSED        OUT NUMBER) IS

 

  v_count           number(10);
  v_internal_count  number(10);
  v_prev_start_date date;
  v_prev_end_date   date;
  
  CURSOR act_cur(v_mstr_act_seq_id NUMBER) IS
    SELECT a.activity_code
    FROM Tpa_Activity_Master_Details a
    WHERE a.act_mas_dtl_seq_id = v_mstr_act_seq_id;
    
  v_prev_act_code     VARCHAR2(50);
  v_curr_act_code     VARCHAR2(50);
  
  cursor hosp_tariff is
   select a.start_date, a.end_date
   from app.tpa_hosp_tariff_details a
   where a.hosp_tariff_seq_id = v_tariff_seq_id;

  cursor ins_tariff is
    select a.start_date, a.end_date
    from app.tpa_ins_tariff_details a
    where a.ins_tariff_seq_id = v_tariff_seq_id;
 
  cursor corp_tariff is
    select a.start_date, a.end_date
    from app.tpa_corp_tariff_details a
    where a.corp_tariff_seq_id = v_tariff_seq_id;
    

  CURSOR prev_tariff_cur(v_ins_seq_id number, v_hosp_seq_id NUMBER) IS
   select A.HOSP_TARIFF_SEQ_ID,
          A.START_DATE,
          A.END_DATE,
          A.GROSS_AMOUNT,
          a.disc_percent,
          a.disc_amount,
          a.internal_code,
          a.activity_seq_id,
          a.remarks

      from app.tpa_hosp_tariff_details a
      where a.hosp_tariff_seq_id=V_TARIFF_SEQ_ID/*a.hosp_seq_id = v_hosp_seq_id
      and a.ins_seq_id = v_ins_seq_id
      --and a.activity_seq_id = V_ACTIVITY_SEQ_ID
      and a.internal_code = V_INTERNAL_CODE --added by chiranjibi
      and a.service_seq_id = v_service_seq_id
      and a.network_type = v_network_type*/;
      --and a.end_date IS NULL;

  v_hosp_seq_id      number(10);
  v_ins_seq_id       number(10);
  v_group_reg_seq_id number(10);

  
  v_log_seq_id         tpa_hosp_log.log_seq_id%TYPE;
  v_remarks_concat     VARCHAR2(4000);
  v_screen_name        VARCHAR2(1000) := 'Tariff Details Screen';
  v_system_gen_yn      CHAR(1) := 'Y';
  v_log_type_id        tpa_hosp_log.log_type_id%TYPE := 'HNC';
  v_mod_reason_type_id tpa_hosp_log.mod_reason_type_id%TYPE;
  v_reference_date     tpa_hosp_log.reference_date%TYPE;
  v_reference_no       tpa_hosp_log.reference_no%TYPE;
  v_remarks_log        tpa_hosp_log.remarks%TYPE;
  prev_rec             prev_tariff_cur%rowtype;
  ----
  v_act_seq_id         VARCHAR2(1000);
  v_tar_gross_amount   VARCHAR2(1000);
  v_disc_perc          VARCHAR2(1000);
  v_amount             VARCHAR2(1000);
  v_trf_end_dt         VARCHAR2(1000);
  
  v_log                VARCHAR2(1000);
  v_log1               VARCHAR2(1000);
  v_log2               VARCHAR2(1000);
  v_log3               VARCHAR2(1000);
  v_log4               VARCHAR2(1000);

BEGIN
  
  IF nvl(V_GROSS_AMOUNT, 0) < nvl(V_DISC_AMOUNT, 0) THEN
    raise_application_error(-20994,
                            'Discount amount should not be greater than Gross amount.');
  END IF;

  IF v_tariff_flag = 'HOSP' THEN
    v_hosp_seq_id := CASE WHEN NVL(V_TARIFF_SEQ_ID, 0) = 0 THEN get_tariff_assoc_id('EMP', V_HOSP_licence_num) ELSE V_HOSP_licence_num END;
    v_ins_seq_id  := CASE WHEN NVL(V_TARIFF_SEQ_ID, 0) = 0 THEN get_tariff_assoc_id('INS', V_INS_ID) ELSE V_INS_ID END;

    OPEN hosp_tariff;
    FETCH hosp_tariff INTO v_prev_start_date, v_prev_end_date;
    close hosp_tariff;

    select count(1)
      into v_count
      from app.tpa_hosp_tariff_details a
      where a.hosp_seq_id = v_hosp_seq_id
      and a.ins_seq_id = v_ins_seq_id
      and a.activity_seq_id = V_ACTIVITY_SEQ_ID
      and a.internal_code = V_INTERNAL_CODE
      and a.service_seq_id = v_service_seq_id
      and a.network_type = v_network_type
      and (V_START_DATE between a.start_date and nvl(a.end_date,sysdate));

  ELSIF v_tariff_flag = 'INS' THEN
    v_ins_seq_id       := get_tariff_assoc_id('INS', V_INS_ID);

    OPEN ins_tariff;
    FETCH ins_tariff INTO v_prev_start_date, v_prev_end_date;
    close ins_tariff;

    select count(1) INTO v_count
    from app.tpa_ins_tariff_details a
    where a.ins_seq_id = v_ins_seq_id
    and a.activity_seq_id = v_activity_seq_id
    and a.internal_code = V_INTERNAL_CODE
    and a.service_seq_id = v_service_seq_id
    and a.network_type = v_network_type
    and (V_START_DATE between a.start_date and nvl(a.end_date,sysdate));

  ELSIF v_tariff_flag = 'COR' THEN
    v_group_reg_seq_id := get_tariff_assoc_id('COR', V_corp_ID);
    v_ins_seq_id       := get_tariff_assoc_id('INS', V_INS_ID);

    OPEN corp_tariff;
    FETCH corp_tariff INTO v_prev_start_date, v_prev_end_date;
    close corp_tariff;

    select count(1) into v_count
    from app.tpa_corp_tariff_details a
    where a.group_reg_seq_id = v_group_reg_seq_id
    and a.activity_seq_id = v_activity_seq_id
    and a.internal_code = V_INTERNAL_CODE
    and a.service_seq_id = v_service_seq_id
    and a.ins_seq_id = v_ins_seq_id
    and a.network_type = v_network_type
    and (V_START_DATE between a.start_date and nvl(a.end_date,sysdate));

  END IF;

 

  /*IF NVL(V_TARIFF_SEQ_ID, 0) = 0 AND V_COUNT > 0 THEN

    raise_application_error(-20877, 'Activity/Service is already exist.');

    \* elsif V_COUNT>0 and v_start_date between v_prev_start_date and v_prev_end_date then

    raise_application_error(-20877,'Activity/Service is already exist.');*\

  END IF;*/

  IF V_TARIFF_FLAG = 'HOSP' THEN
    open prev_tariff_cur(v_ins_seq_id, v_hosp_seq_id);
    fetch prev_tariff_cur into prev_rec;
    close prev_tariff_cur;

    /*select count(t.internal_code) into v_internal_count
      from tpa_hosp_tariff_details t
      where t.internal_code = V_INTERNAL_CODE
      and t.hosp_seq_id = v_hosp_seq_id
      and t.end_date is null;
   
    IF v_internal_count > 0 then*/
      
    V_PRICE_REF_NUMBER := v_ins_id || '-' || V_HOSP_licence_num || '-' ||V_NETWORK_TYPE;

    IF NVL(V_TARIFF_SEQ_ID, 0) = 0 THEN
       if nvl(prev_rec.hosp_tariff_seq_id,0)>0 then
         if /*prev_rec.start_date =v_start_date and (prev_rec.gross_amount!=v_gross_amount or prev_rec.disc_percent !=v_disc_percent or*/ prev_rec.internal_code != V_INTERNAL_CODE then
            UPDATE TPA_HOSP_TARIFF_DETAILS td
            set td.gross_amount = v_gross_amount,
                td.disc_percent =  v_disc_percent,
                td.disc_amount  = (td.gross_amount*v_disc_percent)/100
            where td.hosp_tariff_seq_id=prev_rec.hosp_tariff_seq_id;

         elsif prev_rec.start_date > v_start_date then
           raise_application_error (-20030, 'Start Date should be greater than to Previous Start Date.');
         elsif prev_rec.start_date != v_start_date then
           update TPA_HOSP_TARIFF_DETAILS d
           set d.end_date=V_START_DATE-1
           where   d.hosp_tariff_seq_id=prev_rec.hosp_tariff_seq_id and d.end_date is null;

          commit;

               INSERT INTO TPA_HOSP_TARIFF_DETAILS
               (HOSP_TARIFF_SEQ_ID,
                HOSP_SEQ_ID,
                Price_Ref_Number,
                ACTIVITY_SEQ_ID,
                ACITIVITY_TYPE_SEQ_ID,
                GROSS_AMOUNT,
                DISC_PERCENT,
                DISC_AMOUNT,
                DRG_WEIGHT,
                SERVICE_SEQ_ID,
                BUNDLE_ID,
                Package_Id,
                INTERNAL_CODE,
                HOSP_ACT_DESC,
                START_DATE,
                END_DATE,
                REMARKS,
                ADDED_BY,
                ADDED_DATE,
                INS_SEQ_ID,
                NETWORK_TYPE,
                INTERNAL_DESC,
                PACKAGE_SIZE,
                PACKAGE_PRICE)

                VALUES

                  (TPA_HOSP_TARIFF_DETAILS_SEQ.NEXTVAL,
                   V_HOSP_SEQ_ID,
                   V_PRICE_REF_NUMBER,
                   V_ACTIVITY_SEQ_ID,
                   V_ACITIVITY_TYPE_SEQ_ID,
                   V_GROSS_AMOUNT,
                   V_DISC_PERCENT,
                   V_DISC_AMOUNT,
                   V_DRG_WEIGHT,
                   V_SERVICE_SEQ_ID,
                   V_BUNDLE_ID,
                   V_PKG_ID,
                   V_INTERNAL_CODE,
                   V_HOSP_ACT_DESC,
                   V_START_DATE,
                   V_END_DATE,
                   V_REMARKS,
                   V_ADDED_BY,
                   SYSDATE,
                   V_INS_SEQ_ID,
                   V_NETWORK_TYPE,
                   V_INTERNAL_DESC,
                   V_PKG_SIZE,
                   V_PKG_PRICE
                  )
                RETURNING HOSP_TARIFF_SEQ_ID INTO V_TARIFF_SEQ_ID;

         /*elsif prev_rec.start_date =v_start_date and (prev_rec.gross_amount = v_gross_amount or prev_rec.disc_percent = v_disc_percent ) then          

              raise_application_error(-20877, 'Activity/Service is already exist.');*/
         elsif prev_rec.internal_code = V_INTERNAL_CODE then
           raise_application_error(-20877, 'Internal Code is already assigned to other CPT(Activity) for this Provider');
         end if;

      else

        INSERT INTO TPA_HOSP_TARIFF_DETAILS
          (HOSP_TARIFF_SEQ_ID,
           HOSP_SEQ_ID,
           Price_Ref_Number,
           ACTIVITY_SEQ_ID,
           ACITIVITY_TYPE_SEQ_ID,
           GROSS_AMOUNT,
           DISC_PERCENT,
           DISC_AMOUNT,
           DRG_WEIGHT,
           SERVICE_SEQ_ID,
           BUNDLE_ID,
           Package_Id,
           INTERNAL_CODE,
           HOSP_ACT_DESC,
           START_DATE,
           END_DATE,
           REMARKS,
           ADDED_BY,
           ADDED_DATE,
           INS_SEQ_ID,
           NETWORK_TYPE,
           INTERNAL_DESC,
           PACKAGE_SIZE,
           PACKAGE_PRICE)
        VALUES
          (TPA_HOSP_TARIFF_DETAILS_SEQ.NEXTVAL,
           V_HOSP_SEQ_ID,
           V_PRICE_REF_NUMBER,
           V_ACTIVITY_SEQ_ID,
           V_ACITIVITY_TYPE_SEQ_ID,
           V_GROSS_AMOUNT,
           V_DISC_PERCENT,
           V_DISC_AMOUNT,
           V_DRG_WEIGHT,
           V_SERVICE_SEQ_ID,
           V_BUNDLE_ID,
           V_PKG_ID,
           V_INTERNAL_CODE,
           V_HOSP_ACT_DESC,
           V_START_DATE,
           V_END_DATE,
           V_REMARKS,
           V_ADDED_BY,
           SYSDATE,
           V_INS_SEQ_ID,
           V_NETWORK_TYPE,
           V_INTERNAL_DESC,
           V_PKG_SIZE,
           V_PKG_PRICE
          )RETURNING HOSP_TARIFF_SEQ_ID INTO V_TARIFF_SEQ_ID;

     end if;
    ELSE
      -- End date cannot be less than previous end date
      IF V_END_DATE IS NOT NULL AND (V_END_DATE < v_prev_end_date) THEN
        RAISE_APPLICATION_ERROR(-20959, 'End date cannot be less than existing end date.');
      END IF;
      
      --Previous Activity Code
      OPEN act_cur(prev_rec.activity_seq_id);
      FETCH act_cur INTO v_prev_act_code;
      CLOSE act_cur;
      
      --Current Activity Code
      OPEN act_cur(V_ACTIVITY_SEQ_ID);
      FETCH act_cur INTO v_curr_act_code;
      CLOSE act_cur;
      
      v_act_seq_id := CASE WHEN V_ACTIVITY_SEQ_ID != prev_rec.activity_seq_id THEN
                         ' For :'||v_screen_name ||';'||' Column : '||'Activity Code Changed From '||v_prev_act_code||' To: '||v_curr_act_code
                      END;
      v_log1 := CASE WHEN V_ACTIVITY_SEQ_ID != prev_rec.activity_seq_id THEN
                   'Tariff Activity mapping changes'
                END;
      v_tar_gross_amount := CASE WHEN V_GROSS_AMOUNT != prev_rec.gross_amount THEN
                           ' For :'||v_screen_name||' Column : '||'Gross Amount Changed From '||prev_rec.gross_amount||' To: '||V_GROSS_AMOUNT
                        END;
      
      v_log2 := CASE WHEN V_GROSS_AMOUNT != prev_rec.gross_amount THEN
                  'Tariff amount changes'
                END;
      v_disc_perc := CASE WHEN V_DISC_PERCENT != NVL(prev_rec.disc_percent, (prev_rec.gross_amount * prev_rec.disc_amount / 100)) THEN
                       ' For :'||v_screen_name||' Column : '||'Discount Changed From '||prev_rec.disc_percent||' To: '||V_DISC_PERCENT
                     END;
      
      v_log3 := CASE WHEN V_DISC_PERCENT != NVL(prev_rec.disc_percent, (prev_rec.gross_amount * prev_rec.disc_amount / 100)) THEN
                  'Tariff discount percent changes'
                END;
                
      v_trf_end_dt := CASE WHEN V_END_DATE != prev_rec.end_date THEN
                       ' For :'||v_screen_name||' Column : '||'End Date Changed From '||to_char(prev_rec.end_date, 'DD/MM/RRRR')||' To: '||to_char(V_END_DATE, 'DD/MM/RRRR')
                      END;
      
      v_log4 := CASE WHEN V_END_DATE != prev_rec.end_date THEN
                  'Tariff end date changes'
                END;
                               
      v_remarks_concat := CASE WHEN v_act_seq_id IS NOT NULL THEN v_act_seq_id END||' '||
                          CASE WHEN v_tar_gross_amount IS NOT NULL THEN v_tar_gross_amount END||' '||
                          CASE WHEN v_disc_perc IS NOT NULL THEN v_disc_perc END||' '||
                          CASE WHEN v_trf_end_dt IS NOT NULL THEN v_trf_end_dt END;
                            
      v_remarks_concat := 'Reference Date : '||TO_CHAR(SYSDATE, 'DD/MM/RRRR')||' '||v_remarks_concat;
                          
      v_log := CASE WHEN v_log1 IS NOT NULL THEN v_log1 END||' '||CHR(10)||
               CASE WHEN v_log2 IS NOT NULL THEN v_log2 END||' '||CHR(10)||
               CASE WHEN v_log3 IS NOT NULL THEN v_log3 END||' '||CHR(10)||
               CASE WHEN v_log4 IS NOT NULL THEN v_log3 END;
               
                      
      UPDATE TPA_HOSP_TARIFF_DETAILS
         SET GROSS_AMOUNT = NVL(V_GROSS_AMOUNT,GROSS_AMOUNT),
             SERVICE_SEQ_ID = NVL(V_SERVICE_SEQ_ID,SERVICE_SEQ_ID),
             DISC_PERCENT = NVL(V_DISC_PERCENT,DISC_PERCENT),
             DISC_AMOUNT  = NVL(V_DISC_AMOUNT,DISC_AMOUNT),
             START_DATE   = NVL(V_START_DATE,START_DATE),
             END_DATE     = NVL(V_END_DATE,END_DATE),
             REMARKS      = NVL(V_REMARKS,REMARKS),
             UPDATED_BY   = V_ADDED_BY,
             UPDATED_DATE = SYSDATE,/*,
             PACKAGE_SIZE = V_PKG_SIZE,
             PACKAGE_PRICE= V_PKG_PRICE*/
             ACTIVITY_SEQ_ID = V_ACTIVITY_SEQ_ID,
             TAR_LOG         = v_log,
             HOSP_ACT_DESC = V_HOSP_ACT_DESC
       WHERE HOSP_TARIFF_SEQ_ID = V_TARIFF_SEQ_ID;
      
      
      v_rows_processed := SQL%ROWCOUNT;
  
      --- Capture Log
     ttk_util_pkg.pr_user_log ( v_log_seq_id ,v_hosp_seq_id,
                                v_system_gen_yn,'TAR' ,
                                'REF',SYSDATE,V_INTERNAL_CODE,---v_reference_no
                                v_remarks_concat,v_added_by,v_rows_processed );
    END IF;

  ELSIF V_TARIFF_FLAG = 'INS' THEN

    V_PRICE_REF_NUMBER := v_ins_id || '-' || V_NETWORK_TYPE;
    IF NVL(V_TARIFF_SEQ_ID, 0) = 0 THEN
      INSERT INTO TPA_INS_TARIFF_DETAILS
        (INS_TARIFF_SEQ_ID,
         INS_SEQ_ID,
         Price_Ref_Number,
         ACTIVITY_SEQ_ID,
         ACITIVITY_TYPE_SEQ_ID,
         GROSS_AMOUNT,
         DISC_PERCENT,
         DISC_AMOUNT,
         DRG_WEIGHT,
         SERVICE_SEQ_ID,
         BUNDLE_ID,
         Package_Id,
         INTERNAL_CODE,
         HOSP_ACT_DESC,
         START_DATE,
         END_DATE,
         REMARKS,
         ADDED_BY,
         ADDED_DATE,
         NETWORK_TYPE)
      VALUES

        (TPA_INS_TARIFF_DETAILS_SEQ.NEXTVAL,
         V_INS_SEQ_ID,
         V_PRICE_REF_NUMBER,
         V_ACTIVITY_SEQ_ID,
         V_ACITIVITY_TYPE_SEQ_ID,
         V_GROSS_AMOUNT,
         V_DISC_PERCENT,
         V_DISC_AMOUNT,
         V_DRG_WEIGHT,
         V_SERVICE_SEQ_ID,
         V_BUNDLE_ID,
         V_PKG_ID,
         V_INTERNAL_CODE,
         V_HOSP_ACT_DESC,
         V_START_DATE,
         V_END_DATE,
         V_REMARKS,
         V_ADDED_BY,
         SYSDATE,
         V_NETWORK_TYPE)
      RETURNING INS_TARIFF_SEQ_ID INTO V_TARIFF_SEQ_ID;
    
    ELSE
      UPDATE TPA_INS_TARIFF_DETAILS
         SET GROSS_AMOUNT = V_GROSS_AMOUNT,
             SERVICE_SEQ_ID = V_SERVICE_SEQ_ID,
             DISC_PERCENT = V_DISC_PERCENT,
             DISC_AMOUNT  = V_DISC_AMOUNT,
             START_DATE   = V_START_DATE,
             END_DATE     = V_END_DATE,
             REMARKS      = V_REMARKS,
             UPDATED_BY   = V_ADDED_BY,
             UPDATED_DATE = SYSDATE
       WHERE INS_TARIFF_SEQ_ID = V_TARIFF_SEQ_ID;
    END IF;

  ELSIF V_TARIFF_FLAG = 'COR' THEN
    V_PRICE_REF_NUMBER := v_ins_id || '-' || V_corp_ID || '-' ||
                          V_NETWORK_TYPE;

    IF NVL(V_TARIFF_SEQ_ID, 0) = 0 THEN
      INSERT INTO TPA_CORP_TARIFF_DETAILS
        (CORP_TARIFF_SEQ_ID,
         GROUP_REG_SEQ_ID,
         Price_Ref_Number,
         ACTIVITY_SEQ_ID,
         ACITIVITY_TYPE_SEQ_ID,
         GROSS_AMOUNT,
         DISC_PERCENT,
         DISC_AMOUNT,
         DRG_WEIGHT,
         SERVICE_SEQ_ID,
         BUNDLE_ID,
         Package_Id,
         INTERNAL_CODE,
         HOSP_ACT_DESC,
         START_DATE,
         END_DATE,
         REMARKS,
         ADDED_BY,
         ADDED_DATE,
         INS_SEQ_ID,
         NETWORK_TYPE)
      VALUES
        (TPA_CORP_TARIFF_DETAILS_SEQ.NEXTVAL,
         V_GROUP_REG_SEQ_ID,
         V_PRICE_REF_NUMBER,
         V_ACTIVITY_SEQ_ID,
         V_ACITIVITY_TYPE_SEQ_ID,
         V_GROSS_AMOUNT,
         V_DISC_PERCENT,
         V_DISC_AMOUNT,
         V_DRG_WEIGHT,
         V_SERVICE_SEQ_ID,
         V_BUNDLE_ID,
         V_PKG_ID,
         V_INTERNAL_CODE,
         V_HOSP_ACT_DESC,
         V_START_DATE,
         V_END_DATE,
         V_REMARKS,
         V_ADDED_BY,
         SYSDATE,
         V_INS_SEQ_ID,
         V_NETWORK_TYPE)
      RETURNING CORP_TARIFF_SEQ_ID INTO V_TARIFF_SEQ_ID;

    ELSE

      UPDATE TPA_CORP_TARIFF_DETAILS
         SET GROSS_AMOUNT = V_GROSS_AMOUNT,
             SERVICE_SEQ_ID = V_SERVICE_SEQ_ID,
             DISC_PERCENT = V_DISC_PERCENT,
             DISC_AMOUNT  = V_DISC_AMOUNT,
             START_DATE   = V_START_DATE,
             END_DATE     = V_END_DATE,
             REMARKS      = V_REMARKS,
             UPDATED_BY   = V_ADDED_BY,
             UPDATED_DATE = SYSDATE
       WHERE CORP_TARIFF_SEQ_ID = V_TARIFF_SEQ_ID;
    END IF;

  ELSIF V_TARIFF_FLAG = 'TPA' THEN
    --v_group_reg_seq_id := get_tariff_assoc_id('COR',V_corp_ID);
    --v_ins_seq_id       := get_tariff_assoc_id('INS', V_INS_ID); 

    V_PRICE_REF_NUMBER := 'TPA' || '-' || V_NETWORK_TYPE;
    
    IF NVL(V_TARIFF_SEQ_ID, 0) = 0 THEN
      INSERT INTO TPA_TARIFF_DETAILS
        (TPA_TARIFF_SEQ_ID,
         HOSP_SEQ_ID,
         INS_SEQ_ID,
         GROUP_REG_SEQ_ID,
         Price_Ref_Number,
         ACTIVITY_SEQ_ID,
         ACITIVITY_TYPE_SEQ_ID,
         GROSS_AMOUNT,
         DISC_PERCENT,
         DISC_AMOUNT,
         DRG_WEIGHT,
         SERVICE_SEQ_ID,
         BUNDLE_ID,
         PACKAGE_ID,
         INTERNAL_CODE,
         HOSP_ACT_DESC,
         START_DATE,
         END_DATE,
         REMARKS,
         ADDED_BY,
         ADDED_DATE,
         NETWORK_TYPE)

      VALUES
        (TPA_TARIFF_DETAILS_SEQ.NEXTVAL,
         v_HOSP_SEQ_ID,
         v_INS_SEQ_ID,
         v_GROUP_REG_SEQ_ID,
         V_PRICE_REF_NUMBER,
         v_ACTIVITY_SEQ_ID,
         v_ACITIVITY_TYPE_SEQ_ID,
         v_GROSS_AMOUNT,
         v_DISC_PERCENT,
         v_DISC_AMOUNT,
         v_DRG_WEIGHT,
         v_SERVICE_SEQ_ID,
         v_BUNDLE_ID,
         V_PKG_ID,
         v_INTERNAL_CODE,
         v_HOSP_ACT_DESC,
         v_START_DATE,
         v_END_DATE,
         v_REMARKS,
         v_ADDED_BY,
         SYSDATE,
         V_NETWORK_TYPE)
      RETURNING TPA_TARIFF_SEQ_ID INTO V_TARIFF_SEQ_ID;

    ELSE

      UPDATE TPA_TARIFF_DETAILS
         SET GROSS_AMOUNT = V_GROSS_AMOUNT,
             SERVICE_SEQ_ID = V_SERVICE_SEQ_ID,
             DISC_PERCENT = V_DISC_PERCENT,
             DISC_AMOUNT  = V_DISC_AMOUNT,
             START_DATE   = V_START_DATE,
             END_DATE     = V_END_DATE,
             REMARKS      = V_REMARKS,
             UPDATED_BY   = V_ADDED_BY,
             UPDATED_DATE = SYSDATE
       WHERE TPA_TARIFF_SEQ_ID = V_TARIFF_SEQ_ID;
    END IF;
  END IF;

  --v_rows_processed := SQL%ROWCOUNT;
  COMMIT;

END save_tariff_details;
----===================================
FUNCTION get_tariff_assoc_id(v_flag   VARCHAR2,
                             v_value  VARCHAR2,
                             v_value1 VARCHAR2 DEFAULT NULL,
                             v_value2 varchar2 default null)
  RETURN VARCHAR2 IS
  v_result VARCHAR2(100);

  CURSOR hosp_cur IS
    SELECT thi.hosp_seq_id
      FROM tpa_hosp_info thi
     where upper(thi.hosp_licenc_numb) = upper(trim(v_value));

  CURSOR price_ref_cur IS
    SELECT tpr.Price_Ref_Number
      FROM app.tpa_price_reference_dtls tpr
     where upper(tpr.price_ref_number) = upper(trim(v_value));

  CURSOR act_cur IS
    SELECT case when v_flag='ACT' THEN tad.activity_seq_id
                when v_flag='SERV' THEN tsd.service_seq_id
                else tc.activity_type_seq_id END AS SEQ_ID
      FROM app.tpa_activity_details tad
      JOIN app.tpa_service_details tsd
        on (tad.service_seq_id = tsd.service_seq_id)
      Join app.tpa_activity_type_codes tc on (tc.activity_type_id=tad.activity_type_id)
     where upper(tad.activity_code) = upper(trim(v_value))
       and tad.activity_type_id = round(v_value1)
       and upper(tsd.service_name) = upper(v_value2);

  CURSOR bundle_cur IS
    SELECT thb.bundle_seq_id
      FROM app.tpa_hosp_bundle_id_dtls thb
     where upper(thb.bundle_number) = upper(trim(v_value));

  CURSOR pkg_cur IS
    SELECT thp.pkg_seq_id
      FROM app.tpa_hosp_package_dtls thp
     where upper(thp.package_id) = upper(trim(v_value));

  CURSOR ins_cur IS
    SELECT i.ins_seq_id
      FROM tpa_ins_info i
     where upper(i.ins_comp_code_number) = upper(trim(v_value));

  CURSOR corp_cur IS
    SELECT r.group_reg_seq_id
      FROM tpa_group_registration r
     where upper(r.group_id) = upper(trim(v_value));

  v_sql_str    CLOB;
  v_result_set sys_refcursor;

BEGIN

  IF v_flag = 'EMP' THEN
    OPEN hosp_cur;
    FETCH hosp_cur
      INTO v_result;
    CLOSE hosp_cur;
  ELSIF v_flag = 'PRN' THEN
    OPEN price_ref_cur;
    FETCH price_ref_cur
      INTO v_result;
    CLOSE price_ref_cur;
  ELSIF v_flag IN('ACT','SERV','ACTYPE') THEN
    OPEN act_cur;
    FETCH act_cur
      INTO v_result;
    CLOSE act_cur;
  ELSIF v_flag = 'BNDL' THEN
    OPEN bundle_cur;
    FETCH bundle_cur
      INTO v_result;
    CLOSE bundle_cur;
  ELSIF v_flag = 'PKG' THEN
    OPEN pkg_cur;
    FETCH pkg_cur
      INTO v_result;
    CLOSE pkg_cur;
  ELSIF v_flag = 'INS' THEN
    OPEN ins_cur;
    FETCH ins_cur
      INTO v_result;
    CLOSE ins_cur;
  
  ELSIF v_flag = 'COR' THEN
    OPEN corp_cur;
    FETCH corp_cur
      INTO v_result;
    CLOSE corp_cur;
  END IF;

  RETURN v_result;

END get_tariff_assoc_id;
----------========================
PROCEDURE load_hosp_tariff(v_tariff_doc       XMLTYPE,
                           v_log_file      out clob)
IS
  v_doc                         DBMS_XMLDOM.DOMDocument;
  v_elem                        DBMS_XMLDOM.DOMElement;
  v_elem1                       DBMS_XMLDOM.DOMElement;
  v_elem2                       DBMS_XMLDOM.DOMElement;
  v_elem3                       DBMS_XMLDOM.DOMElement;
  v_root_node_list              DBMS_XMLDOM.DOMNODELIST;
  v_parent_node_lst             DBMS_XMLDOM.DOMNODELIST;
  v_parent_node1_lst            DBMS_XMLDOM.DOMNODELIST;
  v_chld_node_list              DBMS_XMLDOM.DOMNODELIST;
  v_chld_node                   DBMS_XMLDOM.domnode;
  v_chld_node1_list             DBMS_XMLDOM.DOMNODELIST;
  v_chld_node1                  DBMS_XMLDOM.domnode;
  v_chld_node2_list             DBMS_XMLDOM.DOMNODELIST;
  v_chld_node2                  DBMS_XMLDOM.domnode;
  v_chld_node3_list             DBMS_XMLDOM.DOMNODELIST;
  v_chld_node3                  DBMS_XMLDOM.domnode;
  v_parent_node                 DBMS_XMLDOM.domnode;
  v_parent_node1                DBMS_XMLDOM.domnode;
  v_root_node                   DBMS_XMLDOM.domnode;
  v_tariff_xml                  xmltype;
  tariff_rec                    tpa_hosp_tariff_details%rowtype;
  ins_tariff_rec                tpa_ins_tariff_details%rowtype;
  corp_tariff_rec               tpa_corp_tariff_details%rowtype;
  price_ref_rec                 tpa_price_reference_dtls%rowtype;
  bundl_id_rec                  tpa_hosp_bundle_id_dtls%rowtype;
  pkg_rec                       tpa_hosp_package_dtls%rowtype;
  V_PRICE_REF_SEQ_ID             NUMBER(10);
  v_tarifff_doc                  CLOB;
  v_tariff_seq_id                NUMBER(10);
  v_tariff_flag                  VARCHAR2(5);
  v_network_type                 VARCHAR2(1000);
  v_hosp_licence_numb            VARCHAR2(32767);
  v_ins_id                       varchar2(32767);
  v_corp_id                      varchar2(32767);
  v_rows_processed               NUMBER(10);
  v_tariff_log_seq_id            NUMBER(10);
  v_act_code                     varchar2(60);
  v_act_type_id                  number(10);
  v_service_name                 VARCHAR2(50);
  v_tpa_bach_seq_id              number(20);
  v_service_type                 VARCHAR2(10);
  v_hosp_seq_id                  NUMBER;
  v_internal_count               NUMBER;
 
  str_tab_nt ttk_util_pkg.str_table_type;--networktype
  str_tab_pd ttk_util_pkg.str_table_type;---providers
  str_tab_py ttk_util_pkg.str_table_type;---payers
  str_tab_cp ttk_util_pkg.str_table_type;---corporates
  v_count  number(10);
  v_scp_count                 number(10);   
 

  CURSOR tariff_logs(v_bach_seq_id NUMBER) IS
  SELECT * FROM tpa_tariff_logs p
  where p.tariff_batch_seq_id=v_bach_seq_id;
  
  CURSOR tarrif_cur(v_hosp_seq_id NUMBER, v_internal_code VARCHAR2, v_network VARCHAR2) IS
    SELECT t.internal_code,
       t.start_date,
       t.end_date,
       t.network_type
       
    FROM tpa_hosp_tariff_details t
    WHERE t.hosp_seq_id = v_hosp_seq_id
    AND upper(t.internal_code) = upper(v_internal_code)
    AND t.network_type = v_network;
  
  CURSOR act_cur(v_code VARCHAR2) IS
    select c.service_seq_id,
           a.act_mas_dtl_seq_id,
           b.activity_type_seq_id
           
    from app.tpa_activity_master_details a 
    join app.tpa_activity_type_codes b on (a.activity_type_seq_id = b.activity_type_seq_id)
    join app.tpa_service_details c on (a.service_seq_id = c.service_seq_id)
    where trim(upper(a.activity_code))=trim(upper(v_code)); 
  
  act_rec                      act_cur%ROWTYPE;
  tarr_rec                     tarrif_cur%ROWTYPE;  
  v_test                       xmltype;
  v_upld_typ                   VARCHAR2(10);
  v_field_val                  VARCHAR2(4000);
  FOUND_DUPLICATE exception;
  Pragma exception_init(FOUND_DUPLICATE ,-1);
  SQLMSG VARCHAR2(1000);

BEGIN
  --delete from priyadarshan.xml_tab;
  --insert into priyadarshan.xml_tab values(1,v_tariff_doc);
  --for i in (select xml_rec from xml_tab x where x.xml_id = 1) loop
  select TPA_TARIFF_BATCH_SEQ.nextval into v_tpa_bach_seq_id from dual;
  --v_tariff_xml := XMLTYPE.createXML(v_tariff_doc);

  v_doc            := dbms_xmldom.newdomdocument(v_tariff_doc);--v_tariff_doc
  v_root_node_list := dbms_xmldom.getelementsbytagname(v_doc, 'tariffdetails');
  
  for v_root_node_index in 0 .. dbms_xmldom.getlength(v_root_node_list) - 1 loop
    v_root_node := dbms_xmldom.item(v_root_node_list, v_root_node_index);
    v_elem        := dbms_xmldom.makeelement(v_root_node);
 
    v_parent_node_lst := dbms_xmldom.getelementsbytagname(v_elem, 'pricerefdetails');
    for parent_node_index in 0 .. dbms_xmldom.getlength(v_parent_node_lst) - 1 loop
      v_parent_node := dbms_xmldom.item(v_parent_node_lst, parent_node_index);
      v_elem1    := dbms_xmldom.makeelement(v_parent_node);
      
      price_ref_rec.price_ref_number:=dbms_xmldom.getAttribute(v_elem1,'pricerefno');
      price_ref_rec.added_by:=dbms_xmldom.getAttribute(v_elem1,'userid');
      v_tariff_flag:=dbms_xmldom.getAttribute(v_elem1,'tariffflag');
      v_network_type:=dbms_xmldom.getAttribute(v_elem1,'networktype');
      v_service_type:=dbms_xmldom.getAttribute(v_elem1,'discAt');
      v_hosp_licence_numb:=dbms_xmldom.getAttribute(v_elem1,'empanelnumber');
      v_ins_id:=dbms_xmldom.getAttribute(v_elem1,'insuranceid');
      v_corp_id:=dbms_xmldom.getAttribute(v_elem1,'corporateid');
      v_upld_typ :=dbms_xmldom.getAttribute(v_elem1,'uploadType');
      
      IF v_tariff_flag='TPA' then
        if v_network_type is not null then
          str_tab_nt := ttk_util_pkg.parse_str ( v_network_type );
        end if;

      ELSIf v_tariff_flag='HOSP' THEN
        if v_upld_typ != 'ACT' then
          raise_application_error(-20947,'Please choose a correct file to upload.');
        end if;
        -->
        if v_hosp_licence_numb is not null then
          str_tab_pd := ttk_util_pkg.parse_str ( v_hosp_licence_numb);
        end if;

        if v_ins_id is not null then
          str_tab_py := ttk_util_pkg.parse_str ( v_ins_id );
        end if;

        if v_network_type is not null then
          str_tab_nt := ttk_util_pkg.parse_str ( v_network_type );
        end if;

      ELSIF v_tariff_flag='INS' THEN
        if v_ins_id is not null then
          str_tab_py := ttk_util_pkg.parse_str ( v_ins_id );
        end if;

        if v_network_type is not null then
          str_tab_nt := ttk_util_pkg.parse_str ( v_network_type );
        end if;

      ELSIF v_tariff_flag='COR' THEN
        if v_ins_id is not null then
          str_tab_py := ttk_util_pkg.parse_str ( v_ins_id );
        end if;

        if v_corp_id is not null then
          str_tab_cp := ttk_util_pkg.parse_str ( v_corp_id );
        end if;

        if v_network_type is not null then
          str_tab_nt := ttk_util_pkg.parse_str ( v_network_type );
        end if;
      END IF;

     --SELECT COUNT(*) INTO V_COUNT FROM TPA_PRICE_REFERENCE_DTLS D WHERE D.PRICE_REF_NUMBER=price_ref_rec.price_ref_number;

     /*IF V_COUNT=0 THEN
        INSERT INTO TPA_PRICE_REFERENCE_DTLS(PRICE_REF_SEQ_ID,PRICE_REF_NUMBER,ADDED_BY,ADDED_DATE,TARIFF_TYPE,NETWORK_TYPE)
        VALUES (tpa_price_reference_dtls_seq.NEXTVAL,price_ref_rec.price_ref_number,price_ref_rec.added_by,sysdate,v_tariff_flag,v_network_type)
        RETURNING PRICE_REF_SEQ_ID  INTO V_PRICE_REF_SEQ_ID ;
      ELSE
        SELECT D.PRICE_REF_SEQ_ID INTO V_PRICE_REF_SEQ_ID FROM TPA_PRICE_REFERENCE_DTLS D WHERE D.PRICE_REF_NUMBER=price_ref_rec.price_ref_number;
      END IF;
      COMMIT;*/

    end loop;

    IF v_tariff_flag='TPA' then
      FOR  network_type  IN str_tab_nt.First..str_tab_nt.Last LOOP
        v_chld_node_list := dbms_xmldom.getelementsbytagname(v_elem, 'tariff');
    
        for chld_node_index in 0 .. dbms_xmldom.getlength(v_chld_node_list) - 1 loop
          v_chld_node := dbms_xmldom.item(v_chld_node_list, chld_node_index);
          v_elem3     := dbms_xmldom.makeelement(v_chld_node);
          begin
            tariff_rec:=null;
            v_tariff_seq_id:=0;
            v_act_code:=0;
            v_act_type_id:=0;

            tariff_rec.price_ref_number:=dbms_xmldom.getAttribute(v_elem3,'pricerefno');
            v_act_code:=dbms_xmldom.getAttribute(v_elem3,'activitycode');
            v_act_type_id:=dbms_xmldom.getAttribute(v_elem3,'acttypeid');
            v_service_name:=dbms_xmldom.getAttribute(v_elem3,'servicename');
            --tariff_rec.activity_seq_id:=get_tariff_assoc_id('ACT',dbms_xmldom.getAttribute(v_elem3,'activitycode'),dbms_xmldom.getAttribute(v_elem3,'acttypeid'),dbms_xmldom.getAttribute(v_elem3,'servname'));
            --tariff_rec.Service_Seq_Id:=get_tariff_assoc_id('SERV',dbms_xmldom.getAttribute(v_elem3,'activitycode'),dbms_xmldom.getAttribute(v_elem3,'acttypeid'),dbms_xmldom.getAttribute(v_elem3,'servname'));
            --tariff_rec.Acitivity_Type_Seq_Id:=get_tariff_assoc_id('ACTYPE',dbms_xmldom.getAttribute(v_elem3,'activitycode'),dbms_xmldom.getAttribute(v_elem3,'acttypeid'),dbms_xmldom.getAttribute(v_elem3,'servname'));
            tariff_rec.internal_code:=dbms_xmldom.getAttribute(v_elem3,'internalcode');
            tariff_rec.hosp_act_desc:=dbms_xmldom.getAttribute(v_elem3,'activitydesc');
            tariff_rec.gross_amount:=dbms_xmldom.getAttribute(v_elem3,'grossamt');
            tariff_rec.disc_amount:=dbms_xmldom.getAttribute(v_elem3,'discamt');
            tariff_rec.disc_percent:=dbms_xmldom.getAttribute(v_elem3,'discpercent');
            tariff_rec.start_date:=to_date(dbms_xmldom.getAttribute(v_elem3,'fromdate'),'dd/mm/yyyy');
            tariff_rec.end_date:=to_date(dbms_xmldom.getAttribute(v_elem3,'expirydate'),'dd/mm/yyyy');
            tariff_rec.bundle_id:=get_tariff_assoc_id('BNDL',dbms_xmldom.getAttribute(v_elem3,'bundleid'));
            tariff_rec.Package_Id:=get_tariff_assoc_id('PKG',dbms_xmldom.getAttribute(v_elem3,'packageid'));
            tariff_rec.Internal_Desc:=dbms_xmldom.getAttribute(v_elem3,'internalDesc');
 
            IF v_service_type = 'PRL' THEN   
              IF v_act_code IS NOT NULL THEN
                SELECT COUNT(1) INTO v_count 
                FROM app.tpa_activity_master_details a 
                WHERE trim(upper(a.activity_code))=trim(upper(v_act_code));
              END IF;

              if v_count>0 then
                select a.act_mas_dtl_seq_id,b.activity_type_seq_id,a.service_seq_id into tariff_rec.activity_seq_id,tariff_rec.Acitivity_Type_Seq_Id,tariff_rec.Service_Seq_Id
                from app.tpa_activity_master_details a
                join app.tpa_activity_type_codes b on (a.activity_type_seq_id=b.activity_type_seq_id)
                where trim(upper(a.activity_code))=trim(upper(v_act_code));
              else
                raise_application_error(-20875,'activity code is not existing in master data.');
              end if;

              IF tariff_rec.hosp_act_desc is null or tariff_rec.gross_amount is null or v_act_code is null or tariff_rec.disc_amount is null or  tariff_rec.start_date is null then
               raise_application_error(-20876,'Please check some of the mandatory fields are coming empty.');
              END IF;

            ELSIF v_service_type = 'SRL' THEN
              IF v_act_code IS NOT NULL THEN
                SELECT COUNT(1) INTO v_count FROM app.tpa_activity_master_details a WHERE trim(upper(a.activity_code))=trim(upper(v_act_code));
              END IF;

              if v_count<0 then
                raise_application_error(-20875,'activity code is not matching in master data.');
              else
                select a.act_mas_dtl_seq_id,b.activity_type_seq_id into tariff_rec.activity_seq_id,tariff_rec.Acitivity_Type_Seq_Id
                from app.tpa_activity_master_details a
                join app.tpa_activity_type_codes b on (a.activity_type_seq_id=b.activity_type_seq_id)
                where trim(upper(a.activity_code))=trim(upper(v_act_code));
              end if;

              IF tariff_rec.hosp_act_desc is null or tariff_rec.internal_code is null or tariff_rec.Internal_Desc is null or tariff_rec.hosp_act_desc is null or
                tariff_rec.gross_amount is null or tariff_rec.disc_amount is null or  tariff_rec.disc_percent is null or tariff_rec.start_date is null then
                raise_application_error(-20876,'Please check some of the mandatory fields are coming empty.');
              END IF;

              IF v_service_name IS NOT NULL THEN
                select count(1) INTO v_count 
                from app.tpa_activity_master_details a 
                join app.tpa_activity_type_codes b on (a.activity_type_seq_id = b.activity_type_seq_id) 
                join app.tpa_service_details c on (a.service_seq_id = c.service_seq_id)
                where trim(upper(c.service_name)) = trim(upper(v_service_name));

                if v_count<0 then
                  raise_application_error(-20877,'Service name is not matching in master data.');
                else
                  select c.service_seq_id into tariff_rec.Service_Seq_Id
                  from app.tpa_activity_master_details a
                  join app.tpa_activity_type_codes b on (a.activity_type_seq_id = b.activity_type_seq_id)
                  join app.tpa_service_details c on (a.service_seq_id = c.service_seq_id)where trim(upper(a.activity_code))=trim(upper(v_act_code))
                  and trim(upper(c.service_name)) = trim(upper(v_service_name));      
                end if;

                ELSIF v_service_name IS NULL THEN
                  raise_application_error(-20878,'Service type is mandatory.');
                END IF;

            END IF;    

     /*IF tariff_rec.activity_seq_id IS NULL OR tariff_rec.Service_Seq_Id IS NULL OR tariff_rec.Acitivity_Type_Seq_Id IS NULL THEN

     raise_application_error(-20875,'activity code  or service name or activity type id is not matching.');

     END IF;*/

            save_tariff_details(v_tariff_seq_id,null,null,null,v_tariff_flag,tariff_rec.price_ref_number,tariff_rec.activity_seq_id,tariff_rec.Acitivity_Type_Seq_Id,
            
            tariff_rec.gross_amount,tariff_rec.disc_amount,null,tariff_rec.Service_Seq_Id,tariff_rec.bundle_id,tariff_rec.Package_Id,tariff_rec.start_date,tariff_rec.end_date,'tariff upload',price_ref_rec.added_by,tariff_rec.internal_code,tariff_rec.hosp_act_desc,str_tab_nt(network_type),tariff_rec.disc_percent, tariff_rec.Internal_Desc, null, null, v_rows_processed);

          exception
            WHEN FOUND_DUPLICATE THEN
              sqlmsg:= '           Activity/Service is already exist.';
              save_tariff_logs(v_tariff_log_seq_id,null,null,null,v_act_code,sqlcode,sqlmsg,'T',price_ref_rec.added_by,V_PRICE_REF_SEQ_ID);
            WHEN NO_DATA_FOUND THEN
              sqlmsg:= '           For Activity Service name not matching.';
              save_tariff_logs(v_tariff_log_seq_id,null,null,null,v_act_code,sqlcode,sqlmsg,'T',price_ref_rec.added_by,V_PRICE_REF_SEQ_ID);
            when others then
              save_tariff_logs(v_tariff_log_seq_id,null,null,null,v_act_code,sqlcode,sqlerrm,'T',price_ref_rec.added_by,V_PRICE_REF_SEQ_ID);
          end;

        end loop;
      end loop;

    elsif v_tariff_flag='HOSP' then
      IF v_upld_typ = 'PHARMA' THEN
        raise_application_error(-20947,'Please choose a correct file to upload.');
      END IF;
                  
      if v_hosp_licence_numb is not null then
        str_tab_pd := ttk_util_pkg.parse_str ( v_hosp_licence_numb);
      end if;
                  
      if v_ins_id is not null then
        str_tab_py := ttk_util_pkg.parse_str ( v_ins_id );
      end if;

      if v_network_type is not null then
        str_tab_nt := ttk_util_pkg.parse_str ( v_network_type );
      end if;
                  
      FOR  payer  IN str_tab_py.First..str_tab_py.Last LOOP
        FOR provider IN str_tab_pd.First..str_tab_pd.Last LOOP
          FOR network_type IN str_tab_nt.First..str_tab_nt.Last LOOP
            v_chld_node_list := dbms_xmldom.getelementsbytagname(v_elem, 'tariff');
              
            for chld_node_index in 0 .. dbms_xmldom.getlength(v_chld_node_list) - 1 loop
              v_chld_node := dbms_xmldom.item(v_chld_node_list, chld_node_index);
              v_elem3    := dbms_xmldom.makeelement(v_chld_node);

              begin
                tariff_rec:=null;
                v_tariff_seq_id:=0;
                v_act_code:=0;
                v_act_type_id:=0;

                tariff_rec.price_ref_number:=get_tariff_assoc_id('PRN',dbms_xmldom.getAttribute(v_elem1,'pricerefno'));
                v_act_code:=dbms_xmldom.getAttribute(v_elem3,'activitycode');
                v_act_type_id:=dbms_xmldom.getAttribute(v_elem3,'acttypeid');
                v_service_name:=dbms_xmldom.getAttribute(v_elem3,'servicename');
                --tariff_rec.activity_seq_id:=get_tariff_assoc_id('ACT',dbms_xmldom.getAttribute(v_elem3,'activitycode'),dbms_xmldom.getAttribute(v_elem3,'acttypeid'),dbms_xmldom.getAttribute(v_elem3,'servname'));
                --tariff_rec.Service_Seq_Id:=get_tariff_assoc_id('SERV',dbms_xmldom.getAttribute(v_elem3,'activitycode'),dbms_xmldom.getAttribute(v_elem3,'acttypeid'),dbms_xmldom.getAttribute(v_elem3,'servname'));
                --tariff_rec.Acitivity_Type_Seq_Id:=get_tariff_assoc_id('ACTYPE',dbms_xmldom.getAttribute(v_elem3,'activitycode'),dbms_xmldom.getAttribute(v_elem3,'acttypeid'),dbms_xmldom.getAttribute(v_elem3,'servname'));
                tariff_rec.internal_code:=dbms_xmldom.getAttribute(v_elem3,'internalcode');
                tariff_rec.hosp_act_desc:=dbms_xmldom.getAttribute(v_elem3,'activitydesc');
                tariff_rec.gross_amount:=dbms_xmldom.getAttribute(v_elem3,'grossamt');
                tariff_rec.disc_amount:=dbms_xmldom.getAttribute(v_elem3,'discamt');
                tariff_rec.disc_percent:=dbms_xmldom.getAttribute(v_elem3,'discpercent');
                tariff_rec.start_date:=to_date(dbms_xmldom.getAttribute(v_elem3,'fromdate'),'dd/mm/yyyy');
                tariff_rec.end_date:=to_date(dbms_xmldom.getAttribute(v_elem3,'expirydate'),'dd/mm/yyyy');
                tariff_rec.bundle_id:=get_tariff_assoc_id('BNDL',dbms_xmldom.getAttribute(v_elem3,'bundleid'));
                tariff_rec.Package_Id:=get_tariff_assoc_id('PKG',dbms_xmldom.getAttribute(v_elem3,'packageid'));
                tariff_rec.Internal_Desc:=dbms_xmldom.getAttribute(v_elem3,'internalDesc');

                IF v_service_type = 'PRL' THEN
                  
                  v_act_code := trim(v_act_code);
                  v_service_name := trim(v_service_name);
                  tariff_rec.internal_code := trim(tariff_rec.internal_code);
                  v_field_val := trim(tariff_rec.price_ref_number)||
                                 trim(v_act_code)||
                                 trim(v_act_type_id)||
                                 trim(v_service_name)||
                                 trim(tariff_rec.internal_code)||
                                 trim(tariff_rec.gross_amount)||
                                 trim(tariff_rec.disc_percent)||
                                 trim(tariff_rec.start_date)||
                                 trim(tariff_rec.end_date)||
                                 trim(tariff_rec.Internal_Desc)||
                                 trim(tariff_rec.hosp_act_desc);
                  
                  IF tariff_rec.end_date IS NOT NULL THEN
                    IF to_date(tariff_rec.end_date, 'DD/MM/RRRR') <= to_date(tariff_rec.start_date, 'DD/MM/RRRR') /*OR to_date(tariff_rec.end_date, 'DD/MM/RRRR') <= to_date(sysdate, 'DD/MM/RRRR'))*/ THEN
                      raise_application_error(-20880,'Tariff end date should be grater than start date.');
                    END IF;
                  END IF;
                  
                  OPEN act_cur(v_act_code);
                  FETCH act_cur INTO act_rec;
                  CLOSE act_cur;
                  
                  
                  tariff_rec.activity_seq_id       := act_rec.act_mas_dtl_seq_id;
                  tariff_rec.Acitivity_Type_Seq_Id := act_rec.activity_type_seq_id;
                  tariff_rec.Service_Seq_Id		     := act_rec.service_seq_id;      
                  tariff_rec.internal_code         := UPPER(tariff_rec.internal_code);
                  
                  IF v_act_code IS NULL THEN
                     raise_application_error(-20880,'Tariff can not be uploaded without Activity/ CPT code.');
                  ELSIF v_act_code IS NULL OR tariff_rec.internal_code IS NULL OR tariff_rec.gross_amount IS NULL OR tariff_rec.Internal_Desc IS NULL OR tariff_rec.start_date IS NULL THEN
                     raise_application_error(-20876,'Please check some of the mandatory fields are coming empty.');
                  ELSIF length(v_act_code) > 15 or act_rec.service_seq_id = 7  THEN
                     raise_application_error(-20881,'Required valid Activity code for '||tariff_rec.internal_code||'.');
                  ELSIF (tariff_rec.gross_amount < 0) OR (tariff_rec.disc_amount < 0) OR (tariff_rec.disc_percent < 0) THEN
                     raise_application_error(-20881,'Amount field cannot be negative value. ');
                  ELSE
                      SELECT COUNT(1) INTO v_count 
                      FROM app.tpa_activity_master_details a 
                      WHERE trim(upper(a.activity_code))=trim(upper(v_act_code));
                      
                      IF v_count = 0 then
                        raise_application_error(-20875,'activity code is not existing in master data.');
                      ELSE
                        IF tariff_rec.internal_code IS NOT NULL THEN
                          select CASE
                                 WHEN regexp_count(upper(trim(tariff_rec.internal_code)), '[[:space:]]') > 1 THEN
                                   1
                                 ELSE
                                   0
                                 END as spc INTO v_scp_count
                          from dual;
                        
                          IF v_scp_count = 1 THEN
                            raise_application_error(-20873,'more than 1 space cannot allow for internal code '||tariff_rec.internal_code||'.');
                          END IF;
                        END IF;
                        
                        
                        v_hosp_seq_id := get_tariff_assoc_id('EMP', str_tab_pd(provider));
                        
                        select COUNT(t.internal_code) INTO v_internal_count
                        from tpa_hosp_tariff_details t
                        where t.hosp_seq_id = v_hosp_seq_id
                        and upper(t.internal_code) = upper(trim(tariff_rec.internal_code))
                        and t.network_type = UPPER(trim(str_tab_nt(network_type)))
                        and t.activity_seq_id != tariff_rec.activity_seq_id;
             
                            IF v_internal_count > 0 THEN
                          raise_application_error(-20876,'Internal Code '||tariff_rec.internal_code||' is already assigned to other Activity code for same Provider.');
                        ELSE
                          select COUNT(t.internal_code) INTO v_internal_count
                          from tpa_hosp_tariff_details t
                          where t.hosp_seq_id = v_hosp_seq_id
                          and upper(t.internal_code) = upper(trim(tariff_rec.internal_code))
                          and t.network_type = UPPER(trim(str_tab_nt(network_type)))
                          and (to_date(tariff_rec.start_date, 'DD/MM/RRRR') BETWEEN t.start_date AND t.end_date);
                          
                          OPEN tarrif_cur (v_hosp_seq_id, tariff_rec.internal_code, str_tab_nt(network_type));
                          FETCH tarrif_cur INTO tarr_rec;
                          CLOSE tarrif_cur;
                          
                          IF tarr_rec.end_date IS NOT NULL AND (to_date(tariff_rec.start_date, 'DD/MM/RRRR') <= to_date(tarr_rec.end_date, 'DD/MM/RRRR')) THEN
                            v_internal_count := 1;
                          END IF;
                      
                          IF v_internal_count > 0 THEN
                            IF tarr_rec.internal_code = tariff_rec.internal_code AND tarr_rec.start_date = tariff_rec.start_date THEN
                               raise_application_error(-20876,'Same Internal Code '||tariff_rec.internal_code||' cannot be uploaded more than once in same day.');
                            END IF;                          
                            
                            raise_application_error(-20876,'Start date should be greater than previous Internal Code '||tariff_rec.internal_code);
                          END IF;
                        END IF;                    
                      END IF;
                    END IF;
       	
                ELSIF v_service_type = 'SRL' THEN
                  IF v_act_code is null then
                     raise_application_error(-20880,'Tariff can not be uploaded without Activity/ CPT code.');
                  END IF;

                  IF v_act_code IS NOT NULL THEN
                    SELECT COUNT(1) INTO v_count
                    FROM app.tpa_activity_master_details a 
                    WHERE trim(upper(a.activity_code))=trim(upper(v_act_code));
                  END IF;

                  if v_count<0 then
                    raise_application_error(-20875,'activity code is not matching in master data.');
                  else
                    select a.act_mas_dtl_seq_id,b.activity_type_seq_id into tariff_rec.activity_seq_id,tariff_rec.Acitivity_Type_Seq_Id  from app.tpa_activity_master_details a
                    join app.tpa_activity_type_codes b on (a.activity_type_seq_id=b.activity_type_seq_id)
                    where trim(upper(a.activity_code))=trim(upper(v_act_code));
                  end if;

                  v_hosp_seq_id := get_tariff_assoc_id('EMP', str_tab_pd(provider));
                  
                  -->
                  IF tariff_rec.internal_code IS NOT NULL THEN
                    select CASE
                           WHEN regexp_count(upper(trim(tariff_rec.internal_code)), '[[:space:]]') > 1 THEN
                             1
                           ELSE
                             0
                           END as spc INTO v_scp_count
                    from dual;
                    
                    IF v_scp_count = 1 THEN
                      raise_application_error(-20873,'more than 1 space cannot allow for internal code '||tariff_rec.internal_code||'.');
                    ELSE
                      select count(1) into v_scp_count
                      from Dual
                      where not regexp_like(upper(tariff_rec.internal_code), '[.,;&'']');
                      
                      IF v_scp_count = 0 THEN
                        raise_application_error(-20873,'some spacial character cannot allow for internal code '||tariff_rec.internal_code||'.');
                      ELSE
                        select COUNT(t.internal_code) INTO v_internal_count
                        from tpa_hosp_tariff_details t
                        where t.hosp_seq_id = v_hosp_seq_id
                        and t.internal_code = upper(trim(tariff_rec.internal_code))
                        and t.network_type = UPPER(trim(str_tab_nt(network_type)))
                        and nvl(t.end_date, to_date(sysdate, 'dd/mm/rrrr')) > to_date(sysdate, 'dd/mm/rrrr');
                        --or t.end_date is null);
         
                        IF v_internal_count > 0 then
                          raise_application_error(-20876,'Internal Code '||tariff_rec.internal_code||' is already assigned to other Activity code for same Provider.');
                        END IF;
                      END IF;
                    END IF;
                  END IF;
                  -->
       
                  IF tariff_rec.internal_code is null or tariff_rec.Internal_Desc is null or tariff_rec.hosp_act_desc is null or
                    tariff_rec.disc_percent is null or tariff_rec.gross_amount is null or tariff_rec.disc_amount is null or  tariff_rec.start_date is null then
                    raise_application_error(-20876,'Please check some of the mandatory fields are coming empty.');
                  END IF;

                  /*IF v_service_name IS NOT NULL THEN
                    select count(1) INTO v_count 
                    from app.tpa_activity_master_details a 
                    join app.tpa_activity_type_codes b on (a.activity_type_seq_id = b.activity_type_seq_id)
                    join app.tpa_service_details c on (a.service_seq_id = c.service_seq_id)
                    where trim(upper(c.service_name)) = trim(upper(v_service_name));

                    if v_count<0 then
                      raise_application_error(-20877,'Service name is not matching in master data.');
                    else
                      select c.service_seq_id into tariff_rec.Service_Seq_Id 
                      from app.tpa_activity_master_details a 
                      join app.tpa_activity_type_codes b on (a.activity_type_seq_id = b.activity_type_seq_id)
                      join app.tpa_service_details c on (a.service_seq_id = c.service_seq_id)
                      where trim(upper(a.activity_code))=trim(upper(v_act_code))
                      and trim(upper(c.service_name)) = trim(upper(v_service_name));      
                    end if;

                  ELSIF v_service_name IS NULL THEN
                    raise_application_error(-20878,'Service type is mandatory.');
                  END IF;*/

                END IF; 

                save_tariff_details(v_tariff_seq_id,str_tab_pd(provider),str_tab_py(payer),null,v_tariff_flag,tariff_rec.price_ref_number,tariff_rec.activity_seq_id,tariff_rec.Acitivity_Type_Seq_Id,
                tariff_rec.gross_amount,tariff_rec.disc_amount,null,tariff_rec.Service_Seq_Id,tariff_rec.bundle_id,tariff_rec.Package_Id,tariff_rec.start_date,tariff_rec.end_date,'tariff upload',price_ref_rec.added_by,tariff_rec.internal_code,tariff_rec.hosp_act_desc,str_tab_nt(network_type),tariff_rec.disc_percent, tariff_rec.Internal_Desc, null, null, v_rows_processed);

              exception
                WHEN FOUND_DUPLICATE THEN
                  sqlmsg:= '           Activity/Service is already exist.';
                  save_tariff_logs(v_tariff_log_seq_id,null,null,null,v_act_code,sqlcode,sqlmsg,'T',price_ref_rec.added_by,V_PRICE_REF_SEQ_ID);
                WHEN NO_DATA_FOUND THEN
                  sqlmsg:= '           For Activity Service name not matching.';
                  save_tariff_logs(v_tariff_log_seq_id,str_tab_pd(provider),str_tab_py(payer),null,v_act_code,sqlcode,sqlmsg,'T',price_ref_rec.added_by,v_tpa_bach_seq_id);
                when others then
                  save_tariff_logs(v_tariff_log_seq_id,str_tab_pd(provider),str_tab_py(payer),null,v_act_code,sqlcode,sqlerrm,'T',price_ref_rec.added_by,v_tpa_bach_seq_id);
              end;
            end loop;
          END LOOP;
        END LOOP;
      END LOOP;

    elsif v_tariff_flag='INS' then 
      FOR  payer  IN str_tab_py.First..str_tab_py.Last LOOP
        FOR network_type IN str_tab_nt.First..str_tab_nt.Last LOOP
          v_chld_node_list := dbms_xmldom.getelementsbytagname(v_elem, 'tariff');
              
          for chld_node_index in 0 .. dbms_xmldom.getlength(v_chld_node_list) - 1 loop
            v_chld_node := dbms_xmldom.item(v_chld_node_list, chld_node_index);
            v_elem3     := dbms_xmldom.makeelement(v_chld_node);

            begin
              tariff_rec:=null;
              v_tariff_seq_id:=0;
              v_act_code:=0;
              v_act_type_id:=0;

              tariff_rec.price_ref_number:=get_tariff_assoc_id('PRN',dbms_xmldom.getAttribute(v_elem1,'pricerefno'));
              v_act_code:=dbms_xmldom.getAttribute(v_elem3,'activitycode');
              v_act_type_id:=dbms_xmldom.getAttribute(v_elem3,'acttypeid');
              v_service_name:=dbms_xmldom.getAttribute(v_elem3,'servicename');
              -- tariff_rec.activity_seq_id:=get_tariff_assoc_id('ACT',dbms_xmldom.getAttribute(v_elem3,'activitycode'),dbms_xmldom.getAttribute(v_elem3,'acttypeid'),dbms_xmldom.getAttribute(v_elem3,'servname'));
              --tariff_rec.Service_Seq_Id:=get_tariff_assoc_id('SERV',dbms_xmldom.getAttribute(v_elem3,'activitycode'),dbms_xmldom.getAttribute(v_elem3,'acttypeid'),dbms_xmldom.getAttribute(v_elem3,'servname'));
              --tariff_rec.Acitivity_Type_Seq_Id:=get_tariff_assoc_id('ACTYPE',dbms_xmldom.getAttribute(v_elem3,'activitycode'),dbms_xmldom.getAttribute(v_elem3,'acttypeid'),dbms_xmldom.getAttribute(v_elem3,'servname'));
              tariff_rec.internal_code:=dbms_xmldom.getAttribute(v_elem3,'internalcode');
              tariff_rec.hosp_act_desc:=dbms_xmldom.getAttribute(v_elem3,'activitydesc');
              tariff_rec.gross_amount:=dbms_xmldom.getAttribute(v_elem3,'grossamt');
              tariff_rec.disc_amount:=dbms_xmldom.getAttribute(v_elem3,'discamt');
              tariff_rec.disc_percent:=dbms_xmldom.getAttribute(v_elem3,'discpercent');
              tariff_rec.start_date:=to_date(dbms_xmldom.getAttribute(v_elem3,'fromdate'),'dd/mm/yyyy');
              tariff_rec.end_date:=to_date(dbms_xmldom.getAttribute(v_elem3,'expirydate'),'dd/mm/yyyy');
              tariff_rec.bundle_id:=get_tariff_assoc_id('BNDL',dbms_xmldom.getAttribute(v_elem3,'bundleid'));
              tariff_rec.Package_Id:=get_tariff_assoc_id('PKG',dbms_xmldom.getAttribute(v_elem3,'packageid'));

              IF v_service_type = 'PRL' THEN   
                IF v_act_code IS NOT NULL THEN
                  SELECT COUNT(1) INTO v_count FROM app.tpa_activity_master_details a WHERE trim(upper(a.activity_code))=trim(upper(v_act_code));
                END IF;

                if v_count>0 then
                  select a.act_mas_dtl_seq_id,b.activity_type_seq_id,a.service_seq_id into tariff_rec.activity_seq_id,tariff_rec.Acitivity_Type_Seq_Id,tariff_rec.Service_Seq_Id  from app.tpa_activity_master_details a
                  join app.tpa_activity_type_codes b on (a.activity_type_seq_id=b.activity_type_seq_id) where trim(upper(a.activity_code))=trim(upper(v_act_code));
                else
                  raise_application_error(-20875,'activity code is not existing in master data.');
                end if;

                IF v_act_code is null or tariff_rec.hosp_act_desc is null or
                  tariff_rec.gross_amount is null or tariff_rec.disc_amount is null or  tariff_rec.start_date is null then
                  raise_application_error(-20876,'Please check some of the mandatory fields are coming empty.');
                END IF;

              ELSIF v_service_type = 'SRL' THEN
                  
                IF v_act_code IS NOT NULL THEN
                  SELECT COUNT(1) INTO v_count 
                  FROM app.tpa_activity_master_details a 
                  WHERE trim(upper(a.activity_code))=trim(upper(v_act_code));
                END IF;

                if v_count<0 then
                  raise_application_error(-20875,'activity code is not matching in master data.');
                else
                  select a.act_mas_dtl_seq_id,b.activity_type_seq_id into tariff_rec.activity_seq_id,tariff_rec.Acitivity_Type_Seq_Id
                  from app.tpa_activity_master_details a
                  join app.tpa_activity_type_codes b on (a.activity_type_seq_id=b.activity_type_seq_id)
                  where trim(upper(a.activity_code))=trim(upper(v_act_code));
                end if;

                IF v_act_code is null or tariff_rec.hosp_act_desc is null or
                  tariff_rec.gross_amount is null or tariff_rec.disc_amount is null or  tariff_rec.start_date is null then
                  raise_application_error(-20876,'Please check some of the mandatory fields are coming empty.');
                END IF;

                IF v_service_name IS NOT NULL THEN
                  select count(1) INTO v_count 
                  from app.tpa_activity_master_details a 
                  join app.tpa_activity_type_codes b on (a.activity_type_seq_id = b.activity_type_seq_id)
                  join app.tpa_service_details c on (a.service_seq_id = c.service_seq_id)
                  where trim(upper(c.service_name)) = trim(upper(v_service_name));

                  if v_count<0 then
                    raise_application_error(-20877,'Service name is not matching in master data.');
                  else
                    select c.service_seq_id into tariff_rec.Service_Seq_Id
                    from app.tpa_activity_master_details a
                    join app.tpa_activity_type_codes b on (a.activity_type_seq_id = b.activity_type_seq_id)
                    join app.tpa_service_details c on (a.service_seq_id = c.service_seq_id)where trim(upper(a.activity_code))=trim(upper(v_act_code))
                    and trim(upper(c.service_name)) = trim(upper(v_service_name));      
                  end if;

                ELSIF v_service_name IS NULL THEN
                  raise_application_error(-20878,'Service type is mandatory.');
                END IF;
              END IF;
                  
              save_tariff_details(v_tariff_seq_id,null,str_tab_py(payer),null,v_tariff_flag,tariff_rec.price_ref_number,tariff_rec.activity_seq_id,tariff_rec.Acitivity_Type_Seq_Id,
              tariff_rec.gross_amount,tariff_rec.disc_amount,null,tariff_rec.Service_Seq_Id,tariff_rec.bundle_id,tariff_rec.Package_Id,tariff_rec.start_date,tariff_rec.end_date,'tariff upload',price_ref_rec.added_by,tariff_rec.internal_code,tariff_rec.hosp_act_desc,str_tab_nt(network_type),tariff_rec.disc_percent,null, null,null,v_rows_processed);
            
            exception
              when others then
                save_tariff_logs(v_tariff_log_seq_id,null,str_tab_py(payer),null,v_act_code,sqlcode,sqlerrm,'T',price_ref_rec.added_by,v_tpa_bach_seq_id);
            end;
          end loop;
        end loop;
      end loop;

    elsif v_tariff_flag='COR' then
      FOR  payer  IN str_tab_py.First..str_tab_py.Last LOOP
          FOR  corporate  IN str_tab_cp.First..str_tab_cp.Last LOOP
            FOR network_type IN str_tab_nt.First..str_tab_nt.Last LOOP
              v_chld_node_list := dbms_xmldom.getelementsbytagname(v_elem, 'tariff');
              
              for chld_node_index in 0 .. dbms_xmldom.getlength(v_chld_node_list) - 1 loop
                v_chld_node := dbms_xmldom.item(v_chld_node_list, chld_node_index);
                v_elem3    := dbms_xmldom.makeelement(v_chld_node);
                    
                begin
                  tariff_rec:=null;
                  v_tariff_seq_id:=0;
                  v_act_code:=0;
                  v_act_type_id:=0;

                  tariff_rec.price_ref_number:=get_tariff_assoc_id('PRN',dbms_xmldom.getAttribute(v_elem1,'pricerefno'));
                  --tariff_rec.activity_seq_id:=get_tariff_assoc_id('ACT',dbms_xmldom.getAttribute(v_elem3,'activitycode'),dbms_xmldom.getAttribute(v_elem3,'acttypeid'),dbms_xmldom.getAttribute(v_elem3,'servname'));
                  --tariff_rec.Service_Seq_Id:=get_tariff_assoc_id('SERV',dbms_xmldom.getAttribute(v_elem3,'activitycode'),dbms_xmldom.getAttribute(v_elem3,'acttypeid'),dbms_xmldom.getAttribute(v_elem3,'servname'));
                  --tariff_rec.Acitivity_Type_Seq_Id:=get_tariff_assoc_id('ACTYPE',dbms_xmldom.getAttribute(v_elem3,'activitycode'),dbms_xmldom.getAttribute(v_elem3,'acttypeid'),dbms_xmldom.getAttribute(v_elem3,'servname'));
                  tariff_rec.internal_code:=dbms_xmldom.getAttribute(v_elem3,'internalcode');
                  tariff_rec.hosp_act_desc:=dbms_xmldom.getAttribute(v_elem3,'activitydesc');
                  tariff_rec.gross_amount:=dbms_xmldom.getAttribute(v_elem3,'grossamt');
                  tariff_rec.disc_amount:=dbms_xmldom.getAttribute(v_elem3,'discamt');
                  tariff_rec.disc_percent:=dbms_xmldom.getAttribute(v_elem3,'discpercent');
                  tariff_rec.start_date:=to_date(dbms_xmldom.getAttribute(v_elem3,'fromdate'),'dd/mm/yyyy');
                  tariff_rec.end_date:=to_date(dbms_xmldom.getAttribute(v_elem3,'expirydate'),'dd/mm/yyyy');
                  tariff_rec.bundle_id:=get_tariff_assoc_id('BNDL',dbms_xmldom.getAttribute(v_elem3,'bundleid'));
                  tariff_rec.Package_Id:=get_tariff_assoc_id('PKG',dbms_xmldom.getAttribute(v_elem3,'packageid'));
                  v_act_code:=dbms_xmldom.getAttribute(v_elem3,'activitycode');
                  v_act_type_id:=dbms_xmldom.getAttribute(v_elem3,'acttypeid');
                  v_service_name:=dbms_xmldom.getAttribute(v_elem3,'servicename');

                  IF v_service_type = 'PRL' THEN   
                    IF v_act_code IS NOT NULL THEN
                      SELECT COUNT(1) INTO v_count FROM app.tpa_activity_master_details a WHERE trim(upper(a.activity_code))=trim(upper(v_act_code));
                    END IF;

                    if v_count>0 then
                      select a.act_mas_dtl_seq_id,b.activity_type_seq_id,a.service_seq_id into tariff_rec.activity_seq_id,tariff_rec.Acitivity_Type_Seq_Id,tariff_rec.Service_Seq_Id
                      from app.tpa_activity_master_details a
                      join app.tpa_activity_type_codes b on (a.activity_type_seq_id=b.activity_type_seq_id)
                      where trim(upper(a.activity_code))=trim(upper(v_act_code));
                    else
                      raise_application_error(-20875,'activity code is not existing in master data.');
                    end if;

                    IF v_act_code is null or tariff_rec.hosp_act_desc is null or
                      tariff_rec.gross_amount is null or tariff_rec.disc_amount is null or  tariff_rec.start_date is null then
                      raise_application_error(-20876,'Please check some of the mandatory fields are coming empty.');
                    END IF;

                  ELSIF v_service_type = 'SRL' THEN
                    IF v_act_code IS NOT NULL THEN
                      SELECT COUNT(1) INTO v_count FROM app.tpa_activity_master_details a WHERE trim(upper(a.activity_code))=trim(upper(v_act_code));
                    END IF;

                    if v_count<0 then
                      raise_application_error(-20875,'activity code is not matching in master data.');
                    else
                      select a.act_mas_dtl_seq_id,b.activity_type_seq_id into tariff_rec.activity_seq_id,tariff_rec.Acitivity_Type_Seq_Id
                      from app.tpa_activity_master_details a
                      join app.tpa_activity_type_codes b on (a.activity_type_seq_id=b.activity_type_seq_id)
                      where trim(upper(a.activity_code))=trim(upper(v_act_code));
                    end if;

                    IF v_act_code is null or tariff_rec.hosp_act_desc is null or
                      tariff_rec.gross_amount is null or tariff_rec.disc_amount is null or  tariff_rec.start_date is null then
                      raise_application_error(-20876,'Please check some of the mandatory fields are coming empty.');
                    END IF;

                    IF v_service_name IS NOT NULL THEN
                      select count(1) INTO v_count 
                      from app.tpa_activity_master_details a 
                      join app.tpa_activity_type_codes b on (a.activity_type_seq_id = b.activity_type_seq_id)
                      join app.tpa_service_details c on (a.service_seq_id = c.service_seq_id)
                      where trim(upper(c.service_name)) = trim(upper(v_service_name));
                          
                      if v_count<0 then
                        raise_application_error(-20877,'Service name is not matching in master data.');
                      else
                        select c.service_seq_id into tariff_rec.Service_Seq_Id
                        from app.tpa_activity_master_details a
                        join app.tpa_activity_type_codes b on (a.activity_type_seq_id = b.activity_type_seq_id)
                        join app.tpa_service_details c on (a.service_seq_id = c.service_seq_id)
                        where trim(upper(a.activity_code))=trim(upper(v_act_code))
                        and trim(upper(c.service_name)) = trim(upper(v_service_name));      
                      end if;

                    ELSIF v_service_name IS NULL THEN
                      raise_application_error(-20878,'Service type is mandatory.');
                    END IF;
                  END IF;

                    save_tariff_details(v_tariff_seq_id,null,str_tab_py(payer),str_tab_cp(corporate),v_tariff_flag,tariff_rec.price_ref_number,tariff_rec.activity_seq_id,tariff_rec.Acitivity_Type_Seq_Id,
                      
                    tariff_rec.gross_amount,tariff_rec.disc_amount,null,tariff_rec.Service_Seq_Id,tariff_rec.bundle_id,tariff_rec.Package_Id,tariff_rec.start_date,tariff_rec.end_date,'tariff upload',price_ref_rec.added_by,tariff_rec.internal_code,tariff_rec.hosp_act_desc,str_tab_nt(network_type),tariff_rec.disc_percent, null, null, null,v_rows_processed);

                exception
                  WHEN FOUND_DUPLICATE THEN
                     sqlmsg:= '           Activity/Service is already exist.';
                     save_tariff_logs(v_tariff_log_seq_id,null,null,null,v_act_code,sqlcode,sqlmsg,'T',price_ref_rec.added_by,V_PRICE_REF_SEQ_ID);
                  WHEN NO_DATA_FOUND THEN
                     sqlmsg:= '           For Activity Service name not matching.';
                     save_tariff_logs(v_tariff_log_seq_id,null,str_tab_py(payer),str_tab_cp(corporate),v_act_code,sqlcode,sqlmsg,'T',price_ref_rec.added_by,v_tpa_bach_seq_id);
                  WHEN others then
                     save_tariff_logs(v_tariff_log_seq_id,null,str_tab_py(payer),str_tab_cp(corporate),v_act_code,sqlcode,sqlerrm,'T',price_ref_rec.added_by,v_tpa_bach_seq_id);

                end;
              end loop;
           end loop;
        end loop;
      end loop;
    END IF;
  end loop;

 

  for i in tariff_logs(v_tpa_bach_seq_id) loop
    v_log_file:=v_log_file||' '||'Activity code :'||i.act_code||' '||substr(i.error_message,11)||chr(13);
  end loop;
    v_log_file:=nvl(v_log_file,'Tariff details uploaded successfully');
  --end loop;

END load_hosp_tariff;

 
 
 /*==============================================================================================
    Name       : delete_tds_certificate
    Created on :
    Created By : Anil MK
    Company    : SPAN Infotech (India) Pvt. Ltd.
    Comments   :
 ============================================================================================== */
  PROCEDURE delete_tarrif_details(
    v_search_str             IN VARCHAR2,
    v_rows_processed         IN OUT NUMBER
  )
  IS
    str_tab ttk_util_pkg.str_table_type:= ttk_util_pkg.parse_str(v_search_str);

  BEGIN
    v_rows_processed:=0;
     IF str_tab.COUNT>0 THEN

     FOR i IN str_tab.FIRST..str_tab.LAST LOOP

         DELETE FROM mou_docs_info a WHERE a.mou_doc_seq_id=str_tab(i);
         v_rows_processed:=v_rows_processed+SQL%ROWCOUNT;
     END LOOP;

     END IF;

    COMMIT;
  END delete_tarrif_details;

-------------------------------------
PROCEDURE save_hosp_professionals(V_CONTACT_SEQ_ID       IN OUT TPA_HOSP_PROFESSIONALS.CONTACT_SEQ_ID%Type,
                                  V_USER_GENERAL_TYPE_ID IN TPA_HOSP_PROFESSIONALS.USER_GENERAL_TYPE_ID%Type,
                                  V_HOSP_SEQ_ID          IN TPA_HOSP_PROFESSIONALS.HOSP_SEQ_ID%Type,
                                  V_CONTACT_NAME         IN TPA_HOSP_PROFESSIONALS.CONTACT_NAME%Type,
                                  V_PROFESSIONAL_ID      IN TPA_HOSP_PROFESSIONALS.PROFESSIONAL_ID%Type,
                                  V_PROF_AUTHORITY       IN TPA_HOSP_PROFESSIONALS.PROF_AUTHORITY%Type,
                                  V_GENDER_GENERAL_TYPE  IN TPA_HOSP_PROFESSIONALS.GENDER_GENERAL_TYPE%Type,
                                  V_AGE                  IN TPA_HOSP_PROFESSIONALS.AGE%Type,
                                  V_CONSULT_GEN_TYPE     IN TPA_HOSP_PROFESSIONALS.CONSULT_GEN_TYPE%Type,
                                  V_VALID_FROM_DATE      IN TPA_HOSP_PROFESSIONALS.VALID_FROM_DATE%Type,
                                  V_VALID_TO_DATE        IN TPA_HOSP_PROFESSIONALS.VALID_TO_DATE%Type,
                                  V_PRIMARY_EMAIL_ID     IN TPA_HOSP_PROFESSIONALS.PRIMARY_EMAIL_ID%Type,
                                  V_ACTIVE_YN            IN TPA_HOSP_PROFESSIONALS.ACTIVE_YN%Type,
                                  V_ISD_CODE             IN TPA_HOSP_PROFESSIONALS.ISD_CODE%Type,
                                  V_STD_CODE             IN TPA_HOSP_PROFESSIONALS.STD_CODE%Type,
                                  V_OFF_PHONE_NO_1       IN TPA_HOSP_PROFESSIONALS.OFF_PHONE_NO_1%Type,
                                  V_OFF_PHONE_NO_2       IN TPA_HOSP_PROFESSIONALS.OFF_PHONE_NO_2%Type,
                                  V_MOBILE_NO            IN TPA_HOSP_PROFESSIONALS.MOBILE_NO%Type,
                                  V_FAX_NO               IN TPA_HOSP_PROFESSIONALS.FAX_NO%Type,
                                  V_NATIONALITY_ID       IN TPA_HOSP_PROFESSIONALS.NATIONALITY_ID%Type,
                                  V_SPECIALITY_ID        IN TPA_HOSP_PROFESSIONALS.SPECIALITY_ID%Type, 
                                  V_PROF_FILE_NAME       IN TPA_HOSP_PROFESSIONALS.PROF_FILE_NAME%Type,
                                  V_PROF_FILE            IN TPA_HOSP_PROFESSIONALS.PROF_FILE%Type,
                                  V_ADDED_BY             IN TPA_HOSP_PROFESSIONALS.ADDED_BY%Type,
                                  V_ROWS_PROCESSED       OUT NUMBER) 
 IS
  V_CNT        NUMBER(10);
  V_AUT_CNT    NUMBER(10);
  v_reg_auth_check varchar2(100);

CURSOR pre_prof_cur IS 
  SELECT c.valid_from_date,c.valid_to_date,c.hosp_seq_id FROM tpa_hosp_professionals c WHERE c.professional_id=v_professional_id;
         pre_prof_rec   pre_prof_cur%rowtype;
         
BEGIN
  
  select ho.regist_authority into V_reg_auth_check from app.tpa_hosp_info ho where ho.hosp_seq_id=V_HOSP_SEQ_ID;

   IF V_PROFESSIONAL_ID IS NOT NULL AND v_hosp_seq_id IS NOT NULL and  NVL(V_CONTACT_SEQ_ID, 0)=0 THEN 
     SELECT COUNT(1) INTO V_CNT from app.tpa_hosp_professionals p WHERE p.professional_id=V_PROFESSIONAL_ID and p.hosp_seq_id=v_hosp_seq_id;
    SELECT COUNT(1) INTO v_aut_cnt from app.dha_clinicians_list_master lm where lm.clinitian_id=V_PROFESSIONAL_ID;
   --IF v_aut_cnt=0 and V_reg_auth_check IN ('Govt','Priv')  THEN
   --  raise_application_error(-20872,'Professional id is not matching with DHPO .');
   IF V_CNT>0 and upper(V_reg_auth_check) IN ('GOVT','PRIV')  THEN
        raise_application_error(-20873,'Professional already associated  with this Provider.');
      
   END IF;
      OPEN pre_prof_cur;
      FETCH pre_prof_cur INTO pre_prof_rec;
      close pre_prof_cur;
       IF pre_prof_rec.hosp_seq_id!=v_hosp_seq_id THEN
         IF trunc(nvl(v_valid_from_date,SYSDATE)) BETWEEN pre_prof_rec.valid_from_date AND nvl(pre_prof_rec.valid_to_date,sysdate) AND 
           v_consult_gen_type NOT IN ('VCPH','CMPH')THEN
           raise_application_error(-20874,'This License number is already associated  with another Provider.');
         END IF;
       /* ELSIF pre_prof_rec.hosp_seq_id=v_hosp_seq_id THEN
          raise_application_error(-20873,'Doctot is already exist under this Provider.');*/
      END IF;
   END IF;
  IF NVL(V_CONTACT_SEQ_ID, 0) = 0 THEN
    INSERT INTO TPA_HOSP_PROFESSIONALS
      (CONTACT_SEQ_ID,
       USER_GENERAL_TYPE_ID,
       HOSP_SEQ_ID,
       CONTACT_NAME,
       PROFESSIONAL_ID,
       PROF_AUTHORITY,
       GENDER_GENERAL_TYPE,
       AGE,
       CONSULT_GEN_TYPE,
       VALID_FROM_DATE,
       VALID_TO_DATE,
       PRIMARY_EMAIL_ID,
       ACTIVE_YN,
       ISD_CODE,
       STD_CODE,
       OFF_PHONE_NO_1,
       OFF_PHONE_NO_2,
       MOBILE_NO,
       FAX_NO,
       NATIONALITY_ID,
       PROF_FILE_NAME,
       PROF_FILE,
       ADDED_DATE,
       ADDED_BY,
       SPECIALITY_ID)
    VALUES
      (TPA_HOSP_PROFESSIONALS_SEQ.NEXTVAL,
       V_USER_GENERAL_TYPE_ID,
       V_HOSP_SEQ_ID,
       V_CONTACT_NAME,
       V_PROFESSIONAL_ID,
       V_PROF_AUTHORITY,
       V_GENDER_GENERAL_TYPE,
       V_AGE,
       V_CONSULT_GEN_TYPE,
       V_VALID_FROM_DATE,
       V_VALID_TO_DATE,
       V_PRIMARY_EMAIL_ID,
       V_ACTIVE_YN,
       V_ISD_CODE,
       V_STD_CODE,
       V_OFF_PHONE_NO_1,
       V_OFF_PHONE_NO_2,
       V_MOBILE_NO,
       V_FAX_NO,
       V_NATIONALITY_ID,
       V_PROF_FILE_NAME,
       V_PROF_FILE,
       SYSDATE,
       V_ADDED_BY,
       V_SPECIALITY_ID)RETURNING CONTACT_SEQ_ID INTO V_CONTACT_SEQ_ID;
	   
	   INSERT INTO APP.dha_clinicians_list_master
	   (CLINI_SEQ_ID,
     CLINI_STANDARD,
	   CLINITIAN_ID,
	   PROFESSIONAL_NAME,
	   STATUS,
	   UPDATED_DATE) 
	   VALUES
	   (V_CONTACT_SEQ_ID,
     'QHA',
	   V_PROFESSIONAL_ID,
	   V_CONTACT_NAME,
	  CASE WHEN V_ACTIVE_YN='Y' THEN 'ACTIVE'
	   WHEN V_ACTIVE_YN='N' THEN 'INACTIVE' ELSE NULL END,
	   SYSDATE
	   );
	   
  
  ELSE 
   UPDATE TPA_HOSP_PROFESSIONALS
   SET USER_GENERAL_TYPE_ID      = V_USER_GENERAL_TYPE_ID,
       HOSP_SEQ_ID               = V_HOSP_SEQ_ID,
       CONTACT_NAME              = V_CONTACT_NAME,
       PROFESSIONAL_ID           = V_PROFESSIONAL_ID,
       PROF_AUTHORITY            = V_PROF_AUTHORITY,
       GENDER_GENERAL_TYPE       = V_GENDER_GENERAL_TYPE,
       AGE                       = V_AGE,
       CONSULT_GEN_TYPE          = V_CONSULT_GEN_TYPE,
       VALID_FROM_DATE           = V_VALID_FROM_DATE,
       VALID_TO_DATE             = V_VALID_TO_DATE,
       PRIMARY_EMAIL_ID          = V_PRIMARY_EMAIL_ID,
       ACTIVE_YN                 = V_ACTIVE_YN,
       ISD_CODE                  = V_ISD_CODE,
       STD_CODE                  = V_STD_CODE,
       OFF_PHONE_NO_1            = V_OFF_PHONE_NO_1,
       OFF_PHONE_NO_2            = V_OFF_PHONE_NO_2,
       MOBILE_NO                 = V_MOBILE_NO,
       FAX_NO                    = V_FAX_NO,
       NATIONALITY_ID            = V_NATIONALITY_ID,
       PROF_FILE_NAME            = V_PROF_FILE_NAME,
       PROF_FILE                 = V_PROF_FILE,
       UPDATED_DATE              = SYSDATE,
       UPDATED_BY                = V_ADDED_BY,
       SPECIALITY_ID             = V_SPECIALITY_ID 
       where CONTACT_SEQ_ID = V_CONTACT_SEQ_ID;                        

		UPDATE APP.dha_clinicians_list_master 
		SET CLINITIAN_ID=V_PROFESSIONAL_ID,
		PROFESSIONAL_NAME=V_CONTACT_NAME,
    CLINI_STANDARD='QHA',
		STATUS=CASE WHEN V_ACTIVE_YN='Y' THEN 'ACTIVE'
	   WHEN V_ACTIVE_YN='N' THEN 'INACTIVE' ELSE NULL END,
	   UPDATED_DATE=SYSDATE
	   WHERE CLINI_SEQ_ID=V_CONTACT_SEQ_ID;
		
		

END IF;
v_rows_processed := SQL%ROWCOUNT;
COMMIT;
END SAVE_HOSP_PROFESSIONALS;
----------------------
PROCEDURE hosp_docotors_upload( v_hosp_doc   clob,v_log_file  out clob)
  IS
  
  v_doc                         DBMS_XMLDOM.DOMDocument;
  v_elem                        DBMS_XMLDOM.DOMElement;
  v_elem1                       DBMS_XMLDOM.DOMElement;
  v_elem2                       DBMS_XMLDOM.DOMElement;
  v_elem3                       DBMS_XMLDOM.DOMElement;
  v_root_node_list              DBMS_XMLDOM.DOMNODELIST;
  v_parent_node_lst             DBMS_XMLDOM.DOMNODELIST;
  v_chld_node_list              DBMS_XMLDOM.DOMNODELIST;  
  v_parent_node                 DBMS_XMLDOM.domnode;
  v_chaild_node                 DBMS_XMLDOM.domnode;
  v_root_node                   DBMS_XMLDOM.domnode;
  v_xml_doc                     xmltype;
  contact_rec                   tpa_hosp_professionals%rowtype;
  batch_rec                     tpa_professional_batch_dtls%rowtype;
  v_gender_type                 tpa_general_code.description%type;
  v_user_id                     tpa_login_info.user_id%type;
  v_row_processed               number;
  v_hossp_doc   clob;--for testing
  V_PROF_BATCH_SEQ_ID            tpa_professional_batch_dtls.PROF_BATCH_SEQ_ID%TYPE;
  V_PROVIDER_LOG_SEQ_ID          TPA_PROVIDER_LOGS.PROVIDER_LOG_SEQ_ID%type;  
  v_cons_desc                    TPA_GENERAL_CODE.DESCRIPTION%TYPE;
  v_spec_desc                    DHA_CLNSN_SPECIALTIES_MASTER.SPECIALTY%type;
 
  v_authority     varchar2(10);

  CURSOR prof_logs(v_bach_seqid NUMBER) IS 
    SELECT ROW_NUMBER() OVER (ORDER BY professional_id NULLS FIRST) AS SL_NO,
           professional_id,error_message  
     FROM tpa_provider_logs p 
     JOIN tpa_professional_batch_dtls bd on (bd.prof_batch_seq_id=p.prof_batch_seq_id)
    WHERE bd.prof_batch_seq_id=v_bach_seqid;

  Cursor dhpo_prof(v_prof_id  varchar2) is 
   SELECT m.professional_name,m.clinitian_id 
    FROM app.dha_clinicians_list_master m 
   WHERE m.clinitian_id=v_prof_id;
   
  prof_rec    dhpo_prof%rowtype; 
      
   CURSOR pre_prof_cur(v_professional_id  VARCHAR2) IS 
     SELECT c.valid_from_date,c.valid_to_date,c.hosp_seq_id 
       FROM tpa_hosp_professionals c 
     WHERE c.professional_id=v_professional_id;
   pre_prof_rec   pre_prof_cur%rowtype;    
      
  v_reg_auth_check                      VARCHAR2(100);
  v_cons                                APP.TPA_GENERAL_CODE.GENERAL_TYPE_ID%type;
  v_spec                                app.DHA_CLNSN_SPECIALTIES_MASTER.SPECIALTY_ID%type;
  V_CNT                                 NUMBER(10);
  V_AUT_CNT                             NUMBER(10);
  v_error_msg                           VARCHAR2(4000);
  v_nationality                         VARCHAR2(1000);
  v_valid_from_date                     VARCHAR2(100);
  v_valid_to_date                       VARCHAR2(100);

     
BEGIN
  --select t.xml_col into v_hossp_doc from xml_test t;--for testing
  --v_xml_doc:=xmltype(v_hosp_doc);
  v_xml_doc := XMLTYPE.createXML(v_hosp_doc);
  v_doc            := dbms_xmldom.newdomdocument(v_xml_doc);
  v_root_node_list := dbms_xmldom.getelementsbytagname(v_doc, 'provider');
  for v_root_node_index in 0 .. dbms_xmldom.getlength(v_root_node_list) - 1 loop
    v_root_node := dbms_xmldom.item(v_root_node_list, v_root_node_index);
    v_elem        := dbms_xmldom.makeelement(v_root_node);
     v_parent_node_lst := dbms_xmldom.getelementsbytagname(v_elem, 'batch');
    for parent_node_index in 0 .. dbms_xmldom.getlength(v_parent_node_lst) - 1 loop
      v_parent_node := dbms_xmldom.item(v_parent_node_lst, parent_node_index);
      v_elem1    := dbms_xmldom.makeelement(v_parent_node);        
      batch_rec.batch_number:=dbms_xmldom.getAttribute(v_elem1,'batchno');
      batch_rec.hosp_seq_id:= dbms_xmldom.getAttribute(v_elem1,'hospseqid');
      batch_rec.added_by:=dbms_xmldom.getAttribute(v_elem1,'uploadedby');
      batch_rec.num_of_rows:=dbms_xmldom.getAttribute(v_elem1,'noofrows');
      batch_rec.batch_date:=sysdate;
      INSERT INTO tpa_professional_batch_dtls(PROF_BATCH_SEQ_ID,HOSP_SEQ_ID,BATCH_NUMBER,BATCH_DATE
                  ,num_of_rows,added_by,added_date)
            VALUES(tpa_prof_batch_dtls_seq.NEXTVAL,batch_rec.hosp_seq_id,batch_rec.batch_number,
                   batch_rec.batch_date,batch_rec.num_of_rows,batch_rec.added_by,batch_rec.batch_date) RETURNING PROF_BATCH_SEQ_ID  INTO V_PROF_BATCH_SEQ_ID ;
     COMMIT;
    end loop;
    v_chld_node_list := dbms_xmldom.getelementsbytagname(v_elem, 'professional');
    for child_node_index in 0 .. dbms_xmldom.getlength(v_chld_node_list) - 1 loop
      v_chaild_node := dbms_xmldom.item(v_chld_node_list, child_node_index);
      v_elem2    := dbms_xmldom.makeelement(v_chaild_node);      
      
  begin
     
   
      contact_rec:=null;
      v_error_msg:=null;
      contact_rec.CONTACT_SEQ_ID:=0;
      --contact_rec.hosp_seq_id:= dbms_xmldom.getAttribute(v_elem2,'hospseqid');
      contact_rec.professional_id:= dbms_xmldom.getAttribute(v_elem2,'profid');
      contact_rec.contact_name:= dbms_xmldom.getAttribute(v_elem2,'profname');
      contact_rec.gender_general_type:=get_gen_codes('GEN','GEN', dbms_xmldom.getAttribute(v_elem2,'gender'));     
      contact_rec.Age:= dbms_xmldom.getAttribute(v_elem2,'age');
      contact_rec.prof_authority:= get_gen_codes('GEN','AUTH',dbms_xmldom.getAttribute(v_elem2,'authority'));
      contact_rec.Primary_Email_Id:= dbms_xmldom.getAttribute(v_elem2,'primarmailid');
      contact_rec.Off_Phone_No_1:= dbms_xmldom.getAttribute(v_elem2,'officephone1');
      contact_rec.Off_Phone_No_2:= dbms_xmldom.getAttribute(v_elem2,'officephone2');
      contact_rec.fax_no:= dbms_xmldom.getAttribute(v_elem2,'fax');
      contact_rec.Mobile_No:= dbms_xmldom.getAttribute(v_elem2,'mobileno');
      
      v_nationality := dbms_xmldom.getAttribute(v_elem2,'nationality');
      contact_rec.Nationality_Id:=get_gen_codes('NAT',NULL, dbms_xmldom.getAttribute(v_elem2,'nationality'));
      
      contact_rec.consult_gen_type:=get_gen_codes('GEN','CONS',dbms_xmldom.getAttribute(v_elem2,'consultationtype'));
      contact_rec.speciality_id:= get_spec_codes(dbms_xmldom.getAttribute(v_elem2,'specialist'));
      v_cons_desc:=dbms_xmldom.getAttribute(v_elem2,'consultationtype');
      v_spec:=dbms_xmldom.getAttribute(v_elem2,'specialist');
      
     OPEN  dhpo_prof(contact_rec.professional_id);
     FETCH dhpo_prof INTO prof_rec;
     CLOSE dhpo_prof;
     
     OPEN  pre_prof_cur(contact_rec.professional_id);
     FETCH pre_prof_cur INTO pre_prof_rec;
     CLOSE pre_prof_cur; 

    
  IF (contact_rec.professional_id  IS NULL) then
    v_error_msg := 'please enter the Clinician ID.';
    --save_provider_logs(v_provider_log_seq_id,null,batch_rec.hosp_seq_id,contact_rec.professional_id,contact_rec.contact_name,contact_rec.prof_authority,'121','please enter the Professional ID','D',batch_rec.added_by,v_prof_batch_seq_id);
  END IF;
  IF(contact_rec.contact_name IS NULL ) THEN
   	 v_error_msg := v_error_msg||';'||'please enter the Clinician Name.';
     --save_provider_logs(v_provider_log_seq_id,null,batch_rec.hosp_seq_id,contact_rec.professional_id,contact_rec.contact_name,contact_rec.prof_authority,'201','please enter the Professional Name','D',batch_rec.added_by,v_prof_batch_seq_id);
  END IF;
  IF(v_cons_desc  IS NULL ) THEN
    v_error_msg := v_error_msg||';'||'please enter the Consultation Type.';
    --save_provider_logs(v_provider_log_seq_id,null,batch_rec.hosp_seq_id,contact_rec.professional_id,contact_rec.contact_name,contact_rec.prof_authority,'141','please enter the Consult GenType','D',batch_rec.added_by,v_prof_batch_seq_id);
  END IF;
  IF(v_spec IS NULL ) THEN
   v_error_msg := v_error_msg||';'||'please enter the Speciality.';
   --save_provider_logs(v_provider_log_seq_id,null,batch_rec.hosp_seq_id,contact_rec.professional_id,contact_rec.contact_name,contact_rec.prof_authority,'151','please enter the Speciality ID','D',batch_rec.added_by,v_prof_batch_seq_id);
  END IF;
    --Consultation Type Validation
  IF v_cons_desc IS NOT NULL AND contact_rec.consult_gen_type IS NULL THEN
     v_error_msg := v_error_msg||';'||'please choose the valid  Consultation Type.';
     --save_provider_logs(v_provider_log_seq_id,null,batch_rec.hosp_seq_id,contact_rec.professional_id,contact_rec.contact_name,contact_rec.prof_authority,'11','please choose the valid  Consult GenType','D',batch_rec.added_by,v_prof_batch_seq_id);
  END IF;
  --specil_list_type Type Validation
  IF v_spec is  not null AND contact_rec.speciality_id is null then
      v_error_msg := v_error_msg||';'||'please choose the valid  Specialty.';
      --save_provider_logs(v_provider_log_seq_id,null,batch_rec.hosp_seq_id,contact_rec.professional_id,contact_rec.contact_name,contact_rec.prof_authority,'11','please choose the valid  Specialty','D',batch_rec.added_by,v_prof_batch_seq_id);
  END  IF;

  /*IF v_nationality IS NULL THEN
    v_error_msg := v_error_msg||';'||'please choose the valid  Nationality.';
  END IF;*/
  
   BEGIN
     v_valid_from_date                := dbms_xmldom.getAttribute(v_elem2,'startdate');
     contact_rec.valid_from_date      := to_date(dbms_xmldom.getAttribute(v_elem2,'startdate'),'dd/mm/yyyy');
    EXCEPTION 
       WHEN OTHERS THEN
      v_error_msg := v_error_msg||';'||'Invalid date format for valid from date.';
    END;
    -----
    BEGIN
     v_valid_to_date                   := dbms_xmldom.getAttribute(v_elem2,'enddate');
     contact_rec.valid_to_date         := to_date(dbms_xmldom.getAttribute(v_elem2,'enddate'),'dd/mm/yyyy');
    EXCEPTION 
       WHEN OTHERS THEN
      v_error_msg := v_error_msg||';'||'Invalid date format for valid to date.';
    END;
   
   IF contact_rec.valid_from_date >  contact_rec.valid_to_date THEN
     v_error_msg := v_error_msg||';'||'Start date can''t be greater than end date.';
   ELSIF TRUNC(contact_rec.valid_from_date) > TRUNC (SYSDATE) THEN
     v_error_msg := v_error_msg||';'||'Start date can''t be greater than current date.';
   END IF;
 
  IF((contact_rec.professional_id IS NOT NULL) AND 
  	 (contact_rec.speciality_id IS NOT NULL) AND
     (contact_rec.consult_gen_type IS NOT NULL)AND 
     (contact_rec.contact_name IS NOT NULL)) THEN
                            
      select ho.regist_authority into V_reg_auth_check from app.tpa_hosp_info ho where ho.hosp_seq_id=batch_rec.hosp_seq_id;

   IF contact_rec.professional_id IS NOT NULL AND batch_rec.hosp_seq_id IS NOT NULL and  NVL(contact_rec.contact_seq_id, 0)=0 THEN 
     SELECT COUNT(1) INTO V_CNT from app.tpa_hosp_professionals p WHERE p.professional_id=contact_rec.professional_id and p.hosp_seq_id=batch_rec.hosp_seq_id;
    /*SELECT COUNT(1) INTO v_aut_cnt from app.dha_clinicians_list_master lm where lm.clinitian_id=contact_rec.professional_id;
  -- IF v_aut_cnt=0 and V_reg_auth_check='DHA' THEN
  --   v_error_msg := v_error_msg||';'||'Professional id is not matching with DHPO.';*/
     --save_provider_logs(v_provider_log_seq_id,null,batch_rec.hosp_seq_id,contact_rec.professional_id,contact_rec.contact_name,contact_rec.prof_authority,'11','Professional id is not matching with DHPO .','D',batch_rec.added_by,v_prof_batch_seq_id);
   IF V_CNT>0 and V_reg_auth_check IN ('PRIV','GOVT') THEN
        v_error_msg := v_error_msg||';'||'Professional already associated  with this Provider.';
        --save_provider_logs(v_provider_log_seq_id,null,batch_rec.hosp_seq_id,contact_rec.professional_id,contact_rec.contact_name,contact_rec.prof_authority,'11','Professional already associated  with this Provider.','D',batch_rec.added_by,v_prof_batch_seq_id);
   END IF;
      OPEN pre_prof_cur(contact_rec.professional_id);
      FETCH pre_prof_cur INTO pre_prof_rec;
      close pre_prof_cur;
       IF pre_prof_rec.hosp_seq_id!=batch_rec.hosp_seq_id THEN
         IF trunc(nvl(contact_rec.valid_from_date,SYSDATE)) BETWEEN pre_prof_rec.valid_from_date AND nvl(pre_prof_rec.valid_to_date,sysdate) AND 
           contact_rec.consult_gen_type NOT IN ('VCPH','CMPH')THEN
           v_error_msg := v_error_msg||';'||'This License number is already associated  with another Provider.';
           --save_provider_logs(v_provider_log_seq_id,null,batch_rec.hosp_seq_id,contact_rec.professional_id,contact_rec.contact_name,contact_rec.prof_authority,'11','This License number is already associated  with another Provider.','D',batch_rec.added_by,v_prof_batch_seq_id);
         END IF;
      END IF;
   END IF;
  IF NVL(contact_rec.contact_seq_id, 0) = 0 AND v_error_msg IS NULL THEN
    INSERT INTO TPA_HOSP_PROFESSIONALS
      (CONTACT_SEQ_ID,
       USER_GENERAL_TYPE_ID,
       HOSP_SEQ_ID,
       CONTACT_NAME,
       PROFESSIONAL_ID,
       PROF_AUTHORITY,
       GENDER_GENERAL_TYPE,
       AGE,
       CONSULT_GEN_TYPE,
       VALID_FROM_DATE,
       VALID_TO_DATE,
       PRIMARY_EMAIL_ID,
       ACTIVE_YN,
       ISD_CODE,
       STD_CODE,
       OFF_PHONE_NO_1,
       OFF_PHONE_NO_2,
       MOBILE_NO,
       FAX_NO,
       NATIONALITY_ID,
       PROF_FILE_NAME,
       PROF_FILE,
       ADDED_DATE,
       ADDED_BY,
       SPECIALITY_ID)
    VALUES
      (TPA_HOSP_PROFESSIONALS_SEQ.NEXTVAL,
       contact_rec.User_General_Type_Id,
       batch_rec.HOSP_SEQ_ID,
       contact_rec.contact_name,
       contact_rec.professional_id,
       contact_rec.prof_authority,
       contact_rec.gender_general_type,
       contact_rec.age,
       contact_rec.CONSULT_GEN_TYPE,
       contact_rec.VALID_FROM_DATE,
       contact_rec.VALID_TO_DATE,
       contact_rec.PRIMARY_EMAIL_ID,
       contact_rec.ACTIVE_YN,
       contact_rec.ISD_CODE,
       contact_rec.STD_CODE,
       contact_rec.OFF_PHONE_NO_1,
       contact_rec.OFF_PHONE_NO_2,
       contact_rec.MOBILE_NO,
       contact_rec.FAX_NO,
       contact_rec.NATIONALITY_ID,
       contact_rec.PROF_FILE_NAME,
       contact_rec.PROF_FILE,
       SYSDATE,
       batch_rec.ADDED_BY,
       contact_rec.SPECIALITY_ID)RETURNING CONTACT_SEQ_ID INTO contact_rec.contact_seq_id;
  END IF;                  
    END IF;
   IF v_error_msg IS NOT NULL THEN
     v_error_msg := TRIM(BOTH ';' FROM (v_error_msg));
     save_provider_logs(v_provider_log_seq_id,null,batch_rec.hosp_seq_id,contact_rec.professional_id,contact_rec.contact_name,contact_rec.prof_authority,NULL,v_error_msg,'D',batch_rec.added_by,v_prof_batch_seq_id);
   END IF;
   END;
  END LOOP;
 END LOOP;
  
 IF v_error_msg IS NULL THEN
   v_log_file:= nvl(v_log_file,'Clinician details uploaded successfully');
 ELSE 
  FOR i in prof_logs(v_prof_batch_seq_id)
    LOOP
       IF v_log_file IS NOT NULL THEN 
        v_log_file  := v_log_file||chr(10)||' '||i.sl_no||': '||CASE WHEN i.professional_id IS NULL THEN NULL
                                                                     ELSE 'For Professional ID '||i.professional_id||':- ' END||' '||i.error_message||';'||chr(10);
       ELSE
        v_log_file  := v_log_file||' '||i.sl_no||': '||CASE WHEN i.professional_id IS NULL THEN NULL
                                                                     ELSE 'For Professional ID '||i.professional_id||':- ' END||' '||i.error_message||';'||chr(10); 
       END IF;
    END LOOP;
 END IF;   
    
END hosp_docotors_upload;
--------------------------------
--------------------------------
FUNCTION get_gen_codes(v_flag               VARCHAR2,
                       v_header             varchar2,
                       v_description        tpa_general_code.description%type)
RETURN VARCHAR2
IS
v_sql_str              clob;
v_result_set           sys_refcursor;
v_result               TPA_GENERAL_CODE.DESCRIPTION%TYPE;

CURSOR nationality_cur IS
SELECT a.nationality_id FROM tpa_nationalities_code a
where UPPER(a.description)=UPPER(v_description);


BEGIN
  
 IF v_flag='NAT' THEN
   OPEN nationality_cur;
   FETCH nationality_cur INTO v_result;
   CLOSE nationality_cur;
 ELSE
  v_sql_str:='SELECT tgc.general_type_id FROM tpa_general_code tgc
                   where UPPER(tgc.description)=UPPER((:v_description))';
   IF v_header='GEN' THEN
    v_sql_str:=v_sql_str||' and tgc.header_type=''GENDER_DETAILS''';
   ELSIF v_header='AUTH' THEN
       v_sql_str:=v_sql_str||' and tgc.header_type=''AUTHORITY_TYPE''';
   ELSIF v_header='CONS' THEN
       v_sql_str:=v_sql_str||' and tgc.header_type=''CONSULTATION_TYPE''';  
   END IF;
  
  OPEN v_result_set FOR  v_sql_str USING v_description;
  FETCH v_result_set INTO v_result;
  CLOSE v_result_set;
  
  END IF;
  RETURN v_result;
  
END get_gen_codes;
-------------------------------------
PROCEDURE save_provider_logs(
    V_PROVIDER_LOG_SEQ_ID                IN  TPA_PROVIDER_LOGS.PROVIDER_LOG_SEQ_ID%TYPE,
    V_TPA_OFICE_SEQ_ID                   IN  TPA_PROVIDER_LOGS.TPA_OFFICE_SEQ_ID%TYPE,
    V_HOSP_SEQ_ID                        IN  TPA_PROVIDER_LOGS.HOSP_SEQ_ID%TYPE,
    V_PROFESSIONAL_ID                    IN  TPA_PROVIDER_LOGS.PROFESSIONAL_ID%TYPE,
    V_PROF_NAME                          IN  TPA_PROVIDER_LOGS.PROF_NAME%TYPE,
    V_AUTHORITY                          IN  TPA_PROVIDER_LOGS.AUTHORITY%TYPE,
    V_ERROR_NO                           IN  TPA_PROVIDER_LOGS.ERROR_NO%TYPE,
    V_ERROR_MESSAGE                      IN  TPA_PROVIDER_LOGS.ERROR_MESSAGE%TYPE,
    V_ERROR_TYPE                         IN  TPA_PROVIDER_LOGS.ERROR_TYPE%TYPE,
    V_ADDED_BY                           IN  TPA_PROVIDER_LOGS.ADDED_BY%TYPE,
    V_PROF_BATCH_SEQ_ID                  IN  NUMBER
   )
  IS
    PRAGMA AUTONOMOUS_TRANSACTION ;
  BEGIN
      INSERT INTO TPA_PROVIDER_LOGS(
        PROVIDER_LOG_SEQ_ID,
        ERROR_LOGGED_DATE,
        TPA_OFFICE_SEQ_ID,
        HOSP_SEQ_ID,
        PROFESSIONAL_ID,
        PROF_NAME,
        AUTHORITY,
        ERROR_NO,
        ERROR_MESSAGE,
        ERROR_TYPE,
        ADDED_BY,
        ADDED_DATE,
        PROF_BATCH_SEQ_ID)
    VALUES (
        TPA_PROVIDER_LOGS_SEQ.NEXTVAL,
        SYSDATE,
        V_TPA_OFICE_SEQ_ID,
        V_HOSP_SEQ_ID,
        V_PROFESSIONAL_ID,
        V_PROF_NAME,
        V_AUTHORITY,
        v_error_no * -1,
        v_error_message,
        'D',----DOCTOR
        V_ADDED_BY,
        SYSDATE ,
        V_PROF_BATCH_SEQ_ID);

    COMMIT;
    
    /*IF v_error_no != 0 THEN
      raise_application_error(v_error_no, v_error_message) ;
    END IF;*/
  END save_provider_logs;
-----------========================================================
procedure get_provider_logs(v_file_id       IN  VARCHAR2,
                            V_LOGS          OUT SYS_REFCURSOR,
                            V_HOSP_NAME    OUT tpa_hosp_info.hosp_name%type)
is
begin
  SELECT distinct ii.hosp_name INTO v_hosp_name FROM APP.TPA_PROVIDER_LOGS P JOIN APP.TPA_HOSP_INFO II ON 
 (P.HOSP_SEQ_ID=P.HOSP_SEQ_ID)
WHERE P.PROF_BATCH_SEQ_ID=v_file_id ;
  OPEN v_logs FOR 
  SELECT P.PROFESSIONAL_ID,P.AUTHORITY FROM APP.TPA_PROVIDER_LOGS P 
 WHERE P.PROF_BATCH_SEQ_ID=v_file_id;
end;
----------------------------------------------------
PROCEDURE save_tariff_logs(V_TARIFF_LOG_SEQ_ID IN TPA_TARIFF_LOGS.TARIFF_LOG_SEQ_ID%TYPE,
                           V_HOSP_SEQ_ID       IN TPA_TARIFF_LOGS.HOSP_LICENCE_NUM%TYPE,
                           V_INS_SEQ_ID        IN TPA_TARIFF_LOGS.INS_ID%TYPE,
                           V_GROUP_REG_SEQ_ID  IN TPA_TARIFF_LOGS.GROUP_ID%TYPE,
                           V_ACT_CODE          IN TPA_TARIFF_LOGS.ACT_CODE%TYPE,
                           V_ERROR_NO          IN TPA_TARIFF_LOGS.ERROR_NO%TYPE,
                           V_ERROR_MESSAGE     IN TPA_TARIFF_LOGS.ERROR_MESSAGE%TYPE,
                           V_ERROR_TYPE        IN TPA_TARIFF_LOGS.ERROR_TYPE%TYPE,
                           V_ADDED_BY          IN TPA_TARIFF_LOGS.ADDED_BY%TYPE,
                           V_TPA_BATCH_SEQ_ID  IN NUMBER) IS
  PRAGMA AUTONOMOUS_TRANSACTION;
BEGIN
  INSERT INTO TPA_TARIFF_LOGS
    (TARIFF_LOG_SEQ_ID,
     ERROR_LOGGED_DATE,
     HOSP_LICENCE_NUM,
     INS_ID,
     GROUP_ID,
     ACT_CODE,
     ERROR_NO,
     ERROR_MESSAGE,
     ERROR_TYPE,
     ADDED_BY,
     ADDED_DATE,
     TARIFF_BATCH_SEQ_ID)
  VALUES
    (TPA_TARIFF_LOGS_SEQ.NEXTVAL,
     SYSDATE,
     V_HOSP_SEQ_ID,
     V_INS_SEQ_ID,
     V_GROUP_REG_SEQ_ID,
     V_ACT_CODE,
     v_error_no * -1,
     v_error_message,
     'T', ----tariff
     V_ADDED_BY,
     SYSDATE,
     V_tpa_batch_seq_id);

  COMMIT;

END save_tariff_logs;
--------------------------------------------------------
PROCEDURE select_tariff_list (
    v_tariff_flag                        IN VARCHAR2,----HOSP,INS,COR
    v_seq_id                             IN TPA_HOSP_TARIFF_DETAILS.HOSP_SEQ_ID%TYPE,--hosp_seq_id,ins_seq_id,group_reg_seq_id
    v_price_ref_no                       IN VARCHAR2,
    v_ins_seq_id                         IN NUMBER,
    v_act_code                           IN VARCHAR2,
    v_service_seq_id                     IN NUMBER,
    v_interna_code                       IN VARCHAR2,
    v_network_type                       IN VARCHAR2,  
    v_sort_var                           IN VARCHAR2,
    v_sort_order                         IN VARCHAR2,
    v_start_num                          IN NUMBER ,
    v_end_num                            IN NUMBER,
    v_added_by                           IN NUMBER,
    v_end_date                           IN VARCHAR2,
    result_set                           OUT SYS_REFCURSOR

  )
  IS
    v_sql_str                            VARCHAR2(6000);
    v_where                              VARCHAR2(3000);
    TYPE bind_tab_type IS TABLE OF VARCHAR2(250) INDEX BY BINARY_INTEGER ;
    bind_tab                             bind_tab_type;
    i                                    NUMBER(2) := 0;
    v_end_date1                          DATE;
  BEGIN
 
 v_end_date1 := TO_DATE(v_end_date, 'DD/MM/YYYY');
 if v_tariff_flag='HOSP' THEN
    v_sql_str :=
        'select b.price_ref_number,
         b.hosp_tariff_seq_id as tariff_seq_id,
         c.activity_code,
         d.service_name,
         b.hosp_seq_id,
         b.gross_amount,
         b.disc_amount,
         b.disc_percent as disc_percentage,
         b.network_type ,
         b.internal_code,
         NVL(TO_CHAR(b.end_date, ''dd/mm/yyyy''), ''NA'') as end_date,
         ''HOSP'' AS tariff_type,
         b.hosp_act_desc 
        from tpa_hosp_tariff_details b 
        left outer join app.tpa_activity_master_details c on (c.act_mas_dtl_seq_id=b.activity_seq_id)
        left outer join app.tpa_service_details d on (d.service_seq_id=b.service_seq_id)
        where c.service_seq_id not in (14, 7)';
        
  ELSIF v_tariff_flag='INS' THEN
     v_sql_str :=
        'select b.price_ref_number,
         c.activity_code,
         b.ins_tariff_seq_id as tariff_seq_id,
         d.service_name,
         b.ins_seq_id,
         b.gross_amount,
         b.disc_amount,
         b.disc_percent as disc_percentage,
         b.network_type,
         b.internal_code,
         NVL(TO_CHAR(b.end_date, ''dd/mm/yyyy''), ''NA'') as end_date,
         ''INS'' AS tariff_type,
         b.hosp_act_desc 
        from  tpa_ins_tariff_details b 
        left outer join app.tpa_activity_master_details c on (c.act_mas_dtl_seq_id=b.activity_seq_id)
        left outer join app.tpa_service_details d on (d.service_seq_id=b.service_seq_id)';
 ELSIF v_tariff_flag='COR' THEN
     v_sql_str :=
         'select b.price_ref_number,
          c.activity_code,
          b.corp_tariff_seq_id as tariff_seq_id,
          d.service_name,
          b.group_reg_seq_id,
          b.gross_amount,
          b.disc_amount,
          b.disc_percent as disc_percentage,
          b.network_type,
          b.internal_code,
          NVL(TO_CHAR(b.end_date, ''dd/mm/yyyy''), ''NA'') as end_date,
          ''COR'' AS tariff_type,
          b.hosp_act_desc 
          from  tpa_corp_tariff_details b 
          left outer join app.tpa_activity_master_details c on (c.act_mas_dtl_seq_id=b.activity_seq_id)
          left outer join app.tpa_service_details d on (d.service_seq_id=b.service_seq_id)';
  ELSIF v_tariff_flag='TPA' THEN
     v_sql_str :=
        'select b.price_ref_number,
         c.activity_code,
         b.TPA_TARIFF_SEQ_ID as tariff_seq_id,
         d.service_name,
         b.ins_seq_id,
         b.gross_amount,
         b.disc_amount,
         b.disc_percent as disc_percentage,
         B.network_type,
         b.internal_code,
         NVL(TO_CHAR(b.end_date, ''dd/mm/yyyy''), ''NA'') as end_date,
         ''TPA'' AS tariff_type,
         B.hosp_act_desc 
        from  tpa_tariff_details b 
        left outer join app.tpa_activity_master_details c on (c.act_mas_dtl_seq_id=b.activity_seq_id)
        left outer join app.tpa_service_details d on (d.service_seq_id=b.service_seq_id)';
 END IF;
       IF v_seq_id IS NOT NULL THEN
         IF v_tariff_flag='HOSP' THEN
         v_where := v_where ||' AND b.hosp_seq_id = :v_seq_id ';
         i := i+1;
         bind_tab(i) := v_seq_id ;
         ELSIF v_tariff_flag='INS' THEN
          v_where := v_where ||' AND b.ins_seq_id = :v_seq_id ';
          i := i+1;
          bind_tab(i) := v_seq_id ;
         ELSIF v_tariff_flag='COR' THEN
          v_where := v_where ||' AND b.group_reg_seq_id = :v_seq_id ';
          i := i+1;
          bind_tab(i) := v_seq_id ;
         ELSIF v_tariff_flag='TPA' THEN
          v_where := v_where ;
        END IF;
       END IF;

       IF v_price_ref_no IS NOT NULL THEN
         v_where := v_where  ||' AND b.price_ref_number = :v_price_ref_no ';
         i := i+1;
         bind_tab(i) := UPPER(v_price_ref_no) ;
       END IF;
       IF v_ins_seq_id IS NOT NULL THEN
         v_where := v_where  ||' AND b.ins_seq_id = :v_ins_seq_id ';
         i := i+1;
         bind_tab(i) := v_ins_seq_id ;
       END IF;
       
       IF v_act_code IS NOT NULL THEN
         v_where := v_where  ||' AND c.activity_code = :v_act_code ';
         i := i+1;
         bind_tab(i) := UPPER(v_act_code) ;
       END IF;
       IF v_service_seq_id IS NOT NULL THEN
         v_where := v_where  ||' AND b.service_seq_id = :v_service_seq_id ';
         i := i+1;
         bind_tab(i) := v_service_seq_id ;
       END IF;
       IF v_interna_code IS NOT NULL THEN
         v_where := v_where  ||' AND upper(b.Internal_Code) = :v_interna_code ';
         i := i+1;
         bind_tab(i) := UPPER(v_interna_code) ;
       END IF;
       
       IF v_network_type IS NOT NULL THEN
         v_where := v_where  ||' AND upper(b.network_type) = :v_network_type ';
         i := i+1;
         bind_tab(i) := UPPER(v_network_type) ;
       END IF;
      
       IF v_end_date IS NOT NULL THEN
         v_where := v_where  ||' AND b.end_date = TO_DATE(:v_end_date1) ';
         i := i+1;
         bind_tab(i) := v_end_date1 ;
       END IF;
       
       IF v_tariff_flag = 'HOSP' THEN
         IF v_where IS NOT NULL THEN
          v_sql_str := v_sql_str||' AND '|| substr(v_where,6);
         END IF;
       ELSE
         IF v_where IS NOT NULL THEN
          v_sql_str := v_sql_str||' WHERE '|| substr(v_where,6);
         END IF;
       END IF;
          
       v_sql_str := 'SELECT * FROM
            (SELECT A.*,DENSE_RANK() OVER (ORDER BY '||v_sort_var||' '||v_sort_order||',ROWNUM)
            Q FROM (' ||v_sql_str||') A ) WHERE Q>= :v_start_num  AND Q<= :v_end_num ' ;

   
    
    IF bind_tab.FIRST IS NOT NULL THEN
       CASE bind_tab.COUNT
         WHEN 1  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),v_start_num,v_end_num ;
         WHEN 2  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2) ,v_start_num ,v_end_num ;
         WHEN 3  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3),v_start_num ,v_end_num ;
         WHEN 4  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3),bind_tab(4),v_start_num ,v_end_num ;
         WHEN 5  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3),bind_tab(4),bind_tab(5),v_start_num ,v_end_num ;
         WHEN 6  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3),bind_tab(4),bind_tab(5),bind_tab(6),v_start_num ,v_end_num ;
         WHEN 7  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3),bind_tab(4),bind_tab(5),bind_tab(6),bind_tab(7),v_start_num ,v_end_num ;
         WHEN 8  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3),bind_tab(4),bind_tab(5),bind_tab(6),bind_tab(7),bind_tab(8), v_start_num ,v_end_num ;
        END CASE;
    ELSE
      OPEN result_set FOR v_sql_str USING v_start_num , v_end_num ;
    END IF;

  END select_tariff_list;
 ----------------------------------------------------------------------
 PROCEDURE select_tariff_item (
    v_tariff_flag                        IN VARCHAR2,----HOSP,INS,CORP
    v_tariff_seq_id                      IN TPA_HOSP_TARIFF_DETAILS.HOSP_TARIFF_SEQ_ID%TYPE,
    v_added_by                           IN NUMBER,
    result_set                           OUT SYS_REFCURSOR
  )
  IS
    v_sql_str                            VARCHAR2(6000);
    v_where                              VARCHAR2(3000);
    TYPE bind_tab_type IS TABLE OF VARCHAR2(250) INDEX BY BINARY_INTEGER ;
    bind_tab                             bind_tab_type;
    i                                    NUMBER(2) := 0;
  BEGIN
 
 if v_tariff_flag='HOSP' THEN
    OPEN result_set FOR 
    SELECT B.price_ref_number,
          c.activity_code,
         b.hosp_tariff_seq_id as tariff_seq_id,
         b.start_date,
         b.remarks,
         b.end_date,
         b.hosp_seq_id,
         b.ins_seq_id,
         b.internal_code,
         hi.hosp_name,
         ii.ins_comp_name,
         b.gross_amount,
         case when b.disc_percent > 0 then round(nvl((b.gross_amount * b.disc_percent /100), 0),3) else 0 end as disc_amount,
         b.disc_percent as disc_percentage,
         b.activity_seq_id,
         b.acitivity_type_seq_id,
         b.service_seq_id,
         d.service_name,
         B.network_type ,
         b.Package_Id,
         b.bundle_id,
         'HOSP' AS tariff_type,
         nvl(b.hosp_act_desc, c.short_description) as hosp_act_desc,
         null as group_reg_seq_id,
         null as group_name,
         null as group_id ,
         b.internal_desc as internal_desc
        from  tpa_hosp_tariff_details b LEFT OUTER JOIN TPA_HOSP_INFO HI ON (B.HOSP_SEQ_ID=HI.HOSP_SEQ_ID)
        JOIN TPA_INS_INFO II ON (B.INS_SEQ_ID=II.INS_SEQ_ID)
        left outer join app.tpa_activity_master_details c on (c.act_mas_dtl_seq_id=b.activity_seq_id)
        left outer join app.tpa_service_details d on (d.service_seq_id=b.service_seq_id)
        --left outer join app.tpa_hosp_package_dtls pd on (pd.pkg_seq_id=b.pkg_seq_id)
        --left outer join app.tpa_hosp_bundle_id_dtls id on (id.bundle_seq_id=b.bundle_seq_id)
        WHERE b.hosp_tariff_seq_id=v_tariff_seq_id;
  ELSIF v_tariff_flag='INS' THEN
     OPEN result_set FOR 
    SELECT B.Price_Ref_Number,
         c.activity_code,
         b.ins_tariff_seq_id as tariff_seq_id,
         b.internal_code,
         b.remarks,
         b.start_date,
         b.end_date,
         b.ins_seq_id,
         ii.ins_comp_name,
         b.gross_amount,
         b.disc_amount,
         b.disc_percent as disc_percentage,
         b.hosp_act_desc,
         b.activity_seq_id,
         b.acitivity_type_seq_id,
         b.service_seq_id,
         d.service_name,
         B.network_type ,
         b.Package_Id,
         b.bundle_id,
         'INS' AS tariff_type,
         null as group_reg_seq_id,
         null as group_name,
         null as group_id,
         null as hosp_seq_id,
         null as hosp_name,
         null as internal_desc
        from tpa_ins_tariff_details b 
        JOIN TPA_INS_INFO II ON (B.INS_SEQ_ID=II.INS_SEQ_ID)
        left outer join app.tpa_activity_master_details c on (c.act_mas_dtl_seq_id=b.activity_seq_id)
        left outer join app.tpa_service_details d on (d.service_seq_id=b.service_seq_id)
        --left outer join app.tpa_hosp_package_dtls pd on (pd.pkg_seq_id=b.pkg_seq_id)
        --left outer join app.tpa_hosp_bundle_id_dtls id on (id.bundle_seq_id=b.bundle_seq_id)
        WHERE b.ins_tariff_seq_id=v_tariff_seq_id;
 ELSIF v_tariff_flag='COR' THEN
     OPEN result_set FOR 
    SELECT B.Price_Ref_Number,
         c.activity_code,
         b.corp_tariff_seq_id as tariff_seq_id,
         b.internal_code,
         b.remarks,
         b.start_date,
         b.end_date,
         b.gross_amount,
         b.disc_amount,
         b.disc_percent as disc_percentage,
         b.activity_seq_id,
         b.acitivity_type_seq_id,
         b.service_seq_id,
         b.hosp_act_desc,
         d.service_name,
         gr.group_reg_seq_id,
         gr.group_name,
         gr.group_id,
         B.network_type ,
         b.Package_Id,
         b.bundle_id,
         'COR' AS tariff_type,
         null as ins_seq_id,
         null as ins_comp_name,
         null as hosp_seq_id,
         null as hosp_name,
         null as internal_desc
        from tpa_corp_tariff_details b 
        JOIN tpa_group_registration gr ON (b.group_reg_seq_id=gr.group_reg_seq_id)
        left outer join app.tpa_activity_master_details c on (c.act_mas_dtl_seq_id=b.activity_seq_id)
        left outer join app.tpa_service_details d on (d.service_seq_id=b.service_seq_id)
        --left outer join app.tpa_hosp_package_dtls pd on (pd.pkg_seq_id=b.pkg_seq_id)
       -- left outer join app.tpa_hosp_bundle_id_dtls id on (id.bundle_seq_id=b.bundle_seq_id)
        WHERE b.corp_tariff_seq_id=v_tariff_seq_id;
  ELSIF v_tariff_flag='TPA' THEN
     OPEN result_set FOR 
    SELECT B.Price_Ref_Number,
         c.activity_code,
         b.tpa_tariff_seq_id as tariff_seq_id,
         b.internal_code,
         b.remarks,
         b.start_date,
         b.end_date,
         b.gross_amount,
         b.disc_amount,
         b.disc_percent as disc_percentage,
         b.activity_seq_id,
         b.acitivity_type_seq_id,
         b.service_seq_id,
         b.hosp_act_desc,
         d.service_name,
         null as group_reg_seq_id,
         null as group_name,
         null as group_id,
         B.network_type ,
         b.Package_Id,
         b.bundle_id,
         'TPA' AS tariff_type,
         null as ins_seq_id,
         null as ins_comp_name,
         null as hosp_seq_id,
         null as hosp_name,
         null as internal_desc
        from tpa_tariff_details b 
        left outer join app.tpa_activity_master_details c on (c.act_mas_dtl_seq_id=b.activity_seq_id)
        left outer join app.tpa_service_details d on (d.service_seq_id=b.service_seq_id)
        --left outer join app.tpa_hosp_package_dtls pd on (pd.pkg_seq_id=b.pkg_seq_id)
       -- left outer join app.tpa_hosp_bundle_id_dtls id on (id.bundle_seq_id=b.bundle_seq_id)
        WHERE b.tpa_tariff_seq_id=v_tariff_seq_id;    
  END IF;
       

  END select_tariff_item;
 ----------------------------------------------------------------
 PROCEDURE delete_tariff_details (
   v_tariff_flag                      IN VARCHAR2,--HOSP,INS,CORP
   v_tariff_seq_id                    IN VARCHAR2 , -- Concatenated Sequence IDs.
   v_user_id                          IN NUMBER,
   v_rows_processed                   OUT NUMBER
   )
IS
         str_tab   Ttk_Util_Pkg.str_table_type;
BEGIN
  -- Calling Function from Ttk_Util_Pkg Package
    str_tab := Ttk_Util_Pkg.parse_str ( v_tariff_seq_id );

    FOR i IN str_tab.First..str_tab.LAST
    LOOP
         IF  v_tariff_flag='HOSP' THEN 
           
         DELETE FROM TPA_HOSP_TARIFF_DETAILS D
            WHERE D.HOSP_TARIFF_SEQ_ID = TO_NUMBER(str_tab(i));
            
         ELSIF v_tariff_flag='INS' THEN
         
         DELETE FROM TPA_INS_TARIFF_DETAILS D
            WHERE D.INS_TARIFF_SEQ_ID = TO_NUMBER(str_tab(i));
            
        ELSIF v_tariff_flag='COR' THEN
        
         DELETE FROM TPA_CORP_TARIFF_DETAILS D
            WHERE D.CORP_TARIFF_SEQ_ID = TO_NUMBER(str_tab(i));
        END IF;
    END LOOP;
    v_rows_processed := str_tab.LAST;
    COMMIT;
END delete_tariff_details;
---------------------------------------------------
PROCEDURE modify_service_item (
   v_tariff_flag                      IN VARCHAR2,--HOSP,INS,CORP
   v_tariff_seq_id                    IN VARCHAR2 , -- Concatenated Sequence IDs.
   v_disc_percent                     IN NUMBER,
   v_user_id                          IN NUMBER,
   v_rows_processed                   OUT NUMBER
   )
IS
         str_tab   Ttk_Util_Pkg.str_table_type;
         v_gross_amount      number(10,2);
         
         v_disc_amount        number(10,2);
BEGIN
  -- Calling Function from Ttk_Util_Pkg Package
    str_tab := Ttk_Util_Pkg.parse_str ( v_tariff_seq_id );
    FOR i IN str_tab.First..str_tab.LAST
    LOOP
         v_disc_amount:=0;
         IF  v_tariff_flag='HOSP' THEN
          select d.gross_amount into v_gross_amount from app.tpa_hosp_tariff_details d where d.hosp_tariff_seq_id=TO_NUMBER(str_tab(i));
       
       v_disc_amount:=round((v_disc_percent/100)*v_gross_amount,2);   
       
       update tpa_hosp_tariff_details a
            set a.disc_amount = v_disc_amount,
                a.disc_percent = v_disc_percent,
                a.updated_by  = v_user_id,
                a.updated_date = sysdate
            WHERE a.hosp_tariff_seq_id = TO_NUMBER(str_tab(i));
            
         ELSIF v_tariff_flag='INS' THEN
         select d.gross_amount into v_gross_amount from app.tpa_ins_tariff_details d where d.ins_tariff_seq_id=TO_NUMBER(str_tab(i));
          
           v_disc_amount:=round((v_disc_percent/100)*v_gross_amount,2);
         
         update tpa_ins_tariff_details a
            set a.disc_amount = v_disc_amount,
                a.disc_percent = v_disc_percent,
                a.updated_by  = v_user_id,
                a.updated_date = sysdate
            WHERE a.ins_tariff_seq_id = TO_NUMBER(str_tab(i));
            
        ELSIF v_tariff_flag='COR' THEN
        select d.gross_amount into v_gross_amount from app.tpa_corp_tariff_details d where d.corp_tariff_seq_id=TO_NUMBER(str_tab(i));
       
        v_disc_amount:=round((v_disc_percent/100)*v_gross_amount,2);
         
         update tpa_corp_tariff_details a
            set a.disc_amount  = v_disc_amount,
                a.disc_percent = v_disc_percent,
                a.updated_by   = v_user_id,
                a.updated_date = sysdate
            WHERE a.corp_tariff_seq_id = TO_NUMBER(str_tab(i));
        
         ELSIF v_tariff_flag='TPA' THEN
        select d.gross_amount into v_gross_amount from app.tpa_tariff_details d where d.tpa_tariff_seq_id=TO_NUMBER(str_tab(i));
       
        v_disc_amount:=round((v_disc_percent/100)*v_gross_amount,2);
         
         update tpa_tariff_details a
            set a.disc_amount  = v_disc_amount,
                a.disc_percent = v_disc_percent,
                a.updated_by   = v_user_id,
                a.updated_date = sysdate
            WHERE a.tpa_tariff_seq_id = TO_NUMBER(str_tab(i));
        END IF;
    END LOOP;
    v_rows_processed := str_tab.LAST;
    COMMIT;
END modify_service_item;
--==================================================================================
PROCEDURE modify_network_service_item (
   v_tariff_flag                      IN VARCHAR2,--HOSP,INS,CORP
   v_disc_list                        IN VARCHAR2,--',|12|CN|11|,|12|SN|22|,|20|CN|33|,|20|SN|44|,'
   v_user_id                          IN NUMBER,
   v_hosp_licence_num                 IN VARCHAR2,
   v_ins_id                           IN VARCHAR2,
   v_corp_id                          IN VARCHAR2,
   v_rows_processed                   OUT NUMBER 
   )
IS
         str_tab   Ttk_Util_Pkg.str_table_type;
         v_gross_amount      number(10,2);
         
         v_disc_amount        number(10,2);
         --v_service_seq_id     number;
  v_hosp_seq_id      number(10);
  v_ins_seq_id       number(10);
  v_group_reg_seq_id number(10);
    str_tab_nt ttk_util_pkg.str_table_type;--networktype
    str_tab_pd ttk_util_pkg.str_table_type;---providers
    str_tab_py ttk_util_pkg.str_table_type;---payers
    str_tab_cr ttk_util_pkg.str_table_type;---corporates 
    str_tab_sr ttk_util_pkg.str_table_type;---service type
    str_tab_per ttk_util_pkg.str_table_type;---percentage
    str_tab_dis ttk_util_pkg.str_table_type;
BEGIN 
  -- Calling Function from Ttk_Util_Pkg Package
  --delete app.temp_test;
  --insert into app.temp_test(error1)values(v_tariff_flag||' '||v_disc_list||' '||v_user_id||' '||v_hosp_licence_num||' '||v_ins_id||' '||v_corp_id);
  --commit;
  IF  v_tariff_flag='HOSP' THEN
     str_tab_pd := ttk_util_pkg.parse_str ( v_hosp_licence_num );
     str_tab_py := ttk_util_pkg.parse_str ( v_ins_id );
      FOR provider IN str_tab_pd.First..str_tab_pd.LAST  LOOP
         v_disc_amount:=0;
           v_hosp_seq_id :=  get_tariff_assoc_id('EMP', str_tab_pd(provider));
           v_ins_seq_id  := get_tariff_assoc_id('INS',str_tab_py(1) ); 
       str_tab_per := ttk_util_pkg.parse_string( v_disc_list ); 
      for rec in str_tab_per.first..str_tab_per.last
          loop
            str_tab_dis := ttk_util_pkg.parse_str( str_tab_per(rec) );
             for rec1 in str_tab_dis.first..str_tab_dis.last
              loop 
        for i in ( select d.gross_amount,d.service_seq_id,d.network_type,d.activity_seq_id
            from app.tpa_hosp_tariff_details d
           WHERE d.hosp_seq_id = trim(v_hosp_seq_id)
             and d.service_seq_id = trim(str_tab_dis(1))
             and d.network_type = trim(str_tab_dis(2))
             and d.ins_seq_id = v_ins_seq_id )loop
           v_disc_amount:=round((trim(str_tab_dis(3))/100)*i.gross_amount,2);   
          
          update tpa_hosp_tariff_details a
            set a.disc_amount = v_disc_amount,
                a.disc_percent = str_tab_dis(3),
                a.updated_by  = v_user_id,
                a.updated_date = sysdate
            WHERE a.hosp_seq_id = v_hosp_seq_id
              and a.service_seq_id = str_tab_dis(1)
              and a.network_type = str_tab_dis(2)
              and a.ins_seq_id = v_ins_seq_id
              and a.activity_seq_id=i.activity_seq_id; 
              
           commit;
          
          END LOOP;
           END LOOP;
            END LOOP;
             END LOOP; 
        v_rows_processed := '1'; 
       -- insert into app.temp_test(error2)values(v_rows_processed);     
   ELSIF v_tariff_flag='INS' THEN
     str_tab_py := ttk_util_pkg.parse_str ( v_ins_id );
      FOR payer IN str_tab_py.First..str_tab_py.LAST  LOOP
         v_disc_amount:=0;
         v_ins_seq_id  := get_tariff_assoc_id('INS', str_tab_py(payer));
         
     str_tab_per := ttk_util_pkg.parse_string( v_disc_list ); 
      for rec in str_tab_per.first..str_tab_per.last
          loop
            str_tab_dis := ttk_util_pkg.parse_str( str_tab_per(rec) );
             for rec1 in str_tab_dis.first..str_tab_dis.last
              loop
         for i in ( select d.gross_amount,d.service_seq_id,d.activity_seq_id
           from app.tpa_ins_tariff_details d
          WHERE d.ins_seq_id = v_ins_seq_id
            and d.service_seq_id = str_tab_dis(1)
            and d.network_type = trim(str_tab_dis(2))
            )loop
          
           v_disc_amount:=round((trim(str_tab_dis(3))/100)*v_gross_amount,2);
         
         update tpa_ins_tariff_details a
            set a.disc_amount = v_disc_amount,
                a.disc_percent = trim(str_tab_dis(3)),
                a.updated_by  = v_user_id,
                a.updated_date = sysdate
            WHERE a.service_seq_id = TO_NUMBER(i.service_seq_id)
                 and a.ins_seq_id = v_ins_seq_id
                 and a.service_seq_id = str_tab_dis(1)
                 and a.network_type = trim(str_tab_dis(2))
                 and a.ins_seq_id = v_ins_seq_id
                 and a.activity_seq_id=i.activity_seq_id;
             COMMIT;
          v_rows_processed := sql%rowcount;      
         END LOOP;
          END LOOP;
           END LOOP;
            END LOOP;  
   ELSIF v_tariff_flag='COR' THEN
    str_tab_pd := ttk_util_pkg.parse_str ( v_corp_id );
      FOR cor IN str_tab_cr.First..str_tab_cr.LAST  LOOP
        v_disc_amount:=0;   
      v_group_reg_seq_id := get_tariff_assoc_id('COR', str_tab_cr(cor));
      
      str_tab_per := ttk_util_pkg.parse_string( v_disc_list ); 
      for rec in str_tab_per.first..str_tab_per.last
          loop
            str_tab_dis := ttk_util_pkg.parse_str( str_tab_per(rec) );
             for rec1 in str_tab_dis.first..str_tab_dis.last
              loop
        for i in ( select d.gross_amount,d.service_seq_id,d.activity_seq_id
          from app.tpa_corp_tariff_details d
         WHERE d.group_reg_seq_id = v_group_reg_seq_id
           and d.service_seq_id = str_tab_dis(1)
           and d.network_type = trim(str_tab_dis(2)))loop
       
        v_disc_amount:=round((trim(str_tab_dis(3))/100)*v_gross_amount,2);
         
         update tpa_corp_tariff_details a
            set a.disc_amount  = v_disc_amount,
                a.disc_percent = trim(str_tab_dis(3)),
                a.updated_by   = v_user_id,
                a.updated_date = sysdate
            WHERE a.group_reg_seq_id = v_group_reg_seq_id
              and a.service_seq_id = str_tab_dis(1)
              and a.network_type = trim(str_tab_dis(2))
              and a.activity_seq_id=i.activity_seq_id;
      
      COMMIT;
      v_rows_processed := sql%rowcount;
        END LOOP;      
         END LOOP;
          END LOOP;
          
           END LOOP;
           
       /*ELSIF v_tariff_flag='TPA' THEN
        select d.gross_amount into v_gross_amount from app.tpa_tariff_details d where d.tpa_tariff_seq_id=TO_NUMBER(str_tab(i));
       
        v_disc_amount:=round((v_disc_percent/100)*v_gross_amount,2);
         
         update tpa_tariff_details a
            set a.disc_amount  = v_disc_amount,
                a.disc_percent = v_disc_percent,
                a.updated_by   = v_user_id,
                a.updated_date = sysdate
            WHERE a.service_seq_id = TO_NUMBER(str_tab(i));*/

        
        END IF;
        
      EXCEPTION
       when no_data_found then
        dbms_output.put_line('no data found for update');  
    COMMIT;
    
END modify_network_service_item;
--==============================================================================
/*PROCEDURE modify_network_service (
   v_tariff_flag                      IN VARCHAR2,--HOSP,INS,CORP
   v_service_list                     IN VARCHAR2 , -- Concatenated Sequence IDs.
   v_rows_processed                   OUT NUMBER
   )
IS

 TYPE NumList IS TABLE OF VARCHAR2(300);
   n NumList := NumList(v_service_list);
   counter INTEGER;
   
 BEGIN
   delete app.temp_test;
  
    DBMS_OUTPUT.PUT_LINE('N''s first subscript is ' || n.FIRST);
   DBMS_OUTPUT.PUT_LINE('N''s last subscript is ' || n.LAST);
-- When the subscripts are consecutive starting at 1, 
-- it's simple to loop through them.
   FOR i IN n.FIRST .. n.LAST
   LOOP
      DBMS_OUTPUT.PUT_LINE('Element #' || i || ' = ' || n(i)); 
   END LOOP;
   --DBMS_OUTPUT.PUT_LINE('Element #' || '' || ' = ' || n(4));
    DELETE APP.TEMP_TEST2;
    INSERT INTO APP.TEMP_TEST2(ERROR1,ERROR2,ERROR3,ERROR4,ERROR5,ERROR6,ERROR7,ERROR8,ERROR9,ERROR10,ERROR11,ERROR12)
    VALUES(n(1),n(2),n(3),n(4),n(5),N(6),n(7),n(8),n(9),n(10),n(11),N(12));
    COMMIT;
    v_rows_processed := sql%rowcount;
 END modify_network_service;  */   
--==================================================================================
 FUNCTION FN_ASSO_PAYEER_LIST
           RETURN VARCHAR2
           IS
           v_list varchar2(32767);
           BEGIN
            FOR REC IN (select ins_comp_code_number,ins_seq_id from app.tpa_ins_info)loop
            v_list := v_list||REC.ins_comp_code_number||'|'||'Y||';
            end loop;
            v_list := '||'||v_list ;
      RETURN v_list;
 END FN_ASSO_PAYEER_LIST; 
--===========================================================================================
 FUNCTION FN_PAYEER_ID(v_ins_comp_code_number IN tpa_ins_info.ins_comp_code_number%type)
           RETURN NUMBER
           IS
    cursor ins_cur(v_ins_comp_code_number tpa_ins_info.ins_comp_code_number%type) is 
           select ins_seq_id from app.tpa_ins_info
            where ins_comp_code_number = v_ins_comp_code_number;       
           v_ins_seq_id number;
           BEGIN
            OPEN ins_cur(v_ins_comp_code_number);
            FETCH ins_cur into v_ins_seq_id;
            CLOSE ins_cur;
      RETURN v_ins_seq_id;
 END FN_PAYEER_ID; 
--===========================================================================================
PROCEDURE select_hosp_professional (
    v_contact_seq_id        IN  OUT tpa_login_info.contact_seq_id%TYPE,
    user_cur                OUT SYS_REFCURSOR
  )
  IS

  BEGIN
  OPEN user_cur FOR
    SELECT null as user_id,
        A.user_general_type_id,
        A.contact_seq_id,
        A.hosp_seq_id,
        A.contact_name,
        A.primary_email_id,
        A.off_phone_no_1,
        A.off_phone_no_2,
        A.mobile_no,
        A.fax_no,
        b.empanel_number,
        b.hosp_name,
        -----------------------prof details
        a.professional_id as hosp_prof_id,
        a.prof_authority as prof_authority,
        a.valid_from_date as start_date,
        a.valid_to_date as end_date,
        b.std_code,
        b.isd_code,
        a.prof_file_name,
        a.prof_file,
        a.consult_gen_type,
        a.nationality_id,
        a.gender_general_type as gender,
        a.age,
        a.active_yn,
        a.speciality_id as speciality,
        null as ins_seq_id,
        null as tpa_office_seq_id,
        null as group_reg_seq_id ,
        null as bank_seq_id,
        null as prefix_general_type_id,
        null as designation_type_id,
        null as designation ,
        null as secondary_email_id,
        null as user_active_yn ,
        null as provide_access_user_yn,
        null as contact_type_id ,
        null as spec_type_id ,
        null as dr_regist_nmbr ,
        null as dr_qualif,
        null as resident_dr_yn,
        null as employee_number,
        null as res_phone_no,
        null as dept_general_type_id ,
        null as role_seq_id,
        null as role_name,
        null as ins_office_code,
        null as ins_comp_name,
        null as group_id,
        null as group_name ,
        null as contact_pa_limit ,
        null as contact_claim_limit ,
        null as softcopy_access_yn,
        null as softcopy_other_branch_yn,
        null as date_of_joining,
        null as date_of_resignation,
        null as accn_locked_yn,    --Added for CR-KOC1235
        null as pat_app_yn,
        null as pat_rej_yn,
        null as clm_app_yn,
        null as clm_rej_yn
        FROM tpa_hosp_professionals A
        LEFT OUTER JOIN tpa_hosp_info b ON (A.hosp_seq_id = b.hosp_seq_id)
        WHERE A.contact_seq_id = v_contact_seq_id ;
  END select_hosp_professional;
---==================================================================
PROCEDURE pr_account_info_update (
    v_hosp_bank_seq_id                 IN OUT tpa_hosp_account_details.hosp_bank_seq_id%TYPE,
    v_addr_seq_id                      IN OUT tpa_hosp_address.addr_seq_id%TYPE,
    v_hosp_seq_id                      IN tpa_hosp_account_details.hosp_seq_id%TYPE,
    -- SECTION: Hospital Bank Account Details
    v_bank_name                        IN tpa_hosp_account_details.bank_name%TYPE, --/ED
    v_account_number                   IN tpa_hosp_account_details.account_number%TYPE, --/ED
    v_account_in_name_of               IN tpa_hosp_account_details.account_in_name_of%TYPE,
    -- SECTION: Branch Details
    v_branch_name                      IN tpa_hosp_account_details.branch_name%TYPE,
    v_address_1                        IN tpa_hosp_address.address_1%TYPE,
    v_address_2                        IN tpa_hosp_address.address_2%TYPE,
    v_address_3                        IN tpa_hosp_address.address_3%TYPE,
    v_city_type_id                     IN tpa_hosp_address.city_type_id%TYPE,
    v_state_type_id                    IN tpa_hosp_address.state_type_id%TYPE,
    v_pin_code                         IN tpa_hosp_address.pin_code%TYPE,
    v_country_id                       IN tpa_hosp_address.country_id%TYPE,
    -- SECTION: Hospital Management Details
    v_management_name                  IN tpa_hosp_account_details.management_name%TYPE,
    v_issue_cheques_type_id            IN tpa_hosp_account_details.issue_cheques_type_id%TYPE,
     -- SECTION: PR_USER_LOG
    v_log_seq_id                       IN OUT tpa_hosp_log.log_seq_id%TYPE,
    v_mod_reason_type_id               IN tpa_hosp_log.mod_reason_type_id%TYPE,
    v_reference_date                   IN tpa_hosp_log.reference_date%TYPE,
    v_reference_no                     IN tpa_hosp_log.reference_no%TYPE,
    v_remarks_log                      IN tpa_hosp_log.remarks%TYPE,
    -- Auditing fields.
    v_user_id                          IN NUMBER,
    V_START_DATE                       IN DATE,
    V_END_DATE                         IN DATE,
    v_IBAN_NUM                         IN tpa_hosp_account_details.Bank_Ifsc%TYPE,
    v_SWIFT_CODE                       IN tpa_hosp_account_details.bank_micr%TYPE,
    v_review_yn                        IN tpa_hosp_account_details.review_yn%type,
    v_rows_processed                   OUT NUMBER
  )
  IS
    --to convert to upper case
    v_bank_name_upper               tpa_hosp_account_details.bank_name%TYPE:=upper(v_bank_name); --/ED
    v_branch_name_upper             tpa_hosp_account_details.branch_name%TYPE:=upper(v_branch_name);
    v_management_name_upper         tpa_hosp_account_details.management_name%TYPE:=upper(v_management_name);

    --to concatenate log information
    v_screen_name                   VARCHAR2(100):='Add Account Detail Screen ';
    v_column_name                   VARCHAR2(100);
    v_system_gen_yn                 tpa_hosp_log.system_gen_yn%TYPE := 'Y';
    v_log_type_id                   tpa_hosp_log.log_type_id%TYPE;
    v_old_bank_name                 tpa_hosp_account_details.bank_name%TYPE; --/ED
    v_old_account_number            tpa_hosp_account_details.account_number%TYPE; --/ED
    v_old_branch_name               tpa_hosp_account_details.account_in_name_of%TYPE;
    v_old_management_name           tpa_hosp_account_details.management_name%TYPE;
    v_remarks_bank_name             VARCHAR2(1000):= NULL; --/ED
    v_remarks_account_number        VARCHAR2(1000):= NULL;
    v_remarks_branch_name           VARCHAR2(1000):= NULL;
    v_remarks_management_name       VARCHAR2(1000):= NULL;
    v_remarks_concat                VARCHAR2(1000):= NULL;

  BEGIN

    IF ( nvl(v_hosp_bank_seq_id,0)!= 0 ) THEN     
      
      -- for Log screen.
      IF ( v_mod_reason_type_id IS NOT NULL ) OR ( v_remarks_log IS NOT NULL ) THEN
        --fetch old value for bank_name or account_number,branch_name
        SELECT ttk_util_pkg.fn_decrypt(bank_name),ttk_util_pkg.fn_decrypt(account_number),ttk_util_pkg.fn_decrypt(branch_name),management_name --/ED
          INTO v_old_bank_name,v_old_account_number,v_old_branch_name,v_old_management_name
          FROM tpa_hosp_account_details
         WHERE hosp_seq_id = v_hosp_seq_id
           AND hosp_bank_seq_id = v_hosp_bank_seq_id;

        IF ( v_old_bank_name != v_bank_name_upper ) OR ( v_old_account_number != v_account_number ) OR ( v_old_branch_name != v_branch_name_upper ) THEN --/ED
          --check for bank_name changed or not
          IF ( v_old_bank_name != v_bank_name_upper ) THEN --/ED
            v_column_name:=' Bank Name ';
            ttk_util_pkg.pr_log_concat (v_column_name,v_old_bank_name,v_bank_name_upper,v_remarks_bank_name); --/ED
          END IF;

          --check for account_number changed or not
          IF ( v_old_account_number != v_account_number ) THEN
            v_column_name:= ' Account Number ';
            ttk_util_pkg.pr_log_concat (v_column_name,v_old_account_number,v_account_number,v_remarks_account_number);
          END IF;

          --check for branch_name changed or not
          IF ( v_old_branch_name != v_branch_name_upper ) THEN
            v_column_name:= ' Branch Name ';
            ttk_util_pkg.pr_log_concat (v_column_name,v_old_branch_name,v_branch_name_upper,v_remarks_branch_name);
          END IF;

          --concate the infn. abt value changed in particular cols.
          v_remarks_concat := 'Reference Date   : '||to_char(v_reference_date,'dd/mm/yyyy')||CHR(10)||
                              ' For : '||v_screen_name||CHR(10)||v_remarks_bank_name||CHR(10)|| --/ED
                              v_remarks_account_number ||CHR(10)||v_remarks_branch_name||CHR(10)||
                              ' Remarks          : '|| v_remarks_log;

          --assign log_type_id to account changes
          v_log_type_id := 'ACC';

          -- insert into log table for account changes
          ttk_util_pkg.pr_user_log (v_log_seq_id ,v_hosp_seq_id,
                                    v_system_gen_yn,v_log_type_id ,
                                    v_mod_reason_type_id, v_reference_date,v_reference_no,
                                    v_remarks_concat,v_user_id,v_rows_processed );
        END IF;

        --check for Management Name changed or not
        IF ( v_old_management_name != v_management_name_upper ) THEN
          v_column_name:= ' Management Name ';
          ttk_util_pkg.pr_log_concat(v_column_name,v_old_management_name,v_management_name_upper,v_remarks_management_name);

          --concate the remarks of managment_name with other details.
          v_remarks_concat := 'Reference Date   : '||to_char(v_reference_date,'dd/mm/yyyy')||CHR(10)||
                              ' For : '||v_screen_name||CHR(10)||
                              v_remarks_management_name||CHR(10)||
                              ' Remarks  : '||v_remarks_log;

          --assign log_type_id to management changes
          v_log_type_id := 'MNC';

          -- insert into log table for management changes
          ttk_util_pkg.pr_user_log (v_log_seq_id , v_hosp_seq_id,
                                    v_system_gen_yn, v_log_type_id ,
                                    v_mod_reason_type_id, v_reference_date,
                                    v_reference_no, v_remarks_concat,
                                    v_user_id, v_rows_processed);
        END IF;
      END IF;
      -- save the modified deails of accounts
      UPDATE tpa_hosp_account_details
         SET bank_name                       = ttk_util_pkg.fn_encrypt(v_bank_name_upper), --/ED
             account_number                  = ttk_util_pkg.fn_encrypt(v_account_number),
             account_in_name_of              = v_account_in_name_of,
             branch_name                     = ttk_util_pkg.fn_encrypt(v_branch_name_upper),
             management_name                 = v_management_name_upper,
             issue_cheques_type_id           = v_issue_cheques_type_id,
             updated_by                      = v_user_id,
             updated_date                    = SYSDATE,
             start_date                      = v_start_date,
             end_date                        = v_end_date,
             bank_micr                       = v_SWIFT_CODE,
             Bank_Ifsc                       = v_IBAN_NUM,
             REVIEW_YN                       = v_review_yn
       WHERE hosp_bank_seq_id   = v_hosp_bank_seq_id
         AND hosp_seq_id        = v_hosp_seq_id ;

      v_rows_processed  := SQL%ROWCOUNT;

      -- save modified BANK ADDRESS.
      address_pkg.pr_hospital_bank_address_save (v_addr_seq_id,v_hosp_bank_seq_id,v_address_1,
                                                 v_address_2, v_address_3, v_city_type_id,v_state_type_id,
                                                 v_pin_code,v_country_id,null,v_user_id,v_rows_processed);

      -- save modified Pay Order ADDRESS.
     /* address_pkg.pr_hospital_po_address_save (v_po_addr_seq_id,v_hosp_gnrl_seq_id,v_po_address_1,
                                               v_po_address_2,v_po_address_3,v_po_city_type_id,v_po_state_type_id,
                                               v_po_pin_code,v_po_country_id,v_user_id,v_rows_processed);*/
 
 END IF;
       
   COMMIT;
 END pr_account_info_update;
--===================================================================
procedure tariff_network_type( v_hosp_lice_no in varchar2,
                               v_result_set out sys_refcursor)
as

 str_tab_pd ttk_util_pkg.str_table_type;---providers
 TYPE str_table_type IS TABLE OF VARCHAR2(250);
 str_tab_nt str_table_type;--networktype  
 V_CN varchar2(10);
 V_GN varchar2(10);
 V_SN varchar2(10);
 V_BN varchar2(10);
 V_WN varchar2(10);
 begin  
 str_tab_pd := ttk_util_pkg.parse_str ( v_hosp_lice_no );
-- delete from app.tariff_network;
 FOR provider IN str_tab_pd.First..str_tab_pd.LAST  LOOP 
   
 open v_result_set for 
 SELECT tg.general_type_id,tg.description
  FROM APP.TPA_HOSP_NETWORK J, APP.TPA_GENERAL_CODE TG,
       app.tpa_hosp_info hp
 WHERE TG.HEADER_TYPE = 'PROVIDER_NETWORK'
   AND J.NETWORK_TYPE = TG.GENERAL_TYPE_ID
   and hp.hosp_seq_id=j.hosp_seq_id
   AND HP.HOSP_LICENC_NUMB  in( str_tab_pd(provider))  and j.network_yn='Y'
 order by tg.sort_no;
 
/*   
  SELECT case when hp.cn_yn = 'Y' then 'CN' else '' end as CN,
                           case when hp.gn_yn = 'Y' then  'GN' else '' end as GN,  
                           case when hp.sn_yn = 'Y' then 'SN' else '' end as SN, 
                           case when hp.bn_yn = 'Y' then 'BN' else '' end as BN, 
                           case when hp.wn_yn = 'Y' then 'VN' else '' end as WN 
                        into V_CN,V_GN,V_SN,V_BN,V_WN
                       FROM app.tpa_hosp_info hp               
                       WHERE HP.HOSP_LICENC_NUMB in( str_tab_pd(provider));
                       
   str_tab_nt:= str_table_type(V_CN,V_GN,V_SN,V_BN,V_WN);  
   
   for i in str_tab_nt.first..str_tab_nt.last
     loop
       dbms_output.put_line(str_tab_nt(i));
       insert into app.tariff_network(hosp_licenc_no,network_type)values(str_tab_pd(provider),str_tab_nt(1));
       commit;
       insert into app.tariff_network(hosp_licenc_no,network_type)values(str_tab_pd(provider),str_tab_nt(2));
       commit;
       insert into app.tariff_network(hosp_licenc_no,network_type)values(str_tab_pd(provider),str_tab_nt(3));
       commit;
       insert into app.tariff_network(hosp_licenc_no,network_type)values(str_tab_pd(provider),str_tab_nt(4));
       commit;
       insert into app.tariff_network(hosp_licenc_no,network_type)values(str_tab_pd(provider),str_tab_nt(5));
       commit;
     end loop; */
     end loop;
  --open v_result_set for 'select g.general_type_id,g.description from app.tpa_general_code g where g.general_type_id in (select network_type from app.tariff_network) order by g.sort_no';
   
end tariff_network_type;

---==================================================================
/* Adding the Network type to master list  */
PROCEDURE save_Network_type ( V_DESCRIPTION             IN app.tpa_general_code.description%type,
                              V_GENERAL_TYPE_ID         IN app.tpa_general_code.general_type_id%type,
                              V_SORT_NO                 IN app.tpa_general_code.sort_no%type,
                              V_ADDED_BY                IN app.tpa_general_code.added_by%type,
                              v_rows_processed             OUT NUMBER)

IS

net_type_check number;
net_sort_check number;

cursor net_type_cnt is 
select count(1) from app.tpa_general_code np 
where np.general_type_id =V_GENERAL_TYPE_ID and np.header_type = 'PROVIDER_NETWORK';

cursor net_sort_cnt is 
select count(1) from app.tpa_general_code np 
where np.sort_no =V_SORT_NO and np.header_type = 'PROVIDER_NETWORK';
BEGIN
 
    open net_type_cnt;
    fetch net_type_cnt into net_type_check;
    close net_type_cnt;
    
    open net_sort_cnt;
    fetch net_sort_cnt into net_sort_check;
    close net_sort_cnt;
  if net_type_check=0 and  net_sort_check=0 then 

    INSERT INTO app.tpa_general_code( NETWORK_TYPE_SEQ_ID,
                                          DESCRIPTION,
                                          DETAIL,
                                          SORT_NO,
                                          GENERAL_TYPE_ID,
                                          HEADER_TYPE,
                                          ADDED_BY,
                                          ADDED_DATE
                                         )
                       VALUES(APP.NOTWORK_PRIORITY_SEQ.NEXTVAL,
                              V_DESCRIPTION,
                              'This is used in EMP of Hospital - General Screen',
                              V_SORT_NO,
                              V_GENERAL_TYPE_ID,
                              'PROVIDER_NETWORK',
                              V_ADDED_BY,
                              SYSDATE);
     else 
       
       RAISE_APPLICATION_ERROR(-20400,'Network type is existing with Another Network or Network sort is existing with Another Network.');
    end if;
      
 v_rows_processed:=SQL%ROWCOUNT;
commit;                                
END save_Network_type; 
---===================================================================================================

/* Modifying the network type master list*/

PROCEDURE modify_Network_type_mstr ( v_network_type                    IN VARCHAR2 , -- Concatenated Sequence IDs.
                                     V_ADDED_BY                        IN app.tpa_general_code.added_by%type
                                    )
IS
str_tab   Ttk_Util_Pkg.str_table_type;
BEGIN
  -- Calling Function from Ttk_Util_Pkg Package
    str_tab := Ttk_Util_Pkg.parse_str ( v_network_type );
        
       update app.tpa_general_code a  
            set a.general_type_id = str_tab(2),
                a.description = str_tab(3),
                a.sort_no     = str_tab(4),
                a.updated_by  = V_ADDED_BY,
                a.updated_date = sysdate
            WHERE a.network_type_seq_id = TO_NUMBER(str_tab(1));
    COMMIT;
END modify_Network_type_mstr;
---=====================================================================================================
/* To save HAAD fatcotr values       */
--======================================================================================================
procedure save_haad_aggreed_factor( V_HAAD_AGG_SEQ_ID         IN HAAD_AGGREED_FACTOR_BSPY.haad_agg_seq_id%type,
									                  V_HOSP_SEQ_ID             IN tpa_hosp_info.hosp_seq_id%type,
									                  V_CATEGORY_TYPE_SEQ_ID    IN tpa_haad_category_type.category_type_seq_id%type,
									                  V_FACTOR                  IN HAAD_AGGREED_FACTOR_BSPY.factor%type,
									                  V_VALUE                   IN HAAD_AGGREED_FACTOR_BSPY.value%type,
									                  V_ADDED_BY                IN HAAD_AGGREED_FACTOR_BSPY.added_by%type,
                                    V_NETWORK_TYPE            IN HAAD_AGGREED_FACTOR_BSPY.NETWORK_TYPE%TYPE )

IS
BEGIN
IF  NVL(V_HAAD_AGG_SEQ_ID,0)=0 THEN
 INSERT INTO  APP.HAAD_AGGREED_FACTOR_BSPY(
                                        HAAD_AGG_SEQ_ID,
                                        HOSP_SEQ_ID,
                                        CATEGORY_TYPE_SEQ_ID,
                                        FACTOR,
                                        VALUE,
                                        ADDED_DATE,
                                        Start_Date,
                                        ADDED_BY,
                                        NETWORK_TYPE) 
 VALUES (
         haad_aggreed_factor_seq.nextval,
         v_hosp_seq_id,
         v_category_type_seq_id,
         v_factor,
         v_value,
         sysdate,
         sysdate,
         v_added_by,
         v_network_type);
END IF;

COMMIT;
END;

---=====================================================================================================
/* To save HAAD fatcotr   NEW VALUES      */
--======================================================================================================
procedure modify_haad_aggreed_factor(v_network_type            IN VARCHAR2,--||
                                     v_category_type_seq_id    IN VARCHAR2,--||
                                     V_FACTOR_ID               IN app.haad_generl_code.id%type,
                                     v_start_date              IN varchar2,
                                     v_end_date                IN varchar2,
                                     V_VALUE                   IN varchar2,
                                     V_HOSP_SEQ_ID             IN APP.HAAD_AGGREED_FACTOR_BSPY.HOSP_SEQ_ID%TYPE,
                                     V_ADDED_BY                IN app.HAAD_AGGREED_FACTOR_BSPY.added_by%type,
                                     V_RESULT_SET              OUT SYS_REFCURSOR,
                                     v_rows_processed          OUT NUMBER)




IS
cursor factor_type is select column_name from app.haad_generl_code where  id = v_factor_id;
cursor primary_network is select hi.primary_network from tpa_hosp_info hi where hi.hosp_seq_id = v_hosp_seq_id ;

v_activity_type varchar2(20);
v_factor_name   varchar2(20);
v_value1 number;
v_primary_network    varchar2(10);

v_from_date   date;
V_to_date     date;

str_tab_nt ttk_util_pkg.str_table_type;--networktype
str_tab_ct ttk_util_pkg.str_table_type;---cattegory_type

BEGIN
  
 v_from_date    :=to_date(v_start_date,'dd/mm/rrrr');
 V_to_date      := case when v_end_date is not null then to_date(v_end_date,'dd/mm/rrrr') else null end;
 if v_network_type is not null then
      str_tab_nt := ttk_util_pkg.parse_str ( v_network_type );
 end if;

if v_category_type_seq_id is not null then
      str_tab_ct := ttk_util_pkg.parse_str ( v_category_type_seq_id );
end if;

open factor_type;
fetch factor_type into v_factor_name;
close factor_type;

open primary_network;
fetch primary_network into v_primary_network;
close primary_network;

for network in str_tab_nt.first..str_tab_nt.last loop
  for category in str_tab_ct.first..str_tab_ct.last loop

update app.haad_aggreed_factor_bspy  t set t.end_date=sysdate-1 
where t.category_type_seq_id = str_tab_ct(category) and t.factor=v_factor_name
and t.network_type = str_tab_nt(network)
and t.hosp_seq_id=V_HOSP_SEQ_ID  and t.end_date is  null;

 if V_VALUE='.' then 
    V_VALUE1:=0.0;
 else 
     V_VALUE1:=V_VALUE;
 end if;


INSERT INTO HAAD_AGGREED_FACTOR_BSPY(
                                        HAAD_AGG_SEQ_ID,
                                        HOSP_SEQ_ID,
                                        CATEGORY_TYPE_SEQ_ID,
                                        FACTOR,
                                        VALUE,
                                        ADDED_DATE,
                                        Start_Date,
                                        END_DATE,
                                        ADDED_BY,
                                        network_type) 
 VALUES (
         HAAD_AGGREED_FACTOR_SEQ.nextval,
         V_HOSP_SEQ_ID,
         str_tab_ct(category),
         v_factor_name,
         V_VALUE,
         SYSDATE,
         v_from_date,
         V_to_date,
         v_added_by,
         str_tab_nt(network));
 
v_rows_processed:=SQL%ROWCOUNT;
COMMIT;
end loop;
end loop;
COMMIT;

open v_result_set for 
 select fb.haad_agg_seq_id,fb.factor,fb.value,fb.hosp_seq_id,
 fb.category_type_seq_id,fb.start_date,fb.end_date,fb.network_type
 from haad_aggreed_factor_bspy fb join tpa_hosp_info hi on (hi.hosp_seq_id=fb.hosp_seq_id)
 where hi.hosp_seq_id=v_hosp_seq_id and fb.network_type = v_primary_network;

END modify_haad_aggreed_factor;

---===========================================================================================
procedure agg_factors_bulk_update(v_hosp_seq_id             in tpa_hosp_info.hosp_seq_id%type,
                                  V_FACTOR                  IN HAAD_AGGREED_FACTOR_BSPY.factor%type,
									                V_VALUE                   IN HAAD_AGGREED_FACTOR_BSPY.value%type,
									                V_sta_date                IN varchar2,
                                  v_end_date                IN varchar2,
                                  V_NETWORK_TYPE            IN HAAD_AGGREED_FACTOR_BSPY.NETWORK_TYPE%TYPE,
                                  v_activity_type           in TPA_HAAD_CATEGORY_TYPE.Activity_Type%type,
                                  V_ADDED_BY                IN app.HAAD_AGGREED_FACTOR_BSPY.added_by%type
                                  )
  is 
  cursor facto_date_exist is 
  select count(1)
  from APP.HAAD_AGGREED_FACTOR_BSPY T
 where t.haad_agg_seq_id =
       (select max(t.haad_agg_seq_id) haad_agg_seq_id
          from APP.HAAD_AGGREED_FACTOR_BSPY T,APP.TPA_HAAD_CATEGORY_TYPE G
         where t.hosp_seq_id = v_hosp_seq_id--35971
           and t.category_type_seq_id=g.category_type_seq_id
           and t.factor = V_FACTOR--'FACTOR'
           and t.network_type = V_NETWORK_TYPE--'RN'
           and t.value = V_VALUE--11
           and t.value is not null 
           and g.activity_type = v_activity_type--'SERVICE'
           and t.start_date = to_date(V_sta_date, 'dd/mm/yyyy'));
           
 cursor facto_date_cur is 
  select *
  from APP.HAAD_AGGREED_FACTOR_BSPY T
 where t.haad_agg_seq_id =
       (select max(t.haad_agg_seq_id) haad_agg_seq_id
          from APP.HAAD_AGGREED_FACTOR_BSPY T,APP.TPA_HAAD_CATEGORY_TYPE G
         where t.hosp_seq_id = v_hosp_seq_id--35971
           and t.category_type_seq_id=g.category_type_seq_id
           and t.factor = V_FACTOR--'FACTOR'
           and t.network_type = V_NETWORK_TYPE--'RN'
           --and t.value = V_VALUE--11
           and t.value is not null 
           and g.activity_type = v_activity_type--'SERVICE'
           --and t.start_date = to_date(V_sta_date, 'mm/dd/yyyy')
           );
 cursor act_cat_id is           
  select  g.category_type_seq_id from  APP.TPA_HAAD_CATEGORY_TYPE G   
  where g.activity_type=v_activity_type;        
   
           
 fac_dat_rec facto_date_cur%rowtype; 
 fatc_dat_cnt number;
 v_from_date date;
 V_to_date date;
 v_cat_id number;
           
         
begin
 --v_from_date    :=to_date(V_sta_date,'dd/mm/rrrr');
 v_from_date    :=to_date(V_sta_date,'dd/mm/rrrr');
 V_to_date      := case when v_end_date is not null then to_date(v_end_date,'dd/mm/rrrr') else null end;

open facto_date_exist;
fetch facto_date_exist into fatc_dat_cnt;
close facto_date_exist;

  if fatc_dat_cnt=0  then 
    
    open facto_date_cur;
    fetch facto_date_cur into fac_dat_rec;
    close facto_date_cur;
    
    open act_cat_id;
    fetch act_cat_id into v_cat_id;
    close act_cat_id;
    
  
     update app.haad_aggreed_factor_bspy  t set t.end_date=v_from_date-1 
      where t.category_type_seq_id =fac_dat_rec.category_type_seq_id  and t.factor=fac_dat_rec.factor
      and t.network_type = fac_dat_rec.network_type
      and t.hosp_seq_id=fac_dat_rec.hosp_seq_id;
    
   commit;
    if V_VALUE is not null then 
    INSERT INTO HAAD_AGGREED_FACTOR_BSPY(
                                        HAAD_AGG_SEQ_ID,
                                        HOSP_SEQ_ID,
                                        CATEGORY_TYPE_SEQ_ID,
                                        FACTOR,
                                        VALUE,
                                        ADDED_DATE,
                                        Start_Date,
                                        end_date,
                                        ADDED_BY,
                                        network_type) 
 VALUES (
         HAAD_AGGREED_FACTOR_SEQ.nextval,
         V_HOSP_SEQ_ID,
         v_cat_id,
         V_FACTOR,
         V_VALUE,
         SYSDATE,
         v_from_date,
         V_to_date,
         v_added_by,
         V_NETWORK_TYPE);  
       
end if;
  end if;
  
  commit; 
end agg_factors_bulk_update;

--=======================================================================================================

FUNCTION get_spec_codes( v_description        DHA_CLNSN_SPECIALTIES_MASTER.SPECIALTY%type)
RETURN VARCHAR2
IS
v_sql_str              clob;
v_result_set           sys_refcursor;
v_result               DHA_CLNSN_SPECIALTIES_MASTER.SPECIALTY%TYPE;

BEGIN
  v_sql_str:='select SPECIALTY_ID from DHA_CLNSN_SPECIALTIES_MASTER
              where upper(trim(SPECIALTY))=UPPER(trim((:v_description)))';
  
  OPEN v_result_set FOR  v_sql_str USING v_description;
  FETCH v_result_set INTO v_result;
  CLOSE v_result_set;
  
 
  RETURN v_result;
  
END get_spec_codes;
--=======================================================================================================
PROCEDURE dwnld_tariff(p_prov_seq_id     IN Tpa_Hosp_Info.Hosp_Seq_Id%TYPE,
                       p_resultset       OUT SYS_REFCURSOR)
AS
BEGIN
  
  OPEN p_resultset FOR
    SELECT nvl(am.activity_code, '-') as Activity_Code,
           nvl(t.internal_code, '-') as Internal_Code,
           nvl(s.service_name, '-') as Service_Name,
           nvl(t.internal_desc, '-') as Internal_Description,
           nvl(am.activity_description, '-') as Activity_Description,
           nvl(to_char(t.package_id), '-') as Package_Id,
           nvl(to_char(t.bundle_id), '-') as Bundle_Id,
           nvl(to_char(t.gross_amount), '-') as Gross_Amount,
           nvl(to_char(t.disc_percent), '-') as Discount_Percentage ,
           to_char(t.start_date, 'DD-MM-RRRR') as From_Date,
           nvl(to_char(t.end_date, 'DD-MM-RRRR'), '-') as Expiry_Date
           
    FROM Tpa_Hosp_Tariff_Details t
    JOIN Tpa_Hosp_Info h ON (t.hosp_seq_id = h.hosp_seq_id)
    JOIN Tpa_Activity_Master_Details am ON (am.act_mas_dtl_seq_id = t.activity_seq_id)
    JOIN Tpa_Service_Details s ON (s.service_seq_id = t.service_seq_id)
    WHERE h.hosp_seq_id = p_prov_seq_id
    AND s.service_seq_id not in (14, 7);
    
END dwnld_tariff;
--=======================================================================================================
PROCEDURE select_activity_list (v_act_code                 IN OUT tpa_activity_master_details.activity_code%TYPE,
                                v_description              IN OUT tpa_activity_master_details.activity_description%TYPE,
                                v_start_num                IN OUT NUMBER,
                                v_end_num                  IN OUT NUMBER,
                                v_tariff_type              IN  VARCHAR2,
                                v_result_set               OUT SYS_REFCURSOR
                               )
AS
  v_str       VARCHAR2(4000);
  v_act_count NUMBER;
BEGIN
  
  v_description := UPPER('%'||v_description||'%');
  
  IF v_tariff_type='ACTIVITY' THEN
    v_str := ' SELECT
                 md.act_mas_dtl_seq_id as act_mas_dtl_seq_id, md.activity_code ,md.activity_description, md.activity_type_seq_id, md.service_seq_id, s.service_name
                 FROM tpa_activity_master_details md
                 LEFT JOIN tpa_service_details s ON s.service_seq_id = md.service_seq_id
                 WHERE ( UPPER(:v_act_code) IS NULL OR UPPER(md.activity_code) LIKE UPPER(:v_act_code) )
                 AND ( UPPER(:v_description) IS NULL OR UPPER(md.activity_description) LIKE UPPER(:v_description))
                 AND md.service_seq_id NOT IN (''7'',''14'')';
             
             
    v_str := 'SELECT * FROM
                (SELECT A.*, DENSE_RANK() OVER (ORDER BY '||'act_mas_dtl_seq_id'||' '||'ASC'||',ROWNUM) Q FROM (' ||v_str|| ') A )
                WHERE  Q>= :v_start_num  AND Q<= :v_end_num ';
    
    
    OPEN v_result_set FOR v_str USING v_act_code, v_act_code, v_description, v_description, v_start_num, v_end_num;
  
  ELSIF v_tariff_type='PHARMACY' THEN
  
    v_str := ' SELECT
                 md.act_mas_dtl_seq_id as act_mas_dtl_seq_id, md.activity_code ,md.activity_description, md.activity_type_seq_id, md.service_seq_id, s.service_name 
                 FROM tpa_activity_master_details md
                 LEFT JOIN tpa_service_details s ON s.service_seq_id = md.service_seq_id
                 WHERE ( UPPER(:v_act_code) IS NULL OR UPPER(md.activity_code) LIKE UPPER(:v_act_code) )
                 AND ( UPPER(:v_description) IS NULL OR UPPER(md.activity_description) LIKE UPPER(:v_description))
                 AND md.service_seq_id IN (''7'',''14'')';
             
             
    v_str := 'SELECT * FROM
                (SELECT A.*, DENSE_RANK() OVER (ORDER BY '||'act_mas_dtl_seq_id'||' '||'ASC'||',ROWNUM) Q FROM (' ||v_str|| ') A )
                WHERE  Q>= :v_start_num  AND Q<= :v_end_num ';
      
    OPEN v_result_set FOR v_str USING v_act_code, v_act_code, v_description, v_description, v_start_num, v_end_num;
  END IF;
    
END select_activity_list;
--=======================================================================================================
PROCEDURE update_bulk_tariff(v_tariff_doc       XMLTYPE,
                             v_log_file      out clob
                            )
AS
  v_doc                         DBMS_XMLDOM.DOMDocument;
  v_elem                        DBMS_XMLDOM.DOMElement;
  v_elem1                       DBMS_XMLDOM.DOMElement;
  v_elem3                       DBMS_XMLDOM.DOMElement;
  v_root_node_list              DBMS_XMLDOM.DOMNODELIST;
  v_parent_node_lst             DBMS_XMLDOM.DOMNODELIST;
  v_chld_node_list              DBMS_XMLDOM.DOMNODELIST;
  v_chld_node                   DBMS_XMLDOM.domnode;
  v_parent_node                 DBMS_XMLDOM.domnode;
  v_root_node                   DBMS_XMLDOM.domnode;
  tariff_rec                    tpa_hosp_tariff_details%rowtype;
  price_ref_rec                 tpa_price_reference_dtls%rowtype;
  v_price_ref_no                VARCHAR2(30);
  v_network_type                VARCHAR2(1000);
  v_hosp_licence_numb           VARCHAR2(32767);
  v_ins_id                      varchar2(32767);
  v_ins_seq_id                  number;
  v_hosp_id                     varchar2(32767);
  v_tariff_log_seq_id           NUMBER(10);
  v_act_code                    varchar2(60);
  v_act_type_id                 number(10);
  v_service_name                VARCHAR2(50);
  v_tpa_bach_seq_id             number(20);
  v_service_type                VARCHAR2(10);
  v_hosp_seq_id                 NUMBER;
  v_scp_count                   NUMBER;
  v_upload_type                 VARCHAR2(30);
  v_rows_processed              NUMBER;
  v_count                       NUMBER;
  
  str_tab_nt ttk_util_pkg.str_table_type;
  str_tab_pd ttk_util_pkg.str_table_type;
  str_tab_py ttk_util_pkg.str_table_type;
  
  CURSOR tariff_logs(v_bach_seq_id NUMBER) IS
  SELECT * FROM tpa_tariff_logs p
  where p.tariff_batch_seq_id=v_bach_seq_id;
  
  CURSOR tarrif_cur(v_hosp_seq_id NUMBER, v_internal_code VARCHAR2, v_start_date VARCHAR2, v_network varchar) IS
    SELECT t.hosp_tariff_seq_id,
           t.activity_seq_id,
           t.internal_code,
           t.start_date,
           t.end_date,
           t.network_type,
           t.hosp_seq_id
           
    FROM tpa_hosp_tariff_details t
    WHERE t.hosp_seq_id = v_hosp_seq_id
    AND upper(t.internal_code) = upper(v_internal_code)
    AND trunc(t.start_date) >= v_start_date
    AND t.network_type = v_network;
  
  CURSOR act_cur(v_code VARCHAR2) IS
    select c.service_seq_id,
           a.act_mas_dtl_seq_id,
           b.activity_type_seq_id
           
    from app.tpa_activity_master_details a 
    join app.tpa_activity_type_codes b on (a.activity_type_seq_id = b.activity_type_seq_id)
    join app.tpa_service_details c on (a.service_seq_id = c.service_seq_id)
    where trim(upper(a.activity_code))=trim(upper(v_code)); 
  
  act_rec                      act_cur%ROWTYPE;
  tarr_rec                     tarrif_cur%ROWTYPE;  
  
  FOUND_DUPLICATE exception;
  Pragma exception_init(FOUND_DUPLICATE ,-1);
  SQLMSG VARCHAR2(1000);
  v_field_val       VARCHAR2(4000);
BEGIN
  --delete from priyadarshan.xml_tab;
  --insert into priyadarshan.xml_tab values(1,v_tariff_doc);
  --for i in (select x.xml_str from priyadarshan.xml_tab x where x.xml_id = 1) loop
  select TPA_TARIFF_BATCH_SEQ.nextval into v_tpa_bach_seq_id from dual;
  --v_tariff_xml := XMLTYPE.createXML(v_tariff_doc);

  v_doc            := dbms_xmldom.newdomdocument(v_tariff_doc);--v_tariff_doc
  v_root_node_list := dbms_xmldom.getelementsbytagname(v_doc, 'tariffdetails');
  
  for v_root_node_index in 0 .. dbms_xmldom.getlength(v_root_node_list) - 1 loop
    v_root_node := dbms_xmldom.item(v_root_node_list, v_root_node_index);
    v_elem      := dbms_xmldom.makeelement(v_root_node);
 
    v_parent_node_lst := dbms_xmldom.getelementsbytagname(v_elem, 'pricerefdetails');
    
    for parent_node_index in 0 .. dbms_xmldom.getlength(v_parent_node_lst) - 1 loop
      v_parent_node := dbms_xmldom.item(v_parent_node_lst, parent_node_index);
      v_elem1       := dbms_xmldom.makeelement(v_parent_node);
      
      price_ref_rec.price_ref_number:=dbms_xmldom.getAttribute(v_elem1,'pricerefno');
      price_ref_rec.added_by        :=dbms_xmldom.getAttribute(v_elem1,'userid');
      v_network_type                :=dbms_xmldom.getAttribute(v_elem1,'networktype');
      v_service_type                :=dbms_xmldom.getAttribute(v_elem1,'discAt');
      v_hosp_licence_numb           :=dbms_xmldom.getAttribute(v_elem1,'empanelnumber');
      v_ins_id                      :=dbms_xmldom.getAttribute(v_elem1,'insuranceid');
      v_hosp_id                     :=dbms_xmldom.getAttribute(v_elem1,'corporateid');
      v_upload_type                 :=dbms_xmldom.getAttribute(v_elem1,'uploadType');
       
        if v_hosp_licence_numb is not null then
          str_tab_pd := ttk_util_pkg.parse_str ( v_hosp_licence_numb);
        end if;

        if v_ins_id is not null then
          str_tab_py := ttk_util_pkg.parse_str ( v_ins_id );
        end if;

        if v_network_type is not null then
          str_tab_nt := ttk_util_pkg.parse_str ( v_network_type );
        end if;

    end loop;

      FOR  payer  IN str_tab_py.First..str_tab_py.Last LOOP
        FOR provider IN str_tab_pd.First..str_tab_pd.Last LOOP
          FOR network_type IN str_tab_nt.First..str_tab_nt.Last LOOP
            v_chld_node_list := dbms_xmldom.getelementsbytagname(v_elem, 'tariff');
              
            for chld_node_index in 0 .. dbms_xmldom.getlength(v_chld_node_list) - 1 loop
              v_chld_node := dbms_xmldom.item(v_chld_node_list, chld_node_index);
              v_elem3     := dbms_xmldom.makeelement(v_chld_node);

              begin
                tariff_rec                       := null;
                v_act_code                       := null;
                v_act_type_id                    := 0;

                tariff_rec.price_ref_number := get_tariff_assoc_id('PRN',dbms_xmldom.getAttribute(v_elem1,'pricerefno'));
                v_act_code                  := dbms_xmldom.getAttribute(v_elem3,'activitycode');
                tariff_rec.internal_code    := dbms_xmldom.getAttribute(v_elem3,'internalcode');
                tariff_rec.Internal_Desc    := dbms_xmldom.getAttribute(v_elem3,'internalDesc');
                tariff_rec.hosp_act_desc    :=dbms_xmldom.getAttribute(v_elem3,'activitydesc');
                
                v_act_code     := trim(v_act_code);
                v_service_name := trim(v_service_name);
                tariff_rec.internal_code := trim(tariff_rec.internal_code);
                v_field_val := trim(tariff_rec.price_ref_number)||
                               trim(v_act_code)||
                               trim(tariff_rec.internal_code)||
                               trim(v_service_name)||
                               trim(tariff_rec.Internal_Desc)||
                               trim(tariff_rec.hosp_act_desc);
                               
                tariff_rec.start_date       := to_date(dbms_xmldom.getAttribute(v_elem3,'fromdate'),'dd/mm/rrrr');
                tariff_rec.end_date         := to_date(dbms_xmldom.getAttribute(v_elem3,'expirydate'),'dd/mm/rrrr');
                v_service_name              := dbms_xmldom.getAttribute(v_elem3,'servicename');
                
                
                IF tariff_rec.end_date IS NOT NULL THEN
                  IF to_date(tariff_rec.end_date, 'DD/MM/RRRR') <= to_date(tariff_rec.start_date, 'DD/MM/RRRR') /*OR to_date(tariff_rec.end_date, 'DD/MM/RRRR') <= to_date(sysdate, 'DD/MM/RRRR'))*/ THEN
                    raise_application_error(-20880,'Tariff end date should be grater than start date.');
                  END IF;
                END IF;
                
                act_rec.act_mas_dtl_seq_id       := NULL;
                act_rec.activity_type_seq_id     := NULL;
                tariff_rec.activity_seq_id       := NULL;
                act_rec.service_seq_id           := NULL;
                tariff_rec.Acitivity_Type_Seq_Id := NULL;
                tariff_rec.Service_Seq_Id		     := NULL;
                
                OPEN act_cur(v_act_code);
                FETCH act_cur INTO act_rec;
                CLOSE act_cur;
                
                tariff_rec.activity_seq_id       := act_rec.act_mas_dtl_seq_id;
                tariff_rec.Acitivity_Type_Seq_Id := act_rec.activity_type_seq_id;
                tariff_rec.Service_Seq_Id	       := act_rec.service_seq_id;
                tariff_rec.internal_code         := UPPER(trim(tariff_rec.internal_code));  
                
                IF v_act_code IS NULL OR tariff_rec.internal_code IS NULL OR tariff_rec.Internal_Desc IS NULL OR tariff_rec.hosp_act_desc IS NULL OR tariff_rec.start_date IS NULL THEN
                    raise_application_error(-20876,'Please check some of the mandatory fields are coming empty.');
                ELSIF v_upload_type IN ('ACT', 'ACTIVITY') AND tariff_rec.Service_Seq_Id IN (7, 14) THEN
                    raise_application_error(-20876,'Cannot update drug code in activity tariff template.');
                ELSIF v_upload_type IN ('PHARMA', 'PHARMACY') AND tariff_rec.Service_Seq_Id NOT IN (7, 14) THEN
                    raise_application_error(-20876,'Cannot update activity code in drug tariff template.');
                ELSIF tariff_rec.activity_seq_id IS NULL THEN
                    raise_application_error(-20874, 'activity code is not existing in master data.');
                ELSE
                  IF tariff_rec.internal_code IS NOT NULL THEN
                    select CASE
                           WHEN regexp_count(upper(trim(tariff_rec.internal_code)), '[[:space:]]') > 1 THEN
                             1
                           ELSE
                             0
                           END as spc INTO v_scp_count
                    from dual;
                      
                    IF v_scp_count = 1 THEN
                      raise_application_error(-20873,'more than 1 space cannot allow for internal code '||tariff_rec.internal_code||'.');
                    END IF;
                  END IF;
                    
                  v_hosp_seq_id := get_tariff_assoc_id('EMP', str_tab_pd(provider));
                  v_ins_seq_id := get_tariff_assoc_id('INS', str_tab_py(payer));
                  
                  SELECT count(1) INTO v_count
                  FROM Tpa_Hosp_Tariff_Details t
                  WHERE UPPER(t.internal_code) = tariff_rec.internal_code
                  AND t.hosp_seq_id = v_hosp_seq_id;
                  
                  IF v_count = 0 THEN
                    raise_application_error(-20875, tariff_rec.internal_code||' Internal code is not existing in tariff data for this provider.');
                  END IF;
                  
                  v_count := NULL;
                    
                  IF v_upload_type IN ('ACT', 'ACTIVITY') THEN
                    SELECT count(1) INTO v_count
                    FROM Tpa_Hosp_Tariff_Details t
                    WHERE UPPER(t.internal_code) = tariff_rec.internal_code
                    AND t.hosp_seq_id = v_hosp_seq_id
                    AND t.service_seq_id NOT IN (7, 14);
                      
                    IF v_count = 0 THEN
                      raise_application_error(-20876,'Cannot update drug code in activity tariff template.');
                    END IF;
                  ELSE
                    SELECT count(1) INTO v_count
                    FROM Tpa_Hosp_Tariff_Details t
                    WHERE UPPER(t.internal_code) = tariff_rec.internal_code
                    AND t.hosp_seq_id = v_hosp_seq_id
                    AND t.service_seq_id IN (7, 14);
                      
                    IF v_count = 0 THEN
                      raise_application_error(-20876,'Cannot update activity code in pharmacy tariff template.');
                    END IF;
                  END IF;
                  
                  v_count := NULL;
                  
                  SELECT count(1) INTO v_count
                  FROM Tpa_Hosp_Tariff_Details t
                  WHERE UPPER(t.internal_code) = tariff_rec.internal_code
                  AND t.hosp_seq_id = v_hosp_seq_id
                  AND trunc(t.start_date) = tariff_rec.start_date;
                  
                  IF v_count = 0 THEN
                    raise_application_error(-20876,'From date/Expiry date does not match with tariff details for: '||tariff_rec.internal_code);
                  
                  ELSE
                    SELECT count(1) INTO v_count
                    FROM Tpa_Hosp_Tariff_Details t
                    WHERE UPPER(t.internal_code) = tariff_rec.internal_code
                    AND t.hosp_seq_id = v_hosp_seq_id
                    AND trunc(t.start_date) = tariff_rec.start_date
                    AND t.network_type = str_tab_nt(network_type);
                    
                    IF v_count = 0  THEN
                      raise_application_error(-20875, ' Internal code '||tariff_rec.internal_code||' and activity code '||v_act_code||' combination does not available in the selected network type category.');
                    END IF;
                  END IF;
                END IF;
                
                OPEN tarrif_cur (v_hosp_seq_id, tariff_rec.internal_code, tariff_rec.start_date, str_tab_nt(network_type));
                FETCH tarrif_cur INTO tarr_rec;
                CLOSE tarrif_cur;
                    
                v_price_ref_no := v_ins_id || '-' || str_tab_pd(provider) || '-' ||str_tab_py(payer);
                
                save_tariff_details(tarr_rec.hosp_tariff_seq_id,
                                    v_hosp_seq_id,
                                    v_ins_seq_id,
                                    null,
                                    'HOSP',
                                    tariff_rec.price_ref_number,
                                    tariff_rec.activity_seq_id,
                                    tariff_rec.Acitivity_Type_Seq_Id,
                                    tariff_rec.gross_amount,
                                    tariff_rec.disc_amount,
                                    null,
                                    tariff_rec.Service_Seq_Id,
                                    tariff_rec.bundle_id,
                                    tariff_rec.Package_Id,
                                    tariff_rec.start_date,
                                    tariff_rec.end_date,
                                    'tariff upload',
                                    price_ref_rec.added_by,
                                    tariff_rec.internal_code,
                                    tariff_rec.hosp_act_desc,
                                    str_tab_nt(network_type),
                                    tariff_rec.disc_percent,
                                    tariff_rec.Internal_Desc,
                                    null,
                                    null,
                                    v_rows_processed);
                                    
              exception
                when others then
                  IF v_field_val IS NOT NULL THEN
                    save_tariff_logs(v_tariff_log_seq_id,str_tab_pd(provider),str_tab_py(payer),null,v_act_code,sqlcode,sqlerrm,'T',price_ref_rec.added_by,v_tpa_bach_seq_id);
                  END IF;
              end;
            end loop;
          END LOOP;
        END LOOP;
      END LOOP;
  end loop;

 

  for i in tariff_logs(v_tpa_bach_seq_id) loop
     v_log_file:=v_log_file||' '||'Activity code :'||i.act_code||' '||substr(i.error_message,11)||chr(13);
  end loop;
    v_log_file:=nvl(v_log_file,'Tariff details uploaded successfully');
  --end loop;

END update_bulk_tariff;
--=======================================================================================================
PROCEDURE get_pharma_tariff_list (v_ins_seq_id                         IN NUMBER,
                                  v_seq_id                             IN TPA_HOSP_TARIFF_DETAILS.HOSP_SEQ_ID%TYPE,--hosp_seq_id,ins_seq_id,group_reg_seq_id
                                  v_price_ref_no                       IN VARCHAR2,
                                  v_act_code                           IN VARCHAR2,
                                  v_service_seq_id                     IN NUMBER,
                                  v_interna_code                       IN VARCHAR2,
                                  v_network_type                       IN VARCHAR2,  
                                  v_end_date                           IN VARCHAR2,
                                  v_sort_var                           IN VARCHAR2,
                                  v_sort_order                         IN VARCHAR2,
                                  v_start_num                          IN NUMBER ,
                                  v_end_num                            IN NUMBER,
                                  result_set                           OUT SYS_REFCURSOR
                                 )
  AS
    v_sql_str                            VARCHAR2(6000);
    v_where                              VARCHAR2(3000);
    TYPE bind_tab_type IS TABLE OF VARCHAR2(250) INDEX BY BINARY_INTEGER ;
    bind_tab                             bind_tab_type;
    i                                    NUMBER(2) := 0;
    v_end_date1                          DATE;
  BEGIN

    v_end_date1 := TO_DATE(v_end_date, 'DD/MM/YYYY');
        v_sql_str :=
            'select b.price_ref_number,
                    b.hosp_tariff_seq_id as tariff_seq_id,
                    c.activity_code,
                    d.service_name as service_name,
                    d.service_name as service_type,
                    b.internal_code,
                    nvl(b.hosp_act_desc, c.short_description) activity_desc,
                    nvl(b.hosp_act_desc, c.short_description) hosp_act_desc,
                    b.internal_desc,
                    b.gross_amount as unit_price,
                    b.gross_amount as gross_amount,
                    b.package_price as pckg_price,
                    case when b.gross_amount > 0 and b.disc_percent > 0 then round(nvl((b.gross_amount * b.disc_percent /100), 0),3) else 0 end as disc_amt,
                    case when b.gross_amount > 0 and b.disc_percent > 0 then round(nvl((b.gross_amount * b.disc_percent /100), 0),3) else 0 end as disc_amount,
                    b.disc_percent as discount_percentage,
                    b.disc_percent as disc_percent,
                    b.network_type,
                    NVL(TO_CHAR(b.end_date, ''dd/mm/yyyy''), ''NA'') as end_date,
                    ''HOSP'' AS tariff_type,
                    b.hosp_seq_id,
                    b.package_size as pkgSize
             
            from tpa_hosp_tariff_details b 
            left outer join app.tpa_activity_master_details c on (c.act_mas_dtl_seq_id=b.activity_seq_id)
            left outer join app.tpa_service_details d on (d.service_seq_id=b.service_seq_id)
            where c.service_seq_id in (14, 7) ';
    
    IF v_seq_id IS NOT NULL THEN
       v_where := v_where ||' AND b.hosp_seq_id = :v_seq_id ';
       i := i+1;
       bind_tab(i) := v_seq_id ;
    END IF;
    
    IF v_price_ref_no IS NOT NULL THEN
       v_where := v_where  ||' AND b.price_ref_number = :v_price_ref_no ';
       i := i+1;
       bind_tab(i) := UPPER(v_price_ref_no);
    END IF;
    
    IF v_ins_seq_id IS NOT NULL THEN
      v_where := v_where  ||' AND b.ins_seq_id = :v_ins_seq_id ';
      i := i+1;
      bind_tab(i) := v_ins_seq_id ;
    END IF;
    
    IF v_act_code IS NOT NULL THEN
      v_where := v_where  ||' AND c.activity_code = :v_act_code ';
      i := i+1;
      bind_tab(i) := UPPER(v_act_code) ;
    END IF;
    
    IF v_service_seq_id IS NOT NULL THEN
      v_where := v_where  ||' AND b.service_seq_id = :v_service_seq_id ';
      i := i+1;
      bind_tab(i) := v_service_seq_id ;
    END IF;
    
    IF v_interna_code IS NOT NULL THEN
      v_where := v_where  ||' AND upper(b.Internal_Code) = :v_interna_code ';
      i := i+1;
      bind_tab(i) := UPPER(v_interna_code) ;
    END IF;
           
    IF v_network_type IS NOT NULL THEN
      v_where := v_where  ||' AND upper(b.network_type) = :v_network_type ';
      i := i+1;
      bind_tab(i) := UPPER(v_network_type) ;
    END IF;
          
    IF v_end_date IS NOT NULL THEN
      v_where := v_where  ||' AND b.end_date = TO_DATE(:v_end_date1) ';
      i := i+1;
      bind_tab(i) := v_end_date1 ;
    END IF;
    
    IF v_where IS NOT NULL THEN
      v_sql_str := v_sql_str||' AND '|| substr(v_where,6);
    END IF;
    
    v_sql_str := 'SELECT * FROM
        (SELECT A.*,DENSE_RANK() OVER (ORDER BY '||v_sort_var||' '||v_sort_order||',ROWNUM)
        Q FROM (' ||v_sql_str||') A ) WHERE Q>= :v_start_num  AND Q<= :v_end_num' ;
        
    IF bind_tab.FIRST IS NOT NULL THEN
       CASE bind_tab.COUNT
         WHEN 1  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),v_start_num,v_end_num ;
         WHEN 2  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2), v_start_num, v_end_num ;
         WHEN 3  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3), v_start_num, v_end_num ;
         WHEN 4  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3),bind_tab(4),v_start_num ,v_end_num ;
         WHEN 5  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3),bind_tab(4),bind_tab(5),v_start_num ,v_end_num ;
         WHEN 6  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3),bind_tab(4),bind_tab(5),bind_tab(6),v_start_num ,v_end_num ;
         WHEN 7  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3),bind_tab(4),bind_tab(5),bind_tab(6),bind_tab(7),v_start_num ,v_end_num ;
         WHEN 8  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3),bind_tab(4),bind_tab(5),bind_tab(6),bind_tab(7),bind_tab(8),v_start_num ,v_end_num ;
        END CASE;
    ELSE
      OPEN result_set FOR v_sql_str USING v_start_num , v_end_num ;
    END IF;

  END get_pharma_tariff_list;
--=======================================================================================================
PROCEDURE Tariff_updation_Log ( v_hosp_seq_id  IN  VARCHAR2,
                                v_log_type     IN   VARCHAR2,
                                v_start_date   IN   VARCHAR2,
                                v_end_date     IN   VARCHAR2,
                                v_inter_code   IN   VARCHAR2,
                                v_result_set   out   SYS_REFCURSOR)
IS
 v_sqlstr	 VARCHAR2(4000);
 v_where   VARCHAR2(4000);
 TYPE search_tab IS TABLE OF VARCHAR2(1000) INDEX BY BINARY_INTEGER;
 ser_tab search_tab;
 i       NUMBER:=0;
 v_sort_var   VARCHAR2(50):='ADDED_DATE';
 v_sort_order VARCHAR2(10):='DESC';
 
BEGIN
  
v_sqlstr :='SELECT l.added_date,
                   l.remarks,l.log_seq_id,l.log_type_id,
                   (select c.contact_name from tpa_user_contacts c 
                           where c.contact_seq_id= l.added_by) as CONTACT_NAME,
                           l.hosp_seq_id,l.system_gen_yn,
                           CASE WHEN g.general_type_id=''TAR'' THEN ''Tariff Activity Mapping Changes'' 
                                        ELSE NULL END AS DESCRIPTION,
                           l.reference_no as internal_code 
                           FROM tpa_hosp_log L
                               JOIN tpa_general_code g on (l.log_type_id=g.general_type_id)
                                WHERE  L.HOSP_SEQ_ID='''||v_hosp_seq_id||''' AND l.LOG_TYPE_ID='''||v_log_type||'''';
IF v_start_date IS NOT NULL THEN
   IF v_end_date IS NOT NULL THEN
      v_where := v_where||'AND l.added_date BETWEEN :v_start_date AND :v_end_date';
      
      i:= i+1;
      ser_tab(i):=TO_DATE(v_start_date,'DD-MM-YYYY');
      
      i:= i+1;
      ser_tab(i):=TO_DATE(v_end_date,'DD-MM-YYYY') +1;
  ELSIF v_end_date  IS NULL THEN
        v_where := v_where||'AND l.added_date BETWEEN :v_start_date AND :v_end_date';
        i:= i+1;
       ser_tab(i):=TO_DATE(v_start_date,'DD-MM-YYYY');
        i:= i+1;
       ser_tab(i):=TO_DATE(sysdate,'DD-MM-YYYY');
  END IF;
END IF;

IF v_inter_code IS NOT NULL THEN
  v_where := v_where||' AND l.reference_no = :v_inter_code';
  i:= i+1;
  ser_tab(i):=upper(trim(v_inter_code));
END IF;

v_sqlstr :=v_sqlstr||v_where;

v_sqlstr := 'SELECT * FROM
        (SELECT A.*,DENSE_RANK() OVER (ORDER BY '||v_sort_var||' '||v_sort_order||',ROWNUM)
        Q FROM (' ||v_sqlstr||') A )';

CASE WHEN ser_tab.FIRST IS NOT NULL THEN
     case ser_tab.count
          WHEN 1 THEN OPEN v_result_set FOR v_sqlstr USING ser_tab(1);
          WHEN 2 THEN OPEN v_result_set FOR v_sqlstr USING ser_tab(1),ser_tab(2);
          WHEN 3 THEN OPEN v_result_set FOR v_sqlstr USING ser_tab(1),ser_tab(2),ser_tab(3); 
     end case;
ELSE
  OPEN v_result_set FOR v_sqlstr; 
END case;
END Tariff_updation_Log;
--=======================================================================================================
PROCEDURE load_hosp_pharmacy(v_tariff_doc       XMLTYPE,
                             v_log_file      out clob)
AS
  v_doc                         DBMS_XMLDOM.DOMDocument;
  v_elem                        DBMS_XMLDOM.DOMElement;
  v_elem1                       DBMS_XMLDOM.DOMElement;
  v_elem3                       DBMS_XMLDOM.DOMElement;
  v_root_node_list              DBMS_XMLDOM.DOMNODELIST;
  v_parent_node_lst             DBMS_XMLDOM.DOMNODELIST;
  v_chld_node_list              DBMS_XMLDOM.DOMNODELIST;
  v_chld_node                   DBMS_XMLDOM.domnode;
  v_parent_node                 DBMS_XMLDOM.domnode;
  v_root_node                   DBMS_XMLDOM.domnode;
  tariff_rec                    tpa_hosp_tariff_details%rowtype;
  price_ref_rec                 tpa_price_reference_dtls%rowtype;
  V_PRICE_REF_SEQ_ID            NUMBER(10);
  v_tariff_seq_id               NUMBER(10);
  v_tariff_flag                 VARCHAR2(5);
  v_network_type                VARCHAR2(1000);
  v_hosp_licence_numb           VARCHAR2(32767);
  v_ins_id                      varchar2(32767);
  v_hosp_id                     varchar2(32767);
  v_rows_processed              NUMBER(10);
  v_tariff_log_seq_id           NUMBER(10);
  v_act_code                    varchar2(60);
  v_act_type_id                 number(10);
  v_service_name                VARCHAR2(50);
  v_tpa_bach_seq_id             number(20);
  v_service_type                VARCHAR2(10);
  v_hosp_seq_id                 NUMBER;
  v_internal_count              NUMBER;
  v_scp_count                   NUMBER;
  v_count                       NUMBER;
  v_xml                         CLOB;
  v_pkg_price                   NUMBER(12,3);
  v_upld_typ                    VARCHAR2(10);
  v_pkg_qnt                     NUMBER(12,3);
  
  str_tab_nt ttk_util_pkg.str_table_type;--networktype
  str_tab_pd ttk_util_pkg.str_table_type;---providers
  str_tab_py ttk_util_pkg.str_table_type;---payers
  
  CURSOR tariff_logs(v_bach_seq_id NUMBER) IS
  SELECT * FROM tpa_tariff_logs p
  where p.tariff_batch_seq_id=v_bach_seq_id;
  
  CURSOR tarrif_cur(v_hosp_seq_id NUMBER, v_internal_code VARCHAR2, v_network VARCHAR2) IS
    SELECT t.internal_code,
       t.start_date,
       t.end_date,
       t.network_type
       
    FROM tpa_hosp_tariff_details t
    WHERE t.hosp_seq_id = v_hosp_seq_id
    AND upper(t.internal_code) = upper(v_internal_code)
    AND t.network_type = v_network;
  
  CURSOR act_cur(v_code VARCHAR2) IS
    select c.service_seq_id,
           a.act_mas_dtl_seq_id,
           b.activity_type_seq_id
           
    from app.tpa_activity_master_details a 
    join app.tpa_activity_type_codes b on (a.activity_type_seq_id = b.activity_type_seq_id)
    join app.tpa_service_details c on (a.service_seq_id = c.service_seq_id)
    where trim(upper(a.activity_code))=trim(upper(v_code)); 
  
  act_rec                      act_cur%ROWTYPE;
  tarr_rec                     tarrif_cur%ROWTYPE;  
  v_test                       xmltype;

  FOUND_DUPLICATE exception;
  Pragma exception_init(FOUND_DUPLICATE ,-1);
  SQLMSG VARCHAR2(1000);
  v_field_val       VARCHAR2(4000);
BEGIN
  --delete from priyadarshan.xml_tab;
  --insert into priyadarshan.xml_tab values(1,v_tariff_doc);
  --for i in (select x.xml_str from priyadarshan.xml_tab x where x.xml_id = 1) loop
  select TPA_TARIFF_BATCH_SEQ.nextval into v_tpa_bach_seq_id from dual;
  --v_tariff_xml := XMLTYPE.createXML(v_tariff_doc);

  v_doc            := dbms_xmldom.newdomdocument(v_tariff_doc);--v_tariff_doc
  v_root_node_list := dbms_xmldom.getelementsbytagname(v_doc, 'tariffdetails');
  
  for v_root_node_index in 0 .. dbms_xmldom.getlength(v_root_node_list) - 1 loop
    v_root_node := dbms_xmldom.item(v_root_node_list, v_root_node_index);
    v_elem      := dbms_xmldom.makeelement(v_root_node);
 
    v_parent_node_lst := dbms_xmldom.getelementsbytagname(v_elem, 'pricerefdetails');
    
    for parent_node_index in 0 .. dbms_xmldom.getlength(v_parent_node_lst) - 1 loop
      v_parent_node := dbms_xmldom.item(v_parent_node_lst, parent_node_index);
      v_elem1       := dbms_xmldom.makeelement(v_parent_node);
      
      price_ref_rec.price_ref_number:=dbms_xmldom.getAttribute(v_elem1,'pricerefno');
      price_ref_rec.added_by        :=dbms_xmldom.getAttribute(v_elem1,'userid');
      v_tariff_flag                 :=dbms_xmldom.getAttribute(v_elem1,'tariffflag');
      v_network_type                :=dbms_xmldom.getAttribute(v_elem1,'networktype');
      v_service_type                :=dbms_xmldom.getAttribute(v_elem1,'discAt');
      v_hosp_licence_numb           :=dbms_xmldom.getAttribute(v_elem1,'empanelnumber');
      v_ins_id                      :=dbms_xmldom.getAttribute(v_elem1,'insuranceid');
      v_hosp_id                     :=dbms_xmldom.getAttribute(v_elem1,'corporateid');
      v_upld_typ                    :=dbms_xmldom.getAttribute(v_elem1,'uploadType');
      --IF v_tariff_flag='HOSP' THEN
        IF v_upld_typ != 'PHARMA' THEN
          raise_application_error(-20947,'Please choose a correct file to upload.');
        END IF;
        
        if v_hosp_licence_numb is not null then
          str_tab_pd := ttk_util_pkg.parse_str ( v_hosp_licence_numb);
        end if;

        if v_ins_id is not null then
          str_tab_py := ttk_util_pkg.parse_str ( v_ins_id );
        end if;

        if v_network_type is not null then
          str_tab_nt := ttk_util_pkg.parse_str ( v_network_type );
        end if;
      --END IF;

    end loop;

    --if v_tariff_flag='HOSP' then
      FOR  payer  IN str_tab_py.First..str_tab_py.Last LOOP
        FOR provider IN str_tab_pd.First..str_tab_pd.Last LOOP
          FOR network_type IN str_tab_nt.First..str_tab_nt.Last LOOP
            v_chld_node_list := dbms_xmldom.getelementsbytagname(v_elem, 'tariff');
              
            for chld_node_index in 0 .. dbms_xmldom.getlength(v_chld_node_list) - 1 loop
              v_chld_node := dbms_xmldom.item(v_chld_node_list, chld_node_index);
              v_elem3     := dbms_xmldom.makeelement(v_chld_node);

              begin
                tariff_rec                       := null;
                v_tariff_seq_id                  := 0;
                v_act_code                       := null;
                v_act_type_id                    := 0;
                tariff_rec.activity_seq_id       := NULL;
                tariff_rec.Acitivity_Type_Seq_Id := NULL;
                tariff_rec.Service_Seq_Id		     := NULL;

                tariff_rec.price_ref_number := get_tariff_assoc_id('PRN',dbms_xmldom.getAttribute(v_elem1,'pricerefno'));
                v_act_code                  := dbms_xmldom.getAttribute(v_elem3,'activitycode');
                v_act_type_id               := dbms_xmldom.getAttribute(v_elem3,'acttypeid');
                v_service_name              := dbms_xmldom.getAttribute(v_elem3,'servicename');
                tariff_rec.internal_code    := dbms_xmldom.getAttribute(v_elem3,'internalcode');
                tariff_rec.gross_amount     := dbms_xmldom.getAttribute(v_elem3,'unitPrice');
                v_pkg_price                 := dbms_xmldom.getAttribute(v_elem3,'pkgPrince');
                tariff_rec.disc_percent     := dbms_xmldom.getAttribute(v_elem3,'discpercent');
                tariff_rec.start_date       := to_date(dbms_xmldom.getAttribute(v_elem3,'fromdate'),'dd/mm/rrrr');
                tariff_rec.end_date         := to_date(dbms_xmldom.getAttribute(v_elem3,'expirydate'),'dd/mm/rrrr');
                tariff_rec.Internal_Desc    := dbms_xmldom.getAttribute(v_elem3,'internalDesc');
                tariff_rec.hosp_act_desc    :=dbms_xmldom.getAttribute(v_elem3,'activityDesc');
                v_pkg_qnt                   :=dbms_xmldom.getAttribute(v_elem3,'pkgSize');
                ---
                v_act_code := trim(v_act_code);
                v_service_name := trim(v_service_name);
                tariff_rec.internal_code := trim(tariff_rec.internal_code);
                v_field_val := trim(tariff_rec.price_ref_number)||
                               trim(v_act_code)||
                               trim(v_act_type_id)||
                               trim(v_service_name)||
                               trim(tariff_rec.internal_code)||
                               trim(tariff_rec.gross_amount)||
                               trim(v_pkg_price)||
                               trim(tariff_rec.disc_percent)||
                               trim(tariff_rec.start_date)||
                               trim(tariff_rec.end_date)||
                               trim(tariff_rec.Internal_Desc)||
                               trim(tariff_rec.hosp_act_desc)||
                               trim(v_pkg_qnt);
                ---
                IF tariff_rec.end_date IS NOT NULL THEN
                  IF to_date(tariff_rec.end_date, 'DD/MM/RRRR') <= to_date(tariff_rec.start_date, 'DD/MM/RRRR') /*OR to_date(tariff_rec.end_date, 'DD/MM/RRRR') <= to_date(sysdate, 'DD/MM/RRRR'))*/ THEN
                    raise_application_error(-20880,'Tariff end date should be grater than start date.');
                  END IF;
                END IF;
                --
                OPEN act_cur(v_act_code);
                FETCH act_cur INTO act_rec;
                CLOSE act_cur;
                
                tariff_rec.activity_seq_id       := act_rec.act_mas_dtl_seq_id;
                tariff_rec.Acitivity_Type_Seq_Id := act_rec.activity_type_seq_id;
                tariff_rec.Service_Seq_Id	     := act_rec.service_seq_id;
                tariff_rec.internal_code         := UPPER(tariff_rec.internal_code);  
                tariff_rec.disc_amount           := round((tariff_rec.disc_amount * tariff_rec.disc_percent / 100), 2);
                IF v_act_code IS NULL THEN
                     raise_application_error(-20880,'Tariff can not be uploaded without Activity/ CPT code.');
                ELSIF v_act_code IS NULL OR tariff_rec.internal_code IS NULL OR tariff_rec.Internal_Desc IS NULL OR tariff_rec.start_date IS NULL THEN
                    raise_application_error(-20876,'Please check some of the mandatory fields are coming empty.');
                ELSIF length(v_act_code) < 15 AND act_rec.service_seq_id != 7  THEN
                    raise_application_error(-20881,'Required valid DDC code for '||tariff_rec.internal_code||'.');
                ELSIF v_pkg_price IS NOT NULL AND v_pkg_price < tariff_rec.gross_amount THEN
                    raise_application_error(-20881,'Package price cannot be less than unit price '||tariff_rec.internal_code||'.');
                ELSIF (tariff_rec.gross_amount < 0) OR (v_pkg_price < 0) OR (tariff_rec.disc_percent < 0) THEN
                    raise_application_error(-20881,'Amount field cannot be negative value. ');
                ELSE
                  SELECT COUNT(1) INTO v_count 
                    FROM app.tpa_activity_master_details a 
                    WHERE trim(upper(a.activity_code))=trim(upper(v_act_code));
                  
                  IF v_count = 0 then
                    raise_application_error(-20875,'activity code is not existing in master data.');
                  ELSE
                    IF tariff_rec.internal_code IS NOT NULL THEN
                      select CASE
                             WHEN regexp_count(upper(trim(tariff_rec.internal_code)), '[[:space:]]') > 1 THEN
                               1
                             ELSE
                               0
                             END as spc INTO v_scp_count
                      from dual;
                    
                      IF v_scp_count = 1 THEN
                        raise_application_error(-20873,'more than 1 space cannot allow for internal code '||tariff_rec.internal_code||'.');
                      END IF;
                    END IF;
                    
                    
                    v_hosp_seq_id := get_tariff_assoc_id('EMP', str_tab_pd(provider));
                    
                    select COUNT(t.internal_code) INTO v_internal_count
                    from tpa_hosp_tariff_details t
                    where t.hosp_seq_id = v_hosp_seq_id
                    and upper(t.internal_code) = upper(trim(tariff_rec.internal_code))
                    and t.network_type = UPPER(trim(str_tab_nt(network_type)))
                    and t.activity_seq_id != tariff_rec.activity_seq_id;
                        
                    IF v_internal_count > 0 THEN
                      raise_application_error(-20876,'Internal Code '||tariff_rec.internal_code||' is already assigned to other Activity code for same Provider.');
                    ELSE
                      select COUNT(t.internal_code) INTO v_internal_count
                      from tpa_hosp_tariff_details t
                      where t.hosp_seq_id = v_hosp_seq_id
                      and upper(t.internal_code) = upper(trim(tariff_rec.internal_code))
                      and t.network_type = UPPER(trim(str_tab_nt(network_type)))
                      and (to_date(tariff_rec.start_date, 'DD/MM/RRRR') BETWEEN t.start_date AND t.end_date);
                      
                      OPEN tarrif_cur (v_hosp_seq_id, tariff_rec.internal_code, str_tab_nt(network_type));
                      FETCH tarrif_cur INTO tarr_rec;
                      CLOSE tarrif_cur;
                        
                      IF to_date(tariff_rec.start_date, 'DD/MM/RRRR') <= to_date(tarr_rec.end_date, 'DD/MM/RRRR') THEN
                        v_internal_count := 1;
                      END IF;
                      
                      IF v_internal_count > 0 THEN
                        IF tarr_rec.internal_code = tariff_rec.internal_code AND tarr_rec.start_date = tariff_rec.start_date THEN
                           raise_application_error(-20876,'Same Internal Code '||tariff_rec.internal_code||' cannot be uploaded more than once in same day.');
                        END IF;                          
                        
                        raise_application_error(-20876,'Start date should be greater than previous Internal Code '||tariff_rec.internal_code);
                      END IF;
                    END IF;                    
                  END IF;
                END IF;

                save_tariff_details(v_tariff_seq_id,
                                    str_tab_pd(provider),
                                    str_tab_py(payer),
                                    null,
                                    v_tariff_flag,
                                    tariff_rec.price_ref_number,
                                    tariff_rec.activity_seq_id,
                                    tariff_rec.Acitivity_Type_Seq_Id,
                                    tariff_rec.gross_amount,
                                    tariff_rec.disc_amount,
                                    null,
                                    tariff_rec.Service_Seq_Id,
                                    tariff_rec.bundle_id,
                                    tariff_rec.Package_Id,
                                    tariff_rec.start_date,
                                    tariff_rec.end_date,
                                    'tariff upload',
                                    price_ref_rec.added_by,
                                    tariff_rec.internal_code,
                                    tariff_rec.hosp_act_desc,
                                    str_tab_nt(network_type),
                                    tariff_rec.disc_percent,
                                    tariff_rec.Internal_Desc,
                                    v_pkg_qnt,
                                    v_pkg_price,
                                    v_rows_processed);

              exception
                WHEN FOUND_DUPLICATE THEN
                  sqlmsg:= '           Activity/Service is already exist.';
                  IF v_field_val IS NOT NULL THEN
                    save_tariff_logs(v_tariff_log_seq_id,null,null,null,v_act_code,sqlcode,sqlmsg,'T',price_ref_rec.added_by,V_PRICE_REF_SEQ_ID);
                  END IF;
                WHEN NO_DATA_FOUND THEN
                  sqlmsg:= '           For Activity Service name not matching.';
                  IF v_field_val IS NOT NULL THEN
                    save_tariff_logs(v_tariff_log_seq_id,str_tab_pd(provider),str_tab_py(payer),null,v_act_code,sqlcode,sqlmsg,'T',price_ref_rec.added_by,v_tpa_bach_seq_id);
                  END IF;
                when others then
                  IF v_field_val IS NOT NULL THEN
                    if v_upld_typ = 'PHARMA' THEN
                      save_tariff_logs(v_tariff_log_seq_id,str_tab_pd(provider),str_tab_py(payer),null,v_act_code,sqlcode,sqlerrm,'T',price_ref_rec.added_by,v_tpa_bach_seq_id);
                    end if;
                  END IF;
              end;
            end loop;
          END LOOP;
        END LOOP;
      END LOOP;
    --END IF;
  end loop;

 

  for i in tariff_logs(v_tpa_bach_seq_id) loop
     v_log_file:=v_log_file||' '||'Activity code :'||i.act_code||' '||substr(i.error_message,11)||chr(13);
  end loop;
    v_log_file:=nvl(v_log_file,'Tariff details uploaded successfully');
  --end loop;

END load_hosp_pharmacy;

--==================================================================================================================================================================================
PROCEDURE dwnld_pharma_tariff(p_prov_seq_id     IN Tpa_Hosp_Info.Hosp_Seq_Id%TYPE,
                              p_resultset       OUT SYS_REFCURSOR)
AS
BEGIN

  OPEN p_resultset FOR
    SELECT nvl(am.activity_code, '-') as Activity_Code,
           nvl(t.internal_code, '-') as Internal_Code,
           nvl(s.service_name, '-') as Service_Name,
           nvl(t.internal_desc, '-') as Internal_Description,
           nvl(am.activity_description, '-') as Activity_Description,
           nvl(to_char(t.gross_amount), '-') as Unit_Price,
           nvl(to_char(t.package_price), '-') as Package_Price,
           nvl(to_char(t.disc_percent), '-') as Discount_Percentage ,
           to_char(t.start_date, 'DD-MM-RRRR') as From_Date,
           nvl(to_char(t.end_date, 'DD-MM-RRRR'), '-') as Expiry_Date,
           t.package_size as pkgsize
           
    FROM Tpa_Hosp_Tariff_Details t
    JOIN Tpa_Hosp_Info h ON (t.hosp_seq_id = h.hosp_seq_id)
    JOIN Tpa_Activity_Master_Details am ON (am.act_mas_dtl_seq_id = t.activity_seq_id)
    JOIN Tpa_Service_Details s ON (s.service_seq_id = t.service_seq_id)
    WHERE h.hosp_seq_id = p_prov_seq_id
    AND s.service_seq_id in (14, 7);
    
END dwnld_pharma_tariff;
--==================================================================================================================================================================================
PROCEDURE modify_service_type(v_licence_no          IN TPA_HOSP_INFO.HOSP_LICENC_NUMB%TYPE,
                              v_ins_comp_code       IN TPA_INS_INFO.INS_COMP_CODE_NUMBER%TYPE,
                              v_network_type        IN TPA_HOSP_TARIFF_DETAILS.NETWORK_TYPE%TYPE,
                              v_flag                IN VARCHAR2,
                              v_result              OUT SYS_REFCURSOR
                             )
AS  
BEGIN
    
  IF v_flag = 'ACT' THEN
    OPEN v_result FOR
      SELECT TD.SERVICE_SEQ_ID AS SERVICE_SEQ_ID,
             D.SERVICE_NAME||'|'||TD.NETWORK_TYPE||'|'||TD.SERVICE_SEQ_ID AS SERVICE_NAME_NETWORK_TYPE
      
      FROM APP.TPA_HOSP_TARIFF_DETAILS TD
      JOIN APP.TPA_HOSP_INFO HI ON (TD.HOSP_SEQ_ID =  HI.HOSP_SEQ_ID)
      JOIN APP.TPA_ACTIVITY_MASTER_DETAILS MD ON (MD.ACT_MAS_DTL_SEQ_ID = TD.ACTIVITY_SEQ_ID)
      JOIN APP.TPA_SERVICE_DETAILS D ON (D.SERVICE_SEQ_ID = TD.SERVICE_SEQ_ID)
      JOIN APP.TPA_INS_INFO II ON (TD.INS_SEQ_ID = II.INS_SEQ_ID)
      WHERE HI.HOSP_LICENC_NUMB IN (v_licence_no)
      AND II.INS_COMP_CODE_NUMBER = v_ins_comp_code
      AND TD.NETWORK_TYPE IN (select TRIM(COLUMN_VALUE) from 
                              XMLTABLE(('"'||REPLACE(v_network_type,'|','","')||'"')))
      AND MD.SERVICE_SEQ_ID not in (14, 7)
      GROUP BY II.INS_COMP_NAME, D.SERVICE_NAME||'|'||TD.NETWORK_TYPE, TD.SERVICE_SEQ_ID;
  ELSE
    OPEN v_result FOR
      SELECT TD.SERVICE_SEQ_ID AS SERVICE_SEQ_ID,
             D.SERVICE_NAME||'|'||TD.NETWORK_TYPE||'|'||TD.SERVICE_SEQ_ID AS SERVICE_NAME_NETWORK_TYPE
      
      FROM APP.TPA_HOSP_TARIFF_DETAILS TD
      JOIN APP.TPA_HOSP_INFO HI ON (TD.HOSP_SEQ_ID =  HI.HOSP_SEQ_ID)
      JOIN APP.TPA_ACTIVITY_MASTER_DETAILS MD ON (MD.ACT_MAS_DTL_SEQ_ID = TD.ACTIVITY_SEQ_ID)
      JOIN APP.TPA_SERVICE_DETAILS D ON (D.SERVICE_SEQ_ID = TD.SERVICE_SEQ_ID)
      JOIN APP.TPA_INS_INFO II ON (TD.INS_SEQ_ID = II.INS_SEQ_ID)
      WHERE HI.HOSP_LICENC_NUMB IN (v_licence_no)
      AND II.INS_COMP_CODE_NUMBER = v_ins_comp_code
      AND TD.NETWORK_TYPE IN (select TRIM(COLUMN_VALUE) from 
                              XMLTABLE(('"'||REPLACE(v_network_type,'|','","')||'"')))
      AND MD.SERVICE_SEQ_ID in (14, 7)
      GROUP BY II.INS_COMP_NAME, D.SERVICE_NAME||'|'||TD.NETWORK_TYPE, TD.SERVICE_SEQ_ID;
  END IF;
END modify_service_type;
--==================================================================================================================================================================================
--In this Procedure we are saving fast track & volume base discount details
--Added on 28-02-2019
--venu babu
--==================================================================================================================
PROCEDURE save_fast_track_vol_base_dtls (v_disc_seq        IN   NUMBER,
                                         v_hosp_seq_id     IN   NUMBER,
                                         v_disc_mode       IN   VARCHAR2,
                                         v_fastr_from_days IN   VARCHAR2,
                                         v_fastr_to_days   IN   VARCHAR2,
	                                       v_disc_type       IN   VARCHAR2,
                                         v_dis_vol_amt_st  IN   NUMBER,
                                         v_dis_vol_amt_ed  IN   NUMBER,
                                         v_disc_perc       IN   NUMBER,
                                         v_user_seq_id     IN   VARCHAR2,
                                         v_start_date      IN   VARCHAR2,
                                         v_end_date        IN   VARCHAR2,
                                         v_status          IN   VARCHAR2,
                                         v_rows_processed  OUT  NUMBER
                                         ) AS



v_count            NUMBER(10);
v_cnt1             VARCHAR2(10);

BEGIN
  
IF v_disc_mode ='FAST' THEN
 
    IF v_status='ACT' THEN 
       SELECT count(1) INTO v_count
           FROM app.tpa_fasttract_disc_details d
           WHERE d.hosp_seq_id =v_hosp_seq_id and
                 (TO_DATE(v_start_date,'DD-MM-YYYY')between d.start_date and (D.END_DATE) or 
                  TO_DATE(v_end_date,'DD-MM-YYYY')between d.start_date and (D.END_DATE ))
                 AND d.status='ACT' AND d.disc_mode='FAST';
                
    END IF;
           
      IF v_count>0 THEN
        RAISE_APPLICATION_ERROR(-20966,'Please Check the Configuration details...Same configuration was avilable');
      END IF; 
       
        
   IF NVL(v_disc_seq,0)=0 THEN
     INSERT INTO APP.TPA_FASTTRACT_DISC_DETAILS 
                                             (DISC_SEQ_ID,
                                              FST_FROM_DAYS,
                                              FST_TO_DAYS,
                                              DISC_MODE,
                                              DISC_PERC,
                                              START_DATE,
                                              END_DATE,
                                              STATUS,
                                              HOSP_SEQ_ID,
                                              added_by,
                                              added_date)
            	                            VALUES 
                                             (TPA_FASTTRACT_VOL_BASE_SEQ.NEXTVAL,
                                              v_fastr_from_days,
                                              v_fastr_to_days,
                                              v_disc_mode,
                                              v_disc_perc,
                                              TO_DATE(v_start_date,'DD-MM-YYYY'),
                                              TO_DATE(v_end_date,'DD-MM-YYYY'),
                                              v_status,
                                              v_hosp_seq_id,
                                              v_user_seq_id,
                                              sysdate); 
   
   ELSE
     
   update  APP.TPA_FASTTRACT_DISC_DETAILS d
   set d.STATUS 	     = v_status,
       d.updated_by    = v_user_seq_id,
       d.updated_date  = sysdate
   where d.hosp_seq_id=v_hosp_seq_id and d.disc_seq_id=v_disc_seq;
   END IF;
   
ELSIF v_disc_mode='VOL' THEN

SELECT count(1) INTO v_count
       FROM app.tpa_fasttract_disc_details d
       WHERE d.hosp_seq_id =v_hosp_seq_id 
             and (
                 (d.disc_mode='VOL' AND TO_DATE(v_start_date,'DD-MM-YYYY') between d.start_date and (d.end_date))
             or  ((d.disc_mode='VOL' and v_dis_vol_amt_st between d.disc_vol_amt_st and d.disc_vol_amt_ed)) 
             or  (d.disc_mode='VOL' AND TO_DATE(v_start_date,'DD-MM-YYYY') between d.start_date and (d.end_date))  
                 )
             AND d.status='ACT';
            
SELECT count(1) INTO v_cnt1
       FROM APP.TPA_FASTTRACT_DISC_DETAILS fa 
       WHERE fa.disc_type=v_disc_type AND fa.status='ACT' AND fa.hosp_seq_id=v_hosp_seq_id;


      IF v_count>0 THEN
        RAISE_APPLICATION_ERROR(-20966,'Please Check the Configuration details...Same configuration was avilable');
      END IF; 
      
      /*IF v_cnt1!= v_disc_type THEN
        RAISE_APPLICATION_ERROR(-20967,'Current and Previous Discount Type Configuration Should be Same...');
      END IF;*/
      
   IF NVL(v_disc_seq,0)=0 THEN
      INSERT INTO APP.TPA_FASTTRACT_DISC_DETAILS 
                                         (DISC_SEQ_ID,
                                          DISC_MODE,
                                          DISC_VOL_AMT_ST,
                                          DISC_VOL_AMT_ED,
                                          DISC_PERC,
                                          --VDP_START_DATE,
                                          START_DATE,
                                          END_DATE,
                                          STATUS,
                                          HOSP_SEQ_ID,
                                          DISC_TYPE,
                                          added_by,
                                          added_date)
                                        VALUES 
                                        (TPA_FASTTRACT_VOL_BASE_SEQ.NEXTVAL,
                                         v_disc_mode,
                                         v_dis_vol_amt_st,
                                         v_dis_vol_amt_ed,
                                         v_disc_perc,
                                         --TO_DATE(v_vol_disc_st_dt,'DD-MM-YYYY'),
                                         TO_DATE(v_start_date,'DD-MM-YYYY'),
                                         TO_DATE(v_end_date,'DD-MM-YYYY'),
                                         v_status,
                                         v_hosp_seq_id,
                                         v_disc_type,
                                         v_user_seq_id,
                                         sysdate);
   
   ELSE   
                                    
   UPDATE app.tpa_fasttract_disc_details d
   set d.status	       = v_status,
       d.updated_date  = sysdate,
       d.updated_by    = v_user_seq_id
   where d.disc_seq_id=v_disc_seq and d.hosp_seq_id=v_hosp_seq_id;
  
   END IF;
END IF;

COMMIT;
END save_fast_track_vol_base_dtls;
--===================================================================================================
PROCEDURE select_hosp_disc_details (v_hosp_seq_id    IN   NUMBER,
                                    v_disc_mode      IN   VARCHAR2,
                                    v_in_out_flag    IN   VARCHAR2,
                                    v_result         OUT  SYS_REFCURSOR
                                    )
AS

BEGIN
  
IF v_disc_mode='FAST' AND v_in_out_flag='IN' THEN
  
  OPEN v_result FOR 
     SELECT  f.disc_seq_id,TO_CHAR(f.start_date,'DD-MM-YYYY') as f_start_date,
           f.FST_FROM_DAYS||' Days' as f_FST_FROM_DAYS,f.FST_TO_DAYS||' Days' as f_FST_TO_DAYS,
           f.disc_perc as f_disc_perc,TO_CHAR(f.end_date,'DD-MM-YYYY') as f_end_date,
           CASE WHEN f.status='ACT' THEN 'Active'
                WHEN f.status='INT' THEN 'Inactive' else null end as f_status,
                  (select c.contact_name from app.tpa_user_contacts c where c.contact_seq_id= nvl(f.updated_by,f.added_by)) as added_by,
                 to_char(nvl(f.updated_date,f.added_date),'dd-mm-yyyy hh:mi am') as added_date
      FROM APP.TPA_FASTTRACT_DISC_DETAILS F
      WHERE F.HOSP_SEQ_ID = v_hosp_seq_id and f.disc_mode='FAST';
      
ELSIF v_disc_mode='VOL' AND v_in_out_flag='IN' THEN

  OPEN v_result FOR 
   SELECT CASE WHEN f.disc_type='MNPD' THEN 'Monthly Discount' END  as v_disc_type,f.disc_vol_amt_st as v_disc_vol_amt_st,f.disc_vol_amt_ed as v_disc_vol_amt_ed,
           TO_CHAR(f.vdp_start_date,'DD-MM-YYYY') as v_vdp_start_date,TO_CHAR(f.start_date,'DD-MM-YYYY') as v_start_date,TO_CHAR(f.end_date,'DD-MM-YYYY') as v_end_date,
           CASE WHEN f.status='ACT' THEN 'Active'
                WHEN f.status='INT' THEN 'Inactive' else null end as v_status,f.disc_perc as v_disc_perc,f.disc_seq_id
      FROM APP.TPA_FASTTRACT_DISC_DETAILS F
      WHERE F.HOSP_SEQ_ID = v_hosp_seq_id and f.disc_mode='VOL';

ELSIF v_disc_mode='FAST' AND v_in_out_flag='OUT' THEN

  OPEN v_result FOR 
     SELECT   TO_CHAR(f.start_date,'DD-MM-YYYY') as f_start_date,f.disc_seq_id,
           f.FST_FROM_DAYS||' Days' as f_FST_FROM_DAYS,f.FST_TO_DAYS||' Days' as f_FST_TO_DAYS,
           f.disc_perc as f_disc_perc, TO_CHAR(f.end_date,'DD-MM-YYYY') as f_end_date,
           CASE WHEN f.status='ACT' THEN 'Active'
                WHEN f.status='INT' THEN 'Inactive' else null end as f_status,
             (select c.contact_name from app.tpa_user_contacts c where c.contact_seq_id= nvl(f.updated_by,f.added_by)) as added_by,
             to_char(nvl(f.updated_date,f.added_date),'dd-mm-yyyy hh:mi am') as added_date     
      FROM APP.TPA_FASTTRACT_DISC_DETAILS F
      WHERE F.HOSP_SEQ_ID = v_hosp_seq_id and f.disc_mode='FAST' and f.status='ACT';

ELSIF v_disc_mode='VOL' AND v_in_out_flag='OUT' THEN

  OPEN v_result FOR 
   SELECT case when f.disc_type='MNPD' THEN 'Monthly Discount' END as v_disc_type,
          f.disc_vol_amt_st as v_disc_vol_amt_st,f.disc_vol_amt_ed as v_disc_vol_amt_ed,
            TO_CHAR(f.vdp_start_date,'DD-MM-YYYY') as v_vdp_start_date, TO_CHAR(f.start_date,'DD-MM-YYYY') as v_start_date, TO_CHAR(f.end_date,'DD-MM-YYYY') as v_end_date,
           CASE WHEN f.status='ACT' THEN 'Active'
                WHEN f.status='INT' THEN 'Inactive' else null end as v_status,f.disc_perc as v_disc_perc,f.disc_seq_id
      FROM APP.TPA_FASTTRACT_DISC_DETAILS F
      WHERE F.HOSP_SEQ_ID = v_hosp_seq_id and f.disc_mode='VOL' and f.status='ACT';
END IF;

END select_hosp_disc_details;  
--===================================================================================================================
END  hospital_empanel_pkg;

/

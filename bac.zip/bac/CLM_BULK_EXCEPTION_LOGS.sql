--------------------------------------------------------
--  DDL for Synonymn CLM_BULK_EXCEPTION_LOGS
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."CLM_BULK_EXCEPTION_LOGS" FOR "APP"."CLM_BULK_EXCEPTION_LOGS";

--------------------------------------------------------
--  DDL for Synonymn ENROL_UPD_SEQ_ID
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."ENROL_UPD_SEQ_ID" FOR "APP"."ENROL_UPD_SEQ_ID";

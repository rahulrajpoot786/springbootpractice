--------------------------------------------------------
--  DDL for Synonymn BULK_LOAD_CLAIM_REQUEST
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."BULK_LOAD_CLAIM_REQUEST" FOR "INTX"."BULK_LOAD_CLAIM_REQUEST";

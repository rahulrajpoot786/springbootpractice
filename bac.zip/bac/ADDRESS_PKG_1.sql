--------------------------------------------------------
--  DDL for Package ADDRESS_PKG
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "VENUBABU"."ADDRESS_PKG" 
IS
--     Author     : Raghavendra M.K.
--    Created     :
--    Project     : TTK.
--  Description   :	Package has the procedures required to process the address.
--  History of Changes:     Date   --   User -- Description
--                      2nd-Oct-2005--	Raghu  -- Created.
--
--
--
--
--


--		This procedure is used to INSERT and UPDATE the Hospital address.

  	   PROCEDURE PR_HOSPITAL_ADDRESS_SAVE (
				V_Addr_Seq_Id 			   		   IN OUT TPA_HOSP_ADDRESS.ADDR_SEQ_ID%TYPE,
				V_Hosp_Seq_Id                      IN TPA_HOSP_INFO.HOSP_SEQ_ID%Type,
				V_Address_1                        IN TPA_HOSP_ADDRESS.ADDRESS_1%Type,
				V_Address_2                        IN TPA_HOSP_ADDRESS.ADDRESS_2%Type,
				V_Address_3                        IN TPA_HOSP_ADDRESS.ADDRESS_3%Type,
				V_City_Type_Id                     IN TPA_HOSP_ADDRESS.City_Type_Id%Type,
				V_State_Type_Id                    IN TPA_HOSP_ADDRESS.STATE_TYPE_ID%Type,
				V_Pin_Code                         IN TPA_HOSP_ADDRESS.PIN_CODE%Type,
				V_Country_Id                       IN TPA_HOSP_ADDRESS.COUNTRY_ID%Type,
				V_Landmarks                        IN TPA_HOSP_ADDRESS.LANDMARKS%Type,
				V_User_ID                          IN  NUMBER,
				v_rows_processed                    OUT  NUMBER
	   );

-- - - - - - - - - - - - - -- - - - - - - - - - - - -- - - - - - - - - - - - -
--		This procedure is used to INSERT and UPDATE the Bank address.

	   PROCEDURE PR_HOSPITAL_BANK_ADDRESS_SAVE (
				V_Addr_Seq_Id 			   		   IN OUT TPA_HOSP_ADDRESS.ADDR_SEQ_ID%TYPE,
				V_HOSP_BANK_SEQ_ID                 IN TPA_HOSP_ADDRESS.HOSP_BANK_SEQ_ID%Type,
				V_Address_1                        IN TPA_HOSP_ADDRESS.ADDRESS_1%Type,
				V_Address_2                        IN TPA_HOSP_ADDRESS.ADDRESS_2%Type,
				V_Address_3                        IN TPA_HOSP_ADDRESS.ADDRESS_3%Type,
				V_City_Type_Id                     IN TPA_HOSP_ADDRESS.City_Type_Id%Type,
				V_State_Type_Id                    IN TPA_HOSP_ADDRESS.STATE_TYPE_ID%Type,
				V_Pin_Code                         IN TPA_HOSP_ADDRESS.PIN_CODE%Type,
				V_Country_Id                       IN TPA_HOSP_ADDRESS.COUNTRY_ID%Type,
        			v_branch_seq_id                    IN NUMBER,
				V_User_ID                          IN  NUMBER,
				v_rows_processed                    OUT  NUMBER
		);

-- - - - - - - - - - - - - -- - - - - - - - - - - - -- - - - - - - - - - - - -
--		This procedure is used to INSERT and UPDATE the Purchase Order address.
   PROCEDURE PR_HOSPITAL_PO_ADDRESS_SAVE (
				V_Addr_Seq_Id 			   		   IN OUT TPA_HOSP_ADDRESS.ADDR_SEQ_ID%TYPE,
				V_HOSP_GNRL_SEQ_ID                 IN TPA_HOSP_ADDRESS.HOSP_GNRL_SEQ_ID%Type,
				V_Address_1                        IN TPA_HOSP_ADDRESS.ADDRESS_1%Type,
				V_Address_2                        IN TPA_HOSP_ADDRESS.ADDRESS_2%Type,
				V_Address_3                        IN TPA_HOSP_ADDRESS.ADDRESS_3%Type,
				V_City_Type_Id                     IN TPA_HOSP_ADDRESS.City_Type_Id%Type,
				V_State_Type_Id                    IN TPA_HOSP_ADDRESS.STATE_TYPE_ID%Type,
				V_Pin_Code                         IN TPA_HOSP_ADDRESS.PIN_CODE%Type,
				V_Country_Id                       IN TPA_HOSP_ADDRESS.COUNTRY_ID%Type,
				V_User_ID                          IN  NUMBER,
				v_rows_processed                    OUT  NUMBER
		);

-- #################################################################################

 --  *******************************PARTNER LOGIN ******************************* 
 
 
--    This procedure is used to INSERT and UPDATE the Partner address.
    
     PROCEDURE PR_PARTNER_ADDRESS_SAVE (
        V_Addr_Seq_Id                       IN OUT TPA_PARTNER_ADDRESS.ADDR_SEQ_ID%TYPE,
        v_ptnr_seq_id                      IN tpa_partner_info.PTNR_SEQ_ID%TYPE,
        V_Address_1                        IN TPA_PARTNER_ADDRESS.ADDRESS_1%TYPE,
        V_Address_2                        IN TPA_PARTNER_ADDRESS.ADDRESS_2%TYPE,
        V_Address_3                        IN TPA_PARTNER_ADDRESS.ADDRESS_3%TYPE,
        V_City_Type_Id                     IN TPA_PARTNER_ADDRESS.City_Type_Id%TYPE,
        V_State_Type_Id                    IN TPA_PARTNER_ADDRESS.STATE_TYPE_ID%TYPE,
        V_Pin_Code                         IN TPA_PARTNER_ADDRESS.PIN_CODE%TYPE,
        V_Country_Id                       IN TPA_PARTNER_ADDRESS.COUNTRY_ID%TYPE,
        --V_Landmarks                        IN TPA_PARTNER_ADDRESS.LANDMARKS%TYPE,
        v_added_by                          IN  NUMBER,
        v_rows_processed                   OUT  NUMBER
     );
     
     
     ---------------------------------------------------------------------------------------		 

--		This procedure is used to INSERT and UPDATE the Bank address.
	
   PROCEDURE PR_PARTNER_BANK_ADDRESS_SAVE (
        V_Addr_Seq_Id                      IN OUT TPA_PARTNER_ADDRESS.ADDR_SEQ_ID%TYPE,
        V_PTNR_BANK_SEQ_ID                 IN TPA_PARTNER_ADDRESS.PTNR_BANK_SEQ_ID%TYPE,
        V_Address_1                        IN TPA_PARTNER_ADDRESS.ADDRESS_1%TYPE,
        V_Address_2                        IN TPA_PARTNER_ADDRESS.ADDRESS_2%TYPE,
        V_Address_3                        IN TPA_PARTNER_ADDRESS.ADDRESS_3%TYPE,
        V_City_Type_Id                     IN TPA_PARTNER_ADDRESS.City_Type_Id%TYPE,
        V_State_Type_Id                    IN TPA_PARTNER_ADDRESS.STATE_TYPE_ID%TYPE,
        V_Pin_Code                         IN TPA_PARTNER_ADDRESS.PIN_CODE%TYPE,
        V_Country_Id                       IN TPA_PARTNER_ADDRESS.COUNTRY_ID%TYPE,
        v_added_by                          IN  NUMBER,
        v_rows_processed                    OUT  NUMBER
     );
     
     
     -------------------------------------------------------------------------------------------------	 
     
--    This procedure is used to INSERT and UPDATE the Purchase Order address.
	 PROCEDURE PR_PARTNER_PO_ADDRESS_SAVE (
        V_Addr_Seq_Id                      IN OUT TPA_PARTNER_ADDRESS.ADDR_SEQ_ID%TYPE,
        V_PTNR_GNRL_SEQ_ID                 IN TPA_PARTNER_ADDRESS.PTNR_GNRL_SEQ_ID%TYPE,
        V_Address_1                        IN TPA_PARTNER_ADDRESS.ADDRESS_1%TYPE,
        V_Address_2                        IN TPA_PARTNER_ADDRESS.ADDRESS_2%TYPE,
        V_Address_3                        IN TPA_PARTNER_ADDRESS.ADDRESS_3%TYPE,
        V_City_Type_Id                     IN TPA_PARTNER_ADDRESS.City_Type_Id%TYPE,
        V_State_Type_Id                    IN TPA_PARTNER_ADDRESS.STATE_TYPE_ID%TYPE,
        V_Pin_Code                         IN TPA_PARTNER_ADDRESS.PIN_CODE%TYPE,
        V_Country_Id                       IN TPA_PARTNER_ADDRESS.COUNTRY_ID%TYPE,
        v_added_by                          IN  NUMBER,
        v_rows_processed                    OUT  NUMBER
    );
	
	
	 
	--  *******************************PartnerLogin ******************************* 
     

-- ###########################################################

END;

/

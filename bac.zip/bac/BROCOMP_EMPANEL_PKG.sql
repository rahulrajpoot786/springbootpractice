--------------------------------------------------------
--  DDL for Synonymn BROCOMP_EMPANEL_PKG
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."BROCOMP_EMPANEL_PKG" FOR "INTX"."BROCOMP_EMPANEL_PKG";

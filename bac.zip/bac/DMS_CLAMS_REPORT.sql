--------------------------------------------------------
--  DDL for Synonymn DMS_CLAMS_REPORT
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."DMS_CLAMS_REPORT" FOR "APP"."DMS_CLAMS_REPORT";

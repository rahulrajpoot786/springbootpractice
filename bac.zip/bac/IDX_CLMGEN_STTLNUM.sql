--------------------------------------------------------
--  DDL for Synonymn IDX_CLMGEN_STTLNUM
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."IDX_CLMGEN_STTLNUM" FOR "APP"."IDX_CLMGEN_STTLNUM";

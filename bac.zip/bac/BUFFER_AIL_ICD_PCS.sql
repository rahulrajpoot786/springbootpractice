--------------------------------------------------------
--  DDL for Synonymn BUFFER_AIL_ICD_PCS
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."BUFFER_AIL_ICD_PCS" FOR "APP"."BUFFER_AIL_ICD_PCS";

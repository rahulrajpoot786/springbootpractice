--------------------------------------------------------
--  DDL for Package Body HOSP_DIAGNOSYS_PKG
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "VENUBABU"."HOSP_DIAGNOSYS_PKG" 
IS

-- ===============================================================================

PROCEDURE validate_enrollment_id (
    v_tpa_enrollment_id                  IN  PAT_ENROLL_DETAILS.tpa_enrollment_id%TYPE,
    v_hosp_seq_id                        IN  tpa_hosp_info.hosp_seq_id%type,
    v_added_by                           IN  NUMBER,
    v_member_seq_id                      OUT tpa_enr_policy_member.member_seq_id%type,
    v_diag_gen_seq_id                    OUT tpa_diagnosys_gen_dtls.Diag_Gen_Seq_Id%TYPE,
    v_date_of_hosp                       IN  varchar2,
    v_rows_processed                     OUT NUMBER)
IS

v_result_set                              SYS_REFCURSOR;
v_otp_id                                  tpa_enr_pol_mem_otp_codes.otp_seq_id%type;
v_mem_status_type                         VARCHAR2(10);
v_eff_from_date                           date;
v_eff_to_date                             date;
v_date_of_exit                            date;
v_comple_yn                               VARCHAR2(10);
v_inception_date                          DATE;
v_policy_seq_id                           tpa_enr_policy.policy_seq_id%TYPE;
v_policy_group_seq_id                     tpa_enr_policy_group.policy_group_seq_id%TYPE;
v_stop_pat_yn                             tpa_ins_prod_policy.stop_preauth_yn%TYPE;
v_stop_pat_date                           tpa_ins_prod_policy.stop_preauth_date%TYPE;

CURSOR stop_pol_cur (v_pol_id tpa_enr_policy.policy_seq_id%TYPE) IS SELECT  stop_preauth_yn,stop_preauth_date  FROM app.tpa_ins_prod_policy  WHERE policy_seq_id = v_pol_id;

CURSOR stop_pro_cur  IS SELECT stop_preauth_yn,stop_preauth_date FROM app.tpa_hosp_info WHERE hosp_seq_id = v_hosp_seq_id;

CURSOR mem_stop_cur (v_mem_seq_id tpa_enr_policy_member.member_seq_id%TYPE) IS
                                                 SELECT stop_pat_clm_process_yn ,recieved_after 
                                                 FROM app.tpa_enr_policy_member tepm
                                                 WHERE tepm.member_seq_id = v_mem_seq_id; 
                                                 
CURSOR emp_stop_cur (v_emp_id tpa_enr_policy_group.policy_group_seq_id%TYPE) IS
                                                 SELECT stop_pat_clm_process_yn ,recieved_after 
                                                 FROM app.tpa_enr_policy_group tepg
                                                 WHERE tepg.policy_group_seq_id = v_emp_id; 
                                                 
BEGIN

OPEN v_result_set  FOR
  SELECT a.member_seq_id,a.status_general_type_id,c.effective_from_date,c.effective_to_date,a.date_of_exit,c.completed_yn, a.date_of_inception,c.policy_seq_id,b.policy_group_seq_id
  FROM   tpa_enr_policy_member A
  JOIN tpa_enr_policy_group B ON (A.policy_group_seq_id = B.policy_group_seq_id)
  JOIN tpa_enr_policy C ON (B.policy_seq_id = C.policy_seq_id )
  WHERE  (a.tpa_enrollment_id=v_tpa_enrollment_id or a.emirate_id=v_tpa_enrollment_id)
  AND ( SYSDATE BETWEEN C.effective_from_date AND C.effective_to_date+1);
FETCH v_result_set INTO v_member_seq_id,v_mem_status_type,v_eff_from_date,v_eff_to_date,v_date_of_exit,v_comple_yn, v_inception_date,v_policy_seq_id,v_policy_group_seq_id;
CLOSE v_result_set;

OPEN stop_pol_cur(v_policy_seq_id);
FETCH stop_pol_cur INTO v_stop_pat_yn,v_stop_pat_date;
CLOSE stop_pol_cur;

IF v_member_seq_id IS NULL THEN
  RAISE_APPLICATION_ERROR(-20265,'Please enter a valid Vidal Id');
END IF;

IF ((v_mem_status_type = 'POC' or v_mem_status_type = 'POA') AND (v_date_of_exit < to_date(v_date_of_hosp,'dd/mm/yyyy') or v_comple_yn='N')) OR (to_date(v_date_of_hosp,'dd/mm/yyyy') < to_date(v_inception_date,'dd/mm/yyyy')) THEN
  RAISE_APPLICATION_ERROR(-20271,'Vidal Id Is Not Active');
END IF;

IF to_date(v_date_of_hosp,'dd/mm/yyyy') < v_eff_from_date OR to_date(v_date_of_hosp,'dd/mm/yyyy') > v_eff_to_date THEN
  RAISE_APPLICATION_ERROR(-20272,'Date of Adimission not between policy period');
END IF;

IF v_stop_pat_yn='Y' AND trunc(sysdate) >= trunc(v_stop_pat_date) THEN
   RAISE_APPLICATION_ERROR(-20414,'Member is not covered as the contract between Corporate & Al Koot is on hold');
END IF;

OPEN emp_stop_cur(v_policy_group_seq_id);
FETCH emp_stop_cur INTO v_stop_pat_yn,v_stop_pat_date;
CLOSE emp_stop_cur;

IF v_stop_pat_yn='Y' AND trunc(sysdate) >= trunc(v_stop_pat_date) THEN
   RAISE_APPLICATION_ERROR(-20417,'Member is not eligible for treatment as the contract between member & Al Koot is on hold');
END IF;

OPEN mem_stop_cur(v_member_seq_id);
FETCH mem_stop_cur INTO v_stop_pat_yn,v_stop_pat_date;
CLOSE mem_stop_cur;

IF v_stop_pat_yn='Y' AND trunc(sysdate) >= trunc(v_stop_pat_date) THEN
   RAISE_APPLICATION_ERROR(-20417,'Member is not eligible for treatment as the contract between member & Al Koot is on hold');
END IF;

OPEN stop_pro_cur ;
FETCH stop_pro_cur INTO v_stop_pat_yn,v_stop_pat_date;
CLOSE stop_pro_cur;

IF v_stop_pat_yn='Y' AND trunc(sysdate) >= trunc(v_stop_pat_date) THEN
   RAISE_APPLICATION_ERROR(-20416,'The eligibility check option is disabled since the contract between your facility & Al Koot is on hold');
END IF;

/*IF v_member_seq_id IS NOT NULL AND NVL(v_diag_gen_seq_id,0)=0 THEN
 INSERT INTO  tpa_diagnosys_gen_dtls(
                   diag_gen_seq_id,
                   hosp_seq_id,
                   member_seq_id,
                   intimated_yn,
                   added_by,
                   added_date)
   VALUES (tpa_diag_test_seq.nextval,
           v_hosp_seq_id,
           v_member_seq_id,
           'N',
           v_added_by,
           SYSDATE ) RETURNING diag_gen_seq_id INTO v_diag_gen_seq_id ;
          
 IF NVL(v_diag_gen_seq_id,0)!=0 THEN
   generate_otp(v_member_seq_id,v_diag_gen_seq_id,v_added_by ,v_otp_id );
 END IF;
 
END IF;*/
 v_rows_processed:=SQL%ROWCOUNT;
commit;
END validate_enrollment_id;
--=================================================================================
PROCEDURE select_diag_mem_list(v_pre_auth_number              IN pat_enroll_details.pre_auth_number%TYPE,
                               v_auth_number                  IN pat_enroll_details.auth_number%TYPE,
                               v_mem_name                     IN VARCHAR2,
                               v_tpa_enrollment_id            IN tpa_enr_policy_member.tpa_enrollment_id%type,
                               v_otp_confirm_yn        IN CHAR,
                               v_bill_complete_yn             IN CHAR,
                               v_start_date                   IN VARCHAR2,
                               v_end_date                     IN VARCHAR2,
                               v_hosp_seq_id                  IN tpa_hosp_info.hosp_seq_id%TYPE,
                               v_sort_var                     IN  VARCHAR2,
                               v_sort_order                   IN  VARCHAR2 ,
                               v_start_num                    IN  NUMBER ,
                               v_end_num                      IN  NUMBER ,
                               result_set                   OUT SYS_REFCURSOR)


IS
 TYPE bind_tab_type IS TABLE OF VARCHAR2(250) INDEX BY BINARY_INTEGER ;
     bind_tab                             bind_tab_type;
     i                                    BINARY_INTEGER :=0;
     v_where                              VARCHAR2(3000);
     v_sql_str                        VARCHAR2(2000);
     v_from_date                date:=to_date(v_start_date,'DD/MM/YYYY');
     v_to_date                  date:=to_date(v_end_date,'DD/MM/YYYY');
     v_validate_status          tpa_enr_pol_mem_otp_codes.status%type;

BEGIN

v_sql_str:=
'SELECT tepm.tpa_enrollment_id,
       tdgd.added_date as admission_date,
       ped.pre_auth_number,
       ped.auth_number,
       tdgd.total_entered_rate tot_bill_req_amount,
       tdgd.total_discount_rate after_disc_bill_req_amount,
       tepoc.ref_number,
       tepm.mem_name,
       tdgd.diag_gen_seq_id,
       tdgd.hosp_seq_id, 
       tdgd.member_seq_id 

FROM tpa_diagnosys_gen_dtls tdgd
JOIN tpa_enr_policy_member tepm ON (tdgd.member_seq_id=tepm.member_seq_id)
JOIN Tpa_Enr_Pol_Mem_Otp_Codes tepoc ON (tdgd.member_seq_id=tepoc.member_seq_id and tdgd.diag_gen_seq_id=tepoc.diag_gen_seq_id AND tepoc.active_yn=''Y'')
LEFT OUTER JOIN pat_general_details pgd on (tdgd.diag_gen_seq_id=pgd.diag_gen_seq_id and pgd.pat_enhanced_yn=''N'')
LEFT OUTER JOIN pat_enroll_details ped on (pgd.pat_enroll_detail_seq_id=ped.pat_enroll_detail_seq_id )
WHERE  tdgd.hosp_seq_id = :v_hosp_seq_id ' ;

IF v_pre_auth_number IS NOT NULL THEN
       v_where :=  v_where||' AND ped.pre_auth_number = :v_pre_auth_number ';
       i := i+1;
       bind_tab(i) := UPPER(v_pre_auth_number);
END IF;

IF v_auth_number IS NOT NULL THEN
       v_where :=  v_where||' AND ped.auth_number = :v_auth_number ';
       i := i+1;
       bind_tab(i) := UPPER(v_auth_number);
END IF;

IF v_mem_name IS NOT NULL THEN
       v_where :=  v_where||' AND tepm.mem_name like :v_mem_name';
       i := i+1;
       bind_tab(i) := UPPER(v_mem_name||'%');
END IF;

IF v_tpa_enrollment_id IS NOT NULL THEN
       v_where :=  v_where||' AND tepm.tpa_enrollment_id = :v_tpa_enrollment_id ';
       i := i+1;
       bind_tab(i) := UPPER(v_tpa_enrollment_id);
END IF;


IF v_from_date IS NOT NULL THEN
       v_where :=  v_where||' AND tdgd.added_date > = :v_from_date ';
       i := i+1;
       bind_tab(i) := UPPER(v_from_date);
END IF;

IF v_to_date IS NOT NULL THEN
       v_where :=  v_where||' AND tdgd.added_date < =:v_to_date ';
       i := i+1;
       bind_tab(i) := UPPER(v_to_date);
END IF;

IF v_otp_confirm_yn IS NOT NULL THEN
  v_validate_status:=CASE WHEN v_otp_confirm_yn='Y' THEN 'VALIDATED'  WHEN v_otp_confirm_yn='N'  THEN 'NOTVALIDATED' END ;
       v_where :=  v_where||' AND NVL(tepoc.status,''NOTVALIDATED'')=:v_validate_status ';
       i := i+1;
       bind_tab(i) := UPPER(v_validate_status);
END IF;

IF v_bill_complete_yn IS NOT NULL THEN  
       v_where :=  v_where||' AND NVL(tdgd.intimated_yn,''N'') = :v_bill_complete_yn ';
       i := i+1;
       bind_tab(i) := UPPER(v_bill_complete_yn);
END IF;

v_sql_str:=v_sql_str||v_where ;

    v_sql_str := 'SELECT * FROM
        (SELECT A.*,DENSE_RANK() OVER (ORDER BY '||v_sort_var||' '||v_sort_order||',ROWNUM)
        Q FROM (' ||v_sql_str|| ') A ) WHERE  Q>= :v_start_num AND Q<= :v_end_num ';


  IF bind_tab.FIRST IS NOT NULL THEN
       CASE bind_tab.COUNT
         WHEN 1  THEN OPEN result_set FOR v_sql_str USING v_hosp_seq_id,bind_tab(1), v_start_num , v_end_num ;
         WHEN 2  THEN OPEN result_set FOR v_sql_str USING v_hosp_seq_id,bind_tab(1),bind_tab(2), v_start_num , v_end_num ;
         WHEN 3  THEN OPEN result_set FOR v_sql_str USING v_hosp_seq_id,bind_tab(1),bind_tab(2) ,bind_tab(3) , v_start_num , v_end_num ;
         WHEN 4  THEN OPEN result_set FOR v_sql_str USING v_hosp_seq_id,bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) , v_start_num , v_end_num ;
         WHEN 5  THEN OPEN result_set FOR v_sql_str USING v_hosp_seq_id,bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) , bind_tab(5),v_start_num , v_end_num ;
         WHEN 6  THEN OPEN result_set FOR v_sql_str USING v_hosp_seq_id,bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) , bind_tab(5),bind_tab(6),v_start_num , v_end_num ;
         WHEN 7  THEN OPEN result_set FOR v_sql_str USING v_hosp_seq_id,bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) , bind_tab(5),bind_tab(6),bind_tab(7),v_start_num , v_end_num ;
         WHEN 8  THEN OPEN result_set FOR v_sql_str USING v_hosp_seq_id,bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) , bind_tab(5),bind_tab(6),bind_tab(7),bind_tab(8),v_start_num , v_end_num ;
         WHEN 9  THEN OPEN result_set FOR v_sql_str USING v_hosp_seq_id,bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) , bind_tab(5),bind_tab(6),bind_tab(7),bind_tab(8),bind_tab(9),v_start_num , v_end_num ;
         WHEN 10  THEN OPEN result_set FOR v_sql_str USING v_hosp_seq_id,bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) , bind_tab(5),bind_tab(6),bind_tab(7),bind_tab(8),bind_tab(9),bind_tab(10),v_start_num , v_end_num ;
         END CASE;
     ELSE
       OPEN result_set FOR v_sql_str USING v_hosp_seq_id,v_start_num , v_end_num ;
   END IF;

END select_diag_mem_list;
--=================================================================================

PROCEDURE save_diagnosys_details (
    v_diag_enroll_seq_id                 IN OUT tpa_diagnosys_enroll_dtls.diag_enroll_seq_id%type,
    v_diag_test_seq_id                   IN tpa_diagnosys_enroll_dtls.diag_test_seq_id%TYPE,
    v_diag_gen_seq_id                    IN tpa_diagnosys_enroll_dtls.Diag_Gen_Seq_Id%TYPE,
    v_entered_rate                       IN tpa_diagnosys_enroll_dtls.Entered_Rate%TYPE,
    v_agreed_rate                        IN tpa_diagnosys_enroll_dtls.Agreed_Rate%TYPE,
    v_discount_perc                      IN tpa_diagnosys_enroll_dtls.Discount_Perc%TYPE,
    v_discount_rate                      IN tpa_diagnosys_enroll_dtls.Discount_Rate%TYPE,
    v_added_by                           IN  NUMBER,
    v_rows_processed                     OUT NUMBER)
IS

CURSOR mem_otp_cur IS
SELECT tepo.status FROM tpa_enr_pol_mem_otp_codes tepo
WHERE tepo.diag_gen_seq_id=v_diag_gen_seq_id
AND tepo.active_yn='Y';

otp_rec  mem_otp_cur%ROWTYPE;


BEGIN

OPEN mem_otp_cur;
FETCH mem_otp_cur INTO otp_rec;
CLOSE mem_otp_cur;

IF NVL(otp_rec.status,'NOTVALIDATED')!='VALIDATED' THEN
   RAISE_APPLICATION_ERROR(-20266,'Please validate the OTP Number');
END IF;  

IF  NVL(v_diag_enroll_seq_id,0)=0 THEN
 INSERT INTO  tpa_diagnosys_enroll_dtls(
              diag_enroll_seq_id,
              diag_test_seq_id,
              diag_gen_seq_id,
              entered_rate,
              agreed_rate,
              discount_perc,
              discount_rate,
              added_by,
              added_date)
   VALUES (tpa_diag_enroll_seq.nextval,
           v_diag_test_seq_id,
           v_diag_gen_seq_id,
           v_entered_rate,
           CASE WHEN v_entered_rate>v_agreed_rate THEN v_agreed_rate ELSE v_entered_rate END,
           v_discount_perc,
           CASE WHEN v_entered_rate>v_agreed_rate THEN v_agreed_rate-(v_agreed_rate*v_discount_perc)/100 ELSE v_entered_rate-(v_entered_rate*v_discount_perc)/100 END,
           v_added_by,
           SYSDATE ) RETURNING diag_enroll_seq_id INTO v_diag_enroll_seq_id ;

ELSE

        UPDATE tpa_diagnosys_enroll_dtls tded
        SET    tded.entered_rate  = v_entered_rate,
               tded.agreed_rate  = v_agreed_rate,
               tded.discount_perc = v_discount_perc,
               tded.discount_rate = v_discount_rate,
               tded.updated_by = v_added_by,
               tded.updated_date = SYSDATE
         WHERE tded.diag_enroll_seq_id = v_diag_enroll_seq_id;

END IF;

 v_rows_processed:=SQL%ROWCOUNT;
COMMIT;
END save_diagnosys_details;
--=================================================================================


--=================================================================================
PROCEDURE save_diagnosys_details(
  v_diag_seq_id       IN diagnosys_details.diag_seq_id%type,
  v_pat_auth_seq_id   IN diagnosys_details.pat_auth_seq_id%type,
  v_diagnosys_code    IN diagnosys_details.diagnosys_code%type,
  v_priamry_yn        IN diagnosys_details.Primary_Ailment_Yn%TYPE,
  v_added_by          IN diagnosys_details.added_by%type )
IS
cursor dig is    select tic.icd10_seq_id from tpa_icd10_master_details tic 
where tic.icd_code=v_diagnosys_code;
v_icd_code_seq_id number;

cursor pat_diag_ben is
  select p.benifit_type as icd_benefit, i.benefit_type as pat_benefit
  from pat_authorization_details p
  join diagnosys_details d on (d.pat_auth_seq_id = p.pat_auth_seq_id)
  join tpa_icd10_master_details i on (i.icd_code = d.diagnosys_code)
  where p.pat_auth_seq_id = v_pat_auth_seq_id
  and d.primary_ailment_yn = 'Y';

pat_diag_ben_rec          pat_diag_ben%ROWTYPE;

BEGIN
  
  OPEN dig;
  FETCH dig INTO v_icd_code_seq_id;
  CLOSE dig;

  OPEN pat_diag_ben;
  FETCH pat_diag_ben INTO pat_diag_ben_rec;
  CLOSE pat_diag_ben;
  
  IF pat_diag_ben_rec.icd_benefit IS NOT NULL THEN
    IF pat_diag_ben_rec.icd_benefit != pat_diag_ben_rec.pat_benefit then
      RAISE_APPLICATION_ERROR(-20323,'Ailment does not belogs to the selected benefit type, please select Dental benefit type!');
    END IF;
  END IF;
  
IF  NVL(v_diag_seq_id,0)=0 THEN
  

 INSERT INTO  diagnosys_details(
              diag_seq_id,
              pat_auth_seq_id,
              icd_code_seq_id,
              diagnosys_code,
              primary_ailment_yn,
              added_by,
              added_date)
   VALUES (diagnosys_detail_seq.nextval,
              v_pat_auth_seq_id,
              v_icd_code_seq_id,
              v_diagnosys_code,
              v_priamry_yn,
              v_added_by,
           SYSDATE )  ;
  ELSE
        UPDATE diagnosys_details dd
        SET    
               dd.pat_auth_seq_id = v_pat_auth_seq_id,
               dd.icd_code_seq_id = v_icd_code_seq_id,
               dd.diagnosys_code = v_diagnosys_code,
               dd.primary_ailment_yn = v_priamry_yn,
               dd.updated_by = v_added_by,
               dd.updated_date = SYSDATE
         WHERE dd.diag_seq_id = v_diag_seq_id;

  END IF;

COMMIT;
END save_diagnosys_details;
--=================================================================================

PROCEDURE select_diagnosys_test_list (v_hosp_seq_id                      IN tpa_hosp_info.hosp_seq_id%type,
                                         v_result_set                       OUT SYS_REFCURSOR)
IS

BEGIN

  OPEN v_result_set FOR
  SELECT tdcd.diag_test_seq_id,
         tdcd.hosp_seq_id,
         tdcd.test_name,
         tdcd.rate,
         tdcd.discount
   FROM  tpa_diagnosys_center_dtls tdcd
  WHERE tdcd.hosp_seq_id=v_hosp_seq_id;

END  select_diagnosys_test_list;


--=================================================================================
PROCEDURE select_diagnosys_test_details (v_diag_gen_seq_id                  IN tpa_diagnosys_enroll_dtls.diag_gen_seq_id%TYPE,
                                         --vidal_result_set                       OUT SYS_REFCURSOR,
                                         diagnosys_enrol_result                 OUT SYS_REFCURSOR)
IS

BEGIN
/*
OPEN vidal_result_set FOR
WITH amt_tab AS (SELECT SUM(nvl(entered_rate,0)) AS tot_entered_rate,
                        SUM(nvl(agreed_rate ,0)) AS tot_agreed_rate,
                        SUM(nvl(discount_perc ,0)) AS tot_discount_perc,
                        SUM(nvl(discount_rate ,0)) AS tot_discount_rate,
                        tded.diag_gen_seq_id
 FROM tpa_diagnosys_enroll_dtls tded
                 WHERE tded.diag_gen_seq_id =v_diag_gen_seq_id
                GROUP BY tded.diag_gen_seq_id )
 SELECT tdgd.member_seq_id,
        tdgd.hosp_seq_id,
        tepm.tpa_enrollment_id tpa_enrollment_id,
        TO_CHAR(NVL(tdgd.total_entered_rate,at.tot_entered_rate),'FM9999999999.009') as total_entered_rate,
        TO_CHAR(nvl(tdgd.total_agreed_rate,at.tot_agreed_rate),'FM9999999999.009') as total_agreed_rate,
        nvl(tdgd.total_discount_perc,at.tot_discount_perc) as total_discount_perc,
        TO_CHAR(nvl(tdgd.total_discount_rate,at.tot_discount_rate),'FM99999999990.009') as total_discount_rate,
        tdgd.rejected_amount as rejected_amount,
        replace(replace(tdgd.remarks,chr(10),''),chr(13),'') as remarks,
        ped.pre_auth_number,
        ped.auth_number as auth_number,
        account_info_pkg.get_gen_desc(ped.pat_status_general_type_id,'G') AS preauth_status

  FROM tpa_diagnosys_gen_dtls tdgd
 JOIN tpa_enr_policy_member tepm ON (tdgd.member_seq_id=tepm.member_seq_id)
 LEFT OUTER JOIN pat_general_details pgd ON (tdgd.diag_gen_seq_id=pgd.diag_gen_seq_id AND pgd.pat_enhanced_yn='N')
 LEFT OUTER JOIN pat_enroll_details ped ON (pgd.pat_enroll_detail_seq_id=ped.pat_enroll_detail_seq_id)
 LEFT OUTER JOIN amt_tab at ON (tdgd.diag_gen_seq_id=at.diag_gen_seq_id)
 WHERE tdgd.diag_gen_seq_id = v_diag_gen_seq_id;

*/
  OPEN diagnosys_enrol_result FOR
  SELECT tded.diag_enroll_seq_id,
         tded.diag_test_seq_id,
         tded.diag_gen_seq_id,
         TO_CHAR(tded.entered_rate,'FM9999999999.009') entered_rate,
         TO_CHAR(tded.agreed_rate,'FM9999999999.009') agreed_rate,
         tded.discount_perc discount_perc,
         TO_CHAR(tded.discount_rate,'FM9999999999.009') discount_rate,
         tdcd.test_name test_name

   FROM  tpa_diagnosys_enroll_dtls tded
   JOIN tpa_diagnosys_center_dtls tdcd on (tded.diag_test_seq_id=tdcd.diag_test_seq_id)
  WHERE tded.diag_gen_seq_id=v_diag_gen_seq_id;

END  select_diagnosys_test_details;

--=================================================================================
PROCEDURE select_diag_test(v_str   IN VARCHAR2,
                           v_result_set  OUT SYS_REFCURSOR)

IS

v_out                    VARCHAR2(2500);

BEGIN
  v_out:=REPLACE(v_str,'|',',');

      OPEN v_result_set FOR
     ' SELECT tdcd.diag_test_seq_id,
         tdcd.hosp_seq_id,
         tdcd.test_name,
         tdcd.rate,
         tdcd.discount
   FROM  tpa_diagnosys_center_dtls tdcd
  WHERE tdcd.diag_test_seq_id IN ( ' ||v_out||')';


END    select_diag_test;
--=================================================================================
PROCEDURE generate_otp(v_member_seq_id       IN tpa_enr_policy_member.member_seq_id%type,
                       v_diag_gen_seq_id     IN tpa_diagnosys_gen_dtls.diag_gen_seq_id%type,
                       v_added_by            IN NUMBER,
                       v_otp_id              OUT NUMBER)
IS
CURSOR mem_otp_cur IS
SELECT * FROM tpa_enr_pol_mem_otp_codes tepo
WHERE tepo.member_seq_id=v_member_seq_id
and tepo.diag_gen_seq_id=v_diag_gen_seq_id
AND tepo.active_yn='Y';

CURSOR otp_gen_cur IS
SELECT otp.mobile_no, otp.email_id, otp.otp_number
FROM tpa_enr_pol_mem_otp_codes otp
WHERE otp.member_seq_id=v_member_seq_id
AND otp.active_yn='Y';

CURSOR mem_phone_cur IS
SELECT NVL(ttk_util_pkg.fn_decrypt(tema.mobile_no),ttk_util_pkg.fn_decrypt(tepa.mobile_no)) as mobile_no,tepm.tpa_enrollment_id,
nvl(ttk_util_pkg.fn_decrypt(tema.email_id),ttk_util_pkg.fn_decrypt(tepa.email_id)) as email_id
 FROM tpa_enr_policy_member tepm
JOIN tpa_enr_policy_group tepg on (tepm.policy_group_seq_id=tepg.policy_group_seq_id)
LEFT OUTER JOIN tpa_enr_mem_address tema ON (tepm.enr_address_seq_id=tema.enr_address_seq_id)
LEFT OUTER JOIN tpa_enr_mem_address tepa ON (tepg.enr_address_seq_id=tepa.enr_address_seq_id)
WHERE tepm.member_seq_id=v_member_seq_id;

otp_rec  mem_otp_cur%ROWTYPE;
v_otp_number        VARCHAR2(10);
v_mobile_no         tpa_enr_mem_address.mobile_no%type;
v_mobile_no1        tpa_enr_mem_address.mobile_no%type;
v_dest_msg_seq_id   destination_message.dest_msg_seq_id%type;
v_tpa_id            tpa_enr_policy_member.tpa_enrollment_id%type;
v_otp_number1       tpa_enr_pol_mem_otp_codes.otp_number%TYPE;
v_email_id          tpa_enr_mem_address.email_id%type;
v_email_id1         tpa_enr_mem_address.email_id%type;
v_ref_number        tpa_enr_pol_mem_otp_codes.ref_number%type;


BEGIN

OPEN mem_otp_cur;
FETCH mem_otp_cur INTO otp_rec;
CLOSE mem_otp_cur;

IF otp_rec.otp_seq_id IS NOT NULL THEN
   UPDATE tpa_enr_pol_mem_otp_codes tepo
   SET    tepo.active_yn='N',
           tepo.updated_by=v_added_by,
           tepo.updated_date=sysdate
   WHERE tepo.otp_seq_id=otp_rec.otp_seq_id ;
END IF;


IF NVL(v_member_seq_id,0)!=0 THEN
  
    OPEN mem_phone_cur;
    FETCH mem_phone_cur INTO v_mobile_no,v_tpa_id,v_email_id;
    CLOSE mem_phone_cur;

  v_otp_number:=DBMS_RANDOM.STRING('B',2)||lpad(tpa_otp_gen_seq.Nextval,4,0);
  v_ref_number:=TO_NUMBER(to_char(sysdate,'YYMMDDHH24MISS'));
  INSERT INTO tpa_enr_pol_mem_otp_codes
         (otp_seq_id,
          member_seq_id,
          otp_number,
          REF_NUMBER,
          mobile_no,
          generated_date,
          active_yn,
          added_by,
          added_date,
          email_id,
          diag_gen_seq_id)
  VALUES  (Tpa_Mem_Otp_Seq.Nextval,
          v_member_seq_id,
          v_otp_number,
          v_ref_number,
          /*v_mobile_no,--'8050021725,9008087799,*/'9845366164',--sarthak
          sysdate,
          'Y',
          v_added_by,
          SYSDATE,
          v_email_id,
          v_diag_gen_seq_id) RETURN otp_seq_id INTO v_otp_id;
          
   OPEN otp_gen_cur;
    FETCH otp_gen_cur INTO v_mobile_no1,v_email_id1, v_otp_number1;
    CLOSE otp_gen_cur;

   generate_mail_pkg.proc_generate_message('OTP_SMS_INT',v_member_seq_id,1,v_dest_msg_seq_id);

END IF;


END   generate_otp  ;
--=================================================================================
PROCEDURE validate_otp(v_diag_gen_seq_id                    IN tpa_diagnosys_gen_dtls.Diag_Gen_Seq_Id%TYPE,
                       v_otp_number                         IN tpa_enr_pol_mem_otp_codes.otp_number%type,
                       v_otp_outdated_yn                    OUT CHAR,
                       v_otp_blocked_yn                     OUT CHAR,
                       v_otp_wrong_yn                       OUT CHAR,
                       v_validated_yn                       OUT CHAR,
                       v_added_by                           IN NUMBER,
                       v_rows_processed                     OUT NUMBER)
IS

CURSOR mem_otp_cur IS
SELECT * FROM tpa_enr_pol_mem_otp_codes tepo
WHERE tepo.diag_gen_seq_id=v_diag_gen_seq_id
AND tepo.active_yn='Y';

otp_rec  mem_otp_cur%ROWTYPE;

BEGIN

    OPEN mem_otp_cur;
    FETCH mem_otp_cur INTO otp_rec;
    CLOSE mem_otp_cur;

    v_otp_outdated_yn:='N';
    v_otp_blocked_yn:='N';
    v_otp_wrong_yn:='N';


   IF v_otp_number IS NOT NULL AND TRIM(v_otp_number)=otp_rec.otp_number AND NVL(otp_rec.wrong_attempts,0)<3 THEN

     IF ROUND(((SYSDATE-otp_rec.Generated_Date)*24)*60) > 60 THEN
           v_otp_outdated_yn:='Y';
           --RAISE_APPLICATION_ERROR(-20267,'Entered OTP Number is outdated, Please generate New OTP number');
     END IF;

     IF v_otp_outdated_yn='N' THEN
       UPDATE tpa_enr_pol_mem_otp_codes tepo
       SET tepo.status='VALIDATED',
           tepo.updated_by=v_added_by,
           tepo.updated_date=sysdate
       WHERE tepo.otp_seq_id=otp_rec.otp_seq_id;
     END IF;

   ELSE

    IF nvl(otp_rec.wrong_attempts,0)>=2 THEN
      v_otp_blocked_yn:='Y';
      --RAISE_APPLICATION_ERROR(-20268,'Enterd OTP number is Blocked,Please generate New OTP Number!');
    END IF;

   IF  nvl(otp_rec.wrong_attempts,0) <=2 THEN
     UPDATE tpa_enr_pol_mem_otp_codes tepo
       SET tepo.status='WRONGOTP',
           tepo.wrong_attempts=NVL(tepo.wrong_attempts,0)+1,
           tepo.updated_by=v_added_by,
           tepo.updated_date=sysdate
       WHERE tepo.diag_gen_seq_id=otp_rec.diag_gen_seq_id
       AND tepo.active_yn='Y';
   END IF;

    COMMIT;

   v_otp_wrong_yn:='Y';
     --RAISE_APPLICATION_ERROR(-20269,'Enterd OTP number is wrong,Please try again!');
   END IF;

   IF v_otp_outdated_yn='N' AND  v_otp_blocked_yn='N' AND v_otp_wrong_yn='N' THEN
     v_validated_yn:='Y';
   ELSE
     v_validated_yn:='N';
   END IF;

v_rows_processed:=SQL%ROWCOUNT;

COMMIT;
END   validate_otp;
/*PROCEDURE validate_otp (v_mem_seq_id IN tpa_enr_pol_mem_otp_codes.member_seq_id%TYPE,
                              v_otp        IN tpa_enr_pol_mem_otp_codes.otp_number%type,
                              v_added_by   IN tpa_enr_pol_mem_otp_codes.added_by%type,
                              v_otp_status OUT tpa_enr_pol_mem_otp_codes.status%TYPE)
 AS
   v_otp_chk tpa_enr_pol_mem_otp_codes.otp_number%type;
   v_mem_seq_id_check tpa_enr_pol_mem_otp_codes.member_seq_id%TYPE;
   
   CURSOR otp_cur IS
     SELECT otp.otp_seq_id, otp.otp_number otp, otp.member_seq_id mem_seq_id
     FROM tpa_enr_pol_mem_otp_codes otp
     WHERE otp.member_seq_id = v_mem_seq_id
     AND otp.active_yn = 'Y';
     
     v_otp_cur otp_cur%ROWTYPE;
 BEGIN
   IF v_otp IS NOT NULL AND v_mem_seq_id IS NOT NULL THEN
     open otp_cur;
     fetch otp_cur into v_otp_cur;
     close otp_cur;
     
     IF v_otp_cur.otp <> v_otp THEN
       raise_application_error(-20012, 'Invalid OTP Entered');
     ELSE
       UPDATE tpa_enr_pol_mem_otp_codes o
       SET o.status = 'VALIDATED', o.added_by = v_added_by
       WHERE o.member_seq_id = v_otp_cur.mem_seq_id
       AND o.otp_seq_id = v_otp_cur.otp_seq_id;
       
       v_otp_status := 'Success';
     END IF;
   ELSE
     raise_application_error(-20013, 'Invalid Member ID or OTP');
   END IF;
 END validate_otp;*/
--=================================================================================

PROCEDURE gen_bill_report1(v_diag_gen_seq_id                  IN tpa_diagnosys_enroll_dtls.diag_gen_seq_id%TYPE,
                          v_result_set                       OUT SYS_REFCURSOR)

  IS

  BEGIN

  OPEN v_result_set FOR
  WITH amt_tab AS (SELECT SUM(nvl(entered_rate,0)) AS tot_entered_rate,
                          SUM(nvl(agreed_rate ,0)) AS tot_agreed_rate,
                          SUM(nvl(discount_perc ,0)) AS tot_discount_perc,
                          SUM(nvl(discount_rate ,0)) AS tot_discount_rate,
                          tded.diag_gen_seq_id
   FROM tpa_diagnosys_enroll_dtls tded
                   WHERE tded.diag_gen_seq_id =v_diag_gen_seq_id
                  GROUP BY tded.diag_gen_seq_id )
   SELECT tdgd.member_seq_id,
          tdgd.hosp_seq_id,
          tepm.tpa_enrollment_id,
          NVL(tdgd.total_entered_rate,at.tot_entered_rate) as total_entered_rate,
          nvl(tdgd.total_agreed_rate,at.tot_agreed_rate) as total_agreed_rate,
          nvl(tdgd.total_discount_perc,at.tot_discount_perc) as total_discount_perc,
          at.tot_discount_rate as total_discount_rate,
          tdgd.rejected_amount AS rejected_amount,
          tdgd.remarks AS remarks,
          thi.hosp_name AS hosp_name,
          toi.office_name as location,
          tha.address_1 address_1,
          tha.address_2 address_2,
          tha.address_3 address_3,
          to_char(tha.pin_code) pin_code,
          ped.auth_number pre_auth_number,
          to_char(pgd.pat_received_date,'DD/MM/YYYY') pat_received_date,
          tepm.mem_name mem_name,
          sysdate as generated_date,
          'Vidal Healthcare Services Pvt Ltd'||', '||ta.address_1||', '||ta.address_2||', '||ta.address_3||', '||tcc.city_description||' - '||ta.pin_code||', '||'Fax No:'||nvl(tooi.office_fax_no_1,tooi.office_fax_no_2) footer


   FROM tpa_diagnosys_gen_dtls tdgd
   JOIN tpa_enr_policy_member tepm ON (tdgd.member_seq_id=tepm.member_seq_id)
   JOIN tpa_hosp_info thi ON (tdgd.hosp_seq_id=thi.hosp_seq_id)
   JOIN tpa_hosp_address tha ON (thi.hosp_seq_id=tha.hosp_seq_id)
   LEFT OUTER JOIN tpa_office_info toi ON (thi.tpa_office_seq_id=toi.tpa_office_seq_id)
   JOIN pat_general_details pgd ON (tdgd.diag_gen_seq_id=pgd.diag_gen_seq_id AND pgd.pat_enhanced_yn='N')
   JOIN pat_enroll_details ped ON (pgd.pat_enroll_detail_seq_id=ped.pat_enroll_detail_seq_id)
   LEFT OUTER JOIN tpa_office_info tooi ON (ped.tpa_office_seq_id=tooi.tpa_office_seq_id)
   LEFT OUTER JOIN tpa_address ta ON (tooi.tpa_office_seq_id=ta.tpa_office_seq_id)
   LEFT OUTER JOIN tpa_city_code tcc ON (ta.city_type_id=tcc.city_type_id)
   LEFT OUTER JOIN amt_tab at ON (tdgd.diag_gen_seq_id=at.diag_gen_seq_id)
   WHERE tdgd.diag_gen_seq_id = v_diag_gen_seq_id;

END     gen_bill_report1;
--=================================================================================

PROCEDURE gen_bill_report(v_diag_gen_seq_id                  IN tpa_diagnosys_enroll_dtls.diag_gen_seq_id%TYPE,
                           v_result_set                       OUT SYS_REFCURSOR)

  IS

  BEGIN

  OPEN v_result_set FOR
  SELECT tded.diag_enroll_seq_id,
         tded.diag_test_seq_id,
         tded.diag_gen_seq_id,
         tded.entered_rate entered_rate,
         tded.agreed_rate agreed_rate,
         tded.discount_perc discount_perc,
         tded.discount_rate discount_rate,
         tdcd.test_name

   FROM  tpa_diagnosys_enroll_dtls tded
   JOIN tpa_diagnosys_center_dtls tdcd on (tded.diag_test_seq_id=tdcd.diag_test_seq_id)
  WHERE tded.diag_gen_seq_id=v_diag_gen_seq_id;

END  gen_bill_report;
--=================================================================================
PROCEDURE select_total_amt_details (v_diag_gen_seq_id                  IN tpa_diagnosys_enroll_dtls.diag_gen_seq_id%TYPE,
                                         vidal_result_set                       OUT SYS_REFCURSOR)
IS

BEGIN

OPEN vidal_result_set FOR
WITH amt_tab AS (SELECT SUM(nvl(entered_rate,0)) AS tot_entered_rate,
                        SUM(nvl(agreed_rate ,0)) AS tot_agreed_rate,
                        SUM(nvl(discount_perc ,0)) AS tot_discount_perc,
                        SUM(nvl(discount_rate ,0)) AS tot_discount_rate,
                        tded.diag_gen_seq_id
 FROM tpa_diagnosys_enroll_dtls tded
                 WHERE tded.diag_gen_seq_id =v_diag_gen_seq_id
                GROUP BY tded.diag_gen_seq_id )
 SELECT tdgd.member_seq_id,
        tdgd.hosp_seq_id,
        tepm.tpa_enrollment_id tpa_enrollment_id,
        TO_CHAR(NVL(tdgd.total_entered_rate,at.tot_entered_rate),'FM9999999999.009') as total_entered_rate,
        TO_CHAR(nvl(tdgd.total_agreed_rate,at.tot_agreed_rate),'FM9999999999.009') as total_agreed_rate,
        nvl(tdgd.total_discount_perc,at.tot_discount_perc) as total_discount_perc,
        at.tot_discount_rate as total_discount_rate,
        tdgd.rejected_amount as rejected_amount,
        tdgd.remarks as remarks,
        ped.pre_auth_number,
        ped.auth_number as auth_number,
        account_info_pkg.get_gen_desc(ped.pat_status_general_type_id,'G') AS preauth_status,
        DECODE(tepo.status,'VALIDATED','Y','N') AS OTP_STATUS

 FROM tpa_diagnosys_gen_dtls tdgd
 JOIN tpa_enr_policy_member tepm ON (tdgd.member_seq_id=tepm.member_seq_id)
 JOIN tpa_enr_pol_mem_otp_codes tepo ON (tdgd.diag_gen_seq_id=tepo.diag_gen_seq_id and tepo.active_yn='Y')
 LEFT OUTER JOIN pat_general_details pgd ON (tdgd.diag_gen_seq_id=pgd.diag_gen_seq_id AND pgd.pat_enhanced_yn='N')
 LEFT OUTER JOIN pat_enroll_details ped ON (pgd.pat_enroll_detail_seq_id=ped.pat_enroll_detail_seq_id)
 LEFT OUTER JOIN amt_tab at ON (tdgd.diag_gen_seq_id=at.diag_gen_seq_id)
 WHERE tdgd.diag_gen_seq_id = v_diag_gen_seq_id;


END  select_total_amt_details;
--=================================================================================

PROCEDURE submit_diagnosys_details (v_diag_gen_seq_id                  IN tpa_diagnosys_enroll_dtls.diag_gen_seq_id%TYPE,
                                    v_hosp_seq_id                      IN tpa_hosp_info.hosp_seq_id%TYPE,
                                    v_member_seq_id                    IN OUT tpa_enr_policy_member.member_seq_id%TYPE,
                                    v_tot_enter_amt                    IN pat_general_details.pat_requested_amount%TYPE,
                                    v_tot_agreed_amt                   IN pat_general_details.pat_requested_amount%TYPE,
                                    v_tot_discount_perc                IN tpa_diagnosys_gen_dtls.total_discount_rate%TYPE,
                                    v_total_app_amt                    IN OUT pat_general_details.total_app_amount%TYPE,
                                    v_added_by                         IN OUT NUMBER,
                                    v_pre_auth_number                  IN OUT pat_enroll_details.pre_auth_number%TYPE,
                                    v_error_msg                         OUT VARCHAR2,
                                    v_rows_processed                   OUT NUMBER)
IS

CURSOR pat_cur IS
  SELECT
        'REG' AS preauth_type,
        NULL AS pre_auth_number,
        SYSDATE AS pat_received_date,
        SYSDATE date_of_hospitalization ,
        0 AS prev_approved_amount ,
        v_tot_enter_amt AS pat_requested_amount ,
        NULL AS treating_dr_name ,
        'INP' AS  pat_status_general_type_id,
        'MID' AS pat_priority_general_type_id,
        'OLN' AS pat_rcvd_thru_general_type_id ,
        nvl(ttk_util_pkg.fn_decrypt(tema.mobile_no),ttk_util_pkg.fn_decrypt(tpma.mobile_no)) as phone_no_in_hospitalisation ,
        null as remarks,
        v_added_by as assign_users_seq_id,
        account_info_pkg.get_gen_desc(v_added_by,'G') AS  contact_name,
        1 tpa_office_seq_id,
        'BANGALORE' AS office_name,
        tepm.tpa_enrollment_id,
        tepm.mem_name claimant_name,
        tepm.gender_general_type_id ,
        tepm.mem_age ,
        tepm.date_of_inception ,
        tepm.date_of_exit ,
        tepm.mem_tot_sum_insured ,
        0  AS ava_sum_insured,
        0  AS buffer_ava_amount,
        0  AS ava_cum_bonus ,
        tepm.category_general_type_id ,
        J.description AS category ,
        tep.effective_from_date policy_effective_from ,
        tep.effective_to_date policy_effective_to ,
        tep.enrol_type_id ,
        tep.policy_number ,
        tep.policy_seq_id ,
        tep.product_seq_id ,
        tep.policy_sub_general_type_id ,
        tepg.insured_name,
        tep.ins_status_general_type_id ,
        tema.off_phone_no_1  AS phone,
        d.group_reg_seq_id ,
        D.group_name,
        D.group_id group_id ,
        e.ins_seq_id,
        E.ins_comp_name,
        E.ins_comp_code_number ,
        tepm.member_seq_id,
        null as parent_gen_detail_seq_id  ,
        'N' AS pat_enhanced_yn,
        NULL AS insur_ref_number,
        tepm.relship_type_id,
        tepg.employee_no,
        tepg.date_of_joining,
        tep.admin_auth_general_type_id,
        nvl(ttk_util_pkg.fn_decrypt(tema.email_id),ttk_util_pkg.fn_decrypt(tpma.email_id)) as email_id


        FROM tpa_enr_policy_member tepm
        JOIN tpa_enr_policy_group tepg on (tepm.policy_group_seq_id=tepg.policy_group_seq_id)
        JOIN tpa_enr_policy tep on (tepg.policy_seq_id=tep.policy_seq_id)
        LEFT OUTER JOIN tpa_enr_mem_address tema on (tepm.enr_address_seq_id=tema.enr_address_seq_id)
        LEFT OUTER JOIN tpa_enr_mem_address tpma on (tepg.enr_address_seq_id=tema.enr_address_seq_id)
        LEFT OUTER JOIN tpa_ins_info E ON (tep.ins_seq_id = E.ins_seq_id)
        LEFT OUTER JOIN tpa_group_registration D ON (tep.group_reg_seq_id = D.group_reg_seq_id )
        LEFT OUTER JOIN tpa_general_code J ON (tepm.category_general_type_id = J.general_type_id)
        WHERE tepm.member_seq_id = v_member_seq_id ;



        pat_rec                       pat_cur%ROWTYPE;

  v_pat_enroll_detail_seq_id    pat_enroll_details.pat_enroll_detail_seq_id%type:=0;
  v_pat_gen_detail_seq_id        pat_general_details.pat_gen_detail_seq_id%type;
  v_additional_dtl_seq_id        PAT_ADDITIONAL_DETAILS.additional_dtl_seq_id%TYPE;
  v_discrepancy_present_yn       PAT_GENERAL_DETAILS.discrepancy_present_yn%TYPE;
  v_completed_yn                 PAT_GENERAL_DETAILS.Completed_Yn%TYPE:='N';
  v_selection_type               VARCHAR2(10):='PAT' ;

  v_AILMENT_details_seq_id       AILMENT_DETAILS.AILMENT_details_seq_id%TYPE:=0;
  v_claim_seq_id                 AILMENT_DETAILS.claim_seq_id%TYPE;
  v_AILMENT_description          AILMENT_DETAILS.AILMENT_description%TYPE;
  v_specialty_general_type_id    AILMENT_DETAILS.specialty_general_type_id%TYPE := 'UNS';
  v_AILMENT_duration             AILMENT_DETAILS.AILMENT_duration%TYPE;
  v_pat_duration_general_type_id AILMENT_DETAILS.pat_duration_general_type_id%TYPE;
  v_clinical_findings            AILMENT_DETAILS.clinical_findings%TYPE;
  v_provisional_diagnosis        AILMENT_DETAILS.provisional_diagnosis%TYPE;
  v_related_to_prev_illness_yn   AILMENT_DETAILS.related_to_previous_illness_yn%TYPE;
  v_trtmnt_plan_general_type_id  AILMENT_DETAILS.trtmnt_plan_general_type_id%TYPE;
  v_investigation_reports        AILMENT_DETAILS.investigation_reports%TYPE;
  v_line_of_treatment            AILMENT_DETAILS.line_of_treatment%TYPE;
  v_duration_of_hospitalization  AILMENT_DETAILS.duration_of_hospitalization%TYPE;
  v_history                      AILMENT_DETAILS.history%TYPE;
  v_family_history               AILMENT_DETAILS.family_history%TYPE;
  v_date_of_surgery              AILMENT_DETAILS.date_of_surgery%TYPE;
  v_cond_general_type_id         AILMENT_DETAILS.discharge_cond_general_type_id%TYPE;
  v_advice_to_patient            AILMENT_DETAILS.advice_to_patient%TYPE;
  v_doctor_opinion               AILMENT_DETAILS.doctor_opinion%TYPE;
  v_disability_general_type_id   AILMENT_DETAILS.disability_general_type_id%TYPE;
  v_medicine_general_type_id     AILMENT_DETAILS.medicine_general_type_id %TYPE := 'SAL';
  v_ailment_clm_general_type_id  AILMENT_DETAILS.AILMENT_clm_general_type_id %TYPE := 'CLN';
  v_surgery_general_type_id      AILMENT_DETAILS.Surgery_General_Type_Id %TYPE;
  v_mat_general_type_id          AILMENT_DETAILS.mat_general_type_id%TYPE;
  v_children_during_mat          AILMENT_DETAILS.children_during_mat%TYPE;

  v_event_seq_id         PAT_GENERAL_DETAILS.event_seq_id%TYPE;
  v_review_count          PAT_GENERAL_DETAILS.review_count%TYPE;
  v_required_review_count PAT_GENERAL_DETAILS.required_review_count%TYPE;
  v_mode                  CHAR(5) := 'PAT'; -- Put it to 'PAT'
  v_type                  CHAR(10); -- Dummy
  v_event_name            TPA_EVENT.EVENT_NAME%TYPE;
  v_review                VARCHAR2(25);
  v_coding_review_yn      CHAR(5);
  v_show_coding_override  CHAR(5);

  --ICD / PCS DETAILS
  v_icd_pcs_seq_id           ICD_PCS_DETAIL.icd_pcs_seq_id%TYPE;
  v_seq_id                   ICD_PCS_DETAIL.pat_gen_detail_seq_id%TYPE; -- pat_general_detail_seq_id or Claim_seq_id
  v_ped_code_id              ICD_PCS_DETAIL.ped_code_id%TYPE;
  v_other_desc               ICD_PCS_DETAIL.other_desc%TYPE;
  v_icd_code                 ICD_PCS_DETAIL.icd_code%TYPE;
  v_primary_ailment_yn       ICD_PCS_DETAIL.primary_ailment_yn%TYPE ;
  v_hospital_general_type_id ICD_PCS_DETAIL.hospital_general_type_id%TYPE := 'REL';
  v_frequency_of_visit       ICD_PCS_DETAIL.frequency_of_visit%TYPE;
  v_no_of_visits             ICD_PCS_DETAIL.no_of_visits%TYPE;
  v_tariff_general_type_id   ICD_PCS_DETAIL.tariff_general_type_id%TYPE;
  v_pkg_seq_id               PAT_PACKAGE_PROCEDURES.PKG_SEQ_ID%TYPE;
  v_proc_seq_ids             VARCHAR2(15);
  v_proc_delete_seq_ids      VARCHAR2(15);
  v_scr_mode                 VARCHAR2(3) := 'PAT'; -- PAT -> preauth -- CLM -> Claims
  v_proc_code                tpa_day_care_procedure.proc_code%type;

  --FOR AUTHORIZATION
  v_approved_amount        ailment_caps.approved_amount%type;
  V_ailment_caps_seq_id    AILMENT_CAPS.AILMENT_CAPS_SEQ_ID%TYPE;
  v_auth_number            PAT_ENROLL_DETAILS.auth_number%TYPE;
  v_rson_general_type_id   ASSIGN_USERS.rson_general_type_id%TYPE := 'ARS';
  v_assign_users_seq_id    ASSIGN_USERS.assign_users_seq_id%TYPE;
  v_permission_sought_from PAT_GENERAL_DETAILS.permission_sought_from%TYPE;
  v_balance_seq_id         tpa_enr_balance.balance_seq_id%TYPE;
  v_max_app_amount         NUMBER;
  v_discount_amount        pat_general_details.discount_amount%TYPE;
  v_co_payment_amount      pat_general_details.co_payment_amount%TYPE;
  v_pat_status_general_type_id pat_enroll_details.pat_status_general_type_id%type:='APR';
  v_diagnosys_seq_id                   tpa_diagnosys_details.diagnosys_seq_id%TYPE;
  v_co_pay_buff_amount               pat_general_details.co_payment_buffer_amount%TYPE; --KOCIBM
  v_pd                                 pat_general_details.policy_deductable_amt%TYPE; --koc1277

CURSOR get_bal_cur IS
SELECT  teb.sum_insured ,teb.balance_seq_id,
teb.utilised_sum_insured,tepg.policy_group_seq_id,
teb.sum_insured-nvl(teb.utilised_sum_insured,0) as balance_amt
  FROM tpa_enr_policy_member tepm
JOIN tpa_enr_policy_group tepg on (tepm.policy_group_seq_id=tepg.policy_group_seq_id)
JOIN tpa_enr_balance teb ON (CASE WHEN teb.member_seq_id IS NULL  THEN tepm.policy_group_seq_id END = teb.policy_group_seq_id OR CASE WHEN  teb.member_seq_id IS NOT NULL THEN tepm.Member_Seq_Id END = teb.Member_Seq_Id )
WHERE tepm.member_seq_id= v_member_seq_id;

get_bal_rec              get_bal_cur%ROWTYPE;

CURSOR get_preauth_cur IS
SELECT ped.pat_enroll_detail_seq_id,
       pgd.pat_gen_detail_seq_id,
       pgd.event_seq_id,
       ad.ailment_details_seq_id,
       ped.pat_status_general_type_id,
       ped.pre_auth_number,
       ipd.icd_pcs_seq_id,
       ac.ailment_caps_seq_id

FROM pat_enroll_details ped
JOIN pat_general_details pgd ON (ped.pat_enroll_detail_seq_id=pgd.pat_enroll_detail_seq_id AND pgd.pat_enhanced_yn='N')
LEFT OUTER JOIN ailment_details ad ON (pgd.pat_gen_detail_seq_id=ad.pat_gen_detail_seq_id)
LEFT OUTER JOIN icd_pcs_detail ipd ON (pgd.pat_gen_detail_seq_id=ipd.pat_gen_detail_seq_id)
LEFT OUTER JOIN ailment_caps ac on (ipd.icd_pcs_seq_id=ac.icd_pcs_seq_id)
WHERE pgd.diag_gen_seq_id=v_diag_gen_seq_id;


CURSOR get_auth_cur(v_pat_gen_detail_seq_id pat_general_details.pat_gen_detail_seq_id%type) IS
SELECT ped.pre_auth_number,ped.auth_number
FROM pat_enroll_details ped
JOIN pat_general_details pgd ON (ped.pat_enroll_detail_seq_id=pgd.pat_enroll_detail_seq_id AND pgd.pat_enhanced_yn='N')
WHERE pgd.pat_gen_detail_seq_id=v_pat_gen_detail_seq_id;

preauth_rec                  get_preauth_cur%ROWTYPE;
auth_rec                     get_auth_cur%ROWTYPE;
v_event_count                number(2):=0;
v_rejected_amt               tpa_diagnosys_gen_dtls.rejected_amount%type;



BEGIN

  OPEN get_bal_cur;
  FETCH get_bal_cur INTO get_bal_rec;
  CLOSE get_bal_cur;

  IF NVL(get_bal_rec.Balance_Amt,0)=0 THEN
    v_pat_status_general_type_id:='REJ';
  END IF;

v_rejected_amt:=  case when NVL(get_bal_rec.Balance_Amt,0)>v_total_app_amt THEN 0 ELSE v_total_app_amt-NVL(get_bal_rec.Balance_Amt,0)  END;
v_total_app_amt:=case when NVL(get_bal_rec.Balance_Amt,0)>v_total_app_amt THEN  v_total_app_amt ELSE NVL(get_bal_rec.Balance_Amt,0) END;

select toi.tpa_office_seq_id into pat_rec.tpa_office_seq_id from app.tpa_hosp_info toi where toi.hosp_seq_id= v_hosp_seq_id;

 UPDATE tpa_diagnosys_gen_dtls tdgd
        SET tdgd.total_entered_rate = v_tot_enter_amt,
            tdgd.total_agreed_rate = v_tot_agreed_amt,
            tdgd.total_discount_perc = v_tot_discount_perc ,
            tdgd.total_discount_rate = v_total_app_amt,
            tdgd.rejected_amount = NVL(v_rejected_amt,0),
            tdgd.remarks = CASE WHEN v_rejected_amt>0 THEN 'Rs. '||v_rejected_amt||' got Rejected because Sufficient Balance does not Exists!' WHEN v_pat_status_general_type_id ='REJ' THEN 'Balance does not Exists!, Pre-Authorization request has been Rejected' else 'Approved amount = Agreed Tariff amount, Requested amount which ever is lesser' end
 WHERE tdgd.diag_gen_seq_id = v_diag_gen_seq_id
 RETURN total_discount_rate INTO v_total_app_amt;

  OPEN  get_preauth_cur;
  FETCH get_preauth_cur INTO preauth_rec;
  CLOSE get_preauth_cur;

  v_pre_auth_number:=preauth_rec.Pre_Auth_Number;
  v_pat_gen_detail_seq_id := NVL(v_pat_gen_detail_seq_id,preauth_rec.Pat_Gen_Detail_Seq_Id);
  v_pat_enroll_detail_seq_id:=NVL(v_pat_enroll_detail_seq_id,preauth_rec.pat_enroll_detail_seq_id);
  v_balance_seq_id:=get_bal_rec.balance_seq_id;
  v_added_by:=287479;

 OPEN   pat_cur;
 FETCH  pat_cur INTO pat_rec;
 CLOSE  pat_cur;

 IF preauth_rec.Pat_Gen_Detail_Seq_Id Is null then
 self_fund_pre_auth_pkg.save_preauth(
            v_pat_enroll_detail_seq_id,
            v_member_seq_id,
            pat_rec.tpa_enrollment_id,
            pat_rec.policy_number,
            pat_rec.policy_seq_id,
            pat_rec.ins_seq_id,
            pat_rec.gender_general_type_id,
            pat_rec.claimant_name,
            pat_rec.mem_age,
            pat_rec.date_of_inception,
            pat_rec.date_of_exit,
            pat_rec.mem_tot_sum_insured,
            pat_rec.category_general_type_id,
            pat_rec.insured_name,
            pat_rec.phone,
            pat_rec.policy_effective_from,
            pat_rec.policy_effective_to,
            pat_rec.product_seq_id,
            pat_rec.ins_status_general_type_id,
            pat_rec.enrol_type_id,
            pat_rec.policy_sub_general_type_id,
            pat_rec.group_reg_seq_id,
            sysdate,
            pat_rec.tpa_office_seq_id,
            v_hosp_seq_id,
            pat_rec.pat_status_general_type_id,
            v_pat_gen_detail_seq_id,
            'REG',
            pat_rec.pat_priority_general_type_id,
            pat_rec.pat_received_date,
            pat_rec.prev_approved_amount,
            pat_rec.pat_requested_amount,
            pat_rec.treating_dr_name,
            pat_rec.pat_rcvd_thru_general_type_id,
            pat_rec.phone_no_in_hospitalisation,
            v_discrepancy_present_yn,
            pat_rec.parent_gen_detail_seq_id,
            pat_rec.remarks,
            pat_rec.ava_sum_insured,
            pat_rec.ava_cum_bonus,
            v_additional_dtl_seq_id,
            pat_rec.relship_type_id,
            pat_rec.employee_no,
            pat_rec.insured_name,
            pat_rec.date_of_joining,
            sysdate,
            null,
            null,
            null,
            pat_rec.contact_name,
            null,
            null,
            null,
            'N',
            pat_rec.admin_auth_general_type_id,
            v_completed_yn,
            pat_rec.pre_auth_number,
            pat_rec.email_id,
            null,
            null,
            null,
            v_selection_type,
            NULL,
            v_added_by,
            v_rows_processed );

    UPDATE pat_general_details a
    SET a.diag_gen_seq_id=v_diag_gen_seq_id
    WHERE a.pat_gen_detail_seq_id=v_pat_gen_detail_seq_id;

 END IF;

 v_pre_auth_number:= pat_rec.pre_auth_number;

 IF v_pre_auth_number IS NULL THEN
     OPEN get_auth_cur(v_pat_gen_detail_seq_id);
     FETCH get_auth_cur INTO auth_rec;
     CLOSE get_auth_cur;
     v_pre_auth_number:=auth_rec.pre_auth_number;
 END IF;

 IF preauth_rec.Ailment_Details_Seq_Id IS NULL THEN

 self_fund_pre_auth_pkg.save_ailment_details(
          v_ailment_details_seq_id,
          v_pat_gen_detail_seq_id,
          v_claim_seq_id,
          v_ailment_description,
          v_specialty_general_type_id,
          v_ailment_duration,
          v_pat_duration_general_type_id,
          v_clinical_findings,
          v_provisional_diagnosis,
          v_related_to_prev_illness_yn,
          v_trtmnt_plan_general_type_id,
          v_investigation_reports,
          v_line_of_treatment,
          v_duration_of_hospitalization,
          v_history,
          v_family_history,
          v_date_of_surgery,
          v_cond_general_type_id,
          v_advice_to_patient,
          v_doctor_opinion,
          v_added_by,
          v_disability_general_type_id,
          v_medicine_general_type_id,
          v_ailment_clm_general_type_id,
          v_surgery_general_type_id,
          v_mat_general_type_id,
          v_children_during_mat,
          NULL,
          NULL,
          NULL,
          0,
          0,
          0,
          'N',
          NULL,
          SYSDATE,
          SYSDATE,
          v_rows_processed,
          'N',
          NULL,
          0,
          NULL);
 END IF;

 IF preauth_rec.Event_Seq_Id=9 OR preauth_rec.Event_Seq_Id IS NULL THEN
   v_event_count:=2;
 ELSIF preauth_rec.Event_Seq_Id=10 THEN
   v_event_count:=1;
 END IF;

  v_event_seq_id:=NVL(v_event_seq_id,preauth_rec.Event_Seq_Id);

  FOR I IN 1 .. v_event_count LOOP

                self_fund_pre_auth_pkg.set_review(v_pat_gen_detail_seq_id,
                                            v_event_seq_id,
                                            v_review_count,
                                            v_required_review_count,
                                            'PAT',
                                            NULL,
                                            V_ADDED_BY,
                                            v_event_name,
                                            v_review,
                                            v_coding_review_yn,
                                            v_show_coding_override);

  END LOOP;

   v_trtmnt_plan_general_type_id := 'MDC';

  IF preauth_rec.Icd_Pcs_Seq_Id IS NULL THEN
     v_icd_pcs_seq_id              := 0;
            self_fund_pre_auth_pkg.save_icd_pcs_detail_update(v_icd_pcs_seq_id,
                                                 v_pat_gen_detail_seq_id,
                                                 34333,
                                                 NULL,
                                                 'DUMMY',
                                                 v_primary_ailment_yn,
                                                 v_hospital_general_type_id,
                                                 v_trtmnt_plan_general_type_id,
                                                 v_frequency_of_visit,
                                                 v_pat_duration_general_type_id,
                                                 v_no_of_visits,
                                                 v_tariff_general_type_id,
                                                 v_pkg_seq_id,
                                                 v_proc_seq_ids,
                                                 v_proc_delete_seq_ids,
                                                 v_scr_mode,
                                                 v_added_by,
                                                 v_diagnosys_seq_id,
                                                 NULL,
                                                 NULL,
                                                 v_rows_processed
                                                 );


  END IF;

   v_icd_pcs_seq_id:=NVL(v_icd_pcs_seq_id,preauth_rec.Icd_Pcs_Seq_Id);

   UPDATE icd_pcs_detail ipd
   SET ipd.primary_ailment_yn='Y'
   WHERE ipd.icd_pcs_seq_id=   v_icd_pcs_seq_id;

 v_event_count:=0;

 IF preauth_rec.Event_Seq_Id=11 OR preauth_rec.Event_Seq_Id IS NULL THEN
   v_event_count:=2;
 ELSIF preauth_rec.Event_Seq_Id=12 THEN
   v_event_count:=1;
 END IF;

 v_event_seq_id:=NVL(v_event_seq_id,preauth_rec.Event_Seq_Id);

            FOR I IN 1 .. v_event_count LOOP

              self_fund_pre_auth_pkg.set_review(v_pat_gen_detail_seq_id,
                                          v_event_seq_id,
                                          v_review_count,
                                          v_required_review_count,
                                          'PAT',
                                          NULL,
                                          V_ADDED_BY,
                                          v_event_name,
                                          v_review,
                                          v_coding_review_yn,
                                          v_show_coding_override);

            END LOOP;
              --FOR PRE AUTH APPROVED AMOUNT
   IF  preauth_rec.Ailment_Caps_Seq_Id IS NULL THEN
      INSERT INTO ailment_caps
              (ailment_caps_seq_id,
               icd_pcs_seq_id,
               maximum_allowed_amount,
               approved_amount,
               notes,
               added_by,
               added_date)
            VALUES
              (ailment_caps_seq.NEXTVAL,
               v_icd_pcs_seq_id,
               NULL,
               v_total_app_amt,
               NULL,
               v_added_by,
               SYSDATE);

      update discrepancy_information u
      set u.resolved_yn = 'Y'
      where u.pat_gen_detail_seq_id = v_pat_gen_detail_seq_id;
      commit;
  END IF;

IF preauth_rec.Pat_Status_General_Type_Id='INP' OR preauth_rec.Pat_Gen_Detail_Seq_Id IS NULL THEN

self_fund_pre_auth_pkg.save_authorization(
      v_pat_gen_detail_seq_id  ,
      v_pat_enroll_detail_seq_id  ,
      v_auth_number  ,
      pat_rec.mem_tot_sum_insured  ,
      v_pat_status_general_type_id  ,
      v_rson_general_type_id  ,
      null  ,
      v_assign_users_seq_id  ,
      v_permission_sought_from  ,
      v_balance_seq_id  ,
      v_max_app_amount  ,
      v_discount_amount  ,
      v_co_payment_amount  ,
      v_co_pay_buff_amount  ,
      v_added_by  ,
      0  ,
      0  ,
      'N'  ,
      v_pd  ,
      NULL  ,
      v_rows_processed  );

 v_event_seq_id:=NVL(v_event_seq_id,preauth_rec.Event_Seq_Id);

self_fund_pre_auth_pkg.set_review(v_pat_gen_detail_seq_id,
                                        v_event_seq_id,
                                        v_review_count,
                                        v_required_review_count,
                                        'PAT',
                                        NULL,
                                        V_ADDED_BY,
                                        v_event_name,
                                        v_review,
                                        v_coding_review_yn,
                                        v_show_coding_override);

    UPDATE tpa_diagnosys_gen_dtls  tdgd
       SET tdgd.intimated_yn='Y',
       tdgd.int_status_type_id='INT'
       WHERE tdgd.diag_gen_seq_id=v_diag_gen_seq_id;
END IF;

COMMIT;

END  submit_diagnosys_details;
--=================================================================================
PROCEDURE save_hosp_mem_vital_dtls(V_mem_vital_seq_id IN OUT TPA_HOSP_MEM_VITAL_DETAILS.MEM_VITAL_SEQ_ID%type,
                                   v_member_id        IN TPA_HOSP_MEM_VITAL_DETAILS.VIDAL_ID%TYPE,
                                   v_bp_systolic      IN TPA_HOSP_MEM_VITAL_DETAILS.BP_SYSTOLIC%TYPE,
                                   v_bp_diastolic     IN TPA_HOSP_MEM_VITAL_DETAILS.BP_DIASTOLIC%TYPE,
                                   v_temperature      IN TPA_HOSP_MEM_VITAL_DETAILS.TEMPERATURE%TYPE,
                                   v_pulse            IN TPA_HOSP_MEM_VITAL_DETAILS.PULSE%TYPE,
                                   v_respiration      IN TPA_HOSP_MEM_VITAL_DETAILS.RESPIRATION%TYPE,
                                   v_height           IN TPA_HOSP_MEM_VITAL_DETAILS.HEIGHT%TYPE,
                                   v_weight           IN TPA_HOSP_MEM_VITAL_DETAILS.WEIGHT%TYPE,
                                   v_added_by         IN TPA_HOSP_MEM_VITAL_DETAILS.ADDED_BY%TYPE,
                                   v_rows_processed   OUT NUMBER) IS

BEGIN

  IF NVL(V_mem_vital_seq_id, 0) = 0 THEN
    INSERT INTO TPA_HOSP_MEM_VITAL_DETAILS
      (MEM_VITAL_SEQ_ID,
       VIDAL_ID,
       BP_SYSTOLIC,
       BP_DIASTOLIC,
       TEMPERATURE,
       PULSE,
       RESPIRATION,
       HEIGHT,
       WEIGHT,
       ADDED_BY,
       ADDED_DATE)
    VALUES
      (TPA_HOSP_MEM_VITAL_DETAILS_SEQ.NEXTVAL,
       v_member_id,
       v_bp_systolic,
       v_bp_diastolic,
       v_temperature,
       v_pulse,
       v_respiration,
       v_height,
       v_weight,
       v_added_by,
       SYSDATE);
  
  ELSE
  
    UPDATE TPA_HOSP_MEM_VITAL_DETAILS VD
       SET vd.bp_systolic  = v_bp_systolic,
           vd.bp_diastolic = v_bp_diastolic,
           vd.temperature  = v_temperature,
           vd.pulse        = v_pulse,
           vd.respiration  = v_respiration,
           vd.height       = v_height,
           vd.weight       = v_weight,
           vd.updated_by   = v_added_by,
           vd.updated_date = SYSDATE
     WHERE vd.mem_vital_seq_id = V_mem_vital_seq_id;
  
  END IF;

  v_rows_processed := SQL%ROWCOUNT;
  COMMIT;
END save_hosp_mem_vital_dtls;
---===========================================
PROCEDURE save_hosp_cashless(V_INTIMATE_SEQ_ID          IN OUT PAT_HOSP_INTIMATION_DETAILS.INTIMATE_SEQ_ID%Type,
                             V_HOSP_SEQ_ID              IN PAT_HOSP_INTIMATION_DETAILS.HOSP_SEQ_ID%Type,
                             V_MEMBER_SEQ_ID            IN PAT_HOSP_INTIMATION_DETAILS.MEMBER_SEQ_ID%Type,
                             V_CARD_HOLDER              IN PAT_HOSP_INTIMATION_DETAILS.CARD_HOLDER%Type,
                             V_INS_SEQ_ID               IN PAT_HOSP_INTIMATION_DETAILS.INS_SEQ_ID%Type,
                             V_TREATEMENT_DATE          IN PAT_HOSP_INTIMATION_DETAILS.TREATEMENT_DATE%Type,
                             V_INTIMATION_NUMBER        OUT PAT_HOSP_INTIMATION_DETAILS.INTIMATION_NUMBER%Type,
                             V_MEDICAL_RECORD_NO        IN PAT_HOSP_INTIMATION_DETAILS.MEDICAL_RECORD_NO%Type,
                             V_EMERGENCY_YN             IN PAT_HOSP_INTIMATION_DETAILS.EMERGENCY_YN%Type,
                             V_TREATING_PHYSICIAN       IN PAT_HOSP_INTIMATION_DETAILS.TREATING_PHYSICIAN%Type,
                             V_PHYSICIAN_ID             IN PAT_HOSP_INTIMATION_DETAILS.PHYSICIAN_ID%Type,
                             V_PHY_SPECIALITY_TYPE      IN PAT_HOSP_INTIMATION_DETAILS.PHY_SPECIALITY_TYPE%Type,
                             V_AILMENT_DESCRIPTION      IN PAT_HOSP_INTIMATION_DETAILS.AILMENT_DESCRIPTION%Type,
                             V_MEDICINE_GENERAL_TYPE_ID IN PAT_HOSP_INTIMATION_DETAILS.MEDICINE_GENERAL_TYPE_ID%Type,
                             V_ACCIDENT_REL_GEN_TYPE_ID IN PAT_HOSP_INTIMATION_DETAILS.ACCIDENT_REL_GEN_TYPE_ID%Type,
                             V_AILMENT_DURATION         IN PAT_HOSP_INTIMATION_DETAILS.AILMENT_DURATION%Type,
                             V_DURATION_GEN_TYPE_ID     IN PAT_HOSP_INTIMATION_DETAILS.DURATION_GEN_TYPE_ID%Type,
                             V_MEDICAL_FINDINGS         IN PAT_HOSP_INTIMATION_DETAILS.MEDICAL_FINDINGS%Type,
                             V_REQUESTED_AMOUNT         IN PAT_HOSP_INTIMATION_DETAILS.REQUESTED_AMOUNT%Type,
                             V_TREATMENT_GEN_TYPE_ID    IN PAT_HOSP_INTIMATION_DETAILS.TREATMENT_GEN_TYPE_ID%Type,
                             V_PREVIOUS_ILLNESS_YN      IN PAT_HOSP_INTIMATION_DETAILS.PREVIOUS_ILLNESS_YN%Type,
                             V_TREATMENT_DETAILS        IN PAT_HOSP_INTIMATION_DETAILS.TREATMENT_DETAILS%Type,
                             V_MEDICAL_REVIEW_YN        IN PAT_HOSP_INTIMATION_DETAILS.MEDICAL_REVIEW_YN%Type,
                             V_ADDED_BY                 IN PAT_HOSP_INTIMATION_DETAILS.ADDED_BY%Type,
                             V_rows_processed           OUT NUMBER) IS

  V_ins_code tpa_ins_info.ins_comp_code_number%type;

BEGIN
  IF V_INS_SEQ_ID IS NOT NULL THEN
    SELECT I.INS_COMP_CODE_NUMBER
      INTO V_ins_code
      FROM TPA_INS_INFO I
     WHERE I.INS_SEQ_ID = V_INS_SEQ_ID;
  END IF;
  IF NVL(V_INTIMATE_SEQ_ID, 0) = 0 THEN
    INSERT INTO PAT_HOSP_INTIMATION_DETAILS
      (INTIMATE_SEQ_ID,
       HOSP_SEQ_ID,
       MEMBER_SEQ_ID,
       CARD_HOLDER,
       INS_SEQ_ID,
       TREATEMENT_DATE,
       INTIMATION_NUMBER,
       MEDICAL_RECORD_NO,
       EMERGENCY_YN,
       TREATING_PHYSICIAN,
       PHYSICIAN_ID,
       PHY_SPECIALITY_TYPE,
       AILMENT_DESCRIPTION,
       MEDICINE_GENERAL_TYPE_ID,
       ACCIDENT_REL_GEN_TYPE_ID,
       AILMENT_DURATION,
       DURATION_GEN_TYPE_ID,
       MEDICAL_FINDINGS,
       REQUESTED_AMOUNT,
       TREATMENT_GEN_TYPE_ID,
       PREVIOUS_ILLNESS_YN,
       TREATMENT_DETAILS,
       MEDICAL_REVIEW_YN,
       ADDED_BY,
       ADDED_DATE)
    VALUES
      (PAT_HOSP_INTIMATION_DTLS_SEQ.NEXTVAL,
       V_HOSP_SEQ_ID,
       V_MEMBER_SEQ_ID,
       V_CARD_HOLDER,
       V_INS_SEQ_ID,
       V_TREATEMENT_DATE,
       'PAT-' || V_ins_code || '-' || PAT_HOSP_INTIMATION_DTLS_SEQ.CURRVAL,
       V_MEDICAL_RECORD_NO,
       V_EMERGENCY_YN,
       V_TREATING_PHYSICIAN,
       V_PHYSICIAN_ID,
       V_PHY_SPECIALITY_TYPE,
       V_AILMENT_DESCRIPTION,
       V_MEDICINE_GENERAL_TYPE_ID,
       V_ACCIDENT_REL_GEN_TYPE_ID,
       V_AILMENT_DURATION,
       V_DURATION_GEN_TYPE_ID,
       V_MEDICAL_FINDINGS,
       V_REQUESTED_AMOUNT,
       V_TREATMENT_GEN_TYPE_ID,
       V_PREVIOUS_ILLNESS_YN,
       V_TREATMENT_DETAILS,
       V_MEDICAL_REVIEW_YN,
       V_ADDED_BY,
       SYSDATE);
  ELSE
  
    UPDATE PAT_HOSP_INTIMATION_DETAILS
       SET TREATEMENT_DATE          = V_TREATEMENT_DATE,
           MEDICAL_RECORD_NO        = V_MEDICAL_RECORD_NO,
           EMERGENCY_YN             = V_EMERGENCY_YN,
           TREATING_PHYSICIAN       = V_TREATING_PHYSICIAN,
           PHYSICIAN_ID             = V_PHYSICIAN_ID,
           PHY_SPECIALITY_TYPE      = V_PHY_SPECIALITY_TYPE,
           AILMENT_DESCRIPTION      = V_AILMENT_DESCRIPTION,
           MEDICINE_GENERAL_TYPE_ID = V_MEDICINE_GENERAL_TYPE_ID,
           ACCIDENT_REL_GEN_TYPE_ID = V_ACCIDENT_REL_GEN_TYPE_ID,
           AILMENT_DURATION         = V_AILMENT_DURATION,
           DURATION_GEN_TYPE_ID     = V_AILMENT_DURATION,
           MEDICAL_FINDINGS         = V_MEDICAL_FINDINGS,
           REQUESTED_AMOUNT         = V_REQUESTED_AMOUNT,
           TREATMENT_GEN_TYPE_ID    = V_TREATMENT_GEN_TYPE_ID,
           PREVIOUS_ILLNESS_YN      = V_PREVIOUS_ILLNESS_YN,
           TREATMENT_DETAILS        = V_TREATMENT_DETAILS,
           MEDICAL_REVIEW_YN        = V_MEDICAL_REVIEW_YN,
           UPDATED_BY               = V_ADDED_BY,
           UPDATED_DATE             = SYSDATE
     WHERE INTIMATE_SEQ_ID = V_INTIMATE_SEQ_ID;
  END IF;

  V_rows_processed := SQL%ROWCOUNT;
  COMMIT;
END save_hosp_cashless;
---===========================================
PROCEDURE get_mem_benifit_details(v_tpa_enrollment_id                  IN  PAT_ENROLL_DETAILS.tpa_enrollment_id%TYPE,
                                  v_benefit_type                       IN  PAT_AUTHORIZATION_DETAILS.Benifit_Type%TYPE,                                     
                                  v_hosp_seq_id                        IN  TPA_HOSP_INFO.HOSP_SEQ_ID%TYPE,
                                  v_result_set                         OUT SYS_REFCURSOR,
                                  v_network_check                      OUT SYS_REFCURSOR)
IS 
benefit_type           varchar2(30);
--v_enroll_type          varchar2(30);
v_provider_network     varchar2(30);

CURSOR enroll_type_cur IS
  select tep.enrol_type_id,tep.policy_seq_id, count(tep.enrol_type_id) as cnt,tem.member_seq_id
  from app.tpa_enr_policy tep
  join app.tpa_enr_policy_group teg on (tep.policy_seq_id = teg.policy_seq_id) 
  join app.tpa_enr_policy_member tem on(teg.policy_group_seq_id = tem.policy_group_seq_id)
 where  (tem.tpa_enrollment_id=v_tpa_enrollment_id or tem.emirate_id=v_tpa_enrollment_id)
  and sysdate between tep.effective_from_date and tep.effective_to_date+1
 group by tep.enrol_type_id,tep.policy_seq_id,tem.member_seq_id;
 
CURSOR Eligible_benifits IS
 select wm_concat(a.benifit_type) 
 from 
 (select distinct hc.benifit_type as benifit_type
  from app.tpa_enr_policy tep
  join app.tpa_enr_policy_group teg
    on (tep.policy_seq_id = teg.policy_seq_id) 
  join app.tpa_enr_policy_member tem
 on(teg.policy_group_seq_id = tem.policy_group_seq_id)
 join app.tpa_ins_prod_hosp_copay hc on (hc.policy_seq_id=tep.policy_seq_id)
 join app.tpa_ins_assoc_prod_hosp ph on (hc.prod_policy_seq_id=ph.prod_policy_seq_id 
                                            and ph.status_general_type_id='ASL' and ph.hosp_seq_id=v_hosp_seq_id)
 where ( tem.tpa_enrollment_id=v_tpa_enrollment_id) and sysdate between tep.effective_from_date and tep.effective_to_date and hc.hosp_seq_id=v_hosp_seq_id or tem.emirate_id=v_tpa_enrollment_id) a;
                                        
 
v_enroll_type enroll_type_cur%ROWTYPE;
v_hosp_ben    VARCHAR2(32000);
v_policy_seq_id   NUMBER(10);
v_policy_number   VARCHAR2(100);
v_elg_cnt       NUMBER(10);
v_benefit_limit NUMBER(10);


CURSOR PREVIOUS_POLICY_NUMBER(v_policy_seq_id number) IS
    SELECT ENR.POLICY_NUMBER 
    FROM tpa_enr_policy enr
    WHERE ENR.PREV_POLICY_SEQ_ID is null
    START WITH ENR.POLICY_SEQ_ID=v_policy_seq_id
    CONNECT BY enr.POLICY_SEQ_ID = PRIOR PREV_POLICY_SEQ_ID;
    
CURSOR Curr_Policy_seq_id IS
  select tep.policy_seq_id
  from app.tpa_enr_policy tep
  join app.tpa_enr_policy_group teg on (tep.policy_seq_id = teg.policy_seq_id) 
  join app.tpa_enr_policy_member tem on(teg.policy_group_seq_id = tem.policy_group_seq_id)
  where  tem.tpa_enrollment_id=v_tpa_enrollment_id and sysdate between tep.effective_from_date and tep.effective_to_date+1;
                                             
CURSOR CR_BENEFIT_YA (cv_policy_seq_id IN app.tpa_enr_policy.policy_seq_id%TYPE)
IS
SELECT COUNT(1) AS CNT
FROM app.tpa_enr_policy tep
      INNER JOIN app.tpa_ins_prod_hosp_copay hc on (hc.policy_seq_id=tep.policy_seq_id)
      INNER JOIN app.tpa_ins_assoc_prod_hosp ph on (hc.prod_policy_seq_id=ph.prod_policy_seq_id
                                            and ph.status_general_type_id='ASL' and ph.hosp_seq_id=v_hosp_seq_id)
WHERE tep.policy_seq_id=v_policy_seq_id AND hc.benifit_type IS NOT NULL;
LV_CR_BENEFIT_YA CR_BENEFIT_YA%ROWTYPE;

--------------getting_limits
CURSOR Optical_limit_cur(v_cur_policy_seq number) IS
       SELECT SUM(nvl(s.used_amount, r.used_amount)) FROM
         ( SELECT b.approved_amount AS used_amount , b.Pat_Auth_Seq_Id, a.claim_seq_id -----PROD FIXING
               FROM pat_authorization_details a
               left outer join app.clm_authorization_details x on (a.pat_auth_seq_id = x.pat_auth_seq_id)-----PROD FIXING
               JOIN pat_activity_details b ON (a.pat_auth_seq_id = b.pat_auth_seq_id AND A.pat_status_type_id != 'PCN' AND A.pat_status_type_id != 'REJ' )
               JOIN tpa_activity_details G ON (b.code = g.activity_code)
               --JOIN tpa_activity_details gg ON (g.master_activity_code = gg.master_activity_code )
               WHERE A.Tpa_Enrollment_Id = v_tpa_enrollment_id 
               AND NVL(A.Pat_Enhanced_Yn,'N') = 'N'   ----NEWLY ADDED FOR PAT_ENHANCE 
               --AND gg.activity_code = 'V2020'
               and a.policy_seq_id=v_cur_policy_seq
               AND ((a.benifit_type='OPTC' AND g.master_activity_code='9')OR g.master_activity_code IN ('V2020','92015')) AND nvl(b.optc_payable,'EXC')='INC'
               AND (a.claim_seq_id IS NULL OR (a.claim_seq_id IS NOT NULL AND x.clm_status_type_id IN ('INP', 'REQ') 
               ))
               --AND a.hospitalization_date >= v_start_date AND A.Discharge_Date <= v_end_date 
               ) r
          FULL OUTER JOIN
           ( SELECT b.approved_amount AS used_amount , a.claim_seq_id  -----PROD FIXING 
               FROM clm_authorization_details A 
               JOIN pat_activity_details b ON (a.claim_seq_id = b.claim_seq_id AND A.CLM_STATUS_TYPE_ID != 'PCN' AND A.CLM_STATUS_TYPE_ID != 'REJ' )-----***
               JOIN tpa_activity_details G ON (b.code = g.activity_code)
               --JOIN tpa_activity_details gg ON (g.master_activity_code = gg.master_activity_code )
               WHERE A.Tpa_Enrollment_Id = v_tpa_enrollment_id 
               --AND gg.activity_code = 'V2020'
               and a.policy_seq_id = v_cur_policy_seq
               AND ((a.benifit_type='OPTC' AND g.master_activity_code='9')OR g.master_activity_code IN ('V2020','92015')) AND nvl(b.optc_payable,'EXC')='INC'
               AND (A.PAT_AUTH_SEQ_ID IS NULL OR (A.PAT_AUTH_SEQ_ID IS NOT NULL AND A.clm_status_type_id = 'APR'))-- Fixing for used amount
               --AND A.date_of_hospitalization  >= v_start_date AND A.date_of_discharge  <= v_end_date 
               ) s
               ON ( r.claim_seq_id = s.claim_seq_id );
              
          
        CURSOR dental_limit_cur(v_cur_policy_seq number) IS
        SELECT SUM(nvl(s.used_amount, r.used_amount)) FROM
         ( SELECT CASE WHEN  a.claim_seq_id IS NOT NULL AND x.clm_status_type_id in ('INP','REQ') THEN  
                  b.approved_amount 
                  ELSE CASE WHEN NVL(A.CLAIM_SEQ_ID,0) = 0 THEN b.approved_amount END
                  END AS used_amount , b.Pat_Auth_Seq_Id, a.claim_seq_id 
               FROM pat_authorization_details a
               left outer join app.clm_authorization_details x on (a.pat_auth_seq_id = x.pat_auth_seq_id)
               JOIN pat_activity_details b ON (a.pat_auth_seq_id = b.pat_auth_seq_id AND A.pat_status_type_id != 'PCN' AND A.pat_status_type_id != 'REJ' )
               JOIN tpa_activity_details G ON (b.code = g.activity_code)
               WHERE A.Tpa_Enrollment_Id = v_tpa_enrollment_id  
               AND NVL(A.Pat_Enhanced_Yn,'N') = 'N' 
               --AND g.activity_code LIKE 'D%'
               and a.policy_seq_id = v_cur_policy_seq
               and a.benifit_type='DNTL'
               and b.approved_amount>0
               AND (a.claim_seq_id IS NULL OR (a.claim_seq_id IS NOT NULL AND x.clm_status_type_id IN ('INP', 'REQ') 
               ))
               ) r
          FULL OUTER JOIN
           ( SELECT CASE WHEN A.PAT_AUTH_SEQ_ID IS NOT NULL AND A.clm_status_type_id IN ('INP','REQ') THEN NULL
                    ELSE CASE WHEN NVL(A.PAT_AUTH_SEQ_ID,0) = 0 THEN   b.approved_amount 
                             WHEN A.PAT_AUTH_SEQ_ID IS NOT NULL AND A.clm_status_type_id IN ('APR') THEN   b.approved_amount  END
                    END AS used_amount , a.claim_seq_id 
               FROM clm_authorization_details A 
               JOIN pat_activity_details b ON (a.claim_seq_id = b.claim_seq_id AND A.CLM_STATUS_TYPE_ID != 'PCN' AND A.CLM_STATUS_TYPE_ID != 'REJ' ) -----***
               JOIN tpa_activity_details G ON (b.code = g.activity_code)
               WHERE A.Tpa_Enrollment_Id = v_tpa_enrollment_id   
               --AND g.activity_code LIKE 'D%' 
               and a.policy_seq_id = v_cur_policy_seq
               and a.benifit_type='DNTL'
               AND (A.PAT_AUTH_SEQ_ID IS NULL OR (A.PAT_AUTH_SEQ_ID IS NOT NULL AND A.clm_status_type_id = 'APR'))-- Fixing for used amount
               ) s
               ON ( r.claim_seq_id = s.claim_seq_id );
               
              
    CURSOR health_checkup_limit(v_cur_policy_seq number) IS    
    SELECT SUM(nvl(s.used_no_visit, r.used_no_visit)) AS used_no_visit,SUM(nvl(s.used_amount, r.used_amount)) AS tot_approved_amount
    FROM (SELECT CASE WHEN b.pat_auth_seq_id IS NOT NULL THEN 1 ELSE 0 END AS used_no_visit,
                  CASE WHEN  a.claim_seq_id IS NOT NULL AND x.clm_status_type_id in ('INP','REQ') THEN  
                  b.allowed_amount 
                  ELSE CASE WHEN NVL(A.CLAIM_SEQ_ID,0) = 0 THEN b.allowed_amount END
                  END AS used_amount,
                 b.pat_auth_seq_id,
                 a.claim_seq_id
            FROM pat_authorization_details A
            left outer join app.clm_authorization_details x on (a.pat_auth_seq_id = x.pat_auth_seq_id)-----PROD FIXING 
            JOIN pat_activity_details B
              ON (a.pat_auth_seq_id = b.pat_auth_seq_id AND
                 A.Pat_Status_Type_Id != 'PCN' AND
                 A.Pat_Status_Type_Id != 'REJ')
           WHERE A.Tpa_Enrollment_Id = v_tpa_enrollment_id 
             AND  NVL(A.Pat_Enhanced_Yn,'N') = 'N'
             and a.policy_seq_id = v_cur_policy_seq
             AND a.benifit_type = 'HEAC'
             AND (a.claim_seq_id IS NULL OR (a.claim_seq_id IS NOT NULL AND x.clm_status_type_id IN ('INP', 'REQ') 
               ))             
               ) r
    FULL OUTER JOIN 
      (SELECT CASE WHEN b.claim_seq_id IS NOT NULL THEN 1 ELSE 0 END AS used_no_visit,
                        CASE WHEN A.PAT_AUTH_SEQ_ID IS NOT NULL AND A.clm_status_type_id IN ('INP','REQ') THEN NULL
                        ELSE CASE WHEN NVL(A.PAT_AUTH_SEQ_ID,0) = 0 THEN  b.allowed_amount 
                             WHEN A.PAT_AUTH_SEQ_ID IS NOT NULL AND A.clm_status_type_id IN ('APR') THEN  b.allowed_amount  END
                        END AS used_amount, a.claim_seq_id  
                       FROM clm_authorization_details A
                       JOIN pat_activity_details B
                         ON (A.claim_seq_id = B.claim_seq_id AND
                            a.clm_status_type_id != 'PCO' AND
                            A.clm_status_type_id != 'REJ')
                      WHERE A.Tpa_Enrollment_Id = v_tpa_enrollment_id
                      and a.policy_seq_id = v_cur_policy_seq 
                      AND a.benifit_type = 'HEAC'
                      AND (A.PAT_AUTH_SEQ_ID IS NULL OR (A.PAT_AUTH_SEQ_ID IS NOT NULL AND A.clm_status_type_id = 'APR'))-- Fixing for used amount
                     ) s
      ON (r.claim_seq_id = s.claim_seq_id);
     
    CURSOR maternity_oplimit_cur(v_cur_policy_seq number) IS
       SELECT SUM(nvl(s.used_amount, r.used_amount)) FROM
         ( SELECT  CASE WHEN  a.claim_seq_id IS NOT NULL AND x.clm_status_type_id in ('INP','REQ') THEN  
                  A.Tot_Allowed_Amount 
                  ELSE CASE WHEN NVL(A.CLAIM_SEQ_ID,0) = 0 THEN A.Tot_Allowed_Amount END
                  END AS used_amount , A.Pat_Auth_Seq_Id, a.claim_seq_id
           FROM pat_authorization_details a
           left outer join app.clm_authorization_details x on (a.pat_auth_seq_id = x.pat_auth_seq_id)  -----PROD FIXING
            WHERE a.pat_auth_seq_id IN
               (SELECT distinct a.pat_auth_seq_id    
               FROM pat_authorization_details a
               JOIN diagnosys_details b ON (a.pat_auth_seq_id = b.pat_auth_seq_id AND A.pat_status_type_id != 'PCN' AND A.pat_status_type_id != 'REJ' )
               JOIN tpa_icd_codes G ON (b.diagnosys_code = g.icd_code)
               JOIN tpa_icd_codes gg ON (g.master_icd_code = gg.master_icd_code )
               WHERE A.Tpa_Enrollment_Id = v_tpa_enrollment_id
               AND  NVL(A.Pat_Enhanced_Yn,'N') = 'N'  
               AND gg.icd_code = 'Z34.90'
               and a.encounter_type_id in ('1','2')
               AND a.benifit_type = 'OMTI'
               AND NVL(A.MAT_COMPLCTON_YN,'N') = 'N'
               AND (a.claim_seq_id IS NULL OR (a.claim_seq_id IS NOT NULL AND x.clm_status_type_id IN ('INP', 'REQ') 
               ))               
               ))r
          FULL OUTER JOIN
           ( SELECT CASE WHEN A.PAT_AUTH_SEQ_ID IS NOT NULL AND A.clm_status_type_id IN ('INP','REQ') THEN NULL
                    ELSE CASE WHEN NVL(A.PAT_AUTH_SEQ_ID,0) = 0 THEN   A.Tot_Allowed_Amount 
                             WHEN A.PAT_AUTH_SEQ_ID IS NOT NULL AND A.clm_status_type_id IN ('APR') THEN   A.Tot_Allowed_Amount  END
                    END  /*A.Tot_Allowed_Amount*/ AS used_amount , a.claim_seq_id  -----PROD FIXING
             FROM clm_authorization_details A 
              WHERE a.claim_seq_id IN  
               (SELECT distinct a.claim_seq_id  
               FROM clm_authorization_details A 
               JOIN diagnosys_details b ON (a.claim_seq_id = b.claim_seq_id AND A.CLM_STATUS_TYPE_ID != 'PCN' AND A.CLM_STATUS_TYPE_ID != 'REJ' )-----***
               JOIN tpa_icd_codes G ON (b.diagnosys_code = g.icd_code)
               JOIN tpa_icd_codes gg ON (g.master_icd_code = gg.master_icd_code )
               WHERE A.Tpa_Enrollment_Id = v_tpa_enrollment_id  
               AND gg.icd_code = 'Z34.90'
               and a.encounter_type_id in ('1','2')
               AND NVL(A.MAT_COMPLCTON_YN,'N') = 'N'
               AND a.benifit_type = 'OMTI'
               AND (A.PAT_AUTH_SEQ_ID IS NULL OR (A.PAT_AUTH_SEQ_ID IS NOT NULL AND A.clm_status_type_id = 'APR'))-- Fixing for used amount
               )) s
               ON ( r.claim_seq_id = s.claim_seq_id );
              
             
       CURSOR maternity_Iplimit_cur(v_cur_policy_seq number) IS
       SELECT SUM(nvl(s.used_amount, r.used_amount)) FROM
         ( SELECT  CASE WHEN  a.claim_seq_id IS NOT NULL AND x.clm_status_type_id in ('INP','REQ') THEN  
                  A.Tot_Allowed_Amount 
                  ELSE CASE WHEN NVL(A.CLAIM_SEQ_ID,0) = 0 THEN A.Tot_Allowed_Amount END
                  END AS used_amount , A.Pat_Auth_Seq_Id, a.claim_seq_id
           FROM pat_authorization_details a
           left outer join app.clm_authorization_details x on (a.pat_auth_seq_id = x.pat_auth_seq_id)  -----PROD FIXING
            WHERE a.pat_auth_seq_id IN
               (SELECT distinct a.pat_auth_seq_id    
               FROM pat_authorization_details a
               JOIN diagnosys_details b ON (a.pat_auth_seq_id = b.pat_auth_seq_id AND A.pat_status_type_id != 'PCN' AND A.pat_status_type_id != 'REJ' and b.primary_ailment_yn='Y')
               JOIN tpa_icd_codes G ON (b.diagnosys_code = g.icd_code)
               JOIN tpa_icd_codes gg ON (g.master_icd_code = gg.master_icd_code )
               WHERE A.Member_Seq_Id = v_cur_policy_seq
               AND  NVL(A.Pat_Enhanced_Yn,'N') = 'N'  
               AND gg.icd_code = 'Z34.90'
               and a.encounter_type_id in ('3','4','1','2')
               AND a.benifit_type in  ('IMTI','OMTI')
               AND NVL(A.MAT_COMPLCTON_YN,'N') = 'N'
               AND (a.claim_seq_id IS NULL OR (a.claim_seq_id IS NOT NULL AND x.clm_status_type_id IN ('INP', 'REQ') 
               ))               
               ) )r
          FULL OUTER JOIN
           ( SELECT CASE WHEN A.PAT_AUTH_SEQ_ID IS NOT NULL AND A.clm_status_type_id IN ('INP','REQ') THEN NULL
                    ELSE CASE WHEN NVL(A.PAT_AUTH_SEQ_ID,0) = 0 THEN   A.Tot_Allowed_Amount 
                             WHEN A.PAT_AUTH_SEQ_ID IS NOT NULL AND A.clm_status_type_id IN ('APR') THEN   A.Tot_Allowed_Amount  END
                    END  /*A.Tot_Allowed_Amount*/ AS used_amount , a.claim_seq_id  -----PROD FIXING
             FROM clm_authorization_details A 
              WHERE a.claim_seq_id IN  
               (SELECT distinct a.claim_seq_id  
               FROM clm_authorization_details A 
               JOIN diagnosys_details b ON (a.claim_seq_id = b.claim_seq_id AND A.CLM_STATUS_TYPE_ID != 'PCN' AND A.CLM_STATUS_TYPE_ID != 'REJ' and b.primary_ailment_yn='Y')-----***
               JOIN tpa_icd_codes G ON (b.diagnosys_code = g.icd_code)
               JOIN tpa_icd_codes gg ON (g.master_icd_code = gg.master_icd_code )
               WHERE A.Member_Seq_Id=v_cur_policy_seq  
               AND gg.icd_code = 'Z34.90'
               and a.encounter_type_id in ('3','4','1','2')
               AND NVL(A.MAT_COMPLCTON_YN,'N') = 'N'
               AND a.benifit_type in  ('IMTI','OMTI')
               AND (A.PAT_AUTH_SEQ_ID IS NULL OR (A.PAT_AUTH_SEQ_ID IS NOT NULL AND A.clm_status_type_id = 'APR'))-- Fixing for used amount
               )) s
               ON ( r.claim_seq_id = s.claim_seq_id );
            
           v_limit    number(10):=0;
           v_visits   number(10):=0;
           
  CURSOR get_benefit_limit_cur(v_seq tpa_ins_prod_policy_rules.prod_policy_rule_seq_id%type,v_si number) is 
  select tep.policy_seq_id,
--new
nvl(max(case when d.cond_id = 'cnd.18.1.8' and c.coverage_pay_val = 1 then  to_char(v_si) when d.cond_id = 'cnd.18.1.8' and c.coverage_pay_val = 2 then '0.1' when d.cond_id = 'cnd.18.1.8' and c.coverage_pay_val = 3 then nvl(replace(case when d.cond_id = 'cnd.18.1.8' then REGEXP_SUBSTR(d.cond_fun, '[^,]+', 1, 3) else null end, ''''), to_char(v_si)) end), '0') Maternity_limit,
 nvl(max(case when d.cond_id = 'cnd.27.1.1' and c.coverage_pay_val = 1 then to_char(v_si) when d.cond_id = 'cnd.27.1.1' and c.coverage_pay_val = 2 then '0.1' when d.cond_id = 'cnd.27.1.1' and c.coverage_pay_val = 3 then nvl(replace(case when d.cond_id = 'cnd.27.1.1' then REGEXP_SUBSTR(d.cond_fun, '[^,]+', 1, 6) else null end, ''''), to_char(v_si)) end), '0') HC_limit,
 nvl(max(case when d.cond_id = 'cnd.20.1.2' and c.coverage_pay_val = 1 then to_char(v_si) when d.cond_id = 'cnd.20.1.2' and c.coverage_pay_val = 2 then '0.1' when d.cond_id = 'cnd.20.1.2' and c.coverage_pay_val = 3 then nvl(replace(case when d.cond_id = 'cnd.20.1.2' then REGEXP_SUBSTR(d.cond_fun, '[^,]+', 1, 3) else null end, ''''), to_char(v_si)) end), '0') dental_limit, 
 nvl(max(case when d.cond_id = 'cnd.11.1.2' and c.coverage_pay_val = 1 then to_char(v_si) when d.cond_id = 'cnd.11.1.2' and c.coverage_pay_val = 2 then '0.1' when d.cond_id = 'cnd.11.1.2' and c.coverage_pay_val = 3 then nvl(replace(case when d.cond_id = 'cnd.11.1.2' then REGEXP_SUBSTR(d.cond_fun, '[^,]+', 1, 3) else null end, ''''), to_char(v_si)) end), '0') Optical_limit,
 nvl(max(case when d.cond_id = 'cnd.18.1.8' and c.coverage_pay_val = 3 then nvl(replace(case when d.cond_id = 'cnd.18.1.8' then REGEXP_SUBSTR(d.cond_fun, '[^,]+', 1, 27) else null end, ''''), '0')end ),'0') as Maternity_flag,
 nvl(max(case when d.cond_id = 'cnd.20.1.2' and c.coverage_pay_val = 3 then nvl(replace(case when d.cond_id = 'cnd.20.1.2' then replace(REGEXP_SUBSTR(d.cond_fun, '[^,]+', 1, 10),')') else null end, ''''), '0') end ),'0') as dental_flag,
 nvl(max(case when d.cond_id = 'cnd.11.1.2' and c.coverage_pay_val = 3 then nvl(replace(case when d.cond_id = 'cnd.11.1.2' then replace(REGEXP_SUBSTR(d.cond_fun, '[^,]+', 1, 10),')') else null end, ''''), '0') end ),'0') as Optical_flag,
 nvl(max(case when d.cond_id = 'cnd.18.1.8' then  c.coverage_pay_val else 0 end) ,  '0') maternity_coverage,
 nvl(max(case when d.cond_id = 'cnd.27.1.1' then c.coverage_pay_val else 0  end), '0') hc_coverage,
 nvl(max(case when d.cond_id = 'cnd.20.1.2' then c.coverage_pay_val else 0  end), '0') dental_coverage, 
 nvl(max(case when d.cond_id = 'cnd.11.1.2' then c.coverage_pay_val else 0 end), '0') Optical_coverage
 ,MAX(case when d.cond_id = 'cnd.19.8.1' THEN to_number(nvl(substr(SUBSTR(d.cond_fun,INSTR(d.cond_fun,',',1,2)+1),2,INSTR(SUBSTR(d.cond_fun,INSTR(d.cond_fun,',',1,2)+1),',',1,1)-3),v_si)) END) AS opts_limit
 ,max(case when d.cond_id = 'cnd.19.8.1' THEN substr(d.cond_fun,INSTR(d.cond_fun,',',-1,1)+2,2) END) opts_limit_per    
 
  FROM app.tpa_enr_policy tep
  left join app.tpa_ins_prod_policy tipp
    ON (tep.policy_seq_id = tipp.policy_seq_id)
  join app.tpa_ins_prod_policy_rules tippr
    on (tippr.prod_policy_seq_id = tipp.prod_policy_seq_id)
  join app.tpa_ins_prod_pol_clauses B
    on (b.prod_policy_rule_seq_id = tippr.prod_policy_rule_seq_id)
  JOIN app.tpa_ins_prod_pol_coverages C
    ON (B.clause_seq_id = c.clause_seq_id)
  JOIN app.tpa_ins_prod_pol_conditions d
    ON (c.coverage_seq_id = d.coverage_seq_id)
 
 WHERE  d.cond_id in ('cnd.11.1.2','cnd.20.1.2','cnd.27.1.1','cnd.18.1.8','cnd.19.8.1') 
 and tippr.prod_policy_rule_seq_id=v_seq
 group by tep.policy_seq_id ;

CURSOR curr_mem_si IS
  select tem.mem_tot_sum_insured,
         CASE WHEN v_benefit_type = 'DNTL' THEN pp.dntl_buffer_limit
              WHEN v_benefit_type = 'OPTC' THEN pp.optc_buffer_limit
              WHEN v_benefit_type = 'OPTS' THEN pp.opts_buffer_limit 
              WHEN v_benefit_type = 'OMTI' THEN pp.omti_buffer_limit
         END AS buffer_limit
         
  from app.tpa_enr_policy tep
  join app.tpa_enr_policy_group teg on (tep.policy_seq_id = teg.policy_seq_id) 
  join app.tpa_enr_policy_member tem on(teg.policy_group_seq_id = tem.policy_group_seq_id)
  JOIN tpa_ins_prod_policy pp ON (pp.policy_seq_id = tep.policy_seq_id)
  where  tem.tpa_enrollment_id=v_tpa_enrollment_id 
  and sysdate between tep.effective_from_date and tep.effective_to_date+1;
 v_mem_rec  curr_mem_si%ROWTYPE;
 
 benefit_limit_rec   get_benefit_limit_cur%rowtype;
 v_prod_policy_rule_seq_id       tpa_ins_prod_policy_rules.prod_policy_rule_seq_id%type:=null;
 v_ava_limit   number:=0;
 --v_mem_si  number:=0;


/*CURSOR opts_limit_cur(v_policy_seq_id NUMBER) IS
 SELECT to_number(substr(SUBSTR(d.cond_fun,INSTR(d.cond_fun,',',1,2)+1),2,INSTR(SUBSTR(d.cond_fun,INSTR(d.cond_fun,',',1,2)+1),',',1,1)-3)) AS opts_limit
        ,substr(d.cond_fun,INSTR(d.cond_fun,',',-1,1)+2,2) limit_per    
     FROM tpa_enr_policy p 
     join tpa_ins_prod_policy pp on (p.policy_seq_id = pp.policy_seq_id)
     join tpa_ins_prod_policy_rules r on (r.prod_policy_seq_id= pp.prod_policy_seq_id)
     join tpa_ins_prod_pol_clauses B on (r.prod_policy_rule_seq_id = b.prod_policy_rule_seq_id)
     JOIN tpa_ins_prod_pol_coverages C ON (b.clause_seq_id = c.clause_seq_id)
     JOIN tpa_ins_prod_pol_conditions D ON (c.coverage_seq_id = d.coverage_seq_id)
    where p.policy_seq_id =v_policy_seq_id AND d.cond_id ='cnd.19.8.1' ;
v_opts_limit    opts_limit_cur%ROWTYPE;*/

 CURSOR Get_tot_utilised_amt(v_policy_seq_id NUMBER) IS
      SELECT SUM (NVL(CL.FINAL_APP_AMOUNT,PR.FINAL_APP_AMOUNT))
       FROM 
       (SELECT CASE WHEN P.PAT_STATUS_TYPE_ID='APR' THEN P.FINAL_APP_AMOUNT ELSE P.TOT_APPROVED_AMOUNT END  
              AS FINAL_APP_AMOUNT,P.CLAIM_SEQ_ID,P.PAT_AUTH_SEQ_ID 
         FROM PAT_AUTHORIZATION_DETAILS P
         LEFT OUTER JOIN CLM_AUTHORIZATION_DETAILS CAD ON (P.CLAIM_SEQ_ID=CAD.CLAIM_SEQ_ID)
         WHERE P.Tpa_Enrollment_Id= v_tpa_enrollment_id AND p.policy_seq_id= v_policy_seq_id
         AND NVL(P.Pat_Enhanced_Yn,'N') ='N'
         AND P.PAT_STATUS_TYPE_ID IN ('INP','APR','REQ') AND P.BENIFIT_TYPE='OPTS' AND NVL(P.LIMIT_APPLIED_FLAG,'WOP')='WOP'
         AND (P.CLAIM_SEQ_ID IS NULL OR (P.CLAIM_SEQ_ID IS NOT NULL AND NVL(CAD.CAL_ACT_YN,'N')='N') 
         AND CAD.CLM_STATUS_TYPE_ID IN ('INP','APR','REQ'))) PR
        FULL OUTER JOIN
        (
         SELECT CASE WHEN C.CLM_STATUS_TYPE_ID='APR' THEN C.FINAL_APP_AMOUNT ELSE C.TOT_APPROVED_AMOUNT END  
             AS FINAL_APP_AMOUNT,c.CLAIM_SEQ_ID
          FROM CLM_AUTHORIZATION_DETAILS C
          WHERE C.Tpa_Enrollment_Id=v_tpa_enrollment_id AND c.policy_seq_id=v_policy_seq_id
          AND C.CLM_STATUS_TYPE_ID IN ('INP','APR','REQ')
          AND C.BENIFIT_TYPE='OPTS' AND NVL(C.LIMIT_APPLIED_FLAG,'WOP')='WOP'
         ) CL
         ON (PR.CLAIM_SEQ_ID=CL.CLAIM_SEQ_ID);
   v_opts_used   NUMBER(20,2);
  ---------------- optical enhance ----------------------
  CURSOR optc_used_cur(v_policy_seq_id NUMBER) IS
    SELECT SUM(nvl(c.used_amount, p.used_amount)) FROM
      (SELECT nvl(b.approved_amount,0) used_amount,a.pat_auth_seq_id,a.claim_seq_id 
         FROM pat_authorization_details a
         left outer join app.clm_authorization_details x on (a.pat_auth_seq_id = x.pat_auth_seq_id)
         JOIN pat_activity_details b ON(a.pat_auth_seq_id=b.pat_auth_seq_id AND a.benifit_type='OPTC' AND nvl(b.optc_payable,'EXC')='EXC')
         JOIN tpa_activity_details c ON (b.code=c.activity_code AND c.master_activity_code IN ('9','V2020','92015'))
        WHERE a.tpa_enrollment_id= v_tpa_enrollment_id AND a.policy_seq_id=v_policy_seq_id
          AND (a.claim_seq_id IS NULL OR (a.claim_seq_id IS NOT NULL AND x.clm_status_type_id IN ('INP', 'REQ'))))p 
     FULL OUTER JOIN
      (SELECT nvl(b.approved_amount,0) used_amount,a.claim_seq_id 
         FROM clm_authorization_details a
         JOIN pat_activity_details b ON(a.claim_seq_id=b.claim_seq_id AND a.benifit_type='OPTC'  AND nvl(b.optc_payable,'EXC')='EXC')
         JOIN tpa_activity_details c ON (b.code=c.activity_code AND c.master_activity_code IN ('9','V2020','92015'))
        WHERE a.tpa_enrollment_id= v_tpa_enrollment_id AND a.policy_seq_id=v_policy_seq_id
        AND (A.PAT_AUTH_SEQ_ID IS NULL OR (A.PAT_AUTH_SEQ_ID IS NOT NULL AND A.clm_status_type_id = 'APR')))c
     ON ( p.claim_seq_id = c.claim_seq_id );
  
  v_optc_used_amt                  NUMBER(20,2);
  v_limit_flag          VARCHAR2(5);
  -------------------------------------------------------
  
BEGIN
  
--delete from test_claim;commit;
--insert into test_claim(claim_number) values(v_tpa_enrollment_id||'@'||v_benefit_type); commit;
  
open enroll_type_cur;
fetch enroll_type_cur into v_enroll_type;
close enroll_type_cur;

open curr_mem_si;
fetch curr_mem_si into v_mem_rec;
close curr_mem_si;

OPEN CR_BENEFIT_YA(v_enroll_type.policy_seq_id);
FETCH CR_BENEFIT_YA INTO LV_CR_BENEFIT_YA;
CLOSE CR_BENEFIT_YA;

IF LV_CR_BENEFIT_YA.CNT > 0 THEN
open Eligible_benifits;
fetch Eligible_benifits into v_hosp_ben;
close Eligible_benifits;
END IF;

  /*open Curr_Policy_seq_id;
     fetch Curr_Policy_seq_id into v_policy_seq_id;
          close Curr_Policy_seq_id;*/

open PREVIOUS_POLICY_NUMBER(v_enroll_type.policy_seq_id);
  fetch PREVIOUS_POLICY_NUMBER into v_policy_number;
    close PREVIOUS_POLICY_NUMBER;

IF v_enroll_type.cnt > 1 then
  raise_application_error (-20402, 'More than one Values Returning');
END IF;
v_prod_policy_rule_seq_id:=intx.authorization_pkg.get_prod_pol_seq_id(v_enroll_type.policy_seq_id,'POL');


open get_benefit_limit_cur(v_prod_policy_rule_seq_id,v_mem_rec.mem_tot_sum_insured);
fetch get_benefit_limit_cur into benefit_limit_rec;
close get_benefit_limit_cur;

select hi.primary_network into v_provider_network from tpa_hosp_info hi where hosp_seq_id = v_hosp_seq_id;
     select case when v_benefit_type = 'IPT' then 'In-Patient'
                 when v_benefit_type = 'OPTS'  then 'Out-Patient' 
                 when v_benefit_type = 'OPTC'  then 'Optical'
                 when v_benefit_type ='IMTI' then 'In-Patient Maternity'
                 when v_benefit_type ='OMTI' then 'Out-Patient Maternity'
                 when v_benefit_type = 'DNTL'  then 'Dental' 
                 when v_benefit_type = 'HEAC'  then 'Health Check Up' 
                 when v_benefit_type = 'DAYC'  then 'Daycare' end as v_benefit_type into benefit_type from dual; 
IF v_benefit_type ='OPTS' THEN
  /*OPEN  opts_limit_cur(v_enroll_type.policy_seq_id);
  FETCH opts_limit_cur INTO v_opts_limit;
  CLOSE opts_limit_cur;*/
  v_limit_flag:=benefit_limit_rec.opts_limit_per;
  IF benefit_limit_rec.opts_limit_per ='PP' AND benefit_limit_rec.opts_limit IS NOT NULL THEN
    OPEN  Get_tot_utilised_amt(v_enroll_type.policy_seq_id);
    FETCH Get_tot_utilised_amt INTO v_opts_used;
    CLOSE Get_tot_utilised_amt;
    
    OPEN optc_used_cur(v_enroll_type.policy_seq_id);
    FETCH optc_used_cur INTO v_optc_used_amt;
    CLOSE optc_used_cur;
    v_limit := nvl(v_opts_used,0)+nvl(v_optc_used_amt,0);
    benefit_limit_rec.opts_limit:=greatest(benefit_limit_rec.opts_limit-nvl(v_limit,0),0);
    
  END IF;
  v_ava_limit := nvl(benefit_limit_rec.opts_limit,0);
ELSIF v_benefit_type='OPTC'  THEN 
  v_limit_flag:=benefit_limit_rec.optical_flag;
  IF nvl(benefit_limit_rec.optical_flag,'NA')!='PC' and nvl(benefit_limit_rec.optical_coverage,0)!=2  THEN 
    open Optical_limit_cur(v_enroll_type.policy_seq_id);
    fetch Optical_limit_cur into v_limit;
    close Optical_limit_cur;
   END IF;
   v_ava_limit:= nvl(benefit_limit_rec.optical_limit,0)-nvl(v_limit,0);
    
ELSIF v_benefit_type='DNTL'  THEN
  v_limit_flag:=benefit_limit_rec.dental_flag;
  IF nvl(benefit_limit_rec.dental_flag,'NA')!='PC' and nvl(benefit_limit_rec.dental_coverage,0)!=2 THEN 
    open dental_limit_cur(v_enroll_type.policy_seq_id);
    fetch dental_limit_cur into v_limit;
    close dental_limit_cur;
   END IF; 
   v_ava_limit:= nvl(benefit_limit_rec.dental_limit,0)-nvl(v_limit,0);
    
ELSIF v_benefit_type='HEAC'    THEN
   
   if nvl(benefit_limit_rec.hc_coverage,0)!=2 then
      open health_checkup_limit(v_enroll_type.policy_seq_id);
      fetch health_checkup_limit into v_visits,v_limit;
      close health_checkup_limit;
   end if;
    v_ava_limit:= nvl(benefit_limit_rec.hc_limit,0)-nvl(v_limit,0);
     
ELSIF v_benefit_type in ('IMTI','OMTI')   THEN
  v_limit_flag:=benefit_limit_rec.maternity_flag;
  IF nvl(benefit_limit_rec.maternity_flag,'NA')!='PC' and nvl(benefit_limit_rec.maternity_coverage,0)!=2  THEN 
    open maternity_Iplimit_cur(v_enroll_type.member_seq_id);
    fetch maternity_Iplimit_cur into v_limit;
    close maternity_Iplimit_cur;
   v_limit:=v_limit ;
  END IF;
   v_ava_limit:= nvl(benefit_limit_rec.maternity_limit,0)-(nvl(v_limit,0));
   


END IF;

IF nvl(v_ava_limit,0)<=0 and nvl(v_limit,0) > 0 and v_benefit_type in ('OMTI','IMTI','HEAC','DNTL','OPTC','OPTS')then
   --raise_application_error (-20967, 'Patient Eligible for availing '|| case when v_benefit_type='IMTI' then 'IP Maternity' when v_benefit_type='OMTI' then 'OP Maternity' else benefit_type end||' Benefit :'||' No.Benefit limit is exhausted');
     raise_application_error (-20967, 'Not eligible as '|| case when v_benefit_type='IMTI' then 'IP Maternity' when v_benefit_type='OMTI' then 'OP Maternity' else benefit_type end||' Benefit'||' limit exhausted');
ELSIF /*benefit_limit_rec.optical_limit >0 AND*/ v_limit_flag='PP' AND nvl(v_ava_limit,0)< v_mem_rec.buffer_limit AND v_benefit_type in ('OMTI','DNTL','OPTC','OPTS') THEN
     raise_application_error (-20847, 'Please take the prior approval as there is only minimal balance limit available for '||CASE when v_benefit_type='OMTI' then 'OP Maternity' else benefit_type end);
END IF;



IF v_enroll_type.enrol_type_id = 'COR' THEN
  OPEN v_result_set FOR
     SELECT hi.primary_network,
            c.tpa_enrollment_id,
            c.emirate_id,
            c.member_seq_id,
            c.mem_name,
            b.insured_name,
            c.mem_age,
            c.mem_dob,
            decode(c.gender_general_type_id,'MAL','MALE','FEMALE') as gender,
            d.ins_comp_name as payer_name,
            d.ins_seq_id,
            case when v_hosp_ben is null then
           -- case when ','||v_hosp_ben||',' like '%,'||v_benefit_type||',%' THEN 
            case when v_benefit_type IN ('IMTI', 'OMTI') and h.eligible_yn='Y' and nvl(v_ava_limit,0)>0 then 
              case when (c.gender_general_type_id='FEM' and nvl(c.marital_status_id,'SNG')='MRD' and c.relship_type_id in ('NSF','YSP')) then --changed in CR-0180 & CR-0182 
                'YES' 
              else 
                'NO'
              end 
             else 
               case when h.eligible_yn='Y' and v_benefit_type NOT IN ('IPT', 'OPTS') and nvl(v_ava_limit,0)>0 then 'YES' 
                    when h.eligible_yn='Y' and v_benefit_type  IN ('IPT', 'OPTS') THEN 'YES'
               else 
                 'NO'
               end
             end
             ELSE
            case when ','||v_hosp_ben||',' like '%,'||v_benefit_type||',%' THEN 
            case when v_benefit_type IN ('IMTI', 'OMTI') and h.eligible_yn='Y' then 
              case when (c.gender_general_type_id='FEM' and nvl(c.marital_status_id,'SNG')='MRD' and c.relship_type_id in ('NSF','YSP')) then --changed in Cr-0180 & CR-0182
                'YES' 
              else 
                'NO'
              end 
             else 
               case when h.eligible_yn='Y' and v_benefit_type NOT IN ('IPT', 'OPTS') and nvl(v_ava_limit,0)>0 then 'YES' 
                    when h.eligible_yn='Y' and v_benefit_type  IN ('IPT', 'OPTS') THEN 'YES'
               else 
                 'NO'
               end
             end
             ELSE  'NO'
             end end
              as eligibility,
            '' as deductible,
            h.copay_perc as co_participation,
            --null as applicable_procedure,
            '-' as exclusions,
            h.authorization_req_yn,
            i.pat_intimation_id,
            tip.product_cat_type_id as productType,
            --null as tob
            case when nvl(c.vip_yn,'N') = 'Y' then nvl(to_char(f.vip_pre_aprvl_limit),'Nil')
                 when nvl(c.vip_yn,'N') = 'N' then nvl(to_char(f.non_vip_pre_aprvl_limit),'Nil') end as pre_apprvl_limit,
            case when nvl(h.eligible_yn,'N')='N' or ((c.gender_general_type_id='MAL' or nvl(c.marital_status_id,'SNG')!='MRD'or c.relship_type_id not in ('NSF','YSP')) and v_benefit_type IN ('IMTI', 'OMTI')) THEN 'Member is not eligible for this Benefit type. ' else null end ||    
            case when hi.primary_network != v_provider_network THEN 'Member is not eligible for this Network type. ' else null end||
            case when v_hosp_ben is not null then
              case when ','||v_hosp_ben||',' like ',%'||v_benefit_type||',%' then NULL else 'Provider is not covered for given Benifit type' end end
              as elig_denial_reason,
            hi.hosp_name,hi.off_phone_no_1,hi.office_fax_no,hi.hosp_licenc_numb,hi.std_code,
            a.policy_number as policy_no,
            to_char(a.effective_from_date, 'DD/MM/RRRR') as policy_st_dt,
            to_char(a.effective_to_date, 'DD/MM/RRRR') as policy_en_dt,
            NVL(v_policy_number,'-') as INITIAL_POLICY_NO,
            CASE WHEN c.date_of_inception<a.effective_from_date THEN to_char(a.effective_from_date, 'DD/MM/RRRR') ELSE to_char(c.date_of_inception, 'DD/MM/RRRR') END as member_st_dt,
            to_char(c.date_of_exit, 'DD/MM/RRRR') as member_en_dt,
            case when a.opts_pat_limit is not null and hi.opts_pat_limit is not null then least(a.opts_pat_limit,hi.opts_pat_limit)
            else coalesce(a.opts_pat_limit,hi.opts_pat_limit) end as opts_pat_limit
            ,benefit_limit_rec.opts_limit AS opts_avl_limit
            
     FROM tpa_enr_policy a join tpa_enr_policy_group b ON (a.policy_seq_id=b.policy_seq_id)
     JOIN tpa_enr_policy_member c on (b.policy_group_seq_id=c.policy_group_seq_id)
     LEFT OUTER JOIN tpa_ins_info d on (d.ins_seq_id=a.ins_seq_id)
     LEFT OUTER JOIN tpa_ins_product e on (a.product_seq_id=e.product_seq_id)
     LEFT OUTER JOIN tpa_ins_prod_policy f ON (a.policy_seq_id=f.policy_seq_id)
     LEFT OUTER JOIN tpa_ins_prod_policy_rules g on (g.prod_policy_seq_id=f.prod_policy_seq_id)
     LEFT OUTER JOIN tpa_ins_prod_pol_benefits h on (h.prod_policy_rule_seq_id=g.prod_policy_rule_seq_id and upper(h.benefit_name) = upper(benefit_type))
     left outer join pat_intimation_details i on (i.member_seq_id=c.member_seq_id)
     left outer join prov_payer_association pp on (d.ins_seq_id = pp.ins_seq_id)
     left join tpa_ins_product tip on (a.product_seq_id = tip.product_seq_id)
     left outer join tpa_hosp_info hi on (pp.hosp_seq_id = hi.hosp_seq_id)
     where (c.tpa_enrollment_id=v_tpa_enrollment_id or c.emirate_id=v_tpa_enrollment_id) --emirate_id validation added in cr0218
       and sysdate between a.effective_from_date and a.effective_to_date+1
      and hi.hosp_seq_id=v_hosp_seq_id;
 ELSIF v_enroll_type.enrol_type_id != 'COR' THEN
 OPEN v_result_set FOR
     SELECT hi.primary_network,
            c.tpa_enrollment_id,
            c.member_seq_id,
            c.mem_name,
            b.insured_name,
            c.mem_age,
            c.mem_dob,
            decode(c.gender_general_type_id,'MAL','MALE','FEMALE') as gender,
            d.ins_comp_name as payer_name,
            d.ins_seq_id,
            case when v_benefit_type IN ('IMTI', 'OMTI') and h.eligible_yn='Y' and nvl(v_ava_limit,0)>0 then case when (c.gender_general_type_id='FEM' and nvl(c.marital_status_id,'SNG')='MRD' and c.relship_type_id in ('NSF','YSP')) then 'Y' else 'N' end  
                else 
                  case when h.eligible_yn='Y' and v_benefit_type NOT IN ('IPT', 'OPTS') and nvl(v_ava_limit,0)>0 then 'YES' 
                    when h.eligible_yn='Y' and v_benefit_type  IN ('IPT', 'OPTS') THEN 'YES' 
                    else 'NO' end 
                      end as eligibility,
            '-' as deductible,
            h.copay_perc as co_participation,
            --null as applicable_procedure,
            '-' as exclusions,
            h.authorization_req_yn,
            i.pat_intimation_id,
            tip.product_cat_type_id as productType,
            case when c.vip_yn = 'Y' then f.vip_pre_aprvl_limit
                 when c.vip_yn = 'N' then f.non_vip_pre_aprvl_limit end as pre_apprvl_limit,
            --null as tob
            case when nvl(h.eligible_yn,'N')='N' or (v_benefit_type IN ('MTI', 'OMTI', 'IMTI') and c.gender_general_type_id!='FEM' or nvl(c.marital_status_id,'SNG')!='MRD' or c.relship_type_id not in ('NSF','YSP')) THEN 'member is not eligible for this benefit type ' else null end ||   --changed in CR-0180 & CR-0182
             case when hi.primary_network != v_provider_network THEN 'member is not eligible for this network type ' else null end as elig_denial_reason     
            , NULL as INITIAL_POLICY_NO,
            CASE WHEN c.date_of_inception<a.effective_from_date THEN to_char(a.effective_from_date, 'DD/MM/RRRR') ELSE to_char(c.date_of_inception, 'DD/MM/RRRR') END as member_st_dt,
            to_char(c.date_of_exit, 'DD/MM/RRRR') as member_en_dt,
            case when a.opts_pat_limit is not null and hi.opts_pat_limit is not null then least(a.opts_pat_limit,hi.opts_pat_limit)
            else coalesce(a.opts_pat_limit,hi.opts_pat_limit) end as opts_pat_limit
            ,benefit_limit_rec.opts_limit AS opts_avl_limit 
     
     FROM tpa_enr_policy a join tpa_enr_policy_group b ON (a.policy_seq_id=b.policy_seq_id)
     JOIN tpa_enr_policy_member c on (b.policy_group_seq_id=c.policy_group_seq_id)
     LEFT OUTER JOIN tpa_ins_info d on (d.ins_seq_id=a.ins_seq_id)
     LEFT OUTER JOIN tpa_ins_product e on (a.product_seq_id=e.product_seq_id)
     LEFT OUTER JOIN tpa_ins_prod_policy f ON (e.product_seq_id=f.product_seq_id)
     LEFT OUTER JOIN tpa_ins_prod_policy_rules g on (g.prod_policy_seq_id=f.prod_policy_seq_id)
     LEFT OUTER JOIN tpa_ins_prod_pol_benefits h on (h.prod_policy_rule_seq_id=g.prod_policy_rule_seq_id and h.benefit_name = benefit_type)
     left outer join pat_intimation_details i on (i.member_seq_id=c.member_seq_id)
     left outer join prov_payer_association pp on (d.ins_seq_id = pp.ins_seq_id)
     left join tpa_ins_product tip on (a.product_seq_id = tip.product_seq_id)
     left outer join tpa_hosp_info hi on (pp.hosp_seq_id = hi.hosp_seq_id)
     where (c.tpa_enrollment_id=v_tpa_enrollment_id or c.emirate_id=v_tpa_enrollment_id) and hi.hosp_seq_id=v_hosp_seq_id ;

 END IF;
      OPEN v_network_check FOR 
       select hn.network_type, hn.network_yn
        from app.tpa_hosp_network hn,app.tpa_general_code gc
       where gc.general_type_id=hn.network_type and hn.hosp_seq_id = v_hosp_seq_id
       order by gc.sort_no;
  
 END get_mem_benifit_details;
 --=======================================================================================
 PROCEDURE get_hosp_details(v_tpa_enrollment_id                  IN  PAT_ENROLL_DETAILS.tpa_enrollment_id%TYPE,
                            v_benefit_type                       IN  PAT_AUTHORIZATION_DETAILS.Benifit_Type%TYPE,                                     
                            v_hosp_seq_id                        IN  TPA_HOSP_INFO.HOSP_SEQ_ID%TYPE,
                            v_result_set                         OUT SYS_REFCURSOR)
IS 
benefit_type           varchar2(30);
v_enroll_type          varchar2(30);
v_provider_network     varchar2(30);
BEGIN

  OPEN v_result_set FOR
     SELECT hi.hosp_name,
            hi.off_phone_no_1,
            hi.office_fax_no,
            hi.hosp_licenc_numb,
            hi.std_code,
            cc.city_description as prov_loc
       FROM tpa_hosp_info hi
       left outer join tpa_hosp_address ha
         on (hi.hosp_seq_id = ha.hosp_seq_id)
       left outer join app.tpa_city_code cc
         on (ha.city_type_id = cc.city_type_id)
      where hi.hosp_seq_id = v_hosp_seq_id;
   
 END get_hosp_details;
 -----------===================================================================
 PROCEDURE save_hosp_presc_dtls(
    v_prescription_seq_id              IN OUT TPA_HOSP_PRESCRIPTION_DETAILS.prescription_seq_id%TYPE,
    v_hosp_seq_id                      IN TPA_HOSP_PRESCRIPTION_DETAILS.hosp_seq_id%TYPE,
    v_intimate_seq_id                  IN TPA_HOSP_PRESCRIPTION_DETAILS.INTIMATE_SEQ_ID%TYPE,
    v_medical_type_id                  IN TPA_HOSP_PRESCRIPTION_DETAILS.medical_type_id%TYPE,
    v_added_by                         IN TPA_HOSP_PRESCRIPTION_DETAILS.ADDED_BY%TYPE
  )
  IS
  BEGIN
   
    IF  nvl(v_prescription_seq_id,0) = 0  THEN
      INSERT INTO tpa_hosp_prescription_details (prescription_seq_id,hosp_seq_id,INTIMATE_SEQ_ID,medical_type_id,
                  added_by,added_date)
           VALUES (TPA_HOSP_PRESC_DETAILS_SEQ.NEXTVAL,v_hosp_seq_id,v_intimate_seq_id,v_medical_type_id,
                  v_added_by,SYSDATE);
    ELSE
     
      UPDATE tpa_hosp_prescription_details
         SET medical_type_id               = v_medical_type_id,
             updated_by                    = v_added_by,
             updated_date                  = SYSDATE
       WHERE prescription_seq_id     = v_prescription_seq_id;

    END IF;
  END save_hosp_presc_dtls;
--===============================================================================
PROCEDURE add_prescription_details(
    v_prescription_type             IN TPA_HOSP_PRESC_MEDICAL_CODE.PRESCRIPTION_TYPE_ID%TYPE,
    v_medical_abb_type              IN TPA_HOSP_PRESC_MEDICAL_CODE.MEDICAL_TYPE_ID%TYPE,
    v_activity_code                 IN TPA_HOSP_PRESC_MEDICAL_CODE.ACTIVITY_CODE%TYPE,
    v_description                   IN TPA_HOSP_PRESC_MEDICAL_CODE.MEDICAL_DESCRIPTION%TYPE,
    v_added_by                      IN TPA_HOSP_PRESC_MEDICAL_CODE.added_by%TYPE,
    v_rows_processed                OUT NUMBER
  )
  IS
  v_cnt    number(10);
  BEGIN
       SELECT COUNT(1) INTO v_cnt FROM TPA_HOSP_PRESC_MEDICAL_CODE M WHERE M.MEDICAL_TYPE_ID=UPPER(v_medical_abb_type);  
       IF v_cnt =0 THEN
         INSERT INTO TPA_HOSP_PRESC_MEDICAL_CODE(MEDICAL_TYPE_ID,
                                                 PRESCRIPTION_TYPE_ID,
                                                 ACTIVITY_CODE,
                                                 MEDICAL_DESCRIPTION,
                                                 ADDED_DATE,
                                                 ADDED_BY )
                                        VALUES  (upper(v_medical_abb_type),
                                                 v_prescription_type,
                                                 v_activity_code,
                                                 v_description,
                                                 SYSDATE,
                                                 v_added_by);
       
       ELSE
        raise_application_error(-20870,'Medical abbreviation code is already exist,please enter new one'); 
      END IF;
       v_rows_processed := SQL%ROWCOUNT;
       COMMIT;
  END add_prescription_details;
 --====================================================
 PROCEDURE check_enrollment_id (
    v_tpa_enrollment_id                  IN  PAT_ENROLL_DETAILS.tpa_enrollment_id%TYPE,
    v_flag                               OUT VARCHAR2
    )
IS

v_result_set                              SYS_REFCURSOR;
v_otp_id                                  tpa_enr_pol_mem_otp_codes.otp_seq_id%type;
v_member_seq_id                           tpa_enr_pol_mem_otp_codes.member_seq_id%TYPE;

BEGIN

OPEN v_result_set  FOR
  SELECT a.member_seq_id
  FROM   tpa_enr_policy_member A
  JOIN tpa_enr_policy_group B ON (A.policy_group_seq_id = B.policy_group_seq_id)
  JOIN tpa_enr_policy C ON (B.policy_seq_id = C.policy_seq_id )
  JOIN tpa_enr_pol_mem_otp_codes oc on (oc.member_seq_id=a.member_seq_id)
  WHERE a.tpa_enrollment_id=v_tpa_enrollment_id
  AND ( SYSDATE BETWEEN C.effective_from_date AND C.effective_to_date+1)
  and trunc(oc.generated_date)=trunc(sysdate);
FETCH v_result_set INTO v_member_seq_id;
CLOSE v_result_set;



IF v_member_seq_id IS NOT NULL  THEN
  V_FLAG:='Y';
 ELSE 
  V_FLAG:='N';
END IF;
 
END check_enrollment_id;
----------------------------------------------
procedure save_pat_intimatimation(v_pat_intimation_seq_id   in out pat_intimation_details.pat_intimation_seq_id%type,
                                  v_member_seq_id           in pat_intimation_details.member_seq_id%type,
                                  v_ins_seq_id              in pat_intimation_details.ins_seq_id%type,
                                  v_hosp_seq_id             in pat_intimation_details.hosp_seq_id%type,
                                  v_pre_auth_seq_id         in pat_intimation_details.pre_auth_seq_id%type,
                                  v_medical_record_no       in pat_intimation_details.medical_record_no%type,
                                  v_emergency_yn            in pat_intimation_details.emergency_yn%type,
                                  v_clinician_id            in pat_intimation_details.clinician_id%type,
                                  v_clinician_speciality    in pat_intimation_details.clinician_speciality%type,
                                  v_presenting_complaints   in pat_intimation_details.presenting_complaints%type,
                                  v_medicine_gen_type_id    in pat_intimation_details.medicine_gen_type_id%type,
                                  v_accident_case_yn        in pat_intimation_details.accident_case_yn%type,
                                  v_procedure_gen_type_id   in pat_intimation_details.procedure_gen_type_id%type,
                                  v_since_when              in pat_intimation_details.since_when%type,
                                  v_trtmnt_plan_gen_type_id in pat_intimation_details.trtmnt_plan_gen_type_id%type,
                                  v_estimation_amount       in pat_intimation_details.estimation_amount%type,
                                  v_bp_systolic             in pat_intimation_details.bp_systolic%type,
                                  v_bp_diastolic            in pat_intimation_details.bp_diastolic%type,
                                  v_details_of_treatment    in pat_intimation_details.details_of_treatment%type,
                                  v_medical_findings        in pat_intimation_details.medical_findings%type,
                                  v_file_name               in pat_intimation_details.file_name%type,
                                  v_medical_type_ids        in varchar2,
                                  v_added_by                in pat_intimation_details.added_by%type,
                                  v_invoice_num             in pat_intimation_details.INVOICE_NUMBER%TYPE,
                                  V_FIR_NUMBER              in pat_intimation_details.FIR_NUMBER%TYPE,
                                  V_rows_processed          out NUMBER) IS

  str_tab               ttk_util_pkg.str_table_type;
  v_prescription_seq_id tpa_hosp_prescription_details.prescription_seq_id%type;
  V_ins_code            tpa_ins_info.ins_comp_code_number%type;
BEGIN

  IF v_medical_type_ids IS NOT NULL THEN
    str_tab := ttk_util_pkg.parse_str(v_medical_type_ids);
  END IF;
  IF V_INS_SEQ_ID IS NOT NULL THEN
    SELECT I.INS_COMP_CODE_NUMBER
      INTO V_ins_code
      FROM TPA_INS_INFO I
     WHERE I.INS_SEQ_ID = V_INS_SEQ_ID;
  END IF;

  IF (nvl(v_pat_intimation_seq_id, 0) = 0) THEN
    INSERT INTO pat_intimation_details
      (PAT_INTIMATION_SEQ_ID,
       MEMBER_SEQ_ID,
       PAT_INTIMATION_ID,
       HOSP_SEQ_ID,
       PRE_AUTH_SEQ_ID,
       MEDICAL_RECORD_NO,
       EMERGENCY_YN,
       CLINICIAN_ID,
       CLINICIAN_SPECIALITY,
       PRESENTING_COMPLAINTS,
       MEDICINE_GEN_TYPE_ID,
       ACCIDENT_CASE_YN,
       PROCEDURE_GEN_TYPE_ID,
       SINCE_WHEN,
       TRTMNT_PLAN_GEN_TYPE_ID,
       ESTIMATION_AMOUNT,
       BP_SYSTOLIC,
       BP_DIASTOLIC,
       DETAILS_OF_TREATMENT,
       MEDICAL_FINDINGS,
       FILE_NAME,
       ADDED_BY,
       ADDED_DATE,
       INS_SEQ_ID,
       treatment_date,
       INVOICE_NUMBER,
       FIR_NUMBER)
    VALUES
      (pat_intimation_details_seq.NEXTVAL,
       v_MEMBER_SEQ_ID,
       'PAT-' || V_ins_code || '-' || pat_intimation_details_seq.currval,
       v_HOSP_SEQ_ID,
       v_PRE_AUTH_SEQ_ID,
       v_MEDICAL_RECORD_NO,
       v_EMERGENCY_YN,
       v_CLINICIAN_ID,
       v_CLINICIAN_SPECIALITY,
       v_PRESENTING_COMPLAINTS,
       v_MEDICINE_GEN_TYPE_ID,
       v_ACCIDENT_CASE_YN,
       v_PROCEDURE_GEN_TYPE_ID,
       v_SINCE_WHEN,
       v_TRTMNT_PLAN_GEN_TYPE_ID,
       v_ESTIMATION_AMOUNT,
       v_BP_SYSTOLIC,
       v_BP_DIASTOLIC,
       v_DETAILS_OF_TREATMENT,
       v_MEDICAL_FINDINGS,
       v_FILE_NAME,
       v_ADDED_BY,
       SYSDATE,
       V_INS_SEQ_ID,
       sysdate,
       v_invoice_num,
       V_FIR_NUMBER)
    RETURNING PAT_INTIMATION_SEQ_ID INTO v_pat_intimation_seq_id;
  ELSE
    UPDATE pat_intimation_details
       SET 
           MEDICAL_RECORD_NO       = V_MEDICAL_RECORD_NO,
           EMERGENCY_YN            = V_EMERGENCY_YN,
           CLINICIAN_ID            = V_CLINICIAN_ID,
           CLINICIAN_SPECIALITY    = V_CLINICIAN_SPECIALITY,
           PRESENTING_COMPLAINTS   = V_PRESENTING_COMPLAINTS,
           MEDICINE_GEN_TYPE_ID    = V_MEDICINE_GEN_TYPE_ID,
           ACCIDENT_CASE_YN        = V_ACCIDENT_CASE_YN,
           PROCEDURE_GEN_TYPE_ID   = V_PROCEDURE_GEN_TYPE_ID,
           SINCE_WHEN              = V_SINCE_WHEN,
           TRTMNT_PLAN_GEN_TYPE_ID = V_TRTMNT_PLAN_GEN_TYPE_ID,
           ESTIMATION_AMOUNT       = V_ESTIMATION_AMOUNT,
           BP_SYSTOLIC             = V_BP_SYSTOLIC,
           BP_DIASTOLIC            = V_BP_DIASTOLIC,
           DETAILS_OF_TREATMENT    = V_DETAILS_OF_TREATMENT,
           MEDICAL_FINDINGS        = V_MEDICAL_FINDINGS,
           FILE_NAME               = V_FILE_NAME,
           UPDATED_BY              = v_ADDED_BY,
           UPDATED_DATE            = SYSDATE ,
           INVOICE_NUMBER          = v_invoice_num,
           FIR_NUMBER              = V_FIR_NUMBER
    
     WHERE PAT_INTIMATION_SEQ_ID = V_PAT_INTIMATION_SEQ_ID;
  
  END IF;
  /* FOR i IN str_tab.FIRST .. str_tab.LAST
   LOOP
   save_hosp_presc_dtls(v_prescription_seq_id,v_hosp_seq_id,v_pat_intimation_seq_id,str_tab(i),v_added_by);   
  END LOOP;*/
  V_rows_processed := SQL%ROWCOUNT;
  COMMIT;
END save_pat_intimatimation;

---=============================================================================================
procedure save_pat_online_intimation(v_pre_auth_seq_id        in out pat_authorization_details.pat_auth_seq_id%type,
                                    v_member_seq_id           in pat_authorization_details.member_seq_id%type,
                                    v_hospitalization_date    in pat_authorization_details.hospitalization_date%type,
                                    v_discharge_date          IN pat_authorization_details.discharge_date%type,
                                    v_clinician_name          in pat_non_network_details.clinician_name%type,
                                    v_clinician_id            in pat_authorization_details.clinician_id%type,
                                    v_presenting_complaints   in pat_authorization_details.presenting_complaints%type,
                                    v_past_history            in pat_authorization_details.past_history%type,
                                    v_duration_above_illness              in pat_authorization_details.duration_above_illness%type,
                                    v_duration_above_illness_time         in pat_authorization_details.duration_above_illness_time%type,
                                    v_since_when              in pat_authorization_details.since_when%type,
                                    v_since_when_time         in pat_authorization_details.since_when_time%type,
                                    v_encounter_start_type    in pat_authorization_details.encounter_start_type%type,
                                    v_encounter_type_id          in pat_authorization_details.encounter_type_id%type,
                                    v_pre_auth_number         in out pat_authorization_details.pre_auth_number%type,
                                    v_added_by                in pat_authorization_details.added_by%type,
                                    v_hosp_seq_id             in tpa_hosp_info.hosp_seq_id%type,
                                    v_tpa_enrollment_id       in pat_authorization_details.tpa_enrollment_id%type,
                                    v_benefit_type            in pat_authorization_details.benifit_type%type,
                                    v_clinician_speciality    in pat_authorization_details.clinician_speciality%type,
                                    v_consultation_type       in pat_authorization_details.consultation_type%type,
                                    v_rows_processed          out NUMBER,
                                    v_provider_login           in varchar2,
                                    v_file_name               in varchar2 := null,
                                    v_date_of_lmp             in pat_authorization_details.lmp_date%TYPE,
                                    v_conception_type         in pat_authorization_details.conception_type%TYPE,
                                    v_system_of_med           in pat_authorization_details.system_of_medicine_type_id%TYPE,
                                    v_delvy_mode              in pat_authorization_details.delvry_mod_type%TYPE,
                                    v_success_enh_yn          in pat_authorization_details.success_enh_yn%TYPE----NEWLY ADDED FOR PREAUTH ENHANCEMENT SUBMIT OR NOT
                                    ) 
IS
  
cursor mem_cur is SELECT a.member_seq_id,
         a.tpa_enrollment_id,
         a.mem_name,
         nvl(a.mem_age,(months_between(sysdate,a.mem_dob)/12)) as mem_age,
         a.emirate_id,
         tii.ins_seq_id,
         tii.ins_comp_name,
         tii.ins_comp_code_number as payer_id,
         c.policy_seq_id,
         c.enrol_type_id,
         account_info_pkg.get_gen_desc(A.GENDER_GENERAL_TYPE_ID,'G') AS gender,
         (c.policy_number||'('||ip.product_cat_type_id||')') as policy_number,
         (d.group_name||'('||d.group_id||')') as corporate_name,
         d.group_reg_seq_id,
         c.effective_from_date as policy_start_date,
         c.effective_to_date as policy_end_date,
         nc.description as nationality,
         nvl(eb.sum_insured,0) - nvl(eb.utilised_sum_insured,0) AS ava_sum_insured,
         eb.sum_insured,
         a.vip_yn,
         reg.corp_vip_yn
  FROM   tpa_enr_policy_member A
  JOIN tpa_enr_policy_group B ON (A.policy_group_seq_id = B.policy_group_seq_id)
  JOIN tpa_enr_policy C ON (B.policy_seq_id = C.policy_seq_id )
  JOIN tpa_ins_product ip ON (ip.product_seq_id=c.product_seq_id)
  LEFT OUTER JOIN tpa_group_registration d ON (d.group_reg_seq_id=c.group_reg_seq_id)
  join tpa_ins_info tii on (c.ins_seq_id=tii.ins_seq_id)
  left outer join tpa_nationalities_code nc on (nc.nationality_id=a.nationality_id)
  LEFT OUTER JOIN tpa_enr_balance eb ON (b.policy_group_seq_id = eb.policy_group_seq_id)
  LEFT OUTER JOIN tpa_group_registration reg on(b.group_reg_seq_id = reg.group_reg_seq_id)
  WHERE a.tpa_enrollment_id=upper(trim(v_tpa_enrollment_id))
  AND ( SYSDATE BETWEEN C.effective_from_date AND C.effective_to_date+1)
  and  (a.mem_general_type_id != 'PFL' AND a.member_seq_id = eb.member_seq_id OR eb.member_seq_id IS NULL OR a.member_seq_id IS NULL)
  and a.status_general_type_id IN ('POA','POC')
  AND b.status_general_type_id IN ('POA','POC')
  AND C.COMPLETED_YN='Y'
  and B.DELETED_YN='N'
  AND A.DELETED_YN='N';

mem_rec           mem_cur%rowtype; 

cursor prov_cur is select hi.hosp_seq_id,hi.hosp_name,
hi.empanel_number,
ha.city_type_id,
ha.state_type_id,
ha.country_id,
ha.address_1,
ha.address_2,
ha.address_3,
ha.pin_code
from app.tpa_hosp_info hi 
left outer join app.tpa_hosp_address ha on (hi.hosp_seq_id = ha.hosp_seq_id) 
where hi.hosp_seq_id = v_hosp_seq_id;

prov_rec     prov_cur%rowtype;

v_consultation_type1  pat_authorization_details.consultation_type%type; 
--l_benifit_type        VARCHAR2(100);
v_act_cnt             NUMBER;

CURSOR act_dtl IS
SELECT SUM(NVL(pa.gross_amount,0)) as tot_gross_amount
      ,SUM(NVL(pa.discount_amount,0)) as tot_discount_amount
      ,SUM(NVL(pa.disc_gross_amount,0)) as tot_disc_gross_amount
      ,SUM(NVL(pa.patient_share_amount,0)) as tot_patient_share_amount
      ,SUM(NVL(pa.net_amount,0)) as tot_net_amount
      ,SUM(NVL(pa.allowed_amount,0)) as tot_allowed_amount
      ,SUM(NVL(pa.approved_amount,0)) as tot_approved_amount
      ,SUM(NVL(pa.ucr, 0))            as tot_ucr_amount
 FROM pat_activity_details pa
WHERE pa.Pat_Auth_Seq_Id=v_pre_auth_seq_id;

rec_act_dtl                act_dtl%ROWTYPE;

CURSOR pat_diag_cur IS
  SELECT count(1) 
  FROM diagnosys_details dd
  WHERE dd.pat_auth_seq_id= v_pre_auth_seq_id;

v_diag_count         NUMBER;

----********
CURSOR icd_benefit_cur(v_diagnosys_code VARCHAR2) IS
  Select ic.benefit_type
  From tpa_icd10_master_details ic
  Where ic.icd_code = upper(v_diagnosys_code);

CURSOR pat_icd_cur IS
  Select d.diagnosys_code, p.benifit_type
  From diagnosys_details d
  Join pat_authorization_details p on (p.pat_auth_seq_id = d.pat_auth_seq_id)
  Where d.pat_auth_seq_id = v_pre_auth_seq_id
  And d.primary_ailment_yn = 'Y';
  
CURSOR icd_cur IS
 Select count(1)
 From diagnosys_details d
 Where d.pat_auth_seq_id = v_pre_auth_seq_id
 And d.primary_ailment_yn = 'Y';

  pat_icd_rec          pat_icd_cur%ROWTYPE;
  v_icd_benefit        icd_benefit_cur%ROWTYPE; 
  v_icd_count          NUMBER;

----*********NEWLY ADDED PREAUTH ENHANCEMENT******
CURSOR enhance_pat_cur
IS
SELECT count(1)
FROM app.pat_authorization_details a 
WHERE a.pat_auth_seq_id = v_pre_auth_seq_id
AND a.parent_pat_auth_seq_id IS NOT NULL 
AND a.parent_pat_auth_seq_id != 0;

v_enhance_cnt        NUMBER(4);

CURSOR parent_pat_cur
IS
SELECT a.parent_pat_auth_seq_id
FROM app.pat_authorization_details a
WHERE a.pat_auth_seq_id = v_pre_auth_seq_id;

v_parnt_pat_rec      parent_pat_cur%ROWTYPE;   

-------

BEGIN
  
  OPEN pat_diag_cur;
  FETCH pat_diag_cur INTO v_diag_count;
  CLOSE pat_diag_cur;
  
  IF v_diag_count<1 THEN
    RAISE_APPLICATION_ERROR(-20380,'Please add atleast one Diagnosis');
  END IF;
  
  --ICD
  OPEN icd_cur;
  FETCH icd_cur INTO v_icd_count;
  CLOSE icd_cur;
      
  IF v_icd_count = 0 THEN
    RAISE_APPLICATION_ERROR(-20923,'Primary ICD required to complete the preauth/ claim.');
  END IF;
      
  OPEN pat_icd_cur;
  FETCH pat_icd_cur INTO pat_icd_rec;
  CLOSE pat_icd_cur;
      
  OPEN icd_benefit_cur(pat_icd_rec.diagnosys_code);
  FETCH icd_benefit_cur INTO v_icd_benefit;
  CLOSE icd_benefit_cur;
      
  IF v_icd_benefit.benefit_type = 'DNTL' OR pat_icd_rec.benifit_type = 'DNTL' THEN
    IF pat_icd_rec.benifit_type != NVL(v_icd_benefit.benefit_type, 'NA') THEN
      RAISE_APPLICATION_ERROR(-20323,'Ailment does not belogs to the selected benefit type, please select appropriate benefit type!');
    END IF;
  END IF;
  --END ICD
  
  OPEN  mem_cur;
  FETCH mem_cur INTO mem_rec;
  CLOSE mem_cur;
  
  open  prov_cur;
  fetch prov_cur into prov_rec;
  close prov_cur;
 
------- 
  OPEN  enhance_pat_cur;
  FETCH enhance_pat_cur INTO v_enhance_cnt;
  CLOSE enhance_pat_cur;


IF   v_enhance_cnt = 0 THEN 

 save_pat_details_app_level(v_pre_auth_seq_id,           
                             null,
                            sysdate,
                            v_discharge_date,             
                            null,
                            v_hospitalization_date,      
                            v_member_seq_id ,             
                            trim(v_tpa_enrollment_id),
                            v_pre_auth_number,
                            null,              
                            mem_rec.mem_name,
                            mem_rec.mem_age,
                            mem_rec.ins_seq_id,
                            v_hosp_seq_id,
                            mem_rec.policy_seq_id,
                            mem_rec.emirate_id,
                            v_encounter_type_id,
                            null,          
                            v_encounter_start_type,
                            null,
                            null,       
                            1, --Default User System                 
                            v_clinician_id,         
                            v_system_of_med ,
                            'CLN',
                            /*'MID'*/case when mem_rec.vip_yn='Y' or NVL(mem_rec.corp_vip_yn,'CVN')='CVY' then 'HIG' else 'MID' END,
                            'Y',
                            prov_rec.hosp_name,
                            prov_rec.empanel_number,
                            prov_rec.city_type_id,
                            prov_rec.state_type_id,
                            prov_rec.country_id,
                            prov_rec.address_1||prov_rec.address_2||prov_rec.address_3,
                            prov_rec.pin_code,
                            null,
                            v_benefit_type,
                            null,
                            null,
                            null,
                            null,
                            'PAT',
                            'QAR',
                            v_clinician_name,
                            mem_rec.ava_sum_insured,
                            null,
                            null,
                            null,
                            null,
                            null,
                            null,
                            null,
                            v_rows_processed,
                            v_past_history ,
                            v_duration_above_illness ,
                            v_duration_above_illness_time ,
                            v_since_when              ,
                            v_since_when_time,
                            v_clinician_speciality,
                            v_consultation_type,
                            v_presenting_complaints,
                            v_provider_login,
                            v_file_name,
                            v_date_of_lmp,
                            v_conception_type,
                            NULL
                            );
                            
ELSE
  
       OPEN   parent_pat_cur;
       FETCH  parent_pat_cur INTO v_parnt_pat_rec;
       CLOSE  parent_pat_cur;
       
 save_pat_details_app_level(v_pre_auth_seq_id,           
                            v_parnt_pat_rec.parent_pat_auth_seq_id,
                            sysdate,
                            v_discharge_date,             
                            null,
                            v_hospitalization_date,      
                            v_member_seq_id ,             
                            trim(v_tpa_enrollment_id),
                            v_pre_auth_number,
                            null,              
                            mem_rec.mem_name,
                            mem_rec.mem_age,
                            mem_rec.ins_seq_id,
                            v_hosp_seq_id,
                            mem_rec.policy_seq_id,
                            mem_rec.emirate_id,
                            v_encounter_type_id,
                            null,          
                            v_encounter_start_type,
                            null,
                            null,       
                            1, --Default User System                 
                            v_clinician_id,         
                            v_system_of_med ,
                            'CLN',
                            /*'MID'*/case when mem_rec.vip_yn='Y'  or NVL(mem_rec.corp_vip_yn,'CVN')='CVY' then 'HIG' else 'MID' END,
                            'Y',
                            prov_rec.hosp_name,
                            prov_rec.empanel_number,
                            prov_rec.city_type_id,
                            prov_rec.state_type_id,
                            prov_rec.country_id,
                            prov_rec.address_1||prov_rec.address_2||prov_rec.address_3,
                            prov_rec.pin_code,
                            null,
                            v_benefit_type,
                            null,
                            null,
                            null,
                            null,
                            'ENH',
                            'QAR',
                            v_clinician_name,
                            mem_rec.ava_sum_insured,
                            null,
                            null,
                            null,
                            null,
                            null,
                            null,
                            null,
                            v_rows_processed,
                            v_past_history ,
                            v_duration_above_illness ,
                            v_duration_above_illness_time ,
                            v_since_when              ,
                            v_since_when_time,
                            v_clinician_speciality,
                            v_consultation_type,
                            v_presenting_complaints,
                            'N'/*v_provider_login*/,-----need to change  pass N(HARD CODED)
                            v_file_name,
                            v_date_of_lmp,
                            v_conception_type,
                            v_success_enh_yn
                            );
                            
END IF;                             


end save_pat_online_intimation;
--================================================================================================
PROCEDURE select_pat_intimation_details(v_pat_auth_seq_id       IN pat_authorization_details.pat_auth_seq_id%type,
                                        v_result_set            OUT SYS_REFCURSOR) IS

BEGIN

  OPEN v_result_set FOR
       SELECT  id.pat_auth_seq_id,
           id.pre_auth_number,
           c.tpa_enrollment_id,
           c.member_seq_id,
           teg.insured_name,
           c.mem_dob,
           decode(c.gender_general_type_id, 'mal', 'male', 'female') as gender,
           id.hospitalization_date,
           id.discharge_date,
           id.clinician_id,
           hp.contact_name as clinician_name, 
           hp.speciality_id  as clinician_speciality,
           id.presenting_complaints,
           hp.consult_gen_type as consultation,
           id.benifit_type,
           id.since_when,
           id.since_when_time,
           id.duration_above_illness,
           id.duration_above_illness_time,
           id.system_of_medicine_type_id,
           id.encounter_type_id

      FROM pat_authorization_details id
      join tpa_enr_policy_member c on (c.member_seq_id = id.member_seq_id)
      left outer join app.tpa_enr_policy_group teg on (c.policy_group_seq_id = teg.policy_group_seq_id)
      left outer join tpa_hosp_professionals hp on (hp.professional_id=id.clinician_id)
     where id.pat_auth_seq_id = v_pat_auth_seq_id;
     
END select_pat_intimation_details;
---========================================================================
PROCEDURE add_consumable_details(v_CONSUMABLE_SEQ_ID     IN out tpa_consumable_details. CONSUMABLE_SEQ_ID %type,
                                 v_PAT_INTIMATION_SEQ_ID IN tpa_consumable_details. PAT_INTIMATION_SEQ_ID %type,
                                 v_ACTIVITY_SEQ_ID       IN tpa_consumable_details. ACTIVITY_SEQ_ID %type,
                                 v_ACTIVITY_CODE         IN tpa_consumable_details. ACTIVITY_CODE %type,
                                 v_UNIT_PRICE            IN tpa_consumable_details. UNIT_PRICE %type,
                                 v_QUANTITY              IN tpa_consumable_details. QUANTITY %type,
                                 v_GROSS                 IN tpa_consumable_details. GROSS %type,
                                 v_DISCOUNT              IN tpa_consumable_details. DISCOUNT %type,
                                 v_DISCOUNTED_GROSS      IN tpa_consumable_details. DISCOUNTED_GROSS %type,
                                 v_PATIENT_SHARE         IN tpa_consumable_details. PATIENT_SHARE %type,
                                 v_NET_AMOUNT            IN tpa_consumable_details. NET_AMOUNT %type,
                                 v_ADDED_BY              IN tpa_consumable_details. ADDED_BY %type,
                                 v_rows_processed        OUT NUMBER) IS

BEGIN

  IF nvl(v_CONSUMABLE_SEQ_ID, 0) = 0 THEN
    INSERT INTO tpa_consumable_details
      (CONSUMABLE_SEQ_ID,
       PAT_INTIMATION_SEQ_ID,
       ACTIVITY_SEQ_ID,
       ACTIVITY_CODE,
       UNIT_PRICE,
       QUANTITY,
       GROSS,
       DISCOUNT,
       DISCOUNTED_GROSS,
       PATIENT_SHARE,
       NET_AMOUNT,
       ADDED_BY,
       ADDED_DATE,
       SERVICE_NAME)
    VALUES
      (tpa_consumable_details_seq.nextval,
       v_PAT_INTIMATION_SEQ_ID,
       v_ACTIVITY_SEQ_ID,
       v_ACTIVITY_CODE,
       v_UNIT_PRICE,
       v_QUANTITY,
       v_GROSS,
       v_DISCOUNT,
       v_DISCOUNTED_GROSS,
       v_PATIENT_SHARE,
       v_NET_AMOUNT,
       v_ADDED_BY,
       sysdate,
       'CONSUMABLES')
    RETURNING CONSUMABLE_SEQ_ID INTO v_CONSUMABLE_SEQ_ID;
  
  ELSE
    update tpa_consumable_details
       set PAT_INTIMATION_SEQ_ID = v_PAT_INTIMATION_SEQ_ID,
           ACTIVITY_SEQ_ID       = v_ACTIVITY_SEQ_ID,
           ACTIVITY_CODE         = v_ACTIVITY_CODE,
           UNIT_PRICE            = v_UNIT_PRICE,
           QUANTITY              = v_QUANTITY,
           GROSS                 = v_GROSS,
           DISCOUNT              = v_DISCOUNT,
           DISCOUNTED_GROSS      = v_DISCOUNTED_GROSS,
           PATIENT_SHARE         = v_PATIENT_SHARE,
           NET_AMOUNT            = v_NET_AMOUNT,
           UPDATED_BY            = v_ADDED_BY,
           UPDATED_DATE          = sysdate;
  
  END IF;
  v_rows_processed := SQL%ROWCOUNT;
  COMMIT;
END add_consumable_details;
--==================================================
PROCEDURE get_consumable_details(v_pat_intimation_seq_id IN tpa_hosp_info.hosp_seq_id%type,
                                 v_result_set            OUT SYS_REFCURSOR) IS

BEGIN

  OPEN v_result_set FOR
    SELECT id.*
      FROM tpa_consumable_details id
      where id.pat_intimation_seq_id = v_pat_intimation_seq_id;

END get_consumable_details;
--===========================================================================================================
PROCEDURE select_activity_code(v_hosp_seq_id               IN tpa_hosp_info.hosp_seq_id%TYPE,
                               v_tpa_enrollment_id         IN tpa_enr_policy_member.tpa_enrollment_id%type,
                               v_activity_code             IN NUMBER,
                               v_activity_date             IN pat_activity_details.start_date%TYPE,
                               v_flag                      IN OUT VARCHAR2,
                               v_flag1                     IN VARCHAR2,                     
                               v_tariff_result             OUT SYS_REFCURSOR)
  
IS

CURSOR mem_cur IS
SELECT tip.product_cat_type_id,tep.ins_seq_id,tep.group_reg_seq_id, tep.policy_seq_id,tep.tariff_type_id
FROM app.tpa_enr_policy_member tem
JOIN app.tpa_enr_policy_group teg ON (tem.policy_group_seq_id = teg.policy_group_seq_id)
JOIN tpa_enr_policy tep ON (teg.policy_seq_id=tep.policy_seq_id)
JOIN tpa_ins_product tip ON (tep.product_seq_id=tip.product_seq_id)
WHERE tem.tpa_enrollment_id = trim(v_tpa_enrollment_id)
AND TO_DATE(SYSDATE, 'DD/MM/RRRR') BETWEEN TO_DATE(tep.effective_from_date, 'DD/MM/RRRR') AND TO_DATE(tep.effective_to_date, 'DD/MM/RRRR');

mem_rec             mem_cur%ROWTYPE;

/*
CURSOR provider_network IS 
SELECT i.cn_yn,i.gn_yn,i.sn_yn,i.bn_yn,i.wn_yn,i.primary_network FROM tpa_hosp_info i where i.hosp_seq_id=v_hosp_seq_id;
*/
CURSOR provider_network(v_product_net_type varchar2) IS
SELECT i.primary_network, ny.network_type, ny.network_yn, gc.sort_no
  FROM tpa_hosp_info i, app.tpa_hosp_network ny, app.tpa_general_code gc
 where ny.hosp_seq_id = i.hosp_seq_id
   and gc.general_type_id = ny.network_type
   and gc.header_type = 'PROVIDER_NETWORK'
   and ny.network_yn = 'Y'
   and i.hosp_seq_id = v_hosp_seq_id
   and gc.sort_no =
       (SELECT min(gc.sort_no)
          FROM tpa_hosp_info        i,
               app.tpa_hosp_network ny,
               app.tpa_general_code gc
         where ny.hosp_seq_id = i.hosp_seq_id
           and gc.general_type_id = ny.network_type
           and gc.header_type = 'PROVIDER_NETWORK'
           and ny.network_yn = 'Y'
           and i.hosp_seq_id = v_hosp_seq_id 
           and gc.sort_no >=
               (SELECT min(gc.sort_no)
                  FROM tpa_hosp_info        i,
                       app.tpa_hosp_network ny,
                       app.tpa_general_code gc
                 where ny.hosp_seq_id = i.hosp_seq_id
                   and gc.general_type_id = ny.network_type
                   and gc.header_type = 'PROVIDER_NETWORK'
                   and i.hosp_seq_id = v_hosp_seq_id
                   and gc.general_type_id = v_product_net_type))
 order by gc.sort_no;


CURSOR pharmacy_cur IS 
SELECT i.disc_percent FROM app.tpa_hosp_tariff_details i where i.acitivity_type_seq_id=5 and i.hosp_seq_id=v_hosp_seq_id;

CURSOR tooth_cur IS
  SELECT t.tooth_code
  FROM tpa_tooth_number t;

tooth_rec tooth_cur%ROWTYPE;

provider_rec   provider_network%rowtype;
v_product_network_type    varchar2(20);
v_count   number(10);
v_tariff_ins_seq_id           number(10);
v_tariff_count                number(10);
v_tpa_ins_seq_id              number(10);
v_activity_type_seq_id        number(10);
v_pharmacy_rec                number(10);


BEGIN
  
 OPEN tooth_cur;
 FETCH tooth_cur INTO tooth_rec;
 CLOSE tooth_cur;

 IF v_flag IS NULL AND v_flag1 = 'activityCodeDesc' THEN
   v_flag := 'TAR';
 END IF;
 

 IF v_flag IS NULL AND v_flag1 = 'activityCodeDesc' THEN
   v_flag := 'TAR';
 END IF;
 
 OPEN mem_cur;
 FETCH mem_cur INTO mem_rec;
 CLOSE mem_cur;
 
 OPEN provider_network(mem_rec.product_cat_type_id);
 FETCH provider_network INTO provider_rec;
 CLOSE provider_network;
 
 
 IF mem_rec.Ins_Seq_Id IS NOT NULL THEN 
   SELECT COUNT(1) INTO v_tariff_count from tpa_hosp_tariff_details d 
   where d.ins_seq_id=mem_rec.Ins_Seq_Id and d.hosp_seq_id=v_hosp_seq_id;
 END IF; 
 
 select ii.ins_seq_id into v_tpa_ins_seq_id from app.tpa_ins_info ii where ii.ins_comp_code_number='ALK01'; 
   IF v_tariff_count>0 THEN 
     v_tariff_ins_seq_id:=mem_rec.Ins_Seq_Id;
   ELSE 
     v_tariff_ins_seq_id:=v_tpa_ins_seq_id;
   END IF;   
   
    v_product_network_type:=provider_rec.network_type; 
   
   IF v_flag1 = 'drugDesc' THEN
     /*if length(v_activity_code)>=15 then*/
       v_activity_type_seq_id:=5;
     /*end if;*/
   END IF;
   
   if v_activity_type_seq_id=5 then
    select count(1) into v_count from tpa_pharmacy_master_details tamd
    JOIN tpa_activity_type_codes tatc ON (tamd.activity_type_seq_id=tatc.activity_type_seq_id)
    WHERE tamd.act_mas_dtl_seq_id=upper(v_activity_code)
    AND tamd.start_date <= v_activity_date and nvl(tamd.end_date,v_activity_date) >=v_activity_date; 
     
   else
     IF v_flag = 'ACT' THEN
        select count(1) into v_count           
        from tpa_activity_master_details tamd
        JOIN tpa_activity_type_codes tatc ON (tamd.activity_type_seq_id=tatc.activity_type_seq_id)
        JOIN tpa_hosp_tariff_details thtd ON (tamd.act_mas_dtl_seq_id=thtd.activity_seq_id)
        WHERE thtd.hosp_seq_id=v_hosp_seq_id
        AND thtd.ins_seq_id=v_tariff_ins_seq_id
        --AND thtd.network_type=v_product_network_type
        AND v_activity_date BETWEEN  thtd.start_date AND NVL(thtd.end_date,v_activity_date)
        AND tamd.act_mas_dtl_seq_id= v_activity_code;
     ELSE
       select count(1) into v_count           
        from tpa_activity_master_details tamd
        JOIN tpa_activity_type_codes tatc ON (tamd.activity_type_seq_id=tatc.activity_type_seq_id)
        JOIN tpa_hosp_tariff_details thtd ON (tamd.act_mas_dtl_seq_id=thtd.activity_seq_id)
        WHERE thtd.hosp_seq_id=v_hosp_seq_id
        AND thtd.ins_seq_id=v_tariff_ins_seq_id
        --AND thtd.network_type=v_product_network_type
        AND v_activity_date BETWEEN  thtd.start_date AND NVL(thtd.end_date,v_activity_date)
        AND thtd.hosp_tariff_seq_id = v_activity_code;
     END IF;
   end if;
   
   
   if v_count=0 then
     raise_application_error (-20274,'given activity code is not in valid period');
   end if;
   if v_activity_type_seq_id=5 then 
     open pharmacy_cur ; 
     fetch pharmacy_cur into v_pharmacy_rec ;
     close pharmacy_cur;
     
     OPEN v_tariff_result FOR 
     select 
           nvl(tamd.unit_price,0) as gross_amount ,
           tamd.unit_price*(nvl(v_pharmacy_rec,0)/100) as disc_amount,
           null as unit_discount,
           tamd.unit_price-tamd.unit_price*(nvl(v_pharmacy_rec,0)/100) as disc_gross_amount,
           null as bundle_id,
           null as package_id,
		   '-' as internal_code,
           tamd.unit_price,
           tamd.package_price,
           tamd.granular_unit,
           tamd.act_mas_dtl_seq_id as activity_seq_id,
           tamd.activity_code,
           tamd.activity_description,
           tatc.activity_type_seq_id,
           tatc.activity_type_id,
           v_pharmacy_rec as disc_perc,
           NVL(d.tooth_no_required, 'N') as tooth_req_yn,
           tooth_rec.tooth_code as tooth_no
    from app.tpa_pharmacy_master_details tamd
    JOIN tpa_activity_type_codes tatc ON (tamd.activity_type_seq_id=tatc.activity_type_seq_id)
    LEFT JOIN dental_rule_tab d ON (d.cdt_code = tamd.activity_code)
    WHERE tamd.act_mas_dtl_seq_id= v_activity_code;
    --AND tamd.start_date <= v_activity_date and nvl(tamd.end_date,v_activity_date) >=v_activity_date;
   else
     IF v_flag = 'TAR' OR v_flag IS NULL THEN
      if v_count>0 then
       OPEN v_tariff_result FOR 
               select 
               nvl(thtd.gross_amount,0) as gross_amount,
               --nvl(thtd.disc_amount,0) as disc_amount,
               --thtd.disc_amount as unit_discount,
               --thtd.gross_amount- thtd.disc_amount as disc_gross_amount,
               case when thtd.service_seq_id = 7 then NVL((thtd.gross_amount * thtd.disc_percent / 100 ),0) else case when thtd.service_seq_id not in (7, 14) then nvl(thtd.disc_amount,0) end end as disc_amount,
               case when thtd.service_seq_id = 7 then NVL((thtd.gross_amount * thtd.disc_percent / 100 ),0) else case when thtd.service_seq_id not in (7, 14) then thtd.disc_amount end end as unit_discount,
               case when thtd.service_seq_id = 7 then NVL((thtd.gross_amount - (thtd.gross_amount * thtd.disc_percent / 100 )),0) else case when thtd.service_seq_id not in (7, 14) then thtd.gross_amount - thtd.disc_amount end end as disc_gross_amount,
               thtd.bundle_id,
               thtd.package_id,
               nvl(thtd.internal_code, '-') as internal_code,
               tamd.unit_price,
               tamd.package_price,
               tamd.granular_unit,
               tamd.act_mas_dtl_seq_id as activity_seq_id,
               tamd.activity_code,
               tamd.short_description,
               tatc.activity_type_seq_id,
               tatc.activity_type_id,
               v_pharmacy_rec as disc_perc ,
               tamd.activity_description,
               tamd.activity_code,
               NVL(d.tooth_no_required, 'N') as tooth_req_yn,
               tooth_rec.tooth_code as tooth_no,
               thtd.internal_desc
        from tpa_activity_master_details tamd
        JOIN tpa_activity_type_codes tatc ON (tamd.activity_type_seq_id=tatc.activity_type_seq_id)
        left outer JOIN tpa_hosp_tariff_details thtd ON (tamd.act_mas_dtl_seq_id=thtd.activity_seq_id)
        LEFT JOIN dental_rule_tab d ON (d.cdt_code = tamd.activity_code)
        WHERE thtd.hosp_seq_id=v_hosp_seq_id
        AND thtd.ins_seq_id=v_tariff_ins_seq_id
        --AND thtd.network_type=v_product_network_type--pat_rec.product_cat_type_id
       -- AND v_activity_date BETWEEN  thtd.start_date AND NVL(thtd.end_date,v_activity_date)
        AND thtd.hosp_tariff_seq_id = v_activity_code;
     END IF;
   else
     IF v_flag = 'ACT' THEN
          OPEN v_tariff_result FOR 
             select 
             0 as gross_amount,
             0 as disc_amount,
             null as unit_discount,
             null as disc_gross_amount,
             null as bundle_id,
             null as package_id,
             '-' as internal_code,
             tamd.unit_price,
             tamd.package_price,
             tamd.granular_unit,
             tamd.act_mas_dtl_seq_id as activity_seq_id,
             tamd.activity_code,
             tamd.activity_description,
             tatc.activity_type_seq_id,
             tatc.activity_type_id,
             null as disc_perc ,
             tamd.short_description as    activity_description,
             tamd.activity_code,
             NVL(d.tooth_no_required, 'N') as tooth_req_yn,
             tooth_rec.tooth_code as tooth_no
      from tpa_activity_master_details tamd
      JOIN tpa_activity_type_codes tatc ON (tamd.activity_type_seq_id=tatc.activity_type_seq_id)
      ---left outer JOIN tpa_hosp_tariff_details thtd ON (tamd.act_mas_dtl_seq_id=thtd.activity_seq_id)
      LEFT JOIN dental_rule_tab d ON (d.cdt_code = tamd.activity_code)
      WHERE tamd.act_mas_dtl_seq_id= v_activity_code;
   END IF;
  end if;
 end if;
  
END select_activity_code;
---===========================================================================================
PROCEDURE select_activity_list (
    v_act_code                 IN OUT tpa_activity_master_details.activity_code%TYPE,
    v_description              IN OUT tpa_activity_master_details.activity_description%TYPE,
    v_search_flag              IN VARCHAR2,
    v_hosp_seq_id              IN tpa_hosp_info.hosp_seq_id%TYPE,
    v_tpa_enrollment_id        IN tpa_enr_policy_member.tpa_enrollment_id%type,
    v_internal_code            IN OUT tpa_hosp_tariff_details.internal_code%TYPE,
    v_sort_var                 IN OUT VARCHAR2 ,
    v_sort_order               IN OUT VARCHAR2,
    v_start_num                IN OUT NUMBER  ,
    v_end_num                  IN OUT NUMBER  ,
    v_result_set               OUT SYS_REFCURSOR,
    v_flag                     IN VARCHAR2
  )
  IS
    v_str                      VARCHAR2(2000);
    l_act_code                 VARCHAR2(30);
    l_description              VARCHAR2(2000);
    l_internal_code            VARCHAR2(30);
    
 Cursor tariff_mem_cur is 
SELECT tip.product_cat_type_id,tep.ins_seq_id,tep.group_reg_seq_id, tep.policy_seq_id,tep.tariff_type_id
FROM app.tpa_enr_policy_member tem
JOIN app.tpa_enr_policy_group teg ON (tem.policy_group_seq_id = teg.policy_group_seq_id)
JOIN tpa_enr_policy tep ON (teg.policy_seq_id=tep.policy_seq_id)
JOIN tpa_ins_product tip ON (tep.product_seq_id=tip.product_seq_id)
WHERE tem.tpa_enrollment_id = trim(v_tpa_enrollment_id)
AND TO_DATE(SYSDATE, 'DD/MM/RRRR') BETWEEN TO_DATE(tep.effective_from_date, 'DD/MM/RRRR') AND TO_DATE(tep.effective_to_date, 'DD/MM/RRRR');
  
      v_ins_seq_id           number;
      v_tariff_ins_seq_id    number(10);
      v_tariff_count         number(10);
      v_tpa_ins_seq_id       number(10);


mem_rec             tariff_mem_cur%ROWTYPE;

/*
CURSOR provider_network IS 
SELECT i.cn_yn,i.gn_yn,i.sn_yn,i.bn_yn,i.wn_yn,i.primary_network FROM tpa_hosp_info i where i.hosp_seq_id=v_hosp_seq_id;
*/
CURSOR provider_network(v_product_net_type varchar2) IS
SELECT i.primary_network, ny.network_type, ny.network_yn, gc.sort_no
  FROM tpa_hosp_info i, app.tpa_hosp_network ny, app.tpa_general_code gc
 where ny.hosp_seq_id = i.hosp_seq_id
   and gc.general_type_id = ny.network_type
   and gc.header_type = 'PROVIDER_NETWORK'
   and ny.network_yn = 'Y'
   and i.hosp_seq_id = v_hosp_seq_id
   and gc.sort_no =
       (SELECT min(gc.sort_no)
          FROM tpa_hosp_info        i,
               app.tpa_hosp_network ny,
               app.tpa_general_code gc
         where ny.hosp_seq_id = i.hosp_seq_id
           and gc.general_type_id = ny.network_type
           and gc.header_type = 'PROVIDER_NETWORK'
           and ny.network_yn = 'Y'
           and i.hosp_seq_id = v_hosp_seq_id
           and gc.sort_no >=
               (SELECT min(gc.sort_no)
                  FROM tpa_hosp_info        i,
                       app.tpa_hosp_network ny,
                       app.tpa_general_code gc
                 where ny.hosp_seq_id = i.hosp_seq_id
                   and gc.general_type_id = ny.network_type
                   and gc.header_type = 'PROVIDER_NETWORK'
                   and i.hosp_seq_id = v_hosp_seq_id
                   and gc.general_type_id = v_product_net_type))
 order by gc.sort_no;

provider_rec   provider_network%rowtype;

v_product_network_type   VARCHAR2(100);
  
  
  BEGIN
    l_act_code := v_act_code;
    l_description := v_description;
    
    v_sort_var   := CASE WHEN v_sort_var IS NULL THEN 'ACTIVITY_CODE' ELSE v_sort_var END;
    v_sort_order := CASE WHEN v_sort_order IS NULL THEN 'ASC' ELSE v_sort_order END;
    v_start_num  := CASE WHEN v_start_num IS NULL THEN 1 ELSE v_start_num END;
    v_end_num    := CASE WHEN v_end_num IS NULL THEN 70000 ELSE v_end_num END;

    v_act_code         := CASE WHEN v_act_code IS NOT NULL THEN UPPER(v_act_code)||'%' ELSE v_act_code END;
    v_description      := CASE WHEN v_description IS NOT NULL THEN '%'||UPPER(v_description)||'%' ELSE v_description END;
    v_internal_code    := CASE WHEN v_internal_code IS NOT NULL THEN UPPER(v_internal_code)||'%' ELSE v_internal_code END;
   
   IF v_search_flag='ACT' THEN
      v_str :=
         ' SELECT
           md.act_mas_dtl_seq_id ,md.activity_code ,md.activity_description, null as internal_code , d.tooth_no_required as tooth_req_yn, null as requested_amt
           ,NVL2(ra.activity_code,1,0) rcnt
           FROM tpa_activity_master_details md
           LEFT JOIN tpa_activity_details ta on (ta.activity_code = md.activity_code)
           LEFT JOIN tpa_hosp_tariff_details t on (t.activity_seq_id = ta.activity_seq_id)
		   LEFT JOIN dental_rule_tab d ON (d.cdt_code = md.activity_code)
       LEFT JOIN tpa_restrict_activity_tab ra ON (md.activity_code=ra.activity_code)
           WHERE length(md.activity_code)<=15
           AND md.service_seq_id NOT IN (14/*, 7*/) 
           AND (( :v_act_code IS NULL OR md.activity_code LIKE :v_act_code ) 
           AND ( :v_description IS NULL OR md.activity_description LIKE :v_description )) ';
           --OR (:v_internal_code IS NULL OR UPPER(t.internal_code ) LIKE :v_internal_code ) ';
         
   ELSIF v_search_flag='TAR' THEN
     
     OPEN tariff_mem_cur;
     FETCH tariff_mem_cur INTO mem_rec;
     close tariff_mem_cur;
    
    OPEN provider_network(mem_rec.product_cat_type_id);
    FETCH provider_network INTO provider_rec;
    CLOSE provider_network;
     
   IF mem_rec.ins_seq_id IS NOT NULL THEN 

     SELECT COUNT(1) INTO v_tariff_count from tpa_hosp_tariff_details d 
     where d.ins_seq_id=mem_rec.ins_seq_id and d.hosp_seq_id=v_hosp_seq_id;
   END IF; 
     
   select ii.ins_seq_id into v_tpa_ins_seq_id from app.tpa_ins_info ii where ii.ins_comp_code_number='ALK01'; 
   IF v_tariff_count>0 THEN 
     v_tariff_ins_seq_id:=mem_rec.ins_seq_id;
   ELSE 
     v_tariff_ins_seq_id:=v_tpa_ins_seq_id;
   END IF;
   
   IF mem_rec.tariff_type_id='HSPL' THEN
     
   v_product_network_type:=provider_rec.network_type;
   
   END IF;
     
     v_str := 
      'SELECT DISTINCT * FROM (SELECT
         d.hosp_tariff_seq_id, md.act_mas_dtl_seq_id ,md.activity_code ,d.hosp_act_desc as activity_description, nvl(d.internal_code, ''-'') as internal_code,
		 dt.tooth_no_required as tooth_req_yn, (d.gross_amount) as requested_amt 
         ,NVL2(ra.activity_code,1,0) rcnt
         FROM tpa_hosp_tariff_details d join tpa_activity_master_details md on (d.activity_seq_id=md.act_mas_dtl_seq_id)
         LEFT JOIN dental_rule_tab dt ON (dt.cdt_code = md.activity_code)
         LEFT JOIN tpa_restrict_activity_tab ra ON (md.activity_code=ra.activity_code)
         WHERE( UPPER(:v_act_code) IS NULL OR UPPER(md.activity_code) LIKE UPPER(:v_act_code) )
         AND ( UPPER(:v_description) IS NULL OR UPPER(d.hosp_act_desc) LIKE UPPER(:v_description) ) 
         AND ( UPPER(:v_internal_code) IS NULL OR UPPER(d.internal_code) LIKE UPPER(:v_internal_code))
         AND (d.ins_seq_id=:v_tariff_ins_seq_id)
         AND (d.hosp_seq_id=:v_hosp_seq_id)
         AND length(md.activity_code)<=15
         AND d.service_seq_id NOT IN (14)--7
         AND (d.network_type IN (select general_type_id
                                 FROM (select g.general_type_id, g.sort_no, dense_rank() over(order by g.sort_no) r
                                       from tpa_general_code g
                                       where g.header_type = ''PROVIDER_NETWORK''
                                      ) q
                                 WHERE  q.r >=(select sort_no from tpa_general_code where general_type_id = :v_product_network_type))))';

   END IF;
   IF V_search_flag = 'ACT' THEN
     v_str := 'SELECT * FROM
        (SELECT A.*, DENSE_RANK() OVER (ORDER BY '||v_sort_var||' '||v_sort_order||',ROWNUM) Q FROM (' ||v_str|| ') A )
         WHERE  Q>= :v_start_num  AND Q<= :v_end_num ';
   ELSE
    v_str := 'SELECT * FROM
      (SELECT A.*, DENSE_RANK() OVER (ORDER BY '||v_sort_var||' '||v_sort_order||',ROWNUM) Q FROM (' ||v_str|| ') A )
       WHERE  Q>= :v_start_num  AND Q<= :v_end_num ';
   END IF;
  
  IF V_search_flag='TAR' THEN
    OPEN v_result_set FOR v_str USING v_act_code, v_act_code, v_description, v_description ,v_internal_code, v_internal_code, v_tariff_ins_seq_id,v_hosp_seq_id,v_product_network_type, v_start_num, v_end_num;
  ELSIF V_search_flag = 'ACT' THEN
    OPEN v_result_set FOR v_str USING v_act_code, v_act_code, v_description , v_description, v_start_num, v_end_num;
  END IF;
 
  END select_activity_list;
----=======================================================================
PROCEDURE select_DDC_list (
    v_act_code                 IN OUT tpa_activity_master_details.activity_code%TYPE,
    v_description              IN OUT tpa_activity_master_details.activity_description%TYPE,
    v_search_flag              IN VARCHAR2,
    v_hosp_seq_id              IN tpa_hosp_info.hosp_seq_id%TYPE,
    v_tpa_enrollment_id         IN tpa_enr_policy_member.tpa_enrollment_id%type,
    v_sort_var                 IN OUT VARCHAR2 ,
    v_sort_order               IN OUT VARCHAR2,
    v_start_num                IN OUT NUMBER  ,
    v_end_num                  IN OUT NUMBER  ,
    v_result_set               OUT SYS_REFCURSOR
  )
  IS
  v_str                      VARCHAR2(2000);
  
  BEGIN
    
    v_sort_var   := CASE WHEN v_sort_var IS NULL THEN 'ACTIVITY_CODE' ELSE v_sort_var END;
    v_sort_order := CASE WHEN v_sort_order IS NULL THEN 'ASC' ELSE v_sort_order END;
    v_start_num  := CASE WHEN v_start_num IS NULL THEN 1 ELSE v_start_num END;
    v_end_num    := CASE WHEN v_end_num IS NULL THEN 70000 ELSE v_end_num END;

    v_act_code         := CASE WHEN v_act_code IS NOT NULL THEN UPPER(v_act_code)||'%' ELSE v_act_code END;
    v_description      := CASE WHEN v_description IS NOT NULL THEN '%'||UPPER(replace(v_description,' ','%'))||'%' ELSE v_description END;

 v_str := 
      'SELECT DISTINCT * FROM (SELECT md.act_mas_dtl_seq_id,
       md.activity_code,
       md.activity_description as activity_description,
       md.granular_unit
       FROM tpa_pharmacy_master_details md
       where /*md.activity_type_seq_id = 5 
       AND*/ (:v_act_code IS NULL OR md.activity_code LIKE :v_act_code )
       AND (:v_description IS NULL OR md.activity_description LIKE :v_description )
       )';
      
      
  v_str := 'SELECT * FROM
      (SELECT A.*, DENSE_RANK() OVER (ORDER BY '||v_sort_var||' '||v_sort_order||',ROWNUM) Q FROM (' ||v_str|| ') A )
       WHERE  Q>= :v_start_num  AND Q<= :v_end_num ';
 
    OPEN v_result_set FOR v_str USING v_act_code, v_act_code, v_description, v_description , v_start_num, v_end_num;
END select_DDC_list;
--===============================================================================
PROCEDURE save_activity_details(
    v_activity_dtl_seq_id     IN  pat_activity_details.activity_dtl_seq_id%TYPE,
    v_pat_auth_seq_id         IN  pat_activity_details.pat_auth_seq_id%TYPE,
    v_code                    IN  pat_activity_details.code%TYPE,
    v_quantity                IN  pat_activity_details.quantity%TYPE,
    v_gross_amount            IN  pat_activity_details.gross_amount%TYPE,
    v_discount_amount         IN  pat_activity_details.discount_amount%TYPE,
    v_disc_gross_amount       IN  pat_activity_details.disc_gross_amount%TYPE,
    v_net_amount              IN  pat_activity_details.net_amount%TYPE,
    v_start_date              IN  varchar2,
    v_allowed_yn              in  varchar2,
    v_clinician_id            in  pat_activity_details.clinician_id%type,
    v_added_by                IN  pat_activity_details.added_by%TYPE,
    v_activity_type_id        in  app.tpa_activity_type_codes.activity_type_id%type,
    v_internal_code           in  pat_activity_details.internal_code%TYPE,
	  v_tooth_no                in  pat_activity_details.tooth_no%TYPE,
    v_internal_desc           in  pat_activity_details.internal_desc%Type,
    v_override_yn             IN  pat_activity_details.override_yn%type,----
    v_override_remarks        IN  pat_activity_details.override_remarks%type,-----
    v_denial_code             IN  pat_activity_details.denial_code%type,
    v_denial_desc             IN  pat_activity_details.denial_desc%type,
    v_override_remarks_code     IN  pat_activity_details.override_remarks_code%type, --- added in override drop down list cr
    v_other_remarks           IN  pat_activity_details.other_remarks%type            --- added in override drop down list cr
)
 IS
 v_prod_pol_rule_seq_id       tpa_ins_prod_policy_rules.prod_policy_rule_seq_id%type;
 
 CURSOR master_cur IS
   SELECT *
   FROM Tpa_Activity_Master_Details m
   WHERE m.activity_code = UPPER(v_code);
   
 master_rec master_cur%ROWTYPE;
 
 CURSOR act_cur IS
  SELECT max(pad.s_no) max_sno
  FROM pat_activity_details pad
  WHERE pad.pat_auth_seq_id=v_pat_auth_seq_id;
  
  CURSOR pat_diag_cur IS
  SELECT count(1) 
  FROM diagnosys_details dd
  WHERE dd.pat_auth_seq_id=v_pat_auth_seq_id;
  

  CURSOR pat_cur IS
 SELECT pad.pat_auth_seq_id,
       pad.pat_batch_seq_id,
       pad.claim_seq_id,
       pad.member_seq_id,       
       pad.final_app_amount,
       pad.denial_reason,
       pad.completed_yn,
       pad.pat_enhanced_yn,
       pad.CONVERSION_RATE
  FROM pat_authorization_details pad
  WHERE pad.pat_auth_seq_id=v_pat_auth_seq_id;
 

  
 pat_rec              pat_cur%ROWTYPE;
 act_rec              act_cur%ROWTYPE;
 v_s_no               NUMBER;
 v_diag_count         NUMBER;
 
 v_copay_per          number:=0;
 v_rule_limit         number:=0;
 v_start_date1        date;
 v_tot_gross_amount  number:=0;
 v_tot_discount_amount  number:=0;
 v_tot_disc_gross_amount   number:=0;
 v_tariff_count            NUMBER;
BEGIN
   intx.prc_track_error(v_pat_auth_seq_id, 
                  'v_gross_amount: '||v_gross_amount||CHR(10)||
                  'v_discount_amount :'||v_discount_amount||CHR(10)||
                  'v_quantity :'||v_quantity||CHR(10)||
                  'PROCEDURE: '||'HOSP_DIAGNOSYS_PKG.SAVE_ACTIVITY_DETAILS',
                  'ACT'
                 );
  
  v_start_date1:=to_date(v_start_date,'DD/MM/YYYY');

OPEN master_cur;
FETCH master_cur INTO master_rec;
CLOSE master_cur;

IF v_pat_auth_seq_id IS NOT NULL THEN 
  OPEN pat_diag_cur;
  FETCH pat_diag_cur INTO v_diag_count;
  CLOSE pat_diag_cur;
 END IF;
  
  if v_pat_auth_seq_id is not null then
   OPEN pat_cur;
   FETCH pat_cur INTO pat_rec;
   CLOSE pat_cur;
  end if;
    
  IF v_diag_count<1 THEN
    RAISE_APPLICATION_ERROR(-20380,'Please add atleast one Diagnosis');
  END IF;
  
  --IF NVL(v_activity_dtl_seq_id,0)=0 THEN
    if v_pat_auth_seq_id is not null then
     OPEN act_cur;
     FETCH act_cur INTO act_rec;
     CLOSE act_cur;
    end if;
    v_s_no:=NVL(act_rec.max_sno,0)+1;
    
    SELECT COUNT(1) INTO v_tariff_count
    FROM TPA_IP_SERVICE_DETAILS S
    WHERE TRIM(UPPER(S.SERVICE_CODE)) = TRIM(UPPER(v_code));
    
    IF v_tariff_count = 0 THEN
      SELECT COUNT(1) INTO v_tariff_count
      FROM TPA_HOSP_TARIFF_DETAILS T
      WHERE T.HOSP_SEQ_ID = (SELECT P.HOSP_SEQ_ID
                             FROM PAT_AUTHORIZATION_DETAILS P
                             WHERE P.PAT_AUTH_SEQ_ID = v_pat_auth_seq_id
                            )
      AND ((v_start_date1 BETWEEN TO_DATE(T.START_DATE, 'DD/MM/RRRR') AND TO_DATE(NVL(T.END_DATE, SYSDATE), 'DD/MM/RRRR')) OR
           TO_DATE(T.START_DATE, 'DD/MM/RRRR') <= v_start_date1 AND T.END_DATE IS NULL)
      AND TRIM(UPPER(T.INTERNAL_CODE)) = TRIM(UPPER(v_internal_code));
      
      IF v_tariff_count = 0 THEN
        RAISE_APPLICATION_ERROR(-20274,'Tariff rates are not agreed for this item');
      END IF;
    END IF;
    
    INSERT INTO pat_activity_details(
                activity_dtl_seq_id,
                pat_auth_seq_id,
                code,
                quantity,      --4
                gross_amount,    -- 800
                unit_price,      --200
                discount_amount,  --2*4
                disc_gross_amount, --198*4
                net_amount,         --198*4
                added_by,
                added_date,
                start_date,
                allow_yn,
                clinician_id,
                unit_discount_amount,    --2,
                approvd_quantity,
                activity_type,
                service_type,
                activity_seq_id,
                internal_code,
                tooth_no,
                service_code,
                internal_desc,
                CONVERTED_ACITIVTY_AMT,
                override_yn,   ---NEWLY ADDED PREAUTH ENHANCEMENT
                override_remarks,---NEWLY ADDED PREAUTH ENHANCEMENT
                denial_code,---NEWLY ADDED PREAUTH ENHANCEMENT
                allowed_amount,----NEWLY ADDED PREAUTH ENHANCEMENT
                approved_amount,---NEWLY ADDED PREAUTH ENHANCEMENT
                activity_type_id,---NEWLY ADDED PREAUTH ENHANCEMENT
                denial_desc,
                override_remarks_code,   ---NEWLY ADDED OVERRIDER DROP DOWN LIST
                other_remarks            ---NEWLY ADDED OVERRIDER DROP DOWN LIST
                )
          VALUES (
                pat_activity_detail_seq.nextval,
                v_pat_auth_seq_id,
                CASE WHEN master_rec.act_mas_dtl_seq_id IS NOT NULL THEN UPPER(TRIM(v_code)) ELSE NULL END,
                v_quantity,
                v_gross_amount,
                v_gross_amount / v_quantity ,
                v_discount_amount,
                (v_gross_amount - v_discount_amount),
                (v_gross_amount - v_discount_amount),
                v_added_by,
                SYSDATE,
                v_start_date1,
                v_allowed_yn,
                v_clinician_id ,
                v_discount_amount / v_quantity,       ---added for provider login issue,
                v_quantity,
                master_rec.activity_type_seq_id,
                CASE WHEN master_rec.act_mas_dtl_seq_id IS NOT NULL THEN 'ACD' ELSE 'SCD' END,
                master_rec.act_mas_dtl_seq_id,
                v_internal_code,
                v_tooth_no,
                CASE WHEN master_rec.act_mas_dtl_seq_id IS NOT NULL THEN NULL ELSE UPPER(TRIM(v_code)) END,
                v_internal_desc,
                (pat_rec.CONVERSION_RATE * (v_gross_amount / v_quantity )),
                v_override_yn,---NEWLY ADDED PREAUTH ENHANCEMENT
                v_override_remarks,---NEWLY ADDED PREAUTH ENHANCEMENT
                v_denial_code,---NEWLY ADDED PREAUTH ENHANCEMENT
                v_net_amount,---NEWLY ADDED PREAUTH ENHANCEMENT
                v_net_amount,---NEWLY ADDED PREAUTH ENHANCEMENT
                v_activity_type_id,---NEWLY ADDED PREAUTH ENHANCEMENT
                v_denial_desc,
                v_override_remarks_code, ---NEWLY ADDED OVERRIDER DROP DOWN LIST
                v_other_remarks          ---NEWLY ADDED OVERRIDER DROP DOWN LIST
                
               ) ;
   
  
   /*ELSE
     
           UPDATE pat_activity_details SET
          pat_auth_seq_id       =  v_pat_auth_seq_id,
          code                  =  UPPER(TRIM(v_code)),
          quantity              =  v_quantity,
          gross_amount          =  v_gross_amount* v_quantity,---v_tot_gross_amount,
          unit_price            =  v_gross_amount,
          discount_amount       =  v_discount_amount * v_quantity,--v_tot_discount_amount,
          disc_gross_amount     =  (v_gross_amount*v_quantity)-(v_discount_amount * v_quantity),--v_tot_disc_gross_amount,
          net_amount            =  (v_gross_amount*v_quantity)-(v_discount_amount * v_quantity),
          updated_by            =  v_added_by,
          updated_date          =  SYSDATE,
          start_date            =  v_start_date1 ,
          allow_yn              =  v_allowed_yn,
          clinician_id          =  v_clinician_id,
          unit_discount_amount  =  v_discount_amount,
          approvd_quantity      =  v_quantity,
          activity_type         =  v_activity_type_id
          
    WHERE activity_dtl_seq_id =  v_activity_dtl_seq_id;*/
 

 --END IF;
  COMMIT;
END save_activity_details;
--==============================================================================
PROCEDURE save_ddc_details(
    v_activity_dtl_seq_id     IN  pat_activity_details.activity_dtl_seq_id%TYPE,
    v_pat_auth_seq_id         IN  pat_activity_details.pat_auth_seq_id%TYPE,
    v_code                    IN  pat_activity_details.code%TYPE,
    v_quantity                IN  pat_activity_details.quantity%TYPE,
    v_posology                IN  pat_activity_details.posology%TYPE,
    v_posology_duration       IN  pat_activity_details.posology_duration%TYPE,
    v_unit_type               IN  pat_activity_details.unit_type%TYPE,
    v_gross_amount            IN  pat_activity_details.gross_amount%TYPE,
    v_discount_amount         IN  pat_activity_details.discount_amount%TYPE,
    v_disc_gross_amount       IN  pat_activity_details.disc_gross_amount%TYPE,
    v_net_amount              IN  pat_activity_details.net_amount%TYPE,
    v_start_date              IN  varchar2,
    v_allowed_yn              in  varchar2,
    v_clinician_id            in  pat_activity_details.clinician_id%type,
    v_added_by                IN  pat_activity_details.added_by%TYPE
)
 IS
 v_prod_pol_rule_seq_id       tpa_ins_prod_policy_rules.prod_policy_rule_seq_id%type;
 
 CURSOR master_cur IS
   SELECT *
   FROM Tpa_Activity_Master_Details m
   WHERE m.activity_code = UPPER(v_code);
   
 master_rec master_cur%ROWTYPE;
 
 CURSOR act_cur IS
  SELECT max(pad.s_no) max_sno
  FROM pat_activity_details pad
  WHERE pad.pat_auth_seq_id=v_pat_auth_seq_id;
  
  CURSOR pat_diag_cur IS
  SELECT count(1) 
  FROM diagnosys_details dd
  WHERE dd.pat_auth_seq_id=v_pat_auth_seq_id;
  

  CURSOR pat_cur IS
 SELECT pad.pat_auth_seq_id,
       pad.pat_batch_seq_id,
       pad.claim_seq_id,
       pad.member_seq_id,       
       pad.final_app_amount,
       pad.denial_reason,
       pad.completed_yn
  FROM pat_authorization_details pad
  WHERE pad.pat_auth_seq_id=v_pat_auth_seq_id;
 

  
 pat_rec              pat_cur%ROWTYPE;
 act_rec              act_cur%ROWTYPE;
 v_s_no               NUMBER;
 v_diag_count         NUMBER;
 
 v_copay_per          number:=0;
 v_rule_limit         number:=0;
 v_start_date1        date;
 ----added below variables for calculating 
 v_tot_gross_amount  number;
 v_tot_discount_amount  number;
 v_tot_disc_gross_amount   number;
 
  
BEGIN
   v_start_date1:=to_date(v_start_date,'DD/MM/YYYY');

OPEN master_cur;
FETCH master_cur INTO master_rec;
CLOSE master_cur;

IF v_pat_auth_seq_id IS NOT NULL THEN 
  OPEN pat_diag_cur;
  FETCH pat_diag_cur INTO v_diag_count;
  CLOSE pat_diag_cur;
 END IF;
  
  if v_pat_auth_seq_id is not null then
   OPEN pat_cur;
   FETCH pat_cur INTO pat_rec;
   CLOSE pat_cur;
  end if;
  
  IF v_diag_count<1 THEN
    RAISE_APPLICATION_ERROR(-20380,'Please add atleast one Diagnosis');
  END IF;
  
  --IF NVL(v_activity_dtl_seq_id,0)=0 THEN
    if v_pat_auth_seq_id is not null then
     OPEN act_cur;
     FETCH act_cur INTO act_rec;
     CLOSE act_cur;
    end if;
    v_s_no:=NVL(act_rec.max_sno,0)+1;
    
    /*v_tot_gross_amount       := v_gross_amount*v_quantity;
    v_tot_discount_amount    :=v_discount_amount*v_quantity;
    v_tot_disc_gross_amount  :=v_disc_gross_amount*v_quantity;*/
    
    INSERT INTO pat_activity_details(
                activity_dtl_seq_id,
                pat_auth_seq_id,
                code,
                quantity,
                posology ,
                posology_duration   ,
                unit_type      ,
                gross_amount,
                unit_price,
                discount_amount,
                disc_gross_amount,
                net_amount,
                added_by,
                added_date,
                start_date,
                allow_yn,
                clinician_id,
                unit_discount_amount,
                activity_type,
                service_type,
                activity_seq_id,
                approvd_quantity
                 )
          VALUES (
                pat_activity_detail_seq.nextval,
                v_pat_auth_seq_id,
                UPPER(TRIM(v_code)),
                v_quantity,
                v_posology         ,
                v_posology_duration   ,
                v_unit_type          ,
                v_gross_amount,--v_tot_gross_amount,
                (v_gross_amount/v_quantity),---UNIT PRICE
                v_discount_amount,--v_tot_discount_amount,
                v_disc_gross_amount,--v_tot_disc_gross_amount,
                v_net_amount,
                v_added_by,
                SYSDATE,
                v_start_date1,
                v_allowed_yn,
                v_clinician_id,
                v_discount_amount,
                5,
                'ACD',
                master_rec.act_mas_dtl_seq_id,
                v_quantity
                
               ) ;
   
  
   /*ELSE
     
  \*  v_tot_gross_amount      :=   v_gross_amount*v_quantity;
    v_tot_discount_amount   :=   v_discount_amount*v_quantity;
    v_tot_disc_gross_amount :=   v_disc_gross_amount*v_quantity;*\
     
      UPDATE pat_activity_details SET
          pat_auth_seq_id       =  v_pat_auth_seq_id,
          code                  =  UPPER(TRIM(v_code)),
          quantity              =  v_quantity,
          gross_amount          =  v_gross_amount,---v_tot_gross_amount,
          unit_price            =  v_gross_amount,
          discount_amount       =  v_discount_amount,--v_tot_discount_amount,
          disc_gross_amount     =  v_disc_gross_amount,--v_tot_disc_gross_amount,
          net_amount            =  v_net_amount,
          updated_by            =  v_added_by,
          updated_date          =  SYSDATE,
          start_date            =  v_start_date1 ,
          allow_yn              =  v_allowed_yn,
          clinician_id          =  v_clinician_id,
          unit_discount_amount  =  v_discount_amount
    WHERE activity_dtl_seq_id =  v_activity_dtl_seq_id;
 

 END IF;*/
  COMMIT;
END save_ddc_details;

--=====================================================================
----------------------For Print Form Member Details -------------------

PROCEDURE get_mem_details(v_tpa_enrollment_id          IN  app.tpa_enr_policy_member.tpa_enrollment_id%TYPE,
                          v_result_set                 OUT SYS_REFCURSOR)
IS 
  v_event                 VARCHAR2(10);
  v_seq                   NUMBER;
BEGIN
  select app.event_ref_no_seq.nextval into v_seq from dual;
  v_event := rpad(v_seq, 7, 0);
  
  OPEN v_result_set FOR
     SELECT case when c.gender_general_type_id='MAL' then 'MALE'  else 'FEMALE' end  gender,
            c.mem_name,
            c.mem_age years,
            to_char(c.mem_dob,'DD-MM-YYYY') AS mem_dob,
            c.tpa_enrollment_id ,
            a.policy_number ,
             trunc(mod(months_between(sysdate,c.mem_dob ),12)) as months,
            b.employee_no EMPLOYEE_NO,
            d.group_name COMPANY_NAME,
            ttk_util_pkg.fn_decrypt(e.mobile_no) as MOBILE_NO,
            ttk_util_pkg.fn_decrypt(e.email_id) as Email_Id,
            a.policy_number,
            c.emirate_id as quatar_id,
            v_event      as event_no
            
     FROM tpa_enr_policy a join tpa_enr_policy_group b ON (a.policy_seq_id=b.policy_seq_id)
     JOIN tpa_enr_policy_member c on (b.policy_group_seq_id=c.policy_group_seq_id)
     join app.tpa_group_registration d on (b.group_reg_seq_id=d.group_reg_seq_id)
     join app.tpa_enr_mem_address e on (b.enr_address_seq_id=e.enr_address_seq_id)
     where c.member_seq_id=(select max(me.member_seq_id)
                                   from tpa_enr_policy_member me
                                   where  me.tpa_enrollment_id=v_tpa_enrollment_id);
   
 END get_mem_details;
 ---==========================SAVE PREAUTH GENERAL DETAILS=======================================================================
 procedure save_pat_online_intimation1
          (v_pre_auth_seq_id        in out pat_authorization_details.pat_auth_seq_id%type,
          v_member_seq_id           in pat_authorization_details.member_seq_id%type,
          v_hospitalization_date    in pat_authorization_details.hospitalization_date%type,
          v_discharge_date          IN pat_authorization_details.discharge_date%type,
          v_clinician_name          in pat_non_network_details.clinician_name%type,
          v_clinician_id            in pat_authorization_details.clinician_id%type,
          v_presenting_complaints   in pat_authorization_details.presenting_complaints%type,
          v_past_history            in pat_authorization_details.past_history%type,
          v_duration_above_illness              in pat_authorization_details.duration_above_illness%type,
          v_duration_above_illness_time         in pat_authorization_details.duration_above_illness_time%type,
          v_since_when              in pat_authorization_details.since_when%type,
          v_since_when_time         in pat_authorization_details.since_when_time%type,
          v_encounter_start_type    in pat_authorization_details.encounter_start_type%type,
          v_encounter_type_id       in pat_authorization_details.encounter_type_id%type,
          v_pl_preauth_refno        in out pat_authorization_details.pl_preauth_refno%type,
          v_added_by                in pat_authorization_details.added_by%type,
          v_hosp_seq_id             in tpa_hosp_info.hosp_seq_id%type,
          v_tpa_enrollment_id       in pat_authorization_details.tpa_enrollment_id%type,
          v_benefit_type            in pat_authorization_details.benifit_type%type,
          v_clinician_speciality    in pat_authorization_details.clinician_speciality%type,
          v_consultation_type       in pat_authorization_details.consultation_type%type,
          v_rows_processed          out NUMBER,
          v_file_name               in varchar2 := null,
          v_enhance_yn              in varchar2,
          v_gentype_id              in MOU_DOCS_INFO1.FILE_NAME%TYPE,
          v_image_data              in MOU_DOCS_INFO1.IMAGE_FILE%TYPE := null,
          v_date_of_lmp             in pat_authorization_details.lmp_date%TYPE,
          v_conception_type         in pat_authorization_details.conception_type%TYPE,
          v_system_of_med           in pat_authorization_details.system_of_medicine_type_id%TYPE,
          v_delvy_mode              in pat_authorization_details.delvry_mod_type%TYPE,
		      v_event_no                in pat_authorization_details.event_no%TYPE
          ) 
 IS

cursor mem_cur is SELECT a.member_seq_id,
         a.tpa_enrollment_id,
         a.mem_name,
         nvl(a.mem_age,(months_between(sysdate,a.mem_dob)/12)) as mem_age,
         a.emirate_id,
         tii.ins_seq_id,
         tii.ins_comp_name,
         tii.ins_comp_code_number as payer_id,
         c.policy_seq_id,
         c.enrol_type_id,
         account_info_pkg.get_gen_desc(A.GENDER_GENERAL_TYPE_ID,'G') AS gender,
         (c.policy_number||'('||ip.product_cat_type_id||')') as policy_number,
         (d.group_name||'('||d.group_id||')') as corporate_name,
         d.group_reg_seq_id,
         c.effective_from_date as policy_start_date,
         c.effective_to_date as policy_end_date,
         nc.description as nationality,
         nvl(eb.sum_insured,0) - nvl(eb.utilised_sum_insured,0) AS ava_sum_insured,
         eb.sum_insured,
         a.vip_yn,
         reg.corp_vip_yn
         
  FROM   tpa_enr_policy_member A
  JOIN tpa_enr_policy_group B ON (A.policy_group_seq_id = B.policy_group_seq_id)
  JOIN tpa_enr_policy C ON (B.policy_seq_id = C.policy_seq_id )
  JOIN tpa_ins_product ip ON (ip.product_seq_id=c.product_seq_id)
  LEFT OUTER JOIN tpa_group_registration d ON (d.group_reg_seq_id=c.group_reg_seq_id)
  join tpa_ins_info tii on (c.ins_seq_id=tii.ins_seq_id)
  left outer join tpa_nationalities_code nc on (nc.nationality_id=a.nationality_id)
  LEFT OUTER JOIN tpa_enr_balance eb ON (b.policy_group_seq_id = eb.policy_group_seq_id)
  LEFT OUTER JOIN tpa_group_registration reg ON(reg.group_reg_seq_id = b.group_reg_seq_id)
  WHERE a.tpa_enrollment_id=upper(trim(v_tpa_enrollment_id))
  AND ( SYSDATE BETWEEN C.effective_from_date AND C.effective_to_date+1)
  and  (a.mem_general_type_id != 'PFL' AND a.member_seq_id = eb.member_seq_id OR eb.member_seq_id IS NULL OR a.member_seq_id IS NULL)
  and a.status_general_type_id IN ('POA','POC')
  AND b.status_general_type_id IN ('POA','POC')
  AND C.COMPLETED_YN='Y'
  and B.DELETED_YN='N'
  AND A.DELETED_YN='N';

mem_rec           mem_cur%rowtype; 

cursor prov_cur is select hi.hosp_seq_id,hi.hosp_name,
hi.empanel_number,
ha.city_type_id,
ha.state_type_id,
ha.country_id,
ha.address_1,
ha.address_2,
ha.address_3,
ha.pin_code
from app.tpa_hosp_info hi 
left outer join app.tpa_hosp_address ha on (hi.hosp_seq_id = ha.hosp_seq_id) 
where hi.hosp_seq_id = v_hosp_seq_id;

prov_rec     prov_cur%rowtype;

CURSOR event_cur IS
  select count(p.event_no)
  from pat_authorization_details p
  where p.event_no = trim(v_event_no);
  
-----***FOR PREAUTH ENHANCEMENT*****-------

CURSOR parnt_pat_cnt_cur
IS
SELECT count(1)
FROM app.pat_authorization_details a
WHERE a.pat_auth_seq_id = v_pre_auth_seq_id 
and a.completed_yn = 'Y' 
and a.pat_enhanced_yn = 'N'
and a.pat_status_type_id = 'APR';



v_count   NUMBER(4);

CURSOR parnt_val_cur
IS
SELECT nvl(a.parent_pat_auth_seq_id,0) parent_pat_auth_seq_id
FROM   app.pat_authorization_details a
WHERE a.pat_auth_seq_id = v_pre_auth_seq_id ;

parnt_val   parnt_val_cur%ROWTYPE;

v_benfit_typ   VARCHAR2(100);

CURSOR pl_preno_cur
IS
SELECT a.pl_preauth_refno
FROM APP.PAT_AUTHORIZATION_DETAILS a
WHERE a.pat_auth_seq_id = v_pre_auth_seq_id;

v_pl_pre_no      pl_preno_cur%ROWTYPE;


CURSOR  VALID_ENROLL_CUR
 IS
 SELECT COUNT(A.MEMBER_SEQ_ID)
  FROM   tpa_enr_policy_member A
  JOIN tpa_enr_policy_group B ON (A.policy_group_seq_id = B.policy_group_seq_id)
  JOIN tpa_enr_policy C ON (B.policy_seq_id = C.policy_seq_id )
  JOIN tpa_ins_product ip ON (ip.product_seq_id=c.product_seq_id)
  LEFT OUTER JOIN tpa_group_registration d ON (d.group_reg_seq_id=c.group_reg_seq_id)
  join tpa_ins_info tii on (c.ins_seq_id=tii.ins_seq_id)
  left outer join tpa_nationalities_code nc on (nc.nationality_id=a.nationality_id)
  LEFT OUTER JOIN tpa_enr_balance eb ON (b.policy_group_seq_id = eb.policy_group_seq_id)
  WHERE a.tpa_enrollment_id=upper(trim(v_tpa_enrollment_id))
  AND ( SYSDATE BETWEEN C.effective_from_date AND C.effective_to_date+1)
  and  (a.mem_general_type_id != 'PFL' AND a.member_seq_id = eb.member_seq_id OR eb.member_seq_id IS NULL OR a.member_seq_id IS NULL)
  and a.status_general_type_id IN ('POA','POC')
  AND b.status_general_type_id IN ('POA','POC')
  AND C.COMPLETED_YN='Y'
  and B.DELETED_YN='N'
  AND A.DELETED_YN='N';


  V_COUNT_VALID   NUMBER(10);

  
event_num          VARCHAR2(15);
v_event_num        VARCHAR2(15);
v_spec_char_cnt    NUMBER;
v_event_len        NUMBER;
v_pat_id           NUMBER;

BEGIN
  
  open mem_cur;
  fetch mem_cur into mem_rec;
  close mem_cur;
   
  open prov_cur;
  fetch prov_cur into prov_rec;
  close prov_cur;
  
IF v_enhance_yn = 'Y' THEN 
  
  OPEN VALID_ENROLL_CUR;
  FETCH VALID_ENROLL_CUR  INTO V_COUNT_VALID;
  CLOSE VALID_ENROLL_CUR;
    
  IF V_COUNT_VALID = 0 THEN 
    
    RAISE_APPLICATION_ERROR(-20954,'ALKOOT ID IS NOT VALID OR POLICY EXPIRED');
    
  END IF;
  
END IF;
  
  -- If Event is not generated or Existing Event Number
  IF v_event_no IS NOT NULL THEN
    IF NVL(v_pre_auth_seq_id, 0) = 0 THEN
      
      SELECT count(1) INTO v_spec_char_cnt FROM DUAL
      WHERE REGEXP_LIKE(v_event_no, '^\d+(\\d+)?$', '');
        
      IF v_spec_char_cnt = 0 THEN
        RAISE_APPLICATION_ERROR(-20916, 'Event Number should be number format .');
      END IF;
      
      SELECT length(v_event_no) INTO v_event_len
      FROM DUAL;
      
      IF v_event_len != 7 THEN
        RAISE_APPLICATION_ERROR(-20918, 'Event Number Length should be 7 .');
      END IF;
      
      /*open event_cur;
      fetch event_cur into event_num;
      close event_cur;*/
      
      /*select rpad((s.LAST_NUMBER - 1), 7, 0) INTO v_event_num
      from all_sequences s
      where s.SEQUENCE_NAME = UPPER('event_ref_no_seq')
      and s.SEQUENCE_OWNER = 'APP';*/
      
      /*IF event_num > 0 THEN
        RAISE_APPLICATION_ERROR(-20914, 'Given Event Number is Already assinged to other Preaproval/ Claim.');
      END IF;*/
      
      
      
      /*IF to_number(trim(v_event_no)) > v_event_num THEN
        RAISE_APPLICATION_ERROR(-20915, 'Given Event Number is not valid.');
      END IF;*/ -- Commented For AL AHALI Preapprovals
      
   ELSE
     IF v_event_no IS NOT NULL THEN
      SELECT count(1) INTO v_spec_char_cnt FROM DUAL
      WHERE REGEXP_LIKE(v_event_no, '^\d+(\\d+)?$', '');
        
      IF v_spec_char_cnt = 0 THEN
        RAISE_APPLICATION_ERROR(-20916, 'Event Number should be number format .');
      END IF;
     END IF;
     
     SELECT length(v_event_no) INTO v_event_len
     FROM DUAL;
      
     IF v_event_len != 7 THEN
       RAISE_APPLICATION_ERROR(-20919, 'Event reference Number should be 7 digits .');
     END IF;
       
     /*Select Count(p.event_no) Into event_num
     From Pat_Authorization_Details p
     Where p.pat_auth_seq_id != v_pre_auth_seq_id
     And p.event_no = trim(v_event_no);*/
     
     /*select rpad((s.LAST_NUMBER - 1), 7, 0) INTO v_event_num
      from all_sequences s
      where s.SEQUENCE_NAME = UPPER('event_ref_no_seq')
      and s.SEQUENCE_OWNER = 'APP';*/
     
     /*IF to_number(trim(v_event_no)) > v_event_num THEN
       RAISE_APPLICATION_ERROR(-20915, 'Given Event Number is not valid.');
     END IF;*/ -- Commented For AL AHALI Preapprovals
     
     /*IF event_num > 0 THEN
       RAISE_APPLICATION_ERROR(-20914, 'Given Event Number is Already assinged to other Preaproval/ Claim.');
     END IF;*/
      
   END IF;
 END IF;--case when v_enhance_yn = 'Y' THEN NULL 
 
 
  IF   v_enhance_yn = 'Y' THEN
   
  select case when UPPER(v_benefit_type) = 'IN-PATIENT'   then 'IPT'
              when UPPER(v_benefit_type) = 'OUT-PATIENT'  then 'OPTS'
              when UPPER(v_benefit_type) = 'OPTICAL'  then  'OPTC' 
              when UPPER(v_benefit_type) = 'IN-PATIENT MATERNITY'   then  'IMTI'  
              when UPPER(v_benefit_type) = 'OUT-PATIENT MATERNITY'   then 'OMTI'
              when UPPER(v_benefit_type) = 'DENTAL'  then 'DNTL'
              when UPPER(v_benefit_type) = 'HEALTH CHECK-UP'  then  'HEAC'
              when UPPER(v_benefit_type) = 'DAY CARE'  then   'DAYC' 
            end as benefit_type into v_benfit_typ
  from dual ;
  
  OPEN  pl_preno_cur;
  FETCH pl_preno_cur INTO v_pl_pre_no; 
  CLOSE pl_preno_cur;
  

END IF;

     
   

IF  v_enhance_yn = 'N' THEN  
    
save_pat_details
              (v_pre_auth_seq_id, ----NEWLY ADDED FOR ENHANCE PREAUTH           
               NULL,---v_parent_pat_auth_seq_id
              sysdate,
              v_discharge_date,             
              null,
              v_hospitalization_date,      
              v_member_seq_id ,             
              trim(v_tpa_enrollment_id),
              v_pl_preauth_refno,
              null,              
              mem_rec.mem_name,
              mem_rec.mem_age,
              mem_rec.ins_seq_id,
              v_hosp_seq_id,
              mem_rec.policy_seq_id,
              mem_rec.emirate_id,
              v_encounter_type_id,
              null,          
              v_encounter_start_type,
              null,
              null,       
              1, --Default User System                  
              v_clinician_id,         
              v_system_of_med,
              'CLN',
              /*'MID'*/case when mem_rec.vip_yn='Y' or NVL(mem_rec.corp_vip_yn,'CVN')='CVY' then 'HIG' else 'MID' END,
              'Y',
              prov_rec.hosp_name,
              prov_rec.empanel_number,
              prov_rec.city_type_id,
              prov_rec.state_type_id,
              prov_rec.country_id,
              prov_rec.address_1||prov_rec.address_2||prov_rec.address_3,
              prov_rec.pin_code,
              null,
              v_benefit_type,
              null,
              null,
              null,
              null,
              'PAT' ,
              'QAR',
              v_clinician_name,
              mem_rec.ava_sum_insured,
              v_rows_processed,
              v_past_history ,
              v_duration_above_illness ,
              v_duration_above_illness_time ,
              v_since_when              ,
              v_since_when_time,
              v_clinician_speciality,
              v_consultation_type,
              v_presenting_complaints,
              v_file_name,
              v_enhance_yn,
              v_gentype_id,
              v_image_data,
              v_date_of_lmp,
              v_conception_type,
              v_delvy_mode,
              v_event_no
              ) ;
 

ELSE
  
  OPEN    parnt_pat_cnt_cur ;
  FETCH   parnt_pat_cnt_cur  INTO v_count;
  CLOSE   parnt_pat_cnt_cur; 

  IF V_COUNT = 1 THEN 
  
  v_pat_id           :=     case when v_enhance_yn = 'Y' THEN v_pre_auth_seq_id ELSE 0 END;      
  v_pre_auth_seq_id  :=     case when v_enhance_yn = 'Y' THEN 0 ELSE v_pre_auth_seq_id END;

    save_pat_details
              (v_pre_auth_seq_id, ----NEWLY ADDED FOR ENHANCE PREAUTH           
               v_pat_id,---v_parent_pat_auth_seq_id
              sysdate,
              v_discharge_date,             
              null,
              v_hospitalization_date,      
              v_member_seq_id ,             
              trim(v_tpa_enrollment_id),
              v_pl_pre_no.pl_preauth_refno,
              null,              
              mem_rec.mem_name,
              mem_rec.mem_age,
              mem_rec.ins_seq_id,
              v_hosp_seq_id,
              mem_rec.policy_seq_id,
              mem_rec.emirate_id,
              v_encounter_type_id,
              null,          
              v_encounter_start_type,
              null,
              null,       
              1, --Default User System                  
              v_clinician_id,         
              v_system_of_med,
              'CLN',
              /*'MID'*/case when mem_rec.vip_yn='Y' or NVL(mem_rec.corp_vip_yn,'CVN')='CVY' then 'HIG' else 'MID' END,
              'Y',
              prov_rec.hosp_name,
              prov_rec.empanel_number,
              prov_rec.city_type_id,
              prov_rec.state_type_id,
              prov_rec.country_id,
              prov_rec.address_1||prov_rec.address_2||prov_rec.address_3,
              prov_rec.pin_code,
              null,
              v_benfit_typ,
              null,
              null,
              null,
              null,
              'ENH' ,
              'QAR',
              v_clinician_name,
              mem_rec.ava_sum_insured,
              v_rows_processed,
              v_past_history ,
              v_duration_above_illness ,
              v_duration_above_illness_time ,
              v_since_when              ,
              v_since_when_time,
              v_clinician_speciality,
              v_consultation_type,
              v_presenting_complaints,
              v_file_name,
              v_enhance_yn,
              v_gentype_id,
              v_image_data,
              v_date_of_lmp,
              v_conception_type,
              v_delvy_mode,
              v_event_no
              ) ;
              
   ELSE 
    
    OPEN  parnt_val_cur;
    FETCH parnt_val_cur  INTO  parnt_val;
    CLOSE parnt_val_cur;   
    
    
    save_pat_details
              (v_pre_auth_seq_id, ----NEWLY ADDED FOR ENHANCE PREAUTH           
               parnt_val.parent_pat_auth_seq_id,---v_parent_pat_auth_seq_id
              sysdate,
              v_discharge_date,             
              null,
              v_hospitalization_date,      
              v_member_seq_id ,             
              trim(v_tpa_enrollment_id),
               v_pl_pre_no.pl_preauth_refno,
              null,              
              mem_rec.mem_name,
              mem_rec.mem_age,
              mem_rec.ins_seq_id,
              v_hosp_seq_id,
              mem_rec.policy_seq_id,
              mem_rec.emirate_id,
              v_encounter_type_id,
              null,          
              v_encounter_start_type,
              null,
              null,       
              1, --Default User System                  
              v_clinician_id,         
              v_system_of_med,
              'CLN',
              /*'MID'*/case when mem_rec.vip_yn='Y' or NVL(mem_rec.corp_vip_yn,'CVN')='CVY' then 'HIG' else 'MID' END,
              'Y',
              prov_rec.hosp_name,
              prov_rec.empanel_number,
              prov_rec.city_type_id,
              prov_rec.state_type_id,
              prov_rec.country_id,
              prov_rec.address_1||prov_rec.address_2||prov_rec.address_3,
              prov_rec.pin_code,
              null,
              v_benfit_typ,
              null,
              null,
              null,
              null,
              'ENH' ,
              'QAR',
              v_clinician_name,
              mem_rec.ava_sum_insured,
              v_rows_processed,
              v_past_history ,
              v_duration_above_illness ,
              v_duration_above_illness_time ,
              v_since_when              ,
              v_since_when_time,
              v_clinician_speciality,
              v_consultation_type,
              v_presenting_complaints,
              v_file_name,
              v_enhance_yn,
              v_gentype_id,
              v_image_data,
              v_date_of_lmp,
              v_conception_type,
              v_delvy_mode,
              v_event_no
              ) ;
  END IF;                       
 
  
 END IF;            

--delete(select *from diagnosys_details dd where dd.pat_auth_seq_id=v_pre_auth_seq_id);


  COMMIT;
end save_pat_online_intimation1;


----=========================added this save for general save(Submit) in provider login------
PROCEDURE save_pat_details(v_pat_auth_seq_id            in out pat_authorization_details.pat_auth_seq_id%type,
                           v_parent_pat_auth_seq_id     in pat_authorization_details.parent_pat_auth_seq_id%type,
                           v_pat_received_date          in pat_authorization_details.pat_received_date%type,
                           v_discharge_date             IN pat_authorization_details.discharge_date%type,
                           v_source_type_id             in pat_authorization_details.source_type_id%type,
                           v_hospitalization_date       in pat_authorization_details.hospitalization_date%type,
                           v_member_seq_id              in pat_authorization_details.member_seq_id%type,
                           v_tpa_enrollment_id          in pat_authorization_details.tpa_enrollment_id%type,
                           v_pl_preauth_refno            in out pat_authorization_details.pl_preauth_refno%type,
                           v_auth_number                in pat_authorization_details.auth_number%type,
                           v_mem_name                   in pat_authorization_details.mem_name%type,
                           v_mem_age                    in pat_authorization_details.mem_age%type,
                           v_ins_seq_id                 in pat_authorization_details.ins_seq_id%type,
                           v_hosp_seq_id                in pat_authorization_details.hosp_seq_id%type,
                           v_policy_seq_id              in pat_authorization_details.policy_seq_id%type,
                           v_emirate_id                 in pat_authorization_details.emirate_id%type,
                           v_encounter_type_id          in pat_authorization_details.encounter_type_id%type,
                           v_encounter_facility_id      in pat_authorization_details.encounter_facility_id%type,
                           v_encounter_start_type       IN pat_authorization_details.encounter_start_type%type,
                           v_encounter_end_type         IN pat_authorization_details.encounter_end_type%type,
                           v_remarks                    in pat_authorization_details.remarks%type,
                           v_added_by                   in number,
                           v_clinician_id               in pat_authorization_details.clinician_id%type,
                           v_system_of_medicine_type_id in pat_authorization_details.system_of_medicine_type_id%type,
                           v_accident_related_type_id   in pat_authorization_details.Accident_Related_Type_Id%TYPE,
                           v_priority_gen_type_id       in pat_authorization_details.priority_general_type_id%TYPE,
                           v_network_yn                 in pat_authorization_details.network_yn%type,
                           v_provider_name              in pat_non_network_details.provider_name%type,
                           v_provider_id                in pat_non_network_details.provider_id%type,
                           v_city_type_id               in pat_non_network_details.city_type_id%type,
                           v_state_type_id              in pat_non_network_details.state_type_id%type,
                           v_country_type_id            in pat_non_network_details.country_type_id%type,
                           v_provider_address           in pat_non_network_details.provider_address%type,
                           v_pincode                    in pat_non_network_details.pincode%type,
                           v_requested_amount           in pat_authorization_details.requested_amount%type,
                           v_benifit_type               in pat_authorization_details.benifit_type%type,
                           v_gravida                    in pat_authorization_details.gravida%type,
                           v_para                       in pat_authorization_details.para%type,
                           v_live                       in pat_authorization_details.live%type,
                           v_abortion                   in pat_authorization_details.abortion%type,
                           v_selection_type             in varchar2,--PAT,'ENH'--enhancement
                           v_currency_type              in pat_authorization_details.currency_type%type,
                           v_clinician_name             in pat_non_network_details.clinician_name%type,
                           v_ava_sum_insured            in pat_authorization_details.ava_sum_insured%type,
                           v_rows_processed             out number,
                           v_past_history               in pat_authorization_details.past_history%type:= null,
                           v_duration_above_illness              in pat_authorization_details.duration_above_illness%type,
                           v_duration_above_illness_time         in pat_authorization_details.duration_above_illness_time%type,
                           v_since_when                          in pat_authorization_details.since_when%type,
                           v_since_when_time                     in pat_authorization_details.since_when_time%type,
                           v_clinician_speciality    in pat_authorization_details.clinician_speciality%type:= null,
                           v_consultation_type       in pat_authorization_details.consultation_type%type:= null,
                           v_presenting_comp   IN pat_authorization_details.presenting_complaints%TYPE, 
                           v_file_name               in varchar2,
                           v_enhance_yn              in varchar2,
                           v_gentype_id              in MOU_DOCS_INFO1.DOCS_GENTYPE_ID%TYPE,
                           v_image_data              in MOU_DOCS_INFO1.IMAGE_FILE%TYPE,
                           v_date_of_lmp             in pat_authorization_details.lmp_date%TYPE,
                           v_conception_type         in pat_authorization_details.conception_type%TYPE,  
                           v_delvy_mode              in pat_authorization_details.delvry_mod_type%TYPE,
                           v_event_no                in pat_authorization_details.event_no%TYPE
                           ) is

  CURSOR mem_cur IS
    SELECT tepm.date_of_inception,
           tepm.date_of_exit,
           tepm.mem_name,
           tepm.mem_age,
           tcc.short_name,
           tsc.state_type_id,
           tepg.policy_group_seq_id,
           tepg.policy_seq_id,
           tepm.member_seq_id
      FROM tpa_enr_policy_group tepg
      JOIN tpa_enr_policy_member tepm
        ON (tepg.policy_group_seq_id = tepm.policy_group_seq_id)
     LEFT OUTER JOIN tpa_enr_mem_address tema
        ON (tepg.enr_address_seq_id = tema.enr_address_seq_id)
     LEFT OUTER JOIN tpa_country_code tcc
        ON (tema.country_id = tcc.country_id)
     LEFT OUTER JOIN tpa_state_code tsc
        ON (tema.state_type_id = tsc.state_type_id)
     WHERE tepm.Member_Seq_Id = v_member_seq_id;

  CURSOR pat_dup_cur IS
    SELECT pad.hospitalization_date
      FROM pat_authorization_details pad
     WHERE pad.member_seq_id = v_member_seq_id
       AND pad.pat_auth_seq_id != nvl(v_pat_auth_seq_id, 0)
     ORDER BY pad.hospitalization_date desc;

  CURSOR pat_cur(v_pat_auth_seq_id NUMBER) IS
    SELECT pad.completed_yn,pad.pat_status_type_id,pad.pat_enhanced_yn
      FROM pat_authorization_details pad
     WHERE pad.pat_auth_seq_id = v_pat_auth_seq_id;
     
  CURSOR clinician_cur IS
   SELECT hp.hosp_seq_id,hp.professional_id,hp.valid_from_date,hp.valid_to_date FROM app.tpa_hosp_professionals hp
   WHERE hp.professional_id=v_clinician_id
   AND hp.hosp_seq_id = v_hosp_seq_id;--
 
 CURSOR clinician_count_cur IS
   SELECT count(1) FROM app.tpa_hosp_professionals hp
   WHERE hp.professional_id=v_clinician_id AND hp.hosp_seq_id=v_hosp_seq_id;
   
 CURSOR prev_balance_cur IS SELECT b.balance_seq_id , b.sum_insured  ,b.utilised_sum_insured ,
        a.policy_group_seq_id ,a.mem_general_type_id 
      FROM tpa_enr_policy_member a JOIN tpa_enr_balance b ON (a.policy_group_seq_id = b.policy_group_seq_id )
      JOIN tpa_enr_policy c ON (b.policy_seq_id = c.policy_seq_id)
      WHERE a.member_seq_id = v_member_seq_id
      AND (a.mem_general_type_id = 'PFL' AND b.member_seq_id IS NULL
               OR a.mem_general_type_id != 'PFL' AND b.member_seq_id = v_member_seq_id );
  
 CURSOR enh_pat_cur IS
   SELECT MAX(pad.pat_auth_seq_id) as pat_auth_seq_id
   FROM pat_authorization_details pad
   WHERE pad.PARENT_PAT_AUTH_SEQ_ID = v_pat_auth_seq_id;
 
  enh_pat_rec   enh_pat_cur%ROWTYPE;

---------****NEWLY ADDED*****------------
  
  CURSOR enh_pre_auth_no_cur(v_pre_auth_id  number)  
  IS
    SELECT  a.pre_auth_number ,
            a.ptnr_seq_id,
            a.onl_pat_auth_seq_id,
            a.onl_pre_auth_refno,
            a.xml_seq_id,
            a.override_remarks,
            a.internal_remarks,
            a.medical_opinion_remarks,
            a.pbm_yn,
            a.status_code_id,
            a.risk_level,
            a.code_added_by,
            a.code_remarks,
            a.code_added_date,
            a.suspect_veri_check,
            a.appeal_count,
            a.appeal_yn,
            a.appeal_date
  FROM  app.pat_authorization_details a
  WHERE a.pat_auth_seq_id =  v_pre_auth_id;
 
  enh_pat_no_rec    enh_pre_auth_no_cur%ROWTYPE; 
  

  CURSOR check_clm_yn_cur(v_pre_auth_id  number)
  IS
  SELECT count(1)
  FROM  app.pat_authorization_details a
  WHERE a.claim_seq_id is not null 
    and a.pat_enhanced_yn = 'N'
    and a.pat_auth_seq_id = v_pre_auth_id;
   
  rec_clm_yn        NUMBER;   
  
  
 CURSOR icd_cur IS
 SELECT count(1)
 FROM  diagnosys_details d
 WHERE d.pat_auth_seq_id = v_pat_auth_seq_id
 AND d.primary_ailment_yn = 'Y';
 
  v_icd_count          NUMBER;
  
 CURSOR pat_rec_cur
 IS
 SELECT * 
 FROM APP.PAT_AUTHORIZATION_DETAILS A
 WHERE A.PAT_AUTH_SEQ_ID = v_parent_pat_auth_seq_id;

 pat_rec_var                     pat_rec_cur%ROWTYPE;

 CURSOR Dental_iotn_Config IS
 SELECT * 
 FROM ORTHODONTIC_DETAILS_TAB o 
 WHERE o.Source_Seq_Id=v_parent_pat_auth_seq_id ;  

 Dental_iotn                   Dental_iotn_Config%ROWTYPE;
 
 CURSOR shrtfal_cnt
 IS
 SELECT COUNT(1)
 FROM   app.shortfall_details a
 WHERE  A.PAT_GEN_DETAIL_SEQ_ID = v_parent_pat_auth_seq_id;
    
  v_shrt_count          NUMBER(5);
 
  CURSOR doc_cnt_cur
  IS
  SELECT COUNT(1)
  FROM  APP.PAT_CLM_DOCS_TAB A
  WHERE A.PAT_CLM_SEQ_ID = v_parent_pat_auth_seq_id AND UPPER(TRIM(A.SOURCE_ID)) = 'PAT';
  
  
  CURSOR cur_corporate_name IS
    SELECT UPPER(TRIM(REPLACE(R.GROUP_NAME,' ',''))) AS CORP_NAME
    FROM TPA_ENR_POLICY_MEMBER M
    JOIN TPA_ENR_POLICY_GROUP G ON G.POLICY_GROUP_SEQ_ID = M.POLICY_GROUP_SEQ_ID
    JOIN TPA_GROUP_REGISTRATION R ON R.GROUP_REG_SEQ_ID = G.GROUP_REG_SEQ_ID
    WHERE M.MEMBER_SEQ_ID = v_member_seq_id;
   
  v_doc_cnt           NUMBER(5);

 -----------------------  
   pat_rec pat_cur%ROWTYPE;
   v_count          number(10);
   clin_rec        clinician_cur%rowtype;
   mem_rec         mem_cur%ROWTYPE;
   balance_rec                  prev_balance_cur%ROWTYPE;
   v_denial_reason pat_authorization_details.denial_reason%type;
   v_denial_code     pat_authorization_details.denial_code%type;
   v_parent_pat_rcvd_date   pat_authorization_details.pat_received_date%type;
   v_parent_completed_yn    varchar2(2);
   v_pat_status_type_id     pat_authorization_details.pat_status_type_id%type;
   v_parent_app_sum_insured pat_general_details.app_sum_insured%TYPE;
   V_shortfall_count       number;
   v_prod_policy_rule_seq_id number;
   --l_benifit_type            VARCHAR2(100);
   
   v_docs_seq_id NUMBER;
   v_doc_gen_type VARCHAR2(10);
   v_docs_path    VARCHAR2(100);
   l_rows_processed NUMBER;
   v_length         NUMBER;
   v_dest_msg_seq_id NUMBER;
   v_seq_id          NUMBER;
   v_pat_seq_id      NUMBER;
   v_cor_name        VARCHAR2(1000);
   v_pre_auth_number varchar2(100);
   v_appeal_cnt      number(3);
   
   
   CURSOR  Get_Parent_preauth_number IS 
    SELECT p.pre_auth_number,p.appeal_count,p.appeal_yn,p.appeal_date
        FROM PAT_AUTHORIZATION_DETAILS P
         WHERE P.PAT_AUTH_SEQ_ID=v_parent_pat_auth_seq_id;
         
   Get_Parent_preauth_rec Get_Parent_preauth_number%rowtype;      
BEGIN
 
  OPEN mem_cur;
  FETCH mem_cur
    INTO mem_rec;
  CLOSE mem_cur;

  OPEN pat_cur(v_pat_auth_seq_id);
  FETCH pat_cur
    INTO pat_rec;
  CLOSE pat_cur;

  OPEN clinician_cur;
  FETCH clinician_cur
    INTO clin_rec;
  CLOSE clinician_cur;
  
  OPEN clinician_count_cur;
  FETCH clinician_count_cur
    INTO v_count;
  CLOSE clinician_count_cur;
  
    OPEN prev_balance_cur;
    FETCH prev_balance_cur INTO balance_rec;
    CLOSE prev_balance_cur;
  
  OPEN cur_corporate_name;
  FETCH cur_corporate_name INTO v_cor_name;
  CLOSE cur_corporate_name;
   
  IF pat_rec.completed_yn = 'Y' AND v_enhance_yn = 'N' THEN
    RAISE_APPLICATION_ERROR(-20107,
                            'You cannot perform this action through a completed Claim.');
  END IF;
    
  IF NVL(V_PAT_AUTH_SEQ_ID, 0) != 0 AND v_enhance_yn = 'Y' THEN 
    v_pat_status_type_id := 'INP';
    OPEN enh_pat_cur;
    FETCH enh_pat_cur INTO enh_pat_rec;
    CLOSE enh_pat_cur;
    
 /* OPEN icd_cur;
  FETCH icd_cur INTO v_icd_count;
  CLOSE icd_cur;
      
  IF v_icd_count = 0 THEN
    RAISE_APPLICATION_ERROR(-20923,'Primary ICD required to complete the preauth/ claim.');
  END IF;*/
    
    OPEN pat_cur(enh_pat_rec.pat_auth_seq_id);
    FETCH pat_cur INTO pat_rec;
    CLOSE pat_cur;
    
    IF pat_rec.completed_yn = 'Y' AND pat_rec.pat_enhanced_yn = 'N' AND pat_rec.pat_status_type_id = 'APR' THEN
      authorization_pkg.save_enhanced_preauth(v_pat_seq_id, enh_pat_rec.pat_auth_seq_id, 1);
    END IF;
  END IF;  
  -----------
  IF mem_rec.member_seq_id IS NULL THEN
    RAISE_APPLICATION_ERROR(-20370, 'Patient is not a covered member');
 /* ELSIF v_hospitalization_date < mem_rec.date_of_inception THEN
    RAISE_APPLICATION_ERROR(-20371,
                            'Services performed prior to the effective date of coverage');*/
    --commented to validate in global rule level
  /*ELSIF v_hospitalization_date > mem_rec.Date_Of_Exit THEN
    RAISE_APPLICATION_ERROR(-20373,
                            'Services performed after the last date of coverage');*/
  END IF;
  
 /* IF v_count=0 Then 
      RAISE_APPLICATION_ERROR(-20381,
                            'Clinician is not exist under this provider,please check with Network department');
  END IF;*/
  
  /*IF clin_rec.hosp_seq_id!=v_hosp_seq_id Then 
      RAISE_APPLICATION_ERROR(-20382,
                            'This Clinician is exist under some other provider ,please check with Network department');
  END IF;*/
  /*FOR rec IN pat_dup_cur LOOP
    IF trunc(rec.hospitalization_date) = trunc(v_hospitalization_date) and nvl(v_selection_type,'PAT')!='ENH' THEN
      RAISE_APPLICATION_ERROR(-20372, 'Duplicate Preauth');
    END IF;
  END LOOP;*/
  
   IF nvl(v_parent_pat_auth_seq_id,0)!=0  THEN
     
     OPEN   check_clm_yn_cur(v_parent_pat_auth_seq_id);
     FETCH  check_clm_yn_cur  into rec_clm_yn;
     CLOSE  check_clm_yn_cur;
     
      update pat_authorization_details ad set ad.pat_enhance_seq=pat_enhance_seq.nextval
      where ad.pat_auth_seq_id =v_parent_pat_auth_seq_id;
      commit;
     
     
     IF rec_clm_yn > 0 THEN 
      
     ----error code need to change
      
     RAISE_APPLICATION_ERROR(-20949,'You can''t perform this action as pre_auth is linked to claim');
     
     END IF;
     
/*  OPEN icd_cur;
  FETCH icd_cur INTO v_icd_count;
  CLOSE icd_cur;
      
  IF v_icd_count = 0 THEN
    RAISE_APPLICATION_ERROR(-20923,'Primary ICD required to complete the preauth/ claim.');
  END IF;*/
    
     
      SELECT a.pat_received_date, a.completed_yn,a.tot_approved_amount
         INTO v_parent_pat_rcvd_date ,v_parent_completed_yn,v_parent_app_sum_insured
         FROM pat_authorization_details a
         WHERE a.pat_auth_seq_id = v_parent_pat_auth_seq_id ;

      IF v_pat_received_date < v_parent_pat_rcvd_date THEN
        raise_application_error(-20383,'Enhancement received date/time should not be less than original preauth received date/time.');
      END IF;

      IF NVL(V_PAT_AUTH_SEQ_ID, 0) = 0  THEN
        v_pat_status_type_id := 'INP';
        IF v_parent_completed_yn = 'N' THEN
          raise_application_error(-20384,' Please Complete the parent Pre_auth First ');
        END IF;
        IF v_member_seq_id IS NOT NULL THEN
          UPDATE tpa_enr_balance a SET
            a.utilised_sum_insured = a.utilised_sum_insured - nvl(v_parent_app_sum_insured,0),
            a.updated_by                   = v_added_by,
            a.updated_date                 = SYSDATE
            WHERE a.balance_seq_id = balance_rec.balance_seq_id;
        END IF;
      END IF;
    END IF; 
  IF NVL(V_PAT_AUTH_SEQ_ID, 0) = 0  THEN
    IF v_pl_preauth_refno IS NULL AND upper(v_enhance_yn) = 'N' THEN ---Not for enhance case
       v_pl_preauth_refno := generate_id_numbers('PL');
                                             
    END IF;
    
    IF nvl(v_parent_pat_auth_seq_id,0)=0 then --- NEWLY ADDED TO AVOID PARTIAL SAVE PREAUTHS
      
         v_pre_auth_number := authorization_pkg.generate_id_numbers('PA',
                                                          mem_rec.short_name,
                                                          mem_rec.state_type_id,
                                                          v_pre_auth_number); 
     ELSE 
       
        OPEN Get_Parent_preauth_number;
          FETCH Get_Parent_preauth_number INTO Get_Parent_preauth_rec ;
            CLOSE Get_Parent_preauth_number;
                 
     END IF;
    
    INSERT INTO PAT_AUTHORIZATION_DETAILS
      (pat_auth_seq_id,
       parent_pat_auth_seq_id,
       pat_received_date,
       discharge_date,
       source_type_id,
       hospitalization_date,
       member_seq_id,
       tpa_enrollment_id,
       auth_number,
       mem_name,
       mem_age,
       ins_seq_id,
       hosp_seq_id,
       policy_seq_id,
       tpa_office_seq_id,
       emirate_id,
       encounter_type_id,
       encounter_facility_id,
       encounter_start_type,
       encounter_end_type,
       ava_sum_insured,
       remarks,
       denial_reason,
       pat_enhanced_yn,
       currency_type,
       maternity_yn,
       pat_status_type_id,
       clinician_id,
       system_of_medicine_type_id,
       accident_related_type_id,
       added_by,
       added_date,
       priority_general_type_id,
       network_yn,
       requested_amount,
       benifit_type,
       gravida,
       para,
       live,
       abortion,
       past_history   ,
       dur_ailment,--duration_above_illness ,
       duration_flag,--duration_above_illness_time ,
       since_when ,
       since_when_time,
       clinician_speciality,
       consultation_type,
       pl_preauth_refno,
       presenting_complaints,
       file_name,
       lmp_date,
       conception_type,
       treatment_type,
       delvry_mod_type,
       req_amt_currency_type,
       converted_amount_currency_type,
       conversion_rate,
       event_no,
       pre_auth_number,
       appeal_count,
       appeal_yn,
       appeal_date
         )
    VALUES
      (pat_auth_detail_seq.nextval,
       nvl(v_parent_pat_auth_seq_id,0),
       v_pat_received_date,
       NVL(v_discharge_date, v_hospitalization_date),
       NVL(v_source_type_id, 'PLPR'),
       v_hospitalization_date,
       v_member_seq_id,
       v_tpa_enrollment_id,
       --v_pre_auth_number,
       v_auth_number,
       nvl(v_mem_name, mem_rec.mem_name),
       nvl(v_mem_age, mem_rec.mem_age),
       v_ins_seq_id,
       v_hosp_seq_id,
       nvl(v_policy_seq_id, mem_rec.policy_seq_id),
       1,
       v_emirate_id,
       v_encounter_type_id,
       v_encounter_facility_id,
        case when UPPER(v_benifit_type) NOT IN ('DNTL', 'Dental','IMTI','OMTI') then v_encounter_start_type else 1 end,
       v_encounter_end_type,
       v_ava_sum_insured,
       v_remarks,
       v_denial_reason,
       'N',
       v_currency_type,
       case when nvl(v_benifit_type,'A') IN ('MTI', 'OMTI', 'IMTI') THEN 'Y' ELSE 'N' end,
       'INP',
       v_clinician_id,
       v_system_of_medicine_type_id,
       v_accident_related_type_id,
       v_added_by,
       SYSDATE,
       CASE WHEN v_cor_name LIKE 'ALJAZEERAMEDIANETWORK%' THEN 'HIG' ELSE v_priority_gen_type_id END,
       v_network_yn,
       v_requested_amount,
       v_benifit_type,
       v_gravida,
       v_para,
       v_live,
       v_abortion,
       v_past_history   ,
       v_duration_above_illness ,
       v_duration_above_illness_time ,
       v_since_when ,
       v_since_when_time,
       v_clinician_speciality,
       v_consultation_type,
       v_pl_preauth_refno,
       v_presenting_comp,
       null,
       v_date_of_lmp,
       v_conception_type,
       case when v_benifit_type IN ('DNTL', 'Dental') then v_encounter_start_type else null end,
       v_delvy_mode,
       'QAR',
       'QAR',
       1,
       v_event_no,
       Get_Parent_preauth_rec.Pre_Auth_Number,
       Get_Parent_preauth_rec.Appeal_Count,
       Get_Parent_preauth_rec.Appeal_Yn,
       Get_Parent_preauth_rec.Appeal_Date
       )
      RETURNING pat_auth_seq_id INTO v_pat_auth_seq_id;
   
    --IF v_network_yn = 'N' then
      INSERT INTO PAT_NON_NETWORK_DETAILS
        (PAT_NON_NETWORK_SEQ_ID,
         PAT_AUTH_SEQ_ID,
         PROVIDER_NAME,
         PROVIDER_ID,
         CITY_TYPE_ID,
         STATE_TYPE_ID,
         COUNTRY_TYPE_ID,
         PROVIDER_ADDRESS,
         PINCODE,
         ADDED_BY,
         ADDED_DATE,
         CLINICIAN_ID,
         CLINICIAN_NAME)
      values
        (PAT_NON_NETWORK_DETAILS_SEQ.nextval,
         v_pat_auth_seq_id,
         v_provider_name,
         v_provider_id,
         v_city_type_id,
         v_state_type_id,
         v_country_type_id,
         v_provider_address,
         v_pincode,
         v_added_by,
         sysdate,
         v_clinician_id,
         v_clinician_name
         );
    --end if;
    -- Assign to System
    authorization_pkg.reassign_user('|'||v_pat_auth_seq_id||'|',null,null,v_added_by,'AUT',v_seq_id);
    IF v_selection_type = 'ENH' THEN--enhancement
           UPDATE pat_authorization_details d SET
             d.pat_enhanced_yn = 'Y',
             d.pat_status_type_id = 'APR'            
             WHERE d.pat_auth_seq_id = v_parent_pat_auth_seq_id ;
             
    ----****newly added******----- 
           
      OPEN   enh_pre_auth_no_cur(v_parent_pat_auth_seq_id);
      FETCH  enh_pre_auth_no_cur  into enh_pat_no_rec;
      CLOSE  enh_pre_auth_no_cur;
    
       ----updating preauth number from parent preauth to fresh enhance pre auth 
     UPDATE  app.pat_authorization_details a 
      SET    a.pre_auth_number         = enh_pat_no_rec.pre_auth_number,
             a.ptnr_seq_id             = enh_pat_no_rec.ptnr_seq_id,
             a.onl_pat_auth_seq_id     = enh_pat_no_rec.onl_pat_auth_seq_id,
             a.onl_pre_auth_refno      = enh_pat_no_rec.onl_pre_auth_refno,
             a.override_remarks        = enh_pat_no_rec.override_remarks,
             a.internal_remarks        = enh_pat_no_rec.internal_remarks,
             a.medical_opinion_remarks = enh_pat_no_rec.medical_opinion_remarks,
             a.xml_seq_id              = enh_pat_no_rec.xml_seq_id,
             a.pbm_yn                  = enh_pat_no_rec.pbm_yn,
             a.status_code_id          = enh_pat_no_rec.status_code_id,
             a.risk_level              = enh_pat_no_rec.risk_level,
             a.code_added_by           = v_added_by,
             a.code_remarks            = enh_pat_no_rec.code_remarks,
             a.code_added_date         = enh_pat_no_rec.code_added_date,
             a.suspect_veri_check      = enh_pat_no_rec.suspect_veri_check,
             a.appeal_yn               = enh_pat_no_rec.appeal_yn,
             a.appeal_count            = enh_pat_no_rec.appeal_count,
             a.appeal_date             =enh_pat_no_rec.appeal_date
                
      WHERE  a.pat_auth_seq_id = v_pat_auth_seq_id;

    ---------------
     OPEN   pat_rec_cur;
     FETCH  pat_rec_cur   INTO  pat_rec_var;
     CLOSE  pat_rec_cur;
    
         IF pat_rec_var.benifit_type='DNTL' THEN
 
             OPEN  Dental_iotn_Config;
             FETCH Dental_iotn_Config INTO Dental_iotn;
             CLOSE Dental_iotn_Config;
 
                INSERT INTO ORTHODONTIC_DETAILS_TAB
                                                  (
                                                   ORTHO_SEQ_ID,
                                                   SOURCE_SEQ_ID,
                                                   SOURCE_FROM,
                                                   DENTO_CLASS_I,
                                                   DENTO_CLASS_II,
                                                   DENTO_CLASS_II_TEXT,
                                                   DENTO_CLASS_III,
                                                   SKELE_CLASS_I,
                                                   SKELE_CLASS_II,
                                                   SKELE_CLASS_III,
                                                   OVERJET_MM,
                                                   REV_OVERJET_MM,
                                                   REV_OVERJET_YN,
                                                   CROSSBITE_ANT,
                                                   CROSSBITE_POST,
                                                   CROSSBITE_BETW,
                                                   OPENBIT_ANT,
                                                   OPENBIT_POST,
                                                   OPENBIT_LATE,
                                                   CONT_POINT_DISP,
                                                   OVERBIT_DEEP,
                                                   OVERBIT_PATA,
                                                   OVERBIT_GING,
                                                   HYPO_QUAD1,
                                                   HYPO_QUAD2,
                                                   HYPO_QUAD3,
                                                   HYPO_QUAD4,
                                                   OTHERS_IMPEDED,
                                                   OTHERS_IMPACT,
                                                   OTHERS_SUBMERG,
                                                   OTHERS_SUPERNUM,
                                                   OTHERS_RETAINE,
                                                   OTHERS_ECTOPIC,
                                                   OTHERS_CRANIO,
                                                   AC_MARKS,
                                                   CROSSBITE_ANT_MM,
                                                   CROSSBITE_PRST_MM,
                                                   CROSSBITE_BETW_MM,
                                                   CONT_POINT_DISP_MM,
                                                   DENTO_CLASS_III_TEXT,
                                                   IOTN_REMARK
                                                  ) 
                                           VALUES 
                                                 (
                                                  NULL,
                                                  v_pat_auth_seq_id,
                                                  Dental_iotn.SOURCE_FROM,
                                                  Dental_iotn.DENTO_CLASS_I,
                                                  Dental_iotn.DENTO_CLASS_II,
                                                  Dental_iotn.DENTO_CLASS_II_TEXT,
                                                  Dental_iotn.DENTO_CLASS_III,
                                                  Dental_iotn.SKELE_CLASS_I,
                                                  Dental_iotn.SKELE_CLASS_II,
                                                  Dental_iotn.SKELE_CLASS_III,
                                                  Dental_iotn.OVERJET_MM,
                                                  Dental_iotn.REV_OVERJET_MM,
                                                  Dental_iotn.REV_OVERJET_YN,
                                                  Dental_iotn.CROSSBITE_ANT,
                                                  Dental_iotn.CROSSBITE_POST,
                                                  Dental_iotn.CROSSBITE_BETW,
                                                  Dental_iotn.OPENBIT_ANT,
                                                  Dental_iotn.OPENBIT_POST,
                                                  Dental_iotn.OPENBIT_LATE,
                                                  Dental_iotn.CONT_POINT_DISP,
                                                  Dental_iotn.OVERBIT_DEEP,
                                                  Dental_iotn.OVERBIT_PATA,
                                                  Dental_iotn.OVERBIT_GING,
                                                  Dental_iotn.HYPO_QUAD1,
                                                  Dental_iotn.HYPO_QUAD2,
                                                  Dental_iotn.HYPO_QUAD3,
                                                  Dental_iotn.HYPO_QUAD4,
                                                  Dental_iotn.OTHERS_IMPEDED,
                                                  Dental_iotn.OTHERS_IMPACT,
                                                  Dental_iotn.OTHERS_SUBMERG,
                                                  Dental_iotn.OTHERS_SUPERNUM,
                                                  Dental_iotn.OTHERS_RETAINE,
                                                  Dental_iotn.OTHERS_ECTOPIC,
                                                  Dental_iotn.OTHERS_CRANIO,
                                                  Dental_iotn.AC_MARKS,
                                                  Dental_iotn.CROSSBITE_ANT_MM,
                                                  Dental_iotn.CROSSBITE_PRST_MM,
                                                  Dental_iotn.CROSSBITE_BETW_MM,
                                                  Dental_iotn.CONT_POINT_DISP_MM,
                                                  Dental_iotn.DENTO_CLASS_III_TEXT,
                                                  Dental_iotn.IOTN_REMARK
                                                );
            
           
         END IF;
         
         
      OPEN   shrtfal_cnt;
      FETCH  shrtfal_cnt   INTO v_shrt_count;-----SHORTFALL AVAILABLE FOR PREAUTH OR NOT
      CLOSE  shrtfal_cnt;
      
    IF   v_shrt_count > 0 THEN  -----
    
       INSERT INTO APP.SHORTFALL_DETAILS
                                       (
								                  SHORTFALL_SEQ_ID,
								                  PAT_GEN_DETAIL_SEQ_ID,
							                  	CLAIM_SEQ_ID,
								                  SHORTFALL_ID,
							                    SRTFLL_GENERAL_TYPE_ID,
								                  SRTFLL_SENT_DATE,
							                    SRTFLL_STATUS_GENERAL_TYPE_ID,
							                    SRTFLL_RECEIVED_DATE,
							                	  SRTFLL_REASON_GENERAL_TYPE_ID,
								                  REMARKS,
								                  SHORTFALL_QUESTIONS,
								                  ENTERED_DATE,
								                  DOCUMENT_GENERATED_YN,
								                  DOCUMENT_SENT_YN,
							                  	 DOCUMENT_PATH,
								                  LAST_REMINDER_LOG_SEQ_ID,
								                  REMINDER_COUNT,
								                  CLOSED_DATE,
							                	  SHORTFALL_RAISED_BY,
								                  ADD_CLAUSE_NUMBER,
								                  SHORTFALL_RAISED_FOR,
								                  CLAUSE_SEQ_ID,
								                  UPLOADED_FILE,
								                  DOCS_STATUS,
							                	  FILE_NAME,
								                  ADDED_BY,
                                  ADDED_DATE,
                                  UPDATED_BY,
                                  UPDATED_DATE
								                )
								 
                 SELECT       shortfall_details_seq.NEXTVAL,
				                      v_pat_auth_seq_id,
							                NULL,
				                      A.SHORTFALL_ID,
                              A.SRTFLL_GENERAL_TYPE_ID,
                              A.SRTFLL_SENT_DATE,
                              A.SRTFLL_STATUS_GENERAL_TYPE_ID,
                              A.SRTFLL_RECEIVED_DATE,      
                              A.SRTFLL_REASON_GENERAL_TYPE_ID,
                              A.REMARKS,
                              A.SHORTFALL_QUESTIONS,
                              A.ENTERED_DATE,
                              A.DOCUMENT_GENERATED_YN,
                              A.DOCUMENT_SENT_YN,
                              A.DOCUMENT_PATH,
                              A.LAST_REMINDER_LOG_SEQ_ID,
                              A.REMINDER_COUNT,
                              A.CLOSED_DATE,
                              A.SHORTFALL_RAISED_BY,                                                                                                                                                 
                              A.ADD_CLAUSE_NUMBER,
                              A.SHORTFALL_RAISED_FOR,
                              A.CLAUSE_SEQ_ID,
                              A.UPLOADED_FILE,
                              A.DOCS_STATUS,
                              A.FILE_NAME,
                              A.ADDED_BY,----
                              A.ADDED_DATE,----
                              A.UPDATED_BY,----
                              A.UPDATED_DATE-----
       
                FROM APP.SHORTFALL_DETAILS A
			         	WHERE A.PAT_GEN_DETAIL_SEQ_ID = v_parent_pat_auth_seq_id;
    END IF;
      
        -- Copying previous diagnosis details
       FOR I IN (SELECT * FROM diagnosys_details dd
                      WHERE dd.pat_auth_seq_id = v_parent_pat_auth_seq_id) loop 
         INSERT INTO diagnosys_details(diag_seq_id,pat_auth_seq_id,icd_code_seq_id,diagnosys_code,primary_ailment_yn,added_by,added_date)
         VALUES (diagnosys_detail_seq.nextval,v_pat_auth_seq_id,I.icd_code_seq_id,I.diagnosys_code,I.primary_ailment_yn,v_added_by,sysdate);
       END LOOP;
          
          --Copying activity details 
          FOR I IN (SELECT * FROM pat_activity_details
                      WHERE pat_auth_seq_id = v_parent_pat_auth_seq_id)
          LOOP
          INSERT INTO pat_activity_details(activity_dtl_seq_id,pat_auth_seq_id,Activity_Seq_Id,activity_id,s_no,start_date,activity_type,code,
                      unit_type,modifier,internal_code,package_id,bundle_id,quantity,gross_amount,discount_amount,disc_gross_amount,patient_share_amount,
                      copay_amount,co_ins_amount,deduct_amount,out_of_pocket_amount,net_amount,allowed_amount,approved_amount,allow_yn,denial_code,
                      remarks,added_by,added_date,denial_desc,approvd_quantity,unit_price,service_type,service_code,converted_acitivty_amt,tooth_no,override_yn,
                      override_remarks,internal_desc,Unit_Discount_Amount,clinician_id,Override_Remarks_Code,Other_Remarks,tpa_denial_code,tpa_denial_desc)
          VALUES (pat_activity_detail_seq.nextval,v_pat_auth_seq_id,i.activity_seq_id,i.activity_id,i.s_no,i.start_date,i.activity_type,i.code,i.unit_type,
                 i.modifier,i.internal_code,i.package_id,i.bundle_id,i.quantity,i.gross_amount,i.discount_amount,i.disc_gross_amount,i.patient_share_amount,i.copay_amount,
                 i.co_ins_amount,i.deduct_amount,i.out_of_pocket_amount,i.net_amount,i.allowed_amount,i.allowed_amount,i.allow_yn,i.denial_code,i.remarks,v_added_by,
                 SYSDATE,i.denial_desc,i.approvd_quantity,i.unit_price,i.service_type,i.service_code,i.converted_acitivty_amt,i.tooth_no,i.override_yn,
                     i.override_remarks,i.internal_desc,i.Unit_Discount_Amount,i.clinician_id,i.Override_Remarks_Code,i.Other_Remarks,i.tpa_denial_code,i.tpa_denial_desc);
            
           FOR J IN (SELECT * FROM app.pat_observation_details od 
               where od.activity_dtl_seq_id=i.activity_dtl_seq_id) loop
              INSERT INTO pat_observation_details(observation_seq_id,activity_dtl_seq_id,observation_type_id,observation_code_id,value,
                  obs_value_type_id,added_by,added_date,remarks )
           VALUES (pat_observation_detail_seq.Nextval,j.activity_dtl_seq_id,j.observation_type_id,j.observation_code_id,j.value,j.obs_value_type_id,
                  v_added_by,sysdate,j.remarks);
           END LOOP;   
        END LOOP;
        
         ------******COPYING PREVIOUS PRE AUTH DOC ******----- 
  
   OPEN   doc_cnt_cur;
   FETCH  doc_cnt_cur  INTO  v_doc_cnt;
   CLOSE  doc_cnt_cur;
   
       IF    v_doc_cnt  > 0 THEN 
  
         FOR I IN (SELECT * FROM PAT_CLM_DOCS_TAB a
                              WHERE a.PAT_CLM_SEQ_ID = v_parent_pat_auth_seq_id
                                   AND   UPPER(TRIM(a.SOURCE_ID)) = 'PAT')  LOOP
              
            INSERT INTO APP.PAT_CLM_DOCS_TAB
                                         (
								                           DOCS_SEQ_ID,
                                           PAT_CLM_SEQ_ID,
                                           SOURCE_ID,
                                           FILE_DESC,
                                           FILE_NAME,
                                           FILE_PATH,
                                           IMAGE_FILE,
                                           ADDED_DATE,
                                           ADDED_BY,
                                           UPDATED_DATE,
                                           UPDATED_BY,
                                           REFERENCE_SEQ_ID,
                                           REFERENCE_FROM	
								                         )
					                        VALUES
                                        (
                                           pat_clm_docs_seq.nextval,
                                           v_pat_auth_seq_id,
                                           I.SOURCE_ID,
                                           I.FILE_DESC,
                                           I.FILE_NAME,
                                           I.FILE_PATH,
                                           I.IMAGE_FILE,
                                           I.ADDED_DATE,
                                           I.ADDED_BY,
                                           I.UPDATED_DATE,
                                           I.UPDATED_BY,
                                           I.REFERENCE_SEQ_ID,
                                           I.REFERENCE_FROM
								                         );
          END LOOP;
     
      END IF;-----DOC
      ------ COPYING CFD TAGGING & CONFIRMATION DETAILS
       FOR K IN (SELECT * FROM tpa_fraud_inv_details
                            WHERE pat_auth_seq_id = v_parent_pat_auth_seq_id ORDER BY inv_seq_id) LOOP
        INSERT INTO tpa_fraud_inv_details(inv_seq_id,inv_status,inv_out_category,amt_util_for_inv,amount_saved,cfd_remarks,inv_start_date,added_date,
                                          added_by,pat_auth_seq_id,claim_seq_id )
          VALUES (app.tpa_inv_seq.nextval,k.inv_status,k.inv_out_category,k.amt_util_for_inv,k.amount_saved,k.cfd_remarks,k.inv_start_date,k.added_date,
                                          v_added_by,v_pat_auth_seq_id,k.claim_seq_id);
        END LOOP;
    END IF;
 
  ELSE
    
    UPDATE pat_authorization_details
       SET parent_pat_auth_seq_id     = nvl(v_parent_pat_auth_seq_id,0),
           pat_received_date          = v_pat_received_date,
           discharge_date             = NVL(v_discharge_date, v_hospitalization_date),
           --source_type_id             = v_source_type_id,
           hospitalization_date       = v_hospitalization_date,
           member_seq_id              = v_member_seq_id,
           tpa_enrollment_id          = v_tpa_enrollment_id,
           auth_number                = v_auth_number,
           mem_name                   = v_mem_name,
           mem_age                    = v_mem_age,
           ins_seq_id                 = v_ins_seq_id,
           hosp_seq_id                = v_hosp_seq_id,
           policy_seq_id              = v_policy_seq_id,
           emirate_id                 = v_emirate_id,
           encounter_type_id          = v_encounter_type_id,
           encounter_facility_id      = v_encounter_facility_id,
           denial_reason              = v_denial_reason,
           encounter_start_type       = case when v_benifit_type NOT IN ('DNTL', 'Dental','IMTI','OMTI') then v_encounter_start_type else 1 end,
           encounter_end_type         = v_encounter_end_type,
           ava_sum_insured            = v_ava_sum_insured,
           remarks                    = v_remarks,
           currency_type              = v_currency_type,
           maternity_yn               = case when nvl(v_benifit_type,'A') IN ('MTI', 'OMTI', 'IMTI') THEN 'Y' ELSE 'N' end,
           pat_status_type_id         = /*case when v_enhance_yn = 'Y' then 'APR' else*/ 'INP' /*end*/,
          -- pat_enhanced_yn            = v_enhance_yn,
           clinician_id               = v_clinician_id,
           system_of_medicine_type_id = v_system_of_medicine_type_id,
           accident_related_type_id   = v_accident_related_type_id,
           updated_by                 = v_added_by,
           updated_date               = sysdate,
           priority_general_type_id   = CASE WHEN v_cor_name LIKE 'ALJAZEERAMEDIANETWORK%' THEN 'HIG' ELSE v_priority_gen_type_id END,
           network_yn                 = v_network_yn,
           requested_amount           = v_requested_amount,
           --benifit_type               = v_benifit_type,
           gravida                    = v_gravida ,
           para                       = v_para,
           live                       = v_live,
           abortion                   = v_abortion,
           denial_code                = v_denial_code,
           past_history               = v_past_history   ,
           dur_ailment                = v_duration_above_illness ,
           duration_flag              = v_duration_above_illness_time ,        
           since_when                  = v_since_when ,
           since_when_time             = v_since_when_time,
           clinician_speciality        = v_clinician_speciality,
           consultation_type           = v_consultation_type,
           presenting_complaints       = v_presenting_comp,
           file_name                   = null,
           lmp_date                    = v_date_of_lmp,
           conception_type             = v_conception_type,
           treatment_type              = case when v_benifit_type IN ('DNTL', 'Dental') then v_encounter_start_type else null end,
           delvry_mod_type             =  v_delvy_mode,
           req_amt_currency_type       = 'QAR',
           converted_amount_currency_type = 'QAR',
           conversion_rate                = 1,
           event_no                    = v_event_no              
     WHERE pat_auth_seq_id             = v_pat_auth_seq_id;
  
  --IF v_network_yn = 'N' then
   update pat_non_network_details set
         provider_name          = v_provider_name,
         provider_id            = v_provider_id,
         city_type_id           = v_city_type_id,
         state_type_id          = v_state_type_id,
         country_type_id        = v_country_type_id,
         provider_address       = v_provider_address,
         pincode                = v_pincode,
         updated_by             = v_added_by,
         updated_date           = sysdate,
         clinician_id           = v_clinician_id,
         clinician_name         = v_clinician_name
         where pat_auth_seq_id = v_pat_auth_seq_id;
  -- end if;
  END IF;
  /*prc_track_error(v_pat_auth_seq_id, 'v_policy_seq_id: '||v_policy_seq_id||CHR(10)||
                                     'mem_rec.policy_seq_id: '||mem_rec.policy_seq_id||CHR(10)||
                                     'v_member_seq_id: '||v_member_seq_id||CHR(10)||
                                     'PROCEDURE: '||'save_pat_details',
                                     'PAT'
                                     );*/
 /* GENERATE_MAIL_PKG.proc_generate_message('PREAUTH_RECEIPT',
                                          v_pat_auth_seq_id,
                                          v_added_by,
                                          v_dest_msg_seq_id);
                                          
  GENERATE_MAIL_PKG.proc_generate_message('PREAUTH_RECEIPT_NHCP',
                                          v_pat_auth_seq_id,
                                          v_added_by,
                                          v_dest_msg_seq_id);     */      
    IF v_image_data IS NOT NULL THEN
      hospital_empanel_pkg.save_mou_docs_info1(0,
                                               v_pat_auth_seq_id,
                                               v_gentype_id ,
                                               v_docs_path,
                                               v_file_name,
                                               v_added_by,
                                               v_image_data,
                                               v_hosp_seq_id,
                                               l_rows_processed
                                              );
                                              
                                              
                               
    END IF;

  v_prod_policy_rule_seq_id := authorization_pkg.get_prod_pol_seq_id(mem_rec.policy_seq_id,
                                                   'POL');
  pat_xml_load_pkg.execute_global_rules('P',
                                        v_pat_auth_seq_id,
                                        v_member_seq_id,
                                        v_prod_policy_rule_seq_id);
  IF v_enhance_yn = 'N' THEN
    check_pat_approved(v_pat_auth_seq_id, v_added_by);
  END IF;
  commit;
END save_pat_details;
-------generate the if for the preauth Ref no -----------
FUNCTION generate_id_numbers (v_flag       IN VARCHAR2
                             ) RETURN VARCHAR2
IS
   v_result                         VARCHAR2(60);
   v_last_number                    VARCHAR2(60);
   
    CURSOR rl_cur(v_result VARCHAR2) IS 
            SELECT MAX(TO_NUMBER(TRIM(REPLACE(pl_preauth_refno,'PL-',''))))
            FROM pat_authorization_details
           WHERE pl_preauth_refno LIKE v_result||'%';
  
           
    CURSOR pl_no_length(v_number varchar2)
    IS
    SELECT LENGTH(TRIM(REPLACE(v_number,'PL-',''))) A 
    FROM DUAL;
    
    v_length   number;
           
           
BEGIN
  
  IF v_flag = 'PL' THEN -- PREAUTH NUMBER
      v_result := v_flag||'-';

      OPEN rl_cur(v_result);
      FETCH rl_cur INTO v_last_number;
      CLOSE rl_cur;

      IF v_last_number IS NULL THEN
        v_result := v_result || '0001';
      ELSE
        
        OPEN  pl_no_length(v_last_number);
        FETCH pl_no_length  INTO  v_length;
        CLOSE pl_no_length;
        
        v_result := v_result ||LTRIM(LPAD(TO_NUMBER(SUBSTR(v_last_number,-v_length))+1,v_length+1,'0'),'0');
        
       ---- v_result := v_result ||LPAD(TO_NUMBER(SUBSTR(v_last_number,-4))+1,4,'0');
        
      END IF;
   
    END IF;
    RETURN v_result;
  END generate_id_numbers;
--===================================
--select preath
--added on 5th JAN 2017-----
---=====================================================  
PROCEDURE select_pat_auth_details (
    v_pat_auth_seq_id                           IN  pat_authorization_details.pat_auth_seq_id%type,
    v_auth_result_set                           OUT SYS_REFCURSOR ,
    v_diag_result_set                           OUT SYS_REFCURSOR ,
    v_activity_result_set                       OUT SYS_REFCURSOR ,
    v_observ_result_set                         OUT SYS_REFCURSOR ,
    v_shortfall_details                         OUT SYS_REFCURSOR ,
    v_drugs_result_set                          OUT SYS_REFCURSOR  )

IS

  CURSOR srtfll_cur IS
    SELECT sd.srtfll_status_general_type_id
    FROM SHORTFALL_DETAILS sd
    WHERE sd.shortfall_seq_id = (SELECT MAX(S.SHORTFALL_SEQ_ID)
                                 FROM SHORTFALL_DETAILS s
                                 WHERE S.PAT_GEN_DETAIL_SEQ_ID = v_pat_auth_seq_id
                                )
    AND sd.PAT_GEN_DETAIL_SEQ_ID = v_pat_auth_seq_id;
	
	v_shrtfll_status                              VARCHAR2(10);
  v_benefit_type                                VARCHAR2(50);
  v_encounter_type                              VARCHAR2(100);
   
 CURSOR encounter_type is  
 select en.description 
 from tpa_encounter_type_codes en
 where en.encounter_seq_id = (select pa.encounter_type_id
                             from pat_authorization_details pa
                             where pa.pat_auth_seq_id = v_pat_auth_seq_id)
 and en.header_type = 'ENCOUNTER_TYPE';
  
BEGIN
 
  OPEN srtfll_cur;
  FETCH srtfll_cur INTO v_shrtfll_status;
  CLOSE srtfll_cur;
  
 select case when pad.benifit_type = 'IPT'   then 'In-Patient'
             when pad.benifit_type = 'OPTS'  then 'Out-Patient'
             when pad.benifit_type = 'OPTC'  then 'Optical'
             when pad.benifit_type = 'IMTI'   then 'In-Patient Maternity'
             when pad.benifit_type = 'OMTI'   then 'Out-Patient Maternity'
             when pad.benifit_type = 'DNTL'  then 'Dental'
             when pad.benifit_type = 'HEAC'  then 'Health Check up'
             when pad.benifit_type = 'DAYC'  then 'Day Care'
          
         end as benefit_type into v_benefit_type
  from pat_authorization_details pad
  where pad.pat_auth_seq_id=v_pat_auth_seq_id; 
  
  OPEN encounter_type;
  FETCH encounter_type into v_encounter_type;
  CLOSE encounter_type;
  
/* select en.description into v_encounter_type
 from tpa_encounter_type_codes en
 where en.encounter_seq_id = (select pa.encounter_type_id
                             from pat_authorization_details pa
                             where pa.pat_auth_seq_id = v_pat_auth_seq_id)
 and en.header_type = 'ENCOUNTER_TYPE';*/
                             
 OPEN v_auth_result_set FOR
   select  tepm.tpa_enrollment_id as tpa_enrolment_id,
         tepm.member_seq_id,
         pad.pat_auth_seq_id,
         tepm.mem_dob,
         tepm.mem_name,
         case when tepm.gender_general_type_id='MAL' then 'MALE' else 'FEMALE' end mem_gender  ,
         pad.hospitalization_date,
         pad.clinician_id,
         nvl(thp.contact_name,pnd.clinician_name) clinician_name, 
         csm.specialty_id as Clinician_Speciality ,
         pad.consultation_type as Consultation_Type ,
         pad.pl_preauth_refno,
         --pb.benefit_name benifit_type,
         --v_encounter_type as encounter_type_id,
         pad.encounter_type_id as encounter_type_id,
         --pad.encounter_type_id,
         pad.encounter_start_type,
         case when upper(pad.benifit_type) in ('DNTL') then pad.treatment_type else to_char(pad.encounter_start_type) end  as treatment_type,
        --- pad.treatment_type,
         pad.presenting_complaints,
         pad.dur_ailment as duration_above_illness,
         pad.discharge_date,
         pad.past_history,
         pad.duration_flag as duration_above_illness_time,
         pad.since_when,
         pad.since_when_time,
         pad.file_name,
         pad.pre_auth_number,
         tepm.emirate_id,
         v_benefit_type as benifit_type_code, --
         pad.authorization_id,
         ins.ins_comp_name as insurance_comp,
         pad.auth_number,
         ins.ins_comp_code_number as payer_id,
         nvl(pad.denial_reason, '-') as comments, ---- Need Conformation
         nvl(pad.tot_approved_amount, 0) as tot_approved_amount,
         DECODE(pad.pat_status_type_id, 'APR', 'Approved', 'INP', 'In-Progress', 'REJ', 'Rejected') as status,
         pad.pat_status_type_id as status_type,
         ep.policy_number as policy_number,
         pad.benifit_type as pre_benifit_type,
         pad.benifit_type as benifit_type,
         pad.lmp_date as date_of_lmp,
         pad.conception_type,
         pad.system_of_medicine_type_id as system_of_medicine,
         pad.delvry_mod_type,
         od.ORTHO_SEQ_ID,
         od.SOURCE_SEQ_ID,
         od.DENTO_CLASS_I,
         od.DENTO_CLASS_II,
         od.DENTO_CLASS_II_TEXT,
         od.DENTO_CLASS_III,
         od.DENTO_CLASS_III_TEXT,
         od.SKELE_CLASS_I,
         od.SKELE_CLASS_II,
         od.SKELE_CLASS_III,
         od.OVERJET_MM,
         od.REV_OVERJET_MM,
         od.REV_OVERJET_YN,
         od.CROSSBITE_ANT,
         od.CROSSBITE_POST,
         od.CROSSBITE_BETW,
         od.OPENBIT_ANT,
         od.OPENBIT_POST,
         od.OPENBIT_LATE,
         od.CONT_POINT_DISP,
         od.OVERBIT_DEEP as OVERBITE,
         od.OVERBIT_COMP,
         od.OVERBIT_INCOMP,
         od.OVERBIT_PATA,
         od.OVERBIT_GING,
         od.HYPO_QUAD1,
         od.HYPO_QUAD2,
         od.HYPO_QUAD3,
         od.HYPO_QUAD4,
         od.OTHERS_IMPEDED,
         od.OTHERS_IMPACT,
         od.OTHERS_SUBMERG,
         od.OTHERS_SUPERNUM,
         od.OTHERS_RETAINE,
         od.OTHERS_ECTOPIC,
         od.OTHERS_CRANIO,
         od.AC_MARKS,
         od.iotn_remark as iotn,
         od.crossbite_ant_mm,
         od.crossbite_prst_mm,
         od.crossbite_betw_mm,
         od.cont_point_disp_mm,
         pad.event_no as event_no,
         to_char(pad.completed_date,'dd/mm/yyyy hh:mi Am') as decision_date,
         to_char(pad.pat_received_date,'dd/mm/yyyy hh:mi Am') as submission_date,
         CASE     WHEN upper(pad.pat_status_type_id) = 'INP' 
                  AND  pad.parent_pat_auth_seq_id is not null 
                  AND  pad.parent_pat_auth_seq_id != 0 THEN 
                'Y'
         ELSE 
                'N'
           END AS SUBMIT_EN, -----NEWLY ADDED FOR ENHANCE PREAUTH
         PAD.PAT_STATUS_TYPE_ID||'-'||COALESCE(v_shrtfll_status, CASE WHEN PAD.APPEAL_YN = 'Y' THEN 'APL' END, (CASE WHEN NVL(PAD.PARENT_PAT_AUTH_SEQ_ID, 0) > 0 THEN 'ENH' END)) AS IN_PROGESS_STATUS,
         PAD.APPEAL_REMARK,
         CASE WHEN length(dc.image_file) > 0 THEN 'Y' ELSE 'N' END AS docs_available_yn,
         PAD.TOT_DISC_GROSS_AMOUNT,
		 PAD.source_type_id
         
         ----------
         
         
  from pat_authorization_details  pad
    left join pat_clm_docs_tab dc on dc.pat_clm_seq_id = pad.pat_auth_seq_id
    left join orthodontic_details_tab od ON (od.source_seq_id = pad.pat_auth_seq_id)
    join tpa_enr_policy ep on (ep.policy_seq_id=pad.policy_seq_id)
    join tpa_ins_product ip on (ip.product_seq_id=ep.product_seq_id)
    left outer join tpa_group_registration gr on (gr.group_reg_seq_id=ep.group_reg_seq_id)
    left outer join tpa_enr_policy_member tepm ON (pad.member_seq_id=tepm.member_seq_id)
    left outer join tpa_enr_policy_group pg on (pg.policy_group_seq_id=tepm.policy_group_seq_id)
    left outer join tpa_hosp_professionals thp   ON (pad.clinician_id=thp.professional_id and  pad.hosp_seq_id=thp.hosp_seq_id)
    left outer join app.tpa_general_code gc on (gc.general_type_id=thp.consult_gen_type)
    left outer join  app.dha_clnsn_specialties_master csm on (csm.specialty_id=thp.speciality_id)
    left outer join app.tpa_general_code ec on (gc.general_type_id=pad.enrol_type_id)
    left outer join APP.TPA_INS_PROD_POLICY pp   on (pp.policy_seq_id=ep.policy_seq_id)
    left outer join tpa_ins_prod_policy_rules pr on (pr.prod_policy_seq_id=pp.prod_policy_seq_id)
    left outer join app.TPA_INS_PROD_POL_BENEFITS pb on (pb.prod_policy_rule_seq_id=pr.prod_policy_rule_seq_id and pb.benefit_name = v_benefit_type)
    join pat_non_network_details pnd on (pnd.pat_auth_seq_id=pad.pat_auth_seq_id)
    JOIN tpa_ins_info ins ON (ins.ins_seq_id = pad.ins_seq_id)
    where pad.pat_auth_seq_id = v_pat_auth_seq_id;--4413 
  
 OPEN v_diag_result_set FOR 
       select dd.diag_seq_id,
             dd.pat_auth_seq_id,
             tic.icd_code as diagnosys_code,
             dd.primary_ailment_yn,
             tic.icd10_seq_id as icd_code_seq_id,
             tic.short_desc as icd_description
        from diagnosys_details dd
        left outer join tpa_icd10_master_details tic on (dd.diagnosys_code=tic.icd_code)
       where dd.pat_auth_seq_id =v_pat_auth_seq_id
   order by dd.diag_seq_id;
  
  OPEN v_activity_result_set FOR 
      select
      ad.activity_dtl_seq_id,
      case when ad.code is not null then ad.code else ad.service_code end as activity_code,
      ad.unit_price as unit_price,
      case when ad.code is not null then nvl(tamd.activity_description,md.activity_description) 
      else
        substr(tis.service_descreption, 1, length(tis.service_descreption) - 8)
      end as activity_description,
      nvl(ad.gross_amount,0) gross_amount ,
      --nvl(ad.approved_amount,0) as approved_amt,
      case when ad.approved_amount is null then nvl((ad.net_amount * ad.quantity), 0) else ad.approved_amount end as approved_amt,
      nvl(ad.discount_amount,0) discount_amount,
      ad.quantity,
      nvl((nvl(ad.net_amount,0)-nvl(ad.patient_share_amount,0)), 0) as net_amount,
      case when nvl(ad.approved_amount, 0) > 0 AND pad.pat_status_type_id = 'APR' then
             'Approved'
           when nvl(ad.approved_amount, 0) <= 0 AND pad.pat_status_type_id = 'APR' then
             'Rejected'
           when pad.pat_status_type_id = 'REJ' then
             'Rejected'
      else
        'Inprogress'
      end as status,
      nvl(ad.patient_share_amount, 0) as patient_share,
      nvl(ad.disc_gross_amount, 0) as disc_gross_amount,
      ad.posology_duration as duration,
      ad.denial_code||' - '||ad.denial_desc as denial,
      nvl(ad.denial_desc, '-') as remarks,
      nvl(ad.internal_code, '-') as internal_code,
      ad.tooth_no,
      ad.internal_desc,
      ad.unit_price,
      ad.override_yn,---NEWLY ADDED PREAUTH ENHANCEMENT
      ad.override_remarks,---NEWLY ADDED PREAUTH ENHANCEMENT
      ad.denial_code,---NEWLY ADDED PREAUTH ENHANCEMENT
      ad.allowed_amount,---NEWLY ADDED PREAUTH ENHANCEMENT
      ad.approved_amount,---NEWLY ADDED PREAUTH ENHANCEMENT
      ad.activity_type_id,---NEWLY ADDED PREAUTH ENHANCEMENT
      nvl(ad.denial_desc, ' ') as denial_desc,  ---NEWLY ADDED PREAUTH ENHANCEMENT
      ad.override_remarks_code, ---NEWLY ADDED OVERRIDE REMARKS LIST CR
      ad.other_remarks          ---NEWLY ADDED OVERRIDE REMARKS LIST CR
      from pat_activity_details ad
      join pat_authorization_details pad on (pad.pat_auth_seq_id = ad.pat_auth_seq_id)
      left outer join tpa_activity_master_details tamd on (ad.code=tamd.activity_code)
      left outer join tpa_pharmacy_master_details md on (ad.code = md.activity_code /*and ad.start_date between md.start_date and md.end_date*/)
      left join tpa_ip_service_details  tis on (tis.service_code=ad.service_code)
      --left outer join app.tpa_ip_service_details isd on (isd.service_code=ad.service_code)
      where ad.pat_auth_seq_id =v_pat_auth_seq_id and nvl(activity_type,0) <>'5' 
     order by s_no;
     
     -----drugs 
     OPEN v_drugs_result_set FOR
     select
      ad.activity_dtl_seq_id, 
      ad.code as ACTIVITY_CODE,
      nvl(tamd.activity_description,md.activity_description) as activity_description,
      nvl(ad.gross_amount, 0) as gross_amount,
      nvl(ad.approved_amount, 0) as approved_amount,
      nvl(ad.disc_gross_amount, 0) as disc_gross_amount ,
      nvl(ad.discount_amount, 0) as discount_amount,
      ad.quantity,
      nvl(ad.disc_gross_amount, 0)/*(ad.disc_gross_amount-ad.patient_share_amount)*/ as net_amount,
       ad.unit_type,
      ad.posology,
       nvl(ad.posology_duration,0) as posology_duration,
      nvl(ad.patient_share_amount, 0) as patient_share,
      ad.denial_code||' - '||ad.denial_desc as denial,
      --trim(replace(wm_concat(ad.remarks), ';')) as remarks
      nvl(ad.denial_desc, '-') as remarks,
      case when nvl(ad.approved_amount, 0) > 0 AND pad.pat_status_type_id = 'APR' then
             'Approved'
           when nvl(ad.approved_amount, 0) <= 0 AND pad.pat_status_type_id = 'APR' then
             'Rejected'
           when pad.pat_status_type_id = 'REJ' then
             'Rejected'
      else
        'Inprogress'
      end as status,
      ad.unit_price 
      
      from pat_activity_details ad
      left join pat_authorization_details pad on (pad.pat_auth_seq_id = ad.pat_auth_seq_id)
      left outer join tpa_activity_master_details tamd on (ad.code=tamd.activity_code)
      left outer join tpa_pharmacy_master_details md on (ad.code = md.activity_code /*and ad.start_date between md.start_date and md.end_date*/)
      --left outer join app.tpa_ip_service_details isd on (isd.service_code=ad.service_code)
      where ad.pat_auth_seq_id =v_pat_auth_seq_id and  activity_type = '5' 
     order by s_no;
     
     
     -----
     
     
  OPEN v_observ_result_set FOR 
       select od.observation_seq_id,
       od.activity_dtl_seq_id,
       od.value,
       od.observation_type_id as type,
       od.obs_value_type_id as value_type_id,
       od.observation_code_id as code 
  from pat_observation_details od
  join pat_activity_details ad on (od.activity_dtl_seq_id=ad.activity_dtl_seq_id)
 where ad.pat_auth_seq_id =v_pat_auth_seq_id;
 
 OPEN v_shortfall_details FOR
   select a.pat_auth_seq_id,
       b.shortfall_seq_id,
       b.shortfall_id,
       c.description as shortfall_type,
       DECODE(b.srtfll_status_general_type_id,'OPN','Open','RES','Responded','CLS','Closed','ORD','Overridden') AS srtfll_status_general_type_id,
       b.srtfll_sent_date
  from pat_authorization_details a
  join shortfall_details b on (a.pat_auth_seq_id=b.pat_gen_detail_seq_id)
  join tpa_general_code c on (c.general_type_id=b.srtfll_general_type_id)
 where a.pat_auth_seq_id =v_pat_auth_seq_id; 
   
END select_pat_auth_details;

------------------=================================================================
PROCEDURE get_benifit_copay_dedu(V_BINIFIT_TYPE VARCHAR2,
                                 V_MEME_ID VARCHAR2,
                                 V_result_set    OUT SYS_REFCURSOR
                               )
  IS
  
  CURSOR  Psychiatric_allowed_cur is 
  select case when nvl(extractvalue(rul.prod_policy_rule,'/clauses/clause/coverage[@id="cvg.23.19"]/@allowed'),0)
         in (1,3) then 'COVERED' else 'NOT-COVERED' end as Psychiatric_allowed
         from tpa_enr_policy_member mem join tpa_enr_policy_group          polg on(polg.POLICY_GROUP_SEQ_ID = mem.POLICY_GROUP_SEQ_ID)
                                        join tpa_enr_policy                pol  on(pol.policy_seq_id        = polg.policy_seq_id)
                                        join tpa_ins_prod_policy           ipol on(ipol.policy_seq_id       = pol.policy_seq_id)
                                        join APP.TPA_INS_PROD_POLICY_RULES rul  on(rul.PROD_POLICY_SEQ_ID   = ipol.PROD_POLICY_SEQ_ID)
         where SYSDATE BETWEEN pol.effective_from_date and pol.effective_to_date and (mem.tpa_enrollment_id = V_MEME_ID or mem.emirate_id=V_MEME_ID) and tpa_enrollment_id=V_MEME_ID;
  v_psychiatric_allowed   varchar2(50);
BEGIN
  /*INSERT INTO TT(NAME) VALUES(V_BINIFIT_TYPE);*/
  
  OPEN Psychiatric_allowed_cur;
  FETCH Psychiatric_allowed_cur INTO v_psychiatric_allowed;
  CLOSE Psychiatric_allowed_cur;

   if V_BINIFIT_TYPE='OPTS' then
   open V_result_set for   
   select 
       --case when  V_BINIFIT_TYPE='OPTS' then  case when nvl(pp.co_ins,0)>0 then to_char(pp.co_ins) else 'Nil' end end as copay,
       --case when  pp.eligibility is not null then pp.eligibility else 'Nil' end as eligibility,
       --case when  V_BINIFIT_TYPE='OPTS' then case when nvl(pp.deductible,NULL)<>NULL then pp.deductible else 'Nil' end end deductible,  
       nvl(to_char(p.co_ins),'Nil')  copay,
       nvl(p.eligibility_yn,'Nil') eligibility,
       nvl(to_char(p.deductable),'Nil') deductible,
       nvl(to_char(p.CO_INS),'Nil')  CO_INS,
       nvl(p.pol_class,'Nil') CLASS,
       nvl(p.pol_plan,'Nil') PLAN,
       nvl(p.maternity_yn,'Nil') MATERNITY_YN,
       nvl(p.maternity_co_pay,'0') MATERNITY_COPAY,
       nvl(p.optical_yn,'Nil') OPTICAL_YN,
       nvl(p.optical_co_pay,'0') OPTICAL_COPAY,
       nvl(p.dental_yn,'Nil') DENTAL_YN,
       nvl(p.dental_co_pay,'0') DENTAL_COPAY,
       nvl(p.ip_op_services,'Nil') IP_OP_SERVICES,
       nvl(p.pharmaceutical,'Nil')  PHARMACEUTICALS,
       v_psychiatric_allowed as Psychiatric_allowed

       from app.tpa_enr_policy p
  join app.tpa_enr_policy_group pg
    on (p.policy_seq_id = pg.policy_seq_id)
  join app.tpa_enr_policy_member pm
    on (pm.policy_group_seq_id = pg.policy_group_seq_id)
  join app.tpa_group_registration gr
    on (p.group_reg_seq_id = gr.group_reg_seq_id)
  join app.tpa_ins_product pp
    on (pp.product_seq_id = p.product_seq_id)
 where SYSDATE BETWEEN p.effective_from_date and p.effective_to_date and  (pm.tpa_enrollment_id = V_MEME_ID or pm.emirate_id=V_MEME_ID);
 
 elsif V_BINIFIT_TYPE='IPT' then 
  
open V_result_set for   
 select 
       --case when  V_BINIFIT_TYPE='IPT' then case when nvl(pp.co_ins,0)>0 then to_char(pp.co_ins) else 'Nil' end end copay,
      -- nvl(to_char(pp.CO_INS),'Nil')   copay,
       --case when pp.eligibility is not null then pp.eligibility else 'Nil' end as eligibility,
       --case when  V_BINIFIT_TYPE='IPT' then case when nvl(pp.deductible,0)>0 then pp.deductible else 'Nil' end end deductible
       nvl(to_char(p.co_ins),'Nil')  copay,
       nvl(p.eligibility_yn,'Nil') eligibility,
       nvl(to_char(p.deductable),'Nil') deductible,
       nvl(to_char(p.CO_INS),'Nil')  CO_INS,
       nvl(p.pol_class,'Nil') CLASS,
       nvl(p.pol_plan,'Nil') PLAN,
       nvl(p.maternity_yn,'Nil') MATERNITY_YN,
       nvl(p.maternity_co_pay,'0') MATERNITY_COPAY,
       nvl(p.optical_yn,'Nil') OPTICAL_YN,
       nvl(p.optical_co_pay,'0') OPTICAL_COPAY,
       nvl(p.dental_yn,'Nil') DENTAL_YN,
       nvl(p.dental_co_pay,'0') DENTAL_COPAY,
       nvl(p.ip_op_services,'Nil') IP_OP_SERVICES,
       nvl(p.pharmaceutical,'Nil')  PHARMACEUTICALS,
       v_psychiatric_allowed as Psychiatric_allowed
         
       from app.tpa_enr_policy p
  join app.tpa_enr_policy_group pg
    on (p.policy_seq_id = pg.policy_seq_id)
  join app.tpa_enr_policy_member pm
    on (pm.policy_group_seq_id = pg.policy_group_seq_id)
  join app.tpa_group_registration gr
    on (p.group_reg_seq_id = gr.group_reg_seq_id)
  join app.tpa_ins_product pp
    on (pp.product_seq_id = p.product_seq_id)
 where SYSDATE BETWEEN p.effective_from_date and p.effective_to_date and  (pm.tpa_enrollment_id = V_MEME_ID or pm.emirate_id=V_MEME_ID);
 elsif V_BINIFIT_TYPE IN ('MTI', 'OMTI', 'IMTI') then 
 open V_result_set for   
   select 
       --case when pp.maternity_yn='Y' and V_BINIFIT_TYPE='MTI' then pp.maternity_copay  else 'Nil' end copay,
       --case when pp.eligibility is not null then pp.eligibility else 'Nil' end as eligibility,
       nvl(to_char(p.co_ins),'Nil')  copay,
       nvl(p.eligibility_yn,'Nil') eligibility,
       nvl(to_char(p.deductable),'Nil') deductible,
       nvl(to_char(p.CO_INS),'Nil')  CO_INS,
       nvl(p.pol_class,'Nil') CLASS,
       nvl(p.pol_plan,'Nil') PLAN,
       nvl(p.maternity_yn,'Nil') MATERNITY_YN,
       nvl(p.maternity_co_pay,'0') MATERNITY_COPAY,
       nvl(p.optical_yn,'Nil') OPTICAL_YN,
       nvl(p.optical_co_pay,'0') OPTICAL_COPAY,
       nvl(p.dental_yn,'Nil') DENTAL_YN,
       nvl(p.dental_co_pay,'0') DENTAL_COPAY,
       nvl(p.ip_op_services,'Nil') IP_OP_SERVICES,
       nvl(p.pharmaceutical,'Nil')  PHARMACEUTICALS,
       v_psychiatric_allowed as Psychiatric_allowed
       from app.tpa_enr_policy p
  join app.tpa_enr_policy_group pg
    on (p.policy_seq_id = pg.policy_seq_id)
  join app.tpa_enr_policy_member pm
    on (pm.policy_group_seq_id = pg.policy_group_seq_id)
  join app.tpa_group_registration gr
    on (p.group_reg_seq_id = gr.group_reg_seq_id)
  join app.tpa_ins_product pp
    on (pp.product_seq_id = p.product_seq_id)
 where SYSDATE BETWEEN p.effective_from_date and p.effective_to_date and  (pm.tpa_enrollment_id = V_MEME_ID or pm.emirate_id=V_MEME_ID);
 
 elsif V_BINIFIT_TYPE='DNTL' then 
 open V_result_set for   
   select 
       --case when V_BINIFIT_TYPE='DNTL' then case when pp.dental_copay is not null then pp.dental_copay else 'Nil' end end copay,
       --case when pp.eligibility is not null then pp.eligibility else 'Nil' end as eligibility,
      nvl(to_char(p.co_ins),'Nil')  copay,
       nvl(p.eligibility_yn,'Nil') eligibility,
       nvl(to_char(p.deductable),'Nil') deductible,
       nvl(to_char(p.CO_INS),'Nil')  CO_INS,
       nvl(p.pol_class,'Nil') CLASS,
       nvl(p.pol_plan,'Nil') PLAN,
       nvl(p.maternity_yn,'Nil') MATERNITY_YN,
       nvl(p.maternity_co_pay,'0') MATERNITY_COPAY,
       nvl(p.optical_yn,'Nil') OPTICAL_YN,
       nvl(p.optical_co_pay,'0') OPTICAL_COPAY,
       nvl(p.dental_yn,'Nil') DENTAL_YN,
       nvl(p.dental_co_pay,'0') DENTAL_COPAY,
       nvl(p.ip_op_services,'Nil') IP_OP_SERVICES,
       nvl(p.pharmaceutical,'Nil')  PHARMACEUTICALS,
       v_psychiatric_allowed as Psychiatric_allowed
       from app.tpa_enr_policy p
  join app.tpa_enr_policy_group pg
    on (p.policy_seq_id = pg.policy_seq_id)
  join app.tpa_enr_policy_member pm
    on (pm.policy_group_seq_id = pg.policy_group_seq_id)
  join app.tpa_group_registration gr
    on (p.group_reg_seq_id = gr.group_reg_seq_id)
  join app.tpa_ins_product pp
    on (pp.product_seq_id = p.product_seq_id)
 where SYSDATE BETWEEN p.effective_from_date and p.effective_to_date and  (pm.tpa_enrollment_id = V_MEME_ID or pm.emirate_id=V_MEME_ID);

  elsif V_BINIFIT_TYPE='OPTC' then 
 open V_result_set for   
   select 
       --case when V_BINIFIT_TYPE='OPTC' then pp.optical_copay end copay,
       nvl(to_char(p.co_ins),'Nil')  copay,
       nvl(p.eligibility_yn,'Nil') eligibility,
       nvl(to_char(p.deductable),'Nil') deductible,
       nvl(to_char(p.CO_INS),'Nil')  CO_INS,
       nvl(p.pol_class,'Nil') CLASS,
       nvl(p.pol_plan,'Nil') PLAN,
       nvl(p.maternity_yn,'Nil') MATERNITY_YN,
       nvl(p.maternity_co_pay,'0') MATERNITY_COPAY,
       nvl(p.optical_yn,'Nil') OPTICAL_YN,
       nvl(p.optical_co_pay,'0') OPTICAL_COPAY,
       nvl(p.dental_yn,'Nil') DENTAL_YN,
       nvl(p.dental_co_pay,'0') DENTAL_COPAY,
       nvl(p.ip_op_services,'Nil') IP_OP_SERVICES,
       nvl(p.pharmaceutical,'Nil')  PHARMACEUTICALS,
       v_psychiatric_allowed as Psychiatric_allowed
       from app.tpa_enr_policy p
  join app.tpa_enr_policy_group pg
    on (p.policy_seq_id = pg.policy_seq_id)
  join app.tpa_enr_policy_member pm
    on (pm.policy_group_seq_id = pg.policy_group_seq_id)
  join app.tpa_group_registration gr
    on (p.group_reg_seq_id = gr.group_reg_seq_id)
  join app.tpa_ins_product pp
    on (pp.product_seq_id = p.product_seq_id)
 where SYSDATE BETWEEN p.effective_from_date and p.effective_to_date and  (pm.tpa_enrollment_id = V_MEME_ID or pm.emirate_id=V_MEME_ID);

  else
 open V_result_set for   
   select 
       'Nil'  copay,
       'Nil' eligibility,
       'Nil' as deductible,
       nvl(to_char(p.CO_INS),'Nil')  CO_INS,
       nvl(p.pol_class,'Nil') CLASS,
       nvl(p.pol_plan,'Nil') PLAN,
       nvl(p.maternity_yn,'Nil') MATERNITY_YN,
       nvl(p.maternity_co_pay,'0') MATERNITY_COPAY,
       nvl(p.optical_yn,'Nil') OPTICAL_YN,
       nvl(p.optical_co_pay,'0') OPTICAL_COPAY,
       nvl(p.dental_yn,'Nil') DENTAL_YN,
       nvl(p.dental_co_pay,'0') DENTAL_COPAY,
       nvl(p.ip_op_services,'Nil') IP_OP_SERVICES,
       nvl(p.pharmaceutical,'Nil')  PHARMACEUTICALS,
       v_psychiatric_allowed as Psychiatric_allowed
       from app.tpa_enr_policy p
  join app.tpa_enr_policy_group pg
    on (p.policy_seq_id = pg.policy_seq_id)
  join app.tpa_enr_policy_member pm
    on (pm.policy_group_seq_id = pg.policy_group_seq_id)
  join app.tpa_group_registration gr
    on (p.group_reg_seq_id = gr.group_reg_seq_id)
  join app.tpa_ins_product pp
    on (pp.product_seq_id = p.product_seq_id)
 where SYSDATE BETWEEN p.effective_from_date and p.effective_to_date and  (pm.tpa_enrollment_id = V_MEME_ID or pm.emirate_id=V_MEME_ID);
 end if;
   
END get_benifit_copay_dedu; 
--===========================This is save the preauth at batch level in provider login 
PROCEDURE save_pat_details_app_level
                          (v_pat_auth_seq_id            in out pat_authorization_details.pat_auth_seq_id%type,
                           v_parent_pat_auth_seq_id     in pat_authorization_details.parent_pat_auth_seq_id%type,
                           v_pat_received_date          in pat_authorization_details.pat_received_date%type,
                           v_discharge_date             IN pat_authorization_details.discharge_date%type,
                           v_source_type_id             in pat_authorization_details.source_type_id%type,
                           v_hospitalization_date       in pat_authorization_details.hospitalization_date%type,
                           v_member_seq_id              in pat_authorization_details.member_seq_id%type,
                           v_tpa_enrollment_id          in pat_authorization_details.tpa_enrollment_id%type,
                           v_pre_auth_number            in out pat_authorization_details.pre_auth_number%type,
                           v_auth_number                in pat_authorization_details.auth_number%type,
                           v_mem_name                   in pat_authorization_details.mem_name%type,
                           v_mem_age                    in pat_authorization_details.mem_age%type,
                           v_ins_seq_id                 in pat_authorization_details.ins_seq_id%type,
                           v_hosp_seq_id                in pat_authorization_details.hosp_seq_id%type,
                           v_policy_seq_id              in pat_authorization_details.policy_seq_id%type,
                           v_emirate_id                 in pat_authorization_details.emirate_id%type,
                           v_encounter_type_id          in pat_authorization_details.encounter_type_id%type,
                           v_encounter_facility_id      in pat_authorization_details.encounter_facility_id%type,
                           v_encounter_start_type       IN pat_authorization_details.encounter_start_type%type,
                           v_encounter_end_type         IN pat_authorization_details.encounter_end_type%type,
                           v_remarks                    in pat_authorization_details.remarks%type,
                           v_added_by                   in number,
                           v_clinician_id               in pat_authorization_details.clinician_id%type,
                           v_system_of_medicine_type_id in pat_authorization_details.system_of_medicine_type_id%type,
                           v_accident_related_type_id   in pat_authorization_details.Accident_Related_Type_Id%TYPE,
                           v_priority_gen_type_id       in pat_authorization_details.priority_general_type_id%TYPE,
                           v_network_yn                 in pat_authorization_details.network_yn%type,
                           v_provider_name              in pat_non_network_details.provider_name%type,
                           v_provider_id                in pat_non_network_details.provider_id%type,
                           v_city_type_id               in pat_non_network_details.city_type_id%type,
                           v_state_type_id              in pat_non_network_details.state_type_id%type,
                           v_country_type_id            in pat_non_network_details.country_type_id%type,
                           v_provider_address           in pat_non_network_details.provider_address%type,
                           v_pincode                    in pat_non_network_details.pincode%type,
                           v_requested_amount           in pat_authorization_details.requested_amount%type,
                           v_benifit_type               in pat_authorization_details.benifit_type%type,
                           v_gravida                    in pat_authorization_details.gravida%type,
                           v_para                       in pat_authorization_details.para%type,
                           v_live                       in pat_authorization_details.live%type,
                           v_abortion                   in pat_authorization_details.abortion%type,
                           v_selection_type             in varchar2,--PAT,'ENH'--enhancement
                           v_currency_type              in pat_authorization_details.currency_type%type,
                           v_clinician_name             in pat_non_network_details.clinician_name%type,
                           v_ava_sum_insured            in pat_authorization_details.ava_sum_insured%type,
                          ---------------------------------------------------------------------------------
                           v_Oral_diagnosis            	in pat_authorization_details.Oral_diagnosis%type,
                           v_Oral_services              in pat_authorization_details.Oral_services%type,
                           v_Orala_Aproved_amount      	in pat_authorization_details.Orala_Aproved_amount%type,
                           v_Oral_diagnosis_revised       in pat_authorization_details.Oral_diagnosis_revised%type,
                           v_Oral_services_revised        in pat_authorization_details.Oral_services_revised%type,
                           v_Orala_Aproved_amount_revised in pat_authorization_details.Orala_Aproved_amount_revised%type,
                           v_Oral_system_Status			    in pat_authorization_details.Oral_system_Status%type,
                           ------------------------------------------------------------------------------
                           v_rows_processed             out number,
                           v_past_history                        in pat_authorization_details.past_history%type:= null,
                           v_duration_above_illness              in pat_authorization_details.duration_above_illness%type,
                           v_duration_above_illness_time         in pat_authorization_details.duration_above_illness_time%type,
                           v_since_when                          in pat_authorization_details.since_when%type,
                           v_since_when_time                     in pat_authorization_details.since_when_time%type,
                           v_clinician_speciality    in pat_authorization_details.clinician_speciality%type:= null,
                           v_consultation_type       in pat_authorization_details.consultation_type%type:= null,
                           v_presenting_comp         IN pat_authorization_details.presenting_complaints%TYPE:= null,
                           v_provider_login          in varchar2:= null,
                           v_file_name               in varchar2:= null,
                           v_date_of_lmp             in pat_authorization_details.lmp_date%TYPE,
                           v_conception_type         in pat_authorization_details.conception_type%TYPE,
                           v_success_enh_yn          in pat_authorization_details.success_enh_yn%TYPE----NEWLY ADDED FOR PREAUTH ENHANCEMENT SUBMIT OR NOT
                           ) 
                   is
                   
  CURSOR act_cur IS
    SELECT count(p.denial_code) as denial_count
    FROM Pat_Activity_Details p
    WHERE p.pat_auth_seq_id = v_pat_auth_seq_id;
     
  CURSOR pat_diag_cur IS
  SELECT count(1) 
  FROM diagnosys_details dd
  WHERE dd.pat_auth_seq_id=v_pat_auth_seq_id;
  
  v_diag_count NUMBER;
                   
  CURSOR denial_cur IS
    SELECT COUNT(pa.code) as Code 
    FROM pat_activity_details pa
    JOIN app.tpa_restrict_activity_tab rat ON (pa.code = rat.activity_code)
    WHERE pa.pat_auth_seq_id = v_pat_auth_seq_id;
    
  v_denial_count             NUMBER;
  
  CURSOR mem_cur(v_hosp_date date) IS
    SELECT tepm.date_of_inception,
           tepm.date_of_exit,
           tepm.mem_name,
           tepm.mem_age,
           tcc.short_name,
           tsc.state_type_id,
           tepg.policy_group_seq_id,
           tepg.policy_seq_id,
           tepm.member_seq_id,
           case when tepg.stop_pat_clm_process_yn = 'Y' and trunc(v_hosp_date)>= trunc(tepg.recieved_after ) then 'Y' end as emp_stop_yn,
           case when tepm.stop_pat_clm_process_yn='Y' and trunc(v_hosp_date)>= trunc(tepm.recieved_after) then 'Y' end as mem_stop_yn,
           case when tipp.stop_preauth_yn='Y'and trunc(v_hosp_date)>=trunc(tipp.stop_preauth_date) then 'Y' end  as pol_stop_yn
      FROM tpa_enr_policy_group tepg
      JOIN tpa_enr_policy_member tepm
        ON (tepg.policy_group_seq_id = tepm.policy_group_seq_id)
     LEFT OUTER JOIN tpa_ins_prod_policy tipp
        ON (tepg.policy_seq_id = tipp.policy_seq_id)
     LEFT OUTER JOIN tpa_enr_mem_address tema
        ON (tepg.enr_address_seq_id = tema.enr_address_seq_id)
     LEFT OUTER JOIN tpa_country_code tcc
        ON (tema.country_id = tcc.country_id)
     LEFT OUTER JOIN tpa_state_code tsc
        ON (tema.state_type_id = tsc.state_type_id)
     WHERE tepm.Member_Seq_Id = v_member_seq_id;

  CURSOR pat_dup_cur IS
    SELECT pad.hospitalization_date
      FROM pat_authorization_details pad
     WHERE pad.member_seq_id = v_member_seq_id
       AND pad.pat_auth_seq_id != nvl(v_pat_auth_seq_id, 0)
     ORDER BY pad.hospitalization_date desc;

  CURSOR pat_cur IS
    SELECT pad.completed_yn,pad.pat_status_type_id, pad.tot_approved_amount, pad.tot_disc_gross_amount, pad.pre_auth_number
      FROM pat_authorization_details pad
     WHERE pad.pat_auth_seq_id = v_pat_auth_seq_id;
     
  CURSOR clinician_cur IS
   SELECT hp.hosp_seq_id,hp.professional_id,hp.valid_from_date,hp.valid_to_date FROM app.tpa_hosp_professionals hp
   WHERE hp.professional_id=v_clinician_id;
 
 CURSOR clinician_count_cur IS
   SELECT count(1) FROM app.tpa_hosp_professionals hp
   WHERE hp.professional_id=v_clinician_id AND hp.hosp_seq_id=v_hosp_seq_id;
   
 CURSOR prev_balance_cur IS SELECT b.balance_seq_id , b.sum_insured  ,b.utilised_sum_insured ,
        a.policy_group_seq_id ,a.mem_general_type_id 
      FROM tpa_enr_policy_member a JOIN tpa_enr_balance b ON (a.policy_group_seq_id = b.policy_group_seq_id )
      JOIN tpa_enr_policy c ON (b.policy_seq_id = c.policy_seq_id)
      WHERE a.member_seq_id = v_member_seq_id
      AND (a.mem_general_type_id = 'PFL' AND b.member_seq_id IS NULL
               OR a.mem_general_type_id != 'PFL' AND b.member_seq_id = v_member_seq_id );
 
 CURSOR cur_corporate_name IS
    SELECT UPPER(TRIM(REPLACE(R.GROUP_NAME,' ',''))) AS CORP_NAME
    FROM TPA_ENR_POLICY_MEMBER M
    JOIN TPA_ENR_POLICY_GROUP G ON G.POLICY_GROUP_SEQ_ID = M.POLICY_GROUP_SEQ_ID
    JOIN TPA_GROUP_REGISTRATION R ON R.GROUP_REG_SEQ_ID = G.GROUP_REG_SEQ_ID
    WHERE M.MEMBER_SEQ_ID = v_member_seq_id;
    
CURSOR stop_pro_cur (v_hosp_date date) IS SELECT case when stop_preauth_yn = 'Y' and trunc(v_hosp_date)>=trunc(stop_preauth_date) then 'Y' end pro_stop_yn FROM app.tpa_hosp_info WHERE hosp_seq_id = v_hosp_seq_id;

   pat_rec pat_cur%ROWTYPE;
   v_count          number(10);
   clin_rec        clinician_cur%rowtype;
   mem_rec         mem_cur%ROWTYPE;
   balance_rec                  prev_balance_cur%ROWTYPE;
   v_denial_reason pat_authorization_details.denial_reason%type;
   v_denial_code     pat_authorization_details.denial_code%type;
   v_parent_pat_rcvd_date   pat_authorization_details.pat_received_date%type;
   v_parent_completed_yn    varchar2(2);
   v_pat_status_type_id     pat_authorization_details.pat_status_type_id%type;
   v_parent_app_sum_insured pat_general_details.app_sum_insured%TYPE;
   V_shortfall_count       number;
   v_denial_codes          VARCHAR2(250);
   v_dest_msg_seq_id      number;
   v_prod_policy_rule_seq_id number;
   v_allowed_amount          NUMBER;
   v_medical_opinion_remarks NUMBER;
   v_auth_number_o           VARCHAR2(20);
   
   v_pat_resultset           SYS_REFCURSOR;
   v_result_set              SYS_REFCURSOR;
   l_pre_auth_number         VARCHAR2(30);
   v_seq_id                  NUMBER;
   v_act_denial_count        NUMBER;
   v_prov_amount_limit       NUMBER(30,3);
   v_cor_name                VARCHAR2(1000);
   pro_stop_yn              VARCHAR2(1);
 
 CURSOR act_dtl IS
SELECT SUM(NVL(pa.gross_amount,0)) as tot_gross_amount
      ,SUM(NVL(pa.discount_amount,0)) as tot_discount_amount
      ,SUM(NVL(pa.disc_gross_amount,0)) as tot_disc_gross_amount
      ,SUM(NVL(pa.patient_share_amount,0)) as tot_patient_share_amount
      ,SUM(NVL(pa.net_amount,0)) as tot_net_amount
      ,SUM(NVL(pa.allowed_amount,0)) as tot_allowed_amount
      ,SUM(NVL(pa.approved_amount,0)) as tot_approved_amount
      ,SUM(NVL(pa.ucr, 0))            as tot_ucr_amount
 FROM pat_activity_details pa
WHERE pa.Pat_Auth_Seq_Id=v_pat_auth_seq_id;

rec_act_dtl                act_dtl%ROWTYPE;

  CURSOR pat_act_count_cur IS
  SELECT count(1) 
  FROM pat_activity_details pad
  WHERE pad.pat_auth_seq_id=v_pat_auth_seq_id;
  
  v_act_count        number(10);
  
  CURSOR pre_number_cur
  IS
  SELECT a.pre_auth_number
  FROM app.pat_authorization_details a
  WHERE a.pat_auth_seq_id = v_parent_pat_auth_seq_id;
       
  
  CURSOR hosp_benifit_limit_cur IS
  SELECT  CASE WHEN v_benifit_type ='OPTS'  THEN hosp.OPTS_LIMIT
               WHEN v_benifit_type ='OPTC'  THEN hosp.OPTC_LIMIT
               WHEN v_benifit_type ='DNTL'  THEN hosp.DNTL_LIMIT
               WHEN v_benifit_type ='OMTI'  THEN hosp.OMTI_LIMIT  
          END AS v_ind_benifit_limit
FROM tpa_hosp_info hosp WHERE hosp_seq_id = v_hosp_seq_id;
      
      CURSOR vip_nvip_cursor(v_pat_seq_id number)IS 
      select b.vip_yn from pat_authorization_Details a join   tpa_enr_policy_member b
      on ( a.MEMBER_SEQ_ID=b.MEMBER_SEQ_ID) where a.pat_auth_seq_id =  v_pat_auth_seq_id;
      
      vip_nvip_rec           tpa_enr_polIcy_member.VIP_YN%TYPE;

hosp_benifit_limit_rec NUMBER(15,2);

BEGIN

  OPEN  mem_cur(v_hospitalization_date);
  FETCH mem_cur  INTO mem_rec;
  CLOSE mem_cur;

  OPEN  pat_cur;
  FETCH pat_cur  INTO pat_rec;
  CLOSE pat_cur;

  OPEN clinician_cur;
  FETCH clinician_cur INTO clin_rec;
  CLOSE clinician_cur;
  
  OPEN clinician_count_cur;
  FETCH clinician_count_cur  INTO v_count;
  CLOSE clinician_count_cur;
  
  OPEN prev_balance_cur;
  FETCH prev_balance_cur INTO balance_rec;
  CLOSE prev_balance_cur;
  
  ----- STOP PREAUTH CR
  OPEN stop_pro_cur(v_hospitalization_date);
  FETCH stop_pro_cur INTO pro_stop_yn;
  CLOSE stop_pro_cur;
  
  IF v_pat_auth_seq_id IS NOT NULL THEN 
    OPEN pat_diag_cur;
    FETCH pat_diag_cur INTO v_diag_count;
    CLOSE pat_diag_cur;
    
    OPEN pat_act_count_cur;
    FETCH pat_act_count_cur INTO  v_act_count;
    CLOSE pat_act_count_cur;
    
    OPEN cur_corporate_name;
    FETCH cur_corporate_name INTO v_cor_name;
    CLOSE cur_corporate_name;
  
  END IF;
  
  IF v_diag_count<1 THEN
    RAISE_APPLICATION_ERROR(-20380,'Please add atleast one Diagnosis');
   END IF;
  
  IF v_act_count<1 THEN
    RAISE_APPLICATION_ERROR(-20273,'Please add atleast one Activity');
  END IF;
  
  IF pat_rec.completed_yn = 'Y' THEN
    RAISE_APPLICATION_ERROR(-20107,'You cannot perform this action through a completed Claim.');
  END IF;
  
  IF mem_rec.member_seq_id IS NULL THEN
    RAISE_APPLICATION_ERROR(-20370, 'Patient is not a covered member');
  END IF;
  
   IF nvl(v_parent_pat_auth_seq_id,0)!=0  THEN

      SELECT a.pat_received_date, a.completed_yn,a.tot_approved_amount
         INTO v_parent_pat_rcvd_date ,v_parent_completed_yn,v_parent_app_sum_insured
         FROM pat_authorization_details a
         WHERE a.pat_auth_seq_id = v_parent_pat_auth_seq_id ;

      IF v_pat_received_date < v_parent_pat_rcvd_date THEN
        raise_application_error(-20383,'Enhancement received date/time should not be less than original preauth received date/time.');
      END IF;

      IF NVL(V_PAT_AUTH_SEQ_ID, 0) = 0  THEN
        v_pat_status_type_id := 'INP';
        IF v_parent_completed_yn = 'N' THEN
          raise_application_error(-20384,' Please Complete the parent Pre_auth First ');
        END IF;
        IF v_member_seq_id IS NOT NULL THEN
          UPDATE tpa_enr_balance a SET
            a.utilised_sum_insured = a.utilised_sum_insured - nvl(v_parent_app_sum_insured,0),
            a.updated_by                   = v_added_by,
            a.updated_date                 = SYSDATE
            WHERE a.balance_seq_id = balance_rec.balance_seq_id;
        END IF;
      END IF;
    END IF;
  IF NVL(V_PAT_AUTH_SEQ_ID, 0) = 0 THEN
    IF v_pre_auth_number IS NULL THEN
      
     v_pre_auth_number := authorization_pkg.generate_id_numbers('PA',
                                               mem_rec.short_name,
                                               mem_rec.state_type_id,
                                               v_pre_auth_number);
                                               
    END IF;
    
    INSERT INTO PAT_AUTHORIZATION_DETAILS
      (pat_auth_seq_id,
       parent_pat_auth_seq_id,
       pat_received_date,
       discharge_date,
       source_type_id,
       hospitalization_date,
       member_seq_id,
       tpa_enrollment_id,
       pre_auth_number,
       auth_number,
       mem_name,
       mem_age,
       ins_seq_id,
       hosp_seq_id,
       policy_seq_id,
       tpa_office_seq_id,
       emirate_id,
       encounter_type_id,
       encounter_facility_id,
       encounter_start_type,
       encounter_end_type,
       ava_sum_insured,
       remarks,
       denial_reason,
       pat_enhanced_yn,
       currency_type,
       maternity_yn,
       pat_status_type_id,
       clinician_id,
       system_of_medicine_type_id,
       accident_related_type_id,
       added_by,
       added_date,
       priority_general_type_id,
       network_yn,
       requested_amount,
       benifit_type,
       gravida,
       para,
       live,
       abortion,
       past_history   ,
       dur_ailment,--duration_above_illness ,
       duration_flag,--duration_above_illness_time ,
       since_when ,
       since_when_time,
       clinician_speciality,
       consultation_type,
       -------------------------------
       Oral_diagnosis,
       Oral_services,
       Orala_Aproved_amount,
       Oral_system_Status,
       Oral_diagnosis_revised,
       Oral_services_revised,
       Orala_Aproved_amount_revised,
       presenting_complaints,
       file_name,
       lmp_date,
       conception_type,
       process_type
      )
    VALUES
      (pat_auth_detail_seq.nextval,
       nvl(v_parent_pat_auth_seq_id,0),
       v_pat_received_date,
       NVL(v_discharge_date, v_hospitalization_date),
       v_source_type_id,
       v_hospitalization_date,
       v_member_seq_id,
       v_tpa_enrollment_id,
       v_pre_auth_number,
       v_auth_number,
       nvl(v_mem_name, mem_rec.mem_name),
       nvl(v_mem_age, mem_rec.mem_age),
       v_ins_seq_id,
       v_hosp_seq_id,
       nvl(v_policy_seq_id, mem_rec.policy_seq_id),
       1,
       v_emirate_id,
       v_encounter_type_id,
       v_encounter_facility_id,
       v_encounter_start_type,
       v_encounter_end_type,
       v_ava_sum_insured,
       v_remarks,
       v_denial_reason,
       'N',
       v_currency_type,
       case when nvl(v_benifit_type,'A') IN ('MTI', 'OMTI', 'IMTI') THEN 'Y' ELSE 'N' end,
       'INP',
       v_clinician_id,
       v_system_of_medicine_type_id,
       v_accident_related_type_id,
       v_added_by,
       SYSDATE,
       CASE WHEN v_cor_name LIKE 'ALJAZEERAMEDIANETWORK%' THEN 'HIG' ELSE v_priority_gen_type_id END,
       v_network_yn,
       v_requested_amount,
       v_benifit_type,
       v_gravida,
       v_para,
       v_live,
       v_abortion,
       v_past_history   ,
       v_duration_above_illness ,
       v_duration_above_illness_time ,
       v_since_when ,
       v_since_when_time,
       v_clinician_speciality,
       v_consultation_type,
       --------------------------------------
       v_Oral_diagnosis,
       v_Oral_services,
       v_Orala_Aproved_amount,
       v_Oral_system_Status,
       v_Oral_diagnosis_revised,
       v_Oral_services_revised,
       v_Orala_Aproved_amount_revised,
       v_presenting_comp,
       v_file_name,
       v_date_of_lmp,
       v_conception_type,
       'RGL'
       )
      RETURNING pat_auth_seq_id INTO v_pat_auth_seq_id;
  
    --IF v_network_yn = 'N' then
      INSERT INTO PAT_NON_NETWORK_DETAILS
        (PAT_NON_NETWORK_SEQ_ID,
         PAT_AUTH_SEQ_ID,
         PROVIDER_NAME,
         PROVIDER_ID,
         CITY_TYPE_ID,
         STATE_TYPE_ID,
         COUNTRY_TYPE_ID,
         PROVIDER_ADDRESS,
         PINCODE,
         ADDED_BY,
         ADDED_DATE,
         CLINICIAN_ID,
         CLINICIAN_NAME)
      values
        (PAT_NON_NETWORK_DETAILS_SEQ.nextval,
         v_pat_auth_seq_id,
         v_provider_name,
         v_provider_id,
         v_city_type_id,
         v_state_type_id,
         v_country_type_id,
         v_provider_address,
         v_pincode,
         v_added_by,
         sysdate,
         v_clinician_id,
         v_clinician_name
         );
  GENERATE_MAIL_PKG.proc_generate_message('PREAUTH_RECEIPT',
                                          v_pat_auth_seq_id,
                                          v_added_by,
                                          v_dest_msg_seq_id); --PREAUTH_RECEIPT_NHCP
                                          
  GENERATE_MAIL_PKG.proc_generate_message('PREAUTH_RECEIPT_NHCP',
                                          v_pat_auth_seq_id,
                                          v_added_by,
                                          v_dest_msg_seq_id);
  IF v_benifit_type IN('IPT','IMTI') THEN
  GENERATE_MAIL_PKG.proc_generate_message('IN-PATIENT_PREAPPROVAL',
                                          v_pat_auth_seq_id,
                                          v_added_by,
                                          v_dest_msg_seq_id);
  END IF;
  
      IF v_pat_auth_seq_id IS NOT NULL THEN
      OPEN vip_nvip_cursor(v_pat_auth_seq_id);
      fetch vip_nvip_cursor into vip_nvip_rec;
      close  vip_nvip_cursor;
      
      IF NVL(vip_nvip_rec,'N')='Y' and v_pat_auth_seq_id is not null and v_pre_auth_number is not null THEN
        GENERATE_MAIL_PKG.proc_generate_message('VIP_PAT_UPLOADED',v_pat_auth_seq_id,v_added_by,v_dest_msg_seq_id);
        GENERATE_MAIL_PKG.proc_generate_message('VIP_PREAPPROVAL',v_pat_auth_seq_id,v_added_by,v_dest_msg_seq_id);
      END IF;
      END IF;

                                          
   
    IF v_selection_type = 'ENH' THEN--enhancement
           UPDATE pat_authorization_details d SET
             d.pat_enhanced_yn = 'Y'
             WHERE d.pat_auth_seq_id = v_parent_pat_auth_seq_id ;


          -- Copying previous diagnosis details
       FOR I IN (SELECT * FROM diagnosys_details dd
                      WHERE dd.pat_auth_seq_id = v_parent_pat_auth_seq_id) loop 
         INSERT INTO diagnosys_details(diag_seq_id,pat_auth_seq_id,icd_code_seq_id,diagnosys_code,primary_ailment_yn,added_by,added_date)
         VALUES (diagnosys_detail_seq.nextval,v_pat_auth_seq_id,I.icd_code_seq_id,I.diagnosys_code,I.primary_ailment_yn,v_added_by,sysdate);
       END LOOP;
          
          --Copying activity details 
          FOR I IN (SELECT * FROM pat_activity_details
                      WHERE pat_auth_seq_id = v_parent_pat_auth_seq_id)
          LOOP
          INSERT INTO pat_activity_details(activity_dtl_seq_id,pat_auth_seq_id,Activity_Seq_Id,activity_id,s_no,start_date,activity_type,code,
                      unit_type,modifier,internal_code,package_id,bundle_id,quantity,gross_amount,discount_amount,disc_gross_amount,patient_share_amount,
                      copay_amount,co_ins_amount,deduct_amount,out_of_pocket_amount,net_amount,allowed_amount,approved_amount,allow_yn,denial_code,
                      remarks,added_by,added_date,denial_desc,approvd_quantity,unit_price,converted_acitivty_amt )
          VALUES (pat_activity_detail_seq.nextval,v_pat_auth_seq_id,i.activity_seq_id,i.activity_id,i.s_no,i.start_date,i.activity_type,i.code,i.unit_type,
                 i.modifier,i.internal_code,i.package_id,i.bundle_id,i.quantity,i.gross_amount,i.discount_amount,i.disc_gross_amount,i.patient_share_amount,i.copay_amount,
                 i.co_ins_amount,i.deduct_amount,i.out_of_pocket_amount,i.net_amount,i.allowed_amount,i.allowed_amount,i.allow_yn,i.denial_code,i.remarks,v_added_by,
                 SYSDATE,i.denial_desc,i.approvd_quantity,i.unit_price,i.converted_acitivty_amt);
            
           FOR J IN (SELECT * FROM app.pat_observation_details od 
               where od.activity_dtl_seq_id=i.activity_dtl_seq_id) loop
              INSERT INTO pat_observation_details(observation_seq_id,activity_dtl_seq_id,observation_type_id,observation_code_id,value,
                  obs_value_type_id,added_by,added_date,remarks )
           VALUES (pat_observation_detail_seq.Nextval,j.activity_dtl_seq_id,j.observation_type_id,j.observation_code_id,j.value,j.obs_value_type_id,
                  v_added_by,sysdate,j.remarks);
           END LOOP;   
        END LOOP;

    END IF;
 
  ELSE
    
   /* IF v_provider_login='Y'  THEN
    
       v_pre_auth_number := authorization_pkg.generate_id_numbers('PA',
                                               mem_rec.short_name,
                                               mem_rec.state_type_id,
                                               v_pre_auth_number);
    ELSE  
    
        OPEN   pre_number_cur;
        FETCH  pre_number_cur  INTO  v_pre_auth_number;
        CLOSE  pre_number_cur;
    
    
    END IF;*/ -- commented by venn babu added in first save procedure
  
    UPDATE pat_authorization_details
       SET parent_pat_auth_seq_id     = nvl(v_parent_pat_auth_seq_id,0),
           pat_received_date          = v_pat_received_date,
           discharge_date             = NVL(v_discharge_date, v_hospitalization_date),
           source_type_id             = 'PLPR',
           hospitalization_date       = v_hospitalization_date,
           member_seq_id              = v_member_seq_id,
           tpa_enrollment_id          = v_tpa_enrollment_id,
          -- pre_auth_number            = v_pre_auth_number,
           auth_number                = v_auth_number,
           mem_name                   = v_mem_name,
           mem_age                    = v_mem_age,
           ins_seq_id                 = v_ins_seq_id,
           hosp_seq_id                = v_hosp_seq_id,
           policy_seq_id              = v_policy_seq_id,
           emirate_id                 = v_emirate_id,
           encounter_type_id          = v_encounter_type_id,
           encounter_facility_id      = v_encounter_facility_id,
         ---  denial_reason              = v_denial_reason,
           encounter_start_type       = case when v_benifit_type NOT IN ('DNTL', 'Dental','IMTI','OMTI', 'HEAC') then v_encounter_start_type else 1 end,
           encounter_end_type         = v_encounter_end_type,
           ava_sum_insured            = v_ava_sum_insured,
           remarks                    = v_remarks,
           currency_type              = v_currency_type,
           maternity_yn               = case when nvl(v_benifit_type,'A') IN ('MTI', 'OMTI', 'IMTI') THEN 'Y' ELSE 'N' end,
           pat_status_type_id         = 'INP',
           clinician_id               = v_clinician_id,
           system_of_medicine_type_id = v_system_of_medicine_type_id,
           accident_related_type_id   = v_accident_related_type_id,
           updated_by                 = v_added_by,
           updated_date               = sysdate,
           priority_general_type_id   = CASE WHEN v_cor_name LIKE 'ALJAZEERAMEDIANETWORK%' THEN 'HIG' ELSE v_priority_gen_type_id END,
           network_yn                 = v_network_yn,
           requested_amount           = v_requested_amount,
           benifit_type               = v_benifit_type,
           gravida                    = v_gravida ,
           para                       = v_para,
           live                       = v_live,
           abortion                   = v_abortion,
         ---  denial_code                = v_denial_code,
           past_history               = v_past_history   ,
           dur_ailment                = v_duration_above_illness ,
           duration_flag              = v_duration_above_illness_time ,
           since_when                  = v_since_when ,
           since_when_time             = v_since_when_time,
           clinician_speciality        = v_clinician_speciality,
           consultation_type           = v_consultation_type,
           --------------------------------------------------
           Oral_diagnosis              = v_Oral_diagnosis,
           Oral_services               = v_Oral_services,
           Orala_Aproved_amount        = v_Orala_Aproved_amount,
           Oral_system_Status          = v_Oral_system_Status,
           Oral_diagnosis_revised      = v_Oral_diagnosis_revised,
           Oral_services_revised       = v_Oral_services_revised,
           Orala_Aproved_amount_revised = v_Orala_Aproved_amount_revised,
           presenting_complaints       =  v_presenting_comp,
           file_name                   = v_file_name,
           lmp_date                    = v_date_of_lmp,
           conception_type             = v_conception_type,
           process_type                = 'RGL',
           treatment_type              = case when v_benifit_type IN ('DNTL', 'Dental') then v_encounter_start_type else null end
     WHERE pat_auth_seq_id             = v_pat_auth_seq_id RETURNING PRE_AUTH_NUMBER INTO v_pre_auth_number;
  
  IF v_network_yn = 'N' then
   update pat_non_network_details set
         provider_name          = v_provider_name,
         provider_id            = v_provider_id,
         city_type_id           = v_city_type_id,
         state_type_id          = v_state_type_id,
         country_type_id        = v_country_type_id,
         provider_address       = v_provider_address,
         pincode                = v_pincode,
         updated_by             = v_added_by,
         updated_date           = sysdate,
         clinician_id           = v_clinician_id,
         clinician_name         = v_clinician_name
         where pat_auth_seq_id = v_pat_auth_seq_id;

  END IF;
 end if;
 
 /*prc_track_error(v_pat_auth_seq_id, 'v_policy_seq_id: '||v_policy_seq_id||CHR(10)||
                                     'mem_rec.policy_seq_id: '||mem_rec.policy_seq_id||CHR(10)||
                                     'v_member_seq_id: '||v_member_seq_id||CHR(10)||
                                     'PROCEDURE: '||'save_pat_details_app_level',
                                     'PAT'
                                     );*/
   -----****FOR PREAUTH ENHANCEMENT*****
  
   
  IF v_success_enh_yn = 'Y' then 
 
     UPDATE app.pat_authorization_details a
     SET a.success_enh_yn = 'Y'
     WHERE A.PAT_AUTH_SEQ_ID = v_pat_auth_seq_id;
 
   END IF;
 

  check_pat_approved(v_pat_auth_seq_id, v_added_by);
  
  -- Auto Calculate Approve The PreAuth
  IF v_benifit_type = 'OPTS' OR v_benifit_type = 'OPTC' OR 
     v_benifit_type = 'DNTL' OR v_benifit_type = 'OMTI' THEN
  
    authorization_pkg.calculate_authorization(v_pat_auth_seq_id,
                                              v_hosp_seq_id,
                                              v_allowed_amount,
                                              v_result_set,
                                              v_added_by
                                             );
    
    
    open pat_cur;
    fetch pat_cur into pat_rec;
    close pat_cur;

    open hosp_benifit_limit_cur;
    fetch hosp_benifit_limit_cur into hosp_benifit_limit_rec;
    close hosp_benifit_limit_cur;
    
    select nvl(hosp_benifit_limit_rec, 0) into v_prov_amount_limit from dual;
    --from Tpa_Hosp_Info h
    --where h.hosp_seq_id = v_hosp_seq_id;
    
    IF pat_rec.tot_disc_gross_amount <= v_prov_amount_limit THEN
      IF pat_rec.tot_approved_amount > 0 THEN
      
        select nvl(pa.tot_allowed_amount, 0), medical_opinion_remarks
            into v_allowed_amount, v_medical_opinion_remarks
          from app.pat_authorization_details pa
          where pa.pat_auth_seq_id = v_pat_auth_seq_id;
        
        OPEN denial_cur;
        FETCH denial_cur INTO v_denial_count;
        CLOSE denial_cur;
        
        OPEN act_cur;
        FETCH act_cur INTO v_act_denial_count;
        CLOSE act_cur;
        
        IF v_act_denial_count = 0 THEN
          IF v_denial_count = 0 THEN
            v_pat_status_type_id := 'APR';
          ELSE
            v_pat_status_type_id := 'INP';
          END IF;
        ELSE
          v_pat_status_type_id := 'INP';
        END IF;
        
        IF v_prov_amount_limit <=0 THEN
          v_pat_status_type_id:= 'INP';
        END IF;
        
        IF pro_stop_yn = 'Y' or mem_rec.pol_stop_yn = 'Y' or mem_rec.emp_stop_yn = 'Y' or mem_rec.mem_stop_yn = 'Y' then
            v_pat_status_type_id:= 'INP';
        END IF;
        
        IF v_pat_status_type_id = 'APR' THEN
            -- Generate Auth Number
          v_auth_number_o:=authorization_pkg.generate_id_numbers('AT',
                                                                   mem_rec.short_name,
                                                                   mem_rec.state_type_id,
                                                                   pat_rec.pre_auth_number
                                                                   );
            -- Save PreAuthorization                                     
            authorization_pkg.save_authorization(v_pat_auth_seq_id,
                                                 v_member_seq_id,
                                                 v_auth_number_o,
                                                 v_hospitalization_date,
                                                 v_allowed_amount,
                                                 v_source_type_id,
                                                 v_pat_status_type_id,
                                                 v_medical_opinion_remarks,
                                                 v_added_by,
                                                 'Y',
                                                 null,
                                                 null,
                                                 v_rows_processed
                                                );
                              
        END IF;
      END IF;
    END IF;
  END IF;
  
  OPEN act_dtl;
  FETCH act_dtl INTO rec_act_dtl;
  CLOSE act_dtl;
  
  UPDATE pat_authorization_details a
  SET a.REQUESTED_AMOUNT= rec_act_dtl.tot_disc_gross_amount,
      a.CONVERTED_AMOUNT= rec_act_dtl.tot_disc_gross_amount,
      a.conversion_rate = 1,
      a.authorized_by      = 1
  WHERE A.pat_auth_seq_id  = v_pat_auth_seq_id;
  
  IF v_pat_status_type_id='APR' then
      GENERATE_MAIL_PKG.proc_generate_message('PREAUTH_APPROVED',
                                            v_pat_auth_seq_id,
                                            v_added_by,
                                            v_dest_msg_seq_id);

      GENERATE_MAIL_PKG.proc_generate_message('PREAUTH_APPROVED_NHCP',
                                            v_pat_auth_seq_id,
                                            v_added_by,
                                            v_dest_msg_seq_id);
  END IF;

  IF v_benifit_type IN('IPT','IMTI') THEN
  GENERATE_MAIL_PKG.proc_generate_message('IN-PATIENT_PREAPPROVAL',
                                          v_pat_auth_seq_id,
                                          v_added_by,
                                          v_dest_msg_seq_id);
  END IF;
        IF v_pat_auth_seq_id IS NOT NULL THEN
      OPEN vip_nvip_cursor(v_pat_auth_seq_id);
      fetch vip_nvip_cursor into vip_nvip_rec;
      close  vip_nvip_cursor;
      
      IF NVL(vip_nvip_rec,'N')='Y' and v_pat_auth_seq_id is not null and v_pre_auth_number is not null THEN
        GENERATE_MAIL_PKG.proc_generate_message('VIP_PAT_UPLOADED',v_pat_auth_seq_id,v_added_by,v_dest_msg_seq_id);
        GENERATE_MAIL_PKG.proc_generate_message('VIP_PREAPPROVAL',v_pat_auth_seq_id,v_added_by,v_dest_msg_seq_id);
      END IF;
      END IF;
  
  commit;
 
END save_pat_details_app_level;
--========================================================================================================

----barch level deleting the activities and diagnonsis details for the preatuh---
PROCEDURE delete_Daig_act_prev(v_code               IN varchar2, --comma separated values of dia or act
                               v_pat_auth_seq_id    IN app.pat_authorization_details.pat_auth_seq_id%type, 
                               v_flag               IN varchar2, --ICD,ACT
                               v_quantity           IN varchar2,   
                               v_hosp_seq_id        IN Tpa_Hosp_Info.Hosp_Seq_Id%TYPE,
                               v_rows_processed            OUT NUMBER
                               )
is 
v_count                      NUMBER;
v_diag_count                 NUMBER;
v_seq_id                     NUMBER;
v_act_code                   VARCHAR2(1000);
v_act_qnty                   VARCHAR2(1000);
str_tab                      ttk_util_pkg.str_table_type;
str_tab1                     ttk_util_pkg.str_table_type;
dlt_query VARCHAR2(32767);
v_mat_act_seq_id             NUMBER;
CURSOR pat_diag_cur IS
  SELECT count(1) 
  FROM diagnosys_details dd
  WHERE dd.pat_auth_seq_id= v_pat_auth_seq_id;

/*CURSOR dig_cur (v_diagnosys_code VARCHAR2) IS
  SELECT tic.icd10_seq_id 
  FROM tpa_icd10_master_details tic 
  WHERE tic.icd_code=v_diagnosys_code;*/
  
v_icd_code_seq_id app.tpa_icd10_master_details.icd10_seq_id%type;


CURSOR pat_cur IS
  SELECT *
  FROM Pat_Authorization_Details pa
  WHERE pa.pat_auth_seq_id = v_pat_auth_seq_id;

pat_rec pat_cur%ROWTYPE;

CURSOR act_cursor IS
  SELECT *
  FROM Pat_Activity_Details pad
  WHERE to_char(pad.activity_dtl_seq_id) IN (v_code);

act_rec act_cursor%ROWTYPE;
  
CURSOR act_master_cur(v_code VARCHAR2, v_seq_id NUMBER, v_pre_hosp_seq_id NUMBER) IS
 select distinct nvl(b.unit_price, a.gross_amount) as unit_price, a.disc_amount, a.activity_seq_id, a.start_date, a.end_date, b.act_mas_dtl_seq_id, b.activity_type_seq_id
 from(
 select gross_amount, hosp_seq_id, activity_seq_id, start_date, end_date, disc_amount
 from tpa_hosp_tariff_details ) a
 full join (select unit_price, act_mas_dtl_seq_id, activity_type_seq_id 
            from tpa_activity_master_details
            where activity_code = v_code) b on (a.activity_seq_id = b.act_mas_dtl_seq_id)
 where a.activity_seq_id = v_seq_id
 and a.hosp_seq_id = v_pre_hosp_seq_id;
  
act_master_rec act_master_cur%ROWTYPE;

--CURSOR tarif_cur IS
----********
CURSOR icd_benefit_cur(v_diagnosys_code VARCHAR2) IS
  Select ic.benefit_type,ic.icd10_seq_id 
  From tpa_icd10_master_details ic
  Where ic.icd_code = upper(v_diagnosys_code);

CURSOR pat_icd_cur(v_prim_icd VARCHAR2) IS
  Select p.benifit_type
  From pat_authorization_details p
  Where p.pat_auth_seq_id = v_pat_auth_seq_id
  And v_prim_icd = 'Y';
  
  pat_icd_rec          pat_icd_cur%ROWTYPE;
  v_icd_benefit        tpa_icd10_master_details.benefit_type%type; 
  v_cnt            number(5);


  
begin
  OPEN pat_cur;
  FETCH pat_cur INTO pat_rec;
  CLOSE pat_cur;
  
  OPEN act_cursor;
  FETCH act_cursor INTO act_rec;
  CLOSE act_cursor;
  
  
  if   v_flag='ICD' then
     select count(1) into v_count from app.diagnosys_details jk 
                   where jk.pat_auth_seq_id=v_pat_auth_seq_id;
     IF v_count > 0 THEN             
       dlt_query := 'delete from app.diagnosys_details jk 
                     where jk.pat_auth_seq_id='||v_pat_auth_seq_id||'';
     END IF;
  elsif v_flag='ACT' then 
     select count(1) into v_count from app.pat_activity_details jk 
                where jk.pat_auth_seq_id=v_pat_auth_seq_id;
     
     IF v_count > 0 THEN            
       dlt_query := 'delete from app.pat_activity_details jk 
                  where jk.pat_auth_seq_id='||v_pat_auth_seq_id||'';
     END IF;
   /*elsif v_flag='ICD' and v_code is null then 
   
    dlt_query := 'delete from app.diagnosys_details jk 
                where jk.pat_auth_seq_id='||v_pat_auth_seq_id||'';
   elsif v_flag='ACT' and v_code is null then 
       
    dlt_query := 'delete from app.pat_activity_details jk 
                where jk.pat_auth_seq_id='||v_pat_auth_seq_id||'';*/
            
  end if;
    IF v_count > 0 THEN
      EXECUTE IMMEDIATE dlt_query;
    END IF;
    
    v_rows_processed:=SQL%ROWCOUNT;
    commit; 
    IF v_flag = 'ICD' THEN ---1
      ---*********
      IF v_code IS NULL THEN
        RAISE_APPLICATION_ERROR(-20380,'Please add atleast one Diagnosis');
      END IF;
      ---*********
      IF v_code IS NOT NULL THEN --2
        v_act_code := ','||v_code||',';
        str_tab := ttk_util_pkg.parse_string(v_act_code);
      
        for actCode in str_tab.first.. str_tab.last loop
        v_act_qnty := '|'||str_tab(actCode)||'|';
        str_tab1   := ttk_util_pkg.parse_str(v_act_qnty);
      
      ---*******
        OPEN icd_benefit_cur(str_tab1(2));
        FETCH icd_benefit_cur INTO v_icd_benefit,v_icd_code_seq_id;
        CLOSE icd_benefit_cur;
      
        OPEN pat_icd_cur(str_tab1(3));
        FETCH pat_icd_cur INTO pat_icd_rec;
        CLOSE pat_icd_cur;
      
        IF (v_icd_benefit = 'DNTL' OR pat_icd_rec.benifit_type = 'DNTL') AND NVL(str_tab1(3), 'N') = 'Y' THEN
          IF pat_icd_rec.benifit_type != NVL(v_icd_benefit, 'NA') THEN
            RAISE_APPLICATION_ERROR(-20323,'Ailment does not belogs to the selected benefit type, please select appropriate benefit type!');
          END IF;
        END IF;
      ---*******
        ---------- CR0248(Benefit type restriction for meternity icd) ---------
        select count(1) into v_cnt from tpa_icd_codes 
        where icd_code=UPPER(str_tab1(2)) and master_icd_code='Z34.90' /*AND NVL(str_tab1(3), 'N')='Y'*/;
        
        IF  v_cnt >= 1 /*AND NVL(str_tab1(3), 'N')='Y' */ AND pat_rec.benifit_type NOT IN('IMTI','OMTI','MTI')THEN 
          RAISE_APPLICATION_ERROR(-20323,'Ailment does not belogs to the selected benefit type, please select appropriate benefit type!');
        END IF;  
        -------------------------------------------------------------------------
      --IF  NVL(to_number(str_tab1(1)),0)=0 THEN
        
         INSERT INTO  diagnosys_details(
                      diag_seq_id,
                      pat_auth_seq_id,
                      icd_code_seq_id,
                      diagnosys_code,
                      primary_ailment_yn,
                      added_by,
                      added_date)
           VALUES (diagnosys_detail_seq.nextval,
                   v_pat_auth_seq_id,
                   v_icd_code_seq_id,
                   str_tab1(2),
                   str_tab1(3),
                   to_number(str_tab1(4)),
                   SYSDATE )  ;
        
      
        end loop;
      END IF;--2
    /*ELSIF v_flag = 'ACT' THEN ---1
      
      IF v_code IS NOT NULL THEN --3
        v_act_code := ','||v_code||',';
        str_tab := ttk_util_pkg.parse_string(v_act_code);
        
        for actCode in str_tab.first.. str_tab.last loop
          v_act_qnty := '|'||str_tab(actCode)||'|';
          str_tab1   := ttk_util_pkg.parse_str(v_act_qnty);
          
          select m.act_mas_dtl_seq_id INTO v_mat_act_seq_id
          from tpa_activity_master_details m where m.activity_code = UPPER(str_tab1(1));
          
          OPEN act_master_cur(str_tab1(1), v_mat_act_seq_id, v_hosp_seq_id );
          FETCH act_master_cur INTO act_master_rec;
          CLOSE act_master_cur;
        
          SELECT MAX(pad.activity_dtl_seq_id) INTO v_seq_id FROM Pat_Activity_Details pad;
          
          OPEN pat_diag_cur;
          FETCH pat_diag_cur INTO v_diag_count;
          CLOSE pat_diag_cur;
          
          IF v_diag_count = 0 THEN
             RAISE_APPLICATION_ERROR(-20380,'Please add atleast one Diagnosis');
          END IF;
          
          INSERT INTO PAT_ACTIVITY_DETAILS PA(ACTIVITY_DTL_SEQ_ID,
                                              PAT_AUTH_SEQ_ID,
                                              ACTIVITY_SEQ_ID,
                                              START_DATE,
                                              ACTIVITY_TYPE,
                                              CODE,
                                              CLINICIAN_ID,
                                              QUANTITY,
                                              ALLOW_YN,
                                              GROSS_AMOUNT,
                                              DISCOUNT_AMOUNT,
                                              DISC_GROSS_AMOUNT,
                                              NET_AMOUNT,
                                              ADDED_BY,
                                              ADDED_DATE,
                                              APPROVD_QUANTITY,
                                              UNIT_PRICE,
                                              UNIT_DISCOUNT_AMOUNT,
                                              OVERRIDE_YN,
                                              SERVICE_TYPE
                                             )

          VALUES(v_seq_id + 1,
                 v_pat_auth_seq_id,
                 act_master_rec.act_mas_dtl_seq_id,
                 sysdate,
                 act_master_rec.activity_type_seq_id,
                 str_tab1(1),
                 act_rec.clinician_id,
                 str_tab1(2),
                 'Y',
                 act_master_rec.unit_price * str_tab1(2),
                 act_master_rec.disc_amount,
                 act_master_rec.unit_price * str_tab1(2),
                 act_master_rec.unit_price * str_tab1(2),
                 1,
                 sysdate,
                 str_tab1(2),
                 act_master_rec.unit_price,
                 0,
                 'N',
                 'ACD'); 
        
      end loop;
      END IF;*/ --3
    END IF;-----1
  commit;

end ;
                                 



--=====================================================================
PROCEDURE calculate_authorization(v_pat_auth_seq_id            IN  pat_authorization_details.pat_auth_seq_id%type,
                                  v_hosp_seq_id                IN  pat_authorization_details.hosp_seq_id%TYPE,
                                  v_allowed_amount             OUT  pat_authorization_details.Tot_Allowed_Amount%TYPE,
                                  v_result_set                 OUT SYS_REFCURSOR,
                                  v_added_by                   IN  NUMBER
                                  )
AS

  CURSOR act_cur IS
  SELECT SUM(NVL(pa.gross_amount,0)) as tot_gross_amount
         ,SUM(NVL(pa.discount_amount,0)) as tot_discount_amount
         ,SUM(NVL(pa.disc_gross_amount,0)) as tot_disc_gross_amount
         ,SUM(NVL(pa.patient_share_amount,0)) as tot_patient_share_amount
         ,SUM(NVL(pa.net_amount,0)) as tot_net_amount
         ,SUM(NVL(pa.allowed_amount,0)) as tot_allowed_amount
         ,SUM(NVL(pa.approved_amount,0)) as tot_approved_amount

  FROM pat_activity_details pa
  WHERE pa.pat_auth_seq_id=v_pat_auth_seq_id
  AND pa.allow_yn='Y';

  CURSOR pat_cur IS
  SELECT pad.denial_reason,pad.denial_code,pad.remarks,pad.completed_yn,pad.member_seq_id,
         to_date(pad.hospitalization_date,'dd/mm/rrrr') as hospitalization_date,pad.network_yn  
  FROM pat_authorization_details pad
  WHERE pad.pat_auth_seq_id=v_pat_auth_seq_id;
 
  CURSOR enrol_type IS
    select ep.enrol_type_id,ep.policy_seq_id from app.tpa_enr_policy ep join app.pat_authorization_details ad on (ep.policy_seq_id=ad.policy_seq_id)
    where ad.pat_auth_seq_id=v_pat_auth_seq_id;

  enrol_rec   enrol_type%rowtype;
  act_rec                    act_cur%ROWTYPE;
  pat_rec                    pat_cur%ROWTYPE;

  CURSOR floater_cur(v_policy_group_seq_id    tpa_enr_policy_group.policy_group_seq_id%type,v_admission_date   date)
   IS 
  SELECT a.policy_group_seq_id,
         SUM(A.mem_sum_insured) AS sum_insured,
         b.sum_insured as tot_sum_insured,
         b.utilised_sum_insured  FROM tpa_enr_mem_insured a
  JOIN tpa_enr_balance b on (a.policy_group_seq_id=b.policy_group_seq_id)
  WHERE a.policy_group_seq_id=v_policy_group_seq_id
  AND a.policy_date<=v_admission_date
  GROUP BY a.policy_group_seq_id,b.sum_insured,b.utilised_sum_insured;

  CURSOR nonfloater_cur(v_member_seq_id    tpa_enr_policy_member.member_seq_id%type,v_admission_date   date)
   IS 
  SELECT a.member_seq_id,
         SUM(A.mem_sum_insured) AS sum_insured,
         b.sum_insured as tot_sum_insured,
         b.utilised_sum_insured
         
  FROM tpa_enr_mem_insured a
  JOIN tpa_enr_balance b on (a.policy_group_seq_id=b.policy_group_seq_id)
  WHERE a.member_seq_id=v_member_seq_id
  AND a.policy_date<=v_admission_date
  GROUP BY a.member_seq_id,b.sum_insured,b.utilised_sum_insured;
  
  sum_rec              floater_cur%rowtype;

  CURSOR mem_cur (v_member_seq_id    tpa_enr_policy_member.member_seq_id%type) IS
  SELECT a.date_of_inception,a.date_of_exit,a.member_seq_id,b.policy_group_seq_id,c.policy_seq_id,c.policy_sub_general_type_id FROM tpa_enr_policy_member a
  JOIN tpa_enr_policy_group b on (a.policy_group_seq_id=b.policy_group_seq_id)
  JOIN tpa_enr_policy c on (b.policy_seq_id=c.policy_seq_id)
  WHERE a.member_seq_id=v_member_seq_id;

  CURSOR pat_act_cur IS
  SELECT pad.activity_dtl_seq_id,
         pad.pat_auth_seq_id,
         pad.allowed_amount,
         pad.approved_amount
        FROM pat_activity_details pad
        where pad.pat_auth_seq_id=v_pat_auth_seq_id;

  mem_rec              mem_cur%ROWTYPE;
  v_ava_sum_insured    tpa_enr_balance.utilised_sum_insured%type;
  v_remarks            varchar2(100);
  v_max_act            number(10);
  v_member_seq_id      number(10);
  v_chronic_count      number(10);
  v_final_allowed_amount  number;
  v_prod_policy_rule_seq_id number;

BEGIN
    
    OPEN pat_cur;
    FETCH pat_cur INTO pat_rec;
    CLOSE pat_cur;
    
    open mem_cur(pat_rec.member_seq_id);
    fetch mem_cur into mem_rec;
    close mem_cur;
     
    IF mem_rec.policy_sub_general_type_id='PFL' THEN
      OPEN floater_cur(mem_rec.policy_group_seq_id,pat_rec.hospitalization_date);
      FETCH floater_cur INTO sum_rec;
      CLOSE floater_cur;
    ELSIF  mem_rec.policy_sub_general_type_id='PNF' THEN
      OPEN nonfloater_cur(mem_rec.member_seq_id,pat_rec.hospitalization_date);
      FETCH nonfloater_cur INTO sum_rec;
      CLOSE nonfloater_cur;
    END IF; 
    v_ava_sum_insured:=(NVL(sum_rec.sum_insured,0)-NVL(sum_rec.utilised_sum_insured,0)) ;  

    --IF NVL(v_prod_policy_rule_seq_id,0)=0 THEN 
    OPEN enrol_type;
    FETCH enrol_type INTO enrol_rec;
    CLOSE enrol_type;
    --END IF;
     IF enrol_rec.enrol_type_id='IND' THEN
       v_prod_policy_rule_seq_id:=authorization_pkg.get_prod_pol_seq_id(enrol_rec.policy_seq_id,'IND');
     ELSE
       v_prod_policy_rule_seq_id:=authorization_pkg.get_prod_pol_seq_id(enrol_rec.policy_seq_id,'POL');
     END IF; 
    
    IF pat_rec.Completed_Yn='Y' THEN
      RAISE_APPLICATION_ERROR(-20107,'You cannot perform this action through a completed Claim.');
    END IF;
   
   
   --IF pat_rec.Denial_Reason is null THEN
     
     update pat_activity_details ad set 
      ad.denial_code=case when (nvl(ad.override_yn,'N')='N' and ad.denial_desc is not null) or (nvl(ad.override_yn,'N')='Y' and ad.denial_desc is not null) then null else ad.denial_code end,
      ad.remarks=null,
      ad.denial_desc=case when (nvl(ad.override_yn,'N')='N' and ad.denial_desc is not null) or (nvl(ad.override_yn,'N')='Y' and ad.denial_desc is not null) then null else ad.denial_desc end,
      ad.patient_share_amount=case when nvl(ad.override_yn,'N')='N' then 0 else ad.patient_share_amount end,
      ad.allowed_amount=null,
      ad.approved_amount=null,
      ad.approvd_quantity = case when nvl(ad.phy_yn,'N')='Y' then ad.quantity else ad.approvd_quantity end 
      where ad.pat_auth_seq_id=v_pat_auth_seq_id and nvl(ad.override_yn,'N')='N' and nvl(ad.service_type,'ACD')='ACD'; 
      
      update diagnosys_details dd 
      set dd.denial_reason=null,
          dd.remarks=null
       where dd.pat_auth_seq_id=v_pat_auth_seq_id;
       
      update pat_authorization_details pad
      set pad.benefit_limit=null,
          pad.benefit_copay=null,
          pad.tot_allowed_amount=null,
          pad.tot_approved_amount=null
          where pad.pat_auth_seq_id = v_pat_auth_seq_id;
      
   
    IF pat_rec.Denial_Reason is not null THEN
      UPDATE pat_activity_details pad
               SET pad.denial_desc  = pat_rec.Denial_Reason,
                   pad.denial_code  = pat_rec.denial_code,
                   pad.remarks      = pat_rec.remarks,
                   pad.updated_by   = v_added_by,
                   pad.updated_date = SYSDATE
             WHERE pad.pat_auth_seq_id = v_pat_auth_seq_id;
    end if;
    commit; 
    select count(1) into v_chronic_count from  
    app.pat_authorization_details d join app.diagnosys_details dd on (d.pat_auth_seq_id=dd.pat_auth_seq_id and d.benifit_type='OPTS')
    join app.tpa_day_care_icd c on (c.icd_code=dd.diagnosys_code and dd.primary_ailment_yn='Y') where d.pat_auth_seq_id=v_pat_auth_seq_id;
    
    --pat_xml_load_pkg.update_activity_gross(v_pat_auth_seq_id,'PAT',v_added_by);
    pat_xml_load_pkg.check_duplicate_activity(v_pat_auth_seq_id,'PAT',v_added_by);
    --pat_xml_load_pkg.check_ddc_rule(v_pat_auth_seq_id,'PAT',v_added_by);
    pat_xml_load_pkg.check_room_icu_code(v_pat_auth_seq_id,'PAT',v_added_by);
    --pat_xml_load_pkg.check_lmrp_rules(v_pat_auth_seq_id,'PAT',v_added_by);-- comented as per Dr.yasmin
    pat_xml_load_pkg.check_ncci_hosp_phy_rules(v_pat_auth_seq_id,v_hosp_seq_id,'PAT',v_added_by);
    pat_xml_load_pkg.check_mue_rules(v_pat_auth_seq_id,'PAT',v_added_by);
    pat_xml_load_pkg.execute_diag_rule(v_pat_auth_seq_id,'PAT' ,v_prod_policy_rule_seq_id  ,v_added_by);     
--    if v_chronic_count=0 then
    pat_xml_load_pkg.execute_activity_rule(v_pat_auth_seq_id,'PAT',v_prod_policy_rule_seq_id  ,v_added_by  );        
    --end if;
    pat_xml_load_pkg.check_add_on_rules(v_pat_auth_seq_id,'PAT',v_added_by);
    if nvl(pat_rec.network_yn,'N')='Y' then
    pat_xml_load_pkg.check_tariff_rule (v_pat_auth_seq_id,'PAT',v_added_by);
    end if;
    pat_xml_load_pkg.check_physiotherapy_pd(v_pat_auth_seq_id,'PAT',v_added_by);
   /*ELSE
     
            UPDATE pat_activity_details pad
               SET pad.denial_desc  = pat_rec.Denial_Reason,
                   pad.denial_code  = pat_rec.denial_code,
                   pad.remarks      = pat_rec.remarks,
                   pad.updated_by   = v_added_by,
                   pad.updated_date = SYSDATE
             WHERE pad.pat_auth_seq_id = v_pat_auth_seq_id;
   END IF;*/
    pat_xml_load_pkg.admin_activity_rule('CLM',v_pat_auth_seq_id);
    pat_xml_load_pkg.calculate_allowed_amount( v_pat_auth_seq_id,'PAT');

    OPEN act_cur;
    FETCH act_cur INTO act_rec;
    CLOSE act_cur;
     
    UPDATE pat_authorization_details A
    SET a.tot_gross_amount           = act_rec.tot_gross_amount,
        a.tot_discount_amount        = act_rec.tot_discount_amount,
        a.tot_disc_gross_amount      = act_rec.tot_disc_gross_amount,
        a.tot_patient_share_amount   = act_rec.tot_patient_share_amount,
        a.tot_net_amount             = act_rec.tot_net_amount,
        a.tot_allowed_amount         = act_rec.tot_allowed_amount,
        a.tot_approved_amount        = act_rec.tot_approved_amount,
        a.remarks                    = v_remarks
   WHERE a.pat_auth_seq_id           = v_pat_auth_seq_id
   RETURNING a.tot_approved_amount INTO v_allowed_amount;

  pat_xml_load_pkg.execute_global_amnt_rules('P',v_pat_auth_seq_id,pat_rec.member_seq_id,v_Prod_Policy_Rule_Seq_Id);
  check_pat_approved(v_pat_auth_seq_id, v_added_by);
  check_activity_limits(v_pat_auth_seq_id,'PAT',v_allowed_amount,v_added_by,v_remarks,v_final_allowed_amount);
  
   
  UPDATE pat_activity_details pad
               SET pad.denial_desc  = replace(pad.denial_desc,';;',';')
                   WHERE pad.pat_auth_seq_id = v_pat_auth_seq_id;
  
 commit;
 
  OPEN v_result_set FOR 
  SELECT SUM(NVL(pa.gross_amount,0)) as tot_gross_amount
      ,SUM(NVL(pa.discount_amount,0)) as tot_discount_amount
      ,SUM(NVL(pa.disc_gross_amount,0)) as tot_disc_gross_amount
      ,SUM(NVL(pa.patient_share_amount,0)) as tot_patient_share_amount
      ,(SUM(NVL(pa.disc_gross_amount,0))-SUM(NVL(pa.patient_share_amount,0))) as tot_net_amount
      ,SUM(NVL(pa.allowed_amount,0)) as tot_allowed_amount
      ,SUM(NVL(pa.Approved_Amount,0)) as tot_approved_amount

 FROM pat_activity_details pa
WHERE pa.pat_auth_seq_id=v_pat_auth_seq_id
AND pa.allow_yn='Y';

commit;
END calculate_authorization;
--=====================================================================================================================
PROCEDURE check_pat_approved(v_pat_auth_seq_id      IN pat_authorization_details.pat_auth_seq_id%TYPE,                      
                             v_added_by             IN NUMBER)
IS

CURSOR mem_cur(v_member_seq_id  IN tpa_enr_policy_member.Member_Seq_Id%TYPE)
 IS 
  SELECT 
         tepm.date_of_inception,
         tepm.date_of_exit,
         tepm.mem_name,
         tepm.mem_age,
         tepg.policy_group_seq_id,
         tepg.policy_seq_id,
         tepm.member_seq_id,
         tep.policy_sub_general_type_id
  FROM tpa_enr_policy_member tepm
  JOIN tpa_enr_policy_group tepg  ON (tepm.policy_group_seq_id=tepg.policy_group_seq_id)
  JOIN tpa_enr_policy tep ON (tepg.policy_seq_id=tep.policy_seq_id)
  WHERE tepm.Member_Seq_Id=v_member_seq_id;
  
  CURSOR pat_cur IS
  SELECT pad.hospitalization_date ,pad.final_app_amount,pad.pat_status_type_id,
  pad.member_seq_id,pad.policy_seq_id
  FROM pat_authorization_details pad
  WHERE  pad.pat_auth_seq_id=v_pat_auth_seq_id;
  
   pat_rec         pat_cur%ROWTYPE;
   mem_rec         mem_cur%ROWTYPE;
   
   CURSOR shortfall_count IS 
   SELECT COUNT(1)  FROM APP.shortfall_details s where 
   s.srtfll_status_general_type_id='OPN' and s.pat_gen_detail_seq_id=v_pat_auth_seq_id ;
   V_shortfall_count  number;
                       
BEGIN
  
  OPEN pat_cur;
  FETCH pat_cur INTO pat_rec;
  CLOSE pat_cur;
  
  OPEN mem_cur(pat_rec.Member_Seq_Id);
  FETCH mem_cur INTO mem_rec;
  CLOSE mem_cur;
 
  open shortfall_count;
  fetch shortfall_count into V_shortfall_count;
  close shortfall_count; 
  
 IF pat_rec.Pat_Status_Type_Id='APR' THEN
  
  IF mem_rec.policy_sub_general_type_id='PFL' THEN    
   UPDATE tpa_enr_balance b
   SET b.utilised_sum_insured = b.utilised_sum_insured - nvl(pat_rec.final_app_amount,0),
       b.updated_by           = v_added_by,
       b.updated_date         = SYSDATE
   WHERE b.policy_group_seq_id = mem_rec.policy_group_seq_id;
  ELSIF mem_rec.policy_sub_general_type_id='PNF' THEN  
  UPDATE tpa_enr_balance b
   SET b.utilised_sum_insured = b.utilised_sum_insured - nvl(pat_rec.final_app_amount,0),
       b.updated_by           = v_added_by,
       b.updated_date         = SYSDATE
   WHERE b.member_seq_id = mem_rec.member_seq_id; 
  END IF;
    
 END IF;
 
   UPDATE pat_authorization_details pad
   SET pad.completed_yn='N',
       pad.pat_status_type_id= case when nvl(V_shortfall_count,0)>0 then 'REQ' else 'INP' end ,
       pad.final_app_amount=0
   WHERE pad.pat_auth_seq_id=v_pat_auth_seq_id;
 
END check_pat_approved;
--===============================================================================
PROCEDURE check_activity_limits (v_seq_id                 IN pat_authorization_details.pat_auth_seq_id%TYPE,
                                 v_mode                   IN VARCHAR2,
                                 v_allowed_amt            IN NUMBER,
                                 v_added_by               IN NUMBER,
                                 v_remarks                IN VARCHAR2,
                                 v_final_allowed_amount   OUT NUMBER)
IS
  CURSOR pat_cur IS
  SELECT pad.approved_amount,pad.activity_dtl_seq_id,pad.pat_auth_seq_id FROM pat_activity_details pad
  WHERE pad.pat_auth_seq_id=v_seq_id AND pad.code <>'AC001';

  CURSOR clm_cur IS
  SELECT pad.approved_amount,pad.activity_dtl_seq_id,pad.claim_seq_id FROM pat_activity_details pad
  WHERE pad.claim_seq_id=v_seq_id AND pad.code <>'AC001';

  rec   pat_cur%ROWTYPE;
  CURSOR pat_master_code_cur is
  SELECT distinct g.master_activity_code, case when b.maternity_yn='Y' then b.maternity_allowed_amt 
                                               when b.benifit_type='DNTL' then nvl(b.benefit_limit,b.ava_sum_insured) 
                                               else case when c.rule_limit>=0 then c.rule_limit else b.ava_sum_insured end end as rule_limit,c.override_yn 
               FROM pat_authorization_details b
               JOIN pat_activity_details C ON (b.pat_auth_seq_id = c.pat_auth_seq_id )
               JOIN tpa_activity_details G ON (c.code = G.ACTIVITY_CODE)
               JOIN tpa_activity_details gg ON (g.master_activity_code = gg.master_activity_code )
               WHERE  B.pat_auth_seq_id =v_seq_id AND c.code <>'AC001';

  CURSOR clm_master_code_cur is
  SELECT distinct g.master_activity_code,case when b.maternity_yn='Y' then b.maternity_allowed_amt 
                                              when b.benifit_type='DNTL' then nvl(b.benefit_limit,b.ava_sum_insured) 
                                              else case when c.rule_limit>=0 then c.rule_limit else b.ava_sum_insured end end as rule_limit,
                                              b.pat_approved_amount ,c.override_yn
               FROM clm_authorization_details b
               JOIN pat_activity_details C ON (b.claim_seq_id = c.claim_seq_id )
               JOIN tpa_activity_details G ON (c.code = G.ACTIVITY_CODE)
               JOIN tpa_activity_details gg ON (g.master_activity_code = gg.master_activity_code )
               WHERE  b.claim_seq_id =v_seq_id AND c.code <>'AC001';



  cursor pat_act_cur (v_code  pat_activity_details.code%type) is  
  SELECT c.activity_dtl_seq_id,c.code,c.allowed_amount,c.approved_amount,c.net_amount,c.rule_unit
               FROM pat_authorization_details b
               JOIN pat_activity_details C ON (b.pat_auth_seq_id = c.pat_auth_seq_id )
               JOIN tpa_activity_details G ON (c.code = G.ACTIVITY_CODE)
               JOIN tpa_activity_details gg ON (g.master_activity_code = gg.master_activity_code )
               WHERE gg.activity_code=v_code and B.pat_auth_seq_id = v_seq_id
               AND c.code <>'AC001'
               order by c.activity_dtl_seq_id;

  cursor clm_act_cur (v_code  pat_activity_details.code%type) is  
  SELECT c.activity_dtl_seq_id,c.code,c.approved_amount,c.allowed_amount,c.net_amount,b.pat_approved_amount,b.claim_type,c.rule_unit
               FROM clm_authorization_details b
               JOIN pat_activity_details C ON (b.claim_seq_id = c.claim_seq_id )
               JOIN tpa_activity_details G ON (c.code = G.ACTIVITY_CODE)
               JOIN tpa_activity_details gg ON (g.master_activity_code = gg.master_activity_code )
               WHERE gg.activity_code=v_code and b.claim_seq_id = v_seq_id
               AND c.code <>'AC001'
               order by c.activity_dtl_seq_id;

  CURSOR act_cur_pat IS
  SELECT SUM(NVL(pa.gross_amount,0)) as tot_gross_amount
        ,SUM(NVL(pa.discount_amount,0)) as tot_discount_amount
        ,SUM(NVL(pa.disc_gross_amount,0)) as tot_disc_gross_amount
        ,SUM(NVL(pa.patient_share_amount,0)) as tot_patient_share_amount
        ,SUM(NVL(pa.net_amount,0)) as tot_net_amount
        ,SUM(NVL(pa.allowed_amount,0)) as tot_allowed_amount
        ,SUM(NVL(pa.approved_amount,0)) as tot_approved_amount

   FROM pat_activity_details pa
  WHERE pa.pat_auth_seq_id=v_seq_id
  AND pa.allow_yn='Y';

  CURSOR act_cur_clm IS
  SELECT SUM(NVL(pa.gross_amount,0)) as tot_gross_amount
        ,SUM(NVL(pa.discount_amount,0)) as tot_discount_amount
        ,SUM(NVL(pa.disc_gross_amount,0)) as tot_disc_gross_amount
        ,SUM(NVL(pa.patient_share_amount,0)) as tot_patient_share_amount
        ,SUM(NVL(pa.net_amount,0)) as tot_net_amount
        ,SUM(NVL(pa.allowed_amount,0)) as tot_allowed_amount
        ,SUM(NVL(pa.approved_amount,0)) as tot_approved_amount

   FROM pat_activity_details pa
  WHERE pa.claim_seq_id=v_seq_id
  AND pa.allow_yn='Y';

  CURSOR pat_icd_cur is select case when dd.denial_reason like '%NCOV-001%' then null else nvl(dd.rule_limit,ad.ava_sum_insured) end as rule_limit,dd.denial_reason,dd.remarks,null as pat_approved_amount,dd.copay,dd.deduct,ci.day_care_icd_group_id,ad.benifit_type 
  from app.pat_authorization_details ad
  join diagnosys_details dd on (ad.pat_auth_seq_id=dd.pat_auth_seq_id)
  join tpa_day_care_icd ci on (ci.icd_code=dd.diagnosys_code AND dd.primary_ailment_yn='Y')
  where dd.pat_auth_seq_id=v_seq_id and ci.day_care_icd_group_id='ICD001';


  CURSOR clm_icd_cur is select case when dd.denial_reason like '%NCOV-001%' then null else nvl(dd.rule_limit,ad.ava_sum_insured) end as rule_limit,dd.denial_reason,dd.remarks,ad.pat_approved_amount,dd.copay,dd.deduct,ci.day_care_icd_group_id,ad.benifit_type 
  from app.clm_authorization_details ad
  join diagnosys_details dd on (ad.claim_seq_id=dd.claim_seq_id)
  join tpa_day_care_icd ci on (ci.icd_code=dd.diagnosys_code AND dd.primary_ailment_yn='Y')
  where dd.claim_seq_id=v_seq_id and ci.day_care_icd_group_id='ICD001';

  cursor pat_chronic_cur  is  
  SELECT c.activity_dtl_seq_id,c.code,c.allowed_amount,c.approved_amount,c.net_amount,c.override_yn
               FROM pat_authorization_details b
               JOIN pat_activity_details C ON (b.pat_auth_seq_id = c.pat_auth_seq_id )
               WHERE B.pat_auth_seq_id = v_seq_id AND c.code <>'AC001'
               order by c.activity_dtl_seq_id;

  cursor clm_chronic_cur  is  
  SELECT c.activity_dtl_seq_id,c.code,c.approved_amount,c.allowed_amount,c.net_amount,b.pat_approved_amount,b.claim_type,c.override_yn
               FROM clm_authorization_details b
               JOIN pat_activity_details C ON (b.claim_seq_id = c.claim_seq_id )
               WHERE b.claim_seq_id = v_seq_id AND c.code <>'AC001'
               order by c.activity_dtl_seq_id;
               
  cursor pat_dental_cur  is  
  SELECT CASE WHEN b.benifit_type='DNTL' THEN nvl(b.benefit_limit,b.ava_sum_insured) 
              WHEN b.benifit_type IN ('MTI', 'OMTI', 'IMTI') THEN nvl(b.Maternity_Allowed_Amt,b.ava_sum_insured) END as benefit_limit
               FROM pat_authorization_details b
               WHERE B.pat_auth_seq_id = v_seq_id;

  cursor clm_dental_cur  is  
  SELECT  CASE WHEN b.benifit_type='DNTL' THEN nvl(b.benefit_limit,b.ava_sum_insured) 
               WHEN b.benifit_type IN ('MTI', 'OMTI', 'IMTI') THEN nvl(b.Maternity_Allowed_Amt,b.ava_sum_insured) END as benefit_limit ,b.pat_approved_amount,b.claim_type
               FROM clm_authorization_details b
               WHERE b.claim_seq_id = v_seq_id;
              


  icd_rec                   pat_icd_cur%ROWTYPE;    
  act_rec                   act_cur_pat%ROWTYPE;
  v_item_sum                NUMBER(12,2);
  v_rest_amount             NUMBER(12,2):=0;
  v_remain_amount           NUMBER(12,2);
  v_claim_type              clm_authorization_details.claim_type%type;
  v_benefit_type            varchar2(100);
  v_pat_aprov_amount        varchar2(100):=0;
  V_PRE_AUTH_SEQ_ID        NUMBER(10);
BEGIN
  
  IF v_mode='PAT' THEN
  select pad.benifit_type into v_benefit_type from app.pat_authorization_details pad where pad.pat_auth_seq_id=v_seq_id;
  if v_allowed_amt>0 then  
  OPEN pat_icd_cur;
  FETCH pat_icd_cur INTO icd_rec;
  CLOSE pat_icd_cur;
    
   
     
    if icd_rec.day_care_icd_group_id='ICD001' and icd_rec.benifit_type= 'OPTS' then 
     v_rest_amount:=nvl(icd_rec.rule_limit,0);
     FOR rec in pat_chronic_cur loop
      if nvl(rec.override_yn,'N')='N' then
      v_rest_amount:=CASE WHEN rec.approved_amount>v_rest_amount  THEN v_rest_amount  WHEN rec.approved_amount<=v_rest_amount  THEN rec.approved_amount  ELSE v_rest_amount END;
      v_remain_amount:=nvl(v_remain_amount,icd_rec.rule_limit)-v_rest_amount;
       UPDATE pat_activity_details pad
        SET pad.approved_amount = case when v_rest_amount>0 then v_rest_amount else 0 end,
            pad.allowed_amount =  case when v_rest_amount>0 then v_rest_amount else 0 end,
            pad.remarks =  case when pad.approved_amount>v_rest_amount then case when pad.remarks is  null then ' Chronic limit has been exceeded' else case when pad.denial_code like '%BENX-005%'then ' Chronic limit has been exceeded' else pad.remarks||';'||' Chronic limit has been exceeded' end end else pad.remarks end,
            pad.denial_desc = case when pad.approved_amount>v_rest_amount then  case when pad.denial_desc is  null then 'Annual limit/sublimit amount exceeded' else case when pad.denial_code like '%BENX-005%'then pad.denial_desc else pad.denial_desc||';'||'Annual limit/sublimit amount exceeded' end end else pad.denial_desc end,
            pad.denial_code = case when pad.approved_amount>v_rest_amount then case when pad.denial_code is  null then 'BENX-005' else case when pad.denial_code like '%BENX-005%'then pad.denial_code else pad.denial_code||';'||'BENX-005' end end else pad.denial_code end,
            pad.benifit_deductible=icd_rec.deduct,
            pad.updated_by = v_added_by,
            pad.updated_date = SYSDATE        
      WHERE pad.activity_dtl_seq_id = rec.activity_dtl_seq_id;
      v_rest_amount:=v_remain_amount;
     end if;
     END LOOP;
     elsif v_benefit_type='DNTL' then
     FOR dent in pat_dental_cur LOOP
     v_rest_amount:=nvl(dent.benefit_limit,0);
     FOR rec in pat_chronic_cur loop
      if nvl(rec.override_yn,'N')='N' then
      v_rest_amount:=CASE WHEN rec.approved_amount>v_rest_amount  THEN v_rest_amount  WHEN rec.approved_amount<=v_rest_amount  THEN rec.approved_amount  ELSE v_rest_amount END;
      v_remain_amount:=nvl(v_remain_amount,dent.benefit_limit)-v_rest_amount;
       UPDATE pat_activity_details pad
        SET pad.approved_amount = case when v_rest_amount>0 then v_rest_amount else 0 end,
            pad.allowed_amount =  case when v_rest_amount>0 then v_rest_amount else 0 end,
            pad.remarks =  case when pad.approved_amount>v_rest_amount then case when pad.remarks is  null then 'The claimed amount is more than the allowed limit as per  policy benefits.Hence the amount over and above the allowed limit is disallowed' else case when pad.denial_code like '%BENX-005%'then pad.remarks else pad.remarks||';'||' The claimed amount is more than the allowed limit as per  policy benefits.Hence the amount over and above the allowed limit is disallowed' end end else pad.remarks end,
            pad.denial_desc = case when pad.approved_amount>v_rest_amount then  case when pad.denial_desc is  null then 'Annual limit/sublimit amount exceeded' else case when pad.denial_code like '%BENX-005%'then pad.denial_desc else pad.denial_desc||';'||'Annual limit/sublimit amount exceeded' end end else pad.denial_desc end,
            pad.denial_code = case when pad.approved_amount>v_rest_amount then case when pad.denial_code is  null then 'BENX-005' else case when pad.denial_code like '%BENX-005%'then pad.denial_code else pad.denial_code||';'||'BENX-005' end end else pad.denial_code end,
            pad.benifit_deductible=icd_rec.deduct,
            pad.updated_by = v_added_by,
            pad.updated_date = SYSDATE        
      WHERE pad.activity_dtl_seq_id = rec.activity_dtl_seq_id;
      v_rest_amount:=v_remain_amount;
      end if;
     END LOOP;
    END LOOP;
    elsif v_benefit_type IN ('MTI', 'OMTI', 'IMTI') then
    FOR dent in pat_dental_cur LOOP
     v_rest_amount:=nvl(dent.benefit_limit,0);
     FOR rec in pat_chronic_cur loop
     if nvl(rec.override_yn,'N')='N' then
      v_rest_amount:=CASE WHEN rec.approved_amount>v_rest_amount  THEN v_rest_amount  WHEN rec.approved_amount<=v_rest_amount  THEN rec.approved_amount  ELSE v_rest_amount END;
      v_remain_amount:=nvl(v_remain_amount,dent.benefit_limit)-v_rest_amount;
       UPDATE pat_activity_details pad
        SET pad.approved_amount = case when v_rest_amount>0 then v_rest_amount else 0 end,
            pad.allowed_amount =  case when v_rest_amount>0 then v_rest_amount else 0 end,
            pad.remarks =  case when pad.approved_amount>v_rest_amount then case when pad.remarks is  null then 'The claimed amount is more than the allowed limit as per  policy benefits.Hence the amount over and above the allowed limit is disallowed' else case when pad.denial_code like '%BENX-005%'then pad.remarks else pad.remarks||';'||'The claimed amount is more than the allowed limit as per  policy benefits.Hence the amount over and above the allowed limit is disallowed' end end end,--else nvl(pad.remarks,'The claimed amount is more than the allowed limit as per  policy benefits.Hence the amount over and above the allowed limit is disallowed') end,
            pad.denial_desc = case when pad.approved_amount>v_rest_amount then  case when pad.denial_desc is  null then 'Annual limit/sublimit amount exceeded' else case when pad.denial_code like '%BENX-005%'then pad.denial_desc else pad.denial_desc||';'||'Annual limit/sublimit amount exceeded' end end else case when pad.approved_amount=0 then nvl(pad.denial_desc,'Annual limit/sublimit amount exceeded') end end,
            pad.denial_code = case when pad.approved_amount>v_rest_amount then case when pad.denial_code is  null then 'BENX-005' else case when pad.denial_code like '%BENX-005%'then pad.denial_code else pad.denial_code||';'||'BENX-005' end end else case when pad.approved_amount=0 then nvl(pad.denial_code,'BENX-005') end end,
            --pad.benifit_deductible=icd_rec.deduct,
            pad.updated_by = v_added_by,
            pad.updated_date = SYSDATE        
      WHERE pad.activity_dtl_seq_id = rec.activity_dtl_seq_id;
      v_rest_amount:=v_remain_amount;
     end if;
     END LOOP;
    END LOOP;
    else
     FOR master_code in pat_master_code_cur LOOP
     if nvl(master_code.override_yn,'N')='N' then
      v_remain_amount:=null;
      v_rest_amount:=master_code.rule_limit;
     FOR rec in pat_act_cur(master_code.master_activity_code) loop
       if master_code.master_activity_code not in ('17.03','17.17') then
      v_rest_amount:=CASE WHEN rec.approved_amount>v_rest_amount  THEN v_rest_amount  WHEN rec.approved_amount<=v_rest_amount  THEN rec.approved_amount  ELSE v_rest_amount END;
      v_remain_amount:=nvl(v_remain_amount,master_code.rule_limit)-v_rest_amount;
       UPDATE pat_activity_details pad
        SET pad.approved_amount = case when v_rest_amount>0 then v_rest_amount else 0 end,
            pad.allowed_amount =  case when v_rest_amount>0 then v_rest_amount else 0 end,
            pad.remarks =  case when pad.approved_amount>v_rest_amount then case when pad.remarks is  null then 'The claimed amount is more than the allowed limit as per  policy benefits.Hence the amount over and above the allowed limit is disallowed' else case when pad.denial_code like '%BENX-005%'then pad.remarks else pad.remarks||';'||'The claimed amount is more than the allowed limit as per  policy benefits.Hence the amount over and above the allowed limit is disallowed' end end else pad.remarks end,
            pad.denial_desc = case when pad.approved_amount>v_rest_amount then  case when pad.denial_desc is  null then 'Annual limit/sublimit amount exceeded' else case when pad.denial_code like '%BENX-005%'then pad.denial_desc else pad.denial_desc||';'||'Annual limit/sublimit amount exceeded' end end else pad.denial_desc end,
            pad.denial_code = case when pad.approved_amount>v_rest_amount then case when pad.denial_code is  null then 'BENX-005' else case when pad.denial_code like '%BENX-005%'then pad.denial_code else pad.denial_code||';'||'BENX-005' end end else pad.denial_code end,
            pad.updated_by = v_added_by,
            pad.updated_date = SYSDATE        
      WHERE pad.activity_dtl_seq_id = rec.activity_dtl_seq_id;
      v_rest_amount:=v_remain_amount;
       elsif master_code.master_activity_code  in ('17.03','17.17') and rec.rule_unit!='PD'  then 
         v_rest_amount:=CASE WHEN rec.approved_amount>v_rest_amount  THEN v_rest_amount  WHEN rec.approved_amount<=v_rest_amount  THEN rec.approved_amount  ELSE v_rest_amount END;
      v_remain_amount:=nvl(v_remain_amount,master_code.rule_limit)-v_rest_amount;
       UPDATE pat_activity_details pad
        SET pad.approved_amount = case when v_rest_amount>0 then v_rest_amount else 0 end,
            pad.allowed_amount =  case when v_rest_amount>0 then v_rest_amount else 0 end,
            pad.remarks =  case when pad.approved_amount>v_rest_amount then case when pad.remarks is  null then 'The claimed amount is more than the allowed limit as per  policy benefits.Hence the amount over and above the allowed limit is disallowed' else case when pad.denial_code like '%BENX-005%'then pad.remarks else pad.remarks||';'||'The claimed amount is more than the allowed limit as per  policy benefits.Hence the amount over and above the allowed limit is disallowed' end end else pad.remarks end,
            pad.denial_desc = case when pad.approved_amount>v_rest_amount then  case when pad.denial_desc is  null then 'Annual limit/sublimit amount exceeded' else case when pad.denial_code like '%BENX-005%'then pad.denial_desc else pad.denial_desc||';'||'Annual limit/sublimit amount exceeded' end end else pad.denial_desc end,
            pad.denial_code = case when pad.approved_amount>v_rest_amount then case when pad.denial_code is  null then 'BENX-005' else case when pad.denial_code like '%BENX-005%'then pad.denial_code else pad.denial_code||';'||'BENX-005' end end else pad.denial_code end,
            pad.updated_by = v_added_by,
            pad.updated_date = SYSDATE        
      WHERE pad.activity_dtl_seq_id = rec.activity_dtl_seq_id;
      v_rest_amount:=v_remain_amount;
       end if;
     END LOOP;
     end if;
     END LOOP;
     end if;
   
    OPEN act_cur_pat;
    FETCH act_cur_pat INTO act_rec;
    CLOSE act_cur_pat;
   
  UPDATE pat_authorization_details A
    SET a.tot_gross_amount           = act_rec.tot_gross_amount,
        a.tot_discount_amount        = act_rec.tot_discount_amount,
        a.tot_disc_gross_amount      = act_rec.tot_disc_gross_amount,
        a.tot_patient_share_amount   = act_rec.tot_patient_share_amount,
        a.tot_net_amount             = act_rec.tot_net_amount,
        a.tot_allowed_amount         = act_rec.tot_allowed_amount,
        a.tot_approved_amount        = act_rec.tot_approved_amount,
        a.remarks                    = v_remarks,
        a.dis_allowed_amount         = nvl(act_rec.tot_net_amount,0)-nvl(act_rec.tot_approved_amount,0)
   WHERE a.pat_auth_seq_id           = v_seq_id 
   RETURNING a.tot_approved_amount INTO v_final_allowed_amount;
  end if;  
  ELSIF v_mode='CLM' THEN
  select pad.benifit_type,pad.pat_auth_seq_id into v_benefit_type,v_pre_auth_seq_id from app.clm_authorization_details pad where pad.claim_seq_id=v_seq_id;
  --if v_allowed_amt>0 then 
    OPEN clm_icd_cur;
    FETCH clm_icd_cur INTO icd_rec;
    CLOSE clm_icd_cur;
   
   select cad.claim_type into v_claim_type from clm_authorization_details cad where cad.claim_seq_id=v_seq_id;
   
   if v_claim_type!='CNH' OR (v_claim_type='CNH' AND NVL(v_pre_auth_seq_id,0)=0) THEN  
   IF icd_rec.day_care_icd_group_id='ICD001' and icd_rec.benifit_type= 'OPTS' THEN 
     v_rest_amount:=nvl(icd_rec.rule_limit,0);
     FOR rec in clm_chronic_cur loop
     if nvl(rec.override_yn,'N')='N' then
     v_rest_amount:=CASE WHEN rec.approved_amount>v_rest_amount  THEN v_rest_amount  WHEN rec.approved_amount<=v_rest_amount  THEN rec.approved_amount  ELSE v_rest_amount END;
      v_remain_amount:=nvl(v_remain_amount,icd_rec.rule_limit)-v_rest_amount;
       UPDATE pat_activity_details pad
        SET pad.approved_amount = case when v_rest_amount>0 then v_rest_amount else 0 end,
            pad.allowed_amount =  case when v_rest_amount>0 then v_rest_amount else 0 end,
            pad.remarks = case when icd_rec.remarks is null then case when pad.approved_amount>v_rest_amount then case when pad.remarks is  null then ' Chronic limit has been exceeded' else case when pad.denial_code like '%BENX-005%'then 'Chronic limit has been exceeded' else pad.remarks||';'||' Chronic limit has been exceeded' end end else pad.remarks end else icd_rec.remarks end,
            pad.denial_desc = case when icd_rec.remarks is null then case when pad.approved_amount>v_rest_amount then  case when pad.denial_desc is  null then 'Annual limit/sublimit amount exceeded' else case when pad.denial_code like '%BENX-005%'then pad.denial_desc else pad.denial_desc||';'||'Annual limit/sublimit amount exceeded' end end else pad.denial_desc end else icd_rec.remarks end,
            pad.denial_code = case when icd_rec.denial_reason is null then case when pad.approved_amount>v_rest_amount then case when pad.denial_code is  null then 'BENX-005' else case when pad.denial_code like '%BENX-005%'then pad.denial_code else pad.denial_code||';'||'BENX-005' end end else pad.denial_code end else icd_rec.denial_reason end,
            --pad.benifit_deductible=icd_rec.deduct,
            pad.updated_by = v_added_by,
            pad.updated_date = SYSDATE        
      WHERE pad.activity_dtl_seq_id = rec.activity_dtl_seq_id;
      v_rest_amount:=v_remain_amount;
      end if;
     END LOOP;
   ELSIF v_benefit_type='DNTL' THEN
     FOR dent in clm_dental_cur LOOP
     v_rest_amount:=nvl(dent.benefit_limit,0);
     FOR rec in clm_chronic_cur loop
      if nvl(rec.override_yn,'N')='N' then
      v_rest_amount:=CASE WHEN rec.approved_amount>v_rest_amount  THEN v_rest_amount  WHEN rec.approved_amount<=v_rest_amount  THEN rec.approved_amount  ELSE v_rest_amount END;
      v_remain_amount:=nvl(v_remain_amount,dent.benefit_limit)-v_rest_amount;
       UPDATE pat_activity_details pad
        SET pad.approved_amount = case when v_rest_amount>0 then v_rest_amount else 0 end,
            pad.allowed_amount =  case when v_rest_amount>0 then v_rest_amount else 0 end,
            pad.remarks =  case when pad.approved_amount>v_rest_amount then case when pad.remarks is  null then 'The claimed amount is more than the allowed limit as per  policy benefits.Hence the amount over and above the allowed limit is disallowed' else case when pad.denial_code like '%BENX-005%'then pad.remarks else pad.remarks||';'||'The claimed amount is more than the allowed limit as per  policy benefits.Hence the amount over and above the allowed limit is disallowed' end end else pad.remarks end,
            pad.denial_desc = case when pad.approved_amount>v_rest_amount then  case when pad.denial_desc is  null then 'Annual limit/sublimit amount exceeded' else case when pad.denial_code like '%BENX-005%'then pad.denial_desc else pad.denial_desc||';'||'Annual limit/sublimit amount exceeded' end end else pad.denial_desc end,
            pad.denial_code = case when pad.approved_amount>v_rest_amount then case when pad.denial_code is  null then 'BENX-005' else case when pad.denial_code like '%BENX-005%'then pad.denial_code else pad.denial_code||';'||'BENX-005' end end else pad.denial_code end,
            pad.benifit_deductible=icd_rec.deduct,
            pad.updated_by = v_added_by,
            pad.updated_date = SYSDATE        
      WHERE pad.activity_dtl_seq_id = rec.activity_dtl_seq_id;
      v_rest_amount:=v_remain_amount;
     end if;
     END LOOP;
    END LOOP;
    
   ELSIF v_benefit_type IN ('MTI', 'OMTI', 'IMTI') THEN
     FOR dent in clm_dental_cur LOOP
     v_rest_amount:=nvl(dent.benefit_limit,0);
     FOR rec in clm_chronic_cur loop
      if nvl(rec.override_yn,'N')='N' then
      v_rest_amount:=CASE WHEN rec.approved_amount>v_rest_amount  THEN v_rest_amount  WHEN rec.approved_amount<=v_rest_amount  THEN rec.approved_amount  ELSE v_rest_amount END;
      v_remain_amount:=nvl(v_remain_amount,dent.benefit_limit)-v_rest_amount;
       UPDATE pat_activity_details pad
        SET pad.approved_amount = case when v_rest_amount>0 then v_rest_amount else 0 end,
            pad.allowed_amount =  case when v_rest_amount>0 then v_rest_amount else 0 end,
            pad.remarks =  case when pad.approved_amount>v_rest_amount then case when pad.remarks is  null then 'The claimed amount is more than the allowed limit as per  policy benefits.Hence the amount over and above the allowed limit is disallowed' else case when pad.denial_code like '%BENX-005%'then pad.remarks else pad.remarks||';'||'The claimed amount is more than the allowed limit as per  policy benefits.Hence the amount over and above the allowed limit is disallowed' end end end,--else nvl(pad.remarks,'The claimed amount is more than the allowed limit as per  policy benefits.Hence the amount over and above the allowed limit is disallowed') end,
            pad.denial_desc = case when pad.approved_amount>v_rest_amount then  case when pad.denial_desc is  null then 'Annual limit/sublimit amount exceeded' else case when pad.denial_code like '%BENX-005%'then pad.denial_desc else pad.denial_desc||';'||'Annual limit/sublimit amount exceeded' end end else case when pad.approved_amount=0 then nvl(pad.denial_desc,'Annual limit/sublimit amount exceeded') end end,
            pad.denial_code = case when pad.approved_amount>v_rest_amount then case when pad.denial_code is  null then 'BENX-005' else case when pad.denial_code like '%BENX-005%'then pad.denial_code else pad.denial_code||';'||'BENX-005' end end else case when pad.approved_amount=0 then nvl(pad.denial_code,'BENX-005') end end,
            --pad.benifit_deductible=icd_rec.deduct,
            pad.updated_by = v_added_by,
            pad.updated_date = SYSDATE        
      WHERE pad.activity_dtl_seq_id = rec.activity_dtl_seq_id;
      v_rest_amount:=v_remain_amount;
     end if;
     END LOOP;
     END LOOP;
  ELSE
     FOR master_code in clm_master_code_cur LOOP
     if nvl(master_code.override_yn,'N')='N' then
      v_remain_amount:=null;
      v_rest_amount:=master_code.rule_limit;
     FOR rec in clm_act_cur(master_code.master_activity_code) loop
       if master_code.master_activity_code not in ('17.03','17.17') then
      v_rest_amount:=CASE WHEN rec.approved_amount>v_rest_amount  THEN v_rest_amount  WHEN rec.approved_amount<=v_rest_amount  THEN rec.approved_amount  ELSE v_rest_amount END;
      v_remain_amount:=nvl(v_remain_amount,master_code.rule_limit)-v_rest_amount;
       UPDATE pat_activity_details pad
        SET pad.approved_amount = case when v_rest_amount>0 then v_rest_amount else 0 end,
            pad.allowed_amount =  case when v_rest_amount>0 then v_rest_amount else 0 end,
            pad.remarks =  case when pad.approved_amount>v_rest_amount then case when pad.remarks is  null then 'The claimed amount is more than the allowed limit as per  policy benefits.Hence the amount over and above the allowed limit is disallowed' else case when pad.denial_code like '%BENX-005%'then pad.remarks else pad.remarks||';'||'The claimed amount is more than the allowed limit as per  policy benefits.Hence the amount over and above the allowed limit is disallowed' end end else pad.remarks end,
            pad.denial_desc = case when pad.approved_amount>v_rest_amount then  case when pad.denial_desc is  null then 'Annual limit/sublimit amount exceeded' else case when pad.denial_code like '%BENX-005%'then pad.denial_desc else pad.denial_desc||';'||'Annual limit/sublimit amount exceeded' end end else pad.denial_desc end,
            pad.denial_code = case when pad.approved_amount>v_rest_amount then case when pad.denial_code is  null then 'BENX-005' else case when pad.denial_code like '%BENX-005%'then pad.denial_code else pad.denial_code||';'||'BENX-005' end end else pad.denial_code end,
            pad.updated_by = v_added_by,
            pad.updated_date = SYSDATE        
      WHERE pad.activity_dtl_seq_id = rec.activity_dtl_seq_id;
      v_rest_amount:=v_remain_amount;
       elsif master_code.master_activity_code  in ('17.03','17.17') and rec.rule_unit!='PD'  then 
         v_rest_amount:=CASE WHEN rec.approved_amount>v_rest_amount  THEN v_rest_amount  WHEN rec.approved_amount<=v_rest_amount  THEN rec.approved_amount  ELSE v_rest_amount END;
       v_remain_amount:=nvl(v_remain_amount,master_code.rule_limit)-v_rest_amount;
       UPDATE pat_activity_details pad
        SET pad.approved_amount = case when v_rest_amount>0 then v_rest_amount else 0 end,
            pad.allowed_amount =  case when v_rest_amount>0 then v_rest_amount else 0 end,
            pad.remarks =  case when pad.approved_amount>v_rest_amount then case when pad.remarks is  null then 'The claimed amount is more than the allowed limit as per  policy benefits.Hence the amount over and above the allowed limit is disallowed' else case when pad.denial_code like '%BENX-005%'then pad.remarks else pad.remarks||';'||'The claimed amount is more than the allowed limit as per  policy benefits.Hence the amount over and above the allowed limit is disallowed' end end else pad.remarks end,
            pad.denial_desc = case when pad.approved_amount>v_rest_amount then  case when pad.denial_desc is  null then 'Annual limit/sublimit amount exceeded' else case when pad.denial_code like '%BENX-005%'then pad.denial_desc else pad.denial_desc||';'||'Annual limit/sublimit amount exceeded' end end else pad.denial_desc end,
            pad.denial_code = case when pad.approved_amount>v_rest_amount then case when pad.denial_code is  null then 'BENX-005' else case when pad.denial_code like '%BENX-005%'then pad.denial_code else pad.denial_code||';'||'BENX-005' end end else pad.denial_code end,
            pad.updated_by = v_added_by,
            pad.updated_date = SYSDATE        
      WHERE pad.activity_dtl_seq_id = rec.activity_dtl_seq_id;
      v_rest_amount:=v_remain_amount;
       end if;
     END LOOP;
     end if;
     END LOOP;
     /*FOR master_code in clm_master_code_cur LOOP
     --if nvl(v_item_sum,0)>nvl(master_code.rule_limit,0) then
      v_rest_amount:=master_code.rule_limit;
     FOR rec in clm_act_cur(master_code.master_activity_code) loop
      v_rest_amount:=CASE WHEN rec.approved_amount>v_rest_amount  THEN v_rest_amount  WHEN rec.approved_amount<=v_rest_amount  THEN rec.approved_amount  ELSE v_rest_amount END;
      v_remain_amount:=nvl(v_remain_amount,master_code.rule_limit)-v_rest_amount;
       UPDATE pat_activity_details pad
        SET pad.approved_amount = case when v_rest_amount>0 then v_rest_amount else 0 end,
            pad.allowed_amount =  case when v_rest_amount>0 then v_rest_amount else 0 end,
            pad.remarks =  case when pad.approved_amount>v_rest_amount then case when pad.remarks is  null then 'The claimed amount is more than the allowed limit as per  policy benefits.Hence the amount over and above the allowed limit is disallowed' else case when pad.denial_code like '%BENX-005%'then pad.remarks else pad.remarks||';'||'The claimed amount is more than the allowed limit as per  policy benefits.Hence the amount over and above the allowed limit is disallowed' end end else pad.remarks end,
            pad.denial_desc = case when pad.approved_amount>v_rest_amount then  case when pad.denial_desc is  null then 'Annual limit/sublimit amount exceeded' else case when pad.denial_code like '%BENX-005%'then pad.denial_desc else pad.denial_desc||';'||'Annual limit/sublimit amount exceeded' end end else pad.denial_desc end,
            pad.denial_code = case when pad.approved_amount>v_rest_amount then case when pad.denial_code is  null then 'BENX-005' else case when pad.denial_code like '%BENX-005%'then pad.denial_code else pad.denial_code||';'||'BENX-005' end end else pad.denial_code end,
            pad.updated_by = v_added_by,
            pad.updated_date = SYSDATE        
      WHERE pad.activity_dtl_seq_id = rec.activity_dtl_seq_id;
      v_rest_amount:=v_remain_amount;
     END LOOP;
     --end if;
     END LOOP;*/
     end if;
  
   
    OPEN act_cur_clm;
    FETCH act_cur_clm INTO act_rec;
    CLOSE act_cur_clm;
   
   UPDATE clm_authorization_details A
    SET a.tot_gross_amount           = act_rec.tot_gross_amount,
        a.tot_discount_amount        = act_rec.tot_discount_amount,
        a.tot_disc_gross_amount      = act_rec.tot_disc_gross_amount,
        a.tot_patient_share_amount   = act_rec.tot_patient_share_amount,
        a.tot_net_amount             = act_rec.tot_net_amount,
        a.tot_allowed_amount         = act_rec.tot_allowed_amount,
        a.tot_approved_amount        = act_rec.tot_approved_amount,
        a.remarks                    = v_remarks
   WHERE a.claim_seq_id           = v_seq_id 
   RETURNING a.tot_approved_amount INTO v_final_allowed_amount;
  
  ELSE
  
    IF icd_rec.day_care_icd_group_id='ICD001' and icd_rec.benifit_type= 'OPTS' THEN 
     v_pat_aprov_amount:=case when nvl(icd_rec.rule_limit,0)>=icd_rec.pat_approved_amount then icd_rec.pat_approved_amount else nvl(icd_rec.rule_limit,0) end ;
     v_rest_amount:= case when nvl(icd_rec.rule_limit,0)>=icd_rec.pat_approved_amount then icd_rec.pat_approved_amount else nvl(icd_rec.rule_limit,0) end ;
     FOR rec in clm_chronic_cur loop
     if nvl(rec.override_yn,'N')='N' then
     v_rest_amount:=CASE WHEN rec.approved_amount>v_rest_amount  THEN v_rest_amount  WHEN rec.approved_amount<=v_rest_amount  THEN rec.approved_amount  ELSE v_rest_amount END;
      v_remain_amount:=nvl(v_remain_amount,v_pat_aprov_amount)-v_rest_amount;
       UPDATE pat_activity_details pad
        SET pad.approved_amount = case when v_rest_amount>0 then v_rest_amount else 0 end,
            pad.allowed_amount =  case when v_rest_amount>0 then v_rest_amount else 0 end,
            pad.remarks =  case when pad.approved_amount>v_rest_amount then case when pad.remarks is  null then ' Chronic limit has been exceeded' else case when pad.denial_code like '%BENX-005%'then ' Chronic limit has been exceeded' else pad.remarks||';'||' Chronic limit has been exceeded' end end else ' Chronic limit has been exceeded' end,
            pad.denial_desc = case when pad.approved_amount>v_rest_amount then  case when pad.denial_desc is  null then 'Chronic limit has been exceeded' else case when pad.denial_code like '%BENX-005%'then pad.denial_desc else pad.denial_desc||';'||'Chronic limit has been exceeded ' end end else pad.denial_desc end,
            pad.denial_code = case when pad.approved_amount>v_rest_amount then case when pad.denial_code is  null then 'BENX-005' else case when pad.denial_code like '%BENX-005%'then pad.denial_code else pad.denial_code||';'||'BENX-005' end end else pad.denial_code end,
            --pad.benifit_deductible=icd_rec.deduct,
            pad.updated_by = v_added_by,
            pad.updated_date = SYSDATE        
      WHERE pad.activity_dtl_seq_id = rec.activity_dtl_seq_id;
      v_rest_amount:=v_remain_amount;
     end if;
     END LOOP;
   ELSIF v_benefit_type='DNTL' THEN
     FOR dent in clm_dental_cur LOOP
     v_pat_aprov_amount:=case when nvl(dent.benefit_limit,0)>=dent.pat_approved_amount then dent.pat_approved_amount else nvl(dent.benefit_limit,0) end ;
     v_rest_amount:=case when nvl(dent.benefit_limit,0)>=dent.pat_approved_amount then dent.pat_approved_amount else nvl(dent.benefit_limit,0) end ;
     FOR rec in clm_chronic_cur loop
     if nvl(rec.override_yn,'N')='N' then
      v_rest_amount:=CASE WHEN rec.approved_amount>v_rest_amount  THEN v_rest_amount  WHEN rec.approved_amount<=v_rest_amount  THEN rec.approved_amount  ELSE v_rest_amount END;
      v_remain_amount:=nvl(v_remain_amount,v_pat_aprov_amount)-v_rest_amount;
       UPDATE pat_activity_details pad
        SET pad.approved_amount = case when v_rest_amount>0 then v_rest_amount else 0 end,
            pad.allowed_amount =  case when v_rest_amount>0 then v_rest_amount else 0 end,
            pad.remarks =  case when pad.approved_amount>v_rest_amount then case when pad.remarks is  null then 'The claimed amount is more than the allowed limit as per  policy benefits.Hence the amount over and above the allowed limit is disallowed' else case when pad.denial_code like '%BENX-005%'then pad.remarks else pad.remarks||';'||'The claimed amount is more than the allowed limit as per  policy benefits.Hence the amount over and above the allowed limit is disallowed' end end else nvl(pad.remarks,'The claimed amount is more than the allowed limit as per  policy benefits.Hence the amount over and above the allowed limit is disallowed') end,
            pad.denial_desc = case when pad.approved_amount>v_rest_amount then  case when pad.denial_desc is  null then 'Annual limit/sublimit amount exceeded' else case when pad.denial_code like '%BENX-005%'then pad.denial_desc else pad.denial_desc||';'||'Annual limit/sublimit amount exceeded' end end else nvl(pad.denial_desc,'Annual limit/sublimit amount exceeded') end,
            pad.denial_code = case when pad.approved_amount>v_rest_amount then case when pad.denial_code is  null then 'BENX-005' else case when pad.denial_code like '%BENX-005%'then pad.denial_code else pad.denial_code||';'||'BENX-005' end end else nvl(pad.denial_code,'BENX-005') end,
            pad.benifit_deductible=icd_rec.deduct,
            pad.updated_by = v_added_by,
            pad.updated_date = SYSDATE        
      WHERE pad.activity_dtl_seq_id = rec.activity_dtl_seq_id;
      v_rest_amount:=v_remain_amount;
      end if;
     END LOOP;
    END LOOP;
    
   ELSIF v_benefit_type IN ('MTI', 'OMTI', 'IMTI') THEN
     FOR dent in clm_dental_cur LOOP
      v_pat_aprov_amount:=dent.pat_approved_amount;
      v_rest_amount:=case when nvl(dent.benefit_limit,0)>=dent.pat_approved_amount then dent.pat_approved_amount else nvl(dent.benefit_limit,0)end ;
     FOR rec in clm_chronic_cur loop
      if nvl(rec.override_yn,'N')='N' then
      v_rest_amount:=CASE WHEN rec.approved_amount>v_rest_amount  THEN v_rest_amount  WHEN rec.approved_amount<=v_rest_amount  THEN rec.approved_amount  ELSE v_rest_amount END;
      v_remain_amount:=nvl(v_remain_amount,v_pat_aprov_amount)-v_rest_amount;
       UPDATE pat_activity_details pad
        SET pad.approved_amount = case when v_rest_amount>0 then v_rest_amount else 0 end,
            pad.allowed_amount =  case when v_rest_amount>0 then v_rest_amount else 0 end,
            pad.remarks =  case when pad.approved_amount>v_rest_amount then case when pad.remarks is  null then 'The claimed amount is more than the allowed limit as per  policy benefits.Hence the amount over and above the allowed limit is disallowed' else case when pad.denial_code like '%BENX-005%'then pad.remarks else pad.remarks||';'||'The claimed amount is more than the allowed limit as per  policy benefits.Hence the amount over and above the allowed limit is disallowed' end end end,--else nvl(pad.remarks,'The claimed amount is more than the allowed limit as per  policy benefits.Hence the amount over and above the allowed limit is disallowed') end,
            pad.denial_desc = case when pad.approved_amount>v_rest_amount then  case when pad.denial_desc is  null then 'Annual limit/sublimit amount exceeded' else case when pad.denial_code like '%BENX-005%'then pad.denial_desc else pad.denial_desc||';'||'Annual limit/sublimit amount exceeded' end end else case when pad.approved_amount=0 then nvl(pad.denial_desc,'Annual limit/sublimit amount exceeded') end end,
            pad.denial_code = case when pad.approved_amount>v_rest_amount then case when pad.denial_code is  null then 'BENX-005' else case when pad.denial_code like '%BENX-005%'then pad.denial_code else pad.denial_code||';'||'BENX-005' end end else case when pad.approved_amount=0 then nvl(pad.denial_code,'BENX-005') end end,
            --pad.benifit_deductible=icd_rec.deduct,
            pad.updated_by = v_added_by,
            pad.updated_date = SYSDATE        
      WHERE pad.activity_dtl_seq_id = rec.activity_dtl_seq_id;
      v_rest_amount:=v_remain_amount;
     end if;
     END LOOP;
     END LOOP;
  
  ELSIF  v_benefit_type = 'IPT'  THEN                         ----
    FOR master_code in clm_master_code_cur LOOP
     if nvl(master_code.override_yn,'N')='N' then
     v_remain_amount:=null;
     v_pat_aprov_amount:=case when nvl(master_code.rule_limit,0)>=master_code.pat_approved_amount then master_code.pat_approved_amount else master_code.rule_limit end;
     v_rest_amount:=case when master_code.rule_limit> 0 then case when master_code.rule_limit>=master_code.pat_approved_amount then master_code.pat_approved_amount else nvl(master_code.rule_limit,0) end else master_code.pat_approved_amount end  ;
     FOR rec in clm_act_cur(master_code.master_activity_code) loop
      v_rest_amount:=CASE WHEN rec.approved_amount>v_rest_amount  THEN v_rest_amount  WHEN rec.approved_amount<=v_rest_amount  THEN rec.approved_amount  ELSE v_rest_amount END;
      v_remain_amount:=nvl(v_remain_amount,v_pat_aprov_amount)-v_rest_amount;
       UPDATE pat_activity_details pad
        SET pad.approved_amount = case when v_rest_amount>0 then v_rest_amount else 0 end,
            pad.allowed_amount =  case when v_rest_amount>0 then v_rest_amount else 0 end,
            pad.remarks =  case when pad.approved_amount>v_rest_amount then case when pad.remarks is  null then ' The claimed amount is more than the allowed limit as per  policy benefits.Hence the amount over and above the allowed limit is disallowed' else case when pad.denial_code like '%AUTH-005%'then pad.remarks else pad.remarks||';'||'The claimed amount is more than the allowed limit as per  policy benefits.Hence the amount over and above the allowed limit is disallowed' end end else pad.remarks end,
            pad.denial_desc = case when pad.approved_amount>v_rest_amount then  case when pad.denial_desc is  null then 'Claim information is inconsistent with pre-certified/authorized services' else case when pad.denial_code like '%AUTH-005%'then pad.denial_desc else pad.denial_desc||';'||'Claim information is inconsistent with pre-certified/authorized services' end end else pad.denial_desc end,
            pad.denial_code = case when pad.approved_amount>v_rest_amount then case when pad.denial_code is  null then 'AUTH-005' else case when pad.denial_code like '%AUTH-005%'then pad.denial_code else pad.denial_code||';'||'AUTH-005' end end else pad.denial_code end,
            pad.updated_by = v_added_by,
            pad.updated_date = SYSDATE        
      WHERE pad.activity_dtl_seq_id = rec.activity_dtl_seq_id;
      v_rest_amount:=v_remain_amount;
     END LOOP;
     end if;
     END LOOP;  
       
       OPEN act_cur_clm;
       FETCH act_cur_clm INTO act_rec;
       CLOSE act_cur_clm;
      v_remain_amount:=null;
    FOR dent in clm_dental_cur LOOP
     v_rest_amount:=case when nvl(act_rec.tot_allowed_amount,0)>=dent.pat_approved_amount then dent.pat_approved_amount else nvl(act_rec.tot_allowed_amount,0)end ;
     v_pat_aprov_amount:=case when nvl(act_rec.tot_allowed_amount,0)>=dent.pat_approved_amount then dent.pat_approved_amount else nvl(act_rec.tot_allowed_amount,0)end ;
     FOR rec in clm_chronic_cur loop
      if nvl(rec.override_yn,'N')='N' then
      v_rest_amount:=CASE WHEN rec.approved_amount>v_rest_amount  THEN v_rest_amount  WHEN rec.approved_amount<=v_rest_amount  THEN rec.approved_amount  ELSE v_rest_amount END;
      v_remain_amount:=nvl(v_remain_amount,v_pat_aprov_amount)-v_rest_amount;
       UPDATE pat_activity_details pad
        SET pad.approved_amount = case when v_rest_amount>0 then v_rest_amount else 0 end,
            pad.allowed_amount =  case when v_rest_amount>0 then v_rest_amount else 0 end,
            pad.remarks =  case when pad.approved_amount>v_rest_amount then case when pad.remarks is  null then 'The claimed amount is more than the allowed limit as per  policy benefits.Hence the amount over and above the allowed limit is disallowed' else case when pad.denial_code like '%AUTH-005%'then pad.remarks else pad.remarks||';'||'The claimed amount is more than the allowed limit as per  policy benefits.Hence the amount over and above the allowed limit is disallowed' end end else nvl(pad.remarks,'The claimed amount is more than the allowed limit as per  policy benefits.Hence the amount over and above the allowed limit is disallowed') end,
            pad.denial_desc = case when pad.approved_amount>v_rest_amount then  case when pad.denial_desc is  null then 'Claim information is inconsistent with pre-certified/authorized services' else case when pad.denial_code like '%AUTH-005%'then pad.denial_desc else pad.denial_desc||';'||'Claim information is inconsistent with pre-certified/authorized services' end end else pad.denial_desc end,
            pad.denial_code = case when pad.approved_amount>v_rest_amount then case when pad.denial_code is  null then 'AUTH-005' else case when pad.denial_code like '%AUTH-005%'then pad.denial_code else pad.denial_code||';'||'AUTH-005' end end else pad.denial_code end,
            ---pad.benifit_deductible=icd_rec.deduct,
            pad.updated_by = v_added_by,
            pad.updated_date = SYSDATE        
      WHERE pad.activity_dtl_seq_id = rec.activity_dtl_seq_id;
      v_rest_amount:=v_remain_amount;
     end if;
     END LOOP;
     END LOOP;----
  ELSE
     FOR master_code in clm_master_code_cur LOOP
     if nvl(master_code.override_yn,'N')='N' then
     v_remain_amount:=null;
     v_pat_aprov_amount:=master_code.pat_approved_amount;
     v_rest_amount:=case when master_code.rule_limit> 0 then case when master_code.rule_limit>=master_code.pat_approved_amount then master_code.pat_approved_amount else nvl(master_code.rule_limit,0) end else master_code.pat_approved_amount end  ;
     FOR rec in clm_act_cur(master_code.master_activity_code) loop
      v_rest_amount:=CASE WHEN rec.approved_amount>v_rest_amount  THEN v_rest_amount  WHEN rec.approved_amount<=v_rest_amount  THEN rec.approved_amount  ELSE v_rest_amount END;
      v_remain_amount:=nvl(v_remain_amount,master_code.pat_approved_amount)-v_rest_amount;
       UPDATE pat_activity_details pad
        SET pad.approved_amount = case when v_rest_amount>0 then v_rest_amount else 0 end,
            pad.allowed_amount =  case when v_rest_amount>0 then v_rest_amount else 0 end,
            pad.remarks =  case when pad.approved_amount>v_rest_amount then case when pad.remarks is  null then ' The claimed amount is more than the allowed limit as per  policy benefits.Hence the amount over and above the allowed limit is disallowed' else case when pad.denial_code like '%BENX-005%'then pad.remarks else pad.remarks||';'||'The claimed amount is more than the allowed limit as per  policy benefits.Hence the amount over and above the allowed limit is disallowed' end end else pad.remarks end,
            pad.denial_desc = case when pad.approved_amount>v_rest_amount then  case when pad.denial_desc is  null then 'Annual limit/sublimit amount exceeded' else case when pad.denial_code like '%BENX-005%'then pad.denial_desc else pad.denial_desc||';'||'Annual limit/sublimit amount exceeded' end end else pad.denial_desc end,
            pad.denial_code = case when pad.approved_amount>v_rest_amount then case when pad.denial_code is  null then 'BENX-005' else case when pad.denial_code like '%BENX-005%'then pad.denial_code else pad.denial_code||';'||'BENX-005' end end else pad.denial_code end,
            pad.updated_by = v_added_by,
            pad.updated_date = SYSDATE        
      WHERE pad.activity_dtl_seq_id = rec.activity_dtl_seq_id;
      v_rest_amount:=v_remain_amount;
     END LOOP;
     end if;
     END LOOP;  
       
       OPEN act_cur_clm;
       FETCH act_cur_clm INTO act_rec;
       CLOSE act_cur_clm;
      v_remain_amount:=null;
    FOR dent in clm_dental_cur LOOP
     v_rest_amount:=case when nvl(act_rec.tot_allowed_amount,0)>=dent.pat_approved_amount then dent.pat_approved_amount else nvl(act_rec.tot_allowed_amount,0)end ;
     v_pat_aprov_amount:=case when nvl(act_rec.tot_allowed_amount,0)>=dent.pat_approved_amount then dent.pat_approved_amount else nvl(act_rec.tot_allowed_amount,0)end ;
     FOR rec in clm_chronic_cur loop
      if nvl(rec.override_yn,'N')='N' then
      v_rest_amount:=CASE WHEN rec.approved_amount>v_rest_amount  THEN v_rest_amount  WHEN rec.approved_amount<=v_rest_amount  THEN rec.approved_amount  ELSE v_rest_amount END;
      v_remain_amount:=nvl(v_remain_amount,v_pat_aprov_amount)-v_rest_amount;
       UPDATE pat_activity_details pad
        SET pad.approved_amount = case when v_rest_amount>0 then v_rest_amount else 0 end,
            pad.allowed_amount =  case when v_rest_amount>0 then v_rest_amount else 0 end,
            pad.remarks =  case when pad.approved_amount>v_rest_amount then case when pad.remarks is  null then 'The claimed amount is more than the allowed limit as per  policy benefits.Hence the amount over and above the allowed limit is disallowed' else case when pad.denial_code like '%BENX-005%'then pad.remarks else pad.remarks||';'||'The claimed amount is more than the allowed limit as per  policy benefits.Hence the amount over and above the allowed limit is disallowed' end end else nvl(pad.remarks,'The claimed amount is more than the allowed limit as per  policy benefits.Hence the amount over and above the allowed limit is disallowed') end,
            pad.denial_desc = case when pad.approved_amount>v_rest_amount then  case when pad.denial_desc is  null then 'Annual limit/sublimit amount exceeded' else case when pad.denial_code like '%BENX-005%'then pad.denial_desc else pad.denial_desc||';'||'Annual limit/sublimit amount exceeded' end end else pad.denial_desc end,
            pad.denial_code = case when pad.approved_amount>v_rest_amount then case when pad.denial_code is  null then 'BENX-005' else case when pad.denial_code like '%BENX-005%'then pad.denial_code else pad.denial_code||';'||'BENX-005' end end else pad.denial_code end,
            ---pad.benifit_deductible=icd_rec.deduct,
            pad.updated_by = v_added_by,
            pad.updated_date = SYSDATE        
      WHERE pad.activity_dtl_seq_id = rec.activity_dtl_seq_id;
      v_rest_amount:=v_remain_amount;
     end if;
     END LOOP;
     END LOOP; 
    
   end if;
   
   end if;
     OPEN act_cur_clm;
     FETCH act_cur_clm INTO act_rec;
     CLOSE act_cur_clm;
   
   UPDATE clm_authorization_details A
    SET a.tot_gross_amount           = act_rec.tot_gross_amount,
        a.tot_discount_amount        = act_rec.tot_discount_amount,
        a.tot_disc_gross_amount      = act_rec.tot_disc_gross_amount,
        a.tot_patient_share_amount   = act_rec.tot_patient_share_amount,
        a.tot_net_amount             = act_rec.tot_net_amount,
        a.tot_allowed_amount         = act_rec.tot_allowed_amount,
        a.tot_approved_amount        = act_rec.tot_approved_amount,
        a.remarks                    = v_remarks
   WHERE a.claim_seq_id           = v_seq_id 
   RETURNING a.tot_approved_amount INTO v_final_allowed_amount;
  END IF;
  
END check_activity_limits;
--============================================================================
-- Save Shortfall Detals
PROCEDURE save_shortfall_details (p_shortfall_seq_id      IN shortfall_details.shortfall_seq_id%TYPE,
                                  p_shortfall_file        IN shortfall_details.uploaded_file%TYPE,
                                  p_status                OUT VARCHAR2,
                                  p_added_by              IN shortfall_details.added_by%TYPE := NULL
                                 )
AS
  CURSOR clm_cur(v_claim_seq_id NUMBER) IS
     SELECT c.claim_type
     FROM Clm_Authorization_Details c
     JOIN Shortfall_Details s ON (c.claim_seq_id = s.claim_seq_id)
     WHERE s.shortfall_seq_id = p_shortfall_seq_id
     AND c.claim_seq_id = v_claim_seq_id;
  
  CURSOR shrtfll_cur IS
    select s.pat_gen_detail_seq_id, s.claim_seq_id
    from shortfall_details s
    where s.shortfall_seq_id = p_shortfall_seq_id;
      
  v_shortfall_file               shortfall_details.uploaded_file%TYPE;
  v_added_by                     NUMBER;
  v_desc_msg_seq_id              VARCHAR2(30);
  v_pat_seq_id                   NUMBER;
  v_clm_seq_id                   NUMBER;
  v_network_type                 VARCHAR2(5);
BEGIN
  
  OPEN shrtfll_cur;
  FETCH shrtfll_cur INTO v_pat_seq_id, v_clm_seq_id;
  CLOSE shrtfll_cur;
  
  v_shortfall_file := p_shortfall_file;
  
  IF v_shortfall_file IS NOT NULL THEN
    p_status := 'Y';
  ELSE
    p_status := 'N';
  END IF;
  /*select sh.added_by into v_added_by
  from shortfall_details sh
  where sh.shortfall_seq_id = p_shortfall_seq_id;*/
  
    UPDATE shortfall_details c
    SET uploaded_file = v_shortfall_file,
        docs_status   = p_status,
        srtfll_status_general_type_id = 'RES',
        srtfll_received_date  = SYSDATE,
        c.updated_by = p_added_by
    WHERE shortfall_seq_id = p_shortfall_seq_id;
    
    IF v_pat_seq_id IS NOT NULL THEN
      UPDATE Pat_Authorization_Details p
      SET p.pat_status_type_id = 'INP',
          p.updated_date = SYSDATE
      WHERE p.pat_auth_seq_id = v_pat_seq_id;
    
      generate_mail_pkg.proc_generate_message('PREAUTH_SHORTFALL_RECEIVED', p_shortfall_seq_id, p_added_by, v_desc_msg_seq_id); 
    ELSE
      UPDATE Clm_Authorization_Details c
      SET c.clm_status_type_id = 'INP',
          c.updated_date = SYSDATE
      WHERE c.claim_seq_id = v_clm_seq_id;
        
      OPEN clm_cur(v_clm_seq_id);
      FETCH clm_cur INTO v_network_type;
      CLOSE clm_cur;
      
      IF v_network_type = 'CTM' THEN
        generate_mail_pkg.proc_generate_message('CLAIM_SHORTFALL', p_shortfall_seq_id, p_added_by, v_desc_msg_seq_id);
      END IF;
    END IF;
  commit;
END save_shortfall_details;
--==============================================================================
PROCEDURE save_authorization(v_pat_auth_seq_id                 IN pat_authorization_details.Pat_Auth_Seq_Id%TYPE,
                             v_member_seq_id                   IN pat_authorization_details.member_seq_id%TYPE,
                             v_auth_number                     IN OUT pat_authorization_details.Auth_Number%TYPE,
                             v_admission_date                  IN pat_authorization_details.hospitalization_date%type,
                             v_allowed_amount                  IN pat_authorization_details.Tot_Allowed_Amount%TYPE,
                             v_source_type_id                  IN pat_authorization_details.source_type_id%TYPE,
                             v_pat_status_type_id              IN OUT pat_authorization_details.Pat_Status_Type_Id%TYPE,
                             v_medical_opinion_remarks         IN pat_authorization_details.medical_opinion_remarks%type,
                             v_added_by                        IN  NUMBER,
                             v_prov_yn                         IN  VARCHAR2,
                             v_rows_processed                  OUT NUMBER)
IS

CURSOR mem_cur IS
SELECT a.date_of_inception,a.date_of_exit,a.member_seq_id,b.policy_group_seq_id,c.policy_seq_id,c.policy_sub_general_type_id FROM tpa_enr_policy_member a
JOIN tpa_enr_policy_group b on (a.policy_group_seq_id=b.policy_group_seq_id)
JOIN tpa_enr_policy c on (b.policy_seq_id=c.policy_seq_id)
WHERE a.member_seq_id=v_member_seq_id;

mem_rec             mem_cur%ROWTYPE;

CURSOR pat_cur IS
SELECT * FROM pat_authorization_details pad
WHERE pad.pat_auth_seq_id=v_pat_auth_seq_id;

pat_rec  pat_cur%rowtype;
CURSOR floater_cur(v_policy_group_seq_id    tpa_enr_policy_group.policy_group_seq_id%type)
 IS 
SELECT a.policy_group_seq_id,
       SUM(A.mem_sum_insured) AS sum_insured,
       b.sum_insured as tot_sum_insured,
       b.utilised_sum_insured  FROM tpa_enr_mem_insured a
JOIN tpa_enr_balance b on (a.policy_group_seq_id=b.policy_group_seq_id)
WHERE a.policy_group_seq_id=v_policy_group_seq_id
--AND a.policy_date<=v_admission_date
GROUP BY a.policy_group_seq_id,b.sum_insured,b.utilised_sum_insured;

CURSOR nonfloater_cur(v_member_seq_id    tpa_enr_policy_member.member_seq_id%type)
 IS 
SELECT a.member_seq_id,
       SUM(A.mem_sum_insured) AS sum_insured,
       b.sum_insured as tot_sum_insured,
       b.utilised_sum_insured
       
FROM tpa_enr_mem_insured a
JOIN tpa_enr_balance b on (a.member_seq_id=b.member_seq_id)
WHERE a.member_seq_id=v_member_seq_id
--AND a.policy_date<=v_admission_date
GROUP BY a.member_seq_id,b.sum_insured,b.utilised_sum_insured;

CURSOR shortfall_count IS 
SELECT COUNT(1)  FROM APP.shortfall_details s where 
 s.srtfll_status_general_type_id='OPN' and s.pat_gen_detail_seq_id=v_pat_auth_seq_id ;
  

sum_rec              floater_cur%rowtype;
v_ava_sum_insured    tpa_enr_balance.utilised_sum_insured%type;
v_app_amount         pat_authorization_details.final_app_amount%type;
v_reason             pat_authorization_details.remarks%type;
v_denial_reason      pat_authorization_details.denial_reason%type;
v_count              number(10);
v_dest_msg_seq_id    VARCHAR2(250);
v_out_preauth xmltype;

BEGIN
  
  OPEN mem_cur;
  FETCH mem_cur INTO mem_rec;
  CLOSE mem_cur;
  
  OPEN pat_cur;
  FETCH pat_cur INTO pat_rec;
  CLOSE pat_cur;
  
  IF pat_rec.Completed_Yn='Y' THEN
    RAISE_APPLICATION_ERROR(-20107,'You cannot perform this action through a completed Claim.');
  END IF;
  
  open shortfall_count;
  fetch shortfall_count into v_count;
  close shortfall_count;
  
  IF v_count>0 and v_pat_status_type_id ='APR'then 
    RAISE_APPLICATION_ERROR(-20387,'Please close the opened shortfall before complete the Pre_auth/Claim.');
  END IF;
   
   IF mem_rec.policy_sub_general_type_id='PFL' THEN
    OPEN floater_cur(mem_rec.policy_group_seq_id);
    FETCH floater_cur INTO sum_rec;
    CLOSE floater_cur;
   ELSIF  mem_rec.policy_sub_general_type_id='PNF' THEN
    OPEN nonfloater_cur(mem_rec.member_seq_id);
    FETCH nonfloater_cur INTO sum_rec;
    CLOSE nonfloater_cur;
  END IF; 
  
  v_ava_sum_insured:=(NVL(sum_rec.sum_insured,0)-NVL(sum_rec.utilised_sum_insured,0)) ;  
     
    IF v_pat_status_type_id='APR' THEN
      IF v_allowed_amount<=v_ava_sum_insured THEN
         v_app_amount:=v_allowed_amount; 
      ELSE 
         RAISE_APPLICATION_ERROR(-20737,'Sufficient Balance doesnot exist');
      END IF;   
    ELSIF v_pat_status_type_id='REJ' THEN
          v_app_amount:=0;
    END IF; 
    
  IF v_auth_number IS NULL THEN
    v_auth_number:=authorization_pkg.generate_id_numbers('AT',NULL,NULL,pat_rec.pre_auth_number);
  END IF;
  
   UPDATE pat_authorization_details a
     SET A.final_app_amount   = v_app_amount,
         a.pat_status_type_id = v_pat_status_type_id ,
         a.medical_opinion_remarks            = NVL(v_medical_opinion_remarks,v_reason),
         a.denial_reason      = v_denial_reason,
         A.auth_number        = v_auth_number,
         A.completed_yn       = case when v_pat_status_type_id IN ('REJ','CAN','APR') THEN 'Y' ELSE 'N' END,
         a.completed_date     = case when v_pat_status_type_id IN ('REJ','CAN','APR') THEN sysdate end,
         a.updated_by         = v_added_by,
         a.updated_date       = SYSDATE,
         a.authorized_by      = v_added_by
     WHERE A.pat_auth_seq_id  = v_pat_auth_seq_id;
 
 IF v_pat_status_type_id='APR' then
 
 v_out_preauth:= pat_xml_load_pkg.upload_priorAuth_xml(v_pat_auth_seq_id);
 
 update app.pat_upload_dhpo_dtls d 
 set d.upload_file = v_out_preauth,
     d.added_by    = v_added_by,
     d.added_date  = sysdate ,
     d.up_load_status='N'
  where d.pat_seq_id = v_pat_auth_seq_id;
 
 IF mem_rec.policy_sub_general_type_id='PFL' THEN    
   UPDATE tpa_enr_balance b
   SET b.utilised_sum_insured = nvl(b.utilised_sum_insured,0) + v_app_amount,
       b.updated_by           = v_added_by,
       b.updated_date         = SYSDATE
   WHERE b.policy_group_seq_id = mem_rec.policy_group_seq_id;
 ELSIF mem_rec.policy_sub_general_type_id='PNF' THEN  
  UPDATE tpa_enr_balance b
   SET b.utilised_sum_insured = nvl(b.utilised_sum_insured,0) + v_app_amount,
       b.updated_by           = v_added_by,
       b.updated_date         = SYSDATE
   WHERE b.member_seq_id      = mem_rec.member_seq_id; 
 END IF;
 END IF;
 
 v_rows_processed:=SQL%ROWCOUNT;
 
COMMIT;

  IF v_pat_status_type_id='APR' then
    --IF NVL(v_prov_yn, 'N') = 'N' THEN
      GENERATE_MAIL_PKG.proc_generate_message('PREAUTH_APPROVED',
                                            v_pat_auth_seq_id,
                                            v_added_by,
                                            v_dest_msg_seq_id);

      GENERATE_MAIL_PKG.proc_generate_message('PREAUTH_APPROVED_NHCP',
                                            v_pat_auth_seq_id,
                                            v_added_by,
                                            v_dest_msg_seq_id);
    --ELSE
      /*GENERATE_MAIL_PKG.proc_generate_message('PREAUTH_APPROVED_NHCP',
                                            v_pat_auth_seq_id,
                                            v_added_by,
                                            v_dest_msg_seq_id);*/
    --END IF;
  ELSIF v_pat_status_type_id='REJ' then
    GENERATE_MAIL_PKG.proc_generate_message('PREAUTH_REJECTED',
                                          v_pat_auth_seq_id,
                                          v_added_by,
                                          v_dest_msg_seq_id);
    GENERATE_MAIL_PKG.proc_generate_message('PREAUTH_REJECTED_NHCP',
                                          v_pat_auth_seq_id,
                                          v_added_by,
                                          v_dest_msg_seq_id);
  END IF;
  
END save_authorization;
--=============================================================================================
PROCEDURE select_activity_list (
    v_description              IN OUT tpa_activity_master_details.activity_description%TYPE,
    v_hosp_seq_id              IN NUMBER,
    v_sort_order               IN OUT VARCHAR2,
    v_start_num                IN OUT NUMBER  ,
    v_end_num                  IN OUT NUMBER  ,
    v_flag                     IN VARCHAR2,
    v_tpa_enrollment_id        IN VARCHAR2,
    v_result_set               OUT SYS_REFCURSOR
  )
  IS
  v_str                      VARCHAR2(2000);
  v_sort_var                 VARCHAR2(20);
  
  Cursor tariff_mem_cur is 
  SELECT tip.product_cat_type_id,tep.ins_seq_id,tep.group_reg_seq_id, tep.policy_seq_id,tep.tariff_type_id
  FROM app.tpa_enr_policy_member tem
  JOIN app.tpa_enr_policy_group teg ON (tem.policy_group_seq_id = teg.policy_group_seq_id)
  JOIN tpa_enr_policy tep ON (teg.policy_seq_id=tep.policy_seq_id)
  JOIN tpa_ins_product tip ON (tep.product_seq_id=tip.product_seq_id)
  WHERE tem.tpa_enrollment_id = trim(v_tpa_enrollment_id)
  AND TO_DATE(SYSDATE, 'DD/MM/RRRR') BETWEEN TO_DATE(tep.effective_from_date, 'DD/MM/RRRR') AND TO_DATE(tep.effective_to_date, 'DD/MM/RRRR');
  
  mem_rec             tariff_mem_cur%ROWTYPE;
  
  /*Cursor provider_cur is    
   select g.general_type_id
   from tpa_general_code g
   join tpa_hosp_network hn on hn.network_type = g.general_type_id
   join tpa_hosp_info i on i.hosp_seq_id = hn.hosp_seq_id
   where g.header_type = 'PROVIDER_NETWORK'
   and i.hosp_seq_id = v_hosp_seq_id
   and hn.network_yn = 'Y';
     */
   v_network_type   VARCHAR2(5);
   
   CURSOR provider_network(v_product_net_type varchar2) IS
   SELECT i.primary_network, ny.network_type, ny.network_yn, gc.sort_no
   FROM tpa_hosp_info i, app.tpa_hosp_network ny, app.tpa_general_code gc
   where ny.hosp_seq_id = i.hosp_seq_id
   and gc.general_type_id = ny.network_type
   and gc.header_type = 'PROVIDER_NETWORK'
   and ny.network_yn = 'Y'
   and i.hosp_seq_id = v_hosp_seq_id
   and gc.sort_no =
       (SELECT min(gc.sort_no)
          FROM tpa_hosp_info        i,
               app.tpa_hosp_network ny,
               app.tpa_general_code gc
          where ny.hosp_seq_id = i.hosp_seq_id
          and gc.general_type_id = ny.network_type
          and gc.header_type = 'PROVIDER_NETWORK'
          and ny.network_yn = 'Y'
          and i.hosp_seq_id = v_hosp_seq_id
          and gc.sort_no >=
               (SELECT min(gc.sort_no)
                  FROM tpa_hosp_info        i,
                       app.tpa_hosp_network ny,
                       app.tpa_general_code gc
                  where ny.hosp_seq_id = i.hosp_seq_id
                   and gc.general_type_id = ny.network_type
                   and gc.header_type = 'PROVIDER_NETWORK'
                   and i.hosp_seq_id = v_hosp_seq_id
                   and gc.general_type_id = v_product_net_type))
    order by gc.sort_no;

    provider_rec   provider_network%rowtype;

    v_product_network_type   VARCHAR2(100);
  BEGIN
    
    OPEN tariff_mem_cur;
     FETCH tariff_mem_cur INTO mem_rec;
     close tariff_mem_cur;
    
    OPEN provider_network(mem_rec.product_cat_type_id);
    FETCH provider_network INTO provider_rec;
    CLOSE provider_network;
    
    v_product_network_type := provider_rec.network_type;
    --------------
    /*OPEN provider_cur;
    FETCH provider_cur INTO v_network_type;
    CLOSE provider_cur;*/
    
    v_sort_var   := CASE WHEN  v_sort_var IS NULL  then 'SEARCH_DATA' ELSE v_sort_var END;
    v_sort_order := CASE WHEN v_sort_order IS NULL THEN 'ASC' ELSE v_sort_order END;
    v_start_num  := CASE WHEN v_start_num IS NULL THEN 1 ELSE v_start_num END;
    v_end_num    := CASE WHEN v_end_num IS NULL THEN 101 ELSE v_end_num END;
    
    --v_act_code         := CASE WHEN v_act_code IS NOT NULL THEN UPPER(v_act_code)||'%' ELSE v_act_code END;
    IF v_flag = 'CODE' THEN
      v_description      := CASE WHEN v_description IS NULL THEN UPPER(v_description||'%') ELSE UPPER(v_description||'%') END;
    ELSIF v_flag = 'INTERNALCODE' THEN
      v_description      := UPPER(v_description||'%');
    ELSE
      v_description      := CASE WHEN v_description IS NULL THEN UPPER(replace(v_description,' ','%'))||'%' ELSE '%'||UPPER(replace(v_description,' ','%'))||'%' END;
    END IF;
    
    IF v_flag = 'CODE' THEN
      v_str :=
         /*'SELECT DISTINCT * FROM (SELECT (md.activity_description||''--''||t.internal_code||''#''||md.activity_code) as search_data
         FROM tpa_hosp_tariff_details t
         FULL join tpa_activity_master_details md on (md.act_mas_dtl_seq_id = t.activity_seq_id)
         WHERE length(md.activity_code) < 16
         AND (:v_description IS NULL OR upper(md.activity_code) LIKE :v_description )
         ORDER BY md.activity_code)';*/  
         'SELECT search_data, ACT_CODE FROM 
         (SELECT md.activity_description||''--''||null||''--''||d.tooth_no_required||''#''||md.activity_code||''--''||NVL2(ra.activity_code,1,0) as search_data, md.activity_code AS ACT_CODE
          FROM tpa_activity_master_details md
          LEFT JOIN tpa_pharmacy_master_details tp ON (tp.act_mas_dtl_seq_id = md.act_mas_dtl_seq_id)
          LEFT JOIN dental_rule_tab d ON (d.cdt_code = md.activity_code)
          LEFT JOIN tpa_restrict_activity_tab ra ON (md.activity_code=ra.activity_code)
          WHERE length(md.activity_code) < 16
          AND (:v_description1 IS NULL OR upper(md.activity_code) LIKE :v_description2 )
          AND  UPPER(d.network_type)IN (select general_type_id
                                     FROM (select g.general_type_id, g.sort_no, dense_rank() over(order by g.sort_no) r
                                           from tpa_general_code g
                                           where g.header_type = ''PROVIDER_NETWORK''
                                          ) q
          WHERE  q.r >=(select sort_no from tpa_general_code where general_type_id = :v_product_network_type)))
          
          UNION
          
          SELECT null||''--''||t.internal_code||''--''||null||''#''||null||''--''||null as search_data, t.internal_code AS ACT_CODE
          FROM tpa_hosp_tariff_details t
          WHERE t.internal_code = :v_description3
          AND  UPPER(d.network_type)IN (select general_type_id
                                     FROM (select g.general_type_id, g.sort_no, dense_rank() over(order by g.sort_no) r
                                           from tpa_general_code g
                                           where g.header_type = ''PROVIDER_NETWORK''
                                          ) q
          WHERE  q.r >=(select sort_no from tpa_general_code where general_type_id = :v_product_network_type)))
         )
         ORDER BY ACT_CODE ASC';  
         
      v_str := 'SELECT * FROM
        (SELECT A.*, DENSE_RANK() OVER (ORDER BY '||'ACT_CODE'||' '||v_sort_order||',ROWNUM) Q FROM (' ||v_str|| ') A )
         WHERE  Q>= :v_start_num  AND Q<= :v_end_num ';
         
    ELSIF v_flag = 'DESC' THEN
      v_str := 
        'SELECT DISTINCT * FROM (SELECT (md.activity_code||''--''||t.internal_code||''--''||d.tooth_no_required||''--''||t.hosp_tariff_seq_id||''--''||(t.gross_amount)||''#''||t.hosp_act_desc||''--''||NVL2(ra.activity_code,1,0)) as search_data
         FROM tpa_hosp_tariff_details t
         --FULL join tpa_activity_details ta on (t.activity_seq_id = ta.activity_seq_id)
         LEFT join tpa_activity_master_details md on (md.act_mas_dtl_seq_id = t.activity_seq_id)
         LEFT JOIN dental_rule_tab d ON (d.cdt_code = md.activity_code)
         --WHERE md.activity_type_seq_id NOT IN (5, 3)
         LEFT JOIN tpa_restrict_activity_tab ra ON (md.activity_code=ra.activity_code)
         WHERE md.service_seq_id NOT IN (14)
         AND length(md.activity_code) < 16
         AND (UPPER(:v_description) IS NULL OR upper(t.hosp_act_desc) LIKE UPPER(:v_description) )
         AND  UPPER(t.network_type)IN (select general_type_id
                                     FROM (select g.general_type_id, g.sort_no, dense_rank() over(order by g.sort_no) r
                                           from tpa_general_code g
                                           where g.header_type = ''PROVIDER_NETWORK''
                                          ) q
         WHERE  q.r >=(select sort_no from tpa_general_code where general_type_id = :v_product_network_type))
         AND t.hosp_seq_id = '||v_hosp_seq_id||')';   
        
         
      v_str := 'SELECT * FROM
        (SELECT A.*, DENSE_RANK() OVER (ORDER BY '||v_sort_var||' '||v_sort_order||',ROWNUM) Q FROM (' ||v_str|| ') A )
         WHERE  Q>= :v_start_num  AND Q<= :v_end_num ';
    
    ELSIF v_flag = 'INTERNALCODE' THEN
      v_str := 
        'SELECT DISTINCT * FROM (SELECT (md.activity_code||''--''||t.hosp_act_desc||''--''||d.tooth_no_required||''--''||t.hosp_tariff_seq_id||''--''||(t.gross_amount)||''#''||t.internal_code||''--''||NVL2(ra.activity_code,1,0)) as search_data
         FROM tpa_hosp_tariff_details t
         --LEFT join tpa_activity_details ta on (t.activity_seq_id = ta.activity_seq_id)
         LEFT join tpa_activity_master_details md on (md.act_mas_dtl_seq_id = t.activity_seq_id)
         LEFT JOIN dental_rule_tab d ON (d.cdt_code = md.activity_code)
         --WHERE md.activity_type_seq_id NOT IN (5, 3)
         LEFT JOIN tpa_restrict_activity_tab ra ON (md.activity_code=ra.activity_code)
         WHERE md.service_seq_id NOT IN (14)
         AND length(md.activity_code) < 16
         AND (:v_description IS NULL OR upper(t.internal_code) LIKE :v_description )
         AND  UPPER(t.network_type)IN (select general_type_id
                                       FROM (select g.general_type_id, g.sort_no, dense_rank() over(order by g.sort_no) r
                                             from tpa_general_code g
                                             where g.header_type = ''PROVIDER_NETWORK''
                                            ) q
         WHERE  q.r >=(select sort_no from tpa_general_code where general_type_id = :v_product_network_type))
         AND t.hosp_seq_id = '||v_hosp_seq_id;  
        
         
      v_str := 'SELECT * FROM
        (SELECT A.*, DENSE_RANK() OVER (ORDER BY '||v_sort_var||' '||v_sort_order||',ROWNUM) Q FROM (' ||v_str|| ')) A )
         WHERE  Q>= :v_start_num  AND Q<= :v_end_num ';
    END IF;
    
    IF v_flag = 'CODE' THEN
      OPEN v_result_set FOR v_str USING v_description, v_description, v_product_network_type/*v_network_type*/, v_description, v_start_num, v_end_num;
    ELSE
      OPEN v_result_set FOR v_str USING v_description, v_description, v_product_network_type/*v_network_type*/, v_start_num, v_end_num;
    END IF;
END select_activity_list;
--===================================================================================================
PROCEDURE select_drug_list (
    v_description              IN OUT tpa_activity_master_details.activity_description%TYPE,
    v_sort_var                 IN OUT VARCHAR2 ,
    v_sort_order               IN OUT VARCHAR2,
    v_start_num                IN OUT NUMBER  ,
    v_end_num                  IN OUT NUMBER  ,
    v_flag                     IN VARCHAR2    ,
    v_tpa_enrollment           IN VARCHAR2,
    v_hosp_date                IN VARCHAR2,
    v_result_set               OUT SYS_REFCURSOR
  )
  IS
  v_str                      VARCHAR2(2000);
  v_hosp_date1   Date:=to_date(v_hosp_date,'dd/mm/rrrr');
  v_count  number:=0;
  BEGIN

    v_sort_var   := CASE WHEN  v_sort_var IS NULL  then 'SEARCH_DATA' ELSE v_sort_var END;
    v_sort_order := CASE WHEN v_sort_order IS NULL THEN 'ASC' ELSE v_sort_order END;
    v_start_num  := CASE WHEN v_start_num IS NULL THEN 1 ELSE v_start_num END;
    v_end_num    := CASE WHEN v_end_num IS NULL THEN 101 ELSE v_end_num END;

    --v_act_code         := CASE WHEN v_act_code IS NOT NULL THEN UPPER(v_act_code)||'%' ELSE v_act_code END;
    v_description      := CASE WHEN v_description IS NOT NULL THEN UPPER(replace(v_description,' ','%'))||'%' ELSE v_description END;

   SELECT count(1) into v_count
             FROM tpa_pharmacy_master_details md
             WHERE ( UPPER(v_description) IS NULL OR (md.activity_description) LIKE UPPER(v_description))
             AND md.start_date <= v_hosp_date1 and nvl(md.end_date,v_hosp_date1) >=v_hosp_date1;
   
   
   
   IF v_flag = 'CODE' THEN
     
     IF v_count>0 then 
       v_str := 
        'SELECT DISTINCT * FROM (SELECT (md.act_mas_dtl_seq_id||''#''||md.activity_code) as search_data
         FROM tpa_pharmacy_master_details md
         where md.activity_type_seq_id = 5 
         AND (:v_description IS NULL OR upper(md.activity_code) LIKE :v_description )
         AND md.start_date <= :v_hosp_date1 and nvl(md.end_date,:v_hosp_date1) >=:v_hosp_date1)'; 
      else
       v_str := 
        'SELECT DISTINCT * FROM (SELECT (md.act_mas_dtl_seq_id||''#''||md.activity_code) as search_data
         FROM tpa_pharmacy_master_details md
         where md.activity_type_seq_id = 5 
         AND (:v_description IS NULL OR upper(md.activity_code) LIKE :v_description ))';   
      end if;
       
     v_str := 'SELECT * FROM
        (SELECT A.*, DENSE_RANK() OVER (ORDER BY '||v_sort_var||' '||v_sort_order||',ROWNUM) Q FROM (' ||v_str|| ') A )
         WHERE  Q>= :v_start_num  AND Q<= :v_end_num ';
         
   ELSE
     
    IF v_count>0 then 
     v_str := 
      'SELECT DISTINCT * FROM (SELECT (md.act_mas_dtl_seq_id||''#''||md.activity_description) as search_data
       FROM tpa_pharmacy_master_details md
       where md.activity_type_seq_id = 5 
       AND (:v_description IS NULL OR upper(md.activity_description) LIKE :v_description )
       AND md.start_date <= :v_hosp_date1 and nvl(md.end_date,:v_hosp_date1) >=:v_hosp_date1)';   
      ELSE
       v_str := 
        'SELECT DISTINCT * FROM (SELECT (md.act_mas_dtl_seq_id||''#''||md.activity_description) as search_data
         FROM tpa_pharmacy_master_details md
         where md.activity_type_seq_id = 5 
         AND (:v_description IS NULL OR upper(md.activity_description) LIKE :v_description ))';
      END IF;
       
     v_str := 'SELECT * FROM
        (SELECT A.*, DENSE_RANK() OVER (ORDER BY '||v_sort_var||' '||v_sort_order||',ROWNUM) Q FROM (' ||v_str|| ') A )
         WHERE  Q>= :v_start_num  AND Q<= :v_end_num ';
   END IF;
   
   IF v_count>0 then
    OPEN v_result_set FOR v_str USING v_description, v_description ,v_hosp_date1,v_hosp_date1,v_hosp_date1 ,v_start_num, v_end_num;
   ELSE     
    OPEN v_result_set FOR v_str USING v_description, v_description , v_start_num, v_end_num;    
   END IF;

END select_drug_list;
--=================================================================================================================================
PROCEDURE select_clinician_list (
    v_clinician_id             IN OUT tpa_hosp_professionals.professional_id%TYPE,
    v_sort_var                 IN OUT VARCHAR2 ,
    v_sort_order               IN OUT VARCHAR2,
    v_start_num                IN OUT NUMBER  ,
    v_end_num                  IN OUT NUMBER  ,
    v_hosp_seq_id              IN VARCHAR2,
    v_tpa_enrollment_id        IN VARCHAR2:=NULL,
    v_result_set               OUT SYS_REFCURSOR
  )
  IS
  v_str                      VARCHAR2(2000);
  l_hosp_seq_id              VARCHAR2(20);
  BEGIN

    v_sort_var   := CASE WHEN v_sort_var IS NULL then  'SEARCH_DATA' ELSE v_sort_var END;
    v_sort_order := CASE WHEN v_sort_order IS NULL THEN 'ASC' ELSE v_sort_order END;
    v_start_num  := CASE WHEN v_start_num IS NULL THEN 1 ELSE v_start_num END;
    v_end_num    := CASE WHEN v_end_num IS NULL THEN 101 ELSE v_end_num END;

    v_clinician_id         := CASE WHEN v_clinician_id IS NOT NULL THEN UPPER(v_clinician_id)||'%' ELSE v_clinician_id END;
    l_hosp_seq_id            := CASE WHEN v_hosp_seq_id IS NOT NULL THEN v_hosp_seq_id ELSE '%' END;
    
   v_str := 
        'SELECT DISTINCT * FROM (SELECT (md.contact_name||''--''||md.speciality_id||''#''||md.professional_id) as search_data
         FROM tpa_hosp_professionals md
         where md.hosp_seq_id = :hosp_seq_id
         AND (:v_clinician_id IS NULL OR upper(md.professional_id) LIKE :v_clinician_id ))';
      
      v_str := 'SELECT * FROM
        (SELECT A.*, DENSE_RANK() OVER (ORDER BY '||v_sort_var||' '||v_sort_order||',ROWNUM) Q FROM (' ||v_str|| ') A )
         WHERE  Q>= :v_start_num  AND Q<= :v_end_num ';
         
 
    OPEN v_result_set FOR v_str USING l_hosp_seq_id, v_clinician_id, v_clinician_id, v_start_num, v_end_num;
  
END select_clinician_list;
--===================================================================================================================================
PROCEDURE select_clinician_name_list (
    v_clinician_name           IN OUT tpa_hosp_professionals.contact_name%TYPE,
    v_sort_var                 IN OUT VARCHAR2 ,
    v_sort_order               IN OUT VARCHAR2,
    v_start_num                IN OUT NUMBER  ,
    v_end_num                  IN OUT NUMBER  ,
    v_hosp_seq_id              IN VARCHAR2,
    v_tpa_enrollment_id        IN VARCHAR2,
    v_result_set               OUT SYS_REFCURSOR
  )
  IS
  v_str                      VARCHAR2(2000);
  l_hosp_seq_id              VARCHAR2(20);
  
  BEGIN

    v_sort_var   := CASE WHEN v_sort_var IS NULL then  'SEARCH_DATA' ELSE v_sort_var END;
    v_sort_order := CASE WHEN v_sort_order IS NULL THEN 'ASC' ELSE v_sort_order END;
    v_start_num  := CASE WHEN v_start_num IS NULL THEN 1 ELSE v_start_num END;
    v_end_num    := CASE WHEN v_end_num IS NULL THEN 101 ELSE v_end_num END;

    v_clinician_name         := CASE WHEN v_clinician_name IS NOT NULL THEN UPPER(v_clinician_name)||'%' ELSE v_clinician_name END;
    l_hosp_seq_id            := CASE WHEN v_hosp_seq_id IS NOT NULL THEN v_hosp_seq_id ELSE '%' END;
    
   v_str := 
        'SELECT DISTINCT * FROM (SELECT (md.professional_id||''--''||md.speciality_id||''#''||md.contact_name) as search_data
         FROM tpa_hosp_professionals md
         where md.hosp_seq_id = :hosp_seq_id
         AND (:v_clinician_name IS NULL OR upper(md.contact_name) LIKE :v_clinician_name ))';
      
      v_str := 'SELECT * FROM
        (SELECT A.*, DENSE_RANK() OVER (ORDER BY '||v_sort_var||' '||v_sort_order||',ROWNUM) Q FROM (' ||v_str|| ') A )
         WHERE  Q>= :v_start_num  AND Q<= :v_end_num ';
 
 
    OPEN v_result_set FOR v_str USING l_hosp_seq_id, v_clinician_name, v_clinician_name, v_start_num, v_end_num;
  
END select_clinician_name_list;
--===================================================================================================================================
PROCEDURE get_file_details (p_pat_seq_id IN MOU_DOCS_INFO1.PAT_SEQ_ID%TYPE,
                            p_result     OUT SYS_REFCURSOR
                           )
AS
BEGIN
  OPEN p_result FOR
    SELECT I.MOU_DOC_SEQ_ID,
           GC.DESCRIPTION,
           to_char(I.added_date, 'MM/DD/YYYY HH24:MI:SS') as ADDED_DATE,
           UC.CONTACT_NAME,
           I.DOCS_PATH,
           I.HOSP_SEQ_ID,
           I.FILE_NAME
           
    FROM MOU_DOCS_INFO1 I
  LEFT JOIN TPA_GENERAL_CODE GC    ON (I.DOCS_GENTYPE_ID = GC.GENERAL_TYPE_ID)
  LEFT JOIN TPA_USER_CONTACTS UC   ON (UC.CONTACT_SEQ_ID = I.ADDED_BY)
  WHERE I.PAT_SEQ_ID = p_pat_seq_id
  ORDER BY I.MOU_DOC_SEQ_ID;
END get_file_details;
--=============================================================================================
PROCEDURE get_shortfall_details (p_shortfall_seq_id IN shortfall_details.shortfall_seq_id%TYPE,
                                 p_resultset        OUT SYS_REFCURSOR
                                )
AS
BEGIN
  OPEN p_resultset FOR
    SELECT sd.shortfall_id,
           decode(pa.pat_status_type_id, 'INP', 'In-Progress', 'APR', 'Approved', 'REJ', 'Rejected', 'REQ', 'Required Information') as status,
           to_char(sysdate, 'DD/MM/RRRR') as generated_date,
           case  when h.hosp_seq_id is not null then h.hosp_name  else upper(a.PROVIDER_NAME) end as prov_name,-----newly changed
           nvl(h.off_phone_no_1, h.off_phone_no_2) as contact_no,
           h.hosp_licenc_numb as licence_no,
           ttk_util_pkg.fn_decrypt(h.primary_email_id) as prov_email,
           pa.mem_name as patient_name,
           m.tpa_enrollment_id as alkoot_id,
           to_char(m.mem_dob, 'DD/MM/RRRR') as dob,
           decode(m.gender_general_type_id, 'MAL', 'Male', 'FEM', 'Female', 'Other') as gender,
           case when pa.benifit_type = 'IPT'   then 'In-Patient'
             when pa.benifit_type = 'OPTS'  then 'Out-Patient'
             when pa.benifit_type = 'OPTC'  then 'Optical'
             when pa.benifit_type = 'OMTI'   then 'Out-Patient Maternity'
             when pa.benifit_type = 'IMTI'   then 'In-Patient Maternity'
             when pa.benifit_type = 'DNTL'  then 'Dental'
             when pa.benifit_type = 'HEAC'  then 'Health Check-up'
             when pa.benifit_type = 'DAYC'  then 'Day Care'
         end as benefit_type,
         to_char(pa.hospitalization_date, 'DD/MM/RRRR') as treatment_date,
         po.policy_number,
         c.contact_name as processed_by,
         pa.pre_auth_number,
         decode(sd.srtfll_status_general_type_id, 'OPN', 'Open', 'CLS', 'Closed', 'RES', 'Responded') as shortfall_status
         
    FROM Shortfall_Details sd
    LEFT JOIN Pat_Authorization_Details pa ON (pa.pat_auth_seq_id = sd.pat_gen_detail_seq_id)
    LEFT JOIN Tpa_Hosp_Info h ON (h.hosp_seq_id = pa.hosp_seq_id)
    LEFT JOIN Tpa_Enr_Policy_Member m ON (pa.member_seq_id = m.member_seq_id)
    LEFT JOIN Tpa_Enr_Policy po ON (po.policy_seq_id = pa.policy_seq_id)
    JOIN Tpa_User_Contacts c ON (pa.added_by = c.contact_seq_id)
	join APP.PAT_NON_NETWORK_DETAILS a on (pa.pat_auth_seq_id = a.pat_auth_seq_id)-----newly added
    WHERE sd.shortfall_seq_id = p_shortfall_seq_id;
	    
END get_shortfall_details;
--=============================================================================
PROCEDURE select_pbm_icd_list (
    v_icd_code                 IN OUT tpa_icd10_master_details.icd_code%TYPE,
    v_description              IN OUT tpa_icd10_master_details.long_desc%TYPE,
    v_search_flag              IN VARCHAR2,--CODE,DESC
    v_sort_var                 IN OUT VARCHAR2 ,
    v_sort_order               IN OUT VARCHAR2,
    v_start_num                IN OUT NUMBER  ,
    v_end_num                  IN OUT NUMBER  ,
    v_result_set               OUT SYS_REFCURSOR
  )
  IS
  v_str                      VARCHAR2(2000);
  
  BEGIN

    v_sort_var   := CASE WHEN v_sort_var IS NULL and v_search_flag ='CODE' THEN 'DESCREPTION' WHEN v_sort_var IS NULL and v_search_flag ='DESC' then 'DESCREPTION' ELSE v_sort_var END;
    v_sort_order := CASE WHEN v_sort_order IS NULL THEN 'ASC' ELSE v_sort_order END;
    v_start_num  := CASE WHEN v_start_num IS NULL THEN 1 ELSE v_start_num END;
    v_end_num    := CASE WHEN v_end_num IS NULL THEN 101 ELSE v_end_num END;

    v_icd_code         := CASE WHEN v_icd_code IS NOT NULL THEN UPPER(v_icd_code)||'%' ELSE v_icd_code END;
    v_description      := CASE WHEN v_description IS NOT NULL THEN '%'||UPPER(replace(v_description,' ','%'))||'%' ELSE v_description END;

 
 if v_search_flag ='CODE' then 
 v_str := 
      'SELECT DISTINCT * FROM (SELECT md.icd10_seq_id,
       md.icd_code as descreption
       ,NVL2(ri.icd_code,1,0) rcnt
       FROM tpa_icd10_master_details md
  left join tpa_restrict_icd ri on(md.icd_code = ri.icd_code)      
       where  (:v_icd_code IS NULL OR upper(md.icd_code) LIKE :v_icd_code ))';
    
    v_str := 'SELECT * FROM
      (SELECT A.*, DENSE_RANK() OVER (ORDER BY '||v_sort_var||' '||v_sort_order||',ROWNUM) Q FROM (' ||v_str|| ') A )
       WHERE  Q>= :v_start_num  AND Q<= :v_end_num ';
 
    OPEN v_result_set FOR v_str USING v_icd_code, v_icd_code, v_start_num, v_end_num;
  
  
  else 
     v_str := 
      'SELECT DISTINCT * FROM (SELECT md.icd10_seq_id ,
       md.LONG_DESC as descreption
       ,NVL2(ri.icd_code,1,0) rcnt
       FROM tpa_icd10_master_details md
  left join tpa_restrict_icd ri on(md.icd_code = ri.icd_code)       
       where  (:v_description IS NULL OR upper(md.LONG_DESC) LIKE :v_description ))';   
      
    v_str := 'SELECT * FROM
      (SELECT A.*, DENSE_RANK() OVER (ORDER BY '||v_sort_var||' '||v_sort_order||',ROWNUM) Q FROM (' ||v_str|| ') A )
       WHERE  Q>= :v_start_num  AND Q<= :v_end_num ';
   
 
    OPEN v_result_set FOR v_str USING v_description, v_description , v_start_num, v_end_num;
  
  
  
  end if;   
      
  
END select_pbm_icd_list;
--=======================================================================
PROCEDURE select_pbm_drug_list (
    v_search_flag              IN VARCHAR2,--CODE,DESC,
    v_search_data             IN OUT VARCHAR2,
    v_sort_var                 IN OUT VARCHAR2 ,
    v_sort_order               IN OUT VARCHAR2,
    v_start_num                IN OUT NUMBER  ,
    v_end_num                  IN OUT NUMBER  ,
    v_result_set               OUT SYS_REFCURSOR
  )
  IS
  v_str                      VARCHAR2(2000);
  
  BEGIN

    v_sort_var   := CASE WHEN  v_sort_var IS NULL  then 'SEARCH_DATA' ELSE v_sort_var END;
    v_sort_order := CASE WHEN v_sort_order IS NULL THEN 'ASC' ELSE v_sort_order END;
    v_start_num  := CASE WHEN v_start_num IS NULL THEN 1 ELSE v_start_num END;
    v_end_num    := CASE WHEN v_end_num IS NULL THEN 101 ELSE v_end_num END;

    --v_act_code         := CASE WHEN v_act_code IS NOT NULL THEN UPPER(v_act_code)||'%' ELSE v_act_code END;
    v_search_data      := CASE WHEN v_search_data IS NOT NULL THEN '%'||UPPER(replace(v_search_data,' ','%'))||'%' ELSE v_search_data END;

 
     v_str := 
      'SELECT DISTINCT * FROM (SELECT (md.act_mas_dtl_seq_id||''#''||md.drug_name_pbm) as search_data
       FROM tpa_pharmacy_master_details md
       where md.activity_type_seq_id = 5 
       AND (:v_search_data IS NULL OR upper(md.drug_name_pbm) LIKE :v_search_data ))';   
      
       
  v_str := 'SELECT * FROM
      (SELECT A.*, DENSE_RANK() OVER (ORDER BY '||v_sort_var||' '||v_sort_order||',ROWNUM) Q FROM (' ||v_str|| ') A )
       WHERE  Q>= :v_start_num  AND Q<= :v_end_num ';
 
    OPEN v_result_set FOR v_str USING v_search_data, v_search_data , v_start_num, v_end_num;

   
  
END select_pbm_drug_list;
--======================================================================================================
PROCEDURE dental_event_number(v_tpa_enrollment_id          IN  app.tpa_enr_policy_member.tpa_enrollment_id%TYPE,
                              v_result                     OUT SYS_REFCURSOR)
IS 
  v_event     VARCHAR2(10);
  v_seq       VARCHAR2(10);
BEGIN
  select app.event_ref_no_seq.nextval into v_seq from dual;
  v_event := rpad(v_seq, 7, 0);
  
  OPEN v_result FOR
     SELECT case when c.gender_general_type_id='MAL' then 'MALE'  else 'FEMALE' end  gender,
            c.mem_name,
            c.mem_age years,
            to_char(c.mem_dob, 'DD/MM/RRRR') as mem_dob,
            c.tpa_enrollment_id ,
            a.policy_number ,
             trunc(mod(months_between(sysdate,c.mem_dob ),12)) as months,
            b.employee_no EMPLOYEE_NO,
            d.group_name COMPANY_NAME,
            ttk_util_pkg.fn_decrypt(e.mobile_no) as MOBILE_NO,
            ttk_util_pkg.fn_decrypt(e.email_id) as Email_Id,
            a.policy_number,
            c.emirate_id as quatar_id,
            v_event      as event_no
            
     FROM tpa_enr_policy a join tpa_enr_policy_group b ON (a.policy_seq_id=b.policy_seq_id)
     JOIN tpa_enr_policy_member c on (b.policy_group_seq_id=c.policy_group_seq_id)
     join app.tpa_group_registration d on (b.group_reg_seq_id=d.group_reg_seq_id)
     join app.tpa_enr_mem_address e on (b.enr_address_seq_id=e.enr_address_seq_id)
     where c.tpa_enrollment_id=v_tpa_enrollment_id and sysdate between a.effective_from_date and a.effective_to_date;
   
    
END dental_event_number;
--================================================================================================================
PROCEDURE dental_form_event(v_tpa_enrollment_id                  IN  PAT_ENROLL_DETAILS.tpa_enrollment_id%TYPE,
                            v_benefit_type                       IN  PAT_AUTHORIZATION_DETAILS.Benifit_Type%TYPE,                                     
                            v_hosp_seq_id                        IN  TPA_HOSP_INFO.HOSP_SEQ_ID%TYPE,
                            v_result_set                         OUT SYS_REFCURSOR
                           )
IS 
BEGIN
  
  OPEN v_result_set FOR
     SELECT hi.hosp_name,
            hi.off_phone_no_1,
            hi.office_fax_no,
            hi.hosp_licenc_numb,
            hi.std_code,
            cc.city_description as prov_loc,
            'P.O.Box '||a.pin_code||', '||s.state_name||'-'||c.country_name||', '||'Call : '||'+'||a.isd_code||'-'||a.office_phone1||', Email: customercare@alkoot-medical.com Website: www.alkoot.com.qa' as address
       FROM tpa_hosp_info hi
       left join tpa_office_info o             on (o.tpa_office_seq_id = hi.tpa_office_seq_id)
       left join tpa_address a                 on (a.tpa_office_seq_id = o.tpa_office_seq_id)
       left join tpa_state_code s              on (s.state_type_id = a.state_type_id)
       left join tpa_country_code c            on (c.country_id = a.country_id)
       left outer join app.tpa_city_code cc    on (a.city_type_id = cc.city_type_id)
      where hi.hosp_seq_id = v_hosp_seq_id;
    
END dental_form_event;
--=================================================================================================================
PROCEDURE check_icd_benefit(p_icd_code                          IN VARCHAR2,
                            p_benefit_type                      IN PAT_AUTHORIZATION_DETAILS.BENIFIT_TYPE%TYPE,
                            p_result                            OUT VARCHAR2
                           )
AS
  CURSOR icd_ben_cur IS
    Select i.benefit_type
    From Tpa_Icd10_Master_Details i
    Where i.icd_code = trim(p_icd_code)
    And i.benefit_type = 'DNTL';
  
  p_icd_ben_type VARCHAR2(10);  
BEGIN
  OPEN icd_ben_cur;
  FETCH icd_ben_cur INTO p_icd_ben_type;
  CLOSE icd_ben_cur;
  
  IF p_benefit_type = 'DNTL' AND NVL(p_icd_ben_type, 'NA') = p_benefit_type THEN
    p_result := 'Y';
  ELSE
    IF p_benefit_type != 'DNTL' AND NVL(p_icd_ben_type, p_benefit_type) = p_benefit_type THEN
      p_result := 'Y';
    ELSE
      p_result := 'N';
    END IF;
  END IF;
END check_icd_benefit;
--=================================================================================================================
PROCEDURE save_appeal_remark(v_seq_id  IN PAT_AUTHORIZATION_DETAILS.PAT_AUTH_SEQ_ID%TYPE,
                             v_remark  IN OUT VARCHAR2
                            )
AS
  CURSOR appeal_cur IS
    SELECT nvl(p.appeal_count, 0) as cnt,p.pat_status_type_id,p.final_app_amount,p.member_seq_id,
      p.pat_auth_seq_id,p.pat_received_date
    FROM Pat_Authorization_Details p
    WHERE p.pat_auth_seq_id = v_seq_id;
    
   appeal_cur_rec           appeal_cur%ROWTYPE; 
 
BEGIN
  OPEN appeal_cur;
  FETCH appeal_cur INTO appeal_cur_rec;
  CLOSE appeal_cur;
  
  ---While doing appeal through provider login, Capturing Service Logs
  INSERT INTO app.APPEAL_LOGS   (pat_auth_seq_id,pat_recv_date,apeal_date,added_date)
  VALUES (appeal_cur_rec.pat_auth_seq_id,appeal_cur_rec.pat_received_date,SYSDATE,SYSDATE);
  ----
  IF appeal_cur_rec.cnt = 0 THEN
    UPDATE Pat_Authorization_Details p
    SET p.appeal_date = p.pat_received_date
    WHERE p.pat_auth_seq_id = v_seq_id;
  END IF;
  
  IF appeal_cur_rec.pat_status_type_id='APR' THEN
    UPDATE tpa_enr_balance b
     SET b.utilised_sum_insured = b.utilised_sum_insured - nvl(appeal_cur_rec.final_app_amount,0)
    WHERE b.member_seq_id = appeal_cur_rec.member_seq_id ; 
  END IF;
  
  
  UPDATE Pat_Authorization_Details p
  SET p.appeal_remark = v_remark,
      p.appeal_yn = 'Y',
      p.pat_status_type_id = 'INP',
      p.completed_yn = 'N',
      p.pat_received_date = SYSDATE,
      p.appeal_count = NVL(p.appeal_count, 0) + 1,
      p.cal_act_yn='N'
      
  WHERE p.pat_auth_seq_id = v_seq_id
  RETURNING p.appeal_remark INTO v_remark;
  
  COMMIT;
END save_appeal_remark;
--=========================================================================================================
END HOSP_DIAGNOSYS_PKG;

/

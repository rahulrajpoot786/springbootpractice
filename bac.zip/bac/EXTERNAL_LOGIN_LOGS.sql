--------------------------------------------------------
--  DDL for Synonymn EXTERNAL_LOGIN_LOGS
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."EXTERNAL_LOGIN_LOGS" FOR "INTX"."EXTERNAL_LOGIN_LOGS";

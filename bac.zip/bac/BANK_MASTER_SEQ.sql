--------------------------------------------------------
--  DDL for Synonymn BANK_MASTER_SEQ
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."BANK_MASTER_SEQ" FOR "APP"."BANK_MASTER_SEQ";

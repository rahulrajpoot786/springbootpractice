--------------------------------------------------------
--  DDL for Synonymn IDX_MEMBUFF_DIFF_CHECK_BUFFSEQ
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."IDX_MEMBUFF_DIFF_CHECK_BUFFSEQ" FOR "APP"."IDX_MEMBUFF_DIFF_CHECK_BUFFSEQ";

--------------------------------------------------------
--  DDL for Synonymn IDX_MEMBUFF_DIFF_CHECK_POLSEQ
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."IDX_MEMBUFF_DIFF_CHECK_POLSEQ" FOR "APP"."IDX_MEMBUFF_DIFF_CHECK_POLSEQ";

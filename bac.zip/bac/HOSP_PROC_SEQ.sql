--------------------------------------------------------
--  DDL for Synonymn HOSP_PROC_SEQ
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."HOSP_PROC_SEQ" FOR "APP"."HOSP_PROC_SEQ";

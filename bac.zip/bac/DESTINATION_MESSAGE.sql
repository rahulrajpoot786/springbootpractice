--------------------------------------------------------
--  DDL for Synonymn DESTINATION_MESSAGE
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."DESTINATION_MESSAGE" FOR "APP"."DESTINATION_MESSAGE";

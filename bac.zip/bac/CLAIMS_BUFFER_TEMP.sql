--------------------------------------------------------
--  DDL for Synonymn CLAIMS_BUFFER_TEMP
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."CLAIMS_BUFFER_TEMP" FOR "APP"."CLAIMS_BUFFER_TEMP";

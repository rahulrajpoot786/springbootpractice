--------------------------------------------------------
--  DDL for Synonymn IDX_ERRORLOG_BATCHNUMTYPE
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."IDX_ERRORLOG_BATCHNUMTYPE" FOR "APP"."IDX_ERRORLOG_BATCHNUMTYPE";

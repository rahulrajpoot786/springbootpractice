--------------------------------------------------------
--  DDL for Synonymn HAAD_GENERL_CODE
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."HAAD_GENERL_CODE" FOR "APP"."HAAD_GENERL_CODE";

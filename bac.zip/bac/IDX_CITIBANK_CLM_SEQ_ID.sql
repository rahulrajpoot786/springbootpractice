--------------------------------------------------------
--  DDL for Synonymn IDX_CITIBANK_CLM_SEQ_ID
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."IDX_CITIBANK_CLM_SEQ_ID" FOR "APP"."IDX_CITIBANK_CLM_SEQ_ID";

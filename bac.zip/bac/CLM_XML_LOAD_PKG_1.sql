--------------------------------------------------------
--  DDL for Package CLM_XML_LOAD_PKG
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "VENUBABU"."CLM_XML_LOAD_PKG" 
is
--===============================================================================

clm_batch_rec     clm_batch_upload_details%rowtype;
clm_rec           clm_authorization_details%rowtype;
clm_hosp_rec      clm_hospital_details%rowtype;
diag_rec          diagnosys_details%rowtype;
activity_rec      pat_activity_details%rowtype;
observation_rec   pat_observation_details%rowtype;
v_hosp_seq_id     tpa_hosp_info.hosp_seq_id%TYPE;
v_ins_seq_id      tpa_ins_info.ins_seq_id%TYPE;
v_activity_count      number(4):=0;
v_prod_policy_rule_seq_id       tpa_ins_prod_policy_rules.prod_policy_rule_seq_id%type;

CURSOR clm_cur(v_claim_seq_id  clm_authorization_details.claim_seq_id%TYPE)IS
 SELECT cad.claim_seq_id,
       cad.clm_batch_seq_id,
       cad.pat_auth_seq_id,
       cad.member_seq_id,       
       cad.final_app_amount,
       cad.denial_reason,
       cad.remarks
  FROM clm_authorization_details cad
  WHERE cad.claim_seq_id=v_claim_seq_id;
  
 prev_clm_rec              clm_cur%ROWTYPE;
  
--===============================================================================

PROCEDURE clear_all(v_flag   varchar2) ;
--===============================================================================

--===============================================================================
                                  
PROCEDURE set_clm_details(v_seq_id           IN clm_authorization_details.claim_seq_id%type);
--===============================================================================
PROCEDURE save_clm_batch_details(v_clm_batch_seq_id  in out clm_batch_upload_details.clm_batch_seq_id%type,
                                 v_batch_no          in out clm_batch_upload_details.batch_no%type,
                                 v_sender_id         in clm_batch_upload_details.sender_id%type,
                                 v_receiver_id       in clm_batch_upload_details.receiver_id%type,
                                 v_received_date     in clm_batch_upload_details.received_date%type,
                                 v_record_count      in clm_batch_upload_details.record_count%type,
                                 v_batch_tot_amount  in clm_batch_upload_details.batch_tot_amount%type,
                                 v_tpa_office_aeq_id in clm_batch_upload_details.tpa_office_aeq_id%type,
                                 v_batch_status_type in clm_batch_upload_details.batch_status_type%type,
                                 v_benefit_type      in clm_batch_upload_details.benefit_type%type,
                                 v_claim_type        in clm_batch_upload_details.clm_type_gen_type_id%type,
                                 v_submission_type   in clm_batch_upload_details.submission_type_id%type,
                                 v_currency_type     in clm_batch_upload_details.currency_type%type,
                                 v_source_type       in clm_batch_upload_details.source_type_id%type,
                                 v_added_by          in clm_batch_upload_details.added_by%type);
--===============================================================================
--===============================================================================
PROCEDURE get_header_details(v_header_node IN DBMS_XMLDOM.DOMNode,v_xml IN xmltype,v_file_id IN varchar2);
--===============================================================================

PROCEDURE get_claim_details(v_auth_node IN DBMS_XMLDOM.DOMNode);

--===============================================================================

PROCEDURE get_diagnosys_details(v_diagnosys_node IN DBMS_XMLDOM.DOMNode);
--===============================================================================

PROCEDURE get_activity_details(v_activity_node IN DBMS_XMLDOM.DOMNode);
--===============================================================================

PROCEDURE get_observation_details(v_observation_node IN DBMS_XMLDOM.DOMNode);
--===============================================================================
PROCEDURE save_clm_details(V_CLAIM_SEQ_ID               IN OUT CLM_AUTHORIZATION_DETAILS.CLAIM_SEQ_ID%type,
                           V_CLM_BATCH_SEQ_ID           IN CLM_AUTHORIZATION_DETAILS.CLM_BATCH_SEQ_ID%type,
                           V_PAT_AUTH_SEQ_ID            IN OUT CLM_AUTHORIZATION_DETAILS.PAT_AUTH_SEQ_ID%type,
                           V_PARENT_CLAIM_SEQ_ID        IN CLM_AUTHORIZATION_DETAILS.PARENT_CLAIM_SEQ_ID%type,
                           V_CLAIM_NUMBER               IN OUT CLM_AUTHORIZATION_DETAILS.CLAIM_NUMBER%type,
                           V_CLAIM_FILE_NUMBER          IN CLM_AUTHORIZATION_DETAILS.CLAIM_FILE_NUMBER%type,
                           V_SETTLEMENT_NUMBER          IN CLM_AUTHORIZATION_DETAILS.SETTLEMENT_NUMBER%type,
                           V_CLM_RECEIVED_DATE          IN CLM_AUTHORIZATION_DETAILS.CLM_RECEIVED_DATE%type,
                           V_SOURCE_TYPE_ID             IN CLM_AUTHORIZATION_DETAILS.SOURCE_TYPE_ID%type,
                           V_HOSPITALIZATION_DATE       IN CLM_AUTHORIZATION_DETAILS.DATE_OF_HOSPITALIZATION%type,
                           V_DISCHARGE_DATE             IN CLM_AUTHORIZATION_DETAILS.DATE_OF_DISCHARGE%type,
                           V_CLAIM_TYPE                 IN CLM_AUTHORIZATION_DETAILS.CLAIM_TYPE%type,
                           V_CLAIM_SUB_TYPE             IN CLM_AUTHORIZATION_DETAILS.CLAIM_SUB_TYPE%type,
                           V_MEMBER_SEQ_ID              IN CLM_AUTHORIZATION_DETAILS.MEMBER_SEQ_ID%type,
                           V_TPA_ENROLLMENT_ID          IN CLM_AUTHORIZATION_DETAILS.TPA_ENROLLMENT_ID%type,
                           V_MEM_NAME                   IN CLM_AUTHORIZATION_DETAILS.MEM_NAME%type,
                           V_MEM_AGE                    IN CLM_AUTHORIZATION_DETAILS.MEM_AGE%type,
                           V_INS_SEQ_ID                 IN CLM_AUTHORIZATION_DETAILS.INS_SEQ_ID%type,
                           V_POLICY_SEQ_ID              IN CLM_AUTHORIZATION_DETAILS.POLICY_SEQ_ID%type,
                           V_ENROL_TYPE_ID              IN CLM_AUTHORIZATION_DETAILS.ENROL_TYPE_ID%type,
                           V_EMIRATE_ID                 IN CLM_AUTHORIZATION_DETAILS.EMIRATE_ID%type,
                           V_ENCOUNTER_TYPE_ID          IN CLM_AUTHORIZATION_DETAILS.ENCOUNTER_TYPE_ID%type,
                           V_ENCOUNTER_START_TYPE       IN CLM_AUTHORIZATION_DETAILS.ENCOUNTER_START_TYPE%type,
                           V_ENCOUNTER_END_TYPE         IN CLM_AUTHORIZATION_DETAILS.ENCOUNTER_END_TYPE%type,
                           V_ENCOUNTER_FACILITY_ID      IN CLM_AUTHORIZATION_DETAILS.ENCOUNTER_FACILITY_ID%type,
                           V_PAYER_ID                   IN CLM_AUTHORIZATION_DETAILS.PAYER_ID%type,
                           V_AVA_SUM_INSURED            IN CLM_AUTHORIZATION_DETAILS.AVA_SUM_INSURED%type,
                           V_CURRENCY_TYPE              IN CLM_AUTHORIZATION_DETAILS.CURRENCY_TYPE%type,
                           V_CLM_STATUS_TYPE_ID         IN CLM_AUTHORIZATION_DETAILS.CLM_STATUS_TYPE_ID%type,
                           V_REMARKS                    IN CLM_AUTHORIZATION_DETAILS.REMARKS%type,
                           V_INVOICE_NUMBER             IN CLM_AUTHORIZATION_DETAILS.INVOICE_NUMBER%type,
                           V_REQUESTED_AMOUNT           IN CLM_AUTHORIZATION_DETAILS.REQUESTED_AMOUNT%type,
                           V_CLINICIAN_ID               IN CLM_AUTHORIZATION_DETAILS.CLINICIAN_ID%type,
                           V_SYSTEM_OF_MEDICINE_TYPE_ID IN CLM_AUTHORIZATION_DETAILS.SYSTEM_OF_MEDICINE_TYPE_ID%type,
                           V_ACCIDENT_RELATED_TYPE_ID   IN CLM_AUTHORIZATION_DETAILS.ACCIDENT_RELATED_TYPE_ID%type,
                           V_PRIORITY_GENERAL_TYPE_ID   IN CLM_AUTHORIZATION_DETAILS.PRIORITY_GENERAL_TYPE_ID%type,
                           V_NETWORK_YN                 IN CLM_AUTHORIZATION_DETAILS.NETWORK_YN%type,
                           V_BENIFIT_TYPE               IN CLM_AUTHORIZATION_DETAILS.BENIFIT_TYPE%type,
                           V_GRAVIDA                    IN CLM_AUTHORIZATION_DETAILS.GRAVIDA%type,
                           V_PARA                       IN CLM_AUTHORIZATION_DETAILS.PARA%type,
                           V_LIVE                       IN CLM_AUTHORIZATION_DETAILS.LIVE%type,
                           V_ABORTION                   IN CLM_AUTHORIZATION_DETAILS.ABORTION%type,
                           V_PRESENTING_COMPLAINTS      IN CLM_AUTHORIZATION_DETAILS.PRESENTING_COMPLAINTS%type,
                           V_MEDICAL_OPINION_REMARKS    IN CLM_AUTHORIZATION_DETAILS.MEDICAL_OPINION_REMARKS%type,
                           V_HOSP_SEQ_ID                IN CLM_HOSPITAL_DETAILS.HOSP_SEQ_ID%type,
                           V_HOSP_NAME                  IN CLM_HOSPITAL_DETAILS.HOSP_NAME%type,
                           V_ADDRESS_1                  IN CLM_HOSPITAL_DETAILS.ADDRESS_1%type,
                           V_CITY_TYPE_ID               IN CLM_HOSPITAL_DETAILS.CITY_TYPE_ID%type,
                           V_STATE_TYPE_ID              IN CLM_HOSPITAL_DETAILS.STATE_TYPE_ID%type,
                           V_PIN_CODE                   IN CLM_HOSPITAL_DETAILS.PIN_CODE%type,
                           V_OFF_PHONE_NO_1             IN CLM_HOSPITAL_DETAILS.OFF_PHONE_NO_1%type,
                           V_OFFICE_FAX_NO              IN CLM_HOSPITAL_DETAILS.OFFICE_FAX_NO%type,
                           V_PROVIDER_ID                IN CLM_HOSPITAL_DETAILS.PROVIDER_ID%type,
                           V_COUNTRY_TYPE_ID            IN CLM_HOSPITAL_DETAILS.COUNTRY_TYPE_ID%type,
                           v_clinician_name             IN CLM_HOSPITAL_DETAILS.CLINICIAN_NAME%type,
                           V_ADDED_BY                   IN CLM_AUTHORIZATION_DETAILS.ADDED_BY%type,
						   V_RESUB_TYPE                 IN CLM_AUTHORIZATION_DETAILS.RESUB_TYPE%type,
                           V_RESUB_COMMENT              IN CLM_AUTHORIZATION_DETAILS.Re_Submission_Remarks%type,
                           v_first_ins_dt               IN CLM_AUTHORIZATION_DETAILS.FIRST_INCIDENT_DATE%TYPE,
                           v_first_report_dt            IN CLM_AUTHORIZATION_DETAILS.FIRST_REPORTED_DATE%TYPE,
                           v_lmp_date                   IN CLM_AUTHORIZATION_DETAILS.Lmp_Date%TYPE,
                           v_con_nature                 IN CLM_AUTHORIZATION_DETAILS.CONCEPTION_TYPE%TYPE,
                           V_AUTH_NO                    IN CLM_AUTHORIZATION_DETAILS.AUTH_NUMBER%TYPE,
                           V_CONVERTED_RATE             IN CLM_AUTHORIZATION_DETAILS.CONVERSION_RATE%TYPE,
						   V_EVENT_NO                   IN CLM_AUTHORIZATION_DETAILS.EVENT_NO%TYPE,
                           V_ROWS_PROCESSED             OUT NUMBER);
--===============================================================================
PROCEDURE calculate_authorization(v_claim_seq_id               IN  clm_authorization_details.claim_seq_id%type,
                                  v_hosp_seq_id                IN  clm_hospital_details.hosp_seq_id%TYPE,
                                  v_allowed_amount             OUT clm_authorization_details.tot_allowed_amount%type,
                                  v_result_set                 OUT SYS_REFCURSOR,
                                  v_added_by                   IN  NUMBER);
--===============================================================================
PROCEDURE save_settlement(  v_claim_seq_id                     IN clm_authorization_details.claim_seq_id%TYPE,
                             v_member_seq_id                   IN clm_authorization_details.member_seq_id%TYPE,
                             v_settlement_number               IN OUT clm_authorization_details.settlement_number%TYPE,
                             v_admission_date                  IN clm_authorization_details.date_of_hospitalization%type,
                             v_allowed_amount                  IN clm_authorization_details.Tot_Allowed_Amount%TYPE,
                             v_source_type_id                  IN clm_authorization_details.source_type_id%TYPE,
                             v_clm_status_type_id              IN OUT clm_authorization_details.clm_status_type_id%TYPE,
                             v_remarks                         IN clm_authorization_details.remarks%type,
                             v_added_by                        IN  NUMBER,
                             v_rows_processed                  OUT NUMBER);
--===============================================================================
procedure gene_remittance_advice(v_settlement_number   clm_authorization_details.settlement_number%type);
---===================================================================
PROCEDURE load_claim_request(v_claim_doc IN xmltype,v_file_id varchar2,v_out_flag OUT VARCHAR2);
--===============================================================================
PROCEDURE save_dhpo_new_transactions(
                     v_download_seq_id	     in  app.dhpo_new_transaction_download.download_seq_id%type,
                     v_file_id	             in  app.dhpo_new_transaction_download.file_id%type,
                     v_file_name	         in  app.dhpo_new_transaction_download.file_name%type,
                     v_down_load_file	     in  app.dhpo_new_transaction_download.down_load_file%type,
                     v_file_type	         in  app.dhpo_new_transaction_download.file_type%type,
                     v_down_load_status	   in  app.dhpo_new_transaction_download.down_load_status%type,
                     v_result_type	       in  app.dhpo_new_transaction_download.result_type%type,
                     v_error_message	     in  app.dhpo_new_transaction_download.error_message%type,
					 v_alert               out varchar2
                  ) ;
--===============================================================================
PROCEDURE get_preauth_list (
    v_member_seq_id                  IN  pat_authorization_details.member_seq_id%TYPE,
    v_hosp_seq_id                    IN  pat_authorization_details.hosp_seq_id%TYPE,
    v_start_date                     IN  date,
    v_end_date                       IN  date,
    v_pre_auth_seq_id                OUT pat_authorization_details.pat_auth_seq_id%TYPE,
    v_auth_number                    OUT pat_authorization_details.Auth_Number%TYPE,
    v_tot_apr_amount                 OUT pat_authorization_details.tot_approved_amount%TYPE
     
  );
--===============================================================================
PROCEDURE save_gn_main_transactions(
                     v_download_seq_id	     in  Gn_new_main_trans_download.download_seq_id%type,
                     v_file_id	             in  Gn_new_main_trans_download.file_id%type,
                     v_file_name	           in  Gn_new_main_trans_download.file_name%type,
                     v_down_load_file	       in  Gn_new_main_trans_download.down_load_file%type,
                     v_file_type	           in  Gn_new_main_trans_download.file_type%type,
                     v_down_load_status	     in  Gn_new_main_trans_download.down_load_status%type,
                     v_result_type	         in  Gn_new_main_trans_download.result_type%type,
                     v_error_message	       in  Gn_new_main_trans_download.error_message%type,
                     v_bifurcation_yn	       in  Gn_new_main_trans_download.Bifurcation_Yn%type,
                     v_alert                 out varchar2);
--===============================================================================
PROCEDURE save_gn_vidal_transactions(
                     v_download_seq_id	     in  dhpo_new_transaction_download.download_seq_id%type,
                     v_file_id	             in  dhpo_new_transaction_download.file_id%type,
                     v_file_name	           in  dhpo_new_transaction_download.file_name%type,
                     v_down_load_file	       in  dhpo_new_transaction_download.down_load_file%type,
                     v_file_type	           in  dhpo_new_transaction_download.file_type%type,
                     v_down_load_status	     in  dhpo_new_transaction_download.down_load_status%type,
                     v_result_type	         in  dhpo_new_transaction_download.result_type%type,
                     v_error_message	       in  dhpo_new_transaction_download.error_message%type,
                     v_insert_mode           in out  varchar2,--'GN','SH'
                     v_dhpo_tx_date          in  VARCHAR2,
                     v_dhpo_total_rec_cnt    in  Dhpo_New_Transaction_Download.Dhpo_Total_Rec_Cnt%type,
                     v_gn_rec_cnt            in  Dhpo_New_Transaction_Download.Clm_Rec_Cnt%type,
                     v_sh_rec_cnt            in  dhpo_new_transaction_download.Clm_Rec_Cnt%type
                  );
--===============================================================================
PROCEDURE select_gn_main_transactions (
    result_set                           OUT SYS_REFCURSOR  );
--------------------------------------------------------------------------------
procedure select_sn_xml_files(
       v_downloadedYN                             IN dhpo_sh_transactions.user_downloaded_yn%type,
       v_xml_date_from                            IN varchar2 ,
       v_xml_date_to                              IN varchar2 ,
       v_fileName                                 IN varchar2 ,
       v_fileID                                   IN varchar2 ,
       v_trans_date                               IN varchar2 ,
       v_mode                                     in varchar2 ,--PAT,CLM
       v_sort_var                                 IN  VARCHAR2 ,
       v_sort_order                               IN  VARCHAR2 ,
       v_start_num                                IN  NUMBER ,
       v_end_num                                  IN  NUMBER ,
       result_set                                 out sys_refcursor );
-----------------------------------------------------------------------------
PROCEDURE update_sh_transactions(
                     v_download_seq_id	     in  dhpo_sh_transactions.download_seq_id%type,
                     v_update_mode           in  varchar2,--'V'(View),'U'(Update)
                     v_mode                  in varchar2,---PAT,CLM
                     v_files                 out sys_refcursor
                  );
--------------------------------------------------------------------------------
PROCEDURE gn_valid_member (v_mem_id      varchar2,
                           v_flag        out varchar2);
    
----------====================================================================

end clm_xml_load_pkg;

/

--------------------------------------------------------
--  DDL for Synonymn GN_PAT_MAIN_TRANS_DOWNLOAD
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."GN_PAT_MAIN_TRANS_DOWNLOAD" FOR "APP"."GN_PAT_MAIN_TRANS_DOWNLOAD";

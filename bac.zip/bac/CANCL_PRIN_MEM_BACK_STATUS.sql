--------------------------------------------------------
--  DDL for Synonymn CANCL_PRIN_MEM_BACK_STATUS
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."CANCL_PRIN_MEM_BACK_STATUS" FOR "APP"."CANCL_PRIN_MEM_BACK_STATUS";

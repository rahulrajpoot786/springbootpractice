--------------------------------------------------------
--  DDL for Synonymn CLM_BATCH_DELETE_BKP
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."CLM_BATCH_DELETE_BKP" FOR "APP"."CLM_BATCH_DELETE_BKP";

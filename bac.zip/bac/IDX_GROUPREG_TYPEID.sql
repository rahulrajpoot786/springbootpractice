--------------------------------------------------------
--  DDL for Synonymn IDX_GROUPREG_TYPEID
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."IDX_GROUPREG_TYPEID" FOR "APP"."IDX_GROUPREG_TYPEID";

--------------------------------------------------------
--  DDL for Synonymn DEBIT_NOTE_TRANS_SEQ
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."DEBIT_NOTE_TRANS_SEQ" FOR "FIN_APP"."DEBIT_NOTE_TRANS_SEQ";

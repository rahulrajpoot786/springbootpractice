--------------------------------------------------------
--  DDL for Synonymn ASSO_SEQ
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."ASSO_SEQ" FOR "APP"."ASSO_SEQ";

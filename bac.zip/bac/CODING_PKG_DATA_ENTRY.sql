--------------------------------------------------------
--  DDL for Synonymn CODING_PKG_DATA_ENTRY
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."CODING_PKG_DATA_ENTRY" FOR "INTX"."CODING_PKG_DATA_ENTRY";

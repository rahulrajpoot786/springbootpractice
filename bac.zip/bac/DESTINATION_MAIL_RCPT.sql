--------------------------------------------------------
--  DDL for Synonymn DESTINATION_MAIL_RCPT
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."DESTINATION_MAIL_RCPT" FOR "APP"."DESTINATION_MAIL_RCPT";

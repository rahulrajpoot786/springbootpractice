--------------------------------------------------------
--  DDL for Package BANK_PKG
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "VENUBABU"."BANK_PKG" IS

  PROCEDURE select_bank_list(
    v_bank_name                 IN  OUT TPA_BANK_MASTER.Bank_Name%TYPE,
    v_start_num                 IN  NUMBER   := 1,
    v_end_num                   IN  NUMBER   := 25,
    v_added_by                  IN  NUMBER,
    result_set	                OUT	SYS_REFCURSOR
  );
 --============================================================================
  PROCEDURE select_branch_list(
    v_ho_id                     IN  TPA_BANK_MASTER.ho_id%TYPE,
    v_added_by                  IN  NUMBER,
    result_set	                OUT	SYS_REFCURSOR
  ) ;
  --==========================================================================
  PROCEDURE select_bank_detail(
    v_bank_seq_id           	 	IN OUT	TPA_BANK_MASTER.bank_seq_id%TYPE,
    v_added_by                  IN      NUMBER,
    result_set	                OUT	    SYS_REFCURSOR
  );
  --=======================================================================

  PROCEDURE save_bank(
    v_bank_seq_id               IN OUT TPA_BANK_MASTER.bank_seq_id%TYPE,
    v_bank_name                 IN     TPA_BANK_MASTER.bank_name%TYPE,
    v_ho_id                     IN     TPA_BANK_MASTER.ho_id%TYPE,
    v_contact_person            IN     TPA_BANK_MASTER.contact_person%TYPE,
    v_address1                  IN     TPA_BANK_MASTER.address1%TYPE,
    v_address2                  IN     TPA_BANK_MASTER.address2%TYPE,
    v_address3                  IN     TPA_BANK_MASTER.address3%TYPE,
    v_state                     IN     TPA_BANK_MASTER.state%TYPE,
    v_city                      IN     TPA_BANK_MASTER.city%TYPE,
    v_country                   IN     TPA_BANK_MASTER.country%TYPE,
    v_pincode                   IN     TPA_BANK_MASTER.pincode%TYPE,
    v_email_id                  IN     TPA_BANK_MASTER.email_id%TYPE,
    v_phone_num1                IN     TPA_BANK_MASTER.phone_num1%TYPE,
    v_phone_num2                IN     TPA_BANK_MASTER.phone_num2%TYPE,
    v_mobile_num                IN     TPA_BANK_MASTER.mob_number%TYPE,
    v_fax_num                   IN     TPA_BANK_MASTER.fax_no%TYPE,
    v_remarks                   IN     TPA_BANK_MASTER.remarks%TYPE,
    v_cheque_template_id        IN     CHEQUE_TEMPLATE.cheque_template_id%TYPE,
    v_added_by                  IN     NUMBER,
    v_acc_file_name             IN     TPA_BANK_MASTER.Acc_File_Name%type,
    v_acc_doc                   IN     TPA_BANK_MASTER.Acc_Doc%type,
    v_ifsc_code                 IN     TPA_BANK_MASTER.IBAN_NO%TYPE,
    v_isd_code                  IN     TPA_BANK_MASTER.ISD_CODE%TYPE,
    v_std_code                  IN     TPA_BANK_MASTER.STD_CODE%TYPE,
    v_usd_iban                  IN     TPA_BANK_MASTER.USD_IBAN_NO%TYPE,
    v_euro_iban	                IN     TPA_BANK_MASTER.EURO_IBAN_NO%TYPE,
    v_gbp_iban                  IN     TPA_BANK_MASTER.GBP_IBAN_NO%TYPE, 
    v_rows_processed	          OUT    INTEGER
  );
 --==========================================================================================
  PROCEDURE delete_branch(
    v_bank_seq_id  	          IN	TPA_BANK_MASTER.bank_seq_id%TYPE,
    v_added_by                IN  NUMBER,
    v_rows_processed	        OUT	INTEGER
  );
 --==========================================================================================

END BANK_PKG;

/

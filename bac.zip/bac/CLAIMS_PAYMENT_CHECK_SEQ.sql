--------------------------------------------------------
--  DDL for Synonymn CLAIMS_PAYMENT_CHECK_SEQ
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."CLAIMS_PAYMENT_CHECK_SEQ" FOR "FIN_APP"."CLAIMS_PAYMENT_CHECK_SEQ";

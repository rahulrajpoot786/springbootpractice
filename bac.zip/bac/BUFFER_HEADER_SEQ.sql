--------------------------------------------------------
--  DDL for Synonymn BUFFER_HEADER_SEQ
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."BUFFER_HEADER_SEQ" FOR "APP"."BUFFER_HEADER_SEQ";

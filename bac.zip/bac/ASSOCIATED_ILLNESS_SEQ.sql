--------------------------------------------------------
--  DDL for Synonymn ASSOCIATED_ILLNESS_SEQ
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."ASSOCIATED_ILLNESS_SEQ" FOR "APP"."ASSOCIATED_ILLNESS_SEQ";

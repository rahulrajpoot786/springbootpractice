--------------------------------------------------------
--  DDL for Synonymn DHA_LOCATION_MASTER
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."DHA_LOCATION_MASTER" FOR "APP"."DHA_LOCATION_MASTER";

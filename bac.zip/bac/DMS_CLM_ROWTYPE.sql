--------------------------------------------------------
--  DDL for Synonymn DMS_CLM_ROWTYPE
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."DMS_CLM_ROWTYPE" FOR "APP"."DMS_CLM_ROWTYPE";

--------------------------------------------------------
--  DDL for Synonymn IDX_CLMINWARD_INWARDNO
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."IDX_CLMINWARD_INWARDNO" FOR "APP"."IDX_CLMINWARD_INWARDNO";

--------------------------------------------------------
--  DDL for Synonymn DHA_NATIONALITIES_MASTER
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."DHA_NATIONALITIES_MASTER" FOR "APP"."DHA_NATIONALITIES_MASTER";

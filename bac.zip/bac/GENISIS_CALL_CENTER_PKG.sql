--------------------------------------------------------
--  DDL for Package Body GENISIS_CALL_CENTER_PKG
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "VENUBABU"."GENISIS_CALL_CENTER_PKG" IS

PROCEDURE PAT_CLM_MOB_DTL_SEARCH (
P_MOBILE          IN VARCHAR2 ,
P_IVR_NO          IN VARCHAR2 ,--1 PREAUTH 2 CLAIM 
P_PREAUTH_NUMBER  IN VARCHAR2,
P_CLAIM_NUMBER    IN VARCHAR2,
P_OUT_RESULT1     OUT  SYS_REFCURSOR)
IS

CURSOR CLAIM_CUR IS
SELECT DISTINCT pg.TPA_ENROLLMENT_NUMBER,ce.mem_name as CLAIMANT_NAME,CE.MEM_AGE,B.MOBILE_NO, 
 CASE CE.Clm_Status_Type_Id WHEN 'INP'  THEN 1 
                                    WHEN 'APR'  THEN 2
                                    WHEN 'REJ'  THEN 3
                                    WHEN 'PCN'  THEN 4
                                    WHEN 'REQ'  THEN 5
                                    WHEN 'PCO'  THEN 6
                                    WHEN 'IPOL' THEN 7  END STATUS,ce.CLAIM_NUMBER as Pre_Or_Clm_No
             FROM APP.clm_authorization_details CE
                  JOIN APP.TPA_ENR_POLICY_MEMBER M ON (CE.MEMBER_SEQ_ID=M.MEMBER_SEQ_ID)        
                  JOIN APP.TPA_ENR_POLICY_GROUP PG ON(m.policy_group_seq_id=pg.policy_group_seq_id)
                  LEFT OUTER JOIN (Select  TTK_UTIL_PKG.FN_DECRYPT(g.MOBILE_NO) MOBILE_NO,g.ENR_ADDRESS_SEQ_ID
                  from APP.TPA_ENR_MEM_ADDRESS g where  g.MOBILE_NO is not null) B
                  ON (PG.ENR_ADDRESS_SEQ_ID=B.ENR_ADDRESS_SEQ_ID)
                  where  
                  ce.CLAIM_NUMBER=P_CLAIM_NUMBER; 
lv_CLAIM_CUR CLAIM_CUR%ROWTYPE;


CURSOR CLAIM_MEM_CUR  IS
WITH LCN AS
   (SELECT    CASE ce.clm_status_type_id WHEN 'INP'  THEN 1     
                                         WHEN 'APR'  THEN 2       
                                         WHEN 'REJ'  THEN 3
                                         WHEN 'PCN'  THEN 4
                                         WHEN 'REQ'  THEN 5
                                         WHEN 'PCO'  THEN 6
                                         WHEN 'IPOL' THEN 7  END AS STATUS,pg.TPA_ENROLLMENT_NUMBER,ce.mem_name as claimant_name,
                      ce.mem_age ,ce.claim_number as CLAIM_NUMBER,CE.ADDED_DATE,P_MOBILE AS MOBILE_NO
                    , ROW_NUMBER() OVER (order by ce.added_date DESC) RN

                  FROM APP.clm_authorization_details CE
                  JOIN APP.TPA_ENR_POLICY_MEMBER M ON (CE.MEMBER_SEQ_ID=M.MEMBER_SEQ_ID)
                  JOIN APP.tpa_enr_policy_group TG ON (TG.policy_group_seq_id = M.policy_group_seq_id)
                  JOIN APP.TPA_ENR_POLICY_GROUP PG ON(m.policy_group_seq_id=pg.policy_group_seq_id)
                  JOIN APP.TPA_ENR_MEM_ADDRESS g ON (G.ENR_ADDRESS_SEQ_ID=TG.ENR_ADDRESS_SEQ_ID)
                  WHERE INTX.FN_MOB_DECRYPT(G.MOBILE_NO) =P_MOBILE order by ce.added_date desc)
        select * from LCN where LCN.RN = 1; 

LV_CLAIM_MEM_CUR CLAIM_MEM_CUR%ROWTYPE;          

CURSOR PRE_CUR IS 
SELECT DISTINCT  pg.TPA_ENROLLMENT_NUMBER,pe.mem_name as CLAIMANT_NAME,PE.MEM_AGE,B.MOBILE_NO,
         CASE PE.Pat_Status_Type_Id WHEN 'INP'  THEN 1 
                                    WHEN 'APR'  THEN 2
                                    WHEN 'REJ'  THEN 3
                                    WHEN 'PCN'  THEN 4
                                    WHEN 'REQ'  THEN 5
                                    WHEN 'PCO'  THEN 6
                                    WHEN 'IPOL' THEN 7  END STATUS,PE.PRE_AUTH_NUMBER as PRE_OR_CLM_NO
             FROM APP.pat_authorization_details PE
                 JOIN APP.TPA_ENR_POLICY_MEMBER M ON (PE.MEMBER_SEQ_ID=M.MEMBER_SEQ_ID)        
                 JOIN APP.TPA_ENR_POLICY_GROUP PG ON(m.policy_group_seq_id=pg.policy_group_seq_id)
                  LEFT OUTER JOIN (Select  TTK_UTIL_PKG.FN_DECRYPT(g.MOBILE_NO) MOBILE_NO,g.ENR_ADDRESS_SEQ_ID
                  from APP.TPA_ENR_MEM_ADDRESS g where  g.MOBILE_NO is not null AND g.MOBILE_NO <> '0') B
                  ON (PG.ENR_ADDRESS_SEQ_ID=B.ENR_ADDRESS_SEQ_ID)
                  where PE.PRE_AUTH_NUMBER=P_PREAUTH_NUMBER;

LV_PRE_CUR PRE_CUR%ROWTYPE;

CURSOR PRE_MEM_CUR IS 
WITH LPN AS(
 SELECT CASE PE.Pat_Status_Type_Id WHEN 'INP'  THEN 1     
                                     WHEN 'APR'  THEN 2       
                                     WHEN 'REJ'  THEN 3
                                     WHEN 'PCN'  THEN 4
                                     WHEN 'REQ'  THEN 5
                                     WHEN 'PCO'  THEN 6
                                     WHEN 'IPOL' THEN 7  END AS STATUS
                     ,PE.PRE_AUTH_NUMBER,PE.ADDED_DATE,TEP.TPA_ENROLLMENT_NUMBER,PE.Mem_Name as CLAIMANT_NAME,PE.MEM_AGE
                       ,P_MOBILE AS MOBILE_NO
                       , ROW_NUMBER() OVER (order by PE.ADDED_DATE  DESC) RN
                    FROM APP.pat_authorization_details PE
                    JOIN APP.TPA_ENR_POLICY_MEMBER M ON (PE.MEMBER_SEQ_ID=M.MEMBER_SEQ_ID)
                    JOIN APP.tpa_enr_policy_group TG ON((TG.policy_group_seq_id = M.policy_group_seq_id))
                    JOIN APP.TPA_ENR_POLICY_GROUP TEP ON(m.policy_group_seq_id=TEP.policy_group_seq_id)
                    JOIN APP.TPA_ENR_MEM_ADDRESS g ON(TG.ENR_ADDRESS_SEQ_ID=G.ENR_ADDRESS_SEQ_ID)                  
                    where INTX.FN_MOB_DECRYPT(G.MOBILE_NO) = P_MOBILE ORDER BY PE.ADDED_DATE DESC
                    )
select * from LPN where LPN.RN = 1;  

LV_PRE_MEM_CUR PRE_MEM_CUR%ROWTYPE;
            
    CURSOR MOB_CUR IS 
    SELECT me.member_seq_id,me.MEM_NAME,ME.mem_age,gr.TPA_ENROLLMENT_NUMBER,COUNT(*) CNT
          FROM app.tpa_enr_policy ep
               INNER JOIN app.tpa_enr_policy_group gr ON (gr.policy_seq_id=ep.policy_seq_id)
               INNER JOIN app.tpa_enr_policy_member me ON (me.policy_group_seq_id=gr.policy_group_seq_id)
               INNER JOIN app.tpa_enr_mem_address ad ON (ad.enr_address_seq_id=GR.enr_address_seq_id)
         WHERE 
         intx.FN_MOB_DECRYPT(ad.MOBILE_NO) = P_MOBILE AND
          me.RELSHIP_TYPE_ID='NSF'
         and ep.effective_to_date > (SYSDATE-30)
               AND ep.policy_status_general_type_id!='POC' AND me.deleted_yn='N'
          GROUP BY me.member_seq_id,me.MEM_NAME,ME.mem_age,gr.TPA_ENROLLMENT_NUMBER
            ORDER BY me.member_seq_id DESC      ;
          
LV_MOB_CUR MOB_CUR%ROWTYPE;    
 
BEGIN
--1
IF  P_PREAUTH_NUMBER IS NULL AND P_CLAIM_NUMBER IS NULL AND P_IVR_NO IS NULL AND P_MOBILE IS NOT NULL THEN
         OPEN  MOB_CUR;
         FETCH MOB_CUR INTO LV_MOB_CUR;
         CLOSE MOB_CUR;
         IF NVL(LV_MOB_CUR.CNT,0) >0 THEN 
        OPEN P_OUT_RESULT1 FOR SELECT 'STATUS:'||'Y'||'|'||'MOBILE_NO:'||P_MOBILE||'|'||'TPA_ENROLLMENT_NUMBER:'||LV_MOB_CUR.TPA_ENROLLMENT_NUMBER||'|'||'CLAIMANT_NAME:'||LV_MOB_CUR.MEM_NAME||'|'||'MEM_AGE:'||LV_MOB_CUR.MEM_AGE AS CALL_MEMBER_DETAILS FROM DUAL;
         ELSE 
        OPEN P_OUT_RESULT1 FOR SELECT 'STATUS:'||'N' AS CALL_MEMBER_DETAILS FROM DUAL;
         END IF;
END IF;
--2
IF P_PREAUTH_NUMBER IS NULL AND P_MOBILE IS NOT NULL AND P_IVR_NO=1 THEN
         OPEN  MOB_CUR;
         FETCH MOB_CUR INTO LV_MOB_CUR;
         CLOSE MOB_CUR;
    IF NVL(LV_MOB_CUR.CNT,0) >0 THEN 
      OPEN PRE_MEM_CUR;
      FETCH PRE_MEM_CUR INTO LV_PRE_MEM_CUR;
      CLOSE PRE_MEM_CUR;
      
    IF LV_PRE_MEM_CUR.pre_auth_number IS NOT NULL THEN
     OPEN P_OUT_RESULT1 FOR SELECT 'STATUS:'||LV_PRE_MEM_CUR.Status||'|'||'MOBILE_NO:'||LV_PRE_MEM_CUR.MOBILE_NO||'|'||'TPA_ENROLLMENT_NUMBER:'||LV_PRE_MEM_CUR.TPA_ENROLLMENT_NUMBER||'|'||'CLAIMANT_NAME:'||
         LV_PRE_MEM_CUR.CLAIMANT_NAME||'|'||'MEM_AGE:'||LV_PRE_MEM_CUR.MEM_AGE||'|'||'PRE_AUTH_NUMBER:'||LV_PRE_MEM_CUR.PRE_AUTH_NUMBER AS CALL_MEMBER_DETAILS FROM DUAL;
    ELSE
         OPEN P_OUT_RESULT1 FOR SELECT 'STATUS:'||0 AS CALL_MEMBER_DETAILS FROM DUAL;
    END IF;
    ELSE 
     OPEN P_OUT_RESULT1 FOR SELECT 'STATUS:'||'N' AS CALL_MEMBER_DETAILS FROM DUAL;
    END IF;
END IF;
--3
IF P_CLAIM_NUMBER IS NULL AND P_MOBILE IS NOT NULL AND P_IVR_NO=2 THEN
         OPEN  MOB_CUR;
         FETCH MOB_CUR INTO LV_MOB_CUR;
         CLOSE MOB_CUR;
        IF NVL(LV_MOB_CUR.CNT,0) >0 THEN 
        OPEN CLAIM_MEM_CUR;--LV_MOB_CUR.member_seq_id);
        FETCH CLAIM_MEM_CUR INTO LV_CLAIM_MEM_CUR;
        CLOSE CLAIM_MEM_CUR;
        
        IF LV_CLAIM_MEM_CUR.CLAIM_NUMBER IS NOT NULL THEN 
           OPEN P_OUT_RESULT1 FOR SELECT 'STATUS:'||LV_CLAIM_MEM_CUR.Status||'|'||'MOBILE_NO:'||LV_CLAIM_MEM_CUR.MOBILE_NO||'|'||'TPA_ENROLLMENT_NUMBER:'||LV_CLAIM_MEM_CUR.TPA_ENROLLMENT_NUMBER
                ||'|'||'CLAIMANT_NAME:'||LV_CLAIM_MEM_CUR.CLAIMANT_NAME||'|'||'MEM_AGE:'||LV_CLAIM_MEM_CUR.MEM_AGE||'|'||'CLAIM_NUMBER:'||LV_CLAIM_MEM_CUR.CLAIM_NUMBER AS CALL_MEMBER_DETAILS FROM DUAL;
        ELSE
         OPEN P_OUT_RESULT1 FOR SELECT  'STATUS:'||0 AS CALL_MEMBER_DETAILS FROM DUAL;
        END IF;
        ELSE
         OPEN P_OUT_RESULT1 FOR SELECT 'STATUS:'||'N' AS CALL_MEMBER_DETAILS FROM DUAL;
        END IF;
   ELSIF P_CLAIM_NUMBER IS NULL AND P_MOBILE IS NULL AND P_IVR_NO=2 THEN
        OPEN P_OUT_RESULT1 FOR SELECT 'STATUS:'||0  AS CALL_MEMBER_DETAILS FROM DUAL;
END IF;
--4   
IF P_PREAUTH_NUMBER IS NOT NULL AND NVL(P_IVR_NO,0) IN (1,0) THEN
         OPEN PRE_CUR;
         FETCH PRE_CUR INTO LV_PRE_CUR;
         CLOSE PRE_CUR;
         
        IF LV_PRE_CUR.PRE_OR_CLM_NO IS NOT NULL THEN
        OPEN P_OUT_RESULT1 FOR SELECT 'STATUS:'||LV_PRE_CUR.Status||'|'||'MOBILE_NO:'||LV_PRE_CUR.MOBILE_NO||'|'||'TPA_ENROLLMENT_NUMBER:'||LV_PRE_CUR.TPA_ENROLLMENT_NUMBER
             ||'|'||'CLAIMANT_NAME:'||LV_PRE_CUR.CLAIMANT_NAME||'|'||'MEM_AGE:'||LV_PRE_CUR.MEM_AGE||'|'||'PRE_AUTH_NUMBER:'||LV_PRE_CUR.PRE_OR_CLM_NO  AS CALL_MEMBER_DETAILS FROM DUAL;
        ELSE
         OPEN P_OUT_RESULT1 FOR SELECT 'STATUS:'||0  AS CALL_MEMBER_DETAILS FROM DUAL;
        END IF;
END IF;
--5   
IF P_CLAIM_NUMBER IS NOT NULL AND NVL(P_IVR_NO,0) IN (2,0) THEN
            OPEN  CLAIM_CUR;
            FETCH CLAIM_CUR into lv_CLAIM_CUR;
            CLOSE CLAIM_CUR;
        
        IF lv_CLAIM_CUR.Pre_Or_Clm_No IS NOT NULL THEN 
        OPEN P_OUT_RESULT1 FOR SELECT 'STATUS:'||lv_CLAIM_CUR.Status||'|'||'MOBILE_NO:'||lv_CLAIM_CUR.MOBILE_NO||'|'||'TPA_ENROLLMENT_NUMBER:'||lv_CLAIM_CUR.TPA_ENROLLMENT_NUMBER
             ||'|'||'CLAIMANT_NAME:'||lv_CLAIM_CUR.CLAIMANT_NAME||'|'||'MEM_AGE:'||lv_CLAIM_CUR.MEM_AGE||'|'||'CLAIM_NUMBER:'||lv_CLAIM_CUR.PRE_OR_CLM_NO AS CALL_MEMBER_DETAILS FROM DUAL;
        ELSE
        OPEN P_OUT_RESULT1 FOR SELECT 'STATUS:'||0 AS CALL_MEMBER_DETAILS FROM DUAL;
        END IF;
END IF;

END PAT_CLM_MOB_DTL_SEARCH;


--===============================================================================================================

PROCEDURE WEBSERVICE_ENROLLMENT_NO(
P_ENROLLMENT_NO TPA_ENR_POLICY_GROUP.TPA_ENROLLMENT_NUMBER%TYPE,
P_ENROLL_HISTORY  OUT XMLTYPE)
IS

CURSOR ENROLL_CUR IS SELECT me.MEM_NAME,ME.mem_age,ttk_util_pkg.fn_decrypt(ad.MOBILE_NO) mobile_no,gr.TPA_ENROLLMENT_NUMBER,me.RELSHIP_TYPE_ID
          FROM app.tpa_enr_policy ep
               INNER JOIN app.tpa_enr_policy_group gr ON (gr.policy_seq_id=ep.policy_seq_id)
               INNER JOIN app.tpa_enr_policy_member me ON (me.policy_group_seq_id=gr.policy_group_seq_id)
             LEFT OUTER JOIN app.tpa_enr_mem_address ad ON (ad.enr_address_seq_id=GR.enr_address_seq_id)
         WHERE  GR.TPA_ENROLLMENT_NUMBER=P_ENROLLMENT_NO 
     -- AND me.RELSHIP_TYPE_ID='NSF'
      AND ep.policy_status_general_type_id!='POC' AND me.deleted_yn='N'
      order by case when me.RELSHIP_TYPE_ID='NSF' then 1 end;
      
      V_ENROLL_CUR  ENROLL_CUR%ROWTYPE;
      v_preauth_doc        DBMS_XMLDOM.DOMDocument;
      v_preauth_root_node  DBMS_XMLDOM.DOMNode;
      v_elem               DBMS_XMLDOM.DOMElement;
      v_node               DBMS_XMLDOM.DOMNode;
      v_parent_node        DBMS_XMLDOM.DOMNODE;

BEGIN
      v_preauth_doc := dbms_xmldom.newDOMDocument;
      dbms_xmldom.setVersion( v_preauth_doc, '1.0' );
      v_preauth_root_node := dbms_xmldom.makeNode(v_preauth_doc);
       v_elem := dbms_xmldom.createElement( v_preauth_doc, 'enrollmenthistory' );
      v_node := dbms_xmldom.makeNode( v_elem );
      v_preauth_root_node := dbms_xmldom.appendChild( v_preauth_root_node, v_node );
      
      FOR V_ENROLL_CUR IN ENROLL_CUR
      LOOP
v_elem:=dbms_xmldom.createElement(v_preauth_doc,'enrollmentdetails');
          dbms_xmldom.setAttribute(v_elem,'memname',V_ENROLL_CUR.MEM_NAME);
          dbms_xmldom.setAttribute(v_elem,'age',V_ENROLL_CUR.mem_age);
          dbms_xmldom.setAttribute(v_elem,'mobileno',V_ENROLL_CUR.mobile_no);
          dbms_xmldom.setAttribute(v_elem,'relationship',V_ENROLL_CUR.RELSHIP_TYPE_ID);
          dbms_xmldom.setAttribute(v_elem,'enrollmentno',V_ENROLL_CUR.TPA_ENROLLMENT_NUMBER);
        
          v_node := dbms_xmldom.makeNode(v_elem);
          v_parent_node := dbms_xmldom.appendChild( v_preauth_root_node, v_node);
       
         END LOOP;
         P_ENROLL_HISTORY := dbms_xmldom.getxmltype(v_preauth_doc);
           dbms_xmldom.freeDocument(v_preauth_doc);
           
END WEBSERVICE_ENROLLMENT_NO;


--===============================================================================================================

PROCEDURE SELECT_ENROLL_SEARCH_PROC(
P_TPA_ENROLLMENT_ID IN TPA_ENR_POLICY_MEMBER.TPA_ENROLLMENT_ID%TYPE,
P_mobile_no         IN  TPA_ENR_MEM_ADDRESS.mobile_no%TYPE,
P_employee_no       IN  TPA_ENR_POLICY_GROUP.employee_no%TYPE,
P_insured_name      IN  TPA_ENR_POLICY_GROUP.insured_name%TYPE,
P_SORT_VAR          IN VARCHAR2,
P_SORT_ORDER        IN VARCHAR2,   --ASC/DESC                                 
P_START_NUM         IN NUMBER,
P_END_NUM           IN NUMBER, 
P_FLAG              IN VARCHAR2,
P_CORPORATE         IN TPA_GROUP_REGISTRATION.GROUP_NAME%TYPE, 
P_POLICY_NUMBER     IN TPA_ENR_POLICY.POLICY_NUMBER%TYPE,
P_EMIRATE_ID        IN TPA_ENR_POLICY_MEMBER.EMIRATE_ID%TYPE,
P_EMAIL             IN VARCHAR2,
P_OUT_RESULT        OUT SYS_REFCURSOR
)  
IS

TYPE bind_tab_type IS TABLE OF VARCHAR2(250) INDEX BY BINARY_INTEGER ;
 bind_tab   bind_tab_type;
 i   NUMBER(2) := 0;
 v_type  VARCHAR2(20);
 V_STRING   VARCHAR2(5000);
 V_WHERE    VARCHAR2(5000):=NULL;

BEGIN
IF P_TPA_ENROLLMENT_ID IS NOT NULL OR P_mobile_no IS NOT NULL OR P_insured_name IS NOT NULL
  OR P_POLICY_NUMBER IS NOT NULL OR P_CORPORATE IS NOT NULL OR P_employee_no IS NOT NULL OR P_EMIRATE_ID IS NOT NULL or P_EMAIL is not null THEN
      V_STRING:='
      WITH mobile_tb AS (select INTX.FN_MOB_DECRYPT(mobile_no)  mobile_no,ENR_ADDRESS_SEQ_ID,
           ttk_util_pkg.fn_decrypt(email_id ) as email_id
      from tpa_enr_mem_address)
      SELECT me.TPA_ENROLLMENT_ID,me.MEM_NAME,ME.mem_age,RE.RELSHIP_DESCRIPTION,
      CASE WHEN ME.RELSHIP_TYPE_ID=''NSF'' THEN gr.employee_no ELSE NULL END AS employee_no,
      ad.MOBILE_NO as MOBILE_NO,ME.MEMBER_SEQ_ID,EP.POLICY_NUMBER,EP.POLICY_SEQ_ID
      ,CASE WHEN COUNT(C.pre_auth_number )>0 THEN ''Y'' ELSE ''N'' END PAT_CNT
      ,CASE WHEN count(CE.CLAIM_SEQ_ID)>0 THEN ''Y'' ELSE ''N'' END CLM_CNT
      ,case when EP.ENROL_TYPE_ID=''IND'' THEN ''INDIVIDUAL POLICY'' ELSE tg.GROUP_NAME END  CORPORATE_NAME
      ,GR.POLICY_GROUP_SEQ_ID
      ,CASE WHEN EP.ENROL_TYPE_ID = ''COR'' THEN TEL.TEMPLATE_NAME
            ELSE TEP.TEMPLATE_NAME END AS TEMPLATE_NAME,
           CASE WHEN to_date(sysdate,''dd-mm-yyyy'')> to_date(EP.Effective_To_Date,''dd-mm-yyyy'') and ME.STATUS_GENERAL_TYPE_ID =''POA'' THEN  ''Policy Expired''  
                  WHEN ME.STATUS_GENERAL_TYPE_ID=''POA'' THEN ''Active'' 
                  WHEN ME.STATUS_GENERAL_TYPE_ID=''POC'' THEN  ''Cancelled'' END as MEM_STATUS,
        TPL.PROD_POLICY_SEQ_ID,
         gen.DESCRIPTION AS NETWORK_TYPE,
         ME.VIP_YN as VIP,
         CASE WHEN  ME.VIP_YN = ''Y'' THEN ''Yes'' ELSE ''No'' END  as VIPYN,
         ME.EMIRATE_ID QATAR_ID
           
        FROM app.tpa_enr_policy ep
      INNER JOIN APP.tpa_ins_product ip on (ep.product_seq_id=ip.product_seq_id)
      JOIN APP.tpa_general_code GEN ON  (ip.PRODUCT_CAT_TYPE_ID=GEN.GENERAL_TYPE_ID)  
      INNER JOIN app.tpa_enr_policy_group gr ON (gr.policy_seq_id=ep.policy_seq_id)
      INNER JOIN app.tpa_enr_policy_member me ON (me.policy_group_seq_id=gr.policy_group_seq_id)
      LEFT OUTER JOIN mobile_tb ad ON (ad.enr_address_seq_id=me.enr_address_seq_id)
      INNER JOIN TPA_RELATIONSHIP_CODE RE ON (RE.RELSHIP_TYPE_ID=me.RELSHIP_TYPE_ID)
      LEFT OUTER JOIN pat_authorization_details C ON ( ME.member_seq_id = C.member_seq_id )
      LEFT OUTER JOIN clm_authorization_details CE ON (ME.member_seq_id = CE.member_seq_id)
      LEFT OUTER JOIN  TPA_GROUP_REGISTRATION TG on (TG.GROUP_REG_SEQ_ID=GR.GROUP_REG_SEQ_ID)
      LEFT OUTER JOIN TPA_INS_PROD_POLICY TPD ON (TPD.PRODUCT_SEQ_ID=EP.PRODUCT_SEQ_ID)----PRODUCT
      LEFT OUTER JOIN APP.TPA_POLICY_TEMPLATES TEP ON (TEP.TEMPLATE_ID=TPD.TEMPLATE_ID )----PRODUCT
      LEFT OUTER JOIN TPA_INS_PROD_POLICY TPL ON (TPL.POLICY_SEQ_ID=EP.POLICY_SEQ_ID)-----POLICY
      LEFT OUTER JOIN APP.TPA_POLICY_TEMPLATES TEL ON (TEL.TEMPLATE_ID=TPL.TEMPLATE_ID)-----POLICY
      ';
       
       
      IF P_TPA_ENROLLMENT_ID IS NOT NULL THEN
       V_WHERE:=  V_WHERE|| ' AND GR.POLICY_GROUP_SEQ_ID IN 
                             (SELECT POLICY_GROUP_SEQ_ID 
                                   FROM TPA_ENR_POLICY_GROUP 
                                   WHERE TPA_ENROLLMENT_NUMBER=UPPER(:P_TPA_ENROLLMENT_ID))';
       --V_WHERE:=  V_WHERE|| ' AND ME.TPA_ENROLLMENT_ID=UPPER(:P_TPA_ENROLLMENT_ID)';
      i:=i+1;
      bind_tab(i):=P_TPA_ENROLLMENT_ID;
      END IF;
       
       IF P_mobile_no IS NOT NULL THEN
        V_WHERE:=  V_WHERE|| ' AND ad.MOBILE_NO = :P_mobile_no';
       i:=i+1;
      bind_tab(i):= P_mobile_no;
        END IF;
        
       IF P_employee_no IS NOT NULL THEN
        V_WHERE:=  V_WHERE|| ' AND gr.employee_no=:P_employee_no';
        i:=i+1;
      bind_tab(i):=P_employee_no;
       END IF;
       
       IF P_insured_name IS NOT NULL THEN
       V_WHERE:=  V_WHERE|| ' AND ME.MEM_NAME like :P_insured_name';
        i:=i+1;
      bind_tab(i):='%'||upper(P_insured_name)||'%';
       END IF;
       
       IF P_CORPORATE IS  NOT NULL THEN 
       V_WHERE:=  V_WHERE|| ' AND TG.GROUP_NAME like :P_CORPORATE';
        i:=i+1;
      bind_tab(i):='%'||P_CORPORATE||'%';
       END IF;
       
        IF P_POLICY_NUMBER IS NOT NULL THEN
        V_WHERE:=  V_WHERE|| ' AND EP.POLICY_NUMBER=:P_POLICY_NUMBER';
       i:=i+1;
      bind_tab(i):=P_POLICY_NUMBER;
        END IF;
      ------------ CR0218(SEARCH BY QATARID)---------------------- 
      IF P_EMIRATE_ID IS NOT NULL THEN
        V_WHERE:=  V_WHERE|| ' AND ME.EMIRATE_ID=:P_EMIRATE_ID';
        i:=i+1;
        bind_tab(i):=P_EMIRATE_ID;
      END IF;
      ------------------------------------------------------------- 
     IF P_EMAIL IS NOT NULL THEN
        V_WHERE:=  V_WHERE|| ' AND ad.email_id = :P_EMAIL';
       i:=i+1;
       bind_tab(i):= P_EMAIL;
     END IF;
      IF V_WHERE IS NOT NULL THEN
       V_WHERE:=' WHERE '|| SUBSTR(V_WHERE,5) ;
       END IF;
       
       V_STRING :=V_STRING||V_WHERE||' GROUP BY me.TPA_ENROLLMENT_ID,me.MEM_NAME,ME.mem_age,RE.RELSHIP_DESCRIPTION,
      ME.RELSHIP_TYPE_ID,gr.employee_no ,TPL.PROD_POLICY_SEQ_ID,gen.DESCRIPTION,ME.VIP_YN, ME.VIP_YN,
      ad.MOBILE_NO,ME.MEMBER_SEQ_ID,EP.POLICY_NUMBER,EP.POLICY_SEQ_ID,EP.ENROL_TYPE_ID,tg.GROUP_NAME,GR.POLICY_GROUP_SEQ_ID,TEL.TEMPLATE_NAME,TEP.TEMPLATE_NAME ,me.STATUS_GENERAL_TYPE_ID,EP.Effective_To_Date,ME.EMIRATE_ID ' ;
       
      IF P_FLAG='Y' THEN 
       v_string:= ' SELECT * FROM (SELECT A.*,DENSE_RANK() OVER(ORDER BY '||P_SORT_VAR ||' '||P_SORT_ORDER||',ROWNUM) Q 
       FROM ('||v_string||') A) WHERE  Q>=  '||P_START_NUM||' AND Q<= '||P_END_NUM || ' ORDER BY POLICY_SEQ_ID DESC,1' ;
 ELSE
     v_string:= ' SELECT * FROM (SELECT A.*,DENSE_RANK() OVER(ORDER BY '||P_SORT_VAR ||' '||P_SORT_ORDER||',ROWNUM) Q 
     FROM ('||v_string||') A) WHERE  Q>=  '||P_START_NUM||' AND Q<= '||P_END_NUM || ' ORDER BY POLICY_SEQ_ID ASC,1' ;
END  IF;

CASE bind_tab.COUNT
  WHEN 1 THEN OPEN P_OUT_RESULT FOR v_string USING bind_tab(1);
  WHEN 2 THEN OPEN P_OUT_RESULT FOR v_string USING bind_tab(1),bind_tab(2);
  WHEN 3 THEN OPEN P_OUT_RESULT FOR v_string USING bind_tab(1),bind_tab(2),bind_tab(3);
  WHEN 4 THEN OPEN P_OUT_RESULT FOR v_string USING bind_tab(1),bind_tab(2),bind_tab(3),bind_tab(4);
  WHEN 5 THEN OPEN P_OUT_RESULT FOR v_string USING bind_tab(1),bind_tab(2),bind_tab(3),bind_tab(4),bind_tab(5);
  WHEN 6 THEN OPEN P_OUT_RESULT FOR v_string USING bind_tab(1),bind_tab(2),bind_tab(3),bind_tab(4),bind_tab(5),bind_tab(6);
  WHEN 7 THEN OPEN P_OUT_RESULT FOR v_string USING bind_tab(1),bind_tab(2),bind_tab(3),bind_tab(4),bind_tab(5),bind_tab(6),bind_tab(7);
ELSE
  OPEN P_OUT_RESULT FOR v_string;
END CASE;
ELSE
  
OPEN P_OUT_RESULT FOR 
            SELECT NULL AS TPA_ENROLLMENT_ID,
	                 NULL AS MEM_NAME,
                   NULL AS mem_age,
                   NULL AS RELSHIP_DESCRIPTION,
                   NULL AS employee_no,
                   NULL AS MOBILE_NO,
	                 NULL AS MEMBER_SEQ_ID,
	                 NULL AS POLICY_NUMBER,
	                 NULL AS POLICY_SEQ_ID,
                    'N' AS PAT_CNT,
                    'N' AS CLM_CNT,
                   NULL AS CORPORATE_NAME,
                   NULL AS POLICY_GROUP_SEQ_ID,
                   NULL AS TEMPLATE_NAME,
                  NULL AS MEM_STATUS,
                   NULL AS PROD_POLICY_SEQ_ID,
                   NULL AS NETWORK_TYPE,                   
                   NULL AS VIP,
                   NULL AS VIPYN,
                   NULL AS QATAR_ID
             FROM DUAL;

END IF;

END SELECT_ENROLL_SEARCH_PROC;

--===============================================================================================================

PROCEDURE SELECT_POLICY_DTL_PROC(
P_MEMBER_SEQ_ID    tpa_enr_policy_member.member_seq_id%TYPE,
P_OUT_RESULT        OUT SYS_REFCURSOR
)
IS

BEGIN

OPEN P_OUT_RESULT FOR
SELECT 
ME.tpa_enrollment_id,
ME.MEM_NAME,
C.description AS GENDER,
TO_CHAR(ME.MEM_DOB,'DD/MM/YYYY') AS MEM_DOB,
ME.MEM_AGE,
TO_CHAR(ME.DATE_OF_INCEPTION,'DD/MM/YYYY') AS DATE_OF_INCEPTION,
TO_CHAR(ME.DATE_OF_EXIT,'DD/MM/YYYY') AS DATE_OF_EXIT,
J.description AS CATEGORY,
TIP.PRODUCT_NAME,
P.POLICY_NUMBER,
P.ZONE_CODE,
ME.DIABETES_COVER_YN,
ME.HYPERTENSION_COVER_YN,
L.INS_COMP_NAME,
CASE P.ENROL_TYPE_ID WHEN 'COR' THEN 'Corporate'
                     WHEN 'IND' THEN 'Individual'
                     WHEN 'ING' THEN 'Individual As Group'
                     WHEN 'NCR' THEN 'Non Corporate' END as POLICY_TYPE,
CASE P.POLICY_SUB_GENERAL_TYPE_ID  WHEN 'PNF' THEN 'Non-Floater'  
                                   WHEN 'PFL' THEN 'Floater'       
                                   WHEN 'PFR' THEN 'Floater with Restriction' 
                                   WHEN 'PFL' THEN 'Floater + Non-Floater' END POLICY_SUB_TYPE,
M.GROUP_NAME AS CORPORATE_NAME,
M.GROUP_ID,
TO_CHAR(P.EFFECTIVE_FROM_DATE,'DD/MM/YYYY') AS POLICY_START_DATE,
TO_CHAR(P.EFFECTIVE_TO_DATE,'DD/MM/YYYY')  AS POLICY_END_DATE,
CASE WHEN ME.Mem_General_Type_Id = 'PFL' THEN TRIM(TO_CHAR(TG.FAMILY_TOT_SUM_INSURED, '999,999,9999,999,999')) ELSE '0' END TOTAL_SUM_INSURED ,
CASE WHEN ME.Mem_General_Type_Id = 'PNF' THEN  TRIM(TO_CHAR(MB.SUM_INSURED, '999,999,9999,999,999')) ELSE '0' END  AS mem_sum_insured,
--(mb.sum_insured + MB.bonus - MB.utilised_sum_insured - MB.utilised_cum_bonus) AS balnace_sum_insured ,
/*TRIM(TO_CHAR(case when p.enrol_type_id='COR'    THEN
        CASE WHEN p.Policy_Sub_General_Type_Id='PFL' THEN administration_pkg.get_max_restrict_amt_rel(tg.policy_seq_id,tg.policy_group_seq_id,me.MEMBER_SEQ_ID,'AB')
        ELSE administration_pkg.get_max_restrict_amt(tg.policy_seq_id,tg.policy_group_seq_id,me.MEMBER_SEQ_ID,'AB') END
        ELSE (mb.sum_insured + bonus - utilised_sum_insured - utilised_cum_bonus) END, '999,999,9999,999,999'))*/ 
 TO_CHAR(nvl(mb.sum_insured,0) - nvl(mb.utilised_sum_insured,0), '999,999,9999,999,999') AS balnace_sum_insured,
--P.CUMULATIVE_BONUS,
CASE WHEN P.POLICY_SUB_GENERAL_TYPE_ID='PNF' THEN (SELECT NVL(ROUND(B.BONUS),0) FROM APP.TPA_ENR_BALANCE B  WHERE B.MEMBER_SEQ_ID=ME.MEMBER_SEQ_ID )
     WHEN P.POLICY_SUB_GENERAL_TYPE_ID='PFL' THEN (SELECT NVL(ROUND(B.BONUS),0) FROM APP.TPA_ENR_BALANCE B  WHERE B.POLICY_GROUP_SEQ_ID=tG.POLICY_GROUP_SEQ_ID)
     END CUMULATIVE_BONUS,
Q.description AS policy_status,
TG.EMPLOYEE_NO,
--TTK_UTIL_PKG.FN_DECRYPT(AD.MOBILE_NO) MOBILE_NO,
--TG.EMP_GRADE,
--TG.EMP_GRADE_DESC,
CASE WHEN ME.mem_age >= 60 THEN 'Y' ELSE 'N' END as senior_citizen_yn
--,NVL(P.TOPUP_POLICY,'N') TOPUP_POLICY
,NVL2(P.BUFFER_ALLOC_AMOUNT,'Y','N') BUFFER_ALLOC_AMOUNT
,ME.MEMBER_SEQ_ID
,P.ENROL_TYPE_ID,
ttk_util_pkg.fn_decrypt(mad.mobile_no) as mobile_no,
ttk_util_pkg.fn_decrypt(mad.email_id) as email_id,
P.Policy_Seq_Id,
CASE WHEN me.marital_status_id='SNG' THEN 'Single' 
     WHEN me.marital_status_id='MRD' THEN 'Married' ELSE 'NA' END maritalStatus,
       cc.description as nationality,
  CASE WHEN p.tpa_cheque_issued_general_type='IQC' THEN  ttk_util_pkg.fn_decrypt(corb.bank_name)
       WHEN p.tpa_cheque_issued_general_type='IQI'  THEN ttk_util_pkg.fn_decrypt(memb.bank_name)
         ELSE NULL END bankName,
           CASE WHEN p.tpa_cheque_issued_general_type='IQC' THEN ttk_util_pkg.fn_decrypt(corb.bank_ifsc)
       WHEN p.tpa_cheque_issued_general_type='IQI'  THEN  ttk_util_pkg.fn_decrypt(memb.bank_ifsc)
         ELSE NULL END swiftCode,
           CASE WHEN p.tpa_cheque_issued_general_type='IQC' THEN  ttk_util_pkg.fn_decrypt(corb.bank_micr)
       WHEN p.tpa_cheque_issued_general_type='IQI'  THEN  ttk_util_pkg.fn_decrypt(memb.bank_micr)
         ELSE NULL END ibanNo,
           CASE WHEN p.tpa_cheque_issued_general_type='IQC' THEN  corc.state_name
       WHEN p.tpa_cheque_issued_general_type='IQI'  THEN  memc.state_name
         ELSE NULL END bankCity,
       me.passport_number,  --- Added in Insurance Certificate Cr
       me.emirate_id        --- Added in Insurance Certificate Cr
           
FROM tpa_enr_policy P
JOIN tpa_enr_policy_group TG  ON (P.policy_seq_id = TG.policy_seq_id)
JOIN tpa_enr_policy_member ME  ON (TG.policy_group_seq_id = ME.policy_group_seq_id)
JOIN tpa_general_code C ON (ME.gender_general_type_id =C.general_type_id)
LEFT OUTER JOIN  tpa_general_code J ON (ME.CATEGORY_GENERAL_TYPE_ID = J.general_type_id )
JOIN tpa_ins_info L ON (P.ins_seq_id = L.ins_seq_id)
JOIN TPA_INS_PRODUCT TIP ON (P.PRODUCT_SEQ_ID=TIP.PRODUCT_SEQ_ID)
LEFT OUTER JOIN tpa_group_registration M ON (TG.group_reg_seq_id = M.group_reg_seq_id)
JOIN tpa_enr_mem_address ad ON (tg.enr_address_seq_id = ad.enr_address_seq_id)
JOIN tpa_enr_mem_address mad ON (me.enr_address_seq_id = mad.enr_address_seq_id)
LEFT OUTER JOIN tpa_enr_balance mb ON (ME.policy_group_seq_id = mb.policy_group_seq_id)
JOIN tpa_general_code Q ON (P.policy_status_general_type_id = Q.general_type_id )
JOIN app.tpa_nationalities_code cc on (me.nationality_id=cc.nationality_id)
LEFT OUTER JOIN tpa_enr_bank_dtls corb on (p.bank_seq_id=corb.bank_seq_id)
LEFT OUTER JOIN tpa_enr_bank_dtls memb on (tg.bank_seq_id=memb.bank_seq_id)
LEFT OUTER JOIN tpa_state_code corc on (corb.state_type_id=corc.state_type_id) 
LEFT OUTER JOIN tpa_state_code memc on (memb.state_type_id=memc.state_type_id)
WHERE ME.MEMBER_SEQ_ID=P_MEMBER_SEQ_ID 
and  (ME.mem_general_type_id != 'PFL' AND ME.member_seq_id = mb.member_seq_id OR mb.member_seq_id IS NULL OR ME.member_seq_id IS NULL);

END SELECT_POLICY_DTL_PROC;

--===============================================================================================================

PROCEDURE SEARCH_POLICY_PROC(
P_POLICY_NUMBER     IN TPA_ENR_POLICY.POLICY_NUMBER%TYPE,
P_mobile_no         IN  TPA_ENR_MEM_ADDRESS.mobile_no%TYPE,
P_employee_no       IN  TPA_ENR_POLICY_GROUP.employee_no%TYPE,
P_insured_name      IN  TPA_ENR_POLICY_GROUP.insured_name%TYPE,
P_SORT_VAR          IN VARCHAR2,
P_SORT_ORDER        IN VARCHAR2,   --ASC/DESC                                 
P_START_NUM         IN NUMBER,
P_END_NUM           IN NUMBER, 
P_OUT_RESULT        OUT SYS_REFCURSOR
)  
IS
TYPE bind_tab_type IS TABLE OF VARCHAR2(250) INDEX BY BINARY_INTEGER ;
 bind_tab   bind_tab_type;
 i   NUMBER(2) := 0;
 v_type  VARCHAR2(20);
 V_STRING   VARCHAR2(5000);
 V_WHERE    VARCHAR2(5000):=NULL;
 

BEGIN
V_STRING:='SELECT me.TPA_ENROLLMENT_ID,me.MEM_NAME,ME.mem_age,RE.RELSHIP_DESCRIPTION,
 CASE WHEN ME.RELSHIP_TYPE_ID=''NSF'' THEN gr.employee_no ELSE NULL END AS employee_no,
TTK_UTIL_PKG.FN_DECRYPT(ad.MOBILE_NO) as MOBILE_NO,ME.MEMBER_SEQ_ID,EP.POLICY_NUMBER
 FROM app.tpa_enr_policy ep
               INNER JOIN app.tpa_enr_policy_group gr ON (gr.policy_seq_id=ep.policy_seq_id)
               INNER JOIN app.tpa_enr_policy_member me ON (me.policy_group_seq_id=gr.policy_group_seq_id)
               INNER JOIN app.tpa_enr_mem_address ad ON (ad.enr_address_seq_id=GR.enr_address_seq_id)
               INNER JOIN TPA_RELATIONSHIP_CODE RE ON (RE.RELSHIP_TYPE_ID=me.RELSHIP_TYPE_ID)';
  
  IF P_POLICY_NUMBER IS NOT NULL THEN
 V_WHERE:=  V_WHERE|| ' AND EP.POLICY_NUMBER=UPPER(:P_POLICY_NUMBER)';
i:=i+1;
bind_tab(i):=P_POLICY_NUMBER;
END IF;
 
 IF P_mobile_no IS NOT NULL THEN
  V_WHERE:=  V_WHERE|| ' AND intx.FN_MOB_DECRYPT(ad.MOBILE_NO)=:P_mobile_no';
 i:=i+1;
bind_tab(i):=P_mobile_no;
  END IF;
  
 IF P_employee_no IS NOT NULL THEN
  V_WHERE:=  V_WHERE|| ' AND gr.employee_no=:P_employee_no';
  i:=i+1;
bind_tab(i):=P_employee_no;
 END IF;
 
 IF P_insured_name IS NOT NULL THEN
 V_WHERE:=  V_WHERE|| ' AND GR.INSURED_NAME=:P_insured_name';
  i:=i+1;
bind_tab(i):=P_insured_name;
 END IF;
  
  IF V_WHERE IS NOT NULL THEN
 V_WHERE:=' WHERE '|| SUBSTR(V_WHERE,5) ;
 END IF;
 
 V_STRING :=V_STRING||V_WHERE;
 
 v_string:= ' SELECT * FROM (SELECT A.*,DENSE_RANK() OVER(ORDER BY '||P_SORT_VAR ||' '||P_SORT_ORDER||',ROWNUM) Q 
 FROM ('||v_string||') A) WHERE  Q>=  '||P_START_NUM||' AND Q<= '||P_END_NUM   ;
  

CASE bind_tab.COUNT
  WHEN 1 THEN OPEN P_OUT_RESULT FOR v_string USING bind_tab(1);
  WHEN 2 THEN OPEN P_OUT_RESULT FOR v_string USING bind_tab(1),bind_tab(2);
  WHEN 3 THEN OPEN P_OUT_RESULT FOR v_string USING bind_tab(1),bind_tab(2),bind_tab(3);
  WHEN 4 THEN OPEN P_OUT_RESULT FOR v_string USING bind_tab(1),bind_tab(2),bind_tab(3),bind_tab(4);
ELSE
  OPEN P_OUT_RESULT FOR v_string;
END CASE;
END SEARCH_POLICY_PROC;


--===============================================================================================================

PROCEDURE SEARCH_PREAUTH_PROC(
P_PRE_AUTH_NUMBER    IN PAT_ENROLL_DETAILS.PRE_AUTH_NUMBER%TYPE,
P_TPA_ENROLLMENT_ID  IN TPA_ENR_POLICY_MEMBER.TPA_ENROLLMENT_ID%TYPE,
P_MOBILE_NO         IN  TPA_ENR_MEM_ADDRESS.mobile_no%TYPE,
P_MEM_NAME          IN  TPA_ENR_POLICY_MEMBER.MEM_NAME%TYPE,
P_CORPORATE         IN TPA_GROUP_REGISTRATION.GROUP_NAME%TYPE, 
P_SORT_VAR          IN VARCHAR2,
P_SORT_ORDER        IN VARCHAR2,   --ASC/DESC                                 
P_START_NUM         IN NUMBER,
P_END_NUM           IN NUMBER,
P_employee_no       IN  TPA_ENR_POLICY_GROUP.employee_no%TYPE,
P_POLICY_NUMBER     IN TPA_ENR_POLICY.POLICY_NUMBER%TYPE,
P_FLAG              IN VARCHAR2,
P_EMIRATE_ID        IN TPA_ENR_POLICY_MEMBER.EMIRATE_ID%TYPE,
P_EMAIL             IN VARCHAR2,
P_OUT_RESULT        OUT SYS_REFCURSOR
)  
IS
TYPE BIND_TAB_TYPE IS TABLE OF VARCHAR2(500) INDEX BY BINARY_INTEGER ;
BIND_TAB    BIND_TAB_TYPE;
i number:=0;
V_STRING VARCHAR2(5000);
V_WHERE  VARCHAR2(3000);
V_SORT_VAR  VARCHAR2(100):='PAT_RECEIVED_DATE';
V_SORT_ORD  VARCHAR2(10):='DESC';

BEGIN
  
if P_TPA_ENROLLMENT_ID is not null or P_MOBILE_NO is not null OR P_MEM_NAME IS NOT NULL 
  OR P_PRE_AUTH_NUMBER IS NOT NULL OR P_CORPORATE IS NOT NULL OR P_POLICY_NUMBER IS NOT NULL
  OR P_employee_no IS NOT NULL OR P_EMIRATE_ID IS NOT NULL  OR P_EMAIL IS NOT NULL then
V_STRING:='WITH mobile_tb AS (select INTX.FN_MOB_DECRYPT(mobile_no)  mobile_no,ENR_ADDRESS_SEQ_ID,
 ttk_util_pkg.fn_decrypt(email_id) as email_id from tpa_enr_mem_address )
SELECT  PE.PRE_AUTH_NUMBER ,
ME.MEM_NAME ,
CASE WHEN PE.Pat_Status_Type_Id=''INP''  THEN ''In-Progress'' 
       WHEN PE.Pat_Status_Type_Id=''APR''  THEN ''Approved''
       WHEN PE.Pat_Status_Type_Id=''REJ'' THEN ''Rejected''
       WHEN PE.Pat_Status_Type_Id=''PCN'' THEN ''Cancelled''
       WHEN PE.Pat_Status_Type_Id=''REQ'' THEN ''Required Information''
       WHEN PE.Pat_Status_Type_Id=''PCO'' THEN ''Closed''
       WHEN PE.Pat_Status_Type_Id=''IPOL'' THEN ''Invalid Policy''  END AS STATUS,
CASE WHEN Pe.Pat_Status_Type_Id=''APR''  THEN TRIM(TO_CHAR(Pe.Final_App_Amount, ''999,999,9999,999,999'')) ELSE NULL END  AS  APPROVE_AMOUNT,
B.HOSP_NAME,
ME.TPA_ENROLLMENT_ID,
TO_CHAR(Pe.Hospitalization_Date,''DD/MM/YYYY HH:MI AM'') AS LIKELY_DATE_OF_HOSPITALIZATION,
Pe.Pat_Auth_Seq_Id as PAT_GEN_DETAIL_SEQ_ID,
intx.FN_MOB_DECRYPT(ad.MOBILE_NO) MOBILE_NO,
tg.GROUP_NAME
,TP.POLICY_SEQ_ID
,ROW_NUMBER() OVER (PARTITION BY PRE_AUTH_NUMBER ORDER BY PRE_AUTH_NUMBER DESC )  ROW_NUM
,TO_CHAR(PE.PAT_RECEIVED_DATE,''DD-MM-YYYY HH:MI AM'') AS DATE_OF_RECEIVED,
PE.PAT_RECEIVED_DATE,
ME.EMIRATE_ID QATAR_ID

FROM TPA_ENR_POLICY TP 
LEFT OUTER JOIN pat_authorization_details PE ON (TP.POLICY_SEQ_ID=PE.POLICY_SEQ_ID AND PE.PAT_ENHANCED_YN = ''N'')
JOIN TPA_ENR_POLICY_GROUP TPG ON (TPG.POLICY_SEQ_ID=TP.POLICY_SEQ_ID)
JOIN TPA_ENR_POLICY_MEMBER ME ON (ME.POLICY_GROUP_SEQ_ID=TPG.POLICY_GROUP_SEQ_ID AND ME.MEMBER_SEQ_ID=PE.MEMBER_SEQ_ID)
LEFT OUTER JOIN TPA_HOSP_INFO B ON (PE.HOSP_SEQ_ID=B.HOSP_SEQ_ID)
LEFT OUTER JOIN mobile_tb ad ON (ad.enr_address_seq_id=me.enr_address_seq_id)
LEFT OUTER JOIN  TPA_GROUP_REGISTRATION TG on (TG.GROUP_REG_SEQ_ID=tp.GROUP_REG_SEQ_ID)';

V_WHERE := V_WHERE||'AND PE.PRE_AUTH_NUMBER IS NOT NULL';
IF P_PRE_AUTH_NUMBER IS NOT NULL THEN
 V_WHERE:=  V_WHERE|| ' AND PE.PRE_AUTH_NUMBER=:P_PRE_AUTH_NUMBER';
i:=i+1;
bind_tab(i):=P_PRE_AUTH_NUMBER;
END IF;

IF P_TPA_ENROLLMENT_ID IS NOT NULL THEN
V_WHERE:=  V_WHERE|| ' AND tpg.POLICY_GROUP_SEQ_ID IN
                         (SELECT POLICY_GROUP_SEQ_ID 
                                 FROM TPA_ENR_POLICY_GROUP 
                                 WHERE TPA_ENROLLMENT_NUMBER=UPPER(:P_TPA_ENROLLMENT_ID))';
-- V_WHERE:=  V_WHERE|| ' AND ME.TPA_ENROLLMENT_ID=:P_TPA_ENROLLMENT_ID';
i:=i+1;
bind_tab(i):=P_TPA_ENROLLMENT_ID;
END IF;
 
 IF P_MOBILE_NO IS NOT NULL THEN
  V_WHERE:=  V_WHERE|| ' AND ad.MOBILE_NO = :P_MOBILE_NO';
 i:=i+1;
bind_tab(i):= P_MOBILE_NO;
  END IF;
  
IF P_MEM_NAME IS NOT NULL THEN
 V_WHERE:=  V_WHERE|| ' AND ME.MEM_NAME like :P_MEM_NAME';
  i:=i+1;
bind_tab(i):='%'||upper(P_MEM_NAME)||'%';
 END IF;

IF P_CORPORATE IS  NOT NULL THEN 
 V_WHERE:=  V_WHERE|| ' AND TG.GROUP_NAME like :P_CORPORATE';
  i:=i+1;
bind_tab(i):='%'||P_CORPORATE||'%';
 END IF;


IF P_employee_no IS NOT NULL THEN
  V_WHERE:=  V_WHERE|| ' AND tpg.employee_no=:P_employee_no';
  i:=i+1;
bind_tab(i):=P_employee_no;
 END IF;
 
  IF P_POLICY_NUMBER IS NOT NULL THEN
  V_WHERE:=  V_WHERE|| ' AND tP.POLICY_NUMBER=:P_POLICY_NUMBER';
 i:=i+1;
bind_tab(i):=P_POLICY_NUMBER;
  END IF;
  ------------ CR0218(SEARCH BY QATARID)---------------------- 
  IF P_EMIRATE_ID IS NOT NULL THEN
    V_WHERE:=  V_WHERE|| ' AND ME.EMIRATE_ID=:P_EMIRATE_ID';
    i:=i+1;
    bind_tab(i):=P_EMIRATE_ID;
  END IF;
  -------------------------------------------------------------
   IF P_EMAIL IS NOT NULL THEN
     V_WHERE:=  V_WHERE|| ' AND ad.email_id = :P_EMAIL';
     i:=i+1;
     bind_tab(i):= P_EMAIL;
  END IF;
  
IF V_WHERE IS NOT NULL THEN
 V_WHERE:=' WHERE '|| SUBSTR(V_WHERE,5) ;
 END IF;
 
 V_STRING :=V_STRING||V_WHERE;
 
 IF P_FLAG='Y' THEN 
 V_STRING:= ' SELECT * FROM (SELECT A.*,DENSE_RANK() OVER(ORDER BY '||V_SORT_VAR ||' '||V_SORT_ORD||',ROWNUM) Q 
 FROM ('||v_string||') A) WHERE ROW_NUM=1 AND  Q>=  '||P_START_NUM||' AND Q<= '||P_END_NUM ||' ORDER BY  PAT_RECEIVED_DATE DESC' ;
 ELSE
  V_STRING:= ' SELECT * FROM (SELECT A.*,DENSE_RANK() OVER(ORDER BY '||V_SORT_VAR ||' '||V_SORT_ORD||',ROWNUM) Q 
 FROM ('||v_string||') A) WHERE ROW_NUM=1 AND Q>=  '||P_START_NUM||' AND Q<= '||P_END_NUM || ' ORDER BY PAT_RECEIVED_DATE DESC';
  END IF;


 CASE bind_tab.COUNT
  WHEN 1 THEN OPEN P_OUT_RESULT FOR V_STRING USING bind_tab(1);
  WHEN 2 THEN OPEN P_OUT_RESULT FOR V_STRING USING bind_tab(1),bind_tab(2);
  WHEN 3 THEN OPEN P_OUT_RESULT FOR V_STRING USING bind_tab(1),bind_tab(2),bind_tab(3);
  WHEN 4 THEN OPEN P_OUT_RESULT FOR V_STRING USING bind_tab(1),bind_tab(2),bind_tab(3),bind_tab(4);
  WHEN 5 THEN OPEN P_OUT_RESULT FOR V_STRING USING bind_tab(1),bind_tab(2),bind_tab(3),bind_tab(4),bind_tab(5);
  WHEN 6 THEN OPEN P_OUT_RESULT FOR V_STRING USING bind_tab(1),bind_tab(2),bind_tab(3),bind_tab(4),bind_tab(5),bind_tab(6);
  WHEN 7 THEN OPEN P_OUT_RESULT FOR V_STRING USING bind_tab(1),bind_tab(2),bind_tab(3),bind_tab(4),bind_tab(5),bind_tab(6),bind_tab(7);
  WHEN 8 THEN OPEN P_OUT_RESULT FOR V_STRING USING bind_tab(1),bind_tab(2),bind_tab(3),bind_tab(4),bind_tab(5),bind_tab(6),bind_tab(7),bind_tab(8);
ELSE
  OPEN P_OUT_RESULT FOR V_STRING;
END CASE;
else
  OPEN P_OUT_RESULT FOR  
  SELECT 
       NULL AS PRE_AUTH_NUMBER ,
       NULL AS MEM_NAME ,
       NULL as STATUS,
       NULL AS APPROVE_AMOUNT,
       NULL AS HOSP_NAME,
       NULL  AS TPA_ENROLLMENT_ID,
       NULL AS LIKELY_DATE_OF_HOSPITALIZATION,
       NULL AS PAT_GEN_DETAIL_SEQ_ID,
       NULL AS MOBILE_NO,
       NULL AS GROUP_NAME,
       NULL AS POLICY_SEQ_ID,
        NULL AS ROW_NUM,
       NULL AS DATE_OF_RECEIVED,
       NULL AS PAT_RECEIVED_DATE,
       NULL AS QATAR_ID
  FROM DUAL;
end if;
END SEARCH_PREAUTH_PROC;

--===============================================================================================================

PROCEDURE SELECT_PREAUTH_DTL(
P_PAT_GENERAL_SEQ_ID  IN PAT_GENERAL_DETAILS.PAT_GEN_DETAIL_SEQ_ID%TYPE,
P_OUT_RESULT        OUT SYS_REFCURSOR
)
IS
BEGIN
OPEN P_OUT_RESULT FOR 

WITH 
SHORPFALL_DTL AS 
(SELECT COUNT(A.shortfall_seq_id) SHORT_FALL,Pe.Pat_Auth_Seq_Id FROM 
 TPA_ENR_POLICY_MEMBER EM  
 JOIN pat_authorization_details PE ON (EM.MEMBER_SEQ_ID=PE.MEMBER_SEQ_ID)
 LEFT OUTER JOIN shortfall_details A ON (A.PAT_GEN_DETAIL_SEQ_ID=Pe.Pat_Auth_Seq_Id)
 WHERE Pe.Pat_Auth_Seq_Id=P_PAT_GENERAL_SEQ_ID
 GROUP BY Pe.Pat_Auth_Seq_Id )

SELECT  C.Pre_Auth_Number,
        C.Mem_Name as Claimant_Name,
        b.TPA_ENROLLMENT_ID,
        N.Description as  preauth_type,
        TO_CHAR(c.pat_received_date,'DD/MM/YYYY HH:MI AM') AS rcvd_date,
        TO_CHAR(C.Hospitalization_Date,'DD/MM/YYYY HH:MI AM') ADMMISSION_DATE,
        to_char(c.discharge_date,'dd/mm/yyyy') AS probable_date_of_discharge,
        NVL(CASE WHEN NVL(c.network_yn,'N')='Y' THEN thp.contact_name||DECODE(thp.contact_name,NULL,thp.contact_name,'('||thp.professional_id||')') 
                ELSE n.clinician_name END,n.clinician_name) as Doctor_name,
        D.Hosp_Name,
        CASE WHEN NVL(c.process_type,'RGL') = 'RGL' THEN nvl(c.tot_disc_gross_amount,0)
                             ELSE nvl(c.converted_amount,0) END as pat_requested_amount,
        --J.description AS reason_status,
        c.presenting_complaints as ailment_description,
        I.Description as pat_status,
        C.AUTH_NUMBER,
        CASE WHEN NVL(c.process_type,'RGL') = 'RGL' THEN nvl(c.final_app_amount,0)
                             ELSE nvl(c.converted_final_approved_amt,0) END as AUTHORIZATION_AMT,
        D.office_fax_no AS FAX_NUMBER,
        D.off_phone_no_1 AS CONTACT_NO,
        CASE WHEN b.mem_age >= 60 THEN 'Y' ELSE 'N' end as senior_citizen_yn ,
        ---CASE WHEN B.Mem_General_Type_Id = 'PFL' THEN TRIM(TO_CHAR(A.floater_tot_bonus, '999,999,9999,999,999'))
              --WHEN B.Mem_General_Type_Id != 'PFL' THEN TRIM(TO_CHAR(B.mem_tot_bonus, '999,999,9999,999,999')) END AS Bonus,
        c.medical_opinion_remarks as AUTHORIZATION_REMARKS 
        --,UC.CONTACT_NAME AS AUTHORISED_BY
        --,TO_CHAR(H.COMPLETED_DATE,'DD/MM/YYYY HH:MI AM') AS AUTHORISED_DATE_TIME
        ,B.MEM_AGE
        ,c.tot_patient_share_amount
        --,NVL(E.FINAL_APP_YN,'N') AS FINAL_APPROVE
        ,EP.POLICY_NUMBER
        ,TTK_UTIL_PKG.FN_DECRYPT(D.PRIMARY_EMAIL_ID)AS HOSP_MAIL_ID
        --,D.GIPSA_PPNYN
        ,c.pat_auth_seq_id as PAT_GEN_DETAIL_SEQ_ID
        ,CASE WHEN Y.SHORT_FALL>0 THEN 'Y' ELSE 'N' END SHORTFALL_FLAG
        ,c.PAT_ENHANCED_YN,
        pp.prod_policy_seq_id,
         to_date(c.pat_received_date,'dd-mm-yyyy hh:mi am') as DECISION_DATE,
         (SELECT c.contact_name from tpa_user_contacts c where c.contact_seq_id=c.processed_by) as processed_by,
        genn.description as MODE_OF_PREAUTH,
        gen.description as BENEFIT_TYPE,
        CASE WHEN C.PAT_STATUS_TYPE_ID ='APR' AND C.COMPLETED_YN='Y' THEN 'Y' ELSE 'N' END APPROVED_YN,
        C.INTERNAL_REMARKS,
        C.OVERRIDE_REMARKS,
        (SELECT ca.contact_name from tpa_user_contacts ca where ca.contact_seq_id=h.assigned_to_user) as AssignedTo
        
         
FROM 
TPA_ENR_POLICY EP JOIN 
tpa_enr_policy_group A ON (EP.POLICY_SEQ_ID=A.POLICY_SEQ_ID)
JOIN tpa_enr_policy_member B  ON ( A.policy_group_seq_id = B.policy_group_seq_id )
          JOIN pat_authorization_details C ON ( B.member_seq_id = C.member_seq_id )
          JOIN tpa_hosp_info D ON ( D.hosp_seq_id = C.hosp_seq_id )
          JOIN tpa_general_code gen on (c.benifit_type=gen.general_type_id)
          JOIN tpa_general_code genn on (c.source_type_id=genn.general_type_id)
          --JOIN pat_general_details E ON ( E.pat_enroll_detail_seq_id = C.pat_enroll_detail_seq_id )
          --LEFT OUTER JOIN ailment_details F ON ( F.pat_gen_detail_seq_id = E.pat_gen_detail_seq_id )
          LEFT OUTER JOIN assign_users H ON ( c.assign_user_seq_id = H.assign_users_seq_id )
          LEFT OUTER JOIN tpa_general_code I ON ( C.Pat_Status_Type_Id = I.general_type_id )
          --LEFT OUTER JOIN tpa_general_code J ON ( H.rson_general_type_id = J.general_type_id )
          LEFT OUTER JOIN tpa_general_code N ON (c.process_type = N.general_type_id )
          --LEFT OUTER JOIN tpa_user_contacts UC ON (H.assigned_to_user = UC.contact_seq_id)
          LEFT OUTER JOIN SHORPFALL_DTL Y ON   (Y.Pat_Auth_Seq_Id=c.pat_auth_seq_id)
          LEFT OUTER JOIN pat_non_network_details n ON (c.pat_auth_seq_id=n.pat_auth_seq_id)
          LEFT OUTER JOIN tpa_hosp_professionals thp ON (c.clinician_id=thp.professional_id and thp.hosp_seq_id=d.hosp_seq_id)
          LEFT OUTER JOIN tpa_ins_prod_policy pp on(pp.policy_seq_id=c.policy_seq_id)
          WHERE c.Pat_Auth_Seq_Id=P_PAT_GENERAL_SEQ_ID  
          and C.PAT_ENHANCED_YN='N'   ------NEWLY ADDED FOR PAT ENHANCEMENT
          ;
END SELECT_PREAUTH_DTL;

--===============================================================================================================

PROCEDURE SEARCH_CLAIM_PROC(
P_CLAIM_NUMBER      IN CLM_GENERAL_DETAILS.CLAIM_NUMBER%TYPE,
P_TPA_ENROLLMENT_ID IN TPA_ENR_POLICY_MEMBER.TPA_ENROLLMENT_ID%TYPE,
P_MOBILE_NO         IN  TPA_ENR_MEM_ADDRESS.mobile_no%TYPE,
P_MEM_NAME          IN  TPA_ENR_POLICY_MEMBER.MEM_NAME%TYPE,
P_CORPORATE         IN TPA_GROUP_REGISTRATION.GROUP_NAME%TYPE, 
P_SORT_VAR          IN VARCHAR2,
P_SORT_ORDER        IN VARCHAR2,   --ASC/DESC                                 
P_START_NUM         IN NUMBER,
P_END_NUM           IN NUMBER, 
P_employee_no       IN  TPA_ENR_POLICY_GROUP.employee_no%TYPE,
P_POLICY_NUMBER     IN TPA_ENR_POLICY.POLICY_NUMBER%TYPE,
P_FLAG              IN VARCHAR2,
P_EMIRATE_ID        IN TPA_ENR_POLICY_MEMBER.EMIRATE_ID%TYPE,
P_EMAIL             IN VARCHAR2,
P_OUT_RESULT        OUT SYS_REFCURSOR
)
IS

TYPE BIND_TAB_TYPE IS TABLE OF VARCHAR2(500) INDEX BY BINARY_INTEGER ;
BIND_TAB    BIND_TAB_TYPE;
i number:=0;
V_STRING VARCHAR2(5000);
V_WHERE  VARCHAR2(3000);
V_SORT_VAR  VARCHAR2(100):='CLM_RECEIVED_DATE';
V_SORT_ORD  VARCHAR2(10):='DESC';
BEGIN
  
IF P_TPA_ENROLLMENT_ID IS NOT NULL OR P_MOBILE_NO IS NOT NULL OR P_MEM_NAME IS NOT NULL 
  OR P_CLAIM_NUMBER IS NOT NULL OR P_CORPORATE IS NOT NULL OR P_POLICY_NUMBER IS NOT NULL OR P_employee_no IS NOT NULL 
   OR P_EMIRATE_ID IS NOT NULL OR P_EMAIL IS NOT NULL  THEN
V_STRING:='
WITH mobile_tb AS (select intx.FN_MOB_DECRYPT(mobile_no)  mobile_no,ENR_ADDRESS_SEQ_ID,
ttk_util_pkg.fn_decrypt(email_id) as emial_id
 from tpa_enr_mem_address )
SELECT  CE.CLAIM_NUMBER ,
ME.MEM_NAME ,
CASE   WHEN CE.CLM_STATUS_TYPE_ID=''INP''  THEN ''In-Progress'' 
       WHEN CE.CLM_STATUS_TYPE_ID=''APR'' AND CE.COMPLETED_YN=''Y''  THEN ''Approved''
       WHEN CE.CLM_STATUS_TYPE_ID=''APR'' AND CE.COMPLETED_YN=''N''  THEN ''In-Progress''
       WHEN CE.CLM_STATUS_TYPE_ID=''REJ'' THEN ''Rejected''
       WHEN CE.CLM_STATUS_TYPE_ID=''PCN'' THEN ''Cancelled''
       WHEN CE.CLM_STATUS_TYPE_ID=''REQ'' THEN ''Required Information''
       WHEN CE.CLM_STATUS_TYPE_ID=''PCO'' THEN ''Closed''  END AS STATUS, 
CASE WHEN NVL(ce.process_type,''RGL'') = ''RGL'' THEN nvl(ce.final_app_amount,0)
             ELSE nvl(ce.converted_final_approved_amt,0) END  AS  APPROVE_AMOUNT,
NVL(HI.HOSP_NAME,Q.HOSP_NAME ) AS HOSP_NAME,
ME.TPA_ENROLLMENT_ID,
TO_CHAR(CE.DATE_OF_HOSPITALIZATION,''DD/MM/YYYY HH:MI AM'') AS DATE_OF_ADMISSION,
CE.CLAIM_SEQ_ID,
ad.MOBILE_NO,
tg.GROUP_NAME
,TP.POLICY_SEQ_ID
,TO_CHAR(CE.CLM_RECEIVED_DATE,''DD-MM-YYYY HH:MI AM'') as DATE_OF_RECEIVED,
CE.CLM_RECEIVED_DATE,
ME.EMIRATE_ID QATAR_ID

FROM 
tpa_enr_policy_group TPG 
JOIN tpa_enr_policy_member ME  ON (TPG.policy_group_seq_id = ME.policy_group_seq_id)
JOIN  clm_authorization_details CE ON (ME.member_seq_id = CE.member_seq_id)
LEFT OUTER JOIN  clm_hospital_details Q ON (CE.claim_seq_id = Q.claim_seq_id)
LEFT OUTER JOIN  tpa_general_code A ON(CE.CLM_STATUS_TYPE_ID = A.general_type_id)
INNER JOIN tpa_enr_policy TP ON (ce.Policy_Seq_Id=Tp.policy_seq_id)
LEFT OUTER JOIN mobile_tb ad ON (ad.enr_address_seq_id=me.enr_address_seq_id)
LEFT OUTER JOIN tpa_hosp_info HI ON (HI.hosp_seq_id = Q.hosp_seq_id)
LEFT OUTER JOIN  TPA_GROUP_REGISTRATION TG on (TG.GROUP_REG_SEQ_ID=TP.GROUP_REG_SEQ_ID)';

IF P_CLAIM_NUMBER IS NOT NULL THEN
 V_WHERE:=  V_WHERE|| ' AND CE.CLAIM_NUMBER=:P_CLAIM_NUMBER';
i:=i+1;
bind_tab(i):=P_CLAIM_NUMBER;
END IF;

IF P_TPA_ENROLLMENT_ID IS NOT NULL THEN
V_WHERE:=  V_WHERE|| ' AND tpg.POLICY_GROUP_SEQ_ID IN
                       (SELECT POLICY_GROUP_SEQ_ID 
                             FROM TPA_ENR_POLICY_GROUP 
                             WHERE TPA_ENROLLMENT_NUMBER=UPPER(:P_TPA_ENROLLMENT_ID))';
-- V_WHERE:=  V_WHERE|| ' AND ME.TPA_ENROLLMENT_ID=:P_TPA_ENROLLMENT_ID';
i:=i+1;
bind_tab(i):=P_TPA_ENROLLMENT_ID;
END IF;
 
 IF P_MOBILE_NO IS NOT NULL THEN
  V_WHERE:=  V_WHERE|| ' AND ad.MOBILE_NO = :P_MOBILE_NO';
 i:=i+1;
bind_tab(i):= P_MOBILE_NO;
  END IF;
  
IF P_MEM_NAME IS NOT NULL THEN
 V_WHERE:=  V_WHERE|| ' AND ME.MEM_NAME like :P_MEM_NAME';
  i:=i+1;
bind_tab(i):= '%'||upper(P_MEM_NAME)||'%';
 END IF;

IF P_CORPORATE IS  NOT NULL THEN 
 V_WHERE:=  V_WHERE|| ' AND TG.GROUP_NAME like :P_CORPORATE';
  i:=i+1;
bind_tab(i):='%'||P_CORPORATE||'%';
 END IF;

 IF P_employee_no IS NOT NULL THEN
  V_WHERE:=  V_WHERE|| ' AND TPG.employee_no=:P_employee_no';
  i:=i+1;
bind_tab(i):=P_employee_no;
 END IF;

 IF P_POLICY_NUMBER IS NOT NULL THEN
  V_WHERE:=  V_WHERE|| ' AND TP.POLICY_NUMBER=:P_POLICY_NUMBER';
 i:=i+1;
bind_tab(i):=P_POLICY_NUMBER;
  END IF;
  ------------ CR0218(SEARCH BY QATARID)---------------------- 
  IF P_EMIRATE_ID IS NOT NULL THEN
    V_WHERE:=  V_WHERE|| ' AND ME.EMIRATE_ID=:P_EMIRATE_ID';
    i:=i+1;
    bind_tab(i):=P_EMIRATE_ID;
  END IF;
  -------------------------------------------------------------
  
  IF P_EMAIL IS NOT NULL THEN
   V_WHERE:=  V_WHERE|| ' AND ad.EMIAL_ID =:P_EMAIL';
   i:=i+1; 
   bind_tab(i):= P_EMAIL;
  END IF;
  
IF V_WHERE IS NOT NULL THEN
 V_WHERE:=' WHERE '|| SUBSTR(V_WHERE,5) ;
 END IF;
 
 V_STRING :=V_STRING||V_WHERE;
 
 IF P_FLAG ='Y' THEN 
 V_STRING:= ' SELECT * FROM (SELECT A.*,DENSE_RANK() OVER(ORDER BY '||V_SORT_VAR ||' '||V_SORT_ORD||',ROWNUM) Q 
 FROM ('||v_string||') A) WHERE  Q>=  '||P_START_NUM||' AND Q<= '||P_END_NUM || ' ORDER BY CLM_RECEIVED_DATE DESC' ;
 ELSE
  V_STRING:= ' SELECT * FROM (SELECT A.*,DENSE_RANK() OVER(ORDER BY '||V_SORT_VAR ||' '||V_SORT_ORD||',ROWNUM) Q 
 FROM ('||v_string||') A) WHERE  Q>=  '||P_START_NUM||' AND Q<= '||P_END_NUM || ' ORDER BY CLM_RECEIVED_DATE DESC' ;
 END IF;

 CASE bind_tab.COUNT
  WHEN 1 THEN OPEN P_OUT_RESULT FOR V_STRING USING bind_tab(1);
  WHEN 2 THEN OPEN P_OUT_RESULT FOR V_STRING USING bind_tab(1),bind_tab(2);
  WHEN 3 THEN OPEN P_OUT_RESULT FOR V_STRING USING bind_tab(1),bind_tab(2),bind_tab(3);
  WHEN 4 THEN OPEN P_OUT_RESULT FOR V_STRING USING bind_tab(1),bind_tab(2),bind_tab(3),bind_tab(4);
  WHEN 5 THEN OPEN P_OUT_RESULT FOR V_STRING USING bind_tab(1),bind_tab(2),bind_tab(3),bind_tab(4),bind_tab(5);
  WHEN 6 THEN OPEN P_OUT_RESULT FOR V_STRING USING bind_tab(1),bind_tab(2),bind_tab(3),bind_tab(4),bind_tab(5),bind_tab(6);
  WHEN 7 THEN OPEN P_OUT_RESULT FOR V_STRING USING bind_tab(1),bind_tab(2),bind_tab(3),bind_tab(4),bind_tab(5),bind_tab(6),bind_tab(7);
  WHEN 8 THEN OPEN P_OUT_RESULT FOR V_STRING USING bind_tab(1),bind_tab(2),bind_tab(3),bind_tab(4),bind_tab(5),bind_tab(6),bind_tab(7),bind_tab(8);
ELSE
  OPEN P_OUT_RESULT FOR V_STRING;
END CASE;
ELSE
  OPEN P_OUT_RESULT FOR
  SELECT 
       NULL AS CLAIM_NUMBER ,
       NULL AS MEM_NAME ,
       NULL AS STATUS, 
       NULL AS APPROVE_AMOUNT,
       NULL AS HOSP_NAME,
       NULL AS TPA_ENROLLMENT_ID,
       NULL AS DATE_OF_ADMISSION,
       NULL AS CLAIM_SEQ_ID,
       NULL AS MOBILE_NO,
       NULL AS GROUP_NAME,
       NULL AS POLICY_SEQ_ID,
       NULL AS DATE_OF_RECEIVED,
       NULL AS CLM_RECEIVED_DATE,
       NULL AS QATAR_ID
       FROM DUAL;
END IF;


END SEARCH_CLAIM_PROC;


--===============================================================================================================

PROCEDURE SELECT_CLAIM_DTL(
P_CLAIM_SEQ_ID IN CLM_GENERAL_DETAILS.CLAIM_SEQ_ID%TYPE,
P_OUT_RESULT        OUT SYS_REFCURSOR
)
IS

BEGIN



OPEN P_OUT_RESULT FOR 
WITH SHORTFALL_DTL AS
(SELECT COUNT(A.shortfall_seq_id) SHORT_FALL,A.claim_seq_id
  FROM shortfall_details A 
 WHERE A.claim_seq_id =P_CLAIM_SEQ_ID 
 GROUP BY A.claim_seq_id
 ),
 
CHECK_DTL AS 
 (select  ttk_util_pkg.fn_decrypt(V.payee_name) payee_name,
          X.check_num,
          TRIM(TO_CHAR(X.check_amount,'999,999,9999,999,999'))as check_amount,
          TRIM(TO_CHAR((td.approved_amount - td.check_amount), '999,999,9999,999,999')) AS tds_amount,
          v.claim_payment_status AS cheque_status,
          TO_CHAR(X.check_date,'DD/MM/YYYY') AS check_date,   
          X.CONSIGNMENT_NO,
          X.PROVIDER_NAME ,
          TO_CHAR(x.despatch_date,'DD/MM/YYYY HH:MI AM') AS despatch_date,
          x.CHECK_STATUS,
          CG.CLAIM_SEQ_ID
     FROM clm_authorization_details cg
      LEFT OUTER JOIN tpa_claims_payment V ON (V.claim_seq_id = CG.claim_seq_id)
      LEFT OUTER JOIN tpa_payment_checks_details W ON (W.payment_seq_id = V.payment_seq_id)
      LEFT OUTER JOIN tpa_claims_check X ON (X.claims_chk_seq_id = W.claims_chk_seq_id)
      LEFT OUTER JOIN tpa_general_code Z ON (X.check_status = Z.general_type_id)
      LEFT OUTER JOIN tpa_clm_tds_details td ON (td.claim_seq_id=CG.claim_seq_id)
    WHERE cg.claim_seq_id =P_CLAIM_SEQ_ID  AND x.CHECK_STATUS='CSI'
    )

select Cl.Claim_Number,
        --Cg.Claim_File_Number,
        EM.TPA_ENROLLMENT_ID,
        Cl.mem_name as Claimant_Name,
        TO_CHAR(CI.Received_Date,'DD/MM/YYYY HH:MI AM') AS rcvd_date,
        TRIM(TO_CHAR(Cl.requested_amount, '999,999,9999,999,999')) as requested_amount,
        e.Description AS CLAIM_TYPE,
        NVL(TH.HOSP_NAME,CH.HOSP_NAME) AS HOSP_NAME,
        d.address_1||''||d.address_2||''||d.address_3||' '||TC.city_description||' '||TS.STATE_NAME||'-'||d.pin_code AS address,
        th.EMPANEL_NUMBER,
        TO_CHAR(cl.date_of_hospitalization,'DD/MM/YYYY HH:MI AM') AS admission_date,
        TO_CHAR(cl.date_of_discharge,'DD/MM/YYYY HH:MI AM') AS discharge_date,
        A.Description as clm_status,
        --C.Description as denial_reason,
        Cl.settlement_number as Claim_Settlement_Number,
        --CASE WHEN em.Mem_General_Type_Id = 'PFL' THEN TRIM(TO_CHAR(tpg.floater_tot_bonus, '999,999,9999,999,999'))
        --WHEN em.Mem_General_Type_Id != 'PFL' THEN TRIM(TO_CHAR(em.mem_tot_bonus, '999,999,9999,999,999')) END AS Bonus,
        cl.presenting_complaints as Ailment_Description,
        nvl(th.office_fax_no,ch.office_fax_no) fax_no,
        nvl(th.off_phone_no_1,ch.off_phone_no_1) as phone_num,
        case when em.mem_age >= 60 then 'Y' else 'N' end as senior_citizen_yn,
        t.Description MODE_OF_CLAIM,
        CASE WHEN cl.Completed_Yn='N' THEN NULL  ELSE cl.FINAL_REMARKS end as remarks,
        --cl.FINAL_REMARKS as remarks,
        cl.claim_seq_id,
        CASE WHEN NVL(cl.process_type,'RGL') = 'RGL' THEN nvl(cl.final_app_amount,0)
         ELSE nvl(cl.converted_final_approved_amt,0) END  AS   approved_amount,
        X.payee_name ,
        X.check_num,
        X.check_amount,
        X.tds_amount,
        X.cheque_status,
        X.check_date,   
        X.CONSIGNMENT_NO,
        X.PROVIDER_NAME ,
        X.despatch_date,
        CASE WHEN cL.clm_status_type_id = 'REJ' THEN 'Y' ELSE 'N' END REJECTION_FLAG,
        CASE WHEN Y.SHORT_FALL>0 THEN 'Y' ELSE 'N' END SHORTFALL_FLAG,
        --,TO_CHAR(INV.INVESTIGATED_DATE,'DD/MM/YYYY HH:MI AM') as INVESTIGATED_DATE
        --,INV.INVESTIGATED_BY
        --,X.Description AS INVESTIGATION_STATUS
        EP.POLICY_NUMBER
        ,TO_CHAR((CASE WHEN CI.SOURCE_TYPE_ID='CCR' THEN CI.RECEIVED_DATE ELSE NULL END),'DD/MM/YYYY HH:MI AM') AS COURIER_RCVD_DATE
        ,CL.TOT_PATIENT_SHARE_AMOUNT
        --, TO_CHAR((CASE WHEN CG.COMPLETED_YN='Y' THEN B.COMPLETED_DATE END),'DD/MM/YYYY HH:MI AM') COMPLETED_DATE
        ,CASE WHEN CL.CLM_STATUS_TYPE_ID ='APR' AND cl.COMPLETED_YN='Y' THEN 'Y' ELSE 'N' END COMPLETED_YN,
        to_char(cl.decision_date,'dd-mm-yyyy hh:mi am') as DECISION_DATE,
    (SELECT c.contact_name from tpa_user_contacts c where c.contact_seq_id=cl.processed_by) as processed_by,
     gen.description as Benefit_type,
     genn.description as MODE_OF_CLAIM,
     PP.PROD_POLICY_SEQ_ID,
     prc.description as submission_type,
     CL.INTERNAL_REMARKS,
     CL.OVERRIDE_REMARKS,
     (SELECT c.contact_name from tpa_user_contacts c where c.contact_seq_id=b.assigned_to_user) as AssignedTo
      
 from tpa_enr_policy_group TPG 
    JOIN tpa_enr_policy_member EM  ON (TPG.policy_group_seq_id = EM.policy_group_seq_id)
    JOIN  clm_authorization_details cl ON (EM.member_seq_id = CL.member_seq_id)
    JOIN tpa_general_code gen ON (cl.benifit_type=gen.general_type_id)
    --JOIN  clm_general_details CG ON (CG.claim_seq_id = CL.claim_seq_id)
    LEFT OUTER JOIN  clm_hospital_details CH ON (CL.claim_seq_id = CH.claim_seq_id)
    LEFT OUTER JOIN  tpa_general_code A ON(CL.CLM_STATUS_TYPE_ID = A.general_type_id)
    LEFT OUTER JOIN clm_batch_upload_details ci   on (ci.clm_batch_seq_id = cl.clm_batch_seq_id)
    LEFT OUTER JOIN tpa_general_code genn ON (gen.general_type_id=ci.source_type_id)
    LEFT OUTER JOIN assign_users B ON (Cl.Assign_User_Seq_Id = B.assign_users_seq_id)
    --LEFT OUTER JOIN tpa_general_code C ON (B.rson_general_type_id = C.general_type_id)
    LEFT OUTER JOIN tpa_hosp_info TH ON (TH.hosp_seq_id = CH.hosp_seq_id)
    LEFT OUTER JOIN tpa_hosp_address D ON ( d.hosp_seq_id = th.hosp_seq_id)
    LEFT OUTER JOIN tpa_city_code TC ON ( D.city_type_id = TC.city_type_id)
    LEFT OUTER join tpa_state_code TS ON (D.STATE_TYPE_ID=TS.STATE_TYPE_ID )
    left JOIN tpa_general_code E ON (CI.Clm_Type_Gen_Type_Id = E.general_type_id)
    LEFT OUTER JOIN tpa_general_code t ON (CI.Source_Type_Id = t.general_type_id)
    --LEFT OUTER JOIN ailment_details Y ON (CG.claim_seq_id = Y.claim_seq_id)
    left outer join CHECK_DTL X on (x.CLAIM_SEQ_ID=cl.CLAIM_SEQ_ID)
    INNER JOIN tpa_enr_policy ep ON (TPG.Policy_Seq_Id=ep.policy_seq_id)
    --LEFT OUTER JOIN REJECTION_DTL X ON (X.CLAIM_SEQ_ID=CG.CLAIM_SEQ_ID)
    LEFT OUTER JOIN SHORTFALL_DTL Y ON (Y.CLAIM_SEQ_ID=Cl.CLAIM_SEQ_ID)
    --LEFT OUTER JOIN investigation_details INV ON(INV.CLAIM_SEQ_ID=CG.CLAIM_SEQ_ID)
    --LEFT OUTER JOIN tpa_general_code X ON (X.general_type_id=INV.INVST_STATUS_GENERAL_TYPE_ID)
    LEFT OUTER JOIN TPA_INS_PROD_POLICY PP ON (PP.POLICY_SEQ_ID=CL.POLICY_SEQ_ID)
    join tpa_general_code prc on (cl.process_type=prc.general_type_id)
    where Cl.claim_seq_id=P_CLAIM_SEQ_ID;

END SELECT_CLAIM_DTL ;

--===============================================================================================================

PROCEDURE CLM_DISALLOWED_AMT_PROC(
P_CLAIM_SEQ_ID IN CLM_GENERAL_DETAILS.CLAIM_SEQ_ID%TYPE,
P_OUT_RESULT        OUT SYS_REFCURSOR
)
IS
BEGIN
OPEN P_OUT_RESULT FOR

SELECT 
Ce.CLAIM_NUMBER,
Ce.Settlement_Number as Claim_Settlement_Number,
EM.TPA_ENROLLMENT_ID,
--CBH.bill_no, 
--to_char(CBH.bill_date,'dd/mm/yyyy') AS bill_date, CBH.bill_issued_by,
--w.ward_description AS BILL_HEADER, 
TRIM(TO_CHAR(Ce.Requested_Amount, '999,999,9999,999,999')) as requested_amount,
CASE WHEN NVL(ce.process_type,'RGL') = 'RGL' THEN nvl(ce.final_app_amount,0)
         ELSE nvl(ce.converted_final_approved_amt,0) END as allowed_amount,
TRIM(TO_CHAR(Ce.Tot_Discount_Amount, '999,999,9999,999,999')) as rejected_amount
--,A.total_req_amt, 
--A.total_allow_amt,
--A.total_rej_amt,
/*CBD.remarks AS BILL_REMARKS_old,
CASE WHEN CLAIMS_PKG.FN_NONMED_EXPDTL(CBD.clm_bill_dtl_seq_id) IS NOT NULL 
THEN 'Non-medical expenses : '||CLAIMS_PKG.FN_NONMED_EXPDTL(CBD.clm_bill_dtl_seq_id) 
||CHR(13)||CBD.remarks ELSE CBD.remarks END AS BILL_REMARKS*/
FROM  APP.clm_authorization_details CE 
JOIN APP.tpa_enr_policy_member EM ON (CE.MEMBER_SEQ_ID=EM.MEMBER_SEQ_ID) 
--JOIN CLM_GENERAL_DETAILS CG ON (CE.Claim_seq_id=CG.Claim_seq_id)
--LEFT OUTER JOIN clm_bill_header CBH ON (CG.Claim_seq_id=CBH.Claim_seq_id)
--JOIN clm_bill_details CBD ON (CBH.clm_bill_seq_id = CBD.clm_bill_seq_id)
--JOIN tpa_hosp_ward_code W ON (CBD.ward_type_id = W.ward_type_id)
--JOIN totl_bill_amt A on (CBH.Claim_seq_id=A.Claim_seq_id)
WHERE ce.Claim_seq_id = P_CLAIM_SEQ_ID;

END CLM_DISALLOWED_AMT_PROC;

--===============================================================================================================
PROCEDURE SELECT_PREAUTHS_DTLS(
P_MEMBER_SEQ_ID  IN tpa_enr_policy_member.MEMBER_SEQ_ID%TYPE,
P_OUT_RESULT        OUT SYS_REFCURSOR
)
IS
v_sqlstr            VARCHAR2(10000);
v_sort_var          VARCHAR2(100):='PAT_RECEIVED_DATE';
v_sort_ord          VARCHAR2(10):='DESC';

BEGIN



IF P_MEMBER_SEQ_ID IS NOT NULL THEN 
  v_sqlstr:=' 
WITH SHORPFALL_DTL AS 
(SELECT COUNT(a.shortfall_seq_id) short_fall_cnt,pa.pat_auth_seq_id
  FROM tpa_enr_policy_member em  
  JOIN pat_authorization_details pa ON (em.member_seq_id=pa.member_seq_id)
  LEFT OUTER JOIN shortfall_details A ON (A.Pat_Gen_Detail_Seq_Id=pa.pat_auth_seq_id)
 WHERE pa.member_seq_id='''||p_member_seq_id||'''
 GROUP BY pa.pat_auth_seq_id)
 
 SELECT pa.pat_auth_seq_id as PAT_GEN_DETAIL_SEQ_ID,
       pa.pre_auth_number,
       m.tpa_enrollment_id,
       TO_CHAR(pa.pat_received_date,''DD/MM/YYYY HH:MI AM'') as RCVD_DATE,
       TO_CHAR(pa.hospitalization_date,''DD/MM/YYYY HH:MI AM'') as ADMMISSION_DATE,
       TO_CHAR(pa.discharge_date,''DD/MM/YYYY HH:MI AM'') as PROBABLE_DATE_OF_DISCHARGE,
       NVL(i.hosp_name,n.provider_name) AS HOSP_NAME,
       ttk_util_pkg.fn_decrypt(i.primary_email_id) AS hosp_mail_id,
       pa.presenting_complaints as AILMENT_DESCRIPTION,     
       st.description as PAT_STATUS,
       pa.auth_number,
       CASE WHEN m.mem_age >= 60 THEN ''Y'' ELSE ''N'' END AS senior_citizen_yn,
       pa.tot_patient_share_amount,
       ep.policy_number,
       pa.mem_name as CLAIMANT_NAME,
       m.mem_age,
       CASE WHEN NVL(pa.process_type,''RGL'') = ''RGL'' THEN ''Regular''
            ELSE ''Direct Billing'' END as PREAUTH_TYPE,
       NVL(CASE WHEN NVL(pa.network_yn,''N'')=''Y'' THEN thp.contact_name||DECODE(thp.contact_name,NULL,thp.contact_name,''(''||thp.professional_id||'')'') 
                ELSE n.clinician_name END,n.clinician_name) as DOCTOR_NAME,
       CASE WHEN NVL(pa.process_type,''RGL'') = ''RGL'' THEN nvl(pa.tot_disc_gross_amount,0)
                             ELSE nvl(pa.converted_amount,0) END as PAT_REQUESTED_AMOUNT,
       CASE WHEN NVL(pa.process_type,''RGL'') = ''RGL'' THEN nvl(pa.final_app_amount,0)
                             ELSE nvl(pa.converted_final_approved_amt,0) END as AUTHORIZATION_AMT,
       i.off_phone_no_1 AS contact_no,
       i.office_fax_no AS FAX_NUMBER,
       pa.medical_opinion_remarks as AUTHORIZATION_REMARKS,
       CASE WHEN sd.short_fall_cnt > 0 THEN ''Y'' ELSE ''N'' END SHORTFALL_FLAG,
       pa.pat_enhanced_yn,
       pp.prod_policy_seq_id,
       to_char(pa.pat_received_date,''dd-mm-yyyy hh:mi am'') as DECISION_DATE,
       (SELECT c.contact_name from tpa_user_contacts c where c.contact_seq_id=pa.processed_by) as processed_by,
       genn.description as MODE_OF_PREAUTH,
       gen.description as BENEFIT_TYPE,
       PA.PAT_RECEIVED_DATE,
       CASE WHEN pa.PAT_STATUS_TYPE_ID =''APR'' AND pa.COMPLETED_YN=''Y'' THEN ''Y'' ELSE ''N'' END APPROVED_YN,
        pa.INTERNAL_REMARKS,
        pa.OVERRIDE_REMARKS
         
  FROM tpa_enr_policy_member m
    JOIN pat_authorization_details pa ON (m.member_seq_id=pa.member_seq_id and pa.pat_enhanced_yn = ''N'')
    JOIN tpa_enr_policy ep ON (pa.policy_seq_id=ep.policy_seq_id)
    JOIN tpa_general_code gen ON (pa.benifit_type=gen.general_type_id)
    JOIN tpa_general_code genn on (genn.general_type_id=pa.source_type_id)
    LEFT OUTER JOIN tpa_hosp_info i ON (pa.hosp_seq_id=i.hosp_seq_id)
    LEFT OUTER JOIN pat_non_network_details n ON (pa.pat_auth_seq_id=n.pat_auth_seq_id)
    LEFT OUTER JOIN tpa_hosp_professionals thp ON (pa.clinician_id=thp.professional_id and thp.hosp_seq_id=i.hosp_seq_id)
    LEFT OUTER JOIN tpa_general_code st ON ( pa.pat_status_type_id = st.general_type_id )
    LEFT OUTER JOIN shorpfall_dtl sd ON (sd.pat_auth_seq_id = pa.pat_auth_seq_id)
   JOIN tpa_ins_prod_policy pp on(pp.policy_seq_id=pa.policy_seq_id)
  WHERE pa.pre_auth_number is not null and m.member_seq_id ='''||P_MEMBER_SEQ_ID||'''';


v_sqlstr := 'SELECT * FROM
                      (SELECT A.*,DENSE_RANK() OVER (ORDER BY '||v_sort_var||' '||v_sort_ord||',ROWNUM)
                       Q FROM (' ||v_sqlstr|| ') A )';   
END IF;

IF v_sqlstr IS NOT NULL THEN
  OPEN P_OUT_RESULT FOR v_sqlstr;
ELSE
  OPEN P_OUT_RESULT FOR 
      SELECT NULL as PAT_GEN_DETAIL_SEQ_ID,
       NULL AS pre_auth_number,
       NULL AS tpa_enrollment_id,
       NULL AS  RCVD_DATE,
       NULL AS ADMMISSION_DATE,
       NULL AS PROBABLE_DATE_OF_DISCHARGE,
       NULL AS HOSP_NAME,
       NULL AS hosp_mail_id,
       NULL AS AILMENT_DESCRIPTION,     
       NULL AS PAT_STATUS,
       NULL AS auth_number,
       NULL AS senior_citizen_yn,
       NULL AS tot_patient_share_amount,
       NULL AS policy_number,
       NULL AS CLAIMANT_NAME,
       NULL AS mem_age,
       NULL AS PREAUTH_TYPE,
       NULL AS DOCTOR_NAME,
       NULL AS PAT_REQUESTED_AMOUNT,
       NULL AS AUTHORIZATION_AMT,
       NULL AS contact_no,
       NULL AS FAX_NUMBER,
       NULL AS AUTHORIZATION_REMARKS,
       NULL AS SHORTFALL_FLAG,
       NULL AS pat_enhanced_yn,
       NULL AS prod_policy_seq_id,
       NULL AS DECISION_DATE,
       NULL AS processed_by,
       NULL AS MODE_OF_PREAUTH,
       NULL AS BENEFIT_TYPE,
       NULL AS PAT_RECEIVED_DATE,
       NULL AS APPROVED_YN,
       NULL AS INTERNAL_REMARKS,
       NULL AS OVERRIDE_REMARKS
  FROM DUAL;
END IF;                       
                     

END SELECT_PREAUTHS_DTLS;
--===============================================================================================================
PROCEDURE SELECT_CLAIMS_DTLS(
P_MEMBER_SEQ_ID  IN tpa_enr_policy_member.MEMBER_SEQ_ID%TYPE,
P_OUT_RESULT        OUT SYS_REFCURSOR
)
IS

v_sqlstr            VARCHAR2(10000);
v_sort_var          VARCHAR2(100):='CLM_RECEIVED_DATE';
v_sort_ord          VARCHAR2(10):='DESC';


BEGIN

IF P_MEMBER_SEQ_ID IS NOT NULL THEN
v_sqlstr:=' WITH CHECK_DTL AS 
            (SELECT 
              ttk_util_pkg.fn_decrypt(V.payee_name) payee_name,X.check_num,TRIM(TO_CHAR(X.check_amount,''999,999,9999,999,999''))as check_amount,
              TRIM(TO_CHAR((td.approved_amount - td.check_amount), ''999,999,9999,999,999'')) AS tds_amount,
              v.claim_payment_status AS cheque_status,TO_CHAR(X.check_date,''DD/MM/YYYY'') AS check_date,X.CONSIGNMENT_NO,
              X.PROVIDER_NAME ,TO_CHAR(x.despatch_date,''DD/MM/YYYY HH:MI AM'') AS despatch_date,x.CHECK_STATUS,ca.CLAIM_SEQ_ID
             FROM clm_authorization_details ca
             LEFT OUTER JOIN tpa_claims_payment V ON (V.claim_seq_id = ca.claim_seq_id)
             LEFT OUTER JOIN tpa_payment_checks_details W ON (W.payment_seq_id = V.payment_seq_id)
             LEFT OUTER JOIN tpa_claims_check X ON (X.claims_chk_seq_id = W.claims_chk_seq_id)
             LEFT OUTER JOIN tpa_general_code Z ON (X.check_status = Z.general_type_id)
             LEFT OUTER JOIN tpa_clm_tds_details td ON (td.claim_seq_id=ca.claim_seq_id)
            WHERE ca.member_seq_id='''||P_MEMBER_SEQ_ID ||''' AND x.CHECK_STATUS=''CSI''
            )
            ,
            SHORPFALL_DTL AS
            (SELECT COUNT(A.shortfall_seq_id) SHORT_FALL,ce.CLAIM_SEQ_ID FROM 
             TPA_ENR_POLICY_MEMBER EM  
             JOIN clm_authorization_details CE ON (EM.MEMBER_SEQ_ID=CE.MEMBER_SEQ_ID)
             LEFT OUTER JOIN shortfall_details A ON (A.CLAIM_SEQ_ID=ce.CLAIM_SEQ_ID)
            WHERE CE.MEMBER_SEQ_ID='''||P_MEMBER_SEQ_ID||'''
            GROUP BY CE.CLAIM_SEQ_ID
            )
             
            SELECT  DISTINCT ce.claim_number,
                  EM.TPA_ENROLLMENT_ID,
                  ce.mem_name as Claimant_Name,
                  TO_CHAR(cb.received_date,''DD/MM/YYYY HH:MI AM'') AS rcvd_date,
                  TRIM(TO_CHAR(ce.requested_amount, ''999,999,9999,999,999'')) as requested_amount,
                  CASE WHEN NVL(ce.process_type,''RGL'') = ''RGL'' THEN ''Regular''
                       ELSE ''Direct Billing'' END AS submission_type,
                  NVL(TH.HOSP_NAME,CH.HOSP_NAME) AS HOSP_NAME,
                  d.address_1||''''||d.address_2||''''||d.address_3||'' ''||TC.city_description||'' ''||TS.STATE_NAME||''-''||d.pin_code AS address,
                  th.EMPANEL_NUMBER,
                  TO_CHAR(ce.date_of_hospitalization,''DD/MM/YYYY HH:MI AM'') AS admission_date,
                  TO_CHAR(ce.date_of_discharge,''DD/MM/YYYY HH:MI AM'') AS discharge_date,
                  A.Description as clm_status,
                  ce.settlement_number as Claim_Settlement_Number,
                  ce.presenting_complaints as Ailment_Description,
                  nvl(th.office_fax_no,ch.office_fax_no) fax_no,
                  nvl(th.off_phone_no_1,ch.off_phone_no_1) as phone_num,
                  case when em.mem_age >= 60 then ''Y'' else ''N'' end as senior_citizen_yn,
                  t.Description MODE_OF_CLAIM,
                  ce.claim_seq_id,
                  CASE WHEN NVL(ce.process_type,''RGL'') = ''RGL'' THEN nvl(ce.final_app_amount,0)
                       ELSE nvl(ce.converted_final_approved_amt,0) END  AS approved_amount,
                  Z.payee_name,
                  Z.check_num,
                  Z.check_amount,
                  Z.tds_amount,
                  Z.cheque_status,
                  Z.check_date  ,
                  Z.CONSIGNMENT_NO,
                  Z.PROVIDER_NAME ,
                  Z.despatch_date,
                  CASE WHEN Y.SHORT_FALL>0 THEN ''Y'' ELSE ''N'' END SHORTFALL_FLAG
                  ,EP.POLICY_NUMBER
                  ,ce.tot_patient_share_amount
                  ,CASE WHEN ce.clm_status_type_id =''APR'' THEN ''Y'' ELSE ''N'' END COMPLETED_YN
                  ,CASE WHEN ce.clm_status_type_id = ''REJ'' THEN ''Y'' ELSE ''N'' END as REJECTION_FLAG,
                  to_char(ce.decision_date,''dd-mm-yyyy hh:mi am'') as DECISION_DATE,
                  (SELECT c.contact_name from tpa_user_contacts c where c.contact_seq_id=ce.processed_by) as processed_by,
                  gen.description as BENEFIT_TYPE,
                  PP.PROD_POLICY_SEQ_ID,
                   PRC.DESCRIPTION AS CLAIM_TYPE,
                   cb.received_date,
                   ce.CLM_RECEIVED_DATE,
                   Ce.INTERNAL_REMARKS,
                   Ce.OVERRIDE_REMARKS
                  --genn.description as MODE_OF_CLAIM
                       
            FROM tpa_enr_policy_group TPG 
            JOIN tpa_enr_policy_member EM  ON (TPG.policy_group_seq_id = EM.policy_group_seq_id)
            JOIN  clm_authorization_details ce ON (EM.member_seq_id = ce.member_seq_id)
            JOIN tpa_general_code gen ON (gen.general_type_id=ce.benifit_type)
            LEFT OUTER JOIN clm_batch_upload_details cb   on (cb.clm_batch_seq_id = ce.clm_batch_seq_id)
            LEFT OUTER JOIN tpa_general_code genn ON (genn.general_type_id=cb.source_type_id)
            LEFT OUTER JOIN  clm_hospital_details CH ON (ce.claim_seq_id = CH.claim_seq_id)
            LEFT OUTER JOIN  tpa_general_code A ON(ce.clm_status_type_id = a.general_type_id)
            LEFT OUTER JOIN tpa_hosp_info TH ON (TH.hosp_seq_id = CH.hosp_seq_id)
            LEFT OUTER JOIN tpa_hosp_address D ON ( d.hosp_seq_id = th.hosp_seq_id)
            LEFT OUTER JOIN tpa_city_code TC ON ( D.city_type_id = TC.city_type_id)
            LEFT OUTER join tpa_state_code TS ON (D.STATE_TYPE_ID=TS.STATE_TYPE_ID )
            INNER JOIN tpa_enr_policy ep ON (TPG.Policy_Seq_Id=ep.policy_seq_id)
            LEFT OUTER JOIN tpa_general_code t ON (cb.source_type_id = t.general_type_id)
            LEFT OUTER JOIN CHECK_DTL Z ON (Z.CLAIM_SEQ_ID=ce.CLAIM_SEQ_ID)
            LEFT OUTER JOIN SHORPFALL_DTL Y ON   (Y.CLAIM_SEQ_ID=ce.CLAIM_SEQ_ID)
            LEFT OUTER JOIN TPA_INS_PROD_POLICY PP ON (PP.POLICY_SEQ_ID=CE.POLICY_SEQ_ID)
            JOIN TPA_GENERAL_CODE PRC ON (PRC.GENERAL_TYPE_ID=CE.CLAIM_TYPE)
            WHERE EM.MEMBER_SEQ_ID='''||P_MEMBER_SEQ_ID||'''';

 v_sqlstr := 'SELECT * FROM
                      (SELECT A.*,DENSE_RANK() OVER (ORDER BY '||v_sort_var||' '||v_sort_ord||',ROWNUM)
                       Q FROM (' ||v_sqlstr|| ') A )';   
 END IF;                      
                       
IF  v_sqlstr IS NOT NULL THEN                
OPEN P_OUT_RESULT FOR v_sqlstr;                       
ELSE
  OPEN P_OUT_RESULT FOR 
  SELECT  NULL AS claim_number,
        NULL AS TPA_ENROLLMENT_ID,
        NULL AS Claimant_Name,
        NULL AS rcvd_date,
        NULL AS requested_amount,
        NULL AS submission_type,
        NULL AS HOSP_NAME,
        NULL AS address,    
        NULL AS EMPANEL_NUMBER,
        NULL AS admission_date,
        NULL AS discharge_date,
        NULL AS clm_status,
        NULL AS Claim_Settlement_Number,
        NULL AS Ailment_Description,
        NULL AS fax_no,
        NULL AS  phone_num,
        NULL AS senior_citizen_yn,
        NULL AS MODE_OF_CLAIM,
        NULL AS claim_seq_id,
        NULL AS approved_amount,
        NULL AS payee_name,
        NULL AS check_num,
        NULL AS check_amount,
        NULL AS tds_amount,
        NULL AS cheque_status,
        NULL AS check_date  ,
        NULL AS CONSIGNMENT_NO,
        NULL AS PROVIDER_NAME ,
        NULL AS despatch_date,
        NULL AS SHORTFALL_FLAG,
        NULL AS POLICY_NUMBER,
        NULL AS tot_patient_share_amount,
        NULL AS COMPLETED_YN,
        NULL AS REJECTION_FLAG,
        NULL AS DECISION_DATE,
        NULL AS Processed_by,
        NULL AS BENEFIT_TYPE,
        NULL AS PROD_POLICY_SEQ_ID,
        NULL AS CLAIM_TYPE,
        NULL AS received_date,
        NULL AS CLM_RECEIVED_DATE,
        NULL AS INTERNAL_REMARKS,
        NULL AS OVERRIDE_REMARKS FROM DUAL;
END IF;
END SELECT_CLAIMS_DTLS ;
--===============================================================================================================
PROCEDURE CLM_CHECK_DETAILS_PROC (
P_CLAIM_SEQ_ID IN CLM_GENERAL_DETAILS.CLAIM_SEQ_ID%TYPE,
P_OUT_RESULT        OUT SYS_REFCURSOR
)
IS
BEGIN
OPEN P_OUT_RESULT FOR 
select 
    ttk_util_pkg.fn_decrypt(V.payee_name) payee_name,
     X.check_num,
     X.check_amount,
     TRIM(TO_CHAR((td.approved_amount - td.check_amount), '999,999,9999,999,999')) AS tds_amount,
     Z.description AS cheque_status,
     TO_CHAR(X.check_date,'DD/MM/YYYY') AS check_date,   
      X.CONSIGNMENT_NO,
      X.PROVIDER_NAME ,
      TO_CHAR(x.despatch_date,'DD/MM/YYYY HH:MI AM') AS despatch_date
     FROM clm_authorization_details CL 
      --JOIN  clm_general_details CG ON (CG.claim_seq_id = CL.claim_seq_id)
      LEFT OUTER JOIN tpa_claims_payment V ON (V.claim_seq_id = cl.claim_seq_id)
      LEFT OUTER JOIN tpa_payment_checks_details W ON (W.payment_seq_id = V.payment_seq_id)
      LEFT OUTER JOIN tpa_claims_check X ON (X.claims_chk_seq_id = W.claims_chk_seq_id)
      LEFT OUTER JOIN tpa_general_code Z ON (X.check_status = Z.general_type_id)
      LEFT OUTER JOIN tpa_clm_tds_details td ON (td.claim_seq_id=cl.claim_seq_id)
 WHERE cl.CLAIM_SEQ_ID=P_CLAIM_SEQ_ID
 ORDER BY cl.claim_seq_id DESC;
 
END  CLM_CHECK_DETAILS_PROC;
--===============================================================================================================
PROCEDURE CLAIM_SHORTFALL_LIST(
P_CLAIM_SEQ_ID IN CLM_GENERAL_DETAILS.CLAIM_SEQ_ID%TYPE,
P_OUT_RESULT        OUT SYS_REFCURSOR
)
IS

BEGIN
OPEN P_OUT_RESULT FOR 
SELECT A.shortfall_seq_id,
           A.shortfall_id AS SHORTFALL_NO, 
           A.srtfll_general_type_id AS short_type,
          B.description AS shortfall_type,
          C.description AS status,
          TO_CHAR(A.srtfll_received_date,'DD/MM/YYYY HH:MI AM') Rreceived_date,
          TO_CHAR(A.srtfll_sent_date,'DD/MM/YYYY HH:MI AM')  sent_date,
          a.shortfall_raised_for as template_type,
         nvl(d.cigna_yn,'N') as cigna_yn--koc_ins_mail
         ,A.claim_seq_id
          FROM shortfall_details A LEFT OUTER JOIN tpa_general_code B ON (A.srtfll_general_type_id = B.general_type_id)
          LEFT OUTER JOIN tpa_general_code C ON (A.srtfll_status_general_type_id = C.general_type_id)
      LEFT OUTER JOIN app.shortfall_email_dtl d on (d.shortfall_seq_id=a.shortfall_seq_id)--koc_ins_mail
          WHERE A.claim_seq_id =P_CLAIM_SEQ_ID;
END CLAIM_SHORTFALL_LIST;
--===============================================================================================================
 PROCEDURE CLAIM_SHORTFALL_QUESTIONS(
P_SHORT_FALL_SEQ_ID       IN  shortfall_details.shortfall_seq_id%TYPE,
P_OUT_RESULT        OUT SYS_REFCURSOR
  )
  IS
BEGIN
OPEN P_OUT_RESULT FOR 
 SELECT  extract(A.shortfall_questions,'/').getclobval() AS questions
     FROM shortfall_details A
     WHERE A.shortfall_seq_id =P_SHORT_FALL_SEQ_ID;
     
  END CLAIM_SHORTFALL_QUESTIONS;


--===============================================================================================================
PROCEDURE RULE_DALA_XML_PARSING(
P_MEMBER_SEQ_ID  IN tpa_enr_policy_member.MEMBER_SEQ_ID%TYPE,
P_ENROL_TYPE_ID  TPA_ENR_POLICY.ENROL_TYPE_ID%TYPE
)
IS
CNT number;
V_exclusion_name clob;
V_allowence varchar2(10);
V_ALLOWENCE_DESCRIPTION varchar2(50);
V_COVERGARE_ID varchar2(50);

BEGIN
DELETE FROM APP.RULE_DATA_XML_PARSING;

IF P_ENROL_TYPE_ID='COR' THEN

SELECT 
REGEXP_COUNT(extract(e.PROD_POLICY_RULE,'/clauses/clause[@id="cls.23"]').getclobval(),'coverage')/2 INTO CNT
FROM TPA_ENR_POLICY A JOIN tpa_enr_policy_GROUP B ON(A.POLICY_SEQ_ID=B.POLICY_SEQ_ID)
JOIN  tpa_enr_policy_member C ON (C.POLICY_GROUP_SEQ_ID=B.POLICY_GROUP_SEQ_ID)
LEFT OUTER JOIN TPA_INS_PROD_POLICY d on (A.POLICY_SEQ_ID=d.POLICY_SEQ_ID)
LEFT OUTER JOIN TPA_INS_PROD_POLICY_RULES e on(d.PROD_POLICY_SEQ_ID=e.PROD_POLICY_SEQ_ID)
 WHERE 
C.Member_Seq_Id =P_MEMBER_SEQ_ID;
 
 
  FOR i IN 1..cnt
LOOP 
SELECT extract(e.PROD_POLICY_RULE,'/clauses/clause[@id="cls.23"]/coverage['||i||']/@name').getclobval() as V_exclusion_name ,
TO_CHAR(extract(e.PROD_POLICY_RULE,'/clauses/clause[@id="cls.23"]/coverage['||i||']/@allowed').getclobval())  as V_allowence
,CASE TO_CHAR(extract(e.PROD_POLICY_RULE,'/clauses/clause[@id="cls.23"]/coverage['||i||']/@allowed').getclobval()  )
WHEN '1' then 'PAY'
WHEN '2' then 'Don'||CHR(39)||'t Pay'
WHEN '3' then 'Pay Conditionally' END as V_ALLOWENCE_DESCRIPTION
,to_char(extract(e.PROD_POLICY_RULE,'/clauses/clause[@id="cls.23"]/coverage['||i||']/@id').getclobval()) as covergare_id
INTO V_exclusion_name,V_allowence,V_ALLOWENCE_DESCRIPTION,V_COVERGARE_ID
FROM TPA_ENR_POLICY A JOIN tpa_enr_policy_GROUP B ON(A.POLICY_SEQ_ID=B.POLICY_SEQ_ID)
JOIN  tpa_enr_policy_member C ON (C.POLICY_GROUP_SEQ_ID=B.POLICY_GROUP_SEQ_ID)
LEFT OUTER JOIN TPA_INS_PROD_POLICY d on (A.POLICY_SEQ_ID=d.POLICY_SEQ_ID)
LEFT OUTER JOIN TPA_INS_PROD_POLICY_RULES e on(d.PROD_POLICY_SEQ_ID=e.PROD_POLICY_SEQ_ID)
 WHERE 
C.Member_Seq_Id =P_MEMBER_SEQ_ID; 
 
INSERT INTO APP.RULE_DATA_XML_PARSING (EXCLUSION_NAME,ALLOWENCE,ALLOWENCE_DESCRIPTION,COVERGARE_ID)
VALUES(V_EXCLUSION_NAME,V_ALLOWENCE,V_ALLOWENCE_DESCRIPTION,V_COVERGARE_ID);
END LOOP;
 
 ELSE
 
SELECT 
REGEXP_COUNT(extract(e.PROD_POLICY_RULE,'/clauses/clause[@id="cls.23"]').getclobval(),'coverage')/2 INTO CNT 
FROM TPA_ENR_POLICY A JOIN tpa_enr_policy_GROUP B ON(A.POLICY_SEQ_ID=B.POLICY_SEQ_ID)
JOIN  tpa_enr_policy_member C ON (C.POLICY_GROUP_SEQ_ID=B.POLICY_GROUP_SEQ_ID)
LEFT OUTER JOIN TPA_INS_PROD_POLICY d on (A.PRODUCT_SEQ_ID=d.PRODUCT_SEQ_ID)
LEFT OUTER JOIN TPA_INS_PROD_POLICY_RULES e on(d.PROD_POLICY_SEQ_ID=e.PROD_POLICY_SEQ_ID)
 WHERE 
C.Member_Seq_Id =P_MEMBER_SEQ_ID
AND  E.VALID_FROM=(SELECT 
MAX( E.VALID_FROM)
FROM TPA_ENR_POLICY A JOIN tpa_enr_policy_GROUP B ON(A.POLICY_SEQ_ID=B.POLICY_SEQ_ID)
JOIN  tpa_enr_policy_member C ON (C.POLICY_GROUP_SEQ_ID=B.POLICY_GROUP_SEQ_ID)
LEFT OUTER JOIN TPA_INS_PROD_POLICY d on (A.PRODUCT_SEQ_ID=d.PRODUCT_SEQ_ID)
LEFT OUTER JOIN TPA_INS_PROD_POLICY_RULES e on(d.PROD_POLICY_SEQ_ID=e.PROD_POLICY_SEQ_ID)
WHERE 
C.Member_Seq_Id =P_MEMBER_SEQ_ID);
 
 FOR i IN 1..cnt
LOOP    

 SELECT extract(e.PROD_POLICY_RULE,'/clauses/clause[@id="cls.23"]/coverage['||i||']/@name').getclobval() as V_exclusion_name ,
TO_CHAR(extract(e.PROD_POLICY_RULE,'/clauses/clause[@id="cls.23"]/coverage['||i||']/@allowed').getclobval())  as V_allowence
,CASE TO_CHAR(extract(e.PROD_POLICY_RULE,'/clauses/clause[@id="cls.23"]/coverage['||i||']/@allowed').getclobval()  )
WHEN '1' then 'PAY'
WHEN '2' then 'Don'||CHR(39)||'t Pay'
WHEN '3' then 'Pay Conditionally' END as V_ALLOWENCE_DESCRIPTION
,to_char(extract(e.PROD_POLICY_RULE,'/clauses/clause[@id="cls.23"]/coverage['||i||']/@id').getclobval()) as covergare_id
INTO V_exclusion_name,V_allowence,V_ALLOWENCE_DESCRIPTION,V_COVERGARE_ID
FROM TPA_ENR_POLICY A JOIN tpa_enr_policy_GROUP B ON(A.POLICY_SEQ_ID=B.POLICY_SEQ_ID)
JOIN  tpa_enr_policy_member C ON (C.POLICY_GROUP_SEQ_ID=B.POLICY_GROUP_SEQ_ID)
LEFT OUTER JOIN TPA_INS_PROD_POLICY d on (A.PRODUCT_SEQ_ID=d.PRODUCT_SEQ_ID)
LEFT OUTER JOIN TPA_INS_PROD_POLICY_RULES e on(d.PROD_POLICY_SEQ_ID=e.PROD_POLICY_SEQ_ID)
 WHERE 
C.Member_Seq_Id =P_MEMBER_SEQ_ID
AND  E.VALID_FROM=(SELECT 
MAX( E.VALID_FROM)
FROM TPA_ENR_POLICY A JOIN tpa_enr_policy_GROUP B ON(A.POLICY_SEQ_ID=B.POLICY_SEQ_ID)
JOIN  tpa_enr_policy_member C ON (C.POLICY_GROUP_SEQ_ID=B.POLICY_GROUP_SEQ_ID)
LEFT OUTER JOIN TPA_INS_PROD_POLICY d on (A.PRODUCT_SEQ_ID=d.PRODUCT_SEQ_ID)
LEFT OUTER JOIN TPA_INS_PROD_POLICY_RULES e on(d.PROD_POLICY_SEQ_ID=e.PROD_POLICY_SEQ_ID)
WHERE 
C.Member_Seq_Id =P_MEMBER_SEQ_ID);

 INSERT INTO APP.RULE_DATA_XML_PARSING(EXCLUSION_NAME,ALLOWENCE ,ALLOWENCE_DESCRIPTION,COVERGARE_ID )
 VALUES(V_exclusion_name,V_allowence,V_ALLOWENCE_DESCRIPTION,V_COVERGARE_ID);
END LOOP;
END IF;
 
 
EXCEPTION 
WHEN NO_DATA_FOUND THEN     
NULL;
DELETE FROM APP.RULE_DATA_XML_PARSING;
 
WHEN OTHERS THEN     
NULL;
DELETE FROM APP.RULE_DATA_XML_PARSING;

END RULE_DALA_XML_PARSING; 
--===============================================================================================================

PROCEDURE INITIAL_PERIOD_EXCL_DTL_PROC(
P_MEMBER_SEQ_ID  IN tpa_enr_policy_member.MEMBER_SEQ_ID%TYPE,
P_ENROL_TYPE_ID  IN TPA_ENR_POLICY.ENROL_TYPE_ID%TYPE,
P_OUT_RESULT        OUT SYS_REFCURSOR
) IS
BEGIN
RULE_DALA_XML_PARSING(P_MEMBER_SEQ_ID,P_ENROL_TYPE_ID);

OPEN P_OUT_RESULT FOR SELECT * FROM APP.RULE_DATA_XML_PARSING ORDER BY lpad(substr(COVERGARE_ID,8),3);

END INITIAL_PERIOD_EXCL_DTL_PROC;
--===============================================================================================================
PROCEDURE IMPORTANE_NOTES_PROC(
P_MEMBER_SEQ_ID  IN tpa_enr_policy_member.MEMBER_SEQ_ID%TYPE,
P_ENROL_TYPE_ID  IN TPA_ENR_POLICY.ENROL_TYPE_ID%TYPE,
P_OUT_RESULT        OUT SYS_REFCURSOR
)
IS
BEGIN

IF P_ENROL_TYPE_ID='COR' THEN

OPEN P_OUT_RESULT FOR 
SELECT EXTRACT(e.PROD_POLICY_RULE,'/clauses/clause[@id="cls.28"]//text/@value').getclobval()  AS IMPORTANT_NOTE
FROM TPA_ENR_POLICY A JOIN tpa_enr_policy_GROUP B ON(A.POLICY_SEQ_ID=B.POLICY_SEQ_ID)
JOIN  tpa_enr_policy_member C ON (C.POLICY_GROUP_SEQ_ID=B.POLICY_GROUP_SEQ_ID)
LEFT OUTER JOIN TPA_INS_PROD_POLICY d on (A.POLICY_SEQ_ID=d.POLICY_SEQ_ID)
LEFT OUTER JOIN TPA_INS_PROD_POLICY_RULES e on(d.PROD_POLICY_SEQ_ID=e.PROD_POLICY_SEQ_ID)
 WHERE 
C.Member_Seq_Id =P_MEMBER_SEQ_ID; 

ELSE

OPEN P_OUT_RESULT FOR 
 SELECT EXTRACT(e.PROD_POLICY_RULE,'/clauses/clause[@id="cls.28"]//text/@value').getclobval() AS IMPORTANT_NOTE
FROM TPA_ENR_POLICY A JOIN tpa_enr_policy_GROUP B ON(A.POLICY_SEQ_ID=B.POLICY_SEQ_ID)
JOIN  tpa_enr_policy_member C ON (C.POLICY_GROUP_SEQ_ID=B.POLICY_GROUP_SEQ_ID)
LEFT OUTER JOIN TPA_INS_PROD_POLICY d on (A.PRODUCT_SEQ_ID=d.PRODUCT_SEQ_ID)
LEFT OUTER JOIN TPA_INS_PROD_POLICY_RULES e on(d.PROD_POLICY_SEQ_ID=e.PROD_POLICY_SEQ_ID)
 WHERE 
C.Member_Seq_Id =P_MEMBER_SEQ_ID
AND  E.VALID_FROM=(SELECT 
MAX( E.VALID_FROM)
FROM TPA_ENR_POLICY A JOIN tpa_enr_policy_GROUP B ON(A.POLICY_SEQ_ID=B.POLICY_SEQ_ID)
JOIN  tpa_enr_policy_member C ON (C.POLICY_GROUP_SEQ_ID=B.POLICY_GROUP_SEQ_ID)
LEFT OUTER JOIN TPA_INS_PROD_POLICY d on (A.PRODUCT_SEQ_ID=d.PRODUCT_SEQ_ID)
LEFT OUTER JOIN TPA_INS_PROD_POLICY_RULES e on(d.PROD_POLICY_SEQ_ID=e.PROD_POLICY_SEQ_ID)
WHERE 
C.Member_Seq_Id =P_MEMBER_SEQ_ID);

END IF;



EXCEPTION 
WHEN NO_DATA_FOUND THEN     
NULL;

END IMPORTANE_NOTES_PROC;

--===============================================================================================================
PROCEDURE SEARCH_FINANCE_DTL_PROC(
P_CLAIM_PAT_NUMBER      IN CLM_GENERAL_DETAILS.CLAIM_NUMBER%TYPE,
P_TPA_ENROLLMENT_ID IN TPA_ENR_POLICY_MEMBER.TPA_ENROLLMENT_ID%TYPE,
P_MOBILE_NO         IN  TPA_ENR_MEM_ADDRESS.mobile_no%TYPE,
P_MEM_NAME          IN  TPA_ENR_POLICY_MEMBER.MEM_NAME%TYPE,
P_CORPORATE         IN TPA_GROUP_REGISTRATION.GROUP_NAME%TYPE,
P_employee_no       IN  TPA_ENR_POLICY_GROUP.employee_no%TYPE,
P_POLICY_NUMBER     IN TPA_ENR_POLICY.POLICY_NUMBER%TYPE,
P_FLAG              IN VARCHAR2,
P_SORT_VAR          IN VARCHAR2,
P_SORT_ORDER        IN VARCHAR2,   --ASC/DESC                                 
P_START_NUM         IN NUMBER,
P_END_NUM           IN NUMBER,
P_EMIRATE_ID        IN TPA_ENR_POLICY_MEMBER.EMIRATE_ID%TYPE,
P_EMAIL             IN VARCHAR2, 
P_OUT_RESULT        OUT SYS_REFCURSOR
)
IS
TYPE BIND_TAB_TYPE IS TABLE OF VARCHAR2(500) INDEX BY BINARY_INTEGER ;
BIND_TAB    BIND_TAB_TYPE;
i number:=0;
V_STRING VARCHAR2(5000);
V_WHERE  VARCHAR2(3000);
V_COUNT   NUMBER;
V_CLAIM_NUMBER   CLM_GENERAL_DETAILS.CLAIM_NUMBER%TYPE;
V_PAT_ENROLL_DETAIL_SEQ_ID PAT_ENROLL_DETAILS.PAT_ENROLL_DETAIL_SEQ_ID%TYPE;
BEGIN
  
IF P_MOBILE_NO IS NOT NULL OR P_TPA_ENROLLMENT_ID IS NOT NULL OR P_MEM_NAME IS NOT NULL OR P_CLAIM_PAT_NUMBER IS NOT NULL 
  OR P_CORPORATE IS NOT NULL OR P_employee_no IS NOT NULL OR P_POLICY_NUMBER IS NOT NULL 
  OR P_EMIRATE_ID IS NOT NULL or P_EMAIL is not null THEN 
V_STRING:='WITH mobile_tb AS (select INTX.FN_MOB_DECRYPT(mobile_no)  mobile_no,ENR_ADDRESS_SEQ_ID,
        ttk_util_pkg.fn_decrypt(email_id) as email_id             
 from tpa_enr_mem_address )
select
cl.claim_number,
ep.policy_number,
Ad.Mobile_No,
GR.TPA_ENROLLMENT_NUMBER,
EM.MEM_NAME,
TG.GROUP_NAME,
ttk_util_pkg.fn_decrypt(V.payee_name) payee_name,
X.check_num,
TRIM(TO_CHAR(X.check_amount,''999,999,9999,999,999''))as check_amount,
TRIM(TO_CHAR((td.approved_amount - td.check_amount), ''999,999,9999,999,999'')) AS tds_amount,
Z.description AS cheque_status,
TO_CHAR(X.check_date,''DD/MM/YYYY'') AS check_date,   
X.CONSIGNMENT_NO,
X.PROVIDER_NAME ,
TO_CHAR(x.despatch_date,''dd/mm/yyyy hh:mi AM'') AS despatch_date
,X.CLAIMS_CHK_SEQ_ID
,cl.CLAIM_SEQ_ID
,EM.TPA_ENROLLMENT_ID,
EM.EMIRATE_ID QATAR_ID

FROM
app.tpa_enr_policy ep
INNER JOIN app.tpa_enr_policy_group gr ON (gr.policy_seq_id=ep.policy_seq_id)
INNER JOIN app.tpa_enr_policy_member EM ON (EM.policy_group_seq_id=gr.policy_group_seq_id)
LEFT OUTER JOIN mobile_tb ad ON (ad.enr_address_seq_id=em.enr_address_seq_id)
LEFT OUTER JOIN  clm_authorization_details CL ON (EM.member_seq_id = CL.member_seq_id)
--LEFT OUTER JOIN  clm_general_details CG ON (CG.claim_seq_id = CL.claim_seq_id)
JOIN tpa_claims_payment V ON (V.claim_seq_id = cl.claim_seq_id)
LEFT OUTER JOIN tpa_payment_checks_details W ON (W.payment_seq_id = V.payment_seq_id)
LEFT OUTER JOIN tpa_claims_check X ON (X.claims_chk_seq_id = W.claims_chk_seq_id)
LEFT OUTER JOIN tpa_clm_tds_details td ON (td.claim_seq_id=cl.claim_seq_id)
LEFT OUTER JOIN tpa_general_code Z ON (X.check_status = Z.general_type_id)
LEFT OUTER JOIN  TPA_GROUP_REGISTRATION TG on (TG.GROUP_REG_SEQ_ID=EP.GROUP_REG_SEQ_ID)';

IF P_TPA_ENROLLMENT_ID IS NOT NULL THEN
V_WHERE:=  V_WHERE|| ' AND GR.POLICY_GROUP_SEQ_ID IN
                       (SELECT POLICY_GROUP_SEQ_ID 
                             FROM TPA_ENR_POLICY_GROUP 
                             WHERE TPA_ENROLLMENT_NUMBER=UPPER(:P_TPA_ENROLLMENT_ID))';
i:=i+1;
bind_tab(i):=P_TPA_ENROLLMENT_ID;
END IF;
 
 IF P_MOBILE_NO IS NOT NULL THEN
  V_WHERE:=  V_WHERE|| ' AND ad.MOBILE_NO=:P_MOBILE_NO';
 i:=i+1;
bind_tab(i):=P_MOBILE_NO;
  END IF;
  
IF P_MEM_NAME IS NOT NULL THEN
 V_WHERE:=  V_WHERE|| ' AND EM.MEM_NAME like :P_MEM_NAME';
  i:=i+1;
bind_tab(i):='%'||upper(P_MEM_NAME);
 END IF;

IF P_CORPORATE IS  NOT NULL THEN 
 V_WHERE:=  V_WHERE|| ' AND TG.GROUP_NAME=:P_CORPORATE';
  i:=i+1;
bind_tab(i):=P_CORPORATE;
 END IF;

 IF P_employee_no IS NOT NULL THEN
  V_WHERE:=  V_WHERE|| ' AND GR.employee_no=:P_employee_no';
  i:=i+1;
bind_tab(i):=P_employee_no;
 END IF;

 IF P_POLICY_NUMBER IS NOT NULL THEN
  V_WHERE:=  V_WHERE|| ' AND EP.POLICY_NUMBER=:P_POLICY_NUMBER';
 i:=i+1;
bind_tab(i):=P_POLICY_NUMBER;
  END IF;
  ------------ CR0218(SEARCH BY QATARID)---------------------- 
  IF P_EMIRATE_ID IS NOT NULL THEN
    V_WHERE:=  V_WHERE|| ' AND EM.EMIRATE_ID=:P_EMIRATE_ID';
    i:=i+1;
    bind_tab(i):=P_EMIRATE_ID;
  END IF;
  -------------------------------------------------------------
  
   IF P_EMAIL IS NOT NULL THEN
    V_WHERE:=  V_WHERE|| ' AND ad.EMAIL_ID=:P_EMAIL';
    i:=i+1;
    bind_tab(i):=P_EMAIL;
  END IF;
  
IF V_WHERE IS NOT NULL THEN
 V_WHERE:=' WHERE '|| SUBSTR(V_WHERE,5) ;
 END IF;
 
 V_STRING :=V_STRING||V_WHERE;


IF P_CLAIM_PAT_NUMBER IS NOT NULL THEN
  
BEGIN

SELECT COUNT(PRE_AUTH_NUMBER),PAT_AUTH_SEQ_ID INTO V_COUNT,V_PAT_ENROLL_DETAIL_SEQ_ID
FROM pat_authorization_details WHERE PRE_AUTH_NUMBER=P_CLAIM_PAT_NUMBER
GROUP BY PAT_AUTH_SEQ_ID;

EXCEPTION
  WHEN NO_DATA_FOUND THEN
NULL;
END;

IF  V_WHERE IS NOT NULL THEN 

   IF V_COUNT>0 THEN

       V_STRING :=V_STRING|| ' AND CL.CLAIM_NUMBER in  (SELECT CLAIM_NUMBER  FROM clm_authorization_details
          WHERE PAT_AUTH_SEQ_ID=' || V_PAT_ENROLL_DETAIL_SEQ_ID || ' )';

       ELSE

          V_STRING :=V_STRING|| ' AND CL.CLAIM_NUMBER = ' || chr(39)|| P_CLAIM_PAT_NUMBER||chr(39);
  END IF;

ELSE

      IF V_COUNT>0 THEN

       V_STRING :=V_STRING|| ' where  CL.CLAIM_NUMBER in  (SELECT CLAIM_NUMBER  FROM clm_authorization_details
            WHERE PAT_AUTH_SEQ_ID = ' || V_PAT_ENROLL_DETAIL_SEQ_ID || ' )';
       ELSE
           V_STRING :=V_STRING|| 'where  CL.CLAIM_NUMBER = ' || chr(39)|| P_CLAIM_PAT_NUMBER||chr(39) ;

        END IF;

END IF;
END IF;

 IF P_FLAG ='Y' THEN 
 V_STRING:= ' SELECT * FROM (SELECT A.*,DENSE_RANK() OVER(ORDER BY '||P_SORT_VAR ||' '||P_SORT_ORDER||',ROWNUM) Q 
 FROM ('||v_string||') A) WHERE  Q>=  '||P_START_NUM||' AND Q<= '||P_END_NUM || ' ORDER BY CLAIMS_CHK_SEQ_ID DESC' ;
 ELSE
  V_STRING:= ' SELECT * FROM (SELECT A.*,DENSE_RANK() OVER(ORDER BY '||P_SORT_VAR ||' '||P_SORT_ORDER||',ROWNUM) Q 
 FROM ('||v_string||') A) WHERE  Q>=  '||P_START_NUM||' AND Q<= '||P_END_NUM || ' ORDER BY CLAIM_SEQ_ID DESC' ;
 END IF;
 
 --dbms_output.put_line(V_STRING);
 


 CASE bind_tab.COUNT
  WHEN 1 THEN OPEN P_OUT_RESULT FOR V_STRING USING bind_tab(1);
  WHEN 2 THEN OPEN P_OUT_RESULT FOR V_STRING USING bind_tab(1),bind_tab(2);
  WHEN 3 THEN OPEN P_OUT_RESULT FOR V_STRING USING bind_tab(1),bind_tab(2),bind_tab(3);
  WHEN 4 THEN OPEN P_OUT_RESULT FOR V_STRING USING bind_tab(1),bind_tab(2),bind_tab(3),bind_tab(4);
  WHEN 5 THEN OPEN P_OUT_RESULT FOR V_STRING USING bind_tab(1),bind_tab(2),bind_tab(3),bind_tab(4),bind_tab(5);
  WHEN 6 THEN OPEN P_OUT_RESULT FOR V_STRING USING bind_tab(1),bind_tab(2),bind_tab(3),bind_tab(4),bind_tab(5),bind_tab(6);
  WHEN 7 THEN OPEN P_OUT_RESULT FOR V_STRING USING bind_tab(1),bind_tab(2),bind_tab(3),bind_tab(4),bind_tab(5),bind_tab(6),bind_tab(7);
  WHEN 8 THEN OPEN P_OUT_RESULT FOR V_STRING USING bind_tab(1),bind_tab(2),bind_tab(3),bind_tab(4),bind_tab(5),bind_tab(6),bind_tab(7),bind_tab(8);
ELSE
  OPEN P_OUT_RESULT FOR V_STRING;
END CASE;
ELSE
  OPEN P_OUT_RESULT FOR
SELECT  NULL AS claim_number,
        NULL AS policy_number,
        NULL AS Mobile_No,
        NULL AS TPA_ENROLLMENT_NUMBER,
        NULL AS MEM_NAME,
        NULL AS GROUP_NAME,
        NULL AS payee_name,
        NULL AS check_num,
        NULL AS check_amount,
        NULL AS tds_amount,
        NULL AS cheque_status,
        NULL AS check_date,   
        NULL AS CONSIGNMENT_NO,
        NULL AS PROVIDER_NAME ,
        NULL AS despatch_date,
        NULL AS CLAIMS_CHK_SEQ_ID,
        NULL AS CLAIM_SEQ_ID,
        NULL AS TPA_ENROLLMENT_ID,
        NULL AS QATAR_ID
        FROM DUAL;
         
END IF; 
 
END SEARCH_FINANCE_DTL_PROC;

--===============================================================================================================

PROCEDURE SELECT_DATA_FOR_CARD_PRINT (P_POLICY_GROUP_SEQ_ID  IN  TPA_ENR_POLICY_GROUP.POLICY_GROUP_SEQ_ID%type,
                                      P_OUT_RESULT        OUT SYS_REFCURSOR)
  IS
      v_Age                 VARCHAR2(15);      v_Gender        VARCHAR2(100);
      v_Emp_Num             VARCHAR2(100);      v_Toll_Free_Num VARCHAR2(100);
      v_Insurance_Id        VARCHAR2(50);      v_Policy_Num    VARCHAR2(50);
      v_Certificate_Num     VARCHAR2(100);      v_Valid_From    VARCHAR2(100);
      v_Valid_Upto          VARCHAR2(100);      v_Remarks       tpa_ins_card_rules.short_remarks%TYPE;
      v_Company_Code        VARCHAR2(100);      v_DOB           VARCHAR2(100);
      v_DOJ                 VARCHAR2(100);      v_Image         VARCHAR2(1000);
      v_Company_Name        VARCHAR2(1000);      v_Enrollment_Id VARCHAR2(100);
      v_Policy_Holder_Name  VARCHAR2(1000);      v_ins_seq_id    tpa_ins_info.ins_seq_id%TYPE;
      v_Policy_Rule         NUMBER(12):=0;    v_bank_acct_num VARCHAR2(100);
      v_relship             VARCHAR2(100);
      v_temp  blob;
      v_mem_name            VARCHAR2(500);
  BEGIN
  -- For checking is there any card rule defined at policy level if it is a corporate policy. 
     SELECT COUNT(1) INTO v_Policy_Rule
       FROM tpa_enr_policy_group g JOIN tpa_enr_policy p ON (g.policy_seq_id = p.policy_seq_id)
            JOIN tpa_ins_prod_policy pp ON (p.policy_seq_id = pp.policy_seq_id)
            JOIN tpa_ins_card_rules cr ON (pp.prod_policy_seq_id = cr.prod_policy_seq_id AND
                                            p.enrol_type_id = cr.enrol_type_id AND
                                            (p.ins_head_office_seq_id = cr.ins_seq_id OR
                                             p.ins_seq_id = cr.ins_seq_id ))
         WHERE p.enrol_type_id = 'COR' AND g.policy_group_seq_id = P_POLICY_GROUP_SEQ_ID;
            
  -- For checking is there any card rule defined at insurance office level. 
     SELECT COUNT(1) INTO v_ins_seq_id
       FROM tpa_enr_policy_group g
            JOIN tpa_enr_policy p ON (g.policy_seq_id = p.policy_seq_id)
            JOIN tpa_ins_prod_policy pp ON ((p.product_seq_id = pp.product_seq_id AND v_Policy_Rule=0)
                                        OR  (p.policy_seq_id = pp.policy_seq_id AND v_Policy_Rule>0))
            JOIN tpa_ins_card_rules cr ON (pp.prod_policy_seq_id = cr.prod_policy_seq_id AND
                                            p.enrol_type_id = cr.enrol_type_id AND
                                            p.Ins_Seq_Id = cr.Ins_Seq_Id)
         WHERE g.policy_group_seq_id = P_POLICY_GROUP_SEQ_ID;
         
  -- Pick the corresponding insurance office seq for which rule is defined.
     SELECT CASE WHEN v_ins_seq_id = 0 THEN p.ins_head_office_seq_id
                 ELSE p.ins_seq_id END INTO v_ins_seq_id
       FROM tpa_enr_policy_group g
            JOIN tpa_enr_policy p ON (g.policy_seq_id = p.policy_seq_id)
          WHERE g.policy_group_seq_id = P_POLICY_GROUP_SEQ_ID;
          
  -- Pick the Card rule.
     FOR rec IN (SELECT cr.card_rule_type_id, cr.general_type_id, cr.short_remarks
                   FROM tpa_enr_policy_group g
                        JOIN tpa_enr_policy p ON (g.policy_seq_id = p.policy_seq_id)
                        JOIN tpa_ins_prod_policy pp ON ((p.product_seq_id = pp.product_seq_id AND v_Policy_Rule=0)
                                                    OR  (p.policy_seq_id = pp.policy_seq_id AND v_Policy_Rule>0))
                        JOIN tpa_ins_card_rules cr ON (pp.prod_policy_seq_id = cr.prod_policy_seq_id AND
                                                        p.enrol_type_id = cr.enrol_type_id)
                        LEFT OUTER JOIN tpa_general_code gc ON (cr.general_type_id = gc.general_type_id)
                      WHERE g.policy_group_seq_id = P_POLICY_GROUP_SEQ_ID
                        AND cr.card_rule_type_id NOT IN ('CTY','DIS','CRP')
                        AND cr.Ins_Seq_Id = v_ins_seq_id)
     LOOP
           CASE rec.card_rule_type_id
                 WHEN 'MEM' THEN v_mem_name           := rec.general_type_id;
                 WHEN 'MNB' THEN v_Enrollment_Id      := rec.general_type_id;
                 WHEN 'PLN' THEN v_Policy_Num         := rec.general_type_id;
                 WHEN 'CNM' THEN v_Company_Name       := rec.general_type_id;
                 WHEN 'PHN' THEN v_Policy_Holder_Name := rec.general_type_id;
                 WHEN 'VST' THEN v_Valid_From         := rec.general_type_id;
                 WHEN 'VED' THEN v_Valid_Upto         := rec.general_type_id;
                 WHEN 'AGE' THEN v_Age                := rec.general_type_id;
                 WHEN 'GND' THEN v_Gender             := rec.general_type_id;
                 WHEN 'YOB' THEN v_DOB                := rec.general_type_id;
                 WHEN 'EID' THEN v_Emp_Num            := rec.general_type_id;
                 WHEN 'CPR' THEN v_Image              := rec.general_type_id;
                  ELSE NULL;
            END CASE ;
     END LOOP;
select image into v_temp from app.temp_image ;
  -- Apply the Card rule and pick data for e-cards.
     OPEN P_OUT_RESULT FOR
     SELECT CASE WHEN v_mem_name           = 'MENY' THEN m.mem_name ELSE NULL END AS Name,
            CASE WHEN v_Enrollment_Id      = 'TPEY' THEN m.tpa_enrollment_id ELSE NULL END AS Enrollment_Id,
            CASE WHEN v_Policy_Num         = 'PNOY' THEN p.policy_number ELSE NULL END AS Policy_Num,
            CASE WHEN v_Company_Name       = 'INCY' THEN gr.group_name ELSE NULL END AS Company_Name,
            CASE WHEN v_Policy_Holder_Name = 'ENMY' THEN g.insured_name ELSE NULL END AS Policy_Holder_Name,  
            CASE WHEN v_Valid_From         = 'EFTY' THEN to_char((CASE WHEN p.effective_from_date > m.date_of_inception OR 
                                                                           m.date_of_inception IS NULL 
                                                                      THEN p.effective_from_date ELSE m.date_of_inception  
                                                                  END),'dd/mm/yyyy') ELSE NULL END AS Valid_From,
            CASE WHEN v_Valid_Upto         = 'ETTY' THEN to_char((CASE WHEN p.effective_to_date < m.date_of_exit OR
                                                                           m.date_of_exit IS NULL
                                                                      THEN p.effective_to_date ELSE m.date_of_exit 
                                                                  END),'dd/mm/yyyy') ELSE NULL END AS Valid_Upto,
            CASE WHEN v_Age                = 'AGEY' THEN m.mem_age ELSE NULL END AS Age,
            CASE WHEN v_Gender             = 'GNDY' THEN substr(gc.description,1,1) ELSE NULL END AS Gender,
            CASE WHEN v_Emp_Num            = 'ENOY' THEN g.employee_no ELSE NULL END AS Emp_Num,
            CASE WHEN v_DOB                = 'MEMY' THEN to_char(m.mem_dob,'dd/mm/yyyy') ELSE NULL END AS DOB,
            CASE WHEN v_Image              = ('AVL') THEN NVL(im.IMAGE,v_temp) ELSE v_temp END AS Image,
            TO_CHAR(m.date_of_inception,'dd/mm/yyyy') as POLICY_ISSUE_DATE,
            m.vip_yn as VIP,
            M.MEM_NAME as mem_name,
            GC.DESCRIPTION AS DESCRIPTION
      FROM tpa_enr_policy_member m
            JOIN tpa_enr_policy_group g ON (m.policy_group_seq_id = g.policy_group_seq_id)
            JOIN tpa_enr_policy p ON (g.policy_seq_id = p.policy_seq_id)
            JOIN TPA_INS_PRODUCT TIP ON (P.PRODUCT_SEQ_ID=TIP.PRODUCT_SEQ_ID)
            join tpa_general_code GC ON (GC.GENERAL_TYPE_ID=TIP.PRODUCT_CAT_TYPE_ID)
            
            LEFT OUTER JOIN tpa_group_registration gr ON (p.group_reg_seq_id = gr.group_reg_seq_id)
            JOIN tpa_ins_info i ON (p.ins_seq_id = i.ins_seq_id)
            LEFT OUTER JOIN tpa_office_info oi ON (p.tpa_office_seq_id = oi.tpa_office_seq_id)
            LEFT OUTER JOIN tpa_general_code gc ON (m.gender_general_type_id = gc.general_type_id)
            LEFT OUTER JOIN idcard.image_data im ON (m.tpa_enrollment_id = im.enrolment_id)
            LEFT OUTER JOIN tpa_enr_bank_dtls bd ON bd.bank_seq_id = g.bank_seq_id
            LEFT OUTER JOIN tpa_relationship_code rc ON m.relship_type_id = rc.relship_type_id
         WHERE g.policy_group_seq_id = P_POLICY_GROUP_SEQ_ID 
         AND m.status_general_type_id != 'POC' AND m.deleted_yn = 'N'
         ORDER BY m.tpa_enrollment_id;
         
  END SELECT_DATA_FOR_CARD_PRINT;
--===============================================================================================================
PROCEDURE PREAUTH_SHORTFALL_LIST(
P_PAT_GEN_DETAIL_SEQ_ID IN SHORTFALL_DETAILS.PAT_GEN_DETAIL_SEQ_ID%TYPE,
P_OUT_RESULT        OUT SYS_REFCURSOR
)
IS
BEGIN
OPEN P_OUT_RESULT FOR
SELECT A.shortfall_seq_id,
           A.shortfall_id AS SHORTFALL_NO, 
           A.srtfll_general_type_id AS short_type,
          B.description AS shortfall_type,
          C.description AS status,
          TO_CHAR(A.srtfll_received_date,'DD/MM/YYYY HH:MI AM') Rreceived_date,
          TO_CHAR(A.srtfll_sent_date,'DD/MM/YYYY HH:MI AM')  sent_date,
          a.shortfall_raised_for as template_type,
         nvl(d.cigna_yn,'N') as cigna_yn--koc_ins_mail
         ,A.PAT_GEN_DETAIL_SEQ_ID
          FROM shortfall_details A LEFT OUTER JOIN tpa_general_code B ON (A.srtfll_general_type_id = B.general_type_id)
          LEFT OUTER JOIN tpa_general_code C ON (A.srtfll_status_general_type_id = C.general_type_id)
      LEFT OUTER JOIN app.shortfall_email_dtl d on (d.shortfall_seq_id=a.shortfall_seq_id)--koc_ins_mail
          WHERE A.PAT_GEN_DETAIL_SEQ_ID =P_PAT_GEN_DETAIL_SEQ_ID;
END PREAUTH_SHORTFALL_LIST;

--===============================================================================================================

PROCEDURE COURIER_DETAILS_LIST_PROC(
  P_COURIER_ID        IN COURIER_DETAILS.COURIER_ID%TYPE,
  P_CONSIGNMENT_NO    IN COURIER_DETAILS.DOCKET_NUMBER%TYPE,
  P_TPA_OFFICE_SEQ_ID  IN TPA_OFFICE_INFO.TPA_OFFICE_SEQ_ID%TYPE,
  P_SORT_VAR          IN VARCHAR2,
  P_SORT_ORDER        IN VARCHAR2,   --ASC/DESC                                 
  P_START_NUM         IN NUMBER,
  P_END_NUM           IN NUMBER, 
  P_OUT_RESULT        OUT SYS_REFCURSOR)
  
  IS
  
TYPE BIND_TAB_TYPE IS TABLE OF VARCHAR2(500) INDEX BY BINARY_INTEGER ;
BIND_TAB    BIND_TAB_TYPE;
i number:=0;
V_STRING VARCHAR2(5000);
V_WHERE  VARCHAR2(3000);

 BEGIN


V_STRING:='SELECT 
A.COURIER_ID  as Courier_No,
A.DOCKET_NUMBER as CONSIGNMENT_NO,
B.COURIER_COMP_NAME AS Courier_Name ,
TO_CHAR(A.DOC_DISPATCH_RCVD_DATE,''DD/MM/YYYY HH:MI:SS AM'') AS  Courier_Date,
C.OFFICE_NAME AS  TPA_Branch ,
a.RECEIVER_NAME,
a.SENDER_BRANCH as from_location,
a.SENDER_NAME as from_address
FROM COURIER_DETAILS A 
LEFT OUTER JOIN COURIER_COMPANY B ON (A.COURIER_COMP_SEQ_ID=B.COURIER_COMP_SEQ_ID)
 JOIN TPA_OFFICE_INFO C ON (A.TPA_OFFICE_SEQ_ID=C.TPA_OFFICE_SEQ_ID)';

 IF P_COURIER_ID IS  NOT NULL THEN 
 V_WHERE:=  V_WHERE|| ' AND A.COURIER_ID=:P_COURIER_ID';
  i:=i+1;
bind_tab(i):=P_COURIER_ID;
 END IF;

 IF P_CONSIGNMENT_NO IS NOT NULL THEN
  V_WHERE:=  V_WHERE|| ' AND A.DOCKET_NUMBER=:P_CONSIGNMENT_NO';
  i:=i+1;
bind_tab(i):=P_CONSIGNMENT_NO;
 END IF;

 IF   P_TPA_OFFICE_SEQ_ID  IS NOT NULL THEN
  V_WHERE:=  V_WHERE|| ' AND C.TPA_OFFICE_SEQ_ID=:P_TPA_OFFICE_SEQ_ID';
 i:=i+1;
bind_tab(i):=P_TPA_OFFICE_SEQ_ID;
  END IF;
  
  IF V_WHERE IS NOT NULL THEN
 V_WHERE:=' WHERE '|| SUBSTR(V_WHERE,5) ;
 END IF;
 
   V_STRING :=V_STRING||V_WHERE;

V_STRING:= ' SELECT * FROM (SELECT A.*,DENSE_RANK() OVER(ORDER BY '||P_SORT_VAR ||' '||P_SORT_ORDER||',ROWNUM) Q 
 FROM ('||v_string||') A) WHERE  Q>=  '||P_START_NUM||' AND Q<= '||P_END_NUM   ;


  CASE bind_tab.COUNT
  WHEN 1 THEN OPEN P_OUT_RESULT FOR V_STRING USING bind_tab(1);
  WHEN 2 THEN OPEN P_OUT_RESULT FOR V_STRING USING bind_tab(1),bind_tab(2);
  WHEN 3 THEN OPEN P_OUT_RESULT FOR V_STRING USING bind_tab(1),bind_tab(2),bind_tab(3);
  ELSE
  OPEN P_OUT_RESULT FOR V_STRING;
END CASE;
  
  END COURIER_DETAILS_LIST_PROC;
  
--===============================================================================================================

PROCEDURE EMPANLED_HOSPITAL_LIST_PROC(
P_TYPE  IN VARCHAR2,
P_HOSPITAL_NAME  IN TPA_HOSP_INFO.HOSP_NAME%TYPE,
P_STATE_ID       IN  TPA_HOSP_ADDRESS.STATE_TYPE_ID%TYPE,
P_CITY_TYPE_ID   IN  TPA_HOSP_ADDRESS.CITY_TYPE_ID%TYPE,
P_LOCATION       IN VARCHAR2,
P_SORT_VAR       IN VARCHAR2,
P_SORT_ORDER      IN VARCHAR2,   --ASC/DESC                                 
P_START_NUM       IN NUMBER,
P_END_NUM        IN NUMBER,
P_OUT_RESULT        OUT SYS_REFCURSOR)
IS

TYPE BIND_TAB_TYPE IS TABLE OF VARCHAR2(500) INDEX BY BINARY_INTEGER ;
BIND_TAB    BIND_TAB_TYPE;
V_STRING VARCHAR2(5000);
V_WHERE VARCHAR2(2000);
i number :=0;
BEGIN

 V_STRING:='SELECT  HI.HOSP_NAME,CC.CITY_DESCRIPTION,SC.STATE_NAME, 
 HA.ADDRESS_1 || '' '' || HA.ADDRESS_2 || '' '' || HA.ADDRESS_3 || '' - '' || HA.PIN_CODE AS ADDRESS, 
 NVL(HI.OFF_PHONE_NO_1,0) AS MOBILE_NO,
 HI.OFF_PHONE_NO_2 ,
TTK_UTIL_PKG.FN_DECRYPT(HI.PRIMARY_EMAIL_ID) AS HOSP_EMAIL_ID
FROM TPA_HOSP_INFO HI 
LEFT OUTER JOIN TPA_HOSP_ADDRESS HA ON (HI.HOSP_SEQ_ID = HA.HOSP_SEQ_ID)
LEFT OUTER JOIN TPA_HOSP_EMPANEL_STATUS HES ON (HI.HOSP_SEQ_ID = HES.HOSP_SEQ_ID AND HES.ACTIVE_YN = ''Y'' AND HES.EMPANEL_STATUS_TYPE_ID = ''EMP'')
LEFT OUTER JOIN TPA_OFFICE_INFO OI ON (HI.TPA_OFFICE_SEQ_ID = OI.TPA_OFFICE_SEQ_ID)
LEFT OUTER JOIN TPA_CITY_CODE CC ON (HA.CITY_TYPE_ID = CC.CITY_TYPE_ID)
LEFT OUTER JOIN TPA_STATE_CODE SC ON (HA.STATE_TYPE_ID = SC.STATE_TYPE_ID) ';
           


IF P_HOSPITAL_NAME IS NOT NULL THEN
V_WHERE:=V_WHERE||' AND HI.HOSP_NAME LIKE :P_HOSPITAL_NAME' ;
i:=i+1;
BIND_TAB(i):= '%'|| UPPER(P_HOSPITAL_NAME)||'%';
END IF;

IF P_STATE_ID  IS NOT NULL THEN
V_WHERE:=V_WHERE||' AND SC.STATE_TYPE_ID=:P_STATE_ID ' ;
i:=i+1;
BIND_TAB(i):=P_STATE_ID ;
END IF;

IF P_CITY_TYPE_ID IS NOT NULL THEN
V_WHERE:=V_WHERE||' AND CC.CITY_TYPE_ID=:P_CITY_TYPE_ID' ;
i:=i+1;
BIND_TAB(i):=P_CITY_TYPE_ID;
END IF;

IF P_LOCATION IS NOT NULL THEN
V_WHERE:=V_WHERE||' AND (HA.ADDRESS_1 || '','' || HA.ADDRESS_2 || '','' || HA.ADDRESS_3)  LIKE :P_HOSPITAL_NAME' ;
i:=i+1;
BIND_TAB(i):= '%'|| UPPER(P_LOCATION)||'%';
END IF;


IF P_TYPE='VPPN' THEN

V_WHERE:=V_WHERE||' AND HI.GIPSA_PPNYN = ''Y'' ';

END IF;


IF V_WHERE IS NOT NULL THEN
 V_WHERE:=' WHERE '|| SUBSTR(V_WHERE,5) ;
 END IF;
 
   V_STRING :=V_STRING||V_WHERE;

V_STRING:= ' SELECT * FROM (SELECT A.*,DENSE_RANK() OVER(ORDER BY '||P_SORT_VAR ||' '||P_SORT_ORDER||',ROWNUM) Q 
 FROM ('||v_string||') A) WHERE  Q>=  '||P_START_NUM||' AND Q<= '||P_END_NUM   ;

CASE bind_tab.COUNT
  WHEN 1 THEN OPEN P_OUT_RESULT FOR V_STRING USING bind_tab(1);
  WHEN 2 THEN OPEN P_OUT_RESULT FOR V_STRING USING bind_tab(1),bind_tab(2);
  WHEN 3 THEN OPEN P_OUT_RESULT FOR V_STRING USING bind_tab(1),bind_tab(2),bind_tab(3);
  WHEN 4 THEN OPEN P_OUT_RESULT FOR V_STRING USING bind_tab(1),bind_tab(2),bind_tab(3),bind_tab(4);
  ELSE
  OPEN P_OUT_RESULT FOR V_STRING;
END CASE;


END EMPANLED_HOSPITAL_LIST_PROC;

--===============================================================================================================
PROCEDURE PASSWORD_VALIDATION_PROC(
P_USER_ID IN  TPA_LOGIN_INFO.USER_ID%TYPE,
P_PASSWORD IN TPA_LOGIN_INFO.PASSWORD%TYPE,
P_OUT_RESULT  OUT VARCHAR2)

IS

CURSOR  ACTIVE_PASSWORD_CUR IS (
SELECT TTK_UTIL_PKG.FN_DECRYPT(PASSWORD) PASSWORD,ACTIVE_YN 
FROM TPA_LOGIN_INFO A WHERE A.USER_ID=P_USER_ID);

CURSOR EXPIRE_ALERT_CUR IS ( SELECT TO_DATE(trunc(n.password_generated_date) + a.password_valid_days,'DD/MM/YYYY') EXPIRE_DATE,
TO_DATE(trunc(n.password_generated_date) + a.password_valid_days -a.alert_days + 1,'DD/MM/YYYY') ALERT_START_DATE
FROM APP.password_config a, tpa_login_info n
WHERE n.user_id =P_USER_ID and a.config_type ='TTK' );

V_ACTIVE_PASSWORD_CUR ACTIVE_PASSWORD_CUR%ROWTYPE;    
V_EXPIRE_ALERT_CUR EXPIRE_ALERT_CUR%ROWTYPE;    

V_PASSWORD_VALID_YN VARCHAR2(2);
V_ACTIVE_YN VARCHAR2(2);
V_PASSWORD_ALERT VARCHAR2(2);

BEGIN

OPEN ACTIVE_PASSWORD_CUR;
FETCH ACTIVE_PASSWORD_CUR INTO V_ACTIVE_PASSWORD_CUR;
CLOSE ACTIVE_PASSWORD_CUR;

OPEN EXPIRE_ALERT_CUR;
FETCH EXPIRE_ALERT_CUR INTO  V_EXPIRE_ALERT_CUR;
CLOSE EXPIRE_ALERT_CUR;

IF P_PASSWORD=V_ACTIVE_PASSWORD_CUR.PASSWORD THEN
V_PASSWORD_VALID_YN :='Y';
ELSE
V_PASSWORD_VALID_YN :='N';
END IF;

IF V_ACTIVE_PASSWORD_CUR.ACTIVE_YN='Y' THEN
V_ACTIVE_YN:='Y';
ELSE
V_ACTIVE_YN:='N';
END IF;


IF V_EXPIRE_ALERT_CUR.EXPIRE_DATE<=TO_DATE(TRUNC(SYSDATE),'DD/MM/YYYY') THEN
V_PASSWORD_ALERT:='N';
ELSE
V_PASSWORD_ALERT:='Y';
END IF;

P_OUT_RESULT:='PASSWORD_VALID_YN : '||V_PASSWORD_VALID_YN||' | '|| 'ACTIVE_YN : '||V_ACTIVE_YN||' | '|| 'PASSWORD_EXPIRY_ALERT : '||V_PASSWORD_ALERT;


END PASSWORD_VALIDATION_PROC;
--===============================================================================================================
 procedure current_status( v_seq_id  IN NUMBER,
                           v_mode    IN NUMBER,
                           v_status OUT NUMBER)
IS              

v_seq_id1      varchar2(50):=''||v_seq_id||'';
                              
CURSOR clm_status  IS
select CASE WHEN Clm_Status_Type_Id='INP' THEN 1
            WHEN Clm_Status_Type_Id='APR' THEN 2
            WHEN Clm_Status_Type_Id='REQ' THEN 3
            WHEN Clm_Status_Type_Id='REJ' THEN 4
            WHEN Clm_Status_Type_Id='PCN' THEN 5
            WHEN Clm_Status_Type_Id='PCO' THEN 6
            END 
        from Clm_Authorization_Details
        where Claim_Number=v_seq_id1;


CURSOR pat_status  IS
select  
       CASE WHEN Pat_Status_Type_Id='INP' THEN 1
            WHEN Pat_Status_Type_Id='APR' THEN 2
            WHEN Pat_Status_Type_Id='REQ' THEN 3
            WHEN Pat_Status_Type_Id='REJ' THEN 4
            WHEN Pat_Status_Type_Id='PCN' THEN 5
            WHEN Pat_Status_Type_Id='PCO' THEN 6
            END 
    from pat_Authorization_Details
where Pre_Auth_Number=v_seq_id1;

BEGIN
IF v_mode=1 THEN
OPEN pat_status;
  FETCH pat_status INTO v_status;
    CLOSE pat_status;
ELSE
OPEN clm_status;
  FETCH clm_status INTO v_status;
    CLOSE clm_status;
END IF;    
END current_status;    
--============================================================================================================
PROCEDURE ICD_ACTIVITY_DETAILS (V_PRE_CLAIM_NUMBER   IN  VARCHAR2,
                                V_MODE               IN  VARCHAR2,
                                V_DIAG_CURSOR        OUT SYS_REFCURSOR,
                                V_ACTIVITY_CUR       OUT SYS_REFCURSOR)
AS

BEGIN
  
IF V_MODE='PAT' THEN
  OPEN  V_DIAG_CURSOR FOR
    SELECT DD.DIAGNOSYS_CODE AS ICD_CODE,
           ICD.SHORT_DESC AS DIAG_DESC,
           CASE WHEN DD.PRIMARY_AILMENT_YN='Y' THEN 'Primary' 
                 ELSE 'Secondary' END AS DIAG_TYPE  
     FROM PAT_AUTHORIZATION_DETAILS PAT
     JOIN DIAGNOSYS_DETAILS DD ON (PAT.PAT_AUTH_SEQ_ID=DD.PAT_AUTH_SEQ_ID)
     JOIN TPA_ICD10_MASTER_DETAILS ICD ON (DD.DIAGNOSYS_CODE=ICD.ICD_CODE)
     WHERE PAT.PAT_AUTH_SEQ_ID=V_PRE_CLAIM_NUMBER;
     
  OPEN V_ACTIVITY_CUR FOR 
  
   select 
       NVL(ad.code,ad.internal_code) as ACT_CODE,
       ad.quantity,
       ad.approvd_quantity as APR_QTY,
       to_char(ad.start_date,'DD-MM-YYYY') AS start_date,
       ad.discount_amount as DISC_AMNT,
       ad.gross_amount,
       CASE WHEN SIGN(nvl(ad.disc_gross_amount,0)-nvl(ad.patient_share_amount,0))= -1 THEN 0
                 ELSE nvl(ad.disc_gross_amount,0)-nvl(ad.patient_share_amount,0) END  as net_amount,
       ad.disc_gross_amount as DISC_GROSS,
       ad.patient_share_amount as PATIENT_SHARE,
       nvl(ad.allowed_amount,0) as ALLOWED_AMNT,
       nvl(ad.denial_code,'-') as DEN_CODE,
       case when (nvl(ad.disc_gross_amount,0)-nvl(ad.patient_share_amount,0))-nvl(ad.approved_amount,0)>0
              then (nvl(ad.disc_gross_amount,0)-nvl(ad.patient_share_amount,0))-nvl(ad.approved_amount,0) else 0 end  as DIS_ALLOWED_AMNT,
       ad.denial_desc as den_desc,
       TAMD.ACTIVITY_DESCRIPTION as act_desc          
      from pat_activity_details ad
      left outer join tpa_activity_master_details tamd on (ad.code=tamd.activity_code)
      left outer join tpa_pharmacy_master_details md on (ad.code = md.activity_code and ad.start_date between md.start_date and md.end_date)
      left outer join app.tpa_ip_service_details isd on (isd.service_code=ad.service_code)
      where ad.pat_auth_seq_id =V_PRE_CLAIM_NUMBER
     order by ad.activity_dtl_seq_id;
         
  ELSIF V_MODE='CLM' THEN
  
  OPEN  V_DIAG_CURSOR FOR
    SELECT DD.DIAGNOSYS_CODE AS ICD_CODE,
           ICD.SHORT_DESC AS DIAG_DESC,
           CASE WHEN DD.PRIMARY_AILMENT_YN='Y' THEN 'Primary' 
                 ELSE 'Secondary' END AS DIAG_TYPE 
        FROM CLM_AUTHORIZATION_DETAILS PAT
         JOIN DIAGNOSYS_DETAILS DD ON (PAT.CLAIM_SEQ_ID=DD.CLAIM_SEQ_ID)
         JOIN TPA_ICD10_MASTER_DETAILS ICD ON (DD.DIAGNOSYS_CODE=ICD.ICD_CODE)
         WHERE PAT.CLAIM_SEQ_ID=V_PRE_CLAIM_NUMBER;
    
  OPEN V_ACTIVITY_CUR FOR 
    select 
       ad.code as ACT_CODE,
       ad.quantity,
       ad.approvd_quantity as APR_QTY,
       to_char(ad.start_date,'DD-MM-YYYY') AS start_date,
       ad.discount_amount as DISC_AMNT,
       ad.gross_amount,
       CASE WHEN SIGN(nvl(ad.disc_gross_amount,0)-nvl(ad.patient_share_amount,0))= -1 THEN 0
                 ELSE nvl(ad.disc_gross_amount,0)-nvl(ad.patient_share_amount,0) END  as net_amount,
       ad.disc_gross_amount as DISC_GROSS,
       ad.patient_share_amount as PATIENT_SHARE,
       nvl(ad.allowed_amount,0) as ALLOWED_AMNT,
       nvl(ad.denial_code,'-') as DEN_CODE,
      case when (nvl(ad.disc_gross_amount,0)-nvl(ad.patient_share_amount,0))-nvl(ad.approved_amount,0)>0
              then (nvl(ad.disc_gross_amount,0)-nvl(ad.patient_share_amount,0))-nvl(ad.approved_amount,0) else 0 end  as DIS_ALLOWED_AMNT, 
       ad.denial_desc as den_desc,
       TAMD.ACTIVITY_DESCRIPTION as act_desc  
      from pat_activity_details ad
      left outer join tpa_activity_master_details tamd on (ad.code=tamd.activity_code)
      left outer join tpa_pharmacy_master_details md on (ad.code = md.activity_code and ad.start_date between md.start_date and md.end_date)
      left outer join app.tpa_ip_service_details isd on (isd.service_code=ad.service_code)
      where ad.Claim_Seq_Id =V_PRE_CLAIM_NUMBER
     order by ad.activity_dtl_seq_id;   
      
  END IF;    
 END ICD_ACTIVITY_DETAILS;                           
--============================================================================================================
PROCEDURE VIEW_PRE_AUTH_CLM_DOCS (V_MODE      in VARCHAR2,
                                  V_SEQ_ID    IN NUMBER,
                                  V_RESULTSET OUT SYS_REFCURSOR)
  
AS
cursor Claim_source_type IS
 SELECT D.SOURCE_TYPE_ID FROM CLM_BATCH_UPLOAD_DETAILS D 
 JOIN CLM_AUTHORIZATION_DETAILS C ON (D.CLM_BATCH_SEQ_ID=C.CLM_BATCH_SEQ_ID)
 WHERE C.CLAIM_SEQ_ID=V_SEQ_ID;
 
 V_SOUREC_TYPE          VARCHAR2(1000);
BEGIN

OPEN Claim_source_type;
  FETCH Claim_source_type INTO  V_SOUREC_TYPE;
    CLOSE Claim_source_type;
IF NVL(V_SOUREC_TYPE,'NA') != 'MCLM' THEN  
    OPEN  V_RESULTSET FOR
    select pat.docs_seq_id,pat.file_name,gen.description,pat.image_file as file_data,
           to_char(pat.added_date,'dd-mm-yyyy') added_date,'N' as mob_app_yn,
         (select a.contact_name from tpa_user_contacts A where A.CONTACT_SEQ_ID=pat.added_by) as added_by
    from pat_clm_docs_tab pat
    LEFT OUTER join tpa_general_code gen on (pat.file_desc=gen.general_type_id)
    where pat.source_id= V_MODE and pat.pat_clm_seq_id=V_SEQ_ID;
ELSIF  V_SOUREC_TYPE ='MCLM' THEN  
  OPEN  V_RESULTSET FOR 
     select  ba.clm_batch_seq_id as docs_seq_id,'Mobie Doc Upload' as file_name,'Mobie Doc Upload' as description,ba.onl_mob_clm_docmnts as file_data,'Y' as mob_app_yn
           ,to_char(ba.added_date,'dd-mm-yyyy') added_date,
         (select a.contact_name from tpa_user_contacts A where A.CONTACT_SEQ_ID=ba.added_by) as added_by
     from CLM_BATCH_UPLOAD_DETAILS ba
     JOIN CLM_AUTHORIZATION_DETAILS cad on (ba.clm_batch_seq_id=cad.clm_batch_seq_id)
     where cad.claim_seq_id=V_SEQ_ID
     union all
    select pat.docs_seq_id,pat.file_name,gen.description,pat.image_file as file_data,'N' as mob_app_yn,
           to_char(pat.added_date,'dd-mm-yyyy') added_date,
         (select a.contact_name from tpa_user_contacts A where A.CONTACT_SEQ_ID=pat.added_by) as added_by
    from pat_clm_docs_tab pat
    LEFT OUTER join tpa_general_code gen on (pat.file_desc=gen.general_type_id)
    where pat.source_id= V_MODE and pat.pat_clm_seq_id=V_SEQ_ID ;
END IF; 
END;
--============================================================================================================
PROCEDURE SELECT_PRE_CLM_DOC (V_SEQ_ID     IN NUMBER,
                             	V_MOB_YN     IN VARCHAR2,
                              V_FILE       OUT PAT_CLM_DOCS_TAB.IMAGE_FILE%TYPE,
                              V_FILE_NAME  OUT PAT_CLM_DOCS_TAB.FILE_NAME%TYPE)
AS
cursor image_file is
select pat.image_file as file_data,pat.file_name
  from pat_clm_docs_tab pat
  where pat.docs_seq_id=V_SEQ_ID;

cursor mob_image_file is
 select NVL(ba.ONL_MOB_CLM_DOCMNTS,doc.image_file)as image_file,nvl(doc.file_name,'abc.pdf') as file_name 
   from clm_batch_upload_details ba
   left outer join clm_authorization_details cad on (ba.clm_batch_seq_id=cad.clm_batch_seq_id)
   left outer join pat_clm_docs_tab doc on (cad.claim_seq_id=doc.pat_clm_seq_id and doc.source_id='CLM')
   where ba.clm_batch_seq_id=V_SEQ_ID; 
BEGIN
  
 IF V_MOB_YN='N' THEN
  open image_file;
  fetch image_file into V_FILE,V_FILE_NAME  ;
  close image_file;
  ELSIF V_MOB_YN='Y' THEN
   open mob_image_file;
   fetch mob_image_file into V_FILE,V_FILE_NAME;
   close mob_image_file;
  END IF;
END SELECT_PRE_CLM_DOC;                                   
--====================================================================
PROCEDURE Update_member_Contact_det (v_member_seq_id    IN   NUMBER,
                                     v_mobile_no        IN   app.tpa_enr_mem_address.mobile_no%type,
                                     v_email            IN   app.tpa_enr_mem_address.email_id%type,
                                     v_passport_no      IN   app.tpa_enr_policy_member.passport_number%type,
                                     v_qatar_id         IN   app.tpa_enr_policy_member.emirate_id%type,
                                     v_ref_cur          OUT  SYS_REFCURSOR)
                                     
as

CURSOR Get_Mem_Contact_det IS
  SELECT TTK_UTIL_PKG.fn_decrypt(A.MOBILE_NO) AS MOBILE_NO,
         TTK_UTIL_PKG.fn_decrypt(A.EMAIL_ID) AS EMIAL_ID,
         A.ENR_ADDRESS_SEQ_ID,
         M.PASSPORT_NUMBER,
         M.EMIRATE_ID,
         M.TPA_ENROLLMENT_ID
    FROM TPA_ENR_POLICY_MEMBER M
     JOIN TPA_ENR_MEM_ADDRESS A ON (M.ENR_ADDRESS_SEQ_ID=A.ENR_ADDRESS_SEQ_ID)
     WHERE M.MEMBER_SEQ_ID=v_member_seq_id;
     
 Get_Mem_Contact_rec Get_Mem_Contact_det%ROWTYPE; 
 v_remarks           VARCHAR2(3000);
            ---- Addein in Insurance certificate Cr for Duplicate Qatar id validation
  cursor prev_policy is 
        SELECT p.PREV_POLICY_SEQ_ID   FROM tpa_enr_policy_member a
         left join app.tpa_enr_policy_group g on (a.policy_group_seq_id = g.policy_group_seq_id)
         Left join app.tpa_enr_policy p on (g.policy_seq_id = p.policy_seq_id)
       WHERE  a.member_seq_id = nvl(v_member_seq_id,0) ;
       v_prev_pol_id   tpa_enr_policy.policy_seq_id%type;
    
   cursor prev_qatar_id(v_pol_id tpa_enr_policy.policy_seq_id%type,v_enr_id tpa_enr_policy_member.tpa_enrollment_id%type) is 
        SELECT a.emirate_id   FROM tpa_enr_policy_member a
         left join app.tpa_enr_policy_group g on (a.policy_group_seq_id = g.policy_group_seq_id)
         Left join app.tpa_enr_policy p on (g.policy_seq_id = p.policy_seq_id)
       WHERE  a.tpa_enrollment_id = v_enr_id and p.policy_seq_id = v_pol_id;
         v_qid   tpa_enr_policy_member.emirate_id%type;
          
   CURSOR Emirate_id_cur IS SELECT COUNT(1) FROM tpa_enr_policy_member a
         left join app.tpa_enr_policy_group g on (a.policy_group_seq_id = g.policy_group_seq_id)
         Left join app.tpa_enr_policy p on (g.policy_seq_id = p.policy_seq_id)
       WHERE  a.emirate_id = v_qatar_id 
       AND a.member_seq_id != nvl(v_member_seq_id,0) 
       AND a.deleted_yn = 'N'
       and a.emirate_id not in('11111111111','00000000000');
      v_emirate_count     NUMBER;
      v_row_process    NUMBER(10);
    
BEGIN
  OPEN Get_Mem_Contact_det;
    FETCH Get_Mem_Contact_det INTO Get_Mem_Contact_rec;
      CLOSE Get_Mem_Contact_det;
            ---- Addein in Insurance certificate Cr for Duplicate Qatar id validation
   OPEN prev_policy;
   FETCH prev_policy INTO v_prev_pol_id;
   CLOSE prev_policy;
      
   if v_prev_pol_id is not null   then
     OPEN prev_qatar_id(v_prev_pol_id,Get_Mem_Contact_rec.Tpa_Enrollment_Id);
     FETCH prev_qatar_id INTO v_qid;
     CLOSE prev_qatar_id;
   end if;
        
   if v_qatar_id != nvl(v_qid,0) then
    IF v_qatar_id IS NOT NULL THEN
      OPEN Emirate_id_cur;
      FETCH Emirate_id_cur INTO v_emirate_count;
      CLOSE Emirate_id_cur;
      IF v_emirate_count > 0 THEN
        RAISE_APPLICATION_ERROR(-20398,'  Duplicate Emirate Id.');
      END IF;
    END IF;
    end if;  
        ------  End of duplicate Emirate id validation
      IF Get_Mem_Contact_rec.Mobile_No != v_mobile_no THEN
        v_remarks := 'Mobile Number was Modified from '|| Get_Mem_Contact_rec.Mobile_No || ' TO '||v_mobile_no;
      END IF;
      
      IF Get_Mem_Contact_rec.Emial_Id != v_email THEN
        v_remarks := v_remarks ||'Email id was Modified from '|| Get_Mem_Contact_rec.Emial_Id || ' To '||  v_email;
      END IF;
             --- Added in Insurance Certificate Generation Cr
      IF Get_Mem_Contact_rec.passport_number != v_passport_no THEN
        v_remarks := 'Passport No was Modified from '|| Get_Mem_Contact_rec.passport_number || ' TO '||v_passport_no;
      END IF;
   
      IF Get_Mem_Contact_rec.emirate_id != v_qatar_id THEN
        v_remarks := v_remarks ||'Qatar id was Modified from '|| Get_Mem_Contact_rec.emirate_id || ' To '||  v_qatar_id;
      END IF;
      
   IF v_remarks IS NOT NULL THEN
      INSERT INTO app.TPA_MEM_CONTACT_DTL_LOGS
      (MEMBER_SEQ_ID,
       OLD_MOBILE_NO,
       NEW_MOBILE_NO,
       OLD_EMIAL_ID,
       NEW_EMAIL_NO,
       OLD_PASSPORT_NUMBER,
       NEW_PASSPORT_NUMBER,
       OLD_EMIRATE_ID,
       NEW_EMIRATE_ID,
       UPDATE_DATE,
       UPDATED_BY,
       REMARKS)
      VALUES  
      (v_member_seq_id,
      Get_Mem_Contact_rec.Mobile_No,
      v_mobile_no,
      Get_Mem_Contact_rec.Emial_Id,
      v_email,
      Get_Mem_Contact_rec.passport_number,
      v_passport_no,
      Get_Mem_Contact_rec.emirate_id,
      v_qatar_id,
      SYSDATE,
      null,
      v_remarks
      );
  END IF;
  
  UPDATE APP.TPA_ENR_MEM_ADDRESS A
  SET A.MOBILE_NO = TTK_UTIL_PKG.fn_decrypt(v_mobile_no),
      A.EMAIL_ID= TTK_UTIL_PKG.fn_decrypt(v_email)
  WHERE A.ENR_ADDRESS_SEQ_ID = Get_Mem_Contact_rec.Enr_Address_Seq_Id;
  
  UPDATE APP.TPA_ENR_POLICY_MEMBER A
  SET A.PASSPORT_NUMBER = v_passport_no,
      A.EMIRATE_ID= v_qatar_id
  WHERE A.MEMBER_SEQ_ID = v_member_seq_id;
  
  v_row_process:= SQL%ROWCOUNT;
  
  open v_ref_cur for select v_row_process as process_cnt from dual;
  

COMMIT;
END Update_member_Contact_det;                                                                        
-------------------------------- --------------------------------------------------------------------------
END GENISIS_CALL_CENTER_PKG;

/

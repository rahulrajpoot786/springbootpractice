--------------------------------------------------------
--  DDL for Synonymn CLM_INWARD_SEQ_ID
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."CLM_INWARD_SEQ_ID" FOR "APP"."CLM_INWARD_SEQ_ID";

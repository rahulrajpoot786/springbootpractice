--------------------------------------------------------
--  DDL for Synonymn IDX_GROUPREG_GROUPID
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."IDX_GROUPREG_GROUPID" FOR "APP"."IDX_GROUPREG_GROUPID";

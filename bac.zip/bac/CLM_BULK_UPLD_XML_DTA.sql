--------------------------------------------------------
--  DDL for Synonymn CLM_BULK_UPLD_XML_DTA
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."CLM_BULK_UPLD_XML_DTA" FOR "APP"."CLM_BULK_UPLD_XML_DTA";

--------------------------------------------------------
--  DDL for Synonymn CLM_INWARD_DEL_LOG
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."CLM_INWARD_DEL_LOG" FOR "APP"."CLM_INWARD_DEL_LOG";

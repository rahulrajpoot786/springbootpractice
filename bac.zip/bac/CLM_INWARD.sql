--------------------------------------------------------
--  DDL for Synonymn CLM_INWARD
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."CLM_INWARD" FOR "APP"."CLM_INWARD";

--------------------------------------------------------
--  DDL for Package Body CLM_XML_LOAD_PKG
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "VENUBABU"."CLM_XML_LOAD_PKG" 
is

--===============================================================================
--===============================================================================
--===============================================================================
--===============================================================================

PROCEDURE clear_all(v_flag   varchar2) IS
  
  BEGIN
   
  IF v_flag='HEAD' THEN
    clm_batch_rec:=null;    
    v_ins_seq_id:=NULL;
    v_hosp_seq_id:=NULL;
    clm_rec:=NULL;
    diag_rec:=NULL;
    activity_rec:=NULL;
    observation_rec:=NULL;    
  ELSIF v_flag='CLM' THEN
    clm_rec:=NULL;
    clm_hosp_rec:=null;
    diag_rec:=NULL;
    activity_rec:=NULL;
    observation_rec:=NULL;
    v_activity_count:=0;
  END IF;
    
  END clear_all;
--===============================================================================
PROCEDURE set_clm_details(v_seq_id           IN clm_authorization_details.claim_seq_id%type)
                              
  IS
  
 BEGIN   

     OPEN clm_cur(v_seq_id);
     FETCH clm_cur INTO prev_clm_rec;
     CLOSE clm_cur; 
  
 END set_clm_details;  
--===============================================================================
PROCEDURE save_clm_batch_details(v_clm_batch_seq_id  in out clm_batch_upload_details.clm_batch_seq_id%type,
                                 v_batch_no          in out clm_batch_upload_details.batch_no%type,
                                 v_sender_id         in clm_batch_upload_details.sender_id%type,
                                 v_receiver_id       in clm_batch_upload_details.receiver_id%type,
                                 v_received_date     in clm_batch_upload_details.received_date%type,
                                 v_record_count      in clm_batch_upload_details.record_count%type,
                                 v_batch_tot_amount  in clm_batch_upload_details.batch_tot_amount%type,
                                 v_tpa_office_aeq_id in clm_batch_upload_details.tpa_office_aeq_id%type,
                                 v_batch_status_type in clm_batch_upload_details.batch_status_type%type,
                                 v_benefit_type      in clm_batch_upload_details.benefit_type%type,
                                 v_claim_type        in clm_batch_upload_details.clm_type_gen_type_id%type,
                                 v_submission_type   in clm_batch_upload_details.submission_type_id%type,
                                 v_currency_type     in clm_batch_upload_details.currency_type%type,
                                 v_source_type       in clm_batch_upload_details.source_type_id%type,
                                 v_added_by          in clm_batch_upload_details.added_by%type) IS
                                

CURSOR batch_cur(v_result VARCHAR2, v_length NUMBER) IS SELECT substr(MAX(d.batch_no),1,v_length)
                                          FROM clm_batch_upload_details d
                                         WHERE d.batch_no LIKE v_result||'%';
                                         
CURSOR encounter_cur IS SELECT case when c.general_type_id ='OPTS' then 'OP'
                                            when c.general_type_id ='IPT' then 'IP'
                                            when c.general_type_id = 'HEAC' then 'HC'
                                            when c.general_type_id = 'DAYC' then 'DC' 
                                            when c.general_type_id IN ('MTI', 'OMTI', 'IMTI') then 'MN'
                                            when c.general_type_id = 'DNTL' then 'DN'  
                                            when c.general_type_id = 'OPTC' then  'OC' end
                                          FROM tpa_general_code c
                                         WHERE c.header_type='BENIFIT_TYPE' 
                                         and c.general_type_id =v_benefit_type;                                        
   v_result            varchar2(1000);
   v_last_number       varchar2(100);
   v_flag              varchar2(10);
   v_clm_count         number;
   v_requested_amount  number;
   v_batch_len         number;
   

Cursor batch_status_cur is 
select ud.batch_status_type,ud.batch_tot_amount from app.clm_batch_upload_details ud where ud.clm_batch_seq_id=v_clm_batch_seq_id;

status_rec    batch_status_cur%rowtype;   

CURSOR batch_len_cur(v_clm_type VARCHAR2) IS
  select max(length(b.batch_no))
  from clm_batch_upload_details b
  where b.batch_no like v_clm_type||'%'
  and to_date(b.added_date, 'DD-MM-RRRR') = to_date(sysdate, 'DD-MM-RRRR');
  
BEGIN

  open batch_status_cur;
  fetch batch_status_cur into status_rec;
  close batch_status_cur;
  
 IF NVL(v_clm_batch_seq_id, 0) = 0 THEN
    
    OPEN batch_len_cur(case when v_claim_type = 'CNH' then 'NC' else 'MR' end);
    FETCH batch_len_cur INTO v_batch_len;
    CLOSE batch_len_cur;
    
    IF v_batch_no IS NULL THEN
      IF v_claim_type = 'CNH' THEN
       v_result:= 'NC'||'-'||substr(lpad(v_sender_id,length(v_sender_id),0),-length(v_sender_id))||'-'||to_char(sysdate,'ddmmyyyy')||'-';
       ELSE 
        v_result:= 'MR'||'-'||'00001'||'-'||to_char(sysdate,'ddmmrrrr')||'-'; 
      END IF;
      
      OPEN batch_cur(v_result, v_batch_len);
      FETCH batch_cur INTO v_last_number;
      CLOSE batch_cur;
      
      v_last_number := trim(trailing '-' from v_last_number);
      
      OPEN encounter_cur;
      FETCH encounter_cur INTO v_flag;
      CLOSE encounter_cur;
      
      IF v_last_number IS NULL THEN
        v_result := v_result || '01';
      ELSE
        if v_last_number like '%R' Then
         v_result := v_result ||lpad(TO_NUMBER(substr(v_last_number,-3,1))+1,2,'0');
        else
         v_result := v_result ||lpad(TO_NUMBER(substr(v_last_number,-2,2))+1,2,'0');
        end if;
      END IF;
      IF v_submission_type='DTR' then
       --v_batch_no:=v_result||'-'||v_flag||'-'||'R';
       v_batch_no:=v_result||'-'||'R';
      ELSE
      --v_batch_no:=v_result||'-'||v_flag;
      v_batch_no:=v_result;
      END IF;
    END IF;
    
    INSERT INTO clm_batch_upload_details
      (CLM_BATCH_SEQ_ID,
       BATCH_NO,
       SENDER_ID,
       RECEIVER_ID,
       RECEIVED_DATE,
       TRANSACTION_DATE,
       RECORD_COUNT,
       DISPOSITION_FLAG,
       BATCH_TOT_AMOUNT,
       TPA_OFFICE_AEQ_ID,
       BATCH_STATUS_TYPE,
       clm_type_gen_type_id,
       submission_type_id,
       ADDED_BY,
       ADDED_DATE,
       CURRENCY_TYPE,
       SOURCE_TYPE_ID,
       benefit_type,
       NETWORK_YN)
    VALUES
      (clm_batch_upload_detail_SEQ.Nextval,
       V_BATCH_NO,
       V_SENDER_ID,
       V_RECEIVER_ID,
       V_RECEIVED_DATE,
       SYSDATE,
       V_RECORD_COUNT,
       'PRODUCTION',
       V_BATCH_TOT_AMOUNT,
       V_TPA_OFFICE_AEQ_ID,
       V_BATCH_STATUS_TYPE,
       v_claim_type,
       'DTC',
       V_ADDED_BY,
       SYSDATE,
       v_currency_type,
       v_source_type,
       v_benefit_type,
       'Y') RETURNING CLM_BATCH_SEQ_ID INTO v_clm_batch_seq_id;
  ELSE
     
    if v_batch_status_type='COMP' then 
      select count(1) into v_clm_count from app.clm_authorization_details ad 
      where ad.clm_batch_seq_id=v_clm_batch_seq_id;
      
      select sum(ad.requested_amount) into v_requested_amount from app.clm_authorization_details ad 
      where ad.clm_batch_seq_id=v_clm_batch_seq_id;
     if v_requested_amount!=status_rec.batch_tot_amount then 
        RAISE_APPLICATION_ERROR(-20388,'Claims total amount should be equal to batch total amount.');
     end if;
     if v_clm_count != v_record_count then
       RAISE_APPLICATION_ERROR(-20389,'Entered Claims count should be equal to no of calims recieved count to complete the batch.');
     end if;
     
    end if;
    UPDATE clm_batch_upload_details set
       SENDER_ID             = V_SENDER_ID,
       RECEIVER_ID           = V_RECEIVER_ID,
       RECEIVED_DATE         = V_RECEIVED_DATE,
       RECORD_COUNT          = RECORD_COUNT + V_RECORD_COUNT,
       BATCH_TOT_AMOUNT      = NVL(V_BATCH_TOT_AMOUNT, 0),
       TPA_OFFICE_AEQ_ID     = V_TPA_OFFICE_AEQ_ID,
       BATCH_STATUS_TYPE     = V_BATCH_STATUS_TYPE,
       clm_type_gen_type_id  = v_claim_type,
       submission_type_id    = v_submission_type, 
       UPDATED_DATE          = SYSDATE,
       UPDATED_BY            = v_added_by,
       CURRENCY_TYPE         = v_currency_type,
       SOURCE_TYPE_ID        = v_source_type,
       benefit_type          = v_benefit_type
       WHERE clm_batch_seq_id =v_clm_batch_seq_id;
    
  END IF;

END save_clm_batch_details; 
--===============================================================================
--===============================================================================
PROCEDURE get_header_details(v_header_node IN DBMS_XMLDOM.DOMNode,v_xml IN xmltype,v_file_id IN varchar2)
IS

  v_doc                        DBMS_XMLDOM.DOMDocument;
  v_elem                       DBMS_XMLDOM.DOMElement; 
  v_chld_node                  DBMS_XMLDOM.domnode; 
  v_parent_node                DBMS_XMLDOM.domnode; 
  v_node_list                  DBMS_XMLDOM.DOMNodeList;
  v_batch_no                   varchar2(30);
  v_batch_tot_amount           number;
  v_benefit_type               varchar2(300):='DHPO';
  v_count                      number:=1;
  
BEGIN 
    v_elem:=dbms_xmldom.makeelement(v_header_node);
    v_node_list := xmldom.getChildNodes(v_header_node);
    FOR j IN 0..dbms_xmldom.getLength( v_node_list ) -1 LOOP
       v_parent_node := DBMS_XMLDOM.item(v_node_list, j);
   
      CASE  DBMS_XMLDOM.getNodeName(v_parent_node)
       WHEN 'SenderID' THEN
          v_chld_node := DBMS_XMLDOM.getFirstChild(v_parent_node);
          clm_batch_rec.SENDER_ID:=DBMS_XMLDOM.getNodeValue(v_chld_node);
          v_hosp_seq_id:=TO_NUMBER(pat_xml_load_pkg.get_associated_id('HOS',clm_batch_rec.SENDER_ID));
       WHEN 'ReceiverID' THEN
          v_chld_node := DBMS_XMLDOM.getFirstChild(v_parent_node);
          clm_batch_rec.receiver_ID:=DBMS_XMLDOM.getNodeValue(v_chld_node);
          v_ins_seq_id:=pat_xml_load_pkg.get_associated_id('INS',clm_batch_rec.receiver_ID);
       WHEN 'TransactionDate' THEN
          v_chld_node := DBMS_XMLDOM.getFirstChild(v_parent_node);
          clm_batch_rec.transaction_date:=to_date(DBMS_XMLDOM.getNodeValue(v_chld_node),'dd/mm/yyyy hh24:mi');
       WHEN 'RecordCount' THEN
          v_chld_node := DBMS_XMLDOM.getFirstChild(v_parent_node);
          clm_batch_rec.record_count:=DBMS_XMLDOM.getNodeValue(v_chld_node);
       WHEN 'DispositionFlag' THEN
          v_chld_node := DBMS_XMLDOM.getFirstChild(v_parent_node);
          clm_batch_rec.disposition_flag:=DBMS_XMLDOM.getNodeValue(v_chld_node);
       ELSE NULL;
      END CASE; 
    END LOOP;
 /*   for i in (select error7 from app.temp_test)loop
    WHILE i.error7.existsNode('//Header[' || v_count || ']') = 1 LOOP
    v_benefit_type := i.error7.extract('//Claim/Encounter[' || v_count || ']/Type/text()').getStringVal();
    v_count := v_count + 1;
   END LOOP;
   End loop;
    dbms_output.put_line('v_benefit_type: '||v_benefit_type);*/
    clm_batch_rec.added_by:=1;
   
    save_clm_batch_details(clm_batch_rec.clm_batch_seq_id,v_batch_no,clm_batch_rec.sender_id,clm_batch_rec.receiver_id,clm_batch_rec.transaction_date,clm_batch_rec.record_count,v_batch_tot_amount,'1','COMP',v_benefit_type,'CNH','DTC','AED','ECL',clm_batch_rec.added_by);
  
  update app.clm_batch_upload_details b
  set b.xml_file = v_xml,
      b.file_id  = v_file_id
  where b.clm_batch_seq_id = clm_batch_rec.clm_batch_seq_id;
  commit; 
 
end get_header_details;    

--===============================================================================
PROCEDURE get_claim_details(v_auth_node IN DBMS_XMLDOM.DOMNode)
IS

  v_doc                        DBMS_XMLDOM.DOMDocument;
  v_elem                       DBMS_XMLDOM.DOMElement; 
  v_chld_node                  DBMS_XMLDOM.domnode; 
  v_parent_node                 DBMS_XMLDOM.domnode; 
  v_elem1                       DBMS_XMLDOM.DOMElement; 
  v_chld_node1                  DBMS_XMLDOM.domnode; 
  v_node_list                   DBMS_XMLDOM.DOMNODELIST; 
  v_chld_node_list              DBMS_XMLDOM.DOMNODELIST; 
  v_authorization_type          varchar2(30);
  v_diag_node                   DBMS_XMLDOM.domnode; 
  v_activity_node               DBMS_XMLDOM.domnode;
  type str_tab is table of  DBMS_XMLDOM.domnode ;
  diag_node             str_tab:=str_tab();
  act_node              str_tab:=str_tab();
  v_payerid             tpa_ins_info.tpa_payer_id%type;
  i                     number(4):=0;
  j                     number(4):=0;
  v_rows_processed      number(4);
  v_activity_net        number;
  v_cnt                 number;
  v_type                varchar2(100);
  v_commet              varchar2(4000);
   
  v_policy_group_seq_id tpa_enr_policy_group.policy_group_seq_id%TYPE;
  cursor pol_mem_cur (v_enrollment_id app.tpa_enr_policy_member.tpa_enrollment_id%type)is 
        select tem.mem_name,tem.mem_age,tep.policy_seq_id,tep.enrol_type_id,
        (nvl(f.sum_insured,0) - nvl(f.utilised_sum_insured,0)) AS ava_sum_insured
        from app.tpa_enr_policy_member tem
        join app.tpa_enr_policy_group teg
          on (tem.policy_group_seq_id = teg.policy_group_seq_id)
          join app.tpa_enr_policy tep
            on (teg.policy_seq_id = tep.policy_seq_id)
           LEFT OUTER JOIN tpa_enr_balance F ON (teg.policy_group_seq_id = f.policy_group_seq_id)
             where (tem.tpa_enrollment_id = v_enrollment_id or tem.global_net_member_id = v_enrollment_id)
            and ( tem.mem_general_type_id != 'PFL' AND tem.member_seq_id = F.member_seq_id OR F.member_seq_id IS NULL OR tem.member_seq_id IS NULL );
  
 pol_mem_rec      pol_mem_cur%rowtype;
 
  cursor header_cur(v_claim_id     clm_authorization_details.claim_id%type)is
  select *
  from app.clm_batch_upload_details cbud
  left outer join app.clm_authorization_details cad
    on (cbud.clm_batch_seq_id = cad.clm_batch_seq_id)
 where cad.claim_id = v_claim_id; 
  
  header_rec  header_cur%rowtype;
  v_result_set   sys_refcursor;
 
BEGIN 
   clear_all('CLM');
    v_elem:=dbms_xmldom.makeelement(v_auth_node);
    v_node_list := xmldom.getChildNodes(v_auth_node);
    FOR k IN 0..dbms_xmldom.getLength( v_node_list ) -1 LOOP
       v_parent_node := DBMS_XMLDOM.item(v_node_list, k);   
       CASE  DBMS_XMLDOM.getNodeName(v_parent_node)
       WHEN 'ID' THEN
          v_chld_node := DBMS_XMLDOM.getFirstChild(v_parent_node);
          clm_rec.claim_id:=DBMS_XMLDOM.getNodeValue(v_chld_node);      
       WHEN 'IDPayer' THEN
          v_chld_node := DBMS_XMLDOM.getFirstChild(v_parent_node);
          clm_rec.id_payer:=DBMS_XMLDOM.getNodeValue(v_chld_node);
          clm_rec.parent_claim_seq_id:=pat_xml_load_pkg.get_associated_id('CLM',clm_rec.id_payer);
       WHEN 'MemberID' THEN
          v_chld_node := DBMS_XMLDOM.getFirstChild(v_parent_node);
          clm_rec.tpa_enrollment_id:=upper(DBMS_XMLDOM.getNodeValue(v_chld_node));
          clm_rec.member_seq_id:=pat_xml_load_pkg.get_associated_id('MEM',upper(clm_rec.tpa_enrollment_id));
              open pol_mem_cur(clm_rec.tpa_enrollment_id);
              fetch pol_mem_cur into pol_mem_rec;
              close pol_mem_cur;
     WHEN 'PayerID' THEN
          v_chld_node := DBMS_XMLDOM.getFirstChild(v_parent_node);
          v_payerid:=DBMS_XMLDOM.getNodeValue(v_chld_node);
          clm_rec.Ins_Seq_Id:=pat_xml_load_pkg.get_associated_id('INS',v_payerid);       
       WHEN 'ProviderID' THEN
          v_chld_node := DBMS_XMLDOM.getFirstChild(v_parent_node);
          clm_hosp_rec.hosp_seq_id:=pat_xml_load_pkg.get_associated_id('HOS',DBMS_XMLDOM.getNodeValue(v_chld_node));       
          clm_hosp_rec.provider_id :=DBMS_XMLDOM.getNodeValue(v_chld_node);
       WHEN 'EmiratesIDNumber' THEN
          v_chld_node := DBMS_XMLDOM.getFirstChild(v_parent_node);
          clm_rec.emirate_id:=DBMS_XMLDOM.getNodeValue(v_chld_node);
       WHEN 'Gross' THEN
          v_chld_node := DBMS_XMLDOM.getFirstChild(v_parent_node);
          clm_rec.tot_disc_gross_amount:=DBMS_XMLDOM.getNodeValue(v_chld_node);
          clm_rec.tot_gross_amount:=DBMS_XMLDOM.getNodeValue(v_chld_node);       
       WHEN 'PatientShare' THEN
          v_chld_node := DBMS_XMLDOM.getFirstChild(v_parent_node);
          clm_rec.tot_patient_share_amount:=DBMS_XMLDOM.getNodeValue(v_chld_node);
       WHEN 'Net' THEN
          v_chld_node := DBMS_XMLDOM.getFirstChild(v_parent_node);
          clm_rec.tot_net_amount:=DBMS_XMLDOM.getNodeValue(v_chld_node);
       WHEN 'Encounter' THEN
          v_elem1    := dbms_xmldom.makeelement(v_parent_node);
          v_chld_node_list := xmldom.getChildNodes(v_parent_node);
         FOR k IN 0..dbms_xmldom.getLength( v_chld_node_list ) -1 LOOP
           v_chld_node := DBMS_XMLDOM.item(v_chld_node_list, k);
           CASE  DBMS_XMLDOM.getNodeName(v_chld_node)
            WHEN 'FacilityID' THEN
            v_chld_node1 := DBMS_XMLDOM.getFirstChild(v_chld_node);
            clm_rec.encounter_facility_id:=DBMS_XMLDOM.getNodeValue(v_chld_node1);
            WHEN 'Type' THEN
            v_chld_node1 := DBMS_XMLDOM.getFirstChild(v_chld_node);
            clm_rec.encounter_type_id:=DBMS_XMLDOM.getNodeValue(v_chld_node1);
            clm_rec.benifit_type:= pat_xml_load_pkg.get_associated_id('BENEFIT',clm_rec.encounter_type_id);
            WHEN 'Start' THEN
            v_chld_node1 := DBMS_XMLDOM.getFirstChild(v_chld_node);
            clm_rec.date_of_hospitalization:=to_date(DBMS_XMLDOM.getNodeValue(v_chld_node1),'dd/mm/yyyy hh24:mi');
            WHEN 'End' THEN
            v_chld_node1 := DBMS_XMLDOM.getFirstChild(v_chld_node);
            clm_rec.date_of_discharge:=to_date(DBMS_XMLDOM.getNodeValue(v_chld_node1),'dd/mm/yyyy hh24:mi');            
            WHEN 'StartType' THEN
            v_chld_node1 := DBMS_XMLDOM.getFirstChild(v_chld_node);
            clm_rec.encounter_start_type:=DBMS_XMLDOM.getNodeValue(v_chld_node1);
            WHEN 'EndType' THEN
            v_chld_node1 := DBMS_XMLDOM.getFirstChild(v_chld_node);
            clm_rec.encounter_end_type:=DBMS_XMLDOM.getNodeValue(v_chld_node1);
            WHEN 'DateofLMP' THEN
            v_chld_node1 := DBMS_XMLDOM.getFirstChild(v_chld_node);
            clm_rec.lmp_date :=DBMS_XMLDOM.getNodeValue(v_chld_node1);
            WHEN 'ConceptionType' THEN
            v_chld_node1 := DBMS_XMLDOM.getFirstChild(v_chld_node);
            clm_rec.delvry_mod_type :=DBMS_XMLDOM.getNodeValue(v_chld_node1);           
            WHEN 'AuthorizationNo' THEN
            v_chld_node1 := DBMS_XMLDOM.getFirstChild(v_chld_node);
            clm_rec.auth_number :=DBMS_XMLDOM.getNodeValue(v_chld_node1);
            WHEN 'EventNo' THEN
            v_chld_node1 := DBMS_XMLDOM.getFirstChild(v_chld_node);
            clm_rec.event_no :=DBMS_XMLDOM.getNodeValue(v_chld_node1);
            ELSE 
              NULL;
            END CASE;
          END LOOP;

       WHEN 'Diagnosis' THEN 
         diag_node.extend; 
         i:=i+1;
         diag_node(i):= v_parent_node; 
                                
       WHEN 'Activity' THEN
         act_node.extend; 
         j:=j+1;
         act_node(j):= v_parent_node; 
        WHEN 'Resubmission' THEN
         v_elem1    := dbms_xmldom.makeelement(v_parent_node);
          v_chld_node_list := xmldom.getChildNodes(v_parent_node);
         FOR k IN 0..dbms_xmldom.getLength( v_chld_node_list ) -1 LOOP
           v_chld_node := DBMS_XMLDOM.item(v_chld_node_list, k);
           CASE  DBMS_XMLDOM.getNodeName(v_chld_node)
            WHEN 'Type' THEN
              v_chld_node1 := DBMS_XMLDOM.getFirstChild(v_chld_node);
              v_type := DBMS_XMLDOM.getNodeValue(v_chld_node1);
              --dbms_output.put_line(v_type);
            WHEN 'Comment' THEN
              v_chld_node1 := DBMS_XMLDOM.getFirstChild(v_chld_node);
              v_commet := DBMS_XMLDOM.getNodeValue(v_chld_node1);
               --dbms_output.put_line(v_commet);
            WHEN 'Attachment' THEN
              v_chld_node1 := DBMS_XMLDOM.getFirstChild(v_chld_node);
               --v_attachment := DBMS_XMLDOM.getNodeValue(v_chld_node1);
              --v_attachment := to_clob(DBMS_XMLDOM.getNodeValue(v_chld_node1));
              --v_attachment := lpad('x',32767, 'x');
             /* LOOP
               numBytes := 100;
                  v_attachment.read ( buffer, numBytes);
              if numBytes <= 0 then
                    exit;
               end if;
               END LOOP;
              update app.temp_test
              set error13 = buffer; 
              commit;*/
               --dbms_xmldom.writeToBuffer(v_chld_node1, v_attachment);
               --dbms_output.put_line('First :'||v_buf);
               ELSE 
              NULL;
            END CASE;
          END LOOP;                  
       ELSE 
         NULL;
      END CASE;
    END LOOP;
    
     IF /*v_ins_seq_id!=clm_rec.Ins_Seq_Id or*/ v_ins_seq_id is null then
       clm_rec.remarks:='Payer id is wrong/mismatch in xml';
     END IF; 
         IF (clm_rec.claim_id IS NULL /*OR  clm_rec.member_seq_id IS NULL*/ OR clm_rec.tot_disc_gross_amount IS NULL 
           OR clm_rec.encounter_facility_id IS NULL OR clm_rec.encounter_type_id IS NULL 
           OR clm_rec.date_of_hospitalization IS NULL 
           OR (clm_rec.tot_patient_share_amount IS NULL OR clm_rec.tot_patient_share_amount < 0 )
           OR (clm_rec.tot_net_amount IS NULL OR clm_rec.tot_net_amount < 0 ))THEN
            raise_application_error(-20405,'DATA SHOULD NOT BE EMPTY OR LESS THAN 0 IN CLAIMS PART.');
         END IF;
         IF (clm_rec.tot_patient_share_amount+clm_rec.tot_net_amount>clm_rec.tot_gross_amount) THEN
            raise_application_error(-20406,'Sum of patient share and net amt should not be Greater than gross amt.');
         END IF;
     
    /* select sum(x.net) into v_activity_net
        from app.temp_test t
       , xmltable('Claim.Submission/Claim/Activity'
           passing t.error7 columns Net varchar2(15) path 'Net' ) x;  
      
      IF (clm_rec.tot_net_amount != v_activity_net) THEN
            raise_application_error(-20407,'Sum of net amt in activity level not matching claim level net amt.');
         END IF;    */       
       select count(*) into v_cnt
        from app.dha_providers_master m
        where m.provider_id = clm_rec.encounter_facility_id;
      
         IF (v_cnt = 0) THEN
            raise_application_error(-20408,'facility_id is not valid.');
         END IF;
   OPEN header_cur(clm_rec.claim_id);
   FETCH header_cur into header_rec;
   CLOSE header_cur;
      IF (clm_rec.benifit_type = 'IPT' AND clm_rec.date_of_discharge IS NULL) 
       OR (clm_rec.benifit_type = 'IPT' AND clm_rec.encounter_end_type  IS NULL)THEN 
         raise_application_error(-20409,'for inpatient discharge date should not be null.');
       END IF; 
        IF (to_char(clm_rec.date_of_hospitalization,'dd-mon-yyyy')> to_char(header_rec.transaction_date,'dd-mon-yyyy')
         OR (clm_rec.date_of_discharge IS NOT NULL AND to_char(clm_rec.date_of_discharge,'dd-mon-yyyy')<to_char(header_rec.transaction_date-1*12*30,'dd-mon-yyyy'))
         OR (clm_rec.date_of_discharge IS NULL AND to_char(clm_rec.date_of_hospitalization,'dd-mon-yyyy')<to_char(header_rec.transaction_date-1*12*30,'dd-mon-yyyy')))THEN     
             raise_application_error(-20410,'End date/Start date is not valid.');
        END IF;
         
          save_clm_details(clm_rec.claim_seq_id,
                           clm_batch_rec.clm_batch_seq_id,
				                   clm_rec.pat_auth_seq_id,
				                   clm_rec.parent_claim_seq_id,
				                   clm_rec.claim_number,
                           clm_rec.claim_file_number,
				                   clm_rec.settlement_number,
				                   clm_batch_rec.transaction_date,
				                   'ECLM',  
				                   clm_rec.date_of_hospitalization, 
				                   nvl(clm_rec.date_of_discharge,clm_rec.date_of_hospitalization), 
				                   'CNH', 
                           clm_rec.claim_sub_type,  
				                   clm_rec.member_seq_id, 
				                   clm_rec.tpa_enrollment_id,
				                   pol_mem_rec.mem_name, 
				                   pol_mem_rec.mem_age,  
				                   clm_rec.ins_seq_id, 
				                   pol_mem_rec.policy_seq_id,
                           pol_mem_rec.enrol_type_id,
				                   clm_rec.emirate_id, 
				                   clm_rec.encounter_type_id,
				                   clm_rec.encounter_start_type,
				                   nvl(clm_rec.encounter_end_type,'1'), 
				                   clm_rec.encounter_facility_id, 
                            null,--V_PAYER_ID
				                    pol_mem_rec.ava_sum_insured,--V_AVA_SUM_INSURED
				                    null,--V_CURRENCY_TYPE
				                    null,--V_CLM_STATUS_TYPE_ID
				                    clm_rec.remarks,
				                    null,--V_INVOICE_NUMBER
				                    clm_rec.tot_net_amount, --V_REQUESTED_AMOUNT
				                    clm_rec.clinician_id, 
				                    null,--V_SYSTEM_OF_MEDICINE_TYPE_ID
				                    null,--V_ACCIDENT_RELATED_TYPE_ID
				                    null,--V_PRIORITY_GENERAL_TYPE_ID
				                    null,--V_NETWORK_YN
				                    clm_rec.benifit_type,
				                    null,--V_GRAVIDA
				                    null,--V_PARA
				                    null,--V_LIVE
				                    null,--V_ABORTION
				                    null,--V_PRESENTING_COMPLAINTS
				                    null,--V_MEDICAL_OPINION_REMARKS
                                    v_hosp_seq_id,
				                    clm_hosp_rec.hosp_name,
				                    clm_hosp_rec.address_1,
				                    clm_hosp_rec.state_name,
				                    clm_hosp_rec.city_name,
				                    clm_hosp_rec.pin_code,
                                    clm_hosp_rec.off_phone_no_1,
				                    clm_hosp_rec.office_fax_no,
				                    clm_hosp_rec.provider_id,
				                    null,--V_COUNTRY_TYPE_ID
				                    clm_hosp_rec.clinician_name,--v_clinician_name
				                    clm_batch_rec.added_by,
									          v_type,
                            v_commet,
                            null,
                            null,
                            clm_rec.lmp_date,
                            clm_rec.delvry_mod_type,
                            clm_rec.auth_number,
                            clm_rec.conversion_rate,
                            clm_rec.event_no,
				                    v_rows_processed);
                         
/*        save_clm_details(clm_rec.claim_seq_id,clm_batch_rec.clm_batch_seq_id,clm_rec.pat_auth_seq_id,clm_rec.parent_claim_seq_id,clm_rec.claim_number,
                           clm_rec.claim_file_number,clm_rec.settlement_number,clm_batch_rec.transaction_date,'ECLM',  clm_rec.date_of_hospitalization, clm_rec.date_of_discharge, 'CNH', 
                           clm_rec.claim_sub_type,  clm_rec.member_seq_id, clm_rec.tpa_enrollment_id,pol_mem_rec.mem_name, pol_mem_rec.mem_age,  clm_rec.ins_seq_id, pol_mem_rec.policy_seq_id,
                           pol_mem_rec.enrol_type_id,clm_rec.emirate_id, clm_rec.encounter_type_id,clm_rec.encounter_start_type,clm_rec.encounter_end_type, clm_rec.encounter_facility_id, 
                           null,null,null,null, clm_rec.remarks,null,null, clm_rec.clinician_id, null,null,null,null,clm_rec.benifit_type,null,null,null,null,null,null,   
                           v_hosp_seq_id,clm_hosp_rec.hosp_name,clm_hosp_rec.address_1,clm_hosp_rec.state_name,clm_hosp_rec.city_name,clm_hosp_rec.pin_code,
                           clm_hosp_rec.off_phone_no_1,clm_hosp_rec.office_fax_no,clm_rec.id_payer,null,null,clm_batch_rec.added_by,v_rows_processed);*/
  
/*claim_pkg.save_clm_details(clm_rec.claim_seq_id,  clm_batch_rec.clm_batch_seq_id, clm_rec.pat_auth_seq_id,  clm_rec.parent_claim_seq_id,  
                      clm_batch_rec.transaction_date,clm_rec.date_of_discharge,  'ECLM',  clm_rec.date_of_hospitalization, 'CTM', clm_rec.claim_sub_type,  
                      clm_rec.member_seq_id,  clm_rec.tpa_enrollment_id,  clm_rec.claim_number,  clm_rec.settlement_number,  
                      clm_rec.mem_name,  clm_rec.mem_age,  clm_rec.ins_seq_id,   clm_rec.policy_seq_id,  
                      clm_rec.emirate_id,clm_rec.claim_id,clm_rec.id_payer,  clm_rec.encounter_type_id,  clm_rec.encounter_facility_id,    clm_rec.remarks, v_hosp_seq_id,  clm_hosp_rec.hosp_name,
                      clm_hosp_rec.address_1,clm_hosp_rec.address_2,clm_hosp_rec.address_3,clm_hosp_rec.state_name,clm_hosp_rec.city_name,clm_hosp_rec.pin_code,clm_hosp_rec.off_phone_no_1,
                      clm_hosp_rec.off_phone_no_2,clm_hosp_rec.office_fax_no,clm_rec.encounter_start_type,clm_rec.encounter_end_type, clm_batch_rec.added_by,v_rows_processed);
*/   
    update app.clm_authorization_details
    set tot_disc_gross_amount    = clm_rec.tot_disc_gross_amount,
        tot_patient_share_amount = clm_rec.tot_patient_share_amount
    where claim_seq_id = clm_rec.claim_seq_id;
    commit;
    
   IF diag_node.FIRST IS NOT NULL THEN
    for i in diag_node.first..diag_node.last loop
      get_diagnosys_details(diag_node(i));
    end loop;
   END IF; 
   
   IF act_node.FIRST IS NOT NULL THEN
    for j in act_node.first..act_node.last loop
      v_activity_count:=v_activity_count+1;
      get_activity_details(act_node(j));
    end loop;
   END IF; 
   
    update app.clm_authorization_details
    set invoice_number = clm_rec.claim_id
    where claim_seq_id = clm_rec.claim_seq_id;
    commit;

   calculate_authorization(clm_rec.claim_seq_id,clm_hosp_rec.hosp_seq_id,clm_rec.tot_allowed_amount,v_result_set,clm_batch_rec.added_by );    
   save_settlement(clm_rec.claim_seq_id,clm_rec.member_seq_id,clm_rec.settlement_number,clm_rec.date_of_hospitalization,NVL(clm_rec.tot_allowed_amount,0),'ECL',clm_rec.clm_status_type_id,clm_rec.remarks,clm_batch_rec.added_by,v_rows_processed);
 
end get_claim_details;
--===============================================================================
PROCEDURE get_diagnosys_details(v_diagnosys_node IN DBMS_XMLDOM.DOMNode)
IS

  v_doc                          DBMS_XMLDOM.DOMDocument;
  v_elem                         DBMS_XMLDOM.DOMElement; 
  v_chld_node                    DBMS_XMLDOM.domnode; 
  v_parent_node                  DBMS_XMLDOM.domnode; 
  v_node_list                    DBMS_XMLDOM.DOMNodeList;
  v_diagnosys_type               tpa_general_code.general_type_id%type;
  
BEGIN 
    diag_rec:=null;
    v_elem:=dbms_xmldom.makeelement(v_diagnosys_node);
    v_node_list := xmldom.getChildNodes(v_diagnosys_node);
    FOR j IN 0..dbms_xmldom.getLength( v_node_list ) -1 LOOP
       v_parent_node := DBMS_XMLDOM.item(v_node_list, j);
         CASE  DBMS_XMLDOM.getNodeName(v_parent_node)
            WHEN 'Type' THEN
            v_chld_node := DBMS_XMLDOM.getFirstChild(v_parent_node);
            v_diagnosys_type:=pat_xml_load_pkg.get_associated_id('GEN',DBMS_XMLDOM.getNodeValue(v_chld_node),'DIAG');
            WHEN 'Code' THEN
            v_chld_node := DBMS_XMLDOM.getFirstChild(v_parent_node);
            diag_rec.diagnosys_code:=DBMS_XMLDOM.getNodeValue(v_chld_node);
            diag_rec.icd_code_seq_id:=pat_xml_load_pkg.get_associated_id('ICD',diag_rec.diagnosys_code);
            ELSE 
              NULL;
         END CASE; 
     END LOOP;   
     IF diag_rec.icd_code_seq_id IS NULL THEN
            raise_application_error(-20411,'ICD Code not valid.');
      END IF; 
               
     diag_rec.primary_ailment_yn:=case when v_diagnosys_type='PRPL' THEN 'Y' ELSE 'N' END;
     diag_rec.icd_code_seq_id:=pat_xml_load_pkg.get_associated_id('ICD',diag_rec.diagnosys_code);
     pat_xml_load_pkg.save_diagnosys_details(diag_rec.diag_seq_id ,null,clm_rec.claim_seq_id,diag_rec.icd_code_seq_id,diag_rec.diagnosys_code,diag_rec.primary_ailment_yn,clm_batch_rec.added_by);
 
  
end get_diagnosys_details;

--===============================================================================
PROCEDURE get_activity_details(v_activity_node IN DBMS_XMLDOM.DOMNode)
IS

  v_doc                        DBMS_XMLDOM.DOMDocument;
  v_elem                       DBMS_XMLDOM.DOMElement; 
  v_chld_node                  DBMS_XMLDOM.domnode; 
  v_parent_node                DBMS_XMLDOM.domnode; 
  v_node_list                  DBMS_XMLDOM.DOMNodeList;
  v_observation_node           DBMS_XMLDOM.domnode; 
  type rec is record(node DBMS_XMLDOM.domnode);
  type str_tab is table of  rec ;
  observ_node    str_tab:=str_tab();
  i     number(4):=0;
 
 CURSOR diag_cur IS
 select dd.diagnosys_code from diagnosys_details dd
 where dd.pat_auth_seq_id = clm_rec.pat_auth_seq_id
 and dd.remarks is not null;
 
 diag_rec       diag_cur%rowtype;
 cursor header_cur(v_claim_id     clm_authorization_details.claim_id%type)is
  select *
  from app.clm_batch_upload_details cbud
  left outer join app.clm_authorization_details cad
    on (cbud.clm_batch_seq_id = cad.clm_batch_seq_id)
 where cad.claim_id = v_claim_id; 
  
  header_rec  header_cur%rowtype;
  v_cnt          number;
-------tariff------  
CURSOR clm_tariff_cur(v_seq_id pat_activity_details.claim_seq_id%type) IS
SELECT hd.hosp_seq_id,tip.product_cat_type_id,tep.ins_seq_id,tep.group_reg_seq_id,pad.claim_seq_id,pad.claim_type,pad.network_yn,pad.policy_seq_id,tep.tariff_type_id
FROM clm_authorization_details pad
JOIN clm_hospital_details hd on (hd.claim_seq_id=pad.claim_seq_id)
JOIN tpa_enr_policy tep ON (pad.policy_seq_id=tep.policy_seq_id)
JOIN tpa_ins_product tip ON (tep.product_seq_id=tip.product_seq_id)
WHERE pad.claim_seq_id=v_seq_id;

clm_tariff_rec             clm_tariff_cur%ROWTYPE;


CURSOR provider_network(v_hosp_seq number,v_product_net_type varchar2) IS
SELECT i.primary_network, ny.network_type, ny.network_yn, gc.sort_no
  FROM tpa_hosp_info i, app.tpa_hosp_network ny, app.tpa_general_code gc
 where ny.hosp_seq_id = i.hosp_seq_id
   and gc.general_type_id = ny.network_type
   and gc.header_type = 'PROVIDER_NETWORK'
   and ny.network_yn = 'Y'
   and i.hosp_seq_id = v_hosp_seq
   and gc.sort_no =
       (SELECT min(gc.sort_no)
          FROM tpa_hosp_info        i,
               app.tpa_hosp_network ny,
               app.tpa_general_code gc
         where ny.hosp_seq_id = i.hosp_seq_id
           and gc.general_type_id = ny.network_type
           and gc.header_type = 'PROVIDER_NETWORK'
           and ny.network_yn = 'Y'
           and i.hosp_seq_id = v_hosp_seq
           and gc.sort_no >=
               (SELECT min(gc.sort_no)
                  FROM tpa_hosp_info        i,
                       app.tpa_hosp_network ny,
                       app.tpa_general_code gc
                 where ny.hosp_seq_id = i.hosp_seq_id
                   and gc.general_type_id = ny.network_type
                   and gc.header_type = 'PROVIDER_NETWORK'
                   and i.hosp_seq_id = v_hosp_seq
                   and gc.general_type_id = v_product_net_type))
 order by gc.sort_no;

cursor act_tariff_cur(v_hosp_seq number,v_ins_seq_id number,v_network_type varchar2,v_act_code varchar2,v_start_date date) is 
select  thtd.gross_amount ,
           thtd.disc_amount,
           thtd.gross_amount- thtd.disc_amount as disc_gross_amount,
           thtd.bundle_id,
           thtd.package_id,
           thtd.internal_code,
           tamd.act_mas_dtl_seq_id as activity_seq_id,
           tamd.activity_code,
           tatc.activity_type_id 
           from tpa_activity_master_details tamd
    JOIN tpa_activity_type_codes tatc ON (tamd.activity_type_seq_id=tatc.activity_type_seq_id)
    JOIN tpa_hosp_tariff_details thtd ON (tamd.act_mas_dtl_seq_id=thtd.activity_seq_id)
    WHERE thtd.hosp_seq_id=v_hosp_seq
    AND thtd.ins_seq_id=v_ins_seq_id
    AND thtd.network_type=v_network_type
    AND v_start_date BETWEEN  thtd.start_date AND NVL(thtd.end_date,v_start_date)
    AND tamd.activity_code=upper(v_act_code);

provider_rec   provider_network%rowtype;
v_product_network_type    varchar2(20);
v_count   number(10);
v_tariff_ins_seq_id           number(10);
v_tariff_count                number(10);
v_tpa_ins_seq_id              number(10);
v_activity_type_seq_id        number(10);

-------tariff------
CURSOR PHARMACY_DISCOUNT(v_hosp_seq number) IS
SELECT A.DISC_PERCENT FROM app.tpa_hosp_tariff_details a where a.acitivity_type_seq_id=5 and a.hosp_seq_id=v_hosp_seq; 
 
 V_PHARMACY_DISC               NUMBER; 

CURSOR clin_name_cur(v_clinician_id varchar2) is select nvl(hp.contact_name,m.professional_name) as professional_name  from app.dha_clinicians_list_master m 
  left outer join app.tpa_hosp_professionals hp on (m.clinitian_id=hp.professional_id)
  where m.clinitian_id=v_clinician_id;

v_clinician_name    varchar2(100);
BEGIN 
   activity_rec:=null;
    v_elem:=dbms_xmldom.makeelement(v_activity_node);
    v_node_list := xmldom.getChildNodes(v_activity_node);
 FOR j IN 0..dbms_xmldom.getLength( v_node_list ) -1 LOOP   
    v_parent_node := DBMS_XMLDOM.item(v_node_list, j);  
    CASE  DBMS_XMLDOM.getNodeName(v_parent_node)
    WHEN 'ID' THEN
    v_chld_node := DBMS_XMLDOM.getFirstChild(v_parent_node);
    activity_rec.activity_id:=DBMS_XMLDOM.getNodeValue(v_chld_node);
    WHEN 'Start' THEN
    v_chld_node := DBMS_XMLDOM.getFirstChild(v_parent_node);
    activity_rec.start_date:=to_date(DBMS_XMLDOM.getNodeValue(v_chld_node),'dd/mm/yyyy hh24:mi');
    WHEN 'Type' THEN
    v_chld_node := DBMS_XMLDOM.getFirstChild(v_parent_node);
    activity_rec.activity_type:=DBMS_XMLDOM.getNodeValue(v_chld_node);
    WHEN 'Code' THEN
    v_chld_node := DBMS_XMLDOM.getFirstChild(v_parent_node);
    activity_rec.code:=DBMS_XMLDOM.getNodeValue(v_chld_node);
    --dbms_output.put_line(activity_rec.code);
    WHEN 'Quantity' THEN
    v_chld_node := DBMS_XMLDOM.getFirstChild(v_parent_node);
    activity_rec.quantity:=DBMS_XMLDOM.getNodeValue(v_chld_node);
    WHEN 'Net' THEN
    v_chld_node := DBMS_XMLDOM.getFirstChild(v_parent_node);
    activity_rec.gross_amount:=DBMS_XMLDOM.getNodeValue(v_chld_node);
    activity_rec.net_amount :=DBMS_XMLDOM.getNodeValue(v_chld_node);
    WHEN 'Clinician' THEN
    v_chld_node := DBMS_XMLDOM.getFirstChild(v_parent_node);
    activity_rec.clinician_id:=DBMS_XMLDOM.getNodeValue(v_chld_node);      
    WHEN 'Observation' THEN
      observ_node.extend;
      i:=i+1;
      observ_node(i).node:=v_parent_node;
    WHEN 'PriorAuthorizationID' THEN
    v_chld_node := DBMS_XMLDOM.getFirstChild(v_parent_node);
    activity_rec.PRIOR_AUTHID:=DBMS_XMLDOM.getNodeValue(v_chld_node);  --need to check with mohan
    clm_rec.auth_number := DBMS_XMLDOM.getNodeValue(v_chld_node);
    clm_rec.pat_auth_seq_id:=pat_xml_load_pkg.get_associated_id('PAT',clm_rec.auth_number); 
            
  ELSE NULL;
  END CASE; 
 END LOOP; 
 
  activity_rec.Clinician_Remarks:=pat_xml_load_pkg.validate_clinician(v_hosp_seq_id,activity_rec.clinician_id); 
  activity_rec.activity_seq_id:=pat_xml_load_pkg.get_associated_id('ACT',activity_rec.code);
  -------tariff-------------------------------------------
  OPEN  clm_tariff_cur(clm_rec.claim_seq_id);
  FETCH clm_tariff_cur INTO clm_tariff_rec;
  CLOSE clm_tariff_cur;

 OPEN provider_network(clm_tariff_rec.hosp_seq_id,clm_tariff_rec.product_cat_type_id);
 FETCH provider_network INTO provider_rec;
 CLOSE provider_network;
 
 IF clm_tariff_rec.Ins_Seq_Id IS NOT NULL THEN 
   SELECT COUNT(*) INTO v_tariff_count from tpa_hosp_tariff_details d 
   where d.ins_seq_id=clm_tariff_rec.Ins_Seq_Id and d.hosp_seq_id=clm_tariff_rec.hosp_seq_id;
  END IF; 
 
 select ii.ins_seq_id into v_tpa_ins_seq_id from app.tpa_ins_info ii where ii.ins_comp_code_number='TPA033'; 
   IF v_tariff_count>0 THEN 
     v_tariff_ins_seq_id:=clm_tariff_rec.Ins_Seq_Id;
   ELSE 
     v_tariff_ins_seq_id:=v_tpa_ins_seq_id;
   END IF;   
  
  IF nvl(clm_tariff_rec.claim_type,'CNH')!='CTM' then 
    IF clm_tariff_rec.tariff_type_id='HSPL' THEN
    
   v_product_network_type:=provider_rec.network_type;
  
   
   select count(1) into v_count           
    from tpa_activity_master_details tamd
    JOIN tpa_activity_type_codes tatc ON (tamd.activity_type_seq_id=tatc.activity_type_seq_id)
    JOIN tpa_hosp_tariff_details thtd ON (tamd.act_mas_dtl_seq_id=thtd.activity_seq_id)
    WHERE thtd.hosp_seq_id=clm_tariff_rec.hosp_seq_id
    AND thtd.ins_seq_id=v_tariff_ins_seq_id
    AND thtd.network_type=v_product_network_type
    AND activity_rec.start_date BETWEEN  thtd.start_date AND NVL(thtd.end_date,activity_rec.start_date)
    AND tamd.activity_code=upper(activity_rec.code);
   
    if length(activity_rec.code)>=15 then
     
       v_activity_type_seq_id:=5;
    end if;   
    if v_activity_type_seq_id=5 then
      select count(1) into v_count from tpa_pharmacy_master_details tamd
      JOIN tpa_activity_type_codes tatc ON (tamd.activity_type_seq_id=tatc.activity_type_seq_id)
      WHERE tamd.activity_code=upper(activity_rec.code)
      AND tamd.start_date <= activity_rec.start_date and nvl(tamd.end_date,activity_rec.start_date) >=activity_rec.start_date; 
     
     else
      select count(1) into v_count           
       from tpa_activity_master_details tamd
       JOIN tpa_activity_type_codes tatc ON (tamd.activity_type_seq_id=tatc.activity_type_seq_id)
       JOIN tpa_hosp_tariff_details thtd ON (tamd.act_mas_dtl_seq_id=thtd.activity_seq_id)
       WHERE thtd.hosp_seq_id=clm_tariff_rec.hosp_seq_id
       AND thtd.ins_seq_id=v_tariff_ins_seq_id
       AND thtd.network_type=v_product_network_type
       AND activity_rec.start_date BETWEEN  thtd.start_date AND NVL(thtd.end_date,activity_rec.start_date)
       AND tamd.activity_code=upper(activity_rec.code); 
      end if;
   
   if v_activity_type_seq_id=5 then 
      OPEN PHARMACY_DISCOUNT(clm_tariff_rec.hosp_seq_id);
      FETCH PHARMACY_DISCOUNT INTO V_PHARMACY_DISC;
      CLOSE PHARMACY_DISCOUNT;
     if v_count>0 then
          select 
           tamd.unit_price as gross_amount ,
           ((tamd.unit_price*NVL(v_pharmacy_disc,0))/100)*(activity_rec.quantity) as disc_amount,
           ((tamd.unit_price*NVL(v_pharmacy_disc,0))/100)*(activity_rec.quantity) as unit_discount,
           tamd.unit_price as disc_gross_amount,
           null as bundle_id,
           null as package_id,
           null as internal_code,
           tamd.act_mas_dtl_seq_id as activity_seq_id,
           tamd.activity_code,
           tatc.activity_type_id
           into activity_rec.gross_amount,
                activity_rec.discount_amount,
                activity_rec.unit_discount_amount,
                activity_rec.disc_gross_amount,
                activity_rec.bundle_id,
                activity_rec.package_id,
                activity_rec.internal_code,
                activity_rec.activity_seq_id,
                activity_rec.code,
                activity_rec.activity_type
       from tpa_pharmacy_master_details tamd
       JOIN tpa_activity_type_codes tatc ON (tamd.activity_type_seq_id=tatc.activity_type_seq_id)
       WHERE tamd.activity_code=upper(activity_rec.code)
       AND tamd.start_date <= activity_rec.start_date and nvl(tamd.end_date,activity_rec.start_date) >=activity_rec.start_date;
     else
         select 
           tamd.unit_price as gross_amount ,
           ((tamd.unit_price*NVL(v_pharmacy_disc,0))/100)*(activity_rec.quantity) as disc_amount,
           ((tamd.unit_price*NVL(v_pharmacy_disc,0))/100)*(activity_rec.quantity) as unit_discount,
           tamd.unit_price as disc_gross_amount,
           null as bundle_id,
           null as package_id,
           null as internal_code,
           tamd.act_mas_dtl_seq_id as activity_seq_id,
           tamd.activity_code,
           tatc.activity_type_id
           into activity_rec.gross_amount,
                activity_rec.discount_amount,
                activity_rec.unit_discount_amount,
                activity_rec.disc_gross_amount,
                activity_rec.bundle_id,
                activity_rec.package_id,
                activity_rec.internal_code,
                activity_rec.activity_seq_id,
                activity_rec.code,
                activity_rec.activity_type
     from tpa_pharmacy_master_details tamd
     JOIN tpa_activity_type_codes tatc ON (tamd.activity_type_seq_id=tatc.activity_type_seq_id)
     WHERE tamd.activity_code=upper(activity_rec.code) and tamd.act_mas_dtl_seq_id in 
     (select max(d.act_mas_dtl_seq_id) from tpa_pharmacy_master_details d where d.activity_code= upper(activity_rec.code))
     order by tamd.act_mas_dtl_seq_id desc ;
    end if;
   elsif v_count > 0 then
    
    open act_tariff_cur(clm_tariff_rec.hosp_seq_id,v_tariff_ins_seq_id,v_product_network_type,activity_rec.code,activity_rec.start_date);
    fetch act_tariff_cur into activity_rec.gross_amount,activity_rec.discount_amount,
                activity_rec.disc_gross_amount,activity_rec.bundle_id,
                activity_rec.package_id,activity_rec.internal_code,
                activity_rec.activity_seq_id,activity_rec.code,
                activity_rec.activity_type;
    close act_tariff_cur;
    
   end if;
 end if;
 end if;
 ------------------------------tariff------------------------
  
  IF (activity_rec.activity_id IS NULL  AND to_char(activity_rec.start_date,'dd-mon-yyyy')<'01-Jun-2011')
     OR activity_rec.code IS NULL THEN 
     raise_application_error(-20411,'Activity ID is not valid OR Activity code should not be null.');
  END IF;
 
   OPEN header_cur(clm_rec.claim_id);
   FETCH header_cur into header_rec;
   CLOSE header_cur;
  IF (activity_rec.start_date<clm_rec.date_of_hospitalization OR activity_rec.start_date>clm_rec.date_of_discharge) 
  OR (to_char(activity_rec.start_date,'dd-mon-yyyy')> to_char(header_rec.transaction_date,'dd-mon-yyyy')) THEN 
     raise_application_error(-20412,'Activity date should be within date of hospitalization and date of discharge OR less than transction date.');
  END IF;
  
   IF clm_rec.benifit_type = 'OPT' AND (activity_rec.start_date >clm_rec.date_of_hospitalization+1) THEN
      raise_application_error(-20413,'for outpatient hospitalization date should be within 24 hours.');
   END IF; 
  
     
     IF (clm_rec.encounter_type_id in (1,2,7,8,9) and v_cnt>0) THEN
       raise_application_error(-20414,'incorrect service code');
     END IF;

     IF (activity_rec.quantity IS NULL AND activity_rec.quantity>1000 OR activity_rec.quantity<0) THEN
       raise_application_error(-20415,'Quantity is not Valid.');
     END IF; 
     IF (activity_rec.net_amount IS NULL AND activity_rec.net_amount<0) THEN
       raise_application_error(-20416,'Net Amount Is not Valid.');
     END IF; 
               
     IF (activity_rec.clinician_id IS NULL ) THEN
       raise_application_error(-20417,'Clinician Is not Valid.');
     END IF;  
     
     if activity_rec.activity_type='4' then
       activity_rec.disc_gross_amount := activity_rec.gross_amount;
       activity_rec.net_amount        := activity_rec.gross_amount;
     end if;
     
  pat_xml_load_pkg.save_activity_details(
                      activity_rec.activity_dtl_seq_id,
                      null,
                      clm_rec.claim_seq_id,
                      activity_rec.Activity_Seq_Id,
                      activity_rec.activity_id,
                      v_activity_count,
                      activity_rec.start_date,
                      activity_rec.activity_type,
                      activity_rec.code,
                      activity_rec.unit_type,
                      activity_rec.modifier,
                      activity_rec.internal_code,
                      activity_rec.package_id,
                      activity_rec.bundle_id,
                      activity_rec.quantity,
                      (activity_rec.gross_amount)*(activity_rec.quantity),
                      activity_rec.discount_amount,
                      case when v_activity_type_seq_id=5 then (((activity_rec.disc_gross_amount)*(activity_rec.quantity))- activity_rec.discount_amount) else ((activity_rec.disc_gross_amount)*(activity_rec.quantity)) end,
                      activity_rec.patient_share_amount,
                      activity_rec.copay_amount,
                      activity_rec.co_ins_amount,
                      activity_rec.deduct_amount,
                      activity_rec.out_of_pocket_amount,
                      activity_rec.net_amount,
                      0,
                      activity_rec.clinician_id,
                      'Y',
                      activity_rec.denial_code,
                      activity_rec.remarks,
                      activity_rec.Clinician_Remarks,
                      activity_rec.gross_amount,
                      clm_batch_rec.added_by,
                      activity_rec.PRIOR_AUTHID,
                      activity_rec.tooth_no,
                      activity_rec.internal_desc,
                      null,
                      activity_rec.converted_acitivty_amt,
                      null,
                      null); ---need to check with mohan
        
  IF observ_node.FIRST IS NOT NULL THEN
    for i in observ_node.first..observ_node.last loop
      get_observation_details(observ_node(i).node);
    end loop;  
  END IF;
                 
  OPEN diag_cur;
  FETCH diag_cur INTO diag_rec;
  CLOSE diag_cur;
  
  
    OPEN clin_name_cur(activity_rec.clinician_id);
    FETCH clin_name_cur INTO v_clinician_name;
    CLOSE clin_name_cur;
  
  
        
  
   UPDATE clm_authorization_details 
   SET    clinician_id             =  activity_rec.clinician_id,
          pat_auth_seq_id          =  clm_rec.pat_auth_seq_id,
          network_yn               =  'Y'
   WHERE  claim_seq_id          =  clm_rec.claim_seq_id;
 
  UPDATE clm_hospital_details d SET
         d.clinician_name         =  v_clinician_name
   WHERE  claim_seq_id            =  clm_rec.claim_seq_id;
  
  UPDATE app.pat_activity_details pa SET
          pa.approvd_quantity    = activity_rec.quantity
   WHERE  pa.activity_dtl_seq_id = activity_rec.activity_dtl_seq_id;
     commit;
end get_activity_details;

--===============================================================================
PROCEDURE get_observation_details(v_observation_node IN DBMS_XMLDOM.DOMNode)
IS

  v_doc                        DBMS_XMLDOM.DOMDocument;
  v_elem                       DBMS_XMLDOM.DOMElement; 
  v_chld_node                  DBMS_XMLDOM.domnode; 
  v_parent_node                  DBMS_XMLDOM.domnode;
  v_node_list                    DBMS_XMLDOM.DOMNodeList;
  v_observation_type             tpa_general_code.description%type;
  v_observation_id               tpa_general_code.description%type;

BEGIN 
   observation_rec:=null;
   v_elem:=dbms_xmldom.makeelement(v_observation_node);
   v_node_list := xmldom.getChildNodes(v_observation_node);
    FOR j IN 0..dbms_xmldom.getLength( v_node_list ) -1 LOOP
    v_parent_node := DBMS_XMLDOM.item(v_node_list, j);          
   CASE  DBMS_XMLDOM.getNodeName(v_parent_node)
   WHEN 'Type' THEN
   v_chld_node := DBMS_XMLDOM.getFirstChild(v_parent_node);
   v_observation_type:=DBMS_XMLDOM.getNodeValue(v_chld_node);
   observation_rec.observation_type_id:=pat_xml_load_pkg.get_associated_id('OBSERVATION_TYPE',v_observation_type,'OBSERVATION_TYPE');
   WHEN 'Code' THEN
   v_chld_node := DBMS_XMLDOM.getFirstChild(v_parent_node);
   observation_rec.observation_code_id:=pat_xml_load_pkg.get_associated_id('OBSERVATION_CODE',DBMS_XMLDOM.getNodeValue(v_chld_node),'OBSERVATION_CODE');
   WHEN 'Value' THEN
   v_chld_node := DBMS_XMLDOM.getFirstChild(v_parent_node);
   observation_rec.value:=DBMS_XMLDOM.getNodeValue(v_chld_node);
   WHEN 'ValueType' THEN
   v_chld_node := DBMS_XMLDOM.getFirstChild(v_parent_node);
   v_observation_id:=DBMS_XMLDOM.getNodeValue(v_chld_node);
   observation_rec.obs_value_type_id:=pat_xml_load_pkg.get_associated_id('OBSERVATION_VALUE_TYPE',v_observation_id,'OBSERVATION_VALUE_TYPE');
   ELSE NULL;
   END CASE;  
  END LOOP;                         
 
 pat_xml_load_pkg.save_observation_details(observation_rec.observation_seq_id,activity_rec.activity_dtl_seq_id,observation_rec.observation_type_id,observation_rec.observation_code_id,observation_rec.value,observation_rec.obs_value_type_id,1);    

end get_observation_details;
--===============================================================================
PROCEDURE save_clm_details(V_CLAIM_SEQ_ID               IN OUT CLM_AUTHORIZATION_DETAILS.CLAIM_SEQ_ID%type,
                           V_CLM_BATCH_SEQ_ID           IN CLM_AUTHORIZATION_DETAILS.CLM_BATCH_SEQ_ID%type,
                           V_PAT_AUTH_SEQ_ID            IN OUT CLM_AUTHORIZATION_DETAILS.PAT_AUTH_SEQ_ID%type,
                           V_PARENT_CLAIM_SEQ_ID        IN CLM_AUTHORIZATION_DETAILS.PARENT_CLAIM_SEQ_ID%type,
                           V_CLAIM_NUMBER               IN OUT CLM_AUTHORIZATION_DETAILS.CLAIM_NUMBER%type,
                           V_CLAIM_FILE_NUMBER          IN CLM_AUTHORIZATION_DETAILS.CLAIM_FILE_NUMBER%type,
                           V_SETTLEMENT_NUMBER          IN CLM_AUTHORIZATION_DETAILS.SETTLEMENT_NUMBER%type,
                           V_CLM_RECEIVED_DATE          IN CLM_AUTHORIZATION_DETAILS.CLM_RECEIVED_DATE%type,
                           V_SOURCE_TYPE_ID             IN CLM_AUTHORIZATION_DETAILS.SOURCE_TYPE_ID%type,
                           V_HOSPITALIZATION_DATE       IN CLM_AUTHORIZATION_DETAILS.DATE_OF_HOSPITALIZATION%type,
                           V_DISCHARGE_DATE             IN CLM_AUTHORIZATION_DETAILS.DATE_OF_DISCHARGE%type,
                           V_CLAIM_TYPE                 IN CLM_AUTHORIZATION_DETAILS.CLAIM_TYPE%type,
                           V_CLAIM_SUB_TYPE             IN CLM_AUTHORIZATION_DETAILS.CLAIM_SUB_TYPE%type,
                           V_MEMBER_SEQ_ID              IN CLM_AUTHORIZATION_DETAILS.MEMBER_SEQ_ID%type,
                           V_TPA_ENROLLMENT_ID          IN CLM_AUTHORIZATION_DETAILS.TPA_ENROLLMENT_ID%type,
                           V_MEM_NAME                   IN CLM_AUTHORIZATION_DETAILS.MEM_NAME%type,
                           V_MEM_AGE                    IN CLM_AUTHORIZATION_DETAILS.MEM_AGE%type,
                           V_INS_SEQ_ID                 IN CLM_AUTHORIZATION_DETAILS.INS_SEQ_ID%type,
                           V_POLICY_SEQ_ID              IN CLM_AUTHORIZATION_DETAILS.POLICY_SEQ_ID%type,
                           V_ENROL_TYPE_ID              IN CLM_AUTHORIZATION_DETAILS.ENROL_TYPE_ID%type,
                           V_EMIRATE_ID                 IN CLM_AUTHORIZATION_DETAILS.EMIRATE_ID%type,
                           V_ENCOUNTER_TYPE_ID          IN CLM_AUTHORIZATION_DETAILS.ENCOUNTER_TYPE_ID%type,
                           V_ENCOUNTER_START_TYPE       IN CLM_AUTHORIZATION_DETAILS.ENCOUNTER_START_TYPE%type,
                           V_ENCOUNTER_END_TYPE         IN CLM_AUTHORIZATION_DETAILS.ENCOUNTER_END_TYPE%type,
                           V_ENCOUNTER_FACILITY_ID      IN CLM_AUTHORIZATION_DETAILS.ENCOUNTER_FACILITY_ID%type,
                           V_PAYER_ID                   IN CLM_AUTHORIZATION_DETAILS.PAYER_ID%type,
                           V_AVA_SUM_INSURED            IN CLM_AUTHORIZATION_DETAILS.AVA_SUM_INSURED%type,
                           V_CURRENCY_TYPE              IN CLM_AUTHORIZATION_DETAILS.CURRENCY_TYPE%type,
                           V_CLM_STATUS_TYPE_ID         IN CLM_AUTHORIZATION_DETAILS.CLM_STATUS_TYPE_ID%type,
                           V_REMARKS                    IN CLM_AUTHORIZATION_DETAILS.REMARKS%type,
                           V_INVOICE_NUMBER             IN CLM_AUTHORIZATION_DETAILS.INVOICE_NUMBER%type,
                           V_REQUESTED_AMOUNT           IN CLM_AUTHORIZATION_DETAILS.REQUESTED_AMOUNT%type,
                           V_CLINICIAN_ID               IN CLM_AUTHORIZATION_DETAILS.CLINICIAN_ID%type,
                           V_SYSTEM_OF_MEDICINE_TYPE_ID IN CLM_AUTHORIZATION_DETAILS.SYSTEM_OF_MEDICINE_TYPE_ID%type,
                           V_ACCIDENT_RELATED_TYPE_ID   IN CLM_AUTHORIZATION_DETAILS.ACCIDENT_RELATED_TYPE_ID%type,
                           V_PRIORITY_GENERAL_TYPE_ID   IN CLM_AUTHORIZATION_DETAILS.PRIORITY_GENERAL_TYPE_ID%type,
                           V_NETWORK_YN                 IN CLM_AUTHORIZATION_DETAILS.NETWORK_YN%type,
                           V_BENIFIT_TYPE               IN CLM_AUTHORIZATION_DETAILS.BENIFIT_TYPE%type,
                           V_GRAVIDA                    IN CLM_AUTHORIZATION_DETAILS.GRAVIDA%type,
                           V_PARA                       IN CLM_AUTHORIZATION_DETAILS.PARA%type,
                           V_LIVE                       IN CLM_AUTHORIZATION_DETAILS.LIVE%type,
                           V_ABORTION                   IN CLM_AUTHORIZATION_DETAILS.ABORTION%type,
                           V_PRESENTING_COMPLAINTS      IN CLM_AUTHORIZATION_DETAILS.PRESENTING_COMPLAINTS%type,
                           V_MEDICAL_OPINION_REMARKS    IN CLM_AUTHORIZATION_DETAILS.MEDICAL_OPINION_REMARKS%type,
                           V_HOSP_SEQ_ID                IN CLM_HOSPITAL_DETAILS.HOSP_SEQ_ID%type,
                           V_HOSP_NAME                  IN CLM_HOSPITAL_DETAILS.HOSP_NAME%type,
                           V_ADDRESS_1                  IN CLM_HOSPITAL_DETAILS.ADDRESS_1%type,
                           V_CITY_TYPE_ID               IN CLM_HOSPITAL_DETAILS.CITY_TYPE_ID%type,
                           V_STATE_TYPE_ID              IN CLM_HOSPITAL_DETAILS.STATE_TYPE_ID%type,
                           V_PIN_CODE                   IN CLM_HOSPITAL_DETAILS.PIN_CODE%type,
                           V_OFF_PHONE_NO_1             IN CLM_HOSPITAL_DETAILS.OFF_PHONE_NO_1%type,
                           V_OFFICE_FAX_NO              IN CLM_HOSPITAL_DETAILS.OFFICE_FAX_NO%type,
                           V_PROVIDER_ID                IN CLM_HOSPITAL_DETAILS.PROVIDER_ID%type,
                           V_COUNTRY_TYPE_ID            IN CLM_HOSPITAL_DETAILS.COUNTRY_TYPE_ID%type,
                           v_clinician_name             IN CLM_HOSPITAL_DETAILS.CLINICIAN_NAME%type,
                           V_ADDED_BY                   IN CLM_AUTHORIZATION_DETAILS.ADDED_BY%type,
						   V_RESUB_TYPE                 IN CLM_AUTHORIZATION_DETAILS.RESUB_TYPE%type,
                           V_RESUB_COMMENT              IN CLM_AUTHORIZATION_DETAILS.Re_Submission_Remarks%type,
                           v_first_ins_dt               IN CLM_AUTHORIZATION_DETAILS.FIRST_INCIDENT_DATE%TYPE,
                           v_first_report_dt            IN CLM_AUTHORIZATION_DETAILS.FIRST_REPORTED_DATE%TYPE,
                           v_lmp_date                   IN CLM_AUTHORIZATION_DETAILS.Lmp_Date%TYPE,
                           v_con_nature                 IN CLM_AUTHORIZATION_DETAILS.CONCEPTION_TYPE%TYPE,
                           V_AUTH_NO                    IN CLM_AUTHORIZATION_DETAILS.AUTH_NUMBER%TYPE,
                           V_CONVERTED_RATE             IN CLM_AUTHORIZATION_DETAILS.CONVERSION_RATE%TYPE,
						   V_EVENT_NO                   IN CLM_AUTHORIZATION_DETAILS.EVENT_NO%TYPE,
                           V_ROWS_PROCESSED             OUT NUMBER) is

  CURSOR mem_cur IS
    SELECT tepm.date_of_inception,
           tepm.date_of_exit,
           tepm.mem_name,
           tepm.mem_age,
           tcc.short_name,
           tsc.state_type_id,
           tepg.policy_group_seq_id,
           tepg.policy_seq_id,
           ep.enrol_type_id,
           tepm.member_seq_id,
           tepm.vip_yn,
           ep.ins_seq_id                   ----
      FROM tpa_enr_policy ep join tpa_enr_policy_group tepg on(ep.policy_seq_id=tepg.policy_seq_id)
      JOIN tpa_enr_policy_member tepm
        ON (tepg.policy_group_seq_id = tepm.policy_group_seq_id)
      LEFT OUTER JOIN tpa_enr_mem_address tema
        ON (tepg.enr_address_seq_id = tema.enr_address_seq_id)
      LEFT OUTER JOIN tpa_country_code tcc
        ON (tema.country_id = tcc.country_id)
      LEFT OUTER JOIN tpa_state_code tsc
        ON (tema.state_type_id = tsc.state_type_id)
     WHERE tepm.Member_Seq_Id = v_member_seq_id;

  CURSOR clm_cur IS
    SELECT cad.date_of_hospitalization
      FROM clm_authorization_details cad
     WHERE cad.member_seq_id = v_member_seq_id
       AND cad.claim_seq_id != nvl(v_claim_seq_id, 0)
       and nvl(cad.parent_claim_seq_id,0)=0
     ORDER BY cad.date_of_hospitalization desc;
     
  cursor pat_cur(v_pat_auth_seq_id number) is select * from app.pat_authorization_details a
  where a.pat_auth_seq_id=v_pat_auth_seq_id;
  
  CURSOR clm_batch_cur is
  select * from app.clm_batch_upload_details d where d.clm_batch_seq_id = v_clm_batch_seq_id;
  
  
   CURSOR tpa_office_cur IS
    SELECT tcc.short_name,
           tsc.state_type_id
      from tpa_office_info i join tpa_address a on (i.tpa_office_seq_id=a.tpa_office_seq_id)     
      LEFT OUTER JOIN tpa_country_code tcc
        ON (a.country_id = tcc.country_id)
      LEFT OUTER JOIN tpa_state_code tsc
        ON (a.state_type_id = tsc.state_type_id)
     WHERE i.tpa_office_seq_id= 1; 

 
  clm_rec clm_cur%ROWTYPE;
  mem_rec         mem_cur%ROWTYPE;
  pat_rec         pat_cur%ROWTYPE;
  office_rec      tpa_office_cur%ROWTYPE;
  batch_rec       clm_batch_cur%ROWTYPE; 
  v_denial_reason clm_authorization_details.denial_reason%type:=null;
  v_denial_code   clm_authorization_details.denial_code%type:=null;
  v_pat_approved_amount   clm_authorization_details.pat_approved_amount%type;
  v_pat_benft_type        pat_authorization_details.benifit_type%type;
  v_clm_status      varchar2(100);
  v_pat_hosp_seq_id number;
  v_auth_number     pat_authorization_details.auth_number%type;
  v_pre_approval_yn      varchar2(1);
  v_pre_approval_limit   number(10,2);

BEGIN

  OPEN mem_cur;
  FETCH mem_cur
    INTO mem_rec;
  CLOSE mem_cur;
 
 
 if nvl(V_PARENT_CLAIM_SEQ_ID,0)!=0 then 
   update clm_batch_upload_details d 
   set d.submission_type_id='DTR',
       d.batch_no = d.batch_no||'-'||'R'
       where d.clm_batch_seq_id= v_clm_batch_seq_id and d.batch_no not like'%R';
 end if;
 commit;
 
 OPEN clm_batch_cur;
 FETCH clm_batch_cur INTO batch_rec;
 CLOSE clm_batch_cur;
 
 OPEN tpa_office_cur;
 FETCH tpa_office_cur INTO office_rec;
 CLOSE tpa_office_cur;
 
  if V_CLAIM_SEQ_ID is not null then 
    select ad.completed_yn into v_clm_status from app.clm_authorization_details ad where ad.claim_seq_id=v_claim_seq_id;
   if nvl(v_clm_status,'N')='Y' then 
      RAISE_APPLICATION_ERROR(-20107,'You cannot perform this action through a completed Claim.');
   end if;
  end if; 
  IF v_source_type_id = 'ECLM' THEN
    IF mem_rec.member_seq_id IS NULL THEN
      v_denial_code := 'ELIG-001';
      v_denial_reason := 'Patient is not a covered member';
    ELSIF v_hospitalization_date < mem_rec.date_of_inception THEN
      v_denial_code := 'ELIG-006';
      v_denial_reason := 'Services performed prior to the effective date of coverage';
    ELSIF v_hospitalization_date > mem_rec.Date_Of_Exit THEN
      v_denial_code := 'ELIG-005';
      v_denial_reason := 'Services performed after the last date of coverage';
    ----payerid validation 
    ELSIF mem_rec.ins_seq_id != V_INS_SEQ_ID THEN
      v_denial_code := 'WRNG-001';
      v_denial_reason := 'Wrong submission, receiver is not responsible for the payer within this transaction submission.';    
    ----    
    END IF;
  
    /*IF NVL(V_PARENT_CLAIM_SEQ_ID,0)=0 THEN
    FOR rec IN clm_cur LOOP
      IF trunc(rec.date_of_hospitalization) = trunc(v_hospitalization_date) THEN
        v_denial_code := 'DUPL-001';
        v_denial_reason := 'Claim is a duplicate based on service codes and dates';
      END IF;
    END LOOP;
   END IF;*/--commented as per Dr.Yasmin
  ELSE
    IF mem_rec.member_seq_id IS NULL THEN
      RAISE_APPLICATION_ERROR(-20370, 'Patient is not a covered member');
    /*ELSIF v_hospitalization_date < mem_rec.date_of_inception THEN--comented to validate through rules
      RAISE_APPLICATION_ERROR(-20371,
                              'Services performed prior to the effective date of coverage');
    ELSIF v_hospitalization_date > mem_rec.Date_Of_Exit THEN
      RAISE_APPLICATION_ERROR(-20372,
                              'Services performed after the last date of coverage');*/
    END IF;
  END IF;
  IF V_PAT_AUTH_SEQ_ID is not null then
   open pat_cur(V_PAT_AUTH_SEQ_ID);
   fetch pat_cur into pat_rec;
   close  pat_cur;
   v_pat_approved_amount:=pat_rec.tot_approved_amount;
  END IF;
  
  if v_policy_seq_id is not null then
   IF mem_rec.enrol_type_id='COR' THEN
   SELECT gt.pre_approval_yn,case when nvl(mem_rec.vip_yn,'N')='Y' then gt.vip_pre_aprvl_limit else gt.non_vip_pre_aprvl_limit end into v_pre_approval_yn,v_pre_approval_limit
        FROM tpa_enr_policy GH
        JOIN tpa_ins_prod_policy GT ON (GH.policy_seq_id=GT.policy_seq_id)
     WHERE GH.policy_seq_id=v_policy_seq_id;
   ELSE
   SELECT tipp.pre_approval_yn,case when nvl(mem_rec.vip_yn,'N')='Y' then tipp.vip_pre_aprvl_limit else tipp.non_vip_pre_aprvl_limit end into v_pre_approval_yn,v_pre_approval_limit
     FROM tpa_enr_policy tep
     LEFT OUTER JOIN tpa_ins_product tip on (tip.product_seq_id=tep.product_seq_id)
     LEFT OUTER JOIN tpa_ins_prod_policy tipp on (tipp.product_seq_id=tip.product_seq_id)
     WHERE tep.policy_seq_id=v_policy_seq_id;
   END IF;
  end if;
  IF V_CLAIM_TYPE ='CNH' THEN 
   IF NVL(v_pre_approval_yn,'N')='Y' THEN 
     IF v_requested_amount > nvl(v_pre_approval_limit,0) and v_pat_auth_seq_id IS NULL THEN
          --RAISE_APPLICATION_ERROR(-20394, 'Authorization number is mandatory for Network Claim');
---        get_preauth_list(v_member_seq_id,v_hosp_seq_id,v_hospitalization_date,v_discharge_date,v_pat_auth_seq_id,v_auth_number,v_pat_approved_amount);
         null;
      /*if v_pat_auth_seq_id is null then
                RAISE_APPLICATION_ERROR(-20394, 'Authorization number is mandatory for Network Claim');
     else 
         open pat_cur(v_pat_auth_seq_id);
         fetch pat_cur into pat_rec;
         close pat_cur;
       v_pat_approved_amount:=pat_rec.tot_approved_amount;
     end if;*/
    ELSIF v_requested_amount > nvl(v_pre_approval_limit,0) and v_pat_auth_seq_id IS NOT NULL THEN
        
                  v_pat_approved_amount:=pat_rec.tot_approved_amount;
                /*IF (pat_rec.benifit_type != v_benifit_type) OR (pat_rec.hosp_seq_id != v_hosp_seq_id and nvl(V_NETWORK_YN,'N')='Y' ) THEN
                 RAISE_APPLICATION_ERROR(-20392,'Please check Pre_auth and claims Benefit_Type/provider is not matching');
                END IF;
                 IF v_benifit_type='MTI' THEN
                   IF (V_GRAVIDA!=pat_rec.gravida) OR (V_PARA !=pat_rec.para ) OR (V_LIVE !=pat_rec.live) OR (V_ABORTION !=pat_rec.abortion) then
                         RAISE_APPLICATION_ERROR(-20393,'Please check Pre_auth and claims maternity(gravida/para/live/abortion) values are not matching');
                   END IF;
                 END IF;*/
       
    END IF;
   /*ELSE
         IF V_PAT_AUTH_SEQ_ID IS NOT NULL THEN
   
                 v_pat_approved_amount:=pat_rec.tot_approved_amount;
                IF (pat_rec.benifit_type != v_benifit_type) OR (pat_rec.hosp_seq_id != v_hosp_seq_id and nvl(V_NETWORK_YN,'N')='Y' ) THEN
                    RAISE_APPLICATION_ERROR(-20392,'Please check Pre_auth and claims Benefit_Type/provider is not matching');
                END IF;
               IF v_benifit_type IN ('MTI', 'OMTI', 'IMTI') THEN
                 IF (V_GRAVIDA!=pat_rec.gravida) OR (V_PARA !=pat_rec.para ) OR (V_LIVE !=pat_rec.live) OR (V_ABORTION !=pat_rec.abortion) then
                    RAISE_APPLICATION_ERROR(-20393,'Please check Pre_auth and claims maternity(gravida/para/live/abortion) values are not matching');
                 END IF;
               END IF;
          ELSE
            --RAISE_APPLICATION_ERROR(-20394, 'Authorization number is mandatory for Network Claim');
         --get_preauth_list(v_member_seq_id,v_hosp_seq_id,v_hospitalization_date,v_discharge_date,v_pat_auth_seq_id,v_auth_number,v_pat_approved_amount);
          \*if v_pat_auth_seq_id is null then
                RAISE_APPLICATION_ERROR(-20394, 'Authorization number is mandatory for Network Claim');
		  else 
            
                  open pat_cur(v_pat_auth_seq_id);
                  fetch pat_cur into pat_rec;
                  close  pat_cur;
               v_pat_approved_amount:=pat_rec.tot_approved_amount;
          end if;*\
		  null;
        END IF; */ 
  END IF;
 END IF; 
  
  
  IF NVL(v_claim_seq_id, 0) = 0 THEN
    
      IF v_claim_number IS NULL and batch_rec.submission_type_id='DTC' THEN
        v_claim_number      := authorization_pkg.generate_id_numbers('CL', NVL(mem_rec.short_name,office_rec.short_name) , NVL(mem_rec.state_type_id,office_rec.State_Type_Id), v_claim_number);
      ELSIF v_claim_number IS NULL and batch_rec.submission_type_id='DTR' THEN
        v_claim_number      := authorization_pkg.generate_id_numbers('RS',NVL(mem_rec.short_name,office_rec.short_name), NVL(mem_rec.state_type_id,office_rec.State_Type_Id), v_claim_number);
      
      END IF;
    
    
   
INSERT INTO clm_authorization_details
  (claim_seq_id,
   clm_batch_seq_id,
   pat_auth_seq_id,
   parent_claim_seq_id,
   claim_number,
   claim_file_number,
   settlement_number,
   clm_received_date,
   source_type_id,
   date_of_hospitalization,
   date_of_discharge,
   claim_type,
   claim_sub_type,
   member_seq_id,
   tpa_enrollment_id,
   mem_name,
   mem_age,
   ins_seq_id,
   policy_seq_id,
   enrol_type_id,
   emirate_id,
   encounter_type_id,
   encounter_start_type,
   encounter_end_type,
   encounter_facility_id,
   ava_sum_insured,
   currency_type,
   clm_status_type_id,
   denial_reason,
   remarks,
   added_by,
   added_date,
   invoice_number,
   requested_amount,
   clinician_id,
   system_of_medicine_type_id,
   accident_related_type_id,
   priority_general_type_id,
   network_yn,
   benifit_type,
   gravida,
   para,
   live,
   abortion,
   presenting_complaints,
   medical_opinion_remarks,
   payer_id ,
   denial_code,
   pat_approved_amount,
   resub_type,
   Re_Submission_Remarks,
   Lmp_Date,
   Conception_Type,
   first_incident_date,
   first_reported_date,
   AUTH_NUMBER,
   CONVERSION_RATE,
   req_amt_currency_type,
   SOURCE_FROM,
   event_no)
VALUES
  (clm_authorization_detail_seq.nextval,
   v_clm_batch_seq_id,
   v_pat_auth_seq_id,
   v_parent_claim_seq_id,
   v_claim_number,
   v_claim_file_number,
   v_settlement_number,
   v_clm_received_date,
   v_source_type_id,
   v_hospitalization_date,
   v_discharge_date,
   v_claim_type,
   v_claim_sub_type,
   v_member_seq_id,
   v_tpa_enrollment_id,
   v_mem_name,
   v_mem_age,
   v_ins_seq_id,
   v_policy_seq_id,
   v_enrol_type_id,
   v_emirate_id,
   v_encounter_type_id,
   v_encounter_start_type,
   v_encounter_end_type,
   v_encounter_facility_id,
   v_ava_sum_insured,
   v_currency_type,
   v_clm_status_type_id,
   v_denial_reason,
   v_remarks,
   v_added_by,
   sysdate,
   v_invoice_number,
   v_requested_amount,
   v_clinician_id,
   v_system_of_medicine_type_id,
   v_accident_related_type_id,
   v_priority_general_type_id,
   v_network_yn,
   v_benifit_type,
   v_gravida,
   v_para,
   v_live,
   v_abortion,
   v_presenting_complaints,
   v_medical_opinion_remarks,
   v_payer_id,
   v_denial_code,
   v_pat_approved_amount,
   v_resub_type,
   v_resub_comment,
   v_lmp_date,
   v_con_nature,
   v_first_ins_dt,
   v_first_report_dt,
   V_AUTH_NO,
   V_CONVERTED_RATE,
   'QAR' ,
   'EXL',
   V_EVENT_NO) returning claim_seq_id into v_claim_seq_id;
  
    insert into clm_hospital_details c
      (clm_hosp_assoc_seq_id,
       claim_seq_id,
       hosp_seq_id,
       hosp_name,
       address_1,
       city_type_id,
       state_type_id,
       pin_code,
       off_phone_no_1,
       office_fax_no,
       remarks,
       added_by,
       added_date,
       provider_id,
       country_type_id,
       clinician_name)
    values
      (clm_hosp_dtl_hosp_assoc_seq.nextval,
       v_claim_seq_id,
       v_hosp_seq_id,
       v_hosp_name,
       v_address_1,
       v_city_type_id,
       v_state_type_id,
       v_pin_code,
       v_off_phone_no_1,
       v_office_fax_no,
       v_remarks,
       v_added_by,
       sysdate,
       v_provider_id,
       v_country_type_id,
       v_clinician_name);
  
  if v_pat_auth_seq_id is not null then 
    update pat_authorization_details pad 
    set pad.claim_seq_id = v_claim_seq_id,
        pad.updated_by   = v_added_by,
        pad.updated_date = sysdate
   where pad.pat_auth_seq_id=v_pat_auth_seq_id ;
  end if;
  
  ELSE
   
   
      IF v_claim_number IS NULL and batch_rec.submission_type_id='DTC' THEN
        v_claim_number      := authorization_pkg.generate_id_numbers('CL', NVL(mem_rec.short_name,office_rec.short_name) , NVL(mem_rec.state_type_id,office_rec.State_Type_Id), v_claim_number);
      ELSIF v_claim_number IS NULL and batch_rec.submission_type_id='DTR' THEN
        v_claim_number      := authorization_pkg.generate_id_numbers('RS',NVL(mem_rec.short_name,office_rec.short_name), NVL(mem_rec.state_type_id,office_rec.State_Type_Id), v_claim_number);
      
      END IF;
  
  
   UPDATE clm_authorization_details
      SET clm_batch_seq_id           = v_clm_batch_seq_id,
          pat_auth_seq_id            = v_pat_auth_seq_id,
          parent_claim_seq_id        = v_parent_claim_seq_id,
          claim_number               = v_claim_number,
          claim_file_number          = v_claim_file_number,
          settlement_number          = v_settlement_number,
          clm_received_date          = v_clm_received_date,
          source_type_id             = v_source_type_id,
          date_of_hospitalization    = v_hospitalization_date,
          date_of_discharge          = v_discharge_date,
          claim_type                 = v_claim_type,
          claim_sub_type             = v_claim_sub_type,
          member_seq_id              = v_member_seq_id,
          tpa_enrollment_id          = v_tpa_enrollment_id,
          mem_name                   = v_mem_name,
          mem_age                    = v_mem_age,
          ins_seq_id                 = v_ins_seq_id,
          policy_seq_id              = v_policy_seq_id,
          enrol_type_id              = v_enrol_type_id,
          emirate_id                 = v_emirate_id,
          encounter_type_id          = v_encounter_type_id,
          encounter_start_type       = v_encounter_start_type,
          encounter_end_type         = v_encounter_end_type,
          encounter_facility_id      = v_encounter_facility_id,
          ava_sum_insured            = v_ava_sum_insured,
          currency_type              = v_currency_type,
          clm_status_type_id         = v_clm_status_type_id,
          denial_reason              = v_denial_reason,
          remarks                    = v_remarks,
          updated_by                 = v_added_by,
          updated_date               = sysdate,
          invoice_number             = v_invoice_number,
          requested_amount           = v_requested_amount,
          clinician_id               = v_clinician_id,
          system_of_medicine_type_id = v_system_of_medicine_type_id,
          accident_related_type_id   = v_accident_related_type_id,
          priority_general_type_id   = v_priority_general_type_id,
          network_yn                 = v_network_yn,
          benifit_type               = v_benifit_type,
          gravida                    = v_gravida,
          para                       = v_para,
          live                       = v_live,
          abortion                   = v_abortion,
          presenting_complaints      = v_presenting_complaints,
          medical_opinion_remarks    = v_medical_opinion_remarks,
          payer_id                   = v_payer_id,
          denial_code                = v_denial_code,
          pat_approved_amount        = v_pat_approved_amount,
          resub_type                 = v_resub_type,
          Re_Submission_Remarks      = v_resub_comment,
          lmp_date                   = v_lmp_date,
          conception_type            = v_con_nature,
          first_incident_date        = v_first_ins_dt,
          first_reported_date        = v_first_report_dt,
          AUTH_NUMBER                = V_AUTH_NUMBER,
          req_amt_currency_type      = 'QAR',
          event_no                   = V_EVENT_NO
         WHERE claim_seq_id = v_claim_seq_id;
  
    update clm_hospital_details chd
       set hosp_seq_id      = v_hosp_seq_id,
           hosp_name        = v_hosp_name,
           address_1        = v_address_1,
           city_type_id     = v_city_type_id,
           state_type_id    = v_state_type_id,
           pin_code         = v_pin_code,
           off_phone_no_1   = v_off_phone_no_1,
           office_fax_no    = v_office_fax_no,
           remarks          = v_remarks,
           updated_by       = v_added_by,
           updated_date     = sysdate,
           provider_id      = v_provider_id,
           country_type_id  = v_country_type_id,
           clinician_name   = v_clinician_name
     where chd.claim_seq_id = v_claim_seq_id;
  
  
  if v_pat_auth_seq_id is not null then 
    update pat_authorization_details pad 
    set pad.claim_seq_id = v_claim_seq_id,
        pad.updated_by   = v_added_by,
        pad.updated_date = sysdate
   where pad.pat_auth_seq_id=v_pat_auth_seq_id ;
  end if;
  
  END IF;
  /*v_claim_seq_id:=v_claim_seq_id;

  v_prod_policy_rule_seq_id := pat_xml_load_pkg.get_prod_pol_seq_id(mem_rec.policy_seq_id,
                                                                    'POL');

  pat_xml_load_pkg.execute_global_rules('C',
                                        v_claim_seq_id,
                                        v_member_seq_id,
                                        v_prod_policy_rule_seq_id);*/
  --commit;
END save_clm_details;
--===============================================================================
PROCEDURE calculate_authorization(v_claim_seq_id               IN  clm_authorization_details.claim_seq_id%type,
                                  v_hosp_seq_id                IN  clm_hospital_details.hosp_seq_id%TYPE,
                                  v_allowed_amount             OUT clm_authorization_details.tot_allowed_amount%type,
                                  v_result_set                 OUT SYS_REFCURSOR,
                                  v_added_by                   IN  NUMBER)
IS



CURSOR act_cur IS
SELECT SUM(NVL(pa.gross_amount,0)) as tot_gross_amount
      ,SUM(NVL(pa.discount_amount,0)) as tot_discount_amount
      ,SUM(NVL(pa.disc_gross_amount,0)) as tot_disc_gross_amount
      ,SUM(NVL(pa.patient_share_amount,0)) as tot_patient_share_amount
      ,SUM(NVL(pa.net_amount,0)) as tot_net_amount
      ,SUM(NVL(pa.allowed_amount,0)) as tot_allowed_amount
      ,SUM(NVL(pa.approved_amount,0)) as tot_approved_amount


 FROM pat_activity_details pa
WHERE pa.claim_seq_id=v_claim_seq_id;

 CURSOR clm_cur IS
  SELECT cad.denial_reason,cad.denial_code,cad.remarks,cad.completed_yn,cad.member_seq_id,
     to_date(cad.date_of_hospitalization,'dd/mm/rrrr') as hospitalization_date,cad.claim_type 
     FROM clm_authorization_details cad
     WHERE cad.claim_seq_id=v_claim_seq_id;

CURSOR enrol_type IS
select ep.enrol_type_id,ep.policy_seq_id from app.tpa_enr_policy ep join app.clm_authorization_details ad on (ep.policy_seq_id=ad.policy_seq_id)
where ad.claim_seq_id=v_claim_seq_id;   

enrol_rec                  enrol_type%rowtype;  
act_rec                    act_cur%ROWTYPE;
clm_rec                    clm_cur%ROWTYPE;
v_remarks                  varchar2(100);
v_chronic_count            number(10);

--v_hosp_seq_id        number(10);
v_final_allowed_amount   number;
BEGIN
   
    OPEN clm_cur;
    FETCH clm_cur INTO clm_rec;
    CLOSE clm_cur;
    
   
    OPEN enrol_type;
    FETCH enrol_type INTO enrol_rec;
    CLOSE enrol_type;
    
     IF nvl(clm_rec.Completed_Yn,'N')='Y' THEN
        RAISE_APPLICATION_ERROR(-20107,'You cannot perform this action through a completed Claim.');
     END IF;
     IF enrol_rec.enrol_type_id='IND' THEN
       v_prod_policy_rule_seq_id:=authorization_pkg.get_prod_pol_seq_id(enrol_rec.policy_seq_id,'IND');
     ELSE
       v_prod_policy_rule_seq_id:=authorization_pkg.get_prod_pol_seq_id(enrol_rec.policy_seq_id,'POL');
     END IF; 
   
      update pat_activity_details ad set 
      ad.denial_code=null,ad.remarks=null,
      ad.denial_desc=null,ad.patient_share_amount=0,ad.allowed_amount=null,
      ad.approved_amount=null,ad.copay_perc=null,ad.deduct_amount=null,
      ad.benifit_copay=null,ad.benifit_deductible=null,ad.copay_amount=null
      where ad.claim_seq_id=v_claim_seq_id;
      
      update diagnosys_details dd 
      set dd.denial_reason=null,
          dd.remarks=null,dd.rule_limit=null,dd.rule_copay=null,dd.deduct=0,dd.copay=null
       where dd.claim_seq_id=v_claim_seq_id;
       
      update clm_authorization_details pad
      set pad.benefit_limit=null,
          pad.benefit_copay=null,
          pad.tot_allowed_amount=null,
          pad.tot_approved_amount=null,
          pad.tot_patient_share_amount=null
          where pad.claim_seq_id = v_claim_seq_id;
     
   
    IF clm_rec.Denial_Reason is not null THEN
      UPDATE pat_activity_details pad
               SET pad.denial_desc  = clm_rec.Denial_Reason,
                   pad.denial_code  = clm_rec.denial_code,
                   pad.remarks      = clm_rec.remarks,
                   pad.updated_by   = v_added_by,
                   pad.updated_date = SYSDATE
             WHERE pad.claim_seq_id = v_claim_seq_id;
    end if; 
    commit; 
    select count(1) into v_chronic_count from  
    app.clm_authorization_details d join app.diagnosys_details dd on (d.claim_seq_id=dd.claim_seq_id and d.benifit_type='OPTS')
    join app.tpa_day_care_icd c on (c.icd_code=dd.diagnosys_code) where d.claim_seq_id=v_claim_seq_id;
    
    pat_xml_load_pkg.check_duplicate_activity(v_claim_seq_id,'CLM',v_added_by);
    pat_xml_load_pkg.check_ddc_rule(v_claim_seq_id,'CLM',v_added_by);
    --pat_xml_load_pkg.check_lmrp_rules(v_claim_seq_id,'CLM',v_added_by);--comented as per Dr.yasmin
    pat_xml_load_pkg.check_ncci_hosp_phy_rules(v_claim_seq_id,v_hosp_seq_id,'CLM',v_added_by);
    --pat_xml_load_pkg.check_mue_rules(v_claim_seq_id,'CLM',v_added_by);--comented as per Dr.yasmin
    pat_xml_load_pkg.execute_diag_rule(v_claim_seq_id,'CLM' ,v_prod_policy_rule_seq_id  ,v_added_by);     
    --if v_chronic_count=0 then
    pat_xml_load_pkg.execute_activity_rule(v_claim_seq_id,'CLM'  ,v_prod_policy_rule_seq_id  ,v_added_by  );        
    --end if;
    pat_xml_load_pkg.check_add_on_rules(v_claim_seq_id,'CLM',v_added_by);
    IF clm_rec.claim_type='CNH' THEN 
    pat_xml_load_pkg.check_tariff_rule(v_claim_seq_id,'CLM',v_added_by);
    --pat_xml_load_pkg.check_network_clm_rule(v_claim_seq_id,v_added_by);
    END IF;
   pat_xml_load_pkg.calculate_allowed_amount(v_claim_seq_id,'CLM');
   
    OPEN  act_cur;
    FETCH act_cur INTO act_rec;
    CLOSE act_cur;
    
    UPDATE clm_authorization_details A
    SET a.tot_gross_amount           = act_rec.tot_gross_amount,
        a.tot_discount_amount        = act_rec.tot_discount_amount,
        a.tot_disc_gross_amount      = act_rec.tot_disc_gross_amount,
        a.tot_patient_share_amount   = act_rec.tot_patient_share_amount,
        a.tot_net_amount             = act_rec.tot_net_amount,
        a.tot_allowed_amount         = act_rec.tot_allowed_amount,
        a.tot_approved_amount        = act_rec.tot_approved_amount
   WHERE a.Claim_Seq_Id           = v_claim_seq_id
   RETURNING a.tot_allowed_amount INTO v_allowed_amount;
  
  pat_xml_load_pkg.execute_global_amnt_rules('C',v_claim_seq_id,clm_rec.member_seq_id,v_Prod_Policy_Rule_Seq_Id);
  authorization_pkg.check_activity_limits(v_claim_seq_id,'CLM',null,v_added_by,v_remarks,v_final_allowed_amount);
  
   
  UPDATE pat_activity_details pad
               SET pad.denial_desc  = replace(pad.denial_desc,';;',';')
                   WHERE pad.claim_seq_id = v_claim_seq_id;
  
 commit;
 OPEN v_result_set FOR 
  SELECT SUM(NVL(pa.gross_amount,0)) as tot_gross_amount
      ,SUM(NVL(pa.discount_amount,0)) as tot_discount_amount
      ,SUM(NVL(pa.disc_gross_amount,0)) as tot_disc_gross_amount
      ,SUM(NVL(pa.patient_share_amount,0)) as tot_patient_share_amount
      ,SUM(NVL(pa.net_amount,0)) as tot_net_amount
      ,SUM(NVL(pa.allowed_amount,0)) as tot_allowed_amount
      ,SUM(NVL(pa.Approved_Amount,0)) as tot_approved_amount

 FROM pat_activity_details pa
WHERE pa.claim_seq_id=v_claim_seq_id
AND pa.allow_yn='Y';  
  
END calculate_authorization;
--===============================================================================
PROCEDURE save_settlement(  v_claim_seq_id                     IN clm_authorization_details.claim_seq_id%TYPE,
                             v_member_seq_id                   IN clm_authorization_details.member_seq_id%TYPE,
                             v_settlement_number               IN OUT clm_authorization_details.settlement_number%TYPE,
                             v_admission_date                  IN clm_authorization_details.date_of_hospitalization%type,
                             v_allowed_amount                  IN clm_authorization_details.Tot_Allowed_Amount%TYPE,
                             v_source_type_id                  IN clm_authorization_details.source_type_id%TYPE,
                             v_clm_status_type_id              IN OUT clm_authorization_details.clm_status_type_id%TYPE,
                             v_remarks                         IN clm_authorization_details.remarks%type,
                             v_added_by                        IN  NUMBER,
                             v_rows_processed                  OUT NUMBER)
IS

CURSOR mem_cur IS
SELECT a.date_of_inception,a.date_of_exit,a.member_seq_id,b.policy_group_seq_id,c.policy_seq_id,c.policy_sub_general_type_id,
c.enrol_type_id,tcc.short_name,
tsc.state_type_id FROM tpa_enr_policy_member a
JOIN tpa_enr_policy_group b on (a.policy_group_seq_id=b.policy_group_seq_id)
JOIN tpa_enr_policy c on (b.policy_seq_id=c.policy_seq_id)
left outer JOIN tpa_enr_mem_address tema ON (b.enr_address_seq_id = tema.enr_address_seq_id)
left outer JOIN tpa_country_code tcc  ON (tema.country_id = tcc.country_id)
left outer JOIN tpa_state_code tsc  ON (tema.state_type_id = tsc.state_type_id)
WHERE a.member_seq_id=v_member_seq_id;

mem_rec             mem_cur%ROWTYPE;

CURSOR clm_cur IS
SELECT * FROM clm_authorization_details cad
WHERE cad.claim_seq_id=v_claim_seq_id;

clm_rec  clm_cur%rowtype;
CURSOR floater_cur(v_policy_group_seq_id    tpa_enr_policy_group.policy_group_seq_id%type)
 IS 
SELECT a.policy_group_seq_id,
       SUM(A.mem_sum_insured) AS sum_insured,
       b.sum_insured as tot_sum_insured,
       b.utilised_sum_insured  FROM tpa_enr_mem_insured a
JOIN tpa_enr_balance b on (a.policy_group_seq_id=b.policy_group_seq_id)
WHERE a.policy_group_seq_id=v_policy_group_seq_id
AND a.policy_date<=v_admission_date
GROUP BY a.policy_group_seq_id,b.sum_insured,b.utilised_sum_insured;

CURSOR nonfloater_cur(v_member_seq_id    tpa_enr_policy_member.member_seq_id%type)
 IS 
SELECT a.member_seq_id,
       SUM(A.mem_sum_insured) AS sum_insured,
       b.sum_insured as tot_sum_insured,
       b.utilised_sum_insured
       
FROM tpa_enr_mem_insured a
JOIN tpa_enr_balance b on (a.policy_group_seq_id=b.policy_group_seq_id)
WHERE a.member_seq_id=v_member_seq_id
AND a.policy_date<=v_admission_date
GROUP BY a.member_seq_id,b.sum_insured,b.utilised_sum_insured;



CURSOR tpa_office_cur IS
    SELECT tcc.short_name,
           tsc.state_type_id
      from tpa_office_info i join tpa_address a on (i.tpa_office_seq_id=a.tpa_office_seq_id)     
      LEFT OUTER JOIN tpa_country_code tcc
        ON (a.country_id = tcc.country_id)
      LEFT OUTER JOIN tpa_state_code tsc
        ON (a.state_type_id = tsc.state_type_id)
     WHERE i.tpa_office_seq_id= 1; 


office_rec      tpa_office_cur%ROWTYPE;
sum_rec              floater_cur%rowtype;
v_ava_sum_insured    tpa_enr_balance.utilised_sum_insured%type;
v_app_amount         pat_authorization_details.final_app_amount%type:=v_allowed_amount;
v_reason             pat_authorization_details.remarks%type;
v_denial_reason      pat_authorization_details.denial_reason%type;
v_compleated_yn   VARCHAR2(5);
v_final_remarks      VARCHAR2(2000);

BEGIN
  
  OPEN mem_cur;
  FETCH mem_cur INTO mem_rec;
  CLOSE mem_cur;
  
  OPEN clm_cur;
  FETCH clm_cur INTO clm_rec;
  CLOSE clm_cur;
  
  IF clm_rec.Completed_Yn='Y' THEN
    RAISE_APPLICATION_ERROR(-20152,'You cannot perform this action through a completed Claim.');
  END IF;
   
  IF mem_rec.policy_sub_general_type_id='PFL' THEN
    OPEN floater_cur(mem_rec.policy_group_seq_id);
    FETCH floater_cur INTO sum_rec;
    CLOSE floater_cur;
  ELSIF  mem_rec.policy_sub_general_type_id='PNF' THEN
    OPEN nonfloater_cur(mem_rec.member_seq_id);
    FETCH nonfloater_cur INTO sum_rec;
    CLOSE nonfloater_cur;
  END IF; 
  
  v_ava_sum_insured:=(NVL(sum_rec.sum_insured,0)-NVL(sum_rec.utilised_sum_insured,0)) ;    
  IF clm_rec.Denial_Reason IS NOT NULL OR clm_rec.remarks is NOT NULL THEN
    v_clm_status_type_id:='REJ';
    v_denial_reason:=clm_rec.Denial_Reason||' '||clm_rec.remarks;
    v_app_amount:=0;
  ELSE
    IF clm_rec.manual_process_req_yn='Y'  THEN
      v_app_amount:=0;
      v_clm_status_type_id:='INP';
    ELSE
      IF clm_rec.maternity_yn='Y'  THEN
        IF clm_rec.maternity_allowed_amt=0 AND   v_allowed_amount>0 THEN  
          v_app_amount:=0;
          v_clm_status_type_id:='REJ';
          v_denial_reason:='Maternity Limit Exceeded,Pre-Auth/Claim got Rejected';
     
        ELSIF v_allowed_amount=0 THEN
          v_app_amount:=0;
          v_clm_status_type_id:='REJ';
          v_denial_reason:='Maternity Limit Exceeded,Pre-Auth/Claim got Rejected';
        ELSIF v_allowed_amount > clm_rec.maternity_allowed_amt AND clm_rec.maternity_allowed_amt>0 THEN
          v_app_amount:=clm_rec.maternity_allowed_amt;
          v_clm_status_type_id:='APR'; 
        ELSE
          v_app_amount:=v_allowed_amount;
          v_clm_status_type_id:='APR'; 
      END IF; 
     END IF;    
  
   IF v_clm_status_type_id IS NULL OR v_clm_status_type_id='APR' THEN
     IF v_app_amount=0 OR  v_ava_sum_insured=0 THEN        
        v_app_amount:=0;
        v_clm_status_type_id:='REJ';
     ELSIF v_app_amount<=v_ava_sum_insured THEN        
        v_clm_status_type_id:='APR';  
     ELSIF v_app_amount >v_ava_sum_insured AND v_ava_sum_insured>0  THEN
        v_app_amount:=v_ava_sum_insured;
        v_clm_status_type_id:='APR';
     END IF; 
   END IF;

   END IF;
 END IF;
 
     IF v_app_amount > clm_rec.requested_amount then
      v_app_amount:= clm_rec.requested_amount;
       v_final_remarks:='Total Approved Amount should be less than or equal to Requested Amount';
     else 
       v_app_amount :=v_app_amount;
     end if;
 
 /*IF NVL(clm_rec.manual_process_req_yn,'N')='N' AND v_allowed_amount!=v_app_amount THEN
     pat_xml_load_pkg.update_activity_limits(v_claim_seq_id,'CLM',v_app_amount,v_added_by,NULL);
 END IF;*/ 
 
  v_settlement_number:=null; 
  IF v_settlement_number IS NULL THEN    
     --v_settlement_number:=authorization_pkg.generate_id_numbers('CNH',NULL,NULL,clm_rec.claim_number,NULL);
     v_settlement_number:=authorization_pkg.generate_id_numbers('STC',nvl(mem_rec.short_name,office_rec.short_name),nvl(mem_rec.state_type_id,office_rec.state_type_id),clm_rec.claim_number,clm_rec.claim_type);
  END IF;
  
  v_clm_status_type_id:='INP';
  v_compleated_yn:=CASE WHEN v_clm_status_type_id='INP' THEN 'N' ELSE 'Y' END;
   UPDATE clm_authorization_details a
     SET A.final_app_amount   = v_app_amount,
         a.clm_status_type_id = v_clm_status_type_id,
         a.remarks            = NVL(v_remarks,v_reason),
         a.final_remarks      = case when v_final_remarks is not null then v_final_remarks ||';'||NVL(v_remarks,v_reason)else NVL(v_remarks,v_reason) end,
         a.denial_reason      = v_denial_reason,
         A.Settlement_Number  = v_settlement_number,
         A.completed_yn       = 'N',--CASE WHEN v_clm_status_type_id='INP' THEN 'N' ELSE 'Y' END,
         --a.ava_sum_insured    = v_ava_sum_insured,
         a.updated_by         = v_added_by,
         a.updated_date       = SYSDATE
     WHERE A.Claim_Seq_Id  = v_Claim_Seq_Id;
 
 if v_compleated_yn='Y' and v_clm_status_type_id='APR' then
 IF mem_rec.policy_sub_general_type_id='PFL' THEN    
   UPDATE tpa_enr_balance b
   SET b.utilised_sum_insured = b.utilised_sum_insured + v_app_amount,
       b.updated_by           = v_added_by,
       b.updated_date         = SYSDATE
   WHERE b.policy_group_seq_id = mem_rec.policy_group_seq_id;
 ELSIF mem_rec.policy_sub_general_type_id='PNF' THEN  
  UPDATE tpa_enr_balance b
   SET b.utilised_sum_insured = b.utilised_sum_insured + v_app_amount,
       b.updated_by           = v_added_by,
       b.updated_date         = SYSDATE
   WHERE b.member_seq_id = mem_rec.member_seq_id; 
 END IF;
 end if;
 v_rows_processed:=SQL%ROWCOUNT;
 
COMMIT;   
  
END save_settlement;
--===============================================================================
             -----====== xml uploads =====--------
--===================================================================================
-- Purpose :This procedure is used to generate the RemittanceAdvice xml to upload the status of claim into DHPO portal
---====================================================================================
procedure gene_remittance_advice(v_settlement_number   clm_authorization_details.settlement_number%type) is
  v_doc           dbms_xmldom.DOMDocument;
  v_main_node     dbms_xmldom.DOMNode;
  v_root_node     dbms_xmldom.DOMNode;
  v_chld_node     dbms_xmldom.DOMNode;
  v_auth_node     dbms_xmldom.DOMNode;
  v_en_node       dbms_xmldom.DOMNode;
  v_node        dbms_xmldom.domnode;
  v_act_node    dbms_xmldom.domnode;
  v_header_node dbms_xmldom.domnode;
  v_elem        dbms_xmldom.DOMElement;
  v_text        dbms_xmldom.DOMText;
  v_xml         xmltype;
  v_out         clob;
  v_body        varchar2(32767);
  v_buff        varchar2(32767);
  v_filename    varchar2(60);
  v_filenames   varchar2(32767);
  v_count       NUMBER(2):=1;
  v_os_user     varchar2(100);

  
    /*cursor get_header_cur is
     select *
             from app.clm_batch_upload_details cad
             where to_char(cad.received_date, 'mm/dd/yyyy hh:mi') between
                   to_char(to_date('9/8/2015','mm/dd/yyyy') - ((1 / 24 / 60) * 30), 'mm/dd/yyyy hh:mi') and
                   to_char(to_date('9/8/2015','mm/dd/yyyy'), 'mm/dd/yyyy hh:mi');*/
            /* select *
             from app.clm_batch_upload_details cad
             where to_char(cad.received_date, 'mm/dd/yyyy hh:mi') between
                   to_char(sysdate - ((1 / 24 / 60) * 30), 'mm/dd/yyyy hh:mi') and
                   to_char(sysdate, 'mm/dd/yyyy hh:mi');
          */

  cursor get_header_cur is
  SELECT ud.clm_batch_seq_id,'TPA033' AS SENDER_ID,ud.sender_id as receiver_id,to_char(sysdate, 'dd/mm/yyyy hh:mi') as transaction_date,
  1 as record_count,'TEST' AS disposition_flag 
  from app.clm_authorization_details a
  join app.clm_batch_upload_details ud on (a.clm_batch_seq_id=ud.clm_batch_seq_id) 
  --left outer join app.clm_hospital_details b on (a.claim_seq_id=b.claim_seq_id)
  --left outer join app.tpa_hosp_info h on (h.hosp_seq_id=b.hosp_seq_id)
  left outer join fin_app.tpa_claims_payment cp on (A.claim_seq_id=cp.claim_seq_id)
  where cp.claim_payment_status='PAID' AND cp.claim_settlement_no=v_settlement_number;
  
  
  cursor act_cur(v_claim_seq_id number) is
    select tpd.*
      from app.pat_activity_details tpd
      join app.clm_authorization_details cad
        on (cad.claim_seq_id = tpd.claim_seq_id)
        where tpd.claim_seq_id = v_claim_seq_id;
       --where tpa.tpa_enrollment_id = v_member_id
    --order by to_date(tpd.start_date,'yyyymmddhh24mi');           

   cursor settle_cur(v_clm_batch_seq_id number) is
    select ca.claim_seq_id,
       ca.invoice_number as claim_ID,
       ca.settlement_number as ClaimIDPayer,
       h.hosp_licenc_numb as ClaimProviderID,
       ca.denial_code as ClaimDenialCode,
       ck.check_num as PaymentReference,
       to_char(ck.check_date,'dd/mm/yyyy hh:mi') as ClaimDateSettlement,
       h.hosp_licenc_numb as EncounterFacilityID,
       case when ca.completed_yn = 'Y' then 'Yes'
       when ca.completed_yn = 'N' then 'No'
            else ''  end as completed_yn,
       ca.auth_number as PriorAuthorizationID,
       ca.final_app_amount as PaymentAmount
   from app.clm_authorization_details ca
   join app.clm_batch_upload_details ud on (ca.clm_batch_seq_id=ud.clm_batch_seq_id) 
   left outer join app.clm_hospital_details b on (ca.claim_seq_id=b.claim_seq_id)
   left outer join app.tpa_hosp_info h on (h.hosp_seq_id=b.hosp_seq_id)
   left outer join fin_app.tpa_claims_payment cp on (ca.claim_seq_id=cp.claim_seq_id)
   left outer join fin_app.tpa_payment_checks_details tg on (cp.payment_seq_id=tg.payment_seq_id and tg.v_csr_flag = 1)
   left outer join fin_app.tpa_claims_check ck on (tg.claims_chk_seq_id=ck.claims_chk_seq_id and tg.deleted_yn = 'N')
   where ca.clm_batch_seq_id = v_clm_batch_seq_id
    order by ca.clm_received_date ;

  head_rec get_header_cur%rowtype;
 type tab is table of varchar2(60) index by binary_integer;
 str_tab   tab;
 i         number:=1;

begin

  open get_header_cur;
  LOOP
  fetch get_header_cur into head_rec;
  EXIT WHEN get_header_cur%NOTFOUND;
  

  for rec in settle_cur(head_rec.clm_batch_seq_id) loop
    v_doc := dbms_xmldom.newDOMDocument;
  dbms_xmldom.setVersion(v_doc, '1.0" encoding="UTF-8');

  v_root_node := dbms_xmldom.makeNode(v_doc);

  v_elem      := dbms_xmldom.createElement(v_doc, 'Remittance.Advice');
  v_main_node := dbms_xmldom.makeNode(v_elem);
  dbms_xmldom.setAttribute(v_elem,
                           'xmlns:xsi',
                           'http://www.w3.org/2001/XMLSchema-instance');
  dbms_xmldom.setAttribute(v_elem,
                           'xsi:schemaLocation',
                           'http://www.eClaimLink.ae/DHD/CommonTypes.xsd http://www.w3.org/2001/XMLSchema-instance');
  dbms_xmldom.setAttribute(v_elem,
                           'xsi:noNamespaceSchemaLocation',
                           'http://www.eClaimLink.ae/DHD/CommonTypes/PriorRequest.xsd');

  v_main_node := dbms_xmldom.appendChild(v_root_node, v_main_node);
  v_elem      := dbms_xmldom.createElement(v_doc, 'Header');
  v_node      := dbms_xmldom.makeNode(v_elem);
  v_header_node := dbms_xmldom.appendChild(v_main_node, v_node);

  v_elem := dbms_xmldom.createElement(v_doc, 'SenderID');
  v_node := dbms_xmldom.appendChild(v_header_node,
                                    dbms_xmldom.makeNode(v_elem));
  v_text := DBMS_XMLDOM.createTextNode(v_doc, head_rec.sender_id);
  v_text := dbms_xmldom.makeText(DBMS_XMLDOM.appendChild(v_node,
                                                         dbms_xmldom.makeNode(v_text)));

  v_elem := dbms_xmldom.createElement(v_doc, 'ReceiverID');
  v_node := dbms_xmldom.appendChild(v_header_node,
                                    dbms_xmldom.makeNode(v_elem));
  v_text := DBMS_XMLDOM.createTextNode(v_doc, head_rec.receiver_id);
  v_text := dbms_xmldom.makeText(DBMS_XMLDOM.appendChild(v_node,
                                                         dbms_xmldom.makeNode(v_text)));

  v_elem := dbms_xmldom.createElement(v_doc, 'TransactionDate');
  v_node := dbms_xmldom.appendChild(v_header_node,
                                    dbms_xmldom.makeNode(v_elem));
  v_text := DBMS_XMLDOM.createTextNode(v_doc,head_rec.transaction_date);
  
  v_text := dbms_xmldom.makeText(DBMS_XMLDOM.appendChild(v_node,
                                                         dbms_xmldom.makeNode(v_text)));

  v_elem := dbms_xmldom.createElement(v_doc, 'RecordCount');
  v_node := dbms_xmldom.appendChild(v_header_node,
                                    dbms_xmldom.makeNode(v_elem));
  v_text := DBMS_XMLDOM.createTextNode(v_doc, head_rec.record_count);
  v_text := dbms_xmldom.makeText(DBMS_XMLDOM.appendChild(v_node,
                                                         dbms_xmldom.makeNode(v_text)));

  v_elem := dbms_xmldom.createElement(v_doc, 'DispositionFlag');
  v_node := dbms_xmldom.appendChild(v_header_node,
                                    dbms_xmldom.makeNode(v_elem));
  v_text := DBMS_XMLDOM.createTextNode(v_doc, replace(replace(head_rec.disposition_flag,chr(13),''),chr(10),''));
  v_text := dbms_xmldom.makeText(DBMS_XMLDOM.appendChild(v_node,
                                                         dbms_xmldom.makeNode(v_text)));

   
 
    v_elem      := dbms_xmldom.createElement(v_doc, 'Claim');
    v_node      := dbms_xmldom.makeNode(v_elem);
    v_auth_node := dbms_xmldom.appendChild(v_main_node, v_node);
       
    v_elem := dbms_xmldom.createElement(v_doc, 'ID');
    v_node := dbms_xmldom.appendChild(v_auth_node,
                                      dbms_xmldom.makeNode(v_elem));
    v_text := DBMS_XMLDOM.createTextNode(v_doc, rec.claim_id);
    v_text := dbms_xmldom.makeText(DBMS_XMLDOM.appendChild(v_node,
                                                           dbms_xmldom.makeNode(v_text)));
  
    v_elem := dbms_xmldom.createElement(v_doc, 'IDPayer');
    v_node := dbms_xmldom.appendChild(v_auth_node,
                                      dbms_xmldom.makeNode(v_elem));
    v_text := DBMS_XMLDOM.createTextNode(v_doc, rec.claimidpayer);
    v_text := dbms_xmldom.makeText(DBMS_XMLDOM.appendChild(v_node,
                                                           dbms_xmldom.makeNode(v_text)));
    
    v_elem := dbms_xmldom.createElement(v_doc, 'ProviderID');
    v_node := dbms_xmldom.appendChild(v_auth_node,
                                      dbms_xmldom.makeNode(v_elem));
    v_text := DBMS_XMLDOM.createTextNode(v_doc, rec.claimproviderid);
    v_text := dbms_xmldom.makeText(DBMS_XMLDOM.appendChild(v_node,
                                                           dbms_xmldom.makeNode(v_text)));
    v_elem := dbms_xmldom.createElement(v_doc, 'PaymentReference');
    v_node := dbms_xmldom.appendChild(v_auth_node,
                                      dbms_xmldom.makeNode(v_elem));
    v_text := DBMS_XMLDOM.createTextNode(v_doc, rec.paymentreference);
    v_text := dbms_xmldom.makeText(DBMS_XMLDOM.appendChild(v_node,
                                                           dbms_xmldom.makeNode(v_text)));
  
     
    v_elem := dbms_xmldom.createElement(v_doc, 'DateSettlement');
    v_node := dbms_xmldom.appendChild(v_auth_node,
                                      dbms_xmldom.makeNode(v_elem));
    v_text := DBMS_XMLDOM.createTextNode(v_doc, rec.claimdatesettlement);
    v_text := dbms_xmldom.makeText(DBMS_XMLDOM.appendChild(v_node,
                                                           dbms_xmldom.makeNode(v_text)));
    
    v_elem     := dbms_xmldom.createElement(v_doc, 'Encounter');
    v_node     := dbms_xmldom.makeNode(v_elem);
    v_en_node := dbms_xmldom.appendChild(v_auth_node, v_node);
    
      v_elem := dbms_xmldom.createElement(v_doc, 'FacilityID');
      v_node := dbms_xmldom.appendChild(v_en_node,
                                        dbms_xmldom.makeNode(v_elem));
      v_text := DBMS_XMLDOM.createTextNode(v_doc, rec.encounterfacilityid);
      v_text := dbms_xmldom.makeText(DBMS_XMLDOM.appendChild(v_node,
                                                             dbms_xmldom.makeNode(v_text)));
    
    
    for act_rec in act_cur (rec.claim_seq_id)loop
      v_elem     := dbms_xmldom.createElement(v_doc, 'Activity');
      v_node     := dbms_xmldom.makeNode(v_elem);
      v_act_node := dbms_xmldom.appendChild(v_auth_node, v_node);
    
      v_elem := dbms_xmldom.createElement(v_doc, 'ID');
      v_node := dbms_xmldom.appendChild(v_act_node,
                                        dbms_xmldom.makeNode(v_elem));
      v_text := DBMS_XMLDOM.createTextNode(v_doc, act_rec.activity_id);
      v_text := dbms_xmldom.makeText(DBMS_XMLDOM.appendChild(v_node,
                                                             dbms_xmldom.makeNode(v_text)));
      
      v_elem := dbms_xmldom.createElement(v_doc, 'Start');
      v_node := dbms_xmldom.appendChild(v_act_node,
                                      dbms_xmldom.makeNode(v_elem));
      v_text := DBMS_XMLDOM.createTextNode(v_doc,
                                         to_char(act_rec.start_date,
                                                 'dd/mm/yyyy hh:mm'));    
      v_text := dbms_xmldom.makeText(DBMS_XMLDOM.appendChild(v_node, dbms_xmldom.makeNode(v_text)));
    
   
      v_elem := dbms_xmldom.createElement(v_doc, 'Type');
      v_node := dbms_xmldom.appendChild(v_act_node,
                                        dbms_xmldom.makeNode(v_elem));
      v_text := DBMS_XMLDOM.createTextNode(v_doc, act_rec.activity_type);
      v_text := dbms_xmldom.makeText(DBMS_XMLDOM.appendChild(v_node,
                                                             dbms_xmldom.makeNode(v_text)));
    
      v_elem := dbms_xmldom.createElement(v_doc, 'Code');
      v_node := dbms_xmldom.appendChild(v_act_node,
                                        dbms_xmldom.makeNode(v_elem));
      v_text := DBMS_XMLDOM.createTextNode(v_doc, act_rec.code);
      v_text := dbms_xmldom.makeText(DBMS_XMLDOM.appendChild(v_node,
                                                             dbms_xmldom.makeNode(v_text)));
    
      v_elem := dbms_xmldom.createElement(v_doc, 'Quantity');
      v_node := dbms_xmldom.appendChild(v_act_node,
                                        dbms_xmldom.makeNode(v_elem));
      v_text := DBMS_XMLDOM.createTextNode(v_doc, act_rec.quantity);
      v_text := dbms_xmldom.makeText(DBMS_XMLDOM.appendChild(v_node,
                                                             dbms_xmldom.makeNode(v_text)));
      v_elem := dbms_xmldom.createElement(v_doc, 'Net');
      v_node := dbms_xmldom.appendChild(v_act_node,
                                        dbms_xmldom.makeNode(v_elem));
      v_text := DBMS_XMLDOM.createTextNode(v_doc, nvl(act_rec.provider_net_amount,act_rec.net_amount));
      v_text := dbms_xmldom.makeText(DBMS_XMLDOM.appendChild(v_node,
                                                             dbms_xmldom.makeNode(v_text)));
      v_elem := dbms_xmldom.createElement(v_doc, 'Clinician');
      v_node := dbms_xmldom.appendChild(v_act_node,
                                        dbms_xmldom.makeNode(v_elem));
      v_text := DBMS_XMLDOM.createTextNode(v_doc, act_rec.clinician_id);
      v_text := dbms_xmldom.makeText(DBMS_XMLDOM.appendChild(v_node,
                                                             dbms_xmldom.makeNode(v_text)));
      v_elem := dbms_xmldom.createElement(v_doc, 'PriorAuthorizationID');
      v_node := dbms_xmldom.appendChild(v_act_node,
                                        dbms_xmldom.makeNode(v_elem));
      v_text := DBMS_XMLDOM.createTextNode(v_doc, rec.PriorAuthorizationID);
      v_text := dbms_xmldom.makeText(DBMS_XMLDOM.appendChild(v_node,
                                                             dbms_xmldom.makeNode(v_text)));
      v_elem := dbms_xmldom.createElement(v_doc, 'Gross');
      v_node := dbms_xmldom.appendChild(v_act_node,
                                        dbms_xmldom.makeNode(v_elem));
      v_text := DBMS_XMLDOM.createTextNode(v_doc, act_rec.net_amount+nvl(act_rec.patient_share_amount,0));
      v_text := dbms_xmldom.makeText(DBMS_XMLDOM.appendChild(v_node,
                                                             dbms_xmldom.makeNode(v_text)));
      v_elem := dbms_xmldom.createElement(v_doc, 'PatientShare');
      v_node := dbms_xmldom.appendChild(v_act_node,
                                        dbms_xmldom.makeNode(v_elem));
      v_text := DBMS_XMLDOM.createTextNode(v_doc, nvl(act_rec.patient_share_amount,0));
      v_text := dbms_xmldom.makeText(DBMS_XMLDOM.appendChild(v_node,
                                                             dbms_xmldom.makeNode(v_text)));
      v_elem := dbms_xmldom.createElement(v_doc, 'PaymentAmount');
      v_node := dbms_xmldom.appendChild(v_act_node,
                                        dbms_xmldom.makeNode(v_elem));
      v_text := DBMS_XMLDOM.createTextNode(v_doc, rec.paymentamount);
      v_text := dbms_xmldom.makeText(DBMS_XMLDOM.appendChild(v_node,
                                                             dbms_xmldom.makeNode(v_text)));
    
    
    end loop;
  
  dbms_xmldom.writeToBuffer(v_root_node, v_buff);
  dbms_output.put_line(v_buff);  
  v_xml := dbms_xmldom.getXmlType(v_doc);  
  v_out:=v_xml.getClobval();
  --v_filename:='CLAIM_'||TO_CHAR(i)||TO_CHAR(SYSDATE,'_DD_MON_RRRR_HH24_MI_SS')||'.xml';
  --str_tab(i):=v_filename;
  --dbms_xslprocessor.clob2file(v_out,'XML_DIR',v_filename); 
  i:=i+1;
  dbms_xmldom.freeDocument(v_doc); 
  --insert into xml_test(xml_col) values(v_out);
  commit;
  end loop;
  END LOOP;
  close get_header_cur;
end gene_remittance_advice;

--===============================================================================
PROCEDURE load_claim_request(v_claim_doc IN xmltype,v_file_id IN varchar2,v_out_flag OUT VARCHAR2)
IS

    v_doc                      DBMS_XMLDOM.DOMDocument;
    v_root_node                DBMS_XMLDOM.DOMNode;
    v_parent_node              DBMS_XMLDOM.DOMNode;
    v_root_node_list           dbms_xmldom.DOMNodeList;
    v_elem                     dbms_xmldom.DOMElement;
    v_node_list                dbms_xmldom.DOMNodeList;
    v_node_count               number:=0;
    v_buf                      varchar2(10000);
    V_RecordCount              number:=0;
    v_count                    number:=1;
    V_SenderID                 varchar2(100);
    V_ReceiverID               varchar2(100);
    V_TransactionDate          varchar2(100);
    V_DispositionFlag          varchar2(100);
    v_Eclm_Xml_Error_Msg       varchar2(10000);
    v_eclm_xml_error_code      varchar2(100);
    
    cursor sender_exist_cur (v_hosp_licenc_numb varchar2)is 
      select count(*)
      from app.tpa_hosp_info hi
      where hi.hosp_licenc_numb = v_hosp_licenc_numb;
      
   cursor data_save_cur is  
    select eclm_xml_error_code,Eclm_Xml_Error_Msg from app.tpa_eclm_xml_logs
    where trunc(added_date) = trunc(sysdate) ;  
     v_sender_exist_count        number;
    
BEGIN
    clear_all('HEAD');
    --for i in (select error7 from dha_xml_test)loop
    --v_preauth_doc := v_pre_doc; 
  v_doc            := dbms_xmldom.newdomdocument(v_claim_doc);--v_claim_doc
  v_root_node_list := dbms_xmldom.getelementsbytagname(v_doc, 'Claim.Submission');
    for v_root_node_index in 0 .. dbms_xmldom.getlength(v_root_node_list) - 1 loop
    v_root_node := dbms_xmldom.item(v_root_node_list, v_root_node_index);
    v_elem        := dbms_xmldom.makeelement(v_root_node); 

    v_node_list := xmldom.getChildNodes(v_root_node);
    FOR j IN 0..dbms_xmldom.getLength( v_node_list ) -1 LOOP
       v_parent_node := DBMS_XMLDOM.item(v_node_list, j); 
    IF dbms_xmldom.getnodename(v_parent_node) = 'Claim' THEN
          v_node_count:= v_node_count+1;
       end if;
        END LOOP;   
          --dbms_output.put_line('v_node_count:'||v_node_count);
   WHILE v_claim_doc.existsNode('//Header[' || v_count || ']') = 1 LOOP
    V_RecordCount := v_claim_doc.extract('//Header[' || v_count || ']/RecordCount/text()').getStringVal();
    V_SenderID := v_claim_doc.extract('//Header[' || v_count || ']/SenderID/text()').getStringVal();
    V_ReceiverID := v_claim_doc.extract('//Header[' || v_count || ']/ReceiverID/text()').getStringVal();
    V_TransactionDate := v_claim_doc.extract('//Header[' || v_count || ']/TransactionDate/text()').getStringVal();
    V_DispositionFlag := v_claim_doc.extract('//Header[' || v_count || ']/DispositionFlag/text()').getStringVal();
    --v_benefit_type := v_claim_doc.extract('//Claim/Encounter[' || v_count || ']/StartType/text()').getStringVal();
    v_count := v_count + 1;
   END LOOP;
              
       OPEN sender_exist_cur(V_SenderID);
       FETCH sender_exist_cur INTO v_sender_exist_count;
       CLOSE sender_exist_cur;      
     --dbms_output.put_line('V_RecordCount:'||V_RecordCount);       
      IF (V_RecordCount =  v_node_count) /*and (V_ReceiverID = 'TPA033')*/ and v_sender_exist_count>0
      and(to_char(to_date(V_TransactionDate,'dd/mm/yyyy hh24:mi'),'dd-mon-yyyy') = to_char(sysdate,'dd-mon-yyyy') or to_char(to_date(V_TransactionDate,'dd/mm/yyyy hh24:mi'),'dd-mon-yyyy') >= '01-Jan-2011')
      and(upper(V_DispositionFlag) in ('PRODUCTION','TEST')) THEN 

  v_doc            := dbms_xmldom.newdomdocument(v_claim_doc);
  v_root_node_list := dbms_xmldom.getelementsbytagname(v_doc, 'Claim.Submission');
  for v_root_node_index in 0 .. dbms_xmldom.getlength(v_root_node_list) - 1 loop
    v_root_node := dbms_xmldom.item(v_root_node_list, v_root_node_index);
    v_elem        := dbms_xmldom.makeelement(v_root_node); 
    
    v_node_list := xmldom.getChildNodes(v_root_node);
    FOR j IN 0..dbms_xmldom.getLength( v_node_list ) -1 LOOP
       v_parent_node := DBMS_XMLDOM.item(v_node_list, j);
       
    CASE dbms_xmldom.getNodeNAME(v_parent_node)
        WHEN 'Header' THEN
           get_header_details ( v_parent_node,v_claim_doc,v_file_id );
        WHEN 'Claim' THEN
          get_claim_details( v_parent_node );
        ELSE
          NULL;
      END CASE;
     END LOOP;
    END LOOP;
    ELSE
    raise_application_error(-20388,'DATA MISS MATCH IN HEADER PART.');
    END IF;
  END LOOP;
  --END LOOP;
    open data_save_cur;
    fetch data_save_cur into v_eclm_xml_error_code,v_Eclm_Xml_Error_Msg;
    close data_save_cur;
   IF v_eclm_xml_error_code is null or v_Eclm_Xml_Error_Msg is null THEN
        commit;
   ELSE
        rollback;
   END IF;  
  
  exception
      when others then
        v_eclm_xml_error_code := sqlcode ;
        v_Eclm_Xml_Error_Msg := substr(sqlerrm,11,length(sqlerrm)) ;  
     /* insert into app.tpa_eclm_xml_logs(eclm_xml_error_code,Eclm_Xml_Error_Msg,claim_id,activity_id,activity_code,added_date) values(v_eclm_xml_error_code,v_Eclm_Xml_Error_Msg,clm_rec.claim_id,activity_rec.activity_id,activity_rec.code,sysdate);
       commit; 
       */
 END load_claim_request;
--===============================================================================
PROCEDURE save_dhpo_new_transactions(
                     v_download_seq_id	     in  app.dhpo_new_transaction_download.download_seq_id%type,
                     v_file_id	             in  app.dhpo_new_transaction_download.file_id%type,
                     v_file_name	         in  app.dhpo_new_transaction_download.file_name%type,
                     v_down_load_file	     in  app.dhpo_new_transaction_download.down_load_file%type,
                     v_file_type	         in  app.dhpo_new_transaction_download.file_type%type,
                     v_down_load_status	   in  app.dhpo_new_transaction_download.down_load_status%type,
                     v_result_type	       in  app.dhpo_new_transaction_download.result_type%type,
                     v_error_message	     in  app.dhpo_new_transaction_download.error_message%type,
					 v_alert               out varchar2
                  ) IS
                                


v_count number;
BEGIN

 if v_file_id is not null then
  select count(*) into v_count  from app.dhpo_new_transaction_download d where d.file_id=v_file_id 
  and d.down_load_file is not null;
 end if;
 
 IF v_count>0 then
    v_alert:='File Already Exist'; 
 ELSE 
     v_alert:='File Inserted Successfully';    
 IF NVL(v_download_seq_id, 0) = 0 THEN
    
   INSERT INTO dhpo_new_transaction_download
      (DOWNLOAD_SEQ_ID,
       FILE_ID,
       FILE_NAME,
       DOWN_LOAD_FILE,
       DOWN_LOAD_DATE,
       FILE_TYPE,
       DOWN_LOAD_STATUS,
       RESULT_TYPE,
       ERROR_MESSAGE,
       ADDED_DATE)
    VALUES
      (dhpo_new_transaction_seq.Nextval,
       V_FILE_ID,
       V_FILE_NAME,
       V_DOWN_LOAD_FILE,
       SYSDATE,
       nvl(V_FILE_TYPE,'CLM'),
       V_DOWN_LOAD_STATUS,
       V_RESULT_TYPE,
       V_ERROR_MESSAGE,
       SYSDATE ); 
 
  END IF;
  END IF;
  COMMIT;

END save_dhpo_new_transactions;
----============================================================================
PROCEDURE get_preauth_list (
    v_member_seq_id                  IN  pat_authorization_details.member_seq_id%TYPE,
    v_hosp_seq_id                    IN  pat_authorization_details.hosp_seq_id%TYPE,
    v_start_date                     IN  date,
    v_end_date                       IN  date,
    v_pre_auth_seq_id                OUT pat_authorization_details.pat_auth_seq_id%TYPE,
    v_auth_number                    OUT pat_authorization_details.Auth_Number%TYPE,
    v_tot_apr_amount                 OUT pat_authorization_details.tot_approved_amount%TYPE
     
  )
  IS
    TYPE bind_tab_type IS TABLE OF VARCHAR2(250) INDEX BY BINARY_INTEGER ;
    bind_tab                         bind_tab_type;
    i                                NUMBER(2) := 0;
    v_sql_str                        VARCHAR2(4000);
    v_where                          VARCHAR2(2000);
    v_from_date                      DATE := trunc(v_start_date);
    v_to_date                        DATE := trunc(v_end_date);
    
   cursor mem_pre_auth is 
   SELECT distinct a.pat_auth_seq_id,
        A.auth_number,
        a.tot_approved_amount 
       FROM pat_authorization_details A join tpa_hosp_info B ON (a.hosp_seq_id = b.hosp_seq_id AND a.pat_status_type_id = 'APR' AND a.pat_enhanced_yn = 'N' AND a.completed_yn = 'Y')
      LEFT OUTER JOIN tpa_enr_policy_member D ON ( a.member_seq_id = d.member_seq_id )
      WHERE  a.hosp_seq_id = v_hosp_seq_id 
      AND A.member_seq_id  = v_member_seq_id  AND trunc(A.hospitalization_date) >= v_from_date  AND TRUNC(A.hospitalization_date) <= nvl(v_to_date,v_from_date) 
      AND  A.claim_seq_id IS NULL ; 
    
  BEGIN
    OPEN mem_pre_auth;
    fetch mem_pre_auth into v_pre_auth_seq_id,v_auth_number,v_tot_apr_amount;
    close mem_pre_auth;

  END get_preauth_list;
-------------------------========================================================
PROCEDURE save_gn_main_transactions(
                     v_download_seq_id	     in  Gn_new_main_trans_download.download_seq_id%type,
                     v_file_id	             in  Gn_new_main_trans_download.file_id%type,
                     v_file_name	           in  Gn_new_main_trans_download.file_name%type,
                     v_down_load_file	       in  Gn_new_main_trans_download.down_load_file%type,
                     v_file_type	           in  Gn_new_main_trans_download.file_type%type,
                     v_down_load_status	     in  Gn_new_main_trans_download.down_load_status%type,
                     v_result_type	         in  Gn_new_main_trans_download.result_type%type,
                     v_error_message	       in  Gn_new_main_trans_download.error_message%type,
                     v_bifurcation_yn	       in  Gn_new_main_trans_download.Bifurcation_Yn%type,
                     v_alert                 out varchar2

                  ) IS
                                

v_count  number;

BEGIN
 if v_file_id is not null then
  select count(*) into v_count  from app.Gn_new_main_trans_download d where d.file_id=v_file_id 
  and d.down_load_file is not null;
 end if;
 
 IF v_count>0 then
    v_alert:='File Already Exist'; 
 ELSE 
     v_alert:='File Inserted Successfully';    
 IF NVL(v_download_seq_id, 0) = 0 THEN
    
   INSERT INTO Gn_new_main_trans_download
      (DOWNLOAD_SEQ_ID,
       FILE_ID,
       FILE_NAME,
       DOWN_LOAD_FILE,
       DOWN_LOAD_DATE,
       FILE_TYPE,
       DOWN_LOAD_STATUS,
       RESULT_TYPE,
       ERROR_MESSAGE,
       ADDED_DATE,
       bifurcation_yn)
    VALUES
      (Gn_new_main_trans_download_seq.Nextval,
       V_FILE_ID,
       V_FILE_NAME,
       V_DOWN_LOAD_FILE,
       SYSDATE,
       nvl(V_FILE_TYPE,'CLM'),
       V_DOWN_LOAD_STATUS,
       V_RESULT_TYPE,
       V_ERROR_MESSAGE,
       SYSDATE,
       v_bifurcation_yn ); 
 
  END IF;
  END IF;
  COMMIT;

END save_gn_main_transactions;
--===============================================================================
PROCEDURE select_gn_main_transactions (
    result_set                           OUT SYS_REFCURSOR  )
IS

BEGIN
 OPEN result_set FOR 
    select gn.download_seq_id,
      gn.file_id,
      gn.file_name,
      gn.down_load_date,
      gn.file_type,
      gn.down_load_status,
      gn.result_type,
      gn.error_message,
      gn.added_date,
      gn.down_load_file.getclobval() as xml_file,
      gn.bifurcation_yn
  from Gn_new_main_trans_download gn
  where gn.bifurcation_yn='N';
    
END select_gn_main_transactions;  

--==================================================================================
PROCEDURE save_gn_vidal_transactions(
                     v_download_seq_id	     in  dhpo_new_transaction_download.download_seq_id%type,
                     v_file_id	             in  dhpo_new_transaction_download.file_id%type,
                     v_file_name	           in  dhpo_new_transaction_download.file_name%type,
                     v_down_load_file	       in  dhpo_new_transaction_download.down_load_file%type,
                     v_file_type	           in  dhpo_new_transaction_download.file_type%type,
                     v_down_load_status	     in  dhpo_new_transaction_download.down_load_status%type,
                     v_result_type	         in  dhpo_new_transaction_download.result_type%type,
                     v_error_message	       in  dhpo_new_transaction_download.error_message%type,
                     v_insert_mode           in out  varchar2,--'GN','SH'
                     v_dhpo_tx_date          in  VARCHAR2,
                     v_dhpo_total_rec_cnt    in  Dhpo_New_Transaction_Download.Dhpo_Total_Rec_Cnt%type,
                     v_gn_rec_cnt            in  Dhpo_New_Transaction_Download.Clm_Rec_Cnt%type,
                     v_sh_rec_cnt            in  dhpo_new_transaction_download.Clm_Rec_Cnt%type

                  ) IS
                                


                      

v_count number:=0;
BEGIN

/* if v_file_id is not null and v_insert_mode='GN' then
  select count(*) into v_count  from dhpo_new_transaction_download d where d.file_id=v_file_id 
  and d.down_load_file is not null;
 elsif v_file_id is not null and v_insert_mode='SH' then
    select count(*) into v_count  from dhpo_sh_transactions d where d.file_id=v_file_id 
     and d.sh_file is not null ;
 end if;*/

/*for i in (select d.down_load_file.extract('/Claim.Submission/Claim/MemberID/text()').getStringVal() as memID,
  d.down_load_file.extract('/Claim.Submission/Header/TransactionDate/text()').getStringVal() as transdate,d.* FROM Gn_new_main_trans_download d 
  where NVL(d.bifurcation_yn,'N')='N')loop

 select count(*) into v_count from tpa_enr_policy_member pm where pm.tpa_enrollment_id = I.MEMID or pm.global_net_member_id = I.MEMID ;
 
 v_insert_mode:= CASE WHEN (I.MEMID LIKE '%DXB%' OR I.MEMID LIKE '%OIG%' OR I.MEMID LIKE '%OIF%') AND 
                            (I.MEMID NOT LIKE '%E0012%' AND I.MEMID NOT LIKE '%K0203%') or v_count>0 THEN 'GN' ELSE 'SH' END;
  */
 IF NVL(v_download_seq_id, 0) = 0 THEN
 if v_insert_mode='GN' then   
   INSERT INTO dhpo_new_transaction_download
      (DOWNLOAD_SEQ_ID,
       FILE_ID,
       FILE_NAME,
       DOWN_LOAD_FILE,
       DOWN_LOAD_DATE,
       FILE_TYPE,
       DOWN_LOAD_STATUS,
       RESULT_TYPE,
       ERROR_MESSAGE,
       ADDED_DATE,
       Dhpo_Tx_Date,
       Dhpo_Total_Rec_Cnt,
       Clm_Rec_Cnt
       )
    VALUES
      (dhpo_new_transaction_seq.Nextval,
       V_FILE_ID,
       V_FILE_NAME,
       V_DOWN_LOAD_FILE,
       SYSDATE,
       nvl(V_FILE_TYPE,'CLM'),
       V_DOWN_LOAD_STATUS,
       V_RESULT_TYPE,
       V_ERROR_MESSAGE,
       SYSDATE,
       TO_DATE(v_Dhpo_Tx_Date,'DD/MM/YYYY HH24:MI'),
       v_Dhpo_Total_Rec_Cnt,
       v_gn_rec_cnt
        ); 
  else
    INSERT INTO dhpo_sh_transactions
      (DOWNLOAD_SEQ_ID,
       FILE_ID,
       FILE_NAME,
       SH_FILE,
       DOWN_LOAD_DATE,
       FILE_TYPE,
       DOWN_LOAD_STATUS,
       RESULT_TYPE,
       ERROR_MESSAGE,
       ADDED_DATE,
       Dhpo_Tx_Date,
       Dhpo_Total_Rec_Cnt,
       Clm_Rec_Cnt)
    VALUES
      (dhpo_sh_transactions_seq.Nextval,
       V_FILE_ID,
       V_FILE_NAME,
       V_DOWN_LOAD_FILE,
       SYSDATE,
       nvl(V_FILE_TYPE,'CLM'),
       V_DOWN_LOAD_STATUS,
       V_RESULT_TYPE,
       V_ERROR_MESSAGE,
       SYSDATE ,
       TO_DATE(v_Dhpo_Tx_Date,'DD/MM/YYYY HH24:MI'),
       v_Dhpo_Total_Rec_Cnt,
       v_sh_rec_cnt); 
    
   END IF;
     update Gn_new_main_trans_download td
      set td.bifurcation_yn='Y'
         where td.file_id= v_file_id and td.file_name=v_file_name ;
  END IF;
  --END IF;
  --end loop;
  COMMIT;

END save_gn_vidal_transactions;
---=================================================================================
procedure select_sn_xml_files(
       v_downloadedYN                             IN dhpo_sh_transactions.user_downloaded_yn%type,
       v_xml_date_from                            IN varchar2 ,
       v_xml_date_to                              IN varchar2 ,
       v_fileName                                 IN varchar2 ,
       v_fileID                                   IN varchar2 ,
       v_trans_date                               IN varchar2 ,
       v_mode                                     in varchar2 ,--PAT,CLM
       v_sort_var                                 IN  VARCHAR2 ,
       v_sort_order                               IN  VARCHAR2 ,
       v_start_num                                IN  NUMBER ,
       v_end_num                                  IN  NUMBER ,
       result_set                                 out sys_refcursor )

is
   TYPE bind_tab_type IS TABLE OF VARCHAR2(250) INDEX BY BINARY_INTEGER ;
    bind_tab                             bind_tab_type;
    i                                    NUMBER(2) := 0;
   v_from_date    date := to_date(v_xml_date_from,'dd/mm/rrrr');
   v_to_date      date := nvl(to_date(v_xml_date_to,'dd/mm/rrrr'),sysdate);
   v_transact_date date:= to_date(v_trans_date,'dd/mm/rrrr');
   v_where    varchar2(32767);
   v_sql_str  varchar2(32767);

begin

if v_mode = 'CLM' then 
v_sql_str :='select st.download_seq_id,
            st.file_id, 
            st.file_name,
            st.down_load_date,
            st.user_downloaded_yn,
            st.user_downloaded_date,
            to_char(st.dhpo_tx_date,''dd/mm/yyyy hh:mi'') as dhpo_tx_date,
            st.dhpo_total_rec_cnt,
            st.clm_rec_cnt
        from app.dhpo_sh_transactions st';

    IF v_downloadedYN IS NOT NULL THEN
      v_where := v_where  || ' AND st.user_downloaded_yn = :v_downloadedYN ';
       i := i+1;
       bind_tab(i) := UPPER(v_downloadedYN);
    END IF;
    
    IF v_fileName IS NOT NULL THEN
      v_where := v_where  || ' AND st.file_name = :v_fileName ';
       i := i+1;
       bind_tab(i) := v_fileName;
    END IF;
    
    IF v_fileID IS NOT NULL THEN
      v_where := v_where  || ' AND st.file_id = :v_fileID ';
       i := i+1;
       bind_tab(i) := v_fileID;
    END IF;
   IF v_transact_date IS NOT NULL THEN
      v_where := v_where  ||' AND trunc(st.Dhpo_Tx_Date) = :v_transact_date';
      i := i+1;
      bind_tab(i) := UPPER(v_transact_date);
    END IF;
    IF v_from_date IS NOT NULL THEN
      v_where := v_where  ||' AND trunc(st.down_load_date) = :v_from_date';
      i := i+1;
      bind_tab(i) := UPPER(v_from_date);
    END IF;

    IF v_from_date IS NOT Null and v_to_date is not null THEN
      v_where := v_where  || ' AND trunc(st.down_load_date) between :v_from_date and :v_to_date';
      i := i+1;
      bind_tab(i) := v_from_date;
      i := i+1;
      bind_tab(i) := v_to_date+1;
      
    END IF;
    
    IF v_where IS NOT NULL THEN
      v_where   := ' WHERE '|| SUBSTR(v_where,5);
      v_sql_str := v_sql_str ||v_where;
    END IF;
    
    v_sql_str := 'SELECT * FROM
        (SELECT A.*,DENSE_RANK() OVER (ORDER BY '||v_sort_var||' '||v_sort_order||',ROWNUM)
        Q FROM (' ||v_sql_str|| ') A ) WHERE  Q>= :v_start_num AND Q<= :v_end_num ';

    IF bind_tab.FIRST IS NOT NULL THEN
       CASE bind_tab.COUNT
         WHEN 1  THEN OPEN result_set FOR v_sql_str USING bind_tab(1), v_start_num , v_end_num ;
         WHEN 2  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2), v_start_num , v_end_num ;
         WHEN 3  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2) ,bind_tab(3) , v_start_num , v_end_num ;
         WHEN 4  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2) ,bind_tab(3) ,bind_tab(4), v_start_num , v_end_num ;
         WHEN 5  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2) ,bind_tab(3) ,bind_tab(4), bind_tab(5), v_start_num , v_end_num ;
         WHEN 6  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2) ,bind_tab(3) ,bind_tab(4),bind_tab(5),bind_tab(6), v_start_num , v_end_num ;
         WHEN 7  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2) ,bind_tab(3) ,bind_tab(4),bind_tab(5),bind_tab(6), bind_tab(7), v_start_num , v_end_num ;
         END CASE;
     ELSE
       OPEN result_set FOR v_sql_str USING v_start_num , v_end_num ;
     END IF;
  else 
    v_sql_str :='select st.download_seq_id,
            st.file_id, 
            st.file_name,
            st.down_load_date,
            st.user_downloaded_yn,
            st.user_downloaded_date,
            to_char(st.dhpo_tx_date,''dd/mm/yyyy hh:mi'') as dhpo_tx_date,
            st.dhpo_total_rec_cnt,
            st.clm_rec_cnt
        from app.dhpo_pat_sh_transactions st';

    IF v_downloadedYN IS NOT NULL THEN
      v_where := v_where  || ' AND st.user_downloaded_yn = :v_downloadedYN ';
       i := i+1;
       bind_tab(i) := UPPER(v_downloadedYN);
    END IF;
    
    IF v_fileName IS NOT NULL THEN
      v_where := v_where  || ' AND st.file_name = :v_fileName ';
       i := i+1;
       bind_tab(i) := v_fileName;
    END IF;
    
    IF v_fileID IS NOT NULL THEN
      v_where := v_where  || ' AND st.file_id = :v_fileID ';
       i := i+1;
       bind_tab(i) := v_fileID;
    END IF;
   IF v_transact_date IS NOT NULL THEN
      v_where := v_where  ||' AND trunc(st.Dhpo_Tx_Date) = :v_transact_date';
      i := i+1;
      bind_tab(i) := UPPER(v_transact_date);
    END IF;
    IF v_from_date IS NOT NULL THEN
      v_where := v_where  ||' AND trunc(st.down_load_date) = :v_from_date';
      i := i+1;
      bind_tab(i) := UPPER(v_from_date);
    END IF;

    IF v_from_date IS NOT Null and v_to_date is not null THEN
      v_where := v_where  || ' AND trunc(st.down_load_date) between :v_from_date and :v_to_date';
      i := i+1;
      bind_tab(i) := v_from_date;
      i := i+1;
      bind_tab(i) := v_to_date+1;
      
    END IF;
    
    IF v_where IS NOT NULL THEN
      v_where   := ' WHERE '|| SUBSTR(v_where,5);
      v_sql_str := v_sql_str ||v_where;
    END IF;
    
    v_sql_str := 'SELECT * FROM
        (SELECT A.*,DENSE_RANK() OVER (ORDER BY '||v_sort_var||' '||v_sort_order||',ROWNUM)
        Q FROM (' ||v_sql_str|| ') A ) WHERE  Q>= :v_start_num AND Q<= :v_end_num ';

    IF bind_tab.FIRST IS NOT NULL THEN
       CASE bind_tab.COUNT
         WHEN 1  THEN OPEN result_set FOR v_sql_str USING bind_tab(1), v_start_num , v_end_num ;
         WHEN 2  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2), v_start_num , v_end_num ;
         WHEN 3  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2) ,bind_tab(3) , v_start_num , v_end_num ;
         WHEN 4  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2) ,bind_tab(3) ,bind_tab(4), v_start_num , v_end_num ;
         WHEN 5  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2) ,bind_tab(3) ,bind_tab(4), bind_tab(5), v_start_num , v_end_num ;
         WHEN 6  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2) ,bind_tab(3) ,bind_tab(4),bind_tab(5),bind_tab(6), v_start_num , v_end_num ;
         WHEN 7  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2) ,bind_tab(3) ,bind_tab(4),bind_tab(5),bind_tab(6), bind_tab(7), v_start_num , v_end_num ;
         END CASE;
     ELSE
       OPEN result_set FOR v_sql_str USING v_start_num , v_end_num ;
     END IF;
    
  end if;   
   

end select_sn_xml_files;
--==================================================================================
PROCEDURE update_sh_transactions(
                     v_download_seq_id	     in  dhpo_sh_transactions.download_seq_id%type,
                     v_update_mode           in  varchar2,--'V'(View),'U'(Update)
                     v_mode                  in varchar2,---PAT,CLM
                     v_files                 out sys_refcursor
                  ) IS
                                

BEGIN
 
  IF v_download_seq_id is not null THEN
   if v_mode ='CLM' then
    if v_update_mode ='U' then
     update dhpo_sh_transactions s 
      set s.user_downloaded_yn    = 'Y',
          s.user_downloaded_date  = sysdate
      where s.download_seq_id = v_download_seq_id; 
     
     end if;
      open v_files for
        select d.file_id,d.file_name,d.down_load_date,d.sh_file.getclobval() as sh_file from dhpo_sh_transactions d where d.download_seq_id=v_download_seq_id;
   else 
      if v_update_mode ='U' then
       update dhpo_pat_sh_transactions s 
       set s.user_downloaded_yn    = 'Y',
           s.user_downloaded_date  = sysdate
       where s.download_seq_id = v_download_seq_id; 
     
      end if;
      open v_files for
        select d.file_id,d.file_name,d.down_load_date,d.sh_file.getclobval() as sh_file from dhpo_pat_sh_transactions d where d.download_seq_id=v_download_seq_id;
    
   end if;
   END IF;
   commit;
   exception 
     when others then 
       rollback;
     

END update_sh_transactions;
--===============================================
PROCEDURE gn_valid_member (v_mem_id      varchar2,
                           v_flag        out varchar2)
                           is
       v_count   number(10):=0;
   begin
     select count(*) into v_count from tpa_enr_policy_member pm 
     where pm.tpa_enrollment_id = upper(v_mem_id) or upper(pm.global_net_member_id) = upper(v_mem_id);

   if v_count>0 then
        v_flag:='TRUE';
   else 
     v_flag:='FALSE';
   end if;
 end gn_valid_member;
 --========================================================================
 

end clm_xml_load_pkg;

/

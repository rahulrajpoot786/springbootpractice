--------------------------------------------------------
--  DDL for Synonymn CLAIM_SEQ_ID_SECOND_TEMP
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."CLAIM_SEQ_ID_SECOND_TEMP" FOR "APP"."CLAIM_SEQ_ID_SECOND_TEMP";

--------------------------------------------------------
--  DDL for Synonymn CLM_SMS_INTIMATION
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."CLM_SMS_INTIMATION" FOR "APP"."CLM_SMS_INTIMATION";

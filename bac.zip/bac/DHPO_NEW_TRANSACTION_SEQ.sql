--------------------------------------------------------
--  DDL for Synonymn DHPO_NEW_TRANSACTION_SEQ
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."DHPO_NEW_TRANSACTION_SEQ" FOR "APP"."DHPO_NEW_TRANSACTION_SEQ";

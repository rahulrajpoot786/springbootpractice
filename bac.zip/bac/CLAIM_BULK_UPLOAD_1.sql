--------------------------------------------------------
--  DDL for Package CLAIM_BULK_UPLOAD
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "VENUBABU"."CLAIM_BULK_UPLOAD" is

  -- Author  : MANAS.PRUSTY
  -- Created : 02/12/2018 11:35:19 AM
  -- Purpose : Upload caim bulk wise in excel
------------------------------------------------------------------------------------------------------ 
PROCEDURE clear_all; 
------------------------------------------------------------------------------------------------------
PROCEDURE claim_upload (v_xml_seq_id            IN OUT NUMBER,                     
                        v_clm_batch_seq_id      OUT APP.clm_bulk_upld_clm_details.clm_batch_seq_id%type,
                        v_batch_no              OUT APP.clm_bulk_upld_clm_details.batch_no%type,
                        v_tot_rec_cnt           OUT APP.clm_bulk_upld_xml_dta.tot_rec_cnt%type,
                        v_fail_cnt              OUT APP.clm_bulk_upld_xml_dta.fail_cnt%type,
                        v_success_cnt           OUT APP.clm_bulk_upld_xml_dta.success_cnt%type,
                        v_tot_claim_cnt         OUT APP.clm_bulk_upld_xml_dta.TOT_CLM_CNT%type,
                        v_tot_icd_cnt           OUT APP.clm_bulk_upld_xml_dta.TOT_CLM_ICD_CNT%type,
                        v_tot_act_cnt           OUT APP.clm_bulk_upld_xml_dta.TOT_CLM_ACT_CNT%type,
                        v_batch_tot_amnt        OUT APP.clm_batch_upload_details.batch_tot_amount%type,
                        v_added_by              IN NUMBER);  
------------------------------------------------------------------------------------------------------
PROCEDURE save_claim_xml
                       (v_xml_seq_id            IN OUT NUMBER,                     
                        v_clm_in_xl             IN XMLTYPE,
                        v_added_by              IN NUMBER,
                        v_file_name             IN VARCHAR2); 
------------------------------------------------------------------------------------------------------
PROCEDURE extract_claim_info
                       (v_xml_seq_id            IN NUMBER,                     
                        v_added_by              IN NUMBER); 
------------------------------------------------------------------------------------------------------
PROCEDURE validate_claim_info
                       (v_xml_seq_id            IN NUMBER, 
                        v_added_by              IN NUMBER);                              
------------------------------------------------------------------------------------------------------
PROCEDURE split_claims_info
                       (v_xml_seq_id            IN NUMBER, 
                        v_added_by              IN NUMBER);                             
------------------------------------------------------------------------------------------------------
 PROCEDURE update_clm_seq_no(v_xml_seq_id       IN NUMBER,
                             v_qtr_claim_count  IN NUMBER,
                             v_ind_claim_count  IN NUMBER,
                             v_oth_claim_count  IN NUMBER,
                             v_file_mx_no       IN VARCHAR2); 
--======================================================================================================
PROCEDURE save_clm_batch_details(v_clm_batch_seq_id  in out clm_batch_upload_details.clm_batch_seq_id%type,
                                 v_batch_no          in out clm_batch_upload_details.batch_no%type,
                                 v_sender_id         in clm_batch_upload_details.sender_id%type,
                                 v_receiver_id       in clm_batch_upload_details.receiver_id%type,
                                 v_received_date     in clm_batch_upload_details.received_date%type,
                                 v_record_count      in clm_batch_upload_details.record_count%type,
                                 v_batch_tot_amount  in clm_batch_upload_details.batch_tot_amount%type,
                                 v_tpa_office_aeq_id in clm_batch_upload_details.tpa_office_aeq_id%type,
                                 v_batch_status_type in clm_batch_upload_details.batch_status_type%type,
                                 v_benefit_type      in clm_batch_upload_details.benefit_type%type,
                                 v_claim_type        in clm_batch_upload_details.clm_type_gen_type_id%type,
                                 v_submission_type   in clm_batch_upload_details.submission_type_id%type,
                                 v_currency_type     in clm_batch_upload_details.currency_type%type,
                                 v_source_type       in clm_batch_upload_details.source_type_id%type,
                                 v_added_by          in clm_batch_upload_details.added_by%type,
                                 v_xml_seq_id        in NUMBER) ;                             
------------------------------------------------------------------------------------------------------  
PROCEDURE save_claim_details
                       (v_xml_seq_id            IN NUMBER,
                        v_clm_batch_seq_id      IN clm_batch_upload_details.clm_batch_seq_id%type,
                        v_batch_no              OUT clm_batch_upload_details.batch_no%type,
                        v_added_by              IN NUMBER);                              
------------------------------------------------------------------------------------------------------
FUNCTION get_benf_type_id 
                       (v_desc                  IN VARCHAR2)
 RETURN VARCHAR2;
------------------------------------------------------------------------------------------------------
FUNCTION check_data_type
                       (v_flag                  IN VARCHAR2,
                        v_value                 IN VARCHAR2)
 RETURN VARCHAR2;  
------------------------------------------------------------------------------------------------------
FUNCTION check_size    (v_value_typ             IN VARCHAR2,
                        v_value                 IN VARCHAR2,
                        v_add_fild              IN VARCHAR2 DEFAULT NULL)
 RETURN VARCHAR2; 
----------------------------------------------------------------------------------------------------
FUNCTION validate_data (v_flag                  IN VARCHAR2,
                       	v_id                    IN VARCHAR2,
                        v_id2                   IN VARCHAR2 DEFAULT NULL,
                        v_id3                   IN VARCHAR2 DEFAULT NULL)
 RETURN VARCHAR2  ;
------------------------------------------------------------------------------------------------------  
FUNCTION get_mem_seq_id(v_member_id             IN VARCHAR2,
                        v_hosp_date             IN DATE)
 RETURN NUMBER;
-------------------------------------------------------------------------------------------------------          
FUNCTION get_clinician_id
                       (V_CLM_XML_SEQ_ID        IN NUMBER)
 RETURN VARCHAR2; 
 -------------------------------------------------------------------------------------------------------          
FUNCTION get_clinician_nme
                       (V_CLM_XML_SEQ_ID        IN NUMBER)
 RETURN VARCHAR2; 
 -------------------------------------------------------------------------------------------------------          
FUNCTION get_lmp_date  (V_CLM_XML_SEQ_ID        IN NUMBER)
 RETURN DATE; 
-------------------------------------------------------------------------------------------------------          
FUNCTION get_symptoms(V_CLM_XML_SEQ_ID                   IN NUMBER)
   RETURN VARCHAR2; 
-------------------------------------------------------------------------------------------------------- 
FUNCTION check_prior_apr_dnl_code
                       (v_member_seq_id         IN NUMBER,
                        v_policy_seq_id         IN NUMBER,
                        v_vip_yn                IN VARCHAR2,
                        v_claim_type            IN VARCHAR2,
                        v_clm_req_amount        IN NUMBER,
                        v_pre_auth_no           IN VARCHAR2,
                        v_enrol_type_id         IN VARCHAR2)
  RETURN VARCHAR2;                                   
-------------------------------------------------------------------------------------------------------- 
FUNCTION check_prior_apr_dnl_desc
                       (v_member_seq_id         IN NUMBER,
                        v_policy_seq_id         IN NUMBER,
                        v_vip_yn                IN VARCHAR2,
                        v_claim_type            IN VARCHAR2,
                        v_clm_req_amount        IN NUMBER,
                        v_pre_auth_no           IN VARCHAR2,
                        v_enrol_type_id         IN VARCHAR2)
  RETURN VARCHAR2;  
-------------------------------------------------------------------------------------------------------- 
PROCEDURE save_exception_log
                       (v_xml_seq_id            IN NUMBER,
                        v_clm_xml_seq_id        IN NUMBER,
                        v_sql_code              IN VARCHAR2,
                        v_sql_msg               IN VARCHAR2,
                        v_bulk_eror_msg         IN CLOB,
                        v_added_by              IN NUMBER,
                        v_proc_name             IN VARCHAR2,
                        v_hosp_seq_id           IN NUMBER);  
-------------------------------------------------------------------------------------------------------- 
PROCEDURE get_error_log_list
                       (v_xml_seq_id            IN NUMBER,
                        v_file_name             IN VARCHAR2,
                        v_from_date             IN VARCHAR2,
                        v_to_date               IN VARCHAR2,
                        v_hosp_seq_id           IN NUMBER,
                        v_sub_type              IN VARCHAR2,
                        v_sort_var              IN VARCHAR2,
                        v_sort_order            IN VARCHAR2,
                        v_start_num             IN NUMBER,
                        v_end_num               IN NUMBER,
                        result_set              OUT SYS_REFCURSOR);                
-------------------------------------------------------------------------------------------------------- 
PROCEDURE get_error_log(v_xml_seq_id            IN VARCHAR2,
                        result_set              OUT SYS_REFCURSOR);                  
--------------------------------------------------------------------------------------------------------
PROCEDURE save_time_details(v_xml_seq_id            IN NUMBER,
                            v_flag                  IN VARCHAR2,
                            v_start_time            IN NUMBER);                                                                  
                                 
--------------------------------------------------------------------------------------------------------
PROCEDURE claim_upload_validation(v_xml_seq_id       IN OUT NUMBER,
                                  v_added_by         IN NUMBER);
                                 
---------------------------------------------------------------------------------------------------
PROCEDURE save_clm_batch_xml(v_xml_seq_id            IN NUMBER,
                               v_clm_batch_seq_id      OUT clm_batch_upload_details.clm_batch_seq_id%type,
                               v_batch_no              OUT clm_batch_upload_details.batch_no%type,
                               v_added_by              IN NUMBER);
-----------------------------------------------------------------------------------------------------
PROCEDURE claim_upload_job;

-----------------------------------------------------------------
PROCEDURE claim_adjudication;
--=================================================================================================
PROCEDURE save_resub_claims_xml (	v_xml_seq_id IN OUT NUMBER,
                                  v_xml_file   IN   XMLTYPE,
                                  v_added_by   IN   NUMBER,
                                  v_file_name  IN   VARCHAR2,
                                  v_sub_type   IN   VARCHAR2);
                                  
--=================================================================================================
PROCEDURE extract_resub_xml_Data (v_xml_seq_id  IN NUMBER ) ;                                 
--==================================================================================================
PROCEDURE upload_resubmission_claims(v_xml_seq_id        IN OUT app.clm_bulk_upld_resub_dtls.xml_seq_id%TYPE,
          	                         v_clm_batch_seq_id  OUT VARCHAR2,
                                     v_batch_no          OUT VARCHAR2,
                                     v_tot_rec_cnt       OUT VARCHAR2,
                                     v_fail_cnt          OUT VARCHAR2,                       
                                     v_succ_cnt          OUT VARCHAR2,
                                     v_no_of_claims      OUT VARCHAR2,
                                     v_batch_amt         OUT VARCHAR2,
                                     v_added_by          IN  NUMBER
                                     );
--==================================================================================================
PROCEDURE validate_resubmission_data(v_xml_seq_id IN app.clm_bulk_upld_resub_dtls.xml_seq_id%TYPE);
--===================================================================================================
FUNCTION validate_parent_claim (v_xml_seq_id   IN NUMBER,
                                v_member_id    IN VARCHAR2,
                                v_claim_number IN VARCHAR2,
                                v_hosp_seq_id  IN NUMBER
                                )
 RETURN VARCHAR2;
--=================================================================
PROCEDURE copy_parent_claim_dtls (
    v_xml_seq_id                      IN NUMBER,
    v_claim_seq_id                    IN OUT clm_authorization_details.claim_seq_id%TYPE,
    v_parent_claim_seq_id             IN clm_authorization_details.parent_claim_seq_id%TYPE,
    v_claim_batch_seq_id              IN clm_batch_upload_details.clm_batch_seq_id%TYPE ,
    v_requested_amount                IN clm_authorization_details.requested_amount%TYPE,
    v_added_by                        IN NUMBER
  );
--=================================================================
PROCEDURE Delete_Exceptional_Claims(v_xml_seq_id       NUMBER,
                                    v_clm_batch_seq_id NUMBER);
--=================================================================
end claim_bulk_upload;

/

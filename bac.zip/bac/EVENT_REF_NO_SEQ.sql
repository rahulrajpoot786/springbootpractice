--------------------------------------------------------
--  DDL for Synonymn EVENT_REF_NO_SEQ
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."EVENT_REF_NO_SEQ" FOR "APP"."EVENT_REF_NO_SEQ";

--------------------------------------------------------
--  DDL for Synonymn DHA_CPT_CODE_MASTER
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."DHA_CPT_CODE_MASTER" FOR "APP"."DHA_CPT_CODE_MASTER";

--------------------------------------------------------
--  DDL for Function EMP_INFO
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "VENUBABU"."EMP_INFO" (v_empno IN NUMBER,
                                     V1 OUT SYS_REFCURSOR,
                                     V out sys_refcursor)
RETURN sys_refcursor


AS
V_REQ sys_refcursor;
BEGIN
  OPEN V FOR  SELECT * FROM SCOTT.DEPT WHERE DEPTNO=10;
 OPEN V_REQ FOR SELECT * FROM MYEMP WHERE EMPNO=v_empno;
 OPEN V1 FOR SELECT * FROM SCOTT.EMP WHERE EMPNO=v_empno;
RETURN V_REQ;
END;

/

--------------------------------------------------------
--  DDL for Synonymn HOSP_MODIFIED_MOU_SEQ
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."HOSP_MODIFIED_MOU_SEQ" FOR "APP"."HOSP_MODIFIED_MOU_SEQ";

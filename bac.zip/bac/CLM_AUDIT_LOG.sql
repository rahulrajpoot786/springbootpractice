--------------------------------------------------------
--  DDL for Synonymn CLM_AUDIT_LOG
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."CLM_AUDIT_LOG" FOR "APP"."CLM_AUDIT_LOG";

--------------------------------------------------------
--  DDL for Synonymn CLM_DISCH_VOUCH_SEQ
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."CLM_DISCH_VOUCH_SEQ" FOR "APP"."CLM_DISCH_VOUCH_SEQ";

--------------------------------------------------------
--  DDL for Synonymn DHA_PROVIDER_TYPE
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."DHA_PROVIDER_TYPE" FOR "APP"."DHA_PROVIDER_TYPE";

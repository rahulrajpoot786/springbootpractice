--------------------------------------------------------
--  DDL for Synonymn ALL_TRAN
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."ALL_TRAN" FOR "APP"."ALL_TRAN";

--------------------------------------------------------
--  DDL for Synonymn CLM_AUDIT_SEQ
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."CLM_AUDIT_SEQ" FOR "APP"."CLM_AUDIT_SEQ";

--------------------------------------------------------
--  DDL for Synonymn CASH_BEN
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."CASH_BEN" FOR "APP"."CASH_BEN";

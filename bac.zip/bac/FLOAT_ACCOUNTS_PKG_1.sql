--------------------------------------------------------
--  DDL for Package FLOAT_ACCOUNTS_PKG
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "VENUBABU"."FLOAT_ACCOUNTS_PKG" IS

  -- Author  : GOVARDHANA_RG and Prasanna Kumar R J, SPAN Infotech.
  -- Created : 6/9/2006 3:30:00 PM
  -- Purpose : Create An Float Account To issue Checks To Insured Person.
  TYPE split_amt_type IS TABLE OF NUMBER INDEX BY VARCHAR2(3);
  --====================================================================================
  FUNCTION get_Rej_billno(v_claim_seq_id IN NUMBER) RETURN VARCHAR2
    DETERMINISTIC;
  --================================================================================================
  /*PROCEDURE select_float_acc_list(
    v_float_acc_number       IN      TPA_FLOAT_ACCOUNT.float_account_number%TYPE,
    v_float_acc_name         IN      TPA_FLOAT_ACCOUNT.float_account_name%TYPE,
    v_float_type             IN      TPA_FLOAT_ACCOUNT.float_type%TYPE,
    v_float_status           IN      TPA_FLOAT_ACCOUNT.float_status%TYPE,
    v_office_seq_id          IN      TPA_OFFICE_INFO.tpa_office_seq_id%TYPE,
    v_bank_name              IN      TPA_BANK_MASTER.bank_name%TYPE,
    v_acc_number             IN      TPA_BANK_ACCOUNTS.account_number%TYPE,
    v_ins_seq_id             IN      TPA_INS_INFO.ins_seq_id %TYPE,
    v_ins_comp_code_number   IN      TPA_INS_INFO.ins_comp_code_number%TYPE,
    v_sort_var               IN      VARCHAR2,
    v_sort_order             IN      VARCHAR2,
    v_start_num              IN      NUMBER  ,
    v_end_num                IN      NUMBER ,
    v_added_by               IN      NUMBER,
    result_set               OUT     SYS_REFCURSOR
  );*/
  PROCEDURE select_float_acc_list(v_float_acc_number     IN TPA_FLOAT_ACCOUNT.float_account_number%TYPE,
                                  v_float_acc_name       IN TPA_FLOAT_ACCOUNT.float_account_name%TYPE,
                                  v_float_type           IN TPA_FLOAT_ACCOUNT.float_type%TYPE,
                                  v_float_status         IN TPA_FLOAT_ACCOUNT.float_status%TYPE,
                                  v_office_seq_id        IN TPA_OFFICE_INFO.tpa_office_seq_id%TYPE,
                                  v_bank_name            IN TPA_BANK_MASTER.bank_name%TYPE,
                                  v_acc_number           IN TPA_BANK_ACCOUNTS.account_number%TYPE,
                                  v_ins_seq_id           IN TPA_INS_INFO.ins_seq_id %TYPE,
                                  v_ins_comp_code_number IN TPA_INS_INFO.ins_comp_code_number%TYPE,
                                  v_claim_settlement_no  IN TPA_CLAIMS_PAYMENT.claim_settlement_no%TYPE,
                                  v_sort_var             IN VARCHAR2,
                                  v_sort_order           IN VARCHAR2,
                                  v_start_num            IN NUMBER,
                                  v_end_num              IN NUMBER,
                                  v_added_by             IN NUMBER,
                                  result_set             OUT SYS_REFCURSOR);
  --===========================================================================================
  /*PROCEDURE select_float_acc_detail(
    v_float_seq_id        IN  OUT TPA_FLOAT_ACCOUNT.float_seq_id%TYPE,
    v_added_by            IN      NUMBER,
    result_set            OUT     SYS_REFCURSOR
  );*/
  PROCEDURE select_float_acc_detail(v_float_seq_id IN OUT TPA_FLOAT_ACCOUNT.float_seq_id%TYPE,
                                    v_added_by     IN NUMBER,
                                    result_set     OUT SYS_REFCURSOR,
                                    corporate_list OUT SYS_REFCURSOR);
  --========================================================================================

  PROCEDURE float_acc_save(v_float_seq_id         IN OUT TPA_FLOAT_ACCOUNT.float_seq_id%TYPE,
                           v_float_type           IN TPA_FLOAT_ACCOUNT.float_type%TYPE,
                           v_float_acc_name       IN TPA_FLOAT_ACCOUNT.float_account_name%TYPE,
                           v_float_status         IN TPA_FLOAT_ACCOUNT.float_status%TYPE,
                           v_effective_date       IN TPA_FLOAT_ACCOUNT.effective_date%TYPE,
                           v_expiration_date      IN TPA_FLOAT_ACCOUNT.expiration_date%TYPE,
                           v_bank_acc_seq_id      IN TPA_FLOAT_ACCOUNT.bank_acc_seq_id%TYPE,
                           v_ins_seq_id           IN TPA_FLOAT_ACCOUNT.ins_seq_id%TYPE,
                           v_group_reg_seq_id     IN TPA_FLOAT_ACCOUNT.group_reg_seq_id%TYPE,
                           v_established_amt      IN TPA_FLOAT_ACCOUNT.established_amt%TYPE,
                           v_comments             IN TPA_FLOAT_ACCOUNT.comments%TYPE,
                           v_prod_general_type_id IN tpa_float_account.prod_general_type_id%TYPE,
                           v_added_by             IN NUMBER,
                           v_process_type         IN TPA_FLOAT_ACCOUNT.PROCESS_TYPE%TYPE,
                           v_row_processed        OUT INTEGER);
  --=======================================================================================
  PROCEDURE select_float_acc_trn_list(v_float_seq_id     IN TPA_FLOAT_TRANSACTION.float_seq_id%TYPE,
                                      v_float_trn_number IN OUT TPA_FLOAT_TRANSACTION.float_trn_number%TYPE,
                                      v_trn_type         IN TPA_FLOAT_TRANSACTION.flt_trn_type%TYPE,
                                      v_trn_date         IN VARCHAR2,
                                      v_trn_to_date      IN VARCHAR2,
                                      v_sort_var         IN VARCHAR2,
                                      v_sort_order       IN VARCHAR2,
                                      v_start_num        IN NUMBER,
                                      v_end_num          IN NUMBER,
                                      v_added_by         IN NUMBER,
                                      
                                      result_set OUT SYS_REFCURSOR);
  --========================================================================================
  PROCEDURE select_float_acc_trn_detail(v_float_trn_seq_id IN OUT TPA_FLOAT_TRANSACTION.float_trn_seq_id%TYPE,
                                        v_float_seq_id     IN TPA_FLOAT_TRANSACTION.float_seq_id%TYPE,
                                        v_added_by         IN NUMBER,
                                        result_set         OUT SYS_REFCURSOR);
  --=======================================================================================
  PROCEDURE float_acc_trn_save(v_float_trn_seq_id IN OUT TPA_FLOAT_TRANSACTION.float_trn_seq_id%TYPE,
                               v_float_seq_id     IN TPA_FLOAT_TRANSACTION.float_seq_id%TYPE,
                               v_trn_type         IN TPA_FLOAT_TRANSACTION.flt_trn_type %TYPE,
                               v_trn_date         IN TPA_FLOAT_TRANSACTION.flt_trn_date %TYPE,
                               v_trn_amount       IN TPA_FLOAT_TRANSACTION.flt_trn_amount %TYPE,
                               v_comments         IN TPA_FLOAT_TRANSACTION.comments%TYPE,
                               v_added_by         IN NUMBER,
                               v_float_type       IN VARCHAR2,
                               v_currency_type    IN TPA_FLOAT_TRANSACTION.currency_type%TYPE, -- added by chiranjibi
                               v_rows_processed   OUT INTEGER);
  --========================================================================================
  PROCEDURE select_claims_list(v_float_seq_id        IN TPA_CLAIMS_PAYMENT.float_seq_id%TYPE,
                               v_debit_seq_id        IN TPA_DEBIT_NOTE.debit_seq_id%TYPE,
                               v_claim_settlement_no IN TPA_CLAIMS_PAYMENT.claim_settlement_no%TYPE,
                               v_enrollment_id       IN TPA_ENR_POLICY_MEMBER.tpa_enrollment_id%TYPE,
                               v_payment_mode        IN VARCHAR2, --added for KOC1103 IF EFT THEN SEARCH ONLY PENDING CLAIMS WHICH IS HAVING BANK ACN NUM ELSE WHICH DOESN'T HAVE ACCOUNT NUMBER RECORDS
                               v_claim_app_date        IN VARCHAR2,
                               v_corporate_name      IN tpa_group_registration.group_name%TYPE,
                               v_mem_name     IN TPA_ENR_POLICY_MEMBER.mem_name%TYPE,
                               v_claim_type   IN TPA_CLAIMS_PAYMENT.claim_type%TYPE,
                               v_policy_type  IN TPA_ENR_POLICY.enrol_type_id%TYPE,
                               v_in_favour_of        IN TPA_CLAIMS_PAYMENT.Payee_Name%TYPE,
                               v_added_by            IN NUMBER,
                               v_curency_type        IN VARCHAR2,
                               v_claim_recv_date     IN VARCHAR2,
                               v_qatar_id            IN TPA_ENR_POLICY_MEMBER.EMIRATE_ID%TYPE,
                               v_payment_to          IN VARCHAR2,
                               v_prov_ptnr_seq       IN VARCHAR2,
                               v_priority_claims     IN VARCHAR,
                               v_pr_from             IN VARCHAR2,
                               v_pr_to               IN VARCHAR2,
                               v_sort_var            IN VARCHAR2,
                               v_sort_order          IN VARCHAR2,
                               v_start_num           IN NUMBER,
                               v_end_num             IN NUMBER,
                               result_set     OUT SYS_REFCURSOR);
  --========================================================================================
  PROCEDURE select_claim_detail(v_payment_seq_id IN OUT TPA_CLAIMS_PAYMENT.payment_seq_id%TYPE,
                                v_float_seq_id   IN TPA_CLAIMS_PAYMENT.float_seq_id%TYPE,
                                v_added_by       IN NUMBER,
                                result_set       OUT SYS_REFCURSOR);

  --========================================================================================
  PROCEDURE cheque_printing_details_save(v_payment_seq_id      IN OUT TPA_CLAIMS_PAYMENT.payment_seq_id%TYPE,
                                         v_claim_settlement_no IN TPA_CLAIMS_PAYMENT.claim_settlement_no%TYPE,
                                         v_comments            IN TPA_CLAIMS_PAYMENT.remarks%TYPE,
                                         v_added_by            IN NUMBER,
                                         v_rows_processed      OUT INTEGER);
  --======================================================================================
  PROCEDURE float_acc_delete(v_float_seq_id   IN VARCHAR2,
                             v_added_by       IN NUMBER,
                             v_rows_processed OUT INTEGER);

  --====================================================================================
  PROCEDURE float_acc_tran_reverse(v_float_acc_seq_id IN TPA_FLOAT_TRANSACTION.float_seq_id%TYPE,
                                   v_float_trn_seq_id IN VARCHAR2,
                                   v_added_by         IN NUMBER,
                                   v_rows_processed   OUT INTEGER);
  --=======================================================================
  PROCEDURE pr_check_float(v_ins_seq_id           IN TPA_INS_INFO.ins_seq_id%TYPE,
                           v_prod_general_type_id IN tpa_float_account.prod_general_type_id%TYPE,
                           v_group_reg_seq_id     IN tpa_group_registration.group_reg_seq_id%TYPE,
                           v_claim_seq_id         IN clm_authorization_details.claim_seq_id%TYPE,
                           v_float_seq_id         OUT TPA_FLOAT_ACCOUNT.float_seq_id%TYPE);
  --=============================================================================
  PROCEDURE print_bank_advice(v_payment_seq_id IN VARCHAR2,
                              v_float_seq_id   IN TPA_FLOAT_ACCOUNT.float_seq_id%type,
                              v_payment_method IN TPA_CLAIMS_PAYMENT.payee_type%TYPE,
                              v_added_by       IN NUMBER,
                              v_rows_processed OUT INTEGER);
  --===========================================================================================================
  PROCEDURE float_accnts_unsettld_clm;
  --==============================================================================================================
  PROCEDURE generate_payment_advice(v_payment_seq_id IN VARCHAR2,
                                    v_float_seq_id   IN tpa_float_account.float_seq_id%TYPE,
                                    v_bank_type      IN VARCHAR2,
                                    --v_rpt_type          IN     VARCHAR2,
                                    v_batch_date     IN DATE,
                                    v_added_by       IN NUMBER,
                                    v_payment_type   IN VARCHAR2,
                                    v_pur_of_rem     IN VARCHAR2,
                                    v_rows_processed OUT INTEGER,
                                    v_resultset      OUT SYS_REFCURSOR);
  --=======================================================================================================================
  PROCEDURE generate_payment_advice_dtl(v_payment_seq_id IN VARCHAR2,
                                        v_float_seq_id   IN tpa_float_account.float_seq_id%TYPE,
                                        v_resultset      OUT SYS_REFCURSOR);
  --=======================================================================================================================
  PROCEDURE view_payment_advice(v_float_seq_id        IN TPA_FLOAT_ACCOUNT.float_seq_id%TYPE,
                                v_file_name           IN OUT TPA_BANK_ADVICE_BATCH.file_name%TYPE,
                                v_batch_number        IN TPA_BANK_ADVICE_BATCH.batch_seq_id%TYPE,
                                v_claim_settlement_no IN OUT tpa_claims_payment.claim_settlement_no%TYPE,
                                v_batch_date          IN VARCHAR2,
                                v_sort_var            IN VARCHAR2,
                                v_sort_order          IN VARCHAR2,
                                v_start_num           IN NUMBER,
                                v_end_num             IN NUMBER,
                                v_added_by            IN NUMBER,
                                v_resultset           OUT SYS_REFCURSOR);
  --=========================================================================================================================
  PROCEDURE select_payment_advice_list(v_float_seQ_id IN TPA_FLOAT_ACCOUNT.float_seq_id%Type,
                                       --v_bank_seq_id             IN     TPA_BANK_MASTER.bank_seq_id%TYPE,
                                       v_float_name    IN TPA_FLOAT_ACCOUNT.float_account_name%TYPE,
                                       v_office_seq_id IN TPA_OFFICE_INFO.tpa_office_seq_id%TYPE,
                                       v_bank_acc_no   IN TPA_BANK_ACCOUNTS.account_number%TYPE,
                                       v_added_by      IN NUMBER,
                                       v_curency_type  IN VARCHAR2,
                                       v_payment_to    IN VARCHAR2,
						    v_vol_base_type IN VARCHAR2,	
                                       v_sort_var      IN VARCHAR2,
                                       v_sort_order    IN VARCHAR2,
                                       v_start_num     IN NUMBER,
                                       v_end_num       IN NUMBER,
                                      
                                       result_set      OUT SYS_REFCURSOR);
  --============================================================================================================================
  PROCEDURE select_eft_payment_advice_list( --KOC1103
                                           v_float_seQ_id IN TPA_FLOAT_ACCOUNT.float_seq_id%Type,
                                           --v_bank_seq_id             IN     TPA_BANK_MASTER.bank_seq_id%TYPE,
                                           v_float_name    IN TPA_FLOAT_ACCOUNT.float_account_name%TYPE,
                                           v_office_seq_id IN TPA_OFFICE_INFO.tpa_office_seq_id%TYPE,
                                           v_bank_acc_no   IN TPA_BANK_ACCOUNTS.account_number%TYPE,
                                           v_added_by      IN NUMBER,
                                           v_curency_type  IN VARCHAR2,
                                           v_payment_to    IN VARCHAR2,
							 v_vol_base_type IN VARCHAR2,
                                           v_sort_var      IN VARCHAR2,
                                           v_sort_order    IN VARCHAR2,
                                           v_start_num     IN NUMBER,
                                           v_end_num       IN NUMBER,
                                           result_set      OUT SYS_REFCURSOR);
  --============================================================================================================================
  PROCEDURE manual_batch_list(v_payment_seq_id IN VARCHAR2,
                              v_resultset      OUT SYS_REFCURSOR);
  --================================================================================================================================
  PROCEDURE generate_ind_invoice_list(v_fin_policy_seq_id IN VARCHAR2,
                                      v_enrol_type        IN VARCHAR2,
                                      v_batch_date        IN DATE,
                                      v_added_by          IN NUMBER,
                                      v_resultset         OUT SYS_REFCURSOR);
  --======================================================================================================================================
  PROCEDURE view_inv_batch(v_batch_name IN VARCHAR2,
                           v_from_date  IN VARCHAR2,
                           v_to_date    IN VARCHAR2,
                           v_added_by   IN NUMBER,
                           v_invoice_number IN VARCHAR2,
                           v_group_id   IN VARCHAR2,
                           v_group_name IN VARCHAR2,
                           v_policy_num IN VARCHAR2,
                           v_inv_cred   IN VARCHAR2,
                           v_sort_var   IN VARCHAR2,
                           v_sort_order IN VARCHAR2,
                           v_start_num  IN NUMBER,
                           v_end_num    IN NUMBER,
                           result_set   OUT SYS_REFCURSOR);
  --==============================================================================================================================================
  PROCEDURE payment_advice_upload(v_cheque_number  IN tpa_claims_check.check_num%TYPE,
                                  v_cheque_amt     IN tpa_claims_check.check_amount%TYPE,
                                  v_cheque_date    IN tpa_claims_check.check_date%TYPE,
                                  v_batch_number   IN tpa_bank_advice_batch.batch_seq_id%TYPE,
                                  v_claim_settl_no IN tpa_claims_payment.claim_settlement_no%TYPE,
                                  v_payee_name     IN tpa_claims_payment.payee_name%TYPE,
                                  v_added_by       IN NUMBER);
  --======================================================================================================================================
  PROCEDURE upload_payment_advice(v_payment_advice_doc IN CLOB,
                                  v_log_file           OUT CLOB,
                                  v_sys_ref            OUT SYS_REFCURSOR);
  --===============================================================================================
  --Below procedure are used to upload the Transaction details of claims which has settled through EFT
  --===============================================================================================
  PROCEDURE EFT_payment_advice_upload( --KOC1103
                                      
                                      v_tran_num        IN tpa_claims_check.check_num%TYPE,
                                      v_tran_amt        IN tpa_claims_check.check_amount%TYPE,
                                      v_tran_date       IN tpa_claims_check.check_date%TYPE,
                                      v_batch_number    IN tpa_bank_advice_batch.batch_seq_id%TYPE,
                                      v_claim_settl_no  IN tpa_claims_payment.claim_settlement_no%TYPE,
                                      v_emp_acct_number IN tpa_claims_payment.emp_acct_number%TYPE,
                                      v_emp_bank_name   IN tpa_claims_payment.claim_settlement_no%TYPE,
                                      v_emp_bank_branch IN tpa_claims_payment.emp_bank_branch%TYPE,
                                      v_payee_name      IN tpa_claims_payment.payee_name%TYPE,
                                      v_added_by        IN NUMBER);
  --=================================================================================================================================================
  PROCEDURE cheque_nos_issued_yn(v_bank_acc_seq_id IN tpa_bank_accounts.bank_acc_seq_id%TYPE,
                                 v_check_num       IN tpa_claims_check.check_num%TYPE,
                                 v_result          OUT NUMBER);

--=================================================================================================================================================

  PROCEDURE manual_print_check(
    v_payment_seq_id     IN     VARCHAR2,
    v_float_seq_id       IN     TPA_FLOAT_ACCOUNT.float_seq_id%TYPE,
    v_cheque_number      IN     tpa_claims_check.check_num%TYPE,
    v_payment_method     IN     TPA_CLAIMS_PAYMENT.payee_type%TYPE,
    v_added_by           IN     NUMBER,
    v_rows_processed     OUT    INTEGER,
    v_resultset           OUT    SYS_REFCURSOR
  ) ;
--===================================================================================
  PROCEDURE set_fund_transfer(
    v_payment_seq_id     IN  VARCHAR2,
    v_float_seq_id       IN  TPA_FLOAT_ACCOUNT.float_seq_id%TYPE,
    v_remarks            IN  VARCHAR2,
    v_payment_method     IN  TPA_CLAIMS_PAYMENT.payee_type%TYPE,
    v_added_by           IN  NUMBER,
    v_rows_processed     OUT INTEGER
  );
--===================================================================================
  PROCEDURE get_debit_note_list (
    v_float_seq_id   IN  TPA_FLOAT_ACCOUNT.float_seq_id%TYPE,
    v_debit_status   IN  TPA_DEBIT_NOTE.debit_status_general_type_id%TYPE,
    v_debit_note_num IN  TPA_DEBIT_NOTE.debit_note_number%TYPE,
    v_from_date      IN  VARCHAR2,
    v_to_date        IN  VARCHAR2,
    v_flag           IN  VARCHAR2,
    v_sort_var       IN  VARCHAR2,
    v_sort_order     IN  VARCHAR2,
    v_start_num      IN  NUMBER,
    v_end_num        IN  NUMBER,
    v_result_set     OUT SYS_REFCURSOR
  );
--===================================================================================
 PROCEDURE get_debit_note_details (
    v_debit_seq_id IN  TPA_DEBIT_NOTE.debit_seq_id%TYPE,
    v_user_seq_id  IN  NUMBER,
    v_result_set   OUT SYS_REFCURSOR
 );
--===================================================================================
  PROCEDURE debit_note_save(
    v_float_seq_id   IN  TPA_FLOAT_ACCOUNT.float_seq_id%TYPE,
    v_debit_seq_id   IN  OUT TPA_DEBIT_NOTE.debit_seq_id%TYPE,
     v_debit_date    IN  TPA_DEBIT_NOTE.debit_date%TYPE,   
    v_debit_status   IN  TPA_DEBIT_NOTE.debit_status_general_type_id%TYPE,
    v_debit_amount   IN  TPA_DEBIT_NOTE.debit_amount%TYPE,
    v_remarks        IN  TPA_DEBIT_NOTE.Remarks%TYPE,
    v_added_by       IN  NUMBER,
    v_final_date     IN  TPA_DEBIT_NOTE.FINAL_DATE%TYPE,
    v_row_processed  OUT INTEGER
  );
--===================================================================================
 PROCEDURE get_debit_claims_list (
    v_float_seq_id    IN  TPA_FLOAT_ACCOUNT.float_seq_id%TYPE,
    v_debit_seq_id    IN  TPA_DEBIT_NOTE.debit_seq_id%TYPE,
    v_claim_Settle_No IN  TPA_CLAIMS_PAYMENT.Claim_Settlement_No%TYPE,
    v_Enrollment_Id   IN  CLM_ENROLL_DETAILS.tpa_enrollment_id%TYPE,
    v_claimant_name   IN  CLM_ENROLL_DETAILS.claimant_name%TYPE,
    v_claim_type      IN  CLM_INWARD.claim_general_type_id%TYPE,
    v_policy_type     IN  CLM_ENROLL_DETAILS.enrol_type_id%TYPE,
    v_Payee           IN  TPA_CLAIMS_PAYMENT.Payee_Name%TYPE,
    v_payment_mode    IN  TPA_CLAIMS_PAYMENT.payee_type%TYPE,--koc1163
    v_Assoc_UnAssoc   IN  VARCHAR2, -- DBA - Associated DBU - Unassociated
    v_sort_var        IN  OUT VARCHAR2,
    v_sort_order      IN  OUT VARCHAR2,
    v_start_num       IN  OUT NUMBER,
    v_end_num         IN  OUT NUMBER,
    v_result_set      OUT SYS_REFCURSOR
  );
--===================================================================================
  PROCEDURE save_debit_note_claims_assoc (
    v_debit_seq_id   IN  TPA_DEBIT_NOTE.debit_seq_id%TYPE,
    v_claim_seq_ids  IN  VARCHAR2,
    v_Assoc_UnAssoc  IN  VARCHAR2, -- DBA - Associated DBU - Unassociated
    v_added_by       IN  NUMBER,
    v_row_processed  OUT INTEGER
  );
--===================================================================================
  PROCEDURE get_debit_note_deposit_details (
    v_float_seq_id     IN  TPA_FLOAT_ACCOUNT.float_seq_id%TYPE,
    v_float_trn_seq_id IN  TPA_FLOAT_TRANSACTION.float_trn_seq_id%TYPE,
    v_result_set       OUT SYS_REFCURSOR
  );
--===================================================================================
  PROCEDURE save_debit_note_deposit_dtl (
    v_float_trn_seq_id        IN  TPA_FLOAT_TRANSACTION.float_trn_seq_id%TYPE,
    v_debit_seq_id            IN  TPA_DEBIT_NOTE.debit_seq_id%TYPE,
    v_deposited_amt           IN  TPA_DEBIT_NOTE_TRANSACTION.deposited_debit_amount%TYPE,
    v_flag                    IN  VARCHAR2,
    v_added_by                IN  NUMBER
  );
--===================================================================================
  PROCEDURE get_claims_deposit_details (
    v_debit_seq_id     IN  TPA_DEBIT_NOTE.debit_seq_id%TYPE,
    v_float_trn_seq_id IN  TPA_FLOAT_TRANSACTION.float_trn_seq_id%TYPE,
    v_result_set       OUT SYS_REFCURSOR
  );
--===================================================================================
  PROCEDURE save_claims_deposit_dtl (
    v_debit_note_trans_seq_id IN TPA_DEBIT_NOTE_TRANSACTION.debit_note_trans_seq_id%TYPE,
    v_claim_seq_id            IN TPA_DEBIT_CLAIMS_TRANSACTION.claim_seq_id%TYPE,
    v_deposited_amt             IN TPA_DEBIT_CLAIMS_TRANSACTION.deposited_amount%TYPE,
    v_flag                    IN  VARCHAR2,
    v_added_by                IN NUMBER
  );
--===================================================================================
  PROCEDURE delete_debit_notes (
    v_debit_seq_id  IN VARCHAR2,
    v_added_by      IN NUMBER,
    v_row_processed OUT INTEGER
  );
--===================================================================================
  PROCEDURE select_invoices_dtl_list (
    v_invoice_number                 IN TPA_FIN_INVOICE.invoice_number%TYPE,
    v_from_date                      IN  VARCHAR2,
    v_to_date                        IN  VARCHAR2,
    v_inv_status_general_type_id     IN TPA_FIN_INVOICE.inv_status_general_type_id%TYPE,
    v_group_id                       IN app.tpa_group_registration.group_id%type,
    v_group_name                     IN app.tpa_group_registration.group_name%type,
    v_policy_number                  IN app.tpa_enr_policy.policy_number%type,
    v_sort_var                       IN  VARCHAR2 ,
    v_sort_order                     IN  VARCHAR2 ,
    v_start_num                      IN  NUMBER,
    v_end_num                        IN  NUMBER ,
    v_added_by                       IN NUMBER,
    v_result_set                     OUT SYS_REFCURSOR
  );
--===================================================================================
  PROCEDURE select_invoices_dtl(
    v_invoice_seq_id               IN TPA_FIN_INVOICE.invoice_seq_id%TYPE,
    v_added_by                     IN NUMBER,
    v_result_set                   OUT SYS_REFCURSOR
  );
  

  --===================================================================================
  PROCEDURE save_invoice_dtl(v_invoice_seq_id             IN OUT TPA_FIN_INVOICE.invoice_seq_id%TYPE,
                             v_inv_from_date              IN TPA_FIN_INVOICE.inv_from_date%TYPE,
                             v_inv_to_date                IN TPA_FIN_INVOICE.inv_to_date%TYPE,
                             v_inv_status_general_type_id IN TPA_FIN_INVOICE.inv_status_general_type_id%TYPE,
                             v_include_old_yn             IN TPA_FIN_INVOICE.include_old_yn%TYPE,
                             v_added_by                   IN TPA_FIN_INVOICE.added_by%TYPE,
                             v_group_reg_seq_id           IN tpa_fin_policy_details.group_reg_seq_id%TYPE,
                             v_policy_seq_id              IN tpa_enr_policy.policy_seq_id%TYPE,
                             v_inv_gen_period             IN tpa_fin_invoice.inv_gen_period%TYPE, 
                             v_due_date_1                 IN DATE,
                             v_due_date_2                 IN DATE,
                             v_due_date_3                 IN DATE,
                             v_due_date_4                 IN DATE,
                             v_inv_type                   IN VARCHAR2,
                             v_row_processed              OUT INTEGER);
  --===================================================================================
  PROCEDURE select_inv_policy_list(v_group_reg_seq_id  IN tpa_fin_policy_details.group_reg_seq_id%TYPE,
                                   v_IND_YN            IN VARCHAR2,
                                   v_COR_YN            IN VARCHAR2,
                                   v_ING_YN            IN VARCHAR2,
                                   v_NCR_YN            IN VARCHAR2,
                                   v_tpa_office_seq_id IN tpa_office_info.tpa_office_seq_id%TYPE,
                                   v_from_date         IN VARCHAR2,
                                   v_to_date           IN VARCHAR2,
                                   v_Assoc_UnAssoc     IN VARCHAR2, -- DBA - Associated DBU - Unassociated
                                   v_invoice_seq_id    IN TPA_FIN_INVOICE.invoice_seq_id%TYPE,
                                   v_include_old_yn    IN TPA_FIN_INVOICE.include_old_yn%TYPE,
                                   v_added_by          IN NUMBER,
                                   v_inv_type          IN VARCHAR2,
                                   v_sort_var          IN VARCHAR2,
                                   v_sort_order        IN VARCHAR2,
                                   v_start_num         IN NUMBER,
                                   v_end_num           IN NUMBER,
                                   v_result_set        OUT SYS_REFCURSOR);
/*  --===================================================================================
  PROCEDURE save_inv_policy_assoc(v_invoice_seq_id  IN TPA_FIN_INVOICE.invoice_seq_id%TYPE,
                                  v_fin_pol_seq_ids IN VARCHAR2,
                                  v_Assoc_UnAssoc   IN VARCHAR2, -- DBA - Associated DBU - Unassociated
                                  v_added_by        IN NUMBER,
                                  v_row_processed   OUT INTEGER);*/
  --===================================================================================
  PROCEDURE save_inv_policy_assoc_all(v_group_reg_seq_id  IN tpa_fin_policy_details.group_reg_seq_id%TYPE,
                                      v_IND_YN            IN VARCHAR2,
                                      v_COR_YN            IN VARCHAR2,
                                      v_ING_YN            IN VARCHAR2,
                                      v_NCR_YN            IN VARCHAR2,
                                      v_tpa_office_seq_id IN tpa_office_info.tpa_office_seq_id%TYPE,
                                      v_from_date         IN VARCHAR2,
                                      v_to_date           IN VARCHAR2,
                                      v_Assoc_UnAssoc     IN VARCHAR2, -- DBA - Associated DBU - Unassociated
                                      v_invoice_seq_id    IN TPA_FIN_INVOICE.invoice_seq_id%TYPE,
                                      v_include_old_yn    IN TPA_FIN_INVOICE.include_old_yn%TYPE,
                                      v_added_by          IN NUMBER,
                                      v_row_processed     OUT INTEGER);
  --===================================================================================================
  PROCEDURE get_new_inv_from_date(--v_group_reg_seq_id  IN tpa_fin_policy_details.group_reg_seq_id%TYPE,
                                  v_new_inv_from_date OUT DATE);
  --===================================================================================
  PROCEDURE tpa_commission(v_inv_policy_seq_id         IN VARCHAR2,
                           v_start_date            IN VARCHAR2,
                           v_end_date              IN VARCHAR2,
                           v_added_by              IN NUMBER,
                           --Individual_Enrl_cur     OUT SYS_REFCURSOR,
                           --Individual_End_cur      OUT SYS_REFCURSOR,
                           --Corporate_Enrl_cur      OUT SYS_REFCURSOR, commented in cr0229
                           --Corporate_End_cur       OUT SYS_REFCURSOR,
                           --Non_Corp_Enrl_cur       OUT SYS_REFCURSOR,
                           --Non_Corp_End_cur        OUT SYS_REFCURSOR,
                           --Ind_as_group_Enrl_cur   OUT SYS_REFCURSOR,
                           --Ind_as_group_End_cur    OUT SYS_REFCURSOR,
                           --start_date_cur          OUT SYS_REFCURSOR,
                           --bo_do_cur               OUT SYS_REFCURSOR,
                           --summary_cur             OUT SYS_REFCURSOR,
                           --policy_type_summary_cur OUT SYS_REFCURSOR,
                           corp_dtl_premium_cur    OUT SYS_REFCURSOR,  
                           corp_mem_clm_inp_cur    OUT SYS_REFCURSOR, 
                           v_batch_seq_id          OUT tpa_inv_batch.batch_seq_id%TYPE);
  --===================================================================================
  PROCEDURE get_bank_advice_save_file_name(v_batch_file_no         IN tpa_bank_advice_batch.batch_file_no%TYPE,
                                           v_bank_advice_file_name OUT VARCHAR2);
  --===================================================================================
  -- this procedure is used to display list of paid claims records from tpa_claims_payment.
  PROCEDURE select_batch_claims_list(v_float_seq_id        IN TPA_CLAIMS_PAYMENT.float_seq_id%TYPE,
                                     v_from_date           IN VARCHAR2,
                                     v_to_date             IN VARCHAR2,
                                     v_claim_settlement_no IN TPA_CLAIMS_PAYMENT.claim_settlement_no%TYPE,
                                     v_payment_type        IN VARCHAR2, --ADDED FOR KOC1103
                                     v_sort_var            IN VARCHAR2,
                                     v_sort_order          IN VARCHAR2,
                                     v_start_num           IN NUMBER,
                                     v_end_num             IN NUMBER,
                                     v_added_by            IN NUMBER,
                                     result_set            OUT SYS_REFCURSOR);
  --===================================================================================
  PROCEDURE get_tds_amount(v_claim_seq_id    IN tpa_claims_payment.claim_seq_id%TYPE,
                           v_hosp_seq_id     IN tpa_claims_payment.hosp_seq_id%TYPE,
                           v_approved_amount IN OUT tpa_claims_payment.approved_amount%TYPE,
                           split_amt_tab     IN OUT split_amt_type,
                           split_perc_tab    IN OUT split_amt_type,
                           v_exist_yn        IN OUT VARCHAR2,
                           v_date            IN DATE := trunc(SYSDATE));
  --===================================================================================
  PROCEDURE save_clm_tds_details(v_payment_seq_id  IN TPA_CLM_TDS_DETAILS.payment_seq_id%TYPE,
                                 v_claim_seq_id    IN TPA_CLM_TDS_DETAILS.claim_seq_id%TYPE,
                                 v_approved_amount IN TPA_CLM_TDS_DETAILS.approved_amount%TYPE,
                                 v_check_amount    IN TPA_CLM_TDS_DETAILS.check_amount%TYPE,
                                 split_amt_tab     IN split_amt_type,
                                 split_perc_tab    IN split_amt_type,
                                 v_payment_type    IN TPA_CLM_TDS_DETAILS.payment_type%TYPE,
                                 v_added_by        IN TPA_CLM_TDS_DETAILS.added_by%TYPE);
  --===================================================================================
  PROCEDURE save_report_master(v_start_date IN DATE, v_end_date IN DATE);
  --===================================================================================
  PROCEDURE save_tpa_float_group_assoc(v_float_seq_id     IN tpa_float_group_assoc.float_seq_id%TYPE,
                                       v_group_reg_seq_id IN tpa_float_group_assoc.group_reg_seq_id%TYPE,
                                       v_policy_number    IN tpa_float_group_assoc.policy_number%TYPE, --added by chiranjibi
                                       v_added_by         IN tpa_float_group_assoc.added_by%TYPE,
                                       v_rows_processed   IN OUT NUMBER);
  --===================================================================================
  PROCEDURE delete_tpa_float_group_assoc(v_tpa_float_group_assoc_seq IN tpa_float_group_assoc.tpa_float_group_assoc_seq%TYPE,
                                         v_rows_processed            OUT NUMBER);
  --===================================================================================
  PROCEDURE select_float_group_assoc(v_float_seq_id IN tpa_float_account.float_seq_id%TYPE,
                                     v_result_set   OUT SYS_REFCURSOR);
  --===================================================================================
  FUNCTION get_date_of_inception(v_tpa_enrollment_id IN tpa_enr_policy_member.tpa_enrollment_id%TYPE,
                                 v_policy_seq_id     IN tpa_enr_policy.policy_seq_id%TYPE,
                                 v_ins_seq_id        IN tpa_enr_policy.ins_seq_id%TYPE)
    RETURN VARCHAR2 DETERMINISTIC;
  --===================================================================================
  PROCEDURE generate_oi_payment_advice(v_payment_seq_id IN VARCHAR2,
                                       v_float_seq_id   IN tpa_float_account.float_seq_id%TYPE,
                                       v_bank_type      IN VARCHAR2, -- '0' for CITI, '1' for UTI and '2' for ICICI bank
                                       v_batch_date     IN DATE,
                                       v_added_by       IN NUMBER,
                                       v_rows_processed OUT INTEGER,
                                       v_resultset      OUT SYS_REFCURSOR);
  /*==============================================================================================
    Name       : generate_boi_payment_advice
    Created on : 01-10-2012
    Created By : Ibrahim Sayyed
    Company    : RCS Technologies
    Added for  : KOC1220
    Comments   : This procedure is used to generate xlreport for payment advice
  ============================================================================================== */
  PROCEDURE generate_boa_payment_advice(v_payment_seq_id IN VARCHAR2,
                                        v_float_seq_id   IN tpa_float_account.float_seq_id%TYPE,
                                        v_resultset      OUT SYS_REFCURSOR);
  -- ==============================================================================================
  function boa_unique(v_id number) return number;
  --============================================================================
  PROCEDURE select_corporate_list(v_policy_number     IN tpa_enr_policy.policy_number%TYPE, --added by chiranjibi      
                                  v_group_id          IN tpa_group_registration.group_id%TYPE,
                                  v_group_name        IN tpa_group_registration.group_name%TYPE,
                                  v_tpa_office_seq_id IN tpa_office_info.tpa_office_seq_id%TYPE,
                                  v_enrol_type_id     IN tpa_enr_policy.enrol_type_id%TYPE,
                                  v_sort_var          IN VARCHAR2 := 'group_name',
                                  v_sort_order        IN VARCHAR2 := 'ASC',
                                  v_start_num         IN NUMBER := 1,
                                  v_end_num           IN NUMBER := 25,
                                  result_set          OUT SYS_REFCURSOR);
  --============================================================================================
  PROCEDURE save_finance_logs(V_FIN_LOG_SEQ_ID    IN FINANCE_LOGS.FIN_LOG_SEQ_ID%TYPE,
                              V_TPA_BATCH_SEQ_ID  IN finance_logs.fin_batch_seq_id%TYPE,
                              V_ERROR_NO          IN FINANCE_LOGS.ERROR_NO%TYPE,
                              V_ERROR_MESSAGE     IN FINANCE_LOGS.ERROR_MESSAGE%TYPE,
                              V_ERROR_TYPE        IN FINANCE_LOGS.ERROR_TYPE%TYPE,
                              V_UPLOAD_TYPE       IN FINANCE_LOGS.UPLOAD_TYPE%TYPE,
                              V_CLM_SETTLEMENT_NO IN FINANCE_LOGS.claim_settlement_no%TYPE,
                              v_policy_no         IN FINANCE_LOGS.policy_number%TYPE,
                              v_enrolment_number  IN FINANCE_LOGS.enrollment_id%TYPE,
                              v_employee_no       IN FINANCE_LOGS.employee_no%TYPE,
                              v_empanel_number    IN FINANCE_LOGS.empanelment_no%TYPE,
					v_batch_number      IN FINANCE_LOGS.batch_number%TYPE,
                              V_ADDED_BY          IN FINANCE_LOGS.ADDED_BY%TYPE);
  --==========================================================================================  
  PROCEDURE print_ENBD_check(v_payment_seq_id IN VARCHAR2,
                             v_float_seq_id   IN TPA_FLOAT_ACCOUNT.float_seq_id%TYPE,
                             v_added_by       IN NUMBER,
                             v_batch_date     IN DATE,
                             v_rows_processed OUT INTEGER,
                             v_resultset      OUT SYS_REFCURSOR,
                             v_conresultset   OUT SYS_REFCURSOR,
                             v_file_name      IN  VARCHAR2);
  --============================================================================
  PROCEDURE print_ENBD_Consolidated_check(v_payment_seq_id IN VARCHAR2,
                                          v_float_seq_id   IN TPA_FLOAT_ACCOUNT.float_seq_id%TYPE,
                                          v_added_by       IN NUMBER,
                                          v_batch_date     IN DATE,
                                          v_rows_processed OUT INTEGER,
                                          v_resultset      OUT SYS_REFCURSOR);
  --==============================================================================  
   PROCEDURE count_enbd_list (p_float_seq_id IN NUMBER,
                             p_file_name    IN VARCHAR2
                            );
--===============================================================================================
PROCEDURE get_invoice_details(v_inv_policy_seq_id     IN VARCHAR2,
                              rec_invoice_details     OUT SYS_REFCURSOR);
--===============================================================================================
FUNCTION get_claimed_amount (v_member_seq_id        IN NUMBER)
  RETURN NUMBER;                                                          
--===============================================================================================
FUNCTION get_mem_clm_inp_cnt (v_member_seq_id        IN NUMBER)
  RETURN NUMBER;  

--===============================================================================================
FUNCTION get_mem_clm_cnt (v_member_seq_id        IN NUMBER)
  RETURN NUMBER;  
  --==============================================================================
    PROCEDURE payment_upload_details (v_claim_settlement_no IN VARCHAR2,
                              v_float_seq_id   IN TPA_FLOAT_ACCOUNT.float_seq_id%TYPE,
                              v_currency_type  IN VARCHAR2,
                              v_payment_method IN TPA_CLAIMS_PAYMENT.payee_type%TYPE,
                              v_payment_to          IN  VARCHAR2,
                              v_rows_processed OUT INTEGER,
                              V_RESULT         OUT SYS_REFCURSOR);
  --=================================================================================
   procedure batch_log
       (v_indate   in varchar2,
        v_outdate  in varchar2,
        v_flag     in varchar2,      --P --payment-- A --PAYMENT ADVICE-- D--DEBIT NOTE
        v_result   out sys_refcursor);
   --=============================================================================
   PROCEDURE payment_advice_upload_details (v_claim_settlement_no IN VARCHAR2,
                              v_float_seq_id   IN TPA_FLOAT_ACCOUNT.float_seq_id%TYPE,
                              v_currency_type  IN VARCHAR2,
                              v_payment_method IN TPA_CLAIMS_PAYMENT.payee_type%TYPE,
                              v_payment_to          IN  VARCHAR2,
                              v_rows_processed OUT INTEGER,
                              V_RESULT         OUT SYS_REFCURSOR);     
  --========================================================================================
  /*PROCEDURE payment_advice_upload_details(
                             v_claim_settlement_no IN VARCHAR2,
                             v_float_seq_id   IN TPA_FLOAT_ACCOUNT.float_seq_id%TYPE,
                             v_added_by       IN NUMBER,
                             v_batch_date     IN DATE,
                             v_currency_type  IN clm_authorization_details.currency_type%TYPE,
                             v_rows_processed OUT INTEGER,
                             v_resultset      OUT SYS_REFCURSOR,
                             v_conresultset   OUT SYS_REFCURSOR,
                             v_file_name      IN VARCHAR2);*/
  --============================================================================================
  PROCEDURE Upload_Payment_Error_log (v_flag             IN   VARCHAR2,
                                      v_batch_number     IN   NUMBER,
                                      v_error_log_count  OUT  SYS_REFCURSOR,
                                      v_error_log        OUT   SYS_REFCURSOR,
                                      v_error_log1       OUT   SYS_REFCURSOR );
  --==================================================================================
 PROCEDURE Gen_Detail_Cons_advice  (v_payment_seq_id IN CLOB,
                                    v_float_seq_id   IN tpa_float_account.float_seq_id%TYPE,
                                    v_added_by       IN NUMBER,
                                    v_batch_date     IN DATE,
                                    v_payment_type   IN VARCHAR2,
                                    v_pur_of_rem     IN VARCHAR2,
                                    v_pay_tras_to    IN VARCHAR2,
                                    v_bank_type      IN VARCHAR2,
                                    v_vol_base_type  IN VARCHAR2,
                                    v_deb_ban_seq_id IN VARCHAR2,
                                    v_rows_processed OUT INTEGER,
                                    v_resultset      OUT SYS_REFCURSOR,
                                    v_consolidated   OUT SYS_REFCURSOR
                                    
                                   ) ;
  --===================================================================
  PROCEDURE finance_cheque_no_upld_err_log(v_batch_number in  VARCHAR2,
                                           v_failed_count out SYS_REFCURSOR);
  --========================================================================
  PROCEDURE Apply_fast_and_vol_discounts (v_payment_seq_id   IN VARCHAR,
                                          v_float_seq_id     IN NUMBER,
                                          v_batch_date       IN VARCHAR2,
                                          v_batch_seq_id     IN NUMBER,
                                          v_pay_tras_to      IN VARCHAR2,
                                          v_vol_base_type    IN VARCHAR2);
  --===================================================================
   PROCEDURE settlement_list(p_settlement            IN   tpa_claims_payment.claim_settlement_no%TYPE,
                            p_payment_method        IN   VARCHAR2,
                            p_claim_type            IN   VARCHAR2,
                            p_advice_batchno        IN   TPA_BANK_ADVICE_BATCH.batch_seq_id%TYPE,
                            p_advice_batch_date     IN   VARCHAR2,
                            p_finance_status        IN   tpa_claims_payment.claim_payment_status%TYPE :='SENT_TO_BANK',   
                            p_sort_var              IN   VARCHAR2,
                            p_sort_order            IN   VARCHAR2,
                            p_start_num             IN   NUMBER,
                            p_end_num               IN   NUMBER,
                            result_set              OUT SYS_REFCURSOR
                           ); 
  --================================================================== 
 PROCEDURE bringback_to_pending (p_settlement_no      IN  VARCHAR2,--|1180059384|1180060438||
                                 p_added_by           IN  NUMBER,
                                 p_remarks            IN  VARCHAR2,
                                 result_cnt           OUT NUMBER
                                );                                       
  --==================================================================
  PROCEDURE print_check (v_payment_seq_id IN VARCHAR2,
                              v_float_seq_id   IN TPA_FLOAT_ACCOUNT.float_seq_id%TYPE,
                              v_cheque_number  IN tpa_claims_check.check_num%TYPE,
                              v_payment_method IN TPA_CLAIMS_PAYMENT.payee_type%TYPE,
                              v_added_by       IN NUMBER,
                              v_batch_date     IN DATE,
                              v_rows_processed OUT INTEGER,
                              v_resultset      OUT SYS_REFCURSOR);
 --==================================================================================                             
 ---- Manual Cheque Generation Report Log
PROCEDURE view_manual_check_rpt(v_float_seq_id        IN TPA_FLOAT_ACCOUNT.float_seq_id%TYPE,
                                v_file_name           IN OUT TPA_BANK_ADVICE_BATCH.file_name%TYPE,
                                v_batch_number        IN TPA_BANK_ADVICE_BATCH.batch_seq_id%TYPE,
                                v_claim_settlement_no IN OUT tpa_claims_payment.claim_settlement_no%TYPE,
                                v_batch_date          IN VARCHAR2,
                                v_sort_var            IN VARCHAR2,
                                v_sort_order          IN VARCHAR2,
                                v_start_num           IN NUMBER,
                                v_end_num             IN NUMBER,
                                v_resultset           OUT SYS_REFCURSOR);
 --==================================================================================
 PROCEDURE Claims_Dump_Into_ERP (v_payment_seq_id   IN VARCHAR,
                                 v_pay_adv_batch    IN NUMBER,
                                 v_flag             IN VARCHAR2); 
 --================================================================================
 PROCEDURE Invoice_Dump_Into_ERP (v_invoice_seq_id VARCHAR2,
                                 v_policy_seq_id  VARCHAR2,
                                 v_mod_flag       VARCHAR2,
                                 v_success_YN OUT VARCHAR2);
 --=================================================================================
                            
END FLOAT_ACCOUNTS_PKG;

/

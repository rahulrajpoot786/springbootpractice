--------------------------------------------------------
--  DDL for Package Body CHEQUE_INFO_PKG
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "VENUBABU"."CHEQUE_INFO_PKG" IS

--=====================================================================================
  --this procedure is used to dispaly list of cheques to float account number .
  PROCEDURE select_chq_list(
    v_check_num             IN    TPA_CLAIMS_CHECK.check_num%TYPE,
    v_float_acc_number      IN    TPA_FLOAT_ACCOUNT.float_account_number%TYPE,
    v_check_status          IN    TPA_CLAIMS_CHECK.check_status%TYPE,
    v_start_date            IN    VARCHAR2,
    v_end_date              IN    VARCHAR2,
    v_claim_settlement_no   IN    TPA_CLAIMS_PAYMENT.claim_settlement_no%TYPE,
    v_claim_type            IN    TPA_CLAIMS_PAYMENT.claim_type%TYPE,
    v_ins_seq_id            IN    TPA_INS_INFO.ins_seq_id%TYPE,
    v_ins_comp_code_number  IN    TPA_INS_INFO.ins_comp_code_number%TYPE,
    v_batch_number          IN    TPA_CLAIMS_CHECK.batch_number%TYPE,
    v_policy_number         IN    TPA_ENR_POLICY.policy_number%TYPE,
    v_enrollment_id         IN    TPA_ENR_POLICY_MEMBER.tpa_enrollment_id%TYPE,
    v_payee_method          IN    TPA_CLAIMS_PAYMENT.payee_type%TYPE,
    v_sort_var              IN    VARCHAR2,
    v_sort_order            IN    VARCHAR2 := 'ASC',
    v_start_num             IN    NUMBER   := 1,
    v_end_num               IN    NUMBER   := 25,
    v_added_by              IN    NUMBER,
    v_qatar_id              IN    TPA_ENR_POLICY_MEMBER.Emirate_Id%type,
    result_set              OUT    SYS_REFCURSOR
  )
  IS
    v_sql_str             VARCHAR2(4000);
    v_from_date           DATE  :=  TO_DATE(v_start_date,'DD/MM/YYYY');
    v_to_date             DATE  :=  TO_DATE(v_end_date,'DD/MM/YYYY');
    TYPE bind_tab_type IS TABLE OF VARCHAR2(250) INDEX BY BINARY_INTEGER ;
    bind_tab                             bind_tab_type;
    i                                    NUMBER(2) := 0;
    v_where               VARCHAR2(1000);
  BEGIN
    --displaying only logically deled records
    v_sql_str :=
      'SELECT
        A.claims_chk_seq_id,
        --A.check_num,
        --CASE WHEN C.Payee_Type=''EFT'' THEN ''EFT'' ELSE to_char(A.check_num) END AS check_num,
        CASE WHEN a.PAYMENT_TYPE=''EFT'' THEN ''EFT-''||to_char(A.check_num) when a.PAYMENT_TYPE=''PCA'' THEN ''CHQ-''||to_char(A.check_num) else (CASE WHEN C.Payee_Type=''EFT'' THEN ''EFT-''||to_char(A.check_num) ELSE to_char(A.check_num) END) END AS check_num,--ADDED FOR KOC1103 ,koc1175
                   /*For eft when do print cheque that time only amount insert into cheque info table,if NH Claim it is inserting without tax deduction but tax deduction will
                    be done in next step payment advice. after cheque uploading it will show exact cheque data in claim,cheque_info,account_info modules else it will show null.
                    --(else before it will show wrong data for NG claims*/
        D.float_account_number,
        H.description as check_status,
        A.check_date,
        C.claim_settlement_no,
        G.description AS claim_type,
        E.ins_comp_name,
        F.description status,
        OI.office_name,
        C.Payment_Seq_Id
        FROM tpa_claims_check A LEFT OUTER JOIN tpa_payment_checks_details B ON(A.claims_chk_seq_id = B. claims_chk_seq_id)
        LEFT OUTER JOIN tpa_claims_payment C ON(C.payment_seq_id = B.payment_seq_id)
        LEFT OUTER JOIN tpa_float_account  D ON (C.float_seq_id = D.float_seq_id)
        JOIN tpa_bank_accounts BA ON(D.bank_acc_seq_id=BA.bank_acc_seq_id)
        JOIN tpa_office_info OI ON(BA.tpa_office_seq_id=OI.tpa_office_seq_id)
        LEFT OUTER JOIN tpa_ins_info E  ON (C.ins_seq_id = E.ins_seq_id)
        LEFT OUTER JOIN tpa_general_code F ON (A.check_status=F.general_type_id)
        LEFT OUTER JOIN tpa_general_code G ON (G.general_type_id = C.claim_type)
        LEFT OUTER JOIN tpa_general_code H ON (A.check_status = H.general_type_id)
        JOIN clm_authorization_details X ON(C.claim_seq_id=X.claim_seq_id)';
        --searching by  v_check_num value
      IF (v_check_num) IS NOT NULL THEN
        v_where := v_where || ' AND A.check_num = :v_check_num';
        i := i+1;
        bind_tab(i) := v_check_num;
      END IF;
      --searching by  v_float_acc_number value
      IF (v_float_acc_number) IS NOT NULL THEN
        v_where := v_where || ' AND D.float_account_number LIKE :v_float_acc_number';
        i := i+1;
        bind_tab(i) := UPPER (v_float_acc_number)||'%';
      END IF;
      --searching by  v_check_status value
      IF (v_check_status ) IS NOT NULL THEN
        v_where := v_where || ' AND A.check_status = :v_check_status ';
        i := i+1;
        bind_tab(i) := v_check_status;
      END IF;
      --searching by  v_claim_settlement_no value
      IF (v_claim_settlement_no) IS NOT NULL THEN
        v_where := v_where || ' AND C.claim_settlement_no LIKE :v_claim_settlement_no';
        i := i+1;
        bind_tab(i) := UPPER(v_claim_settlement_no)||'%';
      END IF;
      --searching by  v_claim_type value
      IF (v_claim_type ) IS NOT NULL THEN
        v_where := v_where || ' AND C.claim_type = :v_claim_type ';
        i := i+1;
        bind_tab(i) := v_claim_type;
      END IF;
      --searching by  v_ins_seq_id value
      IF (v_ins_seq_id) IS NOT NULL THEN
        --v_where := v_where || ' AND E.ins_seq_id = :v_ins_seq_id ';
        v_where := v_where || ' AND E.ins_head_office_seq_id = :v_ins_seq_id ';
        i := i+1;
        bind_tab(i) := v_ins_seq_id;
      END IF;
      --searching by  v_ins_comp_code_number value
      IF (v_ins_comp_code_number )IS NOT NULL THEN
        v_where := v_where || ' AND ins_comp_code_number LIKE :v_ins_comp_code_number';
        i := i+1;
        bind_tab(i) := UPPER(v_ins_comp_code_number)||'%';
      END IF;
      --searching by v_batch_number_value
      IF (v_batch_number) IS NOT NULL THEN
        v_where := v_where || ' AND A.batch_number LIKE :v_batch_number';
        i := i+1;
        bind_tab(i) := UPPER(v_batch_number)||'%';
      END IF;
      --searching by v_policy_number_value
      IF (v_policy_number) IS NOT NULL THEN
        v_where := v_where || ' AND X.policy_number LIKE :v_policy_number';
        i := i+1;
        bind_tab(i) := UPPER(v_policy_number)||'%';
      END IF;
      --searching by v_enrollment_id_value
      IF (v_enrollment_id) IS NOT NULL THEN
        v_where := v_where || ' AND X.tpa_enrollment_id LIKE :v_enrollment_id';
        i := i+1;
        bind_tab(i) := UPPER(v_enrollment_id)||'%';
      END IF;
      --searching by v_payee_method value
      IF (v_payee_method ) IS NOT NULL THEN
        v_where := v_where || ' AND C.payee_type = :v_payee_method ';
        i := i+1;
        bind_tab(i) := v_payee_method;
      END IF;
      IF (v_from_date ) IS NOT NULL THEN
        v_where := v_where || ' AND TRUNC(check_date) >= :v_from_date ';
        i := i+1;
        bind_tab(i) := v_from_date;
      END IF;
      IF (v_to_date )IS NOT NULL THEN
        v_where := v_where || ' AND  TRUNC(check_date)  <= :v_to_date ';
        i := i+1;
        bind_tab(i) := v_to_date;
      END IF;
      ------------ CR0218(Search by QatarID)---------------
      IF (v_qatar_id) IS NOT NULL THEN
        v_where := v_where || ' AND X.emirate_id = :v_qatar_id';
        i := i+1;
        bind_tab(i) := UPPER(v_qatar_id);
      END IF;
      ------------------------------------------------------
      v_where  := v_where ||' AND A.deleted_yn = ''N''';
      v_where   := ' WHERE '|| SUBSTR(v_where,5);
      v_sql_str := v_sql_str ||v_where;

      v_sql_str := 'SELECT * FROM
      (SELECT A.*,DENSE_RANK() OVER (ORDER BY '||v_sort_var||' '||v_sort_order||',ROWNUM)
      Q FROM (' ||v_sql_str|| ') A ) WHERE  Q>= :v_start_num  AND Q<= :v_end_num ';

      IF bind_tab.FIRST IS NOT NULL THEN
        CASE bind_tab.COUNT
           WHEN 1  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),v_start_num ,v_end_num ;
           WHEN 2  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2) ,v_start_num ,v_end_num ;
           WHEN 3  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2) ,bind_tab(3) ,v_start_num ,v_end_num ;
           WHEN 4  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4),v_start_num ,v_end_num ;
           WHEN 5  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),v_start_num ,v_end_num ;
           WHEN 6  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6),v_start_num ,v_end_num ;
           WHEN 7  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6),bind_tab(7),v_start_num ,v_end_num ;
           WHEN 8  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6),bind_tab(7),bind_tab(8),v_start_num ,v_end_num ;
           WHEN 9  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6),bind_tab(7),bind_tab(8),bind_tab(9) ,v_start_num ,v_end_num ;
           WHEN 10  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6),bind_tab(7),bind_tab(8),bind_tab(9) , bind_tab(10) ,v_start_num ,v_end_num ;
           WHEN 11  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6),bind_tab(7),bind_tab(8),bind_tab(9) , bind_tab(10) ,bind_tab(11) ,v_start_num ,v_end_num ;
           WHEN 12  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6),bind_tab(7),bind_tab(8),bind_tab(9) , bind_tab(10) ,bind_tab(11) ,bind_tab(12) ,v_start_num ,v_end_num ;
           WHEN 13  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6),bind_tab(7),bind_tab(8),bind_tab(9) , bind_tab(10) ,bind_tab(11) ,bind_tab(12) ,bind_tab(13) ,v_start_num ,v_end_num ;
           WHEN 14  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6),bind_tab(7),bind_tab(8),bind_tab(9) , bind_tab(10) ,bind_tab(11) ,bind_tab(12) ,bind_tab(13) ,bind_tab(14) ,v_start_num ,v_end_num ;
        END CASE;
      ELSE
        OPEN result_set FOR v_sql_str USING v_start_num , v_end_num ;
      END IF;
  END  select_chq_list;
--=======================================================================================
 -- this procedure is used to save only updated info into tpa_claims_check.
 -- modified by Ravi
 -- CR kocdup
 -- purpose for duplicate claims on 8nov2012
---==================================================================================
  PROCEDURE chq_details_save(
    v_claims_chq_seq_id      IN OUT  TPA_CLAIMS_CHECK.claims_chk_seq_id%TYPE,
    v_cheque_status          IN      TPA_CLAIMS_CHECK.check_status%TYPE,
    v_cleared_date           IN      TPA_CLAIMS_CHECK.cleared_date%TYPE,
    v_comments               IN      TPA_FLOAT_ACCOUNT.comments%TYPE,
    v_added_by               IN      NUMBER,
    v_rows_processed         OUT     INTEGER
  )
  IS
    P_status                   VARCHAR2(3);
    v_flag                     NUMBER(5);
    v_flagging                 NUMBER(5);
    p_clear_date               DATE;
    p_void_date                DATE;
    p_stale_date               DATE; --stale
    p_check_date               DATE; --stale
    v_reissue_check_amount     TPA_CLAIMS_CHECK.check_amount%TYPE := 0;
    v_float_seq_id             TPA_CLAIMS_PAYMENT.float_seq_id%TYPE;
    v_bank_acc_seq_id          TPA_BANK_ACCOUNTS.bank_balance%TYPE;
    V_CLAIM_SEQ_ID             TPA_CLAIMS_PAYMENT.CLAIM_SEQ_ID%TYPE;
    --koc1175
    v_payment_seq_id           tpa_payment_checks_details.payment_seq_id%type;
    v_debit_seq_id             tpa_debit_note.debit_seq_id%type;
    v_float_trn_seq_id         tpa_debit_note_transaction.float_trn_seq_id%type;
    v_appr_amount              TPA_CLAIMS_PAYMENT.APPROVED_AMOUNT%TYPE:=0;
    --koc1175

    CURSOR cml_chq_cur IS SELECT A.check_status,cleared_date,void_date,a.stale_date,a.check_date
           FROM tpa_claims_check A WHERE A.claims_chk_seq_id = v_claims_chq_seq_id;

    CURSOR clm_chq_pay_cur IS                                    -- GETTING CLARIFICATION INFORMATION
     SELECT A.check_amount,
     b.payment_seq_id  --koc1175
     FROM tpa_claims_check A JOIN tpa_payment_checks_details B ON (A.claims_chk_seq_id = B.claims_chk_seq_id)
     WHERE A.claims_chk_seq_id = v_claims_chq_seq_id;

    --chq_pay_cur                               clm_chq_pay_cur%ROWTYPE;
  BEGIN

  --get status of check by passing claims_chq_seq_id .

    OPEN cml_chq_cur;
    FETCH cml_chq_cur  INTO p_status , p_clear_date, p_void_date,p_stale_date,p_check_date;
    CLOSE cml_chq_cur;

    OPEN clm_chq_pay_cur;
    FETCH clm_chq_pay_cur  INTO v_reissue_check_amount,
    v_payment_seq_id; --koc1175
    CLOSE clm_chq_pay_cur;

    IF v_cleared_date < p_clear_date or v_cleared_date < p_void_date or v_cleared_date<p_stale_date or v_cleared_date<p_check_date or
       v_cleared_date>trunc(sysdate) THEN
       RAISE_APPLICATION_ERROR(-20857,'Enterd date should not less than cheque date or greater than current datae ');
   END IF; --KOCstale

    -- To get cheque date is greater than float account open date.
    SELECT COUNT(1) INTO v_flagging
      FROM  tpa_float_account A JOIN tpa_claims_payment  B  ON(A.float_seq_id = B.float_seq_id)
      JOIN tpa_payment_checks_details C ON(B.payment_seq_id = C.payment_seq_id)
      JOIN tpa_claims_check D ON (C.claims_chk_seq_id = D.claims_chk_seq_id)
      WHERE TO_DATE(v_cleared_date,'DD/MM/YYYY') >= TO_DATE(A.effective_date,'DD/MM/YYYY')
         AND A.float_status  NOT IN ('ASC','ASI') AND D.claims_chk_seq_id = v_claims_chq_seq_id ;

    --here issue_date is check_date by default it is

    IF (P_status IN ('CSI','CSS'))  THEN  -- check status issued
    -- Following conditions Added/changed by Prasanna Kumar to allow re-issue of checks if account is not active but another active account exists.
       IF ( v_cheque_status = 'CSR') AND (v_flagging = 0)THEN
          SELECT DISTINCT NVL(NFA.float_seq_id,0) INTO v_float_seq_id
            FROM tpa_claims_payment CP JOIN tpa_payment_checks_details CQD ON (CP.payment_seq_id = CQD.payment_seq_id)
                 JOIN tpa_float_account FA ON (CP.float_seq_id = FA.float_seq_id)
                 LEFT OUTER JOIN tpa_float_account NFA ON (FA.Ins_Seq_Id = NFA.Ins_Seq_Id AND
                                                NVL(FA.Prod_General_Type_Id,0) = NVL(NFA.Prod_General_Type_Id,0) AND
                                                NVL(FA.Group_Reg_Seq_Id,0) = NVL(NFA.Group_Reg_Seq_Id,0) AND
                                                nvl(NFA.expiration_date,sysdate) >= SYSDATE AND
                                                NFA.float_status = 'ASA')
              WHERE CQD.claims_chk_seq_id = v_claims_chq_seq_id ;
       END IF;

       IF (v_flagging = 0) AND NOT ( v_cheque_status = 'CSR' AND v_float_seq_id > 0) THEN
           RAISE_APPLICATION_ERROR(-20232,'Enterd date should be between Account Created  Date.Float status should be Active.');
       END IF;
       IF (P_status = 'CSI' AND v_cheque_status IN ('CSV','CSC')) OR ( v_cheque_status = 'CSR') THEN
         UPDATE tpa_claims_check  SET
             check_status = v_cheque_status,
             void_date    = v_cleared_date,
             comments     = v_comments,
             updated_by   = v_added_by,
             updated_date = SYSDATE,
             v_csr_flag   = 0  --kocdup
             WHERE claims_chk_seq_id = v_claims_chq_seq_id;

         UPDATE fin_app.tpa_payment_checks_details ty  
           SET v_csr_flag=0 ,payment_cheq_issue_seq = fin_app.payment_cheq_issue_seq_val.nextval
         where ty.claims_chk_seq_id= v_claims_chq_seq_id;  --for koc_dup

       ELSIF P_status = 'CSI' AND ( v_cheque_status = 'CSS')  THEN   --check status stale
          --check six months happened or not after issiung check.
          -- Changed from 6 months to 3 months
           SELECT  COUNT(1) INTO v_flag
            FROM tpa_claims_check B
            WHERE (trunc(v_cleared_date)-trunc(b.check_date)>=90)
            AND  B.claims_chk_seq_id = v_claims_chq_seq_id ;

           --if check given but it is not credit in bank account then flag is 1 AND update check date as stale date.
         IF (v_flag = 1) THEN
              --for stale only status is captured not date.
           UPDATE tpa_claims_check SET
                   check_status = v_cheque_status,
                   stale_date   = v_cleared_date, -- stale
                   comments     = v_comments,
                   updated_by   = v_added_by,
                   updated_date = SYSDATE,
                   v_csr_flag   = 0  --kocdup
                   WHERE claims_chk_seq_id = v_claims_chq_seq_id;

          UPDATE fin_app.tpa_payment_checks_details ty  SET v_csr_flag=0
                 where ty.claims_chk_seq_id= v_claims_chq_seq_id;  --for koc_dup

              --if three months is not happened the show error message.
         ELSIF (v_flag = 0) THEN
            RAISE_APPLICATION_ERROR(-20217,'check status cannot be staled still three months not completed.');
         END IF;
       END IF;
       IF ( v_cheque_status = 'CSR') THEN  --check status re-issued
           FOR get_payment_info IN ( SELECT B.payment_seq_id , A.check_amount
                                         FROM tpa_claims_check A JOIN tpa_payment_checks_details B ON (A.claims_chk_seq_id = B.claims_chk_seq_id)
                                        WHERE A.claims_chk_seq_id = v_claims_chq_seq_id )
           LOOP
              --change ststus of cliams to pending for second time payment with new check number.


            UPDATE tpa_claims_payment A1 SET
                A1.claim_payment_status = 'PENDING',
                A1.reissued_yn = 'Y',
                A1.Float_Seq_Id = NVL(v_float_seq_id, A1.Float_Seq_Id)
                WHERE A1.payment_seq_id = get_payment_info.payment_seq_id
                RETURNING float_seq_id,a1.approved_amount INTO v_float_seq_id,v_appr_amount;  --koc1175

             --kocdup

               UPDATE tpa_claims_check SET v_csr_flag=0
                WHERE claims_chk_seq_id = v_claims_chq_seq_id;
                UPDATE fin_app.tpa_payment_checks_details ty  SET v_csr_flag=0
                where ty.claims_chk_seq_id= v_claims_chq_seq_id;

             --kocdup

           END LOOP;
       END IF;
           --Added By Ramakrishna for Updating Balance only once for Individual/Consolidated Cheques
       IF P_status = 'CSI' AND v_cheque_status IN ('CSS','CSR','CSV') THEN
          IF v_cheque_status IN ('CSS', 'CSV') THEN

             SELECT A.float_seq_id,a.approved_amount INTO v_float_seq_id,v_appr_amount
               FROM tpa_claims_payment A JOIN tpa_payment_checks_details B ON (A.payment_seq_id = B.payment_seq_id)
                 WHERE b.claims_chk_seq_id = v_claims_chq_seq_id AND rownum = 1;
          END IF;

          UPDATE tpa_float_account SET
                 current_balance = NVL(current_balance,0) + NVL(v_appr_amount,0)
                 WHERE float_seq_id = v_float_seq_id
                 RETURNING bank_acc_seq_id INTO v_bank_acc_seq_id ;

          --get clim_amount of this check b'coz it is reissued update float balance with claim_amt
          UPDATE tpa_bank_accounts T1 SET
                 T1.bank_balance = (T1.bank_balance + NVL(v_appr_amount,0))
                 WHERE bank_acc_seq_id = v_bank_acc_seq_id;

--koc1175

        DELETE FROM TPA_CLM_TDS_DETAILS D   WHERE D.PAYMENT_SEQ_ID = v_payment_seq_id;

        SELECT  A.CLAIM_SEQ_ID INTO V_CLAIM_SEQ_ID FROM TPA_CLAIMS_PAYMENT A
               WHERE A.PAYMENT_SEQ_ID=v_payment_seq_id;

        DELETE FROM tpa_debit_note_claims_assoc B
        WHERE B.CLAIM_SEQ_ID=V_CLAIM_SEQ_ID returning b.debit_seq_id into v_debit_seq_id;

        DELETE FROM tpa_debit_claims_transaction C WHERE C.CLAIM_SEQ_ID=V_CLAIM_SEQ_ID ;


        update fin_app.tpa_debit_note u
        set u.debit_amount= (u.debit_amount - NVL(v_appr_amount,0))
        where u.debit_seq_id = v_debit_seq_id;

        update fin_app.tpa_debit_note_transaction g
        set g.deposited_debit_amount = (g.deposited_debit_amount -  NVL(v_appr_amount,0))
        where g.debit_seq_id = v_debit_seq_id
        returning g.float_trn_seq_id into v_float_trn_seq_id;

        update fin_app.tpa_float_transaction d
        set d.flt_trn_amount = (d.flt_trn_amount - NVL(v_appr_amount,0))
        where d.float_trn_seq_id = v_float_trn_seq_id;

--koc1175
       END IF;
        --check cannot be issued.
       IF (P_status = 'CSS') AND v_cheque_status != 'CSR' THEN
          RAISE_APPLICATION_ERROR(-20221,' staled check cannot be issued.');
       END IF;
    --only check can be reissued here reissue_date is void_date
    ELSIF (P_status = 'CSV') THEN
        UPDATE tpa_claims_check SET
            comments = v_comments
            WHERE claims_chk_seq_id = v_claims_chq_seq_id;

        IF (v_cheque_status = 'CSC') OR (v_cheque_status = 'CSR') OR (v_cheque_status = 'CSI') OR (v_cheque_status = 'CSS') THEN
           RAISE_APPLICATION_ERROR(-20219,' void  check cannot be  issued.');
        END IF;
    --dont allow to chane status display error
    ELSIF P_status IN ('CSC','CSR') THEN
      UPDATE tpa_claims_check SET
          comments = v_comments
          WHERE claims_chk_seq_id = v_claims_chq_seq_id;

      IF (v_cheque_status = 'CSV') OR (v_cheque_status = 'CSC') OR (v_cheque_status = 'CSI') OR (v_cheque_status = 'CSS') THEN
        RAISE_APPLICATION_ERROR(-20220,' cleared check cannot be  issued.');
      END IF;
    END IF;
    --number of rows inserted/updated
    v_rows_processed := SQL%ROWCOUNT;
    COMMIT;
  END chq_details_save;
 --=======================================================================================
--this procedure is used to display a record wrt claim settlement number from tpa_claims_check.
  PROCEDURE select_chq_detail(
    v_seq_id                IN OUT tpa_claims_check.claims_chk_seq_id%TYPE,
    v_payment_seq_id        IN     TPA_CLAIMS_PAYMENT.payment_seq_id%TYPE,--only in case of cheque detail info
    v_float_seq_id          IN     TPA_CLAIMS_PAYMENT.float_seq_id%TYPE,
    v_added_by              IN     NUMBER,
    result_set              OUT     SYS_REFCURSOR
  )
  IS

  BEGIN
  --this procedure is used to both claims and cheques detail info.
  --if  web board value is not there then cheque detail info.
    IF (v_float_seq_id ) IS NULL THEN
       OPEN result_set FOR
         SELECT
         --CASE WHEN C.Payee_Type='EFT' THEN 'EFT' ELSE to_char(A.check_num) END AS check_num,
          CASE WHEN C.Payee_Type='EFT' THEN 'EFT-'||to_char(A.check_num) 
               WHEN C.Payee_Type='PCA' THEN 'CHQ-'||to_char(A.check_num) 
               WHEN C.Payee_Type='PMM' THEN  to_char(A.check_num) 
            ELSE NULL END AS check_num,--ADDED FOR KOC1103
          A.claims_chk_seq_id,
          A.check_date,
          A.void_date,
          --A.in_favour_of,
          ttk_util_pkg.fn_decrypt(C.payee_name) AS in_favour_of,--modified for koc11ed
        --  A.check_amount,
          CASE WHEN C.Payee_Type='EFT' THEN (CASE WHEN C.CLAIM_PAYMENT_STATUS='PAID' THEN A.check_amount ELSE NULL END ) ELSE A.check_amount END AS check_amount,--ADDED FOR KOC1103
          D.float_account_number,
          C.claim_settlement_no,
          --C.claim_type AS claim_type,
          J.description AS claim_type,
          C.claim_aprv_date,
          C.approved_amount,
          X.tpa_enrollment_id AS tpa_enrollment_id,
          tem.mem_name AS mem_name,
          tep.policy_number AS policy_number,
          I.enrol_description,
          G.ins_comp_name,
          G.ins_comp_code_number ins_comp_code_number,
          H.group_id,
          H.group_name,
          C.address1,
          C.address2,
          C.address3,
          C.state AS state,
          C.city,
          C.pincode,
          C.country,
          C.email_id,
          C.phone1,
          C.phone2,
          C.home_phone,
          C.mob_num,
          C.fax_no,
          A.check_status,
          A.cleared_date,
          A.comments,
          decode(A.check_status,'CSS',A.stale_date,trunc(sysdate)) AS stale_date,
          c.payee_type as payment_method,  --koc1175
          c.transfer_currency,
          CASE WHEN c.transfer_currency='USD' THEN x.pay_amt_in_usd-nvl(c.discount_amount/3.64,0)
               WHEN c.transfer_currency='GBP' THEN x.pay_amt_in_gbp-nvl(c.discount_amount/x.conv_rate_in_gbp,0)
               WHEN c.transfer_currency='EUR' THEN x.pay_amt_in_euro-nvl(c.discount_amount/x.conv_rate_in_euro,0) END as transfered_amt
          FROM  tpa_claims_check A
          LEFT OUTER JOIN tpa_payment_checks_details B ON(A.claims_chk_seq_id = B.claims_chk_seq_id)
          LEFT OUTER JOIN tpa_claims_payment C ON(C.payment_seq_id = B.payment_seq_id)
          LEFT OUTER JOIN tpa_float_account D ON(D.float_seq_id = C.float_seq_id)
          JOIN clm_authorization_details X ON(C.claim_seq_id=X.claim_seq_id)
          JOIN tpa_enr_policy tep ON(x.policy_seq_id = tep.policy_seq_id)
          JOIN tpa_enr_policy_member tem ON(x.member_seq_id = tem.member_seq_id)
          LEFT OUTER JOIN tpa_ins_info G ON(C.ins_seq_id = G.ins_seq_id)
          LEFT OUTER JOIN tpa_group_registration H ON(C.group_reg_seq_id = H.group_reg_seq_id)
          JOIN tpa_enrolment_type_code I ON(C.enrol_type_id = I.enrol_type_id)
          JOIN tpa_general_code J ON(C.claim_type=J.general_type_id)
          WHERE A.claims_chk_seq_id = v_seq_id
          AND C.payment_seq_id=v_payment_seq_id;
    ELSE
       --if  web board value is  there then claims payments detail info.
       OPEN result_set FOR
          SELECT UNIQUE A.claim_settlement_no,
          J.Description AS claim_type,
          A.claim_aprv_date,
          A.approved_amount,
          A.float_seq_id,
          X.tpa_enrollment_id AS tpa_enrollment_id,
          tem.mem_name AS mem_name,
          tep.policy_number AS policy_number,
          I.enrol_description AS enrol_description,
          D.ins_comp_name,
          D.ins_comp_code_number ins_comp_code_number,
          E.group_id,
          E.group_name,
          ttk_util_pkg.fn_decrypt(A.payee_name) AS in_favour_of,  --modified for koc11ed
          G.comments,
          A.address1,
          A.Address2,
          A.Address3,
          A.State,
          A.City,
          A.Pincode,
          A.Country,
          A.Email_Id,
          A.Phone1,
          A.Phone2,
          A.Home_Phone,
          A.Mob_Num,
          A.Fax_No,
          --TO_DATE(TO_CHAR(G.check_date,'DD/MM/YYYY'),'DD/MM/YYYY') AS check_date
          G.check_date AS check_date,
          a.payee_type as payment_method,  --koc1175
          a.transfer_currency,
          CASE WHEN a.transfer_currency='USD' THEN x.pay_amt_in_usd-nvl(a.discount_amount/3.64,0)
               WHEN a.transfer_currency='GBP' THEN x.pay_amt_in_gbp-nvl(a.discount_amount/x.conv_rate_in_gbp,0)
               WHEN a.transfer_currency='EUR' THEN x.pay_amt_in_euro-nvl(a.discount_amount/x.conv_rate_in_euro,0) END as transfered_amt   --koc1175
          FROM tpa_claims_payment A
          JOIN clm_authorization_details X ON(A.claim_seq_id=X.claim_seq_id)
          JOIN tpa_enr_policy tep ON(x.policy_seq_id = tep.policy_seq_id)
          JOIN tpa_enr_policy_member tem ON(x.member_seq_id = tem.member_seq_id)
          LEFT OUTER JOIN tpa_ins_info D ON (A.ins_seq_id = D.ins_seq_id)
          LEFT OUTER JOIN tpa_group_registration E ON(A.group_reg_seq_id = E.group_reg_seq_id)
          LEFT OUTER JOIN tpa_payment_checks_details F ON (A.payment_seq_id = F.payment_seq_id)
          LEFT OUTER JOIN tpa_claims_check G ON (F.claims_chk_seq_id = G.claims_chk_seq_id)
          JOIN tpa_enrolment_type_code I ON(A.enrol_type_id = I.enrol_type_id)
          JOIN tpa_general_code J ON (A.claim_type=J.general_type_id)
          WHERE A.payment_seq_id = v_seq_id
          AND A.float_seq_id = v_float_seq_id ;
    END IF;
  END  select_chq_detail;
--===================================================================================

END cheque_info_pkg;

/

--------------------------------------------------------
--  DDL for Synonymn BATCH_UPLOAD_ERROR_LOG
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."BATCH_UPLOAD_ERROR_LOG" FOR "FIN_APP"."BATCH_UPLOAD_ERROR_LOG";

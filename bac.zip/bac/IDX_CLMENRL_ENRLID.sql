--------------------------------------------------------
--  DDL for Synonymn IDX_CLMENRL_ENRLID
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."IDX_CLMENRL_ENRLID" FOR "APP"."IDX_CLMENRL_ENRLID";

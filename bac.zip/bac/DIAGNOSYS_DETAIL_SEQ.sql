--------------------------------------------------------
--  DDL for Synonymn DIAGNOSYS_DETAIL_SEQ
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."DIAGNOSYS_DETAIL_SEQ" FOR "APP"."DIAGNOSYS_DETAIL_SEQ";

--------------------------------------------------------
--  DDL for Synonymn DHA_CLNSN_SPECIALTIES_MASTER
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."DHA_CLNSN_SPECIALTIES_MASTER" FOR "APP"."DHA_CLNSN_SPECIALTIES_MASTER";

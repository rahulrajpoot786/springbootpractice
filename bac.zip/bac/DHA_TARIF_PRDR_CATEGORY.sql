--------------------------------------------------------
--  DDL for Synonymn DHA_TARIF_PRDR_CATEGORY
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."DHA_TARIF_PRDR_CATEGORY" FOR "APP"."DHA_TARIF_PRDR_CATEGORY";

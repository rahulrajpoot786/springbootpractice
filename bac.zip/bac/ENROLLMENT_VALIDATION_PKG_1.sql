--------------------------------------------------------
--  DDL for Package ENROLLMENT_VALIDATION_PKG
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "VENUBABU"."ENROLLMENT_VALIDATION_PKG" is

  -- Author  : SREERAJ_SV
  -- Created : 9/12/2006 10:18:34 AM
  -- Purpose :
  FUNCTION exec_field_fun ( v_fn_name VARCHAR2 )  RETURN VARCHAR   ;
  /*PROCEDURE validate_enrollment( v_id IN NUMBER, v_flag IN CHAR, v_out OUT XMLTYPE );*/
-- ==========================================================================================
  FUNCTION getColumnValue(
    v_field_xml               IN XMLTYPE,
    v_parent_elem_name        IN VARCHAR2,
    v_elem_name IN VARCHAR2
  ) RETURN VARCHAR2;
-- ==========================================================================================
  FUNCTION getChildTextNode(
    element                   IN DBMS_XMLDOM.DOMELEMENT,
    v_name                    IN VARCHAR2
  ) RETURN VARCHAR2 DETERMINISTIC;

-- ==========================================================================================

 PROCEDURE process_xml( v_flag  VARCHAR2, v_val_rule_xml IN OUT XMLTYPE) ;
-- ==========================================================================================
 /*PROCEDURE process_member(
    v_enrollment_xml            IN  XMLTYPE,
    v_mem_xml                   IN  OUT XMLTYPE ,
    v_policy_group_seq_id       IN  TPA_ENR_POLICY_GROUP.policy_group_seq_id%TYPE,
    v_flag                      IN CHAR,
    v_out_xml                   OUT XMLTYPE
 );*/
-- ==========================================================================================
  PROCEDURE combine_xml(
    v_parent_xml            IN  OUT XMLTYPE,
    v_child_xml             IN  XMLTYPE
  );
-- ==========================================================================================
  PROCEDURE set_attributes( v_flag VARCHAR2, v_rule_xml  IN OUT xmltype);
-- ==========================================================================================
  PROCEDURE pr_auto_select(  v_merge_xml IN OUT XMLTYPE);
END enrollment_validation_pkg;

/

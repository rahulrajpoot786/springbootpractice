--------------------------------------------------------
--  DDL for Synonymn ADITIONAL_DEDUCTABLE_FACTORS
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."ADITIONAL_DEDUCTABLE_FACTORS" FOR "APP"."ADITIONAL_DEDUCTABLE_FACTORS";

--------------------------------------------------------
--  DDL for Synonymn FIN_0907_POLICY
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."FIN_0907_POLICY" FOR "INTX"."FIN_0907_POLICY";

--------------------------------------------------------
--  DDL for Synonymn DIAGNOSYS_DELETE_BKP
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."DIAGNOSYS_DELETE_BKP" FOR "APP"."DIAGNOSYS_DELETE_BKP";

--------------------------------------------------------
--  DDL for Synonymn CLM_DISCHARGE_VOUCHER_SEQ
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."CLM_DISCHARGE_VOUCHER_SEQ" FOR "APP"."CLM_DISCHARGE_VOUCHER_SEQ";

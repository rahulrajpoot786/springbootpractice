--------------------------------------------------------
--  DDL for Synonymn CLM_BILL_DTL_SEQ
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."CLM_BILL_DTL_SEQ" FOR "APP"."CLM_BILL_DTL_SEQ";

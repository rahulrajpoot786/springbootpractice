--------------------------------------------------------
--  DDL for Synonymn IDX_ENDS_PNUM_INS_PRO_CUST
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."IDX_ENDS_PNUM_INS_PRO_CUST" FOR "APP"."IDX_ENDS_PNUM_INS_PRO_CUST";

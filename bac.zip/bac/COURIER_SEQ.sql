--------------------------------------------------------
--  DDL for Synonymn COURIER_SEQ
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."COURIER_SEQ" FOR "APP"."COURIER_SEQ";

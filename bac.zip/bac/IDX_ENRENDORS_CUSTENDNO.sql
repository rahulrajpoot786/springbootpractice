--------------------------------------------------------
--  DDL for Synonymn IDX_ENRENDORS_CUSTENDNO
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."IDX_ENRENDORS_CUSTENDNO" FOR "APP"."IDX_ENRENDORS_CUSTENDNO";

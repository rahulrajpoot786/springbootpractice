--------------------------------------------------------
--  DDL for Synonymn GENESIS_IP_ADDRESS
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."GENESIS_IP_ADDRESS" FOR "APP"."GENESIS_IP_ADDRESS";

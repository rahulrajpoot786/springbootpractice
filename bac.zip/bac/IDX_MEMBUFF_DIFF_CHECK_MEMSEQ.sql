--------------------------------------------------------
--  DDL for Synonymn IDX_MEMBUFF_DIFF_CHECK_MEMSEQ
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."IDX_MEMBUFF_DIFF_CHECK_MEMSEQ" FOR "APP"."IDX_MEMBUFF_DIFF_CHECK_MEMSEQ";

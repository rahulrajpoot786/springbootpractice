--------------------------------------------------------
--  DDL for Procedure DELETE_FAILED_BATCH
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "VENUBABU"."DELETE_FAILED_BATCH" (p_batch_seq_id IN Clm_Batch_Upload_Details.Clm_Batch_Seq_Id%TYPE,
                                  p_deleted_by   IN NUMBER)
AS
   v_fin_cnt                  NUMBER;       

   CURSOR clm_cur IS
    Select c.claim_seq_id,
           c.clm_batch_seq_id,
           c.invoice_number,
           c.assign_user_seq_id,
           c.pat_auth_seq_id

    From Clm_Authorization_Details c
    Left Join Pat_Authorization_Details p On (p.pat_auth_seq_id = c.pat_auth_seq_id)
    Where c.clm_batch_seq_id = p_batch_seq_id;

    --Batch Details
    Cursor clm_batch_cur IS
      Select b.*
      From app.clm_batch_upload_details b
      Where b.clm_batch_seq_id = p_batch_seq_id;

    clm_batch_rec   clm_batch_cur%ROWTYPE;

    --Claim Details
    Cursor clm_details_cur IS
      Select c.claim_seq_id,
             c.clm_batch_seq_id,
             c.pat_auth_seq_id,
             c.claim_number,
             c.settlement_number,
             c.clm_received_date,
             c.source_type_id,
             c.date_of_hospitalization,
             c.date_of_discharge,
             c.claim_type,
             c.claim_sub_type,
             c.member_seq_id,
             c.tpa_enrollment_id,
             c.mem_name,
             c.mem_age,
             c.ins_seq_id,
             c.policy_seq_id,
             c.emirate_id,
             c.encounter_type_id,
             c.ava_sum_insured,
             c.currency_type,
             c.clm_status_type_id,
             c.added_by,
             c.added_date,
             c.invoice_number,
             c.requested_amount,
             c.clinician_id,
             c.system_of_medicine_type_id,
             c.network_yn,
             c.benifit_type,
             c.presenting_complaints,
             c.medical_opinion_remarks,
             c.pat_approved_amount,
             c.Lmp_Date,
             c.Conception_Type,
             c.first_incident_date,
             c.first_reported_date,
             c.AUTH_NUMBER,
             c.CONVERSION_RATE,
             c.req_amt_currency_type,
             c.SOURCE_FROM,
             c.event_no,
             c.tot_gross_amount,
             c.tot_discount_amount,
             c.tot_disc_gross_amount,
             c.tot_patient_share_amount,
             c.tot_net_amount,
             c.tot_allowed_amount,
             c.tot_approved_amount

      From app.clm_authorization_details c
      Where c.clm_batch_seq_id = p_batch_seq_id;

    --clm_details_rec   clm_details_cur%ROWTYPE;
    TYPE clm_typ IS TABLE OF clm_details_cur%ROWTYPE;
    clm_obj      clm_typ;
    --Claim Hospital Details
    Cursor clm_hosp_cur IS
      Select ch.clm_hosp_assoc_seq_id,
             ch.claim_seq_id,
             ch.hosp_seq_id,
             ch.hosp_name,
             ch.address_1,
             ch.city_type_id,
             ch.state_type_id,
             ch.pin_code,
             ch.off_phone_no_1,
             ch.office_fax_no,
             ch.remarks,
             ch.added_by,
             ch.added_date,
             ch.provider_id,
             ch.country_type_id,
             ch.clinician_name

      From app.clm_hospital_details ch
      Join clm_authorization_details c ON (ch.claim_seq_id = c.claim_seq_id)
      Where c.clm_batch_seq_id = p_batch_seq_id;

    clm_hosp_rec      clm_hosp_cur%ROWTYPE;

    --Claim Diagnosys Details
    Cursor diag_cur IS
      Select d.diag_seq_id,
             d.pat_auth_seq_id,
             d.claim_seq_id,
             d.icd_code_seq_id,
             d.diagnosys_code,
             d.primary_ailment_yn,
             d.remarks,
             d.added_by,
             d.added_date

      From app.diagnosys_details d
      Join app.clm_authorization_details c ON (c.claim_seq_id = d.claim_seq_id)
      Where c.clm_batch_seq_id = p_batch_seq_id;

    --diag_rec    diag_cur%ROWTYPE;
    TYPE diag_typ IS TABLE OF diag_cur%ROWTYPE;
    diag_obj      diag_typ;
    --Claim Shortfall Details
    Cursor shortfll_cur IS
      Select s.shortfall_seq_id,
             s.pat_gen_detail_seq_id,
             s.claim_seq_id,
             s.shortfall_id,
             s.srtfll_general_type_id,
             s.srtfll_sent_date,
             s.srtfll_reason_general_type_id,
             s.remarks,
             s.shortfall_questions,
             s.added_by,
             s.added_date,
             s.updated_date,
             s.updated_by,             
             s.reminder_count,
             s.closed_date,
             s.shortfall_raised_by,
             s.uploaded_file

      From app.shortfall_details s
      Join app.clm_authorization_details c ON (c.claim_seq_id = s.claim_seq_id)
      Where c.clm_batch_seq_id = p_batch_seq_id;

    --shortfll_rec    shortfll_cur%ROWTYPE; 
    TYPE shrtfll_typ IS TABLE OF shortfll_cur%ROWTYPE;
    shrtfll_obj      shrtfll_typ;
    --Claim Activity Details
    Cursor act_details_cur IS
      Select p.activity_dtl_seq_id,
             p.pat_auth_seq_id,
             p.claim_seq_id,
             p.activity_id,
             p.activity_seq_id,
             p.s_no,
             p.start_date,
             p.activity_type,
             p.code,
             p.unit_type,
             p.clinician_id,
             p.internal_code,
             p.quantity,
             p.allow_yn,
             p.gross_amount,
             p.discount_amount,
             p.disc_gross_amount,
             p.copay_perc,
             p.copay_amount,
             p.deduct_amount,
             p.patient_share_amount,
             p.net_amount,
             p.allowed_amount,
             p.approved_amount,
             p.currency_type,
             p.denial_code,
             p.remarks,
             p.added_by,
             p.added_date,
             p.updated_by,
             p.updated_date,
             p.service_type,
             p.service_code,
             p.benifit_deductible,
             p.unit_discount_amount,
             p.benifit_copay,
             p.override_yn,
             p.override_remarks,
             p.disallowed_amount,
             p.tooth_no,
             p.internal_desc

      From app.pat_activity_details p
      Join app.clm_authorization_details c ON (c.claim_seq_id = p.claim_seq_id)
      Where c.clm_batch_seq_id = p_batch_seq_id;

    --act_details_rec   act_details_cur%ROWTYPE;
    TYPE act_typ IS TABLE OF act_details_cur%ROWTYPE;
    act_obj      act_typ;


    --Claim Observation Details
    Cursor observation_cur IS
      Select o.*
      From app.pat_observation_details o
      Join app.pat_activity_details p ON (o.activity_dtl_seq_id = p.activity_dtl_seq_id)
      Join app.clm_authorization_details c ON (c.claim_seq_id = p.claim_seq_id)
      Where c.clm_batch_seq_id = p_batch_seq_id;

    TYPE obsrv_typ IS TABLE OF observation_cur%ROWTYPE;
    obsrv_obj      obsrv_typ;

  v_count NUMBER;

BEGIN
  Select Count(1) INTO v_count
  From Clm_Batch_Upload_Details cb
  Where cb.clm_batch_seq_id = p_batch_seq_id;

  IF v_count > 0 THEN
    Select count(1)  INTO v_fin_cnt
    From Clm_Authorization_Details c
    Join Tpa_Claims_Payment cp ON cp.claim_seq_id = c.claim_seq_id
    Where c.clm_batch_seq_id = p_batch_seq_id
    And c.clm_status_type_id = 'APR';

    IF v_fin_cnt > 0 THEN
      RAISE_APPLICATION_ERROR(-20020, 'Cannot Delete for Completed Claim .');
    END IF;


    OPEN clm_details_cur;
    FETCH clm_details_cur BULK COLLECT INTO clm_obj;
    CLOSE clm_details_cur;


    FORALL i IN clm_obj.FIRST.. clm_obj.LAST
       Update Clm_Authorization_Details c
       Set c.assign_user_seq_id = null
       Where c.claim_seq_id = clm_obj(i).claim_seq_id;

    FORALL i IN clm_obj.FIRST.. clm_obj.LAST
       --IF clm_obj(3).pat_auth_seq_id IS NOT NULL THEN
         Update Clm_Authorization_Details a
         set a.auth_number = null,
             a.pat_auth_seq_id = null
         where a.claim_seq_id = clm_obj(i).claim_seq_id;
       --END IF;
    FORALL i IN clm_obj.FIRST.. clm_obj.LAST   
         Update pat_authorization_details p
         set p.claim_seq_id = null
         where p.claim_seq_id = clm_obj(i).claim_seq_id;

    FORALL i IN clm_obj.FIRST.. clm_obj.LAST   
       Delete from Assign_Users u
       Where u.claim_seq_id = clm_obj(i).claim_seq_id;

    FORALL i IN clm_obj.FIRST.. clm_obj.LAST  
       Delete From Pat_Observation_Details od
       Where od.activity_dtl_seq_id in 
            (Select ad.activity_dtl_seq_id
             From pat_activity_details ad
             Where ad.claim_seq_id = clm_obj(i).claim_seq_id);

    FORALL i IN clm_obj.FIRST.. clm_obj.LAST        
       Delete From Pat_Activity_Details ad
       Where ad.claim_seq_id = clm_obj(i).claim_seq_id;

    FORALL i IN clm_obj.FIRST.. clm_obj.LAST    
       Delete From Diagnosys_Details d 
       Where d.claim_seq_id = clm_obj(i).claim_seq_id;

    FORALL i IN clm_obj.FIRST.. clm_obj.LAST   
       Delete from Shortfall_Details s
       Where s.claim_seq_id = clm_obj(i).claim_seq_id;

    FORALL i IN clm_obj.FIRST.. clm_obj.LAST  
       Delete From Clm_Hospital_Details h 
       Where h.claim_seq_id = clm_obj(i).claim_seq_id;

    FORALL i IN clm_obj.FIRST.. clm_obj.LAST   
       Delete Clm_Authorization_Details cl
       Where cl.clm_batch_seq_id = clm_obj(i).clm_batch_seq_id;

    FORALL i IN clm_obj.FIRST.. clm_obj.LAST   
       Delete Clm_Batch_Upload_Details b 
       Where b.clm_batch_seq_id = clm_obj(i).clm_batch_seq_id;

    commit;
  END IF;

END delete_failed_batch;

/

--------------------------------------------------------
--  DDL for Synonymn IDX_END_INSHEADSEQ
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."IDX_END_INSHEADSEQ" FOR "APP"."IDX_END_INSHEADSEQ";

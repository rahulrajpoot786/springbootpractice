--------------------------------------------------------
--  DDL for Synonymn AUTHORISATION
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."AUTHORISATION" FOR "APP"."AUTHORISATION";

--------------------------------------------------------
--  DDL for Synonymn CLM_HOSPITAL_ADDITIONAL_DTL
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."CLM_HOSPITAL_ADDITIONAL_DTL" FOR "APP"."CLM_HOSPITAL_ADDITIONAL_DTL";

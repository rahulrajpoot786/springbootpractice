--------------------------------------------------------
--  DDL for Synonymn CLM_AUDIT_DATA
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."CLM_AUDIT_DATA" FOR "APP"."CLM_AUDIT_DATA";

--------------------------------------------------------
--  DDL for Synonymn FLOAT_ACC_SEQ
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."FLOAT_ACC_SEQ" FOR "FIN_APP"."FLOAT_ACC_SEQ";

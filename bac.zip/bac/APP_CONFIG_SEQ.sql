--------------------------------------------------------
--  DDL for Synonymn APP_CONFIG_SEQ
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."APP_CONFIG_SEQ" FOR "APP"."APP_CONFIG_SEQ";

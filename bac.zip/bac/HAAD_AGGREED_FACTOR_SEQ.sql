--------------------------------------------------------
--  DDL for Synonymn HAAD_AGGREED_FACTOR_SEQ
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."HAAD_AGGREED_FACTOR_SEQ" FOR "APP"."HAAD_AGGREED_FACTOR_SEQ";

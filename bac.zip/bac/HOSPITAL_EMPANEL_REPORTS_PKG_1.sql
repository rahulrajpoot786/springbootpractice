--------------------------------------------------------
--  DDL for Package HOSPITAL_EMPANEL_REPORTS_PKG
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "VENUBABU"."HOSPITAL_EMPANEL_REPORTS_PKG" is

  -- Author  : MAMATHA_S
  -- Created : 5/30/2006 5:05:21 PM
  -- Purpose : reports for empanelment module
--===========================================================================
--1  report
  PROCEDURE  pr_hosp_doc_sent_sigmou_report (
    where_clause              IN VARCHAR2,
    cur                       OUT SYS_REFCURSOR
  );
---------------------------------------------------
--1 b) report
  PROCEDURE  pr_hosp_doc_rcvd_report (
    where_clause              IN VARCHAR2,
    cur                       OUT SYS_REFCURSOR
  );
---------------------------------------------------
--2 report
  PROCEDURE  pr_hosp_mou_rcvd_report (
    where_clause              IN VARCHAR2,
    cur                       OUT SYS_REFCURSOR
  );
---------------------------------------------------
--3 report
  PROCEDURE  pr_hosp_shortfall_report (
    where_clause              IN VARCHAR2,
    cur                       OUT SYS_REFCURSOR
  );
---------------------------------------------------
--4 report
  PROCEDURE  pr_hosp_DD_collect_report (
    where_clause              IN VARCHAR2,
    cur                       OUT SYS_REFCURSOR
  );
---------------------------------------------------
--5  report
  PROCEDURE  pr_hosp_empanel_dtl_report (
    where_clause              IN VARCHAR2,
    cur                       OUT SYS_REFCURSOR
  );
---------------------------------------------------
--8 report
  PROCEDURE  pr_hosp_log_report (
    where_clause              IN VARCHAR2,
    cur                       OUT SYS_REFCURSOR
  );
---------------------------------------------------
--9 report

  PROCEDURE  pr_hosp_emp_tobe_expire_report (
    where_clause              IN VARCHAR2,
    cur                       OUT SYS_REFCURSOR
  );
--===========================================================================
end hospital_empanel_reports_pkg;

/

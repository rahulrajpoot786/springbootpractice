--------------------------------------------------------
--  DDL for Synonymn CG_IND_IPF_BACKUP_DUMP
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."CG_IND_IPF_BACKUP_DUMP" FOR "APP"."CG_IND_IPF_BACKUP_DUMP";

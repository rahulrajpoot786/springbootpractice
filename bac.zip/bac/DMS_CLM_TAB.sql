--------------------------------------------------------
--  DDL for Synonymn DMS_CLM_TAB
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."DMS_CLM_TAB" FOR "APP"."DMS_CLM_TAB";

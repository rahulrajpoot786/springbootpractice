--------------------------------------------------------
--  DDL for Synonymn DHA_DSL_CODE_MASTER
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."DHA_DSL_CODE_MASTER" FOR "APP"."DHA_DSL_CODE_MASTER";

--------------------------------------------------------
--  DDL for Synonymn DATA_MASTERS
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."DATA_MASTERS" FOR "APP"."DATA_MASTERS";

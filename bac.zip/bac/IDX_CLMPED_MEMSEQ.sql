--------------------------------------------------------
--  DDL for Synonymn IDX_CLMPED_MEMSEQ
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."IDX_CLMPED_MEMSEQ" FOR "APP"."IDX_CLMPED_MEMSEQ";

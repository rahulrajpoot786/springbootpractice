--------------------------------------------------------
--  DDL for Synonymn AILMENT_CAPS
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."AILMENT_CAPS" FOR "APP"."AILMENT_CAPS";

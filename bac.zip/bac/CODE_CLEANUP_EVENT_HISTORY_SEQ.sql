--------------------------------------------------------
--  DDL for Synonymn CODE_CLEANUP_EVENT_HISTORY_SEQ
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."CODE_CLEANUP_EVENT_HISTORY_SEQ" FOR "APP"."CODE_CLEANUP_EVENT_HISTORY_SEQ";

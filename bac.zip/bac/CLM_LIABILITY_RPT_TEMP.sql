--------------------------------------------------------
--  DDL for Synonymn CLM_LIABILITY_RPT_TEMP
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."CLM_LIABILITY_RPT_TEMP" FOR "APP"."CLM_LIABILITY_RPT_TEMP";

--------------------------------------------------------
--  DDL for Synonymn DIAGNOSIS_ICD_CODE_MASTER
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."DIAGNOSIS_ICD_CODE_MASTER" FOR "APP"."DIAGNOSIS_ICD_CODE_MASTER";

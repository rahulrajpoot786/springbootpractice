--------------------------------------------------------
--  DDL for Procedure ADDNUMBERS
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "VENUBABU"."ADDNUMBERS" (number01 in number,
                                       number02 in number,
                                       number03 out number)
as
begin
number03:=number01+number02;
end;

/

--------------------------------------------------------
--  DDL for Package AUTHORIZATION_PKG
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "VENUBABU"."AUTHORIZATION_PKG" 
is
 -- OTP Global Variable
 v_otp number;
--====================================================================================
v_prod_policy_rule_seq_id   tpa_ins_prod_policy_rules.prod_policy_rule_seq_id%type;

PROCEDURE select_pat_auth_list (
    v_pre_auth_number                    IN  PAT_AUTHORIZATION_DETAILS.Pre_Auth_Number%type,
    v_claimant_name                      IN  tpa_enr_policy_member.mem_name%type,
    v_received_date                      IN  VARCHAR2,
    v_pat_status_general_type_id         IN  PAT_AUTHORIZATION_DETAILS.Pat_Status_Type_Id%type,
    v_policy_number                      IN  tpa_enr_policy.Policy_Number%TYPE,
    v_member_id                          IN  PAT_AUTHORIZATION_DETAILS.Tpa_Enrollment_Id%TYPE,
    v_sort_var                           IN  VARCHAR2,
    v_sort_order                         IN  VARCHAR2 ,
    v_start_num                          IN  NUMBER ,
    v_end_num                            IN  NUMBER ,
    v_added_by                           IN  NUMBER,
    result_set                           OUT SYS_REFCURSOR
  );
--====================================================================================
PROCEDURE select_pat_auth (
    v_pat_auth_seq_id                    IN  pat_authorization_details.pat_auth_seq_id%type,
    v_claim_seq_id                       IN  clm_authorization_details.claim_seq_id%type,
    result_set                           OUT SYS_REFCURSOR  );
--====================================================================================
PROCEDURE select_diagnosys_details (
    v_seq_id         IN  pat_authorization_details.pat_auth_seq_id%type,    
    v_mode           IN  CHAR, -- "PAT" OR "CLM"    
    result_set       OUT SYS_REFCURSOR  );
--====================================================================================
PROCEDURE select_diagnosys_details (
    v_seq_id              IN  diagnosys_details.pat_auth_seq_id%type,
    v_diag_seq_id         IN  diagnosys_details.diag_seq_id%type,    
    v_mode                IN  CHAR, -- "PAT" OR "CLM"    
    result_set            OUT SYS_REFCURSOR  );
--====================================================================================

PROCEDURE select_activity_details (
    v_seq_id         IN  pat_authorization_details.pat_auth_seq_id%type,    
    v_mode           IN  CHAR, -- "PAT" OR "CLM"    
    result_set       OUT SYS_REFCURSOR  );
--====================================================================================

PROCEDURE select_observation_details (
    v_activity_dtl_seq_id         IN  pat_observation_details.activity_dtl_seq_id%type,    
    result_set                OUT SYS_REFCURSOR  );

--====================================================================================

PROCEDURE select_observation_detail (
    v_observation_seq_id         IN  pat_observation_details.observation_seq_id%type,    
    result_set                OUT SYS_REFCURSOR  );

--====================================================================================

PROCEDURE select_activity_details (
    v_activity_dtl_seq_id         IN  pat_activity_details.activity_dtl_seq_id%type,    
    result_set                    OUT SYS_REFCURSOR  );    
--====================================================================================
PROCEDURE select_pat_auth_details (
    v_pat_auth_seq_id                           IN  pat_authorization_details.pat_auth_seq_id%type,
    v_auth_result_set                           OUT SYS_REFCURSOR ,
    v_diag_result_set                           OUT SYS_REFCURSOR ,
    v_activity_result_set                       OUT SYS_REFCURSOR ,
    v_observ_result_set                         OUT SYS_REFCURSOR ,
    v_shortfall_details                         OUT SYS_REFCURSOR ,
	v_pat_count                                 OUT SYS_REFCURSOR ,
    v_clm_count                                 OUT SYS_REFCURSOR 
     );
--====================================================================================
PROCEDURE save_pat_batch_details( v_pat_batch_seq_id               IN OUT pat_batch_upload_details.pat_batch_seq_id%TYPE,
                                  v_transaction_date               IN pat_batch_upload_details.transaction_date%TYPE,
                                  v_record_count                   IN pat_batch_upload_details.record_count%TYPE,
                                  v_disposition_flag               IN pat_batch_upload_details.disposition_flag%TYPE,
                                  v_sender_id                      IN pat_batch_upload_details.sender_id%type,
                                  v_receiver_id                    IN pat_batch_upload_details.receiver_id%type,
                                  v_added_by                       IN pat_batch_upload_details.Added_By%TYPE);
--====================================================================================


PROCEDURE save_pat_details(v_pat_auth_seq_id            in out pat_authorization_details.pat_auth_seq_id%type,
                           v_parent_pat_auth_seq_id     in pat_authorization_details.parent_pat_auth_seq_id%type,
                           v_pat_received_date          in pat_authorization_details.pat_received_date%type,
                           v_discharge_date             IN pat_authorization_details.discharge_date%type,
                           v_source_type_id             in pat_authorization_details.source_type_id%type,
                           v_hospitalization_date       in pat_authorization_details.hospitalization_date%type,
                           v_member_seq_id              in pat_authorization_details.member_seq_id%type,
                           v_tpa_enrollment_id          in pat_authorization_details.tpa_enrollment_id%type,
                           v_pre_auth_number            in out pat_authorization_details.pre_auth_number%type,
                           v_auth_number                in pat_authorization_details.auth_number%type,
                           v_mem_name                   in pat_authorization_details.mem_name%type,
                           v_mem_age                    in pat_authorization_details.mem_age%type,
                           v_ins_seq_id                 in pat_authorization_details.ins_seq_id%type,
                           v_hosp_seq_id                in pat_authorization_details.hosp_seq_id%type,
                           v_policy_seq_id              in pat_authorization_details.policy_seq_id%type,
                           v_emirate_id                 in pat_authorization_details.emirate_id%type,
                           v_encounter_type_id          in pat_authorization_details.encounter_type_id%type,
                           v_encounter_facility_id      in pat_authorization_details.encounter_facility_id%type,
                           v_encounter_start_type       IN pat_authorization_details.encounter_start_type%type,
                           v_encounter_end_type         IN pat_authorization_details.encounter_end_type%type,
                           v_remarks                    in pat_authorization_details.remarks%type,
                           v_added_by                   in number,
                           v_clinician_id               in pat_authorization_details.clinician_id%type,
                           v_system_of_medicine_type_id in pat_authorization_details.system_of_medicine_type_id%type,
                           v_accident_related_type_id   in pat_authorization_details.Accident_Related_Type_Id%TYPE,
                           v_priority_gen_type_id       in pat_authorization_details.priority_general_type_id%TYPE,
                           v_network_yn                 in pat_authorization_details.network_yn%type,
                           v_provider_name              in pat_non_network_details.provider_name%type,
                           v_provider_id                in pat_non_network_details.provider_id%type,
                           v_city_type_id               in pat_non_network_details.city_type_id%type,
                           v_state_type_id              in pat_non_network_details.state_type_id%type,
                           v_country_type_id            in pat_non_network_details.country_type_id%type,
                           v_provider_address           in pat_non_network_details.provider_address%type,
                           v_pincode                    in pat_non_network_details.pincode%type,
                           v_requested_amount           in pat_authorization_details.requested_amount%type,
                           v_benifit_type               in pat_authorization_details.benifit_type%type,
                           v_gravida                    in pat_authorization_details.gravida%type,
                           v_para                       in pat_authorization_details.para%type,
                           v_live                       in pat_authorization_details.live%type,
                           v_abortion                   in pat_authorization_details.abortion%type,
                           v_selection_type             in varchar2,--PAT,'ENH'--enhancement
                           v_currency_type              in pat_authorization_details.currency_type%type,
                           v_clinician_name             in pat_non_network_details.clinician_name%type,
                           v_ava_sum_insured            in pat_authorization_details.ava_sum_insured%type,
                          ---------------------------------------------------------------------------------
                           v_Oral_diagnosis            	in pat_authorization_details.Oral_diagnosis%type,
                           v_Oral_services              in pat_authorization_details.Oral_services%type,
                           v_Orala_Aproved_amount      	in pat_authorization_details.Orala_Aproved_amount%type,
                           v_Oral_diagnosis_revised       in pat_authorization_details.Oral_diagnosis_revised%type,
                           v_Oral_services_revised        in pat_authorization_details.Oral_services_revised%type,
                           v_Orala_Aproved_amount_revised in pat_authorization_details.Orala_Aproved_amount_revised%type,
                           v_Oral_system_Status			    in pat_authorization_details.Oral_system_Status%type,
                           -------------------------------------------------------------------------------
                           v_nat_conception          IN pat_authorization_details.conception_type%type,
                           v_lmp                     IN pat_authorization_details.lmp_date%type,
                           ------------------------------------------------------------------------------Currency Conversion
                           v_process_type                IN pat_authorization_details.process_type%TYPE,
                           v_req_amt_currency_type       IN pat_authorization_details.Req_Amt_Currency_Type%TYPE:=NULL, 
                           v_converted_amount            IN pat_authorization_details.Converted_Amount%TYPE:=NULL,  
                           v_converted_amt_currency_type IN pat_authorization_details.Converted_Amount_Currency_Type%TYPE:=NULL,
                           v_conversion_rate             IN pat_authorization_details.Conversion_Rate%TYPE:=NULL,
                           v_oth_tpa_ref_no              IN pat_authorization_details.oth_tpa_ref_no%TYPE:=NULL,
						               v_treatment_type          	 IN pat_authorization_details.treatment_type%TYPE:= null,
                           v_mode_of_delvry              IN pat_authorization_details.delvry_mod_type%TYPE :=NULL,
                           ------------------------------------------------------------------------------ partner preauth
				                   --- v_partner_name             in tpa_partner_info.partner_name%type, --NEWLY ADDED PARTNER
                           v_ptnr_seq_id                in tpa_partner_info.ptnr_seq_id%type,--NEWLY ADDED PARTNER
                           v_onl_pat_auth_seq_id     in pat_authorization_details.onl_pat_auth_seq_id%type, --newly added for partner
                           v_onl_pre_auth_refno      in pat_authorization_details.onl_pre_auth_refno%type,--newly added for partner
                          -------------------------------------------------------------------------------------------- 
						               v_event_no                in pat_authorization_details.event_no%TYPE,
                           v_MAT_COMPLCTON_YN        IN pat_authorization_details.MAT_COMPLCTON_YN%TYPE,
						               v_clinician_mail          in pat_authorization_details.clinician_mail%TYPE, -----NEWLY ADDED FOE ALAHALI ENHANCEMENT
                           v_clinician_spec          in pat_authorization_details.clinician_speciality%TYPE,
                           v_rows_processed             out number,                    
                           v_past_history               in pat_authorization_details.past_history%type:= null,
                           v_duration_above_illness              in pat_authorization_details.duration_above_illness%type:= null,
                           v_duration_above_illness_time         in pat_authorization_details.duration_above_illness_time%type:= null,
                           v_since_when                          in pat_authorization_details.since_when%type:= null,
                           v_since_when_time                     in pat_authorization_details.since_when_time%type:= null,
                           v_clinician_speciality    in pat_authorization_details.clinician_speciality%type:= null,
                           v_consultation_type       in pat_authorization_details.consultation_type%type:= null,
                           v_presenting_comp         IN pat_authorization_details.presenting_complaints%TYPE:= null,
                           v_provider_login          in varchar2:= null,
                           v_file_name               in varchar2:= null);
--===============================================================================
PROCEDURE save_diagnosys_details(
  v_diag_seq_id       IN OUT diagnosys_details.diag_seq_id%type,
  v_pat_auth_seq_id   IN diagnosys_details.pat_auth_seq_id%type,
  v_claim_seq_id      IN diagnosys_details.claim_seq_id%type,
  v_icd_code_seq_id   IN diagnosys_details.icd_code_seq_id%type,
  v_diagnosys_code    IN diagnosys_details.diagnosys_code%type,
  v_priamry_yn        IN diagnosys_details.Primary_Ailment_Yn%TYPE,
  v_presenting_comp   IN pat_authorization_details.presenting_complaints%TYPE,
  v_duration_ailment  IN pat_authorization_details.dur_ailment%type:=null,--ped
  v_duration_flag     IN pat_authorization_details.duration_flag%type:=null,--ped
  v_added_by          IN diagnosys_details.added_by%type ,
  v_rows_processed    OUT NUMBER);
--===============================================================================
PROCEDURE save_activity_details(
    v_activity_dtl_seq_id     IN OUT pat_activity_details.activity_dtl_seq_id%TYPE,
    v_pat_auth_seq_id         IN  pat_activity_details.pat_auth_seq_id%TYPE,
    v_claim_seq_id            IN  pat_activity_details.claim_seq_id%TYPE,
    v_activity_id             IN  pat_activity_details.activity_id%TYPE,
    v_Activity_Seq_Id         IN  pat_activity_details.Activity_Seq_Id%TYPE,
    v_start_date              IN  pat_activity_details.start_date%TYPE,
    v_activity_type           IN  pat_activity_details.activity_type%TYPE,
    v_code                    IN  pat_activity_details.code%TYPE,
    v_unit_type               IN  pat_activity_details.unit_type%TYPE,
    v_modifier                IN  pat_activity_details.modifier%TYPE,
    v_internal_code           IN  pat_activity_details.internal_code%TYPE,
    v_package_id              IN  pat_activity_details.package_id%TYPE,
    v_bundle_id               IN  pat_activity_details.bundle_id%TYPE,
    v_quantity                IN  pat_activity_details.quantity%TYPE,
    v_gross_amount            IN  pat_activity_details.gross_amount%TYPE,
    v_discount_amount         IN  pat_activity_details.discount_amount%TYPE,
    v_disc_gross_amount       IN  pat_activity_details.disc_gross_amount%TYPE,
    v_patient_share_amount    IN  pat_activity_details.patient_share_amount%TYPE,
    v_copay_amount            IN  pat_activity_details.copay_amount%TYPE,
    v_co_ins_amount           IN  pat_activity_details.co_ins_amount%TYPE,
    v_deduct_amount           IN  pat_activity_details.deduct_amount%TYPE,
    v_out_of_pocket_amount    IN  pat_activity_details.out_of_pocket_amount%TYPE,
    v_net_amount              IN  pat_activity_details.net_amount%TYPE,
    v_allowed_amount          IN  pat_activity_details.allowed_amount%TYPE,
    v_approved_amount         IN  pat_activity_details.approved_amount%TYPE,
    v_allow_yn                IN  pat_activity_details.allow_yn%TYPE,
    v_denial_code             IN  pat_activity_details.denial_code%TYPE,
    v_remarks                 IN  pat_activity_details.remarks%TYPE,
    v_added_by                IN  pat_activity_details.added_by%TYPE,
    v_approved_quantity       IN  pat_activity_details.approvd_quantity%type,
    v_unit_price              IN  pat_activity_details.unit_price%type,
    v_clinician_id            IN  pat_activity_details.clinician_id%type,
    v_override_yn             IN  pat_activity_details.override_yn%type,
    v_override_remarks_code   IN  pat_activity_details.override_Remarks_Code%TYPE,  -- added in Override remarks drop down cr
    v_approve_yn              IN  pat_activity_details.approve_yn%TYPE,
    v_duration_days           IN  pat_activity_details.posology_duration%TYPE,
    v_posology                IN  pat_activity_details.posology%TYPE,
    v_req_amount              IN  pat_activity_details.provider_net_amount%TYPE,
    v_denial_desc             IN  pat_activity_details.denial_desc%TYPE,
    v_service_type            IN  pat_activity_details.service_type%TYPE,
    v_service_code            IN  pat_activity_details.service_code%TYPE,
    v_ucr                     IN  pat_activity_details.ucr%TYPE DEFAULT NULL,
    v_denial_res_dis          IN  pat_activity_details.denial_res_dis%TYPE DEFAULT NULL,
    v_non_network_co_pay      in  pat_activity_details.non_network_co_pay%type, 
    v_converted_acitivty_amt  in  pat_activity_details.converted_acitivty_amt%type, 
    v_internal_desc           IN  pat_activity_details.internal_desc%TYPE,
    v_tooth_no                IN  pat_activity_details.tooth_no%TYPE,
    v_mem_service_code        IN  pat_activity_details.mem_service_Code%TYPE,
    v_mem_service_desc        IN  pat_activity_details.mem_service_desc%TYPE,
	  v_act_type                IN  VARCHAR2,
    v_override_remarks        IN  pat_activity_details.override_remarks%TYPE,
    v_other_remarks           IN  pat_activity_details.other_remarks%TYPE,       -- added in Override remarks drop down cr
    v_rows_processed          OUT NUMBER,
    v_delt_den_code           IN  pat_activity_details.delt_den_code%TYPE,
    v_delt_den_code_desc      IN  pat_activity_details.delt_den_code_desc%TYPE);
--===============================================================================
PROCEDURE save_observation_details(
    v_observation_seq_id	IN OUT pat_observation_details.observation_seq_id%TYPE,
    v_activity_dtl_seq_id	IN pat_observation_details.activity_dtl_seq_id%TYPE,
    v_mode                IN VARCHAR2,
    v_seq_id              IN pat_authorization_details.pat_auth_seq_id%TYPE,
    v_type	              IN pat_observation_details.observation_type_id%TYPE,
    v_code	              IN pat_observation_details.observation_code_id%TYPE,
    v_value	              IN pat_observation_details.value%TYPE,
    v_value_type_id	      IN pat_observation_details.obs_value_type_id%TYPE,
    v_added_by	          IN pat_observation_details.added_by%TYPE,
    v_remarks		          IN pat_observation_details.REMARKS%TYPE,
    v_rows_processed      OUT NUMBER );
--====================================================================================
FUNCTION generate_id_numbers (
    v_flag                           IN VARCHAR2,
    v_country_id                            IN VARCHAR2,
    v_state_id                            IN VARCHAR2,
    v_number                         IN VARCHAR2,  -- CAN BE PREAUTH NUMBER OR SHORTFALL_ID OR INVESTIGATION_ID
    v_claim_type                     IN VARCHAR2 := NULL
  ) RETURN VARCHAR2;
--====================================================================================
PROCEDURE calculate_authorization(v_pat_auth_seq_id            IN  pat_authorization_details.pat_auth_seq_id%type,
                                  v_hosp_seq_id                IN  pat_authorization_details.hosp_seq_id%TYPE,
                                  v_allowed_amount             OUT  pat_authorization_details.Tot_Allowed_Amount%TYPE,
                                  v_result_set                 OUT SYS_REFCURSOR,
                                  v_added_by                   IN  NUMBER);
--====================================================================================
PROCEDURE save_authorization(v_pat_auth_seq_id                 IN pat_authorization_details.Pat_Auth_Seq_Id%TYPE,
                             v_member_seq_id                   IN pat_authorization_details.member_seq_id%TYPE,
                             v_auth_number                     IN OUT pat_authorization_details.Auth_Number%TYPE,
                             v_admission_date                  IN pat_authorization_details.hospitalization_date%type,
                             v_allowed_amount                  IN pat_authorization_details.Tot_Allowed_Amount%TYPE,
                             v_source_type_id                  IN pat_authorization_details.source_type_id%TYPE,
                             v_pat_status_type_id              IN OUT pat_authorization_details.Pat_Status_Type_Id%TYPE,
                             v_medical_opinion_remarks         IN pat_authorization_details.medical_opinion_remarks%type,
                             v_added_by                        IN NUMBER,
                             p_denial_code                     IN Tpa_Denial_Codes.Denial_Code%TYPE,
                             v_over_remarks                    IN pat_authorization_details.override_remarks%TYPE,
                             v_internal_remarks                IN VARCHAR2,
                             v_rows_processed                  OUT NUMBER) ;              

--====================================================================================
FUNCTION get_prod_pol_seq_id(v_seq_id IN pat_general_details.pat_gen_detail_seq_id%type,
                             v_flag in varchar2 -- 'PAT','CLM'
                             ) RETURN NUMBER;
--====================================================================================
PROCEDURE create_preauth_xml (
    v_pre_auth_seq_id                       IN  pat_authorization_details.pat_auth_seq_id%type,
    v_preauth_history_doc                   OUT clob
   );
--====================================================================================


--====================================================================================
PROCEDURE save_enhanced_preauth(v_pat_auth_seq_id            IN OUT pat_authorization_details.pat_auth_seq_id%TYPE,
                                v_parent_pat_auth_seq_id     IN pat_authorization_details.pat_auth_seq_id%TYPE,
                                v_added_by                   IN NUMBER);

--====================================================================================


--====================================================================================
PROCEDURE select_member(v_tpa_enrollment_id      IN tpa_enr_policy_member.tpa_enrollment_id%type,
                        v_result_set             OUT SYS_REFCURSOR);
--====================================================================================
PROCEDURE select_provider(v_provider_id            IN tpa_hosp_info.hosp_licenc_numb%type,
                          v_result_set             OUT SYS_REFCURSOR);
--====================================================================================
PROCEDURE select_icd(v_icd_code             IN  tpa_icd_codes.icd_code%type,
                     v_seq_id               IN  pat_authorization_details.pat_auth_seq_id%type, 
                     v_mode                 IN VARCHAR2,--PAT,CLM
                     v_result_set           OUT SYS_REFCURSOR);
--====================================================================================
PROCEDURE select_activity_code(v_seq_id                    IN  pat_authorization_details.pat_auth_seq_id%TYPE,
                               v_mode                      IN  VARCHAR2,
                               v_activity_code             IN  OUT tpa_activity_master_details.activity_code%type,
                               v_flag                      IN  VARCHAR2,
                               v_activity_date             IN  pat_activity_details.start_date%TYPE,
                               v_act_result                OUT SYS_REFCURSOR,
                               v_tariff_result             OUT SYS_REFCURSOR);

--====================================================================================

--====================================================================================
PROCEDURE delete_diagnosys_details(v_seq_id             IN pat_authorization_details.pat_auth_seq_id%TYPE,
                                   v_diag_seq_id        IN diagnosys_details.diag_seq_id%type,
                                   v_mode               IN VARCHAR2,
                                   v_added_by           IN NUMBER,
                                   v_rows_processed     OUT NUMBER) ;
--====================================================================================
PROCEDURE check_pat_approved(v_pat_auth_seq_id      IN pat_authorization_details.pat_auth_seq_id%TYPE,                      
                             v_added_by             IN NUMBER);

--====================================================================================
PROCEDURE delete_preauth(v_pat_auth_seq_ids             IN VARCHAR2,
                         v_added_by                    IN NUMBER,
                         v_rows_processed              OUT NUMBER);
--====================================================================================
PROCEDURE delete_activity_details(v_seq_id                       IN pat_authorization_details.pat_auth_seq_id%TYPE,
                                  v_activity_dtl_seq_id          IN pat_activity_details.activity_dtl_seq_id%type,
                                  v_mode                         IN VARCHAR2,
                                  v_added_by                     IN NUMBER,
                                  v_rows_processed               OUT NUMBER) ;
--====================================================================================
PROCEDURE delete_observation_details(v_seq_ids                       IN VARCHAR2,
                                     v_seq_id                        IN pat_authorization_details.pat_auth_seq_id%type,
                                     v_mode                         IN VARCHAR2,
                                     v_rows_processed               OUT NUMBER) ;

--====================================================================================
PROCEDURE save_shortfall_details(v_shortfall_seq_id       IN OUT SHORTFALL_DETAILS.shortfall_seq_id%TYPE,
                                 v_pat_auth_seq_id        IN SHORTFALL_DETAILS.pat_gen_detail_seq_id%TYPE,
                                 v_claim_seq_id           IN SHORTFALL_DETAILS.claim_seq_id%TYPE,
                                 v_srtfll_general_type_id IN SHORTFALL_DETAILS.srtfll_general_type_id%TYPE,
                                 v_status_general_type_id IN SHORTFALL_DETAILS.srtfll_status_general_type_id%TYPE,
                                 v_reason_general_type_id IN SHORTFALL_DETAILS.srtfll_reason_general_type_id%TYPE,
                                 v_remarks                IN SHORTFALL_DETAILS.remarks%TYPE,
                                 v_srtfll_received_date   IN SHORTFALL_DETAILS.srtfll_received_date%TYPE,
                                 v_shortfall_questions    IN SHORTFALL_DETAILS.shortfall_questions%TYPE, -- new column
                                 v_correspondence_date    IN SHORTFALL_REMINDER_LOG.reminder_date%TYPE, -- new column
                                 v_new_correspondence_yn  IN OUT CHAR,
                                 v_selection_type         IN VARCHAR2, --SENT OR SAVE 
                                 v_template_type          IN VARCHAR2,
                                 v_added_by               IN SHORTFALL_DETAILS.added_by%TYPE,
                                 v_received_yn            IN VARCHAR2,
                                 --v_file_name              IN SHORTFALL_DETAILS.FILE_NAME%TYPE,
                                 v_rows_processed         IN OUT NUMBER);
--====================================================================================
PROCEDURE select_shortfall_details(v_shortfall_seq_id      IN SHORTFALL_DETAILS.shortfall_seq_id%TYPE,
                                   v_pat_auth_seq_id       IN PAT_AUTHORIZATION_DETAILS.PAT_AUTH_SEQ_ID%TYPE,
                                   v_claim_seq_id          IN SHORTFALL_DETAILS.Claim_Seq_Id%TYPE,
                                   v_added_by              IN NUMBER,
                                   result_set              OUT SYS_REFCURSOR);
--====================================================================================
PROCEDURE delete_shortfalls(v_seq_id           IN pat_authorization_details.pat_auth_seq_id%type,
                            v_shortfall_seq_id IN shortfall_details.shortfall_seq_id%type,
                            v_mode             IN VARCHAR2,--PAT,CLM
                            v_added_by         IN NUMBER,
                            v_rows_processed OUT NUMBER);
--==============================================================================
PROCEDURE select_shortfall_list (
    v_shortfall_number                   IN  shortfall_details.shortfall_id%type,
    v_pre_auth_number                    IN  pat_authorization_details.Pre_Auth_Number%type,
    v_status_general_type_id             IN  shortfall_details.srtfll_status_general_type_id%type,
    v_policy_number                      IN  tpa_enr_policy.Policy_Number%TYPE,
    v_member_id                          IN  pat_authorization_details.Tpa_Enrollment_Id%TYPE,
    v_mode                               IN  VARCHAR2,
    v_sort_var                           IN  VARCHAR2,
    v_sort_order                         IN  VARCHAR2 ,
    v_start_num                          IN  NUMBER ,
    v_end_num                            IN  NUMBER ,
    v_added_by                           IN  NUMBER,
    v_qatar_id                           IN  pat_authorization_details.emirate_id%type,
    result_set                           OUT SYS_REFCURSOR
  );
 ---======================================================================                                                                               
PROCEDURE select_activity_list (
    v_act_code                 IN OUT tpa_activity_master_details.activity_code%TYPE,
    v_description              IN OUT tpa_activity_master_details.activity_description%TYPE,
    V_search_flag              IN VARCHAR2,
    v_mode                     IN VARCHAR2,---PAT,CLM
    v_seq_id                   IN pat_authorization_details.pat_auth_seq_iD%TYPE,
    v_sort_var                 IN OUT VARCHAR2 ,
    v_sort_order               IN OUT VARCHAR2,
    v_start_num                IN OUT NUMBER  ,
    v_end_num                  IN OUT NUMBER  ,
    v_added_by                 IN  NUMBER,
    v_internal_code            IN VARCHAR2,
    v_result_set               OUT SYS_REFCURSOR
  );
------===============================================
PROCEDURE select_icd_list (
    v_icd_code                 IN OUT tpa_icd10_master_details.icd_code%TYPE,
    v_description              IN OUT tpa_icd10_master_details.long_desc%TYPE,
    v_sort_var                 IN OUT VARCHAR2 ,
    v_sort_order               IN OUT VARCHAR2,
    v_start_num                IN OUT NUMBER  ,
    v_end_num                  IN OUT NUMBER  ,
    v_added_by                 IN  NUMBER,
    v_result_set               OUT SYS_REFCURSOR
  );
 --==========================================================================
   PROCEDURE select_enhance_pat_list (
    v_pre_auth_number                    IN  PAT_AUTHORIZATION_DETAILS.Pre_Auth_Number%type,
    v_claimant_name                      IN  tpa_enr_policy_member.mem_name%type,
    v_received_date                      IN  VARCHAR2,
    v_pat_status_general_type_id         IN  PAT_AUTHORIZATION_DETAILS.Pat_Status_Type_Id%type,
    v_policy_number                      IN  tpa_enr_policy.Policy_Number%TYPE,
    v_member_id                          IN  PAT_AUTHORIZATION_DETAILS.Tpa_Enrollment_Id%TYPE,
    v_assign_user_id                     IN  VARCHAR2,
    v_other                              IN  VARCHAR2,
    v_sort_var                           IN  VARCHAR2,
    v_sort_order                         IN  VARCHAR2 ,
    v_start_num                          IN  NUMBER ,
    v_end_num                            IN  NUMBER ,
    v_added_by                           IN  NUMBER,
    v_qatar_id                           IN  pat_authorization_details.emirate_id%type,
    result_set                           OUT SYS_REFCURSOR
  );
 --=================================================================
  PROCEDURE select_provider_list (
    v_provider_id              IN OUT tpa_hosp_info.hosp_licenc_numb%TYPE,
    v_hosp_name                IN OUT tpa_hosp_info.hosp_name%TYPE,
    v_empanel_number           IN OUT tpa_hosp_info.empanel_number%TYPE,
    v_sort_var                 IN OUT VARCHAR2 ,
    v_sort_order               IN OUT VARCHAR2,
    v_start_num                IN OUT NUMBER  ,
    v_end_num                  IN OUT NUMBER  ,
    v_added_by                 IN  NUMBER,
    v_result_set               OUT SYS_REFCURSOR
  );
 --===============================================================
   PROCEDURE select_clinician_list (
    v_clinician_id             IN OUT tpa_hosp_professionals.professional_id%TYPE,
    v_clinician_name           IN OUT tpa_hosp_professionals.contact_name%TYPE,
    v_provider_id              IN OUT tpa_hosp_info.hosp_licenc_numb%TYPE,
    v_hosp_name                IN OUT tpa_hosp_info.hosp_name%TYPE,
    v_sort_var                 IN OUT VARCHAR2 ,
    v_sort_order               IN OUT VARCHAR2,
    v_start_num                IN OUT NUMBER  ,
    v_end_num                  IN OUT NUMBER  ,
    v_added_by                 IN  NUMBER,
    v_result_set               OUT SYS_REFCURSOR
  );
--==========================================================================
 procedure select_encounter_types(v_benefit_type in Tpa_Encounter_Type_Codes.Benefit_Gen_Type_Id%type,
                                  v_result_set   out sys_refcursor);
---============================================================================
PROCEDURE check_activity_limits (v_seq_id                 IN pat_authorization_details.pat_auth_seq_id%TYPE,
                                 v_mode                   IN VARCHAR2,
                                 v_allowed_amt            IN NUMBER,
                                 v_added_by               IN NUMBER,
                                 v_remarks                IN VARCHAR2,
                                 v_final_allowed_amount   OUT NUMBER);
--============================================================================
PROCEDURE select_pat_clm_history(v_member_seq_id IN tpa_enr_policy_member.member_seq_id%type,
                                  v_mode          IN varchar2,
                                  v_result_set    OUT SYS_REFCURSOR);
--====================================================================================
PROCEDURE pat_ins_intimate (v_pat_auth_seq_id               IN pat_authorization_details.pat_auth_seq_id%TYPE,
                            v_pat_status_type_id            IN pat_authorization_details.pat_status_type_id%TYPE,
                            v_max_app_amount                IN pat_authorization_details.tot_approved_amount%TYPE,
                            v_flag                          IN varchar2,
                            v_added_by                      IN NUMBER);
--===============================================================================
PROCEDURE select_ddc_price(v_activity_code             IN  tpa_activity_master_details.activity_code%type,
                           v_activity_date             IN  pat_activity_details.start_date%TYPE,
                           v_unit_type                 IN varchar2,--PCKG,LOSE
                           v_hosp_seq_id               IN tpa_hosp_info.hosp_seq_id%TYPE,
                           v_internal_code             IN tpa_hosp_tariff_details.internal_code%TYPE,
                           v_ddc_price                 OUT varchar2,
                           v_ddc_discount              OUT  varchar2);
--------==============================================================================
 PROCEDURE sent_attachment_proc (v_shortfall_seq_id   IN  shortfall_details.shortfall_seq_id%type,
                                  v_added_by           IN  NUMBER,
                                  v_srtfll_type        IN CHAR);
--------==============================================================================
PROCEDURE select_member_list (
		v_tpa_enrollment_id        IN    tpa_enr_policy_member.tpa_enrollment_id%type,
		v_sort_var                 IN    VARCHAR2 ,
		v_sort_order               IN OUT  VARCHAR2,
		v_start_num                IN OUT  NUMBER  ,
		v_end_num                  IN OUT  NUMBER  ,
		v_added_by                 IN  NUMBER,
		v_result_set               OUT SYS_REFCURSOR
	  );
                                  
                                  
  --------==============================================================================                                
                                
 --=================================================================      
FUNCTION get_nat_concp_valid_msg(v_member_seq_id       IN NUMBER,
                                 v_type                IN VARCHAR2,
                                 v_nat_conception      IN VARCHAR2)
 RETURN VARCHAR2;
 --====================================================================
  PROCEDURE override_preauth (
    v_pat_auth_seq_id               IN pat_authorization_details.pat_auth_seq_id%TYPE,
    v_added_by                      IN NUMBER,
    v_override_remarks              IN pat_authorization_details.override_remarks%TYPE,
    v_rows_processed                OUT NUMBER
  );
 
--======================================================================================
PROCEDURE SAVE_ORTHODONTIC_DETAILS(P_ORTHO_SEQ_ID       IN OUT ORTHODONTIC_DETAILS_TAB.ORTHO_SEQ_ID%TYPE,
                                   P_SOURCE_SEQ_ID      IN ORTHODONTIC_DETAILS_TAB.SOURCE_SEQ_ID%TYPE,
                                   P_SOURCE_FROM        IN ORTHODONTIC_DETAILS_TAB.SOURCE_FROM%TYPE,
                                   P_DENTO_CLASS_I      IN ORTHODONTIC_DETAILS_TAB.DENTO_CLASS_I%TYPE,
                                   P_DENTO_CLASS_II     IN ORTHODONTIC_DETAILS_TAB.DENTO_CLASS_II%TYPE,
                                   P_DENTO_CLASS_II_TEXT IN ORTHODONTIC_DETAILS_TAB.DENTO_CLASS_II_TEXT%TYPE,
                                   P_DENTO_CLASS_III    IN ORTHODONTIC_DETAILS_TAB.DENTO_CLASS_III%TYPE,
                                   P_SKELE_CLASS_I      IN ORTHODONTIC_DETAILS_TAB.SKELE_CLASS_I%TYPE,
                                   P_SKELE_CLASS_II     IN ORTHODONTIC_DETAILS_TAB.SKELE_CLASS_II%TYPE,
                                   P_SKELE_CLASS_III    IN ORTHODONTIC_DETAILS_TAB.SKELE_CLASS_III%TYPE,
                                   P_OVERJET_MM         IN ORTHODONTIC_DETAILS_TAB.OVERJET_MM%TYPE,
                                   P_REV_OVERJET_MM     IN ORTHODONTIC_DETAILS_TAB.REV_OVERJET_MM%TYPE,
                                   P_REV_OVERJET_YN     IN ORTHODONTIC_DETAILS_TAB.REV_OVERJET_YN%TYPE,
                                   P_CROSSBITE_ANT      IN ORTHODONTIC_DETAILS_TAB.CROSSBITE_ANT%TYPE,
                                   P_CROSSBITE_POST     IN ORTHODONTIC_DETAILS_TAB.CROSSBITE_POST%TYPE,
                                   P_CROSSBITE_BETW     IN ORTHODONTIC_DETAILS_TAB.CROSSBITE_BETW%TYPE,
                                   P_OPENBIT_ANT        IN ORTHODONTIC_DETAILS_TAB.OPENBIT_ANT%TYPE,
                                   P_OPENBIT_POST       IN ORTHODONTIC_DETAILS_TAB.OPENBIT_POST%TYPE,
                                   P_OPENBIT_LATE       IN ORTHODONTIC_DETAILS_TAB.OPENBIT_LATE%TYPE,
                                   P_CONT_POINT_DISP    IN ORTHODONTIC_DETAILS_TAB.CONT_POINT_DISP%TYPE,
                                   P_OVERBIT            IN ORTHODONTIC_DETAILS_TAB.OVERBIT_DEEP%TYPE,
                                   P_OVERBIT_PATA       IN ORTHODONTIC_DETAILS_TAB.OVERBIT_PATA%TYPE,
                                   P_OVERBIT_GING       IN ORTHODONTIC_DETAILS_TAB.OVERBIT_GING%TYPE,
                                   P_HYPO_QUAD1         IN ORTHODONTIC_DETAILS_TAB.HYPO_QUAD1%TYPE,
                                   P_HYPO_QUAD2         IN ORTHODONTIC_DETAILS_TAB.HYPO_QUAD2%TYPE,
                                   P_HYPO_QUAD3         IN ORTHODONTIC_DETAILS_TAB.HYPO_QUAD3%TYPE,
                                   P_HYPO_QUAD4         IN ORTHODONTIC_DETAILS_TAB.HYPO_QUAD4%TYPE,
                                   P_OTHERS_IMPEDED     IN ORTHODONTIC_DETAILS_TAB.OTHERS_IMPEDED%TYPE,
                                   P_OTHERS_IMPACT      IN ORTHODONTIC_DETAILS_TAB.OTHERS_IMPACT%TYPE,
                                   P_OTHERS_SUBMERG     IN ORTHODONTIC_DETAILS_TAB.OTHERS_SUBMERG%TYPE,
                                   P_OTHERS_SUPERNUM    IN ORTHODONTIC_DETAILS_TAB.OTHERS_SUPERNUM%TYPE,
                                   P_OTHERS_RETAINE     IN ORTHODONTIC_DETAILS_TAB.OTHERS_RETAINE%TYPE,
                                   P_OTHERS_ECTOPIC     IN ORTHODONTIC_DETAILS_TAB.OTHERS_ECTOPIC%TYPE,
                                   P_OTHERS_CRANIO      IN ORTHODONTIC_DETAILS_TAB.OTHERS_CRANIO%TYPE,
                                   P_AC_MARKS           IN  ORTHODONTIC_DETAILS_TAB.AC_MARKS%TYPE,
                                   P_CROSSBITE_ANT_MM	  IN ORTHODONTIC_DETAILS_TAB.CROSSBITE_ANT_MM%TYPE,
								                   P_CROSSBITE_PRST_MM	IN ORTHODONTIC_DETAILS_TAB.CROSSBITE_PRST_MM%TYPE,
								                   P_CROSSBITE_BETW_MM	IN ORTHODONTIC_DETAILS_TAB.CROSSBITE_BETW_MM%TYPE,
								                   P_CONT_POINT_DISP_MM	IN ORTHODONTIC_DETAILS_TAB.CONT_POINT_DISP_MM%TYPE,
                                   P_DENTO_CLASS_III_TEXT IN ORTHODONTIC_DETAILS_TAB.DENTO_CLASS_III_TEXT%TYPE,
                                   P_IOTN               OUT ORTHODONTIC_DETAILS_TAB.IOTN_REMARK%TYPE
                                 );
--================================================================================================================================
PROCEDURE check_ortho_cond (p_seq_id IN NUMBER,
                            p_flag   IN VARCHAR2
                           );
--============================================================================================================
 
 --===============================================================================================
PROCEDURE save_assign_users(
    v_assign_users_seq_id                IN  OUT ASSIGN_USERS.assign_users_seq_id%TYPE,
    v_claim_seq_id                       IN VARCHAR2,
    v_pat_gen_detail_seq_id              IN VARCHAR2,
    v_tpa_office_seq_id                  IN ASSIGN_USERS.tpa_office_seq_id%TYPE,
    v_assigned_to_user                   IN ASSIGN_USERS.assigned_to_user%TYPE,
    v_pat_status_general_type_id         IN ASSIGN_USERS.pat_status_general_type_id%TYPE,
    v_remarks                            IN ASSIGN_USERS.Remarks%TYPE,
    v_call_type                          IN  VARCHAR2,
    v_super_user_yn                      IN  CHAR , -- 'Y'/'N'
    v_added_by                           IN  NUMBER,
    v_mode                               IN  VARCHAR2,
    v_rows_processed                     IN  OUT NUMBER
  );
--===============================================================================================
  PROCEDURE reassign_user(
    v_pat_gen_detail_seq_id                IN VARCHAR2,
    v_claim_seq_id                         IN VARCHAR2,
    v_assigned_to_user                     IN ASSIGN_USERS.assigned_to_user%TYPE,
    v_added_by                             IN NUMBER,
    v_flag                                 IN VARCHAR2,
	 v_assign_users_seq_id                OUT ASSIGN_USERS.assign_users_seq_id%TYPE,
   v_remarks                              IN ASSIGN_USERS.Remarks%TYPE DEFAULT NULL
  );
--===============================================================================================
    PROCEDURE select_assign_to(
    v_assign_users_seq_id         IN ASSIGN_USERS.assign_users_seq_id%TYPE,
    v_added_by                    IN NUMBER,
    v_mode                        IN VARCHAR2,
    result_set                    OUT SYS_REFCURSOR
  );
--===============================================================================================
PROCEDURE manual_assign_preauth (
         v_tpa_office_seq_id                    IN TPA_USER_CONTACTS.tpa_office_seq_id%TYPE,
         v_result_set                           OUT SYS_REFCURSOR 
		 );
--==========================================================================
procedure select_provider_copay (v_pre_auth IN NUMBER,
                                v_mode      IN VARCHAR2,
                                v_res_set   OUT SYS_REFCURSOR
					  );
--===============================================================================================================
PROCEDURE check_approval_limit (
    v_assigned_to_user                 IN assign_users.assigned_to_user%TYPE,
    v_approval_amount                  IN NUMBER,
    v_flag                             IN CHAR
  );
--================================================================================================================
---******DISPLAY OF PRE_AUTH AND CLAIM HISTORY IN PRE_AUTH AND CLAIM MODULE

PROCEDURE select_pat_clm_benefit_history (
                                          v_member_seq_id IN tpa_enr_policy_member.member_seq_id%type,
                                          v_mode          IN varchar2,
                                          v_alkood_id     IN tpa_enr_policy_member.tpa_enrollment_id%type,
                                          v_policy_seq_id IN tpa_enr_policy.policy_seq_id%type,
                                          v_benefit_type  IN varchar2,
                                          v_sort_var      IN VARCHAR2,
                                          v_sor_order     IN VARCHAR2,
                                          v_result_set    OUT SYS_REFCURSOR,
										                      v_tot_apr_amt   OUT SYS_REFCURSOR ------- newly added for sum of total_approved_amount
                                         );
--===============================================================================================================										 
------------*******DISPLAY PRE_AUTH AND CLAIM COUNT IN CLAIM GENERAL SCREEN******--------------

procedure get_pat_clm_count(
           v_member_seq_id        IN    tpa_enr_policy_member.member_seq_id%type,
           v_pat_clm_count            OUT SYS_REFCURSOR 
             );
-----------------------------------------

PROCEDURE upld_clm_pat_docs(p_docs_seq_id       IN pat_clm_docs_tab.docs_seq_id%TYPE,
                            p_pat_clm_seq_id    IN pat_clm_docs_tab.pat_clm_seq_id%TYPE,
                            p_source_id         IN pat_clm_docs_tab.source_id%TYPE,
                            p_docs_desc         IN pat_clm_docs_tab.file_desc%TYPE,
                            p_file_path         IN pat_clm_docs_tab.file_path%TYPE,
                            p_file_name         IN pat_clm_docs_tab.file_name%TYPE,
                            p_added_by          IN pat_clm_docs_tab.added_by%TYPE,
                            p_image_file        IN pat_clm_docs_tab.image_file%TYPE,
                            --p_added_date        IN pat_clm_docs_tab.added_date%TYPE := null,
                            --p_updated_by        IN pat_clm_docs_tab.updated_by%TYPE := null,
                            --p_updated_date      IN pat_clm_docs_tab.updated_date%TYPE := null,
                            p_ref_seq_id        IN pat_clm_docs_tab.reference_seq_id%TYPE,
                            p_flag              OUT NUMBER
                           );
--==========================================================================
PROCEDURE delete_upld_file_details(p_docs_seq_id       IN VARCHAR2,
                                   p_rowcount          OUT NUMBER
                                  );
--==========================================================================
PROCEDURE check_overal_limit(v_seq_id         IN NUMBER,
                             v_flag           IN VARCHAR2,
                             v_prod_seq_id    IN NUMBER);
--==========================================================================
PROCEDURE check_pat_limit(p_clm_seq_id IN NUMBER,
                          V_HOSP_NAME  IN VARCHAR2);
--==========================================================================
PROCEDURE Provider_Benifit_eligibility (v_seq_id             IN    NUMBER,
                                        v_mode               IN    VARCHAR2,
                                        v_benifit_type       IN    VARCHAR2,
                                        v_hosp_seq_id        IN    NUMBER,
                                        v_policy_seq_id      IN    NUMBER);
--================================================================================
PROCEDURE Act_Detls_for_override_case (v_seq_id   IN 	  NUMBER,
                                       v_mode     IN    VARCHAR2,
                                       v_act_code IN    VARCHAR2,
                                       v_int_code IN    VARCHAR2,
                                       v_st_date  IN    VARCHAR2,
                                       v_result   OUT   SYS_REFCURSOR );
--===============================================================================
PROCEDURE Check_Resub_Activity_Limits (v_seq_id      IN    NUMBER,
                                      v_benefit_type IN    VARCHAR2,
                                      v_added_by     IN    NUMBER);
--===========================================================================
PROCEDURE select_docs_list(p_seq_id  IN NUMBER,
                           p_flag    IN VARCHAR2,
                           p_result  OUT SYS_REFCURSOR
                          );
--==========================================================================
PROCEDURE Set_Member_Sum_insured (v_mode	 IN	VARCHAR2,
                                  v_seq_id IN NUMBER);
--==========================================================================
PROCEDURE Get_Denial_category ( v_act_seq_id  IN NUMBER,
                                v_result_set  OUT SYS_REFCURSOR);
 --==========================================================
 PROCEDURE save_pat_clm_logs( p_flag             IN   VARCHAR2
                             ,p_seq_id           IN   NUMBER
                             ,p_log_type_id      IN   VARCHAR2
                             ,p_logs             IN   VARCHAR2
                             ,p_added_by         IN   NUMBER
                             ,p_system_gen_yn    IN   VARCHAR2
                            ); 
 --=========================================================
 PROCEDURE select_alert( p_flag        IN VARCHAR2  --P/C
                        ,p_seq_id      IN NUMBER
                        ,p_log_type    IN VARCHAR2
                        ,p_start_date  IN VARCHAR2
                        ,p_end_date    IN VARCHAR2
                        ,result_set    OUT SYS_REFCURSOR 
                       );
 --================================================
 PROCEDURE user_create_log( p_flag          IN VARCHAR2
                           ,p_seq_id        IN NUMBER
                           ,p_log           IN VARCHAR2
                           ,p_added_by      IN NUMBER
                           ,result_set      OUT NUMBER
                           );                                                                                 
--==========================================================================
end authorization_pkg;

/

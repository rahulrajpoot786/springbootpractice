--------------------------------------------------------
--  DDL for Synonymn CLM_BULK_UPLD_DIAG_DETAILS
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."CLM_BULK_UPLD_DIAG_DETAILS" FOR "APP"."CLM_BULK_UPLD_DIAG_DETAILS";

--------------------------------------------------------
--  DDL for Synonymn AUTH_SIGN_SEQ
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."AUTH_SIGN_SEQ" FOR "APP"."AUTH_SIGN_SEQ";

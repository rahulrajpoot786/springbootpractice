--------------------------------------------------------
--  DDL for Package FINGER_PRINT_PKG
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "VENUBABU"."FINGER_PRINT_PKG" 
iS
--============================================================================================
PROCEDURE SAVE_FING_PRINT(
                        V_PROVIDER_ID            IN VARCHAR2,                
                        V_USER_ID                IN VARCHAR2 ,
                        V_FNGPRINT               IN BLOB,
                        V_ROW_PROCESSED         OUT NUMBER
                        );
--=================================================================================                       
PROCEDURE SELECT_FINGER_PRINT ( V_PROVIDE_ID   IN VARCHAR2,
                               RESULT_SET     OUT SYS_REFCURSOR                
                               );
--================================================================================    
PROCEDURE GET_CREDENTIALS ( V_CONTACT_ID   IN VARCHAR2,
                             RESULT_SET     OUT SYS_REFCURSOR                
                           );
--=================================================================================   
PROCEDURE SAVE_MEM_FING_PRINT(          
                              V_MEMBER_ID              IN VARCHAR2 ,
                              V_FNGPRINT               IN BLOB,
                              V_ROW_PROCESSED         OUT NUMBER
                                           );
--=================================================================================
PROCEDURE SELECT_MEM_FIN_PRINT (V_MEMBER_ID IN TPA_ENR_POLICY_MEMBER.tpa_enrollment_id%type,
                                                  RESULT_SET OUT   SYS_REFCURSOR);
--=================================================================================

--=================================================================================
END FINGER_PRINT_PKG;

/

--------------------------------------------------------
--  DDL for Synonymn CRITICAL_ILLNESS_CONFIG_SEQ
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."CRITICAL_ILLNESS_CONFIG_SEQ" FOR "APP"."CRITICAL_ILLNESS_CONFIG_SEQ";

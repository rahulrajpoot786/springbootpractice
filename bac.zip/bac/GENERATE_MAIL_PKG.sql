--------------------------------------------------------
--  DDL for Package Body GENERATE_MAIL_PKG
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "VENUBABU"."GENERATE_MAIL_PKG" IS
  --=============================================================================================
  -- This procedure will be called from the scheduler
  --=============================================================================================
  PROCEDURE proc_send_message_scheduled(v_msg_type  destination_message_rcpt.msg_type%TYPE,
                                        v_resultset OUT SYS_REFCURSOR
                                        
                                        ) IS
  
  BEGIN
    OPEN v_resultset FOR
      SELECT ltu.*
        FROM (SELECT RANK() over(partition by destination_message_rcpt.msg_type order by destination_message_rcpt.dest_msg_rcpt_seq_id asc) as AQ,
                     destination_message_rcpt.dest_msg_rcpt_seq_id,
                     destination_message.msg_id,
                     destination_message.msg_sent_from,
                     destination_message_rcpt.msg_type,
                     destination_message_rcpt.present_yn,
                     destination_message.message_title,
                     CASE
                       WHEN destination_message_rcpt.msg_type = 'SMS' THEN
                        destination_message.sms_description
                       ELSE
                        CASE
                          WHEN destination_message.msg_id LIKE 'CIGNA%' THEN
                           dbms_lob.substr(destination_message.cigna_mesage,
                                           4000,
                                           1)
                          ELSE
                           TO_CHAR(destination_message.message)
                        END
                     END AS Message,
                     CASE
                       WHEN destination_message_rcpt.msg_type = 'EMAIL' and
                            destination_message.msg_id LIKE 'CIGNA%' THEN
                        dbms_lob.substr(destination_message.cigna_mesage,
                                        8000,
                                        4001)
                       else
                        null
                     end as cigna_msg,
                     destination_message.enrollment_number,
                     replace(replace(replace(REPLACE(destination_message_rcpt.prm_rcpt_email_list,
                                                     ';',
                                                     ','),
                                             ' ',
                                             NULL),
                                     ';,',
                                     ','),
                             '.,',
                             ',') AS prm_rcpt_email_list,
                     destination_message_rcpt.prm_rcpt_fax_nos,
                     destination_message_rcpt.prm_rcpt_sms,
                     destination_message_rcpt.sec_rcpt_email_list,
                     destination_message.file_path_name,
                     case
                       when destination_message.msg_id LIKE 'CIGNA%' then
                        'Claims@cignattk.in'
                       else
                        ttk_app_config.app_param_value
                     end sender_mail_id,
                     destination_message.added_date,
                     destination_message.cigna_sms_yn,
                     NVL(destination_message.Policy_Tob,(SELECT DOC_DATA FROM APP.TTK_HELP_DOC WHERE DOC_NAME='TOB_DOC' )) AS Policy_Tob
                   
                FROM destination_message,
                     destination_message_rcpt,
                     ttk_app_config
               WHERE (destination_message_rcpt.dest_msg_seq_id =
                     destination_message.dest_msg_seq_id)
                 and (destination_message_rcpt.mail_status = 'INP')
                 AND (destination_message_rcpt.present_yn = 'Y')
                 AND (destination_message_rcpt.added_date <= sysdate)
                 AND (ttk_app_config.app_parameter = 'SITE_ADMIN_EMAIL')
                 AND (destination_message_rcpt.msg_type = v_msg_type)
                 AND (destination_message.source_id <>('PREAUTH'))
                 AND  (destination_message.msg_id!='CLAIM_BULK_UPLOAD_DASHBOARD')
                 and (destination_message.Message_Title NOT IN ('Preauth Status of ')
                     )
                 and upper(destination_message.msg_id) != 'MOB_APP_OTP') ltu
       WHERE ltu.aq <= 125; --ADDED FOR CR KOC1132
    /*AND
    ( destination_message_rcpt.prm_rcpt_email_list IS NOT NULL AND
    instr(destination_message_rcpt.prm_rcpt_email_list,'@') > 0 AND
    instr(destination_message_rcpt.prm_rcpt_email_list,'.') > 0 )*/
  END;
  --===============================================================================================
  PROCEDURE proc_send_msg_sched_preauth(v_msg_type  destination_message_rcpt.msg_type%TYPE,
                                        v_resultset OUT SYS_REFCURSOR) IS
  
    v_msg_id       varchar2(100); --koc_ins_mail
    v_cigna_mesage varchar2(32767); --koc_ins_mail
  
  BEGIN
  
    OPEN v_resultset FOR
      SELECT ltu.*
        FROM (SELECT /*+ optimizer_features_enable('11.2.0.1') */
               RANK() over(partition by destination_message_rcpt.msg_type order by destination_message_rcpt.dest_msg_rcpt_seq_id asc) as AQ,
               destination_message_rcpt.dest_msg_rcpt_seq_id,
               destination_message.msg_id,
               destination_message.msg_sent_from,
               destination_message_rcpt.msg_type,
               destination_message_rcpt.present_yn,
               destination_message.message_title,
               CASE
                 WHEN destination_message_rcpt.msg_type = 'SMS' THEN
                  destination_message.sms_description
                 ELSE
                  CASE
                    WHEN destination_message.msg_id LIKE '%CIGNA%' THEN
                     dbms_lob.substr(destination_message.cigna_mesage, 4000, 1)
                  --   WHEN  destination_message.msg_id LIKE 'GLOBAL_CIGNA%' THEN dbms_lob.substr(destination_message.cigna_mesage, 4000, 1 )--- added by "manas"
                    ELSE
                     TO_CHAR(destination_message.message)
                  END
               END AS Message,
               CASE
                 WHEN destination_message_rcpt.msg_type = 'EMAIL' and
                      destination_message.msg_id LIKE '%CIGNA%' THEN
                  dbms_lob.substr(destination_message.cigna_mesage,
                                  8000,
                                  4001)
               /* WHEN destination_message_rcpt.msg_type ='EMAIL' and destination_message.msg_id LIKE 'GLOBAL_CIGNA%' THEN---- added by "manas"
               dbms_lob.substr(destination_message.cigna_mesage, 8000, 4001 )*/
                 else
                  null
               end as cigna_msg,
               destination_message.enrollment_number,
               replace(replace(replace(REPLACE(destination_message_rcpt.prm_rcpt_email_list,
                                               ';',
                                               ','),
                                       ' ',
                                       NULL),
                               ';,',
                               ','),
                       '.,',
                       ',') AS prm_rcpt_email_list,
               destination_message_rcpt.prm_rcpt_fax_nos,
               destination_message_rcpt.prm_rcpt_sms,
               destination_message_rcpt.sec_rcpt_email_list,
               destination_message.file_path_name,
               case
                 when destination_message.msg_id LIKE '%CIGNA%' then
                  'Claims@cignattk.in'
               --when destination_message.msg_id LIKE 'GLOBAL_CIGNA%' then 'Claims@cignattk.in'--added by "manas"
                 else
                  ttk_app_config.app_param_value
               end sender_mail_id,
               destination_message.added_date,
               destination_message.cigna_sms_yn
                FROM app.destination_message,
                     app.destination_message_rcpt,
                     app.ttk_app_config
               WHERE (destination_message_rcpt.dest_msg_seq_id =
                     destination_message.dest_msg_seq_id)
                 and (destination_message_rcpt.mail_status = 'INP')
                 AND (destination_message_rcpt.present_yn = 'Y')
                 AND (destination_message_rcpt.added_date <= sysdate)
                 AND (ttk_app_config.app_parameter = 'SITE_ADMIN_EMAIL')
                 AND (destination_message_rcpt.msg_type = v_msg_type)
                 and (destination_message.Message_Title NOT IN
                     ('Preauth Status of '))
                 and (upper(destination_message.source_id) NOT IN ('CLAIMS', 'CLAIM'))
                 and (upper(destination_message.source_id) =
                     upper('PREAUTH') or
                     upper(destination_message.msg_id) in
                     ('FORGOT_PASSWORD_EMP',
                       'RESET_PASSWORD',
                       'RESET_PASSWORD_BROCODE',
                       'RESET_PASSWORD_GROUPID',
                       'RESET_PASSWORD_INSCODE','RESET_PASSWORD_EMP'))
                 and upper(destination_message.msg_id) != 'MOB_APP_OTP') ltu
       WHERE ltu.aq <= 50; --ADDED FOR CR KOC1132
    /*AND
    ( destination_message_rcpt.prm_rcpt_email_list IS NOT NULL AND
    instr(destination_message_rcpt.prm_rcpt_email_list,'@') > 0 AND
    instr(destination_message_rcpt.prm_rcpt_email_list,'.') > 0 )*/
  
  END proc_send_msg_sched_preauth;
  --=============================================================================================
  -- This procedure will be called from the Java scheduler
  -- This procedure will return the list of OTP Records Only to verify against the DONE queue in
  --=============================================================================================
  PROCEDURE proc_send_scheduled_otp(v_msg_type  destination_message_rcpt.msg_type%TYPE,
                                    v_resultset OUT SYS_REFCURSOR
                                   ) IS
  
  BEGIN
    OPEN v_resultset FOR
      SELECT ltu.*
        FROM (SELECT RANK() over(partition by destination_message_rcpt.msg_type order by destination_message_rcpt.dest_msg_rcpt_seq_id asc) as AQ,
                     destination_message_rcpt.dest_msg_rcpt_seq_id,
                     destination_message.msg_id,
                     destination_message.msg_sent_from,
                     destination_message_rcpt.msg_type,
                     destination_message_rcpt.present_yn,
                     destination_message.message_title,
                     CASE
                       WHEN destination_message_rcpt.msg_type = 'SMS' THEN
                        destination_message.sms_description
                       ELSE
                        CASE
                          WHEN destination_message.msg_id LIKE 'CIGNA%' THEN
                           dbms_lob.substr(destination_message.cigna_mesage,
                                           4000,
                                           1)
                          ELSE
                           TO_CHAR(destination_message.message)
                        END
                     END AS Message,
                     CASE
                       WHEN destination_message_rcpt.msg_type = 'EMAIL' and
                            destination_message.msg_id LIKE 'CIGNA%' THEN
                        dbms_lob.substr(destination_message.cigna_mesage,
                                        8000,
                                        4001)
                       else
                        null
                     end as cigna_msg,
                     destination_message.enrollment_number,
                     replace(replace(replace(REPLACE(destination_message_rcpt.prm_rcpt_email_list,
                                                     ';',
                                                     ','),
                                             ' ',
                                             NULL),
                                     ';,',
                                     ','),
                             '.,',
                             ',') AS prm_rcpt_email_list,
                     destination_message_rcpt.prm_rcpt_fax_nos,
                     destination_message_rcpt.prm_rcpt_sms,
                     destination_message_rcpt.sec_rcpt_email_list,
                     destination_message.file_path_name,
                     case
                       when destination_message.msg_id LIKE 'CIGNA%' then
                        'Claims@cignattk.in'
                       else
                        ttk_app_config.app_param_value
                     end sender_mail_id,
                     destination_message.added_date,
                     destination_message.cigna_sms_yn
                FROM destination_message,
                     destination_message_rcpt,
                     ttk_app_config
               WHERE (destination_message_rcpt.dest_msg_seq_id =
                     destination_message.dest_msg_seq_id)
                 and (destination_message_rcpt.mail_status = 'INP')
                 AND (destination_message_rcpt.present_yn = 'Y')
                 AND (destination_message_rcpt.added_date <= sysdate)
                 AND (ttk_app_config.app_parameter = 'SITE_ADMIN_EMAIL')
                 AND (destination_message_rcpt.msg_type = v_msg_type)
                 AND upper(destination_message.msg_id) IN 'MOB_APP_OTP' ) ltu
       WHERE ltu.aq <= 125;    
  END proc_send_scheduled_otp;
  --=============================================================================================
  -- This procedure will be called from the Java scheduler
  -- This procedure will return the list of FAX Records Only to verify against the DONE queue in
  -- FAX Server
  --=============================================================================================
  PROCEDURE proc_get_pending_fax(v_resultset OUT SYS_REFCURSOR) IS
  
  BEGIN
    OPEN v_resultset FOR
      SELECT destination_message_rcpt.dest_msg_rcpt_seq_id,
             destination_message_rcpt.message_job_id
        FROM destination_message_rcpt
       WHERE (destination_message_rcpt.msg_type = 'FAX')
         AND (destination_message_rcpt.mail_status = 'SNT')
         AND (destination_message_rcpt.msg_status_general_type_id = 'MIQ')
       ORDER BY destination_message_rcpt.added_date;
  END;
  --=============================================================================================
  -- This procedure will be called to get the mail details and Branch ID & toll free number.
  -- This requirement was changed to get only Branch ID and TOll number. Email iD and SMS will be the one
  -- that is entered either in Pre-auth or claims.
  --=============================================================================================

  PROCEDURE proc_get_mail_details(v_policy_seq_id  tpa_enr_policy.policy_seq_id%TYPE,
                                  v_seq_id         tpa_enr_policy_member.member_seq_id%TYPE, -- If policy Seq id is Null, v_seq_id will be claim seq id
                                  v_tpa_code       OUT tpa_office_info.office_code%TYPE,
                                  v_tpa_toll_phone OUT tpa_office_info.toll_free_no%TYPE) IS
    -- Get Mail details for Policy Number. This also returns the Branch which owns the policy and
    -- their toll free number.
    CURSOR cr_get_mail_details(v_policy_seq_id tpa_enr_policy.policy_seq_id%TYPE) IS
      SELECT tpa_office_info.office_code, tpa_office_info.toll_free_no
        FROM tpa_enr_policy, tpa_office_info
       WHERE (tpa_office_info.tpa_office_seq_id =
             tpa_enr_policy.tpa_office_seq_id)
         AND (tpa_enr_policy.policy_seq_id = v_policy_seq_id);
  
    -- In case of Manual Claims Only.
    CURSOR cr_get_claim_mail_details(v_seq_id tpa_enr_policy_member.member_seq_id%TYPE) IS
      SELECT toi.office_code, toi.toll_free_no
        FROM tpa_office_info           toi,
             clm_authorization_details clm,
             tpa_hosp_info             thi,
             clm_hospital_details      ch
       WHERE ch.hosp_seq_id = thi.hosp_seq_id
         AND clm.claim_seq_id = ch.claim_seq_id
         AND clm.claim_seq_id = v_seq_id;
    /*SELECT tpa_office_info.office_code,
           tpa_office_info.toll_free_no
      FROM tpa_office_info,
           clm_general_details,
           clm_inward
    WHERE ( clm_inward.tpa_office_seq_id              = tpa_office_info.tpa_office_seq_id ) AND
          ( clm_general_details.claims_inward_seq_id  = clm_inward.claims_inward_seq_id ) AND
          ( clm_general_details.claim_seq_id          = v_seq_id ) ;*/
  BEGIN
  
    IF (v_policy_seq_id IS NOT NULL) THEN
      -- get mail details
      OPEN cr_get_mail_details(v_policy_seq_id);
      FETCH cr_get_mail_details
        INTO v_tpa_code, v_tpa_toll_phone;
      CLOSE cr_get_mail_details;
    ELSIF (v_policy_seq_id IS NULL) THEN
      -- Used in Orphan Claims Only in case,
      OPEN cr_get_claim_mail_details(v_seq_id);
      FETCH cr_get_claim_mail_details
        INTO v_tpa_code, v_tpa_toll_phone;
      CLOSE cr_get_claim_mail_details;
    END IF;
  END;

  --=============================================================================================
  -- This procedure will be called from the Application or other procedures.
  -- This is first level interface
  -- In the same call if the generate message has to be called multiple times, the same can be
  -- handled here.
  --=============================================================================================

  PROCEDURE proc_form_message(v_message_type_id    VARCHAR2,
                              v_parameters         VARCHAR2,
                              v_added_by           Destination_message.added_by%TYPE DEFAULT 0,
                              v_DEST_MSG_SEQ_ID    OUT VARCHAR2,
                              v_additional_param   VARCHAR2 DEFAULT 0,
                              v_additional_param_2 VARCHAR2 DEFAULT 0,
                              v_additional_param_3 VARCHAR2 DEFAULT 0,
                              v_doc                VARCHAR2 DEFAULT null --added by chiranjibi
                              ) IS
  
    v_email_id            tpa_user_contacts.primary_email_id%TYPE;
    v_pol_email_id        app.tpa_enr_mem_address.email_id%TYPE;
    v_pol_mob             app.tpa_enr_mem_address.mobile_no%TYPE;
    v_ins_email_id        app.tpa_ins_info.email_id%TYPE;
    v_clm_mem_mail        tpa_enr_mem_address.Email_Id%type;
    v_clm_mem_phone       tpa_enr_mem_address.mobile_no%type;
    v_next_message_called VARCHAR2(1000);
    v_count               INTEGER;
    v_count1              INTEGER;
    v_count2              INTEGER;
    v_count3              INTEGER;
    v_count4              INTEGER;
    v_hosp_seq_id         TPA_HOSP_INFO.HOSP_SEQ_ID%TYPE;
    v_pat_auth_seq_id     PAT_AUTHORIZATION_DETAILS.PAT_AUTH_SEQ_ID%TYPE;
    v_ins_seq_id          TPA_INS_INFO.INS_SEQ_ID%TYPE;
    v_claim_seq_id        Clm_Authorization_Details.Claim_Seq_Id%TYPE;
    v_clm_hosp_mail       TPA_HOSP_INFO.PRIMARY_EMAIL_ID%TYPE;
    v_clm_hosp_phone      TPA_HOSP_INFO.OFF_PHONE_NO_1%TYPE;
    v_group_seq_id        TPA_GROUPS.GROUP_SEQ_ID%TYPE;
    v_cor_email           VARCHAR2(100);
    v_count5              NUMBER;
  
    -- Get the Hospital ACTIVE TPA PRIMARY CO-ordinators EMAIL ID for THOSE HOSPITALS
    -- Where the Notification is being ENABLED.
    /*CURSOR cr_get_hospital_email_id ( v_hosp_seq_id TPA_HOSP_INFO.HOSP_SEQ_ID%TYPE ) IS
     SELECT tpa_user_contacts.primary_email_id AS EMAIL_ID --//ED
     FROM tpa_hosp_info,
          tpa_user_contacts
    WHERE ( tpa_user_contacts.active_yn = 'Y' ) AND
          ( tpa_user_contacts.primary_email_id IS NOT NULL ) AND --//ED
          ( tpa_user_contacts.hosp_seq_id = tpa_hosp_info.hosp_seq_id ) and
          ( tpa_user_contacts.designation_type_id = 'CRP' ) AND
          ( tpa_hosp_info.notification_general_type_id = 'NAE' ) AND
          ( tpa_hosp_info.hosp_seq_id = v_hosp_seq_id ) ;*/
  
    -- PRE-Auth
    --CURSOR cr_get_regular_preauth (v_pat_gen_detail_seq_id pat_general_details.pat_gen_detail_seq_id%TYPE) IS
    /*SELECT pat_enroll_details.hosp_seq_id
     FROM pat_enroll_details,
          pat_general_details
    WHERE ( pat_general_details.pat_enroll_detail_seq_id = pat_enroll_details.pat_enroll_detail_seq_id ) and
          ( pat_general_details.pat_gen_detail_seq_id    = v_pat_gen_detail_seq_id ) ;*/
  
    -- PRE-AUTH shortfall
    --CURSOR cr_get_shortfall_regular ( v_shortfall_seq_id shortfall_details.SHORTFALL_SEQ_ID%TYPE ) IS
    /*SELECT pat_enroll_details.hosp_seq_id
     FROM pat_enroll_details,
          pat_general_details,
          shortfall_details A
    WHERE ( pat_general_details.pat_enroll_detail_seq_id = pat_enroll_details.pat_enroll_detail_seq_id ) and
          ( pat_general_details.pat_gen_detail_seq_id    = A.PAT_GEN_DETAIL_SEQ_ID ) and
          ( A.SHORTFALL_SEQ_ID                           = v_shortfall_seq_id );*/
    
    
    -- CORPORATE SEQ_ID
    CURSOR cr_get_cor (v_group_seq_id TPA_GROUPS.group_name%TYPE) IS
      SELECT uc.contact_seq_id,
             ttk_util_pkg.fn_decrypt(uc.primary_email_id) cor_emial
      FROM Tpa_User_Contacts uc
      WHERE uc.contact_seq_id = v_group_seq_id;
      
    -- BROKER SEQ_ID
    CURSOR cr_get_bro (v_bro_seq_id NUMBER) IS
    SELECT bi.ins_seq_id
    FROM Tpa_Bro_Info bi
    WHERE bi.ins_seq_id = v_bro_seq_id;
    -- PRE-AUTH shortfall            
    CURSOR cr_get_shortfall_regular(v_shortfall_seq_id shortfall_details.SHORTFALL_SEQ_ID%TYPE) IS
      SELECT pad.hosp_seq_id
        FROM pat_authorization_details pad, shortfall_details sd
       WHERE (pad.pat_auth_seq_id = sd.pat_gen_detail_seq_id)
         and (sd.SHORTFALL_SEQ_ID = v_shortfall_seq_id);
  
    --Pre_Auth Seq Id
    CURSOR cur_get_pre_auth(v_pat_auth_seq_id pat_authorization_details.pat_auth_seq_id%TYPE) IS
      SELECT pad.pat_auth_seq_id
        FROM PAT_AUTHORIZATION_DETAILS pad
       WHERE pad.pat_auth_seq_id = v_pat_auth_seq_id;
  
    --Polilcy Holder Contact Info
    CURSOR pol_hol_details_cur(v_pat_auth_seq_id pat_authorization_details.pat_auth_seq_id%TYPE) IS
      SELECT ttk_util_pkg.fn_decrypt(ma.email_id) Pol_Email,
             ttk_util_pkg.fn_decrypt(ma.mobile_no) Pol_Mob
      
        FROM pat_authorization_details pad,
             tpa_office_info           toi,
             tpa_hosp_info             tpi,
             app.tpa_enr_policy_member pm,
             app.tpa_enr_mem_address   ma,
             app.tpa_ins_info          tii,
             app.tpa_enr_policy        tep
      
       WHERE pad.hosp_seq_id = tpi.hosp_seq_id
         and pad.ins_seq_id = tii.ins_seq_id
         and pad.policy_seq_id = tep.policy_seq_id
         and pm.member_seq_id = pad.member_seq_id
         and pm.enr_address_seq_id = ma.enr_address_seq_id
         and tpi.tpa_office_seq_id = toi.tpa_office_seq_id
         and pad.pat_auth_seq_id = v_pat_auth_seq_id;
  
    --Payer Id
    CURSOR payer_seq_cur(v_ins_seq_id Tpa_Ins_Info.Ins_Seq_Id%TYPE) IS
      SELECT tii.ins_seq_id
        FROM Tpa_Ins_Info tii, pat_authorization_details pad
       WHERE pad.Ins_Seq_Id = tii.Ins_Seq_Id
         AND tii.ins_seq_id = v_ins_seq_id;
  
    -- Payer Contact Info
    CURSOR ins_con_info_cur(v_ins_seq_id tpa_ins_info.ins_seq_id%TYPE) IS
      SELECT ttk_util_pkg.fn_decrypt(tii.email_id) Ins_Email
        FROM pat_authorization_details pad, app.tpa_ins_info tii
       WHERE pad.ins_seq_id = tii.ins_seq_id
         and tii.ins_seq_id = v_ins_seq_id
       group by tii.ins_seq_id, tii.email_id;
  
    --Provider Seq Id
    CURSOR cr_get_hosp_seq(v_hosp_seq_id tpa_hosp_info.hosp_seq_id%TYPE) IS
      SELECT thi.hosp_seq_id
        FROM tpa_hosp_info thi, pat_authorization_details pad
       WHERE (thi.hosp_seq_id = pad.hosp_seq_id)
         and (pad.hosp_seq_id = v_hosp_seq_id);
  
    --Provider Contact Info
    CURSOR cr_get_hospital_email_id(v_hosp_seq_id tpa_hosp_info.hosp_seq_id%TYPE) IS
    
      SELECT ttk_util_pkg.fn_decrypt(tpi.primary_email_id) Hosp_Email,
             ttk_util_pkg.fn_decrypt(tpi.off_phone_no_1) Hosp_Phone,
             ttk_util_pkg.fn_decrypt(tpi.office_fax_no) Hosp_Fax
      
        FROM pat_authorization_details pad, tpa_hosp_info tpi
       WHERE pad.hosp_seq_id = tpi.hosp_seq_id
         and tpi.hosp_seq_id = v_hosp_seq_id
       GROUP BY tpi.hosp_seq_id,
                tpi.primary_email_id,
                tpi.off_phone_no_1,
                tpi.office_fax_no;
  
    -- Claim Seq Id
    CURSOR cur_get_clm_seq(v_claim_seq_id clm_authorization_details.claim_seq_id%TYPE) IS
      SELECT clm.claim_seq_id
        FROM clm_authorization_details clm
       WHERE clm.claim_seq_id = v_claim_seq_id;
    -- Claim info
    CURSOR clm_info_cur(v_claim_seq_id clm_authorization_details.claim_seq_id%TYPE) IS
      select ttk_util_pkg.fn_decrypt(ma.email_id) email,
             ttk_util_pkg.fn_decrypt(ma.mobile_no) mobile
        FROM app.clm_authorization_details clm,
             app.tpa_enr_policy_member     pm,
             app.tpa_enr_mem_address       ma,
             app.clm_hospital_details      csh,
             tpa_hosp_info                 tpi,
             tpa_office_info               toi
      
       WHERE pm.member_seq_id = clm.member_seq_id
         and ma.enr_address_seq_id = pm.enr_address_seq_id
         and csh.claim_seq_id = clm.claim_seq_id
         and csh.hosp_seq_id = tpi.hosp_seq_id
         and tpi.tpa_office_seq_id = toi.tpa_office_seq_id
         and clm.claim_seq_id = v_claim_seq_id;
  
    --Cursor Claim Hosp Details
    CURSOR cur_clm_hosp_det(v_claim_seq_id clm_authorization_details.claim_seq_id%TYPE) IS
      select ttk_util_pkg.fn_decrypt(tpi.primary_email_id) email,
             ttk_util_pkg.fn_decrypt(tpi.off_phone_no_1) mobile
        FROM app.clm_authorization_details clm,
             app.tpa_enr_policy_member     pm,
             app.tpa_enr_mem_address       ma,
             app.clm_hospital_details      csh,
             tpa_hosp_info                 tpi,
             tpa_office_info               toi
      
       WHERE pm.member_seq_id = clm.member_seq_id
         and ma.enr_address_seq_id = pm.enr_address_seq_id
         and csh.claim_seq_id = clm.claim_seq_id
         and csh.hosp_seq_id = tpi.hosp_seq_id
         and tpi.tpa_office_seq_id = toi.tpa_office_seq_id
         and clm.claim_seq_id = v_claim_seq_id;
    ---------------------------------------------------------------------------------
    --Added this cursor for fetch Contacts Details of Pre_Auth--
    ---------------------------------------------------------------------------------
  
  BEGIN
  
    --Rgular mail generation
    proc_generate_message(v_message_type_id,
                          v_parameters,
                          v_added_by,
                          v_dest_msg_seq_id,
                          v_additional_param,
                          v_additional_param_2,
                          v_additional_param_3,
                          v_doc);
  
    -- Additionl to the earlier mail, if hospital mail has to be sent, then following execution has to happen.
    IF ((v_message_type_id = 'PREAUTH_STATUS') OR
       (v_message_type_id = 'PREAUTH_APPROVED') OR
       (v_message_type_id = 'PREAUTH_REJECTED')) THEN
    
      IF (v_message_type_id = 'PREAUTH_STATUS') THEN
        v_next_message_called := 'PREAUTH_STATUS_NHCP';
      ELSIF (v_message_type_id = 'PREAUTH_APPROVED') THEN
        v_next_message_called := 'PREAUTH_APPROVED_NHCP';
      
      ELSIF (v_message_type_id = 'PREAUTH_REJECTED') THEN
        v_next_message_called := 'PREAUTH_REJECTED_NHCP';
      
      END IF;
      --For gather Hospital Contact Information 
      OPEN cr_get_hosp_seq(v_parameters);
      FETCH cr_get_hosp_seq
        INTO v_hosp_seq_id;
      CLOSE cr_get_hosp_seq;
      -- For gather Policy Holder Contact Information
      OPEN cur_get_pre_auth(v_parameters);
      FETCH cur_get_pre_auth
        INTO v_pat_auth_seq_id;
      CLOSE cur_get_pre_auth;
    
      OPEN payer_seq_cur(v_parameters);
      FETCH payer_seq_cur
        INTO v_ins_seq_id;
      CLOSE payer_seq_cur;
    
    ELSIF (v_message_type_id = 'PREAUTH_SHORTFALL') THEN
      v_next_message_called := 'PREAUTH_SHORTFALL_NHCP';
      OPEN cr_get_shortfall_regular(v_parameters);
      FETCH cr_get_shortfall_regular
        INTO v_hosp_seq_id;
      CLOSE cr_get_shortfall_regular;
    END IF;
    
    IF (v_message_type_id = 'NEW_USERID_GROUPID') THEN
      OPEN cr_get_cor (v_parameters);
      FETCH cr_get_cor INTO v_group_seq_id, v_cor_email;
      CLOSE cr_get_cor;
    END IF;
  
    -- Usually there is going to be only one TPA_COORDINATOR.
    -- Incase if there are more than 1 TPA PRIMARY CO-ordinator....
    v_count := 0;
    FOR rec IN cr_get_hospital_email_id(v_hosp_seq_id) LOOP
      IF (v_count = 0) THEN
        v_email_id := rec.Hosp_Email;
        v_count    := v_count + 1;
      ELSE
        v_email_id := v_email_id || ',' || rec.Hosp_Email;
      END IF;
    END LOOP;
    -- For Policy Holder Contacts
    v_count1 := 0;
    FOR rec IN pol_hol_details_cur(v_pat_auth_seq_id) LOOP
      IF (v_count1 = 0) THEN
        v_pol_email_id := rec.pol_email;
        v_pol_mob      := rec.pol_mob;
        v_count1       := v_count1 + 1;
      ELSE
        v_pol_email_id := v_pol_email_id || ',' || rec.pol_email;
        v_pol_mob      := v_pol_mob || ',' || rec.pol_mob;
      END IF;
    END LOOP;
  
    v_count2 := 0;
    FOR rec IN ins_con_info_cur(v_hosp_seq_id) LOOP
      IF (v_count2 = 0) THEN
        v_ins_email_id := rec.Ins_Email;
        v_count2       := v_count2 + 1;
      ELSE
        v_ins_email_id := v_ins_email_id || ',' || rec.Ins_Email;
      END IF;
    END LOOP;
  
    v_count3 := 0;
    FOR rec IN clm_info_cur(v_claim_seq_id) LOOP
      IF (v_count3 = 0) THEN
        v_clm_mem_mail  := rec.email;
        v_clm_mem_phone := rec.mobile;
      ELSE
        v_clm_mem_mail  := v_clm_mem_mail || ', ' || rec.email;
        v_clm_mem_phone := v_clm_mem_phone || ', ' || rec.mobile;
      END IF;
    END LOOP;
  
    v_count4 := 0;
    FOR rec IN cur_clm_hosp_det(v_claim_seq_id) LOOP
      IF (v_count3 = 0) THEN
        v_clm_hosp_mail  := rec.email;
        v_clm_hosp_phone := rec.mobile;
      ELSE
        v_clm_hosp_mail  := v_clm_hosp_mail || ' ' || rec.email;
        v_clm_hosp_phone := v_clm_hosp_phone || ' ' || rec.mobile;
      END IF;
    END LOOP;
    
    v_count5 := 0;
    FOR rec IN cr_get_cor(v_group_seq_id) LOOP
      IF (v_count4 = 0) THEN
        v_cor_email := v_cor_email ||' '||rec.cor_emial;
      END IF;
    END LOOP;
    -- If v_count1 = 1 then policy holder notification to be sent.
    IF (v_count1 = 1) THEN
      proc_generate_message(v_next_message_called,
                            v_parameters,
                            v_added_by,
                            v_DEST_MSG_SEQ_ID,
                            v_email_id,
                            v_additional_param_2,
                            null);
    END IF;
    
    --==================================================================
    -- If v_count2 = 1 then Payer notification to be setn.
    /*FOR rec IN ins_con_info_cur(v_ins_seq_id)
    LOOP
      IF (v_count2 = 0) THEN
        v_ins_email_id := rec.pol_email;
        v_pol_mob      := rec.pol_mob;
        v_count1       := v_ount1 + 1;
      ELSE
        v_ins_email_id := v_ins_email_id || ',' ||rec.ins_email;
      END IF;
    END LOOP;
    
    -- If v_count = 1 then policy holder notification to be sent.
    IF ( v_count2 = 1 ) THEN
       proc_generate_message ( v_next_message_called, v_parameters, v_added_by, v_DEST_MSG_SEQ_ID,
                      v_email_id, v_additional_param_2,null );
    END IF;*/
  
  END;

  --=============================================================================================
  -- This procedure will get the data from the tables and would call mail merge procedure
  --=============================================================================================
  PROCEDURE proc_generate_message(v_message_type_id    VARCHAR2,
                                  v_parameters         VARCHAR2,
                                  v_added_by           Destination_message.added_by%TYPE,
                                  v_DEST_MSG_SEQ_ID    OUT VARCHAR2,
                                  v_additional_param   VARCHAR2 DEFAULT 0,
                                  v_additional_param_2 VARCHAR2 DEFAULT 0,
                                  v_additional_param_3 VARCHAR2 DEFAULT 0,
                                  v_doc                VARCHAR2 DEFAULT null --added by chiranjibi
                                  ) IS
    v_sid                VARCHAR2(100);
    v_merged_message     VARCHAR2(32765);
    v_merged_SMS_message VARCHAR2(4000);
    -- v_user_id                  tpa_login_info.user_id%TYPE;
    v_email_id1        tpa_user_contacts.primary_email_id%TYPE;
    v_url_name         tpa_system_parameters.application_url%TYPE;
    v_module_name      APP.SOURCE_MESSAGE.module_name%TYPE;
    v_sent_from        APP.SOURCE_MESSAGE.msg_sent_from%TYPE;
    v_msg_title        APP.SOURCE_MESSAGE.message_title%TYPE;
    v_send_as_email_yn APP.SOURCE_MESSAGE.send_as_email_yn%TYPE;
    v_send_as_sms_yn   APP.SOURCE_MESSAGE.send_as_sms_yn%TYPE;
    v_send_as_fax_yn   APP.SOURCE_MESSAGE.send_as_fax_yn%TYPE;
    v_prm_rcpt_list    APP.SOURCE_MESSAGE.prm_rcpt_email_list%TYPE;
    v_sec_rcpt_list    APP.SOURCE_MESSAGE.sec_rcpt_email_list%TYPE;
    v_email_ids        DESTINATION_MESSAGE_RCPT.PRM_RCPT_EMAIL_LIST%TYPE;
    v_sms              DESTINATION_MESSAGE_RCPT.PRM_RCPT_SMS%TYPE;
    v_fax              DESTINATION_MESSAGE_RCPT.PRM_RCPT_FAX_NOS%TYPE;
    v_insert_message   VARCHAR2(1);
    --v_claimant_name            pat_enroll_details.claimant_name%TYPE;
    v_employee_no           VARCHAR2(50); --FOR KOC 1268
    v_claimant_name         VARCHAR2(90);
    v_received_date         DATE;
    v_pre_auth_number       pat_enroll_details.pre_auth_number%TYPE;
    v_auth_number           pat_enroll_details.auth_number%TYPE;
    v_status                tpa_general_code.description%TYPE;
    v_sms_phone             pat_general_details.phone_no_in_hospitalisation%TYPE;
    v_fax_number            DESTINATION_MESSAGE_RCPT.PRM_RCPT_FAX_NOS%TYPE;
    v_requested_amt         pat_general_details.pat_requested_amount%TYPE;
    v_type                  pat_general_details.pat_general_type_id%TYPE;
    v_total_approved_amount pat_general_details.total_app_amount%TYPE;
    v_count                 NUMBER;
    v_tpa_code              tpa_office_info.office_code%TYPE;
    v_tpa_toll_phone        tpa_office_info.toll_free_no%TYPE;
    v_shortfall_id          shortfall_details.shortfall_id%TYPE;
    v_hosp_seq_id           pat_enroll_details.hosp_seq_id%TYPE;
    v_policy_seq_id         tpa_enr_policy.policy_seq_id%TYPE;
    v_member_seq_id         tpa_enr_policy_member.member_seq_id%TYPE;
    v_remarks               VARCHAR2(3000);
    v_claim_number          clm_general_details.claim_number%TYPE;
    v_final_log_message     VARCHAR2(4000);
    v_message_status        VARCHAR2(2000);
    v_hospital_name         TPA_HOSP_INFO.HOSP_NAME%TYPE;
    v_notification_type     VARCHAR2(30);
    v_pat_gen_detail_seq_id pat_general_details.pat_gen_detail_seq_id%TYPE;
    v_claim_seq_id          clm_general_details.claim_seq_id%TYPE;
    v_claim_type            clm_inward.claim_general_type_id%TYPE;
    v_enrollment_number     tpa_enr_policy_group.tpa_enrollment_number%TYPE;
    v_msg_type              destination_message_rcpt.msg_type%TYPE;
    v_present_yn            destination_message_rcpt.present_yn%TYPE;
    v_document_name         destination_message.FILE_PATH_NAME%TYPE;
    v_user_type             tpa_user_contacts.user_general_type_id%TYPE;
    v_case_number           VARCHAR2(250);
    v_member_info           VARCHAR2(32679);
    v_doh                   DATE;
    v_mail_category         VARCHAR2(3); -- The send message id is of what type in Database
    v_process_yn            VARCHAR2(1); -- Can the process be done or not
    v_general_mail          DESTINATION_MESSAGE_RCPT.PRM_RCPT_EMAIL_LIST%TYPE; -- Generic mail id created at the group
    v_cc_mail               DESTINATION_MESSAGE_RCPT.SEC_RCPT_EMAIL_LIST%TYPE;
    v_group_name            TPA_GROUP_REGISTRATION.GROUP_NAME%TYPE;
    v_customise_allowed_YN  APP.SOURCE_MESSAGE.CUSTOMIZATION_ALLOWED_YN%TYPE;
    --koc 1216 v1 mail template
  
    V_AILMENT_DESCRIPTION        AILMENT_DETAILS.AILMENT_DESCRIPTION%TYPE;
    V_DATE_OF_DISCHARGE          DATE;
    V_INSURED_NAME               TPA_ENR_POLICY_GROUP.INSURED_NAME%TYPE;
    V_TPA_ENROLLMENT_ID          PAT_ENROLL_DETAILS.TPA_ENROLLMENT_ID%TYPE;
    v_provisional_diagnosis      AILMENT_DETAILS.provisional_diagnosis%type;
    v_pat_status_general_type_id pat_enroll_details.pat_status_general_type_id%type;
    v_prev_approved_amount       pat_general_details.prev_approved_amount%type;
    V_CLAIM_FILE_NUMBER          CLM_GENERAL_DETAILS.CLAIM_FILE_NUMBER%TYPE;
    V_POLICY_NUMBER              tpa_enr_policy.policy_number%type;
    V_HOSP_NAME                  TPA_HOSP_INFO.HOSP_NAME%TYPE;
    V_ADDITTIONAL_SUM            PAT_GENERAL_DETAILS.PAT_REQUESTED_AMOUNT%TYPE;
    V_FINAL_SUM                  PAT_GENERAL_DETAILS.PAT_REQUESTED_AMOUNT%TYPE;
    v_hosp_email_id              tpa_hosp_info.primary_email_id%TYPE; --Added By Chiranjibi
    v_ph_no_catagory             pat_general_details.ph_no_catagory%TYPE; --Added by chiranjibi
    --================================================================================================================
    v_Apr_Amt1           pat_authorization_details.tot_approved_amount%TYPE;
    v_Claiment_Name1     pat_authorization_details.Mem_Name%TYPE;
    v_Addmission_Date1   pat_authorization_details.Hospitalization_Date%TYPE;
    v_Preauth_Number1    pat_authorization_details.pre_auth_number%TYPE;
    v_Enrollment_Id1     pat_authorization_details.tpa_enrollment_id%TYPE;
    v_Authorization_Num1 pat_authorization_details.auth_number%TYPE;
    v_Policy_Num1        tpa_enr_policy.policy_number%TYPE;
    v_status1            varchar2(10);
    v_hosp_name1         tpa_hosp_info.hosp_name%TYPE;
    v_Mem_Email1         tpa_enr_mem_address.email_id%TYPE;
    v_mem_sec_mail       tpa_enr_mem_address.email_id1%TYPE;
    v_Mem_Phone1         tpa_enr_mem_address.mobile_no%TYPE;
    v_Hosp_Email1        tpa_hosp_info.primary_email_id%TYPE;
    v_Hosp_Phone1        tpa_hosp_info.off_phone_no_1%TYPE;
    v_Office_Fax1        tpa_hosp_info.office_fax_no%TYPE;
    v_Ins_Email1         tpa_ins_info.email_id%TYPE;
    v_toll_free_no1      tpa_office_info.toll_free_no%TYPE;
    v_clm_seq_id         clm_authorization_details.claim_seq_id%TYPE;
    v_mem_email          tpa_enr_mem_address.email_id%TYPE;
    v_ins_email          tpa_hosp_info.primary_email_id%TYPE;
    v_hosp_email         tpa_hosp_info.primary_email_id%TYPE;
    v_email_id           tpa_user_contacts.primary_email_id%TYPE;
    v_set_num            clm_authorization_details.settlement_number%type;
    v_auth_num           pat_authorization_details.auth_number%type;
    v_req_amt            clm_authorization_details.requested_amount%TYPE;
    v_toll_free_num      VARCHAR2(100);
    v_toll_free_email    VARCHAR2(100);
    v_prov_name          VARCHAR2(250);
    v_policy_holder      VARCHAR2(250);
    v_claim_details      CLOB;--VARCHAR2(32000);
    v_hospit_name        VARCHAR2(1000);
    v_benefit_type       VARCHAR2(50);
    v_invoice            clm_authorization_details.Invoice_Number%TYPE;
    v_speed_recovery     VARCHAR2(250);
    v_mem_id             VARCHAR2(30);
    -- Get the URL Name
    CURSOR cr_get_URL_Name(v_user_type tpa_user_contacts.user_general_type_id%TYPE) IS
      SELECT CASE
               WHEN v_user_type IN ('TTK', 'DMC', 'CAL') THEN
                APPLICATION_URL
               ELSE
                WEB_LOGIN_URL
             END AS APPLICATION_URL
        FROM TPA_SYSTEM_PARAMETERS;
  
    -- Get other core message info
    CURSOR cr_get_core_mesg_dtl(v_message_type_id VARCHAR2) IS
      SELECT module_name,
             msg_sent_from,
             message_title,
             send_as_email_yn,
             send_as_sms_yn,
             send_as_fax_yn,
             prm_rcpt_email_list,
             sec_rcpt_email_list,
             mail_cat_general_type_id,
             customization_allowed_yn
      
        FROM APP.SOURCE_MESSAGE A
       WHERE msg_id = v_message_type_id;
  
    -- NEW_USERID
    CURSOR cr_get_user_info(v_contact_seq_id NUMBER,
                            v_contact_type   VARCHAR2) IS
    
      SELECT b.contact_name,
             ttk_util_pkg.fn_decrypt(a.user_id) user_id,
             ttk_util_pkg.fn_decrypt(a.password) pwd,
             ttk_util_pkg.fn_decrypt(b.primary_email_id) as primary_email_id, --//ED
             ttk_util_pkg.fn_decrypt(b.SECONDARY_EMAIL_ID) as secondary_email_id,
             ttk_util_pkg.fn_decrypt(c.email_id) as corp_email,
             ttk_util_pkg.fn_decrypt(e.email_id) as bro_eamil,
             ttk_util_pkg.fn_decrypt(gr.hr_email_id) as hr_mail,
             ttk_util_pkg.fn_decrypt(f.primary_email_id) as prov_mail, --hops
             ttk_util_pkg.fn_decrypt(g.primary_email_id) as part_mail, --part   newly added
             nvl(b.off_phone_no_1, b.off_phone_no_2) as tollfree_num,
             b.user_general_type_id,
             d.ins_comp_code_number as comp_code,
             e.ins_comp_code_number as bro_code,
             ttk_util_pkg.fn_decrypt(d.email_id) as ins_email,
             CASE b.user_general_type_id
               WHEN 'TTK' THEN
                ''
               WHEN 'COR' THEN
                c.group_id
               WHEN 'INS' THEN
                d.ins_comp_code_number
               WHEN 'BRO' THEN
                e.ins_comp_code_number
               WHEN 'HOS' THEN
                TO_CHAR(f.empanel_number)
               WHEN 'PTR' THEN                  --newly added
			          TO_CHAR(g.empanel_number)       
             END AS group_id,
             b.mobile_no,
             b.off_phone_no_1,
             b.off_phone_no_2
        FROM tpa_login_info a
        JOIN tpa_user_contacts b
          ON a.contact_seq_id = b.contact_seq_id
        LEFT OUTER JOIN tpa_group_registration c
          ON b.group_reg_seq_id = c.group_reg_seq_id
        LEFT OUTER JOIN tpa_ins_info d
          ON b.ins_seq_id = d.ins_seq_id
        LEFT JOIN tpa_bro_info e
          --ON (e.ins_comp_code_number = d.ins_comp_code_number)
          ON (e.ins_seq_id = b.ins_seq_id)
        LEFT JOIN tpa_hosp_info f
          ON (f.hosp_seq_id = b.hosp_seq_id)
        LEFT JOIN tpa_partner_info g    ------------------------NEWLY added
		      ON (g.ptnr_seq_id=b.ptnr_seq_id)
        LEFT JOIN tpa_group_registration gr
          ON (gr.group_reg_seq_id = b.group_reg_seq_id)
       WHERE b.contact_seq_id = v_contact_seq_id;
  
    
  
    cr_get_user_info_rec cr_get_user_info%ROWTYPE;
    
    
    CURSOR toll_free_cur IS
      SELECT o.tpa_office_seq_id, o.toll_free_no, o.email_id
      FROM tpa_office_info o
      WHERE o.tpa_office_seq_id = 1;
      
    toll_free_rec         toll_free_cur%ROWTYPE;
    --Alternative Mail Address
    CURSOR sec_email_cur (v_contact_seq_id NUMBER) IS
      SELECT ttk_util_pkg.fn_decrypt(c.secondary_email_id) as secn_mail_id
      FROM Tpa_User_Contacts c
      WHERE c.contact_seq_id = v_contact_seq_id;
    
    v_sec_email_cur sec_email_cur%ROWTYPE;
    
    -- To get the Type of Pre-auth
    CURSOR cr_get_typeof_preauth(v_pat_gen_detail_seq_id pat_general_details.pat_gen_detail_seq_id%TYPE) IS
      SELECT CASE pat_general_details.pat_general_type_id
               WHEN 'MRG' THEN
                'REG'
               ELSE
                pat_general_details.pat_general_type_id
             END AS pat_general_type_id
        FROM pat_general_details
       WHERE pat_general_details.pat_gen_detail_seq_id =
             v_pat_gen_detail_seq_id;
  
    -- Get Hospital Information
    CURSOR cr_get_hospital_info(v_hosp_seq_id tpa_hosp_info.hosp_seq_id%TYPE) IS
      SELECT tpa_hosp_info.office_fax_no,
             tpa_hosp_info.hosp_name || ', ' ||
             tpa_city_code.city_description as hosp_name
        FROM tpa_hosp_address, tpa_hosp_info, tpa_city_code
       WHERE (tpa_hosp_info.hosp_seq_id = tpa_hosp_address.hosp_seq_id)
         and (tpa_city_code.city_type_id = tpa_hosp_address.city_type_id)
         and (tpa_hosp_info.hosp_seq_id = v_hosp_seq_id);
  
    -- To get the Type of Pre-auth for Shortfall
    CURSOR cr_get_typeof_preauth_shtfall(v_shtfall_seq_id shortfall_details.shortfall_seq_id%TYPE) IS
      SELECT CASE pat_general_details.pat_general_type_id
               WHEN 'MRG' THEN
                'REG'
               ELSE
                pat_general_details.pat_general_type_id
             END AS pat_general_type_id
        FROM pat_general_details, shortfall_details
       WHERE pat_general_details.pat_gen_detail_seq_id =
             shortfall_details.pat_gen_detail_seq_id
         and shortfall_details.shortfall_seq_id = v_shtfall_seq_id;
  
    -- PRE-Auth REGULAR
    CURSOR cr_get_regular_preauth(v_pat_auth_seq_id pat_authorization_details.pat_auth_seq_id%TYPE) IS
      SELECT a.mem_name,
             a.pat_received_date,
             a.pre_auth_number,
             b.description,
             ttk_util_pkg.fn_decrypt(ma.mobile_no) as mobile_no,
             a.requested_amount,
             a.tot_approved_amount,
             a.policy_seq_id,
             a.member_seq_id,
             a.auth_number,
             a.hosp_seq_id,
             ttk_util_pkg.fn_decrypt(ma.email_id) as email_id,
             e.INSURED_NAME,
             d.TPA_ENROLLMENT_ID,
             a.pat_status_type_id,
             a.remarks,
             f.HOSP_NAME
      
        FROM pat_authorization_details a
        join tpa_general_code b
          on (a.pat_status_type_id = b.general_type_id)
        join tpa_enr_policy_member d
          on (d.member_seq_id = a.member_seq_id)
        join tpa_enr_mem_address ma
          on (ma.enr_address_seq_id = d.enr_address_seq_id)
        join tpa_enr_policy_group e
          on (e.policy_group_seq_id = d.policy_group_seq_id)
        left outer join TPA_HOSP_INFO f
          on (f.hosp_seq_id = a.hosp_seq_id)
       WHERE a.pat_auth_seq_id = v_pat_auth_seq_id;
  
    -- PRE-Auth Manual
    CURSOR cr_get_manual_preauth(v_pat_gen_detail_seq_id pat_general_details.pat_gen_detail_seq_id%TYPE) IS
      SELECT pat_enroll_details.claimant_name,
             pat_general_details.pat_received_date,
             pat_enroll_details.pre_auth_number,
             tpa_general_code.description,
             pat_general_details.ph_no_catagory, --Added by chiranjibi
             pat_general_details.phone_no_in_hospitalisation,
             pat_general_details.pat_requested_amount,
             ttk_util_pkg.fn_decrypt(pat_enroll_details.email_id) as email_id,
             ttk_util_pkg.fn_decrypt(tpa_hosp_info.primary_email_id) primary_email_id, --Added by chiranjibi
             pat_general_details.total_app_amount,
             tpa_office_info.office_code,
             tpa_office_info.toll_free_no,
             pat_enroll_details.auth_number,
             pat_enroll_details.hosp_seq_id,
             pat_general_details.likely_date_of_hospitalization
        FROM pat_enroll_details,
             pat_general_details,
             tpa_general_code,
             tpa_office_info,
             tpa_hosp_info
       WHERE (pat_enroll_details.tpa_office_seq_id =
             tpa_office_info.tpa_office_seq_id)
         and (tpa_general_code.general_type_id =
             pat_enroll_details.pat_status_general_type_id)
         and (pat_general_details.pat_enroll_detail_seq_id =
             pat_enroll_details.pat_enroll_detail_seq_id)
         and (pat_general_details.pat_gen_detail_seq_id =
             v_pat_gen_detail_seq_id);
  
    -- Get Shortfall information for Regular Pre-auth
    CURSOR cr_get_shortfall_regular(v_shortfall_seq_id shortfall_details.SHORTFALL_SEQ_ID%TYPE) IS
      SELECT a.mem_name,
             a.pre_auth_number,
             replace(substr(ttk_util_pkg.fn_decrypt(d.mobile_no), instr(ttk_util_pkg.fn_decrypt(d.mobile_no), '|', 1)), '|', null) as mobile_no,
             b.shortfall_id,
             a.hosp_seq_id,
             a.policy_seq_id,
             a.member_seq_id,
             a.pat_auth_seq_id,
             ttk_util_pkg.fn_decrypt(nvl(d.email_id, d.email_id1)) as email_id, --//ED
             --ttk_util_pkg.fn_decrypt(d.email_id1) as alter_email,
             ttk_util_pkg.fn_decrypt(ii.email_id) toll_free_email,
             ttk_util_pkg.fn_decrypt(tpi.primary_email_id) Hosp_Email,
             ttk_util_pkg.fn_decrypt(tpi.off_phone_no_1) Hosp_Mob,
             f.toll_free_no as toll_free_num,
             c.mem_name as policy_holder,
             c.tpa_enrollment_id,
             a.clinician_mail
      
        FROM tpa_enr_policy_member c
        join tpa_enr_policy_group           g   ON (c.policy_group_seq_id = g.policy_group_seq_id)
        join tpa_enr_mem_address            d   ON (d.enr_address_seq_id = c.enr_address_seq_id)
        join pat_authorization_details      a   ON (a.member_seq_id = c.member_seq_id)
        join shortfall_details              b  ON (b.pat_gen_detail_seq_id = a.pat_auth_seq_id)
        JOIN tpa_ins_info                   ii  ON (ii.ins_seq_id = a.ins_seq_id)
        JOIN tpa_office_info                f   ON (f.tpa_office_seq_id = ii.tpa_office_seq_id)
        LEFT JOIN tpa_hosp_info             tpi ON (tpi.hosp_seq_id = a.hosp_seq_id)
        LEFT JOIN tpa_general_code          gc  ON (gc.general_type_id = a.benifit_type)
        WHERE b.SHORTFALL_SEQ_ID = v_shortfall_seq_id;
    
    v_cr_get_shortfall_regular cr_get_shortfall_regular%ROWTYPE;
    -- Get Shortfall information for Manual Pre-auth
    CURSOR cr_get_shortfall_manual(v_shortfall_seq_id shortfall_details.SHORTFALL_SEQ_ID%TYPE) IS
      SELECT a.mem_name,
             a.pre_auth_number,
             a.auth_number,
             ttk_util_pkg.fn_decrypt(e.mobile_no) as mobile_no,
             ttk_util_pkg.fn_decrypt(e.email_id) as email_id, --//ED
             c.shortfall_id,
             a.hosp_seq_id,
             a.pat_auth_seq_id
        FROM pat_authorization_details a
        join tpa_general_code b
          on (a.pat_status_type_id = b.general_type_id)
        join shortfall_details c
          on (c.pat_gen_detail_seq_id = a.pat_auth_seq_id)
        join tpa_enr_policy_member d
          on (d.member_seq_id = a.member_seq_id)
        join tpa_enr_mem_address e
          on (e.enr_address_seq_id = d.enr_address_seq_id)
       WHERE c.shortfall_seq_id = v_shortfall_seq_id;
  
    --Get VIP Preauth information for preauth intimation OR Escalation
    -------------------------------- ADDED FOR KOC1137
    CURSOR CR_GET_PAT_ITN_ETN(V_PAT_GEN_DETAIL_SEQ_ID PAT_GENERAL_DETAILS.PAT_GEN_DETAIL_SEQ_ID%TYPE) IS
      SELECT PE.CLAIMANT_NAME,
             PE.PRE_AUTH_NUMBER,
             PG.PAT_RECEIVED_DATE,
             PG.ADDED_DATE
        FROM PAT_ENROLL_DETAILS PE, PAT_GENERAL_DETAILS PG
       WHERE PE.PAT_ENROLL_DETAIL_SEQ_ID = PG.PAT_ENROLL_DETAIL_SEQ_ID
         AND PG.PAT_GEN_DETAIL_SEQ_ID = V_PAT_GEN_DETAIL_SEQ_ID;
    REC_GET_PAT_ITN_ETN CR_GET_PAT_ITN_ETN%ROWTYPE;
    --Get VIP CLAIM information for CLAIM Escalation
    CURSOR CR_GET_CLM_ESCALATION(v_claim_seq_id CLM_GENERAL_DETAILS.claim_seq_id%TYPE) IS
      SELECT CE.CLAIMANT_NAME, CE.ADDED_DATE, CG.CLAIM_NUMBER
        FROM CLM_ENROLL_DETAILS CE, CLM_GENERAL_DETAILS CG
       WHERE CE.CLAIM_SEQ_ID = CG.CLAIM_SEQ_ID
         AND CG.CLAIM_SEQ_ID = v_claim_seq_id;
    REC_GET_CLM_ESCALATION CR_GET_CLM_ESCALATION%ROWTYPE;
    --Get CALL BACK information for CALL Escalation
    CURSOR CR_GET_CALL_ESCALATION(V_CALL_LOG_SEQ_ID TPA_CALL_LOG.CALL_LOG_SEQ_ID%TYPE) IS
      SELECT L.CLAIMANT_NAME, L.CALL_RECORDED_DATE, L.CALL_LOG_NUMBER
        FROM TPA_CALL_LOG L
       WHERE L.CALL_LOG_SEQ_ID = V_CALL_LOG_SEQ_ID;
    REC_GET_CALL_ESCALATION CR_GET_CALL_ESCALATION%ROWTYPE;
    --GET CLAIM INWARD DETAILS FOR VIP INTIMATION OR REMINDER
    CURSOR cr_get_clm_inward_vip(v_inward_seq_id clm_inward.claims_inward_seq_id%TYPE) IS
      SELECT clm_enroll_details.claimant_name,
             clm_inward.rcvd_date,
             clm_general_details.added_date,
             clm_general_details.claim_number,
             clm_enroll_details.policy_seq_id,
             clm_enroll_details.member_seq_id,
             clm_general_details.claim_seq_id,
             ttk_util_pkg.fn_decrypt(clm_enroll_details.email_id) as email_id,
             clm_enroll_details.notification_phone_number,
             clm_general_details.requested_amount --//ED
        FROM clm_enroll_details, clm_general_details, clm_inward
       WHERE (clm_general_details.claim_seq_id =
             clm_enroll_details.claim_seq_id)
         and (clm_inward.claims_inward_seq_id =
             clm_general_details.claims_inward_seq_id)
         and (clm_inward.claims_inward_seq_id = v_inward_seq_id);
    vip_added_date date;
  
    --==============================Addded for koc_investigation================================================
    
  
    CURSOR CR_GET_CLM_INVEST(v_claim_seq_id CLM_GENERAL_DETAILS.claim_seq_id%TYPE) IS
      SELECT I.INVESTIGATION_ID,
             CG.CLAIM_NUMBER,
             CE.CLAIMANT_NAME,
             CE.ADDED_DATE,
             TEM.EMAIL_ID As Addr_email_id,
             IA.PRIMARY_EMAIL_ID,
             IA.SECONDARY_EMAIL_ID,
             CE.EMAIL_ID
        FROM INVESTIGATION_DETAILS I
        JOIN CLM_GENERAL_DETAILS CG
          ON (I.CLAIM_SEQ_ID = CG.CLAIM_SEQ_ID)
        JOIN CLM_ENROLL_DETAILS CE
          ON (CE.claim_seq_id = CG.claim_SEQ_ID)
        JOIN TPA_ENR_POLICY_MEMBER TEP
          ON (TEP.MEMBER_SEQ_ID = CE.MEMBER_SEQ_ID)
        LEFT OUTER JOIN TPA_ENR_MEM_ADDRESS TEM
          ON (TEM.ENR_ADDRESS_SEQ_ID = TEP.ENR_ADDRESS_SEQ_ID)
        JOIN investigation_agency_details ia
          on (ia.invest_agncy_seq_id = i.invest_agncy_seq_id)
       WHERE CG.CLAIM_seq_id = v_claim_seq_id; /*1956311*/
    REC_GET_CLM_INVEST CR_GET_CLM_INVEST%ROWTYPE;
  
    -------------------------ADDED THE ABOVE CURSORS  from KOC1137 cr_get_clm_inward_vip,CR_GET_CLM_ESCALATION,CR_GET_PAT_ITN_ETN) FOR CR KOC1137
    --ADDED FOR BELOW CURSOR FOR CR KOC1105
    CURSOR cr_computation(v_payment_seq_id TPA_CLAIMS_PAYMENT.PAYMENT_SEQ_ID%Type) is
      SELECT cg.claim_seq_id,
             ce.policy_seq_id,
             cg.claim_number,
             ce.claimant_name,
             pg.insured_name,
             cc.check_num,
             cc.check_date,
             ce.tpa_enrollment_id,
             ce.policy_number,
             cg.claim_file_number,
             cp.claim_settlement_no,
             cc.check_amount,
             (tds.approved_amount - tds.check_amount) tds_amount,
             cp.approved_amount,
             cp.emp_acct_number,
             ttk_util_pkg.fn_decrypt(CASE
                                       WHEN cp.claim_type = 'CNH' THEN
                                        hi.primary_email_id
                                       ELSE
                                        (CASE
                                          WHEN pe.enrol_type_id = 'COR' THEN
                                           (CASE
                                             WHEN pe.tpa_cheque_issued_general_type = 'IQI' THEN
                                              ema.email_id
                                             ELSE
                                              gr.notify_email_id
                                           END)
                                          ELSE
                                           ema.email_id
                                        END)
                                     END) AS EMAIL_ID,
             --koc 1216 v1 mail template
             IC.INS_COMP_NAME,
             PG.EMPLOYEE_NO,
             CG.DATE_OF_ADMISSION,
             CG.DATE_OF_DISCHARGE,
             HI.HOSP_NAME,
             HA.ADDRESS_1,
             CA.CITY_DESCRIPTION,
             AD.AILMENT_DESCRIPTION,
             ttk_util_pkg.fn_decrypt(CP.PAYEE_NAME) "PAYEE_NAME"
      
        FROM app.clm_general_details cg
        JOIN app.clm_enroll_details ce
          ON (cg.claim_seq_id = ce.claim_seq_id)
        JOIN app.tpa_claims_payment cp
          ON (CE.claim_seq_id = CP.claim_seq_id)
        JOIN app.tpa_payment_checks_details tp
          ON (cp.payment_seq_id = tp.payment_seq_id)
        JOIN fin_app.tpa_claims_check cc
          ON (tp.claims_chk_seq_id = cc.claims_chk_seq_id)
        JOIN app.tpa_enr_policy_member pm
          ON (pm.member_seq_id = ce.member_seq_id)
        LEFT OUTER JOIN app.tpa_enr_policy_group pg
          ON (pm.policy_group_seq_id = pg.policy_group_seq_id)
        LEFT OUTER JOIN APP.tpa_enr_policy pe
          on (ce.policy_seq_id = pe.policy_seq_id)
        LEFT OUTER JOIN app.tpa_group_registration gr
          ON (pe.group_reg_seq_id = gr.group_reg_seq_id)
        LEFT OUTER JOIN app.tpa_enr_mem_address ema
          ON (pg.enr_address_seq_id = ema.enr_address_seq_id)
        LEFT OUTER JOIN app.tpa_clm_tds_details tds
          ON (tp.payment_seq_id = tds.payment_seq_id)
        LEFT OUTER JOIN app.clm_hospital_association ch
          ON (cg.claim_seq_id = ch.claim_seq_id)
        LEFT OUTER JOIN app.tpa_hosp_info hi
          ON (ch.hosp_seq_id = hi.hosp_seq_id)
      --koc 1216 v1 mail template
        JOIN APP.AILMENT_DETAILS AD
          ON (CG.CLAIM_SEQ_ID = AD.CLAIM_SEQ_ID)
        LEFT OUTER JOIN APP.TPA_HOSP_ADDRESS HA
          ON (HI.HOSP_SEQ_ID = HA.HOSP_SEQ_ID)
        LEFT OUTER JOIN APP.TPA_CITY_CODE CA
          ON (HA.CITY_TYPE_ID = CA.CITY_TYPE_ID)
        LEFT OUTER JOIN APP.TPA_INS_INFO IC
          ON (CE.INS_SEQ_ID = IC.INS_SEQ_ID)
       WHERE check_status IN ('CSI', 'CSC')
         AND cp.payment_seq_id = v_payment_seq_id;
    rec_computation cr_computation%rowtype;
    ------------------------------------------------ADDED FOR COMPUTATION
    
    CURSOR cr_get_claims_inward(v_inward_seq_id clm_authorization_details.claim_seq_id%TYPE) IS
      SELECT rownum,
             clm.currency_type,
             cb.batch_no,
             NVL(clm.final_app_amount, 0) appr_amt,
             --NVL(clm.tot_disc_gross_amount, 0) req_amt,
             nvl(clm.requested_amount, 0) req_amt,
             nvl((clm.tot_disc_gross_amount - clm.tot_approved_amount), 0) disallowed_amount,
             clm.claim_seq_id clm_seq_id,
             clm.mem_name,
             clm.clm_received_date clm_rec_date,
             clm.claim_number clm_num,
             clm.settlement_number set_num,
             g.description benifit_type,
             --tep.policy_number,
             teg.tpa_enrollment_id,
             clm.member_seq_id mem_seq_id,
             clm.policy_seq_id,
             clm.invoice_number,
             nvl(thi.hosp_name, ch.hosp_name) as hosp_name,
             replace(substr(ttk_util_pkg.fn_decrypt(tem.mobile_no), instr(ttk_util_pkg.fn_decrypt(tem.mobile_no), '|', 1)), '|', null) as mem_mobile_no,
             ttk_util_pkg.fn_decrypt (nvl(tem.email_id, tem.email_id1)) member_mail,
             --ttk_util_pkg.fn_decrypt(tem.email_id1) as alter_mail,
             ttk_util_pkg.fn_decrypt(tii.email_id) ins_mail,
             ttk_util_pkg.fn_decrypt(thi.primary_email_id) hosp_mail,
             ttk_util_pkg.fn_decrypt(b.email_id) bro_mail,
             ttk_util_pkg.fn_decrypt(th.email_id) corp_emial,
             ttk_util_pkg.fn_decrypt(f.email_id) as toll_free_email,
             f.toll_free_no,
             clm.req_amt_currency_type
             
      
        FROM tpa_enr_policy_member teg
        JOIN tpa_enr_policy_group            gr on (teg.policy_group_seq_id = gr.policy_group_seq_id)
        JOIN tpa_enr_mem_address            tem on (tem.enr_address_seq_id = teg.enr_address_seq_id)
        JOIN clm_authorization_details      clm on (clm.member_seq_id = teg.member_seq_id)
        JOIN clm_batch_upload_details       cb ON (clm.clm_batch_seq_id = cb.clm_batch_seq_id)
        JOIN tpa_ins_info                   tii ON (tii.ins_seq_id = clm.ins_seq_id)
        JOIN tpa_office_info                f ON (f.tpa_office_seq_id = tii.tpa_office_seq_id)
        LEFT JOIN clm_hospital_details      ch  ON (ch.claim_seq_id = clm.claim_seq_id)
        LEFT JOIN tpa_hosp_info             thi ON (thi.hosp_seq_id = ch.hosp_seq_id)
        LEFT JOIN tpa_bro_info b            ON (b.ins_seq_id = tii.ins_seq_id)
        LEFT JOIN tpa_group_registration th ON (th.group_reg_seq_id = gr.group_reg_seq_id)
        LEFT JOIN tpa_general_code       g  ON (g.general_type_id = clm.benifit_type)
        WHERE clm.claim_seq_id = v_inward_seq_id;
        
     v_corp_emial                   VARCHAR2(100); -- Corporate Mail
     v_rownum                       NUMBER;
     v_batchno                      VARCHAR2(100);
     v_mem_mobile_no                VARCHAR2(30);
     v_currency                     VARCHAR2(5);
     v_disallowed_amount            NUMBER(10, 2);
     v_utr_no                       VARCHAR2(30);
    rec_get_claims_inward cr_get_claims_inward%ROWTYPE;
    -- Generate message for Claims Status
    CURSOR cr_get_claims_status(v_seq_id clm_general_details.claim_seq_id%TYPE) IS
      SELECT clm_enroll_details.claimant_name,
             clm_inward.rcvd_date,
             clm_general_details.claim_number,
             tpa_general_code.description,
             clm_enroll_details.notification_phone_number,
             clm_general_details.requested_amount,
             clm_general_details.total_app_amount,
             clm_enroll_details.policy_seq_id,
             clm_enroll_details.member_seq_id,
             clm_hospital_association.hosp_seq_id,
             clm_general_details.claim_settlement_number,
             ttk_util_pkg.fn_decrypt(clm_enroll_details.email_id) email_id,
             --koc 1216 v1 mail template
             CLM_GENERAL_DETAILS.CLAIM_FILE_NUMBER,
             TPA_ENR_POLICY_GROUP.INSURED_NAME,
             TPA_ENR_POLICY_MEMBER.TPA_ENROLLMENT_ID,
             clm_general_details.DATE_OF_ADMISSION,
             PAT_ENROLL_DETAILS.AUTH_NUMBER,
             PAT_ENROLL_DETAILS.PRE_AUTH_NUMBER,
             CLM_ENROLL_DETAILS.POLICY_NUMBER
      
        FROM clm_inward,
             clm_enroll_details,
             clm_general_details,
             tpa_general_code,
             clm_hospital_association,
             --koc 1216 v1 mail template
             TPA_ENR_POLICY_MEMBER,
             TPA_ENR_POLICY_GROUP,
             PAT_ENROLL_DETAILS
       WHERE (clm_general_details.claim_seq_id =
             clm_hospital_association.claim_seq_id(+))
         AND (tpa_general_code.general_type_id =
             clm_enroll_details.clm_status_general_type_id)
         and (clm_general_details.claims_inward_seq_id =
             clm_inward.claims_inward_seq_id)
         and (clm_general_details.claim_seq_id =
             clm_enroll_details.claim_seq_id)
         and
            --koc 1216 v1 mail template
             (CLM_ENROLL_DETAILS.MEMBER_SEQ_ID =
             TPA_ENR_POLICY_MEMBER.MEMBER_SEQ_ID)
         AND (TPA_ENR_POLICY_MEMBER.POLICY_GROUP_SEQ_ID =
             TPA_ENR_POLICY_GROUP.POLICY_GROUP_SEQ_ID)
         AND (CLM_GENERAL_DETAILS.PAT_ENROLL_DETAIL_SEQ_ID =
             PAT_ENROLL_DETAILS.PAT_ENROLL_DETAIL_SEQ_ID(+))
         AND (clm_general_details.claim_seq_id = v_seq_id);
  
    CURSOR cr_get_claim_shortfall_regular(v_shortfall_seq_id shortfall_details.SHORTFALL_SEQ_ID%TYPE) IS
      SELECT clm.MEM_NAME,
             clm.Claim_Number,
             bat.batch_no,
             sd.shortfall_id,
             ttk_util_pkg.fn_decrypt(nvl(tem.email_id, tem.email_id1)) Mem_Email,
             --ttk_util_pkg.fn_decrypt(nvl(tem.mobile_no, tem.res_phone_no)) as mem_mobile_no,
             ttk_util_pkg.fn_decrypt(thi.primary_email_id) as hosp_email,
             replace(substr(ttk_util_pkg.fn_decrypt(tem.mobile_no), instr(ttk_util_pkg.fn_decrypt(tem.mobile_no), '|', 1)), '|', null) Mem_Mob,
             ttk_util_pkg.fn_decrypt(nvl(thi.off_phone_no_1,thi.off_phone_no_2)) as hosp_phone,
             ttk_util_pkg.fn_decrypt(tii.email_id) Ins_Email,
             off.toll_free_no,
             m.tpa_enrollment_id,
             ttk_util_pkg.fn_decrypt(off.email_id) Toll_Free_Email
      
      from tpa_enr_policy_member m 
      join tpa_enr_policy_group           g on (m.policy_group_seq_id = g.policy_group_seq_id)
      join tpa_enr_mem_address            tem on (tem.enr_address_seq_id = m.enr_address_seq_id)
      join clm_authorization_details      clm on (clm.member_seq_id = m.member_seq_id)
      LEFT JOIN Shortfall_Details         sd  ON (clm.claim_seq_id = sd.claim_seq_id)
      join clm_batch_upload_details       bat ON (clm.clm_batch_seq_id = bat.clm_batch_seq_id)
      JOIN tpa_ins_info                   tii ON (tii.ins_seq_id = clm.ins_seq_id)
      JOIN tpa_office_info                off ON (off.tpa_office_seq_id = tii.tpa_office_seq_id)
      LEFT JOIN clm_hospital_details      ch  ON (ch.claim_seq_id = clm.claim_seq_id)
      LEFT JOIN tpa_hosp_info             thi ON (thi.hosp_seq_id = ch.hosp_seq_id)
      WHERE sd.shortfall_seq_id = v_shortfall_seq_id;
        --AND sd.srtfll_status_general_type_id = 'OPN';
    
    
    -- Generate message for E-Claims Status
    CURSOR eclaim_cur (v_batch_seq_id Clm_Authorization_Details.Invoice_Number%TYPE) IS
      SELECT rownum,
             cb.batch_no,
             cl.claim_number,
             cl.tpa_enrollment_id,
             cl.mem_name,
             g.description as benifit_type,
             cl.invoice_number,
             cl.requested_amount,
             cl.clm_received_date,
             ch.hosp_name,
             ttk_util_pkg.fn_decrypt(t.primary_email_id) as hosp_mail,
             nvl(f.email_id, i.email_id) as tolfree_email,
             f.toll_free_no
             
             
      FROM Clm_Authorization_Details cl
      JOIN Clm_Batch_Upload_Details cb on (cb.clm_batch_seq_id = cl.clm_batch_seq_id)
      JOIN Clm_Hospital_Details ch on (ch.claim_seq_id = cl.claim_seq_id)
      JOIN Tpa_Hosp_Info t      on (t.hosp_seq_id = ch.hosp_seq_id)
      JOIN Tpa_Ins_Info i       on (i.ins_seq_id = cl.ins_seq_id)
      JOIN Tpa_Office_Info f    on (f.tpa_office_seq_id = i.tpa_office_seq_id)
      JOIN Tpa_General_Code g ON (g.general_type_id = cl.benifit_type)
      WHERE Cl.Clm_Batch_Seq_Id = v_batch_seq_id;
    
    eclaim_rec eclaim_cur%ROWTYPE;
    
    -- This query is used for generating the Mails for ECARD GENERATION based on policy group seq id.
    CURSOR cr_get_employee_enroll_nmbr(v_policy_group_seq_id TPA_ENR_POLICY_GROUP.POLICY_GROUP_SEQ_ID%TYPE) IS
      SELECT tpa_enr_policy_group.tpa_enrollment_number,
             tpa_enr_policy_group.employee_no,
             ttk_util_pkg.fn_decrypt(tpa_enr_mem_address.email_id) as email_id, --//ED
             tpa_enr_policy_group.insured_name
        FROM tpa_enr_mem_address, tpa_enr_policy_group
       WHERE (tpa_enr_policy_group.enr_address_seq_id =
             tpa_enr_mem_address.enr_address_seq_id)
         and (tpa_enr_policy_group.policy_group_seq_id =
             v_policy_group_seq_id);
  
    cr_get_REC cr_get_employee_enroll_nmbr%ROWTYPE;
  
    -- This query is used for generating the Mails for NEW EMPLOYEE ENROLLMENT based on policy group seq id.
    CURSOR cr_get_employee_Info(v_policy_group_seq_id TPA_ENR_POLICY_GROUP.POLICY_GROUP_SEQ_ID%TYPE) IS
      SELECT pg.insured_name,
             pg.employee_no,
             ttk_util_pkg.fn_get_emp_password(v_policy_group_seq_id) password,
             ep.policy_number,
             gr.group_id,
             (ttk_util_pkg.fn_decrypt(ma.email_id) || ',' ||
             gr.hr_email_id) as email_id, --//ED
             ep.policy_seq_id,
             NVL(family_tot_sum_insured, 0) family_tot_sum_insured,
             floater_sum_insured,
             floater_premium,
             mail_general_type_id, -- get the flag value whether the Sum insured to be shown or not
             policy_sub_general_type_id,
             pg.policy_group_seq_id,
             tpa_enrollment_number,
             TO_CHAR(m.date_of_inception, 'DD-MON-YYYY') date_of_inception,
             TO_CHAR(m.date_of_exit, 'DD-MON-YYYY') date_of_exit,
             g.description AS gender
        FROM tpa_enr_mem_address ma 
             JOIN tpa_enr_policy_group pg ON (pg.enr_address_seq_id = ma.enr_address_seq_id)
             JOIN tpa_enr_policy ep ON (pg.policy_seq_id = ep.policy_seq_id)
             JOIN tpa_group_registration gr ON (gr.group_reg_seq_id = ep.group_reg_seq_id)
             JOIN weblogin_config wb ON (ep.policy_seq_id=wb.policy_seq_id)
             LEFT OUTER JOIN tpa_enr_policy_member m ON (pg.policy_group_seq_id=m.policy_group_seq_id 
                                                         AND m.relship_type_id = 'NSF' 
                                                         AND m.status_general_type_id != 'POC' AND m.deleted_yn != 'Y'
                                                         )
             LEFT OUTER JOIN tpa_general_code g ON (m.gender_general_type_id=g.general_type_id)
       WHERE pg.policy_group_seq_id = v_policy_group_seq_id
             ;
  
    cr_get_employee_REC cr_get_employee_Info%ROWTYPE;
  
    -- This query is used for sending the Mails for EMPLOYEE Forgot Password ENROLLMENT based on policy group seq id.
    CURSOR cr_get_emp_forgot_passwordInfo(v_policy_group_seq_id TPA_ENR_POLICY_GROUP.POLICY_GROUP_SEQ_ID%TYPE) IS
      SELECT a.employee_user_id,
             a.tpa_enrollment_number,
             a.employee_no,
             ttk_util_pkg.fn_decrypt(b.email_id) as email_id, --//ED
             a.insured_name,
             ttk_util_pkg.fn_get_emp_password(v_policy_group_seq_id) AS password,
             c.policy_number,
             d.group_id,
             c.policy_seq_id,
             m.tpa_enrollment_id,
             a.policy_group_seq_id,
             m.relship_type_id
        FROM tpa_enr_policy_group a
        LEFT OUTER JOIN tpa_enr_mem_address B
          ON (a.enr_address_seq_id = b.enr_address_seq_id)
        JOIN tpa_enr_policy C
          ON (a.policy_seq_id = c.policy_seq_id)
        JOIN tpa_group_registration D
          ON (c.group_reg_seq_id = d.group_reg_seq_id)
        JOIN app.tpa_enr_policy_member m on( m.policy_group_seq_id=a.policy_group_seq_id)
       WHERE a.policy_group_seq_id = v_policy_group_seq_id and m.relship_type_id='NSF';
  
    cr_get_emp_forgot_password_REC cr_get_emp_forgot_passwordInfo%ROWTYPE;
  
    -- This query is used for getting any additional Notification details planned for the Corporate Policy.
    -- This is only considered for NEW EMPLOYEE INFO GENERATION.
    CURSOR cr_get_policy_notify(v_policy_seq_id_id tpa_enr_policy.policy_seq_id %Type) IS
      SELECT A.NOTIFICATION_DETAILS
        FROM WEBLOGIN_CONFIG A
       WHERE POLICY_SEQ_ID = v_policy_seq_id_id;
  
    cr_get_policy_notify_REC cr_get_policy_notify%ROWTYPE;
  
    -- At the end of Window Period or after Modification Time period, a mail has to be sent.
    -- This cursor will get the Employee Information.
    --******************************************************************************************************************
    CURSOR cr_get_employee_details(v_sendmail_seq_id TPA_ENR_POLICY_GROUP.POLICY_GROUP_SEQ_ID%TYPE) IS
    --sch_emp_info_sendmail.sendmail_seq_id%TYPE ) IS
      SELECT b.policy_number,
             a.tpa_enrollment_number,
             m.tpa_enrollment_id,
             a.employee_no,
             a.insured_name,
             ttk_util_pkg.fn_decrypt(c.email_id) as email_id, --//ED
             ttk_util_pkg.fn_decrypt(tii.email_id) as ins_email,
             NVL(a.family_tot_sum_insured, 0) family_tot_sum_insured,
             a.floater_sum_insured,
             a.floater_premium,
             d.policy_group_seq_id,
             d.include_sum_general_type_id, -- get the flag value whether the Sum insured to be shown or not
             b.policy_sub_general_type_id, -- get the type of Policy - Floater/Non-Floater
             TO_CHAR(m.date_of_inception, 'DD/MM/YYYY') date_of_inception,
             TO_CHAR(m.date_of_exit, 'DD/MM/YYYY') date_of_exit,
             TO_CHAR(m.Mem_Dob, 'DD/MM/YYYY') date_of_birth,
             TO_CHAR(b.effective_from_date, 'DD/MM/YYYY') effective_from_date,
             TO_CHAR(b.effective_to_date, 'DD/MM/YYYY') effective_to_date,
             g.description AS gender,
             REPLACE(intx.ttk_util_pkg.fn_decrypt(c.mobile_no),'|') as mobile_no,
             b.pol_tob_doc,
             b.policy_seq_id
        FROM tpa_enr_policy_group a
        JOIN tpa_enr_policy b
          ON (a.policy_seq_id = b.policy_seq_id)
        JOIN tpa_enr_mem_address c
          ON (a.enr_address_seq_id = c.enr_address_seq_id)
        JOIN sch_emp_info_sendmail d
          ON (d.policy_group_seq_id = a.policy_group_seq_id)
        JOIN tpa_ins_info tii
          ON (tii.ins_seq_id = b.ins_seq_id)
        LEFT OUTER JOIN tpa_enr_policy_member m ON (a.policy_group_seq_id=m.policy_group_seq_id 
                                                         AND m.relship_type_id = 'NSF' 
                                                         AND m.status_general_type_id != 'POC' AND m.deleted_yn != 'Y'
                                                         )
        LEFT OUTER JOIN tpa_general_code g ON (m.gender_general_type_id=g.general_type_id)  
       WHERE a.policy_group_seq_id = v_sendmail_seq_id;
    
  
    cr_get_employee_cred_REC cr_get_employee_details%ROWTYPE;
  
    CURSOR cr_get_employee_member_details(v_policy_group_seq_id TPA_ENR_POLICY_GROUP.POLICY_GROUP_SEQ_ID%TYPE) IS
      SELECT a.tpa_enrollment_id,
             a.mem_name,
             d.relship_description,
             TO_CHAR(a.date_of_inception, 'DD-MON-YYYY') date_of_inception,
             TO_CHAR(a.date_of_exit, 'DD-MON-YYYY') date_of_exit,
             TO_CHAR(a.mem_dob, 'DD/MM/YYYY') date_of_birth,
             a.status_general_type_id,
             CASE
               WHEN a.mem_general_type_id != 'PFL' THEN
                a.mem_tot_sum_insured
               ELSE
                NULL
             END AS member_sum_insured,
             CASE
               WHEN a.mem_general_type_id != 'PFL' THEN
                a.mem_total_premium
               ELSE
                NULL
             END AS member_premium,
             g.description as gender
        FROM tpa_enr_policy_member a
        JOIN tpa_relationship_code d
          ON (d.relship_type_id = a.relship_type_id)
        JOIN tpa_general_code g ON (a.gender_general_type_id = g.general_type_id)  
       WHERE a.policy_group_seq_id = v_policy_group_seq_id
         and a.deleted_yn = 'N'
       ORDER BY a.tpa_enrollment_id;

-----************************NEWLY ADDED FOR HR LOGIN***************------------------
---------******ADDITION****
CURSOR  cr_get_hr_mem_add_details(v_policy_group_seq_id TPA_ENR_POLICY_GROUP.POLICY_GROUP_SEQ_ID%TYPE,
                                 v_member_seq_id       tpa_enr_policy_member.member_Seq_id%type)  
is
 SELECT      a.mem_name,
             d.group_name,
             c.policy_number,
             TO_CHAR(c.effective_from_date,'DD/MM/YYYY') effective_from_date ,
             TO_CHAR(c.effective_to_date,'DD/MM/YYYY')  effective_to_date,
             a.tpa_enrollment_id,
             f.relship_description,
            TO_CHAR(a.date_of_inception, 'DD/MM/YYYY') date_of_inception,
            TO_CHAR(a.date_of_exit, 'DD/MM/YYYY') date_of_exit,
            CASE WHEN a.gender_general_type_id = 'MAL' THEN  'Male'
                 WHEN a.gender_general_type_id = 'FEM' THEN 'Female'
                 ELSE
                     'Not Disclosed'  END   gender,
             TO_CHAR(a.mem_dob, 'DD/MM/YYYY') date_of_birth,
             e.description,
             CASE WHEN A.marital_status_id = 'SNG' THEN 'Single'
                  WHEN A.marital_status_id = 'MRD' THEN 'Married'
                  END AS marital_status,
             a.emirate_id ,
             a.passport_number,
           (select intx.ttk_util_pkg.fn_decrypt(y.primary_email_id)
             from  tpa_user_contacts y 
             where y.contact_seq_id = a.added_by and y.user_general_type_id = 'COR') AS email_id,-----newly changed(mail trig to hr)
            INTX.ttk_util_pkg.fn_decrypt(g.email_id) AS email_id1,-----EMPLOYEE EMAIL ID
           ---- INTX.ttk_util_pkg.fn_decrypt(g.mobile_no) as mobile_no,
             g.off_phone_no_1 as mobile_no,
            (select user_id from app.tpa_login_info where contact_seq_id = a.added_by) as added_by,
            (select contact_name from app.tpa_user_contacts where contact_seq_id = a.added_by) as user_name,
            TO_CHAR(SYSDATE,'DD/MM/YYYY') added_date

        FROM tpa_enr_policy_member a
        LEFT OUTER JOIN tpa_enr_policy_group b ON (b.policy_group_seq_id = a.policy_group_seq_id)
        LEFT OUTER JOIN tpa_enr_policy c ON (b.policy_seq_id = c.policy_seq_id)  
        LEFT OUTER JOIN APP.tpa_group_registration d on (b.group_reg_seq_id = d.group_reg_seq_id)
        LEFT OUTER JOIN APP.tpa_nationalities_code e on (a.nationality_id = e.nationality_id)
        LEFT OUTER JOIN APP.tpa_relationship_code f on (a.relship_type_id = f.relship_type_id)
        LEFT OUTER JOIN APP.tpa_enr_mem_address g on (b.enr_address_seq_id = g.enr_address_seq_id)
       WHERE a.policy_group_seq_id = v_policy_group_seq_id  and  a.member_seq_id = v_member_seq_id
         and a.deleted_yn = 'N'
       ORDER BY a.tpa_enrollment_id;
       
  hr_member_info  cr_get_hr_mem_add_details%rowtype;
  
  str_tab                            ttk_util_pkg.str_table_type;
  
  v_hr_parms           VARCHAR2(1000); 
  
  v_mail_merge         VARCHAR2(1000);
 ------------------------ 
----------*************MEMBER DELETIONN
 CURSOR group_mem_count_cur(v_policy_group_seq_id TPA_ENR_POLICY_GROUP.POLICY_GROUP_SEQ_ID%TYPE)
 IS    
     SELECT COUNT(1)
      FROM APP.TPA_ENR_POLICY_GROUP A
        WHERE A.POLICY_GROUP_SEQ_ID = v_policy_group_seq_id;-----(FOR GROUP OR MEMBER)
        
  rec_count  number;      
        
 ------*********** GROUP INFORMATION FOR DELETE
 CURSOR cr_hr_group_dtls_cur(v_policy_group_seq_id TPA_ENR_POLICY_GROUP.POLICY_GROUP_SEQ_ID%TYPE)
 is
 SELECT      a.mem_name,
             d.group_name,
             c.policy_number,
             TO_CHAR(c.effective_from_date,'DD/MM/YYYY') effective_from_date ,
             TO_CHAR(c.effective_to_date,'DD/MM/YYYY')  effective_to_date,
             a.tpa_enrollment_id,
             f.relship_description,
            TO_CHAR(a.date_of_inception, 'DD/MM/YYYY') date_of_inception,
            TO_CHAR(a.date_of_exit, 'DD/MM/YYYY') date_of_exit,
            CASE WHEN a.gender_general_type_id = 'MAL' THEN  'Male'
                 WHEN a.gender_general_type_id = 'FEM' THEN 'Female'
                 ELSE
                     'Not Disclosed'  END   gender,
             TO_CHAR(a.mem_dob, 'DD/MM/YYYY') date_of_birth,
             e.description,
             a.emirate_id ,
             a.passport_number,
           (select intx.ttk_util_pkg.fn_decrypt(y.primary_email_id)
             from  tpa_user_contacts y 
             where y.contact_seq_id = a.updated_by and y.user_general_type_id = 'COR') AS email_id, ------newly changed(mail trig to hr)
          ---  INTX.ttk_util_pkg.fn_decrypt(g.email_id) AS email_id,
            INTX.ttk_util_pkg.fn_decrypt(g.mobile_no) as mobile_no,
            (select user_id from app.tpa_login_info where contact_seq_id = a.updated_by) as added_by,
            (select contact_name from app.tpa_user_contacts where contact_seq_id = a.updated_by) as user_name,
            TO_CHAR(SYSDATE,'DD/MM/YYYY')  added_date

        FROM tpa_enr_policy_member a
        LEFT OUTER JOIN tpa_enr_policy_group b ON (b.policy_group_seq_id = a.policy_group_seq_id)
        LEFT OUTER JOIN tpa_enr_policy c ON (b.policy_seq_id = c.policy_seq_id)  
        LEFT OUTER JOIN APP.tpa_group_registration d on (b.group_reg_seq_id = d.group_reg_seq_id)
        LEFT OUTER JOIN APP.tpa_nationalities_code e on (a.nationality_id = e.nationality_id)
        LEFT OUTER JOIN APP.tpa_relationship_code f on (a.relship_type_id = f.relship_type_id)
        LEFT OUTER JOIN APP.tpa_enr_mem_address g on (b.enr_address_seq_id = g.enr_address_seq_id)
       WHERE a.policy_group_seq_id = v_policy_group_seq_id  AND a.RELSHIP_TYPE_ID = 'NSF'
       /*  and a.deleted_yn = 'Y'*/
       ORDER BY a.tpa_enrollment_id;
       
    hr_group_dtls   cr_hr_group_dtls_cur%rowtype;
    
    
-------*********FOR MEMBER DELETION 

CURSOR cr_hr_member_dtls_cur(v_policy_group_seq_id TPA_ENR_POLICY_GROUP.POLICY_GROUP_SEQ_ID%TYPE)
 is
 SELECT      a.mem_name,
             d.group_name,
             c.policy_number,
             TO_CHAR(c.effective_from_date,'DD/MM/YYYY') effective_from_date ,
             TO_CHAR(c.effective_to_date,'DD/MM/YYYY')  effective_to_date,
             a.tpa_enrollment_id,
             f.relship_description,
            TO_CHAR(a.date_of_inception, 'DD/MM/YYYY') date_of_inception,
            TO_CHAR(a.date_of_exit, 'DD/MM/YYYY') date_of_exit,
            CASE WHEN a.gender_general_type_id = 'MAL' THEN  'Male'
                 WHEN a.gender_general_type_id = 'FEM' THEN 'Female'
                 ELSE
                     'Not Disclosed'  END   gender,
             TO_CHAR(a.mem_dob, 'DD/MM/YYYY') date_of_birth,
             e.description,
             a.emirate_id ,
             a.passport_number,
             (select intx.ttk_util_pkg.fn_decrypt(y.primary_email_id)
             from  tpa_user_contacts y 
             where y.contact_seq_id = a.updated_by and y.user_general_type_id = 'COR') AS email_id,---newly changed(mail trig to hr)
           ---- INTX.ttk_util_pkg.fn_decrypt(g.email_id) AS email_id,
            INTX.ttk_util_pkg.fn_decrypt(g.mobile_no) as mobile_no,
            (select user_id from app.tpa_login_info where contact_seq_id = a.updated_by) as added_by,
            (select contact_name from app.tpa_user_contacts where contact_seq_id = a.updated_by) as user_name,
            TO_CHAR(SYSDATE,'DD/MM/YYYY') added_date  

        FROM tpa_enr_policy_member a
        LEFT OUTER JOIN tpa_enr_policy_group b ON (b.policy_group_seq_id = a.policy_group_seq_id)
        LEFT OUTER JOIN tpa_enr_policy c ON (b.policy_seq_id = c.policy_seq_id)  
        LEFT OUTER JOIN APP.tpa_group_registration d on (b.group_reg_seq_id = d.group_reg_seq_id)
        LEFT OUTER JOIN APP.tpa_nationalities_code e on (a.nationality_id = e.nationality_id)
        LEFT OUTER JOIN APP.tpa_relationship_code f on (a.relship_type_id = f.relship_type_id)
        LEFT OUTER JOIN APP.tpa_enr_mem_address g on (b.enr_address_seq_id = g.enr_address_seq_id)
       WHERE a.MEMBER_SEQ_ID = v_policy_group_seq_id 
        /* and a.deleted_yn = 'Y'*/
       ORDER BY a.tpa_enrollment_id;
       
    hr_member_dtls   cr_hr_member_dtls_cur%rowtype;
    

 ------*********** MEMBER INFORMATION FOR DELETE
 
----- NEWLY ADDED FOR GROUP INFORMATION    
  CURSOR cr_get_hr_mem_del_details(v_policy_group_seq_id TPA_ENR_POLICY_GROUP.POLICY_GROUP_SEQ_ID%TYPE)
  IS         
    SELECT a.mem_name,
                  a.tpa_enrollment_id,
                 d.relship_description,
                 TO_CHAR( a.date_of_exit , 'DD/MM/YYYY' ) date_of_exit     
             FROM tpa_enr_policy_member a
             JOIN tpa_relationship_code d ON (d.relship_type_id = a.relship_type_id)
            WHERE (a.policy_group_seq_id = v_policy_group_seq_id /*or a.member_seq_id =v_policy_group_seq_id*/) /*and
                  a.deleted_yn = 'Y'*/
          ORDER BY a.tpa_enrollment_id ;
          
     mem_del_dtls  cr_get_hr_mem_del_details%rowtype;
 
 -----NEWLY ADDED FOR MEMBER INFORMATION    
     
  CURSOR cr_get_hr_mem_del1_details(v_policy_group_seq_id TPA_ENR_POLICY_GROUP.POLICY_GROUP_SEQ_ID%TYPE)
  IS         
    SELECT a.mem_name,
                  a.tpa_enrollment_id,
                 d.relship_description,
                 TO_CHAR( a.date_of_exit , 'DD/MM/YYYY' ) date_of_exit     
             FROM tpa_enr_policy_member a
             JOIN tpa_relationship_code d ON (d.relship_type_id = a.relship_type_id)
            WHERE (/*a.policy_group_seq_id = v_policy_group_seq_id or*/ a.member_seq_id =v_policy_group_seq_id) /*and
                  a.deleted_yn = 'Y'*/
          ORDER BY a.tpa_enrollment_id ;
          
     mem_del_dtls1  cr_get_hr_mem_del1_details%rowtype;
     
   
     v_member_details     CLOB;
     
  
      
----********************************************************************************
    -- This SQL is for Repeated Calls
    CURSOR cr_get_repeated_calllog(v_log_seq_id TPA_CALL_LOG.CALL_LOG_SEQ_ID%TYPE) IS
      SELECT A.CALL_LOG_NUMBER, B.OFFICE_CODE
        FROM TPA_CALL_LOG A, TPA_OFFICE_INFO B, TPA_GENERAL_CODE C
       WHERE A.TPA_OFFICE_SEQ_ID = B.TPA_OFFICE_SEQ_ID
         AND A.CALL_LOG_SEQ_ID = v_log_seq_id;
  
    cr_get_repeated_calllog_REC cr_get_repeated_calllog%ROWTYPE;
  
    CURSOR cr_get_pat_ailment(v_pat_gen_detail_seq_id pat_general_details.pat_gen_detail_seq_id%TYPE) IS
      SELECT PROVISIONAL_DIAGNOSIS
        FROM AILMENT_DETAILS
       WHERE PAT_GEN_DETAIL_SEQ_ID = v_pat_gen_detail_seq_id;
  
    cr_get_pat_ailment_REC cr_get_pat_ailment%ROWTYPE;
  
    CURSOR cr_get_preauth_escalation(v_pat_gen_detail_seq_id pat_general_details.pat_gen_detail_seq_id%TYPE) IS
      SELECT pat_enroll_details.claimant_name,
             pat_general_details.added_date,
             pat_enroll_details.pre_auth_number,
             tpa_office_info.office_code,
             tpa_general_code.description
        FROM pat_enroll_details,
             pat_general_details,
             TPA_OFFICE_INFO,
             TPA_GENERAL_CODE
       WHERE (tpa_general_code.general_type_id =
             pat_enroll_details.pat_status_general_type_id)
         AND (pat_enroll_details.tpa_office_seq_id =
             TPA_OFFICE_INFO.TPA_OFFICE_SEQ_ID)
         AND (pat_general_details.pat_enroll_detail_seq_id =
             pat_enroll_details.pat_enroll_detail_seq_id)
         and (pat_general_details.pat_gen_detail_seq_id =
             v_pat_gen_detail_seq_id);
  
    cr_get_preauth_escalation_REC cr_get_preauth_escalation%ROWTYPE;
  
    -- Query to get the Online RECEIPT once the CORPORATE USER has submitted their Question
    CURSOR cr_get_Online_receipt(v_query_detail_seq_id Online_Query_Details.Query_Details_Seq_Id%TYPE) IS
      SELECT tpa_enr_policy_group.tpa_enrollment_number,
             tpa_enr_policy.policy_number,
             tpa_group_registration.group_name,
             tpa_group_registration.group_id,
             tpa_group_registration.email_id AS group_email_id, --//ED has to check
             tpa_group_registration.cc_email_id AS group_cc_email_id,
             ONLINE_QUERY_HEADER.REQUEST_ID,
             ONLINE_QUERY_DETAILS.SUBMITTED_DATE,
             ttk_util_pkg.fn_decrypt(Online_Query_Header.Email_Id) AS emp_email_id --//ED has to check
        FROM online_query_details,
             online_query_header,
             tpa_enr_policy_group,
             tpa_enr_policy,
             tpa_group_registration
       WHERE (online_query_details.query_header_seq_id =
             online_query_header.query_header_seq_id)
         and (online_query_header.policy_group_seq_id =
             tpa_enr_policy_group.policy_group_seq_id)
         and (tpa_enr_policy.policy_seq_id =
             tpa_enr_policy_group.policy_seq_id)
         and (tpa_enr_policy.group_reg_seq_id =
             tpa_group_registration.group_reg_seq_id)
         and (online_query_details.query_details_seq_id =
             v_query_detail_seq_id);
  
    cr_get_Online_receipt_REC cr_get_Online_receipt%ROWTYPE;
  
    -- Query to get the Online Response once the TTK has submitted the RESPONSE.
    CURSOR cr_get_Online_response(v_query_detail_seq_id Online_Query_Details.Query_Details_Seq_Id%TYPE) IS
      SELECT A.request_id,
             B.SUBMITTED_DATE,
             B.CLARIFIED_DATE,
             app.ttk_util_pkg.fn_decrypt(A.EMAIL_ID) as email_id --//ED has to check
        FROM ONLINE_QUERY_HEADER A, ONLINE_QUERY_DETAILS B
       WHERE A.QUERY_HEADER_SEQ_ID = B.QUERY_HEADER_SEQ_ID
         AND B.QUERY_DETAILS_SEQ_ID = v_query_detail_seq_id;
  
    cr_get_Online_response_REC cr_get_Online_response%ROWTYPE;
  
    -- Query is used to generate notification for EFT, Payadvice and Manual Cheque generation.
    CURSOR cr_get_FINANCIAL_PAYMENT(v_payment_seq_id TPA_CLAIMS_PAYMENT.PAYMENT_SEQ_ID%Type) IS
      
      SELECT ce.claimant_name,
             cg.claim_number,
             ce.notification_phone_number,
             cg.total_app_amount,
             ce.policy_seq_id,
             ce.member_seq_id,
             ttk_util_pkg.fn_decrypt(ce.email_id) as email_id,
             cp.payee_type,
             cc.check_amount, -- FOR KOC 1268
             ce.employee_no -- FOR KOC 1268
        FROM clm_enroll_details ce
       INNER JOIN clm_general_details cg
          ON ce.claim_seq_id = cg.claim_seq_id
       INNER JOIN tpa_claims_payment cp
          ON cg.claim_seq_id = cp.claim_seq_id
       INNER JOIN tpa_payment_checks_details pc
          ON cp.payment_seq_id = pc.payment_seq_id
       INNER JOIN tpa_claims_check cc
          ON pc.claims_chk_seq_id = cc.claims_chk_seq_id
       WHERE cc.check_status IN ('CSI', 'CSC')
         AND cp.payment_seq_id = v_payment_seq_id;
         
     cr_get_Financial_payment_REC cr_get_Financial_payment%ROWTYPE;
     
     CURSOR eft_cur (v_payment_seq_id TPA_CLAIMS_PAYMENT.PAYMENT_SEQ_ID%Type) IS
       select cl.claim_number,
       cl.currency_type,
       pm.mem_name as Claimant_Name,
       cp.approved_amount,
       gc.description as benifit_type,
       ch.hosp_name,
       rownum as sl_no,
       cb.batch_no,
       cl.tpa_enrollment_id,
       cl.mem_name as patitent_name,
       cl.invoice_number,
       cl.converted_amount AS requested_amount,
       cl.tot_disc_gross_amount-cl.tot_approved_amount as disallowed_amount,
       fa.float_account_number,
       ttk_util_pkg.fn_decrypt(tm.email_id) as mem_email,
       ttk_util_pkg.fn_decrypt(tm.mobile_no) as mem_mob,
       ttk_util_pkg.fn_decrypt(tf.toll_free_no) as toll_free_num,
       ttk_util_pkg.fn_decrypt(tf.email_id) as toll_free_email,
       ttk_util_pkg.fn_decrypt(th.primary_email_id) as hosp_email,
       null as employee_no,
       po.policy_seq_id,
       cc.check_num
       
  from clm_authorization_details cl
  left join clm_batch_upload_details cb  on (cb.clm_batch_seq_id = cl.clm_batch_seq_id)
  join tpa_claims_payment cp        on (cl.settlement_number = cp.claim_settlement_no)
  join fin_app.tpa_payment_checks_details pc on (cp.payment_seq_id=pc.payment_seq_id)
  join fin_app.tpa_claims_check cc on (pc.claims_chk_seq_id=cc.claims_chk_seq_id)
  left join tpa_float_account fa    on (fa.float_seq_id = cp.float_seq_id)
  left join clm_hospital_details ch on (ch.claim_seq_id = cl.claim_seq_id)
  left join tpa_hosp_info th        on (th.hosp_seq_id = ch.hosp_seq_id)
  left join tpa_enr_policy po       on (po.policy_seq_id = cl.policy_seq_id)
  left join tpa_enr_policy_member pm on (pm.tpa_enrollment_id = cl.tpa_enrollment_id)
  left join tpa_enr_policy_group  gr on (pm.policy_group_seq_id = gr.policy_group_seq_id)
  left join tpa_enr_mem_address  tm on (tm.enr_address_seq_id = gr.enr_address_seq_id)
  left join tpa_general_code gc     on (gc.general_type_id = cl.benifit_type)
  left join tpa_ins_info ti         on (ti.ins_seq_id = cl.ins_seq_id)
  left join tpa_office_info  tf     on (tf.tpa_office_seq_id = ti.tpa_office_seq_id)
  where cp.payment_seq_id = v_payment_seq_id
  and cp.claim_payment_status = 'PAID';
  
  eft_rec                     eft_cur%ROWTYPE;
     
     CURSOR get_eft_rec_cur (v_payment_seq_id NUMBER) IS
       SELECT cl.mem_name,
       cl.tot_approved_amount,
       CASE tp.enrol_type_id
         WHEN  'TTK' THEN
           ttk_util_pkg.fn_decrypt(td.email_id)
         WHEN 'COR' THEN
           ttk_util_pkg.fn_decrypt(tg.hr_email_id)
         WHEN 'HOS' THEN
           ttk_util_pkg.fn_decrypt(ti.primary_email_id)
         end as email
         
       FROM clm_authorization_details cl
       LEFT JOIN clm_hospital_details ch          ON ch.claim_seq_id = cl.claim_seq_id
       LEFT JOIN tpa_hosp_info ti                 ON ch.hosp_seq_id = ti.hosp_seq_id
       LEFT JOIN tpa_group_registration tg        ON tg.group_reg_seq_id = cl.claim_seq_id
       LEFT JOIN tpa_enr_policy tp                ON cl.policy_seq_id = tp.policy_seq_id
       LEFT JOIN tpa_enr_policy_member tpg        ON tpg.member_seq_id = cl.member_seq_id
       LEFT JOIN tpa_enr_policy_group t           ON t.group_reg_seq_id = tg.group_reg_seq_id
       LEFT JOIN tpa_enr_mem_address td           ON td.enr_address_seq_id = tpg.enr_address_seq_id
       LEFT JOIN tpa_claims_payment cp            ON cl.claim_seq_id = cp.claim_seq_id
       INNER JOIN tpa_payment_checks_details pc    ON cp.payment_seq_id = pc.payment_seq_id
       INNER JOIN tpa_claims_check cc              ON pc.claims_chk_seq_id = cc.claims_chk_seq_id
       WHERE cp.payee_type IN ('EFT')
       AND cp.payment_seq_id = v_payment_seq_id;
  
    v_get_eft_rec_cur get_eft_rec_cur%ROWTYPE;
  
    -- Query is used to generate notification on expiry of first login window period.
    CURSOR cr_get_INSURED_DTL(v_policy_group_seq_id TPA_ENR_POLICY_GROUP.POLICY_GROUP_SEQ_ID%Type) IS
      SELECT g.insured_name,
             ttk_util_pkg.fn_decrypt(a.email_id) as email_id --//ED
        FROM tpa_enr_policy_group g
        LEFT OUTER JOIN tpa_enr_mem_address a
          ON (g.enr_address_seq_id = a.enr_address_seq_id)
       WHERE g.policy_group_seq_id = v_policy_group_seq_id;
  
    cr_get_Insured_Dtl_REC cr_get_Insured_Dtl%ROWTYPE;
    --koc1216
  
    CURSOR cr_policy_opted(v_policy_group_seq_id TPA_ENR_POLICY_GROUP.POLICY_GROUP_SEQ_ID%TYPE) IS
      SELECT tpa_enr_policy_group.insured_name,
             tpa_enr_policy_group.employee_no,
             ttk_util_pkg.fn_get_emp_password(v_policy_group_seq_id) password,
             tpa_enr_policy.policy_number,
             tpa_group_registration.group_id,
             ttk_util_pkg.fn_decrypt(tpa_enr_mem_address.email_id) as email_id,
             tpa_enr_policy.policy_seq_id
        FROM tpa_enr_mem_address,
             tpa_enr_policy_group,
             tpa_enr_policy,
             tpa_group_registration
       WHERE (tpa_group_registration.group_reg_seq_id =
             tpa_enr_policy.group_reg_seq_id)
         and (tpa_enr_policy_group.enr_address_seq_id =
             tpa_enr_mem_address.enr_address_seq_id)
         and (tpa_enr_policy_group.policy_seq_id =
             tpa_enr_policy.policy_seq_id)
         and (tpa_enr_policy_group.policy_group_seq_id =
             v_policy_group_seq_id);
  
    cr_policy_opted_REC cr_policy_opted%ROWTYPE;
  
    --koc1216
    --======================================================================================================================
    ---Gethering Data for PREAUTH APPROVAL LETTER (CR)
    --======================================================================================================================
    CURSOR Pre_Auth_Approved_Cur(v_pat_auth_seq_id pat_authorization_details.pat_auth_seq_id%TYPE) IS
      SELECT pad.tot_approved_amount Amt,
             pad.mem_name Name,
             m.mem_name as policy_holder,
             pad.member_seq_id,
             thi.hosp_name,
             pad.pre_auth_number,
             pad.auth_number,
             gc.description as benefit_type,
             to_char(pad.pat_received_date, 'DD/MON/YYYY HH12:MI:SS AM') as pat_received_date,
             ttk_util_pkg.fn_decrypt(nvl(md.email_id, md.email_id1)) Mem_Email,
             --ttk_util_pkg.fn_decrypt(tem.email_id1) Alternative_mail,
             ttk_util_pkg.fn_decrypt(f.email_id) as toll_free_email,
             --ttk_util_pkg.fn_decrypt(tem.mobile_no) Mem_Mob,
             replace(substr(ttk_util_pkg.fn_decrypt(md.mobile_no), instr(ttk_util_pkg.fn_decrypt(md.mobile_no), '|', 1)), '|', null) as Mem_Mob,
             --ttk_util_pkg.fn_decrypt(thi.off_phone_no_1) as hosp_phone,
             replace(substr(ttk_util_pkg.fn_decrypt(thi.off_phone_no_1), instr(ttk_util_pkg.fn_decrypt(thi.off_phone_no_1), '|', 1)), '|', null) as hosp_phone,
             ttk_util_pkg.fn_decrypt(tii.email_id) Ins_Email,
             ttk_util_pkg.fn_decrypt(thi.primary_email_id) Hos_Email,
             f.toll_free_no as toll_free_num,
             m.mem_name as policy_holderName,
             m.tpa_enrollment_id,
             pad.clinician_mail   ------NEWLY ADDED FOR ALAHALI ENHANCEMENT
             
             
          from tpa_enr_policy_member m 
          join tpa_enr_policy_group           g on (m.policy_group_seq_id = g.policy_group_seq_id)
          join tpa_enr_mem_address            md on (md.enr_address_seq_id = m.enr_address_seq_id)
          join pat_authorization_details      pad on (pad.member_seq_id = m.member_seq_id)
          JOIN tpa_ins_info                   tii ON (tii.ins_seq_id = pad.ins_seq_id)
          JOIN tpa_office_info                f ON (f.tpa_office_seq_id = tii.tpa_office_seq_id)
          LEFT JOIN tpa_hosp_info             thi ON (thi.hosp_seq_id = pad.hosp_seq_id)
          LEFT JOIN tpa_general_code gc        ON (gc.general_type_id = pad.benifit_type)
          WHERE pad.pat_auth_seq_id = v_pat_auth_seq_id;
         
     v_auth_cursor Pre_Auth_Approved_Cur%ROWTYPE;
     
       -----------*********NEWLY ADDED CURSOR FOR PARTNER FOR ONLINE PREAUTH SUBMISSION********---------------- 
       
     CURSOR Pre_Auth_Approved_Cur_Ptnr(v_onl_pat_auth_seq_id PREAUTH_SUBMISSION.onl_pat_auth_seq_id%TYPE)  ----column name will change
     IS
     
     SELECT M.MEM_NAME AS name,
       GC.DESCRIPTION  AS benefit_type,
        M.TPA_ENROLLMENT_ID,
        pas.onl_pre_auth_refno,
        ptr.partner_name,
       PAS.HOSP_NAME hosp_name,
      ttk_util_pkg.fn_decrypt(ptr.primary_email_id) ptr_Email,
      C.Toll_Free_No   toll_free_num 
    FROM    
           TPA_ENR_POLICY_MEMBER M
       JOIN  TPA_ENR_POLICY_GROUP G ON (M.POLICY_GROUP_SEQ_ID = G.POLICY_GROUP_SEQ_ID)
       JOIN TPA_ENR_POLICY A ON (G.POLICY_SEQ_ID = A.POLICY_SEQ_ID)
       JOIN TPA_INS_INFO B ON (A.INS_SEQ_ID = B.INS_SEQ_ID)
       JOIN TPA_OFFICE_INFO C ON (B.TPA_OFFICE_SEQ_ID = C.TPA_OFFICE_SEQ_ID)
       JOIN  TPA_ENR_MEM_ADDRESS MD ON (M.ENR_ADDRESS_SEQ_ID = MD.ENR_ADDRESS_SEQ_ID)
       JOIN  PREAUTH_SUBMISSION PAS ON (M.MEMBER_SEQ_ID = PAS.MEMBER_SEQ_ID)
        JOIN TPA_GENERAL_CODE GC ON  (GC.GENERAL_TYPE_ID = PAS.BENIFIT_TYPE)
        JOIN TPA_PARTNER_INFO PTR ON  (PAS.PTNR_SEQ_ID = PTR.PTNR_SEQ_ID)
        WHERE PAS.ONL_PAT_AUTH_SEQ_ID =v_onl_pat_auth_seq_id;
        
          v_auth_cursor_ptnr Pre_Auth_Approved_Cur_Ptnr%ROWTYPE;
    
   /*  SELECT M.MEM_NAME AS name,
       GC.DESCRIPTION  AS benefit_type,
        M.TPA_ENROLLMENT_ID,
       PAS.HOSP_NAME hosp_name,
      ttk_util_pkg.fn_decrypt(ptr.primary_email_id) ptr_Email,
      '1800 123456'   toll_free_num -----HARD CODED
    FROM    TPA_ENR_POLICY_MEMBER M
       JOIN  TPA_ENR_POLICY_GROUP G ON (M.POLICY_GROUP_SEQ_ID = G.POLICY_GROUP_SEQ_ID)
       JOIN  TPA_ENR_MEM_ADDRESS MD ON (M.ENR_ADDRESS_SEQ_ID = MD.ENR_ADDRESS_SEQ_ID)
       JOIN  PREAUTH_SUBMISSION PAS ON (M.TPA_ENROLLMENT_ID = PAS.TPA_ENROLLMENT_ID)
        JOIN TPA_GENERAL_CODE GC ON  (GC.GENERAL_TYPE_ID = PAS.BENIFIT_TYPE)
        JOIN TPA_PARTNER_INFO PTR ON  (PAS.PTNR_SEQ_ID = PTR.PTNR_SEQ_ID)*/
        
     
   
     
     -----------*********NEWLY ADDED FOR PARTNER FOR ONLINE PREAUTH SUBMISSION********----------------  
     
    --v_Pre_Auth_Approved_Cur Pre_Auth_Approved_Cur%ROWTYPE;
    CURSOR pat_denial_cur(v_pat_auth_seq_id pat_authorization_details.pat_auth_seq_id%TYPE) IS
      SELECT pa.denial_desc as denial, nvl(pa.benifit_copay, pa.copay_perc) as copay_perc,
             pa.benifit_deductible
     --trim(regexp_substr(pa.denial_desc, '[^;]+', 1, LEVEL)) denial
     FROM Pat_Authorization_Details pad
     LEFT JOIN Pat_Activity_Details pa ON pa.pat_auth_seq_id = pad.pat_auth_seq_id
     WHERE pad.pat_auth_seq_id = v_pat_auth_seq_id
     CONNECT BY instr(denial_reason, ';', 1, LEVEL - 1) > 0;
     
    pat_denial_rec                   pat_denial_cur%ROWTYPE;
    --=======================================================================================
    --Getharing Data for Shortfall
    --=======================================================================================
    CURSOR Pre_Auth_Srt_Cur(v_pat_gen_detail_seq_id shortfall_details.pat_gen_detail_seq_id%TYPE) IS
      SELECT pad.mem_name Mem_Name,
             ttk_util_pkg.fn_decrypt(toi.toll_free_no) AS Toll_Free,
             pad.pre_auth_number Pre_Auth_Num
        FROM pat_authorization_details pad,
             tpa_office_info           toi,
             tpa_hosp_info             tpi,
             shortfall_details         sd
      
       WHERE (pad.hosp_seq_id = tpi.hosp_seq_id)
         and (tpi.tpa_office_seq_id = toi.tpa_office_seq_id)
         and (pad.pat_auth_seq_id = sd.pat_gen_detail_seq_id)
         and (sd.pat_gen_detail_seq_id = v_pat_gen_detail_seq_id);
  
    v_Pre_Auth_Srt_Cur Pre_Auth_Srt_Cur%ROWTYPE;
    
    CURSOR otp_cur (v_member_seq_id NUMBER) IS
      select o.otp_number, ttk_util_pkg.fn_decrypt(t1.email_id) mem_email_addr
      from tpa_enr_policy_member t
      inner join tpa_enr_mem_address t1 on (t.enr_address_seq_id = t1.enr_address_seq_id)
      inner join tpa_enr_pol_mem_otp_codes o on (t.member_seq_id = o.member_seq_id)
      where o.member_seq_id = v_member_seq_id;
    v_otp_msg otp_cur%ROWTYPE;
    --Cursor for Insurance (Payer)
    /*CURSOR cur_ins_detils (v_pat_auth_seq_id pat_authorization_details.pat_auth_seq_id%TYPE) IS
    SELECT */
    --============================================================================
    --Gathering Data for Pre-Auth Receipt
    --============================================================================
    
        -----====================Referral Letter CR=======

  CURSOR cur_referral_letter
  (v_referral_seq_id app.tpa_referral_letter.referral_seq_id%type) 
  IS   
  select trl.provider_mail_id mail_id,
         trl.file_name,
         trl.content_of_letter 
  from app.tpa_referral_letter trl 
      join app.tpa_hosp_info hi         on (hi.hosp_licenc_numb = trl.hosp_licenc_numb)
      --join app.tpa_user_contacts uc     on (hi.hosp_seq_id=uc.hosp_seq_id)
      --join app.tpa_designation_code gd  on (uc.designation_type_id=gd.designation_type_id) 
     where  trl.referral_seq_id = v_referral_seq_id;
       
    rec_ref_letter   cur_referral_letter%rowtype;  
    
    v_network CHAR(3); --Network Type
    v_bro_Email Tpa_Bro_Info.Email_Id%TYPE;
    
    v_pat_rec_date VARCHAR2(30);
    v_tot_depend_cnt NUMBER(10);
    
   CURSOR mob_app_otp_cur(v_policy_group_seq_id   NUMBER) IS 
    SELECT o.otp_number,o.user_id,o.email_id,o.mobile_no
     FROM app.tpa_mob_app_otp_codes o 
    WHERE o.policy_group_seq_id = v_policy_group_seq_id
    AND o.active_yn = 'Y';
      
    rec_mob_app_otp                   mob_app_otp_cur%ROWTYPE;
    
   CURSOR mob_app_psw_cur(v_policy_group_seq_id   NUMBER) IS 
    SELECT i.user_id,intx.ttk_util_pkg.fn_decrypt(i.password) as password,
           SUBSTR(intx.ttk_util_pkg.fn_decrypt(ma.mobile_no),INSTR(intx.ttk_util_pkg.fn_decrypt(ma.mobile_no),'|')+1) as mobile_no,
           nvl(intx.ttk_util_pkg.fn_decrypt(ma.email_id),intx.ttk_util_pkg.fn_decrypt(ma.email_id1)) as email_id
     FROM app.tpa_mob_app_login_info i
     JOIN app.tpa_enr_policy_group pg ON (i.policy_group_seq_id=pg.policy_group_seq_id)
     JOIN app.tpa_enr_mem_address ma ON (pg.enr_address_seq_id=ma.enr_address_seq_id)
    WHERE i.policy_group_seq_id = v_policy_group_seq_id;
      
    rec_mob_app_psw                   mob_app_psw_cur%ROWTYPE;
    
   CURSOR clm_batch_dtls(v_claim_seq_id   NUMBER) IS
     SELECT b.batch_no,ca.invoice_number,
            intx.ttk_util_pkg.fn_decrypt(ma.email_id) as email_id
     FROM clm_authorization_details ca
     JOIN clm_batch_upload_details b ON (ca.clm_batch_seq_id=b.clm_batch_seq_id) 
     JOIN tpa_enr_policy_member m ON (ca.member_seq_id=m.member_seq_id)
     JOIN tpa_enr_policy_group pg ON (m.policy_group_seq_id = pg.policy_group_seq_id)
     JOIN tpa_enr_mem_address ma ON (pg.enr_address_seq_id = ma.enr_address_seq_id)
     WHERE ca.claim_seq_id = v_claim_seq_id;
     
    rec_clm_batch_dtls        clm_batch_dtls%ROWTYPE; 
     
    
cursor hr_info_cur is
select A.GROUP_ID as id,B.GROUP_NAME as name,C.POLICY_NUMBER as policynum,A.HR_USER_ID as userId,TO_CHAR(SYSDATE,'DD/MM/YYYY')  as hdate from APP.HR_UPLOAD_DETAILS A,APP.TPA_GROUP_REGISTRATION B,APP.TPA_ENR_POLICY C
WHERE A.GROUP_ID=B.GROUP_ID AND C.POLICY_SEQ_ID=A.POLICY_SEQ_ID AND  A.HR_USER_ID=cr_get_user_info_rec.user_id AND A.GROUP_ID=cr_get_user_info_rec.group_id AND A.POLICY_SEQ_ID =v_additional_param AND A.FILE_SEQ_ID=v_additional_param_2;

hr_info_cur_rec hr_info_cur%rowtype;

CURSOR hr_info_comp_cur is
select UC.PRIMARY_EMAIL_ID,UC.SECONDARY_EMAIL_ID from hr_upload_details UD JOIN TPA_LOGIN_INFO LI ON(UD.HR_USER_ID=LI.USER_ID)
                                   JOIN TPA_USER_CONTACTS UC ON(LI.CONTACT_SEQ_ID=UC.CONTACT_SEQ_ID) WHERE UD.file_seq_id=v_additional_param;

hr_info_comp_rec hr_info_comp_cur%rowtype;

CURSOR cur_pricing_pol_dtls(v_grp_prof_seq_id NUMBER) IS
   SELECT P.REF_NO,CASE NVL(P.RENEWAL_YN,'N') WHEN 'Y' THEN 'Renewal' ELSE 'New client' END AS RENEWAL_YN,
          P.CLIENT_CODE,GR.GROUP_NAME,P.ADDED_DATE AS INITIATED_DATE,nvl(CP.UPDATED_DATE,CP.ADDED_DATE) AS CALCULATE_DATE,
          p.tot_cov_lives
   FROM APP.TPA_GROUP_PROFILE_DETAILS P  
   LEFT OUTER JOIN APP.TPA_GROUP_REGISTRATION GR ON (P.CLIENT_CODE = GR.GROUP_ID) 
   LEFT OUTER JOIN APP.tpa_group_fnl_cpm_details CP ON (P.GRP_PROF_SEQ_ID=CP.GRP_PROF_SEQ_ID)
   WHERE P.GRP_PROF_SEQ_ID = v_grp_prof_seq_id
     AND ROWNUM = 1;
   
 rec_pricing_pol_dtls             cur_pricing_pol_dtls%ROWTYPE;  
 
CURSOR clim_assign_user_cur(v_claim_seq_id number) is 
select clm.claim_number,case when NVL(mem.vip_yn,'N')='Y' then 'VIP' else 'NON-VIP' end vip_yn,
       gen.DESCRIPTION mode_of_claim,bat.BATCH_NO,
      case when clm.CLAIM_TYPE ='CTM' then 'Member' else 'Network' end as type_of_claim,
      mem.TPA_ENROLLMENT_ID alkoot_id,mem.MEM_NAME patient_name,grp.GROUP_NAME,pol.POLICY_NUMBER,
      gen1.DESCRIPTION benifit_type,clm.INVOICE_NUMBER,
      clm.REQUESTED_AMOUNT||' '||clm.REQ_AMT_CURRENCY_TYPE claimed_amount,
      hosp.hosp_name, clm.CLAIM_TYPE,clm.clm_received_date as clm_received_date                                                                
      from app.clm_authorization_details clm join app.tpa_enr_policy_member mem on(clm.member_Seq_id=mem.member_seq_id)
      join app.clm_batch_upload_details bat on(bat.CLM_BATCH_SEQ_ID=clm.CLM_BATCH_SEQ_ID)
      left outer join app.tpa_general_code gen on(gen.general_type_id=bat.source_type_id and gen.header_type='CLM_SOURCE')                                                                        
      left outer join app.tpa_enr_policy_group plg on(plg.POLICY_GROUP_SEQ_ID=mem.POLICY_GROUP_SEQ_ID)
      left outer join app.TPA_GROUP_REGISTRATION grp on(grp.GROUP_REG_SEQ_ID=plg.GROUP_REG_SEQ_ID)
      left outer join app.tpa_enr_policy pol on(clm.policy_seq_id=pol.policy_seq_id)
      left outer join app.tpa_general_code gen1 on(clm.BENIFIT_TYPE=gen1.GENERAL_TYPE_ID and gen1.HEADER_TYPE='BENIFIT_TYPE')
      left outer join app.CLM_HOSPITAL_DETAILS hpl on(hpl.claim_seq_id = clm.claim_seq_id)
      left outer join app.tpa_hosp_info hosp on(hosp.hosp_seq_id= hpl.hosp_seq_id)
      where clm.claim_Seq_id=v_claim_seq_id;
  clim_assign_user_rec                  clim_assign_user_cur%rowtype;

CURSOR pat_assign_user_cur(v_pat_auth_seq_id number) is 
  select pat.pre_auth_number,case when NVL(mem.vip_yn,'N')='Y' then 'VIP' else 'NON-VIP' end vip_yn, 
         hosp.HOSP_NAME,mem.TPA_ENROLLMENT_ID alkoot_id ,mem.MEM_NAME patient_name,grp.GROUP_NAME,
         pol.policy_number,gen1.description benifit_type, pat.REQUESTED_AMOUNT||' '||pat.REQ_AMT_CURRENCY_TYPE req_amount,
         pat.PAT_RECEIVED_DATE as pat_received_date,gen.DESCRIPTION mode_of_pat,NVL(pat.pat_enhanced_yn,'N') as pat_enhanced_yn
        from app.pat_authorization_Details pat join app.tpa_enr_policy_member mem on(pat.member_seq_id=mem.member_seq_id)
                                               left outer join app.tpa_hosp_info hosp on (hosp.hosp_seq_id=pat.hosp_seq_id)
                                               left outer join app.tpa_enr_policy_group plg on(plg.POLICY_GROUP_SEQ_ID=mem.POLICY_GROUP_SEQ_ID)
                                               left outer join app.TPA_GROUP_REGISTRATION grp on(grp.GROUP_REG_SEQ_ID=plg.GROUP_REG_SEQ_ID)
                                               left outer join app.tpa_enr_policy pol on (pol.policy_seq_id=pat.policy_seq_id)
                                               left outer join app.tpa_general_code gen1 on(pat.BENIFIT_TYPE=gen1.GENERAL_TYPE_ID and gen1.HEADER_TYPE='BENIFIT_TYPE')
                                               left outer join app.tpa_general_code gen on(pat.SOURCE_TYPE_ID=gen.GENERAL_TYPE_ID and gen.HEADER_TYPE='PAT_SOURCE')
        where pat_auth_seq_id =v_pat_auth_seq_id;
  
  pat_assign_user_rec                         pat_assign_user_cur%rowtype;
  
CURSOR user_assigned_flags_cur(v_contact_seq_id number) is     	
select vip_pat_sms,vip_pat_email,vip_pat_primary,vip_pat_alternate,vip_pat_cnh_req,vip_pat_freq,
       vip_clm_sms,vip_clm_email,vip_clm_primary,vip_clm_alternate,vip_clm_ctm_req,vip_clm_cnh_req,vip_clm_freq,
       non_vip_pat_sms,non_vip_pat_email,non_vip_pat_primary,non_vip_pat_alternate,non_vip_pat_cnh_req,non_vip_pat_freq,
       non_vip_clm_sms,non_vip_clm_email,non_vip_clm_primary, non_vip_clm_alternate,non_vip_clm_ctm_req, non_vip_clm_cnh_req,non_vip_clm_freq,   
       vip_pat_rej,vip_clm_rej 
      from tpa_user_contacts where contact_seq_id =v_contact_seq_id;
      
   user_assigned_flags_rec user_assigned_flags_cur%rowtype;
 CURSOR mob_app_emp(v_emp_id VARCHAR2) IS
   SELECT M.MEM_NAME, TTK_UTIL_PKG.fn_decrypt(MA.EMAIL_ID) AS EMAIL_ID,
   GR.GROUP_NAME

   FROM TPA_ENR_POLICY_MEMBER M
   JOIN TPA_ENR_MEM_ADDRESS MA ON MA.ENR_ADDRESS_SEQ_ID = M.ENR_ADDRESS_SEQ_ID
   JOIN TPA_ENR_POLICY_GROUP G ON G.POLICY_GROUP_SEQ_ID = M.POLICY_GROUP_SEQ_ID
   JOIN TPA_GROUP_REGISTRATION GR ON GR.GROUP_REG_SEQ_ID = G.GROUP_REG_SEQ_ID
   WHERE M.TPA_ENROLLMENT_ID = trim(v_emp_id);
 
 mob_rec  mob_app_emp%ROWTYPE;
 v_pol_tob         BLOB;
 

  CURSOR recovery_cur IS
    SELECT S.RECOVERY_MSG, NVL(S.RECOVERY_MSG_YN, 'N') AS RECOVERY_MSG_YN
    FROM APP.SOURCE_MESSAGE S
    WHERE S.MSG_ID = v_message_type_id;
    
  recovery_rec  recovery_cur%ROWTYPE;
  
 CURSOR empl_login_cur(v_enroll_id VARCHAR2) IS
   SELECT M.MEM_NAME, TTK_UTIL_PKG.fn_decrypt(MA.EMAIL_ID) AS EMAIL_ID,
   GR.GROUP_NAME,TTK_UTIL_PKG.fn_decrypt(MA.MOBILE_NO) MOBILE_NO,m.tpa_enrollment_id,
   TTK_UTIL_PKG.fn_decrypt(ma.email_id1) email_id1,TTK_UTIL_PKG.fn_decrypt(G.EMPLOYEE_PASSWORD) PWD

   FROM TPA_ENR_POLICY_MEMBER M
   JOIN TPA_ENR_MEM_ADDRESS MA ON MA.ENR_ADDRESS_SEQ_ID = M.ENR_ADDRESS_SEQ_ID
   JOIN TPA_ENR_POLICY_GROUP G ON G.POLICY_GROUP_SEQ_ID = M.POLICY_GROUP_SEQ_ID
   JOIN TPA_GROUP_REGISTRATION GR ON GR.GROUP_REG_SEQ_ID = G.GROUP_REG_SEQ_ID
   WHERE M.Member_Seq_Id = trim(v_enroll_id); 
 
 empl_rec empl_login_cur%ROWTYPE;
  
  ------------------ cr0295 ------------
  CURSOR emp_login_pwd(v_policy_group_seq_id number) IS
     SELECT a.insured_name,
            a.tpa_enrollment_number,
            m.tpa_enrollment_id,
            ttk_util_pkg.fn_decrypt(a.employee_user_id) user_id,
            ttk_util_pkg.fn_decrypt(a.employee_password) pwd,
            ttk_util_pkg.fn_decrypt(b.email_id) as primary_email_id,
            ttk_util_pkg.fn_decrypt(b.email_id1) as secondary_email_id
       
       FROM tpa_enr_policy_group a
       JOIN tpa_enr_mem_address b on(a.enr_address_seq_id=b.enr_address_seq_id)
       join tpa_enr_policy_member m on (m.policy_group_seq_id=a.policy_group_seq_id and m.relship_type_id='NSF')
      WHERE a.policy_group_seq_id = v_policy_group_seq_id;
      
   v_emp_login_pwd   emp_login_pwd%rowtype;
  ---------------------------------------
 
 ------ CFD Cr generation mail (Tagging & investigation Status Confirmation)
     ---------- preapproval case
 CURSOR cfd_pre_approval_cur IS
        SELECT pad.pre_auth_number,CASE pad.risk_level WHEN 'HR' THEN 'High Risk' WHEN 'IR' THEN 'Intermediate Risk' WHEN 'LR' THEN 'Low Risk' end risk_level,pad.tpa_enrollment_id,
        to_char(pad.code_added_date, 'DD-MON-YYYY HH12:MI:SS AM') AS added_date,pad.mem_name,tep.policy_number,tgp.group_name,pad.requested_amount,
        CASE pad.benifit_type WHEN 'OPTS' THEN 'OUT-PATIENT' WHEN 'IPT' THEN 'IN-PATIENT' WHEN 'OPTC' THEN 'OPTICAL' WHEN 'DNTL' THEN 'DENTAL' WHEN 'IMTI' THEN 'IN-PATIENT MATERNITY'
                              WHEN 'DAYC' THEN 'DAYCARE' WHEN 'IEMA' THEN 'INTERNATIONAL EMERGENCY MEDICAL ASSISTANCE' WHEN 'IPRE' THEN 'IN-PATIENT REHABILITATION' WHEN 'PAHC' THEN 'PAHC'
                              WHEN 'OMTI' THEN 'OUT-PATIENT MATERNITY' END benifit_type,
        to_char(pad.pat_received_date,'DD-MON-YYYY HH12:MI:SS AM') pat_rec_date,tuc.contact_name
        FROM PAT_AUTHORIZATION_DETAILS PAD 
        JOIN TPA_ENR_POLICY TEP ON (TEP.POLICY_SEQ_ID = PAD.POLICY_SEQ_ID)
        JOIN TPA_GROUP_REGISTRATION TGP ON (TEP.GROUP_REG_SEQ_ID = TGP.GROUP_REG_SEQ_ID)
        JOIN TPA_USER_CONTACTS TUC ON (TUC.CONTACT_SEQ_ID = PAD.CODE_ADDED_BY)
        WHERE PAD.PAT_AUTH_SEQ_ID = TO_NUMBER(v_parameters);

CURSOR inv_status_cur (v_mode varchar2)  IS  
       SELECT * FROM (SELECT        CASE  inv_status WHEN 'II' THEN 'Investigation In-progress'
                                          WHEN 'CA' THEN 'Cleared for Approval'
                                          WHEN 'PCA' THEN 'Partially Cleared For Approval'
                                          WHEN 'FD' THEN 'Fraud Detected' 
                                          ELSE NULL END AS inv_status,
                                     CASE inv_out_category  WHEN 'MOF' THEN 'Misrepresentation Of Facts'
                                                             WHEN 'CBMP' THEN 'Collision Between Member And Provider'
                                                             WHEN 'AAUP' THEN 'Abuse And Undocumented Services'
                                                             WHEN 'PB' THEN 'Phantom Billing'
                                                             WHEN 'DB' THEN 'Duplicate Billing'
                                                             WHEN 'UOS' THEN 'Unbundling Of Services'
                                                             WHEN 'OU' THEN 'Overutilization'
                                                             ELSE NULL END AS inv_out_category,
                                    to_char(added_date,'DD-MON-YYYY HH12:MI:SS AM') as dec_date
         FROM app.tpa_fraud_inv_details WHERE CASE WHEN V_MODE = 'PAT' THEN pat_auth_seq_id ELSE claim_seq_id END = TO_NUMBER(v_parameters) ORDER BY inv_seq_id DESC)
      WHERE rownum =1;
 
      ---------- claims case
      CURSOR cfd_claim_cur IS
        SELECT cad.claim_number,CASE cad.risk_level WHEN 'HR' THEN 'High Risk' WHEN 'IR' THEN 'Intermediate Risk' WHEN 'LR' THEN 'Low Risk' END risk_level,cad.tpa_enrollment_id,tgp.group_name,thi.hosp_name,cbd.batch_no,cad.invoice_number,
        to_char(cad.code_added_date, 'DD-MON-YYYY HH12:MI:SS AM') AS added_date,cad.mem_name,tep.policy_number,cad.requested_amount,CASE cad.claim_type WHEN 'CNH' THEN 'NetWork' WHEN 'CTM' THEN 'Reimbursement' END type_of_claim,
        CASE cad.benifit_type WHEN 'OPTS' THEN 'OUT-PATIENT' WHEN 'IPT' THEN 'IN-PATIENT' WHEN 'OPTC' THEN 'OPTICAL' WHEN 'DNTL' THEN 'DENTAL' WHEN 'IMTI' THEN 'IN-PATIENT MATERNITY'
                              WHEN 'DAYC' THEN 'DAYCARE' WHEN 'IEMA' THEN 'INTERNATIONAL EMERGENCY MEDICAL ASSISTANCE' WHEN 'IPRE' THEN 'IN-PATIENT REHABILITATION' WHEN 'PAHC' THEN 'PAHC'
                              WHEN 'OMTI' THEN 'OUT-PATIENT MATERNITY' END benifit_type,
        to_char(cad.clm_received_date,'DD-MON-YYYY HH24:MI:SS AM') clm_rec_date,tuc.contact_name
        FROM CLM_AUTHORIZATION_DETAILS CAD 
        JOIN CLM_BATCH_UPLOAD_DETAILS CBD ON (CBD.CLM_BATCH_SEQ_ID = CAD.CLM_BATCH_SEQ_ID)
        LEFT JOIN CLM_HOSPITAL_DETAILS CHD ON (CHD.CLAIM_SEQ_ID = CAD.CLAIM_SEQ_ID)
        LEFT JOIN TPA_HOSP_INFO THI ON (THI.HOSP_SEQ_ID = CHD.HOSP_SEQ_ID)
        JOIN TPA_ENR_POLICY TEP ON (TEP.POLICY_SEQ_ID = cad.POLICY_SEQ_ID)
        JOIN TPA_GROUP_REGISTRATION TGP ON (TEP.GROUP_REG_SEQ_ID = TGP.GROUP_REG_SEQ_ID)
        JOIN TPA_USER_CONTACTS TUC ON (TUC.CONTACT_SEQ_ID = cad.CODE_ADDED_BY)
        WHERE cad.CLAIM_SEQ_ID = TO_NUMBER(v_parameters);
  
  inv_stat_rec inv_status_cur%ROWTYPE;
  cfd_pre_approval_rec cfd_pre_approval_cur%ROWTYPE;
  cfd_claim_rec  cfd_claim_cur%ROWTYPE;
      
 CURSOR pre_approval_cur IS 
 select mem.tpa_enrollment_id,
       mem.mem_name,
       ttk_util_pkg.fn_decrypt(ad.mobile_no) mobile_no,
       reg.group_name,
       pat.pre_auth_number,
       nvl(hos.hosp_name,non.provider_name) provider_name,
       nvl(hos.off_phone_no_1,hos.off_phone_no_2) provider_number
  from app.pat_authorization_details pat
  left outer join app.tpa_enr_policy_member mem
    on (mem.member_seq_id = pat.member_seq_id)
  left outer join app.tpa_enr_mem_address ad
    on (mem.enr_address_seq_id = ad.enr_address_seq_id)
  left outer join app.tpa_enr_policy_group grp
    on (mem.policy_group_seq_id = grp.policy_group_seq_id)
  left outer join app.tpa_group_registration reg
    on (reg.group_reg_seq_id = grp.group_reg_seq_id)
  left outer join app.tpa_hosp_info hos
    on (hos.hosp_seq_id = pat.hosp_seq_id)
  left outer join app.pat_non_network_details non
    on (non.pat_auth_seq_id = pat.pat_auth_seq_id)
 where pat.pat_auth_seq_id = v_parameters;
 
 pre_approval_rec    pre_approval_cur%ROWTYPE;
  
 CURSOR mem_card_cur(v_mem_seq_id NUMBER) IS
    SELECT L.USER_ID,
           CO.PRIMARY_EMAIL_ID,
           M.TPA_ENROLLMENT_ID AS MEM_ID,
           M.MEM_NAME,
           C.GROUP_NAME AS CORP_NAME,
           P.POLICY_NUMBER
       
    FROM TPA_ENR_POLICY_MEMBER M
    JOIN TPA_ENR_POLICY_GROUP G ON G.POLICY_GROUP_SEQ_ID = M.POLICY_GROUP_SEQ_ID
    JOIN TPA_ENR_POLICY P ON P.POLICY_SEQ_ID = G.POLICY_SEQ_ID
    JOIN TPA_ENR_MEM_ADDRESS A ON A.ENR_ADDRESS_SEQ_ID = M.ENR_ADDRESS_SEQ_ID
    JOIN TPA_GROUP_REGISTRATION C ON C.GROUP_REG_SEQ_ID = G.GROUP_REG_SEQ_ID
    LEFT JOIN TPA_USER_CONTACTS CO ON CO.CONTACT_SEQ_ID = v_added_by
    JOIN TPA_LOGIN_INFO L ON L.CONTACT_SEQ_ID = CO.CONTACT_SEQ_ID
    WHERE M.MEMBER_SEQ_ID = v_mem_seq_id
    AND NVL(M.DELETED_YN, 'N') = 'N';
    
  CURSOR grp_card_cur(v_mem_seq_id NUMBER) IS
    SELECT L.USER_ID,
           CO.PRIMARY_EMAIL_ID,
           M.TPA_ENROLLMENT_ID AS MEM_ID,
           M.MEM_NAME,
           C.GROUP_NAME AS CORP_NAME,
           P.POLICY_NUMBER
       
    FROM TPA_ENR_POLICY_MEMBER M
    JOIN TPA_ENR_POLICY_GROUP G ON G.POLICY_GROUP_SEQ_ID = M.POLICY_GROUP_SEQ_ID
    JOIN TPA_ENR_POLICY P ON P.POLICY_SEQ_ID = G.POLICY_SEQ_ID
    JOIN TPA_ENR_MEM_ADDRESS A ON A.ENR_ADDRESS_SEQ_ID = M.ENR_ADDRESS_SEQ_ID
    JOIN TPA_GROUP_REGISTRATION C ON C.GROUP_REG_SEQ_ID = G.GROUP_REG_SEQ_ID
    LEFT JOIN TPA_USER_CONTACTS CO ON CO.CONTACT_SEQ_ID = v_added_by
    JOIN TPA_LOGIN_INFO L ON L.CONTACT_SEQ_ID = CO.CONTACT_SEQ_ID
    WHERE M.POLICY_GROUP_SEQ_ID = v_mem_seq_id
    AND NVL(M.DELETED_YN, 'N') = 'N';
    
  mem_card_rec            mem_card_cur%ROWTYPE;
  
 
 TYPE Mem_Part_Info IS RECORD
 ( member_id   app.tpa_enr_policy_member.tpa_enrollment_id%type,
   member_name app.tpa_enr_policy_member.mem_name%type,
   member_relation     VARCHAR2(100),
   policy_grp_seq      app.tpa_enr_policy_member.policy_group_seq_id%type,
   email_id            app.tpa_enr_mem_address.email_id%type
 );
 
 TYPE Mem_Part_Info_Rec IS TABLE OF Mem_Part_Info INDEX BY BINARY_INTEGER; 
 Mem_Part_Info_R Mem_Part_Info_Rec;
 v_member_seq_ids       VARCHAR2(500);
 v_policy_grp_seq       NUMBER(30); 

  BEGIN
   
    -- This variable will indicate whether the message has to be logged into the Alert Table.
    -- If it is none, then no insertion, else depending CLAIMS, claim seq id would be updated.
    -- If pre-auth notifications, Pre-auth related id will be added.
    v_notification_type := 'NONE';
    v_enrollment_number := NULL;
    v_msg_type          := NULL;
  
    -- For the selected Event ID, decide how should the message be sent ?
    OPEN cr_get_core_mesg_dtl(v_message_type_id);
    FETCH cr_get_core_mesg_dtl
      INTO v_module_name,
           v_sent_from,
           v_msg_title,
           v_send_as_email_yn,
           v_send_as_sms_yn,
           v_send_as_fax_yn,
           v_prm_rcpt_list,
           v_sec_rcpt_list,
           v_mail_category,
           v_customise_allowed_YN;
    CLOSE cr_get_core_mesg_dtl;
  
    -- Verify whether mail should be sent or not. Is it customised mail or general mail.
    validate_process_mail(v_message_type_id,
                          v_parameters,
                          v_mail_category,
                          v_process_yn,
                          v_general_mail,
                          v_cc_mail,
                          v_group_name,
                          v_customise_allowed_YN);
  
    IF (v_process_yn = 'Y') THEN
      -- ########### NEW_USERID - Generating message for User Creation (TTK USERS and COPROATE HR's )
      -- Message will be sent only through Email for the user
      IF ((v_message_type_id = 'NEW_USERID') OR
         (v_message_type_id = 'RESET_PASSWORD_NHCP') OR
         (v_message_type_id = 'RESET_PASSWORD') OR
         (v_message_type_id = 'NEW_USERID_GROUPID') OR
         (v_message_type_id = 'RESET_PASSWORD_GROUPID') OR
         (v_message_type_id = 'NEW_USERID_INSCODE') OR
         (v_message_type_id = 'RESET_PASSWORD_INSCODE')OR
         (v_message_type_id = 'PROVIDER_USER_ID') OR
         (v_message_type_id = 'FORGOT_PASSWORD_HOSP') OR
         (v_message_type_id = 'FORGOT_PASSWORD_PROV') OR
		 (v_message_type_id = 'FORGOT_PASSWORD_HR') OR 
		 (v_message_type_id = 'HR_UPLOADED_FILE') OR--hr
     (v_message_type_id = 'HR_CONFIRMATION_FILE_UPLOADED') OR
         (v_message_type_id = 'PARTNER_USER_ID') OR     -------------------newly added for partner
         (v_message_type_id = 'FORGOT_PASSWORD_PATR')  OR  ----------------newly added for partner
		 (v_message_type_id = 'MAIL_USER_PASSWORD') OR
          (v_message_type_id = 'CALL_USER_PASSWORD') OR
         (v_message_type_id = 'BROKER_USER_ID') OR
         (v_message_type_id = 'USER_ASSIGNED_CLAIM') OR
         (v_message_type_id = 'USER_ASSIGNED_PREAUTH')) THEN
        -- Call the SQL to get the value
        IF (v_message_type_id = 'NEW_USERID') OR
           (v_message_type_id = 'RESET_PASSWORD') THEN
          OPEN cr_get_user_info(v_parameters, 'TTK');
        ELSIF (v_message_type_id = 'NEW_USERID_GROUPID') OR
              (v_message_type_id = 'RESET_PASSWORD_GROUPID') THEN
          OPEN cr_get_user_info(v_parameters, 'COR');
        ELSIF (v_message_type_id = 'NEW_USERID_INSCODE') OR
              (v_message_type_id = 'RESET_PASSWORD_INSCODE') THEN
          OPEN cr_get_user_info(v_parameters, 'INS');
        ELSIF (v_message_type_id = 'PROVIDER_USER_ID') THEN
          OPEN cr_get_user_info(v_parameters, 'HOS');
        ELSIF (v_message_type_id = 'FORGOT_PASSWORD_HOSP') THEN
          OPEN cr_get_user_info(v_parameters, 'HOS');
        ELSIF (v_message_type_id = 'FORGOT_PASSWORD_PROV') THEN
          OPEN cr_get_user_info(v_parameters, 'HOS');
		ELSIF (v_message_type_id = 'FORGOT_PASSWORD_HR') THEN   --hr
          OPEN cr_get_user_info(v_parameters, 'COR');         
        ELSIF (v_message_type_id = 'PARTNER_USER_ID') THEN     ----------------------NEWLY ADDED FOR PARTNER FOR NEW USER ID FOR NEW USER DURING SAVE CONTACTS IN EMPANELLMENT
          OPEN cr_get_user_info(v_parameters, 'PTR'); 
        ELSIF (v_message_type_id = 'FORGOT_PASSWORD_PATR') THEN ---------------------NEWLY ADDED FOR PARTNER FOR FORGOT PASSWORD DURING PARTNER EXTERNAL ONLINE LOG IN
          OPEN cr_get_user_info(v_parameters, 'PTR'); 
          ELSIF (v_message_type_id = 'RESET_PASSWORD_NHCP') THEN   --hr
          OPEN cr_get_user_info(v_parameters, 'HOS');
		  ELSIF (v_message_type_id = 'HR_UPLOADED_FILE') THEN   --hr
          OPEN cr_get_user_info(v_parameters, 'COR');
		  ELSIF (v_message_type_id ='HR_CONFIRMATION_FILE_UPLOADED') THEN
           OPEN cr_get_user_info(v_parameters,'COR');
		   ELSIF (v_message_type_id = 'MAIL_USER_PASSWORD') THEN   
          OPEN cr_get_user_info(v_parameters, 'TTK');
           ELSIF (v_message_type_id = 'CALL_USER_PASSWORD') THEN   
          OPEN cr_get_user_info(v_parameters, 'CAL');
        ELSIF (v_message_type_id = 'BROKER_USER_ID') THEN
          OPEN cr_get_user_info(v_parameters, 'BRO');
          ELSIF (v_message_type_id = 'USER_ASSIGNED_CLAIM') THEN
          OPEN cr_get_user_info(v_parameters,'TTK');
          ELSIF (v_message_type_id = 'USER_ASSIGNED_PREAUTH') THEN
          OPEN cr_get_user_info(v_parameters,'TTK');
        END IF;
        
      
        FETCH cr_get_user_info
          INTO cr_get_user_info_rec;
        CLOSE cr_get_user_info;
      
        v_email_id := cr_get_user_info_rec.primary_email_id;
      
        OPEN cr_get_URL_Name(cr_get_user_info_rec.user_general_type_id);
        FETCH cr_get_URL_Name
          INTO v_url_name;
        CLOSE cr_get_URL_Name;
        
        OPEN sec_email_cur (v_parameters);
        FETCH sec_email_cur INTO v_sec_email_cur;
        CLOSE sec_email_cur;
        
        OPEN toll_free_cur;
        FETCH toll_free_cur INTO toll_free_rec;
        CLOSE toll_free_cur;
        
        open hr_info_cur;
        fetch hr_info_cur into hr_info_cur_rec;
        close hr_info_cur;
        
        OPEN user_assigned_flags_cur(v_parameters);
        fetch user_assigned_flags_cur into user_assigned_flags_rec;
        close user_assigned_flags_cur;        
     
        IF (v_message_type_id = 'NEW_USERID') THEN
          -- FOR TTK USERS
          v_params(1) := cr_get_user_info_rec.contact_name;
          v_params(2) := v_url_name;
          v_params(3) := cr_get_user_info_rec.user_id;
          v_params(4) := cr_get_user_info_rec.pwd;
        ELSIF (v_message_type_id = 'RESET_PASSWORD') THEN
          -- FOR TTK USERS
          v_params(1) := cr_get_user_info_rec.contact_name;
          v_params(2) := cr_get_user_info_rec.user_id;
          v_params(3) := cr_get_user_info_rec.pwd;
          --v_params(4) := v_url_name;
        ELSIF (v_message_type_id = 'NEW_USERID_GROUPID') THEN
          -- FOR CORPORATE HR's
          
          v_params(1) := cr_get_user_info_rec.group_id; --cr_get_user_info_rec.contact_name;
          v_params(2) := cr_get_user_info_rec.user_id;
          v_params(3) := cr_get_user_info_rec.pwd;
          v_email_id := cr_get_user_info_rec.primary_email_id;
          v_sec_rcpt_list := v_sec_email_cur.secn_mail_id;
          
        ELSIF (v_message_type_id = 'NEW_USERID_INSCODE') THEN
          v_params(1) := cr_get_user_info_rec.group_id;
          v_params(2) := cr_get_user_info_rec.user_id;
          v_params(3) := cr_get_user_info_rec.pwd;
          v_email_id := cr_get_user_info_rec.primary_email_id;
          v_sec_rcpt_list := v_sec_email_cur.secn_mail_id;
          
        ELSIF ((v_message_type_id = 'RESET_PASSWORD_GROUPID') OR
              (v_message_type_id = 'RESET_PASSWORD_INSCODE')) THEN
          -- FOR CORPORATE HR's
          v_params(1) := cr_get_user_info_rec.contact_name;
          v_params(2) := cr_get_user_info_rec.group_id;
          v_params(3) := cr_get_user_info_rec.user_id;
          v_params(4) := cr_get_user_info_rec.pwd;
          v_params(5) := v_url_name;
        
        ELSIF (v_message_type_id = 'PROVIDER_USER_ID') THEN
          v_params(1) := cr_get_user_info_rec.group_id;
          v_params(2) := cr_get_user_info_rec.user_id;
          v_params(3) := cr_get_user_info_rec.pwd;
          v_email_id := cr_get_user_info_rec.primary_email_id;
          v_sec_rcpt_list := v_sec_email_cur.secn_mail_id;
       
       -- For Password for Provider     
       ELSIF (v_message_type_id = 'FORGOT_PASSWORD_HOSP') THEN
          v_params(1) := cr_get_user_info_rec.contact_name;
          v_params(2) := cr_get_user_info_rec.user_id;
          v_params(3) := cr_get_user_info_rec.pwd;
          v_params(4) := toll_free_rec.toll_free_no;
          v_email_id := cr_get_user_info_rec.primary_email_id;
        
        ELSIF (v_message_type_id = 'FORGOT_PASSWORD_PROV') THEN
          -- Email
          v_params(1) := cr_get_user_info_rec.contact_name;
          v_params(2) := cr_get_user_info_rec.user_id;
          v_params(3) := cr_get_user_info_rec.pwd;
          v_params(4) := toll_free_rec.toll_free_no;
		ELSIF (v_message_type_id = 'FORGOT_PASSWORD_HR') THEN
          -- Email
          v_params(1) := cr_get_user_info_rec.contact_name;
          v_params(2) := cr_get_user_info_rec.group_id;
          v_params(3) := cr_get_user_info_rec.user_id;
          v_params(4) := cr_get_user_info_rec.pwd;
          v_params(5) := cr_get_user_info_rec.tollfree_num;
		  
		  ELSIF (v_message_type_id = 'HR_UPLOADED_FILE') THEN
          -- Email
          --v_params(1) := 'Your file has been uploaded successfully.';
          v_email_id := v_prm_rcpt_list;
           v_params(1) := hr_info_cur_rec.name;
          v_params(2) := hr_info_cur_rec.id;
          v_params(3) := hr_info_cur_rec.policynum;
          v_params(4) := hr_info_cur_rec.userId;
          v_params(5) := hr_info_cur_rec.hdate;
          v_sec_rcpt_list := v_sec_rcpt_list;
          ELSIF (v_message_type_id = 'RESET_PASSWORD_NHCP') THEN
          -- FOR NHCP USERS
          v_params(1) := cr_get_user_info_rec.contact_name;
		      v_params(2) :=cr_get_user_info_rec.group_id;
          v_params(3) := cr_get_user_info_rec.user_id;
          v_params(4) := cr_get_user_info_rec.pwd;
          --v_params(4) := v_url_name;         
            ----------------------------------------------------------------------------------    
       ------------------------NEWLY ADDED FOR PARTNER FOR NEW USER ID FOR NEW USER DURING SAVE CONTACTS IN EMPANELLMENT
        -- For partner  
      
      	ELSIF (v_message_type_id = 'PARTNER_USER_ID') THEN   ----------------newly added 
          v_params(1) := cr_get_user_info_rec.group_id;
          v_params(2) := cr_get_user_info_rec.user_id;
          v_params(3) := cr_get_user_info_rec.pwd;
          v_email_id :=  cr_get_user_info_rec.primary_email_id;
          v_sec_rcpt_list := v_sec_email_cur.secn_mail_id;
         
         ---------------------NEWLY ADDED FOR PARTNER FOR FORGOT PASSWORD DURING ONLINE PARTNER LOGIN 
         
         ELSIF (v_message_type_id = 'FORGOT_PASSWORD_PATR') THEN
          -- Email
          v_params(1) := cr_get_user_info_rec.contact_name;
          v_params(2) := cr_get_user_info_rec.user_id;
          v_params(3) := cr_get_user_info_rec.pwd;
       -- v_params(4) := cr_get_user_info_rec.tollfree_num;
	      v_params(4) := toll_free_rec.toll_free_no; ---newly added for toll free no for partner
  
  --------------------------------------------------------------------------------------    
		ELSIF (v_message_type_id = 'MAIL_USER_PASSWORD') THEN
          -- Email
          v_params(1) := cr_get_user_info_rec.contact_name;
          v_params(2) := cr_get_user_info_rec.user_id;
          v_params(3) := cr_get_user_info_rec.pwd;
          v_params(4) := cr_get_user_info_rec.tollfree_num;
          
          	ELSIF (v_message_type_id = 'CALL_USER_PASSWORD') THEN
          -- Email
          v_params(1) := cr_get_user_info_rec.contact_name;
          v_params(2) := cr_get_user_info_rec.user_id;
          v_params(3) := cr_get_user_info_rec.pwd;
          v_params(4) := cr_get_user_info_rec.tollfree_num;        
           
        ELSIF (v_message_type_id = 'BROKER_USER_ID') THEN
          v_params(1) := cr_get_user_info_rec.group_id;
          v_params(2) := cr_get_user_info_rec.user_id;
          v_params(3) := cr_get_user_info_rec.pwd;
          v_email_id := cr_get_user_info_rec.primary_email_id;
          v_sec_rcpt_list := v_sec_email_cur.secn_mail_id;
          
         ELSIF (v_message_type_id = 'HR_CONFIRMATION_FILE_UPLOADED') THEN 
          v_sec_rcpt_list := v_sec_email_cur.secn_mail_id;
          
         ELSIF (v_message_type_id ='USER_ASSIGNED_CLAIM') THEN
            OPEN clim_assign_user_cur(v_additional_param);
            FETCH clim_assign_user_cur INTO clim_assign_user_rec;
            CLOSE clim_assign_user_cur;

            
            v_params(1) := cr_get_user_info_rec.contact_name;
            v_params(2) := case when clim_assign_user_rec.type_of_claim='Member' then 'Reimbursement' else clim_assign_user_rec.type_of_claim end;
            v_params(3) := clim_assign_user_rec.claim_number;
            v_params(4) := clim_assign_user_rec.vip_yn;
            v_params(5) := cr_get_user_info_rec.contact_name;
            v_params(6) := to_char(sysdate,'dd/mm/yyyy')||' at '||to_char(sysdate,'hh:mi AM');
            v_params(7) := case when clim_assign_user_rec.claim_type='CTM' then null
                                else ', for the treatment at'||' '|| clim_assign_user_rec.hosp_name end;
            v_params(8) := 1 ;
            v_params(9) := clim_assign_user_rec.batch_no;
            v_params(10) := clim_assign_user_rec.type_of_claim;
            v_params(11) := clim_assign_user_rec.alkoot_id;
            v_params(12) := clim_assign_user_rec.patient_name;
            v_params(13) := clim_assign_user_rec.group_name;
            v_params(14) := clim_assign_user_rec.policy_number;
            v_params(15) := clim_assign_user_rec.benifit_type;
            v_params(16) := clim_assign_user_rec.invoice_number;
            v_params(17) := clim_assign_user_rec.claimed_amount;
            v_params(18) := v_additional_param_2;
            -----
            v_SMS_params(1):= clim_assign_user_rec.vip_yn;
            v_SMS_params(2):= clim_assign_user_rec.claim_number;
            ---
            v_email_id :=NULL;
            v_sec_rcpt_list := NULL;
            v_sms_phone:=NULL;
               ---For Email      
              IF (clim_assign_user_rec.vip_yn='VIP' AND user_assigned_flags_rec.vip_clm_email='Y') THEN
                  IF (clim_assign_user_rec.type_of_claim ='Member' and  user_assigned_flags_rec.vip_clm_ctm_req='Y') THEN
                     IF user_assigned_flags_rec.vip_clm_primary='Y' AND user_assigned_flags_rec.vip_clm_alternate='Y' THEN
                        v_email_id:=cr_get_user_info_rec.primary_email_id||case when cr_get_user_info_rec.secondary_email_id is not null then  ',' else null end  ||cr_get_user_info_rec.secondary_email_id;
                     ELSIF  user_assigned_flags_rec.vip_clm_primary='Y' AND user_assigned_flags_rec.vip_clm_alternate='N' THEN                    
                          v_email_id:=cr_get_user_info_rec.primary_email_id;
                     ELSIF  user_assigned_flags_rec.vip_clm_primary='N' AND user_assigned_flags_rec.vip_clm_alternate='Y' THEN                    
                          v_email_id:=cr_get_user_info_rec.secondary_email_id;
                     ELSE  v_email_id:=NULL; v_sec_rcpt_list :=NULL;
                     END IF;
                  END IF ;       
               END IF;
              IF (clim_assign_user_rec.vip_yn='VIP' AND user_assigned_flags_rec.vip_clm_email='Y') THEN
                  IF (clim_assign_user_rec.type_of_claim ='Network' and  user_assigned_flags_rec.vip_clm_cnh_req='Y') THEN
                     IF user_assigned_flags_rec.vip_clm_primary='Y' AND user_assigned_flags_rec.vip_clm_alternate='Y' THEN
                        v_email_id:=cr_get_user_info_rec.primary_email_id||case when cr_get_user_info_rec.secondary_email_id is not null then  ',' else null end  ||cr_get_user_info_rec.secondary_email_id;
                     ELSIF  user_assigned_flags_rec.vip_clm_primary='Y' AND user_assigned_flags_rec.vip_clm_alternate='N' THEN                    
                          v_email_id:=cr_get_user_info_rec.primary_email_id;
                     ELSIF  user_assigned_flags_rec.vip_clm_primary='N' AND user_assigned_flags_rec.vip_clm_alternate='Y' THEN                    
                          v_email_id:=cr_get_user_info_rec.secondary_email_id;
                     ELSE  v_email_id:=NULL; v_sec_rcpt_list :=NULL; 
                     END IF ;   
                  END IF;
               END IF;
               IF (clim_assign_user_rec.vip_yn='NON-VIP' AND user_assigned_flags_rec.non_vip_clm_email='Y') THEN        
                  IF (clim_assign_user_rec.type_of_claim ='Member' and  user_assigned_flags_rec.non_vip_clm_ctm_req='Y') THEN        
                       IF user_assigned_flags_rec.non_vip_clm_primary='Y' AND user_assigned_flags_rec.non_vip_clm_alternate='Y' THEN
                            v_email_id:=cr_get_user_info_rec.primary_email_id||case when cr_get_user_info_rec.secondary_email_id is not null then  ',' else null end  ||cr_get_user_info_rec.secondary_email_id;
                       ELSIF  user_assigned_flags_rec.non_vip_clm_primary='Y' AND user_assigned_flags_rec.non_vip_clm_alternate='N' THEN                    
                            v_email_id:=cr_get_user_info_rec.primary_email_id;
                       ELSIF  user_assigned_flags_rec.non_vip_clm_primary='N' AND user_assigned_flags_rec.non_vip_clm_alternate='Y' THEN                    
                            v_email_id:=cr_get_user_info_rec.secondary_email_id;
                       ELSE  v_email_id:=NULL; v_sec_rcpt_list :=NULL; 
                       END IF ; 
                  END IF;
               END IF;
               IF (clim_assign_user_rec.vip_yn='NON-VIP' AND user_assigned_flags_rec.non_vip_clm_email='Y') THEN        
                  IF (clim_assign_user_rec.type_of_claim ='Network' and  user_assigned_flags_rec.non_vip_clm_cnh_req='Y') THEN        
                       IF user_assigned_flags_rec.non_vip_clm_primary='Y' AND user_assigned_flags_rec.non_vip_clm_alternate='Y' THEN
                            v_email_id:=cr_get_user_info_rec.primary_email_id||case when cr_get_user_info_rec.secondary_email_id is not null then  ',' else null end  ||cr_get_user_info_rec.secondary_email_id;
                       ELSIF  user_assigned_flags_rec.non_vip_clm_primary='Y' AND user_assigned_flags_rec.non_vip_clm_alternate='N' THEN                    
                            v_email_id:=cr_get_user_info_rec.primary_email_id;
                       ELSIF  user_assigned_flags_rec.non_vip_clm_primary='N' AND user_assigned_flags_rec.non_vip_clm_alternate='Y' THEN                    
                            v_email_id:=cr_get_user_info_rec.secondary_email_id;
                       ELSE  v_email_id:=NULL; v_sec_rcpt_list :=NULL; 
                       END IF ; 
                   END IF;
                END IF;
               ---For SMS
              IF (clim_assign_user_rec.vip_yn='VIP' AND user_assigned_flags_rec.vip_clm_sms='Y') THEN
                  IF (clim_assign_user_rec.type_of_claim ='Member' and  user_assigned_flags_rec.vip_clm_ctm_req='Y') THEN
                     IF user_assigned_flags_rec.vip_clm_primary='Y' AND user_assigned_flags_rec.vip_clm_alternate='Y' THEN
                         v_sms_phone:=nvl(cr_get_user_info_rec.mobile_no,cr_get_user_info_rec.off_phone_no_1)||case when cr_get_user_info_rec.off_phone_no_2 is not null then  ',' else null end||cr_get_user_info_rec.off_phone_no_2;
                     ELSIF  user_assigned_flags_rec.vip_clm_primary='Y' AND user_assigned_flags_rec.vip_clm_alternate='N' THEN                    
                          v_sms_phone:=nvl(cr_get_user_info_rec.mobile_no,cr_get_user_info_rec.off_phone_no_1);
                     ELSIF  user_assigned_flags_rec.vip_clm_primary='N' AND user_assigned_flags_rec.vip_clm_alternate='Y' THEN                    
                          v_sms_phone:=cr_get_user_info_rec.off_phone_no_2;
                     ELSE v_sms_phone:=NULL;
                     END IF;
                  END IF ;       
               END IF;
              IF (clim_assign_user_rec.vip_yn='VIP' AND user_assigned_flags_rec.vip_clm_sms='Y') THEN
                  IF (clim_assign_user_rec.type_of_claim ='Network' and  user_assigned_flags_rec.vip_clm_cnh_req='Y') THEN
                     IF user_assigned_flags_rec.vip_clm_primary='Y' AND user_assigned_flags_rec.vip_clm_alternate='Y' THEN
                        v_sms_phone:=nvl(cr_get_user_info_rec.mobile_no,cr_get_user_info_rec.off_phone_no_1)||case when cr_get_user_info_rec.off_phone_no_2 is not null then  ',' else null end||cr_get_user_info_rec.off_phone_no_2;
                     ELSIF  user_assigned_flags_rec.vip_clm_primary='Y' AND user_assigned_flags_rec.vip_clm_alternate='N' THEN                    
                        v_sms_phone:=nvl(cr_get_user_info_rec.mobile_no,cr_get_user_info_rec.off_phone_no_1);
                     ELSIF  user_assigned_flags_rec.vip_clm_primary='N' AND user_assigned_flags_rec.vip_clm_alternate='Y' THEN                    
                        v_sms_phone:=cr_get_user_info_rec.off_phone_no_2;
                     ELSE  v_sms_phone:=NULL;
                     END IF ;   
                  END IF;
               END IF;
               IF (clim_assign_user_rec.vip_yn='NON-VIP' AND user_assigned_flags_rec.non_vip_clm_sms='Y') THEN        
                   IF (clim_assign_user_rec.type_of_claim ='Member' and  user_assigned_flags_rec.non_vip_clm_ctm_req='Y') THEN        
                       IF user_assigned_flags_rec.non_vip_clm_primary='Y' AND user_assigned_flags_rec.non_vip_clm_alternate='Y' THEN
                            v_sms_phone:=nvl(cr_get_user_info_rec.mobile_no,cr_get_user_info_rec.off_phone_no_1)||case when cr_get_user_info_rec.off_phone_no_2 is not null then  ',' else null end||cr_get_user_info_rec.off_phone_no_2;
                       ELSIF  user_assigned_flags_rec.non_vip_clm_primary='Y' AND user_assigned_flags_rec.non_vip_clm_alternate='N' THEN                    
                            v_sms_phone:=nvl(cr_get_user_info_rec.mobile_no,cr_get_user_info_rec.off_phone_no_1);
                       ELSIF  user_assigned_flags_rec.non_vip_clm_primary='N' AND user_assigned_flags_rec.non_vip_clm_alternate='Y' THEN                    
                            v_sms_phone:=cr_get_user_info_rec.off_phone_no_2;
                       ELSE  v_sms_phone:=NULL;
                       END IF ; 
                  END IF;
               END IF;
               IF (clim_assign_user_rec.vip_yn='NON-VIP' AND user_assigned_flags_rec.non_vip_clm_sms='Y') THEN        
                  IF (clim_assign_user_rec.type_of_claim ='Network' and  user_assigned_flags_rec.non_vip_clm_cnh_req='Y') THEN        
                       IF user_assigned_flags_rec.non_vip_clm_primary='Y' AND user_assigned_flags_rec.non_vip_clm_alternate='Y' THEN
                            v_sms_phone:=nvl(cr_get_user_info_rec.mobile_no,cr_get_user_info_rec.off_phone_no_1)||case when cr_get_user_info_rec.off_phone_no_2 is not null then  ',' else null end||cr_get_user_info_rec.off_phone_no_2;
                       ELSIF  user_assigned_flags_rec.non_vip_clm_primary='Y' AND user_assigned_flags_rec.non_vip_clm_alternate='N' THEN                    
                            v_sms_phone:=nvl(cr_get_user_info_rec.mobile_no,cr_get_user_info_rec.off_phone_no_1);
                       ELSIF  user_assigned_flags_rec.non_vip_clm_primary='N' AND user_assigned_flags_rec.non_vip_clm_alternate='Y' THEN                    
                            v_sms_phone:=cr_get_user_info_rec.off_phone_no_2;
                       ELSE  v_sms_phone:=NULL; 
                       END IF ; 
                   END IF;
                END IF;
                           
              --USER ASSIGNED claims FLAGS VALIDATION END--- 
     ELSIF (v_message_type_id ='USER_ASSIGNED_PREAUTH') THEN
     
        OPEN   pat_assign_user_cur(v_additional_param);
        FETCH pat_assign_user_cur INTO pat_assign_user_rec;
        CLOSE pat_assign_user_cur;

        v_params(1) := cr_get_user_info_rec.contact_name;
        v_params(2) := pat_assign_user_rec.pre_auth_number;
        v_params(3) := pat_assign_user_rec.vip_yn;
        v_params(4) := cr_get_user_info_rec.contact_name;
        v_params(5) := to_char(sysdate,'dd/mm/yyyy')||' at '||to_char(sysdate,'hh:mi AM');
        v_params(6) := pat_assign_user_rec.hosp_name;
        v_params(7) := 1;
        v_params(8) := to_char(pat_assign_user_rec.pat_received_date,'dd/mm/yyyy hh:mi AM');
        v_params(9) := pat_assign_user_rec.alkoot_id;
        v_params(10) := pat_assign_user_rec.patient_name;
        v_params(11) := pat_assign_user_rec.group_name;
        v_params(12) := pat_assign_user_rec.policy_number;
        v_params(13) := pat_assign_user_rec.benifit_type;
        v_params(14) := pat_assign_user_rec.req_amount;
        v_params(15) := v_additional_param_2;
        ---
        v_SMS_params(1) := pat_assign_user_rec.vip_yn;
        v_SMS_params(2) := pat_assign_user_rec.pre_auth_number;
        --
        v_email_id :=NULL;
        v_sec_rcpt_list := NULL;
        v_sms_phone:=NULL;
                    
              IF (pat_assign_user_rec.vip_yn='VIP' AND user_assigned_flags_rec.vip_pat_email='Y') THEN
                IF user_assigned_flags_rec.vip_pat_cnh_req ='Y' THEN
                     IF user_assigned_flags_rec.vip_pat_primary='Y' AND user_assigned_flags_rec.vip_pat_alternate='Y' THEN
                        v_email_id:=cr_get_user_info_rec.primary_email_id||case when cr_get_user_info_rec.secondary_email_id is not null then  ',' else null end  ||cr_get_user_info_rec.secondary_email_id;
                     ELSIF  user_assigned_flags_rec.vip_pat_primary='Y' AND user_assigned_flags_rec.vip_pat_alternate='N' THEN                    
                          v_email_id:=cr_get_user_info_rec.primary_email_id;
                     ELSIF  user_assigned_flags_rec.vip_pat_primary='N' AND user_assigned_flags_rec.vip_pat_alternate='Y' THEN                    
                          v_email_id:=cr_get_user_info_rec.secondary_email_id;
                     END IF;
                 END IF;
               END IF;               
              IF (pat_assign_user_rec.vip_yn='NON-VIP' AND user_assigned_flags_rec.non_vip_pat_email='Y') THEN
                IF user_assigned_flags_rec.non_vip_pat_cnh_req ='Y' THEN
                     IF user_assigned_flags_rec.non_vip_pat_primary='Y' AND user_assigned_flags_rec.non_vip_pat_alternate='Y' THEN
                        v_email_id:=cr_get_user_info_rec.primary_email_id||case when cr_get_user_info_rec.secondary_email_id is not null then  ',' else null end  ||cr_get_user_info_rec.secondary_email_id;
                     ELSIF  user_assigned_flags_rec.non_vip_pat_primary='Y' AND user_assigned_flags_rec.non_vip_pat_alternate='N' THEN                    
                          v_email_id:=cr_get_user_info_rec.primary_email_id;
                     ELSIF  user_assigned_flags_rec.non_vip_pat_primary='N' AND user_assigned_flags_rec.non_vip_pat_alternate='Y' THEN                    
                          v_email_id:=cr_get_user_info_rec.secondary_email_id;
                     END IF;
                  END IF;
               END IF;
      ---For SMS...
             IF (pat_assign_user_rec.vip_yn='VIP' AND user_assigned_flags_rec.vip_pat_sms='Y') THEN
               IF user_assigned_flags_rec.vip_pat_cnh_req ='Y' THEN
                 IF user_assigned_flags_rec.vip_pat_primary='Y' AND user_assigned_flags_rec.vip_pat_alternate='Y' THEN
                          v_sms_phone:= nvl(cr_get_user_info_rec.mobile_no,cr_get_user_info_rec.off_phone_no_1)||case when cr_get_user_info_rec.off_phone_no_2 is not null then  ',' else null end ||cr_get_user_info_rec.off_phone_no_2;
                 ELSIF  user_assigned_flags_rec.vip_pat_primary='Y' AND user_assigned_flags_rec.vip_pat_alternate='N' THEN                    
                          v_sms_phone:=nvl(cr_get_user_info_rec.mobile_no,cr_get_user_info_rec.off_phone_no_1);
                 ELSIF  user_assigned_flags_rec.vip_pat_primary='N' AND user_assigned_flags_rec.vip_pat_alternate='Y' THEN                    
                          v_sms_phone:=cr_get_user_info_rec.off_phone_no_2;
                 ELSE   v_sms_phone := NULL;                
                 END IF; 
               END IF;
              END IF;
             IF (pat_assign_user_rec.vip_yn='NON-VIP' AND user_assigned_flags_rec.non_vip_pat_sms='Y') THEN
               IF user_assigned_flags_rec.non_vip_pat_cnh_req ='Y' THEN
                     IF user_assigned_flags_rec.non_vip_pat_primary='Y' AND user_assigned_flags_rec.non_vip_pat_alternate='Y' THEN
                        v_sms_phone:=nvl(cr_get_user_info_rec.mobile_no,cr_get_user_info_rec.off_phone_no_1)||case when cr_get_user_info_rec.off_phone_no_2 is not null then  ',' else null end||cr_get_user_info_rec.off_phone_no_2;
                     ELSIF  user_assigned_flags_rec.non_vip_pat_primary='Y' AND user_assigned_flags_rec.non_vip_pat_alternate='N' THEN                    
                        v_sms_phone:=nvl(cr_get_user_info_rec.mobile_no,cr_get_user_info_rec.off_phone_no_1);
                     ELSIF  user_assigned_flags_rec.non_vip_pat_primary='N' AND user_assigned_flags_rec.non_vip_pat_alternate='Y' THEN                    
                        v_sms_phone:=cr_get_user_info_rec.off_phone_no_2;
                     ELSE   v_sms_phone := NULL;
                     END IF;
               END IF; 
             END IF;
        END IF;
        -- This part is for Online Enrollment Window Period mail generation
      ELSIF (v_message_type_id = 'ONLINE_EMPLOYEE_FAMILY_INFO') THEN
        -- GET THE EMPLOYEE INFORMATION
        OPEN cr_get_employee_details(v_parameters);
        FETCH cr_get_employee_details
          INTO cr_get_employee_cred_REC;
        CLOSE cr_get_employee_details;
        
        SELECT COUNT(1) INTO v_tot_depend_cnt
         FROM tpa_enr_policy_group pg 
         JOIN tpa_enr_policy_member m ON (pg.policy_group_seq_id = m.policy_group_seq_id)
         WHERE pg.policy_group_seq_id = v_parameters
            AND m.status_general_type_id != 'POC'
            AND m.deleted_yn = 'N';
      
        v_email_id  := cr_get_employee_cred_REC.Email_Id;
        v_params(1) := cr_get_employee_cred_REC.Insured_Name;
        v_params(2) := v_tot_depend_cnt;
        v_params(3) := cr_get_employee_cred_REC.Insured_Name;
        v_params(4) := cr_get_employee_cred_REC.Policy_Number;
        v_params(5) := cr_get_employee_cred_REC.Tpa_Enrollment_Id;
        v_params(6) := cr_get_employee_cred_REC.Gender;
        v_params(7) := cr_get_employee_cred_REC.Date_Of_Birth;
        v_params(8) := cr_get_employee_cred_REC.Effective_From_Date;
        v_params(9) := cr_get_employee_cred_REC.Date_Of_Inception;
        v_params(10) := cr_get_employee_cred_REC.Effective_To_Date;
        v_params(11) := cr_get_employee_cred_REC.Date_Of_Exit;
        v_pol_tob :=  cr_get_employee_cred_REC.Pol_Tob_Doc;
        v_document_name := cr_get_employee_cred_REC.Policy_Seq_Id;
        
        
      
        -- If show Sum insured is configured in Wbe Config, then do it.
        
     /*  v_params(6) := '-';
       --v_params(6) := '-';
        IF (cr_get_employee_cred_REC.include_sum_general_type_id = 'MSY') THEN
          -- Show Only SI
          IF (cr_get_employee_cred_REC.Policy_Sub_General_Type_Id = 'PFL') THEN
            v_params(6) := TRIM(TO_CHAR(cr_get_employee_cred_REC.Family_Tot_Sum_Insured,
                                        '99G99G99G999D99'));
          END IF;
        ELSIF (cr_get_employee_cred_REC.include_sum_general_type_id = 'MSP') THEN
          -- Show Only SI 
          IF (cr_get_employee_cred_REC.Policy_Sub_General_Type_Id = 'PFL') THEN
            v_params(6) := TRIM(TO_CHAR(cr_get_employee_cred_REC.Family_Tot_Sum_Insured,
                                        '99G99G99G999D99'));
            --v_params(6) := TRIM(TO_CHAR(cr_get_employee_cred_REC.Floater_Premium,'99G99G99G999D99'));
          END IF;
        END IF;*/
      
        -- GET THE MEMBER INFORMATION
        v_params(12) := NULL;
      
        FOR rec IN cr_get_employee_member_details(cr_get_employee_cred_REC.policy_group_seq_id) LOOP
          v_member_info := '<tr><td>' || rec.tpa_enrollment_id ||
                        	 '</td><td>' || rec.mem_name ||
                           '</td><td>' || rec.date_of_birth || '</td><td> ' ||
                           rec.gender || '</td><td>' ||
                           rec.Relship_Description || '</td></tr>';
        
        
        
          /*IF (cr_get_employee_cred_REC.include_sum_general_type_id = 'MSN') THEN
            v_member_info := v_member_info || '- </td></tr>';
          ELSIF (cr_get_employee_cred_REC.include_sum_general_type_id =
                'MSY') THEN
            -- Only SI
            IF (cr_get_employee_cred_REC.Policy_Sub_General_Type_Id = 'PFL') THEN
              v_member_info := v_member_info || '-</td></tr>';
            ELSE
              v_member_info := v_member_info ||
                               TRIM(TO_CHAR(rec.member_sum_insured,
                                            '99G99G99G999D99')) ||
                               '</td></tr>';
            END IF;
          ELSIF (cr_get_employee_cred_REC.include_sum_general_type_id =
                'MSP') THEN
            -- Only SI and Premium
            IF (cr_get_employee_cred_REC.Policy_Sub_General_Type_Id = 'PFL') THEN
              v_member_info := v_member_info || '-</td></tr>';
            ELSE
              v_member_info := v_member_info ||
                               TRIM(TO_CHAR(rec.member_sum_insured,
                                            '99G99G99G999D99')) ||
                               '</td><td>' ||
                               TRIM(TO_CHAR(rec.member_premium,
                                            '99G99G99G999D99')) ||
                               '</td></tr>';
            END IF;
          END IF;*/
        
          IF (v_params(12) IS NULL) THEN
            v_params(12) := v_member_info;
          ELSE
            v_params(12) := v_params(12) || v_member_info;
          END IF;
        END LOOP;
          
            v_params(13) := '180000XXXX';
        
        -- For SMS Generation
          v_SMS_params(1) := cr_get_employee_cred_REC.Insured_Name;
          v_SMS_params(2) := '180000XXXX';
          v_sms_phone     := cr_get_employee_cred_REC.Mobile_No;
  
      ELSIF v_message_type_id = 'POLICY_CERTIFICATE_REQUEST' THEN 
           v_params(1):=null;
           v_params(2):=NULL;
         v_member_seq_idS := RTRIM(LTRIM (REPLACE(TO_CHAR(v_parameters),'|',','),','),',');
         
         EXECUTE IMMEDIATE 'SELECT Mem.Tpa_Enrollment_Id,MEM.MEM_NAME,Rec.Relship_Description,mem.policy_group_seq_id,
                                   gr.INSURED_NAME
                                   FROM Tpa_Enr_Policy_Member MEM
                            JOIN Tpa_Relationship_Code REC ON (Mem.Relship_Type_Id=REC.RELSHIP_TYPE_ID)
                            JOIN Tpa_Enr_Mem_Address mema on (mem.ENR_ADDRESS_SEQ_ID=mema.ENR_ADDRESS_SEQ_ID)
                            JOIN Tpa_Enr_policy_Group gr on (mem.POLICY_GROUP_SEQ_ID=gr.POLICY_GROUP_SEQ_ID)
                            WHERE Mem.Member_Seq_Id IN ('||v_member_seq_idS ||') ' BULK COLLECT INTO Mem_Part_Info_R;
                            
       FOR  rec in Mem_Part_Info_R.first..Mem_Part_Info_R.last LOOP
         v_member_info := '<tr>
                                    <td>' || Mem_Part_Info_R(rec).member_id ||'</td>
                        	          <td>' || Mem_Part_Info_R(rec).member_name ||'</td>
                                    <td>' || Mem_Part_Info_R(rec).member_relation || '</td>
                                 </tr>'; 
       IF v_params(2) IS NOT NULL THEN
          v_params(2) :=  v_params(2) ||v_member_info; 
        ELSE
          v_params(2) :=v_member_info ;
       END IF;
                               
        v_policy_grp_seq :=  Mem_Part_Info_R(rec).policy_grp_seq;
        v_params(1) := Mem_Part_Info_R(rec).email_id;
       END LOOP; 
         
         SELECT sm.prm_rcpt_email_list  into v_email_id
          FROM app.source_message sm WHERE sm.msg_id='POLICY_CERTIFICATE_REQUEST';  
  ----------***********************HR LOGIN*****************-----------------------------        
 ---------****************NEWLY ADDED FOR MEMBER IN HR LOGIN******************-----------------        
 
    ELSIF (v_message_type_id = 'HR_NEW_MEMBER_ADDITION') THEN  
  
         str_tab                            := ttk_util_pkg.parse_str ( v_parameters );
         
         OPEN  cr_get_hr_mem_add_details(str_tab(1),str_tab(2));
         FETCH cr_get_hr_mem_add_details  INTO hr_member_info;
         CLOSE cr_get_hr_mem_add_details;
         
         v_hr_parms  := to_char(str_tab(1));
  
        v_mail_merge := hr_member_info.Email_Id||','||v_prm_rcpt_list;
        
        v_email_id  :=  rtrim(v_mail_merge,',');
        v_params(1) := hr_member_info.mem_name;
        v_params(2) := hr_member_info.group_name;
        v_params(3) := hr_member_info.policy_number;
        v_params(4) := hr_member_info.effective_from_date;
        v_params(5) := hr_member_info.effective_to_date;
        v_params(6) := hr_member_info.tpa_enrollment_id;
        v_params(7) := hr_member_info.relship_description;
        v_params(8) := hr_member_info.date_of_inception;
        v_params(9) := hr_member_info.date_of_exit;
        v_params(10) := hr_member_info.gender;
        v_params(11) := hr_member_info.date_of_birth;
        v_params(12) := hr_member_info.description;
        v_params(13) := hr_member_info.marital_status;
        v_params(14) := hr_member_info.emirate_id;
        v_params(15) := hr_member_info.passport_number;
        v_params(16) := hr_member_info.email_id1;
        v_params(17) := hr_member_info.mobile_no;
        v_params(18) := hr_member_info.added_by;
        v_params(19) := hr_member_info.added_date;
        v_sec_rcpt_list := v_sec_rcpt_list; 
        
        
   ELSIF (v_message_type_id = 'CORPORATE_HR_MEMBER_DELETION') THEN   
   
       OPEN  group_mem_count_cur(v_parameters);
       FETCH group_mem_count_cur INTO rec_count;
       CLOSE group_mem_count_cur;
       
   IF rec_count > 0 then 
   
       OPEN cr_hr_group_dtls_cur(v_parameters);
       FETCH cr_hr_group_dtls_cur INTO hr_group_dtls;
       CLOSE cr_hr_group_dtls_cur;
         
        v_mail_merge := hr_group_dtls.email_Id||','||v_prm_rcpt_list;
        
        v_email_id  :=  rtrim(v_mail_merge,',');
             
       --- v_email_id  := hr_group_dtls.Email_Id;
        v_params(1) := hr_group_dtls.mem_name;
        v_params(2) := hr_group_dtls.group_name;
        v_params(3) := hr_group_dtls.policy_number;
        v_params(4) := hr_group_dtls.effective_from_date;
        v_params(5) := hr_group_dtls.effective_to_date;
        v_params(6) := hr_group_dtls.tpa_enrollment_id;
        v_params(7) := hr_group_dtls.relship_description;
        v_params(8) := hr_group_dtls.date_of_inception;
        v_params(9) := hr_group_dtls.date_of_exit;
        v_params(11):= hr_group_dtls.added_by;
        v_params(12):= hr_group_dtls.added_date;
        v_sec_rcpt_list := v_sec_rcpt_list; 
        
         v_params(10) := null;
   
         OPEN  cr_get_hr_mem_del_details(v_parameters);
         FETCH cr_get_hr_mem_del_details  INTO mem_del_dtls;
         CLOSE cr_get_hr_mem_del_details;

          FOR i IN cr_get_hr_mem_del_details(v_parameters) LOOP 
      
            v_member_details :=       '<tr><td>'  || i.mem_name ||
                                      '</td><td>' || i.tpa_enrollment_id || 
                                      '</td><td> '|| i.relship_description || 
                                      '</td><td>' || i.date_of_exit ||             
                                      '</td></tr>';   
            IF (v_params(10) IS NULL) THEN
               v_params(10) := v_member_details;
            ELSE
               v_params(10) := v_params(10) || v_member_details;
            END IF;  
      
          END LOOP;      
         
        
    ELSE
       
       OPEN  cr_hr_member_dtls_cur(v_parameters);
       FETCH cr_hr_member_dtls_cur  INTO hr_member_dtls;
       CLOSE cr_hr_member_dtls_cur;
       
        v_mail_merge := hr_member_dtls.email_Id||','||v_prm_rcpt_list;
        
        v_email_id  :=  rtrim(v_mail_merge,',');
        v_params(1) := hr_member_dtls.mem_name;
        v_params(2) := hr_member_dtls.group_name;
        v_params(3) := hr_member_dtls.policy_number;
        v_params(4) := hr_member_dtls.effective_from_date;
        v_params(5) := hr_member_dtls.effective_to_date;
        v_params(6) := hr_member_dtls.tpa_enrollment_id;
        v_params(7) := hr_member_dtls.relship_description;
        v_params(8) := hr_member_dtls.date_of_inception;
        v_params(9) := hr_member_dtls.date_of_exit;
        v_params(11):= hr_member_dtls.added_by;
        v_params(12):= hr_member_dtls.added_date;
        v_sec_rcpt_list := v_sec_rcpt_list; 
        
         OPEN  cr_get_hr_mem_del1_details(v_parameters);
         FETCH cr_get_hr_mem_del1_details  INTO mem_del_dtls1;
         CLOSE cr_get_hr_mem_del1_details;

          FOR i IN cr_get_hr_mem_del1_details(v_parameters) LOOP 
      
            v_member_details :=       '<tr><td>'  || i.mem_name ||
                                      '</td><td>' || i.tpa_enrollment_id || 
                                      '</td><td> '|| i.relship_description || 
                                      '</td><td>' || i.date_of_exit ||             
                                      '</td></tr>';   
            IF (v_params(10) IS NULL) THEN
               v_params(10) := v_member_details;
            ELSE
               v_params(10) := v_params(10) || v_member_details;
            END IF;  
      
          END LOOP;      
        
         
     END IF;
       ELSIF v_message_type_id = 'MEMBER_CARD_REQUEST' THEN
     
         IF v_additional_param = 'MEM' THEN
           OPEN mem_card_cur(v_parameters);
           FETCH mem_card_cur INTO mem_card_rec;
           CLOSE mem_card_cur;
           
           v_member_details := 'Al Koot ID:    '|| mem_card_rec.mem_id ||'<br>'||
                               'Member Name:   '|| mem_card_rec.mem_name ||'<br>'||
                               'Corporate Name:'|| mem_card_rec.corp_name ||'<br>'||
                               'Policy No.:    '|| mem_card_rec.policy_number ||'<br><br>'; 
                               
           v_params(1) := mem_card_rec.user_id;
           v_params(2) := mem_card_rec.primary_email_id; 
           v_params(3) := v_member_details;
           v_email_id  := v_prm_rcpt_list;
         ELSE
           
           FOR mem_card_rec IN grp_card_cur(v_parameters) LOOP
             v_member_details := v_member_details||'<br>'||
                                 'Al Koot ID:    '|| mem_card_rec.mem_id ||'<br>'||
                                 'Member Name:   '|| mem_card_rec.mem_name ||'<br>'||
                                 'Corporate Name:'|| mem_card_rec.corp_name ||'<br>'||
                                 'Policy No.:    '|| mem_card_rec.policy_number ||'<br><br>';
                                 
             v_params(1) := mem_card_rec.user_id;
             v_params(2) := mem_card_rec.primary_email_id; 
             v_params(3) := v_member_details;
             v_email_id  := v_prm_rcpt_list;
           END LOOP;
         END IF;
         
        /* v_params(10) := null;
   
         OPEN  cr_get_hr_mem_del_details(v_parameters);
         FETCH cr_get_hr_mem_del_details  INTO mem_del_dtls;
         CLOSE cr_get_hr_mem_del_details;

    FOR i IN cr_get_hr_mem_del_details(v_parameters) LOOP 
      
      v_member_details :=       '<tr><td>'  || i.mem_name ||
                                '</td><td>' || i.tpa_enrollment_id || 
                                '</td><td> '|| i.relship_description || 
                                '</td><td>' || i.date_of_exit ||             
                                '</td></tr>';   
      IF (v_params(10) IS NULL) THEN
          v_params(10) := v_member_details;
      ELSE
          v_params(10) := v_params(10) || v_member_details;
      END IF;  
      
     END LOOP;   */   
         
                
  ------------******************************************************************************    
        -- ########### PREAUTH_STATUS and PREAUTH_STATUS_NHCP
        -- Message will be sent only through Email/SMS to the user
      ELSIF v_message_type_id ='NAMECHANGE_REPRINT_CARD' THEN
         OPEN mem_card_cur(v_parameters);
         FETCH mem_card_cur INTO mem_card_rec;
         CLOSE mem_card_cur;
         
         v_params(1) := mem_card_rec.mem_id;
         v_params(2) := mem_card_rec.mem_name;
         v_params(3) := mem_card_rec.corp_name;
         v_params(4) := mem_card_rec.policy_number;
         v_email_id  := v_prm_rcpt_list;

               
      ELSIF ((v_message_type_id = 'PREAUTH_STATUS') OR
            (v_message_type_id = 'PREAUTH_STATUS_NHCP')) THEN
        v_notification_type     := 'PREAUTH';
        v_pat_gen_detail_seq_id := v_parameters;
      
        OPEN cr_get_typeof_preauth(v_parameters);
        FETCH cr_get_typeof_preauth
          INTO v_type;
        CLOSE cr_get_typeof_preauth;
      
        --IF ( v_type = 'REG' ) THEN
        OPEN cr_get_regular_preauth(v_parameters);
        FETCH cr_get_regular_preauth
          INTO v_claimant_name,
               v_received_date,
               v_pre_auth_number,
               v_status,
               v_sms_phone,
               v_requested_amt,
               v_total_approved_amount,
               v_policy_seq_id,
               v_member_seq_id,
               v_auth_number,
               v_hosp_seq_id,
               v_email_id,
               V_INSURED_NAME,
               V_TPA_ENROLLMENT_ID,
               v_pat_status_general_type_id,
               v_remarks,
               V_HOSP_NAME;
        CLOSE cr_get_regular_preauth;
      
        -- Get Mail details for Policy Number and Member SEQ id. This also returns the Branch which owns the policy and
        -- their toll free number.
        proc_get_mail_details(v_policy_seq_id,
                              v_member_seq_id,
                              v_tpa_code,
                              v_tpa_toll_phone);
      
        
        ELSIF (v_message_type_id = 'OTP_SMS_INT') THEN
                 
          OPEN otp_cur (v_parameters);
          FETCH otp_cur into v_otp_msg;
          CLOSE otp_cur;
          
          v_params(1) := v_otp_msg.otp_number;
          v_email_id := v_otp_msg.mem_email_addr;
        --END IF;
        
        IF (v_message_type_id = 'PREAUTH_STATUS') THEN
          -- For Email Generation
          v_params(1) := v_claimant_name;
          v_params(2) := TO_CHAR(v_received_date, 'DD/MM/YYYY HH:MI AM');
          v_params(3) := v_tpa_toll_phone;
          v_params(4) := v_pre_auth_number;
        
          -- For SMS Generation
          v_SMS_params(1) := v_claimant_name;
          v_SMS_params(2) := TO_CHAR(v_received_date, 'DD/MM/YYYY HH:MI AM');
          v_SMS_params(3) := v_tpa_toll_phone;
          v_SMS_params(4) := v_pre_auth_number;
        ELSIF (v_message_type_id = 'PREAUTH_STATUS_NHCP') THEN
          -- Since mail has to be sent to Hospital EMAIL ID, the email id of the claimant is ignored.
          v_email_id := v_additional_param;
        
          -- For Email Generation
          v_params(1) := v_claimant_name;
          v_params(2) := v_tpa_toll_phone;
          v_params(3) := v_pre_auth_number;
        
        END IF;
        
      
        v_case_number := v_pre_auth_number;
        
      ELSIF (v_message_type_id = 'MOB_APP_OTP') THEN
                 
          OPEN  mob_app_otp_cur (v_parameters);
          FETCH mob_app_otp_cur into rec_mob_app_otp;
          CLOSE mob_app_otp_cur;
          
          v_params(1) := rec_mob_app_otp.otp_number;
          v_params(2) := rec_mob_app_otp.user_id;
          v_email_id  := rec_mob_app_otp.email_id;
       -- For SMS Generation
          v_SMS_params(1) := rec_mob_app_otp.otp_number;
          v_SMS_params(2) := rec_mob_app_otp.user_id;
          v_sms_phone     := rec_mob_app_otp.Mobile_No;
          
      ELSIF (v_message_type_id = 'FORGOT_MOB_APP_PSWD') THEN 
         
          OPEN  mob_app_psw_cur (v_parameters);
          FETCH mob_app_psw_cur into rec_mob_app_psw;
          CLOSE mob_app_psw_cur;
          
          v_params(1) := rec_mob_app_psw.password;
          v_params(2) := rec_mob_app_psw.user_id;
          v_email_id  := rec_mob_app_psw.email_id;
       -- For SMS Generation
          v_SMS_params(1) := rec_mob_app_psw.password;
          v_SMS_params(2) := rec_mob_app_psw.user_id;
          v_sms_phone     := rec_mob_app_psw.Mobile_No;
      
      ELSIF (v_message_type_id = 'MOB_APP_QUERY') THEN 
          
          OPEN mob_app_emp(v_parameters);
          FETCH mob_app_emp INTO mob_rec;
          CLOSE mob_app_emp;
          
          v_params(1) := v_parameters;
          v_params(2) := mob_rec.mem_name;
          v_params(3) := mob_rec.group_name;
          v_params(4) := v_additional_param;
          v_params(5) := v_additional_param_2;
          v_params(6) := v_additional_param_3;
          v_email_id  := 'customercare@alkoot-medical.com';
          
      ELSIF (v_message_type_id = 'NEW_EMP_LOGIN_QUERY') THEN
      
            OPEN empl_login_cur (v_parameters);
            FETCH empl_login_cur into empl_rec;
            CLOSE empl_login_cur;
            
            v_params(1) := empl_rec.tpa_enrollment_id;
            v_params(2) := empl_rec.mem_name;
            v_params(3) := empl_rec.mobile_no;
            v_params(4) := empl_rec.email_id;
            v_params(5) := empl_rec.group_name;
            IF v_additional_param ='PAT' THEN
            v_params(6) := 'Pre-Approval (Report To Alkoot)';
            v_params(7) := 'Pre-Approval No :';
            v_params(8) :=  v_additional_param_2;
            ELSIF v_additional_param ='CLM' THEN
            v_params(6) := 'Claims (Report To Alkoot)';
            v_params(7) := 'Claim No :';
            v_params(8) :=  v_additional_param_2;
            ELSE
            v_params(6) := 'Contact US';
            v_params(7) := 'Query Category     :';
            v_params(8) := CASE v_additional_param WHEN 'ENRL' THEN 'Enrollment'
                                                   WHEN 'PATH' THEN 'Pre-Approvals'
                                                   WHEN 'CLIM' THEN 'Claims'
                                                   WHEN 'PAYS' THEN 'Payment Status'
                                                     WHEN 'PROI' THEN 'Provider Information'
                                                       WHEN 'LOGI' THEN 'Login'
                                                         WHEN 'COMP' THEN 'Complaint'
                                                           WHEN 'OTR' THEN 'Others'
                                                             ELSE NULL END;
            END IF;
            v_params(9) := v_additional_param_3;
            v_email_id  := 'customercare@alkoot-medical.com';
          
      ELSIF (v_message_type_id = 'EMP_LOGIN_CREDENTIALS') THEN
            OPEN empl_login_cur (v_parameters);
            FETCH empl_login_cur into empl_rec;
            CLOSE empl_login_cur;
            
           v_email_id       := empl_rec.email_id;
           v_sec_rcpt_list  := empl_rec.email_id1;
           v_sms            := empl_rec.mobile_no;
           
           v_params(1)      := empl_rec.mem_name;
           v_params(2)      := empl_rec.tpa_enrollment_id;
           v_params(3)      := empl_rec.pwd;
           V_SMS_params(1)  := empl_rec.pwd;
           V_SMS_params(2)  := empl_rec.tpa_enrollment_id;
      
      ELSIF (v_message_type_id = 'MOB_APP_CLM_SUBBMIT') THEN 
          
          OPEN  clm_batch_dtls(v_parameters);
          FETCH clm_batch_dtls INTO rec_clm_batch_dtls;
          CLOSE clm_batch_dtls;
          
          v_params(1) := rec_clm_batch_dtls.batch_no;
          v_params(2) := rec_clm_batch_dtls.invoice_number;
          v_email_id  := v_additional_param;    
      
      ELSIF (v_message_type_id = 'PRICING_INITIATED') THEN
          OPEN  cur_pricing_pol_dtls(v_parameters);
          FETCH cur_pricing_pol_dtls INTO rec_pricing_pol_dtls;
          CLOSE cur_pricing_pol_dtls;
          
          v_params(1) := rec_pricing_pol_dtls.renewal_yn;
          v_params(2) := rec_pricing_pol_dtls.ref_no;
          v_params(3) := rec_pricing_pol_dtls.group_name;
          v_params(4) := TO_CHAR(rec_pricing_pol_dtls.initiated_date,'DD/MM/YYYY HH:MI:SS AM');
          v_email_id  := v_prm_rcpt_list;
      
      
      ELSIF (v_message_type_id in ( 'PRICING_PREMIUM_GEN','PRICING_MODIFIED','PRICING_RE_COMPLETED')) THEN
          OPEN  cur_pricing_pol_dtls(v_parameters);
          FETCH cur_pricing_pol_dtls INTO rec_pricing_pol_dtls;
          CLOSE cur_pricing_pol_dtls;
          
          v_params(1) := rec_pricing_pol_dtls.renewal_yn;
          v_params(2) := rec_pricing_pol_dtls.ref_no;
          v_params(3) := rec_pricing_pol_dtls.group_name;
          v_params(4) := TO_CHAR(rec_pricing_pol_dtls.calculate_date,'DD/MM/YYYY HH:MI:SS AM');
          v_params(5) := rec_pricing_pol_dtls.tot_cov_lives;
          v_email_id  := v_prm_rcpt_list;
          
        -- ########### PREAUTH_APPROVED
      ELSIF ((v_message_type_id = 'PREAUTH_APPROVED') OR
             (v_message_type_id = 'PREAUTH_REJECTED') OR
             (v_message_type_id = 'PREAUTH_REJECTED_NHCP') OR
              (v_message_type_id = 'PREAUTH_APPROVED_NHCP') OR
             (v_message_type_id = 'PREAUTH_ENHANCED') OR
             (v_message_type_id = 'PREAUTH_RECEIPT') OR
             (v_message_type_id = 'PTNR_PREAUTH_ONLN_SUB') OR    --WE HAVE TO ADD IN SOURCE_MESSAGE TABLE
             (v_message_type_id = 'PREAUTH_RECEIPT_NHCP') OR
             (v_message_type_id = 'PREAUTH_SHORTFALL') OR
             (v_message_type_id = 'PREAUTH_SHORTFALL_NHCP') OR
             (v_message_type_id = 'PREAUTH_SHORTFALL_RECEIVED') OR
             (v_message_type_id = 'PREAUTH_SHORTFALL_REMINDER') OR
             (v_message_type_id = 'PAYER_APPROVAL_REQUEST_FOR_CLAIMS') OR
             (v_message_type_id = 'CHECK_PREAPPROVAL_APPROVED') OR
             (v_message_type_id = 'CHECK_PREAPPROVAL_REJECTED')) THEN
             v_notification_type     := 'PREAUTH';
            v_pat_gen_detail_seq_id := v_parameters;
             IF v_message_type_id = 'PTNR_PREAUTH_ONLN_SUB' THEN 
              v_notification_type     := 'PARTNER_PREAUTH';
            END IF;
            
            
        ------------------------**********-----------------------------
        OPEN Pre_Auth_Approved_Cur(v_parameters);
        FETCH Pre_Auth_Approved_Cur INTO v_auth_cursor;
        CLOSE Pre_Auth_Approved_Cur;
      
         -----------*********NEWLY ADDED FOR PARTNER FOR ONLINE PREAUTH SUBMISSION********----------------     
         
        OPEN Pre_Auth_Approved_Cur_Ptnr(v_parameters);
        FETCH Pre_Auth_Approved_Cur_Ptnr INTO v_auth_cursor_ptnr;
        CLOSE Pre_Auth_Approved_Cur_Ptnr;
        
           -----------*********NEWLY ADDED FOR PARTNER FOR ONLINE PREAUTH SUBMISSION********----------------     
        
        --------------------------**********---------------------------
        /*OPEN pat_denial_cur(v_parameters);
        FETCH pat_denial_cur INTO pat_denial_rec;
        CLOSE pat_denial_cur;*/
        IF v_message_type_id = 'CHECK_PREAPPROVAL_APPROVED' THEN
          v_params(1) := v_auth_cursor.name;
          v_params(2) := v_auth_cursor.benefit_type;
          v_params(2) := v_auth_cursor.hosp_name;
          
        ELSIF v_message_type_id = 'CHECK_PREAPPROVAL_REJECTED' THEN
          v_params(1) := v_auth_cursor.name;
          v_params(1) := v_auth_cursor.policy_holder;
        END IF;
   -----------*********NEWLY ADDED FOR PARTNER FOR ONLINE PREAUTH SUBMISSION********----------------   
   ---THIS MAIL WILL TRIGGER WHEN WE SUBMIT ONLINE PREAUTH SUBMISSION IN EXTERNAL PARTNER LOGIN TO PATRNER
   
        IF v_message_type_id = 'PTNR_PREAUTH_ONLN_SUB' THEN
        
          v_params(1) := v_auth_cursor_ptnr.onl_pre_auth_refno;
          v_params(2) := v_auth_cursor_ptnr.tpa_enrollment_id;
          v_params(3) := v_auth_cursor_ptnr.name;
          v_params(4) := v_auth_cursor_ptnr.partner_name;
          v_params(5) := v_auth_cursor_ptnr.hosp_name;
          v_params(6) := v_auth_cursor_ptnr.benefit_type;
          --v_params(5) := v_auth_cursor_ptnr.name;
         -- v_params(6) := v_auth_cursor_ptnr.toll_free_num;
          v_email_id := v_auth_cursor_ptnr.ptr_Email;
         
        
        END IF;
        
   -----------*********NEWLY ADDED FOR PARTNER FOR ONLINE PREAUTH SUBMISSION********----------------     
  ---------------================================= 
  
  
        IF v_message_type_id = 'PREAUTH_RECEIPT' THEN
          v_params(1) := v_auth_cursor.name;
          v_params(2) := v_auth_cursor.benefit_type;
          v_params(3) := v_auth_cursor.hosp_name;
          v_params(4) := v_auth_cursor.toll_free_num;
          v_params(5) := v_auth_cursor.pre_auth_number;
          --v_params(6) := v_auth_cursor.toll_free_num;
          v_email_id := v_auth_cursor.mem_email;
        ----  v_cc_mail   :=  v_auth_cursor.clinician_mail;-----NEWLY ADDED FOR ALAHALI ENHANCEMENT
          
          --v_document_name := v_Preauth_Number1||'.pdf';
          
          --SMS
          v_SMS_params(1) := v_auth_cursor.name;
          v_SMS_params(2) := v_auth_cursor.pat_received_date;
          v_SMS_params(3) := v_auth_cursor.toll_free_num;
          v_sms_phone := v_auth_cursor.mem_mob;
          
        ELSIF (v_message_type_id = 'PREAUTH_RECEIPT_NHCP') THEN
          v_params(1) := v_auth_cursor.name;
          v_params(2) := v_auth_cursor.hosp_name;
          v_params(3) := v_auth_cursor.toll_free_num;
          v_params(4) := v_auth_cursor.pre_auth_number;
          v_params(5) := v_auth_cursor.name;
          --v_params(6) := v_auth_cursor.toll_free_num;
          v_email_id := v_auth_cursor.hos_email;
          --v_sec_rcpt_list := v_Hosp_Email1||','||v_mem_sec_mail; 
           v_cc_mail   :=  v_auth_cursor.clinician_mail;-----NEWLY ADDED FOR ALAHALI ENHANCEMENT
        
          
        ELSIF (v_message_type_id = 'PREAUTH_APPROVED') THEN
          -- For EMAIL Generation
          
          --==============================================================                   
          -- Modified Parameters as per Dubai CR
          v_params(1) := 'QAR '||TRIM(TO_CHAR(nvl(v_auth_cursor.amt, 0), '99G99G99G9990D00'));
          v_params(2) := v_auth_cursor.name;
          v_params(3) := v_auth_cursor.benefit_type;
          v_params(4) := v_auth_cursor.hosp_name;
          v_params(5) := v_auth_cursor.toll_free_num;
          v_params(6) := v_auth_cursor.toll_free_email;
          v_params(7) := v_auth_cursor.pre_auth_number; --v_pre_auth_number;
          v_email_id := v_auth_cursor.hos_email;
          v_cc_mail := v_auth_cursor.mem_email;
          v_sec_rcpt_list  := v_auth_cursor.clinician_mail;--------NEWLY ADDED
          v_document_name := v_auth_cursor.pre_auth_number; 
        
          --SMS
          v_SMS_params(1) := v_auth_cursor.name;
          v_SMS_params(2) := v_auth_cursor.toll_free_num;
          v_sms_phone := v_auth_cursor.mem_mob;
          
        ELSIF v_message_type_id = 'PAYER_APPROVAL_REQUEST_FOR_CLAIMS' THEN
          v_params(1) := v_Preauth_Number1;
          v_params(2) := TRIM(TO_CHAR(v_Apr_Amt1, '99G99G99G9990D00'));
        
          
        ELSIF (v_message_type_id = 'PREAUTH_REJECTED') THEN
          -- For EMAIL Generation
          v_params(1) := v_auth_cursor.name;
          v_params(2) := v_auth_cursor.benefit_type;
          v_params(3) := v_auth_cursor.hosp_name;
          v_params(4) := v_auth_cursor.toll_free_num;
          v_params(5) := v_auth_cursor.pre_auth_number;--v_auth_cursor.toll_free_email;
          --v_params(6) := v_auth_cursor.pre_auth_number;
          v_email_id := v_auth_cursor.hos_email;
          v_cc_mail := v_auth_cursor.mem_email;
          v_sec_rcpt_list  := v_auth_cursor.clinician_mail;--------NEWLY ADDED
          v_document_name := v_auth_cursor.pre_auth_number;
          
          -- For SMS Generation
          v_SMS_params(1) := v_auth_cursor.name;
          v_SMS_params(2) := v_auth_cursor.toll_free_num;
          v_SMS_params(3) := v_auth_cursor.pre_auth_number;
          v_sms_phone := v_auth_cursor.mem_mob;
        
          OPEN cr_get_hospital_info(v_hosp_seq_id);
          FETCH cr_get_hospital_info
            INTO v_fax_number, v_hospital_name;
          CLOSE cr_get_hospital_info;
          --koc 1216 v1 mail template

        ELSIF (v_message_type_id = 'PREAUTH_ENHANCED') THEN
        
          v_params(1) := v_auth_cursor.name;
          v_params(2) := TRIM(TO_CHAR(nvl(v_auth_cursor.amt, 0), '99G99G99G9990D00'));
        
          
        
          v_email_ids := v_auth_cursor.mem_email;
        
          -- For SMS Generation --Added for PREAUTH ENHANCED
          v_SMS_params(1) := v_auth_cursor.pre_auth_number;
          v_SMS_params(2) := to_char(sysdate, 'DD-MON-YYYY HH:MI:SS AM');
          v_SMS_params(3) := v_auth_cursor.toll_free_num;
        
        ELSIF (v_message_type_id = 'PREAUTH_APPROVED_NHCP') THEN
          
          -- Since mail has to be sent to Hospital EMAIL ID, the email id of the claimant is ignored.
          --v_email_id  := v_additional_param;
          -- For EMAIL Generation
          
          --============================================================================                    
          -- Since mail has to be sent to Hospital EMAIL ID
          --========================================================================
         
          v_params(1) := 'QAR '||TRIM(TO_CHAR(nvl(v_auth_cursor.amt, 0), '99G99G99G9990D00'));
          v_params(2) := v_auth_cursor.name;
          v_params(3) := v_auth_cursor.benefit_type;
          v_params(4) := v_auth_cursor.hosp_name;
          v_params(5) := v_auth_cursor.toll_free_num;
          v_params(6) := v_auth_cursor.toll_free_email;
          v_params(7) := v_auth_cursor.pre_auth_number; --v_pre_auth_number;
          --v_email_id := v_auth_cursor.hos_email;
          --v_sec_rcpt_list := v_auth_cursor.alternative_mail;
          v_document_name := v_auth_cursor.pre_auth_number;
          
        ELSIF (v_message_type_id = 'PREAUTH_REJECTED_NHCP') THEN
          -- Since mail has to be sent to Hospital EMAIL ID, the email id of the claimant is ignored.
          --v_email_id  := v_additional_param;
          
          -- Chaned PArameters as per Dubai CR
          v_params(1) := v_auth_cursor.name;
          v_params(2) := v_auth_cursor.benefit_type;
          v_params(3) := v_auth_cursor.hosp_name;
          v_params(4) := v_auth_cursor.toll_free_num;
          v_params(5) := v_auth_cursor.toll_free_email;
          v_params(6) := v_auth_cursor.pre_auth_number;
          --v_email_id := v_auth_cursor.hos_email;
          --v_sec_rcpt_list := v_auth_cursor.alternative_mail;
          v_document_name := v_auth_cursor.pre_auth_number;
          --v_document_name := v_Preauth_Number1;
          
        --ELSIF (v_message_type_id = 'PREAUTH_SHORTFALL') THEN
         
        
        ELSIF (v_message_type_id = 'PREAUTH_SHORTFALL') THEN
        
          OPEN cr_get_shortfall_regular(v_parameters);
          FETCH cr_get_shortfall_regular INTO v_cr_get_shortfall_regular;
          CLOSE cr_get_shortfall_regular;
          
          v_params(1) := v_cr_get_shortfall_regular.mem_name;
          v_params(2) := v_cr_get_shortfall_regular.toll_free_num;
          v_params(3) := v_cr_get_shortfall_regular.pre_auth_number;
          v_email_id := v_cr_get_shortfall_regular.email_id;
          

          --v_sec_rcpt_list := v_Hosp_Email1
          v_document_name := v_cr_get_shortfall_regular.shortfall_id;
          --SMS
          v_SMS_params(1) := v_cr_get_shortfall_regular.mem_name;
          v_SMS_params(2) := v_cr_get_shortfall_regular.toll_free_num;
          v_sms_phone := v_cr_get_shortfall_regular.mobile_no;
          
        ELSIF (v_message_type_id = 'PREAUTH_SHORTFALL_RECEIVED') THEN
          OPEN cr_get_shortfall_regular(v_parameters);
          FETCH cr_get_shortfall_regular INTO v_cr_get_shortfall_regular;
          CLOSE cr_get_shortfall_regular;
          
          v_SMS_params(1) := v_cr_get_shortfall_regular.mem_name;
          v_SMS_params(2) := v_cr_get_shortfall_regular.toll_free_num;
          v_sms_phone := v_cr_get_shortfall_regular.mobile_no;
          
        ELSIF (v_message_type_id = 'PREAUTH_SHORTFALL_NHCP') THEN
        
          OPEN cr_get_shortfall_regular(v_parameters);
          FETCH cr_get_shortfall_regular INTO v_cr_get_shortfall_regular;
          CLOSE cr_get_shortfall_regular;
          
          v_params(1) := v_cr_get_shortfall_regular.mem_name;
          v_params(2) := v_cr_get_shortfall_regular.toll_free_num;
          v_params(3) := v_cr_get_shortfall_regular.pre_auth_number;
          v_email_id  := v_cr_get_shortfall_regular.hosp_email;
          v_cc_mail   := v_cr_get_shortfall_regular.clinician_mail;--------NEWLY ADDED
          v_document_name := v_cr_get_shortfall_regular.shortfall_id;
          
        ELSIF v_message_type_id = 'PREAUTH_SHORTFALL_REMINDER' THEN
          OPEN cr_get_shortfall_regular(v_parameters);
          FETCH cr_get_shortfall_regular INTO v_cr_get_shortfall_regular;
          CLOSE cr_get_shortfall_regular;
          
          v_SMS_params(1) := v_cr_get_shortfall_regular.mem_name;
          v_SMS_params(2) := v_cr_get_shortfall_regular.toll_free_num;
          v_sms_phone := v_cr_get_shortfall_regular.mobile_no;
        END IF;

        

        /*IF v_message_type_id = 'PREAUTH_SHORTFALL_NHCP' THEN
          -- Since mail has to be sent to Hospital EMAIL ID, the email id of the claimant is ignored.
          v_email_id := v_additional_param;
        END IF;*/

        
      
        
        -- ########### PREAUTH_SHORTFALL_MED
      ELSIF ((v_message_type_id = 'PREAUTH_SHORTFALL_REMINDER') OR
            (v_message_type_id = 'PREAUTH_SHORTFALL_RECEIVED')) THEN
        v_notification_type := 'PREAUTH';
      
        ------ Shortfall Cursor-----------------------------(KP)
      
        
      
        /*OPEN cr_get_shortfall_regular(v_parameters);
        FETCH cr_get_shortfall_regular
          INTO v_Claiment_Name1,
               v_Preauth_Number1,
               v_Mem_Phone1,
               v_shortfall_id,
               v_hosp_seq_id,
               v_policy_seq_id,
               v_member_seq_id,
               v_pat_gen_detail_seq_id,
               v_Mem_Email1,
               v_mem_sec_mail,
               v_Hosp_Email1,
               v_Hosp_Phone1,
               v_toll_free_num;
        CLOSE cr_get_shortfall_regular;*/
   --=================================================================   
        

   --=================================================================   
        IF (v_message_type_id = 'REINSURE_INWARD_MR') THEN
          v_params(1) := v_Claiment_Name1;
          v_params(2) := v_Preauth_Number1;
          v_email_id := v_Hosp_Email1;
          v_sms_phone := v_Hosp_Phone1;
        END IF;

        
        /*IF v_message_type_id = 'PREAUTH_SHORTFALL_NHCP' THEN
          -- Since mail has to be sent to Hospital EMAIL ID, the email id of the claimant is ignored.
          v_email_id := v_additional_param;
        END IF;*/

       

      
      
        -- ########### CLAIM_INWARD_MR
      ELSIF ((v_message_type_id = 'CLAIM_INWARD_MR') OR
            (v_message_type_id = 'CLAIM_INWARD_NHCP') OR
            (v_message_type_id = 'CLAIM_MR_APPROVE') OR
            (v_message_type_id = 'CLAIM_RECEIVED_NHCP') OR
            (v_message_type_id = 'CLAIM_MR_RECEIVED') OR
            (v_message_type_id ='CLAIM_RECEIVED_CNH') OR
            (v_message_type_id = 'CLAIM_NHCP_APPROVE') OR
            (v_message_type_id = 'CLAIM_MR_REJECTED') OR
            (v_message_type_id = 'CLAIM_NHCP_REJECTED') OR
            (v_message_type_id = 'ECLAIM_RECEIVED') OR
            (v_message_type_id = 'CLAIM_STATUS')) THEN
             v_notification_type := 'CLAIMS';
        
      
        -- Get Mail details for Policy Number and Member SEQ id. This also returns the Branch which owns the policy and
        -- their toll free number.
      
        -- In case, if the claim received doesn;t have a POLICY Number, then whatever is entered in Inward Entry
        -- is taken.
        IF (v_policy_seq_id IS NULL) THEN
          v_member_seq_id := v_claim_seq_id;
        END IF;

      
        proc_get_mail_details(v_policy_seq_id,
                              v_member_seq_id,
                              v_tpa_code,
                              v_tpa_toll_phone);
      
        -- For email Generation
        v_params(1) := v_claimant_name;
        v_params(2) := TO_CHAR(v_received_date, 'DD/MM/YYYY HH12:MI:SS AM');
        --v_params(3) := v_tpa_toll_phone;
        v_params(3) := v_claim_number;
      
        -- For SMS Generation
        v_SMS_params(1) := v_claimant_name;
        v_SMS_params(2) := TO_CHAR(v_received_date,
                                   'DD/MM/YYYY HH12:MI:SS AM');
        --v_SMS_params(3) := v_tpa_toll_phone;
      
        IF (v_message_type_id = 'CLAIM_INWARD_MR') THEN
          -- For MR claim, less then 100000 SMS should NOT go. By default SMS will be marked as 'Y'
          IF (v_requested_amt <= 100000) THEN
            v_send_as_sms_yn := 'N';
          END IF;

        END IF;

      
        v_case_number := v_claim_number;
        
          OPEN cr_get_claims_inward(v_parameters);
          FETCH cr_get_claims_inward
            INTO v_rownum,
                 v_currency,
                v_batchno,
                v_Apr_Amt1,
                v_req_amt,
               v_disallowed_amount,
               v_clm_seq_id,
               v_claimant_name,
               v_received_date,
               v_claim_number,
               v_set_num,
               v_benefit_type,
               --v_POLICY_NUMBER,
               V_TPA_ENROLLMENT_ID,
               v_member_seq_id,
               v_policy_seq_id,
               v_invoice,
               v_hospit_name,
               v_mem_mobile_no,
               v_Mem_Email1,
               --v_mem_sec_mail,
               v_Ins_Email1,
               v_Hosp_Email1,
               v_bro_Email,
               v_corp_emial,
               v_toll_free_email,
               v_toll_free_num,
               v_currency;
      
        CLOSE cr_get_claims_inward;
        
       /* select distinct nvl(clm.claim_type, null) into v_network
        from clm_authorization_details clm
        where clm.clm_batch_seq_id = v_parameters
        or clm.claim_seq_id = v_parameters;*/
       
        IF (v_message_type_id = 'CLAIM_RECEIVED_NHCP') THEN
            v_notification_type := 'CLAIMS';
             v_params(1) := v_claimant_name;
             v_params(2) := v_hospit_name;
             v_params(3) := v_received_date;
             v_params(4) := v_rownum;
             v_params(5) := v_batchno;
             v_params(6) := V_TPA_ENROLLMENT_ID;
             v_params(7) := v_claimant_name;
             v_params(8) := v_benefit_type;
             v_params(9) := v_invoice;
             v_params(10) := v_currency||v_req_amt;
             v_params(11) := v_toll_free_num;
             v_params(12) := v_claim_number;
             v_params(13) := v_toll_free_email;
             v_email_id   := v_Hosp_Email1;
         
        ELSIF v_message_type_id ='CLAIM_RECEIVED_CNH' THEN
          v_notification_type := 'CLAIMS';
          v_params(1) := v_claimant_name;
          v_params(2) := v_hospit_name;
          v_params(3) := v_received_date;
          v_params(4) := v_rownum;
          v_params(5) := v_batchno;
          v_params(6) := V_TPA_ENROLLMENT_ID;
          v_params(7) := v_claimant_name;
          v_params(8) := v_benefit_type;
          v_params(9) := v_invoice;
          v_params(10) := v_currency||v_req_amt;
          v_params(11) := v_toll_free_num;
          v_params(12) := v_claim_number;
          v_params(13) := v_toll_free_email;
          v_email_id   := v_Mem_Email1; 
          --sms  
          v_SMS_params(1) := v_claimant_name;
          v_SMS_params(2) := v_received_date;
          v_SMS_params(3) := v_toll_free_num;
          v_sms_phone     := v_mem_mobile_no;
          
         ELSIF (v_message_type_id = 'CLAIM_MR_RECEIVED') THEN 
           v_notification_type := 'CLAIMS';
            v_params(1) := v_claimant_name;
            v_params(2) := v_received_date;
            v_params(3) := v_hospit_name;
            v_params(4) := v_rownum;
            v_params(5) := v_batchno;
            v_params(6) := V_TPA_ENROLLMENT_ID;
            v_params(7) := v_claimant_name;
            v_params(8) := v_benefit_type;
            v_params(9) := v_invoice;
            v_params(10) := v_currency||v_req_amt;
            v_params(11) := v_toll_free_num;
            v_params(12) := v_claim_number;
            v_params(13) := v_toll_free_email;
            v_email_id   := v_Mem_Email1; 
            
            --SMS
            v_SMS_params(1) := v_claimant_name;
            v_SMS_params(2) := v_received_date;
            v_SMS_params(3) := v_toll_free_num;
            v_sms_phone     := v_mem_mobile_no;
         
         ELSIF (v_message_type_id = 'ECLAIM_RECEIVED') THEN
           OPEN eclaim_cur (v_parameters);
           FETCH eclaim_cur INTO eclaim_rec;
           CLOSE eclaim_cur;
           
           v_params(1) := eclaim_rec.hosp_name;        
           v_params(2) := to_char(sysdate, 'DD/MM/RRRR');
           
           FOR i IN eclaim_cur(v_parameters) LOOP
             v_claim_details := '<tr><td>'  || i.rownum ||
                                '</td><td>' || i.batch_no || 
                                '</td><td> '|| i.tpa_enrollment_id || 
                                '</td><td>' || i.mem_name || 
                                '</td><td>' || i.benifit_type ||
                                '</td><td>' || i.invoice_number ||
                                '</td><td>' || 'QAR'||' '||i.requested_amount ||
                                '</td></tr>';
                                
              IF (v_params(3) IS NULL) THEN
                v_params(3) := v_claim_details;
              ELSE
                v_params(3) := v_params(3) || v_claim_details;
              END IF;
          
           END LOOP;
           
           v_params(4):= eclaim_rec.toll_free_no;
           v_params(5):= eclaim_rec.batch_no;
           v_params(6):= eclaim_rec.tolfree_email;
           --v_params(7):= eclaim_rec.tolfree_email;
           
           v_email_id := eclaim_rec.hosp_mail;
           
       ELSIF (v_message_type_id = 'CLAIM_STATUS') THEN
         OPEN cr_get_claims_inward(v_parameters);
         FETCH cr_get_claims_inward INTO rec_get_claims_inward;
         CLOSE cr_get_claims_inward;
         
         v_SMS_params(1) := rec_get_claims_inward.clm_rec_date;
         v_SMS_params(2) := rec_get_claims_inward.toll_free_no;
           
       END IF;
       IF (v_message_type_id = 'CLAIM_MR_APPROVE') THEN
         
         --IF v_network = 'CNH' THEN
          -- For email Generation

           --  v_params(1) := v_Apr_Amt1;
             v_params(1) := 'QAR'||' '||v_Apr_Amt1;
             v_params(2) := v_claimant_name;
             v_params(3) := v_benefit_type;
             v_params(4) := v_hospit_name;
             v_params(5):= v_toll_free_num;
             v_params(6):= v_toll_free_email;
             v_params(7) := v_claim_number;
             --v_params(6) := v_batchno;
             --v_params(7) := V_TPA_ENROLLMENT_ID;
             --v_params(8) := v_claimant_name;
             --v_params(9) := v_benefit_type;
             --v_params(10) := v_invoice;
             --v_params(11) := v_claim_number;
             --v_params(12):= v_req_amt;
             --v_params(13):= v_disallowed_amount;
             --v_params(14):= v_Apr_Amt1;
             --v_params(15):= v_utr_no;
             --v_params(16):= v_toll_free_num;
             --v_params(17):= v_Ins_Email1;
             --v_params(18):= v_claim_number;
             v_email_id := v_Mem_Email1;
             v_cc_mail  := v_Hosp_Email1;
               
             v_document_name := v_set_num;
          
             v_SMS_params(1) := v_claimant_name;
             v_SMS_params(2) := v_toll_free_num;
             v_sms_phone     := v_mem_mobile_no;
             
          ELSIF (v_message_type_id = 'CLAIM_NHCP_APPROVE') THEN  
           
          --ELSIF v_network = 'CTM' THEN
             v_params(1) := v_currency||' '||v_Apr_Amt1;
             v_params(2) := v_claimant_name; 
             v_params(3) := v_hospit_name; 
             v_params(4) := v_rownum;
             v_params(5) := v_batchno;
             v_params(6) := V_TPA_ENROLLMENT_ID;
             v_params(7) := v_claimant_name;
             v_params(8) := v_benefit_type;
             v_params(9) := v_invoice;
             v_params(10) := v_claim_number;
             v_params(11):= v_req_amt;
             v_params(12):= v_disallowed_amount;
             v_params(13):= v_Apr_Amt1;
             v_params(14):= v_utr_no;
             v_params(15):= v_toll_free_num;
             v_params(16):= v_toll_free_email;
             v_params(17):= v_batchno;
             --v_email_id  := v_Hosp_Email1;
             --v_document_name := v_set_num;
          END IF;
      
       IF (v_message_type_id = 'CLAIM_MR_REJECTED') THEN
                          
          --IF v_network = 'CNH' THEN
          -- For email Generation
          v_params(1) := v_claimant_name;
          v_params(2) := v_benefit_type;
          v_params(3) := v_hospit_name;
          v_params(4) := v_toll_free_num;
          v_params(5) := v_toll_free_email;
          v_params(6) := v_claim_number;
          v_email_id  := v_Mem_Email1;
          v_cc_mail   := v_Hosp_Email1;
          v_document_name := v_set_num;
          
          -- For SMS Generation
          v_SMS_params(1) := v_claimant_name;
          v_SMS_params(2) := v_toll_free_num;
          v_SMS_params(3) := v_claim_number;
          
          v_sms_phone     := v_mem_mobile_no;
          
          /*ELSIF v_network = 'CTM' THEN
            v_params(1) := v_claimant_name;
            v_params(2) := v_claim_number;
            v_email_id := v_Mem_Email1;
            v_document_name := v_claim_number;
            
            -- For SMS Generation
            v_SMS_params(1) := v_claimant_name;
            v_SMS_params(2) := v_toll_free_num;
            v_SMS_params(3) := v_claim_number;
            v_sms_phone     := v_mem_mobile_no;
         END IF;*/
       END IF;
        -- ########### CLAIMS_STATUS
        -- Message will be sent only through Email for the user
      ELSIF (v_message_type_id = 'CLAIM_STATUS_MR') THEN
        v_notification_type := 'CLAIMS';
        v_claim_seq_id      := v_parameters;
        OPEN cr_get_claims_status(v_parameters);
        FETCH cr_get_claims_status
          INTO v_claimant_name,
               v_received_date,
               v_claim_number,
               v_status,
               v_sms_phone,
               v_requested_amt,
               v_total_approved_amount,
               v_policy_seq_id,
               v_member_seq_id,
               v_hosp_seq_id,
               v_auth_number,
               v_email_id,
               --koc 1216 v1 mail template
               V_CLAIM_FILE_NUMBER,
               V_INSURED_NAME,
               V_TPA_ENROLLMENT_ID,
               V_DOH,
               v_auth_number,
               v_pre_auth_number,
               V_POLICY_NUMBER;
        CLOSE cr_get_claims_status;
      
        -- Get Mail details for Policy Number and Member SEQ id. This also returns the Branch which owns the policy and
        -- their toll free number.
        proc_get_mail_details(v_policy_seq_id,
                              v_member_seq_id,
                              v_tpa_code,
                              v_tpa_toll_phone);
      
        -- For email Generation
        --koc 1216 v1 mail template
        v_params(1) := V_CLAIM_FILE_NUMBER;
        v_params(2) := V_INSURED_NAME;
        v_params(3) := v_claimant_name;
        v_params(4) := V_TPA_ENROLLMENT_ID;
        v_params(5) := V_POLICY_NUMBER;
        v_params(6) := TO_CHAR(v_received_date, 'DD/MM/YYYY HH:MI:SS AM');
        v_params(7) := TO_CHAR(V_DOH, 'DD/MM/YYYY HH:MI:SS AM');
        v_params(8) := TRIM(TO_CHAR(v_requested_amt, '99G99G99G999D99'));
      
        
      
        -- For MR claim, less than 50,000 SMS should NOT go. By default SMS will be marked as 'Y'
        IF (v_requested_amt < 50000.00) THEN
          v_send_as_sms_yn := 'N';
        END IF;

      
        -- For SMS Generation
        v_SMS_params(1) := v_claimant_name;
        v_SMS_params(2) := TO_CHAR(v_received_date, 'DD/MM/YYYY');
        v_SMS_params(3) := v_tpa_toll_phone;
      
        v_case_number := v_claim_number;
      
      ELSIF (v_message_type_id = 'CLAIM_STATUS_NHCP') THEN
        v_notification_type := 'CLAIMS';
        v_claim_seq_id      := v_parameters;
        OPEN cr_get_claims_status(v_parameters);
        FETCH cr_get_claims_status
          INTO v_claimant_name,
               v_received_date,
               v_claim_number,
               v_status,
               v_sms_phone,
               v_requested_amt,
               v_total_approved_amount,
               v_policy_seq_id,
               v_member_seq_id,
               v_hosp_seq_id,
               v_auth_number,
               v_email_id,
               --koc 1216 v1 mail template
               V_CLAIM_FILE_NUMBER,
               V_INSURED_NAME,
               V_TPA_ENROLLMENT_ID,
               V_DOH,
               v_auth_number,
               v_pre_auth_number,
               V_POLICY_NUMBER;
        CLOSE cr_get_claims_status;
      
        -- Get Mail details for Policy Number and Member SEQ id. This also returns the Branch which owns the policy and
        -- their toll free number.
        proc_get_mail_details(v_policy_seq_id,
                              v_member_seq_id,
                              v_tpa_code,
                              v_tpa_toll_phone);
      
        OPEN cr_get_hospital_info(v_hosp_seq_id);
        FETCH cr_get_hospital_info
          INTO v_fax_number, v_hospital_name;
        CLOSE cr_get_hospital_info;
      
        -- For email Generation
        --koc 1216 v1 mail template
        v_params(1) := V_CLAIM_FILE_NUMBER;
        v_params(2) := V_INSURED_NAME;
        v_params(3) := v_claimant_name;
        v_params(4) := V_TPA_ENROLLMENT_ID;
        v_params(5) := V_POLICY_NUMBER;
        v_params(6) := to_char(v_received_date, 'DD/MM/YYYY  HH:MI:SS AM');
        v_params(7) := to_char(V_DOH, 'DD/MM/YYYY HH:MI:SS AM');
        v_params(8) := TRIM(TO_CHAR(v_requested_amt, '99G99G99G999D99'));
        v_params(9) := v_auth_number;
        v_params(10) := v_pre_auth_number;
      
        
        -- For SMS Generation
        v_SMS_params(1) := v_claimant_name;
        v_SMS_params(2) := TO_CHAR(v_received_date, 'DD/MM/YYYY');
        v_SMS_params(3) := v_hospital_name;
        v_SMS_params(4) := v_tpa_toll_phone;
      
        v_case_number := v_claim_number;
      
        -- ########### CLAIM_SHORTFALL

      ELSIF (v_message_type_id = 'CLAIM_SHORTFALL') OR
            (v_message_type_id = 'CLAIM_SHORTFALL_REMINDER') THEN
        v_notification_type := 'CLAIMS';
        
        
        OPEN cr_get_claim_shortfall_regular(v_parameters);
        FETCH cr_get_claim_shortfall_regular
          INTO v_claimant_name,
               v_claim_number,
               v_batchno,
               v_shortfall_id,
               v_Mem_Email1,
               v_hosp_email,
               --v_mem_sec_mail,
               v_Mem_Phone1,
               v_Hosp_Phone1,
               v_Ins_Email1,
               v_toll_free_num,
               v_mem_id,
               v_toll_free_email;
                

        CLOSE cr_get_claim_shortfall_regular;
      
        -- Get Mail details for Policy Number and Member SEQ id. This also returns the Branch which owns the policy and
        -- their toll free number.
        
      /* select nvl(clm.claim_type, null) into v_network
          from clm_authorization_details clm,
          shortfall_details s
          where s.claim_seq_id = clm.claim_seq_id
          and s.shortfall_seq_id  = v_parameters;*/
       
       IF (v_message_type_id = 'CLAIM_SHORTFALL_REMINDER') THEN 
        v_params(1) := v_claimant_name;
        v_params(2) := v_toll_free_num;
        v_params(3) := v_toll_free_email;
        v_params(4) := v_claim_number;
        v_email_id := v_Mem_Email1;
        v_cc_mail  := v_hosp_email;
        v_document_name := v_shortfall_id;
        
        --SMS
        v_SMS_params(1) := v_claimant_name;
        v_SMS_params(2) := v_toll_free_num;
        v_sms_phone     := v_Mem_Phone1;
      END IF;
        -- For email Generation
        /*IF (v_network = 'CNH') THEN
          OPEN cr_get_hospital_info(v_hosp_seq_id);
          FETCH cr_get_hospital_info
            INTO v_fax_number, v_hospital_name;
          CLOSE cr_get_hospital_info;
        END IF;
        
        IF (v_network = 'CTM') THEN
          
        -- For email Generation
        v_params(1) := v_claimant_name;
        v_params(2) := v_claim_number;
        v_email_id := v_Mem_Email1;
        v_sec_rcpt_list := v_mem_sec_mail;
        v_document_name := v_shortfall_id;
      
        -- For SMS Generation
        v_SMS_params(1) := v_claimant_name;
        v_SMS_params(2) := v_claim_number;
        --v_case_number := v_shortfall_id;
      END IF;*/
      IF v_message_type_id = 'CLAIM_SHORTFALL' THEN
        v_SMS_params(1) := v_claimant_name;
        v_SMS_params(2) := v_toll_free_num;
        v_sms_phone     := v_Mem_Phone1;
      END IF;
      
      ELSIF (v_message_type_id = 'CLAIM_SHORTFALL_NHCP') THEN
        v_notification_type := 'CLAIMS';
        v_SMS_params(1) := v_claimant_name;
        v_SMS_params(2) := v_toll_free_num;
        v_sms_phone     := v_Hosp_Phone1;
        -- ########### E-CARDS

      ELSIF (v_message_type_id = 'E_CARDS') THEN
        OPEN cr_get_employee_enroll_nmbr(v_parameters);
        FETCH cr_get_employee_enroll_nmbr
          INTO cr_get_REC;
        CLOSE cr_get_employee_enroll_nmbr;
      
        v_params(1) := cr_get_REC.Tpa_Enrollment_Number;
        v_enrollment_number := cr_get_REC.Tpa_Enrollment_Number;
      
        v_claimant_name := cr_get_REC.Tpa_Enrollment_Number || ' // ' ||
                           cr_get_REC.Insured_Name;
      
        v_case_number := v_enrollment_number;
      
        -- ########### Online Enrollment Employee addition
      ELSIF (v_message_type_id = 'NEW_ONLINE_ENR_EMPLOYEE') THEN
        -- Call the SQL to get the value
        OPEN cr_get_employee_Info(v_parameters);
        FETCH cr_get_employee_Info
          INTO cr_get_employee_REC;
        CLOSE cr_get_employee_Info;
      

        OPEN cr_get_URL_Name('EMP');
        FETCH cr_get_URL_Name
          INTO v_url_name;
        CLOSE cr_get_URL_Name;
      
        -- Get the notification details
        OPEN cr_get_policy_notify(cr_get_employee_REC.Policy_Seq_Id);
        FETCH cr_get_policy_notify
          INTO cr_get_policy_notify_REC;
        CLOSE cr_get_policy_notify;
      
        v_params(1) := cr_get_employee_REC.Insured_Name;
      
        IF LENGTH(TRIM(cr_get_policy_notify_REC.NOTIFICATION_DETAILS)) IS NOT NULL THEN
          v_params(2) := cr_get_policy_notify_REC.NOTIFICATION_DETAILS;
        ELSE
          v_params(2) := ' ';

        END IF;

      
        v_params(3) := v_url_name;
        v_params(4) := cr_get_employee_REC.Group_Id;
        v_params(5) := cr_get_employee_REC.Policy_Number;
        v_params(6) := cr_get_employee_REC.Employee_No;
        v_params(7) := cr_get_employee_REC.Password; -- ttk_util_pkg.fn_get_password( v_user_id);
        v_email_id := cr_get_employee_REC.Email_Id;
      
      ---------------------------------------------------------------------------
        -- ########### Scheduled call logs to be sent to branch manager.
      ELSIF (v_message_type_id = 'CALLLOG_REPEAT') THEN
        OPEN cr_get_repeated_calllog(v_parameters);
        FETCH cr_get_repeated_calllog
          INTO cr_get_repeated_calllog_REC;
        CLOSE cr_get_repeated_calllog;
      
        v_tpa_code := cr_get_repeated_calllog_REC.Office_Code;
        v_params(1) := v_tpa_code;
        proc_mail_merge(v_message_type_id,
                        'ON_EMAIL',
                        v_additional_param,
                        v_email_id);
      
        v_params(1) := cr_get_repeated_calllog_REC.Call_Log_Number;
        v_claimant_name := v_params(1);
      
        -- ########### Custom message to be generated after Medical event
      ELSIF (v_message_type_id = 'PREAUTH_STATUS_MEDICAL') THEN
        v_notification_type     := 'PREAUTH';
        v_pat_gen_detail_seq_id := v_parameters;
      
        OPEN cr_get_typeof_preauth(v_parameters);
        FETCH cr_get_typeof_preauth
          INTO v_type;
        CLOSE cr_get_typeof_preauth;
      
        IF (NVL(v_type, 'REG') = 'REG') THEN
          OPEN cr_get_regular_preauth(v_parameters);
          FETCH cr_get_regular_preauth
            INTO v_claimant_name,
                 v_received_date,
                 v_pre_auth_number,
                 v_status,
                 v_sms_phone,
                 v_requested_amt,
                 v_total_approved_amount,
                 v_policy_seq_id,
                 v_member_seq_id,
                 v_auth_number,
                 v_hosp_seq_id,
                 v_email_id1,
                 V_INSURED_NAME,
                 V_TPA_ENROLLMENT_ID,
                 v_pat_status_general_type_id,
                 v_remarks,
                 V_HOSP_NAME;
          CLOSE cr_get_regular_preauth;
        
          -- Get Mail details for Policy Number and Member SEQ id. This also returns the Branch which owns the policy and
          -- their toll free number.
          proc_get_mail_details(v_policy_seq_id,
                                v_member_seq_id,
                                v_tpa_code,
                                v_tpa_toll_phone);
        
        ELSIF (v_type = 'MAN') THEN
          OPEN cr_get_manual_preauth(v_parameters);
          FETCH cr_get_manual_preauth
            INTO v_claimant_name,
                 v_received_date,
                 v_pre_auth_number,
                 v_status,
                 v_sms_phone,
                 v_requested_amt,
                 v_email_id,
                 v_total_approved_amount,
                 v_tpa_code,
                 v_tpa_toll_phone,
                 v_auth_number,
                 v_hosp_seq_id,
                 v_hosp_email_id,
                 v_ph_no_catagory,
                 v_doh;
          CLOSE cr_get_manual_preauth;

        END IF;

      
        OPEN cr_get_hospital_info(v_hosp_seq_id);
        FETCH cr_get_hospital_info
          INTO v_fax_number, v_hospital_name;
        CLOSE cr_get_hospital_info;
      
        OPEN cr_get_pat_ailment(v_parameters);
        FETCH cr_get_pat_ailment
          INTO cr_get_pat_ailment_REC;
        CLOSE cr_get_pat_ailment;
      
        -- For Email Generation
        --koc 1216 v1 mail template
        v_params(1) := v_pre_auth_number;
        v_params(2) := V_INSURED_NAME;
        v_params(3) := v_claimant_name;
        v_params(4) := V_TPA_ENROLLMENT_ID;
        v_params(5) := TO_CHAR(v_doh, 'DD/MM/YYYY HH:MI AM');
        v_params(6) := to_char(V_DATE_OF_DISCHARGE, 'DD/MM/YYYY HH:MI AM');
        v_params(7) := v_hospital_name;
        v_params(8) := TRIM(TO_CHAR(v_requested_amt, '99G99G99G999D99'));
        v_params(9) := UPPER(V_AILMENT_DESCRIPTION);
        v_params(10) := TO_CHAR(v_received_date, 'DD/MM/YYYY HH:MI AM');
      
             
        v_case_number := v_pre_auth_number;
      
        -- ########### ESCALATION MAILS
      ELSIF (v_message_type_id = 'PREAUTH_ESCALATION') THEN
        v_notification_type     := 'PREAUTH';
        v_pat_gen_detail_seq_id := v_parameters;
      
        OPEN cr_get_preauth_escalation(v_parameters);
        FETCH cr_get_preauth_escalation
          INTO cr_get_preauth_escalation_REC;
        CLOSE cr_get_preauth_escalation;
      
        v_tpa_code := cr_get_preauth_escalation_REC.Office_Code;
        v_params(1) := v_tpa_code;
        v_params(2) := v_additional_param;
      
        -- Changes done with respect to pre-auth escalation Configuration mails.
        IF (v_additional_param_2 IS NOT NULL) THEN
          proc_mail_merge(v_message_type_id,
                          'ON_EMAIL',
                          v_additional_param_2,
                          v_email_id);
        END IF;

      
        -- For Email Generation
        v_params(1) := cr_get_preauth_escalation_REC.Claimant_Name;
        v_params(2) := cr_get_preauth_escalation_REC.Pre_Auth_Number;
        v_params(3) := TO_CHAR(cr_get_preauth_escalation_REC.Added_Date,
                               'DD/MM/YYYY HH:MI AM');
        v_params(4) := cr_get_preauth_escalation_REC.Description;
        v_params(5) := v_additional_param;
        v_params(6) := v_additional_param_3;
      
        v_claimant_name := v_params(5) || ' hours (' || v_params(4) ||
                           ') - ' ||
                           cr_get_preauth_escalation_REC.Claimant_Name;
        v_case_number   := cr_get_preauth_escalation_REC.Pre_Auth_Number;
      
        ---------------------------ADDED FOR CR KOC1137
      ELSIF (v_message_type_id = 'VIP_CLAIM_INTIMATION') or -- Added FOR CR KOC1137
            (v_message_type_id = 'VIP_CLAIM_REMINDER') THEN
        OPEN cr_get_clm_inward_vip(v_parameters);
        FETCH cr_get_clm_inward_vip
          INTO v_claimant_name,
               v_received_date,
               vip_added_date,
               v_claim_number,
               v_policy_seq_id,
               v_member_seq_id,
               v_claim_seq_id,
               v_email_id,
               v_sms_phone,
               v_requested_amt;
        CLOSE cr_get_clm_inward_vip;
        v_params(1) := v_claimant_name;
        v_params(2) := TO_CHAR(vip_added_date, 'DD/MM/YYYY HH:MI AM');
        v_params(3) := v_claim_number;
        v_email_id := v_prm_rcpt_list;

      ELSIF (v_message_type_id = 'VIP_PREAUTH_INTIMATION') or
            (v_message_type_id = 'VIP_PREAUTH_REMINDER') THEN
        -- Added FOR CR KOC1137
        OPEN CR_GET_PAT_ITN_ETN(v_parameters);
        FETCH CR_GET_PAT_ITN_ETN
          INTO REC_GET_PAT_ITN_ETN;
        CLOSE CR_GET_PAT_ITN_ETN;
        v_params(1) := REC_GET_PAT_ITN_ETN.CLAIMANT_NAME;
        v_params(2) := TO_CHAR(REC_GET_PAT_ITN_ETN.PAT_RECEIVED_DATE,
                               'DD/MM/YYYY HH:MI AM');
        v_params(3) := REC_GET_PAT_ITN_ETN.PRE_AUTH_NUMBER;
        v_email_id := v_prm_rcpt_list;
        --========================================================Added for koc_investigation===============================

        
      ELSIF (v_message_type_id = 'CLAIM_INVEST_ESCALATION') THEN
        OPEN cr_get_clm_invest(v_parameters);
        FETCH cr_get_clm_invest
          INTO rec_get_clm_invest;
        CLOSE cr_get_clm_invest;
        v_params(1) := rec_get_clm_invest.claimant_name;
        v_params(2) := rec_get_clm_invest.claim_number;
        v_params(3) := SYSDATE /*TO_CHAR(rec_get_clm_invest.added_date, 'DD/MM/YYYY HH:MI AM')*/
         ;
        v_email_id := rec_get_clm_invest.addr_email_id;
        --=========================================================================================================================       

      ELSIF (v_message_type_id = 'VIP_CLAIM_ESCALATION') THEN
        -- Added FOR CR KOC1137
        OPEN CR_GET_CLM_ESCALATION(v_parameters);
        FETCH CR_GET_CLM_ESCALATION
          INTO REC_GET_CLM_ESCALATION;
        CLOSE CR_GET_CLM_ESCALATION;
        v_params(1) := REC_GET_CLM_ESCALATION.CLAIMANT_NAME;
        v_params(2) := TO_CHAR(REC_GET_CLM_ESCALATION.ADDED_DATE,
                               'DD/MM/YYYY HH:MI AM');
        v_params(3) := REC_GET_CLM_ESCALATION.CLAIM_NUMBER;
      
        IF (v_additional_param_2 IS NOT NULL) THEN
          proc_mail_merge(v_message_type_id,
                          'ON_EMAIL',
                          v_additional_param_2,
                          v_email_id);
        END IF;

        --=====================================================================================

      ELSIF (v_message_type_id = 'CALL_BCK_ESCALATION') THEN
        -- Added FOR CustomerCare changes
        OPEN CR_GET_Call_ESCALATION(v_parameters);
        FETCH CR_GET_Call_ESCALATION
          INTO REC_GET_Call_ESCALATION;
        CLOSE CR_GET_Call_ESCALATION;
        v_params(1) := REC_GET_Call_ESCALATION.Call_Log_Number;
        v_params(2) := TO_CHAR(REC_GET_Call_ESCALATION.Call_Recorded_Date,
                               'DD/MM/YYYY HH:MI AM');
        v_params(3) := REC_GET_Call_ESCALATION.CLAIMANT_NAME;
      
        IF (v_additional_param_2 IS NOT NULL) THEN
          proc_mail_merge(v_message_type_id,
                          'ON_EMAIL',
                          v_prm_rcpt_list,
                          v_email_id);
        END IF;

        --=====================================================================================     

      ELSIF (v_message_type_id = 'VIP_PREAUTH_ESCALATION') THEN
        -- Added FOR CR KOC1137
        OPEN cr_get_preauth_escalation(v_parameters);
        FETCH cr_get_preauth_escalation
          INTO cr_get_preauth_escalation_REC;
        CLOSE cr_get_preauth_escalation;
        v_params(1) := cr_get_preauth_escalation_REC.claimant_name;
        v_params(2) := TO_CHAR(cr_get_preauth_escalation_REC.added_date,
                               'DD/MM/YYYY HH:MI AM');
        v_params(3) := cr_get_preauth_escalation_REC.pre_auth_number;
      
        IF (v_additional_param_2 IS NOT NULL) THEN
          proc_mail_merge(v_message_type_id,
                          'ON_EMAIL',
                          v_additional_param_2,
                          v_email_id);
        END IF;

        ---------------------------ADDED FROM KOC1137  FOR CR KOC1137

        -- ########### AUTO GENERATE MAIL REPORT -CUSTOMER CARE - Report sent to Management
      ELSIF (v_message_type_id = 'CALL_PENDING_REPORT') THEN
        v_claimant_name := TO_CHAR(sysdate, 'DD/MM/YYYY HH:MI AM');
        proc_mail_merge(v_message_type_id,
                        'ON_EMAIL',
                        v_prm_rcpt_list,
                        v_email_id);
        v_document_name := v_doc /*'CALL_PENDING_' || TO_CHAR( sysdate , 'DD_MM_YYYY HH:MM_SS' )*/
         ;
      
        -- ########### AUTO GENERATE MAIL REPORT -CUSTOMER CARE - Report sent to each branch
      ELSIF (v_message_type_id = 'CALL_PENDING_BRANCHWISE_REPORT') THEN
      
        v_params(1) := SUBSTR(v_additional_param,
                              1,
                              (INSTR(v_additional_param, '_', 1) - 1));
        v_params(2) := SUBSTR(v_additional_param,
                              INSTR(v_additional_param, '_', 1) + 1);
      
        v_claimant_name := TO_CHAR(sysdate, 'DD/MM/YYYY HH:MI AM') || ' ( ' ||
                           v_params(2) || ' : ' || v_params(1) || ' Days )';
        proc_mail_merge(v_message_type_id,
                        'ON_EMAIL',
                        v_additional_param_2,
                        v_email_id);
        v_document_name := 'CALL_PENDING_' || v_additional_param || '_' ||
                           TO_CHAR(sysdate, 'DD_MM_YYYY');
      
        -- ########### AUTO GENERATE MAIL REPORT -MR CLAIM PENDING REPORT - Report sent to Management
      ELSIF (v_message_type_id = 'MR_CLAIMS_PENDING_REPORT') THEN
        v_params(1) := v_additional_param;
      
        v_claimant_name := TO_CHAR(sysdate, 'DD/MM/YYYY HH:MI AM') || ' (' ||
                           v_additional_param || ' Days)';
        proc_mail_merge(v_message_type_id,
                        'ON_EMAIL',
                        v_additional_param_2,
                        v_email_id);
      
        v_document_name := 'MR_CLAIMS_PENDING_' || v_additional_param || '_' ||
                           TO_CHAR(sysdate, 'DD_MM_YYYY');
      
        -- ########### AUTO GENERATE MAIL REPORT -MR CLAIM PENDING Shortfall REPORT - Report sent to Management
      ELSIF (v_message_type_id = 'MR_CLAIMS_PENDING_SRTFALL_REPORT') THEN
        v_params(1) := v_additional_param;
      
        v_claimant_name := TO_CHAR(sysdate, 'DD/MM/YYYY HH:MI AM') || ' (' ||
                           v_additional_param || ' Days)';
        proc_mail_merge(v_message_type_id,
                        'ON_EMAIL',
                        v_additional_param_2,
                        v_email_id);
      
        v_document_name := 'MR_CLAIMS_PENDING_SRT_' || v_additional_param || '_' ||
                           TO_CHAR(sysdate, 'DD_MM_YYYY');
      
        -- ########## RECEIPT OF ONLINE ASSISTANCE
      ELSIF (v_message_type_id = 'RECEIPT_ONLINE_ASSISTANCE') THEN
      
        OPEN cr_get_Online_receipt(v_parameters);
        FETCH cr_get_Online_receipt
          INTO cr_get_Online_receipt_REC;
        CLOSE cr_get_Online_receipt;
      
        -- For email Generation
        v_params(1) := cr_get_Online_receipt_REC.Group_Id;
        v_params(2) := cr_get_Online_receipt_REC.Group_Name;
        v_params(3) := cr_get_Online_receipt_REC.Policy_Number;
        v_params(4) := cr_get_Online_receipt_REC.Tpa_Enrollment_Number;
        v_params(5) := cr_get_Online_receipt_REC.Request_Id;
        v_params(6) := TO_CHAR(cr_get_Online_receipt_REC.Submitted_Date,
                               'DD-MON-YYYY HH:MI AM');
      
        v_claimant_name := v_params(1);
      
        -- Added under Online Assistance EMail id..
        v_email_id := cr_get_Online_receipt_REC.Emp_Email_Id;
      
        IF ((cr_get_Online_receipt_REC.Group_Email_Id IS NOT NULL) AND
           (cr_get_Online_receipt_REC.Group_Cc_Email_Id IS NOT NULL)) THEN
          v_cc_mail := cr_get_Online_receipt_REC.Group_Email_Id || ',' ||
                       cr_get_Online_receipt_REC.Group_Cc_Email_Id;
        ELSE
          v_cc_mail := nvl(cr_get_Online_receipt_REC.Group_Email_Id,
                           cr_get_Online_receipt_REC.Group_Cc_Email_Id);

        END IF;

      
        -- ########## RESPONSE TO ONLINE ASSISTANCE
      ELSIF (v_message_type_id = 'RESPONSE_ONLINE_ASSISTANCE') THEN
      
        OPEN cr_get_Online_response(v_parameters);
        FETCH cr_get_Online_response
          INTO cr_get_Online_response_REC;
        CLOSE cr_get_Online_response;
      
        -- For email Generation
        v_params(1) := cr_get_Online_response_REC.Request_Id;
        v_params(2) := TO_CHAR(cr_get_Online_response_REC.Submitted_Date,
                               'DD-MON-YYYY HH:MI AM');
        v_params(3) := TO_CHAR(cr_get_Online_response_REC.Clarified_Date,
                               'DD-MON-YYYY HH:MI AM');
      
        OPEN cr_get_URL_Name('EMP');
        FETCH cr_get_URL_Name
          INTO v_url_name;
        CLOSE cr_get_URL_Name;
      
        v_params(4) := v_url_name;
      
        v_claimant_name := v_params(1);
        v_email_id      := cr_get_Online_response_REC.Email_Id;
      
        -- ########## CLAIM INWARD SHORTFALL RECEIPT
      ELSIF (v_message_type_id = 'CLAIM_SHORTFALL_RECEIVED') THEN
        v_notification_type := 'CLAIMS';
      
        

        OPEN cr_get_claim_shortfall_regular(v_parameters);
        FETCH cr_get_claim_shortfall_regular
          INTO v_claimant_name,
               v_claim_number,
               v_batchno,
               v_shortfall_id,
               v_Mem_Email1, --------Not Inserted
               v_mem_sec_mail,
               v_Mem_Phone1,
               v_Hosp_Phone1,
               v_Ins_Email1,
               v_toll_free_num,
               v_mem_id,
               v_toll_free_email;
               
        CLOSE cr_get_claim_shortfall_regular;
      
        -- Get Mail details for Policy Number and Member SEQ id. This also returns the Branch which owns the policy and
        -- their toll free number.
        proc_get_mail_details(v_policy_seq_id,
                              v_member_seq_id,
                              v_tpa_code,
                              v_tpa_toll_phone);
      
        -- For email Generation
        v_params(1) := v_claimant_name;
        v_params(2) := v_claim_number;
        v_email_id := v_Ins_Email1;
      
        v_document_name := v_shortfall_id;
      
        -- For SMS Generation
        v_SMS_params(1) := v_claimant_name;
      
        v_case_number := v_shortfall_id;
      
        -- ##########Forgot Password
      ELSIF (v_message_type_id = 'FORGOT_PASSWORD_EMP') THEN
        -- Call the SQL to get the value
        OPEN cr_get_emp_forgot_passwordInfo(v_parameters);
        FETCH cr_get_emp_forgot_passwordInfo
          INTO cr_get_emp_forgot_password_REC;
        CLOSE cr_get_emp_forgot_passwordInfo;
      
        OPEN cr_get_URL_Name('EMP');
        FETCH cr_get_URL_Name
          INTO v_url_name;
        CLOSE cr_get_URL_Name;
      
        v_params(1) := cr_get_emp_forgot_password_REC.Insured_Name;
        v_params(2) := v_url_name;
        v_params(3) := cr_get_emp_forgot_password_REC.Employee_No;
        v_params(4) := cr_get_emp_forgot_password_REC.Password; -- ttk_util_pkg.fn_get_password( v_user_id);
        v_email_id := cr_get_emp_forgot_password_REC.Email_Id;
      
      ELSIF (v_message_type_id ='FORGOT_PASSWORD_EMPL') THEN
        OPEN cr_get_emp_forgot_passwordInfo(v_parameters);
        FETCH cr_get_emp_forgot_passwordInfo
          INTO cr_get_emp_forgot_password_REC;
        CLOSE cr_get_emp_forgot_passwordInfo;
        
        v_params(1) := cr_get_emp_forgot_password_REC.Insured_Name;
        v_params(2) := cr_get_emp_forgot_password_REC.Tpa_Enrollment_Id;
        v_params(3) := cr_get_emp_forgot_password_REC.Password;
        v_email_id  := cr_get_emp_forgot_password_REC.Email_Id;
        
      ELSIF (v_message_type_id = 'FINANCE_MEDICLAIM_COMPUTATION') THEN
        --ADDED FOR COMPUTATION --KOC1105
        OPEN cr_computation(v_parameters);
        FETCH cr_computation
          INTO rec_computation;
        CLOSE cr_computation;
        proc_get_mail_details(rec_computation.policy_seq_id,
                              rec_computation.claim_seq_id,
                              v_tpa_code,
                              v_tpa_toll_phone);
      
        --koc 1216 v1 mail template
        v_params(1) := rec_computation.claim_number;
        v_params(2) := rec_computation.claim_file_number;
        v_params(3) := rec_computation.insured_name;
        v_params(4) := rec_computation.tpa_enrollment_id;
        v_params(5) := rec_computation.policy_number;
        v_params(6) := rec_computation.check_num;
        v_params(7) := rec_computation.ins_comp_name;
        v_params(8) := rec_computation.employee_no;
        v_params(9) := TO_CHAR(rec_computation.date_of_admission,
                               'DD-MON-YYYY HH:MI:SS AM');
        v_params(10) := TO_CHAR(rec_computation.date_of_discharge,
                                'DD-MON-YYYY HH:MI:SS AM');
        v_params(11) := rec_computation.hosp_name;
        v_params(12) := rec_computation.address_1;
        v_params(13) := rec_computation.city_description;
        v_params(14) := rec_computation.ailment_description;
        v_params(15) := rec_computation.payee_name;
      
        /*v_params(1) := rec_computation.approved_amount;
        v_params(2) := rec_computation.check_amount;
        v_params(3) := rec_computation.emp_acct_number;
        v_params(4) := rec_computation.check_num;
        v_params(5) := rec_computation.check_date;
        v_params(6) := rec_computation.insured_name;
        v_params(7) := rec_computation.claimant_name;
        v_params(8) := rec_computation.claim_settlement_no;
        v_params(9) := rec_computation.approved_amount;
        v_params(10) := rec_computation.tds_amount;
        v_params(11):= rec_computation.check_amount;
        v_params(12) :=v_tpa_toll_phone; */

        v_email_id      := rec_computation.Email_Id;
        v_document_name := rec_computation.Claim_Settlement_No;
      
        -- ##########FINANCIAL PAYMENT BEING MADE to the CLAIMANT
      ELSIF ((v_message_type_id = 'FINANCE_PAYMENT_EFT') OR
            (v_message_type_id = 'FINANCE_PAYMENT_CHQ') OR
            (v_message_type_id = 'FINANCE_PAYMENT_PAD') OR
            (v_message_type_id = 'FINANCE_PAYMENT_EFT_MR')) THEN
        -- Call the SQL to get the value
        OPEN cr_get_FINANCIAL_PAYMENT(v_parameters);
        FETCH cr_get_FINANCIAL_PAYMENT
          INTO cr_get_FINANCIAL_PAYMENT_REC;
        CLOSE cr_get_FINANCIAL_PAYMENT;
      
        v_employee_no   := nvl(cr_get_FINANCIAL_PAYMENT_REC.Employee_No,
                               'NA'); -- FOR KOC 1268
        v_claimant_name := cr_get_FINANCIAL_PAYMENT_REC.Claimant_Name;
      
        -- Get Mail details for Policy Number and Member SEQ id. This also returns the Branch which owns the policy and
        -- their toll free number.
        proc_get_mail_details(cr_get_FINANCIAL_PAYMENT_REC.policy_seq_id,
                              NULL,
                              v_tpa_code,
                              v_tpa_toll_phone);
                              
        -- for dubai eft
        open get_eft_rec_cur(v_parameters);
        fetch get_eft_rec_cur into v_get_eft_rec_cur;
        close get_eft_rec_cur;
        
        IF v_message_type_id = 'FINANCE_PAYMENT_EFT' THEN
          OPEN eft_cur(v_parameters);
          FETCH eft_cur INTO eft_rec;
          CLOSE eft_cur;
          
          
          v_params(1) := eft_rec.currency_type||''||eft_rec.approved_amount;--eft_rec.approved_amount;
          v_params(2) := eft_rec.benifit_type;
          v_params(3) := eft_rec.patitent_name;
          v_claim_details := '<tr><td>'||eft_rec.sl_no||
                        	   '</td><td>'||eft_rec.batch_no||
                             '</td><td>'||eft_rec.tpa_enrollment_id||
                             '</td><td>'||eft_rec.patitent_name||
                             '</td><td>'||eft_rec.benifit_type||
                             '</td><td>'||eft_rec.invoice_number||
                             '</td><td>'||eft_rec.claim_number||
                             '</td><td>'||eft_rec.requested_amount||
                             '</td><td>'||eft_rec.disallowed_amount||
                             '</td><td>'||eft_rec.approved_amount||
                             '</td><td>'||eft_rec.Check_Num||'</td></tr>';
          /*v_params(5) := eft_rec.sl_no;
          v_params(6) := eft_rec.batch_no;
          v_params(7) := eft_rec.tpa_enrollment_id;
          v_params(8) := eft_rec.patitent_name;
          v_params(9) := eft_rec.benifit_type;
          v_params(10) := eft_rec.invoice_number;
          v_params(11) := eft_rec.requested_amount;
          v_params(12) := eft_rec.disallowed_amount;
          v_params(13) := eft_rec.approved_amount;
          v_params(14) := eft_rec.float_account_number;*/
          v_params(4) := v_claim_details;
          v_params(5) := eft_rec.toll_free_num;
          v_params(6) := eft_rec.toll_free_email;
          v_params(7) := eft_rec.claim_number;
          v_email_id := eft_rec.hosp_email;
          
        ELSIF v_message_type_id = 'FINANCE_PAYMENT_EFT_MR' THEN
            OPEN eft_cur(v_parameters);
            FETCH eft_cur INTO eft_rec;
            CLOSE eft_cur;
          
            v_params(1) := eft_rec.claimant_name;
            v_params(2) := eft_rec.approved_amount;
            v_params(3) := eft_rec.benifit_type;
            v_params(4) := eft_rec.hosp_name;
            v_claim_details := '<tr><td>'||eft_rec.sl_no||
                        	   '</td><td>'||eft_rec.batch_no||
                             '</td><td>'||eft_rec.tpa_enrollment_id||
                             '</td><td>'||eft_rec.patitent_name||
                             '</td><td>'||eft_rec.benifit_type||
                             '</td><td>'||eft_rec.invoice_number||
                             '</td><td>'||eft_rec.claim_number||
                             '</td><td>'||eft_rec.requested_amount||
                             '</td><td>'||eft_rec.disallowed_amount||
                             '</td><td>'||eft_rec.approved_amount||
                             '</td><td>'||eft_rec.Check_Num||'</td></tr>';
            v_params(5) := v_claim_details;
            v_params(6) := eft_rec.toll_free_num;
            v_params(7) := eft_rec.toll_free_email;
            v_params(8) := eft_rec.claim_number;
            v_email_id := eft_rec.mem_email;
         END IF;
        --v_params(1) := v_get_eft_rec_cur.mem_name; -- FOR KOC 1268
        /*v_params(1) := v_get_eft_rec_cur.tot_approved_amount;
        v_email_id := v_get_eft_rec_cur.email;*/
      
        -- For SMS Generation
        v_SMS_params(1) := cr_get_FINANCIAL_PAYMENT_REC.Check_Amount; -- FOR KOC 1268
        v_SMS_params(2) := cr_get_FINANCIAL_PAYMENT_REC.Claimant_Name;
        v_SMS_params(3) := v_tpa_toll_phone;
        v_sms_phone := cr_get_FINANCIAL_PAYMENT_REC.notification_phone_number;
      
        -- ##########FIRST LOGIN WINDOW PERIOD EXPIRED
      ELSIF (v_message_type_id = 'FIRST_LOGIN_PERIOD_CLOSED') THEN
        -- Call the SQL to get the value
        OPEN cr_get_Insured_Dtl(v_parameters);
        FETCH cr_get_Insured_Dtl
          INTO cr_get_Insured_Dtl_REC;
        CLOSE cr_get_Insured_Dtl;
      
        -- Get eMail detail for of the insured
        v_email_id := cr_get_Insured_Dtl_REC.Email_Id;
        v_params(1) := cr_get_Insured_Dtl_REC.Insured_Name;
      
        -- ########## AUTO SHCEDULER REPORT FOR STATUS OF SCHEDULED JOBS
      ELSIF (v_message_type_id = 'SCHEDULED_JOBS') THEN
        --Added for CR KOC1012.
        v_claimant_name := to_char(SYSDATE - 1, 'DD-Mon-YYYY');
      
        v_params(1) := v_claimant_name;
        v_email_id := v_prm_rcpt_list;
      
        v_document_name := 'JobStatusRpt_' ||
                           to_char(SYSDATE, 'DD_MM_YYYY');
      
        --KOC1216
      ELSIF (v_message_type_id = 'POLICY_OPTED_OUT') THEN
      
        OPEN cr_policy_opted(v_parameters);
        FETCH cr_policy_opted
          INTO cr_policy_opted_REC;
        CLOSE cr_policy_opted;
      
        v_email_id       := cr_policy_opted_REC.email_id;
        v_remarks        := 'FOR OPTED OUT POLICY';
        v_msg_type       := 'EMAIL';
        v_insert_message := 'Y';
        v_msg_title      := 'Opted out of IBM''s Group Hospitalization Scheme';
        v_sent_from      := 'ENROLMENT DEPARTMENT';
      
        --KOC1216
      ELSIF (v_message_type_id = 'NIA_WEBSERVICE_MAIL') THEN
        --added by chiranjibi
      
        v_email_id       := v_prm_rcpt_list;
        v_msg_type       := 'EMAIL';
        v_insert_message := 'Y';
        
        ---Referral Letters CR
          ELSIF ( v_message_type_id = 'REFERRAL_LETTER_HOSP' ) THEN
                  OPEN  cur_referral_letter ( v_parameters );
                  FETCH cur_referral_letter INTO rec_ref_letter;
                  CLOSE cur_referral_letter;
                  v_params(1)              := rec_ref_letter.content_of_letter;
                  v_email_id               := rec_ref_letter.mail_id;
                  v_document_name          := rec_ref_letter.file_name ;
           
           ELSIF (v_message_type_id = 'VIP_MEM_CLM_UPLOADED') THEN
                 OPEN clim_assign_user_cur(v_parameters);
                 FETCH clim_assign_user_cur INTO clim_assign_user_rec;
                 CLOSE clim_assign_user_cur;
                 v_params(1) :=  clim_assign_user_rec.claim_number;
                 v_params(2) :=  clim_assign_user_rec.vip_yn;
                 v_params(3) :=  clim_assign_user_rec.mode_of_claim;
                 v_params(4) :=  to_char(clim_assign_user_rec.clm_received_date,'dd/mm/yyyy' )||' at '||to_char(clim_assign_user_rec.clm_received_date,'hh:mi:ss AM');
                 v_params(5) :=  1;
                 v_params(6) :=  clim_assign_user_rec.batch_no;
                 v_params(7) :=  clim_assign_user_rec.type_of_claim; 
                 v_params(8) :=  clim_assign_user_rec.alkoot_id; 
                 v_params(9) :=  clim_assign_user_rec.patient_name;
                 v_params(10) :=  clim_assign_user_rec.group_name;
                 v_params(11) :=  clim_assign_user_rec.policy_number;
                 v_params(12) :=  clim_assign_user_rec.benifit_type;
                 v_params(13) :=  clim_assign_user_rec.invoice_number;
                 v_params(14) :=  clim_assign_user_rec.claimed_amount;              
                 v_email_id   :=  v_prm_rcpt_list;
               
            ELSIF ( v_message_type_id = 'VIP_PAT_UPLOADED' ) THEN
                  OPEN pat_assign_user_cur(v_parameters);
                  FETCH pat_assign_user_cur INTO pat_assign_user_rec;
                  CLOSE pat_assign_user_cur;
                 v_params(1) :=  pat_assign_user_rec.pre_auth_number;
                 v_params(2) :=  pat_assign_user_rec.vip_yn;
                 v_params(3) :=  pat_assign_user_rec.mode_of_pat;
                 v_params(4) :=  to_char(pat_assign_user_rec.pat_received_date,'dd/mm/yyyy' )||' at '||to_char(pat_assign_user_rec.pat_received_date,'hh:mi:ss AM');
                 v_params(5) :=  pat_assign_user_rec.hosp_name;
                 v_params(6) :=  1;
                 v_params(7) :=  pat_assign_user_rec.alkoot_id;
                 v_params(8) :=  pat_assign_user_rec.patient_name;
                 v_params(9) :=  pat_assign_user_rec.group_name;
                 v_params(10):=  pat_assign_user_rec.policy_number;
                 v_params(11):=  pat_assign_user_rec.benifit_type;
                 v_params(12):=  pat_assign_user_rec.req_amount;
                 IF pat_assign_user_rec.pat_enhanced_yn='N' THEN                         
                 v_email_id  :=  v_prm_rcpt_list;
                 ELSE 
                 v_email_id  :=  NULL;
                 END IF;
           ------------------- --cr0295 -----------      
      ELSIF (v_message_type_id = 'RESET_PASSWORD_EMP')THEN 
          OPEN  emp_login_pwd(v_parameters);
          FETCH emp_login_pwd INTO v_emp_login_pwd;
          CLOSE emp_login_pwd;
          
          v_params(1) := v_emp_login_pwd.Insured_Name;
          v_params(2) := v_emp_login_pwd.tpa_enrollment_id;
          v_params(3) := v_emp_login_pwd.Pwd;
          v_email_id  := v_emp_login_pwd.primary_email_id;   
           ----------------------------------------        

           ---Trigger notifications to members on their birthday: ---------
           ELSIF (v_message_type_id = 'BIRTHDAY_WISHES') THEN 
           OPEN empl_login_cur(v_parameters);
           FETCH empl_login_cur INTO empl_rec;
           CLOSE empl_login_cur;
           
           v_params(1)          :=   empl_rec.Mem_Name;
           v_email_id           :=   empl_rec.email_id;
           ----Trigger notifications to customer care for every new admission preapproval request:----
                                     ---AND----
           ----Trigger notifications to customer care for every new approval request for VIP member:---
           ELSIF (v_message_type_id = 'IN-PATIENT_PREAPPROVAL') OR (v_message_type_id = 'VIP_PREAPPROVAL') THEN  --- To 
           OPEN pre_approval_cur;
           FETCH pre_approval_cur INTO pre_approval_rec;
           CLOSE pre_approval_cur;
           
           OPEN toll_free_cur;
           FETCH toll_free_cur INTO toll_free_rec;
           CLOSE toll_free_cur;
           
           v_params(1)            :=  pre_approval_rec.tpa_enrollment_id;
           v_params(2)            :=  pre_approval_rec.mem_name;
           v_params(3)            :=  pre_approval_rec.mobile_no;
           v_params(4)            :=  pre_approval_rec.group_name;
           v_params(5)            :=  pre_approval_rec.pre_auth_number;
           v_params(6)            :=  pre_approval_rec.provider_name;
           v_params(7)            :=  pre_approval_rec.provider_number;
           v_email_id             :=  v_prm_rcpt_list;
           
      END IF;
      END IF;

      --Added by chiranjibi
      IF ((v_message_type_id = 'PREAUTH_ENHANCED') OR
         (v_message_type_id = 'PREAUTH_APPROVED')) AND
         v_ph_no_catagory = 'IntNat' THEN
        v_send_as_sms_yn := 'N';
      END IF;
      
       IF (v_message_type_id ='HR_CONFIRMATION_PROCESSED_FILE') THEN
       OPEN   hr_info_comp_cur;
       FETCH  hr_info_comp_cur INTO hr_info_comp_rec;
       CLOSE  hr_info_comp_cur;
       v_email_id:=hr_info_comp_rec.PRIMARY_EMAIL_ID;
       v_sec_rcpt_list:=hr_info_comp_rec.SECONDARY_EMAIL_ID;
       END IF;
       
       ---- CFD PREAPPROVAL & CLAIM MAIL GENERATION ------
      IF (v_message_type_id IN ('PAT_SUSPECT_TAG','CFD_PAT_CONFIRM','NETCLM_SUSPECT_TAG','CFD_NETCLM_CONFIRM','RECLM_SUSPECT_TAG','CFD_RECLM_CONFIRM')) THEN
          v_email_id:= v_prm_rcpt_list;
        IF (v_message_type_id = 'PAT_SUSPECT_TAG') THEN
          OPEN cfd_pre_approval_cur;
          FETCH cfd_pre_approval_cur INTO cfd_pre_approval_rec;
          CLOSE cfd_pre_approval_cur;

          v_params(1) := cfd_pre_approval_rec.Pre_Auth_Number;
          v_params(2) := cfd_pre_approval_rec.risk_level;
          v_params(3) := cfd_pre_approval_rec.added_date;
          v_params(4) := ' 1 ';
          v_params(5) := cfd_pre_approval_rec.pat_rec_date;
          v_params(6) := cfd_pre_approval_rec.tpa_enrollment_id;
          v_params(7) := cfd_pre_approval_rec.mem_name;
          v_params(8) := cfd_pre_approval_rec.group_name;
          v_params(9) := cfd_pre_approval_rec.policy_number;
          v_params(10) := cfd_pre_approval_rec.benifit_type;
          v_params(11) := 'QAR '||cfd_pre_approval_rec.requested_amount;
          v_params(12) := cfd_pre_approval_rec.contact_name;
          
        ELSIF (v_message_type_id = 'CFD_PAT_CONFIRM') THEN 
          OPEN cfd_pre_approval_cur;
          FETCH cfd_pre_approval_cur INTO cfd_pre_approval_rec;
          CLOSE cfd_pre_approval_cur;
          
          OPEN inv_status_cur('PAT');
          FETCH inv_status_cur INTO inv_stat_rec;
          CLOSE inv_status_cur;
          
          v_params(1) := cfd_pre_approval_rec.Pre_Auth_Number;
          v_params(2) := cfd_pre_approval_rec.risk_level;
          v_params(3) := cfd_pre_approval_rec.added_date;
          v_params(4) := inv_stat_rec.inv_status;
          v_params(5) := inv_stat_rec.inv_out_category;
          v_params(6) := inv_stat_rec.dec_date;
          v_params(7) := ' 1 ';
          v_params(8) := cfd_pre_approval_rec.pat_rec_date;
          v_params(9) := cfd_pre_approval_rec.tpa_enrollment_id;
          v_params(10) := cfd_pre_approval_rec.mem_name;
          v_params(11) := cfd_pre_approval_rec.group_name;
          v_params(12) := cfd_pre_approval_rec.policy_number;
          v_params(13) := cfd_pre_approval_rec.benifit_type;
          v_params(14) := 'QAR '||cfd_pre_approval_rec.requested_amount;
          v_params(15) := cfd_pre_approval_rec.contact_name;
         
         ELSIF (v_message_type_id = 'NETCLM_SUSPECT_TAG') THEN 
          OPEN cfd_claim_cur;
          FETCH cfd_claim_cur INTO cfd_claim_rec;
          CLOSE cfd_claim_cur;
          
          v_params(1) := cfd_claim_rec.claim_number;
          v_params(2) := cfd_claim_rec.risk_level;
          v_params(3) := cfd_claim_rec.added_date;
          v_params(4) := cfd_claim_rec.hosp_name;
          v_params(5) := ' 1 ';
          v_params(6) := cfd_claim_rec.batch_no;
          v_params(7) := cfd_claim_rec.type_of_claim;
          v_params(8) := cfd_claim_rec.tpa_enrollment_id;
          v_params(9) := cfd_claim_rec.mem_name;
          v_params(10) := cfd_claim_rec.group_name;
          v_params(11) := cfd_claim_rec.policy_number;
          v_params(12) := cfd_claim_rec.benifit_type;
          v_params(13) := cfd_claim_rec.invoice_number;
          v_params(14) := 'QAR '||cfd_claim_rec.requested_amount;
          v_params(15) := cfd_claim_rec.contact_name;
          
          ELSIF (v_message_type_id = 'CFD_NETCLM_CONFIRM') THEN 
          OPEN cfd_claim_cur;
          FETCH cfd_claim_cur INTO cfd_claim_rec;
          CLOSE cfd_claim_cur;
          
          OPEN inv_status_cur('CLM');
          FETCH inv_status_cur INTO inv_stat_rec;
          CLOSE inv_status_cur;
          
          v_params(1) := cfd_claim_rec.claim_number;
          v_params(2) := cfd_claim_rec.risk_level;
          v_params(3) := cfd_claim_rec.added_date;
          v_params(4) := cfd_claim_rec.hosp_name;
          v_params(5) := inv_stat_rec.inv_status;
          v_params(6) := inv_stat_rec.inv_out_category;
          v_params(7) := inv_stat_rec.dec_date;
          v_params(8) := ' 1 ';
          v_params(9) := cfd_claim_rec.batch_no;
          v_params(10) := cfd_claim_rec.type_of_claim;
          v_params(11) := cfd_claim_rec.tpa_enrollment_id;
          v_params(12) := cfd_claim_rec.mem_name;
          v_params(13) := cfd_claim_rec.group_name;
          v_params(14) := cfd_claim_rec.policy_number;
          v_params(15) := cfd_claim_rec.benifit_type;
          v_params(16) := cfd_claim_rec.invoice_number;
          v_params(17) := 'QAR '||cfd_claim_rec.requested_amount;
          v_params(18) := cfd_claim_rec.contact_name;
          
        ELSIF (v_message_type_id = 'RECLM_SUSPECT_TAG') THEN 
          OPEN cfd_claim_cur;
          FETCH cfd_claim_cur INTO cfd_claim_rec;
          CLOSE cfd_claim_cur;
          
          v_params(1) := cfd_claim_rec.claim_number;
          v_params(2) := cfd_claim_rec.risk_level;
          v_params(3) := cfd_claim_rec.added_date;
          v_params(4) := ' 1 ';
          v_params(5) := cfd_claim_rec.batch_no;
          v_params(6) := cfd_claim_rec.type_of_claim;
          v_params(7) := cfd_claim_rec.tpa_enrollment_id;
          v_params(8) := cfd_claim_rec.mem_name;
          v_params(9) := cfd_claim_rec.group_name;
          v_params(10) := cfd_claim_rec.policy_number;
          v_params(11) := cfd_claim_rec.benifit_type;
          v_params(12) := cfd_claim_rec.invoice_number;
          v_params(13) := 'QAR '||cfd_claim_rec.requested_amount;
          v_params(14) := cfd_claim_rec.contact_name;
          
         ELSIF (v_message_type_id = 'CFD_RECLM_CONFIRM') THEN 
          OPEN cfd_claim_cur;
          FETCH cfd_claim_cur INTO cfd_claim_rec;
          CLOSE cfd_claim_cur;
          
          OPEN inv_status_cur('CLM');
          FETCH inv_status_cur INTO inv_stat_rec;
          CLOSE inv_status_cur;
          
          v_params(1) := cfd_claim_rec.claim_number;
          v_params(2) := cfd_claim_rec.risk_level;
          v_params(3) := cfd_claim_rec.added_date;
          v_params(4) := inv_stat_rec.inv_status;
          v_params(5) := inv_stat_rec.inv_out_category;
          v_params(6) := inv_stat_rec.dec_date;
          v_params(7) := ' 1 ';
          v_params(8) := cfd_claim_rec.batch_no;
          v_params(9) := cfd_claim_rec.type_of_claim;
          v_params(10) := cfd_claim_rec.tpa_enrollment_id;
          v_params(11) := cfd_claim_rec.mem_name;
          v_params(12) := cfd_claim_rec.group_name;
          v_params(13) := cfd_claim_rec.policy_number;
          v_params(14) := cfd_claim_rec.benifit_type;
          v_params(15) := cfd_claim_rec.invoice_number;
          v_params(16) := 'QAR '||cfd_claim_rec.requested_amount;
          v_params(17) := cfd_claim_rec.contact_name;  
        END IF;
      END IF;
    
      -- Verify whether the FAX number is proper. i.e without any special characters and space.
      -- If yes, then throw error and needs to be rectified.
      IF (v_send_as_fax_yn = 'Y') THEN
        proc_verify_communication('FAX', v_fax_number);
      END IF;

    
      -- This procedure will merge the Raw Message and Data with regards to Message only related to Email
      IF (v_send_as_email_yn = 'Y') THEN
        proc_mail_merge(v_message_type_id,
                        'ON_MESSAGE',
                        NULL,
                        v_merged_message);
      END IF;

    
      -- This procedure will merge the Raw Message and Data with regards to Message only related to SMS
      IF (v_send_as_sms_yn = 'Y') THEN
        proc_mail_merge(v_message_type_id,
                        'ON_SMS_MESSAGE',
                        NULL,
                        v_merged_SMS_message);
      END IF;
    
    
      -- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
      -- This procedure will merge the Raw Message (TITLE ) and Data with regards to TITLE only
      /*v_params(1) := v_claimant_name;
      v_params(2) := v_employee_no;*/ -- FOR KOC 1268
    
      IF /*v_message_type_id = 'PREAUTH_APPROVED' THEN
        v_params(1) := v_auth_cursor.name||'('||v_auth_cursor.tpa_enrollment_id||')';
        v_params(2) := to_char(sysdate, 'DD-MON-YYYY HH:MI:SS AM ');
      ELSIF*/ v_message_type_id = 'PREAUTH_STATUS_MEDICAL' THEN
        v_params(1) := v_pre_auth_number;
        v_params(2) := to_char(sysdate, 'DD-MON-YYYY HH:MI:SS AM');

      ELSIF v_message_type_id = 'PREAUTH_ENHANCED' THEN
        v_params(1) := v_pre_auth_number;
        v_params(2) := to_char(sysdate, 'DD-MON-YYYY HH:MI:SS AM');
        v_sec_rcpt_list := v_hosp_email_id; --Added by chiranjibi

      ELSIF v_message_type_id = 'CLAIM_STATUS_NHCP' THEN
        v_params(1) := V_CLAIM_FILE_NUMBER;
        v_params(2) := v_auth_number;
        v_params(3) := v_claimant_name;
        v_params(4) := V_INSURED_NAME;

      ELSIF v_message_type_id = 'CLAIM_STATUS_MR' THEN
        v_params(1) := V_CLAIM_FILE_NUMBER;
        v_params(2) := v_claimant_name;
        v_params(3) := V_INSURED_NAME;
      ELSIF v_message_type_id = 'PREAUTH_REJECTED_NHCP' THEN
        v_params(1) := v_Claiment_Name1;

      ELSIF v_message_type_id = 'FINANCE_MEDICLAIM_COMPUTATION' then
        v_params(1) := rec_computation.claim_settlement_no;

      END IF;

      -- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
      -- This procedure will merge the Raw Message and EMAIL with regards to EMAIL only
      -- pre_auth~CTTK_Branch~@ttkhealthcareservices.com - replace ~C with the respective branch.
      -- RESET the array with the Branch to which the mail has to be sent.
      --v_params(1) := v_tpa_code;
      proc_mail_merge(v_message_type_id,
                      'ON_EMAIL',
                      v_sec_rcpt_list,
                      v_sec_rcpt_list);
      
      -- For Mail Titel
      IF v_message_type_id IN ('PREAUTH_RECEIPT', 'PREAUTH_RECEIPT_NHCP', 'PREAUTH_APPROVED','PREAUTH_REJECTED') THEN
        v_params(1) := v_auth_cursor.name||'('||v_auth_cursor.tpa_enrollment_id||')';
    -----********NEWLY ADDED FOR PARTNER******-------
    
      ELSIF v_message_type_id IN ('PTNR_PREAUTH_ONLN_SUB') THEN
        v_params(1) := v_auth_cursor_ptnr.onl_pre_auth_refno;----v_auth_cursor_ptnr.name||'('||v_auth_cursor_ptnr.tpa_enrollment_id||')';--NEWLY ADDED
        
    -----********NEWLY ADDED FOR HR LOGIN ******-------
      ELSIF v_message_type_id  IN ('HR_NEW_MEMBER_ADDITION') THEN
   
        str_tab                            := ttk_util_pkg.parse_str ( v_parameters );
         
         OPEN cr_get_hr_mem_add_details(str_tab(1),str_tab(2));
         FETCH cr_get_hr_mem_add_details  INTO hr_member_info;
         CLOSE cr_get_hr_mem_add_details;
         
         v_hr_parms  := to_char(str_tab(1));
         
        v_params(1) :=  hr_member_info.tpa_enrollment_id;
        
        ELSIF v_message_type_id IN ('CORPORATE_HR_MEMBER_DELETION') THEN  
        
          OPEN group_mem_count_cur(v_parameters);
          FETCH group_mem_count_cur INTO rec_count;
          CLOSE group_mem_count_cur;
          
         IF rec_count > 0 then 
            
            OPEN cr_hr_group_dtls_cur(v_parameters);
            FETCH cr_hr_group_dtls_cur INTO hr_group_dtls;
            CLOSE cr_hr_group_dtls_cur;
            
            v_params(1) := hr_group_dtls.tpa_enrollment_id;
          
         ELSE
           
           OPEN  cr_hr_member_dtls_cur(v_parameters);
           FETCH cr_hr_member_dtls_cur  INTO hr_member_dtls;
           CLOSE cr_hr_member_dtls_cur;  
           
            v_params(1) := hr_member_dtls.tpa_enrollment_id;
          
         END IF;  
   
  --------------------****************************************************      
      ELSIF v_message_type_id IN ('PREAUTH_SHORTFALL', 'PREAUTH_SHORTFALL_NHCP') THEN
        v_params(1) := v_cr_get_shortfall_regular.mem_name||'('||v_cr_get_shortfall_regular.tpa_enrollment_id||')';
      ELSIF v_message_type_id IN ('CLAIM_RECEIVED_CNH', 'CLAIM_RECEIVED_NHCP', 'CLAIM_MR_RECEIVED', 'CLAIM_MR_APPROVE', 'CLAIM_NHCP_APPROVE', 'CLAIM_MR_REJECTED') THEN
        v_params(1) := v_claimant_name||'('||V_TPA_ENROLLMENT_ID||')';
      ELSIF v_message_type_id = 'ECLAIM_RECEIVED' THEN
        v_params(1) := eclaim_rec.batch_no;
      ELSIF v_message_type_id = 'CLAIM_SHORTFALL' OR v_message_type_id = 'CLAIM_SHORTFALL_REMINDER' THEN
        v_params(1) := v_claimant_name||'('||v_mem_id||')';
      ELSIF v_message_type_id = 'FINANCE_PAYMENT_EFT' OR v_message_type_id = 'FINANCE_PAYMENT_EFT_MR' THEN
        v_params(1) := eft_rec.patitent_name;
      ELSIF v_message_type_id IN ('PRICING_INITIATED', 'PRICING_PREMIUM_GEN','PRICING_MODIFIED','PRICING_RE_COMPLETED') THEN
        v_params(1) := rec_pricing_pol_dtls.ref_no;
      ELSIF v_message_type_id = 'HR_UPLOADED_FILE' THEN ------BHARATH
        v_params(1) :=hr_info_cur_rec.ID ;
      ELSIF v_message_type_id = 'HR_CONFIRMATION_FILE_UPLOADED' THEN
         v_params(1) :=hr_info_cur_rec.id;
      -------------------------------------------------------
      ELSIF v_message_type_id ='VIP_MEM_CLM_UPLOADED' THEN
          v_params(1) := clim_assign_user_rec.claim_number; 
          v_params(2) := clim_assign_user_rec.vip_yn;
          v_params(3) := clim_assign_user_rec.patient_name;
          v_params(4) := clim_assign_user_rec.alkoot_id;
          v_params(5) := clim_assign_user_rec.group_name;
      ELSIF v_message_type_id = 'VIP_PAT_UPLOADED' THEN
          v_params(1) := pat_assign_user_rec.pre_auth_number; 
          v_params(2) := pat_assign_user_rec.vip_yn;
          v_params(3) := pat_assign_user_rec.patient_name;
          v_params(4) := pat_assign_user_rec.alkoot_id;
          v_params(5) := pat_assign_user_rec.group_name;              
      ----------------------------------------------------------
      ELSIF (v_message_type_id ='USER_ASSIGNED_CLAIM')THEN
          v_params(1) := case when clim_assign_user_rec.type_of_claim='Member' then 'Reimbursement' else clim_assign_user_rec.type_of_claim end;
          v_params(2) := clim_assign_user_rec.claim_number;
          v_params(3) := clim_assign_user_rec.vip_yn;
          v_params(4) := clim_assign_user_rec.patient_name;
          v_params(5) := clim_assign_user_rec.alkoot_id;
          v_params(6) := cr_get_user_info_rec.contact_name;      
      
      ELSIF (v_message_type_id ='USER_ASSIGNED_PREAUTH')THEN
           v_params(1) := pat_assign_user_rec.pre_auth_number;
           v_params(2) := pat_assign_user_rec.vip_yn;
           v_params(3) := pat_assign_user_rec.patient_name;
           v_params(4) := pat_assign_user_rec.alkoot_id;
           v_params(5) := cr_get_user_info_rec.contact_name;
        ----------------------------------------------------------
      ELSIF (v_message_type_id ='NAMECHANGE_REPRINT_CARD')THEN
           v_params(1) := mem_card_rec.mem_id;               
      ELSIF (v_message_type_id='IN-PATIENT_PREAPPROVAL' OR v_message_type_id='VIP_PREAPPROVAL' ) THEN
           v_params(1) :=  pre_approval_rec.tpa_enrollment_id;
           v_params(2) :=  pre_approval_rec.mem_name;
      
      END IF;
        
      IF (v_message_type_id = 'PAT_SUSPECT_TAG') THEN
         v_params(1) := cfd_pre_approval_rec.Pre_Auth_Number;
	       v_params(2) := cfd_pre_approval_rec.risk_level;
      ELSIF (v_message_type_id = 'CFD_PAT_CONFIRM') THEN 
         v_params(1) := cfd_pre_approval_rec.Pre_Auth_Number;
	       v_params(2) := cfd_pre_approval_rec.risk_level;
	       v_params(3) := inv_stat_rec.inv_status;
      ELSIF (v_message_type_id = 'CFD_NETCLM_CONFIRM') THEN
         v_params(1) := cfd_claim_rec.claim_number;
	       v_params(2) := cfd_claim_rec.risk_level;
      ELSIF (v_message_type_id = 'CFD_NETCLM_CONFIRM') THEN
         v_params(1) := cfd_claim_rec.claim_number;
	       v_params(2) := cfd_claim_rec.risk_level;
         v_params(3) := inv_stat_rec.inv_status;
      ELSIF (v_message_type_id = 'RECLM_SUSPECT_TAG') THEN
         v_params(1) := cfd_claim_rec.claim_number;
	       v_params(2) := cfd_claim_rec.risk_level;
      ELSIF (v_message_type_id = 'CFD_RECLM_CONFIRM') THEN
         v_params(1) := cfd_claim_rec.claim_number;
	       v_params(2) := cfd_claim_rec.risk_level;
         v_params(3) := inv_stat_rec.inv_status;
      ELSIF (v_message_type_id ='CURRENCY_CONVERSION_EXC_RATES')THEN
          select sm.prm_rcpt_email_list into v_email_id 
          from app.source_message sm
          where sm.msg_id='CURRENCY_CONVERSION_EXC_RATES' ;
      END IF;

      
      proc_mail_merge(v_message_type_id,
                      'ON_TITLE',
                      v_msg_title,
                      v_msg_title);
      
      -- INSERT THE MESSAGE
      INSERT INTO DESTINATION_MESSAGE
        (DEST_MSG_SEQ_ID,
         MSG_ID,
         SOURCE_ID,
         SOURCE_SEQ_ID,
         MSG_SENT_FROM,
         MESSAGE_TITLE,
         MESSAGE,
         SMS_DESCRIPTION,
         ADDED_BY,
         ADDED_DATE,
         ENROLLMENT_NUMBER,
         FILE_PATH_NAME,
         policy_tob)
      VALUES
        (DESTINATION_MESSAGE_SEQ.NEXTVAL,
         v_message_type_id,
         v_module_name,
         case when v_message_type_id = 'HR_NEW_MEMBER_ADDITION' then v_hr_parms 
              when v_message_type_id = 'POLICY_CERTIFICATE_REQUEST' then to_char(v_policy_grp_seq) else v_parameters end,
         v_sent_from,
         v_msg_title,
         v_merged_message,
         v_merged_SMS_message,
         v_added_by,
         sysdate,
         v_case_number,
         CASE WHEN v_message_type_id = 'PREAUTH_APPROVED' OR v_message_type_id = 'PREAUTH_APPROVED_NHCP' THEN
                v_document_name||'.pdf'
              WHEN v_message_type_id = 'PREAUTH_REJECTED' OR v_message_type_id = 'PREAUTH_REJECTED_NHCP' THEN
                v_document_name||'.pdf'
              WHEN v_message_type_id = 'PREAUTH_SHORTFALL' OR v_message_type_id = 'PREAUTH_SHORTFALL_NHCP' THEN
                v_document_name||'.pdf'
              /*WHEN v_message_type_id = 'PREAUTH_RECEIPT' OR v_message_type_id = 'PREAUTH_RECEIPT_NHCP' THEN
                v_document_name||'.pdf'*/
              WHEN v_message_type_id = 'CLAIM_SHORTFALL' OR v_message_type_id IN ('CLAIM_MR_APPROVE', 'CLAIM_NHCP_APPROVE')  OR v_message_type_id = 'CLAIM_MR_REJECTED' THEN
                v_document_name||'.pdf'
              
              WHEN v_message_type_id = 'CALL_PENDING_REPORT' THEN
                v_document_name
         
         WHEN(v_document_name IS NOT NULL and
              v_message_type_id != 'CALL_PENDING_REPORT') THEN
         v_document_name || '.pdf' ELSE NULL END,
         v_pol_tob)
      RETURNING DEST_MSG_SEQ_ID INTO v_DEST_MSG_SEQ_ID;
      
      v_message_status := v_message_type_id ||
                          ' - Correspondence Message Status : ';
    
      -- Insert the RECEIPIENT INFORMATION.
      v_count := 1;
      WHILE (v_count <= 3) LOOP
        v_email_ids      := NULL;
        v_sms            := NULL;
        v_fax            := NULL;
        v_insert_message := 'N';
        v_remarks        := NULL;
        v_msg_type       := NULL;
        v_present_yn     := 'Y';
      
        IF (v_count = 1) AND (v_send_as_email_yn = 'Y') THEN
          -- To handle the Primary or TO Email iD
          IF ((v_email_id IS NOT NULL) AND (v_general_mail IS NOT NULL)) THEN
            v_email_id := v_email_id || ',' || v_general_mail;
          ELSIF ((v_email_id IS NULL) AND (v_general_mail IS NOT NULL)) THEN
            v_email_id := v_general_mail;

          END IF;

        
          -- To handle the CC Email iD
          IF ((v_sec_rcpt_list IS NOT NULL) AND (v_cc_mail IS NOT NULL)) THEN
            v_sec_rcpt_list := v_sec_rcpt_list || ',' || v_cc_mail;
          ELSIF ((v_sec_rcpt_list IS NULL) AND (v_cc_mail IS NOT NULL)) THEN
            v_sec_rcpt_list := v_cc_mail;

          END IF;

        
          IF (v_email_id = 'NULL') OR (v_email_id = 'null') 
            OR (v_email_id IS NULL) THEN
             v_remarks := 'Primary Email Id is not present ';
             v_present_yn      :='N';
          ELSE
               v_email_ids      := v_email_id;
          END IF;

        
          v_email_ids := v_email_id;
        
          v_insert_message := 'Y';
          v_msg_type       := 'EMAIL';
        
          /*IF ( v_email_ids IS NULL ) THEN
              -- v_insert_message := 'N';
              v_remarks := 'Primary Email Id is not present ';
              v_present_yn      :='N';
          \* -- *********************************************************************
           -- IMPORTANT - COMMENT FROM THIS LINE when this code goes to PRODUCTION SERVER.
           -- FROM POINT 1
           -- *********************************************************************
           ELSE
              -- FOR TEST SERVER, UNCOMMENT ONLY THIS LINE and Comments SPAN EMAIL ID Line.
              -- v_email_ids := 'kishore@ttkhealthcareservices.com,bimiya.bonifus@ttkhealthcareservices.com,tips@ttkhealthcareservices.com,balakrishna_e@spanservices.com,sunil_m@spanservices.com'; -- TEMPORARY FOR TESTTING PURPOSE
              -- FOR DEVELOPMENT SERVER, UNCOMMENT THIS LINE and COMMENT TTK EMAIL ID Line.
              -- v_email_ids := 'balakrishna_e@spanservices.com,sunil_m@spanservices.com'; -- TEMPORARY FOR TESTTING PURPOSE
           *\END IF; */

          -- THE ABOVE PART COMMENETED Y S.V.SREERAJ -- This part can be used in production,test and development without change.
          IF UPPER(nvl(v_email_ids, 'NULL')) = 'NULL' THEN
            -- v_insert_message := 'N';
            v_remarks    := 'Primary Email Id is not present ';
            v_present_yn := 'N';
         ------------- not required for qatar
         /*ELSE
            
            SELECT a.sid
              INTO v_sid
              FROM tpa_system_parameters A
             WHERE ROWNUM = 1;

          
            IF v_sid = 'UAT' THEN
              IF LOWER(v_email_ids) LIKE '%@spanservices.com%' AND
                 v_message_type_id IN
                 ('PREAUTH_REJECTED_NHCP',
                  'PREAUTH_APPROVED_NHCP',
                  'PREAUTH_SHORTFALL_NHCP',
                  'PREAUTH_STATUS_NHCP') THEN
                v_email_ids := substr(substr(lower(v_email_ids),
                                             1,
                                             instr(lower(v_email_ids),
                                                   '@spanservices.com') - 1),
                                      instr(substr(lower(v_email_ids),
                                                   1,
                                                   instr(lower(v_email_ids),
                                                         '@spanservices.com') - 1),
                                            ',',
                                            -1) + 1) || '@spanservices.com'; --This has been done for send the mail to only span employees
              ELSE
                v_email_ids := 'span@ttkhealthcareservices.com,shahin.sm@ttkhealthcareservices.com,sunil_m@spanservices.com,navada_s@spanservices.com,ramakrishna_km@spanservices.com,murali@ttkhealthcareservices.com'; -- TEMPORARY FOR TESTTING PURPOSE

              END IF;

            ELSIF v_sid = 'DEV' THEN
              v_email_ids := 'sunil_m@spanservices.com,prakash_cs@spanservices.com,manikanta_k@spanservices.com'; -- TEMPORARY FOR TESTTING PURPOSE

            END IF;

          */
          END IF;

        
          -- COMMENT TILL HERE FOR POINT 1
          -- **********************************************************************
          v_message_status := v_message_status || v_msg_type || ' - ' ||
                              NVL(v_email_ids, v_remarks) || ';';
        
        ELSIF (v_count = 2) AND (v_send_as_sms_yn = 'Y') THEN
          --IF v_message_type_id IN('PREAUTH_ENHANCED','PREAUTH_APROVED') AND v_ph_no_catagory != 'INTNAT' THEN
          v_sms            := v_sms_phone;
          v_insert_message := 'Y';
          v_msg_type       := 'SMS';
          /*ELSE
          v_sms := v_sms_phone;
          v_insert_message := 'Y';
          v_msg_type       := 'SMS';
          END;*/

          IF (v_sms IS NULL) THEN
            -- v_insert_message := 'N';
            v_remarks    := 'Primary SMS number is not present ';
            v_present_yn := 'N';
          ELSE
            -- (91 is to be prefixed for SMS to be sent.
            IF v_sid IN ('UAT', 'DEV') THEN
              v_sms := '919844459587,919980803569,918088131194,919884404472';
            ELSE
              --v_sms := '91' || v_sms;
              v_sms := v_sms;

            END IF;

          
          END IF;

          v_message_status := v_message_status || v_msg_type || ' - ' ||
                              NVL(v_sms, v_remarks) || ';';

        ELSIF (v_count = 3) AND (v_send_as_fax_yn = 'Y') THEN
          v_fax            := v_fax_number;
          v_insert_message := 'Y';
          v_msg_type       := 'FAX';
        
          IF (v_fax IS NULL) THEN
            --  v_insert_message := 'N';
            v_remarks    := 'Primary Fax number is not present ';
            v_present_yn := 'N';
          END IF;

        
          v_message_status := v_message_status || v_msg_type || ' - ' ||
                              NVL(v_fax, v_remarks) || ';';

        END IF;

      
        -- v_final_log_message := v_merged_message || v_message_status ;
        v_final_log_message := v_message_status;
      
        IF (v_insert_message = 'Y') THEN
        
          INSERT INTO DESTINATION_MESSAGE_RCPT
            (DEST_MSG_RCPT_SEQ_ID,
             DEST_MSG_SEQ_ID,
             PRM_RCPT_EMAIL_LIST,
             PRM_RCPT_SMS,
             PRM_RCPT_FAX_NOS,
             SEC_RCPT_EMAIL_LIST,
             REMARKS,
             ADDED_BY,
             ADDED_DATE,
             MSG_TYPE,
             PRESENT_YN,
             MAIL_STATUS,
             MSG_STATUS_GENERAL_TYPE_ID,
             SENT_DATE)
          VALUES
            (DESTINATION_MESSAGE_RCPT_SEQ.NEXTVAL,
             v_DEST_MSG_SEQ_ID,
			case WHEN v_message_type_id = 'HR_UPLOADED_FILE' AND v_msg_type = 'EMAIL' then v_prm_rcpt_list
           WHEN v_message_type_id= 'HR_CONFIRMATION_FILE_UPLOADED' AND v_msg_type = 'EMAIL' then v_email_id
           WHEN v_message_type_id= 'HR_CONFIRMATION_PROCESSED_FILE' AND v_msg_type = 'EMAIL' then v_email_id
             when v_msg_type = 'EMAIL' then v_email_id  else null end, --'thomas.vazhappilly@vidalhealth.com',--v_email_ids,
             --case when v_msg_type = 'EMAIL' then nvl(v_email_id,v_prm_rcpt_list) else null end, --'thomas.vazhappilly@vidalhealth.com',--v_email_ids,
             case when v_msg_type = 'SMS' then v_sms else null end,
             v_fax,
             case WHEN v_message_type_id= 'HR_CONFIRMATION_FILE_UPLOADED' AND v_msg_type = 'EMAIL' then v_sec_rcpt_list
                  WHEN v_message_type_id= 'HR_CONFIRMATION_PROCESSED_FILE' AND v_msg_type = 'EMAIL' then  v_sec_rcpt_list          
             when v_msg_type = 'EMAIL' then v_sec_rcpt_list else null end,
             v_remarks,
             v_added_by,
             sysdate,
             v_msg_type,
             v_present_yn, --v_present_yn,
             'INP',
             'MIQ', -- Message in queue
             NULL);
          
          COMMIT;
        END IF;

        
        v_count := v_count + 1;
      END LOOP;
      
      IF (v_send_as_sms_yn = 'Y') THEN
        IF v_sms_phone IS NOT NULL THEN
           v_sms            := v_sms_phone;
        ELSE
          v_remarks := 'Primary SMS number is not present ';
        END IF;
        
        OPEN recovery_cur;
        FETCH recovery_cur INTO recovery_rec;
        CLOSE recovery_cur;
        
        
        IF v_message_type_id IN ('PREAUTH_SHORTFALL', 'PREAUTH_SHORTFALL_RECEIVED', 'PREAUTH_APPROVED', 'PREAUTH_REJECTED') AND recovery_rec.recovery_msg_yn = 'Y' THEN
          v_speed_recovery := recovery_rec.recovery_msg;--'AlKoot wishes you a speedy recovery.';
          
          INSERT INTO DESTINATION_MESSAGE
          (DEST_MSG_SEQ_ID,
           MSG_ID,
           SOURCE_ID,
           SOURCE_SEQ_ID,
           MSG_SENT_FROM,
           MESSAGE_TITLE,
           SMS_DESCRIPTION,
           ADDED_BY,
           ADDED_DATE,
           ENROLLMENT_NUMBER
           )
        VALUES
          (DESTINATION_MESSAGE_SEQ.NEXTVAL,
           v_message_type_id,
           v_module_name,
           v_parameters,
           v_sent_from,
           v_msg_title,
           v_speed_recovery,
           v_added_by,
           sysdate,
           v_case_number
           )
           RETURNING DEST_MSG_SEQ_ID INTO v_DEST_MSG_SEQ_ID;
           
     
      INSERT INTO DESTINATION_MESSAGE_RCPT
            (DEST_MSG_RCPT_SEQ_ID,
             DEST_MSG_SEQ_ID,
             --PRM_RCPT_EMAIL_LIST,
             PRM_RCPT_SMS,
             PRM_RCPT_FAX_NOS,
             REMARKS,
             ADDED_BY,
             ADDED_DATE,
             MSG_TYPE,
             PRESENT_YN,
             MAIL_STATUS,
             MSG_STATUS_GENERAL_TYPE_ID,
             SENT_DATE)
          VALUES
            (DESTINATION_MESSAGE_RCPT_SEQ.NEXTVAL,
             v_DEST_MSG_SEQ_ID,
             --v_email_id, --'thomas.vazhappilly@vidalhealth.com',--v_email_ids,
             v_sms,
             v_fax,
             v_remarks,
             v_added_by,
             sysdate,
             'SMS',
             v_present_yn, --v_present_yn,
             'INP',
             'MIQ', -- Message in queue
             NULL);

        END IF;   
      END IF;
      -- Insert the correspondences into the Alert Log.
      IF (v_notification_type = 'PREAUTH') THEN
        IF v_message_type_id LIKE 'PREAUTH_SHORTFALL%' THEN
          select nvl(s.pat_gen_detail_seq_id,0) into v_pat_gen_detail_seq_id
          from shortfall_details s
          where s.shortfall_seq_id = v_parameters;
        END IF;
        
        INSERT INTO PAT_LOG
          (PAT_LOG_SEQ_ID,
           SYSTEM_GEN_YN,
           PAT_LOG_GENERAL_TYPE_ID,
           REFERENCE_DATE,
           REMARKS,
           ADDED_BY,
           ADDED_DATE,
           PAT_GEN_DETAIL_SEQ_ID)
        VALUES
          (PAT_LOG_SEQ.NEXTVAL,
           'Y',
           'COM',
           SYSDATE,
           v_final_log_message,
           v_added_by,
           SYSDATE,
           v_pat_gen_detail_seq_id);

      ELSIF (v_notification_type = 'CLAIMS') THEN
        IF v_message_type_id LIKE 'CLAIM_SHORTFALL%' THEN
          select nvl(s.pat_gen_detail_seq_id,0) into v_pat_gen_detail_seq_id
          from shortfall_details s
          where s.shortfall_seq_id = v_parameters;
        END IF;
        
        INSERT INTO PAT_LOG
          (PAT_LOG_SEQ_ID,
           SYSTEM_GEN_YN,
           PAT_LOG_GENERAL_TYPE_ID,
           REFERENCE_DATE,
           REMARKS,
           ADDED_BY,
           ADDED_DATE,
           CLAIM_SEQ_ID)
        VALUES
          (PAT_LOG_SEQ.NEXTVAL,
           'Y',
           'COM',
           SYSDATE,
           v_final_log_message,
           v_added_by,
           SYSDATE,
           v_claim_seq_id);
           
       ELSIF (v_notification_type = 'PARTNER_PREAUTH') THEN 
       
       
        INSERT INTO PAT_LOG
          (PAT_LOG_SEQ_ID,
           SYSTEM_GEN_YN,
           PAT_LOG_GENERAL_TYPE_ID,
           REFERENCE_DATE,
           REMARKS,
           ADDED_BY,
           ADDED_DATE,
           PAT_GEN_DETAIL_SEQ_ID)
        VALUES
          (PAT_LOG_SEQ.NEXTVAL,
           'Y',
           'COM',
           SYSDATE,
           v_final_log_message,
           v_added_by,
           SYSDATE,
           NULL);

      END IF;

      COMMIT;
   -- END IF;
  END proc_generate_message;


  --=============================================================================================
  -- This procedure will merge the raw message along with the data and provides the merged data.
  --=============================================================================================
  PROCEDURE proc_mail_merge(v_message_type_id VARCHAR2,
                            v_option          VARCHAR2,
                            v_clean_up        VARCHAR2,
                            v_merged_message  OUT VARCHAR2) IS
    v_counter        NUMBER := 0;
    v_posn           NUMBER;
    v_posn1          NUMBER;
    v_length         NUMBER;
    v_string         VARCHAR2(4000);
    v_raw_message    VARCHAR2(32767);
    v_general_params v_array := v_array(1,
                                        2,
                                        3,
                                        4,
                                        5,
                                        6,
                                        7,
                                        8,
                                        9,
                                        10,
                                        11,
                                        12,
                                        13,
                                        14,
                                        15,
                                        16,
                                        17,
                                        18,
                                        19);
  
    -- This is to get the Raw Message
    CURSOR cr_get_raw_message(v_message_type_id VARCHAR2) IS
      SELECT MSG_DESCRIPTION
        FROM APP.SOURCE_MESSAGE
       WHERE MSG_ID = v_message_type_id;

  
    -- This is to get the Raw Message
    CURSOR cr_get_raw_SMS_message(v_message_type_id VARCHAR2) IS
      SELECT SMS_DESCRIPTION
        FROM APP.SOURCE_MESSAGE
       WHERE MSG_ID = v_message_type_id;

  
  BEGIN
    IF (v_option = 'ON_MESSAGE') THEN
      -- retrieve the Raw message for the selected Message Type Id
      OPEN cr_get_raw_message(v_message_type_id);
      FETCH cr_get_raw_message
        INTO v_raw_message;
      CLOSE cr_get_raw_message;
    
      v_general_params := v_params;
    ELSIF (v_option = 'ON_SMS_MESSAGE') THEN
      -- retrieve the Raw SMS message for the selected Message Type Id
      OPEN cr_get_raw_SMS_message(v_message_type_id);
      FETCH cr_get_raw_SMS_message
        INTO v_raw_message;
      CLOSE cr_get_raw_SMS_message;
    
      v_general_params := v_SMS_params;

    ELSIF ((v_option = 'ON_EMAIL') OR (v_option = 'ON_TITLE')) THEN
      v_raw_message    := v_clean_up;
      v_general_params := v_params;

    END IF;

  
    v_posn    := INSTR(v_raw_message, '~C', 1);
    v_posn1   := 1;
    v_counter := 1;
  
    WHILE v_posn > 0 LOOP
      v_posn1       := INSTR(v_raw_message, '~', v_posn + 2);
      v_length      := (v_posn1 - v_posn) + 1;
      v_string      := SUBSTR(v_raw_message, v_posn, v_length);
      v_raw_message := REPLACE(v_raw_message,
                               v_string,
                               v_general_params(v_counter));
      v_posn        := INSTR(v_raw_message, '~C', v_posn);
      v_counter     := v_counter + 1;
    END LOOP;

  
    v_merged_message := v_raw_message;
  END;


  --=============================================================================================
  -- This procedure will be used to verify whether the fax number sent is valid or not
  --=============================================================================================
  PROCEDURE proc_verify_communication(v_message_type_id VARCHAR2,
                                      v_data            VARCHAR2) IS
    v_count NUMBER;

  BEGIN
    IF (v_message_type_id = 'FAX') THEN
      IF (v_data IS NULL) THEN
        RAISE_APPLICATION_ERROR(-20542, 'Invalid Fax number');
      END IF;

    
      SELECT LENGTH(REGEXP_REPLACE(v_data, '\d')) INTO v_count FROM dual;

    
      IF (v_count > 0) THEN
        RAISE_APPLICATION_ERROR(-20542, 'Invalid Fax number');
      END IF;

    END IF;

  END;

  --=============================================================================================
  -- This procedure gets enrollment number from tpa_enr_mem_card_dtl for a batch_seq_id and
  -- would call proc_form_message procedure
  --=============================================================================================

  PROCEDURE proc_enr_numbers(v_batch_seq NUMBER) IS
    v_DEST_MSG_SEQ_ID VARCHAR2(20);
    v_added_by        Destination_Message.Added_By%Type;

  BEGIN
  
    FOR rec IN (SELECT DISTINCT Policy_Group_Seq_Id
                  FROM tpa_enr_mem_card_dtl
                 WHERE Card_Batch_Seq_Id = v_batch_seq) LOOP
      proc_form_message('E_CARDS',
                        rec.Policy_Group_Seq_Id,
                        v_DEST_MSG_SEQ_ID,
                        v_added_by);
      UPDATE DESTINATION_MESSAGE
         SET file_path_name = file_path_name || v_batch_seq || '/'
       WHERE DEST_MSG_SEQ_ID = v_DEST_MSG_SEQ_ID;

    END LOOP;

  
    COMMIT;
  END proc_enr_numbers;

  --=============================================================================================
  -- This procedure is called from the front end to update the status of each of the email.
  --=============================================================================================

  PROCEDURE update_message_rcpt_status(v_dest_msg_rcpt_seq_id   IN NUMBER,
                                       v_mail_status            IN VARCHAR2,
                                       v_message_job_id         IN VARCHAR2,
                                       v_message_remarks        IN VARCHAR2,
                                       v_status_general_type_id IN VARCHAR2) IS
  BEGIN
    IF v_mail_status IS NOT NULL THEN
      UPDATE destination_message_rcpt A
         SET A.mail_status    = v_mail_status,
             A.message_job_id = v_message_job_id,
             A.sent_date      = SYSDATE
       WHERE A.dest_msg_rcpt_seq_id = v_dest_msg_rcpt_seq_id;

    ELSE
      UPDATE destination_message_rcpt A
         SET A.message_remarks            = v_message_remarks,
             A.msg_status_general_type_id = v_status_general_type_id
       WHERE A.dest_msg_rcpt_seq_id = v_dest_msg_rcpt_seq_id;

    END IF;

    COMMIT;
  END update_message_rcpt_status;


  --=============================================================================================
  -- This procedure will validate whether for a particular Group iD, whether the message should be sent or not.
  -- This happens on the customisation done at Group level.
  PROCEDURE validate_process_mail(v_message_type_id      VARCHAR2, -- The Actual Message id generated by the application
                                  v_parameters           VARCHAR2,
                                  v_mail_category        VARCHAR2, -- The send message id is of what type in Database
                                  v_process_yn           OUT VARCHAR2, -- Can the process be done or not
                                  v_general_mail         OUT VARCHAR2, -- Generic TO Email id created at the group
                                  v_cc_mail              OUT VARCHAR2, -- Generic CC Email id created at the group
                                  v_group_name           OUT VARCHAR2,
                                  v_customise_allowed_YN VARCHAR2) IS
    v_count                    NUMBER;
    v_enrol_type_id            PAT_ENROLL_DETAILS.Enrol_Type_Id%TYPE;
    v_general_mail_id          tpa_group_registration.notify_email_id%TYPE;
    v_cc_mail_id               tpa_group_registration.cc_email_id%TYPE;
    v_mail_cat_general_type_id tpa_group_registration.notify_type_id%TYPE;
    v_group_reg_seq_id         tpa_group_registration.group_reg_seq_id%TYPE;
  
    -- PRE-Auth REGULAR
    CURSOR cr_get_regular_preauth(v_pat_gen_detail_seq_id pat_general_details.pat_gen_detail_seq_id%TYPE) IS
      SELECT pat_enroll_details.enrol_type_id,
             tpa_group_registration.notify_email_id,
             tpa_group_registration.cc_email_id,
             tpa_group_registration.notify_type_id,
             pat_enroll_details.group_reg_seq_id,
             tpa_group_registration.group_name
        FROM pat_enroll_details,
             pat_general_details,
             tpa_group_registration
       WHERE (pat_enroll_details.group_reg_seq_id =
             tpa_group_registration.group_reg_seq_id)
         and (pat_general_details.pat_enroll_detail_seq_id =
             pat_enroll_details.pat_enroll_detail_seq_id)
         and (pat_general_details.pat_gen_detail_seq_id =
             v_pat_gen_detail_seq_id);

  
    -- Pre-Auth Shortfall
    CURSOR cr_get_shortfall_regular(v_shortfall_seq_id shortfall_details.SHORTFALL_SEQ_ID%TYPE) IS
      SELECT pat_enroll_details.enrol_type_id,
             tpa_group_registration.notify_email_id,
             tpa_group_registration.cc_email_id,
             tpa_group_registration.notify_type_id,
             pat_enroll_details.group_reg_seq_id,
             tpa_group_registration.group_name
        FROM pat_enroll_details,
             pat_general_details,
             shortfall_details A,
             tpa_group_registration
       WHERE (pat_enroll_details.group_reg_seq_id =
             tpa_group_registration.group_reg_seq_id)
         and (pat_general_details.pat_enroll_detail_seq_id =
             pat_enroll_details.pat_enroll_detail_seq_id)
         and (pat_general_details.pat_gen_detail_seq_id =
             A.PAT_GEN_DETAIL_SEQ_ID)
         and (A.SHORTFALL_SEQ_ID = v_shortfall_seq_id);

  
    CURSOR cr_get_claims_inward(v_inward_seq_id clm_inward.claims_inward_seq_id%TYPE) IS
      SELECT clm_enroll_details.enrol_type_id,
             tpa_group_registration.notify_email_id,
             tpa_group_registration.cc_email_id,
             tpa_group_registration.notify_type_id,
             clm_enroll_details.group_reg_seq_id,
             tpa_group_registration.group_name
        FROM clm_enroll_details,
             clm_general_details,
             clm_inward,
             tpa_group_registration
       WHERE (clm_enroll_details.group_reg_seq_id =
             tpa_group_registration.group_reg_seq_id)
         and (clm_general_details.claim_seq_id =
             clm_enroll_details.claim_seq_id)
         and (clm_inward.claims_inward_seq_id =
             clm_general_details.claims_inward_seq_id)
         and (clm_inward.claims_inward_seq_id = v_inward_seq_id);

  
    CURSOR cr_get_claims_status(v_seq_id clm_general_details.claim_seq_id%TYPE) IS
      SELECT clm_enroll_details.enrol_type_id,
             tpa_group_registration.notify_email_id,
             tpa_group_registration.cc_email_id,
             tpa_group_registration.notify_type_id,
             clm_enroll_details.group_reg_seq_id,
             tpa_group_registration.group_name
        FROM tpa_group_registration,
             clm_enroll_details,
             clm_general_details
       WHERE (clm_enroll_details.group_reg_seq_id =
             tpa_group_registration.group_reg_seq_id)
         and (clm_general_details.claim_seq_id =
             clm_enroll_details.claim_seq_id)
         and (clm_general_details.claim_seq_id = v_seq_id);

  
    CURSOR cr_get_claim_shortfall_regular(v_shortfall_seq_id shortfall_details.SHORTFALL_SEQ_ID%TYPE) IS
      SELECT clm_enroll_details.Enrol_Type_Id,
             tpa_group_registration.notify_email_id,
             tpa_group_registration.cc_email_id,
             tpa_group_registration.notify_type_id,
             clm_enroll_details.group_reg_seq_id,
             tpa_group_registration.group_name
        FROM tpa_group_registration,
             clm_enroll_details,
             clm_general_details,
             shortfall_details
       WHERE (clm_enroll_details.group_reg_seq_id =
             tpa_group_registration.group_reg_seq_id)
         and (clm_general_details.CLAIM_SEQ_ID =
             clm_enroll_details.CLAIM_SEQ_ID)
         and (clm_general_details.claim_seq_id =
             shortfall_details.CLAIM_SEQ_ID)
         and (shortfall_details.SHORTFALL_SEQ_ID = v_shortfall_seq_id);

  
    CURSOR cr_get_ONLINE_ASSISTANCE(v_seq_id ONLINE_QUERY_DETAILS.QUERY_DETAILS_SEQ_ID%TYPE) IS
      SELECT C.Enrol_Type_Id,
             tpa_group_registration.notify_email_id,
             tpa_group_registration.cc_email_id,
             tpa_group_registration.notify_type_id,
             tpa_group_registration.group_reg_seq_id,
             tpa_group_registration.group_name
        FROM tpa_group_registration,
             ONLINE_QUERY_DETAILS   A,
             ONLINE_QUERY_HEADER    B,
             TPA_ENR_POLICY         C
       WHERE (C.GROUP_REG_SEQ_ID = tpa_group_registration.group_reg_seq_id)
         and (B.POLICY_SEQ_ID = C.POLICY_SEQ_ID)
         and (B.QUERY_HEADER_SEQ_ID = A.QUERY_HEADER_SEQ_ID)
         AND (A.QUERY_DETAILS_SEQ_ID = v_seq_id);

  
    -- Query is used to generate notification for EFT, Payadvice and Manual Cheque generation.
    CURSOR cr_get_FINANCIAL_PAYMENT(v_payment_seq_id TPA_CLAIMS_PAYMENT.PAYMENT_SEQ_ID%Type) IS
      SELECT ce.Enrol_Type_Id,
             gr.notify_email_id,
             gr.cc_email_id,
             gr.notify_type_id,
             ce.group_reg_seq_id,
             gr.group_name
        FROM clm_enroll_details ce
       INNER JOIN clm_general_details cg
          ON ce.claim_seq_id = cg.claim_seq_id
       INNER JOIN tpa_claims_payment cp
          ON cg.claim_seq_id = cp.claim_seq_id
       INNER JOIN tpa_group_registration gr
          ON ce.group_reg_seq_id = gr.group_reg_seq_id
       WHERE cp.payment_seq_id = v_payment_seq_id;

  
    -- Query is used to generate notification on expiry of first login window period.
    CURSOR cr_get_1st_LOGIN_PERIOD_CLOSED(v_policy_group_seq_id TPA_ENR_POLICY_GROUP.POLICY_GROUP_SEQ_ID%Type) IS
      SELECT p.Enrol_Type_Id,
             gr.notify_email_id,
             gr.cc_email_id,
             gr.notify_type_id,
             p.group_reg_seq_id,
             gr.group_name
        FROM tpa_enr_policy_group g
       INNER JOIN tpa_enr_policy p
          ON p.policy_seq_id = g.policy_seq_id
       INNER JOIN tpa_group_registration gr
          ON gr.group_reg_seq_id = p.group_reg_seq_id
       WHERE g.policy_group_seq_id = v_policy_group_seq_id;

  BEGIN
  
    v_process_yn               := 'Y';
    v_general_mail             := NULL;
    v_mail_cat_general_type_id := v_mail_category;
  
    -- For following list of Message ID, Customisation should NOT BE allowed at Empanelment of Group Level
    -- 'CALLLOG_REPEAT', 'E_CARDS', 'MAX_CALL_RECEIVED', 'NEW_ONLINE_ENR_EMPLOYEE', 'NEW_USERID',
    -- 'NEW_USERID_GROUPID', 'NEW_USERID_INSCODE', 'ONLINE_EMPLOYEE_FAMILY_INFO', 'RESET_PASSWORD',
    -- 'RESET_PASSWORD_GROUPID', 'RESET_PASSWORD_INSCODE' );
  
    -- 1) If Customised allowed YN = 'N' - then these are default set of mails which cannot be customised.
    --    Just goes thru.
    -- 2) There are around 20 Odd emails which are Customisable.
    -- 3)
    IF (v_customise_allowed_YN = 'Y') THEN
      IF ((v_message_type_id = 'PREAUTH_STATUS') OR
         (v_message_type_id = 'PREAUTH_APPROVED') OR
         (v_message_type_id = 'PREAUTH_REJECTED') OR
         (v_message_type_id = 'PREAUTH_STATUS_MEDICAL')) THEN
        OPEN cr_get_regular_preauth(v_parameters);
        FETCH cr_get_regular_preauth
          INTO v_enrol_type_id,
               v_general_mail_id,
               v_cc_mail_id,
               v_mail_cat_general_type_id,
               v_group_reg_seq_id,
               v_group_name;
        CLOSE cr_get_regular_preauth;
      ELSIF ((v_message_type_id = 'PREAUTH_SHORTFALL') OR
            (v_message_type_id = 'PREAUTH_SHORTFALL_REMINDER')) THEN
        OPEN cr_get_shortfall_regular(v_parameters);
        FETCH cr_get_shortfall_regular
          INTO v_enrol_type_id,
               v_general_mail_id,
               v_cc_mail_id,
               v_mail_cat_general_type_id,
               v_group_reg_seq_id,
               v_group_name;
        CLOSE cr_get_shortfall_regular;

      ELSIF ((v_message_type_id = 'CLAIM_INWARD_MR') OR
            (v_message_type_id = 'CLAIM_INWARD_NHCP')) THEN
        OPEN cr_get_claims_inward(v_parameters);
        FETCH cr_get_claims_inward
          INTO v_enrol_type_id,
               v_general_mail_id,
               v_cc_mail_id,
               v_mail_cat_general_type_id,
               v_group_reg_seq_id,
               v_group_name;
        CLOSE cr_get_claims_inward;

      ELSIF ((v_message_type_id = 'CLAIM_STATUS_MR') OR
            (v_message_type_id = 'CLAIM_STATUS_NHCP') OR
            (v_message_type_id = 'CLAIM_MR_APPROVE') OR
            (v_message_type_id = 'CLAIM_NHCP_APPROVE') OR
            (v_message_type_id = 'CLAIM_MR_REJECTED') OR
            (v_message_type_id = 'CLAIM_NHCP_REJECTED')) THEN
        OPEN cr_get_claims_status(v_parameters);
        FETCH cr_get_claims_status
          INTO v_enrol_type_id,
               v_general_mail_id,
               v_cc_mail_id,
               v_mail_cat_general_type_id,
               v_group_reg_seq_id,
               v_group_name;
        CLOSE cr_get_claims_status;

      ELSIF ((v_message_type_id = 'CLAIM_SHORTFALL') OR
            (v_message_type_id = 'CLAIM_SHORTFALL_RECEIVED')) THEN
        OPEN cr_get_claim_shortfall_regular(v_parameters);
        FETCH cr_get_claim_shortfall_regular
          INTO v_enrol_type_id,
               v_general_mail_id,
               v_cc_mail_id,
               v_mail_cat_general_type_id,
               v_group_reg_seq_id,
               v_group_name;
        CLOSE cr_get_claim_shortfall_regular;

      ELSIF ((v_message_type_id = 'RECEIPT_ONLINE_ASSISTANCE') OR
            (v_message_type_id = 'RESPONSE_ONLINE_ASSISTANCE')) THEN
        OPEN cr_get_ONLINE_ASSISTANCE(v_parameters);
        FETCH cr_get_ONLINE_ASSISTANCE
          INTO v_enrol_type_id,
               v_general_mail_id,
               v_cc_mail_id,
               v_mail_cat_general_type_id,
               v_group_reg_seq_id,
               v_group_name;
        CLOSE cr_get_ONLINE_ASSISTANCE;

      ELSIF ((v_message_type_id = 'FINANCE_PAYMENT_EFT') OR
            (v_message_type_id = 'FINANCE_PAYMENT_CHQ') OR
            (v_message_type_id = 'FINANCE_PAYMENT_PAD')) THEN
        OPEN cr_get_FINANCIAL_PAYMENT(v_parameters);
        FETCH cr_get_FINANCIAL_PAYMENT
          INTO v_enrol_type_id,
               v_general_mail_id,
               v_cc_mail_id,
               v_mail_cat_general_type_id,
               v_group_reg_seq_id,
               v_group_name;
        CLOSE cr_get_FINANCIAL_PAYMENT;

      ELSIF v_message_type_id = 'FIRST_LOGIN_PERIOD_CLOSED' THEN
        OPEN cr_get_1st_LOGIN_PERIOD_CLOSED(v_parameters);
        FETCH cr_get_1st_LOGIN_PERIOD_CLOSED
          INTO v_enrol_type_id,
               v_general_mail_id,
               v_cc_mail_id,
               v_mail_cat_general_type_id,
               v_group_reg_seq_id,
               v_group_name;
        CLOSE cr_get_1st_LOGIN_PERIOD_CLOSED;

      END IF;

    
      -- This is to take care of those corporates where Mail type is not updated.
      -- Default all the corporates will have it as General.
      IF (v_mail_cat_general_type_id IS NULL) THEN
        v_mail_cat_general_type_id := 'NIG';
      END IF;

    
      /*         -- NIG - General Category, NIC - Customise
      IF ( v_enrol_type_id = 'COR' ) THEN
         IF ( ( v_mail_cat_general_type_id = 'NIG' ) AND ( v_mail_category = 'NIG' ) )  THEN
              v_process_yn   := 'Y'; -- Continue processing
         ELSIF ( ( v_mail_cat_general_type_id = 'NIG' ) AND ( v_mail_category = 'NIC' ) )  THEN
              v_process_yn := 'N';  -- DONT Continue processing
         ELSIF ( v_mail_cat_general_type_id = 'NIC' ) THEN
              -- Check in the Custom Source message for this Corporate whether Custom Message is mapped or not
              SELECT COUNT(1)
                INTO v_count
                FROM APP.SOURCE_MESSAGE_CUSTOM_GRP A
               WHERE A.MSG_ID           = v_message_type_id AND
                     A.GROUP_REG_SEQ_ID = v_group_reg_seq_id;
      
              IF ( v_count > 0 ) THEN
                 v_process_yn := 'Y';
              ELSE
                 v_process_yn := 'N';
              END IF;
         END IF;
      
         IF ( v_process_yn = 'Y' ) THEN
            v_general_mail := v_general_mail_id;
            v_cc_mail      := v_cc_mail_id;
         END IF;
      END IF;*/

    
      -- This is to take care of those corporates where Mail type is not updated.
      -- Default all the corporates will have it as General.
    
      -- NIG - General Category, NIC - Customise
      IF (v_enrol_type_id = 'COR') THEN
        IF (v_mail_cat_general_type_id = 'NIG') THEN
          v_process_yn := 'Y'; -- Continue processing
        ELSIF (v_mail_cat_general_type_id = 'NIC') THEN
          -- Check in the Custom Source message for this Corporate whether Custom Message is mapped or not
          SELECT COUNT(1)
            INTO v_count
            FROM APP.SOURCE_MESSAGE_CUSTOM_GRP A
           WHERE A.MSG_ID = v_message_type_id
             AND A.GROUP_REG_SEQ_ID = v_group_reg_seq_id;

        
          IF (v_count > 0) THEN
            v_process_yn := 'Y';
          ELSE
            v_process_yn := 'N';

          END IF;

        END IF;

      
        IF (v_process_yn = 'Y') THEN
          v_general_mail := v_general_mail_id;
          v_cc_mail      := v_cc_mail_id;
        END IF;

      END IF;

    END IF;

  END validate_process_mail;

  /* --=====================================================================================================
     Name       : generate_clm_shortfal_mails
      Created on : 07-01-2013
      Created By : Ibrahim Sayyed
      Company    : RCS Technologies
      Added for  : KOC1179
      modifeid by: RAM
      Modified date: 16-05-2013
      Comments   :   This procedure used to send claim shortfall requests (this procedure is calling internally)
  --=====================================================================================================*/


  PROCEDURE generate_clm_shortfal_mails(v_message_type    IN VARCHAR2,
                                        v_seq_id          IN VARCHAR2,
                                        v_request_type    IN VARCHAR2,
                                        v_dest_msg_seq_id OUT VARCHAR2,
                                        v_added_by        IN Destination_message.added_by%TYPE,
                                        v_rows_processed  OUT NUMBER) IS
  
    v_case_number VARCHAR2(250);
  
    CURSOR cr_get_shtfal_email_dtl(v_shortfal_email_seq_id NUMBER) IS
      SELECT a.shortfall_id,
             b.claim_number,
             (CASE d.claim_general_type_id
               WHEN 'CTM' THEN
                ttk_util_pkg.fn_decrypt(nvl(c.EMAIL_ID, k.email_id))
               WHEN 'CNH' THEN
                ttk_util_pkg.fn_decrypt(i.primary_email_id)
             END) AS email_id,
             TTK_UTIL_PKG.fn_decrypt(j.email_id) insurer_email_id,
             (CASE d.claim_general_type_id
               WHEN 'CTM' THEN
                nvl(c.NOTIFICATION_PHONE_NUMBER,
                    ttk_util_pkg.fn_decrypt(k.mobile_no))
               WHEN 'CNH' THEN
                i.off_phone_no_2
             END) AS notify_phone_num,
             nvl(F.EMPLOYEE_USER_ID, 'NA') AS EMPLOYEE_USER_ID,
             d.claim_general_type_id,
             ttk_util_pkg.fn_decrypt(nvl(c.EMAIL_ID, k.email_id)) as insured_email_id
        FROM shortfall_email_dtl se
        JOIN shortfall_details a
          ON (se.shortfall_seq_id = a.shortfall_seq_id)
        JOIN clm_general_details b
          ON (a.claim_seq_id = b.claim_seq_id)
        JOIN clm_enroll_details c
          ON (b.claim_seq_id = c.claim_seq_id)
        JOIN clm_inward d
          ON (b.claims_inward_seq_id = d.claims_inward_seq_id)
        LEFT OUTER JOIN tpa_enr_policy_member e
          ON (c.member_seq_id = e.member_seq_id)
        LEFT OUTER JOIN tpa_enr_policy_group f
          ON (e.policy_group_seq_id = f.policy_group_seq_id)
        LEFT OUTER JOIN tpa_enr_policy g
          ON (f.policy_seq_id = g.policy_seq_id)
        LEFT OUTER JOIN clm_hospital_association h
          ON (b.claim_seq_id = h.claim_seq_id)
        LEFT OUTER JOIN tpa_hosp_info i
          ON (h.hosp_seq_id = i.hosp_seq_id)
        LEFT OUTER JOIN tpa_ins_info j
          ON (c.ins_seq_id = j.ins_seq_id)
        LEFT OUTER JOIN tpa_enr_mem_address k
          ON (f.enr_address_seq_id = k.enr_address_seq_id)
       WHERE se.shortfal_email_seq_id = v_shortfal_email_seq_id; --need to change condition
  
    CURSOR cr_get_shtfal_dtl(v_shortfall_seq_id NUMBER) IS
      SELECT a.shortfall_id,
             b.claim_number,
             (CASE d.claim_general_type_id
               WHEN 'CTM' THEN
                ttk_util_pkg.fn_decrypt(nvl(c.EMAIL_ID, k.email_id))
               WHEN 'CNH' THEN
                ttk_util_pkg.fn_decrypt(i.primary_email_id)
             END) AS email_id,
             ttk_util_pkg.fn_decrypt(j.email_id) as insurer_email_id,
             (CASE d.claim_general_type_id
               WHEN 'CTM' THEN
                nvl(c.NOTIFICATION_PHONE_NUMBER,
                    ttk_util_pkg.fn_decrypt(k.mobile_no))
               WHEN 'CNH' THEN
                i.off_phone_no_2
             END) AS notify_phone_num,
             NVL(F.EMPLOYEE_USER_ID, 'NA') AS EMPLOYEE_USER_ID,
             d.claim_general_type_id,
             ttk_util_pkg.fn_decrypt(nvl(c.EMAIL_ID, k.email_id)) as insured_email_id
      
        FROM shortfall_details a
        JOIN clm_general_details b
          ON (a.claim_seq_id = b.claim_seq_id)
        JOIN clm_enroll_details c
          ON (b.claim_seq_id = c.claim_seq_id)
        JOIN clm_inward d
          ON (b.claims_inward_seq_id = d.claims_inward_seq_id)
        LEFT OUTER JOIN tpa_enr_policy_member e
          ON (c.member_seq_id = e.member_seq_id)
        LEFT OUTER JOIN tpa_enr_policy_group f
          ON (e.policy_group_seq_id = f.policy_group_seq_id)
        LEFT OUTER JOIN tpa_enr_policy g
          ON (f.policy_seq_id = g.policy_seq_id)
        LEFT OUTER JOIN clm_hospital_association h
          ON (b.claim_seq_id = h.claim_seq_id)
        LEFT OUTER JOIN tpa_hosp_info i
          ON (h.hosp_seq_id = i.hosp_seq_id)
        LEFT OUTER JOIN tpa_ins_info j
          ON (c.ins_seq_id = j.ins_seq_id)
        LEFT OUTER JOIN tpa_enr_mem_address k
          ON (f.enr_address_seq_id = k.enr_address_seq_id)
       WHERE a.shortfall_seq_id = v_shortfall_seq_id; --need to change condition
  
    rec_get_shtfal_email_dtl cr_get_shtfal_email_dtl%ROWTYPE;
  
    CURSOR cr_get_core_mesg_dtl(v_message_type_id VARCHAR2) IS
      SELECT module_name,
             msg_sent_from,
             message_title,
             send_as_email_yn,
             send_as_sms_yn,
             send_as_fax_yn,
             prm_rcpt_email_list,
             sec_rcpt_email_list,
             mail_cat_general_type_id,
             customization_allowed_yn
        FROM APP.SOURCE_MESSAGE A
       WHERE msg_id = v_message_type_id;

  
    rec_get_core_mesg_dtl cr_get_core_mesg_dtl%ROWTYPE;
  
    v_enrollment_number    TPA_ENR_POLICY_GROUP.tpa_enrollment_number%TYPE;
    v_msg_type             DESTINATION_MESSAGE_RCPT.msg_type%TYPE;
    v_general_mail         DESTINATION_MESSAGE_RCPT.prm_rcpt_email_list%TYPE; -- Generic mail id created at the group
    v_cc_mail              DESTINATION_MESSAGE_RCPT.sec_rcpt_email_list%TYPE;
    v_group_name           TPA_GROUP_REGISTRATION.group_name%TYPE;
    v_module_name          APP.SOURCE_MESSAGE.module_name%TYPE;
    v_sent_from            APP.SOURCE_MESSAGE.msg_sent_from%TYPE;
    v_msg_title            APP.SOURCE_MESSAGE.message_title%TYPE;
    v_send_as_email_yn     APP.SOURCE_MESSAGE.send_as_email_yn%TYPE;
    v_send_as_sms_yn       APP.SOURCE_MESSAGE.send_as_sms_yn%TYPE;
    v_send_as_fax_yn       APP.SOURCE_MESSAGE.send_as_fax_yn%TYPE;
    v_prm_rcpt_list        APP.SOURCE_MESSAGE.prm_rcpt_email_list%TYPE;
    v_sec_rcpt_list        APP.SOURCE_MESSAGE.sec_rcpt_email_list%TYPE;
    v_customise_allowed_YN APP.SOURCE_MESSAGE.customization_allowed_yn%TYPE;
    v_document_name        DESTINATION_MESSAGE.file_path_name%TYPE;
    v_email_ids            DESTINATION_MESSAGE_RCPT.PRM_RCPT_EMAIL_LIST%TYPE;
    v_sms                  DESTINATION_MESSAGE_RCPT.PRM_RCPT_SMS%TYPE;
    v_fax                  DESTINATION_MESSAGE_RCPT.PRM_RCPT_FAX_NOS%TYPE;
    v_present_yn           destination_message_rcpt.present_yn%TYPE;
    v_email_id             tpa_user_contacts.primary_email_id%TYPE;
    v_sms_phone            TPA_HOSP_INFO.off_phone_no_2%TYPE;
    v_fax_number           TPA_HOSP_INFO.office_fax_no%TYPE;
    v_merged_message       VARCHAR2(10000); --koc_ins_mail
    v_merged_SMS_message   VARCHAR2(4000);
    v_process_yn           VARCHAR2(1); -- Can the process be done or not
    v_mail_category        VARCHAR2(3);
    v_count                NUMBER(5);
    v_insert_message       VARCHAR2(1);
    v_remarks              VARCHAR2(250);
  
    --koc_ins_mail
    CURSOR get_cigna_clm_srtfall(v_shortfal_seq_id NUMBER) IS
      SELECT b.claim_seq_id,
             a.policy_number,
             pr.product_name,
             b.claim_number,
             a.claimant_name,
             gr.insured_name pol_holder_name,
             ttk_util_pkg.fn_decrypt(a.email_id) as pol_hold_email_id,
             nvl(hos.hosp_name, C.hosp_name) as hosp_name,
             nvl(had.address_1, C.address_1) || ',' ||
             nvl(had.address_2, C.address_2) || ',' ||
             nvl(had.address_3, C.address_3) hos_address,
             aid.ailment_description,
             ag.agent_name,
             ttk_util_pkg.fn_decrypt(ag.email_id) agent_mail,
             d.rcvd_date,
             gen.description reason,
             b.total_app_amount,
             ttk_util_pkg.num_to_words(b.total_app_amount) final_amt_words,
             ttk_util_pkg.fn_decrypt(A.notification_phone_number) as claimant_phone,
             ag.mobile_id as agent_phone,
             sed.intl_shortfal_snt_date,
             sed.rmdr_req_snt_date,
             sed.clsr_notice_snt_date,
             nvl(ci.clm_intimation_id, cl.call_log_number) as clm_intimation_num
        FROM clm_enroll_details a
        join clm_general_details b
          on (a.claim_seq_id = b.claim_seq_id)
        left outer join clm_hospital_association c
          on (c.claim_seq_id = b.claim_seq_id)
        join clm_inward d
          on (d.claims_inward_seq_id = b.claims_inward_seq_id)
        join tpa_enr_policy_member mem
          on (mem.member_seq_id = a.member_seq_id)
        join tpa_enr_policy_group gr
          on (gr.policy_group_seq_id = mem.policy_group_seq_id)
        left outer join tpa_enr_policy pol
          on (pol.policy_seq_id = a.policy_seq_id)
        left outer join TPA_HOSP_INFO hos
          on (hos.hosp_seq_id = c.hosp_seq_id)
        left outer join tpa_hosp_address had
          on (had.hosp_seq_id = hos.hosp_seq_id)
        left outer join tpa_ins_product pr
          on (pr.product_seq_id = pol.product_seq_id)
        left outer join ailment_details aid
          on (aid.claim_seq_id = b.claim_seq_id)
        left outer join shortfall_details sh
          on (sh.claim_seq_id = b.claim_seq_id)
        left outer join app.shortfall_email_dtl sed
          on (sed.shortfall_seq_id = sh.shortfall_seq_id)
        left outer join tpa_general_code gen
          on (gen.general_type_id = a.rson_general_type_id)
      ----------
        LEFT OUTER JOIN TPA_CALL_LOG CL
          ON (CL.CALL_LOG_SEQ_ID = B.CALL_LOG_SEQ_ID)
        LEFT OUTER JOIN TPA_CALL_CLAIM_INTIMATION CI
          ON (CI.CALL_LOG_SEQ_ID = CL.CALL_LOG_SEQ_ID)
        left outer join app.tpa_ins_agent_details ag
          on (ag.policy_seq_id = pol.policy_seq_id)
       where (sh.shortfall_seq_id = v_shortfal_seq_id or
             sed.shortfal_email_seq_id = v_shortfal_seq_id);

  
    get_cigna_clm_srtfall_rec get_cigna_clm_srtfall%rowtype;
  
    CURSOR get_cigna_pat_srtfall(v_shortfal_seq_id NUMBER) IS
      SELECT b.pat_gen_detail_seq_id,
             a.policy_number,
             pr.product_name,
             a.pre_auth_number,
             a.claimant_name,
             gr.insured_name pol_holder_name,
             ttk_util_pkg.fn_decrypt(a.email_id) as pol_hold_email_id,
             hos.hosp_name,
             had.address_1 || ',' || had.address_2 || ',' || had.address_3 hos_address,
             aid.ailment_description,
             ag.agent_name,
             ttk_util_pkg.fn_decrypt(ag.email_id) agent_mail,
             b.pat_received_date,
             gen.description reason,
             b.total_app_amount,
             ttk_util_pkg.num_to_words(b.total_app_amount) final_amt_words,
             ttk_util_pkg.fn_decrypt(b.phone_no_in_hospitalisation) as claimant_phone,
             ag.mobile_id as agent_phone
        FROM pat_enroll_details a
        join pat_general_details b
          on (a.pat_enroll_detail_seq_id = b.pat_enroll_detail_seq_id)
        join tpa_enr_policy_member mem
          on (a.member_seq_id = mem.member_seq_id)
        join tpa_enr_policy_group gr
          on (mem.policy_group_seq_id = gr.policy_group_seq_id)
        join tpa_enr_policy pol
          on (pol.policy_seq_id = a.policy_seq_id)
        left outer join TPA_HOSP_INFO hos
          on (a.hosp_seq_id = hos.hosp_seq_id)
        left outer join tpa_hosp_address had
          on (had.hosp_seq_id = hos.hosp_seq_id)
        left outer join tpa_ins_product pr
          on (pr.product_seq_id = pol.product_seq_id)
        left outer join ailment_details aid
          on (aid.pat_gen_detail_seq_id = b.pat_gen_detail_seq_id)
        left outer join shortfall_details sh
          on (sh.pat_gen_detail_seq_id = b.pat_gen_detail_seq_id)
        left outer join shortfall_email_dtl se
          on (sh.shortfall_seq_id = se.shortfall_seq_id)
        left outer join tpa_general_code gen
          on (gen.general_type_id = a.rson_general_type_id)
        left outer join tpa_ins_agent_details ag
          on (ag.policy_seq_id = pol.policy_seq_id)
       where sh.shortfall_seq_id = v_shortfal_seq_id;

  
    get_cigna_pat_srtfall_rec get_cigna_pat_srtfall%rowtype;
  
    CURSOR get_off_srtfall_mail(v_shortfal_seq_id NUMBER) IS(
      SELECT case
               when toi.shortfall_br_email_id is null then
                toi.email_id
               else
                toi.shortfall_br_email_id
             end as Email_id
        FROM SHORTFALL_DETAILS sd
        join clm_enroll_details ce
          on (sd.claim_seq_id = ce.claim_seq_id)
        join tpa_enr_policy tep
          on (ce.policy_seq_id = tep.policy_seq_id)
        join tpa_office_info toi
          on (tep.tpa_office_seq_id = toi.tpa_office_seq_id)
       WHERE sd.shortfall_seq_id = v_shortfal_seq_id);

  
    get_off_srtfall_mail_rec get_off_srtfall_mail%rowtype;
  
    CURSOR get_off_srtfall_email(v_shortfal_seq_id NUMBER) IS(
      SELECT case
               when toi.shortfall_br_email_id is null then
                toi.email_id
               else
                toi.shortfall_br_email_id
             end as Email_id
        FROM app.shortfall_email_dtl se
        join clm_enroll_details ce
          on (se.claim_seq_id = ce.claim_seq_id)
        join tpa_enr_policy tep
          on (ce.policy_seq_id = tep.policy_seq_id)
        join tpa_office_info toi
          on (tep.tpa_office_seq_id = toi.tpa_office_seq_id)
       WHERE se.shortfal_email_seq_id = v_shortfal_seq_id);

  
    get_off_srtfall_email_rec get_off_srtfall_email%rowtype;
  
    v_message_type_id varchar2(1000); --koc_ins_mail
    v_shrtfall_que    varchar2(4000); --koc_ins_mail
    V_CIGNA_MESAGE    CLOB; --koc_ins_mail
    v_mesg_id         varchar2(1000); --koc_ins_mail
    str_tab           ttk_util_pkg.str_table_type; --koc_ins_mail

  
  BEGIN
    IF instr(v_message_type, '|') > 0 THEN
      v_mesg_id := ('|' || v_message_type || '|');
      str_tab   := ttk_util_pkg.parse_str(v_mesg_id);
    ELSE
      str_tab(1) := v_message_type;

    END IF;

    FOR i IN str_tab.FIRST .. str_tab.LAST LOOP
      v_message_type_id := str_tab(i);
    
      v_enrollment_number := NULL;
      v_msg_type          := NULL;
      OPEN cr_get_core_mesg_dtl(v_message_type_id);
      FETCH cr_get_core_mesg_dtl
        INTO v_module_name,
             v_sent_from,
             v_msg_title,
             v_send_as_email_yn,
             v_send_as_sms_yn,
             v_send_as_fax_yn,
             v_prm_rcpt_list,
             v_sec_rcpt_list,
             v_mail_category,
             v_customise_allowed_YN;
      CLOSE cr_get_core_mesg_dtl;
    
      proc_get_ccemail_dtls(v_message_type_id,
                            v_seq_id,
                            v_mail_category,
                            v_process_yn,
                            v_general_mail,
                            v_cc_mail,
                            v_customise_allowed_YN);
    
      IF v_process_yn = 'Y' THEN
        IF v_message_type_id IN
           ('INITIAL_SHORTFALL_REQUEST',
            'SHORTFALL_REMINDER_REQUEST',
            'SHORTFALL_CLOSURE_NOTICE',
            'SHORTFALL_CLOSURE_APPROVAL',
            'SHORTFALL_CLOSURE_LETTER',
            'CLAIM_SHORTFALL_REGRET',
            'CLAIM_SHORTFALL_WAIVER',
            'CLAIM_SHORTFALL_REOPEN_RECOMMANDATION',
            'CLAIM_SHORTFALL_NONREOPEN_RECOMMANDATION',
            --koc_ins_mail
            'CIGNA_CLM_DOC_SHFALL_EMAIL_PO',
            'CIGNA_CLM_DOC_SHFALL_EMAIL_AD',
            'CIGNA_CLM_SHFALL_REM1_EMAIL_AD',
            'CIGNA_CLM_SHFALL_REM2_EMAIL_AD',
            'CIGNA_CLM_SHFALL_REM1_EMAIL_PO',
            'CIGNA_CLM_SHFALL_REM2_EMAIL_PO',
            'CIGNA_PAT_SHFALL_FRST_EMAIL_PO',
            'CIGNA_PAT_SHFALL_FRST_EMAIL_AD',
            'CIGNA_PAT_SHFALL_REM1_EMAIL_PO',
            'CIGNA_PAT_SHFALL_REM1_EMAIL_AD',
            'CIGNA_PAT_SHFALL_FNL_EMAIL_PO',
            'CIGNA_PAT_SHFALL_FNL_EMAIL_AD') THEN
        
          IF v_message_type_id IN
             ('INITIAL_SHORTFALL_REQUEST',
              'SHORTFALL_CLOSURE_LETTER',
              'SHORTFALL_REMINDER_REQUEST',
              'SHORTFALL_CLOSURE_NOTICE',
              'CLAIM_SHORTFALL_REGRET') THEN
          
            IF v_message_type_id = 'INITIAL_SHORTFALL_REQUEST' THEN
            
              OPEN cr_get_shtfal_dtl(v_seq_id);
              FETCH cr_get_shtfal_dtl
                INTO rec_get_shtfal_email_dtl;
              CLOSE cr_get_shtfal_dtl;
            
              OPEN get_off_srtfall_mail(v_seq_id);
              FETCH get_off_srtfall_mail
                INTO get_off_srtfall_mail_rec;
              CLOSE get_off_srtfall_mail;
            
            ELSIF v_message_type_id IN
                  ('SHORTFALL_REMINDER_REQUEST',
                   'SHORTFALL_CLOSURE_LETTER',
                   'SHORTFALL_CLOSURE_NOTICE',
                   'CLAIM_SHORTFALL_REGRET') THEN
            
              OPEN cr_get_shtfal_email_dtl(v_seq_id);
              FETCH cr_get_shtfal_email_dtl
                INTO rec_get_shtfal_email_dtl;
              CLOSE cr_get_shtfal_email_dtl;
            
              OPEN get_off_srtfall_email(v_seq_id);
              FETCH get_off_srtfall_email
                INTO get_off_srtfall_email_rec;
              CLOSE get_off_srtfall_email;
            
            END IF;

          
            v_email_id  := rec_get_shtfal_email_dtl.email_id;
            v_sms_phone := rec_get_shtfal_email_dtl.notify_phone_num;
          
            v_params(1) := rec_get_shtfal_email_dtl.claim_number;
            v_params(2) := rec_get_shtfal_email_dtL.EMPLOYEE_USER_ID;
            proc_mail_merge(v_message_type_id,
                            'ON_TITLE',
                            v_msg_title,
                            v_msg_title);
            IF v_message_type_id = 'INITIAL_SHORTFALL_REQUEST' THEN
              v_params(1) := get_off_srtfall_mail_rec.email_id; --koc_off_mail 
            ELSE
              v_params(1) := get_off_srtfall_email_rec.email_id; --koc_off_mail 

            END IF;

            proc_mail_merge(v_message_type_id,
                            'ON_MESSAGE',
                            NULL,
                            v_merged_message);
          
            v_SMS_params(1) := rec_get_shtfal_email_dtl.claim_number;
          
            IF v_message_type_id = 'INITIAL_SHORTFALL_REQUEST' THEN
            
              v_document_name := rec_get_shtfal_email_dtl.shortfall_id;
            ELSE
              v_document_name := v_request_type || '-' ||
                                 rec_get_shtfal_email_dtl.shortfall_id;

            END IF;

          
          ELSIF v_message_type_id IN
                ('RECOMMENDING_WAIVER_OF_DELAY',
                 'SHORTFALL_CLOSURE_APPROVAL',
                 'CLAIM_SHORTFALL_REOPEN_RECOMMANDATION',
                 'CLAIM_SHORTFALL_NONREOPEN_RECOMMANDATION') THEN
          
            OPEN cr_get_shtfal_email_dtl(v_seq_id);
            FETCH cr_get_shtfal_email_dtl
              INTO rec_get_shtfal_email_dtl;
            CLOSE cr_get_shtfal_email_dtl;
          
            OPEN get_off_srtfall_email(v_seq_id);
            FETCH get_off_srtfall_email
              INTO get_off_srtfall_email_rec;
            CLOSE get_off_srtfall_email;
          
            v_email_id := rec_get_shtfal_email_dtl.insurer_email_id;
            v_params(1) := rec_get_shtfal_email_dtl.claim_number;
            v_params(2) := rec_get_shtfal_email_dtL.EMPLOYEE_USER_ID;
            proc_mail_merge(v_message_type_id,
                            'ON_TITLE',
                            v_msg_title,
                            v_msg_title);
            IF v_message_type_id = 'INITIAL_SHORTFALL_REQUEST' THEN
              v_params(1) := get_off_srtfall_mail_rec.email_id; --koc_off_mail 
            ELSE
              v_params(1) := get_off_srtfall_email_rec.email_id; --koc_off_mail 

            END IF;

            proc_mail_merge(v_message_type_id,
                            'ON_MESSAGE',
                            NULL,
                            v_merged_message);
          
            v_document_name := v_request_type || '-' ||
                               rec_get_shtfal_email_dtl.shortfall_id;
          
          ELSIF v_message_type_id IN ---koc_ins_mail
                ('CIGNA_CLM_DOC_SHFALL_EMAIL_PO',
                 'CIGNA_CLM_DOC_SHFALL_EMAIL_AD',
                 'CIGNA_CLM_SHFALL_REM1_EMAIL_AD',
                 'CIGNA_CLM_SHFALL_REM2_EMAIL_AD',
                 'CIGNA_CLM_SHFALL_REM1_EMAIL_PO',
                 'CIGNA_CLM_SHFALL_REM2_EMAIL_PO') THEN
          
            IF v_message_type_id IN
               ('CIGNA_CLM_DOC_SHFALL_EMAIL_AD',
                'CIGNA_CLM_SHFALL_REM1_EMAIL_AD',
                'CIGNA_CLM_SHFALL_REM2_EMAIL_AD') THEN
            
              OPEN get_cigna_clm_srtfall(v_seq_id);
              FETCH get_cigna_clm_srtfall
                INTO get_cigna_clm_srtfall_rec;
              CLOSE get_cigna_clm_srtfall;
            
              for rec in (select rownum, cname
                            from (SELECT extractValue(value(des),
                                                      '/query/@postlabel') AS cname
                                    FROM (SELECT sh.shortfall_questions
                                            FROM clm_enroll_details  a,
                                                 clm_general_details b,
                                                 shortfall_details   sh
                                           WHERE b.claim_seq_id =
                                                 a.claim_seq_id
                                             and b.claim_seq_id =
                                                 sh.claim_seq_id(+)
                                             and sh.shortfall_seq_id =
                                                 v_seq_id) p,
                                         TABLE(XMLSequence(extract(p.shortfall_questions,
                                                                   '/shortfall/section/subsection/query[@value="YES"]'))) des
                                  union all
                                  SELECT extractValue(value(des),
                                                      '/query/@value') AS cname
                                    FROM (SELECT sh.shortfall_questions
                                            FROM clm_enroll_details  a,
                                                 clm_general_details b,
                                                 shortfall_details   sh
                                           WHERE b.claim_seq_id =
                                                 a.claim_seq_id
                                             and b.claim_seq_id =
                                                 sh.claim_seq_id(+)
                                             and sh.shortfall_seq_id =
                                                 v_seq_id) p,
                                         TABLE(XMLSequence(extract(p.shortfall_questions,
                                                                   '/shortfall/section/subsection/query[@type="text"]'))) des)
                           where cname is not null) loop
                v_shrtfall_que := v_shrtfall_que || '<li>' || rec.cname ||
                                  '</li>
       ';
              end loop;

            
              v_shrtfall_que := '<ol>' || v_shrtfall_que || '</ol>';
            
              v_params(1) := get_cigna_clm_srtfall_rec.policy_number;
              v_params(2) := get_cigna_clm_srtfall_rec.pol_holder_name;
              v_params(3) := get_cigna_clm_srtfall_rec.product_name;
              v_params(4) := get_cigna_clm_srtfall_rec.claim_number;
              v_params(5) := nvl(get_cigna_clm_srtfall_rec.clm_intimation_num,
                                 '--');
              v_params(6) := to_char(sysdate, 'DD/MM/YYYY');
              v_params(7) := get_cigna_clm_srtfall_rec.agent_name;
              v_params(8) := get_cigna_clm_srtfall_rec.pol_holder_name;
            
              if v_message_type_id in
                 ('CIGNA_CLM_SHFALL_REM1_EMAIL_AD',
                  'CIGNA_CLM_SHFALL_REM2_EMAIL_AD') then
                if v_message_type_id = 'CIGNA_CLM_SHFALL_REM2_EMAIL_AD' then
                  v_params(9) := to_char(get_cigna_clm_srtfall_rec.intl_shortfal_snt_date,
                                         'DD/MM/YYYY');
                  v_params(10) := to_char(get_cigna_clm_srtfall_rec.rmdr_req_snt_date,
                                          'DD/MM/YYYY');
                  v_params(11) := get_cigna_clm_srtfall_rec.claim_number;
                  v_params(12) := get_cigna_clm_srtfall_rec.claimant_name;
                  v_params(13) := get_cigna_clm_srtfall_rec.hosp_name;
                  v_params(14) := get_cigna_clm_srtfall_rec.hos_address;
                  v_params(15) := v_shrtfall_que;
                else
                  v_params(9) := to_char(get_cigna_clm_srtfall_rec.intl_shortfal_snt_date,
                                         'DD/MM/YYYY');
                  v_params(10) := get_cigna_clm_srtfall_rec.claim_number;
                  v_params(11) := get_cigna_clm_srtfall_rec.claimant_name;
                  v_params(12) := get_cigna_clm_srtfall_rec.hosp_name;
                  v_params(13) := get_cigna_clm_srtfall_rec.hos_address;
                  v_params(14) := v_shrtfall_que;

                end if;

              else
                --CIGNA_CLM_DOC_SHFALL_EMAIL_AD
                v_params(9) := to_char(get_cigna_clm_srtfall_rec.rcvd_date,
                                       'DD/MM/YYYY');
                v_params(10) := get_cigna_clm_srtfall_rec.claim_number;
                v_params(11) := get_cigna_clm_srtfall_rec.claim_number;
                v_params(12) := get_cigna_clm_srtfall_rec.claimant_name;
                v_params(13) := get_cigna_clm_srtfall_rec.hosp_name;
                v_params(14) := get_cigna_clm_srtfall_rec.hos_address;

              end if;

              v_sms_phone := get_cigna_clm_srtfall_rec.agent_phone;
              v_email_id  := get_cigna_clm_srtfall_rec.agent_mail;
              -- For SMS Generation
              v_SMS_params(1) := get_cigna_clm_srtfall_rec.claim_number;
            
            ELSIF v_message_type_id IN
                  ('CIGNA_CLM_DOC_SHFALL_EMAIL_PO',
                   'CIGNA_CLM_SHFALL_REM1_EMAIL_PO',
                   'CIGNA_CLM_SHFALL_REM2_EMAIL_PO') THEN
            
              OPEN get_cigna_clm_srtfall(v_seq_id);
              FETCH get_cigna_clm_srtfall
                INTO get_cigna_clm_srtfall_rec;
              CLOSE get_cigna_clm_srtfall;
            
              for rec in (select rownum, cname
                            from (SELECT extractValue(value(des),
                                                      '/query/@postlabel') AS cname
                                    FROM (SELECT sh.shortfall_questions
                                            FROM clm_enroll_details  a,
                                                 clm_general_details b,
                                                 shortfall_details   sh
                                           WHERE b.claim_seq_id =
                                                 a.claim_seq_id
                                             and b.claim_seq_id =
                                                 sh.claim_seq_id(+)
                                             and sh.shortfall_seq_id =
                                                 v_seq_id) p,
                                         TABLE(XMLSequence(extract(p.shortfall_questions,
                                                                   '/shortfall/section/subsection/query[@value="YES"]'))) des
                                  union all
                                  SELECT extractValue(value(des),
                                                      '/query/@value') AS cname
                                    FROM (SELECT sh.shortfall_questions
                                            FROM clm_enroll_details  a,
                                                 clm_general_details b,
                                                 shortfall_details   sh
                                           WHERE b.claim_seq_id =
                                                 a.claim_seq_id
                                             and b.claim_seq_id =
                                                 sh.claim_seq_id(+)
                                             and sh.shortfall_seq_id =
                                                 v_seq_id) p,
                                         TABLE(XMLSequence(extract(p.shortfall_questions,
                                                                   '/shortfall/section/subsection/query[@type="text"]'))) des)
                           where cname is not null) loop
                v_shrtfall_que := v_shrtfall_que || '<li>' || rec.cname ||
                                  '</li>
        ';
              end loop;

            
              v_shrtfall_que := '<ol>' || v_shrtfall_que || '</ol>';
            
              v_params(1) := get_cigna_clm_srtfall_rec.policy_number;
              v_params(2) := get_cigna_clm_srtfall_rec.product_name;
              v_params(3) := get_cigna_clm_srtfall_rec.claim_number;
              v_params(4) := nvl(get_cigna_clm_srtfall_rec.clm_intimation_num,
                                 '--');
              v_params(5) := to_char(sysdate, 'DD/MM/YYYY');
              v_params(6) := get_cigna_clm_srtfall_rec.pol_holder_name;
            
              if v_message_type_id in
                 ('CIGNA_CLM_SHFALL_REM1_EMAIL_PO',
                  'CIGNA_CLM_SHFALL_REM2_EMAIL_PO') then
                if v_message_type_id = 'CIGNA_CLM_SHFALL_REM2_EMAIL_PO' then
                  v_params(7) := to_char(get_cigna_clm_srtfall_rec.intl_shortfal_snt_date,
                                         'DD/MM/YYYY');
                  v_params(8) := to_char(get_cigna_clm_srtfall_rec.rmdr_req_snt_date,
                                         'DD/MM/YYYY');
                  v_params(9) := get_cigna_clm_srtfall_rec.claim_number;
                  v_params(10) := get_cigna_clm_srtfall_rec.claim_number;
                  v_params(11) := get_cigna_clm_srtfall_rec.claimant_name;
                  v_params(12) := get_cigna_clm_srtfall_rec.hosp_name;
                  v_params(13) := get_cigna_clm_srtfall_rec.hos_address;
                  v_params(14) := get_cigna_clm_srtfall_rec.ailment_description;
                  v_params(15) := v_shrtfall_que;
                else
                  v_params(7) := to_char(get_cigna_clm_srtfall_rec.intl_shortfal_snt_date,
                                         'DD/MM/YYYY');
                  v_params(8) := get_cigna_clm_srtfall_rec.claim_number;
                  v_params(9) := to_char(get_cigna_clm_srtfall_rec.rcvd_date,
                                         'DD/MM/YYYY');
                  v_params(10) := get_cigna_clm_srtfall_rec.claim_number;
                  v_params(11) := get_cigna_clm_srtfall_rec.claimant_name;
                  v_params(12) := get_cigna_clm_srtfall_rec.hosp_name;
                  v_params(13) := get_cigna_clm_srtfall_rec.hos_address;
                  v_params(14) := get_cigna_clm_srtfall_rec.ailment_description;
                  v_params(15) := v_shrtfall_que;

                end if;

              else
                --CIGNA_CLM_DOC_SHFALL_EMAIL_PO
                v_params(7) := get_cigna_clm_srtfall_rec.claim_number;
                v_params(8) := to_char(get_cigna_clm_srtfall_rec.rcvd_date,
                                       'DD/MM/YYYY');
                v_params(9) := get_cigna_clm_srtfall_rec.claim_number;
                v_params(10) := get_cigna_clm_srtfall_rec.claimant_name;
                v_params(11) := get_cigna_clm_srtfall_rec.hosp_name;
                v_params(12) := get_cigna_clm_srtfall_rec.hos_address;
                v_params(13) := get_cigna_clm_srtfall_rec.ailment_description;
                v_params(14) := v_shrtfall_que;

              end if;

            
              v_sms_phone := get_cigna_clm_srtfall_rec.claimant_phone;
              v_email_id  := get_cigna_clm_srtfall_rec.pol_hold_email_id;
            
              -- For SMS Generation
              v_SMS_params(1) := get_cigna_clm_srtfall_rec.claim_number;
            
            END IF;

            ---pat_rmndrs

          ELSIF v_message_type_id IN ---koc_ins_mail
                ('CIGNA_PAT_SHFALL_FRST_EMAIL_PO',
                 'CIGNA_PAT_SHFALL_FRST_EMAIL_AD',
                 'CIGNA_PAT_SHFALL_REM1_EMAIL_PO',
                 'CIGNA_PAT_SHFALL_REM1_EMAIL_AD',
                 'CIGNA_PAT_SHFALL_FNL_EMAIL_PO',
                 'CIGNA_PAT_SHFALL_FNL_EMAIL_AD') THEN
          
            IF v_message_type_id IN
               ('CIGNA_PAT_SHFALL_FRST_EMAIL_AD',
                'CIGNA_PAT_SHFALL_REM1_EMAIL_AD',
                'CIGNA_PAT_SHFALL_FNL_EMAIL_AD') THEN
            
              OPEN get_cigna_pat_srtfall(v_seq_id);
              FETCH get_cigna_pat_srtfall
                INTO get_cigna_pat_srtfall_rec;
              CLOSE get_cigna_pat_srtfall;
            
              /*for rec in ( select rownum,cname from (
                  SELECT extractValue(value(des),'/query/@postlabel') AS cname
                  FROM (SELECT sh.shortfall_questions   FROM pat_enroll_details a,pat_general_details b,shortfall_details sh
                  WHERE  b.pat_enroll_detail_seq_id = a.pat_enroll_detail_seq_id  and b.pat_gen_detail_seq_id = sh.pat_gen_detail_seq_id(+)
                  and sh.shortfall_seq_id =  v_seq_id  )  p, TABLE(XMLSequence(
                  extract(p.shortfall_questions,'/shortfall/section/subsection/query[@value="YES"]'))) des
                 union all
                 SELECT extractValue(value(des),'/query/@value') AS cname
                           FROM (SELECT sh.shortfall_questions   FROM pat_enroll_details a,pat_general_details b,shortfall_details sh
                  WHERE  b.pat_enroll_detail_seq_id = a.pat_enroll_detail_seq_id  and b.pat_gen_detail_seq_id = sh.pat_gen_detail_seq_id(+)
                  and sh.shortfall_seq_id =  v_seq_id  )  p, TABLE(XMLSequence(
                  extract(p.shortfall_questions,'/shortfall/section/subsection/query[@type="text"]'))) des))
               loop
               v_shrtfall_que:= v_shrtfall_que||'<li>'||rec.cname||'</li>
               ';
              end loop;
              
                    v_shrtfall_que:='<ol>'||v_shrtfall_que||'</ol>';*/

            
              v_params(1) := get_cigna_pat_srtfall_rec.policy_number;
              v_params(2) := get_cigna_pat_srtfall_rec.pol_holder_name;
              v_params(3) := get_cigna_pat_srtfall_rec.product_name;
              v_params(4) := get_cigna_pat_srtfall_rec.pre_auth_number;
              v_params(5) := to_char(sysdate, 'DD/MM/YYYY');
              v_params(6) := get_cigna_pat_srtfall_rec.agent_name;
              v_params(7) := get_cigna_pat_srtfall_rec.pol_holder_name;
            
              if v_message_type_id in
                 ('CIGNA_PAT_SHFALL_REM1_EMAIL_AD',
                  'CIGNA_PAT_SHFALL_FNL_EMAIL_AD') then
              
                v_params(8) := get_cigna_pat_srtfall_rec.pre_auth_number;
                v_params(9) := get_cigna_pat_srtfall_rec.claimant_name;
                v_params(10) := get_cigna_pat_srtfall_rec.hosp_name;
                v_params(11) := get_cigna_pat_srtfall_rec.hos_address;
              
              else
                --CIGNA_CLM_DOC_SHFALL_EMAIL_AD
                v_params(8) := to_char(get_cigna_pat_srtfall_rec.pat_received_date,
                                       'DD/MM/YYYY');
                v_params(9) := get_cigna_pat_srtfall_rec.pre_auth_number;
                v_params(10) := get_cigna_pat_srtfall_rec.pre_auth_number;
                v_params(11) := get_cigna_pat_srtfall_rec.claimant_name;
                v_params(12) := get_cigna_pat_srtfall_rec.hosp_name;
                v_params(13) := get_cigna_pat_srtfall_rec.hos_address;
              
              end if;

              v_sms_phone := get_cigna_pat_srtfall_rec.agent_phone;
              v_email_id  := get_cigna_pat_srtfall_rec.agent_mail;
              -- For SMS Generation
              v_SMS_params(1) := get_cigna_pat_srtfall_rec.pre_auth_number;
            
            ELSIF v_message_type_id IN
                  ('CIGNA_PAT_SHFALL_FRST_EMAIL_PO',
                   'CIGNA_PAT_SHFALL_REM1_EMAIL_PO',
                   'CIGNA_PAT_SHFALL_FNL_EMAIL_PO') THEN
            
              OPEN get_cigna_pat_srtfall(v_seq_id);
              FETCH get_cigna_pat_srtfall
                INTO get_cigna_pat_srtfall_rec;
              CLOSE get_cigna_pat_srtfall;
            
              for rec in (select rownum, cname
                            from (SELECT extractValue(value(des),
                                                      '/query/@postlabel') AS cname
                                    FROM (SELECT sh.shortfall_questions
                                            FROM pat_enroll_details  a,
                                                 pat_general_details b,
                                                 shortfall_details   sh
                                           WHERE b.pat_enroll_detail_seq_id =
                                                 a.pat_enroll_detail_seq_id
                                             and b.pat_gen_detail_seq_id =
                                                 sh.pat_gen_detail_seq_id(+)
                                             and sh.shortfall_seq_id =
                                                 v_seq_id) p,
                                         TABLE(XMLSequence(extract(p.shortfall_questions,
                                                                   '/shortfall/section/subsection/query[@value="YES"]'))) des
                                  union all
                                  SELECT extractValue(value(des),
                                                      '/query/@value') AS cname
                                    FROM (SELECT sh.shortfall_questions
                                            FROM pat_enroll_details  a,
                                                 pat_general_details b,
                                                 shortfall_details   sh
                                           WHERE b.pat_enroll_detail_seq_id =
                                                 a.pat_enroll_detail_seq_id
                                             and b.pat_gen_detail_seq_id =
                                                 sh.pat_gen_detail_seq_id(+)
                                             and sh.shortfall_seq_id =
                                                 v_seq_id) p,
                                         TABLE(XMLSequence(extract(p.shortfall_questions,
                                                                   '/shortfall/section/subsection/query[@type="text"]'))) des)
                           where cname is not null) loop
                v_shrtfall_que := v_shrtfall_que || '<li>' || rec.cname ||
                                  '</li>
       ';
              end loop;

            
              v_shrtfall_que := '<ol>' || v_shrtfall_que || '</ol>';
            
              v_params(1) := get_cigna_pat_srtfall_rec.policy_number;
              v_params(2) := get_cigna_pat_srtfall_rec.product_name;
              v_params(3) := get_cigna_pat_srtfall_rec.pre_auth_number;
              v_params(4) := to_char(sysdate, 'DD/MM/YYYY');
              v_params(5) := get_cigna_pat_srtfall_rec.pol_holder_name;
              v_params(6) := get_cigna_pat_srtfall_rec.pre_auth_number;
            
              if v_message_type_id in
                 ('CIGNA_PAT_SHFALL_REM1_EMAIL_PO',
                  'CIGNA_PAT_SHFALL_FNL_EMAIL_PO') then
              
                v_params(7) := to_char(get_cigna_pat_srtfall_rec.pat_received_date,
                                       'DD/MM/YYYY');
                v_params(8) := get_cigna_pat_srtfall_rec.pre_auth_number;
                v_params(9) := get_cigna_pat_srtfall_rec.claimant_name;
                v_params(10) := get_cigna_pat_srtfall_rec.hosp_name;
                v_params(11) := get_cigna_pat_srtfall_rec.hos_address;
                v_params(12) := get_cigna_pat_srtfall_rec.ailment_description;
                v_params(13) := v_shrtfall_que;
              else
                --CIGNA_CLM_DOC_SHFALL_EMAIL_PO
                v_params(7) := to_char(get_cigna_pat_srtfall_rec.pat_received_date,
                                       'DD/MM/YYYY');
                v_params(8) := get_cigna_pat_srtfall_rec.pre_auth_number;
                v_params(9) := get_cigna_pat_srtfall_rec.claimant_name;
                v_params(10) := get_cigna_pat_srtfall_rec.hosp_name;
                v_params(11) := get_cigna_pat_srtfall_rec.hos_address;
                v_params(12) := get_cigna_pat_srtfall_rec.ailment_description;
                v_params(13) := v_shrtfall_que;

              end if;

            
              v_sms_phone := get_cigna_pat_srtfall_rec.claimant_phone;
              v_email_id  := get_cigna_pat_srtfall_rec.pol_hold_email_id;
            
              -- For SMS Generation
              v_SMS_params(1) := get_cigna_pat_srtfall_rec.pre_auth_number;

            END IF;

          END IF;

        
          v_enrollment_number := rec_get_shtfal_email_dtl.SHORTFALL_ID;
        
        END IF;

      
        proc_mail_merge(v_message_type_id,
                        'ON_TITLE',
                        v_msg_title,
                        v_msg_title);
      
        -- This procedure will merge the Raw Message and Data with regards to Message only related to Email
        IF (v_send_as_email_yn = 'Y') THEN
          proc_mail_merge(v_message_type_id,
                          'ON_MESSAGE',
                          NULL,
                          v_merged_message);
        END IF;

      
        -- This procedure will merge the Raw Message and Data with regards to Message only related to SMS
        IF (v_send_as_sms_yn = 'Y') THEN
          proc_mail_merge(v_message_type_id,
                          'ON_SMS_MESSAGE',
                          NULL,
                          v_merged_SMS_message);
        
        END IF;

        IF v_message_type_id LIKE 'CIGNA%' THEN
          ---koc_ins_mail
        
          V_CIGNA_MESAGE := v_merged_message;
        
          INSERT INTO DESTINATION_MESSAGE
            (DEST_MSG_SEQ_ID,
             MSG_ID,
             SOURCE_ID,
             SOURCE_SEQ_ID,
             MSG_SENT_FROM,
             MESSAGE_TITLE,
             MESSAGE,
             SMS_DESCRIPTION,
             ADDED_BY,
             ADDED_DATE,
             ENROLLMENT_NUMBER,
             FILE_PATH_NAME,
             CIGNA_SMS_YN,
             cigna_mesage)
          VALUES
            (DESTINATION_MESSAGE_SEQ.NEXTVAL,
             v_message_type_id,
             v_module_name,
             v_seq_id,
             v_sent_from,
             v_msg_title,
             NULL,
             v_merged_SMS_message,
             v_added_by,
             sysdate,
             v_enrollment_number,
             CASE WHEN v_document_name IS NOT NULL THEN
             v_document_name || '.pdf' ELSE NULL END,
             'Y',
             V_CIGNA_MESAGE)
          RETURNING DEST_MSG_SEQ_ID INTO v_DEST_MSG_SEQ_ID;

        
        ELSE
        
          INSERT INTO DESTINATION_MESSAGE
            (DEST_MSG_SEQ_ID,
             MSG_ID,
             SOURCE_ID,
             SOURCE_SEQ_ID,
             MSG_SENT_FROM,
             MESSAGE_TITLE,
             MESSAGE,
             SMS_DESCRIPTION,
             ADDED_BY,
             ADDED_DATE,
             ENROLLMENT_NUMBER,
             FILE_PATH_NAME)
          VALUES
            (DESTINATION_MESSAGE_SEQ.NEXTVAL,
             v_message_type_id,
             v_module_name,
             v_seq_id,
             v_sent_from,
             v_msg_title,
             v_merged_message,
             v_merged_SMS_message,
             v_added_by,
             sysdate,
             v_enrollment_number,
             CASE WHEN v_document_name IS NOT NULL THEN
             v_document_name || '.pdf' ELSE NULL END)
          RETURNING DEST_MSG_SEQ_ID INTO v_DEST_MSG_SEQ_ID;

        END IF;

      
        -- Insert the RECEIPIENT INFORMATION.
        v_count := 1;
        WHILE (v_count <= 3) LOOP
          v_email_ids      := NULL;
          v_sms            := NULL;
          v_fax            := NULL;
          v_insert_message := 'N';
          v_remarks        := NULL;
          v_msg_type       := NULL;
          v_present_yn     := 'Y';
        
          IF (v_count = 1) AND (v_send_as_email_yn = 'Y') THEN
            -- To handle the Primary or TO Email iD
            IF ((v_email_id IS NOT NULL) AND (v_general_mail IS NOT NULL)) THEN
              v_email_id := v_email_id || ',' || v_general_mail;
            ELSIF ((v_email_id IS NULL) AND (v_general_mail IS NOT NULL)) THEN
              v_email_id := v_general_mail;

            END IF;

          
            -- To handle the CC Email iD
            IF ((v_sec_rcpt_list IS NOT NULL) AND (v_cc_mail IS NOT NULL)) THEN
              v_sec_rcpt_list := v_sec_rcpt_list || ',' || v_cc_mail;
            ELSIF ((v_sec_rcpt_list IS NULL) AND (v_cc_mail IS NOT NULL)) THEN
              v_sec_rcpt_list := v_cc_mail;

            END IF;

          
            IF v_message_type_id = 'SHORTFALL_CLOSURE_NOTICE' AND
               rec_get_shtfal_email_dtL.INSURED_EMAIL_ID IS NOT NULL AND
               rec_get_shtfal_email_dtl.CLAIM_GENERAL_TYPE_ID = 'CNH' THEN
              IF v_sec_rcpt_list IS NOT NULL AND
                 rec_get_shtfal_email_dtL.INSURED_EMAIL_ID IS NOT NULL THEN
                v_sec_rcpt_list := v_sec_rcpt_list || ',' ||
                                   rec_get_shtfal_email_dtL.INSURED_EMAIL_ID;
              ELSIF v_sec_rcpt_list IS NULL AND
                    rec_get_shtfal_email_dtL.INSURED_EMAIL_ID IS NOT NULL THEN
                v_sec_rcpt_list := rec_get_shtfal_email_dtL.INSURED_EMAIL_ID;

              END IF;

            END IF;

          
            v_email_ids := v_email_id;
          
            v_insert_message := 'Y';
            v_msg_type       := 'EMAIL';
          
            IF UPPER(nvl(v_email_ids, 'NULL')) = 'NULL'
              OR (v_email_ids IS NULL) THEN
              v_remarks    := 'Primary Email Id is not present ';
              v_present_yn := 'N';
            END IF;

          
          ELSIF (v_count = 2) AND (v_send_as_sms_yn = 'Y') THEN
            v_sec_rcpt_list  := null;
            v_sms            := v_sms_phone;
            v_insert_message := 'Y';
            v_msg_type       := 'SMS';
          
            IF (v_sms IS NULL) THEN
              -- v_insert_message := 'N';
              v_remarks    := 'Primary SMS number is not present ';
              v_present_yn := 'N';
            ELSE
            
              --v_sms := '91' || v_sms;
              v_sms := v_sms;
            
            END IF;

          ELSIF (v_count = 3) AND (v_send_as_fax_yn = 'Y') THEN
            v_sec_rcpt_list  := null;
            v_fax            := v_fax_number;
            v_insert_message := 'Y';
            v_msg_type       := 'FAX';
          
            IF (v_fax IS NULL) THEN
              --  v_insert_message := 'N';
              v_remarks    := 'Primary Fax number is not present ';
              v_present_yn := 'N';
            END IF;

          
          END IF;

        
          IF (v_insert_message = 'Y') THEN
          
            INSERT INTO DESTINATION_MESSAGE_RCPT
              (DEST_MSG_RCPT_SEQ_ID,
               DEST_MSG_SEQ_ID,
               PRM_RCPT_EMAIL_LIST,
               PRM_RCPT_SMS,
               PRM_RCPT_FAX_NOS,
               SEC_RCPT_EMAIL_LIST,
               REMARKS,
               ADDED_BY,
               ADDED_DATE,
               MSG_TYPE,
               PRESENT_YN,
               MAIL_STATUS,
               MSG_STATUS_GENERAL_TYPE_ID,
               SENT_DATE)
            VALUES
              (DESTINATION_MESSAGE_RCPT_SEQ.NEXTVAL,
               v_DEST_MSG_SEQ_ID,
               v_email_ids,
               v_sms,
               v_fax,
               v_sec_rcpt_list,
               v_remarks,
               v_added_by,
               sysdate,
               v_msg_type,
               v_present_yn,
               'INP',
               'MIQ', -- Message in queue
               NULL);

          END IF;

          v_count := v_count + 1;
        END LOOP;

      END IF;

    END LOOP; ---KOC_INS_MAIL
    v_rows_processed := sql%rowcount;
    commit;
  
  END generate_clm_shortfal_mails;

  /* --=====================================================================================================
      Name       : proc_get_ccemail_dtls
      Created on : 07-01-2013
      Created By : Ibrahim Sayyed
      Company    : RCS Technologies
      Added for  : KOC1179
      Modifeid by: RAM
      Modified date: 16-05-2013
      Comments   :   This procedure used to get CC email details while sending shortfall request
  --=====================================================================================================*/

  PROCEDURE proc_get_ccemail_dtls(v_message_type_id      VARCHAR2, -- The Actual Message id generated by the application
                                  v_parameters           VARCHAR2,
                                  v_mail_category        VARCHAR2, -- The send message id is of what type in Database
                                  v_process_yn           OUT VARCHAR2, -- Can the process be done or not
                                  v_general_mail         OUT VARCHAR2, -- Generic TO Email id created at the group
                                  v_cc_mail              OUT VARCHAR2, -- Generic CC Email id created at the group
                                  v_customise_allowed_YN VARCHAR2) IS
  
    CURSOR cr_get_shortfall_cc_dtls(v_shortfal_seq_id shortfall_details.shortfall_seq_id%TYPE) IS
      SELECT b.enrol_type_id,
             c.notify_email_id /*,D.EMAIL_ID*/,
             c.cc_email_id,
             c.notify_type_id,
             c.group_reg_seq_id
        FROM shortfall_details a
        JOIN clm_enroll_details b
          ON (a.claim_seq_id = b.claim_seq_id)
        JOIN tpa_group_registration c
          ON (b.group_reg_seq_id = c.group_reg_seq_id)
        JOIN TPA_INS_INFO D
          ON (B.INS_SEQ_ID = D.INS_SEQ_ID)
       WHERE a.shortfall_seq_id = v_parameters;

  
    CURSOR cr_get_shortfall_cc_dtls_ins(v_shortfal_seq_id shortfall_details.shortfall_seq_id%TYPE) IS
      SELECT b.ENROL_TYPE_ID, C.EMAIL_ID, C.INS_SEQ_ID
        FROM SHORTFALL_EMAIL_DTL SE
        JOIN shortfall_details a
          ON (SE.SHORTFALL_SEQ_ID = A.SHORTFALL_SEQ_ID)
        JOIN clm_enroll_details b
          ON (a.claim_seq_id = b.claim_seq_id)
        JOIN TPA_INS_INFO c
          ON (B.INS_SEQ_ID = c.INS_SEQ_ID)
       WHERE SE.SHORTFAL_EMAIL_SEQ_ID = v_parameters;

  
    rec_get_shortfall_cc_dtls     cr_get_shortfall_cc_dtls%ROWTYPE;
    rec_get_shortfall_cc_dtls_ins cr_get_shortfall_cc_dtls_ins%ROWTYPE;
    v_group_reg_seq_id            tpa_group_registration.group_reg_seq_id%TYPE;
    v_mail_cat_general_type_id    tpa_group_registration.notify_type_id%TYPE;
    v_enrol_type_id               clm_enroll_details.enrol_type_id%TYPE;
    v_general_mail_id             tpa_group_registration.notify_email_id%TYPE;
    v_cc_mail_id                  tpa_group_registration.cc_email_id%TYPE;
    v_ins_seq_id                  tpa_ins_info.ins_seq_id%type;
    v_count                       NUMBER(5);

  BEGIN
    v_process_yn               := 'Y';
    v_general_mail             := NULL;
    v_mail_cat_general_type_id := v_mail_category;
  
    IF v_message_type_id = 'INITIAL_SHORTFALL_REQUEST' THEN
      OPEN cr_get_shortfall_cc_dtls(v_parameters);
      FETCH cr_get_shortfall_cc_dtls
        INTO v_enrol_type_id,
             v_general_mail_id,
             v_cc_mail_id,
             v_mail_cat_general_type_id,
             v_group_reg_seq_id;
      CLOSE cr_get_shortfall_cc_dtls;
    elsIF v_message_type_id IN
          ('SHORTFALL_CLOSURE_NOTICE',
           'SHORTFALL_REMINDER_REQUEST',
           'CLAIM_SHORTFALL_REGRET',
           'SHORTFALL_CLOSURE_LETTER') THEN
      OPEN cr_get_shortfall_cc_dtls_ins(v_parameters);
      FETCH cr_get_shortfall_cc_dtls_ins
        INTO v_enrol_type_id, v_cc_mail_id, v_ins_seq_id;
      CLOSE cr_get_shortfall_cc_dtls_ins;

    END IF;

    v_cc_mail := v_cc_mail_id;
    IF (v_customise_allowed_YN = 'Y') THEN
    
      IF (v_mail_cat_general_type_id IS NULL) THEN
        v_mail_cat_general_type_id := 'NIG';
      END IF;

    
      IF (v_enrol_type_id = 'COR') THEN
        IF (v_mail_cat_general_type_id = 'NIG') THEN
          v_process_yn := 'Y'; -- Continue processing
        ELSIF (v_mail_cat_general_type_id = 'NIC') THEN
          -- Check in the Custom Source message for this Corporate whether Custom Message is mapped or not
          SELECT COUNT(1)
            INTO v_count
            FROM APP.SOURCE_MESSAGE_CUSTOM_GRP A
           WHERE A.MSG_ID = v_message_type_id
             AND A.GROUP_REG_SEQ_ID = v_group_reg_seq_id;

          IF (v_count > 0) THEN
            v_process_yn := 'Y';
          ELSE
            --need to raise an error
            IF v_message_type_id = 'SHORTFALL_REQUEST' THEN
              --need to raise an error
              raise_application_error(-20455,
                                      'Shortfall not configured mails will not go');
            END IF;

            v_process_yn := 'N';

          END IF;

        END IF;

      
        IF (v_process_yn = 'Y') THEN
          v_general_mail := v_general_mail_id;
          v_cc_mail      := v_cc_mail_id;
        END IF;

      END IF;

    
    END IF;

  END proc_get_ccemail_dtls;

  --=====================================================================================================
  procedure proc_generate_mail(v_msg_id             IN varchar2,
                               v_pat_clm_seq_id     IN clm_general_details.claim_seq_id%type,
                               v_prod_policy_seq_id IN tpa_ins_prod_policy.prod_policy_seq_id%type,
                               v_added_by           IN number) is
  
    CURSOR prod_pol_cur IS
      SELECT DISTINCT a.pat_allowed_yn,
                      a.clm_allowed_yn,
                      a.pat_to_mail_id,
                      a.pat_cc_mail_id,
                      a.clm_to_mail_id,
                      a.clm_cc_mail_id,
                      a.mail_freq_hours,
                      a.mail_freq_mins,
                      a.Mail_Flag
        FROM tpa_ins_prod_policy a
       WHERE (a.pat_allowed_yn = 'Y' or a.clm_allowed_yn = 'Y')
         and a.prod_policy_seq_id = v_prod_policy_seq_id;

  
    cursor rem_days_cur(v_pat_clm_type tpa_prod_pol_pat_clm_esc_cfg.pat_clm_type%type,
                        v_rem_type     tpa_prod_pol_pat_clm_esc_cfg.remainder_type%type) is
      select a.remainder_value
        from app.tpa_prod_pol_pat_clm_esc_cfg a
       where a.prod_policy_seq_id = v_prod_policy_seq_id
         and a.pat_clm_type = v_pat_clm_type
         and a.remainder_type = v_rem_type;

  
    cursor pat_cur is
      SELECT pe.pre_auth_number,
             pii.pat_ins_send_date,
             gc.description,
             pe.pat_enroll_detail_seq_id,
             pe.claimant_name,
             pe.policy_number,
             pg.Pat_Requested_Amount total_app_amount,
             PE.DATE_OF_HOSPITALIZATION
      
        FROM pat_enroll_details pe
        JOIN pat_general_details pg
          ON (pe.pat_enroll_detail_seq_id = pg.pat_enroll_detail_seq_id AND
             pg.pat_enhanced_yn = 'N')
        left outer join pat_ins_intimation_details pii
          on (pe.PAT_ENROLL_DETAIL_SEQ_ID = pii.PAT_AUTH_SEQ_ID)
        JOIN tpa_ins_info tii
          ON (tii.ins_seq_id = pe.ins_seq_id)
        JOIN tpa_general_code gc
          ON (pii.pat_ins_status = gc.general_type_id)
       WHERE pg.pat_gen_detail_seq_id = v_pat_clm_seq_id
         and pii.pat_ins_status IN ('APR', 'REJ', 'REQ')
         AND pg.completed_yn = 'N'
       ORDER BY pe.decision_date ASC;

  
    cursor clm_cur is
      SELECT pg.claim_number,
             cii.clm_ins_send_date,
             gc.description,
             pe.claim_seq_id,
             pe.claimant_name,
             pe.policy_number,
             Requested_Amount total_app_amount,
             PG.DATE_OF_ADMISSION
      
        FROM clm_enroll_details pe
        JOIN clm_general_details pg
          ON (pe.claim_seq_id = pg.claim_seq_id)
        JOIN tpa_ins_info tii
          ON (tii.ins_seq_id = pe.ins_seq_id)
        left outer join clm_ins_intimation_details cii
          on (pe.claim_seq_id = cii.claim_seq_id)
        JOIN tpa_general_code gc
          ON (cii.CLM_INS_STATUS = gc.general_type_id)
       WHERE pg.claim_seq_id = v_pat_clm_seq_id
         and cii.clm_ins_status IN ('APR', 'REJ', 'REQ')
         AND pg.completed_yn = 'N'
       ORDER BY pe.decision_date ASC;

  
    cursor pat_ins_cur is
      SELECT pe.pre_auth_number,
             pii.pat_ins_send_date,
             gc.description,
             pe.pat_enroll_detail_seq_id,
             tii.abbrevation_code,
             pe.ins_seq_id,
             pe.claimant_name,
             pe.policy_number,
             Pat_Requested_Amount total_app_amount,
             pii.ins_rem_snt_date,
             pii.ins_esc_snt_date,
             pe.date_of_hospitalization
      
        FROM pat_enroll_details pe
        JOIN pat_general_details pg
          ON (pe.pat_enroll_detail_seq_id = pg.pat_enroll_detail_seq_id AND
             pg.pat_enhanced_yn = 'N')
        left outer join pat_ins_intimation_details pii
          on (pe.PAT_ENROLL_DETAIL_SEQ_ID = pii.PAT_AUTH_SEQ_ID)
        JOIN tpa_ins_info tii
          ON (tii.ins_seq_id = pe.ins_seq_id)
        JOIN tpa_general_code gc
          ON (gc.general_type_id = pe.pat_status_general_type_id)
       WHERE pg.pat_gen_detail_seq_id = v_pat_clm_seq_id
         and pii.pat_ins_status = 'INP'
         AND pg.completed_yn = 'N'
       ORDER BY pe.decision_date ASC;

  
    cursor clm_ins_cur is
      SELECT pg.claim_number,
             cii.clm_ins_send_date,
             gc.description,
             pe.claim_seq_id,
             tii.abbrevation_code,
             pe.ins_seq_id,
             pe.claimant_name,
             pe.policy_number,
             Requested_Amount total_app_amount,
             cii.ins_rem_snt_date,
             cii.ins_esc_snt_date,
             pg.date_of_admission,
             PE.CLM_STATUS_GENERAL_TYPE_ID,
             tii.ins_comp_code_number
      
        FROM clm_enroll_details pe
        JOIN clm_general_details pg
          ON (pe.claim_seq_id = pg.claim_seq_id)
        JOIN tpa_ins_info tii
          ON (tii.ins_seq_id = pe.ins_seq_id)
        JOIN tpa_general_code gc
          ON (gc.general_type_id = pe.clm_status_general_type_id)
        left outer join clm_ins_intimation_details cii
          on (pe.claim_seq_id = cii.claim_seq_id)
       WHERE pg.claim_seq_id = v_pat_clm_seq_id
         and cii.clm_ins_status = 'INP'
         AND pg.completed_yn = 'N'
       ORDER BY pe.decision_date ASC;

  
    cursor pat_ins_xfdf_cur is
      SELECT pe.pre_auth_number,
             pii.pat_ins_send_date,
             gc.description,
             pe.pat_enroll_detail_seq_id,
             tii.abbrevation_code,
             pe.ins_seq_id,
             pe.claimant_name,
             pe.policy_number,
             Pat_Requested_Amount total_app_amount,
             PE.DATE_OF_HOSPITALIZATION
      
        FROM pat_enroll_details pe
        JOIN pat_general_details pg
          ON (pe.pat_enroll_detail_seq_id = pg.pat_enroll_detail_seq_id AND
             pg.pat_enhanced_yn = 'N')
        left outer join pat_ins_intimation_details pii
          on (pe.PAT_ENROLL_DETAIL_SEQ_ID = pii.PAT_AUTH_SEQ_ID)
        JOIN tpa_ins_info tii
          ON (tii.ins_seq_id = pe.ins_seq_id)
        JOIN tpa_general_code gc
          ON (gc.general_type_id = pe.pat_status_general_type_id)
       WHERE pg.pat_gen_detail_seq_id = v_pat_clm_seq_id
         and pii.pat_ins_status = 'INP'
         AND pg.completed_yn = 'N'
       ORDER BY pe.decision_date ASC;

  
    cursor clm_ins_xfdf_cur is
      SELECT pg.claim_number,
             cii.clm_ins_send_date,
             gc.description,
             pe.claim_seq_id,
             tii.abbrevation_code,
             pe.ins_seq_id,
             pe.claimant_name,
             pe.policy_number,
             Requested_Amount total_app_amount,
             PG.DATE_OF_ADMISSION
      
        FROM clm_enroll_details pe
        JOIN clm_general_details pg
          ON (pe.claim_seq_id = pg.claim_seq_id)
        JOIN tpa_ins_info tii
          ON (tii.ins_seq_id = pe.ins_seq_id)
        JOIN tpa_general_code gc
          ON (gc.general_type_id = pe.clm_status_general_type_id)
        left outer join clm_ins_intimation_details cii
          on (pe.claim_seq_id = cii.claim_seq_id)
       WHERE pg.claim_seq_id = v_pat_clm_seq_id
         and cii.clm_ins_status = 'INP'
         AND pg.completed_yn = 'N'
       ORDER BY pe.decision_date ASC;

  
    CURSOR raw_cur IS
      SELECT * from APP.SOURCE_MESSAGE aa where aa.msg_id = v_msg_id;

  
    raw_rec      raw_cur%rowtype;
    prod_pol_rec prod_pol_cur%rowtype;
  
    v_pre_auth_number   pat_enroll_details.pre_auth_number%type;
    v_claim_number      clm_general_details.claim_number%type;
    v_status            tpa_general_code.description%type;
    v_clm_seq_id        clm_general_details.claim_seq_id%type;
    v_pat_seq_id        pat_general_details.pat_gen_detail_seq_id%type;
    v_abbrevation_code  tpa_ins_info.abbrevation_code%type;
    v_date_of_admission clm_general_details.date_of_admission%type;
    v_title             VARCHAR2(250);
    v_body              varchar2(2000);
    v_to_mail_ids       destination_mail_rcpt.to_mail_ids%type;
    v_cc_mail_ids       destination_mail_rcpt.cc_mail_ids%type;
    v_remarks           destination_mail_rcpt.remarks%type;
    v_flag              char(1); --destination_mail_rcpt.mail_id_exist_yn%type;
    v_send_date         date;
    v_delimitor         char(1) default null;
    v_file_name         varchar2(100);
    v_DEST_MSG_SEQ_ID   DESTINATION_MESSAGE.DEST_MSG_SEQ_ID%TYPE;
    v_generate_yn       char(1);
    v_ins_seq_id        tpa_ins_info.ins_seq_id%type;
    v_claimant_name     pat_enroll_details.claimant_name%type;
    v_policy_number     pat_enroll_details.policy_number%type;
    v_apr_amt           pat_general_details.total_app_amount%type;
  
    cursor ins_prm_email_id_cur(v_ins_seq_id tpa_ins_info.ins_seq_id%type) is
      SELECT WM_CONCAT(primary_email_id) primary_email_id
        FROM (SELECT unique uc.primary_email_id primary_email_id
                FROM tpa_ins_info gt
                JOIN tpa_user_contacts uc
                  ON (uc.ins_seq_id = gt.ins_seq_id)
                JOIN tpa_login_info li
                  ON (uc.contact_seq_id = li.contact_seq_id)
                JOIN tpa_user_roles ur
                  ON (ur.contact_seq_id = li.contact_seq_id)
                JOIN tpa_roles_code ro
                  ON (ur.role_seq_id = ro.role_seq_id)
               WHERE gt.abbrevation_code = v_abbrevation_code
                 and uc.active_yn = 'Y'
                 AND LI.ACTIVE_YN = 'Y'
                 AND UC.PRIMARY_EMAIL_ID IS NOT NULL
                 AND ro.role_name IN ('INSCLAIMSAPPROVER', 'INSCLAIMSVIEW')
                 and gt.ins_seq_id = v_ins_seq_id); --  MAILS SHOULD GO TO ONLY CORRESPONDING INSURANCE REGION  AND BELOW LEVELS ( IF LEVEL IS RO THEN IT SHOULD GO TO RO & DO LEVEL)
    -- connect by prior gt.ins_parent_seq_id=gt.ins_seq_id ;
  
    cursor ins_sec_email_id_cur(v_ins_seq_id tpa_ins_info.ins_seq_id%type) is
      SELECT WM_CONCAT(secondary_email_id) AS secondary_email_id
        FROM (SELECT UNIQUE uc.secondary_email_id
                FROM tpa_ins_info gt
                JOIN tpa_user_contacts uc
                  ON (uc.ins_seq_id = gt.ins_seq_id)
                JOIN tpa_login_info li
                  ON (uc.contact_seq_id = li.contact_seq_id)
                JOIN tpa_user_roles ur
                  ON (ur.contact_seq_id = li.contact_seq_id)
                JOIN tpa_roles_code ro
                  ON (ur.role_seq_id = ro.role_seq_id)
               WHERE gt.abbrevation_code = v_abbrevation_code
                 and uc.active_yn = 'Y'
                 AND LI.ACTIVE_YN = 'Y'
                 AND UC.SECONDARY_EMAIL_ID IS NOT NULL
                 AND ro.role_name IN ('INSCLAIMSAPPROVER', 'INSCLAIMSVIEW')
                 and gt.ins_seq_id = v_ins_seq_id); --  MAILS SHOULD GO TO ONLY CORRESPONDING INSURANCE REGION  AND BELOW LEVELS ( IF LEVEL IS RO THEN IT SHOULD GO TO RO & DO LEVEL)
    --  connect by prior gt.ins_parent_seq_id=gt.ins_seq_id ;
  
    v_pat_cc_mail_ids destination_mail_rcpt.to_mail_ids%type;
    v_clm_cc_mail_ids destination_mail_rcpt.to_mail_ids%type;
  
    cursor ins_escalation_prm_mailid_cur(v_ins_seq_id tpa_ins_info.ins_seq_id%type,
                                         v_comp_code  tpa_ins_info.ins_comp_code_number%type) is
      SELECT WM_CONCAT(primary_email_id) primary_email_id
        FROM (SELECT UNIQUE uc.primary_email_id
                FROM tpa_ins_info gt
                JOIN tpa_user_contacts uc
                  ON (uc.ins_seq_id = gt.ins_seq_id AND
                     gt.ins_office_general_type_id in ('IRO', 'IDO', 'IBO'))
                JOIN tpa_login_info li
                  ON (uc.contact_seq_id = li.contact_seq_id)
                JOIN tpa_user_roles ur
                  ON (ur.contact_seq_id = li.contact_seq_id)
                JOIN tpa_roles_code ro
                  ON (ur.role_seq_id = ro.role_seq_id)
               WHERE gt.abbrevation_code = v_abbrevation_code
                 and uc.active_yn = 'Y'
                 AND LI.ACTIVE_YN = 'Y'
                 AND UC.PRIMARY_EMAIL_ID IS NOT NULL
                 and gt.ins_comp_code_number != v_comp_code
                 AND ro.role_name IN ('INSCLAIMSAPPROVER', 'INSCLAIMSVIEW')
               start with gt.ins_seq_id = v_ins_seq_id --  MAILS SHOULD GO TO ONLY CORRESPONDING INSURANCE REGION  AND BELOW LEVELS ( IF LEVEL IS RO THEN IT SHOULD GO TO RO & DO LEVEL)
              connect by prior gt.ins_parent_seq_id = gt.ins_seq_id);

  
    CURSOR ins_apr_mail_cur is
      SELECT uc.primary_email_id
        FROM tpa_user_contacts uc
       where uc.contact_seq_id = v_added_by;

  
    v_days number(10);
  
    pat_rec          pat_cur%rowtype;
    clm_rec          clm_cur%rowtype;
    pat_ins_rec      pat_ins_cur%rowtype;
    clm_ins_rec      clm_ins_cur%rowtype;
    pat_ins_xfdf_rec pat_ins_xfdf_cur%rowtype;
    clm_ins_xfdf_rec clm_ins_xfdf_cur%rowtype;
    rem_days_rec     rem_days_cur%rowtype;
  
  begin
  
    open raw_cur;
    fetch raw_cur
      into raw_rec;
    close raw_cur;
  
    open prod_pol_cur;
    fetch prod_pol_cur
      into prod_pol_rec;
    close prod_pol_cur;
  
    IF v_msg_id IN ('PAT_INS_XFDF_PICKUP',
                    'TTK_SPOC_PAT_RESP',
                    'PAT_INS_INTIMATION',
                    'PAT_INS_INTIMATION_REMINDER',
                    'PAT_INS_INTIMATION_ESCALATION') then
    
      if v_msg_id = 'PAT_INS_INTIMATION' then
      
        open pat_ins_cur;
        fetch pat_ins_cur
          into pat_ins_rec;
        close pat_ins_cur;
      
        v_pre_auth_number   := pat_ins_rec.pre_auth_number;
        v_date_of_admission := pat_ins_rec.date_of_hospitalization;
        v_status            := pat_ins_rec.description;
        v_pat_seq_id        := pat_ins_rec.pat_enroll_detail_seq_id;
        v_abbrevation_code  := pat_ins_rec.abbrevation_code;
        v_ins_seq_id        := pat_ins_rec.ins_seq_id;
        v_claimant_name     := pat_ins_rec.claimant_name;
        v_policy_number     := pat_ins_rec.policy_number;
        v_apr_amt           := pat_ins_rec.total_app_amount;
      
        v_params(1) := v_pre_auth_number;
        v_params(2) := v_policy_number;
        v_params(3) := v_claimant_name;
        v_params(4) := to_char(v_date_of_admission, 'DD-MON-YYYY');
        v_params(5) := trim(to_char(v_apr_amt, '99G99G99G999D99'));
        v_params(6) := v_status;
      
        v_pat_cc_mail_ids := prod_pol_rec.pat_to_mail_id || case
                               when prod_pol_rec.pat_cc_mail_id is not null then
                                ',' || prod_pol_rec.pat_cc_mail_id
                               else
                                null
                             end;
      
        OPEN ins_prm_email_id_cur(v_ins_seq_id);
        FETCH ins_prm_email_id_cur
          INTO v_to_mail_ids;
        CLOSE ins_prm_email_id_cur;
      
        OPEN ins_sec_email_id_cur(v_ins_seq_id);
        FETCH ins_sec_email_id_cur
          INTO v_cc_mail_ids;
        CLOSE ins_sec_email_id_cur;
      
        v_cc_mail_ids := v_cc_mail_ids || case
                           when v_pat_cc_mail_ids is not null then
                            ',' || v_pat_cc_mail_ids
                           else
                            null
                         end;
      
        v_send_date := case
                         when prod_pol_rec.mail_freq_hours is not null and
                              prod_pol_rec.mail_freq_mins is not null THEN
                          sysdate + (prod_pol_rec.mail_freq_hours / 24) +
                          ((prod_pol_rec.mail_freq_mins / 24) / 60)
                         when prod_pol_rec.mail_freq_hours is null and
                              prod_pol_rec.mail_freq_mins is not null THEN
                          sysdate + ((prod_pol_rec.mail_freq_mins / 24) / 60)
                         when prod_pol_rec.mail_freq_hours is not null and
                              prod_pol_rec.mail_freq_mins is null THEN
                          sysdate + (prod_pol_rec.mail_freq_mins / 24)
                         ELSE
                          SYSDATE + ((30 / 24) / 60)
                       END;
        v_remarks := case
                       when v_to_mail_ids is null then
                        'To mail id not exist'
                       else
                        null
                     end;
        v_flag := case
                    when v_to_mail_ids is null then
                     'N'
                    else
                     'Y'
                  end;
      
      elsif v_msg_id = 'TTK_SPOC_PAT_RESP' and
            prod_pol_rec.pat_allowed_yn = 'Y' then
      
        open pat_cur;
        fetch pat_cur
          into pat_rec;
        close pat_cur;
      
        IF v_added_by != 1 THEN
        
          OPEN ins_apr_mail_cur;
          FETCH ins_apr_mail_cur
            into v_cc_mail_ids;
          CLOSE ins_apr_mail_cur;
        
        END IF;

      
        v_pre_auth_number   := pat_rec.pre_auth_number;
        v_date_of_admission := pat_rec.date_of_hospitalization;
        v_status            := pat_rec.description;
        v_pat_seq_id        := pat_rec.pat_enroll_detail_seq_id;
        v_claimant_name     := pat_rec.claimant_name;
        v_policy_number     := pat_rec.policy_number;
        v_apr_amt           := pat_rec.total_app_amount;
      
        v_to_mail_ids := prod_pol_rec.pat_to_mail_id;
        v_cc_mail_ids := v_cc_mail_ids || ',' ||
                         prod_pol_rec.pat_cc_mail_id;
        v_send_date := case
                         when prod_pol_rec.mail_freq_hours is not null and
                              prod_pol_rec.mail_freq_mins is not null THEN
                          sysdate + (prod_pol_rec.mail_freq_hours / 24) +
                          ((prod_pol_rec.mail_freq_mins / 24) / 60)
                         when prod_pol_rec.mail_freq_hours is null and
                              prod_pol_rec.mail_freq_mins is not null THEN
                          sysdate + ((prod_pol_rec.mail_freq_mins / 24) / 60)
                         when prod_pol_rec.mail_freq_hours is not null and
                              prod_pol_rec.mail_freq_mins is null THEN
                          sysdate + (prod_pol_rec.mail_freq_mins / 24)
                         ELSE
                          SYSDATE + ((30 / 24) / 60)
                       END;
        v_remarks := case
                       when prod_pol_rec.pat_to_mail_id is not null then
                        null
                       else
                        'To mail id not exist.'
                     end;
        v_flag := case
                    when prod_pol_rec.pat_to_mail_id is not null then
                     'Y'
                    ELSE
                     'N'
                  END;
      
        v_params(1) := v_pre_auth_number;
        v_params(2) := v_policy_number;
        v_params(3) := v_claimant_name;
        v_params(4) := to_char(v_date_of_admission, 'DD-MON-YYYY');
        v_params(5) := trim(to_char(v_apr_amt, '99G99G99G999D99'));
        v_params(6) := v_status;
      
      /*elsif v_msg_id = 'PAT_INS_XFDF_PICKUP' then
      
        open pat_ins_xfdf_cur;
        fetch pat_ins_xfdf_cur
          into pat_ins_xfdf_rec;
        close pat_ins_xfdf_cur;
      
        v_pre_auth_number   := pat_ins_xfdf_rec.pre_auth_number;
        v_date_of_admission := pat_ins_xfdf_rec.Date_Of_Hospitalization;
        v_status            := pat_ins_xfdf_rec.description;
        v_pat_seq_id        := pat_ins_xfdf_rec.pat_enroll_detail_seq_id;
        v_abbrevation_code  := pat_ins_xfdf_rec.abbrevation_code;
        v_ins_seq_id        := pat_ins_xfdf_rec.ins_seq_id;
        v_claimant_name     := pat_ins_xfdf_rec.claimant_name;
        v_policy_number     := pat_ins_xfdf_rec.policy_number;
        v_apr_amt           := pat_ins_xfdf_rec.total_app_amount;
      
        claims_approval_pkg.preauth_xfdf_report(v_pat_clm_seq_id,
                                                v_file_name,
                                                v_generate_yn);
      
        v_params(1) := v_pre_auth_number;
        v_params(2) := v_policy_number;
        v_params(3) := v_claimant_name;
        v_params(4) := to_char(v_date_of_admission, 'DD-MON-YYYY');
        v_params(5) := trim(to_char(v_apr_amt, '99G99G99G999D99'));
        v_params(6) := v_status;
      
        v_pat_cc_mail_ids := prod_pol_rec.pat_to_mail_id || case
                               when prod_pol_rec.pat_cc_mail_id is not null then
                                ',' || prod_pol_rec.pat_cc_mail_id
                               else
                                null
                             end;
      
        OPEN ins_prm_email_id_cur(v_ins_seq_id);
        FETCH ins_prm_email_id_cur
          INTO v_to_mail_ids;
        CLOSE ins_prm_email_id_cur;
      
        OPEN ins_sec_email_id_cur(v_ins_seq_id);
        FETCH ins_sec_email_id_cur
          INTO v_cc_mail_ids;
        CLOSE ins_sec_email_id_cur;
      
        v_cc_mail_ids := v_cc_mail_ids || case
                           when v_pat_cc_mail_ids is not null then
                            ',' || v_pat_cc_mail_ids
                           else
                            null
                         end;
      
        v_send_date := case
                         when prod_pol_rec.mail_freq_hours is not null and
                              prod_pol_rec.mail_freq_mins is not null THEN
                          sysdate + (prod_pol_rec.mail_freq_hours / 24) +
                          ((prod_pol_rec.mail_freq_mins / 24) / 60)
                         when prod_pol_rec.mail_freq_hours is null and
                              prod_pol_rec.mail_freq_mins is not null THEN
                          sysdate + ((prod_pol_rec.mail_freq_mins / 24) / 60)
                         when prod_pol_rec.mail_freq_hours is not null and
                              prod_pol_rec.mail_freq_mins is null THEN
                          sysdate + (prod_pol_rec.mail_freq_mins / 24)
                         ELSE
                          SYSDATE + ((30 / 24) / 60)
                       END;
        v_remarks := case
                       when v_to_mail_ids is null then
                        'To mail id not exist'
                       else
                        null
                     end;
        v_flag := case
                    when v_to_mail_ids is null then
                     'N'
                    else
                     'Y'
                  end;*/
      
        /*  elsif v_msg_id in ('PAT_INS_INTIMATION_REMINDER','PAT_INS_INTIMATION_ESCALATION') then
         
         open  pat_ins_cur;
         fetch pat_ins_cur into pat_ins_rec; 
         close pat_ins_cur;
         
        v_pre_auth_number       := pat_ins_rec.pre_auth_number;
        v_date_of_admission     := pat_ins_rec.pat_ins_send_date;
        v_status                := pat_ins_rec.description;
        v_pat_seq_id            := pat_ins_rec.pat_enroll_detail_seq_id;
        v_abbrevation_code      := pat_ins_rec.abbrevation_code;
        v_ins_seq_id            := pat_ins_rec.ins_seq_id;
        v_claimant_name         := pat_ins_rec.claimant_name;
        v_policy_number         := pat_ins_rec.policy_number;
        v_apr_amt               := pat_ins_rec.total_app_amount;
        v_days                  := trunc(sysdate-pat_ins_rec.pat_ins_send_date);
        
        v_params(1):=   v_days;
        v_params(2):=   v_pre_auth_number;
        v_params(3):=   v_policy_number;
        v_params(4):=   v_claimant_name;   
        v_params(5):=   to_char(v_date_of_admission ,'DD-MON-YYYY');
        v_params(6):=   to_char(v_apr_amt,'9999999');
        v_params(7):=   v_status;
        
        v_pat_cc_mail_ids:=prod_pol_rec.pat_to_mail_id||','||prod_pol_rec.pat_cc_mail_id;
        
           */

      
      end if;

    
      select a.pat_enroll_detail_seq_id
        into v_pat_seq_id
        from pat_general_details a
       where a.pat_gen_detail_seq_id = v_pat_clm_seq_id;

    
      proc_mail_merge(v_msg_id, 'ON_MESSAGE', NULL, v_body);
    
      v_params(1) := v_pre_auth_number;
      v_params(2) := v_status;
    
      proc_mail_merge(v_msg_id, 'ON_TITLE', raw_rec.message_title, v_title);
    
    ELSIF v_msg_id IN ('CLM_INS_XFDF_PICKUP',
                       'TTK_SPOC_CLM_RESP',
                       'CLM_INS_INTIMATION',
                       'CLM_INS_INT_REMINDER_ONLINE',
                       'CLM_INS_INT_ESCALATION_ONLINE',
                       'CLM_INS_INT_REMINDER_XFDF',
                       'CLM_INS_INT_ESCALATION_XFDF') THEN
    
      if v_msg_id = 'CLM_INS_INTIMATION' then
      
        open clm_ins_cur;
        fetch clm_ins_cur
          into clm_ins_rec;
        close clm_ins_cur;
      
        v_claim_number      := clm_ins_rec.claim_number;
        v_date_of_admission := clm_ins_rec.Date_Of_Admission;
        v_status            := clm_ins_rec.description;
        v_clm_seq_id        := clm_ins_rec.claim_seq_id;
        v_abbrevation_code  := clm_ins_rec.abbrevation_code;
        v_ins_seq_id        := clm_ins_rec.ins_seq_id;
        v_claimant_name     := clm_ins_rec.claimant_name;
        v_policy_number     := clm_ins_rec.policy_number;
        v_apr_amt           := clm_ins_rec.total_app_amount;
      
        v_params(1) := v_claim_number;
        v_params(2) := v_policy_number;
        v_params(3) := v_claimant_name;
        v_params(4) := to_char(v_date_of_admission, 'DD-MON-YYYY');
        v_params(5) := trim(to_char(v_apr_amt, '99G99G99G999D99'));
        v_params(6) := v_status;
      
        OPEN ins_prm_email_id_cur(v_ins_seq_id);
        FETCH ins_prm_email_id_cur
          INTO v_to_mail_ids;
        CLOSE ins_prm_email_id_cur;
      
        OPEN ins_sec_email_id_cur(v_ins_seq_id);
        FETCH ins_sec_email_id_cur
          INTO v_cc_mail_ids;
        CLOSE ins_sec_email_id_cur;
      
        v_clm_cc_mail_ids := prod_pol_rec.Clm_To_Mail_Id || case
                               when prod_pol_rec.clm_cc_mail_id is not null then
                                ',' || prod_pol_rec.clm_cc_mail_id
                               else
                                null
                             end;
      
        v_cc_mail_ids := v_cc_mail_ids || case
                           when v_clm_cc_mail_ids is not null then
                            ',' || v_clm_cc_mail_ids
                           else
                            null
                         end;
      
        v_send_date := case
                         when prod_pol_rec.mail_freq_hours is not null and
                              prod_pol_rec.mail_freq_mins is not null THEN
                          sysdate + (prod_pol_rec.mail_freq_hours / 24) +
                          ((prod_pol_rec.mail_freq_mins / 24) / 60)
                         when prod_pol_rec.mail_freq_hours is null and
                              prod_pol_rec.mail_freq_mins is not null THEN
                          sysdate + ((prod_pol_rec.mail_freq_mins / 24) / 60)
                         when prod_pol_rec.mail_freq_hours is not null and
                              prod_pol_rec.mail_freq_mins is null THEN
                          sysdate + (prod_pol_rec.mail_freq_mins / 24)
                         ELSE
                          SYSDATE + (4 / 24)
                       END;
        v_remarks := case
                       when v_to_mail_ids is null then
                        'To mail id not exist'
                       else
                        null
                     end;
        v_flag := case
                    when v_to_mail_ids is null then
                     'N'
                    else
                     'Y'
                  end;
      
      elsif v_msg_id = 'TTK_SPOC_CLM_RESP' AND
            prod_pol_rec.Clm_Allowed_Yn = 'Y' then
      
        open clm_cur;
        fetch clm_cur
          into clm_rec;
        close clm_cur;
      
        IF v_added_by != 1 THEN
        
          OPEN ins_apr_mail_cur;
          FETCH ins_apr_mail_cur
            into v_cc_mail_ids;
          CLOSE ins_apr_mail_cur;
        
        END IF;

      
        v_claim_number      := clm_rec.claim_number;
        v_date_of_admission := clm_rec.Date_Of_Admission;
        v_status            := clm_rec.description;
        v_clm_seq_id        := clm_rec.claim_seq_id;
        v_claimant_name     := clm_rec.claimant_name;
        v_policy_number     := clm_rec.policy_number;
        v_apr_amt           := clm_rec.total_app_amount;
      
        v_params(1) := v_claim_number;
        v_params(2) := v_policy_number;
        v_params(3) := v_claimant_name;
        v_params(4) := to_char(v_date_of_admission, 'DD-MON-YYYY');
        v_params(5) := trim(to_char(v_apr_amt, '99G99G99G999D99'));
        v_params(6) := v_status;
      
        v_to_mail_ids := prod_pol_rec.clm_to_mail_id;
        v_cc_mail_ids := v_cc_mail_ids || ',' ||
                         prod_pol_rec.clm_cc_mail_id;
        v_send_date := case
                         when prod_pol_rec.mail_freq_hours is not null and
                              prod_pol_rec.mail_freq_mins is not null THEN
                          sysdate + (prod_pol_rec.mail_freq_hours / 24) +
                          ((prod_pol_rec.mail_freq_mins / 24) / 60)
                         when prod_pol_rec.mail_freq_hours is null and
                              prod_pol_rec.mail_freq_mins is not null THEN
                          sysdate + ((prod_pol_rec.mail_freq_mins / 24) / 60)
                         when prod_pol_rec.mail_freq_hours is not null and
                              prod_pol_rec.mail_freq_mins is null THEN
                          sysdate + (prod_pol_rec.mail_freq_mins / 24)
                         ELSE
                          SYSDATE + (4 / 24)
                       END;
        v_remarks := case
                       when prod_pol_rec.clm_to_mail_id is not null then
                        null
                       else
                        'To mail id not exist.'
                     end;
        v_flag := case
                    when prod_pol_rec.clm_to_mail_id is not null then
                     'Y'
                    ELSE
                     'N'
                  END;
      
      /*elsif v_msg_id = 'CLM_INS_XFDF_PICKUP' then
      
        open clm_ins_xfdf_cur;
        fetch clm_ins_xfdf_cur
          into clm_ins_xfdf_rec;
        close clm_ins_xfdf_cur;
      
        v_claim_number      := clm_ins_xfdf_rec.claim_number;
        v_date_of_admission := clm_ins_xfdf_rec.Date_Of_Admission;
        v_status            := clm_ins_xfdf_rec.description;
        v_clm_seq_id        := clm_ins_xfdf_rec.claim_seq_id;
        v_abbrevation_code  := clm_ins_xfdf_rec.abbrevation_code;
        v_ins_seq_id        := clm_ins_xfdf_rec.ins_seq_id;
        v_claimant_name     := clm_ins_xfdf_rec.claimant_name;
        v_policy_number     := clm_ins_xfdf_rec.policy_number;
        v_apr_amt           := clm_ins_xfdf_rec.total_app_amount;
      
        claims_approval_pkg.claims_xfdf_report(v_pat_clm_seq_id,
                                               v_file_name,
                                               v_generate_yn);
      
        v_params(1) := v_claim_number;
        v_params(2) := v_policy_number;
        v_params(3) := v_claimant_name;
        v_params(4) := to_char(v_date_of_admission, 'DD-MON-YYYY');
        v_params(5) := trim(to_char(v_apr_amt, '99G99G99G999D99'));
        v_params(6) := v_status;
      
        OPEN ins_prm_email_id_cur(v_ins_seq_id);
        FETCH ins_prm_email_id_cur
          INTO v_to_mail_ids;
        CLOSE ins_prm_email_id_cur;
      
        OPEN ins_sec_email_id_cur(v_ins_seq_id);
        FETCH ins_sec_email_id_cur
          INTO v_cc_mail_ids;
        CLOSE ins_sec_email_id_cur;
      
        v_clm_cc_mail_ids := prod_pol_rec.Clm_To_Mail_Id || case
                               when prod_pol_rec.clm_cc_mail_id is not null then
                                ',' || prod_pol_rec.clm_cc_mail_id
                               else
                                null
                             end;
      
        v_cc_mail_ids := v_cc_mail_ids || ',' || v_clm_cc_mail_ids;
      
        v_send_date := case
                         when prod_pol_rec.mail_freq_hours is not null and
                              prod_pol_rec.mail_freq_mins is not null THEN
                          sysdate + (prod_pol_rec.mail_freq_hours / 24) +
                          ((prod_pol_rec.mail_freq_mins / 24) / 60)
                         when prod_pol_rec.mail_freq_hours is null and
                              prod_pol_rec.mail_freq_mins is not null THEN
                          sysdate + ((prod_pol_rec.mail_freq_mins / 24) / 60)
                         when prod_pol_rec.mail_freq_hours is not null and
                              prod_pol_rec.mail_freq_mins is null THEN
                          sysdate + (prod_pol_rec.mail_freq_mins / 24)
                         ELSE
                          SYSDATE + (4 / 24)
                       END;
        v_remarks := case
                       when v_to_mail_ids is null then
                        'To mail id not exist'
                       else
                        null
                     end;
        v_flag := case
                    when v_to_mail_ids is null then
                     'N'
                    else
                     'Y'
                  end;*/
      
      elsif v_msg_id IN
            ('CLM_INS_INT_REMINDER_ONLINE', 'CLM_INS_INT_REMINDER_XFDF') then
      
        open clm_ins_cur;
        fetch clm_ins_cur
          into clm_ins_rec;
        close clm_ins_cur;
      
        open rem_days_cur('CLM', 'REM2');
        fetch rem_days_cur
          into rem_days_rec;
        close rem_days_cur;
      
        v_claim_number      := clm_ins_rec.claim_number;
        v_date_of_admission := clm_ins_rec.Date_Of_Admission;
        v_status            := clm_ins_rec.description;
        v_clm_seq_id        := clm_ins_rec.claim_seq_id;
        v_abbrevation_code  := clm_ins_rec.abbrevation_code;
        v_ins_seq_id        := clm_ins_rec.ins_seq_id;
        v_claimant_name     := clm_ins_rec.claimant_name;
        v_policy_number     := clm_ins_rec.policy_number;
        v_apr_amt           := clm_ins_rec.total_app_amount;
        v_days              := rem_days_rec.remainder_value;
      
        v_params(1) := v_claim_number;
        v_params(2) := v_policy_number;
        v_params(3) := v_claimant_name;
        v_params(4) := to_char(v_date_of_admission, 'DD-MON-YYYY');
        v_params(5) := trim(to_char(v_apr_amt, '99G99G99G999D99'));
        v_params(6) := v_status;
        v_params(7) := to_char(clm_ins_rec.clm_ins_send_date, 'DD-MON-YYYY');
        v_params(8) := CASE clm_ins_rec.Clm_Status_General_Type_Id
                         WHEN 'REJ' THEN
                          'Rejection'
                         when 'APR' THEN
                          'Approval'
                       end;
        v_params(9) := v_days;
      
        v_clm_cc_mail_ids := prod_pol_rec.Clm_To_Mail_Id || case
                               when prod_pol_rec.clm_cc_mail_id is not null then
                                ',' || prod_pol_rec.clm_cc_mail_id
                               else
                                null
                             end;
      
        OPEN ins_prm_email_id_cur(v_ins_seq_id);
        FETCH ins_prm_email_id_cur
          INTO v_to_mail_ids;
        CLOSE ins_prm_email_id_cur;
      
        OPEN ins_sec_email_id_cur(v_ins_seq_id);
        FETCH ins_sec_email_id_cur
          INTO v_cc_mail_ids;
        CLOSE ins_sec_email_id_cur;
      
        v_cc_mail_ids := v_cc_mail_ids || case
                           when v_clm_cc_mail_ids is not null then
                            ',' || v_clm_cc_mail_ids
                           else
                            null
                         end;
      
        v_remarks := case
                       when v_to_mail_ids is null then
                        'To mail id not exist'
                       else
                        null
                     end;
        v_send_date := SYSDATE;
        v_flag := case
                    when v_to_mail_ids is null then
                     'N'
                    else
                     'Y'
                  end;
      
       /* IF v_msg_id = 'CLM_INS_INT_REMINDER_XFDF' then
          claims_approval_pkg.claims_xfdf_report(v_pat_clm_seq_id,
                                                 v_file_name,
                                                 v_generate_yn);
        END IF;*/

      
      ELSIF v_msg_id IN
            ('CLM_INS_INT_ESCALATION_ONLINE', 'CLM_INS_INT_ESCALATION_XFDF') THEN
      
        open clm_ins_cur;
        fetch clm_ins_cur
          into clm_ins_rec;
        close clm_ins_cur;
      
        v_claim_number      := clm_ins_rec.claim_number;
        v_date_of_admission := clm_ins_rec.Date_Of_Admission;
        v_status            := clm_ins_rec.description;
        v_clm_seq_id        := clm_ins_rec.claim_seq_id;
        v_abbrevation_code  := clm_ins_rec.abbrevation_code;
        v_ins_seq_id        := clm_ins_rec.ins_seq_id;
        v_claimant_name     := clm_ins_rec.claimant_name;
        v_policy_number     := clm_ins_rec.policy_number;
        v_apr_amt           := clm_ins_rec.total_app_amount;
      
        v_params(1) := CASE clm_ins_rec.Clm_Status_General_Type_Id
                         WHEN 'REJ' THEN
                          'Rejection'
                         when 'APR' THEN
                          'Approval'
                       end;
        v_params(2) := to_char(clm_ins_rec.Clm_Ins_Send_Date, 'DD-MON-YYYY');
        v_params(3) := to_char(clm_ins_rec.ins_rem_snt_date, 'DD-MON-YYYY');
        v_params(4) := v_claim_number;
        v_params(5) := v_policy_number;
        v_params(6) := v_claimant_name;
        v_params(7) := to_char(v_date_of_admission, 'DD-MON-YYYY');
        v_params(8) := trim(to_char(v_apr_amt, '99G99G99G999D99'));
        v_params(9) := v_status;
      
        v_clm_cc_mail_ids := prod_pol_rec.Clm_To_Mail_Id || case
                               when prod_pol_rec.clm_cc_mail_id is not null then
                                ',' || prod_pol_rec.clm_cc_mail_id
                               else
                                null
                             end;
      
        OPEN ins_escalation_prm_mailid_cur(v_ins_seq_id,
                                           clm_ins_rec.ins_comp_code_number);
        FETCH ins_escalation_prm_mailid_cur
          INTO v_to_mail_ids;
        CLOSE ins_escalation_prm_mailid_cur;
      
        OPEN ins_prm_email_id_cur(v_ins_seq_id);
        FETCH ins_prm_email_id_cur
          INTO v_CC_mail_ids;
        CLOSE ins_prm_email_id_cur;
      
        v_CC_mail_ids := v_CC_mail_ids || case
                           when v_clm_cc_mail_ids is not null then
                            ',' || v_clm_cc_mail_ids
                           else
                            null
                         end;
      
        v_remarks := case
                       when v_to_mail_ids is null then
                        'To mail id not exist'
                       else
                        null
                     end;
        v_send_date := SYSDATE;
        v_flag := case
                    when v_to_mail_ids is null then
                     'N'
                    else
                     'Y'
                  end;
      
      /*  IF v_msg_id = 'CLM_INS_INT_ESCALATION_XFDF' then
          claims_approval_pkg.claims_xfdf_report(v_pat_clm_seq_id,
                                                 v_file_name,
                                                 v_generate_yn);
        END IF;
*/
      
      end if;

    
      proc_mail_merge(v_msg_id, 'ON_MESSAGE', NULL, v_body);
    
      v_params(1) := v_claim_number;
      v_params(2) := v_status;
    
      proc_mail_merge(v_msg_id, 'ON_TITLE', raw_rec.message_title, v_title);
    
      v_clm_seq_id := v_pat_clm_seq_id;
    
    end if;

  
    IF v_msg_id in ('CLM_INS_INT_REMINDER_XFDF',
                    'CLM_INS_INT_ESCALATION_XFDF',
                    'PAT_INS_XFDF_PICKUP',
                    'CLM_INS_XFDF_PICKUP') then
    
      INSERT INTO DESTINATION_MESSAGE
        (DEST_MSG_SEQ_ID,
         MSG_ID,
         SOURCE_ID,
         SOURCE_SEQ_ID,
         MSG_SENT_FROM,
         MESSAGE_TITLE,
         MESSAGE,
         SMS_DESCRIPTION,
         ADDED_BY,
         ADDED_DATE,
         ENROLLMENT_NUMBER,
         FILE_PATH_NAME)
      VALUES
        (DESTINATION_MESSAGE_SEQ.NEXTVAL,
         v_msg_id,
         raw_rec.module_name,
         v_pat_clm_seq_id,
         raw_rec.msg_sent_from,
         v_title,
         v_body,
         null,
         v_added_by,
         sysdate,
         case when v_pre_auth_number is not null then v_pre_auth_number else
         v_claim_number end,
         case when v_file_name is not null then
         replace(v_file_name, '.xfdf', '.pdf') else v_file_name end)
      RETURNING DEST_MSG_SEQ_ID INTO v_DEST_MSG_SEQ_ID;

    
      INSERT INTO DESTINATION_MESSAGE_RCPT
        (DEST_MSG_RCPT_SEQ_ID,
         DEST_MSG_SEQ_ID,
         PRM_RCPT_EMAIL_LIST,
         PRM_RCPT_SMS,
         PRM_RCPT_FAX_NOS,
         SEC_RCPT_EMAIL_LIST,
         REMARKS,
         ADDED_BY,
         ADDED_DATE,
         MSG_TYPE,
         PRESENT_YN,
         MAIL_STATUS,
         MSG_STATUS_GENERAL_TYPE_ID,
         SENT_DATE)
      VALUES
        (DESTINATION_MESSAGE_RCPT_SEQ.NEXTVAL,
         v_DEST_MSG_SEQ_ID,
         v_to_mail_ids,
         NULL,
         NULL,
         v_cc_mail_ids,
         v_remarks,
         v_added_by,
         sysdate,
         'EMAIL',
         V_FLAG,
         'INP',
         'MIQ', -- Message in queue
         NULL);

    
    else
    
      IF (v_msg_id = 'TTK_SPOC_PAT_RESP' and
         prod_pol_rec.pat_allowed_yn = 'Y') OR
         (v_msg_id = 'TTK_SPOC_CLM_RESP' and
         prod_pol_rec.Clm_Allowed_Yn = 'Y') OR
         (v_msg_id IN ('PAT_INS_INTIMATION', 'CLM_INS_INTIMATION')) or
         (v_msg_id in ('PAT_INS_INTIMATION_REMINDER',
                       'PAT_INS_INTIMATION_ESCALATION',
                       'CLM_INS_INT_REMINDER_ONLINE',
                       'CLM_INS_INT_ESCALATION_ONLINE')) THEN
        insert into destination_mail_rcpt
          (destination_mail_seq_id,
           msg_id,
           mail_subject,
           mail_body,
           mail_sent_from,
           to_mail_ids,
           cc_mail_ids,
           mail_send_date,
           remarks,
           mail_id_exist_yn,
           mail_status,
           added_by,
           added_date)
        values
          (destination_mail_seq.nextval,
           v_msg_id,
           v_title,
           v_body,
           raw_rec.msg_sent_from,
           v_to_mail_ids,
           v_cc_mail_ids,
           v_send_date,
           v_remarks,
           v_flag,
           'INP',
           v_added_by,
           SYSDATE);

      END IF;

    end if;

  
    IF sql%rowcount > 0 then
    
      IF v_to_mail_ids IS NOT NULL AND v_msg_id = 'TTK_SPOC_PAT_RESP' then
      
        update PAT_INS_INTIMATION_DETAILS a
           set a.Ins_Mail_Respond_Date = SYSDATE,
               A.UPDATED_BY            = v_added_by,
               A.UPDATED_DATE          = SYSDATE
         WHERE A.PAT_AUTH_SEQ_ID = v_pat_seq_id;

      
      ELSIF v_to_mail_ids IS NOT NULL AND v_msg_id = 'PAT_INS_INTIMATION' then
      
        update PAT_INS_INTIMATION_DETAILS a
           SET a.Pat_Mail_Send_Date = SYSDATE,
               A.UPDATED_BY         = v_added_by,
               A.UPDATED_DATE       = SYSDATE
         WHERE A.PAT_AUTH_SEQ_ID = v_pat_seq_id;

      
      ELSIF v_to_mail_ids IS NOT NULL AND v_msg_id = 'TTK_SPOC_CLM_RESP' then
      
        update CLM_INS_INTIMATION_DETAILS a
           set a.Ins_Mail_Respond_Date = SYSDATE,
               A.UPDATED_BY            = v_added_by,
               A.UPDATED_DATE          = SYSDATE
         WHERE A.Claim_Seq_Id = v_pat_clm_seq_id;

      
      ELSIF v_to_mail_ids IS NOT NULL AND v_msg_id = 'CLM_INS_INTIMATION' then
      
        update CLM_INS_INTIMATION_DETAILS a
           set a.Clm_Mail_Send_Date = SYSDATE,
               A.UPDATED_BY         = v_added_by,
               A.UPDATED_DATE       = SYSDATE
         WHERE A.Claim_Seq_Id = v_pat_clm_seq_id;

      
      ELSIF v_to_mail_ids IS NOT NULL AND v_msg_id = 'PAT_INS_XFDF_PICKUP' then
      
        update PAT_INS_INTIMATION_DETAILS a
           set a.Pat_Mail_Send_Date = SYSDATE,
               A.UPDATED_BY         = v_added_by,
               A.UPDATED_DATE       = SYSDATE
         WHERE A.PAT_AUTH_SEQ_ID = v_pat_seq_id;

      
      ELSIF v_to_mail_ids IS NOT NULL AND v_msg_id = 'CLM_INS_XFDF_PICKUP' then
      
        update CLM_INS_INTIMATION_DETAILS a
           set a.Clm_Mail_Send_Date = SYSDATE,
               A.UPDATED_BY         = v_added_by,
               A.UPDATED_DATE       = SYSDATE
         WHERE A.Claim_Seq_Id = v_pat_clm_seq_id;

      
      ELSIF v_to_mail_ids IS NOT NULL AND
            v_msg_id = 'PAT_INS_INTIMATION_REMINDER' then
      
        update PAT_ins_intimation_details a
           set a.Remainder_Flag   = 'REM',
               a.ins_rem_snt_date = sysdate,
               A.UPDATED_BY       = v_added_by,
               A.UPDATED_DATE     = SYSDATE
         WHERE A.PAT_AUTH_SEQ_ID = v_pat_seq_id;

      
      elsif v_to_mail_ids IS NOT NULL AND
            v_msg_id = 'PAT_INS_INTIMATION_ESCALATION' then
      
        update PAT_ins_intimation_details a
           set a.Remainder_Flag   = 'ESC',
               A.INS_ESC_SNT_DATE = SYSDATE,
               A.UPDATED_BY       = v_added_by,
               A.UPDATED_DATE     = SYSDATE
         WHERE A.PAT_AUTH_SEQ_ID = v_pat_seq_id;

      
      elsif v_to_mail_ids IS NOT NULL AND
            v_msg_id = 'CLM_INS_INT_REMINDER_ONLINE' then
      
        update clm_ins_intimation_details a
           set a.Remainder_Flag   = 'REM',
               A.INS_REM_SNT_DATE = SYSDATE,
               A.UPDATED_BY       = v_added_by,
               A.UPDATED_DATE     = SYSDATE
         WHERE A.Claim_Seq_Id = v_pat_clm_seq_id;

      
      elsif v_to_mail_ids IS NOT NULL AND
            v_msg_id = 'CLM_INS_INT_ESCALATION_ONLINE' then
      
        update clm_ins_intimation_details a
           set a.Remainder_Flag   = 'ESC',
               A.INS_ESC_SNT_DATE = SYSDATE,
               A.UPDATED_BY       = v_added_by,
               A.UPDATED_DATE     = SYSDATE
         WHERE A.Claim_Seq_Id = v_pat_clm_seq_id;

      
      elsif v_to_mail_ids IS NOT NULL AND
            v_msg_id = 'CLM_INS_INT_REMINDER_XFDF' then
      
        update clm_ins_intimation_details a
           set a.Remainder_Flag   = 'REM',
               A.INS_REM_SNT_DATE = SYSDATE,
               A.UPDATED_BY       = v_added_by,
               A.UPDATED_DATE     = SYSDATE
         WHERE A.Claim_Seq_Id = v_pat_clm_seq_id;

      
      elsif v_to_mail_ids IS NOT NULL AND
            v_msg_id = 'CLM_INS_INT_ESCALATION_XFDF' then
      
        update clm_ins_intimation_details a
           set a.Remainder_Flag   = 'ESC',
               A.INS_ESC_SNT_DATE = SYSDATE,
               A.UPDATED_BY       = v_added_by,
               A.UPDATED_DATE     = SYSDATE
         WHERE A.Claim_Seq_Id = v_pat_clm_seq_id;

      
      end if;

    
    end if;

    commit;
  
  end proc_generate_mail;

  -----------------------------------------------------------------------------------------------
  -------------------------------------------------------------------------------------------------

  ----==========================================koc cigna mails ===========================================
  PROCEDURE proc_form_message_cigna(v_message_type_id    VARCHAR2,
                                    v_parameters         VARCHAR2,
                                    v_added_by           Destination_message.added_by%TYPE,
                                    v_DEST_MSG_SEQ_ID    OUT VARCHAR2,
                                    v_additional_param   VARCHAR2 DEFAULT 0,
                                    v_additional_param_2 VARCHAR2 DEFAULT 0,
                                    v_additional_param_3 VARCHAR2 DEFAULT 0)
  
   IS
    v_email_id            tpa_user_contacts.primary_email_id%TYPE;
    v_next_message_called VARCHAR2(1000);
    v_count               INTEGER;
    v_hosp_seq_id         TPA_HOSP_INFO.HOSP_SEQ_ID%TYPE;
    str_tab               ttk_util_pkg.str_table_type; --koc_ins_mail
    v_mesg_id             varchar2(1000); --koc_ins_mail
    v_rows_processed      NUMBER(10); --koc_ins_mail
    v_msg_str             VARCHAR2(10000); --koc_ins_mail
    v_notify_typ_id       TPA_INS_INFO.NOTIFY_TYPE_ID%TYPE; --koc_ins_mail
  
    -- Get the Hospital ACTIVE TPA PRIMARY CO-ordinators EMAIL ID for THOSE HOSPITALS
    -- Where the Notification is being ENABLED.
    CURSOR cr_get_hospital_email_id(v_hosp_seq_id TPA_HOSP_INFO.HOSP_SEQ_ID%TYPE) IS
      SELECT tpa_user_contacts.primary_email_id AS EMAIL_ID --//ED
        FROM tpa_hosp_info, tpa_user_contacts
       WHERE (tpa_user_contacts.active_yn = 'Y')
         AND (tpa_user_contacts.primary_email_id IS NOT NULL)
         AND --//ED
             (tpa_user_contacts.hosp_seq_id = tpa_hosp_info.hosp_seq_id)
         and (tpa_user_contacts.designation_type_id = 'CRP')
         AND (tpa_hosp_info.notification_general_type_id = 'NAE')
         AND (tpa_hosp_info.hosp_seq_id = v_hosp_seq_id);

  
    -- PRE-Auth REGULAR
    CURSOR cr_get_regular_preauth(v_pat_gen_detail_seq_id pat_general_details.pat_gen_detail_seq_id%TYPE) IS
      SELECT pat_enroll_details.hosp_seq_id
        FROM pat_enroll_details, pat_general_details
       WHERE (pat_general_details.pat_enroll_detail_seq_id =
             pat_enroll_details.pat_enroll_detail_seq_id)
         and (pat_general_details.pat_gen_detail_seq_id =
             v_pat_gen_detail_seq_id);

  
    -- PRE-AUTH shortfall
    CURSOR cr_get_shortfall_regular(v_shortfall_seq_id shortfall_details.SHORTFALL_SEQ_ID%TYPE) IS
      SELECT pat_enroll_details.hosp_seq_id
        FROM pat_enroll_details, pat_general_details, shortfall_details A
       WHERE (pat_general_details.pat_enroll_detail_seq_id =
             pat_enroll_details.pat_enroll_detail_seq_id)
         and (pat_general_details.pat_gen_detail_seq_id =
             A.PAT_GEN_DETAIL_SEQ_ID)
         and (A.SHORTFALL_SEQ_ID = v_shortfall_seq_id);

  
  BEGIN
  
    IF instr(v_message_type_id, '|') > 0 THEN
      v_mesg_id := ('|' || v_message_type_id || '|');
      str_tab   := ttk_util_pkg.parse_str(v_mesg_id);
    ELSE
      str_tab(1) := v_message_type_id;

    END IF;

  
    FOR i IN str_tab.FIRST .. str_tab.LAST LOOP
      IF str_tab(i) LIKE '%CIGNA_CLM%' THEN
        for msg_str in (SELECT grp.ins_seq_id,
                               ins.ins_comp_name,
                               grp.msg_id,
                               ins.notify_type_id
                          FROM clm_enroll_details B
                          JOIN clm_general_details C
                            ON (B.CLAIM_SEQ_ID = C.CLAIM_SEQ_ID)
                          JOIN tpa_ins_info ins
                            on (ins.ins_seq_id = b.ins_seq_id)
                          JOIN APP.SOURCE_MESSAGE_custom_grp grp
                            on (grp.ins_seq_id = b.ins_seq_id)
                          LEFT OUTER JOIN SHORTFALL_DETAILS SD
                            ON (SD.CLAIM_SEQ_ID = C.CLAIM_SEQ_ID)
                         WHERE C.Claim_Seq_Id = v_parameters
                            OR SD.SHORTFALL_SEQ_ID = v_parameters) loop
        
          v_msg_str       := v_msg_str || ',' || msg_str.msg_id;
          v_notify_typ_id := msg_str.notify_type_id;
        end loop;

      ELSIF str_tab(i) LIKE '%CIGNA_PAT%' THEN
        for msg_str in (SELECT grp.ins_seq_id,
                               ins.ins_comp_name,
                               grp.msg_id,
                               ins.notify_type_id,
                               c.final_app_yn
                          FROM PAT_ENROLL_DETAILS B
                          JOIN PAT_GENERAL_DETAILS C
                            ON (B.PAT_ENROLL_DETAIL_SEQ_ID =
                               C.PAT_ENROLL_DETAIL_SEQ_ID)
                          JOIN tpa_ins_info ins
                            on (ins.ins_seq_id = b.ins_seq_id)
                          JOIN APP.SOURCE_MESSAGE_custom_grp grp
                            on (grp.ins_seq_id = b.ins_seq_id)
                          LEFT OUTER JOIN SHORTFALL_DETAILS SD
                            ON (SD.PAT_GEN_DETAIL_SEQ_ID =
                               C.PAT_GEN_DETAIL_SEQ_ID)
                         WHERE C.PAT_GEN_DETAIL_SEQ_ID = v_parameters
                            OR SD.SHORTFALL_SEQ_ID = v_parameters) loop
        
          v_notify_typ_id := msg_str.notify_type_id;
          v_msg_str       := v_msg_str || ',' || msg_str.msg_id;
        end loop;

      END IF;

      IF v_msg_str LIKE '%' || str_tab(i) || '%' THEN
        --Rgular mail generation
        IF str_tab(i) LIKE '%PAT_SHFALL_FRST_EMAIL%' THEN
          generate_clm_shortfal_mails(str_tab(i),
                                      v_parameters,
                                      null,
                                      v_dest_msg_seq_id,
                                      v_added_by,
                                      v_rows_processed);
        ELSE
          proc_generate_message_cigna(str_tab(i),
                                      v_parameters,
                                      v_added_by,
                                      v_dest_msg_seq_id,
                                      v_additional_param,
                                      v_additional_param_2,
                                      v_additional_param_3);
        
        END IF;

      END IF;

    
      -- Additionl to the earlier mail, if hospital mail has to be sent, then following execution has to happen.
      IF (str_tab(i) in
         ('CIGNA_PAT_REQUEST_EMAIL_PO', 'CIGNA_PAT_REQUEST_EMAIL_AD') OR
         str_tab(i) in ('CIGNA_PAT_INITIAL_APP_EMAIL_PO',
                         'CIGNA_PAT_INITIAL_APP_EMAIL_AD',
                         'CIGNA_PAT_FINAL_APP_EMAIL_PO',
                         'CIGNA_PAT_FINAL_APP_EMAIL_AD') or
         str_tab(i) in
         ('CIGNA_PAT_REJECT_EMAIL_PO', 'CIGNA_PAT_REJECT_EMAIL_AD')) THEN
        IF str_tab(i) in
           ('CIGNA_PAT_REQUEST_EMAIL_PO', 'CIGNA_PAT_REQUEST_EMAIL_AD') THEN
          v_next_message_called := 'PREAUTH_STATUS_NHCP';
        ELSIF (str_tab(i) in
              ('CIGNA_PAT_INITIAL_APP_EMAIL_PO',
                'CIGNA_PAT_INITIAL_APP_EMAIL_AD',
                'CIGNA_PAT_FINAL_APP_EMAIL_PO',
                'CIGNA_PAT_FINAL_APP_EMAIL_AD')) THEN
          v_next_message_called := 'PREAUTH_APPROVED_NHCP';

        ELSIF (str_tab(i) in
              ('CIGNA_PAT_REJECT_EMAIL_PO', 'CIGNA_PAT_REJECT_EMAIL_AD')) THEN
          v_next_message_called := 'PREAUTH_REJECTED_NHCP';

        END IF;

      
        OPEN cr_get_regular_preauth(v_parameters);
        FETCH cr_get_regular_preauth
          INTO v_hosp_seq_id;
        CLOSE cr_get_regular_preauth;
      ELSIF (str_tab(i) in
            ('CIGNA_PAT_SHFALL_FRST_EMAIL_PO',
              'CIGNA_PAT_SHFALL_FRST_EMAIL_AD')) THEN
        v_next_message_called := 'PREAUTH_SHORTFALL_NHCP';
        OPEN cr_get_shortfall_regular(v_parameters);
        FETCH cr_get_shortfall_regular
          INTO v_hosp_seq_id;
        CLOSE cr_get_shortfall_regular;

      END IF;

    
    end loop;

    -- Usually there is going to be only one TPA_COORDINATOR.
    -- Incase if there are more than 1 TPA PRIMARY CO-ordinator....
    v_count := 0;
    FOR rec IN cr_get_hospital_email_id(v_hosp_seq_id) LOOP
      IF (v_count = 0) THEN
        v_email_id := rec.email_id;
        v_count    := v_count + 1;
      ELSE
        v_email_id := v_email_id || ',' || rec.email_id;

      END IF;

    END LOOP;

  
    -- If v_count = 1 then hospital notification to be sent.
    IF (v_count = 1) THEN
      proc_generate_message(v_next_message_called,
                            v_parameters,
                            v_added_by,
                            v_DEST_MSG_SEQ_ID,
                            v_email_id,
                            v_additional_param_2,
                            v_additional_param_3);
    END IF;

    v_rows_processed := sql%rowcount;
  END proc_form_message_cigna;

  --------------------------------------------------------
  PROCEDURE proc_generate_message_cigna(v_message_type_id    VARCHAR2,
                                        v_parameters         VARCHAR2,
                                        v_added_by           Destination_message.added_by%TYPE,
                                        v_DEST_MSG_SEQ_ID    OUT VARCHAR2,
                                        v_additional_param   VARCHAR2 DEFAULT 0,
                                        v_additional_param_2 VARCHAR2 DEFAULT 0,
                                        v_additional_param_3 VARCHAR2 DEFAULT 0) IS
    v_sid                VARCHAR2(100);
    v_merged_message     VARCHAR2(10000);
    v_merged_SMS_message VARCHAR2(4000);
    -- v_user_id                  tpa_login_info.user_id%TYPE;
    v_email_id         tpa_user_contacts.primary_email_id%TYPE;
    v_url_name         tpa_system_parameters.application_url%TYPE;
    v_module_name      APP.SOURCE_MESSAGE.module_name%TYPE;
    v_sent_from        APP.SOURCE_MESSAGE.msg_sent_from%TYPE;
    v_msg_title        APP.SOURCE_MESSAGE.message_title%TYPE;
    v_send_as_email_yn APP.SOURCE_MESSAGE.send_as_email_yn%TYPE;
    v_send_as_sms_yn   APP.SOURCE_MESSAGE.send_as_sms_yn%TYPE;
    v_send_as_fax_yn   APP.SOURCE_MESSAGE.send_as_fax_yn%TYPE;
    v_prm_rcpt_list    APP.SOURCE_MESSAGE.prm_rcpt_email_list%TYPE;
    v_sec_rcpt_list    APP.SOURCE_MESSAGE.sec_rcpt_email_list%TYPE;
    v_email_ids        DESTINATION_MESSAGE_RCPT.PRM_RCPT_EMAIL_LIST%TYPE;
    v_sms              DESTINATION_MESSAGE_RCPT.PRM_RCPT_SMS%TYPE;
    v_fax              DESTINATION_MESSAGE_RCPT.PRM_RCPT_FAX_NOS%TYPE;
    v_insert_message   VARCHAR2(1);
    --v_claimant_name            pat_enroll_details.claimant_name%TYPE;
    v_employee_no           VARCHAR2(50); --FOR KOC 1268
    v_claimant_name         VARCHAR2(90);
    v_received_date         DATE;
    v_pre_auth_number       pat_enroll_details.pre_auth_number%TYPE;
    v_auth_number           pat_enroll_details.auth_number%TYPE;
    v_status                tpa_general_code.description%TYPE;
    v_sms_phone             pat_general_details.phone_no_in_hospitalisation%TYPE;
    v_fax_number            DESTINATION_MESSAGE_RCPT.PRM_RCPT_FAX_NOS%TYPE;
    v_requested_amt         pat_general_details.pat_requested_amount%TYPE;
    v_type                  pat_general_details.pat_general_type_id%TYPE;
    v_total_approved_amount pat_general_details.total_app_amount%TYPE;
    v_count                 NUMBER;
    v_tpa_code              tpa_office_info.office_code%TYPE;
    v_tpa_toll_phone        tpa_office_info.toll_free_no%TYPE;
    v_shortfall_id          shortfall_details.shortfall_id%TYPE;
    v_hosp_seq_id           pat_enroll_details.hosp_seq_id%TYPE;
    v_policy_seq_id         tpa_enr_policy.policy_seq_id%TYPE;
    v_member_seq_id         tpa_enr_policy_member.member_seq_id%TYPE;
    v_remarks               VARCHAR2(3000);
    v_claim_number          clm_general_details.claim_number%TYPE;
    v_final_log_message     VARCHAR2(4000);
    v_message_status        VARCHAR2(2000);
    v_hospital_name         TPA_HOSP_INFO.HOSP_NAME%TYPE;
    v_notification_type     VARCHAR2(30);
    v_pat_gen_detail_seq_id pat_general_details.pat_gen_detail_seq_id%TYPE;
    v_claim_seq_id          clm_general_details.claim_seq_id%TYPE;
    v_claim_type            clm_inward.claim_general_type_id%TYPE;
    v_enrollment_number     tpa_enr_policy_group.tpa_enrollment_number%TYPE;
    v_msg_type              destination_message_rcpt.msg_type%TYPE;
    v_present_yn            destination_message_rcpt.present_yn%TYPE;
    v_document_name         destination_message.FILE_PATH_NAME%TYPE;
    v_user_type             tpa_user_contacts.user_general_type_id%TYPE;
    v_case_number           VARCHAR2(250);
    v_member_info           VARCHAR2(4000);
    v_doh                   DATE;
    v_mail_category         VARCHAR2(3); -- The send message id is of what type in Database
    v_process_yn            VARCHAR2(1); -- Can the process be done or not
    v_general_mail          DESTINATION_MESSAGE_RCPT.PRM_RCPT_EMAIL_LIST%TYPE; -- Generic mail id created at the group
    v_cc_mail               DESTINATION_MESSAGE_RCPT.SEC_RCPT_EMAIL_LIST%TYPE;
    v_group_name            TPA_GROUP_REGISTRATION.GROUP_NAME%TYPE;
    v_customise_allowed_YN  APP.SOURCE_MESSAGE.CUSTOMIZATION_ALLOWED_YN%TYPE;
    --koc 1216 v1 mail template
  
    V_AILMENT_DESCRIPTION        AILMENT_DETAILS.AILMENT_DESCRIPTION%TYPE;
    V_DATE_OF_DISCHARGE          DATE;
    V_INSURED_NAME               TPA_ENR_POLICY_GROUP.INSURED_NAME%TYPE;
    V_TPA_ENROLLMENT_ID          PAT_ENROLL_DETAILS.TPA_ENROLLMENT_ID%TYPE;
    v_provisional_diagnosis      AILMENT_DETAILS.provisional_diagnosis%type;
    v_pat_status_general_type_id pat_enroll_details.pat_status_general_type_id%type;
    v_prev_approved_amount       pat_general_details.prev_approved_amount%type;
    V_CLAIM_FILE_NUMBER          CLM_GENERAL_DETAILS.CLAIM_FILE_NUMBER%TYPE;
    V_POLICY_NUMBER              tpa_enr_policy.policy_number%type;
    V_HOSP_NAME                  TPA_HOSP_INFO.HOSP_NAME%TYPE;
    V_ADDITTIONAL_SUM            PAT_GENERAL_DETAILS.PAT_REQUESTED_AMOUNT%TYPE;
    V_FINAL_SUM                  PAT_GENERAL_DETAILS.PAT_REQUESTED_AMOUNT%TYPE;
  
    v_shrtfall_que varchar2(4000);
  
    -- Get the URL Name
    CURSOR cr_get_URL_Name(v_user_type tpa_user_contacts.user_general_type_id%TYPE) IS
      SELECT CASE
               WHEN v_user_type IN ('TTK', 'DMC', 'CAL') THEN
                APPLICATION_URL
               ELSE
                WEB_LOGIN_URL
             END AS APPLICATION_URL
        FROM TPA_SYSTEM_PARAMETERS;

  
    -- Get other core message info
    CURSOR cr_get_core_mesg_dtl(v_message_type_id VARCHAR2) IS
      SELECT module_name,
             msg_sent_from,
             message_title,
             send_as_email_yn,
             send_as_sms_yn,
             send_as_fax_yn,
             prm_rcpt_email_list,
             sec_rcpt_email_list,
             mail_cat_general_type_id,
             customization_allowed_yn
      
        FROM APP.SOURCE_MESSAGE A
       WHERE msg_id = v_message_type_id;

  
    CURSOR cr_get_regular_preauth(v_pat_gen_detail_seq_id pat_general_details.pat_gen_detail_seq_id%TYPE) IS
      SELECT b.pat_gen_detail_seq_id,
             a.policy_number,
             pr.product_name,
             a.pre_auth_number,
             a.claimant_name,
             gr.insured_name pol_holder_name,
             ttk_util_pkg.fn_decrypt(a.email_id) as pol_hold_email_id,
             hos.hosp_name,
             had.address_1 || ',' || had.address_2 || ',' || had.address_3 hos_address,
             aid.ailment_description,
             ag.agent_name,
             ttk_util_pkg.fn_decrypt(ag.email_id) agent_mail,
             b.pat_received_date,
             gen.description reason,
             b.app_sum_insured AS total_app_amount,
             ttk_util_pkg.num_to_words(b.total_app_amount) final_amt_words,
             b.pat_requested_amount,
             ttk_util_pkg.fn_decrypt(b.phone_no_in_hospitalisation) as claimant_phone,
             ag.mobile_id as agent_phone,
             (ppc.clause_number || ':' || ppc.clause_description) as clause_description
        FROM pat_enroll_details a
        join pat_general_details b
          on (a.pat_enroll_detail_seq_id = b.pat_enroll_detail_seq_id)
        join tpa_enr_policy_member mem
          on (mem.member_seq_id = a.member_seq_id)
        join tpa_enr_policy_group gr
          on (mem.policy_group_seq_id = gr.policy_group_seq_id)
        join tpa_enr_policy pol
          on (pol.policy_seq_id = a.policy_seq_id)
        left outer join TPA_HOSP_INFO hos
          on (a.hosp_seq_id = hos.hosp_seq_id)
        left outer join tpa_hosp_address had
          on (had.hosp_seq_id = hos.hosp_seq_id)
        left outer join tpa_ins_product pr
          on (pr.product_seq_id = pol.product_seq_id)
        left outer join ailment_details aid
          on (aid.pat_gen_detail_seq_id = b.pat_gen_detail_seq_id)
        left outer join tpa_rejection_clauses rc
          on (rc.pat_enroll_detail_seq_id = a.pat_enroll_detail_seq_id)
        left outer join tpa_prod_policy_clauses ppc
          on (ppc.clause_seq_id = rc.clause_seq_id)
        left outer join tpa_general_code gen
          on (gen.general_type_id = a.rson_general_type_id)
        left outer join tpa_ins_agent_details ag
          on (ag.policy_seq_id = pol.policy_seq_id)
       where b.pat_gen_detail_seq_id = v_pat_gen_detail_seq_id;

  
    cr_get_regular_preauth_rec cr_get_regular_preauth%rowtype;
  
    CURSOR cr_get_pat_intimate(v_pat_intimation_seq_id TPA_CALL_PAT_INTIMATION.pat_intimation_seq_id%TYPE) is
      SELECT distinct pi.pat_intimation_seq_id,
                      pol.policy_number,
                      pi.pat_intimation_id as pat_intimation_number,
                      pr.product_name,
                      mem.mem_name claimant_name,
                      gr.insured_name pol_holder_name,
                      ttk_util_pkg.fn_decrypt(pi.claimant_email_id) as pol_hold_email_id,
                      hos.hosp_name,
                      had.address_1 || ',' || had.address_2 || ',' ||
                      had.address_3 hos_address,
                      pi.ailment_description,
                      ag.agent_name,
                      ttk_util_pkg.fn_decrypt(ag.email_id) agent_mail,
                      pi.intimation_generated_date pat_reg_date,
                      ttk_util_pkg.fn_decrypt(pi.claimant_mobile_no) as claimant_phone,
                      ag.mobile_id as agent_phone
        FROM TPA_CALL_PAT_INTIMATION      pi,
             PAT_INTIMATION_HOSPITAL_LIST pih,
             tpa_enr_policy_member        mem,
             tpa_enr_policy_group         gr,
             tpa_enr_policy               pol,
             TPA_HOSP_INFO                hos,
             tpa_hosp_address             had,
             tpa_ins_product              pr,
             tpa_ins_agent_details        ag,
             TPA_CALL_PAT_INTIMATION      cp
       WHERE pi.member_seq_id = mem.member_seq_id
         and pi.pat_intimation_seq_id = pih.pat_intimation_seq_id(+)
         and gr.policy_group_seq_id = mem.policy_group_seq_id
         and cp.member_seq_id = mem.member_seq_id
         and pol.policy_seq_id = gr.policy_seq_id
         and hos.hosp_seq_id(+) = pih.hosp_seq_id
         and hos.hosp_seq_id = had.hosp_seq_id(+)
         and pol.product_seq_id = pr.product_seq_id
         and pol.policy_seq_id = ag.policy_seq_id(+)
         and pi.pat_intimation_seq_id = v_pat_intimation_seq_id;

  
    cr_get_pat_intimate_rec cr_get_pat_intimate%rowtype;
  
    --for shortfall preauths
    CURSOR cr_get_reg_pre_srtfall(v_shortfall_seq_id shortfall_details.shortfall_seq_id%TYPE) IS
      SELECT b.pat_gen_detail_seq_id,
             a.policy_number,
             pr.product_name,
             a.pre_auth_number,
             a.claimant_name,
             gr.insured_name pol_holder_name,
             ttk_util_pkg.fn_decrypt(a.email_id) as pol_hold_email_id,
             hos.hosp_name,
             had.address_1 || ',' || had.address_2 || ',' || had.address_3 hos_address,
             aid.ailment_description,
             ag.agent_name,
             ttk_util_pkg.fn_decrypt(ag.email_id) agent_mail,
             b.pat_received_date,
             gen.description reason,
             b.App_Sum_Insured AS total_app_amount,
             ttk_util_pkg.num_to_words(b.total_app_amount) final_amt_words,
             ttk_util_pkg.fn_decrypt(b.phone_no_in_hospitalisation) as claimant_phone,
             ag.mobile_id as agent_phone
        FROM pat_enroll_details    a,
             pat_general_details   b,
             tpa_enr_policy_member mem,
             tpa_enr_policy_group  gr,
             tpa_enr_policy        pol,
             TPA_HOSP_INFO         hos,
             tpa_hosp_address      had,
             tpa_ins_product       pr,
             ailment_details       aid,
             tpa_ins_agent_details ag,
             tpa_general_code      gen,
             shortfall_details     sh
       WHERE b.pat_enroll_detail_seq_id = a.pat_enroll_detail_seq_id
         and a.member_seq_id = mem.member_seq_id
         and gr.policy_group_seq_id = mem.policy_group_seq_id
         and pol.policy_seq_id = gr.policy_seq_id
         and hos.hosp_seq_id = a.hosp_seq_id(+)
         and hos.hosp_seq_id = had.hosp_seq_id(+)
         and aid.pat_gen_detail_seq_id = b.pat_gen_detail_seq_id
         and a.product_seq_id = pr.product_seq_id
         and a.policy_seq_id = ag.policy_seq_id(+)
         and a.rson_general_type_id = gen.general_type_id(+)
         and b.pat_gen_detail_seq_id = sh.pat_gen_detail_seq_id(+)
         and sh.shortfall_seq_id = v_shortfall_seq_id;

  
    cr_get_reg_pre_srtfall_rec cr_get_reg_pre_srtfall%rowtype;
  
    CURSOR cr_get_regular_claims(v_seq_id clm_general_details.claim_seq_id%TYPE) IS
      SELECT B.claim_seq_id,
             B.claim_number,
             a.rcvd_date,
             C.claimant_name,
             C.policy_number,
             pr.product_name,
             nvl(nvl(ci.clm_intimation_id, cl.call_log_number), '--') as clm_intimation_num,
             c.policy_holder_name pol_holder_name,
             ttk_util_pkg.fn_decrypt(C.email_id) as pol_hold_email_id,
             nvl(hos.hosp_name, ass.hosp_name) as hosp_name,
             nvl(had.address_1, ass.address_1) || ',' ||
             nvl(had.address_2, ass.address_2) || ',' ||
             nvl(had.address_3, ass.address_3) hos_address,
             aid.ailment_description,
             ag.agent_name,
             ttk_util_pkg.fn_decrypt(ag.email_id) agent_mail,
             gen.description reason,
             B.APP_SUM_INSURED AS total_app_amount,
             B.requested_amount,
             (B.requested_amount - B.total_app_amount) deduct_amount,
             ttk_util_pkg.num_to_words(B.total_app_amount) final_amt_words,
             ttk_util_pkg.fn_decrypt(C.notification_phone_number) as claimant_phone,
             ag.mobile_id as agent_phone,
             (ppc.clause_number || ':' || ppc.clause_description) as clause_description,
             C.decision_date,
             se.intl_shortfal_snt_date,
             se.rmdr_req_snt_date,
             se.clsr_notice_snt_date,
             au.remarks
        FROM clm_inward a
        JOIN clm_general_details b
          ON (A.CLAIMS_INWARD_SEQ_ID = B.CLAIMS_INWARD_SEQ_ID)
        JOIN clm_ENROLL_details c
          ON (C.CLAIM_SEQ_ID = B.CLAIM_SEQ_ID)
        JOIN ailment_details aid
          ON (AID.CLAIM_SEQ_ID = B.CLAIM_SEQ_ID)
        JOIN assign_users au
          ON (AU.CLAIM_SEQ_ID = B.CLAIM_SEQ_ID)
        JOIN clm_hospital_association ass
          ON (ASS.CLAIM_SEQ_ID = B.CLAIM_SEQ_ID)
        JOIN TPA_ENR_POLICY_MEMBER mem
          ON (MEM.MEMBER_SEQ_ID = C.MEMBER_SEQ_ID)
        left outer JOIN TPA_ENR_POLICY_GROUP grp
          ON (GRP.POLICY_GROUP_SEQ_ID = MEM.MEMBER_SEQ_ID)
        left outer JOIN tpa_enr_policy pol
          ON (pol.POLICY_SEQ_ID = c.POLICY_SEQ_ID)
        left outer JOIN tpa_ins_product pr
          ON (pr.PRODUCT_SEQ_ID = POL.PRODUCT_SEQ_ID)
        left outer JOIN TPA_HOSP_INFO hos
          ON (ASS.HOSP_SEQ_ID = HOS.HOSP_SEQ_ID)
        left outer JOIN tpa_hosp_address had
          ON (HAD.HOSP_SEQ_ID = HOS.HOSP_SEQ_ID)
        left outer JOIN shortfall_details sd
          ON (SD.CLAIM_SEQ_ID = B.CLAIM_SEQ_ID)
        left outer JOIN shortfall_email_dtl se
          ON (SE.SHORTFALL_SEQ_ID = SD.SHORTFALL_SEQ_ID)
        left outer JOIN tpa_rejection_clauses rc
          ON (RC.CLAIM_SEQ_ID = B.CLAIM_SEQ_ID)
        left outer JOIN tpa_prod_policy_clauses ppc
          ON (PPC.CLAUSE_SEQ_ID = RC.CLAUSE_SEQ_ID)
        left outer JOIN tpa_general_code gen
          ON (GEN.GENERAL_TYPE_ID = C.RSON_GENERAL_TYPE_ID)
      ----------
        LEFT OUTER JOIN TPA_CALL_LOG CL
          ON (CL.CALL_LOG_SEQ_ID = B.CALL_LOG_SEQ_ID)
        LEFT OUTER JOIN TPA_CALL_CLAIM_INTIMATION CI
          ON (CI.CALL_LOG_SEQ_ID = CL.CALL_LOG_SEQ_ID)
        left outer JOIN tpa_ins_agent_details ag
          ON (pol.POLICY_SEQ_ID = ag.POLICY_SEQ_ID)
       WHERE B.claim_seq_id = v_seq_id;

  
    cr_get_regular_claims_rec cr_get_regular_claims%rowtype;
  
    CURSOR cr_get_clm_fin(v_seq_id tpa_claims_payment.payment_seq_id%TYPE) IS
      SELECT c.claim_seq_id,
             c.claim_number,
             a.rcvd_date,
             b.claimant_name,
             NVL(C.CO_PAYMENT_AMOUNT, '0.00') AS CO_PAYMENT_AMOUNT,
             NVL(C.POLICY_DEDUCTABLE_AMT, '0.00') AS POLICY_DEDUCTABLE_AMT,
             b.policy_number,
             pr.product_name,
             nvl(nvl(ci.clm_intimation_id, cl.call_log_number), '--') as clm_intimation_num,
             b.policy_holder_name as pol_holder_name,
             ttk_util_pkg.fn_decrypt(b.email_id) as pol_hold_email_id,
             nvl(hos.hosp_name, ass.hosp_name) as hosp_name,
             nvl(had.address_1, ass.address_1) || ',' ||
             nvl(had.address_2, ass.address_2) || ',' ||
             nvl(had.address_3, ass.address_3) hos_address,
             aid.ailment_description,
             ag.agent_name,
             ttk_util_pkg.fn_decrypt(ag.email_id) agent_mail,
             gen.description reason,
             c.App_Sum_Insured AS total_app_amount,
             c.requested_amount,
             (c.requested_amount - c.total_app_amount) deduct_amount,
             ttk_util_pkg.num_to_words(c.total_app_amount) final_amt_words,
             b.claimant_phone_number as claimant_phone,
             ag.mobile_id as agent_phone,
             cc.check_num,
             cc.check_date
        FROM clm_inward a
        join clm_general_details c
          on (a.claims_inward_seq_id = c.claims_inward_seq_id)
        join clm_enroll_details b
          on (b.claim_seq_id = c.claim_seq_id)
        join clm_hospital_association ass
          on (ass.claim_seq_id = c.claim_seq_id)
        join TPA_ENR_POLICY_MEMBER mem
          on (mem.member_seq_id = b.member_seq_id)
        join tpa_enr_policy pol
          on (pol.policy_seq_id = b.policy_seq_id)
        left outer join TPA_HOSP_INFO hos
          on (ass.hosp_seq_id = hos.hosp_seq_id)
        left outer join tpa_hosp_address had
          on (hos.hosp_seq_id = had.hosp_seq_id)
        left outer join tpa_ins_product pr
          on (pol.product_seq_id = pr.product_seq_id)
        left outer join ailment_details aid
          on (aid.claim_seq_id = c.claim_seq_id)
        left outer join tpa_claims_payment cp
          on (cp.claim_seq_id = c.claim_seq_id)
        left outer join tpa_payment_checks_details pc
          on (pc.payment_seq_id = cp.payment_seq_id)
        left outer join tpa_claims_check cc
          on (cc.claims_chk_seq_id = pc.claims_chk_seq_id)
        left outer join tpa_general_code gen
          on (gen.general_type_id = b.rson_general_type_id)
      ----------
        LEFT OUTER JOIN TPA_CALL_LOG CL
          ON (CL.CALL_LOG_SEQ_ID = C.CALL_LOG_SEQ_ID)
        LEFT OUTER JOIN TPA_CALL_CLAIM_INTIMATION CI
          ON (CI.CALL_LOG_SEQ_ID = CL.CALL_LOG_SEQ_ID)
        left outer join tpa_ins_agent_details ag
          on (ag.policy_seq_id = pol.policy_seq_id)
       where cp.payment_seq_id = v_seq_id;

  
    cr_get_clm_fin_rec cr_get_clm_fin%rowtype;
  
    CURSOR cr_get_claim_intimate(v_call_log_seq_id tpa_call_log.call_log_seq_id%TYPE) IS
      SELECT ci.claim_intimation_seq_id,
             pol.policy_number,
             ci.clm_intimation_id as intimation_number,
             pr.product_name,
             cl.claimant_name claimant_name,
             pg.insured_name pol_holder_name,
             ttk_util_pkg.fn_decrypt(cl.primary_email_id) as pol_hold_email_id,
             ci.hospital_name, /*had.address_1||','||had.address_2||','||had.address_3*/
             ci.hospital_address hos_address,
             ci.ailment_description,
             ag.agent_name,
             ttk_util_pkg.fn_decrypt(ag.email_id) agent_mail,
             ci.intimation_generated_date clm_reg_date,
             ttk_util_pkg.fn_decrypt(cl.mobile_no) as claimant_phone,
             ag.mobile_id as agent_phone,
             cl.call_log_number
        FROM TPA_CALL_CLAIM_INTIMATION ci
        left outer join tpa_call_log cl
          on (ci.call_log_seq_id = cl.call_log_seq_id)
        join tpa_enr_policy_member pm
          on (pm.member_seq_id = cl.member_seq_id)
        join tpa_enr_policy_group pg
          on (pg.policy_group_seq_id = pm.policy_group_seq_id)
        left outer join tpa_enr_policy pol
          on (pol.policy_seq_id = pg.policy_seq_id)
        left outer join tpa_hosp_info hi
          on (hi.hosp_seq_id = cl.hosp_seq_id)
        left outer join tpa_hosp_address had
          on (had.hosp_seq_id = hi.hosp_seq_id)
        left outer join tpa_ins_product pr
          on (pr.product_seq_id = pol.product_seq_id)
        left outer join tpa_ins_agent_details ag
          on (ag.policy_seq_id = pol.policy_seq_id)
       where cl.call_log_seq_id = v_call_log_seq_id;

  
    cr_get_claim_intimate_rec cr_get_claim_intimate%rowtype;
  
    CURSOR CR_GET_CLM_BILL_HEADER(v_seq_id clm_general_details.claim_seq_id%TYPE) IS
      select substr(sys_connect_by_path(WARD_DESCRIPTION, '|'), 2) as Expense_Head
        from (SELECT WC.WARD_DESCRIPTION,
                     row_number() over(partition by 1 order by bd.clm_bill_dtl_seq_id) as row_num,
                     COUNT(1) OVER(PARTITION BY 1) AS cnt
                FROM CLM_GENERAL_DETAILS GD
                JOIN CLM_BILL_HEADER BH
                  ON (GD.CLAIM_SEQ_ID = BH.CLAIM_SEQ_ID)
                JOIN CLM_BILL_DETAILS BD
                  ON (BD.CLM_BILL_SEQ_ID = BH.CLM_BILL_SEQ_ID)
                JOIN TPA_HOSP_WARD_CODE WC
                  ON (WC.WARD_TYPE_ID = BD.WARD_TYPE_ID)
               WHERE BD.REJECTED_AMOUNT > 0
                 AND GD.CLAIM_SEQ_ID = v_seq_id)
       where row_num = cnt
       start with row_num = 1
      connect by prior row_num = row_num - 1;

  
    CURSOR CR_GET_CLM_BILL_AMOUNTS(v_seq_id clm_general_details.claim_seq_id%TYPE) IS
      select substr(sys_connect_by_path(Rejected_Amount, '|'), 2) as AMOUNTS
        from (SELECT BD.Rejected_Amount,
                     row_number() over(partition by 1 order by bd.clm_bill_dtl_seq_id) as row_num,
                     COUNT(1) OVER(PARTITION BY 1) AS cnt
                FROM CLM_GENERAL_DETAILS GD
                JOIN CLM_BILL_HEADER BH
                  ON (GD.CLAIM_SEQ_ID = BH.CLAIM_SEQ_ID)
                JOIN CLM_BILL_DETAILS BD
                  ON (BD.CLM_BILL_SEQ_ID = BH.CLM_BILL_SEQ_ID)
                JOIN TPA_HOSP_WARD_CODE WC
                  ON (WC.WARD_TYPE_ID = BD.WARD_TYPE_ID)
               WHERE BD.REJECTED_AMOUNT > 0
                 AND GD.CLAIM_SEQ_ID = v_seq_id)
       where row_num = cnt
       start with row_num = 1
      connect by prior row_num = row_num - 1;

  
    CURSOR CR_GET_CLM_BILL_REASONS(v_seq_id clm_general_details.claim_seq_id%TYPE) IS
      select substr(sys_connect_by_path(REMARKS, '|'), 2) as REASONS
        from (SELECT BD.REMARKS,
                     row_number() over(partition by 1 order by bd.clm_bill_dtl_seq_id) as row_num,
                     COUNT(1) OVER(PARTITION BY 1) AS cnt
                FROM CLM_GENERAL_DETAILS GD
                JOIN CLM_BILL_HEADER BH
                  ON (GD.CLAIM_SEQ_ID = BH.CLAIM_SEQ_ID)
                JOIN CLM_BILL_DETAILS BD
                  ON (BD.CLM_BILL_SEQ_ID = BH.CLM_BILL_SEQ_ID)
                JOIN TPA_HOSP_WARD_CODE WC
                  ON (WC.WARD_TYPE_ID = BD.WARD_TYPE_ID)
               WHERE BD.REJECTED_AMOUNT > 0
                 AND BD.REMARKS IS NOT NULL
                 AND GD.CLAIM_SEQ_ID = v_seq_id)
       where row_num = cnt
       start with row_num = 1
      connect by prior row_num = row_num - 1;

  
    V_CIGNA_SMS_YN     varchar2(1) := 'N';
    V_CLM_BILL_HEADERS varchar2(6000);
    V_CLM_BILL_AMOUNTS VARCHAR2(6000);
    V_CLM_BILL_REASONS VARCHAR2(6000);
    v_clm_int_number   varchar2(100);
    str_tab            ttk_util_pkg.str_table_type; --koc_ins_mail
    str_tab1           ttk_util_pkg.str_table_type; --koc_ins_mail
    str_tab2           ttk_util_pkg.str_table_type; --koc_ins_mail
    v_bill_reasons     varchar2(4000);
    v_bill_headers     varchar2(4000);
    v_bill_amounts     varchar2(4000);
    v_headers          varchar2(4000);
    v_reasons          varchar2(4000);
    v_amounts          varchar2(4000);
    V_CIGNA_MESAGE     CLOB;
  
    CURSOR cr_get_clm_srtfall(v_shortfall_seq_id shortfall_details.shortfall_seq_id%TYPE) IS
      SELECT b.claim_seq_id,
             a.policy_number,
             pr.product_name,
             b.claim_number,
             a.claimant_name,
             gr.insured_name pol_holder_name,
             ttk_util_pkg.fn_decrypt(a.email_id) as pol_hold_email_id,
             hos.hosp_name,
             had.address_1 || ',' || had.address_2 || ',' || had.address_3 hos_address,
             aid.ailment_description,
             ag.agent_name,
             ttk_util_pkg.fn_decrypt(ag.email_id) agent_mail,
             d.rcvd_date,
             gen.description reason,
             b.total_app_amount,
             ttk_util_pkg.num_to_words(b.total_app_amount) final_amt_words
        FROM clm_enroll_details       a,
             clm_general_details      b,
             clm_hospital_association c,
             clm_inward               d,
             tpa_enr_policy_member    mem,
             tpa_enr_policy_group     gr,
             tpa_enr_policy           pol,
             TPA_HOSP_INFO            hos,
             tpa_hosp_address         had,
             tpa_ins_product          pr,
             ailment_details          aid,
             tpa_ins_agent_details    ag,
             tpa_general_code         gen,
             shortfall_details        sh,
             shortfall_email_dtl      sed
       WHERE b.claim_seq_id = a.claim_seq_id
         and a.member_seq_id = mem.member_seq_id
         and gr.policy_group_seq_id = mem.policy_group_seq_id
         and pol.policy_seq_id = gr.policy_seq_id
         and b.claim_seq_id = c.claim_seq_id
         and b.claims_inward_seq_id = d.claims_inward_seq_id
         and hos.hosp_seq_id = c.hosp_seq_id(+)
         and hos.hosp_seq_id = had.hosp_seq_id(+)
         and aid.claim_seq_id = b.claim_seq_id
         and pol.product_seq_id = pr.product_seq_id
         and a.policy_seq_id = ag.policy_seq_id(+)
         and a.rson_general_type_id = gen.general_type_id(+)
         and b.claim_seq_id = sh.claim_seq_id(+)
         and sh.shortfall_seq_id = sed.shortfall_seq_id(+)
         and sh.shortfall_seq_id = v_shortfall_seq_id;

  
    cr_get_clm_srtfall_rec cr_get_clm_srtfall%rowtype;
  
  BEGIN
  
    -- This variable will indicate whether the message has to be logged into the Alert Table.
    -- If it is none, then no insertion, else depending CLAIMS, claim seq id would be updated.
    -- If pre-auth notifications, Pre-auth related id will be added.
    v_notification_type := 'NONE';
    v_enrollment_number := NULL;
    v_msg_type          := NULL;
  
    -- For the selected Event ID, decide how should the message be sent ?
    OPEN cr_get_core_mesg_dtl(v_message_type_id);
    FETCH cr_get_core_mesg_dtl
      INTO v_module_name,
           v_sent_from,
           v_msg_title,
           v_send_as_email_yn,
           v_send_as_sms_yn,
           v_send_as_fax_yn,
           v_prm_rcpt_list,
           v_sec_rcpt_list,
           v_mail_category,
           v_customise_allowed_YN;
    CLOSE cr_get_core_mesg_dtl;
  
    -- Verify whether mail should be sent or not. Is it customised mail or general mail.
    validate_process_mail_cigna(v_message_type_id,
                                v_parameters,
                                v_mail_category,
                                v_process_yn,
                                v_general_mail,
                                v_cc_mail,
                                v_group_name,
                                v_customise_allowed_YN);
  
    --          v_process_yn:='Y';
  
    IF (v_process_yn = 'Y') THEN
    
      IF v_message_type_id = 'CIGNA_PAT_INITIAL_APP_EMAIL_PO' THEN
        --1 ok
      
        OPEN cr_get_regular_preauth(v_parameters);
        FETCH cr_get_regular_preauth
          INTO cr_get_regular_preauth_rec;
        CLOSE cr_get_regular_preauth;
        ------ For Email Generation
        v_params(1) := cr_get_regular_preauth_rec.policy_number;
        v_params(2) := cr_get_regular_preauth_rec.product_name;
        v_params(3) := cr_get_regular_preauth_rec.pre_auth_number;
        v_params(4) := to_char(sysdate, 'DD/MM/YYYY');
        v_params(5) := cr_get_regular_preauth_rec.pol_holder_name;
        v_params(6) := cr_get_regular_preauth_rec.pre_auth_number;
        v_params(7) := to_char(cr_get_regular_preauth_rec.pat_received_date,
                               'DD/MM/YYYY');
        v_params(8) := cr_get_regular_preauth_rec.total_app_amount;
        v_params(9) := cr_get_regular_preauth_rec.claimant_name;
        v_params(10) := cr_get_regular_preauth_rec.hosp_name;
        v_params(11) := cr_get_regular_preauth_rec.hos_address;
        v_params(12) := cr_get_regular_preauth_rec.ailment_description;
      
        v_sms_phone := cr_get_regular_preauth_rec.claimant_phone;
        v_email_id  := cr_get_regular_preauth_rec.pol_hold_email_id;
      
        -- For SMS Generation
        v_SMS_params(1) := cr_get_regular_preauth_rec.pre_auth_number;
        v_SMS_params(2) := cr_get_regular_preauth_rec.total_app_amount;
      
      elsif v_message_type_id = 'CIGNA_PAT_INITIAL_APP_EMAIL_AD' THEN
        ---2 ok
      
        OPEN cr_get_regular_preauth(v_parameters);
        FETCH cr_get_regular_preauth
          INTO cr_get_regular_preauth_rec;
        CLOSE cr_get_regular_preauth;
      
        ------ For Email Generation
        v_params(1) := cr_get_regular_preauth_rec.policy_number;
        v_params(2) := cr_get_regular_preauth_rec.pol_holder_name;
        v_params(3) := cr_get_regular_preauth_rec.product_name;
        v_params(4) := cr_get_regular_preauth_rec.pre_auth_number;
        v_params(5) := to_char(sysdate, 'DD/MM/YYYY');
        v_params(6) := cr_get_regular_preauth_rec.agent_name;
        v_params(7) := cr_get_regular_preauth_rec.pol_holder_name;
        v_params(8) := cr_get_regular_preauth_rec.pre_auth_number;
        v_params(9) := to_char(cr_get_regular_preauth_rec.pat_received_date,
                               'DD/MM/YYYY');
        v_params(10) := cr_get_regular_preauth_rec.total_app_amount;
        v_params(11) := cr_get_regular_preauth_rec.claimant_name;
        v_params(12) := cr_get_regular_preauth_rec.hosp_name;
        v_params(13) := cr_get_regular_preauth_rec.hos_address;
      
        v_sms_phone := cr_get_regular_preauth_rec.agent_phone;
        v_email_id  := cr_get_regular_preauth_rec.agent_mail;
      
        -- For SMS Generation
        v_SMS_params(1) := cr_get_regular_preauth_rec.pre_auth_number;
        v_SMS_params(2) := cr_get_regular_preauth_rec.total_app_amount;
      
      elsif v_message_type_id = 'CIGNA_PAT_REQUEST_EMAIL_PO' THEN
        ---3 ok
      
        OPEN cr_get_regular_preauth(v_additional_param);
        FETCH cr_get_regular_preauth
          INTO cr_get_regular_preauth_rec;
        CLOSE cr_get_regular_preauth;
        ------ For Email Generation
        v_params(1) := cr_get_regular_preauth_rec.policy_number;
        v_params(2) := cr_get_regular_preauth_rec.product_name;
        v_params(3) := cr_get_regular_preauth_rec.pre_auth_number;
        v_params(4) := to_char(sysdate, 'DD/MM/YYYY');
        v_params(5) := cr_get_regular_preauth_rec.pol_holder_name;
        v_params(6) := nvl(to_char(cr_get_regular_preauth_rec.pat_received_date,
                                   'DD/MM/YYYY'),
                           'NA');
        v_params(7) := cr_get_regular_preauth_rec.pre_auth_number;
        v_params(8) := nvl(to_char(cr_get_regular_preauth_rec.pat_received_date,
                                   'DD/MM/YYYY'),
                           'NA');
        v_params(9) := cr_get_regular_preauth_rec.claimant_name;
        v_params(10) := cr_get_regular_preauth_rec.hosp_name;
        v_params(11) := cr_get_regular_preauth_rec.hos_address;
        v_params(12) := cr_get_regular_preauth_rec.pre_auth_number;
      
        v_sms_phone := cr_get_regular_preauth_rec.claimant_phone;
        v_email_id  := cr_get_regular_preauth_rec.pol_hold_email_id;
      
        -- For SMS Generation
      
        v_SMS_params(1) := cr_get_regular_preauth_rec.pre_auth_number;
      
      elsif v_message_type_id = 'CIGNA_PAT_REQUEST_EMAIL_AD' THEN
        ---4 ok
      
        OPEN cr_get_regular_preauth(v_additional_param);
        FETCH cr_get_regular_preauth
          INTO cr_get_regular_preauth_rec;
        CLOSE cr_get_regular_preauth;
      
        v_params(1) := cr_get_regular_preauth_rec.policy_number;
        v_params(2) := cr_get_regular_preauth_rec.pol_holder_name;
        v_params(3) := cr_get_regular_preauth_rec.product_name;
        v_params(4) := cr_get_regular_preauth_rec.pre_auth_number;
        v_params(5) := to_char(sysdate, 'DD/MM/YYYY');
        v_params(6) := nvl(cr_get_regular_preauth_rec.agent_name, 'NA');
        v_params(7) := cr_get_regular_preauth_rec.claimant_name;
        v_params(8) := nvl(to_char(cr_get_regular_preauth_rec.pat_received_date,
                                   'DD/MM/YYYY'),
                           'NA');
        v_params(9) := cr_get_regular_preauth_rec.pol_holder_name || '/' ||
                       cr_get_regular_preauth_rec.claimant_name;
        v_params(10) := cr_get_regular_preauth_rec.pre_auth_number;
        v_params(11) := nvl(to_char(cr_get_regular_preauth_rec.pat_received_date,
                                    'DD/MM/YYYY'),
                            'NA');
        v_params(12) := cr_get_regular_preauth_rec.claimant_name;
        v_params(13) := cr_get_regular_preauth_rec.hosp_name;
        v_params(14) := cr_get_regular_preauth_rec.hos_address;
        v_params(15) := cr_get_regular_preauth_rec.pre_auth_number;
      
        v_sms_phone := cr_get_regular_preauth_rec.agent_phone;
        v_email_id  := cr_get_regular_preauth_rec.agent_mail;
      
        -- For SMS Generation
        v_SMS_params(1) := cr_get_regular_preauth_rec.pre_auth_number;
        v_SMS_params(2) := cr_get_regular_preauth_rec.claimant_name;
      
      elsif v_message_type_id = 'CIGNA_PAT_REJECT_EMAIL_PO' THEN
        ---5 ok
      
        OPEN cr_get_regular_preauth(v_parameters);
        FETCH cr_get_regular_preauth
          INTO cr_get_regular_preauth_rec;
        CLOSE cr_get_regular_preauth;
      
        v_params(1) := cr_get_regular_preauth_rec.policy_number;
        v_params(2) := cr_get_regular_preauth_rec.product_name;
        v_params(3) := cr_get_regular_preauth_rec.pre_auth_number;
        v_params(4) := to_char(sysdate, 'DD/MM/YYYY');
        v_params(5) := cr_get_regular_preauth_rec.pol_holder_name;
        v_params(6) := cr_get_regular_preauth_rec.claimant_name;
        v_params(7) := cr_get_regular_preauth_rec.pre_auth_number;
        v_params(8) := to_char(cr_get_regular_preauth_rec.pat_received_date,
                               'DD/MM/YYYY');
        v_params(9) := cr_get_regular_preauth_rec.hosp_name;
        v_params(10) := cr_get_regular_preauth_rec.ailment_description;
        v_params(11) := cr_get_regular_preauth_rec.clause_description;
      
        v_sms_phone := cr_get_regular_preauth_rec.claimant_phone;
        v_email_id  := cr_get_regular_preauth_rec.pol_hold_email_id;
      
        -- For SMS Generation
        v_SMS_params(1) := cr_get_regular_preauth_rec.pre_auth_number;
      
      elsif v_message_type_id = 'CIGNA_PAT_REJECT_EMAIL_AD' THEN
        ---6 ok
      
        OPEN cr_get_regular_preauth(v_parameters);
        FETCH cr_get_regular_preauth
          INTO cr_get_regular_preauth_rec;
        CLOSE cr_get_regular_preauth;
      
        v_params(1) := cr_get_regular_preauth_rec.policy_number;
        v_params(2) := cr_get_regular_preauth_rec.pol_holder_name;
        v_params(3) := cr_get_regular_preauth_rec.product_name;
        v_params(4) := cr_get_regular_preauth_rec.pre_auth_number;
        v_params(5) := to_char(sysdate, 'DD/MM/YYYY');
        v_params(6) := cr_get_regular_preauth_rec.agent_name;
        v_params(7) := cr_get_regular_preauth_rec.claimant_name;
        v_params(8) := cr_get_regular_preauth_rec.pre_auth_number;
        v_params(9) := to_char(cr_get_regular_preauth_rec.pat_received_date,
                               'DD/MM/YYYY');
        v_params(10) := cr_get_regular_preauth_rec.hosp_name;
        v_params(11) := cr_get_regular_preauth_rec.pol_holder_name || '/' ||
                        cr_get_regular_preauth_rec.claimant_name;
      
        v_sms_phone := cr_get_regular_preauth_rec.agent_phone;
        v_email_id  := cr_get_regular_preauth_rec.agent_mail;
      
        -- For SMS Generation
        v_SMS_params(1) := cr_get_regular_preauth_rec.pre_auth_number;
      
      elsif v_message_type_id = 'CIGNA_PAT_FINAL_APP_EMAIL_PO' THEN
        ---7 ok
      
        OPEN cr_get_regular_preauth(v_parameters);
        FETCH cr_get_regular_preauth
          INTO cr_get_regular_preauth_rec;
        CLOSE cr_get_regular_preauth;
      
        v_params(1) := cr_get_regular_preauth_rec.policy_number;
        v_params(2) := cr_get_regular_preauth_rec.product_name;
        v_params(3) := cr_get_regular_preauth_rec.pre_auth_number;
        v_params(4) := to_char(sysdate, 'DD/MM/YYYY');
        v_params(5) := cr_get_regular_preauth_rec.pol_holder_name;
        v_params(6) := cr_get_regular_preauth_rec.pre_auth_number;
        v_params(7) := cr_get_regular_preauth_rec.total_app_amount || '(' ||
                       cr_get_regular_preauth_rec.final_amt_words || ')';
        v_params(8) := cr_get_regular_preauth_rec.claimant_name;
        v_params(9) := cr_get_regular_preauth_rec.hosp_name;
        v_params(10) := cr_get_regular_preauth_rec.hos_address;
        v_params(11) := cr_get_regular_preauth_rec.ailment_description;
        v_params(12) := cr_get_regular_preauth_rec.pat_requested_amount;
        v_params(13) := cr_get_regular_preauth_rec.total_app_amount;
      
        v_sms_phone := cr_get_regular_preauth_rec.claimant_phone;
        v_email_id  := cr_get_regular_preauth_rec.pol_hold_email_id;
      
        -- For SMS Generation
        v_SMS_params(1) := cr_get_regular_preauth_rec.pre_auth_number;
        v_SMS_params(2) := cr_get_regular_preauth_rec.total_app_amount;
      
      elsif v_message_type_id = 'CIGNA_PAT_FINAL_APP_EMAIL_AD' THEN
        ----8 ok
      
        OPEN cr_get_regular_preauth(v_parameters);
        FETCH cr_get_regular_preauth
          INTO cr_get_regular_preauth_rec;
        CLOSE cr_get_regular_preauth;
      
        v_params(1) := cr_get_regular_preauth_rec.policy_number;
        v_params(2) := cr_get_regular_preauth_rec.pol_holder_name;
        v_params(3) := cr_get_regular_preauth_rec.product_name;
        v_params(4) := cr_get_regular_preauth_rec.pre_auth_number;
        v_params(5) := to_char(sysdate, 'DD/MM/YYYY');
        v_params(6) := cr_get_regular_preauth_rec.agent_name;
        v_params(7) := cr_get_regular_preauth_rec.pre_auth_number;
        v_params(8) := cr_get_regular_preauth_rec.pol_holder_name;
        v_params(9) := to_char(cr_get_regular_preauth_rec.pat_received_date,
                               'DD/MM/YYYY');
        v_params(10) := cr_get_regular_preauth_rec.total_app_amount || '(' ||
                        cr_get_regular_preauth_rec.final_amt_words || ')';
        v_params(11) := cr_get_regular_preauth_rec.claimant_name;
        v_params(12) := cr_get_regular_preauth_rec.hosp_name;
        v_params(13) := cr_get_regular_preauth_rec.hos_address;
      
        v_sms_phone := cr_get_regular_preauth_rec.agent_phone;
        v_email_id  := cr_get_regular_preauth_rec.agent_mail;
      
        -- For SMS Generation
        v_SMS_params(1) := cr_get_regular_preauth_rec.pre_auth_number;
        v_SMS_params(2) := cr_get_regular_preauth_rec.total_app_amount;
      
      elsif v_message_type_id in
            ('CIGNA_PAT_SHFALL_REM1_EMAIL_PO',
             'CIGNA_PAT_SHFALL_FNL_EMAIL_PO',
             'CIGNA_PAT_SHFALL_FRST_EMAIL_PO') THEN
      
        OPEN cr_get_regular_preauth(v_additional_param);
        FETCH cr_get_regular_preauth
          INTO cr_get_regular_preauth_rec;
        CLOSE cr_get_regular_preauth;
      
        for rec in (select rownum, cname
                      from (SELECT extractValue(value(des),
                                                '/query/@postlabel') AS cname
                              FROM (SELECT sh.shortfall_questions
                                      FROM pat_enroll_details  a,
                                           pat_general_details b,
                                           shortfall_details   sh
                                     WHERE b.pat_enroll_detail_seq_id =
                                           a.pat_enroll_detail_seq_id
                                       and b.pat_gen_detail_seq_id =
                                           sh.pat_gen_detail_seq_id(+)
                                       and sh.shortfall_seq_id = v_parameters) p,
                                   TABLE(XMLSequence(extract(p.shortfall_questions,
                                                             '/shortfall/section/subsection/query[@value="YES"]'))) des
                            union all
                            SELECT extractValue(value(des), '/query/@value') AS cname
                              FROM (SELECT sh.shortfall_questions
                                      FROM pat_enroll_details  a,
                                           pat_general_details b,
                                           shortfall_details   sh
                                     WHERE b.pat_enroll_detail_seq_id =
                                           a.pat_enroll_detail_seq_id
                                       and b.pat_gen_detail_seq_id =
                                           sh.pat_gen_detail_seq_id(+)
                                       and sh.shortfall_seq_id = v_parameters) p,
                                   TABLE(XMLSequence(extract(p.shortfall_questions,
                                                             '/shortfall/section/subsection/query[@type="text"]'))) des)
                     where cname is not null) loop
          v_shrtfall_que := v_shrtfall_que || '<li>' || rec.cname || '</li>
      ';
        end loop;

      
        v_shrtfall_que := '<ol>' || v_shrtfall_que || '</ol>';
      
        v_params(1) := cr_get_regular_preauth_rec.policy_number;
        v_params(2) := cr_get_regular_preauth_rec.product_name;
        v_params(3) := cr_get_regular_preauth_rec.pre_auth_number;
        v_params(4) := to_char(sysdate, 'DD/MM/YYYY');
        v_params(5) := cr_get_regular_preauth_rec.pol_holder_name;
        v_params(6) := cr_get_regular_preauth_rec.pre_auth_number;
      
        if v_message_type_id in
           ('CIGNA_PAT_SHFALL_REM1_EMAIL_PO',
            'CIGNA_PAT_SHFALL_FRST_EMAIL_PO') then
        
          v_params(7) := to_char(cr_get_regular_preauth_rec.pat_received_date,
                                 'DD/MM/YYYY');
          v_params(8) := cr_get_regular_preauth_rec.pre_auth_number;
          v_params(9) := cr_get_regular_preauth_rec.claimant_name;
          v_params(10) := cr_get_regular_preauth_rec.hosp_name;
          v_params(11) := cr_get_regular_preauth_rec.hos_address;
          v_params(12) := cr_get_regular_preauth_rec.ailment_description;
          v_params(13) := v_shrtfall_que;
        else
          --CIGNA_PAT_SHFALL_FRST_EMAIL_PO
          v_params(7) := cr_get_regular_preauth_rec.pre_auth_number;
          v_params(8) := cr_get_regular_preauth_rec.claimant_name;
          v_params(9) := cr_get_regular_preauth_rec.hosp_name;
          v_params(10) := cr_get_regular_preauth_rec.hos_address;
          v_params(11) := cr_get_regular_preauth_rec.ailment_description;
          v_params(12) := v_shrtfall_que;

        end if;

      
        v_sms_phone := cr_get_regular_preauth_rec.claimant_phone;
        v_email_id  := cr_get_regular_preauth_rec.pol_hold_email_id;
      
        -- For SMS Generation
        v_SMS_params(1) := cr_get_regular_preauth_rec.pre_auth_number;
      
      elsif v_message_type_id in
            ('CIGNA_PAT_SHFALL_REM1_EMAIL_AD',
             'CIGNA_PAT_SHFALL_FNL_EMAIL_AD',
             'CIGNA_PAT_SHFALL_FRST_EMAIL_AD') THEN
      
        OPEN cr_get_regular_preauth(v_additional_param);
        FETCH cr_get_regular_preauth
          INTO cr_get_regular_preauth_rec;
        CLOSE cr_get_regular_preauth;
      
        for rec in (select rownum, cname
                      from (SELECT extractValue(value(des),
                                                '/query/@postlabel') AS cname
                              FROM (SELECT sh.shortfall_questions
                                      FROM pat_enroll_details  a,
                                           pat_general_details b,
                                           shortfall_details   sh
                                     WHERE b.pat_enroll_detail_seq_id =
                                           a.pat_enroll_detail_seq_id
                                       and b.pat_gen_detail_seq_id =
                                           sh.pat_gen_detail_seq_id(+)
                                       and sh.shortfall_seq_id = v_parameters) p,
                                   TABLE(XMLSequence(extract(p.shortfall_questions,
                                                             '/shortfall/section/subsection/query[@value="YES"]'))) des
                            union all
                            SELECT extractValue(value(des), '/query/@value') AS cname
                              FROM (SELECT sh.shortfall_questions
                                      FROM pat_enroll_details  a,
                                           pat_general_details b,
                                           shortfall_details   sh
                                     WHERE b.pat_enroll_detail_seq_id =
                                           a.pat_enroll_detail_seq_id
                                       and b.pat_gen_detail_seq_id =
                                           sh.pat_gen_detail_seq_id(+)
                                       and sh.shortfall_seq_id = v_parameters) p,
                                   TABLE(XMLSequence(extract(p.shortfall_questions,
                                                             '/shortfall/section/subsection/query[@type="text"]'))) des)
                     where cname is not null) loop
          v_shrtfall_que := v_shrtfall_que || '<li>' || rec.cname || '</li>
      ';
        end loop;

      
        v_shrtfall_que := '<ol>' || v_shrtfall_que || '</ol>';
      
        v_params(1) := cr_get_regular_preauth_rec.policy_number;
        v_params(2) := cr_get_regular_preauth_rec.pol_holder_name;
        v_params(3) := cr_get_regular_preauth_rec.product_name;
        v_params(4) := cr_get_regular_preauth_rec.pre_auth_number;
        v_params(5) := to_char(sysdate, 'DD/MM/YYYY');
        v_params(6) := cr_get_regular_preauth_rec.agent_name;
        v_params(7) := cr_get_regular_preauth_rec.pol_holder_name;
      
        if v_message_type_id in
           ('CIGNA_PAT_SHFALL_REM1_EMAIL_AD',
            'CIGNA_PAT_SHFALL_FNL_EMAIL_AD') then
        
          v_params(8) := cr_get_regular_preauth_rec.pre_auth_number;
          v_params(9) := cr_get_regular_preauth_rec.claimant_name;
          v_params(10) := cr_get_regular_preauth_rec.hosp_name;
          v_params(11) := cr_get_regular_preauth_rec.hos_address;
          v_params(12) := cr_get_regular_preauth_rec.ailment_description;
          v_params(13) := v_shrtfall_que;
        
        else
          --CIGNA_PAT_SHFALL_FRST_EMAIL_AD
          v_params(8) := to_char(cr_get_regular_preauth_rec.pat_received_date,
                                 'DD/MM/YYYY');
          v_params(9) := cr_get_regular_preauth_rec.pre_auth_number;
          v_params(10) := cr_get_regular_preauth_rec.pre_auth_number;
          v_params(11) := cr_get_regular_preauth_rec.claimant_name;
          v_params(12) := cr_get_regular_preauth_rec.hosp_name;
          v_params(13) := cr_get_regular_preauth_rec.hos_address;
          v_params(14) := cr_get_regular_preauth_rec.ailment_description;
          v_params(15) := v_shrtfall_que;
        
        end if;

        v_sms_phone := cr_get_regular_preauth_rec.agent_phone;
        v_email_id  := cr_get_regular_preauth_rec.agent_mail;
        -- For SMS Generation
        v_SMS_params(1) := cr_get_regular_preauth_rec.pre_auth_number;
         
      ELSIF v_message_type_id = 'CIGNA_CLM_REGIS_EMAIL_PO' THEN
        --1 ok
      
        OPEN cr_get_claim_intimate(v_additional_param);
        FETCH cr_get_claim_intimate
          INTO cr_get_claim_intimate_rec;
        CLOSE cr_get_claim_intimate;
      
        if cr_get_claim_intimate_rec.intimation_number is null then
          v_clm_int_number := cr_get_claim_intimate_rec.call_log_number;
        else
          v_clm_int_number := cr_get_claim_intimate_rec.intimation_number;

        end if;

        v_params(1) := cr_get_claim_intimate_rec.policy_number;
        v_params(2) := cr_get_claim_intimate_rec.product_name;
        v_params(3) := v_clm_int_number; --cr_get_claim_intimate_rec.intimation_number;
        v_params(4) := to_char(sysdate, 'DD/MM/YYYY');
        v_params(5) := cr_get_claim_intimate_rec.pol_holder_name;
        v_params(6) := to_char(cr_get_claim_intimate_rec.clm_reg_date,
                               'DD/MM/YYYY');
        v_params(7) := v_clm_int_number; --cr_get_claim_intimate_rec.intimation_number;
        v_params(8) := to_char(cr_get_claim_intimate_rec.clm_reg_date,
                               'DD/MM/YYYY');
        v_params(9) := cr_get_claim_intimate_rec.claimant_name;
        v_params(10) := cr_get_claim_intimate_rec.hospital_name;
        v_params(11) := cr_get_claim_intimate_rec.hos_address;
        v_params(12) := v_clm_int_number; --cr_get_claim_intimate_rec.intimation_number;
      
        v_sms_phone := cr_get_claim_intimate_rec.claimant_phone;
        v_email_id  := cr_get_claim_intimate_rec.pol_hold_email_id;
      
        -- For SMS Generation
        v_SMS_params(1) := v_clm_int_number; --cr_get_claim_intimate_rec.intimation_number;

      
      ELSIF v_message_type_id = 'CIGNA_CLM_REGIS_EMAIL_AD' THEN
        --2 ok
      
        OPEN cr_get_claim_intimate(v_additional_param);
        FETCH cr_get_claim_intimate
          INTO cr_get_claim_intimate_rec;
        CLOSE cr_get_claim_intimate;
      
        if cr_get_claim_intimate_rec.intimation_number is null then
          v_clm_int_number := cr_get_claim_intimate_rec.call_log_number;
        else
          v_clm_int_number := cr_get_claim_intimate_rec.intimation_number;

        end if;

      
        v_params(1) := cr_get_claim_intimate_rec.policy_number;
        v_params(2) := cr_get_claim_intimate_rec.pol_holder_name;
        v_params(3) := cr_get_claim_intimate_rec.product_name;
        v_params(4) := v_clm_int_number; --cr_get_claim_intimate_rec.intimation_number;
        v_params(5) := to_char(sysdate, 'DD/MM/YYYY');
        v_params(6) := nvl(cr_get_claim_intimate_rec.agent_name, 'NA');
        v_params(7) := cr_get_claim_intimate_rec.claimant_name;
        v_params(8) := NVL(to_char(cr_get_claim_intimate_rec.clm_reg_date,
                                   'DD/MM/YYYY'),
                           'NA');
        v_params(9) := cr_get_claim_intimate_rec.pol_holder_name;
        v_params(10) := v_clm_int_number; --cr_get_claim_intimate_rec.intimation_number;
        v_params(11) := to_char(cr_get_claim_intimate_rec.clm_reg_date,
                                'DD/MM/YYYY');
        v_params(12) := cr_get_claim_intimate_rec.claimant_name;
        v_params(13) := cr_get_claim_intimate_rec.hospital_name;
        v_params(14) := cr_get_claim_intimate_rec.hos_address;
        v_params(15) := v_clm_int_number; --cr_get_claim_intimate_rec.intimation_number;
      
        v_sms_phone := cr_get_claim_intimate_rec.agent_phone;
        v_email_id  := cr_get_claim_intimate_rec.agent_mail;
      
        -- For SMS Generation
        v_SMS_params(1) := v_clm_int_number; --cr_get_claim_intimate_rec.intimation_number;
        v_SMS_params(2) := cr_get_claim_intimate_rec.claimant_name;
      
      elsif v_message_type_id in
            ('CIGNA_CLM_DOC_SHFALL_EMAIL_PO',
             'CIGNA_CLM_SHFALL_REM1_EMAIL_PO',
             'CIGNA_CLM_SHFALL_REM2_EMAIL_PO') THEN
      
        OPEN cr_get_regular_claims(v_additional_param);
        FETCH cr_get_regular_claims
          INTO cr_get_regular_claims_rec;
        CLOSE cr_get_regular_claims;
      
        for rec in (select rownum, cname
                      from (SELECT extractValue(value(des),
                                                '/query/@postlabel') AS cname
                              FROM (SELECT sh.shortfall_questions
                                      FROM clm_enroll_details  a,
                                           clm_general_details b,
                                           shortfall_details   sh
                                     WHERE b.claim_seq_id = a.claim_seq_id
                                       and b.claim_seq_id = sh.claim_seq_id(+)
                                       and sh.shortfall_seq_id = v_parameters) p,
                                   TABLE(XMLSequence(extract(p.shortfall_questions,
                                                             '/shortfall/section/subsection/query[@value="YES"]'))) des
                            union all
                            SELECT extractValue(value(des), '/query/@value') AS cname
                              FROM (SELECT sh.shortfall_questions
                                      FROM clm_enroll_details  a,
                                           clm_general_details b,
                                           shortfall_details   sh
                                     WHERE b.claim_seq_id = a.claim_seq_id
                                       and b.claim_seq_id = sh.claim_seq_id(+)
                                       and sh.shortfall_seq_id = v_parameters) p,
                                   TABLE(XMLSequence(extract(p.shortfall_questions,
                                                             '/shortfall/section/subsection/query[@type="text"]'))) des)
                     where cname is not null) loop
          v_shrtfall_que := v_shrtfall_que || '<li>' || rec.cname ||
                            '</li>
       ';
        end loop;

      
        v_shrtfall_que := '<ol>' || v_shrtfall_que || '</ol>';
      
        v_params(1) := cr_get_regular_claims_rec.policy_number;
        v_params(2) := cr_get_regular_claims_rec.product_name;
        v_params(3) := cr_get_regular_claims_rec.claim_number;
        v_params(4) := to_char(sysdate, 'DD/MM/YYYY');
        v_params(5) := cr_get_regular_claims_rec.pol_holder_name;
        v_params(6) := cr_get_regular_claims_rec.claim_number;
      
        if v_message_type_id in
           ('CIGNA_CLM_SHFALL_REM1_EMAIL_PO',
            'CIGNA_CLM_SHFALL_REM2_EMAIL_PO') then
        
          v_params(7) := to_char(cr_get_regular_claims_rec.rcvd_date,
                                 'DD/MM/YYYY');
          v_params(8) := cr_get_regular_claims_rec.claim_number;
          v_params(9) := cr_get_regular_claims_rec.claimant_name;
          v_params(10) := cr_get_regular_claims_rec.hosp_name;
          v_params(11) := cr_get_regular_claims_rec.hos_address;
          v_params(12) := cr_get_regular_claims_rec.ailment_description;
          v_params(13) := v_shrtfall_que;
        else
          --CIGNA_CLM_DOC_SHFALL_EMAIL_PO
          v_params(7) := to_char(cr_get_regular_claims_rec.rcvd_date,
                                 'DD/MM/YYYY');
          v_params(8) := cr_get_regular_claims_rec.claim_number;
          v_params(9) := cr_get_regular_claims_rec.claimant_name;
          v_params(10) := cr_get_regular_claims_rec.hosp_name;
          v_params(11) := cr_get_regular_claims_rec.hos_address;
          v_params(12) := cr_get_regular_claims_rec.ailment_description;
          v_params(13) := v_shrtfall_que;

        end if;

      
        v_sms_phone := cr_get_regular_claims_rec.claimant_phone;
        v_email_id  := cr_get_regular_claims_rec.pol_hold_email_id;
      
        -- For SMS Generation
        v_SMS_params(1) := cr_get_regular_claims_rec.claim_number;
      
      elsif v_message_type_id in
            ('CIGNA_CLM_DOC_SHFALL_EMAIL_AD',
             'CIGNA_CLM_SHFALL_REM1_EMAIL_AD',
             'CIGNA_CLM_SHFALL_REM2_EMAIL_AD') THEN
      
        OPEN cr_get_regular_claims(v_additional_param);
        FETCH cr_get_regular_claims
          INTO cr_get_regular_claims_rec;
        CLOSE cr_get_regular_claims;
      
        for rec in (select rownum, cname
                      from (SELECT extractValue(value(des),
                                                '/query/@postlabel') AS cname
                              FROM (SELECT sh.shortfall_questions
                                      FROM clm_enroll_details  a,
                                           clm_general_details b,
                                           shortfall_details   sh
                                     WHERE b.claim_seq_id = a.claim_seq_id
                                       and b.claim_seq_id = sh.claim_seq_id(+)
                                       and sh.shortfall_seq_id = v_parameters) p,
                                   TABLE(XMLSequence(extract(p.shortfall_questions,
                                                             '/shortfall/section/subsection/query[@value="YES"]'))) des
                            union all
                            SELECT extractValue(value(des), '/query/@value') AS cname
                              FROM (SELECT sh.shortfall_questions
                                      FROM clm_enroll_details  a,
                                           clm_general_details b,
                                           shortfall_details   sh
                                     WHERE b.claim_seq_id = a.claim_seq_id
                                       and b.claim_seq_id = sh.claim_seq_id(+)
                                       and sh.shortfall_seq_id = v_parameters) p,
                                   TABLE(XMLSequence(extract(p.shortfall_questions,
                                                             '/shortfall/section/subsection/query[@type="text"]'))) des)
                     where cname is not null) loop
          v_shrtfall_que := v_shrtfall_que || '<li>' || rec.cname || '</li>
      ';
        end loop;

      
        v_shrtfall_que := '<ol>' || v_shrtfall_que || '</ol>';
      
        v_params(1) := cr_get_regular_claims_rec.policy_number;
        v_params(2) := cr_get_regular_claims_rec.pol_holder_name;
        v_params(3) := cr_get_regular_claims_rec.product_name;
        v_params(4) := cr_get_regular_claims_rec.claim_number;
        v_params(5) := to_char(sysdate, 'DD/MM/YYYY');
        v_params(6) := cr_get_regular_claims_rec.agent_name;
        v_params(7) := cr_get_regular_claims_rec.pol_holder_name;
      
        if v_message_type_id in
           ('CIGNA_CLM_SHFALL_REM1_EMAIL_AD',
            'CIGNA_CLM_SHFALL_REM2_EMAIL_AD') then
        
          v_params(8) := to_char(cr_get_regular_claims_rec.rcvd_date,
                                 'DD/MM/YYYY');
          v_params(9) := cr_get_regular_claims_rec.claim_number;
          v_params(10) := cr_get_regular_claims_rec.claimant_name;
          v_params(11) := cr_get_regular_claims_rec.hosp_name;
          v_params(12) := cr_get_regular_claims_rec.hos_address;
          v_params(13) := v_shrtfall_que;
        
        else
          --CIGNA_CLM_DOC_SHFALL_EMAIL_AD
          v_params(8) := to_char(cr_get_regular_claims_rec.rcvd_date,
                                 'DD/MM/YYYY');
          v_params(9) := cr_get_regular_claims_rec.claim_number;
          v_params(10) := cr_get_regular_claims_rec.claim_number;
          v_params(11) := cr_get_regular_claims_rec.claimant_name;
          v_params(12) := cr_get_regular_claims_rec.hosp_name;
          v_params(13) := cr_get_regular_claims_rec.hos_address;
        
        end if;

        v_sms_phone := cr_get_regular_claims_rec.agent_phone;
        v_email_id  := cr_get_regular_claims_rec.agent_mail;
        -- For SMS Generation
        v_SMS_params(1) := cr_get_regular_claims_rec.claim_number;
      
      ELSIF v_message_type_id = 'CIGNA_CLM_SETTLE_EMAIL_AD' THEN
        --3 ok
      
        OPEN cr_get_clm_fin(v_parameters);
        FETCH cr_get_clm_fin
          INTO cr_get_clm_fin_rec;
        CLOSE cr_get_clm_fin;
        /*
        OPEN CR_GET_CLM_BILL_DTLS( v_parameters );
        FETCH CR_GET_CLM_BILL_DTLS INTO cr_get_clm_bil_rec;
        CLOSE CR_GET_CLM_BILL_DTLS;*/

      
        v_params(1) := cr_get_clm_fin_rec.policy_number;
        v_params(2) := cr_get_clm_fin_rec.pol_holder_name;
        v_params(3) := cr_get_clm_fin_rec.product_name;
        v_params(4) := cr_get_clm_fin_rec.claim_number;
        v_params(5) := cr_get_clm_fin_rec.clm_intimation_num;
        v_params(6) := to_char(sysdate, 'DD/MM/YYYY');
        v_params(7) := cr_get_clm_fin_rec.agent_name;
        v_params(8) := to_char(cr_get_clm_fin_rec.rcvd_date, 'DD/MM/YYYY');
        v_params(9) := cr_get_clm_fin_rec.claimant_name;
        v_params(10) := cr_get_clm_fin_rec.claim_number;
        v_params(11) := cr_get_clm_fin_rec.claimant_name;
        v_params(12) := cr_get_clm_fin_rec.hosp_name;
        v_params(13) := cr_get_clm_fin_rec.hos_address;
        v_params(14) := cr_get_clm_fin_rec.requested_amount;
        v_params(15) := cr_get_clm_fin_rec.total_app_amount || '(' ||
                        cr_get_clm_fin_rec.final_amt_words || ')';
      
        v_sms_phone := cr_get_clm_fin_rec.agent_phone;
        v_email_id  := cr_get_clm_fin_rec.agent_mail;
      
        -- For SMS Generation
        v_SMS_params(1) := cr_get_clm_fin_rec.claim_number;
        v_SMS_params(2) := cr_get_clm_fin_rec.total_app_amount;
        v_SMS_params(3) := to_char(cr_get_clm_fin_rec.check_date,
                                   'DD/MM/YYYY');
      
      ELSIF v_message_type_id = 'CIGNA_CLM_SETTLE_EMAIL_PO' THEN
        --4
      
        OPEN cr_get_clm_fin(v_parameters);
        FETCH cr_get_clm_fin
          INTO cr_get_clm_fin_rec;
        CLOSE cr_get_clm_fin;
      
        OPEN CR_GET_CLM_BILL_HEADER(cr_get_clm_fin_rec.claim_seq_id);
        FETCH CR_GET_CLM_BILL_HEADER
          INTO V_CLM_BILL_HEADERS;
        CLOSE CR_GET_CLM_BILL_HEADER;
      
        OPEN CR_GET_CLM_BILL_AMOUNTS(cr_get_clm_fin_rec.claim_seq_id);
        FETCH CR_GET_CLM_BILL_AMOUNTS
          INTO V_CLM_BILL_AMOUNTS;
        CLOSE CR_GET_CLM_BILL_AMOUNTS;
      
        OPEN CR_GET_CLM_BILL_REASONS(cr_get_clm_fin_rec.claim_seq_id);
        FETCH CR_GET_CLM_BILL_REASONS
          INTO V_CLM_BILL_REASONS;
        CLOSE CR_GET_CLM_BILL_REASONS;
      
        IF instr(V_CLM_BILL_HEADERS, '|') > 0 THEN
          v_headers := ('|' || V_CLM_BILL_HEADERS || '|');
          str_tab   := ttk_util_pkg.parse_str(v_headers);
        ELSE
          str_tab(1) := V_CLM_BILL_HEADERS;

        END IF;

        IF instr(V_CLM_BILL_AMOUNTS, '|') > 0 THEN
          v_amounts := ('|' || V_CLM_BILL_AMOUNTS || '|');
          str_tab1  := ttk_util_pkg.parse_str(v_amounts);
        ELSE
          str_tab1(1) := V_CLM_BILL_AMOUNTS;

        END IF;

        IF instr(V_CLM_BILL_REASONS, '|') > 0 THEN
          v_reasons := ('|' || V_CLM_BILL_REASONS || '|');
          str_tab2  := ttk_util_pkg.parse_str(v_reasons);
        ELSE
          str_tab2(1) := V_CLM_BILL_REASONS;

        END IF;

      
        FOR i IN str_tab.FIRST .. str_tab.LAST LOOP
          v_bill_headers := v_bill_headers || '<li>' || str_tab(i) ||
                            '</li>' || '<li>' || 'COPAY_AMOUNT ' || '</li>' ||
                            '<li>' || 'POLICY_DEDUCTABLE_AMT ' || '</li>';
        end loop;

        --v_bill_headers:='<ol>'||v_bill_headers||'</ol>';----headers
      
        FOR i IN str_tab1.FIRST .. str_tab1.LAST LOOP
          v_bill_amounts := v_bill_amounts || '<li>' || str_tab1(i) ||
                            '</li>' || '<li>' ||
                            cr_get_clm_fin_rec.co_payment_amount || '</li>' ||
                            '<li>' ||
                            cr_get_clm_fin_rec.policy_deductable_amt ||
                            '</li>';
        end loop;

        -- v_bill_amounts:='<ol>'||v_bill_amounts||'</ol>';----amounts
      
        FOR i IN str_tab2.FIRST .. str_tab2.LAST LOOP
          v_bill_reasons := v_bill_reasons || '<li>' || str_tab2(i) ||
                            '</li>' || '<li>' || 'COPAY_AMOUNT ' || '</li>' ||
                            '<li>' || 'POLICY_DEDUCTABLE_AMT ' || '</li>';
        end loop;

        -- v_bill_reasons:='<ol>'||v_bill_reasons||'</ol>';----reasons
      
        v_params(1) := cr_get_clm_fin_rec.policy_number;
        v_params(2) := cr_get_clm_fin_rec.product_name;
        v_params(3) := cr_get_clm_fin_rec.claim_number;
        v_params(4) := cr_get_clm_fin_rec.clm_intimation_num;
        v_params(5) := to_char(sysdate, 'DD/MM/YYYY');
        v_params(6) := cr_get_clm_fin_rec.pol_holder_name;
        v_params(7) := cr_get_clm_fin_rec.claim_number;
        v_params(8) := to_char(cr_get_clm_fin_rec.rcvd_date, 'DD/MM/YYYY');
        v_params(9) := cr_get_clm_fin_rec.claim_number;
        v_params(10) := cr_get_clm_fin_rec.claimant_name;
        v_params(11) := cr_get_clm_fin_rec.hosp_name;
        v_params(12) := cr_get_clm_fin_rec.hos_address;
        v_params(13) := cr_get_clm_fin_rec.ailment_description;
        v_params(14) := cr_get_clm_fin_rec.requested_amount;
        v_params(15) := cr_get_clm_fin_rec.total_app_amount;
        v_params(16) := cr_get_clm_fin_rec.deduct_amount;
        v_params(17) := cr_get_clm_fin_rec.reason;
        v_params(18) := NVL(v_bill_headers, '---');
        v_params(19) := NVL(v_bill_amounts, '0.00');
        v_params(20) := NVL(v_bill_reasons, '---');
        v_params(21) := cr_get_clm_fin_rec.check_num;
        v_params(22) := to_char(cr_get_clm_fin_rec.check_date, 'DD/MM/YYYY');
      
        v_sms_phone := cr_get_clm_fin_rec.claimant_phone;
        v_email_id  := cr_get_clm_fin_rec.pol_hold_email_id;
      
        -- For SMS Generation
        v_SMS_params(1) := cr_get_clm_fin_rec.claim_number;
        v_SMS_params(2) := cr_get_clm_fin_rec.total_app_amount;
        v_SMS_params(3) := cr_get_clm_fin_rec.check_num;
        v_SMS_params(4) := to_char(cr_get_clm_fin_rec.check_date,
                                   'DD/MM/YYYY');
      
      ELSIF v_message_type_id = 'CIGNA_CLM_CLOSER_EMAIL_AD' THEN
        ---5 ok
      
        OPEN cr_get_regular_claims(v_parameters);
        FETCH cr_get_regular_claims
          INTO cr_get_regular_claims_rec;
        CLOSE cr_get_regular_claims;
      
        v_params(1) := cr_get_regular_claims_rec.policy_number;
        v_params(2) := cr_get_regular_claims_rec.pol_holder_name;
        v_params(3) := cr_get_regular_claims_rec.product_name;
        v_params(4) := cr_get_regular_claims_rec.claim_number;
        v_params(5) := cr_get_regular_claims_rec.clm_intimation_num;
        v_params(6) := to_char(sysdate, 'DD/MM/YYYY');
        v_params(7) := cr_get_regular_claims_rec.agent_name;
        v_params(8) := cr_get_regular_claims_rec.claimant_name;
        v_params(9) := to_char(cr_get_regular_claims_rec.rcvd_date,
                               'DD/MM/YYYY');
        v_params(10) := cr_get_regular_claims_rec.pol_holder_name || '/' ||
                        cr_get_regular_claims_rec.claimant_name;
        v_params(11) := NVL(to_char(cr_get_regular_claims_rec.intl_shortfal_snt_date,
                                    'DD/MM/YYYY'),
                            '--');
        v_params(12) := NVL(to_char(cr_get_regular_claims_rec.rmdr_req_snt_date,
                                    'DD/MM/YYYY'),
                            '--');
        v_params(13) := NVL(to_char(cr_get_regular_claims_rec.clsr_notice_snt_date,
                                    'DD/MM/YYYY'),
                            '--');
        v_params(14) := cr_get_regular_claims_rec.claim_number;
        v_params(15) := cr_get_regular_claims_rec.claimant_name;
        v_params(16) := cr_get_regular_claims_rec.hosp_name;
        v_params(17) := cr_get_regular_claims_rec.hos_address;
      
        v_sms_phone := cr_get_regular_claims_rec.agent_phone;
        v_email_id  := cr_get_regular_claims_rec.agent_mail;
      
        -- For SMS Generation
        v_SMS_params(1) := cr_get_regular_claims_rec.claim_number;
      
      ELSIF v_message_type_id = 'CIGNA_CLM_CLOSER_EMAIL_PO' THEN
        --6 ok
      
        OPEN cr_get_regular_claims(v_parameters);
        FETCH cr_get_regular_claims
          INTO cr_get_regular_claims_rec;
        CLOSE cr_get_regular_claims;
      
        for rec in (select rownum, cname
                      from (SELECT extractValue(value(des),
                                                '/query/@postlabel') AS cname
                              FROM (SELECT sh.shortfall_questions
                                      FROM clm_enroll_details  a,
                                           clm_general_details b,
                                           shortfall_details   sh
                                     WHERE b.claim_seq_id = a.claim_seq_id
                                       and b.claim_seq_id = sh.claim_seq_id(+)
                                       and b.claim_seq_id = v_parameters) p,
                                   TABLE(XMLSequence(extract(p.shortfall_questions,
                                                             '/shortfall/section/subsection/query[@value="YES"]'))) des
                            union all
                            SELECT extractValue(value(des), '/query/@value') AS cname
                              FROM (SELECT sh.shortfall_questions
                                      FROM clm_enroll_details  a,
                                           clm_general_details b,
                                           shortfall_details   sh
                                     WHERE b.claim_seq_id = a.claim_seq_id
                                       and b.claim_seq_id = sh.claim_seq_id(+)
                                       and b.claim_seq_id = v_parameters) p,
                                   TABLE(XMLSequence(extract(p.shortfall_questions,
                                                             '/shortfall/section/subsection/query[@type="text"]'))) des)
                     where cname is not null) loop
          v_shrtfall_que := v_shrtfall_que || '<li>' || rec.cname ||
                            '</li>
         ';
        end loop;

      
        v_shrtfall_que := '<ol>' || v_shrtfall_que || '</ol>';
      
        v_params(1) := cr_get_regular_claims_rec.policy_number;
        v_params(2) := cr_get_regular_claims_rec.product_name;
        v_params(3) := cr_get_regular_claims_rec.claim_number;
        v_params(4) := cr_get_regular_claims_rec.clm_intimation_num;
        v_params(5) := to_char(sysdate, 'DD/MM/YYYY');
        v_params(6) := cr_get_regular_claims_rec.pol_holder_name;
        v_params(7) := to_char(cr_get_regular_claims_rec.rcvd_date,
                               'DD/MM/YYYY');
        v_params(8) := to_char(cr_get_regular_claims_rec.intl_shortfal_snt_date,
                               'DD/MM/YYYY'); --test
        v_params(9) := to_char(cr_get_regular_claims_rec.rmdr_req_snt_date,
                               'DD/MM/YYYY');
        v_params(10) := to_char(cr_get_regular_claims_rec.clsr_notice_snt_date,
                                'DD/MM/YYYY');
        v_params(11) := cr_get_regular_claims_rec.claim_number;
        v_params(12) := cr_get_regular_claims_rec.claimant_name;
        v_params(13) := cr_get_regular_claims_rec.hosp_name;
        v_params(14) := cr_get_regular_claims_rec.hos_address;
        v_params(15) := cr_get_regular_claims_rec.ailment_description;
        v_params(16) := v_shrtfall_que;
      
        v_sms_phone := cr_get_regular_claims_rec.claimant_phone;
        v_email_id  := cr_get_regular_claims_rec.pol_hold_email_id;
      
        -- For SMS Generation
        v_SMS_params(1) := cr_get_regular_claims_rec.claim_number;
      
      ELSIF v_message_type_id = 'CIGNA_CLM_REJECT_EMAIL_AD' THEN
        ---7 ok
      
        OPEN cr_get_regular_claims(v_parameters);
        FETCH cr_get_regular_claims
          INTO cr_get_regular_claims_rec;
        CLOSE cr_get_regular_claims;
      
        v_params(1) := cr_get_regular_claims_rec.policy_number;
        v_params(2) := cr_get_regular_claims_rec.pol_holder_name;
        v_params(3) := cr_get_regular_claims_rec.product_name;
        v_params(4) := cr_get_regular_claims_rec.claim_number;
        v_params(5) := cr_get_regular_claims_rec.clm_intimation_num;
        v_params(6) := to_char(sysdate, 'DD/MM/YYYY');
        v_params(7) := cr_get_regular_claims_rec.agent_name;
        v_params(8) := cr_get_regular_claims_rec.claimant_name;
        v_params(9) := to_char(cr_get_regular_claims_rec.rcvd_date,
                               'DD/MM/YYYY');
        v_params(10) := cr_get_regular_claims_rec.pol_holder_name || '/' ||
                        cr_get_regular_claims_rec.claimant_name;
        v_params(11) := cr_get_regular_claims_rec.claim_number;
        v_params(12) := cr_get_regular_claims_rec.claimant_name;
        v_params(13) := cr_get_regular_claims_rec.hosp_name;
        v_params(14) := cr_get_regular_claims_rec.hos_address;
        v_sms_phone := cr_get_regular_claims_rec.agent_phone;
        v_email_id := cr_get_regular_claims_rec.agent_mail;
      
        -- For SMS Generation
        v_SMS_params(1) := cr_get_regular_claims_rec.claim_number;
      
      ELSIF v_message_type_id = 'CIGNA_CLM_REJECT_EMAIL_PO' THEN
        ----8
      
        OPEN cr_get_regular_claims(v_parameters);
        FETCH cr_get_regular_claims
          INTO cr_get_regular_claims_rec;
        CLOSE cr_get_regular_claims;
      
        v_params(1) := cr_get_regular_claims_rec.policy_number;
        v_params(2) := cr_get_regular_claims_rec.product_name;
        v_params(3) := cr_get_regular_claims_rec.claim_number;
        v_params(4) := cr_get_regular_claims_rec.clm_intimation_num;
        v_params(5) := to_char(sysdate, 'DD/MM/YYYY');
        v_params(6) := cr_get_regular_claims_rec.pol_holder_name;
        v_params(7) := cr_get_regular_claims_rec.claim_number;
        v_params(8) := to_char(cr_get_regular_claims_rec.rcvd_date,
                               'DD/MM/YYYY');
        v_params(9) := cr_get_regular_claims_rec.claim_number;
        v_params(10) := cr_get_regular_claims_rec.claimant_name;
        v_params(11) := cr_get_regular_claims_rec.hosp_name;
        v_params(12) := cr_get_regular_claims_rec.hos_address;
        v_params(13) := cr_get_regular_claims_rec.ailment_description;
        v_params(14) := cr_get_regular_claims_rec.reason;
        --if cr_get_regular_claims_rec.clause_description is null then
        v_params(15) := cr_get_regular_claims_rec.remarks;
        /* else
         v_params(15) :=cr_get_regular_claims_rec.clause_description ;--need to get clause with description
        end if;*/

        v_sms_phone := cr_get_regular_claims_rec.claimant_phone;
        v_email_id  := cr_get_regular_claims_rec.pol_hold_email_id;
      
        -- For SMS Generation
        v_SMS_params(1) := cr_get_regular_claims_rec.claim_number;
      
      END IF;

    
      -- Verify whether the FAX number is proper. i.e without any special characters and space.
      -- If yes, then throw error and needs to be rectified.
      IF (v_send_as_fax_yn = 'Y') THEN
        proc_verify_communication('FAX', v_fax_number);
      END IF;

    
      -- This procedure will merge the Raw Message and Data with regards to Message only related to Email
      IF (v_send_as_email_yn = 'Y') THEN
        proc_mail_merge(v_message_type_id,
                        'ON_MESSAGE',
                        NULL,
                        v_merged_message);
      
      END IF;

    
      -- This procedure will merge the Raw Message and Data with regards to Message only related to SMS
      IF (v_send_as_sms_yn = 'Y') THEN
        proc_mail_merge(v_message_type_id,
                        'ON_SMS_MESSAGE',
                        NULL,
                        v_merged_SMS_message);
      END IF;

    
      -- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
      -- This procedure will merge the Raw Message (TITLE ) and Data with regards to TITLE only
      /*               v_params(1) := v_claimant_name;
                     v_params(2) := v_employee_no; -- FOR KOC 1268
      */

    
      --    proc_mail_merge ( v_message_type_id, 'ON_TITLE', v_msg_title, v_msg_title );
    
      -- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
      -- This procedure will merge the Raw Message and EMAIL with regards to EMAIL only
      -- pre_auth~CTTK_Branch~@ttkhealthcareservices.com - replace ~C with the respective branch.
      -- RESET the array with the Branch to which the mail has to be sent.
      -- v_params(1) := v_tpa_code;
      proc_mail_merge(v_message_type_id,
                      'ON_EMAIL',
                      v_sec_rcpt_list,
                      v_sec_rcpt_list);
    
      --begin
      IF v_message_type_id LIKE 'CIGNA%' THEN
        ---koc_ins_mail
        V_CIGNA_MESAGE := v_merged_message;
        INSERT INTO DESTINATION_MESSAGE D
          (DEST_MSG_SEQ_ID,
           MSG_ID,
           SOURCE_ID,
           SOURCE_SEQ_ID,
           MSG_SENT_FROM,
           MESSAGE_TITLE,
           MESSAGE,
           SMS_DESCRIPTION,
           ADDED_BY,
           ADDED_DATE,
           ENROLLMENT_NUMBER,
           FILE_PATH_NAME,
           CIGNA_SMS_YN,
           CIGNA_MESAGE)
        VALUES
          (DESTINATION_MESSAGE_SEQ.NEXTVAL,
           v_message_type_id,
           v_module_name,
           v_parameters,
           v_sent_from,
           v_msg_title,
           NULL,
           v_merged_SMS_message,
           v_added_by,
           sysdate,
           v_case_number,
           CASE WHEN v_document_name IS NOT NULL THEN
           v_document_name || '.pdf' ELSE NULL END,
           CASE WHEN v_message_type_id like 'CIGNA%' then 'Y' else
           V_CIGNA_SMS_YN end,
           V_CIGNA_MESAGE)
        RETURNING DEST_MSG_SEQ_ID INTO v_DEST_MSG_SEQ_ID;

      ELSE
        -- INSERT THE MESSAGE
        INSERT INTO DESTINATION_MESSAGE
          (DEST_MSG_SEQ_ID,
           MSG_ID,
           SOURCE_ID,
           SOURCE_SEQ_ID,
           MSG_SENT_FROM,
           MESSAGE_TITLE,
           MESSAGE,
           SMS_DESCRIPTION,
           ADDED_BY,
           ADDED_DATE,
           ENROLLMENT_NUMBER,
           FILE_PATH_NAME,
           CIGNA_SMS_YN)
        VALUES
          (DESTINATION_MESSAGE_SEQ.NEXTVAL,
           v_message_type_id,
           v_module_name,
           v_parameters,
           v_sent_from,
           v_msg_title,
           v_merged_message,
           v_merged_SMS_message,
           v_added_by,
           sysdate,
           v_case_number,
           CASE WHEN v_document_name IS NOT NULL THEN
           v_document_name || '.pdf' ELSE NULL END,
           CASE WHEN v_message_type_id like 'CIGNA%' then 'Y' else
           V_CIGNA_SMS_YN end
           
           )
        RETURNING DEST_MSG_SEQ_ID INTO v_DEST_MSG_SEQ_ID;

      END IF;

      v_message_status := v_message_type_id ||
                          ' - Correspondence Message Status : ';
    
      -- Insert the RECEIPIENT INFORMATION.
      v_count := 1;
      WHILE (v_count <= 3) LOOP
        v_email_ids      := NULL;
        v_sms            := NULL;
        v_fax            := NULL;
        v_insert_message := 'N';
        v_remarks        := NULL;
        v_msg_type       := NULL;
        v_present_yn     := 'Y';
      
        IF (v_count = 1) AND (v_send_as_email_yn = 'Y') THEN
          -- To handle the Primary or TO Email iD
          IF ((v_email_id IS NOT NULL) AND (v_general_mail IS NOT NULL)) THEN
            v_email_id := v_email_id || ',' || v_general_mail;
          ELSIF ((v_email_id IS NULL) AND (v_general_mail IS NOT NULL)) THEN
            v_email_id := v_general_mail;

          END IF;

        
          -- To handle the CC Email iD
          IF ((v_sec_rcpt_list IS NOT NULL) AND (v_cc_mail IS NOT NULL)) THEN
            v_sec_rcpt_list := v_sec_rcpt_list || ',' || v_cc_mail;
          ELSIF ((v_sec_rcpt_list IS NULL) AND (v_cc_mail IS NOT NULL)) THEN
            v_sec_rcpt_list := v_cc_mail;

          END IF;

        
          /*IF (v_email_id = 'NULL') OR (v_email_id = 'null') THEN
             v_remarks := 'Primary Email Id is not present ';
             v_present_yn      :='N';
          ELSE
               v_email_ids      := v_email_id;
          END IF;*/

        
          v_email_ids := v_email_id;
        
          v_insert_message := 'Y';
          v_msg_type       := 'EMAIL';
        
          /*IF ( v_email_ids IS NULL ) THEN
              -- v_insert_message := 'N';
              v_remarks := 'Primary Email Id is not present ';
              v_present_yn      :='N';
          \* -- *********************************************************************
           -- IMPORTANT - COMMENT FROM THIS LINE when this code goes to PRODUCTION SERVER.
           -- FROM POINT 1
           -- *********************************************************************
           ELSE
              -- FOR TEST SERVER, UNCOMMENT ONLY THIS LINE and Comments SPAN EMAIL ID Line.
              -- v_email_ids := 'kishore@ttkhealthcareservices.com,bimiya.bonifus@ttkhealthcareservices.com,tips@ttkhealthcareservices.com,balakrishna_e@spanservices.com,sunil_m@spanservices.com'; -- TEMPORARY FOR TESTTING PURPOSE
              -- FOR DEVELOPMENT SERVER, UNCOMMENT THIS LINE and COMMENT TTK EMAIL ID Line.
              -- v_email_ids := 'balakrishna_e@spanservices.com,sunil_m@spanservices.com'; -- TEMPORARY FOR TESTTING PURPOSE
           *\END IF; */

          -- THE ABOVE PART COMMENETED Y S.V.SREERAJ -- This part can be used in production,test and development without change.
          IF UPPER(nvl(v_email_ids, 'NULL')) = 'NULL' 
             OR (v_email_ids IS NULL ) THEN
            -- v_insert_message := 'N';
            v_remarks    := 'Primary Email Id is not present ';
            v_present_yn := 'N';
          ELSE
            SELECT a.sid
              INTO v_sid
              FROM tpa_system_parameters A
             WHERE ROWNUM = 1;

          
            IF v_sid = 'UAT' THEN
              IF LOWER(v_email_ids) LIKE '%@spanservices.com%' AND
                 v_message_type_id IN
                 ('PREAUTH_REJECTED_NHCP',
                  'PREAUTH_APPROVED_NHCP',
                  'PREAUTH_SHORTFALL_NHCP',
                  'PREAUTH_STATUS_NHCP') THEN
                v_email_ids := substr(substr(lower(v_email_ids),
                                             1,
                                             instr(lower(v_email_ids),
                                                   '@spanservices.com') - 1),
                                      instr(substr(lower(v_email_ids),
                                                   1,
                                                   instr(lower(v_email_ids),
                                                         '@spanservices.com') - 1),
                                            ',',
                                            -1) + 1) || '@spanservices.com'; --This has been done for send the mail to only span employees
              ELSE
                v_email_ids := 'span@ttkhealthcareservices.com,shahin.sm@ttkhealthcareservices.com,sunil_m@spanservices.com,navada_s@spanservices.com,ramakrishna_km@spanservices.com,murali@ttkhealthcareservices.com'; -- TEMPORARY FOR TESTTING PURPOSE

              END IF;

            ELSIF v_sid = 'DEV' THEN
              v_email_ids := 'sunil_m@spanservices.com,prakash_cs@spanservices.com,manikanta_k@spanservices.com'; -- TEMPORARY FOR TESTTING PURPOSE

            END IF;

          
          END IF;

        
          -- COMMENT TILL HERE FOR POINT 1
          -- **********************************************************************
          v_message_status := v_message_status || v_msg_type || ' - ' ||
                              NVL(v_email_ids, v_remarks) || ';';
        
        ELSIF (v_count = 2) AND (v_send_as_sms_yn = 'Y') THEN
          v_sms            := v_sms_phone;
          v_insert_message := 'Y';
          v_msg_type       := 'SMS';
        
          IF (v_sms IS NULL) THEN
            -- v_insert_message := 'N';
            v_remarks    := 'Primary SMS number is not present ';
            v_present_yn := 'N';
          ELSE
            -- (91 is to be prefixed for SMS to be sent.
            IF v_sid IN ('UAT', 'DEV') THEN
              v_sms := '919844459587,919980803569,918088131194,919884404472';
            ELSE
              --v_sms := '91' || v_sms;
              v_sms := v_sms;

            END IF;

          
          END IF;

          v_message_status := v_message_status || v_msg_type || ' - ' ||
                              NVL(v_sms, v_remarks) || ';';

        ELSIF (v_count = 3) AND (v_send_as_fax_yn = 'Y') THEN
          v_fax            := v_fax_number;
          v_insert_message := 'Y';
          v_msg_type       := 'FAX';
        
          IF (v_fax IS NULL) THEN
            --  v_insert_message := 'N';
            v_remarks    := 'Primary Fax number is not present ';
            v_present_yn := 'N';
          END IF;

        
          v_message_status := v_message_status || v_msg_type || ' - ' ||
                              NVL(v_fax, v_remarks) || ';';

        END IF;

      
        -- v_final_log_message := v_merged_message || v_message_status ;
        v_final_log_message := v_message_status;
      
        IF (v_insert_message = 'Y') THEN
        
          INSERT INTO DESTINATION_MESSAGE_RCPT
            (DEST_MSG_RCPT_SEQ_ID,
             DEST_MSG_SEQ_ID,
             PRM_RCPT_EMAIL_LIST,
             PRM_RCPT_SMS,
             PRM_RCPT_FAX_NOS,
             SEC_RCPT_EMAIL_LIST,
             REMARKS,
             ADDED_BY,
             ADDED_DATE,
             MSG_TYPE,
             PRESENT_YN,
             MAIL_STATUS,
             MSG_STATUS_GENERAL_TYPE_ID,
             SENT_DATE)
          VALUES
            (DESTINATION_MESSAGE_RCPT_SEQ.NEXTVAL,
             v_DEST_MSG_SEQ_ID,
             /*'barani.nathan@vidalhealthtpa.com',--*/

             v_email_ids,
             /*'8861154458,9060994898,8892859655,9886370232',--*/

             v_sms,
             v_fax,
             /*'barani.nathan@vidalhealthtpa.com',--*/

             v_sec_rcpt_list,
             v_remarks,
             v_added_by,
             sysdate,
             v_msg_type,
             v_present_yn,
             'INP',
             'MIQ', -- Message in queue
             NULL);

        END IF;

      
        v_count := v_count + 1;
      END LOOP;

    
      -- Insert the correspondences into the Alert Log.
      IF (v_notification_type = 'PREAUTH') THEN
        INSERT INTO PAT_LOG
          (PAT_LOG_SEQ_ID,
           SYSTEM_GEN_YN,
           PAT_LOG_GENERAL_TYPE_ID,
           REFERENCE_DATE,
           REMARKS,
           ADDED_BY,
           ADDED_DATE,
           PAT_GEN_DETAIL_SEQ_ID)
        VALUES
          (PAT_LOG_SEQ.NEXTVAL,
           'Y',
           'COM',
           SYSDATE,
           v_final_log_message,
           v_added_by,
           SYSDATE,
           v_pat_gen_detail_seq_id);

      ELSIF (v_notification_type = 'CLAIMS') THEN
        INSERT INTO PAT_LOG
          (PAT_LOG_SEQ_ID,
           SYSTEM_GEN_YN,
           PAT_LOG_GENERAL_TYPE_ID,
           REFERENCE_DATE,
           REMARKS,
           ADDED_BY,
           ADDED_DATE,
           CLAIM_SEQ_ID)
        VALUES
          (PAT_LOG_SEQ.NEXTVAL,
           'Y',
           'COM',
           SYSDATE,
           v_final_log_message,
           v_added_by,
           SYSDATE,
           v_claim_seq_id);

      END IF;

    
      COMMIT;
    END IF;

  END proc_generate_message_cigna;

  -----------------------------------------
  PROCEDURE validate_process_mail_cigna(v_message_type_id      VARCHAR2, -- The Actual Message id generated by the application
                                        v_parameters           VARCHAR2,
                                        v_mail_category        VARCHAR2, -- The send message id is of what type in Database
                                        v_process_yn           OUT VARCHAR2, -- Can the process be done or not
                                        v_general_mail         OUT VARCHAR2, -- Generic TO Email id created at the group
                                        v_cc_mail              OUT VARCHAR2, -- Generic CC Email id created at the group
                                        v_group_name           OUT VARCHAR2,
                                        v_customise_allowed_YN VARCHAR2) IS
    v_count                    NUMBER;
    v_enrol_type_id            PAT_ENROLL_DETAILS.Enrol_Type_Id%TYPE;
    v_general_mail_id          tpa_group_registration.notify_email_id%TYPE;
    v_cc_mail_id               tpa_group_registration.cc_email_id%TYPE;
    v_mail_cat_general_type_id tpa_group_registration.notify_type_id%TYPE;
    V_INS_SEQ_ID               TPA_INS_INFO.INS_SEQ_ID%TYPE;
    v_group_reg_seq_id         tpa_group_registration.group_reg_seq_id%TYPE;
  
    -- Pre-Auth Shortfall
    CURSOR cr_get_shortfall_regular(v_shortfall_seq_id shortfall_details.SHORTFALL_SEQ_ID%TYPE) IS
      SELECT pat_enroll_details.enrol_type_id,
             tpa_group_registration.notify_email_id,
             tpa_group_registration.cc_email_id,
             tpa_group_registration.notify_type_id,
             pat_enroll_details.group_reg_seq_id,
             tpa_group_registration.group_name
        FROM pat_enroll_details,
             pat_general_details,
             shortfall_details A,
             tpa_group_registration
       WHERE (pat_enroll_details.group_reg_seq_id =
             tpa_group_registration.group_reg_seq_id)
         and (pat_general_details.pat_enroll_detail_seq_id =
             pat_enroll_details.pat_enroll_detail_seq_id)
         and (pat_general_details.pat_gen_detail_seq_id =
             A.PAT_GEN_DETAIL_SEQ_ID)
         and (A.SHORTFALL_SEQ_ID = v_shortfall_seq_id);

  
    CURSOR cr_get_claims_inward(v_inward_seq_id clm_inward.claims_inward_seq_id%TYPE) IS
      SELECT clm_enroll_details.enrol_type_id,
             tpa_group_registration.notify_email_id,
             tpa_group_registration.cc_email_id,
             tpa_group_registration.notify_type_id,
             clm_enroll_details.group_reg_seq_id,
             tpa_group_registration.group_name
        FROM clm_enroll_details,
             clm_general_details,
             clm_inward,
             tpa_group_registration
       WHERE (clm_enroll_details.group_reg_seq_id =
             tpa_group_registration.group_reg_seq_id)
         and (clm_general_details.claim_seq_id =
             clm_enroll_details.claim_seq_id)
         and (clm_inward.claims_inward_seq_id =
             clm_general_details.claims_inward_seq_id)
         and (clm_inward.claims_inward_seq_id = v_inward_seq_id);

  
    CURSOR cr_get_claims_status(v_seq_id clm_general_details.claim_seq_id%TYPE) IS
      SELECT clm_enroll_details.enrol_type_id,
             tpa_group_registration.notify_email_id,
             tpa_group_registration.cc_email_id,
             tpa_group_registration.notify_type_id,
             clm_enroll_details.group_reg_seq_id,
             tpa_group_registration.group_name
        FROM tpa_group_registration,
             clm_enroll_details,
             clm_general_details
       WHERE (clm_enroll_details.group_reg_seq_id =
             tpa_group_registration.group_reg_seq_id)
         and (clm_general_details.claim_seq_id =
             clm_enroll_details.claim_seq_id)
         and (clm_general_details.claim_seq_id = v_seq_id);

  
    CURSOR cr_get_claim_shortfall_regular(v_shortfall_seq_id shortfall_details.SHORTFALL_SEQ_ID%TYPE) IS
      SELECT clm_enroll_details.Enrol_Type_Id,
             tpa_group_registration.notify_email_id,
             tpa_group_registration.cc_email_id,
             tpa_group_registration.notify_type_id,
             clm_enroll_details.group_reg_seq_id,
             tpa_group_registration.group_name
        FROM tpa_group_registration,
             clm_enroll_details,
             clm_general_details,
             shortfall_details
       WHERE (clm_enroll_details.group_reg_seq_id =
             tpa_group_registration.group_reg_seq_id)
         and (clm_general_details.CLAIM_SEQ_ID =
             clm_enroll_details.CLAIM_SEQ_ID)
         and (clm_general_details.claim_seq_id =
             shortfall_details.CLAIM_SEQ_ID)
         and (shortfall_details.SHORTFALL_SEQ_ID = v_shortfall_seq_id);

  
    CURSOR cr_get_ONLINE_ASSISTANCE(v_seq_id ONLINE_QUERY_DETAILS.QUERY_DETAILS_SEQ_ID%TYPE) IS
      SELECT C.Enrol_Type_Id,
             tpa_group_registration.notify_email_id,
             tpa_group_registration.cc_email_id,
             tpa_group_registration.notify_type_id,
             tpa_group_registration.group_reg_seq_id,
             tpa_group_registration.group_name
        FROM tpa_group_registration,
             ONLINE_QUERY_DETAILS   A,
             ONLINE_QUERY_HEADER    B,
             TPA_ENR_POLICY         C
       WHERE (C.GROUP_REG_SEQ_ID = tpa_group_registration.group_reg_seq_id)
         and (B.POLICY_SEQ_ID = C.POLICY_SEQ_ID)
         and (B.QUERY_HEADER_SEQ_ID = A.QUERY_HEADER_SEQ_ID)
         AND (A.QUERY_DETAILS_SEQ_ID = v_seq_id);

  
    -- Query is used to generate notification for EFT, Payadvice and Manual Cheque generation.
    CURSOR cr_get_FINANCIAL_PAYMENT(v_payment_seq_id TPA_CLAIMS_PAYMENT.PAYMENT_SEQ_ID%Type) IS
      SELECT ce.Enrol_Type_Id,
             gr.notify_email_id,
             gr.cc_email_id,
             gr.notify_type_id,
             ce.group_reg_seq_id,
             gr.group_name
        FROM clm_enroll_details ce
       INNER JOIN clm_general_details cg
          ON ce.claim_seq_id = cg.claim_seq_id
       INNER JOIN tpa_claims_payment cp
          ON cg.claim_seq_id = cp.claim_seq_id
       INNER JOIN tpa_group_registration gr
          ON ce.group_reg_seq_id = gr.group_reg_seq_id
       WHERE cp.payment_seq_id = v_payment_seq_id;

  
    -- Query is used to generate notification on expiry of first login window period.
    CURSOR cr_get_1st_LOGIN_PERIOD_CLOSED(v_policy_group_seq_id TPA_ENR_POLICY_GROUP.POLICY_GROUP_SEQ_ID%Type) IS
      SELECT p.Enrol_Type_Id,
             gr.notify_email_id,
             gr.cc_email_id,
             gr.notify_type_id,
             p.group_reg_seq_id,
             gr.group_name
        FROM tpa_enr_policy_group g
       INNER JOIN tpa_enr_policy p
          ON p.policy_seq_id = g.policy_seq_id
       INNER JOIN tpa_group_registration gr
          ON gr.group_reg_seq_id = p.group_reg_seq_id
       WHERE g.policy_group_seq_id = v_policy_group_seq_id;

  
    CURSOR cr_get_regular_preauth(v_pat_gen_detail_seq_id pat_general_details.pat_gen_detail_seq_id%TYPE) IS
      SELECT pat_enroll_details.enrol_type_id,
             TPA_INS_INFO.TO_MAIL_ID,
             TPA_INS_INFO.CC_MAIL_ID,
             TPA_INS_INFO.NOTIFY_TYPE_ID,
             TPA_INS_INFO.INS_SEQ_ID,
             TPA_INS_INFO.INS_COMP_NAME
        FROM pat_enroll_details, pat_general_details, TPA_INS_INFO
       WHERE (pat_enroll_details.Ins_Seq_Id = TPA_INS_INFO.INS_SEQ_ID)
         and (pat_general_details.pat_enroll_detail_seq_id =
             pat_enroll_details.pat_enroll_detail_seq_id)
         and (pat_general_details.pat_gen_detail_seq_id =
             v_pat_gen_detail_seq_id);

  
    CURSOR cr_get_regular_claims(v_seq_id clm_general_details.claim_seq_id%TYPE) IS
      SELECT ED.enrol_type_id,
             II.TO_MAIL_ID,
             II.CC_MAIL_ID,
             II.NOTIFY_TYPE_ID,
             II.INS_SEQ_ID,
             II.INS_COMP_NAME
        FROM CLM_INWARD          I,
             CLM_ENROLL_DETAILS  ED,
             CLM_GENERAL_DETAILS GD,
             TPA_INS_INFO        II
       WHERE (I.INWARD_INS_SEQ_ID = II.INS_SEQ_ID)
         and (GD.CLAIM_SEQ_ID = ED.CLAIM_SEQ_ID)
         AND (GD.CLAIMS_INWARD_SEQ_ID = I.CLAIMS_INWARD_SEQ_ID)
         and (GD.CLAIM_SEQ_ID = v_seq_id);

    CURSOR cr_get_pat_intimate(v_pat_intimation_seq_id TPA_CALL_PAT_INTIMATION.pat_intimation_seq_id%TYPE) IS
      SELECT ep.enrol_type_id,
             ii.TO_MAIL_ID,
             ii.CC_MAIL_ID,
             ii.NOTIFY_TYPE_ID,
             ii.INS_SEQ_ID,
             ii.INS_COMP_NAME
        FROM tpa_call_pat_intimation pi,
             tpa_enr_policy          ep,
             tpa_enr_policy_group    pg,
             TPA_INS_INFO            ii
       WHERE (pi.policy_group_seq_id = pg.policy_group_seq_id)
         and (ep.policy_seq_id = pg.policy_seq_id)
         and (ep.ins_seq_id = ii.ins_seq_id)
         and (pi.pat_intimation_seq_id = v_pat_intimation_seq_id);

  
    CURSOR cr_get_claim_intimate(v_call_log_seq_id tpa_call_log.call_log_seq_id%TYPE) IS
      SELECT POL.enrol_type_id,
             ii.TO_MAIL_ID,
             ii.CC_MAIL_ID,
             ii.NOTIFY_TYPE_ID,
             ii.INS_SEQ_ID,
             ii.INS_COMP_NAME
        FROM TPA_CALL_CLAIM_INTIMATION ci
        join tpa_call_log cl
          on (ci.call_log_seq_id = cl.call_log_seq_id)
        join tpa_enr_policy_group gr
          on (gr.policy_group_seq_id = cl.policy_group_seq_id)
        join tpa_enr_policy pol
          on (pol.policy_seq_id = gr.policy_seq_id)
        JOIN TPA_INS_INFO II
          ON (II.INS_SEQ_ID = POL.INS_SEQ_ID)
       WHERE cl.call_log_seq_id = v_call_log_seq_id;

  
    cr_get_claim_intimate_rec cr_get_claim_intimate%rowtype;
  
  BEGIN
  
    v_process_yn               := 'Y';
    v_general_mail             := NULL;
    v_mail_cat_general_type_id := v_mail_category;
  
    -- For following list of Message ID, Customisation should NOT BE allowed at Empanelment of Group Level
    -- 'CALLLOG_REPEAT', 'E_CARDS', 'MAX_CALL_RECEIVED', 'NEW_ONLINE_ENR_EMPLOYEE', 'NEW_USERID',
    -- 'NEW_USERID_GROUPID', 'NEW_USERID_INSCODE', 'ONLINE_EMPLOYEE_FAMILY_INFO', 'RESET_PASSWORD',
    -- 'RESET_PASSWORD_GROUPID', 'RESET_PASSWORD_INSCODE' );
  
    -- 1) If Customised allowed YN = 'N' - then these are default set of mails which cannot be customised.
    --    Just goes thru.
    -- 2) There are around 20 Odd emails which are Customisable.
  
    IF (v_customise_allowed_YN = 'Y') THEN
      IF (v_message_type_id in
         ('CIGNA_PAT_INITIAL_APP_EMAIL_PO',
           'CIGNA_PAT_INITIAL_APP_EMAIL_AD',
           'CIGNA_PAT_REJECT_EMAIL_PO',
           'CIGNA_PAT_REJECT_EMAIL_AD',
           'CIGNA_PAT_FINAL_APP_EMAIL_PO',
           'CIGNA_PAT_FINAL_APP_EMAIL_AD')) THEN
        OPEN cr_get_regular_preauth(v_parameters);
        FETCH cr_get_regular_preauth
          INTO v_enrol_type_id,
               v_general_mail_id,
               v_cc_mail_id,
               v_mail_cat_general_type_id,
               V_INS_SEQ_ID,
               v_group_name;
        CLOSE cr_get_regular_preauth;
      
      ELSIF v_message_type_id in
            ('CIGNA_PAT_REQUEST_EMAIL_AD', 'CIGNA_PAT_REQUEST_EMAIL_PO') THEN
        OPEN cr_get_pat_intimate(v_parameters);
        FETCH cr_get_pat_intimate
          INTO v_enrol_type_id,
               v_general_mail_id,
               v_cc_mail_id,
               v_mail_cat_general_type_id,
               V_INS_SEQ_ID,
               v_group_name;
        CLOSE cr_get_pat_intimate;
      
      ELSIF v_message_type_id in
            ('CIGNA_CLM_REGIS_EMAIL_PO', 'CIGNA_CLM_REGIS_EMAIL_AD') THEN
        OPEN cr_get_pat_intimate(v_parameters);
        FETCH cr_get_pat_intimate
          INTO v_enrol_type_id,
               v_general_mail_id,
               v_cc_mail_id,
               v_mail_cat_general_type_id,
               V_INS_SEQ_ID,
               v_group_name;
        CLOSE cr_get_pat_intimate;
      
      ELSIF (v_message_type_id in
            ('CIGNA_CLM_SETTLE_EMAIL_AD',
              'CIGNA_CLM_SETTLE_EMAIL_PO',
              'CIGNA_CLM_CLOSER_EMAIL_AD',
              'CIGNA_CLM_CLOSER_EMAIL_PO',
              'CIGNA_CLM_REJECT_EMAIL_AD',
              'CIGNA_CLM_REJECT_EMAIL_PO')) THEN
        OPEN cr_get_claim_intimate(v_parameters);
        FETCH cr_get_claim_intimate
          INTO v_enrol_type_id,
               v_general_mail_id,
               v_cc_mail_id,
               v_mail_cat_general_type_id,
               V_INS_SEQ_ID,
               v_group_name;
        CLOSE cr_get_claim_intimate;

      END IF;

    
      -- This is to take care of those IND where Mail type is not updated.
      -- Default all the corporates will have it as General.
      IF (v_mail_cat_general_type_id IS NULL) THEN
        v_mail_cat_general_type_id := 'NIG';
      END IF;

    
      -- This is to take care of those IND where Mail type is not updated.
      -- Default all the corporates will have it as General.
    
      -- NIG - General Category, NIC - Customise
      IF (v_enrol_type_id = 'IND') THEN
        IF (v_mail_cat_general_type_id = 'NIG') THEN
          v_process_yn := 'Y'; -- Continue processing
        ELSIF (v_mail_cat_general_type_id = 'NIC') THEN
        
          SELECT COUNT(1)
            INTO v_count
            FROM APP.SOURCE_MESSAGE_CUSTOM_GRP A
           WHERE A.MSG_ID = v_message_type_id
             AND A.INS_SEQ_ID = v_ins_seq_id;

        
          IF (v_count > 0) THEN
            v_process_yn := 'Y';
          ELSE
            v_process_yn := 'N';

          END IF;

        END IF;

      
        IF (v_process_yn = 'Y') THEN
          v_general_mail := v_general_mail_id;
          v_cc_mail      := v_cc_mail_id;
        END IF;

      END IF;

    END IF;

  END validate_process_mail_cigna; ---done
 --==============================================================
 -- get claim dashboard count
 --***************************************** 
PROCEDURE proc_dashboard_mail(v_message_type_id    VARCHAR2, 
                              v_parameters         VARCHAR2,
                              v_added_by           Destination_message.added_by%TYPE,
                              v_DEST_MSG_SEQ_ID    OUT VARCHAR2,
                              v_result             OUT SYS_REFCURSOR
                              ) IS
                              
    v_sid                VARCHAR2(100);
    v_merged_message     VARCHAR2(32765);
    v_merged_SMS_message VARCHAR2(4000);
    -- v_user_id                  tpa_login_info.user_id%TYPE;
    v_email_id1        tpa_user_contacts.primary_email_id%TYPE;
    v_url_name         tpa_system_parameters.application_url%TYPE;
    v_module_name      APP.SOURCE_MESSAGE.module_name%TYPE;
    v_sent_from        APP.SOURCE_MESSAGE.msg_sent_from%TYPE;
    v_msg_title        APP.SOURCE_MESSAGE.message_title%TYPE;
    v_send_as_email_yn APP.SOURCE_MESSAGE.send_as_email_yn%TYPE;
    v_send_as_sms_yn   APP.SOURCE_MESSAGE.send_as_sms_yn%TYPE;
    v_send_as_fax_yn   APP.SOURCE_MESSAGE.send_as_fax_yn%TYPE;
    v_prm_rcpt_list    APP.SOURCE_MESSAGE.prm_rcpt_email_list%TYPE;
    v_sec_rcpt_list    APP.SOURCE_MESSAGE.sec_rcpt_email_list%TYPE;
    v_email_ids        DESTINATION_MESSAGE_RCPT.PRM_RCPT_EMAIL_LIST%TYPE;
    v_sms              DESTINATION_MESSAGE_RCPT.PRM_RCPT_SMS%TYPE;
    v_fax              DESTINATION_MESSAGE_RCPT.PRM_RCPT_FAX_NOS%TYPE;
    v_insert_message   VARCHAR2(1);
    v_received_date         DATE;
    v_fax_number            DESTINATION_MESSAGE_RCPT.PRM_RCPT_FAX_NOS%TYPE;
    v_count                 NUMBER;
    v_tpa_code              tpa_office_info.office_code%TYPE;
    v_tpa_toll_phone        tpa_office_info.toll_free_no%TYPE;
    v_remarks               VARCHAR2(3000);
    v_final_log_message     VARCHAR2(4000);
    v_message_status        VARCHAR2(2000);
    v_notification_type     VARCHAR2(30);
    v_msg_type              destination_message_rcpt.msg_type%TYPE;
    v_present_yn            destination_message_rcpt.present_yn%TYPE;
    v_document_name         destination_message.FILE_PATH_NAME%TYPE;
    v_case_number           VARCHAR2(250);
    v_member_info           VARCHAR2(32679);
    v_doh                   DATE;
    v_mail_category         VARCHAR2(3); -- The send message id is of what type in Database
    v_process_yn            VARCHAR2(1); -- Can the process be done or not
    v_general_mail          DESTINATION_MESSAGE_RCPT.PRM_RCPT_EMAIL_LIST%TYPE; -- Generic mail id created at the group
    v_cc_mail               DESTINATION_MESSAGE_RCPT.SEC_RCPT_EMAIL_LIST%TYPE;
    v_customise_allowed_YN  APP.SOURCE_MESSAGE.CUSTOMIZATION_ALLOWED_YN%TYPE;
    v_group_name            TPA_GROUP_REGISTRATION.GROUP_NAME%TYPE;
    v_speed_recovery     VARCHAR2(250);
    v_mem_id             VARCHAR2(30);
    v_resultset          SYS_REFCURSOR;
    v_email_id           DESTINATION_MESSAGE_RCPT.PRM_RCPT_EMAIL_LIST%TYPE;
    v_sms_phone          pat_general_details.phone_no_in_hospitalisation%TYPE;

    -- Get the URL Name
    CURSOR cr_get_URL_Name(v_user_type tpa_user_contacts.user_general_type_id%TYPE) IS
      SELECT CASE
               WHEN v_user_type IN ('TTK', 'DMC', 'CAL') THEN
                APPLICATION_URL
               ELSE
                WEB_LOGIN_URL
             END AS APPLICATION_URL
        FROM TPA_SYSTEM_PARAMETERS;
  
    -- Get other core message info
    CURSOR cr_get_core_mesg_dtl(v_message_type_id VARCHAR2) IS
      SELECT module_name,
             msg_sent_from,
             message_title,
             send_as_email_yn,
             send_as_sms_yn,
             send_as_fax_yn,
             prm_rcpt_email_list,
             sec_rcpt_email_list,
             mail_cat_general_type_id,
             customization_allowed_yn
      
        FROM APP.SOURCE_MESSAGE A
       WHERE msg_id = v_message_type_id;

 
  CURSOR recovery_cur IS
    SELECT S.RECOVERY_MSG, NVL(S.RECOVERY_MSG_YN, 'N') AS RECOVERY_MSG_YN
    FROM APP.SOURCE_MESSAGE S
    WHERE S.MSG_ID = v_message_type_id;
    
  recovery_rec  recovery_cur%ROWTYPE;
  

  BEGIN
   
    -- This variable will indicate whether the message has to be logged into the Alert Table.
    -- If it is none, then no insertion, else depending CLAIMS, claim seq id would be updated.
    -- If pre-auth notifications, Pre-auth related id will be added.
    v_notification_type := 'NONE';
    v_msg_type          := NULL;
  
    -- For the selected Event ID, decide how should the message be sent ?
    OPEN cr_get_core_mesg_dtl(v_message_type_id);
    FETCH cr_get_core_mesg_dtl
      INTO v_module_name,
           v_sent_from,
           v_msg_title,
           v_send_as_email_yn,
           v_send_as_sms_yn,
           v_send_as_fax_yn,
           v_prm_rcpt_list,
           v_sec_rcpt_list,
           v_mail_category,
           v_customise_allowed_YN;
    CLOSE cr_get_core_mesg_dtl;
  
    -- Verify whether mail should be sent or not. Is it customised mail or general mail.
    validate_process_mail(v_message_type_id,
                          v_parameters,
                          v_mail_category,
                          v_process_yn,
                          v_general_mail,
                          v_cc_mail,
                          v_group_name,
                          v_customise_allowed_YN);
  
    IF (v_process_yn = 'Y') THEN
      -- ########### NEW_USERID - Generating message for User Creation (TTK USERS and COPROATE HR's )
      -- Message will be sent only through Email for the user
      IF (v_message_type_id = 'CLAIM_BULK_UPLOAD_DASHBOARD') THEN
         claim_bulk_upload.clm_blk_upload_dashboard( to_char(SYSDATE-1,'dd/mm/yyyy')
                                                    ,to_char(SYSDATE-1,'dd/mm/yyyy')
                                                    ,v_resultset
                                                   );
         IF v_resultset%ISOPEN THEN
           FETCH v_resultset BULK COLLECT INTO v_res_type;
         END IF;
         v_params(1)   := v_res_type(1).VINGS_BLKEXLCNT ;
         v_params(2)   := v_res_type(1).VINGS_BLKPRCCNT;
         v_params(3)   := v_res_type(1).PROVIDER_BLKEXLCNT ; 
         v_params(4)   := v_res_type(1).PROVIDER_BLKPRCCNT;
         v_params(5)   := v_res_type(1).PBM_BLKEXLCNT ;
         v_params(6)   := v_res_type(1).PBM_BLKPRCCNT;
         v_params(7)   := v_res_type(1).VINGS_RCVCLMCNT ;
         v_params(8)   := v_res_type(1).VINGS_PRCCLMCNT ;
         v_params(9)   := v_res_type(1).PROVIDER_RCVCLMCNT ;
         v_params(10)  := v_res_type(1).PROVIDER_PRCCLMCNT ;
         v_params(11)  := v_res_type(1).PBM_RCVCLMCNT ;
         v_params(12)  := v_res_type(1).PBM_PRCCLMCNT ;
         v_params(13)  := v_res_type(1).VINGS_RCVACTCNT ;
         v_params(14)  := v_res_type(1).VINGS_PRCACTCNT;
         v_params(15)  := v_res_type(1).PROVIDER_RCVACTCNT ;
         v_params(16)  := v_res_type(1).PROVIDER_PRCACTCNT;
         v_params(17)  := v_res_type(1).PBM_RCVACTCNT ;
         v_params(18)  := v_res_type(1).PBM_PRCACTCNT;
         
         --v_params(13)  := v_res_type(1).VINGS_PNDCLMCNT ;
         --v_params(14)  := v_res_type(1).PROVIDER_PNDCLMCNT ;
         --v_params(15)  := v_res_type(1).PBM_PNDCLMCNT ; 
         --v_params(16)  := v_res_type(1).VINGS_PNDACTCNT ;
         --v_params(17)  := v_res_type(1).PROVIDER_PNDACTCNT ;
         --v_params(18)  := v_res_type(1).PBM_PNDACTCNT ; 
         v_email_id    := v_prm_rcpt_list;                                     
           ------------------------------------------------------------------------------------------     
      END IF;
      END IF;

      -- Verify whether the FAX number is proper. i.e without any special characters and space.
      -- If yes, then throw error and needs to be rectified.
      IF (v_send_as_fax_yn = 'Y') THEN
        proc_verify_communication('FAX', v_fax_number);
      END IF;

    
      -- This procedure will merge the Raw Message and Data with regards to Message only related to Email
      IF (v_send_as_email_yn = 'Y') THEN
        proc_mail_merge(v_message_type_id,
                        'ON_MESSAGE',
                        NULL,
                        v_merged_message);
      END IF;

    
      -- This procedure will merge the Raw Message and Data with regards to Message only related to SMS
      IF (v_send_as_sms_yn = 'Y') THEN
        proc_mail_merge(v_message_type_id,
                        'ON_SMS_MESSAGE',
                        NULL,
                        v_merged_SMS_message);
      END IF;   

      -- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
      -- This procedure will merge the Raw Message and EMAIL with regards to EMAIL only
      -- pre_auth~CTTK_Branch~@ttkhealthcareservices.com - replace ~C with the respective branch.
      -- RESET the array with the Branch to which the mail has to be sent.
      proc_mail_merge(v_message_type_id,
                      'ON_EMAIL',
                      v_sec_rcpt_list,
                      v_sec_rcpt_list);


      proc_mail_merge(v_message_type_id,
                      'ON_TITLE',
                      v_msg_title,
                      v_msg_title);
      
      -- INSERT THE MESSAGE
      INSERT INTO DESTINATION_MESSAGE
        (DEST_MSG_SEQ_ID,
         MSG_ID,
         SOURCE_ID,
         SOURCE_SEQ_ID,
         MSG_SENT_FROM,
         MESSAGE_TITLE,
         MESSAGE,
         SMS_DESCRIPTION,
         ADDED_BY,
         ADDED_DATE,
         ENROLLMENT_NUMBER,
         FILE_PATH_NAME
         )
      VALUES
        (DESTINATION_MESSAGE_SEQ.NEXTVAL,
         v_message_type_id,
         v_module_name,
         v_parameters,
         v_sent_from,
         v_msg_title,
         v_merged_message,
         v_merged_SMS_message,
         v_added_by,
         sysdate,
         v_case_number,
         NULL
         )
      RETURNING DEST_MSG_SEQ_ID INTO v_DEST_MSG_SEQ_ID;
      
      v_message_status := v_message_type_id ||
                          ' - Correspondence Message Status : ';
    
      -- Insert the RECEIPIENT INFORMATION.
      v_count := 1;
      WHILE (v_count <= 3) LOOP
        v_email_ids      := NULL;
        v_sms            := NULL;
        v_fax            := NULL;
        v_insert_message := 'N';
        v_remarks        := NULL;
        v_msg_type       := NULL;
        v_present_yn     := 'Y';
      
        IF (v_count = 1) AND (v_send_as_email_yn = 'Y') THEN
          -- To handle the Primary or TO Email iD
          IF ((v_email_id IS NOT NULL) AND (v_general_mail IS NOT NULL)) THEN
            v_email_id := v_email_id || ',' || v_general_mail;
          ELSIF ((v_email_id IS NULL) AND (v_general_mail IS NOT NULL)) THEN
            v_email_id := v_general_mail;

          END IF;

        
          -- To handle the CC Email iD
          IF ((v_sec_rcpt_list IS NOT NULL) AND (v_cc_mail IS NOT NULL)) THEN
            v_sec_rcpt_list := v_sec_rcpt_list || ',' || v_cc_mail;
          ELSIF ((v_sec_rcpt_list IS NULL) AND (v_cc_mail IS NOT NULL)) THEN
            v_sec_rcpt_list := v_cc_mail;

          END IF;

        
          IF (v_email_id = 'NULL') OR (v_email_id = 'null') 
            OR (v_email_id IS NULL) THEN
             v_remarks := 'Primary Email Id is not present ';
             v_present_yn      :='N';
          ELSE
               v_email_ids      := v_email_id;
          END IF;

        
          v_email_ids := v_email_id;
        
          v_insert_message := 'Y';
          v_msg_type       := 'EMAIL';
        
          IF UPPER(nvl(v_email_ids, 'NULL')) = 'NULL' THEN
            -- v_insert_message := 'N';
            v_remarks    := 'Primary Email Id is not present ';
            v_present_yn := 'N';
          END IF;

          v_message_status := v_message_status || v_msg_type || ' - ' ||
                              NVL(v_email_ids, v_remarks) || ';';
        
        ELSIF (v_count = 2) AND (v_send_as_sms_yn = 'Y') THEN
          --IF v_message_type_id IN('PREAUTH_ENHANCED','PREAUTH_APROVED') AND v_ph_no_catagory != 'INTNAT' THEN
          v_sms            := v_sms_phone;
          v_insert_message := 'Y';
          v_msg_type       := 'SMS';
          /*ELSE
          v_sms := v_sms_phone;
          v_insert_message := 'Y';
          v_msg_type       := 'SMS';
          END;*/

          IF (v_sms IS NULL) THEN
            -- v_insert_message := 'N';
            v_remarks    := 'Primary SMS number is not present ';
            v_present_yn := 'N';
          ELSE
            -- (91 is to be prefixed for SMS to be sent.
            IF v_sid IN ('UAT', 'DEV') THEN
              v_sms := '919844459587,919980803569,918088131194,919884404472';
            ELSE
              --v_sms := '91' || v_sms;
              v_sms := v_sms;

            END IF;

          
          END IF;

          v_message_status := v_message_status || v_msg_type || ' - ' ||
                              NVL(v_sms, v_remarks) || ';';

        ELSIF (v_count = 3) AND (v_send_as_fax_yn = 'Y') THEN
          v_fax            := v_fax_number;
          v_insert_message := 'Y';
          v_msg_type       := 'FAX';
        
          IF (v_fax IS NULL) THEN
            --  v_insert_message := 'N';
            v_remarks    := 'Primary Fax number is not present ';
            v_present_yn := 'N';
          END IF;

        
          v_message_status := v_message_status || v_msg_type || ' - ' ||
                              NVL(v_fax, v_remarks) || ';';

        END IF;

        v_final_log_message := v_message_status;
      
        IF (v_insert_message = 'Y') THEN
        
          INSERT INTO DESTINATION_MESSAGE_RCPT
            (DEST_MSG_RCPT_SEQ_ID,
             DEST_MSG_SEQ_ID,
             PRM_RCPT_EMAIL_LIST,
             PRM_RCPT_SMS,
             PRM_RCPT_FAX_NOS,
             SEC_RCPT_EMAIL_LIST,
             REMARKS,
             ADDED_BY,
             ADDED_DATE,
             MSG_TYPE,
             PRESENT_YN,
             MAIL_STATUS,
             MSG_STATUS_GENERAL_TYPE_ID,
             SENT_DATE)
          VALUES
            (DESTINATION_MESSAGE_RCPT_SEQ.NEXTVAL,
             v_DEST_MSG_SEQ_ID,
             CASE when v_msg_type = 'EMAIL' then v_email_id  else null end, 
             case when v_msg_type = 'SMS' then v_sms else null end,
             v_fax,
             CASE when v_msg_type = 'EMAIL' then v_sec_rcpt_list else null end,
             v_remarks,
             v_added_by,
             sysdate,
             v_msg_type,
             v_present_yn, --v_present_yn,
             'INP',
             'MIQ', -- Message in queue
             NULL);
          
          COMMIT;
        END IF;

        
        v_count := v_count + 1;
      END LOOP;
      
      IF (v_send_as_sms_yn = 'Y') THEN
        IF v_sms_phone IS NOT NULL THEN
           v_sms            := v_sms_phone;
        ELSE
          v_remarks := 'Primary SMS number is not present ';
        END IF;
        
        OPEN recovery_cur;
        FETCH recovery_cur INTO recovery_rec;
        CLOSE recovery_cur;
        
        
          
      END IF;     

      COMMIT;
      OPEN v_result FOR 
         SELECT ltu.* FROM 
             (SELECT RANK() over(partition by destination_message_rcpt.msg_type order by destination_message_rcpt.dest_msg_rcpt_seq_id asc) as AQ,
                     destination_message_rcpt.dest_msg_rcpt_seq_id,
                     destination_message.msg_id,
                     destination_message.msg_sent_from,
                     destination_message_rcpt.msg_type,
                     destination_message_rcpt.present_yn,
                     destination_message.message_title,
                     CASE
                       WHEN destination_message_rcpt.msg_type = 'SMS' THEN
                        destination_message.sms_description
                       ELSE
                        CASE
                          WHEN destination_message.msg_id LIKE 'CIGNA%' THEN
                           dbms_lob.substr(destination_message.cigna_mesage,
                                           4000,
                                           1)
                          ELSE
                           TO_CHAR(destination_message.message)
                        END
                     END AS Message,
                     CASE
                       WHEN destination_message_rcpt.msg_type = 'EMAIL' and
                            destination_message.msg_id LIKE 'CIGNA%' THEN
                        dbms_lob.substr(destination_message.cigna_mesage,
                                        8000,
                                        4001)
                       else
                        null
                     end as cigna_msg,
                     destination_message.enrollment_number,
                     replace(replace(replace(REPLACE(destination_message_rcpt.prm_rcpt_email_list,
                                                     ';',
                                                     ','),
                                             ' ',
                                             NULL),
                                     ';,',
                                     ','),
                             '.,',
                             ',') AS prm_rcpt_email_list,
                     destination_message_rcpt.prm_rcpt_fax_nos,
                     destination_message_rcpt.prm_rcpt_sms,
                     destination_message_rcpt.sec_rcpt_email_list,
                     destination_message.file_path_name,
                     case
                       when destination_message.msg_id LIKE 'CIGNA%' then
                        'Claims@cignattk.in'
                       else
                        ttk_app_config.app_param_value
                     end sender_mail_id,
                     destination_message.added_date,
                     destination_message.cigna_sms_yn
                     
                FROM destination_message,
                     destination_message_rcpt,
                     ttk_app_config
               WHERE (destination_message_rcpt.dest_msg_seq_id = destination_message.dest_msg_seq_id)
                 AND  destination_message_rcpt.dest_msg_seq_id=v_DEST_MSG_SEQ_ID
                 AND  destination_message.msg_id='CLAIM_BULK_UPLOAD_DASHBOARD'
                 and (destination_message_rcpt.mail_status = 'INP')
                 AND (destination_message_rcpt.present_yn = 'Y')
                 AND (destination_message_rcpt.added_date <= sysdate)
                 AND (ttk_app_config.app_parameter = 'SITE_ADMIN_EMAIL')
                 AND (destination_message_rcpt.msg_type = 'EMAIL')
                 ) ltu
          WHERE ltu.aq <= 125;
  END proc_dashboard_mail;
 --=============================================================================
END GENERATE_MAIL_PKG;

/

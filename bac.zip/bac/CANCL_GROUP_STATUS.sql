--------------------------------------------------------
--  DDL for Synonymn CANCL_GROUP_STATUS
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."CANCL_GROUP_STATUS" FOR "APP"."CANCL_GROUP_STATUS";

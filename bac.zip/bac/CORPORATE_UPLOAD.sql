--------------------------------------------------------
--  DDL for Synonymn CORPORATE_UPLOAD
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."CORPORATE_UPLOAD" FOR "INTX"."CORPORATE_UPLOAD";

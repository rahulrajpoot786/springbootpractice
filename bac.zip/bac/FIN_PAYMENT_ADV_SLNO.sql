--------------------------------------------------------
--  DDL for Synonymn FIN_PAYMENT_ADV_SLNO
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."FIN_PAYMENT_ADV_SLNO" FOR "APP"."FIN_PAYMENT_ADV_SLNO";

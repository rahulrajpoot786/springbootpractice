--------------------------------------------------------
--  DDL for Synonymn HOSPITALIZATION_ICD
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."HOSPITALIZATION_ICD" FOR "APP"."HOSPITALIZATION_ICD";

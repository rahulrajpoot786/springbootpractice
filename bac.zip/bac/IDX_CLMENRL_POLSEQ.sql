--------------------------------------------------------
--  DDL for Synonymn IDX_CLMENRL_POLSEQ
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."IDX_CLMENRL_POLSEQ" FOR "APP"."IDX_CLMENRL_POLSEQ";

--------------------------------------------------------
--  DDL for Synonymn CAN_MEM_DTL_TAB
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."CAN_MEM_DTL_TAB" FOR "APP"."CAN_MEM_DTL_TAB";

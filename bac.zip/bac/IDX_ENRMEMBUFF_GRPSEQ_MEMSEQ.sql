--------------------------------------------------------
--  DDL for Synonymn IDX_ENRMEMBUFF_GRPSEQ_MEMSEQ
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."IDX_ENRMEMBUFF_GRPSEQ_MEMSEQ" FOR "APP"."IDX_ENRMEMBUFF_GRPSEQ_MEMSEQ";

--------------------------------------------------------
--  DDL for Package ECARD_PKG
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "VENUBABU"."ECARD_PKG" is

  -- Author  : SREERAJ_SV
  -- Created : 5/6/2008 8:02:29 PM
  -- Purpose : ebard generation
  
  PROCEDURE select_data_for_card_print (
    v_policy_group_seq_id IN  NUMBER,
    result_set       OUT SYS_REFCURSOR
  );
  --Procedure to select data for card print for individual membe
    PROCEDURE select_data_for_card_print_mem (
    v_policy_group_seq_id IN  NUMBER,
    v_member_seq_id IN NUMBER,
    result_set       OUT SYS_REFCURSOR
  );

end ecard_pkg;

/

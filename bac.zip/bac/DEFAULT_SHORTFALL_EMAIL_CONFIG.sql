--------------------------------------------------------
--  DDL for Synonymn DEFAULT_SHORTFALL_EMAIL_CONFIG
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."DEFAULT_SHORTFALL_EMAIL_CONFIG" FOR "APP"."DEFAULT_SHORTFALL_EMAIL_CONFIG";

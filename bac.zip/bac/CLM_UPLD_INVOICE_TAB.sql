--------------------------------------------------------
--  DDL for Synonymn CLM_UPLD_INVOICE_TAB
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."CLM_UPLD_INVOICE_TAB" FOR "APP"."CLM_UPLD_INVOICE_TAB";

--------------------------------------------------------
--  DDL for Synonymn CLM_DOCU_RCVD_SEQ
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."CLM_DOCU_RCVD_SEQ" FOR "APP"."CLM_DOCU_RCVD_SEQ";

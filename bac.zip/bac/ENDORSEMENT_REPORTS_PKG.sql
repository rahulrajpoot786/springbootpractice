--------------------------------------------------------
--  DDL for Synonymn ENDORSEMENT_REPORTS_PKG
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."ENDORSEMENT_REPORTS_PKG" FOR "APP"."ENDORSEMENT_REPORTS_PKG";

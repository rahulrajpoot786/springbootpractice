--------------------------------------------------------
--  DDL for Synonymn EMP
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."EMP" FOR "SCOTT"."EMP";

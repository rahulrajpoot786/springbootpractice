--------------------------------------------------------
--  DDL for Synonymn DESTINATION_MAIL_SEQ
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."DESTINATION_MAIL_SEQ" FOR "APP"."DESTINATION_MAIL_SEQ";

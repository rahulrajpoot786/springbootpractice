--------------------------------------------------------
--  DDL for Synonymn CLM_DATA_ENTRY_COMPLETE
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."CLM_DATA_ENTRY_COMPLETE" FOR "APP"."CLM_DATA_ENTRY_COMPLETE";

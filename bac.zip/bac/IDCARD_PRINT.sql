--------------------------------------------------------
--  DDL for Synonymn IDCARD_PRINT
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."IDCARD_PRINT" FOR "INTX"."IDCARD_PRINT";

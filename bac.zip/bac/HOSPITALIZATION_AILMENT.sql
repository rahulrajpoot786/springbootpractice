--------------------------------------------------------
--  DDL for Synonymn HOSPITALIZATION_AILMENT
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."HOSPITALIZATION_AILMENT" FOR "APP"."HOSPITALIZATION_AILMENT";

--------------------------------------------------------
--  DDL for Synonymn ERROR_LOG_SEQ
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."ERROR_LOG_SEQ" FOR "APP"."ERROR_LOG_SEQ";

--------------------------------------------------------
--  DDL for Procedure FIN_TEST
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "VENUBABU"."FIN_TEST" 
AS
v_payment   VARCHAR2(100);
V_SET      VARCHAR2(100);
begin
v_payment:= ''''||replace(trim('|' from '|7090967|7091121|7091122|'),'|',''',''')||'''' ;
SELECT claim_settlement_no INTO V_SET  FROM tpa_claims_payment WHERE TO_CHAR(payment_seq_id) IN (v_payment);
end;

/

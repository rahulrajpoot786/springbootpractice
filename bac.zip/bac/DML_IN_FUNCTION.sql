--------------------------------------------------------
--  DDL for Function DML_IN_FUNCTION
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "VENUBABU"."DML_IN_FUNCTION" 
RETURN NUMBER
AS
PRAGMA AUTONOMOUS_TRANSACTION;
V_CNT NUMBER(10);
BEGIN
RETURN V_CNT;
UPDATE MYEMP
SET SAL=100
WHERE ENAME='KING';
COMMIT;
END;

/

--------------------------------------------------------
--  DDL for Synonymn GN_NEW_MAIN_TRANS_DOWNLOAD
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."GN_NEW_MAIN_TRANS_DOWNLOAD" FOR "APP"."GN_NEW_MAIN_TRANS_DOWNLOAD";

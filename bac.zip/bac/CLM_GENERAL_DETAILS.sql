--------------------------------------------------------
--  DDL for Synonymn CLM_GENERAL_DETAILS
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."CLM_GENERAL_DETAILS" FOR "APP"."CLM_GENERAL_DETAILS";

--------------------------------------------------------
--  DDL for Synonymn CLM_HOSP_DTL_HOSP_ASSOC_SEQ
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."CLM_HOSP_DTL_HOSP_ASSOC_SEQ" FOR "APP"."CLM_HOSP_DTL_HOSP_ASSOC_SEQ";

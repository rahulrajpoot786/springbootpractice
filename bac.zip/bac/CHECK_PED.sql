--------------------------------------------------------
--  DDL for Procedure CHECK_PED
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "VENUBABU"."CHECK_PED" (
     v_ailment_value    IN    NUMBER,
     v_flag             IN    VARCHAR2,--DAYS, MONTHS, YEARS
     v_mem_seq_id       IN    NUMBER, 
     V_OUT              OUT   VARCHAR2 
     )
     IS
     v_policy_enr_days      NUMBER;
     cursor mem_inception_date is
     select date_of_inception from tpa_enr_policy_member where member_seq_id=v_mem_seq_id;
     v_mem_inception_date mem_inception_date%ROWTYPE;
BEGIN
IF not mem_inception_date%isopen THEN
 open mem_inception_date;
END IF;
FETCH mem_inception_date into v_mem_inception_date;
IF  mem_inception_date%isopen THEN
 close mem_inception_date;
END IF;

IF
 v_flag = 'DAYS' THEN
  
  IF  v_ailment_value >366 THEN
  raise_application_error(-20018,'number of days must be less than 365');
  END IF;
  
 select (trunc(sysdate)-to_date(v_mem_inception_date.date_of_inception,'DD-MM-YY')) into v_policy_enr_days from dual;
    IF v_ailment_value > v_policy_enr_days  THEN
    V_OUT :='PED';
    ELSE
    V_OUT :='GEN'; 
    END IF;

ELSIF v_flag='MONTHS' THEN
  IF  v_ailment_value >12 THEN
  raise_application_error(-20018,'number of months must be less than 12');
  END IF;

  SELECT TRUNC(MONTHS_BETWEEN(SYSDATE,v_mem_inception_date.date_of_inception)) INTO v_policy_enr_days FROM DUAL;
    IF v_ailment_value > v_policy_enr_days  THEN
    V_OUT :='PED';
    ELSE
    V_OUT :='GEN'; 
    END IF;

 ELSE
IF  v_ailment_value >1 THEN
  raise_application_error(-20018,'number of yers must be less than or equal to 1');
  END IF;
SELECT TRUNC(MONTHS_BETWEEN(SYSDATE,v_mem_inception_date.date_of_inception)/12) INTO v_policy_enr_days FROM DUAL;
   IF v_ailment_value > v_policy_enr_days  THEN
   V_OUT :='PED';
   ELSE
   V_OUT :='GEN'; 
   END IF;
END IF;
END;

/

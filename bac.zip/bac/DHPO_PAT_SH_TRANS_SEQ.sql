--------------------------------------------------------
--  DDL for Synonymn DHPO_PAT_SH_TRANS_SEQ
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."DHPO_PAT_SH_TRANS_SEQ" FOR "APP"."DHPO_PAT_SH_TRANS_SEQ";

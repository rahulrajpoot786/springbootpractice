--------------------------------------------------------
--  DDL for Synonymn CHANGE_TTK_TO_VIDAL
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."CHANGE_TTK_TO_VIDAL" FOR "INTX"."CHANGE_TTK_TO_VIDAL";

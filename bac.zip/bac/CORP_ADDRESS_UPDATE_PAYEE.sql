--------------------------------------------------------
--  DDL for Synonymn CORP_ADDRESS_UPDATE_PAYEE
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."CORP_ADDRESS_UPDATE_PAYEE" FOR "APP"."CORP_ADDRESS_UPDATE_PAYEE";

--------------------------------------------------------
--  DDL for Synonymn BATCH_MASTER_SEQ
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."BATCH_MASTER_SEQ" FOR "FIN_APP"."BATCH_MASTER_SEQ";

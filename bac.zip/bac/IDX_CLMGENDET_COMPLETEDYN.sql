--------------------------------------------------------
--  DDL for Synonymn IDX_CLMGENDET_COMPLETEDYN
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."IDX_CLMGENDET_COMPLETEDYN" FOR "APP"."IDX_CLMGENDET_COMPLETEDYN";

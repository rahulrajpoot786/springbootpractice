--------------------------------------------------------
--  DDL for Package Body AUDIT_REPORT_UPLOAD
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "VENUBABU"."AUDIT_REPORT_UPLOAD" 
AS
  v_error_code  VARCHAR2(20);
  v_error_msg   VARCHAR2(32000);
  --========================================================================
  PROCEDURE SAVE_AUDIT_XML(v_xml_seq_id   IN  OUT NUMBER,
                           v_xml_file     IN  XMLTYPE,
                           v_file_name    IN  VARCHAR2,
                           v_added_by     IN  VARCHAR2,
                           v_success_yn   OUT VARCHAR2
                          )
  AS
    v_err_count   NUMBER := 0;
    v_rec_count   NUMBER := 0;
    v_succ_count  NUMBER := 0;
  BEGIN
    
    INSERT INTO AUDIT_XML_TAB (XML_SEQ_ID,
                               FILE_NAME,
                               XML_FILE,
                               ADDED_BY,
                               ADDED_DATE
                              )
                       VALUES(audit_xml_seq.nextval,
                              v_file_name,
                              v_xml_file,
                              v_added_by,
                              SYSDATE
                             ) RETURNING XML_SEQ_ID INTO v_xml_seq_id;
  
  
  SELECT COUNT(1) INTO v_err_count
  FROM ERROR_LOG_TAB
  WHERE SOURCE_SEQ_ID = v_xml_seq_id;
  
  IF v_err_count = 0 THEN
    EXTRACT_AUDIT_XML(v_xml_seq_id, v_added_by);
    
    SELECT COUNT(1) INTO v_rec_count
    FROM AUDIT_EXTRACT_DETAILS_TAB A
    WHERE A.XML_SEQ_ID = v_xml_seq_id;
    
    SELECT COUNT(1) INTO v_succ_count
    FROM AUDIT_EXTRACT_DETAILS_TAB A
    WHERE A.XML_SEQ_ID = v_xml_seq_id
    AND A.ERR_REMARKS IS NULL;

    IF v_rec_count > 0 AND v_rec_count = v_succ_count THEN
      VALIDATE_CLAIM_AUDIT(v_xml_seq_id, v_added_by);
    END IF;
    
    SELECT COUNT(1) INTO v_err_count
    FROM ERROR_LOG_TAB
    WHERE SOURCE_SEQ_ID = v_xml_seq_id;
    
    IF v_rec_count > 0 AND v_err_count = 0 THEN
      SELECT COUNT(1) INTO v_err_count
      FROM AUDIT_EXTRACT_DETAILS_TAB
      WHERE XML_SEQ_ID = v_xml_seq_id
      AND ERR_REMARKS IS NOT NULL;
      
      IF v_err_count = 0 AND v_rec_count = v_succ_count THEN
        UPDATE_CLM_STATUS(v_xml_seq_id, v_added_by);
        v_success_yn := 'Y';
      ELSE
        v_success_yn := 'N';
      END IF;
    ELSE
      v_success_yn := 'N';
    END IF;  
  END IF;
    
  COMMIT;
  
  EXCEPTION
    WHEN OTHERS THEN
      v_error_code := NULL;
      v_error_msg  := NULL;
      
      v_error_code := SQLCODE;
      v_error_msg := SQLERRM;
      v_success_yn := 'N';
      
      SAVE_AUDIT_EXCEPTION(NULL, v_xml_seq_id, v_error_code, v_error_msg, 'SAVE_AUDIT_XML', v_added_by);
      
      ROLLBACK;
  END SAVE_AUDIT_XML;
  --========================================================================
  PROCEDURE SAVE_AUDIT_EXCEPTION(v_log_seq_id  IN NUMBER,
                                 v_xml_seq_id  IN NUMBER,
                                 v_error_code  IN VARCHAR2,
                                 v_error_msg   IN VARCHAR2,
                                 v_error_proc  IN VARCHAR2,
                                 v_added_by    IN NUMBER
                                )
  AS
    PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN
    INSERT INTO ERROR_LOG_TAB(LOG_SEQ_ID,
                              SOURCE_SEQ_ID,
                              ERR_CODE,
                              ERR_MSG,
                              PROC_NAME,
                              ADDED_BY,
                              ADDED_DATE
                             )
                       VALUES(error_log_seq.nextval,
                              v_xml_seq_id,
                              v_error_code,
                              v_error_msg,
                              v_error_proc,
                              v_added_by,
                              SYSDATE
                             );
                              
  COMMIT;
                        
  END SAVE_AUDIT_EXCEPTION;
  --========================================================================
  PROCEDURE EXTRACT_AUDIT_XML(v_xml_seq_id  IN NUMBER,
                              v_added_by    IN NUMBER
                             )
  AS
    
    CURSOR audit_xml_cur IS
      SELECT audit_rec.*
      FROM   AUDIT_XML_TAB x,
             XMLTABLE('/claimdetails/claim'
               PASSING x.xml_file
               COLUMNS 
                 claimnumber             VARCHAR2(100)  PATH 'claimnumber',
                 settlementnumber        VARCHAR2(10)   PATH 'settlementnumber',
                 tot_appr_amount         VARCHAR2(100)  PATH 'totalapprovedamount',
                 status                  VARCHAR2(100)  PATH 'status',
                 audit_remarks           VARCHAR2(4000) PATH 'auditremarks'
               ) audit_rec
      WHERE x.xml_seq_id = v_xml_seq_id;
    
   TYPE audit_xml_typ IS TABLE OF audit_xml_cur%ROWTYPE INDEX BY PLS_INTEGER;
   audit_xml_rec   audit_xml_typ;
   
  BEGIN
    OPEN audit_xml_cur;
    LOOP
      FETCH audit_xml_cur BULK COLLECT INTO audit_xml_rec;
      EXIT WHEN audit_xml_rec.COUNT = 0;
      
      FORALL i IN audit_xml_rec.FIRST.. audit_xml_rec.LAST
        INSERT INTO AUDIT_EXTRACT_DETAILS_TAB(AUDIT_SEQ_ID,
                                              XML_SEQ_ID,
                                              CLM_NUMBER,
                                              SETTLEMENT_NUMBER,
                                              TOT_APPR_AMOUNT,
                                              AUDIT_STATUS,
                                              AUDIT_REMARKS,
                                              AUDIT_DATE
                                             )
                                       VALUES(audit_extract_seq.nextval,
                                              v_xml_seq_id,
                                              TRIM(TRIM(BOTH '�' FROM REPLACE(audit_xml_rec(i).claimnumber,CHR(10)))),
                                              TRIM(TRIM(BOTH '�' FROM REPLACE(audit_xml_rec(i).settlementnumber,CHR(10)))),
                                              TRIM(TRIM(BOTH '�' FROM REPLACE(audit_xml_rec(i).tot_appr_amount,CHR(10)))),
                                              TRIM(TRIM(BOTH '�' FROM REPLACE(DECODE(audit_xml_rec(i).status, 'Checked', 'CHK', 'Recheck required', 'RCR', 'Not checked', 'NCH'),CHR(10)))),
                                              TRIM(TRIM(BOTH '�' FROM REPLACE(audit_xml_rec(i).audit_remarks,CHR(10)))),
                                              SYSDATE
                                             );
      END LOOP;
      CLOSE audit_xml_cur;
      
  EXCEPTION
    WHEN OTHERS THEN
      v_error_code := NULL;
      v_error_msg  := NULL;
      
      v_error_code := SQLCODE;
      v_error_msg := SQLERRM;
      
      SAVE_AUDIT_EXCEPTION(NULL, v_xml_seq_id, v_error_code, v_error_msg, 'EXTRACT_AUDIT_XML', v_added_by);
      
  END EXTRACT_AUDIT_XML;
  --========================================================================
  PROCEDURE VALIDATE_CLAIM_AUDIT(v_xml_seq_id IN NUMBER,
                                 v_added_by   IN NUMBER)
  AS
    bulk_errors          EXCEPTION;
    PRAGMA EXCEPTION_INIT(bulk_errors, -24381);
    l_error_count          NUMBER; 
    v_bulk_error_msg       CLOB;
    
    CURSOR audit_cur IS
      WITH DUPL_CLM AS (SELECT AD.AUDIT_SEQ_ID, AD.CLM_NUMBER, AD.ROWID RID,COUNT(AD.CLM_NUMBER) OVER (PARTITION BY AD.CLM_NUMBER ORDER BY AD.AUDIT_SEQ_ID) RNUM
                  FROM AUDIT_EXTRACT_DETAILS_TAB AD
                  WHERE AD.XML_SEQ_ID = v_xml_seq_id
                 )
      SELECT A.AUDIT_SEQ_ID,
             CASE WHEN A.CLM_NUMBER IS NULL THEN 'Claim Number cannot be blank; ' ELSE NULL END ||
             --CASE WHEN A.SETTLEMENT_NUMBER IS NULL THEN 'Claim Settlement number cannot be blank; ' ELSE NULL END ||
             CASE WHEN A.TOT_APPR_AMOUNT IS NULL THEN 'Total Approved Amount cannot be blank; ' ELSE NULL END ||
             CASE WHEN A.AUDIT_STATUS IS NULL THEN 'Audit status cannot be blank; 'ELSE NULL END ||
             CASE WHEN A.AUDIT_STATUS NOT IN ('CHK', 'RCR', 'NCH') THEN 'Audit status is wrong; ' ELSE NULL END ||
             CASE WHEN A.AUDIT_STATUS IS NOT NULL AND A.AUDIT_STATUS = C.AUDIT_STATUS THEN 'Given claim is already uploaded with '||CASE A.AUDIT_STATUS WHEN 'CHK' THEN 'Checked'
                                                                                                                                                        WHEN 'RCR' THEN 'Recheck Checked'
                                                                                                                                                        WHEN 'NCH' THEN 'Not Checked'
                                                                                                                                    END||'; ' ELSE NULL END||
             CASE WHEN A.AUDIT_STATUS IS NOT NULL AND A.AUDIT_STATUS = 'RCR' AND A.AUDIT_REMARKS IS NULL THEN 'Remarks cannot be blank for Re-Check Required; ' ELSE NULL END||
             CASE WHEN A.TOT_APPR_AMOUNT IS NOT NULL THEN
               CASE WHEN AUDIT_REPORT_UPLOAD.CHECK_DATA(A.TOT_APPR_AMOUNT) = 'INVALID' THEN 
                 'Total Approved Amount cannot be alphanumeric; '
               ELSE
                 NULL
               END
             END ||
             CASE WHEN A.CLM_NUMBER IS NOT NULL AND (SELECT COUNT(1) FROM CLM_AUTHORIZATION_DETAILS CL WHERE CL.CLAIM_NUMBER = A.CLM_NUMBER) = 0 THEN 'Claim does not exist in database; ' ELSE NULL END ||
             CASE WHEN A.SETTLEMENT_NUMBER IS NOT NULL AND (SELECT COUNT(1) FROM CLM_AUTHORIZATION_DETAILS CLM WHERE CLM.SETTLEMENT_NUMBER = A.SETTLEMENT_NUMBER) = 0 THEN 'Settlement number does not exist in database; ' ELSE NULL END ||
             CASE WHEN A.SETTLEMENT_NUMBER IS NOT NULL AND (SELECT COUNT(1) FROM CLM_AUTHORIZATION_DETAILS CLM WHERE CLM.SETTLEMENT_NUMBER = A.SETTLEMENT_NUMBER) > 0 THEN 
               CASE WHEN A.SETTLEMENT_NUMBER NOT IN (SELECT C.SETTLEMENT_NUMBER FROM CLM_AUTHORIZATION_DETAILS CL WHERE C.CLAIM_NUMBER = A.CLM_NUMBER) THEN 
               'Settlement number doesnot belongs to given claim number; ' 
               ELSE 
                 NULL 
               END
             END || -- Check Settlement if matching with claim
             CASE WHEN A.CLM_NUMBER IS NOT NULL AND A.TOT_APPR_AMOUNT IS NOT NULL AND (SELECT COUNT(1) FROM CLM_AUTHORIZATION_DETAILS CLM WHERE CLM.CLAIM_NUMBER = A.CLM_NUMBER) > 0 THEN 
               CASE WHEN A.TOT_APPR_AMOUNT NOT IN (SELECT C.TOT_APPROVED_AMOUNT FROM CLM_AUTHORIZATION_DETAILS CL WHERE C.CLAIM_NUMBER = A.CLM_NUMBER) THEN 
               'Amount is not matching with claim number; ' 
               ELSE 
                 NULL
               END 
             END ||
             --CASE WHEN A.CLM_NUMBER IS NOT NULL AND NVL(C.COMPLETED_YN, 'N') = 'N' THEN 'Claim should be complete for audit; ' ELSE NULL END ||
             CASE WHEN CLAIM_PAYMENT_STATUS != 'PENDING' THEN 'Claim payment status should be PENDING for audit the claim; ' ELSE NULL END ||
             CASE WHEN RNUM > 1 THEN 'Duplicate Claim cannot be Audit; ' ELSE NULL END AS REMARKS
             
      FROM AUDIT_EXTRACT_DETAILS_TAB A
      LEFT JOIN DUPL_CLM CD ON CD.AUDIT_SEQ_ID = A.AUDIT_SEQ_ID
      LEFT JOIN CLM_AUTHORIZATION_DETAILS C ON C.CLAIM_NUMBER = A.CLM_NUMBER
      LEFT JOIN TPA_CLAIMS_PAYMENT T ON T.CLAIM_SEQ_ID = C.CLAIM_SEQ_ID
      WHERE A.XML_SEQ_ID = v_xml_seq_id;
      
    TYPE typ_audit_data_vld IS TABLE OF  audit_cur%ROWTYPE INDEX BY PLS_INTEGER;
    audit_rec       typ_audit_data_vld;
    
    CURSOR clm_cur IS
      SELECT C.CLAIM_SEQ_ID,
             A.XML_SEQ_ID,
             A.CLM_NUMBER, 
             A.SETTLEMENT_NUMBER, 
             A.TOT_APPR_AMOUNT, 
             A.AUDIT_STATUS, 
             A.AUDIT_REMARKS, 
             A.AUDIT_DATE
             
      FROM CLM_AUTHORIZATION_DETAILS C
      JOIN AUDIT_EXTRACT_DETAILS_TAB A ON A.CLM_NUMBER = C.CLAIM_NUMBER
      WHERE A.XML_SEQ_ID = v_xml_seq_id
      AND A.ERR_REMARKS IS NULL;
      
    TYPE typ_clm_typ IS TABLE OF  clm_cur%ROWTYPE INDEX BY PLS_INTEGER;
    clm_rec       typ_clm_typ;
    
    v_err_rec  NUMBER := 0;
    v_audit_seq_id NUMBER;
    v_remark       CLOB;
  BEGIN
    OPEN audit_cur;
    LOOP
      FETCH audit_cur BULK COLLECT INTO audit_rec;
      EXIT WHEN audit_rec.COUNT = 0;
      
      FORALL i IN audit_rec.FIRST.. audit_rec.LAST
        UPDATE AUDIT_EXTRACT_DETAILS_TAB A
        SET A.ERR_REMARKS = audit_rec(i).REMARKS
        WHERE A.AUDIT_SEQ_ID = audit_rec(i).AUDIT_SEQ_ID;
    
    END LOOP;
    CLOSE audit_cur;
    
    SELECT COUNT(1) INTO v_err_rec
    FROM AUDIT_EXTRACT_DETAILS_TAB A
    WHERE A.XML_SEQ_ID = v_xml_seq_id
    AND A.ERR_REMARKS IS NOT NULL;
    
    IF v_err_rec = 0 THEN
      OPEN clm_cur;
      LOOP
        FETCH clm_cur BULK COLLECT INTO clm_rec;
        EXIT WHEN clm_rec.COUNT = 0;
      
      FORALL j IN clm_rec.FIRST.. clm_rec.LAST
        INSERT INTO CLM_AUDIT_DATA (CLM_AUDIT_SEQ_ID,
                                    XML_SEQ_ID,
                                    CLM_SEQ_ID,
                                    CLAIM_NUMBER,
                                    SETTLEMENT_NUMBER,
                                    TOT_APPR_AMOUNT,
                                    AUDIT_STATUS,
                                    AUDIT_REMARKS,
                                    ADUIT_BY,
                                    AUDIT_DATE
                                   )
                            VALUES(CLM_AUDIT_SEQ.NEXTVAL,
                                   clm_rec(j).XML_SEQ_ID,
                                   clm_rec(j).CLAIM_SEQ_ID,
                                   clm_rec(j).CLM_NUMBER,
                                   clm_rec(j).SETTLEMENT_NUMBER,
                                   clm_rec(j).TOT_APPR_AMOUNT,
                                   clm_rec(j).AUDIT_STATUS,
                                   clm_rec(j).AUDIT_REMARKS,
                                   v_added_by,
                                   SYSDATE
                                  );
      
      END LOOP;
      CLOSE clm_cur;
    END IF;
                               
    EXCEPTION
    WHEN bulk_errors THEN
      l_error_count := SQL%BULK_EXCEPTIONS.count;
      FOR i IN 1 .. l_error_count LOOP
        v_bulk_error_msg := v_bulk_error_msg ||
                            ('Number of failures: ' || l_error_count ||
                             'Error: ' || i ||
                             ' Array Index: ' || SQL%BULK_EXCEPTIONS(i).error_index ||
                             ' Message: ' || SQLERRM(-SQL%BULK_EXCEPTIONS(i).ERROR_CODE));
      END LOOP;
        SAVE_AUDIT_EXCEPTION(NULL, v_xml_seq_id, v_error_code, v_bulk_error_msg, 'VALIDATE_CLAIM_AUDIT', v_added_by);
        ROLLBACK;
      WHEN OTHERS THEN
        v_error_code := NULL;
        v_error_msg  := NULL;
        
         v_error_code := SQLCODE;
         v_error_msg  := SQLERRM; 
         
         SAVE_AUDIT_EXCEPTION(NULL, v_xml_seq_id, v_error_code, v_error_msg, 'VALIDATE_CLAIM_AUDIT', v_added_by);
         
  END VALIDATE_CLAIM_AUDIT;
  --========================================================================
  PROCEDURE GET_AUDIT_LOG(v_start_dt          IN VARCHAR2,
                          v_end_dt            IN VARCHAR2,
                          v_result_set        OUT SYS_REFCURSOR
                         )
  AS
    v_str     VARCHAR2(32000);
    v_where   VARCHAR2(4000);
    TYPE bind_tab_type IS TABLE OF VARCHAR2(250) INDEX BY BINARY_INTEGER ;
    bind_tab  bind_tab_type;
    i         NUMBER := 0;
    
  BEGIN
    
    v_str := 'SELECT ROWNUM AS SL_NO,
                     TO_CHAR(A.CLM_NUMBER) AS CLM_NUMBER,
                     TO_CHAR(A.SETTLEMENT_NUMBER) AS SETTLEMENT_NUMBER,
                     A.TOT_APPR_AMOUNT,
                     T.DESCRIPTION AS AUDIT_STATUS,
                     TO_CHAR(A.ERR_REMARKS) AS ERR_REMARKS
                      
              FROM AUDIT_XML_TAB X
              JOIN AUDIT_EXTRACT_DETAILS_TAB A ON X.XML_SEQ_ID = A.XML_SEQ_ID
              LEFT JOIN TPA_GENERAL_CODE T ON (T.GENERAL_TYPE_ID = A.AUDIT_STATUS AND T.HEADER_TYPE = ''AUDIT_STATUS'')
              WHERE A.ERR_REMARKS IS NOT NULL';
    
    IF v_start_dt IS NOT NULL AND v_end_dt IS NOT NULL THEN
      v_where := ' AND TO_DATE(X.ADDED_DATE, ''DD/MM/RRRR'') BETWEEN :start_date AND :end_date ';
      i := i+1;
      bind_tab(i) := TO_DATE(v_start_dt, 'DD/MM/RRRR');
      i := i+1;
      bind_tab(i) := TO_DATE(v_end_dt, 'DD/MM/RRRR');
      
    ELSIF v_start_dt IS NOT NULL AND v_end_dt IS NULL THEN
      v_where := ' AND TO_DATE(X.ADDED_DATE, ''DD/MM/RRRR'') BETWEEN :start_date AND :end_date ';
      i := i+1;
      bind_tab(i) := TO_DATE(v_start_dt, 'DD/MM/RRRR');
      i := i+1;
      bind_tab(i) := TO_DATE(v_start_dt, 'DD/MM/RRRR') + 90;
      
    ELSIF v_start_dt IS NULL AND v_end_dt IS NOT NULL THEN
      v_where := ' AND TO_DATE(X.ADDED_DATE, ''DD/MM/RRRR'') BETWEEN :start_date AND :end_date ';
      i := i+1;
      bind_tab(i) := TO_DATE(SYSDATE, 'DD/MM/RRRR') - 90;
      i := i+1;
      bind_tab(i) := TO_DATE(v_end_dt, 'DD/MM/RRRR');
    ELSIF v_start_dt IS NULL AND v_end_dt IS NULL THEN
      v_where := ' AND TO_DATE(X.ADDED_DATE, ''DD/MM/RRRR'') BETWEEN :start_date AND :end_date ';
      i := i+1;
      bind_tab(i) := TO_DATE(SYSDATE, 'DD/MM/RRRR') - 90;
      i := i+1;
      bind_tab(i) := TO_DATE(SYSDATE, 'DD/MM/RRRR');
    END IF;
    
    IF v_where IS NOT NULL THEN
      v_str := v_str ||v_where||' ORDER BY X.XML_SEQ_ID DESC';
    END IF;
    
    CASE WHEN bind_tab.FIRST IS NOT NULL THEN
      CASE bind_tab.count
        WHEN 1 THEN OPEN v_result_set FOR v_str USING bind_tab(1);
        WHEN 2 THEN OPEN v_result_set FOR v_str USING bind_tab(1), bind_tab(2);
        WHEN 3 THEN OPEN v_result_set FOR v_str USING bind_tab(1), bind_tab(2), bind_tab(3);
        WHEN 4 THEN OPEN v_result_set FOR v_str USING bind_tab(1), bind_tab(2), bind_tab(3), bind_tab(4);
      END CASE;
    ELSE
      OPEN v_result_set FOR v_str;
    END CASE;
        
  END GET_AUDIT_LOG;
  --========================================================================
  PROCEDURE UPDATE_CLM_STATUS(v_xml_seq_id  IN NUMBER,
                              v_added_by    IN NUMBER
                             )
  AS
    CURSOR clm_cur IS
      SELECT CA.CLAIM_NUMBER,
             CA.AUDIT_STATUS,
             CA.AUDIT_REMARKS,
             C.CLAIM_SEQ_ID,
             C.CLM_STATUS_TYPE_ID,
             T.PAYMENT_SEQ_ID,
             C.FINAL_APP_AMOUNT,
             C.pat_approved_amount,
             C.MEMBER_SEQ_ID,
             C.PAT_AUTH_SEQ_ID,
             C.COMPLETED_YN
             
      FROM CLM_AUDIT_DATA CA
      JOIN APP.CLM_AUTHORIZATION_DETAILS C ON C.CLAIM_SEQ_ID = CA.CLM_SEQ_ID
      LEFT JOIN TPA_CLAIMS_PAYMENT T ON T.CLAIM_SEQ_ID = C.CLAIM_SEQ_ID
      WHERE CA.XML_SEQ_ID = v_xml_seq_id;
      
    TYPE clm_typ IS TABLE OF clm_cur%ROWTYPE INDEX BY PLS_INTEGER;
    clm_rec clm_typ;
  BEGIN
    OPEN clm_cur;
    LOOP
      FETCH clm_cur BULK COLLECT INTO clm_rec;
      EXIT WHEN clm_rec.COUNT = 0;
    
    FORALL i IN clm_rec.FIRST.. clm_rec.LAST
      UPDATE APP.CLM_AUTHORIZATION_DETAILS C
      SET C.CLM_STATUS_TYPE_ID = CASE WHEN clm_rec(i).AUDIT_STATUS = 'RCR' AND NVL(C.COMPLETED_YN, 'N') = 'Y' THEN 'INP' ELSE C.CLM_STATUS_TYPE_ID END,
          C.COMPLETED_YN = CASE WHEN clm_rec(i).AUDIT_STATUS = 'RCR' AND NVL(C.COMPLETED_YN, 'N') = 'Y' THEN 'N' ELSE C.COMPLETED_YN END,
          C.AUDIT_STATUS = clm_rec(i).AUDIT_STATUS,
          C.CAL_ACT_YN = CASE WHEN clm_rec(i).AUDIT_STATUS = 'RCR' AND NVL(C.COMPLETED_YN, 'N') = 'Y' THEN 'N' ELSE C.CAL_ACT_YN END
          ,C.OVERRIDE_REMARKS = CASE WHEN clm_rec(i).AUDIT_STATUS = 'RCR' AND NVL(C.COMPLETED_YN, 'N') = 'Y'  THEN 
                                'Claim Status was Overriden in Audit Module, Audit Team Remarks are '||clm_rec(i).audit_remarks ELSE C.OVERRIDE_REMARKS END,
          C.OVERRIDE_DATE    = CASE WHEN clm_rec(i).AUDIT_STATUS = 'RCR' AND NVL(C.COMPLETED_YN, 'N') = 'Y'  THEN SYSDATE ELSE C.OVERRIDE_DATE END
      WHERE C.CLAIM_SEQ_ID = clm_rec(i).CLAIM_SEQ_ID;      
    
    FORALL i IN clm_rec.FIRST.. clm_rec.LAST
      DELETE FROM TPA_CLAIMS_PAYMENT T
      WHERE T.PAYMENT_SEQ_ID = CASE WHEN clm_rec(i).PAYMENT_SEQ_ID IS NOT NULL AND clm_rec(i).AUDIT_STATUS = 'RCR' AND clm_rec(i).CLM_STATUS_TYPE_ID = 'APR' THEN clm_rec(i).PAYMENT_SEQ_ID END;
     
    FORALL i IN clm_rec.FIRST.. clm_rec.LAST
      UPDATE APP.TPA_ENR_BALANCE BAL
       SET BAL.UTILISED_SUM_INSURED = CASE WHEN clm_rec(i).AUDIT_STATUS = 'RCR' AND NVL(clm_rec(i).COMPLETED_YN, 'N') = 'Y' AND clm_rec(i).clm_status_type_id ='APR' AND nvl(clm_rec(i).pat_auth_seq_id,0)!=0  THEN    
                                                 BAL.UTILISED_SUM_INSURED - (NVL(clm_rec(i).final_app_amount,0)- NVL(clm_rec(i).pat_approved_amount,0))
                                           WHEN clm_rec(i).AUDIT_STATUS = 'RCR' AND NVL(clm_rec(i).COMPLETED_YN, 'N') = 'Y' AND clm_rec(i).clm_status_type_id ='APR' AND nvl(clm_rec(i).pat_auth_seq_id,0)= 0  THEN
                                                BAL.UTILISED_SUM_INSURED - NVL(clm_rec(i).FINAL_APP_AMOUNT,0)
                                           ELSE  
                                                 BAL.UTILISED_SUM_INSURED  
                                       END 
           ,BAL.UPDATED_BY           = 1
           ,BAL.UPDATED_DATE         = SYSDATE
     WHERE BAL.MEMBER_SEQ_ID = CLM_REC(I).MEMBER_SEQ_ID;  
     
    END LOOP;
    CLOSE clm_cur;    
    
  EXCEPTION
    WHEN OTHERS THEN
      v_error_code := NULL;
      v_error_msg  := NULL;
    
      v_error_code := SQLCODE;
      v_error_msg  := SQLERRM; 
         
      SAVE_AUDIT_EXCEPTION(NULL, v_xml_seq_id, v_error_code, v_error_msg, 'UPDATE_CLM_STATUS', v_added_by);
       
  END UPDATE_CLM_STATUS;
  --========================================================================
  FUNCTION CHECK_DATA(v_value IN VARCHAR2) RETURN VARCHAR2
  AS
    v_data  NUMBER;
  BEGIN
    v_data := v_value;
    RETURN 'VALID';
  EXCEPTION
    WHEN OTHERS THEN
      RETURN 'INVALID';
  END CHECK_DATA;
  --========================================================================
END AUDIT_REPORT_UPLOAD;

/

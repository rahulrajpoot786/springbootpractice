--------------------------------------------------------
--  DDL for Synonymn BUFFER_REQ_NO_SEQ
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."BUFFER_REQ_NO_SEQ" FOR "APP"."BUFFER_REQ_NO_SEQ";

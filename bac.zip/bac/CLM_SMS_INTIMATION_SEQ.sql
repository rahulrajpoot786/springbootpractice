--------------------------------------------------------
--  DDL for Synonymn CLM_SMS_INTIMATION_SEQ
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."CLM_SMS_INTIMATION_SEQ" FOR "APP"."CLM_SMS_INTIMATION_SEQ";

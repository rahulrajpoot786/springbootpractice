--------------------------------------------------------
--  DDL for Synonymn CREATE_FILE
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."CREATE_FILE" FOR "INTX"."CREATE_FILE";

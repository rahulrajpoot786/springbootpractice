--------------------------------------------------------
--  DDL for Synonymn DHA_INS_BROKER_MASTER
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."DHA_INS_BROKER_MASTER" FOR "APP"."DHA_INS_BROKER_MASTER";

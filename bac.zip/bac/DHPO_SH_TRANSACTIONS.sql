--------------------------------------------------------
--  DDL for Synonymn DHPO_SH_TRANSACTIONS
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."DHPO_SH_TRANSACTIONS" FOR "APP"."DHPO_SH_TRANSACTIONS";

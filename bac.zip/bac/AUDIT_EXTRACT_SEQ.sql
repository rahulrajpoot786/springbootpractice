--------------------------------------------------------
--  DDL for Synonymn AUDIT_EXTRACT_SEQ
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."AUDIT_EXTRACT_SEQ" FOR "APP"."AUDIT_EXTRACT_SEQ";

--------------------------------------------------------
--  DDL for Synonymn DHA_PAYERS_MASTER
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."DHA_PAYERS_MASTER" FOR "APP"."DHA_PAYERS_MASTER";

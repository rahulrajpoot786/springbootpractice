--------------------------------------------------------
--  DDL for Synonymn CLM_POLICY
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."CLM_POLICY" FOR "APP"."CLM_POLICY";

--------------------------------------------------------
--  DDL for Synonymn BANK_ADVICE_BATCH_FILE_SEQ
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."BANK_ADVICE_BATCH_FILE_SEQ" FOR "FIN_APP"."BANK_ADVICE_BATCH_FILE_SEQ";

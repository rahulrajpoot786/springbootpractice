--------------------------------------------------------
--  DDL for Synonymn CG_CLAIMS_UPLOAD_FEEDBACK
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."CG_CLAIMS_UPLOAD_FEEDBACK" FOR "APP"."CG_CLAIMS_UPLOAD_FEEDBACK";

--------------------------------------------------------
--  DDL for Synonymn CLM_DAILY_REPORT
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."CLM_DAILY_REPORT" FOR "INTX"."CLM_DAILY_REPORT";

--------------------------------------------------------
--  DDL for Package BUFFER_CHANGES_PKG
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "VENUBABU"."BUFFER_CHANGES_PKG" IS

-- AUTHOR  : SREERAJ_SV
  -- CREATED : 6/2/2009 9:35:12 AM
  PROCEDURE update_amd;
 --============================================================================================
FUNCTION copay_restrict_check( v_prod_policy_seq_id   IN Tpa_ins_prod_policy.prod_policy_seq_id%TYPE,
                               v_claim_seq_id         IN Pat_general_details.pat_gen_detail_seq_id%TYPE,
                               v_app_amount           IN Tpa_enr_balance.sum_insured%TYPE,
                               v_tot_sum_insured      IN Tpa_enr_balance.sum_insured%TYPE,
                               v_used_sum_insured     IN Tpa_enr_balance.utilised_sum_insured%TYPE,
                               v_rest_sum_insured     IN Tpa_enr_balance.restrict_amt%TYPE,
                               v_used_rel_si          IN Tpa_enr_balance.used_restrict_amt%TYPE,
                               v_max_app_amount       IN Tpa_enr_balance.sum_insured%TYPE,
                               v_pat_buff_amount      IN Buffer_header.pre_auth_buffer_app_amount%TYPE,
                               v_restrict_yn          IN Tpa_ins_prod_policy.si_restrict_yn%TYPE,
                               v_type                 IN varchar2)
    RETURN NUMBER;
 --============================================================================================
  PROCEDURE p_copay_si (      v_prod_policy_seq_id   IN Tpa_Ins_Prod_Policy.Prod_Policy_Seq_Id%TYPE,
                              v_restrict_yn          IN VARCHAR2,
                              v_tot_sum_insured      IN OUT Tpa_enr_balance.sum_insured%TYPE,
                              v_rest_sum_insured     IN OUT Tpa_enr_balance.Sum_Insured%TYPE);
--============================================================================================
 PROCEDURE p_ava_copay(       v_claim_seq_id         IN clm_general_details.claim_seq_id%TYPE/*:=6615052*/,
                              v_sum_insured          IN OUT tpa_enr_balance.sum_insured%TYPE,
                              v_rest_si              IN OUT tpa_enr_balance.restrict_amt%TYPE );
--===============================================================================================================
 PROCEDURE  p_pa_ava_copay(  v_pat_gen_detail_seq_id       IN pat_general_details.pat_gen_detail_seq_id%TYPE,
                              v_sum_insured                IN OUT tpa_enr_balance.sum_insured%TYPE,
                              v_rest_si                    IN OUT tpa_enr_balance.restrict_amt%TYPE);
--===============================================================================================================
FUNCTION age_restrict_check( v_prod_policy_seq_id   IN Tpa_ins_prod_policy.prod_policy_seq_id%TYPE,
                               v_claim_seq_id         IN Pat_general_details.pat_gen_detail_seq_id%TYPE,
                               v_app_amount           IN Tpa_enr_balance.sum_insured%TYPE,
                               v_tot_sum_insured      IN Tpa_enr_balance.sum_insured%TYPE,
                               v_used_sum_insured     IN Tpa_enr_balance.utilised_sum_insured%TYPE,
                               v_rest_sum_insured     IN Tpa_enr_balance.restrict_amt%TYPE,
                               v_used_rest_sum        IN Tpa_enr_balance.used_restrict_amt%TYPE,
                               v_age_sum_insured      IN Tpa_enr_balance.restrict_amt%TYPE,
                               v_used_rel_si          IN Tpa_enr_balance.used_restrict_amt%TYPE,
                               v_max_app_amount       IN Tpa_enr_balance.sum_insured%TYPE,
                               v_pat_buff_amount      IN Buffer_header.pre_auth_buffer_app_amount%TYPE,
                               v_restrict_yn          IN Tpa_ins_prod_policy.si_restrict_yn%TYPE,
                               v_type                 IN varchar2)
                   RETURN NUMBER ;
--===============================================================================================================
 PROCEDURE age_copay_psi (  v_prod_policy_seq_id   IN Tpa_Ins_Prod_Policy.Prod_Policy_Seq_Id%TYPE,
                            v_restrict_yn          IN VARCHAR2,
                            v_tot_sum_insured      IN OUT Tpa_enr_balance.sum_insured%TYPE,
                            v_rest_sum_insured     IN OUT Tpa_enr_balance.Sum_Insured%TYPE,
                            v_rel_sum_insured      IN OUT Tpa_enr_balance.restrict_amt%TYPE);
--===============================================================================================================
 PROCEDURE age_ava_copay( v_claim_seq_id                        IN clm_general_details.claim_seq_id%TYPE,
                          v_sum_insured                         IN OUT tpa_enr_balance.sum_insured%TYPE,
                          v_age_si                              IN OUT tpa_enr_balance.restrict_amt%TYPE,
                          v_used_si                             IN OUT tpa_enr_balance.utilised_sum_insured%TYPE,
                          v_rest_si                             IN OUT tpa_enr_balance.restrict_amt%TYPE );
--===============================================================================================================
 PROCEDURE  age_pa_ava_copay(  v_pat_gen_detail_seq_id       IN pat_general_details.pat_gen_detail_seq_id%TYPE,
                               v_sum_insured                 IN OUT tpa_enr_balance.sum_insured%TYPE,
                               v_age_si                      IN OUT tpa_enr_balance.restrict_amt%TYPE,
                               v_used_si                     IN OUT tpa_enr_balance.utilised_sum_insured%TYPE,
                               v_rest_si                     IN OUT tpa_enr_balance.restrict_amt%TYPE) ;
--===============================================================================================================
PROCEDURE copay_adviced(
       v_mem_seq_id          IN  Pat_enroll_details.member_seq_id%TYPE,
       v_pol_grp_seq_id      IN  Tpa_enr_policy_group.policy_group_seq_id%TYPE,
       v_balance_seq_id      IN  Tpa_enr_balance.balance_seq_id%TYPE,
       v_pat_gen_seq_id      IN  Pat_general_details.pat_gen_detail_seq_id%TYPE,
       v_appr_amt            OUT Tpa_enr_balance.sum_insured%TYPE,
       v_max_copay           OUT Tpa_enr_balance.sum_insured%TYPE ) ;
----=============================================================================================
 
  FUNCTION f_icd_code_desc_pat(v_pat_gen_detail_seq_id  IN icd_pcs_detail.pat_gen_detail_seq_id%TYPE, -- to precide ICD CODES
                               v_flag                   IN VARCHAR2,
                               v_type                   IN VARCHAR2) RETURN  VARCHAR2;
                           
  FUNCTION fn_sfremarks_pat (v_pat_gen_detail_seq_id IN pat_general_details.pat_gen_detail_seq_id%TYPE)
  RETURN VARCHAR2;  

  
END buffer_changes_pkg;

/

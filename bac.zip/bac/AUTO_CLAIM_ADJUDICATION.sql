--------------------------------------------------------
--  DDL for Procedure AUTO_CLAIM_ADJUDICATION
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "VENUBABU"."AUTO_CLAIM_ADJUDICATION" 
  AS
    CURSOR clm_cur(v_clm_seq_id NUMBER) IS
      SELECT c.member_seq_id, 
             c.settlement_number, 
             c.date_of_hospitalization, 
             nvl(c.tot_allowed_amount, 0) as tot_allowed_amount,
             c.fnl_amt_currency_type
             
      FROM Clm_Batch_Upload_Details b
      JOIN Clm_Authorization_Details c ON c.clm_batch_seq_id = b.clm_batch_seq_id
      WHERE c.claim_seq_id = v_clm_seq_id;

    CURSOR consultation_cur IS
      SELECT c.claim_number, c.claim_seq_id, nvl(c.updated_by, c.added_by) AS added_by, h.hosp_seq_id
      FROM Clm_Batch_Upload_Details b
      JOIN Clm_Authorization_Details c ON c.clm_batch_seq_id = b.clm_batch_seq_id
      JOIN Pat_Activity_Details pa ON pa.claim_seq_id = c.claim_seq_id
      JOIN Clm_Hospital_Details h ON h.claim_seq_id = c.claim_seq_id
      JOIN Tpa_Activity_Details a ON a.activity_code = pa.code
      WHERE a.master_activity_code = '9'
      AND c.claim_seq_id NOT IN (SELECT c.claim_seq_id
                                 FROM CLM_BATCH_UPLOAD_DETAILS b
                                 JOIN CLM_AUTHORIZATION_DETAILS c ON b.clm_batch_seq_id = c.clm_batch_seq_id
                                 JOIN PAT_ACTIVITY_DETAILS p ON p.CLAIM_SEQ_ID = c.CLAIM_SEQ_ID
                                 WHERE p.CODE IN ('PHARMA', 'ACTIVITY')
                                 AND c.benifit_type = 'OPTS'
                                 AND c.clm_status_type_id = 'INP'
                                 --AND c.claim_type = 'CNH'
                                 AND TRUNC(c.added_date) BETWEEN TRUNC(SYSDATE) - 1 AND TRUNC(SYSDATE)
                                )
      AND c.benifit_type = 'OPTS'
      --AND c.claim_type = 'CNH'
      AND NVL(c.cal_act_yn, 'N') = 'N'
      AND c.clm_status_type_id = 'INP'
      AND TRUNC(c.added_date) BETWEEN TRUNC(SYSDATE) - 1 AND TRUNC(SYSDATE)

      MINUS

      SELECT c.claim_number, c.claim_seq_id, c.added_by, h.hosp_seq_id
      FROM Clm_Batch_Upload_Details b
      JOIN Clm_Authorization_Details c ON c.clm_batch_seq_id = b.clm_batch_seq_id
      JOIN Pat_Activity_Details pa ON pa.claim_seq_id = c.claim_seq_id
      JOIN Clm_Hospital_Details h ON h.claim_seq_id = c.claim_seq_id
      LEFT JOIN Tpa_Activity_Details a ON a.activity_code = pa.code
      WHERE  a.master_activity_code != '9'
      AND c.benifit_type = 'OPTS'
      --AND c.claim_type = 'CNH'
      AND NVL(c.cal_act_yn, 'N') = 'N'
      AND c.clm_status_type_id = 'INP'
      AND TRUNC(c.added_date) BETWEEN TRUNC(SYSDATE) - 1 AND TRUNC(SYSDATE);

      clm_rec              clm_cur%ROWTYPE;
      v_status             VARCHAR2(10);
      v_allowed_amount     CLM_AUTHORIZATION_DETAILS.TOT_ALLOWED_AMOUNT%TYPE;
      v_result_set         SYS_REFCURSOR;
      v_rows_processed     NUMBER;
      v_sql_errm           VARCHAR2(500);
      v_sql_code           VARCHAR2(100);
  BEGIN
    FOR i IN consultation_cur LOOP

    BEGIN    
       claim_pkg.calculate_authorization(i.claim_seq_id, i.hosp_seq_id, v_allowed_amount, v_result_set, i.added_by);
    EXCEPTION

     WHEN OTHERS THEN
       v_sql_code := SQLCODE;
       v_sql_errm := SQLERRM;
       INSERT INTO APP.AUTO_CAL_EXCEPTIONS_LOG 
         (CLAIM_SEQ_ID,EXECPTION_MESG,EXCEPTION_NUMBER,ADDED_DATE)  VALUES 
         (i.claim_seq_id ,v_sql_errm,v_sql_code,SYSDATE);   
    END ;

      OPEN clm_cur(i.claim_seq_id);
      FETCH clm_cur INTO clm_rec;
      CLOSE clm_cur;

      IF clm_rec.tot_allowed_amount > 0 THEN
        v_status := 'APR';
      ELSE
        v_status := 'REJ';
      END IF;

      claim_pkg.save_settlement(i.claim_seq_id, 
                                clm_rec.member_seq_id, 
                                clm_rec.settlement_number, 
                                clm_rec.date_of_hospitalization,
                                clm_rec.tot_allowed_amount,
                                NULL, --v_source_type_id
                                v_status, --v_clm_status_type_id
                                NULL, --v_remarks
                                i.added_by,
                                clm_rec.fnl_amt_currency_type,
                                NULL, --v_clm_remark
                                NULL, --v_internal_remarks
                                v_rows_processed
                               );

      UPDATE CLM_AUTHORIZATION_DETAILS C
      SET C.PROCESSED_BY = 1
      WHERE C.CLAIM_SEQ_ID = i.claim_seq_id;
    END LOOP;
     commit;
  END auto_claim_adjudication;

/

--------------------------------------------------------
--  DDL for Synonymn DESTINATION_MESSAGE_RCPT_BAK1
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."DESTINATION_MESSAGE_RCPT_BAK1" FOR "APP"."DESTINATION_MESSAGE_RCPT_BAK1";

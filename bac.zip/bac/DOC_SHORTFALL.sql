--------------------------------------------------------
--  DDL for Synonymn DOC_SHORTFALL
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."DOC_SHORTFALL" FOR "APP"."DOC_SHORTFALL";

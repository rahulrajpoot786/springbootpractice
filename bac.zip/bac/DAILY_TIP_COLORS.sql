--------------------------------------------------------
--  DDL for Synonymn DAILY_TIP_COLORS
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."DAILY_TIP_COLORS" FOR "APP"."DAILY_TIP_COLORS";

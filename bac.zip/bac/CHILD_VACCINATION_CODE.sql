--------------------------------------------------------
--  DDL for Synonymn CHILD_VACCINATION_CODE
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."CHILD_VACCINATION_CODE" FOR "APP"."CHILD_VACCINATION_CODE";

--------------------------------------------------------
--  DDL for Synonymn IDX_CLMENRL_MEMSEQ
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."IDX_CLMENRL_MEMSEQ" FOR "APP"."IDX_CLMENRL_MEMSEQ";

--------------------------------------------------------
--  DDL for Synonymn FN_QURY
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."FN_QURY" FOR "APP"."FN_QURY";

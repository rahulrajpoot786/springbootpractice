--------------------------------------------------------
--  DDL for Synonymn DEBIT_CLAIM_TRANS_SEQ
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."DEBIT_CLAIM_TRANS_SEQ" FOR "FIN_APP"."DEBIT_CLAIM_TRANS_SEQ";

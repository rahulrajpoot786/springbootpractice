--------------------------------------------------------
--  DDL for Synonymn CARD_BATCH_PKG
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."CARD_BATCH_PKG" FOR "APP"."CARD_BATCH_PKG";

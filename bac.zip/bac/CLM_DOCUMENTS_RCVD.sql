--------------------------------------------------------
--  DDL for Synonymn CLM_DOCUMENTS_RCVD
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."CLM_DOCUMENTS_RCVD" FOR "APP"."CLM_DOCUMENTS_RCVD";

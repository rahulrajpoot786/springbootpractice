--------------------------------------------------------
--  DDL for Synonymn HOSP_GROUP_SEQ
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."HOSP_GROUP_SEQ" FOR "APP"."HOSP_GROUP_SEQ";

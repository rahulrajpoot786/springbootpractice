--------------------------------------------------------
--  DDL for Synonymn DMS_MIGRATION_PKG
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."DMS_MIGRATION_PKG" FOR "APP"."DMS_MIGRATION_PKG";

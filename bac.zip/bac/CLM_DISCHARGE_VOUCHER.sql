--------------------------------------------------------
--  DDL for Synonymn CLM_DISCHARGE_VOUCHER
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."CLM_DISCHARGE_VOUCHER" FOR "APP"."CLM_DISCHARGE_VOUCHER";

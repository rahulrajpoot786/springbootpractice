--------------------------------------------------------
--  DDL for Synonymn BANK_TRANSACTION_SEQ
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."BANK_TRANSACTION_SEQ" FOR "APP"."BANK_TRANSACTION_SEQ";

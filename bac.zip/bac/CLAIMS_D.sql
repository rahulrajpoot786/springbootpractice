--------------------------------------------------------
--  DDL for Synonymn CLAIMS_D
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."CLAIMS_D" FOR "APP"."CLAIMS_D";

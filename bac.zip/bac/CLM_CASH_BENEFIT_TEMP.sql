--------------------------------------------------------
--  DDL for Synonymn CLM_CASH_BENEFIT_TEMP
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."CLM_CASH_BENEFIT_TEMP" FOR "APP"."CLM_CASH_BENEFIT_TEMP";

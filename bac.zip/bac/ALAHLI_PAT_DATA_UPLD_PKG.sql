--------------------------------------------------------
--  DDL for Package Body ALAHLI_PAT_DATA_UPLD_PKG
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "VENUBABU"."ALAHLI_PAT_DATA_UPLD_PKG" 
AS

-------******SAVE XML  DATA TO TABLE******---------------

PROCEDURE SAVE_PRE_AUTH_XML (
                            
                             v_pat_in_xl             IN  XMLTYPE,
                             v_result_set            OUT SYS_REFCURSOR 
                            )
 IS
 
  PRAGMA AUTONOMOUS_TRANSACTION;

  v_sql_code             VARCHAR2(100);
  v_sql_msg              VARCHAR2(4000);
  V_XML_SEQ_ID           NUMBER(10);
  v_error_exst_yn        VARCHAR2(100);
  
BEGIN
   
  INSERT INTO APP.PAT_XML_UPLD_DTA(
                                   XML_SEQ_ID,
                                   XML_DATA,
                                   UPLOAD_YN,
                                   SUCCESS_YN,
                                   ADDED_DATE                              
                                   )
                           VALUES (
                                  app.pat_xml_seq.nextval,
                                   v_pat_in_xl,
                                   'Y',
                                   'N',
                                   SYSDATE
                                  )
                              RETURNING XML_SEQ_ID INTO V_XML_SEQ_ID;

   COMMIT;
   
   
 PARSE_PAT_XML_DTLS   (   
  
                       V_XML_SEQ_ID  
                      
                       );
					   
					   
   v_error_exst_yn   :=    ERROR_EXIST_YN(V_XML_SEQ_ID); -----CHECKING ERROR
 
   IF    v_error_exst_yn  = 'N'  THEN
     
-------FOR SUCCESS RESPONSE	

     OPEN v_result_set  FOR 
       SELECT A.PRE_AUTH_NUMBER  AS PREAUTH_NO,
              CASE WHEN   A.PAT_STATUS_TYPE_ID = 'INP' THEN 'IN-PROGRESS' END    AS PREAUTH_STATUS,
              'SUCCESS'   AS SUCCESS_YN
         FROM   APP.PAT_AUTHORIZATION_DETAILS A
          WHERE A.XML_SEQ_ID = V_XML_SEQ_ID;
          
    ELSE 
 
----------FOR ERROR RESPONSE
 
      OPEN v_result_set  FOR 
       SELECT A.USER_DEFINED_ERROR_MSG  AS ERROR_MSG,            
              'FAIL'   AS SUCCESS_YN
         FROM   APP.PAT_EXCEPTION_LOGS A
          WHERE A.XML_SEQ_ID = V_XML_SEQ_ID
          ORDER BY A.LOG_SEQ_ID;
                           
    END IF;                      
         
  
EXCEPTION
   
  WHEN OTHERS THEN
    
     V_SQL_CODE := SQLCODE;
     V_SQL_MSG  := SQLERRM;

     create_exception_log(v_xml_seq_id,V_SQL_CODE,V_SQL_MSG,V_SQL_MSG,1,NULL); 
     
     OPEN v_result_set  FOR 
       SELECT 'INVALID XML FORMAT'  AS ERROR_MSG,            
              'FAIL'   AS SUCCESS_YN
         FROM   DUAL;
         
 END SAVE_PRE_AUTH_XML;
 
  ------*******PARSE AND VALIDATION AND SAVE*******-------
 
 PROCEDURE   PARSE_PAT_XML_DTLS  (
                                  
                                 V_XML_SEQ_ID  IN PAT_XML_UPLD_DTA.XML_SEQ_ID%TYPE 
                                 
                                 )
                                 
IS

  CURSOR xml_data_cur
  IS
  SELECT xml_data 
  FROM APP.PAT_XML_UPLD_DTA
  WHERE  xml_seq_id = v_xml_seq_id;
  
  xml_var          xmltype;

 v_pat_xml_dtls                     DBMS_XMLDOM.DOMDocument;---- Implements the DOM Document interface.
  v_pat_node                         DBMS_XMLDOM.DOMnodelist;-----Implements the DOM NodeList interface.
  v_pat_dtl                          DBMS_XMLDOM.DOMnodelist;
  v_pat_tag                          DBMS_XMLDOM.DOMnodelist;
  v_diag_tag                         DBMS_XMLDOM.DOMnodelist;------FOR DIAG
  v_parent_node                      DBMS_XMLDOM.DOMNode;    -----Implements the DOM Node interface.
  v_child_node                       DBMS_XMLDOM.DOMNode;
  v_child_node1                      DBMS_XMLDOM.DOMNode;
  v_child_node2                      DBMS_XMLDOM.DOMNode;-------------FOR DIAG
  v_element                          DBMS_XMLDOM.DOMELement;
  v_element1                         DBMS_XMLDOM.DOMELement;
  v_element2                         DBMS_XMLDOM.DOMELement;
  v_element3                         DBMS_XMLDOM.DOMELement;---------FOR DIAG
----**********TIME VALIDATION(HOUR AND MIN)****
  CURSOR  time_valid_cur(v_date  varchar2)
  IS
       SELECT (CASE WHEN REGEXP_LIKE (v_date,'^[0-9]{2}:[0-9]{2}$') THEN 
       CASE WHEN SUBSTR(v_date,1,INSTR(v_date,':',1,1)-1) <= 12 THEN 
          CASE WHEN SUBSTR(v_date,INSTR(v_date,':',1,1)+1) <= 60  THEN 1 ELSE 0 END
         ELSE 
           0 
          END
     ELSE 
      0 
      END)  A FROM DUAL;
  
  
  v_time                             NUMBER(10);     
  
  
  CURSOR icd_benefit_cur(v_code varchar2)
  IS
  SELECT ic.benefit_type
  FROM  tpa_icd10_master_details ic
  WHERE  ic.icd_code = upper(v_code); 
  
  v_icd_benefit         icd_benefit_cur%ROWTYPE;                                                  
   
----********PREAUTH GENERAL INFORMATION DETAILS*******------------- 
  v_disposition                         VARCHAR2(100);
  v_event_no                            APP.pat_authorization_details.event_no%TYPE;
  v_med_type                            APP.pat_authorization_details.system_of_medicine_type_id%TYPE;
  v_accid_rel_case                      APP.pat_authorization_details.accident_related_type_id%TYPE;
  v_tpa_enroll_id                       APP.pat_authorization_details.tpa_enrollment_id%TYPE;
  v_requested_amnt                      APP.pat_authorization_details.requested_amount%TYPE;
  v_clinician_id                        APP.pat_authorization_details.clinician_id%TYPE;
  v_clinicianname                       APP.tpa_hosp_professionals.contact_name%TYPE;
  v_benefitType                         APP.pat_authorization_details.benifit_type%TYPE;
  v_encounterType                       APP.pat_authorization_details.encounter_type_id%TYPE;  
  v_encterStrtType                      APP.pat_authorization_details.encounter_start_type%TYPE;
  v_encterEndType                       APP.pat_authorization_details.encounter_end_type%TYPE;
  v_date_of_hosp                        VARCHAR2(100);--pat_authorization_details.hospitalization_date%TYPE;
  v_date_hosp_time                      VARCHAR2(100);  
  v_hosp_time_am                        VARCHAR2(100);
  v_date_of_exit                        VARCHAR2(100);--pat_authorization_details.discharge_date%TYPE;
  v_date_dis_time                       VARCHAR2(100);
  v_dish_time_pm                        VARCHAR2(100);
  v_lmp                                 VARCHAR2(100);
  v_mode_of_delvry                      APP.pat_authorization_details.delvry_mod_type%TYPE;
  v_nat_conception                      APP.pat_authorization_details.conception_type%TYPE;
  v_pre_auth_number                     APP.pat_authorization_details.pre_auth_number%TYPE;
  v_presenting_complaints               APP.pat_authorization_details.presenting_complaints%TYPE;
  v_clinician_mail                      APP.pat_authorization_details.clinician_mail%type;------NEWLY ADDED FOR ALAHALI ENHANCEMENT
-------*******DENTAL INFORMATION DETAILS **********----------------------
   v_den_encnt_type                     APP.pat_authorization_details.treatment_type%TYPE;   
   p_dento_class_i                      APP.orthodontic_details_tab.dento_class_i%TYPE;
   p_dento_class_ii                     APP.orthodontic_details_tab.dento_class_ii%TYPE;
   p_dento_class_ii_text                APP.orthodontic_details_tab.dento_class_ii_text%TYPE;
   p_dento_class_iii                    APP.orthodontic_details_tab.dento_class_iii%TYPE;
   p_dento_class_iii_text               APP.orthodontic_details_tab.dento_class_iii_text%TYPE;
   p_skele_class_i                      APP.orthodontic_details_tab.skele_class_i%TYPE;
   p_skele_class_ii                     APP.orthodontic_details_tab.skele_class_ii%TYPE;
   p_skele_class_iii                    APP.orthodontic_details_tab.skele_class_iii%TYPE;
   p_overjet_mm                         APP.orthodontic_details_tab.overjet_mm%TYPE;
   p_rev_overjet_mm                     APP.orthodontic_details_tab.rev_overjet_mm%TYPE;
   p_rev_overjet_yn                     APP.orthodontic_details_tab.rev_overjet_yn%TYPE;
   p_crossbite_ant                      APP.orthodontic_details_tab.crossbite_ant%TYPE;
   p_crossbite_post                     APP.orthodontic_details_tab.crossbite_post%TYPE;
   p_crossbite_betw                     APP.orthodontic_details_tab.crossbite_betw%TYPE;
   p_openbit_ant                        APP.orthodontic_details_tab.openbit_ant%TYPE;
   p_openbit_post                       APP.orthodontic_details_tab.openbit_post%TYPE;
   p_openbit_late                       APP.orthodontic_details_tab.openbit_late%TYPE;
   p_cont_point_disp                    APP.orthodontic_details_tab.cont_point_disp%TYPE;
   p_overbit                            APP.orthodontic_details_tab.overbit_deep%TYPE;
   p_overbit_pata                       APP.orthodontic_details_tab.overbit_pata%TYPE;
   p_overbit_ging                       APP.orthodontic_details_tab.overbit_ging%TYPE;
   p_hypo_quad1                         APP.orthodontic_details_tab.hypo_quad1%TYPE;
   p_hypo_quad2                         APP.orthodontic_details_tab.hypo_quad2%TYPE;
   p_hypo_quad3                         APP.orthodontic_details_tab.hypo_quad3%TYPE;
   p_hypo_quad4                         APP.orthodontic_details_tab.hypo_quad4%TYPE;
   p_others_impeded                     APP.orthodontic_details_tab.others_impeded%TYPE;
   p_others_impact                      APP.orthodontic_details_tab.others_impact%TYPE;
   p_others_submerg                     APP.orthodontic_details_tab.others_submerg%TYPE;
   p_others_supernum                    APP.orthodontic_details_tab.others_supernum%TYPE;
   p_others_retaine                     APP.orthodontic_details_tab.others_retaine%TYPE;
   p_others_ectopic                     APP.orthodontic_details_tab.others_ectopic%TYPE;
   p_others_cranio                      APP.orthodontic_details_tab.others_cranio%TYPE;
   p_ac_marks                           APP.orthodontic_details_tab.ac_marks%TYPE;
   p_crossbite_ant_mm	                  APP.orthodontic_details_tab.crossbite_ant_mm%TYPE;
   p_crossbite_prst_mm	                APP.orthodontic_details_tab.crossbite_prst_mm%TYPE;
	 p_crossbite_betw_mm	                APP.orthodontic_details_tab.crossbite_betw_mm%TYPE;
   p_cont_point_disp_mm	                APP.orthodontic_details_tab.cont_point_disp_mm%TYPE;
 
-------******DIAGNOSYS INFORMATION DETIALS*********----------------------  
  v_diag_code_prim                     APP.diagnosys_details.diagnosys_code%TYPE;
  v_diag_code_scnd                     APP.diagnosys_details.diagnosys_code%TYPE;
  v_duration_ailment                   APP.pat_authorization_details.dur_ailment%TYPE;  
  v_duration_flag                      APP.pat_authorization_details.duration_flag%TYPE;
  
-------******ACTIVITY INFORMATION DETAILS**********-----------------------  

   v_activity_type                      APP.pat_activity_details.activity_type%TYPE;
   v_service_type                       APP.pat_activity_details.service_type%TYPE;
   v_start_date                         VARCHAR2(100); -----pat_activity_details.start_date%TYPE;
   v_modifier                           APP.pat_activity_details.modifier%TYPE;
   v_int_code                           APP.pat_activity_details.internal_code%TYPE;
   v_unit_type                          APP.pat_activity_details.unit_type%TYPE;
   v_dur_days                           APP.pat_activity_details.posology_duration%TYPE;
   v_quantity                           APP.pat_activity_details.quantity%TYPE;
   v_posology                           APP.pat_activity_details.posology%TYPE;
   v_unit_price                         APP.pat_activity_details.unit_price%TYPE;
   v_discount_amt                       APP.pat_activity_details.discount_amount%TYPE;
   v_allow_yn                           APP.pat_activity_details.allow_yn%TYPE;
   
   ----------------------------------
   v_pat_ath_seq_id                     APP.pat_authorization_details.pat_auth_seq_id%TYPE;
   p_ortho_seq_id                       APP.ORTHODONTIC_DETAILS_TAB.ORTHO_SEQ_ID%TYPE;                  
   
/* mem_count                            NUMBER(10);
   med_type_count                       NUMBER(10);
   benefit_count                        NUMBER(10);*/
   v_count                              NUMBER;
   v_spec_char_cnt                      NUMBER;
   v_spec_char                          NUMBER;
   v_event_len                          NUMBER;
/*   v_amnt_cnt                           NUMBER;
   v_clin_id_cnt                        NUMBER;
   v_accid_count                        NUMBER; */
   v_time_valid                         NUMBER; 
   v_mm                                 NUMBER;
   v_date                               NUMBER;  
   v_leap_year                          VARCHAR2(10);  
   v_error_exst_yn                      VARCHAR2(5); 
   v_flag_valid                         NUMBER;
   v_hosp_time1                         VARCHAR2(100);
   v_fin_hosp_time1                     DATE;
   v_dis_time1                          VARCHAR2(100); 
   v_fin_dis_time1                      DATE;
   v_rows_processed                     NUMBER; 
   V_SQL_CODE                           VARCHAR2(100);
   V_SQL_MSG                            VARCHAR2(4000);
   v_dis                                NUMBER;
   V_YN                                 VARCHAR2(10);
   V_YN1                                VARCHAR2(10);
   v_dest_msg_seq_id                    NUMBER;
   V_CONS_ACT_CNT                       NUMBER(5); 
   
  CURSOR pat_diag_cur(v_seq_id  number)
  IS
  SELECT count(1) 
  FROM diagnosys_details dd
  WHERE dd.pat_auth_seq_id=v_seq_id;
  
  v_diag_count                          NUMBER;         
      
  /* V_ENCONT_COUNT                       NUMBER;
   */
BEGIN

  OPEN  xml_data_cur;
  FETCH xml_data_cur  INTO xml_var;
  CLOSE xml_data_cur;
  
 
-------*************PREAUTH GENERAL INFORAMTION PARSING AND DATA VALIADTION***********-------------

v_pat_xml_dtls   := dbms_xmldom.newdomdocument(xml_var);  ------Creates a new document

v_pat_node       := dbms_xmldom.getelementsbytagname(v_pat_xml_dtls, 'disposition');
v_parent_node    := dbms_xmldom.getfirstchild(dbms_xmldom.item(v_pat_node, 0));
v_disposition    := dbms_xmldom.getnodevalue(v_parent_node);

---------------

IF   v_disposition IS NULL THEN 
  
    create_exception_log(v_xml_seq_id,NULL,NULL,'disposition:DISPOSITION FIELD IS BLANK',1,v_disposition);

END IF;

IF   v_disposition IS  NOT NULL THEN 
  
  v_dis   :=  case when trim(upper(v_disposition)) = 'A' THEN  1 ELSE 0 END;
  
  IF v_dis = 0 THEN  

    create_exception_log(v_xml_seq_id,NULL,NULL,'disposition:DISPOSITION FIELD DATA IS INVALID',1,NULL);
  
  END IF;
  
END IF;


----------------

v_pat_node       := dbms_xmldom.getelementsbytagname(v_pat_xml_dtls, 'eventRefNo');
v_parent_node    := dbms_xmldom.getfirstchild(dbms_xmldom.item(v_pat_node, 0));
v_event_no       := dbms_xmldom.getnodevalue(v_parent_node);

-----------------------------------
IF v_event_no IS NOT NULL THEN 
  
      SELECT count(1) INTO v_spec_char_cnt FROM DUAL
      WHERE REGEXP_LIKE(trim(v_event_no), '^\d+(\\d+)?$', '');
        
      IF v_spec_char_cnt = 0 THEN        
       create_exception_log(v_xml_seq_id,NULL,NULL,'eventRefNo:EVENT NUMBER SHOULD BE NUMBER FORMAT',1,v_event_no);
      END IF;
      
      SELECT length(trim(v_event_no)) INTO v_event_len
      FROM DUAL;
      
      IF v_event_len != 7 THEN
        create_exception_log(v_xml_seq_id,NULL,NULL,'eventRefNo:EVENT NUMBER LENGTH SHOULD BE 7',1,v_event_no);    
      END IF;
      
END IF;
-----------------------------------
v_pat_node       := dbms_xmldom.getelementsbytagname(v_pat_xml_dtls, 'systemOfMedicine');
v_parent_node    := dbms_xmldom.getfirstchild(dbms_xmldom.item(v_pat_node, 0));
v_med_type       := dbms_xmldom.getnodevalue(v_parent_node);

------------------------
IF  v_med_type IS NULL THEN 
  
     create_exception_log(v_xml_seq_id,NULL,NULL,'systemOfMedicine:SYSTEM OF MEDICINE IS BLANK',1,v_med_type);   

END IF;

IF  v_med_type IS NOT  NULL THEN 
  
    SELECT COUNT(1)  INTO V_COUNT
    FROM  TPA_GENERAL_CODE 
    WHERE HEADER_TYPE ='SYSTEM_OF_MEDICINE' 
    AND  GENERAL_TYPE_ID = TRIM(UPPER(v_med_type));
  
    IF V_COUNT = 0 THEN 
      
        create_exception_log(v_xml_seq_id,NULL,NULL,'systemOfMedicine:GIVEN INPUT ID FOR SYSTEM OF MEDICINE IS INVALID',1,v_med_type);  
     
    END IF; 

END IF;
-----------------------------------
v_pat_node       := dbms_xmldom.getelementsbytagname(v_pat_xml_dtls, 'accidentRelatedCases');
v_parent_node    := dbms_xmldom.getfirstchild(dbms_xmldom.item(v_pat_node, 0));
v_accid_rel_case := dbms_xmldom.getnodevalue(v_parent_node);

--------------------------------------------
IF v_accid_rel_case IS NOT NULL THEN
   
    SELECT COUNT(1) INTO V_COUNT
    FROM APP.TPA_GENERAL_CODE GC
    WHERE GC.HEADER_TYPE='AIL_CLAIM_TYPE' 
    AND GENERAL_TYPE_ID  IN ('NMLC','CLN','CLC')
    AND UPPER(GENERAL_TYPE_ID) = TRIM(UPPER(v_accid_rel_case));
    
   IF   V_COUNT = 0 THEN 
     
       create_exception_log(v_xml_seq_id,NULL,NULL,'accidentRelatedCases:GIVEN INPUT ID FOR ACCIDENTAL CASE IS INVALID',1,v_accid_rel_case);  
     
   END IF;
   
END IF;
-----------------------------------------------------

v_pat_node       := dbms_xmldom.getelementsbytagname(v_pat_xml_dtls, 'alKootID');
v_parent_node    := dbms_xmldom.getfirstchild(dbms_xmldom.item(v_pat_node, 0));
v_tpa_enroll_id  := dbms_xmldom.getnodevalue(v_parent_node);

-------------------------------
IF v_tpa_enroll_id IS NULL THEN 

  create_exception_log(v_xml_seq_id,NULL,NULL,'alKootID:ALKOOT ID IS BLANK',1,v_tpa_enroll_id);
  
END IF;  

IF v_tpa_enroll_id IS NOT NULL THEN 
  
     SELECT COUNT(1) INTO V_COUNT
    FROM  APP.tpa_enr_policy_member A
      JOIN   APP.tpa_enr_policy_group B ON (A.policy_group_seq_id = B.policy_group_seq_id)
      JOIN   APP.tpa_enr_policy C ON (B.policy_seq_id = C.policy_seq_id )
      WHERE A.MEMBER_SEQ_ID = (SELECT MAX(MEMBER_SEQ_ID) FROM APP.TPA_ENR_POLICY_MEMBER 
                              WHERE TPA_ENROLLMENT_ID  = TRIM(v_tpa_enroll_id))
           AND A.DELETED_YN = 'N' AND C.COMPLETED_YN ='Y';
     /*SELECT count(1) into V_COUNT
     FROM APP.TPA_ENR_POLICY_MEMBER  
     WHERE MEMBER_SEQ_ID = (SELECT MAX(MEMBER_SEQ_ID) FROM APP.TPA_ENR_POLICY_MEMBER 
                              WHERE TPA_ENROLLMENT_ID  = TRIM(v_tpa_enroll_id))
      AND DELETED_YN = 'N';*/
                              
    IF  V_COUNT = 0  THEN 
      
      create_exception_log(v_xml_seq_id,NULL,NULL,'alKootID:ALKOOT ID IS NOT VALID OR ALKOOT ID IS NOT EXIST',1,v_tpa_enroll_id);                         
 
    END IF;
    
END IF;
--------*****requestedAmount  
begin
  
v_pat_node       := dbms_xmldom.getelementsbytagname(v_pat_xml_dtls, 'requestedAmount');
v_parent_node    := dbms_xmldom.getfirstchild(dbms_xmldom.item(v_pat_node, 0));
v_requested_amnt := dbms_xmldom.getnodevalue(v_parent_node);

IF v_requested_amnt IS NULL THEN 
  
       create_exception_log(v_xml_seq_id,NULL,NULL,'requestedAmount:REQUESTED AMOUNT IS BLANK',1,v_requested_amnt); 

END IF;

/*IF v_requested_amnt IS  NOT NULL THEN 
      
      SELECT count(1) INTO V_COUNT FROM DUAL
      WHERE REGEXP_LIKE(v_requested_amnt, '^\d+(\\d+)?$', '');
      
      IF V_COUNT = 0 THEN 
   
        create_exception_log(v_xml_seq_id,NULL,NULL,'requestedAmount:REQUESTED AMOUNT MUST BE NUMERIC',1,v_requested_amnt); 
        
      END IF;
      
END IF; */

EXCEPTION
  
WHEN OTHERS THEN
    
  create_exception_log(v_xml_seq_id,NULL,NULL,'requestedAmount:REQUESTED AMOUNT IS INVALID',1,v_requested_amnt);                         
 
end ;

------------------------------
/*IF v_requested_amnt IS  NOT NULL THEN 
      
      SELECT count(1) INTO V_COUNT FROM DUAL
      WHERE REGEXP_LIKE(v_requested_amnt, '^\d+(\\d+)?$', '');
      
      IF V_COUNT = 0 THEN 
   
        create_exception_log(v_xml_seq_id,NULL,NULL,'requestedAmount:REQUESTED AMOUNT MUST BE NUMERIC',1,NULL); 
        
      END IF;
      
END IF;*/      
--------------------------------------------------

v_pat_node       := dbms_xmldom.getelementsbytagname(v_pat_xml_dtls, 'clinicianId');
v_parent_node    := dbms_xmldom.getfirstchild(dbms_xmldom.item(v_pat_node, 0));
v_clinician_id   := dbms_xmldom.getnodevalue(v_parent_node);

----------------
/*IF v_clinician_id IS NULL THEN 
  
       create_exception_log(v_xml_seq_id,NULL,NULL,'clinicianId:CLINICIAN ID FIELD IS BLANK',1,v_clinician_id); 

END IF;*/

----NEED TO COMMENT UNTIL CONFIRMATION
/*
IF v_clinician_id IS NOT NULL THEN -----------AS PER THE REQUIREMENT WE ARE COMMENTING THE CODE
  
    SELECT count(1) INTO  V_COUNT 
    FROM APP.TPA_HOSP_PROFESSIONALS A
    JOIN APP.TPA_HOSP_INFO B ON (A.HOSP_SEQ_ID = B.HOSP_SEQ_ID)
    WHERE UPPER(A.PROFESSIONAL_ID) = TRIM(UPPER(v_clinician_id))
    AND UPPER(B.HOSP_NAME) LIKE  '%AL AHLI HOSPITAL%';
  
   SELECT COUNT(1) INTO  V_COUNT 
    FROM APP.TPA_HOSP_PROFESSIONALS A
    WHERE UPPER(A.PROFESSIONAL_ID) = TRIM(UPPER(v_clinician_id));
    
  IF V_COUNT = 0 THEN 
      
       create_exception_log(v_xml_seq_id,NULL,NULL,'clinicianId:CLINICIAN ID FOR THIS PROVIDER IS INVALID',1,v_clinician_id); 

    END IF;
    
END IF;   */ 

-------------------------------
v_pat_node       := dbms_xmldom.getelementsbytagname(v_pat_xml_dtls, 'clinicianName');
v_parent_node    := dbms_xmldom.getfirstchild(dbms_xmldom.item(v_pat_node, 0));
v_clinicianname  := dbms_xmldom.getnodevalue(v_parent_node);


v_pat_node       := dbms_xmldom.getelementsbytagname(v_pat_xml_dtls, 'clinicianMail');
v_parent_node    := dbms_xmldom.getfirstchild(dbms_xmldom.item(v_pat_node, 0));
v_clinician_mail := dbms_xmldom.getnodevalue(v_parent_node);  ------NEWLY ADDED FOR ALAHALI ENHANCEMENT



v_pat_node       := dbms_xmldom.getelementsbytagname(v_pat_xml_dtls, 'benefitType');
v_parent_node    := dbms_xmldom.getfirstchild(dbms_xmldom.item(v_pat_node, 0));
v_benefitType    := dbms_xmldom.getnodevalue(v_parent_node);

-------------------------------
IF v_benefitType IS NULL THEN 

    create_exception_log(v_xml_seq_id,NULL,NULL,'benefitType:BENEFIT TYPE  IS BLANK',1,v_benefitType);
  
END IF;  

IF v_benefitType IS NOT NULL THEN 
  
      SELECT COUNT(1) INTO V_COUNT
      FROM  TPA_GENERAL_CODE 
      WHERE  HEADER_TYPE = 'BENIFIT_TYPE' 
      AND  GENERAL_TYPE_ID = TRIM(UPPER(v_benefitType));
                              
    IF  V_COUNT = 0  THEN 
      
      create_exception_log(v_xml_seq_id,NULL,NULL,'benefitType:BENEFIT TYPE IS INVALID',1,v_benefitType);                         
 
    END IF;
    
END IF;

--------*****encounterType
BEGIN
  
v_pat_node       := dbms_xmldom.getelementsbytagname(v_pat_xml_dtls, 'encounterType');
v_parent_node    := dbms_xmldom.getfirstchild(dbms_xmldom.item(v_pat_node, 0));
v_encounterType  := dbms_xmldom.getnodevalue(v_parent_node);


-------------------
IF v_encounterType IS NOT NULL THEN
  
        SELECT COUNT(1) INTO V_COUNT
        FROM APP.TPA_ENCOUNTER_TYPE_CODES
        WHERE HEADER_TYPE = 'ENCOUNTER_TYPE'  AND ENCOUNTER_SEQ_ID = TRIM(v_encounterType); 
   
       IF V_COUNT = 0 THEN 
       
        create_exception_log(v_xml_seq_id,NULL,NULL,'encounterType:ENCOUNTER TYPE ID IS INVALID',1,v_encounterType);
        
     END IF;

END IF; 

EXCEPTION
  
   WHEN OTHERS THEN
 
       create_exception_log(v_xml_seq_id,NULL,NULL,'encounterType:ENCOUNTER TYPE ID-DATA- IS INVALID',1,v_encounterType);
       
END;
-------------------
/*IF v_encounterType IS NOT NULL THEN
  
        SELECT COUNT(1) INTO V_COUNT
        FROM APP.TPA_ENCOUNTER_TYPE_CODES
        WHERE HEADER_TYPE = 'ENCOUNTER_TYPE'  AND ENCOUNTER_SEQ_ID = TRIM(v_encounterType); 
   
       IF V_COUNT = 0 THEN 
       
        create_exception_log(v_xml_seq_id,NULL,NULL,'encounterType:ENCOUNTER TYPE ID IS INVALID',1,NULL);
        
     END IF;

END IF; */
--------********encounterStartType
BEGIN
  
v_pat_node       := dbms_xmldom.getelementsbytagname(v_pat_xml_dtls, 'encounterStartType');
v_parent_node    := dbms_xmldom.getfirstchild(dbms_xmldom.item(v_pat_node, 0));
v_encterStrtType := dbms_xmldom.getnodevalue(v_parent_node);

IF v_encterStrtType IS NOT NULL THEN
  
        SELECT COUNT(1) INTO V_COUNT
        FROM APP.TPA_ENCOUNTER_TYPE_CODES
        WHERE HEADER_TYPE = 'ENCOUNTER_START_TYPE'  AND ENCOUNTER_SEQ_ID = TRIM(v_encterStrtType); 
   
       IF V_COUNT = 0 THEN 
       
        create_exception_log(v_xml_seq_id,NULL,NULL,'encounterStartType:ENCOUNTER START TYPE ID IS INVALID',1,v_encterStrtType);
        
     END IF;

END IF;

EXCEPTION
  
   WHEN OTHERS THEN
 
       create_exception_log(v_xml_seq_id,NULL,NULL,'encounterStartType:ENCOUNTER START TYPE ID-DATA- IS INVALID',1,v_encterStrtType);
       
END;

  
--------*******encounterEndType
BEGIN
  
v_pat_node       := dbms_xmldom.getelementsbytagname(v_pat_xml_dtls, 'encounterEndType');
v_parent_node    := dbms_xmldom.getfirstchild(dbms_xmldom.item(v_pat_node, 0));
v_encterEndType  := dbms_xmldom.getnodevalue(v_parent_node);

-------
IF v_encterEndType IS NULL THEN 
  
     create_exception_log(v_xml_seq_id,NULL,NULL,'encounterEndType:ENCOUNTER END TYPE FIELD IS BLANK',1,v_encterEndType);
     
END IF;   

IF  v_encterEndType IS NOT NULL THEN 
  
        SELECT COUNT(1) INTO V_COUNT
        FROM APP.TPA_ENCOUNTER_TYPE_CODES
        WHERE HEADER_TYPE = 'ENCOUNTER_END_TYPE'  AND ENCOUNTER_SEQ_ID = TRIM(v_encterEndType);  

     IF V_COUNT = 0 THEN 
       
        create_exception_log(v_xml_seq_id,NULL,NULL,'encounterEndType:ENCOUNTER END TYPE ID IS INVALID',1,v_encterEndType);
        
     END IF;
        
END IF;

EXCEPTION
  
   WHEN OTHERS THEN 
     
       create_exception_log(v_xml_seq_id,NULL,NULL,'encounterEndType:ENCOUNTER END TYPE ID IS INVALID',1,NULL);
       
END;       
---------------------------------------

v_pat_node       := dbms_xmldom.getelementsbytagname(v_pat_xml_dtls, 'startDateFormat');
v_parent_node    := dbms_xmldom.getfirstchild(dbms_xmldom.item(v_pat_node, 0));
v_pat_node       := dbms_xmldom.getelementsbytagname(v_pat_xml_dtls, 'startDate');
v_parent_node    := dbms_xmldom.getfirstchild(dbms_xmldom.item(v_pat_node, 0));
v_date_of_hosp   := dbms_xmldom.getnodevalue(v_parent_node);

--------------------------------------------
IF v_date_of_hosp  IS NULL THEN 
  
      create_exception_log(v_xml_seq_id,NULL,NULL,'startDate:START DATE OR DATE OF HOSPITALIZATION FIELD IS BLANK',1,v_date_of_hosp);                     
  
END IF;

IF v_date_of_hosp  IS NOT NULL THEN 
  

      SELECT  count(1) INTO V_COUNT
      FROM  dual
      WHERE regexp_like(trim(v_date_of_hosp), '[[:digit:]]{2}/[[:digit:]]{2}/[[:digit:]]{4}') AND
        '0' =(   select 
                    case when  to_number(substr(trim(v_date_of_hosp), 4, 2)) BETWEEN '01' AND '12'  AND
                              to_number(substr(trim(v_date_of_hosp),instr(trim(v_date_of_hosp),'/',1,2)+1))  BETWEEN '1900' AND '2050' 
                              then '0' else '1' 
                                  end a 
                                  from dual );
       
      
    --   (substr(v_date_of_hosp, 4, 2) BETWEEN '01' AND '12'  AND
       ---   substr(v_date_of_hosp, 7, 4)  BETWEEN '1900' AND '2050'  --and
      --- substr('2018/12/32', 9, 2)  between '01' and '31'
         --  );   --------GIVEN FORMAT AND MONTH AND YEAR (IN DATE) VALIDATION
           
     IF  V_COUNT = 0 THEN 
       
          create_exception_log(v_xml_seq_id,NULL,NULL,'startDate:START DATE OR DATE OF HOSPITALIZATION FIELD IS INVALID',1,v_date_of_hosp);                          
      
     END IF;
          
     IF V_COUNT = 1 THEN  --------------GIVEN DAY (IN DATE) VALIDATION
       
     SELECT SUBSTR(trim(v_date_of_hosp),INSTR(trim(v_date_of_hosp),'/',1,1)+1,2) INTO V_MM
     FROM DUAL;
     
     IF V_MM = 02 THEN 
     
          v_leap_year  := FN_LEAP_YEAR(trim(v_date_of_hosp));
          
     END IF;          
     
        v_date :=     CASE WHEN V_MM = 01  THEN  31
                           WHEN V_MM = 02  THEN   CASE WHEN v_leap_year = 'Y' THEN 
                                                              29 
                                                             ELSE 
                                                              28
                                                             END
                           WHEN V_MM = 03  THEN  31
                           WHEN V_MM = 04  THEN  30 
                           WHEN V_MM = 05  THEN  31
                           WHEN V_MM = 06  THEN  30
                           WHEN V_MM = 07  THEN  31
                           WHEN V_MM = 08  THEN  31
                           WHEN V_MM = 09  THEN  30
                           WHEN V_MM = 10  THEN  31
                           WHEN V_MM = 11  THEN  30
                           WHEN V_MM = 12  THEN  31
                       END ;
      
      SELECT  count(1) INTO V_COUNT
      FROM  DUAL
      WHERE regexp_like(trim(v_date_of_hosp), '[[:digit:]]{2}/[[:digit:]]{2}/[[:digit:]]{4}') AND
          (
          substr(trim(v_date_of_hosp), 1, 2) BETWEEN '01' AND v_date 
           );
           
            IF V_COUNT = 0 THEN 
              
                 create_exception_log(v_xml_seq_id,NULL,NULL,'startDate:START DATE OR DATE OF HOSPITALIZATION FIELD IS INVALID',1,v_date_of_hosp);                          

            END IF;
                                                                                     
     END IF;           
      
END IF;      
--------------------------------------------

-----******VALIDATION FOR RENEWAL CASE*****
begin

IF v_tpa_enroll_id IS NOT NULL THEN 
  
     SELECT COUNT(1) INTO V_COUNT
    FROM  APP.tpa_enr_policy_member A
      JOIN   APP.tpa_enr_policy_group B ON (A.policy_group_seq_id = B.policy_group_seq_id)
      JOIN   APP.tpa_enr_policy C ON (B.policy_seq_id = C.policy_seq_id )
      WHERE A.TPA_ENROLLMENT_ID = TRIM(v_tpa_enroll_id)
         AND TO_DATE(trim(v_date_of_hosp),'DD-MM-RRRR') BETWEEN   TO_DATE(C.EFFECTIVE_FROM_DATE,'DD-MM-RRRR') AND
                                                              TO_DATE(C.EFFECTIVE_TO_DATE,'DD-MM-RRRR')+1
           AND A.DELETED_YN = 'N' AND C.COMPLETED_YN ='Y'; 
     
                              
    IF  V_COUNT = 0  THEN 
      
      create_exception_log(v_xml_seq_id,V_SQL_CODE,V_SQL_MSG,'alKootID:DATE OF ADIMISSION NOT BETWEEN POLICY PERIOD',1,v_tpa_enroll_id||' '||v_date_of_hosp);                         
 
    END IF;
    
END IF;

 EXCEPTION
  
  WHEN OTHERS THEN
    
       create_exception_log(v_xml_seq_id,NULL,NULL,'alKootID,startTime:DATE OF ADIMISSION NOT BETWEEN POLICY PERIOD',1,v_den_encnt_type);
 
 END; 

v_pat_node       := dbms_xmldom.getelementsbytagname(v_pat_xml_dtls, 'startTime');
v_parent_node    := dbms_xmldom.getfirstchild(dbms_xmldom.item(v_pat_node, 0));
v_date_hosp_time := dbms_xmldom.getnodevalue(v_parent_node);

----------------
IF  v_date_hosp_time IS NULL THEN 
  
      create_exception_log(v_xml_seq_id,NULL,NULL,'startTime:TIME OF START DATE OR DATE OF HOSPITALIZATION FILED IS BLANK',1,v_date_hosp_time);                     
  
END IF;


IF  v_date_hosp_time IS NOT NULL THEN 


OPEN  time_valid_cur(trim(v_date_hosp_time));
FETCH time_valid_cur INTO v_time;
CLOSE time_valid_cur;

        IF v_time = 0  THEN
  
               create_exception_log(v_xml_seq_id,NULL,NULL,'startTime:TIME OF START DATE OR DATE OF HOSPITALIZATION FIELD DATA IS INVALID',1,v_date_hosp_time);                     

        END IF;

END IF;
 
-----------------

v_pat_node       := dbms_xmldom.getelementsbytagname(v_pat_xml_dtls, 'startAmPm');
v_parent_node    := dbms_xmldom.getfirstchild(dbms_xmldom.item(v_pat_node, 0));
v_hosp_time_am   := dbms_xmldom.getnodevalue(v_parent_node);

-----------------

IF  v_hosp_time_am IS NULL THEN 
  
      create_exception_log(v_xml_seq_id,NULL,NULL,'startAmPm:AM OR PM  OF START DATE OR DATE OF HOSPITALIZATION FILED IS BLANK',1,v_hosp_time_am);                     
  
END IF;

IF v_hosp_time_am IS NOT NULL THEN
   
      V_TIME_VALID:=  CASE WHEN TRIM(UPPER(v_hosp_time_am)) = 'AM'  THEN 1
                           WHEN TRIM(UPPER(v_hosp_time_am)) = 'PM' THEN 2
                           ELSE 0 END;
                           
      IF  V_TIME_VALID = 0 THEN   
        
         create_exception_log(v_xml_seq_id,NULL,NULL,'startAmPm:AM OR PM FOR DATE OF HOSPITALIZATION IS INVALID',1,v_hosp_time_am);                     

      END IF;
  
END IF;

-------------------------------

v_pat_node       := dbms_xmldom.getelementsbytagname(v_pat_xml_dtls, 'endDateFormat');
v_parent_node    := dbms_xmldom.getfirstchild(dbms_xmldom.item(v_pat_node, 0));
v_pat_node       := dbms_xmldom.getelementsbytagname(v_pat_xml_dtls, 'endDate');
v_parent_node    := dbms_xmldom.getfirstchild(dbms_xmldom.item(v_pat_node, 0));
v_date_of_exit   := dbms_xmldom.getnodevalue(v_parent_node);

--------------------------------------------
IF v_date_of_exit  IS NULL THEN 
  
      create_exception_log(v_xml_seq_id,NULL,NULL,'endDateFormat:END DATE OR DATE OF DISCHARGE FIELD IS BLANK',1,v_date_of_exit);                     
  
END IF;

IF v_date_of_exit  IS NOT NULL THEN 
  

      SELECT  count(1) INTO V_COUNT
      FROM  dual
      WHERE regexp_like(trim(v_date_of_exit), '[[:digit:]]{2}/[[:digit:]]{2}/[[:digit:]]{4}') AND
      '0' =(   select 
                    case when  to_number(substr(trim(v_date_of_exit), 4, 2)) BETWEEN '01' AND '12'  AND
                               to_number(substr(trim(v_date_of_exit),instr(trim(v_date_of_exit),'/',1,2)+1))  BETWEEN '1900' AND '2050' 
                              then '0' else '1' 
                                  end a 
                                  from dual );
       --  (substr(v_date_of_exit, 4, 2) BETWEEN '01' AND '12'  AND
       ---   substr(v_date_of_exit, 7, 4)  BETWEEN '1900' AND '2050'  --and
      ---- substr('2018/12/32', 9, 2)  between '01' and '31'
       ---    );   --------GIVEN FORMAT AND MONTH AND YEAR (IN DATE) VALIDATION
           
     IF  V_COUNT = 0 THEN 
       
          create_exception_log(v_xml_seq_id,NULL,NULL,'endDateFormat:DATE OF END DATE OR DATE OF DISCHARGE FIELD IS INVALID',1,v_date_of_exit);                          
      
     END IF;
          
     IF V_COUNT = 1 THEN  --------------GIVEN DAY (IN DATE) VALIDATION
       
     SELECT SUBSTR(trim(v_date_of_exit),INSTR(trim(v_date_of_exit),'/',1,1)+1,2) INTO V_MM
     FROM DUAL;
     
     IF V_MM = 02 THEN 
     
          v_leap_year  := FN_LEAP_YEAR(trim(v_date_of_exit));
          
     END IF;          
     
        v_date :=     CASE WHEN V_MM = 01  THEN  31
                           WHEN V_MM = 02  THEN   CASE WHEN v_leap_year = 'Y' THEN 
                                                             29 
                                                           ELSE 
                                                             28 
                                                           END
                           WHEN V_MM = 03  THEN  31
                           WHEN V_MM = 04  THEN  30 
                           WHEN V_MM = 05  THEN  31
                           WHEN V_MM = 06  THEN  30
                           WHEN V_MM = 07  THEN  31
                           WHEN V_MM = 08  THEN  31
                           WHEN V_MM = 09  THEN  30
                           WHEN V_MM = 10  THEN  31
                           WHEN V_MM = 11  THEN  30
                           WHEN V_MM = 12  THEN  31
                       END ;
      
      SELECT  count(1) INTO V_COUNT
      FROM  DUAL
      WHERE regexp_like(v_date_of_exit, '[[:digit:]]{2}/[[:digit:]]{2}/[[:digit:]]{4}') AND
          (
          substr(v_date_of_exit, 1, 2) BETWEEN '01' AND v_date 
           );
           
            IF V_COUNT = 0 THEN 
              
                 create_exception_log(v_xml_seq_id,NULL,NULL,'endDateFormat:END DATE OR DATE OF DISCHARGE FIELD IS INVALID',1,v_date_of_exit);                          

            END IF;
                                                                                     
     END IF;           
      
END IF;     
--------------------------------------------

v_pat_node       := dbms_xmldom.getelementsbytagname(v_pat_xml_dtls, 'endTime');
v_parent_node    := dbms_xmldom.getfirstchild(dbms_xmldom.item(v_pat_node, 0));
v_date_dis_time  := dbms_xmldom.getnodevalue(v_parent_node);

----------------------
IF  v_date_dis_time IS NULL THEN 
  
      create_exception_log(v_xml_seq_id,NULL,NULL,'endTime:TIME OF END DATE OR DATE OF DISCHARGE FIELD IS BLANK',1,v_date_dis_time);                     
  
END IF;


IF  v_date_dis_time IS NOT NULL THEN 


OPEN  time_valid_cur(trim(v_date_dis_time));
FETCH time_valid_cur INTO v_time;
CLOSE time_valid_cur;

        IF v_time = 0  THEN
  
               create_exception_log(v_xml_seq_id,NULL,NULL,'endTime:TIME OF END DATE OR DATE OF DISCHARGE FIELD DATA IS INVALID',1,v_date_dis_time);                     

        END IF;

END IF;

---------------------
v_pat_node       := dbms_xmldom.getelementsbytagname(v_pat_xml_dtls, 'endDateFormat');
v_parent_node    := dbms_xmldom.getfirstchild(dbms_xmldom.item(v_pat_node, 0));
v_pat_node       := dbms_xmldom.getelementsbytagname(v_pat_xml_dtls, 'endAmPm');
v_parent_node    := dbms_xmldom.getfirstchild(dbms_xmldom.item(v_pat_node, 0));
v_dish_time_pm   := dbms_xmldom.getnodevalue(v_parent_node);

IF  v_dish_time_pm IS NULL THEN 
  
      create_exception_log(v_xml_seq_id,NULL,NULL,'endAmPm:AM OR PM OF END DATE OR DATE OF DISCHARGE FIELD IS BLANK',1,v_dish_time_pm);                     
  
END IF;

---------------------------
IF v_dish_time_pm IS NOT NULL THEN
   
      V_TIME_VALID:=  CASE WHEN TRIM(UPPER(v_dish_time_pm)) = 'AM'  THEN 1
                           WHEN TRIM(UPPER(v_dish_time_pm)) = 'PM'  THEN 2
                           ELSE 0 END;
                           
      IF  V_TIME_VALID = 0 THEN   
        
         create_exception_log(v_xml_seq_id,NULL,NULL,'endAmPm:AM OR PM FOR END  OR DISCHARGE DATE  IS INVALID',1,v_dish_time_pm);                     

      END IF;
  
END IF;
-------------------------------

  
/* v_hosp_time1           := v_date_of_hosp||v_date_hosp_time||v_hosp_time_am;
  v_fin_hosp_time1         := to_char(to_date(v_hosp_time1 , 'dd-mm-rrrr HH:MI AM'));   ------HOSPITALIZATION DATE
  v_dis_time1              := v_date_of_exit||v_date_dis_time||v_dish_time_pm;
  v_fin_dis_time1          := to_char(to_date(v_dis_time1 , 'dd-mm-rrrr HH:MI AM'));-*/---------DISCHARGE DATE
  
  
  
IF  TRIM(v_date_of_exit) < TRIM(v_date_of_hosp)  THEN 
  
 create_exception_log(v_xml_seq_id,NULL,NULL,'endAmPm:END DATE CANNOT BE LESS THAN START DATE',1,v_date_of_exit||v_date_of_hosp);
  
END IF;


IF  TRIM(v_date_of_exit) = TRIM(v_date_of_hosp)  THEN 


V_COUNT  := CASE WHEN UPPER(TRIM(v_dish_time_pm)) = 'AM' AND UPPER(TRIM(v_hosp_time_am)) = 'PM' THEN 0    
            WHEN UPPER(TRIM(v_dish_time_pm)) = 'AM' AND UPPER(TRIM(v_hosp_time_am)) = 'AM' THEN  
              CASE WHEN regexp_replace(v_date_hosp_time,'[:punct:]') > regexp_replace(v_date_dis_time,'[:punct:]') THEN 0 ELSE 1 END  
            WHEN UPPER(TRIM(v_dish_time_pm)) = 'PM' AND UPPER(TRIM(v_hosp_time_am)) = 'PM' THEN  
              CASE WHEN regexp_replace(v_date_hosp_time,'[:punct:]') > regexp_replace(v_date_dis_time,'[:punct:]') THEN 0 ELSE 1 END 
            ELSE 1 END ;
            
            
            IF  V_COUNT = 0 THEN 
              
            create_exception_log(v_xml_seq_id,NULL,NULL,'endAmPm:END DATE CANNOT BE LESS THAN START DATE',1,
            v_date_dis_time||v_dish_time_pm||v_date_hosp_time||v_hosp_time_am);
            
            END IF;
 


END IF;

-----*****NEWLY ADDED presenting_complaints

v_pat_node       := dbms_xmldom.getelementsbytagname(v_pat_xml_dtls, 'presentingComplaints');
v_parent_node    := dbms_xmldom.getfirstchild(dbms_xmldom.item(v_pat_node, 0));
v_presenting_complaints            := dbms_xmldom.getnodevalue(v_parent_node);


    
IF  UPPER(trim(v_benefitType)) IN ('IMTI','OMTI')  THEN   ---------------MATERNITY 

v_pat_node       := dbms_xmldom.getelementsbytagname(v_pat_xml_dtls, 'dateOfLMP');
v_parent_node    := dbms_xmldom.getfirstchild(dbms_xmldom.item(v_pat_node, 0));
v_lmp            := dbms_xmldom.getnodevalue(v_parent_node);

---------
-----******AS PER THE CLIENT REQUEST WE COMMENTED*******
/*IF v_lmp IS NULL THEN 
  
     create_exception_log(v_xml_seq_id,NULL,NULL,'DateOfLMP:LMP DATE FIELD IS BLANK',1,v_lmp);                   

END IF;*/

IF v_lmp  IS NOT NULL THEN 
  

      SELECT  count(1) INTO V_COUNT
      FROM  dual
      WHERE regexp_like(trim(v_lmp), '[[:digit:]]{2}/[[:digit:]]{2}/[[:digit:]]{4}') AND
       '0' =(   select 
                    case when  to_number(substr(trim(v_lmp), 4, 2)) BETWEEN '01' AND '12'  AND
                              to_number(substr(trim(v_lmp),instr(trim(v_lmp),'/',1,2)+1))  BETWEEN '1900' AND '2050' 
                              then '0' else '1' 
                                  end a 
                                  from dual );
       
       --  (substr(v_lmp, 4, 2) BETWEEN '01' AND '12'  AND
       ---   substr(v_lmp, 7, 4)  BETWEEN '1900' AND '2050'  --and
      --- substr('2018/12/32', 9, 2)  between '01' and '31'
        --   );   --------GIVEN FORMAT AND MONTH AND YEAR (IN DATE) VALIDATION
           
     IF  V_COUNT = 0 THEN 
       
          create_exception_log(v_xml_seq_id,NULL,NULL,'DateOfLMP:LMP DATE IS INVALID',1,v_lmp);                          
      
     END IF;
          
     IF V_COUNT = 1 THEN  --------------GIVEN DAY (IN DATE) VALIDATION
       
     SELECT SUBSTR(trim(v_lmp),INSTR(trim(v_lmp),'/',1,1)+1,2) INTO V_MM
     FROM DUAL;
     
     IF V_MM = 02 THEN 
     
          v_leap_year  := FN_LEAP_YEAR(trim(v_lmp));
          
     END IF;          
     
        v_date :=     CASE WHEN V_MM = 01  THEN  31
                           WHEN V_MM = 02  THEN   CASE WHEN v_leap_year = 'Y' THEN 
                                                             29 
                                                           ELSE 
                                                             28 
                                                           END
                           WHEN V_MM = 03  THEN  31
                           WHEN V_MM = 04  THEN  30 
                           WHEN V_MM = 05  THEN  31
                           WHEN V_MM = 06  THEN  30
                           WHEN V_MM = 07  THEN  31
                           WHEN V_MM = 08  THEN  31
                           WHEN V_MM = 09  THEN  30
                           WHEN V_MM = 10  THEN  31
                           WHEN V_MM = 11  THEN  30
                           WHEN V_MM = 12  THEN  31
                       END ;
      
      SELECT  count(1) INTO V_COUNT
      FROM  DUAL
      WHERE regexp_like(trim(v_lmp), '[[:digit:]]{2}/[[:digit:]]{2}/[[:digit:]]{4}') AND
          (
          substr(trim(v_lmp), 1, 2) BETWEEN '01' AND v_date 
           );
           
            IF V_COUNT = 0 THEN 
              
                 create_exception_log(v_xml_seq_id,NULL,NULL,'dateOfLMP:LMP DATE IS INVALID',1,v_lmp);                          

            END IF;
                                                                                     
     END IF;           
      
END IF;     

-----------------------

v_pat_node       := dbms_xmldom.getelementsbytagname(v_pat_xml_dtls, 'natureOfConception');
v_parent_node    := dbms_xmldom.getfirstchild(dbms_xmldom.item(v_pat_node, 0));
v_nat_conception := dbms_xmldom.getnodevalue(v_parent_node);

-------------- 
-----******AS PER THE CLIENT REQUEST WE COMMENTED*******
/*IF v_nat_conception IS NULL THEN 
  
     create_exception_log(v_xml_seq_id,NULL,NULL,'natureOfConception:NATURE OF CONCEPTION FIELD IS BLANK',1,v_nat_conception);          

END IF;*/

IF v_nat_conception IS NOT NULL THEN 
  
  SELECT  COUNT(1)  INTO V_COUNT
  FROM  tpa_general_code A
  WHERE A.HEADER_TYPE = 'CONCEPTION_TYPE' 
  AND  UPPER(A.general_type_id)  = TRIM(UPPER(v_nat_conception));
  
  IF V_COUNT = 0 THEN 
  
     create_exception_log(v_xml_seq_id,NULL,NULL,'natureOfConception:NATURE OF CONCEPTION FIELD ID IS INVALID',1,v_nat_conception);          
  
  END IF;
  
  
END IF;

--------------

v_pat_node       := dbms_xmldom.getelementsbytagname(v_pat_xml_dtls, 'modeOfDelivery');
v_parent_node    := dbms_xmldom.getfirstchild(dbms_xmldom.item(v_pat_node, 0));
v_mode_of_delvry := dbms_xmldom.getnodevalue(v_parent_node);

--------------------
 IF v_mode_of_delvry IS NOT NULL and UPPER(trim(v_benefitType)) IN ('IMTI') THEN 
  
  SELECT  COUNT(1)  INTO V_COUNT
  FROM  tpa_general_code A
  WHERE A.HEADER_TYPE = 'MODE_DELIVERY' 
  AND  UPPER(A.general_type_id)  = TRIM(UPPER(v_mode_of_delvry));
  
     IF V_COUNT = 0 THEN 
  
        create_exception_log(v_xml_seq_id,NULL,NULL,'modeOfDelivery:MODE OF DELIVERY FIELD ID IS INVALID',1,v_mode_of_delvry);          
    
      END IF;
  
  
  END IF;

------------------
END IF;  ---------------MATERNITY 

--------BASED ON BENEFIT TYPE ENCOUNTER TYPE VALIDATION(FRONTEND)********-------------

IF   TRIM(UPPER(v_benefitType)) = 'IPT'   THEN 
  
   IF  v_encounterType is NULL  THEN 
     
    v_encounterType := 3;--------NEWLY ADDED AS IT IS NOT MANDATORY FIELD
   
   END IF;
    
  
    IF  v_encounterType NOT IN (3,4) THEN 
      
       create_exception_log(v_xml_seq_id,NULL,NULL,'encounterType:FOR THIS BENEFIT TYPE ENCOUNTERTYPE IS INVALID',1,v_benefitType||v_encounterType);

    END IF;
    
 END IF;
 
 
 IF   TRIM(UPPER(v_benefitType))= 'OPTS'   THEN 
   
    IF  v_encounterType is NULL  THEN 
     
      v_encounterType := 1;   --------NEWLY ADDED AS IT IS NOT MANDATORY FIELD
    
    END IF;
  
    IF  v_encounterType NOT IN (1,2) THEN 
      
       create_exception_log(v_xml_seq_id,NULL,NULL,'encounterType:FOR THIS BENEFIT TYPE ENCOUNTERTYPE IS INVALID',1,v_benefitType||v_encounterType);

    END IF;
    
       
 END IF;
 
 
 IF   TRIM(UPPER(v_benefitType)) = ('DNTL')   THEN 
   
    IF  v_encounterType is NULL  THEN 
     
      v_encounterType := 3;   --------NEWLY ADDED AS IT IS NOT MANDATORY FIELD
    
    END IF;
  
    IF  v_encounterType NOT IN (1,2,3,4) THEN 
      
       create_exception_log(v_xml_seq_id,NULL,NULL,'encounterType:FOR THIS BENEFIT TYPE ENCOUNTERTYPE IS INVALID',1,v_benefitType||v_encounterType);

    END IF;
    
       
 END IF;
 
 
  IF   TRIM(UPPER(v_benefitType)) = ('OPTC')   THEN 
    
    IF  v_encounterType is NULL  THEN 
     
      v_encounterType := 1;   --------NEWLY ADDED AS IT IS NOT MANDATORY FIELD
    
    END IF;
  
    IF  v_encounterType NOT IN (1,2) THEN 
      
       create_exception_log(v_xml_seq_id,NULL,NULL,'encounterType:FOR THIS BENEFIT TYPE ENCOUNTERTYPE IS INVALID',1,v_benefitType||v_encounterType);

    END IF;
    
       
 END IF;
 
 
IF   TRIM(UPPER(v_benefitType)) = 'DAYC'   THEN
  
   IF  v_encounterType is NULL  THEN 
     
      v_encounterType := 5;   --------NEWLY ADDED AS IT IS NOT MANDATORY FIELD
    
    END IF; 
  
    IF  v_encounterType NOT IN (5,6) THEN 
      
       create_exception_log(v_xml_seq_id,NULL,NULL,'encounterType:FOR THIS BENEFIT TYPE ENCOUNTERTYPE IS INVALID',1,v_benefitType||v_encounterType);

    END IF;
    
       
 END IF;
 
IF   TRIM(UPPER(v_benefitType)) = 'HEAC'   THEN 
  
    IF  v_encounterType NOT IN (7,8,9,1) THEN 
      
       create_exception_log(v_xml_seq_id,NULL,NULL,'encounterType:FOR THIS BENEFIT TYPE ENCOUNTERTYPE IS INVALID',1,v_benefitType||v_encounterType);

    END IF;
    
       
 END IF;
 
 IF  TRIM(UPPER(v_benefitType)) IN ('IEMA','PAHC')   THEN
   
    IF  v_encounterType is NULL  THEN 
     
      v_encounterType := 3;   --------NEWLY ADDED AS IT IS NOT MANDATORY FIELD
    
    END IF;  
  
    IF  v_encounterType NOT IN (3,4,13) THEN 
      
       create_exception_log(v_xml_seq_id,NULL,NULL,'encounterType:FOR THIS BENEFIT TYPE ENCOUNTERTYPE IS INVALID',1,v_benefitType||v_encounterType);

    END IF;
    
       
 END IF;
 
 IF  TRIM(UPPER(v_benefitType)) IN ('IPRE')   THEN 
   
    IF  v_encounterType is NULL  THEN 
     
      v_encounterType := 13;   --------NEWLY ADDED AS IT IS NOT MANDATORY FIELD
    
    END IF; 
  
    IF  v_encounterType NOT IN (3,4,13) THEN 
      
       create_exception_log(v_xml_seq_id,NULL,NULL,'encounterType:FOR THIS BENEFIT TYPE ENCOUNTERTYPE IS INVALID',1,v_benefitType||v_encounterType);

    END IF;
    
       
 END IF;
 
 
 IF  TRIM(UPPER(v_benefitType)) = 'IMTI'   THEN 
   
    IF  v_encounterType is NULL  THEN 
     
      v_encounterType := 3;   --------NEWLY ADDED AS IT IS NOT MANDATORY FIELD
    
    END IF;
  
    IF  v_encounterType NOT IN (3,4) THEN 
      
       create_exception_log(v_xml_seq_id,NULL,NULL,'encounterType:FOR THIS BENEFIT TYPE ENCOUNTERTYPE IS INVALID',1,v_benefitType||v_encounterType);

    END IF;
    
       
 END IF;
 
 
  IF  TRIM(UPPER(v_benefitType)) = 'OMTI'   THEN 
    
    IF  v_encounterType is NULL  THEN 
     
      v_encounterType := 1;   --------NEWLY ADDED AS IT IS NOT MANDATORY FIELD
    
    END IF;
  
    IF  v_encounterType NOT IN (1,2) THEN 
      
       create_exception_log(v_xml_seq_id,NULL,NULL,'encounterType:FOR THIS BENEFIT TYPE ENCOUNTERTYPE IS INVALID',1,v_benefitType||v_encounterType);

    END IF;
    
       
 END IF;
 
------***************DENTAL INFORMATION PARSING AND DATA VAIDATION**************---------------

IF upper(trim(v_benefitType))  =  'DNTL'  THEN 
  
BEGIN
  
v_pat_node       := dbms_xmldom.getelementsbytagname(v_pat_xml_dtls, 'treatmentType');
v_parent_node    := dbms_xmldom.getfirstchild(dbms_xmldom.item(v_pat_node, 0));
v_den_encnt_type := dbms_xmldom.getnodevalue(v_parent_node); 

----------------------------------
IF v_den_encnt_type IS NULL THEN 
  
       create_exception_log(v_xml_seq_id,NULL,NULL,'treatmentType:DENTAL TREATMENT TYPE IS BLANK',1,v_den_encnt_type);                     

END IF; 

IF v_den_encnt_type IS NOT NULL THEN
   
      SELECT COUNT(1)  INTO  V_COUNT
      FROM APP.TPA_ENCOUNTER_TYPE_CODES
      WHERE HEADER_TYPE = 'DNTL_ENCOUNTER_TYPE'  AND ENCOUNTER_SEQ_ID = TRIM(v_den_encnt_type);
      
      IF V_COUNT  = 0 THEN 
        
         create_exception_log(v_xml_seq_id,NULL,NULL,'treatmentType:DENTAL TREATMENT TYPE IS INVALID',1,v_den_encnt_type);                     
    
       END IF;
        
 END IF; 
 
 EXCEPTION
  
  WHEN OTHERS THEN
    
       create_exception_log(v_xml_seq_id,NULL,NULL,'treatmentType:DENTAL TREATMENT TYPE IS INVALID',1,v_den_encnt_type);
 
 END;  
 -------------------------------------
 
 IF TRIM(v_den_encnt_type)  IN ('1','3')  THEN
 
 --------------dentoClass
 
v_pat_node       := dbms_xmldom.getelementsbytagname(v_pat_xml_dtls, 'dentoClass1YN');
v_parent_node    := dbms_xmldom.getfirstchild(dbms_xmldom.item(v_pat_node, 0));
p_dento_class_i  := dbms_xmldom.getnodevalue(v_parent_node);

------
IF p_dento_class_i IS NOT NULL THEN 
  
   v_count  :=  CASE WHEN trim(UPPER(p_dento_class_i)) = 'Y' THEN 1
                     WHEN trim(UPPER(p_dento_class_i)) = 'N' THEN 1
                     WHEN  UPPER(p_dento_class_i) IS NULL  THEN 1
                     ELSE 0 END;
                     
   IF  v_count = 0  THEN 
      
      create_exception_log(v_xml_seq_id,NULL,NULL,'dentoClass1YN:DENTO CLASS I VALUE IS INVALID',1,p_dento_class_i);           
       
   END IF ;                    
   
END IF;
--------

v_pat_node       := dbms_xmldom.getelementsbytagname(v_pat_xml_dtls, 'dentoClass2YN');
v_parent_node    := dbms_xmldom.getfirstchild(dbms_xmldom.item(v_pat_node, 0));
p_dento_class_ii := dbms_xmldom.getnodevalue(v_parent_node); 
---------
IF p_dento_class_i IS NOT NULL THEN 
  
   v_count  :=  CASE WHEN trim(UPPER(p_dento_class_ii)) = 'Y' THEN 1
                     WHEN trim(UPPER(p_dento_class_ii)) = 'N' THEN 1
                     WHEN UPPER(p_dento_class_ii) IS NULL  THEN 1
                     ELSE 0 END;
                     
   IF  v_count = 0  THEN 
      
      create_exception_log(v_xml_seq_id,NULL,NULL,'dentoClass2YN:DENTO CLASS II VALUE IS INVALID',1,p_dento_class_ii);           
       
   END IF ;                    
   
END IF;
-----------
v_pat_node       := dbms_xmldom.getelementsbytagname(v_pat_xml_dtls, 'dentoClass2Value');
v_parent_node    := dbms_xmldom.getfirstchild(dbms_xmldom.item(v_pat_node, 0));
p_dento_class_ii_text := dbms_xmldom.getnodevalue(v_parent_node); 

v_pat_node       := dbms_xmldom.getelementsbytagname(v_pat_xml_dtls, 'dentoClass3YN');
v_parent_node    := dbms_xmldom.getfirstchild(dbms_xmldom.item(v_pat_node, 0));
p_dento_class_iii := dbms_xmldom.getnodevalue(v_parent_node); 

--------------
IF p_dento_class_iii IS NOT NULL THEN 
  
   v_count  :=  CASE WHEN trim(UPPER(p_dento_class_iii)) = 'Y' THEN 1
                     WHEN trim(UPPER(p_dento_class_iii)) = 'N' THEN 1
                     WHEN UPPER(p_dento_class_iii) IS NULL  THEN 1
                     ELSE 0 END;
                     
   IF  v_count = 0  THEN 
      
      create_exception_log(v_xml_seq_id,NULL,NULL,'dentoClass3YN:DENTO CLASS III VALUE IS INVALID',1,p_dento_class_iii);           
       
   END IF ;                    
   
END IF;
------------------

v_pat_node       := dbms_xmldom.getelementsbytagname(v_pat_xml_dtls, 'dentoClass3Value');
v_parent_node    := dbms_xmldom.getfirstchild(dbms_xmldom.item(v_pat_node, 0));
p_dento_class_iii_text := dbms_xmldom.getnodevalue(v_parent_node); 

---------------------------------------

----------------skeletalClass

v_pat_node       := dbms_xmldom.getelementsbytagname(v_pat_xml_dtls, 'skeletalClass1YN');-----skeletalClass1YN
v_parent_node    := dbms_xmldom.getfirstchild(dbms_xmldom.item(v_pat_node, 0));
p_skele_class_i  := dbms_xmldom.getnodevalue(v_parent_node); 

-----------------
IF p_skele_class_i IS NOT NULL THEN 
  
   v_count  :=  CASE WHEN trim(UPPER(p_skele_class_i)) = 'Y' THEN 1
                     WHEN trim(UPPER(p_skele_class_i)) = 'N' THEN 1
                     WHEN UPPER(p_skele_class_i) IS NULL  THEN 1
                     ELSE 0 END;
                     
   IF  v_count = 0  THEN 
      
      create_exception_log(v_xml_seq_id,NULL,NULL,'skeletalClass1YN:SKELETAL CLASS I VALUE IS INVALID',1,p_skele_class_i);           
       
   END IF ;                    
   
END IF;
------------------------

v_pat_node       := dbms_xmldom.getelementsbytagname(v_pat_xml_dtls, 'skeletalClass2YN');-------skeletalClass2YN
v_parent_node    := dbms_xmldom.getfirstchild(dbms_xmldom.item(v_pat_node, 0));
p_skele_class_ii := dbms_xmldom.getnodevalue(v_parent_node); 

-----------------
IF p_skele_class_ii IS NOT NULL THEN 
  
   v_count  :=  CASE WHEN trim(UPPER(p_skele_class_ii)) = 'Y' THEN 1
                     WHEN trim(UPPER(p_skele_class_ii)) = 'N' THEN 1
                     WHEN UPPER(p_skele_class_ii) IS NULL  THEN 1
                     ELSE 0 END;
                     
   IF  v_count = 0  THEN 
      
      create_exception_log(v_xml_seq_id,NULL,NULL,'skeletalClass2YN:SKELETAL CLASS II VALUE IS INVALID',1,p_skele_class_ii);           
       
   END IF ;                    
   
END IF;
------------------------

v_pat_node       := dbms_xmldom.getelementsbytagname(v_pat_xml_dtls, 'skeletalClass3YN');------skeletalClass3YN
v_parent_node    := dbms_xmldom.getfirstchild(dbms_xmldom.item(v_pat_node, 0));
p_skele_class_iii := dbms_xmldom.getnodevalue(v_parent_node); 

-----------------
IF p_skele_class_iii IS NOT NULL THEN 
  
   v_count  :=  CASE WHEN trim(UPPER(p_skele_class_iii)) = 'Y' THEN 1
                     WHEN trim(UPPER(p_skele_class_iii)) = 'N' THEN 1
                     WHEN UPPER(p_skele_class_iii) IS NULL  THEN 1
                     ELSE 0 END;
                     
   IF  v_count = 0  THEN 
      
      create_exception_log(v_xml_seq_id,NULL,NULL,'skeletalClass3YN:SKELETAL CLASS III VALUE IS INVALID',1,p_skele_class_iii);           
       
   END IF ;                    
   
END IF;
------------------------

------------------------------------
-----------overjet

v_pat_node       := dbms_xmldom.getelementsbytagname(v_pat_xml_dtls, 'overjet');-----------overjet
v_parent_node    := dbms_xmldom.getfirstchild(dbms_xmldom.item(v_pat_node, 0));
p_overjet_mm     := dbms_xmldom.getnodevalue(v_parent_node); 

--------
IF p_overjet_mm IS NOT NULL THEN 
  
     SELECT count(1) INTO v_spec_char_cnt
      FROM DUAL
      WHERE REGEXP_LIKE(TRIM(p_overjet_mm), '^\d+(\\d+)?$', '') 
      AND length(TRIM(p_overjet_mm)) <= 5;
        
      IF v_spec_char_cnt = 0 THEN   
        
        SELECT count(1)  INTO v_spec_char
        FROM dual
        WHERE regexp_like(TRIM(p_overjet_mm),'\.') 
        AND NOT regexp_like (TRIM(p_overjet_mm),'[[:alpha:]]')
        AND length(TRIM(p_overjet_mm)) <= 5;

          IF   v_spec_char = 0 THEN 
           
             create_exception_log(v_xml_seq_id,NULL,NULL,'overjet:OVERJET DATA IS INVALID',1,p_overjet_mm);
          
          END IF;
     
      END IF;

END IF;
-----------------------reverseOverjet

v_pat_node       := dbms_xmldom.getelementsbytagname(v_pat_xml_dtls, 'reverseOverJetValue');  ---------reverseOverJetValue
v_parent_node    := dbms_xmldom.getfirstchild(dbms_xmldom.item(v_pat_node, 0));
p_rev_overjet_mm := dbms_xmldom.getnodevalue(v_parent_node); 

------
IF p_rev_overjet_mm IS NOT NULL THEN 
  
      SELECT count(1) INTO v_spec_char_cnt
      FROM DUAL
      WHERE REGEXP_LIKE(TRIM(p_rev_overjet_mm), '^\d+(\\d+)?$', '') 
      AND length(TRIM(p_rev_overjet_mm)) <= 5;
        
      IF v_spec_char_cnt = 0 THEN 
        
        SELECT count(1)  INTO v_spec_char
        FROM dual
        WHERE regexp_like(TRIM(p_rev_overjet_mm),'\.') 
        AND NOT regexp_like (TRIM(p_rev_overjet_mm),'[[:alpha:]]')
        AND length(TRIM(p_rev_overjet_mm)) <= 5;

          IF   v_spec_char = 0 THEN        
             create_exception_log(v_xml_seq_id,NULL,NULL,'reverseOverJetValue:OVERJET DATA IS INVALID',1,p_rev_overjet_mm);
          END IF;
          
       END IF;

END IF;
------


v_pat_node       := dbms_xmldom.getelementsbytagname(v_pat_xml_dtls, 'speechMasticatoryDifficultyYN');------speechMasticatoryDifficultyYN
v_parent_node    := dbms_xmldom.getfirstchild(dbms_xmldom.item(v_pat_node, 0));
p_rev_overjet_yn := dbms_xmldom.getnodevalue(v_parent_node);

--------
IF  p_rev_overjet_yn IS NOT NULL THEN 
  
  v_count  :=  CASE WHEN trim(UPPER(p_rev_overjet_yn)) = 'Y' THEN 1
                    WHEN trim(UPPER(p_rev_overjet_yn)) = 'N' THEN 1
                    WHEN UPPER(p_rev_overjet_yn) IS NULL  THEN 1
                     ELSE 0 END;
                     
   IF  v_count = 0  THEN 
      
      create_exception_log(v_xml_seq_id,NULL,NULL,'speechMasticatoryDifficultyYN:SPEECH MASTICATORY YN VALUE IS INVALID',1,p_rev_overjet_yn);           
       
   END IF ;      

END IF;  
------------------------------------------------- 
-------crossbite
v_pat_node       := dbms_xmldom.getelementsbytagname(v_pat_xml_dtls, 'anteriorToothNos');------anterior
v_parent_node    := dbms_xmldom.getfirstchild(dbms_xmldom.item(v_pat_node, 0));
p_crossbite_ant  := dbms_xmldom.getnodevalue(v_parent_node); 

--------
IF p_crossbite_ant IS NOT NULL THEN 
  
             CHECK_DNTL_YN(
                           v_xml_seq_id,
                           'anteriorToothNos',
                           'CROSSBITE ANTERIOR',
                           p_crossbite_ant,
                           V_YN
                           ); 
                           
        ---  IF  NVL(V_YN,'Y') = 'Y'  THEN
            
                     CHECK_TOOTHNO_DUP(
                                        v_xml_seq_id,
                                       'anteriorToothNos',
                                       'CROSSBITE ANTERIOR',
                                        p_crossbite_ant
                                        ); 
        ---   END IF;                        
     
END IF;
------*********anteriorValue(crossbite)****************-------------
begin
  
v_pat_node       := dbms_xmldom.getelementsbytagname(v_pat_xml_dtls, 'anteriorValue');
v_parent_node    := dbms_xmldom.getfirstchild(dbms_xmldom.item(v_pat_node, 0));
p_crossbite_ant_mm := dbms_xmldom.getnodevalue(v_parent_node); 

IF p_crossbite_ant_mm IS NOT NULL THEN 
  
     SELECT count(1) INTO v_spec_char_cnt
      FROM DUAL
      WHERE REGEXP_LIKE(TRIM(p_crossbite_ant_mm), '^\d+(\\d+)?$', '')
       AND length(TRIM(p_crossbite_ant_mm)) <= 5;
        
      IF v_spec_char_cnt = 0 THEN                    
        
        SELECT count(1)  INTO v_spec_char
        FROM dual
        WHERE regexp_like(TRIM(p_crossbite_ant_mm),'\.') 
        AND NOT regexp_like (TRIM(p_crossbite_ant_mm),'[[:alpha:]]')
        AND length(TRIM(p_crossbite_ant_mm)) <= 5;

          IF   v_spec_char = 0 THEN        
              
             create_exception_log(v_xml_seq_id,NULL,NULL,'anteriorValue:CROSSBITE ANTERIOR MM DATA IS INVALID',1,p_crossbite_ant_mm);
          
          END IF;
         
      END IF;

END IF;

EXCEPTION
  
  WHEN OTHERS THEN
    
       create_exception_log(v_xml_seq_id,NULL,NULL,'anteriorValue:CROSSBITE ANTERIOR MM DATA IS INVALID',1,NULL);
END;

--------****************
                                                                         
v_pat_node       := dbms_xmldom.getelementsbytagname(v_pat_xml_dtls, 'posteriorToothNos'); ------posterior
v_parent_node    := dbms_xmldom.getfirstchild(dbms_xmldom.item(v_pat_node, 0));
p_crossbite_post := dbms_xmldom.getnodevalue(v_parent_node); 

--------
IF p_crossbite_post IS NOT NULL THEN 
  
         CHECK_DNTL_YN    (
                           v_xml_seq_id,
                           'posteriorToothNos',
                           'CROSSBITE POSTERIOR',
                           p_crossbite_post,
                           V_YN
                           );
                           
        ---  IF  NVL(V_YN,'Y') = 'Y'  THEN
            
                CHECK_TOOTHNO_DUP (
                                  v_xml_seq_id,
                                  'posteriorToothNos',
                                  'CROSSBITE POSTERIOR',
                                  p_crossbite_post
                                 ); 
       ---    END IF;   

END IF;
------********posteriorValue(crossbite)***********---------
begin
v_pat_node       := dbms_xmldom.getelementsbytagname(v_pat_xml_dtls, 'posteriorValue');
v_parent_node    := dbms_xmldom.getfirstchild(dbms_xmldom.item(v_pat_node, 0));
p_crossbite_prst_mm := dbms_xmldom.getnodevalue(v_parent_node); 

IF p_crossbite_prst_mm IS NOT NULL THEN 
  
      SELECT count(1) INTO v_spec_char_cnt
      FROM DUAL
      WHERE REGEXP_LIKE(TRIM(p_crossbite_prst_mm), '^\d+(\\d+)?$', '')
      AND length(TRIM(p_crossbite_prst_mm)) <= 5;
        
      IF v_spec_char_cnt = 0 THEN  
        
        SELECT count(1)  INTO v_spec_char
        FROM dual
        WHERE regexp_like(TRIM(p_crossbite_prst_mm),'\.') 
        AND NOT regexp_like (TRIM(p_crossbite_prst_mm),'[[:alpha:]]')
        AND length(TRIM(p_crossbite_prst_mm)) <= 5;

          IF   v_spec_char = 0 THEN   
                    
              create_exception_log(v_xml_seq_id,NULL,NULL,'posteriorValue:CROSSBITE POSTERIOR MM DATA IS INVALID',1,p_crossbite_prst_mm);
         
          END IF;
          
       END IF;

END IF;

EXCEPTION
  
    WHEN OTHERS THEN
      
      create_exception_log(v_xml_seq_id,NULL,NULL,'posteriorValue:CROSSBITE POSTERIOR VALUE IS INVALID',1,NULL);  
      
END;
------
v_pat_node       := dbms_xmldom.getelementsbytagname(v_pat_xml_dtls, 'retrudedIntercuspaloothNos');----retrudedIntercuspalPosition
v_parent_node    := dbms_xmldom.getfirstchild(dbms_xmldom.item(v_pat_node, 0));
p_crossbite_betw := dbms_xmldom.getnodevalue(v_parent_node); 

--------
IF p_crossbite_betw IS NOT NULL THEN 
  
         CHECK_DNTL_YN    (
                           v_xml_seq_id,
                           'retrudedIntercuspaloothNos',
                           'CROSSBITE RETRUDED',
                            p_crossbite_betw,
                            V_YN
                           );
                           
           -- IF  NVL(V_YN,'Y') = 'Y'  THEN
            
                CHECK_TOOTHNO_DUP (
                                  v_xml_seq_id,
                                 'retrudedIntercuspaloothNos',
                                 'CROSSBITE RETRUDED',
                                  p_crossbite_betw
                                 ); 
          ---  END IF;   

     
END IF;

------******retrudedIntercuspaloothNosValue(crossbite)****--------
BEGIN
   
v_pat_node       := dbms_xmldom.getelementsbytagname(v_pat_xml_dtls, 'retrudedIntercuspaloothNosValue');
v_parent_node    := dbms_xmldom.getfirstchild(dbms_xmldom.item(v_pat_node, 0));
p_crossbite_betw_mm := dbms_xmldom.getnodevalue(v_parent_node); 

IF p_crossbite_betw_mm IS NOT NULL THEN 
  
     SELECT count(1) INTO v_spec_char_cnt
      FROM DUAL
      WHERE REGEXP_LIKE(TRIM(p_crossbite_betw_mm), '^\d+(\\d+)?$', '')
      AND length(TRIM(p_crossbite_betw_mm)) <= 5;
        
      IF v_spec_char_cnt = 0 THEN   
        
        SELECT count(1)  INTO v_spec_char
        FROM dual
        WHERE regexp_like(TRIM(p_crossbite_betw_mm),'\.') 
        AND NOT regexp_like (TRIM(p_crossbite_betw_mm),'[[:alpha:]]')
        AND length(TRIM(p_crossbite_betw_mm)) <= 5;

          IF   v_spec_char = 0 THEN 
                   
            create_exception_log(v_xml_seq_id,NULL,NULL,'retrudedIntercuspaloothNosValue:CROSSBITE BETWEEN MM DATA IS INVALID',1,p_crossbite_betw_mm);
      
          END IF;
          
       END IF;

END IF;

EXCEPTION
  
  WHEN OTHERS THEN 
    
     create_exception_log(v_xml_seq_id,NULL,NULL,'retrudedIntercuspaloothNosValue:CROSSBITE BETWEEN MM DATA IS INVALID',1,NULL);
     
END ;
  
------                                                                                           
-------*****openbite                                                                                           

v_pat_node       := dbms_xmldom.getelementsbytagname(v_pat_xml_dtls, 'openAnterior'); --------anterior
v_parent_node    := dbms_xmldom.getfirstchild(dbms_xmldom.item(v_pat_node, 0));
p_openbit_ant    := dbms_xmldom.getnodevalue(v_parent_node); 

------
IF p_openbit_ant IS NOT NULL THEN 
  
     SELECT count(1) INTO v_spec_char_cnt
      FROM DUAL
      WHERE REGEXP_LIKE(TRIM(p_openbit_ant), '^\d+(\\d+)?$', '')
       AND length(TRIM(p_openbit_ant)) <= 5;
        
      IF v_spec_char_cnt = 0 THEN  
        
        SELECT count(1)  INTO v_spec_char
        FROM dual
        WHERE regexp_like(TRIM(p_openbit_ant),'\.') 
        AND NOT regexp_like (TRIM(p_openbit_ant),'[[:alpha:]]')
        AND length(TRIM(p_openbit_ant)) <= 5;

          IF   v_spec_char = 0 THEN       
           
            create_exception_log(v_xml_seq_id,NULL,NULL,'openAnterior:OPENBITE ANTERIOR MM DATA IS INVALID',1,p_openbit_ant);
     
          END IF;
          
       END IF;

END IF;
------

v_pat_node       := dbms_xmldom.getelementsbytagname(v_pat_xml_dtls, 'openPosterior');--------posterior
v_parent_node    := dbms_xmldom.getfirstchild(dbms_xmldom.item(v_pat_node, 0));
p_openbit_post   := dbms_xmldom.getnodevalue(v_parent_node); 


------
IF p_openbit_post IS NOT NULL THEN 
  
     SELECT count(1) INTO v_spec_char_cnt
      FROM DUAL
      WHERE REGEXP_LIKE(TRIM(p_openbit_post), '^\d+(\\d+)?$', '')
      AND length(TRIM(p_openbit_post)) <= 5;
        
      IF v_spec_char_cnt = 0 THEN 
        
        SELECT count(1)  INTO v_spec_char
        FROM dual
        WHERE regexp_like(TRIM(p_openbit_post),'\.') 
        AND NOT regexp_like (TRIM(p_openbit_post),'[[:alpha:]]')
        AND length(TRIM(p_openbit_post)) <= 5;

          IF   v_spec_char = 0 THEN   
                  
            create_exception_log(v_xml_seq_id,NULL,NULL,'openPosterior:OPENBITE POSTERIOR MM DATA IS INVALID',1,p_openbit_post);
     
           END IF;
           
        END IF;

END IF;
------


v_pat_node       := dbms_xmldom.getelementsbytagname(v_pat_xml_dtls, 'openLateral'); ---------lateral
v_parent_node    := dbms_xmldom.getfirstchild(dbms_xmldom.item(v_pat_node, 0));
p_openbit_late   := dbms_xmldom.getnodevalue(v_parent_node); 

-----------------------------------------

------
IF p_openbit_late IS NOT NULL THEN 
  
     SELECT count(1) INTO v_spec_char_cnt
      FROM DUAL
      WHERE REGEXP_LIKE(TRIM(p_openbit_late), '^\d+(\\d+)?$', '')
       AND length(TRIM(p_openbit_late)) <= 5;
        
      IF v_spec_char_cnt = 0 THEN  
        
        SELECT count(1)  INTO v_spec_char
        FROM dual
        WHERE regexp_like(TRIM(p_openbit_late),'\.') 
        AND NOT regexp_like (TRIM(p_openbit_late),'[[:alpha:]]')
        AND length(TRIM(p_openbit_late)) <= 5;

          IF   v_spec_char = 0 THEN   
               
             create_exception_log(v_xml_seq_id,NULL,NULL,'openLateral:OPENBITE LATERAL MM DATA IS INVALID',1,p_openbit_late);
      
          END IF;
          
       END IF;

END IF;
------

---------contactPointDisplacement                                                                             

v_pat_node       := dbms_xmldom.getelementsbytagname(v_pat_xml_dtls, 'pointDisplacementToothNos');  -----pointDisplacementToothNos
v_parent_node    := dbms_xmldom.getfirstchild(dbms_xmldom.item(v_pat_node, 0));
p_cont_point_disp := dbms_xmldom.getnodevalue(v_parent_node); 

-------
IF p_cont_point_disp IS NOT NULL THEN 
  
          CHECK_DNTL_YN    (
                           v_xml_seq_id,
                           'pointDisplacementToothNos',
                           'CONTACT POINT DISPLACEMENT',
                            p_cont_point_disp,
                            V_YN
                           );
                           
             --- IF  NVL(V_YN,'Y') = 'Y'  THEN
            
                 CHECK_TOOTHNO_DUP (
                                       v_xml_seq_id,
                                      'pointDisplacementToothNos',
                                      'CONTACT POINT DISPLACEMENT',
                                       p_cont_point_disp
                                    ); 
              --- END IF; 
     
END IF;
------*******pointDisplacementValue******-----------------
begin
  
v_pat_node       := dbms_xmldom.getelementsbytagname(v_pat_xml_dtls, 'pointDisplacementValue');------pointDisplacementValue
v_parent_node    := dbms_xmldom.getfirstchild(dbms_xmldom.item(v_pat_node, 0));
p_cont_point_disp_mm := dbms_xmldom.getnodevalue(v_parent_node); 

IF p_cont_point_disp_mm IS NOT NULL THEN 
  
     SELECT count(1) INTO v_spec_char_cnt
      FROM DUAL
      WHERE REGEXP_LIKE(TRIM(p_cont_point_disp_mm), '^\d+(\\d+)?$', '')
      AND length(TRIM(p_cont_point_disp_mm)) <= 5;
        
      IF v_spec_char_cnt = 0 THEN 
         
        SELECT count(1)  INTO v_spec_char
        FROM dual
        WHERE regexp_like(TRIM(p_cont_point_disp_mm),'\.') 
        AND NOT regexp_like (TRIM(p_cont_point_disp_mm),'[[:alpha:]]')
        AND length(TRIM(p_cont_point_disp_mm)) <= 5;

          IF   v_spec_char = 0 THEN   
                  
            create_exception_log(v_xml_seq_id,NULL,NULL,'pointDisplacementValue:CONTACT POINT DISPLACEMENT MM DATA IS INVALID',1,p_cont_point_disp_mm);
    
          END IF;
          
       END IF;

END IF;

EXCEPTION
  
     WHEN OTHERS THEN 
       
        create_exception_log(v_xml_seq_id,NULL,NULL,'pointDisplacementValue:CONTACT POINT DISPLACEMENT MM DATA IS INVALID',1,p_cont_point_disp_mm);
        
END;    

---------overbite
v_pat_node       := dbms_xmldom.getelementsbytagname(v_pat_xml_dtls, 'overbiteValue');-------------overbiteValue
v_parent_node    := dbms_xmldom.getfirstchild(dbms_xmldom.item(v_pat_node, 0));
p_overbit        := dbms_xmldom.getnodevalue(v_parent_node); 

--------------------
IF  p_overbit IS NOT NULL THEN 
  
  v_count  :=   CASE WHEN UPPER(TRIM(p_overbit)) = 'D' THEN 1
                     WHEN UPPER(TRIM(p_overbit)) = 'C' THEN 1
                     WHEN UPPER(TRIM(p_overbit)) = 'I' THEN 1
                     WHEN UPPER(TRIM(p_overbit)) = 'N' THEN 1
                     ELSE 0 END;
                     
   IF  v_count = 0  THEN 
      
      create_exception_log(v_xml_seq_id,NULL,NULL,'overbiteValue:OVERBITE YN VALUE IS INVALID',1,p_overbit);           
       
   END IF ;      

END IF; 
-----------------------------------------

v_pat_node       := dbms_xmldom.getelementsbytagname(v_pat_xml_dtls, 'palatalTraumaYN');-------------palatalTraumaYN
v_parent_node    := dbms_xmldom.getfirstchild(dbms_xmldom.item(v_pat_node, 0));
p_overbit_pata   := dbms_xmldom.getnodevalue(v_parent_node); 

-----------
IF  p_overbit_pata IS NOT NULL THEN 
  
  v_count  :=   CASE WHEN trim(UPPER(p_overbit_pata)) = 'Y' THEN 1
                     WHEN trim(UPPER(p_overbit_pata)) = 'N' THEN 1
                     WHEN UPPER(p_overbit_pata) is NULL THEN 1
                     ELSE 0 END;
                     
   IF  v_count = 0  THEN 
      
      create_exception_log(v_xml_seq_id,NULL,NULL,'palatalTraumaYN:OVERBITE WITH PALATAL YN VALUE IS INVALID',1,p_overbit_pata);           
       
   END IF ;      

END IF; 
------------------------

v_pat_node       := dbms_xmldom.getelementsbytagname(v_pat_xml_dtls, 'gingivalTraumaYN');-------------gingivalTraumaYN
v_parent_node    := dbms_xmldom.getfirstchild(dbms_xmldom.item(v_pat_node, 0));
p_overbit_ging   := dbms_xmldom.getnodevalue(v_parent_node); 

-----------
IF  p_overbit_ging IS NOT NULL THEN 
  
  v_count  :=   CASE WHEN trim(UPPER(p_overbit_ging)) = 'Y' THEN 1
                     WHEN trim(UPPER(p_overbit_ging)) = 'N' THEN 1
                     WHEN UPPER(p_overbit_ging) IS NULL THEN 1
                     ELSE 0 END;
                     
   IF  v_count = 0  THEN 
      
      create_exception_log(v_xml_seq_id,NULL,NULL,'gingivalTraumaYN:OVERBITE WITH GINGIVAL YN VALUE IS INVALID',1,p_overbit_ging);           
       
   END IF ;      

END IF; 
------------------------

------------------------
------------------hypodontia

v_pat_node       := dbms_xmldom.getelementsbytagname(v_pat_xml_dtls, 'Quandrant1Teeth');--------Quandrant1Teeth
v_parent_node    := dbms_xmldom.getfirstchild(dbms_xmldom.item(v_pat_node, 0));
p_hypo_quad1     := dbms_xmldom.getnodevalue(v_parent_node);

-------
IF p_hypo_quad1 IS NOT NULL THEN 
  
         CHECK_DNTL_YN    (
                            v_xml_seq_id,
                           'Quandrant1Teeth',
                           'HYPODONTIA QUAD I',
                            p_hypo_quad1,
                            V_YN
                           );
                           
     ---  IF  NVL(V_YN,'Y') = 'Y'  THEN
            
                 CHECK_TOOTHNO_DUP (
                                       v_xml_seq_id,
                                      'Quandrant1Teeth',
                                      'HYPODONTIA QUAD I',
                                       p_hypo_quad1
                                    ); 
       ---  END IF;                            
  
END IF;
--------- 

v_pat_node       := dbms_xmldom.getelementsbytagname(v_pat_xml_dtls, 'Quandrant2Teeth');---------Quandrant2Teeth
v_parent_node    := dbms_xmldom.getfirstchild(dbms_xmldom.item(v_pat_node, 0));
p_hypo_quad2     := dbms_xmldom.getnodevalue(v_parent_node); 

-------
IF p_hypo_quad2 IS NOT NULL THEN 
  
          CHECK_DNTL_YN    (
                           v_xml_seq_id,
                           'Quandrant2Teeth',
                           'HYPODONTIA QUAD II',
                            p_hypo_quad2,
                            V_YN
                           );
                           
      ---   IF  NVL(V_YN,'Y') = 'Y'  THEN
            
                 CHECK_TOOTHNO_DUP (
                                       v_xml_seq_id,
                                      'Quandrant2Teeth',
                                      'HYPODONTIA QUAD II',
                                       p_hypo_quad2
                                    ); 
       ---  END IF;                            
    
END IF;
--------- 

v_pat_node       := dbms_xmldom.getelementsbytagname(v_pat_xml_dtls, 'Quandrant3Teeth');---------Quandrant3Teeth
v_parent_node    := dbms_xmldom.getfirstchild(dbms_xmldom.item(v_pat_node, 0));
p_hypo_quad3     := dbms_xmldom.getnodevalue(v_parent_node); 

-------
IF p_hypo_quad3 IS NOT NULL THEN 
  
          CHECK_DNTL_YN    (
                           v_xml_seq_id,
                           'Quandrant3Teeth',
                           'HYPODONTIA QUAD III',
                            p_hypo_quad3,
                            V_YN
                           ); 
                           
          ----  IF  NVL(V_YN,'Y') = 'Y'  THEN
            
                 CHECK_TOOTHNO_DUP (
                                       v_xml_seq_id,
                                      'Quandrant3Teeth',
                                      'HYPODONTIA QUAD III',
                                       p_hypo_quad3
                                    ); 
           ---  END IF;      
END IF;
---------

v_pat_node       := dbms_xmldom.getelementsbytagname(v_pat_xml_dtls, 'Quandrant4Teeth');-----------Quandrant4Teeth
v_parent_node    := dbms_xmldom.getfirstchild(dbms_xmldom.item(v_pat_node, 0));
p_hypo_quad4     := dbms_xmldom.getnodevalue(v_parent_node); 

-------
IF p_hypo_quad4 IS NOT NULL THEN 
  
          CHECK_DNTL_YN    (
                           v_xml_seq_id,
                           'Quandrant4Teeth',
                           'HYPODONTIA QUAD IIII',
                            p_hypo_quad4,
                            V_YN
                           );  
                           
         ----  IF  NVL(V_YN,'Y') = 'Y'  THEN
            
                 CHECK_TOOTHNO_DUP (
                                       v_xml_seq_id,
                                      'Quandrant4Teeth',
                                      'HYPODONTIA QUAD IIII',
                                       p_hypo_quad4
                                    ); 
          ---- END IF;   
               
END IF;
---------
----------------------------------

-----------others

v_pat_node       := dbms_xmldom.getelementsbytagname(v_pat_xml_dtls, 'impededTeeth');---------impededTeeth
v_parent_node    := dbms_xmldom.getfirstchild(dbms_xmldom.item(v_pat_node, 0));
p_others_impeded := dbms_xmldom.getnodevalue(v_parent_node);

-------
IF p_others_impeded IS NOT NULL THEN 
  
         CHECK_DNTL_YN    (
                            v_xml_seq_id,
                           'impededTeeth',
                           'IMPEDED TEETH',
                            p_others_impeded,
                            V_YN
                           );
                           
                           
       ----    IF  NVL(V_YN,'Y') = 'Y'  THEN
            
                 CHECK_TOOTHNO_DUP (
                                       v_xml_seq_id,
                                      'impededTeeth',
                                      'IMPEDED TEETH',
                                       p_others_impeded
                                    ); 
        ----   END IF;   
      
END IF;
--------- 

v_pat_node       := dbms_xmldom.getelementsbytagname(v_pat_xml_dtls, 'impactedTeeth');---------impactedTeeth
v_parent_node    := dbms_xmldom.getfirstchild(dbms_xmldom.item(v_pat_node, 0));
p_others_impact  := dbms_xmldom.getnodevalue(v_parent_node);

-------
IF p_others_impact IS NOT NULL THEN 
  
          CHECK_DNTL_YN    (
                            v_xml_seq_id,
                           'impactedTeeth',
                           'IMPACTED TEETH',
                            p_others_impact,
                            V_YN
                           );
                           
       ----  IF  NVL(V_YN,'Y') = 'Y'  THEN
            
                 CHECK_TOOTHNO_DUP (
                                       v_xml_seq_id,
                                      'impactedTeeth',
                                      'IMPACTED TEETH',
                                       p_others_impact
                                    ); 
      ---   END IF;                            
        
END IF;
---------  

v_pat_node       := dbms_xmldom.getelementsbytagname(v_pat_xml_dtls, 'submergerdTeeth');----------submergerdTeeth
v_parent_node    := dbms_xmldom.getfirstchild(dbms_xmldom.item(v_pat_node, 0));
p_others_submerg := dbms_xmldom.getnodevalue(v_parent_node); 

-------
IF p_others_submerg IS NOT NULL THEN 
  
          CHECK_DNTL_YN    (
                            v_xml_seq_id,
                           'submergerdTeeth',
                           'SUBMERGERD TEETH',
                            p_others_submerg,
                            V_YN
                           );
                           
                            
        --- IF  NVL(V_YN,'Y') = 'Y'  THEN
            
                 CHECK_TOOTHNO_DUP (
                                       v_xml_seq_id,
                                      'submergerdTeeth',
                                      'SUBMERGERD TEETH',
                                       p_others_submerg
                                    ); 
      ----   END IF;  
      
END IF;
--------- 

v_pat_node       := dbms_xmldom.getelementsbytagname(v_pat_xml_dtls, 'supernumeraryTeeth');----------supernumeraryTeeth
v_parent_node    := dbms_xmldom.getfirstchild(dbms_xmldom.item(v_pat_node, 0));
p_others_supernum := dbms_xmldom.getnodevalue(v_parent_node); 

-------
IF p_others_supernum IS NOT NULL THEN 
  
         CHECK_DNTL_YN    (
                            v_xml_seq_id,
                           'supernumeraryTeeth',
                           'SUPERNUMERARY TEETH',
                            p_others_supernum,
                            V_YN
                           );
                           
       ----  IF  NVL(V_YN,'Y') = 'Y'  THEN
            
                 CHECK_TOOTHNO_DUP (
                                       v_xml_seq_id,
                                      'supernumeraryTeeth',
                                      'SUPERNUMERARY TEETH',
                                       p_others_supernum
                                    ); 
        ---- END IF; 
     
END IF;
--------- 

v_pat_node       := dbms_xmldom.getelementsbytagname(v_pat_xml_dtls, 'retainedTeeth');---------retainedTeeth
v_parent_node    := dbms_xmldom.getfirstchild(dbms_xmldom.item(v_pat_node, 0));
p_others_retaine := dbms_xmldom.getnodevalue(v_parent_node); 

---------
IF p_others_retaine IS NOT NULL THEN 
  
          CHECK_DNTL_YN    (
                            v_xml_seq_id,
                           'retainedTeeth',
                           'RETAINED TEETH',
                            p_others_retaine,
                            V_YN
                           );
                           
         ---- IF  NVL(V_YN,'Y') = 'Y'  THEN
            
                 CHECK_TOOTHNO_DUP (
                                       v_xml_seq_id,
                                      'retainedTeeth',
                                      'RETAINED TEETH',
                                       p_others_retaine
                                    ); 
         ----END IF;                            
    
END IF;
---------

v_pat_node       := dbms_xmldom.getelementsbytagname(v_pat_xml_dtls, 'ectopicTeeth');----------ectopicTeeth
v_parent_node    := dbms_xmldom.getfirstchild(dbms_xmldom.item(v_pat_node, 0));
p_others_ectopic := dbms_xmldom.getnodevalue(v_parent_node); 


---------
IF p_others_ectopic IS NOT NULL THEN 
  
    CHECK_DNTL_YN    (
                            v_xml_seq_id,
                           'ectopicTeeth',
                           'ECTOPIC TEETH',
                            p_others_ectopic,
                            V_YN
                           );
                           
  ----     IF  NVL(V_YN,'Y') = 'Y'  THEN
            
                 CHECK_TOOTHNO_DUP (
                                       v_xml_seq_id,
                                      'ectopicTeeth',
                                      'ECTOPIC TEETH',
                                       p_others_ectopic
                                    ); 
     -----    END IF;                            
     
END IF;
---------

v_pat_node       := dbms_xmldom.getelementsbytagname(v_pat_xml_dtls, 'cranioFacialAnomaly');---------cranioFacialAnomaly
v_parent_node    := dbms_xmldom.getfirstchild(dbms_xmldom.item(v_pat_node, 0));
p_others_cranio  := dbms_xmldom.getnodevalue(v_parent_node); 

-------------------------------------
--------score
v_pat_node       := dbms_xmldom.getelementsbytagname(v_pat_xml_dtls, 'score');------score
v_parent_node    := dbms_xmldom.getfirstchild(dbms_xmldom.item(v_pat_node, 0));
p_ac_marks       := dbms_xmldom.getnodevalue(v_parent_node);


IF p_ac_marks IS NOT NULL THEN  
  
SELECT COUNT(1)  INTO v_count  
  FROM DUAL
  WHERE REGEXP_LIKE(TRIM(p_ac_marks), '^\d+(\\d+)?$', ''); 
  
     IF   v_count =  0  THEN 
       
        create_exception_log(v_xml_seq_id,NULL,NULL,'score:SCORE VALUE IS INVALID',1,p_ac_marks);               
    
     END IF;    
     
END IF;

IF p_ac_marks IS NOT NULL THEN  
  
  v_count := CASE WHEN TRIM(p_ac_marks)  BETWEEN 1 AND 10 THEN 1 ELSE 0 END;

  
     IF   v_count =  0  THEN 
       
        create_exception_log(v_xml_seq_id,NULL,NULL,'SCORE VALUE RANGE  IS NOT BETWEEN 1 TO 10',1,p_ac_marks);               
    
     END IF;    
     
END IF;


------FRONT VALIDATION 

       CHECK_DENTAL_VALIDATION
                                (
                                 V_XML_SEQ_ID,
                                 p_dento_class_i,
                                 p_dento_class_ii,
                                 p_dento_class_ii_text,
                                 p_dento_class_iii,
                                 p_dento_class_iii_text,
                                 p_skele_class_i,
                                 p_skele_class_ii,
                                 p_skele_class_iii,
                                 p_overjet_mm,
                                 p_rev_overjet_mm,
                                 p_rev_overjet_yn,
                                 p_crossbite_ant,
                                 p_crossbite_post,
                                 p_crossbite_betw,
                                 p_openbit_ant,
                                 p_openbit_post,
                                 p_openbit_late,
                                 p_cont_point_disp,
                                 p_overbit,
                                 p_overbit_pata,
                                 p_overbit_ging,
                                 p_hypo_quad1,
                                 p_hypo_quad2,
                                 p_hypo_quad3,
                                 p_hypo_quad4,
                                 p_others_impeded,
                                 p_others_impact,
                                 p_others_submerg,
                                 p_others_supernum,
                                 p_others_retaine,
                                 p_others_ectopic,
                                 p_others_cranio,
                                 p_ac_marks,
                                 p_crossbite_ant_mm,
                                 p_crossbite_prst_mm,
                                 p_crossbite_betw_mm,
                                 p_cont_point_disp_mm
                               ) ;         

--------------
 END IF;
 
 END IF;


  v_error_exst_yn :=  ERROR_EXIST_YN(v_xml_seq_id);
   
   --- IF  v_error_exst_yn = 'N'  THEN 
   
  ------******SAVE PREAUTH INFORMATION******-----------       
        SAVE_AUTHORIZATION_DETAILS(                                     
                                     v_disposition,                             
                                     v_pat_ath_seq_id,                
                                     v_event_no,
									                   upper(v_med_type),
									                   TRIM(upper(v_accid_rel_case)),
									                   v_tpa_enroll_id,
									                   TRIM(v_requested_amnt),
									                   v_clinician_id,
									                   v_clinicianname,
									                   TRIM(upper(v_benefitType)),
									                   TRIM(v_encounterType),
                                     TRIM(v_encterStrtType),
 									                   TRIM(v_encterEndType),
									                   TRIM(v_date_of_hosp),
								                  	 TRIM(v_date_hosp_time),
                                     TRIM(UPPER(v_hosp_time_am)),
                                     TRIM(v_date_of_exit),--pat_authorization_details.discharge_date%TYPE;
                                     TRIM(v_date_dis_time),
                                     TRIM(UPPER(v_dish_time_pm)),
                                     TRIM(v_den_encnt_type),
                                     TRIM(v_lmp)           ,
                                     TRIM(upper(v_mode_of_delvry)),
                                     TRIM(upper(v_nat_conception)),
                                     v_pre_auth_number,
                                     v_presenting_complaints,
                                     v_clinician_mail,----------NEWLY ADDED FOR ALAHALI ENHANCEMENT
                                     v_xml_seq_id,
                                     
									                   v_rows_processed
								                 	 );
                                                                                                    
    -------***********DENTAL INFOARMATION************---------------                              
             IF   TRIM(UPPER(v_benefitType))  = 'DNTL'   THEN
               
                  SAVE_ORTHO_DETAILS(
                                       v_xml_seq_id,
                                       v_disposition,
                                       v_pat_ath_seq_id,                     
                                       p_dento_class_i,
                                       p_dento_class_ii,
                                       p_dento_class_ii_text,
                                       p_dento_class_iii,
                                       p_dento_class_iii_text,
                                       p_skele_class_i,
                                       p_skele_class_ii,
                                       p_skele_class_iii,
                                       TRIM(p_overjet_mm),
                                       TRIM(p_rev_overjet_mm),
                                       p_rev_overjet_yn,
                                       p_crossbite_ant,
                                       p_crossbite_post,
                                       p_crossbite_betw,
                                       TRIM(p_openbit_ant),
                                       TRIM(p_openbit_post),
                                       TRIM(p_openbit_late),
                                       p_cont_point_disp,
                                       UPPER(TRIM(p_overbit)),
                                       p_overbit_pata,
                                       p_overbit_ging,
                                       p_hypo_quad1,
                                       p_hypo_quad2,
                                       p_hypo_quad3,
                                       p_hypo_quad4,
                                       p_others_impeded,
                                       p_others_impact,
                                       p_others_submerg,
                                       p_others_supernum,
                                       p_others_retaine,
                                       p_others_ectopic ,
                                       p_others_cranio,
                                       p_ac_marks ,
                                       TRIM(p_crossbite_ant_mm),
                                       TRIM(p_crossbite_prst_mm),
	                                     TRIM(p_crossbite_betw_mm),
                                       TRIM(p_cont_point_disp_mm)
			                                );
                                                                      
               --- NULL;
                  
            END IF;
                                                                                                                                                         
    ---   ELSE
        
        ---  ROLLBACK;          
          
      ---- END IF;

-------***************DIAGONOSYS INFORMATION PARSING AND DATA VALIDATION****************--------------

 v_pat_node      :=  dbms_xmldom.getelementsbytagname(v_pat_xml_dtls, 'diagnosisDetails'); -------Retrieves the elements in the DOMNODELIST by tag name
  
   FOR v_root_node_index in 0 .. dbms_xmldom.getlength(v_pat_node) - 1 LOOP   -----Retrieves the length of the data
   
    v_parent_node:= dbms_xmldom.item(v_pat_node, v_root_node_index);   -------Retrieves the item given the index in the map
    v_element    := dbms_xmldom.makeelement(v_parent_node);
     
    v_diag_code_prim       := Dbms_xmldom.getAttribute(v_element,'ICDCode');
 
 ---------------
    
       IF   v_diag_code_prim IS  NULL THEN 
         
            create_exception_log(v_xml_seq_id,NULL,NULL,'PRIMARYICDCode:PRIMARY ICD CODE IS BLANK',1,v_diag_code_prim);    
       
       END IF;
       
      IF   v_diag_code_prim IS NOT  NULL THEN 
     
       ----NEED TO CHECK  THIS JOIN 
        
      SELECT SUM(CNT)  INTO V_COUNT FROM
      (SELECT COUNT(1) CNT FROM APP.TPA_ICD_AM_DETAILS M WHERE M.ICD_AM = upper(trim(v_diag_code_prim))
      UNION ALL
      SELECT COUNT(1) CNT FROM APP.TPA_ICD10_MASTER_DETAILS I WHERE I.ICD_CODE = upper(trim(v_diag_code_prim)));
      
             IF V_COUNT = 0 THEN 
          
                        create_exception_log(v_xml_seq_id,NULL,NULL,'PRIMARYICDCode:GIVEN PRIMARY ICD CODE IS INVALID',1,v_diag_code_prim);    
    
              END IF;
       
      END IF;
      
      IF  UPPER(trim(v_benefitType)) = 'DNTL'  THEN
        
          CHECK_DNTL_ICD_PRIM(
                               v_xml_seq_id,
                               v_pat_ath_seq_id,	
                               upper(trim(v_diag_code_prim)),
                               upper(trim(v_benefitType))
                               );
           
      END IF;
           
           
          v_diag_tag  :=   dbms_xmldom.getelementsbytagname(v_pat_xml_dtls, 'durationOfAilment');
         
           FOR v_diag_node_index in 0 .. dbms_xmldom.getlength(v_diag_tag) - 1 LOOP 
             
               v_child_node2  := dbms_xmldom.item(v_diag_tag, v_diag_node_index);   -------Retrieves the item given the index in the map
               v_element3     := dbms_xmldom.makeelement(v_child_node2);
         
      ----*****DURATION OF ALIMENT VALIDATION ( VALIDATION FOR GIVING STRING INSTEAD OF NUMBER)
            
               BEGIN
               
                v_duration_ailment     := Dbms_xmldom.getAttribute(v_element3,'durationValue');
              
               EXCEPTION
                 
                WHEN OTHERS THEN 
                 
                  create_exception_log(v_xml_seq_id,NULL,NULL,'durationValue:GIVEN DURATION VALUE FOR AILMENT IS INVALID',1,v_duration_ailment);
         
                END;
          
      -----*****
              ---    IF  v_duration_ailment IS NULL THEN 
               
                   ---  create_exception_log(v_xml_seq_id,NULL,NULL,'durationValue:GIVEN DURATION VALUE FOR AILMENT IS BLANK',1,v_duration_flag);
              
                 --- END IF; 
                
                
                v_duration_flag        := Dbms_xmldom.getAttribute(v_element3,'durationFlag'); 
            
                ---   IF  v_duration_flag IS NULL THEN 
               
                    --   create_exception_log(v_xml_seq_id,NULL,NULL,'durationOfAilment:GIVEN DURATION FLAG FOR AILMENT IS BLANK',1,v_duration_flag);
              
             ---      END IF;
                  
                   IF  v_duration_flag IS NOT NULL THEN
                  
                         v_flag_valid :=  CASE WHEN TRIM(UPPER(v_duration_flag)) = 'DAYS'   THEN 1
                                               WHEN TRIM(UPPER(v_duration_flag)) = 'WEEKS'  THEN 2
                                               WHEN TRIM(UPPER(v_duration_flag)) = 'MONTHS' THEN 3
                                               WHEN TRIM(UPPER(v_duration_flag)) = 'YEARS'  THEN 4
                                               ELSE 0 END;
                                          
                               IF v_flag_valid  = 0  THEN 
                           
                                     create_exception_log(v_xml_seq_id,NULL,NULL,'durationOfAilment:GIVEN DURATION FLAG FOR AILMENT IS INVALID',1,v_duration_flag);    
                             
                               END IF;
                         
                     END IF;
                
            END LOOP;        
            
 -------------------------------  
     v_error_exst_yn :=  ERROR_EXIST_YN(v_xml_seq_id);
   
     --- IF  v_error_exst_yn = 'N'  THEN 
   
  ------******SAVE PRIMARY DAIGONOSYS INFORMATION******-----------       
        
           SAVE_DIAGNOSYS_DETAILS
 					                          (	
                                      V_XML_SEQ_ID,				                   
					                          	v_pat_ath_seq_id,						                          
						                          upper(trim(v_diag_code_prim)),	
                                      'Y',				               
						                          v_duration_ailment,
					                            v_duration_flag
					                          );
                                                                                                                                                                                  
    --   ELSE
        
        ---  ROLLBACK;          
          
     ---  END IF;
            
     v_pat_dtl   := dbms_xmldom.getelementsbytagname(v_element, 'secondary');
     
     FOR parent_node_index in 0 .. dbms_xmldom.getlength(v_pat_dtl) - 1 LOOP-------------
     
       v_child_node := dbms_xmldom.item(v_pat_dtl, parent_node_index);
       v_element1   := dbms_xmldom.makeelement(v_child_node);
       
       v_pat_tag  :=  dbms_xmldom.getelementsbytagname(v_element1, 'ICDCode');
       
          FOR parent_node_list in 0 .. dbms_xmldom.getlength(v_pat_tag) - 1 LOOP------------------
     
           v_child_node1 := dbms_xmldom.getfirstchild(dbms_xmldom.item(v_pat_tag, parent_node_list));
           v_element2    := dbms_xmldom.makeelement(v_child_node);
       
           v_diag_code_scnd  :=  dbms_xmldom.getnodevalue(v_child_node1);
                      
      IF   v_diag_code_scnd IS NOT  NULL THEN 
       
          SELECT SUM(CNT)  INTO V_COUNT FROM
          (SELECT COUNT(1) CNT FROM APP.TPA_ICD_AM_DETAILS M WHERE M.ICD_AM = upper(trim(v_diag_code_scnd))
          UNION ALL
          SELECT COUNT(1) CNT FROM APP.TPA_ICD10_MASTER_DETAILS I WHERE I.ICD_CODE = upper(trim(v_diag_code_scnd)));
                
             
                    IF V_COUNT = 0 THEN 
          
                        create_exception_log(v_xml_seq_id,NULL,NULL,'secondaryICDCode:GIVEN SECONDARY ICD CODE IS INVALID',1,v_diag_code_scnd);    
    
                    END IF;
         
       ---------*****TO CHECK THE ICD CODE IS EXIST FOR THIS PRE AUTH OR NOT******----  
     IF v_pat_ath_seq_id IS NOT NULL THEN
                
                      CHECK_ICD_CODE_DUP(
                                         V_XML_SEQ_ID,
                                         v_pat_ath_seq_id,
                                         upper(trim(v_diag_code_scnd))
                                        );
       
          /*PROCEDURE  CHECK_ICD_CODE_DUP (
                                          V_XML_SEQ_ID, 
                                          v_pat_ath_seq_id,
                                          v_diag_code_scnd
                                          );*/
            /*SELECT count(1) INTO V_COUNT
                FROM  APP.diagnosys_details dd
                WHERE dd.pat_auth_seq_id=v_pat_ath_seq_id                
                AND dd.diagnosys_code=TRIM(upper(v_diag_code_scnd));
                
                     IF V_COUNT > 1 THEN 
          
                         create_exception_log(v_xml_seq_id,NULL,NULL,'GIVEN SECONDARY ICD CODE IS ALREADY EXIST',1,NULL);    
           
                     END IF;*/
                     
        END IF;                     
        -----------------------------------------
       
    END IF;
              
      v_error_exst_yn :=  ERROR_EXIST_YN(v_xml_seq_id);
   
         IF v_diag_code_scnd IS NOT NULL THEN
  ------******SAVE SECONDARY DAIGONOSYS INFORMATION******-----------       
        
            SAVE_DIAGNOSYS_DETAILS
 					                          (		
                                      V_XML_SEQ_ID ,                 
					                          	v_pat_ath_seq_id,						                          
						                          upper(trim(v_diag_code_scnd)),						               
						                          'N',
                                      v_duration_ailment,
					                            v_duration_flag
					                          	);     
                                                         
          END IF;                                              
                                                                                                                                            
     ---  ELSE
        
       --   ROLLBACK;          
          
      --- END IF;
    
                                       
          END LOOP;

      END LOOP;
    
  END LOOP;  
  
------*********DIAGONOSYS  VALIDATION *******----------------
      OPEN   pat_diag_cur(v_pat_ath_seq_id);
      FETCH  pat_diag_cur  INTO v_diag_count;
      CLOSE  pat_diag_cur; 
      
      IF v_diag_count  < 1 THEN 
        
           create_exception_log(v_xml_seq_id,NULL,NULL,'PLEASE ADD ATLEAST ONE DIAGONOSYS',1,v_diag_count);  
     
      END IF;
    
---------************ACTIVITY INFORMATION PARSING AND DATA VALIDATION**************---------------

v_pat_node      :=  dbms_xmldom.getelementsbytagname(v_pat_xml_dtls, 'activities'); -------Retrieves the elements in the DOMNODELIST by tag name
  
   FOR v_root_node_index in 0 .. dbms_xmldom.getlength(v_pat_node) - 1 LOOP   -----Retrieves the length of the data
   
    v_parent_node:= dbms_xmldom.item(v_pat_node, v_root_node_index);   -------Retrieves the item given the index in the map
    v_element    := dbms_xmldom.makeelement(v_parent_node);
          
      v_pat_dtl       := dbms_xmldom.getelementsbytagname(v_element, 'activityType');
      v_child_node1   := dbms_xmldom.getfirstchild(dbms_xmldom.item(v_pat_dtl, 0));
      v_activity_type := dbms_xmldom.getnodevalue(v_child_node1);
 
--------------------------     
      IF  v_activity_type  IS NULL THEN 
        
         create_exception_log(v_xml_seq_id,NULL,NULL,'activityType:ACTIVITY TYPE IS BLANK',1,v_activity_type);  
      
      END IF; 
      
      IF  v_activity_type  IS NOT NULL THEN 
        
        V_COUNT := CASE WHEN  UPPER(TRIM(v_activity_type)) = 'ACT' THEN 1
                        WHEN  UPPER(TRIM(v_activity_type)) = 'DRG' THEN 1
                       ELSE 0 END;
                       
           IF   V_COUNT  = 0 THEN 
                 
               create_exception_log(v_xml_seq_id,NULL,NULL,'activityType:ACTIVITY TYPE IS INVALID',1,v_activity_type);
               
           END IF;         
      
      END IF; 
      
      
----------------------------      
                   
      v_pat_dtl       := dbms_xmldom.getelementsbytagname(v_element, 'serviceType');
      v_child_node1   := dbms_xmldom.getfirstchild(dbms_xmldom.item(v_pat_dtl, 0));
      v_service_type  := dbms_xmldom.getnodevalue(v_child_node1);
 
---------------------     
     IF  UPPER(trim(v_benefitType)) IN ('IPT','IMTI')  AND  v_service_type  IS NULL THEN 
        
         create_exception_log(v_xml_seq_id,NULL,NULL,'serviceType:FOR THIS BENEFIT SERVICE TYPE IS BLANK',1,v_service_type);  
      
      END IF; 
      
      IF  UPPER(TRIM(v_benefitType)) not  IN ('IPT','IMTI')  AND  v_service_type  IS NOT  NULL THEN 
        
        SELECT COUNT(1)  INTO V_COUNT
        FROM TPA_GENERAL_CODE 
        WHERE HEADER_TYPE = 'SERVICE_TYPE' 
        AND UPPER(GENERAL_TYPE_ID)= TRIM(UPPER(v_service_type))
        AND  UPPER(GENERAL_TYPE_ID) != 'SCD';
        
          IF V_COUNT = 0 THEN 
         
               create_exception_log(v_xml_seq_id,NULL,NULL,'FOR THIS BENEFIT TYPE  SERVICE TYPE IS INVALID',1,v_benefitType||'-'||v_service_type);  

          END IF ;
          
      END IF;
        
     IF  UPPER(trim(v_benefitType)) IN ('IPT','IMTI')  AND  v_service_type  IS NOT  NULL THEN 
        
        SELECT COUNT(1)  INTO V_COUNT
        FROM TPA_GENERAL_CODE 
        WHERE HEADER_TYPE = 'SERVICE_TYPE' 
        AND UPPER(GENERAL_TYPE_ID)= TRIM(UPPER(v_service_type));
        
            IF V_COUNT = 0 THEN 
            
               create_exception_log(v_xml_seq_id,NULL,NULL,'serviceType:GIVEN SERVICE TYPE ID IS INVALID',1,NULL);  
         
           END IF;
       
      END IF;  
--------------------------------------     
      
      v_pat_dtl       := dbms_xmldom.getelementsbytagname(v_element, 'startDate');
      v_child_node1   := dbms_xmldom.getfirstchild(dbms_xmldom.item(v_pat_dtl, 0));
      v_start_date    := dbms_xmldom.getnodevalue(v_child_node1);
 
--------------------------     
    IF  v_start_date  IS NULL THEN 
        
       create_exception_log(v_xml_seq_id,NULL,NULL,'startDate:ACTIVITY START DATE IS BLANK',1,v_start_date);  
      
    END IF; 
      
   IF v_start_date  IS NOT NULL THEN 
  

      SELECT  count(1) INTO V_COUNT
      FROM  dual
      WHERE regexp_like(trim(v_start_date), '[[:digit:]]{2}/[[:digit:]]{2}/[[:digit:]]{4}') AND
       '0' =(   select 
                    case when  to_number(substr(trim(v_start_date), 4, 2)) BETWEEN '01' AND '12'  AND
                               to_number(substr(trim(v_start_date),instr(trim(v_start_date),'/',1,2)+1))  BETWEEN '1900' AND '2050' 
                              then '0' else '1' 
                                  end a 
                                  from dual );
        -- (substr(v_start_date, 4, 2) BETWEEN '01' AND '12'  AND
        --  substr(v_start_date, 7, 4)  BETWEEN '1900' AND '2050'  --and
      --- substr('2018/12/32', 9, 2)  between '01' and '31'
        --   );   --------GIVEN FORMAT AND MONTH AND YEAR (IN DATE) VALIDATION
           
     IF  V_COUNT = 0 THEN 
       
          create_exception_log(v_xml_seq_id,NULL,NULL,'startDate:ACTIVITY START DATE IS INVALID',1,v_start_date);                          
      
     END IF;
          
     IF V_COUNT = 1 THEN  --------------GIVEN DAY (IN DATE) VALIDATION
       
     SELECT SUBSTR(trim(v_start_date),INSTR(trim(v_start_date),'/',1,1)+1,2) INTO V_MM
     FROM DUAL;
     
     IF V_MM = 02 THEN 
     
          v_leap_year  := FN_LEAP_YEAR(trim(v_start_date));
          
     END IF;          
     
        v_date :=     CASE WHEN V_MM = 01  THEN  31
                           WHEN V_MM = 02  THEN   CASE WHEN v_leap_year = 'Y' THEN 
                                                              29 
                                                             ELSE 
                                                              28
                                                             END
                           WHEN V_MM = 03  THEN  31
                           WHEN V_MM = 04  THEN  30 
                           WHEN V_MM = 05  THEN  31
                           WHEN V_MM = 06  THEN  30
                           WHEN V_MM = 07  THEN  31
                           WHEN V_MM = 08  THEN  31
                           WHEN V_MM = 09  THEN  30
                           WHEN V_MM = 10  THEN  31
                           WHEN V_MM = 11  THEN  30
                           WHEN V_MM = 12  THEN  31
                       END ;
      
      SELECT  count(1) INTO V_COUNT
      FROM  DUAL
      WHERE regexp_like(trim(v_start_date), '[[:digit:]]{2}/[[:digit:]]{2}/[[:digit:]]{4}') AND
          (
          substr(trim(v_start_date), 1, 2) BETWEEN '01' AND v_date 
           );
           
            IF V_COUNT = 0 THEN 
              
                 create_exception_log(v_xml_seq_id,NULL,NULL,'startDate:ACTIVITY START DATE IS NOT VALID',1,v_start_date);                          

            END IF;
                                                                                     
     END IF;           
      
END IF; 
------------------------      
      
      v_pat_dtl       := dbms_xmldom.getelementsbytagname(v_element, 'modifier');
      v_child_node1   := dbms_xmldom.getfirstchild(dbms_xmldom.item(v_pat_dtl, 0));
      v_modifier      := dbms_xmldom.getnodevalue(v_child_node1);
      
      IF v_modifier IS NOT NULL THEN
        
        SELECT COUNT(1) INTO V_COUNT
        FROM app.TPA_GENERAL_CODE  a
        WHERE a.HEADER_TYPE='MODIFIER_TYPE' and upper(a.general_type_id)  = upper(trim(v_modifier));
      
           IF V_COUNT = 0 THEN 
      
               create_exception_log(v_xml_seq_id,NULL,NULL,'modifier:MODIFIER IS INVALID',1,v_modifier);  
      
            END IF;
        
       END IF;
      
      v_pat_dtl       := dbms_xmldom.getelementsbytagname(v_element, 'internalCode');
      v_child_node1   := dbms_xmldom.getfirstchild(dbms_xmldom.item(v_pat_dtl, 0));
      v_int_code      := dbms_xmldom.getnodevalue(v_child_node1);
  
--------------------------    
      IF  v_int_code  IS NULL THEN 
        
         create_exception_log(v_xml_seq_id,NULL,NULL,'internalCode:INTERNAL CODE IS BLANK',1,v_int_code);  
      
      END IF; 
      
      IF upper(trim(v_benefitType)) IN ('IPT','IMTI')  AND  UPPER(trim(v_service_type)) = 'SCD'  AND  v_int_code  IS NOT NULL  THEN
        
      SELECT COUNT(1) INTO V_COUNT
      FROM APP.TPA_IP_SERVICE_DETAILS A
      WHERE UPPER(A.SERVICE_CODE) =  TRIM(UPPER(v_int_code)) ;
      
         IF V_COUNT = 0 THEN 
      
            create_exception_log(v_xml_seq_id,NULL,NULL,'internalCode:INTERNAL CODE IS NOT VALID AS FOR THIS SERVICE TYPE',1,v_int_code);  
      
         END IF;
      
      END IF;
      
     IF  v_int_code  IS NOT NULL  AND NVL(UPPER(trim(v_service_type)),'NA') != 'SCD' THEN 
                
           CHECK_INTERNAL_CODE( 
                                 v_pat_ath_seq_id,
                                 v_tpa_enroll_id,
                                 v_xml_seq_id,
                                 v_int_code,
                                 v_start_date,
                                 V_YN1
                               );
         
         ----   IF NVL(V_YN1,'Y')= 'Y'  THEN
                             
                  CHK_ACT_INT_CODE_VALID(
                                          v_xml_seq_id ,
                                          v_tpa_enroll_id,
                                          v_activity_type,
                                          v_int_code,
                                          v_start_date
                                        );
           ----  END IF;

           
       END IF;   
            
--------------------------------
                                         
      v_pat_dtl       := dbms_xmldom.getelementsbytagname(v_element, 'unitType');
      v_child_node1   := dbms_xmldom.getfirstchild(dbms_xmldom.item(v_pat_dtl, 0));
      v_unit_type     := dbms_xmldom.getnodevalue(v_child_node1);
	  
	  ----------

    IF v_unit_type  IS NOT NULL THEN    
      
       SELECT COUNT(1)  INTO V_COUNT
       FROM TPA_GENERAL_CODE  
       WHERE HEADER_TYPE='UNIT_TYPE'  AND UPPER(TRIM(GENERAL_TYPE_ID)) = UPPER(TRIM(v_unit_type));
       
       IF V_COUNT = 0 THEN 
         
           create_exception_log(v_xml_seq_id,NULL,NULL,'unitType:GIVEN UNIT TYPE IS INVALID',1,v_unit_type);      

       END IF;
   
    END IF;   
 
------********durationOfMedication******------------------ 
     BEGIN
      
      v_pat_dtl       := dbms_xmldom.getelementsbytagname(v_element, 'durationOfMedication');
      v_child_node1   := dbms_xmldom.getfirstchild(dbms_xmldom.item(v_pat_dtl, 0));
      v_dur_days      := dbms_xmldom.getnodevalue(v_child_node1);
      
      EXCEPTION
        
        WHEN OTHERS THEN
          
            create_exception_log(v_xml_seq_id,NULL,NULL,'durationOfMedication:GIVEN DURATION O FMEDICATION IS INVALID',1,v_dur_days); 
        
     END;

-------*********** quantity *********--------------------- 
     BEGIN
       
      v_pat_dtl       := dbms_xmldom.getelementsbytagname(v_element, 'quantity');
      v_child_node1   := dbms_xmldom.getfirstchild(dbms_xmldom.item(v_pat_dtl, 0));
      v_quantity      := dbms_xmldom.getnodevalue(v_child_node1);
     
      IF  v_quantity  IS NULL THEN 
        
         create_exception_log(v_xml_seq_id,NULL,NULL,'quantity:QUANTITY FIELD IS BLANK',1,v_quantity);  
      
      END IF; 
      
     EXCEPTION
        
        WHEN OTHERS THEN
          
            create_exception_log(v_xml_seq_id,NULL,NULL,'quantity:GIVEN quantity IS INVALID',1,v_quantity); 
        
     END;
     
-------******** posology **********-------------------   
     BEGIN
         
      v_pat_dtl       := dbms_xmldom.getelementsbytagname(v_element, 'posology');
      v_child_node1   := dbms_xmldom.getfirstchild(dbms_xmldom.item(v_pat_dtl, 0));
      v_posology      := dbms_xmldom.getnodevalue(v_child_node1);
      
      
       IF v_posology IS NOT NULL THEN 
        
        V_COUNT := CASE WHEN  UPPER(TRIM(v_posology)) = 1 THEN 1
                        WHEN  UPPER(TRIM(v_posology)) = 2 THEN 1
                        WHEN  UPPER(TRIM(v_posology)) = 3 THEN 1
                        WHEN  UPPER(TRIM(v_posology)) = 4 THEN 1
                       ELSE 0 END;    
                       
          IF   V_COUNT = 0 THEN
             
             create_exception_log(v_xml_seq_id,NULL,NULL,'posology:POSOLOGY FIELD IS INVALID',1,v_posology); 
            
          END IF;
          
       END IF;
      
     EXCEPTION
        
        WHEN OTHERS THEN
          
            create_exception_log(v_xml_seq_id,NULL,NULL,'posology:GIVEN POSOLGY IS INVALID',1,v_posology); 
        
     END;
	  

   /*   IF v_posology IS NOT NULL THEN 
        
        V_COUNT := CASE WHEN  UPPER(TRIM(v_posology)) = 1 THEN 1
                        WHEN  UPPER(TRIM(v_posology)) = 2 THEN 1
                        WHEN  UPPER(TRIM(v_posology)) = 3 THEN 1
                        WHEN  UPPER(TRIM(v_posology)) = 4 THEN 1
                       ELSE 0 END;    
                       
          IF   V_COUNT = 0 THEN
             
             create_exception_log(v_xml_seq_id,NULL,NULL,'posology:POSOLOGY FIELD IS INVALID',1,NULL); 
            
          END IF;
          
       END IF;    */                      
  
  --------*********unitPrice**************--------------------
    BEGIN
        
      v_pat_dtl       := dbms_xmldom.getelementsbytagname(v_element, 'unitPrice');
      v_child_node1   := dbms_xmldom.getfirstchild(dbms_xmldom.item(v_pat_dtl, 0));
      v_unit_price    := dbms_xmldom.getnodevalue(v_child_node1);
      
       IF  v_unit_price  IS NULL THEN 
        
         create_exception_log(v_xml_seq_id,NULL,NULL,'unitPrice:UNIT PRICE FIELD IS BLANK',1,v_unit_price);  
      
      END IF; 
      
      EXCEPTION
        
        WHEN OTHERS THEN
          
            create_exception_log(v_xml_seq_id,NULL,NULL,'unitPrice:GIVEN UNITPRICE IS INVALID',1,v_unit_price); 
        
      END;
          
 --------*****discount***********-----------
 
    BEGIN
        
      v_pat_dtl       := dbms_xmldom.getelementsbytagname(v_element, 'discount');
      v_child_node1   := dbms_xmldom.getfirstchild(dbms_xmldom.item(v_pat_dtl, 0));
      v_discount_amt  := dbms_xmldom.getnodevalue(v_child_node1);
      
     EXCEPTION
        
        WHEN OTHERS THEN
          
            create_exception_log(v_xml_seq_id,NULL,NULL,'discount:GIVEN DISCOUNT IS INVALID',1,v_discount_amt); 
        
     END; 
 
 -----***********     
      v_pat_dtl       := dbms_xmldom.getelementsbytagname(v_element, 'allowed');
      v_child_node1   := dbms_xmldom.getfirstchild(dbms_xmldom.item(v_pat_dtl, 0));
      v_allow_yn      := dbms_xmldom.getnodevalue(v_child_node1);
      
      
      
      v_error_exst_yn :=  ERROR_EXIST_YN(v_xml_seq_id);
   
     ---  IF  v_error_exst_yn = 'N'  THEN 
          
         SAVE_ACTIVITY_DETAILS  
                                (  
                                V_XML_SEQ_ID,                            
                                v_pat_ath_seq_id,
                                upper(trim(v_activity_type)),
                               	v_service_type,
            	                  trim(v_start_date),
            	                  v_modifier,
            	                  v_int_code,
                                v_unit_type,
	                              v_dur_days,
                                v_quantity,
                              	v_posology,
                               	v_unit_price,
                                v_discount_amt,
                                v_allow_yn,
                                v_benefitType,
                                v_clinician_id,
                                v_tpa_enroll_id
                                );

 ------**** VALIDATION FOR BENEFIT TYPE OUT-PATIENT AND OUT-PATIENT  MATERNITY  IF THE MASTER ACITIVITY CODE 63    
 IF  upper(trim(v_activity_type)) = 'ACT' THEN 
          
     IF  UPPER(TRIM(v_benefitType)) IN  ('OPTS','OMTI')  THEN  
       
         SELECT COUNT(1) INTO v_cons_act_cnt
         FROM pat_authorization_details pa
         JOIN pat_activity_details a ON (pa.pat_auth_seq_id=a.pat_auth_seq_id)
         LEFT OUTER JOIN APP.TPA_ACTIVITY_MASTER_DETAILS c ON (A.CODE = c.activity_code)
         where pa.pat_auth_seq_id = v_pat_ath_seq_id
         and pa.benifit_type in ('OPTS','OMTI')
         and c.master_activity_code in ('63');  
         
         IF v_cons_act_cnt > 0 THEN 
           
             create_exception_log(v_xml_seq_id,NULL,NULL,'benefitType,internalCode:BENEFIT TYPE NOT MATCHING WITH INTERNAL CODE'||'-'||v_benefitType||','||v_int_code,1,v_benefitType||'-'||v_int_code);  
                                        
         END IF;
      
     END IF; 
   
 END IF;  
----------*************
        
     ---  ELSE
        
         -- ROLLBACK;          
          
     ---  END IF;
                     
  END LOOP;  
  
 v_error_exst_yn :=  ERROR_EXIST_YN(v_xml_seq_id);
   
       IF  v_error_exst_yn = 'N'  THEN 
         
           UPDATE APP.PAT_XML_UPLD_DTA A
           SET  A.PAT_AUTH_SEQ_ID = v_pat_ath_seq_id--,
              ---  A.tpa_enrollment_id  = v_tpa_enroll_id
           WHERE A.XML_SEQ_ID = v_xml_seq_id;
           
       END IF;
       
  v_error_exst_yn :=  ERROR_EXIST_YN(v_xml_seq_id);  
  
    IF  v_error_exst_yn = 'N'  THEN     
       
        GENERATE_MAIL_PKG.proc_generate_message('PREAUTH_RECEIPT',
                                                v_pat_ath_seq_id,
                                                1,
                                                v_dest_msg_seq_id); --PREAUTH_RECEIPT_NHCP

        GENERATE_MAIL_PKG.proc_generate_message('PREAUTH_RECEIPT_NHCP',
                                                v_pat_ath_seq_id,
                                                1,
                                                v_dest_msg_seq_id);
                                          
      END IF;                                          
       
  v_error_exst_yn :=  ERROR_EXIST_YN(v_xml_seq_id);
  
     IF  v_error_exst_yn = 'N'  THEN 
 
        COMMIT;
        
     ELSE
       
        ROLLBACK;
        
     END IF;
 
EXCEPTION
  
WHEN OTHERS THEN
  
     V_SQL_CODE := SQLCODE;
     V_SQL_MSG  := SQLERRM;

       create_exception_log(v_xml_seq_id,V_SQL_CODE,V_SQL_MSG,V_SQL_MSG,1,NULL);  
 
END PARSE_PAT_XML_DTLS;

------*************ERROR LOG TRACKING****************---------------------

PROCEDURE CREATE_EXCEPTION_LOG(
                              v_xml_seq_id            IN NUMBER,                             
                              v_sql_code              IN VARCHAR2,
                              v_sql_msg               IN VARCHAR2,
                              V_USER_DEFNED_MSG       IN CLOB,
                              v_added_by              IN NUMBER,
                              V_ERR_MSG               IN VARCHAR2
                               )
 IS
 PRAGMA AUTONOMOUS_TRANSACTION;
 BEGIN
   
   INSERT INTO APP.PAT_EXCEPTION_LOGS
          (LOG_SEQ_ID,
           XML_SEQ_ID,         
           SQL_CODE,
           SQL_MSG,
           USER_DEFINED_ERROR_MSG,
           ADDED_BY,
           ADDED_DATE,
           ERR_MSG)
   VALUES (APP.PAT_EXCEP_LOGS_SEQ.NEXTVAL,
           V_XML_SEQ_ID,     
           V_SQL_CODE,
           V_SQL_MSG,
           V_USER_DEFNED_MSG,
           V_ADDED_BY,
           SYSDATE,
           V_ERR_MSG);
                                
  COMMIT;
 
 END CREATE_EXCEPTION_LOG; 
 
 ------------************LEAP YEAR***************--------------------
 
 FUNCTION FN_LEAP_YEAR (p_year IN VARCHAR2) 
   RETURN VARCHAR2
  IS
    
    v_day NUMBER;
    v_year VARCHAR2(4);
    v_res  VARCHAR2(5);
    v_substr  VARCHAR2(11);
    v_len     NUMBER;
    
  BEGIN
    
  IF p_year IS NULL THEN
      v_year := TO_CHAR(SYSDATE, 'RRRR');
    ELSE
      v_len  := LENGTH(p_year);
      IF v_len = 11 THEN
        v_substr := SUBSTR(p_year, 8);
      ELSIF v_len = 10 THEN
        v_substr := SUBSTR(p_year, 7);
      END IF;
      v_year := TO_CHAR(v_substr);
    END IF;
    
    
    SELECT CASE
             WHEN ( MOD(v_year, 4) = 0 AND MOD(v_year, 100) <> 0 ) OR
                  ( MOD(v_year, 400) = 0 ) THEN 1
             ELSE 0
            END INTO v_day
    FROM DUAL;
    
     IF v_day = 1 THEN 
       
         v_res := 'Y';
        RETURN v_res;
        
     ELSE 
        
        v_res := 'N';
        RETURN v_res;
        
     END IF;
     
  END FN_LEAP_YEAR;
  
----------****NEED TO CHECK WHEATHER ERROR EXIST OR NOT *****-------------------

FUNCTION  ERROR_EXIST_YN(
                         v_xml_seq_id         IN NUMBER
						             )
 RETURN VARCHAR2

 AS

   CURSOR ERROR_LOG_CUR
   IS
   SELECT COUNT(1)
   FROM APP.PAT_EXCEPTION_LOGS A
   WHERE A.XML_sEQ_ID = v_xml_seq_id;

   V_COUNT    NUMBER;

BEGIN

    OPEN  ERROR_LOG_CUR;
    FETCH ERROR_LOG_CUR INTO V_COUNT;
    CLOSE ERROR_LOG_CUR;

  IF   V_COUNT > 0 THEN 
   
       RETURN 'Y';
	   
  ELSE
	   
	      RETURN 'N' ;
	   
  END IF;

  
END ERROR_EXIST_YN;
---------*******PREAUTH INFORMATION SAVE***********----------------

PROCEDURE SAVE_AUTHORIZATION_DETAILS(
                                     v_disposition                       IN   VARCHAR2,
                                     v_pat_ath_seq_id                  IN OUT APP.pat_authorization_details.pat_auth_seq_id%type,
                                     v_event_no                          IN   APP.pat_authorization_details.event_no%TYPE,
									                   v_med_type                          IN   APP.pat_authorization_details.system_of_medicine_type_id%TYPE,
									                   v_accid_rel_case                    IN   APP.pat_authorization_details.accident_related_type_id%TYPE,
									                   v_tpa_enroll_id                     IN   APP.pat_authorization_details.tpa_enrollment_id%TYPE,
									                   v_requested_amnt                    IN   APP.pat_authorization_details.requested_amount%TYPE,
									                   v_clinician_id                      IN   APP.pat_authorization_details.clinician_id%TYPE,
									                   v_clinicianname                     IN   APP.tpa_hosp_professionals.contact_name%TYPE,
									                   v_benefitType                       IN   APP.pat_authorization_details.benifit_type%TYPE,
									                   v_encounterType                     IN   APP.pat_authorization_details.encounter_type_id%TYPE,
                                     v_encterStrtType                    IN   APP.pat_authorization_details.encounter_start_type%TYPE,
 									                   v_encterEndType                     IN   APP.pat_authorization_details.encounter_end_type%TYPE,
									                   v_date_of_hosp                      IN   VARCHAR2,
								                  	 v_date_hosp_time                    IN   VARCHAR2,
                                     v_hosp_time_am                      IN   VARCHAR2,
                                     v_date_of_exit                      IN   VARCHAR2,--pat_authorization_details.discharge_date%TYPE;
                                     v_date_dis_time                     IN   VARCHAR2,
                                     v_dish_time_pm                      IN   VARCHAR2,
                                     v_den_encnt_type                    IN   APP.pat_authorization_details.treatment_type%TYPE,
                                     v_lmp                               IN   VARCHAR2,
                                     v_mode_of_delvry                    IN   APP.pat_authorization_details.delvry_mod_type%TYPE,
                                     v_nat_conception                    IN   APP.pat_authorization_details.conception_type%TYPE,
									                   v_pre_auth_number                 IN OUT APP.pat_authorization_details.pre_auth_number%TYPE,
                                     v_presenting_complaints             IN   APP.pat_authorization_details.presenting_complaints%TYPE,
                                     v_clinician_mail                    IN   APP.pat_authorization_details.clinician_mail%type,
                                     v_xml_seq_id                        IN   NUMBER,
                                     v_rows_processed                    OUT  NUMBER
								                 	 )
									 
AS

   CURSOR hosp_id_cur
   IS
   SELECT  A.HOSP_SEQ_ID ,A.HOSP_LICENC_NUMB,UPPER(A.HOSP_NAME) as  HOSP_NAME
    FROM   APP.TPA_HOSP_INFO A
   WHERE 	UPPER(A.HOSP_NAME) LIKE '%AL AHLI HOSPITAL%'	;

   v_hosp_seq_id                           hosp_id_cur%ROWTYPE;

   CURSOR member_detls_cur
   IS
   SELECT a.member_seq_id,
         a.tpa_enrollment_id,---Al Koot ID:* 
         a.global_net_member_id ,
         a.mem_name/*||' '||a.mem_last_name||' '||a.family_name */ as mem_name,--Patient Name
         nvl(a.mem_age,(months_between(sysdate,a.mem_dob)/12)) as mem_age,-----Age:
         a.emirate_id,-----Qatar Id:
         tii.ins_seq_id,
         tii.ins_comp_name,-----Insurer Name:
         tii.ins_comp_code_number as payer_id,-----------Insurer Id:
         c.policy_seq_id,
         c.enrol_type_id,
         account_info_pkg.get_gen_desc(A.GENDER_GENERAL_TYPE_ID,'G') AS gender,----Gender:
         c.policy_number  as policy_number,   ------Policy No.:
         d.group_name  as corporate_name,-----Corporate Name:
         d.group_reg_seq_id,
         c.effective_from_date as policy_start_date, ---Policy Start Date:
         c.effective_to_date as policy_end_date,-----------Policy End Date:
         nc.description as nationality, ---------Nationality:
         nvl(eb.sum_insured,0) - nvl(eb.utilised_sum_insured,0) AS ava_sum_insured,----Available Sum Insured
         EB.SUM_INSURED,--------------Sum Insured:
         ip.product_name,----Product Name.:
         case when nvl(a.vip_yn,'N')='N' then 'No' else 'Yes' end as vip_yn,----VIP:
         ip.product_cat_type_id as NETWORK_TYPE,------Eligible Networks

        to_char(a.date_of_inception, 'DD/MM/YYYY') as clm_mem_insp_date,-----Member Inception Date:
         tii.payer_authority, --payer authority----------Authority.:
         UPPER(TRIM(REPLACE(d.group_name,' ',''))) AS CORP_NAME
         
  FROM   APP.tpa_enr_policy_member A
  JOIN   APP.tpa_enr_policy_group B ON (A.policy_group_seq_id = B.policy_group_seq_id)
  JOIN   APP.tpa_enr_policy C ON (B.policy_seq_id = C.policy_seq_id )
  JOIN   APP.tpa_ins_product ip ON (ip.product_seq_id=c.product_seq_id)
  LEFT OUTER JOIN APP.tpa_group_registration d ON (d.group_reg_seq_id=c.group_reg_seq_id)
  join   APP.tpa_ins_info tii on (c.ins_seq_id=tii.ins_seq_id)
  left outer join APP.tpa_nationalities_code nc on (nc.nationality_id=a.nationality_id)
  LEFT OUTER JOIN APP.tpa_enr_balance eb ON (b.policy_group_seq_id = eb.policy_group_seq_id)
  WHERE (a.tpa_enrollment_id=trim(upper(v_tpa_enroll_id)) or a.global_net_member_id = trim(upper(v_tpa_enroll_id)))
 -- AND ( SYSDATE BETWEEN C.effective_from_date AND C.effective_to_date+1)
  and  (a.mem_general_type_id != 'PFL' AND a.member_seq_id = eb.member_seq_id OR eb.member_seq_id IS NULL OR a.member_seq_id IS NULL)
  and a.status_general_type_id in ('POA','POC')
  AND b.status_general_type_id IN ('POA','POC')
  AND C.COMPLETED_YN='Y'
  and B.DELETED_YN='N'
  AND A.DELETED_YN='N'
  AND TO_DATE(TRIM(v_date_of_hosp),'DD-MM-RRRR') BETWEEN TO_DATE(C.EFFECTIVE_FROM_DATE,'DD-MM-RRRR') 
                                                AND TO_DATE(C.EFFECTIVE_TO_DATE,'DD-MM-RRRR')+1;
   
     mem_dtls                              member_detls_cur%ROWTYPE;  
  
  
    CURSOR  mem_cur(v_member_seq_id    number)
    IS
    SELECT tepm.date_of_inception,
           tepm.date_of_exit,
           tepm.mem_name,
           tepm.mem_age,
           tcc.short_name,
           tsc.state_type_id,
           tepg.policy_group_seq_id,
           tepg.policy_seq_id,
           tepm.member_seq_id
    FROM   APP.tpa_enr_policy_group tepg
      JOIN APP.tpa_enr_policy_member tepm
        ON (tepg.policy_group_seq_id = tepm.policy_group_seq_id)
     LEFT OUTER JOIN APP.tpa_enr_mem_address tema
        ON (tepg.enr_address_seq_id = tema.enr_address_seq_id)
     LEFT OUTER JOIN APP.tpa_country_code tcc
        ON (tema.country_id = tcc.country_id)
     LEFT OUTER JOIN APP.tpa_state_code tsc
        ON (tema.state_type_id = tsc.state_type_id)
     WHERE tepm.Member_Seq_Id = v_member_seq_id;
	 
	
    mem_rec                              mem_cur%rowtype; 
    
    CURSOR clinician_cur(v_hosp_id   NUMBER) 
    IS
    SELECT A.CONSULT_GEN_TYPE,A.SPECIALITY_ID
    FROM APP.TPA_HOSP_PROFESSIONALS A -----CONSULT_GEN_TYPE,SPECIALTY_ID
    WHERE   A.PROFESSIONAL_ID = TRIM(v_clinician_id) AND HOSP_SEQ_ID = v_hosp_id;
    
    clin_rec                             clinician_cur%ROWTYPE;   
    
/*    CURSOR pat_id_cur
    IS
    SELECT A.PAT_AUTH_SEQ_ID
    FROM APP.PAT_AUTHORIZATION_DETAILS A
    WHERE A.PRE_AUTH_NUMBER = v_pre_auth_number;
    
    
    pat_rec                             pat_id_cur%rowtype;*/
    
 -- v_pre_auth_number                    app.pat_authorization_details.pre_auth_number%type;
    v_prod_policy_rule_seq_id            app.tpa_ins_prod_policy_rules.prod_policy_rule_seq_id%type;            
 -- v_pat_ath_seq_id                     app.pat_authorization_details.pat_auth_seq_id%type;
    v_denial_reason                      app.pat_authorization_details.denial_reason%type;
    v_provider_name                      app.pat_non_network_details.provider_name%type;
    v_provider_id                        app.pat_non_network_details.provider_id%type;
    v_city_type_id                       app.pat_non_network_details.city_type_id%type;
    v_state_type_id                      app.pat_non_network_details.state_type_id%type;
    v_country_type_id                    app.pat_non_network_details.country_type_id%type;
    v_provider_address                   app.pat_non_network_details.provider_address%type;
    v_pincode                            app.pat_non_network_details.pincode%type;
    v_auth_number                        app.pat_authorization_details.auth_number%type;
    v_hosp_time                          VARCHAR2(100);
    v_fin_hosp_time                      DATE;
    v_dis_time                           VARCHAR2(100); 
    v_fin_dis_time                       DATE;
    v_lmp_date                           DATE;
    v_seq_id                             NUMBER;
    V_SQL_CODE                           VARCHAR2(100);
    V_SQL_MSG                            VARCHAR2(4000);
    V_YN                                 VARCHAR2(10);
    V_YN1                                VARCHAR2(10);
    V_YN2                                VARCHAR2(10);
    V_PL_REFNO                           VARCHAR2(100);
    
              
BEGIN
  
  
  OPEN   hosp_id_cur;
  FETCH  hosp_id_cur   INTO   v_hosp_seq_id;
  CLOSE  hosp_id_cur;

  BEGIN

  OPEN   member_detls_cur;
  FETCH  member_detls_cur  INTO  mem_dtls;
  CLOSE  member_detls_cur;
  
  EXCEPTION
   
     WHEN OTHERS THEN 
          
      create_exception_log(v_xml_seq_id,V_SQL_CODE,V_SQL_MSG,'alKootID,startdate:invalid hosp time or alkoot id',1,'SAVE_AUTHORIZATION_DETAILS');               
  
   END ;
  
  OPEN   mem_cur(mem_dtls.member_seq_id);
  FETCH  mem_cur     INTO    mem_rec;
  CLOSE  mem_cur;
  
  OPEN  clinician_cur(v_hosp_seq_id.hosp_Seq_id);
  FETCH clinician_cur  INTO clin_rec;
  CLOSE clinician_cur;
  

  ------******DATE FORMAT******------
        BEGIN
    
           v_hosp_time             := v_date_of_hosp||v_date_hosp_time||v_hosp_time_am;
           v_fin_hosp_time         := to_date(v_hosp_time , 'dd-mm-rrrrHH:MIAM');   ------HOSPITALIZATION DATE
   
        EXCEPTION
   
           WHEN OTHERS THEN 
          
            V_YN   := 'N';
  
         END ;
   ------***----
         BEGIN
    
             v_dis_time              := v_date_of_exit||v_date_dis_time||v_dish_time_pm;
             v_fin_dis_time          := to_date(v_dis_time , 'dd-mm-rrrrHH:MIAM');----------DISCHARGE DATE
 
         EXCEPTION
   
            WHEN OTHERS THEN 
                       
            V_YN1   := 'N';
  
          END ;
    ------***----
          BEGIN
    
             v_lmp_date    :=   TO_DATE(v_lmp,'DD-MM-YYYY');---------------LMP DATE
   
          EXCEPTION
   
             WHEN OTHERS THEN 
          
             V_YN2   := 'N';
  
           END ;
  ----****
    -----generating pre-auth number
   IF v_pre_auth_number IS NULL and TRIM(UPPER(v_disposition))  = 'A'  THEN
     
       v_pre_auth_number := authorization_pkg.generate_id_numbers(
                                                                  'PA',
                                                                   mem_rec.short_name,
                                                                   mem_rec.state_type_id,
                                                                   v_pre_auth_number
                                                                  );
                                                                  
       V_PL_REFNO := HOSP_DIAGNOSYS_PKG.generate_id_numbers('PL');
                                                                         
    END IF;
   
    -----generating auth number
    /*
       v_auth_number  := authorization_pkg.generate_id_numbers(
                                                               'AT',
                                                               mem_rec.short_name,
                                                               mem_rec.state_type_id,
                                                               v_pre_auth_number
                                                               );*/
    
IF    trim(upper(v_disposition))  = 'A'  THEN      
    
     INSERT INTO PAT_AUTHORIZATION_DETAILS
                              (
                                pat_auth_seq_id,
                                parent_pat_auth_seq_id,
                                pat_received_date,
                                discharge_date,
                                source_type_id,
                                hospitalization_date,
                                enrol_type_id,
                                member_seq_id,
                                tpa_enrollment_id,
                                pre_auth_number,
                                auth_number,
                                mem_name,
                                mem_age,
                                ins_seq_id,
                                hosp_seq_id,
                                policy_seq_id,
                                tpa_office_seq_id,
                                emirate_id,
                                encounter_type_id,
                                encounter_facility_id,
                                encounter_start_type,
                                encounter_end_type,
                                ava_sum_insured,
                                remarks,
                                denial_reason,
                                pat_enhanced_yn,
                                currency_type,
                                maternity_yn,
                                pat_status_type_id,
                                clinician_id,
                                system_of_medicine_type_id,
                                accident_related_type_id,
                                added_by,
                                added_date,
                                priority_general_type_id,
                                network_yn,
                                requested_amount,
                                benifit_type,
                                gravida,
                                para,
                                live,
                                abortion,
                                past_history   ,
                                duration_above_illness ,
                                duration_above_illness_time ,
                                since_when ,
                                since_when_time,
                                clinician_speciality,
                                consultation_type,----
                                -------------------------------
                                Oral_diagnosis,
                                Oral_services,
                                Orala_Aproved_amount,
                                Oral_system_Status,
                                Oral_diagnosis_revised,
                                Oral_services_revised,
                                Orala_Aproved_amount_revised,
                                pl_preauth_refno,
                                presenting_complaints,
                                file_name,
                                conception_type,
                                lmp_date,
                                REQ_AMT_CURRENCY_TYPE,
                                CONVERTED_AMOUNT,
                                CONVERTED_AMOUNT_CURRENCY_TYPE,
                                CONVERSION_RATE,
                                PROCESS_TYPE,
                                oth_tpa_ref_no,
                                treatment_type,
	                              ptnr_seq_id,   --newly added for partner
                                onl_pat_auth_seq_id,--newly added for partner
                                onl_pre_auth_refno,  --newly added for partner
	                              delvry_mod_type,
	                              event_no,
                                xml_seq_id,
                                clinician_mail ------NEWLY ADDED FOR ALAHALI ENHANCEMENT
                                )
                        VALUES
                               (
                               pat_auth_detail_seq.nextval,----------------
                               0,--------------v_parent_pat_auth_seq_id--------------1(YES)
                               SYSDATE,--------------------
                               CASE WHEN V_YN  = 'N'  THEN NULL ELSE v_fin_dis_time END,------------------v_discharge_date------------------2
                               'ONL1',---------------------
                               CASE WHEN V_YN1 = 'N' THEN NULL ELSE v_fin_hosp_time END,-----------------v_hospitalization_date------------3
                               mem_dtls.enrol_type_id,----------***newly added in enhancement
                               mem_rec.member_seq_id,------------
                               v_tpa_enroll_id,-----------
                               v_pre_auth_number,------------
                               null,----------------v_auth_number---------newly added
                               mem_rec.mem_name,------------------
                               mem_rec.mem_age,---------------
                               mem_dtls.ins_seq_id,---------------
                               v_hosp_seq_id.hosp_seq_id,---------
                               mem_rec.policy_seq_id,-----------------
                               1,--------------------
                               mem_dtls.emirate_id,----------
                               v_encounterType,-------------
                               NULL,-----------------v_encounter_facility_id--------------5(YES)
                               NVL(v_encterStrtType,1),------------- By default value as application always elective
                               v_encterEndType,--------------
                               mem_dtls.ava_sum_insured,--------------------
                               NULL,---------------v_remarks
                               v_denial_reason,--------------v_denial_reason
                               'N',-----------------------
                               'QAR',-------------------v_currency_type = 'QAR'
                               case when nvl(v_benefitType,'A') IN ('MTI', 'OMTI', 'IMTI') THEN 
                                  'Y' 
                                  ELSE 
                                  'N' 
                                  end,------------
                               'INP',---------------
                                UPPER(TRIM(v_clinician_id)),----------------
                                v_med_type,-------------------
                                v_accid_rel_case,------------
                                 1,-------------------------
                                SYSDATE,---------------------
                                CASE WHEN mem_dtls.CORP_NAME LIKE 'ALJAZEERAMEDIANETWORK%' THEN 'HIG' ELSE 'MID' END,-------------v_priority_gen_type_id = 'MID'
                                'Y',----------v_network_yn = 'Y'
                                 v_requested_amnt,-------------
                                 v_benefitType,-----------------
                                 NULL,------------v_gravida
                                 NULL,---------v_para
                                 NULL,-----------v_live
                                 NULL,---------v_abortion
                                 NULL   ,-----------v_past_history---------------------6(YES)
                                 NULL ,-----------v_duration_above_illness-------------7(YES)
                                 NULL,-----------v_duration_above_illness_time--------8(YES)
                                 NULL ,-------------v_since_when-----------------------9(YES)
                                 NULL,-----------v_since_when_time---------------------10(YES)
                                 clin_rec.SPECIALITY_ID,---------------
                                 clin_rec.CONSULT_GEN_TYPE,--------------
                           --------------------------------------
                                 NULL,------v_Oral_diagnosis
                                 NULL,-----v_Oral_services
                                 NULL,------v_Orala_Aproved_amount
                                 NULL,-----v_Oral_system_Status
                                 NULL,-----v_Oral_diagnosis_revised
                                 NULL,-----v_Oral_services_revised
                                 NULL,-------v_Orala_Aproved_amount_revised
                                 V_PL_REFNO,-----v_pl_preauth_refno    V_PL_REFNO
                                 NVL(v_presenting_complaints,'NA'),---v_presenting_comp----------11(YES)----NEWLY ADDED (PREVIOUSLY NULL)
                                 NULL,------v_file_name
                                 v_nat_conception,-----------------------
                                  CASE WHEN V_YN2 = 'N' THEN NULL ELSE v_lmp_date END,------------------------
                                 'QAR',----------------NVL(v_req_amt_currency_type,rec_hosp_currency_id.currency_id),
                                 v_requested_amnt,------------------v_conv_QAR_amnt
                                 'QAR',----------- v_CONVERTED_AMT_CURRENCY_TYPE
                                  1,-------------------------NVL(NVL(v_conversion_rate,currency_con_rec.aed_per_unit),1)
                                 'RGL',--------------------------------------
                                  NULL,------------v_oth_tpa_ref_no--------------------------12(YES)
                                  v_den_encnt_type,------------------
	                                null,   ------------------
                                  null ,------------
                                  null, --------------
                                  v_mode_of_delvry,-----------------------------
	                                v_event_no,-------------------
                                  v_xml_seq_id,
                                  v_clinician_mail ------NEWLY ADDED FOR ALAHALI ENHANCEMENT
                                  )
                                 RETURNING pat_auth_seq_id INTO v_pat_ath_seq_id;
                                 
                                 
     INSERT INTO PAT_NON_NETWORK_DETAILS
                                 (
                                 PAT_NON_NETWORK_SEQ_ID,
                                 PAT_AUTH_SEQ_ID,
                                 PROVIDER_NAME,
                                 PROVIDER_ID,
                                 CITY_TYPE_ID,
                                 STATE_TYPE_ID,
                                 COUNTRY_TYPE_ID,
                                 PROVIDER_ADDRESS,
                                 PINCODE,
                                 ADDED_BY,
                                 ADDED_DATE,
                                 CLINICIAN_ID,
                                 CLINICIAN_NAME
                                 )
                      values
                                (
                                PAT_NON_NETWORK_DETAILS_SEQ.nextval,
                                v_pat_ath_seq_id,
                                v_hosp_seq_id.HOSP_NAME,
                                v_hosp_seq_id.HOSP_LICENC_NUMB,
                                v_city_type_id,
                                v_state_type_id,
                                v_country_type_id,
                                v_provider_address,
                                v_pincode,
                                1,
                                sysdate,
                                UPPER(TRIM(v_clinician_id)),
                                v_clinicianname
                                 );
                                 
                                                                 
                                                                  
END IF;  

------*******ASSIGN USER*******-------------------------

authorization_pkg.reassign_user('|'||v_pat_ath_seq_id||'|',null,null,1,'AUT',v_seq_id);

-----------------------
       
      v_prod_policy_rule_seq_id := AUTHORIZATION_PKG.get_prod_pol_seq_id (
                                                                          mem_rec.policy_seq_id,
                                                                          'POL'
                                                                          );

        pat_xml_load_pkg.execute_global_rules(
                                                'P',
                                                 v_pat_ath_seq_id,
                                                 mem_rec.member_seq_id,
                                                 v_prod_policy_rule_seq_id
                                              );

         AUTHORIZATION_PKG.check_pat_approved(v_pat_ath_seq_id,1); 

------------------*****EXCEPTION BLOCK***----------

EXCEPTION
  
WHEN OTHERS THEN
  
     V_SQL_CODE := SQLCODE;
     V_SQL_MSG  := SQLERRM;

       create_exception_log(v_xml_seq_id,V_SQL_CODE,V_SQL_MSG,V_SQL_MSG,1,'SAVE_AUTHORIZATION_DETAILS');                                  
                                         
       
 
END SAVE_AUTHORIZATION_DETAILS;

----------*************SAVE DENTAL INFORMATION***********------------------------

PROCEDURE  SAVE_ORTHO_DETAILS(
                             v_xml_seq_id                      IN   NUMBER,
                             v_disposition                     IN  VARCHAR2,
                             v_pat_ath_seq_id                  IN  APP.pat_authorization_details.pat_auth_seq_id%type,                     
                             p_dento_class_i                   IN  APP.orthodontic_details_tab.dento_class_i%TYPE,
                             p_dento_class_ii                  IN  APP.orthodontic_details_tab.dento_class_ii%TYPE,
                             p_dento_class_ii_text             IN  APP.orthodontic_details_tab.dento_class_ii_text%TYPE,
                             p_dento_class_iii                 IN  APP.orthodontic_details_tab.dento_class_iii%TYPE,
                             p_dento_class_iii_text            IN  APP.orthodontic_details_tab.dento_class_iii_text%TYPE,
                             p_skele_class_i                   IN  APP.orthodontic_details_tab.skele_class_i%TYPE,
                             p_skele_class_ii                  IN  APP.orthodontic_details_tab.skele_class_ii%TYPE,
                             p_skele_class_iii                 IN  APP.orthodontic_details_tab.skele_class_iii%TYPE,
                             p_overjet_mm                      IN  APP.orthodontic_details_tab.overjet_mm%TYPE,
                             p_rev_overjet_mm                  IN  APP.orthodontic_details_tab.rev_overjet_mm%TYPE,
                             p_rev_overjet_yn                  IN  APP.orthodontic_details_tab.rev_overjet_yn%TYPE,
                             p_crossbite_ant                   IN  APP.orthodontic_details_tab.crossbite_ant%TYPE,
                             p_crossbite_post                  IN  APP.orthodontic_details_tab.crossbite_post%TYPE,
                             p_crossbite_betw                  IN  APP.orthodontic_details_tab.crossbite_betw%TYPE,
                             p_openbit_ant                     IN  APP.orthodontic_details_tab.openbit_ant%TYPE,
                             p_openbit_post                    IN  APP.orthodontic_details_tab.openbit_post%TYPE,
                             p_openbit_late                    IN  APP.orthodontic_details_tab.openbit_late%TYPE,
                             p_cont_point_disp                 IN  APP.orthodontic_details_tab.cont_point_disp%TYPE,
                             p_overbit                         IN  APP.orthodontic_details_tab.overbit_deep%TYPE,
                             p_overbit_pata                    IN  APP.orthodontic_details_tab.overbit_pata%TYPE,
                             p_overbit_ging                    IN  APP.orthodontic_details_tab.overbit_ging%TYPE,
                             p_hypo_quad1                      IN  APP.orthodontic_details_tab.hypo_quad1%TYPE,
                             p_hypo_quad2                      IN  APP.orthodontic_details_tab.hypo_quad2%TYPE,
                             p_hypo_quad3                      IN  APP.orthodontic_details_tab.hypo_quad3%TYPE,
                             p_hypo_quad4                      IN  APP.orthodontic_details_tab.hypo_quad4%TYPE,
                             p_others_impeded                  IN  APP.orthodontic_details_tab.others_impeded%TYPE,
                             p_others_impact                   IN  APP.orthodontic_details_tab.others_impact%TYPE,
                             p_others_submerg                  IN  APP.orthodontic_details_tab.others_submerg%TYPE,
                             p_others_supernum                 IN  APP.orthodontic_details_tab.others_supernum%TYPE,
                             p_others_retaine                  IN  APP.orthodontic_details_tab.others_retaine%TYPE,
                             p_others_ectopic                  IN  APP.orthodontic_details_tab.others_ectopic%TYPE,
                             p_others_cranio                   IN  APP.orthodontic_details_tab.others_cranio%TYPE,
                             p_ac_marks                        IN  APP.orthodontic_details_tab.ac_marks%TYPE,
                             p_crossbite_ant_mm	               IN  APP.orthodontic_details_tab.crossbite_ant_mm%TYPE,
                             p_crossbite_prst_mm	             IN  APP.orthodontic_details_tab.crossbite_prst_mm%TYPE,
	                           p_crossbite_betw_mm	             IN  APP.orthodontic_details_tab.crossbite_betw_mm%TYPE,
                             p_cont_point_disp_mm	             IN  APP.orthodontic_details_tab.cont_point_disp_mm%TYPE
							             )
                           
AS

 V_ORTHO_SEQ_ID                 NUMBER;
 V_COUNT                        NUMBER;  
 V_SQL_CODE                     VARCHAR2(100);
 V_SQL_MSG                      VARCHAR2(4000);
 
 
  CURSOR treatment_cur 
  IS
  SELECT p.treatment_type
  FROM Pat_Authorization_Details p
  WHERE p.pat_auth_seq_id = v_pat_ath_seq_id;   
  
  treatment_rec             treatment_cur%ROWTYPE; 
  
   invalid_data                      EXCEPTION;
   PRAGMA EXCEPTION_INIT(invalid_data,-6502);                     
                           
BEGIN
  
    IF    trim(upper(v_disposition))  = 'A'  THEN 
      
      SELECT NVL(MAX(A.ORTHO_SEQ_ID), 0) INTO V_ORTHO_SEQ_ID
      FROM ORTHODONTIC_DETAILS_TAB A; 
      
       INSERT INTO ORTHODONTIC_DETAILS_TAB(
                        ORTHO_SEQ_ID,
                        SOURCE_SEQ_ID,
                        SOURCE_FROM,
                        DENTO_CLASS_I,
                        DENTO_CLASS_II,
                        DENTO_CLASS_II_TEXT,
                        DENTO_CLASS_III,
                        SKELE_CLASS_I,
                        SKELE_CLASS_II,
                        SKELE_CLASS_III,
                        OVERJET_MM,
                        REV_OVERJET_MM,
                        REV_OVERJET_YN,
                        CROSSBITE_ANT,
                        CROSSBITE_POST,
                        CROSSBITE_BETW,
                        OPENBIT_ANT,
                        OPENBIT_POST,
                        OPENBIT_LATE,
                        CONT_POINT_DISP,
                        OVERBIT_DEEP,
                        OVERBIT_PATA,
                        OVERBIT_GING,
                        HYPO_QUAD1,
                        HYPO_QUAD2,
                        HYPO_QUAD3,
                        HYPO_QUAD4,
                        OTHERS_IMPEDED,
                        OTHERS_IMPACT,
                        OTHERS_SUBMERG,
                        OTHERS_SUPERNUM,
                        OTHERS_RETAINE,
                        OTHERS_ECTOPIC,
                        OTHERS_CRANIO,
                        AC_MARKS,
                        CROSSBITE_ANT_MM,
                        CROSSBITE_PRST_MM,
                        CROSSBITE_BETW_MM,
                        CONT_POINT_DISP_MM,
                        DENTO_CLASS_III_TEXT
                        )
                
                VALUES (V_ORTHO_SEQ_ID + 1,
                        v_pat_ath_seq_id,
                        'PAT',
                        CASE WHEN UPPER(TRIM(P_DENTO_CLASS_I))  ='Y' THEN 'C1' ELSE NULL END,
                        CASE WHEN UPPER(TRIM(P_DENTO_CLASS_II)) ='Y' THEN 'C2' ELSE NULL END,
                        P_DENTO_CLASS_II_TEXT,
                        CASE WHEN UPPER(TRIM(P_DENTO_CLASS_III))='Y' THEN 'C3' ELSE NULL END,
                        CASE WHEN UPPER(TRIM(P_SKELE_CLASS_I))  ='Y' THEN 'S1' ELSE NULL END,
                        CASE WHEN UPPER(TRIM(P_SKELE_CLASS_II)) ='Y' THEN 'S2' ELSE NULL END,
                        CASE WHEN UPPER(TRIM(P_SKELE_CLASS_III))='Y' THEN 'S3' ELSE NULL END,
                        P_OVERJET_MM,
                        P_REV_OVERJET_MM,
                        trim(upper(P_REV_OVERJET_YN)),
                        P_CROSSBITE_ANT,
                        P_CROSSBITE_POST,
                        P_CROSSBITE_BETW,
                        P_OPENBIT_ANT,
                        P_OPENBIT_POST,
                        P_OPENBIT_LATE,
                        P_CONT_POINT_DISP,
                        P_OVERBIT,
                        TRIM(upper(P_OVERBIT_PATA)),
                        TRIM(upper(P_OVERBIT_GING)),
                        P_HYPO_QUAD1,
                        P_HYPO_QUAD2,
                        P_HYPO_QUAD3,
                        P_HYPO_QUAD4,
                        P_OTHERS_IMPEDED,
                        P_OTHERS_IMPACT,
                        P_OTHERS_SUBMERG,
                        P_OTHERS_SUPERNUM,
                        P_OTHERS_RETAINE,
                        P_OTHERS_ECTOPIC,
                        P_OTHERS_CRANIO,
                        TRIM(UPPER(P_AC_MARKS)),
                        P_CROSSBITE_ANT_MM,
                        P_CROSSBITE_PRST_MM,
                        P_CROSSBITE_BETW_MM,
                        P_CONT_POINT_DISP_MM,
                        P_DENTO_CLASS_III_TEXT
                        );     
      
    END IF;    
    
   OPEN treatment_cur;
   FETCH treatment_cur INTO treatment_rec;
   CLOSE treatment_cur;
 
   IF treatment_rec.treatment_type IN (1, 3) THEN
     
     pat_xml_load_pkg.ortho_score_prc (v_pat_ath_seq_id, 'PAT');
     
   END IF; 

------------------*****EXCEPTION BLOCK***----------
                                
EXCEPTION 
  
 WHEN invalid_data THEN
  
     V_SQL_CODE := SQLCODE;
     V_SQL_MSG  := SQLERRM;

       create_exception_log(v_xml_seq_id,V_SQL_CODE,V_SQL_MSG,NULL,1,'SAVE_ORTHO_DETAILS'||'-'||'INVALID DATA');  

 WHEN OTHERS THEN
  
     V_SQL_CODE := SQLCODE;
     V_SQL_MSG  := SQLERRM;

       create_exception_log(v_xml_seq_id,V_SQL_CODE,V_SQL_MSG,V_SQL_MSG,1,'SAVE_ORTHO_DETAILS');  

END SAVE_ORTHO_DETAILS;     

--------********SAVE ICD/DIAGNOSYS DETAILS*********

PROCEDURE SAVE_DIAGNOSYS_DETAILS
 					                          (
                                      V_XML_SEQ_ID             IN  PAT_XML_UPLD_DTA.XML_SEQ_ID%TYPE ,						                   
					                          	v_pat_ath_seq_id         IN  APP.diagnosys_details.pat_auth_seq_id%TYPE,						                          
						                          v_diag_code_prim         IN  APP.diagnosys_details.diagnosys_code%TYPE,
                                      v_priamry_yn             IN  APP.diagnosys_details.Primary_Ailment_Yn%TYPE,					               
						                          v_duration_ailment       IN  APP.pat_authorization_details.dur_ailment%TYPE,
					                            v_duration_flag          IN  APP.pat_authorization_details.duration_flag%TYPE
					                          	)
                                      
AS

  CURSOR icd_seq_id_cur(i_code  diagnosys_details.diagnosys_code%TYPE)
  IS
  SELECT tic.icd10_seq_id as icd_code_seq_id,
         tic.icd_code,
         tic.short_desc as icd_description
  FROM   app.tpa_icd10_master_details tic
  WHERE  tic.icd_code=upper(i_code);
   
  icd_rec                                 icd_seq_id_cur%ROWTYPE;  
  
  CURSOR icd_am_count
  IS
  SELECT COUNT(1)
  FROM APP.TPA_ICD_AM_DETAILS A
  WHERE A.ICD_AM =  TRIM(UPPER(v_diag_code_prim));
  
  v_count                                 NUMBER;   
  
  CURSOR icd_cm_cur
  IS
  SELECT A.ICD_CM
  FROM APP.TPA_ICD_AM_DETAILS A  
  WHERE A.ICD_AM =  TRIM(UPPER(v_diag_code_prim)); 
  
  
  CURSOR icd10_cm_cur
  IS
  SELECT A.ICD_CODE
  FROM APP.tpa_icd10_master_details A  
  WHERE  A.ICD_CODE = TRIM(UPPER(v_diag_code_prim)); 
  
   v_diag_code                   APP.diagnosys_details.diagnosys_code%TYPE; 
   v_sql_code                    VARCHAR2(100);
   v_sql_msg                     VARCHAR2(4000);                           

BEGIN
  
  OPEN   icd_am_count;
  FETCH  icd_am_count  INTO v_count;
  CLOSE  icd_am_count;
  
  IF V_COUNT = 1 THEN 
    
    OPEN  icd_cm_cur;
    FETCH icd_cm_cur  INTO  v_diag_code;
    CLOSE icd_cm_cur;
    
  ELSE 
    
     OPEN  icd10_cm_cur;
     FETCH icd10_cm_cur  INTO v_diag_code;
     CLOSE icd10_cm_cur;
    
  END IF; 
  
  OPEN     icd_seq_id_cur(v_diag_code);
  FETCH    icd_seq_id_cur   INTO icd_rec;
  CLOSE    icd_seq_id_cur;
 
  IF v_priamry_yn  = 'Y' THEN
    
     --- IF v_duration_ailment IS NOT NULL AND v_duration_flag IS NOT NULL THEN
        
          UPDATE pat_authorization_details pad
          SET    pad.dur_ailment   =  NVL(v_duration_ailment,0) ,
                 pad.duration_flag =  NVL(v_duration_flag,'DAYS')     
          WHERE pad.pat_auth_seq_id = v_pat_ath_seq_id;
          
     ----  END IF;
    
   END IF;
   
   
   IF v_pat_ath_seq_id IS NOT NULL THEN  
   
    UPDATE APP.PAT_AUTHORIZATION_DETAILS PA
       SET PA.CAL_ACT_YN = 'N'
    WHERE PA.PAT_AUTH_SEQ_ID = v_pat_ath_seq_id;
    
   END IF;  
  
  
         
  INSERT INTO diagnosys_details(
                                  diag_seq_id,
                                  pat_auth_seq_id,
                                  claim_seq_id,
                                  icd_code_seq_id,
                                  diagnosys_code,
                                  primary_ailment_yn,
                                  added_by,
                                  added_date
                                 )
                         VALUES (
                                   diagnosys_detail_seq.nextval,
                                   v_pat_ath_seq_id,
                                   NULL,
                                   icd_rec.icd_code_seq_id,
                                   UPPER(TRIM(v_diag_code)),
                                   v_priamry_yn,
                                    1,
                                    SYSDATE
                              ) ;
 
------------------*****EXCEPTION BLOCK***----------                             
EXCEPTION
  
WHEN OTHERS THEN
  
     V_SQL_CODE := SQLCODE;
     V_SQL_MSG  := SQLERRM;

       create_exception_log(v_xml_seq_id,V_SQL_CODE,V_SQL_MSG,V_SQL_MSG,1,'SAVE_DIAGNOSYS_DETAILS');                              
  
END   SAVE_DIAGNOSYS_DETAILS;

-----------*******SAVE ACTIVITY DETAILS INFORMATION**********---------------

PROCEDURE  SAVE_ACTIVITY_DETAILS  
                                (
                                V_XML_SEQ_ID              IN  APP.PAT_XML_UPLD_DTA.XML_SEQ_ID%TYPE,                               
                                v_pat_ath_seq_id          IN  APP.pat_activity_details.pat_auth_seq_id%TYPE,  
                                v_activity_type           IN  pat_activity_details.activity_type%TYPE,
                               	v_service_type            IN  pat_activity_details.service_type%TYPE,
            	                  v_start_date              IN  VARCHAR2,
            	                  v_modifier                IN  pat_activity_details.modifier%TYPE,
            	                  v_internal_code           IN  pat_activity_details.internal_code%TYPE,
                                v_unit_type               IN  pat_activity_details.unit_type%TYPE,
	                              v_duration_days           IN  pat_activity_details.posology_duration%TYPE,
                                v_quantity                IN  pat_activity_details.quantity%TYPE,
                              	v_posology                IN  pat_activity_details.posology%TYPE,
                               	v_unit_price              IN  pat_activity_details.unit_price%type,
                                v_discount_amount         IN  pat_activity_details.discount_amount%TYPE,
                                v_allow_yn                IN  pat_activity_details.allow_yn%TYPE,
                                v_benefitType             IN  APP.pat_authorization_details.benifit_type%TYPE,
                                v_clinician_id            IN  APP.pat_authorization_details.clinician_id%TYPE,
                                v_tpa_enroll_id           IN  APP.pat_authorization_details.tpa_enrollment_id%TYPE
                                )
AS

  CURSOR  member_id_cur
  IS
  select member_seq_id
  FROM app.pat_authorization_details a
  where a.pat_auth_seq_id =  v_pat_ath_seq_id;
  
  v_mem_id          member_id_cur%ROWTYPE;

  CURSOR pat_cur(v_member_id   number) 
  IS
  SELECT 
         ip.product_cat_type_id------Eligible Network
  FROM   APP.tpa_enr_policy_member A
  JOIN   APP.tpa_enr_policy_group B ON (A.policy_group_seq_id = B.policy_group_seq_id)
  JOIN   APP.tpa_enr_policy C ON (B.policy_seq_id = C.policy_seq_id )
  JOIN   APP.tpa_ins_product ip ON (ip.product_seq_id=c.product_seq_id)
  WHERE  A.MEMBER_SEQ_ID = v_member_id;
/*SELECT pad.hosp_seq_id,
       tip.product_cat_type_id,
       tep.ins_seq_id,
       tep.group_reg_seq_id,
       pad.pat_auth_seq_id,
       null as claim_type,
       pad.network_yn, 
       pad.policy_seq_id,
       tep.tariff_type_id,
       pad.benifit_type
       
FROM pat_authorization_details pad
JOIN tpa_enr_policy tep ON (pad.policy_seq_id=tep.policy_seq_id)
JOIN tpa_ins_product tip ON (tep.product_seq_id=tip.product_seq_id)
WHERE pad.pat_auth_seq_id=v_pat_ath_seq_id;*/

pat_rec             pat_cur%ROWTYPE;


CURSOR provider_network(v_hosp_seq number,v_product_net_type varchar2) IS
SELECT i.primary_network, ny.network_type, ny.network_yn, gc.sort_no
  FROM tpa_hosp_info i, app.tpa_hosp_network ny, app.tpa_general_code gc
 where ny.hosp_seq_id = i.hosp_seq_id
   and gc.general_type_id = ny.network_type
   and gc.header_type = 'PROVIDER_NETWORK'
   and ny.network_yn = 'Y'
   and i.hosp_seq_id = v_hosp_seq
   and gc.sort_no =
       (SELECT min(gc.sort_no)
          FROM tpa_hosp_info        i,
               app.tpa_hosp_network ny,
               app.tpa_general_code gc
         where ny.hosp_seq_id = i.hosp_seq_id
           and gc.general_type_id = ny.network_type
           and gc.header_type = 'PROVIDER_NETWORK'
           and ny.network_yn = 'Y'
           and i.hosp_seq_id = v_hosp_seq
           and gc.sort_no >=
               (SELECT min(gc.sort_no)
                  FROM tpa_hosp_info        i,
                       app.tpa_hosp_network ny,
                       app.tpa_general_code gc
                 where ny.hosp_seq_id = i.hosp_seq_id
                   and gc.general_type_id = ny.network_type
                   and gc.header_type = 'PROVIDER_NETWORK'
                   and i.hosp_seq_id = v_hosp_seq
                   and gc.general_type_id = v_product_net_type))
 order by gc.sort_no;
 
 provider_rec                        provider_network%rowtype;


  CURSOR act_cur 
  IS
  SELECT max(pad.s_no) max_sno
  FROM pat_activity_details pad
  WHERE pad.pat_auth_seq_id=v_pat_ath_seq_id;
  
  act_rec                            act_cur%ROWTYPE;
  v_s_no                             NUMBER;
  
------********FOR ACTIVITY*****---------

  CURSOR act_code_cur(v_network      varchar2) 
  IS
  SELECT       B.gross_amount ,
               B.disc_amount AS unit_discount ,
               /*NVL(*/B.disc_amount/*,v_discount_amount)*/* NVL(v_quantity,0) AS discount ,
               --- (B.gross_amount * v_quantity)- (/*NVL(*/B.disc_amount/*,v_discount_amount)*/* NVL(v_quantity,0)) as disc_gross_amount,
               (B.gross_amount * v_quantity)- (NVL(B.disc_amount,0)* NVL(v_quantity,0)) as disc_gross_amount,
               B.bundle_id,
               B.package_id,
               B.internal_code,
               M.act_mas_dtl_seq_id as activity_seq_id,
               M.activity_code,
               M.activity_description,
               M.Unit_Price,
               D.activity_type_seq_id,
               D.activity_type_id,
               B.internal_desc,
               X.SORT_NO     -------NEWLY ADDED IN ENHANCEMENT                      
    FROM APP.TPA_HOSP_INFO A JOIN APP.TPA_HOSP_TARIFF_DETAILS B ON(A.HOSP_SEQ_ID = B.HOSP_SEQ_ID)
    JOIN TPA_ACTIVITY_MASTER_DETAILS M ON (B.ACTIVITY_SEQ_ID=M.ACT_MAS_DTL_SEQ_ID)
    JOIN tpa_activity_type_codes D ON (M.activity_type_seq_id=D.activity_type_seq_id)
    JOIN tpa_general_code X ON (X.GENERAL_TYPE_ID = B.NETWORK_TYPE) -------NEWLY ADDED IN ENHANCEMENT
    WHERE  UPPER(A.HOSP_NAME) LIKE '%AL AHLI HOSPITAL%'
    AND  B.SERVICE_SEQ_ID NOT IN (7,14)
    AND UPPER(B.INTERNAL_CODE) = trim(UPPER(v_internal_code))
    AND  UPPER(B.network_type)IN ( select general_type_id
    FROM  (select g.general_type_id, g.sort_no, dense_rank() over(order by g.sort_no) r
      from tpa_general_code g
      where g.header_type = 'PROVIDER_NETWORK'
     ) q
    WHERE  q.r >= (select sort_no from tpa_general_code where general_type_id = v_network))
    AND ((B.END_DATE IS NOT NULL AND TO_DATE(v_start_date, 'DD-MM-RRRR') BETWEEN TRUNC(B.START_DATE) AND TRUNC(B.END_DATE)) OR
        (B.END_DATE IS NULL AND TO_DATE(v_start_date, 'DD-MM-RRRR') >= TRUNC(B.START_DATE) ))
        ORDER BY X.SORT_NO;-------NEWLY ADDED IN ENHANCEMENT
  
  ------********FOR DRG*****---------
        
  CURSOR drg_code_cur(v_network      varchar2) 
  IS     
   SELECT  CASE WHEN upper(trim(NVL(v_unit_type,'NA'))) != 'PCKG' THEN 
             CASE WHEN NVL(B.gross_amount,0 ) != 0 THEN  NVL(B.gross_amount,v_unit_price)
             ELSE  NVL(v_unit_price,0)  END  
         ELSE CASE WHEN NVL(B.PACKAGE_PRICE,0) != 0 THEN   NVL(B.PACKAGE_PRICE,NVL(v_unit_price,0))    
              ELSE NVL(v_unit_price,0) end 
         end AS gross_amount,
          CASE WHEN upper(trim(NVL(v_unit_type,'NA'))) != 'PCKG' THEN
                CASE WHEN NVL(B.gross_amount,0 ) != 0 THEN  nvl(b.gross_amount,v_unit_price)*(nvl(b.disc_percent,0))/100 
                ELSE nvl(v_unit_price,0)*(nvl(b.disc_percent,0))/100 END 
          ELSE CASE WHEN NVL(B.PACKAGE_PRICE,0) != 0  THEN nvl(B.PACKAGE_PRICE,v_unit_price)*(nvl(b.disc_percent,0))/100 
              ELSE nvl(v_unit_price,0)*(nvl(b.disc_percent,0))/100  END 
          END AS unit_discount ,
           CASE WHEN upper(trim(NVL(v_unit_type,'NA'))) != 'PCKG' THEN
              CASE WHEN NVL(B.gross_amount,0 ) != 0 THEN  NVL(((nvl(b.gross_amount,v_unit_price)*(nvl(b.disc_percent,0))/100)*v_quantity),0)  
              ELSE  NVL(((nvl(v_unit_price,0)*(nvl(b.disc_percent,0))/100)*v_quantity),0) END 
           ELSE 
             CASE WHEN NVL(B.PACKAGE_PRICE,0) != 0  THEN  NVL(((nvl(B.PACKAGE_PRICE,v_unit_price)*(nvl(b.disc_percent,0))/100)*v_quantity),0)  
              ELSE  NVL(((nvl(v_unit_price,0)*(nvl(b.disc_percent,0))/100)*v_quantity),0) END 
           END AS discount,
              -- /*NVL(*/B.disc_amount/*,v_discount_amount)*/ AS unit_discount ,			
             ---  /*NVL(*/B.disc_amount/*,v _discount_amount)*/* NVL(v_quantity,0) AS discount ,
            --- (NVL(B.gross_amount,v_unit_price) * v_quantity)- (/*NVL(*/B.disc_amount/*,v_discount_amount)*/* NVL(v_quantity,0)) as disc_gross_amount,
          CASE WHEN upper(trim(NVL(v_unit_type,'NA'))) != 'PCKG' THEN
            CASE WHEN NVL(B.gross_amount,0 ) != 0 THEN 
             (NVL(B.gross_amount,v_unit_price) * v_quantity)- ((nvl(b.gross_amount,v_unit_price)*(nvl(b.disc_percent,0))/100)* NVL(v_quantity,0)) 
            ELSE (NVL(v_unit_price,0) * v_quantity)- ((nvl(v_unit_price,0)*(nvl(b.disc_percent,0))/100)* NVL(v_quantity,0))  END  
          ELSE  
             CASE WHEN NVL(B.PACKAGE_PRICE,0) != 0 THEN 
               (NVL(B.PACKAGE_PRICE,v_unit_price) * v_quantity)- ((nvl(B.PACKAGE_PRICE,v_unit_price)*(nvl(b.disc_percent,0))/100)* NVL(v_quantity,0))  
             ELSE 
              (NVL(v_unit_price,0) * v_quantity)- ((nvl(v_unit_price,0)*(nvl(b.disc_percent,0))/100)* NVL(v_quantity,0)) 
             END 
          END as disc_gross_amount,
               B.bundle_id,
               B.package_id,
               B.internal_code,
               M.act_mas_dtl_seq_id as activity_seq_id,
               M.activity_code,
               M.activity_description,
               M.Unit_Price,
               D.activity_type_seq_id,
               D.activity_type_id,
               B.internal_desc,
               X.SORT_NO -------NEWLY ADDED IN ENHANCEMENT                         
    FROM APP.TPA_HOSP_INFO A JOIN APP.TPA_HOSP_TARIFF_DETAILS B ON(A.HOSP_SEQ_ID = B.HOSP_SEQ_ID)
    JOIN TPA_ACTIVITY_MASTER_DETAILS M ON (B.ACTIVITY_SEQ_ID=M.ACT_MAS_DTL_SEQ_ID)
    JOIN tpa_activity_type_codes D ON (M.activity_type_seq_id=D.activity_type_seq_id)
    JOIN tpa_general_code X ON (X.GENERAL_TYPE_ID = B.NETWORK_TYPE)-------NEWLY ADDED IN ENHANCEMENT
    WHERE  UPPER(A.HOSP_NAME) LIKE '%AL AHLI HOSPITAL%'
  	AND  B.SERVICE_SEQ_ID  IN (7,14)
    AND UPPER(B.INTERNAL_CODE) = trim(UPPER(v_internal_code))
    AND  UPPER(B.network_type)IN ( select general_type_id
    FROM  (select g.general_type_id, g.sort_no, dense_rank() over(order by g.sort_no) r
      from tpa_general_code g
      where g.header_type = 'PROVIDER_NETWORK'
     ) q
    WHERE  q.r >= (select sort_no from tpa_general_code where general_type_id = v_network))
    AND ((B.END_DATE IS NOT NULL AND TO_DATE(v_start_date, 'DD-MM-RRRR') BETWEEN TRUNC(B.START_DATE) AND TRUNC(B.END_DATE)) OR
        (B.END_DATE IS NULL AND TO_DATE(v_start_date, 'DD-MM-RRRR') >= TRUNC(B.START_DATE) ))
         ORDER BY X.SORT_NO;-------NEWLY ADDED IN ENHANCEMENT


        
   act_code                          act_code_cur%ROWTYPE; 
   
   V_SQL_CODE                        VARCHAR2(100);
   V_SQL_MSG                         VARCHAR2(4000);
 
   
   v_date                            DATE;
   v_date_yn                         VARCHAR2(10);
   invalid_date                      EXCEPTION;
   PRAGMA EXCEPTION_INIT(invalid_date,-1843);
       

BEGIN
  
  OPEN member_id_cur;
  FETCH member_id_cur  INTO v_mem_id;
  CLOSE member_id_cur;
  
 OPEN  pat_cur(v_mem_id.member_seq_id);
 FETCH pat_cur INTO pat_rec;
 CLOSE pat_cur;
 
 
 OPEN  act_code_cur(pat_rec.product_cat_type_id);
 FETCH act_code_cur INTO act_code;
 CLOSE act_code_cur;
 
  IF  v_activity_type = 'ACT' THEN 
   
    OPEN  act_code_cur(pat_rec.product_cat_type_id);
    FETCH act_code_cur INTO act_code;
    CLOSE act_code_cur;
 
  ELSE
   
     OPEN  drg_code_cur(pat_rec.product_cat_type_id);
     FETCH drg_code_cur INTO act_code;
     CLOSE drg_code_cur;
 
 
  END IF;
  


IF v_pat_ath_seq_id IS NOT NULL  THEN
 
 UPDATE APP.PAT_AUTHORIZATION_DETAILS PA
       SET PA.CAL_ACT_YN = 'N'
    WHERE PA.PAT_AUTH_SEQ_ID = v_pat_ath_seq_id;

END IF;

 IF  v_pat_ath_seq_id is not null then  -----FOR SERIAL NO
   
     OPEN act_cur;
     FETCH act_cur INTO act_rec;
     CLOSE act_cur;

 END IF;
 
  v_s_no            :=     NVL(act_rec.max_sno,0) + 1  ;
 
 -----****DATE FORMAT****-----
       BEGIN
   
             v_date            :=      TO_DATE(v_start_date, 'DD-MM-RRRR');
   
       EXCEPTION
   
            WHEN OTHERS THEN 
      
             v_date_yn     :=  'N';
             
        END;
  
  ----------------
 
  
 IF  UPPER(TRIM(v_benefitType)) in ('IPT','IMTI')  AND  UPPER(TRIM(v_service_type)) = 'SCD' THEN 
   
     INSERT INTO pat_activity_details(
                                      activity_dtl_seq_id,
                                      pat_auth_seq_id,
                                      claim_seq_id,
                                      Activity_Seq_Id,
                                      activity_id,
                                      s_no,
                                      start_date,
                                      activity_type,
                                      code,
                                      unit_type,
                                      modifier,
                                      internal_code,
                                      package_id,
                                      bundle_id,
                                      quantity,
                                      gross_amount,
                                      discount_amount,
                                      disc_gross_amount,
                                      patient_share_amount,
                                      co_ins_amount,
                                      deduct_amount,
                                      out_of_pocket_amount,
                                      net_amount,
                                      allowed_amount,
                                      approved_amount,
                                      allow_yn,
                                      denial_code,
                                      remarks,
                                      added_by,
                                      added_date,
                                      denial_desc,
                                      approvd_quantity,
                                      unit_price,
                                      clinician_id,
                                      unit_discount_amount,
                                      provider_copay,
                                      override_yn,
                                      override_remarks,
                                      approve_yn,
                                      posology_duration,
                                      posology,
                                      provider_net_amount,
			                                prior_authid,
                                      service_type,
                                      service_code,
                                      service_remarks,
                                      ucr,
                                      ri_copar,
                                      denial_res_dis,
                                      non_network_co_pay,     ----
                                      internal_desc,
                                      converted_acitivty_amt,      ----
                                      tooth_no,
		                                  mem_service_Code,
		                                  mem_service_desc,
		                                  activity_type_id
                                     )
                              VALUES 
                                     (
                                      pat_activity_detail_seq.nextval,
                                      v_pat_ath_seq_id,
                                      NULL,
                                      NULL,----v_Activity_Seq_Id
                                      NULL,----v_activity_id
                                      v_s_no,
                                      CASE WHEN   v_date_yn  =  'N'  THEN NULL ELSE v_date END,
                                      NULL,----v_activity_type
                                      NULL,------v_code
                                      UPPER(TRIM(v_unit_type)),
                                      UPPER(TRIM(v_modifier)),
                                      UPPER(TRIM(v_internal_code)),
                                      NULL, -------v_package_id
                                      NULL,--------v_bundle_id
                                      v_quantity,
                                      v_unit_price * v_quantity,-------
                                      0,----v_discount_amount * v_quantity , -------
                                      (NVL(v_unit_price,0) * NVL(v_quantity,0))- 0/*(NVL(v_discount_amount,0) * NVL(v_quantity,0))*/,--------v_disc_gross_amount
                                      NULL,-----v_patient_share_amount
                                      NULL,-----v_co_ins_amount
                                      NULL,------v_deduct_amount
                                      NULL,------v_out_of_pocket_amount
                                      NVL(v_unit_price,0) * NVL(v_quantity,0),------v_net_amount
                                      NULL,------v_allowed_amount
                                      NULL,-----v_approved_amount
                                      'Y',
                                      NULL,------v_denial_code
                                      NULL,-----v_denial_code
                                      1,
                                      SYSDATE,
                                      null,
                                      v_quantity,
                                      v_unit_price,
                                       UPPER(TRIM(v_clinician_id)),
                                      0,----nvl(v_discount_amount,0),
                                      NULL,------v_copay_amount
                                      'N',-------v_override_yn
                                      NULL,-------v_override_remarks
                                      'Y',-------v_approve_yn
                                      v_duration_days,-------v_duration_days
                                      v_posology,----------v_posology
                                      NULL,-----v_req_amount
				                              NULL,-------------v_prior_authid
                                      UPPER(TRIM(v_service_type)),---------v_service_type
                                      UPPER(TRIM(v_internal_code)),----------v_service_code
                                      NULL, 
                                      NULL,--Changed by priyadarshanv_check_ucr_yn
                                      NULL,
                                      NULL,  -------v_denial_res_dis
                                      NULL,      ----v_non_network_co_pay
                                      NULL,
                                      NVL(v_unit_price,0),      ----v_converted_acitivty_amt
                                      NULL,
		                                  NULL,
		                                  NULL,
		                                  UPPER(TRIM(v_activity_type))
                                     );
   
 ELSE
 
 INSERT INTO pat_activity_details(
                                       activity_dtl_seq_id,
                                       pat_auth_seq_id,
                                       claim_seq_id,
                                       Activity_Seq_Id,
                                       activity_id,
                                       s_no,
                                       start_date,
                                       activity_type,
                                       code,
                                       unit_type,
                                       modifier,
                                       internal_code,
                                       package_id,
                                       bundle_id,
                                       quantity,
                                       gross_amount,
                                       discount_amount,
                                       disc_gross_amount,
                                       patient_share_amount,
                                       co_ins_amount,
                                       deduct_amount,
                                       out_of_pocket_amount,
                                       net_amount,
                                       allowed_amount,
                                       approved_amount,
                                       allow_yn,
                                       denial_code,
                                       remarks,
                                       added_by,
                                       added_date,
                                       denial_desc,
                                       approvd_quantity,
                                       unit_price,
                                       clinician_id,
                                       unit_discount_amount,
                                       provider_copay,
                                       override_yn,
                                       override_remarks,
                                       approve_yn,
                                       posology_duration,
                                       posology,
                                       provider_net_amount,
			                                 prior_authid,
                                       service_type,
                                       service_code,
                                       service_remarks,
                                       ucr,
                                       ri_copar,
                                       denial_res_dis,
                                       non_network_co_pay,     ----
                                       internal_desc,
                                       converted_acitivty_amt,      ----
                                       tooth_no,
		                                   mem_service_Code,
		                                   mem_service_desc,
		                                   activity_type_id
                                     )
                              VALUES
                                     (
                                       pat_activity_detail_seq.nextval,
                                       v_pat_ath_seq_id,
                                       NULL,
                                       ACT_CODE.activity_seq_id ,-------v_Activity_Seq_Id
                                       NULL,----v_activity_id
                                       v_s_no,
                                       v_date,
                                       ACT_CODE.activity_type_id,
                                       UPPER(TRIM(ACT_CODE.activity_code)),-------------------
                                       UPPER(trim(v_unit_type)),
                                       UPPER(TRIM(v_modifier)),
                                       UPPER(TRIM(v_internal_code)),----v_internal_code
                                       ACT_CODE.package_id,---------NULL
                                       ACT_CODE.bundle_id,-------v_bundle_id
                                       v_quantity,------v_quantity
                                       act_code.gross_amount * v_quantity , ---   GROSS_AMOUNT
                                      /* NVL(*/ACT_CODE.discount/*,(v_discount_amount*v_quantity))*/,------ACT_CODE.discount  discount_amount
                                       act_code.disc_gross_amount,---(act_code.disc_gross_amount)  v_disc_gross_amount
                                       NULL,---v_patient_share_amount
                                       NULL,-----v_co_ins_amount
                                       NULL,-----v_deduct_amount
                                       NULL,----v_out_of_pocket_amount
                                       act_code.gross_amount * v_quantity ,-------v_net_amount
                                       NULL,----v_allowed_amount
                                       NULL,------v_approved_amount
                                       'Y',-------Y
                                       NULL,------v_denial_code
                                       NULL,-------v_remarks
                                       1,
                                       SYSDATE,
                                       NULL,
                                       v_quantity,----v_approved_quantity
                                     /*  nvl(*/act_code.gross_amount/*,v_unit_price)*/,-------
                                       UPPER(TRIM(v_clinician_id)),----v_clinician_id
                                       /*NVL(*/ACT_CODE.UNIT_DISCOUNT/*,v_discount_amount)*/,              
                                      NULL,------v_copay_amount
                                       'N',-----v_override_yn
                                       NULL,-----v_override_remarks
                                       'Y',----v_approve_yn
                                       v_duration_days,
                                       v_posology,
                                       NULL,----v_req_amount
				                               NULL,----v_prior_authid
                                      ---- CASE WHEN UPPER(trim(v_benefitType)) IN ('IPT','IMTI') THEN v_service_type ELSE NULL END,
                                       UPPER(TRIM(v_service_type)),
                                       NULL,-----v_service_code
                                       NULL ,
                                       NULL,--Changed by priyadarshanv_check_ucr_yn
                                       NULL,
                                       NULL,-----v_denial_res_dis
                                       NULL,      ----v_non_network_co_pay
                                       act_code.Internal_Desc,-------v_internal_desc
                                      /* nvl(*/act_code.gross_amount/*,v_unit_price)*/,      ----v_converted_acitivty_amt
                                       CASE WHEN UPPER(trim(v_benefitType)) = 'DNTL' THEN NULL ELSE NULL END ,-------v_tooth_no
		                                   NULL,-------v_mem_service_code
		                                   NULL,-------v_mem_service_desc
		                                   UPPER(TRIM(v_activity_type))
                                       );
                                                  


END IF;

------------------*****EXCEPTION BLOCK***----------

EXCEPTION
  
WHEN invalid_date  THEN
  
 V_SQL_CODE := SQLCODE;
 V_SQL_MSG  := SQLERRM;
 
    create_exception_log(v_xml_seq_id,V_SQL_CODE,V_SQL_MSG,'activitystartDate:ACTIVITY START DATE IS INVALID',1,'SAVE_ACTIVITY_DETAILS');
  
WHEN OTHERS THEN
  
     V_SQL_CODE := SQLCODE;
     V_SQL_MSG  := SQLERRM;

       create_exception_log(v_xml_seq_id,V_SQL_CODE,V_SQL_MSG,V_SQL_MSG,1,'SAVE_ACTIVITY_DETAILS');  

END SAVE_ACTIVITY_DETAILS;

----------------------------------

 
PROCEDURE  CHECK_INTERNAL_CODE(   
                                  v_pat_ath_seq_id        IN  APP.pat_authorization_details.pat_auth_seq_id%type,
                                  v_tpa_enroll_id         IN   APP.pat_authorization_details.tpa_enrollment_id%TYPE,
                                  V_XML_SEQ_ID            IN  PAT_XML_UPLD_DTA.XML_SEQ_ID%TYPE ,
                                  v_int_code              IN  pat_activity_details.internal_code%TYPE,
                                  v_start_date            IN  VARCHAR2,
                                  v_yn                    OUT VARCHAR2
                                  )
AS  

  V_COUNT                       NUMBER;
  v_sql_code                    VARCHAR2(100);
  v_sql_msg                     VARCHAR2(4000);
  
  
/* CURSOR pat_cur 
 IS
 SELECT pad.hosp_seq_id,
       tip.product_cat_type_id,
       tep.ins_seq_id,
       tep.group_reg_seq_id,
       pad.pat_auth_seq_id,
       null as claim_type,
       pad.network_yn, 
       pad.policy_seq_id,
       tep.tariff_type_id,
       pad.benifit_type
       
FROM pat_authorization_details pad
JOIN tpa_enr_policy tep ON (pad.policy_seq_id=tep.policy_seq_id)
JOIN tpa_ins_product tip ON (tep.product_seq_id=tip.product_seq_id)
WHERE pad.pat_auth_seq_id=v_pat_ath_seq_id;*/

---pat_rec             pat_cur%ROWTYPE;

CURSOR hosp_id_cur
IS
SELECT A.HOSP_SEQ_ID
FROM APP.TPA_HOSP_INFO A
WHERE UPPER(A.HOSP_NAME) LIKE '%AL AHLI HOSPITAL%';

v_hosp_id          hosp_id_cur%ROWTYPE;


  CURSOR  member_id_cur
  IS
  select member_seq_id
  FROM app.pat_authorization_details a
  where a.pat_auth_seq_id =  v_pat_ath_seq_id;
  
  v_mem_id          member_id_cur%ROWTYPE;

 CURSOR member_detls_cur(v_member_id   number)
   IS
   SELECT 
         ip.product_cat_type_id ------Eligible Network
  FROM   APP.tpa_enr_policy_member A
  JOIN   APP.tpa_enr_policy_group B ON (A.policy_group_seq_id = B.policy_group_seq_id)
  JOIN   APP.tpa_enr_policy C ON (B.policy_seq_id = C.policy_seq_id )
  JOIN   APP.tpa_ins_product ip ON (ip.product_seq_id=c.product_seq_id)
  WHERE  A.MEMBER_SEQ_ID =v_member_id ;                                                                     
                                  
pat_rec             member_detls_cur%ROWTYPE;                                  
  
 CURSOR ENROL_ID_CUR
 IS
  SELECT COUNT(1) 
    FROM  APP.tpa_enr_policy_member A
      JOIN   APP.tpa_enr_policy_group B ON (A.policy_group_seq_id = B.policy_group_seq_id)
      JOIN   APP.tpa_enr_policy C ON (B.policy_seq_id = C.policy_seq_id )
      WHERE A.MEMBER_SEQ_ID = (SELECT MAX(MEMBER_SEQ_ID) FROM APP.TPA_ENR_POLICY_MEMBER 
                              WHERE TPA_ENROLLMENT_ID  = TRIM(v_tpa_enroll_id))
           AND A.DELETED_YN = 'N' AND C.COMPLETED_YN ='Y';
  
   V_COUNT1                             NUMBER;                    

BEGIN
  
  OPEN member_id_cur;
  FETCH member_id_cur  INTO v_mem_id;
  CLOSE member_id_cur;
  

  OPEN  member_detls_cur(v_mem_id.member_seq_id);
  FETCH member_detls_cur INTO pat_rec;
  CLOSE member_detls_cur;



  OPEN   ENROL_ID_CUR;
  FETCH  ENROL_ID_CUR  INTO V_COUNT1;
  CLOSE  ENROL_ID_CUR;
  

--IF   V_COUNT1 = 1 THEN -----FOR VALID ENROLLMENT ID

   -- IF   UPPER(pat_rec.product_cat_type_id) = 'EN' THEN  -----ELITE,PREMIUM,PRIME
   
    SELECT COUNT(1) INTO V_COUNT
       FROM APP.TPA_HOSP_INFO A JOIN APP.TPA_HOSP_TARIFF_DETAILS B ON(A.HOSP_SEQ_ID = B.HOSP_SEQ_ID)
       JOIN TPA_ACTIVITY_MASTER_DETAILS M ON (B.ACTIVITY_SEQ_ID=M.ACT_MAS_DTL_SEQ_ID)
       where UPPER(A.HOSP_NAME) LIKE '%AL AHLI HOSPITAL%'
       AND UPPER(B.INTERNAL_CODE) = trim(UPPER(v_int_code))
       AND  UPPER(B.network_type) IN   (SELECT general_type_id FROM tpa_general_code 
                             WHERE HEADER_TYPE = 'PROVIDER_NETWORK' AND  SORT_NO >= 
                             (SELECT SORT_NO FROM tpa_general_code A  WHERE A.GENERAL_TYPE_ID = UPPER(pat_rec.product_cat_type_id)));
                             
   IF V_COUNT > 0 THEN                          
 
     SELECT COUNT(1) INTO V_COUNT
       FROM APP.TPA_HOSP_INFO A JOIN APP.TPA_HOSP_TARIFF_DETAILS B ON(A.HOSP_SEQ_ID = B.HOSP_SEQ_ID)
       JOIN TPA_ACTIVITY_MASTER_DETAILS M ON (B.ACTIVITY_SEQ_ID=M.ACT_MAS_DTL_SEQ_ID)
       where UPPER(A.HOSP_NAME) LIKE '%AL AHLI HOSPITAL%'
       AND UPPER(B.INTERNAL_CODE) = trim(UPPER(v_int_code))
       AND  UPPER(B.network_type) IN   (SELECT general_type_id FROM tpa_general_code 
                             WHERE HEADER_TYPE = 'PROVIDER_NETWORK' AND  SORT_NO >= 
                             (SELECT SORT_NO FROM tpa_general_code A  WHERE A.GENERAL_TYPE_ID = UPPER(pat_rec.product_cat_type_id)))
       AND ((TO_DATE( B.END_DATE, 'DD-MM-RRRR') IS NOT NULL AND TO_DATE(v_start_date, 'DD-MM-RRRR') BETWEEN 
            TRUNC(TO_DATE( B.START_DATE, 'DD-MM-RRRR')) AND TRUNC(TO_DATE( B.END_DATE, 'DD-MM-RRRR'))) OR
            (TO_DATE( B.END_DATE, 'DD-MM-RRRR') IS NULL AND TO_DATE(v_start_date, 'DD-MM-RRRR') >= TRUNC(TO_DATE( B.start_date, 'DD-MM-RRRR')) ));
     
   
        
         IF  V_COUNT = 0 THEN 
        
             create_exception_log(v_xml_seq_id,NULL,NULL,'internalCode,activitystartDate:GIVEN INTERNAL CODE IS INVALID '||'-'||v_int_code,1,v_int_code);  
        
             v_yn  :=  'N';
     
          END IF; 
        
      ELSE
  
             create_exception_log(v_xml_seq_id,NULL,NULL,'internalCode,alKootID:GIVEN INTERNAL CODE IS INVALID '||'-'||v_int_code,1,v_int_code);  
             v_yn  :=  'N';   
      
      END IF;

EXCEPTION
  
WHEN OTHERS THEN
  
     V_SQL_CODE := SQLCODE;
     V_SQL_MSG  := SQLERRM;

       create_exception_log(v_xml_seq_id,V_SQL_CODE,V_SQL_MSG,'internalCode,activitystartDate,alKootID:GIVEN INTERNAL CODE IS INVALID'||'-'||v_int_code,1,'CHECK_INTERNAL_CODE'||'-'||v_int_code);  
       v_yn  :=  'N'; 

END CHECK_INTERNAL_CODE; 

-----------******DENTAL VALIDATION*****----------------

  PROCEDURE CHECK_DENTAL_VALIDATION
                                   (
                                 V_XML_SEQ_ID              IN  app.PAT_XML_UPLD_DTA.XML_SEQ_ID%TYPE ,
                                 p_dento_class_i           IN  APP.orthodontic_details_tab.dento_class_i%TYPE,
                                 p_dento_class_ii          IN  APP.orthodontic_details_tab.dento_class_ii%TYPE,
                                 p_dento_class_ii_text     IN  APP.orthodontic_details_tab.dento_class_ii_text%TYPE,
                                 p_dento_class_iii         IN  APP.orthodontic_details_tab.dento_class_iii%TYPE,
                                 p_dento_class_iii_text    IN  APP.orthodontic_details_tab.dento_class_iii_text%TYPE,
                                 p_skele_class_i           IN  APP.orthodontic_details_tab.skele_class_i%TYPE,
                                 p_skele_class_ii          IN  APP.orthodontic_details_tab.skele_class_ii%TYPE,
                                 p_skele_class_iii         IN  APP.orthodontic_details_tab.skele_class_iii%TYPE,
                                 p_overjet_mm              IN  APP.orthodontic_details_tab.overjet_mm%TYPE,
                                 p_rev_overjet_mm          IN  APP.orthodontic_details_tab.rev_overjet_mm%TYPE,
                                 p_rev_overjet_yn          IN  APP.orthodontic_details_tab.rev_overjet_yn%TYPE,
                                 p_crossbite_ant           IN  APP.orthodontic_details_tab.crossbite_ant%TYPE,
                                 p_crossbite_post          IN  APP.orthodontic_details_tab.crossbite_post%TYPE,
                                 p_crossbite_betw          IN  APP.orthodontic_details_tab.crossbite_betw%TYPE,
                                 p_openbit_ant             IN  APP.orthodontic_details_tab.openbit_ant%TYPE,
                                 p_openbit_post            IN  APP.orthodontic_details_tab.openbit_post%TYPE,
                                 p_openbit_late            IN  APP.orthodontic_details_tab.openbit_late%TYPE,
                                 p_cont_point_disp         IN  APP.orthodontic_details_tab.cont_point_disp%TYPE,
                                 p_overbit                 IN  APP.orthodontic_details_tab.overbit_deep%TYPE,
                                 p_overbit_pata            IN  APP.orthodontic_details_tab.overbit_pata%TYPE,
                                 p_overbit_ging            IN  APP.orthodontic_details_tab.overbit_ging%TYPE,
                                 p_hypo_quad1              IN  APP.orthodontic_details_tab.hypo_quad1%TYPE,
                                 p_hypo_quad2              IN  APP.orthodontic_details_tab.hypo_quad2%TYPE,
                                 p_hypo_quad3              IN  APP.orthodontic_details_tab.hypo_quad3%TYPE,
                                 p_hypo_quad4              IN  APP.orthodontic_details_tab.hypo_quad4%TYPE,
                                 p_others_impeded          IN  APP.orthodontic_details_tab.others_impeded%TYPE,
                                 p_others_impact           IN  APP.orthodontic_details_tab.others_impact%TYPE,
                                 p_others_submerg          IN  APP.orthodontic_details_tab.others_submerg%TYPE,
                                 p_others_supernum         IN  APP.orthodontic_details_tab.others_supernum%TYPE,
                                 p_others_retaine          IN  APP.orthodontic_details_tab.others_retaine%TYPE,
                                 p_others_ectopic          IN  APP.orthodontic_details_tab.others_ectopic%TYPE,
                                 p_others_cranio           IN  APP.orthodontic_details_tab.others_cranio%TYPE,
                                 p_ac_marks                IN  APP.orthodontic_details_tab.ac_marks%TYPE,
                                 p_crossbite_ant_mm	       IN  APP.orthodontic_details_tab.crossbite_ant_mm%TYPE,
                                 p_crossbite_prst_mm	     IN  APP.orthodontic_details_tab.crossbite_prst_mm%TYPE,
                                 p_crossbite_betw_mm	     IN  APP.orthodontic_details_tab.crossbite_betw_mm%TYPE,
                                 p_cont_point_disp_mm	     IN  APP.orthodontic_details_tab.cont_point_disp_mm%TYPE
                               )                                 
 
 AS
 
   
    
    VAR                                       VARCHAR2(1000);
    VAR2                                      VARCHAR2(1000);
    VAR3                                      VARCHAR2(1000);
    V_COUNT                                   NUMBER;
	  v_sql_code                                VARCHAR2(100);
    v_sql_msg                                 VARCHAR2(4000);


BEGIN 


IF  p_overjet_mm  IS NOT NULL THEN 

   IF  p_rev_overjet_mm  IS NOT NULL  THEN   
   
      create_exception_log(v_xml_seq_id,NULL,NULL,'OVERJET OR REVERSE OVERJET FILED MUST BE BLANK',1,NULL); 

    END IF;
	
	IF p_openbit_ant IS  NULL AND  p_openbit_post IS NULL AND  p_openbit_late IS NULL THEN 
	
	   create_exception_log(v_xml_seq_id,NULL,NULL,'openAnterior,openAnterior,openAnterior:OPENBITE FIELD MANDAOTORY FOR OBVERJET FIELD',1,NULL); 

	 END IF;
	 
END IF;

IF p_rev_overjet_mm IS NOT NULL  THEN 

    IF p_openbit_ant IS NOT  NULL AND  p_openbit_post IS NOT NULL AND  p_openbit_late IS NULL THEN 
	  
	     create_exception_log(v_xml_seq_id,NULL,NULL,'openAnterior,openAnterior,openAnterior:OPENBITE  FIELDS NOT  MANDAOTORY FOR REVERSE OBVERJET FILED',1,NULL);
		 
    END IF;
	
	 --- IF  p_overbit  IS NOT NULL  AND p_overbit_pata  IS NOT NULL  AND p_overbit_ging  IS NOT NULL  THEN  
    IF  UPPER(TRIM(p_overbit)) IN ('D','I','C') THEN 

           create_exception_log(v_xml_seq_id,NULL,NULL,'overbiteValue:OVERBITE FIELDS NOT  MANDAOTORY FOR REVERSE OBVERJET FILED',1,NULL);	
    
	  END IF;

END IF;	


----------***************************
------*********CROSSBITE*********-------------------
-----NOT SAME TOOTH-------------------
IF  p_crossbite_ant IS NOT NULL THEN
   
      VAR    :=   p_crossbite_post||'|'||p_crossbite_betw;  
      
    FOR i IN (Select column_value as val from table(cast(ttk_mail_pkg.parse(p_crossbite_ant,'|') as strings))) LOOP
      IF i.val IS NOT NULL THEN
         IF '%|'||upper(VAR)||'|%' LIKE '%|'||upper(i.val)||'|%' THEN
             V_COUNT := 1;
              EXIT;
          ELSE
             V_COUNT := 0;

          END IF;

       END IF;

    END LOOP;  
    
     IF V_COUNT > 0 THEN

        create_exception_log(v_xml_seq_id,NULL,NULL,'posteriorToothNos,retrudedIntercuspaloothNos:CROSSBITE SHOULD NOT BE SAME TOOTH NUMBER AS OTHER CROSSBITE',1,p_crossbite_ant||'-'||VAR);  
        
     END IF;

 
END IF;

   -----
IF  p_crossbite_post IS NOT NULL THEN
   
      VAR    :=   p_crossbite_betw;  
      
    FOR i IN (Select column_value as val from table(cast(ttk_mail_pkg.parse(p_crossbite_post,'|') as strings))) LOOP
      IF i.val IS NOT NULL THEN
         IF '%|'||upper(VAR)||'|%' LIKE '%|'||upper(i.val)||'|%' THEN
             V_COUNT := 1;
              EXIT;
          ELSE
             V_COUNT := 0;

          END IF;

       END IF;

    END LOOP;  
    
       IF V_COUNT > 0 THEN

         create_exception_log(v_xml_seq_id,NULL,NULL,'retrudedIntercuspaloothNos:CROSSBITE SHOULD NOT BE SAME TOOTH NUMBER AS OTHER CROSSBITE',1,p_crossbite_post||'-'||VAR);  
        
       END IF;

 
END IF; 

---------*******OPEN BITE***********-------------

IF p_openbit_ant  IS NOT NULL OR p_openbit_post IS NOT NULL OR p_openbit_late IS NOT NULL THEN
  
  IF   p_overjet_mm  IS NULL THEN 
   
      create_exception_log(v_xml_seq_id,NULL,NULL,'OBVERJET FIELD MANDAOTORY FOR OPENBITE FIELD',1,p_overjet_mm); 

  END IF;

  IF  p_rev_overjet_mm  IS NOT NULL THEN
    
       create_exception_log(v_xml_seq_id,NULL,NULL,'REVERSE OBVERJET  FIELDS NOT  MANDAOTORY FOR OPENBITE FILED',1,p_rev_overjet_mm);	
       
  END IF;
  
END IF;

----NEED TO CHECK
/*  IF  p_rev_overjet_mm  IS NOT NULL THEN-------p_rev_overjet_yn
    
       create_exception_log(v_xml_seq_id,NULL,NULL,'REVERSE OBVERJET  FIELDS NOT  MANDAOTORY FOR OPENBITE FILED',1,p_rev_overjet_mm);	
       
  END IF;*/

--------------

---------------------
---------*********DISPLACEMENT*************------ 

IF   p_cont_point_disp  IS NOT NULL THEN  
  
   
   VAR2 :=  p_crossbite_ant||'|'||p_crossbite_post||'|'||p_crossbite_betw;
   
    FOR i IN (Select column_value as val from table(cast(ttk_mail_pkg.parse(p_cont_point_disp,'|') as strings))) LOOP
      IF i.val IS NOT NULL THEN
         IF '%|'||upper(VAR2)||'|%' LIKE '%|'||upper(i.val)||'|%' THEN
             V_COUNT := 1;
              EXIT;
          ELSE
             V_COUNT := 0;

          END IF;

       END IF;

    END LOOP; 
   
    IF V_COUNT > 0 THEN
       
          create_exception_log(v_xml_seq_id,NULL,NULL,'pointDisplacementToothNos:DISPLACEMENT SHOULD NOT BE SAME TOOTH NUMBER AS CROSSBITE',1,p_cont_point_disp||'-'||VAR2);  
        
     END IF; 
      
END IF;



----********HYPODONTIA******---------

IF  p_hypo_quad1  IS NOT NULL THEN

   VAR    :=p_hypo_quad2||'|'||p_hypo_quad3||'|'||p_hypo_quad4;
   
   FOR i IN (Select column_value as val from table(cast(ttk_mail_pkg.parse(p_hypo_quad1,'|') as strings))) LOOP
      IF i.val IS NOT NULL THEN
         IF '%|'||upper(VAR)||'|%' LIKE '%|'||upper(i.val)||'|%' THEN
             V_COUNT := 1;
              EXIT;
          ELSE
             V_COUNT := 0;
          END IF;
       END IF;
   END LOOP;
   
    IF V_COUNT > 0 THEN 

     create_exception_log(v_xml_seq_id,NULL,NULL,'Quandrant2Teeth,Quandrant3Teeth,Quandrant4Teeth:OTHER HYPODONTIA  SHOULD NOT BE SAME TOOTH NUMBER AS OTHER HYPODONTIA QUAND I',1,p_hypo_quad1||'-'||VAR);  

     END IF;
   
END IF;

IF  p_hypo_quad2  IS NOT NULL THEN 
  
 VAR    :=   p_hypo_quad3||'|'||p_hypo_quad4; 
 
    FOR i IN (Select column_value as val from table(cast(ttk_mail_pkg.parse(p_hypo_quad2,'|') as strings))) LOOP
      IF i.val IS NOT NULL THEN
         IF '%|'||upper(VAR)||'|%' LIKE '%|'||upper(i.val)||'|%' THEN
             V_COUNT := 1;
              EXIT;
          ELSE
             V_COUNT := 0;
          END IF;
       END IF;
   END LOOP;
   
    IF V_COUNT > 0 THEN     
   
        create_exception_log(v_xml_seq_id,NULL,NULL,'Quandrant3Teeth,Quandrant4Teeth:OTHER HYPODONTIA  SHOULD NOT BE SAME TOOTH NUMBER AS HYPODONTIA QUAND II',1,p_hypo_quad2||'-'||VAR);	
 
    END IF;
 
END IF;

IF  p_hypo_quad3  IS NOT NULL THEN 
  
 VAR    :=   p_hypo_quad4; 

   FOR i IN (Select column_value as val from table(cast(ttk_mail_pkg.parse(p_hypo_quad3,'|') as strings))) LOOP
      IF i.val IS NOT NULL THEN
         IF '%|'||upper(VAR)||'|%' LIKE '%|'||upper(i.val)||'|%' THEN
             V_COUNT := 1;
              EXIT;
          ELSE
             V_COUNT := 0;
          END IF;
       END IF;
   END LOOP;
   
    IF V_COUNT > 0 THEN     
   
        create_exception_log(v_xml_seq_id,NULL,NULL,'Quandrant4Teeth:OTHER HYPODONTIA  SHOULD NOT BE SAME TOOTH NUMBER AS HYPODONTIA QUAND III',1,p_hypo_quad3||'-'||VAR);	

     END IF;
 
END IF;
 

 
 IF  p_hypo_quad1  IS NOT NULL  OR  p_hypo_quad2  IS NOT NULL  OR 
     p_hypo_quad3  IS NOT NULL  OR  p_hypo_quad4  IS NOT NULL    THEN
     
     VAR :=  p_hypo_quad1||'|'||p_hypo_quad2||'|'||p_hypo_quad3||'|'||p_hypo_quad4; 
 ------ 
 IF p_cont_point_disp IS NOT NULL THEN   -------HYPODENTIA CHECKING DISPLACEMENT
      
   FOR i IN (Select column_value as val from table(cast(ttk_mail_pkg.parse(p_cont_point_disp,'|') as strings))) LOOP
      IF i.val IS NOT NULL THEN
         IF '%|'||upper(VAR)||'|%' LIKE '%|'||upper(i.val)||'|%' THEN
             V_COUNT := 1;
              EXIT;
          ELSE
             V_COUNT := 0;

          END IF;

       END IF;

   END LOOP;

   
    IF V_COUNT > 0 THEN     
     
         create_exception_log(v_xml_seq_id,NULL,NULL,'Quandrant1Teeth,Quandrant2Teeth,Quandrant3Teeth,Quandrant4Teeth:HYPODONTIA SHOULD NOT BE SAME TOOTH NUMBER AS DISPLACEMENT ',1,p_cont_point_disp||'-'||VAR);	

    END IF;

    
  END IF;

  ----------- 
   VAR2 :=  p_crossbite_ant||'|'||p_crossbite_post||'|'||p_crossbite_betw;
   
   IF VAR2 IS NOT NULL THEN 
     
    FOR i IN (Select column_value as val from table(cast(ttk_mail_pkg.parse(VAR2,'|') as strings))) LOOP
      IF i.val IS NOT NULL THEN
         IF '%|'||upper(VAR)||'|%' LIKE '%|'||upper(i.val)||'|%' THEN
             V_COUNT := 1;
              EXIT;
          ELSE
             V_COUNT := 0;

          END IF;

       END IF;

     END LOOP;

   
     IF V_COUNT > 0 THEN
     --IF   REGEXP_COUNT(VAR,p_others_impact) > 0 THEN---p_others_impact
       
        create_exception_log(v_xml_seq_id,NULL,NULL,'Quandrant1Teeth,Quandrant2Teeth,Quandrant3Teeth,Quandrant4Teeth:HYPODONTIA SHOULD NOT BE SAME TOOTH NUMBER AS CROSSBITE',1,VAR||'-'||VAR2);	  
        
     END IF;     
   END IF; 
  
 END IF;

------------********OTHERS**********------------------- 
 --------********IMPEDED********----------
 IF  p_others_impeded IS NOT NULL THEN 
   
         VAR :=  p_others_impact||'|'||p_others_submerg||'|'||p_others_ectopic;
         
    FOR i IN (Select column_value as val from table(cast(ttk_mail_pkg.parse(p_others_impeded,'|') as strings))) LOOP
      IF i.val IS NOT NULL THEN
         IF '%|'||upper(VAR)||'|%' LIKE '%|'||upper(i.val)||'|%' THEN
             V_COUNT := 1;
              EXIT;
          ELSE
             V_COUNT := 0;

          END IF;
        END IF;
     END LOOP;
 
     IF V_COUNT > 0 THEN
         
         create_exception_log(v_xml_seq_id,NULL,NULL,'impactedTeeth,submergerdTeeth,ectopicTeeth:OTHRES SHOULD NOT BE SAME TOOTH NUMBER AS IMPEDED',1,p_others_impeded||'-'||VAR);	  
        
     END IF;

 END IF;
 
 ------
  IF  p_others_impeded IS NOT NULL THEN 
   
     ------IMPEDED WITH HYPODONTIA---------     
   VAR := p_hypo_quad1||'|'||p_hypo_quad2||'|'||p_hypo_quad3||'|'||p_hypo_quad4;
           
    FOR i IN (Select column_value as val from table(cast(ttk_mail_pkg.parse(p_others_impeded,'|') as strings))) LOOP
      IF i.val IS NOT NULL THEN
         IF '%|'||upper(VAR)||'|%' LIKE '%|'||upper(i.val)||'|%' THEN
             V_COUNT := 1;
              EXIT;
          ELSE
             V_COUNT := 0;

          END IF;
        END IF;
     END LOOP;
 
     IF V_COUNT > 0 THEN
         
         create_exception_log(v_xml_seq_id,NULL,NULL,'impededTeeth:IMPEDED SHOULD NOT BE SAME TOOTH NUMBER AS HYPODONTIA',1,p_others_impeded||'-'||VAR);	  
        
     END IF;     
     
   -------IMPEDED WITH DISPLACEMENT-------- 
     
     FOR i IN (Select column_value as val from table(cast(ttk_mail_pkg.parse(p_others_impeded,'|') as strings))) LOOP
      IF i.val IS NOT NULL THEN
         IF '%|'||upper(p_cont_point_disp)||'|%' LIKE '%|'||upper(i.val)||'|%' THEN
             V_COUNT := 1;
              EXIT;
          ELSE
             V_COUNT := 0;

          END IF;
        END IF;
     END LOOP;
 
     IF V_COUNT > 0 THEN
         
         create_exception_log(v_xml_seq_id,NULL,NULL,'impededTeeth:IMPEDED SHOULD NOT BE SAME TOOTH NUMBER AS DISPLACEMENT',1,p_others_impeded||'-'||p_cont_point_disp);	  
        
     END IF;       
  
  ------IMPEDED WITH CROSSBITE------  
   VAR2 := p_crossbite_ant||'|'||p_crossbite_post||'|'||p_crossbite_betw;
   
   FOR i IN (Select column_value as val from table(cast(ttk_mail_pkg.parse(p_others_impeded,'|') as strings))) LOOP
      IF i.val IS NOT NULL THEN
         IF '%|'||upper(VAR2)||'|%' LIKE '%|'||upper(i.val)||'|%' THEN
             V_COUNT := 1;
              EXIT;
          ELSE
             V_COUNT := 0;

          END IF;
        END IF;
     END LOOP;
 
     IF V_COUNT > 0 THEN
         
         create_exception_log(v_xml_seq_id,NULL,NULL,'impededTeeth:IMPEDED SHOULD NOT BE SAME TOOTH NUMBER AS CROSSBITE',1,p_others_impeded||'-'||VAR2);	  
        
     END IF;       
  
  END IF;
  
  
  --------********IMPACTED********----------
 IF  p_others_impact IS NOT NULL THEN 
   
         VAR :=  p_others_submerg||'|'||p_others_ectopic;
         
    FOR i IN (Select column_value as val from table(cast(ttk_mail_pkg.parse(p_others_impact,'|') as strings))) LOOP
      IF i.val IS NOT NULL THEN
         IF '%|'||upper(VAR)||'|%' LIKE '%|'||upper(i.val)||'|%' THEN
             V_COUNT := 1;
              EXIT;
          ELSE
             V_COUNT := 0;

          END IF;
        END IF;
     END LOOP;
 
     IF V_COUNT > 0 THEN
         
         create_exception_log(v_xml_seq_id,NULL,NULL,'submergerdTeeth,ectopicTeeth:OTHRES SHOULD NOT BE SAME TOOTH NUMBER AS IMPACTED',1,p_others_impact||'-'||VAR);	  
        
     END IF;

 END IF;
 
 ------
  IF  p_others_impact IS NOT NULL THEN 
   
     ------HYPODONTIA      
   VAR := p_hypo_quad1||'|'||p_hypo_quad2||'|'||p_hypo_quad3||'|'||p_hypo_quad4;
           
    FOR i IN (Select column_value as val from table(cast(ttk_mail_pkg.parse(p_others_impact,'|') as strings))) LOOP
      IF i.val IS NOT NULL THEN
         IF '%|'||upper(VAR)||'|%' LIKE '%|'||upper(i.val)||'|%' THEN
             V_COUNT := 1;
              EXIT;
          ELSE
             V_COUNT := 0;

          END IF;
        END IF;
     END LOOP;
 
     IF V_COUNT > 0 THEN
         
         create_exception_log(v_xml_seq_id,NULL,NULL,'impactedTeeth:IMPACTED SHOULD NOT BE SAME TOOTH NUMBER AS HYPODONTIA',1,p_others_impact||'-'||VAR);	  
        
     END IF;     
     
   -------DISPLACEMENT  
     
     FOR i IN (Select column_value as val from table(cast(ttk_mail_pkg.parse(p_others_impact,'|') as strings))) LOOP
      IF i.val IS NOT NULL THEN
         IF '%|'||upper(p_cont_point_disp)||'|%' LIKE '%|'||upper(i.val)||'|%' THEN
             V_COUNT := 1;
              EXIT;
          ELSE
             V_COUNT := 0;

          END IF;
        END IF;
     END LOOP;
 
     IF V_COUNT > 0 THEN
         
         create_exception_log(v_xml_seq_id,NULL,NULL,'impactedTeeth:IMPACTED SHOULD NOT BE SAME TOOTH NUMBER AS DISPLACEMENT',1,p_others_impact||'-'||p_cont_point_disp);	  
        
     END IF;       
  
  ------*****CROSSBITE******------  
   VAR2 := p_crossbite_ant||'|'||p_crossbite_post||'|'||p_crossbite_betw;
   
   FOR i IN (Select column_value as val from table(cast(ttk_mail_pkg.parse(p_others_impact,'|') as strings))) LOOP
      IF i.val IS NOT NULL THEN
         IF '%|'||upper(VAR2)||'|%' LIKE '%|'||upper(i.val)||'|%' THEN
             V_COUNT := 1;
              EXIT;
          ELSE
             V_COUNT := 0;

          END IF;
        END IF;
     END LOOP;
 
     IF V_COUNT > 0 THEN
         
         create_exception_log(v_xml_seq_id,NULL,NULL,'impactedTeeth:IMPACTED SHOULD NOT BE SAME TOOTH NUMBER AS CROSSBITE',1,p_others_impact||'-'||VAR2);	  
        
     END IF;       
  
  END IF;
  
  
    --------********SUBMERGED********----------
 IF  p_others_submerg IS NOT NULL THEN 
   
         VAR :=  p_others_ectopic;
         
    FOR i IN (Select column_value as val from table(cast(ttk_mail_pkg.parse(p_others_submerg,'|') as strings))) LOOP
      IF i.val IS NOT NULL THEN
         IF '%|'||upper(VAR)||'|%' LIKE '%|'||upper(i.val)||'|%' THEN
             V_COUNT := 1;
              EXIT;
          ELSE
             V_COUNT := 0;

          END IF;
        END IF;
     END LOOP;
 
     IF V_COUNT > 0 THEN
         
         create_exception_log(v_xml_seq_id,NULL,NULL,'ectopicTeeth:OTHRES SHOULD NOT BE SAME TOOTH NUMBER AS SUBMERGED',1,p_others_submerg||'-'||VAR);	  
        
     END IF;

 END IF;
 
 ------
  IF  p_others_submerg IS NOT NULL THEN 
   
     ------HYPODONTIA -------     
   VAR := p_hypo_quad1||'|'||p_hypo_quad2||'|'||p_hypo_quad3||'|'||p_hypo_quad4;
           
    FOR i IN (Select column_value as val from table(cast(ttk_mail_pkg.parse(p_others_submerg,'|') as strings))) LOOP
      IF i.val IS NOT NULL THEN
         IF '%|'||upper(VAR)||'|%' LIKE '%|'||upper(i.val)||'|%' THEN
             V_COUNT := 1;
              EXIT;
          ELSE
             V_COUNT := 0;

          END IF;
        END IF;
     END LOOP;
 
     IF V_COUNT > 0 THEN
         
         create_exception_log(v_xml_seq_id,NULL,NULL,'submergerdTeeth:SUBMERGED SHOULD NOT BE SAME TOOTH NUMBER AS HYPODONTIA',1,p_others_submerg||'-'||VAR);	  
        
     END IF;     
     
   -------DISPLACEMENT--------
     
     FOR i IN (Select column_value as val from table(cast(ttk_mail_pkg.parse(p_others_submerg,'|') as strings))) LOOP
      IF i.val IS NOT NULL THEN
         IF '%|'||upper(p_cont_point_disp)||'|%' LIKE '%|'||upper(i.val)||'|%' THEN
             V_COUNT := 1;
              EXIT;
          ELSE
             V_COUNT := 0;

          END IF;
        END IF;
     END LOOP;
 
     IF V_COUNT > 0 THEN
         
         create_exception_log(v_xml_seq_id,NULL,NULL,'submergerdTeeth:SUBMERGED SHOULD NOT BE SAME TOOTH NUMBER AS DISPLACEMENT',1,p_others_submerg||'-'||p_cont_point_disp);	  
        
     END IF;       
  
  ------CROSSBITE------  
   VAR2 := p_crossbite_ant||'|'||p_crossbite_post||'|'||p_crossbite_betw;
   
   FOR i IN (Select column_value as val from table(cast(ttk_mail_pkg.parse(p_others_submerg,'|') as strings))) LOOP
      IF i.val IS NOT NULL THEN
         IF '%|'||upper(VAR2)||'|%' LIKE '%|'||upper(i.val)||'|%' THEN
             V_COUNT := 1;
              EXIT;
          ELSE
             V_COUNT := 0;

          END IF;
        END IF;
     END LOOP;
 
     IF V_COUNT > 0 THEN
         
         create_exception_log(v_xml_seq_id,NULL,NULL,'submergerdTeeth:SUBMERGED SHOULD NOT BE SAME TOOTH NUMBER AS CROSSBITE',1,p_others_submerg||'-'||VAR2);	  
        
     END IF;       
  
  END IF;
  
  
  -------********ECTOPIC*********-----------
/*
  IF  p_others_ectopic IS NOT NULL THEN 
   
     ------HYPODONTIA -------     
   VAR := p_hypo_quad1||'|'||p_hypo_quad2||'|'||p_hypo_quad3||'|'||p_hypo_quad4;
           
    FOR i IN (Select column_value as val from table(cast(ttk_mail_pkg.parse(p_others_ectopic,'|') as strings))) LOOP
      IF i.val IS NOT NULL THEN
         IF '%|'||upper(VAR)||'|%' LIKE '%|'||upper(i.val)||'|%' THEN
             V_COUNT := 1;
              EXIT;
          ELSE
             V_COUNT := 0;

          END IF;
        END IF;
     END LOOP;
 
     IF V_COUNT > 0 THEN
         
         create_exception_log(v_xml_seq_id,NULL,NULL,'ectopicTeeth:ECTOPIC SHOULD NOT BE SAME TOOTH NUMBER AS HYPODONTIA',1,p_others_ectopic||'-'||VAR);	  
        
     END IF;     
     
   -------DISPLACEMENT--------
     
     FOR i IN (Select column_value as val from table(cast(ttk_mail_pkg.parse(p_others_ectopic,'|') as strings))) LOOP
      IF i.val IS NOT NULL THEN
         IF '%|'||upper(p_cont_point_disp)||'|%' LIKE '%|'||upper(i.val)||'|%' THEN
             V_COUNT := 1;
              EXIT;
          ELSE
             V_COUNT := 0;

          END IF;
        END IF;
     END LOOP;
 
     IF V_COUNT > 0 THEN
         
         create_exception_log(v_xml_seq_id,NULL,NULL,'ectopicTeeth:ECTOPIC SHOULD NOT BE SAME TOOTH NUMBER AS DISPLACEMENT',1,p_others_ectopic||'-'||p_cont_point_disp);	  
        
     END IF;       
  
  ------CROSSBITE------  
   VAR2 := p_crossbite_ant||'|'||p_crossbite_post||'|'||p_crossbite_betw;
   
   FOR i IN (Select column_value as val from table(cast(ttk_mail_pkg.parse(p_others_ectopic,'|') as strings))) LOOP
      IF i.val IS NOT NULL THEN
         IF '%|'||upper(VAR2)||'|%' LIKE '%|'||upper(i.val)||'|%' THEN
             V_COUNT := 1;
              EXIT;
          ELSE
             V_COUNT := 0;

          END IF;
        END IF;
     END LOOP;
 
     IF V_COUNT > 0 THEN
         
         create_exception_log(v_xml_seq_id,NULL,NULL,'ectopicTeeth:ECTOPIC SHOULD NOT BE SAME TOOTH NUMBER AS CROSSBITE',1,p_others_ectopic||'-'||VAR2);	  
        
     END IF;       
  
  END IF;*/
 
 ------*******SUPERNUMARARY******------------
  
  IF  p_others_supernum IS NOT NULL THEN 
    
  -------DISPLACEMENT--------
     
     FOR i IN (Select column_value as val from table(cast(ttk_mail_pkg.parse(p_others_supernum,'|') as strings))) LOOP
      IF i.val IS NOT NULL THEN
         IF '%|'||upper(p_cont_point_disp)||'|%' LIKE '%|'||upper(i.val)||'|%' THEN
             V_COUNT := 1;
              EXIT;
          ELSE
             V_COUNT := 0;

          END IF;
        END IF;
     END LOOP;
 
     IF V_COUNT > 0 THEN
         
         create_exception_log(v_xml_seq_id,NULL,NULL,'supernumararyTeeth:SUPERNUMERARY SHOULD NOT BE SAME TOOTH NUMBER AS DISPLACEMENT',1,p_others_supernum||'-'||p_cont_point_disp);	  
        
     END IF;       
     
  -----****CROSSBITE*****
  
     VAR2 := p_crossbite_ant||'|'||p_crossbite_post||'|'||p_crossbite_betw;
     
     FOR i IN (Select column_value as val from table(cast(ttk_mail_pkg.parse(p_others_supernum,'|') as strings))) LOOP
        IF i.val IS NOT NULL THEN
           IF '%|'||upper(VAR2)||'|%' LIKE '%|'||upper(i.val)||'|%' THEN
              V_COUNT := 1;
                EXIT;
           ELSE
            
             V_COUNT := 0;

          END IF;
        END IF;
     END LOOP;
     
     IF V_COUNT > 0 THEN
         
         create_exception_log(v_xml_seq_id,NULL,NULL,'supernumararyTeeth:SUPERNUMERARY SHOULD NOT BE SAME TOOTH NUMBER AS CROSSBITE',1,p_others_supernum||'-'||VAR2);	  
        
     END IF;  
     
  END IF;
  
 --------OTHERS
EXCEPTION
  
WHEN OTHERS THEN
  
     V_SQL_CODE := SQLCODE;
     V_SQL_MSG  := SQLERRM;

       create_exception_log(v_xml_seq_id,V_SQL_CODE,V_SQL_MSG,V_SQL_MSG,1,'CHECK_DENTAL_VALIDATION');
      
 END  CHECK_DENTAL_VALIDATION;
 
 -----------***DUPLICATE ICD CODE FOR PRE AUTH*********
 
PROCEDURE  CHECK_ICD_CODE_DUP (
                                 V_XML_SEQ_ID              IN  APP.PAT_XML_UPLD_DTA.XML_SEQ_ID%TYPE, 
                                 v_pat_ath_seq_id          IN  APP.pat_authorization_details.pat_auth_seq_id%TYPE,
                                 v_diag_code_scnd          IN  APP.diagnosys_details.diagnosys_code%TYPE
                               )
AS

 CURSOR icd_seq_id_cur(i_code  diagnosys_details.diagnosys_code%TYPE)
  IS
  SELECT tic.icd10_seq_id as icd_code_seq_id,
         tic.icd_code,
         tic.short_desc as icd_description
  FROM   app.tpa_icd10_master_details tic
  WHERE  tic.icd_code=upper(i_code);

   
  icd_rec                                 icd_seq_id_cur%ROWTYPE;  
  
  CURSOR icd_am_count
  IS
  SELECT COUNT(1)
  FROM APP.TPA_ICD_AM_DETAILS A
  WHERE A.ICD_AM =  TRIM(UPPER(v_diag_code_scnd));

  
  v_count                                 NUMBER;   
  
  CURSOR icd_cm_cur
  IS
  SELECT A.ICD_CM
  FROM APP.TPA_ICD_AM_DETAILS A  
  WHERE A.ICD_AM =  TRIM(UPPER(v_diag_code_scnd)); 
  
  
  CURSOR icd10_cm_cur
  IS
  SELECT A.ICD_CODE
  FROM APP.tpa_icd10_master_details A  
  WHERE  A.ICD_CODE = TRIM(UPPER(v_diag_code_scnd)); 
  
   v_diag_code                   APP.diagnosys_details.diagnosys_code%TYPE; 
   v_sql_code                    VARCHAR2(100);
   v_sql_msg                     VARCHAR2(4000);
   v_count1                      NUMBER;   

BEGIN
  
  OPEN   icd_am_count;
  FETCH  icd_am_count  INTO v_count;
  CLOSE  icd_am_count;
  
  IF V_COUNT = 1 THEN 
    
    OPEN  icd_cm_cur;
    FETCH icd_cm_cur  INTO   v_diag_code;
    CLOSE icd_cm_cur;
    
  ELSE 
    
     OPEN  icd10_cm_cur;
     FETCH icd10_cm_cur  INTO v_diag_code;
     CLOSE icd10_cm_cur;
    
  END IF;

  
  SELECT COUNT(1) INTO V_COUNT1
  FROM APP.DIAGNOSYS_DETAILS A
  WHERE A.PAT_AUTH_SEQ_ID = v_pat_ath_seq_id  AND A.DIAGNOSYS_CODE = UPPER(TRIM(v_diag_code));

  
  IF V_COUNT1 > 0 THEN 
   
      create_exception_log(v_xml_seq_id,NULL,NULL,'secondaryICDCode:GIVEN ICD CODE IS ALREADY EXIST',1,v_diag_code_scnd);    
      
  END IF;   

EXCEPTION
  
WHEN OTHERS THEN
  
     V_SQL_CODE := SQLCODE;
     V_SQL_MSG  := SQLERRM;

       create_exception_log(v_xml_seq_id,V_SQL_CODE,V_SQL_MSG,V_SQL_MSG,1,'CHECK_ICD_CODE_DUP'||'-'||v_diag_code_scnd);
	   
END CHECK_ICD_CODE_DUP;     
     
-----*******CHECK DENTAL PRIMARY ICD FOR BENEFIT TYPE  DENTAL**********---------------------

PROCEDURE  CHECK_DNTL_ICD_PRIM(
                               v_xml_seq_id                 IN  PAT_XML_UPLD_DTA.XML_SEQ_ID%TYPE,
                               v_pat_ath_seq_id             IN  APP.diagnosys_details.pat_auth_seq_id%TYPE,	
                               v_diag_code_prim             IN  APP.diagnosys_details.diagnosys_code%TYPE,
                               v_benefitType                IN   APP.pat_authorization_details.benifit_type%TYPE
                               )
AS                               
                               
  CURSOR icd_am_count
  IS
  SELECT COUNT(1)
  FROM APP.TPA_ICD_AM_DETAILS A
  WHERE A.ICD_AM =  TRIM(UPPER(v_diag_code_prim));

  
  v_count                        NUMBER;                                  
                                                               
  CURSOR icd_cm_cur
  IS
  SELECT A.ICD_CM
  FROM APP.TPA_ICD_AM_DETAILS A  
  WHERE A.ICD_AM =  TRIM(UPPER(v_diag_code_prim)); 
  
  
  CURSOR icd10_cm_cur
  IS
  SELECT A.ICD_CODE
  FROM APP.tpa_icd10_master_details A  
  WHERE  A.ICD_CODE = TRIM(UPPER(v_diag_code_prim)); 
  
   v_diag_code                   APP.diagnosys_details.diagnosys_code%TYPE; 
   
   
  CURSOR icd_benefit_cur(v_code varchar2)
  IS
  SELECT ic.benefit_type
  FROM  tpa_icd10_master_details ic
  WHERE  ic.icd_code = upper(v_code); 

   v_icd_benefit                 icd_benefit_cur%ROWTYPE; 
   v_sql_code                    VARCHAR2(100);
   v_sql_msg                     VARCHAR2(4000);                                
                               				    		
BEGIN
  


  OPEN   icd_am_count;
  FETCH  icd_am_count  INTO v_count;
  CLOSE  icd_am_count;
  
  IF V_COUNT = 1 THEN 
    
    OPEN  icd_cm_cur;
    FETCH icd_cm_cur  INTO   v_diag_code;
    CLOSE icd_cm_cur;
    
     OPEN  icd_benefit_cur(v_diag_code);
     FETCH icd_benefit_cur INTO v_icd_benefit;
     CLOSE icd_benefit_cur;
    
  ELSE 
    
     OPEN  icd10_cm_cur;
     FETCH icd10_cm_cur  INTO v_diag_code;
     CLOSE icd10_cm_cur;
     
     OPEN  icd_benefit_cur(v_diag_code);
     FETCH icd_benefit_cur INTO v_icd_benefit;
     CLOSE icd_benefit_cur;
    
  END IF;
  
          IF (v_icd_benefit.benefit_type = 'DNTL' OR UPPER(v_benefitType) = 'DNTL')  THEN
            
               IF NVL(v_icd_benefit.benefit_type, 'NA') != UPPER(v_benefitType) THEN
                   
                     create_exception_log(v_xml_seq_id,NULL,NULL,'PRIMARYICDCode:PRIMARY ICD CODE IS NOT BELONG TO DENTAL',1,v_benefitType||v_diag_code_prim);    
    
               END IF;
               
         END IF; 
  
EXCEPTION
  
WHEN OTHERS THEN
  
     V_SQL_CODE := SQLCODE;
     V_SQL_MSG  := SQLERRM;

       create_exception_log(v_xml_seq_id,V_SQL_CODE,V_SQL_MSG,V_SQL_MSG,1,v_benefitType||'-'||v_diag_code_prim);
	   
END  CHECK_DNTL_ICD_PRIM;   
------**********DENTAL TOOTH NO VALIDATION*****------------

PROCEDURE   CHECK_DNTL_YN(
                             v_xml_seq_id                      IN     PAT_XML_UPLD_DTA.XML_SEQ_ID%TYPE,
                             v_tooth_tag                       IN     VARCHAR2,
                             v_tooth_name                      IN     VARCHAR2,
                             v_tooth_no                        IN     VARCHAR2,
                             v_yn                              OUT    VARCHAR2
                           ) 
                          
                           
AS

  V_COUNT                       NUMBER;
  V_CNT                         NUMBER;
  v_sql_code                    VARCHAR2(100);
  v_sql_msg                     VARCHAR2(4000);  
   
BEGIN
   
  FOR i IN (Select column_value as val from table(cast(ttk_mail_pkg.parse(v_tooth_no,'|') as strings))) LOOP
   
  -- IF I.VAL IS NOT NULL THEN 
     
       SELECT COUNT(1) INTO V_COUNT
       FROM TPA_TOOTH_NUMBER A
       WHERE    TRIM(A.TOOTH_CODE) = TRIM(I.VAL);
       
          IF  V_COUNT = 0 THEN 
           
            create_exception_log(v_xml_seq_id,NULL,NULL, v_tooth_tag||':'||v_tooth_name||' '||'VALUE IS INVALID',1,v_tooth_no||'-'||I.VAL);    
           
            v_yn := 'N';
            
          END IF;           
       
  --  END IF;
       
  END LOOP;
   
   
 EXCEPTION
  
 WHEN OTHERS THEN
  
     V_SQL_CODE := SQLCODE;
     V_SQL_MSG  := SQLERRM;

     create_exception_log(v_xml_seq_id,V_SQL_CODE,V_SQL_MSG,V_SQL_MSG,1,'CHECK_DNTL_YN');
	   
END CHECK_DNTL_YN; 

------**********DENTAL TOOTH NO DUPLICATE*****------------

PROCEDURE  CHECK_TOOTHNO_DUP  (
                              v_xml_seq_id                      IN     PAT_XML_UPLD_DTA.XML_SEQ_ID%TYPE,
                              v_tooth_tag                       IN     VARCHAR2,
                              v_tooth_name                      IN     VARCHAR2,
                              v_tooth_no                        IN     VARCHAR2
                               ) 
AS

  CURSOR tooth_no_cur
  IS
  SELECT tooth,count(1) cnt from (
  SELECT regexp_substr(upper(v_tooth_no),'[^|]+',1,level) tooth
  FROM  DUAL
  CONNECT  BY length(regexp_substr(upper(v_tooth_no),'[^|]+',1,level)) is not null)
  GROUP BY tooth
  HAVING COUNT(1)>1;
  
  tooth_rec                         tooth_no_cur%ROWTYPE;
  
  V_COUNT                       NUMBER;
  V_CNT                         NUMBER;
  v_sql_code                    VARCHAR2(100);
  v_sql_msg                     VARCHAR2(4000);  
                                   
BEGIN
      
    OPEN  tooth_no_cur;
    FETCH tooth_no_cur  INTO  tooth_rec;
    CLOSE tooth_no_cur;
    
    IF tooth_rec.tooth is not null and  tooth_rec.cnt > 1 then 
      
      create_exception_log(v_xml_seq_id,NULL,NULL, v_tooth_tag||':'||v_tooth_name||' '||'TOOTH NO IS DUPLICATE',1,v_tooth_no);
      
    END IF;
    
EXCEPTION
  
 WHEN OTHERS THEN
  
     V_SQL_CODE := SQLCODE;
     V_SQL_MSG  := SQLERRM;

     create_exception_log(v_xml_seq_id,V_SQL_CODE,V_SQL_MSG,V_SQL_MSG,1,'CHECK_TOOTHNO_DUP'||'-'||v_tooth_no);
    
END CHECK_TOOTHNO_DUP; 

----------****************FOR ACTIVITY TYPE INTERNAL CODE VALID OR NOT********------
PROCEDURE  CHK_ACT_INT_CODE_VALID(
                                   v_xml_seq_id                      IN     PAT_XML_UPLD_DTA.XML_SEQ_ID%TYPE,
                                   v_tpa_enroll_id                   IN     APP.pat_authorization_details.tpa_enrollment_id%TYPE,
                                   v_activity_type                   IN     pat_activity_details.activity_type%TYPE,
                                   v_internal_code                   IN     pat_activity_details.internal_code%TYPE,
                                   v_start_date                      IN     VARCHAR2
                                  )
                                  
AS

  CURSOR  member_id_cur
  IS
  select member_seq_id
  FROM app.pat_authorization_details a
  where a.Xml_Seq_Id =  v_xml_seq_id;
  
  v_mem_id          member_id_cur%ROWTYPE;

 CURSOR member_detls_cur(v_member_id     number)
   IS
   SELECT 
         ip.product_cat_type_id ------Eligible Network
  FROM   APP.tpa_enr_policy_member A
  JOIN   APP.tpa_enr_policy_group B ON (A.policy_group_seq_id = B.policy_group_seq_id)
  JOIN   APP.tpa_enr_policy C ON (B.policy_seq_id = C.policy_seq_id )
  JOIN   APP.tpa_ins_product ip ON (ip.product_seq_id=c.product_seq_id)
  WHERE  A.MEMBER_SEQ_ID = v_member_id; 
                                  
  pat_rec                           member_detls_cur%ROWTYPE;                                    
                                  
  V_COUNT                           NUMBER(10);
  v_sql_code                        VARCHAR2(100);
  v_sql_msg                         VARCHAR2(4000);                                  

BEGIN
  
 
  OPEN member_id_cur;
  FETCH member_id_cur  INTO v_mem_id;
  CLOSE member_id_cur;
  
  OPEN  member_detls_cur(v_mem_id.member_seq_id);
  FETCH member_detls_cur INTO pat_rec;
  CLOSE member_detls_cur;
 
IF  v_activity_type IS NOT NULL AND v_internal_code IS NOT NULL AND v_start_date IS NOT NULL THEN 
  
  IF  UPPER(TRIM(v_activity_type))  = 'DRG' THEN
  
  BEGIN
      
   SELECT COUNT(1) INTO V_COUNT
       FROM APP.TPA_HOSP_INFO A JOIN APP.TPA_HOSP_TARIFF_DETAILS B ON(A.HOSP_SEQ_ID = B.HOSP_SEQ_ID)
       JOIN TPA_ACTIVITY_MASTER_DETAILS M ON (B.ACTIVITY_SEQ_ID=M.ACT_MAS_DTL_SEQ_ID)
       WHERE UPPER(A.HOSP_NAME) LIKE '%AL AHLI HOSPITAL%'
       AND  B.SERVICE_SEQ_ID  IN (7,14)
       AND UPPER(B.INTERNAL_CODE) = trim(UPPER(v_internal_code))
       AND  UPPER(B.network_type) IN   (SELECT general_type_id FROM tpa_general_code 
                             WHERE HEADER_TYPE = 'PROVIDER_NETWORK' AND  SORT_NO >= 
                             (SELECT SORT_NO FROM tpa_general_code A  WHERE A.GENERAL_TYPE_ID = UPPER(pat_rec.product_cat_type_id)))
       AND ((TO_DATE( B.END_DATE, 'DD-MM-RRRR') IS NOT NULL AND TO_DATE(v_start_date, 'DD-MM-RRRR') BETWEEN 
            TRUNC(TO_DATE( B.START_DATE, 'DD-MM-RRRR')) AND TRUNC(TO_DATE( B.END_DATE, 'DD-MM-RRRR'))) OR
            (TO_DATE( B.END_DATE, 'DD-MM-RRRR') IS NULL AND TO_DATE(v_start_date, 'DD-MM-RRRR') >= TRUNC(TO_DATE( B.start_date, 'DD-MM-RRRR')) ));
   
   
     IF  V_COUNT = 0 THEN 
       
            create_exception_log(v_xml_seq_id,NULL,NULL,'activityType:FOR  ACTIVITY TYPE '||''''''||'DRG'||''''''||' INTERNAL CODE  '||v_internal_code||' IS INVALID',1,v_activity_type||'-'||v_internal_code);
     
     END IF;
     
    EXCEPTION
   
   WHEN OTHERS THEN    
     
     V_SQL_CODE := SQLCODE;
     V_SQL_MSG  := SQLERRM;      
        
         create_exception_log(v_xml_seq_id,V_SQL_CODE,V_SQL_MSG,'activityType:FOR THIS ACTIVITY TYPE INTERNAL CODE IS INVALID'||'-'||v_internal_code ,1,'exception'||'-'||v_activity_type||'-'||v_internal_code);
         
     END;
     
  END IF;
  
  
  IF  UPPER(TRIM(v_activity_type))  = 'ACT' THEN
   
  BEGIN 
   
   SELECT COUNT(1) INTO V_COUNT
       FROM APP.TPA_HOSP_INFO A JOIN APP.TPA_HOSP_TARIFF_DETAILS B ON(A.HOSP_SEQ_ID = B.HOSP_SEQ_ID)
       JOIN TPA_ACTIVITY_MASTER_DETAILS M ON (B.ACTIVITY_SEQ_ID=M.ACT_MAS_DTL_SEQ_ID)
       WHERE UPPER(A.HOSP_NAME) LIKE '%AL AHLI HOSPITAL%'
       AND  B.SERVICE_SEQ_ID NOT IN (7,14)
       AND UPPER(B.INTERNAL_CODE) = trim(UPPER(v_internal_code))
       AND  UPPER(B.network_type) IN   (SELECT general_type_id FROM tpa_general_code 
                             WHERE HEADER_TYPE = 'PROVIDER_NETWORK' AND  SORT_NO >= 
                             (SELECT SORT_NO FROM tpa_general_code A  WHERE A.GENERAL_TYPE_ID = UPPER(pat_rec.product_cat_type_id)))
       AND ((TO_DATE( B.END_DATE, 'DD-MM-RRRR') IS NOT NULL AND TO_DATE(v_start_date, 'DD-MM-RRRR') BETWEEN 
            TRUNC(TO_DATE( B.START_DATE, 'DD-MM-RRRR')) AND TRUNC(TO_DATE( B.END_DATE, 'DD-MM-RRRR'))) OR
            (TO_DATE( B.END_DATE, 'DD-MM-RRRR') IS NULL AND TO_DATE(v_start_date, 'DD-MM-RRRR') >= TRUNC(TO_DATE( B.start_date, 'DD-MM-RRRR')) ));
   
   
     IF  V_COUNT = 0 THEN 
       
            create_exception_log(v_xml_seq_id,NULL,NULL,'activityType:FOR  ACTIVITY TYPE '||''''''||'ACT'||''''''||' INTERNAL CODE  '||v_internal_code||' IS INVALID' ,1,v_activity_type||'-'||v_internal_code);
     
     END IF;
     
    EXCEPTION 
     
    WHEN OTHERS THEN 
      
     V_SQL_CODE := SQLCODE;
     V_SQL_MSG  := SQLERRM;
       
      create_exception_log(v_xml_seq_id,V_SQL_CODE,V_SQL_MSG,'activityType:FOR THIS ACTIVITY TYPE INTERNAL CODE IS INVALID'||'-'||v_internal_code ,1,'exception'||'-'||v_activity_type||'-'||v_internal_code);
     
    END;
     
  END IF;

END IF;

EXCEPTION
  
 WHEN OTHERS THEN
  
     V_SQL_CODE := SQLCODE;
     V_SQL_MSG  := SQLERRM;

     create_exception_log(v_xml_seq_id,V_SQL_CODE,V_SQL_MSG,'internalCode,activitystartDate,alKootID:GIVEN INTERNAL CODE IS INVALID'||' '||v_internal_code,1,'CHK_ACT_INT_CODE_VALID'||'-'||v_activity_type||'-'||v_internal_code);
    
END CHK_ACT_INT_CODE_VALID;                                   

------********PREAUTH ACTIVITY AND PREAUTH DETAILS RESPONSE*********------
PROCEDURE    SELECT_PAT_AUTH(
                              v_pre_auth_number                  IN    APP.pat_authorization_details.PRE_AUTH_NUMBER%TYPE,
                              v_auth_result_set                  OUT   SYS_REFCURSOR ,
                              v_activity_result_set              OUT   SYS_REFCURSOR ---,
                         ---- v_observ_result_set                OUT   SYS_REFCURSOR ,
                             )
                             
AS

CURSOR pre_auth_id_cur
IS
SELECT A.PAT_AUTH_SEQ_ID
FROM APP.PAT_AUTHORIZATION_DETAILS A
WHERE A.PRE_AUTH_NUMBER = TRIM(v_pre_auth_number)
ORDER BY ADDED_DATE DESC;

rec                              pre_auth_id_cur%ROWTYPE;


BEGIN
  
  OPEN  pre_auth_id_cur;
  FETCH pre_auth_id_cur  INTO rec;
  CLOSE pre_auth_id_cur;
  
  
  OPEN  v_auth_result_set
  FOR 
  SELECT  A.tot_gross_amount,
          A.tot_discount_amount,
          A.tot_disc_gross_amount,
          A.tot_patient_share_amount,
          ----------NEED TO CHECK----------
          CASE WHEN SIGN(nvl(A.tot_disc_gross_amount,0)-nvl(A.tot_patient_share_amount,0)) = -1
             THEN 
               0
               ELSE
                  (nvl(A.tot_disc_gross_amount,0)-nvl(A.tot_patient_share_amount,0))
              END as tot_net_amount,
            CASE  WHEN (A.tot_disc_gross_amount-nvl(A.tot_patient_share_amount,0))-nvl(A.tot_approved_amount,0)>0
               THEN
             (A.tot_disc_gross_amount-nvl(A.tot_patient_share_amount,0))-nvl(A.tot_approved_amount,0)
              ELSE 
                0 
                END  as dis_allowed_amount,  
          -----------------          
          A.tot_allowed_amount,
          A.Final_App_Amount,
        ---  A.converted_final_approved_amt,
        A.pre_auth_number,
          A.CONVERTED_AMOUNT_CURRENCY_TYPE,
          CASE WHEN  A.pat_status_type_id = 'INP' THEN 'IN-PROGRESS'
               WHEN  A.pat_status_type_id = 'APR' THEN 'APPROVED'
               WHEN  A.pat_status_type_id = 'REQ' THEN 'REQUIRED INFORMATION'
               WHEN  A.pat_status_type_id = 'REJ' THEN 'REJECTED'
               WHEN  A.pat_status_type_id = 'PCN' THEN 'CANCELLED' END AS pat_status_type_id,
          A.auth_number,
          A.internal_remarks,
          A.medical_opinion_remarks,
          A.override_remarks
  FROM APP.PAT_AUTHORIZATION_DETAILS A
   WHERE A.pat_auth_seq_id = rec.pat_auth_seq_id;
  
  OPEN  v_activity_result_set
  FOR 
  SELECT ad.activity_dtl_seq_id,
       ad.pat_auth_seq_id,
       ad.activity_id,       
       ad.s_no,
       ad.activity_type,
       nvl(ad.code,ad.internal_code) as code,
       ad.quantity,
       ad.approvd_quantity  as approved_quantity,
       TO_CHAR(ad.start_date,'DD/MM/YYYY') as start_date,
       ad.gross_amount,
       ad.discount_amount,
       ad.disc_gross_amount,
       ad.patient_share_amount,
       CASE WHEN SIGN(ad.disc_gross_amount-ad.patient_share_amount) = -1 THEN 0 
            ELSE (ad.disc_gross_amount-ad.patient_share_amount) END as net_amount,
       case when (nvl(ad.disc_gross_amount,0)-nvl(ad.patient_share_amount,0))-nvl(ad.approved_amount,0)>0
              then (nvl(ad.disc_gross_amount,0)-nvl(patient_share_amount,0))-nvl(ad.approved_amount,0) 
             else 0 end  as dis_allowed_amount,            
       ad.allowed_amount, 
       ----denial_code
       case when ad.denial_code like ';%' then replace(substr(ad.denial_code,2),'-','ALK') else replace(ad.denial_code,'-','ALK-')end as denial_code,
       case when ad.denial_desc like ';%' then substr(ad.denial_desc,2) else ad.denial_desc end as denial_desc,              
       ad.override_yn,
       ad.override_remarks,-------      
       ad.clinician_id,
       ad.allow_yn,
       case when ad.remarks like ';%' then substr(ad.remarks,2) else ad.remarks end as remarks,
       nvl(tamd.activity_description,md.activity_description) as activity_description,
       ad.activity_seq_id,
       account_info_pkg.get_gen_desc(ad.modifier,'G') AS modifier,
       case when ad.unit_type='PCKG' THEN 'Package'
            when ad.unit_type='LOSE' THEN 'Loose' 
            when ad.unit_type='NA' THEN 'NA' else null end as unit_type,              
       
       ad.approved_amount approved_amt,
       ad.out_of_pocket_amount,
       ad.co_ins_amount,
       ad.approvd_quantity  as approved_quantity,
       ad.unit_price,           
       ad.service_type,
       ad.service_code,
       isd.service_descreption as service_description,
       ad.tooth_no,
	     null as new_pharmacy_yn
       
      from pat_activity_details ad
      left outer join tpa_activity_master_details tamd on (ad.code=tamd.activity_code)
      left outer join tpa_pharmacy_master_details md on (ad.code = md.activity_code and ad.start_date between md.start_date and md.end_date)
      left outer join app.tpa_ip_service_details isd on (isd.service_code=ad.service_code)
      where ad.pat_auth_seq_id = rec.pat_auth_seq_id
     order by ad.activity_dtl_seq_id;

END SELECT_PAT_AUTH;                                                                                           
-------=======================================================================
PROCEDURE SAVE_PREAUTH_DOCUMENT (v_pre_Auth_number IN VARCHAR2,
                                 v_doc_val_null    IN VARCHAR2,
                                 v_document        IN BLOB,
                                 v_row_processed   OUT NUMBER)
AS
BEGIN 
  IF v_pre_Auth_number IS NOT NULL AND NVL(v_doc_val_null,'N')='Y' THEN                              
        
     update app.pat_authorization_details p
     set p.alahli_doc = v_document
     where p.pre_auth_number = v_pre_Auth_number and NVL(p.pat_enhanced_yn,'N')='N' ;
   
  v_row_processed := SQL%ROWCOUNT;
  END IF;                              
                                 
END SAVE_PREAUTH_DOCUMENT;
--=============================================================================
 END ALAHLI_PAT_DATA_UPLD_PKG;

/

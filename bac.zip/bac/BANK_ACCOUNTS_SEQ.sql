--------------------------------------------------------
--  DDL for Synonymn BANK_ACCOUNTS_SEQ
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."BANK_ACCOUNTS_SEQ" FOR "APP"."BANK_ACCOUNTS_SEQ";

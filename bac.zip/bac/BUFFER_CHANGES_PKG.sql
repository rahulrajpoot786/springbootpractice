--------------------------------------------------------
--  DDL for Package Body BUFFER_CHANGES_PKG
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "VENUBABU"."BUFFER_CHANGES_PKG" IS
  -- to update the parent claims last_buffer_detail_seq_id to child claim if it is not updated to
  -- child claim. This procedure has to be executed multiple times to make sure all amendments are
  -- updated.
  PROCEDURE update_amd
  IS
    TYPE num_type IS TABLE OF NUMBER INDEX BY BINARY_INTEGER;

    claim_seq_tab        num_type;
    buff_det_seq_tab     num_type;

    CURSOR claim_cur IS
      SELECT b.claim_seq_id, a.last_buffer_detail_seq_id
        FROM clm_general_details a JOIN clm_general_details b ON (a.claim_seq_id = b.parent_claim_seq_id)
        WHERE a.last_buffer_detail_seq_id IS NOT NULL AND b.last_buffer_detail_seq_id IS NULL;

    claim_rec    claim_cur%ROWTYPE;
  BEGIN
    OPEN claim_cur;
    FETCH claim_cur BULK COLLECT INTO claim_seq_tab, buff_det_seq_tab;
    CLOSE claim_cur;

    IF claim_seq_tab.first IS NOT NULL THEN
      FORALL i IN claim_seq_tab.first .. claim_seq_tab.last
        UPDATE clm_general_details a SET
           a.last_buffer_detail_seq_id = buff_det_seq_tab(i)
           WHERE a.claim_seq_id = claim_seq_tab(i) AND a.last_buffer_detail_seq_id IS NULL;
    END IF;
    COMMIT;
  END update_amd;
  --=============================================================================================

 --==========================================================================================================
FUNCTION copay_restrict_check( v_prod_policy_seq_id   IN Tpa_ins_prod_policy.prod_policy_seq_id%TYPE,
                               v_claim_seq_id         IN Pat_general_details.pat_gen_detail_seq_id%TYPE,
                               v_app_amount           IN Tpa_enr_balance.sum_insured%TYPE,
                               v_tot_sum_insured      IN Tpa_enr_balance.sum_insured%TYPE,
                               v_used_sum_insured     IN Tpa_enr_balance.utilised_sum_insured%TYPE,
                               v_rest_sum_insured     IN Tpa_enr_balance.restrict_amt%TYPE,
                               v_used_rel_si          IN Tpa_enr_balance.used_restrict_amt%TYPE,
                               v_max_app_amount       IN Tpa_enr_balance.sum_insured%TYPE,
                               v_pat_buff_amount      IN Buffer_header.pre_auth_buffer_app_amount%TYPE,
                               v_restrict_yn          IN Tpa_ins_prod_policy.si_restrict_yn%TYPE,
                               v_type                 IN varchar2)
    RETURN NUMBER IS

    v_out                 Tpa_enr_balance.sum_insured%TYPE;
    v_si                  Tpa_enr_balance.sum_insured%TYPE:=v_tot_sum_insured;
    v_rel_si              Tpa_enr_balance.sum_insured%TYPE:=v_rest_sum_insured;
    v_copay_si            Tpa_enr_balance.sum_insured%TYPE;
    v_rest_si             Tpa_enr_balance.sum_insured%TYPE;
    v_out_sum             Tpa_enr_balance.sum_insured%TYPE;
    v_rest_value          Tpa_enr_balance.used_restrict_amt%TYPE;



 CURSOR cur_cop_rest(v_prod_policy_seq_id NUMBER) IS
        SELECT ipp.copay_yn,ipp.copay_approved_amt,ipp.copay_fixed_amt,ipp.copay_perc,ipp.copay_level,
               ipp.si_restrict_yn,ipp.si_relation,ipp.si_restrict_amt,ipp.si_restrict_perc,ipp.si_type,
               ipp.si_rest_level
     FROM tpa_ins_prod_policy  ipp
     WHERE ipp.prod_policy_seq_id=v_prod_policy_seq_id;

     cop_rest_cur cur_cop_rest%ROWTYPE;

 BEGIN

    p_copay_si(v_prod_policy_seq_id ,v_restrict_yn ,v_si, v_rel_si);
     v_copay_si := v_si;
     v_rest_si  := v_rel_si;

    IF v_type ='C' THEN
         p_ava_copay(v_claim_seq_id ,v_copay_si, v_rest_si);
    ELSE p_pa_ava_copay(v_claim_seq_id,v_copay_si,v_rest_si);
    END IF;

     v_out_sum     := v_copay_si;
     v_rest_value  := v_rest_si;

    IF nvl(v_restrict_yn,'N')='N' THEN
      IF v_max_app_amount>(v_out_sum+v_pat_buff_amount) THEN
         raise_application_error(-20815,'amount exceeds the family restricted amount');
         ELSIF v_max_app_amount<=(v_out_sum+v_pat_buff_amount) THEN
         v_out:=v_si-v_used_sum_insured;
         ELSIF v_max_app_amount=v_out_sum THEN
         v_out :=v_max_app_amount;
         ELSE v_out :=0;
         END IF;

       ELSE
        IF v_out_sum<v_rest_value
            THEN  v_rest_value:= v_out_sum;
        END IF;

      IF v_max_app_amount>(v_rest_value+v_pat_buff_amount) then
         raise_application_error(-20815,'amount exceeds the family restricted amount');
         ELSIF v_max_app_amount<=(v_rest_value+v_pat_buff_amount) then
         v_out:=(v_rel_si-v_used_rel_si);
         ELSIF v_max_app_amount=v_rest_value then
         v_out :=v_max_app_amount;
         ELSE v_out :=0;
         END IF;
     END IF;
     RETURN v_out;

 END;
--====================================================================================================================
 PROCEDURE p_copay_si (  v_prod_policy_seq_id   IN Tpa_Ins_Prod_Policy.Prod_Policy_Seq_Id%TYPE,
                         v_restrict_yn          IN VARCHAR2,
                         v_tot_sum_insured      IN OUT Tpa_enr_balance.sum_insured%TYPE,
                         v_rest_sum_insured     IN OUT Tpa_enr_balance.Sum_Insured%TYPE) Is

                v_out_sum    Tpa_Enr_Balance.Sum_Insured%TYPE;
                v_out_rsi    Tpa_Enr_Balance.Sum_Insured%TYPE;

   CURSOR cur_cop_rest(v_prod_policy_seq_id NUMBER) IS
          SELECT ipp.copay_yn,ipp.copay_approved_amt,ipp.copay_fixed_amt,ipp.copay_perc,ipp.copay_level,
          ipp.si_restrict_yn,ipp.si_relation,ipp.si_restrict_amt,ipp.si_restrict_perc,ipp.si_type,
          ipp.si_rest_level
     FROM  tpa_ins_prod_policy  ipp
     WHERE ipp.prod_policy_seq_id=v_prod_policy_seq_id;

      cop_rest_cur cur_cop_rest%ROWTYPE;
BEGIN

   OPEN cur_cop_rest(v_prod_policy_seq_id);
   FETCH cur_cop_rest into cop_rest_cur;
   CLOSE cur_cop_rest;


   IF cop_rest_cur.copay_yn='Y' AND nvl(v_restrict_yn,'N')='N' THEN
      IF cop_rest_cur.copay_fixed_amt IS NOT NULL AND cop_rest_cur.copay_perc IS NULL THEN
         v_out_sum :=cop_rest_cur.copay_fixed_amt;
      ELSIF cop_rest_cur.copay_fixed_amt IS NULL AND cop_rest_cur.copay_perc IS NOT NULL THEN
         v_out_sum :=v_tot_sum_insured *(1-nvl(cop_rest_cur.copay_perc,0)/100);
      ELSIF cop_rest_cur.copay_fixed_amt IS NOT NULL AND cop_rest_cur.copay_perc IS NOT NULL AND cop_rest_cur.si_rest_level='LL'  THEN
         v_out_sum := least(cop_rest_cur.si_restrict_amt,v_tot_sum_insured *(1-nvl(cop_rest_cur.copay_perc,0)/100));
      END IF;
    END IF;

  IF cop_rest_cur.copay_yn='Y' AND v_restrict_yn='Y'  THEN
      IF cop_rest_cur.copay_perc IS NULL THEN
         v_out_rsi :=v_rest_sum_insured-cop_rest_cur.copay_fixed_amt;
      ELSIF nvl(cop_rest_cur.si_restrict_amt,0)=0 AND cop_rest_cur.copay_perc IS NOT NULL THEN
         v_out_rsi := (v_rest_sum_insured *(1-nvl(cop_rest_cur.copay_perc,0)/100));
      ELSIF nvl(cop_rest_cur.si_restrict_amt,0)>0 AND cop_rest_cur.copay_perc IS NOT NULL AND cop_rest_cur.si_rest_level='LL' THEN
         v_out_rsi := least(cop_rest_cur.si_restrict_amt,v_rest_sum_insured *(1-nvl(cop_rest_cur.copay_perc,0)/100));
      END IF;
  END IF;

  IF nvl(cop_rest_cur.copay_yn,'N')='N' AND v_restrict_yn='Y' THEN
     IF nvl(cop_rest_cur.si_restrict_amt,0)=0 AND cop_rest_cur.copay_perc IS NOT NULL THEN
         v_out_rsi := (v_rest_sum_insured *(1-nvl(cop_rest_cur.copay_perc,0)/100));
      ELSIF nvl(cop_rest_cur.si_restrict_amt,0)>0 AND cop_rest_cur.copay_perc IS NOT NULL AND cop_rest_cur.si_rest_level='LL' THEN
         v_out_rsi := least(cop_rest_cur.si_restrict_amt,v_rest_sum_insured *(1-nvl(cop_rest_cur.copay_perc,0)/100));
      END IF;
  END IF;

  v_tot_sum_insured  := NVL(v_out_sum,v_tot_sum_insured);
  v_rest_sum_insured := NVL(v_out_rsi,v_rest_sum_insured);

 END ;
--====================================================================================================================
procedure p_ava_copay(  v_claim_seq_id                        IN clm_general_details.claim_seq_id%TYPE/*:=6615052*/,
                        v_sum_insured                         IN OUT tpa_enr_balance.sum_insured%TYPE,
                        v_rest_si                             IN OUT tpa_enr_balance.restrict_amt%TYPE )
   IS

    v_result_set                           SYS_REFCURSOR;
    v_ctr                                  NUMBER(3);
    v_unusable_sum                         NUMBER(12,2):= 0;
    v_unusable_bonus                       NUMBER(12,2):= 0;
    v_appr_amt                             NUMBER(12,2);
    v_max_allowed_amount                   NUMBER(12,2);
    v_appr_count                           NUMBER(2);
    v_ava_si                               tpa_enr_balance.sum_insured%TYPE;
    v_ava_rsi                              tpa_enr_balance.sum_insured%TYPE;


    CURSOR clm_cur IS SELECT a.auth_number,b.tpa_enrollment_id , c.claim_general_type_id , a.completed_yn , b.member_seq_id ,a.date_of_admission,
        a.claim_sub_general_type_id , c.document_general_type_id, a.last_buffer_detail_seq_id,
        d.buffer_alloc_general_type_id, d.enrol_type_id,b.clm_status_general_type_id,a.serv_tax_calc_amount
        FROM clm_general_details a JOIN clm_enroll_details b ON (a.claim_seq_id = b.claim_seq_id)
        JOIN clm_inward c ON (a.claims_inward_seq_id = c.claims_inward_seq_id)
        LEFT OUTER JOIN tpa_enr_policy d ON (b.policy_seq_id = d.policy_seq_id)
        WHERE a.claim_seq_id = v_claim_seq_id ;

    clm_rec   clm_cur%ROWTYPE;

    CURSOR amt_cur IS SELECT SUM(approved_amount) AS appr_amt, SUM(maximum_allowed_amount) AS max_allowed_amount
                           FROM ailment_caps X JOIN icd_pcs_detail Y ON ( X.icd_pcs_seq_id = Y.icd_pcs_seq_id )
                           WHERE y.claim_seq_id = v_claim_seq_id;

   CURSOR prev_appr_cur IS  SELECT COUNT(1) FROM ( SELECT a.claim_seq_id, a.parent_claim_seq_id
      FROM clm_general_details a
      START WITH a.claim_seq_id = v_claim_seq_id CONNECT BY a.claim_seq_id = PRIOR a.parent_claim_seq_id ) aa
      JOIN clm_enroll_details bb ON (aa.claim_seq_id = bb.claim_seq_id )
      WHERE bb.clm_status_general_type_id = 'APR' AND aa.claim_seq_id != v_claim_seq_id ;

  BEGIN
    OPEN clm_cur;
    FETCH clm_cur INTO clm_rec;
    CLOSE clm_cur;

   IF clm_rec.completed_yn = 'N' THEN
      pre_auth_pkg.get_unusable_amounts( trunc(clm_rec.date_of_admission), clm_rec.member_seq_id, v_unusable_sum , v_unusable_bonus );
    END IF;

    SELECT COUNT(1) INTO v_ctr
      FROM discrepancy_information
      WHERE claim_seq_id = v_claim_seq_id AND resolved_yn = 'N';

    OPEN amt_cur;
    FETCH amt_cur INTO v_appr_amt, v_max_allowed_amount;
    CLOSE amt_cur;

    OPEN prev_appr_cur;
    FETCH prev_appr_cur INTO v_appr_count;
    CLOSE prev_appr_cur;

   OPEN v_result_set FOR
      SELECT
         CASE WHEN a.completed_yn = 'Y' THEN v_sum_insured - Q.utilised_sum_insured
              WHEN ( clm_rec.document_general_type_id != 'DTA' OR clm_rec.document_general_type_id  = 'DTA' AND v_appr_count = 0 )
                   AND v_sum_insured >= (v_sum_insured - Q.utilised_sum_insured + NVL( DECODE(a.app_sum_insured,0,NULL,a.app_sum_insured),NVL(i.app_sum_insured,0))) THEN  (v_sum_insured - Q.utilised_sum_insured + NVL( DECODE(a.app_sum_insured,0,NULL,a.app_sum_insured), NVL(i.app_sum_insured,0)))
              WHEN ( clm_rec.document_general_type_id != 'DTA' OR clm_rec.document_general_type_id  = 'DTA' AND v_appr_count = 0 )
              AND v_sum_insured < (v_sum_insured - Q.utilised_sum_insured + NVL( DECODE(a.app_sum_insured,0,NULL,a.app_sum_insured),NVL(i.app_sum_insured,0))) THEN v_sum_insured
              WHEN clm_rec.document_general_type_id  = 'DTA' AND v_sum_insured >= ( v_sum_insured - Q.utilised_sum_insured + NVL(a.app_sum_insured,0)) THEN v_sum_insured - Q.utilised_sum_insured + NVL(a.app_sum_insured,0)
              WHEN clm_rec.document_general_type_id  = 'DTA' AND v_sum_insured < ( v_sum_insured - Q.utilised_sum_insured + NVL(a.app_sum_insured,0)) THEN v_sum_insured
              END - NVL(v_unusable_sum,0) AS ava_sum_insured,

        CASE  WHEN a.completed_yn = 'Y' THEN (v_rest_si - nvl(Q.Used_Restrict_Amt,0))
              WHEN ( clm_rec.document_general_type_id != 'DTA' OR clm_rec.document_general_type_id  = 'DTA' AND v_appr_count = 0 )
              AND v_rest_si >= ((v_rest_si - nvl(Q.Used_Restrict_Amt,0)) + NVL( DECODE(a.app_sum_insured,0,NULL,a.app_sum_insured),NVL(i.app_sum_insured,0))) THEN  ((v_rest_si - nvl(Q.Used_Restrict_Amt,0)) + NVL( DECODE(a.app_sum_insured,0,NULL,a.app_sum_insured), NVL(i.app_sum_insured,0)))
              WHEN ( clm_rec.document_general_type_id != 'DTA' OR clm_rec.document_general_type_id  = 'DTA' AND v_appr_count = 0 )
              AND v_rest_si < ((v_rest_si - nvl(Q.Used_Restrict_Amt,0)) + NVL( DECODE(a.app_sum_insured,0,NULL,a.app_sum_insured),NVL(i.app_sum_insured,0))) THEN v_rest_si
              WHEN clm_rec.document_general_type_id  = 'DTA' AND v_rest_si >= ( (v_rest_si - nvl(Q.Used_Restrict_Amt,0)) + NVL(a.app_sum_insured,0)) THEN (v_rest_si - nvl(Q.Used_Restrict_Amt,0)) + NVL(a.app_sum_insured,0)
              WHEN clm_rec.document_general_type_id  = 'DTA' AND v_rest_si < ( (v_rest_si - nvl(Q.Used_Restrict_Amt,0)) + NVL(a.app_sum_insured,0)) THEN v_rest_si
              END - NVL(v_unusable_sum,0) AS ava_rest_sum_insured --koc1142

        FROM clm_general_details A JOIN clm_enroll_details B ON (A.claim_seq_id = b.claim_seq_id)
        LEFT OUTER JOIN buffer_details D ON ( a.last_buffer_detail_seq_id = d.buff_detail_seq_id )
        LEFT OUTER JOIN buffer_header E ON ( D.buffer_hdr_seq_id = E.buffer_hdr_seq_id )
        LEFT OUTER JOIN tpa_enr_policy_member G ON (b.member_seq_id = g.member_seq_id )
        LEFT OUTER JOIN tpa_enr_policy_group H ON (G.policy_group_seq_id = H.policy_group_seq_id )
        LEFT OUTER JOIN pat_general_details I ON (a.pat_enroll_detail_seq_id = I.pat_enroll_detail_seq_id AND I.pat_enhanced_yn = 'N')
        LEFT OUTER JOIN assign_users L ON (A.last_assign_user_seq_id  = L.assign_users_seq_id )
        LEFT OUTER JOIN tpa_user_contacts M ON (L.assigned_to_user = M.contact_seq_id)
        LEFT OUTER JOIN buffer_details N ON ( I.last_buffer_detail_seq_id = N.buff_detail_seq_id )
        LEFT OUTER JOIN buffer_header O ON ( N.buffer_hdr_seq_id = O.buffer_hdr_seq_id )
        LEFT OUTER JOIN tpa_enr_balance Q ON (G.policy_group_seq_id = Q.policy_group_seq_id)
        LEFT OUTER JOIN clm_hospital_association R ON (A.claim_seq_id = R.claim_seq_id)
        LEFT OUTER JOIN tpa_hosp_info S ON ( R.hosp_seq_id = S.hosp_seq_id )
        WHERE A.claim_seq_id = v_claim_seq_id
                AND ( G.mem_general_type_id = 'PFL' AND Q.member_seq_id IS NULL OR b.member_seq_id = Q.member_seq_id OR b.member_seq_id IS NULL);
        FETCH v_result_set INTO v_ava_si, v_ava_rsi;
        CLOSE v_result_set;
        ---dbms_output.put_line(v_ava_si||'--'||v_ava_rsi);

   v_sum_insured := v_ava_si;
   v_rest_si     := LEAST(v_ava_si,v_ava_rsi);

END;
--====================================================================================================================
  PROCEDURE  p_pa_ava_copay(  v_pat_gen_detail_seq_id       IN pat_general_details.pat_gen_detail_seq_id%TYPE,
                              v_sum_insured                 IN OUT tpa_enr_balance.sum_insured%TYPE,
                              v_rest_si                     IN OUT tpa_enr_balance.restrict_amt%TYPE) IS


    v_ctr                               NUMBER;
    v_member_seq_id                     Tpa_Enr_Policy_Member.Member_Seq_Id%TYPE;

    v_unusable_sum                      NUMBER(12,2):= 0;
    v_unusable_bonus                    NUMBER(12,2):= 0;
    v_completed_yn                      CHAR(1);
    v_date_of_hospitalization           pat_general_details.likely_date_of_hospitalization%TYPE;
    v_result_set                        SYS_REFCURSOR;
    v_ava_si                            Tpa_enr_balance.sum_insured%TYPE;
    v_ava_rsi                           Tpa_enr_balance.sum_insured%TYPE;

   CURSOR pat_cur IS SELECT a.completed_yn , a.likely_date_of_hospitalization,b.member_seq_id
     FROM pat_general_details a JOIN pat_enroll_details b ON (a.pat_enroll_detail_seq_id = b.pat_enroll_detail_seq_id)
     WHERE a.pat_gen_detail_seq_id = v_pat_gen_detail_seq_id;

  BEGIN
    SELECT COUNT(1) INTO v_ctr
      FROM discrepancy_information
      WHERE pat_gen_detail_seq_id = v_pat_gen_detail_seq_id AND resolved_yn = 'N';

    OPEN pat_cur;
    FETCH pat_cur INTO v_completed_yn , v_date_of_hospitalization, v_member_seq_id;
    CLOSE pat_cur;

    IF v_completed_yn = 'N'THEN
      pre_auth_pkg.get_unusable_amounts( trunc(v_date_of_hospitalization), v_member_seq_id, v_unusable_sum , v_unusable_bonus );
    END IF;

    OPEN v_result_set FOR
    SELECT

      CASE WHEN b.member_seq_id IS NULL THEN a.ava_sum_insured
           WHEN a.completed_yn = 'Y' THEN v_sum_insured - i.utilised_sum_insured
           WHEN (v_sum_insured - i.utilised_sum_insured + NVL(A.app_sum_insured,0)) <= v_sum_insured THEN (v_sum_insured - i.utilised_sum_insured + NVL(A.app_sum_insured,0))
           ELSE v_sum_insured
         END - NVL(v_unusable_sum,0) AS ava_sum_insured,

       CASE WHEN b.member_seq_id IS NULL THEN a.ava_sum_insured
            WHEN a.completed_yn='Y' THEN nvl(v_rest_si,0)-nvl(i.used_restrict_amt,0)
            WHEN (nvl(v_rest_si,0)-nvl(i.used_restrict_amt,0)+NVL(A.app_sum_insured,0))<=NVL(v_rest_si,0) THEN
                 (nvl(v_rest_si,0)-nvl(i.used_restrict_amt,0)+NVL(A.app_sum_insured,0))
            ELSE  nvl(v_rest_si,0) END - NVL(v_unusable_sum,0)
           AS ava_rest_sum_insured

      FROM pat_general_details A
      JOIN pat_enroll_details B ON (A.pat_enroll_detail_seq_id = B.pat_enroll_detail_seq_id)
      LEFT OUTER JOIN tpa_enr_policy_member H ON (b.member_seq_id = h.member_seq_id)
      LEFT OUTER JOIN tpa_enr_balance I ON (h.policy_group_seq_id = i.policy_group_seq_id)
      LEFT OUTER JOIN tpa_ins_prod_policy Z ON (Z.Policy_Seq_Id=i.policy_seq_id)
      WHERE A.pat_gen_detail_seq_id = v_pat_gen_detail_seq_id
        AND (h.mem_general_type_id = 'PFL' AND I.member_seq_id IS NULL OR b.member_seq_id = i.member_seq_id OR b.member_seq_id IS NULL );

   FETCH v_result_set INTO v_ava_si, v_ava_rsi;
   CLOSE v_result_set;
   --dbms_output.put_line(v_ava_si||'--'||v_ava_rsi);

   v_sum_insured := v_ava_si;
   v_rest_si     := LEAST(v_ava_si,v_ava_rsi);

 END ;

/* v_dub := buffer_changes_pkg.age_restrict_check(
                        v_prod_policy_seq_id  ,
                        v_pat_gen_detail_seq_id ,
                        nvl(pat_rec.total_app_amount,0) ,
                        v_mem_total_sum_insured ,
                        pat_rec.utilised_sum_insured,
                        pat_rec.restrict_amt,
                        v_config_amt,
                        nvl(v_used_amt,0),
                        v_max_app_amount ,
                        nvl(pat_rec.pre_auth_buffer_app_amount,0),
                        fam_rest_yn ,
                        'P'*/


--=============================================================================================================
FUNCTION age_restrict_check( v_prod_policy_seq_id   IN Tpa_ins_prod_policy.prod_policy_seq_id%TYPE,
                             v_claim_seq_id         IN Pat_general_details.pat_gen_detail_seq_id%TYPE,
                             v_app_amount           IN Tpa_enr_balance.sum_insured%TYPE,
                             v_tot_sum_insured      IN Tpa_enr_balance.sum_insured%TYPE,
                             v_used_sum_insured     IN Tpa_enr_balance.utilised_sum_insured%TYPE,
                             v_rest_sum_insured     IN Tpa_enr_balance.restrict_amt%TYPE,
                             v_used_rest_sum        IN Tpa_enr_balance.used_restrict_amt%TYPE,
                             v_age_sum_insured      IN Tpa_enr_balance.restrict_amt%TYPE,
                             v_used_rel_si          IN Tpa_enr_balance.used_restrict_amt%TYPE,
                             v_max_app_amount       IN Tpa_enr_balance.sum_insured%TYPE,
                             v_pat_buff_amount      IN Buffer_header.pre_auth_buffer_app_amount%TYPE,
                             v_restrict_yn          IN Tpa_ins_prod_policy.si_restrict_yn%TYPE,
                             v_type                 IN varchar2)
    RETURN NUMBER IS

    v_out                 Tpa_enr_balance.sum_insured%TYPE;
    v_si                  Tpa_enr_balance.sum_insured%TYPE:= v_tot_sum_insured;
    v_rel_si              Tpa_enr_balance.sum_insured%TYPE:= v_rest_sum_insured;
    v_agee_si             Tpa_enr_balance.sum_insured%TYPE:= v_age_sum_insured;
    v_copay_si            Tpa_enr_balance.sum_insured%TYPE;
    v_rest_si             Tpa_enr_balance.sum_insured%TYPE;
    v_age_si              Tpa_enr_balance.sum_insured%TYPE;
    v_out_sum             Tpa_enr_balance.sum_insured%TYPE;
    v_rest_value          Tpa_enr_balance.used_restrict_amt%TYPE;
    v_used_si             Tpa_enr_balance.Utilised_Sum_Insured%TYPE:=v_used_rel_si;



 CURSOR cur_cop_rest(v_prod_policy_seq_id NUMBER) IS
        SELECT ipp.copay_yn,ipp.copay_approved_amt,ipp.copay_fixed_amt,ipp.copay_perc,ipp.copay_level,
               ipp.si_restrict_yn,ipp.si_relation,ipp.si_restrict_amt,ipp.si_restrict_perc,ipp.si_type,
               ipp.si_rest_level
     FROM tpa_ins_prod_policy  ipp
     WHERE ipp.prod_policy_seq_id=v_prod_policy_seq_id;

     cop_rest_cur cur_cop_rest%ROWTYPE;

 BEGIN

    age_copay_psi(v_prod_policy_seq_id ,v_restrict_yn ,v_si, v_rel_si,v_agee_si);
         v_copay_si := v_si;
         v_rest_si  := v_rel_si;
         v_age_si   := v_agee_si;


    IF v_type ='C' THEN
         age_ava_copay(v_claim_seq_id ,v_copay_si, v_age_si,v_used_si,v_rest_si );
    ELSE age_pa_ava_copay(v_claim_seq_id,v_copay_si,v_age_si,v_used_si,v_rest_si);
    END IF;

     v_out_sum     := v_copay_si;
     v_rest_value  := v_rest_si;

    IF nvl(v_restrict_yn,'N')='N' THEN
      IF v_max_app_amount>(v_out_sum+v_pat_buff_amount) THEN
         raise_application_error(-20815,'amount exceeds the family restricted amount');
         ELSIF v_max_app_amount<=(v_out_sum+v_pat_buff_amount) THEN
         v_out:=v_si-v_used_sum_insured;
         ELSIF v_max_app_amount=v_out_sum THEN
         v_out :=v_max_app_amount;
         ELSE v_out :=0;
         END IF;

       ELSE
        IF v_out_sum<v_rest_value
            THEN  v_rest_value:= LEAST(v_out_sum,v_rest_value,v_age_si);

        END IF;

      IF v_max_app_amount>(v_rest_value+v_pat_buff_amount) then
         raise_application_error(-20815,'amount exceeds the family restricted amount');
         ELSIF v_max_app_amount<=(v_rest_value+v_pat_buff_amount) then
         v_out:=least((v_rel_si-v_used_rest_sum),v_agee_si-v_used_rel_si);
         ELSIF v_max_app_amount=v_rest_value then
         v_out :=v_max_app_amount;
         ELSE v_out :=0;
         END IF;
     END IF;
     RETURN v_out;

 END;
--====================================================================================================================
 PROCEDURE age_copay_psi (  v_prod_policy_seq_id   IN Tpa_Ins_Prod_Policy.Prod_Policy_Seq_Id%TYPE,
                            v_restrict_yn          IN VARCHAR2,
                            v_tot_sum_insured      IN OUT Tpa_enr_balance.sum_insured%TYPE,
                            v_rest_sum_insured     IN OUT Tpa_enr_balance.Sum_Insured%TYPE,
                            v_rel_sum_insured      IN OUT Tpa_enr_balance.restrict_amt%TYPE) Is

                v_out_sum    Tpa_Enr_Balance.Sum_Insured%TYPE;
                v_out_rsi    Tpa_Enr_Balance.Sum_Insured%TYPE;
                v_out_rel    Tpa_Enr_Balance.Sum_Insured%TYPE;

   CURSOR cur_cop_rest(v_prod_policy_seq_id NUMBER) IS
          SELECT ipp.copay_yn,ipp.copay_approved_amt,ipp.copay_fixed_amt,ipp.copay_perc,ipp.copay_level,
          ipp.si_restrict_yn,ipp.si_relation,/*ipp.si_restrict_amt,*//*ipp.si_restrict_perc,ipp.si_type,
          ipp.si_rest_level,*/ipp.rest_age,ipp.rest_age_amt
     FROM  tpa_ins_prod_policy  ipp
     WHERE ipp.prod_policy_seq_id=v_prod_policy_seq_id;

      cop_rest_cur cur_cop_rest%ROWTYPE;
BEGIN

   OPEN cur_cop_rest(v_prod_policy_seq_id);
   FETCH cur_cop_rest into cop_rest_cur;
   CLOSE cur_cop_rest;


   IF cop_rest_cur.copay_yn='Y'  THEN
      IF cop_rest_cur.copay_fixed_amt IS NOT NULL AND cop_rest_cur.copay_perc IS NULL THEN
         v_out_sum :=cop_rest_cur.copay_fixed_amt;
         v_out_rsi := cop_rest_cur.copay_fixed_amt;
      ELSIF cop_rest_cur.copay_fixed_amt IS NULL AND cop_rest_cur.copay_perc IS NOT NULL THEN
         v_out_sum := v_tot_sum_insured *(1-nvl(cop_rest_cur.copay_perc,0)/100);
         v_out_rsi := v_rest_sum_insured*(1-nvl(cop_rest_cur.copay_perc,0)/100);
         v_out_rel := v_rel_sum_insured*(1-nvl(cop_rest_cur.copay_perc,0)/100);
      ELSIF cop_rest_cur.copay_fixed_amt IS NOT NULL AND cop_rest_cur.copay_perc IS NOT NULL AND cop_rest_cur.copay_level='LL'  THEN
         v_out_sum := v_tot_sum_insured *(1-nvl(cop_rest_cur.copay_perc,0)/100);
         v_out_rsi := least(cop_rest_cur.copay_fixed_amt,v_rest_sum_insured *(1-nvl(cop_rest_cur.copay_perc,0)/100));
         v_out_rel := v_rel_sum_insured *(1-nvl(cop_rest_cur.copay_perc,0)/100);
      END IF;
    END IF;

  v_tot_sum_insured  := NVL(v_out_sum,v_tot_sum_insured);
  v_rest_sum_insured := NVL(v_out_rsi,v_rest_sum_insured);
  v_rel_sum_insured  := NVL(v_out_rel,v_rel_sum_insured);
 END ;
--====================================================================================================================
 PROCEDURE age_ava_copay( v_claim_seq_id                        IN clm_general_details.claim_seq_id%TYPE,
                          v_sum_insured                         IN OUT tpa_enr_balance.sum_insured%TYPE,
                          v_age_si                              IN OUT tpa_enr_balance.restrict_amt%TYPE,
                          v_used_si                             IN OUT tpa_enr_balance.utilised_sum_insured%TYPE,
                          v_rest_si                             IN OUT tpa_enr_balance.restrict_amt%TYPE )
   IS

    v_result_set                           SYS_REFCURSOR;
    v_ctr                                  NUMBER(3);
    v_unusable_sum                         NUMBER(12,2):= 0;
    v_unusable_bonus                       NUMBER(12,2):= 0;
    v_appr_amt                             NUMBER(12,2);
    v_max_allowed_amount                   NUMBER(12,2);
    v_appr_count                           NUMBER(2);
    v_ava_si                               tpa_enr_balance.sum_insured%TYPE;
    v_ava_rsi                              tpa_enr_balance.sum_insured%TYPE;
    v_age_rsi                              tpa_enr_balance.sum_insured%TYPE;


    CURSOR clm_cur IS SELECT a.auth_number,b.tpa_enrollment_id , c.claim_general_type_id , a.completed_yn , b.member_seq_id ,a.date_of_admission,
        a.claim_sub_general_type_id , c.document_general_type_id, a.last_buffer_detail_seq_id,
        d.buffer_alloc_general_type_id, d.enrol_type_id,b.clm_status_general_type_id,a.serv_tax_calc_amount
        FROM clm_general_details a JOIN clm_enroll_details b ON (a.claim_seq_id = b.claim_seq_id)
        JOIN clm_inward c ON (a.claims_inward_seq_id = c.claims_inward_seq_id)
        LEFT OUTER JOIN tpa_enr_policy d ON (b.policy_seq_id = d.policy_seq_id)
        WHERE a.claim_seq_id = v_claim_seq_id ;

    clm_rec   clm_cur%ROWTYPE;

    CURSOR amt_cur IS SELECT SUM(approved_amount) AS appr_amt, SUM(maximum_allowed_amount) AS max_allowed_amount
                           FROM ailment_caps X JOIN icd_pcs_detail Y ON ( X.icd_pcs_seq_id = Y.icd_pcs_seq_id )
                           WHERE y.claim_seq_id = v_claim_seq_id;

   CURSOR prev_appr_cur IS  SELECT COUNT(1) FROM ( SELECT a.claim_seq_id, a.parent_claim_seq_id
      FROM clm_general_details a
      START WITH a.claim_seq_id = v_claim_seq_id CONNECT BY a.claim_seq_id = PRIOR a.parent_claim_seq_id ) aa
      JOIN clm_enroll_details bb ON (aa.claim_seq_id = bb.claim_seq_id )
      WHERE bb.clm_status_general_type_id = 'APR' AND aa.claim_seq_id != v_claim_seq_id ;

  BEGIN
    OPEN clm_cur;
    FETCH clm_cur INTO clm_rec;
    CLOSE clm_cur;

   IF clm_rec.completed_yn = 'N' THEN
      pre_auth_pkg.get_unusable_amounts( trunc(clm_rec.date_of_admission), clm_rec.member_seq_id, v_unusable_sum , v_unusable_bonus );
    END IF;

    SELECT COUNT(1) INTO v_ctr
      FROM discrepancy_information
      WHERE claim_seq_id = v_claim_seq_id AND resolved_yn = 'N';

    OPEN amt_cur;
    FETCH amt_cur INTO v_appr_amt, v_max_allowed_amount;
    CLOSE amt_cur;

    OPEN prev_appr_cur;
    FETCH prev_appr_cur INTO v_appr_count;
    CLOSE prev_appr_cur;

   OPEN v_result_set FOR
      SELECT
         CASE WHEN a.completed_yn = 'Y' THEN v_sum_insured - Q.utilised_sum_insured
              WHEN ( clm_rec.document_general_type_id != 'DTA' OR clm_rec.document_general_type_id  = 'DTA' AND v_appr_count = 0 )
                   AND v_sum_insured >= (v_sum_insured - Q.utilised_sum_insured + NVL( DECODE(a.app_sum_insured,0,NULL,a.app_sum_insured),NVL(i.app_sum_insured,0))) THEN  (v_sum_insured - Q.utilised_sum_insured + NVL( DECODE(a.app_sum_insured,0,NULL,a.app_sum_insured), NVL(i.app_sum_insured,0)))
              WHEN ( clm_rec.document_general_type_id != 'DTA' OR clm_rec.document_general_type_id  = 'DTA' AND v_appr_count = 0 )
              AND v_sum_insured < (v_sum_insured - Q.utilised_sum_insured + NVL( DECODE(a.app_sum_insured,0,NULL,a.app_sum_insured),NVL(i.app_sum_insured,0))) THEN v_sum_insured
              WHEN clm_rec.document_general_type_id  = 'DTA' AND v_sum_insured >= ( v_sum_insured - Q.utilised_sum_insured + NVL(a.app_sum_insured,0)) THEN v_sum_insured - Q.utilised_sum_insured + NVL(a.app_sum_insured,0)
              WHEN clm_rec.document_general_type_id  = 'DTA' AND v_sum_insured < ( v_sum_insured - Q.utilised_sum_insured + NVL(a.app_sum_insured,0)) THEN v_sum_insured
              END - NVL(v_unusable_sum,0) AS ava_sum_insured,

        CASE  WHEN a.completed_yn = 'Y' THEN (v_age_si - nvl(v_used_si,0))
              WHEN ( clm_rec.document_general_type_id != 'DTA' OR clm_rec.document_general_type_id  = 'DTA' AND v_appr_count = 0 )
              AND v_age_si >= ((v_age_si - nvl(v_used_si,0)) + NVL( DECODE(a.app_sum_insured,0,NULL,a.app_sum_insured),NVL(i.app_sum_insured,0))) THEN  ((v_age_si - nvl(v_used_si,0)) + NVL( DECODE(a.app_sum_insured,0,NULL,a.app_sum_insured), NVL(i.app_sum_insured,0)))
              WHEN ( clm_rec.document_general_type_id != 'DTA' OR clm_rec.document_general_type_id  = 'DTA' AND v_appr_count = 0 )
              AND v_age_si < ((v_age_si - nvl(v_used_si,0)) + NVL( DECODE(a.app_sum_insured,0,NULL,a.app_sum_insured),NVL(i.app_sum_insured,0))) THEN v_age_si
              WHEN clm_rec.document_general_type_id  = 'DTA' AND v_age_si >= ( (v_age_si - nvl(v_used_si,0)) + NVL(a.app_sum_insured,0)) THEN (v_age_si - nvl(v_used_si,0)) + NVL(a.app_sum_insured,0)
              WHEN clm_rec.document_general_type_id  = 'DTA' AND v_age_si < ( (v_age_si - nvl(v_used_si,0)) + NVL(a.app_sum_insured,0)) THEN v_age_si
              END - NVL(v_unusable_sum,0) AS ava_rest_sum_insured, --koc1142

       CASE  WHEN a.completed_yn = 'Y' THEN (v_rest_si - nvl(q.used_restrict_amt,0))
              WHEN ( clm_rec.document_general_type_id != 'DTA' OR clm_rec.document_general_type_id  = 'DTA' AND v_appr_count = 0 )
              AND v_rest_si >= ((v_rest_si - nvl(q.used_restrict_amt,0)) + NVL( DECODE(a.app_sum_insured,0,NULL,a.app_sum_insured),NVL(i.app_sum_insured,0))) THEN  ((v_rest_si - nvl(q.used_restrict_amt,0)) + NVL( DECODE(a.app_sum_insured,0,NULL,a.app_sum_insured), NVL(i.app_sum_insured,0)))
              WHEN ( clm_rec.document_general_type_id != 'DTA' OR clm_rec.document_general_type_id  = 'DTA' AND v_appr_count = 0 )
              AND v_rest_si < ((v_rest_si - nvl(q.used_restrict_amt,0)) + NVL( DECODE(a.app_sum_insured,0,NULL,a.app_sum_insured),NVL(i.app_sum_insured,0))) THEN v_rest_si
              WHEN clm_rec.document_general_type_id  = 'DTA' AND v_rest_si >= ( (v_rest_si - nvl(q.used_restrict_amt,0)) + NVL(a.app_sum_insured,0)) THEN (v_rest_si - nvl(q.used_restrict_amt,0)) + NVL(a.app_sum_insured,0)
              WHEN clm_rec.document_general_type_id  = 'DTA' AND v_rest_si < ( (v_rest_si - nvl(q.used_restrict_amt,0)) + NVL(a.app_sum_insured,0)) THEN v_rest_si
              END - NVL(v_unusable_sum,0) AS ava_rest_sum_insured --koc1142


        FROM clm_general_details A JOIN clm_enroll_details B ON (A.claim_seq_id = b.claim_seq_id)
        LEFT OUTER JOIN buffer_details D ON ( a.last_buffer_detail_seq_id = d.buff_detail_seq_id )
        LEFT OUTER JOIN buffer_header E ON ( D.buffer_hdr_seq_id = E.buffer_hdr_seq_id )
        LEFT OUTER JOIN tpa_enr_policy_member G ON (b.member_seq_id = g.member_seq_id )
        LEFT OUTER JOIN tpa_enr_policy_group H ON (G.policy_group_seq_id = H.policy_group_seq_id )
        LEFT OUTER JOIN pat_general_details I ON (a.pat_enroll_detail_seq_id = I.pat_enroll_detail_seq_id AND I.pat_enhanced_yn = 'N')
        LEFT OUTER JOIN assign_users L ON (A.last_assign_user_seq_id  = L.assign_users_seq_id )
        LEFT OUTER JOIN tpa_user_contacts M ON (L.assigned_to_user = M.contact_seq_id)
        LEFT OUTER JOIN buffer_details N ON ( I.last_buffer_detail_seq_id = N.buff_detail_seq_id )
        LEFT OUTER JOIN buffer_header O ON ( N.buffer_hdr_seq_id = O.buffer_hdr_seq_id )
        LEFT OUTER JOIN tpa_enr_balance Q ON (G.policy_group_seq_id = Q.policy_group_seq_id)
        LEFT OUTER JOIN clm_hospital_association R ON (A.claim_seq_id = R.claim_seq_id)
        LEFT OUTER JOIN tpa_hosp_info S ON ( R.hosp_seq_id = S.hosp_seq_id )
        WHERE A.claim_seq_id = v_claim_seq_id
                AND ( G.mem_general_type_id = 'PFL' AND Q.member_seq_id IS NULL OR b.member_seq_id = Q.member_seq_id OR b.member_seq_id IS NULL);
        FETCH v_result_set INTO v_ava_si,v_age_rsi, v_ava_rsi;
        CLOSE v_result_set;
        ---dbms_output.put_line(v_ava_si||'--'||v_ava_rsi);

   v_sum_insured := v_ava_si;
   v_rest_si     := LEAST(v_ava_si,v_age_rsi,v_ava_rsi);

END;
--====================================================================================================================
PROCEDURE  age_pa_ava_copay(  v_pat_gen_detail_seq_id       IN pat_general_details.pat_gen_detail_seq_id%TYPE,
                               v_sum_insured                IN OUT tpa_enr_balance.sum_insured%TYPE,
                               v_age_si                     IN OUT tpa_enr_balance.restrict_amt%TYPE,
                               v_used_si                    IN OUT tpa_enr_balance.utilised_sum_insured%TYPE,
                               v_rest_si                    IN OUT tpa_enr_balance.restrict_amt%TYPE) IS


    v_ctr                               NUMBER;
    v_member_seq_id                     Tpa_Enr_Policy_Member.Member_Seq_Id%TYPE;

    v_unusable_sum                      NUMBER(12,2):= 0;
    v_unusable_bonus                    NUMBER(12,2):= 0;
    v_completed_yn                      CHAR(1);
    v_date_of_hospitalization           pat_general_details.likely_date_of_hospitalization%TYPE;
    v_result_set                        SYS_REFCURSOR;
    v_ava_si                            Tpa_enr_balance.sum_insured%TYPE;
    v_ava_rsi                           Tpa_enr_balance.sum_insured%TYPE;
    v_ava_asi                           Tpa_enr_balance.sum_insured%TYPE;

   CURSOR pat_cur IS SELECT a.completed_yn , a.likely_date_of_hospitalization,b.member_seq_id
     FROM pat_general_details a
     JOIN pat_enroll_details b ON (a.pat_enroll_detail_seq_id = b.pat_enroll_detail_seq_id)
     WHERE a.pat_gen_detail_seq_id = v_pat_gen_detail_seq_id;

  BEGIN
    SELECT COUNT(1) INTO v_ctr
      FROM discrepancy_information
      WHERE pat_gen_detail_seq_id = v_pat_gen_detail_seq_id AND resolved_yn = 'N';

    OPEN pat_cur;
    FETCH pat_cur INTO v_completed_yn , v_date_of_hospitalization, v_member_seq_id;
    CLOSE pat_cur;

    IF v_completed_yn = 'N'THEN
      pre_auth_pkg.get_unusable_amounts( trunc(v_date_of_hospitalization), v_member_seq_id, v_unusable_sum , v_unusable_bonus );
    END IF;

    OPEN v_result_set FOR
    SELECT

      CASE WHEN b.member_seq_id IS NULL THEN a.ava_sum_insured
           WHEN a.completed_yn = 'Y' THEN v_sum_insured - i.utilised_sum_insured
           WHEN (v_sum_insured - i.utilised_sum_insured + NVL(A.app_sum_insured,0)) <= v_sum_insured THEN (v_sum_insured - i.utilised_sum_insured + NVL(A.app_sum_insured,0))
           ELSE v_sum_insured
         END - NVL(v_unusable_sum,0) AS ava_sum_insured,

       CASE WHEN b.member_seq_id IS NULL THEN a.ava_sum_insured
            WHEN a.completed_yn='Y' THEN nvl(v_age_si,0)-nvl(v_used_si,0)
            WHEN (nvl(v_age_si,0)-nvl(v_used_si,0)+NVL(A.app_sum_insured,0))<=NVL(v_age_si,0) THEN
                 (nvl(v_age_si,0)-nvl(v_used_si,0)+NVL(A.app_sum_insured,0))
            ELSE  nvl(v_age_si,0) END - NVL(v_unusable_sum,0)
           AS ava_age_si ,

       CASE WHEN b.member_seq_id is null THEN a.ava_sum_insured
           WHEN a.completed_yn='Y' then nvl(v_rest_si,0)-nvl(i.used_restrict_amt,0)
           WHEN (nvl(v_rest_si,0)-nvl(i.used_restrict_amt,0)+NVL(A.app_sum_insured,0))<=NVL(v_rest_si,0) THEN
                (nvl(v_rest_si,0)-nvl(i.used_restrict_amt,0)+NVL(A.app_sum_insured,0))
           ELSE  nvl(v_rest_si,0) END - NVL(v_unusable_sum,0) as ava_rest_sum_insured


      FROM pat_general_details A
      JOIN pat_enroll_details B ON (A.pat_enroll_detail_seq_id = B.pat_enroll_detail_seq_id)
      LEFT OUTER JOIN tpa_enr_policy_member H ON (b.member_seq_id = h.member_seq_id)
      LEFT OUTER JOIN tpa_enr_balance I ON (h.policy_group_seq_id = i.policy_group_seq_id)
      LEFT OUTER JOIN tpa_ins_prod_policy Z ON (Z.Policy_Seq_Id=i.policy_seq_id)
      WHERE A.pat_gen_detail_seq_id = v_pat_gen_detail_seq_id
        AND (h.mem_general_type_id = 'PFL' AND I.member_seq_id IS NULL OR b.member_seq_id = i.member_seq_id OR b.member_seq_id IS NULL );

   FETCH v_result_set INTO v_ava_si,v_ava_asi, v_ava_rsi;
   CLOSE v_result_set;
   --dbms_output.put_line(v_ava_si||'--'||v_ava_rsi);

   v_sum_insured := v_ava_si;
   v_rest_si     := LEAST(v_ava_si,v_ava_rsi,v_ava_asi);

 END ;
---=================================================================================
PROCEDURE copay_adviced(
       v_mem_seq_id          IN  Pat_enroll_details.member_seq_id%TYPE,
       v_pol_grp_seq_id      IN  Tpa_enr_policy_group.policy_group_seq_id%TYPE,
       v_balance_seq_id      IN  Tpa_enr_balance.balance_seq_id%TYPE,
       v_pat_gen_seq_id      IN  Pat_general_details.pat_gen_detail_seq_id%TYPE,
       v_appr_amt            OUT Tpa_enr_balance.sum_insured%TYPE,
       v_max_copay           OUT Tpa_enr_balance.sum_insured%TYPE ) IS

    v_pat_enr_seq_id        Pat_general_details.pat_gen_detail_seq_id%TYPE;
    v_prod_policy_seq_id    Tpa_ins_prod_policy.prod_policy_seq_id%TYPE;
    v_poll_grp_seq_id       Tpa_enr_policy_group.policy_group_seq_id%TYPE;
    v_result_set            SYS_REFCURSOR;
    v_rest_ctr              NUMBER(3);

   CURSOR  cur_pol(v_pol_grp_seq_id NUMBER) is
       SELECT    pg.policy_sub_general_type_id AS policy_type,
                 pg.enrol_type_id,
                 pg.policy_number,
                 pg.policy_seq_id
        FROM Tpa_enr_policy pg
        INNER JOIN app.tpa_enr_policy_group epg ON (pg.policy_seq_id=epg.policy_seq_id)
        WHERE epg.policy_group_seq_id=v_pol_grp_seq_id;

    poll_cur cur_pol%rowtype;

   CURSOR cur_cop_rest(v_prod_policy_seq_id NUMBER) IS
          SELECT ipp.copay_yn,
                 ipp.copay_approved_amt,
                 ipp.copay_fixed_amt,
                 ipp.copay_perc,
                 ipp.copay_level,
                 ipp.si_restrict_yn,
                 ipp.si_relation,
                 ipp.si_restrict_amt,
                 ipp.si_restrict_perc,
                 ipp.si_type,
                 ipp.si_rest_level
     FROM  Tpa_ins_prod_policy  ipp
     WHERE ipp.prod_policy_seq_id=v_prod_policy_seq_id;

     cop_rest_cur   cur_cop_rest%ROWTYPE;

   CURSOR cur_si is
          SELECT teb.sum_insured,
                 teb.utilised_sum_insured,
                 teb.restrict_amt,
                 teb.used_restrict_amt
          FROM Tpa_enr_balance teb
          WHERE teb.balance_seq_id=v_balance_seq_id;

   si_cur       cur_si%ROWTYPE;

   CURSOR cur_polc(v_prod_policy_seq_id NUMBER) IS
           SELECT gt.prod_policy_seq_id
            FROM app.tpa_enr_policy GH
            LEFT OUTER JOIN Tpa_ins_prod_policy GT ON (GH.policy_seq_id=GT.policy_seq_id)
            LEFT OUTER JOIN Tpa_ins_prod_policy_rules GM ON (GT.prod_policy_seq_id=GM.prod_policy_seq_id)
            WHERE GH.policy_seq_id=poll_cur.policy_seq_id;

   CURSOR cur_prod(v_prod_policy_seq_id NUMBER) IS
         SELECT tipp.prod_policy_seq_id
           FROM app.tpa_enr_policy tep
           LEFT OUTER JOIN app.tpa_ins_product tip ON (tip.product_seq_id=tep.product_seq_id)
           LEFT OUTER JOIN app.tpa_ins_prod_policy tipp ON (tipp.product_seq_id=tip.product_seq_id)
     WHERE tep.policy_seq_id=poll_cur.policy_seq_id;

     prod_pol              cur_polc%ROWTYPE;
     v_config_amt          tpa_enr_balance.sum_insured%TYPE;
     v_used_amt            tpa_enr_balance.utilised_sum_insured%TYPE;
     v_age_flag            VARCHAR2(3);

     v_sum_ins_ava         tpa_enr_balance.sum_insured%TYPE;
     v_rfm_ins_ava         tpa_enr_balance.sum_insured%TYPE;
     v_age_ins_ava         tpa_enr_balance.sum_insured%TYPE;

 BEGIN

     OPEN  cur_pol(v_pol_grp_seq_id);
     FETCH cur_pol INTO poll_cur;
     CLOSE cur_pol;

     IF poll_cur.enrol_type_id ='COR' THEN
        OPEN  cur_polc(poll_cur.policy_seq_id);
        FETCH cur_polc INTO prod_pol;
        CLOSE cur_polc;
     ELSE
        OPEN  cur_prod(poll_cur.policy_seq_id);
        FETCH cur_prod INTO prod_pol;
        CLOSE cur_prod;
     END IF;

        OPEN  cur_cop_rest(prod_pol.prod_policy_seq_id);
        FETCH cur_cop_rest INTO cop_rest_cur;
        CLOSE cur_cop_rest;

        OPEN  cur_si;
        FETCH cur_si INTO si_cur;
        CLOSE cur_si;

   SELECT pat_enroll_detail_seq_id INTO v_pat_enr_seq_id
   FROM  app.pat_general_details
   WHERE pat_gen_detail_seq_id=v_pat_gen_seq_id;

     pre_auth_pkg.p_rest_si(v_pat_enr_seq_id,v_mem_seq_id,v_poll_grp_seq_id,v_rest_ctr,'P');

     IF v_rest_ctr>0 THEN
       pre_auth_pkg.age_amount_rest(v_pat_gen_seq_id ,'P',v_config_amt ,v_used_amt ,v_age_flag );

       IF v_age_flag ='N' THEN
         v_max_copay:= si_cur.restrict_amt*(1-nvl(cop_rest_cur.copay_perc,0)/100);
        IF (si_cur.restrict_amt*(1-nvl(cop_rest_cur.copay_perc,0)/100)-nvl(si_cur.used_restrict_amt,0))/(1-nvl(cop_rest_cur.copay_perc,0)/100)<
           (si_cur.sum_insured*(1-nvl(cop_rest_cur.copay_perc,0)/100)-nvl(si_cur.utilised_sum_insured,0))/(1-nvl(cop_rest_cur.copay_perc,0)/100)
        THEN
        v_appr_amt :=(si_cur.restrict_amt*(1-nvl(cop_rest_cur.copay_perc,0)/100)-nvl(si_cur.used_restrict_amt,0))/(1-nvl(cop_rest_cur.copay_perc,0)/100);
        ELSE
        v_appr_amt := (si_cur.sum_insured*(1-nvl(cop_rest_cur.copay_perc,0)/100)-nvl(si_cur.utilised_sum_insured,0))/(1-nvl(cop_rest_cur.copay_perc,0)/100);
        END IF;

       ELSIF v_age_flag = 'Y' THEN
            v_max_copay:= v_config_amt*(1-nvl(cop_rest_cur.copay_perc,0)/100);
        IF (v_config_amt*(1-nvl(cop_rest_cur.copay_perc,0)/100)-nvl(v_used_amt,0))/(1-nvl(cop_rest_cur.copay_perc,0)/100)<
           (si_cur.sum_insured*(1-nvl(cop_rest_cur.copay_perc,0)/100)-nvl(si_cur.utilised_sum_insured,0))/(1-nvl(cop_rest_cur.copay_perc,0)/100)

        THEN
        v_sum_ins_ava := (si_cur.sum_insured*(1-nvl(cop_rest_cur.copay_perc,0)/100)-nvl(si_cur.utilised_sum_insured,0))/(1-nvl(cop_rest_cur.copay_perc,0)/100);
        v_rfm_ins_ava := (si_cur.restrict_amt*(1-nvl(cop_rest_cur.copay_perc,0)/100)-nvl(si_cur.used_restrict_amt,0))/(1-nvl(cop_rest_cur.copay_perc,0)/100);
        v_appr_amt := (v_config_amt*(1-nvl(cop_rest_cur.copay_perc,0)/100)-nvl(v_used_amt,0))/(1-nvl(cop_rest_cur.copay_perc,0)/100);
        v_appr_amt := least(v_sum_ins_ava,v_rfm_ins_ava,v_appr_amt);
        ELSE
        v_appr_amt := (si_cur.sum_insured*(1-nvl(cop_rest_cur.copay_perc,0)/100)-nvl(si_cur.utilised_sum_insured,0))/(1-nvl(cop_rest_cur.copay_perc,0)/100);
        v_rfm_ins_ava := (si_cur.restrict_amt*(1-nvl(cop_rest_cur.copay_perc,0)/100)-nvl(si_cur.used_restrict_amt,0))/(1-nvl(cop_rest_cur.copay_perc,0)/100);
        v_appr_amt := least(v_appr_amt,v_rfm_ins_ava);
        END IF;
       END IF;

    ELSE
       v_max_copay:= si_cur.sum_insured*(1-nvl(cop_rest_cur.copay_perc,0)/100);
       v_appr_amt := (si_cur.sum_insured*(1-nvl(cop_rest_cur.copay_perc,0)/100)-nvl(si_cur.utilised_sum_insured,0))/(1-nvl(cop_rest_cur.copay_perc,0)/100);
     END IF;

    END;

 --==================================================================================================================
---- icd_code details 
  FUNCTION f_icd_code_desc_pat(v_pat_gen_detail_seq_id  IN icd_pcs_detail.pat_gen_detail_seq_id%TYPE, -- to precide ICD CODES
                           v_flag                   IN VARCHAR2,
                           v_type                   IN VARCHAR2)
         RETURN  VARCHAR2 AS
         v_out   VARCHAR2(4000);
                          
 CURSOR cur_icd IS              
        SELECT pat_gen_detail_seq_id,
                  nvl(MAX(CASE WHEN icd_rank=1 THEN icd_code ELSE NULL END),'NA') icd_code_1,
                  nvl(MAX(CASE WHEN icd_rank=2 THEN icd_code ELSE NULL END),'NA') icd_code_2,
                  nvl(MAX(CASE WHEN icd_rank=1 THEN ped_description ELSE NULL END),'NA') icd_desc_1,
                  nvl(MAX(CASE WHEN icd_rank=2 THEN ped_description ELSE NULL END),'NA') icd_desc_2
                  FROM
                  (SELECT g.pat_gen_detail_seq_id,
                          i.icd_code,
                          k.ped_description,
                          rank()over (ORDER BY i.icd_pcs_seq_id,i.primary_ailment_yn DESC) icd_rank
                  FROM pat_general_details g
                  LEFT OUTER JOIN icd_pcs_detail i ON (i.pat_gen_detail_seq_id=g.pat_gen_detail_seq_id)
                  LEFT OUTER JOIN tpa_ped_code k ON (k.icd_code=i.icd_code)
                  WHERE g.pat_gen_detail_seq_id=v_pat_gen_detail_seq_id)
                  GROUP BY pat_gen_detail_seq_id ;
                  
      icd_cur     cur_icd%ROWTYPE;
      
  CURSOR cur_pcd IS      
         SELECT pat_gen_detail_seq_id,
                  nvl(MAX(CASE WHEN RANK=1 THEN proc_code ELSE NULL END),'NA') pcs_code_1,
                  nvl(MAX(CASE WHEN RANK=2 THEN proc_code ELSE NULL END),'NA') pcs_code_2,
                  nvl(MAX(CASE WHEN RANK=1 THEN proc_description ELSE NULL END),'NA') pcs_desc_1,
                  nvl(MAX(CASE WHEN RANK=2 THEN proc_description ELSE NULL END),'NA') pcs_desc_2
           FROM (SELECT p.proc_seq_id,
                        g.pat_gen_detail_seq_id,
                        i.icd_code,
                        i.primary_ailment_yn,
                        c.proc_code,
                        nvl(substr(REPLACE(REPLACE(c.proc_description,chr(13),''),CHR(10),' '),1,240),'NA') proc_description,
                        rank()over (ORDER BY p.pat_proc_seq_id DESC) RANK
                  FROM pat_general_details G
                  INNER JOIN icd_pcs_detail I ON (i.pat_gen_detail_seq_id=g.pat_gen_detail_seq_id)
                  INNER JOIN pat_package_procedures P ON (p.icd_pcs_seq_id=i.icd_pcs_seq_id)
                  INNER JOIN tpa_hosp_procedure_code C ON (c.proc_seq_id=p.proc_seq_id)
                  WHERE g.pat_gen_detail_seq_id=v_pat_gen_detail_seq_id) group by pat_gen_detail_seq_id;     
      
      
      pcd_cur         cur_pcd%ROWTYPE;
                  
 BEGIN
 
  IF v_flag ='IC' THEN
 
  OPEN cur_icd;
  FETCH cur_icd INTO icd_cur;
  CLOSE cur_icd;
  
  IF v_type ='IC1' THEN
       v_out := icd_cur.icd_code_1;
  ELSIF v_type ='IC2' THEN  
       v_out := icd_cur.icd_code_2;
  ELSIF v_type ='ID1' THEN        
       v_out := icd_cur.icd_desc_1;
  ELSIF v_type ='ID2' THEN        
       v_out := icd_cur.icd_desc_2;
  END IF;
  
 ELSIF v_flag ='PC' THEN
     OPEN cur_pcd;
     FETCH cur_pcd INTO pcd_cur;
     CLOSE cur_pcd;
  
    IF v_type ='PC1' THEN
       v_out := pcd_cur.pcs_code_1;
    ELSIF v_type ='PC2' THEN  
          v_out := pcd_cur.pcs_code_2;
    ELSIF v_type ='PD1' THEN        
          v_out := pcd_cur.pcs_desc_1;
    ELSIF v_type ='PD2' THEN        
          v_out := pcd_cur.pcs_desc_2;
    END IF;
  
  END IF; 
  
  RETURN nvl(v_out,'NA');
 END;
------------ end of icd pcs details
---==================================================================================
FUNCTION fn_sfremarks_pat (v_pat_gen_detail_seq_id IN pat_general_details.pat_gen_detail_seq_id%TYPE)
  RETURN VARCHAR2
  IS
        CURSOR cur IS
        WITH AB AS (
        SELECT shortfall_questions,s.claim_seq_id,c.pre_auth_dms_reference_id
        FROM shortfall_details s, pat_general_details c
        WHERE c.pat_gen_detail_seq_id =s.pat_gen_detail_seq_id
        AND s.pat_gen_detail_seq_id=v_pat_gen_detail_seq_id
        )
        SELECT extractValue(value(C), '/query/@value') as otherquery
             FROM  AB, table(XMLSequence(extract(SHORTFALL_QUESTIONS ,'shortfall/section/subsection/query')))C
             WHERE upper(extractValue(value(C), '/query/@type'))='TEXT';

        otherquery                VARCHAR2(32000);
        claim_number1             VARCHAR2(100);
        tpa_enrollment_id1        VARCHAR2(100);
        str                       VARCHAR2(32767):=NULL;
        v_str                     CLOB:=null;
        comma                     CHAR:=NULL;
  BEGIN

        OPEN cur;
        LOOP
        FETCH cur INTO otherquery;
        EXIT WHEN cur%NOTFOUND;
        IF length(otherquery)>1   THEN
           v_str:=v_str||comma||otherquery;
            END IF;
            comma:=',';
        END LOOP;
        CLOSE cur;        
        str:=dbms_lob.substr(v_str,3000,1);
        str := REPLACE(str,'&','AND');
        RETURN str;
  END;    
  
  ------------- end of sf remarks
 

END buffer_changes_pkg;

/

--------------------------------------------------------
--  DDL for Synonymn DUMMY
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."DUMMY" FOR "APP"."DUMMY";

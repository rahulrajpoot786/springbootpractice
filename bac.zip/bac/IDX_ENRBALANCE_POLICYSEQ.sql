--------------------------------------------------------
--  DDL for Synonymn IDX_ENRBALANCE_POLICYSEQ
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."IDX_ENRBALANCE_POLICYSEQ" FOR "APP"."IDX_ENRBALANCE_POLICYSEQ";

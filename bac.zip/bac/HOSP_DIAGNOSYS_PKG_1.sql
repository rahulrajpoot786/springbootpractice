--------------------------------------------------------
--  DDL for Package HOSP_DIAGNOSYS_PKG
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "VENUBABU"."HOSP_DIAGNOSYS_PKG" 
IS
--========================================================================================================
PROCEDURE select_diag_mem_list(v_pre_auth_number              IN pat_enroll_details.pre_auth_number%TYPE,
                               v_auth_number                  IN pat_enroll_details.auth_number%TYPE,
                               v_mem_name                     IN VARCHAR2,
                               v_tpa_enrollment_id            IN tpa_enr_policy_member.tpa_enrollment_id%type,
                               v_otp_confirm_yn               IN CHAR,
                               v_bill_complete_yn             IN CHAR,
                               v_start_date                   IN VARCHAR2,
                               v_end_date                     IN VARCHAR2,
                               v_hosp_seq_id                  IN tpa_hosp_info.hosp_seq_id%TYPE,
                               v_sort_var                     IN  VARCHAR2,
                               v_sort_order                   IN  VARCHAR2 ,
                               v_start_num                    IN  NUMBER ,
                               v_end_num                      IN  NUMBER ,
                               result_set                   OUT SYS_REFCURSOR);
--========================================================================================================
PROCEDURE validate_enrollment_id (
    v_tpa_enrollment_id                  IN  PAT_ENROLL_DETAILS.tpa_enrollment_id%TYPE,
    v_hosp_seq_id                        IN  tpa_hosp_info.hosp_seq_id%type,
    v_added_by                           IN  NUMBER,
    v_member_seq_id                      OUT tpa_enr_policy_member.member_seq_id%type,
    v_diag_gen_seq_id                    OUT tpa_diagnosys_gen_dtls.Diag_Gen_Seq_Id%TYPE,
    v_date_of_hosp                       IN  varchar2,
    v_rows_processed                     OUT NUMBER);

--========================================================================================================
PROCEDURE save_diagnosys_details (
    v_diag_enroll_seq_id                 IN OUT tpa_diagnosys_enroll_dtls.diag_enroll_seq_id%type,
    v_diag_test_seq_id                   IN tpa_diagnosys_enroll_dtls.diag_test_seq_id%TYPE,
    v_diag_gen_seq_id                    IN tpa_diagnosys_enroll_dtls.Diag_Gen_Seq_Id%TYPE,
    v_entered_rate                       IN tpa_diagnosys_enroll_dtls.Entered_Rate%TYPE,
    v_agreed_rate                        IN tpa_diagnosys_enroll_dtls.Agreed_Rate%TYPE,
    v_discount_perc                      IN tpa_diagnosys_enroll_dtls.Discount_Perc%TYPE,
    v_discount_rate                      IN tpa_diagnosys_enroll_dtls.Discount_Rate%TYPE,
    v_added_by                           IN  NUMBER,
    v_rows_processed                     OUT NUMBER);
--========================================================================================================
PROCEDURE select_diagnosys_test_list (v_hosp_seq_id                      IN tpa_hosp_info.hosp_seq_id%type,
                                         v_result_set                       OUT SYS_REFCURSOR);
--========================================================================================================
PROCEDURE select_diagnosys_test_details (v_diag_gen_seq_id                  IN tpa_diagnosys_enroll_dtls.diag_gen_seq_id%TYPE,
                                        -- vidal_result_set                       OUT SYS_REFCURSOR,
                                         diagnosys_enrol_result                 OUT SYS_REFCURSOR);
--========================================================================================================

PROCEDURE select_diag_test(v_str   IN VARCHAR2,
                           v_result_set  OUT SYS_REFCURSOR)    ;
--========================================================================================================
PROCEDURE generate_otp(v_member_seq_id       IN tpa_enr_policy_member.member_seq_id%type,
                       v_diag_gen_seq_id     IN tpa_diagnosys_gen_dtls.diag_gen_seq_id%type,
                       v_added_by            IN NUMBER,
                       v_otp_id              OUT NUMBER);
--========================================================================================================
PROCEDURE validate_otp(v_diag_gen_seq_id                    IN tpa_diagnosys_gen_dtls.Diag_Gen_Seq_Id%TYPE,
                       v_otp_number                         IN tpa_enr_pol_mem_otp_codes.otp_number%type,
                       v_otp_outdated_yn                    OUT CHAR,
                       v_otp_blocked_yn                     OUT CHAR,
                       v_otp_wrong_yn                       OUT CHAR,
                       v_validated_yn                       OUT CHAR,
                       v_added_by                           IN NUMBER,
                       v_rows_processed                     OUT NUMBER);
  
--=================================================================================
PROCEDURE gen_bill_report1(v_diag_gen_seq_id                  IN tpa_diagnosys_enroll_dtls.diag_gen_seq_id%TYPE,
                           v_result_set                       OUT SYS_REFCURSOR);

--=================================================================================
PROCEDURE gen_bill_report(v_diag_gen_seq_id                  IN tpa_diagnosys_enroll_dtls.diag_gen_seq_id%TYPE,
                          v_result_set                       OUT SYS_REFCURSOR);
--=================================================================================
PROCEDURE select_total_amt_details (v_diag_gen_seq_id                  IN tpa_diagnosys_enroll_dtls.diag_gen_seq_id%TYPE,
                                         vidal_result_set                       OUT SYS_REFCURSOR);
                                         
--=================================================================================
PROCEDURE submit_diagnosys_details (v_diag_gen_seq_id                  IN tpa_diagnosys_enroll_dtls.diag_gen_seq_id%TYPE,
                                    v_hosp_seq_id                      IN tpa_hosp_info.hosp_seq_id%TYPE,
                                    v_member_seq_id                    IN OUT tpa_enr_policy_member.member_seq_id%TYPE,
                                    v_tot_enter_amt                    IN pat_general_details.pat_requested_amount%TYPE,
                                    v_tot_agreed_amt                   IN pat_general_details.pat_requested_amount%TYPE,
                                    v_tot_discount_perc                IN tpa_diagnosys_gen_dtls.total_discount_rate%TYPE,
                                    v_total_app_amt                    IN OUT pat_general_details.total_app_amount%TYPE,
                                    v_added_by                         IN OUT NUMBER,
                                    v_pre_auth_number                  IN OUT pat_enroll_details.pre_auth_number%TYPE,
                                    v_error_msg                         OUT VARCHAR2,
                                    v_rows_processed                   OUT NUMBER);
--========================================================================================================
PROCEDURE save_hosp_mem_vital_dtls (
    V_mem_vital_seq_id                 IN OUT TPA_HOSP_MEM_VITAL_DETAILS.MEM_VITAL_SEQ_ID%type,
    v_member_id                        IN TPA_HOSP_MEM_VITAL_DETAILS.VIDAL_ID%TYPE,
    v_bp_systolic                      IN TPA_HOSP_MEM_VITAL_DETAILS.BP_SYSTOLIC%TYPE,
    v_bp_diastolic                     IN TPA_HOSP_MEM_VITAL_DETAILS.BP_DIASTOLIC%TYPE,
    v_temperature                      IN TPA_HOSP_MEM_VITAL_DETAILS.TEMPERATURE%TYPE,
    v_pulse                            IN TPA_HOSP_MEM_VITAL_DETAILS.PULSE%TYPE,
    v_respiration                      IN TPA_HOSP_MEM_VITAL_DETAILS.RESPIRATION%TYPE,
    v_height                           IN TPA_HOSP_MEM_VITAL_DETAILS.HEIGHT%TYPE,
    v_weight                           IN TPA_HOSP_MEM_VITAL_DETAILS.WEIGHT%TYPE,
    v_added_by                         IN TPA_HOSP_MEM_VITAL_DETAILS.ADDED_BY%TYPE,
    v_rows_processed                   OUT NUMBER);
    
---====================================================================  
PROCEDURE save_hosp_cashless(v_INTIMATE_SEQ_ID          IN OUT PAT_HOSP_INTIMATION_DETAILS.INTIMATE_SEQ_ID%Type,
                             v_HOSP_SEQ_ID              IN PAT_HOSP_INTIMATION_DETAILS.HOSP_SEQ_ID%Type,
                             v_MEMBER_SEQ_ID            IN PAT_HOSP_INTIMATION_DETAILS.MEMBER_SEQ_ID%Type,
                             v_CARD_HOLDER              IN PAT_HOSP_INTIMATION_DETAILS.CARD_HOLDER%Type,
                             v_INS_SEQ_ID               IN PAT_HOSP_INTIMATION_DETAILS.INS_SEQ_ID%Type,
                             v_TREATEMENT_DATE          IN PAT_HOSP_INTIMATION_DETAILS.TREATEMENT_DATE%Type,
                             v_INTIMATION_NUMBER        OUT PAT_HOSP_INTIMATION_DETAILS.INTIMATION_NUMBER%Type,
                             v_MEDICAL_RECORD_NO        IN PAT_HOSP_INTIMATION_DETAILS.MEDICAL_RECORD_NO%Type,
                             v_EMERGENCY_YN             IN PAT_HOSP_INTIMATION_DETAILS.EMERGENCY_YN%Type,
                             v_TREATING_PHYSICIAN       IN PAT_HOSP_INTIMATION_DETAILS.TREATING_PHYSICIAN%Type,
                             v_PHYSICIAN_ID             IN PAT_HOSP_INTIMATION_DETAILS.PHYSICIAN_ID%Type,
                             v_PHY_SPECIALITY_TYPE      IN PAT_HOSP_INTIMATION_DETAILS.PHY_SPECIALITY_TYPE%Type,
                             v_AILMENT_DESCRIPTION      IN PAT_HOSP_INTIMATION_DETAILS.AILMENT_DESCRIPTION%Type,
                             v_MEDICINE_GENERAL_TYPE_ID IN PAT_HOSP_INTIMATION_DETAILS.MEDICINE_GENERAL_TYPE_ID%Type,
                             v_ACCIDENT_REL_GEN_TYPE_ID IN PAT_HOSP_INTIMATION_DETAILS.ACCIDENT_REL_GEN_TYPE_ID%Type,
                             v_AILMENT_DURATION         IN PAT_HOSP_INTIMATION_DETAILS.AILMENT_DURATION%Type,
                             v_DURATION_GEN_TYPE_ID     IN PAT_HOSP_INTIMATION_DETAILS.DURATION_GEN_TYPE_ID%Type,
                             v_MEDICAL_FINDINGS         IN PAT_HOSP_INTIMATION_DETAILS.MEDICAL_FINDINGS%Type,
                             v_REQUESTED_AMOUNT         IN PAT_HOSP_INTIMATION_DETAILS.REQUESTED_AMOUNT%Type,
                             v_TREATMENT_GEN_TYPE_ID    IN PAT_HOSP_INTIMATION_DETAILS.TREATMENT_GEN_TYPE_ID%Type,
                             v_PREVIOUS_ILLNESS_YN      IN PAT_HOSP_INTIMATION_DETAILS.PREVIOUS_ILLNESS_YN%Type,
                             v_TREATMENT_DETAILS        IN PAT_HOSP_INTIMATION_DETAILS.TREATMENT_DETAILS%Type,
                             v_MEDICAL_REVIEW_YN        IN PAT_HOSP_INTIMATION_DETAILS.MEDICAL_REVIEW_YN%Type,
                             v_ADDED_BY                 IN PAT_HOSP_INTIMATION_DETAILS.ADDED_BY%Type,
                             v_rows_processed           OUT NUMBER);
----======================================================
PROCEDURE get_mem_benifit_details(v_tpa_enrollment_id                  IN  PAT_ENROLL_DETAILS.tpa_enrollment_id%TYPE,
                                  v_benefit_type                       IN  PAT_AUTHORIZATION_DETAILS.Benifit_Type%TYPE,                                     
                                  v_hosp_seq_id                        IN  TPA_HOSP_INFO.HOSP_SEQ_ID%TYPE,
                                  v_result_set                         OUT SYS_REFCURSOR,
                                  v_network_check                      OUT SYS_REFCURSOR);
--------============================================  
 PROCEDURE save_hosp_presc_dtls(
    v_prescription_seq_id              IN OUT TPA_HOSP_PRESCRIPTION_DETAILS.prescription_seq_id%TYPE,
    v_hosp_seq_id                      IN TPA_HOSP_PRESCRIPTION_DETAILS.hosp_seq_id%TYPE,
    v_intimate_seq_id                  IN TPA_HOSP_PRESCRIPTION_DETAILS.INTIMATE_SEQ_ID%TYPE,
    v_medical_type_id                  IN TPA_HOSP_PRESCRIPTION_DETAILS.medical_type_id%TYPE,
    v_added_by                         IN TPA_HOSP_PRESCRIPTION_DETAILS.ADDED_BY%TYPE
  );
---==============================================================
PROCEDURE add_prescription_details(
    v_prescription_type             IN TPA_HOSP_PRESC_MEDICAL_CODE.PRESCRIPTION_TYPE_ID%TYPE,
    v_medical_abb_type              IN TPA_HOSP_PRESC_MEDICAL_CODE.MEDICAL_TYPE_ID%TYPE,
    v_activity_code                 IN TPA_HOSP_PRESC_MEDICAL_CODE.ACTIVITY_CODE%TYPE,
    v_description                   IN TPA_HOSP_PRESC_MEDICAL_CODE.MEDICAL_DESCRIPTION%TYPE,
    v_added_by                      IN TPA_HOSP_PRESC_MEDICAL_CODE.added_by%TYPE,
    v_rows_processed                OUT NUMBER
  );
 -------
  PROCEDURE check_enrollment_id (
    v_tpa_enrollment_id                  IN  PAT_ENROLL_DETAILS.tpa_enrollment_id%TYPE,
    v_flag                               OUT VARCHAR2
    );
-----================================================
procedure save_pat_intimatimation(v_pat_intimation_seq_id   in out pat_intimation_details.pat_intimation_seq_id%type,
                                  v_member_seq_id           in pat_intimation_details.member_seq_id%type,
                                  v_ins_seq_id              in pat_intimation_details.ins_seq_id%type,
                                  v_hosp_seq_id             in pat_intimation_details.hosp_seq_id%type,
                                  v_pre_auth_seq_id         in pat_intimation_details.pre_auth_seq_id%type,
                                  v_medical_record_no       in pat_intimation_details.medical_record_no%type,
                                  v_emergency_yn            in pat_intimation_details.emergency_yn%type,
                                  v_clinician_id            in pat_intimation_details.clinician_id%type,
                                  v_clinician_speciality    in pat_intimation_details.clinician_speciality%type,
                                  v_presenting_complaints   in pat_intimation_details.presenting_complaints%type,
                                  v_medicine_gen_type_id    in pat_intimation_details.medicine_gen_type_id%type,
                                  v_accident_case_yn        in pat_intimation_details.accident_case_yn%type,
                                  v_procedure_gen_type_id   in pat_intimation_details.procedure_gen_type_id%type,
                                  v_since_when              in pat_intimation_details.since_when%type,
                                  v_trtmnt_plan_gen_type_id in pat_intimation_details.trtmnt_plan_gen_type_id%type,
                                  v_estimation_amount       in pat_intimation_details.estimation_amount%type,
                                  v_bp_systolic             in pat_intimation_details.bp_systolic%type,
                                  v_bp_diastolic            in pat_intimation_details.bp_diastolic%type,
                                  v_details_of_treatment    in pat_intimation_details.details_of_treatment%type,
                                  v_medical_findings        in pat_intimation_details.medical_findings%type,
                                  v_file_name               in pat_intimation_details.file_name%type,
                                  v_medical_type_ids        in varchar2,
                                  v_added_by                in pat_intimation_details.added_by%type,
                                  v_invoice_num             in pat_intimation_details.INVOICE_NUMBER%TYPE,
                                  V_FIR_NUMBER              in pat_intimation_details.FIR_NUMBER%TYPE,
                                  V_rows_processed          out NUMBER);
--==========================================================================================================================
procedure save_pat_online_intimation(v_pre_auth_seq_id        in out pat_authorization_details.pat_auth_seq_id%type,
                                    v_member_seq_id           in pat_authorization_details.member_seq_id%type,
                                    v_hospitalization_date    in pat_authorization_details.hospitalization_date%type,
                                    v_discharge_date          IN pat_authorization_details.discharge_date%type,
                                    v_clinician_name          in pat_non_network_details.clinician_name%type,
                                    v_clinician_id            in pat_authorization_details.clinician_id%type,
                                    v_presenting_complaints   in pat_authorization_details.presenting_complaints%type,
                                    v_past_history            in pat_authorization_details.past_history%type,
                                    v_duration_above_illness              in pat_authorization_details.duration_above_illness%type,
                                    v_duration_above_illness_time         in pat_authorization_details.duration_above_illness_time%type,
                                    v_since_when              in pat_authorization_details.since_when%type,
                                    v_since_when_time         in pat_authorization_details.since_when_time%type,
                                    v_encounter_start_type    in pat_authorization_details.encounter_start_type%type,
                                    v_encounter_type_id          in pat_authorization_details.encounter_type_id%type,
                                    v_pre_auth_number         in out pat_authorization_details.pre_auth_number%type,
                                    v_added_by                in pat_authorization_details.added_by%type,
                                    v_hosp_seq_id             in tpa_hosp_info.hosp_seq_id%type,
                                    v_tpa_enrollment_id       in pat_authorization_details.tpa_enrollment_id%type,
                                    v_benefit_type            in pat_authorization_details.benifit_type%type,
                                    v_clinician_speciality    in pat_authorization_details.clinician_speciality%type,
                                    v_consultation_type       in pat_authorization_details.consultation_type%type,
                                    v_rows_processed          out NUMBER,
                                    v_provider_login           in varchar2,
                                    v_file_name               in varchar2 := null,
                                    v_date_of_lmp             in pat_authorization_details.lmp_date%TYPE,
                                    v_conception_type         in pat_authorization_details.conception_type%TYPE,
                                    v_system_of_med           in pat_authorization_details.system_of_medicine_type_id%TYPE,
                                    v_delvy_mode              in pat_authorization_details.delvry_mod_type%TYPE,
                                     v_success_enh_yn          in pat_authorization_details.success_enh_yn%TYPE----NEWLY ADDED FOR PREAUTH ENHANCEMENT SUBMIT OR NOT
                                     ) ;
----------------------------------------------------------------------------------------
PROCEDURE select_pat_intimation_details(v_pat_auth_seq_id       IN pat_authorization_details.pat_auth_seq_id%type,
                                        v_result_set            OUT SYS_REFCURSOR);
---=========================================================================================
PROCEDURE add_consumable_details(v_CONSUMABLE_SEQ_ID     IN out tpa_consumable_details. CONSUMABLE_SEQ_ID %type,
                                 v_PAT_INTIMATION_SEQ_ID IN tpa_consumable_details. PAT_INTIMATION_SEQ_ID %type,
                                 v_ACTIVITY_SEQ_ID       IN tpa_consumable_details. ACTIVITY_SEQ_ID %type,
                                 v_ACTIVITY_CODE         IN tpa_consumable_details. ACTIVITY_CODE %type,
                                 v_UNIT_PRICE            IN tpa_consumable_details. UNIT_PRICE %type,
                                 v_QUANTITY              IN tpa_consumable_details. QUANTITY %type,
                                 v_GROSS                 IN tpa_consumable_details. GROSS %type,
                                 v_DISCOUNT              IN tpa_consumable_details. DISCOUNT %type,
                                 v_DISCOUNTED_GROSS      IN tpa_consumable_details. DISCOUNTED_GROSS %type,
                                 v_PATIENT_SHARE         IN tpa_consumable_details. PATIENT_SHARE %type,
                                 v_NET_AMOUNT            IN tpa_consumable_details. NET_AMOUNT %type,
                                 v_ADDED_BY              IN tpa_consumable_details. ADDED_BY %type,
                                 v_rows_processed        OUT NUMBER);
--------==================================================================================
PROCEDURE get_consumable_details(v_pat_intimation_seq_id IN tpa_hosp_info.hosp_seq_id%type,
                                 v_result_set            OUT SYS_REFCURSOR);

--===================================================================================================
PROCEDURE save_diagnosys_details(
  v_diag_seq_id       IN diagnosys_details.diag_seq_id%type,
  v_pat_auth_seq_id   IN diagnosys_details.pat_auth_seq_id%type,
  v_diagnosys_code    IN diagnosys_details.diagnosys_code%type,
  v_priamry_yn        IN diagnosys_details.Primary_Ailment_Yn%TYPE,
  v_added_by          IN diagnosys_details.added_by%type );
--=================================================
PROCEDURE select_activity_code(v_hosp_seq_id               IN tpa_hosp_info.hosp_seq_id%TYPE,
                               v_tpa_enrollment_id         IN tpa_enr_policy_member.tpa_enrollment_id%type,
                               v_activity_code             IN NUMBER,
                               v_activity_date             IN pat_activity_details.start_date%TYPE,
                               v_flag                      IN OUT VARCHAR2,
                               v_flag1                     IN VARCHAR2,                     
                               v_tariff_result             OUT SYS_REFCURSOR);

---===========================================================================================
PROCEDURE select_activity_list (
    v_act_code                 IN OUT tpa_activity_master_details.activity_code%TYPE,
    v_description              IN OUT tpa_activity_master_details.activity_description%TYPE,
    v_search_flag              IN VARCHAR2,
    v_hosp_seq_id              IN tpa_hosp_info.hosp_seq_id%TYPE,
    v_tpa_enrollment_id        IN tpa_enr_policy_member.tpa_enrollment_id%type,
    v_internal_code            IN OUT tpa_hosp_tariff_details.internal_code%TYPE,
    v_sort_var                 IN OUT VARCHAR2 ,
    v_sort_order               IN OUT VARCHAR2,
    v_start_num                IN OUT NUMBER  ,
    v_end_num                  IN OUT NUMBER  ,
    v_result_set               OUT SYS_REFCURSOR,
    v_flag                     IN VARCHAR2
  );
--=========================================================
PROCEDURE select_DDC_list (
    v_act_code                 IN OUT tpa_activity_master_details.activity_code%TYPE,
    v_description              IN OUT tpa_activity_master_details.activity_description%TYPE,
    v_search_flag              IN VARCHAR2,
    v_hosp_seq_id              IN tpa_hosp_info.hosp_seq_id%TYPE,
    v_tpa_enrollment_id		     IN tpa_enr_policy_member.tpa_enrollment_id%type,
    v_sort_var                 IN OUT VARCHAR2 ,
    v_sort_order               IN OUT VARCHAR2,
    v_start_num                IN OUT NUMBER  ,
    v_end_num                  IN OUT NUMBER  ,
    v_result_set               OUT SYS_REFCURSOR
  );
--====================================================================  
PROCEDURE save_activity_details(
    v_activity_dtl_seq_id     IN  pat_activity_details.activity_dtl_seq_id%TYPE,
    v_pat_auth_seq_id         IN  pat_activity_details.pat_auth_seq_id%TYPE,
    v_code                    IN  pat_activity_details.code%TYPE,
    v_quantity                IN  pat_activity_details.quantity%TYPE,
    v_gross_amount            IN  pat_activity_details.gross_amount%TYPE,
    v_discount_amount         IN  pat_activity_details.discount_amount%TYPE,
    v_disc_gross_amount       IN  pat_activity_details.disc_gross_amount%TYPE,
    v_net_amount              IN  pat_activity_details.net_amount%TYPE,
    v_start_date              IN  varchar2,
    v_allowed_yn              in varchar2,
    v_clinician_id            in  pat_activity_details.clinician_id%type,
    v_added_by                IN  pat_activity_details.added_by%TYPE,
    v_activity_type_id        in  app.tpa_activity_type_codes.activity_type_id%type,
    v_internal_code           in  pat_activity_details.internal_code%TYPE,
	  v_tooth_no                in  pat_activity_details.tooth_no%TYPE,
    v_internal_desc           in pat_activity_details.internal_desc%Type,
    v_override_yn             IN  pat_activity_details.override_yn%type,----
    v_override_remarks        IN  pat_activity_details.override_remarks%type,-----
    v_denial_code             IN  pat_activity_details.denial_code%type,------
    v_denial_desc             IN  pat_activity_details.denial_desc%type,
    v_override_remarks_code     IN  pat_activity_details.override_remarks_code%type,  --- added in override drop down list cr
    v_other_remarks           IN  pat_activity_details.other_remarks%type            --- added in override drop down list cr
  -----
);
--======================================================================
PROCEDURE save_ddc_details(
    v_activity_dtl_seq_id     IN  pat_activity_details.activity_dtl_seq_id%TYPE,
    v_pat_auth_seq_id         IN  pat_activity_details.pat_auth_seq_id%TYPE,
    v_code                    IN  pat_activity_details.code%TYPE,
    v_quantity                IN  pat_activity_details.quantity%TYPE,
    v_posology                IN  pat_activity_details.posology%TYPE,
    v_posology_duration       IN  pat_activity_details.posology_duration%TYPE,
    v_unit_type               IN  pat_activity_details.unit_type%TYPE,
    v_gross_amount            IN  pat_activity_details.gross_amount%TYPE,
    v_discount_amount         IN  pat_activity_details.discount_amount%TYPE,
    v_disc_gross_amount       IN  pat_activity_details.disc_gross_amount%TYPE,
    v_net_amount              IN  pat_activity_details.net_amount%TYPE,
    v_start_date              IN  varchar2,
    v_allowed_yn              in varchar2,
    v_clinician_id            in  pat_activity_details.clinician_id%type,
    v_added_by                IN  pat_activity_details.added_by%TYPE
);
--=============================================================================
PROCEDURE get_hosp_details(v_tpa_enrollment_id                  IN  PAT_ENROLL_DETAILS.tpa_enrollment_id%TYPE,
                                  v_benefit_type                       IN  PAT_AUTHORIZATION_DETAILS.Benifit_Type%TYPE,                                     
                                  v_hosp_seq_id                        IN  TPA_HOSP_INFO.HOSP_SEQ_ID%TYPE,
                                  v_result_set                         OUT SYS_REFCURSOR);

--======================================================================================
PROCEDURE get_mem_details(v_tpa_enrollment_id          IN  app.tpa_enr_policy_member.tpa_enrollment_id%TYPE,
                          v_result_set                     OUT SYS_REFCURSOR);

---==========================SAVE PREAUTH GENERAL DETAILS at edit and save level =======================================================================
PROCEDURE save_pat_online_intimation1
            (v_pre_auth_seq_id        in out pat_authorization_details.pat_auth_seq_id%type,
            v_member_seq_id           in pat_authorization_details.member_seq_id%type,
            v_hospitalization_date    in pat_authorization_details.hospitalization_date%type,
            v_discharge_date          IN pat_authorization_details.discharge_date%type,
            v_clinician_name          in pat_non_network_details.clinician_name%type,
            v_clinician_id            in pat_authorization_details.clinician_id%type,
            v_presenting_complaints   in pat_authorization_details.presenting_complaints%type,
            v_past_history            in pat_authorization_details.past_history%type,
            v_duration_above_illness              in pat_authorization_details.duration_above_illness%type,
            v_duration_above_illness_time         in pat_authorization_details.duration_above_illness_time%type,
            v_since_when              in pat_authorization_details.since_when%type,
            v_since_when_time         in pat_authorization_details.since_when_time%type,
            v_encounter_start_type    in pat_authorization_details.encounter_start_type%type,
            v_encounter_type_id          in pat_authorization_details.encounter_type_id%type,
            v_pl_preauth_refno         in out pat_authorization_details.pl_preauth_refno%type,
            v_added_by                in pat_authorization_details.added_by%type,
            v_hosp_seq_id             in tpa_hosp_info.hosp_seq_id%type,
            v_tpa_enrollment_id       in pat_authorization_details.tpa_enrollment_id%type,
            v_benefit_type            in pat_authorization_details.benifit_type%type,
            v_clinician_speciality    in pat_authorization_details.clinician_speciality%type,
            v_consultation_type       in pat_authorization_details.consultation_type%type,
            v_rows_processed          out NUMBER,
            v_file_name               in varchar2 := null,
            v_enhance_yn              in varchar2,
            v_gentype_id              in MOU_DOCS_INFO1.FILE_NAME%TYPE,
            v_image_data              in MOU_DOCS_INFO1.IMAGE_FILE%TYPE := null,
            v_date_of_lmp             in pat_authorization_details.lmp_date%TYPE,
            v_conception_type         in pat_authorization_details.conception_type%TYPE,
            v_system_of_med           in pat_authorization_details.system_of_medicine_type_id%TYPE,
            v_delvy_mode              in pat_authorization_details.delvry_mod_type%TYPE,
			      v_event_no                in pat_authorization_details.event_no%TYPE);
--==============================This save is added for hosp login ========================================= 
PROCEDURE save_pat_details(v_pat_auth_seq_id            in out pat_authorization_details.pat_auth_seq_id%type,
                           v_parent_pat_auth_seq_id     in pat_authorization_details.parent_pat_auth_seq_id%type,
                           v_pat_received_date          in pat_authorization_details.pat_received_date%type,
                           v_discharge_date             IN pat_authorization_details.discharge_date%type,
                           v_source_type_id             in pat_authorization_details.source_type_id%type,
                           v_hospitalization_date       in pat_authorization_details.hospitalization_date%type,
                           v_member_seq_id              in pat_authorization_details.member_seq_id%type,
                           v_tpa_enrollment_id          in pat_authorization_details.tpa_enrollment_id%type,
                           v_pl_preauth_refno            in out pat_authorization_details.pl_preauth_refno%type,
                           v_auth_number                in pat_authorization_details.auth_number%type,
                           v_mem_name                   in pat_authorization_details.mem_name%type,
                           v_mem_age                    in pat_authorization_details.mem_age%type,
                           v_ins_seq_id                 in pat_authorization_details.ins_seq_id%type,
                           v_hosp_seq_id                in pat_authorization_details.hosp_seq_id%type,
                           v_policy_seq_id              in pat_authorization_details.policy_seq_id%type,
                           v_emirate_id                 in pat_authorization_details.emirate_id%type,
                           v_encounter_type_id          in pat_authorization_details.encounter_type_id%type,
                           v_encounter_facility_id      in pat_authorization_details.encounter_facility_id%type,
                           v_encounter_start_type       IN pat_authorization_details.encounter_start_type%type,
                           v_encounter_end_type         IN pat_authorization_details.encounter_end_type%type,
                           v_remarks                    in pat_authorization_details.remarks%type,
                           v_added_by                   in number,
                           v_clinician_id               in pat_authorization_details.clinician_id%type,
                           v_system_of_medicine_type_id in pat_authorization_details.system_of_medicine_type_id%type,
                           v_accident_related_type_id   in pat_authorization_details.Accident_Related_Type_Id%TYPE,
                           v_priority_gen_type_id       in pat_authorization_details.priority_general_type_id%TYPE,
                           v_network_yn                 in pat_authorization_details.network_yn%type,
                           v_provider_name              in pat_non_network_details.provider_name%type,
                           v_provider_id                in pat_non_network_details.provider_id%type,
                           v_city_type_id               in pat_non_network_details.city_type_id%type,
                           v_state_type_id              in pat_non_network_details.state_type_id%type,
                           v_country_type_id            in pat_non_network_details.country_type_id%type,
                           v_provider_address           in pat_non_network_details.provider_address%type,
                           v_pincode                    in pat_non_network_details.pincode%type,
                           v_requested_amount           in pat_authorization_details.requested_amount%type,
                           v_benifit_type               in pat_authorization_details.benifit_type%type,
                           v_gravida                    in pat_authorization_details.gravida%type,
                           v_para                       in pat_authorization_details.para%type,
                           v_live                       in pat_authorization_details.live%type,
                           v_abortion                   in pat_authorization_details.abortion%type,
                           v_selection_type             in varchar2,--PAT,'ENH'--enhancement
                           v_currency_type              in pat_authorization_details.currency_type%type,
                           v_clinician_name             in pat_non_network_details.clinician_name%type,
                           v_ava_sum_insured            in pat_authorization_details.ava_sum_insured%type,
                           v_rows_processed             out number,
                           v_past_history               in pat_authorization_details.past_history%type:= null,
                           v_duration_above_illness              in pat_authorization_details.duration_above_illness%type,
                           v_duration_above_illness_time         in pat_authorization_details.duration_above_illness_time%type,
                           v_since_when                          in pat_authorization_details.since_when%type,
                           v_since_when_time                     in pat_authorization_details.since_when_time%type,
                           v_clinician_speciality    in pat_authorization_details.clinician_speciality%type:= null,
                           v_consultation_type       in pat_authorization_details.consultation_type%type:= null,
                           v_presenting_comp         IN pat_authorization_details.presenting_complaints%TYPE,
                           v_file_name               in varchar2,
                           v_enhance_yn              in varchar2,
                           v_gentype_id              in MOU_DOCS_INFO1.DOCS_GENTYPE_ID%TYPE,
                           v_image_data              in MOU_DOCS_INFO1.IMAGE_FILE%TYPE,
                           v_date_of_lmp             in pat_authorization_details.lmp_date%TYPE,
                           v_conception_type         in pat_authorization_details.conception_type%TYPE,
                           v_delvy_mode              in pat_authorization_details.delvry_mod_type%TYPE,
						   v_event_no                in pat_authorization_details.event_no%TYPE
                          );
                           
---=====================================================================================================
FUNCTION generate_id_numbers (v_flag       IN VARCHAR2
                             ) RETURN VARCHAR2; 
--======================================================================================================                             
PROCEDURE select_pat_auth_details (
                    v_pat_auth_seq_id                           IN  pat_authorization_details.pat_auth_seq_id%type,
                    v_auth_result_set                           OUT SYS_REFCURSOR ,
                    v_diag_result_set                           OUT SYS_REFCURSOR ,
                    v_activity_result_set                       OUT SYS_REFCURSOR ,
                    v_observ_result_set                         OUT SYS_REFCURSOR ,
                    v_shortfall_details                         OUT SYS_REFCURSOR ,
                    v_drugs_result_set                          OUT SYS_REFCURSOR );
                    
--=======================================================================================================                    
PROCEDURE GET_BENIFIT_COPAY_DEDU(V_BINIFIT_TYPE VARCHAR2,
                                 V_MEME_ID VARCHAR2,
                                 V_result_set    OUT SYS_REFCURSOR); 
                                 
--===========================This is save the preauth at batch level in provider login=================== 
PROCEDURE save_pat_details_app_level
                          (v_pat_auth_seq_id            in out pat_authorization_details.pat_auth_seq_id%type,
                           v_parent_pat_auth_seq_id     in pat_authorization_details.parent_pat_auth_seq_id%type,
                           v_pat_received_date          in pat_authorization_details.pat_received_date%type,
                           v_discharge_date             IN pat_authorization_details.discharge_date%type,
                           v_source_type_id             in pat_authorization_details.source_type_id%type,
                           v_hospitalization_date       in pat_authorization_details.hospitalization_date%type,
                           v_member_seq_id              in pat_authorization_details.member_seq_id%type,
                           v_tpa_enrollment_id          in pat_authorization_details.tpa_enrollment_id%type,
                           v_pre_auth_number            in out pat_authorization_details.pre_auth_number%type,
                           v_auth_number                in pat_authorization_details.auth_number%type,
                           v_mem_name                   in pat_authorization_details.mem_name%type,
                           v_mem_age                    in pat_authorization_details.mem_age%type,
                           v_ins_seq_id                 in pat_authorization_details.ins_seq_id%type,
                           v_hosp_seq_id                in pat_authorization_details.hosp_seq_id%type,
                           v_policy_seq_id              in pat_authorization_details.policy_seq_id%type,
                           v_emirate_id                 in pat_authorization_details.emirate_id%type,
                           v_encounter_type_id          in pat_authorization_details.encounter_type_id%type,
                           v_encounter_facility_id      in pat_authorization_details.encounter_facility_id%type,
                           v_encounter_start_type       IN pat_authorization_details.encounter_start_type%type,
                           v_encounter_end_type         IN pat_authorization_details.encounter_end_type%type,
                           v_remarks                    in pat_authorization_details.remarks%type,
                           v_added_by                   in number,
                           v_clinician_id               in pat_authorization_details.clinician_id%type,
                           v_system_of_medicine_type_id in pat_authorization_details.system_of_medicine_type_id%type,
                           v_accident_related_type_id   in pat_authorization_details.Accident_Related_Type_Id%TYPE,
                           v_priority_gen_type_id       in pat_authorization_details.priority_general_type_id%TYPE,
                           v_network_yn                 in pat_authorization_details.network_yn%type,
                           v_provider_name              in pat_non_network_details.provider_name%type,
                           v_provider_id                in pat_non_network_details.provider_id%type,
                           v_city_type_id               in pat_non_network_details.city_type_id%type,
                           v_state_type_id              in pat_non_network_details.state_type_id%type,
                           v_country_type_id            in pat_non_network_details.country_type_id%type,
                           v_provider_address           in pat_non_network_details.provider_address%type,
                           v_pincode                    in pat_non_network_details.pincode%type,
                           v_requested_amount           in pat_authorization_details.requested_amount%type,
                           v_benifit_type               in pat_authorization_details.benifit_type%type,
                           v_gravida                    in pat_authorization_details.gravida%type,
                           v_para                       in pat_authorization_details.para%type,
                           v_live                       in pat_authorization_details.live%type,
                           v_abortion                   in pat_authorization_details.abortion%type,
                           v_selection_type             in varchar2,--PAT,'ENH'--enhancement
                           v_currency_type              in pat_authorization_details.currency_type%type,
                           v_clinician_name             in pat_non_network_details.clinician_name%type,
                           v_ava_sum_insured            in pat_authorization_details.ava_sum_insured%type,
                          ---------------------------------------------------------------------------------
                           v_Oral_diagnosis            	in pat_authorization_details.Oral_diagnosis%type,
                           v_Oral_services              in pat_authorization_details.Oral_services%type,
                           v_Orala_Aproved_amount      	in pat_authorization_details.Orala_Aproved_amount%type,
                           v_Oral_diagnosis_revised       in pat_authorization_details.Oral_diagnosis_revised%type,
                           v_Oral_services_revised        in pat_authorization_details.Oral_services_revised%type,
                           v_Orala_Aproved_amount_revised in pat_authorization_details.Orala_Aproved_amount_revised%type,
                           v_Oral_system_Status			    in pat_authorization_details.Oral_system_Status%type,
                           ------------------------------------------------------------------------------
                           v_rows_processed             out number,
                           v_past_history               in pat_authorization_details.past_history%type:= null,
                           v_duration_above_illness              in pat_authorization_details.duration_above_illness%type,
                           v_duration_above_illness_time         in pat_authorization_details.duration_above_illness_time%type,
                           v_since_when                          in pat_authorization_details.since_when%type,
                           v_since_when_time                     in pat_authorization_details.since_when_time%type,
                           v_clinician_speciality    in pat_authorization_details.clinician_speciality%type:= null,
                           v_consultation_type       in pat_authorization_details.consultation_type%type:= null,
                           v_presenting_comp         IN pat_authorization_details.presenting_complaints%TYPE:= null,
                           v_provider_login          in varchar2:= null,
                           v_file_name               in varchar2:= null,
                           v_date_of_lmp             in pat_authorization_details.lmp_date%TYPE,
                           v_conception_type         in pat_authorization_details.conception_type%TYPE,
                           v_success_enh_yn          in pat_authorization_details.success_enh_yn%TYPE----NEWLY ADDED FOR PREAUTH ENHANCEMENT SUBMIT OR NOT
                           );
--=========================================================================================================                         

----barch level deleting the activities and diagnonsis details for the preatuh---
PROCEDURE delete_Daig_act_prev(v_code                 IN varchar2,
                               v_pat_auth_seq_id      IN app.pat_authorization_details.pat_auth_seq_id%type,
                               v_flag                 IN varchar2,
                               v_quantity             IN varchar2,
                               v_hosp_seq_id          IN Tpa_Hosp_Info.Hosp_Seq_Id%TYPE,
                               V_rows_processed       OUT NUMBER
                               );
--=======================================================================================================
--Calculate Pre-Authorization Amount
PROCEDURE calculate_authorization(v_pat_auth_seq_id            IN  pat_authorization_details.pat_auth_seq_id%type,
                                  v_hosp_seq_id                IN  pat_authorization_details.hosp_seq_id%TYPE,
                                  v_allowed_amount             OUT  pat_authorization_details.Tot_Allowed_Amount%TYPE,
                                  v_result_set                 OUT SYS_REFCURSOR,
                                  v_added_by                   IN  NUMBER
                                  );
--=========================================================================================================
PROCEDURE check_pat_approved(v_pat_auth_seq_id      IN pat_authorization_details.pat_auth_seq_id%TYPE,                      
                             v_added_by             IN NUMBER);
--======================================================================================================
PROCEDURE check_activity_limits (v_seq_id                 IN pat_authorization_details.pat_auth_seq_id%TYPE,
                                 v_mode                   IN VARCHAR2,
                                 v_allowed_amt            IN NUMBER,
                                 v_added_by               IN NUMBER,
                                 v_remarks                IN VARCHAR2,
                                 v_final_allowed_amount   OUT NUMBER);
--========================================================================================================
PROCEDURE save_shortfall_details (p_shortfall_seq_id      IN shortfall_details.shortfall_seq_id%TYPE,
                                  p_shortfall_file        IN shortfall_details.uploaded_file%TYPE,
                                  p_status                OUT VARCHAR2,
                                  p_added_by              IN shortfall_details.added_by%TYPE := NULL
                                 );
--========================================================================================================
PROCEDURE save_authorization(v_pat_auth_seq_id                 IN pat_authorization_details.Pat_Auth_Seq_Id%TYPE,
                             v_member_seq_id                   IN pat_authorization_details.member_seq_id%TYPE,
                             v_auth_number                     IN OUT pat_authorization_details.Auth_Number%TYPE,
                             v_admission_date                  IN pat_authorization_details.hospitalization_date%type,
                             v_allowed_amount                  IN pat_authorization_details.Tot_Allowed_Amount%TYPE,
                             v_source_type_id                  IN pat_authorization_details.source_type_id%TYPE,
                             v_pat_status_type_id              IN OUT pat_authorization_details.Pat_Status_Type_Id%TYPE,
                             v_medical_opinion_remarks         IN pat_authorization_details.medical_opinion_remarks%type,
                             v_added_by                        IN  NUMBER,
                             v_prov_yn                         IN  VARCHAR2,
                             v_rows_processed                  OUT NUMBER);
--====================================================================================================================
PROCEDURE select_activity_list (
    v_description              IN OUT tpa_activity_master_details.activity_description%TYPE,
    v_hosp_seq_id              IN NUMBER,
    v_sort_order               IN OUT VARCHAR2,
    v_start_num                IN OUT NUMBER  ,
    v_end_num                  IN OUT NUMBER  ,
    v_flag                     IN VARCHAR2,
    v_tpa_enrollment_id        IN VARCHAR2,
    v_result_set               OUT SYS_REFCURSOR
  );
--====================================================================================================================
PROCEDURE select_drug_list (
    v_description              IN OUT tpa_activity_master_details.activity_description%TYPE,
    v_sort_var                 IN OUT VARCHAR2 ,
    v_sort_order               IN OUT VARCHAR2,
    v_start_num                IN OUT NUMBER  ,
    v_end_num                  IN OUT NUMBER  ,
    v_flag                     IN VARCHAR2    ,
    v_tpa_enrollment           IN VARCHAR2,
    v_hosp_date                IN VARCHAR2,
    v_result_set               OUT SYS_REFCURSOR
  );
--======================================================================================================================
PROCEDURE select_clinician_list (
    v_clinician_id             IN OUT tpa_hosp_professionals.professional_id%TYPE,
    v_sort_var                 IN OUT VARCHAR2 ,
    v_sort_order               IN OUT VARCHAR2,
    v_start_num                IN OUT NUMBER  ,
    v_end_num                  IN OUT NUMBER  ,
    v_hosp_seq_id              IN VARCHAR2,
    v_tpa_enrollment_id        IN VARCHAR2:=NULL,
    v_result_set               OUT SYS_REFCURSOR
  );
--======================================================================================================================
PROCEDURE select_clinician_name_list (
    v_clinician_name           IN OUT tpa_hosp_professionals.contact_name%TYPE,
    v_sort_var                 IN OUT VARCHAR2 ,
    v_sort_order               IN OUT VARCHAR2,
    v_start_num                IN OUT NUMBER  ,
    v_end_num                  IN OUT NUMBER  ,
    v_hosp_seq_id              IN VARCHAR2,
    v_tpa_enrollment_id        IN VARCHAR2,
    v_result_set               OUT SYS_REFCURSOR
  );
--======================================================================================================================
PROCEDURE get_file_details (p_pat_seq_id IN MOU_DOCS_INFO1.PAT_SEQ_ID%TYPE,
                            p_result     OUT SYS_REFCURSOR
                           );
--================================================================================================
PROCEDURE get_shortfall_details (p_shortfall_seq_id IN shortfall_details.shortfall_seq_id%TYPE,
                                 p_resultset        OUT SYS_REFCURSOR
                                );
--============================================================================
PROCEDURE select_pbm_icd_list (
    v_icd_code                 IN OUT tpa_icd10_master_details.icd_code%TYPE,
    v_description              IN OUT tpa_icd10_master_details.long_desc%TYPE,
    v_search_flag              IN VARCHAR2,--CODE,DESC
    v_sort_var                 IN OUT VARCHAR2 ,
    v_sort_order               IN OUT VARCHAR2,
    v_start_num                IN OUT NUMBER  ,
    v_end_num                  IN OUT NUMBER  ,
    v_result_set               OUT SYS_REFCURSOR
  );
--===============================================================================
PROCEDURE select_pbm_drug_list (
    v_search_flag              IN VARCHAR2,--CODE,DESC,
    v_search_data              IN OUT VARCHAR2,
    v_sort_var                 IN OUT VARCHAR2 ,
    v_sort_order               IN OUT VARCHAR2,
    v_start_num                IN OUT NUMBER  ,
    v_end_num                  IN OUT NUMBER  ,
    v_result_set               OUT SYS_REFCURSOR
  );
--=================================================================================
PROCEDURE dental_event_number(v_tpa_enrollment_id          IN  app.tpa_enr_policy_member.tpa_enrollment_id%TYPE,
                              v_result                     OUT SYS_REFCURSOR);
 --=====================================================================================================
PROCEDURE dental_form_event(v_tpa_enrollment_id                  IN  PAT_ENROLL_DETAILS.tpa_enrollment_id%TYPE,
                            v_benefit_type                       IN  PAT_AUTHORIZATION_DETAILS.Benifit_Type%TYPE,                                     
                            v_hosp_seq_id                        IN  TPA_HOSP_INFO.HOSP_SEQ_ID%TYPE,
                            v_result_set                         OUT SYS_REFCURSOR
                           );
 --=================================================================================================================
PROCEDURE check_icd_benefit(p_icd_code                          IN VARCHAR2,
                            p_benefit_type                      IN PAT_AUTHORIZATION_DETAILS.BENIFIT_TYPE%TYPE,
                            p_result                            OUT VARCHAR2
                           );
 --==========================================================================================================================
 PROCEDURE save_appeal_remark(v_seq_id  IN PAT_AUTHORIZATION_DETAILS.PAT_AUTH_SEQ_ID%TYPE,
                             v_remark  IN OUT VARCHAR2
                            );
 --===================================================================================================================
END HOSP_DIAGNOSYS_PKG;

/

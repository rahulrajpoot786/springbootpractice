--------------------------------------------------------
--  DDL for Package Body AUTHENTICATION_PKG
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "VENUBABU"."AUTHENTICATION_PKG" IS

  -- Author  : SREERAJ_SV
  -- Created : 12/19/2005 4:41:07 PM
  -- Purpose : User validation.
  ---------------------------------------------------------------------------------------------------------------
  -- PROCEDURE for validating Users,
  ---------------------------------------------------------------------------------------------------------------

  PROCEDURE pr_user_validation(
    v_user_id        IN OUT tpa_login_info.user_id%TYPE,
    v_password       IN OUT tpa_login_info.password%TYPE,
    v_ip_address     IN tpa_login_info.ip_address%TYPE,  --Added for CR-KOC1235
    v_user_sec       OUT XMLTYPE
  )
  IS
    CURSOR cur_user IS
         SELECT A.contact_seq_id ,
                CASE WHEN B.tpa_office_seq_id IS NULL THEN ( CASE WHEN B.INS_SEQ_ID IS NULL THEN CASE WHEN B.HOSP_SEQ_ID IS NULL THEN B.group_reg_seq_id ELSE B.HOSP_SEQ_ID END ELSE B.INS_SEQ_ID END ) ELSE B.Tpa_Office_Seq_Id END AS contacttypeid,
                 B.user_general_type_id ,
                 B.primary_email_id,
                 B.mobile_no ,
                 A.active_yn,
                 B.prefix_general_type_id,
                 B.contact_name,
                 B.provide_access_user_yn,
                 B.contact_pa_limit ,
                 B.contact_claim_limit,
                 C.role_seq_id ,
                 D.role_name,
                 E.pa_allowed_yn,
                 E.Claim_Allowed_Yn,
                 E.tpa_office_seq_id,
                 E.office_name,
                 D.privilege,
                 A.user_id,
                 NVL2(a.PASSWORD_GENERATED_DATE,'N','Y') show_password_alert -- added for CR-KOC1060.
          FROM tpa_login_info A INNER  JOIN tpa_user_contacts B ON (A.contact_seq_id = B.contact_seq_id AND A.user_id = v_user_id AND A.active_yn = 'Y')
               INNER JOIN tpa_user_roles C ON A.contact_seq_id = C.contact_seq_id
               INNER JOIN tpa_roles_code D ON C.role_seq_id  = D.role_seq_id
               LEFT OUTER JOIN tpa_office_info E ON B.tpa_office_seq_id = E.tpa_office_seq_id;

--Added for CR-KOC1235
    CURSOR alert_days IS
           SELECT trunc(n.password_generated_date)+a.password_valid_days ALERT_END_DATE,
           trunc(n.password_generated_date)+a.password_valid_days-a.alert_days+1 ALERT_START_DATE,
           a.alert_days
           FROM password_config a,tpa_login_info n
           , tpa_user_contacts b
           WHERE n.contact_seq_id=b.contact_seq_id
           AND A.CONFIG_TYPE='TTK'  --KOC1257
           AND  n.active_yn='Y' AND b.user_general_type_id IN ('TTK','DMC','CAL') AND n.user_id=v_user_id;


    CURSOR get_password_cur IS
        SELECT password,wrong_attempts  --Added for CR-KOC1235
        FROM tpa_login_info
        WHERE user_id = v_user_id AND active_yn= 'Y';
        
    CURSOR APP_USER_VALIDATION IS
      SELECT  U.USER_GENERAL_TYPE_ID AS APP_USER
      FROM TPA_USER_CONTACTS U
      join tpa_login_info l on (u.contact_seq_id=l.contact_seq_id)
      WHERE l.user_id=v_user_id;    

    v_rec_user cur_user%ROWTYPE;
    alert_days_rec        alert_days%ROWTYPE;  --Added for CR-KOC1235
    v_alert_end_date      date;      --Added for CR-KOC1235
    v_alert_start_date    date;      --Added for CR-KOC1235
    v_alert_days          varchar2(3);    --Added for CR-KOC1235
    v_pwd_alert           varchar2(250);    --Added for CR-KOC1235
    v_expiry_flag_YN      varchar2(1);    --Added for CR-KOC1235
    v_privilege           XMLTYPE;

    v_user_doc         DBMS_XMLDOM.DOMDocument;
    v_privilege_doc    DBMS_XMLDOM.DOMDocument;
    v_user_root_node   DBMS_XMLDOM.DOMNode;
    v_priv_root_node   DBMS_XMLDOM.DOMNode;
    v_wflow_node       DBMS_XMLDOM.DOMNode;
    v_role_node        DBMS_XMLDOM.DOMNode;
    v_group_node       DBMS_XMLDOM.DOMNode;
    v_elem             DBMS_XMLDOM.DOMElement;
    v_node             DBMS_XMLDOM.DOMNode;
    v_parent_node      DBMS_XMLDOM.DOMNODE;
    v_original_pwd                VARCHAR2(200);
    v_wrong_attempts              VARCHAR2(3);     --Added for CR-KOC1235
    v_config_wrong_attempts       VARCHAR2(3);     --Added for CR-KOC1235
    ip_address_log                VARCHAR2(200);  --Added for CR-KOC1235

    v_prev_workflow_seq_id tpa_workflow.workflow_seq_id%TYPE;
    V_USER           VARCHAR2(30);

  BEGIN

  OPEN APP_USER_VALIDATION;
    FETCH APP_USER_VALIDATION INTO V_USER;
      CLOSE APP_USER_VALIDATION ;  
      
  IF V_USER NOT IN ('TTK','CAL') THEN
    raise_application_error(-20426,'Invalid User Name/Password, Remember Login is Case-Sensitive...'); 
  END IF; 
  
    SELECT a.wrong_attempts INTO v_config_wrong_attempts from password_config a where a.config_seq_id=1;  --Added for CR-KOC1235

    OPEN get_password_cur;
    FETCH  get_password_cur INTO v_original_pwd,v_wrong_attempts;    --Added for CR-KOC1235
    CLOSE get_password_cur;

    IF (TO_NUMBER(v_wrong_attempts)>=TO_NUMBER(v_config_wrong_attempts)) THEN         --Added for CR-KOC1235
             raise_application_error(-20950,'Your account locked please contact Authorized person');
    ELSE

    IF NOT ttk_util_pkg.fn_decr_password(v_password,v_original_pwd) THEN
    
    
           IF v_wrong_attempts=(v_config_wrong_attempts-1) THEN            --Added for CR-KOC1235
           UPDATE tpa_login_info a SET a.accn_locked_yn='Y' WHERE a.user_id=v_user_id;  --Added for CR-KOC1235
    END IF;                              --Added for CR-KOC1235
           UPDATE tpa_login_info q SET q.wrong_attempts=nvl(q.wrong_attempts,0)+1      --Added for CR-KOC1235
            WHERE q.user_id=v_user_id;                     --Added for CR-KOC1235
    COMMIT;                              --Added for CR-KOC1235
       raise_application_error(-20048,'Invalid User Name/Password, Remember Login is Case-Sensitive...');
    END IF;
    END IF;
--Added for CR-KOC1235 **start**
    OPEN alert_days;
    FETCH alert_days INTO v_alert_end_date,v_alert_start_date,v_alert_days;
    CLOSE alert_days;

      IF (v_alert_days IS NOT NULL AND (trunc(SYSDATE) BETWEEN (v_alert_start_date-1) AND v_alert_end_date)) THEN
         SELECT NVL2(wc.password_valid_days,(CASE WHEN ((NVL(g.password_generated_date,g.added_date)+wc.password_valid_days)>=SYSDATE) THEN 'Y'
                                           ELSE 'N'  END),'N') expiry_flag_yn
                                           INTO v_expiry_flag_YN
         FROM tpa_login_info g,password_config wc where g.user_id=v_user_id and wc.config_seq_id='1';

              v_pwd_alert:='Your Password is about to expire in '||(v_alert_end_date-trunc(SYSDATE))||' days. Please change it now.';
         ELSE v_pwd_alert:=NULL;

      END IF;

           SELECT a.ip_address INTO ip_address_log FROM tpa_login_info a WHERE a.user_id=v_user_id;

        IF(ip_address_log IS NOT NULL and (v_ip_address !=ip_address_log )) THEN
          raise_application_error(-20951,'user already logged on');
        END IF;

--Added for CR-KOC1235  ** end**

    OPEN  cur_user ;
    FETCH cur_user INTO v_rec_user;
    CLOSE   cur_user;

    IF ( v_rec_user.active_yn != 'Y' ) THEN
       raise_application_error(-20049,'User is not active ....');
    END IF;

    v_user_doc := dbms_xmldom.newDOMDocument;
    dbms_xmldom.setVersion( v_user_doc, '1.0' );
    v_user_root_node := dbms_xmldom.makeNode( v_user_doc);

    v_elem := dbms_xmldom.createElement( v_user_doc, 'usersecurityprofile' );
    v_node := dbms_xmldom.makeNode( v_elem );
    v_user_root_node := dbms_xmldom.appendChild( v_user_root_node, v_node );

    v_elem := dbms_xmldom.createElement(v_user_doc, 'user');
    dbms_xmldom.setAttribute(v_elem,'name',v_rec_user.contact_name);
    dbms_xmldom.setAttribute(v_elem,'contactseqid',v_rec_user.contact_seq_id);
    dbms_xmldom.setAttribute(v_elem,'usertype',v_rec_user.user_general_type_id);
    dbms_xmldom.setAttribute(v_elem,'active',v_rec_user.active_yn);
    dbms_xmldom.setAttribute(v_elem,'contacttypeid',v_rec_user.contacttypeid);
    dbms_xmldom.setAttribute(v_elem,'branchid',v_rec_user.tpa_office_seq_id);
    dbms_xmldom.setAttribute(v_elem,'branchname',v_rec_user.office_name);
    dbms_xmldom.setAttribute(v_elem,'userid',v_rec_user.user_id);
    dbms_xmldom.setAttribute(v_elem,'logindate',to_char(SYSDATE,'DD/MM/YYYY'));
    dbms_xmldom.setAttribute(v_elem,'email',v_rec_user.primary_email_id);
    dbms_xmldom.setAttribute(v_elem,'mobile',v_rec_user.mobile_no);
    dbms_xmldom.setAttribute(v_elem,'showpwdalert',v_rec_user.show_password_alert);
    IF v_pwd_alert IS NOT NULL THEN dbms_xmldom.setAttribute(v_elem,'pwd_alert',v_pwd_alert);  --Added for CR-KOC1235
    END IF;                              --Added for CR-KOC1235
    dbms_xmldom.setAttribute(v_elem,'expiry_flag_YN',NVL(v_expiry_flag_YN,'N'));      --Added for CR-KOC1235

    v_node := dbms_xmldom.makeNode(v_elem);
    v_parent_node := dbms_xmldom.appendChild( v_user_root_node, v_node);

    v_elem := dbms_xmldom.createElement(v_user_doc, 'preauth');
    dbms_xmldom.setAttribute(v_elem,'processing',v_rec_user.pa_allowed_yn);
    dbms_xmldom.setAttribute(v_elem,'limit',v_rec_user.contact_pa_limit);
    v_node := dbms_xmldom.makeNode(v_elem);
    v_node := dbms_xmldom.appendChild( v_parent_node, v_node);

    v_elem := dbms_xmldom.createElement(v_user_doc, 'claim');
    dbms_xmldom.setAttribute(v_elem,'processing',v_rec_user.claim_allowed_yn);
    dbms_xmldom.setAttribute(v_elem,'limit',v_rec_user.contact_claim_limit);
    v_node := dbms_xmldom.makeNode(v_elem);
    v_node := dbms_xmldom.appendChild( v_parent_node, v_node);

    v_elem := dbms_xmldom.createElement(v_user_doc, 'role');
    dbms_xmldom.setAttribute(v_elem,'seqid',v_rec_user.role_seq_id);
    dbms_xmldom.setAttribute(v_elem,'name',v_rec_user.role_name);
    v_node := dbms_xmldom.makeNode(v_elem);
    v_role_node := dbms_xmldom.appendChild( v_parent_node, v_node);

    v_prev_workflow_seq_id := 0 ;
    FOR  rec_event IN  (SELECT a.role_seq_id,b.event_seq_id,b.event_name,c.workflow_seq_id,c.workflow_name
                          FROM tpa_event_role_assoc A INNER JOIN tpa_event B ON A.event_seq_id = B.event_seq_id
                               INNER JOIN tpa_workflow C ON B.workflow_seq_id = C.workflow_seq_id
                         WHERE A.role_seq_id = v_rec_user.role_seq_id
                        ORDER BY B.workflow_seq_id,B.order_number )
   LOOP
     IF ( v_prev_workflow_seq_id <> rec_event.workflow_seq_id ) THEN
       v_elem := dbms_xmldom.createElement(v_user_doc, 'workflow');
       dbms_xmldom.setAttribute(v_elem,'seqid',rec_event.workflow_seq_id);
       dbms_xmldom.setAttribute(v_elem,'name',rec_event.workflow_name);
       v_node := dbms_xmldom.makeNode(v_elem);
       v_wflow_node := dbms_xmldom.appendChild( v_role_node, v_node);
     END IF;

     v_elem := dbms_xmldom.createElement(v_user_doc, 'event');
     dbms_xmldom.setAttribute(v_elem,'seqid',rec_event.event_seq_id);
     dbms_xmldom.setAttribute(v_elem,'name',rec_event.event_name);
     v_node := dbms_xmldom.makeNode(v_elem);
     v_node := dbms_xmldom.appendChild( v_wflow_node, v_node);

     v_prev_workflow_seq_id := rec_event.workflow_seq_id;

   END LOOP;

    v_elem := dbms_xmldom.createElement(v_user_doc, 'groups');
    v_node := dbms_xmldom.makeNode(v_elem);
    v_group_node := dbms_xmldom.appendChild( v_parent_node, v_node);

   FOR rec_group IN ( SELECT H.group_branch_seq_id, I.group_name, H.tpa_office_seq_id,J.product_seq_id
                        FROM tpa_group_user_assoc G INNER JOIN tpa_group_branch H ON G.group_branch_seq_id = H.group_branch_seq_id
                        INNER JOIN tpa_groups I ON H.group_seq_id = I.group_seq_id
                        LEFT OUTER JOIN tpa_ins_prod_policy J ON I.prod_policy_seq_id = J.prod_policy_seq_id
                        WHERE contact_seq_id = v_rec_user.contact_seq_id)
   LOOP

     v_elem := dbms_xmldom.createElement(v_user_doc, 'group');
     dbms_xmldom.setAttribute(v_elem,'seqid',rec_group.group_branch_seq_id );
     dbms_xmldom.setAttribute(v_elem,'name',rec_group.group_name );
     dbms_xmldom.setAttribute(v_elem,'productseqid',rec_group.product_seq_id );
     dbms_xmldom.setAttribute(v_elem,'branchid',rec_group.tpa_office_seq_id );

     v_node := dbms_xmldom.makeNode(v_elem);
     v_node := dbms_xmldom.appendChild( v_group_node, v_node);

   END LOOP;

    v_privilege := v_rec_user.privilege;
    v_privilege_doc := DBMS_XMLDOM.newDOMDocument(v_privilege);
    v_priv_root_node := DBMS_XMLDOM.makeNode(DBMS_XMLDOM.getDocumentElement((v_privilege_doc)));

    v_priv_root_node := dbms_xmldom.importNode(v_user_doc,v_priv_root_node,TRUE);
    v_user_root_node := dbms_xmldom.appendChild(v_user_root_node,v_priv_root_node);
    --dbms_xmldom.writeToBuffer(v_user_root_node, v_buf);
    --dbms_output.put_line('First :'||v_buf);
    v_user_sec := dbms_xmldom.getxmltype(v_user_doc);

   IF v_ip_address LIKE '192.%' /*OR v_ip_address LIKE '10.100.%'*/--modified for VPN users(04/04/2013)-sadiq
      THEN
      UPDATE TPA_LOGIN_INFO G
      SET G.IP_ADDRESS=NULL WHERE G.USER_ID=v_user_id;
      ELSE UPDATE TPA_LOGIN_INFO F
      SET F.IP_ADDRESS=v_ip_address WHERE F.USER_ID=v_user_id;
      COMMIT;
    END IF;

  UPDATE tpa_login_info h SET         --Added for CR-KOC1235
            h.recent_login_date=SYSDATE,      --Added for CR-KOC1235
            h.wrong_attempts=NULL/*,        --Added for CR-KOC1235
            h.ip_address=v_ip_address*/      --Added for CR-KOC1235
      WHERE  h.user_id=v_user_id;        --Added for CR-KOC1235
  COMMIT;
    --INSERT INTO xml_temp VALUES( v_user_sec );
          INSERT INTO tpa_user_login_history(login_seq_id,user_id,login_date)  --Added for CR-KOC1233
          VALUES(tpa_user_login_history_seq.nextval,v_user_id,SYSDATE);
          COMMIT;
    dbms_xmldom.freeDocument(v_user_doc);
    dbms_xmldom.freeDocument(v_privilege_doc);  --SREERAJ TODO
  END pr_user_validation;

--=========================================================================================================
  /*
 Created By :
 Created Date:
 Modified by:   Nagaraj A.H, SPAN Infotech.
 Modified Date: 12/05/2011 8:40:16 AM
 Description: This procedure is modified to store the user login History, password related alerts, first login date etc.
*/
--=========================================================================================================


PROCEDURE pr_external_user_validation(
    v_user_id        IN tpa_login_info.user_id%TYPE,
    v_password       IN tpa_login_info.password%TYPE,
    v_in_policy_number  IN tpa_enr_policy.policy_number%TYPE,
    v_in_enrollment_id  IN tpa_enr_policy_member.tpa_enrollment_id%TYPE,
    v_group_id       IN tpa_group_registration.group_id%TYPE,
    v_login_type     IN CHAR, -- OIN FOR INDIVIDUAL, OCO - EMPLOYEE means CORPORATE , OHR FOR HR, OIU FOR INSURANCE ,OCI --  CITI BANK ,HOS --HOSPITAL LOGIN,OBR --broker,PTR --PARTNER
    v_user_sec       OUT XMLTYPE,
    v_certificate_no IN tpa_enr_policy_group.certificate_no%TYPE := NULL,
    v_expiry_flag_YN OUT CHAR,
    V_PWD_ALERT      OUT VARCHAR2, --KOC1257
    V_FIRST_LOGIN_YN OUT VARCHAR2,  --KOC1257
    V_random_num     OUT tpa_enr_policy_group.random_num%TYPE,   --koc1349
    v_ip_address     IN tpa_login_info.ip_address%TYPE,
    v_hosp_catagory  IN tpa_hosp_info.hosp_catagory%TYPE,
    v_DateOfBath     IN VARCHAR2:=NULL --CR-0378

  )
  IS
    v_privilege          XMLTYPE;
    --v_hosp_xml       XMLTYPE;
    
    v_user_doc         DBMS_XMLDOM.DOMDocument;
    v_privilege_doc    DBMS_XMLDOM.DOMDocument;
    v_user_root_node   DBMS_XMLDOM.DOMNode;
    v_priv_root_node   DBMS_XMLDOM.DOMNode;
    v_wflow_node       DBMS_XMLDOM.DOMNode;
    v_role_node        DBMS_XMLDOM.DOMNode;
    v_group_node       DBMS_XMLDOM.DOMNode;
    v_elem             DBMS_XMLDOM.DOMElement;
    v_node             DBMS_XMLDOM.DOMNode;
    v_parent_node      DBMS_XMLDOM.DOMNODE;
    v_original_pwd     VARCHAR2(200);
    v_employee_no            tpa_enr_policy_group.employee_no%TYPE;
    v_policy_group_seq_id    tpa_enr_policy_group.policy_group_seq_id%TYPE;
    v_template_id            tpa_policy_templates.template_id%TYPE;
    v_template_name          tpa_policy_templates.template_name%TYPE;
    v_pwd_general_type_id    weblogin_config.pwd_general_type_id%TYPE;
    v_tpa_enrol_nbr          tpa_enr_policy_group.tpa_enrollment_number%TYPE;
    v_policy_seq_id          tpa_enr_policy.policy_seq_id%TYPE;
    v_int_access_type_id     weblogin_config.intimation_access_gen_type_id%TYPE;
    v_online_ass_type_id     weblogin_config.online_assistance_gen_type_id%TYPE;
    v_wellness_login_type_id weblogin_config.wellness_login_type_id%TYPE; --KOC1349
    v_online_rate_type_id    weblogin_config.online_rating_gen_type_id%TYPE;
    v_product_seq_id         tpa_enr_policy.product_seq_id%TYPE;
    v_enrol_type_id          tpa_enr_policy.enrol_type_id%type;
    v_policy_number          tpa_enr_policy.policy_number%TYPE;
    v_enrollment_id          tpa_enr_policy_member.tpa_enrollment_id%TYPE;
    v_frst_pwd_alrt          CHAR(1);
    v_ins_hr_cnt_seqid       tpa_login_info.contact_seq_id%TYPE:=NULL;
    v_first_login_date       tpa_enr_policy_group.first_login_date%TYPE:=NULL;--FOR KOC1091CR
    v_first_login_window_period tpa_enr_policy_group.first_login_window_period%TYPE;--FOR KOC1091CR
  v_empanel_status            tpa_hosp_empanel_status.empanel_status_type_id%TYPE;

    
    CURSOR cr_emp IS --MODIFIED IN KOC1059 CR
           SELECT B.employee_password ,
                  B.insured_name ,
                  b.employee_no ,
                  b.policy_group_seq_id ,
                  nvl(e.code_type,d.pwd_general_type_id) AS pwd_general_type_id,
                  b.tpa_enrollment_number,
                  a.policy_seq_id,
                  d.intimation_access_gen_type_id,
                  d.online_assistance_gen_type_id,
                  d.online_rating_gen_type_id,
                  NVL2(B.password_generated_date,'N','Y') show_password_alert,
                  b.first_login_date,--FOR KOC1091 CR
                  d.first_login_window_period,--FOR KOC1091 CR
                  nvl(B.wrong_attempts,0)  wrong_attempts, --KOC1257
                  NVL(D.WRONG_ATTEMPTS,5) CONFIG_WRONG_ATTEMPTS, --KOC1257
                  NVL(B.ACCN_LOCKED_YN,'N') ACCN_LOCKED_YN, --KOC1257
                  nvl(b.FIRST_LOGIN_YN,'Y') FIRST_LOGIN_YN, --KOC1257
                  d.wellness_login_type_id

      FROM tpa_enr_policy A
           INNER JOIN tpa_enr_policy_group B ON A.policy_seq_id = B.policy_seq_id
           INNER JOIN tpa_group_registration C ON A.group_reg_seq_id = C.group_reg_seq_id
           LEFT OUTER JOIN weblogin_config d ON (a.policy_seq_id = d.policy_seq_id)
           LEFT OUTER JOIN tpa_enr_customize_pwd e ON (b.policy_group_seq_id = e.policy_group_seq_id)
      WHERE A.policy_number = v_policy_number
           AND C.group_id = UPPER(v_group_id)
           AND a.completed_yn = 'Y'
           AND A.deleted_yn = 'N'
           AND B.deleted_yn = 'N'
           AND A.policy_status_general_type_id != 'POC'
           AND B.employee_user_id = v_user_id  ;

    CURSOR cur_user IS
       SELECT privilege FROM tpa_roles_code
        WHERE role_name  = 'EXTERNAL' ;

     CURSOR cur_hr IS  SELECT privilege
         FROM tpa_login_info A JOIN tpa_user_roles B ON(A.Contact_Seq_Id=B.Contact_Seq_Id)
         JOIN tpa_roles_code C ON(B.Role_Seq_Id=C.Role_Seq_Id)
        WHERE A.User_Id = v_user_id ;

    CURSOR cur_contact IS SELECT A.contact_seq_id, ttk_util_pkg.fn_decrypt(c.primary_email_id) as tpalogin
        FROM tpa_login_info A
        , tpa_user_contacts c
        WHERE c.contact_seq_id = a.contact_seq_id
        AND A.user_id=v_user_id AND A.active_yn='Y';

     CURSOR cur_mem IS --Modified IN KOC1053 CR
     SELECT C.mem_name,C.member_seq_id,B.policy_group_seq_id,A.product_seq_id,a.enrol_type_id
        FROM tpa_enr_policy A
        INNER JOIN tpa_enr_policy_group B ON ( A.policy_seq_id = B.Policy_Seq_Id )
        INNER JOIN tpa_enr_policy_member C ON (B.policy_group_seq_id = C.Policy_Group_Seq_Id)
       WHERE (C.tpa_enrollment_id =  v_enrollment_id OR A.policy_number =  v_policy_number)
             AND a.completed_yn = 'Y'
             AND A.deleted_yn = 'N'
             AND C.deleted_yn = 'N'
             and b.deleted_yn='N'
             AND A.Policy_Status_General_Type_Id != 'POC'
             AND c.status_general_type_id != 'POC'
       order by a.effective_from_date desc;

     CURSOR ncr_cur_mem IS SELECT C.mem_name,C.member_seq_id,B.policy_group_seq_id,A.product_seq_id
        FROM tpa_enr_policy A  JOIN tpa_enr_policy_group B ON ( A.policy_seq_id = B.Policy_Seq_Id )
        JOIN tpa_enr_policy_member C ON (B.policy_group_seq_id = C.Policy_Group_Seq_Id)
        WHERE C.tpa_enrollment_id =  v_enrollment_id AND A.Ins_Scheme =  v_policy_number AND b.certificate_no = v_certificate_no AND a.completed_yn = 'Y'
        AND A.deleted_yn = 'N' AND C.deleted_yn = 'N' AND A.Policy_Status_General_Type_Id != 'POC' AND c.status_general_type_id != 'POC';

     CURSOR get_password_cur IS  --MODIFIED IN KOC1059 CR
        SELECT A.password,
               B.CONTACT_NAME,
               NVL2(A.PASSWORD_GENERATED_DATE,'N','Y') SHOW_PASSWORD_ALERT,
               a.contact_seq_id,
               nvl(a.wrong_attempts,0) wrong_attempts,  --KOC1257
               NVL(A.ACCN_LOCKED_YN,'N') ACCN_LOCKED_YN, --KOC1257
               NVL(a.FIRST_LOGIN_YN,'Y') FIRST_LOGIN_YN --KOC1257
          FROM tpa_login_info A
              INNER JOIN tpa_user_contacts B ON(A.contact_seq_id=B.contact_seq_id)
              INNER JOIN tpa_group_registration c ON (b.group_reg_seq_id = c.group_reg_seq_id)
          WHERE A.user_id = v_user_id
              AND A.active_yn= 'Y'
              AND c.group_id = UPPER(v_group_id);

     CURSOR get_bro_cur IS  --MODIFIED IN KOC1059 CR
        SELECT A.password,
               B.CONTACT_NAME,
               NVL2(A.PASSWORD_GENERATED_DATE,'N','Y') SHOW_PASSWORD_ALERT,
               a.contact_seq_id,
               nvl(a.wrong_attempts,0) wrong_attempts,  --KOC1257
               NVL(A.ACCN_LOCKED_YN,'N') ACCN_LOCKED_YN, --KOC1257
               NVL(a.FIRST_LOGIN_YN,'Y') FIRST_LOGIN_YN --KOC1257
          FROM tpa_login_info A
              INNER JOIN tpa_user_contacts B ON(A.contact_seq_id=B.contact_seq_id)
              INNER JOIN TPA_BRO_INFO i on (i.ins_seq_id=b.ins_seq_id)
          WHERE A.user_id = v_user_id
             AND i.ins_comp_code_number =UPPER(v_group_id)
              AND A.active_yn= 'Y';

      CURSOR get_ins_password_cur IS  --MODIFIED IN KOC1059 CR
        SELECT A.password,
               B.CONTACT_NAME,
               NVL2(A.PASSWORD_GENERATED_DATE,'N','Y') SHOW_PASSWORD_ALERT,
               A.Contact_Seq_Id,
               nvl(a.wrong_attempts,0) wrong_attempts, --KOC1257
               NVL(A.ACCN_LOCKED_YN,'N') ACCN_LOCKED_YN, --KOC1257
               NVL(a.FIRST_LOGIN_YN,'Y') FIRST_LOGIN_YN, --KOC1257
               C.INS_COMP_NAME
          FROM tpa_login_info A
               INNER JOIN tpa_user_contacts B ON(A.contact_seq_id=B.contact_seq_id)
               INNER JOIN tpa_ins_info C ON(B.ins_seq_id=C.ins_seq_id)
          WHERE A.user_id = v_user_id
               AND A.active_yn= 'Y'
               AND C.Ins_Comp_Code_Number=UPPER(v_group_id);

      CURSOR cur_hr_groupname_cur IS
        SELECT G.group_name
        FROM tpa_group_registration G
        JOIN tpa_user_contacts C ON(G.group_reg_seq_id=C.group_reg_seq_id)
        JOIN tpa_login_info L ON(C.contact_seq_id=L.contact_seq_id)
        WHERE L.user_id=v_user_id;

      CURSOR cur_emp_groupname_cur IS
        SELECT G.group_name
        FROM tpa_group_registration G JOIN tpa_enr_policy P ON(G.group_reg_seq_id=P.group_reg_seq_id)
        WHERE P.Policy_Number=v_policy_number;

          --KOC1257

       CURSOR alert_days(v_user_id varchar2,v_config_type varchar2) IS
           SELECT trunc(n.password_generated_date)+a.password_valid_days ALERT_END_DATE,
           trunc(n.password_generated_date)+a.password_valid_days-a.alert_days+1 ALERT_START_DATE,
           a.alert_days
           FROM password_config a , tpa_login_info n
           , tpa_user_contacts b
           where  (n.contact_seq_id=b.contact_seq_id)
           AND  n.active_yn='Y' AND b.user_general_type_id IN ('COR','INS')
           AND n.user_id=v_user_id and a.config_type=v_config_type;


           CURSOR alert_days_cor(v_policy_group_seq_id number) IS
           SELECT trunc(n.password_generated_date)+a.password_validITY ALERT_END_DATE,
           trunc(n.password_generated_date)+a.password_validITY-a.show_aLlert_days+1 ALERT_START_DATE,
           a.show_aLlert_days
           FROM weblogin_config a,tpa_enr_policy_group n
           where a.policy_seq_id=n.policy_seq_id
           and n.policy_group_seq_id=v_policy_group_seq_id;
                 

           CURSOR WRONG_ATTEMPTS(V_CONFIG_TYPE VARCHAR2) IS
           SELECT a.wrong_attempts
           from app.Password_Config A WHERE CONFIG_TYPE=V_CONFIG_TYPE;

           CURSOR cur_bro_comp_name IS
             SELECT distinct bi.ins_comp_name,bi.ins_comp_code_number
                FROM tpa_login_info Aa JOIN tpa_user_contacts a ON (aa.contact_seq_id = a.contact_seq_id)
                LEFT OUTER JOIN app.tpa_group_user_assoc ua on ( ua.contact_seq_id=aa.contact_seq_id )
                LEFT OUTER JOIN app.tpa_bro_info bi on a.ins_seq_id=bi.ins_seq_id
                WHERE (aa.user_id = v_user_id);
           CURSOR cur_ins_user_last_login IS
            select max(h.login_date)
            from app.tpa_user_login_history h
            where h.login_date not in
            (select max(h.login_date)
             from app.tpa_user_login_history h
             where h.user_id = v_user_id/*'SASA77549'*/);
     

           CURSOR get_hosp_password_cur IS  --MODIFIED IN KOC1059 CR
         SELECT A.password,
               B.CONTACT_NAME,
               c.hosp_seq_id,
               c.hosp_name,
               c.empanel_number,
               f.COUNTRY_name as hospcountry ,
              H.STATE_NAME,
              I.CITY_DESCRIPTION,
               E.address_1||E.address_2||E.address_3  as hospaddress ,
               c.OFF_PHONE_NO_1 as hospphone,
               PROVIDER_TYPE_ID as hospitalType,
               NVL2(A.PASSWORD_GENERATED_DATE,'N','Y') SHOW_PASSWORD_ALERT,
               nvl(a.wrong_attempts,0) wrong_attempts,  
               NVL(A.ACCN_LOCKED_YN,'N') ACCN_LOCKED_YN,
               NVL(a.FIRST_LOGIN_YN,'Y') FIRST_LOGIN_YN,
               A.CONTACT_SEQ_ID,d.empanel_status_type_id,
               c.biometric_yn
               FROM tpa_login_info A
              INNER JOIN tpa_user_contacts B ON(A.contact_seq_id=B.contact_seq_id)
              --LEFT OUTER JOIN tpa_hosp_info c ON (b.provider_id = c.hosp_licenc_numb)
              LEFT OUTER JOIN tpa_hosp_info c ON (b.hosp_seq_id = c.hosp_seq_id)
              LEFT OUTER JOIN tpa_hosp_empanel_status d ON(c.hosp_seq_id=d.hosp_seq_id)
              LEFT OUTER JOIN tpa_hosp_address e on(c.hosp_seq_id=e.hosp_seq_id)
              LEFT OUTER JOIN tpa_country_code f on(e.COUNTRY_ID=f.COUNTRY_ID)
             LEFT OUTER JOIN tpa_state_code H ON ( e.state_type_id = h.state_type_id )
              LEFT OUTER JOIN tpa_city_code I ON ( e.city_type_id = i.city_type_id )
              
              WHERE A.user_id = v_user_id --AND c.hosp_catagory = v_hosp_catagory
              AND A.active_yn= 'Y'
              and c.empanel_number=upper(v_group_id) --commented for provider register details before empaneled 
              and d.empanel_status_type_id IN ('EMP');
              
              
              ----------***********NEWLY ADDED FOR PARTNER*********-------------------------
          
			
			  CURSOR get_ptnr_password_cur IS  
             SELECT A.password,
               B.CONTACT_NAME,
               c.PTNR_SEQ_ID,
               c.PARTNER_NAME,
               c.empanel_number,
               f.COUNTRY_name as ptnrcountry ,
               H.STATE_NAME,
               I.CITY_DESCRIPTION,
               E.address_1||E.address_2||E.address_3  as ptnraddress ,
               c.OFF_PHONE_NO_1 as ptnrphone,
               NVL2(A.PASSWORD_GENERATED_DATE,'N','Y') SHOW_PASSWORD_ALERT,
               nvl(a.wrong_attempts,0) wrong_attempts,  
               NVL(A.ACCN_LOCKED_YN,'N') ACCN_LOCKED_YN,
               NVL(a.FIRST_LOGIN_YN,'Y') FIRST_LOGIN_YN,
               A.CONTACT_SEQ_ID,d.empanel_status_type_id
               FROM tpa_login_info A
              INNER JOIN tpa_user_contacts B ON(A.contact_seq_id=B.contact_seq_id)
              LEFT OUTER JOIN TPA_PARTNER_INFO c ON (b.PTNR_SEQ_ID = c.PTNR_SEQ_ID)
              LEFT OUTER JOIN TPA_PARTNER_EMPANEL_STATUS d ON(c.PTNR_SEQ_ID=d.PTNR_SEQ_ID)
              LEFT OUTER JOIN tpa_PARTNER_address e on(c.PTNR_SEQ_ID=e.PTNR_SEQ_ID)
              LEFT OUTER JOIN tpa_country_code f on(e.COUNTRY_ID=f.COUNTRY_ID)
             LEFT OUTER JOIN tpa_state_code H ON ( e.state_type_id = h.state_type_id )
              LEFT OUTER JOIN tpa_city_code I ON ( e.city_type_id = i.city_type_id )
          WHERE A.user_id = v_user_id 
              AND A.active_yn= 'Y'
              and c.empanel_number=upper(v_group_id) 
              and d.empanel_status_type_id IN ('EMP');
             
           CURSOR cr_emp_empl(v_enrollment_id_empl varchar2) IS --created CR-0197
           SELECT B.employee_password ,
                  B.insured_name ,
                  b.employee_no ,
                  b.policy_group_seq_id ,
                  nvl(e.code_type,d.pwd_general_type_id) AS pwd_general_type_id,
                  b.tpa_enrollment_number,
                  a.policy_seq_id,
                  d.intimation_access_gen_type_id,
                  d.online_assistance_gen_type_id,
                  d.online_rating_gen_type_id,
                  NVL2(B.password_generated_date,'N','Y') show_password_alert,
                  b.first_login_date,
                  d.first_login_window_period,
                  nvl(B.wrong_attempts,0)  wrong_attempts, 
                  NVL(D.WRONG_ATTEMPTS,5) CONFIG_WRONG_ATTEMPTS,
                  NVL(B.ACCN_LOCKED_YN,'N') ACCN_LOCKED_YN, 
                  nvl(b.FIRST_LOGIN_YN,'Y') FIRST_LOGIN_YN,
                  d.wellness_login_type_id,
                  B.EMPLOYEE_USER_ID,
                  A.POLICY_NUMBER,
                  C.GROUP_ID,
                  f.mem_dob

      FROM tpa_enr_policy A
           INNER JOIN tpa_enr_policy_group B ON A.policy_seq_id = B.policy_seq_id
           INNER JOIN tpa_group_registration C ON A.group_reg_seq_id = C.group_reg_seq_id
           LEFT OUTER JOIN weblogin_config d ON (a.policy_seq_id = d.policy_seq_id)
           LEFT OUTER JOIN tpa_enr_customize_pwd e ON (b.policy_group_seq_id = e.policy_group_seq_id)
           JOIN tpa_enr_policy_member F ON(F.POLICY_GROUP_SEQ_ID=B.POLICY_GROUP_SEQ_ID)
      WHERE --A.policy_number = v_policy_number
           --AND C.group_id = UPPER(v_group_id)
           F.TPA_ENROLLMENT_ID=v_enrollment_id_empl
           AND a.completed_yn = 'Y'
           AND A.deleted_yn = 'N'
           AND B.deleted_yn = 'N'
           AND A.policy_status_general_type_id != 'POC'
           and F.Relship_Type_Id = 'NSF'
           /*and a.prev_policy_seq_id is null;*/
           ORDER BY B.POLICY_GROUP_SEQ_ID DESC;
           
           --AND B.employee_user_id = v_user_id  ;
           
            CURSOR cur_emp_groupname_empl_cur(v_policy_seq_id_empl number) IS  ----created CR-0197
        SELECT G.group_name
        FROM tpa_group_registration G JOIN tpa_enr_policy P ON(G.group_reg_seq_id=P.group_reg_seq_id)
        WHERE P.POLICY_SEQ_ID=v_policy_seq_id_empl;
                      
        CURSOR cur_user_empl IS ----created CR-0197
       SELECT privilege FROM tpa_roles_code
        WHERE role_name  = 'MEMEXTERNAL' ;
----------------------------------------------------------------------------

      alert_days_rec        alert_days%ROWTYPE;
      v_alert_end_date      date;
      v_alert_start_date    date;
      v_alert_days          varchar2(3);
      v_wrong_attempts       VARCHAR2(3);
      v_config_wrong_attempts VARCHAR2(3);
      V_ACCN_LOCKED_YN      VARCHAR2(2);
     ip_address_log                VARCHAR2(200);  --Added for CR-kocbroker

          --KOC1257

      v_rec_user            cur_user%ROWTYPE;
      v_rec_hr              cur_hr%ROWTYPE;
      v_rec_contact         cur_contact%ROWTYPE;
      v_user_name           VARCHAR2(60);
      v_mem_seq_id          tpa_enr_policy_member.member_seq_id%TYPE;
      v_group_name          tpa_group_registration.group_name%TYPE;
      v_hosp_seq_id         tpa_hosp_info.hosp_seq_id%type;
      v_ptnr_seq_id         tpa_partner_info.ptnr_seq_id%type;
      v_hosp_name           tpa_hosp_info.hosp_name%type;
      v_partner_name        tpa_partner_info.partner_name%TYPE;
      v_empanel_number      tpa_hosp_info.empanel_number%type;
      --added newly for PBMFIXES
      v_COUNTRY_name        tpa_country_code.COUNTRY_name%type;--added newly for PBMFIXES
      V_emirate             tpa_state_code.STATE_NAME%TYPE;
      V_area                tpa_city_code.CITY_DESCRIPTION%TYPE;
      v_ADDRESS_1           tpa_hosp_address.ADDRESS_1%type;
      v_hospitalType        tpa_hosp_info.PROVIDER_TYPE_ID%type;
      v_ptr_empanel_number  tpa_partner_info.empanel_number%type;--NEWLY ADDED  FOR PATRNER
      v_country_name_ptr    tpa_country_code.COUNTRY_name%type;--NEWLY ADDED  FOR PATRNER
      v_emirate_ptr         tpa_state_code.STATE_NAME%TYPE;--NEWLY ADDED  FOR PATRNER
      V_area_ptr            tpa_city_code.CITY_DESCRIPTION%TYPE;--NEWLY ADDED  FOR PATRNER
      v_address_1_ptr       tpa_partner_address.ADDRESS_1%type;--NEWLY ADDED  FOR PATRNER
      v_off_phone_no_1_ptr  tpa_partner_info.OFF_PHONE_NO_1%type;--NEWLY ADDED  FOR PATRNER
      v_OFF_PHONE_NO_1      tpa_hosp_info.OFF_PHONE_NO_1%type;
      v_hosp_contact_seq_id tpa_login_info.contact_seq_id%type;
      v_ptnr_contact_seq_id tpa_login_info.contact_seq_id%TYPE;--NEWLY ADDED  FOR PATRNER
      v_ins_comp_name       tpa_ins_info.ins_comp_name%type;--added newly
      v_last_login_date     tpa_user_login_history.login_date%type;--added newly
      v_broker_code         tpa_bro_info.ins_comp_code_number%type;--added newly
      v_bio_metric_yn       VARCHAR2(10);---Added For Provider Biometric
      v_empl_user_id        app.tpa_enr_policy_group.employee_user_id%type;
      v_empl_polno          app.tpa_enr_policy.policy_number%type;
      v_empl_group          app.tpa_group_registration.group_id%type;
      v_mem_dob             app.tpa_enr_policy_member.mem_dob%TYPE;
      
    BEGIN

    v_policy_number:=upper(TRIM(v_in_policy_number));
    v_enrollment_id:=upper(TRIM(v_in_enrollment_id));
    v_expiry_flag_YN:='N';

      IF v_login_type = 'OIN' THEN
        OPEN cur_mem ;
        FETCH cur_mem INTO v_user_name, v_mem_seq_id,v_policy_group_seq_id,v_product_seq_id,v_enrol_type_id;
        CLOSE cur_mem ;

        IF ((v_enrol_type_id NOT IN ('IND','ING') OR v_enrol_type_id IS NULL) AND v_policy_number IS NOT NULL) THEN
           raise_application_error(-20784,'Please enter valid Individual/Individual as Group Policy Number');
        ELSIF v_mem_seq_id IS NULL THEN--ADDED IN KOC1053 CR
         raise_application_error(-20785,'Please enter the correct Enrollment Id');
        END IF;

      ELSIF v_login_type = 'OCO' /*OR v_login_type = 'EMPL'*/ THEN

        OPEN  cr_emp ;
        FETCH cr_emp INTO v_original_pwd, v_user_name , v_employee_no, v_policy_group_seq_id ,v_pwd_general_type_id,v_tpa_enrol_nbr,v_policy_seq_id,v_int_access_type_id,v_online_ass_type_id,v_online_rate_type_id,v_frst_pwd_alrt,v_first_login_date,v_first_login_window_period,
        v_wrong_attempts,v_config_wrong_attempts,V_ACCN_LOCKED_YN,V_FIRST_LOGIN_YN,v_wellness_login_type_id; --KOC1257
        CLOSE cr_emp;

       --KOC1257

    IF v_user_name IS NULL OR NOT ttk_util_pkg.emp_auth(v_original_pwd,v_password, v_pwd_general_type_id,v_employee_no, v_policy_group_seq_id,v_user_name ) OR  V_ACCN_LOCKED_YN='Y' THEN

    IF (to_number(v_wrong_attempts)>=NVL(to_number(v_config_wrong_attempts),5) ) THEN
             raise_application_error(-20950,'Your account locked please contact Authorized person');
    ELSE

      IF v_wrong_attempts=(NVL(v_config_wrong_attempts,5)-1) THEN
      UPDATE tpa_enr_policy_group a SET a.accn_locked_yn='Y' WHERE a.policy_group_seq_id=v_policy_group_seq_id;
    END IF;
      UPDATE tpa_enr_policy_group q SET q.wrong_attempts=nvl(q.wrong_attempts,0)+1
      WHERE q.policy_group_seq_id=v_policy_group_seq_id;
    COMMIT;

    raise_application_error(-20048,'Invalid User Name/Password, Remember Login is Case-Sensitive...');
    END IF;
    END IF;

    OPEN alert_days_cor(v_policy_group_seq_id);
    FETCH alert_days_cor INTO v_alert_end_date,v_alert_start_date,v_alert_days;
    CLOSE alert_days_cor;



    IF (v_alert_days IS NOT NULL AND (trunc(SYSDATE) BETWEEN (v_alert_start_date-1) AND v_alert_end_date)) THEN

    SELECT NVL2(wc.password_validity,(CASE WHEN (trunc(NVL(g.password_generated_date,g.added_date)+wc.password_validity)>=trunc(SYSDATE)) THEN 'Y'
                                           ELSE 'N'  END),'N') expiry_flag_yn
                                           INTO v_expiry_flag_YN
     FROM weblogin_config  wc
     join tpa_enr_policy_group g on ( wc.policy_seq_id=g.policy_seq_id)
     where  g.policy_group_seq_id=v_policy_group_seq_id;

       v_pwd_alert:='Your password will expire '||case (TRUNC(v_alert_end_date-1)-trunc(SYSDATE)) WHEN 0 then 'Today. 'when 1 then 'in '||(TRUNC(v_alert_end_date-1)-trunc(SYSDATE))||' day. ' else ' in '||(TRUNC(v_alert_end_date-1)-trunc(SYSDATE))||' days. ' end  ||' Please change it now.';
  ELSE v_pwd_alert:=NULL;

  END IF;
  
 --CR-0197
      
  ELSIF v_login_type = 'EMPL' THEN
  OPEN  cr_emp_empl(v_enrollment_id) ;
        FETCH cr_emp_empl INTO v_original_pwd, v_user_name , v_employee_no, v_policy_group_seq_id ,v_pwd_general_type_id,v_tpa_enrol_nbr,v_policy_seq_id,v_int_access_type_id,v_online_ass_type_id,v_online_rate_type_id,v_frst_pwd_alrt,v_first_login_date,v_first_login_window_period,
        v_wrong_attempts,v_config_wrong_attempts,V_ACCN_LOCKED_YN,V_FIRST_LOGIN_YN,v_wellness_login_type_id,v_empl_user_id,v_empl_polno,v_empl_group,v_mem_dob; 
        CLOSE cr_emp_empl;
  
  IF v_user_name IS NULL OR NOT ttk_util_pkg.emp_auth(v_original_pwd,v_password, v_pwd_general_type_id,v_employee_no, v_policy_group_seq_id,v_user_name ) OR  V_ACCN_LOCKED_YN='Y' OR v_mem_dob != to_date(v_DateOfBath,'dd/mm/yyyy')THEN

    IF (to_number(v_wrong_attempts)>=NVL(to_number(v_config_wrong_attempts),5) ) THEN
             raise_application_error(-20950,'Your account locked please contact Authorized person');
    ELSE

      IF v_wrong_attempts=(NVL(v_config_wrong_attempts,5)-1) THEN
        UPDATE tpa_enr_policy_group a SET a.accn_locked_yn='Y' WHERE a.policy_group_seq_id=v_policy_group_seq_id;
      END IF;
      UPDATE tpa_enr_policy_group q SET q.wrong_attempts=nvl(q.wrong_attempts,0)+1
      WHERE q.policy_group_seq_id=v_policy_group_seq_id;
    COMMIT;  
    raise_application_error(-20838,'Invalid User Name/Password/date of birth, Remember Login is Case-Sensitive...');
    END IF;
    END IF;

    OPEN alert_days_cor(v_policy_group_seq_id);
    FETCH alert_days_cor INTO v_alert_end_date,v_alert_start_date,v_alert_days;
    CLOSE alert_days_cor;



    IF (v_alert_days IS NOT NULL AND (trunc(SYSDATE) BETWEEN (v_alert_start_date-1) AND v_alert_end_date)) THEN

    SELECT NVL2(wc.password_validity,(CASE WHEN (trunc(NVL(g.password_generated_date,g.added_date)+wc.password_validity)>=trunc(SYSDATE)) THEN 'Y'
                                           ELSE 'N'  END),'N') expiry_flag_yn
                                           INTO v_expiry_flag_YN
     FROM weblogin_config  wc
     join tpa_enr_policy_group g on ( wc.policy_seq_id=g.policy_seq_id)
     where  g.policy_group_seq_id=v_policy_group_seq_id;

       v_pwd_alert:='Your password will expire '||case (TRUNC(v_alert_end_date-1)-trunc(SYSDATE)) WHEN 0 then 'Today. 'when 1 then 'in '||(TRUNC(v_alert_end_date-1)-trunc(SYSDATE))||' day. ' else ' in '||(TRUNC(v_alert_end_date-1)-trunc(SYSDATE))||' days. ' end  ||' Please change it now.';
  ELSE v_pwd_alert:=NULL;

  END IF;--KOC1257

  INSERT INTO tpa_user_login_history(login_seq_id, user_id,login_date) --Added by venu babu for internal cr IMP-10
      VALUES(tpa_user_login_history_seq.nextval,v_in_enrollment_id,SYSDATE);
          COMMIT; 
  
  ELSIF v_login_type in ('OBR') THEN

                --KOC1257
         OPEN get_bro_cur;
         FETCH  get_bro_cur INTO v_original_pwd,v_user_name,v_frst_pwd_alrt,v_ins_hr_cnt_seqid,v_wrong_attempts,V_ACCN_LOCKED_YN,V_FIRST_LOGIN_YN;
         CLOSE get_bro_cur;

    IF v_user_name IS NULL OR (NOT ttk_util_pkg.fn_decr_password(v_password,v_original_pwd)) OR  V_ACCN_LOCKED_YN='Y' THEN

    OPEN WRONG_ATTEMPTS('WHR');
    FETCH WRONG_ATTEMPTS INTO v_config_wrong_attempts;
    CLOSE WRONG_ATTEMPTS;

    IF (to_number(v_wrong_attempts)>=to_number(v_config_wrong_attempts)) THEN
             raise_application_error(-20950,'Your account locked please contact Authorized person');
    ELSE
      IF v_wrong_attempts=(v_config_wrong_attempts-1) THEN
      UPDATE app.Tpa_Login_Info a SET a.accn_locked_yn='Y' WHERE a.Contact_Seq_Id=v_ins_hr_cnt_seqid;
    END IF;
      UPDATE app.Tpa_Login_Info q SET q.wrong_attempts=nvl(q.wrong_attempts,0)+1
      WHERE q.Contact_Seq_Id=v_ins_hr_cnt_seqid;
    COMMIT;
          raise_application_error(-20048,'Invalid User Name/Password, Remember Login is Case-Sensitive...');
    END IF;
    END IF;

    OPEN alert_days(v_user_id,'WHR');
    FETCH alert_days INTO v_alert_end_date,v_alert_start_date,v_alert_days;
    CLOSE alert_days;

    IF (v_alert_days IS NOT NULL AND (trunc(SYSDATE) BETWEEN (v_alert_start_date-1) AND v_alert_end_date)) THEN

    SELECT NVL2(wc.password_valid_days,(CASE WHEN ((NVL(g.password_generated_date,g.added_date)+wc.password_valid_days)>=SYSDATE) THEN 'Y'
                                           ELSE 'N'  END),'N') expiry_flag_yn
                                           INTO v_expiry_flag_YN
     FROM app.password_config  wc
     join app.tpa_login_info g
     ON (  g.user_id=v_user_id and wc.config_type='WHR' and g.active_yn='Y');
       v_pwd_alert:='Your password will expire '||case (TRUNC(v_alert_end_date-1)-trunc(SYSDATE)) WHEN 0 then 'Today. 'when 1 then 'in '||(TRUNC(v_alert_end_date-1)-trunc(SYSDATE))||' day. ' else ' in '||(TRUNC(v_alert_end_date-1)-trunc(SYSDATE))||' days. ' end  ||' Please change it now.';
  ELSE v_pwd_alert:=NULL;
  END IF;
  
  --kocbroker NEW  
  SELECT a.ip_address INTO ip_address_log FROM tpa_login_info a WHERE a.user_id=v_user_id;

 /* IF(ip_address_log IS NOT NULL and (v_ip_address !=ip_address_log )) THEN
      raise_application_error(-20951,'user already logged on');
  END IF; */
  
   IF v_ip_address is null /*OR v_ip_address LIKE '10.100.%'*/--modified for VPN users(04/04/2013)-sadiq
      THEN
      UPDATE TPA_LOGIN_INFO G
      SET G.IP_ADDRESS=NULL 
      WHERE G.USER_ID=v_user_id;
   ELSE 
      UPDATE TPA_LOGIN_INFO F
      SET F.IP_ADDRESS=v_ip_address 
      WHERE F.USER_ID=v_user_id;
      COMMIT;
    END IF;

  UPDATE tpa_login_info h SET         --Added for CR-KOC1235
            h.recent_login_date=SYSDATE,      --Added for CR-KOC1235
            h.wrong_attempts=NULL
      WHERE  h.user_id=v_user_id;        --Added for CR-KOC1235
  COMMIT;
  
        --KOC1257

         OPEN cur_contact ;
         FETCH cur_contact INTO v_rec_contact;
         CLOSE cur_contact;

      ELSIF v_login_type = 'OHR' THEN

                --KOC1257
         OPEN get_password_cur;
         FETCH  get_password_cur INTO v_original_pwd,v_user_name,v_frst_pwd_alrt,v_ins_hr_cnt_seqid,v_wrong_attempts,V_ACCN_LOCKED_YN,V_FIRST_LOGIN_YN;
         CLOSE get_password_cur;

    IF v_user_name IS NULL OR (NOT ttk_util_pkg.fn_decr_password(v_password,v_original_pwd)) OR  V_ACCN_LOCKED_YN='Y' THEN

    OPEN WRONG_ATTEMPTS('WHR');
    FETCH WRONG_ATTEMPTS INTO v_config_wrong_attempts;
    CLOSE WRONG_ATTEMPTS;

    IF (to_number(v_wrong_attempts)>=to_number(v_config_wrong_attempts)) THEN
             raise_application_error(-20950,'Your account locked please contact Authorized person');
    ELSE
      IF v_wrong_attempts=(v_config_wrong_attempts-1) THEN
      UPDATE Tpa_Login_Info a SET a.accn_locked_yn='Y' WHERE a.Contact_Seq_Id=v_ins_hr_cnt_seqid;
    END IF;
      UPDATE Tpa_Login_Info q SET q.wrong_attempts=nvl(q.wrong_attempts,0)+1
      WHERE q.Contact_Seq_Id=v_ins_hr_cnt_seqid;
    COMMIT;
          raise_application_error(-20048,'Invalid User Name/Password, Remember Login is Case-Sensitive...');
    END IF;
    END IF;

    OPEN alert_days(v_user_id,'WHR');
    FETCH alert_days INTO v_alert_end_date,v_alert_start_date,v_alert_days;
    CLOSE alert_days;

    IF (v_alert_days IS NOT NULL AND (trunc(SYSDATE) BETWEEN (v_alert_start_date-1) AND v_alert_end_date)) THEN

    SELECT NVL2(wc.password_valid_days,(CASE WHEN ((NVL(g.password_generated_date,g.added_date)+wc.password_valid_days)>=SYSDATE) THEN 'Y'
                                           ELSE 'N'  END),'N') expiry_flag_yn
                                           INTO v_expiry_flag_YN
     FROM password_config  wc
     join tpa_login_info g
     ON (  g.user_id=v_user_id and wc.config_type='WHR' and g.active_yn='Y');
       v_pwd_alert:='Your password will expire '||case (TRUNC(v_alert_end_date-1)-trunc(SYSDATE)) WHEN 0 then 'Today. 'when 1 then 'in '||(TRUNC(v_alert_end_date-1)-trunc(SYSDATE))||' day. ' else ' in '||(TRUNC(v_alert_end_date-1)-trunc(SYSDATE))||' days. ' end  ||' Please change it now.';
  ELSE v_pwd_alert:=NULL;
  END IF;
        --KOC1257

         OPEN cur_contact ;
         FETCH cur_contact INTO v_rec_contact;
         CLOSE cur_contact;
         
   INSERT INTO tpa_user_login_history(login_seq_id, user_id,login_date) --Added by venu babu for internal cr IMP-10
   VALUES(tpa_user_login_history_seq.nextval,v_user_id,SYSDATE);
   COMMIT; 
          
   ELSIF v_login_type = 'OIU' THEN
         OPEN get_ins_password_cur;
         FETCH  get_ins_password_cur INTO v_original_pwd,v_user_name,v_frst_pwd_alrt,v_ins_hr_cnt_seqid,v_wrong_attempts,V_ACCN_LOCKED_YN,V_FIRST_LOGIN_YN,v_ins_comp_name;
         CLOSE get_ins_password_cur;

         --KOC1257
    IF v_user_name IS NULL OR (NOT ttk_util_pkg.fn_decr_password(v_password,v_original_pwd)) OR  V_ACCN_LOCKED_YN='Y' THEN

    OPEN WRONG_ATTEMPTS('INS');
    FETCH WRONG_ATTEMPTS INTO v_config_wrong_attempts;
    CLOSE WRONG_ATTEMPTS;

    IF (to_number(v_wrong_attempts)>=to_number(v_config_wrong_attempts)) THEN
             raise_application_error(-20950,'Your account locked please contact Authorized person');
    ELSE

      IF v_wrong_attempts=(v_config_wrong_attempts-1) THEN

      UPDATE Tpa_Login_Info a SET a.accn_locked_yn='Y' WHERE a.Contact_Seq_Id=v_ins_hr_cnt_seqid;
    END IF;
      UPDATE Tpa_Login_Info q SET q.wrong_attempts=nvl(q.wrong_attempts,0)+1
      WHERE q.Contact_Seq_Id=v_ins_hr_cnt_seqid;
    COMMIT;
          raise_application_error(-20048,'Invalid User Name/Password, Remember Login is Case-Sensitive...');
    END IF;
    END IF;

    OPEN alert_days(V_USER_ID,'INS');
    FETCH alert_days INTO v_alert_end_date,v_alert_start_date,v_alert_days;
    CLOSE alert_days;

       IF (v_alert_days IS NOT NULL AND (trunc(SYSDATE) BETWEEN (v_alert_start_date-1) AND v_alert_end_date)) THEN

             SELECT NVL2(wc.password_valid_days,(CASE WHEN ((NVL(g.password_generated_date,g.added_date)+wc.password_valid_days)>=SYSDATE) THEN 'Y'
                                           ELSE 'N'  END),'N') expiry_flag_yn
                                           INTO v_expiry_flag_YN
                                           FROM password_config  wc
                                           join tpa_login_info g
                                           ON (  g.user_id=v_user_id and wc.config_type='INS' and g.active_yn='Y');
              v_pwd_alert:='Your password will expire '||case (TRUNC(v_alert_end_date-1)-trunc(SYSDATE)) WHEN 0 then 'Today. 'when 1 then 'in '||(TRUNC(v_alert_end_date-1)-trunc(SYSDATE))||' day. ' else ' in '||(TRUNC(v_alert_end_date-1)-trunc(SYSDATE))||' days. ' end  ||' Please change it now.';
       ELSE v_pwd_alert:=NULL;

       
         
  END IF;
  
  --=============================================added for insurance login===================================
        UPDATE tpa_login_info h SET        
            h.recent_login_date=SYSDATE,      
            h.wrong_attempts=NULL
        WHERE  h.user_id=v_user_id;        
     COMMIT;
     INSERT INTO tpa_user_login_history(login_seq_id,user_id,login_date)  --Added for CR-KOC1233
          VALUES(tpa_user_login_history_seq.nextval,v_user_id,SYSDATE);
          COMMIT;           
--===========================================================================================
         OPEN cur_contact ;
         FETCH cur_contact INTO v_rec_contact;
         CLOSE cur_contact;
   ELSIF v_login_type = 'OCI' THEN -- CITI BANK Non Corporate Login
        OPEN ncr_cur_mem ;
        FETCH ncr_cur_mem INTO v_user_name, v_mem_seq_id,v_policy_group_seq_id,v_product_seq_id;
        CLOSE ncr_cur_mem ;
        IF v_mem_seq_id IS NULL THEN
          raise_application_error(-20690,'Invalid Certificate No./Scheme Name/Enrollment Id, Remember Login is Case-Sensitive...');
        END IF;
   ELSIF v_login_type = 'HOS' THEN
   
               --KOC1257
         OPEN get_hosp_password_cur;
         FETCH get_hosp_password_cur INTO v_original_pwd,v_user_name,v_hosp_seq_id,v_hosp_name,v_empanel_number,v_COUNTRY_name,V_emirate,V_area,v_ADDRESS_1,v_OFF_PHONE_NO_1,v_hospitalType,v_frst_pwd_alrt,v_wrong_attempts,V_ACCN_LOCKED_YN,V_FIRST_LOGIN_YN,v_hosp_contact_seq_id,v_empanel_status,v_bio_metric_yn;
         CLOSE get_hosp_password_cur;
         
/*    IF(v_empanel_status!='EMP') THEN
  raise_application_error(-20834,'The given Empanel Id is Dis-Empaneled');
  END IF;*/ 
      IF v_user_name IS NULL OR (NOT ttk_util_pkg.fn_decr_password(v_password,v_original_pwd)) OR  V_ACCN_LOCKED_YN='Y' THEN

    OPEN WRONG_ATTEMPTS('HOS');
    FETCH WRONG_ATTEMPTS INTO v_config_wrong_attempts;
    CLOSE WRONG_ATTEMPTS;

    IF (to_number(v_wrong_attempts)>=to_number(v_config_wrong_attempts)) THEN
             raise_application_error(-20950,'Your account locked please contact Authorized person');
    ELSE
      IF v_wrong_attempts=(v_config_wrong_attempts-1) THEN
      UPDATE Tpa_Login_Info a SET a.accn_locked_yn='Y' WHERE a.Contact_Seq_Id=v_hosp_contact_seq_id;
    END IF;
      UPDATE Tpa_Login_Info q SET q.wrong_attempts=nvl(q.wrong_attempts,0)+1
      WHERE q.Contact_Seq_Id=v_hosp_contact_seq_id;
    COMMIT;
          raise_application_error(-20396,'Invalid Empanelment Id/User Name/Password, Remember Login is Case-Sensitive...');
    END IF;
    END IF;
--=============================================added for hospital login===================================
        UPDATE tpa_login_info h SET        
            h.recent_login_date=SYSDATE,      
            h.wrong_attempts=NULL
        WHERE  h.user_id=v_user_id;        
     COMMIT;
   
     
     INSERT INTO tpa_user_login_history(login_seq_id, user_id,login_date,contact_seq_id)  --Added for CR-KOC1233 --contact_seq_id Added for login reports
          VALUES(tpa_user_login_history_seq.nextval,v_user_id,SYSDATE,v_hosp_contact_seq_id);
          COMMIT;           
--===========================================================================================

    
         OPEN cur_contact ;
         FETCH cur_contact INTO v_rec_contact;
         CLOSE cur_contact;
         
        ELSIF v_login_type = 'PTR' THEN --ADDED NEWLY FOR PARTNER
   
               
         OPEN get_ptnr_password_cur;
         FETCH get_ptnr_password_cur INTO v_original_pwd,v_user_name,v_ptnr_seq_id,v_partner_name,v_empanel_number, v_country_name_ptr,v_emirate_ptr,v_area_ptr,v_address_1_ptr,v_off_phone_no_1_ptr,v_frst_pwd_alrt,v_wrong_attempts,V_ACCN_LOCKED_YN,V_FIRST_LOGIN_YN,v_PTNR_contact_seq_id,v_empanel_status;
         CLOSE get_ptnr_password_cur;
         


      IF v_user_name IS NULL OR (NOT ttk_util_pkg.fn_decr_password(v_password,v_original_pwd)) OR  V_ACCN_LOCKED_YN='Y' THEN

    OPEN WRONG_ATTEMPTS('PTR');
    FETCH WRONG_ATTEMPTS INTO v_config_wrong_attempts;
    CLOSE WRONG_ATTEMPTS;

    IF (v_wrong_attempts>=v_config_wrong_attempts) THEN
             raise_application_error(-20950,'Your account locked please contact Authorized person');
    ELSE
      IF v_wrong_attempts=(v_config_wrong_attempts-1) THEN
      UPDATE Tpa_Login_Info a SET a.accn_locked_yn='Y' WHERE a.Contact_Seq_Id=v_PTNR_contact_seq_id;
    END IF;
      UPDATE Tpa_Login_Info q SET q.wrong_attempts=nvl(q.wrong_attempts,0)+1
      WHERE q.Contact_Seq_Id=v_PTNR_contact_seq_id;
    COMMIT;
          raise_application_error(-20396,'Invalid Empanelment Id/User Name/Password, Remember Login is Case-Sensitive...');
    END IF;
    END IF;
--=============================================added for Partner login===================================
        UPDATE tpa_login_info h SET        
            h.recent_login_date=SYSDATE,      
            h.wrong_attempts=NULL
        WHERE  h.user_id=v_user_id;        
     COMMIT;
     INSERT INTO tpa_user_login_history(login_seq_id,user_id,login_date) 
          VALUES(tpa_user_login_history_seq.nextval,v_user_id,SYSDATE);
          COMMIT;           
--===========================================================================================

    
         OPEN cur_contact ;
         FETCH cur_contact INTO v_rec_contact;
         CLOSE cur_contact;

   END IF;
   
   --=============================================================================================

      IF v_login_type = 'OCO' /*OR v_login_type = 'EMPL'*/ THEN
       OPEN cur_emp_groupname_cur;
       FETCH cur_emp_groupname_cur INTO v_group_name;
       CLOSE cur_emp_groupname_cur;
        SELECT template_id INTO v_template_id
         FROM tpa_ins_prod_policy WHERE policy_seq_id = v_policy_seq_id;
        IF v_template_id IS NULL THEN
          SELECT pp.template_id INTO v_template_id
          FROM tpa_ins_prod_policy pp JOIN tpa_enr_policy p ON (p.product_seq_id = pp.product_seq_id)
          WHERE p.policy_seq_id = v_policy_seq_id;
        END IF;
        IF v_template_id IS NOT NULL THEN
         SELECT template_name INTO v_template_name
         FROM tpa_policy_templates WHERE template_id = v_template_id;
        END IF;
             --CR- 0197  
      ELSIF  v_login_type = 'EMPL' THEN
        OPEN cur_emp_groupname_empl_cur(v_policy_seq_id);
       FETCH cur_emp_groupname_empl_cur INTO v_group_name;
       CLOSE cur_emp_groupname_empl_cur;
        SELECT template_id INTO v_template_id
         FROM tpa_ins_prod_policy WHERE policy_seq_id = v_policy_seq_id;
        IF v_template_id IS NULL THEN
          SELECT pp.template_id INTO v_template_id
          FROM tpa_ins_prod_policy pp JOIN tpa_enr_policy p ON (p.product_seq_id = pp.product_seq_id)
          WHERE p.policy_seq_id = v_policy_seq_id;
        END IF;
        IF v_template_id IS NOT NULL THEN
         SELECT template_name INTO v_template_name
         FROM tpa_policy_templates WHERE template_id = v_template_id;
        END IF;
         
      ELSIF v_login_type in ('OHR') THEN
       OPEN cur_hr_groupname_cur;
       FETCH cur_hr_groupname_cur INTO v_group_name;
       CLOSE cur_hr_groupname_cur;
	   
	    ELSIF v_login_type IN('OBR') THEN
       OPEN cur_bro_comp_name;
       FETCH cur_bro_comp_name INTO v_group_name,v_broker_code;
       CLOSE cur_bro_comp_name;
       
       OPEN cur_ins_user_last_login;
       FETCH cur_ins_user_last_login INTO v_last_login_date;
       CLOSE cur_ins_user_last_login; 
       
       --=========================================added for broker login===================================
        UPDATE tpa_login_info h SET        
            h.recent_login_date=SYSDATE,      
            h.wrong_attempts=NULL
        WHERE  h.user_id=v_user_id;        
         COMMIT;
       INSERT INTO tpa_user_login_history(login_seq_id,user_id,login_date)  
          VALUES(tpa_user_login_history_seq.nextval,v_user_id,SYSDATE);
        COMMIT;     
---======================================================================
      ELSIF v_login_type IN ('OIN','OCI') THEN
        SELECT template_id INTO v_template_id
        FROM tpa_ins_prod_policy WHERE product_seq_id = v_product_seq_id;

        IF v_template_id IS NOT NULL THEN
         SELECT template_name INTO v_template_name
         FROM tpa_policy_templates WHERE template_id = v_template_id;
        END IF;
      ELSIF v_login_type IN('OIU','HOS','PTR') THEN
       OPEN cur_ins_user_last_login;
       FETCH cur_ins_user_last_login INTO v_last_login_date;
       CLOSE cur_ins_user_last_login;  
      END IF;

      v_user_doc := dbms_xmldom.newDOMDocument;
      dbms_xmldom.setVersion( v_user_doc, '1.0' );
      v_user_root_node := dbms_xmldom.makeNode( v_user_doc);

      v_elem := dbms_xmldom.createElement( v_user_doc, 'usersecurityprofile' );
      v_node := dbms_xmldom.makeNode( v_elem );
      v_user_root_node := dbms_xmldom.appendChild( v_user_root_node, v_node );

      v_elem := dbms_xmldom.createElement(v_user_doc, 'user');
      dbms_xmldom.setAttribute(v_elem,'name',v_user_name);
      dbms_xmldom.setAttribute(v_elem,'contactseqid',v_rec_contact.contact_seq_id);
      dbms_xmldom.setAttribute(v_elem,'usertype','');
      dbms_xmldom.setAttribute(v_elem,'active','');
      dbms_xmldom.setAttribute(v_elem,'contacttypeid','');
      dbms_xmldom.setAttribute(v_elem,'branchid','');
      dbms_xmldom.setAttribute(v_elem,'branchname','');
      dbms_xmldom.setAttribute(v_elem,'userid',case when v_login_type ='EMPL' then v_empl_user_id else  '' end);
      dbms_xmldom.setAttribute(v_elem,'logindate',to_char(SYSDATE,'DD/MM/YYYY HH:MI:SS AM'));
      dbms_xmldom.setAttribute(v_elem,'email','');
      dbms_xmldom.setAttribute(v_elem,'mobile','');
      dbms_xmldom.setAttribute(v_elem,'groupname',v_group_name);
      dbms_xmldom.setAttribute(v_elem,'policygrpseqid',v_policy_group_seq_id);
      dbms_xmldom.setAttribute(v_elem,'tpaenrolnbr',v_tpa_enrol_nbr);
      dbms_xmldom.setAttribute(v_elem,'polseqid',v_policy_seq_id);
      dbms_xmldom.setAttribute(v_elem,'intaccesstypeid',v_int_access_type_id);
      dbms_xmldom.setAttribute(v_elem,'onlineasstypeid',v_online_ass_type_id);
      dbms_xmldom.setAttribute(v_elem,'wellnesstypeid',v_wellness_login_type_id);   --KOC1349
      dbms_xmldom.setAttribute(v_elem,'onlineratetypeid',v_online_rate_type_id);
      dbms_xmldom.setAttribute(v_elem,'templatename',v_template_name);
      dbms_xmldom.setAttribute(v_elem,'firstpwdalert',v_frst_pwd_alrt);
      dbms_xmldom.setAttribute(v_elem,'inshrcontactseqid',v_ins_hr_cnt_seqid);
      dbms_xmldom.setAttribute(v_elem,'hospseqid',v_hosp_seq_id);
      dbms_xmldom.setAttribute(v_elem,'hospname',v_hosp_name);
      dbms_xmldom.setAttribute(v_elem,'ptrseqid',v_ptnr_seq_id);--newly added for partner
	    dbms_xmldom.setAttribute(v_elem,'ptnrname',v_partner_name);--newly added for partner
      case when v_login_type IN ('HOS','OCO','OHR','EMPL') THEN     ----ADDED 25/09/2017
      dbms_xmldom.setAttribute(v_elem,'empanelnumber',v_empanel_number);
      dbms_xmldom.setAttribute(v_elem,'hospcountry',v_COUNTRY_name);
      dbms_xmldom.setAttribute(v_elem,'hospemirate',V_emirate);
      dbms_xmldom.setAttribute(v_elem,'hosparea ',V_area);
      dbms_xmldom.setAttribute(v_elem,'hospaddress ',v_ADDRESS_1);
      dbms_xmldom.setAttribute(v_elem,'hospphone',v_OFF_PHONE_NO_1);
      dbms_xmldom.setAttribute(v_elem,'hospitalType',v_hospitalType);
      dbms_xmldom.setAttribute(v_elem,'biometric',v_bio_metric_yn);
           when v_login_type IN ('PTR') THEN 
	    dbms_xmldom.setAttribute(v_elem,'empanelnumber',v_empanel_number);--newly added for partner
		else
        raise_application_error(-20913,'Invalid login');  ---newly added for production issue
	    end case;
      dbms_xmldom.setAttribute(v_elem,'ptnrcountry',v_country_name_ptr);--newly added for partner
      dbms_xmldom.setAttribute(v_elem,'ptnremirate',v_emirate_ptr);--newly added for partner
      dbms_xmldom.setAttribute(v_elem,'ptnrarea ',v_area_ptr);--newly added for partner
      dbms_xmldom.setAttribute(v_elem,'ptnraddress ',v_address_1_ptr);--newly added for partner
      dbms_xmldom.setAttribute(v_elem,'ptnrphone',v_off_phone_no_1_ptr);--newly added for partner
      dbms_xmldom.setAttribute(v_elem,'inscomp',v_ins_comp_name);
      dbms_xmldom.setAttribute(v_elem,'brokercode',v_broker_code);
      dbms_xmldom.setAttribute(v_elem,'lastlogindate',to_char(v_last_login_date,'DD/MM/YYYY HH:MI AM'));
	    dbms_xmldom.setAttribute(v_elem,'hospcat',v_hosp_catagory);
      dbms_xmldom.setAttribute(v_elem,'coordinaterEmailId',v_rec_contact.tpalogin);
      dbms_xmldom.setAttribute(v_elem,'partnerEmailId',v_rec_contact.tpalogin);--added new
      IF v_login_type ='EMPL' THEN
      dbms_xmldom.setAttribute(v_elem,'emplpolnum',v_empl_polno);
      dbms_xmldom.setAttribute(v_elem,'emplgroupid',v_empl_group);
      END IF;
      v_node := dbms_xmldom.makeNode(v_elem);
      v_parent_node := dbms_xmldom.appendChild( v_user_root_node, v_node);

      v_elem := dbms_xmldom.createElement(v_user_doc, 'preauth');
      dbms_xmldom.setAttribute(v_elem,'processing','');
      dbms_xmldom.setAttribute(v_elem,'limit','');
      v_node := dbms_xmldom.makeNode(v_elem);
      v_node := dbms_xmldom.appendChild( v_parent_node, v_node);

      v_elem := dbms_xmldom.createElement(v_user_doc, 'claim');
      dbms_xmldom.setAttribute(v_elem,'processing','');
      dbms_xmldom.setAttribute(v_elem,'limit','');
      v_node := dbms_xmldom.makeNode(v_elem);
      v_node := dbms_xmldom.appendChild( v_parent_node, v_node);

      v_elem := dbms_xmldom.createElement(v_user_doc, 'role');
      dbms_xmldom.setAttribute(v_elem,'seqid','');
      dbms_xmldom.setAttribute(v_elem,'name','');
      v_node := dbms_xmldom.makeNode(v_elem);
      v_role_node := dbms_xmldom.appendChild( v_parent_node, v_node);

      v_elem := dbms_xmldom.createElement(v_user_doc, 'workflow');
      dbms_xmldom.setAttribute(v_elem,'seqid','');
      dbms_xmldom.setAttribute(v_elem,'name','');
      v_node := dbms_xmldom.makeNode(v_elem);
      v_wflow_node := dbms_xmldom.appendChild( v_role_node, v_node);

      v_elem := dbms_xmldom.createElement(v_user_doc, 'groups');
      v_node := dbms_xmldom.makeNode(v_elem);
      v_group_node := dbms_xmldom.appendChild( v_parent_node, v_node);
  
      IF v_login_type in ('OHR') OR v_login_type = 'OIU' OR v_login_type = 'OBR' or v_login_type='HOS' or  v_login_type='PTR' THEN
        OPEN cur_hr;
        FETCH cur_hr INTO v_rec_hr;
        CLOSE cur_hr;
        IF v_rec_hr.privilege IS NOT NULL THEN
           v_privilege := v_rec_hr.privilege;
           v_privilege_doc := DBMS_XMLDOM.newDOMDocument(v_privilege);
           v_priv_root_node := DBMS_XMLDOM.makeNode(DBMS_XMLDOM.getDocumentElement((v_privilege_doc)));

           v_priv_root_node := dbms_xmldom.importNode(v_user_doc,v_priv_root_node,TRUE);
           v_user_root_node := dbms_xmldom.appendChild(v_user_root_node,v_priv_root_node);
           dbms_xmldom.freeDocument(v_privilege_doc);
                v_user_sec := dbms_xmldom.getxmltype(v_user_doc);
 --insert into v_temp values (v_user_sec.getClobVal(),sysdate);
-- commit;
        END IF;
        
     /*   IF v_hosp_seq_id IS NOT NULL THEN
          hospital_pkg.dash_board_pat_clm(v_hosp_seq_id,v_hosp_xml);
            v_privilege_doc := DBMS_XMLDOM.newDOMDocument(v_hosp_xml);
            v_priv_root_node := DBMS_XMLDOM.makeNode(DBMS_XMLDOM.getDocumentElement((v_privilege_doc)));

            v_priv_root_node := dbms_xmldom.importNode(v_user_doc,v_priv_root_node,TRUE);
            v_user_root_node := dbms_xmldom.appendChild(v_user_root_node,v_priv_root_node);
            dbms_xmldom.freeDocument(v_privilege_doc);           
          
      
         END IF; */
         
     ELSIF  v_login_type =('EMPL') THEN
      OPEN cur_user_empl;
         FETCH cur_user_empl INTO v_rec_user;
         CLOSE cur_user_empl;
         IF v_rec_user.privilege IS NOT NULL THEN
            v_privilege := v_rec_user.privilege;
            v_privilege_doc := DBMS_XMLDOM.newDOMDocument(v_privilege);
            v_priv_root_node := DBMS_XMLDOM.makeNode(DBMS_XMLDOM.getDocumentElement((v_privilege_doc)));

            v_priv_root_node := dbms_xmldom.importNode(v_user_doc,v_priv_root_node,TRUE);
            v_user_root_node := dbms_xmldom.appendChild(v_user_root_node,v_priv_root_node);
            dbms_xmldom.freeDocument(v_privilege_doc);
         END IF;  
     ELSE
         OPEN cur_user;
         FETCH cur_user INTO v_rec_user;
         CLOSE cur_user;
         IF v_rec_user.privilege IS NOT NULL THEN
            v_privilege := v_rec_user.privilege;
            v_privilege_doc := DBMS_XMLDOM.newDOMDocument(v_privilege);
            v_priv_root_node := DBMS_XMLDOM.makeNode(DBMS_XMLDOM.getDocumentElement((v_privilege_doc)));

            v_priv_root_node := dbms_xmldom.importNode(v_user_doc,v_priv_root_node,TRUE);
            v_user_root_node := dbms_xmldom.appendChild(v_user_root_node,v_priv_root_node);
            dbms_xmldom.freeDocument(v_privilege_doc);
         END IF;
     END IF;
     v_user_sec := dbms_xmldom.getxmltype(v_user_doc);

       IF v_login_type = 'OCO' /*OR v_login_type = 'EMPL' */AND v_policy_group_seq_id IS NOT NULL AND v_frst_pwd_alrt != 'Y' THEN  -- for CR-KOC1019
    IF (v_first_login_date IS NULL AND NVL(v_first_login_window_period,0)>0) THEN--FOR KOC1091 CR
       UPDATE tpa_enr_policy_group G
         SET G.first_login_date=SYSDATE,
             G.first_login_window_period=DECODE(NVL(v_first_login_window_period,0),0,NULL,v_first_login_window_period)
       WHERE G.policy_group_seq_id=v_policy_group_seq_id;
    END IF;
    INSERT INTO tpa_online_login_history(login_seq_id,policy_group_seq_id,login_date) VALUES (ONLINE_LOGIN_HISTORY_SEQ.NEXTVAL,v_policy_group_seq_id,SYSDATE);
    COMMIT;--FOR KOC1091 CR

  END IF;
    
  IF v_login_type = 'EMPL' AND v_policy_group_seq_id IS NOT NULL AND v_frst_pwd_alrt != 'Y' THEN 
    IF (v_first_login_date IS NULL AND NVL(v_first_login_window_period,0)>0) THEN
       UPDATE tpa_enr_policy_group G
         SET G.first_login_date=SYSDATE,
             G.first_login_window_period=DECODE(NVL(v_first_login_window_period,0),0,NULL,v_first_login_window_period)
       WHERE G.policy_group_seq_id=v_policy_group_seq_id;
    END IF;
    INSERT INTO tpa_online_login_history(login_seq_id,policy_group_seq_id,login_date) VALUES (ONLINE_LOGIN_HISTORY_SEQ.NEXTVAL,v_policy_group_seq_id,SYSDATE);
    END IF;
  dbms_xmldom.freeDocument(v_user_doc);
   --koc1349
  IF v_login_type='OCO' OR v_login_type='EMPL'   then

     v_random_num := dbms_random.string('X',8);
     update app.Tpa_Enr_Policy_Group gr
  set gr.random_num = v_random_num
  where gr.policy_group_seq_id = v_policy_group_seq_id;

   else
     v_random_num := 'ABC';
   end if;
 --koc1349
   commit;


END pr_external_user_validation;
--==============================================================================================
 --   Name       : logout
 --   Created on : 12-12-12
 --   Created By : Sadiq
 --   Comments   : To capture logout details
 --  Added for CR-KOC1235
--============================================================================================
PROCEDURE logout(
    v_user_id           IN tpa_login_info.user_id%TYPE,
    v_ip_address        IN tpa_login_info.ip_address%TYPE,
    v_rows_processed    OUT NUMBER
 )
 IS
     v_user_id_ses     tpa_login_info.ip_address%TYPE;

    CURSOR session_cur IS
    SELECT a.user_id  FROM tpa_login_info a
    WHERE a.ip_address=v_ip_address;


 BEGIN
   
    OPEN session_cur;
    FETCH session_cur INTO v_user_id_ses;
    CLOSE session_cur;

  IF (v_ip_address IS NOT NULL) THEN
  UPDATE tpa_login_info SET ip_address=NULL WHERE user_id=v_user_id_ses;
  UPDATE tpa_user_login_history a SET a.logout_date=SYSDATE, a.ip_address=v_ip_address WHERE a.user_id=v_user_id_ses AND a.login_date =     -- audit logs
 (SELECT MAX(b.login_date) FROM tpa_user_login_history b  WHERE b.user_id=v_user_id_ses AND b.logout_date IS NULL);
  v_rows_processed := SQL%ROWCOUNT;
  END IF;
  COMMIT;
  

  IF (v_user_id IS NOT NULL) THEN
  UPDATE tpa_login_info SET ip_address=NULL WHERE user_id=v_user_id;
  UPDATE tpa_user_login_history a SET a.logout_date=SYSDATE, a.ip_address=v_ip_address WHERE a.user_id=v_user_id AND a.login_date =   -- audit logs
  (SELECT MAX(b.login_date) FROM tpa_user_login_history b  WHERE b.user_id=v_user_id AND b.logout_date IS NULL);
  v_rows_processed := SQL%ROWCOUNT;
  END IF;
  COMMIT;
END logout;
--=========================================================================================================
PROCEDURE pr_external_single_sign(
    v_user_id        IN tpa_login_info.user_id%TYPE,
    v_password       IN tpa_login_info.password%TYPE,
    v_group_id       IN tpa_group_registration.group_id%TYPE,
    v_login_type     IN CHAR, -- OIN FOR INDIVIDUAL, OCO - EMPLOYEE means CORPORATE , OHR FOR HR, OIU FOR INSURANCE ,OCI --  CITI BANK
    v_random_num      OUT tpa_login_info.password%TYPE
  )  --koc1349
  is
 begin
if v_login_type='OCO'   then
   v_random_num := dbms_random.string('X',8);
end if;
  update tpa_login_info log
   set log.password_5=v_random_num
  where log.user_id=v_user_id;
end pr_external_single_sign;
--=========================================================================================================
procedure online_logoff (v_user_id IN tpa_enr_policy_group.employee_no%type,
                         v_random_num IN tpa_enr_policy_group.password_5%type,
                         v_ip_address IN tpa_user_login_history.ip_address%type,
                         v_rows_processed    OUT NUMBER)   --koc1349
is
begin
  update tpa_enr_policy_group gr  set gr.random_num = null
  where gr.employee_no = v_user_id and gr.random_num = v_random_num;
  v_rows_processed := SQL%ROWCOUNT;
  
  UPDATE tpa_login_info SET ip_address=NULL
   WHERE user_id=v_user_id;--kocbroker
   
   UPDATE tpa_user_login_history a SET a.logout_date=SYSDATE ,a.ip_address = v_ip_address
   WHERE a.user_id=v_user_id AND a.login_date = (SELECT MAX(b.login_date) FROM tpa_user_login_history b  WHERE b.user_id=v_user_id AND b.logout_date IS NULL);
   
commit;
end online_logoff;
--=========================================================================================================
PROCEDURE softcopy_login(v_user_id                 IN tpa_login_info.user_id%type,
                         v_pwd                     IN tpa_login_info.password%type,
                         /*v_tpa_office_seq_id       OUT tpa_office_info.tpa_office_seq_id%type,
                         v_office_name             OUT tpa_office_info.office_name%type,
                         v_user_name               OUT tpa_user_contacts.contact_name%type,
                         v_user_seq_id             OUT tpa_user_contacts.contact_seq_id%type,
                         v_rows_processed          OUT NUMBER*/
                         v_sys_cur                 OUT SYS_REFCURSOR)
IS

cursor login_cur IS
select tli.contact_seq_id,tuc.tpa_office_seq_id,tuc.contact_name,tli.password,toi.office_name
 from tpa_login_info tli
join tpa_user_contacts tuc on (tli.contact_seq_id=tuc.contact_seq_id)
join tpa_office_info toi on (tuc.tpa_office_seq_id=toi.tpa_office_seq_id)
where tli.user_id=v_user_id
AND tuc.active_yn='Y'
AND tli.active_yn='Y';

user_rec               login_cur%rowtype;

BEGIN
  
  open login_cur;
  fetch login_cur into user_rec;
  close login_cur;
 
  IF NOT ttk_util_pkg.fn_decr_password(v_pwd,user_rec.password) THEN
       raise_application_error(-20048,'Invalid User Name/Password, Remember Login is Case-Sensitive...');
  ELSE
   /* v_tpa_office_seq_id:=user_rec.Tpa_Office_Seq_Id;
    v_user_name:=user_rec.contact_name;
    v_user_seq_id:=user_rec.contact_seq_id;
    v_office_name:=user_rec.office_name;*/
    OPEN v_sys_cur FOR SELECT to_char(user_rec.Tpa_Office_Seq_Id) AS Off_seq_id,
                              user_rec.office_name as Office_Name,
                              to_char(user_rec.contact_seq_id) as Contact_Seq_id,
                              user_rec.contact_name as Contact_name from dual;
  END IF; 
  
END softcopy_login;                         
                         
--=========================================================================================================
--==============================================================================================
 --   Name       : logout
 --   Created on : 12-12-12
 --   Created By : Sadiq
 --   Comments   : To capture logout details
 --  Added for CR-KOC1235
--============================================================================================
PROCEDURE user_logout(
    v_user_id           IN tpa_login_info.user_id%TYPE,
    v_password          IN tpa_login_info.password%type,
    v_ip_address        IN tpa_login_info.ip_address%TYPE,
    v_flag              OUT varchar2,--'Y','N'
    v_rows_processed    OUT NUMBER
 )
 IS
     v_user_id_ses     tpa_login_info.ip_address%TYPE;

    CURSOR session_cur IS
    SELECT a.user_id  FROM tpa_login_info a
    WHERE a.ip_address=v_ip_address;
    
    v_count   number:=0;


 BEGIN
      
    OPEN session_cur;
    FETCH session_cur INTO v_user_id_ses;
    CLOSE session_cur;
    
    select count(1) into v_count from tpa_login_info l where l.user_id = v_user_id and 
     ttk_util_pkg.fn_decrypt(l.password)=v_password;
     
    IF V_COUNT>0 THEN 
      v_flag:='Y' ;
    ELSE 
      v_flag:='N'; 
    END IF;

  IF (v_ip_address IS NOT NULL) AND v_flag='Y' THEN
  UPDATE tpa_login_info SET ip_address=NULL WHERE user_id=v_user_id_ses;
  UPDATE tpa_user_login_history a SET a.logout_date=SYSDATE WHERE a.user_id=v_user_id_ses AND a.login_date =     -- audit logs
 (SELECT MAX(b.login_date) FROM tpa_user_login_history b  WHERE b.user_id=v_user_id_ses AND b.logout_date IS NULL);
  v_rows_processed := SQL%ROWCOUNT;
  END IF;
  COMMIT;
  

  IF (v_user_id IS NOT NULL) AND v_flag='Y' THEN
  UPDATE tpa_login_info SET ip_address=NULL WHERE user_id=v_user_id;
  UPDATE tpa_user_login_history a SET a.logout_date=SYSDATE WHERE a.user_id=v_user_id AND a.login_date =   -- audit logs
  (SELECT MAX(b.login_date) FROM tpa_user_login_history b  WHERE b.user_id=v_user_id AND b.logout_date IS NULL);
  v_rows_processed := SQL%ROWCOUNT;
  END IF;
  COMMIT;
END user_logout;
--=====================================================================
END authentication_pkg;

/

--------------------------------------------------------
--  DDL for Synonymn CAP_TIME
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."CAP_TIME" FOR "APP"."CAP_TIME";

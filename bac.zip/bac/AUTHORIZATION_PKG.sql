--------------------------------------------------------
--  DDL for Package Body AUTHORIZATION_PKG
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "VENUBABU"."AUTHORIZATION_PKG" 
is
v_ava_sum_ins     NUMBER(20,2);
--====================================================================================
PROCEDURE select_pat_auth_list (
    v_pre_auth_number                    IN  PAT_AUTHORIZATION_DETAILS.Pre_Auth_Number%type,
    v_claimant_name                      IN  tpa_enr_policy_member.mem_name%type,
    v_received_date                      IN  VARCHAR2,
    v_pat_status_general_type_id         IN  PAT_AUTHORIZATION_DETAILS.Pat_Status_Type_Id%type,
    v_policy_number                      IN  tpa_enr_policy.Policy_Number%TYPE,
    v_member_id                          IN  PAT_AUTHORIZATION_DETAILS.Tpa_Enrollment_Id%TYPE,
    v_sort_var                           IN  VARCHAR2,
    v_sort_order                         IN  VARCHAR2 ,
    v_start_num                          IN  NUMBER ,
    v_end_num                            IN  NUMBER ,
    v_added_by                           IN  NUMBER,
    result_set                           OUT SYS_REFCURSOR
  )
  IS

    v_sql_str                            VARCHAR2(10000) ;
    v_pat_received_date                  PAT_AUTHORIZATION_DETAILS.Pat_Received_Date%TYPE := TO_DATE(v_received_date, 'dd/mm/yyyy');
    TYPE bind_tab_type IS TABLE OF VARCHAR2(250) INDEX BY BINARY_INTEGER ;
    bind_tab                             bind_tab_type;
    i                                    NUMBER(2) := 0;
    v_where                              VARCHAR2(2000);

  BEGIN
    v_sql_str :=
    'select pad.pat_auth_seq_id,
       pad.pat_batch_seq_id,
       pad.parent_pat_auth_seq_id,
       pad.pre_auth_number,
       pad.auth_number,
       pad.pat_status_type_id,
       pad.pat_received_date,
       tep.policy_number,
       gc.description as priority_general_type_id,
       pad.hospitalization_date,
       pad.discharge_date,
       tepm.tpa_customer_id
  from pat_authorization_details pad
  join tpa_enr_policy_member tepm on (pad.member_seq_id=tepm.member_seq_id)
  join tpa_enr_policy_group tepg on (tepm.policy_group_seq_id=tepg.policy_group_seq_id)
  join tpa_enr_policy tep on (tepg.policy_seq_id=tep.policy_seq_id)
  left outer join tpa_general_code gc on (gc.general_type_id=pad.priority_general_type_id)
  where pad.pre_auth_number is not null';


    IF v_pre_auth_number IS NOT NULL THEN
      v_where := v_where  ||' AND pad.pre_auth_number = :v_pre_auth_number ';
       i := i+1;
       bind_tab(i) := UPPER(v_pre_auth_number);
    END IF;



    IF v_policy_number IS NOT NULL THEN
      v_where := v_where  ||' AND tep.policy_number = :v_policy_number';
      i := i+1;
      bind_tab(i) := UPPER(v_policy_number);
    END IF;


    IF v_claimant_name IS NOT NULL THEN
      v_where := v_where  ||' AND tepm.mem_name LIKE :v_claimant_name';
      i := i+1;
      bind_tab(i) := UPPER(v_claimant_name)||'%';
    END IF;



    IF v_pat_received_date IS NOT NULL THEN
      v_where := v_where  ||' AND pad.pat_received_date  BETWEEN :v_pat_received_date_1 AND :v_pat_received_date_2 ';
      i := i+1;
      bind_tab(i) := v_pat_received_date;
      i := i+1;
      bind_tab(i) := v_pat_received_date + 1;
    END IF;

    IF v_pat_status_general_type_id IS NOT NULL THEN
      v_where := v_where  ||' AND pad.pat_status_type_id = :v_pat_status_general_type_id ';
       i := i+1;
       bind_tab(i) := v_pat_status_general_type_id;
    END IF;

    IF v_where IS NOT NULL THEN
      --v_where   := ' WHERE '|| SUBSTR(v_where,5);
      v_sql_str := v_sql_str ||v_where;
    END IF;


    v_sql_str := 'SELECT * FROM
        (SELECT A.*,DENSE_RANK() OVER (ORDER BY '||v_sort_var||' '||v_sort_order||',ROWNUM)
        Q FROM (' ||v_sql_str|| ') A ) WHERE  Q>= :v_start_num AND Q<= :v_end_num ';

    IF bind_tab.FIRST IS NOT NULL THEN
       CASE bind_tab.COUNT
         WHEN 1  THEN OPEN result_set FOR v_sql_str USING bind_tab(1), v_start_num , v_end_num ;
         WHEN 2  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2), v_start_num , v_end_num ;
         WHEN 3  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2) ,bind_tab(3) , v_start_num , v_end_num ;
         WHEN 4  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) , v_start_num , v_end_num ;
         WHEN 5  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5), v_start_num , v_end_num ;
         WHEN 6  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6), v_start_num , v_end_num ;
         WHEN 7  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6),bind_tab(7), v_start_num , v_end_num ;
         WHEN 8  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6),bind_tab(7),bind_tab(8), v_start_num , v_end_num ;
         WHEN 9  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6),bind_tab(7),bind_tab(8),bind_tab(9), v_start_num , v_end_num ;
         WHEN 10 THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6),bind_tab(7),bind_tab(8),bind_tab(9),bind_tab(10), v_start_num , v_end_num ;
        END CASE;
     ELSE
       OPEN result_set FOR v_sql_str USING v_start_num , v_end_num ;
     END IF;

  END select_pat_auth_list;
--====================================================================================  
PROCEDURE select_pat_auth (
    v_pat_auth_seq_id                    IN  pat_authorization_details.pat_auth_seq_id%type,
    v_claim_seq_id                       IN  clm_authorization_details.claim_seq_id%type,
    result_set                           OUT SYS_REFCURSOR  )
IS

 CURSOR clm_cur IS
    SELECT pad.completed_yn,pad.final_app_amount,b.submission_type_id
      FROM clm_authorization_details pad JOIN clm_hospital_details hd on (pad.claim_seq_id=hd.claim_seq_id)
      JOIN clm_batch_upload_details b ON (pad.clm_batch_seq_id=b.clm_batch_seq_id)
     WHERE pad.claim_seq_id = v_claim_seq_id ;
     
  CURSOR prev_appr_cur IS  SELECT COUNT(1) FROM ( SELECT a.claim_seq_id, a.parent_claim_seq_id,a.clm_status_type_id
      FROM clm_authorization_details a
      START WITH a.claim_seq_id = v_claim_seq_id CONNECT BY a.claim_seq_id = PRIOR a.parent_claim_seq_id ) aa
      WHERE aa.CLM_STATUS_TYPE_ID = 'APR' AND aa.claim_seq_id != v_claim_seq_id ;    
   
 clm_rec                             clm_cur%rowtype;
 v_appr_count                        NUMBER(10);

BEGIN
  
  open  clm_cur;
  fetch clm_cur into clm_rec;
  close clm_cur;
    
  OPEN prev_appr_cur;
  FETCH prev_appr_cur INTO v_appr_count;
  CLOSE prev_appr_cur;    
    
 OPEN result_set FOR 
  select CASE WHEN clm_rec.completed_yn = 'Y' THEN nvl(eb.sum_insured,0) - nvl(eb.utilised_sum_insured,0)
              WHEN ( clm_rec.submission_type_id != 'DTR' OR clm_rec.submission_type_id  = 'DTR' AND v_appr_count = 0 )
                   AND eb.sum_insured >= (nvl(eb.sum_insured,0) - (nvl(eb.utilised_sum_insured,0) + NVL( DECODE(clm_rec.final_app_amount,0,NULL,clm_rec.final_app_amount),NVL(pad.tot_approved_amount,0)))) 
                   THEN  (nvl(eb.sum_insured,0) - (nvl(eb.utilised_sum_insured,0) + NVL( DECODE(clm_rec.final_app_amount,0,NULL,clm_rec.final_app_amount), NVL(pad.tot_approved_amount,0))))
             WHEN ( clm_rec.submission_type_id != 'DTR' OR clm_rec.submission_type_id  = 'DTR' AND v_appr_count = 0 )
             AND eb.sum_insured < (nvl(eb.sum_insured,0) - (nvl(eb.utilised_sum_insured,0) + NVL( DECODE(clm_rec.final_app_amount,0,NULL,clm_rec.final_app_amount),NVL(pad.tot_approved_amount,0)))) THEN eb.sum_insured
             WHEN clm_rec.submission_type_id  = 'DTR' AND eb.sum_insured >= ( nvl(eb.sum_insured,0) - (nvl(eb.utilised_sum_insured,0) + NVL(clm_rec.final_app_amount,0))) THEN nvl(eb.sum_insured,0) - (nvl(eb.utilised_sum_insured,0) + NVL(clm_rec.final_app_amount,0))
             WHEN clm_rec.submission_type_id  = 'DTR' AND eb.sum_insured < ( nvl(eb.sum_insured,0) - (nvl(eb.utilised_sum_insured,0) + NVL(clm_rec.final_app_amount,0))) THEN eb.sum_insured
             END  AS ava_sum_insured
  from pat_authorization_details pad
  left outer join pat_batch_upload_details pbud on (pad.pat_batch_seq_id = pbud.pat_batch_seq_id)
  left outer join tpa_enr_policy_member tepm      on (pad.member_seq_id=tepm.member_seq_id)
  left outer join tpa_enr_policy_group pg         on (pg.policy_group_seq_id=tepm.policy_group_seq_id)
  LEFT OUTER JOIN tpa_enr_balance eb              on (pg.policy_group_seq_id = eb.policy_group_seq_id)
  where pad.pat_auth_seq_id=v_pat_auth_seq_id
  and  (tepm.mem_general_type_id != 'PFL' AND tepm.member_seq_id = eb.member_seq_id OR eb.member_seq_id IS NULL OR tepm.member_seq_id IS NULL);

END select_pat_auth;  
--====================================================================================
PROCEDURE select_diagnosys_details (
    v_seq_id         IN  pat_authorization_details.pat_auth_seq_id%type,    
    v_mode           IN  CHAR, -- "PAT" OR "CLM"    
    result_set       OUT SYS_REFCURSOR  )
IS

BEGIN

 IF v_mode='PAT' THEN
   OPEN result_set FOR 
       select dd.diag_seq_id,
             dd.pat_auth_seq_id,
             dd.diagnosys_code,
             dd.primary_ailment_yn,
             tic.short_desc icd_description,
             tic.icd10_seq_id as icd_code_seq_id
        from diagnosys_details dd
        left outer join tpa_icd10_master_details tic on (dd.diagnosys_code=tic.icd_code)
       where dd.pat_auth_seq_id =v_seq_id;
 ELSIF v_mode='CLM' THEN
   OPEN result_set FOR 
       select dd.diag_seq_id,
             dd.pat_auth_seq_id,
             dd.diagnosys_code,
             dd.primary_ailment_yn,
             tic.short_desc icd_description,
             tic.icd10_seq_id as icd_code_seq_id
        from diagnosys_details dd
       join tpa_icd10_master_details tic on (dd.icd_code_seq_id=tic.icd10_seq_id)
       where dd.Claim_Seq_Id =v_seq_id;
 END IF;

END select_diagnosys_details;
--====================================================================================
PROCEDURE select_diagnosys_details (
    v_seq_id              IN  diagnosys_details.pat_auth_seq_id%type,
    v_diag_seq_id         IN  diagnosys_details.diag_seq_id%type,    
    v_mode                IN  CHAR, -- "PAT" OR "CLM"    
    result_set            OUT SYS_REFCURSOR  )
IS

BEGIN

 IF v_mode='PAT' THEN
   OPEN result_set FOR 
       select dd.diag_seq_id,
             dd.pat_auth_seq_id,
             dd.diagnosys_code,
             dd.primary_ailment_yn,
             tic.short_desc icd_description,
             tic.icd10_seq_id icd_code_seq_id
        from diagnosys_details dd
        join tpa_icd10_master_details tic on (dd.icd_code_seq_id=tic.icd10_seq_id)
       where dd.pat_auth_seq_id =v_seq_id
       AND dd.diag_seq_id=v_diag_seq_id;
 ELSIF v_mode='CLM' THEN
   OPEN result_set FOR 
       select dd.diag_seq_id,
             dd.pat_auth_seq_id,
             dd.diagnosys_code,
             dd.primary_ailment_yn,
             tic.short_desc icd_description,
             tic.icd10_seq_id icd_code_seq_id
        from diagnosys_details dd
       join tpa_icd10_master_details tic on (dd.icd_code_seq_id=tic.icd10_seq_id)
       where dd.Claim_Seq_Id =v_seq_id
       AND dd.diag_seq_id=v_diag_seq_id;
 END IF;

END select_diagnosys_details;
--====================================================================================

PROCEDURE select_activity_details (
    v_seq_id         IN  pat_authorization_details.pat_auth_seq_id%type,    
    v_mode           IN  CHAR, -- "PAT" OR "CLM" 
    result_set       OUT SYS_REFCURSOR  )
IS
  v_clm_type CHAR(3);
BEGIN

 SELECT C.CLAIM_TYPE INTO v_clm_type
  FROM CLM_AUTHORIZATION_DETAILS C
  WHERE C.CLAIM_SEQ_ID = v_seq_id;

 IF v_mode='PAT' THEN
   OPEN result_set FOR 
       select tamd.activity_description,
              ACTIVITY_DTL_SEQ_ID,
              pat_auth_seq_id,
              claim_seq_id,
              activity_id,
              activity_seq_id,
              s_no,
              to_char(ad.start_date,'dd/mOn/yyyy') as start_date,
              activity_type,
              code,
              unit_type,
              modifier,
              clinician_id,
              clinician_remarks,
              internal_code,
              package_id,
              bundle_id,
              quantity,
              allow_yn,
              copay_perc,
              gross_amount,
              discount_amount,
              disc_gross_amount,
              patient_share_amount,
              copay_amount,
              co_ins_amount,
              deduct_amount,
              out_of_pocket_amount,
              disc_gross_amount-nvl(patient_share_amount,0) as net_amount,
              allowed_amount,
              null ir_copar,
              null ucr,
              currency_type,
              denial_code,
              remarks,
              ad.converted_acitivty_amt


      from pat_activity_details ad
     left outer join tpa_activity_master_details tamd on (ad.activity_seq_id=tamd.act_mas_dtl_seq_id)
     left outer join tpa_pharmacy_master_details tamd on (ad.activity_seq_id=tamd.act_mas_dtl_seq_id)
     where ad.pat_auth_seq_id =v_seq_id;

 ELSIF v_mode='CLM' THEN
   IF v_clm_type = 'CNH' THEN
     OPEN result_set FOR 
       select tamd.activity_description,
              activity_dtl_seq_id,
              pat_auth_seq_id,
              claim_seq_id,
              activity_id,
              activity_seq_id,
              s_no,
              to_char(AD.start_date,'dd/mOn/yyyy') as start_date,
              activity_type,
              code,
              unit_type,
              modifier,
              clinician_id,
              clinician_remarks,
              internal_code,
              package_id,
              bundle_id,
              quantity,
              allow_yn,
              copay_perc,
              gross_amount,
              discount_amount,
              disc_gross_amount,
              patient_share_amount,
              copay_amount,
              co_ins_amount,
              deduct_amount,
              out_of_pocket_amount,
              net_amount,
              allowed_amount
              ri_copar,
              ucr,

              currency_type,
              denial_code,
              remarks,
              ad.converted_acitivty_amt
      from pat_activity_details ad
      left outer join tpa_activity_master_details tamd on (ad.activity_seq_id=tamd.act_mas_dtl_seq_id)
     where ad.claim_seq_id =v_seq_id;

   END IF;

 END IF;

END select_activity_details;
--====================================================================================
PROCEDURE select_observation_details (
    v_activity_dtl_seq_id         IN  pat_observation_details.activity_dtl_seq_id%type,    
    result_set                OUT SYS_REFCURSOR  )
IS

BEGIN

   OPEN result_set FOR 
       select od.observation_seq_id,
       od.activity_dtl_seq_id,      
       od.value,
       od.observation_type_id as type,
       od.obs_value_type_id as value_type_id,
       od.observation_code_id as code,  
       toc.observation_desc as type_desc,
       tod.observation_code as code_desc,
       toe.value_type as value_type_desc,
       od.remarks

  from pat_observation_details od
  JOIN tpa_observation_type_codes toc on (od.observation_type_id=toc.observation_type_id)
  JOIN tpa_observation_value_codes tod on (od.observation_code_id=tod.observation_code_id)
  JOIN tpa_obser_value_type_codes toe on (od.observation_code_id= toe.obs_value_type_code_id)
 where od.activity_dtl_seq_id =v_activity_dtl_seq_id;

END select_observation_details;
--====================================================================================
PROCEDURE select_observation_detail (
    v_observation_seq_id         IN  pat_observation_details.observation_seq_id%type,    
    result_set                OUT SYS_REFCURSOR  )
IS

BEGIN

   OPEN result_set FOR 
       select od.observation_seq_id,
       od.activity_dtl_seq_id,      
       od.value,
       od.observation_type_id as type,
       od.obs_value_type_id as value_type_id,
       od.observation_code_id as code,  
       toc.observation_desc as type_desc,
       tod.observation_code as code_desc,
       toe.value_type as value_type_desc,
       od.remarks

  from pat_observation_details od
  JOIN tpa_observation_type_codes toc on (od.observation_type_id=toc.observation_type_id)
  JOIN tpa_observation_value_codes tod on(od.observation_code_id=tod.observation_code_id)
  JOIN tpa_obser_value_type_codes toe on (od.obs_value_type_id=toe.obs_value_type_code_id)

 where od.observation_seq_id =v_observation_seq_id;

END select_observation_detail;
--====================================================================================

PROCEDURE select_activity_details (
    v_activity_dtl_seq_id         IN  pat_activity_details.activity_dtl_seq_id%type,    
    result_set                    OUT SYS_REFCURSOR  )
IS



CURSOR pat_cur IS
SELECT pad.hosp_seq_id,ad.code,ad.start_date,ad.activity_type,tip.product_cat_type_id,tep.ins_seq_id,tep.group_reg_seq_id,pad.pat_auth_seq_id,pad.policy_seq_id,
tep.tariff_type_id,null as claim_seq_id
FROM pat_authorization_details pad
join pat_activity_details ad on (ad.pat_auth_seq_id=pad.pat_auth_seq_id)
JOIN tpa_enr_policy tep ON (pad.policy_seq_id=tep.policy_seq_id)
JOIN tpa_ins_product tip ON (tep.product_seq_id=tip.product_seq_id)
WHERE ad.activity_dtl_seq_id=v_activity_dtl_seq_id;

CURSOR clm_cur IS
SELECT hd.hosp_seq_id,ad.code,ad.start_date,ad.activity_type,tip.product_cat_type_id,tep.ins_seq_id,tep.group_reg_seq_id,pad.claim_seq_id,pad.policy_seq_id,
tep.tariff_type_id,null as pat_auth_seq_id 
FROM clm_authorization_details pad
join clm_hospital_details hd on (pad.claim_seq_id=hd.claim_seq_id)
join pat_activity_details ad on (ad.claim_seq_id=pad.claim_seq_id)
JOIN tpa_enr_policy tep ON (pad.policy_seq_id=tep.policy_seq_id)
JOIN tpa_ins_product tip ON (tep.product_seq_id=tip.product_seq_id)
WHERE ad.activity_dtl_seq_id=v_activity_dtl_seq_id;

pat_rec             pat_cur%ROWTYPE;


CURSOR provider_network(v_hosp_seq number,v_product_net_type varchar2) IS
SELECT i.primary_network, ny.network_type, ny.network_yn, gc.sort_no
  FROM tpa_hosp_info i, app.tpa_hosp_network ny, app.tpa_general_code gc
 where ny.hosp_seq_id = i.hosp_seq_id
   and gc.general_type_id = ny.network_type
   and gc.header_type = 'PROVIDER_NETWORK'
   and ny.network_yn = 'Y'
   and i.hosp_seq_id = v_hosp_seq--35939 --35337
   and gc.sort_no =
       (SELECT min(gc.sort_no)
          FROM tpa_hosp_info        i,
               app.tpa_hosp_network ny,
               app.tpa_general_code gc
         where ny.hosp_seq_id = i.hosp_seq_id
           and gc.general_type_id = ny.network_type
           and gc.header_type = 'PROVIDER_NETWORK'
           and ny.network_yn = 'Y'
           and i.hosp_seq_id = v_hosp_seq--35939 --35337 
           and gc.sort_no >=
               (SELECT min(gc.sort_no)
                  FROM tpa_hosp_info        i,
                       app.tpa_hosp_network ny,
                       app.tpa_general_code gc
                 where ny.hosp_seq_id = i.hosp_seq_id
                   and gc.general_type_id = ny.network_type
                   and gc.header_type = 'PROVIDER_NETWORK'
                   and i.hosp_seq_id = v_hosp_seq--35939
                   and gc.general_type_id = v_product_net_type))
 order by gc.sort_no;

provider_rec   provider_network%rowtype;
v_product_network_type    varchar2(20);
v_count   number(10);
v_mode    varchar2(10);

CURSOR dental_cur IS
  SELECT d.tooth_no_required
  FROM dental_rule_tab d
  JOIN pat_activity_details pa ON (pa.code = d.cdt_code)
  WHERE pa.activity_dtl_seq_id = v_activity_dtl_seq_id;

dental_rec dental_cur%ROWTYPE;

BEGIN
 
  OPEN dental_cur;
 FETCH dental_cur INTO dental_rec;
 CLOSE dental_cur;


 OPEN  pat_cur;
 FETCH pat_cur INTO pat_rec;
 CLOSE pat_cur;

 if nvl(pat_rec.pat_auth_seq_id,0)=0 then
 OPEN  clm_cur;
 FETCH clm_cur INTO pat_rec;
 CLOSE clm_cur;
 v_mode:='CLM';
 end if;
 OPEN provider_network(pat_rec.hosp_seq_id,pat_rec.product_cat_type_id);
 FETCH provider_network INTO provider_rec;
 CLOSE provider_network;

   IF pat_rec.tariff_type_id='HSPL' THEN

    v_product_network_type:=provider_rec.network_type;  

   END IF;
   if pat_rec.activity_type='5' then
     select count(1) into v_count from tpa_pharmacy_master_details tamd
    JOIN tpa_activity_type_codes tatc ON (tamd.activity_type_seq_id=tatc.activity_type_seq_id)
    WHERE tamd.activity_code=upper(pat_rec.code)
    AND tamd.start_date <=pat_rec.start_date  and nvl(tamd.end_date,pat_rec.start_date) >=pat_rec.start_date; 
   else
   select count(1) into v_count           
    from tpa_activity_master_details tamd
    JOIN tpa_activity_type_codes tatc ON (tamd.activity_type_seq_id=tatc.activity_type_seq_id)
    JOIN tpa_hosp_tariff_details thtd ON (tamd.act_mas_dtl_seq_id=thtd.activity_seq_id)
    WHERE thtd.hosp_seq_id=pat_rec.hosp_seq_id
    AND thtd.ins_seq_id=pat_rec.ins_seq_id
    AND thtd.network_type=v_product_network_type--pat_rec.product_cat_type_id
    AND tamd.activity_code=upper(pat_rec.code);
   end if;
  if nvl(v_mode,'PAT')!='CLM' then  
   OPEN result_set FOR 
       select 
            activity_dtl_seq_id,
            pad.pat_auth_seq_id,
            pad.claim_seq_id,
            activity_id,
            activity_seq_id,
            s_no,
            pad.start_date,
            activity_type,
            pad.code as activity_code ,
            unit_type,
            modifier,
            clinician_remarks,
            internal_code,
            package_id,
            bundle_id,
            quantity,
            nvl(pad.approvd_quantity,pad.quantity) as approved_quantity,
            allow_yn,
            NVL(copay_perc,0) AS copay_perc,
            gross_amount,
            discount_amount,
            disc_gross_amount,
            patient_share_amount,
            copay_amount,
            co_ins_amount,
            deduct_amount,
            out_of_pocket_amount,
            CASE WHEN SIGN(nvl(pad.disc_gross_amount,0)-nvl(patient_share_amount,0))= -1 THEN 0
                 ELSE nvl(pad.disc_gross_amount,0)-(nvl(patient_share_amount,0)+nvl(pad.out_of_pocket_amount,0)) END as net_amount,
            --in net amount we are deducting out of pockets which is Disallowed amount in provider billed amount(Added by venu)
            allowed_amount,
            pad.currency_type,
            trim(both ';' from regexp_replace(pad.denial_code,'[;]{2,}',';')) as denial_code,
            --pad.remarks,
			decode(nvl(pad.service_type,'ACD'),'ACD',pad.remarks,pad.service_remarks) as remarks,----
            pa.pre_auth_number,
            null as claim_number,
            pad.clinician_id,
            nd.clinician_name,
            pad.approved_amount as approved_amt,
            nvl(tamd.activity_description,md.activity_description)as activity_description,
            pad.unit_price,
            case when (nvl(pad.disc_gross_amount,0)-nvl(pad.patient_share_amount,0))-nvl(pad.approved_amount,0)>0
              then (nvl(pad.disc_gross_amount,0)-nvl(patient_share_amount,0))-nvl(pad.approved_amount,0) else 0 end  as dis_allowed_amount,
            --(pad.disc_gross_amount*pad.benifit_copay)/100 as rule_copay,
            pad.benifit_deductible as rule_deductible,
            null as rule_coinsurence,
            null as rule_outof_pocket,
            pad.unit_discount_amount as unit_discount,
            pad.provider_copay,
            case when nvl(v_count,0)>0 then 'Y' else 'N' end as tariff_yn,
            pad.override_yn,
            pad.override_remarks,
            pad.provider_net_amount,
            pad.approve_yn,
            pad.posology_duration,
            pad.posology,
            trim(both ';' from regexp_replace(pad.denial_desc,'[;]{2,}',';')) as denial_desc,
            pad.service_type,
            pad.service_code,
			isd.service_descreption,
            null ri_copar,
            null ucr,
            null denial_res,-- Manually Entered Remarks
            pad.non_network_co_pay,      ----
            NVL(pad.tooth_no,'-') as tooth_no,
            dental_rec.tooth_no_required as tooth_req_yn,      ----
            pad.internal_desc,
            pad.converted_acitivty_amt,
		pad.mem_service_Code,
		pad.mem_service_desc,
		nvl(pad.Copay_Deduct_Flag,'NA') AS Copay_Deduct_Flag,
		pad.Prov_Copay_Flag,
		CASE WHEN nvl(pa.Area_Cover_Yn,'N')='Y' THEN pad.Area_Of_Cov_Copay 
             WHEN nvl(pa.In_Out_Area_Covr_Yn,'N')='Y' THEN pad.In_Out_Area_Copay 
             WHEN nvl(pa.Out_Area_Cover_Yn,'N')='Y' THEN pad.Out_Area_Copay   END AS Area_Of_Cov_Copay,
             
        CASE WHEN nvl(pa.Area_Cover_Yn,'N')='Y' THEN pad.Area_Of_Cov_Deduct 
             WHEN nvl(pa.In_Out_Area_Covr_Yn,'N')='Y' THEN pad.In_Out_Area_Deduct 
             WHEN nvl(pa.Out_Area_Cover_Yn,'N')='Y' THEN pad.Out_Area_Deduct END AS Area_Of_Cov_Deduct,
             
        CASE WHEN nvl(pa.Area_Cover_Yn,'N')='Y' THEN 
                  CASE WHEN pad.Area_Cp_Dct_Flag='BTH' THEN 'BOTH' ELSE  pad.Area_Cp_Dct_Flag END
             WHEN nvl(pa.In_Out_Area_Covr_Yn,'N')='Y' THEN 
                  CASE WHEN pad.In_Out_Area_Cp_Dct_Flag='BTH' THEN 'BOTH' ELSE  pad.In_Out_Area_Cp_Dct_Flag END
             WHEN nvl(pa.Out_Area_Cover_Yn,'N')='Y' THEN  
                CASE WHEN pad.Out_Area_Cp_Dct_Flag='BTH' THEN 'BOTH' ELSE  pad.Out_Area_Cp_Dct_Flag END
             END AS Area_Cp_Dct_Flag,
        CASE WHEN TRIM(REPLACE(hi.hosp_name,' ','')) LIKE '%ALAHLIHOSPITAL%' THEN 'Y' ELSE 'N' END as al_ahli_yn,
        pad.activity_type_id,
        NVL(pad.carry_for_yn,'N') AS carry_for_yn,
        trim(both ';' from regexp_replace(pad.tpa_denial_code,'[;]{2,}',';')) as tpa_denial_code,
        trim(both ';' from regexp_replace(pad.tpa_denial_desc,'[;]{2,}',';')) as tpa_denial_desc,
       pad.override_remarks_code,
       pad.other_remarks,
       null as alkoot_remarks,
       null as Resub_Remarks
            
  from pat_activity_details pad
  join pat_authorization_details pa on (pad.pat_auth_seq_id=pa.pat_auth_seq_id)
  left outer join tpa_hosp_info hi on (pa.hosp_seq_id=hi.hosp_seq_id)
  left outer join pat_non_network_details nd on (nd.pat_auth_seq_id=pa.pat_auth_seq_id)
  left outer join tpa_activity_master_details tamd on (pad.code=tamd.activity_code)
  left outer join tpa_pharmacy_master_details md on (pad.code=md.activity_code)
  left outer join app.tpa_ip_service_details isd on (isd.service_code = pad.service_code)
 where pad.activity_dtl_seq_id =v_activity_dtl_seq_id;
else 
  OPEN result_set FOR 
       select 
            activity_dtl_seq_id,
            pad.claim_seq_id,
            pad.pat_auth_seq_id,
            activity_id,
            activity_seq_id,
            s_no,
            pad.start_date,
            activity_type,
            pad.code as activity_code ,
            unit_type,
            modifier,
            clinician_remarks,
            internal_code,
            package_id,
            bundle_id,
            quantity,
            nvl(pad.approvd_quantity,pad.quantity) as approved_quantity,
            allow_yn,
            NVL (copay_perc,0) AS copay_perc,
            gross_amount,
            discount_amount,
            disc_gross_amount,
            patient_share_amount,
            copay_amount,
            co_ins_amount,
            deduct_amount,
            out_of_pocket_amount,
            case when (nvl(pa.ucr_flag,'N')='N' and nvl(pa.ri_copar_flag,'N')='N') then  
                      nvl(pad.disc_gross_amount,0)-(nvl(patient_share_amount,0)+nvl(pad.out_of_pocket_amount,0)) 
                 else 
                      pad.net_amount-nvl(pad.out_of_pocket_amount,0) end as net_amount,
             --in net amount we are deducting out of pockets which is Disallowed amount in provider billed amount(Added by venu)
            --pad.net_amount,
            nvl(allowed_amount,0) as allowed_amount,
            pad.currency_type,
            trim(both ';' from regexp_replace(pad.denial_code,'[;]{2,}',';')) as denial_code,
            --pad.remarks,
			decode(nvl(pad.service_type,'ACD'),'ACD',pad.remarks,pad.service_remarks) as remarks,----
            pa.claim_number,
            null as pre_auth_number,
            pad.clinician_id,
            hd.clinician_name,
            pad.approved_amount as approved_amt,
            nvl(tamd.activity_description,md.activity_description) as activity_description,
            pad.unit_price,
            case when (nvl(pa.ucr_flag,'N')='N' and nvl(pa.ri_copar_flag,'N')='N') then 
              (nvl(pad.disc_gross_amount,0)-nvl(pad.patient_share_amount,0))-nvl(pad.approved_amount,0) 
              else 
                nvl(pad.disallowed_amount,0) end as dis_allowed_amount,
           --nvl(pad.disallowed_amount,0) as dis_allowed_amount,
           (pad.disc_gross_amount*pad.benifit_copay)/100 as rule_copay,
            pad.benifit_deductible as rule_deductible,
            null as rule_coinsurence,
            null as rule_outof_pocket,
            pad.unit_discount_amount as unit_discount,
            pad.provider_copay,
            case when nvl(v_count,0)>0 then 'Y' else 'N' end as tariff_yn,
            pad.override_yn,
            pad.override_remarks,
            pad.provider_net_amount,
            pad.approve_yn,
            pad.posology_duration,
            pad.posology,
            trim(both ';' from regexp_replace(pad.denial_desc,'[;]{2,}',';')) as denial_desc,
            pad.service_type,
            pad.service_code,

            pad.ri_copar,
            pad.ucr,
            pad.provider_copay,
            pad.denial_res_dis as denial_res, -- Manually Entered Remarks
            pad.non_network_co_pay,            ----
            NVL(pad.tooth_no,'-') as tooth_no,          ----
            dental_rec.tooth_no_required as tooth_req_yn,
            pad.internal_desc,
            pad.converted_acitivty_amt,
		pad.mem_service_Code,
		pad.mem_service_desc,
		nvl(pad.Copay_Deduct_Flag,'NA') AS Copay_Deduct_Flag,
		pad.Prov_Copay_Flag,
		CASE WHEN nvl(pa.Area_Cover_Yn,'N')='Y' THEN pad.Area_Of_Cov_Copay 
             WHEN nvl(pa.In_Out_Area_Covr_Yn,'N')='Y' THEN pad.In_Out_Area_Copay 
             WHEN nvl(pa.Out_Area_Cover_Yn,'N')='Y' THEN pad.Out_Area_Copay   END AS Area_Of_Cov_Copay,
             
        CASE WHEN nvl(pa.Area_Cover_Yn,'N')='Y' THEN pad.Area_Of_Cov_Deduct 
             WHEN nvl(pa.In_Out_Area_Covr_Yn,'N')='Y' THEN pad.In_Out_Area_Deduct 
             WHEN nvl(pa.Out_Area_Cover_Yn,'N')='Y' THEN pad.Out_Area_Deduct END AS Area_Of_Cov_Deduct,
             
        CASE WHEN nvl(pa.Area_Cover_Yn,'N')='Y' THEN 
                  CASE WHEN pad.Area_Cp_Dct_Flag='BTH' THEN 'BOTH' ELSE  pad.Area_Cp_Dct_Flag END
             WHEN nvl(pa.In_Out_Area_Covr_Yn,'N')='Y' THEN 
                  CASE WHEN pad.In_Out_Area_Cp_Dct_Flag='BTH' THEN 'BOTH' ELSE  pad.In_Out_Area_Cp_Dct_Flag END
             WHEN nvl(pa.Out_Area_Cover_Yn,'N')='Y' THEN  
                CASE WHEN pad.Out_Area_Cp_Dct_Flag='BTH' THEN 'BOTH' ELSE  pad.Out_Area_Cp_Dct_Flag END
             END AS Area_Cp_Dct_Flag,
        CASE WHEN TRIM(REPLACE(ho.hosp_name,' ','')) LIKE '%ALAHLIHOSPITAL%' THEN 'Y' ELSE 'N' END as al_ahli_yn,
        pad.activity_type_id,
            NVL(pad.carry_for_yn,'N') as carry_for_yn,
          trim(both ';' from regexp_replace(pad.tpa_denial_code,'[;]{2,}',';')) as tpa_denial_code,
          trim(both ';' from regexp_replace(pad.tpa_denial_desc,'[;]{2,}',';')) as tpa_denial_desc,
        pad.override_remarks_code,
        pad.other_remarks,
        pad.alkoot_remarks,
        pad.resub_remarks as Resub_Remarks
            
  from pat_activity_details pad
  join clm_authorization_details pa on (pad.claim_seq_id=pa.claim_seq_id)
  left outer join clm_hospital_details hd on (hd.claim_seq_id=pa.claim_seq_id)
  left outer join tpa_hosp_info ho on (hd.hosp_seq_id=ho.hosp_seq_id)
  left outer join tpa_activity_master_details tamd on (pad.code=tamd.activity_code)
  left outer join tpa_pharmacy_master_details md on (pad.code=md.activity_code)
 where pad.activity_dtl_seq_id =v_activity_dtl_seq_id;
end if;  
END select_activity_details;
--====================================================================================
PROCEDURE select_pat_auth_details (
    v_pat_auth_seq_id                           IN  pat_authorization_details.pat_auth_seq_id%type,
    v_auth_result_set                           OUT SYS_REFCURSOR ,
    v_diag_result_set                           OUT SYS_REFCURSOR ,
    v_activity_result_set                       OUT SYS_REFCURSOR ,
    v_observ_result_set                         OUT SYS_REFCURSOR ,
    v_shortfall_details                         OUT SYS_REFCURSOR ,
    v_pat_count                                 OUT SYS_REFCURSOR ,
    v_clm_count                                 OUT SYS_REFCURSOR 	)

IS

CURSOR provider_networks(v_hosp_seq_id  tpa_hosp_info.hosp_seq_id%type) is 
select to_char(wm_concat(case when n.network_yn='Y' then n.network_type end )) as eligible_networks from tpa_hosp_info i join app.tpa_hosp_network n on (i.hosp_seq_id=n.hosp_seq_id)
join tpa_general_code gc on (gc.general_type_id=n.network_type)
where i.hosp_seq_id = v_hosp_seq_id;

pro_network  provider_networks%rowtype;

CURSOR clinician_cur IS
   SELECT ad.hosp_seq_id,ad.clinician_id from  pat_authorization_details ad  WHERE ad.pat_auth_seq_id=v_pat_auth_seq_id;

   cln_rec    clinician_cur%rowtype;

CURSOR clinician_count_cur(v_clinician_id varchar2,v_hosp_seq_id number )IS
   SELECT count(1) FROM app.tpa_hosp_professionals hp
   WHERE hp.professional_id=v_clinician_id AND hp.hosp_seq_id=v_hosp_seq_id;

CURSOR pat_cur IS
    SELECT pad.hospitalization_date,pad.member_seq_id,pad.hosp_seq_id,nd.provider_id,pad.tpa_enrollment_id  ---need alkoot id for count in pre-auth screen
      FROM pat_authorization_details pad 
      join pat_non_network_details nd on (pad.pat_auth_seq_id=nd.pat_auth_seq_id)
     WHERE pad.pat_auth_seq_id = v_pat_auth_seq_id;


CURSOR pat_dup_cur(v_member_seq_id pat_authorization_details.member_seq_id%type) IS
    SELECT pad.hospitalization_date
      FROM pat_authorization_details pad
     WHERE pad.member_seq_id = v_member_seq_id
       AND pad.pat_auth_seq_id != nvl(v_pat_auth_seq_id, 0)
     ORDER BY pad.hospitalization_date desc;  
 cursor unit_cur is 
     select bb.PAT_AUTH_SEQ_ID,aa.GRANULAR_UNIT,bb.QUANTITY,bb.UNIT_TYPE,bb.POSOLOGY_DURATION 
     from pat_activity_details bb 
     join tpa_pharmacy_master_details aa on aa.ACTIVITY_CODE =bb.code 
     where bb.PAT_AUTH_SEQ_ID=v_pat_auth_seq_id;    
CURSOR pat_inv_status IS
     SELECT inv_status FROM
      (SELECT inv_status FROM app.tpa_fraud_inv_details WHERE pat_auth_seq_id = v_pat_auth_seq_id order by inv_seq_id desc)
     WHERE rownum =1;
v_inv_status tpa_fraud_inv_details.inv_status%TYPE;  
     
/*CURSOR Processed_by IS 
       SELECT contact_name 
              FROM tpa_user_contacts 
              WHERE contact_seq_id = (SELECT assigned_to_user FROM 
                                          (SELECT assigned_to_user,ROWNUM R FROM
                                                  (select assigned_to_user 
                                                       from assign_users 
                                                     where pat_gen_detail_seq_id= v_pat_auth_seq_id  
                                                     ORDER BY assign_users.added_date DESC)) WHERE R=2);    */ 
   v_tot_units  number(10);
   v_msg    varchar2(1000);
  CURSOR srtfll_cur IS
    SELECT sd.srtfll_status_general_type_id
    FROM SHORTFALL_DETAILS sd
    WHERE sd.shortfall_seq_id = (SELECT MAX(S.SHORTFALL_SEQ_ID)
                                 FROM SHORTFALL_DETAILS s
                                 WHERE S.PAT_GEN_DETAIL_SEQ_ID = v_pat_auth_seq_id
                                )
    AND sd.PAT_GEN_DETAIL_SEQ_ID = v_pat_auth_seq_id;
    
   v_count  number(10);
   v_alert  varchar2(1000):=null;
   pat_rec  pat_cur%rowtype; 
  -- v_processed_by                      VARCHAR2(500);
  v_shrtfll_status  VARCHAR2(10);
  
BEGIN
  OPEN srtfll_cur;
  FETCH srtfll_cur INTO v_shrtfll_status;
  CLOSE srtfll_cur;
  
  open clinician_cur;
  fetch clinician_cur into cln_rec;
  close clinician_cur;

  open clinician_count_cur(cln_rec.clinician_id,cln_rec.hosp_seq_id);
  fetch clinician_count_cur into v_count;
  close clinician_count_cur;

  open pat_cur;
  fetch pat_cur into pat_rec;
  close pat_cur;

  /*FOR rec IN pat_dup_cur(pat_rec.member_seq_id) LOOP
    IF trunc(rec.hospitalization_date) = trunc(pat_rec.hospitalization_date)  THEN
      v_alert:='Duplicate Pre_auth ';
    END IF;
  END LOOP;*/--commented as per dr.Yasmin

   open provider_networks(pat_rec.hosp_seq_id);
  fetch provider_networks into pro_network;
  close provider_networks;
  
  /*  OPEN Processed_by;
     FETCH Processed_by INTO v_processed_by;
      CLOSE Processed_by; */
  open pat_inv_status;
  fetch pat_inv_status into v_inv_status;
  close pat_inv_status;   

v_msg:=NULL;           
for unit_rec in unit_cur loop


if unit_rec.UNIT_TYPE='LOSE' THEN
v_tot_units:= unit_rec.QUANTITY;
elsif unit_rec.UNIT_TYPE='PCKG' THEN
v_tot_units:=unit_rec.GRANULAR_UNIT*unit_rec.QUANTITY;
end if;
if v_tot_units>=270 then
v_msg:=case when v_msg IS NOT NULL then case when v_msg like '%Number of quantities exceeds limit%' then v_msg else v_msg||';'||'Number of quantities exceeds limit' end else 'Number of quantities exceeds limit' end;
end if;

if unit_rec.POSOLOGY_DURATION>=60 then

v_msg:=case when v_msg IS NOT NULL then case when v_msg like '%Duration of medication exceeds limit%' then v_msg else v_msg||';'||'Duration of medication exceeds limit' end else 'Duration of medication exceeds limit' end;
end if;
end loop;




 OPEN v_auth_result_set FOR 
  select pad.pat_auth_seq_id,
          pad.pat_batch_seq_id,
          pad.claim_seq_id,
          case when v_alert is not null then v_alert else null end  as dup_pat,
          pad.parent_pat_auth_seq_id,
          pad.pat_received_date AS pat_received_date,
          pad.source_type_id,
          case when nvl(v_count,0)=0 then 'Clinician is not exist under this provider, please check with network department.' end as clinician_status,
          pad.hospitalization_date,
          pad.discharge_date,
          pad.claim_sub_type,
          pad.member_seq_id,
          tepm.tpa_enrollment_id,
          pad.pre_auth_number,
          pad.auth_number,
          tepm.mem_name ||' '|| tepm.mem_last_name||' '|| tepm.family_name as mem_name,----
          pad.mem_age,
          pad.ins_seq_id,
          pad.hosp_seq_id,
          pad.policy_seq_id,
          (ep.policy_number||'('||ip.product_cat_type_id||')') as policy_number,
          (gr.group_name||'('||gr.group_id||')') as corp_name,
          pad.tpa_office_seq_id,
          pad.assign_user_seq_id,
          ep.enrol_type_id,
          pad.emirate_id,
          pad.authorization_id,
          pad.encounter_type_id,
          pad.encounter_start_type,
          pad.encounter_end_type,
          pad.encounter_facility_id,
          pad.authorization_type_id,
          pad.maternity_allowed_amt,
          --nvl(pad.ava_sum_insured,(nvl(eb.sum_insured,0) - nvl(eb.utilised_sum_insured,0)))  as ava_sum_insured, 
          CASE WHEN pad.completed_yn = 'Y' THEN nvl(eb.sum_insured,0) - nvl(eb.utilised_sum_insured,0)
               WHEN (nvl(eb.sum_insured,0) - (nvl(eb.utilised_sum_insured,0) + NVL(pad.tot_approved_amount,0))) <= nvl(eb.sum_insured,0) THEN (nvl(eb.sum_insured,0) - (nvl(eb.utilised_sum_insured,0) + NVL(pad.tot_approved_amount,0)))
               ELSE eb.sum_insured
          END AS ava_sum_insured,
          pad.tot_gross_amount,
          pad.tot_discount_amount,
          pad.tot_disc_gross_amount,
          pad.tot_patient_share_amount,
          CASE WHEN SIGN(nvl(pad.tot_disc_gross_amount,0)-nvl(pad.tot_patient_share_amount,0)) = -1 THEN 0
               ELSE (nvl(pad.tot_disc_gross_amount,0)-nvl(pad.tot_patient_share_amount,0)) END as tot_net_amount,
          pad.tot_allowed_amount,
          case when (pad.tot_disc_gross_amount-nvl(pad.tot_patient_share_amount,0))-nvl(pad.tot_approved_amount,0)>0 then
             (pad.tot_disc_gross_amount-nvl(pad.tot_patient_share_amount,0))-nvl(pad.tot_approved_amount,0) else 0 end  as dis_allowed_amount,
          nvl(pad.tot_approved_amount,0) as final_app_amount,
          pad.pat_enhanced_yn,
          pad.currency_type,
          /*case when pad.tot_approved_amount>0 then 'APR'
               when pad.tot_approved_amount<1  then 'REJ'

            ELSE pad.pat_status_type_id END AS pat_status_type_id,*/
          pad.pat_status_type_id AS pat_status_type_id,
          pad.maternity_yn,
          pad.manual_process_req_yn,
          pad.denial_reason,
          pad.remarks,
          pad.completed_yn,
          pad.completed_date,
          pad.added_by,
          pad.added_date,
          pad.updated_by,
          pad.updated_date,
          pad.tot_approved_amount,
          pad.clinician_id,
         nvl(thi.hosp_name,nd.provider_name) as hosp_name,
         tha.address_1 || ' ' || tha.address_2 || ' ' || tha.address_3 as hosp_address,
         case when pad.hosp_seq_id is not null then nvl(thi.hosp_licenc_numb,nd.provider_id)||'('||thi.primary_network||')' else nvl(thi.hosp_licenc_numb,nd.provider_id) end as provider_id,
         thi.primary_network,
         tii.ins_comp_name,
         tii.ins_comp_code_number as payer_id,
         account_info_pkg.get_gen_desc(tepm.gender_general_type_id,'G') AS gender,
         nvl(case when nvl(pad.network_yn,'N')='Y' then thp.contact_name||decode(thp.contact_name,null,thp.contact_name,'('||thp.professional_id||')') else nd.clinician_name end,nd.clinician_name)   as clinician_name,
         pad.presenting_complaints,
         pad.medical_opinion_remarks,
         pad.system_of_medicine_type_id,
         pad.accident_related_type_id,
         pad.priority_general_type_id,
         pad.network_yn,
         pad.requested_amount,
         nd.city_type_id,
         tcc.city_description,
         sc.state_name,
         cc.country_name,
         nd.state_type_id,
         nd.country_type_id,
         nd.provider_address,
         nd.pincode,
         pad.benifit_type as benifit_types,
         pad.gravida,
         pad.para,
         pad.live,
         pad.abortion,
         pad.currency_type,
         case when nvl(pad.parent_pat_auth_seq_id,0)!=0  then 'N' ELSE 'Y' END AS fresh_yn,
         ep.effective_from_date as policy_start_date,
         ep.effective_to_date as policy_end_date,
         nc.description as nationality,
         --nvl(eb.sum_insured,0) - nvl(eb.utilised_sum_insured,0) AS ava_sum_insured,
         eb.sum_insured,
         ip.product_name,
         tii.payer_authority,
         uc.contact_name as assigned_to,
         pro_network.eligible_networks as eligible_networks,
         to_char(tepm.date_of_inception, 'DD/MM/YYYY') as pat_mem_insp_date, --Insure Date
         to_char(tepm.date_of_exit,'DD/MM/YYYY') as pat_mem_exit_date,
         case when nvl(tepm.vip_yn,'N')='N' then 'No' else 'Yes' end as vip_yn,

         pad.Oral_diagnosis as Oraldiagnosis,
         pad.Oral_services as Oralservices,
         pad.Orala_Aproved_amount as OralaAprovedamount,
         pad.Oral_system_Status as OralORsystemStatus,
         pad.Oral_diagnosis_revised as OralDiagnosisRevised,
         pad.Oral_services_revised as OralServicesRevised,
         pad.Orala_Aproved_amount_revised as OralaAprovedAmountRevised,
         nvl(thi.hosp_licenc_numb,nd.provider_id) as hospital_id ,
         thi.remarks as PROVIDER_SPECIFIC_REMARKS,
         pad.lmp_date,pad.conception_type,
         pad.delvry_mod_type,
         CASE WHEN pad.benifit_type IN ('MTI', 'OMTI', 'IMTI') THEN authorization_pkg.get_nat_concp_valid_msg(pad.member_seq_id,'PAT',pad.conception_type)
              ELSE null END as mat_alert_msg,
         pad.dur_ailment,
         pad.duration_flag,
         pad.delvry_mod_type as delvry_mod_type,
		 pad.REQ_AMT_CURRENCY_TYPE,
         pad.CONVERTED_AMOUNT,
         pad.CONVERTED_AMOUNT_CURRENCY_TYPE,
         pad.CONVERSION_RATE,
         nvl(pad.REQ_AMT_CURRENCY_TYPE,cur.currency_id) as REQ_AMT_CURRENCY_TYPE1,
         pad.converted_final_approved_amt,
         pad.oth_tpa_ref_no,
         NVL(pad.process_type,'RGL') AS process_type,
		 pad.treatment_type as treatment_type,
         od.ORTHO_SEQ_ID,
         od.SOURCE_SEQ_ID,
         od.DENTO_CLASS_I,
         od.DENTO_CLASS_II,
         od.DENTO_CLASS_II_TEXT,
         od.DENTO_CLASS_III,
         od.DENTO_CLASS_III_TEXT,
         od.SKELE_CLASS_I,
         od.SKELE_CLASS_II,
         od.SKELE_CLASS_III,
         od.OVERJET_MM,
         od.REV_OVERJET_MM,
         od.REV_OVERJET_YN,
         od.CROSSBITE_ANT,
         od.CROSSBITE_POST,
         od.CROSSBITE_BETW,
         od.OPENBIT_ANT,
         od.OPENBIT_POST,
         od.OPENBIT_LATE,
         od.CONT_POINT_DISP,
         od.OVERBIT_DEEP as OVERBITE,
         --od.OVERBIT_COMP,
         --od.OVERBIT_INCOMP,
         od.OVERBIT_PATA,
         od.OVERBIT_GING,
         od.HYPO_QUAD1,
         od.HYPO_QUAD2,
         od.HYPO_QUAD3,
         od.HYPO_QUAD4,
         od.OTHERS_IMPEDED,
         od.OTHERS_IMPACT,
         od.OTHERS_SUBMERG,
         od.OTHERS_SUPERNUM,
         od.OTHERS_RETAINE,
         od.OTHERS_ECTOPIC,
         od.OTHERS_CRANIO,
         od.AC_MARKS,
         od.iotn_remark as iotn,
         od.crossbite_ant_mm,
         od.crossbite_prst_mm,
         od.crossbite_betw_mm,
         od.cont_point_disp_mm,
         pad.treatment_type,
		 pad.ptnr_seq_id partner_name,  ---newly added for partner
         pad.onl_pat_auth_seq_id,---newly added for partner
         pad.onl_pre_auth_refno,  ---newly added for partner
         pad.override_remarks,
		 pad.event_no as event_no,
         lp.prod_policy_seq_id, ---- newly added for policy tob 
      pad.internal_remarks,   --- added newly 
      CASE WHEN pad.pat_status_type_id  IN ('APR','REJ','PCN','PCO')  THEN  
                   to_char(pad.completed_date,'dd/mm/yyyy hh:mi Am') END as decision_date,
       CASE WHEN pad.pat_status_type_id  IN ('APR','REJ','PCN','PCO') THEN 
            nvl((select contact_name from app.tpa_user_contacts c where c.contact_seq_id= pad.processed_by),uc.contact_name)
                 END  
            as processed_by,
      NVL(PAD.MAT_COMPLCTON_YN,'N') AS MAT_COMPLCTON_YN,
            nvl(uc.vip_pat_rej,'N') vip_pat_rej,
            au.assigned_to_user,
            uc.tpa_office_seq_id ,
      ps.line_of_treatment, ------NEWLY ADDED FOR PARTNER LOGIN ENHANCEMENT     
      pad.clinician_mail as clinician_email,
      PAD.PAT_STATUS_TYPE_ID||'-'||COALESCE(v_shrtfll_status, CASE WHEN PAD.APPEAL_YN = 'Y' THEN 'APL' END, (CASE WHEN NVL(PAD.PARENT_PAT_AUTH_SEQ_ID, 0) > 0 THEN 'ENH' END))  AS IN_PROGESS_STATUS,
      PAD.APPEAL_REMARK,
      PAD.APPEAL_YN,
      CASE WHEN PC.FILE_DESC = 'APL' AND PC.IMAGE_FILE IS NOT NULL THEN 'Y' ELSE 'N' END AS DOC_YN,
      TO_CHAR(PAD.Appeal_Date, 'DD/MM/RRRR HH12:MI Am') AS APPEAL_DATE,
           ----- ADDED IN COUNTER FRAUD CR
      case when pad.status_code_id is not null and nvl(pad.suspect_veri_check,'N')='N' then 'Y' else 'N' end as fraud_yn,
      NVL(pad.suspect_veri_check,'N') AS suspect_veri_check,
      CASE WHEN v_inv_status = 'FD' and  pad.status_code_id = 'SUSP' THEN 'Y' ELSE 'N' END as fraud_det_yn,
      v_msg as alt_msg, 
     (select a.relship_description from app.tpa_relationship_code a where a.relship_type_id = tepm.relship_type_id) relationship_desc,
      case when pad.benifit_type in('MTI','IMTI','OMTI')then case when tepm.RELSHIP_TYPE_ID IN('NSF', 'YSP') THEN 'Y' ELSE 'N' END else null end AS COLOUR_YN ,
     tepm.member_remarks,
     CASE WHEN pad.source_type_id NOT IN ('PLPR','ONL1') THEN pad.clinician_speciality ELSE spm.specialty END as CLINICIAN_SPECIALITY         ,
      nvl(pad.appeal_count,0) as   appeal_count
            
    from pat_authorization_details pad
    left join ORTHODONTIC_DETAILS_TAB od on (od.source_seq_id = pad.pat_auth_seq_id)
    join tpa_enr_policy ep on (ep.policy_seq_id=pad.policy_seq_id)
    join tpa_ins_product ip on (ip.product_seq_id=ep.product_seq_id)
    left outer join tpa_group_registration gr  on (gr.group_reg_seq_id=ep.group_reg_seq_id)
    left outer join tpa_enr_policy_member tepm ON (pad.member_seq_id=tepm.member_seq_id)
    left outer join tpa_enr_policy_group pg    on (pg.policy_group_seq_id=tepm.policy_group_seq_id)
    left outer join tpa_hosp_info thi          on (pad.hosp_seq_id = thi.hosp_seq_id)
    left outer join tpa_hosp_address tha       on (thi.hosp_seq_id = tha.hosp_seq_id)
    join tpa_ins_info tii                      on (pad.ins_seq_id = tii.ins_seq_id)
    left outer join tpa_hosp_professionals thp ON ((pad.clinician_id=thp.professional_id) AND pad.hosp_seq_id = thp.hosp_seq_id)
    left outer join pat_non_network_details nd ON (nd.pat_auth_seq_id=pad.pat_auth_seq_id)
    left outer join  tpa_country_code cc       ON (cc.country_id=nd.country_type_id)
    left outer join tpa_state_code sc          ON (sc.state_type_id=nd.state_type_id)
    left outer join tpa_city_code tcc          ON (tcc.city_type_id=nd.city_type_id)
    left outer join tpa_nationalities_code nc  on (nc.nationality_id=tepm.nationality_id)
    LEFT OUTER JOIN tpa_enr_balance eb         ON (pg.policy_group_seq_id = eb.policy_group_seq_id)
    LEFT OUTER JOIN assign_users au on (au.assign_users_seq_id=pad.assign_user_seq_id)
    left outer join tpa_user_contacts uc            on (uc.contact_seq_id=au.assigned_to_user)
    left join tpa_currency_code cur on(tha.country_id = cur.country_id )
	left outer join tpa_ins_prod_policy lp        on(lp.policy_seq_id=pad.policy_seq_id)  --- newly added for policy tob
	--join tpa_partner_info ptr on (pad.ptnr_seq_id = ptr.ptnr_seq_id)   ----newly added for partner
    left outer join shortfall_details sd on (pad.pat_auth_seq_id=sd.pat_gen_detail_seq_id)
     left outer join preauth_submission ps   on(pad.onl_pat_auth_seq_id = ps.onl_pat_auth_seq_id) ------NEWLY ADDED FOR PARTNER LOGIN ENHANCEMENT        
    LEFT JOIN pat_clm_docs_tab pc ON (pc.pat_clm_seq_id = pad.pat_auth_seq_id)
    LEFT OUTER JOIN dha_clnsn_specialties_master spm on (spm.specialty_id = pad.clinician_speciality)
    where pad.pat_auth_seq_id = v_pat_auth_seq_id 
    and  (tepm.mem_general_type_id != 'PFL' AND tepm.member_seq_id = eb.member_seq_id OR eb.member_seq_id IS NULL OR tepm.member_seq_id IS NULL);

 OPEN v_diag_result_set FOR 
       select dd.diag_seq_id,
             dd.pat_auth_seq_id,
             tic.icd_code as diagnosys_code,
             dd.primary_ailment_yn,
             tic.icd10_seq_id as icd_code_seq_id,
             tic.short_desc as icd_description
        from diagnosys_details dd
        left outer join tpa_icd10_master_details tic on (dd.diagnosys_code=tic.icd_code)
       where dd.pat_auth_seq_id =v_pat_auth_seq_id
   order by dd.diag_seq_id;

  OPEN v_activity_result_set FOR 
       select ad.activity_dtl_seq_id,
       ad.pat_auth_seq_id,
       ad.activity_id,
       ad.start_date,
       ad.s_no,
       ad.activity_type,
       ad.code as code,
       ad.quantity,
       CASE WHEN SIGN(ad.disc_gross_amount-ad.patient_share_amount) = -1 THEN 0 
            ELSE (ad.disc_gross_amount-(nvl(ad.patient_share_amount,0)+nvl(ad.out_of_pocket_amount,0))) END as net_amount,
       ad.clinician_id,
       ad.allow_yn,
       case when ad.remarks like ';%' then substr(ad.remarks,2) else ad.remarks end as remarks,
       nvl(tamd.activity_description,md.activity_description) as activity_description,
       ad.activity_seq_id,
       account_info_pkg.get_gen_desc(ad.modifier,'G') AS modifier,
       case when ad.unit_type='PCKG' THEN 'Package'
            when ad.unit_type='LOSE' THEN 'Loose' 
            when ad.unit_type='NA' THEN 'NA' else null end as unit_type,
       ad.gross_amount,
       ad.discount_amount,
       ad.disc_gross_amount,
       ad.patient_share_amount,
       --(case when ad.denial_code='error' then ad.denial_desc else tdc.denial_description end) as denial_desc,
       case when ad.denial_code like ';%' then replace(substr(ad.denial_code,2),'-','ALK') else replace(ad.denial_code,'-','ALK-')end as denial_code,
       case when ad.denial_desc like ';%' then substr(ad.denial_desc,2) else ad.denial_desc end as denial_desc,
       ad.allowed_amount,
       ad.approved_amount approved_amt,
       ad.out_of_pocket_amount,
       ad.co_ins_amount,
       ad.approvd_quantity  as approved_quantity,
       ad.unit_price,
       ad.override_yn,
       ad.override_remarks,
       case when (nvl(ad.disc_gross_amount,0)-nvl(ad.patient_share_amount,0))-nvl(ad.approved_amount,0)>0
              then ((nvl(ad.disc_gross_amount,0)-nvl(patient_share_amount,0))-nvl(ad.approved_amount,0)) else 0 end  as dis_allowed_amount,
       ad.service_type,
       ad.service_code,
       isd.service_descreption as service_description,
       ad.tooth_no,
	   /*case when ad.activity_type_id='DRG' then
       case when (select count(1) from tpa_pharmacy_master_details where activity_code=ad.code)>0 then 'N' else 'Y' end end 
       as */ null as new_pharmacy_yn,
       nvl(ad.internal_desc, tamd.short_description) as internal_desc
       
      from pat_activity_details ad
      left outer join tpa_activity_master_details tamd on (ad.code=tamd.activity_code)
      left outer join tpa_pharmacy_master_details md on (ad.code = md.activity_code and ad.start_date between md.start_date and md.end_date)
      left outer join app.tpa_ip_service_details isd on (isd.service_code=ad.service_code)
      where ad.pat_auth_seq_id =v_pat_auth_seq_id
     order by ad.activity_dtl_seq_id;

  OPEN v_observ_result_set FOR 
       select od.observation_seq_id,
       od.activity_dtl_seq_id,
       od.value,
       od.observation_type_id as type,
       od.obs_value_type_id as value_type_id,
       od.observation_code_id as code 
  from pat_observation_details od
  join pat_activity_details ad on (od.activity_dtl_seq_id=ad.activity_dtl_seq_id)
 where ad.pat_auth_seq_id =v_pat_auth_seq_id;

 OPEN v_shortfall_details FOR
   select a.pat_auth_seq_id,
       b.shortfall_seq_id,
       b.shortfall_id,
       c.description as shortfall_type,
       DECODE(b.srtfll_status_general_type_id,'OPN','Open','RES','Responded','CLS','Closed','ORD','Overridden') AS srtfll_status_general_type_id,
       /*CASE WHEN b.srtfll_status_general_type_id IN ('CLS', 'RES') THEN*/
         to_char(b.srtfll_received_date, 'DD/MM/RRRR HH:MI:SS AM') as srtfll_received_date,
      /* ELSE*/
         to_char(b.srtfll_sent_date, 'DD/MM/RRRR HH:MI:SS AM') 
     /*  END */as srtfll_sent_date
       
  from pat_authorization_details a
  join shortfall_details b on (a.pat_auth_seq_id=b.pat_gen_detail_seq_id)
  join tpa_general_code c on (c.general_type_id=b.srtfll_general_type_id)
 where a.pat_auth_seq_id =v_pat_auth_seq_id
 order by b.shortfall_id asc; 
 
 
   ------------*******DISPLAY PRE_AUTH AND CLAIM COUNT IN CLAIM GENERAL SCREEN******--------------
 
 OPEN v_pat_count  FOR 
 SELECT   count(1) as pat_count , sum(case status_code_id when 'SUSP' then 1 else 0 end) as cfd_tag_cnt   -- added in CFD CR
   FROM pat_authorization_details a 
 WHERE   a.member_seq_id = pat_rec.member_seq_id 
 AND  a.pre_auth_number is not null AND a.pat_enhanced_yn = 'N';-----newly change due to renewal policy
 
 
 OPEN v_clm_count  FOR 
 SELECT count(1) as clm_count , sum(case status_code_id when 'SUSP' then 1 else 0 end) as cfd_tag_cnt  -- added in CFD CR
   FROM clm_authorization_details  a 
 WHERE  a.member_seq_id = pat_rec.member_seq_id and a.claim_number is not null;-----newly change due to renewal policy
 
 -----------------------------------------------

END select_pat_auth_details; 
--===============================================================================
PROCEDURE save_pat_batch_details( v_pat_batch_seq_id               IN OUT pat_batch_upload_details.pat_batch_seq_id%TYPE,
                                  v_transaction_date               IN pat_batch_upload_details.transaction_date%TYPE,
                                  v_record_count                   IN pat_batch_upload_details.record_count%TYPE,
                                  v_disposition_flag               IN pat_batch_upload_details.disposition_flag%TYPE,
                                  v_sender_id                      IN pat_batch_upload_details.sender_id%type,
                                  v_receiver_id                    IN pat_batch_upload_details.receiver_id%type,
                                  v_added_by                       IN pat_batch_upload_details.Added_By%TYPE)
IS

BEGIN

 IF NVL(v_pat_batch_seq_id,0)=0 THEN
   INSERT INTO pat_batch_upload_details
     (pat_batch_seq_id,
      received_date,
      transaction_date,
      record_count,
      disposition_flag,
      sender_id,
      receiver_id,
      added_by,
      added_date)
   VALUES
     (pat_batch_upload_detail_SEQ.Nextval,
      SYSDATE,
      v_transaction_date,
      v_record_count,
      v_disposition_flag,
      v_sender_id,
      v_receiver_id,
      v_added_by,
      SYSDATE) RETURN pat_batch_seq_id INTO v_pat_batch_seq_id;
 END IF;


END save_pat_batch_details;                                  
--===============================================================================

PROCEDURE save_pat_details(v_pat_auth_seq_id            in out pat_authorization_details.pat_auth_seq_id%type,
                           v_parent_pat_auth_seq_id     in pat_authorization_details.parent_pat_auth_seq_id%type,
                           v_pat_received_date          in pat_authorization_details.pat_received_date%type,
                           v_discharge_date             IN pat_authorization_details.discharge_date%type,
                           v_source_type_id             in pat_authorization_details.source_type_id%type,
                           v_hospitalization_date       in pat_authorization_details.hospitalization_date%type,
                           v_member_seq_id              in pat_authorization_details.member_seq_id%type,
                           v_tpa_enrollment_id          in pat_authorization_details.tpa_enrollment_id%type,
                           v_pre_auth_number            in out pat_authorization_details.pre_auth_number%type,
                           v_auth_number                in pat_authorization_details.auth_number%type,
                           v_mem_name                   in pat_authorization_details.mem_name%type,
                           v_mem_age                    in pat_authorization_details.mem_age%type,
                           v_ins_seq_id                 in pat_authorization_details.ins_seq_id%type,
                           v_hosp_seq_id                in pat_authorization_details.hosp_seq_id%type,
                           v_policy_seq_id              in pat_authorization_details.policy_seq_id%type,
                           v_emirate_id                 in pat_authorization_details.emirate_id%type,
                           v_encounter_type_id          in pat_authorization_details.encounter_type_id%type,
                           v_encounter_facility_id      in pat_authorization_details.encounter_facility_id%type,
                           v_encounter_start_type       IN pat_authorization_details.encounter_start_type%type,
                           v_encounter_end_type         IN pat_authorization_details.encounter_end_type%type,
                           v_remarks                    in pat_authorization_details.remarks%type,
                           v_added_by                   in number,
                           v_clinician_id               in pat_authorization_details.clinician_id%type,
                           v_system_of_medicine_type_id in pat_authorization_details.system_of_medicine_type_id%type,
                           v_accident_related_type_id   in pat_authorization_details.Accident_Related_Type_Id%TYPE,
                           v_priority_gen_type_id       in pat_authorization_details.priority_general_type_id%TYPE,
                           v_network_yn                 in pat_authorization_details.network_yn%type,
                           v_provider_name              in pat_non_network_details.provider_name%type,
                           v_provider_id                in pat_non_network_details.provider_id%type,
                           v_city_type_id               in pat_non_network_details.city_type_id%type,
                           v_state_type_id              in pat_non_network_details.state_type_id%type,
                           v_country_type_id            in pat_non_network_details.country_type_id%type,
                           v_provider_address           in pat_non_network_details.provider_address%type,
                           v_pincode                    in pat_non_network_details.pincode%type,
                           v_requested_amount           in pat_authorization_details.requested_amount%type,
                           v_benifit_type               in pat_authorization_details.benifit_type%type,
                           v_gravida                    in pat_authorization_details.gravida%type,
                           v_para                       in pat_authorization_details.para%type,
                           v_live                       in pat_authorization_details.live%type,
                           v_abortion                   in pat_authorization_details.abortion%type,
                           v_selection_type             in varchar2,--PAT,'ENH'--enhancement
                           v_currency_type              in pat_authorization_details.currency_type%type,
                           v_clinician_name             in pat_non_network_details.clinician_name%type,
                           v_ava_sum_insured            in pat_authorization_details.ava_sum_insured%type,
                          ---------------------------------------------------------------------------------
                           v_Oral_diagnosis            	in pat_authorization_details.Oral_diagnosis%type,
                           v_Oral_services              in pat_authorization_details.Oral_services%type,
                           v_Orala_Aproved_amount      	in pat_authorization_details.Orala_Aproved_amount%type,
                           v_Oral_diagnosis_revised       in pat_authorization_details.Oral_diagnosis_revised%type,
                           v_Oral_services_revised        in pat_authorization_details.Oral_services_revised%type,
                           v_Orala_Aproved_amount_revised in pat_authorization_details.Orala_Aproved_amount_revised%type,
                           v_Oral_system_Status			    in pat_authorization_details.Oral_system_Status%type,
                           -------------------------------------------------------------------------------
                           v_nat_conception          IN pat_authorization_details.conception_type%type,
                           v_lmp                     IN pat_authorization_details.lmp_date%type,
                           ------------------------------------------------------------------------------Currency Conversion
                           v_process_type                IN pat_authorization_details.process_type%TYPE,
                           v_req_amt_currency_type       IN pat_authorization_details.Req_Amt_Currency_Type%TYPE:=NULL, 
                           v_converted_amount            IN pat_authorization_details.Converted_Amount%TYPE:=NULL,  
                           v_converted_amt_currency_type IN pat_authorization_details.Converted_Amount_Currency_Type%TYPE:=NULL,
                           v_conversion_rate             IN pat_authorization_details.Conversion_Rate%TYPE:=NULL,
                           v_oth_tpa_ref_no              IN pat_authorization_details.oth_tpa_ref_no%TYPE:=NULL,
						               v_treatment_type          IN pat_authorization_details.treatment_type%TYPE:= null,
                           v_mode_of_delvry              IN pat_authorization_details.delvry_mod_type%TYPE :=NULL,
                           ------------------------------------------------------------------------------  partner preauth
					   --- v_partner_name             in tpa_partner_info.partner_name%type, --NEWLY ADDED PARTNER
                           v_ptnr_seq_id                in tpa_partner_info.ptnr_seq_id%type,--NEWLY ADDED PARTNER
                           v_onl_pat_auth_seq_id     in pat_authorization_details.onl_pat_auth_seq_id%type, --newly added for partner
                           v_onl_pre_auth_refno      in pat_authorization_details.onl_pre_auth_refno%type,--newly added for partner
                           --------------------------------------------------------                          
						               v_event_no                in pat_authorization_details.event_no%TYPE,
                           v_MAT_COMPLCTON_YN        IN pat_authorization_details.MAT_COMPLCTON_YN%TYPE,
                           v_clinician_mail          in pat_authorization_details.clinician_mail%TYPE, -----NEWLY ADDED FOE ALAHALI ENHANCEMENT
                           v_clinician_spec          in pat_authorization_details.clinician_speciality%type,
                           v_rows_processed             out number,
                           v_past_history               in pat_authorization_details.past_history%type:= null,
                           v_duration_above_illness              in pat_authorization_details.duration_above_illness%type:= null,
                           v_duration_above_illness_time         in pat_authorization_details.duration_above_illness_time%type:= null,
                           v_since_when                          in pat_authorization_details.since_when%type:= null,
                           v_since_when_time                     in pat_authorization_details.since_when_time%type:= null,
                           v_clinician_speciality    in pat_authorization_details.clinician_speciality%type:= null,
                           v_consultation_type       in pat_authorization_details.consultation_type%type:= null,
                           v_presenting_comp         IN pat_authorization_details.presenting_complaints%TYPE:= null,
                           v_provider_login          in varchar2:= null,
                           v_file_name               in varchar2:= null
                           ) 
                   is

  CURSOR mem_cur IS
    SELECT tepm.date_of_inception,
           tepm.date_of_exit,
           tepm.mem_name,
           tepm.mem_age,
           tcc.short_name,
           tsc.state_type_id,
           tepg.policy_group_seq_id,
           tepg.policy_seq_id,
           tepm.member_seq_id,
           tepm.vip_yn,
           reg.corp_vip_yn
      FROM tpa_enr_policy_group tepg
      JOIN tpa_enr_policy_member tepm
        ON (tepg.policy_group_seq_id = tepm.policy_group_seq_id)
     LEFT OUTER JOIN tpa_enr_mem_address tema
        ON (tepg.enr_address_seq_id = tema.enr_address_seq_id)
     LEFT OUTER JOIN tpa_country_code tcc
        ON (tema.country_id = tcc.country_id)
     LEFT OUTER JOIN tpa_state_code tsc
        ON (tema.state_type_id = tsc.state_type_id)
     LEFT OUTER JOIN tpa_group_registration reg
        ON (tepg.group_reg_seq_id=reg.group_reg_seq_id)
     WHERE tepm.Member_Seq_Id = v_member_seq_id;

  CURSOR pat_dup_cur IS
    SELECT pad.hospitalization_date
      FROM pat_authorization_details pad
     WHERE pad.member_seq_id = v_member_seq_id
       AND pad.pat_auth_seq_id != nvl(v_pat_auth_seq_id, 0)
     ORDER BY pad.hospitalization_date desc;


CURSOR provider_networks(v_hosp_seq_id  tpa_hosp_info.hosp_seq_id%type) is 
select to_char(wm_concat(case when n.network_yn='Y' then n.network_type end )) as eligible_networks from tpa_hosp_info i join app.tpa_hosp_network n on (i.hosp_seq_id=n.hosp_seq_id)
join tpa_general_code gc on (gc.general_type_id=n.network_type)
where i.hosp_seq_id = v_hosp_seq_id;

pro_network  provider_networks%rowtype;

  CURSOR pat_cur IS
    SELECT pad.completed_yn,pad.pat_status_type_id, pad.benifit_type
      FROM pat_authorization_details pad
     WHERE pad.pat_auth_seq_id = v_pat_auth_seq_id;

  pat_rec  pat_cur%rowtype;

  CURSOR clinician_cur IS
   SELECT hp.hosp_seq_id,hp.professional_id,hp.valid_from_date,hp.valid_to_date FROM app.tpa_hosp_professionals hp
   WHERE hp.professional_id=v_clinician_id;

 CURSOR clinician_count_cur IS
   SELECT count(1) FROM app.tpa_hosp_professionals hp
   WHERE hp.professional_id=v_clinician_id AND hp.hosp_seq_id=v_hosp_seq_id;

 CURSOR prev_balance_cur IS SELECT b.balance_seq_id , b.sum_insured  ,b.utilised_sum_insured ,
        a.policy_group_seq_id ,a.mem_general_type_id 
      FROM tpa_enr_policy_member a JOIN tpa_enr_balance b ON (a.policy_group_seq_id = b.policy_group_seq_id )
      JOIN tpa_enr_policy c ON (b.policy_seq_id = c.policy_seq_id)
      WHERE a.member_seq_id = v_member_seq_id
      AND (a.mem_general_type_id = 'PFL' AND b.member_seq_id IS NULL
               OR a.mem_general_type_id != 'PFL' AND b.member_seq_id = v_member_seq_id );

 ----added for currency conversion 
    
 CURSOR cur_hosp_currency_id IS
   SELECT CO.COUNTRY_NAME,CU.CURRENCY_ID
    FROM APP.TPA_HOSP_INFO THI
    JOIN TPA_HOSP_ADDRESS THA ON (THI.HOSP_SEQ_ID = THA.HOSP_SEQ_ID)
    JOIN TPA_COUNTRY_CODE CO ON (THA.COUNTRY_ID=CO.COUNTRY_ID)
    JOIN TPA_CURRENCY_CODE CU ON (CO.COUNTRY_ID=CU.COUNTRY_ID)   
   WHERE THI.HOSP_SEQ_ID = V_HOSP_SEQ_ID;
   
 rec_hosp_currency_id            cur_hosp_currency_id%ROWTYPE; 
 
 cursor currency_con is 
 select to_number(jk.qar_per_unit) as aed_per_unit
   from app.TPA_CURRENCY_CONV_RATES jk
  where jk.CONV_SEQ_ID =
        (select max(jk.CONV_SEQ_ID)
          from app.TPA_CURRENCY_CONV_RATES jk
         where jk.currency_code = NVL(v_req_amt_currency_type,rec_hosp_currency_id.currency_id)
           and to_date(jk.conversion_date, 'dd/mm/RRRR') =to_date(V_DISCHARGE_DATE,'dd/mm/RRRR'));

 cursor currency_exist_as_per_date is 
 select count(1) 
   from APP.TPA_CURRENCY_CONV_RATES jk
  where to_date(jk.conversion_date, 'DD/MM/RR') =to_date(V_DISCHARGE_DATE,'DD/MM/RR')
    and jk.currency_code = NVL(v_req_amt_currency_type,rec_hosp_currency_id.currency_id);   
    v_cur_exch_cnt number;
    
 currency_con_rec currency_con%rowtype;
 v_conv_QAR_amnt   NUMBER(20,2);
 
  -------********newly added for partner*******------------
 
-- CURSOR ptnr_seq_id_cur IS
--   select ptnr_seq_id 
--     from tpa_partner_info 
--       where upper(partner_name)  = upper(v_partner_name);
--       
--       seq   ptnr_seq_id_cur%rowtype;


--    cursor onl_pre_auth_cur is
--      select pre_auth_number 
--        from  pat_authorization_details
--      where onl_pat_auth_seq_id = v_onl_pat_auth_seq_id;
--      
--    ptnr    onl_pre_auth_cur%rowtype;
--    

     cursor pre_auth_cur  is
     select onl_pat_auth_seq_id,onl_pre_auth_refno, source_type_id
     from pat_authorization_details  pad
     where pad.pat_auth_seq_id = v_pat_auth_seq_id;
     
     pre   pre_auth_cur%rowtype;
    -----------------------------------------
    CURSOR event_cur IS
      select count(p.event_no)
      from pat_authorization_details p
      where p.event_no = trim(v_event_no);
      
  
  -----*******NEWLY ADDED FOR PREAUTH ENHANCEMENT******------    
    CURSOR enh_pre_auth_no_cur(v_pre_auth_id  number)  
    IS
    SELECT a.pre_auth_number,
           a.override_remarks,
           a.internal_remarks,
           a.medical_opinion_remarks,
           a.ptnr_seq_id,
           a.onl_pat_auth_seq_id,
           a.onl_pre_auth_refno,
           a.xml_seq_id,
           a.pl_preauth_refno,
           a.pbm_yn,
           a.clinician_mail,---- NEWLY ADDED FOE ALAHALI ENHANCEMENT  
           a.appeal_yn,
           a.appeal_date,
           a.appeal_count
    FROM  app.pat_authorization_details a
    WHERE a.pat_auth_seq_id =  v_pre_auth_id;
 
    enh_pat_no_rec    enh_pre_auth_no_cur%ROWTYPE; 
    
     -----------------------------------
    CURSOR vip_nvip_cursor(v_pat_seq_id number)IS 
      select b.vip_yn from pat_authorization_Details a join   tpa_enr_policy_member b
               on ( a.MEMBER_SEQ_ID=b.MEMBER_SEQ_ID) where a.pat_auth_seq_id =  v_pat_seq_id;
      ----------------------------------
    CURSOR pat_rec_cur
    IS
    SELECT A.BENIFIT_TYPE 
    FROM APP.PAT_AUTHORIZATION_DETAILS A
    WHERE A.PAT_AUTH_SEQ_ID = v_parent_pat_auth_seq_id;

    pat_rec_var                     pat_rec_cur%ROWTYPE;

    CURSOR Dental_iotn_Config 
    IS
    SELECT * 
    FROM ORTHODONTIC_DETAILS_TAB o 
    WHERE o.Source_Seq_Id=v_parent_pat_auth_seq_id ;  

    Dental_iotn                   Dental_iotn_Config%ROWTYPE;
    
    CURSOR pat_prov_enhance_dtls
    IS
    SELECT pad.clinician_speciality,
           pad.consultation_type,
           pad.presenting_complaints,
           pad.since_when_time,
           pad.since_when,
           pad.duration_above_illness_time,
           pad.duration_above_illness,
           pad.past_history,
           pad.dur_ailment,
           pad.duration_flag,
           pad.status_code_id,
           pad.risk_level,
           pad.code_added_by,
           pad.code_remarks,
           pad.code_added_date,
           pad.suspect_veri_check       
    FROM APP.PAT_AUTHORIZATION_DETAILS pad
    WHERE pad.pat_auth_seq_id = v_parent_pat_auth_seq_id;
    
    pat_enh_dtls       pat_prov_enhance_dtls%ROWTYPE;
    
    CURSOR shrtfal_cnt
    IS
    SELECT COUNT(1)
    FROM   app.shortfall_details a
    WHERE  A.PAT_GEN_DETAIL_SEQ_ID = v_parent_pat_auth_seq_id;
    
    v_shrt_count          NUMBER(5);
    
    CURSOR doc_cnt_cur
    IS
    SELECT COUNT(1)
    FROM  APP.PAT_CLM_DOCS_TAB A
    WHERE A.PAT_CLM_SEQ_ID = v_parent_pat_auth_seq_id AND UPPER(TRIM(A.SOURCE_ID)) = 'PAT';
    
    v_doc_cnt           NUMBER(5);
    
    CURSOR enhance_cnt_cur
    IS 
    SELECT COUNT(1)
    FROM APP.PAT_AUTHORIZATION_DETAILS a
    WHERE a.parent_pat_auth_seq_id = v_parent_pat_auth_seq_id;
    
    CURSOR cur_corporate_name IS
      SELECT UPPER(TRIM(REPLACE(R.GROUP_NAME,' ',''))) AS CORP_NAME
      FROM TPA_ENR_POLICY_MEMBER M
      JOIN TPA_ENR_POLICY_GROUP G ON G.POLICY_GROUP_SEQ_ID = M.POLICY_GROUP_SEQ_ID
      JOIN TPA_GROUP_REGISTRATION R ON R.GROUP_REG_SEQ_ID = G.GROUP_REG_SEQ_ID
      WHERE M.MEMBER_SEQ_ID = v_member_seq_id;
    
    v_enhance_cnt     NUMBER(5);   
                         
   v_count          number(10);
   clin_rec        clinician_cur%rowtype;
   mem_rec         mem_cur%ROWTYPE;
   balance_rec                  prev_balance_cur%ROWTYPE;
   v_denial_reason pat_authorization_details.denial_reason%type;
   v_denial_code     pat_authorization_details.denial_code%type;
   v_parent_pat_rcvd_date   pat_authorization_details.pat_received_date%type;
   v_parent_completed_yn    varchar2(2);
   v_pat_status_type_id     pat_authorization_details.pat_status_type_id%type;
   v_parent_app_sum_insured pat_general_details.app_sum_insured%TYPE;
   V_shortfall_count       number;
   v_denial_codes          VARCHAR2(250);
   v_dest_msg_seq_id      number;
   v_pl_preauth_refno     VARCHAR2(250);
   v_seq_id               number;
   event_num              VARCHAR2(15);
   v_event_num            VARCHAR2(15);
   v_spec_char_cnt        NUMBER;
   v_event_len            NUMBER;
   vip_nvip_rec           tpa_enr_polIcy_member.VIP_YN%TYPE;
   v_mat_cnt              integer;
   v_cor_name             VARCHAR2(1000);


BEGIN

if NVL(v_pat_auth_seq_id,0)!=0  then
authorization_pkg.reassign_user('|'||v_pat_auth_seq_id||'|',null,null,v_added_by,null,v_seq_id);
end if;

if NVL(v_pat_auth_seq_id,0)!=0  then
  
update pat_authorization_details pad
        SET pad.denial_reason= NULL,
            pad.denial_code  = NULL,
            pad.remarks      = NULL
        where pad.pat_auth_seq_id=v_pat_auth_seq_id;

end if;
---***VALIDATION FOR PRE AUTH ENHANCEMENT IN  ENHANCEMENT SCREEN****-

IF v_selection_type = 'ENH' THEN 
  
  OPEN  enhance_cnt_cur;
  FETCH enhance_cnt_cur  INTO v_enhance_cnt;
  CLOSE enhance_cnt_cur;
  
  IF v_pat_auth_seq_id = 0 AND v_enhance_cnt > 0 THEN 
    
     RAISE_APPLICATION_ERROR(-20961,'Pre-auth is already enhanced.For further process please go to pre auth module');
     
  END IF;
  
END IF;

-----

  OPEN mem_cur;
  FETCH mem_cur
    INTO mem_rec;
  CLOSE mem_cur;

  OPEN pat_cur;
  FETCH pat_cur
    INTO pat_rec;
  CLOSE pat_cur;

  /*OPEN clinician_cur;
  FETCH clinician_cur
    INTO clin_rec;
  CLOSE clinician_cur;

  OPEN clinician_count_cur;
  FETCH clinician_count_cur
    INTO v_count;
  CLOSE clinician_count_cur;
*/  -- commented by venu, we are not using this cursors information on 25/02/2019


    OPEN prev_balance_cur;
    FETCH prev_balance_cur INTO balance_rec;
    CLOSE prev_balance_cur;
	
  OPEN cur_corporate_name;
  FETCH cur_corporate_name INTO v_cor_name;
  CLOSE cur_corporate_name;
	   -----*******newly added for partner*****-------- 
--    open ptnr_seq_id_cur;
--    fetch ptnr_seq_id_cur  into seq;
--    close ptnr_seq_id_cur;

--    open onl_pre_auth_cur;
--    fetch onl_pre_auth_cur  into ptnr;
--    close onl_pre_auth_cur;

   /* open pre_auth_cur;
    fetch pre_auth_cur  into pre;
    close pre_auth_cur;*/ -- commented by venu, we are not using this cursors information on 25/02/2019
  ----------------
    
   ----added for currency conversion 
  IF v_hosp_seq_id IS NOT NULL THEN
    OPEN  cur_hosp_currency_id;
    FETCH cur_hosp_currency_id INTO rec_hosp_currency_id;
    CLOSE cur_hosp_currency_id;
  END IF;
  
  OPEN currency_exist_as_per_date;
  FETCH currency_exist_as_per_date INTO v_cur_exch_cnt;
  close currency_exist_as_per_date;
  
  IF NVL(v_req_amt_currency_type,rec_hosp_currency_id.currency_id)=v_converted_amt_currency_type THEN 
     v_conv_QAR_amnt:=v_requested_amount;
  ELSE 
   IF  v_conversion_rate IS NOT NULL   THEN 
       v_conv_QAR_amnt:=v_requested_amount*v_conversion_rate;
   ELSE
    IF v_cur_exch_cnt=0 THEN 
       RAISE_APPLICATION_ERROR(-20405,'As per the date there is no rate existing for this Currency in softcopy');
    END IF ;
     OPEN  currency_con;
     FETCH currency_con INTO currency_con_rec;
     CLOSE currency_con;
     v_conv_QAR_amnt:= v_requested_amount*currency_con_rec.aed_per_unit;
   END IF ;  
  END IF ; 
  IF pat_rec.completed_yn = 'Y' THEN
    RAISE_APPLICATION_ERROR(-20107,
                            'You cannot perform this action through a completed Claim.');
  END IF;
  
  IF mem_rec.member_seq_id IS NULL THEN
    RAISE_APPLICATION_ERROR(-20370, 'Patient is not a covered member');
 /* ELSIF v_hospitalization_date < mem_rec.date_of_inception THEN
    RAISE_APPLICATION_ERROR(-20371,
                            'Services performed prior to the effective date of coverage');*/
    --commented to validate in global rule level
  /*ELSIF v_hospitalization_date > mem_rec.Date_Of_Exit THEN
    RAISE_APPLICATION_ERROR(-20373,
                            'Services performed after the last date of coverage');*/
  END IF;

 /* IF v_count=0 Then 
      RAISE_APPLICATION_ERROR(-20381,
                            'Clinician is not exist under this provider,please check with Network department');
  END IF;*/

  /*IF clin_rec.hosp_seq_id!=v_hosp_seq_id Then 
      RAISE_APPLICATION_ERROR(-20382,
                            'This Clinician is exist under some other provider ,please check with Network department');
  END IF;*/
  /*FOR rec IN pat_dup_cur LOOP
    IF trunc(rec.hospitalization_date) = trunc(v_hospitalization_date) and nvl(v_selection_type,'PAT')!='ENH' THEN
      RAISE_APPLICATION_ERROR(-20372, 'Duplicate Preauth');
    END IF;
  END LOOP;*/
   
   IF nvl(v_parent_pat_auth_seq_id,0)!=0  THEN

      SELECT a.pat_received_date, a.completed_yn,a.tot_approved_amount
         INTO v_parent_pat_rcvd_date ,v_parent_completed_yn,v_parent_app_sum_insured
         FROM pat_authorization_details a
         WHERE a.pat_auth_seq_id = v_parent_pat_auth_seq_id ;
        
      update pat_authorization_details ad set ad.pat_enhance_seq=pat_enhance_seq.nextval
      where ad.pat_auth_seq_id =v_parent_pat_auth_seq_id;
      commit;

      IF v_pat_received_date < v_parent_pat_rcvd_date THEN
        raise_application_error(-20383,'Enhancement received date/time should not be less than original preauth received date/time.');
      END IF;
      
       OPEN    pat_prov_enhance_dtls;
       FETCH   pat_prov_enhance_dtls   INTO pat_enh_dtls;
       CLOSE   pat_prov_enhance_dtls;
      

      IF NVL(V_PAT_AUTH_SEQ_ID, 0) = 0  THEN
        v_pat_status_type_id := 'INP';
        IF v_parent_completed_yn = 'N' THEN
          raise_application_error(-20384,' Please Complete the parent Pre_auth First ');
        END IF;
        IF v_member_seq_id IS NOT NULL THEN
          UPDATE tpa_enr_balance a 
          SET
            a.utilised_sum_insured = a.utilised_sum_insured - nvl(v_parent_app_sum_insured,0),
            a.updated_by                   = v_added_by,
            a.updated_date                 = SYSDATE
            WHERE a.balance_seq_id = balance_rec.balance_seq_id;
        END IF;
      END IF;
    END IF;
  IF NVL(V_PAT_AUTH_SEQ_ID, 0) = 0 THEN
    -- If Event is not generated or Existing Event Number
    IF v_event_no IS NOT NULL THEN
      /*open event_cur;
      fetch event_cur into event_num;
      close event_cur;*/
      
      SELECT count(1) INTO v_spec_char_cnt FROM DUAL
      WHERE REGEXP_LIKE(v_event_no, '^\d+(\\d+)?$', '');
        
      IF v_spec_char_cnt = 0 THEN
        RAISE_APPLICATION_ERROR(-20916, 'Event Number should be number format .');
      END IF;
      
      SELECT length(v_event_no) INTO v_event_len
      FROM DUAL;
      
      IF v_event_len != 7 THEN
        RAISE_APPLICATION_ERROR(-20919, 'Event Number Length should be 7 .');
      END IF;
        
      select rpad((s.LAST_NUMBER - 1), 7, 0) INTO v_event_num
      from all_sequences s
      where s.SEQUENCE_NAME = UPPER('event_ref_no_seq')
      and s.SEQUENCE_OWNER = 'APP';
      
      /*IF event_num > 0 THEN
        RAISE_APPLICATION_ERROR(-20914, 'Given Event Number is Already assinged to other Preaproval/ Claim.');
      END IF;*/
      
      
      
      /*IF to_number(trim(v_event_no)) > v_event_num THEN
        RAISE_APPLICATION_ERROR(-20915, 'Given Event Number is not valid.');
      END IF;*/
    END IF;
    
    IF v_pre_auth_number IS NULL THEN
       v_pre_auth_number := generate_id_numbers('PA',
                                               mem_rec.short_name,
                                               mem_rec.state_type_id,
                                               v_pre_auth_number);
    END IF;
    
 IF  NVL(v_parent_pat_auth_seq_id,0) = 0 THEN  ----FOR ENHANCEMENT  NO NEED TO GENERATE REF NUMBER
      
	 if v_hosp_seq_id  is not null then   ------newly added for partner---this ref no is no need for partner
	
       v_pl_preauth_refno := HOSP_DIAGNOSYS_PKG.generate_id_numbers('PL');
	
	 end if;
   
 END IF;
    
    INSERT INTO PAT_AUTHORIZATION_DETAILS
      (pat_auth_seq_id,
       parent_pat_auth_seq_id,
       pat_received_date,
       discharge_date,
       source_type_id,
       hospitalization_date,
       member_seq_id,
       tpa_enrollment_id,
       pre_auth_number,
       auth_number,
       mem_name,
       mem_age,
       ins_seq_id,
       hosp_seq_id,
       policy_seq_id,
       tpa_office_seq_id,
       emirate_id,
       encounter_type_id,
       encounter_facility_id,
       encounter_start_type,
       encounter_end_type,
       ava_sum_insured,
       remarks,
       denial_reason,
       pat_enhanced_yn,
       currency_type,
       maternity_yn,
       pat_status_type_id,
       clinician_id,
       system_of_medicine_type_id,
       accident_related_type_id,
       added_by,
       added_date,
       priority_general_type_id,
       network_yn,
       requested_amount,
       benifit_type,
       gravida,
       para,
       live,
       abortion,
       past_history   ,
       duration_above_illness ,
       duration_above_illness_time ,
       since_when ,
       since_when_time,
       clinician_speciality,
       consultation_type,
       -------------------------------
       Oral_diagnosis,
       Oral_services,
       Orala_Aproved_amount,
       Oral_system_Status,
       Oral_diagnosis_revised,
       Oral_services_revised,
       Orala_Aproved_amount_revised,
       pl_preauth_refno,
       presenting_complaints,
       file_name,
       conception_type,
       lmp_date,
       REQ_AMT_CURRENCY_TYPE,
       CONVERTED_AMOUNT,
       CONVERTED_AMOUNT_CURRENCY_TYPE,
       CONVERSION_RATE,
       PROCESS_TYPE,
       oth_tpa_ref_no,
       treatment_type,
	   ptnr_seq_id,   --newly added for partner
       onl_pat_auth_seq_id,--newly added for partner
       onl_pre_auth_refno,  --newly added for partner
	   delvry_mod_type,
	   event_no,
     MAT_COMPLCTON_YN,
     clinician_mail,  ---NEWLY ADDED FOE ALAHALI ENHANCEMENT
        --- newly added for CFD CR
     status_code_id, 
     risk_level,       
	   suspect_veri_check,
     code_added_by,
     code_remarks,
     code_added_date
      )
    VALUES
      (pat_auth_detail_seq.nextval,
       nvl(v_parent_pat_auth_seq_id,0),
       v_pat_received_date,
       v_discharge_date,
       v_source_type_id,
       v_hospitalization_date,
       v_member_seq_id,
       v_tpa_enrollment_id,
       v_pre_auth_number,
       v_auth_number,
       nvl(v_mem_name, mem_rec.mem_name),
       nvl(v_mem_age, mem_rec.mem_age),
       v_ins_seq_id,
       v_hosp_seq_id,
       nvl(v_policy_seq_id, mem_rec.policy_seq_id),
       1,
       v_emirate_id,
       v_encounter_type_id,
       v_encounter_facility_id,
       v_encounter_start_type,
       v_encounter_end_type,
       v_ava_sum_insured,
       v_remarks,
       v_denial_reason,
       'N',
       v_currency_type,
       case when nvl(v_benifit_type,'A') IN ('MTI', 'OMTI', 'IMTI') THEN 'Y' ELSE 'N' end,
       'INP',
       v_clinician_id,
       v_system_of_medicine_type_id,
       v_accident_related_type_id,
       v_added_by,
       SYSDATE,
       /*v_priority_gen_type_id*/CASE WHEN v_priority_gen_type_id IS NULL THEN CASE WHEN mem_rec.vip_yn ='Y' or NVL(mem_rec.corp_vip_yn,'CVN')='CVY' THEN 'HIG' ELSE 'MID' END  ELSE v_priority_gen_type_id END,
       v_network_yn,
       v_requested_amount,
       v_benifit_type,
       v_gravida,
       v_para,
       v_live,
       v_abortion,
       nvl(v_past_history,pat_enh_dtls.past_history),----NEWLY CHANGED
       NVL(v_duration_above_illness ,pat_enh_dtls.duration_above_illness),----NEWLY CHANGED
       NVL(v_duration_above_illness_time ,pat_enh_dtls.duration_above_illness_time),----NEWLY CHANGED
       NVL(v_since_when ,pat_enh_dtls.since_when),----NEWLY CHANGED
       NVL(v_since_when_time,pat_enh_dtls.since_when_time),----NEWLY CHANGED
       NVL(nvl(v_clinician_speciality,CASE WHEN v_clinician_id is null THEN null else  v_clinician_spec end),pat_enh_dtls.clinician_speciality),----NEWLY CHANGED
       NVL(v_consultation_type,pat_enh_dtls.consultation_type),----NEWLY CHANGED
       --------------------------------------
       v_Oral_diagnosis,
       v_Oral_services,
       v_Orala_Aproved_amount,
       v_Oral_system_Status,
       v_Oral_diagnosis_revised,
       v_Oral_services_revised,
       v_Orala_Aproved_amount_revised,
       v_pl_preauth_refno,
       NVL(v_presenting_comp,pat_enh_dtls.presenting_complaints),-----NEWLY CHANGED
       v_file_name,
       v_nat_conception,
       v_lmp,
       NVL(v_req_amt_currency_type,rec_hosp_currency_id.currency_id),
       v_conv_QAR_amnt,
       v_CONVERTED_AMT_CURRENCY_TYPE,
       NVL(NVL(v_conversion_rate,currency_con_rec.aed_per_unit),1),
       NVL(v_process_type,'RGL'),
       v_oth_tpa_ref_no,
       v_treatment_type,
	     v_ptnr_seq_id,   --newly added for partner
       v_onl_pat_auth_seq_id ,--newly added for partner
       v_onl_pre_auth_refno,  --newly added for partner
       v_mode_of_delvry,
	     v_event_no,
       v_MAT_COMPLCTON_YN,
     v_clinician_mail,
                  --- newly added for CFD CR
       pat_enh_dtls.status_code_id,
       pat_enh_dtls.risk_level,
	     pat_enh_dtls.suspect_veri_check,
       v_added_by,
       pat_enh_dtls.code_remarks,
       pat_enh_dtls.code_added_date
       )
      RETURNING pat_auth_seq_id INTO v_pat_auth_seq_id;

      IF v_pat_auth_seq_id IS NOT NULL THEN
      OPEN vip_nvip_cursor(v_pat_auth_seq_id);
      fetch vip_nvip_cursor into vip_nvip_rec;
      close  vip_nvip_cursor;
      
      IF NVL(vip_nvip_rec,'N')='Y' and v_pat_auth_seq_id is not null THEN
        GENERATE_MAIL_PKG.proc_generate_message('VIP_PAT_UPLOADED',v_pat_auth_seq_id,v_added_by,v_dest_msg_seq_id);
        GENERATE_MAIL_PKG.proc_generate_message('VIP_PREAPPROVAL',v_pat_auth_seq_id,v_added_by,v_dest_msg_seq_id);
      END IF;
      
      IF v_benifit_type IN('IPT','IMTI') THEN
        GENERATE_MAIL_PKG.proc_generate_message('IN-PATIENT_PREAPPROVAL',v_pat_auth_seq_id,v_added_by,v_dest_msg_seq_id);
      END IF;
      END IF;
    --IF v_network_yn = 'N' then
      INSERT INTO PAT_NON_NETWORK_DETAILS
        (PAT_NON_NETWORK_SEQ_ID,
         PAT_AUTH_SEQ_ID,
         PROVIDER_NAME,
         PROVIDER_ID,
         CITY_TYPE_ID,
         STATE_TYPE_ID,
         COUNTRY_TYPE_ID,
         PROVIDER_ADDRESS,
         PINCODE,
         ADDED_BY,
         ADDED_DATE,
         CLINICIAN_ID,
         CLINICIAN_NAME)
      values
        (PAT_NON_NETWORK_DETAILS_SEQ.nextval,
         v_pat_auth_seq_id,
         v_provider_name,
         v_provider_id,
         v_city_type_id,
         v_state_type_id,
         v_country_type_id,
         v_provider_address,
         v_pincode,
         v_added_by,
         sysdate,
         v_clinician_id,
         v_clinician_name
         );
		 
    --end if;
    --Sortfall type
	
	  ---------******newly added for partner******------------ for change the status of ref no in  Preauth_Submission table
  
      if v_onl_pat_auth_seq_id is not null and v_onl_pre_auth_refno is not null and v_pre_auth_number is not null  then
      
      update Preauth_Submission 
      set onl_pat_status = 'APR',pre_auth_number= v_pre_auth_number
      where  onl_pat_auth_seq_id = v_onl_pat_auth_seq_id;
      
      end if;
	  
    -------*****************************************


authorization_pkg.reassign_user('|'||v_pat_auth_seq_id||'|',null,null,v_added_by,'AUT',v_seq_id);


  if v_hosp_seq_id is not null then   
  
  GENERATE_MAIL_PKG.proc_generate_message('PREAUTH_RECEIPT',
                                          v_pat_auth_seq_id,
                                          v_added_by,
                                          v_dest_msg_seq_id); --PREAUTH_RECEIPT_NHCP

  GENERATE_MAIL_PKG.proc_generate_message('PREAUTH_RECEIPT_NHCP',
                                          v_pat_auth_seq_id,
                                          v_added_by,
                                          v_dest_msg_seq_id);
										  
 end if;  
 
    IF v_selection_type = 'ENH' THEN--enhancement
         
         UPDATE pat_authorization_details d SET
             d.pat_enhanced_yn = 'Y',
             d.pat_status_type_id = 'APR'
             WHERE d.pat_auth_seq_id = v_parent_pat_auth_seq_id ;
                             
   ----*****updating preauth number from parent preauth to fresh  pre auth(NEWLY ADDED)****--- 
           
      OPEN   enh_pre_auth_no_cur(v_parent_pat_auth_seq_id);
      FETCH  enh_pre_auth_no_cur  into enh_pat_no_rec;
      CLOSE  enh_pre_auth_no_cur;
    
  
      UPDATE  app.pat_authorization_details a 
      SET a.pre_auth_number         = enh_pat_no_rec.pre_auth_number,
          a.override_remarks        = enh_pat_no_rec.override_remarks,
          a.internal_remarks        = enh_pat_no_rec.internal_remarks,
          a.medical_opinion_remarks = enh_pat_no_rec.medical_opinion_remarks,
          a.dur_ailment             = pat_enh_dtls.dur_ailment,
          a.duration_flag           = pat_enh_dtls.duration_flag,
          a.ptnr_seq_id             = enh_pat_no_rec.ptnr_seq_id,
          a.onl_pat_auth_seq_id     = enh_pat_no_rec.onl_pat_auth_seq_id,
          a.onl_pre_auth_refno      = enh_pat_no_rec.onl_pre_auth_refno,
          a.xml_seq_id              = enh_pat_no_rec.xml_seq_id,
          a.pl_preauth_refno        = enh_pat_no_rec.pl_preauth_refno,
          a.pbm_yn                  = enh_pat_no_rec.pbm_yn,
          a.clinician_mail          = enh_pat_no_rec.clinician_mail,   --------NEWLY ADDED FOE ALAHALI ENHANCEMENT
          a.appeal_yn               = enh_pat_no_rec.appeal_yn,
          a.appeal_count            = enh_pat_no_rec.appeal_count,
          a.appeal_date             = enh_pat_no_rec.appeal_date
      WHERE a.pat_auth_seq_id = v_pat_auth_seq_id;

    -----------*******
        OPEN   pat_rec_cur;
        FETCH  pat_rec_cur   INTO  pat_rec_var;
        CLOSE  pat_rec_cur;
        
             IF pat_rec_var.benifit_type='DNTL' THEN
 
             OPEN  Dental_iotn_Config;
             FETCH Dental_iotn_Config INTO Dental_iotn;
             CLOSE Dental_iotn_Config;
 
                INSERT INTO ORTHODONTIC_DETAILS_TAB
                                                  (
                                                   ORTHO_SEQ_ID,
                                                   SOURCE_SEQ_ID,
                                                   SOURCE_FROM,
                                                   DENTO_CLASS_I,
                                                   DENTO_CLASS_II,
                                                   DENTO_CLASS_II_TEXT,
                                                   DENTO_CLASS_III,
                                                   SKELE_CLASS_I,
                                                   SKELE_CLASS_II,
                                                   SKELE_CLASS_III,
                                                   OVERJET_MM,
                                                   REV_OVERJET_MM,
                                                   REV_OVERJET_YN,
                                                   CROSSBITE_ANT,
                                                   CROSSBITE_POST,
                                                   CROSSBITE_BETW,
                                                   OPENBIT_ANT,
                                                   OPENBIT_POST,
                                                   OPENBIT_LATE,
                                                   CONT_POINT_DISP,
                                                   OVERBIT_DEEP,
                                                   OVERBIT_PATA,
                                                   OVERBIT_GING,
                                                   HYPO_QUAD1,
                                                   HYPO_QUAD2,
                                                   HYPO_QUAD3,
                                                   HYPO_QUAD4,
                                                   OTHERS_IMPEDED,
                                                   OTHERS_IMPACT,
                                                   OTHERS_SUBMERG,
                                                   OTHERS_SUPERNUM,
                                                   OTHERS_RETAINE,
                                                   OTHERS_ECTOPIC,
                                                   OTHERS_CRANIO,
                                                   AC_MARKS,
                                                   CROSSBITE_ANT_MM,
                                                   CROSSBITE_PRST_MM,
                                                   CROSSBITE_BETW_MM,
                                                   CONT_POINT_DISP_MM,
                                                   DENTO_CLASS_III_TEXT,
                                                   IOTN_REMARK
                                                  ) 
                                           VALUES 
                                                 (
                                                  NULL,
                                                  v_pat_auth_seq_id,
                                                  Dental_iotn.SOURCE_FROM,
                                                  Dental_iotn.DENTO_CLASS_I,
                                                  Dental_iotn.DENTO_CLASS_II,
                                                  Dental_iotn.DENTO_CLASS_II_TEXT,
                                                  Dental_iotn.DENTO_CLASS_III,
                                                  Dental_iotn.SKELE_CLASS_I,
                                                  Dental_iotn.SKELE_CLASS_II,
                                                  Dental_iotn.SKELE_CLASS_III,
                                                  Dental_iotn.OVERJET_MM,
                                                  Dental_iotn.REV_OVERJET_MM,
                                                  Dental_iotn.REV_OVERJET_YN,
                                                  Dental_iotn.CROSSBITE_ANT,
                                                  Dental_iotn.CROSSBITE_POST,
                                                  Dental_iotn.CROSSBITE_BETW,
                                                  Dental_iotn.OPENBIT_ANT,
                                                  Dental_iotn.OPENBIT_POST,
                                                  Dental_iotn.OPENBIT_LATE,
                                                  Dental_iotn.CONT_POINT_DISP,
                                                  Dental_iotn.OVERBIT_DEEP,
                                                  Dental_iotn.OVERBIT_PATA,
                                                  Dental_iotn.OVERBIT_GING,
                                                  Dental_iotn.HYPO_QUAD1,
                                                  Dental_iotn.HYPO_QUAD2,
                                                  Dental_iotn.HYPO_QUAD3,
                                                  Dental_iotn.HYPO_QUAD4,
                                                  Dental_iotn.OTHERS_IMPEDED,
                                                  Dental_iotn.OTHERS_IMPACT,
                                                  Dental_iotn.OTHERS_SUBMERG,
                                                  Dental_iotn.OTHERS_SUPERNUM,
                                                  Dental_iotn.OTHERS_RETAINE,
                                                  Dental_iotn.OTHERS_ECTOPIC,
                                                  Dental_iotn.OTHERS_CRANIO,
                                                  Dental_iotn.AC_MARKS,
                                                  Dental_iotn.CROSSBITE_ANT_MM,
                                                  Dental_iotn.CROSSBITE_PRST_MM,
                                                  Dental_iotn.CROSSBITE_BETW_MM,
                                                  Dental_iotn.CONT_POINT_DISP_MM,
                                                  Dental_iotn.DENTO_CLASS_III_TEXT,
                                                  Dental_iotn.IOTN_REMARK
                                                );
            
           
         END IF;
       
    ------------***COPING SHORTFALL DETAILS********------
    
      OPEN   shrtfal_cnt;
      FETCH  shrtfal_cnt   INTO v_shrt_count;-----SHORTFALL AVAILABLE FOR PREAUTH OR NOT
      CLOSE  shrtfal_cnt;
      
    IF   v_shrt_count > 0 THEN  -----
    
       INSERT INTO APP.SHORTFALL_DETAILS
                                       (
								                  SHORTFALL_SEQ_ID,
								                  PAT_GEN_DETAIL_SEQ_ID,
							                  	CLAIM_SEQ_ID,
								                  SHORTFALL_ID,
							                    SRTFLL_GENERAL_TYPE_ID,
								                  SRTFLL_SENT_DATE,
							                    SRTFLL_STATUS_GENERAL_TYPE_ID,
							                    SRTFLL_RECEIVED_DATE,
							                	  SRTFLL_REASON_GENERAL_TYPE_ID,
								                  REMARKS,
								                  SHORTFALL_QUESTIONS,
								                  ENTERED_DATE,
								                  DOCUMENT_GENERATED_YN,
								                  DOCUMENT_SENT_YN,
							                  	 DOCUMENT_PATH,
								                  LAST_REMINDER_LOG_SEQ_ID,
								                  REMINDER_COUNT,
								                  CLOSED_DATE,
							                	  SHORTFALL_RAISED_BY,
								                  ADD_CLAUSE_NUMBER,
								                  SHORTFALL_RAISED_FOR,
								                  CLAUSE_SEQ_ID,
								                  UPLOADED_FILE,
								                  DOCS_STATUS,
							                	  FILE_NAME,
								                  ADDED_BY,
                                  ADDED_DATE,
                                  UPDATED_BY,
                                  UPDATED_DATE
								                )
								 
                 SELECT       shortfall_details_seq.NEXTVAL,
				                      v_pat_auth_seq_id,
							                NULL,
				                      A.SHORTFALL_ID,
                              A.SRTFLL_GENERAL_TYPE_ID,
                              A.SRTFLL_SENT_DATE,
                              A.SRTFLL_STATUS_GENERAL_TYPE_ID,
                              A.SRTFLL_RECEIVED_DATE,      
                              A.SRTFLL_REASON_GENERAL_TYPE_ID,
                              A.REMARKS,
                              A.SHORTFALL_QUESTIONS,
                              A.ENTERED_DATE,
                              A.DOCUMENT_GENERATED_YN,
                              A.DOCUMENT_SENT_YN,
                              A.DOCUMENT_PATH,
                              A.LAST_REMINDER_LOG_SEQ_ID,
                              A.REMINDER_COUNT,
                              A.CLOSED_DATE,
                              A.SHORTFALL_RAISED_BY,                                                                                                                                                 
                              A.ADD_CLAUSE_NUMBER,
                              A.SHORTFALL_RAISED_FOR,
                              A.CLAUSE_SEQ_ID,
                              A.UPLOADED_FILE,
                              A.DOCS_STATUS,
                              A.FILE_NAME,
                              A.ADDED_BY,----
                              A.ADDED_DATE,----
                              A.UPDATED_BY,----
                              A.UPDATED_DATE-----
       
                FROM APP.SHORTFALL_DETAILS A
			         	WHERE A.PAT_GEN_DETAIL_SEQ_ID = v_parent_pat_auth_seq_id;
    END IF;
          -- Copying previous diagnosis details
       FOR I IN (SELECT * FROM diagnosys_details dd
                      WHERE dd.pat_auth_seq_id = v_parent_pat_auth_seq_id) loop 
         INSERT INTO diagnosys_details(diag_seq_id,pat_auth_seq_id,icd_code_seq_id,diagnosys_code,primary_ailment_yn,added_by,added_date)
         VALUES (diagnosys_detail_seq.nextval,v_pat_auth_seq_id,I.icd_code_seq_id,I.diagnosys_code,I.primary_ailment_yn,v_added_by,sysdate);
       END LOOP;

          --Copying activity details 
          FOR I IN (SELECT * FROM pat_activity_details
                      WHERE pat_auth_seq_id = v_parent_pat_auth_seq_id)
          LOOP
          INSERT INTO pat_activity_details(activity_dtl_seq_id,pat_auth_seq_id,Activity_Seq_Id,activity_id,s_no,start_date,activity_type,code,
                      unit_type,modifier,internal_code,package_id,bundle_id,quantity,gross_amount,discount_amount,disc_gross_amount,patient_share_amount,
                      copay_amount,co_ins_amount,deduct_amount,out_of_pocket_amount,net_amount,allowed_amount,approved_amount,allow_yn,denial_code,
                      remarks,added_by,added_date,denial_desc,approvd_quantity,unit_price,service_type,service_code,converted_acitivty_amt,tooth_no,override_yn,
                       override_remarks,internal_desc,Unit_Discount_Amount,clinician_id,override_remarks_code,other_remarks,tpa_denial_code,tpa_denial_desc)
          VALUES (pat_activity_detail_seq.nextval,v_pat_auth_seq_id,i.activity_seq_id,i.activity_id,i.s_no,i.start_date,i.activity_type,i.code,i.unit_type,
                 i.modifier,i.internal_code,i.package_id,i.bundle_id,i.quantity,i.gross_amount,i.discount_amount,i.disc_gross_amount,i.patient_share_amount,i.copay_amount,
                 i.co_ins_amount,i.deduct_amount,i.out_of_pocket_amount,i.net_amount,i.allowed_amount,i.allowed_amount,i.allow_yn,i.denial_code,i.remarks,v_added_by,
                 SYSDATE,i.denial_desc,i.approvd_quantity,i.unit_price,i.service_type,i.service_code,i.converted_acitivty_amt,i.tooth_no,i.override_yn,
                 i.override_remarks,i.internal_desc,i.Unit_Discount_Amount,i.clinician_id,i.override_remarks_code,i.other_remarks,i.tpa_denial_code,i.tpa_denial_desc);

           FOR J IN (SELECT * FROM app.pat_observation_details od 
               where od.activity_dtl_seq_id=i.activity_dtl_seq_id) loop
              INSERT INTO pat_observation_details(observation_seq_id,activity_dtl_seq_id,observation_type_id,observation_code_id,value,
                  obs_value_type_id,added_by,added_date,remarks )
           VALUES (pat_observation_detail_seq.Nextval,j.activity_dtl_seq_id,j.observation_type_id,j.observation_code_id,j.value,j.obs_value_type_id,
                  v_added_by,sysdate,j.remarks);
           END LOOP;   
        END LOOP;
        
  ------******COPYING PREVIOUS PRE AUTH DOC ******----- 
  
   OPEN   doc_cnt_cur;
   FETCH  doc_cnt_cur  INTO  v_doc_cnt;
   CLOSE  doc_cnt_cur;
   
       IF    v_doc_cnt  > 0 THEN 
  
         FOR I IN (SELECT * FROM PAT_CLM_DOCS_TAB a
                              WHERE a.PAT_CLM_SEQ_ID = v_parent_pat_auth_seq_id
                                   AND   UPPER(TRIM(a.SOURCE_ID)) = 'PAT')  LOOP
              
            INSERT INTO APP.PAT_CLM_DOCS_TAB
                                         (
								                           DOCS_SEQ_ID,
                                           PAT_CLM_SEQ_ID,
                                           SOURCE_ID,
                                           FILE_DESC,
                                           FILE_NAME,
                                           FILE_PATH,
                                           IMAGE_FILE,
                                           ADDED_DATE,
                                           ADDED_BY,
                                           UPDATED_DATE,
                                           UPDATED_BY,
                                           REFERENCE_SEQ_ID,
                                           REFERENCE_FROM	
								                         )
					                        VALUES
                                        (
                                           pat_clm_docs_seq.nextval,
                                           v_pat_auth_seq_id,
                                           I.SOURCE_ID,
                                           I.FILE_DESC,
                                           I.FILE_NAME,
                                           I.FILE_PATH,
                                           I.IMAGE_FILE,
                                           I.ADDED_DATE,
                                           I.ADDED_BY,
                                           I.UPDATED_DATE,
                                           I.UPDATED_BY,
                                           I.REFERENCE_SEQ_ID,
                                           I.REFERENCE_FROM
								                         );
          END LOOP;
     
      END IF;-----DOC

      ------ COPYING CFD TAGGING & CONFIRMATION DETAILS
       FOR K IN (SELECT * FROM tpa_fraud_inv_details
                            WHERE pat_auth_seq_id = v_parent_pat_auth_seq_id ORDER BY inv_seq_id) LOOP
        INSERT INTO tpa_fraud_inv_details(inv_seq_id,inv_status,inv_out_category,amt_util_for_inv,amount_saved,cfd_remarks,inv_start_date,added_date,
                                          added_by,pat_auth_seq_id,claim_seq_id )
          VALUES (app.tpa_inv_seq.nextval,k.inv_status,k.inv_out_category,k.amt_util_for_inv,k.amount_saved,k.cfd_remarks,k.inv_start_date,k.added_date,
                                          v_added_by,v_pat_auth_seq_id,k.claim_seq_id);
        END LOOP;

    END IF;

  ELSE
   ---- for dental fixes ---- 
   SELECT COUNT(1) INTO v_mat_cnt FROM DIAGNOSYS_DETAILS D 
   WHERE D.PAT_AUTH_SEQ_ID = v_pat_auth_seq_id AND D.PRIMARY_AILMENT_YN = 'Y';
   
   IF v_mat_cnt > 0 THEN
     select COUNT(1) INTO v_mat_cnt
     from diagnosys_details dd
     join tpa_icd10_master_details tic on (dd.diagnosys_code=tic.icd_code and dd.primary_ailment_yn='Y' AND tic.benefit_type = 'DNTL')
     WHERE dd.PAT_AUTH_SEQ_ID = v_pat_auth_seq_id;
  
     IF (V_BENIFIT_TYPE = 'DNTL' AND v_mat_cnt = 0) OR (V_BENIFIT_TYPE != 'DNTL' AND v_mat_cnt > 0) THEN
       RAISE_APPLICATION_ERROR(-20323,'Ailment does not belogs to the selected benefit type, please select appropriate benefit type!');
     END IF;
   END IF;
   -------------------------- 
   ---------- CR0248(Benefit type restriction for meternity icd) ---------
   v_mat_cnt:=0;
   select count(1) into v_mat_cnt
   from diagnosys_details dd 
   join tpa_icd_codes tic on (dd.diagnosys_code=tic.icd_code and dd.primary_ailment_yn='Y' and tic.master_icd_code='Z34.90')
   WHERE DD.PAT_AUTH_SEQ_ID = v_pat_auth_seq_id;
   
   IF v_mat_cnt > 0 AND V_BENIFIT_TYPE NOT IN ('IMTI','OMTI','MTI') THEN
     RAISE_APPLICATION_ERROR(-20323,'Ailment does not belogs to the selected benefit type, please select appropriate benefit type!');
   END IF;  
   ------------------------------------------------------------------------
    IF v_event_no IS NOT NULL THEN
      SELECT count(1) INTO v_spec_char_cnt FROM DUAL
      WHERE REGEXP_LIKE(v_event_no, '^\d+(\\d+)?$', '');
        
      IF v_spec_char_cnt = 0 THEN
        RAISE_APPLICATION_ERROR(-20916, 'Event Number should be number format .');
      END IF;
      
      SELECT length(v_event_no) INTO v_event_len
      FROM DUAL;
      
      IF v_event_len != 7 THEN
        RAISE_APPLICATION_ERROR(-20919, 'Event Number Length should be 7 .');
      END IF;
      
      /*Select Count(p.event_no) Into event_num
      From Pat_Authorization_Details p
      Where p.pat_auth_seq_id != v_pat_auth_seq_id
      And p.event_no = trim(v_event_no);*/
     
      select rpad((s.LAST_NUMBER - 1), 7, 0) INTO v_event_num
      from all_sequences s
      where s.SEQUENCE_NAME = UPPER('event_ref_no_seq')
      and s.SEQUENCE_OWNER = 'APP';
     
      /*IF to_number(trim(v_event_no)) > v_event_num THEN
        RAISE_APPLICATION_ERROR(-20915, 'Given Event Number is not valid.');
      END IF;*/
     
      /*IF event_num > 0 THEN
        RAISE_APPLICATION_ERROR(-20914, 'Given Event Number is Already assinged to other Preaproval/ Claim.');
      END IF;*/
    END IF;
    
    UPDATE pat_authorization_details
       SET parent_pat_auth_seq_id     = nvl(v_parent_pat_auth_seq_id,0),
           pat_received_date          = v_pat_received_date,
           discharge_date             = v_discharge_date,
           source_type_id             = v_source_type_id,
           hospitalization_date       = v_hospitalization_date,
           member_seq_id              = v_member_seq_id,
           tpa_enrollment_id          = v_tpa_enrollment_id,
           pre_auth_number            = v_pre_auth_number,
           auth_number                = v_auth_number,
           mem_name                   = v_mem_name,
           mem_age                    = v_mem_age,
           ins_seq_id                 = v_ins_seq_id,
           hosp_seq_id                = v_hosp_seq_id,
           policy_seq_id              = v_policy_seq_id,
           emirate_id                 = v_emirate_id,
           encounter_type_id          = v_encounter_type_id,
           encounter_facility_id      = v_encounter_facility_id,
           denial_reason              = v_denial_reason,
           encounter_start_type       = v_encounter_start_type,
           encounter_end_type         = v_encounter_end_type,
           ava_sum_insured            = v_ava_sum_insured,
           remarks                    = v_remarks,
           currency_type              = v_currency_type,
           maternity_yn               = case when nvl(v_benifit_type,'A') IN ('MTI', 'OMTI', 'IMTI') THEN 'Y' ELSE 'N' end,
           pat_status_type_id         = 'INP',
           clinician_id               = v_clinician_id,
           system_of_medicine_type_id = v_system_of_medicine_type_id,
           accident_related_type_id   = v_accident_related_type_id,
           updated_by                 = v_added_by,
           updated_date               = sysdate,
           priority_general_type_id   = /*v_priority_gen_type_id*/ CASE WHEN v_priority_gen_type_id IS NULL THEN CASE WHEN mem_rec.vip_yn ='Y'  or NVL(mem_rec.corp_vip_yn,'CVN')='CVY' THEN 'HIG' ELSE 'MID' END  ELSE v_priority_gen_type_id END,
           network_yn                 = v_network_yn,
           requested_amount           = v_requested_amount,
           benifit_type               = v_benifit_type,
           gravida                    = v_gravida ,
           para                       = v_para,
           live                       = v_live,
           abortion                   = v_abortion,
           denial_code                = v_denial_code,
           past_history               = v_past_history   ,
           duration_above_illness     = v_duration_above_illness ,
           duration_above_illness_time = v_duration_above_illness_time ,
           since_when                  = v_since_when ,
           since_when_time             = v_since_when_time,
           clinician_speciality        = nvl(v_clinician_speciality,CASE WHEN v_clinician_id IS NULL THEN NULL ELSE v_clinician_spec END),
           consultation_type           = v_consultation_type,
           --------------------------------------------------
           Oral_diagnosis              = v_Oral_diagnosis,
           Oral_services               = v_Oral_services,
           Orala_Aproved_amount        = v_Orala_Aproved_amount,
           Oral_system_Status          = v_Oral_system_Status,
           Oral_diagnosis_revised      = v_Oral_diagnosis_revised,
           Oral_services_revised       = v_Oral_services_revised,
           Orala_Aproved_amount_revised = v_Orala_Aproved_amount_revised,
      ---     presenting_complaints       =  v_presenting_comp,---- commneted for pat enhancement(venu/lalatendu) 
           file_name                   = v_file_name,
           conception_type             = v_nat_conception,
           lmp_date                    = v_lmp,
           REQ_AMT_CURRENCY_TYPE       = NVL(v_req_amt_currency_type,rec_hosp_currency_id.currency_id),  
           CONVERTED_AMOUNT            = v_conv_QAR_amnt,  
           CONVERTED_AMOUNT_CURRENCY_TYPE  = v_CONVERTED_AMT_CURRENCY_TYPE,
           CONVERSION_RATE             = NVL(NVL(v_conversion_rate,currency_con_rec.aed_per_unit),1),
           PROCESS_TYPE                = NVL(v_process_type,'RGL'),
           oth_tpa_ref_no              = v_oth_tpa_ref_no,
           treatment_type              = v_treatment_type,
		   ptnr_seq_id                 = v_ptnr_seq_id,--newly added for partner
           onl_pat_auth_seq_id         = pre.onl_pat_auth_seq_id, --newly added for partner   
           onl_pre_auth_refno          = pre.onl_pre_auth_refno,  --newly added for partner   
           delvry_mod_type             = v_mode_of_delvry,
           CAL_ACT_YN                  = 'N',
		       event_no                    = v_event_no,
           MAT_COMPLCTON_YN            = v_MAT_COMPLCTON_YN,
           clinician_mail              = v_clinician_mail
     WHERE pat_auth_seq_id             = v_pat_auth_seq_id;

  --IF v_network_yn = 'N' then
   update pat_non_network_details set
         provider_name          = v_provider_name,
         provider_id            = v_provider_id,
         city_type_id           = v_city_type_id,
         state_type_id          = v_state_type_id,
         country_type_id        = v_country_type_id,
         provider_address       = v_provider_address,
         pincode                = v_pincode,
         updated_by             = v_added_by,
         updated_date           = sysdate,
         clinician_id           = v_clinician_id,
         clinician_name         = v_clinician_name
         where pat_auth_seq_id = v_pat_auth_seq_id;

  --END IF;
  end if;

  v_prod_policy_rule_seq_id := get_prod_pol_seq_id(mem_rec.policy_seq_id,
                                                   'POL');

  pat_xml_load_pkg.execute_global_rules('P',
                                        v_pat_auth_seq_id,
                                        v_member_seq_id,
                                        v_prod_policy_rule_seq_id);

  check_pat_approved(v_pat_auth_seq_id, v_added_by);

  commit;
END save_pat_details;
--===============================================================================

PROCEDURE save_diagnosys_details(
  v_diag_seq_id       IN OUT diagnosys_details.diag_seq_id%type,
  v_pat_auth_seq_id   IN diagnosys_details.pat_auth_seq_id%type,
  v_claim_seq_id      IN diagnosys_details.claim_seq_id%type,
  v_icd_code_seq_id   IN diagnosys_details.icd_code_seq_id%type,
  v_diagnosys_code    IN diagnosys_details.diagnosys_code%type,
  v_priamry_yn        IN diagnosys_details.Primary_Ailment_Yn%TYPE,
  v_presenting_comp   IN pat_authorization_details.presenting_complaints%TYPE,
  v_duration_ailment  IN pat_authorization_details.dur_ailment%type:=null,--ped
  v_duration_flag     IN pat_authorization_details.duration_flag%type:=null,--ped
  v_added_by          IN diagnosys_details.added_by%type ,
  v_rows_processed    OUT NUMBER)
  IS


 CURSOR pat_cur IS
 SELECT pad.pat_auth_seq_id,
       pad.pat_batch_seq_id,
       pad.claim_seq_id,
       pad.member_seq_id,       
       pad.final_app_amount,
       pad.denial_reason,
       pad.completed_yn,
       pad.benifit_type
  FROM pat_authorization_details pad
  WHERE pad.pat_auth_seq_id=v_pat_auth_seq_id;

 CURSOR clm_cur IS
 SELECT cad.claim_seq_id,
        cad.clm_batch_seq_id,
        cad.pat_auth_seq_id,
        cad.member_seq_id,       
        cad.final_app_amount,
        cad.denial_reason,
        cad.completed_yn,
        cad.benifit_type
  FROM clm_authorization_details cad
  WHERE cad.claim_seq_id=v_claim_seq_id;

  pat_rec              pat_cur%ROWTYPE;
  v_prod_pol_rule_seq_id       tpa_ins_prod_policy_rules.prod_policy_rule_seq_id%type;

  CURSOR diag_cur IS
  SELECT count(1)
  FROM diagnosys_details dd
  WHERE (dd.pat_auth_seq_id=v_pat_auth_seq_id or dd.claim_seq_id=v_claim_seq_id)
  AND dd.diag_seq_id!=nvl(v_diag_seq_id,0)
  AND dd.diagnosys_code=TRIM(upper(v_diagnosys_code));

  CURSOR primary_cur IS
  SELECT count(1)
  FROM diagnosys_details dd
  WHERE (dd.pat_auth_seq_id=v_pat_auth_seq_id or dd.claim_seq_id=v_claim_seq_id)
  AND dd.diag_seq_id!=NVL(v_diag_seq_id,0)
  AND dd.primary_ailment_yn='Y';
  
  CURSOR icd_benefit_cur IS
  Select ic.benefit_type
  From tpa_icd10_master_details ic
  Where ic.icd_code = upper(v_diagnosys_code);
  
  v_icd_benefit         icd_benefit_cur%ROWTYPE;

  v_diag_count           number(2);
  v_primary              number(2);
  v_seq_id               number(10);
  v_count                number(5);
BEGIN 

if v_pat_auth_seq_id is not null then
authorization_pkg.reassign_user('|'||v_pat_auth_seq_id||'|',null,null,v_added_by,null,v_seq_id);
else
authorization_pkg.reassign_user(null,'|'||v_claim_seq_id||'|',null,v_added_by,null, v_seq_id);
end if;

  if v_pat_auth_seq_id is not null then
   OPEN pat_cur;
   FETCH pat_cur INTO pat_rec;
   CLOSE pat_cur;
  else
   OPEN clm_cur;
   FETCH clm_cur INTO pat_rec;
   CLOSE clm_cur;
  end if;   
  IF pat_rec.completed_yn='Y' THEN
    RAISE_APPLICATION_ERROR(-20107,'You cannot perform this action through a completed Claim.');
  END IF;

  OPEN diag_cur;
  FETCH diag_cur INTO v_diag_count;
  CLOSE diag_cur;

  OPEN primary_cur;
  FETCH primary_cur INTO v_primary;
  CLOSE primary_cur;

  IF NVL(v_priamry_yn,'N')='Y' AND v_primary>0 THEN
        RAISE_APPLICATION_ERROR(-20379,'Primary Diagnosis already Exists!');
  END IF;       



  IF v_diag_count>0 THEN
    RAISE_APPLICATION_ERROR(-20374,'Diagnosis code already Exists!');
  END IF;
  
  --ICD
  OPEN icd_benefit_cur;
  FETCH icd_benefit_cur INTO v_icd_benefit;
  CLOSE icd_benefit_cur;
  
  IF (v_icd_benefit.benefit_type = 'DNTL' OR pat_rec.benifit_type = 'DNTL') AND NVL(v_priamry_yn,'N')='Y' THEN
    IF NVL(v_icd_benefit.benefit_type, 'NA') != pat_rec.benifit_type THEN
      RAISE_APPLICATION_ERROR(-20323,'Ailment does not belogs to the selected benefit type, please select appropriate benefit type!');
    END IF;
  END IF;
  ---
  ---------- CR0248(Benefit type restriction for meternity icd) ---------
  select count(1) into v_count from tpa_icd_codes 
  where icd_code=UPPER(trim(v_diagnosys_code)) and master_icd_code='Z34.90' and NVL(v_priamry_yn,'N')='Y';
  
  IF  v_count >= 1 AND NVL(v_priamry_yn,'N')='Y' AND pat_rec.benifit_type NOT IN('IMTI','OMTI','MTI')THEN 
    RAISE_APPLICATION_ERROR(-20323,'Ailment does not belogs to the selected benefit type, please select appropriate benefit type!');
  END IF;  
  -------------------------------------------------------------------------
   IF v_presenting_comp is not null then
   UPDATE pat_authorization_details pad
     SET pad.presenting_complaints=v_presenting_comp
   WHERE pad.pat_auth_seq_id=v_pat_auth_seq_id;
   
   UPDATE clm_authorization_details cad
     SET cad.presenting_complaints=v_presenting_comp
   WHERE cad.claim_seq_id=v_claim_seq_id;
  END IF;

  IF v_duration_ailment IS NOT NULL AND v_duration_flag IS NOT NULL THEN
  UPDATE pat_authorization_details pad
      SET  pad.dur_ailment =  v_duration_ailment ,
        pad.duration_flag =  v_duration_flag     
   WHERE pad.pat_auth_seq_id=v_pat_auth_seq_id;
END IF;
   
   
IF v_duration_ailment IS NOT NULL AND v_duration_flag IS NOT NULL THEN
  UPDATE clm_authorization_details pad
      SET  pad.dur_ailment =  v_duration_ailment ,
        pad.duration_flag =  v_duration_flag     
   WHERE pad.claim_seq_id=v_claim_seq_id;
END IF; 

   IF v_claim_seq_id IS NOT NULL THEN  
    UPDATE APP.CLM_AUTHORIZATION_DETAILS CA
       SET CA.CAL_ACT_YN = 'N'
    WHERE CA.CLAIM_SEQ_ID = v_claim_seq_id;
   ELSE 
    UPDATE APP.PAT_AUTHORIZATION_DETAILS PA
       SET PA.CAL_ACT_YN = 'N'
    WHERE PA.PAT_AUTH_SEQ_ID = v_pat_auth_seq_id;
   END IF;  
   
   
  IF NVL(v_diag_seq_id,0)=0 THEN

    INSERT INTO diagnosys_details(
                diag_seq_id,
                pat_auth_seq_id,
                claim_seq_id,
                icd_code_seq_id,
                diagnosys_code,
                primary_ailment_yn,
                added_by,
                added_date)
          VALUES (
                diagnosys_detail_seq.nextval,
                v_pat_auth_seq_id,
                v_claim_seq_id,
                v_icd_code_seq_id,
                UPPER(TRIM(v_diagnosys_code)),
                v_priamry_yn,
                v_added_by,
                SYSDATE) RETURNING DIAG_SEQ_ID INTO v_diag_seq_id;
   ELSE

      UPDATE diagnosys_details SET
          PAT_AUTH_SEQ_ID      =  V_PAT_AUTH_SEQ_ID,
          claim_seq_id         =  v_claim_seq_id,
          icd_code_seq_id      =  v_icd_code_seq_id,
          diagnosys_code       =  upper(v_diagnosys_code),
          primary_ailment_yn   =  v_priamry_yn,
          updated_by           =  v_added_by,
          updated_date         =  sysdate
    WHERE DIAG_SEQ_ID =v_diag_seq_id;

  END IF;

  v_rows_processed:=SQL%ROWCOUNT;
  check_pat_approved(v_pat_auth_seq_id,v_added_by);
 COMMIT;

END save_diagnosys_details;
--===============================================================================
PROCEDURE save_activity_details(
    v_activity_dtl_seq_id     IN OUT pat_activity_details.activity_dtl_seq_id%TYPE,
    v_pat_auth_seq_id         IN  pat_activity_details.pat_auth_seq_id%TYPE,
    v_claim_seq_id            IN  pat_activity_details.claim_seq_id%TYPE,
    v_activity_id             IN  pat_activity_details.activity_id%TYPE,
    v_Activity_Seq_Id         IN  pat_activity_details.Activity_Seq_Id%TYPE,
    v_start_date              IN  pat_activity_details.start_date%TYPE,
    v_activity_type           IN  pat_activity_details.activity_type%TYPE,
    v_code                    IN  pat_activity_details.code%TYPE,
    v_unit_type               IN  pat_activity_details.unit_type%TYPE,
    v_modifier                IN  pat_activity_details.modifier%TYPE,
    v_internal_code           IN  pat_activity_details.internal_code%TYPE,
    v_package_id              IN  pat_activity_details.package_id%TYPE,
    v_bundle_id               IN  pat_activity_details.bundle_id%TYPE,
    v_quantity                IN  pat_activity_details.quantity%TYPE,
    v_gross_amount            IN  pat_activity_details.gross_amount%TYPE,
    v_discount_amount         IN  pat_activity_details.discount_amount%TYPE,
    v_disc_gross_amount       IN  pat_activity_details.disc_gross_amount%TYPE,
    v_patient_share_amount    IN  pat_activity_details.patient_share_amount%TYPE,
    v_copay_amount            IN  pat_activity_details.copay_amount%TYPE,
    v_co_ins_amount           IN  pat_activity_details.co_ins_amount%TYPE,
    v_deduct_amount           IN  pat_activity_details.deduct_amount%TYPE,
    v_out_of_pocket_amount    IN  pat_activity_details.out_of_pocket_amount%TYPE,
    v_net_amount              IN  pat_activity_details.net_amount%TYPE,
    v_allowed_amount          IN  pat_activity_details.allowed_amount%TYPE,
    v_approved_amount         IN  pat_activity_details.approved_amount%TYPE,
    v_allow_yn                IN  pat_activity_details.allow_yn%TYPE,
    v_denial_code             IN  pat_activity_details.denial_code%TYPE,
    v_remarks                 IN  pat_activity_details.remarks%TYPE,
    v_added_by                IN  pat_activity_details.added_by%TYPE,
    v_approved_quantity       IN  pat_activity_details.approvd_quantity%type,
    v_unit_price              IN  pat_activity_details.unit_price%type,
    v_clinician_id            IN  pat_activity_details.clinician_id%type,
    v_override_yn             IN  pat_activity_details.override_yn%type,
    v_override_remarks_code   IN  pat_activity_details.override_Remarks_Code%TYPE,  -- added in Override remarks drop down cr
    v_approve_yn              IN  pat_activity_details.approve_yn%TYPE,
    v_duration_days           IN  pat_activity_details.posology_duration%TYPE,
    v_posology                IN  pat_activity_details.posology%TYPE,
    v_req_amount              IN  pat_activity_details.provider_net_amount%TYPE,
    v_denial_desc             IN  pat_activity_details.denial_desc%TYPE,
    v_service_type            IN  pat_activity_details.service_type%TYPE,
    v_service_code            IN  pat_activity_details.service_code%TYPE,
    v_ucr                     IN  pat_activity_details.ucr%TYPE DEFAULT NULL,
    v_denial_res_dis          IN  pat_activity_details.denial_res_dis%TYPE DEFAULT NULL,
    v_non_network_co_pay      in  pat_activity_details.non_network_co_pay%type, 
    v_converted_acitivty_amt  in  pat_activity_details.converted_acitivty_amt%type, 
    v_internal_desc           IN  pat_activity_details.internal_desc%TYPE,
    v_tooth_no                IN  pat_activity_details.tooth_no%TYPE,
    v_mem_service_code        IN  pat_activity_details.mem_service_Code%TYPE,
    v_mem_service_desc        IN  pat_activity_details.mem_service_desc%TYPE,
	  v_act_type                IN  VARCHAR2,
    v_override_remarks        IN  pat_activity_details.override_remarks%TYPE,
    v_other_remarks           IN  pat_activity_details.other_remarks%TYPE,       -- added in Override remarks drop down cr
    v_rows_processed          OUT NUMBER,
    v_delt_den_code           IN  pat_activity_details.delt_den_code%TYPE,
    v_delt_den_code_desc      IN  pat_activity_details.delt_den_code_desc%TYPE)
 IS
 v_prod_pol_rule_seq_id       tpa_ins_prod_policy_rules.prod_policy_rule_seq_id%type;



 CURSOR act_cur IS
  SELECT max(pad.s_no) max_sno
  FROM pat_activity_details pad
  WHERE pad.pat_auth_seq_id=v_pat_auth_seq_id;

  CURSOR clm_act_cur IS
  SELECT max(pad.s_no) max_sno
  FROM pat_activity_details pad
  WHERE pad.claim_seq_id=v_claim_seq_id;

  CURSOR pat_diag_cur IS
  SELECT count(1) 
  FROM diagnosys_details dd
  WHERE dd.pat_auth_seq_id=v_pat_auth_seq_id;

  CURSOR clm_diag_cur IS
  SELECT count(1) 
  FROM diagnosys_details dd
  WHERE dd.claim_seq_id=v_claim_seq_id;

  CURSOR pat_cur IS
 SELECT pad.pat_auth_seq_id,
       pad.pat_batch_seq_id,
       pad.claim_seq_id,
       pad.member_seq_id,       
       pad.final_app_amount,
       pad.denial_reason,
       pad.completed_yn,
       pad.source_type_id
  FROM pat_authorization_details pad
  WHERE pad.pat_auth_seq_id=v_pat_auth_seq_id;

 CURSOR clm_cur IS
 SELECT cad.claim_seq_id,
        cad.clm_batch_seq_id,
        cad.pat_auth_seq_id,
        cad.member_seq_id,       
        cad.final_app_amount,
        cad.denial_reason,
        cad.completed_yn,
        cad.source_type_id
  FROM clm_authorization_details cad
  WHERE cad.claim_seq_id=v_claim_seq_id;

 pat_rec              pat_cur%ROWTYPE;
 act_rec              act_cur%ROWTYPE;
 v_s_no               NUMBER;
 v_diag_count         NUMBER;

 v_copay_per          number:=0;
 v_rule_limit         number:=null;
 v_prior_authid    varchar2(100);
 v_check_ucr_yn   CHAR(1);
 v_cb_act_cnt     NUMBER;
 v_Seq_id         NUMBER(10);
 
 CURSOR check_flag_cur IS
   SELECT NVL(C.UCR_FLAG, NULL) AS UCR_FLAG
   FROM CLM_AUTHORIZATION_DETAILS C
   WHERE C.CLAIM_SEQ_ID = v_claim_seq_id;


BEGIN
  
 if v_pat_auth_seq_id is not null then
authorization_pkg.reassign_user('|'||v_pat_auth_seq_id||'|',null,null,v_added_by,null,v_Seq_id);
else
authorization_pkg.reassign_user(null,'|'||v_claim_seq_id||'|',null,v_added_by,null,v_Seq_id);
end if;
  
IF v_pat_auth_seq_id IS NOT NULL THEN 
  OPEN pat_diag_cur;
  FETCH pat_diag_cur INTO v_diag_count;
  CLOSE pat_diag_cur;
 ELSE 
  OPEN clm_diag_cur;
  FETCH clm_diag_cur INTO v_diag_count;
  CLOSE clm_diag_cur; 
   END IF;

  if v_pat_auth_seq_id is not null then
   OPEN pat_cur;
   FETCH pat_cur INTO pat_rec;
   CLOSE pat_cur;
   if pat_rec.pat_auth_seq_id is not null then 

  select pa.pre_auth_number into v_prior_authid from app.pat_authorization_details pa where pa.pat_auth_seq_id=pat_rec.pat_auth_seq_id;

  end if ;

  else
   OPEN clm_cur;
   FETCH clm_cur INTO pat_rec;
   CLOSE clm_cur;
  end if;
  
  IF v_pat_auth_seq_id IS NOT NULL THEN 
   SELECT COUNT(1) INTO v_cb_act_cnt
   FROM pat_authorization_details pa
   JOIN pat_activity_details a ON (pa.pat_auth_seq_id=a.pat_auth_seq_id)
   WHERE pa.pat_auth_seq_id = v_pat_auth_seq_id
    AND a.code = 'CB';
  ELSE 
   SELECT COUNT(1) INTO v_cb_act_cnt
   FROM clm_authorization_details ca
   JOIN pat_activity_details a ON (ca.claim_seq_id=a.claim_seq_id)
   WHERE ca.claim_seq_id = v_claim_seq_id
    AND a.code = 'CB';
  END IF;
  
  IF v_cb_act_cnt > 0 THEN
    RAISE_APPLICATION_ERROR(-20457,'Same activity code already added for this claim.');
  END IF;
  
  IF pat_rec.completed_yn='Y' THEN
    RAISE_APPLICATION_ERROR(-20107,'You cannot perform this action through a completed Claim.');
  END IF;

  IF v_diag_count<1 THEN
    RAISE_APPLICATION_ERROR(-20380,'Please add atleast one Diagnosis');
  END IF;

  /*IF v_disc_gross_amount < v_ucr THEN
    RAISE_APPLICATION_ERROR(-20311,'UCR Amount can not be greater then Requested Amount');
  END IF;*/
  --==========

  open check_flag_cur;
  fetch check_flag_cur into v_check_ucr_yn;
  close check_flag_cur;
  
   IF v_claim_seq_id IS NOT NULL THEN  
    UPDATE APP.CLM_AUTHORIZATION_DETAILS CA
       SET CA.CAL_ACT_YN = 'N'
    WHERE CA.CLAIM_SEQ_ID = v_claim_seq_id;
   ELSE 
    UPDATE APP.PAT_AUTHORIZATION_DETAILS PA
       SET PA.CAL_ACT_YN = 'N'
    WHERE PA.PAT_AUTH_SEQ_ID = v_pat_auth_seq_id;
   END IF; 

  IF NVL(v_activity_dtl_seq_id,0)=0 THEN


    if v_pat_auth_seq_id is not null then
     OPEN act_cur;
     FETCH act_cur INTO act_rec;
     CLOSE act_cur;
    else
     OPEN clm_act_cur;
     FETCH clm_act_cur INTO act_rec;
     CLOSE clm_act_cur;
    end if;
    v_s_no:=NVL(act_rec.max_sno,0)+1;


    INSERT INTO pat_activity_details(
                activity_dtl_seq_id,
                pat_auth_seq_id,
                claim_seq_id,
                Activity_Seq_Id,
                activity_id,
                s_no,
                start_date,
                activity_type,
                code,
                unit_type,
                modifier,
                internal_code,
                package_id,
                bundle_id,
                quantity,
                gross_amount,
                discount_amount,
                disc_gross_amount,
                patient_share_amount,
                co_ins_amount,
                deduct_amount,
                out_of_pocket_amount,
                net_amount,
                allowed_amount,
                approved_amount,
                allow_yn,
                denial_code,
                remarks,
                added_by,
                added_date,
                denial_desc,
                approvd_quantity,
                unit_price,
                clinician_id,
                unit_discount_amount,
                provider_copay,
                override_yn,
                override_remarks,
                approve_yn,
                posology_duration,
                posology,
                provider_net_amount,
			          prior_authid,
                service_type,
                service_code,
                service_remarks,
                ucr,
                ri_copar,
                denial_res_dis,
                non_network_co_pay,     ----
                internal_desc,
                converted_acitivty_amt,      ----
                tooth_no,
		    mem_service_Code,
		    mem_service_desc,
		    activity_type_id,
        override_remarks_code,
        other_remarks
                 )
          VALUES (
                pat_activity_detail_seq.nextval,
                v_pat_auth_seq_id,
                v_claim_seq_id,
                v_Activity_Seq_Id,
                v_activity_id,
                v_s_no,
                v_start_date,
                case when v_code != 'S5001-00001-0001' then v_activity_type end,
                UPPER(TRIM(v_code)),
                v_unit_type,
                v_modifier,
                v_internal_code,
                v_package_id,
                v_bundle_id,
                v_quantity,
                v_gross_amount,
                v_discount_amount,
                v_disc_gross_amount,
                v_patient_share_amount,
                v_co_ins_amount,
                v_deduct_amount,
                v_out_of_pocket_amount,
                v_net_amount,
                v_allowed_amount,
                v_approved_amount,
                NVL(v_allow_yn,'Y'),
                v_denial_code,
                v_remarks,
                v_added_by,
                SYSDATE,
                v_denial_desc,
                v_approved_quantity,
                v_unit_price,
                v_clinician_id,
                nvl(v_discount_amount,0)/v_quantity,
                v_copay_amount,
                v_override_yn,
                v_override_remarks,
                v_approve_yn,
                v_duration_days,
                v_posology,
                v_req_amount,
				        v_prior_authid,
                v_service_type,
                v_service_code,
                case when nvl(v_service_type,'ACD') != 'ACD' then v_remarks else null end, 
                CASE WHEN v_check_ucr_yn = 'Y' THEN v_ucr ELSE 0 END,--Changed by priyadarshan
                NULL,
                v_denial_res_dis,
                v_non_network_co_pay,      ----
                v_internal_desc,
                v_converted_acitivty_amt,      ----
                v_tooth_no,
		    v_mem_service_code,
		    v_mem_service_desc,
		    case when v_code = 'S5001-00001-0001' then 'DRG' else v_act_type end,
        v_override_remarks_code,
        v_other_remarks

                  ) RETURNING activity_dtl_seq_id INTO v_activity_dtl_seq_id;


   ELSE

      UPDATE pat_activity_details SET
          pat_auth_seq_id       =  v_pat_auth_seq_id,
          claim_seq_id          =  v_claim_seq_id,
          Activity_Seq_Id       =  v_Activity_Seq_Id,    
          start_date            =  v_start_date,
          activity_type         =  case when v_code != 'S5001-00001-0001' then v_activity_type end,
          code                  =  UPPER(TRIM(v_code)),
          unit_type             =  v_unit_type,
          modifier              =  v_modifier,
          internal_code         =  v_internal_code,
          package_id            =  v_package_id,
          bundle_id             =  v_bundle_id,
          quantity              =  v_quantity,
          gross_amount          =  v_gross_amount,
          discount_amount       =  v_discount_amount,
          disc_gross_amount     =  v_disc_gross_amount,
          patient_share_amount  =  v_patient_share_amount,
          copay_perc            =  v_copay_per,
          provider_copay        =  v_copay_amount,
          co_ins_amount         =  v_co_ins_amount,
          deduct_amount         =  v_deduct_amount,
          out_of_pocket_amount  =  v_out_of_pocket_amount,
          net_amount            =  v_net_amount,
          allowed_amount        =  v_allowed_amount,
          approved_amount       =  v_approved_amount,
          allow_yn              =  NVL(v_allow_yn,'Y'),
          denial_code           =  CASE WHEN NVL(PBM_WB_SRVC_EXEC_YN,'N') = 'Y' THEN denial_code
                                   ---WHEN denial_code is not null AND v_denial_code IS NOT NULL THEN
                                 ----  CASE  WHEN denial_code LIKE '%'||v_denial_code||'%' THEN denial_code ELSE rtrim(denial_code,';')||';'||ltrim(replace(v_denial_code,denial_code,''),';') END
                                  --- WHEN denial_code is not null AND v_denial_code IS NULL then denial_code 
                                   ELSE v_denial_code END,
          remarks               =  null,
          denial_desc           =   CASE WHEN NVL(PBM_WB_SRVC_EXEC_YN,'N') = 'Y' THEN denial_desc 
                                   --- WHEN denial_desc is not null AND v_denial_desc IS NOT NULL THEN
                                   --- CASE  WHEN denial_desc LIKE '%'||v_denial_desc||'%' THEN denial_desc ELSE rtrim(denial_desc,';')||';'||ltrim(REPLACE(v_denial_desc,denial_desc,''),';') END
                                 ---   WHEN denial_desc is not null AND v_denial_desc IS NULL then denial_desc 
                                    ELSE v_denial_desc END,
          updated_by            =  v_added_by,
          updated_date          =  SYSDATE,
          approvd_quantity      =  v_approved_quantity,
          unit_price            =  v_unit_price,
          rule_limit            =  v_rule_limit,
          clinician_id          =  v_clinician_id,
          unit_discount_amount  =  (nvl(v_discount_amount,0)/v_quantity),
          override_yn           =  nvl(v_override_yn,'N'),
          override_remarks      =  v_override_remarks,
          approve_yn            =  v_approve_yn,
          posology_duration     =  v_duration_days,
          posology              =  v_posology,
          service_type          =  v_service_type,
          service_code          =  v_service_code,
          service_remarks       =  case when nvl(v_service_type,'ACD') != 'ACD' then v_remarks else null end, ----
          ucr                   =  CASE WHEN v_check_ucr_yn = 'Y' THEN v_ucr ELSE 0 END,
          denial_res_dis        = v_denial_res_dis,
          non_network_co_pay    = v_non_network_co_pay,    ----
          internal_desc         = v_internal_desc,
          converted_acitivty_amt =v_converted_acitivty_amt,    ----
          tooth_no            = v_tooth_no,
	    mem_service_Code    = v_mem_service_code,
	    mem_service_desc    = v_mem_service_desc,
	    activity_type_id    =  case when v_code = 'S5001-00001-0001' then 'DRG' else v_act_type end,
      	provider_net_amount =v_req_amount,
        override_remarks_code  =v_override_remarks_code,
        other_remarks          =v_other_remarks, 
        delt_den_code          =  case when v_delt_den_code is not null then
                                  case when delt_den_code is null then v_delt_den_code else delt_den_code||';'||v_delt_den_code end end,
        delt_den_code_desc  = case when v_delt_den_code_desc is not null then
                                 case when delt_den_code_desc is null then v_delt_den_code_desc else delt_den_code_desc||';'||v_delt_den_code_desc end
                              end
      WHERE activity_dtl_seq_id =  v_activity_dtl_seq_id;


 END IF;
  v_rows_processed:=SQL%ROWCOUNT;
  check_pat_approved(v_pat_auth_seq_id,v_added_by);
  COMMIT;
END save_activity_details;
--===============================================================================
PROCEDURE save_observation_details(
    v_observation_seq_id  IN OUT pat_observation_details.observation_seq_id%TYPE,
    v_activity_dtl_seq_id  IN pat_observation_details.activity_dtl_seq_id%TYPE,
    v_mode                IN VARCHAR2,
    v_seq_id              IN pat_authorization_details.pat_auth_seq_id%TYPE,
    v_type                IN pat_observation_details.observation_type_id%TYPE,
    v_code                IN pat_observation_details.observation_code_id%TYPE,
    v_value                IN pat_observation_details.value%TYPE,
    v_value_type_id        IN pat_observation_details.obs_value_type_id%TYPE,
    v_added_by            IN pat_observation_details.added_by%TYPE,
    v_remarks              IN pat_observation_details.REMARKS%TYPE,
    v_rows_processed      OUT NUMBER )

 IS

CURSOR pat_cur IS
 SELECT pad.pat_auth_seq_id,
       pad.pat_batch_seq_id,
       pad.claim_seq_id,
       pad.member_seq_id,       
       pad.final_app_amount,
       pad.denial_reason,
       pad.completed_yn
  FROM pat_authorization_details pad
  WHERE pad.pat_auth_seq_id=v_seq_id;


CURSOR clm_cur IS
 SELECT pad.pat_auth_seq_id,
       pad.clm_batch_seq_id,
       pad.claim_seq_id,
       pad.member_seq_id,       
       pad.final_app_amount,
       pad.denial_reason,
       pad.completed_yn
  FROM clm_authorization_details pad
  WHERE pad.claim_seq_id=v_seq_id;

 pat_rec              pat_cur%ROWTYPE;

BEGIN
 if v_mode='PAT' then  
  OPEN pat_cur;
  FETCH pat_cur INTO pat_rec;
  CLOSE pat_cur;
 else 
  OPEN clm_cur;
  FETCH clm_cur INTO pat_rec;
  CLOSE clm_cur;
 end if;
  IF pat_rec.completed_yn='Y' THEN
    RAISE_APPLICATION_ERROR(-20107,'You cannot perform this action through a completed Claim.');
  END IF;

  IF NVL(V_OBSERVATION_SEQ_ID,0)=0 THEN

    INSERT INTO pat_observation_details(
                observation_seq_id,
                activity_dtl_seq_id,
                observation_type_id,
                observation_code_id,
                value,
                obs_value_type_id,
                added_by,
                added_date,
                REMARKS )
          VALUES (
                pat_observation_detail_seq.Nextval,
                v_activity_dtl_seq_id,
                v_type,
                v_code,
                v_value,
                v_value_type_id,
                v_added_by,
                sysdate,
                V_remarks) RETURNING OBSERVATION_SEQ_ID INTO V_OBSERVATION_SEQ_ID;
   ELSE

      UPDATE pat_observation_details SET
          activity_dtl_seq_id      = v_activity_dtl_seq_id,
          observation_type_id     = v_type,
          observation_code_id     = v_code,
          value                    = v_value,
          obs_value_type_id       = v_value_type_id,
          REMARKS                 = V_remarks,
          updated_by              = v_added_by,
          updated_date            = sysdate
    WHERE OBSERVATION_SEQ_ID =  V_OBSERVATION_SEQ_ID;

  END IF;
 v_rows_processed:=SQL%ROWCOUNT;

 commit;
END save_observation_details;
--===============================================================================
FUNCTION generate_id_numbers (
    v_flag                           IN VARCHAR2,
    v_country_id                     IN VARCHAR2,
    v_state_id                       IN VARCHAR2,
    v_number                         IN VARCHAR2,  -- CAN BE PREAUTH NUMBER OR SHORTFALL_ID OR INVESTIGATION_ID
    v_claim_type                     IN VARCHAR2 := NULL
  ) RETURN VARCHAR2
  IS
    PRAGMA AUTONOMOUS_TRANSACTION ;
    v_office_code                    tpa_office_info.office_code%TYPE;
    v_result                         VARCHAR2(60);
    v_last_number                    VARCHAR2(60);
    v_settlement_flag                VARCHAR2(4);
    v_country_enroll_code            VARCHAR2(10);
    V_SUB_STR                        VARCHAR2(50);
    V_SEARCH_STR                     VARCHAR2(50);
    CURSOR pa_cur(v_result VARCHAR2) IS SELECT MAX(pre_auth_number)
                                          FROM pat_authorization_details
                                         WHERE pre_auth_number LIKE v_result||'%';


   /* CURSOR clm_cur(v_result VARCHAR2) IS SELECT MAX(claim_number )
                                          FROM clm_authorization_details
                                         WHERE claim_number  LIKE v_result||'%';*/

	  CURSOR qtr_clm_cur(v_result VARCHAR2) IS 
      SELECT MAX(S.QTR_CLM_NO_MAX_SEQ_RCH)
      FROM APP.TPA_SEQ_NO_GEN_DETAILS S;-----NEW
      
    CURSOR oth_clm_cur(v_result VARCHAR2) IS 
      SELECT MAX(S.OTH_CLM_NO_MAX_SEQ_RCH)
      FROM APP.TPA_SEQ_NO_GEN_DETAILS S;-----NEW  
      
    CURSOR ind_clm_cur(v_result VARCHAR2) IS 
      SELECT MAX(S.IND_CLM_NO_MAX_SEQ_RCH)
      FROM APP.TPA_SEQ_NO_GEN_DETAILS S;-----NEW   

    CURSOR settlement_cur (v_result VARCHAR2) IS SELECT MAX(a.SETTLEMENT_NUMBER )
                                          FROM clm_authorization_details A
                                         WHERE a.SETTLEMENT_NUMBER  LIKE v_result||'%';
                                         
    CURSOR file_number_cur (v_result VARCHAR2) IS SELECT MAX(a.claim_file_number)
                                          FROM clm_general_details A
                                         WHERE a.claim_file_number  LIKE v_result||'%';

   CURSOR shortfall_cur(V_STR VARCHAR2) IS SELECT MAX(a.shortfall_id)
                                  FROM shortfall_details a
                                 WHERE a.shortfall_id LIKE V_STR||'-%';
   CURSOR COUNTRY_CODE_CUR IS SELECT B.COUNTRY_ENROLL_CODE FROM TPA_COUNTRY_CODE A 
                               JOIN tpa_country_eroll_code B ON (A.COUNTRY_ID=B.COUNTRY_ID) 
                                WHERE A.SHORT_NAME=v_country_id;
    CURSOR AUTH_CUR(v_result VARCHAR2) IS SELECT MAX(AUTH_NUMBER)  
                                  FROM pat_authorization_details 
                                  WHERE AUTH_NUMBER LIKE V_RESULT||'%';                             
	  
    CURSOR PRC_REF_CUR(v_result VARCHAR2) IS SELECT MAX(ref_no)  
                                  FROM app.tpa_group_profile_details p 
                                  WHERE p.ref_no LIKE V_RESULT||'%';
                                  
    CURSOR CUR_PRC_IP_VRN IS
      SELECT COUNT(1) AS VRN_LOG_CNT
      FROM APP.TPA_GROUP_FNL_CPM_LOG_DETAILS L
      WHERE L.GRP_PROF_SEQ_ID= v_country_id; 
      
   CURSOR CUR_MAX_POL_MID_NUM_DTLS IS
     SELECT MAX(SUBSTR( EP.POLICY_NUMBER ,INSTR(EP.POLICY_NUMBER,'/',1,2)+1,
               	  (INSTR(EP.POLICY_NUMBER,'/',-1,2)-INSTR(EP.POLICY_NUMBER,'/',1,2))-1)) AS MID_NUM
        FROM APP.TPA_ENR_POLICY EP;
      
    CURSOR CUR_GRP_POL_CNT IS
     SELECT COUNT(1)
     FROM APP.TPA_ENR_POLICY EP
     JOIN APP.TPA_GROUP_REGISTRATION GR ON (EP.GROUP_REG_SEQ_ID=GR.GROUP_REG_SEQ_ID)
     WHERE GR.GROUP_ID = v_country_id;
        
    CURSOR CUR_PRC_QOT_NO IS
      SELECT COUNT(1) AS VRN_LOG_CNT
      FROM APP.TPA_GROUP_PROF_POL_CPY_DOCS L;  
      
  CURSOR check_Common_File_Number(file_number  VARCHAR2) IS
    SELECT max(substr(cad.common_file_number,13))
         from clm_authorization_details cad
         where cad.common_file_number LIKE file_number||'%';
 
CURSOR cur_grp_pol_mid_num IS
     SELECT MAX(SUBSTR( EP.POLICY_NUMBER ,INSTR(EP.POLICY_NUMBER,'/',1,2)+1,
               	  (INSTR(EP.POLICY_NUMBER,'/',-1,2)-INSTR(EP.POLICY_NUMBER,'/',1,2))-1)) AS MID_NUM
     FROM APP.TPA_ENR_POLICY EP
     JOIN APP.TPA_GROUP_REGISTRATION GR ON (EP.GROUP_REG_SEQ_ID=GR.GROUP_REG_SEQ_ID)
     WHERE GR.GROUP_ID = v_country_id;
   V_POL_MID_NUM               VARCHAR2(50);
   V_POL_LST_NUM               VARCHAR2(50);
   v_file_num                  VARCHAR2(500);
   v_common_file_number        VARCHAR2(500);
   V_MAX_POL_MID_NUM               VARCHAR2(50);
   V_GRP_POL_MID_NUM               VARCHAR2(50);
   V_GRP_POL_CNT                   NUMBER(10);
                                
                                  
  BEGIN
    OPEN COUNTRY_CODE_CUR;
    FETCH COUNTRY_CODE_CUR INTO v_country_enroll_code;
    CLOSE COUNTRY_CODE_CUR;


    IF v_flag = 'PA' THEN -- PREAUTH NUMBER
    
     IF v_country_enroll_code IS NULL OR  v_country_enroll_code != 11 THEN    ----NEWLY ADDED FOR CREATING SAME PREAUTH NUMBER FORMAT FOR  ALL COUNTRY AS PER SWAROOP REQUEST
       
       v_country_enroll_code := 11;
       
     END IF;  
    
       v_result := NVL(v_country_enroll_code,'44')||'1';

      OPEN pa_cur(v_result);
      FETCH pa_cur INTO v_last_number;
      CLOSE pa_cur;

      IF v_last_number IS NULL THEN
        v_result := v_result||'0000001';
      ELSE
        v_result := v_result ||LPAD(TO_NUMBER(SUBSTR(v_last_number,-7))+1,7,'0');
      END IF;
    ELSIF v_flag = 'AT' THEN    -- AUTHORIZATION NUMBER
    
     IF v_country_enroll_code IS NULL OR  v_country_enroll_code != 11 THEN   ----NEWLY ADDED FOR CREATING SAME AUTHORIZATION  NUMBER FORMAT FOR  ALL COUNTRY AS PER SWAROOP REQUEST
       
       v_country_enroll_code := 11;
       
     END IF;   
    
       v_result := NVL(v_country_enroll_code,'44')||'3';
      
      OPEN AUTH_CUR(v_result);
      FETCH AUTH_CUR INTO v_last_number;
      CLOSE AUTH_CUR;
      
     IF v_last_number IS NULL THEN
        v_result := v_result || LPAD(TO_NUMBER(SUBSTR(v_number,-7)),7,'0');
      ELSE
        v_result := v_result ||LPAD(TO_NUMBER(SUBSTR(v_number,-7)),7,'0');
      END IF;
    ELSIF v_flag = 'CNH'  or v_flag = 'CTM' THEN    -- AUTHORIZATION NUMBER
      v_result := NVL(v_country_enroll_code,'44')||'8';
  ELSIF v_flag IN ('STC','STA') THEN  -- SETTLEMENT NUMBER
      IF v_claim_type = 'CNH' THEN
        v_settlement_flag := 'CH';
        TTK_UTIL_PKG.reset_id_flag(v_office_code||'NHCP_SETTLEMENT','N');
      ELSE
        v_settlement_flag := 'CR';
        TTK_UTIL_PKG.reset_id_flag(v_office_code||'MR_SETTLMENT','N');
      END IF;
      IF v_flag = 'STA' THEN
        v_settlement_flag := 'A'||SUBSTR(v_settlement_flag,2);
      END IF;

      IF v_country_enroll_code IS NULL OR  v_country_enroll_code != 11 THEN   ----NEWLY ADDED FOR CREATING SAME SETTLEMENT  NUMBER FORMAT FOR  ALL COUNTRY AS PER SWAROOP REQUEST
         
          v_country_enroll_code  := 11;
          
      END IF;
        
         v_result := NVL(v_country_enroll_code,'44')||'8';

      OPEN settlement_cur(v_result);
      FETCH settlement_cur INTO v_last_number;
      CLOSE settlement_cur;

      IF v_last_number IS NULL THEN
        v_result := v_result ||LPAD(TO_NUMBER(SUBSTR(v_number,-7)),7,'0');
      ELSE
        v_result := v_result ||LPAD(TO_NUMBER(SUBSTR(v_number,-7)),7,'0');
      END IF;

    ELSIF v_flag = 'FL' THEN          -- FILE NUMBER IN CLAIMS

      v_result := v_office_code||'-'||to_char(SYSDATE,'mmyy')||'-'||v_flag||'-';
      TTK_UTIL_PKG.reset_id_flag(v_office_code||'FILENUMBER','N');
      OPEN file_number_cur( v_result );
      FETCH file_number_cur INTO v_last_number;
      CLOSE file_number_cur;

      IF v_last_number IS NULL THEN
        v_result := v_result || '0000001';
      ELSE
        v_result := v_result ||LPAD(TO_NUMBER(SUBSTR(v_last_number,-7))+1,7,'0');
      END IF;
      --TTK_UTIL_PKG.reset_id_flag(v_office_code||'FILENUMBER','Y');
    ELSIF v_flag = 'CL' OR v_flag = 'RS' THEN   -- CLAIM NUMBER OR AMMENDMENT
    
    IF  v_country_enroll_code IS NULL OR v_country_enroll_code  != 11 THEN  ----NEWLY ADDED FOR CREATING SAME CLAIM NUMBER FORMAT FOR  ALL COUNTRY AS PER SWAROOP REQUEST
      
       v_country_enroll_code := 11;
       
    END IF;
      
      v_result := NVL(v_country_enroll_code,'44')||'7';
        
      IF v_country_enroll_code = 11 THEN  
        OPEN  qtr_clm_cur(v_result);
        FETCH qtr_clm_cur INTO v_last_number;
        CLOSE qtr_clm_cur;
      ELSIF v_country_enroll_code = 22 THEN
      
        OPEN  ind_clm_cur(v_result);
        FETCH ind_clm_cur INTO v_last_number;
        CLOSE ind_clm_cur;
      ELSE
        OPEN  oth_clm_cur(v_result);
        FETCH oth_clm_cur INTO v_last_number;
        CLOSE oth_clm_cur;
      END IF;  

      IF v_last_number IS NULL THEN
        v_result := v_result || '0000001';
      ELSE
        v_result := v_result ||LPAD(QAR_CLAIM_SEQ.NEXTVAL, 7, 0);--LPAD(TO_NUMBER(SUBSTR(v_last_number,-7))+1,7,'0');
      END IF;
      
      IF v_country_enroll_code = 11 THEN
        UPDATE APP.TPA_SEQ_NO_GEN_DETAILS S
         SET S.qtr_clm_no_max_seq_rch = v_result;
      ELSIF v_country_enroll_code = 22 THEN
        UPDATE APP.TPA_SEQ_NO_GEN_DETAILS S
         SET S.IND_CLM_NO_MAX_SEQ_RCH = v_result;
      ELSE
        UPDATE APP.TPA_SEQ_NO_GEN_DETAILS S
         SET S.oth_clm_no_max_seq_rch = v_result;
      END IF;   
     
     
     ELSIF v_flag = 'STH' THEN  -- Shortfall
     
    V_SUB_STR:=SUBSTR(v_number,3,1);
      IF V_SUB_STR='1' THEN
      V_SEARCH_STR:=SUBSTR(v_number,1,2)|| REPLACE(SUBSTR(v_number,3,1),1,2)||SUBSTR(v_number,4);
      ELSIF V_SUB_STR='7' THEN
        V_SEARCH_STR:=SUBSTR(v_number,1,2)|| REPLACE(SUBSTR(v_number,3,1),7,6)||SUBSTR(v_number,4);
      ELSE
        V_SEARCH_STR:=V_NUMBER;
        END IF;
       OPEN shortfall_cur(V_SEARCH_STR);
       FETCH shortfall_cur INTO v_result ;
       CLOSE shortfall_cur;
      IF v_result IS NULL THEN
        IF V_SUB_STR='1' THEN
        v_result := SUBSTR(v_number,1,2)|| REPLACE(SUBSTR(v_number,3,1),1,2)||SUBSTR(v_number,4)||'-01';
       ELSIF V_SUB_STR='7' THEN
        v_result := SUBSTR(v_number,1,2)|| REPLACE(SUBSTR(v_number,3,1),7,6)||SUBSTR(v_number,4)||'-01';
        ELSE
           v_result:=v_number||'-01';
        END IF;
      ELSE
        v_result := SUBSTR(v_result,1, length(v_result) - 2)|| lpad(to_number( SUBSTR(v_result,-2) ) + 1,2,'0');
      END IF;
     ELSIF v_flag = 'PRC_REF' THEN  
        v_result := 'PRC'||'-'||to_char(SYSDATE,'MMYY')||'-';

      OPEN  PRC_REF_CUR( v_result );
      FETCH PRC_REF_CUR INTO v_last_number;
      CLOSE PRC_REF_CUR;

      IF v_last_number IS NULL THEN
        v_result := v_result || '00001';
      ELSE
        v_result := v_result ||LPAD(TO_NUMBER(SUBSTR(v_last_number,-5))+1,5,'0');
      END IF;
    ELSIF v_flag = 'PRC_VRN' THEN  
        --v_result := 'Version No. ';

      OPEN  CUR_PRC_IP_VRN;
      FETCH CUR_PRC_IP_VRN INTO v_last_number;
      CLOSE CUR_PRC_IP_VRN;

      IF NVL(v_last_number,0) = 0 THEN
        v_result := '1';
      ELSE
        v_result := TRIM(v_last_number);
      END IF;
    ELSIF v_flag = 'PRC_POL' THEN  
      v_result := 'AK/HC/';

      OPEN  cur_grp_pol_mid_num;
      FETCH cur_grp_pol_mid_num INTO V_GRP_POL_MID_NUM;
      CLOSE cur_grp_pol_mid_num;
      
      OPEN  CUR_GRP_POL_CNT;
      FETCH CUR_GRP_POL_CNT INTO V_GRP_POL_CNT;
      CLOSE CUR_GRP_POL_CNT;
      
      
      OPEN  CUR_MAX_POL_MID_NUM_DTLS;
      FETCH CUR_MAX_POL_MID_NUM_DTLS INTO V_MAX_POL_MID_NUM;
      CLOSE CUR_MAX_POL_MID_NUM_DTLS;
      
      IF V_GRP_POL_MID_NUM IS NOT NULL THEN
        V_GRP_POL_CNT := V_GRP_POL_CNT +1;
        v_result:= v_result||V_GRP_POL_MID_NUM||'/'||CASE WHEN v_number IS NULL THEN 0 ELSE 1 END||'/'||V_GRP_POL_CNT;
      ELSE
        v_result:= v_result||LPAD(V_MAX_POL_MID_NUM+1,LENGTH(V_MAX_POL_MID_NUM+1),0)||'/'||CASE WHEN v_number IS NULL THEN 0 ELSE 1 END||'/1';
      END IF;
     
    ELSIF v_flag = 'PRC_QOT_NO' THEN  
        --v_result := 'Version No. ';

      OPEN  CUR_PRC_QOT_NO;
      FETCH CUR_PRC_QOT_NO INTO v_last_number;
      CLOSE CUR_PRC_QOT_NO;

      IF NVL(v_last_number,0) = 0 THEN
        v_result := '1';
      ELSE
        v_result := TRIM(v_last_number);
      END IF;
      v_result := 'Q'||v_result||'-'||to_char(SYSDATE,'Mon')||'-'||to_char(SYSDATE,'YYYY');
    
    ELSIF v_flag = 'CFN' THEN
    
    v_file_num:='FL-'||TO_CHAR(SYSDATE,'DDMMYYYY');
    
       open check_Common_File_Number(v_file_num);
          fetch check_Common_File_Number into v_common_file_number;
            close check_Common_File_Number;
            
       IF v_common_file_number IS NULL THEN 
           v_common_file_number:=v_file_num||'-00001';
       ELSE
          v_common_file_number:=v_file_num||'-'||LPAD(v_common_file_number+1,LENGTH((v_common_file_number)),'0');
       END IF;              
     
     v_result := v_common_file_number;
    END IF;
    COMMIT;
    RETURN v_result;
  END generate_id_numbers;
--===============================================================================

PROCEDURE calculate_authorization(v_pat_auth_seq_id            IN  pat_authorization_details.pat_auth_seq_id%type,
                                  v_hosp_seq_id                IN  pat_authorization_details.hosp_seq_id%TYPE,
                                  v_allowed_amount             OUT  pat_authorization_details.Tot_Allowed_Amount%TYPE,
                                  v_result_set                 OUT SYS_REFCURSOR,
                                  v_added_by                   IN  NUMBER
                                  )
IS



CURSOR act_cur IS
SELECT SUM(NVL(pa.gross_amount,0)) as tot_gross_amount
      ,SUM(NVL(pa.discount_amount,0)) as tot_discount_amount
      ,SUM(NVL(pa.disc_gross_amount,0)) as tot_disc_gross_amount
      ,SUM(NVL(pa.patient_share_amount,0)) as tot_patient_share_amount
      ,SUM(NVL(pa.net_amount,0)) as tot_net_amount
      ,SUM(NVL(pa.allowed_amount,0)) as tot_allowed_amount
      ,SUM(NVL(pa.approved_amount,0)) as tot_approved_amount
      ,SUM(NVL(pa.out_of_pocket_amount,0)) as manual_disallow_amt

 FROM pat_activity_details pa
WHERE pa.pat_auth_seq_id=v_pat_auth_seq_id
AND pa.allow_yn='Y';

CURSOR pat_cur IS
  SELECT pad.treatment_type, pad.benifit_type, pad.denial_reason,pad.denial_code,pad.remarks,pad.completed_yn,pad.member_seq_id,
   to_date(pad.hospitalization_date,'dd/mm/rrrr') as hospitalization_date,pad.network_yn,
   CASE  WHEN pad.duration_flag = 'DAYS'  THEN CASE WHEN  pad.dur_ailment > (pad.hospitalization_date-mem.date_of_inception) THEN 'Y' ELSE 'N' END 
           WHEN pad.duration_flag = 'MONTHS' THEN CASE WHEN pad.dur_ailment> trunc(months_between(pad.hospitalization_date,mem.date_of_inception)) THEN 'Y' ELSE 'N' END
           WHEN pad.duration_flag = 'YEARS' THEN CASE WHEN pad.dur_ailment> trunc(months_between(pad.hospitalization_date,mem.date_of_inception)/12) THEN 'Y' ELSE 'N' END END AS PED,
     pad.req_amt_currency_type,pad.conversion_rate,pad.system_of_medicine_type_id as sys_med,
     NVL(PAD.MAT_COMPLCTON_YN,'N') AS MAT_COMPLCTON_YN ,
     pad.encounter_type_id,
     pad.policy_seq_id,
     pad.hosp_seq_id,
     pad.tpa_enrollment_id 
     FROM pat_authorization_details pad join
          tpa_enr_policy_member mem on (pad.member_seq_id=mem.member_seq_id)
     WHERE pad.pat_auth_seq_id=v_pat_auth_seq_id;

CURSOR enrol_type IS
select ep.enrol_type_id,ep.policy_seq_id from app.tpa_enr_policy ep join app.pat_authorization_details ad on (ep.policy_seq_id=ad.policy_seq_id)
where ad.pat_auth_seq_id=v_pat_auth_seq_id;

enrol_rec   enrol_type%rowtype;
act_rec                    act_cur%ROWTYPE;
pat_rec                    pat_cur%ROWTYPE;

CURSOR floater_cur(v_policy_group_seq_id    tpa_enr_policy_group.policy_group_seq_id%type,v_admission_date   date)
 IS 
SELECT a.policy_group_seq_id,
       SUM(A.mem_sum_insured) AS sum_insured,
       b.sum_insured as tot_sum_insured,
       b.utilised_sum_insured  FROM tpa_enr_mem_insured a
JOIN tpa_enr_balance b on (a.policy_group_seq_id=b.policy_group_seq_id)
WHERE a.policy_group_seq_id=v_policy_group_seq_id
AND a.policy_date<=v_admission_date
GROUP BY a.policy_group_seq_id,b.sum_insured,b.utilised_sum_insured;

CURSOR nonfloater_cur(v_member_seq_id    tpa_enr_policy_member.member_seq_id%type,v_admission_date   date)
 IS 
SELECT a.member_seq_id,
       SUM(A.mem_sum_insured) AS sum_insured,
       b.sum_insured as tot_sum_insured,
       b.utilised_sum_insured

FROM tpa_enr_mem_insured a
JOIN tpa_enr_balance b on (a.policy_group_seq_id=b.policy_group_seq_id)
WHERE a.member_seq_id=v_member_seq_id
AND a.policy_date<=v_admission_date
GROUP BY a.member_seq_id,b.sum_insured,b.utilised_sum_insured;
sum_rec              floater_cur%rowtype;

CURSOR mem_cur (v_member_seq_id    tpa_enr_policy_member.member_seq_id%type) IS
SELECT a.date_of_inception,a.date_of_exit,a.member_seq_id,b.policy_group_seq_id,c.policy_seq_id,c.policy_sub_general_type_id FROM tpa_enr_policy_member a
JOIN tpa_enr_policy_group b on (a.policy_group_seq_id=b.policy_group_seq_id)
JOIN tpa_enr_policy c on (b.policy_seq_id=c.policy_seq_id)
WHERE a.member_seq_id=v_member_seq_id;

CURSOR pat_act_cur IS
SELECT pad.activity_dtl_seq_id,
       pad.pat_auth_seq_id,
       pad.allowed_amount,
       pad.approved_amount
      FROM pat_activity_details pad
      where pad.pat_auth_seq_id=v_pat_auth_seq_id;
      
CURSOR check_iton is
select den.group_service_code,den.specific_service_code 
from app.dental_rule_tab den
join pat_activity_details pad on (den.cdt_code=pad.code)
join pat_authorization_details pat on (pad.pat_auth_seq_id=pat.pat_auth_seq_id)
where pat.pat_auth_seq_id=v_pat_auth_seq_id 
and (den.group_service_code='XC'  OR den.specific_service_code ='OB');      
      
CURSOR user_genral_type is
select uc.user_general_type_id 
     from tpa_user_contacts  uc
     WHERE contact_seq_id=v_added_by;
     
CURSOR Pre_approval_details IS
SELECT p.benifit_type,p.policy_seq_id 
       FROM PAT_AUTHORIZATION_DETAILS P
       WHERE P.PAT_AUTH_SEQ_ID=v_pat_auth_seq_id;
       
CURSOR op_cons_cnt IS
      SELECT COUNT(1)
                 FROM  APP.PAT_ACTIVITY_DETAILS A
                 JOIN  APP.TPA_ACTIVITY_MASTER_DETAILS B ON (A.CODE=B.ACTIVITY_CODE)
                 WHERE A.PAT_AUTH_SEQ_ID = v_pat_auth_seq_id 
                 AND B.MASTER_ACTIVITY_CODE = '9' 
                 AND NVL(A.OVERRIDE_YN,'N') = 'N';			   
 v_op_cons_cnt   number(10);       

v_act_count          number;
mem_rec              mem_cur%ROWTYPE;
v_ava_sum_insured    tpa_enr_balance.utilised_sum_insured%type;
v_remarks            varchar2(100);
v_max_act            number(10);
v_member_seq_id      number(10);
v_chronic_count      number(10);
v_final_allowed_amount  number;
v_seq_id                NUMBER(10);
v_user_type             VARCHAR2(10);
v_benefit_type          VARCHAR2(10);
v_policy_seq_id         NUMBER(30);
v_drug_cnt              NUMBER(3);

BEGIN

OPEN user_genral_type;
    FETCH user_genral_type INTO v_user_type;
       CLOSE user_genral_type; 
       
 IF v_user_type!='HOS' THEN     
 authorization_pkg.reassign_user('|'||v_pat_auth_seq_id||'|',null,null,v_added_by,null,v_seq_id);
 END IF;

    OPEN pat_cur;
    FETCH pat_cur INTO pat_rec;
    CLOSE pat_cur;


   IF pat_rec.Completed_Yn='Y' THEN
    RAISE_APPLICATION_ERROR(-20107,'You cannot perform this action through a completed Claim.');
   END IF;

    open mem_cur(pat_rec.member_seq_id);
    fetch mem_cur into mem_rec;
    close mem_cur;

    /*IF mem_rec.policy_sub_general_type_id='PFL' THEN
      OPEN floater_cur(mem_rec.policy_group_seq_id,pat_rec.hospitalization_date);
      FETCH floater_cur INTO sum_rec;
      CLOSE floater_cur;
    ELSIF  mem_rec.policy_sub_general_type_id='PNF' THEN
      OPEN nonfloater_cur(mem_rec.member_seq_id,pat_rec.hospitalization_date);
      FETCH nonfloater_cur INTO sum_rec;
      CLOSE nonfloater_cur;
    END IF; 
    v_ava_sum_insured:=(NVL(sum_rec.sum_insured,0)-NVL(sum_rec.utilised_sum_insured,0)) ;  
    */ 
    --Commented by venu v_ava_sum_insured variable we are not using ,commented on 26/02/2019

    --IF NVL(v_prod_policy_rule_seq_id,0)=0 THEN 
    OPEN enrol_type;
    FETCH enrol_type INTO enrol_rec;
    CLOSE enrol_type;
    --END IF;
     IF enrol_rec.enrol_type_id='IND' THEN
       v_prod_policy_rule_seq_id:=authorization_pkg.get_prod_pol_seq_id(enrol_rec.policy_seq_id,'IND');
     ELSE
       v_prod_policy_rule_seq_id:=authorization_pkg.get_prod_pol_seq_id(enrol_rec.policy_seq_id,'POL');
     END IF; 


   --IF pat_rec.Denial_Reason is null THEN

     update pat_activity_details ad set 
      ad.denial_code=CASE WHEN NVL(ad.override_yn,'N')='Y' AND NVL(ad.approve_yn,'Y')='N' THEN ad.denial_code ELSE null END,  
                          
      ad.remarks=CASE WHEN NVL(ad.override_yn,'N')='Y' AND NVL(ad.approve_yn,'Y')='N'THEN ad.remarks ELSE null END,
      ad.denial_desc= CASE WHEN NVL(ad.override_yn,'N')='Y' AND  NVL(ad.approve_yn,'Y')='N' THEN ad.denial_desc ELSE NULL END,
      ad.patient_share_amount=null,
      ad.allowed_amount=null,
      ad.approved_amount=null,
      ad.rule_limit=null,
      ad.benifit_copay=NULL,
      ad.benifit_deductible=NULL,
	    ad.copay_amount=NULL,
      ad.approvd_quantity = ad.quantity,   -- case when nvl(ad.phy_yn,'N')='Y' then ad.quantity else ad.approvd_quantity end,
	  ad.denial_by_rule_cond_id_dtls = NULL,
      ad.denial_by_rule_proc_dtls = NULL,
      ad.denial_by_resons = NULL,
	  ad.deduct_amount=null,
	  ad.provider_copay=null,
	  ad.Prov_Copay_flag=null,
      ad.Prov_Copay_Perc=null,
      ad.copay_deduct_flag=null
      ,ad.optc_payable = NULL
      where ad.pat_auth_seq_id=v_pat_auth_seq_id;/* and nvl(ad.override_yn,'N')='N' and nvl(ad.service_type,'ACD')='ACD'*/

      update diagnosys_details dd 
      set dd.denial_reason=null,
          dd.remarks=null,
		  dd.rule_limit=null,
		  dd.copay=null,
		  dd.deduct=null,
		  dd.copay_persent = NULL,
		  dd.rule_copay=null,
		  dd.copay_limit=null
       where dd.pat_auth_seq_id=v_pat_auth_seq_id;

      update pat_authorization_details pad
      set pad.benefit_limit=null,
          pad.benefit_copay=null,
          pad.tot_allowed_amount=null,
          pad.tot_approved_amount=null,
		  pad.sys_med_yn = null,
          pad.sys_med_limit=null,
          pad.area_cover_yn = NULL,
          pad.area_cov_rule_reg_id = NULL,
          pad.area_rule_limit = NULL,
          pad.out_area_cover_yn = NULL,
          pad.out_area_cov_rule_reg_id = NULL,
          pad.in_out_area_covr_yn = NULL,
          pad.in_out_amnt_perc = NULL,
		  pad.MATERNITY_YN = null,
          pad.deductable = null
          where pad.pat_auth_seq_id = v_pat_auth_seq_id;


    IF pat_rec.Denial_Reason is not null THEN
      UPDATE pat_activity_details pad
               SET pad.denial_desc  = pat_rec.Denial_Reason,
                   pad.denial_code  = pat_rec.denial_code,
                   pad.tpa_denial_code = pat_rec.denial_code,
                   pad.tpa_denial_desc = pat_rec.Denial_Reason,
                   pad.remarks      = pat_rec.remarks,
                   pad.updated_by   = v_added_by,
                   pad.updated_date = SYSDATE,
                   pad.denial_by_rule_proc_dtls = TRIM(BOTH ';' FROM (pad.denial_by_rule_proc_dtls||';'||CHR(10)||'authorization_pkg.calculate_authorization'))
             WHERE pad.pat_auth_seq_id = v_pat_auth_seq_id;
    end if;
    commit; 
    
  /*select count(1) into v_chronic_count 
      from  app.pat_authorization_details d
    join app.diagnosys_details dd on (d.pat_auth_seq_id=dd.pat_auth_seq_id and d.benifit_type='OPTS')
    join app.tpa_day_care_icd c on (c.icd_code=dd.diagnosys_code and dd.primary_ailment_yn='Y')
     where d.pat_auth_seq_id=v_pat_auth_seq_id;*/
     --chronic count, we are not using Commented by venu ,commented on 26/02/2019

    --pat_xml_load_pkg.update_activity_gross(v_pat_auth_seq_id,'PAT',v_added_by);
 
    
    --pat_xml_load_pkg.check_ddc_rule(v_pat_auth_seq_id,'PAT',v_added_by);
    pat_xml_load_pkg.check_room_icu_code(v_pat_auth_seq_id,'PAT',v_added_by);
    pat_xml_load_pkg.check_lmrp_rules(v_pat_auth_seq_id,'PAT',v_added_by);-- comented as per Dr.yasmin/ Enabled on 19th Aug 2017
    pat_xml_load_pkg.check_ncci_hosp_phy_rules(v_pat_auth_seq_id,v_hosp_seq_id,'PAT',v_added_by);
    --pat_xml_load_pkg.check_mue_rules(v_pat_auth_seq_id,'PAT',v_added_by);
    pat_xml_load_pkg.execute_diag_rule(v_pat_auth_seq_id,'PAT' ,v_prod_policy_rule_seq_id  ,v_added_by); 
    pat_xml_load_pkg.execute_sec_icd_mat_rule(v_pat_auth_seq_id,'PAT' ,v_prod_policy_rule_seq_id  ,v_added_by); --- ( gender validation for Maternity secondary ICD)CR062CR0179
    IF pat_rec.MAT_COMPLCTON_YN = 'Y' THEN
    pat_xml_load_pkg.exec_mat_comp_rule(v_pat_auth_seq_id,'PAT' ,v_prod_policy_rule_seq_id  ,v_added_by); 
    END IF;    
--    if v_chronic_count=0 then
    pat_xml_load_pkg.execute_activity_rule(v_pat_auth_seq_id,'PAT',v_prod_policy_rule_seq_id  ,v_added_by  );        
    pat_xml_load_pkg.check_duplicate_activity(v_pat_auth_seq_id,'PAT',v_added_by);
    --end if;
    pat_xml_load_pkg.check_add_on_rules(v_pat_auth_seq_id,'PAT',v_added_by);
    if nvl(pat_rec.network_yn,'N')='Y' then
    pat_xml_load_pkg.check_tariff_rule (v_pat_auth_seq_id,'PAT',v_added_by);
    end if;
    
    
	
    IF pat_rec.ped='Y' and pat_rec.benifit_type in ('OPTS','IPT') THEN
    pat_xml_load_pkg.execute_ped_rule(v_pat_auth_seq_id ,'PAT' ,v_prod_policy_rule_seq_id ,v_added_by );
    END IF;
    
	
	 IF pat_rec.sys_med !='SAL' THEN
	  pat_xml_load_pkg.execute_sys_medicine(v_pat_auth_seq_id ,'PAT' ,v_prod_policy_rule_seq_id ,v_added_by);
	 END IF; 
    
    pat_xml_load_pkg.check_physiotherapy_pd(v_pat_auth_seq_id,'PAT',v_added_by);
    
    select count(1) into v_drug_cnt
     from pat_activity_details d 
     where d.Pat_Auth_Seq_Id=v_pat_auth_seq_id and d.activity_type=5;
    
     -----++++++Clinical Rules ++++++++++++++++++++++++++++++
    IF pat_rec.encounter_type_id not in (3,4) AND v_drug_cnt>0 THEN
    hosp_pbm_pkg.check_mdcl_necessity_rules_1(v_pat_auth_seq_id,'PAT',v_added_by);	
    hosp_pbm_pkg.check_therapeutic_rule_2(v_pat_auth_seq_id,'PAT',v_added_by);
    hosp_pbm_pkg.check_ci_icd_ddc_rules_3(v_pat_auth_seq_id,'PAT',v_added_by);
    hosp_pbm_pkg.check_ci_ddc_ddc_generic(v_pat_auth_seq_id,'PAT',v_added_by);
    hosp_pbm_pkg.check_age_band_rule_4(v_pat_auth_seq_id,'PAT',v_added_by);
    hosp_pbm_pkg.check_gender_rule_5(v_pat_auth_seq_id,'PAT',v_added_by);
    hosp_pbm_pkg.priliminary_check_rule_6(v_pat_auth_seq_id,'PAT',v_added_by);
    hosp_pbm_pkg.check_refill_to_soon_7(v_pat_auth_seq_id,'PAT' ,pat_rec.member_seq_id,v_added_by);
    hosp_pbm_pkg.check_mat_icd_ddc_rule_8(v_pat_auth_seq_id,'PAT',v_added_by);
    END IF;
    ----++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    
-----------------
    /*IF pat_rec.benifit_type = 'DNTL' THEN
      pat_xml_load_pkg.ortho_score_prc(v_pat_auth_seq_id, 'PAT');
    END IF;*/
   /*ELSE

            UPDATE pat_activity_details pad
               SET pad.denial_desc  = pat_rec.Denial_Reason,
                   pad.denial_code  = pat_rec.denial_code,
                   pad.remarks      = pat_rec.remarks,
                   pad.updated_by   = v_added_by,
                   pad.updated_date = SYSDATE
             WHERE pad.pat_auth_seq_id = v_pat_auth_seq_id;
   END IF;*/
    IF pat_rec.benifit_type = 'DNTL'  THEN
      FOR IOTN IN check_iton LOOP
        check_ortho_cond(v_pat_auth_seq_id, 'PAT');
      END LOOP;
  --+++++++++++++++++
      /*select count(1) into v_act_count
      from pat_activity_details p
      join dental_rule_tab d on d.cdt_code = p.code
      where p.pat_auth_seq_id = v_pat_auth_seq_id;*/
  
      IF nvl(v_act_count, 0) = 0 THEN
         check_overal_limit(v_pat_auth_seq_id, 'PAT', v_prod_policy_rule_seq_id);
      END IF;
    END IF;
  --+++++++++++++++++
   ----- FREE FOLLOW UP PERIOD FOR ACTIVITY WISE AND CONSULATION 
    IF  UPPER(pat_rec.benifit_type) in ('OMTI','OPTS') THEN 
        OPEN op_cons_cnt;
          FETCH op_cons_cnt INTO v_op_cons_cnt;
          CLOSE op_cons_cnt;
        IF v_op_cons_cnt > 0 THEN 
         pat_xml_load_pkg.cons_followup_period (v_pat_auth_seq_id,'PAT',v_prod_policy_rule_seq_id,pat_rec.policy_seq_id,pat_rec.member_seq_id,pat_rec.hosp_seq_id,pat_rec.benifit_type,pat_rec.tpa_enrollment_id,pat_rec.hospitalization_date,v_added_by);
        END IF;
      pat_xml_load_pkg.act_followup_period(v_pat_auth_seq_id,'PAT',pat_rec.policy_seq_id,pat_rec.member_seq_id,pat_rec.hosp_seq_id,pat_rec.tpa_enrollment_id,pat_rec.hospitalization_date,v_added_by);
    END IF;
    --------------------------
    pat_xml_load_pkg.admin_activity_rule('PAT',v_pat_auth_seq_id);
    pat_xml_load_pkg.calculate_allowed_amount( v_pat_auth_seq_id,'PAT');

    OPEN act_cur;
    FETCH act_cur INTO act_rec;
    CLOSE act_cur;

    UPDATE pat_authorization_details A
    SET a.tot_gross_amount           = act_rec.tot_gross_amount,
        a.tot_discount_amount        = act_rec.tot_discount_amount,
        a.tot_disc_gross_amount      = act_rec.tot_disc_gross_amount,
        a.tot_patient_share_amount   = act_rec.tot_patient_share_amount,
        a.tot_net_amount             = act_rec.tot_net_amount,
        a.tot_allowed_amount         = act_rec.tot_allowed_amount,
        a.tot_approved_amount        = act_rec.tot_approved_amount,
        a.remarks                    = v_remarks
   WHERE a.pat_auth_seq_id           = v_pat_auth_seq_id
   RETURNING a.tot_approved_amount INTO v_allowed_amount;

  check_pat_approved(v_pat_auth_seq_id,v_added_by);
  
  --for dental IOTN Score validation
  pat_xml_load_pkg.check_policy_date_valid(v_pat_auth_seq_id ,'PAT' ,v_added_by);
  check_activity_limits(v_pat_auth_seq_id,'PAT',v_allowed_amount,v_added_by,v_remarks,v_final_allowed_amount);
  -- Area Of Coverage Rule
  pat_xml_load_pkg.exec_area_cov_rule(v_pat_auth_seq_id,'PAT',v_Prod_Policy_Rule_Seq_Id,v_added_by);
  
  pat_xml_load_pkg.execute_global_amnt_rules('P',v_pat_auth_seq_id,pat_rec.member_seq_id,v_Prod_Policy_Rule_Seq_Id);
  
 IF pat_rec.network_yn='Y' THEN
   
   OPEN Pre_approval_details;
     FETCH Pre_approval_details INTO v_benefit_type,v_policy_seq_id;
        CLOSE Pre_approval_details;
        
   Provider_Benifit_eligibility(v_pat_auth_seq_id,'PAT',v_benefit_type,v_hosp_seq_id,v_policy_seq_id);
 END IF;
  OPEN act_cur;
  FETCH act_cur INTO act_rec;
  CLOSE act_cur;
  
  UPDATE pat_authorization_details A
    SET a.tot_gross_amount           = act_rec.tot_gross_amount,
        a.tot_discount_amount        = act_rec.tot_discount_amount,
        a.tot_disc_gross_amount      = act_rec.tot_disc_gross_amount,
        a.tot_patient_share_amount   = act_rec.tot_patient_share_amount,
        a.tot_net_amount             = act_rec.tot_net_amount,
        a.tot_allowed_amount         = act_rec.tot_allowed_amount,
        a.tot_approved_amount        = act_rec.tot_approved_amount,
        a.remarks                    = v_remarks,
        a.dis_allowed_amount         = nvl(act_rec.tot_net_amount,0)-nvl(act_rec.tot_approved_amount,0),
        a.converted_final_approved_amt = CASE WHEN to_number(pat_rec.conversion_rate) <>0 
                                                THEN act_rec.tot_allowed_amount / to_number(pat_rec.conversion_rate)
                                             ELSE act_rec.tot_allowed_amount END,
        a.cal_act_yn                   = 'Y',
        a.manual_disallow_amt          =act_rec.manual_disallow_amt
   WHERE a.pat_auth_seq_id           = v_pat_auth_seq_id ;
    
  UPDATE pat_activity_details pad
               SET pad.denial_desc  = replace(pad.denial_desc,';;',';')
                   WHERE pad.pat_auth_seq_id = v_pat_auth_seq_id;

 commit;

  OPEN v_result_set FOR 
  SELECT SUM(NVL(pa.gross_amount,0)) as tot_gross_amount
      ,SUM(NVL(pa.discount_amount,0)) as tot_discount_amount
      ,SUM(NVL(pa.disc_gross_amount,0)) as tot_disc_gross_amount
      ,SUM(NVL(pa.patient_share_amount,0)) as tot_patient_share_amount
      ,(SUM(NVL(pa.disc_gross_amount,0))-SUM(NVL(pa.patient_share_amount,0))) as tot_net_amount
      ,SUM(NVL(pa.allowed_amount,0)) as tot_allowed_amount
      ,SUM(NVL(pa.Approved_Amount,0)) as tot_approved_amount

 FROM pat_activity_details pa
WHERE pa.pat_auth_seq_id=v_pat_auth_seq_id
AND pa.allow_yn='Y';
  

END calculate_authorization;                                   
--====================================================================================
PROCEDURE save_authorization(v_pat_auth_seq_id                 IN pat_authorization_details.Pat_Auth_Seq_Id%TYPE,
                             v_member_seq_id                   IN pat_authorization_details.member_seq_id%TYPE,
                             v_auth_number                     IN OUT pat_authorization_details.Auth_Number%TYPE,
                             v_admission_date                  IN pat_authorization_details.hospitalization_date%type,
                             v_allowed_amount                  IN pat_authorization_details.Tot_Allowed_Amount%TYPE,
                             v_source_type_id                  IN pat_authorization_details.source_type_id%TYPE,
                             v_pat_status_type_id              IN OUT pat_authorization_details.Pat_Status_Type_Id%TYPE,
                             v_medical_opinion_remarks         IN pat_authorization_details.medical_opinion_remarks%type,
                             v_added_by                        IN NUMBER,
                             p_denial_code                     IN Tpa_Denial_Codes.Denial_Code%TYPE,
                             v_over_remarks                    IN pat_authorization_details.override_remarks%TYPE,
                             v_internal_remarks                IN VARCHAR2,
                             v_rows_processed                  OUT NUMBER)
IS

 CURSOR pat_denial_cur IS
      SELECT p.denial_code
      FROM Pat_Activity_Details p
      WHERE p.pat_auth_seq_id = v_pat_auth_seq_id;

   v_pat_denial_cur pat_denial_cur%ROWTYPE;

CURSOR denial_cur IS
    SELECT d.denial_code, d.denial_description
    FROM Tpa_Denial_Codes d
  WHERE d.denial_code = p_denial_code;
  
  v_denial_cur denial_cur%ROWTYPE;
  
  

CURSOR mem_cur IS
SELECT a.date_of_inception,a.date_of_exit,a.member_seq_id,b.policy_group_seq_id,c.policy_seq_id,c.policy_sub_general_type_id,e.short_name,f.state_type_id 
FROM tpa_enr_policy_member a
JOIN tpa_enr_policy_group b on (a.policy_group_seq_id=b.policy_group_seq_id)
JOIN tpa_enr_policy c on (b.policy_seq_id=c.policy_seq_id)
LEFT OUTER JOIN TPA_ENR_MEM_ADDRESS D on(B.enr_address_seq_id=D.enr_address_seq_id)
LEFT OUTER JOIN TPA_COUNTRY_CODE e on (e.country_id=d.country_id)
left outer join tpa_state_code f on (f.state_type_id=d.state_type_id)
WHERE a.member_seq_id=v_member_seq_id;

mem_rec             mem_cur%ROWTYPE;

CURSOR pat_cur IS
SELECT * FROM pat_authorization_details pad
WHERE pad.pat_auth_seq_id=v_pat_auth_seq_id;

pat_rec  pat_cur%rowtype;
CURSOR floater_cur(v_policy_group_seq_id    tpa_enr_policy_group.policy_group_seq_id%type)
 IS 
SELECT a.policy_group_seq_id,
       SUM(A.mem_sum_insured) AS sum_insured,
       b.sum_insured as tot_sum_insured,
       b.utilised_sum_insured  FROM tpa_enr_mem_insured a
JOIN tpa_enr_balance b on (a.policy_group_seq_id=b.policy_group_seq_id)
WHERE a.policy_group_seq_id=v_policy_group_seq_id
--AND a.policy_date<=v_admission_date
GROUP BY a.policy_group_seq_id,b.sum_insured,b.utilised_sum_insured;

CURSOR nonfloater_cur(v_member_seq_id    tpa_enr_policy_member.member_seq_id%type)
 IS 
SELECT a.member_seq_id,
       SUM(A.mem_sum_insured) AS sum_insured,
       b.sum_insured as tot_sum_insured,
       b.utilised_sum_insured

FROM tpa_enr_mem_insured a
JOIN tpa_enr_balance b on (a.member_seq_id=b.member_seq_id)
WHERE a.member_seq_id=v_member_seq_id
--AND a.policy_date<=v_admission_date
GROUP BY a.member_seq_id,b.sum_insured,b.utilised_sum_insured;

CURSOR shortfall_count IS 
SELECT COUNT(1)  FROM APP.shortfall_details s where 
 s.srtfll_status_general_type_id = 'OPN' and s.pat_gen_detail_seq_id=v_pat_auth_seq_id ;

CURSOR icd_cur IS
Select count(1)
From diagnosys_details d
Where d.pat_auth_seq_id = v_pat_auth_seq_id
And d.primary_ailment_yn = 'Y';

CURSOR icd_benefit_cur(v_diagnosys_code VARCHAR2) IS
  Select ic.benefit_type
  From tpa_icd10_master_details ic
  Where ic.icd_code = upper(v_diagnosys_code);

CURSOR pat_icd_cur IS
Select d.diagnosys_code, p.benifit_type
From diagnosys_details d
Join pat_authorization_details p on (p.pat_auth_seq_id = d.pat_auth_seq_id)
Where d.pat_auth_seq_id = v_pat_auth_seq_id
And d.primary_ailment_yn = 'Y';

pat_icd_rec          pat_icd_cur%ROWTYPE;
v_icd_benefit        icd_benefit_cur%ROWTYPE;
v_icd_count          NUMBER;

sum_rec              floater_cur%rowtype;
v_ava_sum_insured    tpa_enr_balance.utilised_sum_insured%type;
v_app_amount         pat_authorization_details.final_app_amount%type;
v_reason             pat_authorization_details.remarks%type;
v_denial_reason      pat_authorization_details.denial_reason%type;
v_count              number(10);
v_dest_msg_seq_id    VARCHAR2(250);
v_out_preauth xmltype;
v_seq_id                     NUMBER(10);
v_comp_yn            VARCHAR2(2);
v_utilised_amt       NUMBER(30,2);
V_MODIFIED_DATE      NUMBER;
----- ADDED IN CFD CR 
CURSOR inv_status IS SELECT * FROM (SELECT inv_status FROM app.tpa_fraud_inv_details WHERE pat_auth_seq_id = v_pat_auth_seq_id  ORDER BY inv_seq_id DESC) WHERE ROWNUM=1;
v_inv_status app.tpa_fraud_inv_details.inv_status%TYPE;
CURSOR old_apr_amt IS
SELECT SUBSTR(b.status_log,INSTR(b.status_log,'To')+3) old_apr_amt FROM
   (SELECT SUBSTR(a.status_log,1,INSTR(a.status_log,chr(10))-1) status_log,RANK() OVER(ORDER BY log_seq_id DESC)  r
      FROM tpa_pat_clm_logs a WHERE a.pat_seq_id= v_pat_auth_seq_id AND a.log_type_id='AAC'
   )b WHERE b.r=1;
v_logs        VARCHAR2(100):=NULL;
v_old_apr_amt VARCHAR2(100):=NULL;
---- stop preauth & claim Cr
CURSOR stop_preauth_cur (v_policy_seq_id tpa_enr_policy.policy_seq_id%TYPE) IS 
                                                 SELECT stop_preauth_yn,stop_preauth_date 
                                                 FROM app.tpa_ins_prod_policy tip 
                                                 JOIN app.tpa_enr_policy tep ON (tip.policy_seq_id = tep.policy_seq_id)
                                                 WHERE tep.policy_seq_id = v_policy_seq_id;

CURSOR stop_prov_pre_cur (v_hosp_seq_id pat_authorization_details.hosp_seq_id%TYPE) IS
                                                 SELECT stop_preauth_yn,stop_preauth_date 
                                                 FROM app.tpa_hosp_info
                                                 WHERE hosp_seq_id = v_hosp_seq_id;
                                                 
CURSOR mem_stop_cur (v_mem_seq_id tpa_enr_policy_member.member_seq_id%TYPE) IS
                                                 SELECT stop_pat_clm_process_yn ,recieved_after 
                                                 FROM app.tpa_enr_policy_member tepm
                                                 WHERE tepm.member_seq_id = v_mem_seq_id;

CURSOR stop_grp_pre_cur (v_pol_grp_id tpa_enr_policy.policy_seq_id%TYPE) IS 
                                                 SELECT stop_pat_clm_process_yn,recieved_after 
                                                 FROM  app.tpa_enr_policy_group tepg
                                                 WHERE tepg.policy_group_seq_id = v_pol_grp_id;

v_stop_pre_yn varchar2(1);
v_stop_pre_date date;
BEGIN

  authorization_pkg.reassign_user('|'||v_pat_auth_seq_id||'|',null,null,v_added_by,'SAV',v_seq_id);

  UPDATE ASSIGN_USERS A
  SET A.PAT_STATUS_GENERAL_TYPE_ID = v_pat_status_type_id
  WHERE A.ASSIGN_USERS_SEQ_ID = v_seq_id;

  OPEN mem_cur;
  FETCH mem_cur INTO mem_rec;
  CLOSE mem_cur;

  OPEN pat_cur;
  FETCH pat_cur INTO pat_rec;
  CLOSE pat_cur;

  IF pat_rec.Completed_Yn='Y' THEN
    RAISE_APPLICATION_ERROR(-20107,'You cannot perform this action through a completed Claim.');
  END IF;

  open shortfall_count;
  fetch shortfall_count into v_count;
  close shortfall_count;

  IF v_count>0 and v_pat_status_type_id ='APR'then 
    RAISE_APPLICATION_ERROR(-20387,'Please close the opened shortfall before complete the Pre_auth/Claim.');
  END IF;
  
  IF v_count=0 and v_pat_status_type_id='REQ' THEN 
    RAISE_APPLICATION_ERROR(-20957,'You can not change the status to required information without Raising Shortfall.');
  END IF;
  
  IF v_count>0 and v_pat_status_type_id='INP' THEN 
    RAISE_APPLICATION_ERROR(-20958,'You can not change the status to inprogress without closing Shortfall.');
  END IF;
  
  IF NVL(pat_rec.cal_act_yn,'Y') = 'N' THEN
    RAISE_APPLICATION_ERROR(-20288,'Modification happened, re-calculate activity once again.');
  END IF;
  
   --- ICD Check
    IF v_pat_status_type_id='APR' THEN
      OPEN icd_cur;
      FETCH icd_cur INTO v_icd_count;
      CLOSE icd_cur;
      
      IF v_icd_count = 0 THEN
        RAISE_APPLICATION_ERROR(-20923,'Primary ICD required to complete the preauth/ claim.');
      END IF;
    
      OPEN pat_icd_cur;
      FETCH pat_icd_cur INTO pat_icd_rec;
      CLOSE pat_icd_cur;
      
      OPEN icd_benefit_cur(pat_icd_rec.diagnosys_code);
      FETCH icd_benefit_cur INTO v_icd_benefit;
      CLOSE icd_benefit_cur;
      
      IF v_icd_benefit.benefit_type = 'DNTL' OR pat_icd_rec.benifit_type = 'DNTL' THEN
        IF pat_icd_rec.benifit_type != nvl(v_icd_benefit.benefit_type, 'NA') THEN
          RAISE_APPLICATION_ERROR(-20323,'Ailment does not belogs to the selected benefit type, please select appropriate benefit type!');
        END IF;
      END IF;
    END IF;
    -- End ICD
    
      ------ stop cashless validation 
     OPEN stop_preauth_cur(mem_rec.policy_seq_id);
     FETCH stop_preauth_cur INTO v_stop_pre_yn,v_stop_pre_date;
     CLOSE stop_preauth_cur;
  
     IF v_stop_pre_yn = 'Y' AND trunc(pat_rec.hospitalization_date) >= trunc(v_stop_pre_date)  AND v_pat_status_type_id ='APR' THEN
        RAISE_APPLICATION_ERROR(-20414,'Member is not covered as the contract between Corporate & Al Koot is on hold');
     END IF;
     
     OPEN stop_grp_pre_cur(mem_rec.policy_group_seq_id);
     FETCH stop_grp_pre_cur INTO v_stop_pre_yn,v_stop_pre_date;
     CLOSE stop_grp_pre_cur;
   
      IF v_stop_pre_yn = 'Y' AND trunc(pat_rec.hospitalization_date) >= trunc(v_stop_pre_date)  AND v_pat_status_type_id ='APR' THEN
        RAISE_APPLICATION_ERROR(-20417,'Member is not eligible for treatment as the contract between member & Al Koot is on hold');
     END IF;
     
     OPEN mem_stop_cur(mem_rec.member_seq_id);
     FETCH mem_stop_cur INTO v_stop_pre_yn,v_stop_pre_date;
     CLOSE mem_stop_cur;
         
     IF v_stop_pre_yn = 'Y' AND trunc(pat_rec.hospitalization_date) >= trunc(v_stop_pre_date)  AND v_pat_status_type_id ='APR' THEN
        RAISE_APPLICATION_ERROR(-20417,'Member is not eligible for treatment as the contract between member & Al Koot is on hold');
     END IF;
     
     OPEN stop_prov_pre_cur(pat_rec.hosp_seq_id);
     FETCH stop_prov_pre_cur INTO v_stop_pre_yn,v_stop_pre_date;
     CLOSE stop_prov_pre_cur;
    
   IF v_stop_pre_yn = 'Y' AND trunc(pat_rec.hospitalization_date) >= trunc(v_stop_pre_date)  AND v_pat_status_type_id ='APR' THEN
      RAISE_APPLICATION_ERROR(-20415,'Member is not covered as the contract between Facility & Al Koot is on hold');
   END IF;        
         ----- ADDED IN CFD (COUNT FRAUD CR)
  OPEN inv_status;                     
  FETCH inv_status INTO v_inv_status;
  CLOSE inv_status;
  
  IF (pat_rec.status_code_id = 'SUSP' AND pat_rec.risk_level = 'HR') AND (v_inv_status IS NULL  OR v_inv_status = 'II') AND (v_pat_status_type_id = 'APR') THEN
      RAISE_APPLICATION_ERROR (-20412, 'Claims/Pre-approval is tagged with Suspicion and High Risk, Need CFD Clearance to Proceed further');
  END IF;
  
  IF v_pat_status_type_id NOT IN ('INP','REJ') AND pat_rec.override_by IS NULL AND (pat_rec.status_code_id  = 'SUSP' AND pat_rec.risk_level = 'HR' AND v_inv_status = 'FD')  THEN
      RAISE_APPLICATION_ERROR (-20413, 'Claims/Pre-approval cannot be Approved as Fraudulence detected after Investigation');
  END IF;
    ----- end cfd (counter fraud cr)
  
   IF mem_rec.policy_sub_general_type_id='PFL' THEN
    OPEN floater_cur(mem_rec.policy_group_seq_id);
    FETCH floater_cur INTO sum_rec;
    CLOSE floater_cur;
   ELSIF  mem_rec.policy_sub_general_type_id='PNF' THEN
    OPEN nonfloater_cur(mem_rec.member_seq_id);
    FETCH nonfloater_cur INTO sum_rec;
    CLOSE nonfloater_cur;
  END IF; 

  v_ava_sum_insured:=(NVL(sum_rec.sum_insured,0)-NVL(sum_rec.utilised_sum_insured,0)) ;  
  	--Check PreAuth User Aproval Limit to Approve
    
    IF v_pat_status_type_id ='APR' AND v_added_by != 1 THEN
      check_approval_limit(v_added_by, v_allowed_amount,'PAT');
    END IF;
    IF v_pat_status_type_id='APR' THEN
      IF v_allowed_amount<=v_ava_sum_insured THEN
         v_app_amount:=v_allowed_amount; 
      ELSE 
         RAISE_APPLICATION_ERROR(-20737,'Sufficient Balance doesnot exist');
      END IF;   
    ELSIF v_pat_status_type_id IN ('REJ','REQ') THEN
    
 -- Newly added by L pradhan  
 -- adding denial code while selecting rejected status for the pre auth.
 
    OPEN pat_denial_cur;
       FETCH pat_denial_cur INTO v_pat_denial_cur;
       CLOSE pat_denial_cur;

       OPEN  denial_cur;
       FETCH denial_cur INTO v_denial_cur;
       CLOSE denial_cur;


          UPDATE Pat_Activity_Details pa
          SET pa.allowed_amount = 0,
              pa.approved_amount = 0,
              pa.disallowed_amount= pat_rec.tot_allowed_amount,
              pa.denial_code = CASE WHEN pa.denial_code IS NOT NULL THEN pa.denial_code||';'||v_denial_cur.denial_code ELSE v_denial_cur.denial_code END,
              pa.denial_desc = CASE WHEN pa.denial_desc IS NOT NULL THEN pa.denial_desc||';'||v_denial_cur.denial_description ELSE v_denial_cur.denial_description END,
              pa.tpa_denial_code = CASE WHEN pa.tpa_denial_code IS NOT NULL THEN pa.tpa_denial_code||';'||v_denial_cur.denial_code ELSE v_denial_cur.denial_code END,
              pa.tpa_denial_desc = CASE WHEN pa.tpa_denial_desc IS NOT NULL THEN pa.tpa_denial_desc||';'||v_denial_cur.denial_description ELSE v_denial_cur.denial_description END
             WHERE pa.pat_auth_seq_id = v_pat_auth_seq_id;



          UPDATE app.pat_authorization_details pad
          SET pad.tot_approved_amount = 0,
              pad.final_app_amount = 0,
              pad.tot_allowed_amount=0,
			  pad.Converted_Final_Approved_Amt=0,
        pad.denial_code=p_denial_code
          WHERE pad.pat_auth_seq_id  = v_pat_auth_seq_id;
          
          v_app_amount:=0;
    
     ELSIF v_pat_status_type_id in ('PCN','PCO') THEN
     
  
          UPDATE Pat_Activity_Details pa
          SET pa.allowed_amount = 0,
              pa.approved_amount = 0
          WHERE pa.pat_auth_seq_id = v_pat_auth_seq_id;
      
       UPDATE app.pat_authorization_details pad
          SET pad.tot_approved_amount = 0,
              pad.tot_allowed_amount = 0,
              pad.final_app_amount = 0,
              pad.Converted_Final_Approved_Amt=0
          WHERE pad.pat_auth_seq_id  = v_pat_auth_seq_id;

        v_app_amount:=0;
    END IF; 


  IF v_auth_number IS NULL AND v_pat_status_type_id IN ('APR','REJ','PCN','PCO') THEN
    v_auth_number:=generate_id_numbers('AT',mem_rec.short_name,mem_rec.state_type_id,pat_rec.pre_auth_number);
  END IF;

v_comp_yn := CASE WHEN v_pat_status_type_id IN ('APR','REJ','PCN','PCO') THEN 'Y'
                  WHEN v_pat_status_type_id IN ('INP','REQ') THEN 'N'
             END;       

   UPDATE pat_authorization_details a
     SET A.final_app_amount   = v_app_amount,
         a.pat_status_type_id = v_pat_status_type_id ,
         a.medical_opinion_remarks            = NVL(v_medical_opinion_remarks,v_reason),
         a.denial_reason      = v_denial_reason,
         A.auth_number        = v_auth_number,
         A.completed_yn       = v_comp_yn, --case when v_pat_status_type_id IN ('REJ','CAN','APR') THEN 'Y' ELSE 'N' END,
         a.completed_date     = case when v_pat_status_type_id IN ('APR','REJ','PCN','PCO') THEN sysdate end,
         a.updated_by         = v_added_by,
         a.updated_date       = SYSDATE,
         a.authorized_by      = v_added_by,
         a.tot_approved_amount    = CASE WHEN v_pat_status_type_id IN ('REQ') THEN 0 ELSE tot_approved_amount END,
         a.tot_allowed_amount     = CASE WHEN v_pat_status_type_id IN ('REQ') THEN 0 ELSE tot_allowed_amount END,
         a.override_remarks       = v_over_remarks,
         a.internal_remarks       = v_internal_remarks,
         a.processed_by           = case when v_pat_status_type_id IN ('APR','REJ','PCN','PCO') THEN v_added_by else null end
     WHERE A.pat_auth_seq_id  = v_pat_auth_seq_id;

 IF v_pat_status_type_id='APR' then


 v_out_preauth:= pat_xml_load_pkg.upload_priorAuth_xml(v_pat_auth_seq_id);

 update app.pat_upload_dhpo_dtls d 
 set d.upload_file = v_out_preauth,
     d.added_by    = v_added_by,
     d.added_date  = sysdate ,
     d.up_load_status='N'
  where d.pat_seq_id = v_pat_auth_seq_id;

 IF mem_rec.policy_sub_general_type_id='PFL' THEN    
   UPDATE tpa_enr_balance b
   SET b.utilised_sum_insured = nvl(b.utilised_sum_insured,0) + v_app_amount,
       b.updated_by           = v_added_by,
       b.updated_date         = SYSDATE
   WHERE b.policy_group_seq_id = mem_rec.policy_group_seq_id;
 ELSIF mem_rec.policy_sub_general_type_id='PNF' THEN  
  UPDATE tpa_enr_balance b
   SET b.utilised_sum_insured = nvl(b.utilised_sum_insured,0) + v_app_amount,
       b.updated_by           = v_added_by,
       b.updated_date         = SYSDATE
   WHERE b.member_seq_id      = mem_rec.member_seq_id return b.utilised_sum_insured into v_utilised_amt; 
 END IF;
 
 ----Tracking Sum insured Details
  
  INSERT INTO APP.sum_ins_track (CLAIM_PRE_NUMBER, MEMBER_SEQ_ID,UTILISED_SUM_INS,APPR_AMOUNT,ADDED_DATE,MODULE_FLAG,CLAIM_STATUS,UPDATED_SI)
  VALUES (v_auth_number , v_member_seq_id, sum_rec.utilised_sum_insured,v_allowed_amount,SYSDATE,'PREAUTH',v_pat_status_type_id,v_utilised_amt);
  
 END IF;

 v_rows_processed:=SQL%ROWCOUNT;
 MODIFICATION_TRACKER_PKG.MODIFICATION_HIST_PRC(NULL, v_pat_auth_seq_id, 'PAT', v_pat_status_type_id, v_added_by);
 
 IF v_rows_processed > 0 THEN
   SELECT NVL(COUNT(FIRST_MODIFIED_DATE), 0) INTO V_MODIFIED_DATE
   FROM PAT_AUTHORIZATION_DETAILS P
   WHERE P.PAT_AUTH_SEQ_ID = v_pat_auth_seq_id;
   
   IF V_MODIFIED_DATE = 0 THEN
     UPDATE PAT_AUTHORIZATION_DETAILS P
     SET P.FIRST_MODIFIED_DATE = SYSDATE
     WHERE P.PAT_AUTH_SEQ_ID = v_pat_auth_seq_id;
   END IF;
 END IF;
        ------ CR-0393IssueAndRe-issueOfClaims  --------------
 IF v_pat_status_type_id IN ('APR','REJ','PCN','PCO') THEN
   OPEN old_apr_amt;
   FETCH old_apr_amt INTO v_old_apr_amt;
   CLOSE old_apr_amt;
   


   v_logs := 'Approval Amount Change : '|| nvl(v_old_apr_amt,'NA') ||' To '||v_app_amount;
   save_pat_clm_logs('P',v_pat_auth_seq_id,'AAC',v_logs,v_added_by,'Y');
   
   v_logs := 'Status Change : ' ||CASE pat_rec.pat_status_type_id WHEN 'INP' THEN 'In-Progress'
                                                                  WHEN 'REQ' THEN 'Required Information'
                                                                  WHEN 'APR' THEN 'Approved'
                                                                  WHEN 'REJ' THEN 'Rejected'
                                                                  WHEN 'PCN' THEN 'Cancelled'
                                                                  WHEN 'PCO' THEN 'Closed' END
                        ||' To '||CASE v_pat_status_type_id WHEN 'INP' THEN 'In-Progress'
                                                            WHEN 'REQ' THEN 'Required Information'
                                                            WHEN 'APR' THEN 'Approved'
                                                            WHEN 'REJ' THEN 'Rejected'
                                                            WHEN 'PCN' THEN 'Cancelled'
                                                            WHEN 'PCO' THEN 'Closed' END;
                                                            
   save_pat_clm_logs('P',v_pat_auth_seq_id,'STC',v_logs,v_added_by,'Y');
   
 END IF;
COMMIT; 
 
END save_authorization;                             

--====================================================================================

--====================================================================================
FUNCTION get_prod_pol_seq_id(v_seq_id IN pat_general_details.pat_gen_detail_seq_id%type,
                             v_flag in varchar2 
                             ) RETURN NUMBER IS


  CURSOR pat_cur IS
     SELECT pad.policy_seq_id,tep.enrol_type_id
     FROM pat_authorization_details pad
     JOiN tpa_enr_policy tep ON (pad.policy_seq_id=tep.policy_seq_id)
     WHERE pad.pat_auth_seq_id=v_seq_id;

  CURSOR clm_cur IS
     SELECT cad.policy_seq_id,tep.enrol_type_id
     FROM clm_authorization_details cad
     JOiN tpa_enr_policy tep ON (cad.policy_seq_id=tep.policy_seq_id)
     WHERE cad.claim_seq_id=v_seq_id;

pat_rec                         pat_cur%rowtype;
v_prod_policy_rule_seq_id        tpa_ins_prod_policy_rules.prod_policy_rule_seq_id%TYPE;
v_result_set                     SYS_REFCURSOR;


BEGIN

if v_flag='PAT' THEN

    OPEN pat_cur;
    FETCH pat_cur INTO pat_rec;
    CLOSE pat_cur;

ELSIF v_flag='CLM' THEN
    OPEN clm_cur;
    FETCH clm_cur INTO pat_rec;
    CLOSE clm_cur;
ELSIF v_flag='POL' THEN

      pat_rec.Policy_Seq_Id:=v_seq_id;
      pat_rec.enrol_type_id:='COR';
ELSIF v_flag='IND' THEN

      pat_rec.Policy_Seq_Id:=v_seq_id;
      pat_rec.enrol_type_id:='IND';      
END IF;

 IF pat_rec.enrol_type_id='COR' THEN
    OPEN v_result_set FOR
       'SELECT gm.prod_policy_rule_seq_id
        FROM tpa_enr_policy GH
        JOIN tpa_ins_prod_policy GT ON (GH.policy_seq_id=GT.policy_seq_id)
        JOIN tpa_ins_prod_policy_rules GM ON (GT.prod_policy_seq_id=GM.prod_policy_seq_id)
     WHERE GH.policy_seq_id=:v_policy_seq_id
     order by gm.prod_policy_rule_seq_id desc' USING pat_rec.policy_seq_id;

     FETCH v_result_set INTO v_prod_policy_rule_seq_id;
     CLOSE v_result_set;
 ELSE
     OPEN v_result_set FOR
    'SELECT gm.prod_policy_rule_seq_id
     FROM tpa_enr_policy tep
     LEFT OUTER JOIN tpa_ins_product tip on (tip.product_seq_id=tep.product_seq_id)
     LEFT OUTER JOIN tpa_ins_prod_policy tipp on (tipp.product_seq_id=tip.product_seq_id)
     JOIN tpa_ins_prod_policy_rules GM on  (tipp.prod_policy_seq_id=GM.prod_policy_seq_id)
     WHERE tep.policy_seq_id=:v_policy_seq_id
     order by gm.prod_policy_rule_seq_id desc '  USING pat_rec.policy_seq_id;

     FETCH v_result_set into v_prod_policy_rule_seq_id;
     CLOSE v_result_set;
 END IF;

return v_prod_policy_rule_seq_id;

END get_prod_pol_seq_id;
--====================================================================================
PROCEDURE create_preauth_xml (
    v_pre_auth_seq_id                       IN  pat_authorization_details.pat_auth_seq_id%type,
    v_preauth_history_doc                   OUT clob
   )
   IS


     CURSOR preauth_cur IS
       SELECT pad.pre_auth_number,
              sou.description AS source_description,
              to_char(pad.pat_received_date,'dd/mm/yyyy') as received_date,
              to_char(pad.hospitalization_date,'dd/mm/yyyy hh:mi:ss AM') as date_of_admission,
              pad.authorization_id id_payer,
              pad.member_seq_id ,
              pad.mem_name,
              pad.mem_age,
              pad.emirate_id,
              tetc.description as encounter_type_id,
              tetd.description as encounter_start_type,
              pad.encounter_facility_id,
              tii.ins_comp_code_number as payer_id,
              pad.auth_number,
              pad.hosp_seq_id,
              to_char(pad.discharge_date,'dd/mm/yyyy hh:mi:ss AM') as date_of_discharge,
              account_info_pkg.get_gen_desc(pad.authorization_type_id,'G') AS Autorization_type,
              pad.tot_gross_amount,
              pad.tot_discount_amount,
              pad.tot_disc_gross_amount,
              pad.tot_patient_share_amount,
              (nvl(pad.tot_disc_gross_amount,0)-nvl(pad.tot_patient_share_amount,0)) as tot_net_amount,
              pad.tot_allowed_amount,
              account_info_pkg.get_gen_desc(pad.pat_status_type_id,'G') as status,
              case when nvl(pad.network_yn,'N')='Y' then thi.hosp_name else nd.provider_name end as hosp_name,
              thi.empanel_number,
              pad.ava_sum_insured,
              tii.ins_comp_name as payer_name,
              pad.tpa_enrollment_id,
              tha.address_1||' '||tha.address_2||' '||tha.address_3||' '||tha.pin_code as provider_details,
              thi.hosp_licenc_numb as provider_id,
              tetd.description as start_type,
              teta.description as end_type,
              nvl(tdc.denial_description,pad.denial_reason) denial_reason,
              pad.medical_opinion_remarks as remarks,
              pad.final_app_amount,
              ben.description as Treatment_cat_type,
			        uc.contact_name as assigned_to,
              pad.internal_remarks,
              smd.description as system_of_med,
              pad.event_no,
              pad.auth_number as auth_number1,
              cad.claim_number,
              CASE WHEN pad.network_yn='Y' THEN 'YES' 
                   WHEN pad.network_yn='N' THEN 'NO' END as Network_yn,
              to_date(pad.lmp_date,'dd-mm-yyyy') as date_of_lmp,
              CASE WHEN pad.process_type='RGL' then 'Regular'
                   WHEN pad.process_type='DBL' then 'Direct_Billing' END as process_type,          
              case when pad.conception_type='NAT' THEN 'Natural'
                   when pad.conception_type='AST' THEN 'Assisted' END AS conception_type,
              case when pad.benifit_type='DNTL' THEN dent.description ELSE null end as dental_treatment_type,
                    
            CASE WHEN epm.vip_yn='Y' THEN 'YES'
                 WHEN epm.vip_yn='N' THEN 'NO' 
              END as vip,
              
            CASE WHEN pad.DELVRY_MOD_TYPE='LSS' THEN 'LSCS'
                  WHEN pad.DELVRY_MOD_TYPE='NOR' THEN 'Normal'
              END as mode_of_delivery,
              
            CASE  WHEN pad.BENIFIT_TYPE='DNTL' THEN 'DENTAL'
                  WHEN pad.BENIFIT_TYPE='OPTS' THEN 'OUT-PATIENT'
                  WHEN pad.BENIFIT_TYPE='OPTC' THEN 'OPTICAL'
                  WHEN pad.BENIFIT_TYPE='IMTI' THEN 'IN-PATIENT MATERNITY'
                  WHEN pad.BENIFIT_TYPE='IPT' THEN 'IN-PATIENT'
                  WHEN pad.BENIFIT_TYPE='HEAC' THEN 'HEALTH CHECK-UP'
                  WHEN pad.BENIFIT_TYPE='DAYC' THEN 'DAYCARE'
                  WHEN pad.BENIFIT_TYPE='OMTI' THEN 'OUT-PATIENT MATERNITY'
                  WHEN pad.BENIFIT_TYPE='IEMA' THEN 'INTERNATIONAL EMERGENCY MEDICAL ASSISTANCE'
                  WHEN pad.BENIFIT_TYPE='PAHC' THEN 'PALLIATIVE AND HOSPICE CARE BENEFIT'
                  WHEN pad.BENIFIT_TYPE='LSS' THEN 'LSCS'
                  WHEN pad.BENIFIT_TYPE='IPRE' THEN 'IN-PATIENT REHABILITATION'
              END as BENIFIT_TYPE,
                NVL(PAD.MAT_COMPLCTON_YN,'N') AS MAT_COMPLCTON_YN,
                 case when NVL(pad.suspect_veri_check,'N')='N' then  irc.status_desc  
                   when NVL(pad.suspect_veri_check,'N')='Y' and pad.status_code_id ='SUSP' then 'Suspected Fraud - Verified'
                     when NVL(pad.suspect_veri_check,'N')='Y' and pad.status_code_id ='ALKT' then 'Alkoot Clarification - Verified'
                       when NVL(pad.suspect_veri_check,'N')='Y' and pad.status_code_id ='PROV' then 'Provider Clarification - Verified' end
                            as internal_remarks_status   
                 
        FROM pat_authorization_details pad
        left outer join tpa_hosp_info thi ON (pad.hosp_seq_id=thi.hosp_seq_id)
        left outer join tpa_hosp_address tha on (thi.hosp_seq_id=tha.hosp_seq_id)
        left outer join pat_non_network_details nd on (nd.pat_auth_seq_id = pad.pat_auth_seq_id)
        left outer join tpa_ins_info tii ON (pad.ins_seq_id=tii.ins_seq_id)
        left outer join tpa_encounter_type_codes tetc ON (pad.encounter_type_id=tetc.encounter_seq_id and tetc.header_type='ENCOUNTER_TYPE')
        left outer join tpa_general_code tgc on (tetc.category_type=tgc.general_type_id)
        left outer join tpa_encounter_type_codes tetD ON (pad.encounter_start_type=tetD.encounter_seq_id and tetD.header_type='ENCOUNTER_START_TYPE')
        left outer join tpa_encounter_type_codes tetA ON (pad.encounter_end_type=tetA.encounter_seq_id and tetA.header_type='ENCOUNTER_END_TYPE')
        left outer join tpa_encounter_type_codes dent ON (pad.treatment_type=dent.encounter_seq_id and dent.header_type='DNTL_ENCOUNTER_TYPE')
        left outer join tpa_denial_codes tdc on (trim(pad.denial_code)=tdc.denial_code)
        left outer join assign_users au on (au.assign_users_seq_id=pad.assign_user_seq_id)
        left outer join tpa_user_contacts uc on (uc.contact_seq_id=au.assigned_to_user)
        left outer join tpa_general_code ben on (pad.benifit_type=ben.general_type_id)
        left outer join tpa_general_code sou on (pad.source_type_id=sou.general_type_id)
        left outer join clm_authorization_details cad on (cad.pat_auth_seq_id=pad.pat_auth_seq_id)
        left outer join tpa_general_code smd on (pad.system_of_medicine_type_id=smd.general_type_id)
        left outer join app.tpa_enr_policy_member epm on (epm.member_seq_id=pad.member_seq_id)
        left outer join app.tpa_internal_remark_stat_code irc on((pad.status_code_id)=(irc.status_code_id))
       WHERE pad.pat_auth_seq_id=v_pre_auth_seq_id;


      CURSOR act_cur IS 
      SELECT    pat.*,case when pat.activity_type='5' AND PAT.CODE != 'PHARMA' then md.short_description
                      when  pat.activity_type='5' AND PAT.CODE = 'PHARMA' then m.short_description
      else m.short_description end as act_desc,tdc.denial_description FROM pat_activity_details pat 
      left outer JOIN tpa_activity_master_details m ON (pat.activity_seq_id=m.act_mas_dtl_seq_id)
      left outer JOIN tpa_pharmacy_master_details md ON (pat.activity_seq_id=md.act_mas_dtl_seq_id)
      left outer JOIN tpa_denial_codes tdc ON (pat.denial_code=tdc.denial_code)
      WHERE pat.pat_auth_seq_id=v_pre_auth_seq_id;

      CURSOR diag_cur IS 
      SELECT    dd.*,tic.short_desc as icd_description     
      FROM diagnosys_details dd 
      left outer join tpa_icd10_master_details tic on (dd.diagnosys_code=tic.icd_code)
      WHERE dd.pat_auth_seq_id=v_pre_auth_seq_id;

      CURSOR observ_cur(v_activity_dtl_seq_id pat_observation_details.activity_dtl_seq_id%type) IS 
      SELECT   account_info_pkg.get_gen_desc( pod.observation_type_id,'G') type,
      pod.observation_code_id,pod.value,
      account_info_pkg.get_gen_desc( pod.obs_value_type_id,'G') as value_type     
      FROM pat_observation_details pod
      WHERE pod.activity_dtl_seq_id =v_activity_dtl_seq_id;



      v_rec_user                   preauth_cur%ROWTYPE;
      act_rec                      act_cur%ROWTYPE;
      diag_rec                     diag_cur%ROWTYPE;
      observ_rec                   observ_cur%ROWTYPE;
      v_preauth_doc                DBMS_XMLDOM.DOMDocument;
      v_preauth_root_node          DBMS_XMLDOM.DOMNode;
      v_elem                       DBMS_XMLDOM.DOMElement;
      v_elem1                      DBMS_XMLDOM.DOMElement;
      v_node                       DBMS_XMLDOM.DOMNode;
      v_parent_node                DBMS_XMLDOM.DOMNODE;
      v_activity_node              DBMS_XMLDOM.DOMNODE;
      v_observ_node              DBMS_XMLDOM.DOMNODE;
      v_diag_node                DBMS_XMLDOM.DOMNODE;
      v_root_node          DBMS_XMLDOM.DOMNode;
      v_ctr                NUMBER := 1 ;
      v_xml                xmltype;

   BEGIN

     /* claim_pkg.create_claim_xml(v_claim_seq_id => v_pre_auth_seq_id,v_claim_history_doc => v_preauth_history_doc);
      return;*/

      OPEN preauth_cur;
      FETCH preauth_cur INTO v_rec_user;
      CLOSE preauth_cur;

      v_preauth_doc := dbms_xmldom.newDOMDocument;
      dbms_xmldom.setVersion( v_preauth_doc, '1.0' );
      v_preauth_root_node := dbms_xmldom.makeNode(v_preauth_doc);

      v_elem := dbms_xmldom.createElement( v_preauth_doc, 'preauthorizationhistory' );
      v_node := dbms_xmldom.makeNode( v_elem );
      v_preauth_root_node := dbms_xmldom.appendChild( v_preauth_root_node, v_node );

      v_elem := dbms_xmldom.createElement(v_preauth_doc, 'preauthorizationdetails');
      dbms_xmldom.setAttribute(v_elem,'preauthnumber',v_rec_user.pre_auth_number);
      dbms_xmldom.setAttribute(v_elem,'source',v_rec_user.source_description);
      dbms_xmldom.setAttribute(v_elem,'recieveddate',v_rec_user.received_date);
      dbms_xmldom.setAttribute(v_elem,'admissiondate',v_rec_user.date_of_admission);
      dbms_xmldom.setAttribute(v_elem,'idpayer',v_rec_user.auth_number);
      dbms_xmldom.setAttribute(v_elem,'memname',v_rec_user.mem_name);
      dbms_xmldom.setAttribute(v_elem,'memberid',v_rec_user.tpa_enrollment_id);
      dbms_xmldom.setAttribute(v_elem,'age',v_rec_user.mem_age);
      dbms_xmldom.setAttribute(v_elem,'emirateid',v_rec_user.emirate_id);
      dbms_xmldom.setAttribute(v_elem,'encountertype',v_rec_user.encounter_type_id);
      dbms_xmldom.setAttribute(v_elem,'encstarttype',v_rec_user.start_type);
      dbms_xmldom.setAttribute(v_elem,'treatmenttype',v_rec_user.dental_treatment_type);
      dbms_xmldom.setAttribute(v_elem,'encendtype', v_rec_user.end_type);
      dbms_xmldom.setAttribute(v_elem,'encfacilityid', v_rec_user.provider_id);
      dbms_xmldom.setAttribute(v_elem,'payerid', v_rec_user.payer_id);
      dbms_xmldom.setAttribute(v_elem,'authnumber', v_rec_user.auth_number);
      dbms_xmldom.setAttribute(v_elem,'discharegedate', v_rec_user.date_of_discharge);
      dbms_xmldom.setAttribute(v_elem,'providername', v_rec_user.hosp_name);
      dbms_xmldom.setAttribute(v_elem,'providerdetails', v_rec_user.provider_details);
      dbms_xmldom.setAttribute(v_elem,'empanenumber', v_rec_user.empanel_number);
      dbms_xmldom.setAttribute(v_elem,'authorizationtype', v_rec_user.autorization_type);
      dbms_xmldom.setAttribute(v_elem,'grossamt', v_rec_user.tot_gross_amount);
      dbms_xmldom.setAttribute(v_elem,'netamt', v_rec_user.tot_net_amount);
      dbms_xmldom.setAttribute(v_elem,'patientshare', v_rec_user.tot_patient_share_amount);
      dbms_xmldom.setAttribute(v_elem,'approvedamt', v_rec_user.final_app_amount);
      dbms_xmldom.setAttribute(v_elem,'status', v_rec_user.status);      
      dbms_xmldom.setAttribute(v_elem,'avasuminsured', v_rec_user.ava_sum_insured);
      dbms_xmldom.setAttribute(v_elem,'payername', v_rec_user.payer_name);
      dbms_xmldom.setAttribute(v_elem,'providerid', v_rec_user.provider_id);
      dbms_xmldom.setAttribute(v_elem,'internalremarks', v_rec_user.internal_remarks);
      dbms_xmldom.setAttribute(v_elem,'sysmed', v_rec_user.system_of_med);
      dbms_xmldom.setAttribute(v_elem,'event_no', v_rec_user.event_no);
      dbms_xmldom.setAttribute(v_elem,'network', v_rec_user.network_yn);
      dbms_xmldom.setAttribute(v_elem,'processtype', v_rec_user.process_type);
	    dbms_xmldom.setAttribute(v_elem,'dlmp', v_rec_user.date_of_lmp);
      dbms_xmldom.setAttribute(v_elem,'conception', v_rec_user.conception_type);
      dbms_xmldom.setAttribute(v_elem,'claimnumber', v_rec_user.claim_number);
      dbms_xmldom.setAttribute(v_elem,'denialreason', v_rec_user.denial_reason);
      dbms_xmldom.setAttribute(v_elem,'remarks', v_rec_user.remarks);
      dbms_xmldom.setAttribute(v_elem,'trmtcatype', v_rec_user.treatment_cat_type);
	    dbms_xmldom.setAttribute(v_elem,'assignto', v_rec_user.assigned_to);
       dbms_xmldom.setAttribute(v_elem,'vip', v_rec_user.vip);
      dbms_xmldom.setAttribute(v_elem,'modeofdelivery', v_rec_user.mode_of_delivery);
	    dbms_xmldom.setAttribute(v_elem,'benifittype', v_rec_user.benifit_type);
      dbms_xmldom.setAttribute(v_elem,'matcomplctonyn', v_rec_user.MAT_COMPLCTON_YN);
      dbms_xmldom.setAttribute(v_elem,'internalremarksstatus',v_rec_user.internal_remarks_status);
      
      
      v_node := dbms_xmldom.makeNode( v_elem );
      v_parent_node := dbms_xmldom.appendChild( v_preauth_root_node, v_node );

    for act_rec IN act_cur LOOP
      v_elem := dbms_xmldom.createElement(v_preauth_doc, 'activitydetails');
      dbms_xmldom.setAttribute(v_elem,'actid',act_rec.code);
      dbms_xmldom.setAttribute(v_elem,'actcode',act_rec.code);
      dbms_xmldom.setAttribute(v_elem,'actdesc',act_rec.act_desc);
      dbms_xmldom.setAttribute(v_elem,'modifier',nvl(act_rec.modifier,'-NA-'));
      dbms_xmldom.setAttribute(v_elem,'unittype',nvl(act_rec.unit_type,'-NA-'));
      dbms_xmldom.setAttribute(v_elem,'qty',nvl(act_rec.quantity,'0'));
      dbms_xmldom.setAttribute(v_elem,'apprqty',nvl(act_rec.approvd_quantity,'0'));
      dbms_xmldom.setAttribute(v_elem,'startdate',act_rec.start_date);
      dbms_xmldom.setAttribute(v_elem,'gross',nvl(act_rec.gross_amount,0));
      dbms_xmldom.setAttribute(v_elem,'disc',nvl(act_rec.discount_amount,0));
      dbms_xmldom.setAttribute(v_elem,'discgross',nvl(act_rec.disc_gross_amount,0));
      dbms_xmldom.setAttribute(v_elem,'patientshare',nvl(act_rec.patient_share_amount,0));
      dbms_xmldom.setAttribute(v_elem,'copay',nvl(act_rec.copay_amount,0));
      dbms_xmldom.setAttribute(v_elem,'ded',nvl(act_rec.deduct_amount,0));
      dbms_xmldom.setAttribute(v_elem,'net',nvl(act_rec.net_amount,0));
      dbms_xmldom.setAttribute(v_elem,'appramt',act_rec.approved_amount);
      dbms_xmldom.setAttribute(v_elem,'allowedamt',act_rec.allowed_amount);
      dbms_xmldom.setAttribute(v_elem,'denialcode',NVL(act_rec.denial_code,'-NA-'));
      dbms_xmldom.setAttribute(v_elem,'denialdesc',NVL(act_rec.denial_description,'-NA-'));
      dbms_xmldom.setAttribute(v_elem,'remarks',NVL(act_rec.remarks,'-NA-'));
      dbms_xmldom.setAttribute(v_elem,'currency',NVL(act_rec.currency_type,'-NA-'));
      dbms_xmldom.setAttribute(v_elem,'copayperc',NVL(act_rec.copay_perc,0));
      dbms_xmldom.setAttribute(v_elem,'actdtlseqid',act_rec.activity_dtl_seq_id);
      dbms_xmldom.setAttribute(v_elem,'toothnum',act_rec.tooth_no);

      v_node := dbms_xmldom.makeNode( v_elem );
      v_activity_node := dbms_xmldom.appendChild( v_parent_node, v_node );

    for observ_rec in observ_cur(act_rec.Activity_Dtl_Seq_Id) loop
      v_elem := dbms_xmldom.createElement(v_preauth_doc, 'observationdetails');    
      dbms_xmldom.setAttribute(v_elem,'type',observ_rec.type);
      dbms_xmldom.setAttribute(v_elem,'code',observ_rec.observation_code_id);
      dbms_xmldom.setAttribute(v_elem,'value',observ_rec.value);
      dbms_xmldom.setAttribute(v_elem,'valuetype',observ_rec.value_type);
      v_node := dbms_xmldom.makeNode( v_elem );
      v_observ_node := dbms_xmldom.appendChild( v_activity_node, v_node );      

      end loop;      
     end loop;

      for diag_rec in diag_cur loop
      v_elem := dbms_xmldom.createElement(v_preauth_doc, 'diagnosysdetails');
      dbms_xmldom.setAttribute(v_elem,'diagcode',diag_rec.diagnosys_code);
      dbms_xmldom.setAttribute(v_elem,'description',diag_rec.icd_description);
      dbms_xmldom.setAttribute(v_elem,'primary',case when diag_rec.primary_ailment_yn='Y' then 'Yes' else 'No' end);
      dbms_xmldom.setAttribute(v_elem,'copay',diag_rec.copay);
      dbms_xmldom.setAttribute(v_elem,'denailreason',diag_rec.denial_reason);
      dbms_xmldom.setAttribute(v_elem,'remarks',diag_rec.remarks);
      v_node := dbms_xmldom.makeNode( v_elem );
      v_diag_node := dbms_xmldom.appendChild( v_parent_node, v_node );
      end loop;      



     v_xml  := dbms_xmldom.getxmltype(v_preauth_doc);
     v_preauth_history_doc:=v_xml.getclobval();

    /* delete from temp_xml;
     insert into temp_xml(xml_val) values (v_xml);
     commit;*/

     dbms_xmldom.freeDocument(v_preauth_doc);
   END create_preauth_xml;
--====================================================================================

--====================================================================================
PROCEDURE save_enhanced_preauth(v_pat_auth_seq_id            IN OUT pat_authorization_details.pat_auth_seq_id%TYPE,
                                v_parent_pat_auth_seq_id     IN pat_authorization_details.pat_auth_seq_id%TYPE,
                                v_added_by                   IN NUMBER)
IS

CURSOR pat_cur IS
SELECT pad.pat_auth_seq_id,
       pad.pat_batch_seq_id,
       pad.claim_seq_id,
       pad.member_seq_id,
       tepg.policy_group_seq_id,
       tep.policy_seq_id,
       tep.enrol_type_id,
       tep.policy_sub_general_type_id,
       pad.final_app_amount
  FROM pat_authorization_details pad
  JOIN tpa_enr_policy_member tepm ON (pad.member_seq_id=tepm.member_seq_id)
  JOIN tpa_enr_policy_group tepg ON (tepm.policy_group_seq_id=tepg.policy_group_seq_id)
  JOIN tpa_enr_policy tep ON (tepg.policy_seq_id=tep.policy_seq_id)
  WHERE pad.pat_auth_seq_id=v_parent_pat_auth_seq_id;

 pat_rec              pat_cur%ROWTYPE;

BEGIN

   OPEN  pat_cur;
   FETCH pat_cur INTO pat_rec;
   CLOSE pat_cur;

  INSERT INTO pat_authorization_details
        ( pat_auth_seq_id,
          pat_batch_seq_id,
          claim_seq_id,
          parent_pat_auth_seq_id,
          pat_received_date,
          source_type_id,
          hospitalization_date,
          discharge_date,
          claim_sub_type,
          member_seq_id,
          tpa_enrollment_id,
          pre_auth_number,
          auth_number,
          mem_name,
          mem_age,
          ins_seq_id,
          hosp_seq_id,
          policy_seq_id,
          tpa_office_seq_id,
          assign_user_seq_id,
          enrol_type_id,
          emirate_id,
          authorization_id,
          encounter_type_id,
          encounter_start_type,
          encounter_end_type,
          encounter_facility_id,
          authorization_type_id,
          maternity_allowed_amt,
          ava_sum_insured,	
          tot_gross_amount,		
          tot_discount_amount,		
          tot_disc_gross_amount	,		
          tot_patient_share_amount,	
          tot_net_amount,
          tot_allowed_amount,	
          final_app_amount,
          pat_enhanced_yn	,
          currency_type,
          pat_status_type_id,
          maternity_yn,			
          manual_process_req_yn,			
          denial_reason	,	
          remarks,
          completed_yn,
          completed_date,
          added_by,
          added_date,
          updated_by,			
          updated_date,	
          tot_approved_amount,			
          clinician_id,
          presenting_complaints,
          medical_opinion_remarks,
          system_of_medicine_type_id,
          accident_related_type_id,
          Priority_General_Type_Id,
          network_yn,
          requested_amount,
          benifit_type,
          gravida,
          para,
          live,
          abortion,
          denial_code,
          benefit_limit,
          benefit_copay,
          dis_allowed_amount,
          patient_id,
          authorized_by) 
  SELECT  pat_auth_detail_seq.nextval,
          pat_batch_seq_id,
          claim_seq_id,
          pat_rec.pat_auth_seq_id,
          pat_received_date,
          source_type_id,
          hospitalization_date,
          discharge_date,
          claim_sub_type,
          member_seq_id,
          tpa_enrollment_id,
          pre_auth_number,
          auth_number,
          mem_name,
          mem_age,
          ins_seq_id,
          hosp_seq_id,
          policy_seq_id,
          tpa_office_seq_id,
          assign_user_seq_id,
          enrol_type_id,
          emirate_id,
          authorization_id,
          encounter_type_id,
          encounter_start_type,
          encounter_end_type,
          encounter_facility_id,
          authorization_type_id,
          0,
          0,
          0,
          0,
          0,
          0,
          0,
          0,
          0,
          'N',
          currency_type,
          'INP',
          NULL,
          NULL,
          NULL,
          remarks,
          'N',
          NULL,
          added_by,
          added_date,
          NULL,
          NULL,
          0,
          pad.clinician_id,
          pad.presenting_complaints,
          pad.medical_opinion_remarks,
          pad.system_of_medicine_type_id,
          pad.accident_related_type_id,
          Pad.Priority_General_Type_Id,
          pad.network_yn,
          pad.requested_amount,
          pad.benifit_type,
          pad.gravida,
          pad.para,
          pad.live,
          pad.abortion,
          pad.denial_code,
          pad.benefit_limit,
          pad.benefit_copay,
          pad.dis_allowed_amount,
          pad.patient_id,
          pad.authorized_by

 FROM pat_authorization_details pad
 WHERE  pad.pat_auth_seq_id = v_parent_pat_auth_seq_id;

 SELECT pat_auth_detail_seq.currval INTO v_pat_auth_seq_id FROM DUAL;

  UPDATE pat_authorization_details pad
      SET pad.pat_enhanced_yn='Y'
  WHERE pad.pat_auth_seq_id=v_parent_pat_auth_seq_id; 

 IF pat_rec.policy_sub_general_type_id ='PFL' THEN

   UPDATE tpa_enr_balance teb 
     SET teb.utilised_sum_insured=teb.utilised_sum_insured-pat_rec.final_app_amount
   WHERE teb.policy_group_seq_id=pat_rec.policy_group_seq_id;

 ELSIF pat_rec.policy_sub_general_type_id ='PNF' THEN

    UPDATE tpa_enr_balance teb 
     SET teb.utilised_sum_insured=teb.utilised_sum_insured-pat_rec.final_app_amount
   WHERE teb.member_seq_id=pat_rec.member_seq_id;

 END IF;  

 COMMIT;  
END save_enhanced_preauth;                                 
--====================================================================================

--====================================================================================
PROCEDURE select_member(v_tpa_enrollment_id      IN tpa_enr_policy_member.tpa_enrollment_id%type,
                        v_result_set             OUT SYS_REFCURSOR)

IS

BEGIN

  OPEN v_result_set  FOR
  SELECT a.member_seq_id,
         a.tpa_enrollment_id,
         a.global_net_member_id ,
         a.mem_name||' '||a.mem_last_name||' '||a.family_name as mem_name,----
         nvl(a.mem_age,(months_between(sysdate,a.mem_dob)/12)) as mem_age,
         a.emirate_id,
         tii.ins_seq_id,
         tii.ins_comp_name,
         tii.ins_comp_code_number as payer_id,
         c.policy_seq_id,
         c.enrol_type_id,
         account_info_pkg.get_gen_desc(A.GENDER_GENERAL_TYPE_ID,'G') AS gender,
         (c.policy_number||'('||ip.product_cat_type_id||')') as policy_number,
         (d.group_name||'('||d.group_id||')') as corporate_name,
         d.group_reg_seq_id,
         c.effective_from_date as policy_start_date,
         c.effective_to_date as policy_end_date,
         nc.description as nationality,
         nvl(eb.sum_insured,0) - nvl(eb.utilised_sum_insured,0) AS ava_sum_insured,
         EB.SUM_INSURED,
         ip.product_name,
         case when nvl(a.vip_yn,'N')='N' then 'No' else 'Yes' end as vip_yn,
         ip.product_cat_type_id as NETWORK_TYPE,

    to_char(a.date_of_inception, 'DD/MM/YYYY') as clm_mem_insp_date,
         tii.payer_authority --payer authority
  FROM   tpa_enr_policy_member A
  JOIN tpa_enr_policy_group B ON (A.policy_group_seq_id = B.policy_group_seq_id)
  JOIN tpa_enr_policy C ON (B.policy_seq_id = C.policy_seq_id )
  JOIN tpa_ins_product ip ON (ip.product_seq_id=c.product_seq_id)
  LEFT OUTER JOIN tpa_group_registration d ON (d.group_reg_seq_id=c.group_reg_seq_id)
  join tpa_ins_info tii on (c.ins_seq_id=tii.ins_seq_id)
  left outer join tpa_nationalities_code nc on (nc.nationality_id=a.nationality_id)
  LEFT OUTER JOIN tpa_enr_balance eb ON (b.policy_group_seq_id = eb.policy_group_seq_id)
  WHERE (a.tpa_enrollment_id=upper(v_tpa_enrollment_id) or a.global_net_member_id = v_tpa_enrollment_id)
  AND ( SYSDATE BETWEEN C.effective_from_date AND C.effective_to_date+1)
  and  (a.mem_general_type_id != 'PFL' AND a.member_seq_id = eb.member_seq_id OR eb.member_seq_id IS NULL OR a.member_seq_id IS NULL)
  and a.status_general_type_id ='POA'
  AND b.status_general_type_id ='POA'
  AND C.COMPLETED_YN='Y'
  and B.DELETED_YN='N'
  AND A.DELETED_YN='N';




END select_member;
--====================================================================================
PROCEDURE select_provider(v_provider_id            IN tpa_hosp_info.hosp_licenc_numb%type,
                          v_result_set             OUT SYS_REFCURSOR)

IS

BEGIN

  OPEN v_result_set  FOR
  SELECT
     a.hosp_seq_id,
     a.hosp_name,
     a.empanel_number,
     c.from_date,
     c.To_Date,
     b.addr_seq_id,
     b.address_1,
     b.address_2,
     b.address_3,
     b.address_1||b.address_2||b.address_3 AS address,
     b.state_type_id,
     d.state_name,
     b.city_type_id,
     e.city_description,
     G.country_name,
     b.pin_code,
     a.off_phone_no_1,
     a.off_phone_no_2,
     a.office_fax_no,
     ttk_util_pkg.fn_decrypt(a.primary_email_id) primary_email_id, 
     b.hosp_bank_seq_id,
     c.empanel_seq_id ,
     A.remarks AS hosp_remarks,
     F.empanel_description AS hosp_status,
     C.empanel_status_type_id,
     a.primary_network
     FROM tpa_hosp_info A 
     JOIN tpa_hosp_address B ON (a.hosp_seq_id = b.hosp_seq_id )
     JOIN tpa_hosp_empanel_status c ON (a.hosp_seq_id = C.hosp_seq_id AND C.active_yn = 'Y')
     LEFT OUTER JOIN tpa_state_code d ON (b.state_type_id = d.state_type_id)
     LEFT OUTER JOIN tpa_city_code e ON (b.city_type_id = e.city_type_id)
     JOIN tpa_hosp_empanel_status_code F ON (C.empanel_status_type_id = F.empanel_status_type_id)
     LEFT OUTER JOIN tpa_country_code G ON (B.country_id = G.country_id)
     WHERE a.hosp_licenc_numb = UPPER(v_provider_id);


END select_provider;
--====================================================================================
PROCEDURE select_icd(v_icd_code             IN  tpa_icd_codes.icd_code%type,
                     v_seq_id               IN  pat_authorization_details.pat_auth_seq_id%type, 
                     v_mode                 IN VARCHAR2,--PAT,CLM
                     v_result_set           OUT SYS_REFCURSOR)

IS
 v_count             number(10);
BEGIN
  IF v_mode='PAT' THEN
    select count(1) into v_count from diagnosys_details d where d.pat_auth_seq_id=v_seq_id;
  ELSE 
    select count(1) into v_count from diagnosys_details d where d.Claim_Seq_Id=v_seq_id;  
  END IF;
  OPEN v_result_set  FOR
  SELECT tic.icd10_seq_id as icd_code_seq_id,
         tic.icd_code,
         tic.short_desc as icd_description,
         null as master_icd_code,
         case when  v_count>0 then 'YES' ELSE 'NO' END AS primary

   FROM tpa_icd10_master_details tic
  where tic.icd_code=upper(v_icd_code);

END select_icd;
--====================================================================================
PROCEDURE select_activity_code(v_seq_id                    IN  pat_authorization_details.pat_auth_seq_id%TYPE,
                               v_mode                      IN  VARCHAR2,
                               v_activity_code             IN  OUT tpa_activity_master_details.activity_code%type,
                               v_flag                      IN  VARCHAR2,
                               v_activity_date             IN  pat_activity_details.start_date%TYPE,
                               v_act_result                OUT SYS_REFCURSOR,
                               v_tariff_result             OUT SYS_REFCURSOR)

IS

CURSOR pat_cur IS
SELECT pad.hosp_seq_id,tip.product_cat_type_id,tep.ins_seq_id,tep.group_reg_seq_id,pad.pat_auth_seq_id,null as claim_type,pad.network_yn, pad.policy_seq_id,tep.tariff_type_id,pad.benifit_type,
       CASE WHEN TRUNC(pad.discharge_date) = TRUNC(pad.hospitalization_date) THEN 1
            ELSE (TRUNC(pad.discharge_date)-TRUNC(pad.hospitalization_date)) END AS hosp_days,
       pad.conversion_rate
FROM pat_authorization_details pad
JOIN tpa_enr_policy tep ON (pad.policy_seq_id=tep.policy_seq_id)
JOIN tpa_ins_product tip ON (tep.product_seq_id=tip.product_seq_id)
WHERE pad.pat_auth_seq_id=v_seq_id;

CURSOR clm_cur IS
SELECT hd.hosp_seq_id,tip.product_cat_type_id,tep.ins_seq_id,tep.group_reg_seq_id,pad.claim_seq_id,pad.claim_type,pad.network_yn,pad.policy_seq_id,tep.tariff_type_id,pad.benifit_type,
       CASE WHEN TRUNC(pad.date_of_discharge) = TRUNC(pad.date_of_hospitalization) THEN 1
            ELSE (TRUNC(pad.date_of_discharge)-TRUNC(pad.date_of_hospitalization)) END AS hosp_days,
       pad.conversion_rate
FROM clm_authorization_details pad
JOIN clm_hospital_details hd on (hd.claim_seq_id=pad.claim_seq_id)
JOIN tpa_enr_policy tep ON (pad.policy_seq_id=tep.policy_seq_id)
JOIN tpa_ins_product tip ON (tep.product_seq_id=tip.product_seq_id)
WHERE pad.claim_seq_id=v_seq_id;

pat_rec             pat_cur%ROWTYPE;

/*
CURSOR provider_network(v_hosp_seq number) IS 
SELECT i.cn_yn,i.gn_yn,i.sn_yn,i.bn_yn,i.wn_yn,i.primary_network FROM tpa_hosp_info i where i.hosp_seq_id=v_hosp_seq;
*/

CURSOR provider_network(v_hosp_seq number,v_product_net_type varchar2) IS
SELECT i.primary_network, ny.network_type, ny.network_yn, gc.sort_no
  FROM tpa_hosp_info i, app.tpa_hosp_network ny, app.tpa_general_code gc
 where ny.hosp_seq_id = i.hosp_seq_id
   and gc.general_type_id = ny.network_type
   and gc.header_type = 'PROVIDER_NETWORK'
   and ny.network_yn = 'Y'
   and i.hosp_seq_id = v_hosp_seq--35939 --35337
   and gc.sort_no =
       (SELECT min(gc.sort_no)
          FROM tpa_hosp_info        i,
               app.tpa_hosp_network ny,
               app.tpa_general_code gc
         where ny.hosp_seq_id = i.hosp_seq_id
           and gc.general_type_id = ny.network_type
           and gc.header_type = 'PROVIDER_NETWORK'
           and ny.network_yn = 'Y'
           and i.hosp_seq_id = v_hosp_seq--35939 --35337 
           and gc.sort_no >=
               (SELECT min(gc.sort_no)
                  FROM tpa_hosp_info        i,
                       app.tpa_hosp_network ny,
                       app.tpa_general_code gc
                 where ny.hosp_seq_id = i.hosp_seq_id
                   and gc.general_type_id = ny.network_type
                   and gc.header_type = 'PROVIDER_NETWORK'
                   and i.hosp_seq_id = v_hosp_seq--35939
                   and gc.general_type_id = v_product_net_type))
 order by gc.sort_no;

CURSOR PHARMACY_DISCOUNT(v_hosp_seq number) IS
SELECT A.DISC_PERCENT FROM app.tpa_hosp_tariff_details a where a.acitivity_type_seq_id=5 and a.hosp_seq_id=v_hosp_seq; 

CURSOR cur_cb_dtl IS
SELECT a.cond_fun,b.coverage_pay_val,
       NVL(SUBSTR(a.cond_fun,instr(a.cond_fun,'''',1,3)+1,((instr(a.cond_fun,'''',1,4))-(instr(a.cond_fun,'''',1,3)))-1 ),0) AS amount
FROM tpa_ins_prod_pol_conditions a
JOIN tpa_ins_prod_pol_coverages b ON (a.coverage_seq_id=b.coverage_seq_id)
JOIN tpa_ins_prod_pol_clauses c ON (b.clause_seq_id=c.clause_seq_id)
where c.Prod_Policy_Rule_Seq_Id=V_Prod_Policy_Rule_Seq_Id
 AND a.cond_fun like 'get_cb_limit%';
 
rec_cb_dtl     cur_cb_dtl%ROWTYPE; 
 
provider_rec   provider_network%rowtype;

CURSOR Get_hosp_tariff_seq_id (v_int_code VARCHAR2,v_hospital_seq_id NUMBER, v_network_type VARCHAR2)is
        SELECT t.hosp_tariff_seq_id from tpa_hosp_tariff_details t
        JOIN tpa_general_code tg ON (tg.general_type_id = t.network_type)
          where t.internal_code = v_int_code and t.hosp_seq_id=v_hospital_seq_id
          and t.start_date <= v_activity_date and nvl(t.end_date,v_activity_date) >=v_activity_date
          AND  UPPER(t.network_type) IN (select general_type_id
                                            FROM (select g.general_type_id, g.sort_no, dense_rank() over(order by g.sort_no) r
                                                  from tpa_general_code g
                                                  where g.header_type = 'PROVIDER_NETWORK'
                                                 ) q
          WHERE  q.r >=(select sort_no from tpa_general_code where general_type_id = v_network_type))
          ORDER BY tg.sort_no;
          /*and t.network_type = v_network_type
          and t.start_date <= v_activity_date and nvl(t.end_date,v_activity_date) >=v_activity_date; */
          
v_product_network_type    varchar2(20);
v_count   number(10);
v_tariff_ins_seq_id           number(10);
v_tariff_count                number(10);
v_tpa_ins_seq_id              number(10);
v_activity_type_seq_id        number(10);
V_PHARMACY_DISC               NUMBER;
v_act_cnt                     NUMBER(10);
v_perday_cb_amnt              number(16,2);
v_int_tariff_seq_id           number(30);


CURSOR act_code_cur(v_hosp_seq number, v_activity_date pat_activity_details.start_date%type, v_network VARCHAR2) IS
  SELECT m.activity_code
  FROM tpa_activity_master_details m
  LEFT JOIN tpa_activity_details t ON (m.activity_code = t.activity_code)
  LEFT JOIN tpa_hosp_tariff_details th ON (th.activity_seq_id = m.act_mas_dtl_seq_id)
  JOIN tpa_general_code tg ON (tg.general_type_id = th.network_type)
  WHERE th.hosp_seq_id = v_hosp_seq
  AND (UPPER(th.internal_code) = UPPER(v_activity_code)
  OR UPPER(th.hosp_tariff_seq_id) = UPPER(v_activity_code))
  AND  UPPER(th.network_type)IN (select general_type_id
                                     FROM (select g.general_type_id, g.sort_no, dense_rank() over(order by g.sort_no) r
                                           from tpa_general_code g
                                           where g.header_type = 'PROVIDER_NETWORK'
                                          ) q
       WHERE  q.r >=(select sort_no from tpa_general_code where general_type_id = v_network))
       and th.start_date <= v_activity_date and nvl(th.end_date, v_activity_date) >= v_activity_date
       ORDER BY tg.sort_no;

  
CURSOR act_code_cur1(v_hosp_seq number, v_activity_date pat_activity_details.start_date%type, v_network VARCHAR2) IS
  SELECT m.activity_code
  FROM tpa_activity_master_details m
  LEFT JOIN tpa_activity_details t ON (m.activity_code = t.activity_code)
  LEFT JOIN tpa_hosp_tariff_details th ON (th.activity_seq_id = m.act_mas_dtl_seq_id)
  JOIN tpa_general_code tg ON (tg.general_type_id = th.network_type)
  WHERE th.hosp_seq_id = v_hosp_seq
  AND UPPER(th.internal_code) = UPPER(v_activity_code)
  AND  UPPER(th.network_type)IN (select general_type_id
                                     FROM (select g.general_type_id, g.sort_no, dense_rank() over(order by g.sort_no) r
                                           from tpa_general_code g
                                           where g.header_type = 'PROVIDER_NETWORK'
                                          ) q
       WHERE  q.r >=(select sort_no from tpa_general_code where general_type_id = v_network))
       and th.start_date <= v_activity_date and nvl(th.end_date, v_activity_date) >= v_activity_date
       ORDER BY tg.sort_no;
  /*and th.start_date <= v_activity_date and nvl(th.end_date,v_activity_date) >=v_activity_date
  and th.network_type = v_network; */
  
CURSOR mem_act_code_cur(v_hosp_seq number) IS
  SELECT m.activity_code
  FROM tpa_activity_master_details m
  LEFT JOIN tpa_activity_details t ON (m.activity_code = t.activity_code)
  LEFT JOIN tpa_hosp_tariff_details th ON (th.activity_seq_id = m.act_mas_dtl_seq_id)
  WHERE th.hosp_seq_id = v_hosp_seq
  AND UPPER(th.hosp_tariff_seq_id) = UPPER(v_activity_code);  

v_act_code  VARCHAR2(30);
v_tra_pharma_cnt NUMBER := 0;
BEGIN
                              
 if v_mode='PAT' then
 OPEN  pat_cur;
 FETCH pat_cur INTO pat_rec;
 CLOSE pat_cur;
 else 
  OPEN  clm_cur;
  FETCH clm_cur INTO pat_rec;
  CLOSE clm_cur;
 end if;
 OPEN provider_network(pat_rec.hosp_seq_id,pat_rec.product_cat_type_id);
 FETCH provider_network INTO provider_rec;
 CLOSE provider_network;

 IF pat_rec.Ins_Seq_Id IS NOT NULL THEN 
   SELECT COUNT(1) INTO v_tariff_count from tpa_hosp_tariff_details d 
   where d.ins_seq_id=pat_rec.Ins_Seq_Id and d.hosp_seq_id=pat_rec.hosp_seq_id
   and d.start_date <= v_activity_date and nvl(d.end_date,v_activity_date) >=v_activity_date;
 END IF; 

 select ii.ins_seq_id into v_tpa_ins_seq_id from app.tpa_ins_info ii where ii.ins_comp_code_number='ALK01'; 
   IF v_tariff_count>0 THEN 
     v_tariff_ins_seq_id:=pat_rec.Ins_Seq_Id;
   ELSE 
     v_tariff_ins_seq_id:=v_tpa_ins_seq_id;
   END IF; 
       
 IF v_mode='PAT' or nvl(pat_rec.claim_type,'CNH')!='CTM' then 
 IF pat_rec.tariff_type_id='HSPL' THEN

     v_product_network_type:=provider_rec.network_type;  


   --select m.activity_type_seq_id into v_activity_type_seq_id from app.tpa_activity_master_details m where m.activity_code=upper(trim(v_activity_code));
   if length(v_activity_code)>=15 OR UPPER(v_activity_code)='S5001' then
     --select m.activity_type_seq_id into v_activity_type_seq_id from app.tpa_pharmacy_master_details m where m.activity_code=upper(trim(v_activity_code));
     v_activity_type_seq_id:=5;
   end if;
   
   IF v_flag != 'MSTR' THEN
     select count(t.internal_code) into v_tra_pharma_cnt----
     from tpa_hosp_tariff_details t
     join tpa_activity_master_details ac on t.activity_seq_id = ac.act_mas_dtl_seq_id
     where t.hosp_seq_id = pat_rec.hosp_seq_id
     and (upper(t.internal_code) = upper(v_activity_code)
     or ac.activity_code = upper(v_activity_code)); 
   END IF; 
 
   if v_activity_type_seq_id=5 AND v_tra_pharma_cnt = 0 then
     select count(1) into v_count from tpa_pharmacy_master_details tamd
     JOIN tpa_activity_type_codes tatc ON (tamd.activity_type_seq_id=tatc.activity_type_seq_id)
     WHERE tamd.activity_code=upper(v_activity_code)
     AND tamd.start_date <= v_activity_date and nvl(tamd.end_date,v_activity_date) >=v_activity_date; 
   
   else
    IF v_flag='INT'  THEN
        select count(1) into v_count           
          from tpa_activity_master_details tamd
          JOIN tpa_activity_type_codes tatc ON (tamd.activity_type_seq_id=tatc.activity_type_seq_id)
          JOIN tpa_hosp_tariff_details thtd ON (tamd.act_mas_dtl_seq_id=thtd.activity_seq_id)
          JOIN tpa_general_code tg ON (tg.general_type_id = thtd.network_type)
          WHERE thtd.hosp_seq_id=pat_rec.hosp_seq_id
          AND thtd.ins_seq_id=v_tariff_ins_seq_id
          --AND thtd.network_type=v_product_network_type--pat_rec.product_cat_type_id
          AND  UPPER(thtd.network_type)IN (select general_type_id
                                           from (select g.general_type_id, g.sort_no, dense_rank() over(order by g.sort_no) r
                                                 from tpa_general_code g
                                                 where g.header_type = 'PROVIDER_NETWORK'
                                                ) q
                                           WHERE  q.r >=(select sort_no from tpa_general_code where general_type_id = v_product_network_type)
                                          )
          AND v_activity_date BETWEEN  thtd.start_date AND NVL(thtd.end_date,v_activity_date)
          OR UPPER(tamd.activity_code) = upper(v_activity_code);
    ELSIF  v_flag ='SEARCHOUT' THEN   
      select count(1) into v_count           
        from tpa_activity_master_details tamd
        JOIN tpa_activity_type_codes tatc ON (tamd.activity_type_seq_id=tatc.activity_type_seq_id)
        JOIN tpa_hosp_tariff_details thtd ON (tamd.act_mas_dtl_seq_id=thtd.activity_seq_id)
        JOIN tpa_general_code tg ON (tg.general_type_id = thtd.network_type)
        WHERE thtd.hosp_seq_id=pat_rec.hosp_seq_id
        AND thtd.ins_seq_id=v_tariff_ins_seq_id
        AND  UPPER(thtd.network_type)IN (select general_type_id
                                           from (select g.general_type_id, g.sort_no, dense_rank() over(order by g.sort_no) r
                                                 from tpa_general_code g
                                                 where g.header_type = 'PROVIDER_NETWORK'
                                                ) q
                                           WHERE  q.r >=(select sort_no from tpa_general_code where general_type_id = v_product_network_type)
                                          )
        AND v_activity_date BETWEEN  thtd.start_date AND NVL(thtd.end_date,v_activity_date)
        AND UPPER(thtd.internal_code) = upper(v_activity_code)
        ORDER BY tg.sort_no;
      ELSE
        select count(1) into v_count           
          from tpa_activity_master_details tamd
          JOIN tpa_activity_type_codes tatc ON (tamd.activity_type_seq_id=tatc.activity_type_seq_id)
          JOIN tpa_hosp_tariff_details thtd ON (tamd.act_mas_dtl_seq_id=thtd.activity_seq_id)
          JOIN tpa_general_code tg ON (tg.general_type_id = thtd.network_type)
          WHERE thtd.hosp_seq_id=pat_rec.hosp_seq_id
          AND thtd.ins_seq_id=v_tariff_ins_seq_id
          AND  UPPER(thtd.network_type)IN (select general_type_id
                                           from (select g.general_type_id, g.sort_no, dense_rank() over(order by g.sort_no) r
                                                 from tpa_general_code g
                                                 where g.header_type = 'PROVIDER_NETWORK'
                                                ) q
                                           WHERE  q.r >=(select sort_no from tpa_general_code where general_type_id = v_product_network_type)
                                          )
          AND v_activity_date BETWEEN  thtd.start_date AND NVL(thtd.end_date,v_activity_date)
          AND (UPPER(tamd.activity_code)) =upper(v_activity_code)
          ORDER BY tg.sort_no;
      END IF;
   end if;

   if v_activity_type_seq_id=5 AND v_tra_pharma_cnt = 0 then 

     OPEN PHARMACY_DISCOUNT(pat_rec.hosp_seq_id);
     FETCH PHARMACY_DISCOUNT INTO V_PHARMACY_DISC;
     CLOSE PHARMACY_DISCOUNT;

    if v_count>0 then
      OPEN v_tariff_result FOR 
     select 
           tamd.unit_price as gross_amount ,
           ((tamd.unit_price*NVL(v_pharmacy_disc,0))/100) as disc_amount,
           ((tamd.unit_price*NVL(v_pharmacy_disc,0))/100) as unit_discount,
           tamd.unit_price as disc_gross_amount,
           null as bundle_id,
           null as package_id,
           null as internal_code,
           tamd.act_mas_dtl_seq_id as activity_seq_id,
           tamd.activity_code,
           tamd.activity_description,
           tatc.activity_type_seq_id,
           tatc.activity_type_id,
           NULL as req_quantity,
           NVL(d.tooth_no_required, 'N') as tooth_requ_yn,
           NULL AS internal_desc,
	     NVL(d.tooth_no_required, 'N') as tooth_req_yn,
           'N' as al_ahli_yn	
           
    from tpa_pharmacy_master_details tamd
    JOIN tpa_activity_type_codes tatc ON (tamd.activity_type_seq_id=tatc.activity_type_seq_id)
    LEFT JOIN dental_rule_tab d ON (d.cdt_code = tamd.activity_code)
    WHERE tamd.Activity_Code=upper(v_activity_code)
    AND tamd.start_date <= v_activity_date and nvl(tamd.end_date,v_activity_date) >=v_activity_date;
   else
     OPEN v_tariff_result FOR 
     select 
           tamd.unit_price as gross_amount ,
           ((tamd.unit_price*NVL(v_pharmacy_disc,0))/100) as disc_amount,
           ((tamd.unit_price*NVL(v_pharmacy_disc,0))/100) as unit_discount,
           tamd.unit_price as disc_gross_amount,
           null as bundle_id,
           null as package_id,
           null as internal_code,
           tamd.act_mas_dtl_seq_id as activity_seq_id,
           tamd.activity_code,
           tamd.activity_description,
           tatc.activity_type_seq_id,
           tatc.activity_type_id,
           NULL as req_quantity,
           NVL(d.tooth_no_required, 'N') as tooth_requ_yn,
           NULL AS internal_desc,
	    NVL(d.tooth_no_required, 'N') as tooth_req_yn,
          'N' as al_ahli_yn	
           
    from tpa_pharmacy_master_details tamd
    JOIN tpa_activity_type_codes tatc ON (tamd.activity_type_seq_id=tatc.activity_type_seq_id)
    LEFT JOIN dental_rule_tab d ON (d.cdt_code = tamd.activity_code)
    WHERE tamd.activity_code=upper(v_activity_code) order by tamd.act_mas_dtl_seq_id desc ;
   end if;
   else
     IF v_flag ='MSTR' THEN
       OPEN v_tariff_result FOR 
         select null gross_amount ,
                null disc_amount,
                null unit_discount,
                null disc_gross_amount,
                null bundle_id,
                null package_id,
                null internal_code,
                null activity_seq_id,
                m.activity_code as activity_code,
                m.activity_description activity_description,
                m.activity_type_seq_id as activity_type_seq_id,
                t.activity_type_id as activity_type_id,
                NULL as req_quantity,
                NVL(d.tooth_no_required, 'N') as tooth_requ_yn,
                null internal_desc,
                null as al_ahli_yn
         
         from tpa_activity_master_details m
         JOIN tpa_activity_type_codes t ON (m.activity_type_seq_id=t.activity_type_seq_id)
         LEFT JOIN dental_rule_tab d ON (d.cdt_code = m.activity_code)
         where m.activity_code = UPPER(v_activity_code);
         
     ELSIF v_flag ='ACT' THEN
       OPEN v_tariff_result FOR 
        select 
               thtd.gross_amount ,
               thtd.disc_amount,
               case when tamd.service_seq_id in (14,7) then thtd.gross_amount * thtd.disc_percent / 100 else thtd.disc_amount end as unit_discount,
               thtd.gross_amount- thtd.disc_amount as disc_gross_amount,
               thtd.bundle_id,
               thtd.package_id,
               thtd.internal_code,
               tamd.act_mas_dtl_seq_id as activity_seq_id,
               tamd.activity_code,
               tamd.activity_description,
               tatc.activity_type_seq_id,
               tatc.activity_type_id,
               NULL as req_quantity,
               NVL(d.tooth_no_required, 'N') as tooth_requ_yn,
               thtd.internal_desc,
               CASE WHEN hi.hosp_name LIKE 'AL AHLI HOSPITAL%%' THEN 'Y' ELSE 'N' END as al_ahli_yn
               
              
               
        from tpa_activity_master_details tamd
        JOIN tpa_activity_type_codes tatc ON (tamd.activity_type_seq_id=tatc.activity_type_seq_id)
        JOIN tpa_hosp_tariff_details thtd ON (tamd.act_mas_dtl_seq_id=thtd.activity_seq_id)
        LEFT JOIN dental_rule_tab d ON (d.cdt_code = tamd.activity_code)
        LEFT JOIN tpa_hosp_info hi ON (thtd.hosp_seq_id=hi.hosp_seq_id)
        JOIN tpa_general_code tg ON (tg.general_type_id = thtd.network_type)
        WHERE thtd.hosp_seq_id=pat_rec.hosp_seq_id
        AND thtd.ins_seq_id=v_tariff_ins_seq_id
        --AND thtd.network_type= v_product_network_type--pat_rec.product_cat_type_id
        --AND v_activity_date BETWEEN  thtd.start_date AND NVL(thtd.end_date,v_activity_date)
        AND tamd.activity_code = upper(v_activity_code)
        and  UPPER(thtd.network_type)IN (select general_type_id
                                     FROM (select g.general_type_id, g.sort_no, dense_rank() over(order by g.sort_no) r
                                           from tpa_general_code g
                                           where g.header_type = 'PROVIDER_NETWORK'
                                          ) q
       WHERE  q.r >=(select sort_no from tpa_general_code where general_type_id = v_product_network_type))
       and thtd.start_date <= v_activity_date and nvl(thtd.end_date, v_activity_date) >= v_activity_date
       ORDER BY tg.sort_no;
        
     ELSIF v_flag = 'INT' or v_flag='SEARCHOUT' THEN
       
       IF v_flag = 'INT' THEN
         OPEN act_code_cur (pat_rec.hosp_seq_id, v_activity_date, v_product_network_type);
          FETCH act_code_cur INTO v_act_code;
           CLOSE act_code_cur;
         END IF;
       
      IF v_flag='SEARCHOUT'  THEN 
        
       open Get_hosp_tariff_seq_id (v_activity_code,pat_rec.hosp_seq_id, v_product_network_type);
         fetch Get_hosp_tariff_seq_id into v_int_tariff_seq_id ;
           close Get_hosp_tariff_seq_id;
           
        OPEN act_code_cur1 (pat_rec.hosp_seq_id, v_activity_date, v_product_network_type);
          FETCH act_code_cur1 INTO v_act_code;
            CLOSE act_code_cur1;
             
       v_activity_code:= v_int_tariff_seq_id;
       
       END IF;
       
       OPEN v_tariff_result FOR 
         select 
               thtd.gross_amount ,
               thtd.disc_amount,
               --thtd.disc_amount as unit_discount,
               case when tamd.service_seq_id in (14,7) then thtd.gross_amount * thtd.disc_percent / 100 else thtd.disc_amount end as unit_discount,
               thtd.gross_amount * thtd.disc_percent as unit_discount,
               thtd.gross_amount- thtd.disc_amount as disc_gross_amount,
               thtd.bundle_id,
               thtd.package_id,
               thtd.internal_code as internal_code,
               tamd.act_mas_dtl_seq_id as activity_seq_id,
               tamd.activity_code as activity_code,
               tamd.activity_description,
               tatc.activity_type_seq_id,
               tatc.activity_type_id,
               NULL as req_quantity,
               NVL(d.tooth_no_required, 'N') as tooth_requ_yn,
               thtd.internal_desc,
               CASE WHEN hi.hosp_name LIKE 'AL AHLI HOSPITAL%%' THEN 'Y' ELSE 'N' END as al_ahli_yn
               
               
              
               
        from tpa_activity_master_details tamd
        JOIN tpa_activity_type_codes tatc ON (tamd.activity_type_seq_id=tatc.activity_type_seq_id)
        JOIN tpa_hosp_tariff_details thtd ON (tamd.act_mas_dtl_seq_id=thtd.activity_seq_id)
        LEFT JOIN dental_rule_tab d ON (d.cdt_code = tamd.activity_code)
        LEFT JOIN tpa_hosp_info hi ON (hi.hosp_seq_id=thtd.hosp_seq_id)
        JOIN tpa_general_code tg ON (tg.general_type_id = thtd.network_type)
        WHERE thtd.hosp_seq_id=pat_rec.hosp_seq_id
        AND thtd.ins_seq_id=v_tariff_ins_seq_id
        --AND thtd.network_type=v_product_network_type--pat_rec.product_cat_type_id
        --AND v_activity_date BETWEEN  thtd.start_date AND NVL(thtd.end_date,v_activity_date)
        AND UPPER(thtd.hosp_tariff_seq_id) = upper(v_activity_code)
        and  UPPER(thtd.network_type)IN (select general_type_id
                                     FROM (select g.general_type_id, g.sort_no, dense_rank() over(order by g.sort_no) r
                                           from tpa_general_code g
                                           where g.header_type = 'PROVIDER_NETWORK'
                                          ) q
       WHERE  q.r >=(select sort_no from tpa_general_code where general_type_id = v_product_network_type))
       and thtd.start_date <= v_activity_date and nvl(thtd.end_date, v_activity_date) >= v_activity_date
       ORDER BY tg.sort_no;
      
     ELSE
       
       OPEN v_tariff_result FOR
       select 
               thtd.gross_amount ,
               thtd.disc_amount,
               case when tamd.service_seq_id in (14,7) then thtd.gross_amount * thtd.disc_percent / 100 else thtd.disc_amount end as unit_discount,
               thtd.gross_amount- thtd.disc_amount as disc_gross_amount,
               thtd.bundle_id,
               thtd.package_id,
               thtd.internal_code,
               tamd.act_mas_dtl_seq_id as activity_seq_id,
               tamd.activity_code,
               tamd.activity_description,
               tatc.activity_type_seq_id,
               tatc.activity_type_id,
               NULL as req_quantity,
               NVL(d.tooth_no_required, 'N') as tooth_requ_yn,
               thtd.internal_desc,
               CASE WHEN hi.hosp_name LIKE 'AL AHLI HOSPITAL%%' THEN 'Y' ELSE 'N' END as al_ahli_yn
               
              
               
        from tpa_activity_master_details tamd
        JOIN tpa_activity_type_codes tatc ON (tamd.activity_type_seq_id=tatc.activity_type_seq_id)
        JOIN tpa_hosp_tariff_details thtd ON (tamd.act_mas_dtl_seq_id=thtd.activity_seq_id)
        LEFT JOIN dental_rule_tab d ON (d.cdt_code = tamd.activity_code)
        LEFT JOIN tpa_hosp_info hi ON (thtd.hosp_seq_id=hi.hosp_seq_id)
        JOIN tpa_general_code tg ON (tg.general_type_id = thtd.network_type)
        WHERE thtd.hosp_seq_id=pat_rec.hosp_seq_id
        AND thtd.ins_seq_id=v_tariff_ins_seq_id
        --AND thtd.network_type=v_product_network_type--pat_rec.product_cat_type_id
        --AND v_activity_date BETWEEN  thtd.start_date AND NVL(thtd.end_date,v_activity_date)
        AND tamd.activity_code = upper(v_activity_code) or thtd.internal_code=upper(v_activity_code)
        and  UPPER(thtd.network_type)IN (select general_type_id
                                     FROM (select g.general_type_id, g.sort_no, dense_rank() over(order by g.sort_no) r
                                           from tpa_general_code g
                                           where g.header_type = 'PROVIDER_NETWORK'
                                          ) q
       WHERE  q.r >=(select sort_no from tpa_general_code where general_type_id = v_product_network_type))
       and thtd.start_date <= v_activity_date and nvl(thtd.end_date, v_activity_date) >= v_activity_date
       ORDER BY tg.sort_no;
            
      END IF;
   end if;
 ELSIF pat_rec.tariff_type_id='INSR' THEN
   IF v_flag = 'ACT' THEN
     OPEN v_tariff_result FOR
     select thtd.gross_amount,
             thtd.disc_amount,
             thtd.disc_amount as unit_discount,
             thtd.gross_amount- thtd.disc_amount as disc_gross_amount,
             thtd.bundle_id,
             thtd.package_id,
             thtd.internal_code,
             tamd.act_mas_dtl_seq_id as activity_seq_id,
             tamd.activity_code,
             tamd.activity_description,
             tatc.activity_type_seq_id,
             tatc.activity_type_id,
             NULL as req_quantity,
             NVL(d.tooth_no_required, 'N') as tooth_requ_yn,
             NULL AS internal_desc,
             'N' as al_ahli_yn
             
             
      from tpa_activity_master_details tamd
      JOIN tpa_activity_type_codes tatc ON (tamd.activity_type_seq_id=tatc.activity_type_seq_id)
      Join tpa_ins_tariff_details thtd ON (tamd.act_mas_dtl_seq_id=thtd.activity_seq_id)
      LEFT JOIN dental_rule_tab d ON (d.cdt_code = tamd.activity_code)
      WHERE thtd.ins_seq_id=v_tariff_ins_seq_id
      AND thtd.network_type=pat_rec.product_cat_type_id
      AND v_activity_date BETWEEN thtd.start_date AND nvl(thtd.end_date,v_activity_date)
      AND tamd.activity_code = upper(v_activity_code);
      
   ELSIF v_flag = 'INT' THEN
     OPEN v_tariff_result FOR
     select thtd.gross_amount,
             thtd.disc_amount,
             thtd.disc_amount as unit_discount,
             thtd.gross_amount- thtd.disc_amount as disc_gross_amount,
             thtd.bundle_id,
             thtd.package_id,
             thtd.internal_code,
             tamd.act_mas_dtl_seq_id as activity_seq_id,
             tamd.activity_code,
             tamd.activity_description,
             tatc.activity_type_seq_id,
             tatc.activity_type_id,
             NULL as req_quantity,
             NVL(d.tooth_no_required, 'N') as tooth_requ_yn,
             NULL AS internal_desc,
             'N' as al_ahli_yn             
             
      from tpa_activity_master_details tamd
      JOIN tpa_activity_type_codes tatc ON (tamd.activity_type_seq_id=tatc.activity_type_seq_id)
      Join tpa_ins_tariff_details thtd ON (tamd.act_mas_dtl_seq_id=thtd.activity_seq_id)
      LEFT JOIN dental_rule_tab d ON (d.cdt_code = tamd.activity_code)
      WHERE thtd.ins_seq_id=v_tariff_ins_seq_id
      AND thtd.network_type=pat_rec.product_cat_type_id
      AND v_activity_date BETWEEN thtd.start_date AND nvl(thtd.end_date,v_activity_date)
      AND thtd.internal_code = upper(v_activity_code);

   ELSE
     OPEN v_tariff_result FOR
     select thtd.gross_amount,
             thtd.disc_amount,
             thtd.disc_amount as unit_discount,
             thtd.gross_amount- thtd.disc_amount as disc_gross_amount,
             thtd.bundle_id,
             thtd.package_id,
             thtd.internal_code,
             tamd.act_mas_dtl_seq_id as activity_seq_id,
             tamd.activity_code,
             tamd.activity_description,
             tatc.activity_type_seq_id,
             tatc.activity_type_id,
             NULL as req_quantity,
             NVL(d.tooth_no_required, 'N') as tooth_requ_yn,
             NULL AS internal_desc ,
             'N' as al_ahli_yn            
             
      from tpa_activity_master_details tamd
      JOIN tpa_activity_type_codes tatc ON (tamd.activity_type_seq_id=tatc.activity_type_seq_id)
      Join tpa_ins_tariff_details thtd ON (tamd.act_mas_dtl_seq_id=thtd.activity_seq_id)
      LEFT JOIN dental_rule_tab d ON (d.cdt_code = tamd.activity_code)
      WHERE thtd.ins_seq_id=v_tariff_ins_seq_id
      AND thtd.network_type=pat_rec.product_cat_type_id
      AND v_activity_date BETWEEN thtd.start_date AND nvl(thtd.end_date,v_activity_date)
      AND tamd.activity_code = upper(v_activity_code);
   END IF;
   
 ELSIF pat_rec.tariff_type_id='CRPT' THEN

  OPEN v_tariff_result FOR
   select thtd.gross_amount,
           thtd.disc_amount,
           thtd.disc_amount as unit_discount,
           thtd.gross_amount- thtd.disc_amount as disc_gross_amount,
           thtd.bundle_id,
           thtd.package_id,
           thtd.internal_code,
           tamd.activity_code,
           tamd.act_mas_dtl_seq_id as activity_seq_id,
           tamd.activity_description,
           tatc.activity_type_seq_id,
           tatc.activity_type_id,
           NULL as req_quantity,
           NVL(d.tooth_no_required, 'N') as tooth_req_yn,
           NULL AS internal_desc,
           'N' as al_ahli_yn          

    from tpa_activity_master_details tamd
    JOIN tpa_activity_type_codes tatc ON (tamd.activity_type_seq_id=tatc.activity_type_seq_id)
    JOIN tpa_corp_tariff_details thtd ON (tamd.act_mas_dtl_seq_id=thtd.activity_seq_id) 
    LEFT JOIN dental_rule_tab d ON (d.cdt_code = tamd.activity_code)
    WHERE thtd.group_reg_seq_id=pat_rec.group_reg_seq_id
    AND thtd.network_type=pat_rec.product_cat_type_id
    AND v_activity_date BETWEEN thtd.start_date AND nvl(thtd.end_date,v_activity_date)
    AND thtd.internal_code = upper(v_activity_code);
  ELSE 
   OPEN v_tariff_result FOR
   select  NULL AS gross_amount,
           NULL AS disc_amount,
           NULL AS unit_discount,
           NULL AS  disc_gross_amount,
           NULL AS bundle_id,
           NULL AS package_id,
           NULL AS internal_code,
           NULL as req_quantity,
           NVL(d.tooth_no_required, 'N') as tooth_requ_yn,
           NULL AS internal_desc,
           'N' as al_ahli_yn
           
    from tpa_activity_master_details tamd 
    JOIN tpa_activity_type_codes tatc ON (tamd.activity_type_seq_id=tatc.activity_type_seq_id)
    LEFT JOIN dental_rule_tab d ON (d.cdt_code = tamd.activity_code)
    WHERE tamd.activity_code=upper(v_activity_code);

 END IF;
 ELSE 
   
  IF pat_rec.claim_type='CTM' AND v_flag='INT' THEN
    
   OPEN mem_act_code_cur(pat_rec.hosp_seq_id);
     FETCH mem_act_code_cur INTO v_act_code;
       CLOSE mem_act_code_cur;
       
    v_product_network_type:=provider_rec.network_type;  
       
  END IF;
   
   IF pat_rec.benifit_type = 'CB' THEN
     v_prod_policy_rule_seq_id:=authorization_pkg.get_prod_pol_seq_id(v_seq_id,'CLM');
     OPEN  cur_cb_dtl;
     FETCH cur_cb_dtl INTO rec_cb_dtl;
     CLOSE cur_cb_dtl;
     
     SELECT COUNT(1) INTO v_act_cnt
     FROM clm_authorization_details ca
     JOIN pat_activity_details a ON (ca.claim_seq_id=a.claim_seq_id)
     JOIN tpa_activity_details t ON (a.code=t.activity_code)
    WHERE ca.claim_seq_id = v_seq_id
      AND t.master_activity_code = 'CBF';
     
     IF v_act_cnt > 0 THEN 
          raise_application_error(-20406,'Activity code already added.');
     END IF; 

    
     IF rec_cb_dtl.coverage_pay_val = 3 AND rec_cb_dtl.cond_fun IS NOT NULL THEN 
          v_perday_cb_amnt:= rec_cb_dtl.amount;
     ELSE
          v_perday_cb_amnt:=0;   
     END IF;
        
     OPEN v_tariff_result FOR 
     select 
           CASE WHEN pat_rec.benifit_type = 'CB' THEN (v_perday_cb_amnt) ELSE NULL END as unit_price ,---UNIT PRICE
           CASE WHEN pat_rec.benifit_type = 'CB' THEN (v_perday_cb_amnt * pat_rec.hosp_days) ELSE NULL END as gross_amount ,
           CASE WHEN pat_rec.benifit_type = 'CB' AND NVL(v_act_cnt,0) = 0 THEN pat_rec.hosp_days ELSE NULL END as req_quantity,
           CASE WHEN pat_rec.benifit_type = 'CB' THEN (v_perday_cb_amnt) ELSE 0 END * pat_rec.conversion_rate as conv_unit_price,
           null as disc_amount,
           null as unit_discount,
           null as  disc_gross_amount,
           null as bundle_id,
           null as package_id,
           null as internal_code,
           NULL as  activity_seq_id,
           NULL as activity_code,
           NULL as activity_description,
           NULL as activity_type_seq_id,
           NULL as activity_type_id,
           NULL as internal_desc,
           'N' as al_ahli_yn
           
    from tpa_activity_master_details tamd
    JOIN tpa_activity_type_codes tatc ON (tamd.activity_type_seq_id=tatc.activity_type_seq_id)
    WHERE tamd.activity_code=upper(v_activity_code)
      AND tamd.activity_code = 'CBF';
    
   ELSE
   
   OPEN v_tariff_result FOR 
     select 
           NULL as gross_amount ,
           null as disc_amount,
           null as unit_discount,
           NULL as  disc_gross_amount,
           null as bundle_id,
           null as package_id,
           null as internal_code,
           NULL as  activity_seq_id,
           NULL as activity_code,
           NULL as activity_description,
           NULL as activity_type_seq_id,
           NULL as activity_type_id,
           NULL as req_quantity,
           NVL(d.tooth_no_required, 'N') as tooth_req_yn,
           NULL as internal_desc,
           'N' as al_ahli_yn
           
    from tpa_activity_master_details tamd
    JOIN tpa_activity_type_codes tatc ON (tamd.activity_type_seq_id=tatc.activity_type_seq_id)
    LEFT JOIN dental_rule_tab d ON (d.cdt_code = tamd.activity_code)
    WHERE tamd.activity_code=upper(v_activity_code);
  END IF;
 END IF;
IF pat_rec.benifit_type = 'CB' THEN
   OPEN v_act_result FOR
   select  tamd.act_mas_dtl_seq_id as activity_seq_id,
           tamd.activity_code,
           tamd.activity_description,
           tatc.activity_type_seq_id,
           tatc.activity_type_id,
           case when (v_mode='PAT' or pat_rec.claim_type='CNH') then case when( nvl(v_count,0)>0 or tatc.activity_type_id in (5)and pat_rec.network_yn='Y') then 'Y' else 'N' end  end as tariff_yn,
           case when (v_mode='PAT' or pat_rec.claim_type='CNH') then case when (nvl(v_count,0)=0 and tatc.activity_type_id not in (4,5)) then 'Tariff rates are not agreed for this item' end end as activity_tariff_status,
           NULL as internal_desc,
           'N' as al_ahli_yn,
           NULL AS tooth_req_yn
    
    from tpa_activity_master_details tamd 
    JOIN tpa_activity_type_codes tatc ON (tamd.activity_type_seq_id=tatc.activity_type_seq_id)
    WHERE  tamd.activity_code = upper(v_activity_code)
       AND tamd.activity_code = 'CBF';
ELSE
  
 if length(v_activity_code)>15 AND v_tra_pharma_cnt = 0 then 
  if v_count>0 then
  OPEN v_act_result FOR
   select  md.act_mas_dtl_seq_id as activity_seq_id,
           md.activity_code,
           md.activity_description,
           tatc.activity_type_seq_id,
           tatc.activity_type_id,
           case when (v_mode='PAT' or pat_rec.claim_type='CNH') then case when( nvl(v_count,0)>0 or (tatc.activity_type_id in (5)and pat_rec.network_yn='Y')) then 'Y' else 'N' end  end as tariff_yn,
           case when (v_mode='PAT' or pat_rec.claim_type='CNH') then case when (nvl(v_count,0)=0) then 'Drug Discontinued,Service not covered' end end as activity_tariff_status,
           NVL(d.tooth_no_required, 'N') as tooth_req_yn,
           NULL as internal_desc,
           'N' as al_ahli_yn
           
    from tpa_activity_type_codes tatc
    left outer join tpa_pharmacy_master_details md on (md.activity_type_seq_id=tatc.activity_type_seq_id)
    LEFT JOIN dental_rule_tab d ON (d.cdt_code = md.activity_code)
    WHERE md.activity_code =upper(v_activity_code)  
    AND md.start_date <= v_activity_date and nvl(md.end_date,v_activity_date) >=v_activity_date;
    
  else 
  OPEN v_act_result FOR
   select  md.act_mas_dtl_seq_id as activity_seq_id,
           md.activity_code,
           md.activity_description,
           tatc.activity_type_seq_id,
           tatc.activity_type_id,
           case when (v_mode='PAT' or pat_rec.claim_type='CNH') then case when( nvl(v_count,0)>0 or (tatc.activity_type_id in (5)and pat_rec.network_yn='Y')) then 'Y' else 'N' end  end as tariff_yn,
           case when (v_mode='PAT' or pat_rec.claim_type='CNH') then case when (nvl(v_count,0)=0) then 'Drug Discontinued,Service not covered' end end as activity_tariff_status,
           NVL(d.tooth_no_required, 'N') as tooth_req_yn,
           NULL as internal_desc,
           'N' as al_ahli_yn
           
    from tpa_activity_type_codes tatc
    left outer join tpa_pharmacy_master_details md on (md.activity_type_seq_id=tatc.activity_type_seq_id)
    LEFT JOIN dental_rule_tab d ON (d.cdt_code = md.activity_code)
    WHERE md.activity_code =upper(v_activity_code);
    end if;
   else
     IF v_flag = 'INT' or v_flag='SEARCHOUT' THEN
       v_activity_code := v_act_code;
       
      OPEN v_act_result FOR
      select  tamd.act_mas_dtl_seq_id as activity_seq_id,
               tamd.activity_code,
               tamd.activity_description,
               tatc.activity_type_seq_id,
               tatc.activity_type_id,
               case when (v_mode='PAT' or pat_rec.claim_type='CNH') then case when( nvl(v_count,0)>0 or tatc.activity_type_id in (5)and pat_rec.network_yn='Y') then 'Y' else 'N' end  end as tariff_yn,
               case when (v_mode='PAT' or pat_rec.claim_type='CNH') then case when (nvl(v_count,0)=0 and tatc.activity_type_id not in (4,5)) then 'Tariff rates are not agreed for this item' end end as activity_tariff_status,
               NVL(d.tooth_no_required, 'N') as tooth_req_yn,
               NULL as internal_desc,
               CASE WHEN hi.hosp_name LIKE 'AL AHLI HOSPITAL%%' THEN 'Y' ELSE 'N' END as al_ahli_yn
    
    from tpa_activity_master_details tamd 
    JOIN tpa_hosp_tariff_details thtd ON (tamd.act_mas_dtl_seq_id=thtd.activity_seq_id)
    JOIN tpa_activity_type_codes tatc ON (tamd.activity_type_seq_id=tatc.activity_type_seq_id)
    LEFT JOIN dental_rule_tab d ON (d.cdt_code = tamd.activity_code)
    LEFT JOIN tpa_hosp_info hi ON (thtd.hosp_seq_id=hi.hosp_seq_id)
    JOIN tpa_general_code tg ON (tg.general_type_id = thtd.network_type)
    WHERE tamd.activity_code= upper(v_activity_code) 
    --and thtd.network_type=v_product_network_type;
    AND  UPPER(thtd.network_type)IN (select general_type_id
                                     FROM (select g.general_type_id, g.sort_no, dense_rank() over(order by g.sort_no) r
                                           from tpa_general_code g
                                           where g.header_type = 'PROVIDER_NETWORK'
                                          ) q
       WHERE  q.r >=(select sort_no from tpa_general_code where general_type_id = v_product_network_type))
       ORDER BY tg.sort_no;
    
     ELSIF v_flag = 'ACT' THEN
       v_activity_code := v_activity_code;
      
      OPEN v_act_result FOR
           select  tamd.act_mas_dtl_seq_id as activity_seq_id,
                   tamd.activity_code,
                   tamd.activity_description,
                   tatc.activity_type_seq_id,
                   tatc.activity_type_id,
                   case when (v_mode='PAT' or pat_rec.claim_type='CNH') then case when( nvl(v_count,0)>0 or tatc.activity_type_id in (5)and pat_rec.network_yn='Y') then 'Y' else 'N' end  end as tariff_yn,
                   case when (v_mode='PAT' or pat_rec.claim_type='CNH') then case when (nvl(v_count,0)=0 and tatc.activity_type_id not in (4,5)) then 'Tariff rates are not agreed for this item' end end as activity_tariff_status,
                   NVL(d.tooth_no_required, 'N') as tooth_req_yn,
                   NULL as internal_desc,
                  /* CASE WHEN hi.hosp_name LIKE 'AL AHLI HOSPITAL%%' THEN 'Y' ELSE 'N' END*/ null as al_ahli_yn
            
            from tpa_activity_master_details tamd 
            --JOIN tpa_hosp_tariff_details thtd ON (tamd.act_mas_dtl_seq_id=thtd.activity_seq_id)
            JOIN tpa_activity_type_codes tatc ON (tamd.activity_type_seq_id=tatc.activity_type_seq_id)
            LEFT JOIN dental_rule_tab d ON (d.cdt_code = tamd.activity_code)
           -- LEFT JOIN tpa_hosp_info hi ON (thtd.hosp_seq_id=hi.hosp_seq_id)
            WHERE  tamd.activity_code = upper(v_activity_code);
            
     ELSIF v_flag = 'MSTR' THEN
       v_activity_code := v_activity_code;
      
      OPEN v_act_result FOR
           select  m.act_mas_dtl_seq_id as activity_seq_id,
                   m.activity_code,
                   m.activity_description,
                   t.activity_type_seq_id,
                   t.activity_type_id,
                   NULL as tariff_yn,
                   NULL as activity_tariff_status,
                   NVL(d.tooth_no_required, 'N') as tooth_req_yn,
                   NULL as internal_desc,
                  /* CASE WHEN hi.hosp_name LIKE 'AL AHLI HOSPITAL%%' THEN 'Y' ELSE 'N' END*/ null as al_ahli_yn
            
            from tpa_activity_master_details m 
            JOIN tpa_activity_type_codes t ON (m.activity_type_seq_id=t.activity_type_seq_id)
            LEFT JOIN dental_rule_tab d ON (d.cdt_code = m.activity_code)
            WHERE  m.activity_code = upper(v_activity_code);
            
     END IF;
 

    
   end if; 
END IF;   
END select_activity_code;

--====================================================================================
PROCEDURE delete_diagnosys_details(v_seq_id             IN pat_authorization_details.pat_auth_seq_id%TYPE,
                                   v_diag_seq_id        IN diagnosys_details.diag_seq_id%type,
                                   v_mode               IN VARCHAR2,
                                   v_added_by           IN NUMBER,
                                   v_rows_processed     OUT NUMBER) IS
CURSOR pat_diag_cur IS
SELECT pad.pat_status_type_id,pad.completed_yn
FROM pat_authorization_details pad
WHERE pad.pat_auth_seq_id = v_seq_id;

CURSOR clm_diag_cur IS
SELECT pad.clm_status_type_id,pad.completed_yn
FROM clm_authorization_details pad
WHERE pad.claim_seq_id = v_seq_id;

pat_rec           pat_diag_cur%ROWTYPE;       
clm_rec           clm_diag_cur%ROWTYPE; 
v_dummy           NUMBER;      

BEGIN

 IF v_mode='PAT' THEN
   
 authorization_pkg.reassign_user('|'||v_seq_id||'|',null,null,v_added_by,null,v_dummy);

   OPEN pat_diag_cur;
   FETCH pat_diag_cur INTO pat_rec;
   CLOSE pat_diag_cur;

   IF pat_rec.Pat_Status_Type_Id IN ('APR','REJ') and pat_rec.Completed_Yn='Y' THEN
     RAISE_APPLICATION_ERROR(-20376,'You cannot delete diagnosis details , Until Preauth/Claim Status is Compleate');
    ELSE
      DELETE FROM diagnosys_details dd 
      WHERE dd.diag_seq_id = v_diag_seq_id;
   END IF;
 ELSIF v_mode='CLM' THEN
   authorization_pkg.reassign_user(null,'|'||v_seq_id||'|',null,v_added_by,null,v_dummy);

   OPEN clm_diag_cur;
   FETCH clm_diag_cur INTO clm_rec;
   CLOSE clm_diag_cur;

   IF clm_rec.clm_status_type_id  IN ('APR','REJ') and clm_rec.Completed_Yn='Y' THEN
     RAISE_APPLICATION_ERROR(-20376,'You cannot delete diagnosis details , Until Preauth/Claim Status is Compleate');
    ELSE
      DELETE FROM diagnosys_details dd 
      WHERE dd.diag_seq_id = v_diag_seq_id;
   END IF;

 END IF; 

 v_rows_processed := SQL%ROWCOUNT;

 COMMIT;
END delete_diagnosys_details;

--====================================================================================
PROCEDURE check_pat_approved(v_pat_auth_seq_id      IN pat_authorization_details.pat_auth_seq_id%TYPE,                      
                             v_added_by             IN NUMBER)
IS

CURSOR mem_cur(v_member_seq_id  IN tpa_enr_policy_member.Member_Seq_Id%TYPE)
 IS 
  SELECT 
         tepm.date_of_inception,
         tepm.date_of_exit,
         tepm.mem_name,
         tepm.mem_age,
         tepg.policy_group_seq_id,
         tepg.policy_seq_id,
         tepm.member_seq_id,
         tep.policy_sub_general_type_id
  FROM tpa_enr_policy_member tepm
  JOIN tpa_enr_policy_group tepg  ON (tepm.policy_group_seq_id=tepg.policy_group_seq_id)
  JOIN tpa_enr_policy tep ON (tepg.policy_seq_id=tep.policy_seq_id)
  WHERE tepm.Member_Seq_Id=v_member_seq_id;

  CURSOR pat_cur IS
  SELECT pad.hospitalization_date ,pad.final_app_amount,pad.pat_status_type_id,
  pad.member_seq_id,pad.policy_seq_id
  FROM pat_authorization_details pad
  WHERE  pad.pat_auth_seq_id=v_pat_auth_seq_id;

   pat_rec         pat_cur%ROWTYPE;
   mem_rec         mem_cur%ROWTYPE;

   CURSOR shortfall_count IS 
   SELECT COUNT(1)  FROM APP.shortfall_details s where 
   s.srtfll_status_general_type_id='OPN' and s.pat_gen_detail_seq_id=v_pat_auth_seq_id ;
   V_shortfall_count  number;

BEGIN

  OPEN pat_cur;
  FETCH pat_cur INTO pat_rec;
  CLOSE pat_cur;

  OPEN mem_cur(pat_rec.Member_Seq_Id);
  FETCH mem_cur INTO mem_rec;
  CLOSE mem_cur;

  open shortfall_count;
  fetch shortfall_count into V_shortfall_count;
  close shortfall_count; 

 /*IF pat_rec.Pat_Status_Type_Id='APR' THEN

  IF mem_rec.policy_sub_general_type_id='PFL' THEN    
   UPDATE tpa_enr_balance b
   SET b.utilised_sum_insured = b.utilised_sum_insured - nvl(pat_rec.final_app_amount,0),
       b.updated_by           = v_added_by,
       b.updated_date         = SYSDATE
   WHERE b.policy_group_seq_id = mem_rec.policy_group_seq_id;
  ELSIF mem_rec.policy_sub_general_type_id='PNF' THEN  
  UPDATE tpa_enr_balance b
   SET b.utilised_sum_insured = b.utilised_sum_insured - nvl(pat_rec.final_app_amount,0),
       b.updated_by           = v_added_by,
       b.updated_date         = SYSDATE
   WHERE b.member_seq_id = mem_rec.member_seq_id; 
  END IF;

 END IF;*/

 UPDATE pat_authorization_details pad
 SET pad.completed_yn='N',
     pad.pat_status_type_id= case when nvl(V_shortfall_count,0)>0 then 'REQ' else 'INP' end ,
     pad.final_app_amount=0
 WHERE pad.pat_auth_seq_id=v_pat_auth_seq_id;  

END check_pat_approved;                             

--====================================================================================
PROCEDURE delete_preauth(v_pat_auth_seq_ids             IN VARCHAR2,
                         v_added_by                    IN NUMBER,
                         v_rows_processed              OUT NUMBER)
 IS

 CURSOR pat_cur(v_pat_auth_seq_id IN pat_authorization_details.Pat_Auth_Seq_Id%TYPE) IS
 SELECT pad.pat_auth_seq_id,
        pad.parent_pat_auth_seq_id,
        pad.pat_enhanced_yn,
        pad.final_app_amount,
        pad.pat_status_type_id,
        pad.completed_yn
  FROM pat_authorization_details pad
 WHERE pad.pat_auth_seq_id=v_pat_auth_seq_id;

 pat_rec               pat_cur%ROWTYPE;
 str_tab               ttk_util_pkg.str_table_type;

 BEGIN

  str_tab:=ttk_util_pkg.parse_str(v_pat_auth_seq_ids);

  FOR i in str_tab.first..str_tab.last loop

   OPEN pat_cur(str_tab(i));
   FETCH pat_cur INTO pat_rec;   
   CLOSE pat_cur;

  IF pat_rec.pat_status_type_id='APR' THEN
     RAISE_APPLICATION_ERROR(-20375,'You Cannot delete Approved Preauth, Please change the status to In-Progress/Rejected');
  ELSE
   DELETE FROM  pat_observation_details pod WHERE EXISTS (Select 1 FROM pat_activity_details pad WHERE pad.pat_auth_seq_id=str_tab(i) AND pod.activity_dtl_seq_id=pad.activity_dtl_seq_id);
   DELETE FROM  pat_activity_details pad WHERE pad.pat_auth_seq_id=str_tab(i);
   DELETE FROM  diagnosys_details dd WHERE dd.pat_auth_seq_id=str_tab(i);
   DELETE FROM  pat_authorization_details pad WHERE pad.pat_auth_seq_id=str_tab(i);

   UPDATE pat_authorization_details pad 
    SET pad.pat_status_type_id='INP',
        pad.pat_enhanced_yn='N'
   WHERE pad.pat_auth_seq_id=pat_rec.parent_pat_auth_seq_id;

  END IF;
 END LOOP;
 v_rows_processed:=SQL%ROWCOUNT;
 COMMIT;
 END delete_preauth;                         
--====================================================================================
PROCEDURE delete_activity_details(v_seq_id                       IN pat_authorization_details.pat_auth_seq_id%TYPE,
                                  v_activity_dtl_seq_id          IN pat_activity_details.activity_dtl_seq_id%type,
                                  v_mode                         IN VARCHAR2,
                                  v_added_by                     IN NUMBER ,
                                  v_rows_processed               OUT NUMBER
                                  ) 
IS
CURSOR pat_act_cur IS
SELECT pad.pat_status_type_id,pad.completed_yn,ad.gross_amount,ad.discount_amount,ad.disc_gross_amount,ad.patient_share_amount,
ad.net_amount,ad.allowed_amount,ad.approved_amount
FROM pat_authorization_details pad join pat_activity_details ad on (pad.pat_auth_seq_id=ad.pat_auth_seq_id)
WHERE pad.pat_auth_seq_id = v_seq_id and ad.activity_dtl_seq_id=v_activity_dtl_seq_id;

CURSOR clm_act_cur IS
SELECT pad.clm_status_type_id,pad.completed_yn,ad.gross_amount,ad.discount_amount,ad.disc_gross_amount,ad.patient_share_amount,
ad.net_amount,ad.allowed_amount,ad.approved_amount
FROM clm_authorization_details pad join pat_activity_details ad on (pad.claim_seq_id=ad.claim_seq_id)
WHERE pad.claim_seq_id = v_seq_id and ad.activity_dtl_seq_id=v_activity_dtl_seq_id;


pat_rec           pat_act_cur%ROWTYPE;       
clm_rec           clm_act_cur%ROWTYPE;
v_dummy           NUMBER;       

BEGIN

 IF v_mode='PAT' THEN
   
 authorization_pkg.reassign_user('|'||v_seq_id||'|',null,null,v_added_by,null,v_dummy);

   OPEN pat_act_cur;
   FETCH pat_act_cur INTO pat_rec;
   CLOSE pat_act_cur;

   IF pat_rec.Pat_Status_Type_Id IN ('APR','REJ') and pat_rec.Completed_Yn='Y' THEN
     RAISE_APPLICATION_ERROR(-20377,'You cannot delete Activity details , Until Preauth/Claim Status is Complete');
    ELSE
      update pat_authorization_details ad 
      set ad.tot_gross_amount         = nvl(ad.tot_gross_amount,0)-nvl(pat_rec.gross_amount,0),
          ad.tot_discount_amount      = nvl(ad.tot_discount_amount,0)-nvl(pat_rec.discount_amount,0),
          ad.tot_disc_gross_amount    = nvl(ad.tot_disc_gross_amount,0)-nvl(pat_rec.disc_gross_amount,0),
          ad.tot_patient_share_amount = nvl(ad.tot_patient_share_amount,0)-nvl(pat_rec.patient_share_amount,0),
          ad.tot_net_amount           = nvl(ad.tot_net_amount,0)-nvl(pat_rec.net_amount,0),
          ad.tot_allowed_amount       = nvl(ad.tot_allowed_amount,0)-nvl(pat_rec.allowed_amount,0),
          ad.tot_approved_amount      = nvl(ad.tot_approved_amount,0)-nvl(pat_rec.approved_amount,0) 
        where ad.pat_auth_seq_id=v_seq_id;
       
      DELETE FROM pat_observation_details pod WHERE pod.activity_dtl_seq_id=v_activity_dtl_seq_id;
      DELETE FROM pat_activity_details pad
      WHERE pad.activity_dtl_seq_id=v_activity_dtl_seq_id;
   END IF;
 ELSIF v_mode='CLM' THEN
   
 authorization_pkg.reassign_user(null,'|'||v_seq_id||'|',null,v_added_by,null,v_dummy);

   OPEN clm_act_cur;
   FETCH clm_act_cur INTO clm_rec;
   CLOSE clm_act_cur;

   IF clm_rec.clm_status_type_id  IN ('APR','REJ') and clm_rec.Completed_Yn='Y' THEN
     RAISE_APPLICATION_ERROR(-20377,'You cannot delete Activity details , Until Preauth/Claim Status is Complete');
    ELSE
      update clm_authorization_details ad 
      set ad.tot_gross_amount         = nvl(ad.tot_gross_amount,0)-nvl(pat_rec.gross_amount,0),
          ad.tot_discount_amount      = nvl(ad.tot_discount_amount,0)-nvl(pat_rec.discount_amount,0),
          ad.tot_disc_gross_amount    = nvl(ad.tot_disc_gross_amount,0)-nvl(pat_rec.disc_gross_amount,0),
          ad.tot_patient_share_amount = nvl(ad.tot_patient_share_amount,0)-nvl(pat_rec.patient_share_amount,0),
          ad.tot_net_amount           = nvl(ad.tot_net_amount,0)-nvl(pat_rec.net_amount,0),
          ad.tot_allowed_amount       = nvl(ad.tot_allowed_amount,0)-nvl(pat_rec.allowed_amount,0),
          ad.tot_approved_amount      = nvl(ad.tot_approved_amount,0)-nvl(pat_rec.approved_amount,0) 
        where ad.claim_seq_id = v_seq_id;

      DELETE FROM pat_observation_details pod WHERE pod.activity_dtl_seq_id=v_activity_dtl_seq_id;  
      DELETE FROM pat_activity_details pad
      WHERE pad.activity_dtl_seq_id=v_activity_dtl_seq_id;
   END IF;

 END IF;  

  v_rows_processed:=SQL%ROWCOUNT;
  COMMIT;
END delete_activity_details;
--====================================================================================
PROCEDURE delete_observation_details(v_seq_ids                       IN VARCHAR2,
                                     v_seq_id                        IN pat_authorization_details.pat_auth_seq_id%type,
                                     v_mode                         IN VARCHAR2,
                                     v_rows_processed               OUT NUMBER) 
IS
CURSOR pat_cur IS
SELECT pad.pat_status_type_id,pad.completed_yn
FROM pat_authorization_details pad
WHERE pad.pat_auth_seq_id = v_seq_id;

CURSOR clm_cur IS
SELECT pad.clm_status_type_id,pad.completed_yn
FROM clm_authorization_details pad
WHERE pad.claim_seq_id = v_seq_id;

pat_rec           pat_cur%ROWTYPE;       
clm_rec           clm_cur%ROWTYPE; 

str_tab           ttk_util_pkg.str_table_type;

BEGIN

  str_tab:=ttk_util_pkg.parse_str(v_seq_ids);

 IF v_mode='PAT' THEN
   FOR i IN str_tab.FIRST..str_tab.LAST LOOP

   OPEN pat_cur;
   FETCH pat_cur INTO pat_rec;
   CLOSE pat_cur;

   IF pat_rec.Pat_Status_Type_Id IN ('APR','REJ') and pat_rec.Completed_Yn='Y' THEN
     RAISE_APPLICATION_ERROR(-20378,'You cannot delete Observation details , Until Preauth/Claim Status is Complete');
    ELSE
      DELETE FROM pat_observation_details pod
      WHERE pod.observation_seq_id=str_tab(i);
   END IF;
  END LOOP;
 ELSIF v_mode='CLM' THEN
  FOR i IN str_tab.FIRST..str_tab.LAST LOOP
   OPEN clm_cur;
   FETCH clm_cur INTO clm_rec;
   CLOSE clm_cur;

   IF clm_rec.clm_status_type_id  IN ('APR','REJ') and pat_rec.Completed_Yn='Y' THEN
     RAISE_APPLICATION_ERROR(-20378,'You cannot delete Observation details , Until Preauth/Claim Status is Complete');
    ELSE
      DELETE FROM pat_observation_details pod
      WHERE pod.observation_seq_id=str_tab(i);
   END IF;
  END LOOP;
 END IF;  

  v_rows_processed:=SQL%ROWCOUNT;
  COMMIT;

END delete_observation_details;
--====================================================================================
PROCEDURE save_shortfall_details(v_shortfall_seq_id       IN OUT SHORTFALL_DETAILS.shortfall_seq_id%TYPE,
                                 v_pat_auth_seq_id        IN SHORTFALL_DETAILS.pat_gen_detail_seq_id%TYPE,
                                 v_claim_seq_id           IN SHORTFALL_DETAILS.claim_seq_id%TYPE,
                                 v_srtfll_general_type_id IN SHORTFALL_DETAILS.srtfll_general_type_id%TYPE,
                                 v_status_general_type_id IN SHORTFALL_DETAILS.srtfll_status_general_type_id%TYPE,
                                 v_reason_general_type_id IN SHORTFALL_DETAILS.srtfll_reason_general_type_id%TYPE,
                                 v_remarks                IN SHORTFALL_DETAILS.remarks%TYPE,
                                 v_srtfll_received_date   IN SHORTFALL_DETAILS.srtfll_received_date%TYPE,
                                 v_shortfall_questions    IN SHORTFALL_DETAILS.shortfall_questions%TYPE, -- new column
                                 v_correspondence_date    IN SHORTFALL_REMINDER_LOG.reminder_date%TYPE, -- new column
                                 v_new_correspondence_yn  IN OUT CHAR,
                                 v_selection_type         IN VARCHAR2, --SENT OR SAVE
                                 v_template_type          IN VARCHAR2,
                                 v_added_by               IN SHORTFALL_DETAILS.added_by%TYPE,
                                 v_received_yn            IN VARCHAR2,
                                 --v_file_name              IN SHORTFALL_DETAILS.FILE_NAME%TYPE,
                                 v_rows_processed         IN OUT NUMBER) IS
  CURSOR prev_cur IS
    SELECT srtfll_general_type_id,
           srtfll_status_general_type_id,
           reminder_count
      FROM shortfall_details
     WHERE shortfall_seq_id = v_shortfall_seq_id;

  v_dest_msg_seq_id      VARCHAR2(20);

  v_assign_users_seq_id assign_users.assign_users_seq_id%TYPE;
  prev_rec              prev_cur%ROWTYPE;
  v_shortfall_id        SHORTFALL_DETAILS.shortfall_id%TYPE;
  v_check_status        CHAR(3) := 'NON';

  CURSOR pat_cur IS
    SELECT a.pre_auth_number AS gen_number,a.completed_yn,trunc(a.added_date) added_date, trunc(a.discharge_date) discharge_date --, b.auth_number , a.pat_enroll_detail_seq_id AS seq_id, b.tpa_enrollment_id , b.policy_number, b.policy_seq_id ,a.pre_auth_dms_reference_id AS dms_reference_id
           , null as claim_type
      FROM pat_authorization_details A
     WHERE a.pat_auth_seq_id = v_pat_auth_seq_id;

  CURSOR clm_cur IS
    SELECT a.claim_number AS gen_number,a.completed_yn, trunc(a.added_date) added_date, to_date(a.date_of_discharge) discharge_date, a.claim_type 
      FROM clm_authorization_details A
      WHERE a.claim_seq_id = v_claim_seq_id;

  CURSOR reminder_cur IS
    SELECT a.max_preauth_reminder_count, a.max_claim_reminder_count
      FROM tpa_system_parameters a;


  reminder_rec         reminder_cur%ROWTYPE;
  pat_rec              pat_cur%ROWTYPE;
  v_mode               CHAR(1) := 'I';
  v_ctr                NUMBER(3);
  v_srtfll_sent_date   shortfall_details.srtfll_sent_date%TYPE;
  v_srtfll_type        VARCHAR2(3);
  v_log_yn             CHAR(1) := 'N';
  v_closed_yn          CHAR(1) := 'N';
  v_max_count          NUMBER(3);
  v_pat_log_seq_id     pat_log.pat_log_seq_id%TYPE;
  v_shrtfall_questions SHORTFALL_DETAILS.shortfall_questions%TYPE; 
  v_count             number(10);
  v_seq_id            NUMBER(10);
BEGIN
  
 
if nvl(v_pat_auth_seq_id,0)!=0  then
authorization_pkg.reassign_user('|'||v_pat_auth_seq_id||'|',null,null,v_added_by,null,v_seq_id);
else
authorization_pkg.reassign_user(null,'|'||v_claim_seq_id||'|',null,v_added_by,null,v_seq_id);
end if;
  
  v_shrtfall_questions := v_shortfall_questions; 
  --define_rule_pkg.pr_wsp_shortfall(v_shrtfall_questions);


  IF v_selection_type = 'SENT' OR v_new_correspondence_yn = 'Y' THEN
    v_srtfll_sent_date := NVL(v_correspondence_date,
                              to_date(to_char(SYSDATE, 'dd/mm/yyyy hh:mi am'),
                                      'dd/mm/yyyy hh:mi am'));
    --v_srtfll_reminder_log_seq_id := NULL;
    v_new_correspondence_yn := 'Y';
    v_log_yn                := 'Y';
    IF v_correspondence_date IS NOT NULL AND
       nvl(v_shortfall_seq_id, 0) != 0 THEN
      SELECT COUNT(1)
        INTO v_ctr
        FROM shortfall_reminder_log a
       WHERE a.shortfall_seq_id = v_shortfall_seq_id
         AND a.reminder_date < v_correspondence_date
         AND A.shortfall_seq_id != v_shortfall_seq_id;
      IF v_ctr > 0 THEN
        raise_application_error(-20761,
                                'Reminder date should be greater than that of previous reminders');
      END IF;
    END IF;
  END IF;

  IF nvl(v_received_yn,'N')='Y' THEN 
    v_log_yn :='N';
  END IF;
  IF v_log_yn = 'Y' THEN
    OPEN reminder_cur;
    FETCH reminder_cur
      INTO reminder_rec;
    CLOSE reminder_cur;
    IF v_pat_auth_seq_id IS NOT NULL THEN
      v_max_count := reminder_rec.max_preauth_reminder_count;
    ELSE
      v_max_count := reminder_rec.max_claim_reminder_count;
    END IF;
  END IF;
  if v_pat_auth_seq_id is not null then 
  OPEN pat_cur;
  FETCH pat_cur INTO pat_rec;
  CLOSE pat_cur;
  else 
   OPEN clm_cur;
   FETCH clm_cur INTO pat_rec;
   CLOSE clm_cur;
  end if;
  
  IF v_pat_auth_seq_id IS NOT NULL THEN
    SELECT COUNT(1) INTO V_COUNT FROM APP.shortfall_details s where 
    s.pat_gen_detail_seq_id=v_pat_auth_seq_id and s.srtfll_status_general_type_id='OPN'
    and s.shortfall_seq_id!=v_shortfall_seq_id;
  ELSE
    SELECT COUNT(1) INTO V_COUNT 
    FROM APP.shortfall_details s 
    where s.claim_seq_id= v_claim_seq_id 
    and s.srtfll_status_general_type_id= 'OPN'
    and s.shortfall_seq_id != v_shortfall_seq_id;
  END IF;
  
  IF v_count>0 then 
    RAISE_APPLICATION_ERROR(-20385,'Please close the opened shortfall before raise.');
  END IF;

  IF pat_rec.completed_yn='Y' THEN
    RAISE_APPLICATION_ERROR(-20107,'You cannot perform this action through a completed Claim.');
  END IF;
  
  IF (to_date(v_correspondence_date, 'DD/MM/RRRR') < to_date(pat_rec.added_date, 'DD/MM/RRRR')) THEN
    RAISE_APPLICATION_ERROR(-20427,'Correspondence date most be in between Start Date and End Date');
  END IF;
  
  IF NVL(v_shortfall_seq_id,0) = 0 THEN
    INSERT INTO shortfall_details
      (shortfall_seq_id,
       pat_gen_detail_seq_id,
       claim_seq_id,
       shortfall_id,
       srtfll_general_type_id,
       srtfll_sent_date,
       srtfll_status_general_type_id,
       srtfll_reason_general_type_id,
       remarks,
       srtfll_received_date,
       shortfall_questions,
       reminder_count,
       shortfall_raised_by,
       added_by,
       added_date)
    VALUES
      (shortfall_details_seq.NEXTVAL,
       v_pat_auth_seq_id,
       v_claim_seq_id,
       generate_id_numbers('STH', NULL,NULL, pat_rec.gen_number),
       v_srtfll_general_type_id,
       v_srtfll_sent_date,
       v_status_general_type_id,
       v_reason_general_type_id,
       v_remarks,
       v_srtfll_received_date,
       v_shortfall_questions,
       CASE
         WHEN v_log_yn = 'Y' THEN
          1
         ELSE
          NULL
       END,
       v_added_by,
       v_added_by,
       SYSDATE)

    RETURNING shortfall_seq_id, shortfall_id INTO v_shortfall_seq_id, v_shortfall_id;

    IF v_status_general_type_id = 'OPN' THEN
      v_check_status := 'REQ';
    END IF;

  ELSE

    OPEN prev_cur;
    FETCH prev_cur
      INTO prev_rec;
    CLOSE prev_cur;

    --IF prev_rec.srtfll_status_general_type_id != v_status_general_type_id THEN
      IF v_status_general_type_id IN ('CLS', 'ORD') OR (v_received_yn='Y' and v_status_general_type_id='OPN') THEN
        v_closed_yn := 'Y';
        IF v_claim_seq_id IS NOT NULL THEN
          SELECT COUNT(1)
            INTO v_ctr
            FROM shortfall_details a
           WHERE a.claim_seq_id = v_claim_seq_id
             AND a.shortfall_seq_id != v_shortfall_seq_id
             AND a.srtfll_status_general_type_id = 'OPN';
        ELSE
          SELECT COUNT(1)
            INTO v_ctr
            FROM shortfall_details a
           WHERE a.pat_gen_detail_seq_id = v_pat_auth_seq_id
             AND a.shortfall_seq_id != v_shortfall_seq_id
             AND a.srtfll_status_general_type_id = 'OPN';
        END IF;
        IF v_ctr = 0 THEN
          v_check_status := 'INP';
        ELSE
          v_check_status := 'REQ';
        END IF;
      ELSIF v_status_general_type_id = 'OPN' THEN
        v_check_status := 'REQ';
      END IF;
    --END IF;

    IF prev_rec.reminder_count >= v_max_count and nvl(v_received_yn,'N')='N' THEN
      raise_application_error(-20133,
                              'Maximum limit for sending reminder reached.');
    END IF;
   IF (v_received_yn='Y' and v_status_general_type_id='OPN') OR v_status_general_type_id = 'RES' then
    v_check_status:='INP';
   END IF; 
    UPDATE shortfall_details
       SET srtfll_general_type_id        = v_srtfll_general_type_id,
           srtfll_status_general_type_id = CASE WHEN v_received_yn='Y' and v_status_general_type_id='OPN' then 
                                              'CLS' else v_status_general_type_id end,
           srtfll_reason_general_type_id = CASE WHEN v_received_yn='Y' and v_status_general_type_id='OPN' then 
                                              'SH2' else v_reason_general_type_id end,
           remarks                       = v_remarks,
           shortfall_questions           = v_shortfall_questions,
           srtfll_received_date          = CASE WHEN v_closed_yn = 'Y' OR (v_status_general_type_id = 'RES' AND v_received_yn IN ('Y', 'N')) THEN SYSDATE end ,
           srtfll_sent_date = CASE
                                WHEN v_log_yn = 'Y' THEN
                                 v_srtfll_sent_date
                                ELSE
                                 srtfll_sent_date
                              END,
           reminder_count = CASE
                              WHEN v_log_yn = 'Y' THEN
                               NVL(reminder_count, 0) + 1
                              ELSE
                               reminder_count
                            END,
           closed_date = CASE
                           WHEN v_closed_yn = 'Y' THEN
                            SYSDATE
                           WHEN v_status_general_type_id IN ('CLS', 'ORD') THEN
                            closed_date
                           ELSE
                            NULL
                         END,
           updated_by                    = v_added_by,
           updated_date                  = SYSDATE
     WHERE shortfall_seq_id = v_shortfall_seq_id
    RETURNING shortfall_id INTO v_shortfall_id;
    -- Mode Type Flag for XML Generation.
    v_mode := 'U';
    
  END IF;

  IF v_claim_seq_id IS NULL THEN
    v_srtfll_type := 'PAT';
  ELSE
    v_srtfll_type := 'CLM';
  END IF;

  IF v_srtfll_type = 'PAT' THEN
    IF v_status_general_type_id = 'OPN' THEN 
    --IF nvl(v_received_yn,'N')='Y' THEN
      GENERATE_MAIL_PKG.proc_form_message('PREAUTH_SHORTFALL',
                                          v_shortfall_seq_id,
                                          v_added_by,
                                          v_dest_msg_seq_id);
                                          
      GENERATE_MAIL_PKG.proc_generate_message('PREAUTH_SHORTFALL_NHCP',
                                          v_shortfall_seq_id,
                                          v_added_by,
                                          v_dest_msg_seq_id);
                                          
    ELSIF v_status_general_type_id = 'RES' THEN
      GENERATE_MAIL_PKG.proc_generate_message('PREAUTH_SHORTFALL_RECEIVED',
                                          v_shortfall_seq_id,
                                          v_added_by,
                                          v_dest_msg_seq_id);
    END IF;

    ELSIF v_srtfll_type ='CLM' AND pat_rec.claim_type = 'CTM' THEN 
      --IF nvl(v_received_yn,'N')='Y' THEN
      IF v_status_general_type_id = 'OPN' THEN
        GENERATE_MAIL_PKG.proc_generate_message('CLAIM_SHORTFALL_REMINDER',
                                          v_shortfall_seq_id,
                                          v_added_by,
                                          v_dest_msg_seq_id);
                                          
      ELSIF v_status_general_type_id = 'RES' THEN
        GENERATE_MAIL_PKG.proc_generate_message('CLAIM_SHORTFALL',
                                          v_shortfall_seq_id,
                                          v_added_by,
                                          v_dest_msg_seq_id);
     END IF;
   END IF;

  /*IF v_log_yn = 'Y' THEN

  ELSIF prev_rec.srtfll_status_general_type_id != v_status_general_type_id AND
        v_status_general_type_id IN ('CLS', 'RES') THEN
    IF v_claim_seq_id IS NOT NULL THEN
      GENERATE_MAIL_PKG.proc_form_message('CLAIM_SHORTFALL_RECEIVED',
                                          v_shortfall_seq_id,
                                          v_added_by,
                                          v_dest_msg_seq_id);
    ELSE
      GENERATE_MAIL_PKG.proc_form_message('PREAUTH_SHORTFALL_RECEIVED',
                                          v_shortfall_seq_id,
                                          v_added_by,
                                          v_dest_msg_seq_id);
    END IF;
  END IF;*/

  IF v_check_status != 'NON' THEN
    IF v_pat_auth_seq_id IS NOT NULL THEN
      UPDATE pat_authorization_details d
         SET d.pat_status_type_id = v_check_status,
             updated_by           = v_added_by,
             updated_date         = SYSDATE
       WHERE d.pat_auth_seq_id = v_pat_auth_seq_id
         AND pat_status_type_id != v_check_status;

    ELSE
      UPDATE clm_authorization_details a
         SET clm_status_type_id   = v_check_status,
             updated_by                 = v_added_by,
             updated_date               = SYSDATE
       WHERE claim_seq_id = v_claim_seq_id
         AND clm_status_type_id != v_check_status;
    END IF;

  END IF;

  v_rows_processed := SQL%ROWCOUNT;
  /* IF  v_log_yn = 'Y' THEN
     save_shortfall_rem_log(v_srtfll_reminder_log_seq_id,v_shortfall_seq_id ,NVL(v_srtfll_sent_date,SYSDATE)  ,v_added_by );

    UPDATE shortfall_details  A SET
      a.last_reminder_log_seq_id = v_srtfll_reminder_log_seq_id
      WHERE a.shortfall_seq_id = v_shortfall_seq_id ;
  END IF;*/

  COMMIT;
END save_shortfall_details;
--====================================================================================
PROCEDURE select_shortfall_details(v_shortfall_seq_id      IN SHORTFALL_DETAILS.shortfall_seq_id%TYPE,
                                   v_pat_auth_seq_id       IN PAT_AUTHORIZATION_DETAILS.PAT_AUTH_SEQ_ID%TYPE,
                                   v_claim_seq_id          IN SHORTFALL_DETAILS.Claim_Seq_Id%TYPE,
                                   v_added_by              IN NUMBER,
                                   result_set              OUT SYS_REFCURSOR) IS
  v_max_shortfall_seq_id SHORTFALL_DETAILS.shortfall_seq_id%TYPE;

BEGIN
  IF v_pat_auth_seq_id IS NOT NULL THEN
    SELECT MAX(shortfall_seq_id)
      INTO v_max_shortfall_seq_id
      FROM shortfall_details
     WHERE pat_gen_detail_seq_id = v_pat_auth_seq_id;
  ELSE
    SELECT MAX(shortfall_seq_id)
      INTO v_max_shortfall_seq_id
      FROM shortfall_details
     WHERE claim_seq_id = v_claim_seq_id;
  END IF;

  OPEN result_set FOR
    SELECT A.shortfall_seq_id,
           A.shortfall_id,
           A.pat_gen_detail_seq_id,
           D.pre_auth_number,
           D.pat_auth_seq_id,
           d.tpa_enrollment_id as mem_id,
           d.mem_name,
           A.srtfll_general_type_id,
           C.Description AS shortfall_type,
           A.srtfll_status_general_type_id,
           CASE WHEN a.srtfll_status_general_type_id='CLS' then 'Y' else 'N' end as recieved_yn,
           a.srtfll_sent_date,
           a.srtfll_received_date,
           A.remarks,
           A.srtfll_reason_general_type_id,
           A.shortfall_questions,
            CASE
             WHEN (a.shortfall_seq_id = v_max_shortfall_seq_id) THEN
              'Y'
             ELSE
              'N'
           END AS edit_yn,
           nvl(a.reminder_count, 0) AS reminder_count, 
           A.srtfll_sent_date AS correspondence_date, 
           to_char(srtfll_received_date, 'dd/mm/yyyy') as m_correspondence_date,
           f.srtfll_reminder_log_seq_id,
           a.shortfall_raised_for,
           a.clause_seq_id, 
           a.add_clause_number, 
           h.description as shortfal_email_status,
           a.docs_status as provider_responded_yn
           
      FROM shortfall_details A
      JOIN tpa_general_code B
        ON (a.srtfll_general_type_id = b.general_type_id)
      JOIN tpa_general_code C
        ON (A.srtfll_general_type_id = C.general_type_id)
      LEFT OUTER JOIN pat_authorization_details D
        ON (A.pat_gen_detail_seq_id = D.pat_auth_seq_id)
      LEFT OUTER JOIN clm_authorization_details E
        ON (a.claim_seq_id = e.claim_seq_id)
      LEFT OUTER JOIN clm_batch_upload_details CI
        ON (ci.clm_batch_seq_id = e.claim_seq_id)
      LEFT OUTER JOIN shortfall_reminder_log f
        ON (a.last_reminder_log_seq_id = f.srtfll_reminder_log_seq_id)
      LEFT OUTER JOIN shortfall_email_dtl g
        ON (a.shortfall_seq_id = g.shortfall_seq_id) 
      LEFT OUTER JOIN tpa_general_code h
        ON (g.shortfall_email_status = h.general_type_id) 
     WHERE A.shortfall_seq_id = v_shortfall_seq_id;

END select_shortfall_details;
--=======================================================================
PROCEDURE delete_shortfalls(v_seq_id           IN pat_authorization_details.pat_auth_seq_id%type,
                            v_shortfall_seq_id IN shortfall_details.shortfall_seq_id%type,
                            v_mode             IN VARCHAR2,--PAT,CLM
                            v_added_by         IN NUMBER,
                            v_rows_processed OUT NUMBER) IS
  CURSOR pat_cur IS
    SELECT pad.pat_status_type_id, pad.completed_yn
      FROM pat_authorization_details pad
     WHERE pad.pat_auth_seq_id = v_seq_id;

  CURSOR clm_cur IS
    SELECT pad.clm_status_type_id, pad.completed_yn
      FROM clm_authorization_details pad
     WHERE pad.claim_seq_id = v_seq_id;

  pat_rec pat_cur%ROWTYPE;
  clm_rec clm_cur%ROWTYPE;
  v_dummy        NUMBER;


BEGIN


  IF v_mode = 'PAT' THEN

authorization_pkg.reassign_user('|'||v_seq_id||'|',null,null,v_added_by,null,v_dummy);

      OPEN pat_cur;
      FETCH pat_cur
        INTO pat_rec;
      CLOSE pat_cur;

      IF pat_rec.Pat_Status_Type_Id IN ('APR', 'REJ') OR
         pat_rec.Completed_Yn = 'Y' THEN
        RAISE_APPLICATION_ERROR(-20386,
                                'You cannot delete Shortfall details , Until Preauth/Claim Status is Complete');
      ELSE
        DELETE FROM SHORTFALL_DETAILS SD
         WHERE SD.SHORTFALL_SEQ_ID = v_shortfall_seq_id AND
         SD.PAT_GEN_DETAIL_SEQ_ID=v_seq_id;


         update pat_authorization_details ad 
         set ad.pat_status_type_id='INP'
         where ad.pat_auth_seq_id=v_seq_id;
      END IF;
  ELSIF v_mode = 'CLM' THEN
    
 authorization_pkg.reassign_user(null,'|'||v_seq_id||'|',null,v_added_by,null,v_dummy);
  
      OPEN clm_cur;
      FETCH clm_cur
        INTO clm_rec;
      CLOSE clm_cur;

      IF clm_rec.clm_status_type_id IN ('APR', 'REJ') OR
         pat_rec.Completed_Yn = 'Y' THEN
        RAISE_APPLICATION_ERROR(-20378,
                                'You cannot delete Observation details , Until Preauth/Claim Status is Complete');
      ELSE
        DELETE FROM SHORTFALL_DETAILS SD
         WHERE SD.SHORTFALL_SEQ_ID = v_shortfall_seq_id AND
         SD.CLAIM_SEQ_ID=v_seq_id;

        update clm_authorization_details ad 
         set ad.clm_status_type_id='INP'
         where ad.claim_seq_id=v_seq_id; 
      END IF;
  END IF;

  v_rows_processed := SQL%ROWCOUNT;
  COMMIT;

END delete_shortfalls;
--===================================================
PROCEDURE select_shortfall_list (
    v_shortfall_number                   IN  shortfall_details.shortfall_id%type,
    v_pre_auth_number                    IN  pat_authorization_details.Pre_Auth_Number%type,
    v_status_general_type_id             IN  shortfall_details.srtfll_status_general_type_id%type,
    v_policy_number                      IN  tpa_enr_policy.Policy_Number%TYPE,
    v_member_id                          IN  pat_authorization_details.Tpa_Enrollment_Id%TYPE,
    v_mode                               IN  VARCHAR2,---PAT,CLM
    v_sort_var                           IN  VARCHAR2,
    v_sort_order                         IN  VARCHAR2 ,
    v_start_num                          IN  NUMBER ,
    v_end_num                            IN  NUMBER ,
    v_added_by                           IN  NUMBER,
    v_qatar_id                           IN  pat_authorization_details.emirate_id%type,
    result_set                           OUT SYS_REFCURSOR
  )
  IS

    v_sql_str                            VARCHAR2(10000) ;
    TYPE bind_tab_type IS TABLE OF VARCHAR2(250) INDEX BY BINARY_INTEGER ;
    bind_tab                             bind_tab_type;
    i                                    NUMBER(2) := 0;
    v_where                              VARCHAR2(4000);

  BEGIN
   IF  v_mode='PAT' THEN 
    v_sql_str :=
    'select pad.pat_auth_seq_id,
       pad.pre_auth_number,
       sd.shortfall_id,
       sd.shortfall_seq_id,
       sd.srtfll_status_general_type_id,
       tep.policy_number,
       gc.description as srtfll_status,
       pad.tpa_enrollment_id,
       pad.emirate_id qatar_id
       
  from pat_authorization_details pad
  join shortfall_details sd on (pad.pat_auth_seq_id=sd.pat_gen_detail_seq_id)
  join tpa_enr_policy tep on (pad.policy_seq_id=tep.policy_seq_id)
  join tpa_enr_policy_member tepm on (pad.member_seq_id=tepm.member_seq_id)
  left outer join tpa_general_code gc on (gc.general_type_id=sd.srtfll_status_general_type_id)';



    IF v_shortfall_number IS NOT NULL THEN
      v_where := v_where  ||' AND sd.shortfall_id = :v_shortfall_number ';
       i := i+1;
       bind_tab(i) := UPPER(v_shortfall_number);
    END IF;

    IF v_pre_auth_number IS NOT NULL THEN
      v_where := v_where  ||' AND pad.pre_auth_number = :v_pre_auth_number ';
       i := i+1;
       bind_tab(i) := UPPER(v_pre_auth_number);
    END IF;

    IF v_status_general_type_id IS NOT NULL THEN
      v_where := v_where  ||' AND sd.srtfll_status_general_type_id = :v_status_general_type_id ';
       i := i+1;
       bind_tab(i) := UPPER(v_status_general_type_id);
    END IF;

    IF v_policy_number IS NOT NULL THEN
      v_where := v_where  ||' AND tep.policy_number = :v_policy_number';
      i := i+1;
      bind_tab(i) := UPPER(v_policy_number);
    END IF;


    IF v_member_id IS NOT NULL THEN
      v_where := v_where  ||' AND pad.Tpa_Enrollment_Id = :v_member_id';
      i := i+1;
      bind_tab(i) := UPPER(v_member_id);
    END IF;
    ------------- CR0218(search by QatarID) ---------------------
    IF v_qatar_id IS NOT NULL THEN
      v_where := v_where  ||' AND pad.emirate_id = :v_qatar_id';
      i := i+1;
      bind_tab(i) := UPPER(v_qatar_id);
    END IF;
    -------------------------------------------------------------
    ELSE 
     v_sql_str :=
    'select pad.pat_auth_seq_id,
       pad.pre_auth_number,
       sd.shortfall_id,
       sd.shortfall_seq_id,
       sd.srtfll_status_general_type_id,
       tep.policy_number,
       gc.description as srtfll_status,
       pad.tpa_enrollment_id,
       pad.emirate_id qatar_id
       
  from pat_authorization_details pad
  join shortfall_details sd on (pad.pat_auth_seq_id=sd.pat_gen_detail_seq_id)
  join tpa_enr_policy tep on (tepg.policy_seq_id=tep.policy_seq_id)
  join tpa_enr_policy_member tepm on (pad.member_seq_id=tepm.member_seq_id)
  left outer join tpa_general_code gc on (gc.general_type_id=sd.srtfll_status_general_type_id)';



    IF v_shortfall_number IS NOT NULL THEN
      v_where := v_where  ||' AND sd.shortfall_id = :v_shortfall_number ';
       i := i+1;
       bind_tab(i) := UPPER(v_shortfall_number);
    END IF;

    IF v_pre_auth_number IS NOT NULL THEN
      v_where := v_where  ||' AND pad.pre_auth_number = :v_pre_auth_number ';
       i := i+1;
       bind_tab(i) := UPPER(v_pre_auth_number);
    END IF;

    IF v_status_general_type_id IS NOT NULL THEN
      v_where := v_where  ||' AND sd.srtfll_status_general_type_id = :v_status_general_type_id ';
       i := i+1;
       bind_tab(i) := UPPER(v_status_general_type_id);
    END IF;

    IF v_policy_number IS NOT NULL THEN
      v_where := v_where  ||' AND tep.policy_number = :v_policy_number';
      i := i+1;
      bind_tab(i) := UPPER(v_policy_number);
    END IF;


    IF v_member_id IS NOT NULL THEN
      v_where := v_where  ||' AND pad.Tpa_Enrollment_Id = :v_member_id';
      i := i+1;
      bind_tab(i) := UPPER(v_member_id);
    END IF;
    ------------- CR0218(search by QatarID) ---------------------
    IF v_qatar_id IS NOT NULL THEN
      v_where := v_where  ||' AND pad.emirate_id = :v_qatar_id';
      i := i+1;
      bind_tab(i) := UPPER(v_qatar_id);
    END IF;
    -------------------------------------------------------------
    END IF;
    IF v_where IS NOT NULL THEN
      v_where   := ' WHERE '|| SUBSTR(v_where,5);
      v_sql_str := v_sql_str ||v_where;
    END IF;


    v_sql_str := 'SELECT * FROM
        (SELECT A.*,DENSE_RANK() OVER (ORDER BY '||v_sort_var||' '||v_sort_order||',ROWNUM)
        Q FROM (' ||v_sql_str|| ') A ) WHERE  Q>= :v_start_num AND Q<= :v_end_num ';



    IF bind_tab.FIRST IS NOT NULL THEN
       CASE bind_tab.COUNT
         WHEN 1  THEN OPEN result_set FOR v_sql_str USING bind_tab(1), v_start_num , v_end_num ;
         WHEN 2  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2), v_start_num , v_end_num ;
         WHEN 3  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2) ,bind_tab(3) , v_start_num , v_end_num ;
         WHEN 4  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) , v_start_num , v_end_num ;
         WHEN 5  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5), v_start_num , v_end_num ;
         WHEN 6  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6), v_start_num , v_end_num ;
       END CASE;
     ELSE
       OPEN result_set FOR v_sql_str USING v_start_num , v_end_num ;
     END IF;

  END select_shortfall_list;
---=================================================
PROCEDURE select_activity_list (
    v_act_code                 IN OUT tpa_activity_master_details.activity_code%TYPE,
    v_description              IN OUT tpa_activity_master_details.activity_description%TYPE,
    V_search_flag              IN VARCHAR2,
    v_mode                     IN VARCHAR2,---PAT,CLM
    v_seq_id                   IN pat_authorization_details.pat_auth_seq_iD%TYPE,
    v_sort_var                 IN OUT VARCHAR2 ,
    v_sort_order               IN OUT VARCHAR2,
    v_start_num                IN OUT NUMBER  ,
    v_end_num                  IN OUT NUMBER  ,
    v_added_by                 IN  NUMBER,
    v_internal_code            IN VARCHAR2,
    v_result_set               OUT SYS_REFCURSOR
  )
  IS
    v_str                      VARCHAR2(2000);
 Cursor tariff_pat_cur is 
 SELECT pad.hosp_seq_id,tip.product_cat_type_id,tep.ins_seq_id,tep.group_reg_seq_id,pad.pat_auth_seq_id,pad.policy_seq_id,tep.tariff_type_id
  FROM pat_authorization_details pad
  JOIN tpa_enr_policy tep ON (pad.policy_seq_id=tep.policy_seq_id)
  JOIN tpa_ins_product tip ON (tep.product_seq_id=tip.product_seq_id)
  WHERE pad.pat_auth_seq_id=v_seq_id;

 Cursor tariff_clm_cur is 
  SELECT hd.hosp_seq_id,tip.product_cat_type_id,tep.ins_seq_id,tep.group_reg_seq_id,pad.claim_seq_id,pad.policy_seq_id,tep.tariff_type_id
  FROM clm_authorization_details pad
  JOIN clm_hospital_details hd on (hd.claim_seq_id=pad.claim_seq_id)
  JOIN tpa_enr_policy tep ON (pad.policy_seq_id=tep.policy_seq_id)
  JOIN tpa_ins_product tip ON (tep.product_seq_id=tip.product_seq_id)
  WHERE pad.claim_seq_id=v_seq_id;

      v_ins_seq_id    number;
      v_hosp_seq_id   number;
      v_tariff_ins_seq_id    number(10);
      v_tariff_count         number(10);
      v_tpa_ins_seq_id       number(10);


pat_rec             tariff_pat_cur%ROWTYPE;

/*
CURSOR provider_network(v_hosp_seq number) IS 
SELECT i.cn_yn,i.gn_yn,i.sn_yn,i.bn_yn,i.wn_yn,i.primary_network FROM tpa_hosp_info i where i.hosp_seq_id=v_hosp_seq;
*/
CURSOR provider_network(v_hosp_seq number,v_product_net_type varchar2) IS
SELECT i.primary_network, ny.network_type, ny.network_yn, gc.sort_no
  FROM tpa_hosp_info i, app.tpa_hosp_network ny, app.tpa_general_code gc
 where ny.hosp_seq_id = i.hosp_seq_id
   and gc.general_type_id = ny.network_type
   and gc.header_type = 'PROVIDER_NETWORK'
   and ny.network_yn = 'Y'
   and i.hosp_seq_id = v_hosp_seq--35939 --35337
   and gc.sort_no =
       (SELECT min(gc.sort_no)
          FROM tpa_hosp_info        i,
               app.tpa_hosp_network ny,
               app.tpa_general_code gc
         where ny.hosp_seq_id = i.hosp_seq_id
           and gc.general_type_id = ny.network_type
           and gc.header_type = 'PROVIDER_NETWORK'
           and ny.network_yn = 'Y'
           and i.hosp_seq_id = v_hosp_seq--35939 --35337 
           and gc.sort_no >=
               (SELECT min(gc.sort_no)
                  FROM tpa_hosp_info        i,
                       app.tpa_hosp_network ny,
                       app.tpa_general_code gc
                 where ny.hosp_seq_id = i.hosp_seq_id
                   and gc.general_type_id = ny.network_type
                   and gc.header_type = 'PROVIDER_NETWORK'
                   and i.hosp_seq_id = v_hosp_seq--35939
                   and gc.general_type_id = v_product_net_type))
 order by gc.sort_no;

provider_rec   provider_network%rowtype;

v_product_network_type   VARCHAR2(100);
v_pharmacy_cnt           NUMBER;

Cursor get_pat_hosp_date is select trunc(a.hospitalization_date) as hospitalization_date from app.pat_authorization_details a where a.pat_auth_seq_id = v_seq_id;
Cursor get_clm_hosp_date is select trunc(b.date_of_hospitalization) as hospitalization_date  from app.clm_authorization_details b where b.claim_seq_id = v_seq_id;
v_hosp_date   date;
v_count number:=0;
  BEGIN
    
   SELECT COUNT(1) INTO v_pharmacy_cnt
   FROM tpa_pharmacy_master_details ph
   WHERE ph.activity_code = UPPER(v_act_code);
   
      IF V_MODE='PAT' THEN  
       OPEN get_pat_hosp_date;
       FETCH get_pat_hosp_date INTO v_hosp_date;
       close get_pat_hosp_date;
      ELSE 
       OPEN get_clm_hosp_date;
       FETCH get_clm_hosp_date INTO v_hosp_date;
       close get_clm_hosp_date;
      END IF;
   
   
    v_sort_var   := CASE WHEN v_sort_var IS NULL THEN 'ACTIVITY_CODE' ELSE v_sort_var END;
    v_sort_order := CASE WHEN v_sort_order IS NULL THEN 'ASC' ELSE v_sort_order END;
    v_start_num  := CASE WHEN v_start_num IS NULL THEN 1 ELSE v_start_num END;
    v_end_num    := CASE WHEN v_end_num IS NULL THEN 70000 ELSE v_end_num END;

    v_act_code         := CASE WHEN v_act_code IS NOT NULL THEN UPPER(v_act_code)||'%' ELSE v_act_code END;
    v_description      := CASE WHEN v_description IS NOT NULL THEN '%'||UPPER(replace(v_description,' ','%'))||'%' ELSE v_description END;

   IF v_pharmacy_cnt > 0 AND V_search_flag !='TAR' THEN
     
     
     SELECT count(1) into v_count
             FROM tpa_pharmacy_master_details md
             WHERE ( UPPER(v_act_code) IS NULL OR UPPER(md.activity_code) LIKE UPPER(v_act_code) )
             AND ( UPPER(v_description) IS NULL OR (md.activity_description) LIKE UPPER(v_description))
             AND md.start_date <= v_hosp_date and nvl(md.end_date,v_hosp_date) >=v_hosp_date;
     
     
     
     
     IF V_search_flag='ACT' THEN
       
       
      if v_count>0 then 
       v_str :=
           ' SELECT null as hosp_tariff_seq_id,
             md.act_mas_dtl_seq_id ,md.activity_code ,md.activity_description, ''-'' as internal_code 
             FROM tpa_pharmacy_master_details md
             WHERE ( UPPER(:v_act_code) IS NULL OR UPPER(md.activity_code) LIKE UPPER(:v_act_code) )
             AND ( UPPER(:v_description) IS NULL OR (md.activity_description) LIKE UPPER(:v_description))
             AND md.start_date <= :v_hosp_date and nvl(md.end_date,:v_hosp_date) >=:v_hosp_date';
     
      else 
        v_str :=
            'SELECT null as hosp_tariff_seq_id,
             md.act_mas_dtl_seq_id ,md.activity_code ,md.activity_description, ''-'' as internal_code 
             FROM tpa_pharmacy_master_details md
             WHERE ( UPPER(:v_act_code) IS NULL OR UPPER(md.activity_code) LIKE UPPER(:v_act_code) )
             AND ( UPPER(:v_description) IS NULL OR (md.activity_description) LIKE UPPER(:v_description))';
      end if;
     END IF;
   ELSE
     
        SELECT count(1) into v_count
             FROM tpa_pharmacy_master_details md
             WHERE ( UPPER(v_act_code) IS NULL OR UPPER(md.activity_code) LIKE UPPER(v_act_code) )
             AND ( UPPER(v_description) IS NULL OR (md.activity_description) LIKE UPPER(v_description))
             AND md.start_date <= v_hosp_date and nvl(md.end_date,v_hosp_date) >=v_hosp_date;
     
     
     IF V_search_flag='ACT' THEN
     
     if v_count>0 then  
     
      v_str :=
         ' SELECT  null as hosp_tariff_seq_id,
           md.act_mas_dtl_seq_id ,md.activity_code ,md.activity_description, ''-'' as internal_code 
           FROM tpa_activity_master_details md
           WHERE ( UPPER(:v_act_code) IS NULL OR UPPER(md.activity_code) LIKE UPPER(:v_act_code) )
           AND ( UPPER(:v_description) IS NULL OR UPPER(md.activity_description) LIKE UPPER(:v_description))
           and md.activity_type_seq_id!=5
        union all
          SELECT null as hosp_tariff_seq_id,
          md.act_mas_dtl_seq_id  ,md.activity_code as activity_code ,md.activity_description ,''-'' as internal_code
          FROM tpa_pharmacy_master_details md
          where ( UPPER(:v_description) IS NULL OR (md.activity_description) LIKE UPPER(:v_description))
          AND md.start_date <= :v_hosp_date and nvl(md.end_date,:v_hosp_date) >=:v_hosp_date';
        else  
          
        v_str :=
         ' SELECT  null as hosp_tariff_seq_id,
           md.act_mas_dtl_seq_id ,md.activity_code ,md.activity_description, ''-'' as internal_code 
           FROM tpa_activity_master_details md
           WHERE ( UPPER(:v_act_code) IS NULL OR UPPER(md.activity_code) LIKE UPPER(:v_act_code) )
           AND ( UPPER(:v_description) IS NULL OR UPPER(md.activity_description) LIKE UPPER(:v_description))
           and md.activity_type_seq_id!=5
        union all
          SELECT null as hosp_tariff_seq_id,
          md.act_mas_dtl_seq_id  ,md.activity_code as activity_code ,md.activity_description ,''-'' as internal_code
          FROM tpa_pharmacy_master_details md
          where ( UPPER(:v_description) IS NULL OR (md.activity_description) LIKE UPPER(:v_description))';
          
         end if;
     
     ELSIF V_search_flag='TAR' THEN
      IF V_MODE='PAT' THEN  
       OPEN tariff_pat_cur;
       FETCH tariff_pat_cur INTO pat_rec;
       close tariff_pat_cur;
      ELSE 
       OPEN tariff_clm_cur;
       FETCH tariff_clm_cur INTO pat_rec;
       close tariff_clm_cur;
      END IF;
       v_hosp_seq_id:=pat_rec.hosp_seq_id;
      OPEN provider_network(pat_rec.hosp_seq_id,pat_rec.product_cat_type_id);
      FETCH provider_network INTO provider_rec;
      CLOSE provider_network;
       
     IF pat_rec.ins_seq_id IS NOT NULL THEN 

       SELECT COUNT(1) INTO v_tariff_count from tpa_hosp_tariff_details d 
       where d.ins_seq_id=pat_rec.ins_seq_id and d.hosp_seq_id=pat_rec.hosp_seq_id;
     END IF; 
       
     select ii.ins_seq_id into v_tpa_ins_seq_id from app.tpa_ins_info ii where ii.ins_comp_code_number='ALK01'; 
     IF v_tariff_count>0 THEN 
       v_tariff_ins_seq_id:=pat_rec.ins_seq_id;
     ELSE 
       v_tariff_ins_seq_id:=v_tpa_ins_seq_id;
     END IF;

     IF pat_rec.tariff_type_id='HSPL' THEN

     v_product_network_type:=provider_rec.network_type; 
     
     END IF;
       
       v_str := 
        'SELECT DISTINCT * FROM (SELECT d.hosp_tariff_seq_id,
           md.act_mas_dtl_seq_id ,md.activity_code ,d.hosp_act_desc as activity_description, nvl(d.internal_code, ''-'') as internal_code
           FROM tpa_hosp_tariff_details d join tpa_activity_master_details md on (d.activity_seq_id=md.act_mas_dtl_seq_id)
           WHERE( UPPER(:v_act_code) IS NULL OR UPPER(md.activity_code) LIKE UPPER(:v_act_code) )
           AND ( UPPER(:v_description) IS NULL OR UPPER(d.hosp_act_desc) LIKE UPPER(:v_description) ) 
           AND ( UPPER(:v_internal_code) IS NULL OR UPPER(d.internal_code) LIKE UPPER(:v_internal_code))
           AND (d.ins_seq_id=:v_tariff_ins_seq_id)
           AND (d.hosp_seq_id=:v_hosp_seq_id)
           AND  UPPER(d.network_type)IN (select general_type_id
                                     FROM (select g.general_type_id, g.sort_no, dense_rank() over(order by g.sort_no) r
                                           from tpa_general_code g
                                           where g.header_type = ''PROVIDER_NETWORK''
                                          ) q
          WHERE  q.r >=(select sort_no from tpa_general_code where general_type_id = :v_product_network_type)))';
       
           /*AND (d.network_type=:v_product_network_type))';*/
       
     END IF;
  END IF;
  
  v_str := 'SELECT * FROM
        (SELECT A.*, DENSE_RANK() OVER (ORDER BY '||v_sort_var||' '||v_sort_order||',ROWNUM) Q FROM (' ||v_str|| ') A )
         WHERE  Q>= :v_start_num  AND Q<= :v_end_num ';
         
  IF V_search_flag='TAR' THEN
    OPEN v_result_set FOR v_str USING v_act_code, v_act_code, v_description, v_description ,v_internal_code, v_internal_code, v_tariff_ins_seq_id,v_hosp_seq_id,v_product_network_type, v_start_num, v_end_num;
  ELSIF v_count>0 and nvl(v_pharmacy_cnt,0)>0 then
    OPEN v_result_set FOR v_str USING v_act_code, v_act_code, v_description, v_description ,v_hosp_date,v_hosp_date,v_hosp_date ,v_start_num, v_end_num; 
  ELSIF v_count>0 and nvl(v_pharmacy_cnt,0)=0 then
    OPEN v_result_set FOR v_str USING v_act_code, v_act_code, v_description, v_description , v_description, v_description ,v_hosp_date,v_hosp_date,v_hosp_date ,v_start_num, v_end_num; 
  ELSE
    OPEN v_result_set FOR v_str USING v_act_code, v_act_code, v_description, v_description ,v_description,v_description, v_start_num, v_end_num;
  END IF;
  END select_activity_list;
--===================================================
PROCEDURE select_icd_list (
    v_icd_code                 IN OUT tpa_icd10_master_details.icd_code%TYPE,
    v_description              IN OUT tpa_icd10_master_details.long_desc%TYPE,
    v_sort_var                 IN OUT VARCHAR2 ,
    v_sort_order               IN OUT VARCHAR2,
    v_start_num                IN OUT NUMBER  ,
    v_end_num                  IN OUT NUMBER  ,
    v_added_by                 IN  NUMBER,
    v_result_set               OUT SYS_REFCURSOR
  )
  IS
    v_str                      VARCHAR2(2000);
  BEGIN
    v_sort_var   := CASE WHEN v_sort_var IS NULL THEN 'ICD_CODE' ELSE v_sort_var END;
    v_sort_order := CASE WHEN v_sort_order IS NULL THEN 'ASC' ELSE v_sort_order END;
    v_start_num  := CASE WHEN v_start_num IS NULL THEN 1 ELSE v_start_num END;
    v_end_num    := CASE WHEN v_end_num IS NULL THEN 50000 ELSE v_end_num END;

    v_icd_code         := CASE WHEN v_icd_code IS NOT NULL THEN UPPER(v_icd_code)||'%' ELSE v_icd_code END;
    v_description      := CASE WHEN v_description IS NOT NULL THEN '%'||UPPER(replace(v_description,' ','%'))||'%' ELSE v_description END;

    v_str :=
        'SELECT
         md.icd10_seq_id ,md.icd_code ,md.long_desc 
         ,NVL2(ri.icd_code,1,0) rcnt
         FROM tpa_icd10_master_details md
    left join tpa_restrict_icd ri on(md.icd_code = ri.icd_code) 
         WHERE( :v_icd_code IS NULL OR md.icd_code LIKE :v_icd_code )
         AND ( :v_description IS NULL OR UPPER(md.long_desc) LIKE :v_description ) ';

    v_str := 'SELECT * FROM
      (SELECT A.*, DENSE_RANK() OVER (ORDER BY '||v_sort_var||' '||v_sort_order||',ROWNUM) Q FROM (' ||v_str|| ') A )
       WHERE  Q>= :v_start_num  AND Q<= :v_end_num ';

    OPEN v_result_set FOR v_str USING v_icd_code, v_icd_code, v_description, v_description , v_start_num, v_end_num;

  END select_icd_list;
  --=========================================================================
  PROCEDURE select_enhance_pat_list (
    v_pre_auth_number                    IN  PAT_AUTHORIZATION_DETAILS.Pre_Auth_Number%type,
    v_claimant_name                      IN  tpa_enr_policy_member.mem_name%type,
    v_received_date                      IN  VARCHAR2,
    v_pat_status_general_type_id         IN  PAT_AUTHORIZATION_DETAILS.Pat_Status_Type_Id%type,
    v_policy_number                      IN  tpa_enr_policy.Policy_Number%TYPE,
    v_member_id                          IN  PAT_AUTHORIZATION_DETAILS.Tpa_Enrollment_Id%TYPE,
    v_assign_user_id                     IN  VARCHAR2,
    v_other                              IN  VARCHAR2,
    v_sort_var                           IN  VARCHAR2,
    v_sort_order                         IN  VARCHAR2 ,
    v_start_num                          IN  NUMBER ,
    v_end_num                            IN  NUMBER ,
    v_added_by                           IN  NUMBER,
    v_qatar_id                           IN  pat_authorization_details.emirate_id%type,
    result_set                           OUT SYS_REFCURSOR
  )
  IS

    v_sql_str                            VARCHAR2(10000) ;
    v_pat_received_date                  PAT_AUTHORIZATION_DETAILS.Pat_Received_Date%TYPE := TO_DATE(v_received_date, 'dd/mm/yyyy');
    TYPE bind_tab_type IS TABLE OF VARCHAR2(250) INDEX BY BINARY_INTEGER ;
    bind_tab                             bind_tab_type;
    i                                    NUMBER(2) := 0;
    v_where                              VARCHAR2(2000);

  BEGIN
    v_sql_str :=
    'select pad.pat_auth_seq_id,
       pad.pat_batch_seq_id,
       pad.parent_pat_auth_seq_id,
       (case when level=1 then pad.pre_auth_number else pad.pre_auth_number||''-''||''E''||to_char(level-1) end) as pre_auth_number,
       pad.auth_number,
       pad.pat_status_type_id,
       to_char(pad.pat_received_date,''dd/mm/yyyy hh:mi Am'') as pat_received_date,
       tep.policy_number,
       pad.priority_general_type_id,
       pad.hospitalization_date,
       pad.discharge_date,
       tepm.tpa_customer_id,
       hi.hosp_name,
       pad.mem_name,
       uc.contact_name,
       pad.tpa_enrollment_id,
       uc.tpa_office_seq_id,
       pad.emirate_id qatar_id
       
  from pat_authorization_details pad
  join tpa_enr_policy_member tepm on (pad.member_seq_id=tepm.member_seq_id and pad.pat_status_type_id in (''APR''/*,''REJ''*/) and pad.completed_yn=''Y''
  and pad.pat_enhanced_yn!=''Y'' AND pad.claim_seq_id is null /*AND pad.discharge_date>=sysdate*/)
  join tpa_enr_policy_group tepg on (tepm.policy_group_seq_id=tepg.policy_group_seq_id)
  join tpa_enr_policy tep on (tepg.policy_seq_id=tep.policy_seq_id)
  left outer join tpa_hosp_info hi on (hi.hosp_seq_id=pad.hosp_seq_id)
  left outer join assign_users au on (au.ASSIGN_USERS_SEQ_ID=pad.ASSIGN_USER_SEQ_ID)
  left outer join tpa_user_contacts uc on (uc.contact_seq_id=AU.ASSIGNED_TO_USER)
  left outer join tpa_general_code gc on (gc.general_type_id=pad.priority_general_type_id)';


    IF v_pre_auth_number IS NOT NULL THEN
      v_where := v_where  ||' AND pad.pre_auth_number = :v_pre_auth_number ';
       i := i+1;
       bind_tab(i) := UPPER(v_pre_auth_number);
    END IF;



    IF v_policy_number IS NOT NULL THEN
      v_where := v_where  ||' AND tep.policy_number = :v_policy_number';
      i := i+1;
      bind_tab(i) := UPPER(v_policy_number);
    END IF;


    IF v_claimant_name IS NOT NULL THEN
      v_where := v_where  ||' AND pad.mem_name LIKE :v_claimant_name';
      i := i+1;
      bind_tab(i) := UPPER(v_claimant_name)||'%';
    END IF;



    /*IF v_pat_received_date IS NOT NULL THEN
      v_where := v_where  ||' AND pad.pat_received_date  BETWEEN :v_pat_received_date_1 AND :v_pat_received_date_2 ';
      i := i+1;
      bind_tab(i) := v_pat_received_date;
      i := i+1;
      bind_tab(i) := v_pat_received_date + 1;
    END IF;*/
    
    IF v_pat_received_date IS NOT NULL THEN
      v_where := v_where  ||' AND trunc(pad.pat_received_date) = :v_freceive_date ';
       i := i+1;
       bind_tab(i) := UPPER(v_pat_received_date);
    END IF;
    
    IF v_pat_status_general_type_id IS NOT NULL THEN
      v_where := v_where  ||' AND pad.pat_status_type_id = :v_pat_status_general_type_id ';
       i := i+1;
       bind_tab(i) := v_pat_status_general_type_id;
    END IF;
    
    IF v_member_id IS NOT NULL THEN
      v_where := v_where  ||' AND pad.tpa_enrollment_id = :v_member_id ';
       i := i+1;
       bind_tab(i) := UPPER(v_member_id);
    END IF;
    ---------------- CR0218(search by qatarID) ---------------------------
   IF v_qatar_id IS NOT NULL THEN
      v_where := v_where  ||' AND pad.emirate_id = :v_qatar_id ';
       i := i+1;
       bind_tab(i) := UPPER(v_qatar_id);
    END IF;
    ----------------------------------------------------------------------  
    IF v_assign_user_id = 'SLF' THEN
      v_where := v_where  ||' AND au.assigned_to_user  = :v_added_by ';
       i := i+1;
       bind_tab(i) := v_added_by;
    ELSIF v_assign_user_id = 'OTH' THEN

	  IF v_other IS NULL THEN
     v_where := v_where  ||' AND au.assigned_to_user  != :v_added_by ';
       i := i+1;
       bind_tab(i) := v_added_by;
    ELSE   
       v_where := v_where  ||' AND uc.contact_name  = :v_other ';
     i := i+1;
       bind_tab(i) := v_other;
    END IF; 
	
    ELSIF v_assign_user_id = 'UAS' THEN
      v_where := v_where  ||' AND au.assigned_to_user IS NULL ';
    END IF;
  
    IF v_where IS NOT NULL THEN
      v_where   := ' WHERE '|| SUBSTR(v_where,5);
      v_sql_str := v_sql_str ||v_where ||' start with pad.pat_auth_seq_id=(select a.pat_auth_seq_id from app.pat_authorization_details a where /*nvl(a.parent_pat_auth_seq_id,0)=0 and*/ a.pat_auth_seq_id=pad.pat_auth_seq_id
        and a.completed_yn=''Y'') connect by prior pad.pat_auth_seq_id=pad.parent_pat_auth_seq_id';
    ELSE 
      v_sql_str := v_sql_str ||' start with pad.pat_auth_seq_id=(select a.pat_auth_seq_id from app.pat_authorization_details a where /*nvl(a.parent_pat_auth_seq_id,0)=0 and*/ a.pat_auth_seq_id=pad.pat_auth_seq_id
        and a.completed_yn=''Y'') connect by prior pad.pat_auth_seq_id=pad.parent_pat_auth_seq_id';
    END IF;

    v_sql_str := 'SELECT * FROM
        (SELECT A.*,DENSE_RANK() OVER (ORDER BY '||v_sort_var||' '||v_sort_order||',ROWNUM)
        Q FROM (' ||v_sql_str|| ') A ) WHERE  Q>= :v_start_num AND Q<= :v_end_num ';
    
    IF bind_tab.FIRST IS NOT NULL THEN
       CASE bind_tab.COUNT
         WHEN 1  THEN OPEN result_set FOR v_sql_str USING bind_tab(1), v_start_num , v_end_num ;
         WHEN 2  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2), v_start_num , v_end_num ;
         WHEN 3  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2) ,bind_tab(3) , v_start_num , v_end_num ;
         WHEN 4  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) , v_start_num , v_end_num ;
         WHEN 5  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5), v_start_num , v_end_num ;
         WHEN 6  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5), bind_tab(6), v_start_num , v_end_num ;
        END CASE;
     ELSE
       OPEN result_set FOR v_sql_str USING v_start_num , v_end_num ;
     END IF;

  END select_enhance_pat_list;
 ---=========================================================
 PROCEDURE select_provider_list (
    v_provider_id              IN OUT tpa_hosp_info.hosp_licenc_numb%TYPE,
    v_hosp_name                IN OUT tpa_hosp_info.hosp_name%TYPE,
    v_empanel_number           IN OUT tpa_hosp_info.empanel_number%TYPE,
    v_sort_var                 IN OUT VARCHAR2 ,
    v_sort_order               IN OUT VARCHAR2,
    v_start_num                IN OUT NUMBER  ,
    v_end_num                  IN OUT NUMBER  ,
    v_added_by                 IN  NUMBER,
    v_result_set               OUT SYS_REFCURSOR
    
  )
  IS
    v_str                      VARCHAR2(2000);
  BEGIN
    v_sort_var   := CASE WHEN v_sort_var IS NULL THEN 'HOSP_LICENC_NUMB' ELSE v_sort_var END;
    v_sort_order := CASE WHEN v_sort_order IS NULL THEN 'ASC' ELSE v_sort_order END;
    v_start_num  := CASE WHEN v_start_num IS NULL THEN 1 ELSE v_start_num END;
    v_end_num    := CASE WHEN v_end_num IS NULL THEN 2000 ELSE v_end_num END;

    v_provider_id         := CASE WHEN v_provider_id IS NOT NULL THEN UPPER(v_provider_id)||'%' ELSE v_provider_id END;
    v_hosp_name           := CASE WHEN v_hosp_name IS NOT NULL THEN '%'||UPPER(v_hosp_name)||'%' ELSE v_hosp_name END;
    v_empanel_number      := CASE WHEN v_empanel_number IS NOT NULL THEN '%'||UPPER(v_empanel_number)||'%' ELSE v_empanel_number END;
    
    
    v_str :=
        'SELECT
         cur.currency_id,i.hosp_seq_id ,i.hosp_licenc_numb ,i.hosp_name, i.regist_authority as authority,
         i.remarks as PROVIDER_SPECIFIC_REMARKS,i.empanel_number
         FROM tpa_hosp_info i join tpa_hosp_empanel_status e on (i.hosp_seq_id=e.hosp_seq_id and e.empanel_status_type_id=''EMP'')
         left outer join tpa_hosp_address tha                on (i.hosp_seq_id = tha.hosp_seq_id)
         left outer join tpa_currency_code cur               on(tha.country_id = cur.country_id )
         WHERE( :v_provider_id IS NULL OR i.hosp_licenc_numb LIKE :v_provider_id )
         AND ( :v_hosp_name IS NULL OR UPPER(i.hosp_name) LIKE :v_hosp_name ) 
         AND ( :v_empanel_number IS NULL OR UPPER(i.empanel_number) LIKE :v_empanel_number )';

    v_str := 'SELECT * FROM
      (SELECT A.*, DENSE_RANK() OVER (ORDER BY '||v_sort_var||' '||v_sort_order||',ROWNUM) Q FROM (' ||v_str|| ') A )
       WHERE  Q>= :v_start_num  AND Q<= :v_end_num ';
    OPEN v_result_set FOR v_str USING v_provider_id, v_provider_id, v_hosp_name, v_hosp_name ,v_empanel_number,v_empanel_number, v_start_num, v_end_num;

  END select_provider_list;
 ---====================================================
 PROCEDURE select_clinician_list (
    v_clinician_id             IN OUT tpa_hosp_professionals.professional_id%TYPE,
    v_clinician_name           IN OUT tpa_hosp_professionals.contact_name%TYPE,
    v_provider_id              IN OUT tpa_hosp_info.hosp_licenc_numb%TYPE,
    v_hosp_name                IN OUT tpa_hosp_info.hosp_name%TYPE,
    v_sort_var                 IN OUT VARCHAR2 ,
    v_sort_order               IN OUT VARCHAR2,
    v_start_num                IN OUT NUMBER  ,
    v_end_num                  IN OUT NUMBER  ,
    v_added_by                 IN  NUMBER,
    v_result_set               OUT SYS_REFCURSOR
  )
  IS
    v_str                      VARCHAR2(2000);
  BEGIN
    v_sort_var   := CASE WHEN v_sort_var IS NULL THEN 'PROFESSIONAL_ID' ELSE v_sort_var END;
    v_sort_order := CASE WHEN v_sort_order IS NULL THEN 'ASC' ELSE v_sort_order END;
    v_start_num  := CASE WHEN v_start_num IS NULL THEN 1 ELSE v_start_num END;
    v_end_num    := CASE WHEN v_end_num IS NULL THEN 2000 ELSE v_end_num END;

    v_clinician_id        := CASE WHEN v_clinician_id IS NOT NULL THEN UPPER(v_clinician_id)||'%' ELSE v_clinician_id END;
    v_clinician_name      := CASE WHEN v_clinician_name IS NOT NULL THEN '%'||UPPER(v_clinician_name)||'%' ELSE v_clinician_name END;

    v_provider_id         := CASE WHEN v_provider_id IS NOT NULL THEN upper(SUBSTR(v_provider_id,1,INSTR(v_provider_id,'(',-1,1)-1))||'%' ELSE v_provider_id END;
    v_hosp_name           := CASE WHEN v_hosp_name IS NOT NULL THEN '%'||UPPER(v_hosp_name)||'%' ELSE v_hosp_name END;

IF v_clinician_id IS NOT NULL OR v_clinician_name IS NOT NULL  OR v_provider_id IS NOT NULL  OR v_hosp_name IS NOT NULL  THEN
    v_str :=
        'SELECT
         p.contact_seq_id ,p.professional_id ,p.contact_name , spec.specialty as clinician_speciality 
         FROM tpa_hosp_professionals p left outer join tpa_hosp_info i on (i.hosp_seq_id=p.hosp_seq_id)
         left outer join dha_clnsn_specialties_master spec on (spec.specialty_id=p.speciality_id)
         WHERE( :v_clinician_id IS NULL OR p.professional_id LIKE :v_clinician_id )
         AND ( :v_clinician_name IS NULL OR UPPER(p.contact_name) LIKE :v_clinician_name )
         AND (:v_provider_id IS NULL OR i.hosp_licenc_numb LIKE :v_provider_id )
         AND ( :v_hosp_name IS NULL OR UPPER(i.hosp_name) LIKE :v_hosp_name )  ';

    v_str := 'SELECT * FROM
      (SELECT A.*, DENSE_RANK() OVER (ORDER BY '||v_sort_var||' '||v_sort_order||',ROWNUM) Q FROM (' ||v_str|| ') A )
       WHERE  Q>= :v_start_num  AND Q<= :v_end_num ';

    OPEN v_result_set FOR v_str USING v_clinician_id, v_clinician_id, v_clinician_name, v_clinician_name , v_provider_id , v_provider_id , v_hosp_name , v_hosp_name, v_start_num, v_end_num;
ELSE
  OPEN v_result_set FOR SELECT null AS contact_seq_id ,null AS professional_id ,null AS  contact_name , null AS  clinician_speciality 
  FROM DUAL;
END IF;
  END select_clinician_list;
 --======================================================================
 procedure select_encounter_types(v_benefit_type IN Tpa_Encounter_Type_Codes.Benefit_Gen_Type_Id%type,
                                  v_result_set   OUT sys_refcursor) is
 begin
   IF v_benefit_type = 'IMTI' THEN
     open v_result_set for
       select c.encounter_seq_id,
        decode(gc.description,null,c.description,'('||gc.description||')'||c.description) AS description
        from app.tpa_encounter_type_codes c  
        left outer join tpa_general_code gc ON (c.category_type=gc.general_type_id)
        where c.category_type IN ('INPN');
   ELSIF v_benefit_type IN ('MTI', 'OMTI') THEN
     open v_result_set for
       select c.encounter_seq_id,
        decode(gc.description,null,c.description,'('||gc.description||')'||c.description) AS description
        from app.tpa_encounter_type_codes c  
        left outer join tpa_general_code gc ON (c.category_type=gc.general_type_id)
        where c.category_type IN ('OUTP');
   ELSIF v_benefit_type = 'DNTL' THEN
     open v_result_set for
        select c.encounter_seq_id,
        decode(gc.description,null,c.description,'('||gc.description||')'||c.description) AS description
        from app.tpa_encounter_type_codes c  
        left outer join tpa_general_code gc ON (c.category_type=gc.general_type_id)
        where c.category_type in ('OUTP'/*, 'INPN'*/);--Commenting for CR-0258
   ELSIF v_benefit_type = 'OPTC' THEN
     open v_result_set for
       select c.encounter_seq_id,
       decode(gc.description,null,c.description,'('||gc.description||')'||c.description) AS description
       from app.tpa_encounter_type_codes c  
       left outer join tpa_general_code gc ON (c.category_type=gc.general_type_id)
       where c.encounter_seq_id in (1,2) AND 
       c.header_type='ENCOUNTER_TYPE';
   ELSIF v_benefit_type = 'CB' THEN
     open v_result_set for
       select c.encounter_seq_id,
        decode(gc.description,null,c.description,'('||gc.description||')'||c.description) AS description
        from app.tpa_encounter_type_codes c  
        left outer join tpa_general_code gc ON (c.category_type=gc.general_type_id)
        where c.benefit_gen_type_id in ('IPT');
    ELSIF v_benefit_type = 'IEMA' THEN
     open v_result_set for
        select c.encounter_seq_id,
        decode(gc.description,null,c.description,'('||gc.description||')'||c.description) AS description
        from app.tpa_encounter_type_codes c  
        left outer join tpa_general_code gc ON (c.category_type=gc.general_type_id)
        where c.benefit_gen_type_id like  'IPT';
     
        
   
     ELSIF v_benefit_type = 'IPRE' THEN
     open v_result_set for
        select c.encounter_seq_id,
        decode(gc.description,null,c.description,'('||gc.description||')'||c.description) AS description
        from app.tpa_encounter_type_codes c  
        left outer join tpa_general_code gc ON (c.category_type=gc.general_type_id)
        where c.benefit_gen_type_id like  'IPT';
        
   
        
    ELSIF v_benefit_type = 'PAHC' THEN
     open v_result_set for
        select c.encounter_seq_id,
        decode(gc.description,null,c.description,'('||gc.description||')'||c.description) AS description
        from app.tpa_encounter_type_codes c  
        left outer join tpa_general_code gc ON (c.category_type=gc.general_type_id)
        where c.benefit_gen_type_id like  'IPT';
        
   ELSE
     open v_result_set for
        select c.encounter_seq_id,
        decode(gc.description,null,c.description,'('||gc.description||')'||c.description) AS description
        from app.tpa_encounter_type_codes c  
        left outer join tpa_general_code gc ON (c.category_type=gc.general_type_id)
        where c.benefit_gen_type_id = v_benefit_type
        and c.encounter_seq_id not in (12,15,41,42,13)
        ORDER BY C.ENCOUNTER_SEQ_ID;
   END IF;
 END select_encounter_types;
 --================================================================
 --================================================================
PROCEDURE check_activity_limits (v_seq_id                 IN pat_authorization_details.pat_auth_seq_id%TYPE,
                                 v_mode                   IN VARCHAR2,
                                 v_allowed_amt            IN NUMBER,
                                 v_added_by               IN NUMBER,
                                 v_remarks                IN VARCHAR2,
                                 v_final_allowed_amount   OUT NUMBER)
IS
CURSOR pat_cur IS
SELECT nvl(pad.approved_amount,0) as approved_amount,pad.activity_dtl_seq_id,pad.pat_auth_seq_id FROM pat_activity_details pad
WHERE pad.pat_auth_seq_id=v_seq_id AND pad.code<>'AC001';

CURSOR clm_cur IS
SELECT nvl(pad.approved_amount,0) as approved_amount,pad.activity_dtl_seq_id,pad.claim_seq_id FROM pat_activity_details pad
WHERE pad.claim_seq_id=v_seq_id AND pad.code<>'AC001';

rec   pat_cur%ROWTYPE;
CURSOR pat_master_code_cur is
SELECT distinct NVL(g.master_activity_code,M.master_activity_code) AS master_activity_code,
            case when (NVL(g.master_activity_code,M.master_activity_code) ='70450' and nvl(ctscan_payable,'INC') ='EXC') then 'Y' end ct_flag,
            case when (NVL(g.master_activity_code,M.master_activity_code) ='70551' and nvl(ctscan_payable,'INC') ='EXC') then 'Y' end mri_flag,
           NVL(case when b.maternity_yn='Y' then b.maternity_allowed_amt 
            when b.benifit_type='DNTL' then nvl(b.benefit_limit,v_ava_sum_ins) 
              else case when c.rule_limit>=0 then c.rule_limit 
                        else v_ava_sum_ins end 
        end,0) as rule_limit 
FROM pat_authorization_details b
JOIN pat_activity_details C ON (b.pat_auth_seq_id = c.pat_auth_seq_id )
LEFT JOIN tpa_activity_details G ON (c.code = G.ACTIVITY_CODE)
LEFT JOIN tpa_activity_master_details M ON (c.code = M.ACTIVITY_CODE)
WHERE  b.pat_auth_seq_id =v_seq_id AND c.code<>'AC001';

CURSOR clm_master_code_cur is
SELECT distinct NVL (g.master_activity_code,M.master_activity_code) as master_activity_code,
            case when (NVL(g.master_activity_code,M.master_activity_code) ='70450' and nvl(ctscan_payable,'INC') ='EXC') then 'Y' end ct_flag,
            case when (NVL(g.master_activity_code,M.master_activity_code) ='70551' and nvl(ctscan_payable,'INC') ='EXC') then 'Y' end mri_flag,
       NVL(case when b.maternity_yn='Y' then b.maternity_allowed_amt 
            when b.benifit_type='DNTL' then nvl(b.benefit_limit,v_ava_sum_ins) 
              else case when c.rule_limit>=0 then c.rule_limit 
                        else v_ava_sum_ins end 
             end,0) as rule_limit,
             b.pat_approved_amount,
             v_ava_sum_ins
             
 FROM clm_authorization_details b
 JOIN pat_activity_details C ON (b.claim_seq_id = c.claim_seq_id )
 LEFT JOIN tpa_activity_details g ON (C.code = g.activity_code )
 LEFT JOIN tpa_activity_master_details M ON (c.code = M.ACTIVITY_CODE)
 WHERE  b.claim_seq_id =v_seq_id AND c.code<>'AC001';             



cursor pat_act_cur (v_code  pat_activity_details.code%type) is  
SELECT DISTINCT nvl(g.master_activity_code,m.master_activity_code) as master_activity_code,c.activity_dtl_seq_id,c.code,
             c.allowed_amount,nvl(c.approved_amount,0) as approved_amount,c.net_amount,c.rule_unit,c.rule_limit,c.override_yn
             FROM pat_authorization_details b
             JOIN pat_activity_details C ON (b.pat_auth_seq_id = c.pat_auth_seq_id )
             LEFT JOIN tpa_activity_details G ON (c.code = G.ACTIVITY_CODE)
             LEFT JOIN tpa_activity_master_details M ON (c.code = M.ACTIVITY_CODE)
             WHERE b.pat_auth_seq_id = v_seq_id 
              and (G.MASTER_ACTIVITY_CODE=v_code or M.MASTER_ACTIVITY_CODE = v_code) 
              --and nvl(c.override_yn,'N') = 'N'
              AND c.code<>'AC001'
             order by c.activity_dtl_seq_id;
             
cursor clm_act_cur (v_code  pat_activity_details.code%type) is  
SELECT DISTINCT nvl(g.master_activity_code,m.master_activity_code) as master_activity_code,c.activity_dtl_seq_id,c.code,nvl(c.approved_amount,0) as approved_amount,c.allowed_amount,c.net_amount,
              b.pat_approved_amount,b.claim_type,c.rule_unit,c.rule_limit,b.sys_med_limit,c.override_yn
             FROM clm_authorization_details b
             JOIN pat_activity_details C ON (b.claim_seq_id = c.claim_seq_id )
             LEFT JOIN tpa_activity_details G ON (c.code = G.ACTIVITY_CODE)
             LEFT JOIN tpa_activity_master_details M ON (c.code = M.ACTIVITY_CODE)
             WHERE b.claim_seq_id = v_seq_id 
              and (G.MASTER_ACTIVITY_CODE=v_code or M.MASTER_ACTIVITY_CODE = v_code) 
              --and nvl(c.override_yn,'N') = 'N'
              AND c.code<>'AC001'
             order by c.activity_dtl_seq_id;


CURSOR act_cur_pat IS
SELECT SUM(NVL(pa.gross_amount,0)) as tot_gross_amount
      ,SUM(NVL(pa.discount_amount,0)) as tot_discount_amount
      ,SUM(NVL(pa.disc_gross_amount,0)) as tot_disc_gross_amount
      ,SUM(NVL(pa.patient_share_amount,0)) as tot_patient_share_amount
      ,SUM(NVL(pa.net_amount,0)) as tot_net_amount
      ,SUM(NVL(pa.allowed_amount,0)) as tot_allowed_amount
      ,SUM(NVL(pa.approved_amount,0)) as tot_approved_amount

FROM pat_activity_details pa
WHERE pa.pat_auth_seq_id=v_seq_id
AND pa.allow_yn='Y';

CURSOR act_cur_clm IS
SELECT SUM(NVL(pa.gross_amount,0)) as tot_gross_amount
      ,SUM(NVL(pa.discount_amount,0)) as tot_discount_amount
      ,SUM(NVL(pa.disc_gross_amount,0)) as tot_disc_gross_amount
      ,SUM(NVL(pa.patient_share_amount,0)) as tot_patient_share_amount
      ,SUM(NVL(pa.net_amount,0)) as tot_net_amount
      ,SUM(NVL(pa.allowed_amount,0)) as tot_allowed_amount
      ,SUM(NVL(pa.approved_amount,0)) as tot_approved_amount

FROM pat_activity_details pa
WHERE pa.claim_seq_id=v_seq_id
AND pa.allow_yn='Y';

CURSOR pat_icd_cur is 
select case when dd.denial_reason like '%NCOV-001%' then null 
         else NVL(dd.rule_limit, v_ava_sum_ins) end as rule_limit,
dd.denial_reason,dd.remarks,null as pat_approved_amount,dd.copay,dd.deduct,ci.day_care_icd_group_id,ad.benifit_type,NVL(ad.limit_applied_flag,'OCL') AS limit_applied_flag,v_ava_sum_ins AS sum_ins  
from app.pat_authorization_details ad
join diagnosys_details dd on (ad.pat_auth_seq_id=dd.pat_auth_seq_id)
join tpa_day_care_icd ci on (ci.icd_code=dd.diagnosys_code AND dd.primary_ailment_yn='Y')
where dd.pat_auth_seq_id=v_seq_id and ci.day_care_icd_group_id='ICD001';


CURSOR clm_icd_cur is 
select case when dd.denial_reason like '%NCOV-001%' then null 
       else NVL(dd.rule_limit, v_ava_sum_ins) end as rule_limit,
       dd.denial_reason,dd.remarks,ad.pat_approved_amount,
       dd.copay,dd.deduct,ci.day_care_icd_group_id,ad.benifit_type,NVL(ad.limit_applied_flag,'OCL') AS limit_applied_flag,ad.ava_sum_insured as sum_ins
from app.clm_authorization_details ad
join diagnosys_details dd on (ad.claim_seq_id=dd.claim_seq_id)
join tpa_day_care_icd ci on (ci.icd_code=dd.diagnosys_code AND dd.primary_ailment_yn='Y')
where dd.claim_seq_id=v_seq_id and ci.day_care_icd_group_id='ICD001';
--------
cursor clm_psy_icd_cur is 
select case when dd.denial_reason like '%NCOV-001%' then null 
           else nvl(dd.rule_limit,v_ava_sum_ins) end as rule_limit,
   dd.denial_reason,dd.remarks,ad.pat_approved_amount,dd.copay,dd.deduct,ci.master_icd_code,ad.benifit_type 
   ,NVL(ad.limit_applied_flag,'OPL') as limit_applied_flag,v_ava_sum_ins as sum_ins 
from app.clm_authorization_details ad
join diagnosys_details dd on (ad.claim_seq_id=dd.claim_seq_id)
join tpa_icd_codes ci on (ci.icd_code=dd.diagnosys_code AND dd.primary_ailment_yn='Y')
where dd.claim_seq_id=v_seq_id and ci.master_icd_code IN ('F09', 'B20', 'E66.9', 'E55.9', 'Q00.0', 'C80.1', 'A65', 'Z00.121', 'B16.9', 'B17.11');

cursor pat_psy_icd_cur is

  select case when dd.denial_reason like '%NCOV-001%' then null 
         else nvl(dd.rule_limit,v_ava_sum_ins) end as rule_limit,
  dd.denial_reason,dd.remarks,null as pat_approved_amount,dd.copay,dd.deduct,ci.master_icd_code,ad.benifit_type,NVL(ad.limit_applied_flag,'OPL') as limit_applied_flag,
  v_ava_sum_ins as sum_ins   
from app.pat_authorization_details ad
join diagnosys_details dd on (ad.pat_auth_seq_id=dd.pat_auth_seq_id)
join tpa_icd_codes ci on (ci.icd_code=dd.diagnosys_code AND dd.primary_ailment_yn='Y')
where dd.pat_auth_seq_id=v_seq_id and  ci.master_icd_code IN ('F09', 'B20', 'E66.9', 'E55.9', 'Q00.0', 'C80.1', 'A65', 'Z00.121', 'B16.9', 'B17.11');
--------
cursor pat_chronic_cur  is  
SELECT c.activity_dtl_seq_id,c.code,c.allowed_amount,nvl(c.approved_amount,0) as approved_amount,c.net_amount,c.override_yn,
       case when /*b.benifit_type IN ('IMTI', 'OMTI', 'MTI') OR*/ nvl(b.maternity_yn,'N') = 'Y'  THEN 
         nvl(c.rule_limit, b.ava_sum_insured) 
       else 
       c.rule_limit end as rule_limit,
       D.MASTER_ACTIVITY_CODE/*,
       c.mat_per_cons_flag*/
             FROM pat_authorization_details b
             JOIN pat_activity_details C ON (b.pat_auth_seq_id = c.pat_auth_seq_id )
             left outer join app.tpa_activity_master_details D on (c.code = D.activity_code)
             WHERE B.pat_auth_seq_id = v_seq_id
             --and nvl(c.override_yn,'N') = 'N'
             AND c.code<>'AC001'
             order by c.activity_dtl_seq_id;
 cursor psy_act_cur  is    

             SELECT  c.activity_dtl_seq_id,c.code,c.approved_amount,c.allowed_amount,c.net_amount,c.override_yn,C.benifit_deductible,c.rule_limit
             FROM pat_authorization_details b
             JOIN pat_activity_details C ON (b.pat_auth_seq_id = c.pat_auth_seq_id )
             WHERE B.pat_auth_seq_id = v_seq_id
             --and nvl(c.override_yn,'N') = 'N'
             AND c.code<>'AC001'
             and c.code='90801';
             
 CURSOR psy_actclm_cur is           
             SELECT c.activity_dtl_seq_id,c.code,c.approved_amount,c.allowed_amount,c.net_amount,b.pat_approved_amount,b.claim_type,c.override_yn,C.benifit_deductible,c.rule_limit
             FROM clm_authorization_details b
             JOIN pat_activity_details C ON (b.claim_seq_id = c.claim_seq_id )
             WHERE b.claim_seq_id = v_seq_id
             --and nvl(c.override_yn,'N') = 'N'
              and c.code='90801'
              AND c.code<>'AC001';
            

cursor clm_chronic_cur  is  
SELECT   c.activity_dtl_seq_id,c.code,nvl(c.approved_amount,0) as approved_amount,c.allowed_amount,
         c.net_amount,b.pat_approved_amount,b.claim_type,c.override_yn,
         case  when /*b.benifit_type IN ('IMTI', 'OMTI', 'MTI') OR*/ nvl(b.maternity_yn,'N') = 'Y' THEN 
         nvl(c.rule_limit, b.ava_sum_insured) 
         else 
         c.rule_limit end as rule_limit,-------NEWLY ADDED
         d.master_activity_code/*,  -------NEWLY ADDED
         c.mat_per_cons_flag*/
             FROM clm_authorization_details b
             JOIN pat_activity_details C ON (b.claim_seq_id = c.claim_seq_id )
             left outer join app.tpa_activity_master_details D on (c.code = D.activity_code)
             WHERE b.claim_seq_id = v_seq_id
             --and nvl(c.override_yn,'N') = 'N'
             AND c.code<>'AC001'
             order by c.activity_dtl_seq_id;
-- PAT
cursor get_dent_grp_code_cur is
  select distinct nvl(nvl(d.specific_service_code, nvl(g.master_activity_code, m.master_activity_code)), 'NA') as specific_service_code, nvl(pa.benefit_limit, v_ava_sum_ins) as benefit_limit, v_ava_sum_ins as ava_sum_insured
  from pat_authorization_details pa
  join pat_activity_details p ON pa.pat_auth_seq_id = p.pat_auth_seq_id
  left join dental_rule_tab d on p.code = d.cdt_code
  LEFT JOIN tpa_activity_details G ON (p.code = G.ACTIVITY_CODE)
  LEFT JOIN tpa_activity_master_details M ON (p.code = M.ACTIVITY_CODE)
  where pa.pat_auth_seq_id = v_seq_id
  AND p.code<>'AC001';
/*cursor get_dent_grp_code_cur is
  select distinct d.specific_service_code as specific_service_code, nvl(pa.benefit_limit, pa.ava_sum_insured) as limit, pa.ava_sum_insured as ava_sum_insured
  from dental_rule_tab d
  join pat_activity_details p ON p.code = d.cdt_code
  join pat_authorization_details pa on pa.pat_auth_seq_id = p.pat_auth_seq_id
  where pa.pat_auth_seq_id = v_seq_id;*/

--CLM
cursor clm_get_dent_grp_code_cur is
  select distinct nvl(nvl(d.specific_service_code, nvl(g.master_activity_code, m.master_activity_code)), 'NA') as specific_service_code, nvl(pa.benefit_limit,v_ava_sum_ins) as benefit_limit, v_ava_sum_ins as ava_sum_insured,
         nvl(pa.pat_approved_amount, 0) as pat_approved_amount, pa.requested_amount
         
  from clm_authorization_details pa
  join pat_activity_details p ON pa.claim_seq_id = p.claim_seq_id
  left join dental_rule_tab d on p.code = d.cdt_code
  LEFT JOIN tpa_activity_details G ON (p.code = G.ACTIVITY_CODE)
  LEFT JOIN tpa_activity_master_details M ON (p.code = M.ACTIVITY_CODE)
  where pa.claim_seq_id = v_seq_id
  AND p.code<>'AC001';
  
--get_dent_grp_code_rec      get_dent_grp_code_cur%ROWTYPE;
--PAT
cursor get_dent_code_cur(v_service_code VARCHAR2) is
  select p.code, nvl(p.approved_amount, 0) as approved_amount, p.override_yn, p.activity_dtl_seq_id,
         coalesce(p.rule_limit, least(pa.benefit_limit, pa.ava_sum_insured)) as rule_limit
         
  from pat_authorization_details pa
  join pat_activity_details p ON pa.pat_auth_seq_id = p.pat_auth_seq_id
  left join dental_rule_tab d on p.code = d.cdt_code
  LEFT JOIN tpa_activity_details G ON (p.code = G.ACTIVITY_CODE)
  LEFT JOIN tpa_activity_master_details M ON (p.code = M.ACTIVITY_CODE)
  where pa.pat_auth_seq_id = v_seq_id
  and (d.specific_service_code = v_service_code
  --OR g.master_activity_code = v_service_code
  --OR m.master_activity_code = v_service_code);
  OR case when v_service_code like 'D%' then d.specific_service_code else g.master_activity_code end = v_service_code
  OR case when v_service_code like 'D%' then d.specific_service_code else m.master_activity_code end = v_service_code
  OR (v_service_code = 'NA' AND m.master_activity_code IS NULL))
  AND p.code<>'AC001'
  ORDER BY p.activity_dtl_seq_id;
  /*from dental_rule_tab d
  join pat_activity_details p ON p.code = d.cdt_code
  join pat_authorization_details pa on pa.pat_auth_seq_id = p.pat_auth_seq_id
  where pa.pat_auth_seq_id = v_seq_id
  and d.specific_service_code = v_service_code;*/

--CLM  
cursor clm_get_dent_code_cur(v_service_code VARCHAR2) is
  select p.code, nvl(p.approved_amount, 0) as approved_amount, p.override_yn, p.activity_dtl_seq_id,
         coalesce(p.rule_limit, least(pa.benefit_limit, pa.ava_sum_insured)) as rule_limit
  from clm_authorization_details pa
  join pat_activity_details p ON pa.claim_seq_id = p.claim_seq_id
  left join dental_rule_tab d on p.code = d.cdt_code
  LEFT JOIN tpa_activity_details G ON (p.code = G.ACTIVITY_CODE)
  LEFT JOIN tpa_activity_master_details M ON (p.code = M.ACTIVITY_CODE)
  where pa.claim_seq_id = v_seq_id
  and (d.specific_service_code = v_service_code
  --OR g.master_activity_code = v_service_code
  --OR m.master_activity_code = v_service_code);
  OR case when v_service_code like 'D%' then d.specific_service_code else g.master_activity_code end = v_service_code
  OR case when v_service_code like 'D%' then d.specific_service_code else m.master_activity_code end = v_service_code
  OR (v_service_code = 'NA' AND m.master_activity_code IS NULL))
  AND p.code<>'AC001'
  ORDER BY p.activity_dtl_seq_id;
  
---PAT Dental IOTN Denial Cursor
cursor pat_iotn_scr_cur IS
  SELECT CASE WHEN pa.denial_code  LIKE '%IOTN-007%' THEN pa.denial_code ELSE null END AS iotn
  FROM pat_authorization_details b
  JOIN pat_activity_details pa ON (pa.pat_auth_seq_id = b.pat_auth_seq_id)
  WHERE B.pat_auth_seq_id = v_seq_id 
  AND pa.code<>'AC001'
  ORDER BY pa.activity_dtl_seq_id;

---CLM Dental IOTN Denial Cursor

cursor clm_iotn_scr_cur IS
  SELECT CASE WHEN pa.denial_code  LIKE '%IOTN-007%' THEN pa.denial_code ELSE null END AS iotn
  FROM clm_authorization_details b
  JOIN pat_activity_details pa ON (pa.claim_seq_id = b.claim_seq_id)
  WHERE B.pat_auth_seq_id = v_seq_id
  AND pa.code<>'AC001'
  ORDER BY pa.activity_dtl_seq_id;
  
  
cursor pat_dental_cur  is  
SELECT CASE WHEN b.benifit_type='DNTL' THEN nvl(b.benefit_limit,v_ava_sum_ins) 
            WHEN b.benifit_type IN ('MTI', 'IMTI', 'OMTI') OR b.MATERNITY_YN='Y' THEN nvl(b.Maternity_Allowed_Amt,v_ava_sum_ins) END as benefit_limit
             FROM pat_authorization_details b
             WHERE B.pat_auth_seq_id = v_seq_id;

cursor clm_dental_cur  is  
SELECT  CASE WHEN b.benifit_type='DNTL' THEN nvl(b.benefit_limit,v_ava_sum_ins) 
             WHEN b.benifit_type IN ('MTI', 'IMTI', 'OMTI') OR b.MATERNITY_YN='Y' THEN nvl(b.Maternity_Allowed_Amt,v_ava_sum_ins) END as benefit_limit ,b.pat_approved_amount,b.claim_type
             FROM clm_authorization_details b
             WHERE b.claim_seq_id = v_seq_id;

iotn_scr_cur    pat_iotn_scr_cur%ROWTYPE;     
       
                          
             
CURSOR sys_med_flag_act_pat is      
SELECT distinct nvl(g.master_activity_code,m.master_activity_code) as master_activity_code,NVL(sys_med_yn,'N') AS sys_med_yn,nvl(pad.sys_med_limit,v_ava_sum_ins) as sys_med_limit,diag.rule_limit 
		as icd_limit,pad.sys_med_copay as sys_copay, diag.copay as diag_copay,diag.deduct as diag_deduct, pad.sys_med_deductible as sys_deductible
       FROM pat_authorization_details pad
       JOIN pat_activity_details pat on (pad.pat_auth_seq_id=pat.pat_auth_seq_id)
       JOIN diagnosys_details diag on (diag.pat_auth_seq_id=pad.pat_auth_seq_id)
       LEFT JOIN tpa_activity_details G ON (pat.code = G.ACTIVITY_CODE)
      -- LEFT JOIN tpa_activity_details gg ON (g.master_activity_code = gg.master_activity_code )
       LEFT JOIN tpa_activity_master_details M ON (pat.code = M.ACTIVITY_CODE)
      -- LEFT JOIN tpa_activity_master_details Ma ON (m.master_activity_code = Ma.Master_Activity_Code)
       WHERE pad.pat_auth_seq_id = v_seq_id AND diag.primary_ailment_yn='Y'
       AND pat.code<>'AC001';
                        
CURSOR sys_med_flag_pat (v_code pat_activity_details.code%type) is		 
SELECT pat.rule_limit,pad.sys_med_copay as sys_copay,pat.benifit_copay as act_copay,pat.gross_amount gross_amount,pat.out_of_pocket_amount,
        pat.benifit_deductible as rule_deduct,diag.deduct as diag_deduct,pat.copay_deduct_flag,pat.override_yn,pat.activity_dtl_seq_id,rule_unit,pat.discount_amount as dis_amt,
        pad.sys_med_deductible as sys_deductible
       ,pat.approve_yn
       FROM pat_authorization_details pad
       JOIN pat_activity_details pat on (pad.pat_auth_seq_id=pat.pat_auth_seq_id)
       JOIN diagnosys_details diag on (diag.pat_auth_seq_id=pad.pat_auth_seq_id)
       LEFT JOIN tpa_activity_details G ON (pat.code = G.ACTIVITY_CODE)
       --LEFT JOIN tpa_activity_details gg ON (g.master_activity_code = gg.master_activity_code )
       LEFT JOIN tpa_activity_master_details M ON (pat.code = M.ACTIVITY_CODE)
       --LEFT JOIN tpa_activity_master_details Ma ON (m.master_activity_code = Ma.Master_Activity_Code)
       WHERE (g.master_activity_code=v_code or m.master_activity_code = v_code) and pad.pat_auth_seq_id = v_seq_id
       AND diag.primary_ailment_yn='Y'  AND pat.code<>'AC001' 
       order by pat.activity_dtl_seq_id;
             
CURSOR sys_med_flag_act_clm is
SELECT distinct nvl(g.master_activity_code,m.master_activity_code) as master_activity_code,NVL(sys_med_yn,'N') AS sys_med_yn,nvl(clm.sys_med_limit,v_ava_sum_ins) as sys_med_limit,diag.rule_limit as icd_limit,
       clm.sys_med_copay as sys_copay, diag.copay as diag_copay,pad.benifit_copay as act_copay,diag.deduct as diag_deduct,
       clm.sys_med_deductible as sys_deductible
       
       FROM clm_authorization_details clm 
       JOIN pat_activity_details pad on (clm.claim_seq_id=pad.claim_seq_id)
       JOIN diagnosys_details diag on (diag.claim_seq_id=pad.claim_seq_id)
	     LEFT JOIN tpa_activity_details G ON (pad.code = G.ACTIVITY_CODE)
      -- LEFT JOIN tpa_activity_details gg ON (g.master_activity_code = gg.master_activity_code )
       LEFT JOIN tpa_activity_master_details M ON (pad.code = M.ACTIVITY_CODE)
      -- LEFT JOIN tpa_activity_master_details Ma ON (m.master_activity_code = Ma.Master_Activity_Code)
       WHERE clm.claim_seq_id = v_seq_id AND diag.primary_ailment_yn='Y'
       AND pad.code<>'AC001';             
             
CURSOR sys_med_flag_clm (v_code VARCHAR2) is
SELECT pad.rule_limit,clm.sys_med_copay as sys_copay,pad.benifit_copay as act_copay,pad.gross_amount gross_amount,pad.out_of_pocket_amount
       ,pad.benifit_deductible as rule_deduct,pad.copay_deduct_flag,pad.override_yn,pad.activity_dtl_seq_id,rule_unit,pad.discount_amount as dis_amt,pad.provider_net_amount,
       clm.sys_med_deductible as sys_deductible
       ,pad.approve_yn
       FROM clm_authorization_details clm 
       JOIN pat_activity_details pad on (clm.claim_seq_id=pad.claim_seq_id)
       JOIN diagnosys_details diag on (diag.claim_seq_id=pad.claim_seq_id)
	   LEFT JOIN tpa_activity_details G ON (pad.code = G.ACTIVITY_CODE)
       --LEFT JOIN tpa_activity_details gg ON (g.master_activity_code = gg.master_activity_code )
       LEFT JOIN tpa_activity_master_details M ON (pad.code = M.ACTIVITY_CODE)
     --  LEFT JOIN tpa_activity_master_details Ma ON (m.master_activity_code = Ma.Master_Activity_Code)
       WHERE (g.master_activity_code=v_code or m.master_activity_code = v_code) and clm.claim_seq_id = v_seq_id
       AND diag.primary_ailment_yn='Y' AND pad.code<>'AC001' order by pad.activity_dtl_seq_id ; 
      
      
      CURSOR cur_clm_hosp_nme IS
  SELECT TRIM(REPLACE(H.HOSP_NAME,' ','')) AS HOSP_NAME 
  FROM app.clm_authorization_details ca
  JOIN app.clm_hospital_details h ON (ca.claim_seq_id=h.claim_seq_id)
  WHERE CA.CLAIM_SEQ_ID = v_seq_id;
    
  --Obesyti Cursor
  CURSOR pat_obesyti_cur IS
    SELECT DISTINCT D.DIAGNOSYS_CODE, NVL(P.BENEFIT_LIMIT, P.AVA_SUM_INSURED) AS BENEFIT_LIMIT,
           CASE WHEN NVL(A.MASTER_ACTIVITY_CODE, AC.MASTER_ACTIVITY_CODE) NOT IN ('11000', 'A9270') THEN 'MED' ELSE NVL(A.MASTER_ACTIVITY_CODE, AC.MASTER_ACTIVITY_CODE) END AS MASTER_ACTIVITY_CODE
    FROM PAT_AUTHORIZATION_DETAILS P
    JOIN DIAGNOSYS_DETAILS D ON D.PAT_AUTH_SEQ_ID = P.PAT_AUTH_SEQ_ID
    JOIN PAT_ACTIVITY_DETAILS PA ON PA.PAT_AUTH_SEQ_ID = P.PAT_AUTH_SEQ_ID
    LEFT JOIN TPA_ACTIVITY_DETAILS A ON A.ACTIVITY_CODE = PA.CODE
    LEFT JOIN TPA_ACTIVITY_MASTER_DETAILS AC ON AC.ACTIVITY_CODE = PA.CODE
    LEFT JOIN TPA_ICD10_MASTER_DETAILS ICD ON ICD.ICD_CODE = D.DIAGNOSYS_CODE
    JOIN TPA_ICD_CODES I ON I.ICD_CODE = ICD.ICD_CODE
    WHERE P.PAT_AUTH_SEQ_ID = v_seq_id
    AND I.MASTER_ICD_CODE = 'E66.9'
    AND D.PRIMARY_AILMENT_YN = 'Y'
    AND pa.code<>'AC001';

 CURSOR GET_CLM_GLOBAL_LIMIT IS 
  SELECT CASE WHEN  DICD.DAY_CARE_ICD_GROUP_ID='ICD001' THEN DD.RULE_LIMIT 
              WHEN ICD.MASTER_ICD_CODE='F09' THEN DD.RULE_LIMIT  ELSE v_ava_sum_ins END AS LIMIT
  FROM CLM_AUTHORIZATION_DETAILS PAT
  JOIN DIAGNOSYS_DETAILS DD ON (PAT.CLAIM_SEQ_ID=DD.CLAIM_SEQ_ID AND DD.PRIMARY_AILMENT_YN='Y')
  LEFT OUTER JOIN TPA_DAY_CARE_ICD DICD ON (DD.DIAGNOSYS_CODE=DICD.ICD_CODE)
  LEFT OUTER JOIN TPA_ICD_CODES ICD ON (DD.DIAGNOSYS_CODE=ICD.ICD_CODE)
  WHERE PAT.CLAIM_SEQ_ID=v_seq_id;
 
 CURSOR GET_PAT_GLOBAL_LIMIT IS   
        SELECT CASE WHEN  DICD.DAY_CARE_ICD_GROUP_ID='ICD001' THEN DD.RULE_LIMIT 
                  WHEN ICD.MASTER_ICD_CODE='F09' THEN DD.RULE_LIMIT  ELSE v_ava_sum_ins END AS LIMIT
      FROM PAT_AUTHORIZATION_DETAILS PAT
      JOIN DIAGNOSYS_DETAILS DD ON (PAT.PAT_AUTH_SEQ_ID=DD.PAT_AUTH_SEQ_ID AND DD.PRIMARY_AILMENT_YN='Y')
      LEFT OUTER JOIN TPA_DAY_CARE_ICD DICD ON (DD.DIAGNOSYS_CODE=DICD.ICD_CODE)
      LEFT OUTER JOIN TPA_ICD_CODES ICD ON (DD.DIAGNOSYS_CODE=ICD.ICD_CODE)
      where PAT.Pat_Auth_Seq_Id=v_seq_id;    
           
    
  CURSOR clm_obesyti_cur IS
    SELECT DISTINCT D.DIAGNOSYS_CODE, NVL(C.BENEFIT_LIMIT, C.AVA_SUM_INSURED) AS BENEFIT_LIMIT, C.PAT_APPROVED_AMOUNT,
           CASE WHEN NVL(A.MASTER_ACTIVITY_CODE, AC.MASTER_ACTIVITY_CODE) NOT IN ('11000', 'A9270') THEN 'MED' ELSE NVL(A.MASTER_ACTIVITY_CODE, AC.MASTER_ACTIVITY_CODE) END AS MASTER_ACTIVITY_CODE
           
    FROM CLM_AUTHORIZATION_DETAILS C
    JOIN DIAGNOSYS_DETAILS D ON D.CLAIM_SEQ_ID = C.CLAIM_SEQ_ID
    JOIN PAT_ACTIVITY_DETAILS PA ON PA.CLAIM_SEQ_ID = C.CLAIM_SEQ_ID
    LEFT JOIN TPA_ACTIVITY_DETAILS A ON A.ACTIVITY_CODE = PA.CODE
    LEFT JOIN TPA_ACTIVITY_MASTER_DETAILS AC ON AC.ACTIVITY_CODE = PA.CODE
    LEFT JOIN TPA_ICD10_MASTER_DETAILS ICD ON ICD.ICD_CODE = D.DIAGNOSYS_CODE
    JOIN TPA_ICD_CODES I ON I.ICD_CODE = ICD.ICD_CODE
    WHERE C.CLAIM_SEQ_ID = v_seq_id
    AND I.MASTER_ICD_CODE = 'E66.9'
    AND D.PRIMARY_AILMENT_YN = 'Y'
    AND pa.code<>'AC001';
    
  CURSOR pat_obesyti_med_act(v_mstr_code VARCHAR2) IS
    SELECT p.code, nvl(p.approved_amount, 0) as approved_amount, p.override_yn, p.activity_dtl_seq_id,p.rule_limit as rule_limit
    FROM pat_authorization_details pa
    JOIN pat_activity_details p ON pa.pat_auth_seq_id = p.pat_auth_seq_id
    LEFT JOIN tpa_activity_details G ON (p.code = G.ACTIVITY_CODE)
    LEFT JOIN tpa_activity_master_details m ON (p.code = M.ACTIVITY_CODE)
    WHERE pa.pat_auth_seq_id = v_seq_id AND p.code<>'AC001'
    AND NVL(m.master_activity_code, g.master_activity_code) NOT IN ('A9270', '11000');
    
  CURSOR pat_obesyti_act(v_mstr_code VARCHAR2) IS
    SELECT p.code, nvl(p.approved_amount, 0) as approved_amount, p.override_yn, p.activity_dtl_seq_id,p.rule_limit as rule_limit
    FROM pat_authorization_details pa
    JOIN pat_activity_details p ON pa.pat_auth_seq_id = p.pat_auth_seq_id
    LEFT JOIN tpa_activity_details G ON (p.code = G.ACTIVITY_CODE)
    LEFT JOIN tpa_activity_master_details m ON (p.code = M.ACTIVITY_CODE)
    WHERE pa.pat_auth_seq_id = v_seq_id AND p.code<>'AC001'
    AND NVL(m.master_activity_code, g.master_activity_code) = v_mstr_code
    AND v_mstr_code IN ('A9270', '11000');
    --AND (m.master_activity_code = v_mstr_code OR (v_mstr_code = 'MED' AND m.master_activity_code NOT IN ('A9270', '11000')));
    
  CURSOR clm_obesyti_med_act(v_mstr_code VARCHAR2) IS
    SELECT p.code, nvl(p.approved_amount, 0) as approved_amount, p.override_yn, p.activity_dtl_seq_id,p.rule_limit as rule_limit
    FROM clm_authorization_details c
    JOIN pat_activity_details p ON p.claim_seq_id = c.claim_seq_id
    LEFT JOIN tpa_activity_details G ON (p.code = G.ACTIVITY_CODE)
    LEFT JOIN tpa_activity_master_details m ON (p.code = M.ACTIVITY_CODE)
    WHERE c.claim_seq_id = v_seq_id AND p.code<>'AC001'
    AND NVL(m.master_activity_code, g.master_activity_code) NOT IN ('A9270', '11000');
    
  CURSOR clm_obesyti_act(v_mstr_code VARCHAR2) IS
    SELECT p.code, nvl(p.approved_amount, 0) as approved_amount, p.override_yn, p.activity_dtl_seq_id,p.rule_limit as rule_limit
    FROM clm_authorization_details c
    JOIN pat_activity_details p ON p.claim_seq_id = c.claim_seq_id
    LEFT JOIN tpa_activity_details G ON (p.code = G.ACTIVITY_CODE)
    LEFT JOIN tpa_activity_master_details m ON (p.code = M.ACTIVITY_CODE)
    WHERE c.claim_seq_id = v_seq_id AND p.code<>'AC001'
    AND NVL(m.master_activity_code, g.master_activity_code) = v_mstr_code
    AND v_mstr_code IN ('A9270', '11000');
    --AND (m.master_activity_code = v_mstr_code OR (v_mstr_code = 'MED' AND m.master_activity_code NOT IN ('A9270', '11000')));
    
 CURSOR pat_prim_icd_cur IS
   SELECT I.MASTER_ICD_CODE
   FROM PAT_AUTHORIZATION_DETAILS P
   JOIN DIAGNOSYS_DETAILS D ON D.PAT_AUTH_SEQ_ID = P.PAT_AUTH_SEQ_ID
   JOIN TPA_ICD_CODES I ON I.ICD_CODE = D.DIAGNOSYS_CODE
   WHERE P.PAT_AUTH_SEQ_ID = v_seq_id
   AND D.PRIMARY_AILMENT_YN = 'Y';
   
 CURSOR clm_prim_icd_cur IS
   SELECT I.MASTER_ICD_CODE
   FROM CLM_AUTHORIZATION_DETAILS C
   JOIN DIAGNOSYS_DETAILS D ON D.CLAIM_SEQ_ID = C.CLAIM_SEQ_ID
   JOIN TPA_ICD_CODES I ON I.ICD_CODE = D.DIAGNOSYS_CODE
   WHERE C.CLAIM_SEQ_ID = v_seq_id
   AND D.PRIMARY_AILMENT_YN = 'Y';
   
 -- IF MASTER ACTIVITY CODE IS MED IN OBESITY RULE IF 
 CURSOR pat_act_mstr_cur IS
   SELECT PA.CODE, NVL(A.MASTER_ACTIVITY_CODE, AC.MASTER_ACTIVITY_CODE) AS MASTER_ACTIVITY_CODE
   
   FROM PAT_AUTHORIZATION_DETAILS P
   JOIN PAT_ACTIVITY_DETAILS PA ON PA.PAT_AUTH_SEQ_ID = P.PAT_AUTH_SEQ_ID
   LEFT JOIN TPA_ACTIVITY_DETAILS A ON A.ACTIVITY_CODE = PA.CODE
   LEFT JOIN TPA_ACTIVITY_MASTER_DETAILS AC ON AC.ACTIVITY_CODE = PA.CODE
   WHERE P.PAT_AUTH_SEQ_ID = v_seq_id AND pa.code<>'AC001'
   AND NVL(A.MASTER_ACTIVITY_CODE, AC.MASTER_ACTIVITY_CODE) NOT IN ('A9270', '11000');
   
 CURSOR clm_act_mstr_cur IS
   SELECT PA.CODE, NVL(A.MASTER_ACTIVITY_CODE, AC.MASTER_ACTIVITY_CODE) AS MASTER_ACTIVITY_CODE
   
   FROM CLM_AUTHORIZATION_DETAILS C
   JOIN PAT_ACTIVITY_DETAILS PA ON PA.CLAIM_SEQ_ID = C.CLAIM_SEQ_ID
   LEFT JOIN TPA_ACTIVITY_DETAILS A ON A.ACTIVITY_CODE = PA.CODE
   LEFT JOIN TPA_ACTIVITY_MASTER_DETAILS AC ON AC.ACTIVITY_CODE = PA.CODE
   WHERE C.CLAIM_SEQ_ID = v_seq_id AND pa.code<>'AC001'
   AND NVL(A.MASTER_ACTIVITY_CODE, AC.MASTER_ACTIVITY_CODE) NOT IN ('A9270', '11000'); 
   
v_prim_icd           VARCHAR2(10);   
icd_psyclm_limit     psy_actclm_cur%ROWTYPE;
icd_psy_limit         psy_act_cur%ROWTYPE;         
icd_psy_pat_rec           pat_psy_icd_cur%ROWTYPE;
icd_psy_rec               clm_psy_icd_cur%ROWTYPE; 
pat_sys                  sys_med_flag_act_pat%ROWTYPE;
clm_sys                  sys_med_flag_act_clm%ROWTYPE;
icd_rec                   pat_icd_cur%ROWTYPE;    
act_rec                   act_cur_pat%ROWTYPE;
v_item_sum                NUMBER(12,2);
v_rest_amount             NUMBER(12,2):=0;
v_remain_amount           NUMBER(12,2);
v_claim_type              clm_authorization_details.claim_type%type;
v_benefit_type            varchar2(100);
v_pat_aprov_amount        varchar2(100):=0;
V_PRE_AUTH_SEQ_ID        NUMBER(10);
sys_med                   VARCHAR2(2);
v_fin_rest_amount         NUMBER(12,2);
v_sys_copay               NUMBER(5);
v_sys_deduct              NUMBER(5);
v_patient_share           NUMBER(5);
v_copay_amount            NUMBER(5);
v_appr_amt                NUMBER(15, 3);
v_act_use_amt             NUMBER(5);
V_HOSP_NAME               VARCHAR2(2000);

v_dntl_used_amt           NUMBER(12,2) := 0;
v_used_amount             NUMBER(12,3) := 0;
v_act_appr_amount         NUMBER(12,3);
v_rest_used_amount        NUMBER(12,3);
v_sub_type                VARCHAR2(10);
v_res_limit               number(20,2);

v_mat                     varchar2(10);
v_sys_deductible          NUMBER(10, 3);
v_glob_limit              NUMBER(30);
v_rule_flag               VARCHAR2(10);
v_glb_limit               NUMBER(30,2);
v_res_limit1              number(20,2);
v_rest_amount1            NUMBER(12,2):=0;
v_act_appr_amount1        NUMBER(12,3);
v_remain_amount1          NUMBER(12,2);
v_used_amount1            NUMBER(12,3) := 0;



BEGIN

Set_Member_Sum_insured(v_mode,v_seq_id);

  IF v_mode='PAT' THEN
  
  OPEN pat_prim_icd_cur;
  FETCH pat_prim_icd_cur INTO v_prim_icd;
  CLOSE pat_prim_icd_cur;
  
select pad.benifit_type,pad.MATERNITY_YN,pad.benefit_limit,pad.limit_applied_flag  
         into v_benefit_type,v_mat,v_glob_limit,v_rule_flag 
    from app.pat_authorization_details pad 
    where pad.pat_auth_seq_id=v_seq_id;
  if v_allowed_amt>0 then  
  OPEN pat_icd_cur;
  FETCH pat_icd_cur INTO icd_rec;
  CLOSE pat_icd_cur;
    
    OPEN pat_psy_icd_cur;
  FETCH pat_psy_icd_cur INTO icd_psy_pat_rec;
  CLOSE pat_psy_icd_cur;
  
   OPEN psy_act_cur;
  FETCH psy_act_cur INTO icd_psy_limit;
  CLOSE psy_act_cur;
   
    IF v_prim_icd = 'E66.9' THEN
     
       FOR obs IN pat_obesyti_cur LOOP
         v_dntl_used_amt := 0;
         v_appr_amt := case when (obs.benefit_limit - v_used_amount) > 0 then (obs.benefit_limit - v_used_amount) else 0 end;
         
         IF obs.master_activity_code = 'MED' THEN
           v_remain_amount := NULL;
             FOR rec in pat_obesyti_med_act(obs.master_activity_code) LOOP
               rec.rule_limit := rec.rule_limit - v_dntl_used_amt;
               
               if v_appr_amt > rec.rule_limit then
                 v_appr_amt := rec.rule_limit;
               else
                 v_appr_amt := v_appr_amt;
               end if;
               ----
               if v_appr_amt > rec.approved_amount then
                v_rest_amount := rec.approved_amount;
              else
                v_rest_amount := v_appr_amt;
              end if;
              -------
              v_remain_amount := case when nvl(v_remain_amount, v_appr_amt) - v_rest_amount > 0 then nvl(v_remain_amount, v_appr_amt) - v_rest_amount else 0 end;
              v_used_amount := nvl(v_used_amount, 0) + v_rest_amount;
              v_dntl_used_amt := nvl(v_dntl_used_amt, 0) + nvl(v_rest_amount, 0);
              
              UPDATE pat_activity_details pad
                SET pad.approved_amount = case when v_rest_amount>0 then v_rest_amount else 0 end,
                    pad.allowed_amount =  case when v_rest_amount>0 then v_rest_amount else 0 end,
                    pad.remarks     = case when (pad.approved_amount > v_rest_amount) then case when pad.remarks is null then 'The claimed amount is more than the allowed limit as per  policy benefits.Hence the amount over and above the allowed limit is disallowed' else case when pad.denial_code like '%BENX-005%' then pad.remarks else pad.remarks || ';' ||'The claimed amount is more than the allowed limit as per  policy benefits.Hence the amount over and above the allowed limit is disallowed' end end else pad.remarks end,
                    pad.denial_desc = case when (obs.benefit_limit > 0) AND (pad.approved_amount>v_rest_amount) then 
                                        pad.denial_desc||';'||'Obesyti limit has been exceeded '
                                      else
                                        case when pad.approved_amount>v_rest_amount then  case when pad.denial_desc is  null then 'Annual limit/sublimit amount exceeded' else case when pad.denial_code like '%BENX-005%'then pad.denial_desc else pad.denial_desc||';'||'Annual limit/sublimit amount exceeded' end end else pad.denial_desc end
                                      end,
                    pad.denial_code = case when pad.approved_amount>v_rest_amount then 
                                         case when pad.denial_code is null then 
                                           'BENX-005' 
                                         else 
                                           case when pad.denial_code like '%BENX-005%' then 
                                             pad.denial_code 
                                           else 
                                             pad.denial_code||';'||'BENX-005' 
                                           end 
                                         end 
                                      else 
                                        pad.denial_code
                                      end,
                    pad.benifit_deductible=NVL(benifit_deductible,icd_rec.deduct),
                    pad.updated_by = v_added_by,
                    pad.updated_date = SYSDATE,
                    pad.denial_by_rule_proc_dtls    = case when (pad.approved_amount > v_rest_amount)  then
                                                                TRIM(BOTH ';' FROM (pad.denial_by_rule_proc_dtls||';'||CHR(10)||'authorization_pkg.check_activity_limits'))
                                                           else pad.denial_by_rule_proc_dtls end,
                    pad.denial_by_resons            = case when (pad.approved_amount > v_rest_amount)  then
                                                                TRIM(BOTH ';' FROM (pad.denial_by_resons||';'||CHR(10)||'Dental limit exhausted'))        
                                                           else denial_by_resons end
                 WHERE pad.activity_dtl_seq_id = rec.activity_dtl_seq_id;
          
             v_appr_amt := v_remain_amount;
               
             END LOOP;
         ELSE------------------------MED
           FOR rec in pat_obesyti_act(obs.master_activity_code) LOOP
             v_remain_amount := NULL;
             rec.rule_limit := rec.rule_limit - v_dntl_used_amt;
             
             if v_appr_amt > rec.rule_limit then
               v_appr_amt := rec.rule_limit;
             else
               v_appr_amt := v_appr_amt;
             end if;
             ----
             if v_appr_amt > rec.approved_amount then
              v_rest_amount := rec.approved_amount;
            else
              v_rest_amount := v_appr_amt;
            end if;
            -------
            v_remain_amount := case when nvl(v_remain_amount, v_appr_amt) - v_rest_amount > 0 then nvl(v_remain_amount, v_appr_amt) - v_rest_amount else 0 end;
            v_used_amount := nvl(v_used_amount, 0) + v_rest_amount;
            v_dntl_used_amt := nvl(v_dntl_used_amt, 0) + nvl(v_rest_amount, 0);
            
            UPDATE pat_activity_details pad
              SET pad.approved_amount = case when v_rest_amount>0 then v_rest_amount else 0 end,
                  pad.allowed_amount =  case when v_rest_amount>0 then v_rest_amount else 0 end,
                  pad.remarks     = case when (pad.approved_amount > v_rest_amount) then case when pad.remarks is null then 'The claimed amount is more than the allowed limit as per  policy benefits.Hence the amount over and above the allowed limit is disallowed' else case when pad.denial_code like '%BENX-005%' then pad.remarks else pad.remarks || ';' ||'The claimed amount is more than the allowed limit as per  policy benefits.Hence the amount over and above the allowed limit is disallowed' end end else pad.remarks end,
                  pad.denial_desc = case when (obs.benefit_limit > 0) AND (pad.approved_amount>v_rest_amount) then 
                                      pad.denial_desc||';'||'Obesyti limit has been exceeded '
                                    else
                                      case when pad.approved_amount>v_rest_amount then  case when pad.denial_desc is  null then 'Annual limit/sublimit amount exceeded' else case when pad.denial_code like '%BENX-005%'then pad.denial_desc else pad.denial_desc||';'||'Annual limit/sublimit amount exceeded' end end else pad.denial_desc end
                                    end,
                  pad.denial_code = case when pad.approved_amount>v_rest_amount then case when pad.denial_code is  null then 'BENX-005' else case when pad.denial_code like '%BENX-005%'then pad.denial_code else pad.denial_code||';'||'BENX-005' end end else pad.denial_code end,
                  pad.benifit_deductible=NVL(benifit_deductible,icd_rec.deduct),
                  pad.updated_by = v_added_by,
                  pad.updated_date = SYSDATE,
                  pad.denial_by_rule_proc_dtls    = case when (pad.approved_amount > v_rest_amount)  then
                                                              TRIM(BOTH ';' FROM (pad.denial_by_rule_proc_dtls||';'||CHR(10)||'authorization_pkg.check_activity_limits'))
                                                         else pad.denial_by_rule_proc_dtls end,
                  pad.denial_by_resons            = case when (pad.approved_amount > v_rest_amount)  then
                                                              TRIM(BOTH ';' FROM (pad.denial_by_resons||';'||CHR(10)||'Dental limit exhausted'))        
                                                         else denial_by_resons end
               WHERE pad.activity_dtl_seq_id = rec.activity_dtl_seq_id;
        
          v_appr_amt := v_remain_amount;
             
           END LOOP;
         END IF;
       END LOOP;
    
    elsif icd_rec.day_care_icd_group_id='ICD001' and icd_rec.benifit_type= 'OPTS' AND NVL(icd_psy_rec.master_icd_code, 'NA') NOT IN ('F09', 'B20', 'E66.9', 'E55.9', 'Q00.0', 'C80.1', 'A65', 'Z00.121', 'B16.9', 'B17.11') AND icd_rec.limit_applied_flag IN ('OCL','TSI') then 
     
     IF icd_rec.limit_applied_flag='TSI' THEN
        v_glob_limit:=icd_rec.sum_ins;
     ELSE 
        v_glob_limit:=nvl(icd_rec.rule_limit,0);
     END IF;
     
    FOR p_rec in pat_master_code_cur LOOP
         
          v_glb_limit := v_glob_limit - nvl(v_used_amount,0);
          
          IF v_glb_limit IS NOT NULL AND p_rec.rule_limit IS NOT NULL THEN 
                 v_rest_amount:= LEAST (v_glb_limit,p_rec.rule_limit);
          ELSIF v_glb_limit IS NULL AND p_rec.rule_limit IS NOT NULL THEN 
                 v_rest_amount :=  p_rec.rule_limit;
          ELSIF v_glb_limit IS NOT NULL AND p_rec.rule_limit IS NULL THEN       
                v_rest_amount := v_glb_limit;
          END IF;
          
          v_rest_amount := v_rest_amount;
      v_act_appr_amount :=v_rest_amount;
          v_remain_amount :=null;
         FOR c_rec in pat_act_cur (p_rec.master_activity_code) loop
          
          IF v_rest_amount IS NOT NULL AND c_rec.rule_limit IS NOT NULL THEN
            v_rest_amount := least(v_rest_amount,c_rec.rule_limit);
          ELSIF v_rest_amount IS NOT NULL AND c_rec.rule_limit IS NULL THEN
        v_rest_amount := v_rest_amount;
          ELSIF v_rest_amount IS NULL AND c_rec.rule_limit IS NOT NULL THEN
            v_rest_amount := c_rec.rule_limit;
      END IF;
      
          v_rest_amount:=CASE WHEN c_rec.approved_amount>v_rest_amount  THEN v_rest_amount  WHEN c_rec.approved_amount<=v_rest_amount  THEN c_rec.approved_amount  ELSE v_rest_amount END;
      v_remain_amount:=nvl(v_remain_amount,v_act_appr_amount)-v_rest_amount;
       UPDATE pat_activity_details pad
        SET pad.approved_amount = case when v_rest_amount>0 then v_rest_amount else 0 end,
            pad.allowed_amount =  case when v_rest_amount>0 then v_rest_amount else 0 end,
            pad.remarks     = case when (pad.approved_amount > v_rest_amount)  then case when pad.remarks is  null then ' Chronic limit has been exceeded' else case when pad.denial_code like '%BENX-005%'then ' Chronic limit has been exceeded' else pad.remarks||';'||' Chronic limit has been exceeded' end end else pad.remarks end,
            pad.denial_desc = case when (pad.approved_amount > v_rest_amount)  then  case when pad.denial_desc is  null then 'Annual limit/sublimit amount exceeded' else case when pad.denial_code like '%BENX-005%'then pad.denial_desc else pad.denial_desc||';'||'Annual limit/sublimit amount exceeded' end end else pad.denial_desc end,
            pad.denial_code = case when (pad.approved_amount > v_rest_amount)  then case when pad.denial_code is  null then 'BENX-005' else case when pad.denial_code like '%BENX-005%'then pad.denial_code else pad.denial_code||';'||'BENX-005' end end else pad.denial_code end,
            pad.tpa_denial_desc = case when (pad.approved_amount > v_rest_amount)  then  case when pad.tpa_denial_desc is  null then 'Annual limit/sublimit amount exceeded' else case when pad.tpa_denial_code like '%BENX-005%'then pad.tpa_denial_desc else pad.tpa_denial_desc||';'||'Annual limit/sublimit amount exceeded' end end else pad.tpa_denial_desc end,
            pad.tpa_denial_code = case when (pad.approved_amount > v_rest_amount)  then case when pad.tpa_denial_code is  null then 'BENX-005' else case when pad.tpa_denial_code like '%BENX-005%'then pad.tpa_denial_code else pad.tpa_denial_code||';'||'BENX-005' end end else pad.tpa_denial_code end,
            pad.benifit_deductible=NVL(benifit_deductible,icd_rec.deduct),
            pad.updated_by = v_added_by,
            pad.updated_date = SYSDATE,
            pad.denial_by_rule_proc_dtls    = case when (pad.approved_amount > v_rest_amount)  then
                                                        TRIM(BOTH ';' FROM (pad.denial_by_rule_proc_dtls||';'||CHR(10)||'authorization_pkg.check_activity_limits'))
                                                   else pad.denial_by_rule_proc_dtls end,
            pad.denial_by_resons            = case when (pad.approved_amount > v_rest_amount)  then
                                                        TRIM(BOTH ';' FROM (pad.denial_by_resons||';'||CHR(10)||'Chronic limit exhausted'))        
                                                   else denial_by_resons end
          WHERE pad.activity_dtl_seq_id = c_rec.activity_dtl_seq_id;
            v_used_amount := nvl(v_used_amount,0)+v_rest_amount;
      v_act_appr_amount := v_act_appr_amount- v_rest_amount;
      v_rest_amount:=v_remain_amount;
     END LOOP;
       END LOOP;  
 ELSIF icd_rec.day_care_icd_group_id='ICD001' and icd_rec.benifit_type= 'IPT' AND icd_rec.limit_applied_flag IN ('OCL','TSI') then 
     
     IF icd_rec.limit_applied_flag='TSI' THEN
        v_glob_limit:=icd_rec.sum_ins;
     ELSE 
        v_glob_limit:=nvl(icd_rec.rule_limit,0);
     END IF;
     
    FOR p_rec in pat_master_code_cur LOOP
         
             v_glb_limit:=v_glob_limit - nvl(v_used_amount,0);
              
          IF v_glb_limit IS NOT NULL AND p_rec.rule_limit IS NOT NULL THEN 
                 v_rest_amount:= LEAST (v_glb_limit,p_rec.rule_limit);
          ELSIF v_glb_limit IS NULL AND p_rec.rule_limit IS NOT NULL THEN 
                 v_rest_amount :=  p_rec.rule_limit;
          ELSIF v_glb_limit IS NOT NULL AND p_rec.rule_limit IS NULL THEN       
                v_rest_amount := v_glb_limit;
          END IF;
          
          v_rest_amount := v_rest_amount;
      v_act_appr_amount :=v_rest_amount; 
           v_remain_amount :=null;
         FOR c_rec in pat_act_cur (p_rec.master_activity_code) loop
          
          IF v_rest_amount IS NOT NULL AND c_rec.rule_limit IS NOT NULL THEN
            v_rest_amount := least(v_rest_amount,c_rec.rule_limit);
          ELSIF v_rest_amount IS NOT NULL AND c_rec.rule_limit IS NULL THEN
        v_rest_amount := v_rest_amount;
          ELSIF v_rest_amount IS NULL AND c_rec.rule_limit IS NOT NULL THEN
            v_rest_amount := c_rec.rule_limit;
      END IF;
      
          v_rest_amount:=CASE WHEN c_rec.approved_amount>v_rest_amount  THEN v_rest_amount  WHEN c_rec.approved_amount<=v_rest_amount  THEN c_rec.approved_amount  ELSE v_rest_amount END;
      v_remain_amount:=nvl(v_remain_amount,v_act_appr_amount)-v_rest_amount;
       UPDATE pat_activity_details pad
        SET pad.approved_amount = case when v_rest_amount>0 then v_rest_amount else 0 end,
            pad.allowed_amount =  case when v_rest_amount>0 then v_rest_amount else 0 end,
            pad.remarks     = case when (pad.approved_amount > v_rest_amount)  then case when pad.remarks is  null then ' Chronic limit has been exceeded' else case when pad.denial_code like '%BENX-005%'then ' Chronic limit has been exceeded' else pad.remarks||';'||' Chronic limit has been exceeded' end end else pad.remarks end,
            pad.denial_desc = case when (pad.approved_amount > v_rest_amount)  then  case when pad.denial_desc is  null then 'Annual limit/sublimit amount exceeded' else case when pad.denial_code like '%BENX-005%'then pad.denial_desc else pad.denial_desc||';'||'Annual limit/sublimit amount exceeded' end end else pad.denial_desc end,
            pad.denial_code = case when (pad.approved_amount > v_rest_amount)  then case when pad.denial_code is  null then 'BENX-005' else case when pad.denial_code like '%BENX-005%'then pad.denial_code else pad.denial_code||';'||'BENX-005' end end else pad.denial_code end,
            pad.benifit_deductible=NVL(benifit_deductible,icd_rec.deduct),
            pad.updated_by = v_added_by,
            pad.updated_date = SYSDATE,
            pad.denial_by_rule_proc_dtls    = case when (pad.approved_amount > v_rest_amount)  then
                                                        TRIM(BOTH ';' FROM (pad.denial_by_rule_proc_dtls||';'||CHR(10)||'authorization_pkg.check_activity_limits'))
                                                   else pad.denial_by_rule_proc_dtls end,
            pad.denial_by_resons            = case when (pad.approved_amount > v_rest_amount)  then
                                                        TRIM(BOTH ';' FROM (pad.denial_by_resons||';'||CHR(10)||'Chronic limit exhausted'))        
                                                   else denial_by_resons end
          WHERE pad.activity_dtl_seq_id = c_rec.activity_dtl_seq_id;
            v_used_amount := nvl(v_used_amount,0)+v_rest_amount;
      v_act_appr_amount := v_act_appr_amount-v_rest_amount;
      v_rest_amount:=v_remain_amount;
     END LOOP;   
       END LOOP;  
 
 ELSIF NVL(icd_psy_pat_rec.master_icd_code, 'NA') IN ('F09', 'B20', 'E55.9', 'Q00.0', 'C80.1', 'A65', 'Z00.121', 'B16.9', 'B17.11') AND v_benefit_type NOT IN ('HEAC', 'IEMA', 'IPRE', 'PAHC', 'MTI', 'IMTI', 'OMTI')  AND icd_psy_pat_rec.limit_applied_flag IN ('OPL','TSI') then-- and icd_rec.benifit_type= 'OPTS' THEN 
         
     IF icd_psy_pat_rec.limit_applied_flag='TSI' THEN
        v_glob_limit:=icd_psy_pat_rec.sum_ins;
       ELSE 
        v_glob_limit:=nvl(icd_psy_pat_rec.rule_limit,0); 
       END IF;
 
    FOR p_rec in pat_master_code_cur LOOP
         
             v_glb_limit:=v_glob_limit - nvl(v_used_amount,0);
              
          IF v_glb_limit IS NOT NULL AND p_rec.rule_limit IS NOT NULL THEN 
                 v_rest_amount:= LEAST (v_glb_limit,p_rec.rule_limit);
          ELSIF v_glb_limit IS NULL AND p_rec.rule_limit IS NOT NULL THEN 
                 v_rest_amount :=  p_rec.rule_limit;
          ELSIF v_glb_limit IS NOT NULL AND p_rec.rule_limit IS NULL THEN       
                v_rest_amount := v_glb_limit;
          END IF;
          
          v_rest_amount := v_rest_amount;
       v_act_appr_amount := v_rest_amount;
           v_remain_amount :=null;
         FOR c_rec in pat_act_cur (p_rec.master_activity_code) loop
          
          IF v_rest_amount IS NOT NULL AND c_rec.rule_limit IS NOT NULL THEN
            v_rest_amount := least(v_rest_amount,c_rec.rule_limit);
          ELSIF v_rest_amount IS NOT NULL AND c_rec.rule_limit IS NULL THEN
            v_rest_amount := v_rest_amount;
          ELSIF v_rest_amount IS NULL AND c_rec.rule_limit IS NOT NULL THEN
            v_rest_amount := c_rec.rule_limit;
          END IF;
          
          v_rest_amount:=CASE WHEN c_rec.approved_amount>v_rest_amount  THEN v_rest_amount  WHEN c_rec.approved_amount<=v_rest_amount  THEN c_rec.approved_amount  ELSE v_rest_amount END;
      v_remain_amount:=nvl(v_remain_amount,v_act_appr_amount)-v_rest_amount;
       UPDATE pat_activity_details pad
        SET pad.approved_amount = case when v_rest_amount>0 then v_rest_amount else 0 end,
            pad.allowed_amount =  case when v_rest_amount>0 then v_rest_amount else 0 end,
            pad.remarks =  case when pad.approved_amount>v_rest_amount then case when pad.remarks is  null then ' Anual limit/sublimit has been exceeded' else case when pad.denial_code like '%BENX-005%'then ' Anual limit/sublimit has been exceeded' else trim(LEADING ';' FROM pad.remarks||';'||' Psychiatric limit has been exceeded') end end else pad.remarks end,
            pad.denial_desc = case when pad.approved_amount>v_rest_amount then  case when pad.denial_desc is  null then 'Annual limit/sublimit amount exceeded' else case when pad.denial_code like '%BENX-005%'then pad.denial_desc else trim(LEADING ';' FROM pad.denial_desc||';'||'Annual limit/sublimit amount exceeded') end end else pad.denial_desc end,
            pad.denial_code = case when pad.approved_amount>v_rest_amount then case when pad.denial_code is  null then 'BENX-005' else case when pad.denial_code like '%BENX-005%'then pad.denial_code else trim(LEADING ';' FROM pad.denial_code||';'||'BENX-005') end end else pad.denial_code end,
            pad.tpa_denial_desc = case when (pad.approved_amount > v_rest_amount)  then  case when pad.tpa_denial_desc is  null then 'Annual limit/sublimit amount exceeded' else case when pad.tpa_denial_code like '%BENX-005%'then pad.tpa_denial_desc else pad.tpa_denial_desc||';'||'Annual limit/sublimit amount exceeded' end end else pad.tpa_denial_desc end,
            pad.tpa_denial_code = case when (pad.approved_amount > v_rest_amount)  then case when pad.tpa_denial_code is  null then 'BENX-005' else case when pad.tpa_denial_code like '%BENX-005%'then pad.tpa_denial_code else pad.tpa_denial_code||';'||'BENX-005' end end else pad.tpa_denial_code end,
            pad.benifit_deductible=pad.benifit_deductible,
            pad.updated_by = v_added_by,
                pad.updated_date = SYSDATE,
                pad.denial_by_rule_proc_dtls    = case when (pad.approved_amount > v_rest_amount)  then
                                                            TRIM(BOTH ';' FROM (pad.denial_by_rule_proc_dtls||';'||CHR(10)||'authorization_pkg.check_activity_limits'))
                                                       else pad.denial_by_rule_proc_dtls end,
                pad.denial_by_resons            = case when (pad.approved_amount > v_rest_amount)  then
                                                            TRIM(BOTH ';' FROM (pad.denial_by_resons||';'||CHR(10)||'Psychiatric limit exhausted'))        
                                                       else denial_by_resons end
          WHERE pad.activity_dtl_seq_id = c_rec.activity_dtl_seq_id;
            v_used_amount := nvl(v_used_amount,0)+v_rest_amount;
       v_act_appr_amount := v_act_appr_amount- v_rest_amount;
      v_rest_amount:=v_remain_amount;
     END LOOP;
       END LOOP;  
     -----

     elsif v_benefit_type = 'DNTL' then
      for dent in get_dent_grp_code_cur loop --Master Code
        v_remain_amount := NULL;
        v_dntl_used_amt := 0;
        
        v_appr_amt := case when (dent.benefit_limit - v_used_amount) > 0 then (dent.benefit_limit - v_used_amount) else 0 end;
        for rec in get_dent_code_cur(dent.specific_service_code) loop
          
          rec.rule_limit := rec.rule_limit - v_dntl_used_amt;
          
          if v_appr_amt > rec.rule_limit then
            v_appr_amt := rec.rule_limit;
          else
            v_appr_amt := v_appr_amt;
          end if;
          ------
          if v_appr_amt > rec.approved_amount then
            v_rest_amount := rec.approved_amount;
          else
            v_rest_amount := v_appr_amt;
          end if;
          -------
          v_remain_amount := case when nvl(v_remain_amount, v_appr_amt) - v_rest_amount > 0 then nvl(v_remain_amount, v_appr_amt) - v_rest_amount else 0 end;
          v_used_amount := nvl(v_used_amount, 0) + v_rest_amount;
          v_dntl_used_amt := nvl(v_dntl_used_amt, 0) + nvl(v_rest_amount, 0);
          
          UPDATE pat_activity_details pad
            SET pad.approved_amount = case when v_rest_amount>0 then v_rest_amount else 0 end,
                pad.allowed_amount =  case when v_rest_amount>0 then v_rest_amount else 0 end,
                pad.remarks     = case when (pad.approved_amount > v_rest_amount) then case when pad.remarks is null then 'The claimed amount is more than the allowed limit as per  policy benefits.Hence the amount over and above the allowed limit is disallowed' else case when pad.denial_code like '%BENX-005%' then pad.remarks else pad.remarks || ';' ||'The claimed amount is more than the allowed limit as per  policy benefits.Hence the amount over and above the allowed limit is disallowed' end end else pad.remarks end,
                pad.denial_desc = case when dent.ava_sum_insured > 0 AND dent.benefit_limit IS NULL then 
                                    pad.denial_desc||';'||'Dental limit has been exceeded '
                                  else
                                    case when pad.approved_amount>v_rest_amount then  case when pad.denial_desc is  null then 'Annual limit/sublimit amount exceeded' else case when pad.denial_code like '%BENX-005%'then pad.denial_desc else pad.denial_desc||';'||'Annual limit/sublimit amount exceeded' end end else pad.denial_desc end
                                  end,
                pad.denial_code = case when pad.approved_amount>v_rest_amount then case when pad.denial_code is  null then 'BENX-005' else case when pad.denial_code like '%BENX-005%'then pad.denial_code else pad.denial_code||';'||'BENX-005' end end else pad.denial_code end,
                pad.tpa_denial_desc = case when dent.ava_sum_insured > 0 AND dent.benefit_limit IS NULL then 
                                    pad.tpa_denial_desc||';'||'Dental limit has been exceeded '
                                  else
                                    case when pad.approved_amount>v_rest_amount then  case when pad.tpa_denial_desc is  null then 'Annual limit/sublimit amount exceeded' else case when pad.tpa_denial_code like '%BENX-005%'then pad.tpa_denial_desc else pad.tpa_denial_desc||';'||'Annual limit/sublimit amount exceeded' end end else pad.tpa_denial_desc end
                                  end,
                pad.tpa_denial_code = case when pad.approved_amount>v_rest_amount then case when pad.tpa_denial_code is  null then 'BENX-005' else case when pad.tpa_denial_code like '%BENX-005%'then pad.tpa_denial_code else pad.tpa_denial_code||';'||'BENX-005' end end else pad.tpa_denial_code end,
                pad.benifit_deductible=NVL(benifit_deductible,icd_rec.deduct),
                pad.updated_by = v_added_by,
                pad.updated_date = SYSDATE,
                pad.denial_by_rule_proc_dtls    = case when (pad.approved_amount > v_rest_amount)  then
                                                            TRIM(BOTH ';' FROM (pad.denial_by_rule_proc_dtls||';'||CHR(10)||'authorization_pkg.check_activity_limits'))
                                                       else pad.denial_by_rule_proc_dtls end,
                pad.denial_by_resons            = case when (pad.approved_amount > v_rest_amount)  then
                                                            TRIM(BOTH ';' FROM (pad.denial_by_resons||';'||CHR(10)||'Dental limit exhausted'))        
                                                       else denial_by_resons end
             WHERE pad.activity_dtl_seq_id = rec.activity_dtl_seq_id;
      
        v_appr_amt := v_remain_amount;
      end loop;
    end loop;
    ----------------------------
      
    elsif v_benefit_type IN ('MTI', 'IMTI', 'OMTI') OR NVL(v_mat,'N') = 'Y' then
    FOR dent in pat_dental_cur LOOP
     v_rest_amount:=nvl(dent.benefit_limit,0);
     FOR rec in pat_chronic_cur loop

      v_rest_amount:=CASE WHEN rec.approved_amount>v_rest_amount  THEN v_rest_amount  WHEN rec.approved_amount<=v_rest_amount  THEN rec.approved_amount  ELSE v_rest_amount END;
      v_remain_amount:=nvl(v_remain_amount,dent.benefit_limit)-v_rest_amount;
       UPDATE pat_activity_details pad
        SET pad.approved_amount = case when v_rest_amount>0 then v_rest_amount else 0 end,
            pad.allowed_amount =  case when v_rest_amount>0 then v_rest_amount else 0 end,
            pad.remarks     = case when (pad.approved_amount > v_rest_amount)  then case when pad.remarks is  null then 'The claimed amount is more than the allowed limit as per  policy benefits.Hence the amount over and above the allowed limit is disallowed' else case when pad.denial_code like '%BENX-005%'then pad.remarks else pad.remarks||';'||'The claimed amount is more than the allowed limit as per  policy benefits.Hence the amount over and above the allowed limit is disallowed' end end end,--else nvl(pad.remarks,'The claimed amount is more than the allowed limit as per  policy benefits.Hence the amount over and above the allowed limit is disallowed') end,
            pad.denial_desc = case when (pad.approved_amount > v_rest_amount)  then  case when pad.denial_desc is  null then 'Annual limit/sublimit amount exceeded' else case when pad.denial_code like '%BENX-005%'then pad.denial_desc else pad.denial_desc||';'||'Annual limit/sublimit amount exceeded' end end else pad.denial_desc end,
            pad.denial_code = case when (pad.approved_amount > v_rest_amount)  then case when pad.denial_code is  null then 'BENX-005' else case when pad.denial_code like '%BENX-005%'then pad.denial_code else pad.denial_code||';'||'BENX-005' end end else pad.denial_code end,
            pad.tpa_denial_desc = case when (pad.approved_amount > v_rest_amount)  then  case when pad.tpa_denial_desc is  null then 'Annual limit/sublimit amount exceeded' else case when pad.tpa_denial_code like '%BENX-005%'then pad.tpa_denial_desc else pad.tpa_denial_desc||';'||'Annual limit/sublimit amount exceeded' end end else pad.tpa_denial_desc end,
            pad.tpa_denial_code = case when (pad.approved_amount > v_rest_amount)  then case when pad.tpa_denial_code is  null then 'BENX-005' else case when pad.tpa_denial_code like '%BENX-005%'then pad.tpa_denial_code else pad.tpa_denial_code||';'||'BENX-005' end end else pad.tpa_denial_code end,
            --pad.benifit_deductible=icd_rec.deduct,
            pad.updated_by = v_added_by,
            pad.updated_date = SYSDATE,
            pad.denial_by_rule_proc_dtls    = case when (pad.approved_amount > v_rest_amount)  then
                                                        TRIM(BOTH ';' FROM (pad.denial_by_rule_proc_dtls||';'||CHR(10)||'authorization_pkg.check_activity_limits'))
                                                   else pad.denial_by_rule_proc_dtls end,
            pad.denial_by_resons            = case when (pad.approved_amount > v_rest_amount)  then
                                                        TRIM(BOTH ';' FROM (pad.denial_by_resons||';'||CHR(10)||'Maternity limit exhausted'))        
                                                   else denial_by_resons end
      WHERE pad.activity_dtl_seq_id = rec.activity_dtl_seq_id;
      v_rest_amount:=v_remain_amount;

     END LOOP;
    END LOOP;   
  elsif v_benefit_type ='OPTS' AND NVL(v_rule_flag,'WOP')='WOP' THEN
  
  
       OPEN GET_PAT_GLOBAL_LIMIT;
         FETCH GET_PAT_GLOBAL_LIMIT INTO v_glb_limit;
           CLOSE GET_PAT_GLOBAL_LIMIT;
           
        IF v_glb_limit IS NOT NULL AND v_glob_limit IS NOT NULL THEN    
             v_glob_limit:=Least(v_glob_limit,v_glb_limit);
        ELSIF v_glb_limit IS NULL AND v_glob_limit IS NOT NULL THEN 
               v_glob_limit := v_glob_limit;
        ELSIF v_glb_limit IS NOT NULL AND v_glob_limit IS NULL THEN 
               v_glob_limit := v_glb_limit;       
        END IF;    
             
  FOR  master_act in pat_master_code_cur LOOP
     IF (master_act.master_activity_code ='70450' and master_act.ct_flag ='Y') or
        (master_act.master_activity_code ='70551' and master_act.mri_flag ='Y') then
            v_res_limit1 := v_glb_limit - nvl(v_used_amount1,0); 
      IF v_res_limit1 IS NOT NULL AND master_act.RULE_LIMIT IS NOT NULL THEN 
          v_rest_amount1 := least(v_res_limit1,master_act.rule_limit);
      ELSIF v_res_limit1 IS NULL AND master_act.RULE_LIMIT IS NOT NULL THEN 
          v_rest_amount1 := master_act.RULE_LIMIT;
      ELSIF v_res_limit1 IS NOT NULL AND master_act.RULE_LIMIT IS NULL THEN 
          v_rest_amount1 := v_res_limit1;  
      END IF;
        v_rest_amount1 :=v_rest_amount1;
        v_act_appr_amount1 := v_rest_amount1;
        v_remain_amount1:=null;
        
    FOR child_act in pat_act_cur (master_act.master_activity_code) LOOP
           IF child_act.rule_limit IS NOT NULL AND v_rest_amount1 IS NOT NULL THEN
              v_rest_amount1:= least(v_rest_amount1,child_act.rule_limit);
           ELSIF  child_act.rule_limit IS NULL AND v_rest_amount1 IS NOT NULL THEN
              v_rest_amount1 := v_rest_amount1;
           END IF;
           
        v_rest_amount1:= case when child_act.allowed_amount>v_rest_amount1 then v_rest_amount1 else child_act.allowed_amount end;
        v_remain_amount1:= nvl(v_remain_amount1,v_act_appr_amount1)-NVL(v_rest_amount1,0);
          UPDATE pat_activity_details pad
                SET pad.approved_amount = case when v_rest_amount1>0 then v_rest_amount1 else 0 end,
                    pad.allowed_amount =  case when v_rest_amount1>0 then v_rest_amount1 else 0 end,
                    pad.remarks     = case when (pad.approved_amount > v_rest_amount1)  then case when pad.remarks is  null then 'The claimed amount is more than the allowed limit as per  policy benefits.Hence the amount over and above the allowed limit is disallowed' else case when pad.denial_code like '%BENX-005%'then pad.remarks else pad.remarks||';'||'The claimed amount is more than the allowed limit as per  policy benefits.Hence the amount over and above the allowed limit is disallowed' end end end,
                    pad.denial_desc = case when (pad.approved_amount > v_rest_amount1)  then  case when pad.denial_desc is  null then 'Annual limit/sublimit amount exceeded for op benifit' else case when pad.denial_code like '%BENX-005%'then pad.denial_desc else pad.denial_desc||';'||'Annual limit/sublimit amount exceeded for op benifit' end end else pad.denial_desc end,
                    pad.denial_code = case when (pad.approved_amount > v_rest_amount1)  then case when pad.denial_code is  null then 'BENX-005' else case when pad.denial_code like '%BENX-005%'then pad.denial_code else pad.denial_code||';'||'BENX-005' end end else pad.denial_code end,
                    pad.updated_by = v_added_by,
                    pad.updated_date = SYSDATE,
                    pad.denial_by_rule_proc_dtls    = case when (pad.approved_amount > v_rest_amount1)  then
                                                                TRIM(BOTH ';' FROM (pad.denial_by_rule_proc_dtls||';'||CHR(10)||'authorization_pkg.check_activity_limits'))
                                                           else pad.denial_by_rule_proc_dtls end,
                    pad.denial_by_resons            = case when (pad.approved_amount > v_rest_amount1)  then
                                                                TRIM(BOTH ';' FROM (pad.denial_by_resons||';'||CHR(10)||'outpatient limit exhausted'))        
                                                           else denial_by_resons end
              WHERE pad.activity_dtl_seq_id = child_act.activity_dtl_seq_id;
              v_used_amount1:=nvl(v_used_amount1,0)+v_rest_amount1;
              v_rest_amount1:=v_remain_amount1;
              v_act_appr_amount1 := v_act_appr_amount1-v_used_amount1;
       END LOOP;
     ELSE
           v_res_limit := v_glob_limit -nvl(v_used_amount,0);
      IF v_res_limit IS NOT NULL AND master_act.RULE_LIMIT IS NOT NULL THEN 
          v_rest_amount := least(v_res_limit,master_act.rule_limit);
      ELSIF v_res_limit IS NULL AND master_act.RULE_LIMIT IS NOT NULL THEN 
          v_rest_amount := master_act.RULE_LIMIT;
      ELSIF v_res_limit IS NOT NULL AND master_act.RULE_LIMIT IS NULL THEN 
          v_rest_amount := v_res_limit;  
      END IF;
      
        v_rest_amount :=v_rest_amount;
        v_act_appr_amount := v_rest_amount;
        v_remain_amount:=null;
    FOR child_act in pat_act_cur (master_act.master_activity_code) LOOP
           IF child_act.rule_limit IS NOT NULL AND v_rest_amount IS NOT NULL THEN
              v_rest_amount:= least(v_rest_amount,child_act.rule_limit);
           ELSIF  child_act.rule_limit IS NULL AND v_rest_amount IS NOT NULL THEN
              v_rest_amount := v_rest_amount;
           END IF;
           
        v_rest_amount:= case when child_act.allowed_amount>v_rest_amount then v_rest_amount else child_act.allowed_amount end;
        v_remain_amount:= nvl(v_remain_amount,v_act_appr_amount)-NVL(v_rest_amount,0);
          UPDATE pat_activity_details pad
                SET pad.approved_amount = case when v_rest_amount>0 then v_rest_amount else 0 end,
                    pad.allowed_amount =  case when v_rest_amount>0 then v_rest_amount else 0 end,
                    pad.remarks     = case when (pad.approved_amount > v_rest_amount)  then case when pad.remarks is  null then 'The claimed amount is more than the allowed limit as per  policy benefits.Hence the amount over and above the allowed limit is disallowed' else case when pad.denial_code like '%BENX-005%'then pad.remarks else pad.remarks||';'||'The claimed amount is more than the allowed limit as per  policy benefits.Hence the amount over and above the allowed limit is disallowed' end end end,
                    pad.denial_desc = case when (pad.approved_amount > v_rest_amount)  then  case when pad.denial_desc is  null then 'Annual limit/sublimit amount exceeded for op benifit' else case when pad.denial_code like '%BENX-005%'then pad.denial_desc else pad.denial_desc||';'||'Annual limit/sublimit amount exceeded for op benifit' end end else pad.denial_desc end,
                    pad.denial_code = case when (pad.approved_amount > v_rest_amount)  then case when pad.denial_code is  null then 'BENX-005' else case when pad.denial_code like '%BENX-005%'then pad.denial_code else pad.denial_code||';'||'BENX-005' end end else pad.denial_code end,
                    pad.updated_by = v_added_by,
                    pad.updated_date = SYSDATE,
                    pad.denial_by_rule_proc_dtls    = case when (pad.approved_amount > v_rest_amount)  then
                                                                TRIM(BOTH ';' FROM (pad.denial_by_rule_proc_dtls||';'||CHR(10)||'authorization_pkg.check_activity_limits'))
                                                           else pad.denial_by_rule_proc_dtls end,
                    pad.denial_by_resons            = case when (pad.approved_amount > v_rest_amount)  then
                                                                TRIM(BOTH ';' FROM (pad.denial_by_resons||';'||CHR(10)||'outpatient limit exhausted'))        
                                                           else denial_by_resons end
              WHERE pad.activity_dtl_seq_id = child_act.activity_dtl_seq_id;
              v_used_amount:=nvl(v_used_amount,0)+v_rest_amount;
              v_rest_amount:=v_remain_amount;
              v_act_appr_amount := v_act_appr_amount-v_used_amount;
       END LOOP;
      END IF; 
   END LOOP; 
else
     FOR master_code in pat_master_code_cur LOOP
     
      v_remain_amount:=null;
      v_used_amount := 0;
      v_rest_amount:=master_code.rule_limit  - case when master_code.master_activity_code = '11980' then 0 else v_used_amount end;
      v_rest_amount := case when v_rest_amount > 0 then v_rest_amount else 0 end;
      
     FOR rec in pat_act_cur(master_code.master_activity_code) loop

      if master_code.master_activity_code not in ('17.03','17.17') then
      v_rest_amount:=CASE WHEN rec.approved_amount>v_rest_amount  THEN v_rest_amount  WHEN rec.approved_amount<=v_rest_amount  THEN rec.approved_amount  ELSE v_rest_amount END;
      v_remain_amount:=nvl(v_remain_amount,master_code.rule_limit)-v_rest_amount;
      v_used_amount := nvl(v_used_amount, 0) + v_rest_amount;
      
       UPDATE pat_activity_details pad
        SET pad.approved_amount = case when v_rest_amount>0 then v_rest_amount else 0 end,
            pad.allowed_amount =  case when v_rest_amount>0 then v_rest_amount else 0 end,
            pad.remarks =  case when (pad.approved_amount > v_rest_amount)  then case when pad.remarks is  null then 'The claimed amount is more than the allowed limit as per  policy benefits.Hence the amount over and above the allowed limit is disallowed' else case when pad.denial_code like '%BENX-005%'then pad.remarks else pad.remarks||';'||'The claimed amount is more than the allowed limit as per  policy benefits.Hence the amount over and above the allowed limit is disallowed' end end else pad.remarks end,
            pad.denial_desc = case when (pad.approved_amount > v_rest_amount)  then  case when pad.denial_desc is  null then 'Annual limit/sublimit amount exceeded' else case when pad.denial_code like '%BENX-005%'then pad.denial_desc else pad.denial_desc||';'||'Annual limit/sublimit amount exceeded' end end else pad.denial_desc end,
            pad.denial_code = case when (pad.approved_amount > v_rest_amount)  then case when pad.denial_code is  null then 'BENX-005' else case when pad.denial_code like '%BENX-005%'then pad.denial_code else pad.denial_code||';'||'BENX-005' end end else pad.denial_code end,
            pad.tpa_denial_desc = case when (pad.approved_amount > v_rest_amount)  then  case when pad.tpa_denial_desc is  null then 'Annual limit/sublimit amount exceeded' else case when pad.tpa_denial_code like '%BENX-005%'then pad.tpa_denial_desc else pad.tpa_denial_desc||';'||'Annual limit/sublimit amount exceeded' end end else pad.tpa_denial_desc end,
            pad.tpa_denial_code = case when (pad.approved_amount > v_rest_amount)  then case when pad.tpa_denial_code is  null then 'BENX-005' else case when pad.tpa_denial_code like '%BENX-005%'then pad.tpa_denial_code else pad.tpa_denial_code||';'||'BENX-005' end end else pad.tpa_denial_code end,
            pad.updated_by = v_added_by,
            pad.updated_date = SYSDATE,
            pad.denial_by_rule_proc_dtls    = case when (pad.approved_amount > v_rest_amount)  then
                                                        TRIM(BOTH ';' FROM (pad.denial_by_rule_proc_dtls||';'||CHR(10)||'authorization_pkg.check_activity_limits'))
                                                   else pad.denial_by_rule_proc_dtls end,
            pad.denial_by_resons            = case when (pad.approved_amount > v_rest_amount)  then
                                                        TRIM(BOTH ';' FROM (pad.denial_by_resons||';'||CHR(10)||'Limit exhausted'))        
                                                   else denial_by_resons end
      WHERE pad.activity_dtl_seq_id = rec.activity_dtl_seq_id;
      v_rest_amount:=v_remain_amount;
       elsif master_code.master_activity_code  in ('17.03','17.17') and rec.rule_unit!='PD'  then 
         v_rest_amount:=CASE WHEN rec.approved_amount>v_rest_amount  THEN v_rest_amount  WHEN rec.approved_amount<=v_rest_amount  THEN rec.approved_amount  ELSE v_rest_amount END;
      v_remain_amount:=nvl(v_remain_amount,master_code.rule_limit)-v_rest_amount;
       UPDATE pat_activity_details pad
        SET pad.approved_amount = case when v_rest_amount>0 then v_rest_amount else 0 end,
            pad.allowed_amount =  case when v_rest_amount>0 then v_rest_amount else 0 end,
            pad.remarks =  case when (pad.approved_amount > v_rest_amount)  then case when pad.remarks is  null then 'The claimed amount is more than the allowed limit as per  policy benefits.Hence the amount over and above the allowed limit is disallowed' else case when pad.denial_code like '%BENX-005%'then pad.remarks else pad.remarks||';'||'The claimed amount is more than the allowed limit as per  policy benefits.Hence the amount over and above the allowed limit is disallowed' end end else pad.remarks end,
            pad.denial_desc = case when (pad.approved_amount > v_rest_amount)  then  case when pad.denial_desc is  null then 'Annual limit/sublimit amount exceeded' else case when pad.denial_code like '%BENX-005%'then pad.denial_desc else pad.denial_desc||';'||'Annual limit/sublimit amount exceeded' end end else pad.denial_desc end,
            pad.denial_code = case when (pad.approved_amount > v_rest_amount)  then case when pad.denial_code is  null then 'BENX-005' else case when pad.denial_code like '%BENX-005%'then pad.denial_code else pad.denial_code||';'||'BENX-005' end end else pad.denial_code end,
            pad.tpa_denial_desc = case when (pad.approved_amount > v_rest_amount)  then  case when pad.tpa_denial_desc is  null then 'Annual limit/sublimit amount exceeded' else case when pad.tpa_denial_code like '%BENX-005%'then pad.tpa_denial_desc else pad.tpa_denial_desc||';'||'Annual limit/sublimit amount exceeded' end end else pad.tpa_denial_desc end,
            pad.tpa_denial_code = case when (pad.approved_amount > v_rest_amount)  then case when pad.tpa_denial_code is  null then 'BENX-005' else case when pad.tpa_denial_code like '%BENX-005%'then pad.tpa_denial_code else pad.tpa_denial_code||';'||'BENX-005' end end else pad.tpa_denial_code end,
            pad.updated_by = v_added_by,
            pad.updated_date = SYSDATE,
            pad.denial_by_rule_proc_dtls    = case when (pad.approved_amount > v_rest_amount)  then
                                                        TRIM(BOTH ';' FROM (pad.denial_by_rule_proc_dtls||';'||CHR(10)||'authorization_pkg.check_activity_limits'))
                                                   else pad.denial_by_rule_proc_dtls end,
            pad.denial_by_resons            = case when (pad.approved_amount > v_rest_amount)  then
                                                        TRIM(BOTH ';' FROM (pad.denial_by_resons||';'||CHR(10)||'Limit exhausted'))        
                                                   else denial_by_resons end        
      WHERE pad.activity_dtl_seq_id = rec.activity_dtl_seq_id;
      v_rest_amount:=v_remain_amount;
       end if;
 
     END LOOP; 
     END LOOP;  
end if;
    -----  optical enhance -----    
   v_remain_amount:= NULL; 
   FOR rec IN (SELECT b.activity_dtl_seq_id,nvl(b.rule_limit,a.optc_benefit_limit) rule_limit,a.optc_benefit_limit,b.approved_amount
                 FROM pat_authorization_details a
                 JOIN pat_activity_details b ON (a.pat_auth_seq_id = b.pat_auth_seq_id)
                WHERE a.pat_auth_seq_id = v_seq_id AND b.optc_payable='INC') LOOP
    v_remain_amount := nvl(v_remain_amount,rec.optc_benefit_limit) ;       
    v_rest_amount:=least(v_remain_amount,rec.rule_limit);
    v_rest_amount:=CASE WHEN rec.approved_amount>v_rest_amount  THEN v_rest_amount  WHEN rec.approved_amount<=v_rest_amount  THEN rec.approved_amount  ELSE rec.approved_amount END;
    --v_used_amount := nvl(v_used_amount, 0) + v_rest_amount;           
    UPDATE pat_activity_details pad
        SET pad.approved_amount = case when v_rest_amount>0 then v_rest_amount else 0 end,
            pad.allowed_amount =  case when v_rest_amount>0 then v_rest_amount else 0 end,
            pad.remarks =  case when (pad.approved_amount > v_rest_amount)  then case when pad.remarks is  null then 'The claimed amount is more than the allowed limit as per  policy benefits.Hence the amount over and above the allowed limit is disallowed' else case when pad.denial_code like '%BENX-005%'then pad.remarks else pad.remarks||';'||'The claimed amount is more than the allowed limit as per  policy benefits.Hence the amount over and above the allowed limit is disallowed' end end else pad.remarks end,
            pad.denial_desc = case when (pad.approved_amount > v_rest_amount)  then  case when pad.denial_desc is  null then 'Annual limit/sublimit amount exceeded' else case when pad.denial_code like '%BENX-005%'then pad.denial_desc else pad.denial_desc||';'||'Annual limit/sublimit amount exceeded' end end else pad.denial_desc end,
            pad.denial_code = case when (pad.approved_amount > v_rest_amount)  then case when pad.denial_code is  null then 'BENX-005' else case when pad.denial_code like '%BENX-005%'then pad.denial_code else pad.denial_code||';'||'BENX-005' end end else pad.denial_code end,
            pad.tpa_denial_desc = case when (pad.approved_amount > v_rest_amount)  then  case when pad.tpa_denial_desc is  null then 'Annual limit/sublimit amount exceeded' else case when pad.tpa_denial_code like '%BENX-005%'then pad.tpa_denial_desc else pad.tpa_denial_desc||';'||'Annual limit/sublimit amount exceeded' end end else pad.tpa_denial_desc end,
            pad.tpa_denial_code = case when (pad.approved_amount > v_rest_amount)  then case when pad.tpa_denial_code is  null then 'BENX-005' else case when pad.tpa_denial_code like '%BENX-005%'then pad.tpa_denial_code else pad.tpa_denial_code||';'||'BENX-005' end end else pad.tpa_denial_code end,
            pad.updated_by = v_added_by,
            pad.updated_date = SYSDATE,
            pad.denial_by_rule_proc_dtls    = case when (pad.approved_amount > v_rest_amount)  then
                                                        TRIM(BOTH ';' FROM (pad.denial_by_rule_proc_dtls||';'||CHR(10)||'authorization_pkg.check_activity_limits'))
                                                   else pad.denial_by_rule_proc_dtls end,
            pad.denial_by_resons            = case when (pad.approved_amount > v_rest_amount)  then
                                                        TRIM(BOTH ';' FROM (pad.denial_by_resons||';'||CHR(10)||'Optical Limit exhausted'))        
                                                   else denial_by_resons end        
      WHERE pad.activity_dtl_seq_id = rec.activity_dtl_seq_id;
     v_remain_amount := v_remain_amount - v_rest_amount;  
   END LOOP;
   v_remain_amount:= NULL;  
   FOR rec IN (SELECT b.activity_dtl_seq_id,nvl(b.rule_limit,a.benefit_limit) rule_limit,a.benefit_limit,b.approved_amount
                 FROM pat_authorization_details a
                 JOIN pat_activity_details b ON (a.pat_auth_seq_id = b.pat_auth_seq_id)
                WHERE a.pat_auth_seq_id = v_seq_id AND b.optc_payable='EXC') LOOP
    v_remain_amount := nvl(v_remain_amount,rec.benefit_limit) ;         
    v_rest_amount:=least(v_remain_amount,rec.rule_limit);
    v_rest_amount:=CASE WHEN rec.approved_amount>v_rest_amount  THEN v_rest_amount  WHEN rec.approved_amount<=v_rest_amount  THEN rec.approved_amount  ELSE rec.approved_amount END;
    --v_used_amount := nvl(v_used_amount, 0) + v_rest_amount;           
    UPDATE pat_activity_details pad
        SET pad.approved_amount = case when v_rest_amount>0 then v_rest_amount else 0 end,
            pad.allowed_amount =  case when v_rest_amount>0 then v_rest_amount else 0 end,
            pad.remarks =  case when (pad.approved_amount > v_rest_amount)  then case when pad.remarks is  null then 'The claimed amount is more than the allowed limit as per  policy benefits.Hence the amount over and above the allowed limit is disallowed' else case when pad.denial_code like '%BENX-005%'then pad.remarks else pad.remarks||';'||'The claimed amount is more than the allowed limit as per  policy benefits.Hence the amount over and above the allowed limit is disallowed' end end else pad.remarks end,
            pad.denial_desc = case when (pad.approved_amount > v_rest_amount)  then  case when pad.denial_desc is  null then 'Annual limit/sublimit amount exceeded' else case when pad.denial_code like '%BENX-005%'then pad.denial_desc else pad.denial_desc||';'||'Annual limit/sublimit amount exceeded' end end else pad.denial_desc end,
            pad.denial_code = case when (pad.approved_amount > v_rest_amount)  then case when pad.denial_code is  null then 'BENX-005' else case when pad.denial_code like '%BENX-005%'then pad.denial_code else pad.denial_code||';'||'BENX-005' end end else pad.denial_code end,
            pad.tpa_denial_desc = case when (pad.approved_amount > v_rest_amount)  then  case when pad.tpa_denial_desc is  null then 'Annual limit/sublimit amount exceeded' else case when pad.tpa_denial_code like '%BENX-005%'then pad.tpa_denial_desc else pad.tpa_denial_desc||';'||'Annual limit/sublimit amount exceeded' end end else pad.tpa_denial_desc end,
            pad.tpa_denial_code = case when (pad.approved_amount > v_rest_amount)  then case when pad.tpa_denial_code is  null then 'BENX-005' else case when pad.tpa_denial_code like '%BENX-005%'then pad.tpa_denial_code else pad.tpa_denial_code||';'||'BENX-005' end end else pad.tpa_denial_code end,
            pad.updated_by = v_added_by,
            pad.updated_date = SYSDATE,
            pad.denial_by_rule_proc_dtls    = case when (pad.approved_amount > v_rest_amount)  then
                                                        TRIM(BOTH ';' FROM (pad.denial_by_rule_proc_dtls||';'||CHR(10)||'authorization_pkg.check_activity_limits'))
                                                   else pad.denial_by_rule_proc_dtls end,
            pad.denial_by_resons            = case when (pad.approved_amount > v_rest_amount)  then
                                                        TRIM(BOTH ';' FROM (pad.denial_by_resons||';'||CHR(10)||'Optical Limit exhausted'))        
                                                   else denial_by_resons end        
      WHERE pad.activity_dtl_seq_id = rec.activity_dtl_seq_id;
     v_remain_amount := v_remain_amount - v_rest_amount;  
   END LOOP;
    -----------------------------
----ADDED FOR SYSTEM OF MEDICINE(ALTERNATIVE MEDICINE CR) VENU BABU
for pat_sys in sys_med_flag_act_pat loop

    IF  pat_sys.sys_med_yn ='Y' THEN  
        v_remain_amount:=null;
        IF pat_sys.sys_med_limit IS NULL AND pat_sys.icd_limit IS NOT NULL THEN
        v_rest_amount := pat_sys.icd_limit;
        ELSIF pat_sys.sys_med_limit IS NOT NULL AND pat_sys.icd_limit IS NULL  THEN
        v_rest_amount := pat_sys.sys_med_limit;
        ELSIF pat_sys.sys_med_limit IS NOT NULL AND pat_sys.icd_limit IS NOT NULL THEN 
        v_rest_amount :=least (pat_sys.sys_med_limit,pat_sys.icd_limit);
        END IF;
        
        v_rest_amount := v_rest_amount- nvl(v_act_use_amt,0);
        
        v_sys_copay:= CASE WHEN pat_sys.icd_limit = v_rest_amount THEN nvl(pat_sys.diag_copay,0) 
                           ELSE nvl(pat_sys.sys_copay,0) END;
    
        v_sys_deductible := CASE WHEN pat_sys.icd_limit = v_rest_amount THEN nvl(pat_sys.diag_deduct,0) 
                            ELSE nvl(pat_sys.sys_deductible,0) END;
        
     FOR rec in sys_med_flag_pat(pat_sys.master_activity_code) loop
     v_rest_amount :=least (v_rest_amount,nvl(rec.rule_limit,pat_sys.sys_med_limit));
           v_sys_copay := CASE  WHEN v_rest_amount= nvl(rec.rule_limit,0)  then  rec.act_copay else  v_sys_copay end;
           v_sys_deduct := CASE WHEN v_sys_copay=rec.sys_copay THEN NULL ELSE rec.rule_deduct END;
           v_copay_amount :=case when v_sys_copay is not null then (rec.gross_amount*v_sys_copay/100) else 0 end;

         if rec.copay_deduct_flag='MIN' THEN 
             v_patient_share := least(least(NVL(v_copay_amount,0),nvl(v_sys_deduct,v_copay_amount)), v_sys_deductible);
           elsif rec.copay_deduct_flag='MAX' THEN
              v_patient_share := greatest(NVL(v_copay_amount,0),nvl(v_sys_deduct,v_copay_amount));
           else
             v_patient_share:= NVL(v_copay_amount,0) + NVL(v_sys_deduct,0);   
         end if;
     
     if rec.out_of_pocket_amount is not null then
       v_appr_amt:=(rec.gross_amount-rec.out_of_pocket_amount)-(NVL(v_patient_share,0)+NVL (rec.dis_amt,0));
     else
       v_appr_amt:=rec.gross_amount-(NVL(v_patient_share,0)+NVL (rec.dis_amt,0));
     end if;
        
      v_rest_amount:=CASE WHEN v_appr_amt>v_rest_amount  THEN v_rest_amount  WHEN v_appr_amt <=v_rest_amount  THEN v_appr_amt  ELSE v_rest_amount END;
      v_remain_amount:=nvl(nvl(v_remain_amount,rec.rule_limit),pat_sys.sys_med_limit)-v_rest_amount;
    
       UPDATE pat_activity_details pad
        SET pad.approved_amount = case when v_rest_amount>0 and NVL(rec.approve_yn,'Y')='Y' then v_rest_amount else 0 end,
            pad.allowed_amount =  case when v_rest_amount>0 and NVL(rec.approve_yn,'Y')='Y' then v_rest_amount else 0 end,
            pad.patient_share_amount = v_patient_share,
            pad.benifit_copay= v_sys_copay,
           
            pad.benifit_deductible=v_sys_deductible/*v_sys_deduct*/,
            pad.copay_amount=v_copay_amount,            pad.remarks =  case when v_appr_amt>v_rest_amount then case when pad.remarks is  null then 'The claimed amount is more than the allowed limit as per  policy benefits.Hence the amount over and above the allowed limit is disallowed' else case when pad.denial_code like '%BENX-005%'then pad.remarks else pad.remarks||';'||'The claimed amount is more than the allowed limit as per  policy benefits.Hence the amount over and above the allowed limit is disallowed' end end else pad.remarks end,
            pad.denial_desc = case when v_appr_amt >v_rest_amount then  case when pad.denial_desc is  null then 'System OF Med Annual limit/sublimit amount exceeded' else case when pad.denial_code like '%BENX-005%'then pad.denial_desc else pad.denial_desc||';'||'System OF Med Annual limit/sublimit amount exceeded' end end else pad.denial_desc end,
            pad.denial_code = case when v_appr_amt >v_rest_amount then case when pad.denial_code is  null then 'BENX-005' else case when pad.denial_code like '%BENX-005%'then pad.denial_code else pad.denial_code||';'||'BENX-005' end end else pad.denial_code end,
            pad.tpa_denial_desc = case when (pad.approved_amount > v_rest_amount)  then  case when pad.tpa_denial_desc is  null then 'Annual limit/sublimit amount exceeded' else case when pad.tpa_denial_code like '%BENX-005%'then pad.tpa_denial_desc else pad.tpa_denial_desc||';'||'Annual limit/sublimit amount exceeded' end end else pad.tpa_denial_desc end,
            pad.tpa_denial_code = case when (pad.approved_amount > v_rest_amount)  then case when pad.tpa_denial_code is  null then 'BENX-005' else case when pad.tpa_denial_code like '%BENX-005%'then pad.tpa_denial_code else pad.tpa_denial_code||';'||'BENX-005' end end else pad.tpa_denial_code end,
            pad.updated_by = v_added_by,
            pad.updated_date = SYSDATE,
            pad.denial_by_rule_proc_dtls    = case when (pad.approved_amount > v_rest_amount)  then
                                                        TRIM(BOTH ';' FROM (pad.denial_by_rule_proc_dtls||';'||CHR(10)||'authorization_pkg.check_activity_limits'))
                                                   else pad.denial_by_rule_proc_dtls end,
            pad.denial_by_resons            = case when (pad.approved_amount > v_rest_amount)  then
                                                        TRIM(BOTH ';' FROM (pad.denial_by_resons||';'||CHR(10)||'Limit exhausted'))        
                                                   else denial_by_resons end        
      WHERE pad.activity_dtl_seq_id = rec.activity_dtl_seq_id;
     v_act_use_amt:= nvl(v_act_use_amt,0) + v_rest_amount; 
     v_rest_amount:=v_remain_amount;    
        
     END LOOP;
     end if;
     END LOOP;  
    
    OPEN act_cur_pat;
    FETCH act_cur_pat INTO act_rec;
    CLOSE act_cur_pat;

  UPDATE pat_authorization_details A
    SET a.tot_gross_amount           = act_rec.tot_gross_amount,
        a.tot_discount_amount        = act_rec.tot_discount_amount,
        a.tot_disc_gross_amount      = act_rec.tot_disc_gross_amount,
        a.tot_patient_share_amount   = act_rec.tot_patient_share_amount,
        a.tot_net_amount             = act_rec.tot_net_amount,
        a.tot_allowed_amount         = act_rec.tot_allowed_amount,
        a.tot_approved_amount        = act_rec.tot_approved_amount,
        a.remarks                    = v_remarks,
        a.dis_allowed_amount         = nvl(act_rec.tot_net_amount,0)-nvl(act_rec.tot_approved_amount,0)
   WHERE a.pat_auth_seq_id           = v_seq_id 
   RETURNING a.tot_approved_amount INTO v_final_allowed_amount;
  end if;  

  ELSIF v_mode='CLM' THEN
  
  OPEN clm_prim_icd_cur;
  FETCH clm_prim_icd_cur INTO v_prim_icd;
  CLOSE clm_prim_icd_cur;
  
   select pad.benifit_type,pad.pat_auth_seq_id,pad.MATERNITY_YN into v_benefit_type,v_pre_auth_seq_id,v_mat from app.clm_authorization_details pad where pad.claim_seq_id=v_seq_id;
  --if v_allowed_amt>0 then 
    OPEN clm_icd_cur;
    FETCH clm_icd_cur INTO icd_rec;
    CLOSE clm_icd_cur;

       OPEN clm_psy_icd_cur;
    FETCH clm_psy_icd_cur INTO icd_psy_rec;
    CLOSE clm_psy_icd_cur;
   
      OPEN psy_actclm_cur;
  FETCH psy_actclm_cur INTO icd_psyclm_limit;
  CLOSE psy_actclm_cur;
  
  OPEN  cur_clm_hosp_nme;
  FETCH cur_clm_hosp_nme INTO V_HOSP_NAME;
  CLOSE cur_clm_hosp_nme;
   
   select cad.claim_type,cad.benefit_limit,cad.limit_applied_flag 
        into v_claim_type,v_glob_limit ,v_rule_flag
      from clm_authorization_details cad where cad.claim_seq_id=v_seq_id;

   if v_claim_type!='CNH' OR (v_claim_type='CNH' AND NVL(v_pre_auth_seq_id,0)=0) THEN  
   IF icd_rec.day_care_icd_group_id='ICD001' and icd_rec.benifit_type= 'OPTS' AND NVL(icd_psy_rec.master_icd_code, 'NA') NOT IN ('F09', 'B20', 'E66.9', 'E55.9', 'Q00.0', 'C80.1', 'A65', 'Z00.121', 'B16.9', 'B17.11') and nvl(icd_rec.limit_applied_flag,'OCL') IN ('OCL','TSI') THEN 
     IF icd_rec.limit_applied_flag='TSI' THEN
       v_glob_limit:=icd_rec.sum_ins;
     ELSE 
        v_glob_limit:=nvl(icd_rec.rule_limit,0);
     END IF;
      
   FOR p_rec in clm_master_code_cur LOOP 
     
       v_glb_limit:= v_glob_limit-NVL(v_used_amount,0);
       
     IF v_glb_limit IS NOT NULL AND p_rec.rule_limit IS NOT NULL THEN   
       v_rest_amount := least (v_glb_limit,p_rec.rule_limit);
     ELSIF v_glb_limit IS NULL AND p_rec.rule_limit IS NOT NULL THEN   
       v_rest_amount := p_rec.rule_limit;
     ELSIF v_glb_limit IS NOT NULL AND p_rec.rule_limit IS NULL THEN   
       v_rest_amount := v_glb_limit;  
     END IF;
     
      v_rest_amount := v_rest_amount;
      v_act_appr_amount := v_rest_amount;
      v_remain_amount:=null;

     FOR rec in clm_act_cur(p_rec.master_activity_code) loop
     
     IF v_rest_amount IS NOT NULL AND rec.rule_limit IS NOT NULL THEN
        v_rest_amount := least(v_rest_amount,rec.rule_limit);
      ELSIF v_rest_amount IS NOT NULL AND rec.rule_limit IS NULL THEN
        v_rest_amount := v_rest_amount;
      ELSIF v_rest_amount IS NULL AND rec.rule_limit IS NOT NULL THEN
        v_rest_amount := rec.rule_limit;
      END IF;
      
     v_rest_amount:=CASE WHEN rec.approved_amount>v_rest_amount  THEN v_rest_amount  WHEN rec.approved_amount<=v_rest_amount  THEN rec.approved_amount  ELSE v_rest_amount END;
      v_remain_amount:=nvl(v_remain_amount,v_act_appr_amount)-v_rest_amount;
       UPDATE pat_activity_details pad
        SET pad.approved_amount = case when v_rest_amount>0 then v_rest_amount else 0 end,
            pad.allowed_amount =  case when v_rest_amount>0 then v_rest_amount else 0 end,
            pad.remarks = case when icd_rec.remarks is null then case when (pad.approved_amount > v_rest_amount)  then case when pad.remarks is  null then ' Chronic limit has been exceeded' else case when pad.denial_code like '%BENX-005%'then 'Chronic limit has been exceeded' else pad.remarks||';'||' Chronic limit has been exceeded' end end else pad.remarks end else pad.remarks||';'||icd_rec.remarks end,
            pad.denial_desc = case when icd_rec.remarks is null then case when (pad.approved_amount > v_rest_amount)  then  case when pad.denial_desc is  null then 'Annual limit/sublimit amount exceeded' else case when pad.denial_code like '%BENX-005%'then pad.denial_desc else pad.denial_desc||';'||'Annual limit/sublimit amount exceeded' end end else pad.denial_desc end else pad.denial_desc||';'||icd_rec.remarks end,
            pad.denial_code = case when icd_rec.denial_reason is null then case when (pad.approved_amount > v_rest_amount)  then case when pad.denial_code is  null then 'BENX-005' else case when pad.denial_code like '%BENX-005%'then pad.denial_code else pad.denial_code||';'||'BENX-005' end end else pad.denial_code end else pad.denial_code||';'||icd_rec.denial_reason end,
            pad.tpa_denial_desc = case when icd_rec.remarks is null then case when (pad.approved_amount > v_rest_amount)  then  case when pad.tpa_denial_desc is  null then 'Annual limit/sublimit amount exceeded' else case when pad.tpa_denial_code like '%BENX-005%'then pad.tpa_denial_desc else pad.tpa_denial_desc||';'||'Annual limit/sublimit amount exceeded' end end else pad.tpa_denial_desc end else icd_rec.remarks end,
            pad.tpa_denial_code = case when icd_rec.denial_reason is null then case when (pad.approved_amount > v_rest_amount)  then case when pad.tpa_denial_code is  null then 'BENX-005' else case when pad.tpa_denial_code like '%BENX-005%'then pad.tpa_denial_code else pad.tpa_denial_code||';'||'BENX-005' end end else pad.tpa_denial_code end else icd_rec.denial_reason end,
            --pad.benifit_deductible=icd_rec.deduct,
            pad.updated_by = v_added_by,
            pad.updated_date = SYSDATE,
            pad.denial_by_rule_proc_dtls    = case when (pad.approved_amount > v_rest_amount)  then
                                                        TRIM(BOTH ';' FROM (pad.denial_by_rule_proc_dtls||';'||CHR(10)||'authorization_pkg.check_activity_limits'))
                                                   else pad.denial_by_rule_proc_dtls end,
            pad.denial_by_resons            = case when (pad.approved_amount > v_rest_amount)  then
                                                        TRIM(BOTH ';' FROM (pad.denial_by_resons||';'||CHR(10)||'Chronic limit exhausted'))        
                                                   else denial_by_resons end        
      WHERE pad.activity_dtl_seq_id = rec.activity_dtl_seq_id;
      v_used_amount := nvl(v_used_amount,0) + v_rest_amount;
      v_rest_amount:=v_remain_amount;
      v_act_appr_amount := v_act_appr_amount - nvl(v_used_amount,0);
     END LOOP;
   END LOOP;
  ELSIF icd_rec.day_care_icd_group_id='ICD001' and icd_rec.benifit_type= 'IPT' and nvl(icd_rec.limit_applied_flag,'OCL') IN ('OCL','TSI')  THEN    
     IF icd_rec.limit_applied_flag='TSI' THEN
       v_glob_limit:=icd_rec.sum_ins;
     ELSE 
        v_glob_limit:=nvl(icd_rec.rule_limit,0);
     END IF;
      
   FOR p_rec in clm_master_code_cur LOOP 
        v_glb_limit:= v_glob_limit-NVL(v_used_amount,0);
     IF v_glb_limit IS NOT NULL AND p_rec.rule_limit IS NOT NULL THEN   
       v_rest_amount := least (v_glb_limit,p_rec.rule_limit);
     ELSIF v_glb_limit IS NULL AND p_rec.rule_limit IS NOT NULL THEN   
       v_rest_amount := p_rec.rule_limit;
     ELSIF v_glb_limit IS NOT NULL AND p_rec.rule_limit IS NULL THEN   
       v_rest_amount := v_glb_limit;  
     END IF;
     
      v_rest_amount := v_rest_amount;
       v_act_appr_amount := v_rest_amount;
      v_remain_amount := null;
     FOR rec in clm_act_cur(p_rec.master_activity_code) loop
     
     IF v_rest_amount IS NOT NULL AND rec.rule_limit IS NOT NULL THEN
        v_rest_amount := least(v_rest_amount,rec.rule_limit);
      ELSIF v_rest_amount IS NOT NULL AND rec.rule_limit IS NULL THEN
        v_rest_amount := v_rest_amount;
      ELSIF v_rest_amount IS NULL AND rec.rule_limit IS NOT NULL THEN
        v_rest_amount := rec.rule_limit;
      END IF;
      
     v_rest_amount:=CASE WHEN rec.approved_amount>v_rest_amount  THEN v_rest_amount  WHEN rec.approved_amount<=v_rest_amount  THEN rec.approved_amount  ELSE v_rest_amount END;
      v_remain_amount:=nvl(v_remain_amount,v_act_appr_amount)-v_rest_amount;
       UPDATE pat_activity_details pad
        SET pad.approved_amount = case when v_rest_amount>0 then v_rest_amount else 0 end,
            pad.allowed_amount =  case when v_rest_amount>0 then v_rest_amount else 0 end,
            pad.remarks = case when icd_rec.remarks is null then case when (pad.approved_amount > v_rest_amount)  then case when pad.remarks is  null then ' Chronic limit has been exceeded' else case when pad.denial_code like '%BENX-005%'then 'Chronic limit has been exceeded' else pad.remarks||';'||' Chronic limit has been exceeded' end end else pad.remarks end else icd_rec.remarks end,
            pad.denial_desc = case when icd_rec.remarks is null then case when (pad.approved_amount > v_rest_amount)  then  case when pad.denial_desc is  null then 'Annual limit/sublimit amount exceeded' else case when pad.denial_code like '%BENX-005%'then pad.denial_desc else pad.denial_desc||';'||'Annual limit/sublimit amount exceeded' end end else pad.denial_desc end else icd_rec.remarks end,
            pad.denial_code = case when icd_rec.denial_reason is null then case when (pad.approved_amount > v_rest_amount)  then case when pad.denial_code is  null then 'BENX-005' else case when pad.denial_code like '%BENX-005%'then pad.denial_code else pad.denial_code||';'||'BENX-005' end end else pad.denial_code end else icd_rec.denial_reason end,
            --pad.benifit_deductible=icd_rec.deduct,
            pad.updated_by = v_added_by,
            pad.updated_date = SYSDATE,
            pad.denial_by_rule_proc_dtls    = case when (pad.approved_amount > v_rest_amount)  then
                                                        TRIM(BOTH ';' FROM (pad.denial_by_rule_proc_dtls||';'||CHR(10)||'authorization_pkg.check_activity_limits'))
                                                   else pad.denial_by_rule_proc_dtls end,
            pad.denial_by_resons            = case when (pad.approved_amount > v_rest_amount)  then
                                                        TRIM(BOTH ';' FROM (pad.denial_by_resons||';'||CHR(10)||'Chronic limit exhausted'))        
                                                   else denial_by_resons end        
      WHERE pad.activity_dtl_seq_id = rec.activity_dtl_seq_id;
      v_used_amount := nvl(v_used_amount,0) + v_rest_amount;
      v_rest_amount:=v_remain_amount;
      v_act_appr_amount := v_act_appr_amount - nvl(v_used_amount,0);
     END LOOP;
END LOOP;
      ELSIF NVL(icd_psy_rec.master_icd_code, 'NA') IN ('F09', 'B20', 'E55.9', 'Q00.0', 'C80.1', 'A65', 'Z00.121', 'B16.9', 'B17.11') AND v_benefit_type NOT IN ('HEAC', 'IEMA', 'IPRE', 'PAHC', 'MTI', 'IMTI', 'OMTI') and NVL(icd_psy_rec.limit_applied_flag,'OPL') IN ('OPL','TSI') then-- and icd_rec.benifit_type= 'OPTS' THEN 
     IF icd_psy_rec.limit_applied_flag='TSI' THEN
       v_glob_limit:=icd_psy_rec.sum_ins;
      ELSE 
        v_glob_limit:=nvl(icd_psy_rec.rule_limit,0);
      END IF;
      
   FOR p_rec in clm_master_code_cur LOOP 
        v_glb_limit:= v_glob_limit-NVL(v_used_amount,0);
     IF v_glb_limit IS NOT NULL AND p_rec.rule_limit IS NOT NULL THEN   
       v_rest_amount := least (v_glb_limit,p_rec.rule_limit);
     ELSIF v_glb_limit IS NULL AND p_rec.rule_limit IS NOT NULL THEN   
       v_rest_amount := p_rec.rule_limit;
     ELSIF v_glb_limit IS NOT NULL AND p_rec.rule_limit IS NULL THEN   
       v_rest_amount := v_glb_limit;  
     END IF;
     
      v_rest_amount := v_rest_amount;
        v_act_appr_amount := v_rest_amount;
      v_remain_amount := null;
     FOR rec in clm_act_cur(p_rec.master_activity_code) loop
     IF v_rest_amount IS NOT NULL AND rec.rule_limit IS NOT NULL THEN
        v_rest_amount := least(v_rest_amount,rec.rule_limit);
      ELSIF v_rest_amount IS NOT NULL AND rec.rule_limit IS NULL THEN
        v_rest_amount := v_rest_amount;
      ELSIF v_rest_amount IS NULL AND rec.rule_limit IS NOT NULL THEN
        v_rest_amount := rec.rule_limit;
      END IF;
      
     v_rest_amount:=CASE WHEN rec.approved_amount>v_rest_amount  THEN v_rest_amount  WHEN rec.approved_amount<=v_rest_amount  THEN rec.approved_amount  ELSE v_rest_amount END;
      v_remain_amount:=nvl(v_remain_amount,v_act_appr_amount)-v_rest_amount;
       UPDATE pat_activity_details pad
        SET pad.approved_amount = case when v_rest_amount>0 then v_rest_amount else 0 end,
            pad.allowed_amount =  case when v_rest_amount>0 then v_rest_amount else 0 end,
            pad.remarks = case when icd_psy_rec.remarks is null then case when pad.approved_amount>v_rest_amount then case when pad.remarks is  null then ' Psychiatric limit has been exceeded' else case when pad.denial_code like '%BENX-005%'then 'Psychiatric limit has been exceeded' else pad.remarks||';'||' Psychiatric limit has been exceeded' end end else pad.remarks end else trim(LEADING ';' FROM pad.remarks||'; '||icd_psy_rec.remarks) end,
            pad.denial_desc = case when icd_psy_rec.remarks is null then case when pad.approved_amount>v_rest_amount then  case when pad.denial_desc is  null then 'Annual limit/sublimit amount exceeded' else case when pad.denial_code like '%BENX-005%'then pad.denial_desc else pad.denial_desc||';'||'Annual limit/sublimit amount exceeded' end end else pad.denial_desc end else trim(LEADING ';' FROM pad.denial_desc||'; '||icd_psy_rec.remarks) end,
            pad.denial_code = case when icd_psy_rec.denial_reason is null then case when pad.approved_amount>v_rest_amount then case when pad.denial_code is  null then 'BENX-005' else case when pad.denial_code like '%BENX-005%'then pad.denial_code else pad.denial_code||';'||'BENX-005' end end else pad.denial_code end else trim(LEADING ';' FROM pad.denial_code||'; '||icd_psy_rec.denial_reason) end,
            pad.tpa_denial_desc = case when icd_rec.remarks is null then case when (pad.approved_amount > v_rest_amount)  then  case when pad.tpa_denial_desc is  null then 'Annual limit/sublimit amount exceeded' else case when pad.tpa_denial_code like '%BENX-005%'then pad.tpa_denial_desc else pad.tpa_denial_desc||';'||'Annual limit/sublimit amount exceeded' end end else pad.tpa_denial_desc end else icd_rec.remarks end,
            pad.tpa_denial_code = case when icd_rec.denial_reason is null then case when (pad.approved_amount > v_rest_amount)  then case when pad.tpa_denial_code is  null then 'BENX-005' else case when pad.tpa_denial_code like '%BENX-005%'then pad.tpa_denial_code else pad.tpa_denial_code||';'||'BENX-005' end end else pad.tpa_denial_code end else icd_rec.denial_reason end,
            --pad.benifit_deductible=icd_rec.deduct,
            pad.updated_by = v_added_by,
            pad.updated_date = SYSDATE,
            pad.denial_by_rule_proc_dtls    = case when (pad.approved_amount > v_rest_amount)  then
                                                        TRIM(BOTH ';' FROM (pad.denial_by_rule_proc_dtls||';'||CHR(10)||'authorization_pkg.check_activity_limits'))
                                                   else pad.denial_by_rule_proc_dtls end,
            pad.denial_by_resons            = case when (pad.approved_amount > v_rest_amount)  then
                                                        TRIM(BOTH ';' FROM (pad.denial_by_resons||';'||CHR(10)||'Psychiatric limit exhausted'))        
                                                   else denial_by_resons end        
      WHERE pad.activity_dtl_seq_id = rec.activity_dtl_seq_id;
      v_used_amount := nvl(v_used_amount,0) + v_rest_amount;
      v_rest_amount:=v_remain_amount;
      v_act_appr_amount := v_act_appr_amount - nvl(v_used_amount,0);
     END LOOP;
   END LOOP;
   ------
   ELSIF v_prim_icd = 'E66.9' THEN
     
     FOR obs IN clm_obesyti_cur LOOP
       v_dntl_used_amt := 0;
       
        v_appr_amt := case when (obs.benefit_limit - v_used_amount) > 0 then (obs.benefit_limit - v_used_amount) else 0 end;
        
        IF obs.master_activity_code = 'MED' THEN
          v_remain_amount := NULL;
            FOR rec in  clm_obesyti_med_act(obs.master_activity_code) LOOP
              rec.rule_limit := rec.rule_limit - v_dntl_used_amt;
              if v_appr_amt > rec.rule_limit then
                v_appr_amt := rec.rule_limit;
              else
                v_appr_amt := v_appr_amt;
              end if;
              -----
              if v_appr_amt > rec.approved_amount then
                v_rest_amount := rec.approved_amount;
              else
                v_rest_amount := v_appr_amt;
              end if;
     -------
              v_remain_amount := case when nvl(v_remain_amount, v_appr_amt) - v_rest_amount > 0 then nvl(v_remain_amount, v_appr_amt) - v_rest_amount else 0 end;
              v_used_amount := nvl(v_used_amount, 0) + v_rest_amount;
              v_dntl_used_amt := nvl(v_dntl_used_amt, 0) + nvl(v_rest_amount, 0);
              -------
              UPDATE pat_activity_details pad
              SET pad.approved_amount = case when v_rest_amount>0 then v_rest_amount else 0 end,
                  pad.allowed_amount =  case when v_rest_amount>0 then v_rest_amount else 0 end,
                  pad.remarks =  case when (pad.approved_amount > v_rest_amount) then case when pad.remarks is  null then 'The claimed amount is more than the allowed limit as per  policy benefits.Hence the amount over and above the allowed limit is disallowed' else case when pad.denial_code like '%BENX-005%'then pad.remarks else pad.remarks||';'||'The claimed amount is more than the allowed limit as per  policy benefits.Hence the amount over and above the allowed limit is disallowed' end end else pad.remarks end,--else nvl(pad.remarks,'The claimed amount is more than the allowed limit as per  policy benefits.Hence the amount over and above the allowed limit is disallowed') end,
                  pad.denial_desc = case when (pad.approved_amount > v_rest_amount)  then  case when pad.denial_desc is  null then 'Annual limit/sublimit amount exceeded' else case when pad.denial_code like '%BENX-005%'then pad.denial_desc else pad.denial_desc||';'||'Annual limit/sublimit amount exceeded' end end else pad.denial_desc end,
                  pad.denial_code = case when (pad.approved_amount > v_rest_amount)  then case when pad.denial_code is  null then 'BENX-005' else case when pad.denial_code like '%BENX-005%'then pad.denial_code else pad.denial_code||';'||'BENX-005' end end else pad.denial_code end,
                  pad.updated_by = v_added_by,
                  pad.updated_date = SYSDATE,
                  pad.denial_by_rule_proc_dtls    = case when (pad.approved_amount > v_rest_amount)  then
                                                            TRIM(BOTH ';' FROM (pad.denial_by_rule_proc_dtls||';'||CHR(10)||'authorization_pkg.check_activity_limits'))
                                                       else pad.denial_by_rule_proc_dtls end,
                  pad.denial_by_resons            = case when (pad.approved_amount > v_rest_amount)  then
                                                            TRIM(BOTH ';' FROM (pad.denial_by_resons||';'||CHR(10)||'Pbesyti limit exhausted'))        
                                                       else denial_by_resons end        
             WHERE pad.activity_dtl_seq_id = rec.activity_dtl_seq_id;
            v_appr_amt := v_remain_amount;
            END LOOP;
              
        ELSE--------------MED    
            FOR rec in  clm_obesyti_act(obs.master_activity_code) LOOP
              v_remain_amount := NULL;
              rec.rule_limit := rec.rule_limit - v_dntl_used_amt;
              if v_appr_amt > rec.rule_limit then
                v_appr_amt := rec.rule_limit;
              else
                v_appr_amt := v_appr_amt;
              end if;
              -----
              if v_appr_amt > rec.approved_amount then
                v_rest_amount := rec.approved_amount;
              else
                v_rest_amount := v_appr_amt;
              end if;
              -------
              v_remain_amount := case when nvl(v_remain_amount, v_appr_amt) - v_rest_amount > 0 then nvl(v_remain_amount, v_appr_amt) - v_rest_amount else 0 end;
              v_used_amount := nvl(v_used_amount, 0) + v_rest_amount;
              v_dntl_used_amt := nvl(v_dntl_used_amt, 0) + nvl(v_rest_amount, 0);
              -------
              UPDATE pat_activity_details pad
              SET pad.approved_amount = case when v_rest_amount>0 then v_rest_amount else 0 end,
                  pad.allowed_amount =  case when v_rest_amount>0 then v_rest_amount else 0 end,
                  pad.remarks =  case when (pad.approved_amount > v_rest_amount)  then case when pad.remarks is  null then 'The claimed amount is more than the allowed limit as per  policy benefits.Hence the amount over and above the allowed limit is disallowed' else case when pad.denial_code like '%BENX-005%'then pad.remarks else pad.remarks||';'||'The claimed amount is more than the allowed limit as per  policy benefits.Hence the amount over and above the allowed limit is disallowed' end end else pad.remarks end,--else nvl(pad.remarks,'The claimed amount is more than the allowed limit as per  policy benefits.Hence the amount over and above the allowed limit is disallowed') end,
                  pad.denial_desc = case when (pad.approved_amount > v_rest_amount)  then  case when pad.denial_desc is  null then 'Annual limit/sublimit amount exceeded' else case when pad.denial_code like '%BENX-005%'then pad.denial_desc else pad.denial_desc||';'||'Annual limit/sublimit amount exceeded' end end else pad.denial_desc end,
                  pad.denial_code = case when (pad.approved_amount > v_rest_amount)  then case when pad.denial_code is  null then 'BENX-005' else case when pad.denial_code like '%BENX-005%'then pad.denial_code else pad.denial_code||';'||'BENX-005' end end else pad.denial_code end,
                  pad.updated_by = v_added_by,
                  pad.updated_date = SYSDATE,
                  pad.denial_by_rule_proc_dtls    = case when (pad.approved_amount > v_rest_amount)  then
                                                            TRIM(BOTH ';' FROM (pad.denial_by_rule_proc_dtls||';'||CHR(10)||'authorization_pkg.check_activity_limits'))
                                                       else pad.denial_by_rule_proc_dtls end,
                  pad.denial_by_resons            = case when (pad.approved_amount > v_rest_amount)  then
                                                            TRIM(BOTH ';' FROM (pad.denial_by_resons||';'||CHR(10)||'Pbesyti limit exhausted'))        
                                                       else denial_by_resons end        
             WHERE pad.activity_dtl_seq_id = rec.activity_dtl_seq_id;
            v_appr_amt := v_remain_amount;
          END LOOP;
      END IF;
    END LOOP;
     -------
   ELSIF v_benefit_type='DNTL' THEN
        for dent IN clm_get_dent_grp_code_cur loop
         v_remain_amount := NULL;
         v_dntl_used_amt := 0;
        v_appr_amt := case when (dent.benefit_limit - v_used_amount) > 0 then (dent.benefit_limit - v_used_amount) else 0 end;
        for rec in  clm_get_dent_code_cur(dent.specific_service_code) loop
          rec.rule_limit := rec.rule_limit - v_dntl_used_amt;
          if v_appr_amt > rec.rule_limit then
            v_appr_amt := rec.rule_limit;
          else
            v_appr_amt := v_appr_amt;
          end if;
          -----
          if v_appr_amt > rec.approved_amount then
            v_rest_amount := rec.approved_amount;
          else
            v_rest_amount := v_appr_amt;
          end if;
          -------
          v_remain_amount := case when nvl(v_remain_amount, v_appr_amt) - v_rest_amount > 0 then nvl(v_remain_amount, v_appr_amt) - v_rest_amount else 0 end;
          v_used_amount := nvl(v_used_amount, 0) + v_rest_amount;
          v_dntl_used_amt := nvl(v_dntl_used_amt, 0) + nvl(v_rest_amount, 0);
          -------
          UPDATE pat_activity_details pad
          SET pad.approved_amount = case when v_rest_amount>0 then v_rest_amount else 0 end,
              pad.allowed_amount =  case when v_rest_amount>0 then v_rest_amount else 0 end,
              pad.remarks =  case when (pad.approved_amount > v_rest_amount)  then case when pad.remarks is  null then 'The claimed amount is more than the allowed limit as per  policy benefits.Hence the amount over and above the allowed limit is disallowed' else case when pad.denial_code like '%BENX-005%'then pad.remarks else pad.remarks||';'||'The claimed amount is more than the allowed limit as per  policy benefits.Hence the amount over and above the allowed limit is disallowed' end end else pad.remarks end,
              pad.denial_desc = case when dent.ava_sum_insured > 0 AND dent.benefit_limit IS NULL then 
                                  pad.denial_desc||';'||'Dental limit has been exceeded '
                                else
                                  case when pad.approved_amount>v_rest_amount then  case when pad.denial_desc is  null then 'Annual limit/sublimit amount exceeded' else case when pad.denial_code like '%BENX-005%'then pad.denial_desc else pad.denial_desc||';'||'Annual limit/sublimit amount exceeded' end end else pad.denial_desc end
                                end,
              pad.denial_code = case when pad.approved_amount>v_rest_amount then case when pad.denial_code is  null then 'BENX-005' else case when pad.denial_code like '%BENX-005%'then pad.denial_code else pad.denial_code||';'||'BENX-005' end end else pad.denial_code end,
              pad.tpa_denial_desc = case when dent.ava_sum_insured > 0 AND dent.benefit_limit IS NULL then 
                                    pad.tpa_denial_desc||';'||'Dental limit has been exceeded '
                                  else
                                    case when pad.approved_amount>v_rest_amount then  case when pad.tpa_denial_desc is  null then 'Annual limit/sublimit amount exceeded' else case when pad.tpa_denial_code like '%BENX-005%'then pad.tpa_denial_desc else pad.tpa_denial_desc||';'||'Annual limit/sublimit amount exceeded' end end else pad.tpa_denial_desc end
                                  end,
              pad.tpa_denial_code = case when pad.approved_amount>v_rest_amount then case when pad.tpa_denial_code is  null then 'BENX-005' else case when pad.tpa_denial_code like '%BENX-005%'then pad.tpa_denial_code else pad.tpa_denial_code||';'||'BENX-005' end end else pad.tpa_denial_code end,
              pad.benifit_deductible=NVL(benifit_deductible,icd_rec.deduct),
              pad.updated_by = v_added_by,
              pad.updated_date = SYSDATE,
              pad.denial_by_rule_proc_dtls    = case when (pad.approved_amount > v_rest_amount)  then
                                                          TRIM(BOTH ';' FROM (pad.denial_by_rule_proc_dtls||';'||CHR(10)||'authorization_pkg.check_activity_limits'))
                                                     else pad.denial_by_rule_proc_dtls end,
              pad.denial_by_resons            = case when (pad.approved_amount > v_rest_amount)  then
                                                          TRIM(BOTH ';' FROM (pad.denial_by_resons||';'||CHR(10)||'Dental limit exhausted'))        
                                                     else denial_by_resons end        
          WHERE pad.activity_dtl_seq_id = rec.activity_dtl_seq_id;
        v_appr_amt := v_remain_amount;
      end loop;
    end loop;
    ----------------------------

   ELSIF v_benefit_type IN ('MTI', 'IMTI', 'OMTI') OR NVL(v_mat,'N') = 'Y'  THEN
     FOR dent in clm_dental_cur LOOP
     v_rest_amount:=nvl(dent.benefit_limit,0);
     FOR rec in clm_chronic_cur loop

      v_rest_amount:=CASE WHEN rec.approved_amount>v_rest_amount  THEN v_rest_amount  WHEN rec.approved_amount<=v_rest_amount  THEN rec.approved_amount  ELSE v_rest_amount END;
      v_remain_amount:=nvl(v_remain_amount,dent.benefit_limit)-v_rest_amount;
       UPDATE pat_activity_details pad
        SET pad.approved_amount = case when v_rest_amount>0 then v_rest_amount else 0 end,
            pad.allowed_amount =  case when v_rest_amount>0 then v_rest_amount else 0 end,
            pad.remarks =  case when (pad.approved_amount > v_rest_amount)  then case when pad.remarks is  null then 'The claimed amount is more than the allowed limit as per  policy benefits.Hence the amount over and above the allowed limit is disallowed' else case when pad.denial_code like '%BENX-005%'then pad.remarks else pad.remarks||';'||'The claimed amount is more than the allowed limit as per  policy benefits.Hence the amount over and above the allowed limit is disallowed' end end end,--else nvl(pad.remarks,'The claimed amount is more than the allowed limit as per  policy benefits.Hence the amount over and above the allowed limit is disallowed') end,
            pad.denial_desc = case when (pad.approved_amount > v_rest_amount)  then  case when pad.denial_desc is  null then 'Annual limit/sublimit amount exceeded' else case when pad.denial_code like '%BENX-005%'then pad.denial_desc else pad.denial_desc||';'||'Annual limit/sublimit amount exceeded' end end else pad.denial_desc end,
            pad.denial_code = case when (pad.approved_amount > v_rest_amount)  then case when pad.denial_code is  null then 'BENX-005' else case when pad.denial_code like '%BENX-005%'then pad.denial_code else pad.denial_code||';'||'BENX-005' end end else pad.denial_code end,
            pad.tpa_denial_desc = case when (pad.approved_amount > v_rest_amount)  then  case when pad.tpa_denial_desc is  null then 'Annual limit/sublimit amount exceeded' else case when pad.tpa_denial_code like '%BENX-005%'then pad.tpa_denial_desc else pad.tpa_denial_desc||';'||'Annual limit/sublimit amount exceeded' end end else pad.tpa_denial_desc end,
            pad.tpa_denial_code = case when (pad.approved_amount > v_rest_amount)  then case when pad.tpa_denial_code is  null then 'BENX-005' else case when pad.tpa_denial_code like '%BENX-005%'then pad.tpa_denial_code else pad.tpa_denial_code||';'||'BENX-005' end end else pad.tpa_denial_code end,
            --pad.benifit_deductible=icd_rec.deduct,
            pad.updated_by = v_added_by,
            pad.updated_date = SYSDATE,
            pad.denial_by_rule_proc_dtls    = case when (pad.approved_amount > v_rest_amount)  then
                                                        TRIM(BOTH ';' FROM (pad.denial_by_rule_proc_dtls||';'||CHR(10)||'authorization_pkg.check_activity_limits'))
                                                   else pad.denial_by_rule_proc_dtls end,
            pad.denial_by_resons            = case when (pad.approved_amount > v_rest_amount)  then
                                                        TRIM(BOTH ';' FROM (pad.denial_by_resons||';'||CHR(10)||'Maternity limit exhausted'))        
                                                   else denial_by_resons end        
      WHERE pad.activity_dtl_seq_id = rec.activity_dtl_seq_id;
      v_rest_amount:=v_remain_amount;

     END LOOP;
     END LOOP;
     
/*   elsif v_benefit_type='OPTC' THEN      --- commented by venu on 26-07-2019 for optical limits calculation is happening wrongly
    FOR master_code IN clm_master_code_cur LOOP
        v_remain_amount:=null;
        v_rest_amount:= nvl(master_code.rule_limit, 0) - v_used_amount;
        FOR rec IN clm_act_cur(master_code.master_activity_code) LOOP
          v_rest_amount := case when rec.approved_amount>v_rest_amount THEN 
						                    v_rest_amount
					                     when rec.approved_amount<=v_rest_amount THEN 
						                     rec.approved_amount
				                    else 
				                      v_rest_amount
				                    end;
           v_remain_amount := case when (nvl(v_remain_amount,master_code.rule_limit)-v_rest_amount) > 0 then nvl(v_remain_amount,master_code.rule_limit)-v_rest_amount else 0 end;                 
           v_used_amount   := v_used_amount + v_rest_amount;
          UPDATE pat_activity_details pad
          SET pad.approved_amount = case when v_rest_amount>0 then v_rest_amount else 0 end,
              pad.allowed_amount =  case when v_rest_amount>0 then v_rest_amount else 0 end,
              pad.remarks =  case when (pad.approved_amount > v_rest_amount)  then case when pad.remarks is  null then 'The claimed amount is more than the allowed limit as per  policy benefits.Hence the amount over and above the allowed limit is disallowed' else case when pad.denial_code like '%BENX-005%'then pad.remarks else pad.remarks||';'||'The claimed amount is more than the allowed limit as per  policy benefits.Hence the amount over and above the allowed limit is disallowed' end end else pad.remarks end,
              pad.denial_desc = case when master_code.v_ava_sum_ins > 0 AND master_code.rule_limit IS NULL then 
                                  pad.denial_desc||';'||'Optical limit has been exceeded '
                                else
                                  case when pad.approved_amount>v_rest_amount then  case when pad.denial_desc is  null then 'Annual limit/sublimit amount exceeded' else case when pad.denial_code like '%BENX-005%'then pad.denial_desc else pad.denial_desc||';'||'Annual limit/sublimit amount exceeded' end end else pad.denial_desc end
                                end,
              pad.denial_code = case when pad.approved_amount>v_rest_amount then case when pad.denial_code is  null then 'BENX-005' else case when pad.denial_code like '%BENX-005%'then pad.denial_code else pad.denial_code||';'||'BENX-005' end end else pad.denial_code end,
              pad.tpa_denial_desc = case when master_code.ava_sum_insured > 0 AND master_code.rule_limit IS NULL then 
                                  pad.tpa_denial_desc||';'||'Optical limit has been exceeded '
                                else
                                  case when pad.approved_amount>v_rest_amount then  case when pad.tpa_denial_desc is  null then 'Annual limit/sublimit amount exceeded' else case when pad.tpa_denial_code like '%BENX-005%'then pad.tpa_denial_desc else pad.tpa_denial_desc||';'||'Annual limit/sublimit amount exceeded' end end else pad.tpa_denial_desc end
                                end,
              pad.tpa_denial_code = case when pad.approved_amount>v_rest_amount then case when pad.tpa_denial_code is  null then 'BENX-005' else case when pad.tpa_denial_code like '%BENX-005%'then pad.tpa_denial_code else pad.tpa_denial_code||';'||'BENX-005' end end else pad.tpa_denial_code end,
              pad.benifit_deductible=NVL(benifit_deductible,icd_rec.deduct),
              pad.updated_by = v_added_by,
              pad.updated_date = SYSDATE,
              pad.denial_by_rule_proc_dtls    = case when (pad.approved_amount > v_rest_amount)  then
                                                          TRIM(BOTH ';' FROM (pad.denial_by_rule_proc_dtls||';'||CHR(10)||'authorization_pkg.check_activity_limits'))
                                                     else pad.denial_by_rule_proc_dtls end,
              pad.denial_by_resons            = case when (pad.approved_amount > v_rest_amount)  then
                                                          TRIM(BOTH ';' FROM (pad.denial_by_resons||';'||CHR(10)||'Optical limit exhausted'))        
                                                     else denial_by_resons end        
          WHERE pad.activity_dtl_seq_id = rec.activity_dtl_seq_id;

          
          v_rest_amount:=v_remain_amount;

     END LOOP;
    END LOOP;*/
    
  ELSIF v_benefit_type ='OPTS' and nvl(v_rule_flag,'WOP')='WOP'  THEN
  
      OPEN GET_CLM_GLOBAL_LIMIT;
         FETCH GET_CLM_GLOBAL_LIMIT INTO v_glb_limit;
           CLOSE GET_CLM_GLOBAL_LIMIT;
  
  
           IF v_glb_limit IS NOT NULL AND v_glob_limit IS NOT NULL THEN    
               v_glob_limit:=Least(v_glob_limit,v_glb_limit);
           ELSIF v_glb_limit IS NULL AND v_glob_limit IS NOT NULL THEN
               v_glob_limit := v_glob_limit;
           ELSIF v_glb_limit IS NOT NULL AND v_glob_limit IS NULL THEN
               v_glob_limit := v_glb_limit;
           END IF;  
        
     FOR  master_act in clm_master_code_cur LOOP
     IF (master_act.master_activity_code ='70450' and master_act.ct_flag ='Y') or
        (master_act.master_activity_code ='70551' and master_act.mri_flag ='Y') then
            v_res_limit1 := v_glb_limit - nvl(v_used_amount1,0); 
      IF v_res_limit1 IS NOT NULL AND master_act.RULE_LIMIT IS NOT NULL THEN 
          v_rest_amount1 := least(v_res_limit1,master_act.rule_limit);
      ELSIF v_res_limit1 IS NULL AND master_act.RULE_LIMIT IS NOT NULL THEN 
          v_rest_amount1 := master_act.RULE_LIMIT;
      ELSIF v_res_limit1 IS NOT NULL AND master_act.RULE_LIMIT IS NULL THEN 
          v_rest_amount1 := v_res_limit1;  
      END IF;
        v_rest_amount1 :=v_rest_amount1;
        v_act_appr_amount1 := v_rest_amount1;
        v_remain_amount1:=null;
        
    FOR child_act in clm_act_cur (master_act.master_activity_code) LOOP
           IF child_act.rule_limit IS NOT NULL AND v_rest_amount1 IS NOT NULL THEN
              v_rest_amount1:= least(v_rest_amount1,child_act.rule_limit);
           ELSIF  child_act.rule_limit IS NULL AND v_rest_amount1 IS NOT NULL THEN
              v_rest_amount1 := v_rest_amount1;
           END IF;
           
        v_rest_amount1:= case when child_act.allowed_amount>v_rest_amount1 then v_rest_amount1 else child_act.allowed_amount end;
        v_remain_amount1:= nvl(v_remain_amount1,v_act_appr_amount1)-NVL(v_rest_amount1,0);
          UPDATE pat_activity_details pad
                SET pad.approved_amount = case when v_rest_amount1>0 then v_rest_amount1 else 0 end,
                    pad.allowed_amount =  case when v_rest_amount1>0 then v_rest_amount1 else 0 end,
                    pad.remarks     = case when (pad.approved_amount > v_rest_amount1)  then case when pad.remarks is  null then 'The claimed amount is more than the allowed limit as per  policy benefits.Hence the amount over and above the allowed limit is disallowed' else case when pad.denial_code like '%BENX-005%'then pad.remarks else pad.remarks||';'||'The claimed amount is more than the allowed limit as per  policy benefits.Hence the amount over and above the allowed limit is disallowed' end end end,
                    pad.denial_desc = case when (pad.approved_amount > v_rest_amount1)  then  case when pad.denial_desc is  null then 'Annual limit/sublimit amount exceeded for op benifit' else case when pad.denial_code like '%BENX-005%'then pad.denial_desc else pad.denial_desc||';'||'Annual limit/sublimit amount exceeded for op benifit' end end else pad.denial_desc end,
                    pad.denial_code = case when (pad.approved_amount > v_rest_amount1)  then case when pad.denial_code is  null then 'BENX-005' else case when pad.denial_code like '%BENX-005%'then pad.denial_code else pad.denial_code||';'||'BENX-005' end end else pad.denial_code end,
                    pad.updated_by = v_added_by,
                    pad.updated_date = SYSDATE,
                    pad.denial_by_rule_proc_dtls    = case when (pad.approved_amount > v_rest_amount1)  then
                                                                TRIM(BOTH ';' FROM (pad.denial_by_rule_proc_dtls||';'||CHR(10)||'authorization_pkg.check_activity_limits'))
                                                           else pad.denial_by_rule_proc_dtls end,
                    pad.denial_by_resons            = case when (pad.approved_amount > v_rest_amount1)  then
                                                                TRIM(BOTH ';' FROM (pad.denial_by_resons||';'||CHR(10)||'outpatient limit exhausted'))        
                                                           else denial_by_resons end
              WHERE pad.activity_dtl_seq_id = child_act.activity_dtl_seq_id;
              v_used_amount1:=nvl(v_used_amount1,0)+v_rest_amount1;
              v_rest_amount1:=v_remain_amount1;
              v_act_appr_amount1 := v_act_appr_amount1-v_used_amount1;
       END LOOP;
     ELSE
           v_res_limit := v_glob_limit -nvl(v_used_amount,0);
      IF v_res_limit IS NOT NULL AND master_act.RULE_LIMIT IS NOT NULL THEN 
          v_rest_amount := least(v_res_limit,master_act.rule_limit);
      ELSIF v_res_limit IS NULL AND master_act.RULE_LIMIT IS NOT NULL THEN 
          v_rest_amount := master_act.RULE_LIMIT;
      ELSIF v_res_limit IS NOT NULL AND master_act.RULE_LIMIT IS NULL THEN 
          v_rest_amount := v_res_limit;  
      END IF;
      
        v_rest_amount :=v_rest_amount;
        v_act_appr_amount := v_rest_amount;
        v_remain_amount:=null;
    FOR child_act in clm_act_cur (master_act.master_activity_code) LOOP
           IF child_act.rule_limit IS NOT NULL AND v_rest_amount IS NOT NULL THEN
              v_rest_amount:= least(v_rest_amount,child_act.rule_limit);
           ELSIF  child_act.rule_limit IS NULL AND v_rest_amount IS NOT NULL THEN
              v_rest_amount := v_rest_amount;
           END IF;
           
        v_rest_amount:= case when child_act.allowed_amount>v_rest_amount then v_rest_amount else child_act.allowed_amount end;
        v_remain_amount:= nvl(v_remain_amount,v_act_appr_amount)-NVL(v_rest_amount,0);
          UPDATE pat_activity_details pad
                SET pad.approved_amount = case when v_rest_amount>0 then v_rest_amount else 0 end,
                    pad.allowed_amount =  case when v_rest_amount>0 then v_rest_amount else 0 end,
                    pad.remarks     = case when (pad.approved_amount > v_rest_amount)  then case when pad.remarks is  null then 'The claimed amount is more than the allowed limit as per  policy benefits.Hence the amount over and above the allowed limit is disallowed' else case when pad.denial_code like '%BENX-005%'then pad.remarks else pad.remarks||';'||'The claimed amount is more than the allowed limit as per  policy benefits.Hence the amount over and above the allowed limit is disallowed' end end end,
                    pad.denial_desc = case when (pad.approved_amount > v_rest_amount)  then  case when pad.denial_desc is  null then 'Annual limit/sublimit amount exceeded for op benifit' else case when pad.denial_code like '%BENX-005%'then pad.denial_desc else pad.denial_desc||';'||'Annual limit/sublimit amount exceeded for op benifit' end end else pad.denial_desc end,
                    pad.denial_code = case when (pad.approved_amount > v_rest_amount)  then case when pad.denial_code is  null then 'BENX-005' else case when pad.denial_code like '%BENX-005%'then pad.denial_code else pad.denial_code||';'||'BENX-005' end end else pad.denial_code end,
                    pad.updated_by = v_added_by,
                    pad.updated_date = SYSDATE,
                    pad.denial_by_rule_proc_dtls    = case when (pad.approved_amount > v_rest_amount)  then
                                                                TRIM(BOTH ';' FROM (pad.denial_by_rule_proc_dtls||';'||CHR(10)||'authorization_pkg.check_activity_limits'))
                                                           else pad.denial_by_rule_proc_dtls end,
                    pad.denial_by_resons            = case when (pad.approved_amount > v_rest_amount)  then
                                                                TRIM(BOTH ';' FROM (pad.denial_by_resons||';'||CHR(10)||'outpatient limit exhausted'))        
                                                           else denial_by_resons end
              WHERE pad.activity_dtl_seq_id = child_act.activity_dtl_seq_id;
              v_used_amount:=nvl(v_used_amount,0)+v_rest_amount;
              v_rest_amount:=v_remain_amount;
              v_act_appr_amount := v_act_appr_amount-v_used_amount;
       END LOOP;
      END IF; 
   END LOOP; 
  ELSE

     FOR master_code in clm_master_code_cur LOOP
     
      v_remain_amount:=null;
      v_used_amount := 0;
      v_rest_amount:=master_code.rule_limit - case when master_code.master_activity_code = '11980' then 0 else v_used_amount end;
      v_rest_amount := case when v_rest_amount > 0 then v_rest_amount else 0 end;
      
     FOR rec in clm_act_cur(master_code.master_activity_code) loop

       if master_code.master_activity_code not in ('17.03','17.17') then
      v_rest_amount:=CASE WHEN rec.approved_amount>v_rest_amount  THEN v_rest_amount  WHEN rec.approved_amount<=v_rest_amount  THEN rec.approved_amount  ELSE v_rest_amount END;
      v_remain_amount:=nvl(v_remain_amount,master_code.rule_limit)-v_rest_amount;
      v_used_amount := nvl(v_used_amount, 0) + v_rest_amount;
       
       UPDATE pat_activity_details pad
        SET pad.approved_amount = case when v_rest_amount>0 then v_rest_amount else 0 end,
            pad.allowed_amount =  case when v_rest_amount>0 then v_rest_amount else 0 end,
            pad.remarks =  case when (pad.approved_amount > v_rest_amount)  then case when pad.remarks is  null then 'The claimed amount is more than the allowed limit as per  policy benefits.Hence the amount over and above the allowed limit is disallowed' else case when pad.denial_code like '%BENX-005%'then pad.remarks else pad.remarks||';'||'The claimed amount is more than the allowed limit as per  policy benefits.Hence the amount over and above the allowed limit is disallowed' end end else pad.remarks end,
            pad.denial_desc = case when (pad.approved_amount > v_rest_amount)  then  case when pad.denial_desc is  null then 'Annual limit/sublimit amount exceeded' else case when pad.denial_code like '%BENX-005%'then pad.denial_desc else pad.denial_desc||';'||'Annual limit/sublimit amount exceeded' end end else pad.denial_desc end,
            pad.denial_code = case when (pad.approved_amount > v_rest_amount)  then case when pad.denial_code is  null then 'BENX-005' else case when pad.denial_code like '%BENX-005%'then pad.denial_code else pad.denial_code||';'||'BENX-005' end end else pad.denial_code end,
            pad.tpa_denial_desc = case when (pad.approved_amount > v_rest_amount)  then  case when pad.tpa_denial_desc is  null then 'Annual limit/sublimit amount exceeded' else case when pad.tpa_denial_code like '%BENX-005%'then pad.tpa_denial_desc else pad.tpa_denial_desc||';'||'Annual limit/sublimit amount exceeded' end end else pad.tpa_denial_desc end,
            pad.tpa_denial_code = case when (pad.approved_amount > v_rest_amount)  then case when pad.tpa_denial_code is  null then 'BENX-005' else case when pad.tpa_denial_code like '%BENX-005%'then pad.tpa_denial_code else pad.tpa_denial_code||';'||'BENX-005' end end else pad.tpa_denial_code end,
            pad.updated_by = v_added_by,
            pad.updated_date = SYSDATE,
            pad.denial_by_rule_proc_dtls    = case when (pad.approved_amount > v_rest_amount)  then
                                                        TRIM(BOTH ';' FROM (pad.denial_by_rule_proc_dtls||';'||CHR(10)||'authorization_pkg.check_activity_limits'))
                                                   else pad.denial_by_rule_proc_dtls end,
            pad.denial_by_resons            = case when (pad.approved_amount > v_rest_amount)  then
                                                        TRIM(BOTH ';' FROM (pad.denial_by_resons||';'||CHR(10)||'Limit exhausted'))        
                                                   else denial_by_resons end        
      WHERE pad.activity_dtl_seq_id = rec.activity_dtl_seq_id and pad.claim_seq_id = v_seq_id;
      v_rest_amount:=v_remain_amount;
       elsif master_code.master_activity_code  in ('17.03','17.17') and rec.rule_unit!='PD'  then 
         v_rest_amount:=CASE WHEN rec.approved_amount>v_rest_amount  THEN v_rest_amount  WHEN rec.approved_amount<=v_rest_amount  THEN rec.approved_amount  ELSE v_rest_amount END;
       v_remain_amount:=nvl(v_remain_amount,master_code.rule_limit)-v_rest_amount;
       UPDATE pat_activity_details pad
        SET pad.approved_amount = case when v_rest_amount>0 then v_rest_amount else 0 end,
            pad.allowed_amount =  case when v_rest_amount>0 then v_rest_amount else 0 end,
            pad.remarks =  case when (pad.approved_amount > v_rest_amount)  then case when pad.remarks is  null then 'The claimed amount is more than the allowed limit as per  policy benefits.Hence the amount over and above the allowed limit is disallowed' else case when pad.denial_code like '%BENX-005%'then pad.remarks else pad.remarks||';'||'The claimed amount is more than the allowed limit as per  policy benefits.Hence the amount over and above the allowed limit is disallowed' end end else pad.remarks end,
            pad.denial_desc = case when (pad.approved_amount > v_rest_amount)  then  case when pad.denial_desc is  null then 'Annual limit/sublimit amount exceeded' else case when pad.denial_code like '%BENX-005%'then pad.denial_desc else pad.denial_desc||';'||'Annual limit/sublimit amount exceeded' end end else pad.denial_desc end,
            pad.denial_code = case when (pad.approved_amount > v_rest_amount)  then case when pad.denial_code is  null then 'BENX-005' else case when pad.denial_code like '%BENX-005%'then pad.denial_code else pad.denial_code||';'||'BENX-005' end end else pad.denial_code end,
            pad.tpa_denial_desc = case when (pad.approved_amount > v_rest_amount)  then  case when pad.tpa_denial_desc is  null then 'Annual limit/sublimit amount exceeded' else case when pad.tpa_denial_code like '%BENX-005%'then pad.tpa_denial_desc else pad.tpa_denial_desc||';'||'Annual limit/sublimit amount exceeded' end end else pad.tpa_denial_desc end,
            pad.tpa_denial_code = case when (pad.approved_amount > v_rest_amount)  then case when pad.tpa_denial_code is  null then 'BENX-005' else case when pad.tpa_denial_code like '%BENX-005%'then pad.tpa_denial_code else pad.tpa_denial_code||';'||'BENX-005' end end else pad.tpa_denial_code end,
            pad.updated_by = v_added_by,
            pad.updated_date = SYSDATE,
            pad.denial_by_rule_proc_dtls    = case when (pad.approved_amount > v_rest_amount)  then
                                                        TRIM(BOTH ';' FROM (pad.denial_by_rule_proc_dtls||';'||CHR(10)||'authorization_pkg.check_activity_limits'))
                                                   else pad.denial_by_rule_proc_dtls end,
            pad.denial_by_resons            = case when (pad.approved_amount > v_rest_amount)  then
                                                        TRIM(BOTH ';' FROM (pad.denial_by_resons||';'||CHR(10)||'Limit exhausted'))        
                                                   else denial_by_resons end        
      WHERE pad.activity_dtl_seq_id = rec.activity_dtl_seq_id;
      v_rest_amount:=v_remain_amount;

       end if;
     END LOOP;
     END LOOP;
    
     /*FOR master_code in clm_master_code_cur LOOP
     --if nvl(v_item_sum,0)>nvl(master_code.rule_limit,0) then
      v_rest_amount:=master_code.rule_limit;
     FOR rec in clm_act_cur(master_code.master_activity_code) loop
      v_rest_amount:=CASE WHEN rec.approved_amount>v_rest_amount  THEN v_rest_amount  WHEN rec.approved_amount<=v_rest_amount  THEN rec.approved_amount  ELSE v_rest_amount END;
      v_remain_amount:=nvl(v_remain_amount,master_code.rule_limit)-v_rest_amount;
       UPDATE pat_activity_details pad
        SET pad.approved_amount = case when v_rest_amount>0 then v_rest_amount else 0 end,
            pad.allowed_amount =  case when v_rest_amount>0 then v_rest_amount else 0 end,
            pad.remarks =  case when pad.approved_amount>v_rest_amount then case when pad.remarks is  null then 'The claimed amount is more than the allowed limit as per  policy benefits.Hence the amount over and above the allowed limit is disallowed' else case when pad.denial_code like '%BENX-005%'then pad.remarks else pad.remarks||';'||'The claimed amount is more than the allowed limit as per  policy benefits.Hence the amount over and above the allowed limit is disallowed' end end else pad.remarks end,
            pad.denial_desc = case when pad.approved_amount>v_rest_amount then  case when pad.denial_desc is  null then 'Annual limit/sublimit amount exceeded' else case when pad.denial_code like '%BENX-005%'then pad.denial_desc else pad.denial_desc||';'||'Annual limit/sublimit amount exceeded' end end else pad.denial_desc end,
            pad.denial_code = case when pad.approved_amount>v_rest_amount then case when pad.denial_code is  null then 'BENX-005' else case when pad.denial_code like '%BENX-005%'then pad.denial_code else pad.denial_code||';'||'BENX-005' end end else pad.denial_code end,
            pad.updated_by = v_added_by,
            pad.updated_date = SYSDATE        
      WHERE pad.activity_dtl_seq_id = rec.activity_dtl_seq_id;
      v_rest_amount:=v_remain_amount;
     END LOOP;
     --end if;
     END LOOP;*/
     end if;

    OPEN act_cur_clm;
    FETCH act_cur_clm INTO act_rec;
    CLOSE act_cur_clm;

   UPDATE clm_authorization_details A
    SET a.tot_gross_amount           = act_rec.tot_gross_amount,
        a.tot_discount_amount        = act_rec.tot_discount_amount,
        a.tot_disc_gross_amount      = act_rec.tot_disc_gross_amount,
        a.tot_patient_share_amount   = act_rec.tot_patient_share_amount,
        a.tot_net_amount             = act_rec.tot_net_amount,
        a.tot_allowed_amount         = act_rec.tot_allowed_amount,
        a.tot_approved_amount        = act_rec.tot_approved_amount,
        a.remarks                    = v_remarks
   WHERE a.claim_seq_id           = v_seq_id 
   RETURNING a.tot_approved_amount INTO v_final_allowed_amount;

  ELSE

    IF icd_rec.day_care_icd_group_id='ICD001' and icd_rec.benifit_type= 'OPTS' AND NVL(icd_psy_rec.master_icd_code, 'NA') NOT IN ('F09', 'B20', 'E66.9', 'E55.9', 'Q00.0', 'C80.1', 'A65', 'Z00.121', 'B16.9', 'B17.11') AND NVL(icd_rec.limit_applied_flag,'OCL') IN ('OCL','TSI') THEN 
      IF icd_rec.limit_applied_flag='TSI' THEN
       v_glob_limit:=icd_rec.sum_ins;
      ELSE 
        v_glob_limit:=nvl(icd_rec.rule_limit,0);
     END IF;
      
   FOR p_rec in clm_master_code_cur LOOP 
      v_glb_limit:=v_glob_limit- NVL(v_used_amount,0);
     IF v_glb_limit IS NOT NULL AND p_rec.rule_limit IS NOT NULL THEN   
       v_rest_amount := least (v_glb_limit,p_rec.rule_limit);
     ELSIF v_glb_limit IS NULL AND p_rec.rule_limit IS NOT NULL THEN   
       v_rest_amount := p_rec.rule_limit;
     ELSIF v_glb_limit IS NOT NULL AND p_rec.rule_limit IS NULL THEN   
       v_rest_amount := v_glb_limit;  
     END IF;
     
      v_rest_amount := v_rest_amount;
      v_act_appr_amount := v_rest_amount;
      v_remain_amount := null;
     FOR rec in clm_act_cur(p_rec.master_activity_code) loop
     
      IF v_rest_amount IS NOT NULL AND rec.rule_limit IS NOT NULL THEN
        v_rest_amount := least(v_rest_amount,rec.rule_limit);
      ELSIF v_rest_amount IS NOT NULL AND rec.rule_limit IS NULL THEN
        v_rest_amount := v_rest_amount;
      ELSIF v_rest_amount IS NULL AND rec.rule_limit IS NOT NULL THEN
        v_rest_amount := rec.rule_limit;
      END IF;
       
       v_rest_amount:=CASE WHEN rec.approved_amount>v_rest_amount  THEN v_rest_amount  WHEN rec.approved_amount<=v_rest_amount  THEN rec.approved_amount  ELSE v_rest_amount END;
       v_remain_amount:=nvl(v_remain_amount,v_act_appr_amount)-v_rest_amount;
       UPDATE pat_activity_details pad
        SET pad.approved_amount = case when v_rest_amount>0 then v_rest_amount else 0 end,
            pad.allowed_amount =  case when v_rest_amount>0 then v_rest_amount else 0 end,
            pad.remarks =  case when (pad.approved_amount > v_rest_amount)  then case when pad.remarks is  null then ' Chronic limit has been exceeded' else case when pad.denial_code like '%BENX-005%'then ' Chronic limit has been exceeded' else trim(LEADING ';' FROM pad.remarks||';'||' Chronic limit has been exceeded') end end else trim(LEADING ';' FROM pad.remarks||';'||' Chronic limit has been exceeded') end,
            pad.denial_desc = case when (pad.approved_amount > v_rest_amount)  then  case when pad.denial_desc is  null then 'Chronic limit has been exceeded' else case when pad.denial_code like '%BENX-005%'then pad.denial_desc else trim(LEADING ';' FROM pad.denial_desc||';'||'Chronic limit has been exceeded ') end end else pad.denial_desc end,
            pad.denial_code = case when (pad.approved_amount > v_rest_amount)  then case when pad.denial_code is  null then 'BENX-005' else case when pad.denial_code like '%BENX-005%'then pad.denial_code else trim(LEADING ';' FROM pad.denial_code||';'||'BENX-005') end end else pad.denial_code end,
            pad.tpa_denial_desc = case when (pad.approved_amount > v_rest_amount)  then  case when pad.tpa_denial_desc is  null then 'Annual limit/sublimit amount exceeded' else case when pad.tpa_denial_code like '%BENX-005%'then pad.tpa_denial_desc else pad.tpa_denial_desc||';'||'Annual limit/sublimit amount exceeded' end end else pad.tpa_denial_desc end,
            pad.tpa_denial_code = case when (pad.approved_amount > v_rest_amount)  then case when pad.tpa_denial_code is  null then 'BENX-005' else case when pad.tpa_denial_code like '%BENX-005%'then pad.tpa_denial_code else pad.tpa_denial_code||';'||'BENX-005' end end else pad.tpa_denial_code end,
            --pad.benifit_deductible=icd_rec.deduct,
            pad.updated_by = v_added_by,
            pad.updated_date = SYSDATE,
            pad.denial_by_rule_proc_dtls    = case when (pad.approved_amount > v_rest_amount)  then
                                                        TRIM(BOTH ';' FROM (pad.denial_by_rule_proc_dtls||';'||CHR(10)||'authorization_pkg.check_activity_limits'))
                                                   else pad.denial_by_rule_proc_dtls end,
            pad.denial_by_resons            = case when (pad.approved_amount > v_rest_amount)  then
                                                        TRIM(BOTH ';' FROM (pad.denial_by_resons||';'||CHR(10)||'Chronic limit exhausted'))        
                                                   else denial_by_resons end        
      WHERE pad.activity_dtl_seq_id = rec.activity_dtl_seq_id;
      v_used_amount := nvl(v_used_amount,0) + v_rest_amount;
      v_rest_amount:=v_remain_amount;
      v_act_appr_amount := v_act_appr_amount - nvl(v_used_amount,0);
     END LOOP;
   END LOOP;
   ELSIF icd_rec.day_care_icd_group_id='ICD001' and icd_rec.benifit_type= 'IPT' and nvl(icd_rec.limit_applied_flag,'OCL') IN ('OCL','TSI')  THEN 
     
     IF icd_rec.limit_applied_flag='TSI' THEN
       v_glob_limit:=icd_rec.sum_ins;
     ELSE 
        v_glob_limit:=nvl(icd_rec.rule_limit,0);
     END IF;
      
   FOR p_rec in clm_master_code_cur LOOP 
       v_glb_limit:= v_glob_limit-NVL(v_used_amount,0);
     IF v_glb_limit IS NOT NULL AND p_rec.rule_limit IS NOT NULL THEN   
       v_rest_amount := least (v_glb_limit,p_rec.rule_limit);
     ELSIF v_glb_limit IS NULL AND p_rec.rule_limit IS NOT NULL THEN   
       v_rest_amount := p_rec.rule_limit;
     ELSIF v_glb_limit IS NOT NULL AND p_rec.rule_limit IS NULL THEN   
       v_rest_amount := v_glb_limit;  
     END IF;
     
      v_rest_amount := v_rest_amount;
     v_act_appr_amount:= v_rest_amount ;
      v_remain_amount := null;
     FOR rec in clm_act_cur(p_rec.master_activity_code) loop
     
      IF v_rest_amount IS NOT NULL AND rec.rule_limit IS NOT NULL THEN
        v_rest_amount := least(v_rest_amount,rec.rule_limit);
      ELSIF v_rest_amount IS NOT NULL AND rec.rule_limit IS NULL THEN
        v_rest_amount := v_rest_amount;
      ELSIF v_rest_amount IS NULL AND rec.rule_limit IS NOT NULL THEN
        v_rest_amount := rec.rule_limit;
      END IF;
      
     v_rest_amount:=CASE WHEN rec.approved_amount>v_rest_amount  THEN v_rest_amount  WHEN rec.approved_amount<=v_rest_amount  THEN rec.approved_amount  ELSE v_rest_amount END;
      v_remain_amount:=nvl(v_remain_amount,v_act_appr_amount)-v_rest_amount;
       UPDATE pat_activity_details pad
        SET pad.approved_amount = case when v_rest_amount>0 then v_rest_amount else 0 end,
            pad.allowed_amount =  case when v_rest_amount>0 then v_rest_amount else 0 end,
            pad.remarks = case when icd_rec.remarks is null then case when (pad.approved_amount > v_rest_amount)  then case when pad.remarks is  null then ' Chronic limit has been exceeded' else case when pad.denial_code like '%BENX-005%'then 'Chronic limit has been exceeded' else pad.remarks||';'||' Chronic limit has been exceeded' end end else pad.remarks end else icd_rec.remarks end,
            pad.denial_desc = case when icd_rec.remarks is null then case when (pad.approved_amount > v_rest_amount)  then  case when pad.denial_desc is  null then 'Annual limit/sublimit amount exceeded' else case when pad.denial_code like '%BENX-005%'then pad.denial_desc else pad.denial_desc||';'||'Annual limit/sublimit amount exceeded' end end else pad.denial_desc end else icd_rec.remarks end,
            pad.denial_code = case when icd_rec.denial_reason is null then case when (pad.approved_amount > v_rest_amount)  then case when pad.denial_code is  null then 'BENX-005' else case when pad.denial_code like '%BENX-005%'then pad.denial_code else pad.denial_code||';'||'BENX-005' end end else pad.denial_code end else icd_rec.denial_reason end,
            --pad.benifit_deductible=icd_rec.deduct,
            pad.updated_by = v_added_by,
            pad.updated_date = SYSDATE,
            pad.denial_by_rule_proc_dtls    = case when (pad.approved_amount > v_rest_amount)  then
                                                        TRIM(BOTH ';' FROM (pad.denial_by_rule_proc_dtls||';'||CHR(10)||'authorization_pkg.check_activity_limits'))
                                                   else pad.denial_by_rule_proc_dtls end,
            pad.denial_by_resons            = case when (pad.approved_amount > v_rest_amount)  then
                                                        TRIM(BOTH ';' FROM (pad.denial_by_resons||';'||CHR(10)||'Chronic limit exhausted'))        
                                                   else denial_by_resons end        
      WHERE pad.activity_dtl_seq_id = rec.activity_dtl_seq_id;
      v_used_amount := nvl(v_used_amount,0) + v_rest_amount;
      v_rest_amount:=v_remain_amount;
      v_act_appr_amount := v_act_appr_amount - nvl(v_used_amount,0);
     END LOOP;  
  END LOOP;

     ELSIF NVL(icd_psy_rec.master_icd_code, 'NA') IN ('F09', 'B20', 'E55.9', 'Q00.0', 'C80.1', 'A65', 'Z00.121', 'B16.9', 'B17.11')  AND nvl(icd_psy_rec.limit_applied_flag,'OPL') IN ('OPL','TSI') then
     
     v_pat_aprov_amount:= nvl(icd_psy_rec.rule_limit,0);
     
      IF icd_rec.limit_applied_flag='TSI' THEN
       v_glob_limit:=icd_psy_rec.sum_ins;
     ELSE 
        v_glob_limit:=nvl(icd_psy_rec.rule_limit,0);
     END IF;
      
   FOR p_rec in clm_master_code_cur LOOP 
       v_glb_limit:= v_glob_limit-NVL(v_used_amount,0);
     IF v_glb_limit IS NOT NULL AND p_rec.rule_limit IS NOT NULL THEN   
       v_rest_amount := least (v_glb_limit,p_rec.rule_limit);
     ELSIF v_glb_limit IS NULL AND p_rec.rule_limit IS NOT NULL THEN   
       v_rest_amount := p_rec.rule_limit;
     ELSIF v_glb_limit IS NOT NULL AND p_rec.rule_limit IS NULL THEN   
       v_rest_amount := v_glb_limit;  
     END IF;
     
      v_rest_amount := v_rest_amount;
      v_act_appr_amount:= v_rest_amount;
      v_remain_amount := null;
     FOR rec in clm_act_cur(p_rec.master_activity_code) loop
     
     IF v_rest_amount IS NOT NULL AND rec.rule_limit IS NOT NULL THEN
        v_rest_amount := least(v_rest_amount,rec.rule_limit);
      ELSIF v_rest_amount IS NOT NULL AND rec.rule_limit IS NULL THEN
        v_rest_amount := v_rest_amount;
      ELSIF v_rest_amount IS NULL AND rec.rule_limit IS NOT NULL THEN
        v_rest_amount := rec.rule_limit;
      END IF;
      
       v_rest_amount:=CASE WHEN rec.approved_amount>v_rest_amount  THEN v_rest_amount  WHEN rec.approved_amount<=v_rest_amount  THEN rec.approved_amount  ELSE v_rest_amount END;
       v_remain_amount:=nvl(v_remain_amount,v_act_appr_amount)-v_rest_amount;
       UPDATE pat_activity_details pad
      SET pad.approved_amount = case when v_rest_amount>0 then v_rest_amount else 0 end,
          pad.allowed_amount =  case when v_rest_amount>0 then v_rest_amount else 0 end,
            pad.remarks =  case when pad.approved_amount>v_rest_amount then case when pad.remarks is  null then ' Psychiatric limit has been exceeded' else case when pad.denial_code like '%BENX-005%'then ' Psychiatric limit has been exceeded' else trim(LEADING ';' FROM pad.remarks||';'||' Psychiatric limit has been exceeded') end end else trim(LEADING ';' FROM pad.remarks||';'||' Psychiatric limit has been exceeded') end,
            pad.denial_desc = case when pad.approved_amount>v_rest_amount then  case when pad.denial_desc is  null then 'Annual limit/sublimit amount exceeded' else case when pad.denial_code like '%BENX-005%'then pad.denial_desc else trim(LEADING ';' FROM pad.denial_desc||';'||'Annual limit/sublimit amount exceeded ') end end else pad.denial_desc end,
            pad.denial_code = case when pad.approved_amount>v_rest_amount then case when pad.denial_code is  null then 'BENX-005' else case when pad.denial_code like '%BENX-005%'then pad.denial_code else trim(LEADING ';' FROM pad.denial_code||';'||'BENX-005') end end else pad.denial_code end,
          pad.tpa_denial_desc = case when (pad.approved_amount > v_rest_amount)  then  case when pad.tpa_denial_desc is  null then 'Annual limit/sublimit amount exceeded' else case when pad.tpa_denial_code like '%BENX-005%'then pad.tpa_denial_desc else pad.tpa_denial_desc||';'||'Annual limit/sublimit amount exceeded' end end else pad.tpa_denial_desc end,
          pad.tpa_denial_code = case when (pad.approved_amount > v_rest_amount)  then case when pad.tpa_denial_code is  null then 'BENX-005' else case when pad.tpa_denial_code like '%BENX-005%'then pad.tpa_denial_code else pad.tpa_denial_code||';'||'BENX-005' end end else pad.tpa_denial_code end,
          --pad.benifit_deductible=icd_rec.deduct,
          pad.updated_by = v_added_by,
            pad.updated_date = SYSDATE,
            pad.denial_by_rule_proc_dtls    = case when (pad.approved_amount > v_rest_amount)  then
                                                        TRIM(BOTH ';' FROM (pad.denial_by_rule_proc_dtls||';'||CHR(10)||'authorization_pkg.check_activity_limits'))
                                                   else pad.denial_by_rule_proc_dtls end,
            pad.denial_by_resons            = case when (pad.approved_amount > v_rest_amount)  then
                                                        TRIM(BOTH ';' FROM (pad.denial_by_resons||';'||CHR(10)||'Psychiatric limit exhausted'))        
                                                   else denial_by_resons end        
      WHERE pad.activity_dtl_seq_id = rec.activity_dtl_seq_id;
      v_used_amount := nvl(v_used_amount,0) + v_rest_amount;
     v_rest_amount:=v_remain_amount;
      v_act_appr_amount := v_act_appr_amount - nvl(v_used_amount,0);
    END LOOP;
    END LOOP;

   ELSIF v_prim_icd = 'E66.9' THEN
     
     FOR obs IN clm_obesyti_cur LOOP
       v_dntl_used_amt := 0;
       
        v_appr_amt := case when (obs.benefit_limit - v_used_amount) > 0 then (obs.benefit_limit - v_used_amount) else 0 end;
        
        IF obs.master_activity_code = 'MED' THEN
          v_remain_amount := NULL;
            FOR rec in  clm_obesyti_med_act(obs.master_activity_code) LOOP
              rec.rule_limit := rec.rule_limit - v_dntl_used_amt;
              if v_appr_amt > rec.rule_limit then
                v_appr_amt := rec.rule_limit;
              else
                v_appr_amt := v_appr_amt;
              end if;
              -----
              if v_appr_amt > rec.approved_amount then
                v_rest_amount := rec.approved_amount;
              else
                v_rest_amount := v_appr_amt;
              end if;
              -------
              v_remain_amount := case when nvl(v_remain_amount, v_appr_amt) - v_rest_amount > 0 then nvl(v_remain_amount, v_appr_amt) - v_rest_amount else 0 end;
              v_used_amount := nvl(v_used_amount, 0) + v_rest_amount;
              v_dntl_used_amt := nvl(v_dntl_used_amt, 0) + nvl(v_rest_amount, 0);
              -------
              UPDATE pat_activity_details pad
              SET pad.approved_amount = case when v_rest_amount>0 then v_rest_amount else 0 end,
                  pad.allowed_amount =  case when v_rest_amount>0 then v_rest_amount else 0 end,
                  pad.remarks =  case when (pad.approved_amount > v_rest_amount)  then case when pad.remarks is  null then 'The claimed amount is more than the allowed limit as per  policy benefits.Hence the amount over and above the allowed limit is disallowed' else case when pad.denial_code like '%BENX-005%'then pad.remarks else pad.remarks||';'||'The claimed amount is more than the allowed limit as per  policy benefits.Hence the amount over and above the allowed limit is disallowed' end end else pad.remarks end,--else nvl(pad.remarks,'The claimed amount is more than the allowed limit as per  policy benefits.Hence the amount over and above the allowed limit is disallowed') end,
                  pad.denial_desc = case when (pad.approved_amount > v_rest_amount)  then  case when pad.denial_desc is  null then 'Annual limit/sublimit amount exceeded' else case when pad.denial_code like '%BENX-005%'then pad.denial_desc else pad.denial_desc||';'||'Annual limit/sublimit amount exceeded' end end else pad.denial_desc end,
                  pad.denial_code = case when (pad.approved_amount > v_rest_amount)  then case when pad.denial_code is  null then 'BENX-005' else case when pad.denial_code like '%BENX-005%'then pad.denial_code else pad.denial_code||';'||'BENX-005' end end else pad.denial_code end,
                  pad.updated_by = v_added_by,
                  pad.updated_date = SYSDATE,
                  pad.denial_by_rule_proc_dtls    = case when (pad.approved_amount > v_rest_amount)  then
                                                            TRIM(BOTH ';' FROM (pad.denial_by_rule_proc_dtls||';'||CHR(10)||'authorization_pkg.check_activity_limits'))
                                                       else pad.denial_by_rule_proc_dtls end,
                  pad.denial_by_resons            = case when (pad.approved_amount > v_rest_amount)  then
                                                            TRIM(BOTH ';' FROM (pad.denial_by_resons||';'||CHR(10)||'Pbesyti limit exhausted'))        
                                                       else denial_by_resons end        
             WHERE pad.activity_dtl_seq_id = rec.activity_dtl_seq_id;
            v_appr_amt := v_remain_amount;
            END LOOP;
              
        ELSE--------------MED    
            FOR rec in  clm_obesyti_act(obs.master_activity_code) LOOP
              v_remain_amount := NULL;
              rec.rule_limit := rec.rule_limit - v_dntl_used_amt;
              if v_appr_amt > rec.rule_limit then
                v_appr_amt := rec.rule_limit;
              else
                v_appr_amt := v_appr_amt;
              end if;
              -----
              if v_appr_amt > rec.approved_amount then
                v_rest_amount := rec.approved_amount;
              else
                v_rest_amount := v_appr_amt;
              end if;
              -------
              v_remain_amount := case when nvl(v_remain_amount, v_appr_amt) - v_rest_amount > 0 then nvl(v_remain_amount, v_appr_amt) - v_rest_amount else 0 end;
              v_used_amount := nvl(v_used_amount, 0) + v_rest_amount;
              v_dntl_used_amt := nvl(v_dntl_used_amt, 0) + nvl(v_rest_amount, 0);
              -------
              UPDATE pat_activity_details pad
              SET pad.approved_amount = case when v_rest_amount>0 then v_rest_amount else 0 end,
                  pad.allowed_amount =  case when v_rest_amount>0 then v_rest_amount else 0 end,
                  pad.remarks =  case when (pad.approved_amount > v_rest_amount)  then case when pad.remarks is  null then 'The claimed amount is more than the allowed limit as per  policy benefits.Hence the amount over and above the allowed limit is disallowed' else case when pad.denial_code like '%BENX-005%'then pad.remarks else trim(LEADING ';' FROM pad.remarks||';'||'The claimed amount is more than the allowed limit as per  policy benefits.Hence the amount over and above the allowed limit is disallowed') end end else pad.remarks end,--else nvl(pad.remarks,'The claimed amount is more than the allowed limit as per  policy benefits.Hence the amount over and above the allowed limit is disallowed') end,
                  pad.denial_desc = case when (pad.approved_amount > v_rest_amount)  then  case when pad.denial_desc is  null then 'Annual limit/sublimit amount exceeded' else case when pad.denial_code like '%BENX-005%'then pad.denial_desc else pad.denial_desc||';'||'Annual limit/sublimit amount exceeded' end end else pad.denial_desc end,
                  pad.denial_code = case when (pad.approved_amount > v_rest_amount)  then case when pad.denial_code is  null then 'BENX-005' else case when pad.denial_code like '%BENX-005%'then pad.denial_code else pad.denial_code||';'||'BENX-005' end end else pad.denial_code end,
                  pad.updated_by = v_added_by,
                  pad.updated_date = SYSDATE,
                  pad.denial_by_rule_proc_dtls    = case when (pad.approved_amount > v_rest_amount)  then
                                                            TRIM(BOTH ';' FROM (pad.denial_by_rule_proc_dtls||';'||CHR(10)||'authorization_pkg.check_activity_limits'))
                                                       else pad.denial_by_rule_proc_dtls end,
                  pad.denial_by_resons            = case when (pad.approved_amount > v_rest_amount)  then
                                                            TRIM(BOTH ';' FROM (pad.denial_by_resons||';'||CHR(10)||'Pbesyti limit exhausted'))        
                                                       else denial_by_resons end        
             WHERE pad.activity_dtl_seq_id = rec.activity_dtl_seq_id;
            v_appr_amt := v_remain_amount;
          END LOOP;
      END IF;
    END LOOP;
     -------
     
   ELSIF v_benefit_type='DNTL' THEN
     FOR dent IN clm_get_dent_grp_code_cur LOOP
       v_remain_amount := NULL;
       v_dntl_used_amt := 0;
        v_appr_amt := case when (dent.benefit_limit - v_used_amount) > 0 then  (dent.benefit_limit - v_used_amount) else 0 end;
       
       FOR rec in clm_get_dent_code_cur(dent.specific_service_code) loop
          v_appr_amt := case when (dent.benefit_limit - v_used_amount) > 0 then  (dent.benefit_limit - v_used_amount) else 0 end;
          if v_appr_amt > rec.rule_limit then
            v_appr_amt := rec.rule_limit;
          else
            v_appr_amt := v_appr_amt;
          end if;
          -----
          if v_appr_amt > rec.approved_amount then
            v_rest_amount := rec.approved_amount;
          else
            v_rest_amount := v_appr_amt;
          end if;
          -------
          v_remain_amount := case when nvl(v_remain_amount, v_appr_amt) - v_rest_amount > 0 then nvl(v_remain_amount, v_appr_amt) - v_rest_amount else 0 end;
          v_used_amount := nvl(v_used_amount, 0) + v_rest_amount;
          v_dntl_used_amt := nvl(v_dntl_used_amt, 0) + nvl(v_rest_amount, 0);
          -------
          UPDATE pat_activity_details pad
          SET pad.approved_amount = case when v_rest_amount>0 then v_rest_amount else 0 end,
              pad.allowed_amount =  case when v_rest_amount>0 then v_rest_amount else 0 end,
              pad.remarks =  case when (pad.approved_amount > v_rest_amount)  then case when pad.remarks is  null then 'The claimed amount is more than the allowed limit as per  policy benefits.Hence the amount over and above the allowed limit is disallowed' else case when pad.denial_code like '%BENX-005%'then pad.remarks else pad.remarks||';'||'The claimed amount is more than the allowed limit as per  policy benefits.Hence the amount over and above the allowed limit is disallowed' end end else pad.remarks end,
              pad.denial_desc = case when dent.ava_sum_insured > 0 AND dent.benefit_limit IS NULL then 
                                  pad.denial_desc||';'||'Dental limit has been exceeded '
                                else
                                  case when pad.approved_amount>v_rest_amount then  case when pad.denial_desc is  null then 'Annual limit/sublimit amount exceeded' else case when pad.denial_code like '%BENX-005%'then pad.denial_desc else pad.denial_desc||';'||'Annual limit/sublimit amount exceeded' end end else pad.denial_desc end
                                end,
              pad.denial_code = case when pad.approved_amount>v_rest_amount then case when pad.denial_code is  null then 'BENX-005' else case when pad.denial_code like '%BENX-005%'then pad.denial_code else pad.denial_code||';'||'BENX-005' end end else pad.denial_code end,
              pad.tpa_denial_desc = case when dent.ava_sum_insured > 0 AND dent.benefit_limit IS NULL then 
                                    pad.tpa_denial_desc||';'||'Dental limit has been exceeded '
                                  else
                                    case when pad.approved_amount>v_rest_amount then  case when pad.tpa_denial_desc is  null then 'Annual limit/sublimit amount exceeded' else case when pad.tpa_denial_code like '%BENX-005%'then pad.tpa_denial_desc else pad.tpa_denial_desc||';'||'Annual limit/sublimit amount exceeded' end end else pad.tpa_denial_desc end
                                  end,
              pad.tpa_denial_code = case when pad.approved_amount>v_rest_amount then case when pad.tpa_denial_code is  null then 'BENX-005' else case when pad.tpa_denial_code like '%BENX-005%'then pad.tpa_denial_code else pad.tpa_denial_code||';'||'BENX-005' end end else pad.tpa_denial_code end,
              pad.benifit_deductible=NVL(benifit_deductible,icd_rec.deduct),
              pad.updated_by = v_added_by,
              pad.updated_date = SYSDATE,
              pad.denial_by_rule_proc_dtls    = case when (pad.approved_amount > v_rest_amount)  then
                                                          TRIM(BOTH ';' FROM (pad.denial_by_rule_proc_dtls||';'||CHR(10)||'authorization_pkg.check_activity_limits'))
                                                     else pad.denial_by_rule_proc_dtls end,
              pad.denial_by_resons            = case when (pad.approved_amount > v_rest_amount)  then
                                                          TRIM(BOTH ';' FROM (pad.denial_by_resons||';'||CHR(10)||'Dental limit exhausted'))        
                                                     else denial_by_resons end        
          WHERE pad.activity_dtl_seq_id = rec.activity_dtl_seq_id;
        v_appr_amt := v_remain_amount;
      end loop;
    end loop;
    ----------------------------

   ELSIF v_benefit_type IN ('MTI', 'IMTI', 'OMTI') OR NVL(v_mat,'N') = 'Y'  THEN
     FOR dent in clm_dental_cur LOOP
      v_pat_aprov_amount:= nvl(dent.benefit_limit,0);
      v_rest_amount:= nvl(dent.benefit_limit,0);
     
      FOR rec in clm_chronic_cur loop
        v_rest_amount:=CASE WHEN rec.approved_amount>v_rest_amount  THEN v_rest_amount  WHEN rec.approved_amount<=v_rest_amount  THEN rec.approved_amount  ELSE v_rest_amount END;
        v_remain_amount:=nvl(v_remain_amount,v_pat_aprov_amount)-v_rest_amount;
       
        UPDATE pat_activity_details pad
        SET pad.approved_amount = case when v_rest_amount>0 then v_rest_amount else 0 end,
            pad.allowed_amount =  case when v_rest_amount>0 then v_rest_amount else 0 end,
            pad.remarks =  case when (pad.approved_amount > v_rest_amount)  then case when pad.remarks is  null then 'The claimed amount is more than the allowed limit as per  policy benefits.Hence the amount over and above the allowed limit is disallowed' else case when pad.denial_code like '%BENX-005%'then pad.remarks else pad.remarks||';'||'The claimed amount is more than the allowed limit as per  policy benefits.Hence the amount over and above the allowed limit is disallowed' end end end,--else nvl(pad.remarks,'The claimed amount is more than the allowed limit as per  policy benefits.Hence the amount over and above the allowed limit is disallowed') end,
            pad.denial_desc = case when (pad.approved_amount > v_rest_amount)  then  case when pad.denial_desc is  null then 'Annual limit/sublimit amount exceeded' else case when pad.denial_code like '%BENX-005%'then pad.denial_desc else pad.denial_desc||';'||'Annual limit/sublimit amount exceeded' end end else case when pad.approved_amount=0 then nvl(pad.denial_desc,'Annual limit/sublimit amount exceeded') end end,
            pad.denial_code = case when (pad.approved_amount > v_rest_amount)  then case when pad.denial_code is  null then 'BENX-005' else case when pad.denial_code like '%BENX-005%'then pad.denial_code else pad.denial_code||';'||'BENX-005' end end else case when pad.approved_amount=0 then nvl(pad.denial_code,'BENX-005') end end,
            pad.tpa_denial_desc = case when (pad.approved_amount > v_rest_amount)  then  case when pad.tpa_denial_desc is  null then 'Annual limit/sublimit amount exceeded' else case when pad.tpa_denial_code like '%BENX-005%'then pad.tpa_denial_desc else pad.tpa_denial_desc||';'||'Annual limit/sublimit amount exceeded' end end else pad.tpa_denial_desc end,
            pad.tpa_denial_code = case when (pad.approved_amount > v_rest_amount)  then case when pad.tpa_denial_code is  null then 'BENX-005' else case when pad.tpa_denial_code like '%BENX-005%'then pad.tpa_denial_code else pad.tpa_denial_code||';'||'BENX-005' end end else pad.tpa_denial_code end,
            --pad.benifit_deductible=icd_rec.deduct,
            pad.updated_by = v_added_by,
            pad.updated_date = SYSDATE,
            pad.denial_by_rule_proc_dtls    = case when (pad.approved_amount > v_rest_amount)  then
                                                        TRIM(BOTH ';' FROM (pad.denial_by_rule_proc_dtls||';'||CHR(10)||'authorization_pkg.check_activity_limits'))
                                                   else pad.denial_by_rule_proc_dtls end,
            pad.denial_by_resons            = case when (pad.approved_amount > v_rest_amount)  then
                                                     TRIM(BOTH ';' FROM (pad.denial_by_resons||';'||CHR(10)||'Maternity limit exhausted'))        
                                              else denial_by_resons end
       WHERE pad.activity_dtl_seq_id = rec.activity_dtl_seq_id;
       
       v_rest_amount:=v_remain_amount;

      END LOOP;
    END LOOP;
  
  ELSIF  v_benefit_type = 'IPT'  THEN                         
    FOR master_code in clm_master_code_cur LOOP
      v_remain_amount:=null;
      v_pat_aprov_amount:= master_code.rule_limit;
      v_rest_amount:= master_code.rule_limit;
     
      FOR rec in clm_act_cur(master_code.master_activity_code) loop

        v_rest_amount:=CASE WHEN rec.approved_amount>v_rest_amount  THEN v_rest_amount  WHEN rec.approved_amount<=v_rest_amount  THEN rec.approved_amount  ELSE v_rest_amount END;
        v_remain_amount:=nvl(v_remain_amount,v_pat_aprov_amount)-v_rest_amount;
        
        UPDATE pat_activity_details pad
        SET pad.approved_amount = case when v_rest_amount>0 then v_rest_amount else 0 end,
            pad.allowed_amount =  case when v_rest_amount>0 then v_rest_amount else 0 end,
            pad.remarks =  case when (pad.approved_amount > v_rest_amount)  then case when pad.remarks is  null then ' The claimed amount is more than the allowed limit as per  policy benefits.Hence the amount over and above the allowed limit is disallowed' else case when pad.denial_code like '%BENX-005%'then pad.remarks else pad.remarks||';'||'The claimed amount is more than the allowed limit as per  policy benefits.Hence the amount over and above the allowed limit is disallowed' end end else pad.remarks end,
            pad.denial_desc = case when (pad.approved_amount > v_rest_amount)  then  case when pad.denial_desc is  null then 'Annual limit/sublimit amount exceeded' else case when pad.denial_code like '%BENX-005%'then pad.denial_desc else pad.denial_desc||';'||'Annual limit/sublimit amount exceeded' end end else pad.denial_desc end,
            pad.denial_code = case when (pad.approved_amount > v_rest_amount)  then case when pad.denial_code is  null then 'BENX-005' else case when pad.denial_code like '%BENX-005%'then pad.denial_code else pad.denial_code||';'||'BENX-005' end end else pad.denial_code end,
            pad.tpa_denial_desc = case when (pad.approved_amount > v_rest_amount)  then  case when pad.tpa_denial_desc is  null then 'Annual limit/sublimit amount exceeded' else case when pad.tpa_denial_code like '%BENX-005%'then pad.tpa_denial_desc else pad.tpa_denial_desc||';'||'Annual limit/sublimit amount exceeded' end end else pad.tpa_denial_desc end,
            pad.tpa_denial_code = case when (pad.approved_amount > v_rest_amount)  then case when pad.tpa_denial_code is  null then 'BENX-005' else case when pad.tpa_denial_code like '%BENX-005%'then pad.tpa_denial_code else pad.tpa_denial_code||';'||'BENX-005' end end else pad.tpa_denial_code end,
            pad.updated_by = v_added_by,
            pad.updated_date = SYSDATE,
            pad.denial_by_rule_proc_dtls    = case when (pad.approved_amount > v_rest_amount)  then
                                                        TRIM(BOTH ';' FROM (pad.denial_by_rule_proc_dtls||';'||CHR(10)||'authorization_pkg.check_activity_limits'))
                                                   else pad.denial_by_rule_proc_dtls end,
            pad.denial_by_resons            = case when (pad.approved_amount > v_rest_amount)  then
                                                     TRIM(BOTH ';' FROM (pad.denial_by_resons||';'||CHR(10)||'Limit exhausted'))        
                                              else denial_by_resons end    
      WHERE pad.activity_dtl_seq_id = rec.activity_dtl_seq_id;
      
      v_rest_amount:=v_remain_amount;

     END LOOP;
   END LOOP;  

       OPEN act_cur_clm;
       FETCH act_cur_clm INTO act_rec;
       CLOSE act_cur_clm;
      v_remain_amount:=null;
    FOR dent in clm_dental_cur LOOP
      v_rest_amount:= nvl(act_rec.tot_allowed_amount,0);
      v_pat_aprov_amount:= nvl(act_rec.tot_allowed_amount,0);
      
      FOR rec in clm_chronic_cur loop

        v_rest_amount:=CASE WHEN rec.approved_amount>v_rest_amount  THEN v_rest_amount  WHEN rec.approved_amount<=v_rest_amount  THEN rec.approved_amount  ELSE v_rest_amount END;
        v_remain_amount:=nvl(v_remain_amount,v_pat_aprov_amount)-v_rest_amount;
        
        UPDATE pat_activity_details pad
        SET pad.approved_amount = case when v_rest_amount>0 then v_rest_amount else 0 end,
            pad.allowed_amount =  case when v_rest_amount>0 then v_rest_amount else 0 end,
            pad.remarks =  case when (pad.approved_amount > v_rest_amount)  then case when pad.remarks is  null then 'The claimed amount is more than the allowed limit as per  policy benefits.Hence the amount over and above the allowed limit is disallowed' else case when pad.denial_code like '%BENX-005%'then pad.remarks else pad.remarks||';'||'The claimed amount is more than the allowed limit as per  policy benefits.Hence the amount over and above the allowed limit is disallowed' end end else nvl(pad.remarks,'The claimed amount is more than the allowed limit as per  policy benefits.Hence the amount over and above the allowed limit is disallowed') end,
            pad.denial_desc = case when (pad.approved_amount > v_rest_amount)  then  case when pad.denial_desc is  null then 'Annual limit/sublimit amount exceeded' else case when pad.denial_code like '%BENX-005%'then pad.denial_desc else pad.denial_desc||';'||'Annual limit/sublimit amount exceeded' end end else pad.denial_desc end,
            pad.denial_code = case when (pad.approved_amount > v_rest_amount)  then case when pad.denial_code is  null then 'BENX-005' else case when pad.denial_code like '%BENX-005%'then pad.denial_code else pad.denial_code||';'||'BENX-005' end end else pad.denial_code end,
            pad.tpa_denial_desc = case when (pad.approved_amount > v_rest_amount)  then  case when pad.tpa_denial_desc is  null then 'Annual limit/sublimit amount exceeded' else case when pad.tpa_denial_code like '%BENX-005%'then pad.tpa_denial_desc else pad.tpa_denial_desc||';'||'Annual limit/sublimit amount exceeded' end end else pad.tpa_denial_desc end,
            pad.tpa_denial_code = case when (pad.approved_amount > v_rest_amount)  then case when pad.tpa_denial_code is  null then 'BENX-005' else case when pad.tpa_denial_code like '%BENX-005%'then pad.tpa_denial_code else pad.tpa_denial_code||';'||'BENX-005' end end else pad.tpa_denial_code end,
            ---pad.benifit_deductible=icd_rec.deduct,
            pad.updated_by = v_added_by,
            pad.updated_date = SYSDATE,
            pad.denial_by_rule_proc_dtls    = case when (pad.approved_amount > v_rest_amount)  then
                                                        TRIM(BOTH ';' FROM (pad.denial_by_rule_proc_dtls||';'||CHR(10)||'authorization_pkg.check_activity_limits'))
                                                   else pad.denial_by_rule_proc_dtls end,
            pad.denial_by_resons            = case when (pad.approved_amount > v_rest_amount)  then
                                                     TRIM(BOTH ';' FROM (pad.denial_by_resons||';'||CHR(10)||'Limit exhausted'))        
                                              else denial_by_resons end        
      WHERE pad.activity_dtl_seq_id = rec.activity_dtl_seq_id;
      v_rest_amount:=v_remain_amount;

     END LOOP;
     END LOOP; ----
       
  /*ELSIF v_benefit_type='OPTC' THEN        --- commented by venu on 26-07-2019
    FOR master_code in clm_master_code_cur LOOP
       v_remain_amount:=null;
       v_pat_aprov_amount:= nvl(master_code.rule_limit,0);
       v_rest_amount:=  nvl(master_code.rule_limit,0) - v_used_amount;
       
       FOR rec IN clm_act_cur(master_code.master_activity_code) LOOP
          v_rest_amount:= least(rec.approved_amount, v_rest_amount);
          
           v_remain_amount := case when (nvl(v_remain_amount,v_pat_aprov_amount)-v_rest_amount) > 0 then nvl(v_remain_amount,v_pat_aprov_amount)-v_rest_amount else 0 end;
           v_used_amount   := v_used_amount + v_rest_amount;
           
           UPDATE pat_activity_details pad
            SET pad.approved_amount = case when v_rest_amount>0 then v_rest_amount else 0 end,
                pad.allowed_amount =  case when v_rest_amount>0 then v_rest_amount else 0 end,
                pad.remarks =  case when (pad.approved_amount > v_rest_amount)  then case when pad.remarks is  null then 'The claimed amount is more than the allowed limit as per  policy benefits.Hence the amount over and above the allowed limit is disallowed' else case when pad.denial_code like '%BENX-005%'then pad.remarks else pad.remarks||';'||'The claimed amount is more than the allowed limit as per  policy benefits.Hence the amount over and above the allowed limit is disallowed' end end else nvl(pad.remarks,'The claimed amount is more than the allowed limit as per  policy benefits.Hence the amount over and above the allowed limit is disallowed') end,
                pad.denial_desc = case when master_code.v_ava_sum_ins > 0 AND master_code.rule_limit IS NULL then 
                                    pad.denial_desc||';'||'Optical limit has been exceeded '
                                  else
                                    case when pad.approved_amount>v_rest_amount then  case when pad.denial_desc is  null then 'Annual limit/sublimit amount exceeded' else case when pad.denial_code like '%BENX-005%'then pad.denial_desc else pad.denial_desc||';'||'Annual limit/sublimit amount exceeded' end end else pad.denial_desc end
                                  end,
                pad.denial_code = case when (pad.approved_amount > v_rest_amount)  then case when pad.denial_code is  null then 'BENX-005' else case when pad.denial_code like '%BENX-005%'then pad.denial_code else pad.denial_code||';'||'BENX-005' end end else pad.denial_code end,
                pad.tpa_denial_desc = case when master_code.ava_sum_insured > 0 AND master_code.rule_limit IS NULL then 
                                  pad.tpa_denial_desc||';'||'Optical limit has been exceeded '
                                else
                                  case when pad.approved_amount>v_rest_amount then  case when pad.tpa_denial_desc is  null then 'Annual limit/sublimit amount exceeded' else case when pad.tpa_denial_code like '%BENX-005%'then pad.tpa_denial_desc else pad.tpa_denial_desc||';'||'Annual limit/sublimit amount exceeded' end end else pad.tpa_denial_desc end
                                end,
                pad.tpa_denial_code = case when pad.approved_amount>v_rest_amount then case when pad.tpa_denial_code is  null then 'BENX-005' else case when pad.tpa_denial_code like '%BENX-005%'then pad.tpa_denial_code else pad.tpa_denial_code||';'||'BENX-005' end end else pad.tpa_denial_code end,
                pad.benifit_deductible=NVL(benifit_deductible,icd_rec.deduct),
                pad.updated_by = v_added_by,
                pad.updated_date = SYSDATE,
                pad.denial_by_rule_proc_dtls    = case when (pad.approved_amount > v_rest_amount)  then
                                                            TRIM(BOTH ';' FROM (pad.denial_by_rule_proc_dtls||';'||CHR(10)||'authorization_pkg.check_activity_limits'))
                                                       else pad.denial_by_rule_proc_dtls end,
                pad.denial_by_resons            = case when (pad.approved_amount > v_rest_amount)  then
                                                            TRIM(BOTH ';' FROM (pad.denial_by_resons||';'||CHR(10)||'Optical limit exhausted'))
                                                       else denial_by_resons end
          WHERE pad.activity_dtl_seq_id = rec.activity_dtl_seq_id;
          
          v_rest_amount:=v_remain_amount;
       END LOOP;
     END LOOP;*/
     
  ELSIF v_benefit_type ='OPTS' and NVL(v_rule_flag,'WOP')='WOP' THEN
  
  
  OPEN GET_CLM_GLOBAL_LIMIT;
    FETCH GET_CLM_GLOBAL_LIMIT INTO v_glb_limit;
       CLOSE GET_CLM_GLOBAL_LIMIT;
       
       
       IF v_glb_limit IS NOT NULL AND v_glob_limit IS NOT NULL THEN    
             v_glob_limit:=Least(v_glob_limit,v_glb_limit);
       ELSIF v_glb_limit IS NULL AND v_glob_limit IS NOT NULL THEN 
             v_glob_limit := v_glob_limit;
       ELSIF v_glb_limit IS NOT NULL AND v_glob_limit IS NULL THEN 
             v_glob_limit := v_glb_limit;
       END IF; 
       
      FOR  master_act in clm_master_code_cur LOOP
         v_res_limit:= v_glob_limit-nvl(v_used_amount,0);
          
          IF v_res_limit IS NOT NULL AND master_act.RULE_LIMIT IS NOT NULL THEN 
             v_rest_amount := least(v_res_limit,master_act.rule_limit);
          ELSIF v_res_limit IS NULL AND master_act.RULE_LIMIT IS NOT NULL THEN 
             v_rest_amount := master_act.RULE_LIMIT;
          ELSIF v_res_limit IS NOT NULL AND master_act.RULE_LIMIT IS NULL THEN 
             v_rest_amount := v_res_limit;  
          END IF;
          
            v_rest_amount :=v_rest_amount;
            v_act_appr_amount := v_rest_amount;
            v_remain_amount:=null;
        FOR child_act in clm_act_cur (master_act.master_activity_code) LOOP
               IF child_act.rule_limit IS NOT NULL AND v_rest_amount IS NOT NULL THEN
                  v_rest_amount:= least(v_rest_amount,child_act.rule_limit);
               ELSIF  v_rest_amount IS NOT NULL THEN
                  v_rest_amount := v_rest_amount;
               END IF;
            v_rest_amount:= case when child_act.allowed_amount>v_rest_amount then v_rest_amount else child_act.allowed_amount end;
            v_remain_amount:= nvl(v_remain_amount,v_act_appr_amount)-NVL(v_rest_amount,0);
              UPDATE pat_activity_details pad
                    SET pad.approved_amount = case when v_rest_amount>0 then v_rest_amount else 0 end,
                        pad.allowed_amount =  case when v_rest_amount>0 then v_rest_amount else 0 end,
                        pad.remarks     = case when (pad.approved_amount > v_rest_amount)  then case when pad.remarks is  null then 'The claimed amount is more than the allowed limit as per  policy benefits.Hence the amount over and above the allowed limit is disallowed' else case when pad.denial_code like '%BENX-005%'then pad.remarks else pad.remarks||';'||'The claimed amount is more than the allowed limit as per  policy benefits.Hence the amount over and above the allowed limit is disallowed' end end end,
                        pad.denial_desc = case when (pad.approved_amount > v_rest_amount)  then  case when pad.denial_desc is  null then 'Annual limit/sublimit amount exceeded for op benifit' else case when pad.denial_code like '%BENX-005%'then pad.denial_desc else pad.denial_desc||';'||'Annual limit/sublimit amount exceeded for op benifit' end end else pad.denial_desc end,
                        pad.denial_code = case when (pad.approved_amount > v_rest_amount)  then case when pad.denial_code is  null then 'BENX-005' else case when pad.denial_code like '%BENX-005%'then pad.denial_code else pad.denial_code||';'||'BENX-005' end end else pad.denial_code end,
                        pad.updated_by = v_added_by,
                        pad.updated_date = SYSDATE,
                        pad.denial_by_rule_proc_dtls    = case when (pad.approved_amount > v_rest_amount)  then
                                                                    TRIM(BOTH ';' FROM (pad.denial_by_rule_proc_dtls||';'||CHR(10)||'authorization_pkg.check_activity_limits'))
                                                               else pad.denial_by_rule_proc_dtls end,
                        pad.denial_by_resons            = case when (pad.approved_amount > v_rest_amount)  then
                                                                    TRIM(BOTH ';' FROM (pad.denial_by_resons||';'||CHR(10)||'outpatient limit exhausted'))        
                                                               else denial_by_resons end
                  WHERE pad.activity_dtl_seq_id = child_act.activity_dtl_seq_id;
                  v_used_amount:=nvl(v_used_amount,0)+v_rest_amount;
                  v_rest_amount:=v_remain_amount;
                  v_act_appr_amount :=v_act_appr_amount - v_used_amount;
           END LOOP; 
       END LOOP;
  ELSE
     FOR master_code in clm_master_code_cur LOOP
       v_remain_amount:=null;
       v_pat_aprov_amount:= master_code.rule_limit;
       v_rest_amount:= master_code.rule_limit;
     
       FOR rec in clm_act_cur(master_code.master_activity_code) loop
          v_rest_amount:=CASE WHEN rec.approved_amount>v_rest_amount  THEN v_rest_amount  WHEN rec.approved_amount<=v_rest_amount  THEN rec.approved_amount  ELSE v_rest_amount END;
          v_remain_amount:=nvl(v_remain_amount,v_pat_aprov_amount)-v_rest_amount;
          
          UPDATE pat_activity_details pad
          SET pad.approved_amount = case when v_rest_amount>0 then v_rest_amount else 0 end,
              pad.allowed_amount =  case when v_rest_amount>0 then v_rest_amount else 0 end,
              pad.remarks =  case when (pad.approved_amount > v_rest_amount)  then case when pad.remarks is  null then ' The claimed amount is more than the allowed limit as per  policy benefits.Hence the amount over and above the allowed limit is disallowed' else case when pad.denial_code like '%BENX-005%'then pad.remarks else pad.remarks||';'||'The claimed amount is more than the allowed limit as per  policy benefits.Hence the amount over and above the allowed limit is disallowed' end end else pad.remarks end,
              pad.denial_desc = case when (pad.approved_amount > v_rest_amount)  then  case when pad.denial_desc is  null then 'Annual limit/sublimit amount exceeded' else case when pad.denial_code like '%BENX-005%'then pad.denial_desc else pad.denial_desc||';'||'Annual limit/sublimit amount exceeded' end end else pad.denial_desc end,
              pad.denial_code = case when (pad.approved_amount > v_rest_amount)  then case when pad.denial_code is  null then 'BENX-005' else case when pad.denial_code like '%BENX-005%'then pad.denial_code else pad.denial_code||';'||'BENX-005' end end else pad.denial_code end,
              pad.tpa_denial_desc = case when (pad.approved_amount > v_rest_amount)  then  case when pad.tpa_denial_desc is  null then 'Annual limit/sublimit amount exceeded' else case when pad.tpa_denial_code like '%BENX-005%'then pad.tpa_denial_desc else pad.tpa_denial_desc||';'||'Annual limit/sublimit amount exceeded' end end else pad.tpa_denial_desc end,
              pad.tpa_denial_code = case when (pad.approved_amount > v_rest_amount)  then case when pad.tpa_denial_code is  null then 'BENX-005' else case when pad.tpa_denial_code like '%BENX-005%'then pad.tpa_denial_code else pad.tpa_denial_code||';'||'BENX-005' end end else pad.tpa_denial_code end,
              pad.updated_by = v_added_by,
              pad.updated_date = SYSDATE,
              pad.denial_by_rule_proc_dtls    = case when (pad.approved_amount > v_rest_amount)  then
                                                          TRIM(BOTH ';' FROM (pad.denial_by_rule_proc_dtls||';'||CHR(10)||'authorization_pkg.check_activity_limits'))
                                                     else pad.denial_by_rule_proc_dtls end,
              pad.denial_by_resons            = case when (pad.approved_amount > v_rest_amount)  then
                                                       TRIM(BOTH ';' FROM (pad.denial_by_resons||';'||CHR(10)||'Limit exhausted'))        
                                                else denial_by_resons end        
        WHERE pad.activity_dtl_seq_id = rec.activity_dtl_seq_id;
        
        v_rest_amount:=v_remain_amount;

      END LOOP;
    END LOOP;  

       OPEN act_cur_clm;
       FETCH act_cur_clm INTO act_rec;
       CLOSE act_cur_clm;
      v_remain_amount:=null;
    FOR dent in clm_dental_cur LOOP
      v_rest_amount:= nvl(act_rec.tot_allowed_amount,0);
      v_pat_aprov_amount:= nvl(act_rec.tot_allowed_amount,0);
      
      FOR rec in clm_chronic_cur loop

        v_rest_amount:=CASE WHEN rec.approved_amount>v_rest_amount  THEN v_rest_amount  WHEN rec.approved_amount<=v_rest_amount  THEN rec.approved_amount  ELSE v_rest_amount END;
        v_remain_amount:=nvl(v_remain_amount,v_pat_aprov_amount)-v_rest_amount;
        
        UPDATE pat_activity_details pad
        SET pad.approved_amount = case when v_rest_amount>0 then v_rest_amount else 0 end,
            pad.allowed_amount =  case when v_rest_amount>0 then v_rest_amount else 0 end,
            pad.remarks =  case when (pad.approved_amount > v_rest_amount)  then case when pad.remarks is  null then 'The claimed amount is more than the allowed limit as per  policy benefits.Hence the amount over and above the allowed limit is disallowed' else case when pad.denial_code like '%BENX-005%'then pad.remarks else pad.remarks||';'||'The claimed amount is more than the allowed limit as per  policy benefits.Hence the amount over and above the allowed limit is disallowed' end end else pad.remarks end,
            pad.denial_desc = case when (pad.approved_amount > v_rest_amount)  then  case when pad.denial_desc is  null then 'Annual limit/sublimit amount exceeded' else case when pad.denial_code like '%BENX-005%'then pad.denial_desc else pad.denial_desc||';'||'Annual limit/sublimit amount exceeded' end end else pad.denial_desc end,
            pad.denial_code = case when (pad.approved_amount > v_rest_amount)  then case when pad.denial_code is  null then 'BENX-005' else case when pad.denial_code like '%BENX-005%'then pad.denial_code else pad.denial_code||';'||'BENX-005' end end else pad.denial_code end,
            pad.tpa_denial_desc = case when (pad.approved_amount > v_rest_amount)  then  case when pad.tpa_denial_desc is  null then 'Annual limit/sublimit amount exceeded' else case when pad.tpa_denial_code like '%BENX-005%'then pad.tpa_denial_desc else pad.tpa_denial_desc||';'||'Annual limit/sublimit amount exceeded' end end else pad.tpa_denial_desc end,
            pad.tpa_denial_code = case when (pad.approved_amount > v_rest_amount)  then case when pad.tpa_denial_code is  null then 'BENX-005' else case when pad.tpa_denial_code like '%BENX-005%'then pad.tpa_denial_code else pad.tpa_denial_code||';'||'BENX-005' end end else pad.tpa_denial_code end,
            ---pad.benifit_deductible=icd_rec.deduct,
            pad.updated_by = v_added_by,
            pad.updated_date = SYSDATE,
            pad.denial_by_rule_proc_dtls    = case when (pad.approved_amount > v_rest_amount)  then
                                                        TRIM(BOTH ';' FROM (pad.denial_by_rule_proc_dtls||';'||CHR(10)||'authorization_pkg.check_activity_limits'))
                                                   else pad.denial_by_rule_proc_dtls end,
            pad.denial_by_resons            = case when (pad.approved_amount > v_rest_amount)  then
                                                     TRIM(BOTH ';' FROM (pad.denial_by_resons||';'||CHR(10)||'Limit exhausted'))        
                                              else denial_by_resons end        
      WHERE pad.activity_dtl_seq_id = rec.activity_dtl_seq_id;
      
      v_rest_amount:=v_remain_amount;

     END LOOP;
    END LOOP; 

    end if;
    
   ---Check PreApproval Limit
   IF V_HOSP_NAME NOT LIKE '%ALAHLIHOSPITAL%' THEN
     check_pat_limit(v_seq_id, V_HOSP_NAME);
   END IF;
 end if;
 -----  optical enhance -----    
   v_remain_amount:= NULL; 
   FOR rec IN (SELECT b.activity_dtl_seq_id,nvl(b.rule_limit,a.optc_benefit_limit) rule_limit,a.optc_benefit_limit,b.approved_amount
                 FROM clm_authorization_details a
                 JOIN pat_activity_details b ON (a.claim_seq_id = b.claim_seq_id)
                 JOIN tpa_activity_details c ON (b.code=c.activity_code AND c.master_activity_code IN ('9','V2020','92015'))
                WHERE a.claim_seq_id = v_seq_id AND b.optc_payable='INC') LOOP
    v_remain_amount := nvl(v_remain_amount,rec.optc_benefit_limit) ;          
    v_rest_amount:=least(v_remain_amount,rec.rule_limit);
    v_rest_amount:=CASE WHEN rec.approved_amount>v_rest_amount  THEN v_rest_amount  WHEN rec.approved_amount<=v_rest_amount  THEN rec.approved_amount  ELSE rec.approved_amount END;
    --v_used_amount := nvl(v_used_amount, 0) + v_rest_amount;           
    UPDATE pat_activity_details pad
        SET pad.approved_amount = case when v_rest_amount>0 then v_rest_amount else 0 end,
            pad.allowed_amount =  case when v_rest_amount>0 then v_rest_amount else 0 end,
            pad.remarks =  case when (pad.approved_amount > v_rest_amount)  then case when pad.remarks is  null then 'The claimed amount is more than the allowed limit as per  policy benefits.Hence the amount over and above the allowed limit is disallowed' else case when pad.denial_code like '%BENX-005%'then pad.remarks else pad.remarks||';'||'The claimed amount is more than the allowed limit as per  policy benefits.Hence the amount over and above the allowed limit is disallowed' end end else pad.remarks end,
            pad.denial_desc = case when (pad.approved_amount > v_rest_amount)  then  case when pad.denial_desc is  null then 'Annual limit/sublimit amount exceeded' else case when pad.denial_code like '%BENX-005%'then pad.denial_desc else pad.denial_desc||';'||'Annual limit/sublimit amount exceeded' end end else pad.denial_desc end,
            pad.denial_code = case when (pad.approved_amount > v_rest_amount)  then case when pad.denial_code is  null then 'BENX-005' else case when pad.denial_code like '%BENX-005%'then pad.denial_code else pad.denial_code||';'||'BENX-005' end end else pad.denial_code end,
            pad.tpa_denial_desc = case when (pad.approved_amount > v_rest_amount)  then  case when pad.tpa_denial_desc is  null then 'Annual limit/sublimit amount exceeded' else case when pad.tpa_denial_code like '%BENX-005%'then pad.tpa_denial_desc else pad.tpa_denial_desc||';'||'Annual limit/sublimit amount exceeded' end end else pad.tpa_denial_desc end,
            pad.tpa_denial_code = case when (pad.approved_amount > v_rest_amount)  then case when pad.tpa_denial_code is  null then 'BENX-005' else case when pad.tpa_denial_code like '%BENX-005%'then pad.tpa_denial_code else pad.tpa_denial_code||';'||'BENX-005' end end else pad.tpa_denial_code end,
            pad.updated_by = v_added_by,
            pad.updated_date = SYSDATE,
            pad.denial_by_rule_proc_dtls    = case when (pad.approved_amount > v_rest_amount)  then
                                                        TRIM(BOTH ';' FROM (pad.denial_by_rule_proc_dtls||';'||CHR(10)||'authorization_pkg.check_activity_limits'))
                                                   else pad.denial_by_rule_proc_dtls end,
            pad.denial_by_resons            = case when (pad.approved_amount > v_rest_amount)  then
                                                        TRIM(BOTH ';' FROM (pad.denial_by_resons||';'||CHR(10)||'Optical Limit exhausted'))        
                                                   else denial_by_resons end        
      WHERE pad.activity_dtl_seq_id = rec.activity_dtl_seq_id;
     v_remain_amount := v_remain_amount - v_rest_amount;  
   END LOOP;
   v_remain_amount:= NULL;  
   FOR rec IN (SELECT b.activity_dtl_seq_id,nvl(b.rule_limit,a.benefit_limit) rule_limit,a.benefit_limit,b.approved_amount
                 FROM clm_authorization_details a
                 JOIN pat_activity_details b ON (a.claim_seq_id = b.claim_seq_id)
                 JOIN tpa_activity_details c ON (b.code=c.activity_code AND c.master_activity_code IN ('9','V2020','92015'))
                WHERE a.claim_seq_id = v_seq_id AND b.optc_payable='EXC') LOOP
    v_remain_amount := nvl(v_remain_amount,rec.benefit_limit);        
    v_rest_amount:=least(v_remain_amount,rec.rule_limit);
    v_rest_amount:=CASE WHEN rec.approved_amount>v_rest_amount  THEN v_rest_amount  WHEN rec.approved_amount<=v_rest_amount  THEN rec.approved_amount  ELSE rec.approved_amount END;
    --v_used_amount := nvl(v_used_amount, 0) + v_rest_amount;           
    UPDATE pat_activity_details pad
        SET pad.approved_amount = case when v_rest_amount>0 then v_rest_amount else 0 end,
            pad.allowed_amount =  case when v_rest_amount>0 then v_rest_amount else 0 end,
            pad.remarks =  case when (pad.approved_amount > v_rest_amount)  then case when pad.remarks is  null then 'The claimed amount is more than the allowed limit as per  policy benefits.Hence the amount over and above the allowed limit is disallowed' else case when pad.denial_code like '%BENX-005%'then pad.remarks else pad.remarks||';'||'The claimed amount is more than the allowed limit as per  policy benefits.Hence the amount over and above the allowed limit is disallowed' end end else pad.remarks end,
            pad.denial_desc = case when (pad.approved_amount > v_rest_amount)  then  case when pad.denial_desc is  null then 'Annual limit/sublimit amount exceeded' else case when pad.denial_code like '%BENX-005%'then pad.denial_desc else pad.denial_desc||';'||'Annual limit/sublimit amount exceeded' end end else pad.denial_desc end,
            pad.denial_code = case when (pad.approved_amount > v_rest_amount)  then case when pad.denial_code is  null then 'BENX-005' else case when pad.denial_code like '%BENX-005%'then pad.denial_code else pad.denial_code||';'||'BENX-005' end end else pad.denial_code end,
            pad.tpa_denial_desc = case when (pad.approved_amount > v_rest_amount)  then  case when pad.tpa_denial_desc is  null then 'Annual limit/sublimit amount exceeded' else case when pad.tpa_denial_code like '%BENX-005%'then pad.tpa_denial_desc else pad.tpa_denial_desc||';'||'Annual limit/sublimit amount exceeded' end end else pad.tpa_denial_desc end,
            pad.tpa_denial_code = case when (pad.approved_amount > v_rest_amount)  then case when pad.tpa_denial_code is  null then 'BENX-005' else case when pad.tpa_denial_code like '%BENX-005%'then pad.tpa_denial_code else pad.tpa_denial_code||';'||'BENX-005' end end else pad.tpa_denial_code end,
            pad.updated_by = v_added_by,
            pad.updated_date = SYSDATE,
            pad.denial_by_rule_proc_dtls    = case when (pad.approved_amount > v_rest_amount)  then
                                                        TRIM(BOTH ';' FROM (pad.denial_by_rule_proc_dtls||';'||CHR(10)||'authorization_pkg.check_activity_limits'))
                                                   else pad.denial_by_rule_proc_dtls end,
            pad.denial_by_resons            = case when (pad.approved_amount > v_rest_amount)  then
                                                        TRIM(BOTH ';' FROM (pad.denial_by_resons||';'||CHR(10)||'Optical Limit exhausted'))        
                                                   else denial_by_resons end        
      WHERE pad.activity_dtl_seq_id = rec.activity_dtl_seq_id;
     v_remain_amount := v_remain_amount - v_rest_amount;  
   END LOOP;
    -----------------------------  
  ----ADDED FOR SYSTEM OF MEDICINE(ALTERNATIVE MEDICINE CR) VENU BABU    
for clm_sys in sys_med_flag_act_clm loop

 IF clm_sys.sys_med_yn='Y' THEN
 
        v_remain_amount:=null;
        IF clm_sys.sys_med_limit IS NULL AND clm_sys.icd_limit IS NOT NULL THEN
        v_rest_amount := clm_sys.icd_limit;
        ELSIF clm_sys.sys_med_limit IS NOT NULL AND clm_sys.icd_limit IS NULL THEN
        v_rest_amount := clm_sys.sys_med_limit;
        ELSIF clm_sys.sys_med_limit IS NOT NULL AND clm_sys.icd_limit IS NOT NULL THEN 
        v_rest_amount :=least (clm_sys.sys_med_limit,clm_sys.icd_limit);
        END IF;

       v_rest_amount := v_rest_amount- nvl(v_act_use_amt,0);
 
       v_sys_copay:= CASE WHEN clm_sys.icd_limit = v_rest_amount THEN nvl(clm_sys.diag_copay,0) ELSE nvl(clm_sys.sys_copay,0) END;

       v_sys_deductible := CASE WHEN clm_sys.icd_limit = v_rest_amount THEN nvl(clm_sys.diag_deduct,0) ELSE nvl(clm_sys.sys_deductible,0) END;
       
     FOR rec in sys_med_flag_clm(clm_sys.master_activity_code) loop
     v_rest_amount := LEAST (v_rest_amount,nvl(rec.rule_limit,clm_sys.sys_med_limit));
            v_sys_copay := CASE  WHEN v_rest_amount= nvl(rec.rule_limit,0)  then  rec.act_copay else  v_sys_copay end;
            v_sys_deduct := CASE WHEN v_sys_copay=rec.sys_copay THEN NULL ELSE rec.rule_deduct END;
            v_copay_amount := case when v_sys_copay is not null then (rec.gross_amount*v_sys_copay/100) else 0 end;

           if rec.copay_deduct_flag='MIN' THEN 
             v_patient_share := least(least(NVL(v_copay_amount,0),nvl(v_sys_deduct,0)), v_sys_deductible);
           elsif rec.copay_deduct_flag='MAX' THEN
              v_patient_share := greatest(NVL(v_copay_amount,0),nvl(v_sys_deduct,0));
           else
             v_patient_share:= NVL(v_copay_amount,0) + NVL(v_sys_deduct,0);   
           end if;

   IF nvl(rec.out_of_pocket_amount,0)!=0 THEN
     v_appr_amt:=CASE WHEN nvl(rec.gross_amount,0)!=0 THEN
                             (rec.gross_amount-rec.out_of_pocket_amount)-(nvl(v_patient_share,0)+NVL (rec.dis_amt,0)) END;
   ELSE
     v_appr_amt:=CASE WHEN nvl(rec.gross_amount,0)!=0  THEN
                             rec.gross_amount-(nvl(v_patient_share,0)+NVL (rec.dis_amt,0)) END;
   END IF;
   
   IF rec.provider_net_amount is not null THEN
     v_appr_amt:=least (v_appr_amt,rec.provider_net_amount);
   END IF;
   
      v_rest_amount:= CASE WHEN v_appr_amt>v_rest_amount  THEN v_rest_amount  
                           WHEN v_appr_amt<=v_rest_amount  THEN v_appr_amt  ELSE v_rest_amount END
                                  ;
      v_remain_amount:=nvl(nvl(v_remain_amount,rec.rule_limit),clm_sys.sys_med_limit)-(v_rest_amount);

       UPDATE pat_activity_details pad
        SET pad.approved_amount = case when v_rest_amount>0 AND NVL(rec.approve_yn,'Y')='Y' then v_rest_amount else 0 end,
            pad.allowed_amount =  case when v_rest_amount>0 and NVL(rec.approve_yn,'Y')='Y' then v_rest_amount else 0 end,
            pad.patient_share_amount = v_patient_share,
            pad.benifit_copay= v_sys_copay,
            pad.copay_amount=v_copay_amount,
            pad.benifit_deductible=v_sys_deductible/*v_sys_deduct*/,
            pad.remarks =  case when v_appr_amt >v_rest_amount then case when pad.remarks is  null then 'The claimed amount is more than the allowed limit as per  policy benefits.Hence the amount over and above the allowed limit is disallowed' else case when pad.denial_code like '%BENX-005%'then pad.remarks else pad.remarks||';'||'The claimed amount is more than the allowed limit as per  policy benefits.Hence the amount over and above the allowed limit is disallowed' end end else pad.remarks end,
            pad.denial_desc = case when v_appr_amt >v_rest_amount then  case when pad.denial_desc is  null then 'System OF Med Annual limit/sublimit amount exceeded' else case when pad.denial_code like '%BENX-005%'then pad.denial_desc else pad.denial_desc||';'||'System OF Med Annual limit/sublimit amount exceeded' end end else pad.denial_desc end,
            pad.denial_code = case when v_appr_amt >v_rest_amount then case when pad.denial_code is  null then 'BENX-005' else case when pad.denial_code like '%BENX-005%'then pad.denial_code else pad.denial_code||';'||'BENX-005' end end else pad.denial_code end,
            pad.tpa_denial_desc = case when v_appr_amt >v_rest_amount then  case when pad.tpa_denial_desc is  null then 'System OF Med Annual limit/sublimit amount exceeded' else case when pad.tpa_denial_code like '%BENX-005%'then pad.tpa_denial_desc else pad.tpa_denial_desc||';'||'System OF Med Annual limit/sublimit amount exceeded' end end else pad.tpa_denial_desc end,
            pad.tpa_denial_code = case when v_appr_amt >v_rest_amount then case when pad.tpa_denial_code is  null then 'BENX-005' else case when pad.tpa_denial_code like '%BENX-005%'then pad.tpa_denial_code else pad.tpa_denial_code||';'||'BENX-005' end end else pad.tpa_denial_code end,
            pad.updated_by = v_added_by,
            pad.updated_date = SYSDATE,
            pad.denial_by_rule_proc_dtls    = case when v_appr_amt >v_rest_amount or (pad.approved_amount = 0) then
                                                        TRIM(BOTH ';' FROM (pad.denial_by_rule_proc_dtls||';'||CHR(10)||'authorization_pkg.check_activity_limits'))
                                                   else pad.denial_by_rule_proc_dtls end,
            pad.denial_by_resons            = TRIM(BOTH ';' FROM (pad.denial_by_resons||';'||CHR(10)||'limit exhausted'))			
      WHERE pad.activity_dtl_seq_id = rec.activity_dtl_seq_id and pad.claim_seq_id = v_seq_id;
      
      v_act_use_amt:= nvl(v_act_use_amt,0) + v_rest_amount; 
      v_rest_amount:=v_remain_amount;
       
     END LOOP;
     end if;
     END LOOP;
    
     OPEN act_cur_clm;
     FETCH act_cur_clm INTO act_rec;
     CLOSE act_cur_clm;

   UPDATE clm_authorization_details A
    SET a.tot_gross_amount           = act_rec.tot_gross_amount,
        a.tot_discount_amount        = act_rec.tot_discount_amount,
        a.tot_disc_gross_amount      = act_rec.tot_disc_gross_amount,
        a.tot_patient_share_amount   = act_rec.tot_patient_share_amount,
        a.tot_net_amount             = act_rec.tot_net_amount,
        a.tot_allowed_amount         = act_rec.tot_allowed_amount,
        a.tot_approved_amount        = act_rec.tot_approved_amount,
        a.remarks                    = v_remarks
   WHERE a.claim_seq_id           = v_seq_id 
   RETURNING a.tot_approved_amount INTO v_final_allowed_amount;
  END IF;

END check_activity_limits;

 --================================================================
 PROCEDURE select_pat_clm_history(v_member_seq_id IN tpa_enr_policy_member.member_seq_id%type,
                                  v_mode          IN varchar2,
                                  v_result_set    OUT SYS_REFCURSOR)

IS



BEGIN
  


  if v_mode='PAT' then 
 
  OPEN v_result_set  FOR
  SELECT a.pat_auth_seq_id,
         a.member_seq_id,
         a.claim_seq_id,
         a.pre_auth_number,
         a.auth_number,
         a.mem_name,
         null as claim_number,
         null as settlement_number,
         a.FINAL_APP_AMOUNT as tot_approved_amount,
         nvl(c.hosp_name,b.provider_name) as hosp_name,
         a.hospitalization_date as admission_date,
         d.description as pat_status 
  from app.pat_authorization_details a left outer join 
  pat_non_network_details b on (a.pat_auth_seq_id=b.pat_auth_seq_id)
  left outer join tpa_hosp_info c on (c.hosp_seq_id=a.hosp_seq_id)
  left outer join tpa_general_code d on (d.general_type_id=a.pat_status_type_id) 
  where a.member_seq_id=v_member_seq_id and a.pre_auth_number is not null
  /*and a.completed_yn='Y'*/;
 
 else 
 
  OPEN v_result_set  FOR
  SELECT a.pat_auth_seq_id,
         a.claim_seq_id,
         a.claim_number,
         a.settlement_number,
         a.member_seq_id,
         null as pre_auth_number,
         null as auth_number,
         a.mem_name,
         a.FINAL_APP_AMOUNT as tot_approved_amount,
         nvl(c.hosp_name,b.hosp_name) as hosp_name,
         a.date_of_hospitalization as admission_date,
         d.description as pat_status 
  from app.clm_authorization_details a left outer join 
  clm_hospital_details b on (a.claim_seq_id=b.claim_seq_id)
  left outer join tpa_hosp_info c on (c.hosp_seq_id=b.hosp_seq_id)
  left outer join tpa_general_code d on (d.general_type_id=a.clm_status_type_id) 
  where a.member_seq_id=v_member_seq_id ;
  /*and a.completed_yn='Y'*/
 
 end if;
END select_pat_clm_history;

---============================================================
PROCEDURE pat_ins_intimate (v_pat_auth_seq_id               IN pat_authorization_details.pat_auth_seq_id%TYPE,
                            v_pat_status_type_id            IN pat_authorization_details.pat_status_type_id%TYPE,
                            v_max_app_amount                IN pat_authorization_details.tot_approved_amount%TYPE,
                            v_flag                          IN varchar2,
                            v_added_by                      IN NUMBER)
                  IS

    CURSOR cur_relation (v_prod_policy_seq_id VARCHAR2) IS
    SELECT tps.copay_yn,tps.copay_approved_amt,tps.copay_fixed_amt,tps.copay_perc,
           tps.si_restrict_yn,tps.si_relation,tps.si_restrict_amt,tps.si_restrict_perc,tps.si_type,
           tps.rest_age,tps.rest_age_amt,TPS.INS_REJ_ALLOW_YN,
--preauth
          ins_pat_apr_rej_yn,ins_pat_allow_yn,ins_pat_operator,ins_pat_apr_limit,
          ins_pat_rej_allow_yn,pat_mail_flag,pat_mail_freq_hours,pat_mail_freq_mins,
--cash less claims
          ins_clm_cl_apr_rej_yn,ins_clm_cl_allow_yn,ins_clm_cl_operator,ins_clm_cl_apr_limit,
          ins_clm_cl_rej_allow_yn,clm_cl_mail_flag,
--member claim
          ins_clm_cm_apr_rej_yn,ins_clm_cm_allow_yn,ins_clm_cm_operator,ins_clm_cm_apr_limit,
          ins_clm_cm_rej_allow_yn,clm_cm_mail_flag,clm_mail_freq_hours,clm_mail_freq_mins
     FROM  Tpa_ins_prod_policy tps
     WHERE tps.prod_policy_seq_id = v_prod_policy_seq_id;

   CURSOR cur_pol IS
     SELECT p.pat_status_type_id,ep.policy_number,p.policy_seq_id,ep.enrol_type_id,p.tot_approved_amount as total_app_amount,pii.pat_ins_status,p.pat_auth_seq_id,p.completed_yn,pii.ins_intimation_req_yn
     FROM  pat_authorization_details p join tpa_enr_policy ep on (p.policy_seq_id=ep.policy_seq_id)
     left outer join pat_ins_intimation_details pii on (p.pat_auth_seq_id= pii.pat_auth_seq_id)
     WHERE p.pat_auth_seq_id=v_pat_auth_seq_id;

   pat_rec          cur_pol%ROWTYPE;
   relt_cur         cur_relation%ROWTYPE;


   v_prod_policy_seq_id        tpa_ins_prod_policy.prod_policy_seq_id%TYPE;
   v_result_set                SYS_REFCURSOR;
   v_mail_FLAG              tpa_ins_prod_policy.Mail_Flag%type;

 BEGIN

    OPEN cur_pol;
    FETCH cur_pol INTO pat_rec;
    CLOSE cur_pol;

IF pat_rec.Completed_Yn='Y' THEN
    RAISE_APPLICATION_ERROR(-20107,'You cannot perform this action for completed Preauth/Claim');
END IF;

 IF pat_rec.pat_status_type_id NOT IN ('APR','REJ') THEN
     RAISE_APPLICATION_ERROR(-20867,'Claims/Preauth cannot be intimated with current status, claim should be approved or rejected') ;
 END IF;


 IF pat_rec.enrol_type_id='COR' THEN
    OPEN v_result_set FOR
       'SELECT gt.prod_policy_seq_id,gt.pat_mail_flag
        FROM tpa_enr_policy GH
        LEFT OUTER JOIN tpa_ins_prod_policy GT ON (GH.policy_seq_id=GT.policy_seq_id)
        LEFT OUTER JOIN tpa_ins_prod_policy_rules GM ON (GT.prod_policy_seq_id=GM.prod_policy_seq_id)
     WHERE GH.policy_seq_id=:v_policy_seq_id' USING pat_rec.policy_seq_id;

     FETCH v_result_set INTO v_prod_policy_seq_id,v_mail_flag;
     CLOSE v_result_set;
 ELSE
     OPEN v_result_set FOR
    'SELECT tipp.prod_policy_seq_id,tipp.pat_mail_flag
     FROM tpa_enr_policy tep
     LEFT OUTER JOIN tpa_ins_product tip on (tip.product_seq_id=tep.product_seq_id)
     LEFT OUTER JOIN tpa_ins_prod_policy tipp on (tipp.product_seq_id=tip.product_seq_id)
     WHERE tep.policy_seq_id=:v_policy_seq_id'  USING pat_rec.policy_seq_id;

     FETCH v_result_set into v_prod_policy_seq_id,v_mail_flag;
     CLOSE v_result_set;
 END IF;

      OPEN  cur_relation (v_prod_policy_seq_id);
       FETCH cur_relation INTO relt_cur;
       CLOSE cur_relation;

   IF NVL(pat_rec.ins_intimation_req_yn,'N')!='Y' AND  relt_cur.ins_pat_apr_rej_yn='Y'
     and (relt_cur.ins_pat_allow_yn='Y' OR  relt_cur.ins_pat_rej_allow_yn='Y' )  THEN --KOCBJJ

     if pat_rec.pat_ins_status='INP' THEN
        RAISE_APPLICATION_ERROR(-20953,'Preauth/Claim Already intimated to Insurance Company.') ;
     elsif pat_rec.pat_ins_status IN ('APR','REJ') THEN
      RAISE_APPLICATION_ERROR(-20952,'Insurance company Already responded for this Preauth/Claim') ;
     END IF;

     if  relt_cur.ins_pat_apr_rej_yn='Y' and relt_cur.ins_pat_allow_yn='Y' AND pat_rec.pat_status_type_id ='APR' then

        IF relt_cur.ins_pat_operator='GT' THEN
           IF pat_rec.total_app_amount>=relt_cur.ins_pat_apr_limit  THEN
              --preauths_freeze(v_pat_gen_detail_seq_id,pat_rec.pat_status_general_type_id,'M',v_added_by);

      IF v_mail_flag='MAIL' THEN
            generate_mail_pkg.proc_generate_mail('PAT_INS_INTIMATION',v_pat_auth_seq_id,v_prod_policy_seq_id,v_added_by);
      ELSIF  v_mail_flag='ADOBE' THEN
            generate_mail_pkg.proc_generate_mail('PAT_INS_XFDF_PICKUP',v_pat_auth_seq_id,v_prod_policy_seq_id,v_added_by);
      END IF;

           END IF;
        ELSIF relt_cur.ins_pat_operator='LT' THEN
           IF pat_rec.total_app_amount<=relt_cur.ins_pat_apr_limit  THEN
               --preauths_freeze(v_pat_gen_detail_seq_id,pat_rec.pat_status_general_type_id,'M',v_added_by);
      if v_mail_flag='MAIL' THEN
            generate_mail_pkg.proc_generate_mail('PAT_INS_INTIMATION',v_pat_auth_seq_id,v_prod_policy_seq_id,v_added_by);
      ELSIF  v_mail_flag='ADOBE' THEN
            generate_mail_pkg.proc_generate_mail('PAT_INS_XFDF_PICKUP',v_pat_auth_seq_id,v_prod_policy_seq_id,v_added_by);
      END IF;
           END IF;
        ELSIF relt_cur.ins_pat_operator='EQ' THEN
           IF  pat_rec.total_app_amount=relt_cur.ins_pat_apr_limit  THEN
               --preauths_freeze(v_pat_gen_detail_seq_id,pat_rec.pat_status_general_type_id,'M',v_added_by);
      if v_mail_flag='MAIL' THEN
            generate_mail_pkg.proc_generate_mail('PAT_INS_INTIMATION',v_pat_auth_seq_id,v_prod_policy_seq_id,v_added_by);
      ELSIF  v_mail_flag='ADOBE' THEN
            generate_mail_pkg.proc_generate_mail('PAT_INS_XFDF_PICKUP',v_pat_auth_seq_id,v_prod_policy_seq_id,v_added_by);
      END IF;
           END IF;
        END IF;

      END IF;

     IF relt_cur.ins_pat_apr_rej_yn='Y' and relt_cur.ins_pat_rej_allow_yn='Y' and pat_rec.pat_status_type_id='REJ' THEN --KOCBJJ
            --preauths_freeze(v_pat_gen_detail_seq_id,pat_rec.pat_status_general_type_id,'M',v_added_by); --KOCBJJ

      if v_mail_flag='MAIL' THEN
          generate_mail_pkg.proc_generate_mail('PAT_INS_INTIMATION',v_pat_auth_seq_id,v_prod_policy_seq_id,v_added_by);

      ELSIF  v_mail_flag='ADOBE' THEN

            generate_mail_pkg.proc_generate_mail('PAT_INS_XFDF_PICKUP',v_pat_auth_seq_id,v_prod_policy_seq_id,v_added_by);
      END IF;

     END IF;

    END IF;



  COMMIT;
 END pat_ins_intimate;
--=================================================================
PROCEDURE select_ddc_price(v_activity_code             IN  tpa_activity_master_details.activity_code%type,
                           v_activity_date             IN  pat_activity_details.start_date%TYPE,
                           v_unit_type                 IN varchar2,--PCKG,LOSE
                           v_hosp_seq_id               IN tpa_hosp_info.hosp_seq_id%TYPE,
                           v_internal_code             IN tpa_hosp_tariff_details.internal_code%TYPE,
                           v_ddc_price                 OUT varchar2,
                           v_ddc_discount              OUT  varchar2)

IS

cursor ddc_price_cur(v_unit_flag  varchar2) is 
select  CASE when NVL(v_unit_flag,'LOSE')='PCKG' THEN tamd.Package_Price ELSE tamd.unit_price END as gross_amount
    from tpa_pharmacy_master_details tamd
    JOIN tpa_activity_type_codes tatc ON (tamd.activity_type_seq_id=tatc.activity_type_seq_id)
    WHERE tamd.activity_code=upper(v_activity_code) AND tatc.activity_type_seq_id=5
    AND tamd.start_date <= v_activity_date and nvl(tamd.end_date,v_activity_date) >=v_activity_date;

cursor ddc_price_dis_cur(v_unit_flag  varchar2) is 
select  CASE when NVL(v_unit_flag,'LOSE')='PCKG' THEN tamd.Package_Price ELSE tamd.unit_price END as gross_amount
    from tpa_pharmacy_master_details tamd
    JOIN tpa_activity_type_codes tatc ON (tamd.activity_type_seq_id=tatc.activity_type_seq_id)
    WHERE tamd.activity_code=upper(v_activity_code) AND tatc.activity_type_seq_id=5;


CURSOR PHARMACY_DISCOUNT IS
SELECT A.DISC_PERCENT 
FROM app.tpa_hosp_tariff_details a 
where a.acitivity_type_seq_id=5 
and a.hosp_seq_id=v_hosp_seq_id; 

----
CURSOR pharma_tariff_cur(v_unit_flag  varchar2) IS
  Select case when NVL(v_unit_flag,'LOSE')='PCKG' then t.package_price else t.gross_amount end as gross_amount,
         t.disc_percent
  
  From Tpa_Hosp_Tariff_Details t
  Join Tpa_Activity_Master_Details a on a.act_mas_dtl_seq_id = t.activity_seq_id
  Where t.internal_code = UPPER(v_internal_code)
  And a.activity_code = UPPER(v_activity_code)
  And t.hosp_seq_id = v_hosp_seq_id
  And to_date(v_activity_date, 'DD/MM/RRRR') between trunc(t.start_date) and nvl(trunc(t.end_date),to_date(v_activity_date, 'DD/MM/RRRR'));
  
V_PHARMACY_DISC               NUMBER(15,2);
v_count                       NUMBER;
BEGIN
   IF v_internal_code IS NULL THEN
     OPEN PHARMACY_DISCOUNT;
     FETCH PHARMACY_DISCOUNT INTO V_PHARMACY_DISC;
     CLOSE PHARMACY_DISCOUNT;
   END IF;
   
   IF v_internal_code IS NULL THEN
      select  count(1) into v_count
      from tpa_pharmacy_master_details tamd
      JOIN tpa_activity_type_codes tatc ON (tamd.activity_type_seq_id=tatc.activity_type_seq_id)
      WHERE tamd.activity_code=upper(v_activity_code) AND tatc.activity_type_seq_id=5
      AND tamd.start_date <= v_activity_date and nvl(tamd.end_date,v_activity_date) >=v_activity_date;
   ELSE
      Select count(1) into v_count
      From Tpa_Hosp_Tariff_Details t
      Join Tpa_Activity_Master_Details a on a.act_mas_dtl_seq_id = t.activity_seq_id
      Where t.internal_code = UPPER(v_internal_code)
      And a.activity_code = UPPER(v_activity_code)
      And t.hosp_seq_id = v_hosp_seq_id
      And to_date(v_activity_date, 'DD/MM/RRRR') between trunc(t.start_date) and nvl(trunc(t.end_date),to_date(v_activity_date, 'DD/MM/RRRR'));
   END IF;
  
  IF v_internal_code IS NULL THEN  
    IF V_COUNT > 0 THEN 
       OPEN ddc_price_cur(v_unit_type);
       FETCH ddc_price_cur INTO v_ddc_price;
       CLOSE ddc_price_cur;
    ELSE
       OPEN ddc_price_dis_cur(v_unit_type);
       FETCH ddc_price_dis_cur INTO v_ddc_price;
       CLOSE ddc_price_dis_cur;
    END IF;
  ELSE
    OPEN pharma_tariff_cur(v_unit_type);
    FETCH pharma_tariff_cur INTO v_ddc_price, V_PHARMACY_DISC;
    CLOSE pharma_tariff_cur;
  END IF;
  
  if v_ddc_price is not null then
    v_ddc_discount := ((v_ddc_price*NVL(v_pharmacy_disc,0))/100);
  end if;
  

END select_ddc_price;
 --================================================================
  PROCEDURE sent_attachment_proc (v_shortfall_seq_id   IN  shortfall_details.shortfall_seq_id%type,
                                  v_added_by           IN  NUMBER,
                                  v_srtfll_type        IN CHAR)
 AS
   CURSOR clm_cur IS
     SELECT c.claim_type
     FROM Clm_Authorization_Details c
     JOIN Shortfall_Details s ON (c.claim_seq_id = s.claim_seq_id)
     WHERE s.shortfall_seq_id = v_shortfall_seq_id
     AND 'CLM' = v_srtfll_type;
     
   v_netwotk_type               VARCHAR2(5);
   v_dest_msg_seq_id            VARCHAR2(30);
 BEGIN

   IF v_srtfll_type = 'PAT' THEN 

      GENERATE_MAIL_PKG.proc_generate_message('PREAUTH_SHORTFALL',
                                          v_shortfall_seq_id,
                                          v_added_by,
                                          v_dest_msg_seq_id);
      GENERATE_MAIL_PKG.proc_generate_message('PREAUTH_SHORTFALL_NHCP',
                                          v_shortfall_seq_id,
                                          v_added_by,
                                          v_dest_msg_seq_id);


    ELSIF v_srtfll_type ='CLM' THEN 
      OPEN clm_cur;
      FETCH clm_cur INTO v_netwotk_type;
      CLOSE clm_cur;
      
      IF v_netwotk_type = 'CTM' THEN
        GENERATE_MAIL_PKG.proc_form_message('CLAIM_SHORTFALL',
                                          v_shortfall_seq_id,
                                          v_added_by,
                                          v_dest_msg_seq_id);
      END IF;
    END IF;
 END sent_attachment_proc;
 --=================================================================
 	PROCEDURE select_member_list (
		v_tpa_enrollment_id        IN    tpa_enr_policy_member.tpa_enrollment_id%type,
		v_sort_var                 IN      VARCHAR2 ,
		v_sort_order               IN OUT  VARCHAR2,
		v_start_num                IN OUT  NUMBER  ,
		v_end_num                  IN OUT  NUMBER  ,
		v_added_by                 IN      NUMBER,
		v_result_set               OUT SYS_REFCURSOR
	  )
  IS
    v_str                      VARCHAR2(4000);
  BEGIN
   
    v_sort_order := CASE WHEN v_sort_order IS NULL THEN 'ASC' ELSE v_sort_order END;
    v_start_num  := CASE WHEN v_start_num IS NULL THEN 1 ELSE v_start_num END;
    v_end_num    := CASE WHEN v_end_num IS NULL THEN 2000 ELSE v_end_num END;

 v_str :=
        'SELECT m.member_seq_id,p.policy_seq_id, m.tpa_enrollment_id ,p.policy_number,to_char(p.effective_from_date,''DD/MM/YYYY'') as start_date ,to_char(p.effective_to_date,''DD/MM/YYYY'') as end_date ,
            m.global_net_member_id , m.mem_name||'' ''||m.mem_last_name||'' ''||m.family_name as mem_name,nvl(m.mem_age,(months_between(sysdate,m.mem_dob)/12)) as mem_age,m.emirate_id,tii.ins_seq_id,
           (d.group_name||''(''||d.group_id||'')'') as corporate_name,
            tii.ins_comp_name,tii.ins_comp_code_number as payer_id,p.enrol_type_id,account_info_pkg.get_gen_desc(m.GENDER_GENERAL_TYPE_ID,''G'') AS gender, d.group_reg_seq_id,nc.description as nationality,
            nvl(eb.sum_insured,0) - nvl(eb.utilised_sum_insured,0) AS ava_sum_insured,
            EB.SUM_INSURED,
            ip.product_name,
            case when nvl(m.vip_yn,''N'')=''N'' then ''No'' else ''Yes'' end as vip_yn,
            to_char(m.date_of_inception, ''DD/MM/YYYY'') as mem_insp_date,
            tii.payer_authority as authority,
            ip.product_cat_type_id as network_type,
            CASE WHEN p.tpa_cheque_issued_general_type=''IQC'' THEN ttk_util_pkg.fn_decrypt(cbank.bank_name)
                 WHEN p.tpa_cheque_issued_general_type=''IQI'' THEN ttk_util_pkg.fn_decrypt(mbank.bank_name)
            END as bank_name,
            CASE WHEN p.tpa_cheque_issued_general_type=''IQC'' THEN ttk_util_pkg.fn_decrypt(cbank.Bank_Micr)
                 WHEN p.tpa_cheque_issued_general_type=''IQI'' THEN ttk_util_pkg.fn_decrypt(mbank.Bank_Micr)
             END as IBAN_NUMBER,
             CASE WHEN p.tpa_cheque_issued_general_type=''IQC'' THEN ''CORPORATE''
                  WHEN p.tpa_cheque_issued_general_type=''IQI'' THEN ''MEMBER''
             END AS payment_made_for,
            (select a.relship_description from APP.TPA_RELATIONSHIP_CODE a where a.RELSHIP_TYPE_ID= m.relship_type_id) relationship_desc,
            NULL as COLOUR_YN ,
            m.member_remarks
        FROM tpa_enr_policy_member m
           JOIN tpa_enr_policy_group g ON(m.policy_group_seq_id=g.policy_group_seq_id)
           JOIN tpa_enr_policy p ON( g.policy_seq_id=p.policy_seq_id)
           JOIN tpa_ins_product ip ON (ip.product_seq_id=p.product_seq_id)
           LEFT OUTER JOIN tpa_group_registration d ON (d.group_reg_seq_id=p.group_reg_seq_id)
           JOIN tpa_ins_info tii on (p.ins_seq_id=tii.ins_seq_id)
           LEFT outer join tpa_nationalities_code nc on (nc.nationality_id=m.nationality_id)
           LEFT OUTER JOIN tpa_enr_balance eb ON (g.policy_group_seq_id = eb.policy_group_seq_id)
           left outer join tpa_enr_bank_dtls cbank on (cbank.bank_seq_id=p.bank_seq_id)
           left outer join tpa_enr_bank_dtls mbank on (mbank.bank_seq_id=g.bank_seq_id)
        WHERE( :v_tpa_enrollment_id IS NULL OR  m.tpa_enrollment_id=:v_tpa_enrollment_id)
          --AND ( SYSDATE BETWEEN p.effective_from_date AND p.effective_to_date+1)
          AND  (m.mem_general_type_id != ''PFL'' AND m.member_seq_id = eb.member_seq_id OR eb.member_seq_id IS NULL
          OR m.member_seq_id IS NULL)
          AND (m.status_general_type_id =''POA'' OR m.status_general_type_id  =''POC'')
          AND (g.status_general_type_id =''POA'' OR g.status_general_type_id  =''POC'')
          AND p.COMPLETED_YN=''Y''
          AND g.DELETED_YN=''N''
          AND m.DELETED_YN=''N''';
                  
    
   v_str := 'SELECT * FROM
      (SELECT A.*, DENSE_RANK() OVER (ORDER BY '||v_sort_var||' '||v_sort_order||',ROWNUM) Q FROM (' ||v_str|| ') A )
       WHERE  Q>= :v_start_num  AND Q<= :v_end_num ';
       
      
       
    OPEN v_result_set FOR v_str USING v_tpa_enrollment_id ,v_tpa_enrollment_id, v_start_num, v_end_num;
     

  END select_member_list ;
                                 

  --=================================================================     
FUNCTION get_nat_concp_valid_msg(v_member_seq_id       IN NUMBER,
                                 v_type                IN VARCHAR2,
                                 v_nat_conception      IN VARCHAR2)
 RETURN VARCHAR2
IS

v_non_match_cnt                  NUMBER(10);
v_message                        VARCHAR2(300);
  
BEGIN
  IF v_type = 'CLM' THEN
    SELECT COUNT(1) INTO v_non_match_cnt
    FROM tpa_enr_policy_member m 
    JOIN clm_authorization_details ca ON (m.member_seq_id=ca.member_seq_id)
    WHERE m.member_seq_id = v_member_seq_id
      AND ca.benifit_type IN ('MTI', 'OMTI', 'IMTI')
      AND NVL(ca.conception_type,'NA') != NVL(v_nat_conception,'NA');
  ELSE
    SELECT COUNT(1) INTO v_non_match_cnt
    FROM tpa_enr_policy_member m 
    JOIN pat_authorization_details ca ON (m.member_seq_id=ca.member_seq_id)
    WHERE m.member_seq_id = v_member_seq_id
      AND ca.benifit_type IN ('MTI', 'OMTI', 'IMTI')
      AND NVL(ca.conception_type,'NA') != NVL(v_nat_conception,'NA');
  END IF;    
  
  IF v_non_match_cnt > 0 THEN
    v_message := 'Inconsistency in Nature of conception.';
  ELSE
    v_message := NULL;
  END IF;
 RETURN(v_message); 
END get_nat_concp_valid_msg;
--================================================================================================
PROCEDURE SAVE_ORTHODONTIC_DETAILS(P_ORTHO_SEQ_ID       IN OUT ORTHODONTIC_DETAILS_TAB.ORTHO_SEQ_ID%TYPE,
                                   P_SOURCE_SEQ_ID      IN ORTHODONTIC_DETAILS_TAB.SOURCE_SEQ_ID%TYPE,
                                   P_SOURCE_FROM        IN ORTHODONTIC_DETAILS_TAB.SOURCE_FROM%TYPE,
                                   P_DENTO_CLASS_I      IN ORTHODONTIC_DETAILS_TAB.DENTO_CLASS_I%TYPE,
                                   P_DENTO_CLASS_II     IN ORTHODONTIC_DETAILS_TAB.DENTO_CLASS_II%TYPE,
                                   P_DENTO_CLASS_II_TEXT IN ORTHODONTIC_DETAILS_TAB.DENTO_CLASS_II_TEXT%TYPE,
                                   P_DENTO_CLASS_III    IN ORTHODONTIC_DETAILS_TAB.DENTO_CLASS_III%TYPE,
                                   P_SKELE_CLASS_I      IN ORTHODONTIC_DETAILS_TAB.SKELE_CLASS_I%TYPE,
                                   P_SKELE_CLASS_II     IN ORTHODONTIC_DETAILS_TAB.SKELE_CLASS_II%TYPE,
                                   P_SKELE_CLASS_III    IN ORTHODONTIC_DETAILS_TAB.SKELE_CLASS_III%TYPE,
                                   P_OVERJET_MM         IN ORTHODONTIC_DETAILS_TAB.OVERJET_MM%TYPE,
                                   P_REV_OVERJET_MM     IN ORTHODONTIC_DETAILS_TAB.REV_OVERJET_MM%TYPE,
                                   P_REV_OVERJET_YN     IN ORTHODONTIC_DETAILS_TAB.REV_OVERJET_YN%TYPE,
                                   P_CROSSBITE_ANT      IN ORTHODONTIC_DETAILS_TAB.CROSSBITE_ANT%TYPE,
                                   P_CROSSBITE_POST     IN ORTHODONTIC_DETAILS_TAB.CROSSBITE_POST%TYPE,
                                   P_CROSSBITE_BETW     IN ORTHODONTIC_DETAILS_TAB.CROSSBITE_BETW%TYPE,
                                   P_OPENBIT_ANT        IN ORTHODONTIC_DETAILS_TAB.OPENBIT_ANT%TYPE,
                                   P_OPENBIT_POST       IN ORTHODONTIC_DETAILS_TAB.OPENBIT_POST%TYPE,
                                   P_OPENBIT_LATE       IN ORTHODONTIC_DETAILS_TAB.OPENBIT_LATE%TYPE,
                                   P_CONT_POINT_DISP    IN ORTHODONTIC_DETAILS_TAB.CONT_POINT_DISP%TYPE,
                                   P_OVERBIT            IN ORTHODONTIC_DETAILS_TAB.OVERBIT_DEEP%TYPE,
                                   P_OVERBIT_PATA       IN ORTHODONTIC_DETAILS_TAB.OVERBIT_PATA%TYPE,
                                   P_OVERBIT_GING       IN ORTHODONTIC_DETAILS_TAB.OVERBIT_GING%TYPE,
                                   P_HYPO_QUAD1         IN ORTHODONTIC_DETAILS_TAB.HYPO_QUAD1%TYPE,
                                   P_HYPO_QUAD2         IN ORTHODONTIC_DETAILS_TAB.HYPO_QUAD2%TYPE,
                                   P_HYPO_QUAD3         IN ORTHODONTIC_DETAILS_TAB.HYPO_QUAD3%TYPE,
                                   P_HYPO_QUAD4         IN ORTHODONTIC_DETAILS_TAB.HYPO_QUAD4%TYPE,
                                   P_OTHERS_IMPEDED     IN ORTHODONTIC_DETAILS_TAB.OTHERS_IMPEDED%TYPE,
                                   P_OTHERS_IMPACT      IN ORTHODONTIC_DETAILS_TAB.OTHERS_IMPACT%TYPE,
                                   P_OTHERS_SUBMERG     IN ORTHODONTIC_DETAILS_TAB.OTHERS_SUBMERG%TYPE,
                                   P_OTHERS_SUPERNUM    IN ORTHODONTIC_DETAILS_TAB.OTHERS_SUPERNUM%TYPE,
                                   P_OTHERS_RETAINE     IN ORTHODONTIC_DETAILS_TAB.OTHERS_RETAINE%TYPE,
                                   P_OTHERS_ECTOPIC     IN ORTHODONTIC_DETAILS_TAB.OTHERS_ECTOPIC%TYPE,
                                   P_OTHERS_CRANIO      IN ORTHODONTIC_DETAILS_TAB.OTHERS_CRANIO%TYPE,
                                   P_AC_MARKS           IN ORTHODONTIC_DETAILS_TAB.AC_MARKS%TYPE,
                                   P_CROSSBITE_ANT_MM	  IN ORTHODONTIC_DETAILS_TAB.CROSSBITE_ANT_MM%TYPE,
								                   P_CROSSBITE_PRST_MM	IN ORTHODONTIC_DETAILS_TAB.CROSSBITE_PRST_MM%TYPE,
								                   P_CROSSBITE_BETW_MM	IN ORTHODONTIC_DETAILS_TAB.CROSSBITE_BETW_MM%TYPE,
								                   P_CONT_POINT_DISP_MM	IN ORTHODONTIC_DETAILS_TAB.CONT_POINT_DISP_MM%TYPE,
                                   P_DENTO_CLASS_III_TEXT IN ORTHODONTIC_DETAILS_TAB.DENTO_CLASS_III_TEXT%TYPE,
                                   P_IOTN               OUT ORTHODONTIC_DETAILS_TAB.IOTN_REMARK%TYPE
                                 )
AS
 V_ORTHO_SEQ_ID                 NUMBER;
 V_COUNT                        NUMBER;
 
 CURSOR treatment_cur IS
   SELECT p.treatment_type
   FROM Pat_Authorization_Details p
   WHERE p.pat_auth_seq_id = P_SOURCE_SEQ_ID;
   
 --treatment_rec             treatment_cur%rowtype;
 
 CURSOR clm_treatment_cur IS
   SELECT c.treatment_type
   FROM Clm_Authorization_Details c
   WHERE c.claim_seq_id = P_SOURCE_SEQ_ID;
   
 treatment_rec             treatment_cur%rowtype;
 
BEGIN
 IF NVL(P_ORTHO_SEQ_ID, 0) = 0 THEN
   
   SELECT COUNT(o.ortho_seq_id) INTO V_COUNT
   FROM ORTHODONTIC_DETAILS_TAB o
   WHERE o.source_seq_id = P_SOURCE_SEQ_ID 
   AND o.source_from = P_SOURCE_FROM;
   
   IF V_COUNT > 0 THEN
     DELETE FROM ORTHODONTIC_DETAILS_TAB o
     WHERE o.source_seq_id = P_SOURCE_SEQ_ID
     AND o.source_from = P_SOURCE_FROM;
   END IF;
            
   SELECT NVL(MAX(o.ORTHO_SEQ_ID), 0) INTO V_ORTHO_SEQ_ID
   FROM ORTHODONTIC_DETAILS_TAB o; 
                           
   INSERT INTO ORTHODONTIC_DETAILS_TAB(
                        ORTHO_SEQ_ID,
                        SOURCE_SEQ_ID,
                        SOURCE_FROM,
                        DENTO_CLASS_I,
                        DENTO_CLASS_II,
                        DENTO_CLASS_II_TEXT,
                        DENTO_CLASS_III,
                        SKELE_CLASS_I,
                        SKELE_CLASS_II,
                        SKELE_CLASS_III,
                        OVERJET_MM,
                        REV_OVERJET_MM,
                        REV_OVERJET_YN,
                        CROSSBITE_ANT,
                        CROSSBITE_POST,
                        CROSSBITE_BETW,
                        OPENBIT_ANT,
                        OPENBIT_POST,
                        OPENBIT_LATE,
                        CONT_POINT_DISP,
                        OVERBIT_DEEP,
                        OVERBIT_PATA,
                        OVERBIT_GING,
                        HYPO_QUAD1,
                        HYPO_QUAD2,
                        HYPO_QUAD3,
                        HYPO_QUAD4,
                        OTHERS_IMPEDED,
                        OTHERS_IMPACT,
                        OTHERS_SUBMERG,
                        OTHERS_SUPERNUM,
                        OTHERS_RETAINE,
                        OTHERS_ECTOPIC,
                        OTHERS_CRANIO,
                        AC_MARKS,
                        CROSSBITE_ANT_MM,
                        CROSSBITE_PRST_MM,
                        CROSSBITE_BETW_MM,
                        CONT_POINT_DISP_MM,
                        DENTO_CLASS_III_TEXT
                        )
                
                VALUES (V_ORTHO_SEQ_ID + 1,
                        P_SOURCE_SEQ_ID,
                        P_SOURCE_FROM,
                        P_DENTO_CLASS_I,
                        P_DENTO_CLASS_II,
                        P_DENTO_CLASS_II_TEXT,
                        P_DENTO_CLASS_III,
                        P_SKELE_CLASS_I,
                        P_SKELE_CLASS_II,
                        P_SKELE_CLASS_III,
                        P_OVERJET_MM,
                        P_REV_OVERJET_MM,
                        P_REV_OVERJET_YN,
                        P_CROSSBITE_ANT,
                        P_CROSSBITE_POST,
                        P_CROSSBITE_BETW,
                        P_OPENBIT_ANT,
                        P_OPENBIT_POST,
                        P_OPENBIT_LATE,
                        P_CONT_POINT_DISP,
                        P_OVERBIT,
                        P_OVERBIT_PATA,
                        P_OVERBIT_GING,
                        P_HYPO_QUAD1,
                        P_HYPO_QUAD2,
                        P_HYPO_QUAD3,
                        P_HYPO_QUAD4,
                        P_OTHERS_IMPEDED,
                        P_OTHERS_IMPACT,
                        P_OTHERS_SUBMERG,
                        P_OTHERS_SUPERNUM,
                        P_OTHERS_RETAINE,
                        P_OTHERS_ECTOPIC,
                        P_OTHERS_CRANIO,
                        P_AC_MARKS,
                        P_CROSSBITE_ANT_MM,
                        P_CROSSBITE_PRST_MM,
                        P_CROSSBITE_BETW_MM,
                        P_CONT_POINT_DISP_MM,
                        P_DENTO_CLASS_III_TEXT
                        ) RETURNING ORTHO_SEQ_ID INTO P_ORTHO_SEQ_ID;
                        
 ELSE
   UPDATE ORTHODONTIC_DETAILS_TAB
   SET  ORTHO_SEQ_ID          = P_ORTHO_SEQ_ID,
        SOURCE_SEQ_ID         = P_SOURCE_SEQ_ID,
        SOURCE_FROM           = P_SOURCE_FROM,
        DENTO_CLASS_I         = P_DENTO_CLASS_I,
        DENTO_CLASS_II        = P_DENTO_CLASS_II,
        DENTO_CLASS_II_TEXT   = P_DENTO_CLASS_II_TEXT,
        DENTO_CLASS_III       = P_DENTO_CLASS_III,
        SKELE_CLASS_I         = P_SKELE_CLASS_I,
        SKELE_CLASS_II        = P_SKELE_CLASS_II,
        SKELE_CLASS_III       = P_SKELE_CLASS_III,
        OVERJET_MM            = P_OVERJET_MM,
        REV_OVERJET_MM        = P_REV_OVERJET_MM,
        REV_OVERJET_YN        = P_REV_OVERJET_YN,
        CROSSBITE_ANT         = P_CROSSBITE_ANT,
        CROSSBITE_POST        = P_CROSSBITE_POST,
        CROSSBITE_BETW        = P_CROSSBITE_BETW,
        OPENBIT_ANT           = P_OPENBIT_ANT,
        OPENBIT_POST          = P_OPENBIT_POST,
        OPENBIT_LATE          = P_OPENBIT_LATE,
        CONT_POINT_DISP       = P_CONT_POINT_DISP,
        OVERBIT_DEEP          = P_OVERBIT,
        OVERBIT_PATA          = P_OVERBIT_PATA,
        OVERBIT_GING          = P_OVERBIT_GING,
        HYPO_QUAD1            = P_HYPO_QUAD1,
        HYPO_QUAD2            = P_HYPO_QUAD2,
        HYPO_QUAD3            = P_HYPO_QUAD3,
        HYPO_QUAD4            = P_HYPO_QUAD4,
        OTHERS_IMPEDED        = P_OTHERS_IMPEDED,
        OTHERS_IMPACT         = P_OTHERS_IMPACT,
        OTHERS_SUBMERG        = P_OTHERS_SUBMERG,
        OTHERS_SUPERNUM       = P_OTHERS_SUPERNUM,
        OTHERS_RETAINE        = P_OTHERS_RETAINE,
        OTHERS_ECTOPIC        = P_OTHERS_ECTOPIC,
        OTHERS_CRANIO         = P_OTHERS_CRANIO,
        AC_MARKS              = P_AC_MARKS,
        CROSSBITE_ANT_MM      = P_CROSSBITE_ANT_MM,
        CROSSBITE_PRST_MM     = P_CROSSBITE_PRST_MM,
        CROSSBITE_BETW_MM     = P_CROSSBITE_BETW_MM,
        CONT_POINT_DISP_MM    = P_CONT_POINT_DISP_MM,
        DENTO_CLASS_III_TEXT  = P_DENTO_CLASS_III_TEXT
        
   WHERE ORTHO_SEQ_ID = P_ORTHO_SEQ_ID;
   
 END IF;
 
 IF P_SOURCE_FROM = 'PAT' THEN
   OPEN treatment_cur;
   FETCH treatment_cur INTO treatment_rec;
   CLOSE treatment_cur;
 
   IF treatment_rec.treatment_type IN (1, 3) THEN
     pat_xml_load_pkg.ortho_score_prc (P_SOURCE_SEQ_ID, 'PAT');
   END IF;
 ELSE
   OPEN clm_treatment_cur;
   FETCH clm_treatment_cur INTO treatment_rec;
   CLOSE clm_treatment_cur;
   
   IF treatment_rec.treatment_type IN (1, 3) THEN
     pat_xml_load_pkg.ortho_score_prc (P_SOURCE_SEQ_ID, 'CLM');
   END IF;
 END IF;
 
 commit;
END SAVE_ORTHODONTIC_DETAILS;
--============================================================================================================
PROCEDURE check_ortho_cond (p_seq_id IN NUMBER,
                            p_flag   IN VARCHAR2
                           )
AS
  v_result                 VARCHAR2(100);
  
  CURSOR pat_ortho_act_cur IS
    SELECT o.iotn_remark, o.ac_marks
    FROM orthodontic_details_tab o
    JOIN pat_authorization_details p ON (p.pat_auth_seq_id = o.source_seq_id)
    JOIN pat_activity_details pa ON (pa.pat_auth_seq_id = p.pat_auth_seq_id)
    WHERE o.source_seq_id = p_seq_id
    AND o.source_from = p_flag;
    
  pat_ortho_act_rec  pat_ortho_act_cur%ROWTYPE;
  
  CURSOR clm_ortho_act_cur IS
    SELECT o.iotn_remark, o.ac_marks
    FROM orthodontic_details_tab o
    JOIN clm_authorization_details cl ON (cl.claim_seq_id = o.source_seq_id)
    JOIN pat_activity_details pa ON (cl.claim_seq_id = pa.claim_seq_id)
    WHERE o.source_seq_id = p_seq_id
    AND o.source_from = p_flag;
    
  clm_ortho_act_rec  clm_ortho_act_cur%ROWTYPE;
 
  CURSOR pat_req_orth_cur IS
    SELECT p.code, p.activity_dtl_seq_id, d.iotn_required, d.specific_service_code, p.override_yn, p.denial_code
    FROM Pat_Activity_Details p
    JOIN Dental_Rule_Tab d ON d.cdt_code = p.code
    JOIN Pat_Authorization_Details pa ON (pa.pat_auth_seq_id = p.pat_auth_seq_id)
    WHERE d.iotn_required = 'Y'
    AND pa.pat_auth_seq_id = p_seq_id;
    
  CURSOR clm_req_orth_cur IS
    SELECT p.code, p.activity_dtl_seq_id, d.iotn_required, d.specific_service_code, p.override_yn, p.denial_code
    FROM Pat_Activity_Details p
    JOIN Dental_Rule_Tab d ON (d.cdt_code = p.code)
    JOIN Clm_Authorization_Details c ON (c.claim_seq_id = p.claim_seq_id)
    WHERE d.iotn_required = 'Y'
    AND c.claim_seq_id = p_seq_id;
     
BEGIN
  IF p_flag = 'PAT' THEN
    OPEN pat_ortho_act_cur;
    FETCH pat_ortho_act_cur INTO pat_ortho_act_rec;
    CLOSE pat_ortho_act_cur;
    
    v_result := CASE WHEN pat_ortho_act_rec.iotn_remark = 1 THEN
                          'IOTN SCORE IS REQUIRED'
                     WHEN pat_ortho_act_rec.iotn_remark = 2 THEN
                          'IOTN SCORE IS REQUIRED'
                     WHEN pat_ortho_act_rec.iotn_remark = 3 AND pat_ortho_act_rec.ac_marks IN (8,9,10) THEN
                          'Approved'
                     WHEN pat_ortho_act_rec.iotn_remark = 4 THEN
                          'Approved'
                     WHEN pat_ortho_act_rec.iotn_remark = 5 THEN
                          'Approved'
                ELSE
                  'IOTN SCORE IS REQUIRED'
                END;
                
      FOR i IN pat_req_orth_cur LOOP
        IF v_result = 'IOTN SCORE IS REQUIRED' THEN
          IF '%|'||i.denial_code||'%' NOT LIKE '%'||'IOTN-DEN-001'||'%' THEN
          UPDATE pat_activity_details p
          SET p.denial_code = CASE WHEN nvl(i.override_yn, 'N') = 'N' THEN CASE WHEN v_result = 'IOTN SCORE IS REQUIRED' THEN 
                                CASE WHEN p.denial_code IS NOT NULL THEN p.denial_code||';'||'IOTN-DEN-001' ELSE 'IOTN-DEN-001' END END END,
              p.denial_desc = CASE WHEN nvl(i.override_yn, 'N') = 'N' THEN CASE WHEN v_result = 'IOTN SCORE IS REQUIRED' THEN
                                CASE WHEN p.denial_desc IS NOT NULL THEN p.denial_desc||v_result ELSE v_result END END END
          WHERE p.activity_dtl_seq_id = i.activity_dtl_seq_id
          AND p.pat_auth_seq_id = p_seq_id;
          END IF;
        END IF;
      END LOOP;
  
  
  ELSE
    OPEN clm_ortho_act_cur;
    FETCH clm_ortho_act_cur INTO clm_ortho_act_rec;
    CLOSE clm_ortho_act_cur;
    
    v_result := CASE WHEN clm_ortho_act_rec.iotn_remark = 1 THEN
                          'IOTN SCORE IS REQUIRED'
                     WHEN clm_ortho_act_rec.iotn_remark = 2 THEN
                          'IOTN SCORE IS REQUIRED'
                     WHEN clm_ortho_act_rec.iotn_remark = 3 AND clm_ortho_act_rec.ac_marks IN (8,9,10) THEN
                          'Approved'
                     WHEN clm_ortho_act_rec.iotn_remark = 4 THEN
                          'Approved'
                     WHEN clm_ortho_act_rec.iotn_remark = 5 THEN
                          'Approved'
                ELSE
                  'IOTN SCORE IS REQUIRED'
                END;
                --p.denial_code NOT LIKE 'IOTN-DEN-007'
                
      FOR i IN pat_req_orth_cur LOOP
        IF v_result = 'IOTN SCORE IS REQUIRED' THEN
          IF '%|'||i.denial_code||'%' NOT LIKE '%'||'IOTN-DEN-001'||'%' THEN
            UPDATE pat_activity_details p
            SET p.denial_code = CASE WHEN nvl(i.override_yn, 'N') = 'N' THEN CASE WHEN v_result = 'IOTN SCORE IS REQUIRED' THEN 
                                  CASE WHEN p.denial_code IS NOT NULL THEN p.denial_code||';'||'IOTN-DEN-001' ELSE 'IOTN-DEN-001' END END END,
                p.denial_desc = CASE WHEN nvl(i.override_yn, 'N') = 'N' THEN CASE WHEN v_result = 'IOTN SCORE IS REQUIRED' THEN
                                  CASE WHEN p.denial_desc IS NOT NULL THEN p.denial_desc||v_result ELSE v_result END END END
            WHERE p.activity_dtl_seq_id = i.activity_dtl_seq_id
            AND p.claim_seq_id = p_seq_id;
          END IF;
        END IF;
      END LOOP;
  
  END IF;
END check_ortho_cond;
--=================================================================================
 --===============================================================================================
PROCEDURE save_assign_users(
    v_assign_users_seq_id                IN  OUT ASSIGN_USERS.assign_users_seq_id%TYPE,
    v_claim_seq_id                       IN  VARCHAR2,
    v_pat_gen_detail_seq_id              IN  VARCHAR2,
    v_tpa_office_seq_id                  IN ASSIGN_USERS.tpa_office_seq_id%TYPE,
    v_assigned_to_user                   IN ASSIGN_USERS.assigned_to_user%TYPE,
    v_pat_status_general_type_id         IN ASSIGN_USERS.pat_status_general_type_id%TYPE,
    v_remarks                            IN ASSIGN_USERS.Remarks%TYPE,
    v_call_type                          IN  VARCHAR2,
    v_super_user_yn                      IN  CHAR , -- 'Y'/'N'
    v_added_by                           IN  NUMBER,
    v_mode                               IN  VARCHAR2,
    v_rows_processed                     IN  OUT NUMBER
  )
  IS
    v_assign_flag                        CHAR(3);
    v_count                              NUMBER(10);
    v_claim_seq_ids                      VARCHAR2(500);
    v_pat_auth_seq_idS                    VARCHAR2(500);
	v_dest_msg_seq_id                    destination_message.dest_msg_seq_id%type;
    v_added_by_name                      tpa_user_contacts.contact_name%type;
    PAT_CLM_IDS                          ttk_util_pkg.str_table_type;
  BEGIN
 
    select contact_name into v_added_by_name from tpa_user_contacts where contact_seq_id=v_added_by;
 
    IF v_mode='CLM' THEN

      IF v_super_user_yn = 'Y' THEN
        v_assign_flag    := 'SUP'; 
      ELSE
        v_assign_flag    := 'MAN';
      END IF;
       select regexp_count(replace(v_claim_seq_id,'|',','),',') into v_count from dual;
       
      v_claim_seq_ids := CASE WHEN v_count=0 THEN '|'||v_claim_seq_id||'|' WHEN v_count>0 THEN '|'||v_claim_seq_id END;
      
      reassign_user (  NULL , v_claim_seq_ids, v_assigned_to_user , v_added_by , v_assign_flag,v_assign_users_seq_id,V_REMARKS);
    PAT_CLM_IDS:=ttk_util_pkg.parse_str(v_claim_seq_ids);
    FOR i IN  PAT_CLM_IDS.FIRST..PAT_CLM_IDS.LAST LOOP 
    IF /*v_assign_users_seq_id IS NOT NULL and*/ PAT_CLM_IDS(i) is not null THEN
     generate_mail_pkg.proc_generate_message('USER_ASSIGNED_CLAIM',v_assigned_to_user,v_added_by,v_dest_msg_seq_id,PAT_CLM_IDS(i),v_added_by_name);
    END IF;
    END LOOP;
    
    ELSIF v_mode='PAT' THEN

      IF v_super_user_yn = 'Y' THEN
        v_assign_flag    := 'SUP'; 
      ELSE
        v_assign_flag    := 'MAN';
      END IF;
      
       select regexp_count(replace(v_pat_gen_detail_seq_id,'|',','),',') into v_count from dual;
       
       v_pat_auth_seq_idS := CASE WHEN v_count=0 THEN '|'||v_pat_gen_detail_seq_id||'|' WHEN v_count>0 THEN '|'||v_pat_gen_detail_seq_id END;
       
      reassign_user (  v_pat_auth_seq_idS , NULL , v_assigned_to_user  , v_added_by , v_assign_flag,v_assign_users_seq_id,V_REMARKS );
    PAT_CLM_IDS:=ttk_util_pkg.parse_str(v_pat_auth_seq_idS);
     FOR i IN  PAT_CLM_IDS.FIRST..PAT_CLM_IDS.LAST LOOP 
    IF /*v_assign_users_seq_id IS NOT NULL  and */PAT_CLM_IDS(i) is not null THEN     
     generate_mail_pkg.proc_generate_message('USER_ASSIGNED_PREAUTH',v_assigned_to_user,v_added_by,v_dest_msg_seq_id,PAT_CLM_IDS(i),v_added_by_name);
     END IF;
    END LOOP;
    END IF;

    v_rows_processed := SQL%ROWCOUNT;
    IF v_call_type = 'EXT' THEN
      COMMIT;
    END IF;
  END save_assign_users;


--===============================================================================================
PROCEDURE reassign_user (
    v_pat_gen_detail_seq_id                IN VARCHAR2,
    v_claim_seq_id                         IN VARCHAR2,
    v_assigned_to_user                     IN ASSIGN_USERS.assigned_to_user%TYPE,
    v_added_by                             IN NUMBER,
    v_flag                                 IN VARCHAR2,
    v_assign_users_seq_id                  OUT  ASSIGN_USERS.assign_users_seq_id%TYPE,
    v_remarks                              IN ASSIGN_USERS.Remarks%TYPE DEFAULT NULL
    
  )
  IS
    v_event_seq_id PAT_GENERAL_DETAILS.event_seq_id%TYPE;
    v_update_yn                            CHAR(1) := 'N';
    v_assigned_to ASSIGN_USERS.assigned_to_user%TYPE := v_assigned_to_user;
    
    CURSOR pat_assigned_cur(v_pat_gen_detail_seq_id VARCHAR2) IS 
	  SELECT B.assigned_to_user , b.review_completed_yn , a.assign_user_seq_id,b.remarks ,
      b.rson_general_type_id,NULL as pat_status_general_type_id,a.tot_approved_amount as Total_App_Amount ,a.completed_yn,a.completed_date,UC.tpa_office_seq_id
      FROM pat_authorization_details A 
	  LEFT OUTER JOIN assign_users B ON ( a.assign_user_seq_id = b.assign_users_seq_id )
      RIGHT OUTER JOIN tpa_user_contacts UC on (UC.CONTACT_SEQ_ID=B.ASSIGNED_TO_USER)
      WHERE a.pat_auth_seq_id = v_pat_gen_detail_seq_id
      order by b.ADDED_DATE desc;

    CURSOR clm_assigned_cur(v_claim_seq_id VARCHAR2) IS 
	   SELECT B.assigned_to_user, b.review_completed_yn , a.added_by,b.remarks ,
       b.rson_general_type_id, NULL as pat_status_general_type_id,a.tot_approved_amount as Total_App_Amount,a.completed_yn,a.completed_date,UC.tpa_office_seq_id
       FROM clm_authorization_details A  
	   LEFT OUTER JOIN assign_users B ON ( a.assign_user_seq_id = b.assign_users_seq_id )
       RIGHT OUTER JOIN tpa_user_contacts UC on (UC.CONTACT_SEQ_ID=B.ASSIGNED_TO_USER)
       WHERE a.claim_seq_id = v_claim_seq_id 
       order by b.ADDED_DATE desc;

    user_rec clm_assigned_cur%ROWTYPE;

    v_super_user        CHAR(1) := 'N';
    v_same_user_yn      CHAR(1) := 'N';
    v_mode              CHAR(3);   
    v_code_event_seq    PAT_GENERAL_DETAILS.event_seq_id%TYPE; 
    PAT_CLM_IDS         ttk_util_pkg.str_table_type;     

  BEGIN
 IF v_claim_seq_id IS NULL THEN
      
    PAT_CLM_IDS:= ttk_util_pkg.parse_str(v_pat_gen_detail_seq_id);
    
   FOR I IN  PAT_CLM_IDS.FIRST..PAT_CLM_IDS.LAST LOOP
     
        OPEN  pat_assigned_cur(PAT_CLM_IDS(I));
          FETCH pat_assigned_cur INTO user_rec;
            CLOSE pat_assigned_cur;
          
       IF v_added_by !=NVL(user_rec.assigned_to_user,0) AND NVL(v_flag,'PRIV') NOT IN ('SUP','MAN','AUT') THEN 
        raise_application_error (-20108, 'You lack permissions to modify/Re-assign this Pre-Auth ');
       END IF;
        
       IF v_assigned_to IS NULL THEN
          v_assigned_to := v_added_by;
       END IF;
    
       IF v_flag IN ('SUP','MAN','AUT','SAV') THEN
      
         INSERT INTO assign_users (
          assign_users_seq_id,   pat_gen_detail_seq_id, claim_seq_id, tpa_office_seq_id, assigned_to_user , assigned_date,pat_status_general_type_id,total_app_amount,completed_date,
          remarks, review_completed_yn ,rson_general_type_id,
           added_by,  added_date)
         VALUES 
         ( pat_assign_users_seq.NEXTVAL , PAT_CLM_IDS(I), NULL , user_rec.tpa_office_seq_id, /*v_added_by*/ v_assigned_to, SYSDATE,user_rec.pat_status_general_type_id,user_rec.total_app_amount,user_rec.completed_date,
          v_remarks  ,CASE WHEN v_flag IN ('REV','CMP') THEN 'Y' ELSE 'N' END,user_rec.rson_general_type_id,
          v_added_by,   SYSDATE)
         RETURNING assign_users_seq_id INTO v_assign_users_seq_id ;
    
         UPDATE pat_authorization_details a SET
             a.assign_user_seq_id = v_assign_users_seq_id,
             a.updated_by              = v_added_by,
             a.updated_date            = SYSDATE
         WHERE a.pat_auth_seq_id = PAT_CLM_IDS(I) ;
      END IF;
      
   END LOOP;
    
 ELSE
      
    PAT_CLM_IDS:=ttk_util_pkg.parse_str(v_claim_seq_id);
    
   FOR I IN  PAT_CLM_IDS.FIRST..PAT_CLM_IDS.LAST LOOP 
      OPEN  clm_assigned_cur(PAT_CLM_IDS(I));
        FETCH clm_assigned_cur INTO user_rec;
           CLOSE clm_assigned_cur;
      
      IF v_added_by !=NVL(user_rec.assigned_to_user,0) AND NVL(v_flag,'PRIV') NOT IN ('SUP','MAN','AUT') THEN 
        raise_application_error (-20108, 'You lack permissions to modify/Re-assign this Pre-Auth ');
      END IF;
    
      IF v_assigned_to IS NULL THEN
        v_assigned_to := v_added_by;
      END IF;
    
      IF v_flag IN ('SUP','MAN','AUT','SAV') THEN
      
          INSERT INTO assign_users (
          assign_users_seq_id,   pat_gen_detail_seq_id, claim_seq_id, tpa_office_seq_id, assigned_to_user , assigned_date,pat_status_general_type_id,total_app_amount,completed_date,
          remarks, review_completed_yn ,rson_general_type_id,
           added_by,  added_date)
          VALUES 
          ( pat_assign_users_seq.NEXTVAL , NULL , PAT_CLM_IDS(I) , user_rec.tpa_office_seq_id, /*v_added_by*/ v_assigned_to, SYSDATE,user_rec.pat_status_general_type_id,user_rec.total_app_amount,user_rec.completed_date,
          v_remarks  ,CASE WHEN v_flag IN ('REV','CMP') THEN 'Y' ELSE 'N' END,user_rec.rson_general_type_id,
          v_added_by,   SYSDATE)
          RETURNING assign_users_seq_id INTO v_assign_users_seq_id ;
           
          UPDATE clm_authorization_details a SET
             a.assign_user_seq_id = v_assign_users_seq_id, 
             a.updated_by              = v_added_by,
             a.updated_date            = SYSDATE
          WHERE a.claim_seq_id = PAT_CLM_IDS(I) ;
       
      END IF;
  END LOOP;   
END IF;
   
  END reassign_user ;
--===============================================================================================
 PROCEDURE select_assign_to(
    v_assign_users_seq_id         IN ASSIGN_USERS.assign_users_seq_id%TYPE,
    v_added_by                    IN NUMBER,
    v_mode                        IN VARCHAR2,
    result_set                    OUT SYS_REFCURSOR
  )
  IS
  BEGIN
   IF v_mode = 'PAT' THEN
     OPEN result_set FOR
       SELECT
         a.assign_users_seq_id ,
         A.assigned_to_user ,
         A.tpa_office_seq_id ,
         A.remarks,
         B.pat_auth_seq_id AS seq_id,
         B.pre_auth_number AS id_number,
         B.policy_seq_id
         FROM assign_users A JOIN pat_authorization_details B ON (A.pat_gen_detail_seq_id = B.pat_auth_seq_id)
         WHERE A.assign_users_seq_id = v_assign_users_seq_id ;
    ELSE
      OPEN result_set FOR
       SELECT
         a.assign_users_seq_id ,
         A.assigned_to_user ,
         A.tpa_office_seq_id ,
         A.remarks,
         B.claim_seq_id AS seq_id,
         b.claim_number AS id_number,
         B.policy_seq_id
         FROM assign_users A JOIN clm_authorization_details B ON (A.claim_seq_id = B.claim_seq_id)
         WHERE A.assign_users_seq_id = v_assign_users_seq_id ;
    END IF;
  END select_assign_to;
 --===============================================================================================
 PROCEDURE manual_assign_preauth (
         v_tpa_office_seq_id                    IN TPA_USER_CONTACTS.tpa_office_seq_id%TYPE,
         v_result_set                           OUT SYS_REFCURSOR 
		 )
         AS
  BEGIN


	OPEN v_result_set FOR 
             SELECT UC.CONTACT_SEQ_ID,UC.CONTACT_NAME FROM APP.TPA_LOGIN_INFO UR
             JOIN APP.TPA_USER_CONTACTS UC ON (UR.CONTACT_SEQ_ID=UC.CONTACT_SEQ_ID)
             WHERE UC.TPA_OFFICE_SEQ_ID= v_tpa_office_seq_id AND uc.dept_general_type_id in ('PRE','CLM')
             AND UR.ACTIVE_YN='Y' ORDER BY UC.CONTACT_NAME;
   END 	manual_assign_preauth;		 
--=========================================================================================================================
                                 
PROCEDURE override_preauth (
    v_pat_auth_seq_id               IN pat_authorization_details.pat_auth_seq_id%TYPE,
    v_added_by                      IN NUMBER,
    v_override_remarks              IN pat_authorization_details.override_remarks%TYPE,
    v_rows_processed                OUT NUMBER
  )
  IS

 Cursor pre_com_clm is
 select count(1) from app.clm_authorization_details p 
 where p.pat_auth_seq_id=v_pat_auth_seq_id ;
 --and p.completed_yn='Y';


 Cursor pre_cur_check is
  SELECT k.balance_seq_id,a.* from pat_authorization_details a
    JOIN tpa_enr_policy_member E ON (a.member_seq_id = e.member_seq_id)
    LEFT OUTER JOIN tpa_enr_policy_group gr ON (gr.policy_group_seq_id = e.policy_group_seq_id)
    LEFT OUTER JOIN tpa_enr_balance k ON (e.policy_group_seq_id = k.policy_group_seq_id )
   WHERE ( E.mem_general_type_id != 'PFL' AND A.member_seq_id = K.member_seq_id
         OR K.member_seq_id IS NULL OR A.member_seq_id IS NULL ) AND a.pat_auth_seq_id =v_pat_auth_seq_id;
  v_count   number;
  pre_rec  pre_cur_check%rowtype;
  v_sum pat_authorization_details.ava_sum_insured%TYPE;
  v_seq_id                  NUMBER(10);
  v_logs         VARCHAR2(3000):=NULL;

  BEGIN
  
  authorization_pkg.reassign_user('|'||v_pat_auth_seq_id||'|',null,null,v_added_by,null,v_seq_id);

      OPEN pre_com_clm;
      FETCH pre_com_clm INTO v_count;
      CLOSE pre_com_clm;

      OPEN pre_cur_check;
      FETCH pre_cur_check INTO pre_rec;
      CLOSE pre_cur_check;

      IF pre_rec.final_app_amount>0 THEN
          v_sum   := pre_rec.final_app_amount ;
        else
         v_sum :=0;
      END IF;

     IF v_count>0 THEN
          RAISE_APPLICATION_ERROR(-20397,' Claim Completed so you Cannot Override Preauth.');
     else


        UPDATE pat_authorization_details cd
        SET cd.completed_yn      = 'N',
            cd.claim_seq_id     = null,
            cd.override_by      = v_added_by,
            cd.override_date    = sysdate,
            cd.override_remarks = v_override_remarks,
            cd.completed_date   = null,
            cd.updated_date     = sysdate,
            cd.Updated_By       =v_added_by,
			      cd.pat_status_type_id ='INP',
            cd.cal_act_yn         = 'N'
        where cd.pat_auth_seq_id = v_pat_auth_seq_id;

        /*update app.clm_authorization_details ca
        SET    ca.pat_auth_seq_id=null
        where ca.pat_auth_seq_id=v_pat_auth_seq_id;*/

       UPDATE tpa_enr_balance a SET
               a.utilised_sum_insured   = a.utilised_sum_insured - v_sum ,
               a.updated_by             = v_added_by,
               a.updated_date           = SYSDATE
               WHERE a.balance_seq_id = pre_rec.balance_seq_id;
     END IF;
     v_rows_processed := SQL%ROWCOUNT;
     
     MODIFICATION_TRACKER_PKG.MODIFICATION_HIST_PRC(NULL, v_pat_auth_seq_id, 'PAT', 'OVERRIDE', v_added_by);
     
          ------ CR-0393IssueAndRe-issueOfClaims  --------------
    IF v_count<=0 THEN
       v_logs := 'Override Remark : ' || v_override_remarks;
                                                            
       save_pat_clm_logs('P',v_pat_auth_seq_id,'OVR',v_logs,v_added_by,'Y');
   
    END IF;
       -------------------------------------
    commit;

  END override_preauth;
--======================================================================================================                                 
procedure select_provider_copay (v_pre_auth IN NUMBER,
                                 v_mode     IN VARCHAR2,
                                 v_res_set   OUT SYS_REFCURSOR)
IS
BEGIN

IF v_mode='PAT' THEN
OPEN v_res_set FOR
select distinct pad.benifit_type,NVL(pat.Prov_Copay_Perc,0) AS copay_perc,NVL(pat.Prov_Copay_flag,'NA') AS suffix,
       NVL(pat.deduct_amount,0) AS deduct_amount
from pat_authorization_details pad
join pat_activity_details pat on (pad.pat_auth_seq_id=pat.pat_auth_seq_id)
JOIN Tpa_Activity_Details tad on (tad.activity_code=pat.code)
where  pad.pat_auth_seq_id=v_pre_auth;

ELSE

OPEN v_res_set FOR
select distinct NVL(pat.Prov_Copay_Perc,0) AS copay_perc,NVL(pat.Prov_Copay_flag,'NA') AS suffix,
       NVL(pat.deduct_amount,0) AS deduct_amount
from CLM_authorization_details pad 
join pat_activity_details pat on (pad.claim_seq_id=pat.claim_seq_id)
JOIN Tpa_Activity_Details tad on (tad.activity_code=pat.code)
where  pad.claim_Seq_id=v_pre_auth;
end if;
END select_provider_copay;
--===============================================================================================
--Check Max limit of Approval amount by User of Preauth/ Claim
PROCEDURE check_approval_limit (
    v_assigned_to_user                 IN assign_users.assigned_to_user%TYPE,
    v_approval_amount                  IN NUMBER,
    v_flag                             IN CHAR
  )
  IS
    CURSOR pat_cur IS
      SELECT a.contact_pa_limit , a.contact_claim_limit
       FROM tpa_user_contacts a
       JOIN tpa_office_info b ON (a.tpa_office_seq_id = b.tpa_office_seq_id)
       WHERE a.contact_seq_id = v_assigned_to_user ;

    v_contact_pa_limit                 tpa_user_contacts.contact_pa_limit%TYPE;
    v_contact_claim_limit              tpa_user_contacts.contact_claim_limit%TYPE;
    v_limit                            tpa_user_contacts.contact_claim_limit%TYPE;
  BEGIN
    OPEN pat_cur ;
    FETCH pat_cur INTO v_contact_pa_limit , v_contact_claim_limit;
    CLOSE pat_cur;
    
    IF v_flag = 'PAT' THEN
      v_limit        := v_contact_pa_limit;
    ELSE
      v_limit        := v_contact_claim_limit;
    END IF;
    
    IF v_approval_amount > NVL(v_limit,0) THEN
      RAISE_APPLICATION_ERROR(-20123,'Approval limit Exceeded.');
    END IF;
  END check_approval_limit;
  --==================================================================================================

---********DISPLAY OF PRE_AUTH AND CLAIM HISTORY IN PRE_AUTH AND CLAIM MODULE


PROCEDURE select_pat_clm_benefit_history(
                                         v_member_seq_id IN tpa_enr_policy_member.member_seq_id%type,
                                         v_mode          IN varchar2,
                                         v_alkood_id     IN tpa_enr_policy_member.tpa_enrollment_id%type,
                                         v_policy_seq_id IN tpa_enr_policy.policy_seq_id%type,
                                         v_benefit_type  IN varchar2,
                                         v_sort_var      IN VARCHAR2,
                                         v_sor_order     IN VARCHAR2,
                                         v_result_set    OUT SYS_REFCURSOR,
										                     v_tot_apr_amt   OUT SYS_REFCURSOR ------- newly added for sum of total_approved_amount
                                         )

IS
P_sor_order  varchar2(500);
p_sor_var    varchar2(100);
v_sqlstr     VARCHAR2(10000);

BEGIN
 
IF v_sor_order IS NULL THEN
  P_sor_order:='DESC';
ELSIF v_sor_order IS NOT NULL THEN
  P_sor_order:=v_sor_order; 
END IF;

IF v_sort_var IS NULL THEN
  p_sor_var:='PRE_AUTH_NUMBER';
ELSIF v_sort_var IS NOT NULL THEN
  p_sor_var:=v_sort_var; 
END IF; 
        

    IF  v_benefit_type  is null THEN 
      
      IF v_mode='PAT' THEN 
          -- OPEN v_result_set  FOR
         v_sqlstr:='WITH T AS
 (
  --SELECT A.PAT_AUTH_SEQ_ID FROM APP.PAT_AUTHORIZATION_DETAILS  A  WHERE A.MEMBER_SEQ_ID = '''||v_MEMBER_SEQ_ID||'''
  SELECT A.PAT_AUTH_SEQ_ID FROM APP.PAT_AUTHORIZATION_DETAILS  A 
  join tpa_enr_policy_member pm on (a.member_seq_id=pm.member_seq_id) 
  WHERE pm.tpa_enrollment_id = '''||v_alkood_id||''' and a.policy_seq_id = '''||v_policy_seq_id||'''
  )SELECT a.pat_auth_seq_id,
                     a.member_seq_id,
                     a.claim_seq_id,
                     a.pre_auth_number,
                     a.auth_number,
                     a.mem_name,
                     cad.claim_number as claim_number,
                     null as settlement_number,
                     a.tot_approved_amount,
                     nvl(c.hosp_name,b.provider_name) as hosp_name,
                     TO_CHAR(a.hospitalization_date,''DD-MM-RRRR HH12:MI AM'') as admission_date,
                     d.description as pat_status,
                     ben.description as benifit_type,
                     null as payment_status,
                     ''-'' as claim_file_no,
                      case when nvl(a.parent_pat_auth_seq_id,0) != 0
                                    and a.pat_enhanced_yn = ''N''   then
                                    ''Y''
                                else
                                    ''N''
                                end as ENHANCED_PREAUTHYN,   -----NEWLY ADDED FOR ENHANCE PREAUTH
                    (SELECT  replace(to_char(wm_concat(X.diagnosys_code)), '','', ''/'')
                     FROM APP.PAT_AUTHORIZATION_DETAILS PA
                     join tpa_enr_policy_member pm on (pa.member_seq_id=pm.member_seq_id)
                     JOIN APP.DIAGNOSYS_DETAILS X ON PA.PAT_AUTH_SEQ_ID = X.PAT_AUTH_SEQ_ID
                     WHERE pm.tpa_enrollment_id = '''||v_alkood_id||''' and pa.policy_seq_id = '''||v_policy_seq_id||'''
                     AND PA.PAT_AUTH_SEQ_ID = T.PAT_AUTH_SEQ_ID
                    ) as diag,
                   
                 ( SELECT     replace(to_char(wm_concat(REPLACE(Y.SHORT_DESC,'',''))), '','', ''/'')
                     FROM APP.PAT_AUTHORIZATION_DETAILS PA
                     JOIN tpa_enr_policy_member pm on (pa.member_seq_id=pm.member_seq_id)
                     JOIN APP.DIAGNOSYS_DETAILS X ON PA.PAT_AUTH_SEQ_ID = X.PAT_AUTH_SEQ_ID
                     JOIN APP.TPA_ICD10_MASTER_DETAILS Y ON (X.diagnosys_code=Y.ICD_CODE)
                    WHERE pm.tpa_enrollment_id = '''||v_alkood_id||''' and pa.policy_seq_id = '''||v_policy_seq_id||'''
                     AND PA.PAT_AUTH_SEQ_ID = T.PAT_AUTH_SEQ_ID)  ICD_DESC
                  FROM app.pat_authorization_details a left outer join 
                   app.pat_non_network_details b on (a.pat_auth_seq_id=b.pat_auth_seq_id)
                   JOIN tpa_enr_policy_member pm on (a.member_seq_id=pm.member_seq_id)
                   left outer join app.tpa_hosp_info c on (c.hosp_seq_id=a.hosp_seq_id)
                   left outer join app.tpa_general_code d on (d.general_type_id=a.pat_status_type_id)
                   left outer join app.tpa_general_code ben on (ben.general_type_id=a.Benifit_Type)
                   left outer join app.clm_authorization_details cad on (cad.pat_auth_seq_id=a.pat_auth_seq_id)
                   LEFT OUTER JOIN APP.T ON (A.PAT_AUTH_SEQ_ID = T.PAT_AUTH_SEQ_ID)
                   WHERE pm.tpa_enrollment_id = '''||v_alkood_id||''' and a.policy_seq_id = '''||v_policy_seq_id||''' 
                   and a.pre_auth_number is not null';
  /*and a.completed_yn='Y'*/
   ----display of sum of total approved amount in pre auth and claim history screen with out benefit type	
          v_sqlstr := 'SELECT * FROM
                      (SELECT A.*,DENSE_RANK() OVER (ORDER BY '||p_sor_var||' '||P_sor_order||',ROWNUM)
                       Q FROM (' ||v_sqlstr|| ') A )';   
    OPEN v_result_set FOR v_sqlstr;
         
          OPEN   v_tot_apr_amt FOR
             select  TO_CHAR(SUM(a.tot_approved_amount)) as sum_tot_apr_amt
                 from APP.pat_authorization_details a
                 JOIN tpa_enr_policy_member pm on (a.member_seq_id=pm.member_seq_id)
                 where pm.tpa_enrollment_id =  v_alkood_id and a.policy_seq_id=v_policy_seq_id and  a.pre_auth_number is not null and a.pat_enhanced_yn = 'N';
                   
      ELSE 
            
            --OPEN v_result_set  FOR
               v_sqlstr:=' WITH T AS
 (
  SELECT A.claim_seq_id FROM APP.clm_authorization_details A join tpa_enr_policy_member pm on (a.member_seq_id=pm.member_seq_id) 
  WHERE pm.tpa_enrollment_id = '''||v_alkood_id||''' and a.policy_seq_id = '''||v_policy_seq_id||'''
          ),
  CLM_LIST AS
          (
          SELECT CAD.CLAIM_SEQ_ID,CAD.PARENT_CLAIM_SEQ_ID,CAD.MEMBER_SEQ_ID
                  FROM CLM_AUTHORIZATION_DETAILS CAD 
          WHERE MEMBER_SEQ_ID ='''||v_member_seq_id||''' ),
          RESUB_CNT AS
          (
          SELECT CAD.CLAIM_SEQ_ID,LEVEL AS LV
                  FROM CLM_LIST CAD 
          WHERE MEMBER_SEQ_ID ='''||v_member_seq_id||''' 
          start with PARENT_CLAIM_SEQ_ID is null
          CONNECT BY CAD.PARENT_CLAIM_SEQ_ID=PRIOR CAD.CLAIM_SEQ_ID
  )
SELECT  a.pat_auth_seq_id,
                       a.claim_seq_id,
                       CASE WHEN cnt.lv>1 THEN a.claim_number||'' R''||(cnt.lv-1) ELSE a.claim_number END as claim_number,
                       a.settlement_number,
                       a.member_seq_id,
                       pad.pre_auth_number as pre_auth_number,
                       null as auth_number,
                       a.mem_name,
                       a.tot_approved_amount,
                       nvl(c.hosp_name,b.hosp_name) as hosp_name,
                       TO_CHAR(a.date_of_hospitalization,''DD-MM-RRRR HH12:MI AM'') as admission_date,
                       d.description as pat_status,
                       ben.description as benifit_type,
                       nvl(pay.claim_payment_status,''-'') as payment_status,
                       a.invoice_number,
					  case when a.status_code_id is not null then ''Y'' else ''N'' end as fraud_yn,
                            NVL(a.suspect_veri_check,''N'') AS  suspect_veri_check,
                            a.status_code_id,
                             nvl(a.common_file_number,''-'') as claim_file_no,
                              (SELECT  replace(to_char(wm_concat(X.diagnosys_code)), '','', ''/'')
                     FROM APP.clm_authorization_details PA
                     join tpa_enr_policy_member pm on (pa.member_seq_id=pm.member_seq_id)
                     JOIN APP.DIAGNOSYS_DETAILS X ON PA.claim_seq_id = X.claim_seq_id
                     WHERE pm.tpa_enrollment_id = '''||v_alkood_id||''' and pa.policy_seq_id = '''||v_policy_seq_id||'''
                     AND PA.claim_seq_id = T.claim_seq_id
                    ) as diag,
                      ( SELECT     replace(to_char(wm_concat(REPLACE(NVL(Y.SHORT_DESC,''NA''),'',''))), '','', ''/'')
                     FROM APP.clm_authorization_details PA
                     JOIN TPA_ENR_POLICY_MEMBER pm on (pa.member_seq_id=pm.member_seq_id)
                     JOIN APP.DIAGNOSYS_DETAILS X ON PA.claim_seq_id = X.claim_seq_id
                     LEFT JOIN APP.TPA_ICD10_MASTER_DETAILS Y ON (X.diagnosys_code=Y.ICD_CODE)
                     WHERE pm.tpa_enrollment_id = '''||v_alkood_id||''' and pa.policy_seq_id = '''||v_policy_seq_id||'''
                      AND PA.claim_seq_id = T.claim_seq_id) ICD_DESC
                             
              FROM app.clm_authorization_details a left outer join 
                   app.clm_hospital_details b on (a.claim_seq_id=b.claim_seq_id)
                   join tpa_enr_policy_member pm on (a.member_seq_id=pm.member_seq_id)
                   left outer join app.tpa_hosp_info c on (c.hosp_seq_id=b.hosp_seq_id)
                   left outer join app.tpa_general_code d on (d.general_type_id=a.clm_status_type_id)
                   left outer join fin_app.tpa_claims_payment pay on (a.claim_seq_id=pay.claim_seq_id)
                   left outer join app.pat_authorization_details pad on (a.pat_auth_seq_id=pad.pat_auth_seq_id)  
                   left outer join app.tpa_general_code ben on (ben.general_type_id=a.Benifit_Type)
                   LEFT OUTER JOIN APP.T ON (A.claim_seq_id = T.claim_seq_id)  
                   left outer join resub_cnt cnt on (a.claim_seq_id=cnt.claim_seq_id) 
                   WHERE pm.tpa_enrollment_id = '''||v_alkood_id||''' and a.policy_seq_id = '''||v_policy_seq_id||'''
                   and a.claim_number  is not null';
				   
		       v_sqlstr := 'SELECT * FROM
                      (SELECT A.*,DENSE_RANK() OVER (ORDER BY '||p_sor_var||' '||P_sor_order||',ROWNUM)
                       Q FROM (' ||v_sqlstr|| ') A )';   
         
         OPEN v_result_set FOR v_sqlstr;
         		   
		     OPEN   v_tot_apr_amt FOR
             select  TO_CHAR(SUM(a.tot_approved_amount)) as sum_tot_apr_amt
                 from APP.clm_authorization_details a
                 join tpa_enr_policy_member pm on (a.member_seq_id=pm.member_seq_id)
                   WHERE pm.tpa_enrollment_id =  v_alkood_id and a.policy_seq_id =v_policy_seq_id  
                   and a.claim_number  is not null;                   
        
        
       END IF;
       
   ELSE
   
       IF v_mode='PAT' Then 
           --OPEN v_result_set  FOR
            v_sqlstr:=' WITH T AS
 (
  SELECT A.PAT_AUTH_SEQ_ID FROM APP.PAT_AUTHORIZATION_DETAILS  A  
  join tpa_enr_policy_member pm on (a.member_seq_id=pm.member_seq_id) 
  WHERE pm.tpa_enrollment_id = '''||v_alkood_id||''' and a.policy_seq_id = '''||v_policy_seq_id||'''  
  ) SELECT a.pat_auth_seq_id,
                     a.member_seq_id,
                     a.claim_seq_id,
                     a.pre_auth_number,
                     a.auth_number,
                     a.mem_name,
                     cad.claim_number as claim_number,
                     null as settlement_number,
                     a.tot_approved_amount,
                     nvl(c.hosp_name,b.provider_name) as hosp_name,
                     TO_CHAR(a.hospitalization_date,''DD-MM-RRRR HH12:MI AM'') as admission_date,
                     d.description as pat_status,
                     ben.description as benifit_type,
                     ''-'' as payment_status,
                     null as invoice_number,
                            ''-'' as claim_file_no,
                     case when nvl(a.parent_pat_auth_seq_id,0) != 0
                                    and a.pat_enhanced_yn = ''N''   then
                                    ''Y''
                                else
                                    ''N''
                                end as ENHANCED_PREAUTHYN,   -----NEWLY ADDED FOR ENHANCE PREAUTH
					(SELECT  replace(to_char(wm_concat(X.diagnosys_code)), '','', ''/'')
                     FROM APP.PAT_AUTHORIZATION_DETAILS PA
                     join tpa_enr_policy_member pm on (pa.member_seq_id=pm.member_seq_id)
                     JOIN APP.DIAGNOSYS_DETAILS X ON PA.PAT_AUTH_SEQ_ID = X.PAT_AUTH_SEQ_ID
                     WHERE pm.tpa_enrollment_id = '''||v_alkood_id||''' and a.policy_seq_id = '''||v_policy_seq_id||'''
                     AND PA.PAT_AUTH_SEQ_ID = T.PAT_AUTH_SEQ_ID
                    ) as diag,
                    ( SELECT     replace(to_char(wm_concat(REPLACE(Y.SHORT_DESC,'',''))), '','', ''/'')
                     FROM APP.PAT_AUTHORIZATION_DETAILS PA
                     join tpa_enr_policy_member pm on (pa.member_seq_id=pm.member_seq_id)
                     JOIN APP.DIAGNOSYS_DETAILS X ON PA.PAT_AUTH_SEQ_ID = X.PAT_AUTH_SEQ_ID
                     JOIN APP.TPA_ICD10_MASTER_DETAILS Y ON (X.diagnosys_code=Y.ICD_CODE)
                     WHERE pm.tpa_enrollment_id = '''||v_alkood_id||''' and a.policy_seq_id = '''||v_policy_seq_id||'''
                      AND PA.PAT_AUTH_SEQ_ID = T.PAT_AUTH_SEQ_ID) ICD_DESC

              FROM app.pat_authorization_details a left outer join 
                   app.pat_non_network_details b on (a.pat_auth_seq_id=b.pat_auth_seq_id)
                   join tpa_enr_policy_member pm on (a.member_seq_id=pm.member_seq_id)
                   left outer join app.tpa_hosp_info c on (c.hosp_seq_id=a.hosp_seq_id)
                   left outer join app.tpa_general_code d on (d.general_type_id=a.pat_status_type_id)
                   left outer join app.clm_authorization_details cad on (cad.pat_auth_seq_id=a.pat_auth_seq_id)  
                   join app.tpa_general_code ben on (ben.general_type_id=a.Benifit_Type)
                    LEFT OUTER JOIN APP.T ON (A.PAT_AUTH_SEQ_ID = T.PAT_AUTH_SEQ_ID) 
                   where pm.tpa_enrollment_id = '''||v_alkood_id||''' and a.policy_seq_id = '''||v_policy_seq_id||'''  and a.pre_auth_number is not null 
                        and a.benifit_type ='''||v_benefit_type||''''
                         ;
						 v_sqlstr := 'SELECT * FROM
                      (SELECT A.*,DENSE_RANK() OVER (ORDER BY '||p_sor_var||' '||P_sor_order||',ROWNUM)
                       Q FROM (' ||v_sqlstr|| ') A )';   
         
         OPEN v_result_set FOR v_sqlstr;
  ---------display of sum of total approved amount in pre auth and claim history screen with  benefit type		
	
         OPEN   v_tot_apr_amt FOR
             select  TO_CHAR(SUM(a.tot_approved_amount)) as sum_tot_apr_amt
                 from APP.pat_authorization_details a
                   where a.member_seq_id  = v_member_seq_id  and a.benifit_type = v_benefit_type 
                   and a.pre_auth_number is not null and a.pat_enhanced_yn = 'N' ;	
   						
        
        ELSE 
            
           -- OPEN v_result_set  FOR
               v_sqlstr:=' WITH T AS
 (
  SELECT A.claim_seq_id FROM APP.clm_authorization_details  A  join tpa_enr_policy_member pm on (a.member_seq_id=pm.member_seq_id) 
  WHERE pm.tpa_enrollment_id = '''||v_alkood_id||''' and a.policy_seq_id = '''||v_policy_seq_id||''' 
              ),
  CLM_LIST AS
          (
          SELECT CAD.CLAIM_SEQ_ID,CAD.PARENT_CLAIM_SEQ_ID,CAD.MEMBER_SEQ_ID
                  FROM CLM_AUTHORIZATION_DETAILS CAD 
          WHERE MEMBER_SEQ_ID ='''||v_member_seq_id||''' ),
          RESUB_CNT AS
          (
          SELECT CAD.CLAIM_SEQ_ID,LEVEL AS LV
                  FROM CLM_LIST CAD 
          WHERE MEMBER_SEQ_ID ='''||v_member_seq_id||''' 
          start with PARENT_CLAIM_SEQ_ID is null
          CONNECT BY CAD.PARENT_CLAIM_SEQ_ID=PRIOR CAD.CLAIM_SEQ_ID
          ) 
  
  SELECT  a.pat_auth_seq_id,
                       a.claim_seq_id,
                       CASE WHEN cnt.lv>1 THEN a.claim_number||'' R''||(cnt.lv-1) ELSE a.claim_number END as claim_number,
                       a.settlement_number,
                       a.member_seq_id,
                       pad.pre_auth_number as pre_auth_number,
                       null as auth_number,
                       a.mem_name,
                       a.tot_approved_amount,
                       nvl(c.hosp_name,b.hosp_name) as hosp_name,
                       TO_CHAR(a.date_of_hospitalization,''DD-MM-RRRR HH12:MI AM'') as admission_date,
                       d.description as pat_status,
                       ben.description as benifit_type,
                       nvl(pay.claim_payment_status,''-'') as payment_status,
                       a.invoice_number,
					   case when a.status_code_id is not null then ''Y'' else ''N'' end as fraud_yn,
                            NVL(a.suspect_veri_check,''N'') AS  suspect_veri_check,
                            a.status_code_id,
                            nvl(a.common_file_number,''-'') as claim_file_no,
                          (SELECT  replace(to_char(wm_concat(X.diagnosys_code)), '','', ''/'')
                     FROM APP.clm_authorization_details PA
                     join tpa_enr_policy_member pm on (pa.member_seq_id=pm.member_seq_id)
                     JOIN APP.DIAGNOSYS_DETAILS X ON PA.claim_seq_id = X.claim_seq_id
                     WHERE pm.tpa_enrollment_id = '''||v_alkood_id||''' and pa.policy_seq_id = '''||v_policy_seq_id||'''
                     AND PA.claim_seq_id = T.claim_seq_id
                    ) as diag,
                     ( SELECT     replace(to_char(wm_concat(REPLACE(Y.SHORT_DESC,'',''))), '','', ''/'')
                     FROM APP.clm_authorization_details PA
                     join tpa_enr_policy_member pm on (pa.member_seq_id=pm.member_seq_id)
                     JOIN APP.DIAGNOSYS_DETAILS X ON PA.claim_seq_id = X.claim_seq_id
                     JOIN APP.TPA_ICD10_MASTER_DETAILS Y ON (X.diagnosys_code=Y.ICD_CODE)
                     WHERE pm.tpa_enrollment_id = '''||v_alkood_id||''' and pa.policy_seq_id = '''||v_policy_seq_id||'''
                      AND PA.claim_seq_id = T.claim_seq_id) ICD_DESC  
                            
              FROM app.clm_authorization_details a left outer join 
                   app.clm_hospital_details b on (a.claim_seq_id=b.claim_seq_id)
                   join tpa_enr_policy_member pm on (a.member_seq_id=pm.member_seq_id)
                   left outer join app.tpa_hosp_info c on (c.hosp_seq_id=b.hosp_seq_id)
                   left outer join app.tpa_general_code d on (d.general_type_id=a.clm_status_type_id) 
                   left outer join fin_app.tpa_claims_payment pay on (a.claim_seq_id=pay.claim_seq_id)
                   left outer join app.pat_authorization_details pad on (a.pat_auth_seq_id=pad.pat_auth_seq_id) 
                    left outer join app.tpa_general_code ben on (ben.general_type_id=a.Benifit_Type)
                     LEFT OUTER JOIN APP.T ON (A.claim_seq_id = T.claim_seq_id)  
                    left outer join RESUB_CNT cnt on (cnt.claim_seq_id=a.claim_seq_id)
                   where pm.tpa_enrollment_id = '''||v_alkood_id||''' and a.policy_seq_id = '''||v_policy_seq_id||'''  and a.benifit_type = '''||v_benefit_type||'''  and a.claim_number  is not null';
                   
				 v_sqlstr := 'SELECT * FROM
                      (SELECT A.*,DENSE_RANK() OVER (ORDER BY '||p_sor_var||' '||P_sor_order||',ROWNUM)
                       Q FROM (' ||v_sqlstr|| ') A )';   
         
         OPEN v_result_set FOR v_sqlstr;   
        OPEN   v_tot_apr_amt FOR
             select  TO_CHAR(SUM(a.tot_approved_amount)) as sum_tot_apr_amt
                 from APP.clm_authorization_details a
                   where a.member_seq_id  = v_member_seq_id  and a.benifit_type = v_benefit_type and a.claim_number  is not null ;					 				   
        
       END IF;

    END IF;
       
END select_pat_clm_benefit_history;

--===============================================================================================
------------*******DISPLAY PRE_AUTH AND CLAIM COUNT IN CLAIM GENERAL SCREEN******--------------
PROCEDURE get_pat_clm_count(
           v_member_seq_id        IN    tpa_enr_policy_member.member_seq_id%type,
           v_pat_clm_count            OUT SYS_REFCURSOR 
                           )

IS

BEGIN

 ------------newly change  member_seq_id instead of tpa_enrollment_id due to renewal policy
  
  OPEN   v_pat_clm_count FOR 
    WITH pre_auth_count AS
      (
       SELECT COUNT(1) as pat_count
       FROM pat_authorization_details a 
       WHERE  /*a.tpa_enrollment_id = v_tpa_enrollment_id*/ a.member_seq_id=v_member_seq_id 
       AND  a.pre_auth_number is not null and a.pat_enhanced_yn = 'N'
      ),
       claim_count as
      (
       SELECT COUNT(1) as clm_count
       FROM clm_authorization_details a
       WHERE  /*a.tpa_enrollment_id = v_tpa_enrollment_id */a.member_seq_id=v_member_seq_id and a.claim_number  is not null
      )
      select pat_count,
             clm_count 
      from pre_auth_count,
           claim_count;

END  get_pat_clm_count; 
 
-------============================================
PROCEDURE upld_clm_pat_docs(p_docs_seq_id     IN pat_clm_docs_tab.docs_seq_id%TYPE,
                            p_pat_clm_seq_id    IN pat_clm_docs_tab.pat_clm_seq_id%TYPE,
                            p_source_id         IN pat_clm_docs_tab.source_id%TYPE,
                            p_docs_desc         IN pat_clm_docs_tab.file_desc%TYPE,
                            p_file_path         IN pat_clm_docs_tab.file_path%TYPE,
                            p_file_name         IN pat_clm_docs_tab.file_name%TYPE,
                            p_added_by          IN pat_clm_docs_tab.added_by%TYPE,
                            p_image_file        IN pat_clm_docs_tab.image_file%TYPE,
                            --p_added_date        IN pat_clm_docs_tab.added_date%TYPE := null,
                            --p_updated_by        IN pat_clm_docs_tab.updated_by%TYPE := null,
                            --p_updated_date      IN pat_clm_docs_tab.updated_date%TYPE := null,
                            p_ref_seq_id        IN pat_clm_docs_tab.reference_seq_id%TYPE,
                            p_flag              OUT NUMBER
                           )
AS
  CURSOR clm_cur IS
    SELECT c.completed_yn
    FROM Clm_Authorization_Details c
    WHERE c.claim_seq_id = p_pat_clm_seq_id;
    
  CURSOR pat_cur IS
    SELECT p.completed_yn
    FROM Pat_Authorization_Details p
    WHERE p.pat_auth_seq_id = p_pat_clm_seq_id;
  
  completed_yn              VARCHAR2(4);
  v_seq_id                  NUMBER;
  v_source_from             VARCHAR2(10);
  j                         NUMBER;
  v_prs                     DBMS_UTILITY.uncl_array;
BEGIN
  j:=1;
  for i in (Select column_value as val from table(cast(ttk_mail_pkg.parse(p_source_id,'|') as strings))) loop
    v_prs(j):=i.val;
    j:=j+1;
  end loop;
  
  IF v_prs(1) = 'HOS' AND v_prs(2) = 'CLM' THEN
    v_source_from := 'CLM';
  ELSIF v_prs(1) = 'HOS' AND v_prs(2) = 'PAT' THEN
    v_source_from := 'PAT';
  ELSIF v_prs(1) = 'PBM' AND v_prs(2) = 'CLM' THEN
    v_source_from := 'CLM';
  ELSIF v_prs(1) = 'PBM' AND v_prs(2) = 'PAT' THEN
    v_source_from := 'PAT';
  ELSIF v_prs(1) = 'PTR' AND v_prs(2) = 'PAT' THEN
    v_source_from := 'PAT';
  ELSIF v_prs(1) = 'PTR' AND v_prs(2) = 'CLM' THEN
    v_source_from := 'CLM';
  ELSIF v_prs(1) = 'MOB' AND v_prs(2) = 'PAT' THEN
    v_source_from := 'PAT';
  ELSIF v_prs(1) = 'MOB' AND v_prs(2) = 'CLM' THEN
    v_source_from := 'CLM';
  ELSIF v_prs(1) = 'CFD' AND v_prs(2) = 'PAT' THEN     --- Added in CFD (Counter fraud cr)
    v_source_from := 'PAT';
  ELSIF v_prs(1) = 'CFD' AND v_prs(2) = 'CLM' THEN
    v_source_from := 'CLM';
  ELSE
    v_source_from := p_source_id;
  END IF;
  
  IF v_source_from = 'PAT' THEN
    OPEN pat_cur;
    FETCH pat_cur INTO completed_yn;
    CLOSE pat_cur;
    
    IF completed_yn = 'Y' AND p_docs_desc != 'APL' THEN
      RAISE_APPLICATION_ERROR(-20107,'You cannot perform this action through a completed Claim.');
    END IF;
  ELSE
    OPEN clm_cur;
    FETCH clm_cur INTO completed_yn;
    CLOSE clm_cur;
    
    IF completed_yn = 'Y' AND p_docs_desc != 'APL' THEN
      RAISE_APPLICATION_ERROR(-20107,'You cannot perform this action through a completed Claim.');
    END IF;
  END IF;
  
  IF NVL(p_docs_seq_id, 0) = 0 THEN
    
    INSERT INTO pat_clm_docs_tab (docs_seq_id,
                                  pat_clm_seq_id,
                                  source_id,
                                  file_desc,
                                  file_name,
                                  file_path,
                                  image_file,
                                  added_by,
                                  added_date,
                                  reference_seq_id,
                                  reference_from
                                  --reference_seq_id
                                 )
                          
                          VALUES(pat_clm_docs_seq.nextval,
                                 p_pat_clm_seq_id,
                                 v_source_from,
                                 p_docs_desc,
                                 p_file_name,
                                 p_file_path,
                                 p_image_file,
                                 p_added_by,
                                 sysdate,
                                 p_ref_seq_id,
                                 nvl(v_prs(1), 'VINGS')
                                 --p_ref_seq_id
                                ) RETURNING docs_seq_id INTO v_seq_id;
  
  /*ELSE
    
    UPDATE pat_clm_docs_tab
    SET source_id = p_source_id,
        file_desc = p_docs_desc,
        file_name = p_file_name,
        image_file = p_image_file,
        file_path = file_path,
        updated_by = p_updated_by,
        updated_date = p_updated_date
    WHERE docs_seq_id = p_docs_seq_id;*/

  END IF;
  
  p_flag := SQL%ROWCOUNT;
  
END upld_clm_pat_docs;
--======================================================================================================
PROCEDURE delete_upld_file_details(p_docs_seq_id       IN VARCHAR2,
                                   p_rowcount          OUT NUMBER
                                  )
AS
  str_tab   Ttk_Util_Pkg.str_table_type;
  
  Cursor source_type_cur(v_seq_id VARCHAR2) IS
    Select p.source_id, p.pat_clm_seq_id
    From pat_clm_docs_tab p
    Where p.docs_seq_id = v_seq_id;
    
  p_source_id           source_type_cur%ROWTYPE;
  
  CURSOR clm_cur(v_clm_seq_id NUMBER) IS
   SELECT c.completed_yn
   FROM Clm_Authorization_Details c
   WHERE c.claim_seq_id = v_clm_seq_id;
    
  CURSOR pat_cur(v_pat_seq_id NUMBER) IS
   SELECT p.completed_yn
   FROM Pat_Authorization_Details p
   WHERE p.pat_auth_seq_id = v_pat_seq_id;
  
  completed_yn              VARCHAR2(4);
BEGIN
  
  str_tab := Ttk_Util_Pkg.parse_str ( p_docs_seq_id );
  p_rowcount := 0;
  
  IF str_tab.COUNT>0 THEN
   FOR i IN str_tab.FIRST..str_tab.LAST LOOP
     
     OPEN source_type_cur(str_tab(1));
     FETCH source_type_cur INTO p_source_id;
     CLOSE source_type_cur;
     
     IF p_source_id.source_id = 'PAT' THEN
        OPEN pat_cur(p_source_id.pat_clm_seq_id);
        FETCH pat_cur INTO completed_yn;
        CLOSE pat_cur;
    
        IF completed_yn = 'Y' THEN
          RAISE_APPLICATION_ERROR(-20107,'You cannot perform this action through a completed Claim.');
        END IF;
     ELSE
        OPEN clm_cur(p_source_id.pat_clm_seq_id);
        FETCH clm_cur INTO completed_yn;
        CLOSE clm_cur;
    
        IF completed_yn = 'Y' THEN
          RAISE_APPLICATION_ERROR(-20107,'You cannot perform this action through a completed Claim.');
        END IF;
     END IF;
     
     Delete from pat_clm_docs_tab p
     Where p.docs_seq_id = str_tab(i);
     
     p_rowcount:=p_rowcount + SQL%ROWCOUNT;
   END LOOP;
 END IF;
  
 commit;
    
END delete_upld_file_details;
--======================================================================================================
PROCEDURE check_overal_limit(v_seq_id         IN NUMBER,
                             v_flag           IN VARCHAR2,
                             v_prod_seq_id    IN NUMBER)
AS
  v_appr_limit    NUMBER(15,3);
  
  CURSOR chk_pat_enroll_cur IS
    Select po.enrol_type_id
    From Pat_Authorization_Details p 
    JOIN Tpa_Enr_Policy po ON po.policy_seq_id = p.policy_seq_id
    WHERE p.pat_auth_seq_id = v_seq_id;
    
  CURSOR chk_clm_enroll_cur IS
    Select po.enrol_type_id
    From Clm_Authorization_Details c
    JOIN Tpa_Enr_Policy po ON po.policy_seq_id = c.policy_seq_id
    WHERE c.claim_seq_id = v_seq_id;
  
  v_enroll_type  VARCHAR2(10);
  
  CURSOR gbl_dntl_limit_cur(v_mem_seq_id NUMBER, v_request_type VARCHAR2) IS
    SELECT NVL(r.gbl_dntl_rule_limit, s.gbl_dntl_rule_limit) as gbl_dntl_rule_limit,
           NVL(r.gbl_dntl_rule_cond, s.gbl_dntl_rule_cond) as gbl_dntl_rule_cond,
           NVL(r.gbl_dntl_rule_copay, s.gbl_dntl_rule_copay) as gbl_dntl_rule_copay,
           NVL(r.gbl_dntl_rule_deduct, s.gbl_dntl_rule_deduct) as gbl_dntl_rule_deduct,
           NVL(r.gbl_dntl_rule_mode, s.gbl_dntl_rule_mode) as gbl_dntl_rule_mode,
           NVL(r.coverage_pay_val, s.coverage_pay_val) as coverage_pay_val
    FROM (
          SELECT /*REPLACE(REGEXP_SUBSTR(extractvalue(pr.prod_policy_rule,'/clauses/clause/coverage/condition[@id="cnd.20.1.2"]/@dynValue'),'[^,]+', 1,3), '''') gbl_dntl_rule_limit,
                 REPLACE(REGEXP_SUBSTR(extractvalue(pr.prod_policy_rule,'/clauses/clause/coverage/condition[@id="cnd.20.1.2"]/@dynValue'),'[^,]+', 1,2), '''') gbl_dntl_rule_cond,
                 REPLACE(REGEXP_SUBSTR(extractvalue(pr.prod_policy_rule,'/clauses/clause/coverage/condition[@id="cnd.20.1.2"]/@dynValue'),'[^,]+', 1,6), '''') gbl_dntl_rule_copay,
                 REPLACE(REGEXP_SUBSTR(extractvalue(pr.prod_policy_rule,'/clauses/clause/coverage/condition[@id="cnd.20.1.2"]/@dynValue'),'[^,]+', 1,8), '''') gbl_dntl_rule_deduct,
                 SUBSTR(REPLACE(REGEXP_SUBSTR(extractvalue(pr.prod_policy_rule,'/clauses/clause/coverage/condition[@id="cnd.20.1.2"]/@dynValue'),'[^,]+', 1,10), ''''), 1, 2) gbl_dntl_rule_mode,*/
                 rv.rule_limit as gbl_dntl_rule_limit,
                 rv.rule_copay as gbl_dntl_rule_copay,rv.rule_condition as gbl_dntl_rule_cond,
                 rv.rule_deductable as gbl_dntl_rule_deduct,rv.rule_limit_flag as gbl_dntl_rule_mode,
                 pa.pat_auth_seq_id, pa.claim_seq_id, pa.member_seq_id,
                 rv.coverage_pay_val as coverage_pay_val
                 
          FROM pat_authorization_details pa
          JOIN app.tpa_prod_policy_rule_values rv on (pa.policy_seq_id=rv.policy_seq_id)
          /*JOIN tpa_ins_prod_policy po ON (po.policy_seq_id = pa.policy_seq_id)
          JOIN tpa_ins_prod_policy_rules pr ON (pr.prod_policy_seq_id = po.prod_policy_seq_id)
          JOIN tpa_ins_prod_pol_clauses B   ON b.prod_policy_rule_seq_id = pr.prod_policy_rule_seq_id
          JOIN tpa_ins_prod_pol_coverages C    ON (b.clause_seq_id = c.clause_seq_id)
          JOIN tpa_ins_prod_pol_conditions D   ON (c.coverage_seq_id = d.coverage_seq_id) */ 
          where rv.prod_policy_rule_seq_id=v_prod_seq_id and rv.service_name='DENTAL'
         -- AND d.cond_val = 'A|'||'D0150'
          AND pa.member_seq_id = v_mem_seq_id
          AND pa.pat_enhanced_yn = 'N'   ------NEWLY ADDED FOR PREAUTH ENHANCEMENT
          AND pa.benifit_type = 'DNTL'
          AND pa.claim_seq_id IS NULL
        --  and b.clause_id NOT IN ('cls.1','cls.28') 
         ) r

     FULL JOIN ( 
          SELECT /*REPLACE(REGEXP_SUBSTR(extractvalue(pr.prod_policy_rule,'/clauses/clause/coverage/condition[@id="cnd.20.1.2"]/@dynValue'),'[^,]+', 1,3), '''') gbl_dntl_rule_limit,
                 REPLACE(REGEXP_SUBSTR(extractvalue(pr.prod_policy_rule,'/clauses/clause/coverage/condition[@id="cnd.20.1.2"]/@dynValue'),'[^,]+', 1,2), '''') gbl_dntl_rule_cond,
                 REPLACE(REGEXP_SUBSTR(extractvalue(pr.prod_policy_rule,'/clauses/clause/coverage/condition[@id="cnd.20.1.2"]/@dynValue'),'[^,]+', 1,6), '''') gbl_dntl_rule_copay,
                 REPLACE(REGEXP_SUBSTR(extractvalue(pr.prod_policy_rule,'/clauses/clause/coverage/condition[@id="cnd.20.1.2"]/@dynValue'),'[^,]+', 1,8), '''') gbl_dntl_rule_deduct,
                 SUBSTR(REPLACE(REGEXP_SUBSTR(extractvalue(pr.prod_policy_rule,'/clauses/clause/coverage/condition[@id="cnd.20.1.2"]/@dynValue'),'[^,]+', 1,10), ''''), 1, 2) gbl_dntl_rule_mode,*/
                 rv.rule_limit as gbl_dntl_rule_limit,
                 rv.rule_copay as gbl_dntl_rule_copay,rv.rule_condition as gbl_dntl_rule_cond,
                 rv.rule_deductable as gbl_dntl_rule_deduct,rv.rule_limit_flag as gbl_dntl_rule_mode,
                 cl.pat_auth_seq_id, cl.claim_seq_id, cl.member_seq_id,
                 rv.coverage_pay_val coverage_pay_val
                 
          FROM clm_authorization_details cl
          JOIN app.tpa_prod_policy_rule_values rv on (cl.policy_seq_id=rv.policy_seq_id)
          /*JOIN tpa_ins_prod_policy po ON (cl.policy_seq_id = po.policy_seq_id)
          JOIN tpa_ins_prod_policy_rules pr ON (pr.prod_policy_seq_id = po.prod_policy_seq_id)
          JOIN tpa_ins_prod_pol_clauses B   ON b.prod_policy_rule_seq_id = pr.prod_policy_rule_seq_id
          JOIN tpa_ins_prod_pol_coverages C    ON (b.clause_seq_id = c.clause_seq_id)
          JOIN tpa_ins_prod_pol_conditions D   ON (c.coverage_seq_id = d.coverage_seq_id) */ 
          where rv.prod_policy_rule_seq_id=v_prod_seq_id AND rv.service_name='DENTAL'
         -- AND d.cond_val = 'A|'||'D0150'
          AND cl.benifit_type = 'DNTL'
          AND cl.member_seq_id = v_mem_seq_id
          AND cl.benifit_type = 'DNTL'
          --and b.clause_id NOT IN ('cls.1','cls.28') 
        ) s
    ON (r.claim_seq_id = s.claim_seq_id)
    WHERE (v_request_type = 'P' AND r.pat_auth_seq_id = nvl(v_seq_id, 0)
      OR v_request_type = 'C' AND s.claim_seq_id = nvl(v_seq_id, 0));
  
  ---
  CURSOR ind_gbl_dntl_limit_cur(v_mem_seq_id NUMBER, v_request_type VARCHAR2) IS
    SELECT NVL(r.gbl_dntl_rule_limit, s.gbl_dntl_rule_limit) as gbl_dntl_rule_limit,
           NVL(r.gbl_dntl_rule_cond, s.gbl_dntl_rule_cond) as gbl_dntl_rule_cond,
           NVL(r.gbl_dntl_rule_copay, s.gbl_dntl_rule_copay) as gbl_dntl_rule_copay,
           NVL(r.gbl_dntl_rule_deduct, s.gbl_dntl_rule_deduct) as gbl_dntl_rule_deduct,
           NVL(r.gbl_dntl_rule_mode, s.gbl_dntl_rule_mode) as gbl_dntl_rule_mode,
           NVL(r.coverage_pay_val, s.coverage_pay_val) as coverage_pay_val
    FROM (
          SELECT REPLACE(REGEXP_SUBSTR(extractvalue(pr.prod_policy_rule,'/clauses/clause/coverage/condition[@id="cnd.20.1.2"]/@dynValue'),'[^,]+', 1,3), '''') gbl_dntl_rule_limit,
                 REPLACE(REGEXP_SUBSTR(extractvalue(pr.prod_policy_rule,'/clauses/clause/coverage/condition[@id="cnd.20.1.2"]/@dynValue'),'[^,]+', 1,2), '''') gbl_dntl_rule_cond,
                 REPLACE(REGEXP_SUBSTR(extractvalue(pr.prod_policy_rule,'/clauses/clause/coverage/condition[@id="cnd.20.1.2"]/@dynValue'),'[^,]+', 1,6), '''') gbl_dntl_rule_copay,
                 REPLACE(REGEXP_SUBSTR(extractvalue(pr.prod_policy_rule,'/clauses/clause/coverage/condition[@id="cnd.20.1.2"]/@dynValue'),'[^,]+', 1,8), '''') gbl_dntl_rule_deduct,
                 SUBSTR(REPLACE(REGEXP_SUBSTR(extractvalue(pr.prod_policy_rule,'/clauses/clause/coverage/condition[@id="cnd.20.1.2"]/@dynValue'),'[^,]+', 1,10), ''''), 1, 2) gbl_dntl_rule_mode,
                 pa.pat_auth_seq_id, pa.claim_seq_id, pa.member_seq_id,
                 c.coverage_pay_val
                 
          FROM pat_authorization_details pa
          JOIN tpa_enr_policy pol ON (pol.policy_seq_id = pa.policy_seq_id)
          JOIN tpa_ins_product prd ON (prd.product_seq_id = pol.product_seq_id)
          JOIN tpa_ins_prod_policy po ON (po.product_seq_id = prd.product_seq_id)
          JOIN tpa_ins_prod_policy_rules pr ON (pr.prod_policy_seq_id = po.prod_policy_seq_id)
          JOIN tpa_ins_prod_pol_clauses B   ON b.prod_policy_rule_seq_id = pr.prod_policy_rule_seq_id
          JOIN tpa_ins_prod_pol_coverages C    ON (b.clause_seq_id = c.clause_seq_id)
          JOIN tpa_ins_prod_pol_conditions D   ON (c.coverage_seq_id = d.coverage_seq_id)
          where B.prod_policy_rule_seq_id=v_prod_seq_id
          AND d.cond_val = 'A|'||'D0150'
          AND pa.member_seq_id = v_mem_seq_id
          AND pa.benifit_type = 'DNTL'
          AND pa.claim_seq_id IS NULL
          and b.clause_id NOT IN ('cls.1','cls.28') 
         ) r

     FULL JOIN ( 
          SELECT REPLACE(REGEXP_SUBSTR(extractvalue(pr.prod_policy_rule,'/clauses/clause/coverage/condition[@id="cnd.20.1.2"]/@dynValue'),'[^,]+', 1,3), '''') gbl_dntl_rule_limit,
                 REPLACE(REGEXP_SUBSTR(extractvalue(pr.prod_policy_rule,'/clauses/clause/coverage/condition[@id="cnd.20.1.2"]/@dynValue'),'[^,]+', 1,2), '''') gbl_dntl_rule_cond,
                 REPLACE(REGEXP_SUBSTR(extractvalue(pr.prod_policy_rule,'/clauses/clause/coverage/condition[@id="cnd.20.1.2"]/@dynValue'),'[^,]+', 1,6), '''') gbl_dntl_rule_copay,
                 REPLACE(REGEXP_SUBSTR(extractvalue(pr.prod_policy_rule,'/clauses/clause/coverage/condition[@id="cnd.20.1.2"]/@dynValue'),'[^,]+', 1,8), '''') gbl_dntl_rule_deduct,
                 SUBSTR(REPLACE(REGEXP_SUBSTR(extractvalue(pr.prod_policy_rule,'/clauses/clause/coverage/condition[@id="cnd.20.1.2"]/@dynValue'),'[^,]+', 1,10), ''''), 1, 2) gbl_dntl_rule_mode,
                 cl.pat_auth_seq_id, cl.claim_seq_id, cl.member_seq_id,
                 c.coverage_pay_val
                 
          FROM clm_authorization_details cl
          JOIN tpa_enr_policy pol ON (pol.policy_seq_id = cl.policy_seq_id)
          JOIN tpa_ins_product prd ON (prd.product_seq_id = pol.product_seq_id)
          JOIN tpa_ins_prod_policy po ON (po.product_seq_id = prd.product_seq_id)
          JOIN tpa_ins_prod_policy_rules pr ON (pr.prod_policy_seq_id = po.prod_policy_seq_id)
          JOIN tpa_ins_prod_pol_clauses B   ON b.prod_policy_rule_seq_id = pr.prod_policy_rule_seq_id
          JOIN tpa_ins_prod_pol_coverages C    ON (b.clause_seq_id = c.clause_seq_id)
          JOIN tpa_ins_prod_pol_conditions D   ON (c.coverage_seq_id = d.coverage_seq_id)  
          where B.prod_policy_rule_seq_id=v_prod_seq_id
          AND d.cond_val = 'A|'||'D0150'
          AND cl.benifit_type = 'DNTL'
          AND cl.member_seq_id = v_mem_seq_id
          AND cl.benifit_type = 'DNTL'
          and b.clause_id NOT IN ('cls.1','cls.28') 
        ) s
    ON (r.claim_seq_id = s.claim_seq_id)
    WHERE (v_request_type = 'P' AND r.pat_auth_seq_id = nvl(v_seq_id, 0)
      OR v_request_type = 'C' AND s.claim_seq_id = nvl(v_seq_id, 0));
      
  gbl_dntl_limit_rec           gbl_dntl_limit_cur%ROWTYPE;
  
  --- Total Approved Amount for Previous Claim/ Preauth (PP)
  CURSOR tot_prev_appr_cur(v_mem_seq_id NUMBER, v_request_type VARCHAR2) IS
    SELECT SUM(NVL(r.appr_amt, s.appr_amt)) as tot_appr_amt
    FROM (
          SELECT pa.tot_approved_amount AS appr_amt, pa.member_seq_id, pa.pat_auth_seq_id, pa.claim_seq_id
          FROM pat_authorization_details pa
          left outer join app.clm_authorization_details x on (pa.pat_auth_seq_id = x.pat_auth_seq_id)  -----PROD FIXING 
          WHERE pa.member_seq_id = v_mem_seq_id
          AND PA.PAT_ENHANCED_YN = 'N' ------NEWLY ADDED FOR PREAUTH ENHANCEMENT
          AND pa.pat_status_type_id IN ('INP', 'APR', 'REQ')
          AND pa.benifit_type = 'DNTL'
          AND (pa.claim_seq_id IS NULL OR (pa.claim_seq_id IS NOT NULL AND x.clm_status_type_id IN ('INP', 'REQ') AND pa.claim_seq_id != v_seq_id))-- Fixing for used amount
         )r
               
    FULL JOIN (SELECT cl.tot_approved_amount AS appr_amt, cl.member_seq_id, cl.pat_auth_seq_id, cl.claim_seq_id   -----PROD FIXING 
               FROM clm_authorization_details cl
               WHERE cl.member_seq_id = v_mem_seq_id
               AND cl.clm_status_type_id IN ('INP', 'APR', 'REQ')
               AND cl.benifit_type = 'DNTL'
               AND (cl.PAT_AUTH_SEQ_ID IS NULL OR (cl.PAT_AUTH_SEQ_ID IS NOT NULL AND cl.clm_status_type_id = 'APR'))-- Fixing for used amount
              )s
    ON (r.claim_seq_id = s.claim_seq_id)
    WHERE (v_request_type = 'P' AND nvl(r.pat_auth_seq_id, 0) != nvl(v_seq_id, 0)
    OR v_request_type = 'C' AND nvl(s.claim_seq_id, 0) != nvl(v_seq_id, 0));
    
  tot_prev_appr_rec              tot_prev_appr_cur%ROWTYPE;
  -----
  CURSOR pat_act_limit_cur IS
    Select p.benifit_type,
           p.benefit_limit,
           p.member_seq_id,
           'P' as request_type
    
    From pat_authorization_details p
    Where p.pat_auth_seq_id = v_seq_id;
    
  CURSOR clm_act_limit_cur IS
    Select c.benifit_type,
           c.benefit_limit,
           c.member_seq_id,
           'C' as request_type
    
    From clm_authorization_details c
    Where c.claim_seq_id = v_seq_id;
    
  act_limit_rec          clm_act_limit_cur%ROWTYPE;
BEGIN
  IF v_flag = 'PAT' THEN
    OPEN chk_pat_enroll_cur;
    FETCH chk_pat_enroll_cur INTO v_enroll_type;
    CLOSE chk_pat_enroll_cur;
        
    OPEN pat_act_limit_cur;
    FETCH pat_act_limit_cur INTO act_limit_rec;
    CLOSE pat_act_limit_cur;
  ELSE
    OPEN chk_clm_enroll_cur;
    FETCH chk_clm_enroll_cur INTO v_enroll_type;
    CLOSE chk_clm_enroll_cur;
    
    OPEN clm_act_limit_cur;
    FETCH clm_act_limit_cur INTO act_limit_rec;
    CLOSE clm_act_limit_cur;
  END IF;
  
  IF v_enroll_type = 'COR' THEN
    OPEN gbl_dntl_limit_cur(act_limit_rec.member_seq_id, act_limit_rec.request_type);
    FETCH gbl_dntl_limit_cur INTO gbl_dntl_limit_rec;
    CLOSE gbl_dntl_limit_cur;
  ELSE
    OPEN ind_gbl_dntl_limit_cur(act_limit_rec.member_seq_id, act_limit_rec.request_type);
    FETCH ind_gbl_dntl_limit_cur INTO gbl_dntl_limit_rec;
    CLOSE ind_gbl_dntl_limit_cur;
  END IF;
  
  OPEN tot_prev_appr_cur(act_limit_rec.member_seq_id, act_limit_rec.request_type);
  FETCH tot_prev_appr_cur INTO tot_prev_appr_rec;
  CLOSE tot_prev_appr_cur;
  
  gbl_dntl_limit_rec.gbl_dntl_rule_limit := case when gbl_dntl_limit_rec.coverage_pay_val = 2 then 0 else gbl_dntl_limit_rec.gbl_dntl_rule_limit end;
  
  IF gbl_dntl_limit_rec.gbl_dntl_rule_mode = 'PC' THEN
    v_appr_limit := gbl_dntl_limit_rec.gbl_dntl_rule_limit;
  ELSIF gbl_dntl_limit_rec.gbl_dntl_rule_mode = 'PP' THEN
    v_appr_limit := case when gbl_dntl_limit_rec.gbl_dntl_rule_limit - NVL(tot_prev_appr_rec.tot_appr_amt, 0) > 0 then
                           gbl_dntl_limit_rec.gbl_dntl_rule_limit - NVL(tot_prev_appr_rec.tot_appr_amt, 0)
                         when gbl_dntl_limit_rec.gbl_dntl_rule_limit - NVL(tot_prev_appr_rec.tot_appr_amt, 0) <= 0 then
                           0
                    end;
  ELSE
    v_appr_limit := gbl_dntl_limit_rec.gbl_dntl_rule_limit;
  END IF; 
  
  IF v_flag = 'PAT' THEN
    UPDATE pat_authorization_details pa
    Set pa.benefit_limit = NVL(v_appr_limit, pa.benefit_limit),
        pa.benefit_copay = NVL(gbl_dntl_limit_rec.gbl_dntl_rule_copay, pa.benefit_copay),
        pa.deductable = NVL(gbl_dntl_limit_rec.gbl_dntl_rule_deduct, pa.deductable)
    Where pa.pat_auth_seq_id = v_seq_id;
    
    UPDATE pat_activity_details p
    Set p.denial_code = case when gbl_dntl_limit_rec.coverage_pay_val = 2 then
                              case when p.denial_code is null then 'NCOV-SER-003' 
                                else case when p.denial_code like '%'||'NCOV-SER-003'||'%' then p.denial_code else p.denial_code||';'||'NCOV-SER-003' end end else p.denial_code  end ,
                           
    p.denial_desc = case when gbl_dntl_limit_rec.coverage_pay_val = 2 then
                             case when p.denial_desc is null then 'Service(s) is (are) not covered' 
                               else case when p.denial_code like '%'||'NCOV-SER-003'||'%'   then p.denial_desc else p.denial_desc||';'||'Service(s) is (are) not covered' end end else p.denial_desc end, 
                             
    p.tpa_denial_code = case when gbl_dntl_limit_rec.coverage_pay_val = 2 then
                              case when p.tpa_denial_code is null then 'NCOV-SER-003' 
                                else case when p.tpa_denial_code like '%'||'NCOV-SER-003'||'%' then p.tpa_denial_code else p.tpa_denial_code||';'||'NCOV-SER-003' end end else p.tpa_denial_code end ,
                           
    p.tpa_denial_desc = case when gbl_dntl_limit_rec.coverage_pay_val = 2 then
                             case when p.tpa_denial_desc is null then 'Service(s) is (are) not covered' 
                               else case when p.tpa_denial_code like '%'||'NCOV-SER-003'||'%'   then p.tpa_denial_desc else p.tpa_denial_desc||';'||'Service(s) is (are) not covered' end end else p.tpa_denial_desc end, 
                             
    p.rule_limit = case when p.code in (select pa.code
                                          from pat_activity_details pa
                                          where not exists(select d.cdt_code from dental_rule_tab d
                                                           where d.cdt_code = pa.code)
                                         ) then to_number(gbl_dntl_limit_rec.gbl_dntl_rule_limit) else p.rule_limit end
                        
    Where p.pat_auth_seq_id = v_seq_id;
  ELSE
    UPDATE clm_authorization_details cl
    Set cl.benefit_limit = NVL(v_appr_limit, cl.benefit_limit),
        cl.benefit_copay = NVL(gbl_dntl_limit_rec.gbl_dntl_rule_copay, cl.benefit_copay),
        cl.deductable = NVL(gbl_dntl_limit_rec.gbl_dntl_rule_deduct, cl.deductable)
    Where cl.claim_seq_id = v_seq_id;
    
    UPDATE pat_activity_details p
    Set p.denial_code = case when gbl_dntl_limit_rec.coverage_pay_val = 2 then
                              case when p.denial_code is null then 'NCOV-SER-003' 
                                else case when p.denial_code like '%'||'NCOV-SER-003'||'%' then p.denial_code else p.denial_code||';'||'NCOV-SER-003' end end else p.denial_code end ,
                           
       p.denial_desc = case when gbl_dntl_limit_rec.coverage_pay_val = 2 then
                             case when p.denial_desc is null then 'Service(s) is (are) not covered' 
                               else case when p.denial_code like '%'||'NCOV-SER-003'||'%'   then p.denial_desc else p.denial_desc||';'||'Service(s) is (are) not covered' end end else p.denial_desc end, 
                             
       p.tpa_denial_code = case when gbl_dntl_limit_rec.coverage_pay_val = 2 then
                              case when p.tpa_denial_code is null then 'NCOV-SER-003' 
                                else case when p.tpa_denial_code like '%'||'NCOV-SER-003'||'%' then p.tpa_denial_code else p.tpa_denial_code||';'||'NCOV-SER-003' end end else p.tpa_denial_code end ,
                           
       p.tpa_denial_desc = case when gbl_dntl_limit_rec.coverage_pay_val = 2 then
                             case when p.tpa_denial_desc is null then 'Service(s) is (are) not covered' 
                               else case when p.tpa_denial_code like '%'||'NCOV-SER-003'||'%' then p.tpa_denial_desc else p.tpa_denial_desc||';'||'Service(s) is (are) not covered' end end else tpa_denial_desc end, 
                      
       p.rule_limit = case when p.code in (select pa.code
                                          from pat_activity_details pa
                                          where not exists(select d.cdt_code from dental_rule_tab d
                                                           where d.cdt_code = pa.code)
                                         ) then to_number(gbl_dntl_limit_rec.gbl_dntl_rule_limit) else p.rule_limit end
                        
    Where p.claim_seq_id = v_seq_id;
    
  END IF;
  
END check_overal_limit;
--======================================================================================================
PROCEDURE check_pat_limit(p_clm_seq_id IN NUMBER,
                          V_HOSP_NAME  IN VARCHAR2)
AS
  CURSOR act_exclude_cur IS
    select master_activity_code,code,activity_dtl_seq_id,approved_amount from  (Select DISTINCT nvl(g.master_activity_code,m.master_activity_code) as master_activity_code,pa.code, pa.activity_dtl_seq_id, nvl(pa.approved_amount, 0) as approved_amount,nvl(g.service_seq_id,m.service_seq_id) as service_seq_id
    From pat_activity_details pa
    Join clm_authorization_details cl ON (cl.claim_seq_id = pa.claim_seq_id)
    left join tpa_activity_details g ON (pa.CODE = g.ACTIVITY_CODE)
    left join tpa_activity_master_details m  ON( pa.code = m.activity_code)
    Where cl.claim_seq_id = p_clm_seq_id) tamd where tamd.master_activity_code not in ('9','9.01','63') and (tamd.service_seq_id not in(14) and tamd.master_activity_code !='0000-000000-0000')
    Order by tamd.activity_dtl_seq_id;
    
    CURSOR act_cur IS
    Select pa.code, pa.activity_dtl_seq_id, nvl(pa.approved_amount, 0) as approved_amount
    From pat_activity_details pa
    Join clm_authorization_details cl ON (cl.claim_seq_id = pa.claim_seq_id)
    Where cl.claim_seq_id = p_clm_seq_id
    Order by pa.activity_dtl_seq_id;
    
  CURSOR pat_limit_cur IS
    Select nvl(c.pat_approved_amount, 0) as pat_approved_amount,
           nvl(c.benefit_limit, c.ava_sum_insured) as benefit_limit
           
    From clm_authorization_details c
    Where c.claim_seq_id = p_clm_seq_id;
    
  CURSOR tot_approved_cur IS
    Select sum(p.approved_amount) as tot_approved_amount
    
    From pat_activity_details p
    Where p.claim_seq_id = p_clm_seq_id;

  cursor service_activities_sum_cur is--- This is to find the amount requested apart from consultation and drugs codes
  
  select sum(pad.approved_amount)total_amount from  pat_activity_details pad join pat_authorization_Details pat on ( pad.pat_auth_seq_id= pat.pat_auth_seq_id)
                                                             left outer join APP.TPA_ACTIVITY_details tad on (pad.code=tad.activity_code)
                                                             left outer join APP.TPA_ACTIVITY_MASTER_DETAILS tamd on (pad.code= tamd.activity_code)
                                                             WHERE (NVL(tad.MASTER_ACTIVITY_CODE,tamd.master_activity_code)  IN('9','9.01','63')
                                                                  or  (NVL(tad.service_seq_id,tamd.service_seq_id)  IN (14) and NVL(tad.MASTER_ACTIVITY_CODE,tamd.master_activity_code) ='0000-000000-0000'))
                                                                  AND pad.pat_auth_seq_id= (select pat_auth_seq_id from clm_authorization_details clm 
                                                                                                   where clm.claim_seq_id=p_clm_seq_id);
  service_activities_sum_rec service_activities_sum_cur%rowtype;
  
  
  CURSOR enrol_type IS
  select ep.enrol_type_id,ep.policy_seq_id,pm.vip_yn,(ad.requested_amount-nvl(ad.tot_patient_share_amount,0)) as net_amount 
  from app.tpa_enr_policy ep 
  join app.clm_authorization_details ad on (ep.policy_seq_id=ad.policy_seq_id)
  join app.tpa_enr_policy_member pm on (pm.member_seq_id = ad.member_seq_id)
  where ad.claim_seq_id= p_clm_seq_id;  


  enrol_rec                  enrol_type%rowtype;
  
      CURSOR cur_corp_pol(vip_yn varchar2) IS
   SELECT case when nvl(vip_yn,'N')='Y' then gt.vip_pre_aprvl_limit_yn else gt.non_vip_pre_aprvl_limit_yn end as pre_aprvl_limit_yn,
          case when nvl(vip_yn,'N')='Y' then gt.vip_pre_aprvl_limit else gt.non_vip_pre_aprvl_limit end as pre_aprvl_limit,
          case when nvl(vip_yn,'N')='Y' then gt.vip_mdt_srvce_pre_aprvl_yn else gt.non_vip_mdt_srvce_pre_aprvl_yn end as pre_aprvl_mdt_srvc_yn  
        FROM tpa_enr_policy GH
        JOIN tpa_ins_prod_policy GT ON (GH.policy_seq_id=GT.policy_seq_id)
     WHERE GH.policy_seq_id=enrol_rec.policy_seq_id;

     
  CURSOR cur_ind_pol(vip_yn varchar2) IS   
     SELECT case when nvl(vip_yn,'N')='Y' then tipp.vip_pre_aprvl_limit_yn else tipp.non_vip_pre_aprvl_limit_yn end as pre_aprvl_limit_yn,
            case when nvl(vip_yn,'N')='Y' then tipp.vip_pre_aprvl_limit else tipp.non_vip_pre_aprvl_limit end as pre_aprvl_limit,
            case when nvl(vip_yn,'N')='Y' then tipp.vip_mdt_srvce_pre_aprvl_yn else tipp.non_vip_mdt_srvce_pre_aprvl_yn end as pre_aprvl_mdt_srvc_yn
     FROM tpa_enr_policy tep
     LEFT OUTER JOIN tpa_ins_product tip on (tip.product_seq_id=tep.product_seq_id)
     LEFT OUTER JOIN tpa_ins_prod_policy tipp on (tipp.product_seq_id=tip.product_seq_id)
     WHERE tep.policy_seq_id=enrol_rec.policy_seq_id; 
  
  v_approved_amount      NUMBER(12,3);  
  pat_limit_rec          pat_limit_cur%ROWTYPE;
  v_pat_apr_amount       NUMBER(15,3);
  v_act_apr_amount       NUMBER(15,3);
  v_remain_limit         NUMBER(15,3) := 0;
  v_pat_amount           NUMBER(15,3) := 0;
  v_pre_approval_limit_yn    varchar2(1);
  v_pre_approval_limit       number(10);
  v_pre_aprvl_mdt_srvc_yn    varchar2(1);
 BEGIN
  OPEN pat_limit_cur;
  FETCH pat_limit_cur INTO pat_limit_rec;
  CLOSE pat_limit_cur;
  
    OPEN enrol_type;
    FETCH enrol_type INTO enrol_rec;
    CLOSE enrol_type;
  
    IF enrol_rec.policy_seq_id IS NOT NULL THEN  
       IF enrol_rec.enrol_type_id='COR' THEN
         OPEN  cur_corp_pol(enrol_rec.vip_yn);
         FETCH cur_corp_pol INTO v_pre_approval_limit_yn,v_pre_approval_limit,v_pre_aprvl_mdt_srvc_yn;
         CLOSE cur_corp_pol;
       ELSE
         OPEN  cur_ind_pol(enrol_rec.vip_yn);
         FETCH cur_ind_pol INTO v_pre_approval_limit_yn,v_pre_approval_limit,v_pre_aprvl_mdt_srvc_yn;
         CLOSE cur_ind_pol;
       END IF;
     END IF;   
  
  IF NVL(v_pre_approval_limit_yn,'N')='Y' THEN
  
  OPEN service_activities_sum_cur;
  FETCH service_activities_sum_cur INTO service_activities_sum_rec;
  CLOSE service_activities_sum_cur;
  
  v_pat_amount :=(pat_limit_rec.pat_approved_amount)- nvl(service_activities_sum_rec.total_amount,0);
  for i in act_exclude_cur loop
    v_pat_amount := case when V_HOSP_NAME = '%ALAHLIHOSPITAL%' THEN nvl(pat_limit_rec.benefit_limit,0) else v_pat_amount end;
    v_pat_apr_amount := case when v_pat_amount - v_remain_limit > 0 then v_pat_amount - v_remain_limit else 0 end;
    IF i.approved_amount > v_pat_apr_amount THEN
      v_act_apr_amount := v_pat_apr_amount;
    ELSE
      v_act_apr_amount := i.approved_amount;
    END IF;
    v_remain_limit := v_remain_limit + v_act_apr_amount;
    ---
    UPDATE pat_activity_details pa
    SET pa.approved_amount = case when v_act_apr_amount > 0 then v_act_apr_amount else 0 end,
        pa.allowed_amount = case when v_act_apr_amount > 0 then v_act_apr_amount else 0 end,
        pa.remarks =  case when v_pat_apr_amount < i.approved_amount then case when pa.remarks is  null then 'The claimed amount is more than the allowed limit as per  policy benefits.Hence the amount over and above the allowed limit is disallowed' else case when pa.denial_code like '%BENX-005%'then pa.remarks else pa.remarks||';'||'The claimed amount is more than the allowed limit as per  policy benefits.Hence the amount over and above the allowed limit is disallowed' end end else pa.remarks end,
        pa.denial_desc = case when v_pat_apr_amount < i.approved_amount then  case when pa.denial_desc is  null then 'Preapproval limit/sublimit amount exceeded' else case when pa.denial_code like '%BENX-005%'then pa.denial_desc else pa.denial_desc||';'||'Preapproval limit/sublimit amount exceeded' end end else pa.denial_desc end,
        pa.denial_code = case when v_pat_apr_amount < i.approved_amount then case when pa.denial_code is  null then 'BENX-005' else case when pa.denial_code like '%BENX-005%'then pa.denial_code else pa.denial_code||';'||'BENX-005' end end else pa.denial_code end,
        pa.denial_by_rule_proc_dtls = case when v_pat_apr_amount < i.approved_amount or (pa.approved_amount = 0) then
                                                        TRIM(BOTH ';' FROM (pa.denial_by_rule_proc_dtls||';'||CHR(10)||'authorization_pkg.check_pat_limit'))
                                                   else pa.denial_by_rule_proc_dtls end,
        pa.denial_by_resons  = TRIM(BOTH ';' FROM (pa.denial_by_resons||';'||CHR(10)||'preapproval limit exhausted'))		
            
    WHERE pa.activity_dtl_seq_id = i.activity_dtl_seq_id;
      ----
  end loop;
  
  ELSE
       for i in act_cur loop
    pat_limit_rec.pat_approved_amount := case when V_HOSP_NAME = '%ALAHLIHOSPITAL%' THEN nvl(pat_limit_rec.benefit_limit,0) else pat_limit_rec.pat_approved_amount end;
    v_pat_apr_amount := case when pat_limit_rec.pat_approved_amount - v_remain_limit > 0 then pat_limit_rec.pat_approved_amount - v_remain_limit else 0 end;
    IF i.approved_amount > v_pat_apr_amount THEN
      v_act_apr_amount := v_pat_apr_amount;
    ELSE
      v_act_apr_amount := i.approved_amount;
    END IF;
    v_remain_limit := v_remain_limit + v_act_apr_amount;
    ---
    UPDATE pat_activity_details pa
    SET pa.approved_amount = case when v_act_apr_amount > 0 then v_act_apr_amount else 0 end,
        pa.allowed_amount = case when v_act_apr_amount > 0 then v_act_apr_amount else 0 end,
        pa.remarks =  case when v_pat_apr_amount < i.approved_amount then case when pa.remarks is  null then 'The claimed amount is more than the allowed limit as per  policy benefits.Hence the amount over and above the allowed limit is disallowed' else case when pa.denial_code like '%BENX-005%'then pa.remarks else pa.remarks||';'||'The claimed amount is more than the allowed limit as per  policy benefits.Hence the amount over and above the allowed limit is disallowed' end end else pa.remarks end,
        pa.denial_desc = case when v_pat_apr_amount < i.approved_amount then  case when pa.denial_desc is  null then 'Preapproval limit/sublimit amount exceeded' else case when pa.denial_code like '%BENX-005%'then pa.denial_desc else pa.denial_desc||';'||'Preapproval limit/sublimit amount exceeded' end end else pa.denial_desc end,
        pa.denial_code = case when v_pat_apr_amount < i.approved_amount then case when pa.denial_code is  null then 'BENX-005' else case when pa.denial_code like '%BENX-005%'then pa.denial_code else pa.denial_code||';'||'BENX-005' end end else pa.denial_code end,
        pa.denial_by_rule_proc_dtls = case when v_pat_apr_amount < i.approved_amount or (pa.approved_amount = 0) then
                                                        TRIM(BOTH ';' FROM (pa.denial_by_rule_proc_dtls||';'||CHR(10)||'authorization_pkg.check_pat_limit'))
                                                   else pa.denial_by_rule_proc_dtls end,
        pa.denial_by_resons  =case when v_pat_apr_amount < i.approved_amount then  TRIM(BOTH ';' FROM (pa.denial_by_resons||';'||CHR(10)||'preapproval limit exhausted'))	else pa.denial_by_resons end	
            
    WHERE pa.activity_dtl_seq_id = i.activity_dtl_seq_id;
      ----
  end loop;
  
  END IF;
  
  OPEN tot_approved_cur;
  FETCH tot_approved_cur INTO v_approved_amount;
  CLOSE tot_approved_cur;
  
  UPDATE Clm_Authorization_Details c
  Set c.tot_approved_amount = nvl(v_approved_amount,0),
      c.tot_allowed_amount = nvl(v_approved_amount,0),
      c.converted_final_approved_amt = nvl(v_approved_amount,0),
      c.final_app_amount = nvl(v_approved_amount,0),
      c.pay_amt_in_usd = nvl(v_approved_amount,0) / 3.64
  Where c.claim_seq_id = p_clm_seq_id;
  
END check_pat_limit;
--=======================================================================================
PROCEDURE Provider_Benifit_eligibility (v_seq_id             IN    NUMBER,
                                        v_mode               IN    VARCHAR2,
                                        v_benifit_type       IN    VARCHAR2,
                                        v_hosp_seq_id        IN    NUMBER,
                                        v_policy_seq_id      IN    NUMBER)
                                        
AS
CURSOR benifit_eligibility IS
  SELECT WM_CONCAT(A.BENIFIT_TYPE) FROM
  (SELECT DISTINCT HC.BENIFIT_TYPE 
   FROM TPA_ENR_POLICY ENR 
   JOIN TPA_INS_PROD_HOSP_COPAY HC ON (ENR.POLICY_SEQ_ID=HC.POLICY_SEQ_ID)
   JOIN tpa_ins_assoc_prod_hosp ASS ON (ASS.PROD_POLICY_SEQ_ID=HC.PROD_POLICY_SEQ_ID)
   WHERE HC.HOSP_SEQ_ID=v_hosp_seq_id AND HC.POLICY_SEQ_ID=v_policy_seq_id
   and ass.status_general_type_id='ASL' AND ass.hosp_seq_id=v_hosp_seq_id) A;
   
v_elig_benfits         VARCHAR2(32000);
BEGIN
  
OPEN benifit_eligibility;
     FETCH benifit_eligibility INTO v_elig_benfits;
       CLOSE benifit_eligibility;

IF v_elig_benfits IS NOT NULL THEN
  IF  ',' ||v_elig_benfits ||',' LIKE ',%' ||v_benifit_type||',%' THEN
    NULL;
  ELSE
      IF v_mode='PAT' THEN        
          UPDATE PAT_ACTIVITY_DETAILS PAD
           SET PAD.ALLOWED_AMOUNT=0,
               PAD.APPROVED_AMOUNT=0,
               PAD.DENIAL_CODE='ELIG-008',
               PAD.DENIAL_DESC='Provider is not covered for given Benifit type'
          WHERE PAD.PAT_AUTH_SEQ_ID=v_seq_id;
          
       ELSIF  v_mode='CLM' THEN 
       
          UPDATE PAT_ACTIVITY_DETAILS PAD
           SET PAD.ALLOWED_AMOUNT=0,
               PAD.APPROVED_AMOUNT=0,
               PAD.DENIAL_CODE='ELIG-008',
               PAD.DENIAL_DESC='Provider is not covered for given Benifit type'
          WHERE PAD.CLAIM_SEQ_ID=v_seq_id;
          
      END IF;
  END IF;
END IF;

END;                                        
--=======================================================================================================
PROCEDURE Act_Detls_for_override_case (v_seq_id   IN 	  NUMBER,
                                       v_mode     IN    VARCHAR2,
                                       v_act_code IN    VARCHAR2,
                                       v_int_code IN    VARCHAR2,
                                       v_st_date  IN    VARCHAR2,
                                       v_result   OUT   SYS_REFCURSOR )
AS

CURSOR pat_hosp_details IS
  SELECT PAD.HOSP_SEQ_ID,PRD.PRODUCT_CAT_TYPE_ID,PAD.INS_SEQ_ID 
         FROM PAT_AUTHORIZATION_DETAILS PAD
         JOIN TPA_ENR_POLICY ENR ON (PAD.POLICY_SEQ_ID=ENR.POLICY_SEQ_ID)
         JOIN TPA_INS_PRODUCT PRD ON (ENR.PRODUCT_SEQ_ID=PRD.PRODUCT_SEQ_ID) 
         WHERE PAD.PAT_AUTH_SEQ_ID=V_SEQ_ID;
         
CURSOR clm_hosp_details IS
  SELECT CHP.HOSP_SEQ_ID,PRD.PRODUCT_CAT_TYPE_ID,CLM.INS_SEQ_ID 
         FROM CLM_AUTHORIZATION_DETAILS CLM
         JOIN CLM_HOSPITAL_DETAILS CHP ON (CLM.CLAIM_SEQ_ID=CHP.CLAIM_SEQ_ID)
         JOIN TPA_ENR_POLICY ENR ON (CLM.POLICY_SEQ_ID=ENR.POLICY_SEQ_ID)
         JOIN TPA_INS_PRODUCT PRD ON (ENR.PRODUCT_SEQ_ID=PRD.PRODUCT_SEQ_ID) 
         WHERE CLM.CLAIM_SEQ_ID=V_SEQ_ID;         

v_hosp_seq_id     NUMBER(10);
v_mem_net_type    VARCHAR2(5);
v_ins_seq_id      NUMBER(10);
BEGIN
 
IF v_mode='PAT' THEN
  
OPEN  pat_hosp_details;
  FETCH pat_hosp_details INTO v_hosp_seq_id,v_mem_net_type,v_ins_seq_id;
  CLOSE pat_hosp_details;
  
  IF v_act_code IS NOT NULL AND v_int_code IS NOT NULL THEN
      OPEN v_result FOR
              select
               thtd.gross_amount AS UNIT_PRICE,
               thtd.gross_amount,
               thtd.disc_amount,
               thtd.disc_amount as unit_discount,
               thtd.gross_amount- thtd.disc_amount as disc_gross_amount,
               thtd.bundle_id,
               thtd.package_id,
               thtd.internal_code as internal_code,
               tamd.act_mas_dtl_seq_id as activity_seq_id,
               tamd.activity_code as activity_code,
               tamd.activity_description,
               tatc.activity_type_seq_id,
               tatc.activity_type_id,
               NULL as req_quantity,
               NVL(d.tooth_no_required, 'N') as tooth_req_yn,
               thtd.internal_desc,
               PAT.QUANTITY as QUANTITY,
               PAT.APPROVD_QUANTITY as APPROVED_QUANTITY,
                NULL as OVERRIDE_REMARKS,
                NULL as UNIT_TYPE,
               PAT.POSOLOGY_DURATION as POSOLOGY_DURATION,
               PAT.TOOTH_NO,
               NULL AS MEM_SERVICE_CODE,
               NULL AS MEM_SERVICE_DESC
        from PAT_AUTHORIZATION_DETAILS pad
        JOIN PAT_ACTIVITY_DETAILS PAT ON (PAD.PAT_AUTH_SEQ_ID=PAT.PAT_AUTH_SEQ_ID)
        JOIN tpa_activity_master_details tamd ON (PAT.CODE=TAMD.ACTIVITY_CODE)
        JOIN tpa_activity_type_codes tatc ON (tamd.activity_type_seq_id=tatc.activity_type_seq_id)
        JOIN tpa_hosp_tariff_details thtd ON (tamd.act_mas_dtl_seq_id=thtd.activity_seq_id)
        LEFT JOIN dental_rule_tab d ON (d.cdt_code = tamd.activity_code)
        WHERE thtd.hosp_seq_id=v_hosp_seq_id
        AND thtd.ins_seq_id=v_ins_seq_id
        AND thtd.network_type IN (
                                  SELECT general_type_id FROM tpa_general_code 
                                  WHERE HEADER_TYPE = 'PROVIDER_NETWORK' AND  SORT_NO >= 
                                 (
                                  SELECT SORT_NO FROM tpa_general_code A  
                                  WHERE A.GENERAL_TYPE_ID = UPPER(v_mem_net_type)
                                 ))--v_mem_net_type--pat_rec.product_cat_type_id
        AND v_st_date BETWEEN  thtd.start_date AND NVL(thtd.end_date,v_st_date)
        AND UPPER(thtd.internal_code) = upper(v_int_code);  
  ELSIF v_act_code IS NOT NULL AND v_int_code IS NULL THEN
        OPEN v_result FOR
        SELECT PAT.CODE AS ACTIVITY_CODE,
               PAT.GROSS_AMOUNT,
               PAT.DISCOUNT_AMOUNT as disc_amount,
               PAT.DISC_GROSS_AMOUNT,
               PAT.UNIT_DISCOUNT_AMOUNT as unit_discount,
               PAT.CONVERTED_ACITIVTY_AMT,
               MAS.ACTIVITY_DESCRIPTION,
               MAS.ACT_MAS_DTL_SEQ_ID AS activity_seq_id, 
               ACTT.ACTIVITY_TYPE_SEQ_ID AS activity_type_seq_id,
               ACTT.ACTIVITY_TYPE_ID,
               PAT.UNIT_PRICE,
               PAT.QUANTITY,
               PAT.APPROVD_QUANTITY AS APPROVED_QUANTITY,
               PAT.UNIT_TYPE,
               PAT.POSOLOGY_DURATION,
               PAT.OVERRIDE_REMARKS,
               NULL AS internal_code,
               NULL AS internal_desc,
               NULL AS req_quantity,
               NULL AS bundle_id,
               NULL AS package_id,
               PAT.MEM_SERVICE_CODE,
               PAT.MEM_SERVICE_DESC,
               PAT.TOOTH_NO,
              NULL as tooth_req_yn
               
        FROM PAT_AUTHORIZATION_DETAILS PAD
        JOIN PAT_ACTIVITY_DETAILS PAT ON (PAD.PAT_AUTH_SEQ_ID=PAT.PAT_AUTH_SEQ_ID)
        JOIN TPA_ACTIVITY_MASTER_DETAILS MAS ON (PAT.CODE=MAS.ACTIVITY_CODE)
        JOIN TPA_ACTIVITY_TYPE_CODES ACTT ON (MAS.ACTIVITY_TYPE_SEQ_ID=ACTT.ACTIVITY_TYPE_SEQ_ID)
        WHERE PAT.PAT_AUTH_SEQ_ID=v_seq_id AND PAT.CODE=v_act_code;
  ELSE
     OPEN v_result FOR
        SELECT NULL AS ACTIVITY_CODE,
               NULL AS GROSS_AMOUNT,
               NULL AS disc_amount,
               NULL AS DISC_GROSS_AMOUNT,
               NULL AS unit_discount,
               NULL AS CONVERTED_ACITIVTY_AMT,
               NULL AS ACTIVITY_DESCRIPTION,
               NULL AS activity_type_seq_id,
               NULL AS ACTIVITY_TYPE_ID,
               NULL AS internal_code,
               NULL AS internal_desc,
               NULL AS req_quantity,
               NULL AS bundle_id,
               NULL AS package_id,
               NULL AS UNIT_PRICE,
               NULL as QUANTITY,
               NULL as APPROVD_QUANTITY,
               NULL as OVERRIDE_REMARKS,
               NULL as UNIT_TYPE,
               NULL as POSOLOGY_DURATION
        FROM DUAL;
  
  END IF;
ELSIF v_mode='CLM' THEN

OPEN  clm_hosp_details;
  FETCH clm_hosp_details INTO v_hosp_seq_id,v_mem_net_type,v_ins_seq_id;
  CLOSE clm_hosp_details;
  
IF v_act_code IS NOT NULL AND v_int_code IS NOT NULL THEN
      OPEN v_result FOR
              select
               thtd.gross_amount AS UNIT_PRICE,
               thtd.gross_amount,
               thtd.disc_amount,
               thtd.disc_amount as unit_discount,
               thtd.gross_amount- thtd.disc_amount as disc_gross_amount,
               thtd.bundle_id,
               thtd.package_id,
               thtd.internal_code as internal_code,
               tamd.act_mas_dtl_seq_id as activity_seq_id,
               tamd.activity_code as activity_code,
               tamd.activity_description,
               tatc.activity_type_seq_id,
               tatc.activity_type_id,
               NULL as req_quantity,
               NVL(d.tooth_no_required, 'N') as tooth_req_yn,
               thtd.internal_desc,
               PAT.QUANTITY as QUANTITY,
               PAT.APPROVD_QUANTITY as APPROVED_QUANTITY,
                NULL as OVERRIDE_REMARKS,
                NULL as UNIT_TYPE,
               PAT.POSOLOGY_DURATION as POSOLOGY_DURATION,
               NULL AS MEM_SERVICE_CODE,
               NULL AS MEM_SERVICE_DESC,
               PAT.TOOTH_NO
               
        from CLM_AUTHORIZATION_DETAILS CLM
        JOIN PAT_ACTIVITY_DETAILS PAT ON (CLM.CLAIM_SEQ_ID=PAT.CLAIM_SEQ_ID)
        JOIN tpa_activity_master_details tamd ON (PAT.CODE=TAMD.ACTIVITY_CODE)
        JOIN tpa_activity_type_codes tatc ON (tamd.activity_type_seq_id=tatc.activity_type_seq_id)
        JOIN tpa_hosp_tariff_details thtd ON (tamd.act_mas_dtl_seq_id=thtd.activity_seq_id)
        LEFT JOIN dental_rule_tab d ON (d.cdt_code = tamd.activity_code)
        WHERE thtd.hosp_seq_id=v_hosp_seq_id
        AND thtd.ins_seq_id=v_ins_seq_id
        AND thtd.network_type IN (
                                  SELECT general_type_id FROM tpa_general_code 
                                  WHERE HEADER_TYPE = 'PROVIDER_NETWORK' AND  SORT_NO >= 
                                 (
                                  SELECT SORT_NO FROM tpa_general_code A  
                                  WHERE A.GENERAL_TYPE_ID = UPPER(v_mem_net_type)
                                 ))--v_mem_net_type--pat_rec.product_cat_type_id---=v_mem_net_type--pat_rec.product_cat_type_id
        AND v_st_date BETWEEN  thtd.start_date AND NVL(thtd.end_date,v_st_date)
        AND UPPER(thtd.internal_code) = upper(v_int_code);  
  ELSIF v_act_code IS NOT NULL AND v_int_code IS NULL THEN
        OPEN v_result FOR
        SELECT PAT.CODE AS ACTIVITY_CODE,
               PAT.GROSS_AMOUNT,
               PAT.DISCOUNT_AMOUNT as disc_amount,
               PAT.DISC_GROSS_AMOUNT,
               PAT.UNIT_DISCOUNT_AMOUNT as unit_discount,
               PAT.CONVERTED_ACITIVTY_AMT,
               MAS.ACTIVITY_DESCRIPTION,
               MAS.ACT_MAS_DTL_SEQ_ID AS activity_seq_id, 
               ACTT.ACTIVITY_TYPE_SEQ_ID AS activity_type_seq_id,
               ACTT.ACTIVITY_TYPE_ID,
               PAT.UNIT_PRICE,
               PAT.QUANTITY,
               PAT.APPROVD_QUANTITY AS APPROVED_QUANTITY,
               PAT.UNIT_TYPE,
               PAT.POSOLOGY_DURATION,
               PAT.OVERRIDE_REMARKS,
               NULL AS internal_code,
               NULL AS internal_desc,
               NULL AS req_quantity,
               NULL AS bundle_id,
               NULL AS package_id,
               pat.provider_net_amount,
               pat.mem_service_code,
               pat.mem_service_desc,
               pat.tooth_no,
               NVL(den.tooth_no_required,'N') AS tooth_req_yn
        FROM CLM_AUTHORIZATION_DETAILS CLM
        JOIN PAT_ACTIVITY_DETAILS PAT ON (CLM.CLAIM_SEQ_ID=PAT.CLAIM_SEQ_ID)
        JOIN TPA_ACTIVITY_MASTER_DETAILS MAS ON (PAT.CODE=MAS.ACTIVITY_CODE)
        JOIN TPA_ACTIVITY_TYPE_CODES ACTT ON (MAS.ACTIVITY_TYPE_SEQ_ID=ACTT.ACTIVITY_TYPE_SEQ_ID)
        LEFT OUTER JOIN DENTAL_RULE_TAB DEN on (DEN.CDT_CODE=PAT.CODE)
        WHERE CLM.CLAIM_SEQ_ID=v_seq_id AND PAT.CODE=v_act_code;
  ELSE
     OPEN v_result FOR
        SELECT NULL AS ACTIVITY_CODE,
               NULL AS GROSS_AMOUNT,
               NULL AS disc_amount,
               NULL AS DISC_GROSS_AMOUNT,
               NULL AS unit_discount,
               NULL AS CONVERTED_ACITIVTY_AMT,
               NULL AS ACTIVITY_DESCRIPTION,
               NULL AS activity_type_seq_id,
               NULL AS ACTIVITY_TYPE_ID,
               NULL AS internal_code,
               NULL AS internal_desc,
               NULL AS req_quantity,
               NULL AS bundle_id,
               NULL AS package_id,
               NULL AS UNIT_PRICE,
               NULL as QUANTITY,
               NULL as APPROVD_QUANTITY,
               NULL as OVERRIDE_REMARKS,
               NULL as UNIT_TYPE,
               NULL as POSOLOGY_DURATION,
               NULL as mem_service_code,
               NULL as mem_service_desc,
               NULL as tooth_no,
               NULL as tooth_req_yn
        FROM DUAL;
  
  END IF;
END IF;

END Act_Detls_for_override_case;
--========================================================================================
--Claim Resubmission Limits & Allowed Amount Validations
--Added by Venu Babu
--Added Date 18-05-2018
--======================================================================================================
PROCEDURE Check_Resub_Activity_Limits(v_seq_id           IN    NUMBER,
                                      v_benefit_type     IN    VARCHAR2,
                                      v_added_by         IN    NUMBER)
 AS

CURSOR Parent_claim_seq_id_1 IS
select cc.claim_seq_id
    from clm_authorization_details cc
    where cc.claim_seq_id in
    (select cad.claim_seq_id
    from clm_authorization_details cad 
    start with cad.claim_seq_id=v_seq_id
    connect by cad.claim_seq_id=prior cad.parent_claim_seq_id) and cc.parent_claim_seq_id is null;
               
CURSOR PARENT_ACTIVITY_CODES_MTN(v_actvity_code VARCHAR2,v_p_claim_seq_id VARCHAR2) IS
   select sum(approved_amount) as remain_amt from
   (select distinct pad.activity_dtl_seq_id,pad.approved_amount
    from clm_authorization_details cad
    join pat_activity_details pad on (cad.claim_seq_id=pad.claim_seq_id)
    left outer join tpa_activity_master_details mas on (mas.activity_code=pad.code)
    where level<>1  and mas.master_activity_code=v_actvity_code
    start with cad.claim_seq_id=v_seq_id
    connect by cad.claim_seq_id=prior cad.parent_claim_seq_id);
 
CURSOR Parent_Actvity_Codes_OPIPM(v_par_seq_id 	NUMBER) IS 
select CASE WHEN ((b.req_amount)-sum(a.approved_amount))>0 THEN 
            ((b.req_amount)-sum(a.approved_amount)) ELSE 0 END remain_amt
                 ,a.code FROM 
    (select distinct (pad.approved_amount) as approved_amount ,pad.code
    from clm_authorization_details cad
    join pat_activity_details pad on (cad.claim_seq_id=pad.claim_seq_id)
    left outer join tpa_activity_master_details mas on (mas.activity_code=pad.code)
    where level<>1
    start with cad.claim_seq_id=v_seq_id
    connect by cad.claim_seq_id=prior cad.parent_claim_seq_id
    )a,
    (select  distinct case when nvl(ac.provider_net_amount,0)!=0  and nvl(ac.disc_gross_amount,0)!=0 then
                     least (ac.provider_net_amount,ac.disc_gross_amount) 
                when nvl(ac.provider_net_amount,0)!=0 and nvl(ac.disc_gross_amount,0)!=0 then
                      ac.disc_gross_amount
               else ac.disc_gross_amount end req_amount,ac.code,cc.claim_number
    from clm_authorization_details cc join pat_activity_details ac on (cc.claim_seq_id=ac.claim_seq_id)
    left outer join tpa_activity_master_details mas on (mas.activity_code=ac.code) 
    where CC.claim_seq_id=v_par_seq_id )b
   where a.code=b.code
   GROUP BY a.code,b.req_amount;
 
 CURSOR PARENT_ACTIVITY_CODES_CUN(v_actvity_code VARCHAR2,v_p_claim_seq_id VARCHAR2) IS  
 select sum(req_amount) as remain_amt, sum (rule_limit) as rule_limit
  from (  
    select  case when nvl(ac.provider_net_amount,0)!=0  and nvl(ac.disc_gross_amount,0)!=0 then
                     least (ac.provider_net_amount,ac.disc_gross_amount) 
                when nvl(ac.provider_net_amount,0)=0 and nvl(ac.disc_gross_amount,0)!=0 then
                      ac.disc_gross_amount
               else ac.disc_gross_amount end req_amount,
            nvl(ac.rule_limit,cc.ava_sum_insured)  as rule_limit    
    from clm_authorization_details cc join pat_activity_details ac on (cc.claim_seq_id=ac.claim_seq_id)
    left outer join tpa_activity_master_details mas on (mas.activity_code=ac.code) 
    where CC.claim_seq_id=v_p_claim_seq_id and mas.master_activity_code=v_actvity_code);
    
 CURSOR PARENT_ALLOWED_AMOUNT IS
 SELECT (a.FINAL_ALLOWED_AMOUNT-b.final_app_amount) as FINAL_ALLOWED_AMOUNT
 from 
 (select CASE WHEN cc.converted_amount IS NOT NULL AND cc.pat_approved_amount IS NOT NULL THEN
             LEAST(cc.converted_amount,cc.pat_approved_amount)
             WHEN cc.converted_amount IS NOT NULL AND cc.pat_approved_amount IS NULL THEN
               cc.converted_amount
             END AS FINAL_ALLOWED_AMOUNT,cc.tot_patient_share_amount
    from clm_authorization_details cc 
    join clm_batch_upload_details bt on (cc.clm_batch_seq_id=bt.clm_batch_seq_id)
    where cc.claim_seq_id in (select cad.claim_seq_id
                               from clm_authorization_details cad 
                               start with cad.claim_seq_id=v_seq_id
    connect by cad.claim_seq_id=prior cad.parent_claim_seq_id) and cc.parent_claim_seq_id is null) A,
    (select sum(cad.final_app_amount) as final_app_amount
    from clm_authorization_details cad
    where level<>1 
    start with cad.claim_seq_id=v_seq_id
    connect by cad.claim_seq_id=prior cad.parent_claim_seq_id) B;
    
    
 CURSOR CURRENT_CHILD_ACTIVITY_CODE(V_MASTER_ACT    VARCHAR2) IS
    SELECT PAT.CODE,PAT.APPROVED_AMOUNT,PAT.Activity_Dtl_Seq_Id,PAT.OVERRIDE_YN,
           PAT.OUT_OF_POCKET_AMOUNT,PAT.PROVIDER_NET_AMOUNT
           FROM CLM_AUTHORIZATION_DETAILS CAD
           JOIN PAT_ACTIVITY_DETAILS PAT ON (CAD.CLAIM_SEQ_ID=PAT.CLAIM_SEQ_ID)
           LEFT OUTER JOIN DENTAL_RULE_TAB DEN ON (DEN.CDT_CODE=PAT.CODE)
           LEFT OUTER JOIN TPA_ACTIVITY_MASTER_DETAILS MAS ON (PAT.CODE=MAS.ACTIVITY_CODE)
           WHERE PAT.CLAIM_SEQ_ID=v_seq_id and MAS.MASTER_ACTIVITY_CODE=V_MASTER_ACT; 
           
 CURSOR PARENT_ACTIVITY_CODES_LIST IS
  select TO_CHAR(REPLACE(WM_CONCAT(pat.code),',','|'))
         from clm_authorization_details cad 
        join pat_activity_details pat on (cad.claim_seq_id=pat.claim_seq_id)
        where cad.claim_seq_id in
        (select cad.claim_seq_id
        from clm_authorization_details cad 
        start with cad.claim_seq_id=v_seq_id
        connect by cad.claim_seq_id=prior cad.parent_claim_seq_id) and cad.parent_claim_seq_id is null;           

CURSOR PARENT_CLAIM_LIMIT(v_par_seq_id    NUMBER) IS
SELECT CASE WHEN CAD.BENIFIT_TYPE IN ('IPRE','PAHC','IEMA','HEAC' ) THEN 
                 CASE WHEN (NVL(CAD.BENEFIT_LIMIT,CAD.AVA_SUM_INSURED)-(cad.final_app_amount))>0 THEN
               (NVL(CAD.BENEFIT_LIMIT,CAD.AVA_SUM_INSURED)-(cad.final_app_amount)) ELSE 0 END
            WHEN CAD.BENIFIT_TYPE IN ('IMTI','OMTI') THEN 
                 CASE WHEN (NVL(CAD.MATERNITY_ALLOWED_AMT,CAD.AVA_SUM_INSURED)-(cad.final_app_amount))>0 THEN 
                 (NVL(CAD.MATERNITY_ALLOWED_AMT,CAD.AVA_SUM_INSURED)-(cad.final_app_amount))
              ELSE 0 END
               END   AS AVA_LIMIT
           FROM CLM_AUTHORIZATION_DETAILS CAD
           WHERE CAD.CLAIM_SEQ_ID=v_par_seq_id;      

CURSOR MASTER_ACTIVITY_CODES_OPIP (p_clam_seq_id NUMBER) IS
 SELECT DISTINCT MAS.MASTER_ACTIVITY_CODE AS CODE
           FROM CLM_AUTHORIZATION_DETAILS CAD
           JOIN PAT_ACTIVITY_DETAILS PAT ON (CAD.CLAIM_SEQ_ID=PAT.CLAIM_SEQ_ID)
           LEFT OUTER JOIN TPA_ACTIVITY_MASTER_DETAILS MAS ON (PAT.CODE=MAS.ACTIVITY_CODE AND MAS.ACTIVITY_CODE NOT LIKE 'D%')
           WHERE PAT.CLAIM_SEQ_ID=v_seq_id and MAS.MASTER_ACTIVITY_CODE IS NOT NULL
  INTERSECT
 SELECT DISTINCT MAS.MASTER_ACTIVITY_CODE AS CODE
 FROM CLM_AUTHORIZATION_DETAILS CAD
 JOIN PAT_ACTIVITY_DETAILS PAT ON (CAD.CLAIM_SEQ_ID=PAT.CLAIM_SEQ_ID)
 LEFT OUTER JOIN TPA_ACTIVITY_MASTER_DETAILS MAS ON (PAT.CODE=MAS.ACTIVITY_CODE AND MAS.ACTIVITY_CODE NOT LIKE 'D%')
 WHERE PAT.CLAIM_SEQ_ID=  p_clam_seq_id and MAS.MASTER_ACTIVITY_CODE IS NOT NULL;

CURSOR MASTER_ACTIVITY_CODES_DNTL IS           
 SELECT DISTINCT DEN.SPECIFIC_SERVICE_CODE
           FROM CLM_AUTHORIZATION_DETAILS CAD
           JOIN PAT_ACTIVITY_DETAILS PAT ON (CAD.CLAIM_SEQ_ID=PAT.CLAIM_SEQ_ID)
           LEFT OUTER JOIN DENTAL_RULE_TAB DEN ON (DEN.CDT_CODE=PAT.CODE)
           WHERE PAT.CLAIM_SEQ_ID=v_seq_id AND DEN.SPECIFIC_SERVICE_CODE IS NOT NULL;

CURSOR PARENT_ACTIVITY_CODES_DEN (v_act_code VARCHAR2,v_p_seq_id NUMBER)IS
 select b.rule_limit-sum(a.app_amt) as req_amt from 
  (select  DISTINCT nvl(ac.rule_limit,nvl(cc.benefit_limit,cc.ava_sum_insured)) as rule_limit,ac.code
    from clm_authorization_details cc join pat_activity_details ac on (cc.claim_seq_id=ac.claim_seq_id)
    left outer join DENTAL_RULE_TAB tab on (tab.cdt_code=ac.code) 
    where CC.claim_seq_id=v_p_seq_id and tab.specific_service_code=v_act_code
   ) b,
   (select distinct (pad.approved_amount) as app_amt ,pad.code,pad.activity_dtl_seq_id
    from clm_authorization_details cad
    join pat_activity_details pad on (cad.claim_seq_id=pad.claim_seq_id)
    left outer join DENTAL_RULE_TAB tab on (tab.cdt_code=pad.code)
    where level<>1 and TAB.SPECIFIC_SERVICE_CODE=v_act_code
    start with cad.claim_seq_id=v_seq_id
    connect by cad.claim_seq_id=prior cad.parent_claim_seq_id
    ) a
    where a.code=b.code
    group by b.rule_limit;
    
CURSOR PARENT_ACTIVITY_CODES_DENL (v_act_code VARCHAR2,v_p_seq_id NUMBER)IS
 select CASE WHEN ((b.req_amount)-sum(a.approved_amount))>0 THEN 
            ((b.req_amount)-sum(a.approved_amount)) ELSE 0 END remain_amt
                 ,a.code FROM 
    (select distinct (pad.approved_amount) as approved_amount ,pad.code
    from clm_authorization_details cad
    join pat_activity_details pad on (cad.claim_seq_id=pad.claim_seq_id)
    left outer join dental_rule_tab den on (den.cdt_code=pad.code) 
    where level<>1  and  den.specific_service_code=v_act_code
    start with cad.claim_seq_id=v_seq_id
    connect by cad.claim_seq_id=prior cad.parent_claim_seq_id
    )a,
    (select  distinct (case when nvl(ac.provider_net_amount,0)!=0  and nvl(ac.disc_gross_amount,0)!=0 then
                     least (ac.provider_net_amount,ac.disc_gross_amount) 
                when nvl(ac.provider_net_amount,0)!=0 and nvl(ac.disc_gross_amount,0)!=0 then
                      ac.disc_gross_amount
               else ac.disc_gross_amount end) req_amount,ac.code
    from clm_authorization_details cc join pat_activity_details ac on (cc.claim_seq_id=ac.claim_seq_id)
    left outer join dental_rule_tab den on (den.cdt_code=ac.code) 
    where CC.claim_seq_id=v_p_seq_id and den.specific_service_code=v_act_code  )b
   where a.code=b.code
   GROUP BY a.code,b.req_amount; 

CURSOR CURRENT_CHILD_ACT_CODE_OTH IS
       SELECT PAT.CODE,PAT.APPROVED_AMOUNT,PAT.Activity_Dtl_Seq_Id,PAT.OVERRIDE_YN,PAT.OUT_OF_POCKET_AMOUNT,MAS.MASTER_ACTIVITY_CODE
           FROM CLM_AUTHORIZATION_DETAILS CAD
           JOIN PAT_ACTIVITY_DETAILS PAT ON (CAD.CLAIM_SEQ_ID=PAT.CLAIM_SEQ_ID)
           LEFT OUTER JOIN DENTAL_RULE_TAB DEN ON (DEN.CDT_CODE=PAT.CODE)
           LEFT OUTER JOIN TPA_ACTIVITY_MASTER_DETAILS MAS ON (PAT.CODE=MAS.ACTIVITY_CODE)
           WHERE PAT.CLAIM_SEQ_ID=v_seq_id ;
           
CURSOR DENTAL_GLOBAL_LIMIT(v_pa_seq_id     NUMBER) IS
       select case when benifit_type='DNTL' THEN 
                     (Benefit_Limit-Final_App_Amount) END Global_limit 
              from APP.Clm_Authorization_Details where claim_seq_id=v_pa_seq_id;
   
CURSOR SYSTEM_OF_MED_LIMIT (v_pa_seq_id     NUMBER) IS
    SELECT NVL(CASE WHEN CAD.SYS_MED_LIMIT IS NOT NULL AND DD.RULE_LIMIT IS NOT NULL THEN 
                LEAST (CAD.SYS_MED_LIMIT,DD.RULE_LIMIT) 
                WHEN CAD.SYS_MED_LIMIT IS NOT NULL AND DD.RULE_LIMIT IS NULL THEN
                CAD.SYS_MED_LIMIT
                WHEN CAD.SYS_MED_LIMIT IS NULL AND DD.RULE_LIMIT IS NOT NULL THEN
                DD.RULE_LIMIT END,(BAL.SUM_INSURED-NVL(UTILISED_SUM_INSURED,0))) AS SYS_MED_LIMIT,
                NVL(CAD.SYS_MED_YN,'N') AS SYS_MED_YN
    FROM CLM_AUTHORIZATION_DETAILS CAD 
    JOIN DIAGNOSYS_DETAILS DD ON (CAD.CLAIM_SEQ_ID=DD.CLAIM_SEQ_ID)
    JOIN TPA_ENR_BALANCE BAL ON (BAL.MEMBER_SEQ_ID=CAD.MEMBER_SEQ_ID) 
    WHERE CAD.CLAIM_SEQ_ID=v_pa_seq_id;
                
CURSOR parent_patient_share_amt (v_par_seq_id NUMBER,v_act_code	 VARCHAR2) IS
  select patient_share_amount
         from pat_activity_details p
         where p.claim_seq_id=v_par_seq_id and p.code= v_act_code;
         
CURSOR MASTER_ACTIVITY_CODES_OPIP_CUR(V_ACT_C  VARCHAR2,paren_seq_id  NUMBER) IS
 SELECT  distinct pat.rule_limit,mas.master_activity_code AS CODE
           FROM CLM_AUTHORIZATION_DETAILS CAD
           JOIN PAT_ACTIVITY_DETAILS PAT ON (CAD.CLAIM_SEQ_ID=PAT.CLAIM_SEQ_ID)
           LEFT OUTER JOIN TPA_ACTIVITY_MASTER_DETAILS MAS ON (PAT.CODE=MAS.ACTIVITY_CODE AND MAS.ACTIVITY_CODE NOT LIKE 'D%')
           WHERE PAT.CLAIM_SEQ_ID=paren_seq_id AND MAS.MASTER_ACTIVITY_CODE=V_ACT_C
            and MAS.MASTER_ACTIVITY_CODE IS NOT NULL;  
                   
CURSOR CURRENT_CHILD_ACT_CODE_OTHS(V_ACT_CODES VARCHAR2) IS
       SELECT PAT.CODE,PAT.APPROVED_AMOUNT,pat.activity_dtl_seq_id
       ,pat.out_of_pocket_amount,pat.override_yn,pat.provider_net_amount
           FROM CLM_AUTHORIZATION_DETAILS CAD
           JOIN PAT_ACTIVITY_DETAILS PAT ON (CAD.CLAIM_SEQ_ID=PAT.CLAIM_SEQ_ID)
           JOIN TPA_ACTIVITY_MASTER_DETAILS MAS ON (PAT.CODE=MAS.ACTIVITY_CODE)
           WHERE PAT.CLAIM_SEQ_ID=v_seq_id AND MAS.MASTER_ACTIVITY_CODE=V_ACT_CODES
           AND PAT.CARRY_FOR_YN IS NULL AND MAS.ACTIVITY_CODE NOT LIKE 'D%';
           
CURSOR NEW_ACTIVITY_CODES_OPTS (V_PAR_SQ NUMBER)IS
       SELECT A.MASTER_ACTIVITY_CODE,A.RULE_LIMIT 
 FROM 
 (select x.MASTER_ACTIVITY_CODE,CASE WHEN (x.RULE_LIMIT-y.app_amt)>0 THEN  
                                     (x.RULE_LIMIT-y.app_amt) ELSE 0 END
                           as Rule_limit 
  FROM
    (SELECT DISTINCT M.MASTER_ACTIVITY_CODE,NVL(P.RULE_LIMIT,P.ALLOWED_AMOUNT) AS RULE_LIMIT FROM PAT_ACTIVITY_DETAILS P
        JOIN TPA_ACTIVITY_MASTER_DETAILS M ON (P.CODE=M.ACTIVITY_CODE)
        WHERE P.CLAIM_SEQ_ID=V_PAR_SQ AND M.ACTIVITY_CODE NOT LIKE 'D%') x,
        (SELECT distinct M.MASTER_ACTIVITY_CODE,sum(P.Approved_Amount) as app_amt FROM PAT_ACTIVITY_DETAILS P
        JOIN TPA_ACTIVITY_MASTER_DETAILS M ON (P.CODE=M.ACTIVITY_CODE)
        WHERE P.CLAIM_SEQ_ID=V_PAR_SQ AND M.ACTIVITY_CODE NOT LIKE 'D%'
        group by M.MASTER_ACTIVITY_CODE) y
        WHERE X.MASTER_ACTIVITY_CODE=Y.MASTER_ACTIVITY_CODE
        ) A,
(SELECT MASTER_ACTIVITY_CODE
    FROM ( 
          SELECT DISTINCT MAS.MASTER_ACTIVITY_CODE FROM PAT_ACTIVITY_DETAILS P 
          JOIN TPA_ACTIVITY_MASTER_DETAILS MAS ON (P.CODE=MAS.ACTIVITY_CODE)
          WHERE P.CLAIM_SEQ_ID=v_seq_id AND MAS.ACTIVITY_CODE NOT LIKE 'D%'
                    MINUS
          SELECT DISTINCT MAS.MASTER_ACTIVITY_CODE FROM PAT_ACTIVITY_DETAILS P 
          JOIN TPA_ACTIVITY_MASTER_DETAILS MAS ON (P.CODE=MAS.ACTIVITY_CODE)
          WHERE P.CLAIM_SEQ_ID=V_PAR_SQ AND MAS.ACTIVITY_CODE NOT LIKE 'D%')
  ) B
  WHERE A.MASTER_ACTIVITY_CODE=B.MASTER_ACTIVITY_CODE;
          
CURSOR NEW_ACTIVITY_CODES_DNTL (V_PAR_SQ NUMBER)IS
       SELECT A.SPECIFIC_SERVICE_CODE,A.RULE_LIMIT 
        FROM 
        ( SELECT X.SPECIFIC_SERVICE_CODE, CASE WHEN x.rule_limit is not null then 
                                                  case when (x.rule_limit-y.app_amt)>0 THEN
                                                      (x.rule_limit-y.app_amt) ELSE 0 end
                                               WHEN x.rule_limit is null then x.disc_gross_amount end as rule_limit
        from 
        (SELECT DISTINCT M.SPECIFIC_SERVICE_CODE,NVL(P.RULE_LIMIT,P.ALLOWED_AMOUNT) AS RULE_LIMIT,p.disc_gross_amount FROM PAT_ACTIVITY_DETAILS P
                JOIN DENTAL_RULE_TAB M ON (P.CODE=M.CDT_CODE)
                WHERE P.CLAIM_SEQ_ID=V_PAR_SQ) x,
        (SELECT M.SPECIFIC_SERVICE_CODE,SUM(P.Approved_Amount) as app_amt FROM PAT_ACTIVITY_DETAILS P
                JOIN DENTAL_RULE_TAB M ON (P.CODE=M.CDT_CODE)
                WHERE P.CLAIM_SEQ_ID=V_PAR_SQ
                GROUP BY M.SPECIFIC_SERVICE_CODE
        ) y
            where x.SPECIFIC_SERVICE_CODE=y.SPECIFIC_SERVICE_CODE ) A,
        (SELECT DISTINCT MAS.SPECIFIC_SERVICE_CODE
            FROM DENTAL_RULE_TAB MAS WHERE MAS.CDT_CODE IN ( 
                            SELECT P.CODE FROM PAT_ACTIVITY_DETAILS P WHERE P.CLAIM_SEQ_ID=v_seq_id
                            MINUS
                            SELECT P.CODE FROM PAT_ACTIVITY_DETAILS P WHERE P.CLAIM_SEQ_ID=V_PAR_SQ
                             )
          ) B
          WHERE A.SPECIFIC_SERVICE_CODE=B.SPECIFIC_SERVICE_CODE ;
                         
CURSOR CURRENT_CHILD_ACT_CODE_DNTL(V_ACT_CODES VARCHAR2) IS
       SELECT PAT.CODE,PAT.APPROVED_AMOUNT,pat.activity_dtl_seq_id,pat.out_of_pocket_amount,pat.override_yn
           FROM CLM_AUTHORIZATION_DETAILS CAD
           JOIN PAT_ACTIVITY_DETAILS PAT ON (CAD.CLAIM_SEQ_ID=PAT.CLAIM_SEQ_ID)
           JOIN DENTAL_RULE_TAB DEN ON (DEN.CDT_CODE=PAT.CODE)
           WHERE PAT.CLAIM_SEQ_ID=v_seq_id AND DEN.SPECIFIC_SERVICE_CODE=V_ACT_CODES
           AND PAT.CARRY_FOR_YN IS NULL;
           
CURSOR CURRENT_CHILD_ACT_CODE_MAS(v_par_sqe VARCHAR2) IS
SELECT MASTER_ACTIVITY_CODE
 FROM 
    ((SELECT DISTINCT M.MASTER_ACTIVITY_CODE
       FROM PAT_ACTIVITY_DETAILS P
        JOIN TPA_ACTIVITY_MASTER_DETAILS M ON (P.CODE=M.ACTIVITY_CODE)
        WHERE P.CLAIM_SEQ_ID=v_seq_id       
        ) 
        MINUS
(SELECT DISTINCT MAS.MASTER_ACTIVITY_CODE
    FROM TPA_ACTIVITY_MASTER_DETAILS MAS 
    WHERE MAS.ACTIVITY_CODE IN ( 
    SELECT P.CODE 
      FROM PAT_ACTIVITY_DETAILS P WHERE P.CLAIM_SEQ_ID=v_par_sqe)));           
                        
v_rest_amount			  NUMBER(20,2);
v_remain_amount		  NUMBER(20,2);
v_res_limit         NUMBER(20,2);
v_final_pay         NUMBER(20,2);
v_activity_list     VARCHAR2(32000);
v_parent_seq_id     NUMBER(10);
v_used_amount       NUMBER(20,2);
v_global_limt       NUMBER(20,2);
v_sys_med_yn        VARCHAR2(5);
v_sys_med_limit     NUMBER(20,2);
v_parent_ps_amt     NUMBER(20,2); 
v_act_used_amt      NUMBER(20,2);
v_app_amt           NUMBER(20,2);
 BEGIN
     
   OPEN PARENT_ALLOWED_AMOUNT;
    FETCH PARENT_ALLOWED_AMOUNT INTO v_final_pay;
      CLOSE PARENT_ALLOWED_AMOUNT;
       
     OPEN Parent_claim_seq_id_1;
       FETCH Parent_claim_seq_id_1 INTO v_parent_seq_id;
         CLOSE  Parent_claim_seq_id_1;
        
     OPEN PARENT_ACTIVITY_CODES_LIST;
       FETCH PARENT_ACTIVITY_CODES_LIST INTO v_activity_list;
         CLOSE PARENT_ACTIVITY_CODES_LIST;   
         
      OPEN SYSTEM_OF_MED_LIMIT(v_parent_seq_id);
        FETCH SYSTEM_OF_MED_LIMIT INTO v_sys_med_limit,v_sys_med_yn;
          CLOSE SYSTEM_OF_MED_LIMIT;   
  
  v_rest_amount:=NULL;
  v_rest_amount:=v_final_pay;

---IF THIS CLAIM IS NOT RELATED TO SYSTEM OF MEDICINE THEN THIS CODE WILL EXECUTE
IF v_sys_med_yn ='N' THEN      
    IF v_benefit_type IN ('IPRE','PAHC','IEMA','HEAC','IMTI','OMTI') THEN       

    FOR K IN PARENT_CLAIM_LIMIT(v_parent_seq_id) LOOP 
             v_final_pay:=least(v_rest_amount,k.ava_limit);
             v_rest_amount:=least(v_rest_amount,k.ava_limit);
       FOR J IN Parent_Actvity_Codes_OPIPM(v_parent_seq_id) LOOP
           FOR I IN CURRENT_CHILD_ACTIVITY_CODE(j.code) LOOP
            IF I.CODE=J.CODE THEN
              
               open parent_patient_share_amt (v_parent_seq_id,i.code);
                    fetch parent_patient_share_amt into v_parent_ps_amt;
                      close parent_patient_share_amt;
            
              v_rest_amount := least(least(v_rest_amount,i.provider_net_amount),CASE when I.OUT_OF_POCKET_AMOUNT IS NOT NULL  THEN 
                                                    case when ((j.remain_amt-v_parent_ps_amt)-i.out_of_pocket_amount)>0 then 
                                                            ((j.remain_amt-v_parent_ps_amt)-i.out_of_pocket_amount) 
                                                            else 0 end
                                                     ELSE  (j.remain_amt-v_parent_ps_amt) END);
                      v_rest_amount := CASE WHEN i.approved_amount > v_rest_amount  THEN v_rest_amount  
                                            WHEN i.approved_amount<=v_rest_amount  THEN i.approved_amount  ELSE v_rest_amount END;
                      IF v_rest_amount>=0 THEN
                      v_remain_amount :=NVL(v_remain_amount,v_final_pay)-(v_rest_amount);
                      END IF;
                      
                      update pat_activity_details pat
                        set  pat.approved_amount  =CASE WHEN v_rest_amount>0 THEN v_rest_amount  ELSE 0 END,
                             pat.allowed_amount   =CASE WHEN v_rest_amount>0 THEN v_rest_amount ELSE 0 END,
                             pat.denial_desc      = case when i.approved_amount  >v_rest_amount then  case when pat.denial_desc is  null then 'Approved as per Original Claims requested amount' else case when pat.denial_code like '%CLM-BENX-005%'then pat.denial_desc else pat.denial_desc||';'||'Approved as per Original Claims requested amount' end end else pat.denial_desc end,
                             pat.denial_code      = case when i.approved_amount  >v_rest_amount then case when pat.denial_code is  null then 'AMNT-REQ-002' else case when pat.denial_code like '%AMNT-REQ-002%'then pat.denial_code else pat.denial_code||';'||'AMNT-REQ-002' end end else pat.denial_code end,
                             pat.denial_by_rule_proc_dtls= case when i.approved_amount >v_rest_amount then   'while validating resubmission limits' end,          
                             pat.updated_by       = v_added_by,
                             pat.updated_date     =sysdate         
                      where pat.activity_dtl_seq_id=i.activity_dtl_seq_id;      
                  IF v_remain_amount IS NOT NULL THEN  
                    v_rest_amount:=v_remain_amount;
                  END IF;
             END IF;
          END LOOP;
       END LOOP;   
     END LOOP;
     
     ---VALIDATING ACTIVITY CODES WHICH ARE NOT AVILABLE IN PARENT
     
      FOR H IN CURRENT_CHILD_ACT_CODE_OTH LOOP
           IF '|'||v_activity_list||'|' LIKE '%'||'|'||h.CODE ||'|'||'%' THEN
                  NULL;
           ELSE
                IF (v_final_pay-v_used_amount)>0 THEN
                  v_final_pay:=v_final_pay-nvl(v_used_amount,0);
                ELSE
                  v_final_pay:=0;
                END IF;
               v_rest_amount:=v_final_pay;
               v_remain_amount:=null;
               
                   IF h.OVERRIDE_YN='Y' THEN 
                     v_rest_amount := CASE WHEN h.approved_amount > v_rest_amount  THEN v_rest_amount  
                                           WHEN h.approved_amount<=v_rest_amount  THEN h.approved_amount  ELSE v_rest_amount END;
                    v_remain_amount :=NVL(v_remain_amount,v_final_pay)-(v_rest_amount);
                   END IF;
                  UPDATE pat_activity_details pad
                         SET pad.allowed_amount=CASE WHEN h.override_yn='Y' THEN v_rest_amount ELSE 0 END,
                             pad.approved_amount=CASE WHEN h.override_yn='Y' THEN v_rest_amount ELSE 0 END,
                             pad.denial_desc=case when pad.denial_desc is null then 'Claim Information is Inconsistent With Original Claim services' else case when pad.denial_code like '%'||'Claim Information is Inconsistent With Original Claim services' ||'%'   then pad.denial_desc else pad.denial_desc||';'||'Claim Information is Inconsistent With Original Claim services' end end , 
                             pad.denial_code=case when pad.denial_code is null then 'AUTH-CLA-012' else case when pad.denial_code like '%'||'AUTH-CLA-012'||'%' then pad.denial_code else pad.denial_code||';'||'AUTH-CLA-012' end end,
                             pad.remarks=case when pad.denial_code is null then 'Claim Information is Inconsistent With Original Claim services'  else case when pad.denial_code  like '%'||'Claim Information is Inconsistent With Original Claim services' ||'%' then pad.remarks else pad.remarks||';'||'Claim Information is Inconsistent With Original Claim services'  end end,
                             pad.updated_by   = v_added_by,
                             pad.updated_date = SYSDATE
                       WHERE pad.claim_seq_id = v_seq_id  
                       and pad.activity_dtl_seq_id = h.activity_dtl_seq_id;  
                  
                  IF  v_rest_amount> 0 THEN
                   v_used_amount:=  nvl(v_used_amount,0)+v_rest_amount;
                  END IF;
                  
                   
                    IF v_remain_amount IS NOT NULL THEN
                    v_rest_amount:=v_remain_amount;
                    END IF;
            END IF; 
       END LOOP;    
    ELSIF v_benefit_type IN ('OPTS','IPT','CBF','OPTC') THEN 
     
  FOR K IN MASTER_ACTIVITY_CODES_OPIP (v_parent_seq_id) LOOP
               v_final_pay:=v_final_pay-NVL(v_used_amount,0);
     IF v_final_pay>0 THEN              
               v_rest_amount:=v_final_pay;
               v_remain_amount:=null;
               v_act_used_amt:=NULL;
               v_used_amount:=null;
       FOR L IN PARENT_ACTIVITY_CODES_CUN(k.code,v_parent_seq_id) LOOP
         FOR J IN PARENT_ACTIVITY_CODES_MTN(k.CODE,v_parent_seq_id) LOOP
           v_app_amt := least(l.rule_limit,l.remain_amt)-j.remain_amt;
        
        IF v_app_amt is not null then
          IF v_app_amt >= 0 then  
             v_rest_amount:= least(v_rest_amount,(v_app_amt-NVL(v_act_used_amt,0)));
          END IF;
         ELSE
           v_rest_amount := v_rest_amount-NVL(v_act_used_amt,0);
         END IF;    
        
           FOR I IN CURRENT_CHILD_ACTIVITY_CODE(k.code) LOOP
            open parent_patient_share_amt (v_parent_seq_id,i.code);
                    fetch parent_patient_share_amt into v_parent_ps_amt;
                      close parent_patient_share_amt;
                      
              v_rest_amount := least(least(v_rest_amount,i.provider_net_amount),case when i.out_of_pocket_amount is not null then
                                                         case when ((v_rest_amount-v_parent_ps_amt)-i.out_of_pocket_amount)>0 then 
                                                                   ((v_rest_amount-v_parent_ps_amt)-i.out_of_pocket_amount) else v_rest_amount end
                                                             else ( v_rest_amount-v_parent_ps_amt) end);
                      v_rest_amount := CASE WHEN i.approved_amount > v_rest_amount  THEN v_rest_amount  
                                            WHEN i.approved_amount<=v_rest_amount  THEN i.approved_amount  ELSE v_rest_amount END;
                      
                      
                      update pat_activity_details pat
                        set  pat.approved_amount  =CASE WHEN v_rest_amount>0 THEN v_rest_amount  ELSE 0 END,
                             pat.allowed_amount   =CASE WHEN v_rest_amount>0 THEN v_rest_amount ELSE 0 END,
                             pat.denial_desc      = case when i.approved_amount  >v_rest_amount then  case when pat.denial_desc is  null then 'Approved as per Original Claims requested amount' else case when pat.denial_code like '%CLM-BENX-005%'then pat.denial_desc else pat.denial_desc||';'||'Approved as per Original Claims requested amount' end end else pat.denial_desc end,
                             pat.denial_code      = case when i.approved_amount  >v_rest_amount then case when pat.denial_code is  null then 'AMNT-REQ-002' else case when pat.denial_code like '%AMNT-REQ-002%'then pat.denial_code else pat.denial_code||';'||'AMNT-REQ-002' end end else pat.denial_code end,
                             pat.denial_by_rule_proc_dtls= case when i.approved_amount >v_rest_amount then 'while validating resubmission limits' end,          
                             pat.updated_by       = v_added_by,
                             pat.updated_date     =sysdate         
                      where pat.activity_dtl_seq_id=i.activity_dtl_seq_id;      
              
              IF NVL(v_rest_amount,0)!=0 AND NVL(v_rest_amount,0)>0 THEN      
               v_used_amount:=NVL(v_used_amount,0)+v_rest_amount;
               v_act_used_amt := NVL(v_act_used_amt,0)+v_rest_amount;
               --v_final_pay:=v_final_pay-v_rest_amount;
              END IF;    
               
         IF v_rest_amount>=0 THEN
            v_remain_amount :=NVL(v_remain_amount, least(v_final_pay,case when v_app_amt is not null then v_app_amt else v_final_pay end ))-(nvl(v_used_amount,0));
         END IF;
         
              IF v_remain_amount IS NOT NULL and v_remain_amount>=0 THEN  
                v_rest_amount:=v_remain_amount;
         ELSIF v_remain_amount <= 0 THEN
           v_rest_amount := 0;
              END IF; 
        
            END LOOP;
          END LOOP;
     END LOOP; 
  ELSE
    v_final_pay :=0; 
       FOR I IN CURRENT_CHILD_ACTIVITY_CODE(k.code) LOOP
           v_rest_amount := 0;
           v_rest_amount := CASE WHEN i.approved_amount > v_rest_amount  THEN v_rest_amount  
                                            WHEN i.approved_amount<=v_rest_amount  THEN i.approved_amount  ELSE v_rest_amount END;
                update pat_activity_details pat
                  set  pat.approved_amount  =CASE WHEN v_rest_amount>0 THEN v_rest_amount  ELSE 0 END,
                       pat.allowed_amount   =CASE WHEN v_rest_amount>0 THEN v_rest_amount ELSE 0 END,
                       pat.denial_desc      = case when i.approved_amount  >v_rest_amount then  case when pat.denial_desc is  null then 'Approved as per Original Claims requested amount' else case when pat.denial_code like '%CLM-BENX-005%'then pat.denial_desc else pat.denial_desc||';'||'Approved as per Original Claims requested amount' end end else pat.denial_desc end,
                       pat.denial_code      = case when i.approved_amount  >v_rest_amount then case when pat.denial_code is  null then 'AMNT-REQ-002' else case when pat.denial_code like '%AMNT-REQ-002%'then pat.denial_code else pat.denial_code||';'||'AMNT-REQ-002' end end else pat.denial_code end,
                       pat.denial_by_rule_proc_dtls= case when i.approved_amount >v_rest_amount then 'while validating resubmission limits' end,          
                       pat.updated_by       = v_added_by,
                       pat.updated_date     =sysdate         
                where pat.activity_dtl_seq_id=i.activity_dtl_seq_id;      
                v_rest_amount:=0;
    END LOOP; 
  END IF;   
 END LOOP; 
--------------VALIDATING ACTIVITY CODES WHICH ARE NOT AVILABLE IN PARENT

  FOR P IN NEW_ACTIVITY_CODES_OPTS (v_parent_seq_id) LOOP
    v_act_used_amt:=null;
    v_final_pay := v_final_pay-nvl(v_used_amount,0);
   IF v_final_pay >0 THEN  
    v_act_used_amt:=case when P.RULE_LIMIT is not null then 
                         least(v_final_pay,P.RULE_LIMIT) 
                       else v_final_pay end;     
        v_rest_amount   := v_act_used_amt;
        v_remain_amount := NULL;                   
    FOR C IN CURRENT_CHILD_ACT_CODE_OTHS (P.MASTER_ACTIVITY_CODE) LOOP
      v_rest_amount:=least(least(v_rest_amount,c.provider_net_amount),c.approved_amount);
      if v_rest_amount>=0 then 
       v_remain_amount :=NVL(v_remain_amount, (v_act_used_amt-nvl(v_used_amount,0))-(v_rest_amount));   
      end if;             
                   UPDATE pat_activity_details pad
                         SET pad.allowed_amount=CASE WHEN c.override_yn='Y' THEN v_rest_amount ELSE 0 END,
                             pad.approved_amount=CASE WHEN c.override_yn='Y' THEN v_rest_amount ELSE 0 END,
                             pad.denial_desc=case when pad.denial_desc is null then 'Claim Information is Inconsistent With Original Claim services' else case when pad.denial_code like '%'||'Claim Information is Inconsistent With Original Claim services' ||'%'   then pad.denial_desc else pad.denial_desc||';'||'Claim Information is Inconsistent With Original Claim services' end end , 
                             pad.denial_code=case when pad.denial_code is null then 'AUTH-CLA-012' else case when pad.denial_code like '%'||'AUTH-CLA-012'||'%' then pad.denial_code else pad.denial_code||';'||'AUTH-CLA-012' end end,
                             pad.remarks=case when pad.denial_code is null then 'Claim Information is Inconsistent With Original Claim services'  else case when pad.denial_code  like '%'||'Claim Information is Inconsistent With Original Claim services' ||'%' then pad.remarks else pad.remarks||';'||'Claim Information is Inconsistent With Original Claim services'  end end,
                             pad.updated_by   = v_added_by,
                             pad.updated_date = SYSDATE
                       WHERE pad.claim_seq_id = v_seq_id  
                       and pad.activity_dtl_seq_id = c.activity_dtl_seq_id;  
        
       if nvl(v_rest_amount,0)!=0 and nvl(v_rest_amount,0)>0 then
           v_used_amount:=nvl(v_used_amount,0)+v_rest_amount;
       end if;  
       
       if v_remain_amount is not null and  v_remain_amount>=0 then    
           v_rest_amount:=v_remain_amount;
       end if;       
    END LOOP;
   ELSE
      v_final_pay :=0; 
       FOR I IN CURRENT_CHILD_ACT_CODE_OTHS(P.MASTER_ACTIVITY_CODE) LOOP
           v_rest_amount := 0;
           v_rest_amount := CASE WHEN i.approved_amount > v_rest_amount  THEN v_rest_amount  
                                            WHEN i.approved_amount<=v_rest_amount  THEN i.approved_amount  ELSE v_rest_amount END;
                update pat_activity_details pat
                  set  pat.approved_amount  =CASE WHEN v_rest_amount>0 THEN v_rest_amount  ELSE 0 END,
                       pat.allowed_amount   =CASE WHEN v_rest_amount>0 THEN v_rest_amount ELSE 0 END,
                       pat.denial_desc      = case when i.approved_amount  >v_rest_amount then  case when pat.denial_desc is  null then 'Approved as per Original Claims requested amount' else case when pat.denial_code like '%CLM-BENX-005%'then pat.denial_desc else pat.denial_desc||';'||'Approved as per Original Claims requested amount' end end else pat.denial_desc end,
                       pat.denial_code      = case when i.approved_amount  >v_rest_amount then case when pat.denial_code is  null then 'AMNT-REQ-002' else case when pat.denial_code like '%AMNT-REQ-002%'then pat.denial_code else pat.denial_code||';'||'AMNT-REQ-002' end end else pat.denial_code end,
                       pat.denial_by_rule_proc_dtls= case when i.approved_amount >v_rest_amount then 'while validating resubmission limits' end,          
                       pat.updated_by       = v_added_by,
                       pat.updated_date     =sysdate         
                where pat.activity_dtl_seq_id=i.activity_dtl_seq_id;      
                v_rest_amount:=0;
  END LOOP;   
   END IF; 
  END LOOP;   
 
--NEW MASTER ACTIVITY CODES WHICH ARE NOT AVILABLE IN PARENT ADDED IN RESUBMISSION

      FOR V IN CURRENT_CHILD_ACT_CODE_MAS(v_parent_seq_id) LOOP
            v_final_pay:=v_final_pay-nvl(v_used_amount,0);
            v_act_used_amt:=v_final_pay;
            v_rest_amount:=v_act_used_amt;
            v_remain_amount:=null;
            v_used_amount:=0;
         FOR C IN CURRENT_CHILD_ACT_CODE_OTHS (v.master_activity_code) LOOP   
            v_rest_amount:=least(v_rest_amount,c.approved_amount);
            if v_rest_amount>=0 then
              v_remain_amount :=NVL(v_remain_amount, v_final_pay-nvl(v_used_amount,0))-(v_rest_amount);    
            end if;   
             UPDATE pat_activity_details pad
                         SET pad.allowed_amount=CASE WHEN c.override_yn='Y' THEN v_rest_amount ELSE 0 END,
                             pad.approved_amount=CASE WHEN c.override_yn='Y' THEN v_rest_amount ELSE 0 END,
                             pad.denial_desc=case when pad.denial_desc is null then 'Claim Information is Inconsistent With Original Claim services' else case when pad.denial_code like '%'||'Claim Information is Inconsistent With Original Claim services' ||'%'   then pad.denial_desc else pad.denial_desc||';'||'Claim Information is Inconsistent With Original Claim services' end end , 
                             pad.denial_code=case when pad.denial_code is null then 'AUTH-CLA-012' else case when pad.denial_code like '%'||'AUTH-CLA-012'||'%' then pad.denial_code else pad.denial_code||';'||'AUTH-CLA-012' end end,
                             pad.remarks=case when pad.denial_code is null then 'Claim Information is Inconsistent With Original Claim services'  else case when pad.denial_code  like '%'||'Claim Information is Inconsistent With Original Claim services' ||'%' then pad.remarks else pad.remarks||';'||'Claim Information is Inconsistent With Original Claim services'  end end,
                             pad.updated_by   = v_added_by,
                             pad.updated_date = SYSDATE
                       WHERE pad.claim_seq_id = v_seq_id  
                       and pad.activity_dtl_seq_id = c.activity_dtl_seq_id;  
        
           if nvl(v_rest_amount,0)!=0 and nvl(v_rest_amount,0)>0 then
               v_used_amount:=nvl(v_used_amount,0)+v_rest_amount;
           end if;  
       
           if v_remain_amount is not null and  v_remain_amount>=0 then    
           v_rest_amount:=v_remain_amount;
           end if;       
         END LOOP;  
      END LOOP;

ELSIF v_benefit_type='DNTL' THEN

    ----CODE FOR ACTIVITY CODES WHICH ARE RELATED TO DENTAL 
        OPEN DENTAL_GLOBAL_LIMIT(v_parent_seq_id);
          FETCH DENTAL_GLOBAL_LIMIT INTO v_global_limt;
            CLOSE DENTAL_GLOBAL_LIMIT;
       IF v_global_limt IS NOT NULL THEN
         v_final_pay := LEAST (v_final_pay,v_global_limt);
         v_rest_amount:= v_final_pay;
       END IF;     
            
      FOR k IN MASTER_ACTIVITY_CODES_DNTL LOOP
           v_final_pay := v_final_pay- nvl(v_used_amount,0);
           v_used_amount:=0;
           v_rest_amount:= v_final_pay;
        FOR L IN PARENT_ACTIVITY_CODES_DEN(k.specific_service_code,v_parent_seq_id) LOOP
          FOR J IN PARENT_ACTIVITY_CODES_DENL(k.specific_service_code,v_parent_seq_id) LOOP
            FOR I IN CURRENT_CHILD_ACTIVITY_CODE(j.code) LOOP
               v_rest_amount:= least(v_rest_amount,l.req_amt);
               
               
                IF I.CODE=J.CODE THEN
                  
                  open parent_patient_share_amt (v_parent_seq_id,i.code);
                    fetch parent_patient_share_amt into v_parent_ps_amt;
                      close parent_patient_share_amt;
                      
                          v_rest_amount := least(least(v_rest_amount,i.provider_net_amount),case when i.out_of_pocket_amount is not null then
                                                                    case when ( (j.remain_amt-v_parent_ps_amt)-i.out_of_pocket_amount)>0 then
                                                                      ( (j.remain_amt-v_parent_ps_amt)-i.out_of_pocket_amount) else 0 end
                                                                    else  (j.remain_amt-v_parent_ps_amt) end);
                          v_rest_amount := CASE WHEN i.approved_amount > v_rest_amount  THEN v_rest_amount  
                                                WHEN i.approved_amount<=v_rest_amount  THEN i.approved_amount  ELSE v_rest_amount END;
                          if v_rest_amount >=0 then
                          v_remain_amount :=NVL(v_remain_amount,v_final_pay)-(v_rest_amount);
                          end if;
                          
                          update pat_activity_details pat
                            set  pat.approved_amount  =CASE WHEN v_rest_amount>0 THEN v_rest_amount  ELSE 0 END,
                                 pat.allowed_amount   =CASE WHEN v_rest_amount>0 THEN v_rest_amount ELSE 0 END,
                                 pat.denial_desc      = case when i.approved_amount  >v_rest_amount then  case when pat.denial_desc is  null then 'Approved as per Original Claims requested amount' else case when pat.denial_code like '%CLM-BENX-005%'then pat.denial_desc else pat.denial_desc||';'||'Approved as per Original Claims requested amount' end end else pat.denial_desc end,
                                 pat.denial_code      = case when i.approved_amount  >v_rest_amount then case when pat.denial_code is  null then 'AMNT-REQ-002' else case when pat.denial_code like '%AMNT-REQ-002%'then pat.denial_code else pat.denial_code||';'||'AMNT-REQ-002' end end else pat.denial_code end,
                                 pat.denial_by_rule_proc_dtls= case when i.approved_amount >v_rest_amount then 'while validating resubmission limits' end,          
                                 pat.updated_by       = v_added_by,
                                 pat.updated_date     =sysdate         
                          where pat.activity_dtl_seq_id=i.activity_dtl_seq_id;      
                        
                        IF nvl(v_rest_amount,0)!=0 and nvl(v_rest_amount,0)>0 THEN
                          v_used_amount:=NVL(v_used_amount,0)+v_rest_amount;
                        END IF;
                        
                        if v_remain_amount is not null and  v_remain_amount >= 0 then
                        v_rest_amount:=v_remain_amount;
                        end if;
                 END IF;
               END LOOP;
            END LOOP;
         END LOOP;
      END LOOP;
     
     ----CODE FOR ACTIVITY CODES WHICH ARE NOT RELATED TO DENTAL 
     
       FOR K IN MASTER_ACTIVITY_CODES_OPIP(v_parent_seq_id) LOOP
               v_final_pay:=v_final_pay-NVL(v_used_amount,0);
               v_used_amount:=0;
       FOR L IN PARENT_ACTIVITY_CODES_CUN(k.code,v_parent_seq_id) LOOP
         FOR J IN PARENT_ACTIVITY_CODES_MTN(k.CODE,v_parent_seq_id) LOOP
           v_app_amt := least(l.rule_limit,l.remain_amt)-j.remain_amt;
           v_rest_amount:= least(v_rest_amount,(v_app_amt-NVL(v_used_amount,0)));
           FOR I IN CURRENT_CHILD_ACTIVITY_CODE(k.code) LOOP
              v_rest_amount := least(least(v_rest_amount,i.provider_net_amount), case when i.out_of_pocket_amount is not null then
                                                         case when (v_rest_amount-i.out_of_pocket_amount)>0 then
                                                              (v_rest_amount-i.out_of_pocket_amount) else 0 end
                                                          else v_rest_amount end);
                      v_rest_amount := CASE WHEN i.approved_amount > v_rest_amount  THEN v_rest_amount  
                                            WHEN i.approved_amount<=v_rest_amount  THEN i.approved_amount  ELSE v_rest_amount END;
                      IF v_rest_amount>=0 THEN
                      v_remain_amount :=NVL(v_remain_amount, least(v_final_pay,l.rule_limit))-(v_rest_amount);
                      END IF;
                      
                      update pat_activity_details pat
                        set  pat.approved_amount  =CASE WHEN v_rest_amount>0 THEN v_rest_amount  ELSE 0 END,
                             pat.allowed_amount   =CASE WHEN v_rest_amount>0 THEN v_rest_amount ELSE 0 END,
                             pat.denial_desc      = case when i.approved_amount  >v_rest_amount then  case when pat.denial_desc is  null then 'Approved as per Original Claims requested amount' else case when pat.denial_code like '%CLM-BENX-005%'then pat.denial_desc else pat.denial_desc||';'||'Approved as per Original Claims requested amount' end end else pat.denial_desc end,
                             pat.denial_code      = case when i.approved_amount  >v_rest_amount then case when pat.denial_code is  null then 'AMNT-REQ-002' else case when pat.denial_code like '%AMNT-REQ-002%'then pat.denial_code else pat.denial_code||';'||'AMNT-REQ-002' end end else pat.denial_code end,
                             pat.denial_by_rule_proc_dtls= case when i.approved_amount >v_rest_amount then 'while validating resubmission limits' end,          
                             pat.updated_by       = v_added_by,
                             pat.updated_date     =sysdate         
                      where pat.activity_dtl_seq_id=i.activity_dtl_seq_id;      
              IF NVL(v_rest_amount,0)!=0 AND NVL(v_rest_amount,0)>0 THEN      
               v_used_amount:=NVL(v_used_amount,0)+v_rest_amount;
              END IF;      
              
              IF v_remain_amount IS NOT NULL THEN  
                v_rest_amount:=v_remain_amount;
             END IF;
            END LOOP;
          END LOOP;
     END LOOP; 
    END LOOP;
     
    ---VALIDATING ACTIVITY CODES WHICH ARE NOT AVILABLE IN PARENT
     
    --1--OTHER THAN DENTAL ACTIVITIES
    FOR P IN NEW_ACTIVITY_CODES_OPTS (v_parent_seq_id) LOOP
    v_final_pay := v_final_pay-nvl(v_used_amount,0);
    v_used_amount:=0;
     v_act_used_amt:=case when P.RULE_LIMIT is not null then 
      least(v_final_pay,P.RULE_LIMIT) else v_final_pay end;
      v_rest_amount:=  v_act_used_amt;              
    FOR C IN CURRENT_CHILD_ACT_CODE_OTHS (P.MASTER_ACTIVITY_CODE) LOOP
      v_rest_amount:=least(least(v_rest_amount,c.provider_net_amount),c.approved_amount);
      if v_rest_amount >=0 then 
        v_remain_amount :=NVL(v_remain_amount, v_act_used_amt)-(v_rest_amount);                      
      end if;
      UPDATE pat_activity_details pad
                         SET pad.allowed_amount=CASE WHEN c.override_yn='Y' THEN v_rest_amount ELSE 0 END,
                             pad.approved_amount=CASE WHEN c.override_yn='Y' THEN v_rest_amount ELSE 0 END,
                             pad.denial_desc=case when pad.denial_desc is null then 'Claim Information is Inconsistent With Original Claim services' else case when pad.denial_code like '%'||'Claim Information is Inconsistent With Original Claim services' ||'%'   then pad.denial_desc else pad.denial_desc||';'||'Claim Information is Inconsistent With Original Claim services' end end , 
                             pad.denial_code=case when pad.denial_code is null then 'AUTH-CLA-012' else case when pad.denial_code like '%'||'AUTH-CLA-012'||'%' then pad.denial_code else pad.denial_code||';'||'AUTH-CLA-012' end end,
                             pad.remarks=case when pad.denial_code is null then 'Claim Information is Inconsistent With Original Claim services'  else case when pad.denial_code  like '%'||'Claim Information is Inconsistent With Original Claim services' ||'%' then pad.remarks else pad.remarks||';'||'Claim Information is Inconsistent With Original Claim services'  end end,
                             pad.updated_by   = v_added_by,
                             pad.updated_date = SYSDATE
                       WHERE pad.claim_seq_id = v_seq_id  
                       and pad.activity_dtl_seq_id = c.activity_dtl_seq_id;  
        
       if nvl(v_rest_amount,0)!=0 and nvl(v_rest_amount,0)>0 then
           v_used_amount:=nvl(v_used_amount,0)+v_rest_amount;
       end if;  
       
       if v_remain_amount is not null and  v_remain_amount>=0 then    
           v_rest_amount:=v_remain_amount;
       end if;       
    END LOOP;
  END LOOP;   
    --2--ACTIVITES WHICH ARE IN DENTAL
    FOR P IN NEW_ACTIVITY_CODES_DNTL (v_parent_seq_id) LOOP
    v_final_pay := v_final_pay-nvl(v_used_amount,0);
    v_used_amount:=0;
     v_act_used_amt:=case when P.RULE_LIMIT is not null then 
      least(v_final_pay,P.RULE_LIMIT) else v_final_pay end;   
      v_rest_amount:=   v_act_used_amt;          
    FOR C IN CURRENT_CHILD_ACT_CODE_DNTL (P.SPECIFIC_SERVICE_CODE) LOOP
      v_rest_amount:=least(v_rest_amount,c.approved_amount);
      if v_rest_amount>=0 then
        v_remain_amount :=NVL(v_remain_amount, v_act_used_amt-nvl(v_used_amount,0))-(v_rest_amount);                    
      end if;
           UPDATE pat_activity_details pad
                 SET pad.allowed_amount=CASE WHEN c.override_yn='Y' THEN v_rest_amount ELSE 0 END,
                     pad.approved_amount=CASE WHEN c.override_yn='Y' THEN v_rest_amount ELSE 0 END,
                     pad.denial_desc=case when pad.denial_desc is null then 'Claim Information is Inconsistent With Original Claim services' else case when pad.denial_code like '%'||'Claim Information is Inconsistent With Original Claim services' ||'%'   then pad.denial_desc else pad.denial_desc||';'||'Claim Information is Inconsistent With Original Claim services' end end , 
                     pad.denial_code=case when pad.denial_code is null then 'AUTH-CLA-012' else case when pad.denial_code like '%'||'AUTH-CLA-012'||'%' then pad.denial_code else pad.denial_code||';'||'AUTH-CLA-012' end end,
                     pad.remarks=case when pad.denial_code is null then 'Claim Information is Inconsistent With Original Claim services'  else case when pad.denial_code  like '%'||'Claim Information is Inconsistent With Original Claim services' ||'%' then pad.remarks else pad.remarks||';'||'Claim Information is Inconsistent With Original Claim services'  end end,
                     pad.updated_by   = v_added_by,
                     pad.updated_date = SYSDATE
               WHERE pad.claim_seq_id = v_seq_id  
               and pad.activity_dtl_seq_id = c.activity_dtl_seq_id;  
        
       if nvl(v_rest_amount,0)!=0 and nvl(v_rest_amount,0)>0 then
           v_used_amount:=nvl(v_used_amount,0)+v_rest_amount;
       end if;  
       
       if v_remain_amount is not null and  v_remain_amount>0 then    
           v_rest_amount:=v_remain_amount;
       end if;       
    END LOOP;
  END LOOP;   
  
  --NEW MASTER ACTIVITY CODES WHICH ARE NOT AVILABLE IN PARENT ADDED IN RESUBMISSION

      FOR V IN CURRENT_CHILD_ACT_CODE_MAS(v_parent_seq_id) LOOP
            v_final_pay:=v_final_pay-nvl(v_used_amount,0);
            v_act_used_amt:=v_final_pay;
            v_rest_amount:=v_act_used_amt;
            v_remain_amount:=null;
            v_used_amount:=0;
         FOR C IN CURRENT_CHILD_ACT_CODE_OTHS (v.master_activity_code) LOOP   
            v_rest_amount:=least(least(v_rest_amount,c.provider_net_amount),c.approved_amount);
            if v_rest_amount>=0 then
              v_remain_amount :=NVL(v_remain_amount, v_final_pay-nvl(v_used_amount,0))-(v_rest_amount);    
            end if;    
                UPDATE pat_activity_details pad
                         SET pad.allowed_amount=CASE WHEN c.override_yn='Y' THEN v_rest_amount ELSE 0 END,
                             pad.approved_amount=CASE WHEN c.override_yn='Y' THEN v_rest_amount ELSE 0 END,
                             pad.denial_desc=case when pad.denial_desc is null then 'Claim Information is Inconsistent With Original Claim services' else case when pad.denial_code like '%'||'Claim Information is Inconsistent With Original Claim services' ||'%'   then pad.denial_desc else pad.denial_desc||';'||'Claim Information is Inconsistent With Original Claim services' end end , 
                             pad.denial_code=case when pad.denial_code is null then 'AUTH-CLA-012' else case when pad.denial_code like '%'||'AUTH-CLA-012'||'%' then pad.denial_code else pad.denial_code||';'||'AUTH-CLA-012' end end,
                             pad.remarks=case when pad.denial_code is null then 'Claim Information is Inconsistent With Original Claim services'  else case when pad.denial_code  like '%'||'Claim Information is Inconsistent With Original Claim services' ||'%' then pad.remarks else pad.remarks||';'||'Claim Information is Inconsistent With Original Claim services'  end end,
                             pad.updated_by   = v_added_by,
                             pad.updated_date = SYSDATE
                       WHERE pad.claim_seq_id = v_seq_id  
                       and pad.activity_dtl_seq_id = c.activity_dtl_seq_id;  
        
           if nvl(v_rest_amount,0)!=0 and nvl(v_rest_amount,0)>0 then
               v_used_amount:=nvl(v_used_amount,0)+v_rest_amount;
           end if;  
       
           if v_remain_amount is not null and  v_remain_amount>0 then    
           v_rest_amount:=v_remain_amount;
           end if;       
         END LOOP;  
      END LOOP;    
  
    END IF;
    
---IF THIS CLAIM IS RELATED TO SYSTEM OF MEDICINE THEN THIS CODE WILL EXECUTE 
ELSIF NVL(v_sys_med_yn,'N')='Y' THEN
      v_final_pay := LEAST (v_final_pay,v_sys_med_limit);
    FOR K IN MASTER_ACTIVITY_CODES_OPIP(v_parent_seq_id) LOOP
               v_final_pay:=v_final_pay-NVL(v_used_amount,0);
               v_rest_amount:=v_final_pay;
       FOR L IN PARENT_ACTIVITY_CODES_CUN(k.code,v_parent_seq_id) LOOP
         FOR J IN PARENT_ACTIVITY_CODES_MTN(k.CODE,v_parent_seq_id) LOOP
           v_app_amt := least(l.rule_limit,l.remain_amt)-j.remain_amt;
           v_rest_amount:= least(v_rest_amount,(v_app_amt-NVL(v_used_amount,0)));
           FOR I IN CURRENT_CHILD_ACTIVITY_CODE(k.code) LOOP
              v_rest_amount := least(least(v_rest_amount,i.provider_net_amount),case when i.out_of_pocket_amount is not null then
                                                             	 case when (j.remain_amt- i.out_of_pocket_amount)>0 then
                                                                    (j.remain_amt- i.out_of_pocket_amount) else 0 end
                                                                 else j.remain_amt end);
                      v_rest_amount := CASE WHEN i.approved_amount > v_rest_amount  THEN v_rest_amount  
                                            WHEN i.approved_amount<=v_rest_amount  THEN i.approved_amount  ELSE v_rest_amount END;
                      IF v_rest_amount>=0 THEN
                      v_remain_amount :=NVL(v_remain_amount, least(v_final_pay,l.rule_limit))-(v_rest_amount);
                      END IF;
                      
                      update pat_activity_details pat
                        set  pat.approved_amount  =CASE WHEN v_rest_amount>0 THEN v_rest_amount  ELSE 0 END,
                             pat.allowed_amount   =CASE WHEN v_rest_amount>0 THEN v_rest_amount ELSE 0 END,
                             pat.denial_desc      = case when i.approved_amount  >v_rest_amount then  case when pat.denial_desc is  null then 'Approved as per Original Claims requested amount' else case when pat.denial_code like '%CLM-BENX-005%'then pat.denial_desc else pat.denial_desc||';'||'Approved as per Original Claims requested amount' end end else pat.denial_desc end,
                             pat.denial_code      = case when i.approved_amount  >v_rest_amount then case when pat.denial_code is  null then 'AMNT-REQ-002' else case when pat.denial_code like '%AMNT-REQ-002%'then pat.denial_code else pat.denial_code||';'||'AMNT-REQ-002' end end else pat.denial_code end,
                             pat.denial_by_rule_proc_dtls= case when i.approved_amount >v_rest_amount then 'while validating resubmission limits' end,          
                             pat.updated_by       = v_added_by,
                             pat.updated_date     =sysdate         
                      where pat.activity_dtl_seq_id=i.activity_dtl_seq_id;      
              
              IF NVL(v_rest_amount,0)!=0 AND NVL(v_rest_amount,0)>0 THEN      
               v_used_amount:=NVL(v_used_amount,0)+v_rest_amount;
              END IF;    
               
              IF v_remain_amount IS NOT NULL THEN  
                v_rest_amount:=v_remain_amount;
              END IF;  
            END LOOP;
          END LOOP;
     END LOOP; 
   END LOOP; 

---VALIDATING ACTIVITY CODES WHICH ARE NOT AVILABLE IN PARENT

    FOR H IN  CURRENT_CHILD_ACT_CODE_OTH LOOP
          IF '|'||v_activity_list||'|' LIKE '%'||'|'||h.CODE ||'|'||'%' THEN
                  NULL;
          ELSE
                IF (v_final_pay-v_used_amount)>0 THEN
                  v_final_pay:=v_final_pay-nvl(v_used_amount,0);
                ELSE
                  v_final_pay:=0;
                END IF;
            v_rest_amount:=v_final_pay;
            
               IF h.OVERRIDE_YN='Y' THEN 
                 v_rest_amount := CASE WHEN h.approved_amount > v_rest_amount  THEN v_rest_amount  
                                       WHEN h.approved_amount<=v_rest_amount  THEN h.approved_amount  ELSE v_rest_amount END;
                  if v_rest_amount>=0 then
                    v_remain_amount :=NVL(v_remain_amount,v_final_pay)-(v_rest_amount);
                  end if;
               END IF;
                      UPDATE pat_activity_details pad
                         SET pad.allowed_amount=CASE WHEN h.override_yn='Y' THEN v_rest_amount ELSE 0 END,
                             pad.approved_amount=CASE WHEN h.override_yn='Y' THEN v_rest_amount ELSE 0 END,
                             pad.denial_desc=case when pad.denial_desc is null then 'Claim Information is Inconsistent With Original Claim services' else case when pad.denial_code like '%'||'Claim Information is Inconsistent With Original Claim services' ||'%'   then pad.denial_desc else pad.denial_desc||';'||'Claim Information is Inconsistent With Original Claim services' end end , 
                             pad.denial_code=case when pad.denial_code is null then 'AUTH-CLA-012' else case when pad.denial_code like '%'||'AUTH-CLA-012'||'%' then pad.denial_code else pad.denial_code||';'||'AUTH-CLA-012' end end,
                             pad.remarks=case when pad.denial_code is null then 'Claim Information is Inconsistent With Original Claim services'  else case when pad.denial_code  like '%'||'Claim Information is Inconsistent With Original Claim services' ||'%' then pad.remarks else pad.remarks||';'||'Claim Information is Inconsistent With Original Claim services'  end end,
                             pad.updated_by   = v_added_by,
                             pad.updated_date = SYSDATE
                       WHERE pad.claim_seq_id = v_seq_id  
                       and pad.activity_dtl_seq_id = h.activity_dtl_seq_id;  
               
              IF NVL(v_rest_amount,0)!=0 AND NVL(v_rest_amount,0)>0 THEN      
               v_used_amount:=NVL(v_used_amount,0)+v_rest_amount;
              END IF;  
               
                IF v_remain_amount IS NOT NULL THEN
                v_rest_amount:=v_remain_amount;
                END IF;
             END IF; 
    END LOOP;
END IF;

END  Check_Resub_Activity_Limits;
--======================================================================================================
PROCEDURE select_docs_list(p_seq_id  IN NUMBER,
                           p_flag    IN VARCHAR2,
                           p_result  OUT SYS_REFCURSOR
                           )
AS
  v_flag VARCHAR2(10);
  j      NUMBER;
  v_prs  DBMS_UTILITY.uncl_array;
  v_sql_str varchar2(1000);
BEGIN
  --delete from test_tab;
 --- insert into test_tab values('p_seq_id:'||p_seq_id||CHR(10)||'p_flag:'||p_flag); commit;
  
  j:=1;
  for i in (Select column_value as val from table(cast(ttk_mail_pkg.parse(p_flag,'|') as strings))) loop
    v_prs(j):=i.val;
    j:=j+1;
  end loop;
  
  IF v_prs(1) = 'HOS' AND v_prs(2) = 'CLM' THEN
    v_flag := 'CLM';
  ELSIF v_prs(1) = 'HOS' AND v_prs(2) = 'PAT' THEN
    v_flag := 'PAT';
  ELSIF v_prs(1) = 'PBM' AND v_prs(2) = 'CLM' THEN
    v_flag := 'CLM';
  ELSIF v_prs(1) = 'PBM' AND v_prs(2) = 'PAT' THEN
    v_flag := 'PAT';
  ELSIF v_prs(1) = 'PTR' AND v_prs(2) = 'PAT' THEN
    v_flag := 'PAT';
  ELSIF v_prs(1) = 'PTR' AND v_prs(2) = 'CLM' THEN
    v_flag := 'CLM';
  ELSIF p_flag = 'MOB' AND v_prs(2) = 'PAT' THEN
    v_flag := 'PAT';
  ELSIF p_flag = 'MOB' AND v_prs(2) = 'CLM' THEN
    v_flag := 'CLM';
  ELSIF v_prs(1) = 'CFD' AND v_prs(2) = 'PAT' THEN
    v_flag := 'PAT';
  ELSIF v_prs(1) = 'CFD' AND v_prs(2) = 'CLM' THEN
    v_flag := 'CLM';
  ELSE
    v_flag := p_flag;
  END IF;
  
   v_sql_str:= 'SELECT pc.docs_seq_id,
             pc.pat_clm_seq_id,
             g.description as file_desc,
             pc.file_name,
             to_char(pc.added_date, ''DD/MM/RRRR HH24:MI:SS'') added_date,
             initcap(uc.contact_name) as contact_name,
             pc.file_path,
             pc.reference_seq_id
       FROM pat_clm_docs_tab pc
       left outer join app.preauth_submission ptr on (pc.pat_clm_seq_id = ptr.onl_pat_auth_seq_id)
       left outer JOIN pat_authorization_details p  ON (pc.pat_clm_seq_id = p.pat_auth_seq_id)
       LEFT JOIN tpa_user_contacts uc    ON (uc.contact_seq_id = pc.added_by)
       LEFT JOIN tpa_general_code g      ON (g.general_type_id = pc.file_desc)
       left outer join app.preauth_submission ptr on (pc.pat_clm_seq_id = ptr.onl_pat_auth_seq_id)
       WHERE pat_clm_seq_id = :p_seq_id ';
    
    /*IF v_prs(1) = 'CFD' THEN
       v_sql_str:= v_sql_str||' and pc.reference_from = ''CFD'' order by pc.added_date desc';
    ELSE*/
       v_sql_str:= v_sql_str||'order by pc.added_date desc';
    --END IF;
    
  IF nvl(v_flag, p_flag) = 'PAT' THEN
    OPEN p_result FOR v_sql_str using p_seq_id ;
  ELSIF nvl(v_flag, p_flag) = 'CLM' THEN
    OPEN p_result FOR v_sql_str using p_seq_id ;
  END IF;
END select_docs_list;
--====================================================================================
PROCEDURE Set_Member_Sum_insured (v_mode	 IN	VARCHAR2,
                                  v_seq_id IN NUMBER)
 AS
 
 CURSOR member_ava_sum_ins_clm IS
  SELECT   CASE WHEN nvl(pat_auth_seq_id,0)=0 THEN 
                       available_sum_insured 
                    when nvl(pat_auth_seq_id,0)!=0 then
                       nvl(available_sum_insured,0) + nvl(pat_approved_amount,0)
                END
           FROM (
    SELECT case when (bal.sum_insured-nvl(bal.utilised_sum_insured,0))>0 then 
                   bal.sum_insured-nvl(bal.utilised_sum_insured,0)
              else
                0 
              end as available_sum_insured,cad.pat_auth_seq_id,
              nvl(cad.pat_approved_amount,0) as pat_approved_amount      
          FROM clm_authorization_details cad
               left outer join pat_authorization_details pad on (cad.pat_auth_seq_id= pad.pat_auth_seq_id)
               join tpa_enr_balance bal on (cad.member_seq_id=bal.member_seq_id)
  where cad.claim_seq_id=v_seq_id );
  
  
 CURSOR member_ava_sum_ins_pat IS
  SELECT case when (bal.sum_insured-nvl(bal.utilised_sum_insured,0))>0 then 
                   bal.sum_insured-nvl(bal.utilised_sum_insured,0)
              else
                0 
              end as avilable_sum_insured      
          FROM pat_authorization_details pat
  join tpa_enr_balance bal on (pat.member_seq_id=bal.member_seq_id)
  where pat.pat_auth_seq_id=v_seq_id;  
 
 BEGIN
 
 IF v_mode='PAT' THEN
   
  OPEN member_ava_sum_ins_pat;
    FETCH member_ava_sum_ins_pat INTO v_ava_sum_ins;
      CLOSE member_ava_sum_ins_pat;
 
 ELSIF v_mode='CLM' THEN
 
  OPEN member_ava_sum_ins_clm;
    FETCH member_ava_sum_ins_clm INTO v_ava_sum_ins;
      CLOSE member_ava_sum_ins_clm;
 
 END IF;  
 
 
 END Set_Member_Sum_insured;
--===================================================================================
PROCEDURE Get_Denial_category ( v_act_seq_id  IN NUMBER,
                                v_result_set  OUT SYS_REFCURSOR)
AS

CURSOR DENAIL_LIST (V_ACT_DTL_SEQ_ID  NUMBER) IS
SELECT P.DENIAL_CODE 
FROM PAT_ACTIVITY_DETAILS P
WHERE P.ACTIVITY_DTL_SEQ_ID=V_ACT_DTL_SEQ_ID;

V_DENILS_LIST VARCHAR2(2000);
V_SQL_STR   VARCHAR2(500);  
                              
BEGIN
  OPEN DENAIL_LIST(V_ACT_SEQ_ID);
    FETCH DENAIL_LIST INTO V_DENILS_LIST;
      CLOSE DENAIL_LIST;

  V_DENILS_LIST:=REPLACE(TRIM(';' FROM V_DENILS_LIST),';',''',''');   
  V_SQL_STR :='SELECT REPLACE(WM_CONCAT(DISTINCT D.DENIAL_CATEGORY),'','',''@'') AS DEN_CAT,
               CASE WHEN WM_CONCAT(D.OVERRIDE_YN) LIKE ''%NO%'' THEN ''N'' ELSE ''Y'' END AS OVERRIDE_YN
               FROM TPA_DENIAL_CODES D 
               WHERE D.DENIAL_CODE IN ('''||V_DENILS_LIST||''')';
               
   OPEN v_result_set FOR V_SQL_STR ;
  
END Get_Denial_category ;
 --==========================================================
 -- store logs from claim and preauth level
 -- CR-0393IssueAndRe-issueOfClaims
 ------------------------------------
 PROCEDURE save_pat_clm_logs( p_flag             IN   VARCHAR2
                             ,p_seq_id           IN   NUMBER
                             ,p_log_type_id      IN   VARCHAR2
                             ,p_logs             IN   VARCHAR2
                             ,p_added_by         IN   NUMBER
                             ,p_system_gen_yn    IN   VARCHAR2
                            )IS
                            
   --PRAGMA AUTONOMOUS_TRANSACTION;
   
   CURSOR contact_cur IS SELECT contact_name FROM tpa_user_contacts WHERE contact_seq_id =p_added_by;
   v_contact_rec       contact_cur%ROWTYPE;
   v_log    VARCHAR2(32767);
    
   BEGIN
      OPEN contact_cur;
     FETCH contact_cur INTO v_contact_rec;
     CLOSE contact_cur;
     
     v_log := p_logs||chr(10)||
              'By : '||v_contact_rec.contact_name; 
              
     IF p_flag = 'P' THEN
       
       INSERT INTO tpa_pat_clm_logs( log_seq_id
                                    ,pat_seq_id
                                    ,log_type_id
                                    ,status_log
                                    ,sytem_gen_yn
                                    ,added_by
                                    ,added_date
                                   )
                             VALUES( tpa_patclm_log_seq.nextval
                                    ,p_seq_id
                                    ,p_log_type_id
                                    ,v_log
                                    ,p_system_gen_yn
                                    ,p_added_by
                                    ,SYSDATE
                                   );               
     ELSIF p_flag = 'C' THEN
       
       INSERT INTO tpa_pat_clm_logs( log_seq_id
                                    ,clm_seq_id
                                    ,log_type_id
                                    ,status_log
                                    ,sytem_gen_yn
                                    ,added_by
                                    ,added_date
                                   )
                             VALUES( tpa_patclm_log_seq.nextval
                                    ,p_seq_id
                                    ,p_log_type_id
                                    ,v_log
                                    ,p_system_gen_yn
                                    ,p_added_by
                                    ,SYSDATE
                                   );
     END IF;
     
   --COMMIT;
                                    
 END save_pat_clm_logs;
 --=========================================================
 -- alert log
 -- CR-0393IssueAndRe-issueOfClaims
 -------------------------------------------------------
 PROCEDURE select_alert( p_flag        IN VARCHAR2  --P/C
                        ,p_seq_id      IN NUMBER
                        ,p_log_type    IN VARCHAR2
                        ,p_start_date  IN VARCHAR2
                        ,p_end_date    IN VARCHAR2
                        ,result_set    OUT SYS_REFCURSOR 
                       )IS
   
   v_string    VARCHAR2(32767):=NULL;
   v_str       VARCHAR2(32767):=NULL;
   
   BEGIN
    v_str := 'SELECT a.void_date added_date
                    ,d.description
                    ,''Checqe Re-Issue by ''|| e.contact_name AS remarks
                    ,e.contact_name
                    ,''Y'' system_yn 
               FROM tpa_claims_check a
               JOIN tpa_payment_checks_details b ON(a.claims_chk_seq_id=b.claims_chk_seq_id AND a.check_status=''CSR'')
               JOIN tpa_claims_payment c ON (b.payment_seq_id=c.payment_seq_id)
               JOIN tpa_general_code d ON(a.check_status = d.general_type_id AND d.header_type=''CHEQUE_STATUS'')
               JOIN tpa_user_contacts e ON (a.updated_by=e.contact_seq_id)
              WHERE c.claim_seq_id = :p_seq_id
                AND (to_char(a.void_date,''DD/MM/RRRR'') BETWEEN nvl( :p_start_date,''01/01/2016'') AND nvl(:p_end_date,to_char(SYSDATE,''DD/MM/RRRR'')))';
    
     v_string:= 'SELECT a.added_date
                      ,b.description
                      ,a.status_log remarks
                      ,e.contact_name
                      ,a.SYTEM_GEN_YN system_yn
                 FROM tpa_pat_clm_logs a
                 JOIN tpa_general_code b ON(a.log_type_id=b.general_type_id AND b.header_type=''PAT_CLM_LOGTYPE'')
                 JOIN tpa_user_contacts e ON (a.added_by=e.contact_seq_id)
                WHERE (CASE WHEN :p_flag = ''P'' THEN a.pat_seq_id ELSE a.clm_seq_id END)= :p_seq_id 
                  AND (:p_log_type IS NULL OR a.log_type_id=:p_log_type)
                  AND (to_char(a.added_date,''DD/MM/RRRR'') BETWEEN nvl( :p_start_date,''01/01/2016'') AND nvl(:p_end_date,to_char(SYSDATE,''DD/MM/RRRR'')))' ; 
      
     IF p_log_type = 'REI' THEN
       v_str:='SELECT * FROM ('||v_str||' )A ORDER BY added_date';
       OPEN result_set FOR v_str USING p_seq_id,p_start_date,p_end_date;
     ELSIF p_log_type IS NULL THEN 
       v_string := 'SELECT * FROM ('||v_string||chr(10)||' UNION '||chr(10)||v_str||' )A ORDER BY added_date';
       --dbms_output.put_line(v_string);
       OPEN result_set FOR v_string USING p_flag,p_seq_id,p_log_type,p_log_type,p_start_date,p_end_date,p_seq_id,p_start_date,p_end_date;
     ELSE 
       v_string :=  'SELECT * FROM ('||v_string||' )A ORDER BY added_date';
       OPEN result_set FOR v_string USING p_flag,p_seq_id,p_log_type,p_log_type,p_start_date,p_end_date;
     END IF;  
     
          
 END select_alert;
 --==============================================
  -- alert log
  -- CR-0393IssueAndRe-issueOfClaims
 -------------------------------------------------------
 PROCEDURE user_create_log( p_flag          IN VARCHAR2
                           ,p_seq_id        IN NUMBER
                           ,p_log           IN VARCHAR2
                           ,p_added_by      IN NUMBER
                           ,result_set      OUT NUMBER
                           )IS
   BEGIN
     IF p_flag = 'P' THEN
       INSERT INTO tpa_pat_clm_logs(log_seq_id,pat_seq_id,log_type_id,status_log,sytem_gen_yn,added_by,added_date)
                             VALUES(tpa_patclm_log_seq.nextval,p_seq_id,'USR',p_log,'N',p_added_by,SYSDATE);
     ELSIF p_flag ='C' THEN
       INSERT INTO tpa_pat_clm_logs(log_seq_id,clm_seq_id,log_type_id,status_log,sytem_gen_yn,added_by,added_date)
                             VALUES(tpa_patclm_log_seq.nextval,p_seq_id,'USR',p_log,'N',p_added_by,SYSDATE);
     END IF;
     result_set:=SQL%ROWCOUNT;
                               
 END user_create_log;   
--===================================================================================
end authorization_pkg;

/

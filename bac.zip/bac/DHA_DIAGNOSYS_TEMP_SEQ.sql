--------------------------------------------------------
--  DDL for Synonymn DHA_DIAGNOSYS_TEMP_SEQ
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."DHA_DIAGNOSYS_TEMP_SEQ" FOR "INTX"."DHA_DIAGNOSYS_TEMP_SEQ";

--------------------------------------------------------
--  DDL for Synonymn IDX_ENDORSEMENTS_ADDED_DATE
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."IDX_ENDORSEMENTS_ADDED_DATE" FOR "APP"."IDX_ENDORSEMENTS_ADDED_DATE";

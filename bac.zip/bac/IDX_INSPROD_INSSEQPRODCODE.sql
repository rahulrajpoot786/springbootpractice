--------------------------------------------------------
--  DDL for Synonymn IDX_INSPROD_INSSEQPRODCODE
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."IDX_INSPROD_INSSEQPRODCODE" FOR "APP"."IDX_INSPROD_INSSEQPRODCODE";

--------------------------------------------------------
--  DDL for Synonymn HOSPITALIZATION_PROCDESC
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."HOSPITALIZATION_PROCDESC" FOR "APP"."HOSPITALIZATION_PROCDESC";

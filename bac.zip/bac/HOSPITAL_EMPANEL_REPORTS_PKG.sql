--------------------------------------------------------
--  DDL for Package Body HOSPITAL_EMPANEL_REPORTS_PKG
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "VENUBABU"."HOSPITAL_EMPANEL_REPORTS_PKG" is

-------------------------------------------------------------------------------------
-------------------- Hospital Document sent or mou signed date reports --------------
-- 1 and 7 merged report
-- regarding empanel status is pending
-------------------------------------------------------------------------------------
-- v_param_comb_1 -> 'DOC' or 'SIGMOU'
-- v_param_num_2  -> tpa_office_seq_id
-- v_param_date_3 -> doc_dispatch_date / mou_signed_date (from)
-- v_param_date_4 -> doc_dispatch_date / mou_signed_date (to)

  PROCEDURE  pr_hosp_doc_sent_sigmou_report (
    where_clause              IN VARCHAR2,
    cur                       OUT SYS_REFCURSOR
  )
  IS
    v_where_clause             VARCHAR2( 3000 );
    v_pos                     NUMBER( 3 );
    v_str                     VARCHAR2( 3000 );
    v_param_comb_1            VARCHAR2 ( 250 );
    v_param_num_2             NUMBER( 20 );
    v_param_date_3            DATE;
    v_param_date_4            DATE;


  BEGIN
    v_where_clause := where_clause;
    v_pos          := instr( v_where_clause, '|' ) - 1;
    v_param_comb_1 := substr( v_where_clause, 1, v_pos );
    v_where_clause := substr( v_where_clause, ( v_pos + 2 ) );
    v_pos          := instr( v_where_clause, '|' ) - 1;
    v_param_num_2  := substr( v_where_clause, 1, v_pos );
    v_where_clause := substr( v_where_clause, ( v_pos + 2 ) );
    v_pos          := instr( v_where_clause, '|' ) - 1;
    v_param_date_3 := to_date(substr( v_where_clause, 1, v_pos ),'dd/mm/yyyy');
    v_where_clause := substr( v_where_clause, ( v_pos + 2 ) );
    v_pos          := instr( v_where_clause, '|' ) - 1;
    v_param_date_4 := to_date(substr( v_where_clause, 1, v_pos ),'dd/mm/yyyy');

    IF ( v_param_comb_1 = 'DOC' ) THEN
       v_str :=
      ' SELECT a.empanel_number AS Empanel_number,
               a.hosp_name AS hospital_name,
               a.tpa_regist_date AS tpa_registration_date,
               a.doc_dispatch_date AS document_dispatch_date,
               f.empanel_description AS empanel_status,
               b.address_1||decode(b.address_2,NULL,'''',('',''||b.Address_2))||decode(b.address_3,NULL,'''','',''||b.Address_3) AS hospital_address,
               c.city_description AS city,
               d.state_name AS state
          FROM tpa_hosp_info a,
               tpa_hosp_address b,
               tpa_city_code c,
               tpa_state_code d,
               tpa_hosp_empanel_status e,
               tpa_hosp_empanel_status_code f
         WHERE a.hosp_seq_id = b.hosp_seq_id AND b.city_type_id = c.city_type_id AND b.state_type_id = d.state_type_id
           AND ( a.hosp_seq_id = e.hosp_seq_id AND e.active_yn = ''Y'' )
           AND e.empanel_status_type_id = f.empanel_status_type_id ';

      IF ( v_param_num_2 IS NOT NULL ) THEN
        v_str := v_str ||' AND a.tpa_office_seq_id = '||to_char(v_param_num_2);
      END IF;

      IF ( v_param_date_3 IS NOT NULL ) AND ( v_param_date_4 IS NOT NULL )THEN
        v_str := v_str ||' AND a.doc_dispatch_date between ('''||v_param_date_3||''' AND '''||v_param_date_4||''')'' ';
      END IF;

    ELSIF ( v_param_comb_1 = 'SIGMOU' ) THEN
       v_str :=
      ' SELECT a.empanel_number AS Empanel_number,
               a.hosp_name AS hospital_name,
               a.tpa_regist_date AS tpa_registration_date,
               f.empanel_description AS empanel_status,
               b.address_1||decode(b.address_2,NULL,'''','',''||b.Address_2)||decode(b.address_3,NULL,'''','',''||b.Address_3) AS hospital_address,
               c.city_description AS city,
               d.state_name AS state,
               g.signed_date AS mou_signed_date
          FROM tpa_hosp_info a,
               tpa_hosp_address b,
               tpa_city_code c,
               tpa_state_code d,
               tpa_hosp_empanel_status e,
               tpa_hosp_empanel_status_code f,
               tpa_hosp_general_dtl g
         WHERE a.hosp_seq_id = b.hosp_seq_id AND b.city_type_id = c.city_type_id AND b.state_type_id = d.state_type_id
           AND a.hosp_seq_id = e.hosp_seq_id AND e.active_yn = ''Y''
           AND e.empanel_status_type_id = f.empanel_status_type_id
           AND a.hosp_seq_id = g.hosp_seq_id ';
--           AND e.empanel_status_type_id ='EMP';

      IF ( v_param_num_2 IS NOT NULL ) THEN
        v_str := v_str ||' AND a.tpa_office_seq_id = '''||to_char(v_param_num_2)||'';
      END IF;

      IF ( v_param_date_3 IS NOT NULL ) AND ( v_param_date_4 IS NOT NULL )THEN
        v_str := v_str ||' AND g.mou_signed_date between ('''||v_param_date_3||''' AND '''||v_param_date_4||')';
      END IF;
    END IF;

    OPEN cur FOR v_str || ' order by a.hosp_name ';
  END pr_hosp_doc_sent_sigmou_report;

-------------------------------------------------------------------------------------
-------------- Hospital Document received for selected days range reports -----------
-- 1  b)
-------------------------------------------------------------------------------------
-- v_param_comb_1 -> 'TEN','THIRTY','MORETHAN'
-- v_param_num_2  -> tpa_office_seq_id

  PROCEDURE  pr_hosp_doc_rcvd_report (
    where_clause              IN VARCHAR2,
    cur                       OUT SYS_REFCURSOR
  )
  IS
    v_where_clause             VARCHAR2( 3000 );
    v_pos                     NUMBER( 3 );
    v_str                     VARCHAR2( 3000 );
    v_param_comb_1            VARCHAR2 ( 250 );
    v_param_num_2             NUMBER( 20 );

  BEGIN
    v_where_clause := where_clause;
    v_pos          := instr( v_where_clause, '|' ) - 1;
    v_param_comb_1 := substr( v_where_clause, 1, v_pos );
    v_where_clause := substr( v_where_clause, ( v_pos + 2 ) );
    v_param_num_2 := substr( v_where_clause, 1, v_pos );

    v_str :=
    ' SELECT a.empanel_number AS Empanel_number,
             a.hosp_name AS hospital_name,
             a.tpa_regist_date AS tpa_registration_date,
             a.doc_dispatch_date AS document_dispatch_date,
             f.empanel_description AS empanel_status,
             b.address_1||decode(b.address_2,NULL,'''','',''||b.Address_2)||decode(b.address_3,NULL,'''','',''||b.Address_3) AS hospital_address,
             c.city_description AS city,
             d.state_name AS state,
             g.mou_rcvd_date AS mou_received_date
        FROM tpa_hosp_info a,
             tpa_hosp_address b,
             tpa_city_code c,
             tpa_state_code d,
             tpa_hosp_empanel_status e,
             tpa_hosp_empanel_status_code f,
             tpa_hosp_general_dtl g
       WHERE a.hosp_seq_id = b.hosp_seq_id AND b.city_type_id = c.city_type_id AND b.state_type_id = d.state_type_id
         AND a.hosp_seq_id = e.hosp_seq_id AND e.active_yn = ''Y''
         AND e.empanel_status_type_id = f.empanel_status_type_id
         AND a.hosp_seq_id = g.hosp_seq_id ';

      IF ( v_param_num_2 IS NOT NULL ) THEN
        v_str := v_str ||' AND a.tpa_office_seq_id = '||v_param_num_2;
      END IF;

      IF ( v_param_comb_1 = 'TEN' ) THEN
        v_str := v_str ||'  AND ( g.mou_rcvd_date - a.doc_dispatch_date ) <=10 ';
      ELSIF ( v_param_comb_1= 'THIRTY' ) THEN
        v_str := v_str ||'  AND ( g.mou_rcvd_date - a.doc_dispatch_date ) between 11 and 30 ';
      ELSIF ( v_param_comb_1 = 'MORETHAN' ) THEN
        v_str := v_str ||'  AND ( g.mou_rcvd_date - a.doc_dispatch_date ) > 30 ';
      END IF;

    OPEN cur FOR v_str || '  order by a.hosp_name ';
  END pr_hosp_doc_rcvd_report;

-------------------------------------------------------------------------------------
-------------- Hospital mou received reports -----------
-- 2
-------------------------------------------------------------------------------------
-- v_param_comb_1 -> status of empanelment like EMP,INP,NOT
-- v_param_num_2  -> tpa_office_seq_id
-- v_param_date_3 -> mou_rcvd_date (from)
-- v_param_date_4 -> mou_rcvd_date (to)

  PROCEDURE  pr_hosp_mou_rcvd_report (
    where_clause              IN VARCHAR2,
    cur                       OUT SYS_REFCURSOR
  )
  IS
    v_where_clause             VARCHAR2( 3000 );
    v_pos                     NUMBER( 3 );
    v_str                     VARCHAR2( 3000 );
    v_param_comb_1            VARCHAR2 ( 250 );
    v_param_num_2             NUMBER( 20 );
    v_param_date_3            DATE;
    v_param_date_4            DATE;

  BEGIN
    v_where_clause := where_clause;
    v_pos          := instr( v_where_clause, '|' ) - 1;
    v_param_comb_1 := substr( v_where_clause, 1, v_pos );
    v_where_clause := substr( v_where_clause, ( v_pos + 2 ) );
    v_pos          := instr( v_where_clause, '|' ) - 1;
    v_param_num_2 := substr( v_where_clause, 1, v_pos );
    v_where_clause := substr( v_where_clause, ( v_pos + 2 ) );
    v_pos          := instr( v_where_clause, '|' ) - 1;
    v_param_date_3 := to_date(substr( v_where_clause, 1, v_pos ),'dd/mm/yyyy');
    v_where_clause := substr( v_where_clause, ( v_pos + 2 ) );
    v_param_date_4 := to_date(substr( v_where_clause, 1, v_pos ),'dd/mm/yyyy');

    v_str :=
    ' SELECT a.empanel_number AS Empanel_number,
             a.hosp_name AS hospital_name,
             a.tpa_regist_date AS tpa_registration_date,
             a.doc_dispatch_date AS document_dispatch_date,
             f.empanel_description AS empanel_status,
             b.address_1||decode(b.address_2,NULL,'''','',''||b.Address_2)||decode(b.address_3,NULL,'''','',''||b.Address_3) AS hospital_address,
             c.city_description AS city,
             d.state_name AS state,
             g.mou_rcvd_date AS mou_received_date
        FROM tpa_hosp_info a,
             tpa_hosp_address b,
             tpa_city_code c,
             tpa_state_code d,
             tpa_hosp_empanel_status e,
             tpa_hosp_empanel_status_code f,
             tpa_hosp_general_dtl g
       WHERE a.hosp_seq_id = b.hosp_seq_id AND b.city_type_id = c.city_type_id AND b.state_type_id = d.state_type_id
         AND a.hosp_seq_id = e.hosp_seq_id AND e.active_yn = ''Y''
         AND e.empanel_status_type_id = f.empanel_status_type_id
         AND a.hosp_seq_id = g.hosp_seq_id
         and e.empanel_status_type_id ='''||v_param_comb_1||'''';

      IF ( v_param_num_2 IS NOT NULL ) THEN
        v_str := v_str ||' AND a.tpa_office_seq_id = '||v_param_num_2;
      END IF;
      IF ( v_param_date_3 IS NOT NULL ) AND ( v_param_date_4 IS NOT NULL )THEN
        v_str := v_str ||' AND g.mou_rcvd_date between ('''||v_param_date_3||''' AND '''||v_param_date_4||''')''';
      end if;
    OPEN cur FOR v_str || ' order by a.hosp_name';
  END pr_hosp_mou_rcvd_report;

-----------------------------------------------------------------------
-------------  Hospital Shortfalls -----------------
-- 3rd report
-----------------------------------------------------------------------
-- v_param_comb_1  -> 'MOU','HOS','TAR','VER','REG'
-- v_param_date_2  -> tpa_regist_date  (from)
-- v_param_date_3  -> tpa_regist_date  (to)

  PROCEDURE  pr_hosp_shortfall_report (
    where_clause              IN VARCHAR2,
    cur                       OUT SYS_REFCURSOR
  )
  IS
    v_where_clause             VARCHAR2( 3000 );
    v_pos                     NUMBER( 3 );
    v_str                     VARCHAR2( 3000 );
    v_param_comb_1            VARCHAR2 ( 250 );
    v_param_date_2            DATE;
    v_param_date_3            DATE;
  BEGIN
    v_where_clause := where_clause;
    v_pos           := INSTR( v_where_clause, '|' ) - 1;
    v_param_comb_1  := substr( v_where_clause, 1, v_pos );
    v_where_clause   := substr( v_where_clause, ( v_pos + 2 ) );
    v_pos            := instr( v_where_clause, '|' ) - 1;
    v_param_date_2  := to_date(substr( v_where_clause, 1, v_pos ),'dd/mm/yyyy');
    v_where_clause   := substr( v_where_clause, ( v_pos + 2 ) );
    v_param_date_3  := to_date(v_where_clause,'dd/mm/yyyy');

    IF ( v_param_comb_1 = 'MOU' ) THEN
      v_str := ' c.mou_sent_date is null ';
    ELSIF ( v_param_comb_1 = 'HOS' ) THEN
      v_str := ' c.hosp_info_rcvd_date is null ';
    ELSIF ( v_param_comb_1 = 'TAR' ) THEN
      v_str := ' c.tariff_rcvd_date is null ';
    ELSIF ( v_param_comb_1 = 'VER' ) THEN
      v_str := ' c.hosp_verify_form_rcvd_date is null ';
    ELSIF ( v_param_comb_1 = 'REG' ) THEN
      v_str := ' c.reg_crt_rcvd_date is null ';
    END IF;

     v_str :=
    ' SELECT a.hosp_name,
             a.empanel_number,
             a.tpa_ref_number,
             b.office_name
        FROM
             tpa_hosp_info a,
             tpa_office_info b,
             tpa_hosp_general_dtl c
       WHERE
             a.tpa_office_seq_id = b.tpa_office_seq_id
         AND
             a.hosp_seq_id = c.hosp_seq_id
         AND
             '||v_str||'';

    IF ( v_param_date_2 IS NOT NULL ) AND ( v_param_date_3 IS NOT NULL ) THEN
      v_str  :=  v_str||'  AND a.tpa_regist_date BETWEEN '''||v_param_date_2||''' AND '''||v_param_date_3||'''';
    END IF;

    OPEN cur FOR v_str || ' order by a.hosp_name';
  END pr_hosp_shortfall_report;

-----------------------------------------------------------------------
-------------  Hospital DD Collected reports -----------------
-- 4th report
-----------------------------------------------------------------------
-- v_param_comb_1  -> 'EMP','INP','REN', and etc
-- v_param_num_2   -> tpa_office_seq_id
-- v_param_date_3  -> tpa_regist_date  (from)
-- v_param_date_4  -> tpa_regist_date  (to)

  PROCEDURE  pr_hosp_DD_collect_report (
    where_clause              IN VARCHAR2,
    cur                       OUT SYS_REFCURSOR
  )
  IS
    v_where_clause             VARCHAR2( 3000 );
    v_pos                     NUMBER( 3 );
    v_str                     VARCHAR2( 3000 );
    v_param_comb_1            VARCHAR2 ( 250 );
    v_param_num_2             NUMBER;
    v_param_date_3            DATE;
    v_param_date_4            DATE;
  BEGIN
    v_where_clause := where_clause;
    v_pos          := INSTR( v_where_clause, '|' ) - 1;
    v_param_comb_1 := substr( v_where_clause, 1, v_pos );
    v_where_clause := substr( v_where_clause, ( v_pos + 2 ) );
    v_pos          := instr( v_where_clause, '|' ) - 1;
    v_param_num_2  := substr( v_where_clause, 1, v_pos );
    v_where_clause := substr( v_where_clause, ( v_pos + 2 ) );
    v_pos          := instr( v_where_clause, '|' ) - 1;
    v_param_date_3 := to_date(substr( v_where_clause, 1, v_pos ),'dd/mm/yyyy');
    v_where_clause := substr( v_where_clause, ( v_pos + 2 ) );
    v_param_date_4 := to_date(substr( v_where_clause, 1, v_pos ),'dd/mm/yyyy');

     v_str :=
    ' SELECT a.hosp_name,
             a.empanel_number,
             a.tpa_ref_number,
             b.office_name,
             a.tpa_regist_date,
             c.pay_order_number,
             c.pay_order_received_date,
             c.bank_name,
             c.check_issued_date,
             c.pay_order_amount,
             e.empanel_description
        FROM
             tpa_hosp_info a,
             tpa_office_info b,
             tpa_hosp_general_dtl c,
             tpa_hosp_empanel_status d,
             tpa_hosp_empanel_status_code e
       WHERE
             a.tpa_office_seq_id = b.tpa_office_seq_id
         AND
             a.hosp_seq_id = c.hosp_seq_id
         AND
             c.pay_order_type_id = ''DD''
         AND
             a.hosp_seq_id = d.hosp_seq_id and d.active_yn=''Y''
         AND
             d.empanel_status_type_id = e.empanel_status_type_id ';

    IF ( v_param_comb_1 IS NOT NULL ) THEN
      v_str  :=  v_str||' AND d.empanel_status_type_id = '''||v_param_comb_1||'''';
    END IF;

    IF ( v_param_num_2 IS NOT NULL ) THEN
      v_str  :=  v_str||' AND a.tpa_office_seq_id = '||v_param_num_2;
    END IF;

    IF ( v_param_date_3 IS NOT NULL ) AND ( v_param_date_4 IS NOT NULL ) THEN
      v_str  :=  v_str||'  AND a.tpa_regist_date BETWEEN '''||v_param_date_3||''' AND '''||v_param_date_4||'''';
    END IF;

    OPEN cur FOR v_str ||' ORDER BY a.hosp_name ';

  END pr_hosp_DD_collect_report;

-----------------------------------------------------------------------
-------------  Hospital Empanelment details reports -----------------
-- 5th  report
-- v_param_comb_9  -> tariff plan          (pending)
-----------------------------------------------------------------------
-- v_param_num_1   -> tpa_office_seq_id
-- v_param_date_2  -> empanel_date  (from)
-- v_param_date_3  -> empanel_date  (to)
-- v_param_char_4  -> city
-- v_param_char_5  -> state
-- v_param_comb_6  -> category of hospital
-- v_param_comb_7  -> number of beds  ( any or value)
-- v_param_comb_8  -> grade
-- v_param_comb_9  -> tariff plan                     ( still in pending )
-- v_param_comb_10 -> Status of empanelment

  PROCEDURE  pr_hosp_empanel_dtl_report (
    where_clause              IN VARCHAR2,
    cur                       OUT SYS_REFCURSOR
  )
  IS
    v_where_clause             VARCHAR2( 3000 );
    v_pos                     NUMBER( 3 );
    v_str                     VARCHAR2( 3000 );
    v_param_num_1             NUMBER ;               -- tpa_office_seq_id
    v_param_date_2            DATE;                  -- empanel_date  (from)
    v_param_date_3            DATE;                  -- empanel_date  (to)
    v_param_char_4            VARCHAR2 ( 250 );      -- city
    v_param_char_5            VARCHAR2 ( 250 );      -- state
    v_param_comb_6            VARCHAR2 ( 250 );      -- category of hospital
    v_param_comb_7            VARCHAR2 ( 250 );      -- number of beds  ( any or value)  values - 'TWENTY','FIFTY','TWO_HUNDRED','TWO_HUNDRED_MORE'
    v_param_comb_8            VARCHAR2 ( 250 );      -- grade
    v_param_comb_9            VARCHAR2 ( 250 );      -- tariff plan
    v_param_comb_10           VARCHAR2 ( 250 );      -- Status of empanelment
  BEGIN
    v_where_clause := where_clause;
    v_pos          := INSTR( v_where_clause, '|' ) - 1;
    v_param_num_1  := substr( v_where_clause, 1, v_pos );
    v_where_clause := substr( v_where_clause, ( v_pos + 2 ) );
    v_pos          := instr( v_where_clause, '|' ) - 1;
    v_param_date_2 := to_date(substr( v_where_clause, 1, v_pos ),'dd/mm/yyyy');
    v_where_clause := substr( v_where_clause, ( v_pos + 2 ) );
    v_pos          := instr( v_where_clause, '|' ) - 1;
    v_param_date_3 := to_date(substr( v_where_clause, 1, v_pos ),'dd/mm/yyyy');
    v_where_clause := substr( v_where_clause, ( v_pos + 2 ) );
    v_pos          := instr( v_where_clause, '|' ) - 1;
    v_param_char_4 := substr( v_where_clause, 1, v_pos );
    v_where_clause := substr( v_where_clause, ( v_pos + 2 ) );
    v_pos          := instr( v_where_clause, '|' ) - 1;
    v_param_char_5 := substr( v_where_clause, 1, v_pos );
    v_where_clause := substr( v_where_clause, ( v_pos + 2 ) );
    v_pos          := instr( v_where_clause, '|' ) - 1;
    v_param_comb_6 := substr( v_where_clause, 1, v_pos );
    v_where_clause := substr( v_where_clause, ( v_pos + 2 ) );
    v_pos          := instr( v_where_clause, '|' ) - 1;
    v_param_comb_7 := substr( v_where_clause, 1, v_pos );
    v_where_clause := substr( v_where_clause, ( v_pos + 2 ) );
    v_pos          := instr( v_where_clause, '|' ) - 1;
    v_param_comb_8 := substr( v_where_clause, 1, v_pos );
    v_where_clause := substr( v_where_clause, ( v_pos + 2 ) );
    v_pos          := instr( v_where_clause, '|' ) - 1;
    v_param_comb_9 := substr( v_where_clause, 1, v_pos );
    v_where_clause := substr( v_where_clause, ( v_pos + 2 ) );
    v_param_comb_10:= substr( v_where_clause, 1, v_pos );

     v_str :=
    ' SELECT a.hosp_name,
             a.empanel_number,
             b.address_1||decode(b.address_2,NULL,'''','',''||b.Address_2)||decode(b.address_3,NULL,'''','',''||b.Address_3) AS hospital_address,
             c.city_description as city,
             d.state_name as state,
             e.from_date,
             f.empanel_description as empanel_status,
             g.rson_description,
             h.office_name,
             i.value_1,
             j.approved_grade_type_id,
             k.DESCRIPTION AS category_of_hospital
        FROM
             tpa_hosp_info a,
             tpa_hosp_address b,
             tpa_city_code c,
             tpa_state_code d,
             tpa_hosp_empanel_status e,
             tpa_hosp_empanel_status_code f,
             tpa_hosp_empanel_rson_code g,
             tpa_office_info h,
             tpa_hosp_medical_details i,
             tpa_hosp_grading j,
             tpa_hosp_category_code k
       WHERE
             a.hosp_seq_id = b.hosp_seq_id
         AND
             b.city_type_id = c.city_type_id
         AND
             b.state_type_id = d.state_type_id
         AND
             a.hosp_seq_id = e.hosp_seq_id and e.active_yn=''Y''
         AND
             e.empanel_status_type_id = f.empanel_status_type_id
         AND
             e.empanel_rson_type_id = g.empanel_rson_type_id
         AND
             a.tpa_office_seq_id = h.tpa_office_seq_id
         AND
             a.hosp_seq_id = i.hosp_seq_id
         AND
             a.hosp_seq_id = j.hosp_seq_id
         AND
             j.category_type_id = k.category_type_id';

    IF ( v_param_num_1 IS NOT NULL ) THEN
      v_str  :=  v_str||' AND a.tpa_office_seq_id = '||v_param_num_1;
    END IF;

    IF ( v_param_date_2 IS NOT NULL ) AND ( v_param_date_3 IS NOT NULL ) THEN
      v_str  :=  v_str||'  AND e.from_date BETWEEN '''||v_param_date_2||''' AND '''||v_param_date_3||'''';
    END IF;

    IF ( v_param_char_4 IS NOT NULL ) THEN
      v_str  :=  v_str||' AND b.city_type_id = '''||v_param_char_4||'''';
    END IF;

    IF ( v_param_char_5 IS NOT NULL ) THEN
      v_str  :=  v_str||' AND b.state_type_id = '''||v_param_char_5||'''';
    END IF;

    IF ( v_param_comb_6 IS NOT NULL ) THEN
      v_str  :=  v_str||' AND j.category_type_id = '''||v_param_comb_6||'''';
    END IF;

    IF ( v_param_comb_7 = 'TWENTY') THEN
      v_str  :=  v_str||' AND i.medical_type_id=''TNB'' AND i.value_1 <= 20 ';
    ELSIF ( v_param_comb_7 = 'FIFTY') THEN
      v_str  :=  v_str||' AND i.medical_type_id=''TNB'' AND i.value_1 between 21 and 50 ';
    ELSIF ( v_param_comb_7 = 'TWO_HUNDRED') THEN
      v_str  :=  v_str||' AND i.medical_type_id=''TNB'' AND i.value_1 between 51 and 200 ';
    ELSIF ( v_param_comb_7 = 'TWO_HUNDRED_MORE') THEN
      v_str  :=  v_str||' AND i.medical_type_id=''TNB'' AND i.value_1 > 200 ';
    END IF;

    IF ( v_param_comb_8 IS NOT NULL ) THEN
      v_str  :=  v_str||' AND i.approved_grade_type_id ='''||v_param_comb_8||'''';
    END IF;
    /*
     IF ( v_param_comb_9 IS NOT NULL ) THEN
      v_str  :=  v_str||' AND plan_Seq_id ='|| ;
    END IF;
    */
        IF ( v_param_comb_10 IS NOT NULL ) THEN
      v_str  :=  v_str||' AND e.empanel_status_type_id= '''||v_param_comb_10||'''';
    END IF;

    OPEN cur FOR v_str ||' ORDER BY a.hosp_name ';

  END pr_hosp_empanel_dtl_report;

-----------------------------------------------------------------------
-------------  Hospital details modified reports -----------------
-- 8th report
-----------------------------------------------------------------------
-- v_param_num_1   -> tpa_office_seq_id
-- v_param_date_2  -> added_date (from)
-- v_param_date_3  -> added_date (to)

  PROCEDURE  pr_hosp_log_report (
    where_clause              IN VARCHAR2,
    cur                       OUT SYS_REFCURSOR
  )
  IS
    v_where_clause             VARCHAR2( 3000 );
    v_pos                     NUMBER( 3 );
    v_str                     VARCHAR2( 3000 );
    v_param_num_1             NUMBER ;               -- tpa_office_seq_id
    v_param_date_2            DATE;                  -- empanel_date  (from)
    v_param_date_3            DATE;                  -- empanel_date  (to)
  BEGIN
    v_where_clause := where_clause;
    v_pos          := INSTR( v_where_clause, '|' ) - 1;
    v_param_num_1  := substr( v_where_clause, 1, v_pos );
    v_where_clause := substr( v_where_clause, ( v_pos + 2 ) );
    v_pos          := instr( v_where_clause, '|' ) - 1;
    v_param_date_2 := to_date(substr( v_where_clause, 1, v_pos ),'dd/mm/yyyy');
    v_where_clause := substr( v_where_clause, ( v_pos + 2 ) );
    v_param_date_3 := to_date(substr( v_where_clause, 1, v_pos ),'dd/mm/yyyy');

     v_str := ' SELECT a.hosp_name,
                      a.empanel_number,
                      c.description,
                      c.added_date as modified_date,
                      b.remarks
                 FROM
                      tpa_hosp_info a,
                      tpa_hosp_log b,
                      tpa_hosp_log_code c
                where a.hosp_seq_id = b.hosp_seq_id
                  and b.log_type_id = c.log_type_id';

    IF ( v_param_num_1 IS NOT NULL ) THEN
      v_str  :=  v_str||' AND a.tpa_office_seq_id = '||v_param_num_1;
    END IF;

    IF ( v_param_date_2 IS NOT NULL ) AND ( v_param_date_3 IS NOT NULL ) THEN
      v_str  :=  v_str||'  AND b.added_date BETWEEN '''||v_param_date_2||''' AND '''||v_param_date_3||'''';
    END IF;

    OPEN cur FOR v_str ||' ORDER BY a.hosp_name ';

  END pr_hosp_log_report;

-------------------------------------------------------------------------------------
-------------------- Hospital Empanelment to be expire reports --------------
-- 9th report
-------------------------------------------------------------------------------------
-- v_param_num_1  -> tpa_office_seq_id
-- v_param_comb_2 -> expiry days like 'TEN','THIRTY'

  PROCEDURE  pr_hosp_emp_tobe_expire_report (
    where_clause              IN VARCHAR2,
    cur                       OUT SYS_REFCURSOR
  )
  IS
    v_where_clause             VARCHAR2( 3000 );
    v_pos                     NUMBER( 3 );
    v_str                     VARCHAR2( 3000 );
    v_param_num_1             number;
    v_param_comb_2             VARCHAR2( 250 );
  BEGIN
    v_where_clause := where_clause;
    v_pos          := instr( v_where_clause, '|' ) - 1;
    v_param_num_1  := substr( v_where_clause, 1, v_pos );
    v_where_clause := substr( v_where_clause, ( v_pos + 2 ) );
    v_param_comb_2 := substr( v_where_clause, 1, v_pos );

    v_str :=
      ' SELECT a.empanel_number AS Empanel_number,
               a.hosp_name AS hospital_name,
               b.address_1||decode(b.address_2,NULL,'''','',''||b.Address_2)||decode(b.address_3,NULL,'''','',''||b.Address_3) AS hospital_address,
               c.city_description AS city,
               d.state_name AS state,
               e.from_date as empanel_from_date,
               e.to_date as empanel_to_date,
               approved_grade_type_id
          FROM tpa_hosp_info a,
               tpa_hosp_address b,
               tpa_city_code c,
               tpa_state_code d,
               tpa_hosp_empanel_status e,
               tpa_hosp_empanel_status_code f,
               tpa_hosp_grading g
         WHERE a.hosp_seq_id = b.hosp_seq_id AND b.city_type_id = c.city_type_id AND b.state_type_id = d.state_type_id
           AND ( a.hosp_seq_id = e.hosp_seq_id AND e.active_yn = ''Y'' )
           AND e.empanel_status_type_id = f.empanel_status_type_id
           and a.hosp_seq_id = g.hosp_seq_id ';

      IF ( v_param_num_1 IS NOT NULL ) THEN
        v_str := v_str ||' AND a.tpa_office_seq_id = '||v_param_num_1;
      END IF;

      IF ( v_param_comb_2 = 'TEN' )THEN
        v_str := v_str ||' AND ( e.to_date - sysdate ) <=10 ';
      elsif ( v_param_comb_2 = 'THIRTY' )THEN
        v_str := v_str ||' AND ( e.to_date - sysdate ) between 11 to 30 ';
      END IF;


    OPEN cur FOR v_str || ' order by a.hosp_name ';
  END pr_hosp_emp_tobe_expire_report;

----------------------------------------------------------------------------------------
end hospital_empanel_reports_pkg;

/

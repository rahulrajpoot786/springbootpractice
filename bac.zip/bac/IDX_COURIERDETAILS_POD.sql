--------------------------------------------------------
--  DDL for Synonymn IDX_COURIERDETAILS_POD
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."IDX_COURIERDETAILS_POD" FOR "APP"."IDX_COURIERDETAILS_POD";

--------------------------------------------------------
--  DDL for Synonymn CITIBANK_CLM_HISTORY
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."CITIBANK_CLM_HISTORY" FOR "APP"."CITIBANK_CLM_HISTORY";

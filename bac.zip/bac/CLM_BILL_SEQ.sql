--------------------------------------------------------
--  DDL for Synonymn CLM_BILL_SEQ
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."CLM_BILL_SEQ" FOR "APP"."CLM_BILL_SEQ";

--------------------------------------------------------
--  DDL for Synonymn CLM_BATCH_LOG_TAB
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."CLM_BATCH_LOG_TAB" FOR "APP"."CLM_BATCH_LOG_TAB";

--------------------------------------------------------
--  DDL for Procedure ANALYSE_STATS
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "VENUBABU"."ANALYSE_STATS" 
AS
BEGIN
for i in (select TABLE_NAME,TABLE_OWNER from ALL_INDEXES
where TABLE_OWNER in ('APP','FIN_APP','INTX','IDCARD')) loop
 dbms_stats.unlock_table_stats(i.TABLE_OWNER,i.TABLE_NAME);
 dbms_stats.gather_table_stats(i.TABLE_OWNER,i.TABLE_NAME);
end loop;
END ANALYSE_STATS;

/

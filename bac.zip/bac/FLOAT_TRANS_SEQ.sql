--------------------------------------------------------
--  DDL for Synonymn FLOAT_TRANS_SEQ
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."FLOAT_TRANS_SEQ" FOR "FIN_APP"."FLOAT_TRANS_SEQ";

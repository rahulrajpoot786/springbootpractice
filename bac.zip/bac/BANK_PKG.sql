--------------------------------------------------------
--  DDL for Package Body BANK_PKG
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "VENUBABU"."BANK_PKG" IS
--==============================================================================================
--this procedure is used to display all banks list.
  PROCEDURE select_bank_list(
    v_bank_name                 IN  OUT TPA_BANK_MASTER.bank_name%TYPE,
    v_start_num                 IN  NUMBER ,
    v_end_num                   IN  NUMBER ,
    v_added_by                  IN  NUMBER,
    result_set	                OUT	SYS_REFCURSOR
  )
  IS
     v_sql_str                     VARCHAR2(4000);
  BEGIN
    IF v_bank_name IS NOT NULL THEN
      v_bank_name := UPPER(v_bank_name)||'%';
    END IF;
    v_sql_str :=
     'SELECT
       a.bank_seq_id,
       a.bank_name
       FROM tpa_bank_master A
       WHERE A.ho_id IS NULL
       AND ( :v_bank_name IS NULL OR A.bank_name LIKE :v_bank_name )';

       v_sql_str := 'SELECT * FROM
           (SELECT A.*,DENSE_RANK() OVER (ORDER BY BANK_NAME ASC ,ROWNUM)
            Q FROM (' ||v_sql_str|| ') A ) WHERE  Q>= :v_start_num  AND Q<= :v_end_num ';
       OPEN result_set FOR v_sql_str USING v_bank_name,v_bank_name, v_start_num , v_end_num ;

  END   select_bank_list;
---==================================================================================================
 --this procedure is used to display all branches of the respective bank.
  PROCEDURE select_branch_list(
    v_ho_id                     IN  TPA_BANK_MASTER.ho_id%TYPE,
    v_added_by                  IN  NUMBER,
    result_set                  OUT  SYS_REFCURSOR
  )
  IS
  BEGIN
    OPEN result_set FOR
      SELECT  A.bank_seq_id, A.bank_name FROM tpa_bank_master A
        WHERE A.ho_id = v_ho_id AND A.deleted_yn  = 'N';
  END   select_branch_list;
--========================================================================================================
  --this proceduere is used to edit bank & branch name
  PROCEDURE select_bank_detail(
    v_bank_seq_id                IN OUT  TPA_BANK_MASTER.bank_seq_id%TYPE,
    v_added_by                  IN      NUMBER,
    result_set                  OUT      SYS_REFCURSOR
  )
  IS

  BEGIN
    OPEN result_set FOR
      SELECT A.bank_seq_id,
        A.office_type,
        B.description AS office_type_desc,
        A.ho_id,
        A.bank_name,
        A.contact_person,
        A.address1,
        A.address2,
        A.address3,
        A.state,
        A.city,
        A.pincode,
        A.country,
        A.email_id,
        A.phone_num1,
        A.phone_num2,
        A.mob_number,
        A.fax_no,
        A.remarks,
        A.Acc_File_Name,
        A.ACC_DOC,
        a.IBAN_NO AS IBAN,
        a.usd_iban_no as USD_IBAN, --cr0272/0273
        a.isd_code,
        a.std_code,
        C.cheque_template_id,
        a.euro_iban_no,
        a.gbp_iban_no
        
        FROM tpa_bank_master A LEFT OUTER JOIN tpa_general_code B ON( A.office_type=B.general_type_id )
        LEFT OUTER JOIN cheque_template C ON (A.cheque_template_id=C.cheque_template_id)
        WHERE bank_seq_id = v_bank_seq_id;
  END  select_bank_detail;
 --======================================================================================================
  --This Procedure is used to save a record into bank_master table and it updates also.
  PROCEDURE save_bank(
    v_bank_seq_id               IN OUT TPA_BANK_MASTER.bank_seq_id%TYPE,
    v_bank_name                 IN     TPA_BANK_MASTER.bank_name%TYPE,
    v_ho_id                     IN     TPA_BANK_MASTER.ho_id%TYPE,
    v_contact_person            IN     TPA_BANK_MASTER.contact_person%TYPE,
    v_address1                  IN     TPA_BANK_MASTER.address1%TYPE,
    v_address2                  IN     TPA_BANK_MASTER.address2%TYPE,
    v_address3                  IN     TPA_BANK_MASTER.address3%TYPE,
    v_state                     IN     TPA_BANK_MASTER.state%TYPE,
    v_city                      IN     TPA_BANK_MASTER.city%TYPE,
    v_country                   IN     TPA_BANK_MASTER.country%TYPE,
    v_pincode                   IN     TPA_BANK_MASTER.pincode%TYPE,
    v_email_id                  IN     TPA_BANK_MASTER.email_id%TYPE,
    v_phone_num1                IN     TPA_BANK_MASTER.phone_num1%TYPE,
    v_phone_num2                IN     TPA_BANK_MASTER.phone_num2%TYPE,
    v_mobile_num                IN     TPA_BANK_MASTER.mob_number%TYPE,
    v_fax_num                   IN     TPA_BANK_MASTER.fax_no%TYPE,
    v_remarks                   IN     TPA_BANK_MASTER.remarks%TYPE,
    v_cheque_template_id        IN     CHEQUE_TEMPLATE.cheque_template_id%TYPE,
    v_added_by                  IN     NUMBER,
    v_acc_file_name             IN     TPA_BANK_MASTER.Acc_File_Name%type,
    v_acc_doc                   IN     TPA_BANK_MASTER.Acc_Doc%type,
    v_ifsc_code                 IN     TPA_BANK_MASTER.IBAN_NO%TYPE,
    v_isd_code                  IN     TPA_BANK_MASTER.ISD_CODE%TYPE,
    v_std_code                  IN     TPA_BANK_MASTER.STD_CODE%TYPE,
    v_usd_iban                  IN     TPA_BANK_MASTER.USD_IBAN_NO%TYPE,--cr0272/0273
    v_euro_iban	                IN     TPA_BANK_MASTER.EURO_IBAN_NO%TYPE,
    v_gbp_iban                  IN     TPA_BANK_MASTER.GBP_IBAN_NO%TYPE, 
    v_rows_processed            OUT    INTEGER
  )
  IS
    e_same_bank_name   EXCEPTION;
    PRAGMA EXCEPTION_INIT (e_same_bank_name, -00001);  -- Unique Constraint Violation.
  BEGIN
    --flag zero then insert
    IF (v_bank_seq_id) = 0 THEN
      -- adding BANK
      INSERT INTO tpa_bank_master( bank_seq_id,  office_type,  ho_id,  bank_name,   contact_person,
          address1,  address2,   address3, state,   city,   pincode,  country,   email_id,  phone_num1,
          phone_num2, mob_number, fax_no,  remarks, cheque_template_id, added_by,  added_date,acc_file_name,acc_doc,IBAN_NO,USD_IBAN_NO,isd_code,std_code,euro_iban_no,gbp_iban_no)
      VALUES(fin_app.bank_master_seq.NEXTVAL , CASE WHEN v_ho_id IS NOT NULL THEN 'IBO' ELSE 'IHO' END,  v_ho_id,  v_bank_name,   v_contact_person,  v_address1,
          v_address2,  v_address3,  v_state,   v_city,  v_pincode,    v_country,  v_email_id,  v_phone_num1,
          v_phone_num2,   v_mobile_num, v_fax_num,  v_remarks, v_cheque_template_id,  v_added_by,
          SYSDATE,v_acc_file_name,v_acc_doc,v_ifsc_code,v_usd_iban,v_isd_code,v_std_code,v_euro_iban,v_gbp_iban ) RETURNING bank_seq_id INTO v_bank_seq_id;
    ELSE
      -- update bank details
      UPDATE tpa_bank_master SET
          bank_name            = v_bank_name,
          contact_person       = v_contact_person,
          address1             = v_address1,
          address2             = v_address2,
          address3             = v_address3,
          state                = v_state,
          city                 = v_city,
          pincode              = v_pincode,
          country              = v_country,
          email_id             = v_email_id,
          phone_num1           = v_phone_num1,
          phone_num2           = v_phone_num2,
          mob_number           = v_mobile_num,
          fax_no               = v_fax_num,
          remarks              = v_remarks,
          cheque_template_id   = v_cheque_template_id,
          IBAN_NO              = v_ifsc_code,
          USD_IBAN_NO          = v_usd_iban, --cr0272/0273
          euro_iban_no         = v_euro_iban,
          gbp_iban_no          = v_gbp_iban,
          isd_code             = v_isd_code,
          std_code             = v_std_code,
          updated_by           = v_added_by,
          updated_date         = SYSDATE
          WHERE  bank_seq_id   = v_bank_seq_id;
         
      IF v_acc_file_name is not null and v_acc_doc is not null then
         UPDATE tpa_bank_master SET 
          acc_file_name        = v_acc_file_name,
          acc_doc              = v_acc_doc
         WHERE  bank_seq_id   = v_bank_seq_id;
      END IF;
           
    END IF;
    v_rows_processed := SQL%ROWCOUNT;
    COMMIT;
  EXCEPTION
    WHEN e_same_bank_name  THEN
      RAISE_APPLICATION_ERROR(-20241,'Same Bank Name cannot be issued twice.');
  END save_bank;
--========================================================================================================
--This Procedure is used to  Peramanent Delete a bank from the Database.
  PROCEDURE delete_branch(
    v_bank_seq_id              IN  TPA_BANK_MASTER.bank_seq_id%TYPE,
    v_added_by                IN  NUMBER,
    v_rows_processed          OUT  INTEGER
  )
  IS
    v_flag                   NUMBER(5);
  BEGIN
    --check whether bank having accounts only then dont allow to delete bank.
    SELECT COUNT(1) INTO  v_flag
      FROM  tpa_bank_accounts B
     WHERE B.bank_seq_id = v_bank_seq_id;
    IF (v_flag = 0 ) THEN  --if bank accounts not exists
       DELETE FROM tpa_bank_master WHERE bank_seQ_id = v_bank_seq_id;
    ELSE --if bank account exists display error message.
      RAISE_APPLICATION_ERROR(-20228,'Account(s) are exist! Sorry you cannot delete the bank');
    END IF; --end of if
    v_rows_processed  := SQL%ROWCOUNT;
    COMMIT;
  END delete_branch;
--=======================================================================================================
END bank_pkg;

/

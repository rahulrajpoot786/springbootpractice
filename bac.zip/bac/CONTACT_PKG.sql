--------------------------------------------------------
--  DDL for Package Body CONTACT_PKG
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "VENUBABU"."CONTACT_PKG" 
IS

  -- Procedure to reset password. This would be used only admin to reset password of other TTK Users.
  PROCEDURE reset_password (
    v_contact_seq_id      IN tpa_login_info.contact_seq_id%TYPE,
    v_added_by            IN tpa_login_info.added_by%TYPE,
    v_rows_processed      IN  OUT NUMBER
  )
  IS
    v_len NUMBER(2);
    v_password               tpa_login_info.password%TYPE;
    v_user_id                tpa_login_info.user_id%TYPE;
    v_contact_name           tpa_user_contacts.contact_name%TYPE;
--    v_office_code            tpa_office_info.office_code%TYPE;
--    v_role_name              tpa_roles_code.role_name%TYPE;
    v_employee_number        tpa_user_contacts.employee_number%TYPE;
    v_tpa_office_seq_id      tpa_user_contacts.tpa_office_seq_id%TYPE;
    v_dest_msg_seq_id        VARCHAR2(250);
    v_user_general_type_id   tpa_user_contacts.User_General_Type_Id%TYPE;
 --************************************************
 /* DONT REMOVE commented DMS_INTERFACE_PKG */
 --************************************************

   CURSOR get_password_cur IS
   SELECT B.Primary_Email_Id , b.contact_name, B.user_general_type_id --, c.office_code --, e.role_name
    FROM  tpa_user_contacts B LEFT OUTER JOIN tpa_office_info C ON (B.tpa_office_seq_id = c.tpa_office_seq_id )
--    LEFT OUTER JOIN tpa_user_roles d ON ( b.contact_seq_id = d.contact_seq_id )
--    LEFT OUTER JOIN tpa_roles_code e ON ( d.role_seq_id = e.role_seq_id )
    WHERE b.contact_seq_id = v_contact_seq_id;

    v_conn utl_smtp.connection;
    v_Primary_Email_Id tpa_user_contacts.primary_email_id%TYPE;
    v_admin_email VARCHAR2(130);

  BEGIN
    v_len      := DBMS_RANDOM.VALUE(5,10);
    v_password := DBMS_RANDOM.STRING('X',v_len);

    UPDATE TPA_LOGIN_INFO l SET
           l.password_1=l.password_2,    --Added for CR-KOC1235
           l.password_2=l.password_3,    --Added for CR-KOC1235
           l.password_3=l.password_4,    --Added for CR-KOC1235
           l.password_4=l.password_5,    --Added for CR-KOC1235
           l.password_5=l.password,      --Added for CR-KOC1235
           l.password = ttk_util_pkg.fn_encr_password(v_password ),
           l.default_login_yn  = 'N',
           l.updated_by = v_added_by,
           l.updated_date = SYSDATE,
           l.password_generated_date=NULL,
           L.FIRST_LOGIN_YN='Y' --KOC1257
     WHERE l.contact_seq_id = v_contact_seq_id RETURNING user_id INTO v_user_id;


--- Added by sharmilan on 5-Aug-2006
    OPEN get_password_cur;
    FETCH get_password_cur INTO v_primary_email_id  , v_contact_name, v_user_general_type_id/*, v_office_code , v_role_name */;
    CLOSE get_password_cur;

    v_admin_email := ttk_util_pkg.fn_get_app_config('SITE_ADMIN_EMAIL');
    IF v_admin_email = 'NO_SUCH_PARAM' THEN
      RAISE_APPLICATION_ERROR(-20007,'TTK Admin email is not defined.. ');
    END IF;

    /*v_conn := ttk_mail_pkg.begin_mail(v_admin_email,
                                       v_primary_email_id,
                                      'Access to TTK application');
    ttk_mail_pkg.write_text(v_conn,'Dear Sir/Madam');
    ttk_mail_pkg.write_text(v_conn, '');
    ttk_mail_pkg.write_text(v_conn,'  Your password has been reset to : '||v_password);
--    ttk_mail_pkg.write_text(v_conn, '   Login Id  ' || v_user_id);
    ttk_mail_pkg.write_text(v_conn, '');
    ttk_mail_pkg.write_text(v_conn, '');
    ttk_mail_pkg.write_text(v_conn, 'Regards');
    ttk_mail_pkg.write_text(v_conn, 'TTK Help Desk');
    ttk_mail_pkg.end_mail(v_conn); */
--
 /*   IF v_office_code IS NULL THEN
      SELECT nvl(nvl(nvl(a.tpa_office_seq_id,b.tpa_office_seq_id) ,c.tpa_office_seq_id),d.tpa_office_seq_id) INTO v_tpa_office_seq_id
        FROM tpa_user_contacts a LEFT OUTER JOIN tpa_hosp_info b ON (a.hosp_seq_id = b.hosp_seq_id)
        LEFT OUTER JOIN tpa_ins_info c ON (a.ins_seq_id = c.ins_seq_id)
        LEFT OUTER JOIN tpa_group_registration d ON (a.group_reg_seq_id = d.group_reg_seq_id)
        WHERE a.contact_seq_id = v_contact_seq_id;
      SELECT a.office_code INTO v_office_code
        FROM tpa_office_info a WHERE a.tpa_office_seq_id = v_tpa_office_seq_id ;
    END IF;

     -- CALLING XML Generator.
    DMS_INTERFACE_PKG.user_xml_gen (
        v_employee_number ,
        v_contact_name ,
        v_office_code ,
        v_primary_email_id ,
        v_role_name ,
        v_user_id ,
        v_password ,
        'U'
      ) ;
*/
    v_rows_processed := SQL%ROWCOUNT;

    COMMIT;
    IF v_user_general_type_id = 'COR' THEN
      GENERATE_MAIL_PKG.proc_form_message ( 'RESET_PASSWORD_GROUPID', v_contact_seq_id,v_added_by , v_dest_msg_seq_id );
    ELSIF v_user_general_type_id = 'INS' THEN
      GENERATE_MAIL_PKG.proc_form_message ( 'RESET_PASSWORD_INSCODE', v_contact_seq_id,v_added_by , v_dest_msg_seq_id );
    ELSIF v_user_general_type_id = 'BRO' THEN--broker change password added by Kishor
      GENERATE_MAIL_PKG.proc_form_message ( 'RESET_PASSWORD_BROCODE', v_contact_seq_id,v_added_by , v_dest_msg_seq_id );
       ELSIF v_user_general_type_id = 'HOS' THEN--broker change password added by Kishor
      GENERATE_MAIL_PKG.proc_form_message ( 'RESET_PASSWORD_NHCP', v_contact_seq_id,v_added_by , v_dest_msg_seq_id );
	ELSE
      GENERATE_MAIL_PKG.proc_form_message ( 'RESET_PASSWORD', v_contact_seq_id,v_added_by , v_dest_msg_seq_id );
    END IF;

  END reset_password;
  /*-------------------------------------------------------------------------------------------------
  This will generate the user_id by taking the first four characters of the name
  added with a sequence number. Password is generated as random striong  of length
  between 5 to 10 characters.
  Author S V Sreeraj    Date  16 - 12 - 2005

  */-------------------------------------------------------------------------------------------------
  PROCEDURE gen_user_id(
    v_name          IN tpa_user_contacts.contact_name%TYPE,
    v_user_id       OUT tpa_login_info.user_id%TYPE,
    v_password      OUT tpa_login_info.password%TYPE
  )
  IS
    v_len NUMBER(2);
    v_seq_id NUMBER(12);
  BEGIN
    v_len      := 8;-- DBMS_RANDOM.VALUE(5,10);
    SELECT USER_ID_SEQ.NEXTVAL INTO v_seq_id FROM DUAL;
    v_user_id  := SUBSTR(UPPER(v_name),1,4)||TO_CHAR(v_seq_id);
    v_password := DBMS_RANDOM.STRING('X',v_len);
  END gen_user_id;

  /*-------------------------------------------------------------------------------------------------
    The contacts are not deleted from the contacts table. Instead they can be made active or inactive.
    This procedure converts active_yn flag to 'Y' OR 'N'.
      Author S V Sreeraj    Date  18 - 12 - 2005
    MODIFIED BY:  Nagaraj AH .
    MODIFIED DATE: 18/4/2011 8:52:07 AM
  */-------------------------------------------------------------------------------------------------
 PROCEDURE inactivate_users(
    v_contact_seq_ids  IN VARCHAR2,  -- Concatenated Strings |contact_seq_id|
    v_active_yn        IN VARCHAR2,
    v_rows_processed   OUT NUMBER
  )
  IS
    v_user_general_type_id   tpa_user_contacts.user_general_type_id%TYPE;
    str_tab                  ttk_util_pkg.str_table_type;

   CURSOR prev_usr_dtl_cur(v_contact_id tpa_user_contacts.contact_seq_id%TYPE) IS
               SELECT c.contact_seq_id,c.user_general_type_id,C.active_yn,c.date_of_joining,C.date_of_resignation
                   FROM tpa_user_contacts C
                   WHERE C.contact_seq_id=v_contact_id;
   rec_prev_usr                     prev_usr_dtl_cur%ROWTYPE;

  BEGIN
    str_tab     := ttk_util_pkg.parse_str ( v_contact_seq_ids);
    SELECT user_general_type_id INTO v_user_general_type_id FROM tpa_user_contacts WHERE contact_seq_id = to_number(str_tab(1));

    IF v_user_general_type_id IN ('HOS','INS','COR') THEN
      FOR i IN str_tab.FIRST..(str_tab.COUNT)
      LOOP

        UPDATE tpa_user_contacts
          SET provide_access_user_yn = v_active_yn
                                 WHERE contact_seq_id = to_number(str_tab(i));
          UPDATE tpa_login_info SET active_yn = v_active_yn  WHERE contact_seq_id = str_tab(i);
      END LOOP;
	 
    ELSIF v_user_general_type_id IN('BRO') THEN
          FOR i IN str_tab.FIRST..(str_tab.COUNT)
      LOOP

        UPDATE tpa_user_contacts
          SET provide_access_user_yn = v_active_yn, active_yn = v_active_yn
                                 WHERE contact_seq_id = to_number(str_tab(i));
          UPDATE tpa_login_info SET active_yn = v_active_yn  WHERE contact_seq_id = str_tab(i);
      END LOOP;	 
	  
    ELSE
      FOR i IN str_tab.FIRST..(str_tab.COUNT)
      LOOP

        OPEN prev_usr_dtl_cur(to_number(str_tab(i)));
             FETCH prev_usr_dtl_cur INTO rec_prev_usr;
        CLOSE prev_usr_dtl_cur;

        IF (rec_prev_usr.user_general_type_id='TTK' AND rec_prev_usr.Date_Of_Joining  IS NULL  AND v_active_yn='Y') THEN--ADDED FOR KOC1085 CR
          raise_application_error(-20806,'Please enter the Date of Joining for all the employees. ');
         ELSIF (rec_prev_usr.user_general_type_id='TTK' AND rec_prev_usr.date_of_resignation IS NOT NULL  AND v_active_yn='Y') THEN
          raise_application_error(-20808,'Please remove the Date of Resignation for all the employees. ');
        END IF;

        UPDATE tpa_user_contacts C
          SET active_yn = v_active_yn
        WHERE contact_seq_id = to_number(str_tab(i));

        UPDATE tpa_login_info
          SET active_yn = v_active_yn
        WHERE contact_seq_id = to_number(str_tab(i));

      END LOOP;
    END IF;
    v_rows_processed := (str_tab.COUNT);
    COMMIT;
  END inactivate_users;
 ------------------------------------------------------
 PROCEDURE inactivate_contacts(
    v_contact_seq_ids  IN VARCHAR2,  -- Concatenated Strings |contact_seq_id|
    v_active_yn        IN VARCHAR2,
    v_rows_processed   OUT NUMBER
  )
  IS
    v_provide_access_user_yn tpa_user_contacts.provide_access_user_yn%TYPE;
    v_user_general_type_id   tpa_user_contacts.user_general_type_id%TYPE;
    str_tab                  ttk_util_pkg.str_table_type;
  BEGIN
    str_tab     := ttk_util_pkg.parse_str ( v_contact_seq_ids);

    FOR i IN str_tab.FIRST..(str_tab.COUNT)
    LOOP
      UPDATE tpa_user_contacts
        SET active_yn = v_active_yn
        WHERE contact_seq_id = str_tab(i)
        RETURNING user_general_type_id,provide_access_user_yn
        INTO v_user_general_type_id, v_provide_access_user_yn;
      IF ((v_user_general_type_id IN ('CAL','TTK','DMC','BRO') OR v_provide_access_user_yn = 'Y')) THEN
       UPDATE tpa_login_info
         SET active_yn = v_active_yn
         WHERE contact_seq_id = str_tab(i);
         UPDATE tpa_user_contacts
           SET provide_access_user_yn =  v_active_yn WHERE contact_seq_id = str_tab(i);
      END IF;
    END LOOP;
    v_rows_processed := (str_tab.COUNT);
    COMMIT;
  END inactivate_contacts;
   /*----------------------------------------------------------------------------------------------------------
    A ll the contacts are stored in the table tpa_user_contacts.(ie. like NHCP,CALL centre,Insurance,Corporate,
    TTK ) This procedure for adding and editing the details of contacts.
    Author S V Sreeraj    Date  20 - 12 - 2005
    MODIFIED BY:  Nagaraj AH .
    MODIFIED DATE: 18/4/2011 8:52:07 AM
 */----------------------------------------------------------------------------------------------------------
PROCEDURE save_contacts(
    v_contact_seq_id                 IN OUT tpa_user_contacts.contact_seq_id%TYPE,
    v_user_general_type_id           IN tpa_user_contacts.user_general_type_id%TYPE,--'PTR'  'PARTNER USER'
    v_hosp_seq_id                    IN tpa_user_contacts.hosp_seq_id%TYPE,
    v_ins_seq_id                     IN tpa_user_contacts.ins_seq_id%TYPE,
    v_tpa_office_seq_id              IN tpa_user_contacts.tpa_office_seq_id%TYPE,
    v_group_reg_seq_id               IN tpa_user_contacts.group_reg_seq_id%TYPE,
    v_prefix_general_type_id         IN tpa_user_contacts.prefix_general_type_id%TYPE,
    v_contact_name                   IN tpa_user_contacts.contact_name%TYPE,
    v_designation_type_id            IN tpa_user_contacts.designation_type_id%TYPE,
    v_primary_email_id               IN tpa_user_contacts.primary_email_id%TYPE,
    v_secondary_email_id             IN tpa_user_contacts.secondary_email_id%TYPE,
    v_active_yn                      IN tpa_user_contacts.active_yn%TYPE,
    v_provide_access_user_yn         IN tpa_user_contacts.provide_access_user_yn%TYPE,
    v_contact_type_id                IN tpa_user_contacts.contact_type_id%TYPE,
    v_spec_type_id                   IN tpa_user_contacts.spec_type_id%TYPE,
    v_dr_regist_nmbr                 IN tpa_user_contacts.dr_regist_nmbr%TYPE,
    v_dr_qualif                      IN tpa_user_contacts.dr_qualif%TYPE,
    v_resident_dr_yn                 IN tpa_user_contacts.resident_dr_yn%TYPE,
    v_employee_number                IN tpa_user_contacts.employee_number%TYPE,
    v_dept_general_type_id           IN tpa_user_contacts.dept_general_type_id%TYPE,
    v_res_phone_no                   IN tpa_user_contacts.res_phone_no%TYPE,
    v_off_phone_no_1                 IN tpa_user_contacts.off_phone_no_1%TYPE,
    v_off_phone_no_2                 IN tpa_user_contacts.off_phone_no_2%TYPE,
    v_mobile_no                      IN tpa_user_contacts.mobile_no%TYPE,
    v_fax_no                         IN tpa_user_contacts.fax_no%TYPE,
    v_contact_pa_limit               IN  TPA_USER_CONTACTS.contact_pa_limit%TYPE,
    v_contact_claim_limit            IN  TPA_USER_CONTACTS.contact_claim_limit%TYPE,
    v_added_by                       IN tpa_user_contacts.added_by%TYPE,
    v_user_id                        IN OUT tpa_login_info.user_id%TYPE,           -- Login Name
    v_role_seq_id                    IN tpa_user_roles.role_seq_id%TYPE,               -- For TPA_USER_ROLES
    v_bank_seq_id                    IN tpa_user_contacts.bank_seq_id%TYPE,               -- For TPA_USER_ROLES
    v_softcopy_access_yn             IN tpa_user_contacts.softcopy_access_yn%TYPE,
    v_softcopy_other_branch_yn       IN tpa_user_contacts.softcopy_other_branch_yn%TYPE,
    v_date_of_joining                IN tpa_user_contacts.date_of_joining%TYPE,    --ADDED FOR KOC1085 CR
    v_date_of_resignation            IN tpa_user_contacts.date_of_resignation%TYPE,    --ADDED FOR KOC1085 CR
    v_row_processed                  OUT number,
    v_ACCN_LOCKED_YN                 IN tpa_login_info.ACCN_LOCKED_YN%TYPE,    --Added for CR-KOC1235
    v_prof_id                        IN tpa_user_contacts.hosp_prof_id%type,
    v_prof_authority                 IN tpa_user_contacts.prof_authority%type,
    v_start_date                     IN tpa_user_contacts.start_date%type,
    v_end_date                       IN tpa_user_contacts.end_date%type,
    v_std_code                       IN tpa_user_contacts.std_code%type,
    v_isd_code                       IN tpa_user_contacts.isd_code%type,
    v_prof_file                      IN tpa_user_contacts.prof_file%type,
    v_prof_file_name                 IN tpa_user_contacts.prof_file_name%type,
    v_consult_gen_type               IN tpa_user_contacts.consult_gen_type%type,
    v_nationality_id                 IN tpa_user_contacts.nationality_id%type,
    v_gender_general_type            IN tpa_user_contacts.gender_general_type%type,
    v_age                            In tpa_user_contacts.age%type,
    v_prov_cont_yn                   IN tpa_user_contacts.prov_cont_yn%type,
    V_PROF_BATCH_SEQ_ID              IN tpa_professional_batch_dtls.prof_batch_seq_id%type,
    v_speciality_id                  IN tpa_user_contacts.speciality_id%type,
    v_ptnr_seq_id                    IN tpa_user_contacts.ptnr_seq_id%TYPE,--new_added  for partner
    v_designation_name               IN tpa_user_contacts.designation%type,--new_added  for partner
    v_ptnr_user_type                 IN tpa_user_contacts.ptnr_user_type%type,---new_added  for partner
    ---------------------------------------------------------------------------
    v_vip_pat_email                      IN  TPA_USER_CONTACTS.vip_pat_email%TYPE DEFAULT 'N',
    v_vip_pat_sms                        IN  TPA_USER_CONTACTS.vip_pat_sms%TYPE DEFAULT 'N',
    v_vip_pat_primary                    IN  TPA_USER_CONTACTS.vip_pat_primary%TYPE DEFAULT 'N',
    v_vip_pat_alternate                  IN  TPA_USER_CONTACTS.vip_pat_alternate%TYPE DEFAULT 'N',
    v_vip_pat_cnh_req                    IN  TPA_USER_CONTACTS.vip_pat_cnh_req%TYPE DEFAULT 'N',
    v_vip_pat_freq                       IN  TPA_USER_CONTACTS.vip_pat_freq%TYPE DEFAULT NULL,
    -----------------------------------------------------------------------------
    v_vip_clm_email                      IN  TPA_USER_CONTACTS.vip_clm_email%TYPE DEFAULT 'N',
    v_vip_clm_sms                        IN  TPA_USER_CONTACTS.vip_clm_sms%TYPE DEFAULT 'N',
    v_vip_clm_primary                    IN  TPA_USER_CONTACTS.vip_clm_primary%TYPE DEFAULT 'N',
    v_vip_clm_alternate                  IN  TPA_USER_CONTACTS.vip_clm_alternate%TYPE DEFAULT 'N',
    v_vip_clm_ctm_req                    IN  TPA_USER_CONTACTS.vip_clm_ctm_req%TYPE DEFAULT 'N',
    v_vip_clm_cnh_req                    IN  TPA_USER_CONTACTS.vip_clm_cnh_req%TYPE DEFAULT 'N',
    v_vip_clm_freq                       IN  TPA_USER_CONTACTS.vip_clm_freq%TYPE DEFAULT NULL,
    -------------------------------------------------------------------------------
    v_non_vip_pat_email                  IN  TPA_USER_CONTACTS.non_vip_pat_email%TYPE DEFAULT 'N',
    v_non_vip_pat_sms                    IN  TPA_USER_CONTACTS.non_vip_pat_sms%TYPE DEFAULT 'N',
    v_non_vip_pat_primary                IN  TPA_USER_CONTACTS.non_vip_pat_primary%TYPE DEFAULT 'N',
    v_non_vip_pat_alternate              IN  TPA_USER_CONTACTS.non_vip_pat_alternate%TYPE DEFAULT 'N',
    v_non_vip_pat_cnh_req                IN  TPA_USER_CONTACTS.non_vip_pat_cnh_req%TYPE DEFAULT 'N',
    v_non_vip_pat_freq                   IN  TPA_USER_CONTACTS.non_vip_pat_freq%TYPE DEFAULT NULL,
    -----------------------------------------------------------------------------
    v_non_vip_clm_email                  IN  TPA_USER_CONTACTS.non_vip_clm_email%TYPE DEFAULT 'N',
    v_non_vip_clm_sms                    IN  TPA_USER_CONTACTS.non_vip_clm_sms%TYPE DEFAULT 'N',
    v_non_vip_clm_primary                IN  TPA_USER_CONTACTS.non_vip_clm_primary%TYPE DEFAULT 'N',
    v_non_vip_clm_alternate              IN  TPA_USER_CONTACTS.non_vip_clm_alternate%TYPE DEFAULT 'N',
    v_non_vip_clm_ctm_req                IN  TPA_USER_CONTACTS.non_vip_clm_ctm_req%TYPE DEFAULT 'N',
    v_non_vip_clm_cnh_req                IN  TPA_USER_CONTACTS.non_vip_clm_cnh_req%TYPE DEFAULT 'N',
    v_non_vip_clm_freq                   IN  TPA_USER_CONTACTS.non_vip_clm_freq%TYPE DEFAULT NULL,
    -----------------------------------------------------------------------------------
    v_vip_pat_rej                        IN TPA_USER_CONTACTS.vip_pat_rej%TYPE DEFAULT 'N',
    V_vip_clm_rej                        IN TPA_USER_CONTACTS.vip_clm_rej%TYPE DEFAULT 'N'
    -----------------------------------------------------------------------------------    
  )
  IS
    v_ctr                              NUMBER(1) := 0;
    v_password                         TPA_LOGIN_INFO.PASSWORD%TYPE;
    v_group_branch_seq_id              TPA_GROUP_BRANCH.group_branch_seq_id%TYPE;
    v_dest_msg_id                      VARCHAR2(100);
    v_dest_msg_seq_id        DESTINATION_MESSAGE.DEST_MSG_SEQ_ID%TYPE;
    CURSOR prev_usr_dtl_cur IS
               SELECT c.contact_seq_id,C.active_yn,c.date_of_joining,C.date_of_resignation
                   FROM tpa_user_contacts C
                   WHERE C.contact_seq_id=v_contact_seq_id;

   rec_prev_usr                     prev_usr_dtl_cur%ROWTYPE;
   v_str                            varchar2(10000); --Added for koc1233
   
   ---broker
   
      CURSOR tpa_bro_cur IS
               select  aa.tpa_office_seq_id from app.tpa_bro_info aa
               left outer join tpa_user_contacts bb on aa.ins_seq_id=bb.ins_seq_id
               where aa.ins_seq_id=v_ins_seq_id;

      rec_tpa_bro_usr                     tpa_bro_cur%ROWTYPE;
      v_tpa_office_seq_id_new             tpa_user_contacts.tpa_office_seq_id%TYPE;
     V_CNT                              NUMBER(10);
     V_PROVIDER_LOG_SEQ_ID          tpa_provider_logs.provider_log_seq_id%type;
     v_aut_cnt       NUMBER(10);
  
  CURSOR pre_prof_cur IS 
  SELECT c.start_date,c.end_date,c.hosp_seq_id FROM tpa_user_contacts c WHERE c.hosp_prof_id=v_prof_id;
  
  pre_prof_rec   pre_prof_cur%rowtype;
  BEGIN
  
   IF (v_user_general_type_id = 'TTK') THEN
     OPEN prev_usr_dtl_cur;
        FETCH prev_usr_dtl_cur INTO rec_prev_usr;
     CLOSE prev_usr_dtl_cur;

     IF TRUNC(v_date_of_resignation)>TRUNC(SYSDATE) THEN--ADDED FOR KOC1085 CR
        raise_application_error(-20810,'Date of Resignation cannot be greater than current date. ');
     END IF;

     IF (v_date_of_resignation IS NOT NULL AND v_active_yn='Y')  THEN--ADDED FOR KOC1085 CR
         CASE rec_prev_usr.active_yn
            WHEN 'Y' THEN
               raise_application_error(-20805,'Please uncheck the Active checkbox inorder to inactive the employee. ');
            WHEN 'N' THEN
               raise_application_error(-20807,'Please remove the Date of Resignation inorder to active the employee. ');
         END CASE;
     END IF;
   END IF;
   IF v_prof_id IS NOT NULL /*AND v_hosp_seq_id IS NOT NULL*/ THEN 
     SELECT COUNT(1) INTO V_CNT from app.tpa_user_contacts uc WHERE uc.hosp_prof_id=v_prof_id;
    SELECT COUNT(1) INTO v_aut_cnt from app.dha_clinicians_list_master lm where lm.clinitian_id=v_prof_id;
   IF v_aut_cnt=0 THEN
     raise_application_error(-20872,'Professional id is not matching with DHPO .');
     --save_provider_logs(v_provider_log_seq_id,v_tpa_office_seq_id,v_hosp_seq_id,v_prof_id,v_contact_name,v_prof_authority,20872,'Doctot is already exist under this Provider','D',v_added_by,v_prof_batch_seq_id);
   ELSIF V_CNT>0 THEN
      OPEN pre_prof_cur;
      FETCH pre_prof_cur INTO pre_prof_rec;
      close pre_prof_cur;
       IF pre_prof_rec.hosp_seq_id!=v_hosp_seq_id THEN
         IF trunc(nvl(v_start_date,SYSDATE)) BETWEEN pre_prof_rec.start_date AND pre_prof_rec.end_date AND 
           v_consult_gen_type NOT IN ('VCPH','CPH')THEN
           raise_application_error(-20874,'This License number is already associated  with another Provider.');
         END IF;
       /* ELSIF pre_prof_rec.hosp_seq_id=v_hosp_seq_id THEN
          raise_application_error(-20873,'Doctot is already exist under this Provider.');*/
      END IF;
   END IF;
   END IF;
    IF v_user_general_type_id='BRO' THEN
        OPEN tpa_bro_cur;
        FETCH tpa_bro_cur INTO rec_tpa_bro_usr;
         CLOSE tpa_bro_cur;
        v_tpa_office_seq_id_new             :=rec_tpa_bro_usr.tpa_office_seq_id;
    END IF;
    
  IF nvl(v_contact_seq_id,0) = 0 THEN -- added nvl 
      IF v_user_general_type_id='BRO' THEN
      INSERT INTO tpa_user_contacts (
        contact_seq_id,
        user_general_type_id,
        hosp_seq_id,
        ins_seq_id,
        ptnr_seq_id,--NEWLY ADDED for partner
        tpa_office_seq_id,
        group_reg_seq_id,
        prefix_general_type_id,
        contact_name,
        designation_type_id,
        primary_email_id,
        secondary_email_id,
        active_yn,
        provide_access_user_yn,
        contact_type_id,
        spec_type_id,
        dr_regist_nmbr,
        dr_qualif,
        resident_dr_yn,
        employee_number,
        dept_general_type_id,
        res_phone_no,
        off_phone_no_1,
        off_phone_no_2,
        mobile_no,
        fax_no,
        contact_pa_limit,
        contact_claim_limit ,
        bank_seq_id,
        softcopy_access_yn,
        softcopy_other_branch_yn,
        date_of_joining,--ADDED FOR KOC1085 CR
        date_of_resignation,--ADDED FOR KOC1085 CR
        designation,   --newly added for partner
        ptnr_user_type,--newly added for partner
        added_by,
        added_date,
      -----------------------
      vip_pat_sms,              
      vip_pat_email,
      vip_pat_primary,
      vip_pat_alternate,
      vip_pat_cnh_req, 
      vip_pat_freq ,
      -------------------------
      vip_clm_sms, 
      vip_clm_email,
      vip_clm_primary,
      vip_clm_alternate, 
      vip_clm_ctm_req, 
      vip_clm_cnh_req,
      vip_clm_freq, 
      ---------------------------
      non_vip_pat_sms, 
      non_vip_pat_email, 
      non_vip_pat_primary, 
      non_vip_pat_alternate,  
      non_vip_pat_cnh_req,
      non_vip_pat_freq , 
      ------------------------
      non_vip_clm_sms, 
      non_vip_clm_email ,
      non_vip_clm_primary ,
      non_vip_clm_alternate, 
      non_vip_clm_ctm_req,
      non_vip_clm_cnh_req, 
      non_vip_clm_freq,  
      -------------------------
      vip_pat_rej, 
      vip_clm_rej
      ---------------------
             )
      VALUES 
            (
        tpa_contact_seq.NEXTVAL,
        v_user_general_type_id,
        v_hosp_seq_id,
        v_ins_seq_id,
        v_ptnr_seq_id,--NEWLY ADDED for partner
        v_tpa_office_seq_id_new,
        v_group_reg_seq_id,
        v_prefix_general_type_id,
        UPPER(v_contact_name),
        v_designation_type_id ,
        v_primary_email_id,
        v_secondary_email_id,
        v_active_yn,
        v_provide_access_user_yn,
        v_contact_type_id,
        v_spec_type_id  ,
        v_dr_regist_nmbr ,
        v_dr_qualif,
        v_resident_dr_yn,
        v_employee_number,
        v_dept_general_type_id,
        v_res_phone_no,
        v_off_phone_no_1,
        v_off_phone_no_2,
        v_mobile_no,
        v_fax_no ,
        v_contact_pa_limit,
        v_contact_claim_limit ,
        v_bank_seq_id,
        v_softcopy_access_yn,
        v_softcopy_other_branch_yn,
        v_date_of_joining,--ADDED FOR KOC1085 CR
        v_date_of_resignation,--ADDED FOR KOC1085 CR
        v_designation_name, --newly added for partner
        v_ptnr_user_type,--newly added for partner
        v_added_by,
        SYSDATE,
        ------------------
        v_vip_pat_sms,                            
        v_vip_pat_email,
        v_vip_pat_primary,
        v_vip_pat_alternate,
        v_vip_pat_cnh_req,
        v_vip_pat_freq,
        -------------------
        v_vip_clm_sms,
        v_vip_clm_email,
        v_vip_clm_primary,
        v_vip_clm_alternate,
        v_vip_clm_ctm_req, 
        v_vip_clm_cnh_req,
        v_vip_clm_freq,
        ---------------------
        v_non_vip_pat_sms,
        v_non_vip_pat_email,
        v_non_vip_pat_primary,
        v_non_vip_pat_alternate,
        v_non_vip_pat_cnh_req,                     
        v_non_vip_pat_freq,
        -----------------------
        v_non_vip_clm_sms,
        v_non_vip_clm_email,
        v_non_vip_clm_primary,
        v_non_vip_clm_alternate,
        v_non_vip_clm_ctm_req,
        v_non_vip_clm_cnh_req,
        v_non_vip_clm_freq,
        ----------------------
        v_vip_pat_rej,
        v_vip_clm_rej
        -----------------------
        ) RETURNING contact_seq_id INTO v_contact_seq_id;
        else
       INSERT INTO tpa_user_contacts (
        contact_seq_id,
        user_general_type_id,
        hosp_seq_id,
        ins_seq_id,
        ptnr_seq_id,--NEWLY ADDED for partner
        tpa_office_seq_id,
        group_reg_seq_id,
        prefix_general_type_id,
        contact_name,
        designation_type_id,
        primary_email_id,
        secondary_email_id,
        active_yn,
        provide_access_user_yn,
        contact_type_id,
        spec_type_id,
        dr_regist_nmbr,
        dr_qualif,
        resident_dr_yn,
        employee_number,
        dept_general_type_id,
        res_phone_no,
        off_phone_no_1,
        off_phone_no_2,
        mobile_no,
        fax_no,
        contact_pa_limit,
        contact_claim_limit ,
        bank_seq_id,
        softcopy_access_yn,
        softcopy_other_branch_yn,
        date_of_joining,--ADDED FOR KOC1085 CR
        date_of_resignation,--ADDED FOR KOC1085 CR
        added_by,
        added_date,
        hosp_prof_id,
        prof_authority,
        start_date,
        end_date,
        std_code,
        isd_code,
        prof_file_name,
        prof_file,
        consult_gen_type,
        nationality_id,
        gender_general_type,
        age,
        prov_cont_yn,
        speciality_id,
        designation,--newly added for partner
        ptnr_user_type, --newly added for partner
      -----------------------
      vip_pat_sms,              
      vip_pat_email,
      vip_pat_primary,
      vip_pat_alternate,
      vip_pat_cnh_req, 
      vip_pat_freq ,
      -------------------------
      vip_clm_sms, 
      vip_clm_email,
      vip_clm_primary,
      vip_clm_alternate, 
      vip_clm_ctm_req, 
      vip_clm_cnh_req,
      vip_clm_freq, 
      ---------------------------
      non_vip_pat_sms, 
      non_vip_pat_email, 
      non_vip_pat_primary, 
      non_vip_pat_alternate,  
      non_vip_pat_cnh_req,
      non_vip_pat_freq , 
      ------------------------
      non_vip_clm_sms, 
      non_vip_clm_email ,
      non_vip_clm_primary ,
      non_vip_clm_alternate, 
      non_vip_clm_ctm_req,
      non_vip_clm_cnh_req, 
      non_vip_clm_freq,  
      -------------------------
      vip_pat_rej, 
      vip_clm_rej
      ---------------------
            )
      VALUES 
            (
        tpa_contact_seq.NEXTVAL,
        v_user_general_type_id,
        v_hosp_seq_id,
        v_ins_seq_id,
        v_ptnr_seq_id,----NEWLY ADDED
        v_tpa_office_seq_id,
        v_group_reg_seq_id,
        v_prefix_general_type_id,
        UPPER(v_contact_name),
        v_designation_type_id ,
        v_primary_email_id,
        v_secondary_email_id,
        v_active_yn,
        v_provide_access_user_yn,
        v_contact_type_id,
        v_spec_type_id  ,
        v_dr_regist_nmbr ,
        v_dr_qualif,
        v_resident_dr_yn,
        v_employee_number,
        v_dept_general_type_id,
        v_res_phone_no,
        v_off_phone_no_1,
        v_off_phone_no_2,
        v_mobile_no,
        v_fax_no ,
        v_contact_pa_limit,
        v_contact_claim_limit ,
        v_bank_seq_id,
        v_softcopy_access_yn,
        v_softcopy_other_branch_yn,
        v_date_of_joining,--ADDED FOR KOC1085 CR
        v_date_of_resignation,--ADDED FOR KOC1085 CR
        v_added_by,
        SYSDATE,
        v_prof_id,
        v_prof_authority,
        v_start_date,
        v_end_date,
        v_std_code,
        v_isd_code,
        v_prof_file_name,
        v_prof_file,
        v_consult_gen_type,
        v_nationality_id,
        v_gender_general_type,
        v_age,
        v_prov_cont_yn,
        v_speciality_id,
        v_designation_name, --newly addded for partner
        v_ptnr_user_type,  --newly added for partner
        ------------------
        v_vip_pat_sms,                            
        v_vip_pat_email,
        v_vip_pat_primary,
        v_vip_pat_alternate,
        v_vip_pat_cnh_req,
        v_vip_pat_freq,
        -------------------
        v_vip_clm_sms,
        v_vip_clm_email,
        v_vip_clm_primary,
        v_vip_clm_alternate,
        v_vip_clm_ctm_req, 
        v_vip_clm_cnh_req,
        v_vip_clm_freq,
        ---------------------
        v_non_vip_pat_sms,
        v_non_vip_pat_email,
        v_non_vip_pat_primary,
        v_non_vip_pat_alternate,
        v_non_vip_pat_cnh_req,                     
        v_non_vip_pat_freq,
        -----------------------
        v_non_vip_clm_sms,
        v_non_vip_clm_email,
        v_non_vip_clm_primary,
        v_non_vip_clm_alternate,
        v_non_vip_clm_ctm_req,
        v_non_vip_clm_cnh_req,
        v_non_vip_clm_freq,
        ----------------------
        v_vip_pat_rej,
        v_vip_clm_rej
        ----------------------- 
         ) RETURNING contact_seq_id INTO v_contact_seq_id;
        end if;
        IF ((v_user_general_type_id IN ('CAL','TTK','DMC','BRO', 'COR', 'HOS', 'INS','PTR') OR v_provide_access_user_yn = 'Y')) THEN
           -- Calling User id and password generator.
           ----------------------------------------------
           gen_user_id(v_contact_name,v_user_id,v_password);

           save_login(
              v_contact_seq_id,
              v_user_id,
              v_password,
              v_role_seq_id,
              v_primary_email_id,
              v_active_yn,
              v_employee_number,
              v_contact_name ,
              v_tpa_office_seq_id ,
              v_added_by,
              v_accn_locked_yn    --Added for CR-KOC1235
           );
           if v_user_general_type_id = 'TTK' then
            GENERATE_MAIL_PKG.proc_form_message ( 'MAIL_USER_PASSWORD', v_contact_seq_id,1 , v_dest_msg_seq_id );
            elsif v_user_general_type_id = 'CAL' then
            GENERATE_MAIL_PKG.proc_form_message ( 'CALL_USER_PASSWORD', v_contact_seq_id,1 , v_dest_msg_seq_id );
            end if;
        END IF;

        --Associating the TTK user to the default group
        IF v_user_general_type_id = 'TTK' THEN

          ---SELECT B.group_branch_seq_id INTO v_group_branch_seq_id
           --- FROM tpa_groups A JOIN tpa_group_branch B ON (A.group_seq_id = B.group_seq_id AND B.tpa_office_seq_id = v_tpa_office_seq_id AND A.default_group_yn = 'Y') ;

          save_grp_assoc_user (
              v_group_branch_seq_id ,
              '|'||v_contact_seq_id||'|',
              v_added_by ,
              v_row_processed
            );
        END IF;

    ELSE
         --Below query used to maintain the log
         ---Added for KOC1233
       SELECT  ('|'||  (CASE v_prefix_general_type_id WHEN 'PMR' THEN 'Mr.' WHEN 'MRS' THEN 'Mrs.' WHEN 'PMS' THEN 'Ms.' WHEN 'PDR' THEN 'Dr.' END)
             ||'|'||  v_contact_name
             ||'|'||  (SELECT b.designation_description FROM  tpa_designation_code b  WHERE  b.DESIGNATION_TYPE_ID=v_designation_type_id)
             ||'|'||  NVL(v_primary_email_id,'Blank')
             ||'|'||  NVL(v_secondary_email_id,'Blank')
             ||'|'||  (CASE v_active_yn  WHEN 'Y' THEN 'Active' WHEN 'N' THEN 'Inactive' END)
             ||'|'||  (CASE v_provide_access_user_yn WHEN 'Y' THEN 'Yes' WHEN 'N' THEN 'No' END)
             ||'|'||  (SELECT contact_description FROM tpa_hosp_contact_code WHERE  contact_type_id=v_contact_type_id)
             ||'|'||  NVL(v_employee_number,0)
             ||'|'||  NVL((SELECT c.description FROM tpa_general_code c WHERE c.general_type_id=v_dept_general_type_id),0)
             ||'|'||  NVL(v_res_phone_no,0)
             ||'|'||  NVL(v_off_phone_no_1,0)
             ||'|'||  NVL(v_off_phone_no_2,0)
             ||'|'||  NVL(v_mobile_no,0)
             ||'|'||  NVL(v_fax_no,0)
             ||'|'||  NVL(v_contact_pa_limit,0)
             ||'|'||  NVL(v_contact_claim_limit,0)
             ||'|'||  NVL((CASE v_softcopy_access_yn WHEN 'Y' THEN 'Yes' ELSE 'No' END),0)
             ||'|'||  NVL((CASE v_softcopy_other_branch_yn WHEN 'Y' THEN 'Yes' ELSE 'No' END),0)
             ||'|'||  v_date_of_joining
             ||'|'||  nvl(to_char(to_Date(v_date_of_resignation,'dd-mm-yyyy'),'dd-mm-yyyy'),to_char('00-00-00'))
             ||'|'||  NVL((select role_name from tpa_roles_code WHERE role_seq_id=v_role_seq_id),0)
             ||'|'||  NVL((select office_name from tpa_office_info where tpa_office_seq_id=v_tpa_office_seq_id),0)
             --||'|'||  NVL(v_pa_sms_yn,0)
             ||'|'||  NVL(v_dr_regist_nmbr,0)
             ||'|'||  NVL(v_dr_qualif,0)
             ||'|'||  NVL((CASE WHEN v_resident_dr_yn='Y' THEN 'Yes' ELSE 'No' END),'No')
             ||'|'||  NVL((select description  FROM tpa_hosp_dr_speciality_code  WHERE spec_type_id=v_spec_type_id),'Blank')
             ||'|'||  NVL(v_designation_name,0)||'|')  --------newly added
             INTO v_str FROM DUAL;

      create_user_acn_log(v_contact_seq_id,v_str,v_added_by);   ---Added for KOC1233
      IF v_user_general_type_id NOT IN ('TTK','CAL','DMC','BRO') AND v_provide_access_user_yn = 'N' THEN
        UPDATE tpa_login_info SET active_yn = 'N' WHERE contact_seq_id = v_contact_seq_id;
      ELSIF ((v_user_general_type_id IN ('CAL','TTK','DMC','BRO') OR v_provide_access_user_yn = 'Y')) THEN
           SELECT COUNT(1) INTO v_ctr FROM tpa_login_info WHERE contact_seq_id = v_contact_seq_id;
           IF V_CTR = 0 THEN
             -- Calling User id and password generator.
             ----------------------------------------------
             gen_user_id(v_contact_name,v_user_id,v_password);
               

      
           END IF;
      END IF;

      UPDATE tpa_user_contacts  SET
        prefix_general_type_id         = v_prefix_general_type_id,
        tpa_office_seq_id              = v_tpa_office_seq_id,
        contact_name                   = UPPER(v_contact_name),
        designation_type_id            = v_designation_type_id,
        primary_email_id               = v_primary_email_id,
        secondary_email_id             = v_secondary_email_id,
        active_yn                      = v_active_yn,
        provide_access_user_yn         = v_provide_access_user_yn,
        contact_type_id                = v_contact_type_id,
        spec_type_id                   = v_spec_type_id,
        dr_regist_nmbr                 = v_dr_regist_nmbr,
        dr_qualif                      = v_dr_qualif ,
        resident_dr_yn                 = v_resident_dr_yn,
        employee_number                = v_employee_number,
        dept_general_type_id           = v_dept_general_type_id,
        res_phone_no                   = v_res_phone_no,
        off_phone_no_1                 = v_off_phone_no_1,
        off_phone_no_2                 = v_off_phone_no_2,
        mobile_no                      = v_mobile_no,
        fax_no                         = v_fax_no,
        contact_pa_limit               = v_contact_pa_limit,
        contact_claim_limit            = v_contact_claim_limit ,
        updated_by                     = v_added_by,
        softcopy_access_yn             = v_softcopy_access_yn,
        softcopy_other_branch_yn       = v_softcopy_other_branch_yn,
        date_of_joining                = v_date_of_joining,
        date_of_resignation            = v_date_of_resignation,
        updated_date                   = SYSDATE,
        hosp_prof_id                   = v_prof_id,
        prof_authority                 = v_prof_authority,
        start_date                     = v_start_date,
        end_date                       = v_end_date,
        STD_CODE                       = v_std_code,
        isd_code                       = v_isd_code,
        PROF_FILE_name                 = v_prof_file_name,
        PROF_FILE                      = v_prof_file,
        CONSULT_GEN_TYPE               = v_consult_gen_type,
        NATIONALITY_ID                 = v_nationality_id,
        GENDER_GENERAL_TYPE            = v_gender_general_type,
        age                            = v_age,
        SPECIALITY_ID                  = v_speciality_id,
        designation                    = v_designation_name, --newly added for partner
        ptnr_user_type                 = v_ptnr_user_type,  --newly added for partner
      
        
        --PROV_CONT_YN                   = v_prov_cont_yn
        ----------------------------------------------------
      vip_pat_sms                             = v_vip_pat_sms,
      vip_pat_email                           = v_vip_pat_email,
      vip_pat_primary                         = v_vip_pat_primary,
      vip_pat_alternate                       = v_vip_pat_alternate,
      vip_pat_cnh_req                         = v_vip_pat_cnh_req,
      vip_pat_freq                            = v_vip_pat_freq,
      -----------------------------------------------------
      vip_clm_sms                             = v_vip_clm_sms,
      vip_clm_email                           = v_vip_clm_email,
      vip_clm_primary                         = v_vip_clm_primary,
      vip_clm_alternate                       = v_vip_clm_alternate,
      vip_clm_ctm_req                         = v_vip_clm_ctm_req, 
      vip_clm_cnh_req                         = v_vip_clm_cnh_req,
      vip_clm_freq                            = v_vip_clm_freq,
      -----------------------------------------------------
      non_vip_pat_sms                         = v_non_vip_pat_sms,
      non_vip_pat_email                       = v_non_vip_pat_email,
      non_vip_pat_primary                     = v_non_vip_pat_primary,
      non_vip_pat_alternate                   = v_non_vip_pat_alternate,
      non_vip_pat_cnh_req                     = v_non_vip_pat_cnh_req,                     
      non_vip_pat_freq                        = v_non_vip_pat_freq,
      ----------------------------------------------------
      non_vip_clm_sms                         = v_non_vip_clm_sms,
      non_vip_clm_email                       = v_non_vip_clm_email,
      non_vip_clm_primary                     = v_non_vip_clm_primary,
      non_vip_clm_alternate                   = v_non_vip_clm_alternate,
      non_vip_clm_ctm_req                     = v_non_vip_clm_ctm_req,
      non_vip_clm_cnh_req                     = v_non_vip_clm_cnh_req,
      non_vip_clm_freq                        = v_non_vip_clm_freq,
      ----------------------------------------------------
      vip_pat_rej                             = v_vip_pat_rej,
      vip_clm_rej                             = v_vip_clm_rej
      ------------------------------------------------------
        WHERE contact_seq_id = v_contact_seq_id;

      IF ((v_user_general_type_id IN ('CAL','TTK','DMC','BRO', 'HOS', 'INS', 'COR','PTR') OR v_provide_access_user_yn = 'Y')) THEN
           save_login(
              v_contact_seq_id,
              v_user_id,
              v_password,
              v_role_seq_id,
              v_primary_email_id,
              v_active_yn,
              v_employee_number,
              v_contact_name ,
              v_tpa_office_seq_id ,
              v_added_by,
              v_accn_locked_yn     --Added for CR-KOC1235
           );

       END IF;
    END IF;
    v_row_processed := SQL%ROWCOUNT;
    COMMIT;
    
  END save_contacts;

  /*-------------------------------------------------------------------------------------------------*/
  
  PROCEDURE save_den_mail(
    v_contact_seq_id        IN tpa_user_contacts.contact_seq_id%TYPE,
    v_pat_app_yn            IN tpa_user_contacts.pat_app_yn%TYPE,
    v_pat_rej_yn            IN tpa_user_contacts.pat_rej_yn%TYPE,
    v_clm_app_yn            IN tpa_user_contacts.clm_app_yn%TYPE,
    v_clm_rej_yn            IN tpa_user_contacts.clm_rej_yn%TYPE )

  IS
  
  BEGIN
    
      UPDATE tpa_user_contacts
         SET pat_app_yn = v_pat_app_yn,
             pat_rej_yn = v_pat_rej_yn,
             clm_app_yn = v_clm_app_yn,
             clm_rej_yn = v_clm_rej_yn
       WHERE contact_seq_id = v_contact_seq_id;
  
  END SAVE_DEN_MAIL;    

  /*-------------------------------------------------------------------------------------------------
    The details including that of user_id and password of all application users are stored to the
    table tpa_login_info.
      Author S V Sreeraj    Date  20 - 12 - 2005
  */-------------------------------------------------------------------------------------------------
   PROCEDURE save_login(
    v_contact_seq_id        IN tpa_login_info.contact_seq_id%TYPE,
    v_user_id               IN OUT tpa_login_info.user_id%TYPE,
    v_password              IN tpa_login_info.password%TYPE,
    v_role_seq_id           IN tpa_user_roles.role_seq_id%TYPE,
    v_primary_email_id      IN tpa_user_contacts.primary_email_id%TYPE,
    v_active_yn             IN tpa_login_info.active_yn%TYPE,
    v_employee_number       IN tpa_user_contacts.employee_number%TYPE,
    v_contact_name          IN tpa_user_contacts.contact_name%TYPE,
    v_tpa_office_seq_id     IN tpa_office_info.tpa_office_seq_id%TYPE ,
    v_added_by              IN tpa_login_info.added_by%TYPE,
    v_accn_locked_yn        IN tpa_login_info.ACCN_LOCKED_YN%TYPE    --Added for CR-KOC1235

  )
  IS
    v_seq_id         NUMBER;
    v_conn utl_smtp.connection;
    v_admin_email    VARCHAR2(130);
--    v_role_name      tpa_roles_code.role_name%TYPE;
--    v_office_code    tpa_office_info.office_code%TYPE;
--    v_user_tpa_office_seq_id   tpa_office_info.tpa_office_seq_id%TYPE := v_tpa_office_seq_id;
    v_dest_msg_seq_id       VARCHAR2(250);
    v_user_general_type_id  TPA_USER_CONTACTS.user_general_type_id%TYPE;
    
    v_user_general_type_id_ptr  TPA_USER_CONTACTS.user_general_type_id%TYPE;
--    v_mode           CHAR(1);
 --************************************************
 /* DONT REMOVE commented DMS_INTERFACE_PKG */
 --************************************************
  /*  CURSOR xml_cur IS
     WITH role_tab AS ( SELECT a.role_name  FROM tpa_roles_code a WHERE a.role_seq_id = v_role_seq_id ),
     office_tab AS ( SELECT b.office_code FROM tpa_office_info b WHERE b.tpa_office_seq_id = v_user_tpa_office_seq_id )
     SELECT a.role_name, b.office_code FROM role_tab a, office_tab b ;
    */
    
    
    CURSOR type_cur IS 
     SELECT a.user_general_type_id,
            CASE WHEN HES.EMPANEL_STATUS_TYPE_ID= 'EMP' THEN 'Y' ELSE 'N' END AS empanel_status_yn,
            nvl(a.empnl_mail_trigr_yn,'N') as empnl_mail_trigr_yn
      FROM tpa_user_contacts A 
      LEFT OUTER JOIN TPA_HOSP_INFO HI ON (A.HOSP_SEQ_ID=HI.HOSP_SEQ_ID)
      LEFT OUTER JOIN TPA_HOSP_ADDRESS HA ON (HI.HOSP_SEQ_ID = HA.HOSP_SEQ_ID)
      LEFT OUTER JOIN TPA_HOSP_EMPANEL_STATUS HES ON (HI.HOSP_SEQ_ID = HES.HOSP_SEQ_ID AND HES.ACTIVE_YN = 'Y')
      WHERE A.contact_seq_id = v_contact_seq_id;

	cursor type_cur_ptnr
     is
       SELECT a.user_general_type_id,
            CASE WHEN HES.EMPANEL_STATUS_TYPE_ID= 'EMP' THEN 'Y' ELSE 'N' END AS empanel_status_yn,
            nvl(a.empnl_mail_trigr_yn,'N') as empnl_mail_trigr_yn
      FROM tpa_user_contacts A 
      LEFT OUTER JOIN TPA_PARTNER_INFO HI ON (A.PTNR_SEQ_ID=HI.PTNR_SEQ_ID)
      LEFT OUTER JOIN TPA_PARTNER_ADDRESS HA ON (HI.PTNR_SEQ_ID = HA.PTNR_SEQ_ID)
      LEFT OUTER JOIN TPA_PARTNER_EMPANEL_STATUS HES ON (HI.PTNR_SEQ_ID = HES.PTNR_SEQ_ID AND HES.ACTIVE_YN = 'Y')
      WHERE A.contact_seq_id = v_contact_seq_id;
      
      
      v_ptnr_empanel_yn        VARCHAR2(10);
       
  v_hosp_empanel_yn        VARCHAR2(10);
  v_empnl_mail_trigr_yn    VARCHAR2(10);
  
  BEGIN
    
   
    
    SELECT COUNT(1) INTO v_seq_id FROM tpa_login_info WHERE contact_seq_id = v_contact_seq_id;
    IF v_seq_id = 0 THEN
      INSERT INTO tpa_login_info (
        contact_seq_id,
        user_id,
        password,
        active_yn,
        default_login_yn ,
        first_login_yn,  --KOC1257
        added_by,
        added_date)
      VALUES(
        v_contact_seq_id,
        v_user_id,
        TTK_UTIL_PKG.fn_encr_password(v_password),
        v_active_yn,
        'Y',
        'Y',  --KOC1257
        v_added_by,
        SYSDATE
      );
-- Added by sharmilan on 5-Aug-2006

    v_admin_email := ttk_util_pkg.fn_get_app_config('SITE_ADMIN_EMAIL');
    IF v_admin_email = 'NO_SUCH_PARAM' THEN
      RAISE_APPLICATION_ERROR(-20007,' TTK Admin email is not defined.. ');
    END IF;
   /* v_conn := ttk_mail_pkg.begin_mail(v_admin_email,
                                       v_primary_email_id,
                                      'Access to TTK application');
    ttk_mail_pkg.write_text(v_conn,'Dear Sir/Madam');
    ttk_mail_pkg.write_text(v_conn, '');
    ttk_mail_pkg.write_text(v_conn,'  Click below URL to access the ttk application');
--    ttk_mail_pkg.write_text(v_conn, '   http://10.1.0.208:8085/ttk/index.jsp');
    ttk_mail_pkg.write_text(v_conn, ' http://10.1.0.200/ttk/index.jsp');
    ttk_mail_pkg.write_text(v_conn, '   Your Login information is ');
    ttk_mail_pkg.write_text(v_conn, '   Login Id  ' || v_user_id);
    ttk_mail_pkg.write_text(v_conn, '   Password  '||v_password);
    ttk_mail_pkg.write_text(v_conn, '');
    ttk_mail_pkg.write_text(v_conn, '');
    ttk_mail_pkg.write_text(v_conn, 'Regards');
    ttk_mail_pkg.write_text(v_conn, 'TTK Help Desk');
    ttk_mail_pkg.end_mail(v_conn); */

    -- Added by CSP for testing purpose on August 8th 2007
    OPEN type_cur;
    FETCH type_cur INTO v_user_general_type_id,v_hosp_empanel_yn,v_empnl_mail_trigr_yn;
    CLOSE type_cur;
    
    open type_cur_ptnr;
    fetch type_cur_ptnr into v_user_general_type_id_ptr,v_ptnr_empanel_yn,v_empnl_mail_trigr_yn;
    close type_cur_ptnr;
 
 ---newly added
 
  IF v_user_general_type_id = 'COR' THEN
      GENERATE_MAIL_PKG.proc_generate_message ( 'NEW_USERID_GROUPID', v_contact_seq_id,v_added_by , v_dest_msg_seq_id );
    ELSIF v_user_general_type_id = 'INS' THEN
      GENERATE_MAIL_PKG.proc_generate_message ( 'NEW_USERID_INSCODE', v_contact_seq_id,v_added_by , v_dest_msg_seq_id );
    ELSIF v_user_general_type_id = 'BRO' THEN
      GENERATE_MAIL_PKG.proc_generate_message ( 'BROKER_USER_ID', v_contact_seq_id,v_added_by , v_dest_msg_seq_id ); 
    ELSIF v_user_general_type_id = 'HOS' AND v_hosp_empanel_yn = 'Y' AND v_empnl_mail_trigr_yn = 'N' THEN
      GENERATE_MAIL_PKG.proc_form_message ( 'PROVIDER_USER_ID', v_contact_seq_id,v_added_by , v_dest_msg_seq_id );
    ELSIF v_user_general_type_id_ptr = 'PTR' and v_ptnr_empanel_yn = 'Y' and v_empnl_mail_trigr_yn = 'N' THEN
      GENERATE_MAIL_PKG.proc_generate_message ( 'PARTNER_USER_ID', v_contact_seq_id,v_added_by , v_dest_msg_seq_id );
    ELSE
      GENERATE_MAIL_PKG.proc_form_message ( 'NEW_USERID', v_contact_seq_id,v_added_by , v_dest_msg_seq_id );
    
	END IF;   
--

      INSERT INTO tpa_user_roles(
         user_role_seq_id,
         contact_seq_id,
         role_seq_id ,
         added_by,
         added_date)
      VALUES(
         tpa_user_roles_seq.NEXTVAL,
         v_contact_seq_id,
         v_role_seq_id,
         v_added_by,
         SYSDATE);

     ELSE
       UPDATE tpa_login_info SET
        active_yn            = v_active_yn,
        updated_by           = v_added_by,
        updated_date         = SYSDATE,
     accn_locked_yn       = v_accn_locked_yn,    --Added for CR-KOC1235
        wrong_attempts       = NULL         --Added for CR-KOC1235
       WHERE contact_seq_id = v_contact_seq_id;

       UPDATE tpa_user_roles SET
         role_seq_id  = v_role_seq_id,
         added_by = v_added_by,
         added_date = SYSDATE
       WHERE contact_seq_id = v_contact_seq_id;
    END IF;
  END save_login;
  /*-------------------------------------------------------------------------------------------------
    This procedure is for fetching the details of contacts for editing. The REFCURSOR general_cur
    return the details regarding the contacts and REFCURSOR detail_cur returns the Communication
    details of the contact.
      Author S V Sreeraj    Date  22 - 12 - 2005
  */-------------------------------------------------------------------------------------------------
   PROCEDURE select_contact (
    v_contact_seq_id        IN  OUT tpa_login_info.contact_seq_id%TYPE,
    user_cur                OUT SYS_REFCURSOR
  )
  IS

  BEGIN
   
  OPEN user_cur FOR
      SELECT B.user_id,
        A.user_general_type_id,
        A.contact_seq_id,
        A.hosp_seq_id,
        A.ptnr_seq_id,---newly added for partner
        A.ins_seq_id,
        A.tpa_office_seq_id,
        A.group_reg_seq_id ,
        A.bank_seq_id,
        A.prefix_general_type_id,
        A.contact_name,
        A.designation_type_id ,
        A.designation AS DESIGNATIONS,---newly added for partner
        J.designation_description  AS designation  ,
        A.primary_email_id,
        A.secondary_email_id,
        A.active_yn user_active_yn,
        A.provide_access_user_yn,
        A.contact_type_id ,
        A.spec_type_id ,
        A.dr_regist_nmbr ,
        A.dr_qualif,
        A.resident_dr_yn,
        A.employee_number,
        A.res_phone_no,
        A.off_phone_no_1,
        A.off_phone_no_2,
        A.mobile_no,
        A.fax_no,
        A.dept_general_type_id ,
        C.role_seq_id,
        D.role_name,
        G.empanel_number,
        H.empanel_number AS PTNR_EMPANEL_NUMBER,---newly added for partner
        F.abbrevation_code||'-'||F.ins_comp_code_number INS_OFFICE_CODE,
        F.ins_comp_name,
        G.hosp_name,
        H.partner_name,---newly added for partner
        I.group_id,
        I.group_name ,
        a.contact_pa_limit ,
        a.contact_claim_limit ,
        a.softcopy_access_yn,
        a.softcopy_other_branch_yn,
        a.date_of_joining,
        a.date_of_resignation,
        B.accn_locked_yn,    --Added for CR-KOC1235
        a.pat_app_yn,
        a.pat_rej_yn,
        a.clm_app_yn,
        a.clm_rej_yn,
        a.hosp_prof_id,
        a.prof_authority,
        a.start_date,
        a.end_date,
        A.std_code,
        A.isd_code,
        a.prof_file_name,
        a.prof_file,
        a.consult_gen_type,
        a.nationality_id,
        a.gender_general_type as gender,
        a.age,a.speciality_id as speciality,
        a.ptnr_user_type,   ---newly added for partner
        -----------------
        a.vip_pat_sms,
        a.vip_pat_email,
        a.vip_pat_primary,
        a.vip_pat_alternate,
        a.vip_pat_cnh_req,
        a.vip_pat_freq,
        -----------------
        a.vip_clm_sms,
        a.vip_clm_email,
        a.vip_clm_primary,
        a.vip_clm_alternate,
        a.vip_clm_ctm_req,
        a.vip_clm_cnh_req,
        a.vip_clm_freq,
        ------------------
        a.non_vip_pat_sms,
        a.non_vip_pat_email,
        a.non_vip_pat_primary,
        a.non_vip_pat_alternate,
        a.non_vip_pat_cnh_req,
        a.non_vip_pat_freq,
        --------------------
        a.non_vip_clm_sms,
        a.non_vip_clm_email,
        a.non_vip_clm_primary,
        a.non_vip_clm_alternate,
        a.non_vip_clm_ctm_req,
        a.non_vip_clm_cnh_req,
        a.non_vip_clm_freq,
        ---------------------
        a.vip_pat_rej,
        a.vip_clm_rej
        ----------------------
        FROM tpa_user_contacts A
        LEFT OUTER JOIN  tpa_login_info B ON (A.contact_seq_id  = B.contact_seq_id)
        LEFT OUTER JOIN tpa_user_roles C ON (A.contact_seq_id = C.contact_seq_id)
        LEFT OUTER JOIN tpa_roles_code D ON (C.role_seq_id  = D.role_seq_id )
        LEFT OUTER JOIN tpa_office_info E ON (A.tpa_office_seq_id = E.tpa_office_seq_id)
        LEFT OUTER JOIN tpa_ins_info F ON (A.ins_seq_id = F.ins_seq_id)
        LEFT OUTER JOIN tpa_hosp_info G ON (A.hosp_seq_id = G.hosp_seq_id)
        LEFT OUTER JOIN tpa_partner_info H ON (A.ptnr_seq_id = h.ptnr_seq_id)  ---newly added for partner
        LEFT OUTER JOIN tpa_group_registration I ON (A.group_reg_seq_id = I.group_reg_seq_id)
        LEFT OUTER JOIN tpa_designation_code J ON (A.designation_type_id = J.designation_type_id)
        WHERE A.contact_seq_id = v_contact_seq_id ;    
  END select_contact;
  /*-------------------------------------------------------------------------------------------------
    Procedure to add or modify new Roles to the TPA_ROLES_CODE table.
      Author S V Sreeraj    Date  22 - 12 - 2005
  */-------------------------------------------------------------------------------------------------
  PROCEDURE save_roles(
    v_role_seq_id                    IN OUT tpa_roles_code.role_seq_id%TYPE,
    v_role_name                      IN tpa_roles_code.role_name%TYPE,
    v_role_desc                      IN tpa_roles_code.role_desc%TYPE,
    v_privilege                      IN tpa_roles_code.privilege%TYPE,
    v_user_general_type_id           IN tpa_roles_code.user_general_type_id%TYPE,
    v_added_by                       IN tpa_roles_code.added_by%TYPE,
    v_row_processed                  OUT NUMBER
  )
  IS
    v_ctr                            NUMBER := 0;
    v_old_user_type                  tpa_roles_code.user_general_type_id%TYPE;
    v_old_privilege                  tpa_roles_code.privilege%type;
    
    cursor privilege_cur is select trc.privilege from tpa_roles_code trc where trc.role_seq_id=v_role_seq_id;
    
    
  BEGIN
    OPEN privilege_cur;
      FETCH privilege_cur INTO v_old_privilege;
      CLOSE privilege_cur;
      
    IF v_role_seq_id = 0 THEN
      INSERT INTO tpa_roles_code (
        role_seq_id,
        role_name,
        role_desc,
        privilege,
        user_general_type_id,
        added_by,
        added_date )
      VALUES (
        tpa_roles_code_seq.NEXTVAL,
        UPPER(v_role_name),
        v_role_desc,
        v_privilege,
        v_user_general_type_id,
        v_added_by,
        SYSDATE
        ) RETURNING role_seq_id INTO v_role_seq_id ;
    ELSE
      SELECT user_general_type_id INTO v_old_user_type FROM tpa_roles_code WHERE role_seq_id = v_role_seq_id;
      IF v_old_user_type != v_user_general_type_id THEN
        SELECT COUNT(1) INTO v_ctr FROM tpa_user_roles WHERE role_seq_id = v_role_seq_id;
        IF v_ctr > 0 THEN
           RAISE_APPLICATION_ERROR(-20031,'User Type Cannot be Changed, Associated Users Exist.');
         END IF;
      END IF;

      UPDATE tpa_roles_code SET
        role_name              = UPPER(v_role_name),
        role_desc              = v_role_desc,
        privilege              = v_privilege,
        user_general_type_id   = v_user_general_type_id,
        updated_by             = v_added_by,
        updated_date           = SYSDATE
        WHERE role_seq_id = v_role_seq_id ;
    END IF;
    v_row_processed := SQL%ROWCOUNT;
    
    INSERT INTO TPA_USER_ROLE_LOGS (
        role_seq_id,
        role_name,
        user_general_type_id,
        NEW_PRIVILEGE_DOC,
        added_date,
        added_by,
        OLD_PRIVILEGE_DOC
         )
      VALUES (
        TPA_USER_ROLE_LOGS_SEQ.NEXTVAL,
        UPPER(v_role_name),
        v_user_general_type_id,
        v_privilege,
        SYSDATE,
        v_added_by,
        v_old_privilege
        );
   
  COMMIT;
  END save_roles;
  --------------------------------------------------------------------------------------------------------------
  --  Procedure to delete ROLES from the TPA_ROLES_CODE table.
  --  Author S V Sreeraj    Date  22 - 12 - 2005
  --------------------------------------------------------------------------------------------------------------
  PROCEDURE delete_roles(
    v_role_seq_ids           IN VARCHAR2, -- Concatenated String of role_ids
    v_rows_processed         OUT NUMBER
  )
  IS
    str_tab   ttk_util_pkg.str_table_type;
  BEGIN
    str_tab := ttk_util_pkg.parse_str ( v_role_seq_ids );
    FORALL i IN str_tab.FIRST..str_tab.LAST
      DELETE tpa_roles_code
        WHERE role_seq_id = TO_NUMBER(str_tab(i));
    v_rows_processed  := str_tab.LAST;
    COMMIT;
  END delete_roles;

  --------------------------------------------------------------------------------------------------------------
  --  Procedure to insert or update ROLES from the TPA_ROLES_CODE table.
  --    Author S V Sreeraj    Date  22 - 12 - 2005
  --------------------------------------------------------------------------------------------------------------

  PROCEDURE save_group_branch(
    v_group_seq_id               IN  OUT tpa_group_branch.group_seq_id%TYPE,
    v_group_branch_seq_id        IN  tpa_group_branch.group_branch_seq_id%TYPE,
    v_group_name                 IN  tpa_groups.group_name%TYPE,
    v_group_description          IN  tpa_groups.group_description%TYPE,
    v_tpa_office_seq_id          IN  tpa_group_branch.tpa_office_seq_id%TYPE,
    v_group_type_new             IN  tpa_group_branch.group_type%TYPE,
    v_group_type                 IN  NUMBER,
    v_added_by                   IN  tpa_groups.added_by%TYPE,
    v_user_type                  IN  tpa_group_branch.user_type%TYPE, --KOC_Cigna_insurance_resriction
    v_rows_processed             OUT NUMBER
  )
  IS
    v_default_yn  CHAR;

  BEGIN


    SELECT decode(v_group_type,1,'N','Y') INTO v_default_yn FROM dual;
    -- Calling procedure to add details to TPA_GROUP_BRANCH

    save_groups(
      v_group_seq_id ,
      v_group_name ,
      v_group_description ,
      v_added_by ,
      v_default_yn,
      v_group_type_new
    );

    IF v_group_type = 1 THEN
      IF v_group_branch_seq_id = 0 THEN
        INSERT INTO tpa_group_branch (
          group_branch_seq_id,
          group_seq_id,
          tpa_office_seq_id,
          added_by,
          added_date,
          group_type,
          user_type)  --KOC_Cigna_insurance_resriction
        VALUES (
          group_branch_seq_id.NEXTVAL,
          v_group_seq_id ,
          v_tpa_office_seq_id ,
          v_added_by,
          SYSDATE,
          v_group_type_new,
          v_user_type );  --KOC_Cigna_insurance_resriction
      ELSE
        UPDATE tpa_group_branch SET
        tpa_office_seq_id      = v_tpa_office_seq_id ,
        updated_by             = v_added_by,
        updated_date           = SYSDATE,
        group_type             = v_group_type_new,
        user_type              = v_user_type  --KOC_Cigna_insurance_resriction
        WHERE group_branch_seq_id = v_group_branch_seq_id;
      END IF;
    END IF;
    v_rows_processed := SQL%ROWCOUNT;
    COMMIT;

  END save_group_branch;
  --==============================================================================================
 --   Name       : SAVE_MASTER_GROUPS
 --   Created on-18-JAN-06
 --   Created By-
 --   Comments   :
 --==============================================================================================
   PROCEDURE save_groups(
    v_group_seq_id                       IN  OUT TPA_GROUPS.group_seq_id%TYPE,
    v_group_name                         IN  TPA_GROUPS.group_name%TYPE,
    v_group_description                  IN  TPA_GROUPS.group_description%TYPE,
    v_added_by                           IN  TPA_GROUPS.added_by%TYPE,
    v_default_group_yn                   IN  TPA_GROUPS.default_group_yn%TYPE,
    v_group_type_new                     IN  TPA_GROUPS.group_type%TYPE
  )
  IS

  BEGIN
    IF v_group_seq_id = 0 THEN
      INSERT INTO tpa_groups(
        group_seq_id,
        group_name,
        group_description,
        default_group_yn,
        added_by,
        added_date,group_type )
      VALUES (
        tpa_groups_seq.NEXTVAL,
        UPPER(v_group_name),
        v_group_description,
        v_default_group_yn,
        v_added_by,
        SYSDATE,v_group_type_new ) RETURNING group_seq_id INTO v_group_seq_id;
    ELSE
      UPDATE tpa_groups SET
        group_name                              = v_group_name,
        group_description                       = v_group_description,
        updated_by                              = v_added_by,
        updated_date                            = SYSDATE,
		group_type            					= v_group_type_new
        WHERE group_seq_id = v_group_seq_id;
    END IF;
  END save_groups;

----------------------------------------------------------------------------------------------------------
--  Procedure for Deletion from TPA_ROLES_CODE.
--   Author S V Sreeraj    Date  23 - 12 - 2005
----------------------------------------------------------------------------------------------------------

  PROCEDURE delete_groups(
    v_group_branch_seq_ids         IN VARCHAR2, -- Concatenated String of group_BRANCH_seq_ids
    v_rows_processed               OUT NUMBER
  )
  IS


    CURSOR group_cur(v_group_branch_seq_id tpa_group_branch.group_branch_seq_id%TYPE) IS
      SELECT B.group_seq_id,B.default_group_yn
        FROM tpa_group_branch A JOIN tpa_groups B ON (A.group_seq_id = B.group_seq_id AND A.group_branch_seq_id = v_group_branch_seq_id);

    str_tab        ttk_util_pkg.str_table_type;

    v_group_rec    group_cur%ROWTYPE;
    --v_count        BINARY_INTEGER;

  BEGIN
    str_tab := ttk_util_pkg.parse_str ( v_group_branch_seq_ids);

    FOR i IN str_tab.FIRST..str_tab.LAST
    LOOP
      OPEN group_cur(TO_NUMBER(str_tab(i)));
      FETCH group_cur INTO v_group_rec;
      CLOSE group_cur;

      IF v_group_rec.default_group_yn = 'Y' THEN
        RAISE_APPLICATION_ERROR(-20032,'Default Group Cannot be Deleted.');
      ELSE
        DELETE FROM tpa_group_branch WHERE group_branch_seq_id  = TO_NUMBER(str_tab(i));
      END IF;

/*      SELECT COUNT(1) INTO v_count FROM tpa_group_branch WHERE group_seq_id = v_group_rec.group_seq_id;
      IF v_count = 0 THEN
        DELETE FROM tpa_groups WHERE group_seq_id = v_group_rec.group_seq_id;
      END IF;*/
    END LOOP;
    v_rows_processed  := str_tab.LAST;
    COMMIT;
  END delete_groups;
----------------------------------------------------------------------------------------------------------
--  Procedure for Associating users to groups
--   Author S V Sreeraj    Date  22 - 12 - 2005
----------------------------------------------------------------------------------------------------------
  PROCEDURE save_grp_assoc_user (
    v_group_branch_seq_id    IN tpa_group_user_assoc.group_branch_seq_id%TYPE,
    v_contact_seq_ids        IN VARCHAR2, --concatenated string of contact_seq_id delimeted by '|'.
    v_added_by               IN tpa_group_user_assoc.added_by%TYPE,
    v_rows_processed         OUT NUMBER
  )
  IS
     str_tab   ttk_util_pkg.str_table_type;
  BEGIN
    str_tab := ttk_util_pkg.parse_str ( v_contact_seq_ids );
    FOR  i IN str_tab.FIRST..str_tab.LAST
    LOOP
      INSERT INTO tpa_group_user_assoc (
        group_user_seq_id,
        group_branch_seq_id,
        contact_seq_id,
        added_by,
        added_date)
      VALUES (
        tpa_group_user_assoc_seq.NEXTVAL ,
        v_group_branch_seq_id ,
        TO_NUMBER(str_tab(i)) ,
        v_added_by ,
        SYSDATE );
    END LOOP;
    v_rows_processed  := str_tab.LAST;
    COMMIT;
  END save_grp_assoc_user;
----------------------------------------------------------------------------------------------------------
--  Procedure for Removing or dis-associating users from groups
--   Author S V Sreeraj    Date  22 - 12 - 2005
----------------------------------------------------------------------------------------------------------
  PROCEDURE delete_grp_assoc_user(
    v_group_user_seq_ids        IN VARCHAR2, -- Concatenated String of group_user_seq_ids
    v_rows_processed            OUT NUMBER
  )
  IS
    str_tab   ttk_util_pkg.str_table_type;
  BEGIN
    str_tab := ttk_util_pkg.parse_str ( v_group_user_seq_ids );
    FORALL i  IN str_tab.FIRST..str_tab.LAST
      DELETE tpa_group_user_assoc
        WHERE group_user_seq_id = TO_NUMBER(str_tab(i));
    v_rows_processed  := str_tab.LAST;
    COMMIT;
  END delete_grp_assoc_user;
----------------------------------------------------------------------------------------------------------
--  Procedure for Fetching details of user for all user types.
--  Screen  User Management List of user
--  Author S V Sreeraj    Date  23 - 12 - 2005
----------------------------------------------------------------------------------------------------------
PROCEDURE select_contact_list (
    v_user_general_type_id   IN tpa_user_contacts.user_general_type_id%TYPE,
    v_user_id                IN tpa_login_info.user_id%TYPE,
    v_contact_name           IN tpa_user_contacts.contact_name%TYPE,
    v_role_seq_id            IN tpa_user_roles.role_seq_id%TYPE,
    v_hosp_name              IN tpa_hosp_info.hosp_name%TYPE,  ----------hospital name,partner name
    v_empanel_number         IN tpa_hosp_info.empanel_number%TYPE,
    v_city_type_id           IN tpa_hosp_address.city_type_id%TYPE,
    v_active_yn              IN tpa_user_contacts.active_yn%TYPE,
    v_ins_seq_id             IN tpa_user_contacts.ins_seq_id %TYPE,
    v_ins_comp_code_number   IN tpa_ins_info.Ins_Comp_Code_Number%TYPE,
    v_tpa_office_seq_id      IN tpa_office_info.tpa_office_seq_id%TYPE,
    v_group_name             IN tpa_group_registration.group_name%TYPE,
    v_group_id               IN tpa_group_registration.group_id%TYPE,
    v_sort_var               IN VARCHAR2 ,
    v_start_num              IN NUMBER,
    v_end_num                IN NUMBER ,
    v_sort_order             IN VARCHAR2,
    result_cur               OUT SYS_REFCURSOR
  )
  IS
    v_sql_str                            VARCHAR2(2000);
    TYPE bind_tab_type IS TABLE OF VARCHAR2(250) INDEX BY BINARY_INTEGER ;
    bind_tab                             bind_tab_type;
    i                                    NUMBER(2) := 0;
    v_where                              VARCHAR2(2000);
    v_provide_access_user_yn             tpa_user_contacts.provide_access_user_yn%TYPE;

  BEGIN
-- List of Users =>  (For NHCP users only)
    IF  v_user_id IS NOT NULL THEN
      v_where := v_where || ' AND B.user_id LIKE :v_user_id ';
      i := i+1;
      bind_tab(i) := v_user_id||'%';
    END IF;
    IF v_contact_name IS NOT NULL THEN
      v_where := v_where || ' AND A.contact_name LIKE :v_contact_name ';
      i := i+1;
      bind_tab(i) := upper(v_contact_name)||'%';
    END IF;
    IF v_role_seq_id IS NOT NULL THEN
      v_where := v_where || ' AND C.role_seq_id = :v_role_seq_id ';
      i := i+1;
      bind_tab(i) := v_role_seq_id;
    END IF;

    IF  v_user_general_type_id = 'HOS' THEN
      v_sql_str :=
       'SELECT B.user_id,
        A.contact_seq_id,
        A.contact_name,
        D.role_name,
        E.hosp_name,
        G.city_description CITY,
        NULL AS ins_comp_code,
        E.empanel_number,
        A.active_yn ,
        A.provide_access_user_yn,
        null as policy_group_seq_id
        FROM tpa_user_contacts A JOIN tpa_login_info B ON
        (A.contact_seq_id  = B.contact_seq_id AND A.user_general_type_id = :v_user_general_type_id )
        LEFT OUTER JOIN tpa_user_roles C ON (B.contact_seq_id = C.contact_seq_id)
        LEFT OUTER JOIN tpa_roles_code D ON (C.role_seq_id  = D.role_seq_id )
        LEFT OUTER JOIN tpa_hosp_info E ON (A.hosp_seq_id  = E.hosp_seq_id )
        LEFT OUTER JOIN tpa_hosp_address F ON(A.hosp_seq_id = F.hosp_seq_id )
        LEFT OUTER JOIN tpa_city_code G ON (F.city_type_id = G.city_type_id )
        WHERE A.active_yn = ''Y'' AND A.provide_access_user_yn  = :v_active_yn ';

        IF v_hosp_name  IS NOT NULL THEN
          v_where := v_where || ' AND E.hosp_name LIKE :v_hosp_name';
          i := i+1;
          bind_tab(i) := UPPER(v_hosp_name)||'%';
        END IF;
        IF v_empanel_number IS NOT NULL THEN
          v_where := v_where || ' AND E.empanel_number  LIKE :v_empanel_number';
          i := i+1;
          bind_tab(i) := UPPER(v_empanel_number)||'%';
        END IF;
        IF v_city_type_id IS NOT NULL THEN
          v_where := v_where || ' AND G.city_type_id  = :v_city_type_id ';
          i := i+1;
          bind_tab(i) := UPPER(v_city_type_id);
        END IF;
		
		
		    ----------********************NEWLY ADDED FOR PARTNER***********************----------------------------
        
        ELSIF  v_user_general_type_id = 'PTR' THEN
      v_sql_str :=
       'SELECT B.user_id,
        A.contact_seq_id,
        A.contact_name,
        D.role_name,
        E.partner_name,
        G.city_description CITY,
        NULL AS ins_comp_code,
        E.empanel_number,
        A.active_yn ,
        A.provide_access_user_yn,
        null as policy_group_seq_id
        FROM tpa_user_contacts A JOIN tpa_login_info B ON
        (A.contact_seq_id  = B.contact_seq_id AND A.user_general_type_id = :v_user_general_type_id )
        LEFT OUTER JOIN tpa_user_roles C ON (B.contact_seq_id = C.contact_seq_id)
        LEFT OUTER JOIN tpa_roles_code D ON (C.role_seq_id  = D.role_seq_id )
        LEFT OUTER JOIN tpa_partner_info E ON (A.ptnr_seq_id  = E.ptnr_seq_id )
        LEFT OUTER JOIN tpa_partner_address F ON(A.ptnr_seq_id = F.ptnr_seq_id )
        LEFT OUTER JOIN tpa_city_code G ON (F.city_type_id = G.city_type_id )
        WHERE A.active_yn = ''Y'' AND A.provide_access_user_yn  = :v_active_yn ';
        
       
        IF v_hosp_name  IS NOT NULL THEN    ---------v_hosp_name=partner name 
          v_where := v_where || ' AND E.partner_name LIKE :v_ptnr_name';
          i := i+1;
          bind_tab(i) := UPPER(v_hosp_name)||'%';
        END IF;
        IF v_empanel_number IS NOT NULL THEN
          v_where := v_where || ' AND E.empanel_number  LIKE :v_empanel_number';
          i := i+1;
          bind_tab(i) := UPPER(v_empanel_number)||'%';
        END IF;
        IF v_city_type_id IS NOT NULL THEN
          v_where := v_where || ' AND G.city_type_id  = :v_city_type_id ';
          i := i+1;
          bind_tab(i) := UPPER(v_city_type_id);
        END IF;
        
        ------------------******************************______________________________
		
 --List of Users =>  (For INSURANCE users only)
    ELSIF v_user_general_type_id = 'INS' THEN
      v_sql_str :=
       'SELECT B.user_id ,
        A.contact_seq_id,
        A.contact_name,
        D.role_name,
        E.ins_comp_name,
        NULL AS city,
        E.ins_comp_code_number,
        NULL AS empanel_number,
        A.active_yn ,
        A.provide_access_user_yn,
        null as policy_group_seq_id
        FROM tpa_user_contacts A JOIN tpa_login_info B ON (A.contact_seq_id = B.contact_seq_id
        AND A.user_general_type_id = :v_user_general_type_id )
        LEFT OUTER JOIN tpa_user_roles C ON (B.contact_seq_id = C.contact_seq_id)
        LEFT OUTER JOIN tpa_roles_code D ON (C.role_seq_id  = D.role_seq_id )
        LEFT OUTER JOIN tpa_ins_info E ON (A.ins_seq_id = E.ins_seq_id)
        WHERE A.active_yn = ''Y'' AND A.provide_access_user_yn  = :v_active_yn ';

        IF v_ins_seq_id  IS NOT NULL THEN
          v_where := v_where || ' AND A.ins_seq_id  = :v_ins_seq_id ' ;
          i := i+1;
          bind_tab(i) := v_ins_seq_id;
        END IF;
        IF v_ins_comp_code_number IS NOT NULL THEN
          v_where := v_where || ' AND E.ins_comp_code_number  LIKE :v_ins_comp_code_number';
          i := i+1;
          bind_tab(i) := v_ins_comp_code_number||'%';
        END IF;

       --For Broker Users
       ELSIF v_user_general_type_id = 'BRO' THEN
       
       IF v_active_yn='Y' THEN
      v_sql_str :=
       'SELECT B.user_id ,
        A.contact_seq_id,
        A.contact_name,
        D.role_name,
        E.ins_comp_name,
        NULL AS city,
        E.ins_comp_code_number,
        NULL AS empanel_number,
        A.active_yn ,
        A.provide_access_user_yn,
        null as policy_group_seq_id
        FROM tpa_user_contacts A JOIN tpa_login_info B ON (A.contact_seq_id = B.contact_seq_id
        AND A.user_general_type_id = :v_user_general_type_id )
        LEFT OUTER JOIN tpa_user_roles C ON (B.contact_seq_id = C.contact_seq_id)
        LEFT OUTER JOIN tpa_roles_code D ON (C.role_seq_id  = D.role_seq_id )
        LEFT OUTER JOIN tpa_bro_info E ON (A.ins_seq_id = E.ins_seq_id)
        WHERE A.active_yn = ''Y'' AND A.provide_access_user_yn  = :v_active_yn ';

        IF v_ins_seq_id  IS NOT NULL THEN
          v_where := v_where || ' AND A.ins_seq_id  = :v_ins_seq_id ' ;
          i := i+1;
          bind_tab(i) := v_ins_seq_id;
        END IF;
        IF v_ins_comp_code_number IS NOT NULL THEN
          v_where := v_where || ' AND E.ins_comp_code_number  LIKE :v_ins_comp_code_number';
          i := i+1;
          bind_tab(i) := v_ins_comp_code_number||'%';
        END IF;
        
      ELSE
         v_sql_str :=
       'SELECT B.user_id ,
        A.contact_seq_id,
        A.contact_name,
        D.role_name,
        E.ins_comp_name,
        NULL AS city,
        E.ins_comp_code_number,
        NULL AS empanel_number,
        A.active_yn ,
        A.provide_access_user_yn,
        null as policy_group_seq_id
        FROM tpa_user_contacts A JOIN tpa_login_info B ON (A.contact_seq_id = B.contact_seq_id
        AND A.user_general_type_id = :v_user_general_type_id )
        LEFT OUTER JOIN tpa_user_roles C ON (B.contact_seq_id = C.contact_seq_id)
        LEFT OUTER JOIN tpa_roles_code D ON (C.role_seq_id  = D.role_seq_id )
        LEFT OUTER JOIN tpa_bro_info E ON (A.ins_seq_id = E.ins_seq_id)
        WHERE A.active_yn = ''N'' AND A.provide_access_user_yn  = :v_active_yn ';

        IF v_ins_seq_id  IS NOT NULL THEN
          v_where := v_where || ' AND A.ins_seq_id  = :v_ins_seq_id ' ;
          i := i+1;
          bind_tab(i) := v_ins_seq_id;
        END IF;
        IF v_ins_comp_code_number IS NOT NULL THEN
          v_where := v_where || ' AND E.ins_comp_code_number  LIKE :v_ins_comp_code_number';
          i := i+1;
          bind_tab(i) := v_ins_comp_code_number||'%';
        END IF;
     END IF;
   	-- For corporate users
    ELSIF v_user_general_type_id = 'COR' THEN
      v_sql_str :=
       'SELECT B.user_id,
        A.contact_seq_id,
        A.contact_name,
        D.role_name,
        E.group_name,
        NULL AS city,
        E.group_id,
        NULL AS empanel_seq_id,
        A.active_yn ,
        A.provide_access_user_yn,
        null as policy_group_seq_id
        FROM tpa_user_contacts A JOIN tpa_login_info B ON (A.contact_seq_id = B.contact_seq_id
        AND A.user_general_type_id = :v_user_general_type_id )
        LEFT OUTER JOIN tpa_user_roles C ON (B.contact_seq_id = C.contact_seq_id)
        LEFT OUTER JOIN tpa_roles_code D ON (C.role_seq_id  = D.role_seq_id )
        LEFT OUTER JOIN tpa_group_registration E ON (A.group_reg_seq_id = E.group_reg_seq_id)
        WHERE A.active_yn = ''Y'' AND A.provide_access_user_yn  = :v_active_yn ';

        IF v_group_name  IS NOT NULL THEN
          v_where := v_where || ' AND E.group_name LIKE :v_group_name';
          i := i+1;
          bind_tab(i) := UPPER(v_group_name)||'%';
        END IF;
        IF v_group_id IS NOT NULL THEN
          v_where := v_where || ' AND E.group_id LIKE :v_group_id';
          i := i+1;
          bind_tab(i) := UPPER(v_group_id)||'%';
        END IF;
    ------------- for Policy User(CR-0259) --------------
    ELSIF v_user_general_type_id = 'EMP' THEN
      
      v_sql_str := 'select * from(select rownum r,
                     m.tpa_enrollment_id as user_id,
                     m.mem_name as contact_name,
                     g.policy_group_seq_id,
                     null as contact_seq_id,
                     null as role_name,
                     null as group_name,
                     NULL AS city,
                     null as group_id,
                     NULL AS empanel_seq_id,
                     null as active_yn ,
                     null as provide_access_user_yn
                from tpa_enr_policy_member m
                join tpa_enr_policy_group g on (m.policy_group_seq_id=g.policy_group_seq_id)
                join tpa_enr_policy p on (g.policy_seq_id=p.policy_seq_id)
               where m.tpa_enrollment_id = :v_user_id  and  m.relship_type_id=''NSF'' and m.deleted_yn=''N'' 
                 and p.completed_yn = ''Y'' and g.deleted_yn=''N'' and m.status_general_type_id=''POA''
                 and (case when trunc(sysdate) between trunc(m.date_of_inception) and trunc(m.date_of_exit) then ''Y'' else ''N'' end) = :v_active_yn 
               order by m.member_seq_id desc) where r=1';
    -----------------------------------------------------  
    -- for TTK users and CALLCENTER  Users
    ELSE
      v_sql_str :=
       'SELECT B.user_id,
        A.contact_seq_id,
        A.contact_name,
        D.role_name,
        E.office_name office_name,
        NULL AS city,
        NULL AS ins_comp_code,
        NULL AS empanel_seq_id,
        A.active_yn ,
        A.provide_access_user_yn,
        null as policy_group_seq_id
        FROM tpa_user_contacts A JOIN tpa_login_info B ON (A.contact_seq_id = B.contact_seq_id
        AND A.user_general_type_id = :v_user_general_type_id )
        LEFT OUTER JOIN tpa_user_roles C ON (B.contact_seq_id = C.contact_seq_id)
        LEFT OUTER JOIN tpa_roles_code D ON (C.role_seq_id  = D.role_seq_id )
        LEFT OUTER JOIN tpa_office_info E ON (E.tpa_office_seq_id = A.tpa_office_seq_id )
        WHERE A.active_yn = :v_active_yn ';

        IF v_tpa_office_seq_id IS NOT NULL THEN
          v_where := v_where || ' AND E.tpa_office_seq_id  = :v_tpa_office_seq_id ';
          i := i+1;
          bind_tab(i) := v_tpa_office_seq_id;
        END IF;
    END IF;
    IF v_user_general_type_id = 'EMP' THEN --CR0259
       
       OPEN result_cur FOR v_sql_str USING v_user_id,v_active_yn;
       
    ELSE   
    v_sql_str := v_sql_str || v_where;

    v_sql_str := ' SELECT * FROM (SELECT A.*,DENSE_RANK() OVER(ORDER BY '||v_sort_var||' '||v_sort_order||',ROWNUM) Q FROM ( '|| v_sql_str ||')A)
                       WHERE Q>= :v_start_num  AND Q <= :v_end_num ';

    
       
    IF bind_tab.FIRST IS NOT NULL THEN
       CASE bind_tab.COUNT
         WHEN 1  THEN OPEN result_cur FOR v_sql_str USING v_user_general_type_id,v_active_yn, bind_tab(1) , v_start_num , v_end_num ;
         WHEN 2  THEN OPEN result_cur FOR v_sql_str USING v_user_general_type_id,v_active_yn, bind_tab(1),bind_tab(2), v_start_num , v_end_num ;
         WHEN 3  THEN OPEN result_cur FOR v_sql_str USING v_user_general_type_id,v_active_yn, bind_tab(1),bind_tab(2) ,bind_tab(3) , v_start_num , v_end_num ;
         WHEN 4  THEN OPEN result_cur FOR v_sql_str USING v_user_general_type_id,v_active_yn, bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) , v_start_num , v_end_num ;
         WHEN 5  THEN OPEN result_cur FOR v_sql_str USING v_user_general_type_id,v_active_yn, bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5), v_start_num , v_end_num ;
         WHEN 6  THEN OPEN result_cur FOR v_sql_str USING v_user_general_type_id,v_active_yn, bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6), v_start_num , v_end_num ;
       END CASE ;
     ELSE
       OPEN result_cur FOR v_sql_str USING v_user_general_type_id, v_active_yn, v_start_num , v_end_num ;
     END IF;
    END IF; 
  END select_contact_list;
----------------------------------------------------------------------------------------------------------
--  Procedure for Group Registration.
--  Screen  Empanelment ->Hospital ->Group Registration
--  Author S V Sreeraj    Date  23 - 12 - 2005
----------------------------------------------------------------------------------------------------------
  PROCEDURE save_group_reg (
    v_group_reg_seq_id               IN OUT tpa_group_registration.group_reg_seq_id%TYPE,
    v_tpa_office_seq_id              IN tpa_group_registration.tpa_office_seq_id%TYPE,
    v_group_general_type_id          IN OUT tpa_group_registration.group_general_type_id%TYPE,
    v_group_name                     IN tpa_group_registration.group_name%TYPE,
    v_group_id                       IN OUT tpa_group_registration.group_id%TYPE,
    v_parent_group_seq_id            IN tpa_group_registration.parent_group_seq_id%TYPE,
    v_addr_seq_id                    IN tpa_address.addr_seq_id%TYPE,
    v_address_1                      IN tpa_address.address_1%TYPE,
    v_address_2                      IN tpa_address.address_2%TYPE,
    v_address_3                      IN tpa_address.address_3%TYPE,
    v_state_type_id                  IN tpa_address.state_type_id%TYPE,
    v_city_type_id                   IN tpa_address.city_type_id%TYPE,
    v_country_id                     IN tpa_address.country_id%TYPE,
    v_pin_code                       IN tpa_address.pin_code%TYPE,
    v_location_code                  IN tpa_group_registration.location_code%TYPE,
    v_acc_mgr_contact_seq_id         IN tpa_group_registration.acc_mgr_contact_seq_id%TYPE,
    v_notify_email_id                IN tpa_group_registration.notify_email_id%TYPE,
    v_notify_type_id                 IN tpa_group_registration.notify_type_id%TYPE,
    v_cc_email_id                    IN tpa_group_registration.cc_email_id%TYPE,
    v_email_id                       IN tpa_group_registration.email_id%TYPE,
    v_HR_EMAIL_ID                    IN tpa_group_registration.HR_EMAIL_ID%TYPE, --Added new column For CR KOC1111
    v_PREF_PROV_NTW_FLAG             IN tpa_group_registration.PREF_PROV_NTW_FLAG%TYPE,   --KOC1346
    v_added_by                       IN tpa_group_registration.added_by%TYPE,
    v_isd_code                       IN tpa_address.isd_code%type,
    v_std_code                       IN tpa_address.std_code%type,
    v_offise_phone1                  IN tpa_address.office_phone1%type,
    v_office_phone2                  IN tpa_address.office_phone2%type,
    v_priority_flag                  IN varchar2,
	  v_erp_supp_code					         IN tpa_group_registration.erp_supplier_id%type,
	  v_erp_cust_code					         IN tpa_group_registration.erp_customer_id%type,
    v_rows_processed                 OUT NUMBER,
    v_group_id_alert                 OUT VARCHAR2
  )
 
  IS
    duplicate_location_code  EXCEPTION;
    PRAGMA EXCEPTION_INIT (duplicate_location_code, -00001);
    -- Internal procedure to generate group_id and office number for groups and offices.
    -- User-id is FIRST CHARACTER OF THE NAME || Sequntial Number left padded with Zeros on left to Five Digits.
    ------------------------------------------------------------------------------------------------------------
    v_office_number                  tpa_group_registration.office_number%TYPE;
    v_prev_group_general_type_id     tpa_group_registration.group_general_type_id%TYPE;
    v_ctr                            NUMBER;

    PROCEDURE create_group_id (
      v_group_name          IN tpa_group_registration.group_name%TYPE,
      v_group_id            IN OUT tpa_group_registration.group_id%TYPE,
      v_office_number       IN OUT tpa_group_registration.office_number %TYPE
    )
    IS

      v_last_group_id       tpa_group_registration.group_id %TYPE;
      v_last_office_number  tpa_group_registration.office_number%TYPE;

      v_first_char          VARCHAR2(1) := UPPER(SUBSTR(v_group_name,1,1));

      CURSOR group_id_cur IS SELECT group_id FROM ( SELECT group_id FROM tpa_group_registration
        WHERE GROUP_ID LIKE v_first_char||'%' AND ignore_yn = 'N' ORDER BY TO_NUMBER(regexp_replace( group_id,'\D',NULL)) DESC) WHERE ROWNUM = 1;

      CURSOR office_number_cur IS SELECT * FROM (SELECT A.OFFICE_NUMBER  FROM tpa_group_registration A
          WHERE group_id = v_group_id ORDER BY ADDED_DATE DESC ) WHERE ROWNUM = 1 ;
      
      CURSOR instance_name_cur IS SELECT S.INSTANCE_NAME FROM  APP.TPA_SYSTEM_PARAMETERS S;
      
      V_INSTANCE_NAME      VARCHAR2(100);
    
    BEGIN
       OPEN instance_name_cur;
       FETCH instance_name_cur INTO v_instance_name;
       CLOSE instance_name_cur;
      
      
      IF v_group_id IS NULL THEN    -- New group

        OPEN group_id_cur;
        FETCH group_id_cur INTO v_last_group_id;
        CLOSE group_id_cur;

        IF v_last_group_id IS NULL THEN            -- First group whose name start with that alphabet.
          IF v_instance_name ='GN' THEN--GLOBAL NET
            
              v_group_id := v_first_char||'0201';
              
          ELSIF v_instance_name ='VN' THEN--VIDAL
          
              v_group_id := v_first_char||'0200';
          
          ELSE
            v_group_id := v_first_char||'0001';     -- Assigns directly the group-id
          END IF;
        ELSE   -- Creating the group_id by concatenating First alphabet of the name and the next sequential number.
            IF v_instance_name ='GN' THEN--GLOBAL NET
                if substr(v_last_group_id,2,4) > 198 then
                   v_last_group_id:= case when mod(substr(v_last_group_id,2,4),2)=0 then substr(v_last_group_id,1,1)||LPAD(TO_CHAR(to_number(SUBSTR(v_last_group_id,(-1 * (LENGTH(v_last_group_id)-1))))+1),4,'0') else v_last_group_id end;
                else 
                   v_last_group_id:=substr(v_last_group_id,1,1)||'0199';
                end if;
            ELSIF v_instance_name ='VN' THEN--VIDAL
                if substr(v_last_group_id,2,4) > 198 then
                   v_last_group_id:= case when mod(substr(v_last_group_id,2,4),2)=1 then substr(v_last_group_id,1,1)||LPAD(TO_CHAR(to_number(SUBSTR(v_last_group_id,(-1 * (LENGTH(v_last_group_id)-1))))+1),4,'0') else v_last_group_id end;
                 else 
                   v_last_group_id:=substr(v_last_group_id,1,1)||'0198';
                end if;
          
            ELSE
                 v_last_group_id:=v_last_group_id;
                --v_group_id := v_first_char || LPAD(TO_CHAR(to_number(SUBSTR(v_last_group_id,(-1 * (LENGTH(v_last_group_id)-1))))+2),4,'0');
            END IF;
          v_group_id := v_first_char || LPAD(TO_CHAR(to_number(SUBSTR(v_last_group_id,(-1 * (LENGTH(v_last_group_id)-1))))+1),4,'0');
        END IF;

        v_office_number := '000'; -- For groups office number is always '000'

      ELSE -- for existing groups ie. for adding branches under a group.
        OPEN office_number_cur;
        FETCH office_number_cur INTO  v_last_office_number;
        CLOSE office_number_cur;

        v_office_number := LPAD(to_number(v_last_office_number) + 1,3,'0');  -- assigning the office number by adding 1 to the last
      END IF;
    END create_group_id;


  BEGIN
    IF v_group_general_type_id IS NULL THEN
      SELECT  group_general_type_id INTO v_group_general_type_id
        FROM tpa_group_registration
       WHERE group_reg_seq_id = v_parent_group_seq_id;
    END IF;

    IF v_group_reg_seq_id = 0 THEN
      -- For addition -> calling internal procedure for generating group-id and office number.
      -------------------------------------------------------------------------------------
      create_group_id(v_group_name,v_group_id,v_office_number);
      
      v_group_id_alert := 'Group ID for '||UPPER(v_group_name)||' is '||v_group_id;

      INSERT INTO tpa_group_registration (
        group_reg_seq_id ,
        tpa_office_seq_id,
        group_name,
        group_id ,
        office_number ,
        parent_group_seq_id,
        group_general_type_id,
        ignore_yn,
        location_code,
        acc_mgr_contact_seq_id,
        notify_email_id,
        notify_type_id,
        cc_email_id,
        email_id,
        hr_email_id,--Added new column For CR KOC1111
        added_by,
        added_date,
        PREF_PROV_NTW_FLAG, --KOC1346
        priority_corporate_yn ,
        erp_supplier_id,
        erp_customer_id)
      values (
        tpa_group_registration_seq.NEXTVAL,
        v_tpa_office_seq_id,
        UPPER(v_group_name),
        v_group_id,
        v_office_number,
        v_parent_group_seq_id,
        v_group_general_type_id,
        'N',
        UPPER(v_location_code),
        v_acc_mgr_contact_seq_id,
        v_notify_email_id,
        v_notify_type_id,
        v_cc_email_id,
        v_email_id,
        v_HR_EMAIL_ID,
        v_added_by,
        SYSDATE,
        V_PREF_PROV_NTW_FLAG,
        CASE WHEN UPPER(v_priority_flag) = 'ON' THEN 'Y' ELSE 'N' END  ,
        v_erp_supp_code,
        v_erp_cust_code) RETURNING group_reg_seq_id  INTO v_group_reg_seq_id ;
    ELSE
      SELECT group_general_type_id INTO v_prev_group_general_type_id
        FROM tpa_group_registration
       WHERE group_reg_seq_id = v_group_reg_seq_id;

      IF v_prev_group_general_type_id != v_group_general_type_id THEN
        SELECT COUNT(1) INTO v_ctr FROM tpa_enr_policy
                WHERE group_reg_seq_id = v_group_reg_seq_id  AND deleted_yn = 'N';

        IF v_ctr > 0 THEN
          raise_application_error(-20088,'Policies Exists Cannot Change Group Type ');
        END IF;
      END IF;

      UPDATE tpa_group_registration SET
        group_name                     = UPPER(v_group_name),
        tpa_office_seq_id              = v_tpa_office_seq_id,
        group_general_type_id          = v_group_general_type_id,
        location_code                  = nvl(UPPER(v_location_code),location_code),
        acc_mgr_contact_seq_id         = v_acc_mgr_contact_seq_id,
        notify_email_id                = v_notify_email_id,
        notify_type_id                 = v_notify_type_id,
        cc_email_id                    = v_cc_email_id,
        email_id                       = v_email_id,
        hr_email_id                    =v_hr_email_id,--Added new column For CR KOC1111
        updated_by                     = v_added_by,
        updated_date                   = SYSDATE,
        PREF_PROV_NTW_FLAG             = V_PREF_PROV_NTW_FLAG, --KOC1346
        priority_corporate_yn          = CASE WHEN UPPER(v_priority_flag) = 'ON' THEN 'Y' ELSE 'N' END,
        erp_customer_id                = v_erp_cust_code,
        erp_supplier_id                = v_erp_supp_code
        WHERE group_reg_seq_id  = v_group_reg_seq_id ;
    END IF;
    save_group_address (
      v_addr_seq_id,
      NULL,
      NULL,
      v_group_reg_seq_id,
      v_address_1 ,
      v_address_2,
      v_address_3 ,
      v_state_type_id,
      v_city_type_id ,
      v_country_id ,
      v_pin_code,
      v_added_by,
      v_isd_code,
      v_std_code,
      v_offise_phone1,
      v_office_phone2
    );
    IF v_notify_type_id ='NIG' AND v_group_reg_seq_id IS NOT NULL THEN
       -- Deleteing the Records source_message_custom_grp
     DELETE FROM source_message_custom_grp WHERE group_reg_seq_id=v_group_reg_seq_id;
    END IF;

    v_rows_processed := SQL%ROWCOUNT;
    COMMIT;
  EXCEPTION
    WHEN duplicate_location_code THEN
      raise_application_error(-20545,'  Duplicate Location Code');
  END save_group_reg;


----------------------------------------------------------------------------------------------------------
--  Procedure for adding or modifying address details of groups
--  (Group Registration) as well as TPA OFFICEs
--  Internally called from "pr_group_registration_save" and "ADMINSTRATION_PKG.SAVE_TPA_OFFICE
--  Screen  Empanelment ->Hospital ->Group Registration
--  Author S V Sreeraj    Date  23 - 12 - 2005
----------------------------------------------------------------------------------------------------------
  PROCEDURE save_group_address (
    v_addr_seq_id        IN tpa_address.addr_seq_id%TYPE,
    v_tpa_office_seq_id  IN tpa_address.tpa_office_seq_id%TYPE,
    v_ins_seq_id         IN tpa_address.ins_seq_id%TYPE,
    v_group_reg_seq_id   IN tpa_address.group_reg_seq_id%TYPE,
    v_address_1          IN tpa_address.address_1%TYPE,
    v_address_2          IN tpa_address.address_2%TYPE,
    v_address_3          IN tpa_address.address_3%TYPE,
    v_state_type_id      IN tpa_address.state_type_id%TYPE,
    v_city_type_id       IN tpa_address.city_type_id%TYPE,
    v_country_id         IN tpa_address.country_id%TYPE,
    v_pin_code           IN tpa_address.pin_code%TYPE,
    v_added_by           IN tpa_address.added_by%TYPE,
    v_isd_code           IN tpa_address.isd_code%type,
    v_std_code           IN tpa_address.std_code%type,
    v_offise_phone1      IN tpa_address.office_phone1%type,
    v_office_phone2      IN tpa_address.office_phone2%type
  )
  IS
  BEGIN
    IF v_addr_seq_id = 0 THEN
      INSERT INTO tpa_address (
        addr_seq_id,
        tpa_office_seq_id,
        ins_seq_id,
        group_reg_seq_id,
        address_1,
        address_2,
        address_3,
        state_type_id,
        city_type_id,
        country_id,
        pin_code,
        added_by,
        added_date,
        isd_code,
        std_code,
        office_phone1,
        office_phone2 )
      VALUES (
        tpa_address_seq.NEXTVAL,
        v_tpa_office_seq_id,
        v_ins_seq_id,
        v_group_reg_seq_id,
        v_address_1,
        v_address_2,
        v_address_3,
        v_state_type_id,
        v_city_type_id,
        v_country_id,
        v_pin_code,
        v_added_by,
        SYSDATE,
        v_isd_code,
        v_std_code,
        v_offise_phone1,
        v_office_phone2 ) ;
    ELSE
      UPDATE tpa_address SET
        address_1      = v_address_1,
        address_2      = v_address_2,
        address_3      = v_address_3,
        state_type_id  = v_state_type_id,
        city_type_id   = v_city_type_id,
        country_id     = v_country_id,
        pin_code       = v_pin_code,
        updated_by     = v_added_by,
        updated_date   = SYSDATE,
        isd_code       = v_isd_code,
        std_code       = v_std_code,
        office_phone1  = v_offise_phone1,
        office_phone2  = v_office_phone2
        WHERE addr_seq_id = v_addr_seq_id;
    END IF;
  END save_group_address;
--=======================================================================================
----------------------------------------------------------------------------------------------------------
-- Procedure for deletion from tpa_group_registration
-- Author S.V.Sreeraj Date 25-12-2005
----------------------------------------------------------------------------------------------------------
 PROCEDURE delete_group_reg(
   v_group_reg_seq_id  IN tpa_group_registration.group_reg_seq_id%TYPE,
   v_rows_processed    OUT NUMBER
 )
 IS
 BEGIN
  DELETE FROM tpa_address WHERE group_reg_seq_id = v_group_reg_seq_id;
  DELETE FROM tpa_group_registration WHERE group_reg_seq_id = v_group_reg_seq_id;
  v_rows_processed := SQL%ROWCOUNT;
  COMMIT;
 END delete_group_reg;
 --===================================================================
 --==============================================================================================
 --   Name       : SAVE_PRODUCT_GROUPS
 --   Created on-14-JAN-06
 --   Created By-: S.V.Sreeraj
 --   Comments   : For adding groups (user group) related with products.
 --==============================================================================================
 PROCEDURE save_product_groups(
    v_prod_policy_seq_id                 IN  tpa_ins_prod_policy.prod_policy_seq_id%TYPE,
    v_tpa_office_ids                     IN  VARCHAR2,       --- '|' Concatenated string tpa_office_seq_ids
    v_added_by                           IN  tpa_groups.added_by%TYPE,
    v_rows_processed                     IN  OUT NUMBER
  )
  IS

    new_id_tab                           ttk_util_pkg.str_table_type;
    v_ctr                                BINARY_INTEGER;
    v_new_id_str                         VARCHAR2(2000);
    v_group_name                         tpa_groups.group_name%TYPE;
    v_group_rec                          tpa_groups%ROWTYPE;
    v_group_seq_id                       tpa_groups.group_seq_id%TYPE;
    v_del_rows                           NUMBER(2) := 0;

    CURSOR group_cur IS
       SELECT * FROM tpa_groups
        WHERE prod_policy_seq_id = v_prod_policy_seq_id;

  BEGIN

    new_id_tab := ttk_util_pkg.parse_str( v_tpa_office_ids );

    v_new_id_str := substr(REPLACE(v_tpa_office_ids,'|',','),2,length(v_tpa_office_ids)-2);

    OPEN group_cur;
    FETCH group_cur INTO v_group_rec;
    CLOSE group_cur;

    IF v_group_rec.group_seq_id IS NOT NULL THEN
      v_group_seq_id := v_group_rec.group_seq_id;
      IF v_new_id_str IS NOT NULL THEN
        v_new_id_str := 'DELETE FROM tpa_group_branch WHERE group_seq_id = '||v_group_rec.group_seq_id ||' AND tpa_office_seq_id NOT IN ('||v_new_id_str||')';
      ELSE
        v_new_id_str := 'DELETE FROM tpa_group_branch WHERE group_seq_id = '||v_group_rec.group_seq_id ;
      END IF;

      EXECUTE IMMEDIATE v_new_id_str;
      v_del_rows := SQL%ROWCOUNT;

    ELSE
      SELECT B.product_name||'-'||C.abbrevation_code INTO  v_group_name  FROM
        tpa_ins_prod_policy A  JOIN tpa_ins_product B ON (A.product_seq_id = B.product_seq_id AND A.prod_policy_seq_id = v_prod_policy_seq_id)
        JOIN tpa_ins_info C ON (B.ins_seq_id = C.ins_seq_id);
      INSERT INTO tpa_groups(
            group_seq_id,
            group_name,
            prod_policy_seq_id,
            default_group_yn,
            added_by,
            added_date
             )
      VALUES (
          tpa_groups_seq.NEXTVAL,
          v_group_name,
          v_prod_policy_seq_id,
          'N',
          v_added_by,
          SYSDATE
       )RETURNING group_seq_id INTO v_group_seq_id;
    END IF;
    IF new_id_tab.FIRST IS NOT NULL THEN
      FOR i IN 1 .. new_id_tab.LAST
      LOOP
        SELECT count(1) INTO v_ctr FROM tpa_group_branch WHERE  group_seq_id = v_group_rec.group_seq_id AND tpa_office_seq_id = new_id_tab(i);
        IF v_ctr = 0 THEN
          INSERT INTO tpa_group_branch(
            group_branch_seq_id,
            group_seq_id,
            tpa_office_seq_id,
            added_by,
            added_date
            )
          VALUES (
            tpa_group_branch_seq.NEXTVAL,
            v_group_seq_id,
            new_id_tab(i),
            v_added_by,
            SYSDATE
            );
        END IF;
      END LOOP;
    END IF;

    v_rows_processed := SQL%ROWCOUNT;

    IF v_del_rows > v_rows_processed THEN
       v_rows_processed := v_del_rows;
    END IF;

    SELECT COUNT(1) INTO v_ctr FROM tpa_group_branch WHERE group_seq_id = v_group_seq_id;
    IF v_ctr = 0 THEN
      DELETE FROM tpa_groups WHERE group_seq_id = v_group_seq_id;
    END IF;
    COMMIT;
  END save_product_groups;
  --==============================================================================================
 --   Name       : SAVE_MYPROFILE
 --   Created on : 21-APR-06
 --   Created By : S.V.SREERAJ
 --   Comments   : For Updating Myprofile from Administration -> Myprofile -> Personal Details
 --==============================================================================================
  PROCEDURE save_myprofile(
    v_contact_seq_id                     IN  OUT TPA_USER_CONTACTS.contact_seq_id%TYPE,
    v_primary_email_id                   IN  TPA_USER_CONTACTS.primary_email_id%TYPE,
    v_secondary_email_id                 IN  TPA_USER_CONTACTS.secondary_email_id%TYPE,
    v_res_phone_no                       IN  TPA_USER_CONTACTS.res_phone_no%TYPE,
    v_off_phone_no_1                     IN  TPA_USER_CONTACTS.off_phone_no_1%TYPE,
    v_off_phone_no_2                     IN  TPA_USER_CONTACTS.off_phone_no_2%TYPE,
    v_mobile_no                          IN  TPA_USER_CONTACTS.mobile_no%TYPE,
    v_added_by                           IN  TPA_USER_CONTACTS.added_by%TYPE,
    v_rows_processed                     IN  OUT NUMBER
  )
  IS
  BEGIN
    UPDATE tpa_user_contacts SET
      primary_email_id                        = v_primary_email_id,
      secondary_email_id                      = v_secondary_email_id,
      res_phone_no                            = v_res_phone_no,
      off_phone_no_1                          = v_off_phone_no_1,
      off_phone_no_2                          = v_off_phone_no_2,
      mobile_no                               = v_mobile_no,
      updated_by                              = v_added_by,
      updated_date                            = SYSDATE
      WHERE contact_seq_id = v_contact_seq_id;
    v_rows_processed := SQL%ROWCOUNT;
    COMMIT;
  END save_myprofile;
----------------------------------------------------------------------------------------------------------
   PROCEDURE change_password(
    v_contact_seq_id      IN  tpa_login_info.contact_seq_id%TYPE,
    v_user_id             IN  tpa_login_info.user_id%TYPE,
    v_old_password        IN  tpa_login_info.password%TYPE,
    v_new_password        IN  tpa_login_info.password%TYPE,
    v_rows_processed      IN  OUT NUMBER
  )
  IS
     CURSOR get_password_cur IS
     SELECT a.password,a.password_1,a.password_2,a.password_3,a.password_4,a.password_5 FROM tpa_login_info a  --Added for CR-KOC1235
      WHERE a.user_id = v_user_id;
      user tpa_login_info%ROWTYPE;

 BEGIN

    OPEN get_password_cur;
    FETCH  get_password_cur INTO user.password,user.password_1,user.password_2,user.password_3,user.password_4,user.password_5;  --Added for CR-KOC1235
    CLOSE get_password_cur;

IF  v_old_password!=ttk_util_pkg.FN_DECRYPT(user.password) THEN
    raise_application_error(-20078,' Enter the Current Password as Old Password');

ELSE
    IF ttk_util_pkg.FN_DECRYPT(user.password)=v_new_password  --Added for CR-KOC1235
    OR
ttk_util_pkg.FN_DECRYPT(user.password_1)=v_new_password    --Added for CR-KOC1235
    OR
 ttk_util_pkg.FN_DECRYPT(user.password_2)=v_new_password    --Added for CR-KOC1235
    OR
 ttk_util_pkg.FN_DECRYPT(user.password_3)=v_new_password    --Added for CR-KOC1235
    OR
 ttk_util_pkg.FN_DECRYPT(user.password_4)=v_new_password    --Added for CR-KOC1235
    OR
ttk_util_pkg.FN_DECRYPT(user.password_5)=v_new_password    --Added for CR-KOC1235
    THEN
   raise_application_error(-20079,' Old and New Passwords are Identical ');  --Added for CR-KOC1235
    ELSE

 UPDATE tpa_login_info l SET        --Added for CR-KOC1235
    l.password_1=l.password_2,      --Added for CR-KOC1235
    l.password_2=l.password_3,      --Added for CR-KOC1235
    l.password_3=l.password_4,      --Added for CR-KOC1235
    l.password_4=l.password_5,      --Added for CR-KOC1235
    l.password_5=l.password,      --Added for CR-KOC1235
    l.password=ttk_util_pkg.fn_encrypt(v_new_password),
      l.default_login_yn  = 'N',
      l.Password_Generated_Date=SYSDATE,
        l.first_login_yn='N'  --KOC1257
        WHERE contact_seq_id = v_contact_seq_id;
        END IF;
    v_rows_processed := SQL%ROWCOUNT;
    COMMIT;
    END IF;
  END change_password;
----------------------------------------------------------------------------------------------------------
  PROCEDURE select_acct_mngr_list(
    v_contact_name           IN tpa_user_contacts.contact_name%TYPE,
    v_role_seq_id            IN tpa_roles_code.role_seq_id%TYPE,
    v_employee_number        IN tpa_user_contacts.employee_number%TYPE,
    v_tpa_office_seq_id      IN tpa_user_contacts.tpa_office_seq_id%TYPE,
    v_sort_var               IN VARCHAR2 ,
    v_start_num              IN NUMBER,
    v_end_num                IN NUMBER ,
    v_sort_order             IN VARCHAR2,
    v_result_set             OUT sys_refcursor
  )
  IS
    v_sql_str                            VARCHAR2(2000);
    TYPE bind_tab_type IS TABLE OF VARCHAR2(250) INDEX BY BINARY_INTEGER ;
    bind_tab                             bind_tab_type;
    i                                    NUMBER(2) := 0;
    v_where                              VARCHAR2(2000);
  BEGIN
    IF  v_contact_name IS NOT NULL THEN
      v_where := v_where || ' AND a.contact_name LIKE :v_contact_name ';
      i := i+1;
      bind_tab(i) := UPPER(v_contact_name)||'%';
    END IF;
    IF v_role_seq_id IS NOT NULL THEN
      v_where := v_where || ' AND d.role_seq_id = :v_role_seq_id ';
      i := i+1;
      bind_tab(i) := v_role_seq_id;
    END IF;
    IF v_employee_number IS NOT NULL THEN
      v_where := v_where || ' AND a.employee_number = :v_employee_number ';
      i := i+1;
      bind_tab(i) := v_employee_number;
    END IF;
    IF v_tpa_office_seq_id IS NOT NULL THEN
      v_where := v_where || ' AND A.tpa_office_seq_id = :v_tpa_office_seq_id ';
      i := i+1;
      bind_tab(i) := v_tpa_office_seq_id;
    END IF;

    v_sql_str :=
     'SELECT
      F.user_id,
      A.contact_seq_id,
      a.contact_name,
      a.employee_number,
      a.tpa_office_seq_id,
      C.office_name,
      E.role_name
      FROM tpa_user_contacts a
      JOIN tpa_office_info C ON (a.tpa_office_seq_id = C.tpa_office_seq_id)
      JOIN tpa_user_roles D ON (A.contact_seq_id = D.contact_seq_id)
      JOIN tpa_roles_code E ON (D.role_seq_id = E.role_seq_id)
      JOIN tpa_login_info F ON (A.contact_seq_id = F.contact_seq_id)
      WHERE a.active_yn = ''Y''
      AND a.user_general_type_id=''TTK''';
      v_sql_str := v_sql_str || v_where;

    v_sql_str := ' SELECT * FROM (SELECT A.*,DENSE_RANK() OVER(ORDER BY '||v_sort_var||' '||v_sort_order||',ROWNUM) Q FROM ( '|| v_sql_str ||')A)
                       WHERE Q>= :v_start_num  AND Q <= :v_end_num ';

    IF bind_tab.FIRST IS NOT NULL THEN
      CASE bind_tab.COUNT
         WHEN 1  THEN OPEN v_result_set FOR v_sql_str USING  bind_tab(1) , v_start_num , v_end_num ;
         WHEN 2  THEN OPEN v_result_set FOR v_sql_str USING  bind_tab(1),bind_tab(2), v_start_num , v_end_num ;
         WHEN 3  THEN OPEN v_result_set FOR v_sql_str USING  bind_tab(1),bind_tab(2) ,bind_tab(3) , v_start_num , v_end_num ;
         WHEN 4  THEN OPEN v_result_set FOR v_sql_str USING  bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) , v_start_num , v_end_num ;
      END CASE ;
    ELSE
      OPEN v_result_set FOR v_sql_str USING v_start_num , v_end_num ;
    END IF;
  END select_acct_mngr_list;
  ----------------------------------------------------------------------------------------------------------
  PROCEDURE select_notification_list(
  v_group_reg_seq_id          IN tpa_group_registration.group_reg_seq_id%TYPE,
  notify_ist_cur              OUT SYS_REFCURSOR
  )
  IS
  BEGIN

   OPEN notify_ist_cur FOR
        SELECT
               A.msg_id,
               A.msg_name,
               'AS' status
        FROM source_message A JOIN source_message_custom_grp B ON(A.msg_id=B.msg_id)
        WHERE B.group_reg_seq_id=v_group_reg_seq_id
        UNION
        SELECT
               A.msg_id,
               A.msg_name,
               'NA' status
        FROM source_message A
        WHERE msg_id NOT IN
        (SELECT C.msg_id
         FROM source_message_custom_grp C
         WHERE C.group_reg_seq_id=v_group_reg_seq_id)
         AND A.customization_allowed_yn='Y';
  END select_notification_list;
  ----------------------------------------------------------------------------------------------------------
  -- PROCEDURE INSERT RECORDS INTO SOURCE_MESSAGE_CUSTOM_GRP
-- This procedure will Delete the Existing records and Inserts the New Records along with the Existing ones
-- If they are not removed from the list
----------------------------------------------------------------------------------------------------------
   PROCEDURE save_notification_info(
   v_group_reg_seq_id          IN tpa_group_registration.group_reg_seq_id%TYPE,
   v_msg_id                    IN VARCHAR2 , --CONCATENATED msg_ids
   v_added_by                  IN NUMBER,
   v_rows_processed            IN  OUT NUMBER
   )
   IS
         str_tab   Ttk_Util_Pkg.str_table_type;
         v_notify_type_id tpa_group_registration.notify_type_id%TYPE;
   BEGIN

      SELECT notify_type_id INTO v_notify_type_id
     FROM tpa_group_registration G WHERE G.GROUP_REG_SEQ_ID=v_group_reg_seq_id;

     IF v_notify_type_id = NULL OR v_notify_type_id = 'NIG' THEN
        raise_application_error(-20679,'Notify Type Selected as General');
     END IF;

     -- Deleteing the Records source_message_custom_grp
     DELETE FROM source_message_custom_grp WHERE group_reg_seq_id=v_group_reg_seq_id;

      -- Calling Function from Ttk_Util_Pkg Package
         str_tab := Ttk_Util_Pkg.parse_str ( v_msg_id );

         FOR v_msg_id IN str_tab.First..str_tab.Last
         LOOP

           INSERT INTO source_message_custom_grp(
             cust_seq_id,
            group_reg_seq_id,
            msg_id,
            added_by,
            added_date
           )
           VALUES (
           source_message_custom_grp_seq.nextval,
           v_group_reg_seq_id,
           str_tab(v_msg_id),
           v_added_by,
           SYSDATE
          );
     END LOOP;
     v_rows_processed := SQL%ROWCOUNT;
    COMMIT;
  END save_notification_info;
 --==============================================================================================
 --   Name       : save_password_config
 --   Created on : 12-12-12
 --   Created By : Sadiq Basha
 -- MODIFIED BY: RAM
 --MODIFIED DATE: 26/03/2013
 --   Comments   : This procedure used  for saving the configuration details in password
 --  Added for CR-KOC1235
 --==============================================================================================
  PROCEDURE save_password_config
  (v_acn_expire_in_days     IN  password_config.acn_expire_in_days%TYPE,
   v_password_valid_days    IN password_config.password_valid_days%TYPE,
   v_wrong_attempts         IN password_config.wrong_attempts%TYPE,
   v_alert_days             IN password_config.alert_days%TYPE,
   v_config_type            IN password_config.Config_Type%TYPE, --KOC1257
   v_rows_processed         OUT  number)
   IS
BEGIN
  IF v_config_type='TTK'     THEN -- MODIFIED FOR KOC1257
      UPDATE password_config SET acn_expire_in_days  =  v_acn_expire_in_days,
                             password_valid_days =  v_password_valid_days,
                             wrong_attempts      =  v_wrong_attempts,
                             alert_days          =  v_alert_days,
                             config_type         =  v_config_type
                             WHERE config_seq_id=1;

  ELSIF  v_config_type='WHR' THEN --KOC1257
     UPDATE password_config SET acn_expire_in_days  =  v_acn_expire_in_days,
                             password_valid_days =  v_password_valid_days,
                             wrong_attempts      =  v_wrong_attempts,
                             alert_days          =  v_alert_days,
                             config_type         =  v_config_type
                             WHERE config_seq_id=2;

 ELSIF   v_config_type='INS' THEN   --KOC1257

  UPDATE password_config SET acn_expire_in_days  =  v_acn_expire_in_days,
                             password_valid_days =  v_password_valid_days,
                             wrong_attempts      =  v_wrong_attempts,
                             alert_days          =  v_alert_days,
                             config_type         =  v_config_type
                             WHERE config_seq_id=3;
  END IF;

  v_rows_processed:=sql%rowcount;
  COMMIT;
END save_password_config;
 --==============================================================================================
 --   Name       : create_user_acn_log
 --   Created on : 12-12-12
 --   Created By : IBRAHIM.SAYYED
 --   Comments   : This procedure used to maintain the log for usermanagement module
 --==============================================================================================
PROCEDURE create_user_acn_log(v_contact_seq_id    IN        tpa_user_contacts.contact_seq_id%TYPE,
                                v_new_str           IN        VARCHAR2,
                                v_added_by          IN        NUMBER) IS

   v_old_str            varchar2(30000);
   v_remarks            varchar2(30000);
   str_old_tab          ttk_util_pkg.str_table_type;
   str_new_tab          ttk_util_pkg.str_table_type;

BEGIN
  SELECT  --a.prefix_general_type_id
              '| User Prefix                 :|'||(CASE a.prefix_general_type_id WHEN 'PMR' THEN 'Mr.' WHEN 'MRS' THEN 'Mrs.' WHEN 'PMS' THEN 'Ms.' WHEN 'PDR' THEN 'Dr.' END)
            ||'| Contact Name                :|'||UPPER(a.contact_name)
            ||'| Designation                 :|'||b.designation_description
            ||'| Primary Email Id            :|'||NVL(a.primary_email_id,'Blank')
            ||'| Secondary Email Id          :|'||NVL(a.secondary_email_id,'Blank')
            ||'| User Status Changed         :|'||(CASE a.active_yn  WHEN 'Y' THEN 'Active' WHEN 'N' THEN 'Inactive' END)
            ||'| Provide Application Access  :|'||(CASE a.provide_access_user_yn WHEN 'Y' THEN 'Yes' WHEN 'N' THEN 'No' END)
            ||'| Contact Type                :|'||d.contact_description
            ||'| Employee Number             :|'||a.employee_number
            ||'| Department                  :|'||c.description
            ||'| Residence Phone number      :|'||NVL(a.res_phone_no,0)
            ||'| Office Phone No.            :|'||NVL(a.off_phone_no_1,0)
            ||'| Office Phone No.            :|'||NVL(a.off_phone_no_2,0)
            ||'| Mobile No.                  :|'||NVL(a.mobile_no,0)
            ||'| Fax No.                     :|'||NVL(a.fax_no,0)
            ||'| Pre-Auth Limit                :|'||NVL(a.contact_pa_limit,0)
            ||'| Claim Limit                  :|'||NVL(a.contact_claim_limit,0)
            ||'| Provide Soft Copy Access      :|'||(CASE a.softcopy_access_yn WHEN 'Y' THEN 'Yes' ELSE 'No' END)
            ||'| Provide Soft Copy Access FOR OTHER BRANCH:|'||(CASE a.softcopy_other_branch_yn WHEN 'Y' THEN 'Yes' ELSE 'No' END)
            ||'| Date Of Joining              :|'||a.date_of_joining
            ||'| Date Of Resignation          :|'||nvl(to_char(to_Date(a.date_of_resignation,'dd-mm-yyyy'),'dd-mm-yyyy'),to_char('00-00-00'))
            ||'| User Role                    :|'||NVL(f.role_name,0)
            ||'| Primary TTK Branch           :|'||NVL(g.office_name,0)
         --   ||'| Pre-Auth SMS YES/NO          :|'||NVL(a.pa_sms_yn,0)
            ||'| Doctor Registration No       :|'||NVL(a.dr_regist_nmbr,0)
            ||'| Doctor Qulification          :|'||NVL(a.dr_qualif,0)
            ||'| Resident Doctor              :|'||NVL(a.resident_dr_yn,0)
            ||'| Specialisation:              :|'||NVL(h.description,0)
			||'| Ptnr designation:            :|'||NVL(a.designation,0)||'|'  ---newly added for partner
			INTO   v_old_str
    FROM tpa_user_contacts a
    LEFT OUTER JOIN tpa_designation_code b              ON(a.designation_type_id=b.designation_type_id)
    LEFT OUTER JOIN tpa_general_code c       ON(a.dept_general_type_id=c.general_type_id)
    LEFT OUTER JOIN tpa_hosp_contact_code d  ON(a.contact_type_id=d.contact_type_id)
    LEFT OUTER JOIN tpa_user_roles        e  ON(a.contact_seq_id=e.contact_seq_id)
    LEFT OUTER JOIN tpa_roles_code        f  ON(e.role_seq_id=f.role_seq_id)
    LEFT OUTER JOIN tpa_office_info       g  ON(a.tpa_office_seq_id=g.tpa_office_seq_id)
    LEFT OUTER JOIN tpa_hosp_dr_speciality_code h ON(a.spec_type_id=h.spec_type_id) WHERE a.contact_seq_id=v_contact_seq_id;

    str_new_tab     := ttk_util_pkg.parse_str(v_new_str,'|');
    str_old_tab     := ttk_util_pkg.parse_str(v_old_str,'|');

    FOR I IN str_new_tab.FIRST .. str_new_tab.LAST LOOP
      IF str_new_tab(i)!=str_old_tab(i*2) THEN
        v_remarks:=v_remarks||CHR(10)||CHR(10)||str_old_tab((i*2)-1)||' Changed From '||str_old_tab(i*2)||' To '||str_new_tab(i)||'.';
      END IF;
    END LOOP;
    IF v_remarks IS NOT NULL THEN
     INSERT INTO tpa_user_acn_log(LOG_SEQ_ID,CONTACT_SEQ_ID,REMARKS,ADDED_BY,ADDED_DATE)
       VALUES(tpa_user_acn_log_seq.nextval,v_contact_seq_id,v_remarks,v_added_by,SYSDATE);
    END IF;
END;
--==============================================================================================
 --   Name       : release_acc_lock
 --   Created on : 12-12-12
 --   Created By : Sadiq
 --   modified by: Ram
 --   modified Date: 21-03-2013
 --   Comments   : scheduled to release account for wrong attempts
 --                Account will be released at {()} timing or upon user request
 --  Added for CR-KOC1235, MODIFIED FOR KOC1257
--==============================================================================================
  PROCEDURE release_acc_lock
  IS
  TYPE CONTACT_SEQ IS TABLE OF TPA_LOGIN_INFO.CONTACT_SEQ_ID%TYPE INDEX BY BINARY_INTEGER;
  TYPE POLICY_GRP_SEQ IS TABLE OF TPA_ENR_POLICY_GROUP.POLICY_GROUP_SEQ_ID%TYPE INDEX BY BINARY_INTEGER;  --KOC1257

  contact_seq_tab      CONTACT_SEQ;
  POLICY_GRP_SEQ_TAB      POLICY_GRP_SEQ; --KOC1257

BEGIN
    SELECT a.contact_seq_id BULK COLLECT INTO CONTACT_SEQ_TAB --modfied for   KOC1257
    FROM   tpa_login_info a JOIN tpa_user_contacts b ON (A.contact_seq_id = B.contact_seq_id) AND
    A.active_yn = 'Y' and (a.accn_locked_yn= 'Y' OR A.WRONG_ATTEMPTS>0)
    AND b.user_general_type_id IN('TTK','DMC','CAL','COR','INS');

   SELECT b.POLICY_GROUP_SEQ_ID BULK COLLECT INTO POLICY_GRP_SEQ_TAB --KOC1257
    FROM TPA_ENR_POLICY A
    JOIN TPA_ENR_POLICY_GROUP B ON (A.POLICY_SEQ_ID=B.POLICY_SEQ_ID)
    WHERE A.COMPLETED_YN='Y'
    AND A.POLICY_STATUS_GENERAL_TYPE_ID!='POC'
    AND A.DELETED_YN='N'
    AND B.DELETED_YN='N'
    AND (B.ACCN_LOCKED_YN='Y' OR B.WRONG_ATTEMPTS>0)
    AND A.ENROL_TYPE_ID='COR';

    IF CONTACT_SEQ_TAB.FIRST IS NOT NULL THEN
      FORALL I IN contact_seq_tab.FIRST..contact_seq_tab.LAST
        UPDATE tpa_login_info a
      SET a.accn_locked_yn = 'N',a.wrong_attempts=NULL where a.contact_seq_id=contact_seq_tab(i);
    END IF;

     IF POLICY_GRP_SEQ_TAB.FIRST IS NOT NULL THEN --KOC1257
      FORALL I in POLICY_GRP_SEQ_TAB.FIRST..POLICY_GRP_SEQ_TAB.LAST
      UPDATE TPA_ENR_POLICY_GROUP B SET B.ACCN_LOCKED_YN='N',
      B.WRONG_ATTEMPTS=NULL
      WHERE B.POLICY_GROUP_SEQ_ID=POLICY_GRP_SEQ_TAB(I);
    END IF;

   COMMIT;
END release_acc_lock;
--==============================================================================================
 --   Name       : login_lock
 --   Created on : 12-12-12
 --   Created By : Sadiq
 --   Comments   : scheduled for login aging : Account will be disabled after {()} days if not used
 --  Added for CR-KOC1235
--==============================================================================================
PROCEDURE login_lock
 IS
  TYPE CONTACT_SEQ IS TABLE OF TPA_LOGIN_INFO.CONTACT_SEQ_ID%TYPE INDEX BY BINARY_INTEGER;
  contact_seq_tab      CONTACT_SEQ;
  v_login_expire_days NUMBER(5);
 BEGIN

   SELECT a.acn_expire_in_days INTO v_login_expire_days FROM password_config A WHERE a.config_seq_id=1;
  SELECT a.contact_seq_id BULK COLLECT INTO contact_seq_tab
  FROM  tpa_login_info a JOIN tpa_user_contacts b  ON (A.contact_seq_id = B.contact_seq_id) AND  A.active_yn = 'Y'
  AND  b.user_general_type_id in ('TTK','DMC','CAL')
  AND TRUNC(sysdate-NVL(a.recent_login_date,SYSDATE))>= v_login_expire_days;

   IF contact_seq_tab.FIRST IS NOT NULL THEN
     FORALL I IN contact_seq_tab.FIRST..contact_seq_tab.LAST

     UPDATE tpa_login_info l
     SET l.active_yn='N' where l.contact_seq_id=contact_seq_tab(i);

    FORALL I IN contact_seq_tab.FIRST..contact_seq_tab.LAST
    UPDATE tpa_user_contacts N SET
   N.active_yn='N' where N.contact_seq_id=contact_seq_tab(i);
   END IF;
  COMMIT;
END login_lock;
--==============================================================================================
 --   Name       : expire_password
 --   Created on : 12-12-12
 --   Created By : Sadiq
 --   modified by: Ram
 --   modified Date: 21-03-2013
 --   Comments   : scheduled for password aging : password will expire after {()} days
--  Added for CR-KOC1235
--==============================================================================================
PROCEDURE expire_password
   IS
   TYPE CONTACT_SEQ IS TABLE OF TPA_LOGIN_INFO.CONTACT_SEQ_ID%TYPE INDEX BY BINARY_INTEGER;
   TYPE POL_GRP_SEQ IS TABLE OF TPA_ENR_POLICY_GROUP.POLICY_GROUP_SEQ_ID%TYPE INDEX BY BINARY_INTEGER; --KOC1257

   contact_seq_tab      CONTACT_SEQ;
   HR_contact_seq_tab      CONTACT_SEQ; --KOC1257
   INS_contact_seq_tab      CONTACT_SEQ; --KOC1257
   POL_GRP_SEQ_TAB     POL_GRP_SEQ; --KOC1257

   V_PASSWORD_VALID_DAYS NUMBER(5);
   V_PASSWORD_VALID_DAYS_HR NUMBER(5); --KOC1257
   V_PASSWORD_VALID_DAYS_INS NUMBER(5); --KOC1257


   BEGIN

   SELECT a.PASSWORD_VALID_DAYS INTO V_PASSWORD_VALID_DAYS FROM password_config A WHERE a.config_seq_id=1;

   SELECT a.contact_seq_id BULK COLLECT INTO contact_seq_tab
   FROM  tpa_login_info a JOIN tpa_user_contacts b  ON (A.contact_seq_id = B.contact_seq_id) AND  A.active_yn = 'Y'
   AND  b.user_general_type_id in ('TTK','DMC','CAL')
   AND TRUNC(sysdate-NVL(a.password_generated_date,SYSDATE))>=V_PASSWORD_VALID_DAYS;
 --KOC1257

   SELECT a.PASSWORD_VALID_DAYS INTO V_PASSWORD_VALID_DAYS_HR FROM password_config A WHERE a.config_seq_id=2; --KOC1257

   SELECT a.contact_seq_id BULK COLLECT INTO HR_contact_seq_tab
   FROM  tpa_login_info a JOIN tpa_user_contacts b  ON (A.contact_seq_id = B.contact_seq_id) AND  A.active_yn = 'Y' --KOC1257
   AND  b.user_general_type_id in ('COR')
   AND TRUNC(sysdate-NVL(a.password_generated_date,SYSDATE))>=V_PASSWORD_VALID_DAYS_HR;

   SELECT a.PASSWORD_VALID_DAYS INTO V_PASSWORD_VALID_DAYS_INS FROM password_config A WHERE a.config_seq_id=3; --KOC1257

   SELECT a.contact_seq_id BULK COLLECT INTO INS_contact_seq_tab
   FROM  tpa_login_info a JOIN tpa_user_contacts b  ON (A.contact_seq_id = B.contact_seq_id) AND  A.active_yn = 'Y' --KOC1257
   AND  b.user_general_type_id in ('INS')
   AND TRUNC(sysdate-NVL(a.password_generated_date,SYSDATE))>=V_PASSWORD_VALID_DAYS_INS;


   SELECT B.POLICY_GROUP_SEQ_ID BULK COLLECT INTO POL_GRP_SEQ_TAB --KOC1257
   FROM    TPA_ENR_POLICY A
   JOIN TPA_ENR_POLICY_GROUP B ON ( A.POLICY_SEQ_ID=B.POLICY_SEQ_ID )
   left outer join tpa_group_registration c on (a.group_reg_seq_id=c.group_reg_seq_id)
   WHERE  A.COMPLETED_YN='Y' AND A.POLICY_STATUS_GENERAL_TYPE_ID!='POC'
   AND A.DELETED_YN='N' AND  B.DELETED_YN='N' AND A.ENROL_TYPE_ID='COR'
   and c.group_id not in ('Y0063', 'Y040', 'Y0073' , 'USL01')
   AND TRUNC(sysdate-NVL(b.password_generated_date,SYSDATE))>=
   (select D.PASSWORD_VALIDITY from tpa_enr_policy C,weblogin_config d
   where C.policy_seq_id=d.policy_seq_id and d.password_validity is not null
   and C.policy_status_general_type_id!='POC' AND C.COMPLETED_YN='Y' AND C.ENROL_TYPE_ID='COR'
   AND A.POLICY_SEQ_ID=C.POLICY_SEQ_ID);


 IF contact_seq_tab.FIRST IS NOT NULL THEN
     FORALL I IN contact_seq_tab.FIRST..contact_seq_tab.LAST

      UPDATE tpa_login_info L SET
      l.Password_Generated_Date=NULL,
      l.updated_date = SYSDATE
      WHERE l.contact_seq_id = contact_seq_tab(i);
      END IF;


  IF HR_contact_seq_tab.FIRST IS NOT NULL THEN  --KOC1257

     FORALL I IN HR_contact_seq_tab.FIRST..HR_contact_seq_tab.LAST


      UPDATE tpa_login_info L SET
      l.Password_Generated_Date=NULL,
      l.updated_date = SYSDATE
      WHERE l.contact_seq_id = HR_contact_seq_tab(i);
      END IF;

 IF INS_contact_seq_tab.FIRST IS NOT NULL THEN --KOC1257
     FORALL I IN INS_contact_seq_tab.FIRST..INS_contact_seq_tab.LAST

      UPDATE tpa_login_info L SET
      l.Password_Generated_Date=NULL,
      l.updated_date = SYSDATE
      WHERE l.contact_seq_id = INS_contact_seq_tab(i);
      END IF;

  IF POL_GRP_SEQ_TAB.FIRST IS NOT NULL THEN --KOC1257
   FORALL I IN POL_GRP_SEQ_TAB.FIRST..POL_GRP_SEQ_TAB.LAST

   UPDATE TPA_ENR_POLICY_GROUP B
   SET B.PASSWORD_GENERATED_DATE=NULL,
       B.UPDATED_DATE=SYSDATE
   WHERE B.POLICY_GROUP_SEQ_ID=POL_GRP_SEQ_TAB(I);

 END IF;

      COMMIT;
END expire_password;
--==============================================================================================
 --   Name       : reset_pwd_all
 --   Created on : 12-12-12
 --   Created By : Sadiq
 --   Comments   : This will reset password for all TTK users
 --  Added for CR-KOC1235
--===========================================================================================
PROCEDURE reset_pwd_all(
  v_added_by            IN tpa_login_info.added_by%TYPE,
  v_rows_processed      IN  OUT NUMBER
)
 IS
  TYPE CONTACT_SEQ IS TABLE OF TPA_LOGIN_INFO.CONTACT_SEQ_ID%TYPE INDEX BY BINARY_INTEGER;
  contact_seq_tab      CONTACT_SEQ;
  BEGIN
   SELECT a.contact_seq_id BULK COLLECT INTO contact_seq_tab
   FROM  tpa_login_info a JOIN tpa_user_contacts b  ON (A.contact_seq_id = B.contact_seq_id) AND  A.active_yn = 'Y'
   AND  b.user_general_type_id in ('TTK','DMC','CAL');

 IF contact_seq_tab.FIRST IS NOT NULL THEN
     FORALL I IN contact_seq_tab.FIRST..contact_seq_tab.LAST

      UPDATE tpa_login_info K SET
      k.Password_Generated_Date=NULL,
      k.updated_by = v_added_by,
      k.updated_date = SYSDATE
      WHERE k.contact_seq_id = contact_seq_tab(i);
      END IF;
      v_rows_processed := SQL%ROWCOUNT;
      COMMIT;
END reset_pwd_all;
---=================================================================
--koc_ins_mail
   PROCEDURE save_notification_ins_info(
   v_ins_seq_id                IN TPA_INS_INFO.INS_SEQ_ID%TYPE,
   v_msg_id                    IN VARCHAR2 , --CONCATENATED msg_ids
   v_added_by                  IN NUMBER,
   v_rows_processed            IN  OUT NUMBER
   )
   IS
         str_tab   Ttk_Util_Pkg.str_table_type;
         v_notify_type_id tpa_group_registration.notify_type_id%TYPE;
   BEGIN

      SELECT notify_type_id INTO v_notify_type_id
     FROM TPA_INS_INFO G WHERE G.INS_SEQ_ID=v_ins_seq_id;

     IF v_notify_type_id = NULL OR v_notify_type_id = 'NIG' THEN
        raise_application_error(-20679,'Notify Type Selected as General');
     END IF;

     -- Deleteing the Records source_message_custom_grp
     DELETE FROM source_message_custom_grp WHERE INS_SEQ_ID=v_ins_seq_id;

      -- Calling Function from Ttk_Util_Pkg Package
         str_tab := Ttk_Util_Pkg.parse_str ( v_msg_id );

         FOR v_msg_id IN str_tab.First..str_tab.Last
         LOOP

           INSERT INTO source_message_custom_grp(
             cust_seq_id,
            INS_SEQ_ID,
            msg_id,
            added_by,
            added_date
           )
           VALUES (
           source_message_custom_grp_seq.nextval,
           v_ins_seq_id,
           str_tab(v_msg_id),
           v_added_by,
           SYSDATE
          );
     END LOOP;
     v_rows_processed := SQL%ROWCOUNT;
    COMMIT;
  END save_notification_ins_info;
----------------------------------------------------------------------------------------------------------

PROCEDURE select_notification_INS_list(
   v_ins_seq_id                IN TPA_INS_INFO.INS_SEQ_ID%TYPE,
   notify_ist_cur              OUT SYS_REFCURSOR
  )
  IS
  BEGIN

   OPEN notify_ist_cur FOR
        SELECT
               A.msg_id,
               A.msg_name,
               'AS' status
        FROM source_message A JOIN source_message_custom_grp B ON(A.msg_id=B.msg_id)
        WHERE B.ins_seq_id = v_ins_seq_id
        UNION
        SELECT
               A.msg_id,
               A.msg_name,
               'NA' status
        FROM source_message A
        WHERE msg_id NOT IN
        (SELECT C.msg_id
         FROM source_message_custom_grp C
         WHERE C.ins_seq_id = v_ins_seq_id)
         AND A.customization_allowed_yn='Y';
  END select_notification_INS_list;
--koc_ins_mail
-------------------------------------------------------------
PROCEDURE save_provider_creds(
    v_contact_seq_id                 IN OUT tpa_user_contacts.contact_seq_id%TYPE,
    v_user_general_type_id           IN tpa_user_contacts.user_general_type_id%TYPE,--HOS
    v_contact_name                   IN tpa_user_contacts.contact_name%TYPE,
    v_provider_id                    IN tpa_user_contacts.provider_id%TYPE,
    v_primary_email_id               IN tpa_user_contacts.primary_email_id%TYPE,
    v_added_by                       IN tpa_user_contacts.added_by%TYPE,
    v_hosp_contact_number            IN tpa_user_contacts.Mobile_No%TYPE,
    v_result                         OUT SYS_REFCURSOR,
    v_row_processed                  OUT number
  )
  IS
    v_ctr                              NUMBER(1) := 0;
    v_password                         TPA_LOGIN_INFO.PASSWORD%TYPE;
    v_user_id                          TPA_LOGIN_INFO.USER_ID%TYPE;
    v_count                            NUMBER(10);
   
    
    CURSOR prev_usr_dtl_cur IS
               SELECT c.contact_seq_id,C.active_yn,c.date_of_joining,C.date_of_resignation
                   FROM tpa_user_contacts C
                   WHERE C.contact_seq_id=v_contact_seq_id;

   rec_prev_usr                     prev_usr_dtl_cur%ROWTYPE;
   v_str                            varchar2(10000); --Added for koc1233
   
 
  BEGIN

  IF v_provider_id IS NOT NULL THEN
  SELECT COUNT(1) INTO v_count FROM APP.TPA_USER_CONTACTS UC WHERE UC.PROVIDER_ID=v_provider_id;
  END IF;  
  IF v_count>0 THEN
    raise_application_error(-20871,'Credentials has been already sent to this provider');
	ELSE
     IF v_contact_seq_id = 0 THEN
      IF v_user_general_type_id='HOS' THEN
      INSERT INTO tpa_user_contacts (
        contact_seq_id,
        user_general_type_id,
        contact_name,
        primary_email_id,
        Active_Yn,
        provider_id,
        mobile_no,
        added_by,
        added_date)
      VALUES (
        tpa_contact_seq.NEXTVAL,
        v_user_general_type_id,
        UPPER(v_contact_name),
        v_primary_email_id,
        'Y',
        v_provider_id,
        v_hosp_contact_number,
        v_added_by,
        SYSDATE) RETURNING contact_seq_id INTO v_contact_seq_id;
      END IF;
          
        IF v_user_general_type_id ='HOS' THEN
           -- Calling User id and password generator.
           ----------------------------------------------
           gen_prov_userid(v_provider_id,v_user_id,v_password);

           save_login(
              v_contact_seq_id,
              v_user_id,
              v_password,
              1003,
              v_primary_email_id,
              'Y',
              NULL,
              v_contact_name ,
              null ,
              v_added_by,
              'N'   
           );
        END IF;

     
    ELSE
         --Below query used to maintain the log
         
       SELECT  ('|'|| v_contact_name
             ||'|'||  v_provider_id 
             ||'|'||  NVL(v_primary_email_id,'Blank'))
             INTO v_str FROM DUAL;

      create_user_acn_log(v_contact_seq_id,v_str,v_added_by);  
      
      
      UPDATE tpa_user_contacts   SET
        contact_name                   = UPPER(v_contact_name),
        provider_id                    = v_provider_id,
        primary_email_id               = v_primary_email_id,
        active_yn                      = 'Y',
        mobile_no                      = v_hosp_contact_number,
        updated_by                     = v_added_by,
        updated_date                   = SYSDATE
        WHERE contact_seq_id = v_contact_seq_id;
  
    END IF;
   END IF;
    v_row_processed := SQL%ROWCOUNT;
    COMMIT;
   OPEN v_result FOR 
   SELECT c.contact_seq_id,C.CONTACT_NAME,C.PROVIDER_ID,C.PRIMARY_EMAIL_ID,
   I.USER_ID,TTK_UTIL_PKG.fn_decrypt(I.PASSWORD) AS PASSWORD,c.mobile_no 
   FROM APP.TPA_USER_CONTACTS C 
   JOIN APP.TPA_LOGIN_INFO I ON (I.CONTACT_SEQ_ID=C.CONTACT_SEQ_ID)
   WHERE C.CONTACT_SEQ_ID=v_contact_seq_id;
  END save_provider_creds;
  ----------------------------------------
  PROCEDURE gen_prov_userid(
    v_prov_id          IN tpa_user_contacts.provider_id%TYPE,
    v_user_id          OUT tpa_login_info.user_id%TYPE,
    v_password         OUT tpa_login_info.password%TYPE
  )
  IS
    v_len NUMBER(2);
  BEGIN
  
    v_user_id  := v_prov_id;
    v_password := v_prov_id;
  END gen_prov_userid;
 --====================================================================
 PROCEDURE save_hosp_contacts(
    v_contact_seq_id                 IN OUT tpa_user_contacts.contact_seq_id%TYPE,
    v_user_general_type_id           IN tpa_user_contacts.user_general_type_id%TYPE,
    v_hosp_seq_id                    IN tpa_user_contacts.hosp_seq_id%TYPE,
    v_prefix_general_type_id         IN tpa_user_contacts.prefix_general_type_id%TYPE,
    v_contact_name                   IN tpa_user_contacts.contact_name%TYPE,
    v_active_yn                      IN tpa_user_contacts.active_yn%TYPE,
    v_designation_type_id            IN tpa_user_contacts.designation_type_id%TYPE,
    v_primary_email_id               IN tpa_user_contacts.primary_email_id%TYPE,
    v_secondary_email_id             IN tpa_user_contacts.secondary_email_id%TYPE,
    v_off_phone_no_1                 IN tpa_user_contacts.off_phone_no_1%TYPE,
    v_mobile_no                      IN tpa_user_contacts.mobile_no%TYPE,
    v_added_by                       IN tpa_user_contacts.added_by%TYPE,
    v_std_code                       IN tpa_user_contacts.std_code%type,
    v_isd_code                       IN tpa_user_contacts.isd_code%type,
    v_gender_general_type            IN tpa_user_contacts.gender_general_type%type,
    v_age                            In tpa_user_contacts.age%type
                
  )
  IS
  v_rows_processed      number(10);
  v_user_id  tpa_login_info.user_id%TYPE;
  V_CNT   NUMBER(10);
  v_prov_contact_yn  varchar2(10):='N';
   BEGIN
     SELECT COUNT(1) INTO V_CNT FROM APP.TPA_USER_CONTACTS UC WHERE UC.PROV_CONT_YN='Y' AND 
     UC.HOSP_SEQ_ID=v_hosp_seq_id;
      IF V_CNT =0 then 
       v_prov_contact_yn:='Y';
      ELSE
        raise_application_error(-20869,'primary contact already exist');
      END IF;
     --adding null for ptnr_seq_id ,designation_name,ptnr_user_type here and is present in last 
     IF v_hosp_seq_id IS NOT NULL THEN 
      save_contacts(v_contact_seq_id,v_user_general_type_id,v_hosp_seq_id,
                          null,null,null,v_prefix_general_type_id,v_contact_name,v_designation_type_id,
                          v_primary_email_id,v_secondary_email_id,v_active_yn,null,null,null,null,null,
                          null,null,null,null,v_off_phone_no_1,null,v_mobile_no,null,null,null,v_added_by,v_user_id,null,
                          null,null,null,null,null,v_rows_processed,null,null,null,null,null,v_std_code,
                          v_isd_code,null,null,null,null,v_gender_general_type,v_age,v_prov_contact_yn,null,null,null,null,null);
    END IF;
  END save_hosp_contacts;
 ----========================================================
 FUNCTION get_gen_codes(v_flag               VARCHAR2,
                       v_header             varchar2,
                       v_description        tpa_general_code.description%type)
RETURN VARCHAR2
IS
v_sql_str              clob;
v_result_set           sys_refcursor;
v_result               TPA_GENERAL_CODE.DESCRIPTION%TYPE;

CURSOR nationality_cur IS
SELECT a.nationality_id FROM tpa_nationalities_code a
where UPPER(a.description)=UPPER(v_description);


BEGIN
  
 IF v_flag='NAT' THEN
   OPEN nationality_cur;
   FETCH nationality_cur INTO v_result;
   CLOSE nationality_cur;
 ELSE
  v_sql_str:='SELECT tgc.general_type_id FROM tpa_general_code tgc
                   where UPPER(tgc.description)=UPPER((:v_description))';
   IF v_header='GEN' THEN
    v_sql_str:=v_sql_str||' and tgc.header_type=''GENDER_DETAILS''';
   ELSIF v_header='AUTH' THEN
       v_sql_str:=v_sql_str||' and tgc.header_type=''AUTHORITY_TYPE''';
   ELSIF v_header='CONS' THEN
       v_sql_str:=v_sql_str||' and tgc.header_type=''CONSULTATION_TYPE''';  
   END IF;
  
  OPEN v_result_set FOR  v_sql_str USING v_description;
  FETCH v_result_set INTO v_result;
  CLOSE v_result_set;
  
  END IF;
  RETURN v_result;
  
END get_gen_codes;  

---==========================================================
PROCEDURE hosp_docotors_upload( v_hosp_doc   clob,v_log_file  out clob)
  IS
  
  v_doc                         DBMS_XMLDOM.DOMDocument;
  v_elem                        DBMS_XMLDOM.DOMElement;
  v_elem1                       DBMS_XMLDOM.DOMElement;
  v_elem2                       DBMS_XMLDOM.DOMElement;
  v_elem3                       DBMS_XMLDOM.DOMElement;
  v_root_node_list              DBMS_XMLDOM.DOMNODELIST;
  v_parent_node_lst             DBMS_XMLDOM.DOMNODELIST;
  v_chld_node_list              DBMS_XMLDOM.DOMNODELIST;  
  v_parent_node                 DBMS_XMLDOM.domnode;
  v_chaild_node                 DBMS_XMLDOM.domnode;
  v_root_node                   DBMS_XMLDOM.domnode;
  v_xml_doc                     xmltype;
  contact_rec                   tpa_user_contacts%rowtype;
  batch_rec                     tpa_professional_batch_dtls%rowtype;
  v_gender_type                 tpa_general_code.description%type;
  v_user_id                     tpa_login_info.user_id%type;
  v_ROW_PROCESSED               number;
  v_hossp_doc   clob;--for testing
  V_PROF_BATCH_SEQ_ID            tpa_professional_batch_dtls.PROF_BATCH_SEQ_ID%TYPE;
  V_PROVIDER_LOG_SEQ_ID          TPA_PROVIDER_LOGS.PROVIDER_LOG_SEQ_ID%type;  

CURSOR prof_logs(v_bach_seqid NUMBER) IS 
SELECT * FROM tpa_provider_logs p 
join tpa_professional_batch_dtls bd on (bd.prof_batch_seq_id=p.prof_batch_seq_id)
where bd.prof_batch_seq_id=v_bach_seqid;

Cursor dhpo_prof(v_prof_id  varchar2) is select m.professional_name,m.clinitian_id from app.dha_clinicians_list_master m 
where m.clinitian_id=v_prof_id;
      prof_rec    dhpo_prof%rowtype; 
BEGIN
 -- select t.xml_col into v_hossp_doc from xml_test t;--for testing
  v_xml_doc:=xmltype(v_hosp_doc);
  v_doc            := dbms_xmldom.newdomdocument(v_xml_doc);
  v_root_node_list := dbms_xmldom.getelementsbytagname(v_doc, 'provider');
  for v_root_node_index in 0 .. dbms_xmldom.getlength(v_root_node_list) - 1 loop
    v_root_node := dbms_xmldom.item(v_root_node_list, v_root_node_index);
    v_elem        := dbms_xmldom.makeelement(v_root_node);
     v_parent_node_lst := dbms_xmldom.getelementsbytagname(v_elem, 'batch');
    for parent_node_index in 0 .. dbms_xmldom.getlength(v_parent_node_lst) - 1 loop
      v_parent_node := dbms_xmldom.item(v_parent_node_lst, parent_node_index);
      v_elem1    := dbms_xmldom.makeelement(v_parent_node);        
      batch_rec.batch_number:=dbms_xmldom.getAttribute(v_elem1,'batchno');
      batch_rec.hosp_seq_id:= dbms_xmldom.getAttribute(v_elem1,'hospseqid');
      batch_rec.added_by:=dbms_xmldom.getAttribute(v_elem1,'uploadedby');
      batch_rec.num_of_rows:=dbms_xmldom.getAttribute(v_elem1,'noofrows');
      batch_rec.batch_date:=sysdate;
      INSERT INTO tpa_professional_batch_dtls(PROF_BATCH_SEQ_ID,HOSP_SEQ_ID,BATCH_NUMBER,BATCH_DATE
                  ,num_of_rows,added_by,added_date)
            VALUES(tpa_prof_batch_dtls_seq.NEXTVAL,batch_rec.hosp_seq_id,batch_rec.batch_number,
                   batch_rec.batch_date,batch_rec.num_of_rows,batch_rec.added_by,batch_rec.batch_date) RETURNING PROF_BATCH_SEQ_ID  INTO V_PROF_BATCH_SEQ_ID ;
     COMMIT;
    end loop;
    v_chld_node_list := dbms_xmldom.getelementsbytagname(v_elem, 'professional');
    for child_node_index in 0 .. dbms_xmldom.getlength(v_chld_node_list) - 1 loop
      v_chaild_node := dbms_xmldom.item(v_chld_node_list, child_node_index);
      v_elem2    := dbms_xmldom.makeelement(v_chaild_node);        
      begin
      contact_rec:=null;
      contact_rec.CONTACT_SEQ_ID:=0;
      --contact_rec.hosp_seq_id:= dbms_xmldom.getAttribute(v_elem2,'hospseqid');
      contact_rec.hosp_prof_id:= dbms_xmldom.getAttribute(v_elem2,'profid');
      contact_rec.contact_name:= dbms_xmldom.getAttribute(v_elem2,'profname');
      contact_rec.gender_general_type:=get_gen_codes('GEN','GEN', dbms_xmldom.getAttribute(v_elem2,'gender'));     
      contact_rec.Age:= dbms_xmldom.getAttribute(v_elem2,'age');
      contact_rec.prof_authority:= get_gen_codes('GEN','AUTH',dbms_xmldom.getAttribute(v_elem2,'authority'));
      contact_rec.Primary_Email_Id:= dbms_xmldom.getAttribute(v_elem2,'primarmailid');
      contact_rec.Off_Phone_No_1:= dbms_xmldom.getAttribute(v_elem2,'officephone1');
      contact_rec.Off_Phone_No_2:= dbms_xmldom.getAttribute(v_elem2,'officephone2');
      contact_rec.fax_no:= dbms_xmldom.getAttribute(v_elem2,'fax');
      contact_rec.Mobile_No:= dbms_xmldom.getAttribute(v_elem2,'mobileno');
      contact_rec.Start_Date:= to_date(dbms_xmldom.getAttribute(v_elem2,'startdate'),'dd/mm/yyyy');
      contact_rec.End_Date:= to_date(dbms_xmldom.getAttribute(v_elem2,'enddate'),'dd/mm/yyyy');
      contact_rec.Nationality_Id:=get_gen_codes('NAT',NULL, dbms_xmldom.getAttribute(v_elem2,'nationality'));
      contact_rec.consult_gen_type:=get_gen_codes('GEN','CON',dbms_xmldom.getAttribute(v_elem2,'consultationtype'));
      contact_rec.speciality_id:= dbms_xmldom.getAttribute(v_elem2,'speciality');
     
     OPEN dhpo_prof(contact_rec.hosp_prof_id);
     FETCH dhpo_prof INTO prof_rec;
     CLOSE dhpo_prof; 
     
     IF contact_rec.hosp_prof_id  IS NOT NULL   THEN
     IF (NVL(contact_rec.hosp_prof_id,0)!= NVL(prof_rec.clinitian_id,0)) OR (upper(contact_rec.contact_name)!=upper(NVL(prof_rec.professional_name,''))) THEN
      raise_application_error(-20872,'Professional id or Name is not matching with DHPO.');
     END IF;
    END IF;
     
   save_contacts(
                contact_rec.CONTACT_SEQ_ID,
                contact_rec.USER_GENERAL_TYPE_ID,
                batch_rec.hosp_seq_id,
                contact_rec.INS_SEQ_ID,
                contact_rec.TPA_OFFICE_SEQ_ID,
                contact_rec.GROUP_REG_SEQ_ID,
                contact_rec.PREFIX_GENERAL_TYPE_ID,
                contact_rec.CONTACT_NAME,
                contact_rec.DESIGNATION_TYPE_ID,
                contact_rec.PRIMARY_EMAIL_ID,
                contact_rec.SECONDARY_EMAIL_ID,
                contact_rec.ACTIVE_YN,
                contact_rec.PROVIDE_ACCESS_USER_YN,
                contact_rec.CONTACT_TYPE_ID,
                contact_rec.SPEC_TYPE_ID,
                contact_rec.DR_REGIST_NMBR,
                contact_rec.DR_QUALIF,
                contact_rec.RESIDENT_DR_YN,
                contact_rec.EMPLOYEE_NUMBER,
                contact_rec.DEPT_GENERAL_TYPE_ID,
                contact_rec.RES_PHONE_NO,
                contact_rec.OFF_PHONE_NO_1,
                contact_rec.OFF_PHONE_NO_2,
                contact_rec.MOBILE_NO,
                contact_rec.FAX_NO,
                contact_rec.CONTACT_PA_LIMIT,
                contact_rec.CONTACT_CLAIM_LIMIT,
                1,
                v_user_id,
                NULL,
                contact_rec.BANK_SEQ_ID,
                contact_rec.SOFTCOPY_ACCESS_YN,
                contact_rec.SOFTCOPY_OTHER_BRANCH_YN,
                contact_rec.DATE_OF_JOINING,
                contact_rec.DATE_OF_RESIGNATION,
                V_ROW_PROCESSED,
                'N',
                contact_rec.hosp_prof_id,
                contact_rec.PROF_AUTHORITY,
                contact_rec.START_DATE,
                contact_rec.END_DATE,
                contact_rec.STD_CODE,
                contact_rec.ISD_CODE,
                contact_rec.PROF_FILE,
                contact_rec.PROF_FILE_NAME,
                contact_rec.CONSULT_GEN_TYPE,
                contact_rec.NATIONALITY_ID,
                contact_rec.GENDER_GENERAL_TYPE,
                contact_rec.AGE,
                contact_rec.PROV_CONT_YN,
                V_PROF_BATCH_SEQ_ID,
                contact_rec.speciality_id,
                null,--v_ptnr_seq_id  newly added for partner
                null,--designation_name   newly added  for partner
                null --ptnr_user_type  newly added  for partner
                );
      exception 
        when others then
         
        --dbms_output.put_line(sqlerrm||' '|| sqlerrm||contact_rec.hosp_prof_id);
      save_provider_logs(V_PROVIDER_LOG_SEQ_ID,contact_rec.TPA_OFFICE_SEQ_ID,batch_rec.hosp_seq_id,contact_rec.hosp_prof_id,contact_rec.CONTACT_NAME,contact_rec.prof_authority,sqlcode,sqlerrm,'D',batch_rec.added_by,v_prof_batch_seq_id);
      end;
    end loop;
  end loop;
  
  for i in prof_logs(V_PROF_BATCH_SEQ_ID)
    loop
      v_log_file:=v_log_file||' '||i.professional_id||' '||i.error_message||chr(13);
     dbms_output.put_line( v_log_file);
    end loop;
    
  
END hosp_docotors_upload;
--==================================================================================
PROCEDURE save_provider_logs(
    V_PROVIDER_LOG_SEQ_ID                IN  TPA_PROVIDER_LOGS.PROVIDER_LOG_SEQ_ID%TYPE,
    V_TPA_OFICE_SEQ_ID                   IN  TPA_PROVIDER_LOGS.TPA_OFFICE_SEQ_ID%TYPE,
    V_HOSP_SEQ_ID                        IN  TPA_PROVIDER_LOGS.HOSP_SEQ_ID%TYPE,
    V_PROFESSIONAL_ID                    IN  TPA_PROVIDER_LOGS.PROFESSIONAL_ID%TYPE,
    V_PROF_NAME                          IN  TPA_PROVIDER_LOGS.PROF_NAME%TYPE,
    V_AUTHORITY                          IN  TPA_PROVIDER_LOGS.AUTHORITY%TYPE,
    V_ERROR_NO                           IN  TPA_PROVIDER_LOGS.ERROR_NO%TYPE,
    V_ERROR_MESSAGE                      IN  TPA_PROVIDER_LOGS.ERROR_MESSAGE%TYPE,
    V_ERROR_TYPE                         IN  TPA_PROVIDER_LOGS.ERROR_TYPE%TYPE,
    V_ADDED_BY                           IN  TPA_PROVIDER_LOGS.ADDED_BY%TYPE,
    V_PROF_BATCH_SEQ_ID                  IN  NUMBER
   )
  IS
    PRAGMA AUTONOMOUS_TRANSACTION ;
  BEGIN
      INSERT INTO TPA_PROVIDER_LOGS(
        PROVIDER_LOG_SEQ_ID,
        ERROR_LOGGED_DATE,
        TPA_OFFICE_SEQ_ID,
        HOSP_SEQ_ID,
        PROFESSIONAL_ID,
        PROF_NAME,
        AUTHORITY,
        ERROR_NO,
        ERROR_MESSAGE,
        ERROR_TYPE,
        ADDED_BY,
        ADDED_DATE,
        PROF_BATCH_SEQ_ID)
    VALUES (
        TPA_PROVIDER_LOGS_SEQ.NEXTVAL,
        SYSDATE,
        V_TPA_OFICE_SEQ_ID,
        V_HOSP_SEQ_ID,
        V_PROFESSIONAL_ID,
        V_PROF_NAME,
        V_AUTHORITY,
        v_error_no * -1,
        v_error_message,
        'D',----DOCTOR
        V_ADDED_BY,
        SYSDATE ,
        V_PROF_BATCH_SEQ_ID);

    COMMIT;
    
    /*IF v_error_no != 0 THEN
      raise_application_error(v_error_no, v_error_message) ;
    END IF;*/
  END save_provider_logs;
-----------========================================================
procedure get_provider_logs(v_file_id       IN  VARCHAR2,
                            V_LOGS          OUT SYS_REFCURSOR,
                            V_HOSP_NAME    OUT tpa_hosp_info.hosp_name%type)
is
begin
  SELECT distinct ii.hosp_name INTO v_hosp_name FROM APP.TPA_PROVIDER_LOGS P JOIN APP.TPA_HOSP_INFO II ON 
 (P.HOSP_SEQ_ID=P.HOSP_SEQ_ID)
WHERE P.PROF_BATCH_SEQ_ID=v_file_id ;
  OPEN v_logs FOR 
  SELECT P.PROFESSIONAL_ID,P.AUTHORITY FROM APP.TPA_PROVIDER_LOGS P 
 WHERE P.PROF_BATCH_SEQ_ID=v_file_id;
end;

--==============================================================

--This is for search hospital list in corporate level
PROCEDURE select_corp_hosp_list(
    v_empanel_number                     IN  tpa_hosp_info.empanel_number%TYPE,
    v_hosp_name                          IN  tpa_hosp_info.hosp_name%TYPE,
    v_state_type_id                      IN  tpa_hosp_address.state_type_id%TYPE,
    v_city_type_id                       IN  tpa_hosp_address.city_type_id%TYPE,
    v_flag                               IN  VARCHAR2,--EML(EMPANELED) OR ASL(ASSOCIATE LIST)
    v_grou_reg_seq_id                    IN  tpa_group_registration.group_reg_seq_id%type,
    v_sort_var                           IN  VARCHAR2,
    v_sort_order                         IN  VARCHAR2,
    v_start_num                          IN  NUMBER ,
    v_end_num                            IN  NUMBER ,
    result_set                           OUT SYS_REFCURSOR
  )
  IS
    TYPE bind_tab_type IS TABLE OF VARCHAR2(250) INDEX BY BINARY_INTEGER ;
    v_where                              VARCHAR2(2000);
    bind_tab                             bind_tab_type;
    i                                    NUMBER(2) := 0;
    v_sql_str                            VARCHAR2(4000);
  
    
  BEGIN
       
   IF  v_flag='TTK' THEN
    v_sql_str :=
    'SELECT A.HOSP_SEQ_ID,
            A.HOSP_NAME,
            A.EMPANEL_NUMBER,
            B.OFFICE_NAME,
            B.TPA_OFFICE_SEQ_ID,
            D.CITY_DESCRIPTION,
            SC.STATE_NAME
            FROM TPA_HOSP_INFO A
            JOIN TPA_OFFICE_INFO B ON (A.TPA_OFFICE_SEQ_ID = B.TPA_OFFICE_SEQ_ID) 
            JOIN TPA_HOSP_ADDRESS C ON (A.HOSP_SEQ_ID = C.HOSP_SEQ_ID)
            JOIN TPA_CITY_CODE D ON (C.CITY_TYPE_ID = D.CITY_TYPE_ID)
            JOIN TPA_STATE_CODE SC ON (C.STATE_TYPE_ID=SC.STATE_TYPE_ID) 
            JOIN TPA_HOSP_EMPANEL_STATUS E ON (A.HOSP_SEQ_ID = E.HOSP_SEQ_ID AND E.EMPANEL_STATUS_TYPE_ID=''EMP'')
            LEFT OUTER JOIN APP.TPA_CORP_ASSOC_HOSP F ON (F.HOSP_SEQ_ID=A.HOSP_SEQ_ID)';
     
   ELSE
    v_sql_str :=
    'SELECT F.CORP_HOSP_SEQ_ID,
            A.HOSP_SEQ_ID,
            A.HOSP_NAME,
            A.EMPANEL_NUMBER,
            B.OFFICE_NAME,
            B.TPA_OFFICE_SEQ_ID,
            D.CITY_DESCRIPTION,
            SC.STATE_NAME
            FROM TPA_HOSP_INFO A JOIN  TPA_OFFICE_INFO B ON (A.TPA_OFFICE_SEQ_ID=B.TPA_OFFICE_SEQ_ID)
            JOIN TPA_HOSP_ADDRESS C ON (C.HOSP_SEQ_ID=A.HOSP_SEQ_ID) 
            JOIN TPA_CITY_CODE D ON (C.CITY_TYPE_ID=D.CITY_TYPE_ID)
            JOIN TPA_STATE_CODE SC ON (C.STATE_TYPE_ID=SC.STATE_TYPE_ID)
            JOIN TPA_HOSP_EMPANEL_STATUS E ON (A.HOSP_SEQ_ID = E.HOSP_SEQ_ID AND E.EMPANEL_STATUS_TYPE_ID=''EMP'')
            JOIN  APP.TPA_CORP_ASSOC_HOSP F ON (F.HOSP_SEQ_ID=A.HOSP_SEQ_ID AND F.STATUS_GENERAL_TYPE_ID = ''ASL'')';
     END IF;
     IF v_hosp_name IS NOT NULL THEN
       v_where := v_where  ||' AND A.hosp_name LIKE :v_hosp_name ';
       i := i+1;
       bind_tab(i) := '%'||UPPER(v_hosp_name)||'%';
     END IF;
     IF v_empanel_number IS NOT NULL THEN
       v_where := v_where ||' AND A.empanel_number LIKE :v_empanel_number ';
       i := i+1;
       bind_tab(i) := UPPER(v_empanel_number)||'%';
     END IF;
     IF v_state_type_id IS NOT NULL THEN
       v_where := v_where  ||' AND C.state_type_id = :v_state_type_id ';
       i := i+1;
       bind_tab(i) := v_state_type_id;
     END IF;
     IF v_city_type_id IS NOT NULL THEN
       v_where := v_where  ||' AND C.city_type_id = :v_city_type_id ';
       i := i+1;
       bind_tab(i) := v_city_type_id;
     END IF;
     IF  v_flag!='EML' THEN
      IF v_grou_reg_seq_id IS NOT NULL THEN
       v_where := v_where  ||' AND F.group_reg_seq_id = :v_grou_reg_seq_id ';
       i := i+1;
       bind_tab(i) := v_grou_reg_seq_id;
      END IF;
     END IF;
    v_where := v_where  ||' AND E.ACTIVE_YN = ''Y''';
     v_where := ' WHERE '|| SUBSTR(v_where,5);
     v_sql_str := v_sql_str ||v_where;


      v_sql_str := 'SELECT * FROM
            (SELECT A.*,DENSE_RANK() OVER (ORDER BY '||v_sort_var||' '||v_sort_order||',ROWNUM)
            Q FROM (' ||v_sql_str|| ') A ) WHERE  Q>= :v_start_num AND Q<= :v_end_num ';
      --dbms_output.put_line(v_sql_str);
      IF bind_tab.FIRST IS NOT NULL THEN
         CASE bind_tab.COUNT
           WHEN 1 THEN OPEN result_set FOR v_sql_str USING bind_tab(1) , v_start_num , v_end_num ;
           WHEN 2 THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2), v_start_num , v_end_num ;
           WHEN 3 THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) , v_start_num , v_end_num ;
           WHEN 4 THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,v_start_num ,v_end_num ;
           WHEN 5 THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5) ,v_start_num , v_end_num ;
         END CASE;
      ELSE
        OPEN result_set FOR v_sql_str USING v_start_num , v_end_num ;
      END IF;

  END select_corp_hosp_list;
--------------------------------------------------------------------------------
--inshosp
-- PROCEDURE TO SAVE THE RECORDS IN TPA_INS_ASSOC_HOSP

PROCEDURE corp_hosp_associate_save (
   v_hosp_seq_id                    IN  VARCHAR2 , -- Concatenated HOSPITAL Sequence IDs.
   v_group_reg_seq_id               IN  TPA_GROUP_REGISTRATION.GROUP_REG_SEQ_ID%TYPE,
   v_status_general_type_id         IN  TPA_CORP_ASSOC_HOSP.STATUS_GENERAL_TYPE_ID%TYPE,
   v_user_id                        IN  NUMBER,
   v_rows_processed                 OUT NUMBER
   )
IS
            str_tab   Ttk_Util_Pkg.str_table_type;
            V_HOSP_COUNT          NUMBER;
BEGIN
      -- Calling Function from Ttk_Util_Pkg Package
         str_tab := Ttk_Util_Pkg.parse_str ( V_HOSP_SEQ_ID );

         FOR V_HOSP_SEQ_ID IN str_tab.First..str_tab.Last
         LOOP

       -- Check whether the Hospital is already Associated or Excluded
       SELECT COUNT(1) INTO V_HOSP_COUNT FROM APP.TPA_CORP_ASSOC_HOSP AH
       WHERE AH.HOSP_SEQ_ID = str_tab(V_HOSP_SEQ_ID)
       AND AH.GROUP_REG_SEQ_ID = V_GROUP_REG_SEQ_ID;

       -- Raise an Exception if a Hospital is already Associated or Excluded
       IF V_HOSP_COUNT <> 0 THEN
         RAISE_APPLICATION_ERROR(-20017, 'It is already Associated or Excluded');
       ELSE

              INSERT INTO TPA_CORP_ASSOC_HOSP(                -- New Record
                                 CORP_HOSP_SEQ_ID,
                                 HOSP_SEQ_ID,
                                 GROUP_REG_SEQ_ID,
                                 STATUS_GENERAL_TYPE_ID,
                                 ADDED_BY,
                                 ADDED_DATE
                                 ) VALUES (
                                 TPA_CORP_ASSOC_HOSP_SEQ.NEXTVAL,    -- Sequence Number
                                 str_tab(V_HOSP_SEQ_ID),
                                 V_GROUP_REG_SEQ_ID,
                                 V_STATUS_GENERAL_TYPE_ID,
                                 V_User_ID,
                                 SYSDATE);
       END IF;
     END LOOP;

         v_rows_processed := SQL%ROWCOUNT;

         COMMIT;
END corp_hosp_associate_save;
-------------------------------------
PROCEDURE corp_hosp_associate_delete (
   v_hosp_seq_id                      IN  VARCHAR2 , -- Concatenated Sequence IDs.
   v_user_id                          IN  NUMBER,
   v_rows_processed                   OUT  NUMBER
   )
IS
         str_tab   Ttk_Util_Pkg.str_table_type;
         V_REC_COUNT NUMBER;
BEGIN
  -- Calling Function from Ttk_Util_Pkg Package
    str_tab := Ttk_Util_Pkg.parse_str ( v_hosp_seq_id );

    FOR i IN str_tab.First..str_tab.LAST
    LOOP
          
         DELETE FROM TPA_CORP_ASSOC_HOSP 
            WHERE hosp_seq_id = TO_NUMBER(str_tab(i));
      
    END LOOP;
    v_rows_processed := str_tab.LAST;
    COMMIT;
END corp_hosp_associate_delete;
--===============================================================================
 --=================================================================    
 PROCEDURE select_hr_upload_list (
    V_GROUP_ID		                       IN APP.HR_UPLOAD_DETAILS.GROUP_ID%TYPE,
    V_UPLOAD_DATE	                       IN VARCHAR2,
    v_enr_user_id                        IN TPA_LOGIN_INFO.USER_ID%TYPE,---BHARATH    ( ENR PERSON USER ID)
    v_completed                          IN VARCHAR2,                   ---BHARARH    ( FOR COMPLETE BUTTON)
    v_status                             IN VARCHAR2,                   ---BHARATH    ( FOR SEARCH CRITERIA)
    v_grid_list                          IN VARCHAR2,                   ----BHARATH   ( TO GET SELECTED GRIDS IN LIST FORMAT SEPERATED BY '|')
    v_sort_var                           IN  VARCHAR2,
    v_sort_order                         IN  VARCHAR2 ,
    v_start_num                          IN  NUMBER ,
    v_end_num                            IN  NUMBER ,
    result_set                           OUT SYS_REFCURSOR
  )
  IS

    v_sql_str                            VARCHAR2(10000) ;
    /*v_pat_received_date                  APP.HR_UPLOAD_DETAILS.UPLOAD_DATE%TYPE := TO_DATE(V_UPLOAD_DATE, 'DD/MM/YYYY');*/
    v_pat_received_date                  VARCHAR2(50) :=V_UPLOAD_DATE;
    TYPE bind_tab_type IS TABLE OF VARCHAR2(250) INDEX BY BINARY_INTEGER ;
    bind_tab                             bind_tab_type;
    i                                    NUMBER(2) := 0;
    v_where                              VARCHAR2(4000);
    v_policy_num                         TPA_ENR_POLICY.POLICY_NUMBER%TYPE;
    str_tab                              ttk_util_pkg.str_table_type;     -----BHARATH
    v_dest_msg_seq_id                    DESTINATION_MESSAGE.DEST_MSG_SEQ_ID%TYPE;---BHARATH
    v_file_status                        VARCHAR2(10);
    v_sort_null                          VARCHAR2(50);
    v_sort_var1                          VARCHAR2(100):=v_sort_var;
    
    CURSOR GET_ENR_PWD_CUR IS                                              ------BHARATH
           SELECT A.CONTACT_SEQ_ID,A.USER_ID
          FROM TPA_LOGIN_INFO A
              INNER JOIN TPA_USER_CONTACTS B ON(A.CONTACT_SEQ_ID=B.CONTACT_SEQ_ID)
          WHERE A.USER_ID = v_enr_user_id
              AND A.ACTIVE_YN= 'Y' ;
   v_enr_pwd_rec  GET_ENR_PWD_CUR%ROWTYPE;
  
  BEGIN
    /*v_sql_str :=
    'select HU.FILE_NAME,TO_CHAR(HU.UPLOAD_DATE,''DD/MM/RRRR'') AS UPLOAD_DATE,HU.FILE_PATH from app.HR_UPLOAD_DETAILS HU
    WHERE HU.GROUP_ID ='''|| V_GROUP_ID||'''';*/
    
    IF v_completed='N' THEN       ---BHARATH
      v_sql_str :=
         'select HU.FILE_SEQ_ID,HU.FILE_NAME,
                TO_CHAR(HU.UPLOAD_DATE,''DD/MM/RRRR hh:mi:ss Am'') AS UPLOAD_DATE, 
                TEC.POLICY_NUMBER, HU.HR_USER_ID AS UPLOADED_BY ,
                HU.FILE_PATH,
                CASE WHEN HU.FILE_MODE=''DEL'' THEN ''Deletion'' when HU.FILE_MODE=''ADD'' then ''Addition'' when HU.FILE_MODE=''REN'' then ''Renewal'' when HU.FILE_MODE=''MOD'' then ''modification'' end as FILE_UPLOADED_FOR,
                TO_CHAR(HU.STATUS_CHANGED_DATE,''DD/MM/RRRR hh:mi:ss Am'') AS STATUS_CHANGED_DATE,
                UPPER(HU.STATUS) AS STATUS,
                HU.STAT_CHANGED_BY AS STATUS_CHANGED_BY
          from app.HR_UPLOAD_DETAILS HU LEFT OUTER JOIN TPA_ENR_POLICY TEC ON (HU.POLICY_SEQ_ID=TEC.POLICY_SEQ_ID)
          WHERE HU.GROUP_ID ='''|| V_GROUP_ID||''''; 
      ELSE
        OPEN GET_ENR_PWD_CUR;
        FETCH GET_ENR_PWD_CUR INTO v_enr_pwd_rec;
        CLOSE GET_ENR_PWD_CUR;
        
        str_tab := ttk_util_pkg.parse_str ( v_grid_list );
        FOR  i in 1..str_tab.COUNT LOOP
          SELECT A.STATUS INTO v_file_status FROM APP.HR_UPLOAD_DETAILS A WHERE A.FILE_SEQ_ID=str_tab(i);
          
          IF v_file_status is not null and v_file_status ='PENDING' THEN   
         UPDATE app.HR_UPLOAD_DETAILS HU SET HU.STATUS_CHANGED_DATE=SYSDATE,HU.STATUS=UPPER('completed'),HU.STAT_CHANGED_BY=v_enr_pwd_rec.user_id WHERE HU.FILE_SEQ_ID=str_tab(i);---bharath
         GENERATE_MAIL_PKG.proc_generate_message('HR_CONFIRMATION_PROCESSED_FILE',v_enr_pwd_rec.CONTACT_SEQ_ID,1,v_dest_msg_seq_id,str_tab(i));
         COMMIT;
         END IF;
         END LOOP;
         
         v_sql_str :=
         'select HU.FILE_SEQ_ID,HU.FILE_NAME,
                TO_CHAR(HU.UPLOAD_DATE,''DD/MM/RRRR hh:mi:ss Am'') AS UPLOAD_DATE, 
                TEC.POLICY_NUMBER, HU.HR_USER_ID AS UPLOADED_BY ,
                HU.FILE_PATH,
                CASE WHEN HU.FILE_MODE=''DEL'' THEN ''Deletion'' when HU.FILE_MODE=''ADD'' then ''Addition'' when HU.FILE_MODE=''REN'' then ''Renewal'' when HU.FILE_MODE=''MOD'' then ''modification'' end as FILE_UPLOADED_FOR,
                TO_CHAR(HU.STATUS_CHANGED_DATE,''DD/MM/RRRR hh:mi:ss Am'') AS STATUS_CHANGED_DATE,
                UPPER(HU.STATUS) AS STATUS,
                HU.STAT_CHANGED_BY AS STATUS_CHANGED_BY 
          from app.HR_UPLOAD_DETAILS HU LEFT OUTER JOIN TPA_ENR_POLICY TEC ON (HU.POLICY_SEQ_ID=TEC.POLICY_SEQ_ID)
          WHERE HU.GROUP_ID ='''|| V_GROUP_ID||''''; ---BHARATH
        END IF;
  

   /* IF V_UPLOAD_DATE IS NOT NULL THEN
      v_where := v_where  ||' AND UPLOAD_DATE = :V_UPLOAD_DATE';
      i := i+1;
      bind_tab(i) := v_pat_received_date;
    END IF;*/
    IF v_status is NOT NULL THEN
      IF v_status != 'ALL'   THEN    ----BHARATH
        v_where:= v_where  ||' AND STATUS= :V_STAT';
        i :=i+1;
        bind_tab(i) :=v_status;
        END IF;
        END IF;
 /* IF v_sort_var = 'POLICY_NUMBER' THEN
    v_where:= v_where || ' AND HU.POLICY_SEQ_ID IS NOT NULL ';
   END IF;*/
      
IF v_where IS NOT NULL THEN
      v_where   := ' AND '|| SUBSTR(v_where,5);
      v_sql_str := v_sql_str ||v_where;
END IF; 

    IF v_sort_var1 IN ('UPLOAD_DATE','STATUS_CHANGED_DATE') THEN
      IF v_status ='PENDING' AND (v_sort_var1 in('STATUS_CHANGED_DATE')) THEN

    /*v_sql_str := 'SELECT * FROM
        (SELECT A.*,DENSE_RANK() OVER (ORDER BY '||v_sort_var||' '||v_sort_order||',ROWNUM)
        Q FROM (' ||v_sql_str|| ') A ) WHERE  Q>= :v_start_num AND Q<= :v_end_num ';*/
     v_sql_str:='(SELECT A.*,DENSE_RANK() OVER (ORDER BY FILE_SEQ_ID '||v_sort_order||',ROWNUM)
                Q FROM (' ||v_sql_str|| ') A) ';
       ELSE
     v_sql_str := '(SELECT A.*,DENSE_RANK() OVER (ORDER BY TO_DATE('||v_sort_var1||',''DD/MM/YYYY HH:MI:SS AM'') '||v_sort_order||',ROWNUM)
                Q FROM (' ||v_sql_str|| ') A)  ';
       END IF;
      ELSE
        
      IF v_status ='PENDING' AND (v_sort_var1 in('STATUS_CHANGED_BY')) THEN
          v_sort_var1:='FILE_SEQ_ID';
      END IF;
      v_sql_str := '(SELECT A.*,DENSE_RANK() OVER (ORDER BY '||v_sort_var1||' '||v_sort_order||',ROWNUM)
               Q FROM (' ||v_sql_str|| ') A)';               
      END  IF ;
      
      IF V_UPLOAD_DATE IS NOT NULL THEN 
       v_sql_str := ' SELECT FILE_SEQ_ID, FILE_NAME, UPLOAD_DATE, POLICY_NUMBER, FILE_UPLOADED_FOR,UPLOADED_BY, FILE_PATH,STATUS_CHANGED_DATE, STATUS, STATUS_CHANGED_BY FROM 
                  (SELECT * from 
                        (select FILE_SEQ_ID, FILE_NAME, TO_CHAR( TO_DATE(UPLOAD_DATE,''DD/MM/YYYY HH:MI:SS AM''),''DD/MM/YYYY'') AS UPLOAD_DATE, POLICY_NUMBER,FILE_UPLOADED_FOR, UPLOADED_BY, FILE_PATH,TO_CHAR( TO_DATE(STATUS_CHANGED_DATE,''DD/MM/YYYY HH:MI:SS AM''),''DD/MM/YYYY'') STATUS_CHANGED_DATE, STATUS, STATUS_CHANGED_BY,Q
                                FROM ('||v_sql_str||')B)C
                                    where TO_CHAR(TO_DATE(C.UPLOAD_DATE,''DD/MM/YYYY''))=TO_CHAR(TO_DATE('''||V_UPLOAD_DATE||''',''DD/MM/YYYY'')))D 
                                
                                            WHERE D.Q>= :v_start_num AND D.Q<= :v_end_num' ;
      ELSE 
       v_sql_str :='SELECT  FILE_SEQ_ID, FILE_NAME, TO_CHAR( TO_DATE(UPLOAD_DATE,''DD/MM/YYYY HH:MI:SS AM''),''DD/MM/YYYY'') AS UPLOAD_DATE, POLICY_NUMBER,FILE_UPLOADED_FOR, UPLOADED_BY, FILE_PATH,TO_CHAR( TO_DATE(STATUS_CHANGED_DATE,''DD/MM/YYYY HH:MI:SS AM''),''DD/MM/YYYY'') STATUS_CHANGED_DATE, STATUS, STATUS_CHANGED_BY FROM
                  ('||v_sql_str||')E WHERE E.Q>= :v_start_num AND E.Q<= :v_end_num ';
      END IF;

    IF bind_tab.FIRST IS NOT NULL THEN
       CASE bind_tab.COUNT
         WHEN 1  THEN OPEN result_set FOR v_sql_str USING bind_tab(1), v_start_num , v_end_num ;

       END CASE;
     ELSE
       OPEN result_set FOR v_sql_str USING v_start_num , v_end_num ;
     END IF;


  END select_hr_upload_list;
 --====================================================================
 -- cr0295 
 -- get employee detail to unlock
 ------------------------------------------------
 PROCEDURE select_emp_details(p_policy_group_seq_id      IN    tpa_enr_policy_group.policy_group_seq_id%type,
                              p_resultset                OUT   sys_refcursor
                             )is
  
   BEGIN
     
     OPEN p_resultset FOR
       select gr.group_name,gr.group_id,
              ep.policy_number,pg.tpa_enrollment_number,
              pg.insured_name,nvl(pg.accn_locked_yn,'N') accn_locked_yn,
              ttk_util_pkg.fn_decrypt(ma.email_id) email_id
              
         from tpa_enr_policy_group pg
         join tpa_enr_mem_address ma on(pg.enr_address_seq_id=ma.enr_address_seq_id)
         join tpa_enr_policy ep on (pg.policy_seq_id = ep.policy_seq_id)
         join tpa_group_registration gr on (ep.group_reg_seq_id = gr.group_reg_seq_id)
        where pg.policy_group_seq_id = p_policy_group_seq_id  ;
  
 END select_emp_details;
  --============================================================================================
  -- cr0295
  -- to reset employee password
  -------------------------------------------------
 PROCEDURE reset_emp_pwd(p_policy_group_seq_id         IN    tpa_enr_policy_group.policy_group_seq_id%type,
                         p_added_by                    IN    tpa_enr_policy_group.added_by%type,
                         p_accn_locked_yn              IN    tpa_enr_policy_group.accn_locked_yn%type,
                         p_flag                        IN    varchar2,--S/R                         
                         p_rows_processed              OUT   number
                        )is
                        
    v_len        NUMBER(2);
    v_pwd        varchar2(100);
    v_dest_msg_seq_id        VARCHAR2(250) ;
             
  BEGIN
     
    IF p_flag = 'S' THEN
      UPDATE tpa_enr_policy_group b 
         SET b.accn_locked_yn = p_accn_locked_yn,
             b.wrong_attempts = decode(p_accn_locked_yn,'N',NULL,b.wrong_attempts) 
       WHERE b.policy_group_seq_id = p_policy_group_seq_id;
              
    ELSIF p_flag = 'R' THEN
     v_len := dbms_random.value(5,10);
     v_pwd := dbms_random.string('x',v_len);
     
     UPDATE tpa_enr_policy_group g
        SET g.accn_locked_yn = 'N',
            g.wrong_attempts = NULL,
            g.password_1 = g.password_2,
            g.password_2 = g.password_3,
            g.password_3 = g.password_4,
            g.password_4 = g.password_5,
            g.password_5 = g.employee_password,
            g.employee_password = ttk_util_pkg.fn_encr_password(v_pwd ),
            g.updated_by = p_added_by,
            g.updated_date = SYSDATE,
            g.password_generated_date = NULL,
            g.FIRST_LOGIN_YN = 'Y'
            
      WHERE g.policy_group_seq_id = p_policy_group_seq_id;
         
    END IF; 
    
    p_rows_processed := SQL%ROWCOUNT;
    commit;
    
    IF p_flag = 'R' THEN
      GENERATE_MAIL_PKG.proc_form_message ( 'RESET_PASSWORD_EMP', p_policy_group_seq_id,p_added_by , v_dest_msg_seq_id ); 
    END IF;
 END reset_emp_pwd;                       
 --=============================================================================================
END CONTACT_PKG ;
----------------------------------------------------------------------------------------------------------

/

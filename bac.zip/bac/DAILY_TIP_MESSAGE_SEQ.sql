--------------------------------------------------------
--  DDL for Synonymn DAILY_TIP_MESSAGE_SEQ
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."DAILY_TIP_MESSAGE_SEQ" FOR "APP"."DAILY_TIP_MESSAGE_SEQ";

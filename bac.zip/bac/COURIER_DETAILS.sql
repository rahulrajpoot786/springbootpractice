--------------------------------------------------------
--  DDL for Synonymn COURIER_DETAILS
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."COURIER_DETAILS" FOR "APP"."COURIER_DETAILS";

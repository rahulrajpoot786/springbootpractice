--------------------------------------------------------
--  DDL for Synonymn DENIAL_UPDATE
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."DENIAL_UPDATE" FOR "INTX"."DENIAL_UPDATE";

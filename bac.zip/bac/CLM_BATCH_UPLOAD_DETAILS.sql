--------------------------------------------------------
--  DDL for Synonymn CLM_BATCH_UPLOAD_DETAILS
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."CLM_BATCH_UPLOAD_DETAILS" FOR "APP"."CLM_BATCH_UPLOAD_DETAILS";

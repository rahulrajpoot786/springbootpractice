--------------------------------------------------------
--  DDL for Package CODING_PKG
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "VENUBABU"."CODING_PKG" is

 PROCEDURE return_to_coding (
    v_seq_id                              IN NUMBER,
    v_workflow                            IN VARCHAR2, -- PAT -- preauth , CLM -- claim
    v_added_by                            IN NUMBER,
    v_event_seq_id                        OUT tpa_event.event_seq_id%TYPE,
    v_review_count                        OUT NUMBER,
    v_required_review_count               OUT NUMBER,
    v_event_name                          OUT VARCHAR2,
    v_review                              OUT VARCHAR2,
    v_coding_review_yn                    OUT VARCHAR2
  );


  PROCEDURE select_coding_preauth_list (
    v_pre_auth_number                    IN  PAT_ENROLL_DETAILS.pre_auth_number%TYPE,
    v_tpa_enrollment_id                  IN  PAT_ENROLL_DETAILS.tpa_enrollment_id%TYPE,
    v_tpa_office_seq_id                  IN  TPA_OFFICE_INFO.tpa_office_seq_id%TYPE,
    v_assigned_type_id                   IN  VARCHAR2,
    v_start_limit_type                   IN  VARCHAR2,
    v_sort_var                           IN  VARCHAR2,
    v_sort_order                         IN  VARCHAR2 ,
    v_start_num                          IN  NUMBER ,
    v_end_num                            IN  NUMBER ,
    v_added_by                           IN  NUMBER,
    result_set                           OUT SYS_REFCURSOR
  );

  PROCEDURE select_coding_preauth (
    v_pat_gen_detail_seq_id              IN  PAT_GENERAL_DETAILS.pat_gen_detail_seq_id%TYPE,
    v_added_by                           IN  NUMBER,
    result_set                           OUT SYS_REFCURSOR
  );


  PROCEDURE select_coding_claims_list (
    v_claim_number                   IN  clm_general_details.claim_number%TYPE,
    v_tpa_enrollment_id              IN  clm_enroll_details.tpa_enrollment_id%TYPE,
    v_assigned_to_user               IN  VARCHAR2,
    v_tpa_office_seq_id              IN  tpa_office_info.tpa_office_seq_id%TYPE ,
    v_start_limit_type               IN  VARCHAR2,
    v_sort_var                       IN  VARCHAR2,
    v_sort_order                     IN  VARCHAR2,
    v_start_num                      IN  NUMBER ,
    v_end_num                        IN  NUMBER ,
    v_added_by                       IN  NUMBER,
    result_set                       OUT SYS_REFCURSOR
  );

  PROCEDURE select_coding_claim (
    v_claim_seq_id                  IN clm_general_details.claim_seq_id%TYPE,
    v_added_by                      IN NUMBER,
    v_result_set                    OUT SYS_REFCURSOR
  );

  PROCEDURE select_ailment_list (
    v_pat_gen_detail_seq_id     IN pat_general_details.pat_gen_detail_seq_id%TYPE,
    v_claim_seq_id              IN clm_general_details.claim_seq_id%TYPE,
    icd_cur                     OUT SYS_REFCURSOR
  );

  PROCEDURE get_exact_icd (
    v_icd_code                  IN  tpa_ped_code.icd_code%TYPE,
    v_ped_description           OUT tpa_ped_code.ped_description%TYPE,
    v_ped_code_id               OUT tpa_ped_code.ped_code_id%TYPE
  );

  PROCEDURE get_exact_procedure (
    v_proc_code             IN  tpa_hosp_procedure_code.proc_code%TYPE,
    v_proc_description      OUT  tpa_hosp_procedure_code.proc_description%TYPE,
    v_proc_seq_id           OUT  tpa_hosp_procedure_code.proc_seq_id%TYPE
  );

  PROCEDURE Pending_Case_Report (
    where_clause        IN  VARCHAR2,
    result_set          OUT SYS_REFCURSOR
  );

  PROCEDURE save_coding_ped(
    v_ped_seq_id                         IN  OUT CLAIMANT_PED.claimant_ped_seq_id%TYPE ,
    v_seq_id                             IN  CLAIMANT_PED.pat_gen_detail_seq_id%TYPE,  -- pat_general_detail_seq_id /Claim_seq_id
    v_member_seq_id                      IN  CLAIMANT_PED.member_seq_id%TYPE,
    v_ped_code_id                        IN  OUT CLAIMANT_PED.ped_code_id%TYPE ,
    v_icd_code                           IN  OUT CLAIMANT_PED.icd_code%TYPE ,
    v_scr_mode                           IN  VARCHAR2, -- PAT -> in preauth -- CLM -> In Claims
    v_show_mode                          IN  VARCHAR2, -- TTK -> in preauth/CLAIM -- INSURANCE -- enrollment
    v_added_by                           IN  NUMBER ,
    v_rows_processed                     IN  OUT NUMBER
  );
  PROCEDURE save_coding_search (
    v_workflow IN VARCHAR2, -- PAT -- preauth , CLM -- claim
    v_seq_id   IN NUMBER,
    v_flag     IN VARCHAR2
  );
END CODING_PKG;

/

--------------------------------------------------------
--  DDL for Synonymn CLM_ADD_HOSP_DTL_SEQ_ID
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."CLM_ADD_HOSP_DTL_SEQ_ID" FOR "APP"."CLM_ADD_HOSP_DTL_SEQ_ID";

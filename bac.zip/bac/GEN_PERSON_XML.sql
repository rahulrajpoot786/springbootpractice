--------------------------------------------------------
--  DDL for Synonymn GEN_PERSON_XML
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."GEN_PERSON_XML" FOR "INTX"."GEN_PERSON_XML";

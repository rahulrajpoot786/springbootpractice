--------------------------------------------------------
--  DDL for Synonymn GEN_INSERT_SCRIPT
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."GEN_INSERT_SCRIPT" FOR "INTX"."GEN_INSERT_SCRIPT";

--------------------------------------------------------
--  DDL for Synonymn DHA_QUERIES_FORUPLOAD
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."DHA_QUERIES_FORUPLOAD" FOR "INTX"."DHA_QUERIES_FORUPLOAD";

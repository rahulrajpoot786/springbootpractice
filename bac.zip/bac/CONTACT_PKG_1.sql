--------------------------------------------------------
--  DDL for Package CONTACT_PKG
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "VENUBABU"."CONTACT_PKG" 
IS
--  Author : Ragavendra
--  Created : 19-Sep-2005.
--  Project : TTK
--  Description : Package for Inserting and Updating  Contacts information.
--  History of Changes:     Date   --     User     -- Description
--                         18-Dec-2005 -- S.V.Sreeraj  -- Rwriting Procedures
--                         20-Dec-2005 -- S.V.Sreeraj  -- Adding Procedures

  -------------------------------------------------------------------------------------
  PROCEDURE reset_password (
    v_contact_seq_id      IN tpa_login_info.contact_seq_id%TYPE,
    v_added_by            IN tpa_login_info.added_by%TYPE,
    v_rows_processed      IN  OUT NUMBER
  );
  -------------------------------------------------------------------------------------
  PROCEDURE gen_user_id(
    v_name          IN tpa_user_contacts.contact_name%TYPE,
    v_user_id       OUT tpa_login_info.user_id%TYPE,
    v_password      OUT tpa_login_info.password%TYPE
  );
  -------------------------------------------------------------------------------------
  PROCEDURE inactivate_users(
    v_contact_seq_ids  IN VARCHAR2,  -- Concatenated Strings |contact_seq_id|
    v_active_yn        IN VARCHAR2,
    v_rows_processed   OUT NUMBER
  );
  -------------------------------------------------------------------------------------
   PROCEDURE inactivate_contacts(
    v_contact_seq_ids  IN VARCHAR2,  -- Concatenated Strings |contact_seq_id|
    v_active_yn        IN VARCHAR2,
    v_rows_processed   OUT NUMBER
  );
  -------------------------------------------------------------------------------------
  PROCEDURE save_contacts(
    v_contact_seq_id                 IN OUT tpa_user_contacts.contact_seq_id%TYPE,
    v_user_general_type_id           IN tpa_user_contacts.user_general_type_id%TYPE,
    v_hosp_seq_id                    IN tpa_user_contacts.hosp_seq_id%TYPE,
    v_ins_seq_id                     IN tpa_user_contacts.ins_seq_id%TYPE,
    v_tpa_office_seq_id              IN tpa_user_contacts.tpa_office_seq_id%TYPE,
    v_group_reg_seq_id               IN tpa_user_contacts.group_reg_seq_id%TYPE,
    v_prefix_general_type_id         IN tpa_user_contacts.prefix_general_type_id%TYPE,
    v_contact_name                   IN tpa_user_contacts.contact_name%TYPE,
    v_designation_type_id            IN tpa_user_contacts.designation_type_id%TYPE,
    v_primary_email_id               IN tpa_user_contacts.primary_email_id%TYPE,
    v_secondary_email_id             IN tpa_user_contacts.secondary_email_id%TYPE,
    v_active_yn                      IN tpa_user_contacts.active_yn%TYPE,
    v_provide_access_user_yn         IN tpa_user_contacts.provide_access_user_yn%TYPE,
    v_contact_type_id                IN tpa_user_contacts.contact_type_id%TYPE,
    v_spec_type_id                   IN tpa_user_contacts.spec_type_id%TYPE,
    v_dr_regist_nmbr                 IN tpa_user_contacts.dr_regist_nmbr%TYPE,
    v_dr_qualif                      IN tpa_user_contacts.dr_qualif%TYPE,
    v_resident_dr_yn                 IN tpa_user_contacts.resident_dr_yn%TYPE,
    v_employee_number                IN tpa_user_contacts.employee_number%TYPE,
    v_dept_general_type_id           IN tpa_user_contacts.dept_general_type_id%TYPE,
    v_res_phone_no                   IN tpa_user_contacts.res_phone_no%TYPE,
    v_off_phone_no_1                 IN tpa_user_contacts.off_phone_no_1%TYPE,
    v_off_phone_no_2                 IN tpa_user_contacts.off_phone_no_2%TYPE,
    v_mobile_no                      IN tpa_user_contacts.mobile_no%TYPE,
    v_fax_no                         IN tpa_user_contacts.fax_no%TYPE,
    v_contact_pa_limit               IN  TPA_USER_CONTACTS.contact_pa_limit%TYPE,
    v_contact_claim_limit            IN  TPA_USER_CONTACTS.contact_claim_limit%TYPE,
    v_added_by                       IN tpa_user_contacts.added_by%TYPE,
    v_user_id                        IN OUT tpa_login_info.user_id%TYPE,           -- Login Name
    v_role_seq_id                    IN tpa_user_roles.role_seq_id%TYPE,               -- For TPA_USER_ROLES
    v_bank_seq_id                    IN tpa_user_contacts.bank_seq_id%TYPE,               -- For TPA_USER_ROLES
    v_softcopy_access_yn             IN tpa_user_contacts.softcopy_access_yn%TYPE,
    v_softcopy_other_branch_yn       IN tpa_user_contacts.softcopy_other_branch_yn%TYPE,
    v_date_of_joining                IN tpa_user_contacts.date_of_joining%TYPE,    --ADDED FOR KOC1085 CR
    v_date_of_resignation            IN tpa_user_contacts.date_of_resignation%TYPE,    --ADDED FOR KOC1085 CR
    v_row_processed                  OUT number,
    v_ACCN_LOCKED_YN                 IN tpa_login_info.ACCN_LOCKED_YN%TYPE,    --Added for CR-KOC1235
    v_prof_id                        in tpa_user_contacts.hosp_prof_id%type,
    v_prof_authority                 in tpa_user_contacts.prof_authority%type,
    v_start_date                     in tpa_user_contacts.start_date%type,
    v_end_date                       in tpa_user_contacts.end_date%type,
    v_std_code                       IN tpa_user_contacts.std_code%type,
    v_isd_code                       IN tpa_user_contacts.isd_code%type,
    v_prof_file                      IN tpa_user_contacts.prof_file%type,
    v_prof_file_name                 IN tpa_user_contacts.prof_file_name%type,
    v_consult_gen_type               IN tpa_user_contacts.consult_gen_type%type,
    v_nationality_id                 IN tpa_user_contacts.nationality_id%type,
    v_gender_general_type            IN tpa_user_contacts.gender_general_type%type,
    v_age                            In tpa_user_contacts.age%type,
    v_prov_cont_yn                   IN tpa_user_contacts.prov_cont_yn%type,
    V_PROF_BATCH_SEQ_ID              IN tpa_professional_batch_dtls.prof_batch_seq_id%type,
    v_speciality_id                  IN tpa_user_contacts.speciality_id%type,
    v_ptnr_seq_id                    IN tpa_user_contacts.ptnr_seq_id%TYPE,--new_added  for partner
    v_designation_name               IN tpa_user_contacts.designation%type, ---new_added  for partner
   v_ptnr_user_type                 IN tpa_user_contacts.ptnr_user_type%type,---new_added  for partner
    ---------------------------------------------------------------------------
    v_vip_pat_email                      IN  TPA_USER_CONTACTS.vip_pat_email%TYPE DEFAULT 'N',
    v_vip_pat_sms                        IN  TPA_USER_CONTACTS.vip_pat_sms%TYPE DEFAULT 'N',
    v_vip_pat_primary                    IN  TPA_USER_CONTACTS.vip_pat_primary%TYPE DEFAULT 'N',
    v_vip_pat_alternate                  IN  TPA_USER_CONTACTS.vip_pat_alternate%TYPE DEFAULT 'N',
    v_vip_pat_cnh_req                    IN  TPA_USER_CONTACTS.vip_pat_cnh_req%TYPE DEFAULT 'N',
    v_vip_pat_freq                       IN  TPA_USER_CONTACTS.vip_pat_freq%TYPE DEFAULT NULL,
    -----------------------------------------------------------------------------
    v_vip_clm_email                      IN  TPA_USER_CONTACTS.vip_clm_email%TYPE DEFAULT 'N',    
    v_vip_clm_sms                        IN  TPA_USER_CONTACTS.vip_clm_sms%TYPE DEFAULT 'N',
    v_vip_clm_primary                    IN  TPA_USER_CONTACTS.vip_clm_primary%TYPE DEFAULT 'N',
    v_vip_clm_alternate                  IN  TPA_USER_CONTACTS.vip_clm_alternate%TYPE DEFAULT 'N',
    v_vip_clm_ctm_req                    IN  TPA_USER_CONTACTS.vip_clm_ctm_req%TYPE DEFAULT 'N',
    v_vip_clm_cnh_req                    IN  TPA_USER_CONTACTS.vip_clm_cnh_req%TYPE DEFAULT 'N',
    v_vip_clm_freq                       IN  TPA_USER_CONTACTS.vip_clm_freq%TYPE DEFAULT NULL,
    -------------------------------------------------------------------------------
    v_non_vip_pat_email                  IN  TPA_USER_CONTACTS.non_vip_pat_email%TYPE DEFAULT 'N',
    v_non_vip_pat_sms                    IN  TPA_USER_CONTACTS.non_vip_pat_sms%TYPE DEFAULT 'N',
    v_non_vip_pat_primary                IN  TPA_USER_CONTACTS.non_vip_pat_primary%TYPE DEFAULT 'N',
    v_non_vip_pat_alternate              IN  TPA_USER_CONTACTS.non_vip_pat_alternate%TYPE DEFAULT 'N',
    v_non_vip_pat_cnh_req                IN  TPA_USER_CONTACTS.non_vip_pat_cnh_req%TYPE DEFAULT 'N',
    v_non_vip_pat_freq                   IN  TPA_USER_CONTACTS.non_vip_pat_freq%TYPE DEFAULT NULL,
    -----------------------------------------------------------------------------
    v_non_vip_clm_email                  IN  TPA_USER_CONTACTS.non_vip_clm_email%TYPE DEFAULT 'N',
    v_non_vip_clm_sms                    IN  TPA_USER_CONTACTS.non_vip_clm_sms%TYPE DEFAULT 'N',
    v_non_vip_clm_primary                IN  TPA_USER_CONTACTS.non_vip_clm_primary%TYPE DEFAULT 'N',
    v_non_vip_clm_alternate              IN  TPA_USER_CONTACTS.non_vip_clm_alternate%TYPE DEFAULT 'N',
    v_non_vip_clm_ctm_req                IN  TPA_USER_CONTACTS.non_vip_clm_ctm_req%TYPE DEFAULT 'N',
    v_non_vip_clm_cnh_req                IN  TPA_USER_CONTACTS.non_vip_clm_cnh_req%TYPE DEFAULT 'N',
    v_non_vip_clm_freq                   IN  TPA_USER_CONTACTS.non_vip_clm_freq%TYPE DEFAULT NULL,
    -----------------------------------------------------------------------------------
    v_vip_pat_rej                        IN TPA_USER_CONTACTS.vip_pat_rej%TYPE DEFAULT 'N',
    V_vip_clm_rej                        IN TPA_USER_CONTACTS.vip_clm_rej%TYPE DEFAULT 'N'
    -----------------------------------------------------------------------------------    
  );
  ----------------------------------------------------------------------------------------------------

  PROCEDURE save_login(
    v_contact_seq_id        IN tpa_login_info.contact_seq_id%TYPE,
    v_user_id               IN OUT tpa_login_info.user_id%TYPE,
    v_password              IN tpa_login_info.password%TYPE,
    v_role_seq_id           IN tpa_user_roles.role_seq_id%TYPE,
    v_primary_email_id      IN tpa_user_contacts.primary_email_id%TYPE,
    v_active_yn             IN tpa_login_info.active_yn%TYPE,
    v_employee_number       IN tpa_user_contacts.employee_number%TYPE,
    v_contact_name          IN tpa_user_contacts.contact_name%TYPE,
    v_tpa_office_seq_id     IN tpa_office_info.tpa_office_seq_id%TYPE ,
    v_added_by              IN tpa_login_info.added_by%TYPE,
    v_ACCN_LOCKED_YN        IN tpa_login_info.ACCN_LOCKED_YN%TYPE  --Added for CR-KOC1235
  );
----------------------------------------------------------------------------------------------------
  PROCEDURE select_contact(
    v_contact_seq_id        IN OUT tpa_login_info.contact_seq_id%TYPE,
    user_cur             OUT SYS_REFCURSOR
  );
-------------------------------------------------------------------------------------
  PROCEDURE save_roles(
    v_role_seq_id                    IN OUT tpa_roles_code.role_seq_id%TYPE,
    v_role_name                      IN tpa_roles_code.role_name%TYPE,
    v_role_desc                      IN tpa_roles_code.role_desc%TYPE,
    v_privilege                      IN tpa_roles_code.privilege%TYPE,
    v_user_general_type_id           IN tpa_roles_code.user_general_type_id%TYPE,
    v_added_by                       IN tpa_roles_code.added_by%TYPE,
    v_row_processed                 OUT NUMBER
  );
-------------------------------------------------------------------------------------
  PROCEDURE delete_roles(
    v_role_seq_ids           IN VARCHAR2, -- Concatenated String of role_ids
    v_rows_processed         OUT NUMBER
  ) ;
-------------------------------------------------------------------------------------
  PROCEDURE save_grp_assoc_user (
    v_group_branch_seq_id    IN tpa_group_user_assoc.group_branch_seq_id%TYPE,
    v_contact_seq_ids        IN VARCHAR2, --concatenated string of contact_seq_id delimeted by '|'.
    v_added_by               IN tpa_group_user_assoc.added_by%TYPE,
    v_rows_processed         OUT NUMBER
  );
----------------------------------------------------------------------------------------------------
  PROCEDURE delete_grp_assoc_user(
    v_group_user_seq_ids        IN VARCHAR2, -- Concatenated String of group_user_seq_ids
    v_rows_processed            OUT NUMBER
  );
-------------------------------------------------------------------------------------
    PROCEDURE save_den_mail(
    v_contact_seq_id        IN tpa_user_contacts.contact_seq_id%TYPE,
    v_pat_app_yn            IN tpa_user_contacts.pat_app_yn%TYPE,
    v_pat_rej_yn            IN tpa_user_contacts.pat_rej_yn%TYPE,
    v_clm_app_yn            IN tpa_user_contacts.clm_app_yn%TYPE,
    v_clm_rej_yn            IN tpa_user_contacts.clm_rej_yn%TYPE );
-------------------------------------------------------------------------------------
  PROCEDURE save_group_branch(
    v_group_seq_id               IN  OUT tpa_group_branch.group_seq_id%TYPE,
    v_group_branch_seq_id        IN  tpa_group_branch.group_branch_seq_id%TYPE,
    v_group_name                 IN  tpa_groups.group_name%TYPE,
    v_group_description          IN  tpa_groups.group_description%TYPE,
    v_tpa_office_seq_id          IN  tpa_group_branch.tpa_office_seq_id%TYPE,
    v_group_type_new             IN  tpa_group_branch.group_type%TYPE,
    v_group_type                 IN  NUMBER,
    v_added_by                   IN  tpa_groups.added_by%TYPE,
    v_user_type                  IN  tpa_group_branch.user_type%TYPE, --KOC_Cigna_insurance_resriction
    v_rows_processed             OUT NUMBER
  ) ;
-------------------------------------------------------------------------------------
   PROCEDURE save_groups(
    v_group_seq_id                       IN  OUT TPA_GROUPS.group_seq_id%TYPE,
    v_group_name                         IN  TPA_GROUPS.group_name%TYPE,
    v_group_description                  IN  TPA_GROUPS.group_description%TYPE,
    v_added_by                           IN  TPA_GROUPS.added_by%TYPE,
    v_default_group_yn                   IN  TPA_GROUPS.default_group_yn%TYPE,
    v_group_type_new                     IN  TPA_GROUPS.group_type%TYPE
  );
-------------------------------------------------------------------------------------
  PROCEDURE delete_groups(
    v_group_branch_seq_ids         IN VARCHAR2, -- Concatenated String of group_branch_seq_ids
    v_rows_processed               OUT NUMBER
  );

-------------------------------------------------------------------------------------
  PROCEDURE select_contact_list (
    v_user_general_type_id   IN tpa_user_contacts.user_general_type_id%TYPE,
    v_user_id                IN tpa_login_info.user_id%TYPE,
    v_contact_name           IN tpa_user_contacts.contact_name%TYPE,
    v_role_seq_id            IN tpa_user_roles.role_seq_id%TYPE,
    v_hosp_name              IN tpa_hosp_info.hosp_name%TYPE,
    v_empanel_number         IN tpa_hosp_info.empanel_number%TYPE,
    v_city_type_id           IN tpa_hosp_address.city_type_id%TYPE,
    v_active_yn              IN tpa_user_contacts.active_yn%TYPE,
    v_ins_seq_id             IN tpa_user_contacts.ins_seq_id%TYPE,
    v_ins_comp_code_number   IN tpa_ins_info.Ins_Comp_Code_Number%TYPE,
    v_tpa_office_seq_id      IN tpa_office_info.tpa_office_seq_id%TYPE,
    v_group_name             IN tpa_group_registration.group_name%TYPE,
    v_group_id               IN tpa_group_registration.group_id%TYPE,
    v_sort_var               IN VARCHAR2,
    v_start_num              IN NUMBER ,
    v_end_num                IN NUMBER ,
    v_sort_order             IN VARCHAR2 ,
    result_cur               OUT SYS_REFCURSOR
  );
-------------------------------------------------------------------------------------
      PROCEDURE save_group_reg (
    v_group_reg_seq_id               IN OUT tpa_group_registration.group_reg_seq_id%TYPE,
    v_tpa_office_seq_id              IN tpa_group_registration.tpa_office_seq_id%TYPE,
    v_group_general_type_id          IN OUT tpa_group_registration.group_general_type_id%TYPE,
    v_group_name                     IN tpa_group_registration.group_name%TYPE,
    v_group_id                       IN OUT tpa_group_registration.group_id%TYPE,
    v_parent_group_seq_id            IN tpa_group_registration.parent_group_seq_id%TYPE,
    v_addr_seq_id                    IN tpa_address.addr_seq_id%TYPE,
    v_address_1                      IN tpa_address.address_1%TYPE,
    v_address_2                      IN tpa_address.address_2%TYPE,
    v_address_3                      IN tpa_address.address_3%TYPE,
    v_state_type_id                  IN tpa_address.state_type_id%TYPE,
    v_city_type_id                   IN tpa_address.city_type_id%TYPE,
    v_country_id                     IN tpa_address.country_id%TYPE,
    v_pin_code                       IN tpa_address.pin_code%TYPE,
    v_location_code                  IN tpa_group_registration.location_code%TYPE,
    v_acc_mgr_contact_seq_id         IN tpa_group_registration.acc_mgr_contact_seq_id%TYPE,
    v_notify_email_id                IN tpa_group_registration.notify_email_id%TYPE,
    v_notify_type_id                 IN tpa_group_registration.notify_type_id%TYPE,
    v_cc_email_id                    IN tpa_group_registration.cc_email_id%TYPE,
    v_email_id                       IN tpa_group_registration.email_id%TYPE,
    v_HR_EMAIL_ID                    IN tpa_group_registration.HR_EMAIL_ID%TYPE, --Added new column For CR KOC1111
    v_PREF_PROV_NTW_FLAG             IN tpa_group_registration.PREF_PROV_NTW_FLAG%TYPE,   --KOC1346
    v_added_by                       IN tpa_group_registration.added_by%TYPE,
    v_isd_code                       IN tpa_address.isd_code%type,
    v_std_code                       IN tpa_address.std_code%type,
    v_offise_phone1                  IN tpa_address.office_phone1%type,
    v_office_phone2                  IN tpa_address.office_phone2%type,
    v_priority_flag                  IN varchar2,
	  v_erp_supp_code					         IN tpa_group_registration.erp_supplier_id%type,
	  v_erp_cust_code					         IN tpa_group_registration.erp_customer_id%type,
    v_rows_processed                 OUT NUMBER,
    v_group_id_alert                 OUT VARCHAR2
  );
-------------------------------------------------------------------------------------
  PROCEDURE save_group_address (
    v_addr_seq_id        IN tpa_address.addr_seq_id%TYPE,
    v_tpa_office_seq_id  IN tpa_address.tpa_office_seq_id%TYPE,
    v_ins_seq_id         IN tpa_address.ins_seq_id%TYPE,
    v_group_reg_seq_id   IN tpa_address.group_reg_seq_id%TYPE,
    v_address_1          IN tpa_address.address_1%TYPE,
    v_address_2          IN tpa_address.address_2%TYPE,
    v_address_3          IN tpa_address.address_3%TYPE,
    v_state_type_id      IN tpa_address.state_type_id%TYPE,
    v_city_type_id       IN tpa_address.city_type_id%TYPE,
    v_country_id         IN tpa_address.country_id%TYPE,
    v_pin_code           IN tpa_address.pin_code%TYPE,
    v_added_by           IN tpa_address.added_by%TYPE,
    v_isd_code           IN tpa_address.isd_code%type,
    v_std_code           IN tpa_address.std_code%type,
    v_offise_phone1      IN tpa_address.office_phone1%type,
    v_office_phone2      IN tpa_address.office_phone2%type
  );
-------------------------------------------------------------------------------------
 PROCEDURE delete_group_reg(
   v_group_reg_seq_id  IN tpa_group_registration.group_reg_seq_id%TYPE,
   v_rows_processed    OUT NUMBER
 );
-------------------------------------------------------------------------------------
 PROCEDURE save_product_groups(
    v_prod_policy_seq_id                 IN  tpa_ins_prod_policy.prod_policy_seq_id%TYPE,
    v_tpa_office_ids                     IN  VARCHAR2,       --- '|' Concatenated string tpa_office_seq_ids
    v_added_by                           IN  tpa_groups.added_by%TYPE,
    v_rows_processed                     IN  OUT NUMBER
  );
-------------------------------------------------------------------------------------
  PROCEDURE save_myprofile(
    v_contact_seq_id                     IN  OUT TPA_USER_CONTACTS.contact_seq_id%TYPE,
    v_primary_email_id                   IN  TPA_USER_CONTACTS.primary_email_id%TYPE,
    v_secondary_email_id                 IN  TPA_USER_CONTACTS.secondary_email_id%TYPE,
    v_res_phone_no                       IN  TPA_USER_CONTACTS.res_phone_no%TYPE,
    v_off_phone_no_1                     IN  TPA_USER_CONTACTS.off_phone_no_1%TYPE,
    v_off_phone_no_2                     IN  TPA_USER_CONTACTS.off_phone_no_2%TYPE,
    v_mobile_no                          IN  TPA_USER_CONTACTS.mobile_no%TYPE,
    v_added_by                           IN  TPA_USER_CONTACTS.added_by%TYPE,
    v_rows_processed                     IN  OUT NUMBER
  );
---------------------------------------------------------------------------------------
  PROCEDURE change_password(
    v_contact_seq_id      IN tpa_login_info.contact_seq_id%TYPE,
    v_user_id             IN tpa_login_info.user_id%TYPE,
    v_old_password        IN tpa_login_info.password%TYPE,
    v_new_password        IN tpa_login_info.password%TYPE,
    v_rows_processed      IN  OUT NUMBER
  );
---------------------------------------------------------------------------------------
  PROCEDURE select_acct_mngr_list(
    v_contact_name           IN tpa_user_contacts.contact_name%TYPE,
    v_role_seq_id            IN tpa_roles_code.role_seq_id%TYPE,
    v_employee_number        IN tpa_user_contacts.employee_number%TYPE,
    v_tpa_office_seq_id      IN tpa_user_contacts.tpa_office_seq_id%TYPE,
    v_sort_var               IN VARCHAR2 ,
    v_start_num              IN NUMBER,
    v_end_num                IN NUMBER ,
    v_sort_order             IN VARCHAR2,
    v_result_set             OUT sys_refcursor
  );
---------------------------------------------------------------------------------------
  PROCEDURE select_notification_list(
  v_group_reg_seq_id          IN tpa_group_registration.group_reg_seq_id%TYPE,
  notify_ist_cur              OUT SYS_REFCURSOR
  );
  ---------------------------------------------------------------------------------------
  ----------------------------------------------------------------------------------------------------------
  -- PROCEDURE INSERT RECORDS INTO SOURCE_MESSAGE_CUSTOM_GRP
-- This procedure will Delete the Existing records and Inserts the New Records along with the Existing ones
-- If they are not removed from the list
----------------------------------------------------------------------------------------------------------
  PROCEDURE save_notification_info(
  v_group_reg_seq_id          IN tpa_group_registration.group_reg_seq_id%TYPE,
  v_msg_id                    IN VARCHAR2 , --CONCATENATED msg_ids
  v_added_by                  IN NUMBER,
  v_rows_processed            IN  OUT NUMBER
  );
  ---------------------------------------------------------------------------------------
--Added for CR-KOC1235
--For saving the Password configuratons
 PROCEDURE save_password_config
  (v_acn_expire_in_days     IN  password_config.acn_expire_in_days%TYPE,
   v_password_valid_days    IN password_config.password_valid_days%TYPE,
   v_wrong_attempts         IN password_config.wrong_attempts%TYPE,
   v_alert_days             IN password_config.alert_days%TYPE,
   v_config_type            IN password_config.Config_Type%TYPE, --KOC1257
   v_rows_processed         OUT  number);
--==========================================================
-- Added for CR-KOC1233
-- Audit logs
PROCEDURE create_user_acn_log(v_contact_seq_id    IN        tpa_user_contacts.contact_seq_id%TYPE,
                                v_new_str           IN        VARCHAR2,
                                v_added_by          IN        NUMBER);
--==========================================================
--Added for CR-KOC1235
--scheduler for releasing the locked account at every midnight
PROCEDURE release_acc_lock;
--==========================================================================
--Added for CR-KOC1235
-- scheduler for inactivating the account for persons not using the account for configured days
PROCEDURE login_lock;
--======================================================
--Added for CR-KOC1235
-- Scheduler for expiring password for persons not changing the password for configured days
PROCEDURE expire_password;
--=========================================================
--This will reset the password for all TTK users
PROCEDURE reset_pwd_all(
    v_added_by            IN tpa_login_info.added_by%TYPE,
    v_rows_processed      IN  OUT NUMBER
);
--===============================================================
--koc_ins_mail
 PROCEDURE save_notification_ins_info(
   v_ins_seq_id                IN TPA_INS_INFO.INS_SEQ_ID%TYPE,
   v_msg_id                    IN VARCHAR2 , --CONCATENATED msg_ids
   v_added_by                  IN NUMBER,
   v_rows_processed            IN  OUT NUMBER
   );
--===============================================================
PROCEDURE select_notification_INS_list(
   v_ins_seq_id                IN TPA_INS_INFO.INS_SEQ_ID%TYPE,
   notify_ist_cur              OUT SYS_REFCURSOR
  );
--koc_ins_mail
-----------------------------------------------------------
PROCEDURE gen_prov_userid(
    v_prov_id          IN tpa_user_contacts.provider_id%TYPE,
    v_user_id          OUT tpa_login_info.user_id%TYPE,
    v_password         OUT tpa_login_info.password%TYPE
  );
-----------------------------------------------
PROCEDURE save_provider_creds(
    v_contact_seq_id                 IN OUT tpa_user_contacts.contact_seq_id%TYPE,
    v_user_general_type_id           IN tpa_user_contacts.user_general_type_id%TYPE,
    v_contact_name                   IN tpa_user_contacts.contact_name%TYPE,
    v_provider_id                    IN tpa_user_contacts.provider_id%TYPE,
    v_primary_email_id               IN tpa_user_contacts.primary_email_id%TYPE,
    v_added_by                       IN tpa_user_contacts.added_by%TYPE,
    v_hosp_contact_number            IN tpa_user_contacts.Mobile_No%TYPE,
    v_result                         OUT SYS_REFCURSOR,
    v_row_processed                  OUT number
  );
 --==================================
 PROCEDURE save_hosp_contacts(
    v_contact_seq_id                 IN OUT tpa_user_contacts.contact_seq_id%TYPE,
    v_user_general_type_id           IN tpa_user_contacts.user_general_type_id%TYPE,
    v_hosp_seq_id                    IN tpa_user_contacts.hosp_seq_id%TYPE,
    v_prefix_general_type_id         IN tpa_user_contacts.prefix_general_type_id%TYPE,
    v_contact_name                   IN tpa_user_contacts.contact_name%TYPE,
    v_active_yn                      IN tpa_user_contacts.active_yn%TYPE,
    v_designation_type_id            IN tpa_user_contacts.designation_type_id%TYPE,
    v_primary_email_id               IN tpa_user_contacts.primary_email_id%TYPE,
    v_secondary_email_id             IN tpa_user_contacts.secondary_email_id%TYPE,
    v_off_phone_no_1                 IN tpa_user_contacts.off_phone_no_1%TYPE,
    v_mobile_no                      IN tpa_user_contacts.mobile_no%TYPE,
    v_added_by                       IN tpa_user_contacts.added_by%TYPE,
    v_std_code                       IN tpa_user_contacts.std_code%type,
    v_isd_code                       IN tpa_user_contacts.isd_code%type,
    v_gender_general_type            IN tpa_user_contacts.gender_general_type%type,
    v_age                            In tpa_user_contacts.age%type);
----==================================================
FUNCTION get_gen_codes(v_flag               VARCHAR2,
                       v_header             varchar2,
                       v_description        tpa_general_code.description%type)
                       RETURN VARCHAR2;    
--=========================================================
 PROCEDURE hosp_docotors_upload(v_hosp_doc   clob,v_log_file  out clob);
---========================================================
PROCEDURE save_provider_logs(
    V_PROVIDER_LOG_SEQ_ID                IN  TPA_PROVIDER_LOGS.PROVIDER_LOG_SEQ_ID%TYPE,
    V_TPA_OFICE_SEQ_ID                   IN  TPA_PROVIDER_LOGS.TPA_OFFICE_SEQ_ID%TYPE,
    V_HOSP_SEQ_ID                        IN  TPA_PROVIDER_LOGS.HOSP_SEQ_ID%TYPE,
    V_PROFESSIONAL_ID                    IN  TPA_PROVIDER_LOGS.PROFESSIONAL_ID%TYPE,
    V_PROF_NAME                          IN  TPA_PROVIDER_LOGS.PROF_NAME%TYPE,
    V_AUTHORITY                          IN  TPA_PROVIDER_LOGS.AUTHORITY%TYPE,
    V_ERROR_NO                           IN  TPA_PROVIDER_LOGS.ERROR_NO%TYPE,
    V_ERROR_MESSAGE                      IN  TPA_PROVIDER_LOGS.ERROR_MESSAGE%TYPE,
    V_ERROR_TYPE                         IN  TPA_PROVIDER_LOGS.ERROR_TYPE%TYPE,
    V_ADDED_BY                           IN  TPA_PROVIDER_LOGS.ADDED_BY%TYPE,
    V_PROF_BATCH_SEQ_ID                  IN  NUMBER
   );
  ---========================================
  procedure get_provider_logs(v_file_id       in  varchar2,
                            v_logs          out sys_refcursor,
                            v_hosp_name    out tpa_hosp_info.hosp_name%type);
 ----=============================================================
 -----------Hospital association for corporate------------------
 PROCEDURE select_corp_hosp_list(
    v_empanel_number                     IN  tpa_hosp_info.empanel_number%TYPE,
    v_hosp_name                          IN  tpa_hosp_info.hosp_name%TYPE,
    v_state_type_id                      IN  tpa_hosp_address.state_type_id%TYPE,
    v_city_type_id                       IN  tpa_hosp_address.city_type_id%TYPE,
    v_flag                               IN  VARCHAR2,--EML(EMPANELED) OR ASL(ASSOCIATE LIST)
    v_grou_reg_seq_id                    IN  tpa_group_registration.group_reg_seq_id%type,
    v_sort_var                           IN  VARCHAR2,
    v_sort_order                         IN  VARCHAR2,
    v_start_num                          IN  NUMBER ,
    v_end_num                            IN  NUMBER ,
    result_set                           OUT SYS_REFCURSOR
  );
 -----------------------------------------
 PROCEDURE corp_hosp_associate_save (
   v_hosp_seq_id                    IN  VARCHAR2 , -- Concatenated HOSPITAL Sequence IDs.
   v_group_reg_seq_id               IN  TPA_GROUP_REGISTRATION.GROUP_REG_SEQ_ID%TYPE,
   v_status_general_type_id         IN  TPA_CORP_ASSOC_HOSP.STATUS_GENERAL_TYPE_ID%TYPE,
   v_user_id                        IN  NUMBER,
   v_rows_processed                 OUT NUMBER
   );
   ------------------------------------------------------
 PROCEDURE corp_hosp_associate_delete (
   v_hosp_seq_id                      IN  VARCHAR2 , -- Concatenated Sequence IDs.
   v_user_id                          IN  NUMBER,
   v_rows_processed                   OUT  NUMBER
   ); 

-----------------------------------------------------------------------------
--==================================================================================================
PROCEDURE select_hr_upload_list (
    V_GROUP_ID		                       IN APP.HR_UPLOAD_DETAILS.GROUP_ID%TYPE,
    V_UPLOAD_DATE	                       IN  VARCHAR2,
    v_enr_user_id                        IN TPA_LOGIN_INFO.USER_ID%TYPE,---BHARATH    ( ENR PERSON USER ID)
    v_completed                          IN VARCHAR2,                   ---BHARARH    ( FOR COMPLETE BUTTON)
    v_status                             IN VARCHAR2,                   ---BHARATH    ( FOR SEARCH CRITERIA)
    v_grid_list                          IN VARCHAR2,                   ----BHARATH   ( TO GET SELECTED GRIDS IN LIST FORMAT SEPERATED BY '|')
    v_sort_var                           IN  VARCHAR2,
    v_sort_order                         IN  VARCHAR2 ,
    v_start_num                          IN  NUMBER ,
    v_end_num                            IN  NUMBER ,
  
    result_set                           OUT SYS_REFCURSOR
  );
  --------------------------------------------------------------------------------
 PROCEDURE select_emp_details(p_policy_group_seq_id      IN    tpa_enr_policy_group.policy_group_seq_id%type,
                              p_resultset                OUT   sys_refcursor
                             ); 
 --========================================================================================  
 PROCEDURE reset_emp_pwd(p_policy_group_seq_id         IN    tpa_enr_policy_group.policy_group_seq_id%type,
                         p_added_by                    IN    tpa_enr_policy_group.added_by%type,
                         p_accn_locked_yn              IN    tpa_enr_policy_group.accn_locked_yn%type,
                         p_flag                        IN    varchar2,                         
                         p_rows_processed              OUT   number
                        ) ;
 --=========================================================================================                                                
END  contact_pkg ;
---------------------------------------------------------------------------------------

/

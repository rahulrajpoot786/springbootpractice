--------------------------------------------------------
--  DDL for Synonymn BUFFER_DETAILS_SEQ
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."BUFFER_DETAILS_SEQ" FOR "APP"."BUFFER_DETAILS_SEQ";

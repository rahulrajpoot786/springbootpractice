--------------------------------------------------------
--  DDL for Synonymn DHPO_PAT_SH_TRANSACTIONS
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."DHPO_PAT_SH_TRANSACTIONS" FOR "APP"."DHPO_PAT_SH_TRANSACTIONS";

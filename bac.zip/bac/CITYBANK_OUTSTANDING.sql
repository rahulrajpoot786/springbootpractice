--------------------------------------------------------
--  DDL for Synonymn CITYBANK_OUTSTANDING
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."CITYBANK_OUTSTANDING" FOR "APP"."CITYBANK_OUTSTANDING";

--------------------------------------------------------
--  DDL for Synonymn IDX_CLMINWARD_RCVDDATE
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."IDX_CLMINWARD_RCVDDATE" FOR "APP"."IDX_CLMINWARD_RCVDDATE";

--------------------------------------------------------
--  DDL for Synonymn CURRENCY_CONV_SEQ_ID
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."CURRENCY_CONV_SEQ_ID" FOR "APP"."CURRENCY_CONV_SEQ_ID";

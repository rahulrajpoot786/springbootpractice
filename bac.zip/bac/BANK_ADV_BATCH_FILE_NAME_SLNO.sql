--------------------------------------------------------
--  DDL for Synonymn BANK_ADV_BATCH_FILE_NAME_SLNO
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."BANK_ADV_BATCH_FILE_NAME_SLNO" FOR "FIN_APP"."BANK_ADV_BATCH_FILE_NAME_SLNO";

--------------------------------------------------------
--  DDL for Synonymn IDCARD_PRINT_TEST
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."IDCARD_PRINT_TEST" FOR "INTX"."IDCARD_PRINT_TEST";

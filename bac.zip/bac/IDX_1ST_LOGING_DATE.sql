--------------------------------------------------------
--  DDL for Synonymn IDX_1ST_LOGING_DATE
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."IDX_1ST_LOGING_DATE" FOR "APP"."IDX_1ST_LOGING_DATE";

--------------------------------------------------------
--  DDL for Synonymn CLM_INWARD_NO_SEQ
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."CLM_INWARD_NO_SEQ" FOR "APP"."CLM_INWARD_NO_SEQ";

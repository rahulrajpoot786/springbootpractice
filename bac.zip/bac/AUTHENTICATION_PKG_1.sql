--------------------------------------------------------
--  DDL for Package AUTHENTICATION_PKG
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "VENUBABU"."AUTHENTICATION_PKG" IS

  -- Author  : SREERAJ_SV
  -- Created : 12/19/2005 4:41:07 PM
  -- Purpose : User validation.
  ---------------------------------------------------------------------------------------------------------------
    PROCEDURE pr_user_validation(
    v_user_id        IN OUT tpa_login_info.user_id%TYPE,
    v_password       IN OUT tpa_login_info.password%TYPE,
    v_ip_address     IN tpa_login_info.ip_address%TYPE,  --Added for CR-KOC1235
    v_user_sec       OUT XMLTYPE
  );

  ---------------------------------------------------------------------------------------------------------------
PROCEDURE pr_external_user_validation(
    v_user_id        IN tpa_login_info.user_id%TYPE,
    v_password       IN tpa_login_info.password%TYPE,
    v_in_policy_number  IN tpa_enr_policy.policy_number%TYPE,
    v_in_enrollment_id  IN tpa_enr_policy_member.tpa_enrollment_id%TYPE,
    v_group_id       IN tpa_group_registration.group_id%TYPE,
    v_login_type     IN CHAR, -- OIN FOR INDIVIDUAL, OCO - EMPLOYEE means CORPORATE , OHR FOR HR, OIU FOR INSURANCE ,OCI --  CITI BANK
    v_user_sec       OUT XMLTYPE,
    v_certificate_no IN tpa_enr_policy_group.certificate_no%TYPE := NULL,
    v_expiry_flag_YN OUT CHAR,
    V_PWD_ALERT      OUT VARCHAR2, --KOC1257
    V_FIRST_LOGIN_YN OUT VARCHAR2,  --KOC1257
    V_random_num     OUT tpa_enr_policy_group.random_num%TYPE,   --koc1349
	  v_ip_address     IN tpa_login_info.ip_address%TYPE,
    v_hosp_catagory  IN tpa_hosp_info.hosp_catagory%TYPE,
    v_DateOfBath     IN VARCHAR2:=NULL 
  );
 ----*******Added for CR-KOC1235********
PROCEDURE logout(
    v_user_id           IN tpa_login_info.user_id%TYPE,
    v_ip_address        IN tpa_login_info.ip_address%TYPE,
    v_rows_processed    OUT NUMBER
 );
--==============================================================================================================
PROCEDURE pr_external_single_sign(
    v_user_id        IN tpa_login_info.user_id%TYPE,
    v_password       IN tpa_login_info.password%TYPE,
    v_group_id       IN tpa_group_registration.group_id%TYPE,
    v_login_type     IN CHAR, -- OIN FOR INDIVIDUAL, OCO - EMPLOYEE means CORPORATE , OHR FOR HR, OIU FOR INSURANCE ,OCI --  CITI BANK
   v_random_num      OUT tpa_login_info.password%TYPE
  ); --koc1349
--==============================================================================================================
procedure online_logoff (v_user_id IN tpa_enr_policy_group.employee_no%type,
                         v_random_num IN tpa_enr_policy_group.password_5%type,
                         v_ip_address IN tpa_user_login_history.ip_address%type,
                          v_rows_processed    OUT NUMBER); --koc1349
--=========================================================================================================
PROCEDURE softcopy_login(v_user_id                 IN tpa_login_info.user_id%type,
                         v_pwd                     IN tpa_login_info.password%type,
                         /*v_tpa_office_seq_id       OUT tpa_office_info.tpa_office_seq_id%type,
                         v_office_name               OUT tpa_office_info.office_name%type,
                         v_user_name               OUT tpa_user_contacts.contact_name%type,
                         v_user_seq_id             OUT tpa_user_contacts.contact_seq_id%type,
                         v_rows_processed          OUT NUMBER*/
                         v_sys_cur                 OUT SYS_REFCURSOR);
--=================================================================================================
PROCEDURE user_logout(
    v_user_id           IN tpa_login_info.user_id%TYPE,
    v_password          IN tpa_login_info.password%type,
    v_ip_address        IN tpa_login_info.ip_address%TYPE,
    v_flag              OUT varchar2,--'Y','N'
    v_rows_processed    OUT NUMBER
 );
---============

END authentication_pkg;

/

--------------------------------------------------------
--  DDL for Synonymn CODE_CLEANUP_WORKFLOW_SEQ
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."CODE_CLEANUP_WORKFLOW_SEQ" FOR "APP"."CODE_CLEANUP_WORKFLOW_SEQ";

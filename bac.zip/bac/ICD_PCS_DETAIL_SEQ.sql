--------------------------------------------------------
--  DDL for Synonymn ICD_PCS_DETAIL_SEQ
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."ICD_PCS_DETAIL_SEQ" FOR "APP"."ICD_PCS_DETAIL_SEQ";

--------------------------------------------------------
--  DDL for Package Body ECARD_PKG
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "VENUBABU"."ECARD_PKG" is
 --==================================================================================================  
 /*Author:      Prasanna Kumar R J, SPAN Infotech.
  Description: This procedure extracts data for E-Cards. 
               For corporate policies a Card rule defined at policy level is picked
               For other than corporate policies, and corporate policies having no
               card rule at policy level, card rule defined at product level is picked.
               In case rule doesn't exists at insurace office level, a rule defined
               for the corresponding insurance head office is picked.            */
  
  PROCEDURE select_data_for_card_print (
    v_policy_group_seq_id IN  NUMBER,
    result_set       OUT SYS_REFCURSOR
  )
  IS
      v_Age                 VARCHAR2(15);      v_Gender        VARCHAR2(3);
      v_Emp_Num             VARCHAR2(3);      v_Toll_Free_Num VARCHAR2(3);
      v_Insurance_Id        VARCHAR2(50);      v_Policy_Num    VARCHAR2(50);
      v_Certificate_Num     VARCHAR2(3);      v_Valid_From    VARCHAR2(3);
      v_Valid_Upto          VARCHAR2(3);      v_Remarks       tpa_ins_card_rules.short_remarks%TYPE;
      v_Company_Code        VARCHAR2(3);      v_DOB           VARCHAR2(3);
      v_DOJ                 VARCHAR2(3);      v_Image         VARCHAR2(1000);
      v_Company_Name        VARCHAR2(1000);      v_Enrollment_Id VARCHAR2(100);
      v_Policy_Holder_Name  VARCHAR2(1000);      v_ins_seq_id    tpa_ins_info.ins_seq_id%TYPE;
      v_Policy_Rule         NUMBER(12):=0;    v_bank_acct_num VARCHAR2(3);
      v_relship             VARCHAR2(3);
      v_temp  blob;
  BEGIN
  -- For checking is there any card rule defined at policy level if it is a corporate policy. 
     SELECT COUNT(1) INTO v_Policy_Rule
       FROM tpa_enr_policy_group g JOIN tpa_enr_policy p ON (g.policy_seq_id = p.policy_seq_id)
            JOIN tpa_ins_prod_policy pp ON (p.policy_seq_id = pp.policy_seq_id)
            JOIN tpa_ins_card_rules cr ON (pp.prod_policy_seq_id = cr.prod_policy_seq_id AND
                                            p.enrol_type_id = cr.enrol_type_id AND
                                            (p.ins_head_office_seq_id = cr.ins_seq_id OR
                                             p.ins_seq_id = cr.ins_seq_id ))
         WHERE p.enrol_type_id = 'COR' AND g.policy_group_seq_id = v_policy_group_seq_id;
            
  -- For checking is there any card rule defined at insurance office level. 
     SELECT COUNT(1) INTO v_ins_seq_id
       FROM tpa_enr_policy_group g
            JOIN tpa_enr_policy p ON (g.policy_seq_id = p.policy_seq_id)
            JOIN tpa_ins_prod_policy pp ON ((p.product_seq_id = pp.product_seq_id AND v_Policy_Rule=0)
                                        OR  (p.policy_seq_id = pp.policy_seq_id AND v_Policy_Rule>0))
            JOIN tpa_ins_card_rules cr ON (pp.prod_policy_seq_id = cr.prod_policy_seq_id AND
                                            p.enrol_type_id = cr.enrol_type_id AND
                                            p.Ins_Seq_Id = cr.Ins_Seq_Id)
         WHERE g.policy_group_seq_id = v_policy_group_seq_id;
         
  -- Pick the corresponding insurance office seq for which rule is defined.
     SELECT CASE WHEN v_ins_seq_id = 0 THEN p.ins_head_office_seq_id
                 ELSE p.ins_seq_id END INTO v_ins_seq_id
       FROM tpa_enr_policy_group g
            JOIN tpa_enr_policy p ON (g.policy_seq_id = p.policy_seq_id)
          WHERE g.policy_group_seq_id = v_policy_group_seq_id;
          
  -- Pick the Card rule.
     FOR rec IN (SELECT cr.card_rule_type_id, cr.general_type_id, cr.short_remarks
                   FROM tpa_enr_policy_group g
                        JOIN tpa_enr_policy p ON (g.policy_seq_id = p.policy_seq_id)
                        JOIN tpa_ins_prod_policy pp ON ((p.product_seq_id = pp.product_seq_id AND v_Policy_Rule=0)
                                                    OR  (p.policy_seq_id = pp.policy_seq_id AND v_Policy_Rule>0))
                        JOIN tpa_ins_card_rules cr ON (pp.prod_policy_seq_id = cr.prod_policy_seq_id AND
                                                        p.enrol_type_id = cr.enrol_type_id)
                        LEFT OUTER JOIN tpa_general_code gc ON (cr.general_type_id = gc.general_type_id)
                      WHERE g.policy_group_seq_id = v_policy_group_seq_id
                        AND cr.card_rule_type_id NOT IN ('CPR','CTY','DIS','CRP')
                        AND cr.Ins_Seq_Id = v_ins_seq_id)
     LOOP
            CASE rec.card_rule_type_id
                 WHEN 'AGE' THEN v_Age                := rec.general_type_id;
                 WHEN 'GEN' THEN v_Gender             := rec.general_type_id;
                 WHEN 'EMP' THEN v_Emp_Num            := rec.general_type_id;
                 WHEN 'TOL' THEN v_Toll_Free_Num      := rec.general_type_id;
                 WHEN 'INS' THEN v_Insurance_Id       := rec.general_type_id;
                 WHEN 'PLN' THEN v_Policy_Num         := rec.general_type_id;
                 WHEN 'CNO' THEN v_Certificate_Num    := rec.general_type_id;
                 WHEN 'VFM' THEN v_Valid_From         := rec.general_type_id;
                 WHEN 'VTO' THEN v_Valid_Upto         := rec.general_type_id;
                 WHEN 'CCD' THEN v_Company_Code       := rec.general_type_id;
                 WHEN 'DOB' THEN v_DOB                := rec.general_type_id;
                 WHEN 'DOJ' THEN v_DOJ                := rec.general_type_id;
                 WHEN 'CPR' THEN v_Image              := rec.general_type_id;
                 WHEN 'CNM' THEN v_Company_Name       := rec.general_type_id;
                 WHEN 'MNB' THEN v_Enrollment_Id      := rec.general_type_id;
                 WHEN 'MEM' THEN v_Policy_Holder_Name := rec.general_type_id;
                 WHEN 'ACN' THEN v_bank_acct_num      := rec.general_type_id;
                 WHEN 'SRS' THEN v_relship            := rec.general_type_id;
                 WHEN 'SSR' THEN CASE WHEN rec.general_type_id = 'SRY' THEN v_Remarks := rec.short_remarks; ELSE NULL; END CASE;
                ELSE NULL;
            END CASE ;
     END LOOP;
select image into v_temp from app.temp_image ;
  -- Apply the Card rule and pick data for e-cards.
     OPEN result_set FOR
     SELECT CASE WHEN v_Age                = 'AGEY' THEN m.mem_age ELSE NULL END AS Age,
            CASE WHEN v_Gender             = 'GNDY' THEN substr(gc.description,1,1) ELSE NULL END AS Gender,
            CASE WHEN v_Emp_Num            = 'ENOY' THEN g.employee_no ELSE NULL END AS Emp_Num,
            CASE WHEN v_Toll_Free_Num      = 'CTY' THEN oi.toll_free_no ELSE NULL END AS Toll_Free_Num,
            CASE WHEN v_Insurance_Id       = 'INSY' THEN i.ins_comp_code_number ELSE NULL END AS Insurance_Id,
            CASE WHEN v_Policy_Num         = 'PNOY' THEN p.policy_number ELSE NULL END AS Policy_Num,
            CASE WHEN v_Certificate_Num    = 'CCY' THEN g.certificate_no ELSE NULL END AS Certificate_Num,
            CASE WHEN v_Valid_From         = 'VFY' THEN to_char((CASE WHEN p.effective_from_date > m.date_of_inception OR 
                                                                           m.date_of_inception IS NULL 
                                                                      THEN p.effective_from_date ELSE m.date_of_inception  
                                                                  END),'dd/mm/yyyy') ELSE NULL END AS Valid_From,
            CASE WHEN v_Valid_Upto         = 'VTY' THEN to_char((CASE WHEN p.effective_to_date < m.date_of_exit OR
                                                                           m.date_of_exit IS NULL
                                                                      THEN p.effective_to_date ELSE m.date_of_exit 
                                                                  END),'dd/mm/yyyy') ELSE NULL END AS Valid_Upto,
            CASE WHEN v_Company_Code       = 'CDY' THEN gr.group_id ELSE NULL END AS Company_Code,
            CASE WHEN v_DOB                = 'DOY' THEN to_char(m.mem_dob,'dd/mm/yyyy') ELSE NULL END AS DOB,
            CASE WHEN v_DOJ                = 'DJY' THEN to_char(m.date_of_inception,'dd/mm/yyyy') ELSE NULL END AS DOJ,
            CASE WHEN v_Image              = 'AVL' THEN im.image ELSE NULL END AS NO_Image,
            CASE WHEN v_Company_Name       = 'INCY' THEN gr.group_name ELSE NULL END AS Company_Name,
            CASE WHEN v_Enrollment_Id      = 'TPEY' THEN m.tpa_enrollment_id ELSE NULL END AS Enrollment_Id,
            CASE WHEN v_Policy_Holder_Name = 'MENY' THEN g.insured_name ELSE NULL END AS Policy_Holder_Name,
            CASE WHEN v_relship            = 'RSY' THEN rc.relship_description ELSE NULL END AS Relationship,
            CASE WHEN v_bank_acct_num      = 'ACY' THEN ttk_util_pkg.fn_decrypt(bd.bank_account_no) ELSE NULL END AS Bank_acct_num,
                      v_Remarks AS Remarks,
                      m.mem_name as Name,
                        CASE WHEN TO_DATE(M.date_of_inception,'DD-MM-RRRR') <= TO_DATE(P.EFFECTIVE_FROM_DATE,'DD-MM-RRRR') THEN 
                        to_char(P.EFFECTIVE_FROM_DATE,'dd/mm/yyyy')  ELSE  to_char(M.date_of_inception,'dd/mm/yyyy') END as POLICY_ISSUE_DATE,
                      gc.description as DESCRIPTION,
                      m.vip_yn as VIP,
                      NVL(im.IMAGE,v_temp) AS Image
      FROM tpa_enr_policy_member m
            JOIN tpa_enr_policy_group g ON (m.policy_group_seq_id = g.policy_group_seq_id)
            JOIN tpa_enr_policy p ON (g.policy_seq_id = p.policy_seq_id)
            JOIN TPA_INS_PRODUCT TIP ON (P.PRODUCT_SEQ_ID=TIP.PRODUCT_SEQ_ID)
            join tpa_general_code GC ON (GC.GENERAL_TYPE_ID=TIP.PRODUCT_CAT_TYPE_ID)
            
            LEFT OUTER JOIN tpa_group_registration gr ON (p.group_reg_seq_id = gr.group_reg_seq_id)
            JOIN tpa_ins_info i ON (p.ins_seq_id = i.ins_seq_id)
            LEFT OUTER JOIN tpa_office_info oi ON (p.tpa_office_seq_id = oi.tpa_office_seq_id)
            LEFT OUTER JOIN tpa_general_code gc ON (m.gender_general_type_id = gc.general_type_id)
            LEFT OUTER JOIN image_data im ON (m.tpa_enrollment_id = im.enrolment_id)
            LEFT OUTER JOIN tpa_enr_bank_dtls bd ON bd.bank_seq_id = g.bank_seq_id
            LEFT OUTER JOIN tpa_relationship_code rc ON m.relship_type_id = rc.relship_type_id
         WHERE g.policy_group_seq_id = v_policy_group_seq_id 
         AND m.status_general_type_id != 'POC' AND m.deleted_yn = 'N'
         ORDER BY m.tpa_enrollment_id;
         
  END SELECT_DATA_FOR_CARD_PRINT;
  
 /*ADDED BY:      IBRAHIM SAYYED RCS TECHNOLOGIES.
  Description: This procedure extracts data for E-Cards. 
               For corporate policies a Card rule defined at policy level is picked
               For other than corporate policies, and corporate policies having no
               card rule at policy level, card rule defined at product level is picked.
               In case rule doesn't exists at insurace office level, a rule defined
               for the corresponding insurance head office is picked. it is only for particular member          */
  PROCEDURE select_data_for_card_print_mem (
    v_policy_group_seq_id IN  NUMBER,
    v_member_seq_id IN NUMBER, --ADDED THIS PROCEDURE FOR CR KOC118
    result_set       OUT SYS_REFCURSOR
  )
  IS
      v_Age                 VARCHAR2(15);      v_Gender        VARCHAR2(3);
      v_Emp_Num             VARCHAR2(3);      v_Toll_Free_Num VARCHAR2(3);
      v_Insurance_Id        VARCHAR2(50);      v_Policy_Num    VARCHAR2(50);
      v_Certificate_Num     VARCHAR2(3);      v_Valid_From    VARCHAR2(3);
      v_Valid_Upto          VARCHAR2(3);      v_Remarks       tpa_ins_card_rules.short_remarks%TYPE;
      v_Company_Code        VARCHAR2(3);      v_DOB           VARCHAR2(3);
      v_DOJ                 VARCHAR2(3);      v_Image         VARCHAR2(1000);
      v_Company_Name        VARCHAR2(1000);      v_Enrollment_Id VARCHAR2(100);
      v_Policy_Holder_Name  VARCHAR2(1000);      v_ins_seq_id    tpa_ins_info.ins_seq_id%TYPE;
      v_Policy_Rule         NUMBER(12):=0;    v_bank_acct_num VARCHAR2(3);
      v_relship             VARCHAR2(3);
       v_temp  blob;
     
  BEGIN
  -- For checking is there any card rule defined at policy level if it is a corporate policy. 
     SELECT COUNT(1) INTO v_Policy_Rule
       FROM tpa_enr_policy_group g JOIN tpa_enr_policy p ON (g.policy_seq_id = p.policy_seq_id)
            JOIN tpa_ins_prod_policy pp ON (p.policy_seq_id = pp.policy_seq_id)
            JOIN tpa_ins_card_rules cr ON (pp.prod_policy_seq_id = cr.prod_policy_seq_id AND
                                            p.enrol_type_id = cr.enrol_type_id AND
                                            (p.ins_head_office_seq_id = cr.ins_seq_id OR
                                             p.ins_seq_id = cr.ins_seq_id ))
         WHERE p.enrol_type_id = 'COR' AND g.policy_group_seq_id = v_policy_group_seq_id;
            
  -- For checking is there any card rule defined at insurance office level. 
     SELECT COUNT(1) INTO v_ins_seq_id
       FROM tpa_enr_policy_group g
            JOIN tpa_enr_policy p ON (g.policy_seq_id = p.policy_seq_id)
            JOIN tpa_ins_prod_policy pp ON ((p.product_seq_id = pp.product_seq_id AND v_Policy_Rule=0)
                                        OR  (p.policy_seq_id = pp.policy_seq_id AND v_Policy_Rule>0))
            JOIN tpa_ins_card_rules cr ON (pp.prod_policy_seq_id = cr.prod_policy_seq_id AND
                                            p.enrol_type_id = cr.enrol_type_id AND
                                            p.Ins_Seq_Id = cr.Ins_Seq_Id)
         WHERE g.policy_group_seq_id = v_policy_group_seq_id;
         
  -- Pick the corresponding insurance office seq for which rule is defined.
     SELECT CASE WHEN v_ins_seq_id = 0 THEN p.ins_head_office_seq_id
                 ELSE p.ins_seq_id END INTO v_ins_seq_id
       FROM tpa_enr_policy_group g
            JOIN tpa_enr_policy p ON (g.policy_seq_id = p.policy_seq_id)
          WHERE g.policy_group_seq_id = v_policy_group_seq_id;
    
  -- Pick the Card rule.
     FOR rec IN (SELECT cr.card_rule_type_id, cr.general_type_id, cr.short_remarks
                   FROM tpa_enr_policy_group g
                        JOIN tpa_enr_policy p ON (g.policy_seq_id = p.policy_seq_id)
                        JOIN tpa_ins_prod_policy pp ON ((p.product_seq_id = pp.product_seq_id AND v_Policy_Rule=0)
                                                    OR (p.policy_seq_id = pp.policy_seq_id AND v_Policy_Rule>0))
                        JOIN tpa_ins_card_rules cr ON (pp.prod_policy_seq_id = cr.prod_policy_seq_id AND
                       p.enrol_type_id = cr.enrol_type_id)
                        LEFT OUTER JOIN tpa_general_code gc ON (cr.general_type_id = gc.general_type_id)
                      WHERE g.policy_group_seq_id = v_policy_group_seq_id
                        AND cr.card_rule_type_id NOT IN ('CPR','CTY','DIS','CRP')
                        AND cr.Ins_Seq_Id = v_ins_seq_id)
                        
     LOOP
    
            CASE rec.card_rule_type_id
                 WHEN 'AGE' THEN v_Age                := rec.general_type_id;
                 WHEN 'GEN' THEN v_Gender             := rec.general_type_id;
                 WHEN 'EMP' THEN v_Emp_Num            := rec.general_type_id;
                 WHEN 'TOL' THEN v_Toll_Free_Num      := rec.general_type_id;
                 WHEN 'INS' THEN v_Insurance_Id       := rec.general_type_id;
                 WHEN 'PLN' THEN v_Policy_Num         := rec.general_type_id;
                 WHEN 'CNO' THEN v_Certificate_Num    := rec.general_type_id;
                 WHEN 'VFM' THEN v_Valid_From         := rec.general_type_id;
                 WHEN 'VTO' THEN v_Valid_Upto         := rec.general_type_id;
                 WHEN 'CCD' THEN v_Company_Code       := rec.general_type_id;
                 WHEN 'DOB' THEN v_DOB                := rec.general_type_id;
                 WHEN 'DOJ' THEN v_DOJ                := rec.general_type_id;
                 WHEN 'SHI' THEN v_Image              := rec.general_type_id;
                 WHEN 'CNM' THEN v_Company_Name       := rec.general_type_id;
                 WHEN 'MNB' THEN v_Enrollment_Id      := rec.general_type_id;
                 WHEN 'MEM' THEN v_Policy_Holder_Name := rec.general_type_id;
                 WHEN 'ACN' THEN v_bank_acct_num      := rec.general_type_id;
                 WHEN 'SRS' THEN v_relship            := rec.general_type_id;
                 WHEN 'SSR' THEN CASE WHEN rec.general_type_id = 'SRY' THEN v_Remarks := rec.short_remarks; ELSE NULL; END CASE;
                ELSE NULL;
            END CASE ;
     END LOOP;
select image into v_temp from app.temp_image ;

  -- Apply the Card rule and pick data for e-cards.
     OPEN result_set FOR
     SELECT CASE WHEN v_Age                = 'AGEY' THEN m.mem_age ELSE NULL END AS Age,
            CASE WHEN v_Gender             = 'GNDY' THEN substr(gc.description,1,1) ELSE NULL END AS Gender,
            CASE WHEN v_Emp_Num            = 'ENOY' THEN g.employee_no ELSE NULL END AS Emp_Num,
            CASE WHEN v_Toll_Free_Num      = 'CTY' THEN oi.toll_free_no ELSE NULL END AS Toll_Free_Num,
            CASE WHEN v_Insurance_Id       = 'INSY' THEN i.ins_comp_code_number ELSE NULL END AS Insurance_Id,
            CASE WHEN v_Policy_Num         = 'PNOY' THEN p.policy_number ELSE NULL END AS Policy_Num,
            CASE WHEN v_Certificate_Num    = 'CCY' THEN g.certificate_no ELSE NULL END AS Certificate_Num,
            CASE WHEN v_Valid_From         = 'VFY' THEN to_char((CASE WHEN p.effective_from_date > m.date_of_inception OR 
                                                                           m.date_of_inception IS NULL 
                                                                      THEN p.effective_from_date ELSE m.date_of_inception  
                                                                  END),'dd/mm/yyyy') ELSE NULL END AS Valid_From,
            CASE WHEN v_Valid_Upto         = 'VTY' THEN to_char((CASE WHEN p.effective_to_date < m.date_of_exit OR
                                                                           m.date_of_exit IS NULL
                                                                      THEN p.effective_to_date ELSE m.date_of_exit 
                                                                  END),'dd/mm/yyyy') ELSE NULL END AS Valid_Upto,
            CASE WHEN v_Company_Code       = 'CDY' THEN gr.group_id ELSE NULL END AS Company_Code,
            CASE WHEN v_DOB                = 'DOY' THEN to_char(m.mem_dob,'dd/mm/yyyy') ELSE NULL END AS DOB,
            CASE WHEN v_DOJ                = 'DJY' THEN to_char(m.date_of_inception,'dd/mm/yyyy') ELSE NULL END AS DOJ,
            CASE WHEN v_Image              = 'SIY' THEN im.image ELSE NULL END AS no_Image,
            CASE WHEN v_Company_Name       = 'INCY' THEN gr.group_name ELSE NULL END AS Company_Name,
            CASE WHEN v_Enrollment_Id      = 'TPEY' THEN m.tpa_enrollment_id ELSE NULL END AS Enrollment_Id,
            CASE WHEN v_Policy_Holder_Name = 'MENY' THEN g.insured_name ELSE NULL END AS Policy_Holder_Name,
            CASE WHEN v_relship            = 'RSY' THEN rc.relship_description ELSE NULL END AS Relationship,
            CASE WHEN v_bank_acct_num      = 'ACY' THEN ttk_util_pkg.fn_decrypt(bd.bank_account_no) ELSE NULL END AS Bank_acct_num,
                      v_Remarks AS Remarks,
                      m.mem_name as Name,
                      CASE WHEN TO_DATE(M.date_of_inception,'DD-MM-RRRR') <= TO_DATE(P.EFFECTIVE_FROM_DATE,'DD-MM-RRRR') THEN 
                        to_char(P.EFFECTIVE_FROM_DATE,'dd/mm/yyyy')  ELSE  to_char(M.date_of_inception,'dd/mm/yyyy') END as POLICY_ISSUE_DATE,
                      gc.description as DESCRIPTION,
                      m.vip_yn as VIP,
                      NVL(im.IMAGE,v_temp) AS Image
      FROM tpa_enr_policy_member m
            JOIN tpa_enr_policy_group g ON (m.policy_group_seq_id = g.policy_group_seq_id)
            JOIN tpa_enr_policy p ON (g.policy_seq_id = p.policy_seq_id)
            LEFT OUTER JOIN tpa_group_registration gr ON (p.group_reg_seq_id = gr.group_reg_seq_id)
            JOIN tpa_ins_info i ON (p.ins_seq_id = i.ins_seq_id)
            LEFT OUTER JOIN tpa_office_info oi ON (p.tpa_office_seq_id = oi.tpa_office_seq_id)
            LEFT OUTER JOIN tpa_general_code gc ON (m.gender_general_type_id = gc.general_type_id)
            LEFT OUTER JOIN image_data im ON (m.tpa_enrollment_id = im.enrolment_id)
            LEFT OUTER JOIN tpa_enr_bank_dtls bd ON bd.bank_seq_id = g.bank_seq_id
            LEFT OUTER JOIN tpa_relationship_code rc ON m.relship_type_id = rc.relship_type_id
         WHERE g.policy_group_seq_id = v_policy_group_seq_id 
         AND m.status_general_type_id != 'POC' AND m.deleted_yn = 'N'  and m.member_seq_id=v_member_seq_id
         ORDER BY m.tpa_enrollment_id;
         
  END select_data_for_card_print_mem;
  
end ecard_pkg;

/

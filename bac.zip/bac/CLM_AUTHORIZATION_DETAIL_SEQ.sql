--------------------------------------------------------
--  DDL for Synonymn CLM_AUTHORIZATION_DETAIL_SEQ
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."CLM_AUTHORIZATION_DETAIL_SEQ" FOR "APP"."CLM_AUTHORIZATION_DETAIL_SEQ";

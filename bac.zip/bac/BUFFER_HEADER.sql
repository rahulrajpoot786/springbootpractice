--------------------------------------------------------
--  DDL for Synonymn BUFFER_HEADER
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."BUFFER_HEADER" FOR "APP"."BUFFER_HEADER";

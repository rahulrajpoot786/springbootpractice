--------------------------------------------------------
--  DDL for Synonymn IDX_MEMBUFF_DIFF_CHECK_GRPSEQ
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."IDX_MEMBUFF_DIFF_CHECK_GRPSEQ" FOR "APP"."IDX_MEMBUFF_DIFF_CHECK_GRPSEQ";

--------------------------------------------------------
--  DDL for Synonymn IDX_CALLLOG_PARENTCALLLOGSEQ
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."IDX_CALLLOG_PARENTCALLLOGSEQ" FOR "APP"."IDX_CALLLOG_PARENTCALLLOGSEQ";

--------------------------------------------------------
--  DDL for Synonymn CLM_OUTSTANDING_LIABILITY_RPT
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."CLM_OUTSTANDING_LIABILITY_RPT" FOR "APP"."CLM_OUTSTANDING_LIABILITY_RPT";

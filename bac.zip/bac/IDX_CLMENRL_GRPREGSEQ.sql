--------------------------------------------------------
--  DDL for Synonymn IDX_CLMENRL_GRPREGSEQ
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."IDX_CLMENRL_GRPREGSEQ" FOR "APP"."IDX_CLMENRL_GRPREGSEQ";

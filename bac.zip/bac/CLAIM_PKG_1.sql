--------------------------------------------------------
--  DDL for Package CLAIM_PKG
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "VENUBABU"."CLAIM_PKG" 
is
--===============================================================================

v_prod_policy_rule_seq_id   tpa_ins_prod_policy_rules.prod_policy_rule_seq_id%type;
--===============================================================================
PROCEDURE select_claim_details (
     v_claim_seq_id                              IN  clm_authorization_details.claim_seq_id%type,
     v_clm_result_set                            OUT SYS_REFCURSOR ,
     v_diag_result_set                           OUT SYS_REFCURSOR ,
     v_activity_result_set                       OUT SYS_REFCURSOR ,
     v_observ_result_set                         OUT SYS_REFCURSOR ,
     v_shortfall_details                         OUT SYS_REFCURSOR ,
	 v_pat_count                                 OUT SYS_REFCURSOR ,
     v_clm_count                                 OUT SYS_REFCURSOR );
--===============================================================================
PROCEDURE select_claim (
    v_claim_seq_id                    IN  clm_authorization_details.claim_seq_id%type,
    result_set                           OUT SYS_REFCURSOR  ) ;  
--===============================================================================
PROCEDURE save_clm_details(V_CLAIM_SEQ_ID               IN OUT CLM_AUTHORIZATION_DETAILS.CLAIM_SEQ_ID%type,
                           V_CLM_BATCH_SEQ_ID           IN CLM_AUTHORIZATION_DETAILS.CLM_BATCH_SEQ_ID%type,
                           V_PAT_AUTH_SEQ_ID            IN CLM_AUTHORIZATION_DETAILS.PAT_AUTH_SEQ_ID%type,
                           V_PARENT_CLAIM_SEQ_ID        IN CLM_AUTHORIZATION_DETAILS.PARENT_CLAIM_SEQ_ID%type,
                           V_CLAIM_NUMBER               IN OUT CLM_AUTHORIZATION_DETAILS.CLAIM_NUMBER%type,
                           V_CLAIM_FILE_NUMBER          IN CLM_AUTHORIZATION_DETAILS.CLAIM_FILE_NUMBER%type,
                           V_SETTLEMENT_NUMBER          IN CLM_AUTHORIZATION_DETAILS.SETTLEMENT_NUMBER%type,
                           V_CLM_RECEIVED_DATE          IN CLM_AUTHORIZATION_DETAILS.CLM_RECEIVED_DATE%type,
                           V_SOURCE_TYPE_ID             IN CLM_AUTHORIZATION_DETAILS.SOURCE_TYPE_ID%type,
                           V_HOSPITALIZATION_DATE       IN CLM_AUTHORIZATION_DETAILS.DATE_OF_HOSPITALIZATION%type,
                           V_DISCHARGE_DATE             IN CLM_AUTHORIZATION_DETAILS.DATE_OF_DISCHARGE%type,
                           V_CLAIM_TYPE                 IN CLM_AUTHORIZATION_DETAILS.CLAIM_TYPE%type,
                           V_CLAIM_SUB_TYPE             IN CLM_AUTHORIZATION_DETAILS.CLAIM_SUB_TYPE%type,
                           V_MEMBER_SEQ_ID              IN CLM_AUTHORIZATION_DETAILS.MEMBER_SEQ_ID%type,
                           V_TPA_ENROLLMENT_ID          IN CLM_AUTHORIZATION_DETAILS.TPA_ENROLLMENT_ID%type,
                           V_MEM_NAME                   IN CLM_AUTHORIZATION_DETAILS.MEM_NAME%type,
                           V_MEM_AGE                    IN CLM_AUTHORIZATION_DETAILS.MEM_AGE%type,
                           V_INS_SEQ_ID                 IN CLM_AUTHORIZATION_DETAILS.INS_SEQ_ID%type,
                           V_POLICY_SEQ_ID              IN CLM_AUTHORIZATION_DETAILS.POLICY_SEQ_ID%type,
                           V_ENROL_TYPE_ID              IN CLM_AUTHORIZATION_DETAILS.ENROL_TYPE_ID%type,
                           V_EMIRATE_ID                 IN CLM_AUTHORIZATION_DETAILS.EMIRATE_ID%type,
                           V_ENCOUNTER_TYPE_ID          IN CLM_AUTHORIZATION_DETAILS.ENCOUNTER_TYPE_ID%type,
                           V_ENCOUNTER_START_TYPE       IN CLM_AUTHORIZATION_DETAILS.ENCOUNTER_START_TYPE%type,
                           V_ENCOUNTER_END_TYPE         IN CLM_AUTHORIZATION_DETAILS.ENCOUNTER_END_TYPE%type,
                           V_ENCOUNTER_FACILITY_ID      IN CLM_AUTHORIZATION_DETAILS.ENCOUNTER_FACILITY_ID%type,
                           V_PAYER_ID                   IN CLM_AUTHORIZATION_DETAILS.PAYER_ID%type,
                           V_AVA_SUM_INSURED            IN CLM_AUTHORIZATION_DETAILS.AVA_SUM_INSURED%type,
                           V_CURRENCY_TYPE              IN CLM_AUTHORIZATION_DETAILS.CURRENCY_TYPE%type,
                           V_CLM_STATUS_TYPE_ID         IN CLM_AUTHORIZATION_DETAILS.CLM_STATUS_TYPE_ID%type,
                           V_REMARKS                    IN CLM_AUTHORIZATION_DETAILS.REMARKS%type,
                           V_INVOICE_NUMBER             IN CLM_AUTHORIZATION_DETAILS.INVOICE_NUMBER%type,
                           V_REQUESTED_AMOUNT           IN CLM_AUTHORIZATION_DETAILS.REQUESTED_AMOUNT%type,
                           V_CLINICIAN_ID               IN CLM_AUTHORIZATION_DETAILS.CLINICIAN_ID%type,
                           V_SYSTEM_OF_MEDICINE_TYPE_ID IN CLM_AUTHORIZATION_DETAILS.SYSTEM_OF_MEDICINE_TYPE_ID%type,
                           V_ACCIDENT_RELATED_TYPE_ID   IN CLM_AUTHORIZATION_DETAILS.ACCIDENT_RELATED_TYPE_ID%type,
                           V_PRIORITY_GENERAL_TYPE_ID   IN CLM_AUTHORIZATION_DETAILS.PRIORITY_GENERAL_TYPE_ID%type,
                           V_NETWORK_YN                 IN CLM_AUTHORIZATION_DETAILS.NETWORK_YN%type,
                           V_BENIFIT_TYPE               IN CLM_AUTHORIZATION_DETAILS.BENIFIT_TYPE%type,
                           V_GRAVIDA                    IN CLM_AUTHORIZATION_DETAILS.GRAVIDA%type,
                           V_PARA                       IN CLM_AUTHORIZATION_DETAILS.PARA%type,
                           V_LIVE                       IN CLM_AUTHORIZATION_DETAILS.LIVE%type,
                           V_ABORTION                   IN CLM_AUTHORIZATION_DETAILS.ABORTION%type,
                           V_PRESENTING_COMPLAINTS      IN CLM_AUTHORIZATION_DETAILS.PRESENTING_COMPLAINTS%type,
                           V_MEDICAL_OPINION_REMARKS    IN CLM_AUTHORIZATION_DETAILS.MEDICAL_OPINION_REMARKS%type,
                           V_HOSP_SEQ_ID                IN CLM_HOSPITAL_DETAILS.HOSP_SEQ_ID%type,
                           V_HOSP_NAME                  IN CLM_HOSPITAL_DETAILS.HOSP_NAME%type,
                           V_ADDRESS_1                  IN CLM_HOSPITAL_DETAILS.ADDRESS_1%type,
                           V_CITY_TYPE_ID               IN CLM_HOSPITAL_DETAILS.CITY_TYPE_ID%type,
                           V_STATE_TYPE_ID              IN CLM_HOSPITAL_DETAILS.STATE_TYPE_ID%type,
                           V_PIN_CODE                   IN CLM_HOSPITAL_DETAILS.PIN_CODE%type,
                           V_OFF_PHONE_NO_1             IN CLM_HOSPITAL_DETAILS.OFF_PHONE_NO_1%type,
                           V_OFFICE_FAX_NO              IN CLM_HOSPITAL_DETAILS.OFFICE_FAX_NO%type,
                           V_PROVIDER_ID                IN CLM_HOSPITAL_DETAILS.PROVIDER_ID%type,
                           V_COUNTRY_TYPE_ID            IN CLM_HOSPITAL_DETAILS.COUNTRY_TYPE_ID%type,
                           v_clinician_name             IN CLM_HOSPITAL_DETAILS.CLINICIAN_NAME%type,
                           V_ADDED_BY                   IN CLM_AUTHORIZATION_DETAILS.ADDED_BY%type,
                           V_RI_COPAR_FLAG              IN CLM_AUTHORIZATION_DETAILS.RI_COPAR_FLAG%TYPE,
                           V_UCR_FLAG                   IN CLM_AUTHORIZATION_DETAILS.UCR_FLAG%TYPE,
                           V_TAK_REF_NO                 IN CLM_AUTHORIZATION_DETAILS.TAKAFUL_REF_NO%TYPE,
                           v_nat_conception             IN CLM_AUTHORIZATION_DETAILS.conception_type%type:= null,
                           v_lmp                        IN CLM_AUTHORIZATION_DETAILS.lmp_date%type:= null,
						   V_REQ_AMT_CURRENCY_TYPE      IN CLM_AUTHORIZATION_DETAILS.Req_Amt_Currency_Type%TYPE:=NULL, 
                           V_CONVERTED_AMOUNT           IN CLM_AUTHORIZATION_DETAILS.Converted_Amount%TYPE:=NULL,  
                           v_CONVERTED_AMT_CURRENCY_TYPE  IN CLM_AUTHORIZATION_DETAILS.Converted_Amount_Currency_Type%TYPE:=NULL,
                           V_CONVERSION_RATE            IN CLM_AUTHORIZATION_DETAILS.Conversion_Rate%TYPE:=NULL, 
                           v_process_type               IN CLM_AUTHORIZATION_DETAILS.process_type%TYPE,
                           v_oth_tpa_ref_no             IN CLM_AUTHORIZATION_DETAILS.oth_tpa_ref_no%TYPE:=NULL,
                           v_treatmet_type              IN CLM_AUTHORIZATION_DETAILS.treatment_type%type := null,
                           v_mode_of_delvry             IN clm_authorization_details.delvry_mod_type%TYPE :=NULL,
                           v_event_no                   IN CLM_AUTHORIZATION_DETAILS.EVENT_NO%TYPE,
                           v_embassy_seq_id             IN CLM_AUTHORIZATION_DETAILS.EMBASSY_SEQ_ID%TYPE,
                           v_bank_name                  IN CLM_AUTHORIZATION_DETAILS.BANK_NAME%TYPE,
                           v_iban_no                    IN CLM_AUTHORIZATION_DETAILS.IBAN_NUMBER%TYPE,
                           v_pay_made_for               IN CLM_AUTHORIZATION_DETAILS.PAY_MADE_FOR%TYPE, 
						   v_MAT_COMPLCTON_YN           IN CLM_AUTHORIZATION_DETAILS.MAT_COMPLCTON_YN%TYPE,
                           V_ROWS_PROCESSED             OUT NUMBER);
--===============================================================================
PROCEDURE calculate_authorization(v_claim_seq_id               IN  clm_authorization_details.claim_seq_id%type,
                                  v_hosp_seq_id                IN  clm_hospital_details.hosp_seq_id%TYPE,
                                  v_allowed_amount             OUT clm_authorization_details.tot_allowed_amount%type,
                                  v_result_set                 OUT SYS_REFCURSOR,
                                  v_added_by                   IN  NUMBER
                                 );
--===============================================================================
PROCEDURE save_settlement(  v_claim_seq_id                     IN clm_authorization_details.claim_seq_id%TYPE,
                             v_member_seq_id                   IN clm_authorization_details.member_seq_id%TYPE,
                             v_settlement_number               IN OUT clm_authorization_details.settlement_number%TYPE,
                             v_admission_date                  IN clm_authorization_details.date_of_hospitalization%type,
                             v_allowed_amount                  IN clm_authorization_details.Tot_Allowed_Amount%TYPE,
                             v_source_type_id                  IN clm_authorization_details.source_type_id%TYPE,
                             v_clm_status_type_id              IN OUT clm_authorization_details.clm_status_type_id%TYPE,
                             v_remarks                         IN clm_authorization_details.remarks%type,
                             v_added_by                        IN  NUMBER,
                             v_fnl_amt_currency_type      In varchar2,
					                   v_clm_remark                 IN clm_authorization_details.final_remarks%TYPE,
                             v_internal_remarks           IN VARCHAR2,
                             v_rows_processed     OUT NUMBER,
                             v_rechceck_remarks           IN CLM_AUTHORIZATION_DETAILS.AUDIT_REMARKS%TYPE);
--===============================================================================
PROCEDURE create_claim_xml (
    v_claim_seq_id                       IN  clm_authorization_details.claim_seq_id%type,
    v_claim_history_doc                   OUT clob
   );
--===============================================================================
PROCEDURE save_clm_batch_details(v_clm_batch_seq_id  in out clm_batch_upload_details.clm_batch_seq_id%type,
                                 v_batch_no          in out clm_batch_upload_details.batch_no%type,
                                 v_sender_id         in clm_batch_upload_details.sender_id%type,
                                 v_receiver_id       in clm_batch_upload_details.receiver_id%type,
                                 v_received_date     in clm_batch_upload_details.received_date%type,
                                 v_record_count      in clm_batch_upload_details.record_count%type,
                                 v_batch_tot_amount  in clm_batch_upload_details.batch_tot_amount%type,
                                 v_tpa_office_aeq_id in clm_batch_upload_details.tpa_office_aeq_id%type,
                                 v_batch_status_type in clm_batch_upload_details.batch_status_type%type,
                                 v_benefit_type      in clm_batch_upload_details.benefit_type%type,
                                 v_claim_type        in clm_batch_upload_details.clm_type_gen_type_id%type,
                                 v_submission_type   in clm_batch_upload_details.submission_type_id%type,
                                 v_currency_type     in clm_batch_upload_details.currency_type%type,
                                 v_source_type       in clm_batch_upload_details.source_type_id%type,
                                 v_override          in clm_batch_upload_details.batch_override%type,
                                 v_network_yn        in clm_batch_upload_details.network_yn%type,
                                 v_provider_name     in clm_batch_upload_details.provider_name%type,
                                 v_clm_from          in clm_batch_upload_details.claimfrom_gentype_id%type,
                                 v_added_by          in clm_batch_upload_details.added_by%type,
                                 v_process_type      in clm_batch_upload_details.process_type%type,
                                 v_pymnt_to_type_id  in clm_batch_upload_details.pymnt_to_type_id%type,
                                 v_partner_name      in clm_batch_upload_details.partner_name%type);
--===============================================================================
FUNCTION generate_id_numbers (
    v_flag                           IN VARCHAR2,
    v_country_id                     IN VARCHAR2,
    v_state_id                       IN VARCHAR2,
    v_number                         IN VARCHAR2,  -- CAN BE PREAUTH NUMBER OR SHORTFALL_ID OR INVESTIGATION_ID
    v_claim_type                     IN VARCHAR2 := NULL
  ) RETURN VARCHAR2;
--===============================================================================
PROCEDURE select_clm_batch_details(v_clm_batch_seq_id IN clm_batch_upload_details.clm_batch_seq_id%type,
                                   result_set         OUT SYS_REFCURSOR,
                                   batch_clms         OUT SYS_REFCURSOR);
--===============================================================================
PROCEDURE add_batch_clms(
        v_claim_seq_id                  in  out clm_authorization_details.claim_seq_id%type,
        v_clm_batch_seq_id              in  clm_authorization_details.clm_batch_seq_id%type,
        v_parent_claim_seq_id           in  out clm_authorization_details.parent_claim_seq_id%type,
        v_clm_received_date             in  clm_authorization_details.clm_received_date%type,
        v_claim_type                    in  clm_authorization_details.claim_type%type,
        v_benifit_type                  in  clm_authorization_details.benifit_type%type,
        v_invoice_number                in  clm_authorization_details.invoice_number%type,
        v_requested_amount              in  clm_authorization_details.requested_amount%type,
        v_tot_amount                    in  number,
        v_provider_id                   in  clm_hospital_details.provider_id%type,
        v_member_seq_id                 in  clm_authorization_details.member_seq_id%type,
        v_tpa_enrollmemnt_id            in  clm_authorization_details.tpa_enrollment_id%type,
        v_remarks                       in  clm_authorization_details.re_submission_remarks%type,
        v_added_by                      in  clm_authorization_details.added_by%type,
        v_pymnt_to_type_id              in  clm_authorization_details.pymnt_to_type_id%type,
        v_ptnr_seq_id                   in  clm_authorization_details.ptnr_seq_id%type,
        v_rows_processed                out number);
--===============================================================================
PROCEDURE select_clm_batch_list (
    v_batch_no                           IN  clm_batch_upload_details.batch_no%type,
    v_provider_id                        IN  clm_batch_upload_details.sender_id%type,
    v_received_date                      IN  varchar2,
    V_to_date                            IN  varchar2,
    v_batch_status_type                  IN  clm_batch_upload_details.batch_status_type%TYPE,
    v_clm_type                           IN  clm_batch_upload_details.clm_type_gen_type_id%type,
    v_clm_mode                           IN  clm_authorization_details.source_type_id%type,
    v_submission_type                    IN  clm_batch_upload_details.Submission_Type_Id%TYPE,
    v_sort_var                           IN  VARCHAR2,
    v_sort_order                         IN  VARCHAR2 ,
    v_start_num                          IN  NUMBER ,
    v_end_num                            IN  NUMBER ,
    v_added_by                           IN  NUMBER,
    v_process_type                       in clm_batch_upload_details.process_type%type,
    result_set                           OUT SYS_REFCURSOR
  );
--===============================================================================
--===============================================================================
PROCEDURE save_claims_payment (
    v_claim_seq_id                       IN  TPA_CLAIMS_PAYMENT.claim_seq_id%TYPE,
    v_status                             IN  TPA_CLAIMS_PAYMENT.claim_payment_status%TYPE,
    v_enrol_type_id                      IN  TPA_ENR_POLICY.enrol_type_id%TYPE,
    v_policy_seq_id                      IN  TPA_ENR_POLICY.Policy_Seq_Id%TYPE,
    v_member_seq_id                      IN  TPA_ENR_POLICY_MEMBER.Member_Seq_Id%TYPE,
    v_claim_general_type_id              IN  clm_authorization_details.claim_type%TYPE,
    v_added_by                           IN  TPA_CLAIMS_PAYMENT.added_by%TYPE
  );
--===============================================================================
PROCEDURE select_clm_shortfall_list (
    v_shortfall_id                       IN  shortfall_details.shortfall_id%type,
    v_invoice_number                     IN  clm_authorization_details.invoice_number%type,
    v_batch_no                           IN  clm_batch_upload_details.batch_no%type,
    v_policy_number                      IN  tpa_enr_policy.policy_number%type,
    v_claim_number                       IN  clm_authorization_details.claim_number%type,
    v_claim_type                         IN  clm_batch_upload_details.clm_type_gen_type_id%type,
    v_settlement_number                  IN  clm_authorization_details.settlement_number%TYPE,
    v_tpa_enrollment_id                  IN  clm_authorization_details.tpa_enrollment_id%type,
    v_status_type_id                     IN  shortfall_details.srtfll_status_general_type_id%type,
    v_sort_var                           IN  VARCHAR2,
    v_sort_order                         IN  VARCHAR2 ,
    v_start_num                          IN  NUMBER ,
    v_end_num                            IN  NUMBER ,
    v_added_by                           IN  NUMBER,
    v_qatar_id                           IN  tpa_enr_policy_member.emirate_id%type,
    result_set                           OUT SYS_REFCURSOR
  );
--===============================================================================
PROCEDURE select_preauth_list (
    v_member_seq_id                  IN  pat_authorization_details.member_seq_id%TYPE,
    v_auth_number                    IN  pat_authorization_details.auth_number%TYPE,
    v_hosp_name                      IN  tpa_hosp_info.hosp_name%TYPE,
    v_start_date                     IN  VARCHAR2,
    v_end_date                       IN  VARCHAR2,
    v_tpa_office_seq_id              IN  tpa_office_info.tpa_office_seq_id%TYPE,
    v_sort_var                       IN  VARCHAR2 ,
    v_sort_order                     IN  VARCHAR2,
    v_start_num                      IN  NUMBER,
    v_end_num                        IN  NUMBER,
    v_added_by                       IN  NUMBER,
    result_set                       OUT SYS_REFCURSOR,
    v_claim_seq_id                   IN NUMBER := NULL
  );
--===============================================================================
PROCEDURE select_claims_list (
    v_invoice_number                     IN  clm_authorization_details.invoice_number%type,
    v_batch_no                           IN  clm_batch_upload_details.batch_no%type,
    v_policy_number                      IN  tpa_enr_policy.policy_number%type,
    v_claim_number                       IN  clm_authorization_details.claim_number%type,
    v_claim_type                         IN  clm_batch_upload_details.clm_type_gen_type_id%type,
    v_received_date                      IN  varchar2,
    v_settlement_number                  IN  clm_authorization_details.settlement_number%TYPE,
    v_tpa_enrollment_id                  IN  clm_authorization_details.tpa_enrollment_id%type,
    v_mem_name                           IN  clm_authorization_details.mem_name%type,
    v_clm_status_type_id                 IN  clm_authorization_details.clm_status_type_id%type,
    v_provider_id                        IN  clm_hospital_details.provider_id%type,
    v_ins_seq_id                         IN  clm_authorization_details.ins_seq_id%type,
    v_clm_mode                           IN  clm_authorization_details.source_type_id%type,
    v_global_mem_id                      IN  tpa_enr_policy_member.global_net_member_id%type,
    v_assign_user                        IN    VARCHAR2,
    v_other_user                         IN    VARCHAR2,
    v_added_by                           IN  NUMBER,
    v_process_type                       IN  clm_authorization_details.process_type%type,
    v_srtfll_status_type                 IN  Shortfall_Details.Srtfll_Status_General_Type_Id%TYPE,
    v_event_no                           IN  clm_authorization_details.event_no%TYPE,
    v_common_file_num                    IN  VARCHAR2,
    v_internal_remark_stat               IN  clm_authorization_details.status_code_id%type,
    v_partner_seq_id                     IN  clm_authorization_details.ptnr_seq_id%type,
    v_benifit_type                       IN  clm_authorization_details.benifit_type%type,
    v_req_amt_oper                       IN  VARCHAR2,
    v_req_amount                         IN  VARCHAR2,
    v_linked_pre_no                      IN  VARCHAR2,
    v_qatar_id                           IN  tpa_enr_policy_member.emirate_id%type,
    v_inp_status                         IN  VARCHAR2,
    v_risk_level                         IN  clm_authorization_details.risk_level%type,
    v_inv_status                         IN  tpa_fraud_inv_details.inv_status%type,
    v_fast_disc                          IN  VARCHAR2,
    v_pr_from                            IN  VARCHAR2,
    v_pr_to                              IN  VARCHAR2,
    v_sort_var                           IN  VARCHAR2,
    v_sort_order                         IN  VARCHAR2 ,
    v_start_num                          IN  VARCHAR2 ,
    v_end_num                            IN  VARCHAR2 ,
   
    result_set                           OUT SYS_REFCURSOR,
    v_priority_flag                      IN  VARCHAR2,
    v_audit_status                       IN  VARCHAR2
  );
--===============================================================================
PROCEDURE delete_batch_claims(v_seq_id         IN clm_authorization_details.claim_seq_id%TYPE,
                              v_batch_seq_id   IN clm_batch_upload_details.clm_batch_seq_id%type,
                              v_rows_processed OUT NUMBER);
--===============================================================================
PROCEDURE copy_previous_claim (
    v_claim_seq_id                    IN OUT clm_authorization_details.claim_seq_id%TYPE,
    v_parent_claim_seq_id             IN OUT clm_authorization_details.parent_claim_seq_id%TYPE,
    v_claim_batch_seq_id              IN clm_batch_upload_details.clm_batch_seq_id%TYPE ,
    v_requested_amount                IN clm_authorization_details.requested_amount%TYPE,
    v_added_by                        IN NUMBER
  );
--=============================================================
PROCEDURE select_prev_claim (
    v_member_seq_id              IN  clm_authorization_details.member_seq_id%TYPE,
    v_claim_type                 IN VARCHAR2,
    v_hosp_lic_id                IN VARCHAR2,
    v_sub_cat                    IN VARCHAR2,
    v_payment_to                 IN VARCHAR2,
    v_result_set                 OUT SYS_REFCURSOR
  );
--===============================================================
PROCEDURE delete_claim_records (
    v_claim_seq_id                  IN OUT clm_authorization_details.claim_seq_id%TYPE
  );
--===========================================================================
PROCEDURE override_claim (
    v_claim_seq_id                  IN  clm_authorization_details.claim_seq_id%TYPE,
    v_added_by                      IN NUMBER,
    v_override_remarks              IN clm_authorization_details.override_remarks%TYPE,
    v_rows_processed                OUT NUMBER
  );
--=====================================================================
PROCEDURE control_reject_claims (p_seq_id              IN Clm_Authorization_Details.Claim_Seq_Id%TYPE,
                                 p_denial_code         IN Clm_Authorization_Details.Denial_Code%TYPE,
                                 p_med_opn_remarks     IN Clm_Authorization_Details.Medical_Opinion_Remarks%TYPE,
                                 p_ovrd_remarks        IN Clm_Authorization_Details.Override_Remarks%TYPE,
                                 p_final_remarks       IN Clm_Authorization_Details.Final_Remarks%TYPE,
                                 p_added_by            IN Clm_Authorization_Details.Added_By%Type,
                                 p_internal_remarks    IN Clm_Authorization_Details.Internal_Remarks%Type
                                );
--=================================================================================
PROCEDURE online_clm_submit(v1_batch_seq_id		                      IN VARCHAR2,
                            v1_hosp_seq_id		                      IN VARCHAR2,
                            v1_added_by		                          IN VARCHAR2,
                            v1_sl_no		                            IN VARCHAR2,
                            v1_invoice_num		                      IN VARCHAR2,
                            v1_mem_name		                          IN VARCHAR2,
                            v1_mem_id		                            IN VARCHAR2,
                            v1_pre_auth_num		                      IN VARCHAR2,
                            v1_hospitalization		                  IN VARCHAR2,
                            v1_discharge		                        IN VARCHAR2,
                            v1_med_type		                          IN VARCHAR2,
                            v1_benefit_type		                      IN VARCHAR2,
                            v1_encounter_type		                    IN VARCHAR2,
                            v1_clinician_id		                      IN VARCHAR2 := 'N/A',
                            v1_clinician_name		                    IN VARCHAR2 := 'N/A',
                            v1_sympton		                          IN VARCHAR2,
                            v1_prim_diag_code		                    IN VARCHAR2,
                            v1_prim_diag_desc		                    IN VARCHAR2,
                            v1_secn_diag_code1		                  IN VARCHAR2,
                            v1_secn_diag_code2		                  IN VARCHAR2,
                            v1_secn_diag_code3		                  IN VARCHAR2,
                            v1_secn_diag_code4		                  IN VARCHAR2,
                            v1_secn_diag_code5		                  IN VARCHAR2,
                            v1_first_ins_dt		                      IN VARCHAR2,
                            v1_first_report_dt		                  IN VARCHAR2,
                            v1_service_dt		                      IN VARCHAR2,
							v_activity_type_id 						  IN VARCHAR2,
                            v1_inter_ser_code		                    IN VARCHAR2,
                            v1_service_desc		                      IN VARCHAR2,
                            v1_act_code		                          IN VARCHAR2,
                            v1_act_req_amt		                      IN VARCHAR2,
                            v1_act_qnt		                          IN VARCHAR2,
                            v1_tooth_no		                          IN VARCHAR2,
                            v1_lmp_date		                          IN VARCHAR2,
                            v1_con_nature		                        IN VARCHAR2,
                            v1_observation		                      IN VARCHAR2,
                            v1_event_no                             IN VARCHAR2);
--=====================================================================================================
PROCEDURE online_batch_create(p_batch_no      OUT Clm_Batch_Upload_Details.Batch_No%TYPE,
                              p_bat_seq_id    IN OUT NUMBER,
                              p_sender_id     IN Clm_Batch_Upload_Details.Sender_Id%TYPE,
                              p_recever_id    IN Clm_Batch_Upload_Details.Receiver_Id%TYPE,
                              p_added_by      IN Clm_Batch_Upload_Details.Added_By%TYPE,
                              v_rec_date      IN clm_authorization_details.clm_received_date%Type,
                              v_source_type   IN VARCHAR2
                             );
--=====================================================================================================
PROCEDURE online_clm_submitted_data(p_batch_no      IN NUMBER,
                                    p_err_log       OUT SYS_REFCURSOR,
                                    p_err_count     OUT NUMBER,
                                    p_sucess_count  OUT NUMBER
                                   );
--=====================================================================================================
PROCEDURE search_claims_list (v_submit_from_date                   IN  VARCHAR2,
                              v_submit_to_date                     IN  VARCHAR2,
                              v_from_date                          IN  VARCHAR2,
                              v_to_date                            IN VARCHAR2,
                              v_mem_name                           IN  clm_authorization_details.mem_name%type,
                              v_clm_status_type_id                 IN  clm_authorization_details.clm_status_type_id%type,
                              v_invoice_number                     IN  clm_authorization_details.invoice_number%type,
                              v_batch_number                       IN  clm_batch_upload_details.batch_no%TYPE,
                              v_tpa_enrollment_id                  IN  app.tpa_enr_policy_member.tpa_enrollment_id%type,
                              v_claim_number                       IN  clm_authorization_details.claim_number%type,
                              v_hosp_empanel_no                    IN  VARCHAR2,
                              v_event_no                           IN  pat_authorization_details.event_no%TYPE,
                              v_srtfll_status_type                 IN  VARCHAR2,
                              v_emirate_id                         IN  app.tpa_enr_policy_member.emirate_id%type,
                              v_inp_status                         IN  VARCHAR2,
                              v_sort_var                           IN  VARCHAR2,
                              v_sort_order                         IN  VARCHAR2 ,
                              v_start_num                          IN  VARCHAR2 ,
                              v_end_num                            IN  VARCHAR2 ,
                              result_set                           OUT SYS_REFCURSOR
                             );
--=========================================================================================================================
-- Search Claim List from Provider Details

--===============================================================================================
PROCEDURE get_claim_details(p_clm_seq_id       IN Clm_Authorization_Details.Claim_Seq_Id%TYPE,
                            clm_resultset      OUT SYS_REFCURSOR,
                            diag_resultset     OUT SYS_REFCURSOR,
                            act_resultset      OUT SYS_REFCURSOR,
                            shrtfall_resutlset OUT SYS_REFCURSOR
                           );
--======================================================================================================
PROCEDURE get_shortfall_details (p_shortfall_seq_id IN shortfall_details.shortfall_seq_id%TYPE,
                                 p_resultset        OUT SYS_REFCURSOR
                                );
--=======================================================================================================
                              
PROCEDURE save_error_log(P_ERR_SEQ_ID              IN Error_Log.Err_Seq_Id%TYPE,
                         P_SL_NO                   IN Error_Log.Sl_No%TYPE,
                         P_INVOICE_NO              IN Error_Log.Invoice%TYPE,
                         P_MEM_NAME                IN Error_Log.Mem_Name%TYPE,
                         P_ENROLLMENT_ID           IN Error_Log.Enrollment_Id%TYPE,
                         P_PREAPPTOVAL_NO          IN Error_Log.Preapptoval_No%TYPE,
                         P_DATE_OF_TREATMEMT       IN Error_Log.Date_Of_Treatmemt%TYPE,
                         P_DATE_OF_DISCHARGE       IN Error_Log.Date_Of_Discharge%TYPE,
                         P_SYSTEM_OF_MEDICINE      IN Error_Log.System_Of_Medicine%TYPE,
                         P_BENEFIT_TYPE            IN Error_Log.Benefit_Type%TYPE,
                         P_ENCOUNTER_TYPE          IN Error_Log.Encounter_Type%TYPE,
                         P_CLINICIAN_ID            IN Error_Log.Clinician_Id%TYPE,
                         P_CLINICIAN_NAME          IN Error_Log.Clinician_Name%TYPE,
                         P_SYMPTOMS                IN Error_Log.Symptoms%TYPE,
                         P_PRINCIPAL_ICD_CODE      IN Error_Log.Principal_Icd_Code%TYPE,
                         P_ICD_DESCRIPTION         IN Error_Log.Icd_Description%TYPE,
                         P_SECONDARY_ICD_CODE1     IN Error_Log.Secondary_Icd_Code1%TYPE,
                         P_SECONDARY_ICD_CODE2     IN Error_Log.Secondary_Icd_Code2%TYPE,
                         P_SECONDARY_ICD_CODE3     IN Error_Log.Secondary_Icd_Code3%TYPE,
                         P_SECONDARY_ICD_CODE4     IN Error_Log.Secondary_Icd_Code4%TYPE,
                         P_SECONDARY_ICD_CODE5     IN Error_Log.Secondary_Icd_Code5%TYPE,
                         P_FIRST_INCIDENT_DATE     IN Error_Log.First_Incident_Date%TYPE,
                         P_FIRST_REPORTED_DATE     IN Error_Log.First_Reported_Date%TYPE,
                         P_SERVICE_DATE            IN Error_Log.Service_Date%TYPE,
                         P_INTERNAL_SERVICE_CODE  IN Error_Log.Internal_Service_Code%TYPE,
                         P_SERVICE_DESCRIPTION     IN Error_Log.Service_Description%TYPE,
                         P_CPT_CODE                IN Error_Log.Cpt_Code%TYPE,
                         P_AMOUNT_CLAIMED          IN Error_Log.Amount_Claimed%TYPE,
                         P_QUANTITY                IN VARCHAR2,--Error_Log.Quantity%TYPE,
                         P_TOOTH_NO                IN VARCHAR2,--Error_Log.Tooth_No%TYPE,
                         P_LMP_DATE                IN VARCHAR2,--Error_Log.Lmp_Date%TYPE,
                         P_CON_NATURE              IN VARCHAR2,--Error_Log.Con_Nature%TYPE,
                         P_OBSERVATION             IN Error_Log.Observation%TYPE,
                         P_ERROR_CODE              IN Error_Log.Error_Code%TYPE,
                         P_ERROR_MESSAGE           IN Error_Log.Error_Message%TYPE,
                         P_ERROR_SOURCE            IN Error_Log.Error_Source%TYPE,
                         P_ADDED_BY                IN Error_Log.Added_By%TYPE,
                         P_EVENT_NO                IN Error_Log.Event_No%TYPE
                        );
--================================================================================================================
PROCEDURE create_error_log (
    v_error_no                           IN NUMBER,
    v_error_message                      IN VARCHAR2,
    v_error_type                         IN VARCHAR := NULL,
    v_dependent_count                    IN NUMBER  := NULL
  );
--=======================================================================================================
PROCEDURE select_onl_docs(v_claim_seq_id                    IN clm_authorization_details.claim_seq_id%TYPE,
          	              v_doc                             OUT clm_batch_upload_details.onl_mob_clm_docmnts%TYPE,
                          v_onl_doc_typ                     OUT clm_batch_upload_details.onl_doc_typ%TYPE
                          );
--=================================================================================================================
FUNCTION fn_leap_year (p_year IN VARCHAR2) RETURN NUMBER;
--===============================================================================================
PROCEDURE delt_failed_batch(p_batch_seq_id IN Clm_Batch_Upload_Details.Clm_Batch_Seq_Id%TYPE,
                            p_deleted_by   IN NUMBER);
--===============================================================================================
PROCEDURE Online_Claim_submit_xml (v_clm_in_xl    IN  XMLTYPE,
                                   p_bat_seq_id   OUT VARCHAR2,
                                   v_batch_number OUT VARCHAR2
                                  );
--================================================================================================                                  
PROCEDURE Claim_Payment_Details (v_claim_seq_id      IN NUMBER,
                                  v_result_set        OUT SYS_REFCURSOR);                           
--======================================================================================================

PROCEDURE save_time_details(v_LOG_seq_id            IN NUMBER,
                            v_flag                  IN VARCHAR2,
                            v_start_time            IN NUMBER);                                        
--===================================================================================================
PROCEDURE internal_remark_stat_save(v_pat_clm_seq_id     IN NUMBER,
                                    v_code          IN VARCHAR2,
                                    v_user_id       IN VARCHAR2,
                                    v_code_remarks  IN VARCHAR2,
                                    v_suspect_veri_check IN CHAR,
                                    v_risk_level         IN VARCHAR2,  --- added in CFD module Cr
                                    v_mode               IN VARCHAR2,  --- added in CFD module Cr
                                    v_rows_processed     OUT NUMBER);   --- added in CFD module Cr
--====================================================================================================
PROCEDURE dn_ld_clm_dtls(p_MEMBER_SEQ_ID   IN clm_Authorization_Details.member_seq_id%TYPE,
                         p_flag            in varchar2,
                         v_alkood_id       IN tpa_enr_policy_member.tpa_enrollment_id%TYPE,
                         v_policy_seq_id   IN tpa_enr_policy.policy_seq_id%TYPE,
                         v_benefit_type    IN clm_Authorization_Details.Benifit_Type%TYPE,
                         pat_clm_resultset OUT SYS_REFCURSOR);

--=======================================================================================================
 PROCEDURE clm_and_pat_his_dtl(   p_claim_SEQ_ID      in    clm_Authorization_Details.claim_seq_id%TYPE,
                                  p_flag              in varchar2,   
                                  pat_clm_resultset   OUT       SYS_REFCURSOR);
--===========================================================================================
PROCEDURE select_cfd_pat_clm_list (
     v_claim_number                       IN  clm_authorization_details.claim_number%type,
     v_batch_no                           IN  clm_batch_upload_details.batch_no%type,
     v_provider_id                        IN  clm_hospital_details.provider_id%type,
     v_claim_type                         IN  clm_batch_upload_details.clm_type_gen_type_id%type,
     v_int_remarks                        IN  clm_authorization_details.status_code_id%type,
     v_settlement_number                  IN  clm_authorization_details.settlement_number%TYPE,
     v_policy_number                      IN  tpa_enr_policy.policy_number%type,
     v_partner_seq_id                     IN  clm_authorization_details.ptnr_seq_id%type,
     v_process_type                       IN  clm_authorization_details.process_type%type,
     v_risk_level                         IN  clm_authorization_details.risk_level%type,
     v_tpa_enrollment_id                  IN  clm_authorization_details.tpa_enrollment_id%type,
     v_mem_name                           IN  clm_authorization_details.mem_name%type,
     v_benifit_type                       IN  clm_authorization_details.benifit_type%type,
     v_pre_auth_number                    IN  pat_authorization_details.pre_auth_number%type,
     v_auth_number                        IN  pat_authorization_details.auth_number%type,
     v_invoice_number                     IN  clm_authorization_details.invoice_number%type,
     v_status_type_id                     IN  clm_authorization_details.clm_status_type_id%type,
     v_enr_type                           IN  tpa_enr_policy.enrol_type_id%TYPE,
     v_mode                               IN  clm_authorization_details.source_type_id%type,
     v_inv_status                         IN  tpa_fraud_inv_details.inv_status%type,
     v_sort_var                           IN  VARCHAR2,
     v_sort_order                         IN  VARCHAR2 ,
     v_start_num                          IN  VARCHAR2 ,
     v_end_num                            IN  VARCHAR2 ,
     result_set                           OUT SYS_REFCURSOR);
--==============================================================================================
 ------------- INVESTIGATION STATUS SAVE -------------------
PROCEDURE save_inv_status (
                           v_mode                IN      char,
                           v_seq_id              IN      clm_authorization_details.claim_seq_id%type,
                           v_inv_status          IN      tpa_fraud_inv_details.inv_status%type,
                           v_inv_out_category    IN      tpa_fraud_inv_details.inv_out_category%type,
                           v_amt_util_for_inv    IN      tpa_fraud_inv_details.amt_util_for_inv%type,
                           v_amount_saved        IN      tpa_fraud_inv_details.amount_saved%type,
                           v_cfd_remarks         IN      tpa_fraud_inv_details.cfd_remarks%type,
                           v_inv_start_date      IN      varchar2,
                           v_added_by            IN      tpa_fraud_inv_details.added_by%type,
                           v_rows_processed      OUT     number);
--=================================================================================================
--- added in CFD cr for showing internal & investigation deatils --------------
PROCEDURE  select_int_inv_details(v_mode           IN  VARCHAR2,
                                  v_pat_clm_seq_id IN  NUMBER,
                                  v_int_rem_cur    OUT SYS_REFCURSOR,
                                  v_inv_stat_cur   OUT SYS_REFCURSOR);
 --==================================================================================                                 
 PROCEDURE select_clm_rpt_list(v_fromdate                            IN   VARCHAR2 ,
                              v_toDate                              IN   VARCHAR2 ,
                              v_fromdate1                           IN   VARCHAR2 ,
                              v_toDate1                             IN   VARCHAR2 ,
                              v_patientName                         IN  clm_authorization_details.mem_name%type,
                              v_status                              IN  tpa_general_code.description%type,
                              v_invoice_number                      IN  clm_authorization_details.invoice_number%type,
                              v_batch_no                        in  varchar2,
                              v_memberId                            IN  clm_authorization_details.tpa_enrollment_id%type,
                              v_claim_number                        IN  clm_authorization_details.claim_number%type,
                              v_benifit_type                      in varchar2,
                              v_ref_no                              IN  clm_authorization_details.EVENT_NO%type,
                              v_qatar_id                        IN  varchar2,
                              v_pay_ref_no                      IN VARCHAR2,
                              V_HOSP_SEQ_ID                         IN  pat_authorization_details.hosp_seq_id%type,
                              v_rpt_id                              IN  VARCHAR2,
                              v_sort_var                            IN  VARCHAR2,
                              v_sort_order                          IN  VARCHAR2 ,
                              v_start_num                           IN  NUMBER ,
                              v_end_num                             IN  NUMBER ,
                              result_set                            OUT SYS_REFCURSOR
                             ); 
 --================================================================
 PROCEDURE PRVDR_CLM_RPT (v_input_list IN  VARCHAR2,
                          v_result_set  OUT SYS_REFCURSOR
                         );                                 
--=================================================================================================                           
end  claim_pkg;

/

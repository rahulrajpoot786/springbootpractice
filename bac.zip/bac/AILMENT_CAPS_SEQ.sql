--------------------------------------------------------
--  DDL for Synonymn AILMENT_CAPS_SEQ
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."AILMENT_CAPS_SEQ" FOR "APP"."AILMENT_CAPS_SEQ";

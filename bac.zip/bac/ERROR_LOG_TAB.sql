--------------------------------------------------------
--  DDL for Synonymn ERROR_LOG_TAB
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."ERROR_LOG_TAB" FOR "APP"."ERROR_LOG_TAB";

REM INSERTING into VENUBABU.DUMMY01
SET DEFINE OFF;
Insert into VENUBABU.DUMMY01 (COL1,COL2,COL3) values ('A','B','C');
Insert into VENUBABU.DUMMY01 (COL1,COL2,COL3) values ('B','C','A');
Insert into VENUBABU.DUMMY01 (COL1,COL2,COL3) values ('A','A','B');
Insert into VENUBABU.DUMMY01 (COL1,COL2,COL3) values ('V','V','V');

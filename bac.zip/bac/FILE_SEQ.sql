--------------------------------------------------------
--  DDL for Synonymn FILE_SEQ
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."FILE_SEQ" FOR "APP"."FILE_SEQ";

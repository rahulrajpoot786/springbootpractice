--------------------------------------------------------
--  DDL for Synonymn CLM_DOCUMENT_LIST_CODE
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."CLM_DOCUMENT_LIST_CODE" FOR "APP"."CLM_DOCUMENT_LIST_CODE";

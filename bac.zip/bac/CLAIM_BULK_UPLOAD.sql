--------------------------------------------------------
--  DDL for Package Body CLAIM_BULK_UPLOAD
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "VENUBABU"."CLAIM_BULK_UPLOAD" is

--TYPE typ_clm_data IS TABLE OF APP.CLM_BULK_UPLD_TEMP%ROWTYPE INDEX BY PLS_INTEGER;

                             
rec_clm_xml_dta       APP.CLM_BULK_UPLD_XML_DETAILS%ROWTYPE;
--v_source_type         app.clm_batch_upload_details.source_type_id%type; 
--v_received_date       VARCHAR2(500);      
--rec_clm_details       APP.CLM_BULK_UPLD_CLM_DETAILS%ROWTYPE;

-----------------------------------------------------------------------------------------------------  
PROCEDURE clear_all
  IS
  BEGIN
    rec_clm_xml_dta := NULL;
END clear_all;
------------------------------------------------------------------------------------------------------
PROCEDURE claim_upload (v_xml_seq_id            IN OUT NUMBER,                     
                        v_clm_batch_seq_id      OUT APP.clm_bulk_upld_clm_details.clm_batch_seq_id%type,
                        v_batch_no              OUT APP.clm_bulk_upld_clm_details.batch_no%type,
                        v_tot_rec_cnt           OUT APP.clm_bulk_upld_xml_dta.tot_rec_cnt%type,
                        v_fail_cnt              OUT APP.clm_bulk_upld_xml_dta.fail_cnt%type,
                        v_success_cnt           OUT APP.clm_bulk_upld_xml_dta.success_cnt%type,
                        v_tot_claim_cnt         OUT APP.clm_bulk_upld_xml_dta.TOT_CLM_CNT%type,
                        v_tot_icd_cnt           OUT APP.clm_bulk_upld_xml_dta.TOT_CLM_ICD_CNT%type,
                        v_tot_act_cnt           OUT APP.clm_bulk_upld_xml_dta.TOT_CLM_ACT_CNT%type,
                        v_batch_tot_amnt        OUT APP.clm_batch_upload_details.batch_tot_amount%type,
                        v_added_by              IN NUMBER)
 IS
   
 CURSOR cur_btch_tot_amnt(v_clm_batch_seq_id  NUMBER) IS
  SELECT TO_CHAR(CB.BATCH_TOT_AMOUNT) AS BATCH_TOT_AMOUNT
  FROM APP.CLM_BATCH_UPLOAD_DETAILS CB
  WHERE CB.CLM_BATCH_SEQ_ID = v_clm_batch_seq_id;
  
 CURSOR cur_hosp_seq_id IS
 SELECT X.HOSP_SEQ_ID
 FROM APP.CLM_BULK_UPLD_XML_DETAILS X
 WHERE X.XML_SEQ_ID = V_XML_SEQ_ID
  AND ROWNUM = 1;    
  
   v_data_issue_cnt                NUMBER(10);
   v_exception_cnt                 NUMBER(10);
   v_extrct_data_prsnt_cnt         NUMBER(10);
   v_temp_clm_data_cnt             NUMBER(10);
   v_sql_code                      VARCHAR2(100);
   v_sql_msg                       VARCHAR2(4000);
   V_HOSP_SEQ_ID                   NUMBER(30);
   v_prod_policy_rule_seq_id       NUMBER;
   v_track                         VARCHAR2(32000);
 BEGIN
   
      extract_claim_info (v_xml_seq_id,v_added_by);
      validate_claim_info(v_xml_seq_id,v_added_by);
  
   OPEN  cur_hosp_seq_id;
   FETCH cur_hosp_seq_id INTO V_HOSP_SEQ_ID;
   CLOSE cur_hosp_seq_id;
   
   SELECT COUNT(1) INTO v_extrct_data_prsnt_cnt FROM APP.CLM_BULK_UPLD_XML_DETAILS X WHERE X.XML_SEQ_ID = v_xml_seq_id;
   SELECT COUNT(1) INTO v_data_issue_cnt FROM APP.CLM_BULK_UPLD_XML_DETAILS X WHERE X.XML_SEQ_ID = v_xml_seq_id AND X.REMARKS IS NOT NULL;
   SELECT COUNT(1) INTO v_exception_cnt FROM APP.CLM_BULK_EXCEPTION_LOGS L WHERE L.XML_SEQ_ID = v_xml_seq_id;
   
   IF v_extrct_data_prsnt_cnt > 0 AND v_data_issue_cnt = 0 AND v_exception_cnt = 0 THEN
     split_claims_info(v_xml_seq_id,v_added_by);
   END IF;

   SELECT COUNT(1) INTO v_temp_clm_data_cnt 
   FROM APP.CLM_BULK_UPLD_CLM_DETAILS C
   JOIN APP.CLM_BULK_UPLD_DIAG_DETAILS D ON (C.CLM_XML_SEQ_ID=D.CLM_XML_SEQ_ID)
   JOIN APP.CLM_BULK_UPLD_ACT_DETAILS A ON (C.CLM_XML_SEQ_ID=A.CLM_XML_SEQ_ID)
   WHERE C.XML_SEQ_ID = v_xml_seq_id;
   
   SELECT COUNT(1) INTO v_exception_cnt FROM APP.CLM_BULK_EXCEPTION_LOGS L WHERE L.XML_SEQ_ID = v_xml_seq_id;
   
   IF v_extrct_data_prsnt_cnt > 0 AND v_temp_clm_data_cnt >0 AND v_data_issue_cnt = 0 AND v_exception_cnt = 0 THEN
     
     v_track := 'v_temp_clm_data_cnt: '||v_temp_clm_data_cnt||CHR(10)||
                'v_temp_clm_data_cnt: '||v_temp_clm_data_cnt||CHR(10)||
                'v_data_issue_cnt: '||v_data_issue_cnt||CHR(10)||
                'v_exception_cnt: '||v_exception_cnt;
                
     prc_track_error(v_xml_seq_id, v_track, 'CLM_UPLD');
     
     save_clm_batch_xml(v_xml_seq_id,v_clm_batch_seq_id,v_batch_no,v_added_by);
   END IF;
   
   SELECT COUNT(1) INTO v_exception_cnt FROM APP.CLM_BULK_EXCEPTION_LOGS L WHERE L.XML_SEQ_ID = v_xml_seq_id;
   
   SELECT COUNT(1),
          COUNT(TO_CHAR(x.REMARKS)),
          COUNT(1)-COUNT(TO_CHAR(x.REMARKS)) INTO v_tot_rec_cnt,v_fail_cnt,v_success_cnt
   FROM APP.CLM_BULK_UPLD_XML_DETAILS X
   WHERE X.XML_SEQ_ID = v_xml_seq_id;
   
   /*SELECT COUNT(1) INTO v_fail_cnt
   FROM APP.CLM_BULK_UPLD_XML_DETAILS X
   WHERE X.XML_SEQ_ID = v_xml_seq_id
     AND X.REMARKS IS NOT NULL;*/
     
   v_fail_cnt := CASE WHEN v_fail_cnt != 0 THEN v_fail_cnt
                      ELSE v_exception_cnt END;
   
  /* SELECT COUNT(1) INTO v_success_cnt
   FROM APP.CLM_BULK_UPLD_XML_DETAILS X
   WHERE X.XML_SEQ_ID = v_xml_seq_id
     AND X.REMARKS IS NULL;*/
   
   
   
   SELECT COUNT(1) INTO v_tot_claim_cnt
   FROM APP.CLM_BULK_UPLD_CLM_DETAILS C
   WHERE C.XML_SEQ_ID = v_xml_seq_id;
   
   SELECT COUNT(1) INTO v_tot_icd_cnt
   FROM APP.CLM_BULK_UPLD_DIAG_DETAILS D
   WHERE D.XML_SEQ_ID = v_xml_seq_id;
   
   SELECT COUNT(1) INTO v_tot_act_cnt
   FROM APP.CLM_BULK_UPLD_CLM_DETAILS C
   JOIN APP.CLM_BULK_UPLD_ACT_DETAILS A ON (C.CLM_XML_SEQ_ID=A.CLM_XML_SEQ_ID)
   WHERE C.XML_SEQ_ID = v_xml_seq_id;
   
   UPDATE APP.CLM_BULK_UPLD_XML_DTA X
     SET X.TOT_CLM_CNT     = v_tot_claim_cnt,
         X.TOT_CLM_ICD_CNT = v_tot_icd_cnt,
         X.TOT_CLM_ACT_CNT = v_tot_act_cnt,
         X.TOT_REC_CNT     = v_tot_rec_cnt,
         X.FAIL_CNT        = CASE WHEN v_fail_cnt != 0 THEN v_fail_cnt
                                  ELSE v_exception_cnt END,
         X.SUCCESS_CNT     = v_success_cnt
   WHERE X.XML_SEQ_ID = v_xml_seq_id;
    
   OPEN  cur_btch_tot_amnt(v_clm_batch_seq_id);
   FETCH cur_btch_tot_amnt INTO v_batch_tot_amnt;
   CLOSE cur_btch_tot_amnt;
   
   IF v_fail_cnt > 0  THEN
     DELETE FROM APP.CLM_BATCH_UPLOAD_DETAILS B WHERE B.CLM_BATCH_SEQ_ID = v_clm_batch_seq_id;
   END IF;
   
   FOR i IN (select clm.claim_seq_id,clm.member_seq_id , clm.policy_seq_id from app.clm_authorization_details clm where clm.clm_batch_seq_id= v_clm_batch_seq_id)
   LOOP
      v_prod_policy_rule_seq_id := pat_xml_load_pkg.get_prod_pol_seq_id(i.policy_seq_id,'POL');
      pat_xml_load_pkg.execute_global_rules('C', i.claim_seq_id, i.member_seq_id, v_prod_policy_rule_seq_id);
   END LOOP; 
     
   COMMIT;
   
 EXCEPTION
  WHEN OTHERS THEN
     V_SQL_CODE := SQLCODE;
     V_SQL_MSG  := SQLERRM; 
   
     save_exception_log(v_xml_seq_id,NULL,v_sql_code,v_sql_msg,NULL,v_added_by,'claim_upload',V_HOSP_SEQ_ID);
     ROLLBACK;
     
 END claim_upload;        
------------------------------------------------------------------------------------------------------
PROCEDURE save_claim_xml (v_xml_seq_id            IN OUT NUMBER,                     
                          v_clm_in_xl             IN XMLTYPE,
                          v_added_by              IN NUMBER,
                          v_file_name             IN VARCHAR2)
 IS
  PRAGMA AUTONOMOUS_TRANSACTION;
  
  v_sql_code             VARCHAR2(100);
  v_sql_msg              VARCHAR2(4000);
 BEGIN
   INSERT INTO APP.CLM_BULK_UPLD_XML_DTA(XML_SEQ_ID,XML_DATA,ADDED_BY,FILE_NAME)  
                               VALUES (app.clm_blk_xml_seq.nextval,v_clm_in_xl,v_added_by,v_file_name)
                              RETURNING XML_SEQ_ID INTO V_XML_SEQ_ID;
                              
   COMMIT;
  
 EXCEPTION
  WHEN OTHERS THEN
     V_SQL_CODE := SQLCODE;
     V_SQL_MSG  := SQLERRM; 
   
     save_exception_log(v_xml_seq_id,NULL,v_sql_code,v_sql_msg,NULL,v_added_by,'save_claim_xml',NULL);
     ROLLBACK;
                                   
 END save_claim_xml;                
------------------------------------------------------------------------------------------------------
PROCEDURE extract_claim_info(v_xml_seq_id            IN NUMBER,                     
                             v_added_by              IN NUMBER)
  IS
  
  
 CURSOR cur_clm_xml_info IS
  SELECT D.XML_DATA
  FROM APP.CLM_BULK_UPLD_XML_DTA D
  WHERE D.XML_SEQ_ID = v_xml_seq_id; 


  v_clm_upload_doc  DBMS_XMLDOM.DOMDocument;
  v_parent_node     DBMS_XMLDOM.DOMNode;
  v_child_node      DBMS_XMLDOM.DOMNode;
  v_hosp_node       DBMS_XMLDOM.DOMNodeList;
  v_clm_nodes       DBMS_XMLDOM.DOMNodeList;
  v_element         DBMS_XMLDOM.DOMElement;
  v_element1        DBMS_XMLDOM.DOMELement;
  
  v_sl_no                VARCHAR2(500);
  v_start_time           NUMBER;
  v_sql_code             VARCHAR2(100);
  v_sql_msg              VARCHAR2(4000);
  v_clm_in_xl            XMLTYPE;
  v_clm_raw_dta_seq_id   NUMBER(30);
 
 BEGIN 
   
  clear_all();
  
  OPEN  cur_clm_xml_info;
  FETCH cur_clm_xml_info INTO v_clm_in_xl;
  CLOSE cur_clm_xml_info;
   
    v_start_time     := dbms_utility.get_time;
    v_clm_upload_doc := Dbms_xmldom.newDOMDocument(v_clm_in_xl);
    v_hosp_node      := Dbms_xmldom.getElementsByTagName(v_clm_upload_doc,'claimsUpload');
      
       FOR v_parent_list in 0.. dbms_xmldom.getlength(v_hosp_node) - 1 LOOP
         v_parent_node                := Dbms_xmldom.item(v_hosp_node,v_parent_list);
         v_element                    := Dbms_xmldom.makeElement(v_parent_node);
         rec_clm_xml_dta.hosp_seq_id  := Dbms_Xmldom.getAttribute(v_element,'hospSeqId');
         rec_clm_xml_dta.received_date:= Dbms_xmldom.getAttribute(v_element,'receivedDate');
         rec_clm_xml_dta.received_date:= rtrim(rec_clm_xml_dta.received_date,'.0');
         rec_clm_xml_dta.source_type  := Dbms_Xmldom.getAttribute(v_element,'sourceType');
      END LOOP; 
 
      v_clm_nodes :=Dbms_xmldom.getElementsByTagName(v_element,'claimsData');
      
      FOR v_claim_index in 0..dbms_xmldom.getlength(v_clm_nodes) - 1 LOOP
        v_child_node := Dbms_xmldom.item(v_clm_nodes,v_claim_index);
        v_element1   := Dbms_xmldom.makeElement(v_child_node);
        --claim Details
          rec_clm_xml_dta.clinician_id         :=Dbms_xmldom.getAttribute(v_element1,'clinicianId');
          rec_clm_xml_dta.clinician_name       :=Dbms_xmldom.getAttribute(v_element1,'clinicianName');
          rec_clm_xml_dta.med_type             :=Dbms_xmldom.getAttribute(v_element1,'sysOfMed');
          rec_clm_xml_dta.invoice_no           :=Dbms_xmldom.getAttribute(v_element1,'invNo');
          rec_clm_xml_dta.member_id            :=Dbms_xmldom.getAttribute(v_element1,'memId');
          rec_clm_xml_dta.member_name          :=Dbms_xmldom.getAttribute(v_element1,'memName');
          rec_clm_xml_dta.benefit_type         :=Dbms_xmldom.getAttribute(v_element1,'benType');
          rec_clm_xml_dta.event_ref_no         :=Dbms_xmldom.getAttribute(v_element1,'evntRefNo');
          rec_clm_xml_dta.nature_of_conception := Dbms_xmldom.getAttribute(v_element1,'natOfConep');
          rec_clm_xml_dta.preapproval_no       :=Dbms_xmldom.getAttribute(v_element1,'preAprNo');
          rec_clm_xml_dta.symptoms             :=Dbms_Xmldom.getAttribute(v_element1,'symptoms');
          rec_clm_xml_dta.encounter_type       :=Dbms_xmldom.getAttribute(v_element1,'encType');
        --DIAGNONYSYS RELATED
          rec_clm_xml_dta.principal_icd        :=Dbms_xmldom.getAttribute(v_element1,'princiICdCode');
          rec_clm_xml_dta.icd_description      :=Dbms_xmldom.getAttribute(v_element1,'princiICDesc');
          rec_clm_xml_dta.secondary_icd_code1  :=Dbms_xmldom.getAttribute(v_element1,'secIcd1');
          rec_clm_xml_dta.secondary_icd_code2  :=Dbms_xmldom.getAttribute(v_element1,'secIcd2');
          rec_clm_xml_dta.secondary_icd_code3  :=Dbms_xmldom.getAttribute(v_element1,'secIcd3');
          rec_clm_xml_dta.secondary_icd_code4  :=Dbms_xmldom.getAttribute(v_element1,'secIcd4');
          rec_clm_xml_dta.secondary_icd_code5  :=Dbms_xmldom.getAttribute(v_element1,'secIcd5');
        --ACTIVITY RELATED
          rec_clm_xml_dta.quantity             :=Dbms_xmldom.getAttribute(v_element1,'qty');
          rec_clm_xml_dta.activity_type        :=Dbms_xmldom.getAttribute(v_element1,'actType');
          rec_clm_xml_dta.amount_claimed       :=Dbms_xmldom.getAttribute(v_element1,'amntClmnd');
          rec_clm_xml_dta.cpt_code             :=Dbms_xmldom.getAttribute(v_element1,'cptCode');
          rec_clm_xml_dta.internal_service_code:=Dbms_xmldom.getAttribute(v_element1,'internalCode');
          rec_clm_xml_dta.service_description  :=Dbms_xmldom.getAttribute(v_element1,'servDesc');
          rec_clm_xml_dta.tooth_number         :=Dbms_Xmldom.getAttribute(v_element1,'toothNo');
          rec_clm_xml_dta.observation          :=Dbms_xmldom.getAttribute(v_element1,'observtn');
          --ALL DATE RELATED FIELDS
          rec_clm_xml_dta.date_treatment       :=Dbms_xmldom.getAttribute(v_element1,'dtOfTrtmt');
          rec_clm_xml_dta.date_discharge       :=Dbms_xmldom.getAttribute(v_element1,'dtDisch');
          rec_clm_xml_dta.date_of_lmp          :=Dbms_xmldom.getAttribute(v_element1,'dtOfLMP');
          rec_clm_xml_dta.first_incident_date  :=Dbms_Xmldom.getAttribute(v_element1,'firstIncDt');
          rec_clm_xml_dta.first_reported_date  :=Dbms_Xmldom.getAttribute(v_element1,'firstRepDt');
          rec_clm_xml_dta.service_date         :=Dbms_Xmldom.getAttribute(v_element1,'servDt');
          rec_clm_xml_dta.s_no                 :=Dbms_Xmldom.getAttribute(v_element1,'slno');
          rec_clm_xml_dta.moph_codes           :=Dbms_Xmldom.getAttribute(v_element1,'mophCode');      
          rec_clm_xml_dta.unit_type            :=Dbms_Xmldom.getAttribute(v_element1,'unitType');
          rec_clm_xml_dta.dur_medi             :=Dbms_Xmldom.getAttribute(v_element1,'durationOfMedicine');
          IF rec_clm_xml_dta.source_type='PBCL' THEN
          rec_clm_xml_dta.date_treatment       :=Dbms_xmldom.getAttribute(v_element1,'dateOfPrescription');
          rec_clm_xml_dta.date_discharge       :=Dbms_xmldom.getAttribute(v_element1,'dateOfPrescription');
          --rec_clm_xml_dta.date_of_lmp          :=Dbms_xmldom.getAttribute(v_element1,'dtOfLMP');
          rec_clm_xml_dta.service_date         :=Dbms_Xmldom.getAttribute(v_element1,'dateOfPrescription');
          rec_clm_xml_dta.service_description      :=Dbms_xmldom.getAttribute(v_element1,'drugdescription');        
          END IF;
       INSERT INTO APP.CLM_BULK_UPLD_XML_DETAILS
              (CLM_RAW_DTA_SEQ_ID,
               XML_SEQ_ID,
               S_NO,
               INVOICE_NO,
               MEMBER_NAME,
               MEMBER_ID,
               PREAPPROVAL_NO,
               DATE_TREATMENT,
               DATE_DISCHARGE,
               MED_TYPE,
               BENEFIT_TYPE,
               ENCOUNTER_TYPE,
               CLINICIAN_ID,
               CLINICIAN_NAME,
               SYMPTOMS,
               PRINCIPAL_ICD,
               ICD_DESCRIPTION,
               SECONDARY_ICD_CODE1,
               SECONDARY_ICD_CODE2,
               SECONDARY_ICD_CODE3,
               SECONDARY_ICD_CODE4,
               SECONDARY_ICD_CODE5,
               FIRST_INCIDENT_DATE,
               FIRST_REPORTED_DATE,
               SERVICE_DATE,
               ACTIVITY_TYPE,
               INTERNAL_SERVICE_CODE,
               SERVICE_DESCRIPTION,
               CPT_CODE,
               AMOUNT_CLAIMED,
               QUANTITY,
               TOOTH_NUMBER,
               DATE_OF_LMP,
               NATURE_OF_CONCEPTION,
               OBSERVATION,
               event_ref_no,
               HOSP_SEQ_ID,
               RECEIVED_DATE,
               SOURCE_TYPE,
               MOPH_CODES,
               UNIT_TYPE,
               DUR_MEDI)
       VALUES(app.clm_blk_upld_seq.nextval,
              V_XML_SEQ_ID,
              TRIM(TRIM(BOTH '�' FROM REPLACE(rec_clm_xml_dta.s_no,CHR(10)))),
              TRIM(TRIM(BOTH '�' FROM REPLACE(rec_clm_xml_dta.INVOICE_NO,CHR(10)))),
              TRIM(TRIM(BOTH '�' FROM REPLACE(rec_clm_xml_dta.MEMBER_NAME,CHR(10)))),
              TRIM(TRIM(BOTH '�' FROM REPLACE(UPPER(rec_clm_xml_dta.MEMBER_ID),CHR(10)))),
              TRIM(TRIM(BOTH '�' FROM REPLACE(UPPER(rec_clm_xml_dta.PREAPPROVAL_NO),CHR(10)))),
              TRIM(TRIM(BOTH '�' FROM REPLACE(rec_clm_xml_dta.DATE_TREATMENT,CHR(10)))),
              TRIM(TRIM(BOTH '�' FROM REPLACE(rec_clm_xml_dta.DATE_DISCHARGE,CHR(10)))),
              TRIM(TRIM(BOTH '�' FROM REPLACE(rec_clm_xml_dta.MED_TYPE,CHR(10)))),
              TRIM(TRIM(BOTH '�' FROM REPLACE(rec_clm_xml_dta.BENEFIT_TYPE,CHR(10)))),
              TRIM(TRIM(BOTH '�' FROM REPLACE(rec_clm_xml_dta.ENCOUNTER_TYPE,CHR(10)))),
              TRIM(TRIM(BOTH '�' FROM REPLACE(rec_clm_xml_dta.CLINICIAN_ID,CHR(10)))),
              TRIM(TRIM(BOTH '�' FROM REPLACE(rec_clm_xml_dta.CLINICIAN_NAME,CHR(10)))),
              TRIM(TRIM(BOTH '�' FROM REPLACE(rec_clm_xml_dta.SYMPTOMS,CHR(10)))),
              TRIM(TRIM(BOTH '�' FROM REPLACE(rec_clm_xml_dta.PRINCIPAL_ICD,CHR(10)))),
              TRIM(TRIM(BOTH '�' FROM REPLACE(rec_clm_xml_dta.ICD_DESCRIPTION,CHR(10)))),
              TRIM(TRIM(BOTH '�' FROM REPLACE(rec_clm_xml_dta.SECONDARY_ICD_CODE1,CHR(10)))),
              TRIM(TRIM(BOTH '�' FROM REPLACE(rec_clm_xml_dta.SECONDARY_ICD_CODE2,CHR(10)))),
              TRIM(TRIM(BOTH '�' FROM REPLACE(rec_clm_xml_dta.SECONDARY_ICD_CODE3,CHR(10)))),
              TRIM(TRIM(BOTH '�' FROM REPLACE(rec_clm_xml_dta.SECONDARY_ICD_CODE4,CHR(10)))),
              TRIM(TRIM(BOTH '�' FROM REPLACE(rec_clm_xml_dta.SECONDARY_ICD_CODE5,CHR(10)))),
              TRIM(TRIM(BOTH '�' FROM REPLACE(rec_clm_xml_dta.FIRST_INCIDENT_DATE,CHR(10)))),
              TRIM(TRIM(BOTH '�' FROM REPLACE(rec_clm_xml_dta.FIRST_REPORTED_DATE,CHR(10)))),
              TRIM(TRIM(BOTH '�' FROM REPLACE(rec_clm_xml_dta.SERVICE_DATE,CHR(10)))),
              TRIM(TRIM(BOTH '�' FROM REPLACE(rec_clm_xml_dta.ACTIVITY_TYPE,CHR(10)))),
              TRIM(TRIM(BOTH '�' FROM REPLACE(UPPER(rec_clm_xml_dta.INTERNAL_SERVICE_CODE),CHR(10)))),
              TRIM(TRIM(BOTH '�' FROM REPLACE(rec_clm_xml_dta.SERVICE_DESCRIPTION,CHR(10)))),
              TRIM(TRIM(BOTH '�' FROM REPLACE(UPPER(rec_clm_xml_dta.CPT_CODE),CHR(10)))),
              TRIM(TRIM(BOTH '�' FROM REPLACE(rec_clm_xml_dta.AMOUNT_CLAIMED,CHR(10)))),
              TRIM(TRIM(BOTH '�' FROM REPLACE(rec_clm_xml_dta.QUANTITY,CHR(10)))),
              TRIM(TRIM(BOTH '�' FROM REPLACE(rec_clm_xml_dta.TOOTH_NUMBER,CHR(10)))),
              TRIM(TRIM(BOTH '�' FROM REPLACE(rec_clm_xml_dta.DATE_OF_LMP,CHR(10)))),
              TRIM(TRIM(BOTH '�' FROM REPLACE(rec_clm_xml_dta.NATURE_OF_CONCEPTION,CHR(10)))),
              TRIM(TRIM(BOTH '�' FROM REPLACE(rec_clm_xml_dta.OBSERVATION,CHR(10)))),
              TRIM(TRIM(BOTH '�' FROM REPLACE(rec_clm_xml_dta.event_ref_no,CHR(10)))),
              TRIM(TRIM(BOTH '�' FROM REPLACE(rec_clm_xml_dta.HOSP_SEQ_ID,CHR(10)))),
              TRIM(TRIM(BOTH '�' FROM REPLACE(rec_clm_xml_dta.received_date,CHR(10)))),
              TRIM(TRIM(BOTH '�' FROM REPLACE(rec_clm_xml_dta.source_type,CHR(10)))),
              TRIM(TRIM(BOTH '�' FROM REPLACE(rec_clm_xml_dta.moph_codes,CHR(10)))),
              TRIM(TRIM(BOTH '�' FROM REPLACE(rec_clm_xml_dta.unit_type,CHR(10)))),
              TRIM(TRIM(BOTH '�' FROM REPLACE(rec_clm_xml_dta.dur_medi,CHR(10))))          
              ) RETURNING clm_raw_dta_seq_id INTO v_clm_raw_dta_seq_id;
    END LOOP;
    
save_time_details(v_xml_seq_id,'XML_HOSP_SEQ_ID',rec_clm_xml_dta.HOSP_SEQ_ID); 
    
save_time_details(v_xml_seq_id,'EXTRCT_CLM',v_start_time);

 EXCEPTION
  WHEN OTHERS THEN
     V_SQL_CODE := SQLCODE;
     V_SQL_MSG  := SQLERRM; 
   
     save_exception_log(v_xml_seq_id,v_clm_raw_dta_seq_id,v_sql_code,v_sql_msg,NULL,v_added_by,'extract_claim_info',rec_clm_xml_dta.hosp_seq_id);
     ROLLBACK;
     
 END extract_claim_info; 
------------------------------------------------------------------------------------------------------
PROCEDURE validate_claim_info(v_xml_seq_id            IN NUMBER, 
                              v_added_by              IN NUMBER)
  AS
  
  
  v_start_time           NUMBER;
  bulk_errors          EXCEPTION;
  PRAGMA EXCEPTION_INIT(bulk_errors, -24381);
  l_error_count          NUMBER; 
  v_bulk_error_msg       CLOB;
  
  CURSOR cur_xml_claim_info IS
   SELECT C.SOURCE_TYPE,C.RECEIVED_DATE,C.HOSP_SEQ_ID
   FROM APP.CLM_BULK_UPLD_XML_DETAILS C
   WHERE C.XML_SEQ_ID = v_xml_seq_id
   AND ROWNUM = 1;
   
  CURSOR cur_xml_hosp_info IS
   SELECT xd.HOSP_SEQ_ID
   FROM APP.CLM_BULK_UPLD_XML_DTA xd
   WHERE xd.XML_SEQ_ID = v_xml_seq_id;
   
 rec_xml_claim_info                 cur_xml_claim_info%ROWTYPE;   
  
  CURSOR cur_mand_valdion  IS
     SELECT T.CLM_RAW_DTA_SEQ_ID,
       CASE WHEN T.INVOICE_NO IS NULL THEN 'Invoice number is blank; ' ELSE NULL END ||
       CASE WHEN T.INVOICE_NO IS NOT NULL THEN CASE claim_bulk_upload.check_size('INV',T.INVOICE_NO) WHEN 'SIZE_ISSUE' THEN 'Invoice is invalid/size exceeded; ' WHEN 'INVALID' THEN 'Invoice is invalid; ' WHEN 'NA' THEN 'Invoice is invalid; ' ELSE NULL END ELSE NULL END ||  
       CASE WHEN T.INVOICE_NO IS NOT NULL AND regexp_like(T.INVOICE_NO, '[.,;&'']') THEN 'Special char not allowd for Invoice Number (i.e .,;&''); ' ELSE NULL END ||  
       --CASE WHEN T.INVOICE_NO IS NOT NULL AND claim_bulk_upload.validate_data('INV_HOSP',T.INVOICE_NO,T.HOSP_SEQ_ID) > 0 THEN 'Invoice no. available for this provider; ' ELSE NULL END ||
       CASE WHEN T.INVOICE_NO IS NOT NULL AND (SELECT COUNT(1) FROM APP.CLM_AUTHORIZATION_DETAILS CA
                                                               JOIN APP.CLM_HOSPITAL_DETAILS H ON (CA.CLAIM_SEQ_ID=H.CLAIM_SEQ_ID)
                                                               WHERE  H.HOSP_SEQ_ID = T.HOSP_SEQ_ID
                                                               AND ','||CA.INVOICE_NUMBER||',' LIKE '%,'||T.INVOICE_NO||',%') > 0
              THEN 'Invoice no. available for this provider; ' ELSE NULL END ||
        CASE WHEN T.INVOICE_NO IS NOT NULL AND (SELECT COUNT(1) FROM app.CLM_BULK_UPLD_XML_DTA d 
                                                                JOIN APP.CLM_BULK_UPLD_XML_DETAILS xd on (d.xml_seq_id=xd.xml_seq_id)
                                                                WHERE  XD.HOSP_SEQ_ID = T.HOSP_SEQ_ID and d.tot_rec_cnt=d.success_cnt
                                                               AND ','||XD.Invoice_No||',' LIKE '%,'||T.INVOICE_NO||',%') > 0
              THEN 'Invoice no. available for this provider; ' ELSE NULL END ||
       
       
       CASE WHEN T.MEMBER_NAME IS NULL THEN 'Member name is blank; ' ELSE NULL END || 
       CASE WHEN T.MEMBER_NAME IS NOT NULL THEN CASE claim_bulk_upload.check_size('MNME',T.MEMBER_NAME) WHEN 'SIZE_ISSUE' THEN 'Mem name is invalid/size exceeded; ' WHEN 'INVALID' THEN 'Mem name is invalid; ' WHEN 'NA' THEN 'Mem name is invalid; ' ELSE NULL END ELSE NULL END ||
       
       CASE WHEN T.MEMBER_ID IS NULL THEN 'Member ID is blank; ' ELSE NULL END ||
       --CASE WHEN T.MEMBER_ID IS NOT NULL THEN CASE check_size('MID',T.MEMBER_ID) WHEN 'SIZE_ISSUE' THEN 'Mem ID is invalid/size exceeded; ' WHEN 'INVALID' THEN 'Mem ID is invalid; ' WHEN 'NA' THEN 'Mem ID is invalid; ' ELSE NULL END ELSE NULL END ||
       --CASE WHEN T.MEMBER_ID IS NOT NULL AND claim_bulk_upload.validate_data('MEM_ID',T.MEMBER_ID) = 0 THEN 'Invalid member ID; ' ELSE NULL END ||
       CASE WHEN T.MEMBER_ID IS NOT NULL AND (SELECT COUNT(1) 
                                              FROM APP.TPA_ENR_POLICY_MEMBER M
                                              JOIN APP.TPA_ENR_POLICY_GROUP PG ON (M.POLICY_GROUP_SEQ_ID=PG.POLICY_GROUP_SEQ_ID)
                                              JOIN APP.TPA_ENR_POLICY EP ON (PG.POLICY_SEQ_ID=EP.POLICY_SEQ_ID) 
                                              WHERE M.TPA_ENROLLMENT_ID = T.MEMBER_ID 
                                              AND EP.COMPLETED_YN = 'Y'
                                              AND M.DELETED_YN = 'N') = 0 
             THEN 'Invalid member ID; ' ELSE NULL END ||
       
       
       CASE WHEN T.PREAPPROVAL_NO IS NOT NULL AND PMEM.PRE_AUTH_NUMBER IS NULL THEN 'Member ID mismatch in Pre-approval; ' ELSE NULL END ||  
       
       --CASE WHEN rec_xml_claim_info.source_type!='PBCL' THEN CASE WHEN T.DATE_TREATMENT IS NOT NULL AND T.PREAPPROVAL_NO IS NOT NULL AND claim_bulk_upload.validate_data('PAT_HOSP_DATE', T.PREAPPROVAL_NO, T.DATE_TREATMENT) = 0 THEN 'Treatment date mismatch with Pre-approval; 'ELSE NULL END ELSE NULL END|| --- CR 0198
       CASE WHEN rec_xml_claim_info.source_type!='PBCL' THEN CASE WHEN T.DATE_TREATMENT IS NULL THEN 'Treatment date is blank; ' ELSE NULL END ELSE NULL END ||
       CASE WHEN rec_xml_claim_info.source_type!='PBCL' THEN CASE WHEN T.DATE_TREATMENT IS NOT NULL AND claim_bulk_upload.check_data_type('DT',T.DATE_TREATMENT) IS NULL THEN 'Treatment date is invalid; ' ELSE NULL END ELSE NULL END ||
       CASE WHEN rec_xml_claim_info.source_type!='PBCL' THEN CASE WHEN T.DATE_TREATMENT IS NOT NULL AND claim_bulk_upload.check_data_type('DT',T.DATE_TREATMENT) IS NOT NULL AND TRUNC(TO_DATE(T.DATE_TREATMENT,'DD/MM/YYYY')) > TRUNC(SYSDATE) THEN 'Treatment date can''t be future date; ' ELSE NULL END ELSE NULL END || 
       CASE WHEN rec_xml_claim_info.source_type!='PBCL' THEN CASE WHEN T.DATE_TREATMENT IS NOT NULL AND claim_bulk_upload.check_data_type('DT',T.DATE_TREATMENT) IS NOT NULL AND T.DATE_DISCHARGE IS NOT NULL AND claim_bulk_upload.check_data_type('DT',T.DATE_DISCHARGE) IS NOT NULL AND TO_DATE(T.DATE_TREATMENT,'DD-MM-RRRR') > TO_DATE(T.DATE_DISCHARGE,'DD-MM-RRRR') THEN 'Discharge date can''t be prior to admission date; ' ELSE NULL END ELSE NULL END || 
       
       CASE WHEN rec_xml_claim_info.source_type='PBCL' THEN CASE WHEN T.DATE_TREATMENT IS NULL THEN 'Date or Prescription is blank; ' ELSE NULL END ELSE NULL END ||
       CASE WHEN rec_xml_claim_info.source_type='PBCL' THEN CASE WHEN T.DATE_TREATMENT IS NOT NULL AND claim_bulk_upload.check_data_type('DT',T.DATE_TREATMENT) IS NULL THEN 'Date or Prescriptionis invalid; ' ELSE NULL END ELSE NULL END ||
       CASE WHEN rec_xml_claim_info.source_type='PBCL' THEN CASE WHEN T.DATE_TREATMENT IS NOT NULL AND claim_bulk_upload.check_data_type('DT',T.DATE_TREATMENT) IS NOT NULL AND TRUNC(TO_DATE(T.DATE_TREATMENT,'DD/MM/YYYY')) > TRUNC(SYSDATE) THEN 'Date or Prescription can''t be future date; ' ELSE NULL END  ELSE NULL END ||
       
       
       
       CASE WHEN rec_xml_claim_info.source_type!='PBCL' THEN CASE WHEN T.DATE_DISCHARGE IS NULL AND T.BENEFIT_TYPE IS NOT NULL AND claim_bulk_upload.get_benf_type_id(T.BENEFIT_TYPE) IN ('IPT','IMTI') AND T.PREAPPROVAL_NO IS NULL THEN 'Discharge date is blank; ' ELSE NULL END ELSE NULL END ||          
       CASE WHEN rec_xml_claim_info.source_type!='PBCL' THEN CASE WHEN T.DATE_DISCHARGE IS NOT NULL AND claim_bulk_upload.check_data_type('DT',T.DATE_DISCHARGE) IS NULL THEN 'Discharge date is invalid; ' ELSE NULL END ELSE NULL END ||
       
                     
       CASE WHEN T.MED_TYPE IS NULL THEN 'System of medicine is blank; ' ELSE NULL END ||
       CASE WHEN T.MED_TYPE IS NOT NULL AND T.PREAPPROVAL_NO IS NULL THEN CASE claim_bulk_upload.check_size('SYS',T.MED_TYPE) WHEN 'SIZE_ISSUE' THEN 'Medicine type is invalid/size exceeded; ' WHEN 'INVALID' THEN 'Medicine type is invalid; 'WHEN 'NA' THEN 'Medicine type is invalid; ' ELSE NULL END ELSE NULL END ||
       CASE WHEN rec_xml_claim_info.source_type!='PBCL' THEN CASE WHEN T.MED_TYPE IS NOT NULL AND T.PREAPPROVAL_NO IS NOT NULL THEN CASE WHEN claim_bulk_upload.validate_data('MED_TYPE', T.PREAPPROVAL_NO, claim_bulk_upload.check_size('SYS',T.MED_TYPE)) = 0 THEN 'Medicine type mismatch with Pre-approval; ' ELSE NULL END ELSE NULL END ELSE NULL END|| -- CR 0198
       
       
       CASE WHEN rec_xml_claim_info.source_type!='PBCL' THEN CASE WHEN T.BENEFIT_TYPE IS NULL THEN 'Benefit type is blank; ' ELSE NULL END ELSE NULL END ||
       CASE WHEN rec_xml_claim_info.source_type!='PBCL' THEN CASE WHEN T.BENEFIT_TYPE IS NOT NULL AND T.PREAPPROVAL_NO IS NULL THEN CASE claim_bulk_upload.check_size('BNF',T.BENEFIT_TYPE) WHEN 'SIZE_ISSUE' THEN 'Benefit type is invalid/size exceeded; ' WHEN 'INVALID' THEN 'Benefit type is invalid; 'WHEN 'NA' THEN 'Benefit type is invalid; 'ELSE NULL END ELSE NULL END ELSE NULL END || 
       CASE WHEN rec_xml_claim_info.source_type!='PBCL' THEN CASE WHEN T.BENEFIT_TYPE IS NOT NULL AND T.PREAPPROVAL_NO IS NOT NULL THEN CASE WHEN claim_bulk_upload.validate_data('BEN_TYPE', T.PREAPPROVAL_NO, claim_bulk_upload.check_size('BNF', T.BENEFIT_TYPE, NULL)) = 0 THEN 'Benefit type mismatch with Pre-approval; ' ELSE NULL END ELSE NULL END ELSE NULL END|| -- CR 0198
                                           
       CASE WHEN rec_xml_claim_info.source_type!='PBCL' THEN CASE WHEN T.ENCOUNTER_TYPE IS NULL THEN 'Encounter type is blank; ' ELSE NULL END ELSE NULL END ||  
       CASE WHEN rec_xml_claim_info.source_type!='PBCL' THEN CASE WHEN T.ENCOUNTER_TYPE IS NOT NULL AND T.PREAPPROVAL_NO IS NULL THEN CASE claim_bulk_upload.check_size('ENCTR',T.ENCOUNTER_TYPE,T.BENEFIT_TYPE) WHEN 'SIZE_ISSUE' THEN 'Encounter type is invalid as per benefit type/size exceeded; ' WHEN 'INVALID' THEN 'Encounter type is invalid as per benefit type; 'WHEN 'NA' THEN 'Encounter type is invalid as per benefit type; 'ELSE NULL END ELSE NULL END ELSE NULL END || 
       CASE WHEN rec_xml_claim_info.source_type!='PBCL' THEN CASE WHEN T.ENCOUNTER_TYPE IS NOT NULL AND T.PREAPPROVAL_NO IS NOT NULL THEN CASE WHEN claim_bulk_upload.validate_data('ENC_TYPE',T.PREAPPROVAL_NO, claim_bulk_upload.check_size('ENCTR', T.ENCOUNTER_TYPE, T.BENEFIT_TYPE)) = 0 THEN 'Encounter type mismatch with Pre-approval' ELSE NULL END ELSE NULL END ELSE NULL END || -- CR 0198
       
       CASE WHEN T.CLINICIAN_ID IS NOT NULL THEN CASE claim_bulk_upload.check_size('CID',T.CLINICIAN_ID) WHEN 'SIZE_ISSUE' THEN 'Clinician ID is invalid/size exceeded; ' WHEN 'INVALID' THEN 'Clinician ID is invalid; ' ELSE NULL END ELSE NULL END ||
       CASE WHEN T.CLINICIAN_NAME IS NOT NULL THEN CASE claim_bulk_upload.check_size('CNME',T.CLINICIAN_NAME) WHEN 'SIZE_ISSUE' THEN 'Clinician name is invalid/size exceeded; ' WHEN 'INVALID' THEN 'Clinician nme is invalid; ' ELSE NULL END ELSE NULL END ||

       
       CASE WHEN rec_xml_claim_info.source_type!='PBCL' THEN CASE WHEN T.SYMPTOMS IS NULL THEN 'Symptoms is blank; ' ELSE NULL END ELSE NULL END ||
       CASE WHEN rec_xml_claim_info.source_type!='PBCL' THEN CASE WHEN T.SYMPTOMS IS NOT NULL THEN CASE claim_bulk_upload.check_size('SYM',T.SYMPTOMS) WHEN 'SIZE_ISSUE' THEN 'Symptoms is invalid/size exceeded; ' WHEN 'INVALID' THEN 'Symptoms is invalid; 'WHEN 'NA' THEN 'Symptoms is invalid; 'ELSE NULL END ELSE NULL END ELSE NULL END ||
       
       
       CASE WHEN T.PRINCIPAL_ICD IS NULL THEN 'Principal ICD is blank; ' ELSE NULL END ||
       CASE WHEN T.PRINCIPAL_ICD IS NOT NULL THEN CASE claim_bulk_upload.check_size('PICD',T.PRINCIPAL_ICD) WHEN 'SIZE_ISSUE' THEN 'Principal ICD is invalid/size exceeded; ' WHEN 'INVALID' THEN 'Principal ICD is invalid; 'WHEN 'NA' THEN 'Principal ICD is invalid; 'ELSE NULL END ELSE NULL END ||
       --CASE WHEN T.PRINCIPAL_ICD IS NOT NULL AND claim_bulk_upload.check_size('PICD',T.PRINCIPAL_ICD) NOT IN ('SIZE_ISSUE','INVALID','NA') AND claim_bulk_upload.validate_data('ICD',T.PRINCIPAL_ICD) = 0 THEN 'Principal ICD invalid; ' ELSE NULL END ||
       CASE WHEN T.PRINCIPAL_ICD IS NOT NULL AND claim_bulk_upload.check_size('PICD',T.PRINCIPAL_ICD) NOT IN ('SIZE_ISSUE','INVALID','NA') AND PAM.ICD_SEQ_ID IS NULL AND PI.ICD10_SEQ_ID IS NULL THEN 'Principal ICD invalid; ' ELSE NULL END ||
       
       CASE WHEN rec_xml_claim_info.source_type!='PBCL' THEN CASE WHEN T.PRINCIPAL_ICD IS NOT NULL AND T.PREAPPROVAL_NO IS NULL AND claim_bulk_upload.check_size('PICD',T.PRINCIPAL_ICD) NOT IN ('SIZE_ISSUE','INVALID','NA') AND (DAM.ICD10_SEQ_ID IS NOT NULL OR D10.ICD10_SEQ_ID IS NOT NULL) AND claim_bulk_upload.get_benf_type_id(T.BENEFIT_TYPE) NOT IN ('DNTL') THEN 'Entered diagnosis does not match with the benefit type; ' ELSE NULL END ELSE NULL END ||
       CASE WHEN rec_xml_claim_info.source_type!='PBCL' THEN CASE WHEN T.PRINCIPAL_ICD IS NOT NULL AND T.PREAPPROVAL_NO IS NULL AND claim_bulk_upload.check_size('PICD',T.PRINCIPAL_ICD) NOT IN ('SIZE_ISSUE','INVALID','NA') AND (DAM.ICD10_SEQ_ID IS NULL AND D10.ICD10_SEQ_ID IS NULL) AND claim_bulk_upload.get_benf_type_id(T.BENEFIT_TYPE) IN ('DNTL') THEN 'Entered diagnosis does not match with the benefit type; ' ELSE NULL END ELSE NULL END ||
       
       CASE WHEN rec_xml_claim_info.source_type!='PBCL' THEN CASE WHEN T.PRINCIPAL_ICD IS NOT NULL AND claim_bulk_upload.check_size('PICD',T.PRINCIPAL_ICD) NOT IN ('SIZE_ISSUE','INVALID','NA') AND TIC.MASTER_ICD_CODE = 'Z34.90' AND claim_bulk_upload.get_benf_type_id(T.BENEFIT_TYPE) NOT IN('IMTI','OMTI','MTI') THEN 'Entered diagnosis does not match with the benefit type; ' ELSE NULL END ELSE NULL END ||
         
       CASE WHEN T.ICD_DESCRIPTION IS NULL THEN 'ICD description is blank; ' ELSE NULL END ||
       
       CASE WHEN T.SECONDARY_ICD_CODE1 IS NOT NULL THEN CASE claim_bulk_upload.check_size('SICD1',T.SECONDARY_ICD_CODE1) WHEN 'SIZE_ISSUE' THEN 'Sec ICD1 is invalid/size exceeded; ' WHEN 'INVALID' THEN 'Sec ICD1 is invalid; ' WHEN 'NA' THEN 'Sec ICD1 is invalid; ' ELSE NULL END ELSE NULL END ||
       CASE WHEN T.SECONDARY_ICD_CODE2 IS NOT NULL THEN CASE claim_bulk_upload.check_size('SICD2',T.SECONDARY_ICD_CODE2) WHEN 'SIZE_ISSUE' THEN 'Sec ICD2 is invalid/size exceeded; ' WHEN 'INVALID' THEN 'Sec ICD2 is invalid; ' WHEN 'NA' THEN 'Sec ICD2 is invalid; ' ELSE NULL END ELSE NULL END ||
       CASE WHEN T.SECONDARY_ICD_CODE3 IS NOT NULL THEN CASE claim_bulk_upload.check_size('SICD3',T.SECONDARY_ICD_CODE3) WHEN 'SIZE_ISSUE' THEN 'Sec ICD3 is invalid/size exceeded; ' WHEN 'INVALID' THEN 'Sec ICD3 is invalid; ' WHEN 'NA' THEN 'Sec ICD3 is invalid; ' ELSE NULL END ELSE NULL END ||
       CASE WHEN T.SECONDARY_ICD_CODE4 IS NOT NULL THEN CASE claim_bulk_upload.check_size('SICD4',T.SECONDARY_ICD_CODE4) WHEN 'SIZE_ISSUE' THEN 'Sec ICD4 is invalid/size exceeded; ' WHEN 'INVALID' THEN 'Sec ICD4 is invalid; ' WHEN 'NA' THEN 'Sec ICD4 is invalid; ' ELSE NULL END ELSE NULL END ||
       CASE WHEN T.SECONDARY_ICD_CODE5 IS NOT NULL THEN CASE claim_bulk_upload.check_size('SICD5',T.SECONDARY_ICD_CODE5) WHEN 'SIZE_ISSUE' THEN 'Sec ICD5 is invalid/size exceeded; ' WHEN 'INVALID' THEN 'Sec ICD5 is invalid; ' WHEN 'NA' THEN 'Sec ICD5 is invalid; ' ELSE NULL END ELSE NULL END ||
       /*
       CASE WHEN T.SECONDARY_ICD_CODE1 IS NOT NULL AND claim_bulk_upload.check_size('SICD1',T.SECONDARY_ICD_CODE1) NOT IN ('SIZE_ISSUE','INVALID','NA') AND claim_bulk_upload.validate_data('ICD',T.SECONDARY_ICD_CODE1) = 0 THEN 'Sec ICD1 invalid; ' ELSE NULL END ||
       CASE WHEN T.SECONDARY_ICD_CODE2 IS NOT NULL AND claim_bulk_upload.check_size('SICD2',T.SECONDARY_ICD_CODE2) NOT IN ('SIZE_ISSUE','INVALID','NA') AND claim_bulk_upload.validate_data('ICD',T.SECONDARY_ICD_CODE2) = 0 THEN 'Sec ICD2 invalid; ' ELSE NULL END ||  
       CASE WHEN T.SECONDARY_ICD_CODE3 IS NOT NULL AND claim_bulk_upload.check_size('SICD3',T.SECONDARY_ICD_CODE3) NOT IN ('SIZE_ISSUE','INVALID','NA') AND claim_bulk_upload.validate_data('ICD',T.SECONDARY_ICD_CODE3) = 0 THEN 'Sec ICD3 invalid; ' ELSE NULL END ||
       CASE WHEN T.SECONDARY_ICD_CODE4 IS NOT NULL AND claim_bulk_upload.check_size('SICD4',T.SECONDARY_ICD_CODE4) NOT IN ('SIZE_ISSUE','INVALID','NA') AND claim_bulk_upload.validate_data('ICD',T.SECONDARY_ICD_CODE4) = 0 THEN 'Sec ICD4 invalid; ' ELSE NULL END ||  
       CASE WHEN T.SECONDARY_ICD_CODE5 IS NOT NULL AND claim_bulk_upload.check_size('SICD5',T.SECONDARY_ICD_CODE5) NOT IN ('SIZE_ISSUE','INVALID','NA') AND claim_bulk_upload.validate_data('ICD',T.SECONDARY_ICD_CODE5) = 0 THEN 'Sec ICD5 invalid; ' ELSE NULL END ||
       */
       
       CASE WHEN T.SECONDARY_ICD_CODE1 IS NOT NULL AND claim_bulk_upload.check_size('SICD1',T.SECONDARY_ICD_CODE1) NOT IN ('SIZE_ISSUE','INVALID','NA') AND S1AM.ICD_SEQ_ID IS NULL AND S1I.ICD10_SEQ_ID IS NULL THEN 'Sec ICD1 invalid; ' ELSE NULL END ||
       CASE WHEN T.SECONDARY_ICD_CODE2 IS NOT NULL AND claim_bulk_upload.check_size('SICD2',T.SECONDARY_ICD_CODE2) NOT IN ('SIZE_ISSUE','INVALID','NA') AND S2AM.ICD_SEQ_ID IS NULL AND S2I.ICD10_SEQ_ID IS NULL THEN 'Sec ICD2 invalid; ' ELSE NULL END ||  
       CASE WHEN T.SECONDARY_ICD_CODE3 IS NOT NULL AND claim_bulk_upload.check_size('SICD3',T.SECONDARY_ICD_CODE3) NOT IN ('SIZE_ISSUE','INVALID','NA') AND S3AM.ICD_SEQ_ID IS NULL AND S3I.ICD10_SEQ_ID IS NULL THEN 'Sec ICD3 invalid; ' ELSE NULL END ||
       CASE WHEN T.SECONDARY_ICD_CODE4 IS NOT NULL AND claim_bulk_upload.check_size('SICD4',T.SECONDARY_ICD_CODE4) NOT IN ('SIZE_ISSUE','INVALID','NA') AND S4AM.ICD_SEQ_ID IS NULL AND S4I.ICD10_SEQ_ID IS NULL THEN 'Sec ICD4 invalid; ' ELSE NULL END ||  
       CASE WHEN T.SECONDARY_ICD_CODE5 IS NOT NULL AND claim_bulk_upload.check_size('SICD5',T.SECONDARY_ICD_CODE5) NOT IN ('SIZE_ISSUE','INVALID','NA') AND S5AM.ICD_SEQ_ID IS NULL AND S5I.ICD10_SEQ_ID IS NULL THEN 'Sec ICD5 invalid; ' ELSE NULL END ||
         
       
       CASE WHEN rec_xml_claim_info.source_type!='PBCL' THEN CASE WHEN T.FIRST_INCIDENT_DATE IS NOT NULL AND claim_bulk_upload.check_data_type('DT',T.FIRST_INCIDENT_DATE) IS NULL THEN 'First incident date is invalid; ' ELSE NULL END ELSE NULL END ||    
       CASE WHEN rec_xml_claim_info.source_type!='PBCL' THEN CASE WHEN T.FIRST_REPORTED_DATE IS NOT NULL AND claim_bulk_upload.check_data_type('DT',T.FIRST_REPORTED_DATE) IS NULL THEN 'First reported date is invalid; ' ELSE NULL END ELSE NULL END ||
       
       
       
       CASE WHEN rec_xml_claim_info.source_type!='PBCL' THEN CASE WHEN T.SERVICE_DATE IS NULL THEN 'Service date is blank; ' ELSE NULL END ELSE NULL END||
       CASE WHEN rec_xml_claim_info.source_type!='PBCL' THEN CASE WHEN T.SERVICE_DATE IS NOT NULL AND claim_bulk_upload.check_data_type('DT',T.SERVICE_DATE) IS NULL THEN 'Service date is invalid; ' ELSE NULL END ELSE NULL END||
       CASE WHEN rec_xml_claim_info.source_type!='PBCL' THEN CASE WHEN T.SERVICE_DATE IS NOT NULL AND claim_bulk_upload.check_data_type('DT',T.SERVICE_DATE) IS NOT NULL AND TRUNC(TO_DATE(T.SERVICE_DATE,'DD/MM/YYYY')) > TRUNC(SYSDATE) THEN 'Future service date not allowed; ' ELSE NULL END ELSE NULL END||
       
       
       CASE WHEN T.ACTIVITY_TYPE IS NULL THEN 'Activity type is blank; ' ELSE NULL END ||
       CASE WHEN T.ACTIVITY_TYPE IS NOT NULL THEN CASE claim_bulk_upload.check_size('ACT',T.ACTIVITY_TYPE) WHEN 'SIZE_ISSUE' THEN 'Activity type is invalid/size exceeded; ' WHEN 'INVALID' THEN 'Activity typ is invalid; ' WHEN 'NA' THEN 'Activity typ is invalid; 'ELSE NULL END ELSE NULL END ||
       
       CASE WHEN T.INTERNAL_SERVICE_CODE IS NULL AND T.ACTIVITY_TYPE IS NOT NULL AND claim_bulk_upload.check_size('ACT',T.ACTIVITY_TYPE) IN ('ACT') THEN 'Internal code is required; ' ELSE NULL END || 
       --CASE WHEN T.INTERNAL_SERVICE_CODE IS NOT NULL AND claim_bulk_upload.check_size('ACT',T.ACTIVITY_TYPE) IN ('ACT') AND claim_bulk_upload.validate_data('INT_CODE',T.INTERNAL_SERVICE_CODE,T.HOSP_SEQ_ID,T.SERVICE_DATE) = 0 THEN 'Internal code not valid as per tariff date/data; ' ELSE NULL END ||      
       
       /*CASE WHEN T.INTERNAL_SERVICE_CODE IS NOT NULL AND claim_bulk_upload.check_size('ACT',T.ACTIVITY_TYPE) IN ('ACT') 
                 AND (SELECT COUNT(1) 
                      FROM TPA_HOSP_TARIFF_DETAILS TA
                      JOIN TPA_ACTIVITY_MASTER_DETAILS M ON (TA.ACTIVITY_SEQ_ID=M.ACT_MAS_DTL_SEQ_ID)
                      where tA.hosp_seq_id = T.HOSP_SEQ_ID
                      AND (TA.INTERNAL_CODE) = T.INTERNAL_SERVICE_CODE
                      AND ((TA.END_DATE IS NOT NULL AND TO_DATE(T.SERVICE_DATE, 'DD-MM-RRRR') BETWEEN TRUNC(TA.START_DATE) AND TRUNC(TA.END_DATE)) OR
                          (TA.END_DATE IS NULL AND TO_DATE(T.SERVICE_DATE, 'DD-MM-RRRR') >= TRUNC(TA.START_DATE) ))) = 0
            THEN 'Internal code not valid as per tariff date/data; ' ELSE NULL END ||*/ 
       
       CASE WHEN T.ACTIVITY_TYPE IS NOT NULL AND T.INTERNAL_SERVICE_CODE IS NOT NULL AND claim_bulk_upload.check_size('ACT',T.ACTIVITY_TYPE) IN ('ACT') AND claim_bulk_upload.validate_data('CHK_ACT', T.INTERNAL_SERVICE_CODE, T.HOSP_SEQ_ID) = 0 AND claim_bulk_upload.validate_data('CHK_INTCODE', T.INTERNAL_SERVICE_CODE, T.HOSP_SEQ_ID) >0  THEN 'Activity type and internal code mismatch with provider tariff, please select Activity type as Drug' ELSE NULL END||
       
       CASE WHEN T.ACTIVITY_TYPE IS NOT NULL AND T.INTERNAL_SERVICE_CODE IS NOT NULL AND claim_bulk_upload.check_size('ACT',T.ACTIVITY_TYPE) IN ('ACT') AND claim_bulk_upload.validate_data('CHK_ACT', T.INTERNAL_SERVICE_CODE, T.HOSP_SEQ_ID) = 0 AND claim_bulk_upload.validate_data('CHK_INTCODE', T.INTERNAL_SERVICE_CODE, T.HOSP_SEQ_ID)=0  THEN 'Internal code is Invalid' ELSE NULL END||
      
      
      CASE WHEN rec_xml_claim_info.source_type!='PBCL' THEN CASE WHEN T.ACTIVITY_TYPE IS NOT NULL AND T.INTERNAL_SERVICE_CODE IS NOT NULL AND claim_bulk_upload.check_size('DRG',T.ACTIVITY_TYPE) IN ('DRG') AND claim_bulk_upload.validate_data('CHK_PHARMA', T.INTERNAL_SERVICE_CODE, T.HOSP_SEQ_ID) = 0  AND claim_bulk_upload.validate_data('CHK_INTCODE', T.INTERNAL_SERVICE_CODE, T.HOSP_SEQ_ID) >0 THEN 'Activity type and internal code mismatch with provider tariff, please select Activity type as Activity; ' ELSE NULL END ELSE NULL END||
      
      CASE WHEN rec_xml_claim_info.source_type='PBCL'  THEN  CASE WHEN T.ACTIVITY_TYPE IS NOT NULL AND T.INTERNAL_SERVICE_CODE IS NOT NULL AND claim_bulk_upload.check_size('DRG',T.ACTIVITY_TYPE) IN ('DRG') AND claim_bulk_upload.validate_data('CHK_PBM_PHARMA', T.INTERNAL_SERVICE_CODE, T.HOSP_SEQ_ID) = 0  AND claim_bulk_upload.validate_data('CHK_INTCODE', T.INTERNAL_SERVICE_CODE, T.HOSP_SEQ_ID) >0 THEN 'Activity type and internal code mismatch with provider tariff ; ' ELSE NULL END ELSE NULL END||
      
       --CASE WHEN T.INTERNAL_SERVICE_CODE IS NOT NULL THEN CASE claim_bulk_upload.check_size('INTCD',T.INTERNAL_SERVICE_CODE) WHEN 'SIZE_ISSUE' THEN 'Internal code is invalid/size exceeded; ' WHEN 'INVALID' THEN 'Internal code is invalid; ' WHEN 'NA' THEN 'Internal code is invalid; ' ELSE NULL END ELSE NULL END ||
          
       CASE WHEN rec_xml_claim_info.source_type!='PBCL' THEN CASE WHEN T.SERVICE_DESCRIPTION IS NULL THEN 'Service desc is blank; ' ELSE NULL END ELSE NULL END||
       
       CASE WHEN rec_xml_claim_info.source_type='PBCL' THEN CASE WHEN T.SERVICE_DESCRIPTION IS NULL THEN 'Drug description is blank; ' ELSE NULL END ELSE NULL END|| 
       
       
       CASE WHEN rec_xml_claim_info.source_type!='PBCL' THEN CASE WHEN claim_bulk_upload.check_size('ACT',T.ACTIVITY_TYPE) IN ('DRG') AND T.CPT_CODE IS NOT NULL AND PH.ACTIVITY_CODE IS NULL THEN 'CPT code invalid; ' ELSE NULL END ELSE NULL END ||
        
       CASE WHEN T.AMOUNT_CLAIMED IS NULL THEN 'Claimed amount is blank; ' ELSE NULL END ||
       CASE WHEN T.AMOUNT_CLAIMED IS NOT NULL THEN CASE claim_bulk_upload.check_size('REQ',T.AMOUNT_CLAIMED) WHEN 'SIZE_ISSUE' THEN 'Claim amount is invalid/size exceeded; ' WHEN 'INVALID' THEN 'Claim amount is invalid; ' WHEN 'NA' THEN 'Claim amount is invalid; ' ELSE NULL END ELSE NULL END ||
                                                        
       CASE WHEN T.QUANTITY IS NULL THEN 'Quantity is blank; ' ELSE NULL END ||                                              
       CASE WHEN T.QUANTITY IS NOT NULL THEN CASE claim_bulk_upload.check_size('QNT',T.QUANTITY) WHEN 'SIZE_ISSUE' THEN 'Quantity is invalid/size exceeded; ' WHEN 'INVALID' THEN 'Quantity is invalid; ' WHEN 'NA' THEN 'Quantity is invalid; ' ELSE NULL END ELSE NULL END ||                                              
       CASE WHEN T.QUANTITY IS NOT NULL AND T.QUANTITY = '0' THEN 'Quantity should be greater then zero; ' ELSE NULL END || 
       
       CASE WHEN T.OBSERVATION IS NULL THEN 'Observation is blank; ' ELSE NULL END ||
       CASE WHEN T.OBSERVATION IS NOT NULL THEN CASE claim_bulk_upload.check_size('OBS',T.OBSERVATION) WHEN 'SIZE_ISSUE' THEN 'Observation is invalid/size exceeded; ' WHEN 'INVALID' THEN 'Observation is invalid; ' WHEN 'NA' THEN 'Observation is invalid; ' ELSE NULL END ELSE NULL END ||
       
       
       CASE WHEN rec_xml_claim_info.source_type!='PBCL' THEN CASE WHEN T.DATE_OF_LMP IS NOT NULL AND claim_bulk_upload.check_data_type('DT',T.DATE_OF_LMP) IS NULL THEN 'LMP date is invalid; ' ELSE NULL END ELSE NULL END || 
       --CASE WHEN T.DATE_OF_LMP IS NULL AND claim_bulk_upload.get_benf_type_id(T.BENEFIT_TYPE) IN ('IMTI','OMTI') AND T.PREAPPROVAL_NO IS NULL THEN 'LMP date is required; ' ELSE NULL END||
       --CASE WHEN T.DATE_OF_LMP IS NOT NULL AND T.PREAPPROVAL_NO IS NOT NULL AND claim_bulk_upload.validate_data('LMP_DATE', T.PREAPPROVAL_NO, T.DATE_OF_LMP) IS NULL THEN 'LMP date mismatch in pre-approval; ' ELSE NULL END || -- CR 0198
       
       CASE WHEN T.PREAPPROVAL_NO IS NOT NULL AND PA.PRE_AUTH_NUMBER IS NULL THEN 'Pre-approval not available; ' ELSE NULL END  ||
       CASE WHEN T.PREAPPROVAL_NO IS NOT NULL AND PA.PRE_AUTH_NUMBER IS NOT NULL AND PAPR.PRE_AUTH_NUMBER IS NULL THEN 'Pre-approval is not approved; ' ELSE NULL END  ||
        
       CASE WHEN rec_xml_claim_info.source_type!='PBCL' THEN CASE WHEN T.PREAPPROVAL_NO IS NOT NULL AND PA.PRE_AUTH_NUMBER IS NOT NULL AND PHSP.PRE_AUTH_NUMBER IS NULL THEN 'Provider mismatch in Pre-approval; ' ELSE NULL END ELSE NULL END||
        
       CASE WHEN rec_xml_claim_info.source_type='PBCL' THEN CASE WHEN T.PREAPPROVAL_NO IS NOT NULL AND PA.PRE_AUTH_NUMBER IS NOT NULL AND PBMP.PRE_AUTH_NUMBER IS NULL THEN  'pre-approval number not belongs to PBM; ' ELSE NULL END ELSE NULL END||
       CASE WHEN rec_xml_claim_info.source_type='PBCL' THEN CASE WHEN T.PREAPPROVAL_NO IS NOT NULL AND PA.PRE_AUTH_NUMBER IS NOT NULL AND PHSP.PRE_AUTH_NUMBER IS NULL THEN 'PBM mismatch in Pre-approval; ' ELSE NULL END ELSE NULL END||  
       
       CASE WHEN T.PREAPPROVAL_NO IS NOT NULL AND PA.PRE_AUTH_NUMBER IS NOT NULL AND CA.CLAIM_NUMBER IS NOT NULL THEN 'Pre-approval already linked to other claim'||'(i.e. '||CA.CLAIM_NUMBER||'); ' ELSE NULL END  ||
       CASE WHEN T.PREAPPROVAL_NO IS NOT NULL AND (SELECT COUNT(1) FROM app.CLM_BULK_UPLD_XML_DTA d 
                                                                JOIN APP.CLM_BULK_UPLD_XML_DETAILS xd on (d.xml_seq_id=xd.xml_seq_id)
                                                                WHERE  XD.Preapproval_No = T.Preapproval_No and d.tot_rec_cnt=d.success_cnt
                                                               ) > 0
              THEN 'Pre-approval already linked to other claim;' ELSE NULL END ||
         
       CASE WHEN T.EVENT_REF_NO IS NOT NULL AND T.PREAPPROVAL_NO IS NOT NULL AND PA.PRE_AUTH_NUMBER IS NOT NULL AND PEVT.PRE_AUTH_NUMBER IS NULL THEN 'Event no. mismatch in pre-approval; ' ELSE NULL END ||
       CASE WHEN T.EVENT_REF_NO IS NOT NULL AND T.PREAPPROVAL_NO IS NOT NULL AND PA.PRE_AUTH_NUMBER IS NOT NULL THEN CASE claim_bulk_upload.check_size('EVNT',T.EVENT_REF_NO) WHEN 'SIZE_ISSUE' THEN 'Event ref no is invalid/size exceeded; ' WHEN 'INVALID' THEN 'Event ref no is invalid; ' WHEN 'NA' THEN 'Event ref no is invalid; ' ELSE NULL END ELSE NULL END ||
       
         
       CASE WHEN rec_xml_claim_info.source_type!='PBCL' THEN CASE WHEN T.NATURE_OF_CONCEPTION IS NOT NULL AND T.PREAPPROVAL_NO IS NULL THEN CASE claim_bulk_upload.check_size('CONP',T.NATURE_OF_CONCEPTION) WHEN 'SIZE_ISSUE' THEN 'Nat of Concep is invalid/size exceeded; ' WHEN 'INVALID' THEN 'Nat of Concep is invalid; ' WHEN 'NA' THEN 'Nat of Concep is invalid; ' ELSE NULL END ELSE NULL END ELSE NULL END || 
       --CASE WHEN rec_xml_claim_info.source_type!='PBCL' THEN CASE WHEN T.NATURE_OF_CONCEPTION IS NOT NULL AND T.PREAPPROVAL_NO IS NOT NULL THEN CASE WHEN claim_bulk_upload.validate_data('CONCEPTION_TYPE', T.PREAPPROVAL_NO, T.NATURE_OF_CONCEPTION) = 0 THEN 'Nat of Concep mismatch with Pre-approval; ' ELSE NULL END ELSE NULL END ELSE NULL END || -- CR 0198
       
       
       CASE WHEN rec_xml_claim_info.source_type!='PBCL' THEN CASE WHEN T.TOOTH_NUMBER IS NOT NULL THEN CASE claim_bulk_upload.check_size('TNO',T.TOOTH_NUMBER) WHEN 'SIZE_ISSUE' THEN 'Tooth no is invalid/size exceeded; ' WHEN 'INVALID' THEN 'Tooth no is invalid; ' WHEN 'NA' THEN 'Tooth no should be alpha numeric; ' ELSE NULL END ELSE NULL END ELSE NULL END || 
       
       --CASE WHEN UPPER(T.ACTIVITY_TYPE) = 'ACTIVITY' AND T.INTERNAL_SERVICE_CODE IS NULL THEN 'Internal servc code is blank; ' ELSE NULL END ||  
       --CASE WHEN T.EVENT_REF_NO IS NOT NULL AND REGEXP_COUNT(T.EVENT_REF_NO, '[^[:digit:]]') > 0 THEN 'Event no. should be number format; ' ELSE NULL END ||
       --CASE WHEN T.EVENT_REF_NO IS NOT NULL AND length(T.EVENT_REF_NO) != 7 THEN 'Event no should be 7 digits; ' ELSE NULL END ||
       --CASE WHEN T.EVENT_REF_NO IS NOT NULL AND validate_data('EVNT_DUPL_CLM',T.EVENT_REF_NO) > 0 THEN 'Event no. already linked with other claim; ' ELSE NULL END ||
       --CASE WHEN T.EVENT_REF_NO IS NOT NULL AND REGEXP_COUNT(T.EVENT_REF_NO, '[^[:digit:]]') = 0 AND T.EVENT_REF_NO > validate_data('EVNT_NO',T.EVENT_REF_NO) THEN 'Event no invalid; ' ELSE NULL END ||
       --CASE WHEN T.ACTIVITY_TYPE IS NOT NULL AND LOWER(T.ACTIVITY_TYPE) = 'activity' AND validate_data('CPT',T.CPT_CODE) = 0 THEN 'Invalid  activity code; ' ELSE NULL END ||
        
       
       CASE WHEN rec_xml_claim_info.source_type='PBCL' THEN CASE WHEN T.MOPH_CODES IS NOT NULL THEN CASE WHEN claim_bulk_upload.validate_data('MOPH_CODES',T.MOPH_CODES)=0 THEN 'MOPH Code is not available;' ELSE NULL END ELSE NULL END ELSE NULL END||
       CASE WHEN rec_xml_claim_info.source_type='PBCL' THEN CASE WHEN T.DUR_MEDI IS NOT NULL THEN CASE claim_bulk_upload.check_size('DUR_MEDI',T.DUR_MEDI) WHEN 'SIZE_ISSUE' THEN 'Duration of medication invalid/size exceeded; ' WHEN 'INVALID' THEN 'Duration of medication invalid; ' WHEN 'NA' THEN 'Duration of medication invalid-should be numeric; ' ELSE NULL END ELSE 'Duration of medication is blank; ' END ELSE NULL END||
       CASE WHEN rec_xml_claim_info.source_type='PBCL' THEN CASE WHEN T.UNIT_TYPE IS NULL THEN 'UNIT TYPE is blank; ' else null end ELSE NULL END||
       CASE WHEN rec_xml_claim_info.source_type='PBCL' THEN CASE WHEN T.S_NO IS NULL THEN 'S_NO is blank; ' ELSE NULL END ELSE NULL END||
       CASE WHEN rec_xml_claim_info.source_type='PBCL' THEN CASE WHEN T.S_NO IS NOT NULL AND (SELECT COUNT(1) FROM app.CLM_BULK_UPLD_XML_DETAILS clm WHERE CLM.S_NO IS NOT NULL AND clm.S_NO=T.S_NO AND clm.xml_seq_id=t.xml_seq_id)>1 THEN 'S_NO should not be duplicate; ' else null end ELSE NULL END||
       --CASE WHEN T.BENEFIT_TYPE IS NOT NULL AND TRIM(UPPER(T.BENEFIT_TYPE)) NOT IN ('OUT PATIENT') THEN 'Invalid benifit type; ' ELSE NULL END||
       CASE WHEN rec_xml_claim_info.source_type='PBCL' THEN CASE WHEN T.MED_TYPE IS NOT NULL AND TRIM(UPPER(T.MED_TYPE)) NOT IN('ALLOPATHY') THEN 'Invalid system of medicine; ' ELSE NULL END ELSE NULL END||
       --CASE WHEN T.ENCOUNTER_TYPE IS NOT NULL AND TRIM(UPPER(T.ENCOUNTER_TYPE)) NOT IN ('OP NO-EMERGENCY') THEN 'Invalid encounter type: ' ELSE NULL END||
       CASE WHEN rec_xml_claim_info.source_type='PBCL' THEN CASE WHEN T.UNIT_TYPE IS NOT NULL AND TRIM(UPPER(T.UNIT_TYPE)) NOT IN('LOOSE','PACKAGE') THEN 'Invalid Unit type; ' ELSE NULL END ELSE NULL END
            
       
       AS REMARKS,
          --###############
        CASE WHEN T.BENEFIT_TYPE IS NOT NULL THEN 
             CASE WHEN claim_bulk_upload.check_size('BNF',T.BENEFIT_TYPE) NOT IN ('SIZE_ISSUE','INVALID','NA') THEN
                       claim_bulk_upload.check_size('BNF',T.BENEFIT_TYPE) ELSE NULL END
             ELSE NULL END   AS BENF_TPY_ID,  
        
        CASE WHEN T.ENCOUNTER_TYPE IS NOT NULL THEN 
             CASE WHEN claim_bulk_upload.check_size('ENCTR',T.ENCOUNTER_TYPE,T.BENEFIT_TYPE) NOT IN ('SIZE_ISSUE','INVALID','NA') THEN
                       claim_bulk_upload.check_size('ENCTR',T.ENCOUNTER_TYPE,T.BENEFIT_TYPE) ELSE NULL END
             ELSE NULL END   AS ENCNTR_TYPE_ID,
        CASE WHEN T.MED_TYPE IS NOT NULL THEN 
             CASE WHEN claim_bulk_upload.check_size('SYS',T.MED_TYPE) NOT IN ('SIZE_ISSUE','INVALID','NA') THEN
                       claim_bulk_upload.check_size('SYS',T.MED_TYPE) ELSE NULL END
             ELSE NULL END   AS SOM_TPY_ID,   
        CASE WHEN T.NATURE_OF_CONCEPTION IS NOT NULL THEN 
             CASE WHEN claim_bulk_upload.check_size('CONP',T.NATURE_OF_CONCEPTION) NOT IN ('SIZE_ISSUE','INVALID','NA') THEN
                       claim_bulk_upload.check_size('CONP',T.NATURE_OF_CONCEPTION) ELSE NULL END
             ELSE NULL END   AS NAT_CONCP_TPY_ID,  
        CASE WHEN T.ACTIVITY_TYPE IS NOT NULL THEN 
             CASE WHEN claim_bulk_upload.check_size('ACT',T.ACTIVITY_TYPE) NOT IN ('SIZE_ISSUE','INVALID','NA') THEN
                       claim_bulk_upload.check_size('ACT',T.ACTIVITY_TYPE) ELSE NULL END
             ELSE NULL END   AS ACT_TPY_ID
                                 
 FROM APP.CLM_BULK_UPLD_XML_DETAILS T
 LEFT OUTER JOIN APP.TPA_PHARMACY_MASTER_DETAILS PH ON (T.CPT_CODE=PH.ACTIVITY_CODE)
 LEFT OUTER JOIN APP.PAT_AUTHORIZATION_DETAILS PA ON (T.PREAPPROVAL_NO=PA.PRE_AUTH_NUMBER AND PA.PAT_ENHANCED_YN = 'N')  -----NEWLY ADDED FOR PREAUTH ENHANCEMENT
 LEFT OUTER JOIN APP.PAT_AUTHORIZATION_DETAILS PAPR ON (T.PREAPPROVAL_NO=PAPR.PRE_AUTH_NUMBER AND PAPR.PAT_STATUS_TYPE_ID = 'APR' AND PAPR.PAT_ENHANCED_YN = 'N')-----NEWLY ADDED FOR PREAUTH ENHANCEMENT
 LEFT OUTER JOIN APP.PAT_AUTHORIZATION_DETAILS PHSP ON (T.PREAPPROVAL_NO=PHSP.PRE_AUTH_NUMBER AND PHSP.HOSP_SEQ_ID = T.HOSP_SEQ_ID AND PHSP.PAT_ENHANCED_YN = 'N')-----NEWLY ADDED FOR PREAUTH ENHANCEMENT
 LEFT OUTER JOIN APP.PAT_AUTHORIZATION_DETAILS PMEM ON (T.PREAPPROVAL_NO=PMEM.PRE_AUTH_NUMBER AND PMEM.TPA_ENROLLMENT_ID = T.MEMBER_ID AND PMEM.PAT_ENHANCED_YN = 'N')-----NEWLY ADDED FOR PREAUTH ENHANCEMENT
 LEFT OUTER JOIN APP.PAT_AUTHORIZATION_DETAILS PEVT ON (T.PREAPPROVAL_NO=PEVT.PRE_AUTH_NUMBER AND PEVT.EVENT_NO = T.EVENT_REF_NO AND PEVT.PAT_ENHANCED_YN = 'N')-----NEWLY ADDED FOR PREAUTH ENHANCEMENT
 LEFT OUTER JOIN APP.PAT_AUTHORIZATION_DETAILS PBMP ON (T.PREAPPROVAL_NO=PBMP.PRE_AUTH_NUMBER AND PBMP.PBM_YN ='Y')
 LEFT OUTER JOIN APP.CLM_AUTHORIZATION_DETAILS CA ON (PA.PAT_AUTH_SEQ_ID=CA.PAT_AUTH_SEQ_ID)
 LEFT OUTER JOIN APP.TPA_ICD_AM_DETAILS PAM ON (PAM.ICD_AM = T.PRINCIPAL_ICD)
 LEFT OUTER JOIN APP.TPA_ICD10_MASTER_DETAILS PI ON (PI.ICD_CODE = T.PRINCIPAL_ICD)
 LEFT OUTER JOIN APP.TPA_ICD_AM_DETAILS S1AM ON (S1AM.ICD_AM = T.SECONDARY_ICD_CODE1)
 LEFT OUTER JOIN APP.TPA_ICD10_MASTER_DETAILS S1I ON (S1I.ICD_CODE = T.SECONDARY_ICD_CODE1)
 LEFT OUTER JOIN APP.TPA_ICD_AM_DETAILS S2AM ON (S2AM.ICD_AM = T.SECONDARY_ICD_CODE2)
 LEFT OUTER JOIN APP.TPA_ICD10_MASTER_DETAILS S2I ON (S2I.ICD_CODE = T.SECONDARY_ICD_CODE2)
 LEFT OUTER JOIN APP.TPA_ICD_AM_DETAILS S3AM ON (S3AM.ICD_AM = T.SECONDARY_ICD_CODE3)
 LEFT OUTER JOIN APP.TPA_ICD10_MASTER_DETAILS S3I ON (S3I.ICD_CODE = T.SECONDARY_ICD_CODE3)
 LEFT OUTER JOIN APP.TPA_ICD_AM_DETAILS S4AM ON (S4AM.ICD_AM = T.SECONDARY_ICD_CODE4)
 LEFT OUTER JOIN APP.TPA_ICD10_MASTER_DETAILS S4I ON (S4I.ICD_CODE = T.SECONDARY_ICD_CODE4)
 LEFT OUTER JOIN APP.TPA_ICD_AM_DETAILS S5AM ON (S5AM.ICD_AM = T.SECONDARY_ICD_CODE5)
 LEFT OUTER JOIN APP.TPA_ICD10_MASTER_DETAILS S5I ON (S5I.ICD_CODE = T.SECONDARY_ICD_CODE5)
 LEFT OUTER JOIN APP.TPA_ICD10_MASTER_DETAILS DAM ON (PAM.ICD_CM=DAM.ICD_CODE AND DAM.BENEFIT_TYPE = 'DNTL')
 LEFT OUTER JOIN APP.TPA_ICD10_MASTER_DETAILS D10 ON (D10.ICD_CODE = T.PRINCIPAL_ICD AND D10.BENEFIT_TYPE = 'DNTL')
 LEFT OUTER JOIN APP.TPA_ICD_CODES TIC ON (TIC.ICD_CODE=T.PRINCIPAL_ICD)
 WHERE T.XML_SEQ_ID = V_XML_SEQ_ID; 


CURSOR cur_clm_data_vld IS
SELECT T.CLM_RAW_DTA_SEQ_ID,T.XML_SEQ_ID,T.INVOICE_NO,T.MEMBER_ID,NVL(T.PREAPPROVAL_NO,'BLANK') AS PREAPPROVAL_NO,
                   T.DATE_TREATMENT,T.DATE_DISCHARGE,T.SOM_TPY_ID,T.BENF_TPY_ID,
                   T.ENCNTR_TYPE_ID,T.PRINCIPAL_ICD,T.NAT_CONCP_TPY_ID,T.DATE_OF_LMP
            FROM APP.CLM_BULK_UPLD_XML_DETAILS T
            WHERE T.XML_SEQ_ID = V_XML_SEQ_ID
              AND T.INVOICE_NO IN (SELECT CL.INVOICE_NO
                                   FROM APP.CLM_BULK_UPLD_XML_DETAILS CL
                                   WHERE XML_SEQ_ID = V_XML_SEQ_ID
                                   GROUP BY CL.INVOICE_NO
                                   HAVING COUNT(1)> 1);
                                   
CURSOR cur_clm_pat_vld IS
SELECT T.CLM_RAW_DTA_SEQ_ID,T.XML_SEQ_ID,T.INVOICE_NO,T.MEMBER_ID,NVL(T.PREAPPROVAL_NO,'BLANK') AS PREAPPROVAL_NO,
                   T.DATE_TREATMENT,T.DATE_DISCHARGE,T.SOM_TPY_ID,T.BENF_TPY_ID,
                   T.ENCNTR_TYPE_ID,T.PRINCIPAL_ICD,T.NAT_CONCP_TPY_ID,T.DATE_OF_LMP
            FROM APP.CLM_BULK_UPLD_XML_DETAILS T
            WHERE T.PREAPPROVAL_NO IN (SELECT CL.PREAPPROVAL_NO
                                       FROM APP.CLM_BULK_UPLD_XML_DETAILS CL
                                       WHERE CL.PREAPPROVAL_NO IS NOT NULL
                                       AND XML_SEQ_ID = V_XML_SEQ_ID
                                       GROUP BY CL.PREAPPROVAL_NO
                                       HAVING COUNT(1)> 1)
            AND XML_SEQ_ID = V_XML_SEQ_ID;

CURSOR cur_pbm_clm_date_vld IS                                               
SELECT T.CLM_RAW_DTA_SEQ_ID,T.XML_SEQ_ID,T.INVOICE_NO,T.MEMBER_ID,NVL(T.PREAPPROVAL_NO,'BLANK') AS PREAPPROVAL_NO,
                   T.DATE_TREATMENT,T.DATE_DISCHARGE,T.SOM_TPY_ID,T.BENF_TPY_ID,
                   T.ENCNTR_TYPE_ID,T.PRINCIPAL_ICD,T.NAT_CONCP_TPY_ID,T.DATE_OF_LMP,T.TRTMNT_DT_ISSUE_YN
           FROM APP.CLM_BULK_UPLD_XML_DETAILS T
           WHERE XML_SEQ_ID = V_XML_SEQ_ID AND (T.PREAPPROVAL_NO) IN(SELECT CL.PREAPPROVAL_NO
                                                       FROM APP.CLM_BULK_UPLD_XML_DETAILS CL
                                                       WHERE CL.PREAPPROVAL_NO IS NOT NULL
                                                       AND XML_SEQ_ID = V_XML_SEQ_ID
                                                       GROUP BY CL.PREAPPROVAL_NO
                                                       HAVING COUNT(1)> 1);
                                                       
TYPE typ_clm_data IS TABLE OF  cur_mand_valdion%ROWTYPE INDEX BY PLS_INTEGER;
rec_clm_remarks       typ_clm_data;
								   
TYPE typ_clm_data_vld IS TABLE OF  cur_clm_data_vld%ROWTYPE INDEX BY PLS_INTEGER;
rec_clm_data_vld       typ_clm_data_vld;		

TYPE typ_pbm_clm_vld IS TABLE OF cur_pbm_clm_date_vld%ROWTYPE INDEX BY PLS_INTEGER;
rec_pbm_clm_vld        typ_pbm_clm_vld;

   
          
  v_sql_code                              varchar2(100);
  v_sql_msg                               varchar2(4000);
  
 BEGIN
   
 --SELECT XML_DATA INTO v_xmldoc FROM APP.TEMP T WHERE T.SL_NO = 1;
/* DELETE FROM APP.CLM_BULK_UPLD_XML_DTA;
 DELETE FROM APP.CLM_BULK_UPLD_XML_DETAILS;
 DELETE FROM APP.CLM_BULK_UPLD_CLM_DETAILS;
 DELETE FROM APP.CLM_BULK_UPLD_DIAG_DETAILS;
 DELETE FROM APP.CLM_BULK_UPLD_ACT_DETAILS;
 
UPDATE APP.CLM_BULK_UPLD_XML_DETAILS T
        SET T.REMARKS = NULL,
            T.PAT_ISSUE_YN = NULL,
            T.MEM_ID_ISSUE_YN = NULL,
            T.TRTMNT_DT_ISSUE_YN = NULL,
            T.DIS_DT_ISSUE_YN = NULL,
            T.SOM_ISSUE_YN = NULL,
            T.BENF_ID_ISSUE_YN = NULL,
            T.ENC_TYP_ID_ISSUE_YN = NULL,
            T.PRY_ICD_ISSUE_YN = NULL,
            t.batch_seq_id = 1;
commit;            
*/
            
 OPEN  cur_xml_claim_info;
 FETCH cur_xml_claim_info INTO rec_xml_claim_info;
 CLOSE cur_xml_claim_info;
 
 
 


 v_start_time:= dbms_utility.get_time;

 OPEN  cur_mand_valdion;
 LOOP 
   FETCH cur_mand_valdion BULK COLLECT INTO rec_clm_remarks LIMIT 2000;
   EXIT WHEN rec_clm_remarks.COUNT = 0;
   
 FORALL i IN 1..rec_clm_remarks.COUNT 
     UPDATE APP.CLM_BULK_UPLD_XML_DETAILS T
        SET T.REMARKS          = rec_clm_remarks(i).remarks,
            T.SOM_TPY_ID       = rec_clm_remarks(i).SOM_TPY_ID,
            T.BENF_TPY_ID      = rec_clm_remarks(i).BENF_TPY_ID,
            T.ENCNTR_TYPE_ID   = rec_clm_remarks(i).ENCNTR_TYPE_ID,
            T.NAT_CONCP_TPY_ID = rec_clm_remarks(i).NAT_CONCP_TPY_ID,
            T.ACT_TPY_ID       = rec_clm_remarks(i).ACT_TPY_ID,
            T.UPDATED_DATE     = SYSDATE
     WHERE T.CLM_RAW_DTA_SEQ_ID = rec_clm_remarks(i).CLM_RAW_DTA_SEQ_ID;
     
  END LOOP;
  CLOSE cur_mand_valdion;

 save_time_details(v_xml_seq_id,'MAND_VALD',v_start_time);
 
v_start_time:= dbms_utility.get_time;

  --------------INVOICE WISE SAME CASE
  OPEN  cur_clm_data_vld;
  LOOP
  FETCH cur_clm_data_vld BULK COLLECT INTO rec_clm_data_vld LIMIT 2000;
   EXIT WHEN rec_clm_data_vld.COUNT = 0;
  
  FORALL I IN 1..rec_clm_data_vld.COUNT 
     UPDATE APP.CLM_BULK_UPLD_XML_DETAILS T
        SET T.REMARKS = T.REMARKS||'pre-approval not matching with invoice no. '||rec_clm_data_vld(i).invoice_no||';',
            T.PAT_ISSUE_YN = 'Y',
            T.UPDATED_DATE     = SYSDATE
     WHERE T.XML_SEQ_ID = rec_clm_data_vld(i).XML_SEQ_ID
       AND T.INVOICE_NO = rec_clm_data_vld(i).INVOICE_NO 
       AND T.CLM_RAW_DTA_SEQ_ID != rec_clm_data_vld(i).CLM_RAW_DTA_SEQ_ID
       AND (NVL(T.PREAPPROVAL_NO,'BLANK') != rec_clm_data_vld(i).PREAPPROVAL_NO)
       AND NVL(T.PAT_ISSUE_YN,'N') != 'Y';
  -->>>>>>>>>>
  FORALL I IN 1..rec_clm_data_vld.COUNT 
     UPDATE APP.CLM_BULK_UPLD_XML_DETAILS T
        SET T.REMARKS = T.REMARKS||'Member ID not matching with invoice no. '||rec_clm_data_vld(i).invoice_no||';',
            T.MEM_ID_ISSUE_YN = 'Y',
            T.UPDATED_DATE     = SYSDATE
     WHERE T.XML_SEQ_ID = rec_clm_data_vld(i).XML_SEQ_ID
       AND T.INVOICE_NO = rec_clm_data_vld(i).INVOICE_NO 
       AND T.CLM_RAW_DTA_SEQ_ID != rec_clm_data_vld(i).CLM_RAW_DTA_SEQ_ID
       AND (NVL(T.MEMBER_ID,'B') != rec_clm_data_vld(i).MEMBER_ID)
       AND NVL(T.MEM_ID_ISSUE_YN,'N') != 'Y'
       AND (NVL(T.PAT_ISSUE_YN,'N') = 'Y' OR T.PREAPPROVAL_NO IS NULL);
  -->>>>>>>>>>
  FORALL I IN 1..rec_clm_data_vld.COUNT 
     UPDATE APP.CLM_BULK_UPLD_XML_DETAILS T
        SET T.REMARKS = T.REMARKS||CASE WHEN rec_xml_claim_info.source_type!='PBCL' THEN  'Treatment date not matching with invoice no. ' ELSE 'Prescription date not matching with invoice no. ' END||rec_clm_data_vld(i).invoice_no||';',
            T.TRTMNT_DT_ISSUE_YN = 'Y',
            T.UPDATED_DATE     = SYSDATE
     WHERE T.XML_SEQ_ID = rec_clm_data_vld(i).XML_SEQ_ID
       AND T.INVOICE_NO = rec_clm_data_vld(i).INVOICE_NO 
       AND T.CLM_RAW_DTA_SEQ_ID != rec_clm_data_vld(i).CLM_RAW_DTA_SEQ_ID
       AND (NVL(T.DATE_TREATMENT,'B') != rec_clm_data_vld(i).DATE_TREATMENT)
       AND NVL(T.TRTMNT_DT_ISSUE_YN,'N') != 'Y'
       AND (NVL(T.PAT_ISSUE_YN,'N') = 'Y' OR T.PREAPPROVAL_NO IS NULL);
  -->>>>>>>>>>
  IF rec_xml_claim_info.source_type!='PBCL' THEN
  FORALL I IN 1..rec_clm_data_vld.COUNT 
     UPDATE APP.CLM_BULK_UPLD_XML_DETAILS T
        SET T.REMARKS = T.REMARKS||'Discharge date not matching with invoice no. '||rec_clm_data_vld(i).invoice_no||';',
            T.DIS_DT_ISSUE_YN = 'Y',
            T.UPDATED_DATE     = SYSDATE
     WHERE T.XML_SEQ_ID = rec_clm_data_vld(i).XML_SEQ_ID
       AND T.INVOICE_NO = rec_clm_data_vld(i).INVOICE_NO 
       AND T.CLM_RAW_DTA_SEQ_ID != rec_clm_data_vld(i).CLM_RAW_DTA_SEQ_ID
       AND (NVL(T.DATE_DISCHARGE,'B') != rec_clm_data_vld(i).DATE_DISCHARGE)
       AND NVL(T.DIS_DT_ISSUE_YN,'N') != 'Y'
       AND (NVL(T.PAT_ISSUE_YN,'N') = 'Y' OR T.PREAPPROVAL_NO IS NULL);
  END IF;
  -->>>>>>>>>>
  FORALL I IN 1..rec_clm_data_vld.COUNT 
     UPDATE APP.CLM_BULK_UPLD_XML_DETAILS T
        SET T.REMARKS = T.REMARKS||'System of med not matching with invoice no. '||rec_clm_data_vld(i).invoice_no||';',
            T.SOM_ISSUE_YN = 'Y',
            T.UPDATED_DATE     = SYSDATE
     WHERE T.XML_SEQ_ID = rec_clm_data_vld(i).XML_SEQ_ID
       AND T.INVOICE_NO = rec_clm_data_vld(i).INVOICE_NO 
       AND T.CLM_RAW_DTA_SEQ_ID != rec_clm_data_vld(i).CLM_RAW_DTA_SEQ_ID
       AND (NVL(T.SOM_TPY_ID,'B') != rec_clm_data_vld(i).SOM_TPY_ID)
       AND NVL(T.SOM_ISSUE_YN,'N') != 'Y'
       AND (NVL(T.PAT_ISSUE_YN,'N') = 'Y' OR T.PREAPPROVAL_NO IS NULL);
  -->>>>>>>>>>
  FORALL I IN 1..rec_clm_data_vld.COUNT 
     UPDATE APP.CLM_BULK_UPLD_XML_DETAILS T
        SET T.REMARKS = T.REMARKS||'Benefit type not matching with invoice no. '||rec_clm_data_vld(i).invoice_no||';',
            T.BENF_ID_ISSUE_YN = 'Y',
            T.UPDATED_DATE     = SYSDATE
     WHERE T.XML_SEQ_ID = rec_clm_data_vld(i).XML_SEQ_ID
       AND T.INVOICE_NO = rec_clm_data_vld(i).INVOICE_NO 
       AND T.CLM_RAW_DTA_SEQ_ID != rec_clm_data_vld(i).CLM_RAW_DTA_SEQ_ID
       AND (NVL(T.BENF_TPY_ID,'B') != rec_clm_data_vld(i).BENF_TPY_ID)
       AND NVL(T.BENF_ID_ISSUE_YN,'N') != 'Y'
       AND (NVL(T.PAT_ISSUE_YN,'N') = 'Y' OR T.PREAPPROVAL_NO IS NULL);
  -->>>>>>>>>>
    FORALL I IN 1..rec_clm_data_vld.COUNT 
     UPDATE APP.CLM_BULK_UPLD_XML_DETAILS T
        SET T.REMARKS = T.REMARKS||'Encounter type not matching with invoice no. '||rec_clm_data_vld(i).invoice_no||';',
            T.ENC_TYP_ID_ISSUE_YN = 'Y',
            T.UPDATED_DATE     = SYSDATE
     WHERE T.XML_SEQ_ID = rec_clm_data_vld(i).XML_SEQ_ID
       AND T.INVOICE_NO = rec_clm_data_vld(i).INVOICE_NO 
       AND T.CLM_RAW_DTA_SEQ_ID != rec_clm_data_vld(i).CLM_RAW_DTA_SEQ_ID 
       AND (NVL(T.ENCNTR_TYPE_ID,'B') != rec_clm_data_vld(i).ENCNTR_TYPE_ID)
       AND NVL(T.ENC_TYP_ID_ISSUE_YN,'N') != 'Y'
       AND (NVL(T.PAT_ISSUE_YN,'N') = 'Y' OR T.PREAPPROVAL_NO IS NULL);
  -->>>>>>>>>>
  FORALL I IN 1..rec_clm_data_vld.COUNT 
     UPDATE APP.CLM_BULK_UPLD_XML_DETAILS T
        SET T.REMARKS = T.REMARKS||'Principal ICD not matching with invoice no. '||rec_clm_data_vld(i).invoice_no||';',
            T.PRY_ICD_ISSUE_YN = 'Y',
            T.UPDATED_DATE     = SYSDATE
     WHERE T.XML_SEQ_ID = rec_clm_data_vld(i).XML_SEQ_ID
       AND T.INVOICE_NO = rec_clm_data_vld(i).INVOICE_NO 
       AND T.CLM_RAW_DTA_SEQ_ID != rec_clm_data_vld(i).CLM_RAW_DTA_SEQ_ID
       AND (NVL(T.PRINCIPAL_ICD,'B') != rec_clm_data_vld(i).PRINCIPAL_ICD)
       AND NVL(T.PRY_ICD_ISSUE_YN,'N') != 'Y'
       AND (NVL(T.PAT_ISSUE_YN,'N') = 'Y' OR T.PREAPPROVAL_NO IS NULL);
  -->>>>>>>>>>
  FORALL I IN 1..rec_clm_data_vld.COUNT 
     UPDATE APP.CLM_BULK_UPLD_XML_DETAILS T
        SET T.REMARKS = T.REMARKS||'Nature of conception not matching with invoice no. '||rec_clm_data_vld(i).invoice_no||';',
            T.NAT_CONCEP_ISSUE_YN = 'Y',
            T.UPDATED_DATE     = SYSDATE
     WHERE T.XML_SEQ_ID = rec_clm_data_vld(i).XML_SEQ_ID
       AND T.INVOICE_NO = rec_clm_data_vld(i).INVOICE_NO 
       AND T.CLM_RAW_DTA_SEQ_ID != rec_clm_data_vld(i).CLM_RAW_DTA_SEQ_ID
       AND (NVL(T.NAT_CONCP_TPY_ID,'B') != rec_clm_data_vld(i).NAT_CONCP_TPY_ID)
       AND NVL(T.NAT_CONCEP_ISSUE_YN,'N') != 'Y'
       AND (NVL(T.PAT_ISSUE_YN,'N') = 'Y' OR T.PREAPPROVAL_NO IS NULL);     
  -->>>>>>>>>>
  FORALL I IN 1..rec_clm_data_vld.COUNT 
     UPDATE APP.CLM_BULK_UPLD_XML_DETAILS T
        SET T.REMARKS = T.REMARKS||'LMP date not matching with invoice no. '||rec_clm_data_vld(i).invoice_no||';',
            T.LMP_DT_ISSUE_YN = 'Y',
            T.UPDATED_DATE     = SYSDATE
     WHERE T.XML_SEQ_ID = rec_clm_data_vld(i).XML_SEQ_ID
       AND T.INVOICE_NO = rec_clm_data_vld(i).INVOICE_NO 
       AND T.CLM_RAW_DTA_SEQ_ID != rec_clm_data_vld(i).CLM_RAW_DTA_SEQ_ID
       AND (NVL(T.DATE_OF_LMP,'B') != rec_clm_data_vld(i).DATE_OF_LMP)
       AND NVL(T.LMP_DT_ISSUE_YN,'N') != 'Y'
       AND (NVL(T.PAT_ISSUE_YN,'N') = 'Y' OR T.PREAPPROVAL_NO IS NULL);      
  END LOOP;  
  CLOSE cur_clm_data_vld;
  
  
  ---------------PRE-APPROVAL WISE SAME CASE
  
  
  OPEN  cur_clm_pat_vld;
  LOOP
  FETCH cur_clm_pat_vld BULK COLLECT INTO rec_clm_data_vld LIMIT 2000;
   EXIT WHEN rec_clm_data_vld.COUNT = 0;
  
  FORALL I IN 1..rec_clm_data_vld.COUNT 
     UPDATE APP.CLM_BULK_UPLD_XML_DETAILS T
        SET T.REMARKS = T.REMARKS||'Principal ICD not matching with invoice no. '||rec_clm_data_vld(i).invoice_no||';',
            T.PRY_ICD_ISSUE_YN = 'Y',
            T.UPDATED_DATE     = SYSDATE
     WHERE T.XML_SEQ_ID = V_XML_SEQ_ID
       AND T.PREAPPROVAL_NO = rec_clm_data_vld(i).PREAPPROVAL_NO  
       AND T.CLM_RAW_DTA_SEQ_ID != rec_clm_data_vld(i).CLM_RAW_DTA_SEQ_ID
      AND (NVL(T.PRINCIPAL_ICD,'B') != rec_clm_data_vld(i).PRINCIPAL_ICD)
      AND NVL(T.PRY_ICD_ISSUE_YN,'N') != 'Y';
  END LOOP;  
  CLOSE cur_clm_pat_vld;
  
  ----------pre approval wise pbm date of description validation-----
  --IF rec_xml_claim_info.source_type='PBCL' THEN
  OPEN cur_pbm_clm_date_vld;
  LOOP
  FETCH cur_pbm_clm_date_vld BULK COLLECT INTO rec_pbm_clm_vld LIMIT 1000;
  EXIT WHEN rec_pbm_clm_vld.COUNT=0;
  
  FORALL i IN 1..rec_pbm_clm_vld.COUNT
  UPDATE APP.CLM_BULK_UPLD_XML_DETAILS T
        SET T.REMARKS = T.REMARKS||CASE WHEN rec_xml_claim_info.source_type!='PBCL' THEN  'Treatment date not matching with invoice no. ' ELSE 'Treatment date not matching with pre-approval no. ' END||rec_pbm_clm_vld(i).invoice_no||';',
            T.DT_PREC_ISSU_YN = 'Y',
            T.UPDATED_DATE     = SYSDATE
     WHERE T.XML_SEQ_ID = V_XML_SEQ_ID
       AND T.PREAPPROVAL_NO = rec_pbm_clm_vld(i).PREAPPROVAL_NO  
       AND T.CLM_RAW_DTA_SEQ_ID != rec_pbm_clm_vld(i).CLM_RAW_DTA_SEQ_ID
       AND (NVL(T.DATE_TREATMENT,'B') != rec_pbm_clm_vld(i).DATE_TREATMENT)
       AND NVL(T.DT_PREC_ISSU_YN,'N') != 'Y'
       AND NVL(T.TRTMNT_DT_ISSUE_YN,'N')='N';
  END LOOP;
  CLOSE cur_pbm_clm_date_vld;
  --END IF;  
  
 -- Added for Same Discharge Date for same Preauth
  IF rec_xml_claim_info.source_type!='PBCL' THEN
    OPEN  cur_clm_pat_vld;
    LOOP
    FETCH cur_clm_pat_vld BULK COLLECT INTO rec_clm_data_vld LIMIT 2000;
     EXIT WHEN rec_clm_data_vld.COUNT = 0;
    
    FORALL I IN 1..rec_clm_data_vld.COUNT 
       UPDATE APP.CLM_BULK_UPLD_XML_DETAILS T
          SET T.REMARKS = T.REMARKS||'Discharge not matching with invoice no. '||rec_clm_data_vld(i).invoice_no||';',
              T.DIS_DT_ISSUE_YN = 'Y',
              T.UPDATED_DATE     = SYSDATE
       WHERE T.XML_SEQ_ID = V_XML_SEQ_ID
         AND T.PREAPPROVAL_NO = rec_clm_data_vld(i).PREAPPROVAL_NO  
         AND T.CLM_RAW_DTA_SEQ_ID != rec_clm_data_vld(i).CLM_RAW_DTA_SEQ_ID
        AND (NVL(T.DATE_DISCHARGE,'B') != rec_clm_data_vld(i).DATE_DISCHARGE)
        AND NVL(T.DIS_DT_ISSUE_YN,'N') != 'Y';
    END LOOP;  
    CLOSE cur_clm_pat_vld;
  END IF;
  save_time_details(v_xml_seq_id,'DATA_VALD',v_start_time);
  
 EXCEPTION
    WHEN bulk_errors THEN
      l_error_count := SQL%BULK_EXCEPTIONS.count;
      FOR i IN 1 .. l_error_count LOOP
        v_bulk_error_msg := v_bulk_error_msg ||
                            ('Number of failures: ' || l_error_count ||
                             'Error: ' || i ||
                             ' Array Index: ' || SQL%BULK_EXCEPTIONS(i).error_index ||
                             ' Message: ' || SQLERRM(-SQL%BULK_EXCEPTIONS(i).ERROR_CODE));
      END LOOP;
        save_exception_log(v_xml_seq_id,NULL,NULL,NULL,v_bulk_error_msg,v_added_by,'validate_claim_info',rec_xml_claim_info.hosp_seq_id);
        ROLLBACK;
      WHEN OTHERS THEN
         V_SQL_CODE := SQLCODE;
         V_SQL_MSG  := SQLERRM; 
         
         save_exception_log(v_xml_seq_id,NULL,v_sql_code,v_sql_msg,NULL,v_added_by,'validate_claim_info',rec_xml_claim_info.hosp_seq_id);
         ROLLBACK;
     
 END validate_claim_info;  
------------------------------------------------------------------------------------------------------
PROCEDURE split_claims_info(v_xml_seq_id            IN NUMBER, 
                            v_added_by              IN NUMBER) 
IS
 
 CURSOR cur_same_pat_claim_data IS
   WITH EVENT_DATA AS
     (
      SELECT T.EVENT_REF_NO, T.PREAPPROVAL_NO
      
      FROM APP.CLM_BULK_UPLD_XML_DETAILS T
      JOIN APP.PAT_AUTHORIZATION_DETAILS PA ON (T.PREAPPROVAL_NO = PA.PRE_AUTH_NUMBER AND T.EVENT_REF_NO = PA.EVENT_NO AND PA.PAT_ENHANCED_YN = 'N')
      WHERE T.XML_SEQ_ID = V_XML_SEQ_ID
      AND T.PREAPPROVAL_NO IS NOT NULL
      GROUP BY T.PREAPPROVAL_NO, T.EVENT_REF_NO
     ),
   CLM_DATA AS
      (SELECT /*T.INVOICE_NO,
                T.PREAPPROVAL_NO,PA.TPA_ENROLLMENT_ID AS MEMBER_ID,PA.HOSPITALIZATION_DATE AS DATE_TREATMENT,
                PA.DISCHARGE_DATE AS DATE_DISCHARGE,
                NULL AS FIRST_INCIDENT_DATE,NULL AS FIRST_REPORTED_DATE,PA.LMP_DATE AS DATE_OF_LMP,PA.EVENT_NO AS EVENT_REF_NO,
                PA.BENIFIT_TYPE AS BENF_TPY_ID,PA.ENCOUNTER_TYPE_ID AS ENCNTR_TYPE_ID,
                PA.SYSTEM_OF_MEDICINE_TYPE_ID AS SOM_TPY_ID,PA.CONCEPTION_TYPE AS NAT_CONCP_TPY_ID,*/
				--CR 0198
                T.INVOICE_NO,
                T.PREAPPROVAL_NO, T.MEMBER_ID AS MEMBER_ID, T.DATE_TREATMENT AS DATE_TREATMENT,
                T.DATE_DISCHARGE AS DATE_DISCHARGE,/* NULL AS FIRST_INCIDENT_DATE,NULL AS FIRST_REPORTED_DATE,*/
                PA.LMP_DATE AS DATE_OF_LMP, E.EVENT_REF_NO AS EVENT_REF_NO, T.BENF_TPY_ID AS BENF_TPY_ID,
                T.ENCNTR_TYPE_ID AS ENCNTR_TYPE_ID, T.SOM_TPY_ID AS SOM_TPY_ID, PA.CONCEPTION_TYPE AS NAT_CONCP_TPY_ID,
                get_mem_seq_id(T.MEMBER_ID,TO_DATE(PA.HOSPITALIZATION_DATE,'DD/MM/RRRR')) AS MEMBER_SEQ_ID,
                ROUND(SUM(NVL(T.AMOUNT_CLAIMED,0)),2) AS REQUESTED_AMOUNT,T.HOSP_SEQ_ID,PA.TREATMENT_TYPE,
                MAX(T.DATE_TREATMENT) AS PBM_DATE_TREATMENT,MAX(T.DATE_DISCHARGE) AS PBM_DATE_DISCHARGE,
                MAX(T.SOURCE_TYPE)AS SOURCE_TYPE
         FROM APP.CLM_BULK_UPLD_XML_DETAILS T
         JOIN APP.PAT_AUTHORIZATION_DETAILS PA ON (T.PREAPPROVAL_NO=PA.PRE_AUTH_NUMBER AND PA.PAT_ENHANCED_YN = 'N')
         LEFT JOIN EVENT_DATA E ON E.PREAPPROVAL_NO = T.PREAPPROVAL_NO
         WHERE T.XML_SEQ_ID = V_XML_SEQ_ID
           AND T.PREAPPROVAL_NO IS NOT NULL
         GROUP BY T.INVOICE_NO,T.PREAPPROVAL_NO,PA.TPA_ENROLLMENT_ID,T.DATE_TREATMENT,T.DATE_DISCHARGE, PA.HOSPITALIZATION_DATE,
                  --T.FIRST_INCIDENT_DATE,T.FIRST_REPORTED_DATE,
                  PA.LMP_DATE,E.EVENT_REF_NO,
                  T.BENF_TPY_ID,T.ENCNTR_TYPE_ID,T.SOM_TPY_ID,
                  PA.CONCEPTION_TYPE,T.MEMBER_ID,T.HOSP_SEQ_ID,PA.TREATMENT_TYPE)
                  
      SELECT TO_CHAR(WM_CONCAT(T.INVOICE_NO)) INVOICE_NO_LIST,
             T.PREAPPROVAL_NO,T.MEMBER_ID,T.DATE_TREATMENT,T.DATE_DISCHARGE,
            /* T.FIRST_INCIDENT_DATE,T.FIRST_REPORTED_DATE,*/
             T.DATE_OF_LMP,EVENT_REF_NO,
             T.BENF_TPY_ID,T.ENCNTR_TYPE_ID,T.SOM_TPY_ID,T.NAT_CONCP_TPY_ID,MEMBER_SEQ_ID,
             SUM(REQUESTED_AMOUNT) AS REQUESTED_AMOUNT,T.HOSP_SEQ_ID,T.TREATMENT_TYPE,
             MAX(T.PBM_DATE_TREATMENT) AS PBM_DATE_TREATMENT,MAX(T.PBM_DATE_DISCHARGE) AS PBM_DATE_DISCHARGE,
             MAX(T.SOURCE_TYPE) AS SOURCE_TYPE
      FROM CLM_DATA T           
       GROUP BY T.PREAPPROVAL_NO,T.MEMBER_ID,T.DATE_TREATMENT,T.DATE_DISCHARGE,
                /*T.FIRST_INCIDENT_DATE,T.FIRST_REPORTED_DATE,*/
                T.DATE_OF_LMP,EVENT_REF_NO,
                T.BENF_TPY_ID,T.ENCNTR_TYPE_ID,T.SOM_TPY_ID,T.NAT_CONCP_TPY_ID,MEMBER_SEQ_ID,
                T.HOSP_SEQ_ID,T.TREATMENT_TYPE;---CLINICIAN id NEED TO BE UPDATE AS SAME
            
 CURSOR cur_same_invoice_claim_data IS
   SELECT T.INVOICE_NO AS INVOICE_NO_LIST,
          T.PREAPPROVAL_NO,T.MEMBER_ID,T.DATE_TREATMENT,
          CASE WHEN T.BENF_TPY_ID LIKE '%IPT%' THEN T.DATE_DISCHARGE ELSE T.DATE_TREATMENT END AS DATE_DISCHARGE,
          /*T.FIRST_INCIDENT_DATE,T.FIRST_REPORTED_DATE,*/
          T.DATE_OF_LMP,NULL AS EVENT_REF_NO,
          T.BENF_TPY_ID,T.ENCNTR_TYPE_ID,T.SOM_TPY_ID,T.NAT_CONCP_TPY_ID,
          get_mem_seq_id(T.MEMBER_ID,TO_DATE(T.DATE_TREATMENT,'DD/MM/RRRR')) AS MEMBER_SEQ_ID,
          ROUND(SUM(NVL(T.AMOUNT_CLAIMED,0)),2) AS REQUESTED_AMOUNT,T.HOSP_SEQ_ID
   FROM APP.CLM_BULK_UPLD_XML_DETAILS T
   WHERE T.PREAPPROVAL_NO IS NULL
     AND T.XML_SEQ_ID = V_XML_SEQ_ID
   GROUP BY T.INVOICE_NO,T.PREAPPROVAL_NO,T.MEMBER_ID,T.DATE_TREATMENT,T.DATE_DISCHARGE,
            /*T.FIRST_INCIDENT_DATE,T.FIRST_REPORTED_DATE,*/
            T.DATE_OF_LMP,
            T.BENF_TPY_ID,T.ENCNTR_TYPE_ID,T.SOM_TPY_ID,T.NAT_CONCP_TPY_ID,T.HOSP_SEQ_ID;    
 
 
 
 
 CURSOR cur_same_pat_diag_details IS
   WITH PAT_DIAG_DATA AS
      (SELECT T.PREAPPROVAL_NO,T.PRINCIPAL_ICD AS ICD_LIST, 'Y' AS PRY_ICD_ISSUE_YN
        FROM APP.CLM_BULK_UPLD_XML_DETAILS T
       WHERE T.XML_SEQ_ID = V_XML_SEQ_ID
         AND T.PRINCIPAL_ICD IS NOT NULL
         AND T.PREAPPROVAL_NO IS NOT NULL
      UNION 
       SELECT T.PREAPPROVAL_NO,T.SECONDARY_ICD_CODE1 AS ICD_LIST, 'N' AS PRY_ICD_ISSUE_YN
       FROM APP.CLM_BULK_UPLD_XML_DETAILS T
       WHERE T.XML_SEQ_ID = V_XML_SEQ_ID
         AND T.SECONDARY_ICD_CODE1 IS NOT NULL
         AND T.PREAPPROVAL_NO IS NOT NULL
      UNION 
       SELECT T.PREAPPROVAL_NO,T.SECONDARY_ICD_CODE2 AS ICD_LIST, 'N' AS PRY_ICD_ISSUE_YN
       FROM APP.CLM_BULK_UPLD_XML_DETAILS T
       WHERE T.XML_SEQ_ID = V_XML_SEQ_ID
         AND T.SECONDARY_ICD_CODE2 IS NOT NULL
         AND T.PREAPPROVAL_NO IS NOT NULL
      UNION 
       SELECT T.PREAPPROVAL_NO,T.SECONDARY_ICD_CODE3 AS ICD_LIST, 'N' AS PRY_ICD_ISSUE_YN
       FROM APP.CLM_BULK_UPLD_XML_DETAILS T
       WHERE T.XML_SEQ_ID = V_XML_SEQ_ID
         AND T.SECONDARY_ICD_CODE3 IS NOT NULL
         AND T.PREAPPROVAL_NO IS NOT NULL
      UNION 
       SELECT T.PREAPPROVAL_NO,T.SECONDARY_ICD_CODE4 AS ICD_LIST, 'N' AS PRY_ICD_ISSUE_YN
       FROM APP.CLM_BULK_UPLD_XML_DETAILS T
       WHERE T.XML_SEQ_ID = V_XML_SEQ_ID
         AND T.SECONDARY_ICD_CODE4 IS NOT NULL
         AND T.PREAPPROVAL_NO IS NOT NULL
      UNION 
       SELECT T.PREAPPROVAL_NO,T.SECONDARY_ICD_CODE5 AS ICD_LIST, 'N' AS PRY_ICD_ISSUE_YN
       FROM APP.CLM_BULK_UPLD_XML_DETAILS T
       WHERE T.XML_SEQ_ID = V_XML_SEQ_ID
         AND T.SECONDARY_ICD_CODE5 IS NOT NULL
         AND T.PREAPPROVAL_NO IS NOT NULL)
     SELECT D.PREAPPROVAL_NO,ICD_LIST,PRY_ICD_ISSUE_YN,C.CLM_XML_SEQ_ID
     FROM PAT_DIAG_DATA D
     JOIN APP.CLM_BULK_UPLD_CLM_DETAILS C ON (C.PREAPPROVAL_NO=D.PREAPPROVAL_NO AND C.XML_SEQ_ID = V_XML_SEQ_ID)
     ORDER BY D.PREAPPROVAL_NO,PRY_ICD_ISSUE_YN DESC; 
     
     
  CURSOR cur_same_invoice_diag_details IS
   WITH INVOICE_DIAG_DATA AS
      (SELECT T.INVOICE_NO,T.PRINCIPAL_ICD AS ICD_LIST, 'Y' AS PRY_ICD_ISSUE_YN
        FROM APP.CLM_BULK_UPLD_XML_DETAILS T
       WHERE T.XML_SEQ_ID = V_XML_SEQ_ID
         AND T.PRINCIPAL_ICD IS NOT NULL
         AND T.PREAPPROVAL_NO IS NULL
      UNION 
       SELECT T.INVOICE_NO,T.SECONDARY_ICD_CODE1 AS ICD_LIST, 'N' AS PRY_ICD_ISSUE_YN
       FROM APP.CLM_BULK_UPLD_XML_DETAILS T
       WHERE T.XML_SEQ_ID = V_XML_SEQ_ID
         AND T.SECONDARY_ICD_CODE1 IS NOT NULL
         AND T.PREAPPROVAL_NO IS NULL
      UNION 
       SELECT T.INVOICE_NO,T.SECONDARY_ICD_CODE2 AS ICD_LIST, 'N' AS PRY_ICD_ISSUE_YN
       FROM APP.CLM_BULK_UPLD_XML_DETAILS T
       WHERE T.XML_SEQ_ID = V_XML_SEQ_ID
         AND T.SECONDARY_ICD_CODE2 IS NOT NULL
         AND T.PREAPPROVAL_NO IS NULL
      UNION 
       SELECT T.INVOICE_NO,T.SECONDARY_ICD_CODE3 AS ICD_LIST, 'N' AS PRY_ICD_ISSUE_YN
       FROM APP.CLM_BULK_UPLD_XML_DETAILS T
       WHERE T.XML_SEQ_ID = V_XML_SEQ_ID
         AND T.SECONDARY_ICD_CODE3 IS NOT NULL
         AND T.PREAPPROVAL_NO IS NULL
      UNION 
       SELECT T.INVOICE_NO,T.SECONDARY_ICD_CODE4 AS ICD_LIST, 'N' AS PRY_ICD_ISSUE_YN
       FROM APP.CLM_BULK_UPLD_XML_DETAILS T
       WHERE T.XML_SEQ_ID = V_XML_SEQ_ID
         AND T.SECONDARY_ICD_CODE4 IS NOT NULL
         AND T.PREAPPROVAL_NO IS NULL
      UNION 
       SELECT T.INVOICE_NO,T.SECONDARY_ICD_CODE5 AS ICD_LIST, 'N' AS PRY_ICD_ISSUE_YN
       FROM APP.CLM_BULK_UPLD_XML_DETAILS T
       WHERE T.XML_SEQ_ID = V_XML_SEQ_ID
         AND T.SECONDARY_ICD_CODE5 IS NOT NULL
         AND T.PREAPPROVAL_NO IS NULL)
     SELECT D.INVOICE_NO,ICD_LIST,PRY_ICD_ISSUE_YN,C.CLM_XML_SEQ_ID
     FROM INVOICE_DIAG_DATA D
     JOIN APP.CLM_BULK_UPLD_CLM_DETAILS C ON (C.INVOICE_NO=D.INVOICE_NO AND C.XML_SEQ_ID = V_XML_SEQ_ID)
     ORDER BY D.INVOICE_NO,PRY_ICD_ISSUE_YN DESC;
     
CURSOR cur_same_pat_act_details IS
 SELECT X.INVOICE_NO,X.PREAPPROVAL_NO,X.CLINICIAN_ID,X.SERVICE_DATE,
        X.INTERNAL_SERVICE_CODE,X.SERVICE_DESCRIPTION,
        CASE WHEN X.ACT_TPY_ID = 'DRG' AND X.CPT_CODE IS NULL THEN 'PHARMA'
             ELSE X.CPT_CODE END AS CPT_CODE,
        X.AMOUNT_CLAIMED,X.QUANTITY,X.TOOTH_NUMBER,X.ACT_TPY_ID,
        PA.LMP_DATE AS DATE_OF_LMP,CA.CLM_XML_SEQ_ID,X.CLINICIAN_NAME,
        X.SYMPTOMS,X.OBSERVATION,
        X.MOPH_CODES,CASE WHEN UPPER(X.UNIT_TYPE)='LOOSE' THEN 'LSE' WHEN UPPER(X.UNIT_TYPE)='PACKAGE' THEN 'PKG' END  UNIT_TYPE,X.DUR_MEDI
 FROM APP.CLM_BULK_UPLD_CLM_DETAILS CA
 JOIN APP.CLM_BULK_UPLD_XML_DETAILS X ON (CA.PREAPPROVAL_NO=X.PREAPPROVAL_NO AND CA.XML_SEQ_ID=X.XML_SEQ_ID)
 LEFT OUTER JOIN APP.PAT_AUTHORIZATION_DETAILS PA ON (CA.PREAPPROVAL_NO=PA.PRE_AUTH_NUMBER  AND PA.PAT_ENHANCED_YN = 'N')-----NEWLY ADDED FOR PREUATH ENHANCEMENT      
 WHERE X.XML_SEQ_ID = V_XML_SEQ_ID;
 
CURSOR cur_same_invoice_act_details IS
 SELECT X.INVOICE_NO,X.PREAPPROVAL_NO,X.CLINICIAN_ID,X.SERVICE_DATE,
        X.INTERNAL_SERVICE_CODE,X.SERVICE_DESCRIPTION,
        CASE WHEN X.ACT_TPY_ID = 'DRG' AND X.CPT_CODE IS NULL THEN 'PHARMA'
             ELSE X.CPT_CODE END AS CPT_CODE,
        X.AMOUNT_CLAIMED,X.QUANTITY,X.TOOTH_NUMBER,X.ACT_TPY_ID,
        X.DATE_OF_LMP,CA.CLM_XML_SEQ_ID,X.CLINICIAN_NAME,
        X.SYMPTOMS,X.OBSERVATION,
        X.MOPH_CODES,CASE WHEN UPPER(X.UNIT_TYPE)='LOOSE' THEN 'LSE' WHEN UPPER(X.UNIT_TYPE)='PACKAGE' THEN 'PKG' END UNIT_TYPE,X.DUR_MEDI
 FROM APP.CLM_BULK_UPLD_CLM_DETAILS CA
 JOIN APP.CLM_BULK_UPLD_XML_DETAILS X ON (CA.INVOICE_NO=X.INVOICE_NO AND CA.XML_SEQ_ID=X.XML_SEQ_ID)       
 WHERE X.XML_SEQ_ID = V_XML_SEQ_ID
   AND X.PREAPPROVAL_NO IS NULL; 

   CURSOR cur_xml_hosp_info IS
   SELECT xd.HOSP_SEQ_ID
   FROM APP.CLM_BULK_UPLD_XML_DTA xd
   WHERE xd.XML_SEQ_ID = v_xml_seq_id;   
 
TYPE typ_invoice_clm_data IS TABLE OF  cur_same_invoice_claim_data%ROWTYPE INDEX BY PLS_INTEGER;
rec_invoice_clm_details       typ_invoice_clm_data;
TYPE typ_only_clm_data IS TABLE OF  cur_same_pat_claim_data%ROWTYPE INDEX BY PLS_INTEGER;
rec_clm_details       typ_only_clm_data;
TYPE typ_pat_diag_data IS TABLE OF  cur_same_pat_diag_details%ROWTYPE INDEX BY PLS_INTEGER;
rec_pat_diag_details       typ_pat_diag_data;
TYPE typ_invoice_diag_data IS TABLE OF  cur_same_invoice_diag_details%ROWTYPE INDEX BY PLS_INTEGER;
rec_invoice_diag_details       typ_invoice_diag_data;
TYPE typ_pat_act_data IS TABLE OF  cur_same_pat_act_details%ROWTYPE INDEX BY PLS_INTEGER;
rec_pat_act_details       typ_pat_act_data;
TYPE typ_invoice_act_data IS TABLE OF  cur_same_invoice_act_details%ROWTYPE INDEX BY PLS_INTEGER;
rec_invoice_act_details       typ_invoice_act_data;

 bulk_errors          EXCEPTION;
 PRAGMA EXCEPTION_INIT(bulk_errors, -24381);
 l_error_count          NUMBER; 
 v_bulk_error_msg       CLOB;
 v_start_time           NUMBER;
 v_sql_code             VARCHAR2(100);
 v_sql_msg              VARCHAR2(4000);
 V_HOSP_SEQ_ID          NUMBER(30);

BEGIN
  
v_start_time:= dbms_utility.get_time;

  OPEN  cur_xml_hosp_info;
  FETCH cur_xml_hosp_info INTO V_HOSP_SEQ_ID;
  CLOSE cur_xml_hosp_info;
  
  -----####### Claim Info ############### 
  -----------SAME PRE-APPROVAL CLAIM DATA
  OPEN  cur_same_pat_claim_data;
  LOOP
  FETCH cur_same_pat_claim_data BULK COLLECT INTO rec_clm_details LIMIT 2000;
  EXIT WHEN rec_clm_details.COUNT = 0;
   
    FORALL i IN 1..rec_clm_details.COUNT 
      INSERT INTO APP.CLM_BULK_UPLD_CLM_DETAILS
         (CLM_XML_SEQ_ID,
          XML_SEQ_ID,
          HOSP_SEQ_ID,
          INVOICE_NO,
          PREAPPROVAL_NO,
          MEMBER_ID,
          DATE_TREATMENT,
          DATE_DISCHARGE,
          --CLINICIAN_ID,
          FIRST_INCIDENT_DATE,
          FIRST_REPORTED_DATE,
          DATE_OF_LMP,
          EVENT_REF_NO,
          BENF_TPY_ID,
          ENCNTR_TYPE_ID,
          SOM_TPY_ID,
          NAT_CONCP_TPY_ID,
          ADDED_BY,ADDED_DATE,
          MEMBER_SEQ_ID,
          REQUESTED_AMOUNT,
          TREATMENT_TYPE)
      VALUES(app.clm_blk_upld_clm_seq.nextval,
             V_XML_SEQ_ID,
             rec_clm_details(i).HOSP_SEQ_ID,
             rec_clm_details(i).INVOICE_NO_LIST,
             rec_clm_details(i).PREAPPROVAL_NO,
             rec_clm_details(i).MEMBER_ID,
             CASE WHEN rec_clm_details(i).SOURCE_TYPE!='PBCL' THEN TO_DATE(rec_clm_details(i).DATE_TREATMENT,'DD/MM/RRRR') ELSE TO_DATE(rec_clm_details(i).PBM_DATE_TREATMENT,'DD/MM/RRRR') END,
             CASE WHEN rec_clm_details(i).SOURCE_TYPE!='PBCL' THEN TO_DATE(rec_clm_details(i).DATE_DISCHARGE,'DD/MM/RRRR') ELSE TO_DATE(rec_clm_details(i).PBM_DATE_DISCHARGE,'DD/MM/RRRR') END,
             null,--TO_DATE(rec_clm_details(i).FIRST_INCIDENT_DATE,'DD/MM/RRRR'),
             null,--TO_DATE(rec_clm_details(i).FIRST_REPORTED_DATE,'DD/MM/RRRR'),
             TO_DATE(rec_clm_details(i).DATE_OF_LMP,'DD/MM/RRRR'),
             rec_clm_details(i).EVENT_REF_NO,
             rec_clm_details(i).BENF_TPY_ID,
             rec_clm_details(i).ENCNTR_TYPE_ID,
             rec_clm_details(i).SOM_TPY_ID,
             rec_clm_details(i).NAT_CONCP_TPY_ID,
             1,SYSDATE,
             rec_clm_details(i).MEMBER_SEQ_ID,
             rec_clm_details(i).REQUESTED_AMOUNT,
             rec_clm_details(i).TREATMENT_TYPE);    
  END LOOP;
  CLOSE cur_same_pat_claim_data;
  
  
  -----------SAME INVOICE CLAIM DATA
  OPEN  cur_same_invoice_claim_data;
  LOOP
  FETCH cur_same_invoice_claim_data BULK COLLECT INTO rec_invoice_clm_details LIMIT 2000;
  EXIT WHEN rec_invoice_clm_details.COUNT = 0;
   
    FORALL i IN 1..rec_invoice_clm_details.COUNT 
      INSERT INTO APP.CLM_BULK_UPLD_CLM_DETAILS
         (CLM_XML_SEQ_ID,
          XML_SEQ_ID,
          HOSP_SEQ_ID,
          INVOICE_NO,
          PREAPPROVAL_NO,
          MEMBER_ID,
          DATE_TREATMENT,
          DATE_DISCHARGE,
          --CLINICIAN_ID,
          FIRST_INCIDENT_DATE,
          FIRST_REPORTED_DATE,
          DATE_OF_LMP,
          EVENT_REF_NO,
          BENF_TPY_ID,
          ENCNTR_TYPE_ID,
          SOM_TPY_ID,
          NAT_CONCP_TPY_ID,
          ADDED_BY,ADDED_DATE,
          MEMBER_SEQ_ID,
          REQUESTED_AMOUNT)
      VALUES(app.clm_blk_upld_clm_seq.nextval,
             V_XML_SEQ_ID,
             rec_invoice_clm_details(i).HOSP_SEQ_ID,
             rec_invoice_clm_details(i).INVOICE_NO_LIST,
             rec_invoice_clm_details(i).PREAPPROVAL_NO,
             rec_invoice_clm_details(i).MEMBER_ID,
             TO_DATE(rec_invoice_clm_details(i).DATE_TREATMENT,'DD/MM/RRRR'),
             TO_DATE(rec_invoice_clm_details(i).DATE_DISCHARGE,'DD/MM/RRRR'),
             null,--TO_DATE(rec_invoice_clm_details(i).FIRST_INCIDENT_DATE,'DD/MM/RRRR'),
             null,--TO_DATE(rec_invoice_clm_details(i).FIRST_REPORTED_DATE,'DD/MM/RRRR'),
             TO_DATE(rec_invoice_clm_details(i).DATE_OF_LMP,'DD/MM/RRRR'),
             rec_invoice_clm_details(i).EVENT_REF_NO,
             rec_invoice_clm_details(i).BENF_TPY_ID,
             rec_invoice_clm_details(i).ENCNTR_TYPE_ID,
             rec_invoice_clm_details(i).SOM_TPY_ID,
             rec_invoice_clm_details(i).NAT_CONCP_TPY_ID,
             1,SYSDATE,
             rec_invoice_clm_details(i).MEMBER_SEQ_ID,
             rec_invoice_clm_details(i).REQUESTED_AMOUNT);    
  END LOOP;
  CLOSE cur_same_invoice_claim_data;
  
  --###### ICD Info #######################
  -------SAME PREAPPROVAL DIAGNOSYS DETAILS
  OPEN  cur_same_pat_diag_details;
  LOOP
  FETCH cur_same_pat_diag_details BULK COLLECT INTO rec_pat_diag_details LIMIT 2000;
  EXIT WHEN rec_pat_diag_details.COUNT = 0;
   
    FORALL i IN 1..rec_pat_diag_details.COUNT 
      INSERT INTO APP.CLM_BULK_UPLD_DIAG_DETAILS
         (CLM_XML_DIAG_SEQ_ID,
          CLM_XML_SEQ_ID,
          XML_SEQ_ID,
          preapproval_no,
          diagnosys_code,
          primary_ailment_yn,
          added_by,
          added_date)
      VALUES(app.clm_blk_upld_diag_seq.nextval,
             rec_pat_diag_details(i).CLM_XML_SEQ_ID,
             V_XML_SEQ_ID,
             rec_pat_diag_details(i).PREAPPROVAL_NO,
             rec_pat_diag_details(i).ICD_LIST,
             rec_pat_diag_details(i).PRY_ICD_ISSUE_YN,
             v_added_by,
             SYSDATE);    
  END LOOP;
  CLOSE cur_same_pat_diag_details;
  
 DELETE FROM APP.CLM_BULK_UPLD_DIAG_DETAILS D 
 WHERE (D.INVOICE_NO,D.DIAGNOSYS_CODE) IN (SELECT DD.INVOICE_NO,DD.DIAGNOSYS_CODE
                                           FROM APP.CLM_BULK_UPLD_DIAG_DETAILS DD
                                           WHERE XML_SEQ_ID = V_XML_SEQ_ID
                                           GROUP BY DD.INVOICE_NO,DD.DIAGNOSYS_CODE----XML SEQ ID REQ.
                                           HAVING COUNT(1) > 1)
 AND NVL(D.PRIMARY_AILMENT_YN,'N') = 'N'
 AND XML_SEQ_ID = V_XML_SEQ_ID;
 
 
   -------SAME INVOICE DIAGNOSYS DETAILS
  OPEN  cur_same_invoice_diag_details;
  LOOP
  FETCH cur_same_invoice_diag_details BULK COLLECT INTO rec_invoice_diag_details LIMIT 2000;
  EXIT WHEN rec_invoice_diag_details.COUNT = 0;
   
    FORALL i IN 1..rec_invoice_diag_details.COUNT 
      INSERT INTO APP.CLM_BULK_UPLD_DIAG_DETAILS
         (CLM_XML_DIAG_SEQ_ID,
          CLM_XML_SEQ_ID,
          XML_SEQ_ID,
          invoice_no,
          diagnosys_code,
          primary_ailment_yn,
          added_by,
          added_date)
      VALUES(app.clm_blk_upld_diag_seq.nextval,
             rec_invoice_diag_details(i).CLM_XML_SEQ_ID,
             V_XML_SEQ_ID,
             rec_invoice_diag_details(i).INVOICE_NO,
             rec_invoice_diag_details(i).ICD_LIST,
             rec_invoice_diag_details(i).PRY_ICD_ISSUE_YN,
             v_added_by,
             SYSDATE);    
  END LOOP;
  CLOSE cur_same_invoice_diag_details;
 
 DELETE FROM APP.CLM_BULK_UPLD_DIAG_DETAILS D 
 WHERE (D.PREAPPROVAL_NO,D.DIAGNOSYS_CODE) IN (SELECT DD.PREAPPROVAL_NO,DD.DIAGNOSYS_CODE
                                               FROM APP.CLM_BULK_UPLD_DIAG_DETAILS DD
                                               WHERE XML_SEQ_ID = V_XML_SEQ_ID
                                               GROUP BY DD.PREAPPROVAL_NO,DD.DIAGNOSYS_CODE----XML SEQ ID REQ.
                                               HAVING COUNT(1) > 1)
 AND NVL(D.PRIMARY_AILMENT_YN,'N') = 'N'
 AND XML_SEQ_ID = V_XML_SEQ_ID;
 
  --##### Activity Info ##################
  -------SAME PREAPPROVAL ACTIVITY DETAILS
  OPEN  cur_same_pat_act_details;
  LOOP
  FETCH cur_same_pat_act_details BULK COLLECT INTO rec_pat_act_details LIMIT 2000;
  EXIT WHEN rec_pat_act_details.COUNT = 0;
   
    FORALL i IN 1..rec_pat_act_details.COUNT 
      INSERT INTO APP.CLM_BULK_UPLD_ACT_DETAILS
         (CLM_XML_ACT_SEQ_ID,
          CLM_XML_SEQ_ID,
          invoice_no,
          preapproval_no,
          clinician_id,
          clinician_name,
          service_date,
          internal_service_code,
          service_description,
          cpt_code,
          amount_claimed,
          quantity,
          tooth_number,
          act_tpy_id,
          added_by,
          added_date,
          DATE_OF_LMP,
          SYMPTOMS,
          OBSERVATION,
          MOPH_CODES,
          UNIT_TYPE,
          DUR_MEDI)
      VALUES(app.clm_blk_upld_act_seq.nextval,
             rec_pat_act_details(i).CLM_XML_SEQ_ID,
             rec_pat_act_details(i).invoice_no,
             rec_pat_act_details(i).preapproval_no,
             rec_pat_act_details(i).clinician_id,
             rec_pat_act_details(i).clinician_name,
             TO_DATE(rec_pat_act_details(i).service_date,'DD/MM/RRRR'),
             rec_pat_act_details(i).internal_service_code,
             rec_pat_act_details(i).service_description,
             rec_pat_act_details(i).cpt_code,
             rec_pat_act_details(i).amount_claimed,
             rec_pat_act_details(i).quantity,
             rec_pat_act_details(i).tooth_number,
             rec_pat_act_details(i).act_tpy_id,
             v_added_by,
             SYSDATE,
             TO_DATE(rec_pat_act_details(i).DATE_OF_LMP,'DD/MM/RRRR'),
             rec_pat_act_details(i).SYMPTOMS,
             rec_pat_act_details(i).OBSERVATION,
             rec_pat_act_details(i).MOPH_CODES,
             rec_pat_act_details(i).UNIT_TYPE,
             rec_pat_act_details(i).DUR_MEDI);    
  END LOOP;
  CLOSE cur_same_pat_act_details;
  
   -------SAME INVOICE ACTIVITY DETAILS
  OPEN  cur_same_invoice_act_details;
  LOOP
  FETCH cur_same_invoice_act_details BULK COLLECT INTO rec_invoice_act_details LIMIT 2000;
  EXIT WHEN rec_invoice_act_details.COUNT = 0;
   
    FORALL i IN 1..rec_invoice_act_details.COUNT 
      INSERT INTO APP.CLM_BULK_UPLD_ACT_DETAILS
         (CLM_XML_ACT_SEQ_ID,
          CLM_XML_SEQ_ID,
          invoice_no,
          preapproval_no,
          clinician_id,
          clinician_name,
          service_date,
          internal_service_code,
          service_description,
          cpt_code,
          amount_claimed,
          quantity,
          tooth_number,
          act_tpy_id,
          added_by,
          added_date,
          DATE_OF_LMP,
          SYMPTOMS,
          OBSERVATION,
          MOPH_CODES,
          UNIT_TYPE,
          DUR_MEDI)
      VALUES(app.clm_blk_upld_act_seq.nextval,
             rec_invoice_act_details(i).CLM_XML_SEQ_ID,
             rec_invoice_act_details(i).invoice_no,
             rec_invoice_act_details(i).preapproval_no,
             rec_invoice_act_details(i).clinician_id,
             rec_invoice_act_details(i).clinician_name,
             TO_DATE(rec_invoice_act_details(i).service_date,'DD/MM/RRRR'),
             rec_invoice_act_details(i).internal_service_code,
             rec_invoice_act_details(i).service_description,
             rec_invoice_act_details(i).cpt_code,
             rec_invoice_act_details(i).amount_claimed,
             rec_invoice_act_details(i).quantity,
             rec_invoice_act_details(i).tooth_number,
             rec_invoice_act_details(i).act_tpy_id,
             v_added_by,
             SYSDATE,
             TO_DATE(rec_invoice_act_details(i).DATE_OF_LMP,'DD/MM/RRRR'),
             rec_invoice_act_details(i).SYMPTOMS,
             rec_invoice_act_details(i).OBSERVATION,
             rec_invoice_act_details(i).MOPH_CODES,
             rec_invoice_act_details(i).UNIT_TYPE,
             rec_invoice_act_details(i).DUR_MEDI);    
  END LOOP;
  CLOSE cur_same_invoice_act_details;
  
  save_time_details(v_xml_seq_id,'SPLIT_CLM',v_start_time);
  
 EXCEPTION
    WHEN bulk_errors THEN
      l_error_count := SQL%BULK_EXCEPTIONS.count;
      FOR i IN 1 .. l_error_count LOOP
        v_bulk_error_msg := v_bulk_error_msg ||
                            ('Number of failures: ' || l_error_count ||
                             'Error: ' || i ||
                             ' Array Index: ' || SQL%BULK_EXCEPTIONS(i).error_index ||
                             ' Message: ' || SQLERRM(-SQL%BULK_EXCEPTIONS(i).ERROR_CODE));
      END LOOP;
        save_exception_log(v_xml_seq_id,NULL,NULL,NULL,v_bulk_error_msg,v_added_by,'split_claims_info',V_HOSP_SEQ_ID);
        ROLLBACK;
      WHEN OTHERS THEN
         V_SQL_CODE := SQLCODE;
         V_SQL_MSG  := SQLERRM; 
         
         save_exception_log(v_xml_seq_id,NULL,v_sql_code,v_sql_msg,NULL,v_added_by,'split_claims_info',V_HOSP_SEQ_ID);
         ROLLBACK;
         
END split_claims_info;                            
------------------------------------------------------------------------------------------------------
 PROCEDURE update_clm_seq_no(v_xml_seq_id       IN NUMBER,
                             v_qtr_claim_count  IN NUMBER,
                             v_ind_claim_count  IN NUMBER,
                             v_oth_claim_count  IN NUMBER,
                             v_file_mx_no       IN VARCHAR2
                             )
   IS
   PRAGMA AUTONOMOUS_TRANSACTION;
   
   BEGIN
       
       UPDATE APP.TPA_SEQ_NO_GEN_DETAILS S
         SET S.QTR_CLM_NO_MAX_SEQ_RCH = NVL(S.QTR_CLM_NO_MAX_SEQ_RCH,0) + v_qtr_claim_count,
           ----  S.IND_CLM_NO_MAX_SEQ_RCH = NVL(S.IND_CLM_NO_MAX_SEQ_RCH,0) + v_ind_claim_count,
           ----  S.OTH_CLM_NO_MAX_SEQ_RCH = NVL(S.OTH_CLM_NO_MAX_SEQ_RCH,0) + v_oth_claim_count,
             S.CLM_FILE_NO_MAX        = v_file_mx_no;
 
 COMMIT;
 END update_clm_seq_no; 
--======================================================================================================
PROCEDURE save_clm_batch_details(v_clm_batch_seq_id  in out clm_batch_upload_details.clm_batch_seq_id%type,
                                 v_batch_no          in out clm_batch_upload_details.batch_no%type,
                                 v_sender_id         in clm_batch_upload_details.sender_id%type,
                                 v_receiver_id       in clm_batch_upload_details.receiver_id%type,
                                 v_received_date     in clm_batch_upload_details.received_date%type,
                                 v_record_count      in clm_batch_upload_details.record_count%type,
                                 v_batch_tot_amount  in clm_batch_upload_details.batch_tot_amount%type,
                                 v_tpa_office_aeq_id in clm_batch_upload_details.tpa_office_aeq_id%type,
                                 v_batch_status_type in clm_batch_upload_details.batch_status_type%type,
                                 v_benefit_type      in clm_batch_upload_details.benefit_type%type,
                                 v_claim_type        in clm_batch_upload_details.clm_type_gen_type_id%type,
                                 v_submission_type   in clm_batch_upload_details.submission_type_id%type,
                                 v_currency_type     in clm_batch_upload_details.currency_type%type,
                                 v_source_type       in clm_batch_upload_details.source_type_id%type,
                                 v_added_by          in clm_batch_upload_details.added_by%type,
                                 v_xml_seq_id        in NUMBER) 
IS
                                
PRAGMA AUTONOMOUS_TRANSACTION;

CURSOR batch_cur(v_result VARCHAR2, v_length NUMBER) IS SELECT substr(MAX(d.batch_no),1,v_length)
                                          FROM clm_batch_upload_details d
                                         WHERE d.batch_no LIKE v_result||'%';
                                         
CURSOR encounter_cur IS SELECT case when c.general_type_id ='OPTS' then 'OP'
                                            when c.general_type_id ='IPT' then 'IP'
                                            when c.general_type_id = 'HEAC' then 'HC'
                                            when c.general_type_id = 'DAYC' then 'DC' 
                                            when c.general_type_id IN ('MTI', 'OMTI', 'IMTI') then 'MN'
                                            when c.general_type_id = 'DNTL' then 'DN'  
                                            when c.general_type_id = 'OPTC' then  'OC' end
                                          FROM tpa_general_code c
                                         WHERE c.header_type='BENIFIT_TYPE' 
                                         and c.general_type_id =v_benefit_type;                                        
   v_result            varchar2(1000);
   v_last_number       varchar2(100);
   v_flag              varchar2(10);
   v_clm_count         number;
   v_requested_amount  number;
   v_batch_len         number;
   v_trail             NUMBER(30);
   

Cursor batch_status_cur is 
 select ud.batch_status_type,ud.batch_tot_amount 
  from app.clm_batch_upload_details ud 
  where ud.clm_batch_seq_id=v_clm_batch_seq_id;

status_rec    batch_status_cur%rowtype;   

CURSOR batch_len_cur(v_clm_type VARCHAR2) IS
  select max(length(b.batch_no))
  from clm_batch_upload_details b
  where b.batch_no like v_clm_type||'%'
  and to_date(b.added_date, 'DD-MM-RRRR') = to_date(sysdate, 'DD-MM-RRRR');
  v_sql_code      VARCHAR2(100);
  v_sql_msg       VARCHAR2(2000);
  
  
BEGIN
  
 IF NVL(v_clm_batch_seq_id, 0) = 0 THEN
    
    OPEN batch_len_cur(case when v_claim_type = 'CNH' then 'NC' else 'MR' end);
    FETCH batch_len_cur INTO v_batch_len;
    CLOSE batch_len_cur;
    
    IF v_batch_no IS NULL THEN
      IF v_claim_type = 'CNH' THEN
       v_result:= 'NC'||'-'||substr(lpad(v_sender_id,length(v_sender_id),0),-length(v_sender_id))||'-'||to_char(sysdate,'ddmmyyyy')||'-';
       ELSE 
        v_result:= 'MR'||'-'||'00001'||'-'||to_char(sysdate,'ddmmrrrr')||'-'; 
      END IF;
      
      OPEN batch_cur(v_result, v_batch_len);
      FETCH batch_cur INTO v_last_number;
      CLOSE batch_cur;
      
      v_last_number := trim(trailing '-' from v_last_number);
      
      OPEN encounter_cur;
      FETCH encounter_cur INTO v_flag;
      CLOSE encounter_cur;
      
      IF v_last_number IS NULL THEN
        v_result := v_result || '01';
      ELSE
        if v_last_number like '%R' Then
          v_last_number := TRIM(TRAILING 'R' FROM v_last_number);
          v_last_number := trim(trailing '-' from v_last_number);
		      v_result := v_result ||lpad(TO_NUMBER(substr(v_last_number,-2,2))+1,2,'0');
        else
         v_result := v_result ||lpad(TO_NUMBER(substr(v_last_number,-2,2))+1,2,'0');
        end if;
      END IF;
      IF v_submission_type='DTR' then
       --v_batch_no:=v_result||'-'||v_flag||'-'||'R';
       v_batch_no:=v_result||'-'||'R';
      ELSE
      --v_batch_no:=v_result||'-'||v_flag;
      v_batch_no:=v_result;
      END IF;
    END IF;
    
    INSERT INTO clm_batch_upload_details
      (CLM_BATCH_SEQ_ID,
       BATCH_NO,
       SENDER_ID,
       RECEIVER_ID,
       RECEIVED_DATE,
       TRANSACTION_DATE,
       RECORD_COUNT,
       DISPOSITION_FLAG,
       BATCH_TOT_AMOUNT,
       TPA_OFFICE_AEQ_ID,
       BATCH_STATUS_TYPE,
       clm_type_gen_type_id,
       submission_type_id,
       ADDED_BY,
       ADDED_DATE,
       CURRENCY_TYPE,
       SOURCE_TYPE_ID,
       benefit_type,
       NETWORK_YN,
       XML_SEQ_ID)
    VALUES
      (clm_batch_upload_detail_SEQ.Nextval,
       V_BATCH_NO,
       V_SENDER_ID,
       V_RECEIVER_ID,
       V_RECEIVED_DATE,
       SYSDATE,
       V_RECORD_COUNT,
       'PRODUCTION',
       V_BATCH_TOT_AMOUNT,
       V_TPA_OFFICE_AEQ_ID,
       V_BATCH_STATUS_TYPE,
       v_claim_type,
       v_submission_type,
       V_ADDED_BY,
       SYSDATE,
       v_currency_type,
       v_source_type,
       v_benefit_type,
       'Y',
        v_xml_seq_id) RETURNING CLM_BATCH_SEQ_ID INTO v_clm_batch_seq_id; 
    
  END IF;

COMMIT;
 EXCEPTION
    WHEN OTHERS THEN
     v_sql_code := sqlcode;      v_sql_msg  := sqlerrm; 
     save_exception_log(v_xml_seq_id,NULL,v_sql_code,v_sql_msg,NULL,v_added_by,'save_clm_batch_details',NULL);
     ROLLBACK;
END save_clm_batch_details;  
------------------------------------------------------------------------------------------------------  
PROCEDURE save_claim_details(v_xml_seq_id            IN NUMBER,
                             v_clm_batch_seq_id      IN clm_batch_upload_details.clm_batch_seq_id%type,
                             v_batch_no              OUT clm_batch_upload_details.batch_no%type,
                             v_added_by              IN NUMBER)
  IS

 CURSOR cur_claim_info(v_qtr_clm_mx_seq  VARCHAR2,v_ind_clm_mx_seq  VARCHAR2,v_oth_clm_mx_seq  VARCHAR2,v_file_no_max_seq VARCHAR2) IS
  WITH CLAIM_INFO AS 
   (SELECT C.CLM_XML_SEQ_ID,C.CLM_BATCH_SEQ_ID,PA.PAT_AUTH_SEQ_ID,pa.mat_complcton_yn,
          CASE WHEN A.COUNTRY_ID IN (134,73) THEN 117 
              ---- WHEN A.COUNTRY_ID = 73 THEN 227
                 ELSE 117 END AS CLM_START_NO,
          CB.RECEIVED_DATE,CB.SOURCE_TYPE_ID,C.DATE_TREATMENT,C.DATE_DISCHARGE,
          'CNH' AS CLAIM_TYPE,NULL AS claim_sub_type,
          C.MEMBER_SEQ_ID,C.MEMBER_ID,M.MEM_NAME AS MEMBER_NAME,M.MEM_AGE,
          EP.INS_SEQ_ID,EP.POLICY_SEQ_ID,EP.ENROL_TYPE_ID,M.EMIRATE_ID,
          C.ENCNTR_TYPE_ID, 1 AS encounter_start_type, 1 AS encounter_end_type,
          NULL AS ENCOUNTER_FACILITY_ID,(NVL(B.SUM_INSURED,0) - NVL(B.UTILISED_SUM_INSURED,0)) AS AVA_SUM_INSURED,
          'QAR' AS currency_type,'INP' AS clm_status_type_id,
          check_prior_apr_dnl_desc(c.member_seq_id,ep.policy_seq_id,m.vip_yn,'CNH',(C.REQUESTED_AMOUNT),C.PREAPPROVAL_NO,EP.ENROL_TYPE_ID) AS denial_reason,
          c.added_by,C.INVOICE_NO,C.requested_amount,
          get_clinician_id(C.CLM_XML_SEQ_ID) AS CLINICIAN_ID,C.SOM_TPY_ID AS system_of_medicine_type_id,NULL AS accident_related_type_id,
          NULL AS priority_general_type_id,'Y' AS network_yn,C.BENF_TPY_ID AS benifit_type,
          NULL AS medical_opinion_remarks,'ALK01' AS payer_id,
          check_prior_apr_dnl_code(c.member_seq_id,ep.policy_seq_id,m.vip_yn,'CNH',C.REQUESTED_AMOUNT,C.PREAPPROVAL_NO,EP.ENROL_TYPE_ID) AS denial_code,
          PA.TOT_APPROVED_AMOUNT AS pat_approved_amount,
          C.NAT_CONCP_TPY_ID AS Conception_Type,NVL(PA.LMP_DATE,get_lmp_date(C.CLM_XML_SEQ_ID)) AS LMP_DATE,
          NULL AS resub_type,NULL AS Re_Submission_Remarks,
          C.FIRST_INCIDENT_DATE,C.FIRST_REPORTED_DATE,
          PA.AUTH_NUMBER,1 AS CONVERSION_RATE,'QAR' AS req_amt_currency_type,
          C.EVENT_REF_NO AS event_no,NULL AS SOURCE_FROM,NULL AS delvry_mod_type,
          get_symptoms(C.CLM_XML_SEQ_ID) AS symptoms,
          C.TREATMENT_TYPE
       
    FROM APP.CLM_BULK_UPLD_CLM_DETAILS C
    JOIN APP.CLM_BATCH_UPLOAD_DETAILS CB ON (C.CLM_BATCH_SEQ_ID=CB.CLM_BATCH_SEQ_ID)
    JOIN APP.TPA_ENR_POLICY_MEMBER M ON (C.MEMBER_SEQ_ID=M.MEMBER_SEQ_ID)
    JOIN APP.TPA_ENR_POLICY_GROUP PG ON (M.POLICY_GROUP_SEQ_ID=PG.POLICY_GROUP_SEQ_ID)
    JOIN APP.TPA_ENR_MEM_ADDRESS A ON (PG.ENR_ADDRESS_SEQ_ID=A.ENR_ADDRESS_SEQ_ID)
    JOIN APP.TPA_ENR_POLICY EP ON (PG.POLICY_SEQ_ID=EP.POLICY_SEQ_ID)
    LEFT OUTER JOIN TPA_ENR_BALANCE B ON (PG.POLICY_GROUP_SEQ_ID=B.POLICY_GROUP_SEQ_ID)
    LEFT OUTER JOIN APP.PAT_AUTHORIZATION_DETAILS PA ON (C.PREAPPROVAL_NO=PA.PRE_AUTH_NUMBER AND PA.PAT_ENHANCED_YN = 'N')
    WHERE C.XML_SEQ_ID = v_xml_seq_id
     AND (M.MEM_GENERAL_TYPE_ID != 'PFL' AND M.MEMBER_SEQ_ID = B.MEMBER_SEQ_ID OR B.MEMBER_SEQ_ID IS NULL OR M.MEMBER_SEQ_ID IS NULL)
     )
  SELECT CLM_XML_SEQ_ID,CLM_BATCH_SEQ_ID,PAT_AUTH_SEQ_ID,
         CASE WHEN CLM_START_NO IN (117,227) THEN TO_CHAR(CLM_START_NO)
             ---- WHEN CLM_START_NO = 227 THEN v_ind_clm_mx_seq
              ELSE v_qtr_clm_mx_seq END/*+ROW_NUMBER() OVER (PARTITION BY CLM_START_NO ORDER BY CLM_XML_SEQ_ID)*/ AS CLAIM_NUMBER,
         RECEIVED_DATE,SOURCE_TYPE_ID,DATE_TREATMENT,
         DATE_DISCHARGE,CLAIM_TYPE,CLAIM_SUB_TYPE,MEMBER_SEQ_ID,MEMBER_ID,MEMBER_NAME,
         MEM_AGE,INS_SEQ_ID,POLICY_SEQ_ID,ENROL_TYPE_ID,EMIRATE_ID,ENCNTR_TYPE_ID,
         ENCOUNTER_START_TYPE,ENCOUNTER_END_TYPE,ENCOUNTER_FACILITY_ID,AVA_SUM_INSURED,
         CURRENCY_TYPE,CLM_STATUS_TYPE_ID,DENIAL_REASON,ADDED_BY,INVOICE_NO,REQUESTED_AMOUNT,
         CLINICIAN_ID,SYSTEM_OF_MEDICINE_TYPE_ID,ACCIDENT_RELATED_TYPE_ID,PRIORITY_GENERAL_TYPE_ID,
         NETWORK_YN,BENIFIT_TYPE,MEDICAL_OPINION_REMARKS,PAYER_ID,DENIAL_CODE,
         PAT_APPROVED_AMOUNT,CONCEPTION_TYPE,LMP_DATE,REQ_AMT_CURRENCY_TYPE,CONVERSION_RATE,
         DELVRY_MOD_TYPE,EVENT_NO,SYMPTOMS,TREATMENT_TYPE,
         'FL-'||TO_CHAR(SYSDATE,'DDMMYYYY')||'-'||LPAD((v_file_no_max_seq+(ROW_NUMBER() OVER (ORDER BY CLM_XML_SEQ_ID))),5,'0') AS CLM_FILE_NO,
         mat_complcton_yn
 
  FROM CLAIM_INFO
  ORDER BY CLM_XML_SEQ_ID;
  
  CURSOR hosp_cur(v_hos_seq_id NUMBER) IS
    SELECT t.hosp_seq_id,t.hosp_licenc_numb, t.hosp_name, ha.address_1, ha.city_type_id, ha.state_type_id, ha.pin_code, t.primary_network,
           t.off_phone_no_1, t.office_fax_no, t.empanel_number,ha.country_id
    FROM Tpa_Hosp_Info t
    JOIN tpa_hosp_address ha   ON (ha.hosp_seq_id = t.hosp_seq_id)
    WHERE t.hosp_seq_id = v_hos_seq_id;
    
  hosp_rec hosp_cur%ROWTYPE;   
  
 CURSOR cur_uplded_clm_info IS
   SELECT CA.CLAIM_SEQ_ID,
          get_clinician_nme(BC.CLM_XML_SEQ_ID) AS CLINICIAN_NAME,
          T.HOSP_SEQ_ID,T.HOSP_LICENC_NUMB, T.HOSP_NAME, HA.ADDRESS_1, HA.CITY_TYPE_ID, HA.STATE_TYPE_ID, HA.PIN_CODE, T.PRIMARY_NETWORK,
          T.OFF_PHONE_NO_1, T.OFFICE_FAX_NO, T.EMPANEL_NUMBER,HA.COUNTRY_ID,BC.ADDED_BY
   FROM APP.CLM_BULK_UPLD_CLM_DETAILS BC
   JOIN APP.CLM_AUTHORIZATION_DETAILS CA ON (BC.CLAIM_SEQ_ID=CA.CLAIM_SEQ_ID)
   JOIN APP.TPA_HOSP_INFO T ON (BC.HOSP_SEQ_ID=T.HOSP_SEQ_ID)
   JOIN APP.TPA_HOSP_ADDRESS HA ON (HA.HOSP_SEQ_ID = T.HOSP_SEQ_ID)
   WHERE BC.XML_SEQ_ID = V_XML_SEQ_ID;
   
 CURSOR cur_diag_info IS  
   SELECT C.CLAIM_SEQ_ID,NVL(A10.ICD_CODE,C10.ICD_CODE) AS DIAGNOSYS_CODE,D.PRIMARY_AILMENT_YN,
          NVL(A10.ICD10_SEQ_ID,C10.ICD10_SEQ_ID) AS ICD10_SEQ_ID,
          C.ADDED_BY
    FROM APP.CLM_BULK_UPLD_DIAG_DETAILS D 
    JOIN APP.CLM_BULK_UPLD_CLM_DETAILS C ON (D.CLM_XML_SEQ_ID=C.CLM_XML_SEQ_ID)
    LEFT OUTER JOIN APP.TPA_ICD_AM_DETAILS IA ON (D.DIAGNOSYS_CODE=IA.ICD_AM)
    LEFT OUTER JOIN APP.TPA_ICD10_MASTER_DETAILS A10 ON (IA.ICD_CM=A10.ICD_CODE)
    LEFT OUTER JOIN APP.TPA_ICD10_MASTER_DETAILS C10 ON (D.DIAGNOSYS_CODE=C10.ICD_CODE)
    WHERE D.XML_SEQ_ID = v_xml_seq_id
    ORDER BY D.CLAIM_SEQ_ID,D.PRIMARY_AILMENT_YN DESC;  
 /*   
  CURSOR cur_activity_info IS  
   SELECT A.*,ROW_NUMBER() OVER (PARTITION BY CLAIM_SEQ_ID ORDER BY CLAIM_SEQ_ID) AS SL_NO FROM  
    (WITH ACT_DATA AS 
     (SELECT C.CLAIM_SEQ_ID,AM.ACT_MAS_DTL_SEQ_ID,A.SERVICE_DATE,AC.ACTIVITY_TYPE_ID AS ACTIVITY_TYPE,
           NVL(AM.ACTIVITY_CODE,'ACTIVITY') AS ACTIVITY_CODE,A.INTERNAL_SERVICE_CODE,A.QUANTITY,
           'Y' AS ALLOW_YN,
           NVL(T.GROSS_AMOUNT*A.QUANTITY,A.AMOUNT_CLAIMED) AS GROSS_AMOUNT,
           NVL(T.DISC_AMOUNT,0)*NVL(A.QUANTITY,0) AS DISCOUNT_AMOUNT,
           NVL((T.GROSS_AMOUNT-T.DISC_AMOUNT)*A.QUANTITY,A.AMOUNT_CLAIMED) AS DISC_GROSS_AMOUNT,
           0 AS PATIENT_SHARE_AMOUNT,
           NVL((T.GROSS_AMOUNT-T.DISC_AMOUNT)*A.QUANTITY,A.AMOUNT_CLAIMED) AS NET_AMOUNT,
           'QAR' AS CURRENCY_TYPE,
           A.QUANTITY AS APPROVD_QUANTITY,--
           NVL(NVL(AM.UNIT_PRICE,T.GROSS_AMOUNT),A.AMOUNT_CLAIMED/A.QUANTITY) AS UNIT_PRICE,
           NVL(T.DISC_AMOUNT,0) AS UNIT_DISCOUNT_AMOUNT,
           'N' AS OVERRIDE_YN,
           A.AMOUNT_CLAIMED AS PROVIDER_NET_AMOUNT,
           'Y' AS APPROVE_YN,
           NVL(NVL(AM.UNIT_PRICE,T.GROSS_AMOUNT),A.AMOUNT_CLAIMED/A.QUANTITY) AS CONVERTED_ACITIVTY_AMT,
           NVL(T.INTERNAL_DESC,A.SERVICE_DESCRIPTION) AS INTERNAL_DESC,
           REPLACE(A.TOOTH_NUMBER,',','|') AS TOOTH_NUMBER,
           'ACT' AS ACTIVITY_TYPE_ID,
           A.ADDED_BY,
           PRODUCT_CAT_TYPE_ID,
           NETWORK_TYPE,
           ROW_NUMBER() OVER (PARTITION BY A.CLM_XML_ACT_SEQ_ID ORDER BY T.SORT_NO) AS RNK,
           T.SORT_NO AS TARIFF_NWK_RNK,
           PN.SORT_NO AS PROD_NWK_RNK
        FROM APP.CLM_BULK_UPLD_ACT_DETAILS A 
        JOIN APP.CLM_BULK_UPLD_CLM_DETAILS C ON (A.CLM_XML_SEQ_ID=C.CLM_XML_SEQ_ID)
        LEFT OUTER JOIN APP.TPA_ENR_POLICY_MEMBER M ON (C.MEMBER_SEQ_ID=M.MEMBER_SEQ_ID)
        LEFT OUTER JOIN APP.TPA_ENR_POLICY_GROUP PG ON (M.POLICY_GROUP_SEQ_ID=PG.POLICY_GROUP_SEQ_ID)
        LEFT OUTER JOIN APP.TPA_ENR_POLICY EP ON (PG.POLICY_SEQ_ID=EP.POLICY_SEQ_ID)
        LEFT OUTER JOIN APP.TPA_INS_PRODUCT P ON (EP.PRODUCT_SEQ_ID=P.PRODUCT_SEQ_ID)
        LEFT OUTER JOIN APP.TPA_HOSP_INFO I ON (C.HOSP_SEQ_ID=I.HOSP_SEQ_ID)
        LEFT OUTER JOIN APP.TPA_GENERAL_CODE PN ON (P.PRODUCT_CAT_TYPE_ID = PN.GENERAL_TYPE_ID AND PN.HEADER_TYPE = 'PROVIDER_NETWORK')
        LEFT OUTER JOIN (SELECT T.HOSP_TARIFF_SEQ_ID,T.ACTIVITY_SEQ_ID,T.HOSP_SEQ_ID,T.GROSS_AMOUNT,T.DISC_AMOUNT,T.INTERNAL_CODE,
                                T.INTERNAL_DESC,T.START_DATE,T.END_DATE,TN.SORT_NO,T.NETWORK_TYPE
                          FROM APP.TPA_HOSP_TARIFF_DETAILS T
                          LEFT OUTER JOIN APP.TPA_GENERAL_CODE TN ON (T.NETWORK_TYPE = TN.GENERAL_TYPE_ID AND TN.HEADER_TYPE = 'PROVIDER_NETWORK')                          
                         ) T ON (A.INTERNAL_SERVICE_CODE=T.INTERNAL_CODE  
                                 AND C.HOSP_SEQ_ID=T.HOSP_SEQ_ID 
                                 AND A.SERVICE_DATE BETWEEN T.START_DATE AND NVL(T.END_DATE,TRUNC(SYSDATE))
                                 AND ((PRODUCT_CAT_TYPE_ID = NETWORK_TYPE) OR (PN.SORT_NO <= T.SORT_NO ))
                                     )          
        LEFT OUTER JOIN APP.TPA_ACTIVITY_MASTER_DETAILS AM ON (T.ACTIVITY_SEQ_ID=AM.ACT_MAS_DTL_SEQ_ID)
        LEFT OUTER JOIN tpa_activity_type_codes AC ON (AM.activity_type_seq_id=AC.activity_type_seq_id)
        WHERE C.XML_SEQ_ID = v_xml_seq_id
        AND A.ACT_TPY_ID = 'ACT') 
      SELECT * FROM ACT_DATA
      WHERE RNK = 1
    UNION ALL
      SELECT C.CLAIM_SEQ_ID,PM.ACT_MAS_DTL_SEQ_ID,A.SERVICE_DATE,AC.ACTIVITY_TYPE_ID AS ACTIVITY_TYPE,
           NVL(PM.ACTIVITY_CODE,'PHARMA') AS ACTIVITY_CODE,
           NULL AS INTERNAL_SERVICE_CODE,A.QUANTITY,
           'Y' AS ALLOW_YN,
           NVL(NVL((PM.UNIT_PRICE * A.QUANTITY),A.AMOUNT_CLAIMED),0) AS GROSS_AMOUNT,
           0 AS DISCOUNT_AMOUNT,
           NVL(NVL((PM.UNIT_PRICE * A.QUANTITY),A.AMOUNT_CLAIMED),0) AS DISC_GROSS_AMOUNT,
           0 AS PATIENT_SHARE_AMOUNT,
           NVL(NVL((PM.UNIT_PRICE * A.QUANTITY),A.AMOUNT_CLAIMED),0) AS NET_AMOUNT,
           'QAR' AS CURRENCY_TYPE,
           A.QUANTITY AS APPROVD_QUANTITY,--
           (NVL(PM.UNIT_PRICE,A.AMOUNT_CLAIMED/A.QUANTITY)) AS UNIT_PRICE,
           0 AS UNIT_DISCOUNT_AMOUNT,
           'N' AS OVERRIDE_YN,
           A.AMOUNT_CLAIMED AS PROVIDER_NET_AMOUNT,
           'Y' AS APPROVE_YN,
           (NVL(PM.UNIT_PRICE,A.AMOUNT_CLAIMED/A.QUANTITY)) AS CONVERTED_ACITIVTY_AMT,
           A.SERVICE_DESCRIPTION AS INTERNAL_DESC,
           A.TOOTH_NUMBER,
           'DRG' AS ACTIVITY_TYPE_ID,
           A.ADDED_BY,
           NULL AS PRODUCT_CAT_TYPE_ID,
           NULL AS NETWORK_TYPE,
           NULL AS RNK,
           NULL AS TARIFF_NWK_RNK,
           NULL AS PROD_NWK_RNK
        FROM APP.CLM_BULK_UPLD_ACT_DETAILS A 
        JOIN APP.CLM_BULK_UPLD_CLM_DETAILS C ON (A.CLM_XML_SEQ_ID=C.CLM_XML_SEQ_ID)
        LEFT OUTER JOIN APP.TPA_PHARMACY_MASTER_DETAILS PM ON (A.CPT_CODE=PM.ACTIVITY_CODE)
        LEFT OUTER JOIN tpa_activity_type_codes AC ON (PM.ACTIVITY_TYPE_SEQ_ID=AC.activity_type_seq_id)
        WHERE C.XML_SEQ_ID = v_xml_seq_id
        AND A.ACT_TPY_ID = 'DRG') A
       ORDER BY CLAIM_SEQ_ID;*/
     
 
CURSOR cur_activity_info IS  
    WITH ACT_DATA AS 
     (SELECT C.CLAIM_SEQ_ID, case when t.activity_seq_id is null and a.cpt_code is null and a.moph_codes is not null then phar.ACT_MAS_DTL_SEQ_ID else NVL(AM.ACT_MAS_DTL_SEQ_ID, AM1.ACT_MAS_DTL_SEQ_ID) end AS ACT_MAS_DTL_SEQ_ID,A.SERVICE_DATE, case when t.activity_seq_id is null and a.cpt_code is null and a.moph_codes is not null then AC1.ACTIVITY_TYPE_ID else AC.ACTIVITY_TYPE_ID end AS ACTIVITY_TYPE,
             CASE WHEN A.INTERNAL_SERVICE_CODE IS NOT NULL AND T.SERVICE_SEQ_ID IN (7, 14) THEN 
                      NVL(AM.ACTIVITY_CODE, AM1.ACTIVITY_CODE)
                  --WHEN A.INTERNAL_SERVICE_CODE IS NULL AND A.CPT_CODE IS NOT NULL THEN 
                  WHEN A.INTERNAL_SERVICE_CODE IS NULL AND A.CPT_CODE IS NOT NULL AND NVL(T.SERVICE_SEQ_ID, AM1.SERVICE_SEQ_ID) IN (7, 14) THEN
                    --CASE WHEN NVL(T.SERVICE_SEQ_ID, AM1.SERVICE_SEQ_ID) IN (7, 14) THEN 
                       NVL(AM.ACTIVITY_CODE, AM1.ACTIVITY_CODE)
                    --END
                  WHEN A.INTERNAL_SERVICE_CODE IS NULL AND A.CPT_CODE ='PHARMA' AND A.MOPH_CODES IS NOT NULL AND PHAR.SERVICE_SEQ_ID IN(14) THEN
                    NVL(PHAR.ACTIVITY_CODE,'PHARMA')
                  WHEN AM.SERVICE_SEQ_ID NOT IN (7, 14) THEN
                     AM.ACTIVITY_CODE
             ELSE
               CASE WHEN A.ACT_TPY_ID = 'DRG' THEN
                 'PHARMA' 
               ELSE 
                 'ACTIVITY' 
               END
             END AS ACTIVITY_CODE,
           A.INTERNAL_SERVICE_CODE,
           A.service_description,
           A.QUANTITY,
           'Y' AS ALLOW_YN,
           CASE WHEN NVL(T.SERVICE_SEQ_ID, AM1.SERVICE_SEQ_ID) IN (7, 14)THEN
                   CASE WHEN T.GROSS_AMOUNT > 0 THEN ROUND(NVL((CASE WHEN A.INTERNAL_SERVICE_CODE IS NOT NULL THEN (CASE WHEN A.UNIT_TYPE='LSE' THEN NVL(T.GROSS_AMOUNT,(A.AMOUNT_CLAIMED/A.QUANTITY)) WHEN A.UNIT_TYPE='PKG' THEN NVL(NVL(T.PACKAGE_PRICE,(T.GROSS_AMOUNT*T.PACKAGE_SIZE)),(A.AMOUNT_CLAIMED/A.QUANTITY))ELSE T.GROSS_AMOUNT END)  ELSE AM1.UNIT_PRICE END * A.QUANTITY), 0), 2) ELSE A.AMOUNT_CLAIMED END
                WHEN T.SERVICE_SEQ_ID NOT IN (7, 14) THEN
                 ROUND((T.GROSS_AMOUNT*A.QUANTITY), 2)
           ELSE
               A.AMOUNT_CLAIMED
           END AS GROSS_AMOUNT,
           CASE WHEN T.SERVICE_SEQ_ID IN (7, 14) THEN
                CASE WHEN T.GROSS_AMOUNT > 0 THEN 
                  ROUND(((NVL(CASE WHEN A.UNIT_TYPE='LSE' THEN NVL(T.GROSS_AMOUNT,A.AMOUNT_CLAIMED) WHEN A.UNIT_TYPE='PKG' THEN NVL(NVL(T.PACKAGE_PRICE,(T.GROSS_AMOUNT*T.PACKAGE_SIZE)),A.AMOUNT_CLAIMED) ELSE T.GROSS_AMOUNT END,0)) * T.DISC_PERCENT / 100) * NVL(A.QUANTITY,0), 2)
                ELSE
                  0
                END
                WHEN T.SERVICE_SEQ_ID NOT IN (7, 14) THEN
                  NVL(T.DISC_AMOUNT,0)*NVL(A.QUANTITY,0)
           END AS DISCOUNT_AMOUNT,
           
           CASE WHEN NVL(T.SERVICE_SEQ_ID, AM1.SERVICE_SEQ_ID) IN (7, 14) THEN 
                   CASE WHEN T.GROSS_AMOUNT > 0 THEN ROUND(NVL(CASE WHEN A.INTERNAL_SERVICE_CODE IS NOT NULL THEN ROUND((CASE WHEN A.UNIT_TYPE='LSE' THEN NVL(T.GROSS_AMOUNT,(A.AMOUNT_CLAIMED/A.QUANTITY)) WHEN A.UNIT_TYPE='PKG' THEN NVL(NVL(T.PACKAGE_PRICE,(T.GROSS_AMOUNT*T.PACKAGE_SIZE)),(A.AMOUNT_CLAIMED/A.QUANTITY)) ELSE T.GROSS_AMOUNT END - ((CASE WHEN A.UNIT_TYPE='LSE' THEN NVL(T.GROSS_AMOUNT,(A.AMOUNT_CLAIMED/A.QUANTITY)) WHEN A.UNIT_TYPE='PKG' THEN NVL(NVL(T.PACKAGE_PRICE,(T.GROSS_AMOUNT*T.PACKAGE_SIZE)),(A.AMOUNT_CLAIMED/A.QUANTITY)) ELSE T.GROSS_AMOUNT END) * T.DISC_PERCENT / 100)), 2) ELSE AM1.UNIT_PRICE END * NVL(A.QUANTITY,0), CASE WHEN A.UNIT_TYPE='LSE' THEN NVL(T.GROSS_AMOUNT,0) WHEN A.UNIT_TYPE='PKG' THEN NVL(T.PACKAGE_PRICE,(T.GROSS_AMOUNT*T.PACKAGE_SIZE)) ELSE NVL(T.GROSS_AMOUNT,0) END), 2) ELSE A.AMOUNT_CLAIMED END
                WHEN T.SERVICE_SEQ_ID NOT IN (7, 14) THEN
                   ROUND((NVL(T.GROSS_AMOUNT,0)-NVL(T.DISC_AMOUNT,0))*NVL(A.QUANTITY,0), 2)
           ELSE
               A.AMOUNT_CLAIMED
           END AS DISC_GROSS_AMOUNT,
           
           0 AS PATIENT_SHARE_AMOUNT,
           
           CASE WHEN NVL(T.SERVICE_SEQ_ID, AM1.SERVICE_SEQ_ID) IN (7, 14) THEN
                  CASE WHEN T.GROSS_AMOUNT > 0 THEN ROUND(NVL(CASE WHEN A.INTERNAL_SERVICE_CODE IS NOT NULL THEN ROUND((CASE WHEN A.UNIT_TYPE='LSE' THEN NVL(T.GROSS_AMOUNT,(A.AMOUNT_CLAIMED/A.QUANTITY)) WHEN A.UNIT_TYPE='PKG' THEN NVL(NVL(T.PACKAGE_PRICE,(T.GROSS_AMOUNT*T.PACKAGE_SIZE)),(A.AMOUNT_CLAIMED/A.QUANTITY)) ELSE T.GROSS_AMOUNT END - ((CASE WHEN A.UNIT_TYPE='LSE' THEN NVL(T.GROSS_AMOUNT,(A.AMOUNT_CLAIMED/A.QUANTITY)) WHEN A.UNIT_TYPE='PKG' THEN NVL(NVL(T.PACKAGE_PRICE,(T.GROSS_AMOUNT*T.PACKAGE_SIZE)),(A.AMOUNT_CLAIMED/A.QUANTITY)) ELSE T.GROSS_AMOUNT END) * T.DISC_PERCENT / 100)), 2) ELSE AM1.UNIT_PRICE END * NVL(A.QUANTITY,0), NVL(T.GROSS_AMOUNT,0)), 2) ELSE A.AMOUNT_CLAIMED END
                WHEN T.SERVICE_SEQ_ID NOT IN (7, 14) THEN
                  ROUND(NVL((NVL(T.GROSS_AMOUNT,0)-NVL(T.DISC_AMOUNT,0))*NVL(A.QUANTITY,0), 0), 2)
           ELSE
              A.AMOUNT_CLAIMED
           END AS NET_AMOUNT,
           'QAR' AS CURRENCY_TYPE,
           
           A.QUANTITY AS APPROVD_QUANTITY,--
           
           CASE WHEN NVL(T.SERVICE_SEQ_ID, AM1.SERVICE_SEQ_ID) IN (7, 14) THEN 
                   CASE WHEN T.GROSS_AMOUNT > 0 THEN NVL((CASE WHEN A.UNIT_TYPE='LSE' THEN NVL(T.GROSS_AMOUNT,(A.AMOUNT_CLAIMED/A.QUANTITY)) WHEN A.UNIT_TYPE='PKG' THEN NVL(NVL(T.PACKAGE_PRICE,(T.GROSS_AMOUNT*T.PACKAGE_SIZE)),A.AMOUNT_CLAIMED/A.QUANTITY) ELSE T.GROSS_AMOUNT END), AM1.UNIT_PRICE) ELSE A.AMOUNT_CLAIMED / A.QUANTITY END
                WHEN T.SERVICE_SEQ_ID NOT IN (7, 14) THEN
                  NVL(T.GROSS_AMOUNT, AM.UNIT_PRICE)
           ELSE
             ROUND((A.AMOUNT_CLAIMED/A.QUANTITY), 2)
           END AS UNIT_PRICE,
           
           CASE WHEN T.SERVICE_SEQ_ID IN (7, 14) THEN 
                CASE WHEN T.GROSS_AMOUNT > 0 THEN
                  ROUND((NVL(CASE WHEN A.UNIT_TYPE='LSE' THEN NVL(T.GROSS_AMOUNT,(A.AMOUNT_CLAIMED/A.QUANTITY)) WHEN A.UNIT_TYPE='PKG' THEN NVL(NVL(T.PACKAGE_PRICE,(T.GROSS_AMOUNT*T.PACKAGE_SIZE)),(A.AMOUNT_CLAIMED/A.QUANTITY)) ELSE T.GROSS_AMOUNT END,0) * T.DISC_PERCENT / 100), 2)
                ELSE
                  0
                END
                WHEN T.SERVICE_SEQ_ID NOT IN (7, 14) THEN
                  NVL(T.DISC_AMOUNT,0)
                ELSE 
                  0
           END AS UNIT_DISCOUNT_AMOUNT,
           'N' AS OVERRIDE_YN,
           NVL(A.AMOUNT_CLAIMED, 0) AS PROVIDER_NET_AMOUNT,
           'Y' AS APPROVE_YN,
           
           CASE WHEN NVL(T.SERVICE_SEQ_ID, AM1.SERVICE_SEQ_ID) IN (7, 14) THEN
                  CASE WHEN T.GROSS_AMOUNT > 0 THEN
                    CASE WHEN NVL(NVL(CASE WHEN A.UNIT_TYPE='LSE' THEN NVL(T.GROSS_AMOUNT,(A.AMOUNT_CLAIMED/A.QUANTITY)) WHEN A.UNIT_TYPE='PKG' THEN NVL(NVL(T.PACKAGE_PRICE,(T.GROSS_AMOUNT*T.PACKAGE_SIZE)),(A.AMOUNT_CLAIMED/A.QUANTITY)) ELSE T.GROSS_AMOUNT END, AM1.UNIT_PRICE), 0) > 0 THEN
                      ROUND(NVL(CASE WHEN A.UNIT_TYPE='LSE' THEN NVL(T.GROSS_AMOUNT,(A.AMOUNT_CLAIMED/A.QUANTITY)) WHEN A.UNIT_TYPE='PKG' THEN NVL(NVL(T.PACKAGE_PRICE,(T.GROSS_AMOUNT*T.PACKAGE_SIZE)),(A.AMOUNT_CLAIMED/A.QUANTITY)) ELSE T.GROSS_AMOUNT END, AM1.UNIT_PRICE), 2)
                    END
                  ELSE
                    A.AMOUNT_CLAIMED / A.QUANTITY
                  END   
                WHEN T.SERVICE_SEQ_ID NOT IN (7, 14) THEN
                   ROUND(NVL(T.GROSS_AMOUNT, 0), 2)
           ELSE
              ROUND((A.AMOUNT_CLAIMED/A.QUANTITY), 2)
           END AS CONVERTED_ACITIVTY_AMT,
           CASE WHEN (T.SERVICE_SEQ_ID IN (7, 14)) OR (T.SERVICE_SEQ_ID NOT IN (7, 14)) THEN 
                  NVL(T.INTERNAL_DESC, NVL(AM.SHORT_DESCRIPTION, AM1.SHORT_DESCRIPTION))
           ELSE
                 A.SERVICE_DESCRIPTION
           END AS INTERNAL_DESC,
           REPLACE(A.TOOTH_NUMBER,',','|') AS TOOTH_NUMBER,
           CASE WHEN T.SERVICE_SEQ_ID IN (7, 14) THEN 'DRG'
                WHEN T.SERVICE_SEQ_ID NOT IN (7, 14) THEN 'ACT'
           ELSE
              A.ACT_TPY_ID
           END AS ACTIVITY_TYPE_ID,
           A.ADDED_BY,
           PRODUCT_CAT_TYPE_ID,
           NETWORK_TYPE,
           ROW_NUMBER() OVER (PARTITION BY A.CLM_XML_ACT_SEQ_ID ORDER BY T.SORT_NO) AS RNK,
           T.SORT_NO AS TARIFF_NWK_RNK,
           PN.SORT_NO AS PROD_NWK_RNK,
           A.DUR_MEDI,
           case A.UNIT_TYPE WHEN 'LSE' THEN 'LOSE' WHEN 'PKG' THEN 'PCKG' ELSE NULL END AS UNIT_TYPE,
           A.MOPH_CODES
           
        FROM APP.CLM_BULK_UPLD_ACT_DETAILS A 
        JOIN APP.CLM_BULK_UPLD_CLM_DETAILS C ON (A.CLM_XML_SEQ_ID=C.CLM_XML_SEQ_ID)
        LEFT OUTER JOIN APP.TPA_ENR_POLICY_MEMBER M ON (C.MEMBER_SEQ_ID=M.MEMBER_SEQ_ID)
        LEFT OUTER JOIN APP.TPA_ENR_POLICY_GROUP PG ON (M.POLICY_GROUP_SEQ_ID=PG.POLICY_GROUP_SEQ_ID)
        LEFT OUTER JOIN APP.TPA_ENR_POLICY EP ON (PG.POLICY_SEQ_ID=EP.POLICY_SEQ_ID)
        LEFT OUTER JOIN APP.TPA_INS_PRODUCT P ON (EP.PRODUCT_SEQ_ID=P.PRODUCT_SEQ_ID)
        LEFT OUTER JOIN APP.TPA_HOSP_INFO I ON (C.HOSP_SEQ_ID=I.HOSP_SEQ_ID)
        LEFT OUTER JOIN APP.TPA_GENERAL_CODE PN ON (P.PRODUCT_CAT_TYPE_ID = PN.GENERAL_TYPE_ID AND PN.HEADER_TYPE = 'PROVIDER_NETWORK')
        LEFT OUTER JOIN (SELECT T.HOSP_TARIFF_SEQ_ID,T.ACTIVITY_SEQ_ID,T.HOSP_SEQ_ID,T.GROSS_AMOUNT,T.DISC_AMOUNT,T.INTERNAL_CODE,
                                T.INTERNAL_DESC, T.START_DATE,T.END_DATE,TN.SORT_NO,T.NETWORK_TYPE, T.DISC_PERCENT, T.SERVICE_SEQ_ID,T.PACKAGE_PRICE,T.PACKAGE_SIZE
                          FROM APP.TPA_HOSP_TARIFF_DETAILS T
                          LEFT OUTER JOIN APP.TPA_GENERAL_CODE TN ON (T.NETWORK_TYPE = TN.GENERAL_TYPE_ID AND TN.HEADER_TYPE = 'PROVIDER_NETWORK')                          
                         ) T ON (A.INTERNAL_SERVICE_CODE=T.INTERNAL_CODE  
                                 AND C.HOSP_SEQ_ID=T.HOSP_SEQ_ID 
                                 AND A.SERVICE_DATE BETWEEN T.START_DATE AND NVL(T.END_DATE,TRUNC(SYSDATE))
                                 AND ((PRODUCT_CAT_TYPE_ID = NETWORK_TYPE) OR (PN.SORT_NO <= T.SORT_NO ))
                                     )          
        LEFT OUTER JOIN APP.TPA_ACTIVITY_MASTER_DETAILS AM ON (T.ACTIVITY_SEQ_ID=AM.ACT_MAS_DTL_SEQ_ID)
        LEFT OUTER JOIN APP.TPA_ACTIVITY_MASTER_DETAILS AM1 ON (A.CPT_CODE=AM1.ACTIVITY_CODE)
        LEFT OUTER JOIN tpa_activity_type_codes AC ON (AM.activity_type_seq_id=AC.activity_type_seq_id)
        LEFT OUTER JOIN TPA_PHARMACY_MASTER_DETAILS PHAR ON(A.MOPH_CODES=PHAR.MOPH_CODES)
        LEFT OUTER JOIN tpa_activity_type_codes AC1 ON(PHAR.activity_type_seq_id=AC1.activity_type_seq_id)
        WHERE C.XML_SEQ_ID = v_xml_seq_id) 
 
   SELECT A.*,ROW_NUMBER() OVER (PARTITION BY CLAIM_SEQ_ID ORDER BY CLAIM_SEQ_ID) AS SL_NO 
   FROM ACT_DATA A
   WHERE RNK = 1
   ORDER BY CLAIM_SEQ_ID;
     
 CURSOR cur_xml_claim_info IS
   SELECT C.SOURCE_TYPE,C.RECEIVED_DATE,C.HOSP_SEQ_ID
   FROM APP.CLM_BULK_UPLD_XML_DETAILS C
   WHERE C.XML_SEQ_ID = v_xml_seq_id
    AND ROWNUM = 1;
   
 rec_xml_claim_info                 cur_xml_claim_info%ROWTYPE; 
 
 CURSOR cur_asign_usr_info IS
   SELECT BC.CLAIM_SEQ_ID,B.ASSIGN_USERS_SEQ_ID
   FROM APP.CLM_BULK_UPLD_CLM_DETAILS BC
   JOIN ASSIGN_USERS B ON ( BC.CLAIM_SEQ_ID=B.CLAIM_SEQ_ID)
   WHERE BC.XML_SEQ_ID = v_xml_seq_id;
   
 CURSOR cur_obsr_dtls IS
   SELECT DISTINCT CA.CLAIM_SEQ_ID,A.ACTIVITY_DTL_SEQ_ID,BA.OBSERVATION
   FROM APP.CLM_BULK_UPLD_CLM_DETAILS BC
   JOIN APP.CLM_BULK_UPLD_ACT_DETAILS BA ON (BC.CLM_XML_SEQ_ID=BA.CLM_XML_SEQ_ID)
   JOIN APP.CLM_AUTHORIZATION_DETAILS CA ON (BC.CLAIM_SEQ_ID=CA.CLAIM_SEQ_ID)
   JOIN APP.PAT_ACTIVITY_DETAILS A ON (CA.CLAIM_SEQ_ID=A.CLAIM_SEQ_ID)
   WHERE BC.XML_SEQ_ID = v_xml_seq_id;
   
  CURSOR cur_xml_hosp_info IS
   SELECT xd.HOSP_SEQ_ID
   FROM APP.CLM_BULK_UPLD_XML_DTA xd
   WHERE xd.XML_SEQ_ID = v_xml_seq_id;    
   
 CURSOR cur_tot_claim_insrt_cnt IS
   SELECT COUNT(1)       
    FROM APP.CLM_BULK_UPLD_CLM_DETAILS C
    JOIN APP.TPA_ENR_POLICY_MEMBER M ON (C.MEMBER_SEQ_ID=M.MEMBER_SEQ_ID)
    JOIN APP.TPA_ENR_MEM_ADDRESS A ON (M.ENR_ADDRESS_SEQ_ID=A.ENR_ADDRESS_SEQ_ID)
    JOIN APP.TPA_ENR_POLICY_GROUP PG ON (M.POLICY_GROUP_SEQ_ID=PG.POLICY_GROUP_SEQ_ID)
    JOIN APP.TPA_ENR_POLICY EP ON (PG.POLICY_SEQ_ID=EP.POLICY_SEQ_ID)
    LEFT OUTER JOIN TPA_ENR_BALANCE B ON (PG.POLICY_GROUP_SEQ_ID=B.POLICY_GROUP_SEQ_ID)
    LEFT OUTER JOIN APP.PAT_AUTHORIZATION_DETAILS PA ON (C.PREAPPROVAL_NO=PA.PRE_AUTH_NUMBER AND PA.PAT_ENHANCED_YN = 'N')
    WHERE C.XML_SEQ_ID = v_xml_seq_id
     AND (M.MEM_GENERAL_TYPE_ID != 'PFL' 
     AND M.MEMBER_SEQ_ID = B.MEMBER_SEQ_ID OR B.MEMBER_SEQ_ID IS NULL OR M.MEMBER_SEQ_ID IS NULL);
   
  CURSOR cur_pat_seq_ids IS
   SELECT C.CLM_XML_SEQ_ID,C.CLAIM_SEQ_ID,PA.PAT_AUTH_SEQ_ID
   FROM APP.CLM_BULK_UPLD_CLM_DETAILS C
   JOIN APP.PAT_AUTHORIZATION_DETAILS PA ON (C.PREAPPROVAL_NO=PA.PRE_AUTH_NUMBER AND PA.PAT_ENHANCED_YN = 'N')
   WHERE C.XML_SEQ_ID =  v_xml_seq_id
     AND C.PREAPPROVAL_NO IS NOT NULL;
             
 
 TYPE typ_pat_seq_ids IS TABLE OF cur_pat_seq_ids%ROWTYPE INDEX BY PLS_INTEGER;
 rec_pat_seq_ids              typ_pat_seq_ids; 
        
 TYPE typ_clm_info IS TABLE OF cur_claim_info%ROWTYPE INDEX BY PLS_INTEGER;
 rec_clm_info              typ_clm_info;         
 TYPE typ_uplded_clm_info IS TABLE OF cur_uplded_clm_info%ROWTYPE INDEX BY PLS_INTEGER;
 rec_uplded_clm_info       typ_uplded_clm_info;
 TYPE typ_diag_info IS TABLE OF cur_diag_info%ROWTYPE INDEX BY PLS_INTEGER;
 rec_diag_info             typ_diag_info;  
 TYPE typ_activity_info IS TABLE OF cur_activity_info%ROWTYPE INDEX BY PLS_INTEGER;
 rec_activity_info         typ_activity_info;
 
 TYPE typ_asign_usr_info IS TABLE OF cur_asign_usr_info%ROWTYPE INDEX BY PLS_INTEGER;
 rec_asign_usr_info              typ_asign_usr_info; 
 
 TYPE typ_obsr_dtls IS TABLE OF cur_obsr_dtls%ROWTYPE INDEX BY PLS_INTEGER;
 rec_obsr_dtls              typ_obsr_dtls; 
 
  CURSOR cur_clm_seq_dtls IS
  SELECT NVL(G.QTR_CLM_NO_MAX_SEQ_RCH,0) AS QTR_CLM_NO_MAX_SEQ_RCH,
         NVL(G.IND_CLM_NO_MAX_SEQ_RCH,0) AS IND_CLM_NO_MAX_SEQ_RCH,
         NVL(G.OTH_CLM_NO_MAX_SEQ_RCH,0) AS OTH_CLM_NO_MAX_SEQ_RCH
  FROM APP.TPA_SEQ_NO_GEN_DETAILS G;
  
  rec_clm_seq_dtls          cur_clm_seq_dtls%ROWTYPE;
  
  CURSOR cur_clm_fl_mx_seq_dtls(v_file_no VARCHAR2) IS
  SELECT SUBSTR(G.CLM_FILE_NO_MAX,1,INSTR(G.CLM_FILE_NO_MAX,'-',-1)-1) AS FILE_NO_FRMT,
         (SUBSTR(G.CLM_FILE_NO_MAX,INSTR(G.CLM_FILE_NO_MAX,'-',-1)+1)) AS FILE_NO_MAX_SEQ
  FROM APP.TPA_SEQ_NO_GEN_DETAILS G
   WHERE G.CLM_FILE_NO_MAX LIKE v_file_no||'%';
  
   
  
  CURSOR cur_batch_sum IS
    SELECT ROUND(SUM(NVL(C.REQUESTED_AMOUNT,0)),2)
     FROM APP.CLM_BULK_UPLD_CLM_DETAILS C
    WHERE C.XML_SEQ_ID = v_xml_seq_id; 
    
    CURSOR update_pbm_beni_cur IS           
    SELECT DD.DIAGNOSYS_CODE ,CLM.CLAIM_SEQ_ID,CASE WHEN DD.DIAGNOSYS_CODE IS NOT NULL AND (DAM.ICD10_SEQ_ID IS NOT NULL OR D10.ICD10_SEQ_ID IS NOT NULL) THEN 'DNTL'
                               WHEN DD.DIAGNOSYS_CODE IS NOT NULL AND TIC.ICD_CODE_SEQ_ID IS NOT NULL THEN 'OMTI' ELSE 'OPTS' END AS BENIFIT_TYPE
                               FROM APP.diagnosys_details DD JOIN CLM_AUTHORIZATION_DETAILS CLM ON(DD.CLAIM_SEQ_ID=CLM.CLAIM_SEQ_ID)
                                                   JOIN APP.CLM_BULK_UPLD_CLM_DETAILS CBCL ON(CBCL.CLAIM_SEQ_ID=CLM.CLAIM_SEQ_ID)
                                                   LEFT OUTER JOIN APP.TPA_ICD_AM_DETAILS PAM ON (PAM.ICD_AM = DD.DIAGNOSYS_CODE)
                                                   LEFT OUTER JOIN APP.TPA_ICD10_MASTER_DETAILS DAM ON (PAM.ICD_CM=DAM.ICD_CODE AND DAM.BENEFIT_TYPE = 'DNTL')
                                                   LEFT OUTER JOIN APP.TPA_ICD10_MASTER_DETAILS D10 ON (D10.ICD_CODE = DD.DIAGNOSYS_CODE AND D10.BENEFIT_TYPE = 'DNTL')
                                                   LEFT OUTER JOIN APP.tpa_icd_codes TIC ON( TIC.ICD_CODE=DD.DIAGNOSYS_CODE AND TIC.MASTER_ICD_CODE='Z34.90') 
                                                   WHERE CBCL.XML_SEQ_ID=v_xml_seq_id AND DD.PRIMARY_AILMENT_YN='Y';
      
      TYPE update_pbm_beni_info IS TABLE OF update_pbm_beni_cur%ROWTYPE INDEX BY PLS_INTEGER;
      update_pbm_beni_rec      update_pbm_beni_info;                                              
 
  bulk_errors EXCEPTION;
  PRAGMA EXCEPTION_INIT(bulk_errors, -24381);
  l_error_count  NUMBER;
  
  v_sql_code                              VARCHAR2(100);
  v_sql_msg                               VARCHAR2(4000);
  v_bulk_error_msg                        CLOB;
  v_start_time                            NUMBER;
  v_qtr_claim_count                       NUMBER(10);  
  v_ind_claim_count                       NUMBER(10);                                              
  v_oth_claim_count                       NUMBER(10);
  v_tot_claim_cnt                         NUMBER(10);
  v_batch_tot_amnt                        NUMBER(38,4);
  v_hosp_seq_id                           NUMBER(30);
  v_tot_clm_insrt_cnt                     NUMBER(30);
  unique_const_excp                       EXCEPTION;
  v_file_no_frmt                          VARCHAR2(200);
  v_clm_file_no_max                       VARCHAR2(200);
  v_file_no                               VARCHAR2(200);
  
BEGIN
  
 v_start_time := dbms_utility.get_time;
 
 OPEN  cur_xml_claim_info;
 FETCH cur_xml_claim_info INTO rec_xml_claim_info;
 CLOSE cur_xml_claim_info;
 
 OPEN  cur_xml_hosp_info;
 FETCH cur_xml_hosp_info INTO v_hosp_seq_id;
 CLOSE cur_xml_hosp_info;
 
 OPEN  hosp_cur(rec_xml_claim_info.hosp_seq_id);
 FETCH hosp_cur INTO hosp_rec;
 CLOSE hosp_cur;
 
 OPEN  cur_clm_seq_dtls;
 FETCH cur_clm_seq_dtls INTO rec_clm_seq_dtls;
 CLOSE cur_clm_seq_dtls;
 
 v_file_no := 'FL-'||TO_CHAR(SYSDATE,'DDMMYYYY')||'-';
 
 OPEN  cur_clm_fl_mx_seq_dtls(v_file_no);
 FETCH cur_clm_fl_mx_seq_dtls INTO v_file_no_frmt,v_clm_file_no_max;
 CLOSE cur_clm_fl_mx_seq_dtls;
 
 IF v_clm_file_no_max IS NULL THEN
    v_clm_file_no_max := 1;
    v_file_no         := 'FL-'||TO_CHAR(SYSDATE,'DDMMYYYY')||'-00001';
 ELSE
    v_clm_file_no_max := TO_NUMBER(v_clm_file_no_max);
    v_file_no         := v_file_no_frmt||'-'||LPAD((v_clm_file_no_max+v_tot_clm_insrt_cnt),5,'0');
 END IF;
 
 
 OPEN  cur_tot_claim_insrt_cnt;
 FETCH cur_tot_claim_insrt_cnt INTO v_tot_clm_insrt_cnt;
 CLOSE cur_tot_claim_insrt_cnt;
 
 SELECT COUNT(1) INTO v_qtr_claim_count
   FROM APP.CLM_BULK_UPLD_CLM_DETAILS C
   JOIN APP.TPA_ENR_POLICY_MEMBER M ON (C.MEMBER_SEQ_ID=M.MEMBER_SEQ_ID)
   JOIN APP.TPA_ENR_POLICY_GROUP PG ON (M.POLICY_GROUP_SEQ_ID=PG.POLICY_GROUP_SEQ_ID)
   JOIN APP.TPA_ENR_MEM_ADDRESS A ON (PG.ENR_ADDRESS_SEQ_ID=A.ENR_ADDRESS_SEQ_ID)
   WHERE C.XML_SEQ_ID = v_xml_seq_id
     AND A.COUNTRY_ID = 134;
         
 SELECT COUNT(1) INTO v_ind_claim_count
   FROM APP.CLM_BULK_UPLD_CLM_DETAILS C
   JOIN APP.TPA_ENR_POLICY_MEMBER M ON (C.MEMBER_SEQ_ID=M.MEMBER_SEQ_ID)
   JOIN APP.TPA_ENR_POLICY_GROUP PG ON (M.POLICY_GROUP_SEQ_ID=PG.POLICY_GROUP_SEQ_ID)
   JOIN APP.TPA_ENR_MEM_ADDRESS A ON (PG.ENR_ADDRESS_SEQ_ID=A.ENR_ADDRESS_SEQ_ID)
   WHERE C.XML_SEQ_ID = v_xml_seq_id
     AND A.COUNTRY_ID = 73;  
             
 SELECT COUNT(1) INTO v_oth_claim_count
   FROM APP.CLM_BULK_UPLD_CLM_DETAILS C
   JOIN APP.TPA_ENR_POLICY_MEMBER M ON (C.MEMBER_SEQ_ID=M.MEMBER_SEQ_ID)
   JOIN APP.TPA_ENR_POLICY_GROUP PG ON (M.POLICY_GROUP_SEQ_ID=PG.POLICY_GROUP_SEQ_ID)
   JOIN APP.TPA_ENR_MEM_ADDRESS A ON (PG.ENR_ADDRESS_SEQ_ID=A.ENR_ADDRESS_SEQ_ID)
   WHERE C.XML_SEQ_ID = v_xml_seq_id
     AND A.COUNTRY_ID NOT IN (134,73);  
 
 IF (v_qtr_claim_count + v_ind_claim_count +  v_oth_claim_count) !=  v_tot_clm_insrt_cnt THEN
   raise unique_const_excp;
 END IF;  
     
 SELECT COUNT(1) INTO v_tot_claim_cnt
   FROM APP.CLM_BULK_UPLD_CLM_DETAILS C
   WHERE C.XML_SEQ_ID = v_xml_seq_id;   
   
 OPEN  cur_batch_sum;
 FETCH cur_batch_sum INTO v_batch_tot_amnt;
 CLOSE cur_batch_sum;   
 
 update_clm_seq_no(v_xml_seq_id,v_qtr_claim_count+ v_ind_claim_count +  v_oth_claim_count,v_ind_claim_count,v_oth_claim_count,v_file_no);
 
 
                                         
  ---------@@@@@@@@ Claim Info Insert @@@@@@@@@------------  
  OPEN  cur_claim_info(rec_clm_seq_dtls.qtr_clm_no_max_seq_rch,rec_clm_seq_dtls.ind_clm_no_max_seq_rch,rec_clm_seq_dtls.oth_clm_no_max_seq_rch,v_clm_file_no_max);
  LOOP
    FETCH cur_claim_info BULK COLLECT INTO rec_clm_info LIMIT 2000;
    EXIT WHEN rec_clm_info.COUNT = 0;

    FORALL i IN 1..rec_clm_info.COUNT  
      INSERT INTO APP.CLM_AUTHORIZATION_DETAILS
                     (claim_seq_id,
                      clm_batch_seq_id,
                      clm_xml_seq_id,
                      pat_auth_seq_id,
                      claim_number,
                      clm_received_date,
                      source_type_id,
                      date_of_hospitalization,
                      date_of_discharge,
                      claim_type,
                      claim_sub_type,
                      member_seq_id,
                      tpa_enrollment_id,
                      mem_name,
                      mem_age,
                      ins_seq_id,
                      policy_seq_id,
                      enrol_type_id,
                      emirate_id,
                      encounter_type_id,
                      encounter_start_type,
                      encounter_end_type,
                      encounter_facility_id,
                      ava_sum_insured,
                      currency_type,
                      clm_status_type_id,
                      denial_reason,
                      added_by,
                      added_date,
                      invoice_number,
                      requested_amount,
                      clinician_id,
                      system_of_medicine_type_id,
                      accident_related_type_id,
                      priority_general_type_id,
                      network_yn,
                      benifit_type,
                      presenting_complaints,
                      medical_opinion_remarks,
                      payer_id ,
                      denial_code,
                      pat_approved_amount,
                      conception_type,
                      lmp_date,
                      REQ_AMT_CURRENCY_TYPE,
                      CONVERTED_AMOUNT,
                      CONVERTED_AMOUNT_CURRENCY_TYPE,
                      CONVERSION_RATE,
                      process_type,
                      delvry_mod_type,
                      treatment_type,
                      event_no,
                      common_file_number,
                      mat_complcton_yn
                      )
               VALUES(clm_authorization_detail_seq.nextval,
                      rec_clm_info(i).CLM_BATCH_SEQ_ID,
                      rec_clm_info(i).clm_xml_seq_id,
                      rec_clm_info(i).PAT_AUTH_SEQ_ID,
                      rec_clm_info(i).CLAIM_NUMBER||LPAD(QAR_CLAIM_SEQ.NEXTVAL, 7, 0),
                      rec_clm_info(i).RECEIVED_DATE,
                      rec_clm_info(i).SOURCE_TYPE_ID,
                      rec_clm_info(i).DATE_TREATMENT,
                      rec_clm_info(i).DATE_DISCHARGE,
                      rec_clm_info(i).CLAIM_TYPE,
                      rec_clm_info(i).claim_sub_type,
                      rec_clm_info(i).member_seq_id,
                      rec_clm_info(i).MEMBER_ID,
                      rec_clm_info(i).MEMBER_NAME,
                      rec_clm_info(i).mem_age,
                      rec_clm_info(i).ins_seq_id,
                      rec_clm_info(i).policy_seq_id,
                      rec_clm_info(i).enrol_type_id,
                      rec_clm_info(i).emirate_id,
                      rec_clm_info(i).ENCNTR_TYPE_ID,
                      rec_clm_info(i).encounter_start_type,
                      rec_clm_info(i).encounter_end_type,
                      rec_clm_info(i).encounter_facility_id,
                      rec_clm_info(i).ava_sum_insured,
                      rec_clm_info(i).currency_type,
                      rec_clm_info(i).clm_status_type_id,
                      rec_clm_info(i).denial_reason,
                      1,
                      SYSDATE,
                      rec_clm_info(i).INVOICE_NO,
                      rec_clm_info(i).requested_amount,
                      rec_clm_info(i).clinician_id,
                      rec_clm_info(i).system_of_medicine_type_id,
                      rec_clm_info(i).accident_related_type_id,
                      rec_clm_info(i).priority_general_type_id,
                      rec_clm_info(i).network_yn,
                      rec_clm_info(i).benifit_type,
                      rec_clm_info(i).symptoms,
                      rec_clm_info(i).medical_opinion_remarks,
                      rec_clm_info(i).payer_id,
                      rec_clm_info(i).denial_code,
                      rec_clm_info(i).pat_approved_amount,
                      rec_clm_info(i).conception_type,
                      rec_clm_info(i).lmp_date,
                      rec_clm_info(i).REQ_AMT_CURRENCY_TYPE,
                      rec_clm_info(i).requested_amount,
                      'QAR',
                      rec_clm_info(i).CONVERSION_RATE,
                      'RGL',
                      rec_clm_info(i).delvry_mod_type,
                      rec_clm_info(i).treatment_type,
                      rec_clm_info(i).event_no,
                      rec_clm_info(i).CLM_FILE_NO,
                      rec_clm_info(i).mat_complcton_yn
                      )
                      --LOG ERRORS INTO ERR$_temp_clm ('INSERT') REJECT LIMIT UNLIMITED
                      ;
     END LOOP;
  CLOSE cur_claim_info;                 
                      
      MERGE INTO APP.CLM_BULK_UPLD_CLM_DETAILS BC
           USING APP.CLM_AUTHORIZATION_DETAILS CA
            ON (CA.CLM_XML_SEQ_ID = BC.CLM_XML_SEQ_ID AND BC.XML_SEQ_ID = V_XML_SEQ_ID)                
      WHEN MATCHED THEN
        UPDATE SET BC.CLAIM_SEQ_ID = CA.CLAIM_SEQ_ID
             WHERE BC.XML_SEQ_ID = V_XML_SEQ_ID;
     
  OPEN  cur_pat_seq_ids;
   LOOP
     FETCH cur_pat_seq_ids BULK COLLECT INTO rec_pat_seq_ids LIMIT 2000;
     EXIT WHEN rec_pat_seq_ids.COUNT =0;
        FORALL i IN 1..rec_pat_seq_ids.COUNT
          UPDATE APP.PAT_AUTHORIZATION_DETAILS PA
             SET PA.CLAIM_SEQ_ID = rec_pat_seq_ids(i).claim_seq_id
          WHERE PA.PAT_AUTH_SEQ_ID = rec_pat_seq_ids(i).pat_auth_seq_id
            AND PA.CLAIM_SEQ_ID IS NULL  AND PA.PAT_ENHANCED_YN = 'N';-----NEWLY ADDED FOR PREUATH ENHANCEMENT
   END LOOP;
  CLOSE cur_pat_seq_ids;        
              
 
  
   ---------@@@@@@@@ Claim Hospital Info Insert @@@@@@@@@------------                     
    OPEN  cur_uplded_clm_info;
    LOOP
      FETCH cur_uplded_clm_info BULK COLLECT INTO rec_uplded_clm_info LIMIT 2000;
      EXIT WHEN rec_uplded_clm_info.COUNT =0;
          FORALL i IN 1..rec_uplded_clm_info.COUNT 
            INSERT INTO APP.clm_hospital_details c
                (clm_hosp_assoc_seq_id,
                 claim_seq_id,
                 hosp_seq_id,
                 hosp_name,
                 address_1,
                 city_type_id,
                 state_type_id,
                 pin_code,
                 off_phone_no_1,
                 office_fax_no,
                 remarks,
                 added_by,
                 added_date,
                 provider_id,
                 country_type_id,
                 clinician_name)
              values
                (clm_hosp_dtl_hosp_assoc_seq.nextval,
                 rec_uplded_clm_info(i).claim_seq_id,
                 rec_uplded_clm_info(i).hosp_seq_id,
                 rec_uplded_clm_info(i).hosp_name,
                 rec_uplded_clm_info(i).address_1,
                 rec_uplded_clm_info(i).city_type_id,
                 rec_uplded_clm_info(i).state_type_id,
                 rec_uplded_clm_info(i).pin_code,
                 rec_uplded_clm_info(i).off_phone_no_1,
                 rec_uplded_clm_info(i).office_fax_no,
                 null,
                 1,
                 sysdate,
                 rec_uplded_clm_info(i).empanel_number,
                 rec_uplded_clm_info(i).country_id,
                 rec_uplded_clm_info(i).clinician_name--v_clinician_name
                 );
                 
      FORALL i IN 1..rec_uplded_clm_info.COUNT
       INSERT INTO assign_users
                (assign_users_seq_id,
                 claim_seq_id,
                 assigned_to_user,
                 assigned_date,
                 review_completed_yn,
                 added_by,
                 added_date)
              VALUES
                (pat_assign_users_seq.NEXTVAL,
                 rec_uplded_clm_info(i).claim_seq_id,
                 1,
                 SYSDATE,
                 'N',
                 1,
                 SYSDATE);           
                 
      END LOOP;
     CLOSE cur_uplded_clm_info;
  
    OPEN  cur_asign_usr_info;
    LOOP
      FETCH cur_asign_usr_info BULK COLLECT INTO rec_asign_usr_info LIMIT 2000;
      EXIT WHEN rec_asign_usr_info.COUNT =0;
      
      FORALL i IN 1..rec_asign_usr_info.COUNT
        UPDATE APP.CLM_AUTHORIZATION_DETAILS CA
           SET CA.ASSIGN_USER_SEQ_ID = rec_asign_usr_info(i).assign_users_seq_id
        WHERE CA.CLAIM_SEQ_ID = rec_asign_usr_info(i).CLAIM_SEQ_ID;
      
    END LOOP;
    CLOSE cur_asign_usr_info;
   
  ---------@@@@@@@@ Claim Diagnosys Info Insert @@@@@@@@@------------  
  OPEN  cur_diag_info;
  LOOP
    FETCH cur_diag_info BULK COLLECT INTO rec_diag_info LIMIT 2000;
    EXIT WHEN rec_diag_info.COUNT =0;
    
    FORALL i IN 1..rec_diag_info.COUNT
       INSERT INTO diagnosys_details(
                    diag_seq_id,
                    claim_seq_id,
                    icd_code_seq_id,
                    diagnosys_code,
                    primary_ailment_yn,
                    added_by,
                    added_date)
            VALUES (diagnosys_detail_seq.nextval,
                    rec_diag_info(i).CLAIM_SEQ_ID,
                    rec_diag_info(i).ICD10_SEQ_ID,
                    UPPER(rec_diag_info(i).DIAGNOSYS_CODE),
                    UPPER(rec_diag_info(i).PRIMARY_AILMENT_YN),
                    1,
                    SYSDATE);
  END LOOP;
  CLOSE cur_diag_info;
  ---------@@@@@@@@ updating benifit type (dntl, meternity) depends upon icd for pbm bulk upload@@--------
  IF rec_xml_claim_info.source_type='PBCL' THEN 
    OPEN update_pbm_beni_cur;
    LOOP 
       FETCH update_pbm_beni_cur BULK COLLECT INTO update_pbm_beni_rec LIMIT 2000;
       EXIT WHEN update_pbm_beni_rec.COUNT=0;
       FORALL i IN 1..update_pbm_beni_rec.COUNT
        UPDATE APP.CLM_AUTHORIZATION_DETAILS CLM SET CLM.BENIFIT_TYPE=update_pbm_beni_rec(i).benifit_type
               where CLAIM_SEQ_ID= update_pbm_beni_rec(i).CLAIM_SEQ_ID;
    END LOOP;
    CLOSE update_pbm_beni_cur;
   END IF;
  
  ---------@@@@@@@@ Claim Activity Info Insert @@@@@@@@@------------    
  OPEN  cur_activity_info;
  LOOP
    FETCH cur_activity_info BULK COLLECT INTO rec_activity_info LIMIT 2000;
    EXIT WHEN rec_activity_info.COUNT = 0;
    
    FORALL i IN 1..rec_activity_info.COUNT
     INSERT INTO pat_activity_details(
                activity_dtl_seq_id,
                claim_seq_id,
                activity_seq_id,
                s_no,
                start_date,
                activity_type,
                code,
                unit_type,
                internal_code,
                quantity,
                unit_price,
                currency_type,
                gross_amount,
                discount_amount,
                disc_gross_amount,
                patient_share_amount,
                net_amount,
                approved_amount,
                allow_yn,
                approvd_quantity,
                added_by,
                added_date,
                provider_net_amount,
                tooth_no,
                internal_desc,
                activity_type_id,
                converted_acitivty_amt,
                unit_discount_amount,
                posology_duration,
                MOPH_CODES,
                hosp_internal_code,
                hosp_internal_code_desc)
        VALUES (pat_activity_detail_seq.nextval,
                rec_activity_info(i).CLAIM_SEQ_ID,
                rec_activity_info(i).ACT_MAS_DTL_SEQ_ID,
                rec_activity_info(i).SL_NO,
                rec_activity_info(i).SERVICE_DATE,
                CASE when rec_activity_info(i).ACTIVITY_TYPE_ID='DRG' then '5' else rec_activity_info(i).ACTIVITY_TYPE end,--v_activity_type
                rec_activity_info(i).ACTIVITY_CODE,--CODE
                --NULL,--unit_type
                rec_activity_info(i).UNIT_TYPE,
                rec_activity_info(i).INTERNAL_SERVICE_CODE,--internal_code
                rec_activity_info(i).QUANTITY,
                rec_activity_info(i).UNIT_PRICE,
                rec_activity_info(i).CURRENCY_TYPE,
                rec_activity_info(i).GROSS_AMOUNT,
                rec_activity_info(i).DISCOUNT_AMOUNT,
                rec_activity_info(i).DISC_GROSS_AMOUNT,
                rec_activity_info(i).PATIENT_SHARE_AMOUNT,
                rec_activity_info(i).NET_AMOUNT,
                NULL,---approved amount
                rec_activity_info(i).ALLOW_YN,
                rec_activity_info(i).APPROVD_QUANTITY,
                1,
                SYSDATE,
                rec_activity_info(i).PROVIDER_NET_AMOUNT,
                rec_activity_info(i).TOOTH_NUMBER,
                rec_activity_info(i).INTERNAL_DESC,
                rec_activity_info(i).ACTIVITY_TYPE_ID,
                rec_activity_info(i).CONVERTED_ACITIVTY_AMT,
                rec_activity_info(i).UNIT_DISCOUNT_AMOUNT,
                rec_activity_info(i).DUR_MEDI,
                rec_activity_info(i).MOPH_CODES,
                rec_activity_info(i).internal_service_code,
                rec_activity_info(i).service_description);
     END LOOP;
   CLOSE cur_activity_info;
   ---------@@@@@@@@ Activity Obervation Info Insert @@@@@@@@@------------
   OPEN  cur_obsr_dtls;
    LOOP
    FETCH cur_obsr_dtls BULK COLLECT INTO rec_obsr_dtls LIMIT 2000;
    EXIT WHEN rec_obsr_dtls.COUNT = 0;
    
    FORALL i IN 1..rec_obsr_dtls.COUNT
       INSERT INTO pat_observation_details
          (observation_seq_id,
           activity_dtl_seq_id,
           observation_type_id,
           observation_code_id,
           value,
           obs_value_type_id,
           added_by,
           added_date)
        VALUES
          (pat_observation_detail_seq.Nextval,
           rec_obsr_dtls(i).activity_dtl_seq_id,
           'eRx',
           '8',
           rec_obsr_dtls(i).OBSERVATION,
           'Reference',
           1,
           SYSDATE);
    END LOOP;
   CLOSE cur_obsr_dtls; 
   
                
   save_time_details(v_xml_seq_id,'UPLOAD_CLM',v_start_time);             
  
   EXCEPTION
    WHEN bulk_errors THEN
      l_error_count := SQL%BULK_EXCEPTIONS.count;
      v_bulk_error_msg := 'Number of failures: '||l_error_count;
      FOR i IN 1 .. l_error_count LOOP
        v_bulk_error_msg := v_bulk_error_msg ||CHR(10)||
                            ('Error: ' || i ||
                             ' Array Index: ' || SQL%BULK_EXCEPTIONS(i).error_index ||
                             ' Message: ' || SQLERRM(-SQL%BULK_EXCEPTIONS(i).ERROR_CODE));
      END LOOP;
        save_exception_log(v_xml_seq_id,NULL,NULL,NULL,v_bulk_error_msg,v_added_by,'save_claim_details',v_hosp_seq_id);
        v_batch_no         := NULL;
        ROLLBACK;
      WHEN unique_const_excp THEN
        save_exception_log(v_xml_seq_id,NULL,v_sql_code,'Unique Constraient error, count missmatch',NULL,v_added_by,'save_claim_details',v_hosp_seq_id);
        v_batch_no         := NULL;
        ROLLBACK;  
      WHEN OTHERS THEN
         V_SQL_CODE := SQLCODE;
         V_SQL_MSG  := SQLERRM; 
         
         save_exception_log(v_xml_seq_id,NULL,v_sql_code,v_sql_msg,NULL,v_added_by,'save_claim_details',v_hosp_seq_id);
         v_batch_no         := NULL;
         ROLLBACK;
      
END save_claim_details; 
------------------------------------------------------------------------------------------------------
FUNCTION get_benf_type_id (v_desc                IN VARCHAR2)
 RETURN VARCHAR2
 IS
 v_result                 VARCHAR2(100);
 BEGIN
  v_result := CASE WHEN TRIM(UPPER(V_DESC)) IN ('IN PATIENT', 'IN-PATIENT', 'INPATIENT', 'IPT') THEN 'IPT'
                   WHEN TRIM(UPPER(V_DESC)) IN ('OUT PATIENT', 'OUT-PATIENT','OUTPATIENT') THEN 'OPTS'
                   WHEN TRIM(UPPER(V_DESC)) IN ('OPTICAL', 'OPTC') THEN 'OPTC'
                   WHEN TRIM(UPPER(V_DESC)) IN ('OP MATERNITY', 'MTI')  THEN 'OMTI'
                   WHEN TRIM(UPPER(V_DESC)) IN ('IP MATERNITY', 'MTI')  THEN 'IMTI'
                   WHEN TRIM(UPPER(V_DESC)) IN ('DENTAL','DNTL') THEN 'DNTL'
                   WHEN TRIM(UPPER(V_DESC)) IN ('HEALTH CHECK-UP','HEAC') THEN 'HEAC'
                   WHEN TRIM(UPPER(V_DESC)) IN ('DAY CARE','DAYC', 'DAYCARE') THEN 'DAYC'
                     ELSE NULL
                      END;
       
   RETURN(v_result);               
 END get_benf_type_id;
------------------------------------------------------------------------------------------------------
FUNCTION check_data_type (v_flag                IN VARCHAR2,
                          v_value               IN VARCHAR2)
 RETURN VARCHAR2
 IS
  v_date                 DATE;
 BEGIN
   IF v_flag = 'DT' THEN
     v_date := TO_DATE(TRIM(v_value),'DD/MM/YYYY');
   END IF;
   
   RETURN(v_value);
   
   EXCEPTION 
     WHEN OTHERS THEN
       RETURN NULL;
       
 END check_data_type;                         
------------------------------------------------------------------------------------------------------
FUNCTION check_size (v_value_typ           IN VARCHAR2,
                     v_value               IN VARCHAR2,
                     v_add_fild            IN VARCHAR2 DEFAULT NULL)
 RETURN VARCHAR2
 IS
 
 cursor encounter_cur(l_benifit_type VARCHAR2, l_encounter_type VARCHAR2) is
    select nvl(ec.encounter_seq_id, 0)
    from tpa_encounter_type_codes ec
    where ec.header_type = 'ENCOUNTER_TYPE'
    and UPPER(ec.description) like '%'||UPPER(l_encounter_type)||'%'
    and ec.benefit_gen_type_id = l_benifit_type;
 
 v_encounter_seq_id                        clm_authorization_details.encounter_type_id%TYPE;   
 v_act_req_amt                             clm_authorization_details.converted_amount%TYPE;
 v_act_qnt                                 Pat_Activity_Details.Quantity%TYPE;  
 v_invoice_num                             clm_authorization_details.invoice_number%TYPE;
 v_mem_name                                clm_authorization_details.mem_name%TYPE;
 v_mem_id                                  clm_authorization_details.tpa_enrollment_id%TYPE;
 v_med_type                                clm_authorization_details.system_of_medicine_type_id%TYPE;
 v_clinician_id                            clm_authorization_details.clinician_id%TYPE;
 v_clinician_name                          clm_hospital_details.clinician_name%TYPE;
 v_benefit_type                            clm_authorization_details.benifit_type%TYPE;
 v_sympton                                 clm_authorization_details.presenting_complaints%TYPE;
 v_prim_diag_code                          Diagnosys_Details.diagnosys_code%TYPE;
 v_prim_diag_desc                          tpa_icd_codes.icd_description%TYPE;
 v_secn_diag_code1                         Diagnosys_Details.diagnosys_code%TYPE;
 v_secn_diag_code2                         Diagnosys_Details.diagnosys_code%TYPE;
 v_secn_diag_code3                         Diagnosys_Details.diagnosys_code%TYPE;
 v_secn_diag_code4                         Diagnosys_Details.diagnosys_code%TYPE;
 v_secn_diag_code5                         Diagnosys_Details.diagnosys_code%TYPE;
 v_inter_ser_code                          Pat_Activity_Details.Internal_Code%TYPE; 
 v_Activity_Type_Id                        Pat_Activity_Details.Activity_Type_Id%TYPE;
 v_tooth_no                                Pat_Activity_Details.Tooth_No%TYPE;
 v_con_nature                              clm_authorization_details.conception_type%TYPE;
 v_observation                             pat_observation_details.value%TYPE;
 v_event_no                                clm_authorization_details.event_no%TYPE;
 v_result                                  VARCHAR2(1000);
 v_encounter_type                          VARCHAR2(1000);
 l_benifit_type                            VARCHAR2(1000);
 v_tooth_no_eror_cnt                       NUMBER(10);
 v_dur_medi                                NUMBER(10,2);
  
  
 BEGIN
   
  IF v_value_typ = 'INV' THEN
     v_invoice_num := v_value;
     v_result      := v_value;
  ELSIF v_value_typ = 'MNME' THEN
    v_mem_name    := v_value;
    v_result      := v_value;  
    
  ELSIF v_value_typ = 'MID' THEN
    v_mem_id      := v_value;
    v_result      := v_value;  
    
  ELSIF v_value_typ = 'ENCTR' THEN
      l_benifit_type := get_benf_type_id(v_add_fild);
      v_encounter_type :=  case when trim(UPPER(v_value)) = 'OP NO-EMERGENCY' AND l_benifit_type IN ('OPTS', 'OMTI', 'OPTC', 'DNTL', 'MTI') then
                                  'No Bed + No Emergency room'
                                when trim(UPPER(v_value)) = 'OP EMERGENCY' AND l_benifit_type IN ('OPTS', 'OMTI', 'OPTC', 'DNTL', 'MTI') then
                                  'No Bed + Emergency room'
                                when trim(UPPER(v_value)) = 'IP NO-EMERGENCY' AND l_benifit_type IN ('IPT', 'IMTI', 'MTI') then
                                  'Inpatient Bed + No Emergency room'
                                when trim(UPPER(v_value)) = 'IP EMERGENCY' AND l_benifit_type IN ('IPT', 'IMTI', 'MTI') then
                                  'Inpatient Bed + emergency room'
                                when trim(upper(v_value)) = 'DAYCARE NO-EMERGENCY' AND l_benifit_type = 'DAYC' then
                                  'Daycare Bed + No emergency room'
                                when trim(upper(v_value)) = 'DAYCARE EMERGENCY' AND l_benifit_type = 'DAYC' then
                                  'Daycare Bed + Emergency room'
                           end;
                           
    IF l_benifit_type IN ('IMTI', 'OMTI', 'OPTC', 'DNTL') THEN
        l_benifit_type := CASE WHEN l_benifit_type = 'IMTI' THEN 'IPT'
                           WHEN l_benifit_type = 'OMTI' THEN 'OPTS'
                           WHEN l_benifit_type = 'OPTC' AND substr(trim(v_value), 1, 2) = 'OP' THEN 'OPTS'
                           --WHEN l_benifit_type = 'OPTC' AND substr(trim(v_encounter_type), 1, 2) = 'IP' THEN 'IPT'
                           WHEN l_benifit_type = 'DNTL' AND substr(trim(v_value), 1, 2) = 'OP' THEN 'OPTS'
                           WHEN l_benifit_type = 'DNTL' AND substr(trim(v_value), 1, 2) = 'IP' THEN 'IPT'
                           WHEN l_benifit_type = 'DAYC' THEN 'DAYC'
                       END;
    ELSE
      l_benifit_type := get_benf_type_id(v_add_fild);
    END IF;                    
     
     IF v_encounter_type IS NOT NULL THEN
      OPEN  encounter_cur (l_benifit_type, v_encounter_type);
      FETCH encounter_cur INTO v_encounter_seq_id;
      CLOSE encounter_cur;
     END IF; 
     
    v_result := v_encounter_seq_id;
  
  ELSIF v_value_typ = 'REQ' THEN
    v_act_req_amt := v_value;
    v_result      := v_value;
  ELSIF v_value_typ = 'QNT' THEN
    v_act_qnt     := v_value;
    v_result      := v_value;
  ELSIF v_value_typ = 'SYS' THEN
    v_med_type :=    CASE TRIM(UPPER(V_VALUE)) WHEN 'AYURVEDIC' THEN 'SAY'
                                               WHEN 'HOMEOPATHY' THEN 'SAH'
                                               WHEN 'ACUPUNCTURE' THEN 'SAA'
                                               WHEN 'CHIROPRACTIC' THEN 'SAC'
                                               WHEN 'NATUROPATHY' THEN 'SAN'
                                               WHEN 'OSTEOPATHY' THEN 'SAO'
                                               WHEN 'CHINESE HERBAL MEDICINE' THEN 'SACH'
                                               WHEN 'PODIATRY' THEN 'SAP'
                                               WHEN 'ALLOPATHY' THEN 'SAL' END;
      
    v_result := v_med_type;
  ELSIF v_value_typ = 'CID' THEN
    v_clinician_id := v_value;
    v_result       := v_value;
  ELSIF v_value_typ = 'CNME' THEN
    v_clinician_name := v_value;
    v_result      := v_value;
  ELSIF v_value_typ = 'BNF' THEN
    v_benefit_type := get_benf_type_id(v_value);
    v_result := v_benefit_type;
  ELSIF v_value_typ = 'SYM' THEN
    v_sympton     := v_value;
    v_result      := v_value;
  ELSIF v_value_typ = 'PICD' THEN
    v_prim_diag_code := v_value;
    v_result         := v_value;
  ELSIF v_value_typ = 'ICDSC' THEN
    v_prim_diag_desc := v_value;
    v_result      := v_value;
  ELSIF v_value_typ = 'SICD1' THEN
    v_secn_diag_code1 := v_value;
    v_result      := v_value;
  ELSIF v_value_typ = 'SICD2' THEN
    v_secn_diag_code2 := v_value;
    v_result      := v_value;
  ELSIF v_value_typ = 'SICD3' THEN
    v_secn_diag_code3 := v_value;
    v_result      := v_value;
  ELSIF v_value_typ = 'SICD4' THEN
    v_secn_diag_code4 := v_value;
    v_result      := v_value;
  ELSIF v_value_typ = 'SICD5' THEN
    v_secn_diag_code5 := v_value;
    v_result      := v_value;
  ELSIF v_value_typ = 'INTCD' THEN
    v_inter_ser_code := v_value;
    v_result      := v_value;
  ELSIF v_value_typ = 'ACT' THEN
    v_activity_type_id := CASE WHEN trim(UPPER(v_value)) = 'ACTIVITY' THEN 'ACT'
                               WHEN trim(UPPER(v_value)) = 'DRUG' THEN 'DRG' END;
    v_result := v_activity_type_id;
  ELSIF v_value_typ = 'DRG' THEN
    v_activity_type_id := CASE WHEN trim(UPPER(v_value)) = 'ACTIVITY' THEN 'ACT'
                               WHEN trim(UPPER(v_value)) = 'DRUG' THEN 'DRG' END;
    v_result := v_activity_type_id;  
  ELSIF v_value_typ = 'TNO' THEN
    v_tooth_no := v_value;
    SELECT REGEXP_COUNT(REPLACE(v_tooth_no,','), '[^[:alnum:]]') INTO v_tooth_no_eror_cnt FROM DUAL;
    IF v_tooth_no_eror_cnt > 0 THEN
      v_result      := NULL;
    ELSE
      v_result      := v_value;
    END IF;
  ELSIF v_value_typ = 'CONP' THEN
    v_con_nature := CASE WHEN trim(UPPER(v_value)) = 'NATURAL' THEN 'NAT'
                         WHEN trim(UPPER(v_value)) = 'ASSISTED' THEN 'AST'
                    END;
    v_result := v_con_nature;
  ELSIF v_value_typ = 'OBS' THEN
    v_observation := v_value;
    v_result      := v_value;
  ELSIF v_value_typ = 'EVNT' THEN
    v_event_no := v_value;
    v_result      := v_value;
  ELSIF v_value_typ = 'DUR_MEDI' THEN
    v_dur_medi      := TO_NUMBER(v_value);
    v_result        :=v_value;
    END IF;
    RETURN (NVL(v_result,'NA'));
    
   EXCEPTION 
     WHEN VALUE_ERROR THEN 
       RETURN ('SIZE_ISSUE');
     WHEN INVALID_NUMBER THEN
       RETURN ('INVALID');
     WHEN OTHERS THEN
       RETURN ('NA')  ;
       
 END check_size;     
----------------------------------------------------------------------------------------------------
FUNCTION validate_data (v_flag                       IN VARCHAR2,
                         v_id                         IN VARCHAR2,
                        v_id2                        IN VARCHAR2 DEFAULT NULL,
                        v_id3                        IN VARCHAR2 DEFAULT NULL)
 RETURN VARCHAR2                                             
 IS
 
 CURSOR CUR_PAT_CML_DTLS(V_PA_NO           VARCHAR2)  IS
   SELECT CA.CLAIM_NUMBER
     FROM APP.PAT_AUTHORIZATION_DETAILS PA
     JOIN APP.CLM_AUTHORIZATION_DETAILS CA ON (PA.PAT_AUTH_SEQ_ID=CA.PAT_AUTH_SEQ_ID)
     WHERE PA.PRE_AUTH_NUMBER = V_PA_NO  AND PA.PAT_ENHANCED_YN = 'N'  -----NEWLY ADDED FOR PREUATH ENHANCEMENT
     AND ROWNUM = 1;
 
 v_cnt                  VARCHAR2(50);
 
 BEGIN
   IF v_flag = 'MEM_ID' THEN
     SELECT COUNT(1) INTO v_cnt FROM APP.TPA_ENR_POLICY_MEMBER M WHERE M.TPA_ENROLLMENT_ID = v_id AND M.DELETED_YN = 'N';
   ELSIF v_flag = 'CPT' THEN
     SELECT COUNT(1) INTO v_cnt FROM APP.TPA_PHARMACY_MASTER_DETAILS a WHERE a.activity_code = v_id;
   ELSIF v_flag = 'PAT' THEN
     SELECT COUNT(1) INTO v_cnt FROM APP.PAT_AUTHORIZATION_DETAILS PA WHERE PA.PRE_AUTH_NUMBER = v_id AND PA.PAT_ENHANCED_YN = 'N';-----NEWLY ADDED FOR PREUATH ENHANCEMENT;
   ELSIF v_flag = 'PAT_ST' THEN
     SELECT COUNT(1) INTO v_cnt FROM APP.PAT_AUTHORIZATION_DETAILS PA WHERE PA.PRE_AUTH_NUMBER = v_id AND PA.PAT_STATUS_TYPE_ID = 'APR'  AND PA.PAT_ENHANCED_YN = 'N';-----NEWLY ADDED FOR PREUATH ENHANCEMENT;  
   ELSIF v_flag = 'PAT_HOSP' THEN
     SELECT COUNT(1) INTO v_cnt FROM APP.PAT_AUTHORIZATION_DETAILS PA WHERE PA.PRE_AUTH_NUMBER = v_id AND PA.HOSP_SEQ_ID = v_id2 AND PA.PAT_ENHANCED_YN = 'N';-----NEWLY ADDED FOR PREUATH ENHANCEMENT
   ELSIF v_flag = 'PAT_MEM' THEN
     SELECT COUNT(1) INTO v_cnt FROM APP.PAT_AUTHORIZATION_DETAILS PA WHERE PA.PRE_AUTH_NUMBER = v_id AND PA.TPA_ENROLLMENT_ID = v_id2 AND PA.PAT_ENHANCED_YN = 'N';-----NEWLY ADDED FOR PREUATH ENHANCEMENT  ;  
   ELSIF v_flag = 'EVNT_DUPL_CLM' THEN
     SELECT COUNT(EVENT_NO) INTO V_CNT FROM APP.CLM_AUTHORIZATION_DETAILS C WHERE C.EVENT_NO = V_ID;
   ELSIF v_flag = 'EVNT_DUPL_PAT' THEN
     SELECT COUNT(EVENT_NO) INTO V_CNT FROM APP.PAT_AUTHORIZATION_DETAILS C WHERE C.EVENT_NO = V_ID AND C.PRE_AUTH_NUMBER = v_id2 AND C.PAT_ENHANCED_YN = 'N';-----NEWLY ADDED FOR PREUATH ENHANCEMENT  
   ELSIF v_flag = 'EVNT_NO' THEN
     SELECT RPAD((S.LAST_NUMBER - 1), 7, 0) INTO V_CNT
      FROM ALL_SEQUENCES S WHERE S.SEQUENCE_NAME = 'EVENT_REF_NO_SEQ' AND S.SEQUENCE_OWNER = 'APP'; 
   ELSIF v_flag = 'PAT_LINK' THEN
     OPEN  CUR_PAT_CML_DTLS(v_id);
     FETCH CUR_PAT_CML_DTLS INTO v_cnt;
     CLOSE CUR_PAT_CML_DTLS;
     
   --CR0182
   ELSIF v_flag = 'PAT_HOSP_DATE' THEN
     SELECT COUNT(1) INTO v_cnt FROM APP.PAT_AUTHORIZATION_DETAILS PA WHERE PA.PRE_AUTH_NUMBER = v_id AND TO_DATE(PA.HOSPITALIZATION_DATE, 'DD/MM/RRRR') = TO_DATE(v_id2, 'DD/MM/RRRR') AND PA.PAT_ENHANCED_YN = 'N';
   ELSIF v_flag = 'PAT_DISC_DATE' THEN
     SELECT COUNT(1) INTO v_cnt FROM APP.PAT_AUTHORIZATION_DETAILS PA WHERE PA.PRE_AUTH_NUMBER = v_id AND TO_DATE(PA.DISCHARGE_DATE, 'DD/MM/RRRR') = TO_DATE(v_id2, 'DD/MM/RRRR') AND PA.PAT_ENHANCED_YN = 'N';
   ELSIF v_flag = 'LMP_DATE' THEN
     SELECT COUNT(1) INTO v_cnt FROM APP.PAT_AUTHORIZATION_DETAILS PA WHERE PA.PRE_AUTH_NUMBER = v_id AND TO_DATE(PA.LMP_DATE, 'DD/MM/RRRR') = TO_DATE(v_id2, 'DD/MM/RRRR') AND PA.PAT_ENHANCED_YN = 'N';
   ELSIF v_flag = 'EVENT_NO' THEN
     SELECT COUNT(1) INTO v_cnt FROM APP.PAT_AUTHORIZATION_DETAILS PA WHERE PA.PRE_AUTH_NUMBER = v_id AND PA.EVENT_NO = v_id2 AND PA.PAT_ENHANCED_YN = 'N';
   ELSIF v_flag = 'BEN_TYPE' THEN
     SELECT COUNT(1) INTO v_cnt FROM APP.PAT_AUTHORIZATION_DETAILS PA WHERE PA.PRE_AUTH_NUMBER = v_id AND PA.BENIFIT_TYPE = v_id2 AND PA.PAT_ENHANCED_YN = 'N';
   ELSIF v_flag = 'ENC_TYPE' THEN
     SELECT COUNT(1) INTO v_cnt FROM APP.PAT_AUTHORIZATION_DETAILS PA WHERE PA.PRE_AUTH_NUMBER = v_id AND TO_CHAR(PA.ENCOUNTER_TYPE_ID) = v_id2 AND PA.PAT_ENHANCED_YN = 'N';
   ELSIF v_flag = 'MED_TYPE' THEN
     SELECT COUNT(1) INTO v_cnt FROM APP.PAT_AUTHORIZATION_DETAILS PA WHERE PA.PRE_AUTH_NUMBER = v_id AND PA.SYSTEM_OF_MEDICINE_TYPE_ID = v_id2 AND PA.PAT_ENHANCED_YN = 'N';
   ELSIF v_flag = 'CONCEPTION_TYPE' THEN
     SELECT COUNT(1) INTO v_cnt FROM APP.PAT_AUTHORIZATION_DETAILS PA WHERE PA.PRE_AUTH_NUMBER = v_id AND PA.CONCEPTION_TYPE = v_id2 AND PA.PAT_ENHANCED_YN = 'N';
   ELSIF v_flag = 'TREATMENT_TYPE' THEN --FOR DENTAL BENEFIT
     SELECT COUNT(1) INTO v_cnt FROM APP.PAT_AUTHORIZATION_DETAILS PA WHERE PA.PRE_AUTH_NUMBER = v_id AND PA.TREATMENT_TYPE = v_id2 AND PA.PAT_ENHANCED_YN = 'N';
   --END CR0198
           
   ELSIF v_flag = 'ICD' THEN
     SELECT SUM(CNT)  INTO v_cnt FROM
     (SELECT COUNT(1) CNT FROM APP.TPA_ICD_AM_DETAILS M WHERE M.ICD_AM = v_id
      UNION ALL
      SELECT COUNT(1) CNT FROM APP.TPA_ICD10_MASTER_DETAILS I WHERE I.ICD_CODE = v_id);
   ELSIF v_flag = 'INV_HOSP' THEN
   SELECT COUNT(*) INTO v_cnt 
   FROM (WITH HOSP_IVOICE_DATA AS
          (SELECT ','||CA.INVOICE_NUMBER||',' AS INVOICE_NUMBER
           FROM APP.CLM_AUTHORIZATION_DETAILS CA
           JOIN APP.CLM_HOSPITAL_DETAILS H ON (CA.CLAIM_SEQ_ID=H.CLAIM_SEQ_ID)
           WHERE  H.HOSP_SEQ_ID = v_id2)
         SELECT  INVOICE_NUMBER
         FROM HOSP_IVOICE_DATA
         WHERE INVOICE_NUMBER LIKE '%,'||v_id||',%');  
   
   ELSIF v_flag = 'INT_CODE' THEN
    SELECT COUNT(1) INTO v_cnt
    FROM TPA_HOSP_TARIFF_DETAILS T
    JOIN TPA_ACTIVITY_MASTER_DETAILS M ON (T.ACTIVITY_SEQ_ID=M.ACT_MAS_DTL_SEQ_ID)
    where t.hosp_seq_id = v_id2
    AND UPPER(T.INTERNAL_CODE) = UPPER(V_ID)
    AND ((T.END_DATE IS NOT NULL AND TO_DATE(v_id3, 'DD-MM-RRRR') BETWEEN TRUNC(T.START_DATE) AND TRUNC(T.END_DATE)) OR
        (T.END_DATE IS NULL AND TO_DATE(v_id3, 'DD-MM-RRRR') >= TRUNC(T.START_DATE) ));
   
   ELSIF v_flag = 'CHK_ACT' THEN
     SELECT COUNT(1) INTO v_cnt
     FROM TPA_HOSP_TARIFF_DETAILS T
     JOIN TPA_ACTIVITY_MASTER_DETAILS M ON (T.ACTIVITY_SEQ_ID=M.ACT_MAS_DTL_SEQ_ID)
     WHERE T.HOSP_SEQ_ID = v_id2 and T.SERVICE_SEQ_ID NOT IN ('7','14')
     AND UPPER(T.INTERNAL_CODE) = UPPER(V_ID);
     
   ELSIF v_flag = 'CHK_PHARMA' THEN
   
     SELECT COUNT(1) INTO v_cnt
     FROM TPA_HOSP_TARIFF_DETAILS T
     JOIN TPA_ACTIVITY_MASTER_DETAILS M ON (T.ACTIVITY_SEQ_ID=M.ACT_MAS_DTL_SEQ_ID)
     WHERE T.HOSP_SEQ_ID = v_id2 and T.SERVICE_SEQ_ID IN ('7','14')
     AND UPPER(T.INTERNAL_CODE) = UPPER(V_ID);
     
    ELSIF v_flag = 'CHK_INTCODE' THEN
   
     SELECT COUNT(1) INTO v_cnt
     FROM TPA_HOSP_TARIFF_DETAILS T
     JOIN TPA_ACTIVITY_MASTER_DETAILS M ON (T.ACTIVITY_SEQ_ID=M.ACT_MAS_DTL_SEQ_ID)
     WHERE T.HOSP_SEQ_ID = v_id2
     AND UPPER(T.INTERNAL_CODE) = UPPER(V_ID); 
    
    ELSIF v_flag ='MOPH_CODES' THEN
       SELECT COUNT(1) INTO v_cnt
       from APP.TPA_PHARMACY_MASTER_DETAILS T WHERE UPPER(T.MOPH_CODES)=UPPER(v_id);
       
    ELSIF v_flag ='CHK_PBM_PHARMA' THEN

       SELECT COUNT(1) INTO v_cnt
       FROM TPA_HOSP_TARIFF_DETAILS T
       JOIN TPA_ACTIVITY_MASTER_DETAILS M ON (T.ACTIVITY_SEQ_ID=M.ACT_MAS_DTL_SEQ_ID)
       WHERE T.HOSP_SEQ_ID = v_id2 and T.SERVICE_SEQ_ID IN ('14')
       AND UPPER(T.INTERNAL_CODE) = UPPER(V_ID);  
   END IF;
   
   RETURN(NVL(v_cnt,0));
 END validate_data; 
------------------------------------------------------------------------------------------------------  
FUNCTION get_mem_seq_id (v_member_id                IN VARCHAR2,
                         v_hosp_date                IN DATE)
 RETURN NUMBER
 IS
  CURSOR cur_mem_info IS
   SELECT M.MEMBER_SEQ_ID
   FROM APP.TPA_ENR_POLICY_MEMBER M
   JOIN APP.TPA_ENR_POLICY_GROUP G ON (M.POLICY_GROUP_SEQ_ID=G.POLICY_GROUP_SEQ_ID)
   JOIN APP.TPA_ENR_POLICY P ON (G.POLICY_SEQ_ID=P.POLICY_SEQ_ID)
   WHERE M.TPA_ENROLLMENT_ID = V_MEMBER_ID
     AND V_HOSP_DATE BETWEEN M.DATE_OF_INCEPTION AND M.DATE_OF_EXIT
     AND V_HOSP_DATE BETWEEN P.EFFECTIVE_FROM_DATE AND P.EFFECTIVE_TO_DATE;
 
   V_MEMBER_SEQ_ID             NUMBER(20);
   
 BEGIN
   OPEN  CUR_MEM_INFO;
   FETCH CUR_MEM_INFO INTO V_MEMBER_SEQ_ID;
   CLOSE CUR_MEM_INFO;
   
   IF V_MEMBER_SEQ_ID IS NULL THEN
     SELECT MAX(M.MEMBER_SEQ_ID) INTO V_MEMBER_SEQ_ID FROM TPA_ENR_POLICY_MEMBER M WHERE M.TPA_ENROLLMENT_ID=v_member_id;
   END IF;
   
   RETURN(V_MEMBER_SEQ_ID);
   
 END get_mem_seq_id;
-------------------------------------------------------------------------------------------------------          
FUNCTION get_clinician_id(V_CLM_XML_SEQ_ID                   IN NUMBER)
 RETURN VARCHAR2
 IS
  CURSOR cur_clinician_info IS
   SELECT A.CLINICIAN_ID
   FROM APP.CLM_BULK_UPLD_ACT_DETAILS A
    WHERE A.CLM_XML_SEQ_ID = V_CLM_XML_SEQ_ID
    AND A.CLINICIAN_ID IS NOT NULL
    AND ROWNUM = 1;
    
    V_CLINICIAN_ID            VARCHAR2(500);
 BEGIN
   OPEN  cur_clinician_info;
   FETCH cur_clinician_info INTO V_CLINICIAN_ID;
   CLOSE cur_clinician_info;
 
   RETURN(NVL(V_CLINICIAN_ID,'NA'));
 
 END get_clinician_id;
 -------------------------------------------------------------------------------------------------------          
FUNCTION get_clinician_nme(V_CLM_XML_SEQ_ID                   IN NUMBER)
 RETURN VARCHAR2
 IS
  CURSOR cur_clinician_info IS
   SELECT A.CLINICIAN_NAME
   FROM APP.CLM_BULK_UPLD_ACT_DETAILS A
    WHERE A.CLM_XML_SEQ_ID = V_CLM_XML_SEQ_ID
    AND A.CLINICIAN_NAME IS NOT NULL
    AND ROWNUM = 1;
    
    V_CLINICIAN_NAME            VARCHAR2(500);
 BEGIN
   OPEN  cur_clinician_info;
   FETCH cur_clinician_info INTO V_CLINICIAN_NAME;
   CLOSE cur_clinician_info;
 
   RETURN(NVL(V_CLINICIAN_NAME,'NA'));
 
 END get_clinician_nme;
 -------------------------------------------------------------------------------------------------------          
FUNCTION get_lmp_date(V_CLM_XML_SEQ_ID                   IN NUMBER)
  RETURN DATE
  IS
  CURSOR cur_clinician_info IS
   SELECT A.DATE_OF_LMP
   FROM APP.CLM_BULK_UPLD_ACT_DETAILS A
    WHERE A.CLM_XML_SEQ_ID = V_CLM_XML_SEQ_ID
    AND A.DATE_OF_LMP IS NOT NULL
    AND ROWNUM = 1;
    
    V_LMP_DATE            DATE;
 BEGIN
   OPEN  cur_clinician_info;
   FETCH cur_clinician_info INTO V_LMP_DATE;
   CLOSE cur_clinician_info;
 
   RETURN(V_LMP_DATE);
 
 END get_lmp_date;
-------------------------------------------------------------------------------------------------------          
FUNCTION get_symptoms(V_CLM_XML_SEQ_ID                   IN NUMBER)
   RETURN VARCHAR2
 IS
 
  CURSOR cur_symptoms_info IS
   SELECT A.SYMPTOMS
   FROM APP.CLM_BULK_UPLD_ACT_DETAILS A
    WHERE A.CLM_XML_SEQ_ID = V_CLM_XML_SEQ_ID
    AND A.SYMPTOMS IS NOT NULL
    AND ROWNUM = 1;
    
    V_SYMPTOMS            VARCHAR2(3000);
    
 BEGIN
   OPEN  cur_symptoms_info;
   FETCH cur_symptoms_info INTO V_SYMPTOMS;
   CLOSE cur_symptoms_info;
 
   RETURN (V_SYMPTOMS);
 
 END get_symptoms; 
-------------------------------------------------------------------------------------------------------- 
FUNCTION check_prior_apr_dnl_code(v_member_seq_id               IN NUMBER,
                                  v_policy_seq_id               IN NUMBER,
                                  v_vip_yn                      IN VARCHAR2,
                                  v_claim_type                  IN VARCHAR2,
                                  v_clm_req_amount              IN NUMBER,
                                  v_pre_auth_no                 IN VARCHAR2,
                                  v_enrol_type_id               IN VARCHAR2)
  RETURN VARCHAR2
  IS
    
  CURSOR cur_corp_pol(vip_yn varchar2) IS
   SELECT case when nvl(vip_yn,'N')='Y' then gt.vip_pre_aprvl_limit_yn else gt.non_vip_pre_aprvl_limit_yn end as pre_aprvl_limit_yn,
          case when nvl(vip_yn,'N')='Y' then gt.vip_pre_aprvl_limit else gt.non_vip_pre_aprvl_limit end as pre_aprvl_limit,
          case when nvl(vip_yn,'N')='Y' then gt.vip_mdt_srvce_pre_aprvl_yn else gt.non_vip_mdt_srvce_pre_aprvl_yn end as pre_aprvl_mdt_srvc_yn 
        FROM tpa_enr_policy GH
        JOIN tpa_ins_prod_policy GT ON (GH.policy_seq_id=GT.policy_seq_id)
     WHERE GH.policy_seq_id=v_policy_seq_id;
     
  CURSOR cur_ind_pol(vip_yn varchar2) IS   
     SELECT case when nvl(vip_yn,'N')='Y' then tipp.vip_pre_aprvl_limit_yn else tipp.non_vip_pre_aprvl_limit_yn end as pre_aprvl_limit_yn,
            case when nvl(vip_yn,'N')='Y' then tipp.vip_pre_aprvl_limit else tipp.non_vip_pre_aprvl_limit end as pre_aprvl_limit,
            case when nvl(vip_yn,'N')='Y' then tipp.vip_mdt_srvce_pre_aprvl_yn else tipp.non_vip_mdt_srvce_pre_aprvl_yn end as pre_aprvl_mdt_srvc_yn
     FROM tpa_enr_policy tep
     LEFT OUTER JOIN tpa_ins_product tip on (tip.product_seq_id=tep.product_seq_id)
     LEFT OUTER JOIN tpa_ins_prod_policy tipp on (tipp.product_seq_id=tip.product_seq_id)
     WHERE tep.policy_seq_id=v_policy_seq_id;
  
  
  v_pre_approval_limit_yn      VARCHAR2(1);
  v_pre_approval_limit         NUMBER(10,2);
  v_pre_aprvl_mdt_srvc_yn      VARCHAR2(1);
  v_denial_code                VARCHAR2(200);
  
  
  BEGIN
    IF V_MEMBER_SEQ_ID IS NOT NULL AND V_CLAIM_TYPE ='CNH' THEN 
        IF v_enrol_type_id='COR' THEN
         OPEN  cur_corp_pol(v_vip_yn);
         FETCH cur_corp_pol INTO v_pre_approval_limit_yn,v_pre_approval_limit,v_pre_aprvl_mdt_srvc_yn;
         CLOSE cur_corp_pol;
        ELSE
         OPEN  cur_ind_pol(v_vip_yn);
         FETCH cur_ind_pol INTO v_pre_approval_limit_yn,v_pre_approval_limit,v_pre_aprvl_mdt_srvc_yn;
         CLOSE cur_ind_pol;
       END IF;
       
       IF NVL(v_pre_approval_limit_yn,'N')='Y' AND (v_clm_req_amount)> v_pre_approval_limit 
          AND v_pre_auth_no is null THEN 
              v_denial_code  := 'AUTH-001';
       END IF;
    END IF;

    RETURN(v_denial_code);
  
END check_prior_apr_dnl_code;
-------------------------------------------------------------------------------------------------------- 
FUNCTION check_prior_apr_dnl_desc(v_member_seq_id               IN NUMBER,
                                  v_policy_seq_id               IN NUMBER,
                                  v_vip_yn                      IN VARCHAR2,
                                  v_claim_type                  IN VARCHAR2,
                                  v_clm_req_amount              IN NUMBER,
                                  v_pre_auth_no                 IN VARCHAR2,
                                  v_enrol_type_id               IN VARCHAR2)
  RETURN VARCHAR2
  IS
    
  CURSOR cur_corp_pol(vip_yn varchar2) IS
   SELECT case when nvl(vip_yn,'N')='Y' then gt.vip_pre_aprvl_limit_yn else gt.non_vip_pre_aprvl_limit_yn end as pre_aprvl_limit_yn,
          case when nvl(vip_yn,'N')='Y' then gt.vip_pre_aprvl_limit else gt.non_vip_pre_aprvl_limit end as pre_aprvl_limit,
          case when nvl(vip_yn,'N')='Y' then gt.vip_mdt_srvce_pre_aprvl_yn else gt.non_vip_mdt_srvce_pre_aprvl_yn end as pre_aprvl_mdt_srvc_yn 
        FROM tpa_enr_policy GH
        JOIN tpa_ins_prod_policy GT ON (GH.policy_seq_id=GT.policy_seq_id)
     WHERE GH.policy_seq_id=v_policy_seq_id;
     
  CURSOR cur_ind_pol(vip_yn varchar2) IS   
     SELECT case when nvl(vip_yn,'N')='Y' then tipp.vip_pre_aprvl_limit_yn else tipp.non_vip_pre_aprvl_limit_yn end as pre_aprvl_limit_yn,
            case when nvl(vip_yn,'N')='Y' then tipp.vip_pre_aprvl_limit else tipp.non_vip_pre_aprvl_limit end as pre_aprvl_limit,
            case when nvl(vip_yn,'N')='Y' then tipp.vip_mdt_srvce_pre_aprvl_yn else tipp.non_vip_mdt_srvce_pre_aprvl_yn end as pre_aprvl_mdt_srvc_yn
     FROM tpa_enr_policy tep
     LEFT OUTER JOIN tpa_ins_product tip on (tip.product_seq_id=tep.product_seq_id)
     LEFT OUTER JOIN tpa_ins_prod_policy tipp on (tipp.product_seq_id=tip.product_seq_id)
     WHERE tep.policy_seq_id=v_policy_seq_id;
  
  
  v_pre_approval_limit_yn      varchar2(1);
  v_pre_approval_limit         number(10,2);
  v_pre_aprvl_mdt_srvc_yn      varchar2(1);
  v_denial_remarks             VARCHAR2(200);
  
  
  BEGIN
    IF V_MEMBER_SEQ_ID IS NOT NULL AND V_CLAIM_TYPE ='CNH' THEN 
        IF v_enrol_type_id='COR' THEN
         OPEN  cur_corp_pol(v_vip_yn);
         FETCH cur_corp_pol INTO v_pre_approval_limit_yn,v_pre_approval_limit,v_pre_aprvl_mdt_srvc_yn;
         CLOSE cur_corp_pol;
        ELSE
         OPEN  cur_ind_pol(v_vip_yn);
         FETCH cur_ind_pol INTO v_pre_approval_limit_yn,v_pre_approval_limit,v_pre_aprvl_mdt_srvc_yn;
         CLOSE cur_ind_pol;
       END IF;
       
       IF NVL(v_pre_approval_limit_yn,'N')='Y' AND (v_clm_req_amount)> v_pre_approval_limit 
          AND v_pre_auth_no is null THEN 
              v_denial_remarks  := 'Prior approval is required and was not obtained';
       END IF;
    END IF;

    RETURN(v_denial_remarks);
  
END check_prior_apr_dnl_desc;
-------------------------------------------------------------------------------------------------------- 
PROCEDURE save_exception_log(v_xml_seq_id            IN NUMBER,
                             v_clm_xml_seq_id        IN NUMBER,
                             v_sql_code              IN VARCHAR2,
                             v_sql_msg               IN VARCHAR2,
                             v_bulk_eror_msg         IN CLOB,
                             v_added_by              IN NUMBER,
                             v_proc_name             IN VARCHAR2,
                             v_hosp_seq_id           IN NUMBER)
 IS
 PRAGMA AUTONOMOUS_TRANSACTION;
 BEGIN
   
   INSERT INTO APP.CLM_BULK_EXCEPTION_LOGS
          (LOG_SEQ_ID,
           XML_SEQ_ID,
           CLM_XML_SEQ_ID,
           SQL_CODE,
           SQL_MSG,
           bulk_error_msg,
           ADDED_BY,
           ADDED_DATE,
           PROC_NAME,
           HOSP_SEQ_ID)
   VALUES (app.clm_blk_log_seq.nextval,
           v_xml_seq_id,
           v_clm_xml_seq_id,
           V_SQL_CODE,
           V_SQL_MSG,
           v_bulk_eror_msg,
           v_added_by,
           SYSDATE,
           v_proc_name,
           v_hosp_seq_id);
                                
  COMMIT;
 
 END save_exception_log;                        
-------------------------------------------------------------------------------------------------------- 
PROCEDURE get_error_log_list(v_xml_seq_id            IN NUMBER,
                             v_file_name             IN VARCHAR2,
                             v_from_date             IN VARCHAR2,
                             v_to_date               IN VARCHAR2,
                             v_hosp_seq_id           IN NUMBER,
                             v_sub_type              IN VARCHAR2,
                             v_sort_var              IN VARCHAR2,
                             v_sort_order            IN VARCHAR2,
                             v_start_num             IN NUMBER,
                             v_end_num               IN NUMBER,
                             result_set              OUT SYS_REFCURSOR)
 IS

  v_sql_str                       VARCHAR2(10000);
  
  TYPE bind_tab_type IS TABLE OF VARCHAR2(250) INDEX BY BINARY_INTEGER ;
  bind_tab                             bind_tab_type;
  i                                    NUMBER(2) := 0;
  v_where                              VARCHAR2(2000); 
  
 BEGIN
   
 IF v_sub_type='DTC' THEN 
   
     v_sql_str := 'SELECT XML_SEQ_ID,FILE_NAME,TO_CHAR(ADDED_DATE,''DD/MM/YYYY HH24:MI:SS'') ADDED_DATE,HOSP_SEQ_ID,SOURCE_TYPE
                   FROM(SELECT DISTINCT X.XML_SEQ_ID,X.FILE_NAME,X.ADDED_DATE,C.HOSP_SEQ_ID,C.SOURCE_TYPE
                        FROM APP.CLM_BULK_UPLD_XML_DTA X 
                        JOIN APP.CLM_BULK_UPLD_XML_DETAILS C ON (X.XML_SEQ_ID = C.XML_SEQ_ID)
                        WHERE C.REMARKS IS NOT NULL  AND  NVL(X.SUB_TYPE,''DTC'')=''DTC''
                        UNION ALL
                         SELECT C.XML_SEQ_ID,X.FILE_NAME,C.ADDED_DATE,C.HOSP_SEQ_ID,(SELECT DISTINCT XD.SOURCE_TYPE
                                                                                      FROM APP.CLM_BULK_UPLD_XML_DETAILS XD
                                                                                      WHERE XD.XML_SEQ_ID = X.XML_SEQ_ID
                                                                                     ) AS SOURCE_TYPE
                                           FROM APP.CLM_BULK_EXCEPTION_LOGS C
                                           JOIN APP.CLM_BULK_UPLD_XML_DTA X ON (C.XML_SEQ_ID=X.XML_SEQ_ID)
										   /*LEFT OUTER JOIN APP.CLM_BULK_UPLD_XML_DETAILS XD ON(XD.XML_SEQ_ID=X.XML_SEQ_ID)*/
                       ) WHERE XML_SEQ_ID IS NOT NULL';
 
 ELSIF v_sub_type='DTR' THEN
     v_sql_str :='SELECT X.XML_SEQ_ID,X.FILE_NAME,X.HOSP_SEQ_ID,X.SOURCE_TYPE,TO_CHAR(X.ADDED_DATE,''DD/MM/YYYY HH24:MI:SS'') ADDED_DATE 
                   FROM APP.CLM_BULK_UPLD_XML_DTA X
                   WHERE  NVL(X.SUB_TYPE,''DTC'')=''DTR''';
 ELSE 
     v_sql_str := 'SELECT XML_SEQ_ID,FILE_NAME,TO_CHAR(ADDED_DATE,''DD/MM/YYYY HH24:MI:SS'') ADDED_DATE,HOSP_SEQ_ID,SOURCE_TYPE
                   FROM(SELECT DISTINCT X.XML_SEQ_ID,X.FILE_NAME,X.ADDED_DATE,C.HOSP_SEQ_ID,C.SOURCE_TYPE
                        FROM APP.CLM_BULK_UPLD_XML_DTA X 
                        JOIN APP.CLM_BULK_UPLD_XML_DETAILS C ON (X.XML_SEQ_ID = C.XML_SEQ_ID)
                        WHERE C.REMARKS IS NOT NULL AND NVL(X.SUB_TYPE,''DTC'')=''DTC'' 
                        UNION ALL
                         SELECT C.XML_SEQ_ID,X.FILE_NAME,C.ADDED_DATE,C.HOSP_SEQ_ID,(SELECT DISTINCT XD.SOURCE_TYPE
                                                                                      FROM APP.CLM_BULK_UPLD_XML_DETAILS XD
                                                                                      WHERE XD.XML_SEQ_ID = X.XML_SEQ_ID
                                                                                     ) AS SOURCE_TYPE
                                           FROM APP.CLM_BULK_EXCEPTION_LOGS C
                                           JOIN APP.CLM_BULK_UPLD_XML_DTA X ON (C.XML_SEQ_ID=X.XML_SEQ_ID)
                       )
                       UNION
                       SELECT XML_SEQ_ID,FILE_NAME,TO_CHAR(ADDED_DATE,''DD/MM/YYYY HH24:MI:SS'') ADDED_DATE,HOSP_SEQ_ID,SOURCE_TYPE 
                        FROM APP.CLM_BULK_UPLD_XML_DTA
                         WHERE  NVL(SUB_TYPE,''DTC'')=''DTR'''; 
     
 END IF;
 
  
    IF v_xml_seq_id IS NOT NULL THEN
      v_where := v_where  ||' AND XML_SEQ_ID = :v_xml_seq_id ';
       i := i+1;
       bind_tab(i) := UPPER(v_xml_seq_id);
    END IF;
    
    IF v_hosp_seq_id IS NOT NULL THEN
      v_where := v_where  ||' AND HOSP_SEQ_ID = :v_hosp_seq_id ';
       i := i+1;
       bind_tab(i) := UPPER(v_hosp_seq_id);
    END IF;
    
    IF v_file_name IS NOT NULL THEN
      v_where := v_where  ||' AND FILE_NAME = :v_file_name ';
       i := i+1;
       bind_tab(i) := (v_file_name);
    END IF;
    
    IF v_from_date IS NOT NULL THEN
       v_where := v_where  ||' AND TRUNC(added_date) >= :v_from_date ';
       i := i+1;
       bind_tab(i) := to_date(v_from_date,'DD/MM/YYYY');
    END IF;
    
    IF v_to_date IS NOT NULL THEN
       v_where := v_where  ||' AND TRUNC(added_date) <= :v_to_date ';
       i := i+1;
       bind_tab(i) := to_date(v_to_date,'DD/MM/YYYY');
    END IF;
    
    IF v_where IS NOT NULL THEN
      --v_where   := ' WHERE '|| SUBSTR(v_where,5);
      v_sql_str := v_sql_str ||v_where;
    END IF;


    v_sql_str := 'SELECT * FROM
        (SELECT A.*,DENSE_RANK() OVER (ORDER BY '||v_sort_var||' '||v_sort_order||' NULLS LAST ,ROWNUM)
        Q FROM (' ||v_sql_str|| ') A ) WHERE  Q>= :v_start_num AND Q<= :v_end_num ';
        
    IF bind_tab.FIRST IS NOT NULL THEN
       CASE bind_tab.COUNT
         WHEN 1  THEN OPEN result_set FOR v_sql_str USING bind_tab(1) , v_start_num , v_end_num ;
         WHEN 2  THEN OPEN result_set FOR v_sql_str USING bind_tab(1), bind_tab(2), v_start_num, v_end_num ;
         WHEN 3  THEN OPEN result_set FOR v_sql_str USING bind_tab(1), bind_tab(2), bind_tab(3), v_start_num, v_end_num ;
         WHEN 4  THEN OPEN result_set FOR v_sql_str USING bind_tab(1), bind_tab(2), bind_tab(3), bind_tab(4), v_start_num, v_end_num ;
         WHEN 5  THEN OPEN result_set FOR v_sql_str USING bind_tab(1), bind_tab(2), bind_tab(3), bind_tab(4),bind_tab(5), v_start_num, v_end_num ;
       END CASE;
     ELSE
       OPEN result_set FOR v_sql_str USING v_start_num , v_end_num ;
     END IF;
   
 END get_error_log_list;        
-------------------------------------------------------------------------------------------------------- 
PROCEDURE get_error_log(v_xml_seq_id            IN VARCHAR2,
                        result_set              OUT SYS_REFCURSOR)
 IS
  v_data_issue_cnt                NUMBER(10);
  v_exception_cnt                 NUMBER(10);
  v_source_type                   VARCHAR2(5);
  cursor source_type_cur is
   SELECT X.SOURCE_TYPE  
    FROM APP.CLM_BULK_UPLD_XML_DETAILS X 
  WHERE X.XML_SEQ_ID = v_xml_seq_id AND ROWNUM=1;
  
  CURSOR Get_Submission_Type IS
    SELECT NVL(DT.SUB_TYPE,'DTC') AS Sub_Type
     FROM CLM_BULK_UPLD_XML_DTA DT
    WHERE DT.XML_SEQ_ID = v_xml_seq_id;
    
   Get_Submission_Rec Get_Submission_Type%ROWTYPE; 
 BEGIN

   SELECT COUNT(1) INTO v_data_issue_cnt FROM APP.CLM_BULK_UPLD_XML_DETAILS X WHERE X.XML_SEQ_ID = v_xml_seq_id AND X.REMARKS IS NOT NULL;
   SELECT COUNT(1) INTO v_exception_cnt FROM APP.CLM_BULK_EXCEPTION_LOGS L WHERE L.XML_SEQ_ID = v_xml_seq_id;
   --SELECT X.SOURCE_TYPE INTO v_source_type FROM APP.CLM_BULK_UPLD_XML_DETAILS X WHERE X.XML_SEQ_ID = v_xml_seq_id AND ROWNUM=1;
   open source_type_cur;
   fetch source_type_cur into v_source_type;
   close source_type_cur;
   
   OPEN Get_Submission_Type;
     FETCH Get_Submission_Type INTO Get_Submission_Rec;
       CLOSE Get_Submission_Type;
   
  IF Get_Submission_Rec.Sub_Type ='DTC' THEN 
   IF v_source_type !='PBCL' THEN
   IF v_data_issue_cnt > 0 THEN
    OPEN result_set FOR
     SELECT S_NO AS SL_NO,
            INVOICE_NO,
            MEMBER_NAME,
            MEMBER_ID,
            PREAPPROVAL_NO,
            DATE_TREATMENT,
            DATE_DISCHARGE,
            MED_TYPE,
            BENEFIT_TYPE,
            ENCOUNTER_TYPE,
            CLINICIAN_ID,
            CLINICIAN_NAME,
            SYMPTOMS,
            PRINCIPAL_ICD,
            ICD_DESCRIPTION,
            SECONDARY_ICD_CODE1,
            SECONDARY_ICD_CODE2,
            SECONDARY_ICD_CODE3,
            SECONDARY_ICD_CODE4,
            SECONDARY_ICD_CODE5,
            FIRST_INCIDENT_DATE,
            FIRST_REPORTED_DATE,
            SERVICE_DATE,
            ACTIVITY_TYPE,
            INTERNAL_SERVICE_CODE,
            SERVICE_DESCRIPTION,
            CPT_CODE,
            AMOUNT_CLAIMED,
            QUANTITY,
            TOOTH_NUMBER,
            DATE_OF_LMP,
            NATURE_OF_CONCEPTION,
            OBSERVATION,
            EVENT_REF_NO,
            TO_CHAR(X.REMARKS) AS EROR_LOGS
     FROM APP.CLM_BULK_UPLD_XML_DETAILS X
     WHERE X.XML_SEQ_ID = v_xml_seq_id
     ORDER BY X.PREAPPROVAL_NO,X.INVOICE_NO;
   ELSE
     OPEN result_set FOR 
     SELECT NULL AS SL_NO,
            NULL AS INVOICE_NO,
            NULL AS MEMBER_NAME,
            NULL AS MEMBER_ID,
            NULL AS PREAPPROVAL_NO,
            NULL AS DATE_TREATMENT,
            NULL AS DATE_DISCHARGE,
            NULL AS MED_TYPE,
            NULL AS BENEFIT_TYPE,
            NULL AS ENCOUNTER_TYPE,
            NULL AS CLINICIAN_ID,
            NULL AS CLINICIAN_NAME,
            NULL AS SYMPTOMS,
            NULL AS PRINCIPAL_ICD,
            NULL AS ICD_DESCRIPTION,
            NULL AS SECONDARY_ICD_CODE1,
            NULL AS SECONDARY_ICD_CODE2,
            NULL AS SECONDARY_ICD_CODE3,
            NULL AS SECONDARY_ICD_CODE4,
            NULL AS SECONDARY_ICD_CODE5,
            NULL AS FIRST_INCIDENT_DATE,
            NULL AS FIRST_REPORTED_DATE,
            NULL AS SERVICE_DATE,
            NULL AS ACTIVITY_TYPE,
            NULL AS INTERNAL_SERVICE_CODE,
            NULL AS SERVICE_DESCRIPTION,
            NULL AS CPT_CODE,
            NULL AS AMOUNT_CLAIMED,
            NULL AS QUANTITY,
            NULL AS TOOTH_NUMBER,
            NULL AS DATE_OF_LMP,
            NULL AS NATURE_OF_CONCEPTION,
            NULL AS OBSERVATION,
            NULL AS EVENT_REF_NO,
            NVL(L.SQL_MSG,TO_CHAR(L.BULK_ERROR_MSG)) AS EROR_LOGS
     FROM APP.CLM_BULK_EXCEPTION_LOGS L
     WHERE L.XML_SEQ_ID = v_xml_seq_id;
   END IF;            
   ELSE
     IF v_data_issue_cnt > 0 THEN
     OPEN result_set FOR
     SELECT S_NO AS SL_NO,
            INVOICE_NO,
            MEMBER_NAME,
            MEMBER_ID,
            PREAPPROVAL_NO,
            DATE_TREATMENT,--DATE OF PRECREPTION
            --DATE_DISCHARGE,
            MED_TYPE,
            BENEFIT_TYPE,
            ENCOUNTER_TYPE,
            CLINICIAN_ID,
            CLINICIAN_NAME,
            --SYMPTOMS,
            PRINCIPAL_ICD,
            ICD_DESCRIPTION,
            SECONDARY_ICD_CODE1,
            SECONDARY_ICD_CODE2,
            SECONDARY_ICD_CODE3,
            SECONDARY_ICD_CODE4,
            SECONDARY_ICD_CODE5,
            --FIRST_INCIDENT_DATE,
            --FIRST_REPORTED_DATE,
            --SERVICE_DATE,
            ACTIVITY_TYPE,
            INTERNAL_SERVICE_CODE,
            SERVICE_DESCRIPTION,
            --CPT_CODE,
            AMOUNT_CLAIMED,
            QUANTITY,
            --TOOTH_NUMBER,
            --DATE_OF_LMP,
            --NATURE_OF_CONCEPTION,
            OBSERVATION,
            EVENT_REF_NO,
            TO_CHAR(X.REMARKS) AS EROR_LOGS,
            MOPH_CODES,
            UNIT_TYPE,
            TO_CHAR(DUR_MEDI) AS DUR_MEDI
     FROM APP.CLM_BULK_UPLD_XML_DETAILS X
     WHERE X.XML_SEQ_ID = v_xml_seq_id
     ORDER BY X.PREAPPROVAL_NO,X.INVOICE_NO;
     ELSE
     OPEN result_set FOR
     SELECT NULL AS SL_NO,
            NULL AS INVOICE_NO,
            NULL AS MEMBER_NAME,
            NULL AS MEMBER_ID,
            NULL AS PREAPPROVAL_NO,
            NULL AS DATE_TREATMENT,--DATE OF PRECREPTION
            --DATE_DISCHARGE,
            NULL AS MED_TYPE,
            NULL AS BENEFIT_TYPE,
            NULL AS ENCOUNTER_TYPE,
            NULL AS CLINICIAN_ID,
            NULL AS CLINICIAN_NAME,
            --SYMPTOMS,
            NULL AS PRINCIPAL_ICD,
            NULL AS ICD_DESCRIPTION,
            NULL AS SECONDARY_ICD_CODE1,
            NULL AS SECONDARY_ICD_CODE2,
            NULL AS SECONDARY_ICD_CODE3,
            NULL AS SECONDARY_ICD_CODE4,
            NULL AS SECONDARY_ICD_CODE5,
            --FIRST_INCIDENT_DATE,
            --AS FIRST_REPORTED_DATE,
            --SERVICE_DATE,
            NULL AS ACTIVITY_TYPE,
            NULL AS INTERNAL_SERVICE_CODE,
            NULL AS SERVICE_DESCRIPTION,
            --CPT_CODE,
            NULL AS AMOUNT_CLAIMED,
            NULL AS QUANTITY,
            --TOOTH_NUMBER,
            --DATE_OF_LMP,
            --NATURE_OF_CONCEPTION,
            NULL AS OBSERVATION,
            NULL AS EVENT_REF_NO,
            NVL(L.SQL_MSG,TO_CHAR(L.BULK_ERROR_MSG)) AS EROR_LOGS,
            NULL AS MOPH_CODES,
            NULL AS UNIT_TYPE,
            NULL AS DUR_MEDI
            FROM APP.CLM_BULK_EXCEPTION_LOGS L
     WHERE L.XML_SEQ_ID = v_xml_seq_id;
     END IF;
     END IF;
   ELSE
     OPEN result_set FOR
      SELECT * FROM 
       (SELECT 
          TO_CHAR(DT.S_NO) as SL_NO,
          TO_NUMBER(DT.S_NO) as OR_NO,
          DT.MEM_NAME,
          DT.MEMBER_ID,
          DT.PARENT_CLAIM_NO,
          DT.PARENT_CLM_SET_NO,
          TO_CHAR(DT.RESUB_REQ_AMT) AS RESUB_REQ_AMT,
          TO_CHAR(DT.REQ_QUANT) AS REQ_QUANT,
          DT.SERVICE_DATE,
          DT.ACT_TYPE,
          DT.INTERNAL_CODE,
          DT.ALKOOT_REMARKS,
          DT.RESUB_JUST_REM,
          NVL(DT.SYS_REMARKS,EX.SQL_MSG) as EROR_LOGS,
          DT.RES_REC_DATE,
          DT.CPT_CODE,
          DT.SERV_DESC,
          DT.TOOTH_NO as TOOTH_NO
       FROM APP.CLM_BULK_UPLD_RESUB_DTLS DT
       LEFT OUTER JOIN APP.CLM_BULK_EXCEPTION_LOGS EX ON (DT.XML_SEQ_ID= EX.XML_SEQ_ID)
        WHERE DT.XML_SEQ_ID = v_xml_seq_id) ORDER BY OR_NO ASC ;   
   END IF;  
END get_error_log;                            
--------------------------------------------------------------------------------------------------------
PROCEDURE save_time_details(v_xml_seq_id            IN NUMBER,
                            v_flag                  IN VARCHAR2,
                            v_start_time            IN NUMBER)
IS
PRAGMA AUTONOMOUS_TRANSACTION;
BEGIN
  
  IF v_flag = 'EXTRCT_CLM' THEN
    UPDATE APP.CLM_BULK_UPLD_XML_DTA X
      SET X.TIME_TO_READ_XML = (dbms_utility.get_time - v_start_time)/100
    WHERE X.XML_SEQ_ID = v_xml_seq_id;
  ELSIF v_flag = 'MAND_VALD' THEN
    UPDATE APP.CLM_BULK_UPLD_XML_DTA X
     SET X.time_to_update_mand_val = (dbms_utility.get_time - v_start_time)/100
    WHERE X.XML_SEQ_ID = v_xml_seq_id;
  ELSIF v_flag = 'DATA_VALD' THEN  
    UPDATE APP.CLM_BULK_UPLD_XML_DTA X
     SET X.time_to_data_vald = (dbms_utility.get_time - v_start_time)/100
    WHERE X.XML_SEQ_ID = v_xml_seq_id;
  ELSIF v_flag = 'SPLIT_CLM' THEN  
    UPDATE APP.CLM_BULK_UPLD_XML_DTA X
     SET X.time_to_split_dta = (dbms_utility.get_time - v_start_time)/100
    WHERE X.XML_SEQ_ID = v_xml_seq_id;
  ELSIF v_flag = 'UPLOAD_CLM' THEN  
    UPDATE APP.CLM_BULK_UPLD_XML_DTA X
     SET X.time_to_upld_clms = (dbms_utility.get_time - v_start_time)/100
    WHERE X.XML_SEQ_ID = v_xml_seq_id;
  ELSIF v_flag = 'XML_HOSP_SEQ_ID' THEN  
    UPDATE APP.CLM_BULK_UPLD_XML_DTA XD
     SET XD.HOSP_SEQ_ID   = v_start_time
    WHERE XD.XML_SEQ_ID = v_xml_seq_id;
  -----Capturing timings for claim Resubmission  
  ELSIF v_flag = 'EXTRCT_RESUB_CLM' THEN
   UPDATE APP.CLM_BULK_UPLD_XML_DTA XD
     SET XD.Time_To_Read_Xml   = (dbms_utility.get_time - v_start_time)/100
    WHERE XD.XML_SEQ_ID = v_xml_seq_id;
  ELSIF v_flag = 'VALIDATE_RES_DATA' THEN
   UPDATE APP.CLM_BULK_UPLD_XML_DTA XD
     SET XD.Time_To_Data_Vald   = (dbms_utility.get_time - v_start_time)/100
    WHERE XD.XML_SEQ_ID = v_xml_seq_id;
  ELSIF v_flag= 'COPYING_CLAIMS' THEN  
   UPDATE APP.CLM_BULK_UPLD_XML_DTA XD
     SET XD.Time_To_Split_Dta   = (dbms_utility.get_time - v_start_time)/100
    WHERE XD.XML_SEQ_ID = v_xml_seq_id;
  END IF;
    
 COMMIT;   
    
END save_time_details;
-------------------------------------------------------------------------------------------------------- 
PROCEDURE claim_upload_validation(v_xml_seq_id       IN OUT NUMBER,
                                  v_added_by         IN NUMBER)
 IS
   
 v_clm_batch_seq_id       APP.clm_bulk_upld_clm_details.clm_batch_seq_id%type;
 v_batch_no               APP.clm_bulk_upld_clm_details.batch_no%type;
 v_tot_rec_cnt            APP.clm_bulk_upld_xml_dta.tot_rec_cnt%type;
 v_fail_cnt               APP.clm_bulk_upld_xml_dta.fail_cnt%type;
 v_success_cnt            APP.clm_bulk_upld_xml_dta.success_cnt%type;
 v_tot_claim_cnt          APP.clm_bulk_upld_xml_dta.TOT_CLM_CNT%type;
 v_tot_icd_cnt            APP.clm_bulk_upld_xml_dta.TOT_CLM_ICD_CNT%type;
 v_tot_act_cnt            APP.clm_bulk_upld_xml_dta.TOT_CLM_ACT_CNT%type;
 v_batch_tot_amnt         APP.clm_batch_upload_details.batch_tot_amount%type;
                        
 
 
 CURSOR cur_btch_tot_amnt(v_clm_batch_seq_id  NUMBER) IS
  SELECT TO_CHAR(CB.BATCH_TOT_AMOUNT) AS BATCH_TOT_AMOUNT
  FROM APP.CLM_BATCH_UPLOAD_DETAILS CB
  WHERE CB.CLM_BATCH_SEQ_ID = v_clm_batch_seq_id;
  
 CURSOR cur_hosp_seq_id IS
 SELECT X.HOSP_SEQ_ID
 FROM APP.CLM_BULK_UPLD_XML_DETAILS X
 WHERE X.XML_SEQ_ID = V_XML_SEQ_ID
  AND ROWNUM = 1;    
 
   v_data_issue_cnt                NUMBER(10);
   v_exception_cnt                 NUMBER(10);
   v_extrct_data_prsnt_cnt         NUMBER(10);
   v_temp_clm_data_cnt             NUMBER(10);
   v_sql_code                      VARCHAR2(100);
   v_sql_msg                       VARCHAR2(4000);
   V_HOSP_SEQ_ID                   NUMBER(30);
   
  
  CURSOR clm_batch_seq  IS SELECT c.clm_batch_seq_id  FROM CLM_BULK_UPLD_CLM_DETAILS c
  where c.xml_seq_id =v_xml_seq_id ;
  v_prod_policy_rule_seq_id       APP.TPA_INS_PROD_POLICY_RULES.PROD_POLICY_RULE_SEQ_ID%TYPE;
   
 BEGIN
   
   
   OPEN  clm_batch_seq;
   FETCH clm_batch_seq INTO v_clm_batch_seq_id;
   CLOSE clm_batch_seq;
   
   OPEN  cur_hosp_seq_id;
   FETCH cur_hosp_seq_id INTO V_HOSP_SEQ_ID;
   CLOSE cur_hosp_seq_id;
   
   SELECT COUNT(1) INTO v_extrct_data_prsnt_cnt FROM APP.CLM_BULK_UPLD_XML_DETAILS X WHERE X.XML_SEQ_ID = v_xml_seq_id;
   SELECT COUNT(1) INTO v_data_issue_cnt FROM APP.CLM_BULK_UPLD_XML_DETAILS X WHERE X.XML_SEQ_ID = v_xml_seq_id AND X.REMARKS IS NOT NULL;
   SELECT COUNT(1) INTO v_exception_cnt FROM APP.CLM_BULK_EXCEPTION_LOGS L WHERE L.XML_SEQ_ID = v_xml_seq_id;
   
   

   SELECT COUNT(1) INTO v_temp_clm_data_cnt 
   FROM APP.CLM_BULK_UPLD_CLM_DETAILS C
   JOIN APP.CLM_BULK_UPLD_DIAG_DETAILS D ON (C.CLM_XML_SEQ_ID=D.CLM_XML_SEQ_ID)
   JOIN APP.CLM_BULK_UPLD_ACT_DETAILS A ON (C.CLM_XML_SEQ_ID=A.CLM_XML_SEQ_ID)
   WHERE C.XML_SEQ_ID = v_xml_seq_id;
   
   SELECT COUNT(1) INTO v_exception_cnt FROM APP.CLM_BULK_EXCEPTION_LOGS L WHERE L.XML_SEQ_ID = v_xml_seq_id;
   
   IF v_extrct_data_prsnt_cnt > 0 AND v_temp_clm_data_cnt >0 AND v_data_issue_cnt = 0 AND v_exception_cnt = 0 THEN
     save_claim_details(v_xml_seq_id,v_clm_batch_seq_id,v_batch_no,v_added_by);
   END IF;
   
   SELECT COUNT(1) INTO v_exception_cnt FROM APP.CLM_BULK_EXCEPTION_LOGS L WHERE L.XML_SEQ_ID = v_xml_seq_id;
   
   SELECT COUNT(1) INTO v_tot_rec_cnt
   FROM APP.CLM_BULK_UPLD_XML_DETAILS X
   WHERE X.XML_SEQ_ID = v_xml_seq_id;
   
   SELECT COUNT(1) INTO v_fail_cnt
   FROM APP.CLM_BULK_UPLD_XML_DETAILS X
   WHERE X.XML_SEQ_ID = v_xml_seq_id
     AND X.REMARKS IS NOT NULL;
     
   v_fail_cnt := CASE WHEN v_fail_cnt != 0 THEN v_fail_cnt
                      ELSE v_exception_cnt END;
   
   SELECT COUNT(1) INTO v_success_cnt
   FROM APP.CLM_BULK_UPLD_XML_DETAILS X
   WHERE X.XML_SEQ_ID = v_xml_seq_id
     AND X.REMARKS IS NULL;
   
   
   
   SELECT COUNT(1) INTO v_tot_claim_cnt
   FROM APP.CLM_BULK_UPLD_CLM_DETAILS C
   WHERE C.XML_SEQ_ID = v_xml_seq_id;
   
   SELECT COUNT(1) INTO v_tot_icd_cnt
   FROM APP.CLM_BULK_UPLD_DIAG_DETAILS D
   WHERE D.XML_SEQ_ID = v_xml_seq_id;
   
   SELECT COUNT(1) INTO v_tot_act_cnt
   FROM APP.CLM_BULK_UPLD_CLM_DETAILS C
   JOIN APP.CLM_BULK_UPLD_ACT_DETAILS A ON (C.CLM_XML_SEQ_ID=A.CLM_XML_SEQ_ID)
   WHERE C.XML_SEQ_ID = v_xml_seq_id;
   
   UPDATE APP.CLM_BULK_UPLD_XML_DTA X
     SET X.TOT_CLM_CNT     = v_tot_claim_cnt,
         X.TOT_CLM_ICD_CNT = v_tot_icd_cnt,
         X.TOT_CLM_ACT_CNT = v_tot_act_cnt,
         X.TOT_REC_CNT     = v_tot_rec_cnt,
         X.FAIL_CNT        = CASE WHEN v_fail_cnt != 0 THEN v_fail_cnt
                                  ELSE v_exception_cnt END,
         X.SUCCESS_CNT     = v_success_cnt,
         X.PROCESSED_YN    = case when v_exception_cnt>0 then 'N' else 'Y' end
   WHERE X.XML_SEQ_ID = v_xml_seq_id;
    
   OPEN  cur_btch_tot_amnt(v_clm_batch_seq_id);
   FETCH cur_btch_tot_amnt INTO v_batch_tot_amnt;
   CLOSE cur_btch_tot_amnt;
   
  FOR i IN (select clm.claim_seq_id,clm.member_seq_id , clm.policy_seq_id from app.clm_authorization_details clm where clm.clm_batch_seq_id= v_clm_batch_seq_id)
   LOOP
      v_prod_policy_rule_seq_id := pat_xml_load_pkg.get_prod_pol_seq_id(i.policy_seq_id,'POL');
      pat_xml_load_pkg.execute_global_rules('C', i.claim_seq_id, i.member_seq_id, v_prod_policy_rule_seq_id);
   END LOOP; 
     
   --claim_adjudication(v_xml_seq_id);
   
   COMMIT;
   
 EXCEPTION
  WHEN OTHERS THEN
     V_SQL_CODE := SQLCODE;
     V_SQL_MSG  := SQLERRM; 
   
     save_exception_log(v_xml_seq_id,NULL,v_sql_code,v_sql_msg,NULL,v_added_by,'claim_upload',V_HOSP_SEQ_ID);
     ROLLBACK;
     
 END claim_upload_validation;
 --------------------------------------------------------------------------------------------------------
 PROCEDURE save_clm_batch_xml(v_xml_seq_id            IN NUMBER,
                               v_clm_batch_seq_id      OUT clm_batch_upload_details.clm_batch_seq_id%type,
                               v_batch_no              OUT clm_batch_upload_details.batch_no%type,
                               v_added_by              IN NUMBER)
  IS

 
 
  
  CURSOR hosp_cur(v_hos_seq_id NUMBER) IS
    SELECT t.hosp_seq_id,t.hosp_licenc_numb, t.hosp_name, ha.address_1, ha.city_type_id, ha.state_type_id, ha.pin_code, t.primary_network,
           t.off_phone_no_1, t.office_fax_no, t.empanel_number,ha.country_id
    FROM Tpa_Hosp_Info t
    JOIN tpa_hosp_address ha   ON (ha.hosp_seq_id = t.hosp_seq_id)
    WHERE t.hosp_seq_id = v_hos_seq_id;
    
  hosp_rec hosp_cur%ROWTYPE;   
  
 
 
     
 

     
 CURSOR cur_xml_claim_info IS
   SELECT C.SOURCE_TYPE,C.RECEIVED_DATE,C.HOSP_SEQ_ID
   FROM APP.CLM_BULK_UPLD_XML_DETAILS C
   WHERE C.XML_SEQ_ID = v_xml_seq_id
    AND ROWNUM = 1;
   
 rec_xml_claim_info                 cur_xml_claim_info%ROWTYPE; 
 
 CURSOR cur_asign_usr_info IS
   SELECT BC.CLAIM_SEQ_ID,B.ASSIGN_USERS_SEQ_ID
   FROM APP.CLM_BULK_UPLD_CLM_DETAILS BC
   JOIN ASSIGN_USERS B ON ( BC.CLAIM_SEQ_ID=B.CLAIM_SEQ_ID)
   WHERE BC.XML_SEQ_ID = v_xml_seq_id;
   

   
   
 CURSOR cur_tot_claim_insrt_cnt IS
   SELECT COUNT(1)       
    FROM APP.CLM_BULK_UPLD_CLM_DETAILS C
    JOIN APP.TPA_ENR_POLICY_MEMBER M ON (C.MEMBER_SEQ_ID=M.MEMBER_SEQ_ID)
    JOIN APP.TPA_ENR_MEM_ADDRESS A ON (M.ENR_ADDRESS_SEQ_ID=A.ENR_ADDRESS_SEQ_ID)
    JOIN APP.TPA_ENR_POLICY_GROUP PG ON (M.POLICY_GROUP_SEQ_ID=PG.POLICY_GROUP_SEQ_ID)
    JOIN APP.TPA_ENR_POLICY EP ON (PG.POLICY_SEQ_ID=EP.POLICY_SEQ_ID)
    LEFT OUTER JOIN TPA_ENR_BALANCE B ON (PG.POLICY_GROUP_SEQ_ID=B.POLICY_GROUP_SEQ_ID)
    LEFT OUTER JOIN APP.PAT_AUTHORIZATION_DETAILS PA ON (C.PREAPPROVAL_NO=PA.PRE_AUTH_NUMBER AND PA.PAT_ENHANCED_YN = 'N')
    WHERE C.XML_SEQ_ID = v_xml_seq_id
     AND (M.MEM_GENERAL_TYPE_ID != 'PFL' 
     AND M.MEMBER_SEQ_ID = B.MEMBER_SEQ_ID OR B.MEMBER_SEQ_ID IS NULL OR M.MEMBER_SEQ_ID IS NULL);
  
             

        
       
 
  
 
 
 TYPE typ_asign_usr_info IS TABLE OF cur_asign_usr_info%ROWTYPE INDEX BY PLS_INTEGER;
 rec_asign_usr_info              typ_asign_usr_info; 
 
 
 
  CURSOR cur_clm_seq_dtls IS
  SELECT NVL(G.QTR_CLM_NO_MAX_SEQ_RCH,0) AS QTR_CLM_NO_MAX_SEQ_RCH,
         NVL(G.IND_CLM_NO_MAX_SEQ_RCH,0) AS IND_CLM_NO_MAX_SEQ_RCH,
         NVL(G.OTH_CLM_NO_MAX_SEQ_RCH,0) AS OTH_CLM_NO_MAX_SEQ_RCH
  FROM APP.TPA_SEQ_NO_GEN_DETAILS G;
  
  rec_clm_seq_dtls          cur_clm_seq_dtls%ROWTYPE;
  
  CURSOR cur_clm_fl_mx_seq_dtls(v_file_no VARCHAR2) IS
  SELECT SUBSTR(G.CLM_FILE_NO_MAX,1,INSTR(G.CLM_FILE_NO_MAX,'-',-1)-1) AS FILE_NO_FRMT,
         (SUBSTR(G.CLM_FILE_NO_MAX,INSTR(G.CLM_FILE_NO_MAX,'-',-1)+1)) AS FILE_NO_MAX_SEQ
  FROM APP.TPA_SEQ_NO_GEN_DETAILS G
   WHERE G.CLM_FILE_NO_MAX LIKE v_file_no||'%';
  
   
  
  CURSOR cur_batch_sum IS
    SELECT ROUND(SUM(NVL(C.REQUESTED_AMOUNT,0)),2)
     FROM APP.CLM_BULK_UPLD_CLM_DETAILS C
    WHERE C.XML_SEQ_ID = v_xml_seq_id; 
    
                                               
 
  bulk_errors EXCEPTION;
  PRAGMA EXCEPTION_INIT(bulk_errors, -24381);
  l_error_count  NUMBER;
  
  v_sql_code                              VARCHAR2(100);
  v_sql_msg                               VARCHAR2(4000);
  v_bulk_error_msg                        CLOB;
  v_start_time                            NUMBER;
  v_qtr_claim_count                       NUMBER(10);  
  v_ind_claim_count                       NUMBER(10);                                              
  v_oth_claim_count                       NUMBER(10);
  v_tot_claim_cnt                         NUMBER(10);
  v_batch_tot_amnt                        NUMBER(38,4);
  v_hosp_seq_id                           NUMBER(30);
  v_tot_clm_insrt_cnt                     NUMBER(30);
  unique_const_excp                       EXCEPTION;
  v_file_no_frmt                          VARCHAR2(200);
  v_clm_file_no_max                       VARCHAR2(200);
  v_file_no                               VARCHAR2(200);
  
BEGIN
  
 v_start_time := dbms_utility.get_time;
 
 OPEN  cur_xml_claim_info;
 FETCH cur_xml_claim_info INTO rec_xml_claim_info;
 CLOSE cur_xml_claim_info;

 OPEN  hosp_cur(rec_xml_claim_info.hosp_seq_id);
 FETCH hosp_cur INTO hosp_rec;
 CLOSE hosp_cur;
 
 OPEN  cur_clm_seq_dtls;
 FETCH cur_clm_seq_dtls INTO rec_clm_seq_dtls;
 CLOSE cur_clm_seq_dtls;
 
 v_file_no := 'FL-'||TO_CHAR(SYSDATE,'DDMMYYYY')||'-';
 
 OPEN  cur_clm_fl_mx_seq_dtls(v_file_no);
 FETCH cur_clm_fl_mx_seq_dtls INTO v_file_no_frmt,v_clm_file_no_max;
 CLOSE cur_clm_fl_mx_seq_dtls;
 
 IF v_clm_file_no_max IS NULL THEN
    v_clm_file_no_max := 1;
    v_file_no         := 'FL-'||TO_CHAR(SYSDATE,'DDMMYYYY')||'-00001';
 ELSE
    v_clm_file_no_max := TO_NUMBER(v_clm_file_no_max);
    v_file_no         := v_file_no_frmt||'-'||LPAD((v_clm_file_no_max+v_tot_clm_insrt_cnt),5,'0');
 END IF;
 
 
 OPEN  cur_tot_claim_insrt_cnt;
 FETCH cur_tot_claim_insrt_cnt INTO v_tot_clm_insrt_cnt;
 CLOSE cur_tot_claim_insrt_cnt;
 
 SELECT COUNT(1) INTO v_qtr_claim_count
   FROM APP.CLM_BULK_UPLD_CLM_DETAILS C
   JOIN APP.TPA_ENR_POLICY_MEMBER M ON (C.MEMBER_SEQ_ID=M.MEMBER_SEQ_ID)
   JOIN APP.TPA_ENR_POLICY_GROUP PG ON (M.POLICY_GROUP_SEQ_ID=PG.POLICY_GROUP_SEQ_ID)
   JOIN APP.TPA_ENR_MEM_ADDRESS A ON (PG.ENR_ADDRESS_SEQ_ID=A.ENR_ADDRESS_SEQ_ID)
   WHERE C.XML_SEQ_ID = v_xml_seq_id
     AND A.COUNTRY_ID = 134;
         
 SELECT COUNT(1) INTO v_ind_claim_count
   FROM APP.CLM_BULK_UPLD_CLM_DETAILS C
   JOIN APP.TPA_ENR_POLICY_MEMBER M ON (C.MEMBER_SEQ_ID=M.MEMBER_SEQ_ID)
   JOIN APP.TPA_ENR_POLICY_GROUP PG ON (M.POLICY_GROUP_SEQ_ID=PG.POLICY_GROUP_SEQ_ID)
   JOIN APP.TPA_ENR_MEM_ADDRESS A ON (PG.ENR_ADDRESS_SEQ_ID=A.ENR_ADDRESS_SEQ_ID)
   WHERE C.XML_SEQ_ID = v_xml_seq_id
     AND A.COUNTRY_ID = 73;  
             
 SELECT COUNT(1) INTO v_oth_claim_count
   FROM APP.CLM_BULK_UPLD_CLM_DETAILS C
   JOIN APP.TPA_ENR_POLICY_MEMBER M ON (C.MEMBER_SEQ_ID=M.MEMBER_SEQ_ID)
   JOIN APP.TPA_ENR_POLICY_GROUP PG ON (M.POLICY_GROUP_SEQ_ID=PG.POLICY_GROUP_SEQ_ID)
   JOIN APP.TPA_ENR_MEM_ADDRESS A ON (PG.ENR_ADDRESS_SEQ_ID=A.ENR_ADDRESS_SEQ_ID)
   WHERE C.XML_SEQ_ID = v_xml_seq_id
     AND A.COUNTRY_ID NOT IN (134,73);  
 
 IF (v_qtr_claim_count + v_ind_claim_count +  v_oth_claim_count) !=  v_tot_clm_insrt_cnt THEN
   raise unique_const_excp;
 END IF;  
     
 SELECT COUNT(1) INTO v_tot_claim_cnt
   FROM APP.CLM_BULK_UPLD_CLM_DETAILS C
   WHERE C.XML_SEQ_ID = v_xml_seq_id;   
   
 OPEN  cur_batch_sum;
 FETCH cur_batch_sum INTO v_batch_tot_amnt;
 CLOSE cur_batch_sum;   
 
 update_clm_seq_no(v_xml_seq_id,v_qtr_claim_count+ v_ind_claim_count +  v_oth_claim_count,v_ind_claim_count,v_oth_claim_count,v_file_no);
 
 
 
 save_clm_batch_details( v_clm_batch_seq_id,v_batch_no,hosp_rec.hosp_licenc_numb,
                        'ALK01',
                        CASE WHEN rec_xml_claim_info.source_type='PLCL' THEN SYSDATE 
                             WHEN rec_xml_claim_info.source_type='PBCL' THEN SYSDATE 
                        ELSE 
                             to_date(rtrim(rec_xml_claim_info.received_date,'.0'),'RRRR-MM-DD HH24:MI:SS')
						            END,
                        NULL,--v_xml_rec_count,
                        NULL,
                        '1',
                        'COMP',
                        NULL,
                        'CNH',
                        'DTC',
                        'QAR',
                        rec_xml_claim_info.source_type,
                        1,
                        null);
                        
  UPDATE APP.CLM_BATCH_UPLOAD_DETAILS B
    SET B.RECORD_COUNT     = v_tot_claim_cnt,
        B.BATCH_TOT_AMOUNT = v_batch_tot_amnt,
        B.XML_SEQ_ID       = v_xml_seq_id                                       
  WHERE B.CLM_BATCH_SEQ_ID = v_clm_batch_seq_id;
  
  
  UPDATE APP.CLM_BULK_UPLD_CLM_DETAILS C
    SET C.CLM_BATCH_SEQ_ID = v_clm_batch_seq_id,
        C.BATCH_NO         = v_batch_no
  WHERE C.XML_SEQ_ID = v_xml_seq_id;   
                                         
  
  
  
   
                
   --save_time_details(v_xml_seq_id,'UPLOAD_CLM',v_start_time);             
  
   EXCEPTION
    WHEN bulk_errors THEN
      l_error_count := SQL%BULK_EXCEPTIONS.count;
      v_bulk_error_msg := 'Number of failures: '||l_error_count;
      FOR i IN 1 .. l_error_count LOOP
        v_bulk_error_msg := v_bulk_error_msg ||CHR(10)||
                            ('Error: ' || i ||
                             ' Array Index: ' || SQL%BULK_EXCEPTIONS(i).error_index ||
                             ' Message: ' || SQLERRM(-SQL%BULK_EXCEPTIONS(i).ERROR_CODE));
      END LOOP;
        save_exception_log(v_xml_seq_id,NULL,NULL,NULL,v_bulk_error_msg,v_added_by,'save_clm_batche_xml',v_hosp_seq_id);
        v_clm_batch_seq_id := NULL;
        v_batch_no         := NULL;
        ROLLBACK;
      WHEN unique_const_excp THEN
        save_exception_log(v_xml_seq_id,NULL,v_sql_code,'Unique Constraient error, count missmatch',NULL,v_added_by,'save_clm_batche_xml',v_hosp_seq_id);
        v_clm_batch_seq_id := NULL;
        v_batch_no         := NULL;
        ROLLBACK;  
      WHEN OTHERS THEN
         V_SQL_CODE := SQLCODE;
         V_SQL_MSG  := SQLERRM; 
         
         save_exception_log(v_xml_seq_id,NULL,v_sql_code,v_sql_msg,NULL,v_added_by,'save_clm_batche_xml',v_hosp_seq_id);
         v_clm_batch_seq_id := NULL;
         v_batch_no         := NULL;
         ROLLBACK;
      
END save_clm_batch_xml;
 
 --------------------------------------------------------------------------------------------------------
 PROCEDURE claim_upload_job
 IS
   
 
   
 BEGIN
   for i in (select xd.xml_seq_id,xd.added_by from app.CLM_BULK_UPLD_XML_DTA xd 
     where  nvl(xd.processed_yn,'N')='N' and xd.tot_rec_cnt=xd.success_cnt AND NVL(xd.sub_type,'DTC')='DTC') loop
     
     
     claim_upload_validation(i.xml_seq_id,i.added_by);
     
    
   end loop;
   
  
     
 END claim_upload_job;
 --------------------------------------------------------------------------------------------------------
 -- Procedure to auto-approve out-patient consultation claims
 PROCEDURE claim_adjudication
  AS
    CURSOR clm_cur(v_clm_seq_id NUMBER) IS
      SELECT c.member_seq_id, 
             c.settlement_number, 
             c.date_of_hospitalization, 
             nvl(c.tot_allowed_amount, 0) as tot_allowed_amount,
             c.fnl_amt_currency_type
             
      FROM Clm_Batch_Upload_Details b
      JOIN Clm_Authorization_Details c ON c.clm_batch_seq_id = b.clm_batch_seq_id
      WHERE c.claim_seq_id = v_clm_seq_id;
    
    CURSOR consultation_cur IS
      SELECT c.claim_number, c.claim_seq_id, nvl(c.updated_by, c.added_by) AS added_by, h.hosp_seq_id
      FROM Clm_Batch_Upload_Details b
      JOIN Clm_Authorization_Details c ON c.clm_batch_seq_id = b.clm_batch_seq_id
      JOIN Pat_Activity_Details pa ON pa.claim_seq_id = c.claim_seq_id
      JOIN Clm_Hospital_Details h ON h.claim_seq_id = c.claim_seq_id
      JOIN Tpa_Activity_Details a ON a.activity_code = pa.code
      WHERE a.master_activity_code = '9'
      AND c.claim_seq_id NOT IN (SELECT c.claim_seq_id
                                 FROM CLM_BATCH_UPLOAD_DETAILS b
                                 JOIN CLM_AUTHORIZATION_DETAILS c ON b.clm_batch_seq_id = c.clm_batch_seq_id
                                 JOIN PAT_ACTIVITY_DETAILS p ON p.CLAIM_SEQ_ID = c.CLAIM_SEQ_ID
                                 WHERE p.CODE IN ('PHARMA', 'ACTIVITY')
                                 AND c.benifit_type = 'OPTS'
                                 AND c.clm_status_type_id = 'INP'
                                 --AND c.claim_type = 'CNH'
                                 AND TRUNC(c.added_date) BETWEEN TRUNC(SYSDATE) - 1 AND TRUNC(SYSDATE)
                                )
      AND c.benifit_type = 'OPTS'
      --AND c.claim_type = 'CNH'
      AND NVL(c.cal_act_yn, 'N') = 'N'
      AND c.clm_status_type_id = 'INP' AND NVL(b.submission_type_id,'DTC')='DTC'
      AND TRUNC(c.added_date) BETWEEN TRUNC(SYSDATE) - 1 AND TRUNC(SYSDATE)

      MINUS

      SELECT c.claim_number, c.claim_seq_id, c.added_by, h.hosp_seq_id
      FROM Clm_Batch_Upload_Details b
      JOIN Clm_Authorization_Details c ON c.clm_batch_seq_id = b.clm_batch_seq_id
      JOIN Pat_Activity_Details pa ON pa.claim_seq_id = c.claim_seq_id
      JOIN Clm_Hospital_Details h ON h.claim_seq_id = c.claim_seq_id
      LEFT JOIN Tpa_Activity_Details a ON a.activity_code = pa.code
      WHERE  a.master_activity_code != '9'
      AND c.benifit_type = 'OPTS'
      --AND c.claim_type = 'CNH'
      AND NVL(c.cal_act_yn, 'N') = 'N'
      AND c.clm_status_type_id = 'INP'
      AND TRUNC(c.added_date) BETWEEN TRUNC(SYSDATE) - 1 AND TRUNC(SYSDATE);

      clm_rec              clm_cur%ROWTYPE;
      v_status             VARCHAR2(10);
      v_allowed_amount     CLM_AUTHORIZATION_DETAILS.TOT_ALLOWED_AMOUNT%TYPE;
      v_result_set         SYS_REFCURSOR;
      v_rows_processed     NUMBER;
      v_sql_errm           VARCHAR2(500);
      v_sql_code           VARCHAR2(100);
  BEGIN
    FOR i IN consultation_cur LOOP
            
    BEGIN    
       claim_pkg.calculate_authorization(i.claim_seq_id, i.hosp_seq_id, v_allowed_amount, v_result_set, i.added_by);
        
      OPEN clm_cur(i.claim_seq_id);
      FETCH clm_cur INTO clm_rec;
      CLOSE clm_cur;
      
      IF clm_rec.tot_allowed_amount > 0 THEN
        v_status := 'APR';
      ELSE
        v_status := 'REJ';
      END IF;
      
      claim_pkg.save_settlement(i.claim_seq_id, 
                                clm_rec.member_seq_id, 
                                clm_rec.settlement_number, 
                                clm_rec.date_of_hospitalization,
                                clm_rec.tot_allowed_amount,
                                NULL, --v_source_type_id
                                v_status, --v_clm_status_type_id
                                NULL, --v_remarks
                                i.added_by,
                                clm_rec.fnl_amt_currency_type,
                                NULL, --v_clm_remark
                                NULL, --v_internal_remarks
                                v_rows_processed,
                                null
                               );
                               
      UPDATE CLM_AUTHORIZATION_DETAILS C
      SET C.PROCESSED_BY = 1
      WHERE C.CLAIM_SEQ_ID = i.claim_seq_id;
      
    EXCEPTION
        
     WHEN OTHERS THEN
       v_sql_code := SQLCODE;
       v_sql_errm := SQLERRM;
       INSERT INTO APP.AUTO_CAL_EXCEPTIONS_LOG 
         (CLAIM_SEQ_ID,EXECPTION_MESG,EXCEPTION_NUMBER,ADDED_DATE)  VALUES 
         (i.claim_seq_id ,v_sql_errm,v_sql_code,SYSDATE);   
    END ;
    END LOOP;
     commit;
  END claim_adjudication;
--========================================================================================
-- Claim Resubmission Through Bulk upload
-- Save_and_extract_resub_claims, upload_resubmission_claims, copy_parent_claim_dtls,Delete_Exceptional_Claims
--===========================================================================================
PROCEDURE save_resub_claims_xml (	v_xml_seq_id IN OUT NUMBER,
                                  v_xml_file   IN   XMLTYPE,
                                  v_added_by   IN   NUMBER,
                                  v_file_name  IN   VARCHAR2,
                                  v_sub_type   IN   VARCHAR2)
  AS
  BEGIN
          INSERT INTO APP.CLM_BULK_UPLD_XML_DTA (XML_SEQ_ID,XML_DATA,FILE_NAME,ADDED_BY,SUB_TYPE) 
          VALUES
          (app.clm_blk_xml_seq.nextval,v_xml_file,v_file_name ,v_added_by,v_sub_type)
          RETURNING XML_SEQ_ID INTO v_xml_seq_id;
          
          COMMIT;
END save_resub_claims_xml;
--============================================================================================
PROCEDURE extract_resub_xml_Data (v_xml_seq_id  IN NUMBER )
  AS
  
   CURSOR Get_resub_xml IS
     SELECT XML.XML_DATA 
       FROM CLM_BULK_UPLD_XML_DTA XML 
     WHERE XML.XML_SEQ_ID = v_xml_seq_id;
     
  v_clm_upload_doc    DBMS_XMLDOM.DOMDocument;
  v_parent_node       DBMS_XMLDOM.DOMNode;
  v_child_node        DBMS_XMLDOM.DOMNode;
  v_hosp_node         DBMS_XMLDOM.DOMNodeList;
  v_clm_nodes         DBMS_XMLDOM.DOMNodeList;
  v_element           DBMS_XMLDOM.DOMElement;
  v_element1          DBMS_XMLDOM.DOMELement;
  v_resub_rec         APP.CLM_BULK_UPLD_RESUB_DTLS%rowtype; 
  v_xml_file          XMLTYPE; 
  v_sql_code          VARCHAR2(100);
  v_sql_msg           VARCHAR2(2000);
  v_start_time        NUMBER;  	
BEGIN
   
   v_start_time:=DBMS_UTILITY.get_time;
   
   OPEN Get_resub_xml;
     FETCH Get_resub_xml INTO v_xml_file;
      CLOSE Get_resub_xml;
  
  v_clm_upload_doc := Dbms_xmldom.newDOMDocument(v_xml_file);
  v_hosp_node      := Dbms_xmldom.getElementsByTagName(v_clm_upload_doc,'claimsUpload');
    
 -- Batch Information     
    FOR v_parent_list in 0.. dbms_xmldom.getlength(v_hosp_node) - 1 LOOP
         v_parent_node                := Dbms_xmldom.item(v_hosp_node,v_parent_list);
         v_element                    := Dbms_xmldom.makeElement(v_parent_node);
         v_resub_rec.hosp_seq_id      := Dbms_Xmldom.getAttribute(v_element,'hospSeqId');
         v_resub_rec.res_rec_date     := Dbms_xmldom.getAttribute(v_element,'receivedDate');
         v_resub_rec.res_rec_date     := rtrim(v_resub_rec.res_rec_date,'.0');
         v_resub_rec.source_type      := Dbms_Xmldom.getAttribute(v_element,'sourceType');
    END LOOP; 
 
    v_clm_nodes :=Dbms_xmldom.getElementsByTagName(v_element,'claimsReSubmissionData');
      
 --Parent claims information 
   FOR v_claim_index in 0..dbms_xmldom.getlength(v_clm_nodes) - 1 LOOP
        
     v_child_node := Dbms_xmldom.item(v_clm_nodes,v_claim_index);
     v_element1   := Dbms_xmldom.makeElement(v_child_node);
     
     v_resub_rec.s_no             :=Dbms_Xmldom.getAttribute(v_element1,'slno');
     v_resub_rec.member_id        :=Dbms_xmldom.getAttribute(v_element1,'memId');
     v_resub_rec.mem_name         :=Dbms_xmldom.getAttribute(v_element1,'memName');
     v_resub_rec.parent_claim_no  :=Dbms_xmldom.getAttribute(v_element1,'parentClaimNumber');
     v_resub_rec.parent_clm_set_no:=Dbms_xmldom.getAttribute(v_element1,'parentClaimSettelmentNumber');
     v_resub_rec.resub_req_amt    :=Dbms_xmldom.getAttribute(v_element1,'resubmissionRequestedAmount');
     v_resub_rec.act_type         :=Dbms_xmldom.getAttribute(v_element1,'actType');
     v_resub_rec.cpt_code         :=Dbms_xmldom.getAttribute(v_element1,'cptCode');
     v_resub_rec.req_quant        :=Dbms_xmldom.getAttribute(v_element1,'qty');
     v_resub_rec.service_date     :=Dbms_xmldom.getAttribute(v_element1,'servDt');
     v_resub_rec.internal_code    :=Dbms_xmldom.getAttribute(v_element1,'internalCode');
     v_resub_rec.serv_desc        :=Dbms_xmldom.getAttribute(v_element1,'servDesc');
     v_resub_rec.tooth_no         :=Dbms_xmldom.getAttribute(v_element1,'toothNo');
     v_resub_rec.alkoot_remarks   :=Dbms_xmldom.getAttribute(v_element1,'alKootRemarks');
     v_resub_rec.resub_just_rem   :=Dbms_xmldom.getAttribute(v_element1,'resubmissionJustification');
     
--Dumping into Intermediatery Table

        INSERT INTO APP.CLM_BULK_UPLD_RESUB_DTLS
        (XML_SEQ_ID ,
         S_NO,
         RESUB_INTER_SEQ,
         MEM_NAME ,
         MEMBER_ID ,
         PARENT_CLAIM_NO ,
         PARENT_CLM_SET_NO ,
         RESUB_REQ_AMT,
         REQ_QUANT ,
         SERVICE_DATE,
         ACT_TYPE ,
         INTERNAL_CODE ,
         ALKOOT_REMARKS ,
         RESUB_JUST_REM ,
         RES_REC_DATE,
         HOSP_SEQ_ID,
         ADDED_DATE,
         ADDED_BY,
         SERV_DESC,
         TOOTH_NO
         )
        VALUES
        (v_xml_seq_id,
         v_resub_rec.s_no,
         APP.CLAIM_RESUB_SEQ_VAL.NEXTVAL,
         v_resub_rec.mem_name,
         v_resub_rec.Member_Id,
         v_resub_rec.parent_claim_no,
         v_resub_rec.parent_clm_set_no,
         v_resub_rec.resub_req_amt,
         v_resub_rec.req_quant,
         v_resub_rec.service_date,
         UPPER(v_resub_rec.act_type),
         v_resub_rec.internal_code,
         v_resub_rec.alkoot_remarks,
         v_resub_rec.resub_just_rem,
         v_resub_rec.res_rec_date,
         v_resub_rec.hosp_seq_id,
         SYSDATE,
         1,
         v_resub_rec.serv_desc,
         v_resub_rec.tooth_no
         );
     END LOOP; 
  
    UPDATE APP.CLM_BULK_UPLD_XML_DTA DTA
      SET DTA.SOURCE_TYPE = v_resub_rec.source_type,  
          DTA.HOSP_SEQ_ID = v_resub_rec.hosp_seq_id,
          DTA.BATC_REC_DT = to_date(v_resub_rec.res_rec_date,'rrrr/mm/dd hh24:mi:ss')
    WHERE DTA.XML_SEQ_ID = v_xml_seq_id;    
    COMMIT; 
    save_time_details(v_xml_seq_id,'EXTRCT_RESUB_CLM',v_start_time);
      
  
  EXCEPTION
    WHEN OTHERS THEN
     v_sql_code := sqlcode;      v_sql_msg  := sqlerrm; 
     save_exception_log(v_xml_seq_id,NULL,v_sql_code,v_sql_msg,NULL,1,'extract_resub_claims',NULL);
     ROLLBACK;
  
END  extract_resub_xml_Data;
--=============================================================================================
PROCEDURE upload_resubmission_claims(v_xml_seq_id        IN OUT app.clm_bulk_upld_resub_dtls.xml_seq_id%TYPE,
          	                         v_clm_batch_seq_id  OUT VARCHAR2,
                                     v_batch_no          OUT VARCHAR2,
                                     v_tot_rec_cnt       OUT VARCHAR2,
                                     v_fail_cnt          OUT VARCHAR2,                       
                                     v_succ_cnt          OUT VARCHAR2,
                                     v_no_of_claims      OUT VARCHAR2,
                                     v_batch_amt         OUT VARCHAR2,
                                     v_added_by          IN  NUMBER
                                     )
  AS
  
  CURSOR Get_Sys_remarks IS
    SELECT * FROM 
     (SELECT COUNT(1) AS SYS_REM
        FROM APP.CLM_BULK_UPLD_RESUB_DTLS RD 
      WHERE RD.XML_SEQ_ID = v_xml_seq_id AND RD.SYS_REMARKS IS NOT NULL ) A,
     (SELECT COUNT(1) AS EXC_CNT 
        FROM APP.CLM_BULK_EXCEPTION_LOGS EL
      WHERE EL.XML_SEQ_ID = v_xml_seq_id ) B ;
   
  CURSOR Get_Parent_Details IS
    SELECT RD.PARENT_CLAIM_SEQ_ID,SUM(RD.RESUB_REQ_AMT) AS RESUB_REQ_AMT 
      FROM APP.CLM_BULK_UPLD_RESUB_DTLS RD
    WHERE RD.XML_SEQ_ID = v_xml_seq_id
    GROUP BY RD.PARENT_CLAIM_SEQ_ID; 
  
  CURSOR Get_Hosp_Details IS
    SELECT XMD.SOURCE_TYPE,HI.HOSP_LICENC_NUMB,XMD.BATC_REC_DT
      FROM CLM_BULK_UPLD_XML_DTA XMD
       JOIN TPA_HOSP_INFO HI ON (XMD.HOSP_SEQ_ID=HI.HOSP_SEQ_ID)
      WHERE XMD.XML_SEQ_ID = v_xml_seq_id;  
      
  Get_Sys_Count   Get_Sys_remarks%ROWTYPE;
  Get_Hosp_Det    Get_Hosp_Details%ROWTYPE;
  v_claim_Seq_id  NUMBER(30);  
  v_sql_code      VARCHAR2(30);
  v_sql_msg       VARCHAR2(1500);
  V_dummy         VARCHAR2(1000);
  v_batch_seq_id  NUMBER(30);
    
  BEGIN
   
   --Here we are extracting the xml data 
     extract_resub_xml_Data(v_xml_seq_id);
   --Here we are validating the input data
    validate_resubmission_data(v_xml_seq_id);
   --Here we are validating parent claim information 
    FOR mvb in (SELECT RD.XML_SEQ_ID,RD.PARENT_CLAIM_NO,RD.MEMBER_ID,RD.HOSP_SEQ_ID 
                       FROM APP.CLM_BULK_UPLD_RESUB_DTLS RD
                WHERE RD.XML_SEQ_ID = v_xml_seq_id
                GROUP BY RD.XML_SEQ_ID,RD.PARENT_CLAIM_NO,RD.MEMBER_ID,RD.HOSP_SEQ_ID 
                ) LOOP
    SELECT validate_parent_claim (mvb.xml_seq_id,mvb.member_id,mvb.parent_claim_no,mvb.hosp_seq_id) INTO V_dummy FROM DUAL;                     
    END LOOP;
    
    OPEN Get_Sys_remarks;
      FETCH Get_Sys_remarks INTO Get_Sys_Count;
        CLOSE Get_Sys_remarks;
     
    OPEN Get_Hosp_Details;
      FETCH Get_Hosp_Details INTO Get_Hosp_Det;
        CLOSE Get_Hosp_Details;   
       
    IF Get_Sys_Count.Sys_Rem = 0 AND Get_Sys_Count.Exc_Cnt = 0 THEN
      
    --Creating Resubmission batch      
     save_clm_batch_details(v_batch_seq_id,
                           v_batch_no,
                           Get_Hosp_Det.Hosp_Licenc_Numb,
                           'ALK01',
                           to_date(Get_Hosp_Det.Batc_Rec_Dt,'dd/mm/rrrr hh:mi'),
                           null,
                           null,
                           1,
                           null,
                           null,
                           'CNH',
                           'DTR',
                           'QAR',
                           Get_Hosp_Det.Source_Type,
                           1,
                           v_xml_seq_id
                           );
                           
    UPDATE APP.CLM_BULK_UPLD_RESUB_DTLS RD
      SET RD.BATCH_SEQ_ID = v_batch_seq_id
    WHERE RD.XML_SEQ_ID = v_xml_seq_id;                       
    
      FOR Get_Parent_Det IN Get_Parent_Details LOOP
         BEGIN
           v_claim_Seq_id :=null;
           --Creating Resubmission claim
           IF Get_Parent_Det.Parent_Claim_Seq_Id IS NOT NULL THEN
              copy_parent_claim_dtls(v_xml_seq_id,v_claim_Seq_id,Get_Parent_Det.Parent_Claim_Seq_Id,v_batch_seq_id,Get_Parent_Det.Resub_Req_Amt,1);
           END IF;
         EXCEPTION
           WHEN OTHERS THEN
              DBMS_OUTPUT.put_line (DBMS_UTILITY.format_error_backtrace); 
              v_sql_code := sqlcode;      v_sql_msg  := sqlerrm; 
             save_exception_log(v_xml_seq_id,NULL,v_sql_code,v_sql_msg,NULL,1,'while copying parent claim',NULL);
            ROLLBACK;
         EXIT;
         
         END;  
      END LOOP;
     END IF;
     
    ---Checking exceptions count 
    
    SELECT SUM(A) INTO v_fail_cnt 
    FROM
    (SELECT COUNT(SYS_REMARKS) AS A 
       FROM APP.CLM_BULK_UPLD_RESUB_DTLS DT
     WHERE DT.XML_SEQ_ID = v_xml_seq_id
     union   
     SELECT COUNT(1) AS A
         FROM APP.CLM_BULK_EXCEPTION_LOGS EL
    WHERE EL.XML_SEQ_ID = v_xml_seq_id );  
    
    SELECT COUNT(1) INTO V_NO_OF_CLAIMS FROM 
           (SELECT COUNT(1)
               FROM APP.CLM_BULK_UPLD_RESUB_DTLS RD 
                WHERE RD.XML_SEQ_ID = v_xml_seq_id 
           GROUP BY RD.PARENT_CLAIM_NO);
    
     SELECT COUNT(1) AS TOT_REC ,
            SUM(RD.RESUB_REQ_AMT) AS BATCH_AMT ,
            V_NO_OF_CLAIMS AS NO_OF_CLAIMS,
            CASE WHEN v_fail_cnt=0 THEN V_BATCH_NO ELSE NULL END AS BATCH_NO
     INTO
       v_tot_rec_cnt ,  v_batch_amt ,v_no_of_claims , v_batch_no   
            
      FROM APP.CLM_BULK_UPLD_RESUB_DTLS RD 
     WHERE RD.XML_SEQ_ID = v_xml_seq_id;
       
     v_succ_cnt := nvl(v_tot_rec_cnt,0) - nvl(v_fail_cnt,0);
    
   IF v_fail_cnt =0 THEN  -- Modyfying the batch status
        UPDATE CLM_BATCH_UPLOAD_DETAILS BAT
        SET BAT.BATCH_TOT_AMOUNT =  v_batch_amt,
            BAT.BATCH_STATUS_TYPE = 'COMP',
            BAT.RECORD_COUNT = v_no_of_claims
        WHERE BAT.CLM_BATCH_SEQ_ID = v_batch_seq_id ;    
    ELSIF v_fail_cnt >0 THEN -- Deleting entire batch along with claim details
       Delete_Exceptional_Claims(v_xml_seq_id,v_batch_seq_id);   
    END IF; 
    
   COMMIT;
   
   EXCEPTION
    WHEN OTHERS THEN
      DBMS_OUTPUT.put_line (DBMS_UTILITY.format_error_backtrace); 
     v_sql_code := sqlcode;      v_sql_msg  := sqlerrm; 
     save_exception_log(v_xml_seq_id,NULL,v_sql_code,v_sql_msg,NULL,1,'upload_resubmission_claims',NULL);     
     ROLLBACK;
  END upload_resubmission_claims;
--============================================================================================
--This procedure is used to validate the resubmission xml data
--============================================================================================
PROCEDURE validate_resubmission_data(v_xml_seq_id IN app.clm_bulk_upld_resub_dtls.xml_seq_id%TYPE)
  AS
  
  v_resub_remarks     VARCHAR2(100);
  v_sql_code          VARCHAR2(30);
  v_sql_msg           VARCHAR2(500);
  
  CURSOR validate_resub_data IS
      SELECT RD.RESUB_INTER_SEQ,
             CASE WHEN RD.MEMBER_ID IS NULL THEN 'Alkoot id cannot be Blank' ELSE NULL END ||';'||
             CASE WHEN RD.PARENT_CLAIM_NO IS NULL THEN 'For Re-Submission , Parent Claim is required' ELSE NULL END ||';'||
             CASE WHEN RD.SERVICE_DATE IS NULL THEN 'Service Date cannot be blank' ELSE NULL END||' ; '||
             CASE WHEN RD.ACT_TYPE IS NULL THEN 'Activity type cannot be blank' ELSE NULL END||' ; '||
             CASE WHEN RD.INTERNAL_CODE IS NULL THEN 'Internal Service code cannot be blank' ELSE NULL END||' ; '||
             CASE WHEN RD.SERV_DESC IS NULL THEN 'Internal Service code cannot be blank' ELSE NULL END||' ; '||
             CASE WHEN RD.RESUB_REQ_AMT IS NULL THEN 'Requested Amount cannot be blank' ELSE NULL END ||' ; '||
             CASE WHEN RD.REQ_QUANT IS NULL THEN 'Requested Quantity cannot be blank' ELSE NULL END ||' ; '||
             CASE WHEN RD.RESUB_JUST_REM IS NULL THEN 'Re-Submission Justification cannot be blank' ELSE NULL END||' ; '||
             CASE WHEN RD.ALKOOT_REMARKS IS NULL THEN 'Alkoot Remarks cannot be blank' ELSE NULL END AS SYS_REMARKS
       FROM APP.CLM_BULK_UPLD_RESUB_DTLS RD 
        WHERE RD.XML_SEQ_ID = v_xml_seq_id ;
  
  BEGIN
    FOR rec IN validate_resub_data LOOP
       UPDATE APP.CLM_BULK_UPLD_RESUB_DTLS S
        SET S.SYS_REMARKS = S.SYS_REMARKS|| RTRIM(LTRIM(REPLACE(rec.sys_Remarks,' ; ',';'),';'),';')
       WHERE S.RESUB_INTER_SEQ = rec.RESUB_INTER_SEQ and s.xml_seq_id =v_xml_seq_id;
    END LOOP;
    COMMIT; 
   EXCEPTION
    WHEN OTHERS THEN
      DBMS_OUTPUT.put_line (DBMS_UTILITY.format_error_backtrace); 
     v_sql_code := sqlcode;      v_sql_msg  := sqlerrm; 
     save_exception_log(v_xml_seq_id,NULL,v_sql_code,v_sql_msg,NULL,1,'validate_resubmission_data',NULL); 
      
  END validate_resubmission_data;
--===========================================================================================
--Here we are validating the parent claim details
--===========================================================================================
FUNCTION validate_parent_claim (v_xml_seq_id   IN NUMBER,
                                v_member_id    IN VARCHAR2,
                                v_claim_number IN VARCHAR2,
                                v_hosp_seq_id  IN NUMBER
                                )
 RETURN VARCHAR2
 AS
 PRAGMA AUTONOMOUS_TRANSACTION;
 CURSOR GET_MEMBER_SEQ_ID IS
   SELECT  CAD.SETTLEMENT_NUMBER,CAD.MEM_NAME,CAD.TPA_ENROLLMENT_ID ,CAD.MEMBER_SEQ_ID,CAD.DATE_OF_HOSPITALIZATION,CAD.DATE_OF_DISCHARGE,CAD.CLAIM_SEQ_ID
    FROM CLM_AUTHORIZATION_DETAILS CAD 
    WHERE CAD.CLAIM_NUMBER = v_claim_number;
    
 CURSOR GET_CLAIM_NUMBERS (v_mem_seq NUMBER,v_hosp_seq_id NUMBER) IS
 SELECT A.claim_seq_id,A.claim_number,A.requested_amt,A.appr_amt,A.Converted_Amount,A.Final_App_Amount
       FROM 
      (SELECT cad.claim_seq_id,cad.claim_number,sum(case when nvl(pad.provider_net_amount,0)!=0 And nvl(pad.disc_gross_amount,0)!=0 then
                   least (pad.provider_net_amount,pad.disc_gross_amount)
                   when nvl(pad.provider_net_amount,0)=0 And nvl(pad.disc_gross_amount,0)!=0 then 
                   pad.disc_gross_amount  end) as requested_amt,sum(pad.allowed_amount) as appr_amt,
                   cad.Converted_Amount,cad.Final_App_Amount
      from clm_authorization_details cad
           left outer join clm_hospital_details cah on (cad.claim_seq_id=cah.claim_seq_id)
           JOIN pat_activity_details pad on (pad.claim_seq_id=cad.claim_seq_id)
           where cad.claim_seq_id in(
              SELECT A.claim_seq_id FROM
                    (SELECT cad.claim_seq_id 
                              from clm_authorization_details cad
                              LEFT OUTER join tpa_claims_payment pa on (cad.claim_seq_id = pa.claim_seq_id)
                              where cad.claim_type='CNH' and 
                              ((cad.clm_status_type_id = 'APR'  AND pa.claim_payment_status IN( 'PAID','SENT_TO_BANK')) OR (cad.clm_status_type_id = 'REJ'))
                               AND cad.member_seq_id = v_mem_seq ) A
               MINUS
                     (SELECT cad.parent_claim_seq_id
                         from clm_authorization_details cad
                         where cad.parent_claim_seq_id in
                            ((SELECT c.claim_seq_id
                               from clm_authorization_details c
                               LEFT OUTER join tpa_claims_payment p on (c.claim_seq_id = p.claim_seq_id)
                               where c.member_seq_id =  v_mem_seq AND c.claim_type='CNH' AND c.completed_yn = 'Y' and
                               ((c.clm_status_type_id = 'APR' AND  p.claim_payment_status IN( 'PAID','SENT_TO_BANK')) or (cad.clm_status_type_id='REJ'))
                               ))))
                               AND cah.hosp_seq_id =v_hosp_seq_id
                               group by cad.claim_seq_id,cad.claim_number,cad.Converted_Amount,cad.Final_App_Amount) A
                               where (A.Converted_Amount-A.Final_App_Amount)>0 OR (A.requested_amt-A.appr_amt)>0 ;
 
CURSOR GET_UPLOAD_INFO IS
  SELECT RS.MEM_NAME,RS.PARENT_CLM_SET_NO FROM APP.CLM_BULK_UPLD_RESUB_DTLS RS
  WHERE RS.XML_SEQ_ID =v_xml_seq_id;


 GET_MEMBER_SEQ  GET_MEMBER_SEQ_ID%ROWTYPE;
 GET_UPLOAD_INFO_REC GET_UPLOAD_INFO%ROWTYPE;
 V_MEM_SEQ_ID    NUMBER(30);
 v_elig_yn       VARCHAR2(2);
 v_sql_code      VARCHAR2(30);
 v_sql_msg       VARCHAR2(500);
 v_elig_remarks   VARCHAR2(1000):=NULL;
 
 BEGIN
  
  OPEN GET_MEMBER_SEQ_ID;
    FETCH GET_MEMBER_SEQ_ID INTO GET_MEMBER_SEQ;
      CLOSE GET_MEMBER_SEQ_ID;
      
  OPEN GET_UPLOAD_INFO;
    FETCH GET_UPLOAD_INFO INTO GET_UPLOAD_INFO_REC;
      CLOSE GET_UPLOAD_INFO;    
      
     IF GET_MEMBER_SEQ.TPA_ENROLLMENT_ID = v_member_id THEN
       V_MEM_SEQ_ID := GET_MEMBER_SEQ.MEMBER_SEQ_ID;
     ELSE
       v_elig_yn := 'NO';
     END IF; 
 
     IF v_elig_yn IS NULL THEN
        FOR I IN   GET_CLAIM_NUMBERS (V_MEM_SEQ_ID ,v_hosp_seq_id) LOOP
          IF I.CLAIM_NUMBER = v_claim_number THEN
            v_elig_yn := 'Y';
              EXIT;
          ELSE
             v_elig_yn:= 'N';
          END IF;   
        END LOOP;
        
     END IF;
     
     IF v_elig_yn ='NO' THEN
        v_elig_remarks := ' Given alkoot id was not associated with Claim number ' ;
     ELSIF v_elig_yn='N' THEN
        v_elig_remarks := ' Given Claim number is not eligible for resubmission ' ;
     END IF;
     
     IF GET_MEMBER_SEQ.SETTLEMENT_NUMBER != GET_UPLOAD_INFO_REC.PARENT_CLM_SET_NO THEN
       UPDATE APP.CLM_BULK_UPLD_RESUB_DTLS RD
         SET RD.SYS_REMARKS = RD.SYS_REMARKS || ' ; Given settlement number is not Valid'
        WHERE RD.Parent_Claim_No = v_claim_number and RD.XML_SEQ_ID =v_xml_seq_id AND RD.MEMBER_ID = v_member_id AND RD.PARENT_CLM_SET_NO = GET_UPLOAD_INFO_REC.PARENT_CLM_SET_NO;    
     END IF;
     
     IF GET_MEMBER_SEQ.Mem_Name != GET_UPLOAD_INFO_REC.MEM_NAME THEN
       UPDATE APP.CLM_BULK_UPLD_RESUB_DTLS RD
         SET RD.SYS_REMARKS = RD.SYS_REMARKS || ' ; Given Member Name is not Valid'
        WHERE RD.Parent_Claim_No = v_claim_number and RD.XML_SEQ_ID =v_xml_seq_id AND RD.MEMBER_ID = v_member_id AND RD.Mem_Name = GET_UPLOAD_INFO_REC.MEM_NAME;    
     END IF;
     
     
    IF v_elig_remarks IS NULL AND v_elig_yn ='Y' THEN
        UPDATE APP.CLM_BULK_UPLD_RESUB_DTLS RD
         SET RD.PARENT_CLAIM_SEQ_ID = GET_MEMBER_SEQ.CLAIM_SEQ_ID
        WHERE RD.Parent_Claim_No = v_claim_number and RD.XML_SEQ_ID =v_xml_seq_id AND RD.MEMBER_ID = v_member_id;
    ELSIF v_elig_remarks IS NOT NULL THEN
       UPDATE APP.CLM_BULK_UPLD_RESUB_DTLS RD
         SET RD.SYS_REMARKS = RD.SYS_REMARKS || v_elig_remarks
        WHERE RD.Parent_Claim_No = v_claim_number and RD.XML_SEQ_ID =v_xml_seq_id AND RD.MEMBER_ID = v_member_id;    
    ELSIF  v_elig_remarks IS NULL AND v_elig_yn IS NULL THEN
      UPDATE APP.CLM_BULK_UPLD_RESUB_DTLS RD
         SET RD.SYS_REMARKS = RD.SYS_REMARKS || ' ; Given Claim number is not eligible for resubmission OR Given Claim number was already resubmitted OR Please select Proper Provider '
        WHERE RD.Parent_Claim_No = v_claim_number and RD.XML_SEQ_ID =v_xml_seq_id AND RD.MEMBER_ID = v_member_id;    
    END IF;
        
 COMMIT;
 
 RETURN v_elig_remarks;
  
 END validate_parent_claim;
--===========================================================================================
--This Procedure is used to copying the parent claim details to Re-Submission Claim
--==========================================================================================
PROCEDURE copy_parent_claim_dtls (
    v_xml_seq_id                      IN NUMBER,
    v_claim_seq_id                    IN OUT clm_authorization_details.claim_seq_id%TYPE,
    v_parent_claim_seq_id             IN clm_authorization_details.parent_claim_seq_id%TYPE,
    v_claim_batch_seq_id              IN clm_batch_upload_details.clm_batch_seq_id%TYPE ,
    v_requested_amount                IN clm_authorization_details.requested_amount%TYPE,
    v_added_by                        IN NUMBER
  )
  IS
   
    CURSOR claim_cur IS 
     SELECT
      A.Event_No,A.Delvry_Mod_Type, A.clm_batch_seq_id ,a.parent_claim_seq_id, A.claim_number ,A.claim_file_number , A.Pat_Auth_Seq_Id ,
      A.auth_number ,A.Source_Type_Id ,a.ins_seq_id,a.remarks as pat_remarks,  
      A.Date_Of_Hospitalization,A.Date_Of_Discharge,
      A.Settlement_Number  , a.pat_approved_amount, n.gender_general_type_id, 
      a.member_seq_id ,    a.tpa_enrollment_id ,a.policy_seq_id,f.enrol_type_id,
      a.mem_age ,a.mem_name ,n.emirate_id,d.clinician_name,  
      b.clm_type_gen_type_id ,D.hosp_seq_id ,D.Provider_Id ,       D.hosp_name ,        D.address_1
      ,D.address_2 ,       D.address_3 ,d.city_type_id,d.state_type_id,d.country_type_id,D.state_name ,       D.city_name ,       D.pin_code ,       D.off_phone_no_1,
      D.off_phone_no_2 ,D.office_fax_no,    D.remarks , 
      a.clm_status_type_id ,a.invoice_number,a.clinician_id,a.requested_amount,
      a.network_yn,a.benifit_type,a.GRAVIDA,
      a.PARA, a.LIVE,a.ABORTION,a.PRESENTING_COMPLAINTS,a.MEDICAL_OPINION_REMARKS,
      n.mem_general_type_id,a.encounter_type_id,a.encounter_start_type,a.encounter_end_type,
      a.encounter_facility_id,a.payer_id,a.ava_sum_insured,a.currency_type,
      a.system_of_medicine_type_id,a.accident_related_type_id,a.priority_general_type_id,
      a.REQ_AMT_CURRENCY_TYPE,a.CONVERTED_AMOUNT,a.CONVERTED_AMOUNT_CURRENCY_TYPE,a.CONVERSION_RATE,NVL(A.PROCESS_TYPE,'RGL') AS PROCESS_TYPE,a.oth_tpa_ref_no,
      a.common_file_number,b.submission_type_id,a.treatment_type,a.dur_ailment,a.duration_flag,
      a.lmp_date,a.conception_type
      ,a.embassy_seq_id,
      NVL(A.MAT_COMPLCTON_YN,'N') AS MAT_COMPLCTON_YN
      FROM clm_authorization_details A 
      JOIN clm_batch_upload_details B ON (A.CLM_BATCH_SEQ_ID = B.CLM_BATCH_SEQ_ID )
      JOIN clm_hospital_details D ON ( a.claim_seq_id = d.claim_seq_id )
      JOIN tpa_enr_policy f ON ( a.policy_seq_id = f.policy_seq_id )
      LEFT OUTER JOIN pat_authorization_details k ON (a.pat_auth_seq_id = k.pat_auth_seq_id AND k.pat_enhanced_yn = 'N')
      JOIN tpa_enr_policy_member n ON (a.member_seq_id = n.member_seq_id)
      LEFT OUTER JOIN tpa_enr_policy_group o ON (n.policy_group_seq_id = o.policy_group_seq_id)
      WHERE a.claim_seq_id = v_parent_claim_seq_id AND a.completed_yn = 'Y';
   
     claim_rec                     claim_cur%ROWTYPE;
      
   CURSOR Current_Batch_Details IS
   SELECT sum(ba.resub_req_amt),XMLD.RECEIVED_DATE as received_date , to_char(wm_concat(ba.resub_just_rem))
       FROM APP.CLM_BULK_UPLD_RESUB_DTLS  BA
       JOIN APP.CLM_BATCH_UPLOAD_DETAILS XMLD ON (BA.BATCH_SEQ_ID = XMLD.CLM_BATCH_SEQ_ID)
       where ba.batch_seq_id=v_claim_batch_seq_id AND ba.xml_seq_id = v_xml_seq_id AND ba.parent_claim_seq_id = v_parent_claim_seq_id
       GROUP BY ba.parent_claim_no,XMLD.RECEIVED_DATE ;
       
    CURSOR Dental_iotn_Config IS
    select * 
       from ORTHODONTIC_DETAILS_TAB o 
    where o.Source_Seq_Id=v_parent_claim_seq_id and o.source_from='CLM'; 
          
   CURSOR Verify_Activity_Details (v_parent_seq_id NUMBER)IS
    SELECT RD.INTERNAL_CODE,RD.ACT_TYPE,RD.SERVICE_DATE,RD.HOSP_SEQ_ID,RD.RESUB_REQ_AMT,RD.RESUB_INTER_SEQ,
           RD.REQ_QUANT, RD.SERV_DESC
     FROM APP.CLM_BULK_UPLD_RESUB_DTLS RD
    WHERE RD.XML_SEQ_ID = v_xml_seq_id AND RD.PARENT_CLAIM_SEQ_ID = v_parent_seq_id;
    
    CURSOR Add_Activity_Details (v_parent_seq_id NUMBER)IS
    SELECT RD.INTERNAL_CODE,RD.ACT_TYPE,RD.SERVICE_DATE,RD.HOSP_SEQ_ID,SUM(RD.RESUB_REQ_AMT) AS RESUB_REQ_AMT,
           sum(RD.REQ_QUANT) as REQ_QUANT, RD.SERV_DESC ,wm_concat(RD.ALKOOT_REMARKS) as ALKOOT_REMARKS,
           wm_concat(Resub_Just_Rem) AS Resub_Remarks
     FROM APP.CLM_BULK_UPLD_RESUB_DTLS RD
    WHERE RD.XML_SEQ_ID = v_xml_seq_id AND RD.PARENT_CLAIM_SEQ_ID = v_parent_seq_id
    GROUP BY RD.INTERNAL_CODE,RD.ACT_TYPE,rd.service_date,RD.HOSP_SEQ_ID, RD.SERV_DESC;
    
    CURSOR Get_Activity_Details(v_hosp_seq NUMBER,v_int_code VARCHAR2,v_service_date VARCHAR) IS
      SELECT TAR.GROSS_AMOUNT,
             TAR.DISC_AMOUNT,
             TAR.INTERNAL_CODE,
             MAS.ACT_MAS_DTL_SEQ_ID,
             MAS.ACTIVITY_DESCRIPTION,
             MAS.ACTIVITY_CODE,
             MAS.ACTIVITY_TYPE_SEQ_ID 
         FROM TPA_HOSP_TARIFF_DETAILS TAR
         JOIN TPA_ACTIVITY_MASTER_DETAILS MAS ON (TAR.ACTIVITY_SEQ_ID=MAS.ACT_MAS_DTL_SEQ_ID) 
         WHERE TAR.HOSP_SEQ_ID =  v_hosp_seq AND TAR.INTERNAL_CODE = v_int_code AND
         TO_DATE(V_SERVICE_DATE,'DD/MM/YYYY') BETWEEN TAR.START_DATE AND NVL(TAR.END_DATE,SYSDATE+1);        
               
       
    Verify_Activity_Det           Verify_Activity_Details%ROWTYPE;
    Get_Activity_Det              Get_Activity_Details%ROWTYPE;
    v_prev_parent_seq_id          clm_general_details.parent_claim_seq_id%TYPE;
    v_copy_flag                   CHAR(1) := 'N';
    v_rows_processed              NUMBER(2);
    v_clm_hosp_assoc_seq_id       clm_hospital_association.clm_hosp_assoc_seq_id%TYPE;
    v_add_hosp_dtl_seq_id         clm_hospital_additional_dtl.add_hosp_dtl_seq_id%TYPE;
    v_pat_act_dtl_seq_id          pat_activity_details.activity_dtl_seq_id%TYPE;
    v_prev_appr_count             PLS_INTEGER := 0;
    v_flag                        VARCHAR2(3);
    v_claim_number                varchar2(60);
    v_act_count                   number;
    v_req_amt                     NUMBER(30,2);
    v_current_claim_from          VARCHAR2(30);
    v_parent_claim_form           VARCHAR2(30);
    v_rec_date                    date;
    Dental_iotn                   Dental_iotn_Config%rowtype;
    v_resub_remarks               VARCHAR2(4000);
    v_clm_Seq_id                  NUMBER(30);
    v_sql_code                    VARCHAR2(30);
    v_sql_errm                    VARCHAR2(2000);
    v_elg_yn                      VARCHAR2(2):='Y';
    v_assign_Seq                  NUMBER(30);
    
  BEGIN
   
     OPEN Current_Batch_Details;
      FETCH Current_Batch_Details INTO v_req_amt,v_rec_date,v_resub_remarks;
        CLOSE Current_Batch_Details;
 

    IF NVL(v_claim_seq_id,0) = 0 THEN
      v_copy_flag := 'Y';
    ELSE
      SELECT a.parent_claim_seq_id ,c.clm_hosp_assoc_seq_id 
         INTO v_prev_parent_seq_id ,  v_clm_hosp_assoc_seq_id 
         FROM clm_authorization_details a 
         JOIN clm_batch_upload_details b ON ( a.clm_batch_seq_id = b.clm_batch_seq_id )
         JOIN clm_hospital_details c ON ( a.claim_seq_id = c.claim_seq_id )
         WHERE a.claim_seq_id = v_claim_seq_id ;
    END IF;
    
    IF v_claim_seq_id IS NOT NULL THEN
      
      SELECT COUNT(1) into v_act_count 
        from app.pat_activity_details ad 
      where ad.claim_seq_id = v_claim_seq_id;
      
      if v_act_count=0 then
        v_copy_flag:='Y';
      end if;
      
    END IF;
    
    OPEN claim_cur;
      FETCH claim_cur INTO claim_rec;
      CLOSE claim_cur;
   
   IF v_copy_flag = 'Y' THEN
      -- LOCKING Parent Claim
      TTK_UTIL_PKG.reset_id_flag(v_parent_claim_seq_id||'-CLM','Y');

      UPDATE clm_batch_upload_details A SET
        a.clm_type_gen_type_id = claim_rec.clm_type_gen_type_id
        WHERE a.clm_batch_seq_id = v_claim_batch_seq_id ;

  
 claim_pkg.save_clm_details (v_claim_seq_id,
                           v_claim_batch_seq_id,
                           claim_rec.pat_auth_seq_id,
                           v_parent_claim_seq_id,
                           v_claim_number,
                           null,
                           null, 
                           v_rec_date, --CLM_RECEIVED_DATE 
                           claim_rec.source_type_id,
                           claim_rec.date_of_hospitalization,
                           claim_rec.date_of_discharge,
                           claim_rec.clm_type_gen_type_id,
                           null,--CLAIM_SUB_TYPE
                           claim_rec.member_seq_id,
                           claim_rec.tpa_enrollment_id,
                           claim_rec.mem_name,
                           claim_rec.mem_age,
                           claim_rec.ins_seq_id,
                           claim_rec.policy_seq_id,
                           claim_rec.enrol_type_id,
                           claim_rec.emirate_id,
                           claim_rec.encounter_type_id,
                           claim_rec.encounter_start_type,
                           claim_rec.encounter_end_type,
                           claim_rec.encounter_facility_id,
                           claim_rec.payer_id,
                           claim_rec.ava_sum_insured,
                           claim_rec.currency_type,
                           'INP', 
                           null,-- Resub remarks
                           claim_rec.invoice_number,
                           v_req_amt, 
                           claim_rec.clinician_id,
                           claim_rec.system_of_medicine_type_id,
                           claim_rec.accident_related_type_id,
                           claim_rec.priority_general_type_id,
                           claim_rec.network_yn,
                           claim_rec.benifit_type,
                           claim_rec.GRAVIDA,
                           claim_rec.PARA,
                           claim_rec.LIVE,
                           claim_rec.ABORTION,
                           claim_rec.PRESENTING_COMPLAINTS,
                           claim_rec.MEDICAL_OPINION_REMARKS,
                           claim_rec.HOSP_SEQ_ID,
                           claim_rec.HOSP_NAME,
                           claim_rec.ADDRESS_1,
                           claim_rec.CITY_TYPE_ID,
                           claim_rec.STATE_TYPE_ID,
                           claim_rec.PIN_CODE,
                           claim_rec.OFF_PHONE_NO_1,
                           claim_rec.office_fax_no,
                           claim_rec.PROVIDER_ID,
                           claim_rec.COUNTRY_TYPE_ID,
                           claim_rec.clinician_name,
                           v_added_by,
                           null,
                           NULL,
                           null,			
                           claim_rec.conception_type,
                           claim_rec.lmp_date,
                           claim_rec.REQ_AMT_CURRENCY_TYPE,
                           claim_rec.CONVERTED_AMOUNT,
                           claim_rec.CONVERTED_AMOUNT_CURRENCY_TYPE,
                           claim_rec.CONVERSION_RATE,	
                           claim_rec.Process_Type,	
                           claim_rec.oth_tpa_ref_no,
                           claim_rec.treatment_type,
		                       claim_rec.delvry_mod_type,
                           claim_rec.event_no,
                           claim_rec.embassy_seq_id,
                           NULL,
                           NULL,
                           NULL,
						               claim_rec.MAT_COMPLCTON_YN,
                           v_rows_processed
                           );

      --Assigning to System 
                authorization_pkg.reassign_user( null,'|'||v_claim_seq_id||'|',1,1,'MAN',v_assign_Seq,null);
      --For Copying Dental iotn Configuration 
         IF claim_rec.benifit_type='DNTL' THEN
            
         OPEN Dental_iotn_Config;
           FETCH Dental_iotn_Config INTO Dental_iotn;
             CLOSE Dental_iotn_Config;
             
            INSERT INTO ORTHODONTIC_DETAILS_TAB
                        (ORTHO_SEQ_ID,
                        SOURCE_SEQ_ID,
                        SOURCE_FROM,
                        DENTO_CLASS_I,
                        DENTO_CLASS_II,
                        DENTO_CLASS_II_TEXT,
                        DENTO_CLASS_III,
                        SKELE_CLASS_I,
                        SKELE_CLASS_II,
                        SKELE_CLASS_III,
                        OVERJET_MM,
                        REV_OVERJET_MM,
                        REV_OVERJET_YN,
                        CROSSBITE_ANT,
                        CROSSBITE_POST,
                        CROSSBITE_BETW,
                        OPENBIT_ANT,
                        OPENBIT_POST,
                        OPENBIT_LATE,
                        CONT_POINT_DISP,
                        OVERBIT_DEEP,
                        OVERBIT_PATA,
                        OVERBIT_GING,
                        HYPO_QUAD1,
                        HYPO_QUAD2,
                        HYPO_QUAD3,
                        HYPO_QUAD4,
                        OTHERS_IMPEDED,
                        OTHERS_IMPACT,
                        OTHERS_SUBMERG,
                        OTHERS_SUPERNUM,
                        OTHERS_RETAINE,
                        OTHERS_ECTOPIC,
                        OTHERS_CRANIO,
                        AC_MARKS,
                        CROSSBITE_ANT_MM,
                        CROSSBITE_PRST_MM,
                        CROSSBITE_BETW_MM,
                        CONT_POINT_DISP_MM,
                        DENTO_CLASS_III_TEXT,
                        IOTN_REMARK) VALUES 
                        (
                        null,
                        v_claim_seq_id,
                        Dental_iotn.SOURCE_FROM,
                        Dental_iotn.DENTO_CLASS_I,
                        Dental_iotn.DENTO_CLASS_II,
                        Dental_iotn.DENTO_CLASS_II_TEXT,
                        Dental_iotn.DENTO_CLASS_III,
                        Dental_iotn.SKELE_CLASS_I,
                        Dental_iotn.SKELE_CLASS_II,
                        Dental_iotn.SKELE_CLASS_III,
                        Dental_iotn.OVERJET_MM,
                        Dental_iotn.REV_OVERJET_MM,
                        Dental_iotn.REV_OVERJET_YN,
                        Dental_iotn.CROSSBITE_ANT,
                        Dental_iotn.CROSSBITE_POST,
                        Dental_iotn.CROSSBITE_BETW,
                        Dental_iotn.OPENBIT_ANT,
                        Dental_iotn.OPENBIT_POST,
                        Dental_iotn.OPENBIT_LATE,
                        Dental_iotn.CONT_POINT_DISP,
                        Dental_iotn.OVERBIT_DEEP,
                        Dental_iotn.OVERBIT_PATA,
                        Dental_iotn.OVERBIT_GING,
                        Dental_iotn.HYPO_QUAD1,
                        Dental_iotn.HYPO_QUAD2,
                        Dental_iotn.HYPO_QUAD3,
                        Dental_iotn.HYPO_QUAD4,
                        Dental_iotn.OTHERS_IMPEDED,
                        Dental_iotn.OTHERS_IMPACT,
                        Dental_iotn.OTHERS_SUBMERG,
                        Dental_iotn.OTHERS_SUPERNUM,
                        Dental_iotn.OTHERS_RETAINE,
                        Dental_iotn.OTHERS_ECTOPIC,
                        Dental_iotn.OTHERS_CRANIO,
                        Dental_iotn.AC_MARKS,
                        Dental_iotn.CROSSBITE_ANT_MM,
                        Dental_iotn.CROSSBITE_PRST_MM,
                        Dental_iotn.CROSSBITE_BETW_MM,
                        Dental_iotn.CONT_POINT_DISP_MM,
                        Dental_iotn.DENTO_CLASS_III_TEXT,
                        Dental_iotn.Iotn_Remark
                        );
            
           
         END IF;
         
         --Copying PED Details
         
          UPDATE CLM_AUTHORIZATION_DETAILS D
            SET D.DUR_AILMENT=claim_rec.dur_ailment,
                D.DURATION_FLAG=claim_rec.duration_flag
          WHERE D.CLAIM_SEQ_ID=v_claim_seq_id; 
              
         --Copying diagnosis details
          FOR I IN (SELECT * FROM diagnosys_details dd
                      WHERE dd.claim_seq_id = v_parent_claim_seq_id) loop 
            INSERT INTO diagnosys_details(diag_seq_id,claim_seq_id,icd_code_seq_id,diagnosys_code,primary_ailment_yn,added_by,added_date)
            VALUES (diagnosys_detail_seq.nextval,v_claim_seq_id,I.icd_code_seq_id,I.diagnosys_code,I.primary_ailment_yn,v_added_by,sysdate);
           
           END LOOP;
          
         --Copying activity details 
         
         
          FOR j IN Add_Activity_Details(v_parent_claim_seq_id) LOOP
             v_elg_yn :=null; 
          FOR I IN (SELECT distinct d.approved_amount,claim_seq_id,Activity_Seq_Id,activity_id,start_date,activity_type,code,
                            unit_type,modifier,internal_code,package_id,bundle_id,quantity,gross_amount,discount_amount,disc_gross_amount,patient_share_amount,
                            copay_amount,co_ins_amount,deduct_amount,out_of_pocket_amount,net_amount,allow_yn,
                            added_by,added_date,approvd_quantity,unit_price,mem_service_desc,tooth_no,carry_for_yn 
                            FROM pat_activity_details d WHERE to_date(d.START_DATE,'dd-mm-yyyy') = to_date(j.service_date,'dd-mm-yyyy') 
                              and d.claim_seq_id = v_parent_claim_seq_id and d.internal_code = j.internal_code and nvl(d.approved_amount,0)>0 
                           AND d.approved_amount != (d.disc_gross_amount-nvl(patient_share_amount,0)) ) LOOP
         
             v_elg_yn :=null; 

       ---Carry Forwording service details ,Which are partially paid in parent      
            IF i.Disc_Gross_Amount != i.approved_amount and i.internal_code = j.Internal_Code THEN
                  v_elg_yn := 'N' ; ----- Flag is used for activity identification for outer loop
                
           
                INSERT INTO app.pat_activity_details(activity_dtl_seq_id,claim_seq_id,Activity_Seq_Id,activity_id,start_date,activity_type,code,
                            unit_type,modifier,internal_code,package_id,bundle_id,quantity,gross_amount,discount_amount,disc_gross_amount,patient_share_amount,
                            copay_amount,co_ins_amount,deduct_amount,out_of_pocket_amount,net_amount,allowed_amount,approved_amount,allow_yn,denial_code,
                            remarks,added_by,added_date,denial_desc,approvd_quantity,unit_price,provider_net_amount,mem_service_desc,tooth_no,carry_for_yn ,Alkoot_Remarks,RESUB_REMARKS)
                VALUES (pat_activity_detail_seq.nextval,v_claim_seq_id,i.activity_seq_id,i.activity_id,i.start_date,i.activity_type,i.code,i.unit_type,
                       i.modifier,i.internal_code,i.package_id,i.bundle_id,i.quantity,i.gross_amount,i.discount_amount,i.disc_gross_amount,i.patient_share_amount,i.copay_amount,
                       i.co_ins_amount,i.deduct_amount,i.out_of_pocket_amount,i.net_amount,null,null,'Y',null,null,v_added_by,
                       SYSDATE,null,i.approvd_quantity,i.unit_price,j.resub_req_amt,i.mem_service_desc,i.tooth_no,'Y',j.Alkoot_Remarks,j.Resub_Remarks);
                UPDATE app.clm_authorization_details a
                  SET a.cal_act_yn='N'
                WHERE a.claim_seq_id=v_claim_seq_id;
                
            END IF; -- Adding new activity codes to resubmission claim
          END LOOP;
          
         IF NVL(v_elg_yn,'Y') = 'Y' THEN  
                Get_Activity_Det:=null;--Resetting previous values
            OPEN Get_Activity_Details(j.hosp_seq_id,j.internal_code,j.service_date);
              FETCH Get_Activity_Details INTO Get_Activity_Det;
                CLOSE Get_Activity_Details;
                
          IF  claim_rec.benifit_type='OPTS' AND Get_Activity_Det.Activity_Code='63' THEN
                  
                UPDATE APP.CLM_BULK_UPLD_RESUB_DTLS RD
                 SET RD.SYS_REMARKS ='Benefit type not matching with activity code.'
                WHERE RD.INTERNAL_CODE =J.INTERNAL_CODE AND RD.ACT_TYPE='ACTIVITY' AND RD.HOSP_SEQ_ID= J.HOSP_SEQ_ID
                AND RD.XML_SEQ_ID = v_xml_seq_id and rd.parent_claim_seq_id = v_parent_claim_seq_id;
          
          ELSE
              INSERT INTO app.pat_activity_details
              (activity_dtl_seq_id
               ,claim_seq_id
               ,quantity
               ,Activity_Seq_Id
               ,start_date
               ,activity_type_id
               ,code
               ,internal_code
               ,unit_price
               ,converted_acitivty_amt
               ,gross_amount
               ,disc_gross_amount
               ,discount_amount
               ,provider_net_amount
               ,added_date
               ,added_by
               ,internal_desc
               ,allow_yn
               ,activity_type
               ,Alkoot_Remarks
               ,RESUB_REMARKS)
              VALUES
              (pat_activity_detail_seq.nextval
               ,v_claim_seq_id
               ,j.req_quant
               ,Get_Activity_Det.Act_Mas_Dtl_Seq_Id
               ,to_date(j.service_date,'DD/MM/YYYY')
               ,CASE WHEN j.act_type='DRUG' THEN 'DRG'
                     WHEN j.act_type='ACTIVITY' THEN 'ACT' END
               ,CASE WHEN j.act_type='DRUG' AND Get_Activity_Det.Activity_Code IS NULL THEN 'PHARMA'
                     WHEN j.act_type='ACTIVITY' AND Get_Activity_Det.Activity_Code IS NULL THEN 'ACTIVITY'
                     ELSE Get_Activity_Det.Activity_Code END   
               ,CASE WHEN Get_Activity_Det.internal_code IS NULL THEN j.internal_code
                     WHEN Get_Activity_Det.internal_code IS NOT NULL THEN Get_Activity_Det.internal_code  ELSE NULL END
               ,nvl(Get_Activity_Det.Gross_Amount,j.resub_req_amt)/j.req_quant
               ,nvl(Get_Activity_Det.Gross_Amount,j.resub_req_amt)/j.req_quant
               ,CASE WHEN (Get_Activity_Det.Gross_Amount * j.req_quant) IS NULL THEN j.resub_req_amt 
                     WHEN (Get_Activity_Det.Gross_Amount * j.req_quant) IS NOT NULL THEN (Get_Activity_Det.Gross_Amount * j.req_quant) ELSE NULL END
               ,nvl(Get_Activity_Det.Gross_Amount*j.req_quant,j.resub_req_amt)-nvl(Get_Activity_Det.Disc_Amount*j.req_quant ,0)
               ,Get_Activity_Det.Disc_Amount*j.req_quant
               ,j.resub_req_amt
               ,SYSDATE
               ,1
               ,j.serv_desc
               ,'Y'
               ,Get_Activity_Det.Activity_Type_Seq_Id
               ,j.Alkoot_Remarks
               ,j.Resub_Remarks);
          END IF;    
              UPDATE app.clm_authorization_details a
                SET a.cal_act_yn='N'
              WHERE a.claim_seq_id=v_claim_seq_id;
              
          END IF;
     END LOOP;

     FOR j IN Verify_Activity_Details(v_parent_claim_seq_id) LOOP
       FOR I IN (SELECT distinct d.approved_amount,activity_type,Disc_Gross_Amount,internal_code,CODE
                            FROM pat_activity_details d
                      WHERE d.claim_seq_id = v_parent_claim_seq_id and d.internal_code = j.internal_code and nvl(d.approved_amount,0)>0 and d.approved_amount = (d.disc_gross_amount-nvl(patient_share_amount,0)) ) LOOP
      
         ---Validating the given service with parent billing, Is it paid completly or partially
                 
            IF i.Disc_Gross_Amount = i.approved_amount and i.internal_code = j.Internal_Code THEN
                  v_elg_yn := 'N' ; --- Flag is used for activity identification for outer loop
                UPDATE APP.CLM_BULK_UPLD_RESUB_DTLS RD
                 SET RD.SYS_REMARKS = RD.SYS_REMARKS ||'This Service/Activity is not eligible for resubmission'
                WHERE  RD.RESUB_INTER_SEQ = j.RESUB_INTER_SEQ;
           end if;     
       END LOOP;
    END LOOP;  
   
      END IF;
    EXCEPTION
    WHEN OTHERS THEN
     v_sql_errm := sqlerrm;
     v_sql_code := sqlcode;
     save_exception_log(v_xml_seq_id,NULL,v_sql_code,v_sql_errm,NULL,1,'copy_parent_claim_dtls',NULL);
      DBMS_OUTPUT.put_line (DBMS_UTILITY.format_error_backtrace);   
      
  END copy_parent_claim_dtls;

--===========================================================================================
-->This procedure used to delete the resubmission claims in exceptional case
--===========================================================================================
PROCEDURE Delete_Exceptional_Claims(v_xml_seq_id       NUMBER,
                                    v_clm_batch_seq_id NUMBER)
                                    
AS
CURSOR Get_Claim_Seq_Ids IS
  SELECT cad.clm_batch_seq_id,cad.claim_seq_id,cad.parent_claim_seq_id 
     FROM APP.CLM_BATCH_UPLOAD_DETAILS BAT
    JOIN APP.CLM_AUTHORIZATION_DETAILS CAD ON (BAT.CLM_BATCH_SEQ_ID=CAD.CLM_BATCH_SEQ_ID)
   WHERE BAT.CLM_BATCH_SEQ_ID = v_clm_batch_seq_id; 
BEGIN
  FOR I IN Get_Claim_Seq_Ids LOOP
  
  --Deleting Assining to
   DELETE FROM APP.ASSIGN_USERS AU WHERE AU.CLAIM_SEQ_ID = I.CLAIM_SEQ_ID;
  --Deleting Activies
   DELETE FROM APP.PAT_ACTIVITY_DETAILS PAD WHERE PAD.CLAIM_SEQ_ID = I.CLAIM_SEQ_ID ;
  --Deleting Diagnosys
   DELETE FROM APP.DIAGNOSYS_DETAILS DD WHERE DD.CLAIM_SEQ_ID = I.CLAIM_SEQ_ID; 
  --Deleting Hospital Details
   DELETE FROM APP.CLM_HOSPITAL_DETAILS CHD WHERE CHD.CLAIM_SEQ_ID= I.CLAIM_SEQ_ID;
  -- Updating Parent Claim seq id 
   UPDATE APP.PAT_AUTHORIZATION_DETAILS
    SET CLAIM_SEQ_ID=i.parent_claim_seq_id
   WHERE CLAIM_SEQ_ID = I.CLAIM_SEQ_ID; 
  --Deleting General Details
   DELETE FROM APP.CLM_AUTHORIZATION_DETAILS CAD WHERE CAD.CLAIM_SEQ_ID= I.CLAIM_SEQ_ID;
  -- Deleting batch record
  DELETE FROM APP.CLM_BATCH_UPLOAD_DETAILS BA WHERE BA.CLM_BATCH_SEQ_ID= v_clm_batch_seq_id;
  
  END LOOP;
  COMMIT;
END  Delete_Exceptional_Claims;
--===========================================================================================
                           
end claim_bulk_upload;

/

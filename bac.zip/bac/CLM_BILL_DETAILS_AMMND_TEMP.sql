--------------------------------------------------------
--  DDL for Synonymn CLM_BILL_DETAILS_AMMND_TEMP
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."CLM_BILL_DETAILS_AMMND_TEMP" FOR "APP"."CLM_BILL_DETAILS_AMMND_TEMP";

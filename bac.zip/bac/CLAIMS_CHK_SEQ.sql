--------------------------------------------------------
--  DDL for Synonymn CLAIMS_CHK_SEQ
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."CLAIMS_CHK_SEQ" FOR "FIN_APP"."CLAIMS_CHK_SEQ";

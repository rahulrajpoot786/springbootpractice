--------------------------------------------------------
--  DDL for Synonymn IDX_CLMGEN_FILENUM
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."IDX_CLMGEN_FILENUM" FOR "APP"."IDX_CLMGEN_FILENUM";

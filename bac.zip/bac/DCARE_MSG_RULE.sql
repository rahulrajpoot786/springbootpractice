--------------------------------------------------------
--  DDL for Synonymn DCARE_MSG_RULE
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."DCARE_MSG_RULE" FOR "APP"."DCARE_MSG_RULE";

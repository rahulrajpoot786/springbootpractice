--------------------------------------------------------
--  DDL for Package CLAIMS_APPROVAL_PKG
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "VENUBABU"."CLAIMS_APPROVAL_PKG" AS

 PROCEDURE save_ins_approval_limit(
--preauth
          v_prod_policy_seq_id      IN tpa_ins_prod_policy.prod_policy_seq_id%TYPE,
          v_ins_pat_apr_rej_yn      IN tpa_ins_prod_policy.ins_pat_apr_rej_yn%TYPE,
          v_ins_pat_allow_yn        IN tpa_ins_prod_policy.ins_pat_allow_yn%TYPE,
          v_ins_pat_operator        IN tpa_ins_prod_policy.ins_pat_operator%TYPE,
          v_ins_pat_apr_limit       IN tpa_ins_prod_policy.ins_pat_apr_limit%TYPE,
          v_ins_pat_rej_allow_yn    IN tpa_ins_prod_policy.ins_pat_rej_allow_yn%TYPE,
          v_pat_mail_flag           IN tpa_ins_prod_policy.pat_mail_flag%TYPE,
          v_pat_mail_freq_hours     IN tpa_ins_prod_policy.pat_mail_freq_hours%TYPE,
          v_pat_mail_freq_mins      IN tpa_ins_prod_policy.pat_mail_freq_mins%TYPE,
--cash less claims
          v_ins_clm_cl_apr_rej_yn   IN tpa_ins_prod_policy.ins_clm_cl_apr_rej_yn%TYPE,
          v_ins_clm_cl_allow_yn     IN tpa_ins_prod_policy.ins_clm_cl_allow_yn%TYPE,
          v_ins_clm_cl_operator     IN tpa_ins_prod_policy.ins_clm_cl_operator%TYPE,
          v_ins_clm_cl_apr_limit    IN tpa_ins_prod_policy.ins_clm_cl_apr_limit%TYPE,
          v_ins_clm_cl_rej_allow_yn IN tpa_ins_prod_policy.ins_clm_cl_rej_allow_yn%TYPE,
          v_clm_cl_mail_flag        IN tpa_ins_prod_policy.clm_cl_mail_flag%TYPE,
--member claim
          v_ins_clm_cm_apr_rej_yn   IN tpa_ins_prod_policy.ins_clm_cm_apr_rej_yn%TYPE,
          v_ins_clm_cm_allow_yn     IN tpa_ins_prod_policy.ins_clm_cm_allow_yn%TYPE,
          v_ins_clm_cm_operator     IN tpa_ins_prod_policy.ins_clm_cm_operator%TYPE,
          v_ins_clm_cm_apr_limit    IN tpa_ins_prod_policy.ins_clm_cm_apr_limit%TYPE,
          v_ins_clm_cm_rej_allow_yn IN tpa_ins_prod_policy.ins_clm_cm_rej_allow_yn%TYPE,
          v_clm_cm_mail_flag        IN tpa_ins_prod_policy.clm_cm_mail_flag%TYPE,
          v_clm_mail_freq_hours     IN tpa_ins_prod_policy.clm_mail_freq_hours%TYPE,
          v_clm_mail_freq_mins      IN tpa_ins_prod_policy.clm_mail_freq_mins%TYPE,
          v_added_by                IN tpa_ins_prod_policy.added_by%TYPE,
          v_rows_processed          OUT NUMBER);

PROCEDURE select_ins_approval_limit(v_prod_policy_seq_id     IN tpa_ins_prod_policy.prod_policy_seq_id%TYPE,
                                    v_result_set             OUT SYS_REFCURSOR);

PROCEDURE select_claims_list (
          v_user_seq_id                    IN  tpa_user_contacts.contact_seq_id%TYPE,
          v_tpa_enrollment_id              IN  clm_enroll_details.tpa_enrollment_id%TYPE,
          v_policy_number                  IN  clm_enroll_details.policy_number%TYPE,
          v_claim_number                   IN  clm_general_details.claim_number%TYPE,
          v_from_date                      IN  VARCHAR2,
          v_to_date                        IN  VARCHAR2,
          v_clm_status_general_type_id     IN  clm_enroll_details.clm_status_general_type_id%TYPE,
          v_tpa_office_seq_id              IN  tpa_office_info.tpa_office_seq_id%TYPE ,
          v_ro_do_code                     IN  tpa_ins_info.ins_comp_code_number%TYPE,
          v_operator                       IN  tpa_ins_prod_policy.ins_pat_operator%TYPE,
          v_recomm_amt                     IN  clm_general_details.requested_amount%TYPE,
          v_clm_status_id                  IN  clm_enroll_details.clm_status_general_type_id%TYPE,
          v_sort_var                       IN  VARCHAR2,
          v_sort_order                     IN  VARCHAR2,
          v_start_num                      IN  NUMBER ,
          v_end_num                        IN  NUMBER ,                    
          result_set                       OUT SYS_REFCURSOR );

PROCEDURE select_claims_web (v_claim_seq_id   IN clm_general_details.claim_number%TYPE,
                             v_claim_xml      OUT XMLTYPE,
                             v_ins_status     OUT clm_ins_intimation_details.clm_ins_status%TYPE ,
                             v_ins_remarks    out clm_ins_intimation_details.clm_ins_remarks%type);

FUNCTION fn_sfremarks (v_claim_seq_id     IN NUMBER) RETURN VARCHAR2;

FUNCTION f_rej_amt_rem (v_claim_seq_id    IN clm_general_details.claim_seq_id%TYPE,
                        v_flag            IN VARCHAR2) RETURN VARCHAR2;

FUNCTION f_icd_code_desc(v_claim_seq_id   IN icd_pcs_detail.icd_pcs_seq_id%TYPE,
                         v_flag           IN VARCHAR2,
                         v_type           IN VARCHAR2)  RETURN  VARCHAR2;

PROCEDURE claim_ins_appr_save (v_seq_ids              IN VARCHAR2,
                               v_appr_rej_status      IN clm_enroll_details.Clm_Status_General_Type_Id%TYPE,
                               v_remarks              IN CLM_INS_INTIMATION_DETAILS.clm_ins_remarks%TYPE,
                 v_added_by             IN NUMBER,
                               v_rows_processed       OUT NUMBER);

PROCEDURE claims_intimate_send(v_ins_code              IN tpa_ins_info.abbrevation_code%TYPE,
                               v_result_set            OUT SYS_REFCURSOR);

PROCEDURE clm_generate_letter (v_claim_seq_id          IN clm_enroll_details.claim_seq_id%TYPE,
                               v_clm_result            OUT SYS_REFCURSOR);

PROCEDURE clm_gen_policy_hist(v_policy_number       IN tpa_enr_policy.policy_number%TYPE,
                              v_tpa_enr_id          IN tpa_enr_policy_member.tpa_enrollment_id%TYPE,
                              v_pol_hist_result     OUT SYS_REFCURSOR );

PROCEDURE clm_prev_history(v_tpa_enrollment_id   IN tpa_enr_policy_member.tpa_customer_id%TYPE,
                           v_clm_hist_result     OUT SYS_REFCURSOR );

PROCEDURE clm_bill_details(v_claim_seq_id    IN clm_general_details.claim_seq_id%TYPE,
                            v_bill_result    OUT SYS_REFCURSOR );

PROCEDURE select_preauth_list (
    v_user_seq_id                    IN  tpa_user_contacts.contact_seq_id%TYPE,
    v_tpa_enrollment_id              IN  clm_enroll_details.tpa_enrollment_id%TYPE,
    v_policy_number                  IN  clm_enroll_details.policy_number%TYPE,
    v_preauth_number                 IN  pat_enroll_details.pre_auth_number%TYPE,
    v_from_date                      IN  VARCHAR2,
    v_to_date                        IN  VARCHAR2,
    v_pat_status_general_type_id     IN  pat_enroll_details.pat_status_general_type_id%TYPE,
    v_tpa_office_seq_id              IN  tpa_office_info.tpa_office_seq_id%TYPE ,
    v_ro_do_code                     IN  tpa_ins_info.ins_comp_code_number%TYPE,
    v_operator                       IN  tpa_ins_prod_policy.ins_pat_operator%TYPE,
    v_recomm_amt                     IN  clm_general_details.requested_amount%TYPE,
    v_pat_status_id                  IN  pat_enroll_details.pat_status_general_type_id%TYPE,    
    v_sort_var                       IN  VARCHAR2,
    v_sort_order                     IN  VARCHAR2,
    v_start_num                      IN  NUMBER ,
    v_end_num                        IN  NUMBER ,
    result_set                       OUT SYS_REFCURSOR );

PROCEDURE select_preauth_web (v_pat_gen_detail_seq_id    IN  pat_general_details.pat_gen_detail_seq_id%TYPE,
                              v_pat_xml                  OUT XMLTYPE,
                              v_ins_status               OUT pat_ins_intimation_details.pat_ins_status%TYPE,
                              v_ins_remarks              out pat_ins_intimation_details.pat_ins_remarks%type);

FUNCTION f_icd_code_desc_pat(v_pat_gen_detail_seq_id  IN icd_pcs_detail.pat_gen_detail_seq_id%TYPE, -- to precide ICD CODES
                             v_flag                   IN VARCHAR2,
                             v_type                   IN VARCHAR2) RETURN  VARCHAR2;

FUNCTION fn_sfremarks_pat (v_pat_gen_detail_seq_id IN pat_general_details.pat_gen_detail_seq_id%TYPE)
                          RETURN VARCHAR2;



PROCEDURE pat_ins_appr_save (v_seq_ids                IN VARCHAR2,
                             v_appr_rej_status        IN pat_ins_intimation_details.pat_ins_status%TYPE,
                             v_remarks                IN pat_ins_intimation_details.pat_ins_remarks%TYPE,
               v_added_by             IN NUMBER,
                             v_rows_processed         OUT NUMBER);


PROCEDURE pat_intimate_send (v_ins_code               IN tpa_ins_info.abbrevation_code%TYPE,
                             v_result_set             OUT SYS_REFCURSOR);

PROCEDURE pat_generate_letter (v_pat_gen_detail_seq_id        IN pat_general_details.pat_gen_detail_seq_id%TYPE,
                               v_pat_result                   OUT SYS_REFCURSOR);

PROCEDURE pat_gen_policy_hist(v_policy_number          IN tpa_enr_policy.policy_number%TYPE,
                              v_tpa_enr_id             IN tpa_enr_policy_member.tpa_enrollment_id%TYPE,
                              v_pol_hist_result        OUT SYS_REFCURSOR ) ;

PROCEDURE pat_prev_history (v_tpa_enrollment_id        IN pat_enroll_details.tpa_enrollment_id%TYPE,
                            v_pat_hist_result          OUT SYS_REFCURSOR);

PROCEDURE pat_bill_details(v_pat_gen_detail_seq_id      IN pat_general_details.pat_gen_detail_seq_id%TYPE,
                           v_bill_result                OUT SYS_REFCURSOR) ;

PROCEDURE claims_intimate_send_iar(v_ins_code           IN  tpa_ins_info.abbrevation_code%TYPE,
                                   v_result_set_i       OUT sys_refcursor,
                                   v_result_set_a       OUT sys_refcursor,
                                   v_result_set_r       OUT sys_refcursor);

PROCEDURE pat_intimate_send_iar (v_ins_code      IN  tpa_ins_info.abbrevation_code%TYPE,
                                 v_result_set_i  OUT sys_refcursor,
                                 v_result_set_a  OUT sys_refcursor,
                                 v_result_set_r  OUT sys_refcursor);

PROCEDURE send_mail_intimation (v_ins_code             IN tpa_ins_info.ins_comp_code_number%TYPE,
                                v_msg_id               IN source_message.msg_id%TYPE,
                                v_file_name            IN destination_message.file_path_name%TYPE,
                                v_dest_msg_seq_id      OUT destination_message.dest_msg_seq_id%TYPE,
                                v_rows_processed       OUT NUMBER);
procedure gen_pat_apr_rej_rpt (v_where varchar2,
                               v_result_set out sys_refcursor);

procedure gen_clm_apr_rej_rpt (v_where varchar2,
                               v_result_set out sys_refcursor);

procedure pat_clm_doc_upload (v_pat_seq_id in pat_general_details.pat_gen_detail_seq_id%type,
                            v_clm_seq_id in clm_general_details.claim_seq_id%type,
                            v_file_name  in varchar2,
                            V_remarks    in varchar2,
                            v_added_by   in pat_general_details.added_by%type,
                            v_rows_processed out number) ;

procedure pat_clm_override (v_pat_seq_id in pat_general_details.pat_gen_detail_seq_id%type,
                            v_clm_seq_id in clm_general_details.claim_seq_id%type,
                            v_added_by   in pat_general_details.added_by%type,
                            V_rows_processed out number) ;


PROCEDURE clm_ins_apr_save_xfdf(v_clm_numbers          IN varchar2,
                                v_appr_rej_status      IN clm_ins_intimation_details.clm_ins_status%TYPE,
                                v_remarks              IN clm_ins_intimation_details.clm_ins_remarks%TYPE);

PROCEDURE pat_ins_apr_save_xfdf(v_pat_numbers         IN varchar2,
                               v_appr_rej_status      IN pat_ins_intimation_details.pat_ins_status%TYPE,
                               v_remarks              IN pat_ins_intimation_details.pat_ins_remarks%TYPE);



 function get_srtfall_remarks(v_flag         IN CHAR, -- OTHERS FOR OTHERS QUERY, CHCEKBOX FOR CHECKBOXES
                             v_mode         IN CHAR , --"PAT" FOR PREAUTH, "CLM" FOR CLAIMS
                             v_seq_id       IN CLM_GENERAL_DETAILS.CLAIM_SEQ_ID%TYPE)   RETURN clob ;





PROCEDURE preauth_xfdf_report (v_pat_gen_detail_seq_id    pat_general_details.pat_gen_detail_seq_id%TYPE,
                               v_file_name out varchar2,
                               v_generate_yn out char);

PROCEDURE claims_xfdf_report (v_claim_seq_id    clm_general_details.claim_seq_id%TYPE,
                              v_file_name out varchar2,
                              v_generate_yn   out char);

PROCEDURE save_prod_pol_escalation(
    v_prod_policy_seq_id                 IN  TPA_INS_PROD_POLICY_LIMITS.prod_policy_seq_id%TYPE,
    v_string                             IN  VARCHAR2, --  |prod_pol_esc_seq_id|pat_clm_type|freq_flag|remainder_type|remainder_value|
    v_added_by                           IN  NUMBER,
    v_rows_processed                     OUT NUMBER
  );

PROCEDURE select_prod_pol_escalation(
    v_prod_policy_seq_id                 IN   TPA_INS_PROD_POLICY_LIMITS.prod_policy_seq_id%TYPE,
    v_pat_result_set                         OUT  SYS_REFCURSOR,
    v_clm_result_set                         OUT  SYS_REFCURSOR
  );

PROCEDURE override_ins_intimation(
    v_pat_clm_seq_id                     IN  clm_general_details.claim_seq_id%TYPE,
    v_mode                               IN  VARCHAR2, --  'PAT' FOR PREAUTH, 'CLM' FOR CLAIMS
    v_ins_intimation_req_yn              in  CLM_INS_INTIMATION_DETAILS.ins_intimation_req_yn%type,
    v_ins_int_rson_type                  IN  clm_ins_intimation_details.INS_INT_RSON_TYPE_ID%TYPE,
    v_override_remarks                   in  clm_ins_intimation_details.ins_int_override_remarks%type,
    v_added_by                           in  number,
    v_rows_processed                     out number
  );

PROCEDURE select_ins_intimation(
    v_pat_clm_seq_id                     IN  clm_general_details.claim_seq_id%TYPE,
    v_mode                               IN  VARCHAR2, --  'PAT' FOR PREAUTH, 'CLM' FOR CLAIMS
    v_result_set                         out sys_refcursor
  ) ;
END;

/

--------------------------------------------------------
--  DDL for Synonymn CITYBANK_INS_XML_PAIDCLAIMS
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."CITYBANK_INS_XML_PAIDCLAIMS" FOR "APP"."CITYBANK_INS_XML_PAIDCLAIMS";

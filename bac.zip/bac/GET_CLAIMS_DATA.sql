--------------------------------------------------------
--  DDL for Procedure GET_CLAIMS_DATA
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "VENUBABU"."GET_CLAIMS_DATA" (V_CLAIM_SEQ_ID IN NUMBER,
                                             V_RESULT OUT NUMBER)
                                             AS
                                             
cursor get_claim_info is
   SELECT Q.CLAIM_SEQ_ID INTO V_RESULT
 FROM PAT_ACTIVITY_DETAILS Q WHERE Q.CLAIM_SEQ_ID=V_CLAIM_SEQ_ID;
 
                                             BEGIN
 OPEN get_claim_info;
 fetch get_claim_info into V_RESULT ;
 close get_claim_info;

 END GET_CLAIMS_DATA;

/

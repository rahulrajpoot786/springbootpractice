--------------------------------------------------------
--  DDL for Synonymn CITYBANK_INS_XML_CERTNO
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."CITYBANK_INS_XML_CERTNO" FOR "APP"."CITYBANK_INS_XML_CERTNO";

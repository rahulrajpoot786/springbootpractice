--------------------------------------------------------
--  DDL for Package Body DEFINE_RULE_PKG
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "VENUBABU"."DEFINE_RULE_PKG" IS

---=======================================================================
  -- Author  : SHARMILAN_C
  -- Created : 3/6/2006 9:17:00 PM
  -- Modified : Ravi 06-dec-12
  -- purposer : for koc1107 and koc1109 for entering rule remarks failed
--========================================================================
  PROCEDURE save_prod_policy_rules(v_id               IN OUT NUMBER,
                                   v_flag             CHAR,
                                   v_prod_policy_rule IN TPA_INS_PROD_POLICY_RULES.prod_policy_rule%TYPE,
                                   v_valid_from       IN TPA_INS_PROD_POLICY_RULES.valid_from%TYPE,
                                   v_added_by         IN TPA_INS_PROD_POLICY_RULES.added_by%TYPE,
                                   v_ovride_yn        IN RULE_DATA.OVER_RIDE_YN%TYPE := 'N' --FOR KOC1099 RULE_DATA_REMARKS
                                   ) IS
    v_max_valid_from tpa_ins_prod_policy_rules.valid_to%TYPE;

    CURSOR prod_cur IS
      SELECT c.empaneled_date  FROM tpa_ins_prod_policy A
        JOIN tpa_ins_product B ON (a.product_seq_id = b.product_seq_id)
        JOIN tpa_ins_info C    ON (b.ins_seq_id = c.ins_seq_id)
       WHERE a.prod_policy_seq_id = v_id;
    CURSOR rule_seq_cur IS
      SELECT prod_policy_rule_seq_id
        FROM tpa_ins_prod_policy_rules
       WHERE valid_from = v_max_valid_from  AND prod_policy_seq_id = v_id;
       
     CURSOR Get_Rule_Config_Xml IS
       SELECT R.PROD_POLICY_RULE 
         FROM APP.TPA_INS_PROD_POLICY_RULES R
         WHERE R.PROD_POLICY_RULE_SEQ_ID =  v_id ;

    v_count                      NUMBER(3);
    v_empaneled_date             tpa_ins_info.empaneled_date%TYPE;
    v_execution_flag             NUMBER(1) := 1;
    v_completed_yn               VARCHAR2(1);
    v_max_prd_policy_rule_seq_id tpa_ins_prod_policy_rules.prod_policy_rule_seq_id%TYPE;
    v_prod_policy_rule_wsp       Tpa_ins_prod_policy_rules.Prod_Policy_Rule%TYPE;
    v_prod_policy_rule_old       Tpa_ins_prod_policy_rules.Prod_Policy_Rule%TYPE;


  BEGIN
--insert into app.temp(xml_data) values (v_prod_policy_rule);commit;
       v_prod_policy_rule_wsp :=v_prod_policy_rule;
       pr_whitespc_matprm(v_prod_policy_rule_wsp);

   IF v_flag = 'P' THEN  -- Product or policy level Insertion
      SELECT MAX(valid_from)  INTO v_max_valid_from FROM tpa_ins_prod_policy_rules
       WHERE prod_policy_seq_id = v_id;

      IF v_max_valid_from IS NULL THEN
        OPEN prod_cur;
        FETCH prod_cur INTO v_empaneled_date;
        CLOSE prod_cur;

        IF v_valid_from < v_empaneled_date THEN
          RAISE_APPLICATION_ERROR(-20508,' Rule start date should not earlier to the empanel date of the Insurance Company');
        END IF;

      END IF;
      IF (v_valid_from <= v_max_valid_from) THEN
        RAISE_APPLICATION_ERROR(-20301, 'Already rule exist for this date');
      END IF;
      -- Setting the valid_to date previous rule
      OPEN rule_seq_cur;
      FETCH rule_seq_cur INTO v_max_prd_policy_rule_seq_id;
      CLOSE rule_seq_cur;

      UPDATE tpa_ins_prod_policy_rules
         SET valid_to = v_valid_from - 1
       WHERE prod_policy_rule_seq_id = v_max_prd_policy_rule_seq_id;

      -- Inserting the new rule
      INSERT INTO tpa_ins_prod_policy_rules(prod_policy_rule_seq_id, prod_policy_seq_id,
         prod_policy_rule,valid_from,added_by,added_date)
      VALUES
        (ins_prod_policy_rules_seq.NEXTVAL, v_id,v_prod_policy_rule_wsp,v_valid_from,v_added_by, SYSDATE)
      RETURNING prod_policy_rule_seq_id INTO v_id;
     Prod_Policy_Rules_Extract_Pkg.extract_rules_to_table(v_id,v_prod_policy_rule_wsp);
    ELSIF v_flag = 'R' THEN
    
    --Capturing Rule xml log for every modification
     
     OPEN Get_Rule_Config_Xml;
        FETCH Get_Rule_Config_Xml INTO v_prod_policy_rule_old;
          CLOSE Get_Rule_Config_Xml;
          
    INSERT INTO APP.POLICY_RULES_XML_LOGS 
    (V_LOG_SEQ_ID,V_PROD_POL_RULE_SEQ_ID,V_OLD_RULE_XML,V_NEW_RULE_XML,UPDATED_BY,UPDATED_DATE)
    VALUES
    (APP.PRD_POL_LOGS_SEQ_ID.NEXTVAL ,v_id,v_prod_policy_rule_old , v_prod_policy_rule_wsp,v_added_by,SYSDATE );
      
     -- Rule ( product or policy level updation )
      UPDATE tpa_ins_prod_policy_rules
         SET prod_policy_rule = v_prod_policy_rule_wsp,
             updated_by       = v_added_by,
             updated_date     = SYSDATE
       WHERE prod_policy_rule_seq_id = v_id;
       
    Prod_Policy_Rules_Extract_Pkg.extract_rules_to_table(v_id,v_prod_policy_rule_wsp);

    ELSIF (v_flag = 'G') THEN -- Family Rule

      SELECT COUNT(1) INTO v_count FROM tpa_enr_policy_group_rule
       WHERE policy_group_seq_id = v_id;

      IF (v_count = 0) THEN
        INSERT INTO tpa_enr_policy_group_rule (policy_group_seq_id, group_rule, added_by, added_date)
        VALUES (v_id, v_prod_policy_rule_wsp, v_added_by, SYSDATE);
      ELSE
        UPDATE tpa_enr_policy_group_rule
           SET group_rule   = v_prod_policy_rule_wsp,
               updated_by   = v_added_by,
               updated_date = SYSDATE
         WHERE policy_group_seq_id = v_id;
      END IF;
    ELSIF (v_flag = 'M') THEN
      -- Member Rule
      SELECT COUNT(1) INTO v_count FROM tpa_enr_member_rule
       WHERE member_seq_id = v_id;
      IF (v_count = 0) THEN
        INSERT INTO tpa_enr_member_rule (member_seq_id, member_rule, added_by, added_date)
        VALUES (v_id, v_prod_policy_rule_wsp, v_added_by, SYSDATE);
      ELSE
        UPDATE tpa_enr_member_rule
           SET member_rule  = v_prod_policy_rule_wsp,
               updated_by   = v_added_by,
               updated_date = SYSDATE
         WHERE member_seq_id = v_id;
      END IF;
      -- PI  called  Preauth Initiate check
      -- PU  called from Preauth Continue button press from rules.
      -- PRM called from update_remarks button press from rules  KOC1099 RULE_DATA_REMARKS
      -- CI  called from Claim Initiate check
      -- CU  called from Claim Continue Button Press from rules
      -- CRM called from update_remarks button press from rules KOC1099 RULE_DATA_REMARKS

    ELSIF v_flag IN ('PI', 'PU') THEN
      -- New preauth Rule
    ---//  prod_policy_rulebm := pr_autoselect_matprm('P',v_id, prod_policy_rulem);
      UPDATE rule_data
         SET rule_data    = v_prod_policy_rule_wsp,
             updated_by   = v_added_by,
             updated_date = SYSDATE
       WHERE rule_data_seq_id = v_id
      RETURNING pat_gen_detail_seq_id INTO v_id;
      -----------------------------------------------FOR KOC1099 RULE_DATA_REMARKS
      IF v_flag = 'PI' THEN
        v_execution_flag := 2;
      END IF;

      UPDATE pat_general_details a
      SET a.rule_execution_flag = v_execution_flag
      WHERE a.pat_gen_detail_seq_id = v_id
      RETURNING completed_yn INTO v_completed_yn;

     IF v_completed_yn = 'Y' THEN
        RAISE_APPLICATION_ERROR(-20107,' You cannot modify this Pre-Auth/Claim , Reviews are Completed');
      END IF;

    ELSIF V_FLAG in( 'PRM','PM') THEN  --FOR KOC1099 RULE_DATA_REMARKS
      v_execution_flag := 2;
    ---//  prod_policy_rulebm := pr_autoselect_matprm('P',v_id, prod_policy_rulem);
      UPDATE rule_data
         SET rule_data    = v_prod_policy_rule_wsp,
             updated_by   = v_added_by,
             updated_date = sysdate,
             over_ride_yn = v_ovride_yn
       WHERE rule_data_seq_id = v_id
      RETURNING pat_gen_detail_seq_id INTO v_id;
      -----------------------------------------------FOR KOC1099 RULE_DATA_REMARKS
      IF v_flag = 'PI' THEN
        v_execution_flag := 2;
      END IF;

      UPDATE pat_general_details a
      SET a.rule_execution_flag = v_execution_flag
      WHERE a.pat_gen_detail_seq_id = v_id
      RETURNING completed_yn INTO v_completed_yn;

      IF v_completed_yn = 'Y' THEN
        RAISE_APPLICATION_ERROR(-20107,' You cannot modify this Pre-Auth/Claim , Reviews are Completed');
      END IF;
  -----------------------------------------------------------------------------------------
    ELSIF v_flag IN ('CI', 'CU') THEN     -- New Claim Rule
  ---///   prod_policy_rulebm := pr_autoselect_matprm('C',v_id, prod_policy_rulem);
      UPDATE rule_data
         SET rule_data    = v_prod_policy_rule_wsp,
             updated_by   = v_added_by,
             updated_date = SYSDATE
       WHERE rule_data_seq_id = v_id
      RETURNING claim_seq_id INTO v_id;
  ---------------------------------------------------------------------
       IF v_flag = 'CI' THEN
         v_execution_flag := 2;
      END IF;

      UPDATE clm_general_details a
      SET a.rule_execution_flag = v_execution_flag
      WHERE a.claim_seq_id = v_id
      RETURNING completed_yn INTO v_completed_yn;

      IF v_completed_yn = 'Y' THEN
        RAISE_APPLICATION_ERROR(-20107,' You cannot modify this Pre-Auth/Claim , Reviews are Completed');
      END IF;
 ------------------------------------------------------------------------
    ELSIF V_FLAG in( 'CRM','CM') THEN     --FOR KOC1099 RULE_DATA_REMARKS
     v_execution_flag := 2;
    ---// prod_policy_rulebm := pr_autoselect_matprm('C',v_id, prod_policy_rulem);
      UPDATE rule_data
         SET rule_data    = v_prod_policy_rule_wsp,
             updated_by   = v_added_by,
             updated_date = sysdate,
             over_ride_yn = v_ovride_yn
       WHERE rule_data_seq_id = v_id
             RETURNING claim_seq_id INTO v_id;
   --------------------------------------------------------------------------------
      IF v_flag = 'CI' THEN
        v_execution_flag := 2;
      END IF;

      UPDATE clm_general_details a
      SET a.rule_execution_flag = v_execution_flag
      WHERE a.claim_seq_id = v_id
      RETURNING completed_yn INTO v_completed_yn;

      IF v_completed_yn = 'Y' THEN
        RAISE_APPLICATION_ERROR(-20107,' You cannot modify this Pre-Auth/Claim , Reviews are Completed');
    END IF;
    END IF;
    COMMIT;
  END save_prod_policy_rules;
--===============================================================================================
--    PROCEDURE select_prod_policy_rules
--===============================================================================================
  PROCEDURE select_prod_policy_rules (
    v_id           IN  NUMBER,
    v_flag         CHAR, -- 'P' product_policy_seq_id -- 'R' rule_seq_id -- E policy_seq_id
    result_set     OUT SYS_REFCURSOR
  )IS

    CURSOR policy_group_rule_cur IS
      SELECT B.prod_policy_seq_id, C.prod_policy_rule_seq_id
        FROM tpa_enr_policy_group A JOIN tpa_ins_prod_policy B ON (a.policy_seq_id = b.policy_seq_id)
        JOIN tpa_ins_prod_policy_rules c ON (b.prod_policy_seq_id = c.prod_policy_seq_id)
        WHERE a.policy_group_seq_id = v_id;

    CURSOR prod_group_rule_cur IS
      SELECT C.prod_policy_seq_id, D.prod_policy_rule_seq_id
        FROM tpa_enr_policy_group A JOIN tpa_enr_policy B ON ( a.policy_seq_id = b.policy_seq_id )
        JOIN tpa_ins_prod_policy C ON ( B.product_seq_id = C.product_seq_id )
        JOIN tpa_ins_prod_policy_rules D ON ( C.prod_policy_seq_id = D.prod_policy_seq_id)
        WHERE a.policy_group_seq_id = v_id
        AND D.VALID_FROM <= B.Effective_From_Date AND
          (  D.VALID_TO >= B.Effective_From_Date  OR   D.valid_to IS NULL );


    CURSOR policy_mem_rule_cur IS
      SELECT C.prod_policy_seq_id, D.prod_policy_rule_seq_id
        FROM tpa_enr_policy_member A JOIN tpa_enr_policy_group B ON ( a.policy_group_seq_id = b.policy_group_seq_id )
        JOIN tpa_ins_prod_policy C ON (B.policy_seq_id = C.policy_seq_id)
        JOIN tpa_ins_prod_policy_rules D ON ( C.prod_policy_seq_id = D.prod_policy_seq_id )
        WHERE a.member_seq_id = v_id;


    CURSOR prod_mem_rule_cur IS
      SELECT D.prod_policy_seq_id, E.prod_policy_rule_seq_id
        FROM tpa_enr_policy_member A JOIN tpa_enr_policy_group B ON ( a.policy_group_seq_id = b.policy_group_seq_id )
        JOIN tpa_enr_policy C ON ( b.policy_seq_id = C.policy_seq_id )
        JOIN tpa_ins_prod_policy D ON ( C.Product_Seq_Id = D.Product_Seq_Id )
        JOIN tpa_ins_prod_policy_rules E ON ( D.prod_policy_seq_id = E.prod_policy_seq_id )
        WHERE a.member_seq_id = v_id
        AND E.VALID_FROM <= C.Effective_From_Date AND
          (  E.VALID_TO >= C.Effective_From_Date  OR   E.valid_to IS NULL );


    rule_rec             policy_group_rule_cur%ROWTYPE;
    v_count              NUMBER(1);
  BEGIN
    IF v_flag = 'R' THEN -- Product Rule
      OPEN result_set FOR
        SELECT  A.prod_policy_rule_seq_id,  A.prod_policy_seq_id,  A.prod_policy_rule,  A.valid_from, A.valid_to
          FROM tpa_ins_prod_policy_rules A
         WHERE prod_policy_rule_seq_id = v_id;

    ELSIF v_flag = 'P' THEN -- Policy Rule
      OPEN result_set FOR
        SELECT  A.prod_policy_rule_seq_id, A.prod_policy_seq_id,  A.prod_policy_rule,  A.valid_from, A.valid_to
          FROM tpa_ins_prod_policy_rules A
         WHERE A.prod_policy_seq_id =  v_id ;

    ELSIF v_flag = 'M' THEN

      SELECT COUNT(1) INTO v_count
        FROM tpa_enr_member_rule a WHERE a.member_seq_id = v_id;

      IF v_count > 0 THEN
        OPEN result_set FOR
          SELECT A.member_seq_id AS prod_policy_rule_seq_id,'0' AS prod_policy_seq_id,
                 A.member_rule AS prod_policy_rule , NULL AS valid_from , NULL AS valid_to
             FROM tpa_enr_member_rule A
             WHERE A.member_seq_id = v_id;
      ELSE
        OPEN  policy_mem_rule_cur;
        FETCH policy_mem_rule_cur INTO rule_rec ;
        CLOSE policy_mem_rule_cur;

        IF rule_rec.prod_policy_rule_seq_id IS NULL THEN
          OPEN  prod_mem_rule_cur;
          FETCH prod_mem_rule_cur INTO rule_rec ;
          CLOSE prod_mem_rule_cur;
        END IF;

        OPEN result_set FOR
         SELECT  a.prod_policy_rule_seq_id,  a.prod_policy_seq_id,
               XMLELEMENT("clauses",extract( a.prod_policy_rule,'/clauses/clause[coverage[contains(@module,"M")]]')) AS prod_policy_rule, NULL valid_from, NULL valid_to
           FROM tpa_ins_prod_policy_rules A
          WHERE prod_policy_rule_seq_id = rule_rec.prod_policy_rule_seq_id;

      END IF;

    ELSIF v_flag = 'G' THEN
      SELECT COUNT(1) INTO v_count
        FROM tpa_enr_policy_group_rule a WHERE a.policy_group_seq_id = v_id;

      IF v_count > 0 THEN
        OPEN result_set FOR
          SELECT A.policy_group_seq_id AS prod_policy_rule_seq_id, '0' AS prod_policy_seq_id,
               A.group_rule  AS prod_policy_rule , NULL AS valid_from , NULL AS valid_to
            FROM tpa_enr_policy_group_rule A
            WHERE A.policy_group_seq_id = v_id;
      ELSE
        OPEN  policy_group_rule_cur;
        FETCH policy_group_rule_cur INTO rule_rec ;
        CLOSE policy_group_rule_cur;

        IF rule_rec.prod_policy_rule_seq_id IS NULL THEN
          OPEN  prod_group_rule_cur;
          FETCH prod_group_rule_cur INTO rule_rec ;
          CLOSE prod_group_rule_cur;
        END IF;

        OPEN result_set FOR
         SELECT a.prod_policy_rule_seq_id,  a.prod_policy_seq_id,
               XMLELEMENT("clauses",extract(a.prod_policy_rule,'/clauses/clause[coverage[contains(@module,"E")]]')) AS prod_policy_rule, NULL valid_from, NULL valid_to
           FROM tpa_ins_prod_policy_rules A
          WHERE a.prod_policy_rule_seq_id = rule_rec.prod_policy_rule_seq_id;
      END IF;
    END IF;
  END select_prod_policy_rules;


--===============================================================================================
--    PROCEDURE select_prod_policy_rules
--    This procedure is used to validate validation rules defined in policy or product.
--===============================================================================================

  PROCEDURE select_prod_policy_vaidation (
    v_product_seq_id    IN tpa_ins_product.product_seq_id%TYPE,
    v_ins_seq_id        IN tpa_ins_info.ins_seq_id%TYPE,
    v_policy_number     IN tpa_enr_policy.policy_number%TYPE,
    v_scr_policy_type   IN CHAR, -- 'IP',IG,CP,NC
    v_policy_start_date IN DATE, --- by CSP
    v_valid_from_date   OUT DATE, --- by CSP
    v_valid_to_date     OUT DATE, --- by CSP
    result_set          OUT XMLTYPE
  )IS

  -- ADDED valid from and valid to by CSP
   CURSOR cur_prod_policy(v_policy_number tpa_enr_policy.policy_number%TYPE,v_ins_seq_id tpa_enr_policy.ins_seq_id%TYPE, v_product_seq_id tpa_enr_policy.product_seq_id%TYPE)
       IS
   SELECT B.prod_policy_seq_id,C.prod_policy_rule_seq_id,valid_from, valid_to
     FROM tpa_enr_policy A LEFT OUTER JOIN tpa_ins_prod_policy B ON A.policy_seq_id = B.policy_seq_id
          LEFT OUTER JOIN tpa_ins_prod_policy_rules C ON B.prod_policy_seq_id = C.prod_policy_seq_id
    WHERE A.Policy_Number = v_policy_number AND A.Ins_Seq_Id = v_ins_seq_id AND A.Product_Seq_Id = v_product_seq_id;

   CURSOR cur_prod(v_prod_seq_id tpa_enr_policy.product_seq_id%TYPE) IS
   SELECT A.prod_policy_seq_id,B.prod_policy_rule_seq_id, valid_from, valid_to
     FROM tpa_ins_prod_policy A LEFT OUTER JOIN tpa_ins_prod_policy_rules B ON A.prod_policy_seq_id = B.prod_policy_seq_id
    WHERE A.product_seq_id = v_prod_seq_id
      AND B.VALID_FROM <= v_policy_start_date AND
          ( ( B.VALID_TO >= v_policy_start_date ) OR (  B.valid_to IS NULL )
          );

    rec_prod_policy  cur_prod_policy%ROWTYPE;

  BEGIN
   IF  v_product_seq_id IS NULL OR v_ins_seq_id IS NULL OR v_policy_number IS NULL THEN
     raise_application_error(-20309,' Product Id, Insurance Id and Policy Number cannot be null');
   END IF;

    IF v_scr_policy_type IN ('CP','NC')  THEN
      OPEN cur_prod_policy(v_policy_number,v_ins_seq_id,v_product_seq_id) ;
     FETCH cur_prod_policy INTO rec_prod_policy;
     CLOSE cur_prod_policy;
   ELSIF v_scr_policy_type IN('IP','IG') THEN
      OPEN cur_prod(v_product_seq_id) ;
     FETCH cur_prod INTO rec_prod_policy;
     CLOSE cur_prod;
   END IF;


    IF rec_prod_policy.prod_policy_rule_seq_id IS NULL THEN
      RAISE_APPLICATION_ERROR(-20321,'Rule for product or policy is not defined');
    END IF;

    SELECT  extract(prod_policy_rule,'/clauses/clause[@type="validation"]') AS prod_policy_rule,
           A.valid_from,
           A.valid_to
      INTO result_set,
           v_valid_from_date,
           v_valid_to_date
     FROM tpa_ins_prod_policy_rules A
    WHERE prod_policy_rule_seq_id = rec_prod_policy.prod_policy_rule_seq_id;



   -- p.l(result_set);
--    INSERT INTO TEMP_XML VALUES(result_set);
  --  COMMIT;

  END select_prod_policy_vaidation;

--===============================================================================================
--   PROCEDURE prod_policy_rules_list
--===============================================================================================

  PROCEDURE prod_policy_rules_list (
    v_prod_policy_seq_id      IN  tpa_ins_prod_policy.prod_policy_seq_id%TYPE,
    result_set                OUT SYS_REFCURSOR
  )IS

  BEGIN
    OPEN result_set FOR
       SELECT prod_policy_rule_seq_id,prod_policy_seq_id,valid_from,valid_to
         FROM tpa_ins_prod_policy_rules
        WHERE v_prod_policy_seq_id = prod_policy_seq_id
        ORDER BY prod_policy_rule_seq_id;
  END prod_policy_rules_list;


  PROCEDURE replace_rule_xml(v_first_clause_domlist IN OUT DBMS_XMLDOM.DOMNODELIST,v_node  DBMS_XMLDOM.domnode,v_clause_name VARCHAR,v_flag CHAR)
  IS
   v_elem             DBMS_XMLDOM.DOMElement;
   v_cov_node_lst     DBMS_XMLDOM.domnodelist;
   v_cov_node         DBMS_XMLDOM.domnode;
   v_clause_node      DBMS_XMLDOM.domnode;
   v_con_node_lst         DBMS_XMLDOM.domnodelist;
   v_mast_con_node_lst  DBMS_XMLDOM.domnodelist;
   v_mast_con_node  DBMS_XMLDOM.domnode;
   v_con_node DBMS_XMLDOM.domnode;
   v_temp_node DBMS_XMLDOM.domnode;
   v_cl_name VARCHAR2(100);
   v_cov_name VARCHAR2(100);
   v_cv_name VARCHAR2(100);
   v_con_name  VARCHAR2(100);
   v_mast_con_name  VARCHAR2(100);
   v_allowed_attr VARCHAR2(10);
  BEGIN
   v_elem := DBMS_XMLDOM.makeelement(v_node);

   v_cv_name := DBMS_XMLDOM.getattribute(v_elem,'id');
   v_allowed_attr := DBMS_XMLDOM.getattribute(v_elem,'allowed');

   FOR clause_node_index IN 0 .. DBMS_XMLDOM.getLength(v_first_clause_domlist) -1
    LOOP
      v_clause_node := DBMS_XMLDOM.item (v_first_clause_domlist, clause_node_index);
      v_elem := DBMS_XMLDOM.makeelement(v_clause_node);

      v_cl_name := DBMS_XMLDOM.getattribute(v_elem,'id');
      IF ( v_cl_name = v_clause_name ) THEN


        v_cov_node_lst := DBMS_XMLDOM.getchildnodes (v_clause_node);
        FOR cov_node_index IN 0 .. DBMS_XMLDOM.getLength(v_cov_node_lst) -1
        LOOP
         v_cov_node := DBMS_XMLDOM.item (v_cov_node_lst, cov_node_index);
         IF ( DBMS_XMLDOM.GETNODETYPE(v_cov_node) <> DBMS_XMLDOM.COMMENT_NODE )THEN
           v_elem := DBMS_XMLDOM.makeelement(v_cov_node);

           v_cov_name := DBMS_XMLDOM.getattribute(v_elem,'id');
           IF v_cov_name = v_cv_name THEN
             IF ( NOT (v_flag = 'M' AND DBMS_XMLDOM.getattribute(v_elem,'module')= 'EM' ))  THEN
               DBMS_XMLDOM.setattribute(v_elem,'allowed',v_allowed_attr);
             END IF;

              v_mast_con_node_lst := DBMS_XMLDOM.getchildnodes (v_node);
              FOR mast_con_node_index IN 0 .. DBMS_XMLDOM.getLength(v_mast_con_node_lst) -1
              LOOP
                v_mast_con_node := DBMS_XMLDOM.item (v_mast_con_node_lst, mast_con_node_index);
                IF ( DBMS_XMLDOM.GETNODETYPE(v_mast_con_node) <> DBMS_XMLDOM.COMMENT_NODE )THEN
                  v_elem := DBMS_XMLDOM.makeelement(v_mast_con_node);

                  v_mast_con_name := DBMS_XMLDOM.getattribute(v_elem,'id');
                  v_con_node_lst := DBMS_XMLDOM.getchildnodes (v_cov_node);
                  FOR con_node_index IN 0 .. DBMS_XMLDOM.getLength(v_con_node_lst) -1
                  LOOP
                    v_con_node := DBMS_XMLDOM.item (v_con_node_lst, con_node_index);
                    IF ( DBMS_XMLDOM.GETNODETYPE(v_con_node) <> DBMS_XMLDOM.COMMENT_NODE )THEN
                      v_elem := DBMS_XMLDOM.makeelement(v_con_node);

                      v_con_name := DBMS_XMLDOM.getattribute(v_elem,'id');
                      IF (v_mast_con_name = v_con_name) THEN
                         v_temp_node := DBMS_XMLDOM.replacechild(v_cov_node,v_mast_con_node,v_con_node);
                      END IF;
                    END IF;
                  END LOOP;
                END IF;
              END LOOP;
           END IF;
         END IF;
        END LOOP;
      END IF;
    END LOOP;

  END replace_rule_xml;

--=========================================================================================
--   PROCEDURE combine_rule_xml
--=========================================================================================

  PROCEDURE combine_rule_xml(v_first_xml XMLTYPE,v_sec_xml  XMLTYPE, v_out_xml OUT XMLTYPE,v_flag CHAR)
  IS
    v_sec_doc              DBMS_XMLDOM.DOMDocument;
    v_first_doc        DBMS_XMLDOM.DOMDocument;
    v_clause_domlist   DBMS_XMLDOM.DOMNODELIST;
    v_first_clause_domlist DBMS_XMLDOM.DOMNODELIST;
    v_clause_node      DBMS_XMLDOM.domnode;
    v_cov_node_lst     DBMS_XMLDOM.domnodelist;
    v_cov_node         DBMS_XMLDOM.domnode;
    v_elem             DBMS_XMLDOM.DOMElement;
    v_clause_name      VARCHAR2(100);

  BEGIN
    v_out_xml := v_first_xml;


    v_sec_doc       := DBMS_XMLDOM.newDOMDocument(v_sec_xml);
    v_first_doc     := DBMS_XMLDOM.newDOMDocument(v_first_xml);
    v_clause_domlist := DBMS_XMLDOM.GETELEMENTSBYTAGNAME(v_sec_doc,'clause');
    v_first_clause_domlist := DBMS_XMLDOM.GETELEMENTSBYTAGNAME(v_first_doc,'clause');

    FOR clause_node_index IN 0 .. DBMS_XMLDOM.getLength(v_clause_domlist) -1
    LOOP
      v_clause_node := DBMS_XMLDOM.item (v_clause_domlist, clause_node_index);
      IF ( DBMS_XMLDOM.GETNODETYPE(v_clause_node) <> DBMS_XMLDOM.COMMENT_NODE )THEN
        v_elem := DBMS_XMLDOM.makeelement(v_clause_node);

        v_clause_name := DBMS_XMLDOM.getattribute(v_elem,'id');
        v_cov_node_lst := DBMS_XMLDOM.getchildnodes (v_clause_node);
        FOR cov_node_index IN 0 .. DBMS_XMLDOM.getLength(v_cov_node_lst) -1
        LOOP
          v_cov_node := DBMS_XMLDOM.item (v_cov_node_lst, cov_node_index);
          IF ( DBMS_XMLDOM.GETNODETYPE(v_cov_node) <> DBMS_XMLDOM.COMMENT_NODE )THEN
            v_elem := DBMS_XMLDOM.makeelement(v_cov_node);
            replace_rule_xml(v_first_clause_domlist,v_cov_node ,v_clause_name,v_flag );
          END IF;
        END LOOP;
      END IF;
    END LOOP;
    v_out_xml := DBMS_XMLDOM.GETXMLTYPE(v_first_doc);
    dbms_xmldom.freeDocument( v_first_doc );
    dbms_xmldom.freeDocument( v_sec_doc );
  END combine_rule_xml;

--=========================================================================================
-- PROCEDURE select_pa_claims_rules (
-- Parameter  v_id
-- Parameter v_flag :- IF v_flag is 'PR' vid will be pat_gen_detail_seq_id if rule data is defined returns rule data xml otherwise combined xml
--                     IF v_flag is 'CR' vid will be claim_seq_id if rule data is defined returns rule data xml otherwise combined xml
--                     IF v_flag is 'PC' vid will be pat_gen_detail_seq_id , return combined xml
--                     IF v_flag is 'CC' vid will be claim_seq_id  , return combined xml
--=========================================================================================
  PROCEDURE select_pa_claims_rules (
    v_id           IN  NUMBER,
    v_flag         CHAR,
    result_set     OUT SYS_REFCURSOR
  )
  IS
    CURSOR cur_preauth ( v_pat_gen_detail_seq_id pat_general_details.pat_gen_detail_seq_id%TYPE ) IS
    SELECT A.policy_seq_id, A.member_seq_id, C.rule_data_seq_id, C.rule_data , b.rule_execution_flag , b.completed_yn
      FROM pat_enroll_details A INNER JOIN pat_general_details B  ON A.pat_enroll_detail_seq_id = B.pat_enroll_detail_seq_id
           LEFT OUTER JOIN rule_data C ON B.pat_gen_detail_seq_id = C.pat_gen_detail_seq_id
     WHERE B.pat_gen_detail_seq_id = v_pat_gen_detail_seq_id;

    CURSOR cur_claim ( v_claim_seq_id clm_general_details.claim_seq_id%TYPE) IS
    SELECT A.policy_seq_id,A.member_seq_id,C.rule_data_seq_id,C.rule_data , b.rule_execution_flag , b.completed_yn
      FROM clm_enroll_details A INNER JOIN clm_general_details B  ON A.claim_seq_id = B.claim_seq_id
           LEFT OUTER JOIN rule_data C ON B.claim_seq_id = C.claim_seq_id
     WHERE B.claim_seq_id = v_claim_seq_id;

    CURSOR cur_preauth_policy_rule( v_policy_seq_id tpa_enr_policy.policy_seq_id%TYPE,v_member_seq_id tpa_enr_policy_member.member_seq_id%TYPE)         IS
      SELECT  /*+ optimizer_features_enable('11.2.0.1') */ A.enrol_type_id,A.policy_seq_id,B.prod_policy_seq_id,C.prod_policy_rule_seq_id,
      XMLELEMENT("clauses", extract(C.prod_policy_rule,'/clauses/clause[@type="rule" and contains(@execution,"PRE") ]')) as prod_policy_rule,
      E.member_seq_id, XMLELEMENT("clauses", extract(F.member_rule,'/clauses/clause[@type="rule" and contains(@execution,"PRE") ]')) as member_rule,
      A.product_seq_id,XMLELEMENT("clauses", extract(G.GROUP_RULE,'/clauses/clause[@type="rule" and contains(@execution,"PRE") ]')) as GROUP_RULE
        FROM tpa_enr_policy A LEFT OUTER JOIN tpa_ins_prod_policy B ON ( A.policy_seq_id = B.policy_seq_id )
             LEFT OUTER JOIN tpa_ins_prod_policy_rules C ON ( B.prod_policy_seq_id = C.prod_policy_seq_id )
             LEFT OUTER JOIN tpa_enr_policy_group D ON ( A.policy_seq_id = D.policy_seq_id )
             LEFT OUTER JOIN tpa_enr_policy_group_rule G ON ( D.policy_group_seq_id =  G.policy_group_seq_id )
             LEFT OUTER JOIN tpa_enr_policy_member E ON ( D.policy_group_seq_id = E.policy_group_seq_id )
             LEFT OUTER JOIN tpa_enr_member_rule F ON ( E.member_seq_id = F.member_seq_id )
       WHERE E.member_seq_id = v_member_seq_id;

    CURSOR cur_claim_policy_rule( v_policy_seq_id tpa_enr_policy.policy_seq_id%TYPE,v_member_seq_id tpa_enr_policy_member.member_seq_id%TYPE)         IS
      SELECT  /*+ optimizer_features_enable('11.2.0.1') */ A.enrol_type_id,A.policy_seq_id,B.prod_policy_seq_id,C.prod_policy_rule_seq_id,
      XMLELEMENT("clauses", extract(C.prod_policy_rule,'/clauses/clause[@type="rule" and contains(@execution,"CLA") ]')) as prod_policy_rule,
      E.member_seq_id, XMLELEMENT("clauses", extract(F.member_rule,'/clauses/clause[@type="rule" and contains(@execution,"CLA") ]')) as member_rule,
      A.product_seq_id,XMLELEMENT("clauses", extract(G.GROUP_RULE,'/clauses/clause[@type="rule" and contains(@execution,"CLA") ]')) as GROUP_RULE
        FROM tpa_enr_policy A LEFT OUTER JOIN tpa_ins_prod_policy B ON ( A.policy_seq_id = B.policy_seq_id )
             LEFT OUTER JOIN tpa_ins_prod_policy_rules C ON ( B.prod_policy_seq_id = C.prod_policy_seq_id )
             LEFT OUTER JOIN tpa_enr_policy_group D ON ( A.policy_seq_id = D.policy_seq_id )
             LEFT OUTER JOIN tpa_enr_policy_group_rule G ON ( D.policy_group_seq_id =  G.policy_group_seq_id )
             LEFT OUTER JOIN tpa_enr_policy_member E ON ( D.policy_group_seq_id = E.policy_group_seq_id )
             LEFT OUTER JOIN tpa_enr_member_rule F ON ( E.member_seq_id = F.member_seq_id )
       WHERE E.member_seq_id = v_member_seq_id;

  CURSOR cur_preauth_prod_rule(v_policy_seq_id tpa_enr_policy.policy_seq_id%TYPE) IS
   SELECT  /*+ optimizer_features_enable('11.2.0.1') */ B.prod_policy_seq_id,C.prod_policy_rule_seq_id,
   XMLELEMENT("clauses", extract(C.prod_policy_rule,'/clauses/clause[@type="rule" and contains(@execution,"PRE") ]')) as prod_policy_rule
     FROM tpa_enr_policy A LEFT OUTER JOIN tpa_ins_prod_policy B ON  A.Product_Seq_Id = B.Product_Seq_Id
          LEFT OUTER JOIN tpa_ins_prod_policy_rules C ON B.prod_policy_seq_id = C.prod_policy_seq_id
    WHERE A.policy_seq_id = v_policy_seq_id
      AND C.VALID_FROM <= A.effective_from_date  AND
          (( C.VALID_TO >= A.effective_from_date ) OR (C.valid_to IS NULL ));

  CURSOR cur_claim_prod_rule(v_policy_seq_id tpa_enr_policy.policy_seq_id%TYPE) IS
   SELECT  /*+ optimizer_features_enable('11.2.0.1') */ B.prod_policy_seq_id,C.prod_policy_rule_seq_id,
   XMLELEMENT("clauses", extract(C.prod_policy_rule,'/clauses/clause[@type="rule" and contains(@execution,"CLA") ]')) as prod_policy_rule
     FROM tpa_enr_policy A LEFT OUTER JOIN tpa_ins_prod_policy B ON  A.Product_Seq_Id = B.Product_Seq_Id
          LEFT OUTER JOIN tpa_ins_prod_policy_rules C ON B.prod_policy_seq_id = C.prod_policy_seq_id
    WHERE A.policy_seq_id = v_policy_seq_id
      AND C.VALID_FROM <= A.effective_from_date  AND
          (( C.VALID_TO >= A.effective_from_date ) OR (C.valid_to IS NULL ));

    rec_mem         cur_preauth%ROWTYPE;
    rec_prod_rule   cur_preauth_prod_rule%ROWTYPE;
    rec_policy_rule cur_preauth_policy_rule%ROWTYPE;
    v_merge_xml     XMLTYPE;

  BEGIN

    IF v_flag IN('PR', 'PF') THEN
      OPEN cur_preauth( v_id );
      FETCH cur_preauth INTO rec_mem ;
      CLOSE cur_preauth;
    ELSIF v_flag IN('CR','CF') THEN
       OPEN cur_claim( v_id );
      FETCH cur_claim INTO rec_mem ;
      CLOSE cur_claim;
    END IF;

    IF(rec_mem.rule_data_seq_id IS NULL )THEN
      IF ( rec_mem.member_seq_id IS NULL AND substr(v_flag,1,1) = 'P' ) THEN
        RAISE_APPLICATION_ERROR(-20303,' Manual Preauth policy does not exist ');
      END IF;
      IF ( rec_mem.member_seq_id IS NULL AND substr(v_flag,1,1) = 'C' ) THEN
        RAISE_APPLICATION_ERROR(-20304,' Manual Claim policy does not exist ');
      END IF;
    ELSE
      IF rec_mem.rule_execution_flag IS NOT NULL AND v_flag NOT IN ('PF','CF') THEN -- means rule data is not modifed and there in the table
        OPEN result_set FOR
          SELECT rule_data_seq_id AS rule_data_seq_id , rule_data AS rule , rec_mem.rule_execution_flag AS rule_execution_flag
            FROM rule_data
           WHERE rule_data_seq_id = rec_mem.rule_data_seq_id;
           RETURN;
      END IF;
    END IF;

    IF substr(v_flag,1,1) = 'P' THEN
      OPEN cur_preauth_policy_rule(rec_mem.policy_seq_id,rec_mem.member_seq_id);
      FETCH cur_preauth_policy_rule INTO rec_policy_rule;
      CLOSE cur_preauth_policy_rule;

      IF rec_policy_rule.enrol_type_id <> 'COR'   THEN
        OPEN cur_preauth_prod_rule(rec_policy_rule.policy_seq_id);
        FETCH cur_preauth_prod_rule INTO rec_prod_rule;
        CLOSE cur_preauth_prod_rule;
        rec_policy_rule.prod_policy_rule := rec_prod_rule.prod_policy_rule;
      END IF;
    ELSE
      OPEN cur_claim_policy_rule(rec_mem.policy_seq_id,rec_mem.member_seq_id);
      FETCH cur_claim_policy_rule INTO rec_policy_rule;
      CLOSE cur_claim_policy_rule;

      IF rec_policy_rule.enrol_type_id <> 'COR'   THEN
        OPEN cur_claim_prod_rule(rec_policy_rule.policy_seq_id);
        FETCH cur_claim_prod_rule INTO rec_prod_rule;
        CLOSE cur_claim_prod_rule;
        rec_policy_rule.prod_policy_rule := rec_prod_rule.prod_policy_rule;
      END IF;
    END IF;

    IF ( rec_policy_rule.enrol_type_id <> 'COR' AND rec_prod_rule.prod_policy_rule_seq_id IS NULL) OR ( rec_policy_rule.enrol_type_id = 'COR' AND rec_policy_rule.prod_policy_rule_seq_id IS NULL ) THEN
      RAISE_APPLICATION_ERROR(-20302,' Rule is not defined ');
    END IF;

    IF rec_mem.completed_yn = 'Y' THEN
      RAISE_APPLICATION_ERROR(-20107,' You cannot modify this Pre-Auth , Reviews are Completed');
    END IF;

    IF rec_policy_rule.group_rule IS NOT NULL THEN
      combine_rule_xml(rec_policy_rule.prod_policy_rule,rec_policy_rule.group_rule,v_merge_xml,'P' );
    ELSE
      v_merge_xml := rec_policy_rule.prod_policy_rule;
    END IF;
    IF rec_policy_rule.member_rule IS NOT NULL THEN
      combine_rule_xml(v_merge_xml,rec_policy_rule.member_rule, v_merge_xml,'M' );
    END IF;
    -- Setting all the values required for autoselection to RECORD VARIABLES.
    rule_field_data_pkg.set_pa_details(SUBSTR(v_flag,1,1) , v_id, rec_mem.member_seq_id );
    -- Setting autoselected yes/no to XML
    pr_auto_select (v_merge_xml);

	--optinal_copay
     for rec in (select  /*+ optimizer_features_enable('11.2.0.1') */ pr.co_pay from tpa_enr_cigna_policy pr where pr.policy_seq_id = rec_policy_rule.policy_seq_id)
      loop
        select  /*+ optimizer_features_enable('11.2.0.1') */ UPDATEXML(v_merge_xml,'/clauses/clause/coverage/condition [@id="cnd.25.1.1"]/@dynValue',
        'get_copayment_limit(null,'||rec.co_pay||',''AA'',''LL'',null)') into v_merge_xml
         from dual;
          end loop;
   --optinal_copay

    -- If the record already exist with discarded rule data.
    IF rec_mem.rule_data_seq_id IS NOT NULL THEN
        UPDATE rule_data a
           SET rule_data = v_merge_xml,
               updated_date = SYSDATE
        WHERE  rule_data_seq_id = rec_mem.rule_data_seq_id ;
    END IF;

    IF v_flag IN ('PR','PF') THEN
      IF rec_mem.rule_data_seq_id IS NULL THEN
        INSERT INTO rule_data(rule_data_seq_id, pat_gen_detail_seq_id, rule_data, added_by, added_date)
          VALUES(rule_data_seq.NEXTVAL, v_id, v_merge_xml, 1, SYSDATE) RETURNING rule_data_seq_id INTO rec_mem.rule_data_seq_id;
      END IF;
      UPDATE pat_general_details a SET
        a.rule_execution_flag = 0
        WHERE a.pat_gen_detail_seq_id = v_id;
    ELSIF v_flag IN ('CR','CF') THEN
      IF rec_mem.rule_data_seq_id IS NULL THEN
        INSERT INTO rule_data(rule_data_seq_id, claim_seq_id , rule_data, added_by, added_date)
          VALUES(rule_data_seq.NEXTVAL, v_id, v_merge_xml, 1, SYSDATE) RETURNING rule_data_seq_id INTO rec_mem.rule_data_seq_id;
      END IF;
      UPDATE clm_general_details a SET
        a.rule_execution_flag = 0
        WHERE a.claim_seq_id = v_id;
    END IF;
    COMMIT;


   OPEN result_set FOR
        SELECT a.rule_data_seq_id , rule_data AS rule , 0 AS rule_execution_flag FROM rule_data a
          WHERE a.rule_data_seq_id = rec_mem.rule_data_seq_id ;

  END select_pa_claims_rules;
  --======================================================================================================
  --comments by Ravi to disable check boxes for copay calculations for future use
  --======================================================================================================
  PROCEDURE pr_auto_select(  v_merge_xml IN OUT XMLTYPE)
  IS
    v_doc              DBMS_XMLDOM.DOMDocument;
    v_elem             DBMS_XMLDOM.DOMElement;
    v_clause_domlist   DBMS_XMLDOM.DOMNODELIST;
    v_clause_node      DBMS_XMLDOM.domnode;
    v_cov_node         DBMS_XMLDOM.domnode;
    v_cov_node_lst     DBMS_XMLDOM.domnodelist;
    v_func_name        VARCHAR2 (2000);
    v_func_value       VARCHAR2 (100);
    v_cls_id           VARCHAR2 (20);

  BEGIN

    v_doc     := DBMS_XMLDOM.newDOMDocument(v_merge_xml);
    v_clause_domlist := DBMS_XMLDOM.getelementsbytagname(v_doc,'clause');

    FOR clause_node_index IN 0 .. DBMS_XMLDOM.getLength(v_clause_domlist) -1
    LOOP
      v_clause_node := DBMS_XMLDOM.item (v_clause_domlist, clause_node_index);
      IF ( DBMS_XMLDOM.GETNODETYPE(v_clause_node) <> DBMS_XMLDOM.COMMENT_NODE )THEN
         v_elem := DBMS_XMLDOM.makeelement(v_clause_node);
         v_cls_id := DBMS_XMLDOM.getAttribute(v_elem,'id'); --Ravi 22jan
         IF v_cls_id in ('cls.25','cls.32') THEN---Ravi 22jan13
                 DBMS_XMLDOM.setattribute(v_elem,'disabled','true');
         END IF;
         v_cov_node_lst := DBMS_XMLDOM.getchildnodes (v_clause_node);
         FOR cov_node_index IN 0 .. DBMS_XMLDOM.getLength(v_cov_node_lst) -1
         LOOP
            v_cov_node := DBMS_XMLDOM.item (v_cov_node_lst, cov_node_index);
            IF ( DBMS_XMLDOM.GETNODETYPE(v_cov_node) <> DBMS_XMLDOM.COMMENT_NODE )THEN
              v_elem := DBMS_XMLDOM.makeelement(v_cov_node);
              v_func_name := DBMS_XMLDOM.getattribute(v_elem,'autoselect');
              v_func_name := REPLACE( REPLACE( REPLACE( v_func_name,'(,','(NULL,' ) ,',)', ',NULL)' ) , ',,',',NULL,' ) ;
              IF v_func_name IS NOT NULL THEN
                 v_func_value :=  exec_field_fun(v_func_name);
                 DBMS_XMLDOM.setattribute(v_elem,'selected',v_func_value);
              END IF;
            END IF;
         END LOOP;
      END IF;
    END LOOP;
    v_merge_xml := dbms_xmldom.getxmltype( v_doc );
    dbms_xmldom.freeDocument( v_doc );
  END pr_auto_select;
  --======================================================================================================
  FUNCTION exec_field_fun( v_fn_name VARCHAR2)
  RETURN VARCHAR
  IS
     v_res     NUMBER;
  BEGIN
    EXECUTE IMMEDIATE ' BEGIN :res := rule_field_data_pkg.'||v_fn_name||'; END;' USING OUT v_res;
    IF v_res = 1 THEN
      RETURN 'YES';
    ELSE
      RETURN 'NO';
    END IF;
  END exec_field_fun;
  --=====================================================================================================
  -- v_type -- P -preauth C -- for claim


  ----====================================================================================================
  -- PROCEDURE PR_RULE_XML_VALIDATION
  -- Author: ravi for KOC1099
    -- CREATED ON 18-JAN-2012
  -- PURPOSE FOR CHECKING WHETHER THE RULE_REMARKS ARE NOT WHEN CONFIDENCE FACTOR IS ZERO
  ----=================================================================================================
  PROCEDURE pr_rule_xml_validation(V_ID in NUMBER,v_type in varchar2) IS
    doc           xmldom.DOMDocument;
    v_elem        xmldom.DOMElement;
    v_dom_list    DBMS_XMLDOM.DOMNODELIST;
    v_clause_node DBMS_XMLDOM.domnode;
    clause        varchar2(250byte);
    v_cov_list    DBMS_XMLDOM.domnodelist;
    v_cov_node    DBMS_XMLDOM.DOMNode;
    covrge        varchar2(250byte);
    v_rem_node    DBMS_XMLDOM.DOMNode;
    remrk         varchar2(250byte);
    remrk_id      varchar2(250byte);
    rse_error     varchar2(250byte);
    -- V_COUNT       NUMBER(5):=0;
   -----------------------------------------------------
   /* type temp is table of varchar2(500) index by BINARY_INTEGER;
    err_tab temp;
    i binary_integer :=0; */
  ----------------------------------------------------------
      cursor cur_pat_clm is

      select extract(rule_data, '/clauses/clause') as rule_2 --,rule_data,over_ride_yn
      from rule_data
      where pat_gen_detail_seq_id = v_id ; --'1054781' or '635103';

      cursor cur_clm_pat is
      select extract(rule_data, '/clauses/clause') as rule_2 --,rule_data,over_ride_yn
      from rule_data
      where claim_seq_id=v_id;

    curr cur_pat_clm%rowtype;
    begin
        if v_type='P' then
         open cur_pat_clm;
         fetch cur_pat_clm into curr;
         --if cur_pat_clm%found and curr.rule_2 is not null then
         close cur_pat_clm;
        else
         open cur_clm_pat;
         fetch cur_clm_pat into curr;
         --if cur_pat_clm%found and curr.rule_2 is not null then
         close cur_clm_pat;
       end if;

        doc        := xmldom.newDOMDocument(curr.rule_2);
        v_dom_list := dbms_xmldom.getElementsByTagName(doc, 'clause');

      -- main_node := xmldom.makeNode(doc);

        FOR rule_rec IN 0 .. dbms_xmldom.getlength(v_dom_list) - 1 LOOP
        v_clause_node := DBMS_XMLDOM.item(v_dom_list, rule_rec);
        v_elem        := dbms_xmldom.makeelement(v_clause_node);
        clause        := dbms_xmldom.getAttribute(v_elem, 'name');
        IF clause not in
     ----('Day care procedures','Important Notes','Global', 'Individual Account head limits','Copayment per Claim')
             ('Global','Copayment per Claim','Day care procedures','Important Notes')--,'Individual Account head limits')
       THEN
        v_cov_list := dbms_xmldom.getChildNodes(v_clause_node);
        for cov_rec in 0 .. dbms_xmldom.getlength(v_cov_list) - 1
        loop
        v_cov_node := dbms_xmldom.item(v_cov_list, cov_rec);
        v_elem     := dbms_xmldom.makeelement(v_cov_node);
        covrge     := dbms_xmldom.getattribute(v_elem, 'clpercentage');

        for rem_rec in 0 .. dbms_xmldom.getlength(v_cov_list) - 1
        loop
        v_rem_node := dbms_xmldom.item(v_cov_list, rem_rec);

        IF (DBMS_XMLDOM.GETNODETYPE(v_rem_node) <> DBMS_XMLDOM.COMMENT_NODE) THEN
        v_elem   := dbms_xmldom.makeelement(v_rem_node);
        remrk_id := dbms_xmldom.getattribute(v_elem, 'id');

        if substr(remrk_id, 1, 3) = 'rmk' then
        remrk := dbms_xmldom.getattribute(v_elem, 'value');

        if covrge < 100 and remrk = '~' then
        rse_error := clause;
        -------------------------
        /* i := i+1;
         err_tab(i):=rse_error;*/
        -------------------------------
        if rse_error is not null and v_type='P' then
        update rule_data set over_ride_yn = 'N'
        where pat_gen_detail_seq_id= v_id ;
        else
        update rule_data set over_ride_yn = 'N'
        where  claim_seq_id=v_id;

        commit;

        return;

        end if;
        end if;
        end if;
        end if;

        end loop;
        end loop;
        end if;
        end loop;
      -- DBMS_OUTPUT.PUT_LINE(NVL(rse_error,'ABC'));
        if nvl(rse_error, 'NA') = 'NA' and v_type='P' then
        update rule_data set over_ride_yn='Y'
        where pat_gen_detail_seq_id=v_id ;
        else
        update rule_data set over_ride_yn='Y'
        where  claim_seq_id=v_id;

        commit;
        end if;
     --- dbms_output.put_line(sql%rowcount);
    --end if;
    exception when others then
      return;

    end pr_rule_xml_validation;
 --============================================================================================
  --procedure pr_whitespc_mat_prm for removing white spaces in xmlfile generating from front end
  -- created on 5-mar-12
  -- koc1062 for the maternity rules calculation
  --created for koc1062 by ravi
  --=============================================================================================
   PROCEDURE pr_whitespc_matprm(v_rule_xml IN OUT XMLTYPE) is
   parser_        xmlparser.parser;
   doc            xmldom.DOMDocument;
   v_elem         xmldom.DOMElement;
   v_dom_list     DBMS_XMLDOM.DOMNODELIST;
   v_clause_node  DBMS_XMLDOM.domnode;
   v_cov_list     DBMS_XMLDOM.domnodelist;
   v_cov_node     DBMS_XMLDOM.DOMNode;
   v_cond_list    DBMS_XMLDOM.domnodelist;
   v_cond_node    DBMS_XMLDOM.DOMNode;
   v_allowed      varchar2(250byte);
   v_selected     varchar2(250byte);
   v_attrval      varchar2(1000byte);
   v_field_name   varchar2(1000byte);
   v_id           varchar2(250byte);
   v_method       varchar2(1000byte);
   v_dyn_val      varchar2(4000);
   v_unit         varchar2(10byte);

  begin

   parser_ := xmlparser.newparser;
   xmlparser.setpreservewhitespace(parser_, false);

   doc := DBMS_XMLDOM.newDOMDocument(v_rule_xml);
   v_dom_list := DBMS_XMLDOM.getelementsbytagname(doc,'clause');

  FOR clause_node_index IN 0 .. DBMS_XMLDOM.getLength(v_dom_list) -1 LOOP

          v_clause_node := DBMS_XMLDOM.item (v_dom_list, clause_node_index);
          IF ( DBMS_XMLDOM.GETNODETYPE(v_clause_node) <> DBMS_XMLDOM.COMMENT_NODE )THEN
          v_elem := DBMS_XMLDOM.makeelement(v_clause_node);
          v_cov_list := DBMS_XMLDOM.getchildnodes (v_clause_node);

          FOR cov_node_index IN 0 .. DBMS_XMLDOM.getLength(v_cov_list) -1 LOOP

          v_cov_node := DBMS_XMLDOM.item (v_cov_list, cov_node_index);
          IF ( DBMS_XMLDOM.GETNODETYPE(v_cov_node) <> DBMS_XMLDOM.COMMENT_NODE )THEN
          v_elem :=     DBMS_XMLDOM.makeelement(v_cov_node);
          v_allowed :=  DBMS_XMLDOM.getattribute(v_elem,'allowed');
          v_selected := DBMS_XMLDOM.getattribute(v_elem,'selected');
          v_attrval :=  DBMS_XMLDOM.getattribute(v_elem,'name');

         /* IF DBMS_XMLDOM.getattribute(v_elem,'id') in ('cvg.8.1','cvg.8.2','cvg.8.3') then -- Enable for Maternity
              dbms_xmldom.setattribute(v_elem,'autoselect','get_mat_stats(''MAT'')');
          END IF;*/


          v_cond_list := DBMS_XMLDOM.getchildnodes (v_cov_node);
          FOR con_node_index IN 0 .. DBMS_XMLDOM.getLength(v_cond_list) -1
          LOOP
          v_cond_node := DBMS_XMLDOM.item (v_cond_list, con_node_index);
          IF ( DBMS_XMLDOM.GETNODETYPE(v_cond_node) <> DBMS_XMLDOM.COMMENT_NODE )THEN
          v_elem := DBMS_XMLDOM.makeelement(v_cond_node);

          v_field_name := DBMS_XMLDOM.getattribute(v_elem,'field') ;
          v_id :=      DBMS_XMLDOM.getattribute(v_elem,'id');
          v_method :=  DBMS_XMLDOM.getAttribute(v_elem,'method');
          v_dyn_val := DBMS_XMLDOM.getattribute(v_elem,'dynValue');
          v_unit :=    DBMS_XMLDOM.getattribute(v_elem,'unit');


        /* IF v_field_name ='member.children' -- Enable for Maternity
            THEN  DBMS_XMLDOM.setattribute(v_elem,'method','get_csnb_value(''MC'')');
            DBMS_XMLDOM.setattribute(v_elem,'source','PACKAGE');
            ELSIF v_field_name ='member.surgeries'
            THEN  DBMS_XMLDOM.setattribute(v_elem,'method','get_csnb_value(''MS'')');
            DBMS_XMLDOM.setattribute(v_elem,'source','PACKAGE');
            ELSIF v_field_name ='member.newbornperiod'
            THEN  DBMS_XMLDOM.setattribute(v_elem,'method','get_csnb_value(''MNB'')');
            DBMS_XMLDOM.setattribute(v_elem,'source','PACKAGE');

            END IF; */
            DBMS_XMLDOM.setattribute(v_elem,'method',  replace(v_method,'~','null'));
            DBMS_XMLDOM.setattribute(v_elem,'dynValue',replace(v_dyn_val,'~','null'));

          END IF;
          END LOOP;
          END IF;
          END LOOP;
          END IF;
          END LOOP;

          v_rule_xml :=DBMS_XMLDOM.getxmltype(doc);
          DBMS_XMLDOM.freeDocument(doc);
          END pr_whitespc_matprm;

 --============================================================================================
--koc 1179
PROCEDURE pr_wsp_shortfall(v_ip_xml IN OUT rule_data.rule_data%TYPE) IS

   parser_        xmlparser.parser;
   doc            xmldom.DOMDocument;
   v_elem         xmldom.DOMElement;
   v_dom_list     DBMS_XMLDOM.DOMNODELIST;
   v_clause_node  DBMS_XMLDOM.domnode;
   v_cov_list     DBMS_XMLDOM.domnodelist;
   v_cov_node     DBMS_XMLDOM.DOMNode;
   v_field_name   VARCHAR2(1000);
   v_id           VARCHAR2(250);

  BEGIN
   parser_ := xmlparser.newparser;
   xmlparser.setpreservewhitespace(parser_, false);

   doc := DBMS_XMLDOM.newDOMDocument(v_ip_xml);
   v_dom_list := DBMS_XMLDOM.getelementsbytagname(doc,'subsection');

   FOR clause_node_index IN 0 .. DBMS_XMLDOM.getLength(v_dom_list) -1 LOOP
           v_clause_node := DBMS_XMLDOM.item (v_dom_list, clause_node_index);
           v_elem := DBMS_XMLDOM.makeelement(v_clause_node);
           v_cov_list := DBMS_XMLDOM.getchildnodes (v_clause_node);

   FOR JP IN 0..DBMS_XMLDOM.getLength(v_cov_list) -1 LOOP
           v_cov_node := DBMS_XMLDOM.item (v_cov_list, JP);
           v_elem := DBMS_XMLDOM.makeelement(v_cov_node);
           dbms_xmldom.setAttribute (v_elem,'REF','MANO');
   END LOOP;
   END LOOP;
        v_ip_xml :=DBMS_XMLDOM.getxmltype(doc);
        DBMS_XMLDOM.freeDocument(doc);

        parser_ := xmlparser.newparser;
        xmlparser.setpreservewhitespace(parser_, false);
       END pr_wsp_shortfall;
 --============================================================================================



END define_rule_pkg;

/

--------------------------------------------------------
--  DDL for Synonymn IDX_ENDDTL_MEMSEQACT
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."IDX_ENDDTL_MEMSEQACT" FOR "APP"."IDX_ENDDTL_MEMSEQACT";

--------------------------------------------------------
--  DDL for Package Body BATCH_REPORT_PKG
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "VENUBABU"."BATCH_REPORT_PKG" IS

--====================================================================================
--This Procedure is used to retrieve batch report of particuar batch no.. and batch date
--This Procedure is used to retrieve batch report of particuar batch no.. and batch date
  PROCEDURE batch_report_list(
    where_clause              IN  VARCHAR2,
    result_set                OUT SYS_REFCURSOR
  )
  IS
    str_tab                ttk_util_pkg.str_table_type;
    --v_sql_str              VARCHAR2(4000);
  BEGIN
    str_tab                := ttk_util_pkg.parse_str ( where_clause );

    IF str_tab(3) = 'PCA' THEN
      OPEN result_set FOR
        SELECT A.batch_seq_id AS batch_number,
           TO_CHAR(A.batch_date ,'DD/MM/YYYY') AS batch_date,
           A.no_of_cheques_issued AS number_of_cheques,
           (SELECT SUM(c.check_amount) from tpa_claims_payment b JOIN tpa_clm_tds_details c ON (B.payment_seq_id = C.payment_seq_id)
                where b.bank_advice_batch = a.batch_seq_id) AS batch_amount
           FROM tpa_bank_advice_batch A
           WHERE A.batch_seq_id =  str_tab(2);

    ELSE
      OPEN result_set FOR
         SELECT A.batch_number,
           TO_CHAR(A.batch_date,'DD/MM/YYYY') AS batch_date,
           A.number_of_cheques,
           A.batch_amount
           FROM tpa_batch_master A
           WHERE A.batch_number = UPPER(str_tab(2)) AND A.deleted_yn = 'N';
    END IF;

 END   batch_report_list;
/*--==================================================================================
--This Procedure is used to generate a Covering Letter for issuing a check.
  PROCEDURE covering_letter(
    v_batch_number          IN  VARCHAR2,
    resultset               OUT  SYS_REFCURSOR
  )
  IS
    str_tab                 ttk_util_pkg.str_table_type;
    v_sql_str               varchar2(6000);
  BEGIN
    str_tab := ttk_util_pkg.parse_str ( v_batch_number );

    v_sql_str :=   'SELECT ''CLAIM SETTLEMENT ADVICE'',
        TO_CHAR(SYSDATE,''DD/MM/YYYY'') AS print_date,
        X.tpa_enrollment_id AS ttk_id_no,
        X.policy_number AS policy_number,
        X.policy_holder_name AS insured_name,
        X.claimant_name AS clm_name,
        A.claim_settlement_no AS settlement_no,
        A.claim_file_number AS claim_file_no,
        A.approved_amount AS claimed_amount,
        ttk_util_pkg.fn_decrypt(A.payee_name) AS payee,   --Modified for koc11ed
        C.check_num AS chk_num,
        C.check_amount AS chk_amt,
        SUBSTR(ttk_util_pkg.num_to_words(C.check_amount),9) AS amount_in_words,
        TO_CHAR(C.check_date,''DD/MM/YYYY'') AS chk_date,
        CASE
          WHEN A.address2 IS NOT NULL AND A.address3 IS NOT NULL THEN A.address1 ||'',''||A.address2 ||'',''||A.address3
          WHEN A.address2 IS NOT NULL THEN A.address1||'',''||A.address2
          WHEN A.address3 IS NOT NULL THEN A.address1||'',''||A.address3
          ELSE A.address1
        END AS payee_address ,
        CASE
          WHEN A.city IS NOT NULL AND A.pincode IS NOT NULL THEN A.city||''-''||TO_CHAR(A.pincode)
          WHEN A.city IS NOT NULL THEN A.city
          WHEN A.pincode IS NOT NULL THEN TO_CHAR(A.pincode)
          END AS city_addr,
        CASE WHEN A.group_reg_seq_id IS NULL THEN K.enrol_description
           ELSE L.group_name
        END corp_name,
        CASE
          WHEN a.mob_num IS NOT NULL AND a.home_phone IS NOT NULL AND a.phone1 IS NOT NULL THEN ''(Mob):''||a.mob_num||'' (Res):''||a.home_phone||'' (Off):''||a.phone1
          WHEN a.mob_num IS NOT NULL AND a.home_phone IS NOT NULL THEN ''(Mob):''||a.mob_num||'' (Res):''||a.home_phone
          WHEN a.mob_num IS NOT NULL AND a.phone1 IS NOT NULL THEN ''(Mob):''||a.mob_num||'' (Off):''||a.phone1
          WHEN a.home_phone IS NOT NULL AND a.phone1 IS NOT NULL THEN '' (Res):''||a.home_phone||'' (Off):''||a.phone1
          WHEN a.mob_num IS NOT NULL THEN ''(Mob):''||a.mob_num
          WHEN a.home_phone IS NOT NULL THEN '' (Res):''||a.home_phone
          WHEN a.phone1 IS NOT NULL THEN '' (Off):''||a.phone1
          ELSE NULL
        END AS phone,
        m.office_name AS branch_office  ,
        o.address_1 AS ttk_address_1,
        o.address_2 AS ttk_address_2,
        o.address_3 AS ttk_address_3,
        p.city_description AS ttk_city,
        q.state_name AS ttk_state,
        o.pin_code AS ttk_pin,
        n.hosp_name,
        tds.approved_amount - tds.check_amount tds_amount
        FROM tpa_claims_payment A JOIN tpa_payment_checks_details B ON (A.payment_seq_id = B.payment_seq_id)
        JOIN tpa_claims_check C ON (C.claims_chk_seq_id = B.claims_chk_seq_id)
        JOIN tpa_enrolment_type_code  K ON (A.enrol_type_id = K.enrol_type_id)
        LEFT OUTER JOIN tpa_group_registration L ON(A.group_reg_seq_id = L.group_reg_seq_id)
        LEFT OUTER JOIN tpa_hosp_info N ON (a.hosp_seq_id = n.hosp_seq_id)
        JOIN clm_enroll_details X ON (A.claim_seq_id=X.claim_seq_id)
        JOIN clm_general_details Y ON(A.claim_seq_id = Y.claim_seq_id)
        LEFT OUTER JOIN assign_users H ON (Y.last_assign_user_seq_id  = H.assign_users_seq_id)
        JOIN tpa_office_info m ON (H.tpa_office_seq_id = m.tpa_office_seq_id)
        LEFT OUTER JOIN tpa_address O ON (m.tpa_office_seq_id = o.tpa_office_seq_id)
        LEFT OUTER JOIN tpa_city_code P ON (O.city_type_id = P.city_type_id)
        LEFT OUTER JOIN tpa_state_code q ON (o.state_type_id = q.state_type_id)
        LEFT OUTER JOIN tpa_clm_tds_details tds ON (a.payment_seq_id = tds.payment_seq_id)
        ';

     IF str_tab(3) = 'A' THEN
        v_sql_str := v_sql_str || ' JOIN tpa_bank_advice_batch D ON (D.batch_seq_id  = A.bank_advice_batch )
        WHERE  D.batch_seq_id = :str_tab_2';
     ELSE
        v_sql_str := v_sql_str || ' JOIN tpa_batch_master D ON (D.batch_number = C.batch_number)
        WHERE  D.batch_number = :str_tab_2';
     END IF;
     v_sql_str := v_sql_str || ' AND (A.hosp_seq_id IS NOT NULL AND N.tds_process_yn=''Y'' OR A.hosp_seq_id IS NULL)';
     v_sql_str := v_sql_str || ' ORDER BY C.check_num';
     OPEN resultset FOR v_sql_str USING str_tab(2);

  END covering_letter;*/
--==================================================================================
--This Procedure is used to generate a Covering Letter for issuing a check.
  PROCEDURE covering_letter(
    v_batch_number          IN  VARCHAR2,
    resultset               OUT  SYS_REFCURSOR
  )
  IS
    str_tab                 ttk_util_pkg.str_table_type;
    v_sql_str               varchar2(32767);
  BEGIN

    str_tab := ttk_util_pkg.parse_str ( v_batch_number );
    v_sql_str :=   'SELECT ''CLAIM SETTLEMENT ADVICE'',
        TO_CHAR(SYSDATE,''DD/MM/YYYY'') AS print_date,
        X.tpa_enrollment_id AS ttk_id_no,
        tep.policy_number AS policy_number,
        teg.insured_name AS insured_name,
        X.mem_name AS clm_name,
        A.claim_settlement_no AS settlement_no,
        A.claim_file_number AS claim_file_no,
        A.approved_amount AS claimed_amount,
        ttk_util_pkg.fn_decrypt(A.payee_name) AS payee,   --Modified for koc11ed
        C.check_num AS chk_num,
        C.check_amount AS chk_amt,
        SUBSTR(ttk_util_pkg.num_to_words(C.check_amount),9) AS amount_in_words,
        TO_CHAR(C.check_date,''DD/MM/YYYY'') AS chk_date,
        
        n.hosp_name
        FROM tpa_claims_payment A JOIN tpa_payment_checks_details B ON (A.payment_seq_id = B.payment_seq_id)
        JOIN tpa_claims_check C ON (C.claims_chk_seq_id = B.claims_chk_seq_id)
        LEFT OUTER JOIN tpa_group_registration L ON(A.group_reg_seq_id = L.group_reg_seq_id)
        LEFT OUTER JOIN tpa_hosp_info N ON (a.hosp_seq_id = n.hosp_seq_id)
        JOIN clm_authorization_details X ON (A.claim_seq_id=X.claim_seq_id)
        LEFT OUTER JOIN app.tpa_enr_policy tep on (x.policy_seq_id = tep.policy_seq_id)
        LEFT OUTER JOIN app.tpa_enr_policy_group teg on (x.policy_seq_id = teg.policy_seq_id)';

     IF str_tab(1) = 'A' THEN
        v_sql_str := v_sql_str || ' JOIN tpa_bank_advice_batch D ON (D.batch_seq_id  = A.bank_advice_batch )
        WHERE  D.batch_seq_id = :str_tab_2';
     ELSE
        v_sql_str := v_sql_str || ' JOIN tpa_batch_master D ON (D.batch_number = C.batch_number)
        WHERE  D.batch_number = :str_tab_2';
     END IF;
     v_sql_str := v_sql_str || ' ORDER BY C.check_num';
     
     OPEN resultset FOR v_sql_str USING str_tab(1);

  END covering_letter;  
--===================================================================================
  
  --this procedure is used to generate reports of given month of all bank account deposit/Withdrawl Transactions.
  PROCEDURE bank_transaction_report(
    where_clause                IN  VARCHAR2,
    result_set                  OUT SYS_REFCURSOR
  )
  IS
    str_tab                ttk_util_pkg.str_table_type;
  BEGIN
    str_tab               := ttk_util_pkg.parse_str ( where_clause );

    OPEN result_set  FOR
     SELECT acc_num, trn_amt,
      DECODE(deposit_tran_amt,'Y',trn_amt,0) deposit_trans_month,
      DECODE(deposit_tran_amt,'Z',trn_amt,0) withdrawl_trans_month
      FROM( SELECT CASE WHEN A.trn_type = 'TTD' THEN 'Y' ELSE 'Z' END AS deposit_tran_amt ,
              B.account_number AS acc_num, trn_amount AS trn_amt,  A.trn_type AS trn_type
             FROM fin_app.tpa_bank_transactions A JOIN fin_app.tpa_bank_accounts B ON(B.bank_acc_seq_id = A.bank_acc_seq_id)
            WHERE B.account_number =str_tab(2) AND EXTRACT(MONTH FROM A.trn_date) = str_tab(3) AND EXTRACT(YEAR FROM A.trn_date) = str_tab(4)
             AND A.trn_type IN ('TTD','TTA') ) ORDER BY  deposit_tran_amt DESC ;

  END bank_transaction_report;
--==============================================================================================
  --this procedure is used to generate reports of given month of all Flost account deposit/Withdrawl Transactions.
  PROCEDURE float_transaction_report(
    where_clause                IN  VARCHAR2,
    result_set                  OUT SYS_REFCURSOR
  )
  IS
    str_tab                ttk_util_pkg.str_table_type;
  BEGIN
    str_tab               := ttk_util_pkg.parse_str ( where_clause );

    OPEN result_set  FOR
      SELECT acc_num , trn_amt, DECODE(deposit_tran_amt,'Y',trn_amt,0)deposit_trans_month,
                             DECODE(deposit_tran_amt,'Z',trn_amt,0)withdrawl_trans_month
          FROM( SELECT CASE WHEN A.flt_trn_type = 'TTD' THEN 'Y' ELSE 'Z' END AS deposit_tran_amt ,
          B.float_account_number AS acc_num, A.flt_trn_amount trn_amt, A.flt_trn_type AS trn_type
          FROM fin_app.tpa_float_transaction A JOIN tpa_float_account B ON(B.float_seq_id= A.float_seq_id)
          JOIN fin_app.tpa_bank_accounts C ON(C.bank_acc_seq_id = B.bank_acc_seq_id)
          WHERE C.account_number = str_tab(2) AND EXTRACT(MONTH FROM A.flt_trn_date) = str_tab(3)
          AND EXTRACT(YEAR FROM A.flt_trn_date) = str_tab(4) AND A.flt_trn_type IN ('TTD','TTA' ))
          ORDER BY  deposit_tran_amt DESC ;

  END float_transaction_report;
--================================================================================================
--this procedure is used to generate reconcilation report
--1st column gives cheques information issued before the date given on the screen.
--2nd column  giveS issued cheques information of the current year/month.
--3rd column gives void or cleared cheques information of the current year/month.
--4th column gives outstanding balance of the current year/month.

  PROCEDURE reconcilation_report(
    where_clause              IN  VARCHAR2,
    result_set                OUT  SYS_REFCURSOR

  )
  IS
    str_tab                ttk_util_pkg.str_table_type;
  --  v_date                 VARCHAR2(10);
  BEGIN
    str_tab               := ttk_util_pkg.parse_str ( where_clause );
    IF str_tab(1) IS NOT NULL OR str_tab(1) IS NULL THEN
       OPEN result_set FOR SELECT * FROM dual WHERE 1=2;
    END IF;

 /*  --concatinatinfg both month and year in variable to avoid lipear year.

   v_date := str_tab(3)||'/'||str_tab(4);

   OPEN result_set FOR
      SELECT accnum,chknum, SUM(decode(f1,'a',chckamt,0)) AS OUTSTANDING,
                                       SUM(decode(f1,'b',chckamt,0)) AS issued,
                                       SUM(decode(f1,'c',chckamt,0)) AS voidorcleared,
                                       SUM(decode(f1,'d',chckamt,0)) AS void
        FROM ( SELECT
           CASE WHEN E.check_status = 'CSI' THEN 'a'
                WHEN EXTRACT(MONTH FROM E.check_date) = str_tab(3) AND  EXTRACT(YEAR FROM E.check_date)  = str_tab(4) THEN 'b'
                WHEN (( EXTRACT(MONTH FROM E.void_date) =  str_tab(3) AND EXTRACT(YEAR FROM E.void_date) = str_tab(4))
                     OR ( EXTRACT(MONTH FROM E.cleared_date) = str_tab(3) AND EXTRACT(YEAR FROM E.cleared_date) = str_tab(4))) THEN 'c'
                WHEN (E.cleared_date > LAST_DAY(TO_DATE(v_date ,'MM/YYYY')) OR E.void_date > LAST_DAY(TO_DATE(v_date,'MM/YYYY'))
                OR( E.cleared_date IS NULL AND E.void_date IS NULL )) THEN 'd'
           END AS f1,
           A.account_number AS accnum,
           E.check_num AS chknum,
           E.check_amount AS chckamt,
           E.check_status
           FROM tpa_bank_accounts A JOIN tpa_float_account B ON(A.bank_acc_seq_id = B.bank_acc_seq_id)
           JOIN tpa_claims_payment C ON(B.float_seq_id = C.float_seq_id)
           JOIN tpa_payment_checks_details D ON (C.payment_seq_id = D.payment_seq_id)
           JOIN tpa_claims_check E ON (D.claims_chk_seq_id = E.claims_chk_seq_id)
           WHERE A.account_number = str_tab(2)
           AND EXTRACT(MONTH FROM E.check_date) <= str_tab(3) AND EXTRACT(YEAR FROM E.check_date)  <= str_tab(4) )GROUP by chknum,accnum ORDER BY chknum ;*/

  END reconcilation_report;
--===============================================================================================
  PROCEDURE EFT_claims_details_report(
     where_clause              IN  VARCHAR2, --|S|dropdown|float_account_no|batch_no||
     result_set                 OUT SYS_REFCURSOR
  )
  IS
    str_tab                ttk_util_pkg.str_table_type;
    --v_from_date            DATE;
    --v_to_date              DATE;
  BEGIN
    str_tab     := ttk_util_pkg.parse_str ( where_clause );
    --v_from_date := to_date(str_tab(4),'dd/mm/yyyy');
    --v_to_date   := to_date(str_tab(5),'dd/mm/yyyy')+1;
    OPEN result_set FOR
        SELECT
               E.employee_no AS emp_no,
               E.policy_holder_name AS insured_name,
               E.claimant_name,
               E.tpa_enrollment_id AS tpa_id_no,
               a.claim_settlement_no,
               A.approved_amount AS al_amt,
               a.emp_bank_name,
               a.emp_bank_branch,
               a.emp_acct_number,
               a.emp_email,
               D.total_app_amount
          FROM tpa_claims_payment A JOIN clm_general_details D ON (A.claim_seq_id = D.claim_seq_id)
               JOIN tpa_float_account F ON A.Float_Seq_Id = F.Float_Seq_Id AND F.FLOAT_ACCOUNT_NUMBER = str_tab(3)
               JOIN clm_enroll_details E ON ( D.claim_seq_id = E.claim_seq_id )
               --JOIN  tpa_payment_checks_details rr ON (a.payment_seq_id = rr.payment_seq_id)
               --JOIN tpa_claims_check ss ON (rr.claims_chk_seq_id  = ss.claims_chk_seq_id)
          WHERE a.claim_payment_status = 'PAID'
          AND a.payee_type = 'EFT'
          --AND SS.check_date BETWEEN v_from_date AND v_to_date
          AND a.batch_number_manual = str_tab(4)
          AND a.emp_bank_name||a.emp_bank_branch||a.emp_acct_number||a.emp_email IS NOT NULL;
  END EFT_claims_details_report;
--===============================================================================================
  PROCEDURE CITI_claims_details_report(
     where_clause IN  VARCHAR2,
     result_set   OUT SYS_REFCURSOR
  )
  IS
    str_tab                ttk_util_pkg.str_table_type;
    v_from_date            DATE;
    v_to_date              DATE;
    v_float_seq_id         tpa_float_account.float_seq_id%TYPE;
  BEGIN
    str_tab     := ttk_util_pkg.parse_str ( where_clause );
    v_from_date := to_date(str_tab(3),'dd/mm/yyyy');
    v_to_date   := to_date(str_tab(4),'dd/mm/yyyy')+1;
    SELECT float_seq_id INTO v_float_seq_id FROM tpa_float_account WHERE float_account_number = str_tab(2);

    OPEN result_set FOR
    WITH CSR AS (SELECT  1 AS Units, 'CSR' AS Chq_status, 'Cancelled' AS Cheque_Status FROM DUAL UNION
                 SELECT -1 AS Units, 'CSR', NULL FROM DUAL UNION      -- THIS IS TO SHOW ONE RECORD WITH +VE APPROVED AMOUNT AND ANOTHER WITH -VE AMT IF CHEQUE IS REISSUED. IN CASE OF CHEQUE IS VOID THEN TO SHOW APPROVED AMT AS -VE.
                 SELECT -1 AS Units, 'CSV', NULL FROM DUAL ORDER BY Units DESC)
    SELECT  I.office_name,
            B.ins_comp_name,
            B.ins_comp_code_number,
            B.abbrevation_code,
            E.tpa_enrollment_id AS tpa_id_no,
            E.policy_number,
            d.claim_number AS claim_no,
            k.group_name ,
            E.claimant_name,
            j.mem_age,
            n.relship_description ,
            g.insured_name ,
            H.policy_agent_code,
            a.claim_settlement_no,
            TO_CHAR(F.dv_sent_date,'DD/MM/YYYY') AS dv_sent_date,
            TO_CHAR(F.dv_received_date ,'DD/MM/YYYY') AS dv_received_date,
            I.office_code,
            CASE WHEN a.claim_payment_status = 'PAID' THEN D.requested_amount ELSE D.requested_amount * -1 END AS requested_amount,
            CASE WHEN cbCSR.Chq_status IS NULL THEN D.total_app_amount * NVL(CSR.Units,1) ELSE NULL END AS total_app_amount,
            NVL(o.hosp_name,w.hosp_name ) AS hosp_name ,
            TO_CHAR(v.rcvd_date,'DD/MM/YYYY') AS claim_intimation_date,
            TO_CHAR(d.date_of_admission,'DD/MM/YYYY') AS date_of_admission,
            TO_CHAR(d.date_of_discharge,'DD/MM/YYYY') AS date_of_discharge,
            s.total_app_amount AS al_amt,
            TO_CHAR(r.decision_date,'DD/MM/YYYY') AS al_date,
            t.sum_insured + t.bonus - t.utilised_sum_insured - t.utilised_cum_bonus AS balance_sum_insured ,
            d.claim_file_number ,
            CASE WHEN a.claim_type = 'CTM' AND NVL(D.PAY_TO_GENERAL_TYPE_ID,'MBR')!= 'HSL' THEN  D.total_app_amount * NVL(CSR.Units,1) ELSE NULL END AS amt_paid_beneficiary,
            CASE WHEN a.claim_type = 'CNH' OR NVL(D.PAY_TO_GENERAL_TYPE_ID,'MBR') = 'HSL' THEN  D.total_app_amount * NVL(CSR.Units,1) ELSE NULL END AS amt_paid_hospital,
            NULL AS deposit_to,
            v.claims_inward_no AS claim_app_no,
            G.employee_no AS emp_no,
            batch_report_pkg.get_icds(A.claim_seq_id ) AS ailment,
            batch_report_pkg.get_billno(A.claim_seq_id ) AS bill_nos,
            batch_report_pkg.get_hospitalization( A.claim_seq_id , d.date_of_admission, d.date_of_discharge ) AS pre_post,
            CASE WHEN a.claim_payment_status = 'PAID' THEN D.requested_amount - d.total_app_amount ELSE NULL END AS disc_amt,
            ( SELECT COUNT(1) FROM clm_enroll_details Y WHERE Y.member_seq_id = e.member_seq_id ) AS no_claims ,
            u.remarks AS remarks ,
            CASE WHEN j.mem_general_type_id = 'PFL' THEN G.family_tot_sum_insured ELSE J.mem_tot_sum_insured END AS sum_insured,
            TO_CHAR(H.EFFECTIVE_FROM_DATE,'DD/MM/YYYY') AS POLICY_START_DATE,
            to_char(h.effective_to_date,'DD/MM/YYYY') AS POLICY_END_DATE ,
            ss.batch_number,
            TT.description AS payment_mode,
            CASE WHEN a.claim_payment_status = 'PAID' AND cbCSR.Chq_status IS NULL
                      THEN ss.check_num ELSE NULL END AS check_num,
            CASE WHEN a.claim_payment_status = 'PAID' AND cbCSR.Chq_status IS NULL THEN
                      CASE WHEN CSR.Units = -1 AND ss.check_status = 'CSR' THEN to_char(ss.Void_Date,'dd/mm/yyyy')
                           ELSE to_char(ss.check_date,'dd/mm/yyyy') END ELSE NULL END AS check_date,
            ttk_util_pkg.fn_decrypt(a.payee_name) payee_name, --Modified for koc11ed
            CASE WHEN cbCSR.Chq_status IS NULL THEN nvl(CSR.Cheque_Status,ST.description) ELSE NULL END AS Cheque_status,
            CASE WHEN CSR.Chq_status IS NULL THEN hcbg.requested_amount ELSE NULL END AS hcb_tot_clm_amt,
            CASE WHEN CSR.Chq_status IS NULL THEN hcb.cb_approved_amount ELSE NULL END AS hcb_payable_amt,
            CASE WHEN CSR.Chq_status IS NULL THEN hcbcc.check_amount*nvl(cbCSR.Units,1) ELSE NULL END AS hcb_paid_amt,
            CASE WHEN CSR.Chq_status IS NULL THEN hcbcc.check_num ELSE NULL END AS hcb_chq_number,
            CASE WHEN CSR.Chq_status IS NULL THEN TO_CHAR(hcbcc.check_date,'DD/MM/YYYY') ELSE NULL END AS hcb_chq_date,
            CASE WHEN CSR.Chq_status IS NULL THEN ttk_util_pkg.fn_decrypt(hcbp.payee_name) ELSE NULL END AS hcb_payee_name --Modified for koc11ed
        FROM tpa_claims_payment A JOIN tpa_ins_info B ON( A.ins_seq_id = B.ins_seq_id AND a.float_seq_id = v_float_seq_id)
              JOIN clm_general_details D ON(A.claim_seq_id = D.claim_seq_id AND D.CLAIM_SUB_GENERAL_TYPE_ID !='CBN')
              JOIN clm_enroll_details E ON ( D.claim_seq_id = E.claim_seq_id )
              LEFT OUTER JOIN clm_discharge_voucher F ON (D.claim_seq_id = F.claim_seq_id)
              LEFT OUTER JOIN clm_cash_benefit hcb ON D.Claim_Seq_Id = hcb.parent_claim_seq_id
              LEFT OUTER JOIN clm_general_details hcbg ON hcb.claim_seq_id = hcbg.claim_seq_id
              LEFT OUTER JOIN tpa_claims_payment hcbp ON hcb.claim_seq_id = hcbp.claim_seq_id
              JOIN tpa_enr_policy_member J ON (a.member_seq_id = j.member_seq_id)
              JOIN tpa_enr_policy_group G ON (j.policy_group_seq_id = g.policy_group_seq_id )
              JOIN tpa_enr_policy H ON(H.policy_seq_id = G.policy_seq_id)
              JOIN tpa_office_info I ON( H.tpa_office_seq_id  = I.tpa_office_seq_id)
              LEFT OUTER JOIN tpa_group_registration k ON (a.group_reg_seq_id = k.group_reg_seq_id)
              JOIN tpa_relationship_code n ON (j.relship_type_id = n.relship_type_id)
              LEFT OUTER JOIN tpa_hosp_info o ON (a.hosp_seq_id = o.hosp_seq_id)
              LEFT OUTER JOIN pat_enroll_details r ON (d.pat_enroll_detail_seq_id = r.pat_enroll_detail_seq_id)
              LEFT OUTER JOIN pat_general_details s ON (r.pat_enroll_detail_seq_id = s.pat_enroll_detail_seq_id AND s.pat_enhanced_yn = 'N')
              JOIN tpa_enr_balance T ON ((J.policy_group_seq_id = T.policy_group_seq_id AND J.mem_general_type_id = 'PFL') OR
                                         (J.mem_general_type_id != 'PFL' AND J.Member_Seq_Id = t.member_seq_id ))
              LEFT OUTER JOIN assign_users U ON (d.last_assign_user_seq_id = u.assign_users_seq_id)
              JOIN clm_inward V ON (d.claims_inward_seq_id = v.claims_inward_seq_id)
              LEFT OUTER JOIN clm_hospital_association w ON (a.claim_seq_id = w.claim_seq_id)
              JOIN  tpa_payment_checks_details rr ON (a.payment_seq_id = rr.payment_seq_id)
              JOIN tpa_claims_check ss ON (rr.claims_chk_seq_id  = ss.claims_chk_seq_id)
              JOIN tpa_general_code TT ON (A.payee_type=TT.general_type_id)
              LEFT OUTER JOIN CSR ON ss.check_status = CSR.Chq_status
              LEFT OUTER JOIN tpa_general_code st ON ss.check_status = st.general_type_id
              LEFT OUTER JOIN tpa_payment_checks_details hcbcd ON (hcbp.payment_seq_id = hcbcd.payment_seq_id AND ss.check_status IN ('CSI','CSC','CSS'))
              LEFT OUTER JOIN tpa_claims_check hcbcc ON (hcbcd.claims_chk_seq_id  = hcbcc.claims_chk_seq_id )
              LEFT OUTER JOIN CSR cbCSR ON (hcbcc.check_status = cbCSR.Chq_status)
        WHERE (a.claim_payment_status = 'PAID' AND SS.check_status != 'CSV' AND SS.check_date BETWEEN v_from_date AND v_to_date)
           OR (ss.check_status = 'CSV' AND ss.void_date BETWEEN v_from_date AND v_to_date)
         ORDER BY ins_comp_code_number, check_date;

 END citi_claims_details_report;

--===============================================================================================
--this is an 22 column report here inputs are float_account_number,month,year status of acount is irrelevant.
  --===============================================================================================
--this is an 22 column report here inputs are float_account_number,month,year status of acount is irrelevant.
  PROCEDURE claims_details_report(
     where_clause              IN  VARCHAR2,
     result_set                 OUT SYS_REFCURSOR
  )
  IS
    str_tab                ttk_util_pkg.str_table_type;
    v_from_date            DATE;
    v_to_date              DATE;
    v_float_seq_id         tpa_float_account.float_seq_id%TYPE;
    v_count                NUMBER;
    
   CURSOR Float_acc_Details (v_flaot_number VARCHAR2) is
     SELECT float_seq_id,COUNT(float_seq_id)  
     FROM tpa_float_account 
     WHERE float_account_number =v_flaot_number
     Group by float_seq_id;
   
  BEGIN
    str_tab     := ttk_util_pkg.parse_str ( where_clause );
    v_from_date := to_date(str_tab(4),'dd/mm/yyyy');
    v_to_date   := to_date(str_tab(5),'dd/mm/yyyy')+1;
    
    OPEN Float_acc_Details(str_tab(3));
         FETCH Float_acc_Details INTO v_float_seq_id,v_count;
               CLOSE Float_acc_Details;
               
    --SELECT float_seq_id INTO v_float_seq_id FROM tpa_float_account WHERE float_account_number = str_tab(3);
   If NVL(v_count,0)=0 then 
     Raise_Application_error ('-20922','Given Float Account is not Avilable');
   ELSE
    OPEN result_set FOR
    WITH CSR AS (SELECT  1 AS Units, 'CSR' AS Chq_status, 'Cancelled' AS Cheque_Status FROM DUAL UNION
                 SELECT -1 AS Units, 'CSR', NULL FROM DUAL UNION      -- THIS IS TO SHOW ONE RECORD WITH +VE APPROVED AMOUNT AND ANOTHER WITH -VE AMT IF CHEQUE IS REISSUED. IN CASE OF CHEQUE IS VOID THEN TO SHOW APPROVED AMT AS -VE.
                 SELECT -1 AS Units, 'CSV', NULL FROM DUAL ORDER BY Units DESC)
  
    SELECT   /*+ optimizer_features_enable('11.2.0.1')*/ 
      I.office_name,
            B.ins_comp_name,
            B.ins_comp_code_number,
            B.abbrevation_code,
            j.tpa_enrollment_id AS tpa_id_no,
            h.policy_number,
            d.claim_number AS claim_no,
            k.group_name ,---corporate name
            g.insured_name as claimant_name,
            j.mem_age,
            n.relship_description ,
            g.insured_name ,
            H.policy_agent_code,
            a.claim_settlement_no,
            TO_CHAR(d.clm_received_date,'DD/MM/YYYY') AS claim_Intimation_Date,--clm_recevied date
            TO_CHAR(F.dv_sent_date,'DD/MM/YYYY') AS dv_sent_date,
            TO_CHAR(F.dv_received_date ,'DD/MM/YYYY') AS dv_received_date,
            I.office_code,
            CASE WHEN a.claim_payment_status = 'PAID' THEN D.requested_amount ELSE D.requested_amount * -1 END AS requested_amount,
		        d.req_amt_currency_type as INCURRED_CURRENCY,
            d.conversion_rate as CONVERSION_RATE_TO_QAR,
            d.converted_amount,
            d.converted_amount_currency_type as convertd_currency,
		        d.converted_final_approved_amt as Amount_Payable_in_Incrd_curncy,
            d.req_amt_currency_type as Payable_in_Incrd_curncy,			
            D.Tot_Approved_Amount * NVL(Units,1) AS total_app_amount,
            NVL(o.hosp_name,w.hosp_name ) AS hosp_name ,
            --TO_CHAR(v.rcvd_date,'DD/MM/YYYY') AS claim_intimation_date,
            TO_CHAR(d.date_of_hospitalization,'DD/MM/YYYY') AS date_of_admission,
            TO_CHAR(d.date_of_discharge,'DD/MM/YYYY') AS date_of_discharge,
            d.tot_approved_amount AS al_amt,
            TO_CHAR(d.completed_date,'DD/MM/YYYY') AS al_date,
            t.sum_insured + t.bonus - t.utilised_sum_insured - t.utilised_cum_bonus AS balance_sum_insured ,
            d.claim_file_number ,
            --CASE WHEN a.claim_type = 'CTM' AND NVL(D.PAY_TO_GENERAL_TYPE_ID,'MBR')!= 'HSL' THEN  D.Tot_Approved_Amount * NVL(Units,1) ELSE NULL END AS amt_paid_beneficiary,
            --CASE WHEN a.claim_type = 'CNH' OR NVL(D.PAY_TO_GENERAL_TYPE_ID,'MBR')= 'HSL' THEN  D.Tot_Approved_Amount * NVL(Units,1) ELSE NULL END AS amt_paid_hospital,
            NULL AS deposit_to,
            --v.claims_inward_no AS claim_app_no,
            G.employee_no AS emp_no,
            --get_icds(A.claim_seq_id ) AS ailment,
            --get_billno(A.claim_seq_id ) AS bill_nos,
            --get_hospitalization( A.claim_seq_id , d.date_of_admission, d.date_of_discharge ) AS pre_post,
            --CASE WHEN a.claim_payment_status = 'PAID' THEN D.requested_amount - d.total_app_amount ELSE NULL END AS disc_amt,
            ( SELECT COUNT(1) FROM clm_enroll_details Y WHERE Y.member_seq_id = d.member_seq_id ) AS no_claims ,
            --u.remarks AS remarks ,
            CASE WHEN j.mem_general_type_id = 'PFL' THEN G.family_tot_sum_insured ELSE J.mem_tot_sum_insured END AS sum_insured,
            TO_CHAR(H.EFFECTIVE_FROM_DATE,'DD/MM/YYYY') AS POLICY_START_DATE,
            to_char(h.effective_to_date,'DD/MM/YYYY') AS POLICY_END_DATE ,
            ss.batch_number,
            case ss.PAYMENT_TYPE when 'EFT' THEN 'EFT' WHEN 'PCA' THEN 'Cheque Advice' when 'PMM' THEN 'Manual' ELSE (CASE A.Payee_Type WHEN 'EFT' THEN 'EFT' WHEN 'PCA' THEN 'Cheque Advice' ELSE 'Manual'  END) END AS payment_mode,--koc1175
            CASE WHEN a.claim_payment_status = 'PAID' THEN case  ss.payment_type WHEN 'EFT' then 'EFT-'||ss.check_num WHEN 'PCA'  THEN ss.check_num ELSE (CASE A.Payee_Type WHEN 'EFT' THEN 'EFT-'||ss.check_num ELSE ss.check_num end) END ELSE NULL END AS check_num,--koc1175
                       CASE WHEN a.claim_payment_status = 'PAID' THEN
                      CASE WHEN CSR.Units = -1 AND ss.check_status = 'CSR' THEN to_char(ss.Void_Date,'dd/mm/yyyy')
                           ELSE to_char(ss.check_date,'dd/mm/yyyy') END ELSE NULL END AS check_date,
            ttk_util_pkg.fn_decrypt(a.payee_name) AS  payee_name, --Modified for koc11ed
            nvl(CSR.Cheque_Status,ST.description) AS Cheque_status,
             w.city_name AS Location,
            --pl.Office_Name AS clm_processed_location,
            --tds.approved_amount - tds.check_amount AS tds_amount,
            --nvl(tds.bat_perc,0) + nvl(tds.edc_perc,0) + nvl(tds.sur_perc,0) + nvl(tds.ms1_perc,0) + nvl(tds.ms2_perc,0)   AS tds_precentage,
            --CASE WHEN A.Hosp_Seq_Id IS NOT NULL AND nvl(tds.bat_perc,0)!=0  THEN (nvl(tds.bat_perc,0)) + (nvl(tds.bat_perc,0) * nvl(tds.sur_perc,0)/100)+ ((nvl(tds.bat_perc,0)+(nvl(tds.bat_perc,0)/nvl(tds.sur_perc,0)))*nvl(tds.edc_perc,0)/100) \*+ nvl(tds.ms1_perc,0) + nvl(tds.ms2_perc,0)*\ ELSE NULL END AS tds_precentage ,
            CASE WHEN A.Hosp_Seq_Id IS NOT NULL THEN
              CASE WHEN nvl(tds.bat_perc,0)!=0 AND nvl(tds.sur_perc,0)=0 AND nvl(tds.edc_perc,0)=0  THEN (nvl(tds.bat_perc,0))
                   WHEN nvl(tds.bat_perc,0)!=0 AND nvl(tds.sur_perc,0)!=0 AND nvl(tds.edc_perc,0)=0 THEN (nvl(tds.bat_perc,0)) + (nvl(tds.bat_perc,0) * nvl(tds.sur_perc,0)/100)
                   WHEN nvl(tds.bat_perc,0)!=0 AND nvl(tds.sur_perc,0)!=0 AND nvl(tds.edc_perc,0)!=0 THEN (nvl(tds.bat_perc,0)) + (nvl(tds.bat_perc,0) * nvl(tds.sur_perc,0)/100)+ ((nvl(tds.bat_perc,0)+(nvl(tds.bat_perc,0)/nvl(tds.sur_perc,0)))*nvl(tds.edc_perc,0)/100)
                   ELSE NULL END ELSE NULL END AS tds_precentage ,
            nvl(tds.check_amount,ss.check_amount ) AS cheque_amount,
            icd.short_desc as ailment,
            (d.tot_disc_gross_amount-d.tot_approved_amount) as disc_amt,
            d.invoice_number as bill_nos,
            case when d.claim_type='CTM' then  ss.check_amount  end as amt_paid_beneficiary,
            case when d.claim_type='CNH' then  ss.check_amount  end as  amt_paid_hospital,
			  d.final_remarks as remarks,
       	 to_char(d.completed_date,'dd/mm/yyyy') as Claim_approved_date,
         d.pay_amt_in_usd as usd_amount,
         a.transfer_currency as AMNT_TRANSFERRED_CURR,
         pi.partner_name as partner_name,
         case when TTK_UTIL_PKG.FN_DECRYPT(A.payee_name)=ref.payee_name then ref.TRANS_NUM end as trans_ref_num
         
        FROM tpa_claims_payment A JOIN tpa_ins_info B ON( A.ins_seq_id = B.ins_seq_id AND a.float_seq_id = v_float_seq_id)
              JOIN clm_authorization_details D ON(A.claim_seq_id = D.claim_seq_id)
             /* JOIN pat_activity_details pat ON (pat.claim_seq_id=d.claim_seq_id)*/
              JOIN diagnosys_details dd on (d.claim_seq_id=dd.claim_seq_id  AND dd.primary_ailment_yn='Y')
              JOIN app.tpa_icd10_master_details icd on (icd.icd_code=dd.diagnosys_code)
              --JOIN clm_enroll_details E ON ( D.claim_seq_id = E.claim_seq_id )
              LEFT OUTER JOIN clm_discharge_voucher F ON (D.claim_seq_id = F.claim_seq_id)
              JOIN tpa_enr_policy_member J ON (a.member_seq_id = j.member_seq_id)
              JOIN tpa_enr_policy_group G ON (j.policy_group_seq_id = g.policy_group_seq_id )
              JOIN tpa_enr_policy H ON(H.policy_seq_id = G.policy_seq_id)
              JOIN tpa_office_info I ON( H.tpa_office_seq_id  = I.tpa_office_seq_id)
              LEFT OUTER JOIN tpa_group_registration k ON (a.group_reg_seq_id = k.group_reg_seq_id)
              JOIN tpa_relationship_code n ON (j.relship_type_id = n.relship_type_id)
              LEFT OUTER JOIN tpa_hosp_info o ON (a.hosp_seq_id = o.hosp_seq_id)
              LEFT OUTER JOIN tpa_hosp_address ha ON o.hosp_seq_id = ha.hosp_seq_id
              LEFT OUTER JOIN tpa_city_code cct ON ha.city_type_id = cct.city_type_id
              LEFT OUTER JOIN app.pat_authorization_details r ON (d.pat_auth_seq_id = r.pat_auth_seq_id)
              --LEFT OUTER JOIN pat_general_details s ON (r.pat_enroll_detail_seq_id = s.pat_enroll_detail_seq_id AND s.pat_enhanced_yn = 'N')
              JOIN tpa_enr_balance T ON ((J.policy_group_seq_id = T.policy_group_seq_id AND J.mem_general_type_id = 'PFL') OR
                                         (J.mem_general_type_id != 'PFL' AND J.Member_Seq_Id = t.member_seq_id ))
              --LEFT OUTER JOIN assign_users U ON (d.last_assign_user_seq_id = u.assign_users_seq_id)
              --LEFT OUTER JOIN tpa_office_info pl ON U.Tpa_Office_Seq_Id = pl.tpa_office_seq_id
              LEFT OUTER JOIN app.clm_batch_upload_details V ON (d.clm_batch_seq_id = v.clm_batch_seq_id)
              LEFT OUTER JOIN app.clm_hospital_details w ON (a.claim_seq_id = w.claim_seq_id)
              JOIN  tpa_payment_checks_details rr ON (a.payment_seq_id = rr.payment_seq_id)
              JOIN tpa_claims_check ss ON (rr.claims_chk_seq_id  = ss.claims_chk_seq_id)
              LEFT OUTER JOIN CSR ON ss.check_status = CSR.Chq_status
              LEFT OUTER JOIN tpa_general_code st ON ss.check_status = st.general_type_id
              LEFT OUTER JOIN tpa_clm_tds_details tds ON (a.payment_seq_id = tds.payment_seq_id)
              LEFT OUTER JOIN tpa_partner_info pi ON (D.ptnr_seq_id=pi.ptnr_seq_id)
               LEFT OUTER JOIN tpa_bank_advice_batch batc on (batc.batch_seq_id=a.bank_advice_batch)
               LEFT OUTER JOIN FIN_APP.trans_ref_table ref ON (ref.batch_num=batc.batch_seq_id) AND TTK_UTIL_PKG.FN_DECRYPT(a.payee_name)=ref.payee_name
        WHERE  a.claim_aprv_date between v_from_date AND v_to_date and a.claim_payment_status = 'PAID' AND SS.check_status != 'CSV';
        /*(a.claim_payment_status = 'PAID' AND SS.check_status != 'CSV' AND SS.check_date >= v_from_date AND SS.check_date < v_to_date)
           OR (ss.check_status = 'CSV' AND ss.void_date >= v_from_date AND ss.void_date < v_to_date)
         ORDER BY ins_comp_code_number, check_date*/
  END IF;
  END  claims_details_report;
 --============================================================================================================================================================= 
/*  PROCEDURE claims_details_report(
     where_clause              IN  VARCHAR2,
     result_set                 OUT SYS_REFCURSOR
  )
  IS
    str_tab                ttk_util_pkg.str_table_type;
    v_from_date            DATE;
    v_to_date              DATE;
    v_float_seq_id         tpa_float_account.float_seq_id%TYPE;

  BEGIN
    
    str_tab     := ttk_util_pkg.parse_str ( where_clause );
    --v_from_date := to_date(str_tab(4),'dd/mm/yyyy');
    --v_to_date   := to_date(str_tab(5),'dd/mm/yyyy')+1;

    OPEN result_set FOR
         SELECT 
         ii.ins_comp_name as Insurance_Company,  
         d.Invoice_Number,
         ho.Empanel_Number,
         ho.hosp_licenc_numb as Provider_License_No,
         fa.float_account_number as Float_Account_No, 
         ba.account_number as Bank_Account_No,  
         g.description as Float_Model,  
         k.group_name,
         k.group_id,  
         h.policy_number,
         tip.product_name as Plan,
         d.tpa_enrollment_id as Enrollment_ID,
         TO_CHAR(D.CLM_RECEIVED_DATE,'DD/MM/YYYY')AS "RECEIVED_DATE",
         TO_CHAR(D.DATE_OF_HOSPITALIZATION ,'DD/MM/YYYY') AS "ENCOUNTER DATE",
         TO_CHAR(D.DATE_OF_HOSPITALIZATION,'DD/MM/YYYY')  AS "DATE OF ADMISSION",
          TO_CHAR(D.DATE_OF_DISCHARGE,'DD/MM/YYYY') AS "DATE OF DISCHARGE",
         d.claim_number as "Claim No.",
         d.settlement_number as Claim_Settlement_No, 
         TO_CHAR(D.COMPLETED_DATE,'DD/MM/YYYY') AS "CLAIM_APPROVED_DATE",
         ge.description as claim_type,  
         --teg.insured_name as Insured_Person_Name,
         teg.insured_name||nvl2(teg.insured_middle_name,' '||teg.insured_middle_name,'')||nvl2(teg.insured_family_name,' '||teg.insured_family_name,'') as Insured_Person_Name,
         --d.mem_name as Claimant_Name,  
         pm.mem_name ||nvl2(pm.mem_last_name,' '||pm.mem_last_name,'')||nvl2(pm.family_name,' '||pm.family_name,'') as Claimant_Name,
         d.requested_amount as INCURRED_Amount,
         d.req_amt_currency_type as INCURRED_CURRENCY,
         d.conversion_rate as CONVERSION_RATE_TO_QAR,
         d.converted_amount as "CONV_AMOUNT_In_QAR(Req_Amnt)",
          --d.tot_disc_gross_amount as Total_Claim_Amt,
         d.tot_patient_share_amount as patient_share,
         d.tot_discount_amount as discount,
         d.tot_patient_share_amount as Deductions,
         --null as Reasons,
         d.final_app_amount as AMOUNT_PAYABLE_In_QAR,
         d.converted_final_approved_amt as Amount_Payable_in_Incrd_curncy,
         ttk_util_pkg.fn_decrypt(a.payee_name) as payee_name,
         gen.description as Mode_of_Payment,  
         cc.check_num as Payment_RefNo,  
         to_char(cc.check_date,'dd/mm/yyyy') as Payment_Date,  
         a.claim_payment_status ,  
         a.batch_number_manual as Payment_Batch_No , 
         a.trans_ref_no as Transaction_Reference,
         gener.description as benifit_type,
         gener.description as Encounter_Type,
         H.CAPITATION_YN AS  "ADMINISTRATION CATAGORY",
       --  to_char(d.completed_date,'dd/mm/yyyy') as Claim_approved_date,
         gene.description as Claim_Status,
         tdn.debit_status_general_type_id as DN_Status,
         tdn.debit_note_number as DN_No,
         to_char(tdn.debit_date,'dd/mm/yyyy') as DN_Date,
          --rud.error_msg as ra_dhpo_upload_status,       
          --rud.file_name as "FILE NAME",
         --TO_CHAR(rud.added_date,'DD/MM/YYYY') as  "RA DHPO UPLOAD DATE",
         CASE WHEN d.claim_type = 'CNH' THEN
                 CASE d.pymnt_to_type_id WHEN 'PTN' THEN NULL--ttk_util_pkg.fn_decrypt(pa.account_number) 
                                          ELSE ttk_util_pkg.fn_decrypt(w.account_number) 
                  END 
               ELSE NULL END as ACCOUNT_NO,
         CASE WHEN d.claim_type = 'CNH' THEN
                 CASE d.pymnt_to_type_id WHEN 'PTN' THEN NULL--ttk_util_pkg.fn_decrypt(pa.bank_micr) 
                                          ELSE w.bank_micr 
                  END 
               ELSE NULL END as IBAN_NO,
         CASE WHEN d.claim_type = 'CNH' THEN
                 CASE d.pymnt_to_type_id WHEN 'PTN' THEN NULL--ttk_util_pkg.fn_decrypt(pa.bank_name) 
                                          ELSE ttk_util_pkg.fn_decrypt(w.bank_name) 
                  END 
               ELSE NULL END as BANK_NAME,
         CASE WHEN d.claim_type = 'CNH' THEN
                 CASE d.pymnt_to_type_id WHEN 'PTN' THEN NULL--ttk_util_pkg.fn_decrypt(pa.bank_ifsc) 
                                          ELSE w.bank_ifsc 
                  END 
               ELSE NULL END as BANK_CODE,
          CASE WHEN NVL(d.process_type,'RGL') = 'RGL' THEN 'YES'
               ELSE 'NO' END AS DIRECT_BILLING
         
          
        
          

      /*FROM fin_app.tpa_claims_payment A JOIN app.tpa_ins_info B ON( A.ins_seq_id = B.ins_seq_id)
          JOIN app.clm_authorization_details D ON(A.claim_seq_id = D.claim_seq_id)
          left outer join app.tpa_hosp_info ho on (a.hosp_seq_id=ho.hosp_seq_id)
          LEFT OUTER JOIN app.pat_activity_details ad on (d.claim_seq_id = ad.claim_seq_id)
          JOIN app.tpa_enr_policy H ON(H.policy_seq_id = d.policy_seq_id)
          LEFT OUTER JOIN app.tpa_ins_info ii on (a.ins_seq_id = ii.ins_seq_id)
          LEFT OUTER JOIN app.tpa_enr_policy_group teg on (h.policy_seq_id = teg.policy_seq_id)
          LEFT OUTER JOIN app.tpa_group_registration k ON (a.group_reg_seq_id = k.group_reg_seq_id)
          LEFT OUTER JOIN fin_app.tpa_float_account fa on (a.float_seq_id = fa.float_seq_id)
          LEFT OUTER JOIN fin_app.tpa_bank_accounts ba on (fa.bank_acc_seq_id = ba.bank_acc_seq_id)
          LEFT OUTER JOIN fin_app.tpa_payment_checks_details cd on (a.payment_seq_id = cd.payment_seq_id) 
          LEFT OUTER JOIN fin_app.tpa_claims_check cc on (cd.claims_chk_seq_id = cc.claims_chk_seq_id) 
          LEFT OUTER JOIN FIN_APP.TPA_DEBIT_NOTE tdn on (fa.float_seq_id = tdn.float_seq_id)     
          LEFT OUTER JOIN app.tpa_general_code g    on (fa.float_type = g.general_type_id)
          LEFT OUTER JOIN app.tpa_general_code ge   on (d.claim_type = ge.general_type_id) 
          LEFT OUTER JOIN app.tpa_general_code gen  on (a.payee_type = gen.general_type_id)
          LEFT OUTER JOIN app.tpa_general_code gene on (d.clm_status_type_id = gene.general_type_id)
          LEFT OUTER JOIN app.tpa_general_code gener on (d.benifit_type = gener.general_type_id)*/
      
     /*FROM fin_app.tpa_claims_payment A JOIN app.clm_authorization_details D ON(A.claim_seq_id = D.claim_seq_id)
          JOIN app.tpa_enr_policy H ON(H.policy_seq_id = d.policy_seq_id)
          left outer join app.tpa_hosp_info ho on (a.hosp_seq_id=ho.hosp_seq_id)
          left outer join tpa_enr_policy_member pm on (pm.member_seq_id=d.member_seq_id)
          LEFT OUTER JOIN app.tpa_enr_policy_group teg on (pm.policy_group_seq_id = teg.policy_group_seq_id)
          LEFT OUTER JOIN app.tpa_ins_info ii on (d.ins_seq_id = ii.ins_seq_id)
          LEFT OUTER JOIN app.tpa_group_registration k ON (a.group_reg_seq_id = k.group_reg_seq_id)
          LEFT OUTER JOIN fin_app.tpa_float_account fa on (a.float_seq_id = fa.float_seq_id)
          LEFT OUTER JOIN fin_app.tpa_debit_note_claims_assoc cas on (cas.claim_seq_id=d.claim_seq_id)
          LEFT OUTER JOIN FIN_APP.TPA_DEBIT_NOTE tdn on (cas.debit_seq_id = tdn.debit_seq_id)
          LEFT OUTER JOIN fin_app.tpa_bank_accounts ba on (fa.bank_acc_seq_id = ba.bank_acc_seq_id)
          LEFT OUTER JOIN fin_app.tpa_payment_checks_details cd on (a.payment_seq_id = cd.payment_seq_id) 
          LEFT OUTER JOIN fin_app.tpa_claims_check cc on (cd.claims_chk_seq_id = cc.claims_chk_seq_id) 
          LEFT OUTER JOIN app.tpa_general_code g    on (fa.float_type = g.general_type_id)
          LEFT OUTER JOIN app.tpa_general_code ge   on (d.claim_type = ge.general_type_id) 
          LEFT OUTER JOIN app.tpa_general_code gen  on (a.payee_type = gen.general_type_id)
          LEFT OUTER JOIN app.tpa_general_code gene on (d.clm_status_type_id = gene.general_type_id)
          LEFT OUTER JOIN app.tpa_general_code gener on (d.benifit_type = gener.general_type_id)
          LEFT JOIN      app.tpa_ins_product tip     on (tip.ins_seq_id = ii.ins_seq_id
                                                        AND tip.product_seq_id = h.product_seq_id)
          LEFT JOIN app.clm_batch_upload_details cb on (cb.clm_batch_seq_id = d.clm_batch_seq_id)
          LEFT OUTER JOIN tpa_hosp_account_details W ON(hO.hosp_seq_id=w.hosp_seq_id)
          LEFT OUTER JOIN tpa_partner_info pi ON (D.ptnr_seq_id=pi.ptnr_seq_id)
          LEFT OUTER JOIN tpa_partner_account_details pa ON (pi.ptnr_seq_id=pa.ptnr_seq_id)
      WHERE (a.claim_payment_status = 'PAID' AND (cc.check_status != 'CSV' OR cc.check_status = 'CSV' ))
        AND (str_tab(1) is null or ii.ins_seq_id = str_tab(1))
        AND (str_tab(2) is null or fa.float_account_number = str_tab(2))
        AND (str_tab(3) is null or tdn.debit_note_number = str_tab(3))
        AND (str_tab(4) is null or  upper(ho.hosp_name) like upper(str_tab(4))||'%')
        AND (str_tab(5) is null or upper(k.group_name)  like  upper(str_tab(5))||'%')
        AND ((to_date(str_tab(6),'dd/mm/yyyy') is null and to_date(str_tab(7),'dd/mm/yyyy') is null)
              or (to_date(str_tab(6),'dd/mm/yyyy') is null and cc.check_date <= to_date(str_tab(7),'dd/mm/yyyy'))
              or (to_date(str_tab(7),'dd/mm/yyyy') is null and cc.check_date between to_date(str_tab(6),'dd/mm/yyyy') and sysdate)
              or( to_date(str_tab(6),'dd/mm/yyyy') is not null and to_date(str_tab(7),'dd/mm/yyyy') is not null  
                  and cc.check_date between to_date(str_tab(6),'dd/mm/yyyy') and to_date(str_tab(7),'dd/mm/yyyy')
                  )
             )
      AND (str_tab(8) is null or upper(k.group_id) = upper(str_tab(8)))     
      ORDER BY ii.ins_comp_code_number, check_date;

  END  claims_details_report;*/
--=============================================================================================
 --this procedure is used to get FLOAT STATEMENT EXCEL FORMAT OF BANGALORE ORIENTAL INSURANCE.
  /*PROCEDURE float_statement_report(
    where_clause    IN  VARCHAR2,
    result_set      OUT SYS_REFCURSOR
  )
  IS
  str_tab                ttk_util_pkg.str_table_type;
  v_sql_str              VARCHAR2(4000);
  v_current_balance      tpa_float_account.current_balance%TYPE;
  v_float_trans_amt      tpa_float_transaction.flt_trn_amount%TYPE;
  BEGIN
  str_tab               := ttk_util_pkg.parse_str ( where_clause );

  --get the float balance upto the from date
 \* SELECT a.current_balance INTO v_current_balance
  FROM tpa_float_balances a
  WHERE a.float_seq_id = TO_NUMBER(str_tab(2))
  AND TRUNC(a.float_balance_date) <= TO_DATE(str_tab(3),'DD/MM/YYYY');*\

  --get the float transaction between the dates mentioned.
  SELECT SUM(a.flt_trn_amount) INTO v_float_trans_amt
  FROM tpa_float_transaction a
  WHERE a.float_seq_id = TO_NUMBER(str_tab(2))
  AND TRUNC(a.flt_trn_date) BETWEEN TO_DATE(str_tab(3),'DD/MM/YYYY') AND TO_DATE(str_tab(4),'DD/MM/YYYY');

  v_sql_str := 'SELECT 1 AS slno,
                       a.claim_settlement_no as claim_settl_no,
                       e.ins_office_general_type_id,
                       e.ins_comp_code_number,
                       f.policy_number,
                       g.insured_name,
                       h.claimant_name,
                       a.payee_name,
                       TO_CHAR(c.check_date,''DD/MM/YYYY'') AS CHECK_DATE,
                       c.check_num,
                       c.check_amount,
                       '||v_current_balance||' as current_balance,
                       '||v_float_trans_amt||' as float_trans_amt

               FROM tpa_claims_payment A JOIN tpa_payment_checks_details B ON (a.payment_seq_id = b.payment_seq_id)
               JOIN tpa_claims_check C ON (C.claims_chk_seq_id = b.claims_chk_seq_id)
               JOIN tpa_float_account D ON (D.Float_Seq_Id = a.float_seq_id)
               JOIN tpa_ins_info E ON (e.ins_seq_id = a.ins_seq_id)
               JOIN tpa_enr_policy F ON (f.policy_seq_id = a.policy_seq_id)
               JOIN tpa_enr_policy_group G ON (f.policy_seq_id = g.policy_seq_id)
               JOIN clm_enroll_details H ON (h.claim_seq_id = a.claim_seq_id)
               WHERE d.float_seq_id = '||str_tab(2)||'
               AND a.claim_payment_status = ''PAID''
               AND TRUNC (c.check_date) BETWEEN TO_DATE('''|| str_tab(3) ||''',''dd/mm/yyyy'') AND TO_DATE('''|| str_tab(4) ||''',''dd/mm/yyyy'')';

    v_sql_str := 'SELECT * FROM ('||v_sql_str||') ORDER BY claim_settl_no';

   -- INSERT INTO TEMP VALUES(v_sql_str);
   -- COMMIT;
    OPEN result_set FOR v_sql_str;

  END float_statement_report;*/
--=========================================================================================================
  /*PROCEDURE float_statement_summary(
    where_clause    IN  VARCHAR2,
    result_set      OUT SYS_REFCURSOR
  )
  IS
  str_tab                ttk_util_pkg.str_table_type;
  v_sql_str              VARCHAR2(4000);
  v_current_balance      tpa_float_account.current_balance%TYPE;
  v_float_trans_amt      tpa_float_transaction.flt_trn_amount%TYPE;
  BEGIN
  str_tab               := ttk_util_pkg.parse_str ( where_clause );

  --get the float balance upto the from date
  \*SELECT a.current_balance INTO v_current_balance
  FROM tpa_float_balances a
  WHERE a.float_seq_id = TO_NUMBER(str_tab(2))
  AND TRUNC(a.float_balance_date) <= TO_DATE(str_tab(3),'DD/MM/YYYY');*\

  --get the float transaction between the dates mentioned.
  SELECT SUM(a.flt_trn_amount) INTO v_float_trans_amt
  FROM tpa_float_transaction a
  WHERE a.float_seq_id = TO_NUMBER(str_tab(2))
  AND TRUNC(a.flt_trn_date) BETWEEN TO_DATE(str_tab(3),'DD/MM/YYYY') AND TO_DATE(str_tab(4),'DD/MM/YYYY');
 -- GROUP BY a.flt_trn_type;

  v_sql_str := 'SELECT  e.ins_office_general_type_id AS typed,
                        --''A'' AS flag,
                        e.ins_comp_code_number AS num,
                        SUM(c.check_amount) AS amt,
                        '||v_current_balance||' AS FLOAT_BALANCE,
                        '||v_float_trans_amt||' AS FLOAT_TRANS_BALANCE

               FROM tpa_claims_payment A JOIN tpa_payment_checks_details B ON (a.payment_seq_id = b.payment_seq_id)
               JOIN tpa_claims_check C ON (C.claims_chk_seq_id = b.claims_chk_seq_id)
               JOIN tpa_float_account D ON (D.Float_Seq_Id = a.float_seq_id)
               JOIN tpa_ins_info E ON (e.ins_seq_id = a.ins_seq_id)
               WHERE d.float_seq_id = '||TO_NUMBER(str_tab(2))||'
               AND TRUNC (c.check_date) BETWEEN TO_DATE('''|| str_tab(3)||''',''dd/mm/yyyy'') AND TO_DATE('''|| str_tab(4) ||''',''dd/mm/yyyy'')
               AND a.claim_payment_status = ''PAID''
               --AND E.ins_office_general_type_id  = ''IHO''
               GROUP BY  e.ins_office_general_type_id,e.ins_comp_code_number';

    v_sql_str := 'SELECT * FROM ('|| v_sql_str ||' )';
  -- INSERT INTO TEMP VALUES (V_SQL_STR);
   --COMMIT;
   OPEN result_set FOR V_SQL_STR;
  END  float_statement_summary;

  \*v_sql_str := 'SELECT  e.ins_office_general_type_id AS typed,
                        ''A'' AS flag,
                        e.ins_comp_code_number AS num,
                        SUM(c.check_amount) AS amt

               FROM tpa_claims_payment A JOIN tpa_payment_checks_details B ON (a.payment_seq_id = b.payment_seq_id)
               JOIN tpa_claims_check C ON (C.claims_chk_seq_id = b.claims_chk_seq_id)
               JOIN tpa_float_account D ON (D.Float_Seq_Id = a.float_seq_id)
               JOIN tpa_ins_info E ON (e.ins_seq_id = a.ins_seq_id)
               WHERE d.float_seq_id = '||TO_NUMBER(str_tab(2))||'
               AND TRUNC (c.check_date) BETWEEN TO_DATE('''|| str_tab(3)||''',''dd/mm/yyyy'') AND TO_DATE('''|| str_tab(4) ||''',''dd/mm/yyyy'')
               AND E.ins_office_general_type_id  = ''IHO''
               GROUP BY  e.ins_office_general_type_id,e.ins_comp_code_number
               UNION
               SELECT  e.ins_office_general_type_id AS typed,
                        ''B'' AS flag,
                        e.ins_comp_code_number AS num,
                        SUM(c.check_amount) AS amt

               FROM tpa_claims_payment A JOIN tpa_payment_checks_details B ON (a.payment_seq_id = b.payment_seq_id)
               JOIN tpa_claims_check C ON (C.claims_chk_seq_id = b.claims_chk_seq_id)
               JOIN tpa_float_account D ON (D.Float_Seq_Id = a.float_seq_id)
               JOIN tpa_ins_info E ON (e.ins_seq_id = a.ins_seq_id)
               WHERE d.float_seq_id = '||TO_NUMBER(str_tab(2))||'
               AND TRUNC (c.check_date) BETWEEN TO_DATE('''|| str_tab(3)||''',''dd/mm/yyyy'') AND TO_DATE('''|| str_tab(4) ||''',''dd/mm/yyyy'')
               AND E.ins_office_general_type_id  = ''IRO''
               GROUP BY  e.ins_office_general_type_id,e.ins_comp_code_number';*\


    \*V_SQL_STR := ' SELECT '||v_current_balance||' AS FLAOT_BALANCE,
                          '||v_float_trans_amt||' AS FLOAT_TRANS_BALANCE,
                          typed,
                          num AS NUM,
                          DECODE (flag ,''A'' ,AMT,0) HEAD_BALANCE ,
                          DECODE (flag ,''B'' ,AMT,0) REGION_BALANCE
                   FROM ('||V_SQL_STR ||') ORDER BY NUM ';*\
                   */
--====================================================================================================================
--this function using to get ailment description in 22 column for claim_details_report
  FUNCTION get_ailments(
     v_calims_seq_id           NUMBER ) RETURN VARCHAR2 DETERMINISTIC
  IS
     v_ailment_str  VARCHAR2(1000);
     v_ctr  NUMBER := 0;
     CURSOR v_cur IS SELECT a.ailment_description FROM ailment_details a
        WHERE a.claim_seq_id = v_calims_seq_id ;
  BEGIN
    FOR i IN v_cur
    LOOP
      IF v_ctr = 0 THEN
         v_ailment_str := i.ailment_description ;
         v_ctr         := v_ctr + 1;
      ELSE
         v_ailment_str := v_ailment_str ||','|| i.ailment_description ;
      END IF;
    END LOOP;

    RETURN v_ailment_str;
  end get_ailments;
--========================================================================================
/*
  Input parameters
    - for debit note    |S|<debit_seq_id>|||D||||
    - for float account |S|<float_account_number>|<From date>|<To date>|F||||
    - for EFT details   |S|<float_account_number>|<From date>|<To date>|F|<group_id>|<Claim type>|<batch No.>|
*/
  /*PROCEDURE claims_pending_report(
     where_clause              IN  VARCHAR2,
     v_result_set                 OUT SYS_REFCURSOR
  )
  IS
    str_tab                ttk_util_pkg.str_table_type;
    v_sql_stmt             VARCHAR2(8000);
    TYPE bind_tab_type IS  TABLE OF VARCHAR2(250) INDEX BY BINARY_INTEGER ;
    bind_tab               bind_tab_type;
    i                      NUMBER(2) := 0;
  BEGIN
    str_tab     := ttk_util_pkg.parse_str ( where_clause );

    v_sql_stmt := 'SELECT I.office_name,
          B.ins_comp_name,
          B.ins_comp_code_number ,
          B.abbrevation_code,
          E.tpa_enrollment_id AS tpa_id_no,
          E.policy_number,
          d.claim_number AS claim_no,
          k.group_name ,
          E.claimant_name,
          j.mem_age,
          n.relship_description ,
          g.insured_name ,
          H.policy_agent_code,
          a.claim_settlement_no,
          TO_CHAR(F.dv_sent_date,''DD/MM/YYYY'') AS dv_sent_date,
          TO_CHAR(F.dv_received_date ,''DD/MM/YYYY'') AS dv_received_date,
          I.office_code ,
          D.requested_amount ,
          D.total_app_amount,
          NVL(o.hosp_name,w.hosp_name ) AS hosp_name ,
          TO_CHAR(v.rcvd_date,''DD/MM/YYYY'') AS claim_intimation_date,
          TO_CHAR(d.date_of_admission,''DD/MM/YYYY'') AS date_of_admission,
          TO_CHAR(d.date_of_discharge,''DD/MM/YYYY'') AS date_of_discharge,
          s.total_app_amount AS al_amt,
          TO_CHAR(r.decision_date,''DD/MM/YYYY'') AS al_date,
          t.sum_insured + t.bonus - t.utilised_sum_insured - t.utilised_cum_bonus AS balance_sum_insured ,
          d.claim_file_number ,
          CASE WHEN a.claim_type = ''CTM'' AND NVL(D.PAY_TO_GENERAL_TYPE_ID,''MBR'')!=''HSL'' THEN  D.total_app_amount ELSE NULL END AS amt_paid_beneficiary,
          CASE WHEN a.claim_type = ''CNH'' OR NVL(D.PAY_TO_GENERAL_TYPE_ID,''MBR'')=''HSL'' THEN  D.total_app_amount ELSE NULL END AS amt_paid_hospital,
          NULL AS deposit_to,
          v.claims_inward_no AS claim_app_no,
          G.employee_no AS emp_no,
          batch_report_pkg.get_icds(A.claim_seq_id ) AS ailment,
          batch_report_pkg.get_billno(A.claim_seq_id ) AS bill_nos,
          batch_report_pkg.get_hospitalization( A.claim_seq_id , d.date_of_admission, d.date_of_discharge ) AS pre_post,
          D.requested_amount - d.total_app_amount AS disc_amt,
          (SELECT COUNT(1) FROM clm_enroll_details Y WHERE Y.member_seq_id = e.member_seq_id ) AS no_claims ,
          u.remarks AS remarks ,
          CASE WHEN j.mem_general_type_id = ''PFL'' THEN G.family_tot_sum_insured ELSE J.mem_tot_sum_insured END AS sum_insured,
          TO_CHAR(H.EFFECTIVE_FROM_DATE,''DD/MM/YYYY'') AS POLICY_START_DATE,
          to_char(h.effective_to_date,''DD/MM/YYYY'') AS POLICY_END_DATE,
          a.claim_payment_status,
          a.approved_amount,
          nvl(cct.city_description, w.city_name) AS Location,
          pl.Office_Name AS clm_processed_location
      FROM tpa_claims_payment A JOIN tpa_ins_info B ON( A.ins_seq_id = B.ins_seq_id)
          JOIN clm_general_details D ON(A.claim_seq_id = D.claim_seq_id)
          JOIN clm_enroll_details E ON ( D.claim_seq_id = E.claim_seq_id )
          LEFT OUTER JOIN clm_discharge_voucher F ON (D.claim_seq_id = F.claim_seq_id)
          JOIN tpa_enr_policy_member J ON (a.member_seq_id = j.member_seq_id)
          JOIN tpa_enr_policy_group G ON (j.policy_group_seq_id = g.policy_group_seq_id )
          JOIN tpa_enr_policy H ON(H.policy_seq_id = G.policy_seq_id)
          JOIN tpa_office_info I ON( H.tpa_office_seq_id  = I.tpa_office_seq_id)
          LEFT OUTER JOIN tpa_group_registration k ON (a.group_reg_seq_id = k.group_reg_seq_id)
          JOIN tpa_relationship_code n ON (j.relship_type_id = n.relship_type_id)
          LEFT OUTER JOIN tpa_hosp_info o ON (a.hosp_seq_id = o.hosp_seq_id)
          LEFT OUTER JOIN tpa_hosp_address ha ON o.hosp_seq_id = ha.hosp_seq_id
          LEFT OUTER JOIN tpa_city_code cct ON ha.city_type_id = cct.city_type_id
          LEFT OUTER JOIN pat_enroll_details r ON (d.pat_enroll_detail_seq_id = r.pat_enroll_detail_seq_id)
          LEFT OUTER JOIN pat_general_details s ON (r.pat_enroll_detail_seq_id = s.pat_enroll_detail_seq_id AND s.pat_enhanced_yn = ''N'')
          JOIN tpa_enr_balance T ON ((J.policy_group_seq_id = T.policy_group_seq_id AND J.mem_general_type_id = ''PFL'') OR
                                     (J.mem_general_type_id != ''PFL'' AND J.Member_Seq_Id = t.member_seq_id ))
          LEFT OUTER JOIN assign_users U ON (d.last_assign_user_seq_id = u.assign_users_seq_id)
          LEFT OUTER JOIN tpa_office_info pl ON U.Tpa_Office_Seq_Id = pl.tpa_office_seq_id
          JOIN clm_inward V ON (d.claims_inward_seq_id = v.claims_inward_seq_id)
          LEFT OUTER JOIN clm_hospital_association w ON (a.claim_seq_id = w.claim_seq_id)';
      IF str_tab(5) = 'F' THEN
          v_sql_stmt := v_sql_stmt||' JOIN tpa_float_account fa ON fa.float_seq_id = A.float_seq_id and fa.float_account_number = :v_float_acct_no ';
          i := 3;
          bind_tab(1) := str_tab(2);
          bind_tab(2) := to_date(str_tab(3),'dd/mm/yyyy');
          bind_tab(3) := to_date(str_tab(4),'dd/mm/yyyy')+1;
          v_sql_stmt := v_sql_stmt||' WHERE a.claim_aprv_date BETWEEN :v_from_date AND :v_to_date
                                      AND a.claim_payment_status  IN (''PENDING'',''READY_TO_BANK'',''SENT_TO_BANK'')';
          --v_sql_stmt := v_sql_stmt||' AND a.claim_payment_status  IN (''PENDING'',''READY_TO_BANK'',''SENT_TO_BANK'')';

          IF str_tab(6) IS NOT NULL THEN
             i := i+1;
             bind_tab(i) := str_tab(6);
             v_sql_stmt := v_sql_stmt||' AND k.group_id = :v_group_id';
          END IF ;
          IF str_tab(7) IS NOT NULL THEN
             i := i+1;
             bind_tab(i) := str_tab(7);
             v_sql_stmt := v_sql_stmt||' AND a.claim_type = :v_claim_type';
          END IF ;
          IF str_tab(8) IS NOT NULL THEN
             i := i+1;
             bind_tab(i) := str_tab(8);
             v_sql_stmt := v_sql_stmt||' AND a.batch_number_manual = :v_batch_number_manual';
          END IF ;
       ELSE -- str_tab(5) = 'D'
          i := 1;
          bind_tab(i) := str_tab(2);
          v_sql_stmt := v_sql_stmt||' WHERE a.claim_seq_id IN (SELECT claim_seq_id FROM tpa_debit_note_claims_assoc
                                                                  WHERE debit_seq_id = :v_debit_seq_id)
                                        AND a.claim_payment_status = ''DEBIT_NOTE_ATTACHED''';
       END IF;
       v_sql_stmt := v_sql_stmt||' ORDER BY I.office_name, I.office_code, B.ins_comp_name, B.ins_comp_code_number';

       IF bind_tab.FIRST IS NOT NULL THEN
          CASE bind_tab.COUNT
               WHEN 1 THEN OPEN v_result_set FOR v_sql_stmt USING bind_tab(1);
               WHEN 2 THEN OPEN v_result_set FOR v_sql_stmt USING bind_tab(1), bind_tab(2);
               WHEN 3 THEN OPEN v_result_set FOR v_sql_stmt USING bind_tab(1), bind_tab(2), bind_tab(3);
               WHEN 4 THEN OPEN v_result_set FOR v_sql_stmt USING bind_tab(1), bind_tab(2), bind_tab(3), bind_tab(4);
               WHEN 5 THEN OPEN v_result_set FOR v_sql_stmt USING bind_tab(1), bind_tab(2), bind_tab(3), bind_tab(4), bind_tab(5);
               WHEN 6 THEN OPEN v_result_set FOR v_sql_stmt USING bind_tab(1), bind_tab(2), bind_tab(3), bind_tab(4), bind_tab(5), bind_tab(6);
          END CASE;
       ELSE
          OPEN v_result_set FOR v_sql_stmt;
       END IF;

  END  claims_pending_report;*/
--==================================================================================================
PROCEDURE claims_pending_report(
     where_clause              IN  VARCHAR2,
     v_result_set                 OUT SYS_REFCURSOR
  )
  IS
    str_tab                ttk_util_pkg.str_table_type;
    v_sql_stmt             VARCHAR2(8000);
    TYPE bind_tab_type IS  TABLE OF VARCHAR2(250) INDEX BY BINARY_INTEGER ;
    bind_tab               bind_tab_type;
    i                      NUMBER(2) := 0;
    v_date_cond varchar2(200) ;
    v_count                NUMBER(10);
    
    
    v_from_date            date ;
    v_to_date              date ;
    v_sqlstr               VARCHAR2(32000);
    v_where                VARCHAR2(4000);
    v_claim_type           VARCHAR2(30);
    v_payment_status       VARCHAR2(30);
    
   CURSOR Float_acc_Details (v_flaot_number VARCHAR2) is
     SELECT FLOAT_ACCOUNT_NUMBER,COUNT(float_seq_id)  
     FROM tpa_float_account 
     WHERE float_account_number =v_flaot_number
     Group by FLOAT_ACCOUNT_NUMBER;
     
     
  BEGIN

   
    str_tab     := ttk_util_pkg.parse_str ( where_clause );
    
     OPEN Float_acc_Details(str_tab(2));
         FETCH Float_acc_Details INTO str_tab(2),v_count;
           CLOSE Float_acc_Details;
           
  If NVL(v_count,0)=0 then 
     Raise_Application_error ('-20922','Given Float Account is not Avilable');         
   end if;
   
   v_sqlstr:='SELECT 
                  ii.ins_comp_name, 
                  CASE WHEN D.CLAIM_TYPE=''CTM'' THEN
                     (case when  H.tpa_cheque_issued_general_type=''IQC'' THEN K.GROUP_NAME  
                       WHEN H.tpa_cheque_issued_general_type=''IQI'' THEN teg.insured_name
										END ) 
									ELSE 
                   CASE WHEN D.CLAIM_TYPE=''CNH'' THEN
                       (case when NVL(D.pymnt_to_type_id,''HOS'') =''PTN'' THEN
											 pi.partner_name
											 ELSE
											 HO.HOSP_NAME END)
									END		 
									END as insured_name,				  
				          ii.ins_comp_code_number,
				          ii.abbrevation_code,
                  d.Invoice_Number,
                  ho.Empanel_Number,
                  ho.hosp_licenc_numb as Provider_License_No,
                  fa.float_account_number as Float_Account_No, 
                  ba.account_number as Bank_Account_No,  
                  g.description as Float_Model,  
                  k.group_name,
                  k.group_id,  
                  h.policy_number,
                  tip.product_name as Plan,
                  d.tpa_enrollment_id as tpa_id_no, 
                  d.claim_number as Claim_No, 
                  d.settlement_number as Claim_Settlement_No,  
                  case when a.claim_type=''CTM'' THEN ''Member''
                       when a.claim_type=''CNH'' THEN ''Network'' ELSE NULL END claim_type,  
                  teg.insured_name||nvl2(teg.insured_middle_name,'' ''||teg.insured_middle_name,'''')||nvl2(teg.insured_family_name,'' ''||teg.insured_family_name,'''') as Insured_Person_Name,  
                  pm.mem_name||nvl2(pm.mem_last_name,'' ''||pm.mem_last_name,'''')||nvl2(pm.family_name,'' ''||pm.family_name,'''') as Claimant_Name,
                  d.requested_amount as INCURRED_Amount,
                  d.req_amt_currency_type as INCURRED_CURRENCY,
                  d.conversion_rate as CONVERSION_RATE_TO_QAR,
                  d.converted_amount,
		               d.converted_amount_currency_type as convertd_currency,
                  d.tot_disc_gross_amount as Total_Claim_Amt,
                  d.tot_discount_amount as Deductions,
                  d.requested_amount-d.final_app_amount as dis_allowed_amount,
                  --null as Reasons,
                  d.final_app_amount as AMOUNT_PAYABLE_In_QAR,
                  d.converted_final_approved_amt as Amount_Payable_in_Incrd_curncy,
		              d.req_amt_currency_type as Payable_in_Incrd_curncy,
                  ttk_util_pkg.fn_decrypt(a.payee_name) as payee_name,
                  CASE WHEN a.payee_type=''EFT'' THEN ''EFT''
                       WHEN a.payee_type =''PCA'' THEN ''Cheque Advice''
                       WHEN a.payee_type = ''PMM'' then ''Manual'' else null end ,  
                  cc.check_num as Payment_RefNo,  
                  to_char(cc.check_date,''dd/mm/yyyy'') as Payment_Date,
                  case when a.claim_payment_status=''SENT_TO_BANK'' then ''APPROVED BY FINANCE'' ELSE a.claim_payment_status END claim_payment_status,  
                  --a.claim_payment_status ,  
                  a.batch_number_manual as Payment_Batch_No , 
                  a.trans_ref_no as Transaction_Reference,
                  gener.description as Encounter_Type,
                  to_char(d.completed_date,''dd/mm/yyyy'') as Claim_approved_date,--clm appr date
                  gene.description as claim_Status,
                  genera.description as DN_Status,
                  tdn.debit_note_number as DN_No,
                  to_char(tdn.debit_date,''dd/mm/yyyy'') as DN_Date,
                  pm.mem_age,
                  n.relship_description,
                  ho.hosp_name,
                 TO_CHAR(d.date_of_hospitalization,''DD/MM/YYYY'') AS date_of_admission,
                 TO_CHAR(d.date_of_discharge,''DD/MM/YYYY'') AS date_of_discharge,
                 h.policy_agent_code,
                 teg.employee_no as emp_no,
                 case when d.claim_type=''CTM'' then  cc.check_amount  end as amt_paid_beneficiary,
                 case when d.claim_type =''CNH'' then  cc.check_amount  end as amt_paid_hospital,
                 d.invoice_number as bill_nos,
                 (bal.sum_insured-bal.utilised_sum_insured)as balance_sum_insured,
                 CASE WHEN pm.mem_general_type_id = ''PFL'' THEN teg.family_tot_sum_insured ELSE pm.mem_tot_sum_insured END AS sum_insured,
                 to_char(h.effective_from_date,''dd/mm/yyyy'') as policy_start_date,
                 to_char(h.effective_to_date,''dd/mm/yyyy'') as policy_end_date ,
                 (d.tot_disc_gross_amount-d.tot_approved_amount) disc_amt,
                 d.final_remarks as remarks,
                 TO_CHAR(d.clm_received_date,''DD/MM/YYYY'') AS claim_Intimation_Date,-------clm rec date
                 d.claim_file_number,
                 d.requested_amount,
                 d.final_app_amount as total_app_amount,
                 icd.SHORT_DESC as ailment,
				         w.city_name   as Location,
				         i.office_name,
				         i.office_code,
                 
                  to_char(tdn.debit_date,''dd/mm/yyyy'') as DN_Date,
                  --CASE d.process_type WHEN ''DBL'' THEN ''Yes'' ELSE ''No'' END AS Direct_Billing,
                 /* CASE WHEN d.claim_type = ''CNH'' THEN
                         CASE d.pymnt_to_type_id WHEN ''PTN'' THEN NULL--ttk_util_pkg.fn_decrypt(pa.account_number) 
                                                  ELSE ttk_util_pkg.fn_decrypt(w.account_number) 
                          END 
                       ELSE NULL END as ACCOUNT_NO,
                   CASE WHEN d.claim_type = ''CNH'' THEN
                           CASE d.pymnt_to_type_id WHEN ''PTN'' THEN NULL--ttk_util_pkg.fn_decrypt(pa.bank_micr) 
                                                    ELSE w.bank_micr 
                            END 
                         ELSE NULL END as IBAN_NO,
                   CASE WHEN d.claim_type = ''CNH'' THEN
                           CASE d.pymnt_to_type_id WHEN ''PTN'' THEN NULL--ttk_util_pkg.fn_decrypt(pa.bank_name) 
                                                    ELSE ttk_util_pkg.fn_decrypt(w.bank_name) 
                            END 
                         ELSE NULL END as BANK_NAME,
                   CASE WHEN d.claim_type = ''CNH'' THEN
                           CASE d.pymnt_to_type_id WHEN ''PTN'' THEN NULL--ttk_util_pkg.fn_decrypt(pa.bank_ifsc) 
                                                    ELSE w.bank_ifsc 
                            END 
                         ELSE NULL END as BANK_CODE,*/
          CASE WHEN NVL(d.process_type,''RGL'') = ''RGL'' THEN ''NO''
               ELSE ''YES'' END AS DIRECT_BILLING ,
                  d.pay_amt_in_usd as usd_amount,
                 a.transfer_currency as AMNT_TRANSFERRED_CURR,
          ----- added in finance log & report Cr
                 CASE  WHEN a.payee_type = ''EFT'' then ''ONLINE'' 
                       WHEN a.payee_type IN (''PMM'',''PCA'') then ''CHEQUE''
                       END as "PAYMENT_MODE",
                 to_char(batc.added_date,''DD/MM/YYYY'') as cheque_date,
                 nvl(a.batch_number_manual,a.bank_advice_batch) as "BATCH_NO",
                 case when TTK_UTIL_PKG.FN_DECRYPT(A.payee_name)=ref.payee_name then ref.TRANS_NUM end as trans_ref_num,
                 pi.partner_name as partner_name,
                 cc.check_num as payment_ref_no,
                 (trunc(sysdate)-trunc(d.clm_received_date)) as ageing_recived_date,
                 (trunc(sysdate)-trunc(d.completed_date))as ageing_approved_date,
                 clmb.BATCH_NO AS CLAIM_BATCH_NO,
                CASE  WHEN a.claim_type = ''CTM'' THEN
                         (CASE WHEN h.enrol_type_id = ''COR'' THEN
                             CASE WHEN NVL(clmb.claimfrom_gentype_id,''INSU'')!=''EMBA'' THEN
                              (CASE WHEN a.TPA_CHEQUE_ISSUED_GENERAL_TYPE = ''IQI'' THEN  ttk_util_pkg.fn_decrypt(t.bank_micr)
                                    WHEN a.TPA_CHEQUE_ISSUED_GENERAL_TYPE = ''IQC'' THEN  ttk_util_pkg.fn_decrypt(S.Bank_Micr) END)
                            ELSE
                                      ttk_util_pkg.fn_decrypt(EMBB.BANK_MICR) 
                            END
                          
                          ELSE ttk_util_pkg.fn_decrypt(t.bank_micr) END)
                   ELSE
                      CASE d.pymnt_to_type_id WHEN ''PTN'' THEN ttk_util_pkg.fn_decrypt(pa.bank_micr) 
                                               ELSE ttk_util_pkg.fn_decrypt(ad.bank_micr) 
                   END
                  end as IBANNO,
                  CASE  WHEN a.claim_type = ''CTM'' THEN
                         (CASE WHEN h.enrol_type_id = ''COR'' THEN
                             CASE WHEN NVL(clmb.claimfrom_gentype_id,''INSU'')!=''EMBA'' THEN
                              (CASE WHEN a.TPA_CHEQUE_ISSUED_GENERAL_TYPE = ''IQI'' THEN  ttk_util_pkg.fn_decrypt(t.bank_ifsc)
                                    WHEN a.TPA_CHEQUE_ISSUED_GENERAL_TYPE = ''IQC'' THEN  ttk_util_pkg.fn_decrypt(S.bank_ifsc) END)
                            ELSE
                                      ttk_util_pkg.fn_decrypt(EMBB.bank_ifsc) 
                            END
                          
                          ELSE ttk_util_pkg.fn_decrypt(t.bank_ifsc) END)
                   ELSE
                      CASE d.pymnt_to_type_id WHEN ''PTN'' THEN ttk_util_pkg.fn_decrypt(pa.bank_ifsc) 
                                               ELSE ttk_util_pkg.fn_decrypt(ad.bank_ifsc) 
                   END
                  end as SWIFT_CODE,
                  CASE  WHEN a.claim_type = ''CTM'' THEN
                         (CASE WHEN h.enrol_type_id = ''COR'' THEN
                             CASE WHEN NVL(clmb.claimfrom_gentype_id,''INSU'')!=''EMBA'' THEN
                              (CASE WHEN a.TPA_CHEQUE_ISSUED_GENERAL_TYPE = ''IQI'' THEN  ttk_util_pkg.fn_decrypt(t.bank_name)
                                    WHEN a.TPA_CHEQUE_ISSUED_GENERAL_TYPE = ''IQC'' THEN  ttk_util_pkg.fn_decrypt(S.bank_name) END)
                            ELSE
                                      ttk_util_pkg.fn_decrypt(EMBB.bank_name) 
                            END
                          
                          ELSE ttk_util_pkg.fn_decrypt(t.bank_name) END)
                   ELSE
                      CASE d.pymnt_to_type_id WHEN ''PTN'' THEN ttk_util_pkg.fn_decrypt(pa.bank_name) 
                                               ELSE ttk_util_pkg.fn_decrypt(ad.bank_name) 
                   END
                  end as BANK_NAME,
                  CASE  WHEN a.claim_type = ''CTM'' THEN
                         (CASE WHEN h.enrol_type_id = ''COR'' THEN
                             CASE WHEN NVL(clmb.claimfrom_gentype_id,''INSU'')!=''EMBA'' THEN
                              (CASE WHEN a.TPA_CHEQUE_ISSUED_GENERAL_TYPE = ''IQI'' THEN  ttk_util_pkg.fn_decrypt(t.bank_account_no)
                                    WHEN a.TPA_CHEQUE_ISSUED_GENERAL_TYPE = ''IQC'' THEN  ttk_util_pkg.fn_decrypt(S.bank_account_no) END)
                            ELSE
                                      ttk_util_pkg.fn_decrypt(EMBB.bank_account_no) 
                            END
                          
                          ELSE ttk_util_pkg.fn_decrypt(t.bank_account_no) END)
                   ELSE
                      CASE d.pymnt_to_type_id WHEN ''PTN'' THEN ttk_util_pkg.fn_decrypt(pa.account_number) 
                                               ELSE ttk_util_pkg.fn_decrypt(ad.account_number) 
                   END
                  end as ACC_NUM,
      CASE  WHEN a.claim_type = ''CTM'' THEN
           CASE WHEN h.enrol_type_id = ''COR'' THEN
                   CASE WHEN NVL(clmb.claimfrom_gentype_id,''INSU'')!=''EMBA'' THEN
                      CASE WHEN a.TPA_CHEQUE_ISSUED_GENERAL_TYPE = ''IQI'' THEN  
                        
                                case when NVL(t.ACCOUNT_IN_QATAR_YN,''NA'')=''Y'' then ''Within Qatar'' 
                                     when NVL(t.ACCOUNT_IN_QATAR_YN,''NA'')=''N'' then ''Outside Qatar''
                                  ELSE null end                     
                            
                       WHEN a.TPA_CHEQUE_ISSUED_GENERAL_TYPE = ''IQC'' THEN 
                         
                       case when NVL(s.ACCOUNT_IN_QATAR_YN,''NA'')=''Y'' then ''Within Qatar'' 
                            when NVL(s.ACCOUNT_IN_QATAR_YN,''NA'')=''N'' then ''Outside Qatar''
                         ELSE null end 
                                 
                            END
                            ELSE
                              case when NVL(EMBB.ACCOUNT_IN_QATAR_YN,''NA'')=''Y'' then ''Within Qatar''
                                   when NVL(EMBB.ACCOUNT_IN_QATAR_YN,''NA'')=''N'' then ''Outside Qatar''
                                 ELSE NULL end
                                      
                            END
                          
                          ELSE 
                            case when NVL(t.ACCOUNT_IN_QATAR_YN,''NA'')=''Y'' then ''Within Qatar'' 
                                     when NVL(t.ACCOUNT_IN_QATAR_YN,''NA'')=''N'' then ''Outside Qatar''
                                  ELSE null end  
                              end 
                   ELSE
                      CASE d.pymnt_to_type_id WHEN ''PTN'' THEN 
                        case when NVL(pa.ACCOUNT_IN_QATAR_YN,''NA'')=''Y'' then ''Within Qatar'' 
                                     when NVL(pa.ACCOUNT_IN_QATAR_YN,''NA'')=''N'' then ''Outside Qatar''
                                  ELSE null end  
                                        ELSE 
                                          case when NVL(ad.ACCOUNT_IN_QATAR_YN,''NA'')=''Y'' then ''Within Qatar'' 
                                     when NVL(ad.ACCOUNT_IN_QATAR_YN,''NA'')=''N'' then ''Outside Qatar''
                                  ELSE null end  
                   END
                  end as ACC_NAME,
                  ho.EMPANEL_NUMBER        
    FROM fin_app.tpa_claims_payment A 
          JOIN app.clm_authorization_details D ON(A.claim_seq_id = D.claim_seq_id)
          JOIN diagnosys_details dd on (d.claim_seq_id=dd.claim_seq_id AND dd.primary_ailment_yn=''Y'')
          JOIN APP.clm_batch_upload_details clmb on (clmb.clm_batch_seq_id=d.clm_batch_seq_id)
          LEFT OUTER JOIN app.tpa_icd10_master_details icd on (icd.icd_code=dd.diagnosys_code)
          JOIN app.tpa_enr_policy H ON(H.policy_seq_id = d.policy_seq_id)
		      JOIN tpa_office_info I ON( H.tpa_office_seq_id  = I.tpa_office_seq_id)
          left outer join app.tpa_hosp_info ho on (a.hosp_seq_id=ho.hosp_seq_id)
          join tpa_enr_policy_member pm on (pm.member_seq_id=d.member_seq_id)
          JOIN tpa_relationship_code n ON (pm.relship_type_id = n.relship_type_id)
          JOIN tpa_enr_balance bal ON ( pm.policy_group_seq_id= bal.policy_group_seq_id AND pm.mem_general_type_id = ''PFL'') 
                  OR (pm.mem_general_type_id != ''PFL'' AND pm.Member_Seq_Id = bal.member_seq_id )    
          JOIN app.tpa_enr_policy_group teg on (pm.policy_group_seq_id = teg.policy_group_seq_id)
          JOIN app.tpa_ins_info ii on (d.ins_seq_id = ii.ins_seq_id)
          LEFT OUTER JOIN app.tpa_group_registration k ON (a.group_reg_seq_id = k.group_reg_seq_id)
          JOIN fin_app.tpa_float_account fa on (a.float_seq_id = fa.float_seq_id)
          LEFT OUTER JOIN fin_app.tpa_debit_note_claims_assoc cas on (cas.claim_seq_id=d.claim_seq_id)
          LEFT OUTER JOIN FIN_APP.TPA_DEBIT_NOTE tdn on (cas.debit_seq_id = tdn.debit_seq_id)
          LEFT OUTER JOIN fin_app.tpa_bank_accounts ba on (fa.bank_acc_seq_id = ba.bank_acc_seq_id)
          LEFT OUTER JOIN fin_app.tpa_payment_checks_details cd on (a.payment_seq_id = cd.payment_seq_id and cd.v_csr_flag=1) 
          LEFT OUTER JOIN fin_app.tpa_claims_check cc on (cd.claims_chk_seq_id = cc.claims_chk_seq_id) 
          JOIN app.tpa_general_code g    on (fa.float_type = g.general_type_id)
          JOIN app.tpa_general_code gene on (d.clm_status_type_id = gene.general_type_id)
          JOIN app.tpa_general_code gener on (d.benifit_type = gener.general_type_id)
          LEFT OUTER JOIN app.tpa_general_code genera on (tdn.debit_status_general_type_id = genera.general_type_id)
          LEFT OUTER JOIN app.tpa_ins_product tip     on (tip.ins_seq_id = ii.ins_seq_id
                                                           AND tip.product_seq_id = h.product_seq_id)
		 LEFT OUTER JOIN app.clm_hospital_details w ON (d.claim_seq_id = w.claim_seq_id)
		 LEFT OUTER JOIN tpa_hosp_account_details W ON(hO.hosp_seq_id=w.hosp_seq_id)
         LEFT OUTER JOIN tpa_partner_info pi ON (D.ptnr_seq_id=pi.ptnr_seq_id)
         LEFT OUTER JOIN tpa_partner_account_details pa ON (pi.ptnr_seq_id=pa.ptnr_seq_id)                                                                         
         LEFT OUTER JOIN tpa_bank_advice_batch batc on (batc.batch_seq_id=a.bank_advice_batch)
         LEFT OUTER JOIN FIN_APP.trans_ref_table ref ON (ref.batch_num=batc.batch_seq_id) AND TTK_UTIL_PKG.FN_DECRYPT(a.payee_name)=ref.payee_name
         LEFT OUTER JOIN tpa_enr_bank_dtls S ON (H.bank_seq_id = S.bank_seq_id)
         LEFT OUTER JOIN tpa_enr_bank_dtls T ON (teg.bank_seq_id = T.bank_seq_id)
         LEFT OUTER JOIN APP.tpa_enr_embassy_registration EMB ON (EMB.embassy_seq_id=D.embassy_seq_id)
         LEFT OUTER JOIN APP.tpa_enr_bank_dtls embb on (embb.bank_seq_id=emb.bank_seq_id)
         LEFT OUTER JOIN tpa_hosp_info O  ON (a.hosp_seq_id = O.hosp_seq_id)
         LEFT OUTER JOIN tpa_hosp_account_details ad  ON (O.hosp_seq_id = ad.hosp_seq_id)
    WHERE fa.float_account_number ='''||str_tab(2)||'''';
  

    v_from_date      := (to_date(str_tab(3),'dd/mm/yyyy'));
    v_to_date        := (to_date(str_tab(4),'dd/mm/yyyy')+1);
    v_claim_type   	 := str_tab(5);
    v_payment_status := str_tab(6);
    
    if v_claim_type is not null then
      v_where :=v_where||'and a.claim_type = '''||v_claim_type||'''';
    end if;
    
    if v_payment_status is not null then
      v_where:=v_where||' and  a.claim_payment_status = '''||v_payment_status||''''; 
    else
      v_where :=v_where||' and a.claim_payment_status  IN (''PENDING'',''READY_TO_BANK'',''SENT_TO_BANK'')';
    end if;
    
    if v_from_date is not null and v_to_date is not null then
     v_where :=v_where||' AND d.Clm_Received_Date BETWEEN '''|| v_from_date ||''' AND '''|| v_to_date||'''';
    end if;
      
    v_sqlstr:= v_sqlstr||v_where;

   OPEN v_result_set FOR v_sqlstr;
                  
  END  claims_pending_report;
--==================================================================================================
PROCEDURE Policy_bank_dtl_report(
     where_clause              IN  VARCHAR2,
     v_result_set              OUT SYS_REFCURSOR
  )
  IS
    str_tab                ttk_util_pkg.str_table_type;
    v_sql_stmt             VARCHAR2(8000);
    TYPE bind_tab_type IS  TABLE OF VARCHAR2(250) INDEX BY BINARY_INTEGER ;
    bind_tab               bind_tab_type;
    i                      NUMBER(2) := 0;
  BEGIN
    
    str_tab     := ttk_util_pkg.parse_str ( where_clause );

   OPEN v_result_set FOR
              select
                  tep.policy_number  as PolicyNo,  
                  tem.tpa_enrollment_id as EnrolmentID , 
                  teg.insured_name as PayeeName,  
                  tgr.group_name as CorporateName ,
                  tgr.group_id   as CorporateId, 
                  g.description as Cheque_issue_to,
                  ttk_util_pkg.fn_decrypt(bd.bank_account_no) AS BANK_ACCOUNT_NUMBER,
                  null AS BANK_ACCOUNT_TYPE,
                  ttk_util_pkg.fn_decrypt(bd.bank_name) AS BANK_NAME,
                  ttk_util_pkg.fn_decrypt(bd.bank_branch) AS BRANCH_NAME, 
                  ttk_util_pkg.fn_decrypt(bd.bank_ifsc) AS BANK_IBAN 
             FROM app.tpa_enr_policy tep 
                  join app.tpa_enr_policy_group teg on (tep.policy_seq_id = teg.policy_seq_id)
                  join app.tpa_enr_policy_member tem on (teg.policy_group_seq_id = tem.policy_group_seq_id)
                  left outer join app.tpa_group_registration tgr on (tep.group_reg_seq_id = tgr.group_reg_seq_id)
                  LEFT OUTER JOIN TPA_ENR_BANK_DTLS BD ON (TEG.BANK_SEQ_ID=BD.BANK_SEQ_ID)
                  LEFT OUTER JOIN app.tpa_general_code g on (tep.tpa_cheque_issued_general_type = g.general_type_id)
            WHERE (str_tab(1) is null or tep.policy_number = str_tab(1))
            AND (str_tab(2) is null or tem.tpa_enrollment_id = str_tab(2))
            AND (to_date(str_tab(3),'dd/mm/yyyy') is null or tep.effective_from_date >= to_date(str_tab(3),'dd/mm/yyyy') )
            AND (to_date(str_tab(4),'dd/mm/yyyy')  is null or tep.effective_from_date <= to_date(str_tab(4),'dd/mm/yyyy') )
            AND (str_tab(5) is null or upper(ttk_util_pkg.fn_decrypt(bd.bank_account_no)) like  upper(str_tab(5))||'%')
            AND (str_tab(6) is null or  upper(tgr.group_id)= upper(str_tab(6))) ;
                                                        
  END  Policy_bank_dtl_report;
--==================================================================================================
PROCEDURE Hosp_bank_dtl_report(
     where_clause              IN  VARCHAR2,
     v_result_set              OUT SYS_REFCURSOR
  )
  IS
    str_tab                ttk_util_pkg.str_table_type;
    v_sql_stmt             VARCHAR2(8000);
    TYPE bind_tab_type IS  TABLE OF VARCHAR2(250) INDEX BY BINARY_INTEGER ;
    bind_tab               bind_tab_type;
    i                      NUMBER(2) := 0;
  BEGIN
    --delete from app.temp_test2;
    --insert into app.temp_test2(error2)values(where_clause);
    --commit;
    
    str_tab     := ttk_util_pkg.parse_str ( where_clause );

   OPEN v_result_set FOR
                select 
                     hi.hosp_name as Provider_Name,  
                     hi.empanel_number as Provider_ID,  
                     case when nvl(ha.issue_cheques_type_id,'HOS')='HOS' then hi.hosp_name else ha.management_name end  Payee_Name,
                     ttk_util_pkg.fn_decrypt(ha.account_number) AS BANK_ACCOUNT_NUMBER,
                     ttk_util_pkg.fn_decrypt(HA.ACCOUNT_TYPE ) AS BANK_ACCOUNT_TYPE,
                     ttk_util_pkg.fn_decrypt(ha.bank_name) AS BANK_NAME,
                     ttk_util_pkg.fn_decrypt(ha.branch_name) AS BRANCH_NAME, 
                     ttk_util_pkg.fn_decrypt(ha.bank_ifsc) AS BANK_IBAN 
                from app.tpa_hosp_info hi
                join app.tpa_hosp_account_details ha on (hi.hosp_seq_id = ha.hosp_seq_id)            
                WHERE (str_tab(1) is null or hi.hosp_seq_id = str_tab(1))
                AND (str_tab(2) is null or hi.empanel_number = str_tab(2))
                AND (str_tab(3) is null or UPPER(ttk_util_pkg.fn_decrypt(ha.account_number)) like  UPPER(str_tab(3))||'%')
                AND ((to_date(str_tab(4),'dd/mm/yyyy') is null and to_date(str_tab(5),'dd/mm/yyyy') is null)
                    or (to_date(str_tab(4),'dd/mm/yyyy') is null and ha.start_date <= to_date(str_tab(4),'dd/mm/yyyy'))
                    or (to_date(str_tab(5),'dd/mm/yyyy') is null and ha.start_date between to_date(str_tab(4),'dd/mm/yyyy') and sysdate)
                    or( to_date(str_tab(4),'dd/mm/yyyy') is not null and to_date(str_tab(5),'dd/mm/yyyy') is not null  
                    and ha.start_date between to_date(str_tab(4),'dd/mm/yyyy') and to_date(str_tab(5),'dd/mm/yyyy')
                    ));
      
  END  Hosp_bank_dtl_report;  
--=============================================================================================

/*
  Input parameters
    |S|<float_account_number>|<From date>|<To date>|<Claim type>|<batch No.>|
*/
  PROCEDURE EFT_claims_pending_report(
     where_clause              IN  VARCHAR2,
     v_result_set                 OUT SYS_REFCURSOR
  )
  IS
    str_tab                ttk_util_pkg.str_table_type;
    v_sql_stmt             VARCHAR2(4500);
    TYPE bind_tab_type IS  TABLE OF VARCHAR2(250) INDEX BY BINARY_INTEGER ;
    bind_tab               bind_tab_type;
    i                      NUMBER(2) := 0;
  BEGIN
    str_tab     := ttk_util_pkg.parse_str ( where_clause );

    v_sql_stmt := 'SELECT
          E.tpa_enrollment_id AS tpa_id_no,
          d.claim_number AS claim_no,
          E.claimant_name,
          E.policy_holder_name as insured_name,
          a.claim_settlement_no,
          D.total_app_amount,
          E.employee_no AS emp_no,
          a.claim_payment_status,
          a.approved_amount as al_amt
      FROM tpa_claims_payment A
          JOIN clm_general_details D ON(A.claim_seq_id = D.claim_seq_id)
          JOIN clm_enroll_details E ON ( D.claim_seq_id = E.claim_seq_id )
          LEFT OUTER JOIN tpa_group_registration k ON (a.group_reg_seq_id = k.group_reg_seq_id)
          JOIN tpa_float_account fa ON fa.float_seq_id = A.float_seq_id and fa.float_account_number = :v_float_acct_no';

          i := 3;
          bind_tab(1) := str_tab(2);
          bind_tab(2) := to_date(str_tab(3),'dd/mm/yyyy');
          bind_tab(3) := to_date(str_tab(4),'dd/mm/yyyy')+1;
          v_sql_stmt := v_sql_stmt||' WHERE a.claim_aprv_date BETWEEN :v_from_date AND :v_to_date
                                      AND a.emp_bank_name||a.emp_bank_branch||a.emp_acct_number||a.emp_email IS NULL
                                      AND a.claim_payment_status = ''PAID'' AND a.payee_type = ''EFT''';
          IF str_tab(5) IS NOT NULL THEN
             i := i+1;
             bind_tab(i) := str_tab(5);
             v_sql_stmt := v_sql_stmt||' AND a.claim_type = :v_claim_type';
          END IF ;
          IF str_tab(6) IS NOT NULL THEN
             i := i+1;
             bind_tab(i) := str_tab(6);
             v_sql_stmt := v_sql_stmt||' AND a.batch_number_manual = :v_batch_number_manual';
          END IF ;

       IF bind_tab.FIRST IS NOT NULL THEN
          CASE bind_tab.COUNT
               WHEN 1 THEN OPEN v_result_set FOR v_sql_stmt USING bind_tab(1);
               WHEN 2 THEN OPEN v_result_set FOR v_sql_stmt USING bind_tab(1), bind_tab(2);
               WHEN 3 THEN OPEN v_result_set FOR v_sql_stmt USING bind_tab(1), bind_tab(2), bind_tab(3);
               WHEN 4 THEN OPEN v_result_set FOR v_sql_stmt USING bind_tab(1), bind_tab(2), bind_tab(3), bind_tab(4);
               WHEN 5 THEN OPEN v_result_set FOR v_sql_stmt USING bind_tab(1), bind_tab(2), bind_tab(3), bind_tab(4), bind_tab(5);
          END CASE;
       ELSE
          OPEN v_result_set FOR v_sql_stmt;
       END IF;

  END  EFT_claims_pending_report;
 --=============================================================================================
/*
  Author: R. J. Prasanna Kumar SPAN Infotech.
  Description: This procedure gives list of batch numbers created between two given dates, if
               batch number is not provided in input. If batch number is one amount input then
               just the given batch number along with its created data is the output.
*/
  PROCEDURE get_batch_list (
     v_float_acct_num IN  tpa_float_account.float_account_number%TYPE,
     v_batch_number   IN  tpa_batch_master.batch_number%TYPE,
     v_str_date       IN  VARCHAR2,
     v_end_date       IN  VARCHAR2,
     v_identifier     IN  VARCHAR2,
     v_sort_var       IN  VARCHAR2,
     v_sort_order     IN  VARCHAR2,
     v_start_num      IN  NUMBER ,
     v_end_num        IN  NUMBER ,
     v_result_set      OUT SYS_REFCURSOR
  )
  IS
    v_sql_stmt             VARCHAR2(5000);
    TYPE bind_tab_type IS  TABLE OF VARCHAR2(250) INDEX BY BINARY_INTEGER ;
    bind_tab               bind_tab_type;
    i                      NUMBER(2) := 0;
  BEGIN
    v_sql_stmt := 'SELECT DISTINCT :v_float_acct_num AS Float_acct_num, b.batch_number, b.batch_date,g.template_name
                     FROM tpa_batch_master b
                     JOIN tpa_claims_payment c ON (b.batch_number=c.batch_number_manual)
                     JOIN tpa_float_account d ON (c.float_seq_id=d.float_seq_id)
                     JOIN tpa_bank_accounts e ON (d.bank_acc_seq_id=e.bank_acc_seq_id)
                     JOIN tpa_bank_master f ON (e.bank_seq_id=f.bank_seq_id)
                     LEFT OUTER JOIN cheque_template g ON (f.cheque_template_id = g.cheque_template_id)
                     WHERE batch_number IN (SELECT a.batch_number_manual
                                                FROM tpa_claims_payment a JOIN tpa_float_account fa ON fa.float_seq_id = A.float_seq_id
                                                  WHERE fa.float_account_number = :v_float_acct_num';
    IF v_identifier = 'EFT' THEN
       v_sql_stmt  := v_sql_stmt||' AND a.payee_type = ''EFT'')';
    ELSE
       v_sql_stmt  := v_sql_stmt||')';
    END IF;

    IF v_str_date IS NOT NULL THEN
       i := i + 1;
       bind_tab(i) := to_date(v_str_date,'dd/mm/yyyy');
       i := i + 1;
       bind_tab(i) := nvl(to_date(v_end_date,'dd/mm/yyyy')+1,SYSDATE);
       v_sql_stmt  := v_sql_stmt||' AND b.batch_date BETWEEN :v_from_date AND :v_to_date';
    END IF;
    IF v_batch_number IS NOT NULL THEN
       i := i +1;
       bind_tab(i) := v_batch_number;
       v_sql_stmt  := v_sql_stmt||' AND b.batch_number = :v_batch_number';
    END IF;

    v_sql_stmt := 'SELECT * FROM
                     (SELECT A.*,DENSE_RANK() OVER (ORDER BY '||v_sort_var||' '||v_sort_order||',ROWNUM)
                      Q FROM (' ||v_sql_stmt|| ') A ) WHERE  Q>= :v_start_num AND Q<= :v_end_num ';

    CASE bind_tab.COUNT
         WHEN 1 THEN OPEN v_result_set FOR v_sql_stmt USING v_float_acct_num, v_float_acct_num, bind_tab(1), v_start_num, v_end_num;
         WHEN 2 THEN OPEN v_result_set FOR v_sql_stmt USING v_float_acct_num, v_float_acct_num, bind_tab(1), bind_tab(2), v_start_num, v_end_num;
         WHEN 3 THEN OPEN v_result_set FOR v_sql_stmt USING v_float_acct_num, v_float_acct_num, bind_tab(1), bind_tab(2), bind_tab(3), v_start_num, v_end_num;
    END CASE;


  END get_batch_list;
--=============================================================================================
  PROCEDURE EFT_Covering_letter(
     where_clause    IN  VARCHAR2,
     v_cov_letter     OUT SYS_REFCURSOR
  )
  IS
    str_tab    ttk_util_pkg.str_table_type;
  BEGIN
    str_tab := ttk_util_pkg.parse_str ( where_clause );
    OPEN v_cov_letter FOR
       SELECT bh.bank_name,
              p.emp_bank_name,
              ba.account_number,
              SUM(p.approved_amount) AS Tot_amount
         FROM tpa_claims_payment p JOIN tpa_float_account f ON p.float_seq_id = f.float_seq_id
              JOIN fin_app.tpa_bank_accounts ba ON f.bank_acc_seq_id = ba.bank_acc_seq_id
              JOIN fin_app.tpa_bank_master bm ON ba.bank_seq_id = bm.bank_seq_id
              JOIN fin_app.tpa_bank_master bh ON nvl(bm.ho_id,bm.bank_seq_id) = bh.bank_seq_id
            WHERE p.batch_number_manual = str_tab(2)
               GROUP BY bh.bank_name, p.emp_bank_name, ba.account_number;

  END EFT_Covering_letter;
--=============================================================================================
  PROCEDURE EFT_Cov_letter_Annexure (
     where_clause    IN  VARCHAR2,
     v_abn_bank      OUT SYS_REFCURSOR,
     v_deutsche_bank OUT SYS_REFCURSOR,
     v_hdfc_bank     OUT SYS_REFCURSOR,
     v_axis_bank     OUT SYS_REFCURSOR
  )
  IS
    str_tab    ttk_util_pkg.str_table_type;
  BEGIN
    str_tab := ttk_util_pkg.parse_str ( where_clause );

    OPEN v_abn_bank FOR
       SELECT rownum,
              ttk_util_pkg.fn_decrypt(p.payee_name) AS payee_name, --Modified for koc11ed
              p.emp_acct_number,
              'SALARY ACCOUNT' AS acct_type,
              p.emp_bank_name,
              p.emp_bank_branch,
              p.approved_amount,
              'Annexure-1' AS Annexure
         FROM tpa_claims_payment p
            WHERE p.batch_number_manual = str_tab(2)
              AND p.emp_bank_name LIKE '%ABN%';

    OPEN v_deutsche_bank FOR
       SELECT rownum,
              ttk_util_pkg.fn_decrypt(p.payee_name) payee_name, --Modified for koc11ed
              p.emp_acct_number,
              'SALARY ACCOUNT' AS acct_type,
              p.emp_bank_name,
              p.emp_bank_branch,
              p.approved_amount,
              'Annexure-2' AS Annexure
         FROM tpa_claims_payment p
            WHERE p.batch_number_manual = str_tab(2)
              AND p.emp_bank_name LIKE '%DEUTSCHE%';

    OPEN v_hdfc_bank FOR
       SELECT rownum,
              ttk_util_pkg.fn_decrypt(p.payee_name) AS payee_name, --Modified for koc11ed
              p.emp_acct_number,
              'SALARY ACCOUNT' AS acct_type,
              p.emp_bank_name,
              p.emp_bank_branch,
              p.approved_amount,
              'Annexure-3' AS Annexure
         FROM tpa_claims_payment p
            WHERE p.batch_number_manual = str_tab(2)
              AND p.emp_bank_name LIKE '%HDFC%';

    OPEN v_axis_bank FOR
       SELECT rownum,
              ttk_util_pkg.fn_decrypt(p.payee_name) AS payee_name, --Modified for koc11ed
              p.emp_acct_number,
              'SALARY ACCOUNT' AS acct_type,
              p.emp_bank_name,
              p.emp_bank_branch,
              p.approved_amount,
              'Annexure-4' AS Annexure
         FROM tpa_claims_payment p
            WHERE p.batch_number_manual = str_tab(2)
              AND p.emp_bank_name LIKE '%AXIS%';

  END EFT_Cov_letter_Annexure;
--=============================================================================================
  PROCEDURE tpa_commission_report(
    where_clause            IN VARCHAR2,
    Individual_Enrl_cur     OUT SYS_REFCURSOR ,
    Individual_End_cur      OUT SYS_REFCURSOR ,
    Group_Enrl_cur          OUT SYS_REFCURSOR ,
    Group_End_cur           OUT SYS_REFCURSOR ,
    summary_cur             OUT SYS_REFCURSOR ,
    invoice_cur             OUT SYS_REFCURSOR
  )
  IS
     str_tab           ttk_util_pkg.str_table_type;
     v_invoice_seq_id  fin_app.TPA_FIN_INVOICE.invoice_seq_id%TYPE;
     v_invoice_date    fin_app.TPA_FIN_INVOICE.inv_to_date%TYPE;
     v_inv_date        VARCHAR2(10);
     v_ins_comp_name   TPA_INS_INFO.ins_comp_name%TYPE;
     v_ins_office_type TPA_GENERAL_CODE.description%TYPE;
     v_ins_city        TPA_CITY_CODE.city_description%TYPE;
     v_abbr_code       TPA_INS_INFO.abbrevation_code%TYPE;
     v_office_code     tpa_office_info.office_code%TYPE;
     v_office_type_id  TPA_INS_INFO.ins_office_general_type_id%TYPE;
     v_ins_comp_code   TPA_INS_INFO.ins_comp_code_number%TYPE;

  BEGIN
     str_tab := ttk_util_pkg.parse_str ( where_clause );
     SELECT COUNT(1) INTO v_invoice_seq_id FROM fin_app.tpa_fin_invoice WHERE invoice_number = str_tab(1);

     IF v_invoice_seq_id <= 0 THEN
        RAISE_APPLICATION_ERROR(-20259,'No Invoice found. Please enter proper invoice number.');
     END IF;

     SELECT invoice_seq_id, inv_to_date,to_char(inv_to_date, 'MM/YY') AS inv_date
       INTO v_invoice_seq_id, v_invoice_date,v_inv_date
     FROM fin_app.tpa_fin_invoice WHERE invoice_number = str_tab(1);

     SELECT a.ins_comp_name, b.description, d.city_description,e.office_code,a.abbrevation_code,
     CASE WHEN a.ins_office_general_type_id = 'IHO' THEN 'HO'
          WHEN a.ins_office_general_type_id = 'IBO' THEN 'BO'
          WHEN a.ins_office_general_type_id = 'IRO' THEN 'RO'
          ELSE 'DO'
          END AS office_type,
     a.ins_comp_code_number
            INTO v_ins_comp_name, v_ins_office_type, v_ins_city,v_office_code,v_abbr_code,v_office_type_id,v_ins_comp_code
       FROM tpa_ins_info a
            LEFT OUTER JOIN tpa_general_code b ON (a.ins_office_general_type_id = b.general_type_id)
            LEFT OUTER JOIN tpa_address c ON (a.ins_seq_id = c.ins_seq_id)
            LEFT OUTER JOIN tpa_city_code d ON (c.city_type_id = d.city_type_id)
            JOIN tpa_office_info e ON(a.tpa_office_seq_id=e.tpa_office_seq_id)
          WHERE a.ins_seq_id = str_tab(2);

    OPEN Individual_Enrl_cur FOR SELECT INV_TYPE, v_ins_comp_name AS ins_name, v_ins_city AS ins_city,
       v_invoice_date AS inv_date, "INS" , 'Enrollment-Individual' AS "Type" ,  "Bo/Do" , "PolicyNo",
        "Name" ,"ID",to_char("StartDt",'dd/mm/yyyy') "StartDt" , "Net Sum", "Dependents" , "Net Premium", "TPA" , to_char(added_date ,'dd/mm/yyyy') AS "TPA_adddt"  ,
         "Tenure", to_char(A.expiry_date,'dd/mm/yyyy') expiry_date, commision_to_tpa
          FROM fin_app.vw_invoice_individual_rpt a  WHERE A.invoice_seq_id = v_invoice_seq_id AND A.endorsement_seq_id IS NULL and A."Cust End No" is NULL
             AND (str_tab(2) IS NULL OR a.ins_seq_id  IN (SELECT ins_seq_id FROM  tpa_ins_info
                                                             START WITH ins_seq_id = str_tab(2)
                                                                CONNECT BY PRIOR ins_seq_id = ins_parent_seq_id));

    OPEN Individual_End_cur FOR  SELECT INV_TYPE, v_ins_comp_name AS ins_name, v_ins_city AS ins_city,
       v_invoice_date AS inv_date, "INS" , 'Endorsement-Individual' AS "Type" ,  "Bo/Do" , "PolicyNo",
      "Name" ,"ID",to_char("StartDt",'dd/mm/yyyy') "StartDt" , "Net Sum", "Dependents" , "Net Premium", "TPA" ,to_char(added_date ,'dd/mm/yyyy') AS "TPA_adddt"  ,
       "Tenure","Cust End No",to_char("Cust End Dt",'dd/mm/yyyy') "Cust End Dt", to_char(A.expiry_date,'dd/mm/yyyy') expiry_date, commision_to_tpa
        FROM fin_app.vw_invoice_individual_rpt a  WHERE A.invoice_seq_id = v_invoice_seq_id AND A.endorsement_seq_id IS NOT NULL
             AND (str_tab(2) IS NULL OR a.ins_seq_id  IN (SELECT ins_seq_id FROM  tpa_ins_info
                                                             START WITH ins_seq_id = str_tab(2)
                                                                CONNECT BY PRIOR ins_seq_id = ins_parent_seq_id));

    OPEN Group_Enrl_cur FOR SELECT  INV_TYPE, v_ins_comp_name AS ins_name, v_ins_city AS ins_city,
       v_invoice_date AS inv_date, 'Groups' AS "Type", "Bo/Do","PolicyNo","INS" ,
       "Name","Lives", to_char("Start Date",'dd/mm/yyyy') "Start Date", "Sum Insured", "Premium" , "TPA",
       to_char(added_date ,'dd/mm/yyyy') AS "TPA_adddt" ,ID,"Tenure", to_char(A.expiry_date,'dd/mm/yyyy') expiry_date, commision_to_tpa
       FROM fin_app.vw_invoice_corporate_rpt A WHERE A.invoice_seq_id = v_invoice_seq_id
        AND a.endorsement_seq_id IS NULL AND a."Cust End No" IS NULL
        AND (str_tab(2) IS NULL OR a.ins_seq_id  IN (SELECT ins_seq_id FROM  tpa_ins_info
                                                       START WITH ins_seq_id = str_tab(2)
                                                        CONNECT BY PRIOR ins_seq_id = ins_parent_seq_id))
       UNION ALL
       SELECT  INV_TYPE, v_ins_comp_name AS ins_name, v_ins_city AS ins_city,
       v_invoice_date AS inv_date, 'Non-Corporate Enrollment' AS "Type", "Bo/Do","PolicyNo","INS" ,
       "Name","Lives", to_char("Start Date",'dd/mm/yyyy') "Start Date", "Sum Insured", "Premium" , "TPA",
       to_char(added_date ,'dd/mm/yyyy') AS "TPA_adddt" ,ID,"Tenure", to_char(A.expiry_date,'dd/mm/yyyy') expiry_date, commision_to_tpa
       FROM fin_app.vw_invoice_oth_groups_rpt A WHERE A.invoice_seq_id = v_invoice_seq_id
           AND a.endorsement_seq_id IS NULL AND a."Cust End No" IS NULL AND a.enrol_type_id = 'NCR'
        AND (str_tab(2) IS NULL OR a.ins_seq_id  IN (SELECT ins_seq_id FROM  tpa_ins_info
                                                       START WITH ins_seq_id = str_tab(2)
                                                        CONNECT BY PRIOR ins_seq_id = ins_parent_seq_id))
       UNION ALL
       SELECT  INV_TYPE, v_ins_comp_name AS ins_name, v_ins_city AS ins_city,
       v_invoice_date AS inv_date, 'Individual as Group Enrollment' AS "Type", "Bo/Do","PolicyNo","INS" ,
       "Name","Lives", to_char("Start Date",'dd/mm/yyyy') "Start Date", "Sum Insured", "Premium" , "TPA",
       to_char(added_date ,'dd/mm/yyyy') AS "TPA_adddt" ,ID,"Tenure", to_char(A.expiry_date,'dd/mm/yyyy') expiry_date, commision_to_tpa
       FROM fin_app.vw_invoice_oth_groups_rpt A WHERE A.invoice_seq_id = v_invoice_seq_id
           AND a.endorsement_seq_id IS NULL AND a."Cust End No" IS NULL AND a.enrol_type_id = 'ING'
        AND (str_tab(2) IS NULL OR a.ins_seq_id  IN (SELECT ins_seq_id FROM  tpa_ins_info
                                                       START WITH ins_seq_id = str_tab(2)
                                                        CONNECT BY PRIOR ins_seq_id = ins_parent_seq_id));
--------------------------------
    OPEN Group_End_cur FOR SELECT  INV_TYPE, v_ins_comp_name AS ins_name, v_ins_city AS ins_city,
        v_invoice_date AS inv_date, 'Endorsement-Groups' AS "Type", "Bo/Do","PolicyNo","INS" ,
       "Name","Lives", to_char("Start Date",'dd/mm/yyyy') "Start Date", "Sum Insured", "Premium" , "TPA", to_char(added_date ,'dd/mm/yyyy') AS "TPA_adddt" ,
       ID,"Tenure" ,"Cust End No", to_char("Cust End Dt",'dd/mm/yyyy') "Cust End Dt" , to_char(A.expiry_date,'dd/mm/yyyy') expiry_date, commision_to_tpa
       FROM fin_app.vw_invoice_corporate_rpt A WHERE A.invoice_seq_id = v_invoice_seq_id
        AND a.endorsement_seq_id IS NOT NULL
        AND (str_tab(2) IS NULL OR a.ins_seq_id  IN (SELECT ins_seq_id FROM  tpa_ins_info
                                                      START WITH ins_seq_id = str_tab(2)
                                                       CONNECT BY PRIOR ins_seq_id = ins_parent_seq_id))
       UNION ALL
       SELECT  INV_TYPE, v_ins_comp_name AS ins_name, v_ins_city AS ins_city,
        v_invoice_date AS inv_date, 'Non-Corporate Endorsements' AS "Type", "Bo/Do","PolicyNo","INS" ,
        "Name","Lives", to_char("Start Date",'dd/mm/yyyy') "Start Date", "Sum Insured", "Premium" , "TPA",  to_char(added_date ,'dd/mm/yyyy') AS "TPA_adddt" ,
        ID,"Tenure" ,"Cust End No", to_char("Cust End Dt",'dd/mm/yyyy') "Cust End Dt" , to_char(A.expiry_date,'dd/mm/yyyy') expiry_date, commision_to_tpa
       FROM fin_app.vw_invoice_oth_groups_rpt A WHERE A.invoice_seq_id = v_invoice_seq_id
        AND a.endorsement_seq_id IS NOT NULL AND a.enrol_type_id = 'NCR'
        AND (str_tab(2) IS NULL OR a.ins_seq_id  IN (SELECT ins_seq_id FROM  tpa_ins_info
                                                      START WITH ins_seq_id = str_tab(2)
                                                       CONNECT BY PRIOR ins_seq_id = ins_parent_seq_id))
       UNION ALL
       SELECT  INV_TYPE, v_ins_comp_name AS ins_name, v_ins_city AS ins_city,
       v_invoice_date AS inv_date, 'Individual as Group Endorsements' AS "Type", "Bo/Do","PolicyNo","INS" ,
        "Name","Lives", to_char("Start Date",'dd/mm/yyyy') "Start Date", "Sum Insured", "Premium" , "TPA", to_char(added_date ,'dd/mm/yyyy') AS "TPA_adddt" ,
        ID,"Tenure" ,"Cust End No", to_char("Cust End Dt",'dd/mm/yyyy') "Cust End Dt" , to_char(A.expiry_date,'dd/mm/yyyy') expiry_date, commision_to_tpa
       FROM fin_app.vw_invoice_oth_groups_rpt A WHERE A.invoice_seq_id = v_invoice_seq_id
        AND a.endorsement_seq_id IS NOT NULL AND a.enrol_type_id = 'ING'
        AND (str_tab(2) IS NULL OR a.ins_seq_id  IN (SELECT ins_seq_id FROM  tpa_ins_info
                                                      START WITH ins_seq_id = str_tab(2)
                                                       CONNECT BY PRIOR ins_seq_id = ins_parent_seq_id));

    OPEN summary_cur FOR  SELECT  v_ins_comp_name AS ins_name, v_ins_city AS ins_city,
       v_invoice_date AS inv_date, INS , BODO issuing_branch ,
       SUM(IND_noofpolicies) AS ind_noofpolicies ,
       SUM(IND_Premium) AS  ind_premium_amount ,
       SUM(IND_TPA) AS ind_tpa_commission ,
       SUM(IND_END_noofpolicies) AS ind_end_no_of_policies ,
       SUM(IND_END_Premium) AS  ind_end_premium_amount ,
       SUM(IND_END_TPA) AS ind_end_tpa_commission ,---------
       SUM(GRP_noofpolicies)+ SUM(ING_noofpolicies) + SUM(NCOR_noofpolicies) AS Grp_noofpolicies ,
       SUM(GRP_Premium) + SUM(ING_Premium) + SUM(NCOR_Premium) AS  Grp_premium_amount ,
       SUM(GRP_TPA) + SUM(ING_TPA) + SUM(NCOR_TPA) AS Grp_tpa_commission ,
       SUM(GRP_END_noofpolicies) + SUM(ING_END_noofpolicies) + SUM(NCOR_END_noofpolicies) AS Grp_end_no_of_policies ,
       SUM(GRP_END_Premium) + SUM(ING_END_Premium) + SUM(NCOR_END_Premium) AS Grp_end_premium_amount ,
       SUM(GRP_END_TPA) + SUM(ING_END_TPA) + SUM(NCOR_END_TPA) AS Grp_end_tpa_commission
      FROM
      ( SELECT INS, "Bo/Do" AS bodo ,
           decode( TYPE ,'INDIVIDUAL', COUNT(DISTINCT policy_seq_id),0) AS  IND_noofpolicies ,
           decode( TYPE ,'INDIVIDUAL', SUM(Net_Premium),0) AS IND_Premium,
           decode( TYPE ,'INDIVIDUAL', SUM(TPA),0) AS IND_TPA ,
           decode( TYPE ,'INDIVIDUAL-ENDORSEMENT',COUNT(DISTINCT policy_seq_id),0) AS IND_END_noofpolicies ,
           decode( TYPE ,'INDIVIDUAL-ENDORSEMENT',SUM(Net_Premium),0) AS IND_END_Premium,
           decode( TYPE ,'INDIVIDUAL-ENDORSEMENT',SUM(TPA),0) AS IND_END_TPA ,
           decode( TYPE ,'GROUPS',COUNT(DISTINCT policy_seq_id),0) AS GRP_noofpolicies ,
           decode( TYPE ,'GROUPS',SUM(Net_Premium),0) AS GRP_Premium,
           decode( TYPE ,'GROUPS',SUM(TPA),0) AS GRP_TPA ,
           decode( TYPE ,'GROUPS-ENDORSEMENT',COUNT(DISTINCT policy_seq_id),0) AS  GRP_END_noofpolicies ,
           decode( TYPE ,'GROUPS-ENDORSEMENT',SUM(Net_Premium),0) AS GRP_END_Premium,
           decode( TYPE ,'GROUPS-ENDORSEMENT',SUM(TPA),0) AS GRP_END_TPA ,
           decode( TYPE ,'INDIVIDUAL AS GROUP',COUNT(DISTINCT policy_seq_id),0) AS  ING_noofpolicies ,
           decode( TYPE ,'INDIVIDUAL AS GROUP',SUM(Net_Premium),0) AS ING_Premium,
           decode( TYPE ,'INDIVIDUAL AS GROUP',SUM(TPA),0) AS ING_TPA ,
           decode( TYPE ,'INDIVIDUAL AS GROUP-ENDORSEMENT',COUNT(DISTINCT policy_seq_id ),0) AS  ING_END_noofpolicies ,
           decode( TYPE ,'INDIVIDUAL AS GROUP-ENDORSEMENT',SUM(Net_Premium),0) AS ING_END_Premium,
           decode( TYPE ,'INDIVIDUAL AS GROUP-ENDORSEMENT',SUM(TPA),0) AS ING_END_TPA ,
           decode( TYPE ,'NON-CORPORATE',COUNT(DISTINCT policy_seq_id),0) AS NCOR_noofpolicies ,
           decode( TYPE ,'NON-CORPORATE',SUM(Net_Premium),0) AS NCOR_Premium,
           decode( TYPE ,'NON-CORPORATE',SUM(TPA),0) AS NCOR_TPA ,
           decode( TYPE ,'NON-CORPORATE-ENDORSEMENT',COUNT(DISTINCT policy_seq_id),0) AS  NCOR_END_noofpolicies ,
           decode( TYPE ,'NON-CORPORATE-ENDORSEMENT',SUM(Net_Premium),0) AS NCOR_END_Premium,
           decode( TYPE ,'NON-CORPORATE-ENDORSEMENT', SUM(TPA),0) AS NCOR_END_TPA  FROM  fin_app.VW_FINANCE_rpt
           WHERE invoice_seq_id = v_invoice_seq_id
             AND (str_tab(2) IS NULL OR ins_seq_id IN (SELECT ins_seq_id FROM  tpa_ins_info
                                                         START WITH ins_seq_id = str_tab(2)
                                                          CONNECT BY PRIOR ins_seq_id = ins_parent_seq_id))
           GROUP BY TYPE, INS, "Bo/Do"
      ) GROUP  BY  INS, BODO ORDER BY INS , issuing_branch ;

    OPEN invoice_cur FOR SELECT v_abbr_code || '/'|| v_office_code || '/'|| v_office_type_id || '-'|| v_ins_comp_code || '/'|| str_tab(1) || '/'|| v_inv_date  AS inv_number, v_ins_comp_name AS ins_name,
                                v_ins_office_type || '-'|| v_ins_comp_code AS ins_off_type, v_ins_city AS ins_city,
                                v_invoice_date AS inv_date, COUNT(DISTINCT policy_seq_id) AS noofpolicies,
                                SUM(Net_Premium) AS Premium, SUM(TPA) AS TPA
                            FROM fin_app.VW_FINANCE_rpt
                              WHERE invoice_seq_id = v_invoice_seq_id
                                AND (str_tab(2) IS NULL OR
                                     ins_seq_id IN (SELECT ins_seq_id FROM  tpa_ins_info
                                                     START WITH ins_seq_id = str_tab(2)
                                                      CONNECT BY PRIOR ins_seq_id = ins_parent_seq_id));

 END tpa_commission_report;
--=============================================================================================
  FUNCTION get_billno(
    v_claim_seq_id      IN NUMBER ) RETURN VARCHAR2 DETERMINISTIC
  IS
    v_str   VARCHAR2(1000);
  BEGIN
    FOR I IN ( SELECT a.bill_no FROM clm_bill_header a WHERE a.claim_seq_id = v_claim_seq_id )
    LOOP
        v_str := v_str ||','|| i.bill_no ;
    END LOOP;
    RETURN SUBSTR(v_str,2);
  END ;
--=============================================================================================
  FUNCTION get_hospitalization(
    v_claim_seq_id      IN NUMBER ,
    v_date_of_admission IN DATE := NULL,
    v_date_of_discharge IN DATE := NULL ) RETURN VARCHAR2 DETERMINISTIC
  IS
    v_str   VARCHAR2(1000);
  BEGIN
    WITH bills AS ( SELECT CASE WHEN a.bill_date < v_date_of_admission THEN '/PRE' ELSE '' END AS PRE,
                           CASE WHEN a.bill_date > v_date_of_discharge THEN '/POST' ELSE '' END AS POST,
                           CASE WHEN a.bill_date BETWEEN  v_date_of_admission AND v_date_of_discharge THEN '/HOSP' ELSE '' END AS HOSP
                      FROM clm_bill_header a WHERE a.claim_seq_id = v_claim_seq_id )
     SELECT MAX(PRE)||MAX(HOSP)||MAX(POST) INTO v_str  FROM bills ;

    RETURN SUBSTR(v_str,2);
  END ;
--=============================================================================================
  FUNCTION get_icds(
     v_calims_seq_id           NUMBER ) RETURN VARCHAR2 DETERMINISTIC
  IS
     v_ailment_str  VARCHAR2(4000);
  BEGIN
    FOR i IN (SELECT b.ped_description FROM icd_pcs_detail a JOIN tpa_ped_code b ON (a.ped_code_id = b.ped_code_id)
                WHERE a.claim_seq_id = v_calims_seq_id )
    LOOP
        v_ailment_str := v_ailment_str ||','|| i.ped_description ;
    END LOOP;

    RETURN SUBSTR(v_ailment_str,2);
  end get_icds;
--===============================================================================================
/*   Change Log
   Date        By   Remarks
   26/08/2008  RJP  Date formats for all date columns in result set were changed to mm/dd/yyyy
                    as per CR - KOC850 / JV07035-107
*/
  PROCEDURE Get_76_col_rpt_data (
    FilterValues  IN VARCHAR2,
    v_resultset   OUT SYS_REFCURSOR
  )
  IS
    Parameter      Ttk_Util_Pkg.str_table_type;
  BEGIN
    Parameter := ttk_util_pkg.parse_str(FilterValues);

    IF Parameter(5) = 'D' THEN -- get data from A76_col_debit_note_rpt for claims attached to a debit note.
       A76_col_debit_note_rpt ( FilterValues , v_resultset  );
    ELSE

    OPEN v_resultset FOR
    WITH chgdtl AS ( SELECT bh.claim_seq_id, MIN(bh.bill_date) as bill_date, SUM(bd.allowed_amount) AS Hosp_charges,
                    SUM(CASE WHEN wa.acc_group_name = 'Stay Charges' THEN bd.allowed_amount ELSE 0 END) as Room_nursing_charges,
                    SUM(CASE WHEN wa.acc_group_name = 'Surgery Charges' THEN bd.allowed_amount ELSE 0 END) as Surgery_charges,
                    SUM(CASE WHEN wa.acc_group_name = 'Consultation Charges' THEN bd.allowed_amount ELSE 0 END) as Consultant_charges,
                    SUM(CASE WHEN wa.acc_group_name = 'Investigation Charges' THEN bd.allowed_amount ELSE 0 END) as Investigation_charges,
                    SUM(CASE WHEN wa.acc_group_name = 'Medicines & Drug/implants' THEN bd.allowed_amount ELSE 0 END) as Medicine_charges,
                    SUM(CASE WHEN wa.acc_group_name NOT IN ('Stay Charges','Surgery Charges', 'Consultation Charges',
                                                            'Investigation Charges', 'Medicines & Drug/implants')
                                  THEN bd.allowed_amount ELSE 0 END) as Miscellaneous_charges
               FROM clm_bill_header bh JOIN clm_bill_details bd ON (bh.clm_bill_seq_id = bd.clm_bill_seq_id)
                    JOIN tpa_claims_payment cp ON (bh.claim_seq_id = cp.claim_seq_id)
                    JOIN tpa_float_account fa ON (cp.float_seq_id=fa.float_seq_id)
                    LEFT OUTER JOIN prod_ward_groupings wg ON (bd.ward_type_id = wg.ward_type_id)
                    JOIN ward_account_group wa ON (wg.ward_acc_group_seq_id = wa.ward_acc_group_seq_id  AND wa.group_show_type = 'IRD')
                  WHERE fa.float_account_number=Parameter(2) AND cp.claim_payment_status ='PENDING'
                    AND cp.claim_aprv_date >= to_date(Parameter(3),'dd/mm/yyyy') AND cp.claim_aprv_date < to_date(Parameter(4),'dd/mm/yyyy') + 1
                     GROUP BY bh.claim_seq_id ),
     procs AS (SELECT claim_seq_id, pat_gen_detail_seq_id,
                      SUBSTR(MAX(substr(sys_connect_by_path (pcode,', '),2)),2,60) AS proc_code,
                      SUBSTR(MAX(SUBSTR(sys_connect_by_path (pdesc,'| '),2)),2) AS proc_desc,
                      SUBSTR(MAX(SUBSTR(sys_connect_by_path (icd_code,', '),2)),2) AS Icd_codes,
                      SUBSTR(MAX(SUBSTR(sys_connect_by_path (ped_desc,'| '),2)),2) AS Icd_desc
                FROM (SELECT A.claim_seq_id, A.pat_gen_detail_seq_id, nvl( E.proc_code, F.proc_code) AS PCODE,
                             nvl(E.proc_description, F.proc_description) AS PDESC,
                             A.icd_code, G.ped_description AS ped_desc,
                             row_number() over (partition by A.claim_seq_id, A.pat_gen_detail_seq_id order by A.claim_seq_id, A.pat_gen_detail_seq_id) rn
                        FROM icd_pcs_detail A
                             LEFT OUTER JOIN pat_package_procedures B ON (A.icd_pcs_seq_id = B.icd_pcs_seq_id)
                             LEFT OUTER JOIN tpa_ped_code G ON (A.ped_code_id = G.ped_code_id)
                             JOIN tpa_claims_payment cp ON (A.claim_seq_id = cp.claim_seq_id)
                             JOIN tpa_float_account fa ON (cp.float_seq_id=fa.float_seq_id)
                             LEFT OUTER JOIN tpa_hosp_tariff_item C ON (B.pkg_seq_id = C.pkg_seq_id)
                             LEFT OUTER JOIN tpa_hosp_pkg_proc D ON (C.pkg_seq_id = D.pkg_seq_id)
                             LEFT OUTER JOIN tpa_hosp_procedure_code E ON (D.proc_seq_id = E.proc_seq_id)
                             LEFT OUTER JOIN tpa_hosp_procedure_code F ON (B.proc_seq_id = F.proc_seq_id)
                          WHERE fa.float_account_number= Parameter(2) AND cp.claim_payment_status ='PENDING'
                           AND cp.claim_aprv_date >= to_date(Parameter(3),'dd/mm/yyyy') AND cp.claim_aprv_date < to_date(Parameter(4),'dd/mm/yyyy') + 1
                           ) START WITH rn = 1
                             CONNECT BY rn = PRIOR rn + 1 AND
                                        (PRIOR claim_seq_id = claim_seq_id OR PRIOR pat_gen_detail_seq_id = pat_gen_detail_seq_id)
                                GROUP BY claim_seq_id , pat_gen_detail_seq_id)

     SELECT DISTINCT i.office_name, g.group_name, p.policy_number, ' ' AS IL_Branch, ' ' AS Region,
            to_char(p.effective_from_date,'mm/dd/yyyy') AS effective_from_date,
            to_char(p.effective_to_date,'mm/dd/yyyy') AS effective_to_date, ' ' AS date_of_placement,
            pg.insured_name, pm.mem_name, gc.description, rc.relship_description,
            pm.mem_age, to_char(pm.mem_dob,'mm/dd/yyyy') AS mem_dob,
            (bal.sum_insured - bal.utilised_sum_insured) + (bal.BONUS - bal.UTILISED_CUM_BONUS) AS BALANCE,
            --pm.mem_tot_sum_insured,
            CASE WHEN pm.mem_general_type_id = 'PFL' THEN pg.floater_sum_insured
                 ELSE pm.mem_tot_sum_insured END AS mem_tot_sum_insured,
            pe.auth_number, clp.claim_settlement_no AS claim_number, pd.pat_requested_amount,
            pd.total_app_amount AS pat_total_app_amount,
            cg.requested_amount, cg.Total_App_Amount,
            (cg.requested_amount - cg.Total_App_Amount) AS Disallowed_amt,
            ' ' AS reserve_amt,
            ' ' AS corporate_floater_amt,
            CASE WHEN chgdtl.bill_date BETWEEN cg.date_of_admission AND cg.date_of_discharge+1
                 THEN chgdtl.Hosp_charges ELSE 0 END AS hospital_bill_amt,
            CASE WHEN TRUNC(chgdtl.bill_date) < TRUNC(cg.Date_Of_Admission) THEN chgdtl.Hosp_charges ELSE 0 END AS pre_hosp_amt,
            CASE WHEN TRUNC(chgdtl.bill_date) > TRUNC(cg.date_of_discharge) THEN chgdtl.Hosp_charges ELSE 0 END AS post_hosp_amt,
            Room_nursing_charges,                      Surgery_charges,
            Consultant_charges,                        Investigation_charges,
            Medicine_charges,                          Miscellaneous_charges,
            ' ' AS amt_paid_to_member,
            ' ' AS amt_paid_to_hospital,
            to_char(pd.pat_received_date,'mm/dd/yyyy') AS pre_auth_date,
            to_char(pe.decision_date,'mm/dd/yyyy') AS al_date,
            to_char(cg.date_of_admission,'mm/dd/yyyy') AS date_of_admission,
            to_char(cg.date_of_discharge,'mm/dd/yyyy') AS date_of_discharge,
            to_char(ci.rcvd_date,'mm/dd/yyyy') AS dt_of_file_received,
            ' ' AS deficiencies_dt_raised_by_tpa,
            ' ' AS dt_of_doc_recovery,
            ' ' AS date_send_to_ilgic_for_payment,
            ' ' AS date_paid_by_ilgic,
            ' ' AS lot_no,
            ' ' AS date_of_pay_to_member,
            ' ' AS date_of_pay_to_hospital,
            ' ' AS date_chq_disp_hosp,
            ' ' AS date_chq_disp_mem,
            ' ' AS date_closure_letter_disp,
            ' ' AS date_rejection_letter_disp,
            to_char(ce.decision_date,'mm/dd/yyyy') AS claim_completion_date,
            ' ' AS cheque_no_mem,
            ' ' AS cheque_no_hosp,
            ' ' AS status,
            ' ' AS reason_of_rejection,
            ' ' AS rejected_date,
            ' ' AS closed_date,
            CASE WHEN ((cg.date_of_discharge - cg.date_of_admission)*24*60*60)/3600 > 24 THEN 'IPD' ELSE 'OPD' END AS ipd_opd,
            ctgc.description AS type_of_claim,
            CASE WHEN clp.claim_payment_status IS NOT NULL THEN clp.claim_payment_status ELSE sgc.description END AS stage,
            i.office_code AS tpa_processing_region,
            CASE WHEN ci.claim_general_type_id = 'CNH' THEN hi.hosp_name ELSE clha.hosp_name END AS Hosp_name,
            CASE WHEN ci.claim_general_type_id = 'CNH' THEN cc.city_description ELSE clha.city_name END AS Hosp_location,
            CASE WHEN TRIM(procs.Icd_desc) != '|' THEN procs.Icd_desc ELSE NULL END AS ailment,
            ad.provisional_diagnosis,
            CASE WHEN TRIM( procs.proc_desc) != '|' THEN procs.proc_desc ELSE NULL END AS  proc_desc,
            CASE WHEN TRIM(procs.Icd_codes) != ',' THEN procs.Icd_codes ELSE NULL END AS Icd_codes,
            CASE WHEN TRIM(procs.proc_code) != ',' THEN procs.proc_code ELSE NULL END AS proc_code,
            CASE WHEN TRUNC(chgdtl.bill_date) < TRUNC(cg.Date_Of_Admission) THEN 'Pre-Hospitalization'
                 WHEN TRUNC(chgdtl.bill_date) > TRUNC(cg.date_of_discharge) THEN 'Post-Hospitalization'
                 ELSE 'Hospitalization' END AS pre_post_hosp,
            pm.tpa_enrollment_id
       FROM tpa_enr_policy p
            LEFT OUTER JOIN tpa_group_registration g on(p.group_reg_seq_id = g.group_reg_seq_id)
            JOIN tpa_office_info i ON (p.tpa_office_seq_id = i.tpa_office_seq_id)
            JOIN tpa_enr_policy_group pg ON (p.policy_seq_id = pg.policy_seq_id)
            JOIN tpa_enr_policy_member pm ON (pg.policy_group_seq_id = pm.policy_group_seq_id)
            LEFT OUTER JOIN tpa_general_code gc ON (pm.gender_general_type_id = gc.general_type_id)
            LEFT OUTER JOIN tpa_relationship_code rc ON (pm.relship_type_id = rc.relship_type_id)
            LEFT OUTER JOIN tpa_enr_balance bal ON (pg.policy_group_seq_id = bal.policy_group_seq_id)
            LEFT OUTER JOIN clm_enroll_details ce ON (pm.member_seq_id = ce.member_seq_id)
            LEFT OUTER JOIN clm_general_details cg ON (ce.claim_seq_id = cg.claim_seq_id)
            LEFT OUTER JOIN clm_inward ci ON (cg.claims_inward_seq_id = ci.claims_inward_seq_id)
            LEFT OUTER JOIN chgdtl ON (cg.claim_seq_id = chgdtl.claim_seq_id)
            LEFT OUTER JOIN tpa_general_code ctgc ON (ci.claim_general_type_id = ctgc.general_type_id)
            JOIN tpa_claims_payment clp ON (cg.claim_seq_id = clp.claim_seq_id)
            LEFT OUTER JOIN tpa_general_code sgc ON (ce.clm_status_general_type_id = sgc.general_type_id)
            LEFT OUTER JOIN pat_enroll_details pe ON (pm.member_seq_id = pe.member_seq_id AND cg.pat_enroll_detail_seq_id = pe.pat_enroll_detail_seq_id)
            LEFT OUTER JOIN pat_general_details pd ON (pe.pat_enroll_detail_seq_id = pd.pat_enroll_detail_seq_id AND pd.pat_enhanced_yn = 'N')
            LEFT OUTER JOIN clm_hospital_association clha ON (cg.claim_seq_id = clha.claim_seq_id)
            LEFT OUTER JOIN tpa_hosp_info hi ON (clha.hosp_seq_id = hi.hosp_seq_id)
            LEFT OUTER JOIN tpa_hosp_address ha ON (hi.hosp_seq_id = ha.hosp_seq_id)
            LEFT OUTER JOIN tpa_city_code cc ON (ha.city_type_id = cc.city_type_id)
            LEFT OUTER JOIN ailment_details ad ON (cg.claim_seq_id = ad.claim_seq_id)
            LEFT OUTER JOIN procs ON (cg.claim_seq_id = procs.claim_seq_id)
            JOIN tpa_float_account fa ON (clp.float_seq_id=fa.float_seq_id)
          WHERE (pm.mem_general_type_id = 'PFL' AND bal.member_seq_id IS NULL OR pm.member_seq_id = bal.member_seq_id)
            AND fa.float_account_number=Parameter(2)
            AND clp.claim_aprv_date >= to_date(Parameter(3),'dd/mm/yyyy') AND clp.claim_aprv_date < to_date(Parameter(4),'dd/mm/yyyy') + 1
            AND clp.claim_payment_status ='PENDING';
    END IF;
  END Get_76_col_rpt_data;
--===============================================================================================
/* This procedure is called from Get_76_col_rpt_data procedure in case of data required about
   claims attached to a debit note.
*/
  PROCEDURE A76_col_debit_note_rpt (
      FilterValues  IN VARCHAR2,
      v_resultset    OUT SYS_REFCURSOR
    )
    IS
      Parameter      Ttk_Util_Pkg.str_table_type;
    BEGIN
      Parameter := ttk_util_pkg.parse_str(FilterValues);
      --- Parameter(5) = 'F' Indicates float_account_number in parameter(2). 'D' for debit_seq_id
      OPEN v_resultset FOR
      WITH chgdtl AS ( SELECT bh.claim_seq_id, MIN(bh.bill_date) as bill_date, SUM(bd.allowed_amount) AS Hosp_charges,
                      SUM(CASE WHEN wa.acc_group_name = 'Stay Charges' THEN bd.allowed_amount ELSE 0 END) as Room_nursing_charges,
                      SUM(CASE WHEN wa.acc_group_name = 'Surgery Charges' THEN bd.allowed_amount ELSE 0 END) as Surgery_charges,
                      SUM(CASE WHEN wa.acc_group_name = 'Consultation Charges' THEN bd.allowed_amount ELSE 0 END) as Consultant_charges,
                      SUM(CASE WHEN wa.acc_group_name = 'Investigation Charges' THEN bd.allowed_amount ELSE 0 END) as Investigation_charges,
                      SUM(CASE WHEN wa.acc_group_name = 'Medicines & Drug/implants' THEN bd.allowed_amount ELSE 0 END) as Medicine_charges,
                      SUM(CASE WHEN wa.acc_group_name NOT IN ('Stay Charges','Surgery Charges', 'Consultation Charges',
                                                              'Investigation Charges', 'Medicines & Drug/implants')
                                    THEN bd.allowed_amount ELSE 0 END) as Miscellaneous_charges
                 FROM clm_bill_header bh JOIN clm_bill_details bd ON (bh.clm_bill_seq_id = bd.clm_bill_seq_id)
                      JOIN tpa_claims_payment cp ON (bh.claim_seq_id = cp.claim_seq_id)
                      JOIN fin_app.tpa_debit_note_claims_assoc dca ON (cp.claim_seq_id = dca.claim_seq_id)
                      LEFT OUTER JOIN prod_ward_groupings wg ON (bd.ward_type_id = wg.ward_type_id)
                      JOIN ward_account_group wa ON (wg.ward_acc_group_seq_id = wa.ward_acc_group_seq_id  AND wa.group_show_type = 'IRD')
                    WHERE dca.debit_seq_id = Parameter(2) AND cp.claim_payment_status = 'DEBIT_NOTE_ATTACHED'
                      GROUP BY bh.claim_seq_id ),
       procs AS (SELECT claim_seq_id, pat_gen_detail_seq_id,
                        SUBSTR(MAX(substr(sys_connect_by_path (pcode,', '),2)),2,60) AS proc_code,
                        SUBSTR(MAX(SUBSTR(sys_connect_by_path (pdesc,'| '),2)),2) AS proc_desc,
                        SUBSTR(MAX(SUBSTR(sys_connect_by_path (icd_code,', '),2)),2) AS Icd_codes,
                        SUBSTR(MAX(SUBSTR(sys_connect_by_path (ped_desc,'| '),2)),2) AS Icd_desc
                  FROM (SELECT A.claim_seq_id, A.pat_gen_detail_seq_id, nvl( E.proc_code, F.proc_code) AS PCODE,
                               nvl(E.proc_description, F.proc_description) AS PDESC,
                               A.icd_code, G.ped_description AS ped_desc,
                               row_number() over (partition by A.claim_seq_id, A.pat_gen_detail_seq_id order by A.claim_seq_id, A.pat_gen_detail_seq_id) rn
                          FROM icd_pcs_detail A
                               LEFT OUTER JOIN pat_package_procedures B ON (A.icd_pcs_seq_id = B.icd_pcs_seq_id)
                               LEFT OUTER JOIN tpa_ped_code G ON (A.ped_code_id = G.ped_code_id)
                               JOIN tpa_claims_payment cp ON (A.claim_seq_id = cp.claim_seq_id)
                               JOIN fin_app.tpa_debit_note_claims_assoc dca ON (cp.claim_seq_id = dca.claim_seq_id)
                               LEFT OUTER JOIN tpa_hosp_tariff_item C ON (B.pkg_seq_id = C.pkg_seq_id)
                               LEFT OUTER JOIN tpa_hosp_pkg_proc D ON (C.pkg_seq_id = D.pkg_seq_id)
                               LEFT OUTER JOIN tpa_hosp_procedure_code E ON (D.proc_seq_id = E.proc_seq_id)
                               LEFT OUTER JOIN tpa_hosp_procedure_code F ON (B.proc_seq_id = F.proc_seq_id)
                            WHERE dca.debit_seq_id = Parameter(2) AND cp.claim_payment_status = 'DEBIT_NOTE_ATTACHED'
                            ) START WITH rn = 1
                               CONNECT BY rn = PRIOR rn + 1 AND
                                          (PRIOR claim_seq_id = claim_seq_id OR PRIOR pat_gen_detail_seq_id = pat_gen_detail_seq_id)
                                  GROUP BY claim_seq_id , pat_gen_detail_seq_id)

       SELECT DISTINCT i.office_name, g.group_name, p.policy_number, ' ' AS IL_Branch, ' ' AS Region,
              to_char(p.effective_from_date,'dd/mm/yyyy') AS effective_from_date,
              to_char(p.effective_to_date,'dd/mm/yyyy') AS effective_to_date, ' ' AS date_of_placement,
              pg.insured_name, pm.mem_name, gc.description, rc.relship_description,
              pm.mem_age, to_char(pm.mem_dob,'dd/mm/yyyy') AS mem_dob,
              (bal.sum_insured - bal.utilised_sum_insured) + (bal.BONUS - bal.UTILISED_CUM_BONUS) AS BALANCE,
              --pm.mem_tot_sum_insured,
              CASE WHEN pm.mem_general_type_id = 'PFL' THEN pg.floater_sum_insured
                   ELSE pm.mem_tot_sum_insured END AS mem_tot_sum_insured,
              pe.auth_number, clp.claim_settlement_no AS claim_number, pd.pat_requested_amount,
              pd.total_app_amount AS pat_total_app_amount,
              cg.requested_amount, cg.Total_App_Amount,
              (cg.requested_amount - cg.Total_App_Amount) AS Disallowed_amt,
              ' ' AS reserve_amt,
              ' ' AS corporate_floater_amt,
              CASE WHEN TRUNC(chgdtl.bill_date) BETWEEN TRUNC(cg.date_of_admission) AND TRUNC(cg.date_of_discharge)
                   THEN chgdtl.Hosp_charges ELSE 0 END AS hospital_bill_amt,
              CASE WHEN TRUNC(chgdtl.bill_date) < TRUNC(cg.Date_Of_Admission) THEN chgdtl.Hosp_charges ELSE 0 END AS pre_hosp_amt,
              CASE WHEN TRUNC(chgdtl.bill_date) > TRUNC(cg.date_of_discharge) THEN chgdtl.Hosp_charges ELSE 0 END AS post_hosp_amt,
              Room_nursing_charges,                      Surgery_charges,
              Consultant_charges,                        Investigation_charges,
              Medicine_charges,                          Miscellaneous_charges,
              ' ' AS amt_paid_to_member,
              ' ' AS amt_paid_to_hospital,
              to_char(pd.pat_received_date,'dd/mm/yyyy') AS pre_auth_date,
              to_char(pe.decision_date,'dd/mm/yyyy') AS al_date,
              to_char(cg.date_of_admission,'dd/mm/yyyy') AS date_of_admission,
              to_char(cg.date_of_discharge,'dd/mm/yyyy') AS date_of_discharge,
              to_char(ci.rcvd_date,'dd/mm/yyyy') AS dt_of_file_received,
              ' ' AS deficiencies_dt_raised_by_tpa,
              ' ' AS dt_of_doc_recovery,
              ' ' AS date_send_to_ilgic_for_payment,
              ' ' AS date_paid_by_ilgic,
              ' ' AS lot_no,
              ' ' AS date_of_pay_to_member,
              ' ' AS date_of_pay_to_hospital,
              ' ' AS date_chq_disp_hosp,
              ' ' AS date_chq_disp_mem,
              ' ' AS date_closure_letter_disp,
              ' ' AS date_rejection_letter_disp,
              to_char(ce.decision_date,'dd/mm/yyyy') AS claim_completion_date,
              ' ' AS cheque_no_mem,
              ' ' AS cheque_no_hosp,
              ' ' AS status,
              ' ' AS reason_of_rejection,
              ' ' AS rejected_date,
              ' ' AS closed_date,
              CASE WHEN ((cg.date_of_discharge - cg.date_of_admission)*24*60*60)/3600 > 24 THEN 'IPD' ELSE 'OPD' END AS ipd_opd,
              ctgc.description AS type_of_claim,
              CASE WHEN clp.claim_payment_status IS NOT NULL THEN clp.claim_payment_status ELSE sgc.description END AS stage,
              i.office_code AS tpa_processing_region,
              CASE WHEN ci.claim_general_type_id = 'CNH' THEN hi.hosp_name ELSE clha.hosp_name END AS Hosp_name,
              CASE WHEN ci.claim_general_type_id = 'CNH' THEN cc.city_description ELSE clha.city_name END AS Hosp_location,
              CASE WHEN TRIM(procs.Icd_desc) != '|' THEN procs.Icd_desc ELSE NULL END AS ailment,
              ad.provisional_diagnosis,
              CASE WHEN TRIM( procs.proc_desc) != '|' THEN procs.proc_desc ELSE NULL END AS  proc_desc,
              CASE WHEN TRIM(procs.Icd_codes) != ',' THEN procs.Icd_codes ELSE NULL END AS Icd_codes,
              CASE WHEN TRIM(procs.proc_code) != ',' THEN procs.proc_code ELSE NULL END AS proc_code,
              CASE WHEN TRUNC(chgdtl.bill_date) < TRUNC(cg.Date_Of_Admission) THEN 'Pre-Hospitalization'
                   WHEN TRUNC(chgdtl.bill_date) > TRUNC(cg.date_of_discharge) THEN 'Post-Hospitalization'
                   ELSE 'Hospitalization' END AS pre_post_hosp,
              pm.tpa_enrollment_id
         FROM tpa_enr_policy p
              LEFT OUTER JOIN tpa_group_registration g on(p.group_reg_seq_id = g.group_reg_seq_id)
              JOIN tpa_office_info i ON (p.tpa_office_seq_id = i.tpa_office_seq_id)
              JOIN tpa_enr_policy_group pg ON (p.policy_seq_id = pg.policy_seq_id)
              JOIN tpa_enr_policy_member pm ON (pg.policy_group_seq_id = pm.policy_group_seq_id)
              LEFT OUTER JOIN tpa_general_code gc ON (pm.gender_general_type_id = gc.general_type_id)
              LEFT OUTER JOIN tpa_relationship_code rc ON (pm.relship_type_id = rc.relship_type_id)
              LEFT OUTER JOIN tpa_enr_balance bal ON (pg.policy_group_seq_id = bal.policy_group_seq_id)
              LEFT OUTER JOIN clm_enroll_details ce ON (pm.member_seq_id = ce.member_seq_id)
              LEFT OUTER JOIN clm_general_details cg ON (ce.claim_seq_id = cg.claim_seq_id)
              LEFT OUTER JOIN clm_inward ci ON (cg.claims_inward_seq_id = ci.claims_inward_seq_id)
              LEFT OUTER JOIN chgdtl ON (cg.claim_seq_id = chgdtl.claim_seq_id)
              LEFT OUTER JOIN tpa_general_code ctgc ON (ci.claim_general_type_id = ctgc.general_type_id)
              JOIN tpa_claims_payment clp ON (cg.claim_seq_id = clp.claim_seq_id)
              JOIN fin_app.tpa_debit_note_claims_assoc dca ON (clp.claim_seq_id = dca.claim_seq_id)
              LEFT OUTER JOIN tpa_general_code sgc ON (ce.clm_status_general_type_id = sgc.general_type_id)
              LEFT OUTER JOIN pat_enroll_details pe ON (pm.member_seq_id = pe.member_seq_id AND cg.pat_enroll_detail_seq_id = pe.pat_enroll_detail_seq_id)
              LEFT OUTER JOIN pat_general_details pd ON (pe.pat_enroll_detail_seq_id = pd.pat_enroll_detail_seq_id AND pd.pat_enhanced_yn = 'N')
              LEFT OUTER JOIN clm_hospital_association clha ON (cg.claim_seq_id = clha.claim_seq_id)
              LEFT OUTER JOIN tpa_hosp_info hi ON (clha.hosp_seq_id = hi.hosp_seq_id)
              LEFT OUTER JOIN tpa_hosp_address ha ON (hi.hosp_seq_id = ha.hosp_seq_id)
              LEFT OUTER JOIN tpa_city_code cc ON (ha.city_type_id = cc.city_type_id)
              LEFT OUTER JOIN ailment_details ad ON (cg.claim_seq_id = ad.claim_seq_id)
              LEFT OUTER JOIN procs ON (cg.claim_seq_id = procs.claim_seq_id)
            WHERE (pm.mem_general_type_id = 'PFL' AND bal.member_seq_id IS NULL OR pm.member_seq_id = bal.member_seq_id)
              AND dca.debit_seq_id = Parameter(2) AND clp.claim_payment_status = 'DEBIT_NOTE_ATTACHED'
             ;
  END A76_col_debit_note_rpt;
--===============================================================================================
--==================================================================================
--This Procedure is used to generate a Covering Letter for issued cheques.
  PROCEDURE cheque_covering_letter(
    v_payment_seq_id          IN  VARCHAR2,
    resultset                OUT  SYS_REFCURSOR
  )
  IS
    v_sql_str               varchar2(6000);
    v_payment_seq_id_list  VARCHAR2(4000) := REPLACE(SUBSTR(v_payment_seq_id,2,LENGTH(v_payment_seq_id)-2) ,'|',',') ;
  BEGIN

  execute immediate ' update tpa_claims_payment p set p.che_cov_gen_date=sysdate
        where p.payment_seq_id in ('||v_payment_seq_id_list||') and p.che_cov_gen_date IS null';  --  koc_shortfall_Ltr_modification
     commit;

    v_sql_str := 
    'SELECT ''CLAIM SETTLEMENT ADVICE'',
        TO_CHAR(SYSDATE,''DD/MM/YYYY'') AS print_date,
        E.tpa_enrollment_id AS ttk_id_no,
        w.insured_name AS insured_name,
        tep.policy_number AS policy_number,
        X.mem_name as clm_name,
        A.claim_settlement_no AS settlement_no,
        A.claim_file_number AS claim_file_no,
        A.approved_amount AS claimed_amount,
        ttk_util_pkg.fn_decrypt(A.payee_name) AS payee,  --Modified for koc11ed
        C.check_num AS chk_num,
        C.check_amount AS chk_amt,
        SUBSTR(ttk_util_pkg.num_to_words(C.check_amount),1) AS amount_in_words,
        TO_CHAR(C.check_date,''DD/MM/YYYY'') AS chk_date,
        CASE
          WHEN A.address2 IS NOT NULL AND A.address3 IS NOT NULL THEN A.address1 ||'',''||A.address2 ||'',''||A.address3
          WHEN A.address2 IS NOT NULL THEN A.address1||'',''||A.address2
          WHEN A.address3 IS NOT NULL THEN A.address1||'',''||A.address3
          ELSE A.address1
        END AS payee_address ,
        CASE
          WHEN A.city IS NOT NULL AND A.pincode IS NOT NULL THEN A.city||''-''||TO_CHAR(A.pincode)
          WHEN A.city IS NOT NULL THEN A.city
          WHEN A.pincode IS NOT NULL THEN TO_CHAR(A.pincode)
          END AS city_addr,
        L.group_name  as corp_name,
        CASE
          WHEN a.mob_num IS NOT NULL AND a.home_phone IS NOT NULL AND a.phone1 IS NOT NULL THEN ''(Mob):''||a.mob_num||'' (Res):''||a.home_phone||'' (Off):''||a.phone1
          WHEN a.mob_num IS NOT NULL AND a.home_phone IS NOT NULL THEN ''(Mob):''||a.mob_num||'' (Res):''||a.home_phone
          WHEN a.mob_num IS NOT NULL AND a.phone1 IS NOT NULL THEN ''(Mob):''||a.mob_num||'' (Off):''||a.phone1
          WHEN a.home_phone IS NOT NULL AND a.phone1 IS NOT NULL THEN '' (Res):''||a.home_phone||'' (Off):''||a.phone1
          WHEN a.mob_num IS NOT NULL THEN ''(Mob):''||a.mob_num
          WHEN a.home_phone IS NOT NULL THEN '' (Res):''||a.home_phone
          WHEN a.phone1 IS NOT NULL THEN '' (Off):''||a.phone1
          ELSE NULL
        END AS phone,
        l.group_name,
        n.hosp_name,
        to_char(a.che_cov_gen_date,''dd/mm/yyyy'') letter_gen_date --  koc_shortfall_Ltr_modification
        FROM tpa_claims_payment A JOIN tpa_payment_checks_details B ON (A.payment_seq_id = B.payment_seq_id)
        JOIN TPA_INS_INFO II ON (II.INS_SEQ_ID=A.INS_SEQ_ID)
        JOIN tpa_claims_check C ON (C.claims_chk_seq_id = B.claims_chk_seq_id)
        LEFT OUTER JOIN tpa_group_registration L ON(A.group_reg_seq_id = L.group_reg_seq_id)
        JOIN clm_authorization_details X ON ( A.claim_seq_id = X.claim_seq_id )
        LEFT OUTER JOIN app.clm_hospital_details dd on(X.CLAIM_SEQ_ID = dd.claim_seq_id)
        LEFT OUTER JOIN tpa_hosp_info N ON (dd.hosp_seq_id = n.hosp_seq_id)
        LEFT OUTER JOIN tpa_enr_policy_member E ON (X.member_seq_id = E.member_seq_id)
        LEFT OUTER JOIN tpa_enr_policy_group W ON (X.policy_seq_id = W.policy_seq_id)
        LEFT OUTER JOIN tpa_enr_policy tep ON (X.policy_seq_id = tep.policy_seq_id)
        WHERE A.payment_seq_id IN ('||v_payment_seq_id_list||') AND c.check_status=''CSI''';


     v_sql_str := v_sql_str || ' ORDER BY C.check_num';
     OPEN resultset FOR v_sql_str;

  END cheque_covering_letter;
--===================================================================================
--==================================================================================
--This Procedure is used to generate a Address Label for issued cheques.
 PROCEDURE address_label(
    v_payment_seq_id          IN  VARCHAR2,
    resultset                OUT  SYS_REFCURSOR
  )
  IS
    v_sql_str               varchar2(4000);
    v_payment_seq_id_list  VARCHAR2(2000) := REPLACE(SUBSTR(v_payment_seq_id,2,LENGTH(v_payment_seq_id)-2) ,'|',',') ;


  BEGIN

--empno and empname added for address label report
    v_sql_str :=
        'SELECT
        X.tpa_enrollment_id AS ttk_id_no,
        tpg.insured_name,
        A.claim_settlement_no AS settlement_no,
        A.approved_amount AS claimed_amount,
        ttk_util_pkg.fn_decrypt(A.payee_name) AS payee, --Modified for koc11ed
        CASE WHEN A.Payee_Type=''EFT'' THEN ''EFT'' ELSE to_char(C.check_num) END AS chk_num,
        C.check_amount AS chk_amt,
        TO_CHAR(C.check_date,''DD/MM/YYYY'') AS chk_date,
        CASE
          WHEN A.address2 IS NOT NULL AND A.address3 IS NOT NULL THEN A.address1 ||'',''||A.address2 ||'',''||A.address3
          WHEN A.address2 IS NOT NULL THEN A.address1||'',''||A.address2
          WHEN A.address3 IS NOT NULL THEN A.address1||'',''||A.address3
          ELSE A.address1
        END AS payee_address ,
        CASE
            WHEN X.enrol_type_id=''COR'' THEN tma.city_type_id ELSE ''-''
          END AS city_addr,
         CASE WHEN tpg.employee_no IS NULL THEN ''-'' ELSE tpg.employee_no END AS employee_no,
        CASE WHEN  x.mem_name IS NULL THEN ''-'' ELSE  x.mem_name END AS employee_name

        FROM tpa_claims_payment A JOIN tpa_payment_checks_details B ON (A.payment_seq_id = B.payment_seq_id)
        JOIN tpa_claims_check C ON (C.claims_chk_seq_id = B.claims_chk_seq_id)
        JOIN clm_authorization_details X ON ( A.CLAIM_SEQ_ID = X.CLAIM_SEQ_ID )
        join tpa_enr_policy_member tpa on X.member_seq_id=tpa.member_seq_id
          join tpa_enr_policy_group tpg on tpa.policy_group_seq_id=tpg.policy_group_seq_id
          join tpa_enr_mem_address tma on tpg.enr_address_seq_id=tma.enr_address_seq_id
       WHERE A.payment_seq_id IN ('||v_payment_seq_id_list||')';

     v_sql_str := v_sql_str || ' ORDER BY C.check_num';


     OPEN resultset FOR v_sql_str;



  END address_label;

--===================================================================================
/*==============================================================================================
    Name       : fut_gen_claims_details_report
    Created on : 22-SEP-08
    Created By : Ramakrishna K M.
    Comments   : Used for Fetching Claim details which are paid belongs to Future Generali Insurance Company.
============================================================================================== */
  PROCEDURE fut_gen_claims_details_report(
     where_clause IN  VARCHAR2,
     result_set   OUT SYS_REFCURSOR
  )
  IS
    str_tab                ttk_util_pkg.str_table_type;
    v_from_date            DATE;
    v_to_date              DATE;
    v_float_seq_id         tpa_float_account.float_seq_id%TYPE;
  BEGIN
    str_tab     := ttk_util_pkg.parse_str ( where_clause );
    v_from_date := to_date(str_tab(3),'dd/mm/yyyy');
    v_to_date   := to_date(str_tab(4),'dd/mm/yyyy')+1;
    SELECT float_seq_id INTO v_float_seq_id FROM tpa_float_account WHERE float_account_number = str_tab(2);

    OPEN result_set FOR
    WITH CSR AS (SELECT  1 AS Units, 'CSR' AS Chq_status, 'Cancelled' AS Cheque_Status FROM DUAL UNION
                 SELECT -1 AS Units, 'CSR', NULL FROM DUAL UNION      -- THIS IS TO SHOW ONE RECORD WITH +VE APPROVED AMOUNT AND ANOTHER WITH -VE AMT IF CHEQUE IS REISSUED. IN CASE OF CHEQUE IS VOID THEN TO SHOW APPROVED AMT AS -VE.
                 SELECT -1 AS Units, 'CSV', NULL FROM DUAL ORDER BY Units DESC)
    SELECT
            k.group_name ,
            E.policy_number,
            G.employee_no AS emp_no,
            E.tpa_enrollment_id AS tpa_id_no,
            g.insured_name ,
            E.claimant_name,
            j.mem_age,
            a.claim_settlement_no,
            NVL(o.hosp_name,w.hosp_name ) AS hosp_name ,
            NVL(CI.city_description,w.city_name ) AS hosp_location ,
            ad.provisional_diagnosis AS final_diagnosis,
            TO_CHAR(d.date_of_admission,'DD/MM/YYYY') AS date_of_admission,
            TO_CHAR(d.date_of_discharge,'DD/MM/YYYY') AS date_of_discharge,
            CASE WHEN a.claim_payment_status = 'PAID' THEN D.requested_amount ELSE D.requested_amount * -1 END AS final_bill_amt,
            CASE WHEN a.claim_payment_status = 'PAID' THEN D.requested_amount - d.total_app_amount ELSE NULL END AS not_payable_amt,
            u.remarks AS reasons,
            D.total_app_amount * NVL(Units,1) AS amount_paid,
            CASE WHEN a.claim_payment_status = 'PAID' AND a.claim_type = 'CTM' AND NVL(D.PAY_TO_GENERAL_TYPE_ID,'MBR')!= 'HSL' THEN D.total_app_amount * NVL(CSR.Units,1) ELSE NULL END AS mem_paid_amount,
            --CASE WHEN a.claim_payment_status = 'PAID' AND a.claim_type = 'CNH' THEN s.total_app_amount * NVL(CSR.Units,1) ELSE NULL END AS cashless_amt,
            CASE WHEN a.claim_payment_status = 'PAID' AND (a.claim_type = 'CNH' OR NVL(D.PAY_TO_GENERAL_TYPE_ID,'MBR')= 'HSL')THEN D.total_app_amount * NVL(Units,1) ELSE NULL END AS cashless_amt,
            TO_CHAR(H.EFFECTIVE_FROM_DATE,'DD/MM/YYYY') AS POLICY_START_DATE,
            to_char(h.effective_to_date,'DD/MM/YYYY') AS POLICY_END_DATE ,
            to_char(a.claim_aprv_date,'DD/MM/YYYY') AS dt_of_settlement ,
            ttk_util_pkg.fn_decrypt(a.payee_name) payee_name, --Modified for koc11ed
            CT.description AS claim_type,
            CASE WHEN a.claim_payment_status = 'PAID' THEN
                      CASE WHEN CSR.Units = -1 AND ss.check_status = 'CSR' THEN to_char(ss.Void_Date,'dd/mm/yyyy')
                           ELSE to_char(ss.check_date,'dd/mm/yyyy') END ELSE NULL END AS date_of_payment,
            CASE WHEN a.claim_payment_status = 'PAID' THEN ss.check_num ELSE NULL END AS check_num,
            CASE WHEN a.claim_payment_status = 'PAID' THEN
              ss.check_amount * NVL(CSR.Units,1) ELSE NULL END AS cheque_amount_paid
        FROM tpa_claims_payment A JOIN tpa_ins_info B ON( A.ins_seq_id = B.ins_seq_id AND a.float_seq_id = v_float_seq_id)
              JOIN clm_general_details D ON(A.claim_seq_id = D.claim_seq_id)
              JOIN clm_enroll_details E ON ( D.claim_seq_id = E.claim_seq_id )
              JOIN tpa_enr_policy_member J ON (a.member_seq_id = j.member_seq_id)
              JOIN tpa_enr_policy_group G ON (j.policy_group_seq_id = g.policy_group_seq_id )
              JOIN tpa_enr_policy H ON(H.policy_seq_id = G.policy_seq_id)
              LEFT OUTER JOIN tpa_group_registration k ON (a.group_reg_seq_id = k.group_reg_seq_id)
              LEFT OUTER JOIN tpa_hosp_info o ON (a.hosp_seq_id = o.hosp_seq_id)
              LEFT OUTER JOIN pat_enroll_details r ON (d.pat_enroll_detail_seq_id = r.pat_enroll_detail_seq_id)
              LEFT OUTER JOIN pat_general_details s ON (r.pat_enroll_detail_seq_id = s.pat_enroll_detail_seq_id AND s.pat_enhanced_yn = 'N')
              LEFT OUTER JOIN assign_users U ON (d.last_assign_user_seq_id = u.assign_users_seq_id)
              LEFT OUTER JOIN clm_hospital_association w ON (a.claim_seq_id = w.claim_seq_id)
              JOIN  tpa_payment_checks_details rr ON (a.payment_seq_id = rr.payment_seq_id)
              JOIN tpa_claims_check ss ON (rr.claims_chk_seq_id  = ss.claims_chk_seq_id)
              LEFT OUTER JOIN CSR ON ss.check_status = CSR.Chq_status
              JOIN tpa_general_code CT ON (A.claim_type = CT.general_type_id)
              JOIN ailment_details ad ON (a.Claim_Seq_Id = ad.claim_seq_id)
              LEFT OUTER JOIN tpa_hosp_address HA ON (O.hosp_seq_id = HA.hosp_seq_id)
              LEFT OUTER JOIN tpa_city_code CI ON (HA.city_type_id=CI.city_type_id)
        WHERE (a.claim_payment_status = 'PAID' AND SS.check_status != 'CSV' AND SS.check_date BETWEEN v_from_date AND v_to_date)
           OR (ss.check_status = 'CSV' AND ss.void_date BETWEEN v_from_date AND v_to_date)
         ORDER BY ins_comp_code_number, check_date;

 END fut_gen_claims_details_report;

--===============================================================================================
/*\*==============================================================================================
    Name       : claim_computation
    Created on : 20-OCT-08
    Created By : Ramakrishna K M.
    Comments   : this Proceudre is used to generate Claims Approval letter Caluclations.
============================================================================================== *\
 PROCEDURE claim_computation (
    v_payment_seq_id          IN  VARCHAR2,
    v_resultset       OUT SYS_REFCURSOR
  )
  IS
    str_tab                 ttk_util_pkg.str_table_type;
    v_icd_codes             VARCHAR2(100);
    v_flag                  CHAR := 'N';
    v_payment_seq_id_list  VARCHAR2(2000) := REPLACE(SUBSTR(v_payment_seq_id,2,LENGTH(v_payment_seq_id)-2) ,'|',',') ;
    v_sql_str               varchar2(8000);
  BEGIN
    \*str_tab                            := ttk_util_pkg.parse_str ( v_claim_seq_id );

    FOR rec IN (SELECT a.icd_code FROM icd_pcs_detail a WHERE a.claim_seq_id = str_tab(1))
    LOOP
      IF v_flag = 'N' THEN
        v_icd_codes := rec.icd_code;
        v_flag := 'Y';
      ELSE
        v_icd_codes := v_icd_codes ||','||rec.icd_code;
      END IF;
    END LOOP;*\
--    END IF;
      --bill details displayed if only status is approved.

    execute immediate 'update tpa_claims_payment ad set ad.bat_rpt_clm_gen_date=sysdate
     where ad.payment_seq_id in ('||v_payment_seq_id_list||') and ad.bat_rpt_clm_gen_date is null';  --  koc_shortfall_Ltr_modification
    commit;

    v_sql_str :=
        'SELECT ''MEDICLAIM COMPUTATION'',
          A.claim_number AS claim_no,
          A.claim_file_number AS claim_file_no,
          A.claim_settlement_number AS claim_settl_no,
          B.policy_number AS policy_no,
          B.tpa_enrollment_id AS ttk_id_no,
          C.ins_comp_name AS insurance_company,
          TO_CHAR(SYSDATE,''DD/MM/YYYY'') AS prn_date,
          D.enrol_description AS corporate,
          to_char(B.policy_effective_from,''DD/MM/YYYY'') AS doc,
          to_char(B.policy_effective_to,''DD/MM/YYYY'') AS doe,
          w.insured_name AS insured_person,
          J.relship_description AS rel_desc,
          TO_CHAR(A.date_of_admission,''DD/MM/YYYY HH:MI:SS AM'') AS doa,
          TO_CHAR(A.date_of_discharge,''DD/MM/YYYY HH:MI:SS AM'') AS dod,
          B.mem_age AS age,
          B.employee_no AS emp_no,
          B.mem_name AS claimant_name,
          CASE WHEN NVL(ep.tpa_cheque_issued_general_type,''IQI'') = ''IQC'' THEN ga.address_1 ELSE F.address_1 END AS ADDR1,
          CASE WHEN NVL(ep.tpa_cheque_issued_general_type,''IQI'') = ''IQC'' THEN ga.address_2 ELSE F.address_2 END AS ADDR2,
          CASE WHEN NVL(ep.tpa_cheque_issued_general_type,''IQI'') = ''IQC'' THEN ga.address_3 ELSE F.address_3 END AS ADDR3,
          CASE WHEN NVL(ep.tpa_cheque_issued_general_type,''IQI'') = ''IQC'' THEN ac.city_description||'' - ''||ga.pin_code
               ELSE F.city_type_id||'' - ''|| F.pin_code END AS CITY,
          ( SS.sum_insured - SS.utilised_sum_insured ) + ( SS.BONUS - SS.UTILISED_CUM_BONUS ) AS BALANCE,
          --B.mem_total_sum_insured AS sum_insured,
          A.in_patient_no AS ip_no,
          SS.BONUS AS bonus,
          A.pat_approved_amount AS auth_amount,
          A.total_app_amount AS settled_amt,
          CASE WHEN G.hosp_seq_id IS NOT NULL THEN p.hosp_name ELSE G.hosp_name END  AS hospital_name,
          CASE WHEN G.hosp_seq_id IS NOT NULL THEN q.address_1 ELSE G.address_1 END  AS hosp_addr1,
          CASE WHEN G.hosp_seq_id IS NOT NULL THEN q.address_2 ELSE G.address_2 END  AS hosp_addr2,
          CASE WHEN G.hosp_seq_id IS NOT NULL THEN q.address_3 ELSE G.address_3 END  AS hosp_addr3,
          CASE WHEN G.hosp_seq_id IS NOT NULL THEN ha.city_description ||''-''||Q.PIN_CODE ELSE G.city_name||''-''||G.PIN_CODE END  AS hosp_addr4,

          I.description AS claim_status,
          ttk_util_pkg.num_to_words(A.total_app_amount) AS sum_of_rupees,
          A.total_app_amount AS app_amt,
          a.discount_amount ,
          a.co_payment_amount ,
          A.total_app_amount + nvl(a.discount_amount,0) + nvl(a.co_payment_amount,0) AS tot_app,
          O.contact_name AS prepared_by,
          O.employee_number AS ttk_employee_no ,  ---------------------------------NEW COLUMN
          N.remarks AS remarks,
          R.provisional_diagnosis AS ailment_description,
          --v_icd_codes AS icd_code ,
         -- batch_report_pkg.get_icd_code(A.claim_seq_id)  AS icd_code,
          batch_report_pkg.get_icds(A.claim_seq_id ) AS icd_code,
          SS.sum_insured - SS.utilised_sum_insured AS balance_sum_insured ,
          to_char(b.decision_date,''DD/MM/YYYY HH:MI AM'') AS settlement_date ,
          t.group_name,
          ee.event_name,
          CASE WHEN h.claim_general_type_id = ''CNH'' THEN
          CASE WHEN had.issue_cheques_type_id = ''HOS'' THEN P.Hosp_Name ELSE had.management_name END
          ELSE CASE WHEN NVL(A.PAY_TO_GENERAL_TYPE_ID,''MBR'')!=''HSL'' THEN 
                  CASE WHEN cp.tpa_nhcp_cheques_issued_to=''TPA'' THEN ttk_util_pkg.fn_decrypt(cp.payee_name)ELSE 
                  (CASE WHEN ep.tpa_cheque_issued_general_type = ''IQC'' THEN  T.group_name
                  WHEN ep.tpa_cheque_issued_general_type = ''IQL'' THEN lc.group_name
                  ELSE W.Insured_Name END) END 
               ELSE CASE WHEN had.issue_cheques_type_id = ''HOS'' THEN P.Hosp_Name ELSE had.management_name END END 
          END AS payee_name,
          --B.ins_scheme,
          --B.certificate_no,
          bh.bill_no AS bill_no,
          bh.bill_date AS bill_date,
          wc.ward_description AS nature_of_expenditure,
          bd.requested_amount AS amt_claimed,
          bd.allowed_amount  AS amount_settled,
          bd.rejected_amount AS disallowed,
          CASE WHEN bd.remarks IS NOT NULL THEN REPLACE(bd.remarks,'' '',''  '') ELSE NULL END AS subremarks,
          to_char(cp.bat_rpt_clm_gen_date,''dd/mm/yyyy'') letter_gen_date  --  koc_shortfall_Ltr_modification
          FROM tpa_claims_payment CP JOIN clm_general_details A ON (CP.claim_seq_id=A.claim_seq_id)
          JOIN clm_authorization_details B ON (A.claim_seq_id = B.claim_seq_id)
          JOIN tpa_ins_info C ON (C.ins_seq_id = B.ins_seq_id)
          LEFT OUTER JOIN tpa_enrolment_type_code D ON (D.enrol_type_id = B.enrol_type_id)
          LEFT OUTER JOIN tpa_enr_policy_member E ON (B.member_seq_id = E.member_seq_id)
          LEFT OUTER JOIN tpa_enr_policy_group W ON (E.policy_group_seq_id = W.policy_group_seq_id )
          LEFT OUTER JOIN tpa_enr_policy tep ON (w.policy_seq_id = tep.policy_seq_id)
          LEFT OUTER JOIN tpa_enr_mem_address F ON (W.enr_address_seq_id = F.enr_address_seq_id)
          LEFT OUTER JOIN clm_hospital_association G ON (A.claim_seq_id = G.claim_seq_id)
          JOIN clm_inward H ON (A.claims_inward_seq_id = H.claims_inward_seq_id)
          JOIN tpa_general_code I ON (H.claim_general_type_id = I.general_type_id)
          LEFT OUTER JOIN tpa_relationship_code J ON (B.relship_type_id = J.relship_type_id)
          LEFT OUTER JOIN assign_users N ON (A.last_assign_user_seq_id = N.assign_users_seq_id )
          JOIN tpa_user_contacts O ON (N.assigned_to_user = O.contact_seq_id)
          LEFT OUTER JOIN tpa_hosp_info P ON (P.hosp_seq_id = G.hosp_seq_id)
          LEFT OUTER JOIN tpa_hosp_address Q ON (P.hosp_seq_id = Q.hosp_seq_id)
          LEFT OUTER JOIN tpa_hosp_account_details had ON P.HOSP_SEQ_ID = had.hosp_seq_id
          LEFT OUTER JOIN ailment_details R ON (A.claim_seq_id = R.claim_seq_id)
          LEFT OUTER JOIN tpa_group_registration T ON (T.group_reg_seq_id = W.group_reg_seq_id)
          LEFT OUTER JOIN tpa_group_registration lc ON (W.group_reg_seq_id = lc.group_reg_seq_id)
          LEFT OUTER JOIN tpa_enr_balance SS ON (e.policy_group_seq_id = SS.policy_group_seq_id)
          LEFT OUTER JOIN tpa_general_code TT on (TT.General_Type_Id = A.CLAIM_SUB_GENERAL_TYPE_ID)
          JOIN tpa_event ee ON (a.event_seq_id = ee.event_seq_id)
          LEFT OUTER JOIN tpa_address ga ON (ga.group_reg_seq_id = T.GROUP_REG_SEQ_ID)
          LEFT OUTER JOIN tpa_enr_policy ep ON (ep.policy_seq_id = W.POLICY_SEQ_ID)
          LEFT OUTER JOIN TPA_CITY_CODE ac ON (ac.city_type_id = ga.city_type_id)
          LEFT OUTER JOIN TPA_CITY_CODE ha ON (ha.city_type_id = Q.City_Type_Id)
          JOIN clm_bill_header bh ON (A.claim_seq_id= bh.claim_seq_id)
          JOIN clm_bill_details bd ON (bh.clm_bill_seq_id = bd.clm_bill_seq_id)
          JOIN tpa_hosp_ward_code wc ON (bd.ward_type_id = wc.ward_type_id)
          JOIN tpa_payment_checks_details pc on (cp.payment_seq_id = pc.payment_seq_id)
          JOIN tpa_claims_check cc on (pc.claims_chk_seq_id=cc.claims_chk_seq_id)
          WHERE CP.Payment_Seq_Id IN ('||v_payment_seq_id_list||')
          AND ( E.mem_general_type_id = ''PFL'' AND SS.member_seq_id IS NULL  OR  B.member_seq_id = SS.member_seq_id  OR B.member_seq_id IS NULL)
          AND cc.check_status IN (''CSI'',''CSC'') AND
         ((C.INS_COMP_NAME  LIKE ''CIGNA%'' AND CP.CLAIM_TYPE=''CNH'') or C.INS_COMP_NAME  NOT LIKE ''CIGNA%'')'; -- MODIFIED FOR KOC1105 AND cc.check_status=''CSI''';


          --v_sql_str := v_sql_str || ' ORDER BY CP.payment_seq_id';
          v_sql_str := v_sql_str || ' ORDER BY cc.check_num';
          OPEN v_resultset FOR v_sql_str;
  END claim_computation;*/
  /*==============================================================================================
    Name       : claim_computation
    Created on : 20-OCT-08
    Created By : Ramakrishna K M.
    Comments   : this Proceudre is used to generate Claims Approval letter Caluclations.
============================================================================================== */
 PROCEDURE claim_computation (
    v_payment_seq_id          IN  VARCHAR2,
    v_resultset       OUT SYS_REFCURSOR
  )
  IS
    str_tab                 ttk_util_pkg.str_table_type;
    v_icd_codes             VARCHAR2(100);
    v_flag                  CHAR := 'N';
    v_payment_seq_id_list   VARCHAR2(2000) := REPLACE(SUBSTR(v_payment_seq_id,2,LENGTH(v_payment_seq_id)-2) ,'|',',') ;
    v_sql_str               varchar2(8000);
  BEGIN
    
    execute immediate 'update tpa_claims_payment ad set ad.bat_rpt_clm_gen_date=sysdate
     where ad.payment_seq_id in ('||v_payment_seq_id_list||') and ad.bat_rpt_clm_gen_date is null';  --  koc_shortfall_Ltr_modification
    commit;

    OPEN v_resultset FOR
         SELECT 'MEDICLAIM COMPUTATION',
          b.claim_number AS claim_no,
          b.claim_file_number AS claim_file_no,
          b.settlement_number AS claim_settl_no,
          to_char(b.completed_date,'DD/MM/YYYY') as settlement_date,
          tgc.description as claim_type,
          c.ins_comp_name AS insurance_company,
          tep.policy_number as policy_no,
          d.enrol_description as corporate,
          to_char(tep.effective_from_date,'DD/MM/YYYY') AS doc,
          to_char(tep.effective_to_date,'DD/MM/YYYY') AS doe,
          ttk_util_pkg.fn_decrypt(cp.payee_name) as payee_name,
          e.tpa_enrollment_id AS ttk_id_no,
          J.relship_description AS rel_desc,
          b.mem_name as claimant_name,
          TO_CHAR(b.date_of_hospitalization,'DD/MM/YYYY HH:MI:SS AM') AS doa,
          TO_CHAR(b.date_of_discharge,'DD/MM/YYYY HH:MI:SS AM') AS dod,
          CASE WHEN NVL(tep.tpa_cheque_issued_general_type,'IQI') = 'IQC' THEN ga.address_1 ELSE F.address_1 END AS ADDR1,
          CASE WHEN NVL(tep.tpa_cheque_issued_general_type,'IQI') = 'IQC' THEN ga.address_2 ELSE F.address_2 END AS ADDR2,
          CASE WHEN NVL(tep.tpa_cheque_issued_general_type,'IQI') = 'IQC' THEN ga.address_3 ELSE F.address_3 END AS ADDR3,
          CASE WHEN NVL(tep.tpa_cheque_issued_general_type,'IQI') = 'IQC' THEN ac.city_description||' - '||ga.pin_code
               ELSE F.city_type_id||' - '|| F.pin_code END AS CITY,

          CASE WHEN G.hosp_seq_id IS NOT NULL THEN p.hosp_name ELSE G.hosp_name END  AS hospital_name,
          CASE WHEN G.hosp_seq_id IS NOT NULL THEN q.address_1 ELSE G.address_1 END  AS hosp_addr1,
          CASE WHEN G.hosp_seq_id IS NOT NULL THEN q.address_2 ELSE G.address_2 END  AS hosp_addr2,
          CASE WHEN G.hosp_seq_id IS NOT NULL THEN q.address_3 ELSE G.address_3 END  AS hosp_addr3,
          CASE WHEN G.hosp_seq_id IS NOT NULL THEN ha.city_description ||'-'||Q.PIN_CODE ELSE G.city_name||'-'||G.PIN_CODE END  AS hosp_addr4,
          w.insured_name AS insured_person,
          B.mem_age AS age, 
          w.employee_no emp_no,
          null as ip_no,
          null as bonus,
          pad.tot_approved_amount AS auth_amount,
          tep.total_sum_insured as sum_insured,
          b.tot_approved_amount as settled_Amt,
          b.tot_approved_amount  AS amount_settled,
          b.ava_sum_insured AS BALANCE,
          b.tot_approved_amount + nvl(b.tot_discount_amount,0) + nvl(b.tot_patient_share_amount,0) AS tot_app,
          cp.added_by AS prepared_by,
          b.tot_discount_amount as discount_amount,
          case when b.clm_status_type_id = 'REJ' Then (B.Tot_Disc_Gross_Amount-b.tot_patient_share_amount) Else Null END  AS disallowed,
          tcg.description as Claim_status,
          b.tot_patient_share_amount as co_payment_amount,
          null as ttk_employee_no,
          null AS bill_no,
          null AS bill_date,
          null AS nature_of_expenditure,
          null as subremarks,
          null as Ailment_DESCRIPTION,
          null as event_name,
          dd.diagnosys_code AS icd_code,
          null as final_diag,
          null as remarks,
          null as ins_scheme,
          null as certificate_no,
          t.group_name ,
          (b.tot_disc_gross_amount - b.tot_patient_share_amount) as amt_claimed,
          b.tot_approved_amount as app_amt,
          TO_CHAR(SYSDATE,'DD/MM/YYYY') AS prn_date,
          ttk_util_pkg.num_to_words(b.tot_approved_amount) AS sum_of_rupees
          FROM tpa_claims_payment CP 
          JOIN clm_authorization_details B ON (CP.claim_seq_id = B.claim_seq_id)
          JOIN tpa_ins_info C ON (C.ins_seq_id = B.ins_seq_id)
          JOIN tpa_payment_checks_details pc on (cp.payment_seq_id = pc.payment_seq_id)
          JOIN tpa_claims_check cc on (pc.claims_chk_seq_id = cc.claims_chk_seq_id)
          LEFT OUTER JOIN app.pat_authorization_details pad on (b.pat_auth_seq_id = pad.pat_auth_seq_id)
          LEFT OUTER JOIN app.diagnosys_details dd ON (b.claim_seq_id = dd.claim_seq_id)
          LEFT OUTER JOIN tpa_enrolment_type_code D ON (D.enrol_type_id = B.enrol_type_id)
          LEFT OUTER JOIN tpa_enr_policy_member E ON (B.member_seq_id = E.member_seq_id)
          LEFT OUTER JOIN tpa_enr_policy_group W ON (E.policy_group_seq_id = W.policy_group_seq_id )
          LEFT OUTER JOIN tpa_enr_policy tep ON (w.policy_seq_id = tep.policy_seq_id)
          LEFT OUTER JOIN tpa_enr_mem_address F ON (W.enr_address_seq_id = F.enr_address_seq_id)
          LEFT OUTER JOIN app.clm_hospital_details G ON (B.claim_seq_id = G.claim_seq_id)
          LEFT OUTER JOIN tpa_relationship_code J ON (E.relship_type_id = J.relship_type_id)
          LEFT OUTER JOIN tpa_hosp_info P ON (P.hosp_seq_id = G.hosp_seq_id)
          LEFT OUTER JOIN tpa_hosp_address Q ON (P.hosp_seq_id = Q.hosp_seq_id)
          LEFT OUTER JOIN tpa_hosp_account_details had ON P.HOSP_SEQ_ID = had.hosp_seq_id
          LEFT OUTER JOIN tpa_group_registration T ON (T.group_reg_seq_id = W.group_reg_seq_id)
          LEFT OUTER JOIN tpa_enr_balance SS ON (e.policy_group_seq_id = SS.policy_group_seq_id)
          LEFT OUTER JOIN tpa_address ga ON (ga.group_reg_seq_id = T.GROUP_REG_SEQ_ID)
          LEFT OUTER JOIN TPA_CITY_CODE ac ON (ac.city_type_id = ga.city_type_id)
          LEFT OUTER JOIN TPA_CITY_CODE ha ON (ha.city_type_id = Q.City_Type_Id)
          LEFT OUTER JOIN app.tpa_general_code tgc on (b.claim_type = tgc.general_type_id)
          LEFT OUTER JOIN app.tpa_general_code tcg on (b.clm_status_type_id = tcg.general_type_id)
          WHERE CP.Payment_Seq_Id IN (v_payment_seq_id_list)
          AND ( E.mem_general_type_id = 'PFL' AND SS.member_seq_id IS NULL  OR  B.member_seq_id = SS.member_seq_id  OR B.member_seq_id IS NULL)
          AND cc.check_status IN ('CSI','CSC')
          ORDER BY cc.check_num ; -- MODIFIED FOR KOC1105 AND cc.check_status=''CSI''';

      --OPEN v_resultset FOR v_sql_str;
  END claim_computation;

/*\*==============================================================================================
    Name       : claim_computation
    Created on : 20-OCT-08
    Created By : Ramakrishna K M.
    Comments   : this procedure is used to display the claims line items(viz ailment description)
============================================================================================== *\
  PROCEDURE claim_computation_lineitems(
    v_payment_seq_id    IN  VARCHAR2,
    v_resultset       OUT SYS_REFCURSOR
  )
  IS
    str_tab                 ttk_util_pkg.str_table_type;
    v_payment_seq_id_list  VARCHAR2(2000) := REPLACE(SUBSTR(v_payment_seq_id,2,LENGTH(v_payment_seq_id)-2) ,'|',',') ;
    v_sql_str               varchar2(8000);
  BEGIN
    --str_tab                            := ttk_util_pkg.parse_str ( v_claim_seq_id );
   --if Claim Status is Approved
    --OPEN v_resultset FOR

     execute immediate 'update tpa_claims_payment p set p.CLM_COM_GEN_DATE=sysdate
        where p.payment_seq_id in ('||v_payment_seq_id_list||') and p.CLM_COM_GEN_DATE IS null';  --  koc_shortfall_Ltr_modification
     commit;

    v_sql_str :=
      'SELECT  A.bill_no AS bill_no,
       A.bill_date AS bill_date,
       C.ward_description AS nature_of_expenditure,
       B.requested_amount AS amt_claimed,
       B.allowed_amount  AS amount_settled,
       B.rejected_amount AS disallowed,
       CP.claim_settlement_no,
       CASE WHEN B.remarks IS NOT NULL THEN REPLACE(B.remarks,'' '',''  '') ELSE NULL END AS remarks,
       to_char(cp.CLM_COM_GEN_DATE,''dd/mm/yyyy'') as letter_gen_date  --  koc_shortfall_Ltr_modification
       FROM tpa_claims_payment CP JOIN clm_bill_header A ON (CP.claim_seq_id= A.claim_seq_id)
        JOIN clm_bill_details B ON (A.clm_bill_seq_id = B.clm_bill_seq_id)
       JOIN tpa_hosp_ward_code C ON (B.ward_type_id = C.ward_type_id)
       JOIN tpa_payment_checks_details pc on (cp.payment_seq_id = pc.payment_seq_id)
       JOIN tpa_claims_check cc on (pc.claims_chk_seq_id=cc.claims_chk_seq_id)
       WHERE CP.payment_seq_id IN ('||v_payment_seq_id_list||')
       AND cc.check_status=''CSI''';

       --v_sql_str := v_sql_str || ' ORDER BY CP.payment_seq_id';
       v_sql_str := v_sql_str || ' ORDER BY cc.check_num';
       OPEN v_resultset FOR v_sql_str;
   END claim_computation_lineitems;*/
/*==============================================================================================
    Name       : EFT claim_computation
    Created on : 20-OCT-08
    Created By : Ramakrishna K M.
    Comments   : this procedure is used to display the claims line items(viz ailment description)
============================================================================================== */
  PROCEDURE claim_computation_lineitems(
    v_payment_seq_id    IN  VARCHAR2,
    v_resultset       OUT SYS_REFCURSOR
  )
  IS
    str_tab                 ttk_util_pkg.str_table_type;
    v_payment_seq_id_list  VARCHAR2(2000) := REPLACE(SUBSTR(v_payment_seq_id,2,LENGTH(v_payment_seq_id)-2) ,'|',',') ;
    v_sql_str               varchar2(8000);
  BEGIN
    --str_tab                            := ttk_util_pkg.parse_str ( v_claim_seq_id );
   --if Claim Status is Approved
    --OPEN v_resultset FOR

     execute immediate 'update tpa_claims_payment p set p.CLM_COM_GEN_DATE=sysdate
        where p.payment_seq_id in ('||v_payment_seq_id_list||') and p.CLM_COM_GEN_DATE IS null';  --  koc_shortfall_Ltr_modification
     commit;

    v_sql_str :=
      'SELECT null AS bill_no,
       null AS bill_date,
       null AS nature_of_expenditure,
       (B.Tot_Disc_Gross_Amount-b.tot_patient_share_amount) AS amt_claimed,
       B.Tot_Approved_Amount  AS amount_settled,
       case when b.clm_status_type_id = ''REJ'' Then (B.Tot_Disc_Gross_Amount-b.tot_patient_share_amount) Else Null END  AS disallowed,
       CP.claim_settlement_no,
       CASE WHEN B.Remarks IS NOT NULL THEN REPLACE(B.remarks,'' '',''  '') ELSE NULL END AS remarks,
       to_char(cp.CLM_COM_GEN_DATE,''dd/mm/yyyy'') as letter_gen_date  --  koc_shortfall_Ltr_modification
       FROM tpa_claims_payment CP 
       JOIN clm_authorization_details B ON (CP.claim_seq_id= B.claim_seq_id)
       JOIN tpa_payment_checks_details pc on (cp.payment_seq_id = pc.payment_seq_id)
       JOIN tpa_claims_check cc on (pc.claims_chk_seq_id=cc.claims_chk_seq_id)
       WHERE CP.payment_seq_id IN ('||v_payment_seq_id_list||')  AND cc.check_status=''CSI''';

       --v_sql_str := v_sql_str || ' ORDER BY CP.payment_seq_id';
       v_sql_str := v_sql_str || ' ORDER BY cc.check_num';
       OPEN v_resultset FOR v_sql_str;
   END claim_computation_lineitems;   
--===============================================================================================
  FUNCTION get_comp_icds(
     v_claims_seq_id           NUMBER ) RETURN VARCHAR2 DETERMINISTIC
  IS
     v_icd_codes             VARCHAR2(100);
     v_flag                  CHAR := 'N';
  BEGIN
    FOR rec IN (SELECT a.icd_code FROM icd_pcs_detail a WHERE a.claim_seq_id = v_claims_seq_id)
    LOOP
      IF v_flag = 'N' THEN
        v_icd_codes := rec.icd_code;
        v_flag := 'Y';
      ELSE
        v_icd_codes := v_icd_codes ||','||rec.icd_code;
      END IF;
    END LOOP;

    RETURN v_icd_codes;
  end get_comp_icds;
/*\* --==============================================================================================
  Name       : tds_fund_transfer_rpt
  Created on : -11-JUN-09
  Created By : - S.V.SREERAJ
  Company    : SPAN INFOTECH INDIA Pvt.Ltd.
  Comments   : This can used to get the TDS details of NHCP claims based on date range.
 --============================================================================================== *\
  PROCEDURE tds_fund_transfer_rpt (
    v_from_date               IN VARCHAR2,
    v_to_date                 IN VARCHAR2,
    v_account_number          IN TPA_BANK_ACCOUNTS.account_number%TYPE,
    v_resultset               OUT SYS_REFCURSOR
  )
  IS

  BEGIN
    OPEN v_resultset FOR
      SELECT
      c.account_number,
      c.account_name,
      b.float_account_number,
      b.float_account_name,
      e.ins_comp_name,
      e.abbrevation_code,
      f.city,
      d.approved_amount AS gross_payment,
      ( d.approved_amount - d.check_amount ) AS tds_amount,
      d.check_amount
      FROM TPA_CLAIMS_PAYMENT A JOIN TPA_FLOAT_ACCOUNT B ON (a.float_seq_id = b.float_seq_id)
      JOIN TPA_BANK_ACCOUNTS c ON (b.bank_acc_seq_id = c.bank_acc_seq_id )
      JOIN TPA_CLM_TDS_DETAILS d ON (a.payment_seq_id = d.payment_seq_id)
      JOIN TPA_INS_INFO e ON (a.ins_seq_id = e.ins_seq_id)
      JOIN TPA_ADDRESS f ON (e.ins_seq_id = f.ins_seq_id)
      WHERE d.added_date BETWEEN to_date(v_from_date,'dd/mm/yyyy') AND to_date(v_to_date,'dd/mm/yyyy') + 1
      AND v_account_number IS NULL OR c.account_number = v_account_number
      ORDER BY  account_number;

  END tds_fund_transfer_rpt;
\* --==============================================================================================
  Name       : tds_fund_transfer_rpt
  Created on : -11-JUN-09
  Created By : - S.V.SREERAJ
  Company    : SPAN INFOTECH INDIA Pvt.Ltd.
  Comments   : This can used to get the TDS details of NHCP claims based on date range.
 --============================================================================================== *\
  PROCEDURE tds_monthly_fund_transfer_rpt (
    v_month                   IN VARCHAR2,
    v_year                    IN VARCHAR2,
    v_account_number          IN TPA_BANK_ACCOUNTS.account_number%TYPE,
    v_resultset               OUT SYS_REFCURSOR
  )
  IS
    v_from_date                DATE := to_date('01/'||v_month||'/'||v_year,'dd/mm/yyyy');
    v_to_date                  DATE := last_day(to_date(v_month||'/'||v_year,'mm/yyyy'))+1;
  BEGIN
    OPEN v_resultset FOR
      SELECT
      to_char(trunc(d.added_date),'dd/mm/yyyy') AS payment_date,
      e.ins_comp_name,
      e.abbrevation_code,
      g.empanel_number AS hosp_code,
      g.hosp_name,
      h.city_type_id,
      i.city_description AS hosp_location,
      g.pan_number,
      d.approved_amount AS gross_amt,
      (d.approved_amount - d.check_amount) AS tds_amt,
      d.bat_perc,
      d.bat_amt,
      d.edc_perc,
      d.edc_amt,
      d.sur_perc,
      d.sur_amt,
      d.ms1_perc,
      d.ms1_amt,
      d.ms2_perc,
      d.ms2_amt
      FROM TPA_CLAIMS_PAYMENT A JOIN TPA_FLOAT_ACCOUNT B ON (a.float_seq_id = b.float_seq_id)
      JOIN TPA_BANK_ACCOUNTS c ON (b.bank_acc_seq_id = c.bank_acc_seq_id )
      JOIN TPA_CLM_TDS_DETAILS d ON (a.payment_seq_id = d.payment_seq_id)
      JOIN TPA_INS_INFO e ON (a.ins_seq_id = e.ins_seq_id)
      JOIN TPA_HOSP_INFO g ON (a.hosp_seq_id = g.hosp_seq_id)
      JOIN TPA_HOSP_ADDRESS h ON (g.hosp_seq_id = h.hosp_seq_id)
      JOIN TPA_CITY_CODE i ON (h.city_type_id = i.city_type_id)
      WHERE d.added_date BETWEEN v_from_date AND v_to_date
      AND v_account_number IS NULL OR c.account_number = v_account_number
      ORDER BY trunc(d.added_date),ins_comp_name,hosp_name ;

  END tds_monthly_fund_transfer_rpt;  */
/* --==============================================================================================
  Name       : tds_fund_transfer_rpt
  Created on : -24-JUN-09
  Created By : - S.V.SREERAJ
  Company    : SPAN INFOTECH INDIA Pvt.Ltd.
  Comments   : This can used to get the TDS details -- EXECUTED FROM THE SCHEDULER, DAILY
 --============================================================================================== */
  PROCEDURE tds_daily_rpt (v_resultset  OUT sys_refcursor)
  IS
  V_FROM_DATE             DATE;
  V_TO_DATE               DATE;
  BEGIN

  v_from_date         :=trunc(sysdate)-2;
  v_to_date           :=v_from_date+1;

    OPEN v_resultset FOR
      SELECT
      'V2_TIPS' AS application,
      to_char(v_from_date,'dd/mm/yyyy') AS generated_date,
      e.ins_comp_name,
      e.abbrevation_code,
      g.empanel_number AS hosp_code,
      g.hosp_name,
      h.city_type_id,
      i.city_description AS hosp_location,
      --g.pan_number,
      j.tpa_enrollment_id AS ttk_id,
      l.office_name AS ttk_branch,
      m.claim_number,
      a.claim_settlement_no,
      a.approved_amount AS claim_app_amt,
      (d.approved_amount - d.check_amount) AS tds_amt,
      d.bat_perc,
      d.bat_amt,
      d.edc_perc,
      d.edc_amt,
      d.sur_perc,
      d.sur_amt,
      d.ms1_perc,
      d.ms1_amt,
      d.ms2_perc,
      d.ms2_amt,
      d.check_amount AS cheque_amt,
      o.check_num,
      to_char(trunc(o.check_date),'dd/mm/yyyy') AS cheque_date,
      p.float_account_number,
      c.account_number AS bank_account_number,
      q.bank_name,
      CASE WHEN d.updated_yn = 'D' THEN 'Yes' ELSE NULL END AS Previously_deducted
      FROM TPA_CLAIMS_PAYMENT A JOIN TPA_FLOAT_ACCOUNT B ON (a.float_seq_id = b.float_seq_id)
      JOIN fin_app.TPA_BANK_ACCOUNTS c ON (b.bank_acc_seq_id = c.bank_acc_seq_id )
      JOIN TPA_CLM_TDS_DETAILS d ON (a.payment_seq_id = d.payment_seq_id)
      JOIN TPA_INS_INFO e ON (a.ins_seq_id = e.ins_seq_id)
      JOIN TPA_HOSP_INFO g ON (a.hosp_seq_id = g.hosp_seq_id)
      JOIN TPA_HOSP_ADDRESS h ON (g.hosp_seq_id = h.hosp_seq_id)
      JOIN TPA_CITY_CODE i ON (h.city_type_id = i.city_type_id)
      JOIN CLM_ENROLL_DETAILS J ON (a.claim_seq_id = j.claim_seq_id)
      JOIN tpa_enr_policy k ON (j.policy_seq_id = k.policy_seq_id)
      JOIN tpa_office_info l ON (k.tpa_office_seq_id = l.tpa_office_seq_id)
      JOIN clm_general_details m ON (a.claim_seq_id = m.claim_seq_id)
      LEFT OUTER JOIN tpa_payment_checks_details n ON (a.payment_seq_id = n.payment_seq_id)
      LEFT OUTER JOIN tpa_claims_check o ON (n.claims_chk_seq_id = o.claims_chk_seq_id)
      LEFT OUTER JOIN tpa_float_account p ON (a.float_seq_id = p.float_seq_id)
      JOIN fin_app.tpa_bank_master q ON (c.bank_seq_id = q.bank_seq_id)
      WHERE d.added_date BETWEEN v_from_date AND v_to_date
      ORDER BY trunc(d.added_date),ins_comp_name,hosp_name;
  END tds_daily_rpt;
  --=====================================================================================
  PROCEDURE tds_detail_report (
    v_search_str             IN VARCHAR2,
    v_result_set             OUT SYS_REFCURSOR
  )
  IS
    str_tab                 ttk_util_pkg.str_table_type:= ttk_util_pkg.parse_str(v_search_str);
    v_ins_comp_id           tpa_tds_report_master.ins_comp_id%TYPE := str_tab(2);
    v_start_date            DATE := to_date('01/'||str_tab(4)||'/'||str_tab(3),'dd/mm/yyyy');
    v_end_date              DATE := last_day(v_start_date);
  BEGIN
    OPEN v_result_set FOR SELECT
      a.ttk_branch,
      a.ins_comp_location,
      a.ins_comp_name,
      a.hosp_code,
      b.hosp_name,
      c.description AS hosp_reg_status,
      e.city_description AS city,
      --b.pan_number,
      b.tan_number,
      a.tpa_enrollment_id,
      a.claim_settlement_number,
      ttk_util_pkg.fn_decrypt(a.payee_name) as payee_name,
      a.insured_name,
      a.claimant_name,
      a.corporate_name,
      a.ind_or_group,
      a.ins_comp_id AS do_bo,
      a.policy_number,
      a.cheque_issued_by,
      a.mode_of_payment,
      a.cheque_status,
      ttk_util_pkg.fn_decrypt(a.bank_acct_number) as bank_acct_number,
      ttk_util_pkg.fn_decrypt(a.bank_name) as bank_name,
      a.float_acct_number,
      --------------
      a.float_account_name,
      a.tds_category,
      a.claim_app_amt,
      a.claim_app_amt - nvl(a.tds_amt,0) AS gross_amount,
      a.base_tax_perc,
      a.edu_cess_perc,
      a.surcharge_perc,
      a.ms1_perc,
      a.ms2_perc,
      a.base_tax,
      a.edu_cess,
      a.surcharge,
      a.ms1_amt,
      a.ms2_amt,
      a.cheque_amt,
      --------------------
      a.tds_amt,
      -------------
      a.base_tax_perc + nvl(a.edu_cess_perc,0)  + nvl(a.surcharge_perc,0) + nvl(a.ms1_perc,0) + nvl(a.ms2_perc,0) AS total_tds_perc,
      TO_CHAR(a.cheque_date,'DD/MM/YYYY') AS cheque_date,
      a.cheque_number,
      TO_CHAR(a.generated_date,'DD/MM/YYYY') AS generated_date,
      TO_CHAR(a.daily_remit_date,'DD/MM/YYYY') AS daily_remit_date,
      a.bank_transfer_acct_number,
      TO_CHAR(a.challan_date,'DD/MM/YYYY') AS challan_date,
      a.challan_ref_number,
      a.bsr_code,
      a.acknowledgement_number,
      TO_CHAR(a.acknowledgement_date,'DD/MM/YYYY') AS acknowledgement_date
      FROM TPA_TDS_REPORT_MASTER a JOIN tpa_hosp_info b ON (a.hosp_code = b.empanel_number)
      LEFT OUTER JOIN tpa_general_code c ON (b.hosp_owner_general_type_id = c.general_type_id)
      LEFT OUTER JOIN tpa_hosp_address d ON (b.hosp_seq_id = d.hosp_seq_id)
      LEFT OUTER JOIN tpa_city_code e ON (d.city_type_id = e.city_type_id)
      WHERE a.generated_date BETWEEN v_start_date AND v_end_date
      AND ( v_ins_comp_id IS NULL OR a.ins_comp_id = v_ins_comp_id )
      ORDER BY a.ins_comp_name,a.generated_date;

  END tds_detail_report;
  --=====================================================================================
  PROCEDURE daily_transfer_summary_report(
   v_search_str             IN VARCHAR2,
   v_result_set             OUT SYS_REFCURSOR
  )
  IS  --||NI|TDSC|01/03/2009||||

        str_tab                 ttk_util_pkg.str_table_type:= ttk_util_pkg.parse_str(v_search_str);
        v_ins_comp_id           tpa_tds_report_master.ins_comp_id%TYPE := str_tab(2);
        v_daily_status          VARCHAR2(10)       := str_tab(3);
        v_from_date            DATE := to_date(str_tab(4),'dd/mm/yyyy');
        v_to_date              DATE := to_date(str_tab(5),'dd/mm/yyyy');
        v_bank_acct_number tpa_tds_report_master.bank_acct_number%TYPE:= str_tab(6);
        v_sql_str   VARCHAR2(4000);
        TYPE bind_tab_type IS TABLE OF VARCHAR2(250) INDEX BY BINARY_INTEGER ;
        bind_tab    bind_tab_type;
        i           NUMBER(2) := 0;

  BEGIN

   v_sql_str:='SELECT td.bank_acct_number AS bank_account_no,
                      td.bank_name AS bank_name,
                      td.float_account_name AS float_name,
                      td.float_acct_number AS float_account_no,
                      td.ins_comp_location AS ins_comp_location,
                      td.ins_comp_name AS ins_comp_name,
                      td.claim_app_amt as gross_amt,
                      td.tds_amt AS total_tds_amt,  --total tds amt        tds_amt
                      td.cheque_amt AS net_payment,--total cheque amt         cheque_amt
                      td.base_tax_perc + nvl(td.edu_cess_perc,0)  + nvl(td.surcharge_perc,0) + nvl(td.ms1_perc,0) + nvl(td.ms2_perc,0) AS tds_percentage
                      --NULL AS tds_percentage
               FROM tpa_tds_report_master td
               WHERE td.excluded_yn=''N''
               AND td.ins_comp_id=:v_ins_comp_id ';

              i := i+1;
              bind_tab(i) := str_tab(2);

   IF v_daily_status ='TDSC' THEN
       v_sql_str:=v_sql_str||' AND td.daily_remit_date IS NOT NULL ';
   ELSE
       v_sql_str:=v_sql_str||' AND td.daily_remit_date IS NULL ';
   END IF;

   IF v_from_date IS NOT NULL THEN
      v_sql_str:=v_sql_str||' AND td.generated_date >= :v_from_date ';
      i := i+1;
      bind_tab(i) := v_from_date;
   END IF;

   IF v_to_date IS NOT NULL THEN
      v_sql_str:=v_sql_str||' AND td.generated_date <= :v_to_date ';
      i := i+1;
      bind_tab(i) := v_to_date;
   ELSE
      v_sql_str:=v_sql_str||' AND td.generated_date <= :v_to_date ';
      i := i+1;
      bind_tab(i) := trunc(SYSDATE);
   END IF;

   IF v_bank_acct_number IS NOT NULL THEN
     v_sql_str:=v_sql_str||' AND td.bank_acct_number=:v_bank_acct_number';
     i := i+1;
     bind_tab(i) := str_tab(6);
   END IF;


    CASE bind_tab.COUNT
        -- WHEN 1 THEN OPEN v_result_set FOR v_sql_str USING bind_tab(1) ;
         WHEN 2 THEN OPEN v_result_set FOR v_sql_str USING bind_tab(1),bind_tab(2);
         WHEN 3 THEN OPEN v_result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3);--,bind_tab(2);
         WHEN 4 THEN OPEN v_result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3),bind_tab(4);
         WHEN 5 THEN OPEN v_result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3),bind_tab(4),bind_tab(5);
    END CASE;

  END daily_transfer_summary_report;
--=====================================================================================
  PROCEDURE monthly_remit_sumary_report(
   v_search_str             IN VARCHAR2,
   v_result_set             OUT SYS_REFCURSOR
  )
  IS

        str_tab ttk_util_pkg.str_table_type:= ttk_util_pkg.parse_str(v_search_str);
        v_ins_comp_id   tpa_tds_report_master.ins_comp_id%TYPE := str_tab(2);--NM
        v_monthly_status  VARCHAR2(10)       := str_tab(3);-- Mandatory Pending or Completed TDSC if status is completed , year & month mandatory
        v_start_date            DATE;--use tpa_general_code MONTH
        v_end_date              DATE;
        TYPE bind_tab_type IS TABLE OF VARCHAR2(250) INDEX BY BINARY_INTEGER ;
        bind_tab    bind_tab_type;
        i           NUMBER(2) := 0;
        v_sql_str   VARCHAR2(4000);
       --||NI|TDSP||

  BEGIN
     v_sql_str:='SELECT  to_char(tdm.Generated_Date,''DD/MM/YYYY'') AS date_of_deduction,
                         tdm.ins_comp_name AS insurance_company,
                         tdm.claim_settlement_number AS claim_settlement_num,
                         tdm.hosp_code AS hosp_code,
                         hi.hosp_name AS hosp_name,
                         oi.office_name AS hosp_location,
                         hi.pan_number AS pan_number,
                         tdm.claim_app_amt AS gross_amt_approved,
                         tdm.base_tax_perc AS base_rate_perc,
                         tdm.surcharge_perc AS surcharge_perc,
                         tdm.edu_cess_perc AS edu_cess_perc,
                         tdm.base_tax_perc + nvl(tdm.edu_cess_perc,0)  + nvl(tdm.surcharge_perc,0) + nvl(tdm.ms1_perc,0) + nvl(tdm.ms2_perc,0) AS tds_percentage,
                         tdm.base_tax AS base_rate,
                         tdm.surcharge AS surcharge,
                         tdm.edu_cess AS edu_cess,
                         tdm.tds_amt AS total_tds_amount
                    FROM tpa_tds_report_master tdm
                         JOIN tpa_hosp_info hi ON (tdm.hosp_code=hi.empanel_number)
                         JOIN tpa_office_info oi ON (oi.tpa_office_seq_id=hi.tpa_office_seq_id) WHERE ';

    IF v_monthly_status ='TDSC' THEN
       v_start_date:= CASE WHEN str_tab(5) <=0 THEN NULL ELSE to_date('01/'||str_tab(4)||'/'||str_tab(5),'dd/mm/yyyy') END;
       v_end_date  := last_day(v_start_date);
       --v_sql_str:=v_sql_str|| 'tdm.monthly_remit_date BETWEEN :v_start_date AND :v_end_date ';
       v_sql_str:=v_sql_str|| 'tdm.month_of_remit BETWEEN :v_start_date AND :v_end_date ';
       i := i+1;
       bind_tab(i) :=   v_start_date;
       i := i+1;
       bind_tab(i) := v_end_date;
    ELSE
       v_sql_str:=v_sql_str||'tdm.daily_remit_date IS NOT NULL AND tdm.monthly_remit_date IS NULL ';

       v_start_date:= CASE WHEN str_tab(5) <=0 THEN NULL ELSE to_date('01/'||str_tab(4)||'/'||str_tab(5),'dd/mm/yyyy') END;
       v_end_date  := last_day(v_start_date);
       v_sql_str:=v_sql_str||'AND tdm.generated_date BETWEEN :v_start_date AND :v_end_date ';
       i := i+1;
       bind_tab(i) :=   v_start_date;
       i := i+1;
       bind_tab(i) := v_end_date;

    END IF;

    IF v_ins_comp_id IS NOT NULL THEN

      v_sql_str:=v_sql_str||'AND tdm.Ins_Comp_Id=:v_ins_comp_id ';
      i := i+1;
      bind_tab(i) := v_ins_comp_id;

    END IF;
--    INSERT INTO a11 VALUES(v_sql_str); COMMIT;
--    dbms_output.put_line(v_sql_str);

   -- OPEN v_result_set FOR v_sql_str USING v_ins_comp_id, v_start_date,v_end_date;--,v_start_num, v_end_num ;
   CASE bind_tab.COUNT
         WHEN 0 THEN OPEN v_result_set FOR v_sql_str;-- USING bind_tab(1);
         WHEN 1 THEN OPEN v_result_set FOR v_sql_str USING bind_tab(1);
         WHEN 2 THEN OPEN v_result_set FOR v_sql_str USING bind_tab(1),bind_tab(2);
         WHEN 3 THEN OPEN v_result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3);
    END CASE;

  END monthly_remit_sumary_report;
--=====================================================================================
  PROCEDURE annexure_i26q_report(
  v_search_str             IN VARCHAR2,
  v_result_set             OUT SYS_REFCURSOR
  )
  IS
        str_tab ttk_util_pkg.str_table_type:= ttk_util_pkg.parse_str(v_search_str);
  --        TYPE bind_tab_type IS TABLE OF VARCHAR2(250) INDEX BY BINARY_INTEGER ;
  --        bind_tab    bind_tab_type;
  --        i           NUMBER(2) := 0;
        v_sql_str   VARCHAR2(4000);
        v_financial_year tpa_tds_acknowledgements.financial_start_year%TYPE:=str_tab(2);
        v_quarter tpa_tds_acknowledgements.quarter_general_type_id%TYPE:=str_tab(3);

  BEGIN
     v_sql_str :='SELECT   tds.challan_ref_number AS challan_serial_no,
                      NULL AS deductee_updation_mode,--Blank
                      tds.bsr_code AS branch_bsr_code,
                      to_char(tds.challan_date,''DD/MM/YYYY'') AS tax_deposited_date,
                      tds.challan_transfer_vou_number AS transf_vouch_challan_serail_no,
                      ''194J'' AS payment_made,
                      tds.tds_amt AS total_tds_deducted_deductees,
                      NULL AS int_rs,
                      NULL AS others_rs,
                      tds.tds_amt AS total,
                      NULL AS sr_no,
                      NULL AS last_pan_of_employee,
                      hi.pan_number AS pan_of_deductee,
                      hi.hosp_name AS name_of_deductee,
                      to_char(tds.cheque_date,''DD/MM/YYYY'') AS date_of_payment,
                      tds.claim_app_amt AS amt_paid,
                      tds.base_tax AS tds_rs,
                      tds.surcharge AS surcharge_rs,
                      tds.edu_cess AS edu_cess_rs,
                      nvl(tds.base_tax,0)+nvl(tds.surcharge,0)+ nvl(tds.edu_cess,0) AS total_tax_deducted,
                      NULL AS last_total_tax_deducted,--Blank
                      tds.tds_amt AS total_tax_deposited_rs,
                      NULL AS last_total_tax_deposited,--Blank
                      to_char(tds.cheque_date,''DD/MM/YYYY'') AS date_of_deduction,
                      CASE WHEN SUBSTR(hi.tds_subcat_type_id,1,2)=''RE'' THEN  ''''
                           WHEN SUBSTR(hi.tds_subcat_type_id,1,2)=''TE'' THEN  ''A''
                           WHEN SUBSTR(hi.tds_subcat_type_id,1,2)=''PE'' THEN  ''B'' END
                      AS reason_for_non_deduction,
                      CASE WHEN hi.hosp_owner_general_type_id=''HCOM'' THEN ''1'' ELSE ''2'' END AS deductee_code,
                      /*CASE WHEN nvl(tdS.base_tax_perc,0)!=0 AND nvl(tds.surcharge_perc,0)=0 AND nvl(tds.edu_cess_perc,0)=0 THEN (nvl(tds.base_tax_perc,0))
                           WHEN nvl(tds.base_tax_perc,0)!=0 AND nvl(tds.surcharge_perc,0)!=0 AND nvl(tds.edu_cess_perc,0)=0 THEN (nvl(tds.base_tax_perc,0)) + (nvl(tds.base_tax_perc,0) * nvl(tds.surcharge_perc,0)/100)
                           WHEN nvl(tds.base_tax_perc,0)!=0 AND nvl(tds.surcharge_perc,0)!=0 AND nvl(tds.edu_cess_perc,0)!=0 THEN (nvl(tds.base_tax_perc,0)) + (nvl(tds.base_tax_perc,0) * nvl(tds.surcharge_perc,0)/100)+ ((nvl(tds.base_tax_perc,0)+(nvl(tds.base_tax_perc,0)/nvl(tds.surcharge_perc,0)))*nvl(tds.edu_cess_perc,0)/100)
                       ELSE NULL END
                       AS rate_at_tax_deducted,*/
                       tds.base_tax_perc + nvl(tds.edu_cess_perc,0)  + nvl(tds.surcharge_perc,0) + nvl(tds.ms1_perc,0) + nvl(tds.ms2_perc,0) AS rate_at_tax_deducted,
                      ''No'' AS paid_by_book_entry
  FROM tpa_tds_report_master tds  JOIN tpa_hosp_info hi ON (tds.hosp_code=hi.empanel_number)
       LEFT OUTER JOIN tpa_tds_acknowledgements ta ON (ta.tpa_tds_acknowledge_seq_id =tds.tpa_tds_acknowledge_seq_id )
       WHERE ta.financial_start_year=:v_financial_year
       AND ta.quarter_general_type_id=:v_quarter';
--       LEFT OUTER JOIN tpa_general_code gc ON (gc.general_type_id=ta.quarter_general_type_id)

  OPEN v_result_set FOR v_sql_str USING v_financial_year,v_quarter;

  END annexure_i26q_report;
--=====================================================================================
  PROCEDURE challan_details_q_report(
   v_search_str             IN VARCHAR2,
   v_result_set             OUT SYS_REFCURSOR
  )
  IS
    str_tab ttk_util_pkg.str_table_type:= ttk_util_pkg.parse_str(v_search_str);
    v_financial_year tpa_tds_acknowledgements.financial_start_year%TYPE:=str_tab(2);--CASE WHEN str_tab(2)=0 THEN NULL ELSE str_tab(2) END;
    v_quarter tpa_tds_acknowledgements.quarter_general_type_id%TYPE:=str_tab(3);
    v_sql_str   VARCHAR2(4000);
    v_start_mon NUMBER;
    v_end_mon NUMBER;
    v_start_date DATE;
    v_end_date DATE;
    TYPE dig_tab_type       IS TABLE OF NUMBER;
    month_tab dig_tab_type:=dig_tab_type(1,2,3,4,5,6,7,8,9,10,11,12);
    --||2009|QTR4|
  BEGIN


   IF v_quarter='QTR4' THEN
        v_start_mon:=month_tab(1);
        v_end_mon:=month_tab(3);
   ELSIF v_quarter='QTR3' THEN
        v_start_mon:=month_tab(10);
        v_end_mon:=month_tab(12);
   ELSIF v_quarter='QTR2' THEN
        v_start_mon:=month_tab(7);
        v_end_mon:=month_tab(9);
   ELSIF v_quarter='QTR1' THEN
        v_start_mon:=month_tab(4);
        v_end_mon:=month_tab(6);
   END IF;
--   v_from_date                DATE := to_date('01/'||v_month||'/'||v_year,'dd/mm/yyyy');
      v_start_date:=CASE WHEN v_financial_year =0 THEN NULL ELSE to_date('01/'||v_start_mon||'/'||v_financial_year,'dd/mm/yyyy') END;
--      dbms_output.put_line(to_char(v_start_date,'dd/mm/yyyy'));
      --v_end_date:= to_date(last_day(to_date('01/'||v_end_mon||'/'||v_financial_year,'dd/mm/yyyy'))||'/'||v_end_mon||'/'||v_financial_year,'dd/mm/yyyy');
            v_end_date:=CASE WHEN v_financial_year =0 THEN NULL ELSE last_day(to_date('01/'||v_end_mon||'/'||v_financial_year,'dd/mm/yyyy')) END;
    v_sql_str :='SELECT
                    ROWNUM AS sl_no,
                    NULL AS updation_mode_for_challan,
                    ''194J'' AS section_code,
                    tds.base_tax AS tds_rs,
                    tds.surcharge AS surcharge_rs,
                    tds.edu_cess AS edu_cess_rs,
                    NULL AS int_rs,
                    NULL AS others_rs,
                    NULL AS last_total_tax_deposited_rs,
                    nvl(tds.base_tax,0)+nvl(tds.surcharge,0)+nvl(tds.edu_cess,0) AS total_tax_deposited,--(403+404+405+406+407),
                    tds.challan_ref_number AS cheque_no,
                    NULL AS last_bsr_code,
                    tds.bsr_code AS bsr_code,
                    NULL AS last_tax_deposited_date,
                    to_char(tds.challan_date,''DD/MM/YYYY'') AS tax_deposited_date,
                    NULL AS last_tranfer_voucher_serial_no,
                    tds.challan_transfer_vou_number as transfer_voucher_serial_no,
                    ''No'' AS tds_book_entry_deposited,
                    NULL AS int_rs,
                    NULL AS others_rs
                 FROM tpa_tds_report_master tds
                 WHERE tds.month_of_remit BETWEEN :v_start_date AND :v_end_date';
   OPEN v_result_set FOR v_sql_str USING v_start_date,v_end_date;
  END challan_details_q_report;
--=====================================================================================
  /* --==============================================================================================
  Name       : print_cheque_info
  Created on : -27-APR-10
  Created By : - Ramakrishna K M
  Company    : SPAN INFOTECH INDIA Pvt.Ltd.
  Comments   : This can used to print the cheque in case if cheque pdf is not generated or blank
 --============================================================================================== */
  PROCEDURE print_cheque_info(
    v_batch_number       IN  tpa_claims_check.batch_number%TYPE,
    v_resultset          OUT SYS_REFCURSOR
  )
  IS

  BEGIN
    OPEN v_resultset FOR
        SELECT ttk_util_pkg.fn_decrypt(a.payee_name) payee_name, --Modified for koc11ed
          --SUM(a.approved_amount) approved_amount,
          SUM(nvl(f.check_amount,a.approved_amount)) approved_amount,
          c.check_num,
          SUBSTR(ttk_util_pkg.num_to_words(SUM(nvl(f.check_amount,a.approved_amount))),9) as amt_desc,
          --SYSDATE,
          to_char(c.check_date,'DD/MM/YYYY') AS check_date,
          e.account_number
          FROM tpa_claims_payment A  JOIN tpa_payment_checks_details b  ON(a.payment_seq_id = b.payment_seq_id)
          JOIN tpa_claims_check  C  ON (b.claims_chk_seq_id = c.claims_chk_seq_id)
          JOIN tpa_float_account D  ON (D.float_seq_id = a.float_seq_id)
          JOIN fin_app.tpa_bank_accounts E  ON (d.bank_acc_seq_id = e.bank_acc_seq_id)
          LEFT OUTER JOIN tpa_clm_tds_details f ON (a.payment_seq_id = f.payment_seq_id)
          WHERE c.check_status = 'CSI'
          AND c.batch_number   = v_batch_number
          GROUP BY c.check_num, ttk_util_pkg.fn_decrypt(a.payee_name), e.account_number,c.check_date ORDER BY c.check_num;
  END print_cheque_info;
/*==============================================================================================
    Name       : send_mediclaim_computation
    Created on :
    Created By : Ibrahim Sayyed
    Company    : RCS Technologies
    Added for  : KOC1105
    Comments   : This procedure is used to send  claim computation
  ============================================================================================== */
PROCEDURE send_mediclaim_computation(v_where_clause VARCHAR2,v_added_by number)--KOC1105
  IS
 STR_TAB     ttk_util_pkg.str_table_type;
 v_DEST_MSG_SEQ_ID number(10);
 v_ins_name                        tpa_ins_info.ins_comp_name%type;---koc_ins_mail
 v_notify_tipe_id                  tpa_ins_info.notify_type_id%type;---koc_ins_mail
 v_msg_str                         VARCHAR2(1000);---koc_ins_mail
 v_clm_type                        varchar2(5);---koc_ins_mail
BEGIN
  STR_TAB:=ttk_util_pkg.parse_str(v_where_clause);
  FOR i IN str_tab.first..str_tab.last
    LOOP
  ---koc_ins_mail
      select ii.ins_comp_name,ii.notify_type_id,cad.clm_status_type_id into v_ins_name,v_notify_tipe_id,v_clm_type from
      clm_authorization_details cad 
      join tpa_ins_info ii on(ii.ins_seq_id=cad.ins_seq_id)
      join tpa_claims_payment cp on(cp.claim_seq_id=cad.claim_seq_id)
      where cp.payment_seq_id=str_tab(i);
      IF v_ins_name LIKE 'CIGNA%' AND v_notify_tipe_id ='NIC' AND v_clm_type ='CTM' THEN
        NULL;
      ELSE---koc_ins_mail
      INTX.generate_mail_pkg.proc_generate_message('FINANCE_MEDICLAIM_COMPUTATION',str_tab(i),v_added_by,v_dest_msg_seq_id);
     END IF; ---koc_ins_mail
  END LOOP;
END send_mediclaim_computation;
/*==============================================================================================
    Name       : debit_note_for_ibm_daksh
    Created on : 22-05-2012
    Created By : Ibrahim Sayyed
    Company    : RCS Technologies
    Added for  : KOC1163
    Comments   : This procedure is used to generate the dbit note accotding to float number,debit number
  ============================================================================================== */
  PROCEDURE debit_note_for_ibm_daksh (where_clause IN VARCHAR2,
  v_mr_dn_format           OUT SYS_REFCURSOR)

  IS
  parameter_tab     Ttk_Util_Pkg.str_table_type;

  BEGIN
    Parameter_tab := ttk_util_pkg.parse_str(where_clause);
      OPEN V_MR_DN_FORMAT FOR
     WITH BILL_DETAIL_VIEW AS (
          SELECT a.claim_seq_id,
                 trunc(a.date_of_admission) AS date_of_admission,
                 trunc(a.date_of_discharge) AS date_of_discharge,
                 d.payment_seq_id,
                 d.float_seq_id ,
                 NULL AS ot_allowed_amt,
                 SUM(C.allowed_amount) bill_allowed_amount,
                 SUM(C.rejected_amount) bill_rejected_amount,
                 SUM (CASE WHEN  C.WARD_TYPE_ID='ROO' THEN C.ALLOWED_AMOUNT ELSE 0 END) nicu_allowed_amt,
                 SUM (CASE WHEN  c.ward_type_id IN ('ICU','ICC','ICN','ICR') THEN C.ALLOWED_AMOUNT ELSE 0 END) icu_allowed_amt,
                 SUM (CASE WHEN  c.ward_type_id IN ('CON','HVC') THEN C.ALLOWED_AMOUNT ELSE 0 END) consult_allowed_amt,--?
                 SUM (CASE WHEN  c.ward_type_id ='SUF' THEN C.ALLOWED_AMOUNT ELSE 0 END) surg_allowed_amt,
                 SUM (CASE WHEN  c.ward_type_id IN ('MED','PHA') THEN C.ALLOWED_AMOUNT ELSE 0 END) medicine_allowed_amt,
                 SUM (CASE WHEN  c.ward_type_id IN ('LAI','RAI') THEN C.ALLOWED_AMOUNT ELSE 0 END) investigat_allowed_amt,
                 SUM (CASE WHEN  c.ward_type_id ='MIS' THEN C.ALLOWED_AMOUNT ELSE 0 END) misc_allowed_amt,
                 SUM (CASE WHEN  c.ward_type_id IN ('REF','SEC') THEN C.ALLOWED_AMOUNT ELSE 0 END) reg_sec_allowed_amt,
                 SUM (CASE WHEN  c.ward_type_id ='DAW' THEN c.allowed_amount ELSE 0 END) daily_allowed_amt,
                 SUM (CASE WHEN  c.ward_type_id ='AMF' THEN c.allowed_amount ELSE 0 END) ambulance_allowed_amt,
                 SUM (CASE WHEN  c.ward_type_id IN ('ANE','OTC','SGA') THEN c.allowed_amount ELSE 0 END) anast_ot_charges,
                 SUM (CASE WHEN  c.ward_type_id ='STX' THEN c.allowed_amount ELSE 0 END) service_tax,
                 SUM (CASE WHEN  c.ward_type_id ='PKG' THEN c.allowed_amount ELSE 0 END) PKG_CHARGES,
                 MIN(a.date_of_admission) AS hosp_date,
                 SUM(NVL(c.requested_amount,0)) requested_amount,
                 SUM(NVL(c.allowed_amount,0)) allowed_amount,
                 SUM (CASE WHEN WC.SERVICE_TAX_APPLICABLE_YN='N' THEN C.ALLOWED_AMOUNT ELSE 0 END) SER_TAX_NON_APP_AMOUNT,
                 (SELECT MAX(PT.EVENT_EXEC_DATE) FROM PAT_EVENT_HISTORY PT WHERE PT.CLAIM_SEQ_ID=A.CLAIM_SEQ_ID /*AND PT.EVENT_SEQ_ID=20*/) CLAIM_COMPLETION_DATE
          FROM clm_general_details a
               INNER JOIN clm_bill_header B ON (a.claim_seq_id = b.claim_seq_id )
               INNER JOIN clm_bill_details C ON (B.clm_bill_seq_id = C.clm_bill_seq_id)
               INNER JOIN tpa_claims_payment D ON (B.claim_seq_id = D.claim_seq_id)
               INNER JOIN fin_app.tpa_debit_note_claims_assoc dca ON (d.claim_seq_id = dca.claim_seq_id)
               LEFT OUTER JOIN TPA_HOSP_WARD_CODE WC ON (WC.WARD_TYPE_ID=C.WARD_TYPE_ID)
          WHERE D.float_seq_id =Parameter_tab(2)
               AND dca.debit_seq_id=Parameter_tab(1)
               AND d.claim_payment_status ='DEBIT_NOTE_ATTACHED'
          GROUP BY a.claim_seq_id, d.payment_seq_id, d.float_seq_id ,A.DATE_OF_ADMISSION,A.DATE_OF_DISCHARGE),
ADDRESS_VIEW AS (SELECT GG.CLAIM_SEQ_ID,
                        MA.OFF_PHONE_NO_1,
                        ttk_util_pkg.fn_decrypt(MA.MOBILE_NO) MOBILE_NO, --Modified for koc11ed
                        ttk_util_pkg.fn_decrypt(MA.EMAIL_ID) EMAIL_ID, --Modified for koc11ed
                        GA.ADDRESS_1 ADDRESS_LINE1,
                        GA.ADDRESS_2 ADDRESS_LINE2,
                        GA.ADDRESS_3 ADDRESS_LINE3,
                        NVL(C.CITY_DESCRIPTION,GA.CITY_TYPE_ID) CITY,
                        s.state_name STSTE,
                        GA.PIN_CODE PIN_CODE,
                        (GA.ADDRESS_1||CHR(44)||GA.ADDRESS_2||CHR(44)||GA.ADDRESS_3||CHR(44)||NVL(C.CITY_DESCRIPTION,GA.CITY_TYPE_ID)||CHR(44)||s.state_name||CHR(44)||GA.PIN_CODE) HOSP_FULL_ADDRESS,
                        HI.EMPANEL_NUMBER PROVIDER_CODE,
                        NVL(HI.HOSP_NAME,CLH.HOSP_NAME) PROVIDER_NAME,
                        /* NVL(HD.ADDRESS_1,CLH.ADDRESS_1) PROVIDER_ADDRESS,*/
                        NVL(HD.ADDRESS_1||HD.ADDRESS_2||HD.ADDRESS_3,CLH.ADDRESS_1||CLH.ADDRESS_2||CLH.ADDRESS_3) PROVIDER_ADDRESS,--KOC1343--Changed by Manjunath.B.M. to capture complete hospital address
                        NVL(CT.CITY_DESCRIPTION,CLH.CITY_NAME) PROVIDER_CITY,
                        NVL(STD.STATE_NAME,CLH.STATE_NAME) PROVIDER_STATE,
                        NVL(HD.PIN_CODE,CLH.PIN_CODE) PROVIDER_PIN_CODE,
                        NVL(HI.OFF_PHONE_NO_1,CLH.OFF_PHONE_NO_1) PROVIDER_TEL_NO,
                        HI.SERV_TAX_RGN_NUMBER,
                        TO_CHAR(CI.INTIMATION_GENERATED_DATE,'DD-MON-RRRR')INTIMATION_GENERATED_DATE,
                        TO_CHAR(CI.INTIMATION_GENERATED_DATE,'MON-RRRR') INTIMATION_MONTH,
                        CST.DESCRIPTION CLAIM_SUB_TYPE,
                        AU.REMARKS
                FROM TPA_CLAIMS_PAYMENT CP
                    INNER JOIN CLM_GENERAL_DETAILS GG ON (GG.CLAIM_SEQ_ID=CP.CLAIM_SEQ_ID)
                    INNER JOIN CLM_ENROLL_DETAILS E ON (E.CLAIM_SEQ_ID=CP.CLAIM_SEQ_ID)
                    INNER JOIN TPA_ENR_POLICY_MEMBER M ON (M.MEMBER_SEQ_ID=E.MEMBER_SEQ_ID)
                    INNER JOIN TPA_ENR_POLICY_GROUP G ON (G.POLICY_GROUP_SEQ_ID=M.POLICY_GROUP_SEQ_ID)
                    INNER JOIN fin_app.tpa_debit_note_claims_assoc dca ON (cp.claim_seq_id = dca.claim_seq_id)
                    LEFT OUTER JOIN TPA_ENR_MEM_ADDRESS MA ON (MA.ENR_ADDRESS_SEQ_ID=M.ENR_ADDRESS_SEQ_ID )
                    LEFT OUTER JOIN TPA_ENR_MEM_ADDRESS GA ON (GA.ENR_ADDRESS_SEQ_ID=G.ENR_ADDRESS_SEQ_ID)
                    LEFT OUTER JOIN TPA_STATE_CODE S ON (S.STATE_TYPE_ID=GA.STATE_TYPE_ID)
                    LEFT OUTER JOIN TPA_CITY_CODE C ON (C.CITY_TYPE_ID=GA.CITY_TYPE_ID)
                    LEFT OUTER JOIN CLM_HOSPITAL_ASSOCIATION CLH ON (CLH.CLAIM_SEQ_ID=CP.CLAIM_SEQ_ID)
                    LEFT OUTER JOIN TPA_HOSP_INFO HI ON (HI.HOSP_SEQ_ID=CP.HOSP_SEQ_ID OR CLH.HOSP_SEQ_ID=HI.HOSP_SEQ_ID)
                    LEFT OUTER JOIN TPA_HOSP_ADDRESS HD ON (HD.HOSP_SEQ_ID=HI.HOSP_SEQ_ID)
                    LEFT OUTER JOIN TPA_STATE_CODE STD ON (STD.STATE_TYPE_ID=HD.STATE_TYPE_ID)
                    LEFT OUTER JOIN TPA_CITY_CODE CT ON (CT.CITY_TYPE_ID=HD.CITY_TYPE_ID)
                    LEFT OUTER JOIN TPA_GENERAL_CODE CST ON (CST.GENERAL_TYPE_ID=GG.CLAIM_SUB_GENERAL_TYPE_ID)
                    LEFT OUTER JOIN TPA_CALL_LOG L ON (L.CALL_LOG_SEQ_ID=GG.CALL_LOG_SEQ_ID)
                    LEFT OUTER JOIN TPA_CALL_CLAIM_INTIMATION CI ON (CI.CALL_LOG_SEQ_ID=L.CALL_LOG_SEQ_ID)
                    LEFT OUTER JOIN ASSIGN_USERS AU ON (AU.CLAIM_SEQ_ID=GG.CLAIM_SEQ_ID AND AU.ASSIGN_USERS_SEQ_ID=GG.LAST_ASSIGN_USER_SEQ_ID)
                WHERE CP.FLOAT_SEQ_ID =Parameter_tab(2)
                    AND dca.debit_seq_id=Parameter_tab(1)
                    AND claim_payment_status ='DEBIT_NOTE_ATTACHED'  ),
BILL_NUMBER_DATE_VIEW AS (SELECT p.CLAIM_SEQ_ID,
                                 ltrim(rtrim (xmlagg (xmlelement (e,H.BILL_NO ||',')).extract ('//text()'), ','), ',') HOSPITAL_BILL_NUMBER,
                                 ltrim(rtrim (xmlagg (xmlelement (e,TO_CHAR(H.BILL_DATE,'DD-MON-RRRR')||',')).extract ('//text()'), ','), ',') BILL_DATE
                           FROM TPA_CLAIMS_PAYMENT P
                                INNER JOIN fin_app.tpa_debit_note_claims_assoc dca ON (p.claim_seq_id = dca.claim_seq_id)
                                LEFT OUTER JOIN CLM_BILL_HEADER H ON (H.Claim_Seq_Id=P.Claim_Seq_Id)
                        WHERE P.FLOAT_SEQ_ID =Parameter_tab(2)
                    AND dca.debit_seq_id=Parameter_tab(1)
                    AND claim_payment_status ='DEBIT_NOTE_ATTACHED' GROUP BY P.CLAIM_SEQ_ID),

PROCEDURE_CODE_VIEW AS  (SELECT p.CLAIM_SEQ_ID,
                                ltrim(rtrim (xmlagg (xmlelement (e,HC.PROC_DESCRIPTION||',')).extract ('//text()'), ','), ',') PROC_DESC,
                                ltrim(rtrim (xmlagg (xmlelement (e,HC.PROC_CODE||',')).extract ('//text()'), ','), ',') PROCEDURE_CODE_PRIM
                         FROM TPA_CLAIMS_PAYMENT P
                               INNER JOIN fin_app.tpa_debit_note_claims_assoc dca ON (p.claim_seq_id = dca.claim_seq_id)
                               LEFT OUTER JOIN ICD_PCS_DETAIL ID ON (ID.CLAIM_SEQ_ID=p.CLAIM_SEQ_ID)
                               LEFT OUTER JOIN PAT_PACKAGE_PROCEDURES PK ON (PK.ICD_PCS_SEQ_ID=ID.ICD_PCS_SEQ_ID)
                               LEFT OUTER JOIN TPA_HOSP_PROCEDURE_CODE HC ON (HC.PROC_SEQ_ID=PK.PROC_SEQ_ID)
                         WHERE P.FLOAT_SEQ_ID =Parameter_tab(2)
                                AND dca.debit_seq_id=Parameter_tab(1)
                                AND P.CLAIM_PAYMENT_STATUS ='DEBIT_NOTE_ATTACHED'
                         GROUP BY P.CLAIM_SEQ_ID),
ICD_CODE_VIEW AS         (SELECT p.CLAIM_SEQ_ID,
                                 LTRIM(RTRIM (xmlagg (xmlelement (e,ID.ICD_CODE||',')).extract ('//text()'), ','), ',') ICD_CODE_PRIMARY
                          FROM TPA_CLAIMS_PAYMENT P
                               INNER JOIN fin_app.tpa_debit_note_claims_assoc dca ON (p.claim_seq_id = dca.claim_seq_id)
                               LEFT OUTER JOIN ICD_PCS_DETAIL ID ON (ID.CLAIM_SEQ_ID=p.CLAIM_SEQ_ID)
                          WHERE P.FLOAT_SEQ_ID =Parameter_tab(2)
                                AND dca.debit_seq_id=Parameter_tab(1)
                                AND P.CLAIM_PAYMENT_STATUS ='DEBIT_NOTE_ATTACHED'
                          GROUP BY P.CLAIM_SEQ_ID),
PED_DESC_VIEW  AS         (SELECT CP.CLAIM_SEQ_ID,
                                  LTRIM(RTRIM (xmlagg (xmlelement (e,P.PED_DESCRIPTION||',')).extract ('//text()'), ','), ',') PRE_EXIST_ILL_DESCRIPTION
                          FROM TPA_CLAIMS_PAYMENT CP
                               INNER JOIN fin_app.tpa_debit_note_claims_assoc dca ON (cp.claim_seq_id = dca.claim_seq_id)
                               LEFT OUTER JOIN CLM_ENROLL_DETAILS E ON (e.claim_seq_id=CP.CLAIM_SEQ_ID)
                               LEFT OUTER JOIN TPA_ENR_MEM_PED PD ON (PD.MEMBER_SEQ_ID=E.MEMBER_SEQ_ID AND PD.DELETED_YN='N')
                               LEFT OUTER JOIN TPA_PED_CODE P ON (p.ped_code_id=PD.PED_CODE_ID AND P.ICD_CODE!='UNK')
                          WHERE CP.FLOAT_SEQ_ID =Parameter_tab(2)
                            AND dca.debit_seq_id=Parameter_tab(1)
                            AND cp.CLAIM_PAYMENT_STATUS ='DEBIT_NOTE_ATTACHED'
                          GROUP BY cP.CLAIM_SEQ_ID)
SELECT
          CP.PAYMENT_SEQ_ID,
          CG.CLAIM_SEQ_ID,
          CG.CLAIM_NUMBER,
          CP.CLAIM_SETTLEMENT_NO,
          CE.CLM_ENROLL_DETAIL_SEQ_ID,
          P.POLICY_SEQ_ID,
          M.MEMBER_SEQ_ID,
          G.POLICY_GROUP_SEQ_ID,
          CI.CLAIM_GENERAL_TYPE_ID,
          'TTK HEALTH CARE TPA PVT LTD' AS TPA_Name,
          '016'  TPA_CODE,
          '009' PRINT_LOCATION,
          ce.tpa_enrollment_id AS TPA_UHID,
          AV.PROVIDER_NAME HOSP_NAME,
          P.Policy_Number POLICY_NUMBER,
          AV.SERV_TAX_RGN_NUMBER SERV_TAX_REGN_NUMBER,
         (CASE WHEN CI.CLAIM_GENERAL_TYPE_ID='CTM' THEN NULL ELSE TO_CHAR(CI.RCVD_DATE,'DD-MON-RRRR') END ) INVOICE_DATE,
         TO_CHAR(CI.RCVD_DATE,'DD-MON-RRRR') DATE_OF_FILE_RECEIVED,
          (CASE ce.enrol_type_id WHEN 'IND' THEN 'Individual' ELSE 'Group' END) TYPE_OF_POLICY,
          NVL2(p.renewal_policy_number,'Renewal','Fresh')  NEW_RENEWAL_TRANSFER_POLICY,
          (CASE WHEN CE.ENROL_TYPE_ID='IND' THEN
                     G.INSURED_NAME
                ELSE
                     GR.GROUP_NAME END) GROUPNAME_PROPOSERNAME,
          (CASE WHEN  CI.CLAIM_GENERAL_TYPE_ID='CTM' THEN 'M' ELSE 'P' END) AS CLAIM_TYPE,
          TO_CHAR(p.effective_from_date,'DD-MON-RRRR')  POLICY_START_DATE,
          TO_CHAR(p.effective_to_date,'DD-MON-RRRR')  POLICY_END_DATE,
          TO_CHAR(g.date_of_joining,'DD-MON-RRRR')  DATE_OF_JOINING,
          ce.claimant_name BENEFICIARY_NAME,
          ce.tpa_enrollment_id  MEMBERSHIP_NO,
          REL.relship_description  RELATIONSHIP,
          (CASE m.gender_general_type_id
               WHEN 'MAL' THEN 'Male'
               WHEN 'FEM' THEN 'Female'
               WHEN 'EUN' THEN 'Eunuch'
               WHEN 'OTH' THEN 'Others'
            END)  GENDER,
          AV.OFF_PHONE_NO_1  LANDLINE_NUMBER,
          AV.MOBILE_NO  MOBILE_NUMBER,
           CASE  CI.CLAIM_GENERAL_TYPE_ID WHEN 'CTM' THEN ttk_util_pkg.fn_decrypt(MA.EMAIL_ID)  ELSE  AV.EMAIL_ID END AS EMAIL_ADDRESS, --koc 1216
         --AV.EMAIL_ID EMAIL_ADDRESS,
          (CASE p.policy_sub_general_type_id
               WHEN 'PFL' THEN g.floater_sum_insured
                    ELSE m.mem_tot_sum_insured
             END) SUM_INSURED,
          (CASE WHEN p.policy_sub_general_type_id='PFL' THEN
                             (SELECT (T.SUM_INSURED+T.BONUS-T.UTILISED_SUM_INSURED-T.UTILISED_CUM_BONUS)
                             FROM TPA_ENR_BALANCE T
                             WHERE T.POLICY_SEQ_ID=P.POLICY_SEQ_ID
                             AND T.POLICY_GROUP_SEQ_ID=G.POLICY_GROUP_SEQ_ID)
                WHEN p.policy_sub_general_type_id='PNF' THEN
                            (SELECT (T.SUM_INSURED+T.BONUS-T.UTILISED_SUM_INSURED-T.UTILISED_CUM_BONUS)
                             FROM TPA_ENR_BALANCE T
                             WHERE T.POLICY_SEQ_ID=P.POLICY_SEQ_ID
                             AND T.MEMBER_SEQ_ID=M.MEMBER_SEQ_ID)
           END) BAL_SUM_INS,--TV.BAL_SUM_INSURED BAL_SUM_INS,
          (CASE WHEN CI.CLAIM_GENERAL_TYPE_ID='CTM' THEN GC.DESCRIPTION ELSE NULL END) TYPE_OF_CLAIM_IPD_OPD,
           AV.PROVIDER_CODE,
           (CASE WHEN CI.CLAIM_GENERAL_TYPE_ID='CTM' THEN AV.PROVIDER_NAME ELSE AV.PROVIDER_CODE END) PROVIDER_ID ,
           AV.PROVIDER_NAME PROVIDER_NAME,
                     (CASE WHEN (GR.GROUP_ID='I0475' AND CI.CLAIM_GENERAL_TYPE_ID='CTM')
           THEN 'IBM DAKSH'
           when (GR.GROUP_ID='I310' AND CI.CLAIM_GENERAL_TYPE_ID='CTM')
           THEN 'IBM, Bangalore'
            when (GR.GROUP_ID='N0327' AND CI.CLAIM_GENERAL_TYPE_ID='CTM')
            THEN 'NET SOL'
            ELSE nvl(AV.PROVIDER_ADDRESS,AV.ADDRESS_LINE1) END) PROVIDER_ADDRESS, --koc 1216
           /*(CASE WHEN (GR.GROUP_ID='I0475' and  CI.CLAIM_GENERAL_TYPE_ID='CTM') THEN 'IBM DAKSH' ELSE  nvl(AV.PROVIDER_ADDRESS,AV.ADDRESS_LINE1) END) PROVIDER_ADDRESS, --koc 1216*/
       -- (CASE WHEN CI.CLAIM_GENERAL_TYPE_ID='CTM' THEN 'IBM DAKSH' ELSE AV.PROVIDER_ADDRESS END) PROVIDER_ADDRESS,
           (CASE WHEN CI.CLAIM_GENERAL_TYPE_ID='CTM' THEN NULL ELSE AV.PROVIDER_CITY END) PROVIDER_CITY,
           (CASE WHEN CI.CLAIM_GENERAL_TYPE_ID='CTM' THEN NULL ELSE AV.PROVIDER_STATE END) PROVIDER_STATE,
           AV.PROVIDER_PIN_CODE,
           AV.PROVIDER_TEL_NO,
           PE.AUTH_NUMBER AL_NUMBER,
           TO_CHAR(CG.DATE_OF_ADMISSION,'DD-MON-RRRR') DT_OF_ADMISSION,
           TO_CHAR(CG.DATE_OF_DISCHARGE,'DD-MON-RRRR') DT_OF_DISCHARGE,
           TRUNC(CG.DATE_OF_DISCHARGE-CG.DATE_OF_ADMISSION) LENGTH_OF_STAY,
           AL.AILMENT_DESCRIPTION AILMENT,
           AL.PROVISIONAL_DIAGNOSIS DIAGNOSIS,
           PCV.PROC_DESC,--MIS_V2_FIN_REPORTS_PKG.get_pcd(cg.claim_seq_id,'PCS') PROC_DESC,--CALLING PROCEDURE
           NVL(BT.REQUESTED_AMOUNT,CG.REQUESTED_AMOUNT) CLAIMED_AMOUNT,
           CG.TOTAL_APP_AMOUNT ASSESSED_CLAIM_AMT,
           (CASE WHEN CI.CLAIM_GENERAL_TYPE_ID='CTM' THEN NULL ELSE CG.DISCOUNT_AMOUNT END) NETWORK_DISCOUNT,
           (NVL(BT.REQUESTED_AMOUNT,CG.REQUESTED_AMOUNT)-CG.TOTAL_APP_AMOUNT-CG.DISCOUNT_AMOUNT) DISALLOWED_AMT,
           CG.REQUESTED_AMOUNT,
           CG.TOTAL_APP_AMOUNT RESERVE_AMT,
           BT.NICU_ALLOWED_AMT ACCOMMODATIONCHARGES_NICU,
           BT.ICU_ALLOWED_AMT ACCOMMODATION_CHARGES_ICU,
           BT.CONSULT_ALLOWED_AMT DOCTOR_CONSULTATION_CHARGES,
           BT.SURG_ALLOWED_AMT SURGERY_CHRGS,
           BT.MEDICINE_ALLOWED_AMT MEDICINE_CHRGS,
           BT.INVESTIGAT_ALLOWED_AMT INVESTIGATION_CHRGS,
           BT.MISC_ALLOWED_AMT MISCELLANEOUS_CHRGS,
           BT.REG_SEC_ALLOWED_AMT REG_SERVICE_CHARGES,
           BT.DAILY_ALLOWED_AMT DAILY_ALLOWANCE,
           BT.AMBULANCE_ALLOWED_AMT AMBULANCE_CHARGES,
           NVL(BT.BILL_ALLOWED_AMOUNT,0) + NVL(BT.BILL_REJECTED_AMOUNT,0) HOSPITAL_BILL_AMT,
           DN.DEBIT_NOTE_NUMBER DEBIT_NOTE_NO,
           TO_CHAR( DN.DEBIT_DATE,'DD-MON-RRRR') AS DEBIT_NOTE_DATE,
           NULL AS DATE_SEND_TO_USGIC_FOR_PAYMENT,--BLANK
           NULL AS FLOAT_ACCOUNT_NO,--BLANK
           (CASE WHEN (GR.GROUP_ID='I0475' and  CI.CLAIM_GENERAL_TYPE_ID='CTM') THEN 'IBM DAKSH BUSINESS PROCESS SERVICES PVT LTD' ELSE ttk_util_pkg.fn_decrypt(CP.PAYEE_NAME) END)  PAYEE, --koc 1216
         --  (CASE WHEN CI.CLAIM_GENERAL_TYPE_ID='CTM' THEN 'IBM DAKSH BUSINESS PROCESS SERVICES PVT LTD' ELSE CP.PAYEE_NAME END)  PAYEE,
           G.INSURED_NAME EMPLOYEE_NAME,
           AV.ADDRESS_LINE1 ADDRESS_LINE1,
           AV.ADDRESS_LINE2 ADDRESS_LINE2,
           AV.ADDRESS_LINE3 ADDRESS_LINE3,
           AV.CITY CITY,
           AV.STSTE STSTE,
           AV.PIN_CODE PIN_CODE,

            CASE WHEN CI.CLAIM_GENERAL_TYPE_ID='CTM' THEN ttk_util_pkg.fn_decrypt(bd.bank_name) ELSE
             ttk_util_pkg.fn_decrypt(CASE WHEN HA.ACCOUNT_NUMBER IS NULL OR HA.ACCOUNT_NUMBER='NA'  THEN NULL ELSE HA.BANK_NAME END) END AS BANK_NAME,--Modified for koc11ed ,koc 1216
           CASE WHEN CI.CLAIM_GENERAL_TYPE_ID='CTM' THEN ttk_util_pkg.fn_decrypt(bd.bank_branch) ELSE
             ttk_util_pkg.fn_decrypt(CASE WHEN HA.ACCOUNT_NUMBER IS NULL OR HA.ACCOUNT_NUMBER='NA'  THEN NULL ELSE HA.BRANCH_NAME END) END AS BRANCH_NAME, --Modified for koc11ed,koc 1216
           CASE WHEN CI.CLAIM_GENERAL_TYPE_ID='CTM' THEN  ttk_util_pkg.fn_decrypt(bd.bank_ifsc) ELSE
             ttk_util_pkg.fn_decrypt(CASE WHEN HA.ACCOUNT_NUMBER IS NULL OR HA.ACCOUNT_NUMBER='NA' THEN NULL ELSE HA.BANK_IFSC END) END AS BANK_BRANCH_CODE, --Modified for koc11ed,koc 1216
           CASE WHEN CI.CLAIM_GENERAL_TYPE_ID='CTM' THEN ttk_util_pkg.fn_decrypt(bd.bank_account_no) ELSE
             ttk_util_pkg.fn_decrypt(CASE WHEN HA.ACCOUNT_NUMBER IS NULL OR HA.ACCOUNT_NUMBER='NA' THEN NULL ELSE HA.ACCOUNT_NUMBER END)END AS BANK_ACCOUNT_NUMBER,--Modified for koc11ed,,koc 1216
           CASE WHEN CI.CLAIM_GENERAL_TYPE_ID='CTM' THEN null ELSE
             ttk_util_pkg.fn_decrypt(CASE WHEN HA.ACCOUNT_NUMBER IS NULL OR HA.ACCOUNT_NUMBER='NA'THEN NULL ELSE HA.ACCOUNT_TYPE END )END AS BANK_ACCOUNT_TYPE,  --Modified for koc11ed,koc 1216
           --CASE WHEN CI.CLAIM_GENERAL_TYPE_ID='CTM' THEN M.PAN_NUMBER ELSE  H.PAN_NUMBER END AS PAN_NUMBER, --Modified for koc11ed
             ttk_util_pkg.fn_decrypt(CASE WHEN CI.CLAIM_GENERAL_TYPE_ID='CTM' THEN MA.EMAIL_ID ELSE
             (CASE WHEN HA.ACCOUNT_NUMBER IS NULL OR HA.ACCOUNT_NUMBER='NA' THEN NULL ELSE H.PRIMARY_EMAIL_ID END ) END ) "HOSP_EMAIL_ID",--Modified for koc11ed,,koc 1216


          /* CASE WHEN CI.CLAIM_GENERAL_TYPE_ID='CTM' THEN bd.bank_name ELSE
             (CASE WHEN ttk_util_pkg.fn_decrypt(HA.ACCOUNT_NUMBER) IS NULL OR ttk_util_pkg.fn_decrypt(HA.ACCOUNT_NUMBER)='NA'  THEN NULL ELSE ttk_util_pkg.fn_decrypt(HA.BANK_NAME) END) END AS BANK_NAME,--Modified for koc11ed
           CASE WHEN CI.CLAIM_GENERAL_TYPE_ID='CTM' THEN bd.bank_branch ELSE
             (CASE WHEN ttk_util_pkg.fn_decrypt(HA.ACCOUNT_NUMBER) IS NULL OR ttk_util_pkg.fn_decrypt(HA.ACCOUNT_NUMBER)='NA'  THEN NULL ELSE ttk_util_pkg.fn_decrypt(HA.BRANCH_NAME) END) END AS BRANCH_NAME, --Modified for koc11ed
           CASE WHEN CI.CLAIM_GENERAL_TYPE_ID='CTM' THEN bd.bank_ifsc ELSE
             (CASE WHEN ttk_util_pkg.fn_decrypt(HA.ACCOUNT_NUMBER) IS NULL OR ttk_util_pkg.fn_decrypt(HA.ACCOUNT_NUMBER)='NA' THEN NULL ELSE ttk_util_pkg.fn_decrypt(HA.BANK_IFSC) END) END AS BANK_BRANCH_CODE, --Modified for koc11ed
           CASE WHEN CI.CLAIM_GENERAL_TYPE_ID='CTM' THEN bd.bank_account_no ELSE
             (CASE WHEN ttk_util_pkg.fn_decrypt(HA.ACCOUNT_NUMBER) IS NULL OR ttk_util_pkg.fn_decrypt(HA.ACCOUNT_NUMBER)='NA' THEN NULL ELSE ttk_util_pkg.fn_decrypt(HA.ACCOUNT_NUMBER) END)END AS BANK_ACCOUNT_NUMBER,--Modified for koc11ed
           CASE WHEN CI.CLAIM_GENERAL_TYPE_ID='CTM' THEN NULL ELSE
             (CASE WHEN ttk_util_pkg.fn_decrypt(HA.ACCOUNT_NUMBER) IS NULL OR ttk_util_pkg.fn_decrypt(HA.ACCOUNT_NUMBER)='NA'THEN NULL ELSE HA.ACCOUNT_TYPE END)END AS BANK_ACCOUNT_TYPE,  --Modified for koc11ed
           CASE WHEN CI.CLAIM_GENERAL_TYPE_ID='CTM' THEN NULL ELSE  H.PAN_NUMBER END AS PAN_NUMBER, --Modified for koc11ed
             (CASE WHEN CI.CLAIM_GENERAL_TYPE_ID='CTM' THEN MA.EMAIL_ID ELSE
             (CASE WHEN ttk_util_pkg.fn_decrypt(HA.ACCOUNT_NUMBER) IS NULL OR ttk_util_pkg.fn_decrypt(HA.ACCOUNT_NUMBER)='NA' THEN NULL ELSE ttk_util_pkg.fn_decrypt(H.PRIMARY_EMAIL_ID) END ) END ) HOSP_EMAIL_ID,--Modified for koc11ed */

            TO_CHAR(NVL(BT.CLAIM_COMPLETION_DATE,CE.DECISION_DATE),'DD-MON-RRRR') CLAIM_COMPLETION_DATE,
           'Pending for USGIC approval' CLM_STS_STG_USGIC,
           (CASE WHEN CE.CLM_STATUS_GENERAL_TYPE_ID='REJ' THEN RC.DESCRIPTION END) REASOF_FOR_REJECTION,
           (CASE WHEN CE.CLM_STATUS_GENERAL_TYPE_ID='REJ' THEN TO_CHAR(BT.CLAIM_COMPLETION_DATE,'DD-MON-RRRR') END) CLM_REJECTION_DATE,
           (CASE WHEN CE.CLM_STATUS_GENERAL_TYPE_ID='PCO' THEN TO_CHAR(BT.CLAIM_COMPLETION_DATE,'DD-MON-RRRR') END) CLM_CLOSED_DATE,
           NULL CHILD_CLAIM_NUM_USGIC,--Blank
           (CASE WHEN (CG.PARENT_CLAIM_SEQ_ID IS NOT NULL AND CG.RE_OPEN_TYPE IN ('CDD','RJC')) THEN TO_CHAR(CG.ADDED_DATE,'DD-MON-RRRR') END) CLM_REOPENED_DATE,--CHECK
           NULL SENTDATE_TO_USGIC,--blank
           TO_CHAR(P.EFFECTIVE_TO_DATE,'DD-MON-RRRR') POL_END_DATE,
           G.EMPLOYEE_NO EMPLOYEE_NUM,
           (CASE p.policy_sub_general_type_id
               WHEN 'PFL' THEN g.floater_sum_insured
                    ELSE m.mem_tot_sum_insured
             END) SUM_INSURED2,
           (CASE WHEN p.policy_sub_general_type_id='PFL' THEN
                             (SELECT (T.SUM_INSURED+T.BONUS-T.UTILISED_SUM_INSURED-T.UTILISED_CUM_BONUS)
                             FROM TPA_ENR_BALANCE T
                             WHERE T.POLICY_SEQ_ID=P.POLICY_SEQ_ID
                             AND T.POLICY_GROUP_SEQ_ID=G.POLICY_GROUP_SEQ_ID)
                WHEN p.policy_sub_general_type_id='PNF' THEN
                            (SELECT (T.SUM_INSURED+T.BONUS-T.UTILISED_SUM_INSURED-T.UTILISED_CUM_BONUS)
                             FROM TPA_ENR_BALANCE T
                             WHERE T.POLICY_SEQ_ID=P.POLICY_SEQ_ID
                             AND T.MEMBER_SEQ_ID=M.MEMBER_SEQ_ID)
             END) BAL_SUM_INSURED,--TV.BAL_SUM_INSURED,
           (CASE p.policy_sub_general_type_id
               WHEN 'PFL' THEN g.floater_sum_insured
                    ELSE m.mem_tot_sum_insured
             END) SUM_INSURED1,
           AV.HOSP_FULL_ADDRESS DTL_HOSP_ADDRESS,
           (CASE WHEN CI.CLAIM_GENERAL_TYPE_ID='CTM' THEN NULL ELSE BNV.Hospital_Bill_number END) Hospital_Bill_number ,
           (CASE WHEN CI.CLAIM_GENERAL_TYPE_ID='CTM' THEN NULL ELSE AV.PROVIDER_NAME END) NAME_AS_ON_PAN ,
           NULL AMHI_PROVIDER_ID,
           NULL TDS_AMT,
           NULL TDS_CAL_DT,
           NULL TDS_PAY_ID,
           NULL CREATED_BY,
           NULL CREATED_DATE,
           NULL UPDATED_BY,
           NULL UPDATED_DATE,
           NULL SERICE_TAX_CLAIMED_BY_TPA,
           NULL SERVICE_TAX_CLAIMED,
           NULL SERVICE_TAX_PAYABLE,
           NULL TDS_EXEMPT_STATUS,
           NULL PAYEMENT_STATUS,
           NULL STATUS,
           NULL CLAIM_EXT_NO


      FROM BILL_DETAIL_VIEW BT
      INNER JOIN TPA_CLAIMS_PAYMENT CP ON (CP.CLAIM_SEQ_ID=BT.CLAIM_SEQ_ID)
      INNER JOIN ADDRESS_VIEW AV ON (AV.CLAIM_SEQ_ID=CP.CLAIM_SEQ_ID)
      INNER JOIN BILL_NUMBER_DATE_VIEW BNV ON (BNV.CLAIM_SEQ_ID=CP.CLAIM_SEQ_ID)
      INNER JOIN PROCEDURE_CODE_VIEW PCV ON (PCV.CLAIM_SEQ_ID=CP.CLAIM_SEQ_ID)
      INNER JOIN ICD_CODE_VIEW ICV ON (ICV.CLAIM_SEQ_ID=CP.CLAIM_SEQ_ID)
      INNER JOIN PED_DESC_VIEW PEV ON (PEV.CLAIM_SEQ_ID=CP.CLAIM_SEQ_ID)
      INNER JOIN CLM_GENERAL_DETAILS CG ON (CG.CLAIM_SEQ_ID=CP.CLAIM_SEQ_ID)
      INNER JOIN CLM_ENROLL_DETAILS CE ON (CE.CLAIM_SEQ_ID=CP.CLAIM_SEQ_ID)
      INNER JOIN CLM_INWARD CI ON (CI.CLAIMS_INWARD_SEQ_ID=CG.CLAIMS_INWARD_SEQ_ID)
      INNER JOIN AILMENT_DETAILS AL ON (AL.CLAIM_SEQ_ID=CG.CLAIM_SEQ_ID)
      INNER JOIN TPA_ENR_POLICY P ON (CE.POLICY_SEQ_ID=P.POLICY_SEQ_ID)
      INNER JOIN TPA_ENR_POLICY_MEMBER M ON (CE.MEMBER_SEQ_ID = M.MEMBER_SEQ_ID AND M.Deleted_Yn='N')
      INNER JOIN TPA_ENR_POLICY_GROUP G ON (M.POLICY_GROUP_SEQ_ID = G.POLICY_GROUP_SEQ_ID AND G.Deleted_Yn='N')
      INNER JOIN fin_app.TPA_DEBIT_NOTE_CLAIMS_ASSOC DCA ON (cp.claim_seq_id = dca.claim_seq_id)
      INNER JOIN fin_app.TPA_DEBIT_NOTE DN ON (dn.debit_seq_id=dca.debit_seq_id)
      LEFT OUTER JOIN CLM_HOSPITAL_ASSOCIATION CA ON(CG.CLAIM_SEQ_ID=CA.CLAIM_SEQ_ID)
      LEFT OUTER JOIN TPA_HOSP_INFO H       ON(CA.HOSP_SEQ_ID=H.HOSP_SEQ_ID)
      LEFT OUTER JOIN TPA_HOSP_ACCOUNT_DETAILS HA ON(H.HOSP_SEQ_ID=HA.HOSP_SEQ_ID)
      LEFT OUTER JOIN TPA_RELATIONSHIP_CODE REL ON (M.RELSHIP_TYPE_ID=REL.RELSHIP_TYPE_ID)
      LEFT OUTER JOIN TPA_GENERAL_CODE GC ON (CG.CLAIM_SUB_GENERAL_TYPE_ID=GC.GENERAL_TYPE_ID)
      LEFT OUTER JOIN TPA_GENERAL_CODE RC ON (CE.RSON_GENERAL_TYPE_ID=RC.GENERAL_TYPE_ID)
      LEFT OUTER JOIN TPA_GROUP_REGISTRATION GR ON (GR.GROUP_REG_SEQ_ID=P.GROUP_REG_SEQ_ID)
      LEFT OUTER JOIN PAT_ENROLL_DETAILS PE ON (PE.PAT_ENROLL_DETAIL_SEQ_ID=CG.PAT_ENROLL_DETAIL_SEQ_ID)
      LEFT OUTER JOIN PAT_GENERAL_DETAILS PG ON (PG.PAT_ENROLL_DETAIL_SEQ_ID=PE.PAT_ENROLL_DETAIL_SEQ_ID AND PG.PAT_ENHANCED_YN='N')
      LEFT OUTER JOIN TPA_ENR_BANK_DTLS BD ON (G.BANK_SEQ_ID=BD.BANK_SEQ_ID)--,koc 1216
      LEFT OUTER JOIN TPA_ENR_MEM_ADDRESS MA ON (G.ENR_ADDRESS_SEQ_ID=MA.ENR_ADDRESS_SEQ_ID) --,koc 1216
      WHERE DCA.DEBIT_SEQ_ID=Parameter_tab(1) AND CP.FLOAT_SEQ_ID=Parameter_tab(2) ORDER BY CP.CLAIM_APRV_DATE;
 END debit_note_for_ibm_daksh;

--=========================================================================
FUNCTION get_icd_code (v_claim_seq_id TPA_CLAIMS_PAYMENT.claim_seq_id%TYPE)
  RETURN VARCHAR2 IS
      v_icd_codes varchar2(300);
      v_flag                  CHAR := 'N';


BEGIN

     FOR rec IN (SELECT a.icd_code FROM icd_pcs_detail a WHERE a.claim_seq_id =v_claim_seq_id )
    LOOP
      IF v_flag = 'N' THEN
        v_icd_codes := rec.icd_code;
        v_flag := 'Y';
      ELSE
        v_icd_codes := v_icd_codes ||','||rec.icd_code;
      END IF;
    END LOOP;
    return v_icd_codes;
END get_icd_code;
--============================================================================
FUNCTION leap_year_indicator(p_date IN VARCHAR2 DEFAULT TO_CHAR(SYSDATE,
                                                                'YYYY'))
  RETURN VARCHAR2
AS
  v_year VARCHAR2(5);
  v_rem1 NUMBER(5, 2);
  v_rem2 NUMBER(5, 2);
  v_rem3 NUMBER(5, 2);

  BEGIN
  
    v_rem1 := MOD(p_date, 4);
    v_rem2 := MOD(p_date, 100);
    v_rem3 := MOD(p_date, 400);
  
    IF ((v_rem1 = 0 AND v_rem2 <> 0) OR v_rem3 = 0) THEN
      v_year := 'L';
    
    ELSE
      v_year := 'NL';
    END IF;
  
    RETURN v_year;
  END leap_year_indicator;
--================================================================================================================
PROCEDURE REVENUE_INVOICE_REPORT (p_date IN VARCHAR2,
                                  p_resultset OUT SYS_REFCURSOR
                                 )
AS
  str_tab                ttk_util_pkg.str_table_type;
BEGIN
  
  str_tab     := ttk_util_pkg.parse_str ( p_date );
  OPEN p_resultset FOR
    select rownum sno,
       pm.mem_name as "Beneficiary First Name",
       pm.family_name as "Family Name",
       case pm.relship_type_id
         when 'NCH' then 'CHILD'
         when 'NFR' then 'FATHER'
         when 'YMO' then 'MOTHER'
         when 'OTH' then 'OTHER'
         when 'NSF' then 'SELF'
         when 'YSP' then 'SPOUSE'
       end as Relation,
       to_char(pm.mem_dob, 'DD/MM/YYYY') as DOB,
       TRUNC(MONTHS_BETWEEN(pm.date_of_inception, pm.mem_dob) /12) as AGE,
       case when pm.gender_general_type_id = 'MAL' then
         'MALE'
       when pm.gender_general_type_id = 'FEM' then
         'FEMALE'
       end as GENDER,
       case pm.marital_status_id 
         when 'MRD' then 'MARRIED'
         when 'SNG' then 'UNMARRIED'
       end as "MARITAL STATUS",
       tc.country_name as Nationality,
       p.salary_band "Salary Band",
       pm.emirate_id as "Emirates ID Number",
       t.product_name as CAT,
       
       case when pol.capitation_yn = 'Y' then
         to_char(nvl(pol.total_net_premium, 0), '99G999G999G990D00')
       else
         to_char(nvl(pol.total_net_premium, 0), '99G999G999G990D00')
       end as PREMIUM,
       
       
       --Gross Premium
       case when pol.capitation_yn = 'Y' then
         to_char(nvl(pm.gross_prem, 0), '99G999G999G990D00')
       else
         case when pm.mem_general_type_id = 'PFL' then
           to_char(nvl(p.floater_premium, 0), '99G999G999G990D00')
         else
           to_char(nvl(pm.mem_total_premium, 0), '99G999G999G990D00')
         end
       end as "Gross Premium",
       
       --Net Premium
       case when pol.capitation_yn = 'Y' then
         to_char(nvl(pm.net_prem, 0), '99G999G999G990D00')
       else
         case when pm.mem_general_type_id = 'PFL' then
           to_char((p.floater_premium * ap.commission_to_tpa / 100), '99G999G999G990D000')
         else
           to_char((pm.mem_total_premium * ap.commission_to_tpa / 100), '99G999G999G990D000')
         end
       end as "Net Premium",
       
       -- Caluculated Gross Premium
       case (select batch_report_pkg.leap_year_indicator from dual)
         when 'L' then
           case when pol.capitation_yn = 'Y' then
             case when pm.status_general_type_id = 'POA' then
               to_char(((pm.gross_prem / 366) * ((pm.date_of_exit - pm.date_of_inception) + 1)) , '99G999G999G990D00')
             else
               to_char((nvl(pm.gross_prem, 0) / 366) * ((pm.date_of_exit - pm.date_of_inception)+ 1) -
               (nvl(pm.gross_prem, 0) / 366) * ( (pm.before_update_canc_date - pm.date_of_inception)), '99G999G999G990D00')
             end
           else
             case when pm.status_general_type_id = 'POA' then
               case when pm.mem_general_type_id = 'PFL' then
                 to_char(((nvl(p.floater_premium, 0) / 366) * ((pm.date_of_exit - pm.date_of_inception) + 1)), '99G999G999G990D00')
               else
                 to_char(((nvl(pm.mem_total_premium, 0) / 366) * ((pm.date_of_exit - pm.date_of_inception) + 1)), '99G999G999G990D00')
               end
             else
               case when pm.mem_general_type_id = 'PFL' then
                 to_char((nvl(p.floater_premium, 0) / 366) * ((pm.date_of_exit - pm.date_of_inception)+ 1) -
                 (nvl(p.floater_premium, 0) / 366) * ( (pm.before_update_canc_date - pm.date_of_inception)), '99G999G999G990D00')
               else
                 to_char((nvl(pm.mem_total_premium, 0) / 366) * ((pm.date_of_exit - pm.date_of_inception)+ 1) -
                 (nvl(pm.mem_total_premium, 0) / 366) * ( (pm.before_update_canc_date - pm.date_of_inception)), '99G999G999G990D00')
               end
             end
           end
         when 'NL' then
           case when pol.capitation_yn = 'Y' then
             case when pm.status_general_type_id = 'POA' then
               to_char(((pm.gross_prem / 365) * ((pm.date_of_exit - pm.date_of_inception) + 1)), '99G999G999G990D00')
             else
               to_char((nvl(pm.gross_prem, 0) / 365) * ((pm.date_of_exit - pm.date_of_inception)+ 1) -
               (nvl(pm.gross_prem, 0) / 365) * ( (pm.before_update_canc_date - pm.date_of_inception)), '99G999G999G990D00')
             end
           else
             case when pm.status_general_type_id = 'POA' then
               case when pm.mem_general_type_id = 'PFL' then
                 to_char(((nvl(p.floater_premium, 0) / 365) * ((pm.date_of_exit - pm.date_of_inception) + 1)), '99G999G999G990D00')
               else
                 to_char(((nvl(pm.mem_total_premium, 0) / 365) * ((pm.date_of_exit - pm.date_of_inception) + 1)), '99G999G999G990D00')
               end
             else
               case when pm.mem_general_type_id = 'PFL' then
                 to_char((nvl(p.floater_premium, 0) / 365) * ((pm.date_of_exit - pm.date_of_inception)+ 1) -
                 (nvl(p.floater_premium, 0) / 365) * ( (pm.before_update_canc_date - pm.date_of_inception)), '99G999G999G990D00')
               else
                 to_char((nvl(pm.mem_total_premium, 0) / 365) * ((pm.date_of_exit - pm.date_of_inception)+ 1) -
                 (nvl(pm.mem_total_premium, 0) / 365) * ( (pm.before_update_canc_date - pm.date_of_inception)), '99G999G999G990D00')
               end
             end
           end
       end as "Caluculated Gross Premium",
       
       -- Caluculated Net Premium 
       case (select batch_report_pkg.leap_year_indicator from dual)
         when 'L' then 
           case when pol.capitation_yn = 'Y' then
             case when pm.status_general_type_id = 'POA' then
                 to_char(((pm.net_prem / 366) * (pm.date_of_exit - pm.date_of_inception) + 1), '99G999G999G990D00')
             else
               to_char((nvl(pm.net_prem, 0) / 366) * ((pm.date_of_exit - pm.date_of_inception) + 1) -
               (nvl(pm.net_prem, 0) / 366) * ( (pm.before_update_canc_date - pm.date_of_inception)), '99G999G999G990D00')
             end
           else
             case when pm.status_general_type_id = 'POA' then
               case when pm.mem_general_type_id = 'PFL' then
                 to_char(((p.floater_premium * ap.commission_to_tpa / 100) / 366) * ( (pm.date_of_exit - pm.date_of_inception) + 1), '99G999G999G990D00')
               else
                 to_char(((pm.mem_total_premium * ap.commission_to_tpa / 100) / 366) * ( (pm.date_of_exit - pm.date_of_inception) + 1), '99G999G999G990D00')
               end
             else
               case when pm.mem_general_type_id = 'PFL' then
                 to_char(((p.floater_premium * ap.commission_to_tpa / 100) / 366) * ((pm.date_of_exit - pm.date_of_inception) + 1) -
                 ((p.floater_premium * ap.commission_to_tpa / 100) / 366) * ( (pm.before_update_canc_date - pm.date_of_inception)), '99G999G999G990D00')
               else
                 to_char(((pm.mem_total_premium * ap.commission_to_tpa / 100) / 366) * ((pm.date_of_exit - pm.date_of_inception) + 1) -
                 ((pm.mem_total_premium * ap.commission_to_tpa / 100) / 366) * ( (pm.before_update_canc_date - pm.date_of_inception)), '99G999G999G990D00')
               end
             end
           end
         when 'NL' then
           case when pol.capitation_yn = 'Y' then
             case when pm.status_general_type_id = 'POA' then
               to_char(((nvl(pm.net_prem, 0) / 365) * ((pm.date_of_exit - pm.date_of_inception) + 1)), '99G999G999G990D00')
             else
               to_char((nvl(pm.net_prem, 0) / 365) * ((pm.date_of_exit - pm.date_of_inception) + 1) -
               (nvl(pm.net_prem, 0) / 365) * ( (pm.before_update_canc_date - pm.date_of_inception)), '99G999G999G990D00')
             end
           else
             case when pm.status_general_type_id = 'POA' then
               case when pm.mem_general_type_id = 'PFL' then
                 to_char(((p.floater_premium * ap.commission_to_tpa / 100) / 365) * ( (pm.date_of_exit - pm.date_of_inception) + 1), '99G999G999G990D00')
               else
                 to_char(((pm.mem_total_premium * ap.commission_to_tpa / 100) / 365) * ( (pm.date_of_exit - pm.date_of_inception) + 1), '99G999G999G990D00')
               end
             else
               case when pm.mem_general_type_id = 'PFL' then
                 to_char((((p.floater_premium * ap.commission_to_tpa / 100)) / 365) * ((pm.date_of_exit - pm.date_of_inception) + 1) -
                 ((p.floater_premium * ap.commission_to_tpa / 100) / 365) * ( (pm.before_update_canc_date - pm.date_of_inception)), '99G999G999G990D00')
               else
                 to_char((((pm.mem_total_premium * ap.commission_to_tpa / 100)) / 365) * ((pm.date_of_exit - pm.date_of_inception) + 1) -
                 (((pm.mem_total_premium * ap.commission_to_tpa / 100)) / 365) * ( (pm.before_update_canc_date - pm.date_of_inception)), '99G999G999G990D00')
               end
             end
           end
       end as "Caluculated Net Premium",
       
       (pm.date_of_exit - pm.date_of_inception) + 1 as "Policy Active Days",-- Policy Active Date
       tg.group_name as "Corporate Name",
       pol.policy_number "Policy Number",
       p.employee_no as "Employee Code",
       to_char(pm.date_of_inception, 'DD/MM/YYYY') as DOJ,
       to_char(pol.effective_to_date, 'DD/MM/YYYY') as DOE,
       to_char(pm.date_of_inception, 'DD/MM/YYYY') as "DATE Of INCEPTION",
       case when pm.status_general_type_id = 'POA' then
         null
       else
         to_char(pm.date_of_exit, 'DD/MM/YYYY')
       end as "Date Of Cancelation",
       case 
         when pol.renew_count > 0 then
           'Renew'
         when pol.renew_count = 0 then
           'New'
       end as "Renewal/New",
       --Initial/Deletion/Addition
       case
         when pol.effective_from_date = pm.date_of_inception and pm.status_general_type_id = 'POA'then
           'Initial'
         when pol.effective_from_date < pm.date_of_inception and pm.status_general_type_id = 'POA'then
           'Addition'
         when pm.status_general_type_id = 'POC' then
           'Deletion'
       end as "Initial/Addition/Deletion",
       --Member Status Active/Inactive
       case pm.status_general_type_id
         when 'POA' then 'Active'
         when 'POC' then 'Inactive'
       end as "Mem Status",
       to_char(pm.added_date, 'DD/MM/YYYY') as "Mem Added Date",
       case
         when pm.global_net_member_id is not null then
           pm.global_net_member_id
         when pm.tpa_enrollment_id is not null then
           pm.tpa_enrollment_id
       end as "Member Id",
       to_char(pol.policy_rcvd_date, 'DD/MM/YYYY') "Policy Rcvd Date",
       ti.ins_comp_name as "Ins Comp Name",
       --Capitation/ Non-Capitation
       case when pol.capitation_yn = 'Y' then
         'Capitation'
       else
         'Non-Capitation'
       end as Capitation_Non_capitation,
       case when pm.global_net_member_id is not null then
         'Global Net'
       else
         'Vidal Id'
       end as "Type"
       
       
    from tpa_enr_policy_group p
    left join tpa_enr_policy_member pm on (pm.policy_group_seq_id = p.policy_group_seq_id)
    left join tpa_enr_policy pol on (pol.policy_seq_id = p.policy_seq_id)
    left join tpa_ins_product t on (t.product_seq_id = pol.product_seq_id)
    left join tpa_ins_info ti   on (ti.ins_seq_id = pol.ins_seq_id)
    left join tpa_country_code tc on (tc.country_id = pm.nationality_id)
    left join tpa_group_registration tg on (tg.group_reg_seq_id = pol.group_reg_seq_id)
    left join tpa_ins_assoc_off_product ap on (ap.product_seq_id = t.product_seq_id)
    where pol.policy_rcvd_date between to_date(str_tab(1), 'DD-MM-YY') and to_date(nvl(str_tab(2), sysdate) , 'DD-MM-YY')
    order by SNO;
END REVENUE_INVOICE_REPORT;
--==========================================================================================================   
PROCEDURE generate_crncy_exchng_rpt(where_clause              IN  VARCHAR2,
                                    result_set                OUT SYS_REFCURSOR
                                    )
  IS
  
    str_tab                ttk_util_pkg.str_table_type;
    v_country_id           NUMBER(10);
    v_upld_date            DATE;
    

  BEGIN
    
    str_tab     := ttk_util_pkg.parse_str ( where_clause );
    v_upld_date := TRUNC(to_date(str_tab(1),'dd/mm/yyyy'));
    
  IF v_upld_date IS NOT NULL AND v_country_id IS NULL THEN
    OPEN result_set FOR
     SELECT R.CURRENCY_CODE AS "Currency Code",
            C.CURRENCY_NAME AS "Currency Name",
            R.UNITS_PER_QAR AS "Units Per QAR",
            R.QAR_PER_UNIT AS "QAR Per Unit",
            R.CONVERSION_DATE AS "Conversion Rate",
            TO_CHAR(R.UPLOADED_DATE,'DD/MM/YYYY HH24:MI:SS') AS "Uploaded Date"
        FROM APP.TPA_CURRENCY_CONV_RATES R
        JOIN APP.TPA_CURRENCY_CODE C ON (R.CURRENCY_CODE=C.CURRENCY_ID)
        JOIN APP.TPA_COUNTRY_CODE CO ON (C.COUNTRY_ID=CO.COUNTRY_ID) 
      WHERE TRUNC(r.uploaded_date) = v_upld_date;
      
  ELSIF v_upld_date IS NULL AND v_country_id IS NOT NULL THEN
    OPEN result_set FOR
     SELECT R.CURRENCY_CODE AS "Currency Code",
            C.CURRENCY_NAME AS "Currency Name",
            R.UNITS_PER_QAR AS "Units Per QAR",
            R.QAR_PER_UNIT AS "QAR Per Unit",
            R.CONVERSION_DATE AS "Conversion Rate",
            R.UPLOADED_DATE AS "Uploaded Date"
        FROM APP.TPA_CURRENCY_CONV_RATES R
        JOIN APP.TPA_CURRENCY_CODE C ON (R.CURRENCY_CODE=C.CURRENCY_ID)
        JOIN APP.TPA_COUNTRY_CODE CO ON (C.COUNTRY_ID=CO.COUNTRY_ID) 
      WHERE co.country_id = v_country_id;
  ELSIF v_upld_date IS NOT NULL AND v_country_id IS NOT NULL THEN
    OPEN result_set FOR
     SELECT R.CURRENCY_CODE AS "Currency Code",
            C.CURRENCY_NAME AS "Currency Name",
            R.UNITS_PER_QAR AS "Units Per QAR",
            R.QAR_PER_UNIT AS "QAR Per Unit",
            R.CONVERSION_DATE AS "Conversion Rate",
            R.UPLOADED_DATE AS "Uploaded Date"
        FROM APP.TPA_CURRENCY_CONV_RATES R
        JOIN APP.TPA_CURRENCY_CODE C ON (R.CURRENCY_CODE=C.CURRENCY_ID)
        JOIN APP.TPA_COUNTRY_CODE CO ON (C.COUNTRY_ID=CO.COUNTRY_ID) 
      WHERE TRUNC(r.uploaded_date) = v_upld_date
        AND co.country_id = v_country_id;
  ELSE
    OPEN result_set FOR
     SELECT R.CURRENCY_CODE AS "Currency Code",
            C.CURRENCY_NAME AS "Currency Name",
            R.UNITS_PER_QAR AS "Units Per QAR",
            R.QAR_PER_UNIT AS "QAR Per Unit",
            R.CONVERSION_DATE AS "Conversion Rate",
            R.UPLOADED_DATE AS "Uploaded Date"
        FROM APP.TPA_CURRENCY_CONV_RATES R
        JOIN APP.TPA_CURRENCY_CODE C ON (R.CURRENCY_CODE=C.CURRENCY_ID)
        JOIN APP.TPA_COUNTRY_CODE CO ON (C.COUNTRY_ID=CO.COUNTRY_ID) ;
  END IF;
   
    
END generate_crncy_exchng_rpt;  
--======================================================================================================
PROCEDURE select_crncy_exchng_dtl  (v_upld_date                          IN DATE,
                                    v_country_id                         IN NUMBER,
                                    v_sort_var                           IN  VARCHAR2,
                                    v_sort_order                         IN  VARCHAR2 ,
                                    v_start_num                          IN  NUMBER ,
                                    v_end_num                            IN  NUMBER ,
                                    result_set                           OUT SYS_REFCURSOR
                                    )
IS
    v_sql_str                            VARCHAR2(10000) ;
    TYPE bind_tab_type IS TABLE OF VARCHAR2(250) INDEX BY BINARY_INTEGER ;
    bind_tab                             bind_tab_type;
    i                                    NUMBER(2) := 0;
    v_where                              VARCHAR2(2000);
BEGIN
  
  v_sql_str:= 'SELECT R.CURRENCY_CODE AS "Currency Code",
                      C.CURRENCY_NAME AS "Currency Name",
                      R.UNITS_PER_QAR AS "Units Per QAR",
                      R.QAR_PER_UNIT AS "QAR Per Unit",
                      R.CONVERSION_DATE AS "Conversion Rate",
                      R.UPLOADED_DATE AS "Uploaded Date"
               FROM APP.TPA_CURRENCY_CONV_RATES R
               JOIN APP.TPA_CURRENCY_CODE C ON (R.CURRENCY_CODE=C.CURRENCY_ID)
               JOIN APP.TPA_COUNTRY_CODE CO ON (C.COUNTRY_ID=CO.COUNTRY_ID)';

   IF v_upld_date IS NOT NULL THEN
      v_where := v_where  ||' AND trunc(r.uploaded_date) = :v_upld_date';
      i := i+1;
      bind_tab(i) := trunc(v_upld_date);
   END IF;
    
  IF v_country_id IS NOT NULL THEN
    v_where := v_where  ||' AND co.country_id = :v_country_id';
     i := i+1;
     bind_tab(i) := v_country_id;
  END IF;
    
    IF v_where IS NOT NULL THEN
      v_where   := ' WHERE '|| SUBSTR(v_where,5);
      v_sql_str := v_sql_str ||v_where;
    END IF;


    v_sql_str := 'SELECT * FROM
        (SELECT A.*,DENSE_RANK() OVER (ORDER BY '||v_sort_var||' '||v_sort_order||',ROWNUM)
        Q FROM (' ||v_sql_str|| ') A ) WHERE  Q>= :v_start_num AND Q<= :v_end_num ';

    IF bind_tab.FIRST IS NOT NULL THEN
       CASE bind_tab.COUNT
         WHEN 1  THEN OPEN result_set FOR v_sql_str USING bind_tab(1), v_start_num , v_end_num ;
         WHEN 2  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2), v_start_num , v_end_num ;
       END CASE;
     ELSE
       OPEN result_set FOR v_sql_str USING v_start_num , v_end_num ;
     END IF;

END ;
--=============================================================================================================
--========================================================================================================  
PROCEDURE Claims_setteled_report (where_clause              IN  VARCHAR2,
                                    result_set                OUT SYS_REFCURSOR
                                  )
                                  as
     str_tab                ttk_util_pkg.str_table_type;
    v_recv_from_date            DATE;
    v_recv_to_date               DATE;
    v_apr_from_date             DATE;
    v_apr_to_date               DATE;
    v_float_seq_id         tpa_float_account.float_seq_id%TYPE;
    v_group_id             VARCHAR2(100);      
    v_hosp_seq_id          VARCHAR2(100);  
    v_count                NUMBER(10);
    v_sql_str              VARCHAR2(1000);
    v_sql_qury             VARCHAR2(8000);
    
    
 CURSOR Float_acc_Details (v_flaot_number VARCHAR2) is
   SELECT float_seq_id,COUNT(float_seq_id)  
   FROM tpa_float_account 
   WHERE float_account_number = v_flaot_number
   Group by float_seq_id;
   
   TYPE BIND_DETAILS IS TABLE OF VARCHAR2(100) INDEX BY BINARY_INTEGER;
   sear_tab    BIND_DETAILS; 
   i           number:=0;
    
  BEGIN
    str_tab     := ttk_util_pkg.parse_str ( where_clause );
   
   IF str_tab(6) IS NOT NULL THEN
     v_group_id := str_tab(6);
    END IF;
    
    IF str_tab(7) IS NOT NULL THEN
     v_hosp_seq_id:=str_tab(7);
    END IF;
    
    if str_tab(3) is not null then
      v_recv_from_date := to_date(str_tab(3),'dd/mm/yyyy');
    end if;
    
    if str_tab(4) is not null then 
      v_recv_to_date    := to_date(str_tab(4),'dd/mm/yyyy')+1;
    else
      v_recv_to_date    := to_date(sysdate,'dd/mm/yyyy')+1;
    end if;
    
    
    if str_tab(8) is not null then
     v_apr_from_date := to_date(str_tab(8),'dd/mm/yyyy');
    end if;
    
    if str_tab(8) is not null and str_tab(9) is not null then 
      v_apr_to_date    := to_date(str_tab(9),'dd/mm/yyyy')+1;
    else
      v_apr_to_date    := to_date(sysdate,'dd/mm/yyyy')+1;
    end if;
    
    OPEN Float_acc_Details (str_tab(2));
        FETCH Float_acc_Details INTO v_float_seq_id,v_count;
          CLOSE Float_acc_Details;
          
    IF v_group_id IS NOT NULL THEN
      v_sql_str := ' AND K.GROUP_ID = :v_group_id ';
       i:=i+1;
     sear_tab(i):=v_group_id; 
    END IF;
    
    IF v_hosp_seq_id IS NOT NULL THEN
      v_sql_str:=v_sql_str||' AND HO.HOSP_SEQ_ID = :v_hosp_seq_id ';
      i:=i+1;
     sear_tab(i):=v_hosp_seq_id; 
    END IF;
    
    IF v_recv_from_date IS NOT NULL THEN
      v_sql_str:=v_sql_str||' AND d.clm_received_date BETWEEN  :v_recv_from_date ';
      i:=i+1;
      sear_tab(i):=v_recv_from_date; 
   END IF;
    
    IF v_recv_from_date IS NOT NULL AND v_recv_to_date IS NOT NULL THEN
      v_sql_str:=v_sql_str||' AND   :v_recv_to_date ';
      i:=i+1;
      sear_tab(i):=v_recv_to_date; 
    END IF;    
                
     IF v_apr_from_date IS NOT NULL THEN
      v_sql_str:=v_sql_str||' AND d.completed_date BETWEEN  :v_apr_from_date ';
      i:=i+1;
      sear_tab(i):=v_apr_from_date; 
    END IF;
    
    IF v_apr_from_date IS NOT NULL AND v_apr_to_date IS NOT NULL THEN
      v_sql_str:=v_sql_str||' AND   :v_apr_to_date ';
      i:=i+1;
      sear_tab(i):=v_apr_to_date; 
    END IF;
          
   If NVL(v_count,0)=0 then 
     Raise_Application_error ('-20922','Given Float Account is not Avilable');
  ELSE                                    
 -- open result_set for
     v_sql_qury := ' SELECT   
                   ii.ins_comp_code_number,         
                   CASE WHEN d.claim_type=''CNH'' THEN 
                            CASE WHEN NVL(d.pymnt_to_type_id,''PRV'')=''PTN''  THEN w.hosp_name ELSE  ho.hosp_name END
                        WHEN d.claim_type=''CTM'' THEN w.hosp_name END  AS hosp_name,
                   ii.ins_comp_name,
                   clm.batch_no,
                   k.group_name,
                   tip.product_name,
                   d.Invoice_Number,
                   TO_CHAR(h.effective_from_date,''DD/MM/YYYY'') AS effective_from_date,
                   TO_CHAR(h.effective_to_date,''DD/MM/YYYY'') AS effective_to_date,
                   d.claim_number,
                   d.settlement_number,
                   h.policy_number,
                   TO_CHAR(d.added_date,''DD/MM/YYYY HH24:MI:SS'') as claim_added_date,
                   TO_CHAR(d.date_of_hospitalization,''DD/MM/YYYY'') AS date_of_hospitalization, 
                   TO_CHAR(d.clm_received_date,''DD/MM/YYYY HH24:MI:SS'') AS clm_received_date,
                   ge.description as claim_type,
                   d.tpa_enrollment_id as tpa_id_no, 
                   d.mem_name,
                   gene.description as claim_Status,
                   TO_CHAR(d.completed_date,''DD/MM/YYYY'') as approved_date,
                   d.requested_amount,
                   d.req_amt_currency_type as req_curr,
                   d.conversion_rate as conv_rate,
                   d.converted_amount as conv_amount,
                   (d.tot_disc_gross_amount-d.tot_approved_amount)/*d.tot_patient_share_amount*/ as patient_share,
                   ''QAR'' AS ded_curr,
                   d.converted_final_approved_amt as conv_app_amount,
                   d.converted_amount_currency_type as conv_amount_curr,
                   d.final_app_amount as fin_app_amt,
                   gener.description as benifit_type,
                   a.claim_payment_status,
                   a.payee_type as Mode_of_Payment,
                 /*  ba.file_name as Payment_Ref_No,
                   ba.bank_acc_seq_id as Payment_Batch_No,*/
                   TO_CHAR (SYSDATE,''DD-MM-YYYY'') AS print_date,
                    d.pay_amt_in_usd as usd_amount,
                   a.transfer_currency as AMNT_TRANSFERRED_CURR  
                    

    FROM fin_app.tpa_claims_payment A JOIN app.clm_authorization_details D ON(A.claim_seq_id = D.claim_seq_id)
          /*JOIN tpa_ins_info ins on (d.ins_seq_id=ins.ins_seq_id)*/
          LEFT OUTER JOIN app.clm_batch_upload_details clm on (clm.clm_batch_seq_id=d.clm_batch_seq_id)
          LEFT OUTER JOIN app.diagnosys_details dd on (d.claim_seq_id=dd.claim_seq_id AND dd.primary_ailment_yn=''Y'')
          LEFT OUTER JOIN app.tpa_icd10_master_details icd on (icd.icd_code=dd.diagnosys_code)
          JOIN app.tpa_enr_policy H ON(H.policy_seq_id = d.policy_seq_id)
          JOIN tpa_office_info I ON( H.tpa_office_seq_id  = I.tpa_office_seq_id)
          left outer join app.tpa_hosp_info ho on (a.hosp_seq_id=ho.hosp_seq_id)
          LEFT OUTER JOIN tpa_enr_policy_member pm on (pm.member_seq_id=d.member_seq_id)
          LEFT OUTER JOIN app.tpa_enr_policy_group teg on (pm.policy_group_seq_id = teg.policy_group_seq_id)
          LEFT OUTER JOIN app.tpa_ins_info ii on (d.ins_seq_id = ii.ins_seq_id)
          LEFT OUTER JOIN app.tpa_group_registration k ON (a.group_reg_seq_id = k.group_reg_seq_id)
          JOIN fin_app.tpa_float_account fa on (a.float_seq_id = fa.float_seq_id and a.float_seq_id= '''||v_float_seq_id||''')
          LEFT OUTER JOIN fin_app.tpa_debit_note_claims_assoc cas on (cas.claim_seq_id=d.claim_seq_id)
          LEFT OUTER JOIN FIN_APP.TPA_DEBIT_NOTE tdn on (cas.debit_seq_id = tdn.debit_seq_id)
          LEFT OUTER JOIN fin_app.tpa_bank_accounts ba on (fa.bank_acc_seq_id = ba.bank_acc_seq_id)
         /* LEFT OUTER JOIN fin_app.tpa_payment_checks_details cd on (a.payment_seq_id = cd.payment_seq_id) 
          LEFT OUTER JOIN fin_app.tpa_claims_check cc on (cd.claims_chk_seq_id = cc.claims_chk_seq_id) */
          LEFT OUTER JOIN app.tpa_general_code g    on (fa.float_type = g.general_type_id)
          LEFT OUTER JOIN app.tpa_general_code ge   on (d.claim_type = ge.general_type_id) 
          LEFT OUTER JOIN app.tpa_general_code gen  on (a.payee_type = gen.general_type_id)
          LEFT OUTER JOIN app.tpa_general_code gene on (d.clm_status_type_id = gene.general_type_id)
          LEFT OUTER JOIN app.tpa_general_code gener on (d.benifit_type = gener.general_type_id)
          LEFT OUTER JOIN app.tpa_general_code genera on (tdn.debit_status_general_type_id = genera.general_type_id)
          LEFT OUTER JOIN app.tpa_ins_product tip     on (tip.ins_seq_id = ii.ins_seq_id
                                                           AND tip.product_seq_id = h.product_seq_id)
          LEFT OUTER JOIN app.clm_hospital_details w ON (d.claim_seq_id = w.claim_seq_id)
          LEFT OUTER JOIN tpa_hosp_account_details W ON(hO.hosp_seq_id=w.hosp_seq_id)
          LEFT OUTER JOIN tpa_partner_info pi ON (D.ptnr_seq_id=pi.ptnr_seq_id)
          LEFT OUTER JOIN tpa_partner_account_details pa ON (pi.ptnr_seq_id=pa.ptnr_seq_id)
         -- LEFT OUTER JOIN tpa_bank_advice_batch BA ON (BA.BANK_ACC_SEQ_ID=A.BANK_ADVICE_BATCH)                                                                            
                               
    WHERE a.claim_payment_status IN (''PAID'') and d.clm_status_type_id=''APR''';
          --AND a.claim_aprv_date BETWEEN '''|| v_from_date||''' AND '''||v_to_date||'''';
       
  v_sql_qury :=v_sql_qury||v_sql_str;       
   

  if sear_tab.count is not null then
     case  sear_tab.count when 1 then open result_set for v_sql_qury using  sear_tab(1); 
                          when 2 then open result_set for v_sql_qury using sear_tab(1),sear_tab(2);
                          when 3 then open result_set for v_sql_qury using  sear_tab(1),sear_tab(2),sear_tab(3); 
                          when 4 then open result_set for v_sql_qury using  sear_tab(1),sear_tab(2),sear_tab(3),sear_tab(4); 
                          when 5 then open result_set for v_sql_qury using  sear_tab(1),sear_tab(2),sear_tab(3),sear_tab(4),sear_tab(5); 
                          when 6 then open result_set for v_sql_qury using  sear_tab(1),sear_tab(2),sear_tab(3),sear_tab(4),sear_tab(5),sear_tab(6); 
      else                      
     open result_set for v_sql_qury; 
     end case;
   end if;
  end if;
END Claims_setteled_report;
--==========================================================================================================
PROCEDURE Claims_inprogress_report(where_clause              IN  VARCHAR2,
                                    result_set                OUT SYS_REFCURSOR
                                    )
                                    AS
    str_tab                ttk_util_pkg.str_table_type;
    v_recv_from_date            DATE;
    v_recv_to_date              DATE;
    v_float_seq_id         tpa_float_account.float_seq_id%TYPE; 
    v_group_id             VARCHAR2(100);      
    v_hosp_seq_id          VARCHAR2(100);     
    v_count                NUMBER;
    v_sql_str              varchar2(1000);
    v_sql_qury             VARCHAR2(8000);
 
  /* CURSOR Float_acc_Details (v_flaot_number VARCHAR2) is
   SELECT float_seq_id,COUNT(float_seq_id)  
   FROM tpa_float_account 
   WHERE float_account_number =v_flaot_number
   Group by float_seq_id;*/
   
   TYPE BIND_DETAILS IS TABLE OF VARCHAR2(100) INDEX BY BINARY_INTEGER;
   sear_tab    BIND_DETAILS; 
   i           number:=0;                      
                                    
BEGIN
  
    str_tab          := ttk_util_pkg.parse_str ( where_clause );
    
    IF str_tab(6) IS NOT NULL THEN
     v_group_id := str_tab(6);
    END IF;
    
    IF str_tab(7) IS NOT NULL THEN
     v_hosp_seq_id:=str_tab(7);
    END IF;
      
    if str_tab(3) is not null then
      v_recv_from_date := to_date(str_tab(3),'dd/mm/yyyy');
    end if;
    
    IF str_tab(3) is not null AND str_tab(4) IS NOT NULL THEN
      v_recv_to_date   := to_date(str_tab(4),'dd/mm/yyyy')+1;
    ELSE
      v_recv_to_date   := to_date(sysdate,'dd/mm/yyyy')+1;
    END IF;
      
   /* OPEN Float_acc_Details (str_tab(2));
        FETCH Float_acc_Details INTO v_float_seq_id,v_count;
          CLOSE Float_acc_Details;
        */
   IF v_group_id IS NOT NULL THEN
      v_sql_str := ' AND K.GROUP_ID = :v_group_id ';
       i:=i+1;
     sear_tab(i):=v_group_id; 
      
    END IF;
    
    IF v_hosp_seq_id IS NOT NULL THEN
      v_sql_str:=v_sql_str||' AND HO.HOSP_SEQ_ID = :v_hosp_seq_id ';
      i:=i+1;
     sear_tab(i):=v_hosp_seq_id; 
     
    END IF;
          
    IF v_recv_from_date IS NOT NULL THEN
      v_sql_str:=v_sql_str||' AND d.clm_received_date BETWEEN  :v_recv_from_date ';
      i:=i+1;
     sear_tab(i):=v_recv_from_date; 
    END IF;
    
    IF v_recv_from_date IS NOT NULL AND v_recv_to_date IS NOT NULL THEN
      v_sql_str:=v_sql_str||' AND   :v_recv_to_date ';
      i:=i+1;
     sear_tab(i):=v_recv_to_date; 
    END IF;
    
/*If NVL(v_count,0)=0 then 
     Raise_Application_error ('-20922','Given Float Account is not Avilable');
ELSE*/
 
v_sql_qury:=
    'SELECT ins.ins_comp_name,
         ins.ins_comp_code_number,       
         CASE WHEN d.claim_type=''CNH'' THEN 
                 CASE WHEN NVL(d.pymnt_to_type_id,''PRV'')=''PTN'' THEN w.hosp_name ELSE  ho.hosp_name END
              WHEN d.claim_type=''CTM'' THEN w.hosp_name END  AS hosp_name,
         clm.batch_no,
         k.group_name,
         tip.product_name,
         d.invoice_number,
         TO_CHAR(h.effective_from_date,''DD/MM/YYYY'') AS effective_from_date,
         TO_CHAR(h.effective_to_date,''DD/MM/YYYY'') AS effective_to_date,
         d.claim_number,
         d.settlement_number,
         h.policy_number,
         TO_CHAR(d.added_date,''DD/MM/YYYY HH24:MI:SS'') as claim_added_date,       
         TO_CHAR(d.date_of_hospitalization,''DD/MM/YYYY'') AS date_of_hospitalization, 
         TO_CHAR(d.clm_received_date,''DD/MM/YYYY HH24:MI:SS'') AS clm_received_date,
         ge.description as claim_type,
         pm.tpa_enrollment_id,
         d.mem_name,
         gene.description as claim_status, 
         TO_CHAR(d.completed_date,''DD/MM/YYYY'') as approved_date,
         d.requested_amount,
         d.req_amt_currency_type as req_curr,
         d.conversion_rate as conv_rate,
         d.converted_amount as conv_amount,
         d.converted_amount_currency_type as conv_amount_curr,
         (d.tot_disc_gross_amount-d.tot_approved_amount)/*d.tot_patient_share_amount*/ as patient_share,
         ''QAR'' as ded_curr,
         d.converted_final_approved_amt as conv_app_amount,
         gener.description as benifit_type,
         d.fnl_amt_currency_type as final_app_amount,
		     d.final_app_amount as fin_app_amt,
         TO_CHAR (SYSDATE,''DD-MM-YYYY'') AS print_date
                    
    FROM  app.clm_authorization_details D  
          JOIN tpa_ins_info ins on (d.ins_seq_id=ins.ins_seq_id)
          LEFT OUTER JOIN app.clm_batch_upload_details clm on (d.clm_batch_seq_id=clm.clm_batch_seq_id)
          JOIN app.diagnosys_details dd on (d.claim_seq_id=dd.claim_seq_id AND dd.primary_ailment_yn=''Y'')
          JOIN app.tpa_icd10_master_details icd on (icd.icd_code=dd.diagnosys_code)
          JOIN app.tpa_enr_policy H ON(H.policy_seq_id = d.policy_seq_id)
          JOIN tpa_office_info I ON( H.tpa_office_seq_id  = I.tpa_office_seq_id)
          left outer join tpa_enr_policy_member pm on (pm.member_seq_id=d.member_seq_id)
          LEFT OUTER JOIN app.tpa_enr_policy_group teg on (pm.policy_group_seq_id = teg.policy_group_seq_id)
          LEFT OUTER JOIN app.tpa_ins_info ii on (d.ins_seq_id = ii.ins_seq_id)
          LEFT OUTER JOIN app.tpa_group_registration k ON (teg.group_reg_seq_id = k.group_reg_seq_id)
          LEFT OUTER JOIN app.tpa_general_code ge   on (d.claim_type = ge.general_type_id) 
          LEFT OUTER JOIN app.tpa_general_code gene on (d.clm_status_type_id = gene.general_type_id)
          LEFT OUTER JOIN app.tpa_general_code gener on (d.benifit_type = gener.general_type_id)
          LEFT JOIN  app.tpa_ins_product tip on (tip.ins_seq_id = ii.ins_seq_id AND tip.product_seq_id = h.product_seq_id)
          LEFT OUTER JOIN app.clm_hospital_details w ON (d.claim_seq_id = w.claim_seq_id)
          left outer join app.tpa_hosp_info ho on (w.hosp_seq_id=ho.hosp_seq_id)
          LEFT OUTER JOIN tpa_partner_info pi ON (D.ptnr_seq_id=pi.ptnr_seq_id)
          LEFT OUTER JOIN tpa_partner_account_details pa ON (pi.ptnr_seq_id=pa.ptnr_seq_id)                                                                          
    WHERE d.clm_status_type_id in (''INP'',''REQ'') ';
        --  and d.clm_received_date BETWEEN '''||v_from_date||''' AND '''||v_to_date||'''';
          
     v_sql_qury:=v_sql_qury||v_sql_str;
     
   if sear_tab.count is not null then
     case  sear_tab.count when 1 then open result_set for v_sql_qury using sear_tab(1); 
                          when 2 then open result_set for v_sql_qury using sear_tab(1),sear_tab(2);
                          when 3 then open result_set for v_sql_qury using sear_tab(1),sear_tab(2),sear_tab(3);
                          when 4 then open result_set for v_sql_qury using sear_tab(1),sear_tab(2),sear_tab(3),sear_tab(4);  
      else                      
     open result_set for v_sql_qury; 
     end case;
   end if;
  --end if; 
END Claims_inprogress_report;                                    
--===========================================================================================================
PROCEDURE Claims_Outstanding_report(where_clause              IN  VARCHAR2,
                                    result_set                OUT SYS_REFCURSOR
                                    )
                                    AS
    str_tab                ttk_util_pkg.str_table_type;
    v_recv_from_date            DATE;
    v_recv_to_date               DATE;
    v_apr_from_date             DATE;
    v_apr_to_date               DATE;
    v_float_seq_id         tpa_float_account.float_seq_id%TYPE;
    v_group_id             VARCHAR2(100);      
    v_hosp_seq_id          VARCHAR2(100);  
    V_COUNT                NUMBER(10);
    v_sql_str              VARCHAR2(1000);
    v_sql_qury             VARCHAR2(8000);
    
 
CURSOR Float_acc_Details (v_flaot_number VARCHAR2) is
   SELECT float_seq_id,COUNT(float_seq_id)
   FROM tpa_float_account 
   WHERE float_account_number = v_flaot_number
   GROUP BY float_seq_id;
   
  
	 TYPE BIND_DETAILS IS TABLE OF VARCHAR2(100) INDEX BY BINARY_INTEGER;
     sear_tab    BIND_DETAILS; 
     i           number:=0;  
   
  BEGIN
    str_tab     := ttk_util_pkg.parse_str ( where_clause );
    
    IF str_tab(6) IS NOT NULL THEN
     v_group_id := str_tab(6);
    END IF;
    
    IF str_tab(7) IS NOT NULL THEN
     v_hosp_seq_id:=str_tab(7);
    END IF;
    
    if str_tab(3) is not null then
    v_recv_from_date := to_date(str_tab(3),'dd/mm/yyyy');
    end if;
    
    if str_tab(4) is not null then 
      v_recv_to_date    := to_date(str_tab(4),'dd/mm/yyyy')+1;
    else
      v_recv_to_date    := to_date(sysdate,'dd/mm/yyyy')+1;
    end if;
    
    if str_tab(8) is not null then
     v_apr_from_date := to_date(str_tab(8),'dd/mm/yyyy');
    end if;
    
    if str_tab(8) is not null and str_tab(9) is not null then 
      v_apr_to_date    := to_date(str_tab(9),'dd/mm/yyyy')+1;
    else
      v_apr_to_date    := to_date(sysdate,'dd/mm/yyyy')+1;
    end if;
     
    OPEN Float_acc_Details (str_tab(2));
          FETCH Float_acc_Details INTO v_float_seq_id,V_COUNT;
                CLOSE Float_acc_Details;
                
     	  
    IF v_group_id IS NOT NULL THEN
      v_sql_str := 'AND K.GROUP_ID= '''||v_group_id||'''';
    END IF;
    
    IF v_hosp_seq_id IS NOT NULL THEN
      v_sql_str:=v_sql_str||'AND HO.HOSP_SEQ_ID= '''||v_hosp_seq_id||'''';
    END IF;           
             
   
   IF v_recv_from_date IS NOT NULL THEN
      v_sql_str:=v_sql_str||' AND d.clm_received_date BETWEEN  :v_recv_from_date ';
      i:=i+1;
      sear_tab(i):=v_recv_from_date; 
   END IF;
    
    IF v_recv_from_date IS NOT NULL AND v_recv_to_date IS NOT NULL THEN
      v_sql_str:=v_sql_str||' AND   :v_recv_to_date ';
      i:=i+1;
      sear_tab(i):=v_recv_to_date; 
    END IF;    
                
     IF v_apr_from_date IS NOT NULL THEN
      v_sql_str:=v_sql_str||' AND d.completed_date BETWEEN  :v_apr_from_date ';
      i:=i+1;
      sear_tab(i):=v_apr_from_date; 
    END IF;
    
    IF v_apr_from_date IS NOT NULL AND v_apr_to_date IS NOT NULL THEN
      v_sql_str:=v_sql_str||' AND   :v_apr_to_date ';
      i:=i+1;
      sear_tab(i):=v_apr_to_date; 
    END IF;
           
If NVL(v_count,0)=0 then 
     Raise_Application_error ('-20922','Given Float Account is not Avilable');
ELSE
                                    
 v_sql_qury:=
            'SELECT ins.ins_comp_name,
                   ins.ins_comp_code_number,           
                   CASE WHEN d.claim_type=''CNH'' THEN 
                           CASE WHEN NVL(d.pymnt_to_type_id,''PRV'')=''PTN'' THEN w.hosp_name ELSE  ho.hosp_name END
                        WHEN d.claim_type=''CTM'' THEN w.hosp_name END  AS hosp_name,
                   ii.ins_comp_name,
                   clm.batch_no,
                   k.group_name,
                   tip.product_name,
                   d.Invoice_Number,
                   TO_CHAR(h.effective_from_date,''DD/MM/YYYY'') AS effective_from_date,
                   TO_CHAR(h.effective_to_date,''DD/MM/YYYY'') AS effective_to_date,
                   d.claim_number,
                   d.settlement_number,
                   h.policy_number,
                   TO_CHAR(d.added_date,''DD/MM/YYYY HH24:MI:SS'') as claim_added_date,       
                   TO_CHAR(d.date_of_hospitalization,''DD/MM/YYYY'') AS date_of_hospitalization, 
                   TO_CHAR(d.clm_received_date,''DD/MM/YYYY HH24:MI:SS'') AS clm_received_date,
                   ge.description as claim_type,
                   d.tpa_enrollment_id, 
                   d.mem_name,
                   gene.description as claim_Status,
                   TO_CHAR(d.completed_date,''DD/MM/YYYY'') as approved_date,
                   d.requested_amount,
                   d.req_amt_currency_type as req_curr,
                   d.conversion_rate as conv_rate,
                   d.converted_amount as conv_amount,
                   (d.tot_disc_gross_amount-d.tot_approved_amount)/*d.tot_patient_share_amount*/ as patient_share,
                   ''QAR'' AS ded_curr,
                   d.converted_final_approved_amt as conv_app_amount,
                   d.converted_amount_currency_type as conv_amount_curr,
                   d.final_app_amount as fin_app_amt,
                   gener.description as benifit_type,
                   case when a.claim_payment_status =''SENT_TO_BANK'' then ''APPROVED BY FINANCE'' else a.claim_payment_status end as claim_payment_status,
                   TO_CHAR (SYSDATE,''DD-MM-YYYY'') AS print_date,
                   d.pay_amt_in_usd as usd_amount,
                   a.transfer_currency as AMNT_TRANSFERRED_CURR  

    FROM fin_app.tpa_claims_payment A JOIN app.clm_authorization_details D ON(A.claim_seq_id = D.claim_seq_id)
          JOIN tpa_ins_info ins on (d.ins_seq_id=ins.ins_seq_id)
          LEFT OUTER JOIN app.clm_batch_upload_details clm on (clm.clm_batch_seq_id=d.clm_batch_seq_id)
          LEFT OUTER JOIN app.diagnosys_details dd on (d.claim_seq_id=dd.claim_seq_id AND dd.primary_ailment_yn=''Y'')
          LEFT OUTER JOIN app.tpa_icd10_master_details icd on (icd.icd_code=dd.diagnosys_code)
          JOIN app.tpa_enr_policy H ON(H.policy_seq_id = d.policy_seq_id)
          JOIN tpa_office_info I ON( H.tpa_office_seq_id  = I.tpa_office_seq_id)
          left outer join app.tpa_hosp_info ho on (a.hosp_seq_id=ho.hosp_seq_id)
          left outer join tpa_enr_policy_member pm on (pm.member_seq_id=d.member_seq_id)
          LEFT OUTER JOIN app.tpa_enr_policy_group teg on (pm.policy_group_seq_id = teg.policy_group_seq_id)
          LEFT OUTER JOIN app.tpa_ins_info ii on (d.ins_seq_id = ii.ins_seq_id)
          LEFT OUTER JOIN app.tpa_group_registration k ON (a.group_reg_seq_id = k.group_reg_seq_id)
          JOIN fin_app.tpa_float_account fa on (a.float_seq_id = fa.float_seq_id and a.float_seq_id='''|| v_float_seq_id||''')
          LEFT OUTER JOIN fin_app.tpa_debit_note_claims_assoc cas on (cas.claim_seq_id=d.claim_seq_id)
          LEFT OUTER JOIN FIN_APP.TPA_DEBIT_NOTE tdn on (cas.debit_seq_id = tdn.debit_seq_id)
          LEFT OUTER JOIN fin_app.tpa_bank_accounts ba on (fa.bank_acc_seq_id = ba.bank_acc_seq_id)
          LEFT OUTER JOIN fin_app.tpa_payment_checks_details cd on (a.payment_seq_id = cd.payment_seq_id) 
          LEFT OUTER JOIN fin_app.tpa_claims_check cc on (cd.claims_chk_seq_id = cc.claims_chk_seq_id) 
          LEFT OUTER JOIN app.tpa_general_code g    on (fa.float_type = g.general_type_id)
          LEFT OUTER JOIN app.tpa_general_code ge   on (d.claim_type = ge.general_type_id) 
          LEFT OUTER JOIN app.tpa_general_code gen  on (a.payee_type = gen.general_type_id)
          LEFT OUTER JOIN app.tpa_general_code gene on (d.clm_status_type_id = gene.general_type_id)
          LEFT OUTER JOIN app.tpa_general_code gener on (d.benifit_type = gener.general_type_id)
          LEFT OUTER JOIN app.tpa_general_code genera on (tdn.debit_status_general_type_id = genera.general_type_id)
          LEFT OUTER JOIN app.tpa_ins_product tip     on (tip.ins_seq_id = ii.ins_seq_id AND tip.product_seq_id = h.product_seq_id)
          LEFT OUTER JOIN app.clm_hospital_details w ON (d.claim_seq_id = w.claim_seq_id)
          LEFT OUTER JOIN tpa_hosp_account_details hac ON(hO.hosp_seq_id=hac.hosp_seq_id)
          LEFT OUTER JOIN tpa_partner_info pi ON (D.ptnr_seq_id=pi.ptnr_seq_id)
          LEFT OUTER JOIN tpa_partner_account_details pa ON (pi.ptnr_seq_id=pa.ptnr_seq_id)                                                                          
                               
    WHERE a.claim_payment_status  IN (''PENDING'',''READY_TO_BANK'',''SENT_TO_BANK'',''DEBIT_NOTE_ATTACHED'') and d.clm_status_type_id=''APR''';
    --AND a.claim_aprv_date BETWEEN '''|| v_from_date||''' AND '''||v_to_date||'''';
  
  
  v_sql_qury:=v_sql_qury||v_sql_str;
  

   if sear_tab.count is not null then
     case  sear_tab.count when 1 then open result_set for v_sql_qury using  sear_tab(1); 
                          when 2 then open result_set for v_sql_qury using  sear_tab(1),sear_tab(2);
                          when 3 then open result_set for v_sql_qury using  sear_tab(1),sear_tab(2),sear_tab(3); 
                          when 4 then open result_set for v_sql_qury using  sear_tab(1),sear_tab(2),sear_tab(3),sear_tab(4); 
                          when 5 then open result_set for v_sql_qury using  sear_tab(1),sear_tab(2),sear_tab(3),sear_tab(4),sear_tab(5); 
                          when 6 then open result_set for v_sql_qury using  sear_tab(1),sear_tab(2),sear_tab(3),sear_tab(4),sear_tab(5),sear_tab(6); 
                          
      else                      
     open result_set for v_sql_qury; 
     end case;
   end if;
 end if; 
  
END Claims_Outstanding_report;    
--============================================================================================================ 
---Added newly for CR-0264
--- Added by Venu Babu on (02-04-2019)
--===============================================================================================================
PROCEDURE claims_routine_report(
     where_clause              IN  VARCHAR2,
     v_result_set              OUT SYS_REFCURSOR
  )
  IS
    str_tab                ttk_util_pkg.str_table_type;
    v_sql_stmt             VARCHAR2(32000);
    v_date_cond            VARCHAR2(200) ; 
    v_from_date            DATE;
    v_to_date              DATE;
    v_sql_str              VARCHAR2(32000);
    v_where                VARCHAR2(4000);
    v_claim_type           VARCHAR2(30);
    v_payment_status       VARCHAR2(30);
    v_provider             NUMBER(30);
    v_corporate            VARCHAR2(30);
    v_search_base          VARCHAR2(10);
 
     
  BEGIN
  
    str_tab     := ttk_util_pkg.parse_str ( where_clause );
   
   v_sql_str:='SELECT 
                       k.group_name as Corporate_Name,
                       h.policy_number,
                       to_char(h.effective_from_date,''dd/mm/yyyy'') as policy_start_date,
                       to_char(h.effective_to_date,''dd/mm/yyyy'') as policy_end_date ,
                       d.tpa_enrollment_id as alkootid, 
                       eng.insured_name as principal_name,
                       d.mem_name as member_name,
                       n.relship_description as relation,
                       pi.partner_name as name_of_partner,
                       ho.hosp_name as name_of_provider,
                       ho.empanel_number as empanelment_id,
                       d.invoice_number,
                       to_char(d.date_of_hospitalization,''dd/mm/yyyy'') as dt_of_admission,
                       to_char(d.date_of_discharge,''dd/mm/yyyy'') as dt_of_discharge,
                       CASE WHEN d.claim_type=''CTM'' THEN ''Member''
                            WHEN d.claim_type=''CNH'' THEN ''Network'' else null end as claim_type,
                       clmb.batch_no as claim_batch_no,
                       to_char(d.clm_received_date,''dd/mm/yyyy'') as claim_received_date,
                       to_char(d.added_date,''dd/mm/yyyy'') as claim_added_date,
                       d.claim_number,
                       d.requested_amount as total_claimed_amt,
                       d.req_amt_currency_type as incurred_currency,
                       d.converted_amount as total_claim_amount_qar,
                       d.conversion_rate,
                       gene.description as claim_status,
                       to_char(d.completed_date,''dd/mm/yyyy'') as completed_date,
                       d.settlement_number as claim_settlement_no,
                       d.final_app_amount as amount_payable_qar,
                       d.converted_final_approved_amt as amount_payable_icur,
                       nvl(d.pay_amt_in_usd,(d.final_app_amount/3.64)) as amount_payable_usd,
                       CASE WHEN a.claim_payment_status=''SENT_TO_BANK'' THEN ''Approved By Finance'' ELSE a.claim_payment_status END as finance_status,
                       trunc(sysdate-d.clm_received_date) as ageing_as_per_rec_date,
                       trunc(sysdate-d.completed_date) as ageing_as_per_apr_date,
                       case when a.claim_type=''CTM'' then
                           case when nvl(clmb.claimfrom_gentype_id,''INSU'')!=''EMBA'' then
                             (case when a.tpa_cheque_issued_general_type=''IQC'' then ttk_util_pkg.fn_decrypt(s.bank_name)
                                   when a.tpa_cheque_issued_general_type=''IQI'' then ttk_util_pkg.fn_decrypt(t.bank_name) end )
                           else
                           ttk_util_pkg.fn_decrypt(embb.bank_name)
                           end
                       else 
                         case when a.claim_type=''CNH'' then
                              (case when nvl(d.pymnt_to_type_id,''HOS'') =''PTN'' then ttk_util_pkg.fn_decrypt(pa.bank_name)
				                       else ttk_util_pkg.fn_decrypt(w.bank_name) end)
                         end 
                       end as benf_bank_name,
                       CASE WHEN a.CLAIM_TYPE=''CTM'' THEN 
                         CASE WHEN NVL(clmb.claimfrom_gentype_id,''INSU'')!=''EMBA'' THEN
                            (case when A.TPA_CHEQUE_ISSUED_GENERAL_TYPE=''IQC'' THEN 
                                    CASE WHEN s.ACCOUNT_IN_QATAR_YN=''N'' THEN ''Outside Qatar'' 
                                         when s.ACCOUNT_IN_QATAR_YN=''Y'' THEN ''Within Qatar'' 
                                    ELSE  null END
                                  when A.TPA_CHEQUE_ISSUED_GENERAL_TYPE=''IQI'' THEN 
                                    CASE WHEN t.ACCOUNT_IN_QATAR_YN=''N'' THEN ''Outside Qatar'' 
                                         when s.ACCOUNT_IN_QATAR_YN=''Y'' THEN ''Within Qatar'' 
                                    ELSE null   END 
                             END)
                         ELSE    
                           case when embb.ACCOUNT_IN_QATAR_YN=''N'' then ''Outside Qatar'' 
                                when embb.ACCOUNT_IN_QATAR_YN=''Y'' THEN ''Within Qatar'' 
                            else null end
                         END 
                       ELSE
                       CASE WHEN a.CLAIM_TYPE=''CNH'' THEN   
                                 (case when NVL(d.pymnt_to_type_id,''HOS'') =''PTN'' THEN
                          CASE WHEN pa.ACCOUNT_IN_QATAR_YN=''N'' THEN ''Outside Qatar'' 
                               when pa.ACCOUNT_IN_QATAR_YN=''Y'' THEN ''Within Qatar'' 
                           ELSE NULL  END 
                         ELSE
                          CASE WHEN w.ACCOUNT_IN_QATAR_YN =''N'' THEN ''Outside Qatar'' 
                               when w.ACCOUNT_IN_QATAR_YN=''Y'' THEN ''Within Qatar'' 
                            ELSE NULL  END
                             END )
                        END END  as bank_location,
                       CASE WHEN a.CLAIM_TYPE=''CTM'' THEN 
                         CASE WHEN NVL(clmb.claimfrom_gentype_id,''INSU'')!=''EMBA'' THEN
                            (case when A.TPA_CHEQUE_ISSUED_GENERAL_TYPE=''IQC'' THEN 
                                    CASE WHEN s.ACCOUNT_IN_QATAR_YN=''N'' THEN s.CITY_TYPE_ID ELSE  corc.CITY_DESCRIPTION END
                                  when A.TPA_CHEQUE_ISSUED_GENERAL_TYPE=''IQI'' THEN 
                                    CASE WHEN t.ACCOUNT_IN_QATAR_YN=''N'' THEN t.CITY_TYPE_ID ELSE  memc.CITY_DESCRIPTION END 
                             END)
                         ELSE    
                           case when embb.ACCOUNT_IN_QATAR_YN=''N'' then embb.CITY_TYPE_ID else emci.CITY_DESCRIPTION  end
                         END 
                       ELSE
                       CASE WHEN a.CLAIM_TYPE=''CNH'' THEN   
                                 (case when NVL(d.pymnt_to_type_id,''HOS'') =''PTN'' THEN
                          CASE WHEN pa.ACCOUNT_IN_QATAR_YN=''N'' THEN paa.CITY_TYPE_ID ELSE paci.CITY_DESCRIPTION  END 
                         ELSE
                          CASE WHEN w.ACCOUNT_IN_QATAR_YN =''N'' THEN haa.CITY_TYPE_ID ELSE hosc.CITY_DESCRIPTION  END
                             END )
                            
                        END END  as bank_city,
                        CASE WHEN a.CLAIM_TYPE=''CTM'' THEN 
                         CASE WHEN NVL(clmb.claimfrom_gentype_id,''INSU'')!=''EMBA'' THEN
                            (case when A.TPA_CHEQUE_ISSUED_GENERAL_TYPE=''IQC'' THEN 
                                    cocu.COUNTRY_NAME
                                  when A.TPA_CHEQUE_ISSUED_GENERAL_TYPE=''IQI'' THEN 
                                        mecu.COUNTRY_NAME
                             END)
                         ELSE    
                                        emco.COUNTRY_NAME
                         END 
                       ELSE
                       CASE WHEN a.CLAIM_TYPE=''CNH'' THEN   
                                 (case when NVL(d.pymnt_to_type_id,''HOS'') =''PTN'' THEN
                                       pacu.COUNTRY_NAME
                         ELSE
                                       hocu.COUNTRY_NAME
                             END )
                            
                        END END  as bank_country,
                        case when a.claim_type=''CTM'' then
                           case when nvl(clmb.claimfrom_gentype_id,''INSU'')!=''EMBA'' then
                             (case when a.tpa_cheque_issued_general_type=''IQC'' then ttk_util_pkg.fn_decrypt(s.bank_account_no)
                                   when a.tpa_cheque_issued_general_type=''IQI'' then ttk_util_pkg.fn_decrypt(t.bank_account_no) end )
                           else
                           ttk_util_pkg.fn_decrypt(embb.bank_account_no)
                           end
                       else 
                         case when a.claim_type=''CNH'' then
                              (case when nvl(d.pymnt_to_type_id,''HOS'') =''PTN'' then ttk_util_pkg.fn_decrypt(pa.account_number)
				                       else ttk_util_pkg.fn_decrypt(w.account_number) end)
                         end 
                       end as cust_acc_num,
                        CASE WHEN a.CLAIM_TYPE=''CTM'' THEN
                            CASE WHEN NVL(clmb.claimfrom_gentype_id,''INSU'')!=''EMBA'' THEN
                               (case when  A.TPA_CHEQUE_ISSUED_GENERAL_TYPE=''IQC'' THEN k.GROUP_NAME  
                                     WHEN  A.TPA_CHEQUE_ISSUED_GENERAL_TYPE=''IQI'' THEN eng.insured_name
                                END )
                            ELSE
                               EMB.EMBASSY_NAME
                            END       
                         ELSE 
                       CASE WHEN a.CLAIM_TYPE=''CNH'' THEN
                            (case when NVL(d.pymnt_to_type_id,''HOS'') =''PTN'' THEN
                                  pi.partner_name
                           ELSE
                                  Ho.HOSP_NAME END)
                      END		 
                          END as benf_name,
                           case when a.claim_type=''CTM'' then
                           case when nvl(clmb.claimfrom_gentype_id,''INSU'')!=''EMBA'' then
                             (case when a.tpa_cheque_issued_general_type=''IQC'' then ttk_util_pkg.fn_decrypt(s.bank_micr)
                                   when a.tpa_cheque_issued_general_type=''IQI'' then ttk_util_pkg.fn_decrypt(t.bank_micr) end )
                           else
                           ttk_util_pkg.fn_decrypt(embb.bank_micr)
                           end
                       else 
                         case when a.claim_type=''CNH'' then
                              (case when nvl(d.pymnt_to_type_id,''HOS'') =''PTN'' then ttk_util_pkg.fn_decrypt(pa.bank_micr)
				                       else ttk_util_pkg.fn_decrypt(w.bank_micr) end)
                         end 
                       end as cust_iban_no,
                        case when a.claim_type=''CTM'' then
                           case when nvl(clmb.claimfrom_gentype_id,''INSU'')!=''EMBA'' then
                             (case when a.tpa_cheque_issued_general_type=''IQC'' then ttk_util_pkg.fn_decrypt(s.bank_ifsc)
                                   when a.tpa_cheque_issued_general_type=''IQI'' then ttk_util_pkg.fn_decrypt(t.bank_ifsc) end )
                           else
                           ttk_util_pkg.fn_decrypt(embb.bank_ifsc)
                           end
                       else 
                         case when a.claim_type=''CNH'' then
                              (case when nvl(d.pymnt_to_type_id,''HOS'') =''PTN'' then ttk_util_pkg.fn_decrypt(pa.bank_ifsc)
				                       else ttk_util_pkg.fn_decrypt(w.bank_ifsc) end)
                         end 
                       end as cust_swift_code,
                       tref.trans_num as transaction_reference_no,
                       to_char(bbat.batch_date,''dd-mm-yyyy'') as batch_date,
                       a.bank_advice_batch as finance_batch_no,
                       clmc.check_num as payment_reference_no,
                       to_char(clmc.check_date,''dd-mm-yyyy'') as check_date,
                       d.pay_amt_in_euro,
                       d.pay_amt_in_gbp,
                       case when a.claim_payment_status IN (''PENDING'',''READY_TO_BANK'') THEN 
                                 case when round(sysdate -d.clm_received_date,2) <= FA.FST_TO_DAYS THEN
                                    (a.approved_amount*nvl(fa.disc_perc,0))/100  ELSE 0 END
                            when a.claim_payment_status IN (''SENT_TO_BANK'',''PAID'') THEN a.discount_amount ELSE NULL END as discount_amount,
                       case when a.claim_payment_status IN (''PENDING'',''READY_TO_BANK'') THEN 
                                 CASE when round(sysdate -d.clm_received_date,2) <= FA.FST_TO_DAYS THEN 
                                   a.approved_amount - (a.approved_amount*nvl(fa.disc_perc,0))/100  ELSE a.approved_amount END
                            when a.claim_payment_status IN (''SENT_TO_BANK'',''PAID'') THEN a.approved_amount- nvl(a.discount_amount,0) else null end as payable_amt,
                       eng.employee_no,
                       clmf.description as claim_from,
                       CASE WHEN a.claim_type=''CTM'' THEN
                            CASE WHEN nvl(clmb.claimfrom_gentype_id,''INSU'') =''LYVR'' then 
                                  (case when D.payment_to=''IQC'' then ''Corporate''
                                    when D.payment_to=''IQI'' then ''Individual'' 
                                   end)
                                 WHEN nvl(clmb.claimfrom_gentype_id,''INSU'')!=''EMBA'' then
                                   (case when a.tpa_cheque_issued_general_type=''IQC'' then 
                                           ''Corporate''
                                        when a.tpa_cheque_issued_general_type=''IQI'' then 
                                           ''Individual'' 
                                    end)
                             ELSE
                              ''Embassy''
                              END
                        ELSE 
                      CASE WHEN a.claim_type=''CNH'' THEN
                         (CASE when nvl(d.pymnt_to_type_id,''HOS'') =''PTN'' then ''Partner''
                           ELSE ''Provider'' END)
                          END 
                       END as Payment_To
                        
                        
    FROM fin_app.tpa_claims_payment A 
          JOIN app.clm_authorization_details D ON(A.claim_seq_id = D.claim_seq_id)
          JOIN app.clm_hospital_details w ON (d.claim_seq_id = w.claim_seq_id)
          JOIN APP.clm_batch_upload_details clmb on (clmb.clm_batch_seq_id=d.clm_batch_seq_id)
          JOIN diagnosys_details dd on (d.claim_seq_id=dd.claim_seq_id AND dd.primary_ailment_yn=''Y'')
          left outer join app.tpa_icd10_master_details icd on (icd.icd_code=dd.diagnosys_code)
          join fin_app.tpa_float_account fa on (a.float_seq_id = fa.float_seq_id)
          join app.tpa_general_code gene on (d.clm_status_type_id = gene.general_type_id)
          join app.tpa_general_code gener on (d.benifit_type = gener.general_type_id)
          left outer join fin_app.tpa_payment_checks_details pay  on (a.payment_seq_id=pay.payment_seq_id and  pay.v_csr_flag=1)
          left outer join fin_app.tpa_claims_check clmc on (pay.claims_chk_seq_id=clmc.claims_chk_seq_id)
          left outer join fin_app.tpa_bank_advice_batch bbat on (a.bank_advice_batch=bbat.batch_seq_id)
          left outer join fin_app.trans_ref_table tref on (tref.batch_num=bbat.batch_seq_id and intx.fn_payee_decrypt(A.payee_name)=tref.payee_name )
          left outer join tpa_general_code clmf on (clmf.general_type_id=clmb.claimfrom_gentype_id)
          -----Corporate Bank Deatils  
          JOIN app.tpa_enr_policy H ON(H.policy_seq_id = d.policy_seq_id)
		      left outer join tpa_enr_bank_dtls S ON (H.bank_seq_id = S.bank_seq_id)
          left outer join tpa_city_code corc on (s.city_type_id=corc.city_type_id)
          left outer join tpa_country_code cocu on (cocu.country_id=s.country_type_id)
          
          ---Member Bank Details
          join tpa_enr_policy_member pm on (pm.member_seq_id=d.member_seq_id)
          JOIN tpa_enr_policy_group eng on (pm.policy_group_seq_id=eng.policy_group_seq_id)
          left outer join tpa_enr_bank_dtls T ON (eng.bank_seq_id = T.bank_seq_id)
          left outer join tpa_city_code memc on (t.city_type_id=memc.city_type_id)
          left outer join tpa_country_code mecu on (mecu.country_id=t.country_type_id)
          ------- 
          
          join tpa_relationship_code n ON (pm.relship_type_id = n.relship_type_id)
          join app.tpa_group_registration k ON (K.group_reg_seq_id = H.group_reg_seq_id)
          
          ----Hospital Bank Details
          left outer join app.tpa_hosp_info ho on (a.hosp_seq_id=ho.hosp_seq_id)
          left outer join tpa_hosp_account_details W ON(hO.hosp_seq_id=w.hosp_seq_id)
          left outer join tpa_hosp_address haa on (haa.hosp_bank_seq_id=w.hosp_bank_seq_id)
          left outer join tpa_city_code hosc on (haa.city_type_id=hosc.city_type_id)
          left outer join tpa_country_code hocu on (hocu.country_id=haa.country_id)
 
          ----Partner Bank Details
          left outer join tpa_partner_info pi ON (D.ptnr_seq_id=pi.ptnr_seq_id)
          left outer join tpa_partner_account_details pa ON (pi.ptnr_seq_id=pa.ptnr_seq_id)
          left outer join tpa_partner_address paa on (paa.ptnr_bank_seq_id=pa.ptnr_bank_seq_id)
          left outer join tpa_city_code paci on (paa.city_type_id=paci.city_type_id)
          left outer join tpa_country_code pacu on (paa.country_id=pacu.country_id) 
                                                                                  
         ----Embassy Bank Details 
          LEFT OUTER JOIN APP.tpa_enr_embassy_registration EMB ON (EMB.embassy_seq_id=D.embassy_seq_id)
          LEFT OUTER JOIN APP.tpa_enr_bank_dtls embb on (embb.bank_seq_id=emb.bank_seq_id)
          left outer join tpa_city_code emci on (embb.city_type_id=emci.city_type_id)
          left outer join tpa_country_code emco on (emco.country_id=embb.country_type_id)
            
          ----Fast track discount joinings
          LEFT OUTER JOIN app.tpa_fasttract_disc_details fa on (fa.hosp_seq_id=w.hosp_seq_id and fa.disc_mode=''FAST'' and fa.status=''ACT''
          and d.clm_received_date between fa.start_date and fa.end_date)

    WHERE a.float_seq_id ='''||str_tab(2)||'''';

    v_from_date      := (to_date(str_tab(4),'dd/mm/yyyy'));
    v_to_date        := (to_date(nvl(str_tab(5),sysdate),'dd/mm/yyyy')+1);
    v_corporate      := case when str_tab(7) is not null then str_tab(7) else null end;
    v_provider       := case when str_tab(8) is not null then str_tab(8) else null end;--str_tab(6);
    v_search_base    := str_tab(3);
    v_claim_type   	 := case when str_tab(9) is not null then str_tab(9) else null end;--str_tab(7);
    v_payment_status := case when str_tab(10) is not null then str_tab(10) else null end;--str_tab(8);
    
   if v_payment_status is not null then
      v_where:=v_where||' and  a.claim_payment_status = '''||v_payment_status||''''; 
   end if;
    
   if v_claim_type is not null then
      v_where :=v_where||'and a.claim_type = '''||v_claim_type||'''';
   end if;
   
   --Added date  -- ADD
  --Approved date -- APR
  --Received date -- REC
  --Admission date -- ADM
    
   if v_from_date is not null and v_to_date is not null and v_search_base='ADD' then
      
        v_where :=v_where||' AND d.added_date BETWEEN '''|| v_from_date ||''' AND '''|| v_to_date||'''';
     
   elsif v_from_date is not null and v_to_date is not null and v_search_base='APR' then
    
       v_where :=v_where||' AND a.claim_aprv_date BETWEEN '''|| v_from_date ||''' AND '''|| v_to_date||'''';
     
   elsif v_from_date is not null and v_to_date is not null and v_search_base='REC' then
    
       v_where :=v_where||' AND d.clm_received_date BETWEEN '''|| v_from_date ||''' AND '''|| v_to_date||'''';
     
   elsif v_from_date is not null and v_to_date is not null and v_search_base='ADM' then
    
       v_where :=v_where||' AND d.date_of_hospitalization BETWEEN '''|| v_from_date ||''' AND '''|| v_to_date||'''';
   
   end if;
    
    IF v_corporate IS NOT NULL THEN
      v_where := v_where ||' AND K.GROUP_ID= '''||v_corporate||'''';
    END IF;
    
    IF v_provider IS NOT NULL THEN
      v_where:=v_where||' AND HO.HOSP_SEQ_ID= '''||v_provider||'''';
    END IF;  
      
    v_sql_str:= v_sql_str||v_where;
    
   OPEN v_result_set FOR v_sql_str;
                  
  END  claims_routine_report;          
 --============================================================================================
 -- for claim pending summary report
 -- Cr-0298
 -----------------------------------------------------------
 PROCEDURE clm_pending_summary_report(p_search_base         IN   VARCHAR2,--|F_SID|SR_BASE|START_DATE|END_DATE|CLM_TYPE|COR_SID|PRV_SID|PTN_SID|
                                      result_network        OUT SYS_REFCURSOR,
                                      result_member         OUT SYS_REFCURSOR,
                                      result_partner        OUT SYS_REFCURSOR
                                     )IS
   
   
   v_network_str         varchar2(32767):=null;
   v_member_str          varchar2(32767):=null;
   v_partner_str         varchar2(32767):=null;
   v_where               varchar2(32767):=null;
   v_date_type           varchar2(100);
   v_from_date           date;
   v_to_date             date;
   
   str_tab                ttk_util_pkg.str_table_type;
    
   BEGIN

    str_tab := ttk_util_pkg.parse_str (p_search_base);
    v_from_date := to_date(str_tab(3),'dd/mm/yyyy');
    v_to_date   := to_date(nvl(str_tab(4),sysdate),'dd/mm/yyyy');
     
    v_date_type := case upper(str_tab(2)) when 'REC' then ' trunc(cd.clm_received_date) '
                                          when 'ADD' then ' trunc(cd.added_date) '
                                          when 'APR' then ' trunc(cp.claim_aprv_date) '
                                          when 'ADM' then ' trunc(cd.date_of_hospitalization) ' 
                   else ' trunc(cd.clm_received_date) ' end ;
    
    if upper(str_tab(5)) ='ANY' then
                    ------- for network -------
          v_network_str := 'select ''PENDING'' as claim_type ,
                                   sum(case when trunc(sysdate) - '||v_date_type||' <=15 then 1 end ) as count_claim_0_15,
                                   sum(case when trunc(sysdate) - '||v_date_type||' <=15 then cp.approved_amount end) as sum_amt_0_15,
                                   sum(case when trunc(sysdate) - '||v_date_type||' between 16 and 30 then 1 end) as count_claim_16_30,
                                   sum(case when trunc(sysdate) - '||v_date_type||' between 16 and 30 then cp.approved_amount end) as sum_amt_16_30,
                                   sum(case when trunc(sysdate) - '||v_date_type||' between 31 and 45 then 1 end)as count_claim_31_45,
                                   sum(case when trunc(sysdate) - '||v_date_type||' between 31 and 45 then cp.approved_amount end) as sum_amt_31_45,
                                   sum(case when trunc(sysdate) - '||v_date_type||' between 46 and 60 then 1 end) as count_claim_46_60,
                                   sum(case when trunc(sysdate) - '||v_date_type||' between 46 and 60 then cp.approved_amount end) as sum_amt_46_60,
                                   sum(case when trunc(sysdate) - '||v_date_type||' >60 then 1 end) as count_claim_60_above,
                                   sum(case when trunc(sysdate) - '||v_date_type||' >60 then cp.approved_amount end) as sum_amt_60_above
                              from fin_app.tpa_claims_payment cp
                              join clm_authorization_details cd on (cp.claim_seq_id = cd.claim_seq_id)
                              JOIN clm_batch_upload_details cb on (cd.clm_batch_seq_id=cb.clm_batch_seq_id)
                             where cp.float_seq_id = :str_tab_1 and cp.claim_payment_status=''PENDING''
                               and cp.deleted_yn = ''N'' and cp.claim_type=''CNH'' and nvl(cd.PYMNT_TO_TYPE_ID,''PRV'') != ''PTN''';
          
          if v_from_date is not null then
            v_network_str := v_network_str||chr(10)||' and '||v_date_type||' between '''||v_from_date||''' and '''||v_to_date||'''';
          end if;
          
          v_network_str:='select x.*,nvl(x.count_claim_0_15,0)+nvl(x.count_claim_16_30,0)+nvl(x.count_claim_31_45,0)+nvl(x.count_claim_46_60,0)+nvl(x.count_claim_60_above,0) as tot_count_clm,
                                 nvl(x.sum_amt_0_15,0)+nvl(x.sum_amt_16_30,0)+nvl(x.sum_amt_31_45,0)+nvl(x.sum_amt_46_60,0)+nvl(x.sum_amt_60_above,0) as tot_sum_amt
                           from('||v_network_str||')x';

          open  result_network for v_network_str using str_tab(1);
                       ------ for member ------
          v_member_str := 'select ''PENDING'' as claim_type ,
                                   sum(case when trunc(sysdate) - '||v_date_type||' <=3 then 1 end ) as count_claim_0_3,
                                   sum(case when trunc(sysdate) - '||v_date_type||' <=3 then cp.approved_amount end) as sum_amt_0_3,
                                   sum(case when trunc(sysdate) - '||v_date_type||' between 4 and 6 then 1 end) as count_claim_4_6,
                                   sum(case when trunc(sysdate) - '||v_date_type||' between 4 and 6 then cp.approved_amount end) as sum_amt_4_6,
                                   sum(case when trunc(sysdate) - '||v_date_type||' between 7 and 10 then 1 end)as count_claim_7_10,
                                   sum(case when trunc(sysdate) - '||v_date_type||' between 7 and 10 then cp.approved_amount end) as sum_amt_7_10,
                                   sum(case when trunc(sysdate) - '||v_date_type||' between 11 and 15 then 1 end) as count_claim_11_15,
                                   sum(case when trunc(sysdate) - '||v_date_type||' between 11 and 15 then cp.approved_amount end) as sum_amt_11_15,
                                   sum(case when trunc(sysdate) - '||v_date_type||' between 16 and 21 then 1 end) as count_claim_16_21,
                                   sum(case when trunc(sysdate) - '||v_date_type||' between 16 and 21 then cp.approved_amount end) as sum_amt_16_21,
                                   sum(case when trunc(sysdate) - '||v_date_type||' >21 then 1 end) as count_claim_21_above,
                                   sum(case when trunc(sysdate) - '||v_date_type||' >21 then cp.approved_amount end) as sum_amt_21_above
                              from fin_app.tpa_claims_payment cp
                              join clm_authorization_details cd on (cp.claim_seq_id = cd.claim_seq_id)
                              JOIN clm_batch_upload_details cb on (cd.clm_batch_seq_id=cb.clm_batch_seq_id)
                             where cp.float_seq_id = :str_tab_1 and cp.claim_payment_status=''PENDING''
                               and cp.deleted_yn = ''N'' and cp.claim_type=''CTM'' ';

          if v_from_date is not null then
            v_member_str := v_member_str||chr(10)||' and '||v_date_type||' between '''||v_from_date||''' and '''||v_to_date||'''';
          end if;
          
          v_member_str:='select x.*,nvl(x.count_claim_0_3,0)+nvl(x.count_claim_4_6,0)+nvl(x.count_claim_7_10,0)+nvl(x.count_claim_11_15,0)+nvl(x.count_claim_16_21,0)+nvl(x.count_claim_21_above,0) as tot_count_clm,
                                nvl(x.sum_amt_0_3,0)+nvl(x.sum_amt_4_6,0)+nvl(x.sum_amt_7_10,0)+nvl(x.sum_amt_11_15,0)+nvl(x.sum_amt_16_21,0)+nvl(x.sum_amt_21_above,0) as tot_sum_amt
                           from('||v_member_str||')x';

          open  result_member for v_member_str using str_tab(1);
                 ------ for partner ------
          v_partner_str := 'select ''PENDING'' as claim_type ,
                                   sum(case when trunc(sysdate) - '||v_date_type||' <=15 then 1 end ) as count_claim_0_15,
                                   sum(case when trunc(sysdate) - '||v_date_type||' <=15 then cp.approved_amount end) as sum_amt_0_15,
                                   sum(case when trunc(sysdate) - '||v_date_type||' between 16 and 30 then 1 end) as count_claim_16_30,
                                   sum(case when trunc(sysdate) - '||v_date_type||' between 16 and 30 then cp.approved_amount end) as sum_amt_16_30,
                                   sum(case when trunc(sysdate) - '||v_date_type||' between 31 and 45 then 1 end)as count_claim_31_45,
                                   sum(case when trunc(sysdate) - '||v_date_type||' between 31 and 45 then cp.approved_amount end) as sum_amt_31_45
                              from fin_app.tpa_claims_payment cp
                              join clm_authorization_details cd on (cp.claim_seq_id = cd.claim_seq_id)
                              JOIN clm_batch_upload_details cb on (cd.clm_batch_seq_id=cb.clm_batch_seq_id)
                             where cp.float_seq_id = :str_tab_1 and cp.claim_payment_status=''PENDING''
                               and cp.deleted_yn = ''N'' and cp.claim_type=''CNH'' and nvl(cd.PYMNT_TO_TYPE_ID,''PRV'') = ''PTN''';

          if v_from_date is not null then
            v_partner_str := v_partner_str||chr(10)||' and '||v_date_type||' between '''||v_from_date||''' and '''||v_to_date||'''';
          end if;
          
          v_partner_str:='select x.*,nvl(x.count_claim_0_15,0)+nvl(x.count_claim_16_30,0)+nvl(x.count_claim_31_45,0) as tot_count_clm,
                                 nvl(x.sum_amt_0_15,0)+nvl(x.sum_amt_16_30,0)+nvl(x.sum_amt_31_45,0) as tot_sum_amt
                           from('||v_partner_str||')x';
                                    
          open  result_partner for v_partner_str using str_tab(1);
                                  
    elsif upper(str_tab(5)) = 'CNH' then
                 ------- for network with hospital -------                               
          v_network_str := 'select ''PENDING'' as claim_type ,
                                   sum(case when trunc(sysdate) - '||v_date_type||' <=15 then 1 end ) as count_claim_0_15,
                                   sum(case when trunc(sysdate) - '||v_date_type||' <=15 then cp.approved_amount end) as sum_amt_0_15,
                                   sum(case when trunc(sysdate) - '||v_date_type||' between 16 and 30 then 1 end) as count_claim_16_30,
                                   sum(case when trunc(sysdate) - '||v_date_type||' between 16 and 30 then cp.approved_amount end) as sum_amt_16_30,
                                   sum(case when trunc(sysdate) - '||v_date_type||' between 31 and 45 then 1 end)as count_claim_31_45,
                                   sum(case when trunc(sysdate) - '||v_date_type||' between 31 and 45 then cp.approved_amount end) as sum_amt_31_45,
                                   sum(case when trunc(sysdate) - '||v_date_type||' between 46 and 60 then 1 end) as count_claim_46_60,
                                   sum(case when trunc(sysdate) - '||v_date_type||' between 46 and 60 then cp.approved_amount end) as sum_amt_46_60,
                                   sum(case when trunc(sysdate) - '||v_date_type||' >60 then 1 end) as count_claim_60_above,
                                   sum(case when trunc(sysdate) - '||v_date_type||' >60 then cp.approved_amount end) as sum_amt_60_above
                              from fin_app.tpa_claims_payment cp
                              join clm_authorization_details cd on (cp.claim_seq_id = cd.claim_seq_id)
                              JOIN clm_batch_upload_details cb on (cd.clm_batch_seq_id=cb.clm_batch_seq_id)
                              join clm_hospital_details ch on (ch.claim_seq_id = cd.claim_seq_id)
                             where cp.float_seq_id = :str_tab_1 and cp.claim_payment_status=''PENDING'' 
                               and cp.deleted_yn = ''N'' and cp.claim_type=''CNH'' and nvl(cd.PYMNT_TO_TYPE_ID,''PRV'') != ''PTN''';
                               
          if str_tab(7) is not null then
            v_network_str := v_network_str||chr(10)||' and ch.hosp_seq_id='||str_tab(7);
          end if;
          if v_from_date is not null then
            v_network_str := v_network_str||chr(10)||' and '||v_date_type||' between '''||v_from_date||''' and '''||v_to_date||''''; 
          end if;
            
          v_network_str:='select x.*,nvl(x.count_claim_0_15,0)+nvl(x.count_claim_16_30,0)+nvl(x.count_claim_31_45,0)+nvl(x.count_claim_46_60,0)+nvl(x.count_claim_60_above,0) as tot_count_clm,
                                 nvl(x.sum_amt_0_15,0)+nvl(x.sum_amt_16_30,0)+nvl(x.sum_amt_31_45,0)+nvl(x.sum_amt_46_60,0)+nvl(x.sum_amt_60_above,0) as tot_sum_amt
                           from('||v_network_str||')x';
                                     
          open  result_network for v_network_str using str_tab(1);
              ------- for network with partner -------
          v_partner_str := 'select ''PENDING'' as claim_type ,
                                   sum(case when trunc(sysdate) - '||v_date_type||' <=15 then 1 end ) as count_claim_0_15,
                                   sum(case when trunc(sysdate) - '||v_date_type||' <=15 then cp.approved_amount end) as sum_amt_0_15,
                                   sum(case when trunc(sysdate) - '||v_date_type||' between 16 and 30 then 1 end) as count_claim_16_30,
                                   sum(case when trunc(sysdate) - '||v_date_type||' between 16 and 30 then cp.approved_amount end) as sum_amt_16_30,
                                   sum(case when trunc(sysdate) - '||v_date_type||' between 31 and 45 then 1 end)as count_claim_31_45,
                                   sum(case when trunc(sysdate) - '||v_date_type||' between 31 and 45 then cp.approved_amount end) as sum_amt_31_45
                              from fin_app.tpa_claims_payment cp
                              join clm_authorization_details cd on (cp.claim_seq_id = cd.claim_seq_id)
                              JOIN clm_batch_upload_details cb on (cd.clm_batch_seq_id=cb.clm_batch_seq_id)
                             where cp.float_seq_id = :str_tab_1 and cp.claim_payment_status=''PENDING'' 
                               and cp.deleted_yn = ''N'' and cp.claim_type=''CNH'' and nvl(cd.PYMNT_TO_TYPE_ID,''PRV'') = ''PTN''';
          
          if str_tab(8) is not null then
            v_partner_str := v_partner_str||chr(10)||' and cd.ptnr_seq_id='||str_tab(8);
          end if;
          if v_from_date is not null then
            v_partner_str := v_partner_str||chr(10)||' and '||v_date_type||' between '''||v_from_date||''' and '''||v_to_date||''''; 
          end if;
                               
          v_partner_str:='select x.*,nvl(x.count_claim_0_15,0)+nvl(x.count_claim_16_30,0)+nvl(x.count_claim_31_45,0) as tot_count_clm,
                                 nvl(x.sum_amt_0_15,0)+nvl(x.sum_amt_16_30,0)+nvl(x.sum_amt_31_45,0) as tot_sum_amt
                           from('||v_partner_str||')x';
                             
          open  result_partner for v_partner_str using str_tab(1);
              
    elsif upper(str_tab(5)) = 'CTM' then
            ------- for member -------
          v_member_str := 'select ''PENDING'' as claim_type ,
                                   sum(case when trunc(sysdate) - '||v_date_type||' <=3 then 1 end ) as count_claim_0_3,
                                   sum(case when trunc(sysdate) - '||v_date_type||' <=3 then cp.approved_amount end) as sum_amt_0_3,
                                   sum(case when trunc(sysdate) - '||v_date_type||' between 4 and 6 then 1 end) as count_claim_4_6,
                                   sum(case when trunc(sysdate) - '||v_date_type||' between 4 and 6 then cp.approved_amount end) as sum_amt_4_6,
                                   sum(case when trunc(sysdate) - '||v_date_type||' between 7 and 10 then 1 end)as count_claim_7_10,
                                   sum(case when trunc(sysdate) - '||v_date_type||' between 7 and 10 then cp.approved_amount end) as sum_amt_7_10,
                                   sum(case when trunc(sysdate) - '||v_date_type||' between 11 and 15 then 1 end) as count_claim_11_15,
                                   sum(case when trunc(sysdate) - '||v_date_type||' between 11 and 15 then cp.approved_amount end) as sum_amt_11_15,
                                   sum(case when trunc(sysdate) - '||v_date_type||' between 16 and 21 then 1 end) as count_claim_16_21,
                                   sum(case when trunc(sysdate) - '||v_date_type||' between 16 and 21 then cp.approved_amount end) as sum_amt_16_21,
                                   sum(case when trunc(sysdate) - '||v_date_type||' >21 then 1 end) as count_claim_21_above,
                                   sum(case when trunc(sysdate) - '||v_date_type||' >21 then cp.approved_amount end) as sum_amt_21_above
                              from fin_app.tpa_claims_payment cp
                              join clm_authorization_details cd on (cp.claim_seq_id = cd.claim_seq_id)
                              JOIN clm_batch_upload_details cb on (cd.clm_batch_seq_id=cb.clm_batch_seq_id)
                              join tpa_enr_policy_member pm on (pm.member_seq_id=cd.member_seq_id)
                              join tpa_enr_policy_group pg on (pm.policy_group_seq_id=pg.policy_group_seq_id)
                              join tpa_enr_policy ep on(ep.policy_seq_id = pg.policy_seq_id)
                             where cp.float_seq_id = :str_tab_1 and cp.claim_payment_status=''PENDING'' 
                               and cp.deleted_yn = ''N'' and cp.claim_type=''CTM'' ';
                               
          if str_tab(6) is not null then
            v_member_str := v_member_str||chr(10)||' and ep.group_reg_seq_id='||str_tab(6);
          end if;
          if v_from_date is not null then
            v_member_str := v_member_str||chr(10)||' and '||v_date_type||' between '''||v_from_date||''' and '''||v_to_date||''''; 
          end if;
                               
          v_member_str:='select x.*,nvl(x.count_claim_0_3,0)+nvl(x.count_claim_4_6,0)+nvl(x.count_claim_7_10,0)+nvl(x.count_claim_11_15,0)+nvl(x.count_claim_16_21,0)+nvl(x.count_claim_21_above,0) as tot_count_clm,
                                 nvl(x.sum_amt_0_3,0)+nvl(x.sum_amt_4_6,0)+nvl(x.sum_amt_7_10,0)+nvl(x.sum_amt_11_15,0)+nvl(x.sum_amt_16_21,0)+nvl(x.sum_amt_21_above,0) as tot_sum_amt
                           from('||v_member_str||')x';
                             
          open  result_member for v_member_str using str_tab(1);
    end if;
 END clm_pending_summary_report;
----======================================================================================================
PROCEDURE audit_claim_report(v_audit_status         IN VARCHAR2,
                             v_provider_name        IN VARCHAR2,
                             v_batch_no             IN VARCHAR2,        
                             v_claim_number         IN VARCHAR2,
                             v_settlement_number    IN VARCHAR2,
                             v_member_name          IN VARCHAR2,
                             v_enrollment_id        IN VARCHAR2,
                             v_clm_status           IN VARCHAR2,
                             v_policy_number        IN VARCHAR2,
                             v_clm_recv_from_dt     IN VARCHAR2,
                             v_clm_recv_to_dt       IN VARCHAR2,
                             v_clm_proc_from_dt     IN VARCHAR2,
                             v_clm_proc_to_dt       IN VARCHAR2,
                             v_claim_type           IN VARCHAR2,
                             v_treatment_from_dt    IN VARCHAR2,
                             v_treatment_to_dt      IN VARCHAR2,
                             v_result_set           OUT SYS_REFCURSOR
                            )
AS
  TYPE str_tab IS TABLE OF VARCHAR2(250) INDEX BY BINARY_INTEGER ;
  v_sql_str            VARCHAR2(32000);
  v_where             VARCHAR2(4000);
  bind_tab            str_tab;
  i                   NUMBER := 0;
BEGIN
  
  v_sql_str:= 'WITH SEC_ICD AS(SELECT CLAIM_SEQ_ID, TO_CHAR(LISTAGG(DIAGNOSYS_CODE, '','') WITHIN GROUP(ORDER BY DIAG_SEQ_ID)) AS DIAGNOSYS_CODE,
                                      TO_CHAR(LISTAGG(LONG_DESC, '','') WITHIN GROUP(ORDER BY DIAG_SEQ_ID)) AS DIAGNOSYS_DESC
                               FROM (SELECT CL.CLAIM_SEQ_ID, ICD.DIAGNOSYS_CODE, ICD.DIAG_SEQ_ID, DIAG.LONG_DESC
                               FROM APP.DIAGNOSYS_DETAILS ICD 
                               JOIN APP.CLM_AUTHORIZATION_DETAILS CL ON CL.CLAIM_SEQ_ID = ICD.CLAIM_SEQ_ID
                               JOIN APP.TPA_ICD10_MASTER_DETAILS DIAG ON DIAG.ICD_CODE = ICD.DIAGNOSYS_CODE
                               WHERE NVL(ICD.PRIMARY_AILMENT_YN, ''N'') != ''Y''
                               ORDER BY ICD.DIAG_SEQ_ID
                              )
                              GROUP BY CLAIM_SEQ_ID
                             ),
               PROVIDER_NETWORK AS(SELECT CLAIM_SEQ_ID, TO_CHAR(LISTAGG(DESCRIPTION, '','') WITHIN GROUP(ORDER BY HOSP_NETWORK_SEQ_ID)) AS PROVIDER_NETWORK_TYPE
                                   FROM (SELECT CL.CLAIM_SEQ_ID, GC.DESCRIPTION, NT.HOSP_NETWORK_SEQ_ID
                                         FROM APP.TPA_HOSP_NETWORK NT
                                         JOIN APP.TPA_GENERAL_CODE GC ON GC.GENERAL_TYPE_ID = NT.NETWORK_TYPE
                                         JOIN APP.TPA_HOSP_INFO HOS ON HOS.HOSP_SEQ_ID = NT.HOSP_SEQ_ID
                                         JOIN APP.CLM_HOSPITAL_DETAILS CHL ON CHL.HOSP_SEQ_ID = HOS.HOSP_SEQ_ID
                                         JOIN APP.CLM_AUTHORIZATION_DETAILS CL ON CL.CLAIM_SEQ_ID = CHL.CLAIM_SEQ_ID
                                         WHERE NT.NETWORK_YN = ''Y''
                                         ORDER BY NT.HOSP_NETWORK_SEQ_ID
                                        )
                                   GROUP BY CLAIM_SEQ_ID
                                  )
               SELECT  C.INVOICE_NUMBER,
                       C.CLAIM_NUMBER,
                       P.PRE_AUTH_NUMBER,
                       CASE WHEN C.CLAIM_TYPE = ''CNH'' THEN ''Network'' ELSE ''Member'' END AS CLAIM_TYPE,
                       CASE WHEN M.GENDER_GENERAL_TYPE_ID = ''MAL'' THEN ''Male''
                            WHEN M.GENDER_GENERAL_TYPE_ID = ''FEM'' THEN ''Female''
                            WHEN M.GENDER_GENERAL_TYPE_ID = ''EUN'' THEN ''Not Disclosed''
                       END AS GENDER,
                       TO_CHAR(M.DATE_OF_INCEPTION, ''DD/MM/RRRR'') AS MEMBER_INCEPTION_DATE,
                       PO.POLICY_NUMBER,
                       TO_CHAR(PO.EFFECTIVE_FROM_DATE, ''DD/MM/RRRR'') AS POLICY_START_DATE,
                       TO_CHAR(PO.EFFECTIVE_TO_DATE, ''DD/MM/RRRR'') AS POLICY_END_DATE,
                       GR.GROUP_NAME AS CORPORATE_NAME,
                       DECODE(C.PROCESS_TYPE, ''RGL'', ''Regular'', ''DBL'', ''Direct Billing'') AS SUBMISSION_CATAGORY,
                       GR.DESCRIPTION AS CLAIM_SOURCE,
                       PA.OTHER_REMARKS AS OVERRIDE_REMARKS,
                       CASE WHEN NVL(PA.OVERRIDE_YN, ''N'') = ''Y'' THEN TO_CHAR(PA.UPDATED_DATE, ''DD/MM/RRRR'') END AS OVERRIDE_DATE,
                       TO_CHAR(C.CLM_RECEIVED_DATE, ''DD/MM/RRRR'') AS RECEIVED_DATE,
                       TO_CHAR(C.ADDED_DATE, ''DD/MM/RRRR'') AS ADDED_DATE,
                       TO_CHAR(C.COMPLETED_DATE, ''DD/MM/RRRR'') AS COMPLETED_DATE,
                       NVL(C.COMPLETED_YN, ''N'') AS CLAIM_COMPLETED_YN,
                       TO_CHAR(C.DATE_OF_HOSPITALIZATION, ''DD/MM/RRRR'') AS ADMISSION_DATE,
                       TO_CHAR(C.DATE_OF_DISCHARGE, ''DD/MM/RRRR'') AS DISCHARGE_DATE,
                       NVL(H.HOSP_NAME, CH.HOSP_NAME) AS PROVIDER_NAME,
                       E.DESCRIPTION AS ENCOUNTER_TYPE,
                       GR1.DESCRIPTION AS BENEFIT_TYPE,
                       GR2.DESCRIPTION AS CLAIM_STATUS,
                       PA.DENIAL_CODE,
                       TRIM(BOTH '';'' FROM PA.DENIAL_DESC) AS DENIAL_DESCRIPTION,
                       PA.TOOTH_NO,
                       PA.QUANTITY,
                       D.DIAGNOSYS_CODE AS PRIMARY_ICD_CODE,
                       I.LONG_DESC AS PRIMARY_ICD_DESC,
                       SI.DIAGNOSYS_CODE AS SECONDARY_ICD_CODE,
                       SI.DIAGNOSYS_DESC AS SECONDARY_ICD_DESC,
                       C.PRESENTING_COMPLAINTS,
                       PA.CODE AS ACTIVITY_CODE,
                       CASE WHEN C.BENIFIT_TYPE = ''DNTL'' THEN DNT.CDT_DESC ELSE A.ACTIVITY_DESCRIPTION END AS ACTIVITY_DESCRIPTION,
                       PA.INTERNAL_DESC AS ACTIVITY_INTERNAL_DESCRIPTION,
                       CASE WHEN C.NETWORK_YN = ''Y'' THEN NVL(PA.PROVIDER_NET_AMOUNT, PA.DISC_GROSS_AMOUNT) ELSE PA.DISC_GROSS_AMOUNT END AS REQUESTED_AMOUNT_ACTIVITY,
                       PA.GROSS_AMOUNT,
                       PA.DISCOUNT_AMOUNT,
                       PA.DISC_GROSS_AMOUNT,
                       PA.PATIENT_SHARE_AMOUNT,
                       PA.DISC_GROSS_AMOUNT - (NVL(PA.PATIENT_SHARE_AMOUNT, 0) + NVL(PA.OUT_OF_POCKET_AMOUNT, 0)) AS NET_AMOUNT,
                       CASE WHEN SIGN(PA.DISC_GROSS_AMOUNT - NVL(PA.PATIENT_SHARE_AMOUNT, 0) - PA.APPROVED_AMOUNT) = -1 THEN 0 ELSE (PA.DISC_GROSS_AMOUNT - NVL(PA.PATIENT_SHARE_AMOUNT, 0)) - PA.APPROVED_AMOUNT END AS DISALLOWED_AMOUNT,
                       PA.ALLOWED_AMOUNT,
                       PA.APPROVED_AMOUNT,
                       C.FINAL_REMARKS,
                       C.MEDICAL_OPINION_REMARKS,
                       NVL(PA.MEM_SERVICE_DESC, ''-'') AS SERVICE_DESCRIPTION,
                       PA.QUANTITY AS ACTIVITY_QUANTITY_REQ,
                       PA.APPROVD_QUANTITY AS ACTIVITY_QUANTITY_APPROVED,
                       CN.CONTACT_NAME AS DATA_ENTRY_BY,
                       CNN.CONTACT_NAME AS LAST_UPDATED_BY,
                       CON.CONTACT_NAME AS PROCESSED_BY,
                       --GN.DESCRIPTION AS PRIMARY_NETWORK_TYPE,
                       DECODE(PR.PRODUCT_CAT_TYPE_ID, ''EN'', ''Elite'', ''PE'', ''Premium'', ''PN'', ''Prime'', ''PR'', ''Prime Restructed'') AS PRIMARY_NETWORK_TYPE,
                       C.TPA_ENROLLMENT_ID AS ENROLMENT_ID,
                       M.MEM_NAME AS MEMBER_NAME,
                       RC.RELSHIP_DESCRIPTION,
                       TO_CHAR(M.MEM_DOB, ''DD/MM/RRRR'') AS DOB,
                       --TRUNC(MONTHS_BETWEEN(SYSDATE,M.MEM_DOB)/12) AS MEMBER_AGE,
                       M.MEM_AGE AS MEMBER_AGE,
                       HC.PROVIDER_NAME AS PROVIDER_CATEGORY,
                       C.SETTLEMENT_NUMBER,
                       CC.CHECK_NUM AS CHEQUE_NUMBER,
                       CC.CHECK_DATE AS CHEQUE_DATE,
                       PA.OVERRIDE_YN,
                       NVL(S.SERVICE_NAME, CASE WHEN DNT.SPECIFIC_SERVICE_CODE = ''CD'' THEN ''Dental ''||DNT.GROUP_SERVICE ELSE DNT.SPECIFIC_SERVICE_DESC END) AS SERVICE_NAME,
                       COC.COUNTRY_NAME AS PROVIDER_COUNTRY,
                       C.REQUESTED_AMOUNT AS CLM_REQUESTED_AMOUNT_QAR,
                       C.TOT_APPROVED_AMOUNT AS CLM_APPROVED_AMOUNT_QAR,
                       CASE WHEN SIGN(C.TOT_DISC_GROSS_AMOUNT - NVL(C.TOT_PATIENT_SHARE_AMOUNT, 0) - C.TOT_APPROVED_AMOUNT) = -1 THEN 0 ELSE (C.TOT_DISC_GROSS_AMOUNT - NVL(C.TOT_PATIENT_SHARE_AMOUNT, 0) - C.TOT_APPROVED_AMOUNT) END AS TOT_DISALLOWED_AMOUNT,
                       N.STATUS_DESC AS INTERNAL_REMARK_STATUS,
                       N.STATUS_DESC AS INTERNAL_REMARK_DESC,
                       C.CLINICIAN_ID,
                       NVL(CASE WHEN C.NETWORK_YN = ''Y'' THEN TP.CONTACT_NAME||DECODE(TP.CONTACT_NAME,NULL,TP.CONTACT_NAME,''(''||TP.PROFESSIONAL_ID||'')'') ELSE CH.CLINICIAN_NAME END, CH.CLINICIAN_NAME) AS CLINICIAN_NAME,
                       ATC.ACTIVITY_TYPE_CODE AS ACTIVITY_TYPE,
                       EB.SUM_INSURED,
                       EB.SUM_INSURED - NVL(EB.UTILISED_SUM_INSURED, 0) AS AVA_SUM_INSURED,
                       EB.UTILISED_SUM_INSURED,
                       DECODE(C.AUDIT_STATUS, ''CHK'', ''Checked'', ''RCR'', ''Recheck required'', ''CKD'', ''Re-Checked done'', ''Not checked'') AS AUDIT_STATUS,
                       CAD.AUDIT_REMARKS AS AUDIT_FINDINGS,
                       C.AUDIT_REMARKS AS CLAIMS_REMARKS_TO_AUDIT,
                       PA.TPA_DENIAL_CODE AS TPA_DENIAL_CODE,
                       PA.TPA_DENIAL_DESC AS TPA_DENIAL_DESC,
                       PN.PROVIDER_NETWORK_TYPE AS PROVIDER_NETWORK_CATEGORY,
                       TO_CHAR(CA.AUDIT_DATE, ''DD/MM/RRRR'') AS AUDITED_DATE
                       
                FROM APP.CLM_BATCH_UPLOAD_DETAILS CB
                JOIN APP.CLM_AUTHORIZATION_DETAILS C ON CB.CLM_BATCH_SEQ_ID = C.CLM_BATCH_SEQ_ID
                LEFT JOIN (SELECT MAX(CAD.CLM_AUDIT_SEQ_ID) AS CLM_AUDIT_SEQ_ID, CAD.CLM_SEQ_ID, CAD.AUDIT_DATE
                           FROM APP.CLM_AUDIT_DATA CAD
                           WHERE CAD.AUDIT_DATE = (SELECT MAX(CAD1.AUDIT_DATE)
                                                   FROM APP.CLM_AUDIT_DATA CAD1
                                                   WHERE CAD.CLM_SEQ_ID = CAD1.CLM_SEQ_ID
                                                  )
                           GROUP BY CAD.CLM_SEQ_ID, CAD.AUDIT_DATE
                          ) CA ON CA.CLM_SEQ_ID = C.CLAIM_SEQ_ID
                LEFT JOIN APP.CLM_AUDIT_DATA CAD ON CA.CLM_AUDIT_SEQ_ID = CAD.CLM_AUDIT_SEQ_ID
                LEFT JOIN APP.PAT_AUTHORIZATION_DETAILS P ON P.CLAIM_SEQ_ID = C.CLAIM_SEQ_ID
                LEFT JOIN APP.TPA_INTERNAL_REMARK_STAT_CODE N ON (N.STATUS_CODE_ID = C.STATUS_CODE_ID )
                JOIN APP.PAT_ACTIVITY_DETAILS PA ON PA.CLAIM_SEQ_ID = C.CLAIM_SEQ_ID
                LEFT JOIN APP.TPA_ACTIVITY_MASTER_DETAILS A ON A.ACTIVITY_CODE = PA.CODE
                LEFT JOIN APP.DENTAL_RULE_TAB DNT ON DNT.CDT_CODE = PA.CODE
                LEFT JOIN APP.TPA_ACTIVITY_TYPE_CODES ATC ON ATC.ACTIVITY_TYPE_ID = A.ACTIVITY_TYPE_SEQ_ID
                LEFT JOIN APP.TPA_SERVICE_DETAILS S ON S.SERVICE_SEQ_ID = A.SERVICE_SEQ_ID
                JOIN APP.TPA_USER_CONTACTS CN ON CN.CONTACT_SEQ_ID = C.ADDED_BY
                LEFT JOIN APP.TPA_USER_CONTACTS CNN ON CNN.CONTACT_SEQ_ID = C.UPDATED_BY
                LEFT JOIN APP.TPA_USER_CONTACTS CON ON CON.CONTACT_SEQ_ID = C.PROCESSED_BY
                JOIN APP.DIAGNOSYS_DETAILS D ON D.CLAIM_SEQ_ID = C.CLAIM_SEQ_ID AND D.PRIMARY_AILMENT_YN = ''Y''
                LEFT JOIN APP.TPA_ICD10_MASTER_DETAILS I ON I.ICD_CODE = D.DIAGNOSYS_CODE
                LEFT JOIN SEC_ICD SI ON SI.CLAIM_SEQ_ID = C.CLAIM_SEQ_ID
                LEFT JOIN PROVIDER_NETWORK PN ON PN.CLAIM_SEQ_ID = C.CLAIM_SEQ_ID
                JOIN APP.TPA_GENERAL_CODE GR ON (GR.GENERAL_TYPE_ID = CB.SOURCE_TYPE_ID AND GR.HEADER_TYPE = ''CLM_SOURCE'')
                JOIN APP.TPA_GENERAL_CODE GR1 ON (GR1.GENERAL_TYPE_ID = C.BENIFIT_TYPE AND GR1.HEADER_TYPE = ''BENIFIT_TYPE'')
                JOIN APP.TPA_GENERAL_CODE GR2 ON (GR2.GENERAL_TYPE_ID = C.CLM_STATUS_TYPE_ID AND GR2.HEADER_TYPE = ''PREAUTH_STATUS'')
                JOIN APP.TPA_ENCOUNTER_TYPE_CODES E ON (E.ENCOUNTER_SEQ_ID = C.ENCOUNTER_TYPE_ID AND E.HEADER_TYPE = ''ENCOUNTER_TYPE'')
                JOIN APP.CLM_HOSPITAL_DETAILS CH ON CH.CLAIM_SEQ_ID = C.CLAIM_SEQ_ID
                LEFT JOIN APP.TPA_HOSP_INFO H ON H.HOSP_SEQ_ID = CH.HOSP_SEQ_ID
                LEFT JOIN APP.TPA_HOSP_PROFESSIONALS TP ON (TP.PROFESSIONAL_ID = C.CLINICIAN_ID AND TP.HOSP_SEQ_ID = CH.HOSP_SEQ_ID)
                LEFT JOIN APP.TPA_HOSP_ADDRESS HD ON HD.HOSP_SEQ_ID = H.HOSP_SEQ_ID
                LEFT JOIN APP.TPA_COUNTRY_CODE COC ON COC.COUNTRY_ID = NVL(HD.COUNTRY_ID, CH.COUNTRY_TYPE_ID)
                LEFT JOIN APP.DHA_PROVIDER_TYPE HC ON (HC.PROVIDER_TYPE_ID = H.PROVIDER_TYPE_ID)
                JOIN APP.TPA_ENR_POLICY_MEMBER M ON M.MEMBER_SEQ_ID = C.MEMBER_SEQ_ID
                JOIN APP.TPA_RELATIONSHIP_CODE RC ON RC.RELSHIP_TYPE_ID = M.RELSHIP_TYPE_ID
                JOIN APP.TPA_ENR_POLICY_GROUP G ON G.POLICY_GROUP_SEQ_ID = M.POLICY_GROUP_SEQ_ID
                JOIN APP.TPA_ENR_POLICY PO ON PO.POLICY_SEQ_ID = G.POLICY_SEQ_ID
                LEFT JOIN APP.TPA_ENR_BALANCE EB ON (EB.POLICY_GROUP_SEQ_ID = G.POLICY_GROUP_SEQ_ID AND EB.MEMBER_SEQ_ID = C.MEMBER_SEQ_ID)
                JOIN APP.TPA_INS_PRODUCT PR ON PR.PRODUCT_SEQ_ID = PO.PRODUCT_SEQ_ID
                --LEFT JOIN TPA_GENERAL_CODE GN ON (GN.GENERAL_TYPE_ID = PR.PRODUCT_CAT_TYPE_ID AND GR.HEADER_TYPE = ''PROVIDER_NETWORK'')
                JOIN APP.TPA_GROUP_REGISTRATION GR ON GR.GROUP_REG_SEQ_ID = G.GROUP_REG_SEQ_ID
                LEFT JOIN APP.TPA_CLAIMS_PAYMENT CP ON CP.CLAIM_SEQ_ID = C.CLAIM_SEQ_ID
                LEFT JOIN APP.TPA_PAYMENT_CHECKS_DETAILS CD ON CD.PAYMENT_SEQ_ID = CP.PAYMENT_SEQ_ID
                LEFT JOIN APP.TPA_CLAIMS_CHECK CC ON CC.CLAIMS_CHK_SEQ_ID = CD.CLAIMS_CHK_SEQ_ID ';
              
  IF v_audit_status IS NOT NULL THEN
    v_where := v_where||' AND NVL(C.AUDIT_STATUS, ''NCH'') = :audit_status ';
    i := i+1;
    bind_tab(i) := UPPER(v_audit_status);
  END IF;
  
  IF v_provider_name IS NOT NULL THEN
    v_where := v_where||' AND H.HOSP_LICENC_NUMB = :provider_license ';
    i := i+1;
    bind_tab(i) := UPPER(v_provider_name);
  END IF;
  
  IF v_batch_no IS NOT NULL THEN
    v_where := v_where||' AND CB.BATCH_NO = :batch_no ';
    i := i+1;
    bind_tab(i) := UPPER(v_batch_no);
  END IF;
  
  IF v_claim_number IS NOT NULL THEN
    v_where := v_where||' AND C.CLAIM_NUMBER = :claim_number ';
    i := i+1;
    bind_tab(i) := UPPER(v_claim_number);
  END IF;
  
  IF v_settlement_number IS NOT NULL THEN
    v_where := v_where||' AND C.SETTLEMENT_NUMBER = :settlement_number ';
    i := i+1;
    bind_tab(i) := UPPER(v_settlement_number);
  END IF;
  
  IF v_member_name IS NOT NULL THEN
    v_where := v_where||' AND C.MEM_NAME = :member_name ';
    i := i+1;
    bind_tab(i) := UPPER(v_member_name);
  END IF;
  
  IF v_enrollment_id IS NOT NULL THEN
    --v_where := v_where||' AND C.TPA_ENROLLMENT_ID = :enrollment_id ';
    v_where := v_where||' AND C.MEMBER_SEQ_ID = (SELECT MAX(MEMBER_SEQ_ID) FROM APP.TPA_ENR_POLICY_MEMBER PM WHERE PM.TPA_ENROLLMENT_ID = :enrollment_id) ';
    i := i+1;
    bind_tab(i) := UPPER(v_enrollment_id);
  END IF;
  
  IF v_clm_status IS NOT NULL THEN
    v_where := v_where||' AND C.CLM_STATUS_TYPE_ID = :enrollment_id ';
    i := i+1;
    bind_tab(i) := UPPER(v_clm_status);
  END IF;
  
  IF v_policy_number IS NOT NULL THEN
    v_where := v_where||' AND PO.POLICY_NUMBER = :policy_number ';
    i := i+1;
    bind_tab(i) := UPPER(v_policy_number);
  END IF;
  
  -- Claim Receive Date
  IF v_clm_recv_from_dt IS NOT NULL AND v_clm_recv_to_dt IS NOT NULL THEN
    v_where := v_where||' AND TO_DATE(C.CLM_RECEIVED_DATE, ''DD/MM/RRRR'') BETWEEN :clm_recv_from_dt AND :clm_recv_to_dt ';
    i := i+1;
    bind_tab(i) := TO_DATE(v_clm_recv_from_dt, 'DD/MM/RRRR');
    i := i+1;
    bind_tab(i) := TO_DATE(v_clm_recv_to_dt, 'DD/MM/RRRR');
    
  ELSIF v_clm_recv_from_dt IS NULL AND v_clm_recv_to_dt IS NOT NULL THEN
    v_where := v_where||' AND TO_DATE(C.CLM_RECEIVED_DATE, ''DD/MM/RRRR'') BETWEEN :clm_recv_from_dt AND :clm_recv_to_dt ';
    i := i+1;
    bind_tab(i) := TO_DATE(v_clm_recv_to_dt, 'DD/MM/RRRR') - 90;
    i := i+1;
    bind_tab(i) := TO_DATE(v_clm_recv_to_dt, 'DD/MM/RRRR');
  
  ELSIF v_clm_recv_from_dt IS NOT NULL AND v_clm_recv_to_dt IS NULL THEN
    v_where := v_where||' AND TO_DATE(C.CLM_RECEIVED_DATE, ''DD/MM/RRRR'') BETWEEN :clm_recv_from_dt AND :clm_recv_to_dt ';
    i := i+1;
    bind_tab(i) := TO_DATE(v_clm_recv_from_dt, 'DD/MM/RRRR');
    i := i+1;
    bind_tab(i) := TO_DATE(v_clm_recv_from_dt, 'DD/MM/RRRR') + 90;
  END IF;
  -- Claim Process/ Completed Date
  IF v_clm_proc_from_dt IS NOT NULL AND v_clm_proc_to_dt IS NOT NULL THEN
    v_where := v_where||' AND TO_DATE(C.COMPLETED_DATE, ''DD/MM/RRRR'') BETWEEN :clm_proc_from_dt AND :clm_proc_to_dt ';
    i := i+1;
    bind_tab(i) := TO_DATE(v_clm_proc_from_dt, 'DD/MM/RRRR');
    i := i+1;
    bind_tab(i) := TO_DATE(v_clm_proc_to_dt, 'DD/MM/RRRR');
    
  ELSIF v_clm_proc_from_dt IS NULL AND v_clm_proc_to_dt IS NOT NULL THEN
    v_where := v_where||' AND TO_DATE(C.COMPLETED_DATE, ''DD/MM/RRRR'') BETWEEN :clm_proc_from_dt AND :clm_proc_to_dt ';
    i := i+1;
    bind_tab(i) := TO_DATE(v_clm_proc_to_dt, 'DD/MM/RRRR') - 90;
    i := i+1;
    bind_tab(i) := TO_DATE(v_clm_proc_to_dt, 'DD/MM/RRRR');
  
  ELSIF v_clm_proc_from_dt IS NOT NULL AND v_clm_proc_to_dt IS NULL THEN
    v_where := v_where||' AND TO_DATE(C.COMPLETED_DATE, ''DD/MM/RRRR'') BETWEEN :clm_proc_from_dt AND :clm_proc_to_dt ';
    i := i+1;
    bind_tab(i) := TO_DATE(v_clm_proc_from_dt, 'DD/MM/RRRR');
    i := i+1;
    bind_tab(i) := TO_DATE(v_clm_proc_from_dt, 'DD/MM/RRRR') + 90;
  END IF;
    
  IF v_claim_type IS NOT NULL THEN
    v_where := v_where||' AND C.CLAIM_TYPE = :claim_type ';
    i := i+1;
    bind_tab(i) := UPPER(v_claim_type);
  END IF;
  -- Hospitalization Date
  IF v_treatment_from_dt IS NOT NULL AND v_treatment_to_dt IS NOT NULL THEN
    v_where := v_where||' AND TO_DATE(C.DATE_OF_HOSPITALIZATION, ''DD/MM/RRRR'') BETWEEN :treatment_from_dt AND :treatment_to_dt ';
    i := i+1;
    bind_tab(i) := TO_DATE(v_treatment_from_dt, 'DD/MM/RRRR');
    i := i+1;
    bind_tab(i) := TO_DATE(v_treatment_to_dt, 'DD/MM/RRRR');
  
  ELSIF v_treatment_from_dt IS NOT NULL AND v_treatment_to_dt IS NULL THEN
    v_where := v_where||' AND TO_DATE(C.DATE_OF_HOSPITALIZATION, ''DD/MM/RRRR'') BETWEEN :treatment_from_dt AND :treatment_to_dt ';
    i := i+1;
    bind_tab(i) := TO_DATE(v_treatment_from_dt, 'DD/MM/RRRR');
    i := i+1;
    bind_tab(i) := TO_DATE(v_treatment_from_dt, 'DD/MM/RRRR') + 90;
   
  ELSIF v_treatment_from_dt IS NULL AND v_treatment_to_dt IS NOT NULL THEN
    v_where := v_where||' AND TO_DATE(C.DATE_OF_HOSPITALIZATION, ''DD/MM/RRRR'') BETWEEN :treatment_from_dt AND :treatment_to_dt ';
    i := i+1;
    bind_tab(i) := TO_DATE(v_treatment_to_dt, 'DD/MM/RRRR') - 90;
    i := i+1;
    bind_tab(i) := TO_DATE(v_treatment_to_dt, 'DD/MM/RRRR');
  END IF;
  
  
  IF v_where IS NOT NULL THEN
    v_where   := ' WHERE '||SUBSTR(v_where,5)|| 'ORDER BY PA.ACTIVITY_DTL_SEQ_ID';
    v_sql_str := v_sql_str ||v_where;
  END IF;
  
  
  IF bind_tab.FIRST IS NOT NULL THEN
    CASE bind_tab.COUNT
      WHEN 1  THEN OPEN v_result_set FOR v_sql_str USING bind_tab(1);
      WHEN 2  THEN OPEN v_result_set FOR v_sql_str USING bind_tab(1), bind_tab(2);
      WHEN 3  THEN OPEN v_result_set FOR v_sql_str USING bind_tab(1), bind_tab(2), bind_tab(3);
      WHEN 4  THEN OPEN v_result_set FOR v_sql_str USING bind_tab(1), bind_tab(2), bind_tab(3), bind_tab(4);
      WHEN 5  THEN OPEN v_result_set FOR v_sql_str USING bind_tab(1), bind_tab(2), bind_tab(3), bind_tab(4), bind_tab(5);
      WHEN 6  THEN OPEN v_result_set FOR v_sql_str USING bind_tab(1), bind_tab(2), bind_tab(3), bind_tab(4), bind_tab(5), bind_tab(6);
      WHEN 7  THEN OPEN v_result_set FOR v_sql_str USING bind_tab(1), bind_tab(2), bind_tab(3), bind_tab(4), bind_tab(5), bind_tab(6), bind_tab(7);
      WHEN 8  THEN OPEN v_result_set FOR v_sql_str USING bind_tab(1), bind_tab(2), bind_tab(3), bind_tab(4), bind_tab(5), bind_tab(6), bind_tab(7), bind_tab(8);
      WHEN 9  THEN OPEN v_result_set FOR v_sql_str USING bind_tab(1), bind_tab(2), bind_tab(3), bind_tab(4), bind_tab(5), bind_tab(6), bind_tab(7), bind_tab(8), bind_tab(9);
      WHEN 10 THEN OPEN v_result_set FOR v_sql_str USING bind_tab(1), bind_tab(2), bind_tab(3), bind_tab(4), bind_tab(5), bind_tab(6), bind_tab(7), bind_tab(8), bind_tab(9), bind_tab(10);
      WHEN 11 THEN OPEN v_result_set FOR v_sql_str USING bind_tab(1), bind_tab(2), bind_tab(3), bind_tab(4), bind_tab(5), bind_tab(6), bind_tab(7), bind_tab(8), bind_tab(9), bind_tab(10), bind_tab(11);
      WHEN 12 THEN OPEN v_result_set FOR v_sql_str USING bind_tab(1), bind_tab(2), bind_tab(3), bind_tab(4), bind_tab(5), bind_tab(6), bind_tab(7), bind_tab(8), bind_tab(9), bind_tab(10), bind_tab(11), bind_tab(12);
      WHEN 13 THEN OPEN v_result_set FOR v_sql_str USING bind_tab(1), bind_tab(2), bind_tab(3), bind_tab(4), bind_tab(5), bind_tab(6), bind_tab(7), bind_tab(8), bind_tab(9), bind_tab(10), bind_tab(11), bind_tab(12), bind_tab(13);
      WHEN 14 THEN OPEN v_result_set FOR v_sql_str USING bind_tab(1), bind_tab(2), bind_tab(3), bind_tab(4), bind_tab(5), bind_tab(6), bind_tab(7), bind_tab(8), bind_tab(9), bind_tab(10), bind_tab(11), bind_tab(12), bind_tab(13), bind_tab(14);
      WHEN 15 THEN OPEN v_result_set FOR v_sql_str USING bind_tab(1), bind_tab(2), bind_tab(3), bind_tab(4), bind_tab(5), bind_tab(6), bind_tab(7), bind_tab(8), bind_tab(9), bind_tab(10), bind_tab(11), bind_tab(12), bind_tab(13), bind_tab(14), bind_tab(15);
    END CASE;
  ELSE
    OPEN v_result_set FOR v_sql_str;
  END IF;
END audit_claim_report;
----======================================================================================================
PROCEDURE audit_preauth_report(v_provider_name        IN VARCHAR2,
                               v_preapproval_no       IN VARCHAR2,
                               v_authorization_no     IN VARCHAR2,
                               v_member_name          IN VARCHAR2,
                               v_enrollment_id        IN VARCHAR2,
                               v_pat_status           IN VARCHAR2,
                               v_policy_number        IN VARCHAR2,
                               v_pat_recv_from_dt     IN VARCHAR2,
                               v_pat_recv_to_dt       IN VARCHAR2,
                               v_pat_proc_from_dt     IN VARCHAR2,
                               v_pat_proc_to_dt       IN VARCHAR2,
                               v_treatment_from_dt    IN VARCHAR2,
                               v_treatment_to_dt      IN VARCHAR2,
                               v_result_set           OUT SYS_REFCURSOR
                              )
AS
  TYPE str_tab IS TABLE OF VARCHAR2(250) INDEX BY BINARY_INTEGER ;
  v_sql_str            VARCHAR2(32000);
  v_where             VARCHAR2(4000);
  bind_tab            str_tab;
  i                   NUMBER := 0;
BEGIN
 
  v_sql_str := 'WITH SEC_ICD AS(SELECT PAT_AUTH_SEQ_ID, TO_CHAR(LISTAGG(DIAGNOSYS_CODE, '','') WITHIN GROUP(ORDER BY DIAG_SEQ_ID)) AS DIAGNOSYS_CODE,
                                       TO_CHAR(LISTAGG(LONG_DESC, '','') WITHIN GROUP(ORDER BY DIAG_SEQ_ID)) AS DIAGNOSYS_DESC
                                FROM (SELECT PAT.PAT_AUTH_SEQ_ID, ICD.DIAGNOSYS_CODE, ICD.DIAG_SEQ_ID, DIAG.LONG_DESC
                                      FROM APP.DIAGNOSYS_DETAILS ICD 
                                      JOIN APP.PAT_AUTHORIZATION_DETAILS PAT ON PAT.PAT_AUTH_SEQ_ID = ICD.PAT_AUTH_SEQ_ID
                                      JOIN APP.TPA_ICD10_MASTER_DETAILS DIAG ON DIAG.ICD_CODE = ICD.DIAGNOSYS_CODE
                                      WHERE NVL(ICD.PRIMARY_AILMENT_YN, ''N'') != ''Y''
                                      ORDER BY ICD.DIAG_SEQ_ID
                                     )
                               GROUP BY PAT_AUTH_SEQ_ID
                              ),
                  PROVIDER_NETWORK AS(SELECT PAT_AUTH_SEQ_ID, TO_CHAR(LISTAGG(DESCRIPTION, '','') WITHIN GROUP(ORDER BY HOSP_NETWORK_SEQ_ID)) AS PROVIDER_NETWORK_TYPE
                                      FROM (SELECT PA.PAT_AUTH_SEQ_ID, GC.DESCRIPTION, NT.HOSP_NETWORK_SEQ_ID
                                            FROM APP.TPA_HOSP_NETWORK NT
                                            JOIN APP.TPA_GENERAL_CODE GC ON GC.GENERAL_TYPE_ID = NT.NETWORK_TYPE
                                            JOIN APP.TPA_HOSP_INFO HOS ON HOS.HOSP_SEQ_ID = NT.HOSP_SEQ_ID
                                            JOIN APP.PAT_AUTHORIZATION_DETAILS PA ON PA.HOSP_SEQ_ID = HOS.HOSP_SEQ_ID
                                            WHERE NT.NETWORK_YN = ''Y''
                                            ORDER BY NT.HOSP_NETWORK_SEQ_ID
                                           )
                                     GROUP BY PAT_AUTH_SEQ_ID
                                     )

                SELECT P.PRE_AUTH_NUMBER,
                       C.CLAIM_NUMBER,
                       TO_CHAR(M.DATE_OF_INCEPTION, ''DD/MM/RRRR'') AS MEMBER_INCEPTION_DATE,
                       PO.POLICY_NUMBER,
                       TO_CHAR(PO.EFFECTIVE_FROM_DATE, ''DD/MM/RRRR'') AS POLICY_START_DATE,
                       TO_CHAR(PO.EFFECTIVE_TO_DATE, ''DD/MM/RRRR'') AS POLICY_END_DATE,
                       R.GROUP_NAME AS CORPORATE_NAME,
                       GC.DESCRIPTION AS SOURCE_TYPE,
                       TO_CHAR(P.PAT_RECEIVED_DATE, ''DD/MM/RRRR'') AS PREAUTH_RECEIVED_DATE,
                       TO_CHAR(P.UPDATED_DATE, ''DD/MM/RRRR'') AS LAST_UPDATED_DATE,
                       TO_CHAR(P.COMPLETED_DATE, ''DD/MM/RRRR'') AS PREAUTH_COMPLETED_DATE,
                       H.HOSP_NAME AS PROVIDER_NAME,
                       E.DESCRIPTION AS ENCOUNTER_TYPE,
                       GR1.DESCRIPTION AS BENEFIT_TYPE,
                       TO_CHAR(P.OVERRIDE_DATE, ''DD/MM/RRRR'') AS OVERRIDE_DATE,
                       P.OVERRIDE_REMARKS,
                       PA.DENIAL_CODE,
                       PA.DENIAL_DESC AS DENIAL_DESCRIPTION,
                       PA.TOOTH_NO,
                       PA.QUANTITY,
                       DECODE(P.PAT_STATUS_TYPE_ID, ''APR'', ''Approved'', ''INP'', ''In-Progress'', ''REJ'', ''Rejected'', ''PCN'', ''Cancelled'', ''PCO'', ''Closed'', ''REQ'', ''Required Information'') AS PA_STATUS,
                       D.DIAGNOSYS_CODE AS PRIMARY_ICD_CODE,
                       IC.LONG_DESC AS PRIMARY_ICD_DESC,
                       SI.DIAGNOSYS_CODE AS SECONDARY_ICD_CODE,
                       SI.DIAGNOSYS_DESC AS SECONDARY_ICD_DESC,
                       ATC.ACTIVITY_TYPE_CODE AS ACTIVITY_TYPE,
                       PA.CODE AS ACTIVITY_CODE,
                       T.ACTIVITY_DESCRIPTION AS ACTIVITY_DESCRIPTION,
                       PA.INTERNAL_DESC AS ACTIVITY_INTERNAL_DESCRIPTION,
                       PA.DISC_GROSS_AMOUNT AS REQUESTED_AMOUNT_ACTIVITY,
                       PA.GROSS_AMOUNT,
                       PA.DISCOUNT_AMOUNT,
                       PA.DISC_GROSS_AMOUNT,
                       PA.PATIENT_SHARE_AMOUNT,
                       PA.DISC_GROSS_AMOUNT - (NVL(PA.PATIENT_SHARE_AMOUNT, 0) + NVL(PA.OUT_OF_POCKET_AMOUNT, 0)) AS NET_AMOUNT,
                       CASE WHEN SIGN(PA.DISC_GROSS_AMOUNT - NVL(PA.PATIENT_SHARE_AMOUNT, 0) - PA.APPROVED_AMOUNT) = -1 THEN 0 ELSE (PA.DISC_GROSS_AMOUNT - NVL(PA.PATIENT_SHARE_AMOUNT, 0) - PA.APPROVED_AMOUNT) END AS DISALLOWED_AMOUNT,
                       PA.ALLOWED_AMOUNT,
                       PA.APPROVED_AMOUNT,
                       P.REQUESTED_AMOUNT AS PA_REQ_AMOUNT_QAR,
                       P.TOT_APPROVED_AMOUNT AS PA_APPROVED_AMOUNT_QAR,
                       CASE WHEN SIGN(P.TOT_DISC_GROSS_AMOUNT - NVL(P.TOT_PATIENT_SHARE_AMOUNT, 0) - P.TOT_APPROVED_AMOUNT) = -1 THEN 0 ELSE (P.TOT_DISC_GROSS_AMOUNT - NVL(P.TOT_PATIENT_SHARE_AMOUNT, 0) - P.TOT_APPROVED_AMOUNT) END AS TOT_DISALLOWED_AMOUNT,
                       C.REQUESTED_AMOUNT AS CLM_REQUESTED_AMOUNT_QAR,
                       C.TOT_APPROVED_AMOUNT AS CLM_APPROVED_AMOUNT_QAR,
                       CN.CONTACT_NAME AS ASSIGNED_TO,
                       CN.CONTACT_NAME AS LAST_UPDATED_BY,
                       CON.CONTACT_NAME AS PROCESSED_BY,
                       P.TPA_ENROLLMENT_ID AS ENROLMENT_ID,
                       P.MEM_NAME AS MEMBER_NAME,
                       RC.RELSHIP_DESCRIPTION,
                       M.MEM_AGE AS MEMBER_AGE,
                       CASE WHEN M.GENDER_GENERAL_TYPE_ID = ''MAL'' THEN ''Male''
                            WHEN M.GENDER_GENERAL_TYPE_ID = ''FEM'' THEN ''Female''
                            WHEN M.GENDER_GENERAL_TYPE_ID = ''EUN'' THEN ''Not Disclosed''
                       END AS GENDER,
                       HC.PROVIDER_NAME AS PROVIDER_CATEGORY,
                       PA.OVERRIDE_YN,
                       NVL(S.SERVICE_NAME, CASE WHEN DNT.SPECIFIC_SERVICE_CODE = ''CD'' THEN ''Dental ''||DNT.GROUP_SERVICE ELSE DNT.SPECIFIC_SERVICE_DESC END) AS SERVICE_NAME,
                       PA.QUANTITY AS ACTIVITY_QUANTITY_REQ,
                       PA.APPROVD_QUANTITY AS ACTIVITY_QUANTITY_APPROVED,
                       P.MEDICAL_OPINION_REMARKS,
                       P.CLINICIAN_ID,
                       NVL(CASE WHEN NVL(P.NETWORK_YN,''N'')=''Y'' THEN THP.CONTACT_NAME||DECODE(THP.CONTACT_NAME,NULL,THP.CONTACT_NAME,''(''||THP.PROFESSIONAL_ID||'')'') ELSE ND.CLINICIAN_NAME END,ND.CLINICIAN_NAME) AS CLINICIAN_NAME,
                       PA.TPA_DENIAL_CODE AS TPA_DENIAL_CODE,
                       PA.TPA_DENIAL_DESC AS TPA_DENIAL_DESC,
                       PN.PROVIDER_NETWORK_TYPE AS PROVIDER_NETWORK_CATEGORY,
                       EB.SUM_INSURED,
                       EB.SUM_INSURED - NVL(EB.UTILISED_SUM_INSURED, 0) AS AVA_SUM_INSURED,
                       EB.UTILISED_SUM_INSURED
                       
                       
                FROM APP.PAT_AUTHORIZATION_DETAILS P
                LEFT JOIN APP.PAT_ACTIVITY_DETAILS PA ON PA.PAT_AUTH_SEQ_ID = P.PAT_AUTH_SEQ_ID
                LEFT JOIN APP.DENTAL_RULE_TAB DNT ON DNT.CDT_CODE = PA.CODE
                JOIN APP.DIAGNOSYS_DETAILS D ON D.PAT_AUTH_SEQ_ID = P.PAT_AUTH_SEQ_ID AND D.PRIMARY_AILMENT_YN = ''Y''
                JOIN APP.TPA_ICD10_MASTER_DETAILS IC ON IC.ICD_CODE = D.DIAGNOSYS_CODE
                LEFT JOIN APP.CLM_AUTHORIZATION_DETAILS C ON C.CLAIM_SEQ_ID = P.CLAIM_SEQ_ID
                LEFT JOIN SEC_ICD SI ON SI.PAT_AUTH_SEQ_ID = P.PAT_AUTH_SEQ_ID
                JOIN APP.TPA_ENR_POLICY_MEMBER M ON M.MEMBER_SEQ_ID = P.MEMBER_SEQ_ID
                JOIN APP.TPA_ENR_POLICY_GROUP G ON G.POLICY_GROUP_SEQ_ID = M.POLICY_GROUP_SEQ_ID
                LEFT JOIN APP.TPA_ENR_BALANCE EB ON (EB.POLICY_GROUP_SEQ_ID = G.POLICY_GROUP_SEQ_ID AND EB.MEMBER_SEQ_ID = P.MEMBER_SEQ_ID)
                JOIN APP.TPA_ENR_POLICY PO ON PO.POLICY_SEQ_ID = P.POLICY_SEQ_ID
                JOIN APP.TPA_INS_PRODUCT PR ON PR.PRODUCT_SEQ_ID = PO.PRODUCT_SEQ_ID
                JOIN APP.TPA_GROUP_REGISTRATION R ON R.GROUP_REG_SEQ_ID = G.GROUP_REG_SEQ_ID
                JOIN APP.TPA_GENERAL_CODE GC ON GC.GENERAL_TYPE_ID = P.SOURCE_TYPE_ID AND GC.HEADER_TYPE = ''PAT_SOURCE''
                JOIN APP.TPA_HOSP_INFO H ON H.HOSP_SEQ_ID = P.HOSP_SEQ_ID
                LEFT JOIN PROVIDER_NETWORK PN ON PN.PAT_AUTH_SEQ_ID = P.PAT_AUTH_SEQ_ID
                JOIN APP.DHA_PROVIDER_TYPE HC ON (HC.PROVIDER_TYPE_ID = H.PROVIDER_TYPE_ID)
                JOIN APP.TPA_ENCOUNTER_TYPE_CODES E ON (E.ENCOUNTER_SEQ_ID = P.ENCOUNTER_TYPE_ID AND E.HEADER_TYPE = ''ENCOUNTER_TYPE'')
                JOIN APP.TPA_GENERAL_CODE GR1 ON (GR1.GENERAL_TYPE_ID = P.BENIFIT_TYPE AND GR1.HEADER_TYPE = ''BENIFIT_TYPE'')
                LEFT JOIN APP.TPA_ACTIVITY_MASTER_DETAILS T ON T.ACTIVITY_CODE = PA.CODE
                LEFT JOIN APP.TPA_ACTIVITY_TYPE_CODES ATC ON ATC.ACTIVITY_TYPE_SEQ_ID = T.ACTIVITY_TYPE_SEQ_ID
                LEFT JOIN APP.TPA_SERVICE_DETAILS S ON S.SERVICE_SEQ_ID = T.SERVICE_SEQ_ID
                JOIN APP.TPA_USER_CONTACTS CN ON CN.CONTACT_SEQ_ID = NVL(P.UPDATED_BY, P.ADDED_BY)
                JOIN APP.TPA_USER_CONTACTS CON ON CON.CONTACT_SEQ_ID = P.PROCESSED_BY
                JOIN APP.TPA_RELATIONSHIP_CODE RC ON RC.RELSHIP_TYPE_ID = M.RELSHIP_TYPE_ID
                LEFT JOIN APP.TPA_HOSP_PROFESSIONALS THP ON ((P.CLINICIAN_ID=THP.PROFESSIONAL_ID) AND P.HOSP_SEQ_ID = THP.HOSP_SEQ_ID)
                LEFT JOIN APP.PAT_NON_NETWORK_DETAILS ND ON ND.PAT_AUTH_SEQ_ID=P.PAT_AUTH_SEQ_ID ';
                
  IF v_provider_name IS NOT NULL THEN
    v_where := v_where||' AND H.HOSP_LICENC_NUMB = :provider_licence ';
    i := i+1;
    bind_tab(i) := UPPER(v_provider_name);
  END IF;
  
  IF v_preapproval_no IS NOT NULL THEN
    v_where := v_where||' AND P.PRE_AUTH_NUMBER = :preapproval_no ';
    i := i+1;
    bind_tab(i) := UPPER(v_preapproval_no);
  END IF;
  
  IF v_authorization_no IS NOT NULL THEN
    v_where := v_where||' AND P.AUTH_NUMBER = :authorization_no ';
    i := i+1;
    bind_tab(i) := UPPER(v_authorization_no);
  END IF;
  
  IF v_member_name IS NOT NULL THEN
    v_where := v_where||' AND P.MEM_NAME = :member_name ';
    i := i+1;
    bind_tab(i) := UPPER(v_member_name);
  END IF;
  
  IF v_enrollment_id IS NOT NULL THEN
    v_where := v_where||' AND P.TPA_ENROLLMENT_ID = :enrollment_id ';
    i := i+1;
    bind_tab(i) := UPPER(v_enrollment_id);
  END IF;
  
  IF v_pat_status IS NOT NULL THEN
    v_where := v_where||' AND P.PAT_STATUS_TYPE_ID = :pat_status ';
    i := i+1;
    bind_tab(i) := UPPER(v_pat_status);
  END IF;
  
  IF v_policy_number IS NOT NULL THEN
    v_where := v_where||' AND PO.POLICY_NUMBER = :policy_number ';
    i := i+1;
    bind_tab(i) := UPPER(v_policy_number);
  END IF;
  
  -- Preauth Receive Date
  IF v_pat_recv_from_dt IS NOT NULL AND v_pat_recv_to_dt IS NOT NULL THEN
    v_where := v_where||' AND TO_DATE(P.PAT_RECEIVED_DATE, ''DD/MM/RRRR'') BETWEEN :pat_recv_from_dt AND :pat_recv_to_dt ';
    i := i+1;
    bind_tab(i) := TO_DATE(v_pat_recv_from_dt, 'DD/MM/RRRR');
    i := i+1;
    bind_tab(i) := TO_DATE(v_pat_recv_to_dt, 'DD/MM/RRRR');
    
  ELSIF v_pat_recv_from_dt IS NULL AND v_pat_recv_to_dt IS NOT NULL THEN
    v_where := v_where||' AND TO_DATE(P.PAT_RECEIVED_DATE, ''DD/MM/RRRR'') BETWEEN :pat_recv_from_dt AND :pat_recv_to_dt ';
    i := i+1;
    bind_tab(i) := TO_DATE(v_pat_recv_to_dt, 'DD/MM/RRRR') - 90;
    i := i+1;
    bind_tab(i) := TO_DATE(v_pat_recv_to_dt, 'DD/MM/RRRR');
  
  ELSIF v_pat_recv_from_dt IS NOT NULL AND v_pat_recv_to_dt IS NULL THEN
    v_where := v_where||' AND TO_DATE(P.PAT_RECEIVED_DATE, ''DD/MM/RRRR'') BETWEEN :pat_recv_from_dt AND :pat_recv_to_dt ';
    i := i+1;
    bind_tab(i) := TO_DATE(v_pat_recv_from_dt, 'DD/MM/RRRR');
    i := i+1;
    bind_tab(i) := TO_DATE(v_pat_recv_from_dt, 'DD/MM/RRRR') + 90;
  END IF;
  
  -- Claim Process/ Completed Date
  IF v_pat_proc_from_dt IS NOT NULL AND v_pat_proc_to_dt IS NOT NULL THEN
    v_where := v_where||' AND TO_DATE(P.COMPLETED_DATE, ''DD/MM/RRRR'') BETWEEN :pat_proc_from_dt AND :pat_proc_to_dt ';
    i := i+1;
    bind_tab(i) := TO_DATE(v_pat_proc_from_dt, 'DD/MM/RRRR');
    i := i+1;
    bind_tab(i) := TO_DATE(v_pat_proc_to_dt, 'DD/MM/RRRR');
    
  ELSIF v_pat_proc_from_dt IS NULL AND v_pat_proc_to_dt IS NOT NULL THEN
    v_where := v_where||' AND TO_DATE(P.COMPLETED_DATE, ''DD/MM/RRRR'') BETWEEN :pat_proc_from_dt AND :pat_proc_to_dt ';
    i := i+1;
    bind_tab(i) := TO_DATE(v_pat_proc_to_dt, 'DD/MM/RRRR') - 90;
    i := i+1;
    bind_tab(i) := TO_DATE(v_pat_proc_to_dt, 'DD/MM/RRRR');
  
  ELSIF v_pat_proc_from_dt IS NOT NULL AND v_pat_proc_to_dt IS NULL THEN
    v_where := v_where||' AND TO_DATE(P.COMPLETED_DATE, ''DD/MM/RRRR'') BETWEEN :pat_proc_from_dt AND :pat_proc_to_dt ';
    i := i+1;
    bind_tab(i) := TO_DATE(v_pat_proc_from_dt, 'DD/MM/RRRR');
    i := i+1;
    bind_tab(i) := TO_DATE(v_pat_proc_from_dt, 'DD/MM/RRRR') + 90;
  END IF;
  
  -- Hospitalization Date
  IF v_treatment_from_dt IS NOT NULL AND v_treatment_to_dt IS NOT NULL THEN
    v_where := v_where||' AND TO_DATE(P.HOSPITALIZATION_DATE, ''DD/MM/RRRR'') BETWEEN :treatment_from_dt AND :treatment_to_dt ';
    i := i+1;
    bind_tab(i) := TO_DATE(v_treatment_from_dt, 'DD/MM/RRRR');
    i := i+1;
    bind_tab(i) := TO_DATE(v_treatment_to_dt, 'DD/MM/RRRR');
  
  ELSIF v_treatment_from_dt IS NOT NULL AND v_treatment_to_dt IS NULL THEN
    v_where := v_where||' AND TO_DATE(P.HOSPITALIZATION_DATE, ''DD/MM/RRRR'') BETWEEN :treatment_from_dt AND :treatment_to_dt ';
    i := i+1;
    bind_tab(i) := TO_DATE(v_treatment_from_dt, 'DD/MM/RRRR');
    i := i+1;
    bind_tab(i) := TO_DATE(v_treatment_from_dt, 'DD/MM/RRRR') + 90;
   
  ELSIF v_treatment_from_dt IS NULL AND v_treatment_to_dt IS NOT NULL THEN
    v_where := v_where||' AND TO_DATE(P.HOSPITALIZATION_DATE, ''DD/MM/RRRR'') BETWEEN :treatment_from_dt AND :treatment_to_dt ';
    i := i+1;
    bind_tab(i) := TO_DATE(v_treatment_to_dt, 'DD/MM/RRRR') - 90;
    i := i+1;
    bind_tab(i) := TO_DATE(v_treatment_to_dt, 'DD/MM/RRRR');
  END IF;
  
  IF v_where IS NOT NULL THEN
    v_where   := ' WHERE '||SUBSTR(v_where,5)|| 'ORDER BY PA.ACTIVITY_DTL_SEQ_ID';
    v_sql_str := v_sql_str ||v_where;
  END IF;
  
  
  IF bind_tab.FIRST IS NOT NULL THEN
    CASE bind_tab.COUNT
      WHEN 1  THEN OPEN v_result_set FOR v_sql_str USING bind_tab(1);
      WHEN 2  THEN OPEN v_result_set FOR v_sql_str USING bind_tab(1), bind_tab(2);
      WHEN 3  THEN OPEN v_result_set FOR v_sql_str USING bind_tab(1), bind_tab(2), bind_tab(3);
      WHEN 4  THEN OPEN v_result_set FOR v_sql_str USING bind_tab(1), bind_tab(2), bind_tab(3), bind_tab(4);
      WHEN 5  THEN OPEN v_result_set FOR v_sql_str USING bind_tab(1), bind_tab(2), bind_tab(3), bind_tab(4), bind_tab(5);
      WHEN 6  THEN OPEN v_result_set FOR v_sql_str USING bind_tab(1), bind_tab(2), bind_tab(3), bind_tab(4), bind_tab(5), bind_tab(6);
      WHEN 7  THEN OPEN v_result_set FOR v_sql_str USING bind_tab(1), bind_tab(2), bind_tab(3), bind_tab(4), bind_tab(5), bind_tab(6), bind_tab(7);
      WHEN 8  THEN OPEN v_result_set FOR v_sql_str USING bind_tab(1), bind_tab(2), bind_tab(3), bind_tab(4), bind_tab(5), bind_tab(6), bind_tab(7), bind_tab(8);
      WHEN 9  THEN OPEN v_result_set FOR v_sql_str USING bind_tab(1), bind_tab(2), bind_tab(3), bind_tab(4), bind_tab(5), bind_tab(6), bind_tab(7), bind_tab(8), bind_tab(9);
      WHEN 10 THEN OPEN v_result_set FOR v_sql_str USING bind_tab(1), bind_tab(2), bind_tab(3), bind_tab(4), bind_tab(5), bind_tab(6), bind_tab(7), bind_tab(8), bind_tab(9), bind_tab(10);
      WHEN 11 THEN OPEN v_result_set FOR v_sql_str USING bind_tab(1), bind_tab(2), bind_tab(3), bind_tab(4), bind_tab(5), bind_tab(6), bind_tab(7), bind_tab(8), bind_tab(9), bind_tab(10), bind_tab(11);
      WHEN 12 THEN OPEN v_result_set FOR v_sql_str USING bind_tab(1), bind_tab(2), bind_tab(3), bind_tab(4), bind_tab(5), bind_tab(6), bind_tab(7), bind_tab(8), bind_tab(9), bind_tab(10), bind_tab(11), bind_tab(12);
      WHEN 13 THEN OPEN v_result_set FOR v_sql_str USING bind_tab(1), bind_tab(2), bind_tab(3), bind_tab(4), bind_tab(5), bind_tab(6), bind_tab(7), bind_tab(8), bind_tab(9), bind_tab(10), bind_tab(11), bind_tab(12), bind_tab(13);
      WHEN 14 THEN OPEN v_result_set FOR v_sql_str USING bind_tab(1), bind_tab(2), bind_tab(3), bind_tab(4), bind_tab(5), bind_tab(6), bind_tab(7), bind_tab(8), bind_tab(9), bind_tab(10), bind_tab(11), bind_tab(12), bind_tab(13), bind_tab(14);
    END CASE;
  ELSE
    OPEN v_result_set FOR v_sql_str;
  END IF;
  
END audit_preauth_report;
----======================================================================================================  
END batch_report_pkg;

/

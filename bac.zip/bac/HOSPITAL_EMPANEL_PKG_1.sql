--------------------------------------------------------
--  DDL for Package HOSPITAL_EMPANEL_PKG
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "VENUBABU"."HOSPITAL_EMPANEL_PKG" IS
  --   Author : Raghavendra M.K.
  --   Created :
  --   Project : TTK.
  --   Description :
  --   History of Changes:     Date   --   User -- Description
  --   19th-sep-2005 -- RaghavendraMk  -- Created.

  --=====================================================================================================
  --Insert a of Hospital information.
  --=====================================================================================================
   PROCEDURE pr_hospital_info_save (
    -- Key Fields
    v_hosp_seq_id                      IN OUT tpa_hosp_info.hosp_seq_id%TYPE,
    v_hosp_gnrl_seq_id                 IN OUT tpa_hosp_general_dtl.hosp_gnrl_seq_id%TYPE,
    v_addr_seq_id                      IN OUT tpa_hosp_address.addr_seq_id%TYPE,
    v_discrepancy_status               OUT VARCHAR2,
    -- SECTION: General
    v_empanel_number                   IN tpa_hosp_info.empanel_number%TYPE,
    v_empanel_type_id                  IN tpa_hosp_info.empanel_type_id%TYPE,
    v_tpa_office_seq_id                IN tpa_hosp_info.tpa_office_seq_id%TYPE,
    v_provider_general_type_id         IN tpa_hosp_info.provider_general_type_id%TYPE,
    v_tpa_regist_date                  IN tpa_hosp_info.tpa_regist_date%TYPE,
    ---------------------
    -- SECTION: Document Received Dates
    v_mou_type_id                      IN tpa_hosp_general_dtl.mou_type_id%TYPE,
    v_mou_rcvd_date                    IN tpa_hosp_general_dtl.mou_rcvd_date%TYPE,
    v_credit_period                    IN tpa_hosp_general_dtl.credit_period%TYPE,
    v_interest                         IN tpa_hosp_general_dtl.interest%TYPE,
    v_signed_date                      IN tpa_hosp_general_dtl.signed_date%TYPE,
    v_mou_sent_date                    IN tpa_hosp_general_dtl.mou_sent_date%TYPE,
    v_tariff_rcvd_date                 IN tpa_hosp_general_dtl.tariff_rcvd_date%TYPE,
    v_hosp_info_rcvd_date              IN tpa_hosp_general_dtl.hosp_info_rcvd_date%TYPE,
    v_hosp_verify_form_rcvd_date       IN tpa_hosp_general_dtl.hosp_verify_form_rcvd_date%TYPE,
    v_reg_crt_rcvd_date                IN tpa_hosp_general_dtl.reg_crt_rcvd_date%TYPE,
    ---------------------
    -- SECTION: Hospital Details
    v_hosp_name                        IN tpa_hosp_info.hosp_name%TYPE,
    v_hosp_type_id                     IN tpa_hosp_info.hosp_type_id%TYPE,
    v_hosp_regist_number               IN tpa_hosp_info.hosp_regist_number%TYPE,
    v_regist_authority                 IN tpa_hosp_info.regist_authority%TYPE,
    v_pan_number                       IN tpa_hosp_info.trade_licenc_numb%TYPE,
    v_irda_number                      IN tpa_hosp_info.hosp_licenc_numb%TYPE,
    v_rating                           IN tpa_hosp_info.rating%TYPE,
    v_int_ext_application_yn           IN tpa_hosp_info.int_ext_application_yn%TYPE,
    ---------------------
    -- SECTION: Address details
    v_address_1                        IN tpa_hosp_address.address_1%TYPE,
    v_address_2                        IN tpa_hosp_address.address_2%TYPE,
    v_address_3                        IN tpa_hosp_address.address_3%TYPE,
    v_city_type_id                     IN tpa_hosp_address.city_type_id%TYPE,
    v_state_type_id                    IN tpa_hosp_address.state_type_id%TYPE,
    v_pin_code                         IN tpa_hosp_address.pin_code%TYPE,
    v_country_id                       IN tpa_hosp_address.country_id%TYPE,
    v_std_code                         IN tpa_hosp_info.std_code%TYPE,
    v_off_phone_no_1                   IN tpa_hosp_info.off_phone_no_1%TYPE,
    v_off_phone_no_2                   IN tpa_hosp_info.off_phone_no_2%TYPE,
    v_off_fax_no                       IN tpa_hosp_info.office_fax_no%TYPE,
    v_landmarks                        IN tpa_hosp_address.landmarks%TYPE,
    v_primary_email_id                 IN tpa_hosp_info.primary_email_id%TYPE, --/ED
    v_comm_type_id                     IN tpa_hosp_info.comm_type_id%TYPE,
    v_website                          IN tpa_hosp_info.website%TYPE,
    v_internet_connect_yn              IN tpa_hosp_info.internet_connect_yn%TYPE,
    v_remarks                          IN tpa_hosp_info.remarks%TYPE,
    -- SECTION: Associated/excluded hospitals
    v_prod_policy_seq_id               IN tpa_ins_assoc_prod_hosp.prod_policy_seq_id%TYPE,
    v_status_general_type_id           IN tpa_ins_assoc_prod_hosp.status_general_type_id%TYPE,
    -- SECTION: PR_USER_LOG
    v_log_seq_id                       IN OUT tpa_hosp_log.log_seq_id%TYPE,
    v_mod_reason_type_id               IN tpa_hosp_log.mod_reason_type_id%TYPE,
    v_reference_date                   IN tpa_hosp_log.reference_date%TYPE,
    v_reference_no                     IN tpa_hosp_log.reference_no%TYPE,
    v_remarks_log                      IN tpa_hosp_log.remarks%TYPE,
    v_hosp_regist_date                 IN tpa_hosp_info.hosp_regist_date%TYPE,-- added for issue no. 285
    v_notification_general_type_id     IN tpa_hosp_info.notification_general_type_id%TYPE, --added for KOC840
    v_tan_number                       IN tpa_hosp_info.tan_number%TYPE,
    v_hosp_owner_general_type_id       IN tpa_hosp_info.hosp_owner_general_type_id%TYPE,
    v_tds_subcat_type_id               IN tpa_hosp_info.tds_subcat_type_id%TYPE,
    v_stop_preauth_yn                  IN tpa_hosp_info.stop_preauth_yn%TYPE,
    v_stop_claim_yn                    IN tpa_hosp_info.stop_claim_yn%TYPE,
    v_serv_tax_rgn_number              IN tpa_hosp_info.serv_tax_rgn_number%TYPE,
     -- SECTION: Common arguments:
    v_gipsa_ppnyn                      IN tpa_hosp_info.gipsa_ppnyn%TYPE,
    v_user_id                          IN NUMBER,
    V_CN                               IN VARCHAR2,
    V_GN                               IN VARCHAR2,
    V_SN                               IN VARCHAR2,
    V_BN                               IN VARCHAR2,
    v_provider_type_id                 IN DHA_PROVIDER_TYPE.PROVIDER_TYPE_ID%TYPE,
    v_primary_network                  IN tpa_hosp_info.primary_network%TYPE,
    v_isd_code                         IN tpa_hosp_info.isd_code%TYPE,
    v_clm_submission                   IN tpa_hosp_info.claim_submission_type%TYPE,
    v_prov_ho_yn                       IN tpa_hosp_info.provider_ho_yn%TYPE,
    v_review_yn                        IN tpa_hosp_info.review_yn%type,
    V_WN                               IN VARCHAR2,
    v_hosp_catagory                    IN tpa_hosp_info.hosp_catagory%type, --added by chiranjibi 
    --v_prov_ho_id                       IN tpa_hosp_info.provider_ho_id%TYPE,
    -- SECTION: Hospital Group:
    v_hosp_group_seq_id                IN OUT hosp_group_info.hosp_group_seq_id%TYPE,
    v_group_name                       IN hosp_group_info.group_name%TYPE,
    v_contact_person                   IN hosp_group_info.contact_person%TYPE,                                          
    v_contact_no                       IN hosp_group_info.contact_no%TYPE,
    v_email_ID                         IN hosp_group_info.email_id%TYPE,
    v_address                          IN hosp_group_info.address%TYPE,
    v_asso_payer                       IN tpa_hosp_info.asso_payer%TYPE,
    v_trade_licence_name               IN tpa_hosp_info.trade_licence_name%TYPE,
    v_bio_metric_ena_dis               IN VARCHAR2,
    v_rows_processed                   OUT NUMBER,
    ---Adding the Network types 
    v_network_type                     IN VARCHAR2, --concatenate values ||network type||yes or no values
    v_prov_limit_amt                   IN tpa_hosp_info.amount_limit%TYPE,
    V_OPTS_LIMIT                       IN tpa_hosp_info.OPTS_LIMIT%TYPE,                         
    V_OPTC_LIMIT                       IN tpa_hosp_info.OPTC_LIMIT%TYPE,
    V_DNTL_LIMIT                       IN tpa_hosp_info.DNTL_LIMIT%TYPE,
    V_OMTI_LIMIT                       IN tpa_hosp_info.OMTI_LIMIT%TYPE,
    V_CONS_FOLLOWUP_PERIOD             IN tpa_hosp_info.Cons_Followup_Period%TYPE, --- added in Free Follwup Period Cr
    v_payment_dur                      IN NUMBER,
    v_clm_sub_days                     IN tpa_hosp_info.clm_sub_days%type,
    v_clm_rsub_days                    IN tpa_hosp_info.clm_rsub_days%type,
    v_clm_sub_flag                     IN tpa_hosp_info.clm_sub_flag%type,
    v_opts_pat_limit                   IN tpa_hosp_info.opts_pat_limit%type,
    v_stop_clm_date                    IN tpa_hosp_info.stop_clm_date%TYPE,
    v_stop_pat_date                    IN tpa_hosp_info.stop_preauth_date%TYPE
  );

  --=====================================================================================================
  --to delete the hospitals.
  -- The hospital IDs of the hospitals to be deleted has to be sent concatenated with "|".
  --=====================================================================================================
  PROCEDURE pr_hospital_info_delete(v_hosp_seq_ids   IN VARCHAR2, -- Concatenated Hospital Sequence IDs.
                                    v_rows_processed OUT NUMBER);

  --=====================================================================================================
  --to update the DISCREPANCY information.
  --=====================================================================================================
  PROCEDURE pr_discrepancy_info_save(v_hosp_seq_id    IN tpa_hosp_discrepancy.hosp_seq_id%TYPE,
                                     v_action         IN VARCHAR2,
                                     v_user_id        IN NUMBER,
                                     v_rows_processed OUT NUMBER);

  --=====================================================================================================
  -- This procedure called for the screen ACCOUNTS.
  -- IMP:  There are two address sequence IDs passed here.
  -- One for PO address and another for Hospital address.
  --=====================================================================================================
  PROCEDURE pr_account_info_save(v_hosp_bank_seq_id IN OUT tpa_hosp_account_details.hosp_bank_seq_id%TYPE,
                                 v_addr_seq_id      IN OUT tpa_hosp_address.addr_seq_id%TYPE,
                                 v_po_addr_seq_id   IN OUT tpa_hosp_address.addr_seq_id%TYPE,
                                 v_hosp_seq_id      IN tpa_hosp_account_details.hosp_seq_id%TYPE,
                                 -- SECTION: Hospital Bank Account Details
                                 v_bank_name          IN tpa_hosp_account_details.bank_name%TYPE,
                                 v_account_number     IN tpa_hosp_account_details.account_number%TYPE,
                                 v_account_in_name_of IN tpa_hosp_account_details.account_in_name_of%TYPE,
                                 -- SECTION: Branch Details
                                 v_branch_seq_id   IN tpa_hosp_account_details.branch_name%TYPE,
                                 v_address_1     IN tpa_hosp_address.address_1%TYPE,
                                 v_address_2     IN tpa_hosp_address.address_2%TYPE,
                                 v_address_3     IN tpa_hosp_address.address_3%TYPE,
                                 v_city_type_id  IN tpa_hosp_address.city_type_id%TYPE,
                                 v_state_type_id IN tpa_hosp_address.state_type_id%TYPE,
                                 v_pin_code      IN tpa_hosp_address.pin_code%TYPE,
                                 v_country_id    IN tpa_hosp_address.country_id%TYPE,
                                 -- SECTION: Hospital Management Details
                                 v_management_name       IN tpa_hosp_account_details.management_name%TYPE,
                                 v_issue_cheques_type_id IN tpa_hosp_account_details.issue_cheques_type_id%TYPE,
                                 -- SECTION: Pay Order details.  -- This section is going to be an Update as some of the fields were populated in Hospital screen.
                                 v_hosp_gnrl_seq_id        IN tpa_hosp_general_dtl.hosp_gnrl_seq_id%TYPE,
                                 v_empanel_fees_chrg_yn    IN tpa_hosp_general_dtl.empanel_fees_chrg_yn%TYPE,
                                 v_pay_order_type_id       IN tpa_hosp_general_dtl.pay_order_type_id%TYPE,
                                 v_pay_order_number        IN tpa_hosp_general_dtl.pay_order_number%TYPE,
                                 v_pay_order_amount        IN tpa_hosp_general_dtl.pay_order_amount%TYPE,
                                 v_pay_order_received_date IN tpa_hosp_general_dtl.pay_order_received_date%TYPE,
                                 v_po_bank_name            IN tpa_hosp_general_dtl.bank_name%TYPE,
                                 v_check_issued_date       IN tpa_hosp_general_dtl.check_issued_date%TYPE,
                                 -- SECTION: Bank Guarantee Details
                                 v_bank_guant_seq_id IN tpa_hosp_bank_guarantee.bank_guant_seq_id%TYPE,
                                 v_empanel_seq_id    IN tpa_hosp_bank_guarantee.empanel_seq_id%TYPE,
                                 v_bank_guant_req_yn IN tpa_hosp_bank_guarantee.bank_guant_req_yn%TYPE,
                                 -- SECTION: PO address details
                                 v_po_address_1     IN tpa_hosp_address.address_1%TYPE,
                                 v_po_address_2     IN tpa_hosp_address.address_2%TYPE,
                                 v_po_address_3     IN tpa_hosp_address.address_3%TYPE,
                                 v_po_city_type_id  IN tpa_hosp_address.city_type_id%TYPE,
                                 v_po_state_type_id IN tpa_hosp_address.state_type_id%TYPE,
                                 v_po_pin_code      IN tpa_hosp_address.pin_code%TYPE,
                                 v_po_country_id    IN tpa_hosp_address.country_id%TYPE,
                                 -- SECTION: PR_USER_LOG
                                 v_log_seq_id         IN OUT tpa_hosp_log.log_seq_id%TYPE,
                                 v_mod_reason_type_id IN tpa_hosp_log.mod_reason_type_id%TYPE,
                                 v_reference_date     IN tpa_hosp_log.reference_date%TYPE,
                                 v_reference_no       IN tpa_hosp_log.reference_no%TYPE,
                                 v_remarks_log        IN tpa_hosp_log.remarks%TYPE,
                                 -- Auditing fields.
                                 v_user_id        IN NUMBER,
                                 V_START_DATE     IN DATE,
                                 V_END_DATE       IN DATE,
                                 v_IBAN_NUM       IN tpa_hosp_account_details.Bank_Ifsc%TYPE,
                                 v_SWIFT_CODE     IN tpa_hosp_account_details.bank_micr%TYPE,
                                 v_mode_of_payment                  IN tpa_hosp_account_details.mode_of_payment%TYPE,
                                 V_ACCOUNT_IN_QATAR_YN              IN VARCHAR2,          --CR0226
                                 V_OUTQTR_BANK_BRANCH               IN VARCHAR2 := NULL,  --CR0226
                                 v_account_type                     IN varchar2 :='SB',   --CR0226
                                 v_rows_processed OUT NUMBER);

  --=====================================================================================================
  -- for Insert and Updation of  Validation Information.
  --=====================================================================================================
  PROCEDURE pr_validation_save(v_validate_seq_id            IN OUT tpa_hosp_validation.validate_seq_id%TYPE,
                               v_hosp_seq_id                IN tpa_hosp_validation.hosp_seq_id%TYPE,
                               v_validation_req_yn          IN tpa_hosp_validation.validation_req_yn%TYPE,
                               v_marked_date                IN tpa_hosp_validation.marked_date%TYPE,
                               v_visit_done_yn              IN tpa_hosp_validation.visit_done_yn%TYPE,
                               v_validated_by               IN tpa_hosp_validation.validated_by%TYPE,
                               v_validated_date             IN tpa_hosp_validation.validated_date%TYPE,
                               v_report_rcvd_yn             IN tpa_hosp_validation.report_rcvd_yn%TYPE,
                               v_remarks                    IN tpa_hosp_validation.remarks%TYPE,
                               v_val_status_general_type_id IN tpa_hosp_validation.val_status_general_type_id%TYPE,
                               v_user_id                    IN NUMBER,
                               v_rows_processed             OUT NUMBER);

  --=====================================================================================================
  -- for deleting one or set of validations selected.
  -- The validation IDs should be concatenated. Delimiter is "|"
  --=====================================================================================================
  PROCEDURE pr_validation_delete(v_validate_seq_ids IN VARCHAR2, --  Concatenated IDS. Delimiter is "|".
                                 v_rows_processed   OUT NUMBER);

  --=====================================================================================================
  -- for Create and Updation of feedback and Feedback details.
  -- The Question Id adn Anawer Ids should be sent concatenated. Delimiter is "|"
  --=====================================================================================================
  PROCEDURE pr_hospital_feedback_save(v_feedback_seq_id IN OUT tpa_hosp_feedback.feedback_seq_id%TYPE,
                                      v_hosp_seq_id     IN tpa_hosp_feedback.hosp_seq_id%TYPE,
                                      v_feedback_date   IN tpa_hosp_feedback.feedback_date%TYPE,
                                      v_suggestions     IN tpa_hosp_feedback.suggestions%TYPE,
                                      v_qid_aid         IN VARCHAR2, --  Concatenated IDS. Delimiter is "|".
                                      v_user_id         IN NUMBER, --  Concatenated IDS. Delimiter is "|".
                                      v_rows_processed  OUT NUMBER);

  --=====================================================================================================
  -- for Feedback delete.
  -- The Question Id adn Anawer Ids should be sent concatenated. Delimiter is "|"
  --=====================================================================================================
  PROCEDURE pr_hospital_feedback_delete(v_feedback_seq_ids IN VARCHAR2, --  Concatenated IDS. Delimiter is "|".
                                        v_rows_processed   OUT NUMBER);

  --=====================================================================================================
  -- to change/update the Hospital Empanelment Status.
  --=====================================================================================================
  PROCEDURE pr_hospital_status_save(v_empanel_seq_id         IN tpa_hosp_empanel_status.empanel_seq_id%TYPE,
                                    v_empanel_status_type_id IN tpa_hosp_empanel_status.empanel_status_type_id%TYPE,
                                    v_empanel_rson_type_id   IN tpa_hosp_empanel_status.empanel_rson_type_id%TYPE,
                                    v_from_date              IN tpa_hosp_empanel_status.from_date%TYPE,
                                    v_to_date                IN tpa_hosp_empanel_status.to_date%TYPE,
                                    v_notified_to_tpa_acc    IN tpa_hosp_empanel_status.notified_to_tpa_acc%TYPE,
                                    v_date_of_notification   IN tpa_hosp_empanel_status.date_of_notification%TYPE,
                                    v_remarks                IN tpa_hosp_empanel_status.remarks%TYPE,
                                    v_user_id                IN NUMBER,
                                    v_rows_processed         OUT NUMBER);

  --=====================================================================================================
  -- This procedure is used to know weather DISCREPANCY check is done
  -- If done, weather discrepancy check is required or not.
  -- If this procedure returns "Y", means, discrepancy check is required.
  --=====================================================================================================
  PROCEDURE pr_discrepancy_status(v_hosp_seq_id     IN tpa_hosp_empanel_status.hosp_seq_id%TYPE,
                                  v_disc_present_yn OUT VARCHAR2);

  --=====================================================================================================
  -- save/update general grading for hospital
  -- by mamatha
  --=====================================================================================================
  PROCEDURE pr_grading_general_save(v_hosp_seq_id      IN tpa_hosp_grading.hosp_seq_id%TYPE,
                                    v_location_type_id IN tpa_hosp_grading.location_type_id%TYPE,
                                    v_category_type_id IN tpa_hosp_grading.category_type_id%TYPE,
                                    v_user_id          IN NUMBER,
                                    v_rows_processed   OUT NUMBER);

  --=====================================================================================================
  -- save/update medical services for hospital
  -- by mamatha
  --=====================================================================================================
  PROCEDURE pr_grading_medical_save(v_medical_seq_id  IN tpa_hosp_medical_details.medical_seq_id%TYPE,
                                    v_hosp_seq_id     IN tpa_hosp_medical_details.hosp_seq_id%TYPE,
                                    v_medical_type_id IN tpa_hosp_medical_details.medical_type_id%TYPE,
                                    v_value1          IN tpa_hosp_medical_details.value_1%TYPE,
                                    v_value2          IN tpa_hosp_medical_details.value_2%TYPE,
                                    v_user_id         IN NUMBER);

  --=====================================================================================================
  -- save/update infrastru for hospital
  -- by mamatha
  --=====================================================================================================
  PROCEDURE pr_grading_infrastr_save(v_infrastr_seq_id   IN tpa_hosp_infrastr_info.infrastr_seq_id%TYPE,
                                     v_hosp_seq_id       IN tpa_hosp_infrastr_info.hosp_seq_id%TYPE,
                                     v_whole_premises_yn IN tpa_hosp_infrastr_info.whole_premises_yn%TYPE,
                                     v_other_occupants   IN tpa_hosp_infrastr_info.other_occupants%TYPE,
                                     v_floor_details     IN tpa_hosp_infrastr_info.floor_details%TYPE,
                                     v_built_up_area     IN tpa_hosp_infrastr_info.built_up_area%TYPE,
                                     v_open_area         IN tpa_hosp_infrastr_info.open_area%TYPE,
                                     v_cost_of_area      IN tpa_hosp_infrastr_info.cost_of_area%TYPE,
                                     v_infra_remarks     IN tpa_hosp_infrastr_info.infra_remarks%TYPE, --added for issue 306
                                     v_user_id           IN NUMBER,
                                     v_location_type_id  IN tpa_hosp_grading.location_type_id%TYPE,
                                     v_category_type_id  IN tpa_hosp_grading.category_type_id%TYPE,
                                     v_rows_processed    OUT NUMBER);

  --=====================================================================================================
  -- save/update overriding for hospital
  -- by mamatha
  --=====================================================================================================
  PROCEDURE pr_grading_overriding_save(v_hosp_seq_id            IN tpa_hosp_grading.hosp_seq_id%TYPE,
                                       v_grade_type_id          IN tpa_hosp_grading.grade_type_id%TYPE,
                                       v_approved_by            IN tpa_hosp_grading.approved_by%TYPE,
                                       v_approved_grade_type_id IN tpa_hosp_grading.approved_grade_type_id%TYPE,
                                       v_remarks                IN tpa_hosp_grading.remarks%TYPE,
                                       v_user_id                IN NUMBER,
                                       v_rows_processed         OUT NUMBER);

  --=====================================================================================================
  -- save/update grading_hospital_save for hospital
  -- by mamatha
  --=====================================================================================================
  PROCEDURE pr_grading_hospital_save(v_hosp_seq_id    IN tpa_hosp_grading.hosp_seq_id%TYPE,
                                     v_user_id        IN NUMBER,
                                     v_rows_processed OUT NUMBER);
  --=====================================================================================================
  -- to generate empanel_number for hospital
  --=====================================================================================================
  PROCEDURE pr_generate_empanel_number(v_hosp_seq_id        IN tpa_hosp_info.hosp_seq_id%TYPE,
                                       v_empanelment_number OUT tpa_hosp_info.empanel_number%TYPE);

  --=====================================================================================================
  -- grade calculation for hospital
  --=====================================================================================================
  PROCEDURE hosp_grade_calculation(v_hosp_seq_id IN tpa_hosp_grading.hosp_seq_id%TYPE,
                                   v_grade       OUT tpa_hosp_grade_code.grade_type_id%TYPE);

  --=====================================================================================================
  -- For finding out the Grading value according to the RATIO in HOSP_GRADE_CALCULATION
  --=====================================================================================================
  PROCEDURE find_grade_value(v_val_2            IN NUMBER, --  Either Number of Beds or RATIO(Dr : Beds or Nurses : Beds)
                             v_para_val_1       IN tpa_hosp_grade_param.value_1%TYPE, --  TPA_HOSP_GRADE_PARAM value_1(For TNB )OR value_2 (For TFD a)
                             v_para_val_2       IN tpa_hosp_grade_param.value_2%TYPE, --  TPA_HOSP_GRADE_PARAM value_2(For TNB )OR value_3 (For TFD a)
                             v_point            OUT NUMBER, --  To store the Points of the Parameter.
                             v_allocated_points IN tpa_hosp_grade_param.allocated_points%TYPE, -- Prameter Point from Master Tabe.
                             v_get              OUT BOOLEAN -- Flag
                             );
  -----------------------------------------------------------------------------------
  PROCEDURE show_hosp(result_set OUT Sys_Refcursor);
  ---==================================
   PROCEDURE save_mou_docs_info(v_docs_seq_id  IN MOU_DOCS_INFO.MOU_DOC_SEQ_ID%TYPE,
                              v_hosp_seq_id    IN MOU_DOCS_INFO.hosp_seq_id%TYPE,
                              v_doc_gen_type   IN MOU_DOCS_INFO.DOCS_GENTYPE_ID%TYPE,
                              v_docs_path      IN MOU_DOCS_INFO.docs_PATH%TYPE,
                              v_file_name      IN MOU_DOCS_INFO.FILE_NAME%TYPE,
                              v_added_by       IN MOU_DOCS_INFO.added_by%TYPE,
                              v_image_file     IN MOU_DOCS_INFO.IMAGE_FILE%type,
                              v_rows_processed OUT NUMBER);
                              
                              
PROCEDURE save_mou_docs_info1(v_docs_seq_id    IN MOU_DOCS_INFO.MOU_DOC_SEQ_ID%TYPE,
                              v_pat_seq_id     IN MOU_DOCS_INFO1.Pat_Seq_Id%TYPE,
                              v_doc_gen_type   IN MOU_DOCS_INFO.DOCS_GENTYPE_ID%TYPE,
                              v_docs_path      IN MOU_DOCS_INFO.docs_PATH%TYPE,
                              v_file_name      IN MOU_DOCS_INFO.FILE_NAME%TYPE,
                              v_added_by       IN MOU_DOCS_INFO.added_by%TYPE,
                              v_image_file     IN MOU_DOCS_INFO.IMAGE_FILE%type,
                              v_hosp_seq_id    IN MOU_DOCS_INFO1.Hosp_Seq_Id%TYPE,
                              v_rows_processed OUT NUMBER);                              
  --=========================================================
  /* 
    Procedure  : save_provider_register
    Author     : Mohan RCS Technologies.
    Created On : 23/01/2015
    Description: This procedure saves Provider(hospital) Register details .
  */
  --=========================================================
  PROCEDURE save_provider_register(v_hosp_seq_id        IN OUT tpa_hosp_info.hosp_seq_id%TYPE,
                                   v_hosp_gnrl_seq_id   IN OUT tpa_hosp_general_dtl.hosp_gnrl_seq_id%TYPE,
                                   v_addr_seq_id        IN OUT tpa_hosp_address.addr_seq_id%TYPE,
                                   v_discrepancy_status OUT VARCHAR2,
                                   -- Provider General Details
                                   v_hosp_name            IN tpa_hosp_info.hosp_name%TYPE,
                                   v_hosp_speciality_type IN tpa_hosp_info.hosp_type_id%TYPE,
                                   v_trade_lice_number    IN tpa_hosp_info.trade_licenc_numb%TYPE,
                                   v_provider_type_id     IN DHA_PROVIDER_TYPE.PROVIDER_TYPE_ID%TYPE,
                                   v_regist_authority     IN tpa_hosp_info.regist_authority%TYPE,
                                   v_hosp_licence_number  IN tpa_hosp_info.hosp_licenc_numb%TYPE,
                                   ---------------------
                                   -- Provider Address details
                                   v_address_1             IN tpa_hosp_address.address_1%TYPE,
                                   v_address_2             IN tpa_hosp_address.address_2%TYPE,
                                   v_address_3             IN tpa_hosp_address.address_3%TYPE,
                                   v_city_type_id          IN tpa_hosp_address.city_type_id%TYPE,
                                   v_state_type_id         IN tpa_hosp_address.state_type_id%TYPE,
                                   v_pin_code              IN tpa_hosp_address.pin_code%TYPE,
                                   v_country_id            IN tpa_hosp_address.country_id%TYPE,
                                   v_isd_code              IN tpa_hosp_info.isd_code%TYPE,
                                   v_std_code              IN tpa_hosp_info.std_code%TYPE,
                                   v_off_phone_no_1        IN tpa_hosp_info.off_phone_no_1%TYPE,
                                   v_off_phone_no_2        IN tpa_hosp_info.off_phone_no_2%TYPE,
                                   v_off_fax_no            IN tpa_hosp_info.office_fax_no%TYPE,
                                   v_landmarks             IN tpa_hosp_address.landmarks%TYPE,
                                   v_hosp_primary_email_id IN tpa_hosp_info.primary_email_id%TYPE, --/ED
                                   v_website               IN tpa_hosp_info.website%TYPE,
                                   v_user_id               IN NUMBER,
                                   v_rows_processed        OUT NUMBER);
  ---=========================================
  PROCEDURE add_provider_facilities(v_facility         IN TPA_HOSP_MEDICAL_CODE.FACILITY_TYPE_ID%TYPE,
                                    v_medical_abb_type IN TPA_HOSP_MEDICAL_CODE.MEDICAL_TYPE_ID%TYPE,
                                    v_description      IN TPA_HOSP_MEDICAL_CODE.MEDICAL_DESCRIPTION%TYPE,
                                    v_added_by         IN TPA_HOSP_MEDICAL_CODE.added_by%TYPE,
                                    v_rows_processed   OUT NUMBER);
  --===============================================================
  procedure Dashboard_provider(v_result_set OUT SYS_REFCURSOR);
  --=================================================
 PROCEDURE save_tariff_details(V_TARIFF_SEQ_ID         IN OUT TPA_HOSP_TARIFF_DETAILS.HOSP_TARIFF_SEQ_ID%Type, --HOSP_TARIFF_SEQ_ID,INS_TARIFF_SEQ_ID,CORP_TARIFF_SEQ_ID
                               V_HOSP_licence_num      IN varchar2,
                               V_INS_ID                IN varchar2,
                               V_corp_ID               IN varchar2,
                               V_TARIFF_FLAG           IN VARCHAR2, ---HOSP,INS,CORP
                               V_PRICE_REF_NUMBER      IN OUT TPA_HOSP_TARIFF_DETAILS.Price_Ref_Number%Type,
                               V_ACTIVITY_SEQ_ID       IN TPA_HOSP_TARIFF_DETAILS.ACTIVITY_SEQ_ID%Type,
                               V_ACITIVITY_TYPE_SEQ_ID IN TPA_HOSP_TARIFF_DETAILS.ACITIVITY_TYPE_SEQ_ID%Type,
                               V_GROSS_AMOUNT          IN TPA_HOSP_TARIFF_DETAILS.GROSS_AMOUNT%Type,
                               V_DISC_AMOUNT           IN TPA_HOSP_TARIFF_DETAILS.DISC_AMOUNT%Type,
                               V_DRG_WEIGHT            IN TPA_HOSP_TARIFF_DETAILS.DRG_WEIGHT%Type,
                               V_SERVICE_SEQ_ID        IN TPA_HOSP_TARIFF_DETAILS.SERVICE_SEQ_ID%Type,
                               V_BUNDLE_ID             IN TPA_HOSP_TARIFF_DETAILS.BUNDLE_ID%Type,
                               V_PKG_ID                IN TPA_HOSP_TARIFF_DETAILS.Package_Id%Type,
                               V_START_DATE            IN TPA_HOSP_TARIFF_DETAILS.START_DATE%Type,
                               V_END_DATE              IN TPA_HOSP_TARIFF_DETAILS.END_DATE%Type,
                               V_REMARKS               IN TPA_HOSP_TARIFF_DETAILS.REMARKS%Type,
                               V_ADDED_BY              IN TPA_HOSP_TARIFF_DETAILS.ADDED_BY%Type,
                               V_INTERNAL_CODE         IN TPA_HOSP_TARIFF_DETAILS.INTERNAL_CODE%TYPE,
                               V_HOSP_ACT_DESC         IN TPA_HOSP_TARIFF_DETAILS.HOSP_ACT_DESC%Type,
                               V_NETWORK_TYPE          IN VARCHAR2,
                               V_DISC_PERCENT          IN TPA_HOSP_TARIFF_DETAILS.DISC_PERCENT%Type,
                               V_INTERNAL_DESC         IN TPA_HOSP_TARIFF_DETAILS.INTERNAL_DESC%TYPE,
                               V_PKG_SIZE              IN TPA_HOSP_TARIFF_DETAILS.PACKAGE_SIZE%TYPE,
                               V_PKG_PRICE             IN TPA_HOSP_TARIFF_DETAILS.PACKAGE_PRICE%TYPE,
                               V_ROWS_PROCESSED        OUT NUMBER);
  -----------==================================================
  FUNCTION get_tariff_assoc_id(v_flag   VARCHAR2,
                               v_value  VARCHAR2,
                               v_value1 VARCHAR2 DEFAULT NULL,
                               v_value2 varchar2 default null) RETURN VARCHAR2;
  ----------------------------
  PROCEDURE load_hosp_tariff(v_tariff_doc       XMLTYPE,
                             v_log_file      out clob);
  ----------------------------------
PROCEDURE save_hosp_professionals(V_CONTACT_SEQ_ID       IN OUT TPA_HOSP_PROFESSIONALS.CONTACT_SEQ_ID%Type,
                                  V_USER_GENERAL_TYPE_ID IN TPA_HOSP_PROFESSIONALS.USER_GENERAL_TYPE_ID%Type,
                                  V_HOSP_SEQ_ID          IN TPA_HOSP_PROFESSIONALS.HOSP_SEQ_ID%Type,
                                  V_CONTACT_NAME         IN TPA_HOSP_PROFESSIONALS.CONTACT_NAME%Type,
                                  V_PROFESSIONAL_ID      IN TPA_HOSP_PROFESSIONALS.PROFESSIONAL_ID%Type,
                                  V_PROF_AUTHORITY       IN TPA_HOSP_PROFESSIONALS.PROF_AUTHORITY%Type,
                                  V_GENDER_GENERAL_TYPE  IN TPA_HOSP_PROFESSIONALS.GENDER_GENERAL_TYPE%Type,
                                  V_AGE                  IN TPA_HOSP_PROFESSIONALS.AGE%Type,
                                  V_CONSULT_GEN_TYPE     IN TPA_HOSP_PROFESSIONALS.CONSULT_GEN_TYPE%Type,
                                  V_VALID_FROM_DATE      IN TPA_HOSP_PROFESSIONALS.VALID_FROM_DATE%Type,
                                  V_VALID_TO_DATE        IN TPA_HOSP_PROFESSIONALS.VALID_TO_DATE%Type,
                                  V_PRIMARY_EMAIL_ID     IN TPA_HOSP_PROFESSIONALS.PRIMARY_EMAIL_ID%Type,
                                  V_ACTIVE_YN            IN TPA_HOSP_PROFESSIONALS.ACTIVE_YN%Type,
                                  V_ISD_CODE             IN TPA_HOSP_PROFESSIONALS.ISD_CODE%Type,
                                  V_STD_CODE             IN TPA_HOSP_PROFESSIONALS.STD_CODE%Type,
                                  V_OFF_PHONE_NO_1       IN TPA_HOSP_PROFESSIONALS.OFF_PHONE_NO_1%Type,
                                  V_OFF_PHONE_NO_2       IN TPA_HOSP_PROFESSIONALS.OFF_PHONE_NO_2%Type,
                                  V_MOBILE_NO            IN TPA_HOSP_PROFESSIONALS.MOBILE_NO%Type,
                                  V_FAX_NO               IN TPA_HOSP_PROFESSIONALS.FAX_NO%Type,
                                  V_NATIONALITY_ID       IN TPA_HOSP_PROFESSIONALS.NATIONALITY_ID%Type,
                                  V_SPECIALITY_ID        IN TPA_HOSP_PROFESSIONALS.SPECIALITY_ID%Type,
                                  V_PROF_FILE_NAME       IN TPA_HOSP_PROFESSIONALS.PROF_FILE_NAME%Type,
                                  V_PROF_FILE            IN TPA_HOSP_PROFESSIONALS.PROF_FILE%Type,
                                  V_ADDED_BY             IN TPA_HOSP_PROFESSIONALS.ADDED_BY%Type,
                                  V_ROWS_PROCESSED       OUT NUMBER);
-----------------------------------------------------------------------------------------
 PROCEDURE hosp_docotors_upload( v_hosp_doc   clob,v_log_file  out clob);
-------------------------
 FUNCTION get_gen_codes(v_flag        VARCHAR2,
                       v_header      varchar2,
                       v_description tpa_general_code.description%type)
  RETURN VARCHAR2;
-------------------------------------
 PROCEDURE save_provider_logs(
    V_PROVIDER_LOG_SEQ_ID                IN  TPA_PROVIDER_LOGS.PROVIDER_LOG_SEQ_ID%TYPE,
    V_TPA_OFICE_SEQ_ID                   IN  TPA_PROVIDER_LOGS.TPA_OFFICE_SEQ_ID%TYPE,
    V_HOSP_SEQ_ID                        IN  TPA_PROVIDER_LOGS.HOSP_SEQ_ID%TYPE,
    V_PROFESSIONAL_ID                    IN  TPA_PROVIDER_LOGS.PROFESSIONAL_ID%TYPE,
    V_PROF_NAME                          IN  TPA_PROVIDER_LOGS.PROF_NAME%TYPE,
    V_AUTHORITY                          IN  TPA_PROVIDER_LOGS.AUTHORITY%TYPE,
    V_ERROR_NO                           IN  TPA_PROVIDER_LOGS.ERROR_NO%TYPE,
    V_ERROR_MESSAGE                      IN  TPA_PROVIDER_LOGS.ERROR_MESSAGE%TYPE,
    V_ERROR_TYPE                         IN  TPA_PROVIDER_LOGS.ERROR_TYPE%TYPE,
    V_ADDED_BY                           IN  TPA_PROVIDER_LOGS.ADDED_BY%TYPE,
    V_PROF_BATCH_SEQ_ID                  IN  NUMBER);
------------------------------------------------------
procedure get_provider_logs(v_file_id       IN  VARCHAR2,
                            V_LOGS          OUT SYS_REFCURSOR,
                            V_HOSP_NAME    OUT tpa_hosp_info.hosp_name%type);
------------------------------------------
PROCEDURE save_tariff_logs(V_TARIFF_LOG_SEQ_ID IN TPA_TARIFF_LOGS.TARIFF_LOG_SEQ_ID%TYPE,
                           V_HOSP_SEQ_ID       IN TPA_TARIFF_LOGS.HOSP_LICENCE_NUM%TYPE,
                           V_INS_SEQ_ID        IN TPA_TARIFF_LOGS.INS_ID%TYPE,
                           V_GROUP_REG_SEQ_ID  IN TPA_TARIFF_LOGS.GROUP_ID%TYPE,
                           V_ACT_CODE          IN TPA_TARIFF_LOGS.ACT_CODE%TYPE,
                           V_ERROR_NO          IN TPA_TARIFF_LOGS.ERROR_NO%TYPE,
                           V_ERROR_MESSAGE     IN TPA_TARIFF_LOGS.ERROR_MESSAGE%TYPE,
                           V_ERROR_TYPE        IN TPA_TARIFF_LOGS.ERROR_TYPE%TYPE,
                           V_ADDED_BY          IN TPA_TARIFF_LOGS.ADDED_BY%TYPE,
                           V_TPA_BATCH_SEQ_ID  IN NUMBER);
--------------------------------------------------------------
PROCEDURE select_tariff_list (
          v_tariff_flag                        IN VARCHAR2,----HOSP,INS,COR
          v_seq_id                             IN TPA_HOSP_TARIFF_DETAILS.HOSP_SEQ_ID%TYPE,--hosp_seq_id,ins_seq_id,group_reg_seq_id
          v_price_ref_no                       IN VARCHAR2,
          v_ins_seq_id                         IN NUMBER,
          v_act_code                           IN VARCHAR2,
          v_service_seq_id                     IN NUMBER,
          v_interna_code                       IN VARCHAR2,
          v_network_type                       IN VARCHAR2,  
          v_sort_var                           IN VARCHAR2,
          v_sort_order                         IN VARCHAR2,
          v_start_num                          IN NUMBER ,
          v_end_num                            IN NUMBER,
          v_added_by                           IN NUMBER,
          v_end_date                           IN VARCHAR2,
          result_set                           OUT SYS_REFCURSOR 
          );
 -------------------------------------------------------------
  PROCEDURE select_tariff_item (
    v_tariff_flag                        IN VARCHAR2,----HOSP,INS,CORP
    v_tariff_seq_id                      IN TPA_HOSP_TARIFF_DETAILS.HOSP_TARIFF_SEQ_ID%TYPE,
    v_added_by                           IN NUMBER,
    result_set                           OUT SYS_REFCURSOR
  );
 ------------------------------------------
  PROCEDURE delete_tariff_details (
   v_tariff_flag                      IN VARCHAR2,--HOSP,INS,CORP
   v_tariff_seq_id                    IN VARCHAR2 , -- Concatenated Sequence IDs.
   v_user_id                          IN NUMBER,
   v_rows_processed                   OUT NUMBER
   );
   
   ----------------------------
     PROCEDURE delete_tarrif_details(
    v_search_str             IN VARCHAR2,
    v_rows_processed         IN OUT NUMBER
  );
  --------------------
 PROCEDURE modify_service_item (
   v_tariff_flag                      IN VARCHAR2,--HOSP,INS,CORP
   v_tariff_seq_id                    IN VARCHAR2 , -- Concatenated Sequence IDs.
   v_disc_percent                     IN NUMBER,
   v_user_id                          IN NUMBER,
   v_rows_processed                   OUT NUMBER
   );
 ----------------------------------------------------------------------
PROCEDURE modify_network_service_item (
   v_tariff_flag                      IN VARCHAR2,--HOSP,INS,CORP
   v_disc_list                        IN VARCHAR2,
   v_user_id                          IN NUMBER,
   v_hosp_licence_num                 IN VARCHAR2,
   v_ins_id                           IN VARCHAR2,
   v_corp_id                          IN VARCHAR2,
   v_rows_processed                   OUT NUMBER 
   ); 
---------------------------------------------------------------------
/*PROCEDURE modify_network_service (
   v_tariff_flag                      IN VARCHAR2,--HOSP,INS,CORP
   v_service_list                     IN VARCHAR2 , -- Concatenated Sequence IDs.
   v_rows_processed                   OUT NUMBER
   ); */   
 ---------------------------------------------------
 FUNCTION FN_ASSO_PAYEER_LIST RETURN VARCHAR2; 
 FUNCTION FN_PAYEER_ID(v_ins_comp_code_number IN tpa_ins_info.ins_comp_code_number%type) RETURN NUMBER ; 
 ------------------------------------------------------------
 PROCEDURE select_hosp_professional (
    v_contact_seq_id        IN  OUT tpa_login_info.contact_seq_id%TYPE,
    user_cur                OUT SYS_REFCURSOR
  );
 ----------------------------------------------------------------------
 PROCEDURE pr_account_info_update (
    v_hosp_bank_seq_id                 IN OUT tpa_hosp_account_details.hosp_bank_seq_id%TYPE,
    v_addr_seq_id                      IN OUT tpa_hosp_address.addr_seq_id%TYPE,
    v_hosp_seq_id                      IN tpa_hosp_account_details.hosp_seq_id%TYPE,
    -- SECTION: Hospital Bank Account Details
    v_bank_name                        IN tpa_hosp_account_details.bank_name%TYPE, --/ED
    v_account_number                   IN tpa_hosp_account_details.account_number%TYPE, --/ED
    v_account_in_name_of               IN tpa_hosp_account_details.account_in_name_of%TYPE,
    -- SECTION: Branch Details
    v_branch_name                      IN tpa_hosp_account_details.branch_name%TYPE,
    v_address_1                        IN tpa_hosp_address.address_1%TYPE,
    v_address_2                        IN tpa_hosp_address.address_2%TYPE,
    v_address_3                        IN tpa_hosp_address.address_3%TYPE,
    v_city_type_id                     IN tpa_hosp_address.city_type_id%TYPE,
    v_state_type_id                    IN tpa_hosp_address.state_type_id%TYPE,
    v_pin_code                         IN tpa_hosp_address.pin_code%TYPE,
    v_country_id                       IN tpa_hosp_address.country_id%TYPE,
    -- SECTION: Hospital Management Details
    v_management_name                  IN tpa_hosp_account_details.management_name%TYPE,
    v_issue_cheques_type_id            IN tpa_hosp_account_details.issue_cheques_type_id%TYPE,
     -- SECTION: PR_USER_LOG
    v_log_seq_id                       IN OUT tpa_hosp_log.log_seq_id%TYPE,
    v_mod_reason_type_id               IN tpa_hosp_log.mod_reason_type_id%TYPE,
    v_reference_date                   IN tpa_hosp_log.reference_date%TYPE,
    v_reference_no                     IN tpa_hosp_log.reference_no%TYPE,
    v_remarks_log                      IN tpa_hosp_log.remarks%TYPE,
    -- Auditing fields.
    v_user_id                          IN NUMBER,
    V_START_DATE                       IN DATE,
    V_END_DATE                         IN DATE,
    v_IBAN_NUM                         IN tpa_hosp_account_details.Bank_Ifsc%TYPE,
    v_SWIFT_CODE                       IN tpa_hosp_account_details.bank_micr%TYPE,
    v_review_yn                        IN tpa_hosp_account_details.review_yn%type,
    v_rows_processed                   OUT NUMBER
  );
--======================================================================================
procedure tariff_network_type( v_hosp_lice_no in varchar2,
                               v_result_set out sys_refcursor);
--====================================================================================== 
/* Adding the Network type to master list  */
PROCEDURE save_Network_type ( V_DESCRIPTION             IN app.tpa_general_code.description%type,
                              V_GENERAL_TYPE_ID         IN app.tpa_general_code.general_type_id%type,
                              V_SORT_NO                 IN app.tpa_general_code.sort_no%type,
                              V_ADDED_BY                IN app.tpa_general_code.added_by%type,
                              v_rows_processed             OUT NUMBER);
--==================================================================================================                              
/* Modifying the network type master list*/

PROCEDURE modify_Network_type_mstr ( v_network_type                    IN VARCHAR2 , -- Concatenated Sequence IDs.
                                     V_ADDED_BY                        IN app.tpa_general_code.added_by%type
                                    ); 
--=========================================================================================== 
procedure save_haad_aggreed_factor( V_HAAD_AGG_SEQ_ID         IN HAAD_AGGREED_FACTOR_BSPY.haad_agg_seq_id%type,
									                  V_HOSP_SEQ_ID             IN tpa_hosp_info.hosp_seq_id%type,
									                  V_CATEGORY_TYPE_SEQ_ID    IN tpa_haad_category_type.category_type_seq_id%type,
									                  V_FACTOR                  IN HAAD_AGGREED_FACTOR_BSPY.factor%type,
									                  V_VALUE                   IN HAAD_AGGREED_FACTOR_BSPY.value%type,
									                  V_ADDED_BY                IN HAAD_AGGREED_FACTOR_BSPY.added_by%type,
                                                      V_NETWORK_TYPE            IN HAAD_AGGREED_FACTOR_BSPY.NETWORK_TYPE%TYPE
                                                     );
---=======================================================================================================================
procedure modify_haad_aggreed_factor(v_network_type           in VARCHAR2,--||
                                    V_CATEGORY_TYPE_SEQ_ID    IN VARCHAR2,--||
                                    V_FACTOR_ID               IN app.haad_generl_code.id%type,
                                    V_START_DATE              IN VARCHAR2,
                                    V_END_DATE                IN VARCHAR2,
                                    V_VALUE                   IN varchar2,
                                    V_HOSP_SEQ_ID             IN APP.HAAD_AGGREED_FACTOR_BSPY.HOSP_SEQ_ID%TYPE,
                                    V_ADDED_BY                IN app.HAAD_AGGREED_FACTOR_BSPY.added_by%type,
                                    V_RESULT_SET              OUT SYS_REFCURSOR,
                                    v_rows_processed          OUT NUMBER); 
                                    
---==========================================================================================
procedure agg_factors_bulk_update(v_hosp_seq_id             in tpa_hosp_info.hosp_seq_id%type,
                                  V_FACTOR                  IN HAAD_AGGREED_FACTOR_BSPY.factor%type,
									                V_VALUE                   IN HAAD_AGGREED_FACTOR_BSPY.value%type,
									                V_sta_date                IN varchar2,
                                  v_end_date                IN varchar2,
                                  V_NETWORK_TYPE            IN HAAD_AGGREED_FACTOR_BSPY.NETWORK_TYPE%TYPE,
                                  v_activity_type           in TPA_HAAD_CATEGORY_TYPE.Activity_Type%type,
                                  V_ADDED_BY                IN app.HAAD_AGGREED_FACTOR_BSPY.added_by%type
                                 );                                                                                                      
--===========================================================================================    

FUNCTION get_spec_codes( v_description        DHA_CLNSN_SPECIALTIES_MASTER.SPECIALTY%type)
RETURN VARCHAR2;
--===========================================================================================    
PROCEDURE dwnld_tariff(p_prov_seq_id     IN Tpa_Hosp_Info.Hosp_Seq_Id%TYPE,
                       p_resultset       OUT SYS_REFCURSOR);
--===========================================================================================
PROCEDURE load_hosp_pharmacy(v_tariff_doc       XMLTYPE,
                             v_log_file      out clob);
--===========================================================================================
PROCEDURE get_pharma_tariff_list (v_ins_seq_id                         IN NUMBER,
                                  v_seq_id                             IN TPA_HOSP_TARIFF_DETAILS.HOSP_SEQ_ID%TYPE,--hosp_seq_id,ins_seq_id,group_reg_seq_id
                                  v_price_ref_no                       IN VARCHAR2,
                                  v_act_code                           IN VARCHAR2,
                                  v_service_seq_id                     IN NUMBER,
                                  v_interna_code                       IN VARCHAR2,
                                  v_network_type                       IN VARCHAR2,  
                                  v_end_date                           IN VARCHAR2,
                                  v_sort_var                           IN VARCHAR2,
                                  v_sort_order                         IN VARCHAR2,
                                  v_start_num                          IN NUMBER ,
                                  v_end_num                            IN NUMBER,
                                  result_set                           OUT SYS_REFCURSOR
                                 );
--===========================================================================================
PROCEDURE dwnld_pharma_tariff(p_prov_seq_id     IN Tpa_Hosp_Info.Hosp_Seq_Id%TYPE,
                              p_resultset       OUT SYS_REFCURSOR);
--===========================================================================================
PROCEDURE modify_service_type(v_licence_no          IN TPA_HOSP_INFO.HOSP_LICENC_NUMB%TYPE,
                              v_ins_comp_code       IN TPA_INS_INFO.INS_COMP_CODE_NUMBER%TYPE,
                              v_network_type        IN TPA_HOSP_TARIFF_DETAILS.NETWORK_TYPE%TYPE,
                              v_flag                IN VARCHAR2,
                              v_result              OUT SYS_REFCURSOR
                             );
--===========================================================================================
PROCEDURE select_activity_list (v_act_code                 IN OUT tpa_activity_master_details.activity_code%TYPE,
                                v_description              IN OUT tpa_activity_master_details.activity_description%TYPE,
                                v_start_num                IN OUT NUMBER,
                                v_end_num                  IN OUT NUMBER,
                                v_tariff_type              IN  VARCHAR2,
                                v_result_set               OUT SYS_REFCURSOR
                               );
--===========================================================================================
PROCEDURE update_bulk_tariff(v_tariff_doc       XMLTYPE,
                             v_log_file      out clob
                            );
--===========================================================================================
PROCEDURE Tariff_updation_Log ( v_hosp_seq_id  IN  VARCHAR2,
                                v_log_type     IN   VARCHAR2,
                                v_start_date   IN   VARCHAR2,
                                v_end_date     IN   VARCHAR2,
                                v_inter_code   IN   VARCHAR2,
                                v_result_set   out   SYS_REFCURSOR);
--===========================================================================================
PROCEDURE save_fast_track_vol_base_dtls (v_disc_seq        IN   NUMBER,
                                         v_hosp_seq_id     IN   NUMBER,
                                         v_disc_mode       IN   VARCHAR2,
                                         v_fastr_from_days IN   VARCHAR2,
                                         v_fastr_to_days   IN   VARCHAR2,
                                         v_disc_type       IN   VARCHAR2,
                                         v_dis_vol_amt_st  IN   NUMBER,
                                         v_dis_vol_amt_ed  IN   NUMBER,
                                         v_disc_perc       IN   NUMBER,
                                         v_user_seq_id     IN   VARCHAR2,
                                         v_start_date      IN   VARCHAR2,
                                         v_end_date        IN   VARCHAR2,
                                         v_status          IN   VARCHAR2,
                                         v_rows_processed  OUT  NUMBER
                                         );
--===============================================================================================
PROCEDURE select_hosp_disc_details (v_hosp_seq_id    IN   NUMBER,
                                    v_disc_mode      IN   VARCHAR2,
                                    v_in_out_flag    IN   VARCHAR2,
                                    v_result         OUT  SYS_REFCURSOR
                                    );
--================================================================================================
END hospital_empanel_pkg;

/

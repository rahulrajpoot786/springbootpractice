--------------------------------------------------------
--  DDL for Synonymn FILE_CLOSE
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."FILE_CLOSE" FOR "APP"."FILE_CLOSE";

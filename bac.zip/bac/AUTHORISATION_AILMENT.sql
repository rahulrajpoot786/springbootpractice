--------------------------------------------------------
--  DDL for Synonymn AUTHORISATION_AILMENT
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."AUTHORISATION_AILMENT" FOR "APP"."AUTHORISATION_AILMENT";

--------------------------------------------------------
--  DDL for Synonymn DMS_INTERFACE_PKG
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."DMS_INTERFACE_PKG" FOR "APP"."DMS_INTERFACE_PKG";

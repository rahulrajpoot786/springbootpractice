--------------------------------------------------------
--  DDL for Synonymn AILMENT_DETAILS_SEQ
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."AILMENT_DETAILS_SEQ" FOR "APP"."AILMENT_DETAILS_SEQ";

--------------------------------------------------------
--  DDL for Synonymn CLM_REMINDER
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."CLM_REMINDER" FOR "APP"."CLM_REMINDER";

--------------------------------------------------------
--  DDL for Synonymn CLM_DOCUMENTS_RCVD_SEQ
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."CLM_DOCUMENTS_RCVD_SEQ" FOR "APP"."CLM_DOCUMENTS_RCVD_SEQ";

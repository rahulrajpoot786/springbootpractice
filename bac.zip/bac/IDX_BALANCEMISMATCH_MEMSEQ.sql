--------------------------------------------------------
--  DDL for Synonymn IDX_BALANCEMISMATCH_MEMSEQ
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."IDX_BALANCEMISMATCH_MEMSEQ" FOR "APP"."IDX_BALANCEMISMATCH_MEMSEQ";

--------------------------------------------------------
--  DDL for Synonymn CLAIMANT_PED
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."CLAIMANT_PED" FOR "APP"."CLAIMANT_PED";

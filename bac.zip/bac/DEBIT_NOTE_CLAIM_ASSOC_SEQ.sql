--------------------------------------------------------
--  DDL for Synonymn DEBIT_NOTE_CLAIM_ASSOC_SEQ
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."DEBIT_NOTE_CLAIM_ASSOC_SEQ" FOR "FIN_APP"."DEBIT_NOTE_CLAIM_ASSOC_SEQ";

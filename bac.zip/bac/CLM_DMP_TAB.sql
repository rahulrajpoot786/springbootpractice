--------------------------------------------------------
--  DDL for Synonymn CLM_DMP_TAB
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."CLM_DMP_TAB" FOR "TTKEXT"."CLM_DMP_TAB";

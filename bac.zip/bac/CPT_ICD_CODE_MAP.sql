--------------------------------------------------------
--  DDL for Synonymn CPT_ICD_CODE_MAP
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."CPT_ICD_CODE_MAP" FOR "APP"."CPT_ICD_CODE_MAP";

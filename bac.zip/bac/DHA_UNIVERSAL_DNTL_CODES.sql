--------------------------------------------------------
--  DDL for Synonymn DHA_UNIVERSAL_DNTL_CODES
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."DHA_UNIVERSAL_DNTL_CODES" FOR "APP"."DHA_UNIVERSAL_DNTL_CODES";

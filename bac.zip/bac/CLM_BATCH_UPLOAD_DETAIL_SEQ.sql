--------------------------------------------------------
--  DDL for Synonymn CLM_BATCH_UPLOAD_DETAIL_SEQ
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."CLM_BATCH_UPLOAD_DETAIL_SEQ" FOR "APP"."CLM_BATCH_UPLOAD_DETAIL_SEQ";

--------------------------------------------------------
--  DDL for Synonymn IDX_LMRP_CPT_CODE
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."IDX_LMRP_CPT_CODE" FOR "APP"."IDX_LMRP_CPT_CODE";

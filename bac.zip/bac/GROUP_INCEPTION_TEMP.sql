--------------------------------------------------------
--  DDL for Synonymn GROUP_INCEPTION_TEMP
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."GROUP_INCEPTION_TEMP" FOR "APP"."GROUP_INCEPTION_TEMP";

--------------------------------------------------------
--  DDL for Synonymn IDX_ADD_ON_ADD_ONCOL
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."IDX_ADD_ON_ADD_ONCOL" FOR "APP"."IDX_ADD_ON_ADD_ONCOL";

--------------------------------------------------------
--  DDL for Synonymn GET_COPAYMENT_LIMIT
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."GET_COPAYMENT_LIMIT" FOR "APP"."GET_COPAYMENT_LIMIT";

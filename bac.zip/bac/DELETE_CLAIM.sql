--------------------------------------------------------
--  DDL for Synonymn DELETE_CLAIM
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."DELETE_CLAIM" FOR "INTX"."DELETE_CLAIM";

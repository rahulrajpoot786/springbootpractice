--------------------------------------------------------
--  DDL for Synonymn CLM_INS_INTIMATION_DETAILS
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."CLM_INS_INTIMATION_DETAILS" FOR "APP"."CLM_INS_INTIMATION_DETAILS";

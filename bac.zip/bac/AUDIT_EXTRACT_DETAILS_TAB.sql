--------------------------------------------------------
--  DDL for Synonymn AUDIT_EXTRACT_DETAILS_TAB
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."AUDIT_EXTRACT_DETAILS_TAB" FOR "APP"."AUDIT_EXTRACT_DETAILS_TAB";

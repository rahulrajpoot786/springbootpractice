--------------------------------------------------------
--  DDL for Synonymn CLM_NUM_SEQ
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."CLM_NUM_SEQ" FOR "APP"."CLM_NUM_SEQ";

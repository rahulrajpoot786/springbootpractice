--------------------------------------------------------
--  DDL for Synonymn DHPO_PAT_TRANSACT_SEQ
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."DHPO_PAT_TRANSACT_SEQ" FOR "APP"."DHPO_PAT_TRANSACT_SEQ";

--------------------------------------------------------
--  DDL for Synonymn DHA_XML_TEST
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."DHA_XML_TEST" FOR "INTX"."DHA_XML_TEST";

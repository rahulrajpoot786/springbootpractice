--------------------------------------------------------
--  DDL for Synonymn IDX_COURIERDETAILS_DOCKETNUM
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."IDX_COURIERDETAILS_DOCKETNUM" FOR "APP"."IDX_COURIERDETAILS_DOCKETNUM";

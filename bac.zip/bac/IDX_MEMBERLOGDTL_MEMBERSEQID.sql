--------------------------------------------------------
--  DDL for Synonymn IDX_MEMBERLOGDTL_MEMBERSEQID
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."IDX_MEMBERLOGDTL_MEMBERSEQID" FOR "APP"."IDX_MEMBERLOGDTL_MEMBERSEQID";

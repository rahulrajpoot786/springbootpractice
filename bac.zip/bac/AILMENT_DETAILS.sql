--------------------------------------------------------
--  DDL for Synonymn AILMENT_DETAILS
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."AILMENT_DETAILS" FOR "APP"."AILMENT_DETAILS";

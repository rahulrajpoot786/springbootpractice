--------------------------------------------------------
--  DDL for Synonymn BANK_GUANT_SEQ
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."BANK_GUANT_SEQ" FOR "APP"."BANK_GUANT_SEQ";

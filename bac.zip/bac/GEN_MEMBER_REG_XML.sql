--------------------------------------------------------
--  DDL for Synonymn GEN_MEMBER_REG_XML
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."GEN_MEMBER_REG_XML" FOR "INTX"."GEN_MEMBER_REG_XML";

--------------------------------------------------------
--  DDL for Synonymn CODE_CLEANUP_EVENT_HISTORY
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."CODE_CLEANUP_EVENT_HISTORY" FOR "APP"."CODE_CLEANUP_EVENT_HISTORY";

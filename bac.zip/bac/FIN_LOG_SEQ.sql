--------------------------------------------------------
--  DDL for Synonymn FIN_LOG_SEQ
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."FIN_LOG_SEQ" FOR "FIN_APP"."FIN_LOG_SEQ";

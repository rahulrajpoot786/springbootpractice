--------------------------------------------------------
--  DDL for Synonymn DHA_PROVIDERS_LIST_MASTER
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."DHA_PROVIDERS_LIST_MASTER" FOR "APP"."DHA_PROVIDERS_LIST_MASTER";

--------------------------------------------------------
--  DDL for Synonymn IDX_INSPRODPLAN_PLANCODE
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."IDX_INSPRODPLAN_PLANCODE" FOR "APP"."IDX_INSPRODPLAN_PLANCODE";

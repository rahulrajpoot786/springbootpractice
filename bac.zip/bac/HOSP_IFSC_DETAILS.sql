--------------------------------------------------------
--  DDL for Synonymn HOSP_IFSC_DETAILS
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."HOSP_IFSC_DETAILS" FOR "APP"."HOSP_IFSC_DETAILS";

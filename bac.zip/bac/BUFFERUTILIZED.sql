--------------------------------------------------------
--  DDL for Synonymn BUFFERUTILIZED
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."BUFFERUTILIZED" FOR "APP"."BUFFERUTILIZED";

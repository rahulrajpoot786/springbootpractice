--------------------------------------------------------
--  DDL for Procedure GET_CLAIM_DATA
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "VENUBABU"."GET_CLAIM_DATA" (V_CLAIM_SEQ_ID IN NUMBER,
                                             V_RESULT OUT SYS_REFCURSOR)
                                             AS
                                             

 
                                             BEGIN
 OPEN V_RESULT FOR 
   SELECT *
 FROM PAT_ACTIVITY_DETAILS Q WHERE Q.CLAIM_SEQ_ID=V_CLAIM_SEQ_ID;

 END GET_CLAIM_DATA;

/

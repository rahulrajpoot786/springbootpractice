--------------------------------------------------------
--  DDL for Package Body CODING_PKG
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "VENUBABU"."CODING_PKG" is

  PROCEDURE return_to_coding (
    v_seq_id                              IN NUMBER,
    v_workflow                            IN VARCHAR2, -- PAT -- preauth , CLM -- claim
    v_added_by                            IN NUMBER,
    v_event_seq_id                        OUT tpa_event.event_seq_id%TYPE,
    v_review_count                        OUT NUMBER,
    v_required_review_count               OUT NUMBER,
    v_event_name                          OUT VARCHAR2,
    v_review                              OUT VARCHAR2,
    v_coding_review_yn                    OUT VARCHAR2
  )
  IS
    CURSOR curr_pat_cur IS SELECT b.pat_status_general_type_id AS status, a.completed_yn,a.event_seq_id ,a.review_count, c.event_owner,c.event_name,a.required_review_count
      FROM pat_general_details a JOIN pat_enroll_details b ON (a.pat_enroll_detail_seq_id = b.pat_enroll_detail_seq_id)
      JOIN tpa_event c ON (a.event_seq_id = c.event_seq_id)
      WHERE a.pat_gen_detail_seq_id = v_seq_id ;

    CURSOR curr_clm_cur IS SELECT b.clm_status_general_type_id AS  status, a.completed_yn , a.event_seq_id ,a.review_count,c.event_owner,c.event_name,a.required_review_count
      FROM clm_general_details a JOIN clm_enroll_details b ON (a.claim_seq_id = b.claim_seq_id)
      JOIN tpa_event c ON (a.event_seq_id = c.event_seq_id)
      WHERE a.claim_seq_id = v_seq_id ;


    CURSOR event_cur IS SELECT a.event_name, a.simple_review_count,a.event_seq_id
       FROM tpa_event a JOIN tpa_workflow b ON (a.workflow_seq_id = b.workflow_seq_id)
       WHERE b.sub_general_type_id = v_workflow AND a.event_owner = 'C';

    current_rec               curr_pat_cur%ROWTYPE;
    event_rec                 event_cur%ROWTYPE;
    v_assign_users_seq_id     assign_users.assign_users_seq_id%TYPE;
  BEGIN
    v_coding_review_yn := 'Y';
    IF v_workflow = 'PAT' THEN
   pre_auth_pkg.preauths_freeze(v_seq_id,NULL,'S'); --KOCBJJ

      pre_auth_pkg.reassign_user(v_seq_id ,NULL,NULL,v_added_by, 'AUT');
      OPEN curr_pat_cur;
      FETCH curr_pat_cur INTO current_rec;
      CLOSE curr_pat_cur;
    ELSE
      
     claims_pkg.claims_freeze(v_seq_id,NULL,'S'); --KOCBJJ
      pre_auth_pkg.reassign_user(NULL ,v_seq_id,NULL,v_added_by, 'AUT');
      OPEN curr_clm_cur;
      FETCH curr_clm_cur INTO current_rec;
      CLOSE curr_clm_cur;
    END IF;


    IF current_rec.completed_yn = 'Y' THEN
      raise_application_error(-20703,'Preauth/Claim is already completed, cannot revert back to coding ');
    ELSIF current_rec.status = 'APR' THEN
      raise_application_error(-20704,'Approved Preauth/Claim cannot revert back to coding, make it in-progress and try again ');
    END IF;

    OPEN  event_cur;
    FETCH event_cur INTO event_rec;
    CLOSE event_cur;

    IF event_rec.event_seq_id < current_rec.event_seq_id THEN

      IF v_workflow = 'PAT' THEN
        UPDATE pat_general_details a SET
          a.event_seq_id = event_rec.event_seq_id ,
          a.review_count = 1,
          a.required_review_count = event_rec.simple_review_count,
          a.updated_by   = v_added_by,
          a.updated_date = SYSDATE
          WHERE a.pat_gen_detail_seq_id = v_seq_id
           RETURNING a.last_assign_user_seq_id INTO v_assign_users_seq_id;

      ELSIF v_workflow = 'CLM' THEN
        UPDATE clm_general_details a SET
          a.event_seq_id = event_rec.event_seq_id ,
          a.review_count = 1,
          a.required_review_count = event_rec.simple_review_count,
          a.updated_by  = v_added_by,
          a.updated_date = SYSDATE
          WHERE a.claim_seq_id = v_seq_id
           RETURNING a.last_assign_user_seq_id INTO v_assign_users_seq_id;
      END IF;
      UPDATE assign_users a SET
         a.review_completed_yn  = 'Y' ,
         a.updated_by           = v_added_by,
         a.updated_date         = SYSDATE
         WHERE a.assign_users_seq_id = v_assign_users_seq_id ;

      coding_pkg.save_coding_search(v_workflow,v_seq_id,'INSERT');-- Added for CR-KOC1044

      v_event_seq_id          := event_rec.event_seq_id;
      v_required_review_count := event_rec.simple_review_count;
      v_event_name            := event_rec.event_name;
      v_review                := to_char(1)||'('||TO_CHAR( v_required_review_count )||')';
      COMMIT;
    ELSE
      v_event_seq_id          := current_rec.event_seq_id;
      v_required_review_count := current_rec.required_review_count;
      v_event_name            := current_rec.event_name;
      v_review                := to_char(1)||'('||TO_CHAR( v_required_review_count )||')';
    END IF;
  END  return_to_coding;
  --=============================================================================
  PROCEDURE select_coding_preauth (
    v_pat_gen_detail_seq_id              IN  PAT_GENERAL_DETAILS.pat_gen_detail_seq_id%TYPE,
    v_added_by                           IN  NUMBER,
    result_set                           OUT SYS_REFCURSOR
  )
  IS
  BEGIN
     OPEN result_set FOR
       SELECT
        B.pat_enroll_detail_seq_id,
        A.pat_gen_detail_seq_id ,
        B.pre_auth_number,
        A.pat_general_type_id,
        T.description AS preauth_type,
        A.pat_received_date,
        B.date_of_hospitalization ,
        A.prev_approved_amount ,
        A.pat_requested_amount ,
        A.treating_dr_name ,
        A.pat_priority_general_type_id ,
        v.description AS priority ,
        A.pat_rcvd_thru_general_type_id ,
        w.description AS recieved_through,
        A.phone_no_in_hospitalisation ,
        A.remarks,
        Q.assign_users_seq_id,
        R.contact_name,
        B.tpa_office_seq_id,
        F.office_name AS ttk_branch,
        S.office_name,
        B.tpa_enrollment_id,
        B.claimant_name,
        B.gender_general_type_id ,
        x.description AS gender,
        B.mem_age ,
        B.date_of_inception ,
        B.date_of_exit ,
        B.category_general_type_id ,
        J.description AS category ,
        A.event_seq_id,
        A.required_review_count ,
        A.review_count ,
        TO_CHAR(A.review_count)||'('||TO_CHAR(A.required_review_count)||')' review,
        'Event : '||U.event_name AS event_name,
        CASE WHEN a.review_count = 1 AND q.review_completed_yn = 'Y' THEN 'N' ELSE 'Y' END AS assigned_yn
        FROM pat_general_details A JOIN pat_enroll_details B ON (a.pat_enroll_detail_seq_id = b.pat_enroll_detail_seq_id)
        LEFT OUTER JOIN tpa_ins_info E ON (b.ins_seq_id = E.ins_seq_id)
        LEFT OUTER JOIN tpa_office_info F ON ( B.tpa_office_seq_id = F.tpa_office_seq_id )
        LEFT OUTER JOIN tpa_general_code J ON (B.category_general_type_id = J.general_type_id)
        LEFT OUTER JOIN assign_users Q ON ( A.last_assign_user_seq_id = Q.assign_users_seq_id )
        LEFT OUTER JOIN tpa_user_contacts R ON (Q.assigned_to_user = R.contact_seq_id)
        LEFT OUTER JOIN tpa_office_info S ON ( R.tpa_office_seq_id = S.tpa_office_seq_id )
        LEFT OUTER JOIN tpa_general_code T ON (A.pat_general_type_id = t.general_type_id)
        JOIN tpa_event U ON ( a.event_seq_id = U.event_seq_id )
        LEFT OUTER JOIN tpa_general_code V ON (A.pat_priority_general_type_id = v.general_type_id)
        LEFT OUTER JOIN tpa_general_code W ON (a.pat_rcvd_thru_general_type_id = w.general_type_id)
        LEFT OUTER JOIN tpa_general_code X ON (b.gender_general_type_id = x.general_type_id)
        WHERE A.pat_gen_detail_seq_id = v_pat_gen_detail_seq_id ;

  END select_coding_preauth;
  --=============================================================================
/***********************************************************************************
 This procedure can be dropped once the new procedure select_coding_preauth_list
 is used in production. i.e after moving CR-KOC1044 to production.
************************************************************************************
  PROCEDURE select_coding_preauth_list_old (
    v_pre_auth_number                    IN  PAT_ENROLL_DETAILS.pre_auth_number%TYPE,
    v_tpa_enrollment_id                  IN  PAT_ENROLL_DETAILS.tpa_enrollment_id%TYPE,
    v_tpa_office_seq_id                  IN  TPA_OFFICE_INFO.tpa_office_seq_id%TYPE,
    v_assigned_type_id                   IN  VARCHAR2,
    v_start_limit_type                   IN  VARCHAR2,
    v_sort_var                           IN  VARCHAR2,
    v_sort_order                         IN  VARCHAR2 ,
    v_start_num                          IN  NUMBER ,
    v_end_num                            IN  NUMBER ,
    v_added_by                           IN  NUMBER,
    result_set                           OUT SYS_REFCURSOR
  )
  IS
    v_sql_str                            VARCHAR2(4000) ;
    TYPE bind_tab_type IS TABLE OF VARCHAR2(250) INDEX BY BINARY_INTEGER ;
    bind_tab                             bind_tab_type;
    i                                    NUMBER(2) := 1;
    v_where                              VARCHAR2(2000);


    CURSOR event_cur IS SELECT a.event_seq_id
      FROM tpa_event a JOIN tpa_workflow b ON (a.workflow_seq_id = b.workflow_seq_id)
      WHERE b.sub_general_type_id = 'PAT' AND a.event_owner = 'C';

    v_curr_event_seq_id                       tpa_event.event_seq_id%TYPE;
    v_start_date                              DATE;
  BEGIN
    OPEN event_cur;
    FETCH event_cur INTO v_curr_event_seq_id;
    CLOSE event_cur;
    bind_tab(1) := v_curr_event_seq_id;

    v_sql_str :=
     'SELECT
       a.pat_enroll_detail_seq_id ,
       b.pat_gen_detail_seq_id ,
       a.pre_auth_number ,
       C.hosp_seq_id,
       C.hosp_name,
       a.tpa_enrollment_id ,
       a.claimant_name ,
       E.assigned_to_user ,
       E.pat_status_general_type_id ,
       F.contact_name,
       B.pat_received_date,
       b.pat_priority_general_type_id ,
       b.pat_enhanced_yn ,
       b.review_count ,
       b.required_review_count ,
       b.event_seq_id ,
       a.policy_seq_id,
       a.ins_seq_id ,
       A.member_seq_id ,
       b.parent_gen_detail_seq_id,
       E.assign_users_seq_id,
       A.tpa_office_seq_id ,
       b.pre_auth_dms_reference_id,
       --G.group_branch_seq_id ,
       CASE WHEN b.review_count = 1 AND e.review_completed_yn = ''Y'' THEN ''N'' ELSE ''Y'' END AS assigned_yn
       FROM pat_enroll_details A JOIN pat_general_details B ON (a.pat_enroll_detail_seq_id = b.pat_enroll_detail_seq_id and b.pat_enhanced_yn = ''N'')
       JOIN tpa_hosp_info C ON (A.hosp_seq_id = C.hosp_seq_id)
       LEFT OUTER JOIN assign_users E ON (B.last_assign_user_seq_id  = E.assign_users_seq_id)
       LEFT OUTER JOIN tpa_user_contacts F ON (E.assigned_to_user = F.contact_seq_id)
       --LEFT OUTER JOIN tpa_enr_policy G ON (A.policy_seq_id = G.policy_seq_id)
       --LEFT OUTER JOIN tpa_group_registration H ON (a.group_reg_seq_id = h.group_reg_seq_id)
       WHERE b.event_seq_id = :v_curr_event_seq_id ';

    IF v_pre_auth_number IS NOT NULL THEN
      v_where := v_where  ||' AND A.pre_auth_number = :v_pre_auth_number ';
       i := i+1;
       bind_tab(i) := UPPER(v_pre_auth_number);
    END IF;

    IF v_tpa_enrollment_id IS NOT NULL THEN
      v_where := v_where  ||' AND A.tpa_enrollment_id = :v_tpa_enrollment_id';
       i := i+1;
       bind_tab(i) := UPPER(v_tpa_enrollment_id);
    END IF;

    IF v_assigned_type_id = 'SLF' THEN
       v_where := v_where ||' AND E.assigned_to_user  = :v_added_by AND e.review_completed_yn != ''Y''' ;
       i := i+1;
       bind_tab(i) := v_added_by;
    ELSIF v_assigned_type_id = 'OTH' THEN
       v_where := v_where ||' AND E.assigned_to_user  != :v_added_by AND e.review_completed_yn != ''Y''';
       i := i+1;
       bind_tab(i) := v_added_by;
    ELSIF v_assigned_type_id = 'UAS' THEN
       v_where := v_where ||' AND b.review_count = 1 AND e.review_completed_yn = ''Y'' ';
    END IF;

    IF v_tpa_office_seq_id IS NOT NULL THEN
      v_where := v_where  ||' AND A.tpa_office_seq_id = :v_tpa_office_seq_id ';
       i := i+1;
       bind_tab(i) := v_tpa_office_seq_id;
    END IF;
    IF v_start_limit_type IS NOT NULL THEN
       CASE v_start_limit_type
         WHEN 'S15' THEN
           v_start_date := TRUNC(SYSDATE) - 15;
         WHEN 'S30' THEN
           v_start_date := TRUNC(SYSDATE) - 30;
       END CASE;
       v_where := v_where   ||' AND b.pat_received_date >= :v_start_date ';
       i := i+1;
       bind_tab(i) := v_start_date;
    END IF;
    v_sql_str := v_sql_str ||v_where;

    v_sql_str := 'SELECT * FROM
        (SELECT A.*,DENSE_RANK() OVER (ORDER BY '||v_sort_var||' '||v_sort_order||',ROWNUM)
        Q FROM (' ||v_sql_str|| ') A ) WHERE  Q>= :v_start_num AND Q<= :v_end_num ';
    IF bind_tab.FIRST IS NOT NULL THEN
       CASE bind_tab.COUNT
         WHEN 1  THEN OPEN result_set FOR v_sql_str USING bind_tab(1), v_start_num , v_end_num ;
         WHEN 2  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2), v_start_num , v_end_num ;
         WHEN 3  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2) ,bind_tab(3) , v_start_num , v_end_num ;
         WHEN 4  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) , v_start_num , v_end_num ;
         WHEN 5  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5), v_start_num , v_end_num ;
         WHEN 6  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6), v_start_num , v_end_num ;
       END CASE;
     END IF;

  END select_coding_preauth_list;  */
  --=======================================================================================
/***********************************************************************************
 This procedure can be dropped once the new procedure select_coding_claims_list
 is used in production. i.e after moving CR-KOC1044 to production.
************************************************************************************
  PROCEDURE select_coding_claims_list_old (
    v_claim_number                   IN  clm_general_details.claim_number%TYPE,
    v_tpa_enrollment_id              IN  clm_enroll_details.tpa_enrollment_id%TYPE,
    v_assigned_to_user               IN  VARCHAR2,
    v_tpa_office_seq_id              IN  tpa_office_info.tpa_office_seq_id%TYPE ,
    v_start_limit_type               IN  VARCHAR2,
    v_sort_var                       IN  VARCHAR2,
    v_sort_order                     IN  VARCHAR2,
    v_start_num                      IN  NUMBER ,
    v_end_num                        IN  NUMBER ,
    v_added_by                       IN  NUMBER,
    result_set                       OUT SYS_REFCURSOR
  )
  IS
    TYPE bind_tab_type IS TABLE OF VARCHAR2(250) INDEX BY BINARY_INTEGER ;
    bind_tab                             bind_tab_type;
    i                                    NUMBER(2) := 1;
    v_where                              VARCHAR2(2000);
    v_sql_str                            VARCHAR2(4000);
    v_start_date                         DATE;

    CURSOR event_cur IS SELECT a.event_seq_id
      FROM tpa_event a JOIN tpa_workflow b ON (a.workflow_seq_id = b.workflow_seq_id)
      WHERE b.sub_general_type_id = 'CLM' AND a.event_owner = 'C';

    v_curr_event_seq_id                       tpa_event.event_seq_id%TYPE;

  BEGIN
    OPEN event_cur;
    FETCH event_cur INTO v_curr_event_seq_id;
    CLOSE event_cur;

    bind_tab(1) := v_curr_event_seq_id;

    v_sql_str :=
      ' SELECT
       A.claim_number ,
       B.tpa_enrollment_id ,
       H.hosp_name ,
       b.claimant_name,
       F.contact_name,
       A.date_of_admission ,
       G.auth_number ,
       A.claim_seq_id,
       B.clm_enroll_detail_seq_id,
       G.pat_enroll_detail_seq_id ,
       H.clm_hosp_assoc_seq_id ,
       B.policy_seq_id,
       B.member_seq_id,
       C.tpa_office_seq_id,
       --I.buffer_allowed_yn ,
       E.assign_users_seq_id,
       CASE WHEN a.parent_claim_seq_id IS NULL THEN ''N'' ELSE ''Y'' END ammendment_yn ,
       --I.Group_Branch_Seq_Id ,
       CASE WHEN a.review_count = 1 AND e.review_completed_yn = ''Y'' THEN ''N'' ELSE ''Y'' END AS assigned_yn
      FROM clm_general_details A JOIN clm_enroll_details B ON (A.claim_seq_id = b.claim_seq_id)
      JOIN clm_inward C ON ( a.claims_inward_seq_id = c.claims_inward_seq_id)
      LEFT OUTER JOIN assign_users E ON (A.last_assign_user_seq_id   = E.assign_users_seq_id)
      LEFT OUTER JOIN tpa_user_contacts F ON (E.assigned_to_user = F.contact_seq_id)
      LEFT OUTER JOIN pat_enroll_details G ON (A.pat_enroll_detail_seq_id  = G.pat_enroll_detail_seq_id)
      LEFT OUTER JOIN clm_hospital_association H ON (A.claim_seq_id = H.claim_seq_id)
      --LEFT OUTER JOIN tpa_enr_policy I ON ( B.policy_seq_id = I.policy_seq_id  )
      WHERE a.event_seq_id = :v_curr_event_seq_id ';

    IF v_claim_number IS NOT NULL THEN
      v_where := v_where   ||' AND A.claim_number = :v_claim_number';
       i := i+1;
       bind_tab(i) := UPPER(v_claim_number);
    END IF;

    IF v_assigned_to_user = 'SLF' THEN
      v_where := v_where  ||' AND E.assigned_to_user  = :v_added_by AND e.review_completed_yn != ''Y''';
       i := i+1;
       bind_tab(i) := v_added_by;
    ELSIF v_assigned_to_user = 'OTH' THEN
      v_where := v_where  ||' AND E.assigned_to_user  != :v_added_by  AND e.review_completed_yn != ''Y''';
       i := i+1;
       bind_tab(i) := v_added_by;
    ELSIF v_assigned_to_user = 'UAS' THEN
      v_where := v_where  ||' AND a.review_count = 1 AND e.review_completed_yn = ''Y''';
    END IF;

    IF v_tpa_enrollment_id IS NOT NULL THEN
       v_where := v_where   ||' AND B.tpa_enrollment_id = :v_tpa_enrollment_id';
       i := i+1;
       bind_tab(i) := UPPER(v_tpa_enrollment_id) ;
    END IF;

    IF v_tpa_office_seq_id IS NOT NULL THEN
       v_where := v_where   ||' AND C.tpa_office_seq_id = :v_tpa_office_seq_id ';
       i := i+1;
       bind_tab(i) := v_tpa_office_seq_id;
    END IF;
    IF v_start_limit_type IS NOT NULL THEN
       CASE v_start_limit_type
         WHEN 'S15' THEN
           v_start_date := TRUNC(SYSDATE) - 15;
         WHEN 'S30' THEN
           v_start_date := TRUNC(SYSDATE) - 30;
       END CASE;
       v_where := v_where   ||' AND c.rcvd_date  >= :v_start_date ';
       i := i+1;
       bind_tab(i) := v_start_date;
    END IF;
    v_sql_str := v_sql_str ||v_where;

    v_sql_str := 'SELECT * FROM
          (SELECT A.*, DENSE_RANK() OVER (ORDER BY '||v_sort_var||' '||v_sort_order||',ROWNUM)
          Q FROM (' ||v_sql_str|| ') A ) WHERE Q>= :v_start_num  AND Q<=  :v_end_num ';

    IF bind_tab.FIRST IS NOT NULL THEN
       CASE bind_tab.COUNT
         WHEN 1  THEN OPEN result_set FOR v_sql_str USING bind_tab(1) , v_start_num , v_end_num ;
         WHEN 2  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2), v_start_num , v_end_num ;
         WHEN 3  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2) ,bind_tab(3) , v_start_num , v_end_num ;
         WHEN 4  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) , v_start_num , v_end_num ;
         WHEN 5  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5), v_start_num , v_end_num ;
         WHEN 6  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6), v_start_num , v_end_num ;
       END CASE;
     END IF;

  END select_coding_claims_list;  */
  --=============================================================================
--===========================================================================================================
/****************************************************************
Author     : Prasanna Kumar R.J., SPAN Infotech
Description: This is a new procedure created to replace the old
             one (with same name) as per CR-KOC1044.
*****************************************************************/

PROCEDURE select_coding_preauth_list (
    v_pre_auth_number                    IN  PAT_ENROLL_DETAILS.pre_auth_number%TYPE,
    v_tpa_enrollment_id                  IN  PAT_ENROLL_DETAILS.tpa_enrollment_id%TYPE,
    v_tpa_office_seq_id                  IN  TPA_OFFICE_INFO.tpa_office_seq_id%TYPE,
    v_assigned_type_id                   IN  VARCHAR2,
    v_start_limit_type                   IN  VARCHAR2,
    v_sort_var                           IN  VARCHAR2,
    v_sort_order                         IN  VARCHAR2 ,
    v_start_num                          IN  NUMBER ,
    v_end_num                            IN  NUMBER ,
    v_added_by                           IN  NUMBER,
    result_set                           OUT SYS_REFCURSOR
  )
  IS
    v_sql_str                            VARCHAR2(4000) ;
    TYPE bind_tab_type IS TABLE OF VARCHAR2(250) INDEX BY BINARY_INTEGER ;
    bind_tab                             bind_tab_type;
    i                                    NUMBER(2) := 1;
    v_where                              VARCHAR2(2000);

    CURSOR event_cur IS SELECT a.event_seq_id
      FROM tpa_event a JOIN tpa_workflow b ON (a.workflow_seq_id = b.workflow_seq_id)
      WHERE b.sub_general_type_id = 'PAT' AND a.event_owner = 'C';

    v_curr_event_seq_id   tpa_event.event_seq_id%TYPE;
    v_start_date          DATE;
  BEGIN
    OPEN event_cur;
    FETCH event_cur INTO v_curr_event_seq_id;
    CLOSE event_cur;
    bind_tab(1) := v_curr_event_seq_id;

    v_sql_str :=
     'SELECT pat_enroll_detail_seq_id ,
             pat_gen_detail_seq_id ,
             pre_auth_number ,
             hosp_seq_id,
             hosp_name,
             tpa_enrollment_id ,
             claimant_name ,
             assigned_to_user ,
             pat_status_general_type_id ,
             contact_name,
             rcvd_date as pat_received_date,
             pat_priority_general_type_id ,
             pat_enhanced_yn ,
             review_count ,
             required_review_count ,
             event_seq_id ,
             policy_seq_id,
             ins_seq_id ,
             member_seq_id ,
             parent_gen_detail_seq_id,
             assign_users_seq_id,
             tpa_office_seq_id ,
             pre_auth_dms_reference_id,
             assigned_yn
        FROM Data_For_Coding_Search
          WHERE work_flow = ''PAT''
            AND event_seq_id = :v_curr_event_seq_id ';

    IF v_pre_auth_number IS NOT NULL THEN
      v_where := v_where  ||' AND pre_auth_number = :v_pre_auth_number ';
       i := i+1;
       bind_tab(i) := UPPER(v_pre_auth_number);
    END IF;

    IF v_tpa_enrollment_id IS NOT NULL THEN
      v_where := v_where  ||' AND tpa_enrollment_id = :v_tpa_enrollment_id';
       i := i+1;
       bind_tab(i) := UPPER(v_tpa_enrollment_id);
    END IF;

    IF v_assigned_type_id = 'SLF' THEN
       v_where := v_where ||' AND assigned_to_user  = :v_added_by AND review_completed_yn != ''Y''' ;
       i := i+1;
       bind_tab(i) := v_added_by;
    ELSIF v_assigned_type_id = 'OTH' THEN
       v_where := v_where ||' AND assigned_to_user  != :v_added_by AND review_completed_yn != ''Y''';
       i := i+1;
       bind_tab(i) := v_added_by;
    ELSIF v_assigned_type_id = 'UAS' THEN
       v_where := v_where ||' AND review_count = 1 AND review_completed_yn = ''Y'' ';
    END IF;

    IF v_tpa_office_seq_id IS NOT NULL THEN
      v_where := v_where  ||' AND tpa_office_seq_id = :v_tpa_office_seq_id ';
       i := i+1;
       bind_tab(i) := v_tpa_office_seq_id;
    END IF;
    IF v_start_limit_type IS NOT NULL THEN
       CASE v_start_limit_type
         WHEN 'S15' THEN
           v_start_date := TRUNC(SYSDATE) - 15;
         WHEN 'S30' THEN
           v_start_date := TRUNC(SYSDATE) - 30;
       END CASE;
       v_where := v_where   ||' AND Rcvd_Date >= :v_start_date ';
       i := i+1;
       bind_tab(i) := v_start_date;
    END IF;
   
--KOC_Cigna_insurance_resriction
    if v_added_by IS NOT NULL THEN
        v_where := v_where ||' AND ( ins_seq_id  in (SELECT inf.ins_seq_id FROM APP.TPA_GROUP_USER_ASSOC UA
      JOIN APP.TPA_GROUP_BRANCH GB ON (GB.GROUP_BRANCH_SEQ_ID = UA.GROUP_BRANCH_SEQ_ID)
      join APP.TPA_INS_INFO INF ON (inf.user_group = gb.group_branch_seq_id)
      WHERE GB.USER_TYPE=''NIC'' AND  UA.CONTACT_SEQ_ID = '||v_added_by||') OR (SELECT count(inf.ins_seq_id) FROM APP.TPA_GROUP_USER_ASSOC UA
      JOIN APP.TPA_GROUP_BRANCH GB ON (GB.GROUP_BRANCH_SEQ_ID = UA.GROUP_BRANCH_SEQ_ID)
      join APP.TPA_INS_INFO INF ON (inf.user_group = gb.group_branch_seq_id)
      WHERE GB.USER_TYPE=''NIC'' AND  UA.CONTACT_SEQ_ID = '||v_added_by||') = 0 )';
    end if;
--KOC_Cigna_insurance_resriction
    
    v_sql_str := v_sql_str ||v_where;

    v_sql_str := 'SELECT * FROM
        (SELECT A.*,DENSE_RANK() OVER (ORDER BY '||v_sort_var||' '||v_sort_order||',ROWNUM)
        Q FROM (' ||v_sql_str|| ') A ) WHERE  Q>= :v_start_num AND Q<= :v_end_num ';
    IF bind_tab.FIRST IS NOT NULL THEN
       CASE bind_tab.COUNT
         WHEN 1  THEN OPEN result_set FOR v_sql_str USING bind_tab(1), v_start_num , v_end_num ;
         WHEN 2  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2), v_start_num , v_end_num ;
         WHEN 3  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2) ,bind_tab(3) , v_start_num , v_end_num ;
         WHEN 4  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) , v_start_num , v_end_num ;
         WHEN 5  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5), v_start_num , v_end_num ;
         WHEN 6  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6), v_start_num , v_end_num ;
       END CASE;
     END IF;

  END select_coding_preauth_list;
--===========================================================================================================
/****************************************************************
Author     : Prasanna Kumar R.J., SPAN Infotech
Description: This is a new procedure created to replace the old
             one (with same name) as per CR-KOC1044.
*****************************************************************/
  PROCEDURE select_coding_claims_list (
    v_claim_number                   IN  clm_general_details.claim_number%TYPE,
    v_tpa_enrollment_id              IN  clm_enroll_details.tpa_enrollment_id%TYPE,
    v_assigned_to_user               IN  VARCHAR2,
    v_tpa_office_seq_id              IN  tpa_office_info.tpa_office_seq_id%TYPE ,
    v_start_limit_type               IN  VARCHAR2,
    v_sort_var                       IN  VARCHAR2,
    v_sort_order                     IN  VARCHAR2,
    v_start_num                      IN  NUMBER ,
    v_end_num                        IN  NUMBER ,
    v_added_by                       IN  NUMBER,
    result_set                       OUT SYS_REFCURSOR
  )
  IS
    TYPE bind_tab_type IS TABLE OF VARCHAR2(250) INDEX BY BINARY_INTEGER ;
    bind_tab                             bind_tab_type;
    i                                    NUMBER(2) := 1;
    v_where                              VARCHAR2(2000);
    v_sql_str                            VARCHAR2(4000);
    v_start_date                         DATE;

    CURSOR event_cur IS SELECT a.event_seq_id
      FROM tpa_event a JOIN tpa_workflow b ON (a.workflow_seq_id = b.workflow_seq_id)
      WHERE b.sub_general_type_id = 'CLM' AND a.event_owner = 'C';

    v_curr_event_seq_id                       tpa_event.event_seq_id%TYPE;

  BEGIN
    OPEN event_cur;
    FETCH event_cur INTO v_curr_event_seq_id;
    CLOSE event_cur;

    bind_tab(1) := v_curr_event_seq_id;

    v_sql_str :=
     'SELECT dc.claim_number ,
             dc.tpa_enrollment_id ,
             dc.hosp_name ,
             dc.claimant_name,
             dc.contact_name,
             dc.date_of_admission ,
             dc.pre_auth_number as auth_number ,
             dc.claim_seq_id,
             dc.clm_enroll_detail_seq_id,
             dc.pat_enroll_detail_seq_id ,
             dc.clm_hosp_assoc_seq_id ,
             dc.policy_seq_id,
             dc.member_seq_id,
             dc.tpa_office_seq_id,
             dc.assign_users_seq_id,
             dc.ammendment_yn ,
             dc.assigned_yn,
replace(replace(nvl(d.gen_complete_yn,''N''),''Y'',''G'')||'' ''||replace(nvl(d.med_complete_yn,''N''),''Y'',''M'')||'' ''||replace(nvl(d.cod_complete_yn,''N''),''Y'',''C'')
||'' ''||replace(nvl(d.bill_complete_yn,''N''),''Y'',''B''),''N'','' '') as STATUS
        FROM Data_For_Coding_Search dc
        LEFT OUTER JOIN app.clm_data_entry_complete d ON (d.claim_seq_id = dc.claim_seq_id)
        WHERE dc.work_flow = ''CLM''
          AND dc.event_seq_id = :v_curr_event_seq_id ';

    IF v_claim_number IS NOT NULL THEN
      v_where := v_where   ||' AND claim_number = :v_claim_number';
       i := i+1;
       bind_tab(i) := UPPER(v_claim_number);
    END IF;

    IF v_assigned_to_user = 'SLF' THEN
      v_where := v_where  ||' AND assigned_to_user  = :v_added_by AND review_completed_yn != ''Y''';
       i := i+1;
       bind_tab(i) := v_added_by;
    ELSIF v_assigned_to_user = 'OTH' THEN
      v_where := v_where  ||' AND assigned_to_user  != :v_added_by  AND review_completed_yn != ''Y''';
       i := i+1;
       bind_tab(i) := v_added_by;
    ELSIF v_assigned_to_user = 'UAS' THEN
      v_where := v_where  ||' AND review_count = 1 AND review_completed_yn = ''Y''';
    END IF;

    IF v_tpa_enrollment_id IS NOT NULL THEN
       v_where := v_where   ||' AND tpa_enrollment_id = :v_tpa_enrollment_id';
       i := i+1;
       bind_tab(i) := UPPER(v_tpa_enrollment_id) ;
    END IF;

    IF v_tpa_office_seq_id IS NOT NULL THEN
       v_where := v_where   ||' AND tpa_office_seq_id = :v_tpa_office_seq_id ';
       i := i+1;
       bind_tab(i) := v_tpa_office_seq_id;
    END IF;
    IF v_start_limit_type IS NOT NULL THEN
       CASE v_start_limit_type
         WHEN 'S15' THEN
           v_start_date := TRUNC(SYSDATE) - 15;
         WHEN 'S30' THEN
           v_start_date := TRUNC(SYSDATE) - 30;
       END CASE;
       v_where := v_where   ||' AND rcvd_date  >= :v_start_date ';
       i := i+1;
       bind_tab(i) := v_start_date;
    END IF;

--KOC_Cigna_insurance_resriction
    if v_added_by IS NOT NULL THEN
        v_where := v_where ||' AND ( ins_seq_id  in (SELECT inf.ins_seq_id FROM APP.TPA_GROUP_USER_ASSOC UA
      JOIN APP.TPA_GROUP_BRANCH GB ON (GB.GROUP_BRANCH_SEQ_ID = UA.GROUP_BRANCH_SEQ_ID)
      join APP.TPA_INS_INFO INF ON (inf.user_group = gb.group_branch_seq_id)
      WHERE GB.USER_TYPE=''NIC'' AND  UA.CONTACT_SEQ_ID = '||v_added_by||') OR (SELECT count(inf.ins_seq_id) FROM APP.TPA_GROUP_USER_ASSOC UA
      JOIN APP.TPA_GROUP_BRANCH GB ON (GB.GROUP_BRANCH_SEQ_ID = UA.GROUP_BRANCH_SEQ_ID)
      join APP.TPA_INS_INFO INF ON (inf.user_group = gb.group_branch_seq_id)
      WHERE GB.USER_TYPE=''NIC'' AND  UA.CONTACT_SEQ_ID = '||v_added_by||') = 0 )';
    end if;
--KOC_Cigna_insurance_resriction
    
    v_sql_str := v_sql_str ||v_where;

    v_sql_str := 'SELECT * FROM
          (SELECT A.*, DENSE_RANK() OVER (ORDER BY '||v_sort_var||' '||v_sort_order||',ROWNUM)
          Q FROM (' ||v_sql_str|| ') A ) WHERE Q>= :v_start_num  AND Q<=  :v_end_num ';

    IF bind_tab.FIRST IS NOT NULL THEN
       CASE bind_tab.COUNT
         WHEN 1  THEN OPEN result_set FOR v_sql_str USING bind_tab(1) , v_start_num , v_end_num ;
         WHEN 2  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2), v_start_num , v_end_num ;
         WHEN 3  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2) ,bind_tab(3) , v_start_num , v_end_num ;
         WHEN 4  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) , v_start_num , v_end_num ;
         WHEN 5  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5), v_start_num , v_end_num ;
         WHEN 6  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6), v_start_num , v_end_num ;
       END CASE;
     END IF;

  END select_coding_claims_list;
--===========================================================================================================
  PROCEDURE select_coding_claim (
    v_claim_seq_id                  IN clm_general_details.claim_seq_id%TYPE,
    v_added_by                      IN NUMBER,
    v_result_set                    OUT SYS_REFCURSOR
  )
  IS
  BEGIN

    OPEN v_result_set FOR
      SELECT
       A.claim_seq_id,
       B.tpa_enrollment_id,
       B.claimant_name ,
       B.gender_general_type_id,
       m.description AS gender,
       B.mem_age ,
       B.date_of_inception ,
       B.date_of_exit ,
       B.employee_no ,
       B.employee_name ,
       B.relship_type_id ,
       l.relship_description AS relationship,
       B.claimant_phone_number ,
       A.claim_number ,
       A.claim_file_number ,
       A.parent_claim_seq_id ,
       c.document_general_type_id AS request_general_type_id ,
       R.description AS request_type ,
       C.claim_general_type_id ,
       d.description AS claim_type,
       A.claim_sub_general_type_id ,
       K.description AS sub_type,
       ww.call_recorded_date AS intimation_date,
       A.mode_general_type_id,
       E.Description AS mode_type,
       C.rcvd_date,
       A.treating_dr_name ,
       A.in_patient_no ,
       f.office_name AS ttk_branch,
       c.source_general_type_id,
       g.description AS source_type,
       h.assign_users_seq_id,
       i.contact_name,
       j.office_name AS processing_branch,
       c.claim_number AS prev_claim_number,
       a.requested_amount,
       a.claims_remarks,
       A.event_seq_id,
       A.required_review_count ,
       A.review_count ,
       TO_CHAR(A.review_count)||'('||TO_CHAR(A.required_review_count)||')' review,
       'Event : '||W.event_name AS event_name,
       CASE WHEN a.review_count = 1 AND h.review_completed_yn = 'Y' THEN 'N' ELSE 'Y' END AS assigned_yn
      FROM clm_general_details A JOIN clm_enroll_details B ON ( A.claim_seq_id = b.claim_seq_id )
      JOIN clm_inward C ON ( a.claims_inward_seq_id = c.claims_inward_seq_id )
      LEFT OUTER JOIN tpa_general_code D ON (c.claim_general_type_id = d.general_type_id)
      LEFT OUTER JOIN tpa_general_code E ON (a.mode_general_type_id = e.general_type_id )
      LEFT OUTER JOIN tpa_office_info F ON ( c.tpa_office_seq_id = f.tpa_office_seq_id )
      LEFT OUTER JOIN tpa_general_code G ON ( C.source_general_type_id = g.general_type_id )
      LEFT OUTER JOIN assign_users H ON (A.last_assign_user_seq_id  = H.assign_users_seq_id)
      LEFT OUTER JOIN tpa_user_contacts i ON (h.assigned_to_user = i.contact_seq_id)
      LEFT OUTER JOIN tpa_office_info j ON ( h.tpa_office_seq_id = j.tpa_office_seq_id )
      LEFT OUTER JOIN tpa_general_code K ON ( A.claim_sub_general_type_id = K.general_type_id )
      LEFT OUTER JOIN tpa_relationship_code L ON (B.Relship_Type_Id = l.relship_group_type_id)
      LEFT OUTER JOIN tpa_general_code M ON ( b.gender_general_type_id = M.general_type_id )
      LEFT OUTER JOIN tpa_ins_info N ON (B.ins_seq_id = n.ins_seq_id)
      LEFT OUTER JOIN tpa_general_code R ON (C.Document_General_Type_Id = R.General_Type_Id )
      LEFT OUTER JOIN tpa_event W ON (A.event_seq_id = W.event_seq_id)
      LEFT OUTER JOIN tpa_enr_policy VV ON ( b.policy_seq_id = vv.policy_seq_id )
      LEFT OUTER JOIN tpa_call_log WW ON ( a.call_log_seq_id = ww.call_log_seq_id )
      LEFT OUTER JOIN tpa_enr_policy_member XX ON ( b.member_seq_id = xx.member_seq_id )
      WHERE A.claim_seq_id = v_claim_seq_id ;

  END select_coding_claim;
  --=============================================================================
  PROCEDURE select_ailment_list (
    v_pat_gen_detail_seq_id     IN pat_general_details.pat_gen_detail_seq_id%TYPE,
    v_claim_seq_id              IN clm_general_details.claim_seq_id%TYPE,
    icd_cur                     OUT SYS_REFCURSOR
  )
  IS
  BEGIN
    IF v_pat_gen_detail_seq_id IS NOT NULL THEN
       OPEN icd_cur FOR
         WITH proc_tab AS
         ( SELECT substr(sys_connect_by_path(proc_code,','),2) AS proc_codes ,icd_pcs_seq_id
          FROM ( SELECT bb.proc_code,cc.icd_pcs_seq_id , row_number() Over( PARTITION BY aa.icd_pcs_seq_id ORDER BY aa.pat_proc_seq_id) rowno ,
            COUNT(1) over(PARTITION BY aa.icd_pcs_seq_id) AS rowcnt
              FROM pat_package_procedures aa JOIN tpa_hosp_procedure_code bb ON (aa.proc_seq_id = bb.proc_seq_id)
              JOIN icd_pcs_detail cc ON ( aa.icd_pcs_seq_id = cc.icd_pcs_seq_id )
                WHERE cc.pat_gen_detail_seq_id = v_pat_gen_detail_seq_id)
              WHERE rowno = rowcnt START WITH rowno = 1 CONNECT BY PRIOR rowno = rowno -1 AND icd_pcs_seq_id = PRIOR icd_pcs_seq_id )
         SELECT
          A.icd_pcs_seq_id ,
          A.ped_code_id ,
          A.icd_code ,
          b.ped_description ,
          c.proc_codes,
          '' diagnosys_name,
          '' diag_type,
          0 diagnosys_seq_id
		  
          FROM icd_pcs_detail A JOIN tpa_ped_code b ON (A.ped_code_id = b.ped_code_id)
          LEFT OUTER JOIN proc_tab c ON (a.icd_pcs_seq_id = c.icd_pcs_seq_id )
          WHERE A.pat_gen_detail_seq_id = v_pat_gen_detail_seq_id ORDER BY A.icd_pcs_seq_id;
    ELSE
       OPEN icd_cur FOR
          WITH proc_tab AS
         ( SELECT substr(sys_connect_by_path(proc_code,','),2) AS proc_codes ,icd_pcs_seq_id
          FROM ( SELECT bb.proc_code,cc.icd_pcs_seq_id , row_number() Over( PARTITION BY aa.icd_pcs_seq_id ORDER BY aa.pat_proc_seq_id) rowno ,
            COUNT(1) over(PARTITION BY aa.icd_pcs_seq_id) AS rowcnt
              FROM pat_package_procedures aa JOIN tpa_hosp_procedure_code bb ON (aa.proc_seq_id = bb.proc_seq_id)
              JOIN icd_pcs_detail cc ON ( aa.icd_pcs_seq_id = cc.icd_pcs_seq_id )
                WHERE cc.claim_seq_id = v_claim_seq_id )
              WHERE rowno = rowcnt START WITH rowno = 1 CONNECT BY PRIOR rowno = rowno -1 AND icd_pcs_seq_id = PRIOR icd_pcs_seq_id )
         SELECT
          A.icd_pcs_seq_id ,
          A.ped_code_id ,
          A.icd_code ,
          b.ped_description ,
          c.proc_codes,
         dd.diagnosys_name,  --koc decoupling
         case when a.primary_ailment_yn='Y' then 'P'
           else case when a.secondary_ailment_yn='Y' then 'S'
           else case when a.comorb_ailment_yn='Y' then 'C' else '' end end end  as diag_type,
           dd.diagnosys_seq_id
         
          FROM icd_pcs_detail A JOIN tpa_ped_code b ON (A.ped_code_id = b.ped_code_id)
          LEFT OUTER JOIN proc_tab c ON (a.icd_pcs_seq_id = c.icd_pcs_seq_id )
          LEFT OUTER JOIN clm_data_entry_complete dc on (dc.claim_seq_id = a.claim_seq_id) --koc decoupling 
          LEFT OUTER JOIN tpa_diagnosys_details dd on (dd.diagnosys_seq_id = a.diagnosys_seq_id) --koc decoupling 
          WHERE A.claim_seq_id = v_claim_seq_id ORDER BY A.icd_pcs_seq_id;
          
    END IF;
  END select_ailment_list;
  --=============================================================================
  PROCEDURE get_exact_icd (
    v_icd_code                  IN  tpa_ped_code.icd_code%TYPE,
    v_ped_description           OUT tpa_ped_code.ped_description%TYPE,
    v_ped_code_id               OUT tpa_ped_code.ped_code_id%TYPE
  )
  IS

    CURSOR icd_cur IS SELECT  a.ped_description , a.ped_code_id
      FROM tpa_ped_code a WHERE a.icd_code = v_icd_code;

  BEGIN
    OPEN icd_cur ;
    FETCH icd_cur INTO v_ped_description, v_ped_code_id;
    CLOSE icd_cur ;

    IF v_ped_description IS NULL THEN
      raise_application_error(-20705,'Invalid ICD Code.');
    END IF;
  END get_exact_icd;
--======================================================================================
  PROCEDURE get_exact_procedure (
    v_proc_code             IN  tpa_hosp_procedure_code.proc_code%TYPE,
    v_proc_description      OUT  tpa_hosp_procedure_code.proc_description%TYPE,
    v_proc_seq_id           OUT  tpa_hosp_procedure_code.proc_seq_id%TYPE
  )
  IS

    CURSOR proc_cur IS SELECT  a.proc_description , a.proc_seq_id
      FROM tpa_hosp_procedure_code a WHERE a.proc_code = v_proc_code;

  BEGIN
    OPEN proc_cur ;
    FETCH proc_cur INTO v_proc_description,v_proc_seq_id;
    CLOSE proc_cur ;

    IF v_proc_description IS NULL THEN
      raise_application_error(-20706,'Invalid Procedure Code.');
    END IF;

  END get_exact_procedure;

  --=============================================================================
/*  This is report is used for generating data for Pre-auth coding status report.
*/
  PROCEDURE Pending_Case_Report (
    where_clause        IN  VARCHAR2,
    result_set          OUT SYS_REFCURSOR
  )
  IS
    str_tab       ttk_util_pkg.str_table_type;
  BEGIN
    str_tab  := ttk_util_pkg.parse_str ( where_clause );

/*  str_tab(1) tpa_office_seq_id
    str_tab(2) case_type
    str_tab(3) start_date
    str_tab(4) end_date
    str_tab(5) status  -- P for pending, C for completed AND B for both.
*/

    IF str_tab(2) = 'PRE' THEN
       OPEN result_set FOR
       WITH code_dt AS
           (SELECT pat_gen_detail_seq_id, event_seq_id, rn, event_exec_by,
                   CASE WHEN event_seq_id != 11 THEN coding_comp_dt ELSE coding_rcv_dt END AS coding_rcv_dt,
                   CASE WHEN event_seq_id = 11  THEN coding_comp_dt ELSE NULL END AS coding_comp_dt
              FROM (SELECT pat_gen_detail_seq_id, event_seq_id, event_exec_date AS coding_comp_dt, event_exec_by,
                           lag(event_exec_date,1) over (partition by pat_gen_detail_seq_id order by event_exec_date) coding_rcv_dt,
                           row_number() over (partition by pat_gen_detail_seq_id order by event_exec_date DESC) rn
                      FROM pat_event_history
                         WHERE pat_gen_detail_seq_id IS NOT NULL )
                    WHERE ((coding_rcv_dt BETWEEN to_date(str_tab(3),'dd/mm/yyyy') AND nvl(to_date(str_tab(4),'dd/mm/yyyy')+1,SYSDATE) AND str_tab(5) IN ('P','B')) OR
                          (coding_comp_dt BETWEEN to_date(str_tab(3),'dd/mm/yyyy') AND nvl(to_date(str_tab(4),'dd/mm/yyyy')+1,SYSDATE) AND str_tab(5) IN ('C','B')) )
                      AND (event_seq_id = 11 OR rn = 1))
       SELECT c.office_code, c.office_name, b.pre_auth_number AS pat_clm_number,
              to_char(a.pat_received_date,'dd/mm/yyyy HH:MI AM') AS received_date,
              to_char(cd.coding_rcv_dt,'dd/mm/yyyy HH:MI AM') AS coding_rvc_date,
              to_char(cd.coding_comp_dt,'dd/mm/yyyy HH:MI AM') AS coding_com_date,
              CASE WHEN cd.coding_comp_dt IS NULL THEN 1 ELSE 0 END AS Pending_cnt,
              CASE WHEN cd.coding_comp_dt IS NOT NULL THEN 1 ELSE 0 END AS Complet_cnt,
              CASE WHEN cd.coding_comp_dt IS NOT NULL THEN u.contact_name ELSE NULL END AS Coded_by
         FROM pat_general_details a JOIN pat_enroll_details b
              ON (a.pat_enroll_detail_seq_id = b.pat_enroll_detail_seq_id AND a.pat_enhanced_yn = 'N')
              JOIN code_dt cd ON (a.pat_gen_detail_seq_id = cd.pat_gen_detail_seq_id AND (
                                  cd.event_seq_id = 11 OR (a.event_seq_id = 11 AND cd.rn = 1) ) )
              LEFT OUTER JOIN tpa_office_info c ON (b.tpa_office_seq_id = c.tpa_office_seq_id)
              LEFT OUTER JOIN tpa_user_contacts u ON cd.event_exec_by = u.contact_seq_id
           WHERE a.event_seq_id IN (SELECT event_seq_id FROM tpa_event
                                        WHERE workflow_seq_id = 3
                                          AND ((event_seq_id = 11 AND str_tab(5) = 'P') OR
                                               (event_seq_id > 11 AND str_tab(5) = 'C') OR
                                               (event_seq_id >= 11 AND str_tab(5) = 'B')))
             AND (c.tpa_office_seq_id = str_tab(1) OR str_tab(1) IS NULL)
             AND ((coding_rcv_dt BETWEEN to_date(str_tab(3),'dd/mm/yyyy') AND nvl(to_date(str_tab(4),'dd/mm/yyyy')+1,SYSDATE) AND str_tab(5) IN ('P','B') AND a.event_seq_id = 11) OR
                  (coding_comp_dt BETWEEN to_date(str_tab(3),'dd/mm/yyyy') AND nvl(to_date(str_tab(4),'dd/mm/yyyy')+1,SYSDATE) AND str_tab(5) IN ('C','B') AND a.event_seq_id > 11))
               ORDER BY c.office_name, cd.coding_rcv_dt;

    ELSE --str_tab(2) = 'CLM'
       OPEN result_set FOR
       WITH code_dt AS
               (SELECT claim_seq_id, event_seq_id, rn, event_exec_by,
                       CASE WHEN event_seq_id != 17 THEN coding_comp_dt ELSE coding_rcv_dt END AS coding_rcv_dt,
                       CASE WHEN event_seq_id = 17  THEN coding_comp_dt ELSE NULL END AS coding_comp_dt
                 FROM (SELECT claim_seq_id, event_seq_id, event_exec_date AS coding_comp_dt, event_exec_by,
                               lag(event_exec_date,1) over (partition by claim_seq_id order by event_exec_date) coding_rcv_dt,
                               row_number() over (partition by claim_seq_id order by event_exec_date DESC) rn
                        FROM pat_event_history
                           WHERE claim_seq_id IS NOT NULL)
                        WHERE ((coding_rcv_dt BETWEEN to_date(str_tab(3),'dd/mm/yyyy') AND nvl(to_date(str_tab(4),'dd/mm/yyyy')+1,SYSDATE) AND str_tab(5) IN ('P','B')) OR
                              (coding_comp_dt BETWEEN to_date(str_tab(3),'dd/mm/yyyy') AND nvl(to_date(str_tab(4),'dd/mm/yyyy')+1,SYSDATE) AND str_tab(5) IN ('C','B')) )
                          AND (event_seq_id = 17 OR rn = 1))
       SELECT c.office_code, c.office_name, a.claim_number AS pat_clm_number,
              to_char(b.rcvd_date,'dd/mm/yyyy') AS received_date,
              to_char(cd.coding_rcv_dt,'dd/mm/yyyy HH:MI AM') AS coding_rvc_date,
              to_char(cd.coding_comp_dt,'dd/mm/yyyy HH:MI AM') AS coding_com_date,
              CASE WHEN cd.coding_comp_dt IS NULL THEN 1 ELSE 0 END AS Pending_cnt,
              CASE WHEN cd.coding_comp_dt IS NOT NULL THEN 1 ELSE 0 END AS Complet_cnt,
              CASE WHEN cd.coding_comp_dt IS NOT NULL THEN u.contact_name ELSE NULL END AS Coded_by
         FROM clm_general_details a JOIN clm_inward b ON (a.claims_inward_seq_id = b.claims_inward_seq_id)
              JOIN code_dt cd ON (a.claim_seq_id = cd.claim_seq_id AND (
                                  cd.event_seq_id = 17 OR (a.event_seq_id = 17 AND cd.rn = 1) ) )
              LEFT OUTER JOIN tpa_office_info c ON (b.tpa_office_seq_id = c.tpa_office_seq_id)
              LEFT OUTER JOIN tpa_user_contacts u ON cd.event_exec_by = u.contact_seq_id
           WHERE a.event_seq_id IN (SELECT event_seq_id FROM tpa_event
                                        WHERE workflow_seq_id = 4
                                          AND ((event_seq_id = 17 AND str_tab(5) = 'P') OR
                                               (event_seq_id > 17 AND str_tab(5) = 'C') OR
                                               (event_seq_id >= 17 AND str_tab(5) = 'B')))
             AND (c.tpa_office_seq_id = str_tab(1) OR str_tab(1) IS NULL)
             AND ((coding_rcv_dt BETWEEN to_date(str_tab(3),'dd/mm/yyyy') AND nvl(to_date(str_tab(4),'dd/mm/yyyy')+1,SYSDATE) AND str_tab(5) IN ('P','B') AND a.event_seq_id = 17) OR
                  (coding_comp_dt BETWEEN to_date(str_tab(3),'dd/mm/yyyy') AND nvl(to_date(str_tab(4),'dd/mm/yyyy')+1,SYSDATE) AND str_tab(5) IN ('C','B') AND a.event_seq_id > 17))
               ORDER BY c.office_name, cd.coding_rcv_dt;

    END IF;

  END pending_case_report;
  --=============================================================================
  PROCEDURE save_coding_ped(
    v_ped_seq_id                         IN  OUT CLAIMANT_PED.claimant_ped_seq_id%TYPE ,
    v_seq_id                             IN  CLAIMANT_PED.pat_gen_detail_seq_id%TYPE,  -- pat_general_detail_seq_id /Claim_seq_id
    v_member_seq_id                      IN  CLAIMANT_PED.member_seq_id%TYPE,
    v_ped_code_id                        IN  OUT CLAIMANT_PED.ped_code_id%TYPE ,
    v_icd_code                           IN  OUT CLAIMANT_PED.icd_code%TYPE ,
    v_scr_mode                           IN  VARCHAR2, -- PAT -> in preauth -- CLM -> In Claims
    v_show_mode                          IN  VARCHAR2, -- TTK -> in preauth/CLAIM -- INSURANCE -- enrollment
    v_added_by                           IN  NUMBER ,
    v_rows_processed                     IN  OUT NUMBER
  )
  IS
    v_pat_gen_detail_seq_id              claimant_ped.pat_gen_detail_seq_id%TYPE;
    v_claim_seq_id                       claimant_ped.claim_seq_id%TYPE;
    v_ctr                                NUMBER(1);
    v_ctr_icd                            NUMBER(1);

    CURSOR icd_cur IS SELECT COUNT(1)
      FROM tpa_ped_code a WHERE a.icd_code = v_icd_code;

  BEGIN

    OPEN icd_cur ;
    FETCH icd_cur INTO v_ctr_icd;
    CLOSE icd_cur ;

    IF v_scr_mode = 'PAT' THEN
      v_pat_gen_detail_seq_id            := v_seq_id;
     --Checking pat completed
      pre_auth_pkg.check_pat_completed( v_pat_gen_detail_seq_id , NULL,'APP',v_added_by );
      -- Check and reassign the Preauth
      pre_auth_pkg.reassign_user (  v_pat_gen_detail_seq_id , NULL , NULL  , v_added_by , 'AUT');
      pre_auth_pkg.set_validation_status('P',v_pat_gen_detail_seq_id,'U',v_added_by);
    ELSIF v_scr_mode = 'CLM' THEN
      v_claim_seq_id                     := v_seq_id;
--      check_clm_completed
      pre_auth_pkg.check_clm_completed ( v_claim_seq_id , NULL ,'APP' ,v_added_by);
      pre_auth_pkg.reassign_user (  NULL , v_claim_seq_id , NULL  , v_added_by , 'AUT');
      pre_auth_pkg.set_validation_status('C',v_claim_seq_id,'U',v_added_by);
    END IF;

    IF v_icd_code != 'UNK' THEN
      SELECT COUNT(1) INTO v_ctr
        FROM claimant_ped
       WHERE member_seq_id = v_member_seq_id AND ped_code_id = v_ped_code_id
       AND icd_code = v_icd_code AND claimant_ped_seq_id != v_ped_seq_id;

      IF v_ctr > 0 THEN
        raise_application_error(-20085, ' Disease Already Selected For This Member ' );
      END IF;
    END IF;

    IF v_show_mode = 'TTK' THEN
      IF v_ped_seq_id = 0 THEN
        IF v_ctr_icd = 0 THEN
            raise_application_error(-20705,'Invalid ICD Code.');
        ELSE
          INSERT INTO claimant_ped(
            claimant_ped_seq_id,
            pat_gen_detail_seq_id ,
            claim_seq_id,
            member_seq_id,
            ped_code_id,
            icd_code,
            added_by,
            added_date)
          VALUES (
            claimant_ped_seq.NEXTVAL,
            v_pat_gen_detail_seq_id ,
            v_claim_seq_id,
            v_member_seq_id,
            v_ped_code_id,
            v_icd_code,
            v_added_by,
            SYSDATE ) RETURNING claimant_ped_seq_id INTO v_ped_seq_id ;
          END IF;
      ELSE
        IF v_ctr_icd = 0 THEN
            raise_application_error(-20705,'Invalid ICD Code.');
        ELSE
          UPDATE claimant_ped SET
            ped_code_id                             = v_ped_code_id,
            icd_code                                = v_icd_code,
            updated_by                              = v_added_by,
            updated_date                            = SYSDATE
            WHERE claimant_ped_seq_id = v_ped_seq_id;
        END IF;
      END IF;
    ELSE
     IF v_ped_seq_id = 0 THEN
        IF v_ctr_icd = 0 THEN
            raise_application_error(-20705,'Invalid ICD Code.');
        ELSE
          INSERT INTO tpa_enr_mem_ped(
            mem_ped_seq_id ,
            member_seq_id,
            ped_code_id,
            icd_code,
            added_by,
            added_date)
          VALUES (
            tpa_enr_mem_ped_seq.NEXTVAL ,
            v_member_seq_id,
            v_ped_code_id,
            v_icd_code,
            v_added_by,
            SYSDATE ) RETURNING mem_ped_seq_id INTO v_ped_seq_id ;
        END IF;
      ELSE
        IF v_ctr_icd = 0 THEN
            raise_application_error(-20705,'Invalid ICD Code.');
        ELSE
          UPDATE tpa_enr_mem_ped SET
            ped_code_id                             = v_ped_code_id,
            icd_code                                = v_icd_code,
            updated_by                              = v_added_by,
            updated_date                            = SYSDATE
            WHERE mem_ped_seq_id  = v_ped_seq_id;
        END IF;
      END IF;
    END IF;
    v_rows_processed := SQL%ROWCOUNT;
    COMMIT;
  END save_coding_ped;
--=============================================================================
/****************************************************************
Author     : Prasanna Kumar R.J., SPAN Infotech
Description: This procedure is called when a pre-auth/claim is brought to coding
             or moved away from coding. When pre-auth/claim is put to coding a
             record is inserted into a temp table - Data_For_Coding_Search. On
             the other hand when pre-auth/claim is moved away from coding, the
             corresponding record is deleted in the above table. The temp table
             is used for improving the search performance of coding screen
             through the CR-KOC1044. As this procedure is called from other
             procedures, COMMIT is not issued here.
*****************************************************************/
PROCEDURE save_coding_search (
       v_workflow IN VARCHAR2, -- PAT -- preauth , CLM -- claim
       v_seq_id   IN NUMBER,
       v_flag     IN VARCHAR2)   -- INSERT / UPDATE / DELETE
IS
  v_event_seq_id  clm_general_details.event_seq_id%TYPE;
BEGIN

  SELECT a.event_seq_id INTO v_event_seq_id
    FROM tpa_event a JOIN tpa_workflow b ON (a.workflow_seq_id = b.workflow_seq_id)
       WHERE b.sub_general_type_id = v_workflow AND a.event_owner = 'C';

  IF v_flag = 'INSERT' THEN
      IF v_workflow = 'PAT' THEN
         INSERT INTO Data_For_Coding_Search (policy_seq_id,              ins_seq_id,                   tpa_office_seq_id,
                                             member_seq_id,              tpa_enrollment_id,            pat_enroll_detail_seq_id,
                                             pat_gen_detail_seq_id,      pre_auth_number,              pat_status_general_type_id,
                                             rcvd_date,                  pat_priority_general_type_id, pat_enhanced_yn,
                                             pre_auth_dms_reference_id,  parent_gen_detail_seq_id,     claimant_name,
                                             hosp_seq_id,                hosp_name,                    contact_name,
                                             assigned_to_user,           review_count,                 required_review_count,
                                             event_seq_id,               assign_users_seq_id,          review_completed_yn,
                                             assigned_yn,                work_flow )
         SELECT a.policy_seq_id,             a.ins_seq_id,                   a.tpa_office_seq_id,
                a.member_seq_id,             a.tpa_enrollment_id,            a.pat_enroll_detail_seq_id,
                b.pat_gen_detail_seq_id,     a.pre_auth_number,              E.pat_status_general_type_id,
                B.pat_received_date,         b.pat_priority_general_type_id, b.pat_enhanced_yn,
                b.pre_auth_dms_reference_id, b.parent_gen_detail_seq_id,     a.claimant_name,
                C.hosp_seq_id,               C.hosp_name,                    F.contact_name,
                E.assigned_to_user,          b.review_count,                 b.required_review_count,
                v_event_seq_id,              E.assign_users_seq_id,          e.review_completed_yn,
                CASE WHEN b.review_count = 1 AND e.review_completed_yn = 'Y' THEN 'N' ELSE 'Y' END AS assigned_yn,
                'PAT'
           FROM pat_enroll_details A
                JOIN pat_general_details B ON (a.pat_enroll_detail_seq_id = b.pat_enroll_detail_seq_id and b.pat_enhanced_yn = 'N')
                JOIN tpa_hosp_info C ON (A.hosp_seq_id = C.hosp_seq_id)
                LEFT OUTER JOIN assign_users E ON (B.last_assign_user_seq_id  = E.assign_users_seq_id)
                LEFT OUTER JOIN tpa_user_contacts F ON (E.assigned_to_user = F.contact_seq_id)
             WHERE b.pat_gen_detail_seq_id = v_seq_id ;
       ELSE
         INSERT INTO Data_For_Coding_Search (policy_seq_id,         ins_seq_id,          tpa_office_seq_id,
                                             member_seq_id,         tpa_enrollment_id,   Clm_Enroll_Detail_Seq_Id,
                                             Claim_Seq_Id,          Claim_Number,        Claimant_Name,
                                             Date_Of_Admission,     Parent_Claim_Seq_Id, Rcvd_Date,
                                             Clm_Hosp_Assoc_Seq_Id, Hosp_Seq_Id,         Hosp_Name,
                                             Contact_Name,          Assigned_To_User,    Review_Count,
                                             Required_Review_Count, Event_Seq_Id,        Assign_Users_Seq_Id,
                                             Review_Completed_Yn,   Pre_Auth_Number ,    Pat_Enroll_Detail_Seq_Id,
                                             Ammendment_Yn,         Assigned_Yn,         work_flow)
         SELECT B.policy_seq_id,         b.ins_seq_id,          C.tpa_office_seq_id,
                B.member_seq_id,         B.tpa_enrollment_id,   B.clm_enroll_detail_seq_id,
                A.claim_seq_id,          A.claim_number,        b.claimant_name,
                A.date_of_admission,     a.parent_claim_seq_id, c.rcvd_date,
                H.clm_hosp_assoc_seq_id, H.Hosp_Seq_Id,         H.hosp_name ,
                F.contact_name,          E.assigned_to_user,    a.review_count,
                a.required_review_count, v_event_seq_id,        E.assign_users_seq_id,
                e.review_completed_yn,   G.auth_number ,        G.pat_enroll_detail_seq_id ,
                CASE WHEN a.parent_claim_seq_id IS NULL THEN 'N' ELSE 'Y' END ammendment_yn ,
                CASE WHEN a.review_count = 1 AND e.review_completed_yn = 'Y' THEN 'N' ELSE 'Y' END AS assigned_yn,
                'CLM'
           FROM clm_general_details A JOIN clm_enroll_details B ON (A.claim_seq_id = b.claim_seq_id)
                JOIN clm_inward C ON ( a.claims_inward_seq_id = c.claims_inward_seq_id)
                LEFT OUTER JOIN assign_users E ON (A.last_assign_user_seq_id   = E.assign_users_seq_id)
                LEFT OUTER JOIN tpa_user_contacts F ON (E.assigned_to_user = F.contact_seq_id)
                LEFT OUTER JOIN pat_enroll_details G ON (A.pat_enroll_detail_seq_id  = G.pat_enroll_detail_seq_id)
                LEFT OUTER JOIN clm_hospital_association H ON (A.claim_seq_id = H.claim_seq_id)
            WHERE a.claim_seq_id = v_seq_id;
       END IF;
  ELSIF v_flag = 'DELETE' THEN
      DELETE FROM Data_For_Coding_Search
        WHERE work_flow = v_workflow
          AND (pat_gen_detail_seq_id = v_seq_id OR claim_seq_id = v_seq_id);
  ELSE
      IF v_workflow = 'PAT' THEN
         UPDATE Data_For_Coding_Search
         SET (contact_name, assigned_to_user, review_count, required_review_count,
              assign_users_seq_id, review_completed_yn, assigned_yn) =
             (SELECT F.contact_name, E.assigned_to_user, b.review_count, b.required_review_count,
                     E.assign_users_seq_id, e.review_completed_yn,
                     CASE WHEN b.review_count = 1 AND e.review_completed_yn = 'Y' THEN 'N' ELSE 'Y' END AS assigned_yn
                FROM pat_general_details B
                     LEFT OUTER JOIN assign_users E ON (B.last_assign_user_seq_id  = E.assign_users_seq_id)
                     LEFT OUTER JOIN tpa_user_contacts F ON (E.assigned_to_user = F.contact_seq_id)
                  WHERE b.pat_gen_detail_seq_id = v_seq_id )
         WHERE work_flow = v_workflow
           AND pat_gen_detail_seq_id = v_seq_id;
      ELSIF v_workflow = 'CLM' THEN
         UPDATE Data_For_Coding_Search
         SET (contact_name, assigned_to_user, review_count, required_review_count,
              assign_users_seq_id, review_completed_yn, assigned_yn) =
             (SELECT F.contact_name, E.assigned_to_user, a.review_count, a.required_review_count,
                     E.assign_users_seq_id, e.review_completed_yn,
                     CASE WHEN a.review_count = 1 AND e.review_completed_yn = 'Y' THEN 'N' ELSE 'Y' END AS assigned_yn
                FROM clm_general_details A
                     LEFT OUTER JOIN assign_users E ON (A.last_assign_user_seq_id   = E.assign_users_seq_id)
                     LEFT OUTER JOIN tpa_user_contacts F ON (E.assigned_to_user = F.contact_seq_id)
                  WHERE a.claim_seq_id = v_seq_id)
         WHERE work_flow = v_workflow
           AND claim_seq_id = v_seq_id;
      END IF;
  END IF;

EXCEPTION
  WHEN NO_DATA_FOUND THEN
     raise_application_error (-20786,'Pre-auth/Claim is already under Coding Workflow.');
  WHEN DUP_VAL_ON_INDEX THEN
     raise_application_error (-20786,'Pre-auth/Claim is already under Coding Workflow.');
END save_coding_search;
--=============================================================================
end coding_pkg;

/

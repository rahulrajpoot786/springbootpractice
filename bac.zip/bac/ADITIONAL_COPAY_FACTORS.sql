--------------------------------------------------------
--  DDL for Synonymn ADITIONAL_COPAY_FACTORS
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."ADITIONAL_COPAY_FACTORS" FOR "APP"."ADITIONAL_COPAY_FACTORS";

--------------------------------------------------------
--  DDL for Synonymn CLM_CLM_HOSP_ASSOC_SEQ_ID
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."CLM_CLM_HOSP_ASSOC_SEQ_ID" FOR "APP"."CLM_CLM_HOSP_ASSOC_SEQ_ID";

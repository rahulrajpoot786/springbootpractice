--------------------------------------------------------
--  DDL for Synonymn CODE_CLEANUP_PKG
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."CODE_CLEANUP_PKG" FOR "APP"."CODE_CLEANUP_PKG";

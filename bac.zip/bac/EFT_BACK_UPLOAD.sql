--------------------------------------------------------
--  DDL for Synonymn EFT_BACK_UPLOAD
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."EFT_BACK_UPLOAD" FOR "INTX"."EFT_BACK_UPLOAD";

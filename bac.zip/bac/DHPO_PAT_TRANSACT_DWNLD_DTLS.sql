--------------------------------------------------------
--  DDL for Synonymn DHPO_PAT_TRANSACT_DWNLD_DTLS
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."DHPO_PAT_TRANSACT_DWNLD_DTLS" FOR "APP"."DHPO_PAT_TRANSACT_DWNLD_DTLS";

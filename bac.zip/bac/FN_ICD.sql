--------------------------------------------------------
--  DDL for Synonymn FN_ICD
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."FN_ICD" FOR "APP"."FN_ICD";

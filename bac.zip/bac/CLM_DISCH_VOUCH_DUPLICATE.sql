--------------------------------------------------------
--  DDL for Synonymn CLM_DISCH_VOUCH_DUPLICATE
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."CLM_DISCH_VOUCH_DUPLICATE" FOR "APP"."CLM_DISCH_VOUCH_DUPLICATE";

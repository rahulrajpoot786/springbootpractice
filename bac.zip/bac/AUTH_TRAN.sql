--------------------------------------------------------
--  DDL for Synonymn AUTH_TRAN
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."AUTH_TRAN" FOR "APP"."AUTH_TRAN";

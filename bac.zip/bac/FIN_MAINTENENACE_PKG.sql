--------------------------------------------------------
--  DDL for Synonymn FIN_MAINTENENACE_PKG
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."FIN_MAINTENENACE_PKG" FOR "APP"."FIN_MAINTENENACE_PKG";

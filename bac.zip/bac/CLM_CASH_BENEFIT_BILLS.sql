--------------------------------------------------------
--  DDL for Synonymn CLM_CASH_BENEFIT_BILLS
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."CLM_CASH_BENEFIT_BILLS" FOR "APP"."CLM_CASH_BENEFIT_BILLS";

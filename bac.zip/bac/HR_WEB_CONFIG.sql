--------------------------------------------------------
--  DDL for Procedure HR_WEB_CONFIG
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "VENUBABU"."HR_WEB_CONFIG" (v_policy_seq_id in number)
is
cursor select_policy_det is
SELECT pp.prod_policy_seq_id FROM tpa_enr_policy enr
join tpa_ins_prod_policy pp on (enr.policy_seq_id=pp.policy_seq_id)
where enr.policy_seq_id=v_policy_seq_id;


cursor select_max_rel_id is
select max(PROD_POL_REL_SEQ_ID) 
from app.tpa_prod_policy_relationship;

cursor rel_id is
select relship_type_id 
from app.tpa_ins_relationship_mapping 
where relship_type_id in ('NCH','NFR','YMO','YSP');

v_prod_policy_seq_id    number(10);
v_prod_pol_ref_id       number(10);

begin
---------relationship configuration
open select_policy_det;
  fetch select_policy_det into v_prod_policy_seq_id;
    close select_policy_det;

open select_max_rel_id;
  fetch select_max_rel_id into v_prod_pol_ref_id;
    close select_max_rel_id;    

for i in  rel_id loop  
    INSERT INTO app.tpa_prod_policy_relationship
    (PROD_POL_REL_SEQ_ID,PROD_POLICY_SEQ_ID,POLICY_SEQ_ID,RELSHIP_TYPE_ID,ADDED_BY,ADDED_DATE,RELSHIP_WINDOW_PERIOD,FROM_DATE_GENERAL_TYPE_ID,WP_RESTRICTION_YN)
    VALUES
    (tpa_prod_policy_relship_seq.NEXTVAL,v_prod_policy_seq_id,v_policy_seq_id,i.relship_type_id,1,sysdate,365,'EWA','Y');
end loop;

----MEMBER DETAILS configuration
--Age
insert into  APP.weblogin_policy_mem_config
(POLICY_MEM_CONFIG_SEQ_ID,POLICY_SEQ_ID,PROD_POLICY_SEQ_ID,POL_MEM_FIELD_TYPE_ID,FIELD_STATUS_GENERAL_TYPE_ID,ADDED_BY,ADDED_DATE)
values
(weblogin_mem_config_seq.NEXTVAL,v_policy_seq_id,v_prod_policy_seq_id,'AGE','MCS',1,sysdate);

--Date Of Birth
insert into  APP.weblogin_policy_mem_config
(POLICY_MEM_CONFIG_SEQ_ID,POLICY_SEQ_ID,PROD_POLICY_SEQ_ID,POL_MEM_FIELD_TYPE_ID,FIELD_STATUS_GENERAL_TYPE_ID,ADDED_BY,ADDED_DATE)
values
(weblogin_mem_config_seq.NEXTVAL,v_policy_seq_id,v_prod_policy_seq_id,'DOB','MCE',1,sysdate);

--Enrollment ID
insert into  APP.weblogin_policy_mem_config
(POLICY_MEM_CONFIG_SEQ_ID,POLICY_SEQ_ID,PROD_POLICY_SEQ_ID,POL_MEM_FIELD_TYPE_ID,FIELD_STATUS_GENERAL_TYPE_ID,ADDED_BY,ADDED_DATE)
values
(weblogin_mem_config_seq.NEXTVAL,v_policy_seq_id,v_prod_policy_seq_id,'EID','MCS',1,sysdate);

--Gender
insert into  APP.weblogin_policy_mem_config
(POLICY_MEM_CONFIG_SEQ_ID,POLICY_SEQ_ID,PROD_POLICY_SEQ_ID,POL_MEM_FIELD_TYPE_ID,FIELD_STATUS_GENERAL_TYPE_ID,ADDED_BY,ADDED_DATE)
values
(weblogin_mem_config_seq.NEXTVAL,v_policy_seq_id,v_prod_policy_seq_id,'GND','MCE',1,sysdate);

--Dependent Name
insert into  APP.weblogin_policy_mem_config
(POLICY_MEM_CONFIG_SEQ_ID,POLICY_SEQ_ID,PROD_POLICY_SEQ_ID,POL_MEM_FIELD_TYPE_ID,FIELD_STATUS_GENERAL_TYPE_ID,ADDED_BY,ADDED_DATE)
values
(weblogin_mem_config_seq.NEXTVAL,v_policy_seq_id,v_prod_policy_seq_id,'NME','MCE',1,sysdate);

--Relationship
insert into  APP.weblogin_policy_mem_config
(POLICY_MEM_CONFIG_SEQ_ID,POLICY_SEQ_ID,PROD_POLICY_SEQ_ID,POL_MEM_FIELD_TYPE_ID,FIELD_STATUS_GENERAL_TYPE_ID,ADDED_BY,ADDED_DATE)
values
(weblogin_mem_config_seq.NEXTVAL,v_policy_seq_id,v_prod_policy_seq_id,'RLS','MCE',1,sysdate);

--Member Type
insert into  APP.weblogin_policy_mem_config
(POLICY_MEM_CONFIG_SEQ_ID,POLICY_SEQ_ID,PROD_POLICY_SEQ_ID,POL_MEM_FIELD_TYPE_ID,FIELD_STATUS_GENERAL_TYPE_ID,ADDED_BY,ADDED_DATE)
values
(weblogin_mem_config_seq.NEXTVAL,v_policy_seq_id,v_prod_policy_seq_id,'SUB','MCS',1,sysdate);

--Sum Insured  
insert into  APP.weblogin_policy_mem_config
(POLICY_MEM_CONFIG_SEQ_ID,POLICY_SEQ_ID,PROD_POLICY_SEQ_ID,POL_MEM_FIELD_TYPE_ID,FIELD_STATUS_GENERAL_TYPE_ID,ADDED_BY,ADDED_DATE)
values
(weblogin_mem_config_seq.NEXTVAL,v_policy_seq_id,v_prod_policy_seq_id,'SUM','MCS',1,sysdate);


----------------web configuration
insert into APP.weblogin_config
(WEBCONFIG_SEQ_ID,PROD_POLICY_SEQ_ID,POLICY_SEQ_ID,MODIFICATION_ALLOWED_DAYS,GRP_CNT_ADD_GENERAL_TYPE_ID,
POLICY_DEFAULT_SUM_INSURED,OPD_LIMIT_SUM_INSURED,INCEPTION_DATE_GENERAL_TYPE_ID,ADD_SUM_INS_GENERAL_TYPE_ID,
GRP_CNT_CANCEL_GENERAL_TYPE_ID,SOFT_UPL_GENERAL_TYPE_ID,SEND_MAIL_GENERAL_TYPE_ID,ADDED_BY,ADDED_DATE,PWD_GENERAL_TYPE_ID,
WINDOW_PERIOD,INTIMATION_ACCESS_GEN_TYPE_ID,ONLINE_ASSISTANCE_GEN_TYPE_ID,ONLINE_RATING_GEN_TYPE_ID,
RELSHIP_COMB_GEN_TYPE_ID,DELETION_TIME_FRAME,WEBLOGINOPT_IN_OUT,GEN_TYPE_ID)
values
(weblogin_config_seq.NEXTVAL,v_prod_policy_seq_id,v_policy_seq_id,0,'WAB',0,0,'WDA','WSN','WCN','PSN','WMN',1,sysdate,'EPN',0,'IAN','OAI','ORN','RCN',0,'WSN','OGE');
COMMIT;
end;

/

--------------------------------------------------------
--  DDL for Synonymn DISPLAY_SEQ_NO
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."DISPLAY_SEQ_NO" FOR "APP"."DISPLAY_SEQ_NO";

--------------------------------------------------------
--  DDL for Synonymn IDX_CLAIMGENDET_LASTASGNSEQ
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."IDX_CLAIMGENDET_LASTASGNSEQ" FOR "APP"."IDX_CLAIMGENDET_LASTASGNSEQ";

--------------------------------------------------------
--  DDL for Synonymn AUDIT_XML_SEQ
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."AUDIT_XML_SEQ" FOR "APP"."AUDIT_XML_SEQ";

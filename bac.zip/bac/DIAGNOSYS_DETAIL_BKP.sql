--------------------------------------------------------
--  DDL for Synonymn DIAGNOSYS_DETAIL_BKP
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."DIAGNOSYS_DETAIL_BKP" FOR "APP"."DIAGNOSYS_DETAIL_BKP";

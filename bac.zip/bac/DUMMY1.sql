--------------------------------------------------------
--  DDL for Synonymn DUMMY1
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."DUMMY1" FOR "APP"."DUMMY1";

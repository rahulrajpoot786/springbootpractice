--------------------------------------------------------
--  DDL for Package Body FLOAT_ACCOUNTS_PKG
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "VENUBABU"."FLOAT_ACCOUNTS_PKG" IS
  --==============================================================================================
  v_dest_msg_seq_id VARCHAR2(250);
  FUNCTION get_Rej_billno(v_claim_seq_id IN NUMBER) RETURN VARCHAR2
    DETERMINISTIC IS
    v_str VARCHAR2(1000);
    v_ctr NUMBER(3) := 0;
  BEGIN
    FOR I IN (SELECT DISTINCT a.bill_no
                FROM clm_bill_header a
               INNER JOIN clm_bill_details C
                  ON (a.clm_bill_seq_id = C.clm_bill_seq_id)
               WHERE a.claim_seq_id = v_claim_seq_id
                 AND C.Rejected_Amount > 0) LOOP
      IF v_ctr = 0 THEN
        v_str := i.bill_no;
        v_ctr := v_ctr + 1;
      ELSE
        v_str := v_str || ',' || i.bill_no;
      END IF;
    END LOOP;
    RETURN v_str;
  END;
  --====================================================================================
  --this procedure is used to display list of float accounts from tpa_float_account.
  -- Created By  : Govardhan
  -- Modified by : S.V.Sreeraj on 08-feb-2007
  ------------------------------------------------
  /*PROCEDURE select_float_acc_list(
    v_float_acc_number       IN      TPA_FLOAT_ACCOUNT.float_account_number%TYPE,
    v_float_acc_name         IN      TPA_FLOAT_ACCOUNT.float_account_name%TYPE,
    v_float_type             IN      TPA_FLOAT_ACCOUNT.float_type%TYPE,
    v_float_status           IN      TPA_FLOAT_ACCOUNT.float_status%TYPE,
    v_office_seq_id          IN      TPA_OFFICE_INFO.tpa_office_seq_id%TYPE,
    v_bank_name              IN      TPA_BANK_MASTER.bank_name%TYPE,
    v_acc_number             IN      TPA_BANK_ACCOUNTS.account_number%TYPE,
    v_ins_seq_id             IN      TPA_INS_INFO.ins_seq_id %TYPE,
    v_ins_comp_code_number   IN      TPA_INS_INFO.ins_comp_code_number%TYPE,
    v_sort_var               IN      VARCHAR2,
    v_sort_order             IN      VARCHAR2,
    v_start_num              IN      NUMBER ,
    v_end_num                IN      NUMBER ,
    v_added_by               IN      NUMBER,
    result_set               OUT     SYS_REFCURSOR
  )
  IS
    v_sql_str                            VARCHAR2(4000);
    v_where                              VARCHAR2(4000);
    TYPE bind_tab_type IS TABLE OF VARCHAR2(250) INDEX BY BINARY_INTEGER ;
    bind_tab                             bind_tab_type;
    i                                    NUMBER(2) := 0;
  BEGIN
    v_sql_str :=
      'SELECT A.float_seq_id,
      A.float_account_number,
      A.float_account_name,
      E.ins_comp_name,
      E.ins_comp_code_number ins_comp_code_number,
      F.description status
      FROM tpa_float_account A LEFT OUTER JOIN tpa_bank_accounts B ON (A.bank_acc_seq_id = B.bank_acc_seq_id)
      LEFT OUTER JOIN tpa_office_info C ON (B.tpa_office_seq_id = C.tpa_office_seq_id)
      LEFT OUTER JOIN tpa_bank_master D ON (B.bank_seq_id = D.bank_seq_id)
      LEFT OUTER JOIN tpa_ins_info E ON (A.ins_seq_id = E.ins_seq_id)
      LEFT OUTER JOIN tpa_general_code F ON (A.float_status = F.general_type_id) ';
  
                --search by v_float_acc_number value
      IF (  v_float_acc_number ) IS NOT NULL THEN
        v_where := v_where || ' AND  A.float_account_number LIKE :v_float_acc_number ';
        i := i+1;
        bind_tab(i) := UPPER(v_float_acc_number)||'%';
      END IF;
        --search by v_float_acc_name value
      IF (  v_float_acc_name ) IS NOT NULL THEN
        v_where := v_where || ' AND A.float_account_name LIKE   :v_float_acc_name ';
        i := i+1;
        bind_tab(i) := UPPER (v_float_acc_name)||'%';
      END IF;
        --search by v_float_type value
      IF ( v_float_type ) IS NOT NULL THEN
        v_where := v_where || ' AND A.float_type = :v_float_type  ';
        i := i+1;
        bind_tab(i) := v_float_type;
      END IF;
        --search by v_float_status value
      IF (  v_float_status ) IS NOT NULL THEN
        v_where := v_where || ' AND A.float_status = :v_float_status  ';
        i := i+1;
        bind_tab(i) := v_float_status;
      END IF;
        --search by v_office_seq_id value
      IF (v_office_seq_id) IS NOT NULL THEN
        v_where := v_where || ' AND C.tpa_office_seq_id = :v_office_seq_id ';
        i := i+1;
        bind_tab(i) := v_office_seq_id;
      END IF;
         --search by v_bank_name value
      IF (v_bank_name  ) IS NOT NULL THEN
        v_where := v_where || ' AND  D.bank_name LIKE  :v_bank_name ';
        i := i+1;
        bind_tab(i) := UPPER (v_bank_name)||'%';
      END IF;
             --search by v_acc_number value
      IF ( v_acc_number )   IS NOT NULL THEN
        v_where := v_where || ' AND   B.account_number LIKE  :v_acc_number ';
        i := i+1;
        bind_tab(i) := v_acc_number||'%';
      END IF;
       --search by v_ins_seq_id value
      IF (v_ins_seq_id) IS NOT NULL THEN
        v_where := v_where || ' AND E.ins_head_office_seq_id = :v_ins_seq_id ';
        i := i+1;
        bind_tab(i) := v_ins_seq_id;
      END IF;
       --search by v_ins_comp_code_number value
      IF (v_ins_comp_code_number) IS NOT NULL THEN
        v_where := v_where || ' AND e.ins_comp_code_number LIKE :v_ins_comp_code_number';
        i := i+1;
        bind_tab(i) := UPPER(v_ins_comp_code_number)||'%';
      END IF;
      v_where := v_where ||' AND A.deleted_yn = ''N''';
      v_sql_str   := v_sql_str ||' WHERE '|| SUBSTR(v_where,5);
  
      v_sql_str := 'SELECT * FROM
                     (SELECT A.*,DENSE_RANK() OVER (ORDER BY '||v_sort_var||' '||v_sort_order||',ROWNUM)
                      Q FROM (' ||v_sql_str|| ') A ) WHERE  Q>= :v_start_num AND Q<= :v_end_num ';
  
     IF bind_tab.FIRST IS NOT NULL THEN
       CASE bind_tab.COUNT
           WHEN 1  THEN OPEN result_set FOR v_sql_str USING bind_tab(1) ,v_start_num , v_end_num ;
           WHEN 2  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),v_start_num , v_end_num  ;
           WHEN 3  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2) ,bind_tab(3) ,v_start_num , v_end_num ;
           WHEN 4  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,v_start_num , v_end_num ;
           WHEN 5  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5) ,v_start_num , v_end_num ;
           WHEN 6  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6) ,v_start_num , v_end_num ;
           WHEN 7  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6),bind_tab(7) ,v_start_num , v_end_num ;
           WHEN 8  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6),bind_tab(7),bind_tab(8) ,v_start_num , v_end_num ;
           WHEN 9  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6),bind_tab(7),bind_tab(8) ,bind_tab(9),v_start_num , v_end_num ;
       END CASE;
     ELSE
       OPEN result_set FOR v_sql_str USING v_start_num , v_end_num ;
     END IF;
  
  END select_float_acc_list;*/

  PROCEDURE select_float_acc_list(v_float_acc_number     IN TPA_FLOAT_ACCOUNT.float_account_number%TYPE,
                                  v_float_acc_name       IN TPA_FLOAT_ACCOUNT.float_account_name%TYPE,
                                  v_float_type           IN TPA_FLOAT_ACCOUNT.float_type%TYPE,
                                  v_float_status         IN TPA_FLOAT_ACCOUNT.float_status%TYPE,
                                  v_office_seq_id        IN TPA_OFFICE_INFO.tpa_office_seq_id%TYPE,
                                  v_bank_name            IN TPA_BANK_MASTER.bank_name%TYPE,
                                  v_acc_number           IN TPA_BANK_ACCOUNTS.account_number%TYPE,
                                  v_ins_seq_id           IN TPA_INS_INFO.ins_seq_id %TYPE,
                                  v_ins_comp_code_number IN TPA_INS_INFO.ins_comp_code_number%TYPE,
                                  v_claim_settlement_no  IN TPA_CLAIMS_PAYMENT.claim_settlement_no%TYPE,
                                  v_sort_var             IN VARCHAR2,
                                  v_sort_order           IN VARCHAR2,
                                  v_start_num            IN NUMBER,
                                  v_end_num              IN NUMBER,
                                  v_added_by             IN NUMBER,
                                  result_set             OUT SYS_REFCURSOR) IS
    v_sql_str VARCHAR2(4000);
    v_where   VARCHAR2(4000);
    TYPE bind_tab_type IS TABLE OF VARCHAR2(250) INDEX BY BINARY_INTEGER;
    bind_tab bind_tab_type;
    i        NUMBER(2) := 0;
  
    CURSOR settlement_cur IS
      SELECT DISTINCT a.float_seq_id
        FROM tpa_claims_payment A
       WHERE a.claim_settlement_no = v_claim_settlement_no;
  
    v_float_seq_id TPA_FLOAT_ACCOUNT.float_seq_id%TYPE;
  
  BEGIN
    v_sql_str := 'SELECT A.float_seq_id,
      A.float_account_number,
      A.float_account_name,
      E.ins_comp_name,
      E.ins_comp_code_number ins_comp_code_number,
      F.description status
      FROM TPA_FLOAT_ACCOUNT A LEFT OUTER JOIN TPA_BANK_ACCOUNTS B ON (A.bank_acc_seq_id = B.bank_acc_seq_id)
      LEFT OUTER JOIN TPA_OFFICE_INFO C ON (B.tpa_office_seq_id = C.tpa_office_seq_id)
      LEFT OUTER JOIN TPA_BANK_MASTER D ON (B.bank_seq_id = D.bank_seq_id)
      LEFT OUTER JOIN TPA_INS_INFO E ON (A.ins_seq_id = E.ins_seq_id)
      LEFT OUTER JOIN TPA_GENERAL_CODE F ON (A.float_status = F.general_type_id) ';
  
    --search by v_float_acc_number value
  
    IF v_claim_settlement_no IS NOT NULL THEN
      OPEN settlement_cur;
      FETCH settlement_cur
        INTO v_float_seq_id;
      CLOSE settlement_cur;
    
      v_where := v_where || ' AND A.float_seq_id = :v_float_seq_id';
      i := i + 1;
      bind_tab(i) := nvl(v_float_seq_id, 0);
    
    END IF;
  
    IF (v_float_acc_number) IS NOT NULL THEN
      v_where := v_where ||
                 ' AND  A.float_account_number LIKE :v_float_acc_number ';
      i := i + 1;
      bind_tab(i) := UPPER(v_float_acc_number) || '%';
    END IF;
    --search by v_float_acc_name value
    IF (v_float_acc_name) IS NOT NULL THEN
      v_where := v_where ||
                 ' AND A.float_account_name LIKE   :v_float_acc_name ';
      i := i + 1;
      bind_tab(i) := UPPER(v_float_acc_name) || '%';
    END IF;
    --search by v_float_type value
    IF (v_float_type) IS NOT NULL THEN
      v_where := v_where || ' AND A.float_type = :v_float_type  ';
      i := i + 1;
      bind_tab(i) := v_float_type;
    END IF;
    --search by v_float_status value
    IF (v_float_status) IS NOT NULL THEN
      v_where := v_where || ' AND A.float_status = :v_float_status  ';
      i := i + 1;
      bind_tab(i) := v_float_status;
    END IF;
    --search by v_office_seq_id value
    IF (v_office_seq_id) IS NOT NULL THEN
      v_where := v_where || ' AND C.tpa_office_seq_id = :v_office_seq_id ';
      i := i + 1;
      bind_tab(i) := v_office_seq_id;
    END IF;
    --search by v_bank_name value
    IF (v_bank_name) IS NOT NULL THEN
      v_where := v_where || ' AND  D.bank_name LIKE  :v_bank_name ';
      i := i + 1;
      bind_tab(i) := UPPER(v_bank_name) || '%';
    END IF;
    --search by v_acc_number value
    IF (v_acc_number) IS NOT NULL THEN
      v_where := v_where || ' AND   B.account_number LIKE  :v_acc_number ';
      i := i + 1;
      bind_tab(i) := v_acc_number || '%';
    END IF;
    --search by v_ins_seq_id value
    IF (v_ins_seq_id) IS NOT NULL THEN
      v_where := v_where ||
                 ' AND E.ins_head_office_seq_id = :v_ins_seq_id ';
      i := i + 1;
      bind_tab(i) := v_ins_seq_id;
    END IF;
    --search by v_ins_comp_code_number value
    IF (v_ins_comp_code_number) IS NOT NULL THEN
      v_where := v_where ||
                 ' AND e.ins_comp_code_number LIKE :v_ins_comp_code_number';
      i := i + 1;
      bind_tab(i) := UPPER(v_ins_comp_code_number) || '%';
    END IF;
  
    v_where   := v_where || ' AND A.deleted_yn = ''N''';
    v_sql_str := v_sql_str || ' WHERE ' || SUBSTR(v_where, 5);
  
    v_sql_str := 'SELECT * FROM
                     (SELECT A.*,DENSE_RANK() OVER (ORDER BY ' ||
                 v_sort_var || ' ' || v_sort_order ||
                 ',ROWNUM)
                      Q FROM (' || v_sql_str ||
                 ') A ) WHERE  Q>= :v_start_num AND Q<= :v_end_num ';
  
    IF bind_tab.FIRST IS NOT NULL THEN
      CASE bind_tab.COUNT
        WHEN 1 THEN
          OPEN result_set FOR v_sql_str
            USING bind_tab(1), v_start_num, v_end_num;
        WHEN 2 THEN
          OPEN result_set FOR v_sql_str
            USING bind_tab(1), bind_tab(2), v_start_num, v_end_num;
        WHEN 3 THEN
          OPEN result_set FOR v_sql_str
            USING bind_tab(1), bind_tab(2), bind_tab(3), v_start_num, v_end_num;
        WHEN 4 THEN
          OPEN result_set FOR v_sql_str
            USING bind_tab(1), bind_tab(2), bind_tab(3), bind_tab(4), v_start_num, v_end_num;
        WHEN 5 THEN
          OPEN result_set FOR v_sql_str
            USING bind_tab(1), bind_tab(2), bind_tab(3), bind_tab(4), bind_tab(5), v_start_num, v_end_num;
        WHEN 6 THEN
          OPEN result_set FOR v_sql_str
            USING bind_tab(1), bind_tab(2), bind_tab(3), bind_tab(4), bind_tab(5), bind_tab(6), v_start_num, v_end_num;
        WHEN 7 THEN
          OPEN result_set FOR v_sql_str
            USING bind_tab(1), bind_tab(2), bind_tab(3), bind_tab(4), bind_tab(5), bind_tab(6), bind_tab(7), v_start_num, v_end_num;
        WHEN 8 THEN
          OPEN result_set FOR v_sql_str
            USING bind_tab(1), bind_tab(2), bind_tab(3), bind_tab(4), bind_tab(5), bind_tab(6), bind_tab(7), bind_tab(8), v_start_num, v_end_num;
        WHEN 9 THEN
          OPEN result_set FOR v_sql_str
            USING bind_tab(1), bind_tab(2), bind_tab(3), bind_tab(4), bind_tab(5), bind_tab(6), bind_tab(7), bind_tab(8), bind_tab(9), v_start_num, v_end_num;
        WHEN 10 THEN
          OPEN result_set FOR v_sql_str
            USING bind_tab(1), bind_tab(2), bind_tab(3), bind_tab(4), bind_tab(5), bind_tab(6), bind_tab(7), bind_tab(8), bind_tab(9), bind_tab(10), v_start_num, v_end_num;
      END CASE;
    ELSE
      OPEN result_set FOR v_sql_str
        USING v_start_num, v_end_num;
    END IF;
  
  END select_float_acc_list;
  --============================================
  -- modified by s.v.sreeraj,  on 05-jun-2008
  /*PROCEDURE select_float_acc_detail (
      v_float_seq_id        IN  OUT TPA_FLOAT_ACCOUNT.float_seq_id%TYPE,
      v_added_by            IN      NUMBER,
      result_set            OUT     SYS_REFCURSOR
    )
    IS
      v_office_type                  TPA_BANK_MASTER.Office_Type%TYPE;
      v_bank_seq_id                  TPA_BANK_MASTER.bank_seq_id%TYPE;
      v_flag                         NUMBER(5);
      v_result                       VARCHAR2(1);
    BEGIN
      --getting office type for the respective bank.
  
      SELECT office_type INTO v_office_type
        FROM tpa_bank_master A JOIN tpa_bank_accounts B ON (a.bank_seq_id = b.bank_seq_id)
        JOIN tpa_float_account c ON (b.bank_acc_seq_id = c.bank_acc_seq_id )
        WHERE c.float_seq_id = v_float_seq_id ;
  
      --query gives info whether transactions exists or not to this float account.
      SELECT COUNT(1) INTO v_flag
        FROM  tpa_float_transaction A  WHERE a.float_seq_id = v_float_seq_id;
  
      IF  v_flag = 0 THEN
        --this will gives true if payments exixts for this account it true then hide insurance icon in general float screen.
        SELECT COUNT(1) INTO v_flag
          FROM tpa_claims_payment a
          WHERE a.float_seq_id = v_float_seq_id
          AND a.claim_payment_status = 'PENDING';
      END IF;
             --if Transaction exists Then Return 'Y' Else 'N'
      IF ( v_flag >= 1) THEN
        v_result := 'Y';
      ELSE
        v_result := 'N';
      END IF;
        --to display head office details
  
      OPEN result_set FOR
         SELECT  A.float_seq_id,
            A.float_type,
            v_result AS v_result,
            A.float_account_number,
            A.float_account_name,
            A.float_status,
            A.effective_date,
            A.expiration_date,
            A.bank_acc_seq_id,
            B.account_number,
            B.account_name,
            F.office_name,
  --          c.bank_name,
            CASE WHEN C.HO_ID IS NULL THEN c.bank_name ELSE CC.bank_name||'|'||C.bank_name END AS bank_name,
            D.ins_seq_id,
            D.ins_comp_name,
            D.ins_comp_code_number,
            A.group_reg_seq_id,
            G.group_id,
            G.group_name,
            A.established_amt,
            A.current_balance,
            A.comments,
            H.Description office_type,
            J.description AS ins_office_type,
            K.office_name AS ins_office_name,
            a.prod_general_type_id
            FROM tpa_float_account A JOIN tpa_bank_accounts B ON (A.bank_acc_seq_id = B.bank_acc_seq_id)
            JOIN tpa_bank_master C ON (b.bank_seq_id = c.bank_seq_id)  -- new
            LEFT OUTER JOIN tpa_bank_master CC ON (C.ho_id = Cc.bank_seq_id) -- new
            JOIN tpa_ins_info D ON (A.ins_seq_id = D.ins_seq_id)
            LEFT OUTER JOIN tpa_general_code E ON (A.float_status=E.general_type_id)
            LEFT OUTER JOIN tpa_office_info F ON (B.tpa_office_seq_id=F.tpa_office_seq_id)
            LEFT OUTER JOIN tpa_group_registration G ON (A.group_reg_seq_id=G.group_reg_seq_id)
            LEFT OUTER JOIN tpa_general_code H ON (C.office_type = H.general_type_id)
            LEFT OUTER JOIN tpa_general_code J ON (D.INS_OFFICE_GENERAL_TYPE_ID = J.general_type_id)
            LEFT OUTER JOIN tpa_office_info K ON D.tpa_office_seq_id = K.tpa_office_seq_id
            WHERE A.float_seq_id = v_float_seq_id;
    END select_float_acc_detail;*/

  PROCEDURE select_float_acc_detail(v_float_seq_id IN OUT TPA_FLOAT_ACCOUNT.float_seq_id%TYPE,
                                    v_added_by     IN NUMBER,
                                    result_set     OUT SYS_REFCURSOR,
                                    corporate_list OUT SYS_REFCURSOR) IS
    v_office_type TPA_BANK_MASTER.Office_Type%TYPE;
    v_bank_seq_id TPA_BANK_MASTER.bank_seq_id%TYPE;
    v_flag        NUMBER(5);
    v_result      VARCHAR2(1);
  BEGIN
    --getting office type for the respective bank.
  
    SELECT office_type
      INTO v_office_type
      FROM tpa_bank_master A
      JOIN tpa_bank_accounts B
        ON (a.bank_seq_id = b.bank_seq_id)
      JOIN tpa_float_account c
        ON (b.bank_acc_seq_id = c.bank_acc_seq_id)
     WHERE c.float_seq_id = v_float_seq_id;
  
    --query gives info whether transactions exists or not to this float account.
    SELECT COUNT(1)
      INTO v_flag
      FROM tpa_float_transaction A
     WHERE a.float_seq_id = v_float_seq_id;
  
    IF v_flag = 0 THEN
      --this will gives true if payments exixts for this account it true then hide insurance icon in general float screen.
      SELECT COUNT(1)
        INTO v_flag
        FROM tpa_claims_payment a
       WHERE a.float_seq_id = v_float_seq_id
         AND a.claim_payment_status = 'PENDING';
    END IF;
    --if Transaction exists Then Return 'Y' Else 'N'
    IF (v_flag >= 1) THEN
      v_result := 'Y';
    ELSE
      v_result := 'N';
    END IF;
    --to display head office details

    OPEN result_set FOR
      SELECT A.float_seq_id,
             A.float_type,
             v_result AS v_result,
             A.float_account_number,
             A.float_account_name,
             A.float_status,
             A.effective_date,
             A.expiration_date,
             A.bank_acc_seq_id,
             B.account_number,
             B.account_name,
             F.office_name,
             CASE
               WHEN C.HO_ID IS NULL THEN
                c.bank_name
               ELSE
                CC.bank_name || '|' || C.bank_name
             END AS bank_name,
             D.ins_seq_id,
             D.ins_comp_name,
             D.ins_comp_code_number,
             A.group_reg_seq_id,
             A.established_amt,
             A.current_balance,
             A.comments,
             H.Description office_type,
             J.description AS ins_office_type,
             K.office_name AS ins_office_name,
             a.prod_general_type_id,
             NVL(process_type,'RGL') AS process_type
        FROM tpa_float_account A
        JOIN tpa_bank_accounts B
          ON (A.bank_acc_seq_id = B.bank_acc_seq_id)
        JOIN tpa_bank_master C
          ON (b.bank_seq_id = c.bank_seq_id) -- new
        LEFT OUTER JOIN tpa_bank_master CC
          ON (C.ho_id = Cc.bank_seq_id) -- new
        JOIN tpa_ins_info D
          ON (A.ins_seq_id = D.ins_seq_id)
        LEFT OUTER JOIN tpa_general_code E
          ON (A.float_status = E.general_type_id)
        LEFT OUTER JOIN tpa_office_info F
          ON (B.tpa_office_seq_id = F.tpa_office_seq_id)
        LEFT OUTER JOIN tpa_group_registration G
          ON (A.group_reg_seq_id = G.group_reg_seq_id)
        LEFT OUTER JOIN tpa_general_code H
          ON (C.office_type = H.general_type_id)
        LEFT OUTER JOIN tpa_general_code J
          ON (D.INS_OFFICE_GENERAL_TYPE_ID = J.general_type_id)
        LEFT OUTER JOIN tpa_office_info K
          ON D.tpa_office_seq_id = K.tpa_office_seq_id
       WHERE A.float_seq_id = v_float_seq_id;

    OPEN corporate_list FOR
      SELECT a.tpa_float_group_assoc_seq,
             b.group_reg_seq_id,
             b.group_id,
             b.group_name,
             a.policy_number as policy_no
        FROM tpa_float_group_assoc a
        JOIN tpa_group_registration b
          ON (a.group_reg_seq_id = b.group_reg_seq_id)
       WHERE a.float_seq_id = v_float_seq_id;
  END select_float_acc_detail;

  --===========================================================================================
  --this procedure is used to insert/update a record from tpa_float_account.
  /*PROCEDURE float_acc_save(
      v_float_seq_id         IN OUT TPA_FLOAT_ACCOUNT.float_seq_id%TYPE,
      v_float_type           IN  TPA_FLOAT_ACCOUNT.float_type%TYPE,
      v_float_acc_name       IN  TPA_FLOAT_ACCOUNT.float_account_name%TYPE,
      v_float_status         IN  TPA_FLOAT_ACCOUNT.float_status%TYPE,
      v_effective_date       IN  TPA_FLOAT_ACCOUNT.effective_date%TYPE,
      v_expiration_date      IN  TPA_FLOAT_ACCOUNT.expiration_date%TYPE,
      v_bank_acc_seq_id      IN  TPA_FLOAT_ACCOUNT.bank_acc_seq_id%TYPE,
      v_ins_seq_id           IN  TPA_FLOAT_ACCOUNT.ins_seq_id%TYPE,
      v_group_reg_seq_id     IN  TPA_FLOAT_ACCOUNT.group_reg_seq_id%TYPE,
      v_established_amt      IN  TPA_FLOAT_ACCOUNT.established_amt%TYPE,
      v_comments             IN  TPA_FLOAT_ACCOUNT.comments%TYPE,
      v_prod_general_type_id IN  TPA_FLOAT_ACCOUNT.prod_general_type_id%TYPE,
      v_added_by             IN  NUMBER,
      v_row_processed        OUT INTEGER
    )
    IS
      v_current_balance_regular NUMBER(12,2) := 0;
  --    v_current_balance_debit   NUMBER(12,2) := 0;
      v_count                   NUMBER(5) ;
      v_flag                    NUMBER(5) ;
      p_current_balance         NUMBER(12,2);
      v_acc_status              VARCHAR2(4);
      v_closed_date_check       NUMBER(5);
      v_trn_date                DATE;
      e_float_acc_num_same_bank   EXCEPTION;
      PRAGMA EXCEPTION_INIT (e_float_acc_num_same_bank, -00001);
    BEGIN
  
      IF v_float_status = 'ASA' THEN
        SELECT COUNT(1) INTO v_count
         FROM tpa_float_account
         WHERE ins_seq_id = v_ins_seq_id AND nvl(group_reg_seq_id,0) = nvl(v_group_reg_seq_id,0)
         AND nvl(prod_general_type_id,0) = nvl(v_prod_general_type_id,0)  AND float_status IN ('ASA') AND float_seq_id != v_float_seq_id;
  
       IF v_count > 0 THEN
         RAISE_APPLICATION_ERROR(-20227,'you cannot create more than one float account for same insurance unless status is active');
       END IF;
     END IF;
           --flag zero
       IF (v_float_seq_id) = 0 THEN
            --dont allow to create to open an float account to the same insurance comp if float status in active
         SELECT COUNT(1) INTO v_count
           FROM tpa_float_account
           WHERE ins_seq_id = v_ins_seq_id AND nvl(group_reg_seq_id,0) = nvl(v_group_reg_seq_id,0)
           AND nvl(prod_general_type_id,0) = nvl(v_prod_general_type_id,0)  AND  float_status IN ('ASA');
         IF v_count > 0 THEN
           RAISE_APPLICATION_ERROR(-20227,'you cannot create more than one float account for same insurance unless status is active');
         END IF;

            --float account Should be opened for Active Accoutns
         SELECT A.account_status INTO v_acc_status
           FROM tpa_bank_accounts A
           WHERE A.bank_acc_seq_id = v_bank_acc_seq_id;
              --if Account Is Active
         IF (v_acc_status = 'ASA') THEN
          -- if float_type  is regular then
           IF (v_float_type = 'FTR') THEN   -- FTR -- regular
             v_current_balance_regular := 0;
           ELSE
             v_current_balance_regular := 0;
           END IF;
           INSERT INTO tpa_float_account(
            float_seq_id,
            float_type,
            float_account_number,
            float_account_name,
            float_status,
            effective_date,
            bank_acc_seq_id,
            ins_seq_id,
            group_reg_seq_id,
            current_balance,
            established_amt,
            comments,
            prod_general_type_id,
            added_by,
            added_date)
          VALUES(
            float_acc_seq.NEXTVAL,
            v_float_type ,
            'FL'||'-'||'ACC'||'-'||float_acc_num_seq.Nextval,
            v_float_acc_name,
            v_float_status ,
            SYSDATE,
            v_bank_acc_seq_id ,
            v_ins_seq_id ,
            v_group_reg_seq_id,
            v_current_balance_regular,
            v_established_amt,
            v_comments,
            v_prod_general_type_id,
            v_added_by,
            SYSDATE) RETURNING float_seq_id INTO v_float_seq_id ;
         ELSE
           RAISE_APPLICATION_ERROR(-20238,'cannot create a float account for closed bank account.');
         END IF;
      ELSE
         --this ACTIVE AND INACTIVE STATUS IS CHEQUED FOR PAYMENTS STILL PENDING BUT INSURANCE COMPANY CANNOT BE CHANGED.
        IF ( v_float_status = 'ASC' ) THEN
               --checking the payments are existed for this float_account.
           SELECT COUNT(1) INTO v_flag
             FROM tpa_claims_payment a   WHERE a.float_seq_id = v_float_seq_id  AND a.claim_payment_status = 'PENDING';
           --closed date should be greater or equal of then recent transaction date.
           SELECT TO_DATE(NVL(MAX(b.flt_trn_date),SYSDATE),'DD/MM/YYYY') INTO v_trn_date
             FROM tpa_float_transaction b  WHERE b.float_seq_id = v_float_seq_id ;
          --CHECK THE MAX CLEARED DATE <= ACCOUNT CLOSED DATE
           IF (v_flag >= 1) THEN
              RAISE_APPLICATION_ERROR(-20205,'You cannot close the float Account, payment(S) is exist.' );
           ELSE
             IF (to_date (v_expiration_date,'dd/mm/yyyy') >= v_trn_date )  THEN
          --this is used to check closed date should be greater or equal to open date.
                SELECT COUNT(1) INTO v_closed_date_check
                  FROM TPA_FLOAT_ACCOUNT A
                  WHERE TO_DATE(A.effective_date,'DD/MM/YYYY') <= TO_DATE(v_expiration_date,'DD/MM/YYYY')
                  AND float_seq_id = v_float_seq_id ;

                IF (v_closed_date_check = 1) THEN
                --validate the float balance =0 or not
                   SELECT current_balance INTO p_current_balance
                      FROM tpa_float_account WHERE float_seq_id = v_float_seq_id ;

                   --float_balance should be zero then allow to close account
                   IF (p_current_balance = 0) THEN
                       UPDATE tpa_float_account SET
                             float_type           = v_float_type,
                             float_account_name   = v_float_acc_name,
                             float_status         = v_float_status ,
                             expiration_date      = v_expiration_date,
                             bank_acc_seq_id      = v_bank_acc_seq_id,
                             ins_seq_id           = v_ins_seq_id,
                             group_reg_seq_id     = v_group_reg_seq_id,
                             established_amt      = v_established_amt,
                             comments             = v_comments,
                             prod_general_type_id = v_prod_general_type_id,
                             updated_by           = v_added_by,
                             updated_date         = SYSDATE
                             WHERE float_seq_id = v_float_seq_id ;

                   ELSE--if balance is value or negative  show the error message.
                     RAISE_APPLICATION_ERROR(-20235,'cannot close the account float balance is exists.');
                   END IF;
                 ELSE
                   RAISE_APPLICATION_ERROR(-20240,'Account Closed Date Should be Greater then Account Open Date.');
                 END IF;
               ELSE
                 RAISE_APPLICATION_ERROR(-20230,'Bank Closed date cannot be lesser than Transaction(s) date. ');
               END IF;
             END IF;
          ELSE
             UPDATE tpa_float_account SET
                 float_type          = v_float_type,
                 float_account_name  = v_float_acc_name,
                 float_status        = v_float_status,
                 bank_acc_seq_id     = v_bank_acc_seq_id,
                 ins_seq_id          = v_ins_seq_id,
                 group_reg_seq_id    = v_group_reg_seq_id,
                 established_amt     = v_established_amt,
                 comments            = v_comments  ,
                 prod_general_type_id = v_prod_general_type_id,
                 updated_by          = v_added_by,
                 updated_date        = SYSDATE
                 WHERE float_seq_id  = v_float_seq_id;
          END IF;
          --number of rows updated/inserted
          v_row_processed := SQL%ROWCOUNT;
          COMMIT;
      END IF ;
      --CALL THE SCHEDULER TO SETTLE PAYMENTS INSTANT
      float_accounts_pkg.float_accnts_unsettld_clm();
      EXCEPTION
         WHEN e_float_acc_num_same_bank  THEN
            RAISE_APPLICATION_ERROR(-20242,'Same Float Account Number/Account Name cannot be Duplicated.');
    END float_acc_save;*/
  PROCEDURE float_acc_save(v_float_seq_id         IN OUT TPA_FLOAT_ACCOUNT.float_seq_id%TYPE,
                           v_float_type           IN TPA_FLOAT_ACCOUNT.float_type%TYPE,
                           v_float_acc_name       IN TPA_FLOAT_ACCOUNT.float_account_name%TYPE,
                           v_float_status         IN TPA_FLOAT_ACCOUNT.float_status%TYPE,
                           v_effective_date       IN TPA_FLOAT_ACCOUNT.effective_date%TYPE,
                           v_expiration_date      IN TPA_FLOAT_ACCOUNT.expiration_date%TYPE,
                           v_bank_acc_seq_id      IN TPA_FLOAT_ACCOUNT.bank_acc_seq_id%TYPE,
                           v_ins_seq_id           IN TPA_FLOAT_ACCOUNT.ins_seq_id%TYPE,
                           v_group_reg_seq_id     IN TPA_FLOAT_ACCOUNT.group_reg_seq_id%TYPE,
                           v_established_amt      IN TPA_FLOAT_ACCOUNT.established_amt%TYPE,
                           v_comments             IN TPA_FLOAT_ACCOUNT.comments%TYPE,
                           v_prod_general_type_id IN TPA_FLOAT_ACCOUNT.prod_general_type_id%TYPE,
                           v_added_by             IN NUMBER,
                           v_process_type         IN TPA_FLOAT_ACCOUNT.PROCESS_TYPE%TYPE,
                           v_row_processed        OUT INTEGER) IS
    v_current_balance_regular NUMBER(12, 2) := 0;
    v_count                   NUMBER(5);
    v_flag                    NUMBER(5);
    p_current_balance         NUMBER(12, 2);
    v_acc_status              VARCHAR2(4);
    v_closed_date_check       NUMBER(5);
    v_trn_date                DATE;
    e_float_acc_num_same_bank EXCEPTION;
    PRAGMA EXCEPTION_INIT(e_float_acc_num_same_bank, -00001);
  BEGIN
    --flag zero
    IF (v_float_seq_id) = 0 THEN
      --float account Should be opened for Active Accoutns
      SELECT A.account_status
        INTO v_acc_status
        FROM tpa_bank_accounts A
       WHERE A.bank_acc_seq_id = v_bank_acc_seq_id;
      --if Account Is Active
      IF (v_acc_status = 'ASA') THEN
        -- if float_type  is regular then
        IF (v_float_type = 'FTR') THEN
          -- FTR -- regular
          v_current_balance_regular := 0;
        ELSE
          v_current_balance_regular := 0;
        END IF;
        INSERT INTO tpa_float_account
          (float_seq_id,
           float_type,
           float_account_number,
           float_account_name,
           float_status,
           effective_date,
           bank_acc_seq_id,
           ins_seq_id,
           current_balance,
           established_amt,
           comments,
           prod_general_type_id,
           added_by,
           added_date,
           process_type)
        VALUES
          (float_acc_seq.NEXTVAL,
           v_float_type,
           'FL' || '-' || 'ACC' || '-' || float_acc_num_seq.Nextval,
           v_float_acc_name,
           v_float_status,
           SYSDATE,
           v_bank_acc_seq_id,
           v_ins_seq_id,
           v_current_balance_regular,
           v_established_amt,
           v_comments,
           v_prod_general_type_id,
           v_added_by,
           SYSDATE,
           NVL(v_process_type,'RGL'))
        RETURNING float_seq_id INTO v_float_seq_id;
      ELSE
        RAISE_APPLICATION_ERROR(-20238,
                                'cannot create a float account for closed bank account.');
      END IF;
    ELSE
      --this ACTIVE AND INACTIVE STATUS IS CHEQUED FOR PAYMENTS STILL PENDING BUT INSURANCE COMPANY CANNOT BE CHANGED.
      IF (v_float_status = 'ASC') THEN
        --checking the payments are existed for this float_account.
        SELECT COUNT(1)
          INTO v_flag
          FROM tpa_claims_payment a
         WHERE a.float_seq_id = v_float_seq_id
           AND a.claim_payment_status = 'PENDING';
        --closed date should be greater or equal of then recent transaction date.
        SELECT TO_DATE(NVL(MAX(b.flt_trn_date), SYSDATE), 'DD/MM/YYYY')
          INTO v_trn_date
          FROM tpa_float_transaction b
         WHERE b.float_seq_id = v_float_seq_id;
        --CHECK THE MAX CLEARED DATE <= ACCOUNT CLOSED DATE
        IF (v_flag >= 1) THEN
          RAISE_APPLICATION_ERROR(-20205,
                                  'You cannot close the float Account, payment(S) is exist.');
        ELSE
          IF (to_date(v_expiration_date, 'dd/mm/yyyy') >= v_trn_date) THEN
            --this is used to check closed date should be greater or equal to open date.
            SELECT COUNT(1)
              INTO v_closed_date_check
              FROM TPA_FLOAT_ACCOUNT A
             WHERE TO_DATE(A.effective_date, 'DD/MM/YYYY') <=
                   TO_DATE(v_expiration_date, 'DD/MM/YYYY')
               AND float_seq_id = v_float_seq_id;

            IF (v_closed_date_check = 1) THEN
              --validate the float balance =0 or not
              SELECT current_balance
                INTO p_current_balance
                FROM tpa_float_account
               WHERE float_seq_id = v_float_seq_id;

              --float_balance should be zero then allow to close account
              IF (p_current_balance = 0) THEN
                UPDATE tpa_float_account
                   SET float_type           = v_float_type,
                       float_account_name   = v_float_acc_name,
                       float_status         = v_float_status,
                       expiration_date      = v_expiration_date,
                       bank_acc_seq_id      = v_bank_acc_seq_id,
                       ins_seq_id           = v_ins_seq_id,
                       established_amt      = v_established_amt,
                       comments             = v_comments,
                       prod_general_type_id = v_prod_general_type_id,
                       updated_by           = v_added_by,
                       updated_date         = SYSDATE,
                       process_type         = NVL(v_process_type,'RGL')
                 WHERE float_seq_id = v_float_seq_id;

              ELSE
                --if balance is value or negative  show the error message.
                RAISE_APPLICATION_ERROR(-20235,
                                        'cannot close the account float balance is exists.');
              END IF;
            ELSE
              RAISE_APPLICATION_ERROR(-20240,
                                      'Account Closed Date Should be Greater then Account Open Date.');
            END IF;
          ELSE
            RAISE_APPLICATION_ERROR(-20230,
                                    'Bank Closed date cannot be lesser than Transaction(s) date. ');
          END IF;
        END IF;
      ELSE
        UPDATE tpa_float_account
           SET float_type           = v_float_type,
               float_account_name   = v_float_acc_name,
               float_status         = v_float_status,
               bank_acc_seq_id      = v_bank_acc_seq_id,
               ins_seq_id           = v_ins_seq_id,
               established_amt      = v_established_amt,
               comments             = v_comments,
               prod_general_type_id = v_prod_general_type_id,
               updated_by           = v_added_by,
               updated_date         = SYSDATE,
               process_type         = NVL(v_process_type,'RGL')
         WHERE float_seq_id = v_float_seq_id;
      END IF;
      --number of rows updated/inserted
      v_row_processed := SQL%ROWCOUNT;
      COMMIT;
    END IF;
    --CALL THE SCHEDULER TO SETTLE PAYMENTS INSTANT
    float_accounts_pkg.float_accnts_unsettld_clm();
  EXCEPTION
    WHEN e_float_acc_num_same_bank THEN
      RAISE_APPLICATION_ERROR(-20242,
                              'Same Float Account Number/Account Name cannot be Duplicated.');
  END float_acc_save;
  --=======================================================================================
  -- this procedure is used to display all transaction  records wrt float_seq_id from tpa_float_transaction.
  PROCEDURE select_float_acc_trn_list(v_float_seq_id     IN TPA_FLOAT_TRANSACTION.float_seq_id%TYPE,
                                      v_float_trn_number IN OUT TPA_FLOAT_TRANSACTION.float_trn_number%TYPE,
                                      v_trn_type         IN TPA_FLOAT_TRANSACTION.flt_trn_type%TYPE,
                                      v_trn_date         IN VARCHAR2,
                                      v_trn_to_date      IN VARCHAR2,
                                      v_sort_var         IN VARCHAR2,
                                      v_sort_order       IN VARCHAR2,
                                      v_start_num        IN NUMBER,
                                      v_end_num          IN NUMBER,
                                      v_added_by         IN NUMBER,
                                      result_set         OUT SYS_REFCURSOR) IS
    v_sql_str    VARCHAR2(4000);
    v_start_date DATE := TO_DATE(v_trn_date, 'dd/mm/yyyy');
    v_end_date   DATE := TO_DATE(v_trn_to_date, 'dd/mm/yyyy');
  BEGIN
    --dispaly only non logically deleted records
    v_float_trn_number := v_float_trn_number || '%';
    v_sql_str          := 'SELECT A.float_trn_seq_id,
      A.float_seq_id,
      A.float_trn_number,
      A.flt_trn_type ,
      B.description AS type,
      A.flt_trn_date ,
      A.flt_trn_amount,
      C. current_balance,
      A.reverse_yn
      FROM tpa_float_transaction A LEFT OUTER JOIN tpa_general_code B on( A.flt_trn_type =B.general_type_id)
      LEFT OUTER JOIN tpa_float_account C on(a.float_seq_id = c.float_seq_id)
      WHERE A.float_seq_id = :v_float_seq_id
      AND ( :v_start_date IS NULL OR TRUNC(flt_trn_date) >= :v_start_date )
      AND ( :v_end_date IS NULL OR TRUNC(flt_trn_date) <= :v_end_date )
      AND ( :v_float_trn_number IS NULL OR A.float_trn_number LIKE :v_float_trn_number  )
      AND ( :v_trn_type IS NULL OR A.flt_trn_type= :v_trn_type )
      AND A.deleted_yn = ''N''';

    v_sql_str := 'SELECT * FROM
                       (SELECT A.*,DENSE_RANK() OVER (ORDER BY ' ||
                 v_sort_var || ' ' || v_sort_order ||
                 ',ROWNUM)
                        Q FROM (' || v_sql_str ||
                 ') A ) WHERE  Q>= :v_start_num  AND Q<= :v_end_num ';

    OPEN result_set FOR v_sql_str
      USING v_float_seq_id, v_start_date, v_start_date, v_end_date, v_end_date, v_float_trn_number, v_float_trn_number, v_trn_type, v_trn_type, v_start_num, v_end_num;
  END select_float_acc_trn_list;
  --========================================================================================
  --this procedure is used to display a record wrt to float_seq_id from tpa_float_transaction.
  PROCEDURE select_float_acc_trn_detail(v_float_trn_seq_id IN OUT TPA_FLOAT_TRANSACTION.float_trn_seq_id%TYPE,
                                        v_float_seq_id     IN TPA_FLOAT_TRANSACTION.float_seq_id%TYPE,
                                        v_added_by         IN NUMBER,
                                        result_set         OUT SYS_REFCURSOR) IS
  BEGIN
    OPEN result_set FOR
      SELECT B.float_trn_seq_id,
             B.float_seq_id,
             B.float_trn_number,
             B.flt_trn_type,
             B.flt_trn_date,
             B.flt_trn_amount,
             B.comments,
             A.float_type,
             B.CURRENCY_TYPE --added by chiranjibi
        FROM tpa_float_account A
        LEFT OUTER JOIN tpa_float_transaction B
          ON (A.float_seq_id = B.float_seq_id)
       WHERE B.float_trn_seq_id = v_float_trn_seq_id
         AND B.float_seq_id = v_float_seq_id;
  END select_float_acc_trn_detail;
  --=========================================================================================
  --this procedure is used to display insert/update a record into tpa_float_transaction.
  PROCEDURE float_acc_trn_save(v_float_trn_seq_id IN OUT TPA_FLOAT_TRANSACTION.float_trn_seq_id%TYPE,
                               v_float_seq_id     IN TPA_FLOAT_TRANSACTION.float_seq_id%TYPE,
                               v_trn_type         IN TPA_FLOAT_TRANSACTION.flt_trn_type %TYPE,
                               v_trn_date         IN TPA_FLOAT_TRANSACTION.flt_trn_date %TYPE,
                               v_trn_amount       IN TPA_FLOAT_TRANSACTION.flt_trn_amount %TYPE,
                               v_comments         IN TPA_FLOAT_TRANSACTION.comments%TYPE,
                               v_added_by         IN NUMBER,
                               v_float_type       IN VARCHAR2, -- FTD for Debit and FTR for Regualr.
                               v_currency_type    IN TPA_FLOAT_TRANSACTION.currency_type%TYPE, -- added by chiranjibi
                               v_rows_processed   OUT INTEGER) IS
    p_bank_balance       TPA_BANK_ACCOUNTS.bank_balance%TYPE;
    p_f_bank_balance     TPA_FLOAT_ACCOUNT.current_balance%TYPE;
    v_bank_acc_seq_id    TPA_BANK_ACCOUNTS.bank_acc_seq_id%TYPE;
    v_established_amount TPA_FLOAT_ACCOUNT.ESTABLISHED_AMT%TYPE;
    v_flag               NUMBER(5);

    CURSOR bank_cur IS
      SELECT bank_acc_seq_id, established_amt
        FROM tpa_float_account
       WHERE float_seq_id = v_float_seq_id;
  BEGIN
    --- if v_float_type = 'FTD' then transaction is for debit note. Here
    --- transaction can be allowed only if there is a debit note exists
    --- under the given float_seq_id, not completed and created before the trans date. This condition is added by Prasanna Kumar, SPAN Infotec.
    IF v_float_type = 'FTD' THEN
      WITH trans_status AS
       (SELECT a.debit_seq_id,
               SUM(CASE
                     WHEN b.claim_seq_id IS NULL THEN
                      0
                     ELSE
                      1
                   END) AS NumOf_INP
          FROM tpa_debit_note_claims_assoc a
          LEFT OUTER JOIN tpa_claims_payment b
            ON (a.claim_seq_id = b.claim_seq_id AND
               b.claim_payment_status != 'PAID')
         GROUP BY a.debit_seq_id)
      SELECT COUNT(1)
        INTO v_flag
        FROM tpa_debit_note a
        JOIN trans_status d
          ON (a.debit_seq_id = d.debit_seq_id AND d.NumOf_INP > 0)
       WHERE debit_status_general_type_id = 'DFL'
         AND a.float_seq_id = v_float_seq_id
         AND a.debit_date <= v_trn_date;
      IF v_flag = 0 THEN
        raise_application_error(-20257,
                                'No Debit Note exists to process a transaction.');
      END IF;
    END IF;

    --flag zero
    IF (v_float_trn_seq_id) = 0 THEN
      --transaction type is deposit
      SELECT COUNT(1)
        INTO v_flag
        FROM tpa_float_account b
       WHERE TRUNC(v_trn_date) BETWEEN TRUNC(b.effective_date) AND
             TRUNC(nvl(b.expiration_date, SYSDATE))
         AND b.float_status NOT IN ('ASC', 'ASI')
         AND b.float_seq_id = v_float_seq_id;
      IF (v_flag = 0) THEN
        RAISE_APPLICATION_ERROR(-20225, 'please  enter a valid tran date.');
      ELSE
        --check float type is regular/debit then
        --if regular then update (deposit/withdrawl,bank charges) trn amount to bank account.
        IF (v_trn_type = 'TTD') THEN
          SELECT bank_acc_seq_id
            INTO v_bank_acc_seq_id
            FROM tpa_float_account
           WHERE float_seq_id = v_float_seq_id;

          INSERT INTO tpa_float_transaction
            (float_trn_seq_id,
             float_trn_number,
             float_seq_id,
             flt_trn_type,
             flt_trn_date,
             flt_trn_amount,
             currency_type,
             comments,
             added_by,
             added_date)
          VALUES
            (float_trans_seq.NEXTVAL,
             'TR' || '-' || float_trans_num_seq.NEXTVAL,
             v_float_seq_id,
             v_trn_type,
             v_trn_date,
             v_trn_amount,
             v_currency_type,
             v_comments,
             v_added_by,
             SYSDATE)
          RETURNING float_trn_seq_id INTO v_float_trn_seq_id;

          UPDATE tpa_float_account
             SET current_balance =
                 (current_balance + v_trn_amount)
           WHERE float_seq_id = v_float_seq_id;
          --get bank_acc_seq_id by float_seq_id and update the bank balance
          SELECT bank_acc_seq_id
            INTO v_bank_acc_seq_id
            FROM tpa_float_account
           WHERE float_seq_id = v_float_seq_id;
          --dont update what ever float type is only take care of minimum balance.
          UPDATE tpa_bank_accounts
             SET bank_balance =
                 (bank_balance + v_trn_amount)
           WHERE bank_acc_seq_id = v_bank_acc_seq_id;
        
        ELSE
          OPEN bank_cur;
          FETCH bank_cur
            INTO v_bank_acc_seq_id, v_established_amount;
          CLOSE bank_cur;
          IF v_bank_acc_seq_id IS NULL THEN
            RAISE_APPLICATION_ERROR(-20206,
                                    'bank acc seq id is not existed.');
          END IF;
        
          --validation for withdrawl of minimum balance,balance,for resp bank_acc.
          SELECT bank_balance
            INTO p_bank_balance
            FROM tpa_bank_accounts
           WHERE bank_acc_seq_id = v_bank_acc_seq_id;
        
          SELECT current_balance
            INTO p_f_bank_balance
            FROM tpa_float_account
           WHERE float_seq_id = v_float_seq_id;
          --transaction type is withdrawl/adjustments/bank charges
        
          IF (v_trn_type = 'TTA') THEN
            --transaction amount should be less than or equal to float bal
            IF (v_trn_amount <= p_f_bank_balance) THEN
              --transaction amount should be less than or equal to bank bal
              IF (v_trn_amount <= p_bank_balance) THEN
                --inserting a record when withdrawl.
                INSERT INTO tpa_float_transaction
                  (float_trn_seq_id,
                   float_trn_number,
                   float_seq_id,
                   flt_trn_type,
                   flt_trn_date,
                   flt_trn_amount,
                   currency_type,
                   comments,
                   added_by,
                   added_date)
                VALUES
                  (float_trans_seq.NEXTVAL,
                   'TR' || '-' || float_trans_num_seq.NEXTVAL,
                   v_float_seq_id,
                   v_trn_type,
                   v_trn_date,
                   v_trn_amount,
                   v_currency_type,
                   v_comments,
                   v_added_by,
                   SYSDATE)
                RETURNING FLOAT_TRN_SEQ_ID INTO v_float_trn_seq_id;
              
                UPDATE tpa_float_account
                   SET current_balance =
                       (current_balance - v_trn_amount)
                 WHERE float_seq_id = v_float_seq_id;
                UPDATE tpa_bank_accounts
                   SET bank_balance =
                       (bank_balance - v_trn_amount)
                 WHERE bank_acc_seq_id = v_bank_acc_seq_id;
              ELSE
                RAISE_APPLICATION_ERROR(-20208,
                                        ' Transaction amount should be lessthan bank balance amount.');
              END IF;
            ELSE
              RAISE_APPLICATION_ERROR(-20207,
                                      ' Transaction amount should be lessthan float balance amount.');
            END IF;
          END IF;
        END IF;
      END IF;
    ELSE
      UPDATE tpa_float_transaction
         SET comments = v_comments
       WHERE float_trn_seq_id = v_float_trn_seq_id;
    END IF;
    v_rows_processed := SQL%ROWCOUNT;
    COMMIT;
  END float_acc_trn_save;
  --========================================================================================
  -- this procedure is used to display list of claims records from tpa_claims_payment.
  PROCEDURE select_claims_list(v_float_seq_id        IN TPA_CLAIMS_PAYMENT.float_seq_id%TYPE,
                               v_debit_seq_id        IN TPA_DEBIT_NOTE.debit_seq_id%TYPE,
                               v_claim_settlement_no IN TPA_CLAIMS_PAYMENT.claim_settlement_no%TYPE,
                               v_enrollment_id       IN TPA_ENR_POLICY_MEMBER.tpa_enrollment_id%TYPE,
                               v_payment_mode        IN VARCHAR2, --added for KOC1103 IF EFT THEN SEARCH ONLY PENDING CLAIMS WHICH IS HAVING BANK ACN NUM ELSE WHICH DOESN'T HAVE ACCOUNT NUMBER RECORDS
                               v_claim_app_date      IN VARCHAR2,
                               v_corporate_name      IN tpa_group_registration.group_name%TYPE,
                               v_mem_name            IN TPA_ENR_POLICY_MEMBER.mem_name%TYPE,
                               v_claim_type          IN TPA_CLAIMS_PAYMENT.claim_type%TYPE,
                               v_policy_type         IN TPA_ENR_POLICY.enrol_type_id%TYPE,
                               v_in_favour_of        IN TPA_CLAIMS_PAYMENT.Payee_Name%TYPE,
                               v_added_by            IN NUMBER,
                               v_curency_type        IN VARCHAR2,
                               v_claim_recv_date     IN VARCHAR2,
                               v_qatar_id            IN TPA_ENR_POLICY_MEMBER.EMIRATE_ID%TYPE,
                               v_payment_to          IN VARCHAR2,
                               v_prov_ptnr_seq       IN VARCHAR2,
                               v_priority_claims     IN VARCHAR,
                               v_pr_from             IN VARCHAR2,
                               v_pr_to               IN VARCHAR2,
                               v_sort_var            IN VARCHAR2,
                               v_sort_order          IN VARCHAR2,
                               v_start_num           IN NUMBER,
                               v_end_num             IN NUMBER,
                               result_set            OUT SYS_REFCURSOR) IS
    v_sql_str      VARCHAR2(32676);
    p_dv_recv_date DATE := TO_DATE(v_claim_app_date, 'DD/MM/YYYY');
    p_clm_recv_date DATE :=TO_DATE(v_claim_recv_date,'DD-MM-YYYY');
    TYPE bind_tab_type IS TABLE OF VARCHAR2(250) INDEX BY BINARY_INTEGER;
    bind_tab         bind_tab_type;
    i                NUMBER(2) := 0;
    v_tpa_account_no VARCHAR2(100); --balley
    v_tpa_ifsc       VARCHAR2(60); --balley
  
    CURSOR tpa_bank_details IS
      SELECT ad.account_number, ad.bank_ifsc
        FROM fin_app.tpa_account_details ad;
    tpa_rec tpa_bank_details%rowtype; --balley
  
  BEGIN
   
    OPEN tpa_bank_details;
    FETCH tpa_bank_details
      INTO v_tpa_account_no, v_tpa_ifsc;
    CLOSE tpa_bank_details;
  
    --select d.account_number,d.bank_ifsc into v_tpa_account_no,v_tpa_ifsc from fin_app.tpa_account_details d;--balley
    --dispaly only non logically deleted records
    v_sql_str :=  --added for koc1103
     'with shrtfall as (select max(sd.shortfall_seq_id) sh_seq_id,cad.claim_seq_id
                       from clm_authorization_details cad
                       join shortfall_details sd on (cad.claim_seq_id = sd.claim_seq_id)
                       group by cad.claim_seq_id
                      )
     
     SELECT  nvl(gd.req_amt_currency_type,''-'') as req_amt_currency_type,
       trunc(gd.final_app_amount,2) final_app_amount,
       trunc(gd.CONVERTED_FINAL_APPROVED_AMT,2) CONVERTED_FINAL_APPROVED_AMT,
       A.payment_seq_id,
        A.claim_settlement_no,
        B.tpa_enrollment_id,
        B.mem_name,
        K.description  AS claim_type,
        A.claim_aprv_date,
        ttk_util_pkg.fn_decrypt(a.payee_name) as in_favour_of,
        a.approved_amount,
        F.current_balance,
        H.bank_name AS HO,
        J.bank_name AS BO,
        M.office_code ,
        W.REVIEW_YN as REVIEW_YN,
        /*CASE WHEN a.claim_type=''CTM'' THEN  
         (CASE WHEN e.enrol_type_id=''COR'' THEN
           CASE WHEN clmb.claimfrom_gentype_id!=''EMBA'' THEN
              (CASE WHEN e.tpa_cheque_issued_general_type=''IQI'' THEN nvl(t.review_yn,''N'')
               WHEN e.tpa_cheque_issued_general_type=''IQC'' THEN nvl(s.review_yn,''N'') 
               END)
            ELSE
              nvl(embb.review_yn,''Y'')
           END     
          ELSE nvl(t.review_yn,''N'') END)
        ELSE 
            CASE gd.pymnt_to_type_id WHEN ''PTN'' THEN nvl(pa.review_yn,''Y'') 
            ELSE w.review_yn END
        END  as REVIEW_YN ,*/
        N.template_name,
        o.tds_process_yn,
        CASE WHEN a.claim_type=''CTM'' /*AND nvl(gd.pay_to_general_type_id,''MBR'')!=''HSL'' */THEN
        --CASE WHEN a.tpa_nhcp_cheques_issued_to=''TPA'' THEN ''' ||
                 v_tpa_account_no ||
                 '''  
         (CASE WHEN e.enrol_type_id=''COR'' THEN
           CASE WHEN clmb.claimfrom_gentype_id =''LYVR'' THEN
                   (CASE WHEN gd.payment_to=''IQI'' THEN ttk_util_pkg.fn_decrypt(t.bank_account_no)
                         WHEN gd.payment_to=''IQC'' THEN ttk_util_pkg.fn_decrypt(S.bank_account_no) 
                    END) 
                WHEN clmb.claimfrom_gentype_id!=''EMBA'' THEN
              (CASE WHEN e.tpa_cheque_issued_general_type=''IQI'' THEN ttk_util_pkg.fn_decrypt(t.bank_account_no)
               WHEN e.tpa_cheque_issued_general_type=''IQC'' THEN ttk_util_pkg.fn_decrypt(S.bank_account_no) 
               END)
            ELSE
              ttk_util_pkg.fn_decrypt(embb.bank_account_no)
           END     
         ELSE ttk_util_pkg.fn_decrypt(t.bank_account_no) END)
          --END  as account_num,
          ELSE 
            CASE gd.pymnt_to_type_id WHEN ''PTN'' THEN ttk_util_pkg.fn_decrypt(pa.account_number) 
                                        ELSE ttk_util_pkg.fn_decrypt(w.account_number) 
            END
          end as account_num,

        CASE WHEN a.claim_type=''CTM''/* AND nvl(gd.pay_to_general_type_id,''MBR'')!=''HSL''*/ THEN --added for hyundai requirement
        --CASE WHEN a.tpa_nhcp_cheques_issued_to=''TPA'' THEN ''' ||
                 v_tpa_ifsc ||
                 '''  
        (CASE WHEN e.enrol_type_id=''COR'' THEN 
            CASE WHEN clmb.claimfrom_gentype_id =''LYVR'' THEN
                   (CASE WHEN gd.payment_to=''IQI'' THEN ttk_util_pkg.fn_decrypt(t.bank_MICR)
                         WHEN gd.payment_to=''IQC'' THEN ttk_util_pkg.fn_decrypt(S.bank_MICR) END)
                 WHEN clmb.claimfrom_gentype_id!=''EMBA'' THEN
              (CASE WHEN e.tpa_cheque_issued_general_type=''IQI'' THEN ttk_util_pkg.fn_decrypt(t.bank_MICR)
              WHEN e.tpa_cheque_issued_general_type=''IQC'' THEN ttk_util_pkg.fn_decrypt(S.bank_MICR) END)
            ELSE
              ttk_util_pkg.fn_decrypt(embb.bank_MICR) 
            END
         ELSE ttk_util_pkg.fn_decrypt(t.bank_MICR) END)--END as ifsc
        ELSE  
          CASE gd.pymnt_to_type_id WHEN ''PTN'' THEN pa.bank_MICR 
                                          ELSE w.bank_MICR 
          END
        end as ifsc,
        gd.clm_received_date AS claim_recv_date,
        L.group_name AS corporate_name,
        CASE WHEN '''||v_payment_to||'''=''USD'' THEN nvl(gd.pay_amt_in_usd,0)
             WHEN '''||v_payment_to||'''=''EUR'' THEN nvl(gd.PAY_AMT_IN_EURO,0) 
             WHEN '''||v_payment_to ||'''=''GBP'' THEN nvl(gd.PAY_AMT_IN_GBP,0) END as usd_amount,
        B.emirate_id as qatar_id,
        '''||v_payment_to ||''' as Selected_currency,
        CASE WHEN clmb.CLM_TYPE_GEN_TYPE_ID=''CNH'' AND SRTFLL_RECEIVED_DATE IS NULL THEN
             CASE WHEN (SYSDATE-clmb.RECEIVED_DATE) BETWEEN FA.FST_FROM_DAYS AND FA.FST_TO_DAYS THEN 
                ''Y'' ELSE ''N'' END 
                 WHEN clmb.CLM_TYPE_GEN_TYPE_ID=''CNH'' AND SRTFLL_RECEIVED_DATE IS NOT NULL THEN 
                CASE WHEN (SYSDATE-SRTFLL_RECEIVED_DATE) BETWEEN FA.FST_FROM_DAYS AND FA.FST_TO_DAYS THEN 
                ''Y'' ELSE ''N'' END 
            END AS FAST_TRACK,
        (to_date(SYSDATE,''dd-mm-yyyy'') - to_date(gd.clm_received_date,''dd-mm-yyyy'')) AS claim_age,
         CASE WHEN (round(sysdate - gd.clm_received_date))<= fa.FST_TO_DAYS THEN  A.approved_amount*(fa.DISC_PERC/100) ELSE 0 END DISC_AMOUNT,
        A.approved_amount -(CASE WHEN (round(sysdate - gd.clm_received_date))<= fa.FST_TO_DAYS THEN  A.approved_amount*(fa.DISC_PERC/100) ELSE 0 END ) AMT_PAID_AF_DISC,
        CASE WHEN A.HOSP_SEQ_ID is not null then o.Payment_Dur_Agr 
             WHEN A.PTNR_SEQ_ID is not null then pi.Payment_Dur_Agr end Payment_Dur_Agr

        FROM tpa_claims_payment A JOIN tpa_enr_policy_member B ON(A.member_seq_id = B.member_seq_id)
        JOIN clm_authorization_details gd on (gd.claim_seq_id=a.claim_seq_id)--added for hyundai requirement
        JOIN clm_batch_upload_details clmb on (gd.clm_batch_seq_id=clmb.clm_batch_seq_id)
        JOIN tpa_enr_policy E ON(A.policy_seq_id = E.policy_seq_id )
        JOIN tpa_float_account F ON(A.float_seq_id = F.float_seq_id)
        JOIN clm_hospital_details chd on (chd.CLAIM_SEQ_ID=gd.CLAIM_SEQ_ID)
        LEFT OUTER JOIN tpa_bank_accounts g ON(f.bank_acc_seq_id = g.bank_acc_seq_id)
        LEFT OUTER JOIN tpa_bank_master  h ON (h.bank_seq_id = g.bank_seq_id)
        LEFT OUTER JOIN (SELECT bank_SEQ_ID FROM tpa_bank_master ) I ON(i.bank_seq_id = H.ho_id)
        LEFT OUTER JOIN tpa_bank_master J ON (J.bank_seq_id = I.bank_seq_id)
        LEFT OUTER JOIN tpa_general_code K ON (K.general_type_id = A.claim_type)
        LEFT OUTER JOIN tpa_group_registration L ON (L.group_reg_seq_id = A.group_reg_seq_id)
        LEFT OUTER JOIN tpa_office_info M ON (M.Tpa_Office_Seq_Id=g.tpa_office_seq_id)
        LEFT OUTER JOIN cheque_template N ON (H.cheque_template_id = N.cheque_template_id)
        LEFT OUTER JOIN tpa_enr_policy_group R ON(B.policy_group_seq_id=R.policy_group_seq_id)
        LEFT OUTER JOIN tpa_enr_bank_dtls S ON(E.bank_seq_id=S.bank_seq_id)
        LEFT OUTER JOIN tpa_enr_bank_dtls T ON(R.bank_seq_id=T.bank_seq_id)
        LEFT OUTER JOIN tpa_hosp_info O ON(a.hosp_seq_id=O.hosp_seq_id)
        LEFT OUTER JOIN tpa_hosp_account_details W ON(O.hosp_seq_id=w.hosp_seq_id)
        LEFT OUTER JOIN tpa_partner_info pi ON (gd.ptnr_seq_id=pi.ptnr_seq_id)
        LEFT OUTER JOIN tpa_partner_account_details pa ON (pi.ptnr_seq_id=pa.ptnr_seq_id)
        LEFT OUTER JOIN tpa_enr_embassy_registration emr ON (emr.embassy_seq_id=gd.embassy_seq_id)
        LEFT OUTER JOIN tpa_enr_bank_dtls embb ON(embb.bank_seq_id=emr.bank_seq_id)
        LEFT OUTER JOIN shrtfall sh on (sh.claim_seq_id=a.claim_Seq_id)
        left join shortfall_details sd on (sh.sh_seq_id=sd.shortfall_seq_id)
        LEFT OUTER JOIN APP.TPA_FASTTRACT_DISC_DETAILS FA ON (FA.HOSP_SEQ_ID=a.HOSP_SEQ_ID AND FA.DISC_MODE=''FAST''
        AND FA.STATUS=''ACT'' AND gd.DATE_OF_HOSPITALIZATION between fa.START_DATE and fa.end_date)';
  
    IF v_debit_seq_id IS NOT NULL THEN
      v_sql_str := v_sql_str ||
                   ' JOIN
        (SELECT b.claim_seq_id, SUM(b.deposited_amount) AS total_dep_amt
                                FROM tpa_debit_note_claims_assoc a
                                     JOIN tpa_debit_claims_transaction b ON (a.claim_seq_id = b.claim_seq_id)
                                  WHERE a.debit_seq_id = :v_debit_seq_id GROUP BY b.claim_seq_id) dep_dtl
         ON (A.claim_seq_id = dep_dtl.claim_seq_id AND dep_dtl.total_dep_amt = A.approved_amount)
          WHERE A.float_seq_id = :v_float_seq_id  AND A.deleted_yn = ''N'' AND A.claim_payment_status = ''DEBIT_NOTE_ATTACHED''';
      i := i + 1;
      bind_tab(i) := v_debit_seq_id;
    
      i := i + 1;
      bind_tab(i) := v_float_seq_id;
    ELSE
      v_sql_str := v_sql_str ||
                   ' WHERE A.float_seq_id = :v_float_seq_id  AND A.deleted_yn = ''N''
           AND A.claim_payment_status  = ''PENDING''';
      i := i + 1;
      bind_tab(i) := v_float_seq_id;
    END IF;
  
    --search by v_claim_settlement_no value
    IF (v_claim_settlement_no) IS NOT NULL THEN
      v_sql_str := v_sql_str ||
                   ' AND A.claim_settlement_no LIKE :v_claim_settlement_no';
      i := i + 1;
      bind_tab(i) := v_claim_settlement_no || '%';
    END IF;
    --search by v_enrollment_id value
    IF (v_enrollment_id) IS NOT NULL THEN
      v_sql_str := v_sql_str ||
                   ' AND B.tpa_enrollment_id LIKE :v_enrollment_id';
      i := i + 1;
      bind_tab(i) := v_enrollment_id || '%';
    END IF;
    --search by v_mem_name value
    IF (v_mem_name) IS NOT NULL THEN
      v_sql_str := v_sql_str || ' AND B.mem_name LIKE :v_mem_name';
      i := i + 1;
      bind_tab(i) := UPPER(v_mem_name) || '%';
    END IF;
    --search by v_claim_type value
    
    IF (v_claim_type) IS NOT NULL AND v_claim_type IN ('CTM') THEN 
      v_sql_str := v_sql_str || ' AND A.claim_type = :v_claim_type ';
      i := i + 1;
      bind_tab(i) := v_claim_type;
     --if claim type is network & for Given Provider      
    ELSIF (v_claim_type) IS NOT NULL AND v_claim_type='CNH' THEN 
          
            v_sql_str := v_sql_str || ' AND A.claim_type = :v_claim_type ';
            i := i + 1;
            bind_tab(i) := v_claim_type;
          
          IF v_prov_ptnr_seq IS NOT NULL THEN
             v_sql_str := v_sql_str || ' AND chd.hosp_seq_id = :v_prov_ptnr_seq  ';
             i := i + 1;
             bind_tab(i) := v_prov_ptnr_seq;
    END IF;
     --if claim type is network & for Given Partner
    ELSIF (v_claim_type) IS NOT NULL AND v_claim_type='PTN' THEN 
          IF v_prov_ptnr_seq IS NOT NULL THEN
             v_sql_str := v_sql_str || ' AND gd.ptnr_seq_id = :v_prov_ptnr_seq ';
             i := i + 1;
             bind_tab(i) := v_prov_ptnr_seq;
          ELSE
            v_sql_str := v_sql_str || ' AND gd.ptnr_seq_id is not null ';
           
          END IF;
    END IF;
    
    --search by v_policy_type value
    IF (v_policy_type) IS NOT NULL THEN
      v_sql_str := v_sql_str || ' AND E.enrol_type_id = :v_policy_type ';
      i := i + 1;
      bind_tab(i) := v_policy_type;
    END IF;
    --search by v_curency_type value
    IF (v_curency_type) IS NOT NULL AND v_curency_type!='ANY' THEN
      IF v_curency_type='QAR' THEN
          v_sql_str := v_sql_str || ' AND nvl(gd.req_amt_currency_type,''QAR'') = :v_curency_type ';
          i := i + 1;
          bind_tab(i) := v_curency_type;
      ELSIF v_curency_type='OTQ' THEN 
          v_sql_str := v_sql_str || ' AND gd.req_amt_currency_type != :v_curency_type ';
          i := i + 1;
          bind_tab(i) := 'QAR';
      ELSE
          v_sql_str := v_sql_str || ' AND gd.req_amt_currency_type = :v_curency_type ';
          i := i + 1;
          bind_tab(i) := v_curency_type;  
      END IF;    
    END IF;
    
    --search by v_in_favour_of value
    IF (v_in_favour_of) IS NOT NULL THEN
      v_sql_str := v_sql_str ||
                   ' AND ttk_util_pkg.fn_decrypt(A.payee_name) LIKE :v_in_favour_of';
      i := i + 1;
      bind_tab(i) := v_in_favour_of || '%';
    END IF;
    --if claim approved date is not null then
    IF (v_claim_app_date) IS NOT NULL THEN
      v_sql_str := v_sql_str ||
                   ' AND TRUNC(a.claim_aprv_date) = :p_dv_recv_date ';
      i := i + 1;
      bind_tab(i) := p_dv_recv_date;
    END IF;
    --Claim Received date not null case 
     IF (v_claim_recv_date) IS NOT NULL THEN
      v_sql_str := v_sql_str ||
                   ' AND TRUNC(gd.clm_received_date) = :p_clm_recv_date ';
      i := i + 1;
      bind_tab(i) := p_clm_recv_date;
    END IF;
    IF (v_corporate_name) IS NOT NULL THEN
      v_sql_str := v_sql_str || ' AND L.group_name LIKE :v_corporate_name';
      i := i + 1;
      bind_tab(i) := '%' || UPPER(v_corporate_name) || '%';
    END IF;
    ------------ CR0218(Search by QatarID)------------------
    IF (v_qatar_id) IS NOT NULL THEN
      v_sql_str := v_sql_str ||
                   ' AND B.emirate_id = :v_qatar_id';
      i := i + 1;
      bind_tab(i) := v_qatar_id;
    END IF;
    --------------------------------------------------------
    
     ---- Priority Claims Search
   
   --- Claim type Network case 
   -- PRVA (As Per Ageing)
   -- PRAG (As Provider Agreement Period)
   -- PTRA (As Partner Agreement Period)
   -- DISC (with Discount)
   -- WDIS (without Discount)
   IF v_priority_claims IS NOT NULL AND v_claim_type='CNH' THEN
      IF v_priority_claims ='PRVA' THEN
        IF  v_pr_from IS NOT NULL AND v_pr_to IS NOT NULL THEN 
           v_sql_str:=v_sql_str||' and (SYSDATE-gd.clm_received_date) between '||v_pr_from|| 'and '||v_pr_to ;
       ELSIF v_pr_from IS NOT NULL AND v_pr_to IS NULL THEN
           v_sql_str:=v_sql_str||' and (SYSDATE-gd.clm_received_date)  >= '||v_pr_from|| '';
       ELSIF v_pr_from IS NULL AND v_pr_to IS NOT NULL THEN
          v_sql_str:=v_sql_str||' and (SYSDATE-gd.clm_received_date) <= '||v_pr_to ||'';
       END IF;
      ELSIF v_priority_claims ='PRAG' THEN
      v_sql_str:=v_sql_str||' and (SYSDATE-gd.clm_received_date)>(o.payment_dur_agr-15)' ; 
      ELSIF v_priority_claims='DISC' THEN
       v_sql_str:= ' SELECT * FROM ('||v_sql_str||') WHERE NVL(FAST_TRACK,''N'')=''Y''';
      ELSIF v_priority_claims='WDIS' THEN
       v_sql_str:= 'SELECT * FROM ('||v_sql_str||') WHERE NVL(FAST_TRACK,''N'')=''N''';
      END IF;
   --- Claim type Partner case
   ELSIF v_priority_claims IS NOT NULL AND v_claim_type='PTN' THEN 
      IF v_priority_claims ='PRVA' THEN 
        IF v_pr_from IS NOT NULL AND v_pr_to IS NOT NULL THEN   
          v_sql_str:=v_sql_str||' and    trunc(sysdate - gd.clm_received_date) between '||v_pr_from|| ' and '||v_pr_to ;
        ELSIF v_pr_from IS NOT NULL AND v_pr_to IS NULL THEN
          v_sql_str:=v_sql_str||' and (SYSDATE-gd.clm_received_date)  >= '||v_pr_from|| '';
        ELSIF  v_pr_from IS NULL AND v_pr_to IS NOT NULL THEN
          v_sql_str:=v_sql_str||' and (SYSDATE-gd.clm_received_date) <= '||v_pr_to ||'';
        END IF;
      
      ELSIF v_priority_claims ='PTRA' THEN  
       v_sql_str:=v_sql_str||' and (SYSDATE-gd.clm_received_date)>(pi.payment_dur_agr-15)' ;
      ELSIF v_priority_claims='DISC' THEN
       v_sql_str:= 'SELECT * FROM ('||v_sql_str||') WHERE NVL(FAST_TRACK,''N'')=''Y''';
      ELSIF v_priority_claims='WDIS' THEN
       v_sql_str:= 'SELECT * FROM ('||v_sql_str||') WHERE NVL(FAST_TRACK,''N'')=''N''';
      END IF;
    --- Claim type Member case
   ELSIF v_priority_claims IS NOT NULL AND v_claim_type='CTM' THEN
      IF v_priority_claims ='PRVA' THEN
       IF v_pr_from IS NOT NULL AND v_pr_to IS NOT NULL THEN
          v_sql_str:='SELECT * FROM ('|| v_sql_str || ') WHERE  nvl(claim_age,0) between '||v_pr_from|| 'and '||v_pr_to ;
        ELSIF v_pr_from IS NOT NULL AND v_pr_to IS NULL THEN
          v_sql_str:='SELECT * FROM ('|| v_sql_str || ') WHERE  nvl(claim_age,0)  >= '||v_pr_from|| '';
        ELSIF  v_pr_from IS NULL AND v_pr_to IS NOT NULL THEN
          v_sql_str:=' SELECT * FROM ('|| v_sql_str || ') WHERE  nvl(claim_age,0) <= '||v_pr_to ||'';
        END IF;
      ELSIF v_priority_claims='DISC' THEN
       v_sql_str:= 'SELECT * FROM ('||v_sql_str||') WHERE NVL(FAST_TRACK,''N'')=''Y''';
      ELSIF v_priority_claims='WDIS' THEN
       v_sql_str:= 'SELECT * FROM ('||v_sql_str||') WHERE NVL(FAST_TRACK,''N'')=''N''';
      END IF;
   END IF;
  
  
    IF v_payment_mode = 'EFT' THEN
      --koc1103
      v_sql_str := 'SELECT * FROM
       (SELECT A.*,DENSE_RANK() OVER (ORDER BY ' ||
                   v_sort_var || ' ' || v_sort_order || ',ROWNUM)
        Q FROM (' || v_sql_str ||
                   ') A WHERE A.account_num IS NOT NULL AND A.account_num<>''NA'' AND a.ifsc is not null) WHERE  Q>= :v_start_num  AND Q<= :v_end_num ';
    ELSE
      v_sql_str := 'SELECT * FROM
       (SELECT A.*,DENSE_RANK() OVER (ORDER BY ' ||
                   v_sort_var || ' ' || v_sort_order || ',ROWNUM)
        Q FROM (' || v_sql_str ||
                   ') A WHERE A.account_num IS  NULL OR A.account_num=''NA'' OR A.IFSC IS NULL) WHERE  Q>= :v_start_num  AND Q<= :v_end_num ';
    END IF;
   
    IF bind_tab.FIRST IS NOT NULL THEN
      CASE bind_tab.COUNT
        WHEN 1 THEN
          OPEN result_set FOR v_sql_str
            USING bind_tab(1), v_start_num, v_end_num;
        WHEN 2 THEN
          OPEN result_set FOR v_sql_str
            USING bind_tab(1), bind_tab(2), v_start_num, v_end_num;
        WHEN 3 THEN
          OPEN result_set FOR v_sql_str
            USING bind_tab(1), bind_tab(2), bind_tab(3), v_start_num, v_end_num;
        WHEN 4 THEN
          OPEN result_set FOR v_sql_str
            USING bind_tab(1), bind_tab(2), bind_tab(3), bind_tab(4), v_start_num, v_end_num;
        WHEN 5 THEN
          OPEN result_set FOR v_sql_str
            USING bind_tab(1), bind_tab(2), bind_tab(3), bind_tab(4), bind_tab(5), v_start_num, v_end_num;
        WHEN 6 THEN
          OPEN result_set FOR v_sql_str
            USING bind_tab(1), bind_tab(2), bind_tab(3), bind_tab(4), bind_tab(5), bind_tab(6), v_start_num, v_end_num;
        WHEN 7 THEN
          OPEN result_set FOR v_sql_str
            USING bind_tab(1), bind_tab(2), bind_tab(3), bind_tab(4), bind_tab(5), bind_tab(6), bind_tab(7), v_start_num, v_end_num;
        WHEN 8 THEN
          OPEN result_set FOR v_sql_str
            USING bind_tab(1), bind_tab(2), bind_tab(3), bind_tab(4), bind_tab(5), bind_tab(6), bind_tab(7), bind_tab(8), v_start_num, v_end_num;
        WHEN 9 THEN
          OPEN result_set FOR v_sql_str
            USING bind_tab(1), bind_tab(2), bind_tab(3), bind_tab(4), bind_tab(5), bind_tab(6), bind_tab(7), bind_tab(8), bind_tab(9), v_start_num, v_end_num;
        WHEN 10 THEN
          OPEN result_set FOR v_sql_str
            USING bind_tab(1), bind_tab(2), bind_tab(3), bind_tab(4), bind_tab(5), bind_tab(6), bind_tab(7), bind_tab(8), bind_tab(9), bind_tab(10), v_start_num, v_end_num;
      
      WHEN 11 THEN
          OPEN result_set FOR v_sql_str
            USING bind_tab(1), bind_tab(2), bind_tab(3), bind_tab(4), bind_tab(5), bind_tab(6), bind_tab(7), bind_tab(8), bind_tab(9), bind_tab(10),bind_tab(11), v_start_num, v_end_num;
      WHEN 12 THEN
          OPEN result_set FOR v_sql_str
            USING bind_tab(1), bind_tab(2), bind_tab(3), bind_tab(4), bind_tab(5), bind_tab(6), bind_tab(7), bind_tab(8), bind_tab(9), bind_tab(10),bind_tab(11),bind_tab(12), v_start_num, v_end_num;
      END CASE;
    ELSE
      OPEN result_set FOR v_sql_str
        USING v_float_seq_id, v_start_num, v_end_num;
    END IF;
  
  END select_claims_list;
  --========================================================================================
  -- this procedure is used to display a record for  respective float_acc_number from tpa_claims_payment.
  PROCEDURE select_claim_detail(v_payment_seq_id IN OUT TPA_CLAIMS_PAYMENT.payment_seq_id%TYPE,
                                v_float_seq_id   IN TPA_CLAIMS_PAYMENT.float_seq_id%TYPE,
                                v_added_by       IN NUMBER,
                                result_set       OUT SYS_REFCURSOR) IS
  
  BEGIN
    OPEN result_set FOR
      SELECT A.claim_settlement_no,
             a.claim_type AS claim_type,
             A.claim_aprv_date,
             A.approved_amount,
             A.float_seq_id,
             B.tpa_enrollment_id,
             B.mem_name,
             c.policy_number as policy_seq_id,
             h.description AS enrol_type_id,
             D.ins_comp_name,
             D.abbrevation_code || '-' || D.ins_comp_code_number ins_comp_code_number,
             E.group_id,
             E.group_name,
             ttk_util_pkg.fn_decrypt(a.payee_name) AS in_favour_of,
             G.comments,
             A.address1,
             A.Address2,
             A.Address3,
             A.State,
             A.City,
             A.Pincode,
             A.Country,
             A.Email_Id, --not required to modfiy for koc11ed
             A.Phone1,
             A.Phone2,
             A.Home_Phone,
             A.Mob_Num,
             A.Fax_No,
             G.check_date
        FROM tpa_claims_payment A
        JOIN tpa_enr_policy_member B
          ON (a.member_seq_id = b.member_seq_id)
        JOIN tpa_enr_policy C
          ON (a.policy_seq_id = c.policy_seq_id)
        JOIN tpa_ins_info D
          ON (a.ins_seq_id = d.ins_seq_id)
        LEFT OUTER JOIN tpa_group_registration E
          ON (a.group_reg_seq_id = e.group_reg_seq_id)
        LEFT OUTER JOIN tpa_payment_checks_details F
          ON (a.payment_seq_id = f.payment_seq_id)
        LEFT OUTER JOIN tpa_claims_check G
          ON (f.claims_chk_seq_id = g.claims_chk_seq_id)
        LEFT OUTER JOIN tpa_general_code h
          ON (h.general_type_id = C.enrol_type_id)
       WHERE A.payment_seq_id = v_payment_seq_id
         AND A.float_seq_id = v_float_seq_id;
  END select_claim_detail;
  --===================================================================================
  -- this procedure is used to update a record into tpa_claims_payment.
  PROCEDURE cheque_printing_details_save(v_payment_seq_id      IN OUT TPA_CLAIMS_PAYMENT.payment_seq_id%TYPE,
                                         v_claim_settlement_no IN TPA_CLAIMS_PAYMENT.claim_settlement_no%TYPE,
                                         v_comments            IN TPA_CLAIMS_PAYMENT.remarks%TYPE,
                                         v_added_by            IN NUMBER,
                                         v_rows_processed      OUT INTEGER) IS
  BEGIN
    UPDATE tpa_claims_payment
       SET remarks = v_comments
     WHERE payment_seq_id = v_payment_seq_id;

    v_rows_processed := SQL%ROWCOUNT;
    COMMIT;
  END cheque_printing_details_save;
  --======================================================================================
  -- this procedure is used to delete list of float account records from tpa_float_account.
  PROCEDURE float_acc_delete(v_float_seq_id   IN VARCHAR2,
                             v_added_by       IN NUMBER,
                             v_rows_processed OUT INTEGER) IS
    v_flag  NUMBER(5);
    v_flag1 NUMBER(5);
    str_tab ttk_util_pkg.str_table_type;
  BEGIN
    str_tab := ttk_util_pkg.parse_str(v_float_seq_id);
    FOR i IN str_tab.FIRST .. str_tab.LAST LOOP
      --checking transaction exists
      SELECT COUNT(1)
        INTO v_flag1
        FROM tpa_float_transaction D
       WHERE D.float_seq_id = TO_NUMBER(str_tab(i));

      --checking float account exists dont check of status.
      SELECT COUNT(1)
        INTO v_flag
        FROM tpa_claims_payment E1
       WHERE E1.float_seq_id = TO_NUMBER(str_tab(i));

      --if transaction and payments exisetd the you cannot delete float acount.
      IF (v_flag1 >= 1 OR v_flag >= 1) THEN
        RAISE_APPLICATION_ERROR(-20214,
                                'You cannot DELETE the FLOAT Account Transaction(s)/Payment(s) is exists.');
        --only delete peramently from db when no trans and no payments exists.
      ELSE
        DELETE FROM tpa_float_account
         WHERE float_seq_id = TO_NUMBER(str_tab(i));
      END IF;
    END LOOP;
    --number of rows inserted/updated
    v_rows_processed := str_tab.LAST;
    COMMIT;
  END float_acc_delete;
  --=======================================================================================
  --This Procedure is Used to Float Account Reverse Transactions.
  PROCEDURE float_acc_tran_reverse(v_float_acc_seq_id IN TPA_FLOAT_TRANSACTION.float_seq_id%TYPE,
                                   v_float_trn_seq_id IN VARCHAR2,
                                   v_added_by         IN NUMBER,
                                   v_rows_processed   OUT INTEGER) IS
    str_tab           ttk_util_pkg.str_table_type;
    v_trans_amount    TPA_FLOAT_TRANSACTION.flt_trn_amount%TYPE;
    v_trn_type        TPA_FLOAT_TRANSACTION.flt_trn_type%TYPE;
    v_reverse_yn      TPA_FLOAT_ACCOUNT.reverse_yn%TYPE;
    v_bank_acc_seQ_id TPA_FLOAT_ACCOUNT.bank_acc_seq_id%TYPE;
    v_flag            NUMBER(14, 2);
    v_float_status    TPA_FLOAT_ACCOUNT.float_status%TYPE;
    v_currency_type   TPA_FLOAT_TRANSACTION.CURRENCY_TYPE%TYPE; --added by chiranjibi
  BEGIN
    str_tab := ttk_util_pkg.parse_str(v_float_trn_seq_id);
    FOR i IN str_tab.FIRST .. str_tab.LAST
    --logically deletion
     LOOP
      SELECT flt_trn_amount, flt_trn_type, reverse_yn, currency_type
        INTO v_trans_amount, v_trn_type, v_reverse_yn, v_currency_type
        FROM tpa_float_transaction
       WHERE float_trn_seq_id = TO_NUMBER(str_tab(i))
         AND float_seq_id = v_float_acc_seq_id;

      SELECT a.float_status
        INTO v_float_status
        FROM tpa_float_account a
       WHERE a.float_seq_id = v_float_acc_seq_id;

      IF (v_float_status = 'ASA') THEN
        --display only non reveresed records
        IF (v_reverse_yn = 'N') THEN
          --transaction type is deposit
          IF (v_trn_type = 'TTD') THEN
            SELECT (t.current_balance - v_trans_amount)
              INTO v_flag
              FROM tpa_float_account t
             WHERE t.float_seq_id = v_float_acc_seq_id;
            IF (v_flag < 0) THEN
              RAISE_APPLICATION_ERROR(-20237,
                                      'cannot have negative  balance.');
            ELSE
              --the reverse transaction amount is effecting to float account.
              UPDATE tpa_float_account
                 SET current_balance =
                     (current_balance - v_trans_amount),
                     reverse_yn      = 'Y'
               WHERE float_seq_id = v_float_acc_seq_id;
              --getting bank_acc_seQ_id wof the respective float_seq_id.
              SELECT bank_acc_seQ_id
                INTO v_bank_acc_seq_id
                FROM tpa_float_account
               WHERE float_seq_id = v_float_acc_seq_id;
              --physical account transaction amount is reversing.
              UPDATE tpa_bank_accounts t1
                 SET t1.bank_balance =
                     (t1.bank_balance - v_trans_amount)
               WHERE t1.bank_acc_seq_id = v_bank_acc_seq_id;
              --here insert a new record and chane the status
              INSERT INTO tpa_float_transaction
                (float_trn_seq_id,
                 float_trn_number,
                 float_seq_id,
                 flt_trn_type,
                 flt_trn_date,
                 flt_trn_amount,
                 currency_type,
                 comments,
                 added_by,
                 added_date)
              VALUES
                (float_trans_seq.NEXTVAL,
                 'TR' || '-' || float_trans_num_seq.NEXTVAL,
                 v_float_acc_seq_id,
                 'TTA',
                 SYSDATE,
                 v_trans_amount,
                 v_currency_type,
                 'TR' || '-' || TO_NUMBER(str_tab(i)) ||
                 ' has been reverse entry ',
                 v_added_by,
                 SYSDATE);
              --here changing the reverse_yn status from  N TO Y
              UPDATE tpa_float_transaction
                 SET reverse_yn = 'Y'
               WHERE float_trn_seq_id = TO_NUMBER(str_tab(i));
            END IF;
            --transaction type is adjustments/withdrawl
          ELSIF (v_trn_type = 'TTA') THEN
            --the reverse transaction amount is effecting to float account.
            UPDATE tpa_float_account
               SET current_balance =
                   (current_balance + v_trans_amount),
                   reverse_yn      = 'Y'
             WHERE float_seq_id = v_float_acc_seq_id;
            --getting bank_acc_seQ_id wof the respective float_seq_id.
            SELECT bank_acc_seq_id
              INTO v_bank_acc_seQ_id
              FROM tpa_float_account
             WHERE float_seq_id = v_float_acc_seq_id;
            --physical account transaction amount is reversing.
            UPDATE tpa_bank_accounts t1
               SET t1.bank_balance =
                   (t1.bank_balance + v_trans_amount)
             WHERE t1.bank_acc_seq_id = v_bank_acc_seQ_id;
            --here insert a new record and chane the status
            INSERT INTO tpa_float_transaction
              (float_trn_seq_id,
               float_trn_number,
               float_seq_id,
               flt_trn_type,
               flt_trn_date,
               flt_trn_amount,
               currency_type,
               comments,
               added_by,
               added_date)
            VALUES
              (float_trans_seq.NEXTVAL,
               'TR' || '-' || float_trans_num_seq.NEXTVAL,
               v_float_acc_seq_id,
               'TTD',
               SYSDATE,
               v_trans_amount,
               v_currency_type,
               'TR' || '-' || float_trans_num_seq.NEXTVAL ||
               ' has been reverse entry ',
               v_added_by,
               SYSDATE);
            --here changing the status from N TO Y
            UPDATE tpa_float_transaction
               SET reverse_yn = 'Y'
             WHERE float_trn_seq_id = TO_NUMBER(str_tab(i));
            --transaction type is bank charges
          ELSE
            --the reverse transaction amount is effecting to float account.
            UPDATE tpa_float_account
               SET current_balance =
                   (current_balance + v_trans_amount),
                   reverse_yn      = 'Y'
             WHERE float_seq_id = v_float_acc_seq_id;
            --getting bank_acc_seQ_id wof the respective float_seq_id.
            SELECT bank_acc_seQ_id
              INTO v_bank_acc_seQ_id
              FROM tpa_float_account
             WHERE float_seq_id = v_float_acc_seq_id;
            --physical account transaction amount is reversing.
            UPDATE tpa_bank_accounts t1
               SET t1.bank_balance =
                   (t1.bank_balance + v_trans_amount)
             WHERE t1.bank_acc_seq_id = v_bank_acc_seQ_id;
            --here insert a new record and chane the status
            INSERT INTO tpa_float_transaction
              (float_trn_seq_id,
               float_trn_number,
               float_seq_id,
               flt_trn_type,
               flt_trn_date,
               flt_trn_amount,
               currency_type,
               comments,
               added_by,
               added_date)
            VALUES
              (float_trans_seq.NEXTVAL,
               'TR' || '-' || float_trans_num_seq.NEXTVAL,
               v_float_acc_seq_id,
               'TTD',
               SYSDATE,
               v_trans_amount,
               v_currency_type,
               'TR' || '-' || float_trans_num_seq.NEXTVAL ||
               ' has been reverse entry ',
               v_added_by,
               SYSDATE);
            --here changing the status from N TO Y
            UPDATE tpa_float_transaction
               SET reverse_yn = 'Y'
             WHERE float_trn_seq_id = TO_NUMBER(str_tab(i));
          END IF;
        ELSE
          --already reverse entry occcured
          RAISE_APPLICATION_ERROR(-20204,
                                  'you cannot do the reverse entry again for this record');
        END IF;
      ELSE
        RAISE_APPLICATION_ERROR(-20238, 'account status should be active.');
      END IF;
    END LOOP;
    --number of rows inserted/updated
    v_rows_processed := str_tab.LAST;
    COMMIT;
  END float_acc_tran_reverse;
  --=====================================================================================================
  -- modified by S.V.SREERAJ -- FOR PERFORMANCE
  -- Modified date : 03-06-2008

  /*PROCEDURE pr_check_float (
    v_ins_seq_id               IN  TPA_INS_INFO.ins_seq_id%TYPE,
    v_prod_general_type_id     IN  tpa_float_account.prod_general_type_id%TYPE,
    v_group_reg_seq_id         IN  tpa_group_registration.group_reg_seq_id%TYPE,
    v_float_seq_id             OUT TPA_FLOAT_ACCOUNT.float_seq_id%TYPE
  )
  IS

    CURSOR float_acc_cur(v_ins_seq_id NUMBER ,v_prod_general_type_id VARCHAR2,v_group_reg_seq_id NUMBER)
       IS SELECT oa.float_seq_id FROM tpa_float_account oa JOIN
        ( SELECT a.ins_seq_id,a.ins_parent_seq_id,LEVEL AS l FROM TPA_INS_INFO A START WITH A.INS_SEQ_ID = v_ins_seq_id
           CONNECT BY PRIOR a.ins_parent_seq_id = a.ins_seq_id )ob ON (oa.ins_seq_id = ob.ins_seq_id)
           WHERE ( \*v_prod_general_type_id IS NULL AND*\ oa.prod_general_type_id IS NULL OR  oa.prod_general_type_id = v_prod_general_type_id )
            AND ( v_group_reg_seq_id IS NULL AND oa.group_reg_seq_id IS NULL OR  oa.group_reg_seq_id = v_group_reg_seq_id )
            AND (oa.expiration_date IS NULL OR oa.expiration_date >= SYSDATE )
            AND oa.float_status = 'ASA' ORDER BY l ;

  BEGIN
    OPEN  float_acc_cur(v_ins_seq_id,v_prod_general_type_id,v_group_reg_seq_id);
    FETCH float_acc_cur INTO v_float_seq_id;
    CLOSE float_acc_cur;

    IF v_float_seq_id IS NULL THEN
      IF (v_ins_seq_id IS NOT NULL AND v_prod_general_type_id IS NOT NULL AND v_group_reg_seq_id IS NOT NULL) THEN
        OPEN  float_acc_cur(v_ins_seq_id,v_prod_general_type_id,NULL);
        FETCH float_acc_cur INTO v_float_seq_id;
        CLOSE float_acc_cur;
        IF v_float_seq_id IS NULL THEN
          OPEN  float_acc_cur(v_ins_seq_id,NULL,NULL);
          FETCH float_acc_cur INTO v_float_seq_id;
          CLOSE float_acc_cur;
        END IF;
      ELSIF (v_ins_seq_id IS NOT NULL AND v_prod_general_type_id IS NOT NULL AND v_group_reg_seq_id IS NULL) THEN
        OPEN  float_acc_cur(v_ins_seq_id,NULL,NULL);
        FETCH float_acc_cur INTO v_float_seq_id;
        CLOSE float_acc_cur;
      END IF;
    END IF;
  END pr_check_float;*/
  PROCEDURE pr_check_float(v_ins_seq_id           IN TPA_INS_INFO.ins_seq_id%TYPE,
                           v_prod_general_type_id IN tpa_float_account.prod_general_type_id%TYPE,
                           v_group_reg_seq_id     IN tpa_group_registration.group_reg_seq_id%TYPE,
                           v_claim_seq_id         IN clm_authorization_details.claim_seq_id%TYPE,
                           v_float_seq_id         OUT TPA_FLOAT_ACCOUNT.float_seq_id%TYPE) IS

    CURSOR float_acc_cur(v_ins_seq_id           NUMBER,
                         v_prod_general_type_id VARCHAR2,
                         v_group_reg_seq_id     NUMBER,
                         v_claim_process_type   VARCHAR2) IS
      SELECT oa.float_seq_id
        FROM tpa_float_account oa
        LEFT OUTER JOIN tpa_float_group_assoc fa
          ON (oa.float_seq_id = fa.float_seq_id)
        JOIN (SELECT a.ins_seq_id, a.ins_parent_seq_id, LEVEL AS l
                FROM TPA_INS_INFO A
               START WITH A.INS_SEQ_ID = v_ins_seq_id
              CONNECT BY PRIOR a.ins_parent_seq_id = a.ins_seq_id) ob
          ON (oa.ins_seq_id = ob.ins_seq_id)
       WHERE (oa.prod_general_type_id IS NULL OR
             oa.prod_general_type_id = v_prod_general_type_id)
         AND (v_group_reg_seq_id IS NULL AND fa.group_reg_seq_id IS NULL OR
             fa.group_reg_seq_id = v_group_reg_seq_id)
         AND (oa.expiration_date IS NULL OR oa.expiration_date >= SYSDATE)
         AND oa.float_status = 'ASA'
         AND NVL(oa.process_type,'RGL') = v_claim_process_type
       ORDER BY l;
       
  CURSOR cur_claim_type(v_claim_seq_id   NUMBER) IS
     SELECT NVL(ca.process_type,'RGL') AS process_type
     FROM app.clm_authorization_details ca
     WHERE ca.claim_seq_id = v_claim_seq_id;
     
   v_claim_process_type             app.clm_authorization_details.process_type%TYPE;
   
  BEGIN
    
   OPEN  cur_claim_type(v_claim_seq_id);
   FETCH cur_claim_type INTO v_claim_process_type;
   CLOSE cur_claim_type;
  
    OPEN float_acc_cur(v_ins_seq_id,
                       v_prod_general_type_id,
                       v_group_reg_seq_id,
                       v_claim_process_type);
    FETCH float_acc_cur
      INTO v_float_seq_id;
    CLOSE float_acc_cur;


    IF v_float_seq_id IS NULL THEN
      IF (v_ins_seq_id IS NOT NULL AND v_prod_general_type_id IS NOT NULL AND
         v_group_reg_seq_id IS NOT NULL) THEN
        OPEN float_acc_cur(v_ins_seq_id, v_prod_general_type_id, NULL,v_claim_process_type);
         FETCH float_acc_cur
          INTO v_float_seq_id;
        CLOSE float_acc_cur;   
        IF v_float_seq_id IS NULL THEN
          OPEN float_acc_cur(v_ins_seq_id, NULL, NULL,v_claim_process_type);
          FETCH float_acc_cur
            INTO v_float_seq_id;
          CLOSE float_acc_cur;
 
        END IF;
        IF v_float_seq_id IS NULL THEN
          OPEN float_acc_cur(v_ins_seq_id, v_prod_general_type_id, NULL,'RGL');
         FETCH float_acc_cur
          INTO v_float_seq_id;
        CLOSE float_acc_cur;
        END IF;
        
        IF v_float_seq_id IS NULL THEN
          OPEN float_acc_cur(v_ins_seq_id, NULL, NULL,'RGL');
          FETCH float_acc_cur
            INTO v_float_seq_id;
          CLOSE float_acc_cur;
        END IF;
      ELSIF (v_ins_seq_id IS NOT NULL AND
            v_prod_general_type_id IS NOT NULL AND
            v_group_reg_seq_id IS NULL) THEN
        OPEN float_acc_cur(v_ins_seq_id, NULL, NULL,v_claim_process_type);
        FETCH float_acc_cur
          INTO v_float_seq_id;
        CLOSE float_acc_cur;
        
        IF v_float_seq_id IS NULL THEN
          OPEN float_acc_cur(v_ins_seq_id, NULL, NULL,'RGL');
        FETCH float_acc_cur
          INTO v_float_seq_id;
        CLOSE float_acc_cur;
        END IF;
      END IF;
    END IF;
  END pr_check_float;
  --============================================================================================
  --This procedure is mainly used for cheque advice type
  --==============================================================================
  -- modified by S.V.SREERAJ -- FOR PERFORMANCE
  -- Modified date : 03-03-2008

  PROCEDURE print_bank_advice(v_payment_seq_id IN VARCHAR2, -- Concatenated string of payment_seq_ids seperated by '|'
                              v_float_seq_id   IN TPA_FLOAT_ACCOUNT.float_seq_id%type,
                              v_payment_method IN TPA_CLAIMS_PAYMENT.payee_type%TYPE,
                              v_added_by       IN NUMBER,
                              v_rows_processed OUT INTEGER) IS
    str_tab               ttk_util_pkg.str_table_type := ttk_util_pkg.parse_str(v_payment_seq_id);
    v_bank_acc_seq_id     tpa_bank_accounts.bank_acc_seq_id%TYPE;
    v_counter2            NUMBER(20);
    v_payment_seq_id_list VARCHAR2(32767) := REPLACE(SUBSTR(v_payment_seq_id,
                                                           2,
                                                           LENGTH(v_payment_seq_id) - 2),
                                                    '|',
                                                    ',');
    v_resultset           SYS_REFCURSOR;
    v_sum                 NUMBER := 0;
    c_payment_id          tpa_claims_payment.payment_seq_id%TYPE;
    v_batch_number        NUMBER(20);
    v_claim_chk_id        NUMBER(20);
    v_tab_ctr NUMBER(6);
    v_claim_amount     NUMBER(20,2);

    CURSOR payment_status_cur(c_payment_id tpa_claims_payment.payment_seq_id%TYPE) IS
      SELECT COUNT(1)
        INTO v_counter2
        FROM tpa_claims_payment PT
       WHERE PT.payment_seq_id = c_payment_id
         AND PT.claim_payment_status = 'READY_TO_BANK';
         
    CURSOR claimed_amount(v_pay_seq_id NUMBER) is
      SELECT P.Approved_Amount
        FROM FIN_APP.TPA_CLAIMS_PAYMENT P
        WHERE P.PAYMENT_SEQ_ID =  v_pay_seq_id;   

  BEGIN
    --IF payee_type is BANK ADVICE (PCA)

    IF (v_payment_method = 'PCA') THEN
      v_tab_ctr := str_tab.COUNT;

      IF v_tab_ctr > 999 THEN
        RAISE_APPLICATION_ERROR(-20684,
                                'Maximum selection allowed is 950. ');
      END IF;

      IF v_tab_ctr > 1 THEN
        EXECUTE IMMEDIATE 'SELECT SUM(a.approved_amount) FROM tpa_claims_payment a
            WHERE a.payment_seq_id IN (' ||
                          v_payment_seq_id_list || ')'
          INTO v_sum;
      ELSE
        SELECT SUM(a.approved_amount)
          INTO v_sum
          FROM tpa_claims_payment a
         WHERE a.payment_seq_id = str_tab(1); --AND a.Claim_Payment_Status ='PENDING';
      END IF;

      IF v_sum > 0 THEN
        --here float_account balance is updating after settling claims.
        INSERT INTO tpa_batch_master
               (batch_number, added_by, added_date)
         VALUES
               (batch_master_seq.NEXTVAL, v_added_by, SYSDATE)
          RETURNING batch_number INTO v_batch_number;
        
        UPDATE tpa_float_account
           SET current_balance = current_balance - v_sum
         WHERE float_seq_id = v_float_seq_id
        RETURNING bank_acc_seq_id INTO v_bank_acc_seq_id;
        --Added by Prasanna Kumar.
        UPDATE tpa_bank_accounts
           SET bank_balance = bank_balance - v_sum
         WHERE bank_acc_seq_id = v_bank_acc_seq_id;
         
      IF str_tab.FIRST IS NOT NULL THEN
          for i in  str_tab.FIRST..str_tab.LAST LOOP
            
          
          open claimed_amount(str_tab(i));
            fetch claimed_amount into v_claim_amount;
             close claimed_amount;
           
           INSERT INTO tpa_claims_check
            (claims_chk_seq_id,
             check_num,
             check_date,
             check_status,
             check_amount,
             dsp_courier_name,
             courier_delivery_date,
             batch_number,
             added_by,
             added_date,
             PAYMENT_TYPE) --koc1175
          VALUES
            (claims_chk_seq.NEXTVAL,
             NULL,
             SYSDATE,
             'CSI',
             v_claim_amount,
             'DHL',
             SYSDATE,
             v_batch_number,
             v_added_by,
             SYSDATE,
             'PCA') --koc1175
          RETURNING claims_chk_seq_id INTO v_claim_chk_id;
          
           INSERT INTO tpa_payment_checks_details
            (payment_check_seq_id,
             payment_seq_id,
             claims_chk_seq_id,
             added_by,
             added_date)
          VALUES
            (claims_payment_check_seq.NEXTVAL,
              str_tab(i),
             v_claim_chk_id,
             v_added_by,
             SYSDATE);
        END LOOP;
           
        FORALL i IN str_tab.FIRST .. str_tab.LAST
            UPDATE tpa_claims_payment
               SET payee_type           = 'PCA',
                   claim_payment_status = 'READY_TO_BANK'
             WHERE payment_seq_id = str_tab(i); --  AND claim_payment_status ='PENDING';
        END IF;
      END IF;

      IF SQL%ROWCOUNT != str_tab.COUNT OR nvl(v_sum, 0) = 0 THEN
        RAISE_APPLICATION_ERROR(-20244, 'Claim(s) already PAID');
      END IF;
    ELSE
      RAISE_APPLICATION_ERROR(-20250, 'SELECT THE BANK ADVICE METHOD');
    END IF; -- end of PBA IF
    v_rows_processed := STR_TAB.COUNT;
    COMMIT;
  END print_bank_advice;
  --==========================================================================================================
  --this procedure is used to setle the unsettled claims to a bank.
  -- modified by S.V.SREERAJ -- FOR PERFORMANCE
  -- Modified date : 03-06-2008

  PROCEDURE float_accnts_unsettld_clm IS
  BEGIN
    FOR rec in (SELECT a.ins_seq_id,
                       a.payment_seq_id,
                       a. float_seq_id,
                       a.policy_seq_id,
                       a.group_reg_seq_id,
                       c.prod_general_type_id,
                       a.claim_seq_id
                  FROM tpa_claims_payment a
                  JOIN tpa_enr_policy b
                    ON (a.policy_seq_id = b.policy_seq_id)
                  JOIN tpa_ins_product c
                    ON (b.product_seq_id = c.product_seq_id)
                 WHERE a.float_seq_id IS NULL) LOOP
      pr_check_float(rec.ins_seq_id,
                     rec.prod_general_type_id,
                     rec.group_reg_seq_id,
                     rec.claim_seq_id,
                     rec.float_seq_id);

      IF rec.float_seq_id IS NOT NULL THEN
        UPDATE tpa_claims_payment
           SET float_seq_id = rec.float_seq_id, remarks = NULL
         WHERE payment_seq_id = rec.payment_seq_id;
      ELSE
        UPDATE tpa_claims_payment
           SET remarks = 'Account Not Exists'
         WHERE payment_seq_id = rec.payment_seq_id;
      END IF;
    END LOOP;
    COMMIT;
  END float_accnts_unsettld_clm;
  ---================================================================================================================
  ---comments bank_type taken 99 for cr koc1212 on 30aug12
  ---- modified by ravi
  --- cr koc1212 axis bank pro pay advice and removing for duplicate records
  --- CR kocdup for avoiding duplicate records by ravi ) 08nov2012
  --====================================================================================
  PROCEDURE generate_payment_advice(v_payment_seq_id IN VARCHAR2,
                                    v_float_seq_id   IN tpa_float_account.float_seq_id%TYPE,
                                    v_bank_type      IN VARCHAR2, -- '0' for CITI, '1' for UTI and '2' for ICICI bank
                                    v_batch_date     IN DATE,
                                    v_added_by       IN NUMBER,
                                    v_payment_type   IN VARCHAR2,
                                    v_pur_of_rem     IN VARCHAR2,
                                    v_rows_processed OUT INTEGER,
                                    v_resultset      OUT SYS_REFCURSOR) IS
    v_filename                   VARCHAR2(50);
    v_bank_seq_id                tpa_bank_master.bank_seq_id%TYPE;
    v_count_of_payments          tpa_claims_payment.payment_seq_id%TYPE;
    v_batch_seq_id               tpa_bank_advice_batch.batch_seq_id%TYPE;
    v_bank_advice_file_name      tpa_bank_advice_batch.bank_advice_file_name%TYPE;
    str_tab                      ttk_util_pkg.str_table_type;
    v_where                      VARCHAR2(32000);
    v_sql_str                    VARCHAR2(32767);
    i                            NUMBER(2) := 0;
    v_tds_str                    VARCHAR2(32000);
    v_claim_seq_id               tpa_claims_payment.claim_seq_id%TYPE;
    v_hosp_seq_id                tpa_claims_payment.hosp_seq_id%TYPE;
    v_cheque_amount              tpa_claims_payment.approved_amount%TYPE;
    v_appr_amount                tpa_claims_payment.approved_amount%TYPE;
    v_tds_payment_seq_id         tpa_claims_payment.payment_seq_id%TYPE;
    split_amt_tab                split_amt_type;
    split_perc_tab               split_amt_type;
    v_exist_yn                   VARCHAR2(1) := 'N';
    v_tpa_nhcp_cheques_issued_to tpa_claims_payment.tpa_nhcp_cheques_issued_to%TYPE;
    v_unique                     varchar2(50);
    v_acc_num                    VARCHAR2(50);
  
    CURSOR tpa_bank_details IS
      SELECT ad.bank_name,
             ad.account_number,
             ad.branch_name,
             ad.bank_micr,
             ad.bank_ifsc,
             ad.account_type
        FROM fin_app.tpa_account_details ad;
    tpa_rec tpa_bank_details%rowtype; --balley
  
  BEGIN
  
    OPEN tpa_bank_details;
    FETCH tpa_bank_details
      INTO tpa_rec;
    CLOSE tpa_bank_details;
  
    str_tab := ttk_util_pkg.parse_str(v_payment_seq_id);
  
    SELECT A.bank_seq_id,A.ACCOUNT_NUMBER
      INTO v_bank_seq_id,v_acc_num
      FROM tpa_bank_accounts a
      JOIN tpa_float_account b
        ON (a.bank_acc_seq_id = b.bank_acc_seq_id)
     WHERE b.float_seq_id = v_float_seq_id;
  
    IF (str_tab.FIRST IS NOT NULL) THEN
      IF str_tab.COUNT <= 8 THEN
        FOR i in str_tab.FIRST .. str_tab.LAST LOOP
          v_where := v_where || ' OR D.payment_seq_id = :bind_tab_' || i;
        END LOOP;
      ELSE
        v_where := ' OR D.payment_seq_id IN ( ' ||
                   REPLACE(SUBSTR(v_payment_seq_id,
                                  2,
                                  LENGTH(v_payment_seq_id) - 2),
                           '|',
                           ',') || ') ';
      END IF;
    END IF;
  
    IF v_where IS NOT NULL THEN
      v_where := ' AND (' || substr(v_where, 4) || ')';
    END IF;
  
    IF v_bank_type = '1' THEN
      INSERT INTO tpa_bank_advice_batch
        (batch_seq_id,
         batch_date,
         batch_file_no,
         bank_seq_id,
         float_seq_id,
         added_by,
         added_date,
         bank_advice_file_name)
      VALUES
        (bank_advice_batch_seq.NEXTVAL,
         v_batch_date,
         'FILE_NO' || bank_advice_batch_file_seq.NEXTVAL,
         v_bank_seq_id,
         v_float_seq_id,
         v_added_by,
         SYSDATE,
         'DXB' || '_' || TO_CHAR(v_batch_date, 'YYYYMMDD') || '_' ||
         bank_adv_batch_file_name_slno.NEXTVAL)
      RETURNING batch_seq_id, bank_advice_file_name INTO v_batch_seq_id, v_bank_advice_file_name;
    ELSIF v_bank_type = '4' THEN
      INSERT INTO tpa_bank_advice_batch
        (batch_seq_id,
         batch_date,
         batch_file_no,
         bank_seq_id,
         float_seq_id,
         added_by,
         added_date,
         bank_advice_file_name)
      VALUES
        (bank_advice_batch_seq.NEXTVAL,
         v_batch_date,
         'FILE_NO' || bank_advice_batch_file_seq.NEXTVAL,
         v_bank_seq_id,
         v_float_seq_id,
         v_added_by,
         SYSDATE,
         'DXB' || '_' || TO_CHAR(v_batch_date, 'YYYYMMDD') || '_' ||
         bank_adv_batch_file_name_slno.NEXTVAL)
      RETURNING batch_seq_id, bank_advice_file_name INTO v_batch_seq_id, v_bank_advice_file_name;
    
    ELSIF v_bank_type = '99' THEN
      INSERT INTO tpa_bank_advice_batch
        (batch_seq_id,
         batch_date,
         batch_file_no,
         bank_seq_id,
         float_seq_id,
         added_by,
         added_date,
         bank_advice_file_name)
      VALUES
        (bank_advice_batch_seq.NEXTVAL,
         v_batch_date,
         'FILE_NO' || bank_advice_batch_file_seq.NEXTVAL,
         v_bank_seq_id,
         v_float_seq_id,
         v_added_by,
         SYSDATE,
         'DXB' || '_' || TO_CHAR(v_batch_date, 'YYYYMMDD') || '_' ||
         bank_adv_batch_file_name_slno.NEXTVAL)
      RETURNING batch_seq_id, bank_advice_file_name INTO v_batch_seq_id, v_bank_advice_file_name;

    ELSE
      INSERT INTO tpa_bank_advice_batch
        (batch_seq_id,
         batch_date,
         batch_file_no,
         bank_seq_id,
         float_seq_id,
         added_by,
         added_date,
         bank_advice_file_name)
      VALUES
        (bank_advice_batch_seq.NEXTVAL,
         v_batch_date,
         'FILE_NO' || bank_advice_batch_file_seq.NEXTVAL,
         v_bank_seq_id,
         v_float_seq_id,
         v_added_by,
         SYSDATE,
         'DXB' || '_' || TO_CHAR(v_batch_date, 'YYYYMMDD') || '_' ||
         bank_adv_batch_file_name_slno.NEXTVAL)
      RETURNING batch_seq_id INTO v_batch_seq_id;
    END IF;
    --if bank_type is CITIBANK
  
    v_tds_str := ' SELECT a.payment_seq_id ,a.claim_seq_id ,a.hosp_seq_id, a.approved_amount, A.tpa_nhcp_cheques_issued_to
      FROM tpa_claims_payment a  WHERE a.float_seq_id = :v_float_seq_id ' ||
                 regexp_replace(v_where, 'D\.', 'A.') ||
                 ' AND a.claim_payment_status  = ''READY_TO_BANK''';
  
    IF str_tab.FIRST IS NOT NULL THEN
      IF str_tab.COUNT <= 8 THEN
        CASE str_tab.COUNT
          WHEN 1 THEN
            OPEN v_resultset FOR v_tds_str
              USING v_float_seq_id, str_tab(1);
          WHEN 2 THEN
            OPEN v_resultset FOR v_tds_str
              USING v_float_seq_id, str_tab(1), str_tab(2);
          WHEN 3 THEN
            OPEN v_resultset FOR v_tds_str
              USING v_float_seq_id, str_tab(1), str_tab(2), str_tab(3);
          WHEN 4 THEN
            OPEN v_resultset FOR v_tds_str
              USING v_float_seq_id, str_tab(1), str_tab(2), str_tab(3), str_tab(4);
          WHEN 5 THEN
            OPEN v_resultset FOR v_tds_str
              USING v_float_seq_id, str_tab(1), str_tab(2), str_tab(3), str_tab(4), str_tab(5);
          WHEN 6 THEN
            OPEN v_resultset FOR v_tds_str
              USING v_float_seq_id, str_tab(1), str_tab(2), str_tab(3), str_tab(4), str_tab(5), str_tab(6);
          WHEN 7 THEN
            OPEN v_resultset FOR v_tds_str
              USING v_float_seq_id, str_tab(1), str_tab(2), str_tab(3), str_tab(4), str_tab(5), str_tab(6), str_tab(7);
          WHEN 8 THEN
            OPEN v_resultset FOR v_tds_str
              USING v_float_seq_id, str_tab(1), str_tab(2), str_tab(3), str_tab(4), str_tab(5), str_tab(6), str_tab(7), str_tab(8);
        END CASE;
      ELSE
        OPEN v_resultset FOR v_tds_str
          USING v_float_seq_id;
      END IF;
    END IF;
    /*LOOP
    
      FETCH v_resultset INTO v_tds_payment_seq_id,v_claim_seq_id, v_hosp_seq_id,v_appr_amount,v_tpa_nhcp_cheques_issued_to;
      EXIT WHEN v_resultset%NOTFOUND OR v_resultset%NOTFOUND IS NULL;
      IF v_hosp_seq_id IS NOT NULL AND v_tpa_nhcp_cheques_issued_to IN ('HOS','MAN') THEN
        v_cheque_amount := v_appr_amount;
    
        --get_tds_amount(v_claim_seq_id, v_hosp_seq_id , v_cheque_amount,split_amt_tab,split_perc_tab, v_exist_yn );
        IF v_exist_yn = 'N' THEN
          save_clm_tds_details( v_tds_payment_seq_id,v_claim_seq_id,v_appr_amount,v_cheque_amount,split_amt_tab,split_perc_tab,'P',v_added_by);
        END IF;
      --opdforhs
       ELSIF v_hosp_seq_id IS NULL AND v_tpa_nhcp_cheques_issued_to='TPA' THEN
        v_cheque_amount := v_appr_amount;
    
        --get_tds_amount(v_claim_seq_id, v_hosp_seq_id , v_cheque_amount,split_amt_tab,split_perc_tab, v_exist_yn );
        IF v_exist_yn = 'N' THEN
          save_clm_tds_details( v_tds_payment_seq_id,v_claim_seq_id,v_appr_amount,v_cheque_amount,split_amt_tab,split_perc_tab,'P',v_added_by);
        END IF;
        --opdforhs
      END IF;
    END LOOP;*/
    CLOSE v_resultset;
  
    -- dense_rank() over (order by a.claim_seq_id,ald.ailment_details_seq_id) as AQ, for avoiding two ailments
  
    IF (v_bank_type IN ('0', '2', '3')) THEN
      ---Changes to implement payment advice for HDFC.  KOC647     ...RJP
      v_filename := CASE
                      WHEN v_bank_type = '0' THEN
                       'ENBD-'
                      WHEN v_bank_type = '2' THEN
                       'ENBD-'
                      WHEN v_bank_type = '3' THEN
                       'ENBD-'
                    END || TO_CHAR(v_batch_date, 'DDMMYYYY-HH24MISS') || '-' ||
                    v_added_by;
      IF v_bank_type = '0' THEN
        v_sql_str := 'WITH sum_tab as
         ( SELECT D.payment_seq_id, 
            (a.tot_disc_gross_amount-a.tot_patient_share_amount - a.tot_approved_amount) as v_rej_amt,
            a.tot_discount_amount AS v_disc_amt,
            /*SUM( CASE WHEN C.apply_discount_yn = ''Y'' THEN (C.REQUESTED_AMOUNT * NVL(C.discount_percnt,0))/100
            ELSE 0 END ) AS v_disc_amt,*/ 
            --D.Approved_Amount AS v_pay_amt,
            nvl(c.check_amount, a.tot_approved_amount) AS v_chq_amt,
            a.tot_approved_amount AS v_pay_amt,
            --c.check_amount AS v_chq_amt,
            (a.tot_disc_gross_amount-a.tot_patient_share_amount) AS requested_amount,
            --SUM (CASE WHEN b.bill_date NOT BETWEEN trunc(a.date_of_admission) AND trunc(a.date_of_discharge) THEN c.allowed_amount ELSE 0 END)  pre_post_amount,
            --SUM (CASE WHEN ward_type_id IN (''ROO'',''NUC'') THEN c.allowed_amount ELSE 0 END ) AS ROOM_CHARGES,
            --SUM (CASE WHEN ward_type_id IN (''ICU'',''ICC'',''ICN'',''ICR'') THEN c.allowed_amount ELSE 0 END ) AS ICU_CHARGES,
            --SUM (CASE WHEN ward_type_id IN (''PRO'') THEN c.allowed_amount ELSE 0 END ) AS PROFESSIONAL_CHARGES,
            --SUM (CASE WHEN ward_type_id IN (''LAI'') THEN c.allowed_amount ELSE 0 END ) AS LAB_CHARGES,
            --SUM (CASE WHEN ward_type_id IN (''PHA'',''MED'') THEN c.allowed_amount ELSE 0 END ) AS PHARMACY_CHARGES
            NULL AS pre_post_amount,
            NULL AS ROOM_CHARGES,
            NULL AS ICU_CHARGES,
            NULL AS PROFESSIONAL_CHARGES,
            NULL AS LAB_CHARGES,
            NULL AS PHARMACY_CHARGES
        
          FROM clm_authorization_details A 
              INNER JOIN tpa_claims_payment D ON (A.claim_seq_id = D.claim_seq_id)
              LEFT OUTER JOIN tpa_payment_checks_details E ON (d.payment_seq_id = e.payment_seq_id)
              LEFT OUTER JOIN tpa_claims_check C on (e.claims_chk_seq_id = c.claims_chk_seq_id)
              WHERE D.float_seq_id = :v_float_seq_id ' ||
                     v_where || ' )
              --GROUP BY D.payment_seq_id,a.tot_approved_amount, nvl(c.check_amount, a.tot_approved_amount))
              
         select * from (
          SELECT a.payment_seq_id,dense_rank() over (partition by a.claim_seq_id order by ald.ailment_details_seq_id,rownum desc) as AQ,
              a.claim_payment_status ,' ||
                     v_batch_seq_id ||
                     '  AS batch_no,
              NULL AS save_file_name,
              nvl(Ll.v_rej_amt,0)  AS tot_disallow_amt,
              nvl(Ll.v_disc_amt,0)  AS tot_discount_amt,
              nvl(Ll.v_pay_amt,0)  AS tot_payable_amt,
              nvl(Ll.v_chq_amt,0)  AS cheuqe_amt,
              rownum AS slno,
              CASE WHEN a.hosp_seq_id IS NOT NULL THEN ''H''
                     ELSE CASE WHEN a.ENROL_TYPE_ID IN (''IND'',''ING'') THEN ''I'' WHEN a.ENROL_TYPE_ID =''COR'' THEN ''C'' ELSE ''N'' END
                END  AS chq_drawee,
              ttk_util_pkg.fn_decrypt(a.payee_name) as payee_name,
              a.address1||'', ''||a.address2||'',''||a.address3 AS address,
              a.address1,
              a.address2,
              a.address3,
              null as address4,
              null as address5,
              null as address6,
              a.city,
              a.state,
              a.pincode,
              b.policy_number,
              c.tpa_enrollment_id,
              d.insured_name as mem_name,
              d.employee_no,
              c.certificate_no,
              l.mem_name as claimant_name,
            --l.in_patient_no as ipno,
              null as ipno,
              l.settlement_number as claim_settlement_number ,
              a.claim_amount,
              ''PLEASE CONTACT Vidal Health TPA Pvt. Ltd FOR FURTHER DETAILS. ANY DISAGREEMENT CALL /WRITE WITHIN 10 DAYS.TOLL FREE 080-40539789'' AS pay_adv1,
              ''ENCASHMENT OF CHEQUE DISCHARGES THE LIABILITY OF INSURER UNDER THE SAID CLAIM'' AS pay_adv2,
              --f.remarks as dis_allow_reason1,
              null as dis_allow_reason2,
              null as dis_allow_reason3,
              null as dis_allow_reason4,
              null as dis_allow_reason5,
              i.address_1||i.address_2||i.address_3 AS addr1,
              i.address_1,
              i.address_2,
              i.address_3,
              j.city_description,
              i.pin_code,
              k.off_phone_no_1,
              k.office_fax_no_1,
              h.ins_comp_name,
              1 as do_lost,
              k.email_id,
              NULL AS UTIACC_NUM,
              ''DXB''||k.office_code||''PAY1'' as product_name, h.ins_comp_code_number,
              l.claim_number, k.office_code,
              gc.description, c.mem_age, rc.relship_description as Relationship,
              to_char(b.effective_from_date,''dd/mm/yyyy'') AS effective_from_date,
              to_char(b.effective_to_date,''dd/mm/yyyy'') AS effective_to_date,
              --to_char(ci.rcvd_date,''dd/mm/yyyy'') AS rcvd_date,
              --to_char(ci.rcvd_date,''dd-Mon-yyyy'') AS clm_rcvd_dt,
              --b.total_sum_insured,
              CASE WHEN b.policy_sub_general_type_id=''PNF'' THEN c.mem_tot_sum_insured
                 ELSE d.family_tot_sum_insured END as total_sum_insured,
              b.tpa_cheque_issued_general_type,
              --to_char(l.date_of_admission,''dd/mm/yyyy'') AS date_of_admission,
              --to_char(l.date_of_discharge,''dd/mm/yyyy'') AS date_of_discharge,
              --(trunc(l.date_of_discharge)-trunc(l.date_of_admission)) AS NoOfDays,
              nvl(hosa.hosp_name,hospi.hosp_name) AS hosp_name,
              NVL(hosa.city_name, city.city_description) AS Hosp_place,
              cc.check_num,
              to_char(cc.check_date,''dd/mm/yyyy'') AS check_date,
              ct.description AS Claim_Type,
              
              CASE WHEN ct.description=''Member'' /*AND nvl(L.pay_to_general_type_id,''MBR'')!=''HSL'' */ THEN--This is added for hyundai requirement    -- 3 fields added for CR  KOC1108--same 3 fields modified for koc1103 for parmanent solution
              --CASE WHEN a.tpa_nhcp_cheques_issued_to=''TPA'' THEN ''' ||
                     tpa_rec.account_number ||
                     ''' ELSE 
              (CASE WHEN b.enrol_type_id=''COR'' THEN (CASE WHEN b.tpa_cheque_issued_general_type=''IQI'' THEN ttk_util_pkg.fn_decrypt(p.bank_account_no)
              WHEN B.tpa_cheque_issued_general_type=''IQC'' THEN ttk_util_pkg.fn_decrypt(r.bank_account_no) END)
              ELSE ttk_util_pkg.fn_decrypt(p.bank_account_no) END)--end
              ELSE 
                CASE l.pymnt_to_type_id WHEN ''PTN'' THEN ttk_util_pkg.fn_decrypt(pa.account_number) 
                                        ELSE ttk_util_pkg.fn_decrypt(q.account_number) 
                END
              end as account_num,--Modified for koc11ed
              
              CASE WHEN ct.description=''Member''/*AND nvl(L.pay_to_general_type_id,''MBR'')!=''HSL'' */ THEN--This is added for hyundai requirement
              --CASE WHEN a.tpa_nhcp_cheques_issued_to=''TPA'' THEN ''' ||
                     tpa_rec.account_type ||
                     ''' ELSE 
              (CASE WHEN b.enrol_type_id=''COR'' THEN (CASE WHEN b.tpa_cheque_issued_general_type=''IQI'' THEN p.account_name
              WHEN B.tpa_cheque_issued_general_type=''IQC'' THEN r.account_name end)
              ELSE P.account_name END)--END 
              ELSE 
                CASE l.pymnt_to_type_id WHEN ''PTN'' THEN pa.account_type 
                                        ELSE q.account_type 
                END
              end as account_type,
                
              CASE WHEN ct.description=''Member'' /*AND nvl(L.pay_to_general_type_id,''MBR'')!=''HSL'' */THEN--This is added for hyundai requirement
              --CASE WHEN a.tpa_nhcp_cheques_issued_to=''TPA'' THEN ''' ||
                     tpa_rec.bank_micr ||
                     ''' ELSE 
              (CASE WHEN b.enrol_type_id=''COR'' THEN (CASE WHEN b.tpa_cheque_issued_general_type=''IQI'' THEN ttk_util_pkg.fn_decrypt(p.bank_micr)
              WHEN B.tpa_cheque_issued_general_type=''IQC'' THEN ttk_util_pkg.fn_decrypt(r.bank_micr) end)
              ELSE ttk_util_pkg.fn_decrypt(p.bank_micr) END)--END
              ELSE 
                CASE l.pymnt_to_type_id WHEN ''PTN'' THEN pa.bank_micr 
                                        ELSE q.bank_micr 
                END
              END AS MICR_CODE,  --Modified for koc11ed
                
              CASE WHEN ct.description=''Member'' /*AND nvl(L.pay_to_general_type_id,''MBR'')!=''HSL'' */THEN--This is added for hyundai requirement
              --CASE WHEN a.tpa_nhcp_cheques_issued_to=''TPA'' THEN ''' ||
                     tpa_rec.bank_ifsc ||
                     ''' ELSE 
              (CASE WHEN b.enrol_type_id=''COR'' THEN (CASE WHEN b.tpa_cheque_issued_general_type=''IQI'' THEN ttk_util_pkg.fn_decrypt(p.bank_ifsc)
              WHEN B.tpa_cheque_issued_general_type=''IQC'' THEN ttk_util_pkg.fn_decrypt(r.bank_ifsc) end)
              ELSE ttk_util_pkg.fn_decrypt(p.bank_ifsc) END)--END 
              ELSE 
                  CASE l.pymnt_to_type_id WHEN ''PTN'' THEN pa.bank_ifsc 
                                          ELSE q.bank_ifsc 
                  END
              END AS IFSC_CODE,   --Modified for koc11ed
                
              CASE WHEN c.mem_general_type_id = ''PFL'' THEN d.floater_tot_bonus ELSE c.mem_tot_bonus END AS bonus,
  --            bons.bonus,
              ald.ailment_description AS ailment,
              CASE WHEN tpa_nhcp_cheques_issued_to =''HOS'' AND hospi.hosp_seq_id IS NOT NULL THEN
                        nvl(Ll.v_chq_amt,0) ELSE 0 END AS Qtm_Disbursed_Cashless,
              CASE WHEN NVL(tpa_nhcp_cheques_issued_to,''*'') !=''HOS'' THEN nvl(Ll.v_chq_amt,0) ELSE 0 END AS Qtm_Disbursed_Reimb,
              NULL AS Trans_ref_num, k.office_name,
              FLOAT_ACCOUNTS_PKG.get_Rej_billno(l.claim_seq_id) as Bill_no,
              (SELECT office_name FROM tpa_office_info WHERE office_code = SUBSTR(a.claim_settlement_no,1,3) AND ROWNUM = 1) as print_pay_loc,
              Ll.requested_amount,  ---for KOC647  ...RJP
              -------------------------------------------------From Here
              CASE WHEN A.PAYEE_TYPE=''EFT'' THEN ''N''  ELSE ''D'' END AS payment_type, -- Payment Type ADDED FOR KOC1103
              a.approved_amount , -- Gross Amount
              ll.pre_post_amount, -- Quantum disbursed - pre/ post hospitalization
              FLOAT_ACCOUNTS_PKG.get_date_of_inception ( c.tpa_enrollment_id  , a.policy_seq_id , b.ins_head_office_seq_id  ) as date_of_inception, -- Date of inception of first policy
              batch_report_pkg.get_comp_icds(a.claim_seq_id) AS icd_codes, -- ICD code
              ll.requested_amount AS bill_requested_amount, -- Total billed amount for period of hospitalization
              a.approved_amount  - TDS.check_amount  AS tds_amt, -- TDS
              ll.room_charges, -- Room/ Board/ nursing charges
              ll.icu_charges, -- ICU charges
              ll.professional_charges, -- Professional fees
              ll.lab_charges, -- Lab/ investigation charges
              ll.pharmacy_charges, -- Pharmacy charges
              a.approved_amount - ( ll.room_charges + ll.icu_charges + ll.professional_charges + ll.lab_charges + ll.pharmacy_charges ) AS other_charges, -- Other charges
              --l.total_app_amount - nvl(l.serv_tax_calc_amount,0) AS Claim_Amt_NoST,
              --l.serv_tax_calc_amount AS Service_Tax,
              Ll.v_chq_amt AS Net_Amount --- 3 fields added for CR - KOC1028. RJP.
         FROM tpa_claims_payment a JOIN tpa_enr_policy b ON (a.policy_seq_id = b.policy_seq_id)
              JOIN tpa_enr_policy_member c ON (a.member_seq_id = c.member_seq_id)
              JOIN tpa_enr_policy_group d ON (D.policy_group_seq_id = C.policy_group_seq_id)
              --JOIN clm_general_details l ON (l.claim_seq_id = a.claim_seq_id)
              --JOIN clm_enroll_details e ON (l.claim_seq_id = e.claim_seq_id)
              --JOIN clm_inward ci ON (l.claims_inward_seq_id = ci.claims_inward_seq_id)
              JOIN clm_authorization_details l ON (l.claim_seq_id = a.claim_seq_id)
              JOIN tpa_ins_info h ON (a.ins_seq_id = h.ins_seq_id)
              JOIN tpa_address i ON(h.tpa_office_seq_id = i.tpa_office_seq_id)
              JOIN tpa_city_code j ON (i.city_type_id = j.city_type_id)
              JOIN tpa_office_info k ON (h.tpa_office_seq_id = k.tpa_office_seq_id)
              LEFT OUTER JOIN sum_tab Ll ON (A.payment_seq_id = Ll.payment_seq_id)
              --LEFT OUTER JOIN assign_users f ON (l.claim_seq_id = f.claim_seq_id and l.last_assign_user_seq_id = f.assign_users_seq_id)
              LEFT OUTER JOIN tpa_general_code gc ON (c.gender_general_type_id = gc.general_type_id)
              LEFT OUTER JOIN tpa_relationship_code rc ON (c.relship_type_id = rc.relship_type_id)
              LEFT OUTER JOIN app.clm_hospital_details hosa ON (l.claim_seq_id = hosa.claim_seq_id)
              LEFT OUTER JOIN tpa_hosp_info hospi ON (hosa.hosp_seq_id = hospi.hosp_seq_id)
              LEFT OUTER JOIN tpa_hosp_address ha ON (hospi.hosp_seq_id = ha.hosp_seq_id)
              LEFT OUTER JOIN tpa_city_code city ON (ha.city_type_id = city.city_type_id)
              LEFT OUTER JOIN tpa_enr_bank_dtls P  ON (d.BANK_SEQ_ID=p.BANK_SEQ_ID)
              LEFT OUTER JOIN tpa_enr_bank_dtls r  ON (b.bank_seq_id=r.bank_seq_id)--ADDED FOR KOC1103
              LEFT OUTER JOIN tpa_hosp_account_details q ON(hospi.hosp_seq_id=q.hosp_seq_id)
         --     LEFT OUTER JOIN syn_hosp_ifsc_details  Q  ON (Q.EMPANEL_NUM=HOSPI.EMPANEL_NUMBER)  --Created FOR CR KOC1108 Temporarily and removed for parmanently cr koc1103
              LEFT OUTER JOIN tpa_payment_checks_details pcd ON (a.payment_seq_id = pcd.payment_seq_id and pcd.v_csr_flag=1)
              LEFT OUTER JOIN tpa_claims_check cc ON (pcd.claims_chk_seq_id = cc.claims_chk_seq_id and cc.v_csr_flag=1)
              LEFT OUTER JOIN tpa_general_code ct ON (l.claim_type = ct.general_type_id )
              --LEFT OUTER JOIN tpa_enr_balance bons ON (d.policy_group_seq_id = bons.policy_group_seq_id AND ( c.mem_general_type_id = ''PFL'' AND bons.member_seq_id IS NULL OR c.mem_general_type_id != ''PFL'' AND c.member_seq_id = bons.member_seq_id))
              LEFT OUTER JOIN ailment_details ald  ON (a.claim_seq_id = ald.claim_seq_id)
              LEFT OUTER JOIN tpa_clm_tds_details TDS  ON (a.claim_seq_id = TDS.claim_seq_id)
              LEFT OUTER JOIN tpa_partner_info pi ON (a.ptnr_seq_id=pi.ptnr_seq_id)
              LEFT OUTER JOIN tpa_partner_account_details pa ON (pi.ptnr_seq_id=pa.ptnr_seq_id)
              WHERE a.float_seq_id = :v_float_seq_id ' ||
                     regexp_replace(v_where, 'D\.', 'A.') ||
                     ' AND a.claim_payment_status  = ''READY_TO_BANK'' )';
      ELSE
        v_sql_str := ' WITH sum_tab as ( SELECT D.payment_seq_id, (a.tot_disc_gross_amount-a.tot_patient_share_amount - a.tot_approved_amount) as v_rej_amt,
            a.tot_discount_amount AS v_disc_amt,
            /*SUM( CASE WHEN C.apply_discount_yn = ''Y'' THEN (C.REQUESTED_AMOUNT * NVL(C.discount_percnt,0))/100
            ELSE 0 END ) AS v_disc_amt,*/ 
            --D.Approved_Amount AS v_pay_amt,
            --nvl(e.check_amount, D.Approved_Amount) AS v_chq_amt,
            nvl(c.check_amount, a.tot_approved_amount) AS v_chq_amt,
            a.tot_approved_amount AS v_pay_amt,
            --c.check_amount AS v_chq_amt,
            (a.tot_disc_gross_amount-a.tot_patient_share_amount) AS requested_amount,
            --SUM (CASE WHEN b.bill_date NOT BETWEEN trunc(a.date_of_admission) AND trunc(a.date_of_discharge) THEN c.allowed_amount ELSE 0 END)  pre_post_amount,
            --SUM (CASE WHEN ward_type_id IN (''ROO'',''NUC'') THEN c.allowed_amount ELSE 0 END ) AS ROOM_CHARGES,
            --SUM (CASE WHEN ward_type_id IN (''ICU'',''ICC'',''ICN'',''ICR'') THEN c.allowed_amount ELSE 0 END ) AS ICU_CHARGES,
            --SUM (CASE WHEN ward_type_id IN (''PRO'') THEN c.allowed_amount ELSE 0 END ) AS PROFESSIONAL_CHARGES,
            --SUM (CASE WHEN ward_type_id IN (''LAI'') THEN c.allowed_amount ELSE 0 END ) AS LAB_CHARGES,
            --SUM (CASE WHEN ward_type_id IN (''PHA'',''MED'') THEN c.allowed_amount ELSE 0 END ) AS PHARMACY_CHARGES
            NULL AS pre_post_amount,
            NULL AS ROOM_CHARGES,
            NULL AS ICU_CHARGES,
            NULL AS PROFESSIONAL_CHARGES,
            NULL AS LAB_CHARGES,
            NULL AS PHARMACY_CHARGES
            FROM clm_authorization_details A 
              INNER JOIN tpa_claims_payment D ON (A.claim_seq_id = D.claim_seq_id)
              LEFT OUTER JOIN tpa_payment_checks_details E ON (d.payment_seq_id = e.payment_seq_id)
              LEFT OUTER JOIN tpa_claims_check C on (e.claims_chk_seq_id = c.claims_chk_seq_id)
              WHERE D.float_seq_id = :v_float_seq_id ' ||
                     v_where || ' GROUP BY D.payment_seq_id,D.Approved_Amount, nvl(c.check_amount, D.Approved_Amount))
select * from (
    SELECT a.payment_seq_id, dense_rank() over (partition by a.claim_seq_id order by ald.ailment_details_seq_id,rownum desc) as AQ,
            a.claim_payment_status ,' || v_batch_seq_id ||
                     '  AS batch_no,
            NULL AS save_file_name,
            nvl(Ll.v_rej_amt,0)  AS tot_disallow_amt,
            nvl(Ll.v_disc_amt,0)  AS tot_discount_amt,
            nvl(Ll.v_pay_amt,0)  AS tot_payable_amt,
            nvl(Ll.v_chq_amt,0)  AS cheuqe_amt,
            rownum AS slno,
            CASE WHEN a.hosp_seq_id IS NOT NULL THEN ''H''
                   ELSE CASE WHEN a.ENROL_TYPE_ID IN (''IND'',''ING'') THEN ''I'' WHEN a.ENROL_TYPE_ID =''COR'' THEN ''C'' ELSE ''N'' END
              END  AS chq_drawee,
            ttk_util_pkg.fn_decrypt(a.payee_name) payee_name , --Modified for koc11ed
            a.address1||'', ''||a.address2||'',''||a.address3 AS address,
            a.address1,
            a.address2,
            a.address3,
            null as address4,
            null as address5,
            null as address6,
            a.city,
            a.state,
            a.pincode,
            b.policy_number,
            c.tpa_enrollment_id,
            d.insured_name as mem_name,
            d.employee_no,
            c.certificate_no,
            l.mem_name as claimant_name,
            --l.in_patient_no as ipno,
            null as ipno,
            l.settlement_number as claim_settlement_number ,
            a.claim_amount,
            ''PLEASE CONTACT Vidal Health TPA Pvt. Ltd FOR FURTHER DETAILS. ANY DISAGREEMENT CALL /WRITE WITHIN 10 DAYS.TOLL FREE 080-40539789'' AS pay_adv1,
            ''ENCASHMENT OF CHEQUE DISCHARGES THE LIABILITY OF INSURER UNDER THE SAID CLAIM'' AS pay_adv2,
            --f.remarks as dis_allow_reason1,
            null as dis_allow_reason2,
            null as dis_allow_reason3,
            null as dis_allow_reason4,
            null as dis_allow_reason5,
            i.address_1||i.address_2||i.address_3 AS addr1,
            i.address_1,
            i.address_2,
            i.address_3,
            j.city_description,
            i.pin_code,
            k.off_phone_no_1,
            k.office_fax_no_1,
            h.ins_comp_name,
            1 as do_lost,
            k.email_id, --not required to modfiy for koc11ed
            NULL AS UTIACC_NUM,
            ''DXB''||k.office_code||''PAY1'' as product_name, h.ins_comp_code_number,
            l.claim_number, k.office_code,
            gc.description, c.mem_age, rc.relship_description as Relationship,
            to_char(b.effective_from_date,''dd/mm/yyyy'') AS effective_from_date,
            to_char(b.effective_to_date,''dd/mm/yyyy'') AS effective_to_date,
            to_char(ci.rcvd_date,''dd/mm/yyyy'') AS rcvd_date,
            to_char(ci.rcvd_date,''dd-Mon-yyyy'') AS clm_rcvd_dt,
            --b.total_sum_insured,
            CASE WHEN b.policy_sub_general_type_id=''PNF'' THEN c.mem_tot_sum_insured
                 ELSE d.family_tot_sum_insured END as total_sum_insured,
            b.tpa_cheque_issued_general_type,
            to_char(l.date_of_admission,''dd/mm/yyyy'') AS date_of_admission,
            to_char(l.date_of_discharge,''dd/mm/yyyy'') AS date_of_discharge,
            (trunc(l.date_of_discharge)-trunc(l.date_of_admission)) AS NoOfDays,
            nvl(hosa.hosp_name,hospi.hosp_name) AS hosp_name,
            NVL(hosa.city_name, city.city_description) AS Hosp_place,
            cc.check_num,
            to_char(cc.check_date,''dd/mm/yyyy'') AS check_date,
            ct.description AS Claim_Type,
            CASE WHEN c.mem_general_type_id = ''PFL'' THEN d.floater_tot_bonus ELSE c.mem_tot_bonus END AS bonus,
--            bons.bonus,
            ald.ailment_description AS ailment,
            CASE WHEN tpa_nhcp_cheques_issued_to =''HOS'' AND hospi.hosp_seq_id IS NOT NULL THEN
                      nvl(Ll.v_chq_amt,0) ELSE 0 END AS Qtm_Disbursed_Cashless,
            CASE WHEN NVL(tpa_nhcp_cheques_issued_to,''*'') !=''HOS'' THEN nvl(Ll.v_chq_amt,0) ELSE 0 END AS Qtm_Disbursed_Reimb,
            NULL AS Trans_ref_num, k.office_name,
            FLOAT_ACCOUNTS_PKG.get_Rej_billno(l.claim_seq_id) as Bill_no,
            (SELECT office_name FROM tpa_office_info WHERE office_code = SUBSTR(a.claim_settlement_no,1,3) AND ROWNUM = 1) as print_pay_loc,
            Ll.requested_amount,  ---for KOC647  ...RJP
            NULL AS payment_type,
            NULL AS  date_of_inception,
            NULL AS  icd_codes,
            NULL AS  bill_requested_amount,
            --NULL AS claim_amount,
            NULL AS  tds_amt,
            NULL AS room_charges,
            NULL AS icu_charges,
            NULL AS professional_charges,
            NULL AS lab_charges,
            NULL AS pharmacy_charges,
            NULL AS  other_charges,
            NULL AS Claim_Amt_NoST,
            NULL AS Service_Tax,
            
              CASE WHEN ct.description=''Member'' /*AND nvl(L.pay_to_general_type_id,''MBR'')!=''HSL'' */ THEN--This is added for hyundai requirement    -- 3 fields added for CR  KOC1108--same 3 fields modified for koc1103 for parmanent solution
              --CASE WHEN a.tpa_nhcp_cheques_issued_to=''TPA'' THEN ''' ||
                     tpa_rec.account_number ||
                     ''' ELSE 
              (CASE WHEN b.enrol_type_id=''COR'' THEN (CASE WHEN b.tpa_cheque_issued_general_type=''IQI'' THEN ttk_util_pkg.fn_decrypt(p.bank_account_no)
              WHEN B.tpa_cheque_issued_general_type=''IQC'' THEN ttk_util_pkg.fn_decrypt(r.bank_account_no) END)
              ELSE ttk_util_pkg.fn_decrypt(p.bank_account_no) END)--end
              ELSE 
                CASE l.pymnt_to_type_id WHEN ''PTN'' THEN ttk_util_pkg.fn_decrypt(pa.account_number) 
                                        ELSE ttk_util_pkg.fn_decrypt(q.account_number) 
                END
              end as account_num,--Modified for koc11ed
              
              CASE WHEN ct.description=''Member''/*AND nvl(L.pay_to_general_type_id,''MBR'')!=''HSL'' */ THEN--This is added for hyundai requirement
              --CASE WHEN a.tpa_nhcp_cheques_issued_to=''TPA'' THEN ''' ||
                     tpa_rec.account_type ||
                     ''' ELSE 
              (CASE WHEN b.enrol_type_id=''COR'' THEN (CASE WHEN b.tpa_cheque_issued_general_type=''IQI'' THEN p.account_name
              WHEN B.tpa_cheque_issued_general_type=''IQC'' THEN r.account_name end)
              ELSE P.account_name END)--END 
              ELSE 
                CASE l.pymnt_to_type_id WHEN ''PTN'' THEN pa.account_type 
                                        ELSE q.account_type 
                END
              end as account_type,
                
              CASE WHEN ct.description=''Member'' /*AND nvl(L.pay_to_general_type_id,''MBR'')!=''HSL'' */THEN--This is added for hyundai requirement
              --CASE WHEN a.tpa_nhcp_cheques_issued_to=''TPA'' THEN ''' ||
                     tpa_rec.bank_micr ||
                     ''' ELSE 
              (CASE WHEN b.enrol_type_id=''COR'' THEN (CASE WHEN b.tpa_cheque_issued_general_type=''IQI'' THEN ttk_util_pkg.fn_decrypt(p.bank_micr)
              WHEN B.tpa_cheque_issued_general_type=''IQC'' THEN ttk_util_pkg.fn_decrypt(r.bank_micr) end)
              ELSE ttk_util_pkg.fn_decrypt(p.bank_micr) END)--END
              ELSE 
                CASE l.pymnt_to_type_id WHEN ''PTN'' THEN pa.bank_micr 
                                        ELSE q.bank_micr 
                END
              END AS MICR_CODE,  --Modified for koc11ed
                
              CASE WHEN ct.description=''Member'' /*AND nvl(L.pay_to_general_type_id,''MBR'')!=''HSL'' */THEN--This is added for hyundai requirement
              --CASE WHEN a.tpa_nhcp_cheques_issued_to=''TPA'' THEN ''' ||
                     tpa_rec.bank_ifsc ||
                     ''' ELSE 
              (CASE WHEN b.enrol_type_id=''COR'' THEN (CASE WHEN b.tpa_cheque_issued_general_type=''IQI'' THEN ttk_util_pkg.fn_decrypt(p.bank_ifsc)
              WHEN B.tpa_cheque_issued_general_type=''IQC'' THEN ttk_util_pkg.fn_decrypt(r.bank_ifsc) end)
              ELSE ttk_util_pkg.fn_decrypt(p.bank_ifsc) END)--END 
              ELSE 
                CASE l.pymnt_to_type_id WHEN ''PTN'' THEN pa.bank_ifsc 
                                          ELSE q.bank_ifsc 
                  END
              END AS IFSC_CODE,   --Modified for koc11ed
                   
            NULL AS Net_Amount --- 3 fields added for CR - KOC1028. RJP.
       FROM tpa_claims_payment a JOIN tpa_enr_policy b ON (a.policy_seq_id = b.policy_seq_id)
            JOIN tpa_enr_policy_member c ON (a.member_seq_id = c.member_seq_id)
            JOIN tpa_enr_policy_group d ON (D.policy_group_seq_id = C.policy_group_seq_id)
            --JOIN clm_general_details l ON (l.claim_seq_id = a.claim_seq_id)
            --JOIN clm_general_details l ON (l.claim_seq_id = a.claim_seq_id)
            --JOIN clm_enroll_details e ON (l.claim_seq_id = e.claim_seq_id)
            JOIN clm_authorization_details l ON (l.claim_seq_id = a.claim_seq_id)
            JOIN tpa_ins_info h ON (a.ins_seq_id = h.ins_seq_id)
            JOIN tpa_address i ON(h.tpa_office_seq_id = i.tpa_office_seq_id)
            JOIN tpa_city_code j ON (i.city_type_id = j.city_type_id)
            JOIN tpa_office_info k ON (h.tpa_office_seq_id = k.tpa_office_seq_id)
            LEFT OUTER JOIN sum_tab Ll ON (A.payment_seq_id = Ll.payment_seq_id)
            --LEFT OUTER JOIN assign_users f ON (l.claim_seq_id = f.claim_seq_id and l.last_assign_user_seq_id = f.assign_users_seq_id)
            LEFT OUTER JOIN tpa_general_code gc ON (c.gender_general_type_id = gc.general_type_id)
            LEFT OUTER JOIN tpa_relationship_code rc ON (c.relship_type_id = rc.relship_type_id)
            LEFT OUTER JOIN app.clm_hospital_details hosa ON (l.claim_seq_id = hosa.claim_seq_id)
            LEFT OUTER JOIN tpa_hosp_info hospi ON (hosa.hosp_seq_id = hospi.hosp_seq_id)
            LEFT OUTER JOIN tpa_hosp_address ha ON (hospi.hosp_seq_id = ha.hosp_seq_id)
            LEFT OUTER JOIN tpa_enr_bank_dtls r  ON (b.bank_seq_id=r.bank_seq_id)--ADDED FOR KOC1103
            LEFT OUTER JOIN tpa_enr_bank_dtls P  ON (D.BANK_SEQ_ID=P.BANK_SEQ_ID)--ADDED FOR KOC1103
            LEFT OUTER JOIN tpa_hosp_account_details q ON(hospi.hosp_seq_id=q.hosp_seq_id) --ADDED FOR KOC1103
            LEFT OUTER JOIN tpa_city_code city ON (ha.city_type_id = city.city_type_id)
            LEFT OUTER JOIN tpa_payment_checks_details pcd ON (a.payment_seq_id = pcd.payment_seq_id and pcd.v_csr_flag=1)
            LEFT OUTER JOIN tpa_claims_check cc ON (pcd.claims_chk_seq_id = cc.claims_chk_seq_id and cc.v_csr_flag=1)
            LEFT OUTER JOIN tpa_general_code ct ON (l.claim_type = ct.general_type_id )
            --LEFT OUTER JOIN tpa_enr_balance bons ON (d.policy_group_seq_id = bons.policy_group_seq_id AND ( c.mem_general_type_id = ''PFL'' AND bons.member_seq_id IS NULL OR c.mem_general_type_id != ''PFL'' AND c.member_seq_id = bons.member_seq_id))
            LEFT OUTER JOIN ailment_details ald  ON (a.claim_seq_id = ald.claim_seq_id)
            LEFT OUTER JOIN tpa_partner_info pi ON (a.ptnr_seq_id=pi.ptnr_seq_id)
            LEFT OUTER JOIN tpa_partner_account_details pa ON (pi.ptnr_seq_id=pa.ptnr_seq_id)
            WHERE a.float_seq_id = :v_float_seq_id ' ||
                     regexp_replace(v_where, 'D\.', 'A.') ||
                     ' AND a.claim_payment_status  = ''READY_TO_BANK'')';
      END IF;
    ELSIF (v_bank_type = '1') THEN
      v_filename := 'ENBD' || '-' ||
                    TO_CHAR(v_batch_date, 'DDMMYYYY-HH24MISS') || '-' ||
                    v_added_by;
      v_sql_str  := ' WITH sum_tab as (SELECT D.payment_seq_id, (a.tot_disc_gross_amount-a.tot_patient_share_amount - a.tot_approved_amount) as v_rej_amt,
            a.tot_discount_amount AS v_disc_amt,
            /*SUM( CASE WHEN C.apply_discount_yn = ''Y'' THEN (C.REQUESTED_AMOUNT * NVL(C.discount_percnt,0))/100
            ELSE 0 END ) AS v_disc_amt,*/ 
            --D.Approved_Amount AS v_pay_amt,
            --nvl(e.check_amount, D.Approved_Amount) AS v_chq_amt,
            nvl(c.check_amount, a.tot_approved_amount) AS v_chq_amt,
            a.tot_approved_amount AS v_pay_amt,
            --c.check_amount AS v_chq_amt,
            (a.tot_disc_gross_amount-a.tot_patient_share_amount) AS requested_amount,
            --SUM (CASE WHEN b.bill_date NOT BETWEEN trunc(a.date_of_admission) AND trunc(a.date_of_discharge) THEN c.allowed_amount ELSE 0 END)  pre_post_amount,
            --SUM (CASE WHEN ward_type_id IN (''ROO'',''NUC'') THEN c.allowed_amount ELSE 0 END ) AS ROOM_CHARGES,
            --SUM (CASE WHEN ward_type_id IN (''ICU'',''ICC'',''ICN'',''ICR'') THEN c.allowed_amount ELSE 0 END ) AS ICU_CHARGES,
            --SUM (CASE WHEN ward_type_id IN (''PRO'') THEN c.allowed_amount ELSE 0 END ) AS PROFESSIONAL_CHARGES,
            --SUM (CASE WHEN ward_type_id IN (''LAI'') THEN c.allowed_amount ELSE 0 END ) AS LAB_CHARGES,
            --SUM (CASE WHEN ward_type_id IN (''PHA'',''MED'') THEN c.allowed_amount ELSE 0 END ) AS PHARMACY_CHARGES
            NULL AS pre_post_amount,
            NULL AS ROOM_CHARGES,
            NULL AS ICU_CHARGES,
            NULL AS PROFESSIONAL_CHARGES,
            NULL AS LAB_CHARGES,
            NULL AS PHARMACY_CHARGES
            FROM clm_authorization_details A 
              INNER JOIN tpa_claims_payment D ON (A.claim_seq_id = D.claim_seq_id)
              LEFT OUTER JOIN tpa_payment_checks_details E ON (d.payment_seq_id = e.payment_seq_id)
              LEFT OUTER JOIN tpa_claims_check C on (e.claims_chk_seq_id = c.claims_chk_seq_id)
              WHERE D.float_seq_id = :v_float_seq_id ' ||
                    v_where || ' GROUP BY D.payment_seq_id,D.Approved_Amount, nvl(c.check_amount, D.Approved_Amount))
              

        SELECT a.payment_seq_id,
              a.claim_payment_status ,
              ' || v_batch_seq_id || ' AS batch_no,
              ''' || v_bank_advice_file_name ||
                    ''' AS save_file_name,
              nvl(Ll.v_rej_amt,0)  AS tot_disallow_amt,
              nvl(Ll.v_disc_amt,0)  AS tot_discount_amt,
              nvl(Ll.v_pay_amt,0)  AS tot_payable_amt,
              nvl(Ll.v_chq_amt,0)  AS cheuqe_amt,
              to_number(CASE WHEN fin_payment_adv_slno.NEXTVAL > 199999
                                  THEN fin_payment_adv_slno.CURRVAL+50001
                                  ELSE fin_payment_adv_slno.CURRVAL END  ) AS slno,
              CASE WHEN a.hosp_seq_id IS NOT NULL THEN ''H''
                   ELSE CASE WHEN a.ENROL_TYPE_ID IN (''IND'',''ING'') THEN ''I'' WHEN a.ENROL_TYPE_ID =''COR'' THEN ''C'' ELSE ''N'' END
              END AS chq_drawee,
              ttk_util_pkg.fn_decrypt(a.payee_name) payee_name, --Modified for koc11ed
              a.address1||'', ''||a.address2||'',''||a.address3 AS address,
              a.address1,
              a.address2,
              a.address3,
              null as address4,
              null as address5,
              null as address6,
              a.city,
              a.state,
              a.pincode,
              b.policy_number,
              c.tpa_enrollment_id,
              d.insured_name as mem_name ,
              d.employee_no,
              c.certificate_no,
              l.mem_name as claimant_name,
              --l.in_patient_no as ipno,
              null as ipno,
              l.settlement_number as claim_settlement_number ,
              a.claim_amount,
              ''PLS CONTACT US FOR FURTHER DETAILS'' AS pay_adv1,
              ''ENCASHMENT OF CHEQUE DISCHARGES THE LIABILITY OF INSURER UNDER THE SAID CLAIM'' AS pay_adv2,
              --f.remarks as dis_allow_reason1,
              null as dis_allow_reason2,
              null as dis_allow_reason3,
              null as dis_allow_reason4,
              null as dis_allow_reason5,
              i.address_1||i.address_2||i.address_3 AS addr1,
              i.address_1,
              i.address_2,
              i.address_3,
              j.city_description,
              i.pin_code,
              k.off_phone_no_1,
              k.office_fax_no_1,
              h.ins_comp_name,
              1 as do_lost,
              k.email_id,--not required to modfiy for koc11ed
              n.account_number AS UTIACC_NUM,
              ''DXB''||k.office_code||''PAY1'' AS product_name,
              ''Vidal Health TPA Pvt. Ltd'' AS TTK_Name,
              
                CASE WHEN ct.description=''Member'' /*AND nvl(L.pay_to_general_type_id,''MBR'')!=''HSL'' */ THEN--This is added for hyundai requirement    -- 3 fields added for CR  KOC1108--same 3 fields modified for koc1103 for parmanent solution
              --CASE WHEN a.tpa_nhcp_cheques_issued_to=''TPA'' THEN ''' ||
                    tpa_rec.account_number ||
                    ''' ELSE 
              (CASE WHEN b.enrol_type_id=''COR'' THEN (CASE WHEN b.tpa_cheque_issued_general_type=''IQI'' THEN ttk_util_pkg.fn_decrypt(p.bank_account_no)
              WHEN B.tpa_cheque_issued_general_type=''IQC'' THEN ttk_util_pkg.fn_decrypt(r.bank_account_no) END)
              ELSE ttk_util_pkg.fn_decrypt(p.bank_account_no) END)--end
              ELSE 
                CASE l.pymnt_to_type_id WHEN ''PTN'' THEN ttk_util_pkg.fn_decrypt(pa.account_number) 
                                        ELSE ttk_util_pkg.fn_decrypt(q.account_number) 
                END
              end as account_num,--Modified for koc11ed
              
              CASE WHEN ct.description=''Member''/*AND nvl(L.pay_to_general_type_id,''MBR'')!=''HSL'' */ THEN--This is added for hyundai requirement
              --CASE WHEN a.tpa_nhcp_cheques_issued_to=''TPA'' THEN ''' ||
                    tpa_rec.account_type ||
                    ''' ELSE 
              (CASE WHEN b.enrol_type_id=''COR'' THEN (CASE WHEN b.tpa_cheque_issued_general_type=''IQI'' THEN p.account_name
              WHEN B.tpa_cheque_issued_general_type=''IQC'' THEN r.account_name end)
              ELSE P.account_name END)--END 
              ELSE 
                CASE l.pymnt_to_type_id WHEN ''PTN'' THEN pa.account_type 
                                        ELSE q.account_type 
                END 
              end as account_type,
                
              CASE WHEN ct.description=''Member'' /*AND nvl(L.pay_to_general_type_id,''MBR'')!=''HSL'' */THEN--This is added for hyundai requirement
              --CASE WHEN a.tpa_nhcp_cheques_issued_to=''TPA'' THEN ''' ||
                    tpa_rec.bank_micr ||
                    ''' ELSE 
              (CASE WHEN b.enrol_type_id=''COR'' THEN (CASE WHEN b.tpa_cheque_issued_general_type=''IQI'' THEN ttk_util_pkg.fn_decrypt(p.bank_micr)
              WHEN B.tpa_cheque_issued_general_type=''IQC'' THEN ttk_util_pkg.fn_decrypt(r.bank_micr) end)
              ELSE ttk_util_pkg.fn_decrypt(p.bank_micr) END)--END
              ELSE 
                CASE l.pymnt_to_type_id WHEN ''PTN'' THEN pa.bank_micr 
                                        ELSE q.bank_micr 
                END
              END AS MICR_CODE,  --Modified for koc11ed
                
              CASE WHEN ct.description=''Member'' /*AND nvl(L.pay_to_general_type_id,''MBR'')!=''HSL'' */THEN--This is added for hyundai requirement
              --CASE WHEN a.tpa_nhcp_cheques_issued_to=''TPA'' THEN ''' ||
                    tpa_rec.bank_ifsc ||
                    ''' ELSE 
              (CASE WHEN b.enrol_type_id=''COR'' THEN (CASE WHEN b.tpa_cheque_issued_general_type=''IQI'' THEN ttk_util_pkg.fn_decrypt(p.bank_ifsc)
              WHEN B.tpa_cheque_issued_general_type=''IQC'' THEN ttk_util_pkg.fn_decrypt(r.bank_ifsc) end)
              ELSE ttk_util_pkg.fn_decrypt(p.bank_ifsc) END)--END 
              ELSE 
                CASE l.pymnt_to_type_id WHEN ''PTN'' THEN pa.bank_ifsc 
                                          ELSE q.bank_ifsc 
                END
              END AS IFSC_CODE,   --Modified for koc11ed
                
              
              o.office_name AS Location
              --pl.office_name AS Processed_Location
              FROM tpa_claims_payment a JOIN tpa_enr_policy b ON ( a.policy_seq_id = b.policy_seq_id )
              JOIN tpa_enr_policy_member c ON (a.member_seq_id = c.member_seq_id)
              JOIN tpa_enr_policy_group d ON (D.policy_group_seq_id = C.policy_group_seq_id)
              --JOIN clm_general_details l ON (l.claim_seq_id = a.claim_seq_id)
              --JOIN clm_enroll_details e ON (l.claim_seq_id = e.claim_seq_id)
              JOIN clm_authorization_details l ON (l.claim_seq_id = a.claim_seq_id)
              JOIN tpa_ins_info h ON (a.ins_seq_id = h.ins_seq_id)
              JOIN tpa_address i ON(h.tpa_office_seq_id = i.tpa_office_seq_id)
              JOIN tpa_city_code j ON (i.city_type_id = j.city_type_id)
              JOIN tpa_office_info k ON (h.tpa_office_seq_id = k.tpa_office_seq_id)
              JOIN tpa_office_info o ON (substr(a.claim_settlement_no ,1,3) = o.office_code)
              JOIN tpa_float_account m ON (m.float_seq_id = a.float_seq_id)
              JOIN tpa_bank_accounts n ON (n.bank_acc_seq_id = m.bank_acc_seq_id)
              --JOIN clm_inward ci ON (l.claims_inward_seq_id = ci.claims_inward_seq_id)--ADDED FOR KOC1103
              LEFT OUTER JOIN tpa_general_code ct ON (l.claim_type = ct.general_type_id )
              LEFT OUTER JOIN app.clm_hospital_details hosa ON (l.claim_seq_id = hosa.claim_seq_id)--KOC1103
              LEFT OUTER JOIN tpa_hosp_info hospi ON (hosa.hosp_seq_id = hospi.hosp_seq_id)--KOC1103
              LEFT OUTER JOIN tpa_hosp_address ha ON (hospi.hosp_seq_id = ha.hosp_seq_id)--KOC1103
              LEFT OUTER JOIN tpa_enr_bank_dtls r  ON (b.bank_seq_id=r.bank_seq_id)--ADDED FOR KOC1103
              LEFT OUTER JOIN tpa_enr_bank_dtls P  ON (D.BANK_SEQ_ID=P.BANK_SEQ_ID)--ADDED FOR KOC1103
              LEFT OUTER JOIN tpa_hosp_account_details q ON(hospi.hosp_seq_id=q.hosp_seq_id)--ADDED FOR KOC1103
              LEFT OUTER JOIN sum_tab Ll ON (A.payment_seq_id = Ll.payment_seq_id)
              --LEFT OUTER JOIN assign_users f ON (l.claim_seq_id = f.claim_seq_id and l.last_assign_user_seq_id = f.assign_users_seq_id)
              --LEFT OUTER JOIN tpa_office_info pl ON (f.tpa_office_seq_id = pl.tpa_office_seq_id)
              LEFT OUTER JOIN tpa_partner_info pi ON (a.ptnr_seq_id=pi.ptnr_seq_id)
              LEFT OUTER JOIN tpa_partner_account_details pa ON (pi.ptnr_seq_id=pa.ptnr_seq_id)
              WHERE a.float_seq_id = :v_float_seq_id ' ||
                    regexp_replace(v_where, 'D\.', 'A.') ||
                    ' AND a.claim_payment_status = ''READY_TO_BANK'' ';
    
    ELSIF (v_bank_type = '5') THEN
      --Added for KOC1220
      v_filename := 'ENBD' || TO_CHAR(v_batch_date, 'DDMMYYYYHH24MISS') || '' ||
                    v_added_by;
      -- select to_char(fin_payment_adv_uniqu_ref.nextval) into v_unique from dual;
      v_sql_str := 'WITH sum_tab as
         (SELECT D.payment_seq_id, (a.tot_disc_gross_amount-a.tot_patient_share_amount - a.tot_approved_amount) as v_rej_amt,
            a.tot_discount_amount AS v_disc_amt,
            /*SUM( CASE WHEN C.apply_discount_yn = ''Y'' THEN (C.REQUESTED_AMOUNT * NVL(C.discount_percnt,0))/100
            ELSE 0 END ) AS v_disc_amt,*/ 
            --D.Approved_Amount AS v_pay_amt,
            --nvl(e.check_amount, D.Approved_Amount) AS v_chq_amt,
            nvl(c.check_amount, a.tot_approved_amount) AS v_chq_amt,
            a.tot_approved_amount AS v_pay_amt,
            --c.check_amount AS v_chq_amt,
            (a.tot_disc_gross_amount-a.tot_patient_share_amount) AS requested_amount,
            --SUM (CASE WHEN b.bill_date NOT BETWEEN trunc(a.date_of_admission) AND trunc(a.date_of_discharge) THEN c.allowed_amount ELSE 0 END)  pre_post_amount,
            --SUM (CASE WHEN ward_type_id IN (''ROO'',''NUC'') THEN c.allowed_amount ELSE 0 END ) AS ROOM_CHARGES,
            --SUM (CASE WHEN ward_type_id IN (''ICU'',''ICC'',''ICN'',''ICR'') THEN c.allowed_amount ELSE 0 END ) AS ICU_CHARGES,
            --SUM (CASE WHEN ward_type_id IN (''PRO'') THEN c.allowed_amount ELSE 0 END ) AS PROFESSIONAL_CHARGES,
            --SUM (CASE WHEN ward_type_id IN (''LAI'') THEN c.allowed_amount ELSE 0 END ) AS LAB_CHARGES,
            --SUM (CASE WHEN ward_type_id IN (''PHA'',''MED'') THEN c.allowed_amount ELSE 0 END ) AS PHARMACY_CHARGES
            NULL AS pre_post_amount,
            NULL AS ROOM_CHARGES,
            NULL AS ICU_CHARGES,
            NULL AS PROFESSIONAL_CHARGES,
            NULL AS LAB_CHARGES,
            NULL AS PHARMACY_CHARGES
            FROM clm_authorization_details A 
              INNER JOIN tpa_claims_payment D ON (A.claim_seq_id = D.claim_seq_id)
              LEFT OUTER JOIN tpa_payment_checks_details E ON (d.payment_seq_id = e.payment_seq_id)
              LEFT OUTER JOIN tpa_claims_check C on (e.claims_chk_seq_id = c.claims_chk_seq_id)
              WHERE D.float_seq_id = :v_float_seq_id ' ||
                   v_where ||
                   ' GROUP BY D.payment_seq_id,D.Approved_Amount, nvl(c.check_amount, D.Approved_Amount))
              
         select boa.*,to_char(rownum) as slno, float_accounts_pkg.boa_unique(2) as Transaction_Ref from (
          SELECT dense_rank() over (partition by a.claim_seq_id order by ald.ailment_details_seq_id desc) as AQ,
            --  ''BULKCSV,VIDAL HEALTH TPA PVT. LTD,ttkhcs08,HDUL,''' ||
                   '||TO_CHAR(SYSDATE,''YYYYMMDD'')||'',''||''' ||
                   v_filename || '''||''.txt,TEST'' AS  header,
              ''BULKCSV''                AS BULKCSV,
              ''VIDAL HEALTH TPA PVT. LTD''  AS Company_Name,
              ''ttkhcs08'' AS Company_id,
              ''HDUL'' AS Company_EFT_Key,
              TO_CHAR(SYSDATE,''YYYYMMDD'') AS Creation_Date,
              ''' || v_filename ||
                   ''' AS file_name,
              ''PROD'' file_type,
              a.payment_seq_id,
              a.claim_payment_status ,
              to_char(a.bank_advice_batch) AS batch_no, --koc1220-A
              NULL AS save_file_name,
              nvl(Ll.v_rej_amt,0)  AS tot_disallow_amt,
              nvl(Ll.v_disc_amt,0)  AS tot_discount_amt,
              nvl(Ll.v_pay_amt,0)  AS tot_payable_amt,
              to_char(nvl(Ll.v_chq_amt,0))  AS cheuqe_amt,               -- Transaction Amount --koc1220
              to_char(rownum) AS slmno,
              CASE WHEN a.hosp_seq_id IS NOT NULL THEN ''H''
                     ELSE CASE WHEN a.ENROL_TYPE_ID IN (''IND'',''ING'') THEN ''I'' WHEN a.ENROL_TYPE_ID =''COR'' THEN ''C'' ELSE ''N'' END
                END  AS chq_drawee,
              ttk_util_pkg.fn_decrypt(a.payee_name) as payee_name,                         --Receiving Party Name
              SUBSTR(a.address1||'', ''||a.address2,1,35) AS address,  --Receiving Party Address 1
              SUBSTR(a.address3,1,35)   AS address1,                                                --Receiving Party Address 2
              a.address2,
              a.address3,
              null as address4,
              null as address5,
              null as address6,
              a.city,                                                        --Receiving Party City Name
              a.state,
              NULL AS recv_party_state_code,--Receiving Party State Code
              a.pincode,                                                     --Receiving Party Zip / Postal Code
              b.policy_number,
              c.tpa_enrollment_id,
              d.insured_name as mem_name,
              d.employee_no,
              c.certificate_no,
              l.mem_name as claimant_name,
              --l.in_patient_no as ipno,
              null as ipno,
              l.settlement_number as claim_settlement_number ,                      --Receiving Party ID
              a.claim_amount,
              ''PLEASE CONTACT Vidal Health TPA Pvt. Ltd FOR FURTHER DETAILS. ANY DISAGREEMENT CALL /WRITE WITHIN 10 DAYS.TOLL FREE  080-40539789'' AS pay_adv1,
              ''ENCASHMENT OF CHEQUE DISCHARGES THE LIABILITY OF INSURER UNDER THE SAID CLAIM'' AS pay_adv2,
              --f.remarks as dis_allow_reason1,
              null as dis_allow_reason2,
              null as dis_allow_reason3,
              null as dis_allow_reason4,
              null as dis_allow_reason5,
              i.address_1||i.address_2||i.address_3 AS addr1,
              i.address_1,
              i.address_2,
              i.address_3,
              j.city_description,
              i.pin_code,
              k.off_phone_no_1,
              k.office_fax_no_1,
              h.ins_comp_name,
              1 as do_lost,
              k.email_id,
              NULL AS UTIACC_NUM,
              ''DXB''||k.office_code||''PAY1'' as product_name, h.ins_comp_code_number,
              l.claim_number, k.office_code,
              gc.description, to_char(c.mem_age) as mem_age,
               rc.relship_description as Relationship,
              to_char(b.effective_from_date,''dd-mm-yyyy'') AS effective_from_date, --koc1220-A
              to_char(b.effective_to_date,''dd-mm-yyyy'') AS effective_to_date, --koc1220-A
              to_char(ci.rcvd_date,''dd-mm-yyyy'') AS rcvd_date, --koc1220-A
              to_char(ci.rcvd_date,''dd-Mon-yyyy'') AS clm_rcvd_dt,
              --b.total_sum_insured,
              nvl(to_char(CASE WHEN b.policy_sub_general_type_id=''PNF'' THEN c.mem_tot_sum_insured
                 ELSE d.family_tot_sum_insured END),0) as total_sum_insured, --KOC1220 --koc1220-A
              b.tpa_cheque_issued_general_type,
              to_char(l.date_of_admission,''dd-mm-yyyy'')AS date_of_admission, --koc1220-A
              to_char(l.date_of_discharge,''dd-mm-yyyy'') AS date_of_discharge, --koc1220-A
              to_char((trunc(l.date_of_discharge)-trunc(l.date_of_admission))) AS NoOfDays, --KOC1220
              nvl(hosa.hosp_name,hospi.hosp_name) AS hosp_name,
              NVL(hosa.city_name, city.city_description) AS Hosp_place,
              cc.check_num,       --Check Number
              to_char(cc.check_date,''dd/mm/yyyy'') AS check_date,
              ct.description AS Claim_Type,
--koc1220-A
              nvl(SUBSTR((CASE WHEN a.payee_type=''PCA'' THEN ''NA'' WHEN a.payee_type=''EFT''  THEN
              (CASE WHEN ct.description=''Member'' AND nvl(L.pay_to_general_type_id,''MBR'')!=''HSL'' THEN--This is added for hyundai requirement
              CASE WHEN a.tpa_nhcp_cheques_issued_to=''TPA'' THEN ''' ||
                   tpa_rec.bank_name ||
                   ''' ELSE 
              (CASE WHEN b.enrol_type_id=''COR'' THEN (CASE WHEN b.tpa_cheque_issued_general_type=''IQI'' THEN ttk_util_pkg.fn_decrypt(p.bank_name)
              WHEN B.tpa_cheque_issued_general_type=''IQC'' THEN ttk_util_pkg.fn_decrypt(r.bank_name) END)
              ELSE ttk_util_pkg.fn_decrypt(p.bank_name) END)END 
              ELSE 
                CASE l.pymnt_to_type_id WHEN ''PTN'' THEN ttk_util_pkg.fn_decrypt(pa.bank_name) 
                                        ELSE ttk_util_pkg.fn_decrypt(q.bank_name) 
                END
              END
                
                ) END),1,33),'''') as cust_bank_name,      --Receiving Bank Name

              nvl((CASE WHEN a.payee_type=''PCA'' THEN ''NA'' WHEN a.payee_type=''EFT''  THEN
              (CASE WHEN ct.description=''Member'' AND nvl(L.pay_to_general_type_id,''MBR'')!=''HSL'' THEN--This is added for hyundai requirement
               CASE WHEN a.tpa_nhcp_cheques_issued_to=''TPA'' THEN ''' ||
                   tpa_rec.account_number ||
                   ''' ELSE 
              (CASE WHEN b.enrol_type_id=''COR'' THEN (CASE WHEN b.tpa_cheque_issued_general_type=''IQI'' THEN ttk_util_pkg.fn_decrypt(p.bank_account_no)
              WHEN B.tpa_cheque_issued_general_type=''IQC'' THEN ttk_util_pkg.fn_decrypt(r.bank_account_no) END)
              ELSE ttk_util_pkg.fn_decrypt(p.bank_account_no) END)END
              ELSE 
                CASE l.pymnt_to_type_id WHEN ''PTN'' THEN ttk_util_pkg.fn_decrypt(pa.account_number) 
                                        ELSE ttk_util_pkg.fn_decrypt(q.account_number) 
                END
              END) END),'''') as account_num,    --Receiving Bank Account Number
--koc1220-A
              (CASE WHEN a.payee_type=''PCA'' THEN ''NA'' WHEN a.payee_type=''EFT''  THEN
              (CASE WHEN ct.description=''Member'' AND nvl(L.pay_to_general_type_id,''MBR'')!=''HSL'' THEN--This is added for hyundai requirement
               CASE WHEN a.tpa_nhcp_cheques_issued_to=''TPA'' THEN ''' ||
                   tpa_rec.account_type ||
                   ''' ELSE 
              (CASE WHEN b.enrol_type_id=''COR'' THEN (CASE WHEN b.tpa_cheque_issued_general_type=''IQI'' THEN ttk_util_pkg.fn_decrypt(p.account_name)
              WHEN B.tpa_cheque_issued_general_type=''IQC'' THEN ttk_util_pkg.fn_decrypt(r.account_name) end)
              ELSE ttk_util_pkg.fn_decrypt(P.account_name) END)END 
              ELSE 
                CASE l.pymnt_to_type_id WHEN ''PTN'' THEN pa.account_type 
                                        ELSE q.account_type 
                END
              end) END) as account_type,

              nvl((CASE WHEN a.payee_type=''PCA'' THEN ''NA'' WHEN a.payee_type=''EFT''  THEN
              (CASE WHEN ct.description=''Member'' AND nvl(L.pay_to_general_type_id,''MBR'')!=''HSL'' THEN--This is added for hyundai requirement
              CASE WHEN a.tpa_nhcp_cheques_issued_to=''TPA'' THEN ''' ||
                   tpa_rec.bank_micr ||
                   ''' ELSE 
              (CASE WHEN b.enrol_type_id=''COR'' THEN (CASE WHEN b.tpa_cheque_issued_general_type=''IQI'' THEN ttk_util_pkg.fn_decrypt(p.bank_micr)
              WHEN B.tpa_cheque_issued_general_type=''IQC'' THEN ttk_util_pkg.fn_decrypt(r.bank_micr) end)
              ELSE ttk_util_pkg.fn_decrypt(p.bank_micr) END)END 
              ELSE 
                CASE l.pymnt_to_type_id WHEN ''PTN'' THEN pa.bank_micr 
                                        ELSE q.bank_micr 
                END
              END) END),'''')AS MICR_CODE,

             (CASE WHEN a.payee_type=''PCA'' THEN ''NA'' WHEN a.payee_type=''EFT''  THEN
             (CASE WHEN ct.description=''Member'' AND nvl(L.pay_to_general_type_id,''MBR'')!=''HSL'' THEN--This is added for hyundai requirement
              CASE WHEN a.tpa_nhcp_cheques_issued_to=''TPA'' THEN ''' ||
                   tpa_rec.bank_ifsc ||
                   ''' ELSE 
             (CASE WHEN b.enrol_type_id=''COR'' THEN (CASE WHEN b.tpa_cheque_issued_general_type=''IQI'' THEN ttk_util_pkg.fn_decrypt(p.bank_ifsc)
              WHEN B.tpa_cheque_issued_general_type=''IQC'' THEN ttk_util_pkg.fn_decrypt(r.bank_ifsc) end)
              ELSE ttk_util_pkg.fn_decrypt(p.bank_ifsc) END)END 
              ELSE 
                CASE l.pymnt_to_type_id WHEN ''PTN'' THEN pa.bank_ifsc 
                                          ELSE q.bank_ifsc 
                END
              END) END) AS IFSC_CODE,           --Receiving Bank ID / Sort code

              NULL AS  Rcv_Bank_Qualifier,                  --Receiving Bank Qualifier
              NULL AS  RCV_Bank_Address,                    --Receiving Bank SWIFT Addres
              NULL AS  Rcv_bank_Branch_Num,                --Receiving Bank Branch Number
              ''INDIA'' AS Rcv_Bank_City,                   --ReceivingBank City Name
              ''IN''    AS Rcv_Bank_Country_Code,   --Receiving Bank ISO Country Code

              nvl(to_char(CASE WHEN c.mem_general_type_id = ''PFL'' THEN d.floater_tot_bonus ELSE c.mem_tot_bonus END),0) AS bonus, --KOC1220 --koc1220-A
  --            bons.bonus,
              ald.ailment_description AS ailment,
--koc1220-A
              case when nvl(to_char(CASE WHEN tpa_nhcp_cheques_issued_to =''HOS'' AND hospi.hosp_seq_id IS NOT NULL THEN
                        nvl(Ll.v_chq_amt,0) ELSE 0 END ),0) > 0 then
                        to_char(CASE WHEN tpa_nhcp_cheques_issued_to =''HOS'' AND hospi.hosp_seq_id IS NOT NULL THEN
                        nvl(Ll.v_chq_amt,0) ELSE 0 END ) else
              to_char(CASE WHEN NVL(tpa_nhcp_cheques_issued_to,''*'') !=''HOS'' THEN nvl(Ll.v_chq_amt,0) ELSE 0 END)
             end AS EFT,
--koc1220-A
--             to_char(CASE WHEN tpa_nhcp_cheques_issued_to =''HOS'' AND hospi.hosp_seq_id IS NOT NULL THEN
--                      nvl(Ll.v_chq_amt,0) ELSE 0 END )AS Qtm_Disbursed_Cashless, --koc1220
--            to_char(CASE WHEN NVL(tpa_nhcp_cheques_issued_to,''*'') !=''HOS'' THEN nvl(Ll.v_chq_amt,0) ELSE 0 END) AS Qtm_Disbursed_Reimb, --koc1220
              NULL AS Trans_ref_num, k.office_name,
              FLOAT_ACCOUNTS_PKG.get_Rej_billno(l.claim_seq_id) as Bill_no,
              (SELECT office_name FROM tpa_office_info WHERE office_code = SUBSTR(a.claim_settlement_no,1,3) AND ROWNUM = 1) as print_pay_loc,
              Ll.requested_amount,  ---for KOC647  ...RJP
              -------------------------------------------------From Here
              CASE WHEN A.PAYEE_TYPE=''EFT'' THEN ''N''  ELSE ''D'' END AS payment_type, -- Payment Type ADDED FOR KOC1103
              to_char(a.approved_amount) approved_amount , -- Gross Amount
              to_char(ll.pre_post_amount) pre_post_amount, -- Quantum disbursed - pre/ post hospitalization --koc122
--koc1220-A
             to_char(c.date_of_inception,''dd-mm-yyyy'') as date_of_inception,
             -- REPLACE(FLOAT_ACCOUNTS_PKG.get_date_of_inception ( c.tpa_enrollment_id  , a.policy_seq_id , b.ins_head_office_seq_id  ),''/'',''-'')  as date_of_inception, -- Date of inception of first policy
              batch_report_pkg.get_comp_icds(a.claim_seq_id) AS icd_codes, -- ICD code
              to_char(ll.requested_amount) AS bill_requested_amount, -- Total billed amount for period of hospitalization  KOC1220
              nvl(to_char(a.approved_amount  - TDS.check_amount),0)  AS tds_amt, -- TDS koc1220  --koc1220-A
              to_char(ll.room_charges) as room_charges, -- Room/ Board/ nursing charges --koc1220
              to_char(ll.icu_charges) as icu_charges, -- ICU charges --koc1220
              TO_CHAR(ll.professional_charges) AS professional_charges , -- Professional fees --koc1220
              to_char(ll.lab_charges) as lab_charges , -- Lab/ investigation charges --koc1220
              to_char(ll.pharmacy_charges) as pharmacy_charges, -- Pharmacy charges    --koc1220
              to_char(a.approved_amount - ( ll.room_charges + ll.icu_charges + ll.professional_charges + ll.lab_charges + ll.pharmacy_charges )) AS other_charges, -- Other charges --koc1220
              --l.total_app_amount - nvl(l.serv_tax_calc_amount,0) AS Claim_Amt_NoST,
              --to_char(l.serv_tax_calc_amount)  AS Service_Tax,
              Ll.v_chq_amt AS Net_Amount,
              ''TRN'' AS record_type,                            --Record Type
              (CASE WHEN a.payee_type=''PCA'' THEN ''PBD'' WHEN a.payee_type=''EFT'' THEN ''ACH'' END) AS transaction_type,  --Transaction Type
              NULL AS  Alternate_Trans_Type,                     --Alternate Transaction Type
              NULL AS  US_ACH_company_id,                        --U.S. ACH Company ID
              ''6215'' AS branch_Code,                           --Branch Code
              ''70209011''     AS Originator_acn_no,                     --Originator A/C
              NULL     AS ABA_Routing_Num,                       --ABA Routing Number for US
              ''INR''  AS Originator_ACN_Cur,                    --Originator A/C Currency
              ''PAY''  AS Transaction_Indicator,                 --Transaction Indicator
              ''C''    AS Transaction_Handling_Code,             --Transaction Handling Code
              ''S''    AS Posting_Indicator,                     --Posting Indicator
              NULL     AS Consolidate_Ref,                       --Consolidated Reference
              NULL     AS Priority_Indicator,                    --Priority Indicator
              --Transaction Reference
              NULL     AS Rcv_Part_Mail_Handling_Code,                          --Receiving Party Mail Handling Code
              ''VIDAL HEALTH TPA PVT. LTD'' AS Ordering_Party_Name,            --Ordering Party Name
              NULL     AS ordering_party_ID,                                    --Ordering Party ID
              ''VIDAL HEALTH TPA PVT. LTD'' AS Ordering_Party_Addres1,         --Ordering Party Address 1
              ''Bangalore''                  AS  Ordering_Party_Addres2,        --Ordering Party Address 2
              ''Bangalore''                  AS  Ordering_Party_City,           --Ordering Party City Name
              NULL                           AS  Ordering_Party_State,          --Ordering Party State Code
              NULL                           AS  Ordering_Party_Zip,            --Ordering Party Zip / Postal Code
              ''IN''                         AS Ordering_party_Country_Code,    --Ordering Party ISO Country Code
              ''INR''                        AS Trans_Currency_Code,            --Transaction Currency Code
              TO_CHAR(SYSDATE,''YYYYMMDD'')  AS  payment_value_day,             --Payment Value Date
              NULL AS Trans_Desc,                                               --Transaction Description
              ''OUR'' AS Charge_Indicator,                                         --Charge Indicator
              nvl(Ll.v_chq_amt,0)  AS cal_cheque_amount,            --KOC1220
              ''0'' as cal_num,
--koc1220-A
              case when h.ins_comp_code_number||'''' like ''500%'' then
                substr(h.ins_comp_code_number||'''',1,4)
                else substr(h.ins_comp_code_number||'''',1,2) end as ro_code,
              '''' AS UIIC_CORE_CLAIM_NO,
               CASE WHEN A.CLAIM_TYPE=''CNH'' OR 
                 (ct.description=''Member'' AND L.CLAIM_SUB_GENERAL_TYPE_ID=''OPD'' AND nvl(L.pay_to_general_type_id,''MBR'')=''HSL'') THEN hospi.Pan_Number
                 ELSE '''' END AS PAN_NUMBER
--koc1220-A

         FROM tpa_claims_payment a JOIN tpa_enr_policy b ON (a.policy_seq_id = b.policy_seq_id)
              JOIN tpa_enr_policy_member c ON (a.member_seq_id = c.member_seq_id)
              JOIN tpa_enr_policy_group d ON (D.policy_group_seq_id = C.policy_group_seq_id)
              --JOIN clm_general_details l ON (l.claim_seq_id = a.claim_seq_id)
              --JOIN clm_enroll_details e ON (l.claim_seq_id = e.claim_seq_id)
              JOIN clm_authorization_details l ON (l.claim_seq_id = a.claim_seq_id)
              --JOIN clm_inward ci ON (l.claims_inward_seq_id = ci.claims_inward_seq_id)
              JOIN tpa_ins_info h ON (a.ins_seq_id = h.ins_seq_id)
              JOIN tpa_address i ON(h.tpa_office_seq_id = i.tpa_office_seq_id)
              JOIN tpa_city_code j ON (i.city_type_id = j.city_type_id)
              JOIN tpa_office_info k ON (h.tpa_office_seq_id = k.tpa_office_seq_id)
              LEFT OUTER JOIN sum_tab Ll ON (A.payment_seq_id = Ll.payment_seq_id)
              --LEFT OUTER JOIN assign_users f ON (l.claim_seq_id = f.claim_seq_id and l.last_assign_user_seq_id = f.assign_users_seq_id)
              LEFT OUTER JOIN tpa_general_code gc ON (c.gender_general_type_id = gc.general_type_id)
              LEFT OUTER JOIN tpa_relationship_code rc ON (c.relship_type_id = rc.relship_type_id)
              LEFT OUTER JOIN app.clm_hospital_details hosa ON (l.claim_seq_id = hosa.claim_seq_id)
              LEFT OUTER JOIN tpa_hosp_info hospi ON (hosa.hosp_seq_id = hospi.hosp_seq_id)
              LEFT OUTER JOIN tpa_hosp_address ha ON (hospi.hosp_seq_id = ha.hosp_seq_id)
              LEFT OUTER JOIN tpa_city_code city ON (ha.city_type_id = city.city_type_id)
              LEFT OUTER JOIN tpa_enr_bank_dtls P  ON (d.BANK_SEQ_ID=p.BANK_SEQ_ID)
              LEFT OUTER JOIN tpa_enr_bank_dtls r  ON (b.bank_seq_id=r.bank_seq_id)--ADDED FOR KOC1103
              LEFT OUTER JOIN tpa_hosp_account_details q ON(hospi.hosp_seq_id=q.hosp_seq_id)
         --     LEFT OUTER JOIN syn_hosp_ifsc_details  Q  ON (Q.EMPANEL_NUM=HOSPI.EMPANEL_NUMBER)  --Created FOR CR KOC1108 Temporarily and removed for parmanently cr koc1103
              LEFT OUTER JOIN tpa_payment_checks_details pcd ON (a.payment_seq_id = pcd.payment_seq_id and pcd.v_csr_flag=1)
              LEFT OUTER JOIN tpa_claims_check cc ON (pcd.claims_chk_seq_id = cc.claims_chk_seq_id and cc.v_csr_flag=1)
              LEFT OUTER JOIN tpa_general_code ct ON (l.claim_type = ct.general_type_id )
              --LEFT OUTER JOIN tpa_enr_balance bons ON (d.policy_group_seq_id = bons.policy_group_seq_id AND ( c.mem_general_type_id = ''PFL'' AND bons.member_seq_id IS NULL OR c.mem_general_type_id != ''PFL'' AND c.member_seq_id = bons.member_seq_id))
              LEFT OUTER JOIN ailment_details ald  ON (a.claim_seq_id = ald.claim_seq_id)
              LEFT OUTER JOIN tpa_clm_tds_details TDS  ON (a.claim_seq_id = TDS.claim_seq_id)
              LEFT OUTER JOIN tpa_partner_info pi ON (a.ptnr_seq_id=pi.ptnr_seq_id)
              LEFT OUTER JOIN tpa_partner_account_details pa ON (pi.ptnr_seq_id=pa.ptnr_seq_id
              WHERE a.float_seq_id = :v_float_seq_id ' ||
                   regexp_replace(v_where, 'D\.', 'A.') ||
                   ' AND a.claim_payment_status  = ''READY_TO_BANK'') boa where boa.AQ=1 order by to_number(slno)';
    
    ELSIF (v_bank_type = '99') THEN
      -- added by ravi for koc1212 taken bank_type as axis_type 99
      v_filename := 'ENBD' || '-' ||
                    TO_CHAR(v_batch_date, 'DDMMYYYY-HH24MISS') || '-' ||
                    v_added_by;
      v_sql_str  := ' WITH sum_tab as
         ( SELECT D.payment_seq_id, (a.tot_disc_gross_amount-a.tot_patient_share_amount - a.tot_approved_amount) as v_rej_amt,
            a.tot_discount_amount AS v_disc_amt,
            /*SUM( CASE WHEN C.apply_discount_yn = ''Y'' THEN (C.REQUESTED_AMOUNT * NVL(C.discount_percnt,0))/100
            ELSE 0 END ) AS v_disc_amt,*/ 
            --D.Approved_Amount AS v_pay_amt,
            --nvl(e.check_amount, D.Approved_Amount) AS v_chq_amt,
            nvl(c.check_amount, a.tot_approved_amount) AS v_chq_amt,
            a.tot_approved_amount AS v_pay_amt,
            --c.check_amount AS v_chq_amt,
            (a.tot_disc_gross_amount-a.tot_patient_share_amount) AS requested_amount,
            --SUM (CASE WHEN b.bill_date NOT BETWEEN trunc(a.date_of_admission) AND trunc(a.date_of_discharge) THEN c.allowed_amount ELSE 0 END)  pre_post_amount,
            --SUM (CASE WHEN ward_type_id IN (''ROO'',''NUC'') THEN c.allowed_amount ELSE 0 END ) AS ROOM_CHARGES,
            --SUM (CASE WHEN ward_type_id IN (''ICU'',''ICC'',''ICN'',''ICR'') THEN c.allowed_amount ELSE 0 END ) AS ICU_CHARGES,
            --SUM (CASE WHEN ward_type_id IN (''PRO'') THEN c.allowed_amount ELSE 0 END ) AS PROFESSIONAL_CHARGES,
            --SUM (CASE WHEN ward_type_id IN (''LAI'') THEN c.allowed_amount ELSE 0 END ) AS LAB_CHARGES,
            --SUM (CASE WHEN ward_type_id IN (''PHA'',''MED'') THEN c.allowed_amount ELSE 0 END ) AS PHARMACY_CHARGES
            NULL AS pre_post_amount,
            NULL AS ROOM_CHARGES,
            NULL AS ICU_CHARGES,
            NULL AS PROFESSIONAL_CHARGES,
            NULL AS LAB_CHARGES,
            NULL AS PHARMACY_CHARGES
            FROM clm_authorization_details A 
              INNER JOIN tpa_claims_payment D ON (A.claim_seq_id = D.claim_seq_id)
              LEFT OUTER JOIN tpa_payment_checks_details E ON (d.payment_seq_id = e.payment_seq_id)
              LEFT OUTER JOIN tpa_claims_check C on (e.claims_chk_seq_id = c.claims_chk_seq_id)
              WHERE D.float_seq_id = :v_float_seq_id ' ||
                    v_where || ' GROUP BY D.payment_seq_id,D.Approved_Amount, nvl(c.check_amount, D.Approved_Amount))
              
              /*WHERE D.float_seq_id = ' ||
                    v_float_seq_id || 'AND D.PAYMENT_SEQ_ID= ' ||
                    v_payment_seq_id || '
              GROUP BY D.payment_seq_id,D.Approved_Amount, nvl(e.check_amount, D.Approved_Amount))*/

       select * from (
       SELECT rownum AS slno,
              a.payment_seq_id, dense_rank() over (partition by a.claim_seq_id order by ad.ailment_details_seq_id,rownum desc) as AQ,
              ''' || v_bank_advice_file_name ||
                    ''' AS save_file_name,
             /* (case when a.payee_type = ''PCA'' then ''C''  -- ''PMM'',''PCA'',''EFT'' PRS RTGS,PDD DEMAND DRAFT,IFT INT FUNDS TRANSFER
                    when a.payee_type = ''EFT'' then ''N''
                    when a.payee_type = ''PMM'' then ''M''
                    when a.payee_type = ''PRS'' then ''R''
                    when a.payee_type = ''PDD'' then ''D''
                    when a.payee_type = ''IFT'' then ''I''
                    else null end) as  payment_identifier,*/
                                                        -- ''PMM'',''PCA'',''EFT'' PRS RTGS,PDD DEMAND DRAFT,IFT INT FUNDS TRANSFER
                    (case when
                    (case when substr(ttk_util_pkg.fn_decrypt(tebn.bank_name),1,3)=''UTI'' then 1 else 0 end) =1 and
                    (case when
                    substr( ttk_util_pkg.fn_decrypt((CASE WHEN ct.description=''Member'' AND nvl(L.pay_to_general_type_id,''MBR'')!=''HSL'' THEN--This is added for hyundai requirement
                    CASE WHEN a.tpa_nhcp_cheques_issued_to=''TPA'' THEN ''' ||
                    tpa_rec.bank_name ||
                    ''' ELSE 
                    (CASE WHEN b.enrol_type_id=''COR'' THEN (CASE WHEN b.tpa_cheque_issued_general_type=''IQI'' THEN p.bank_name
                    WHEN B.tpa_cheque_issued_general_type=''IQC'' THEN r.bank_name END)
                    ELSE p.bank_name END)END 
                      ELSE 
                        CASE l.pymnt_to_type_id WHEN ''PTN'' THEN ttk_util_pkg.fn_decrypt(pa.bank_name) 
                                        ELSE ttk_util_pkg.fn_decrypt(q.bank_name) 
                        END
                      end)),1,3)=''AXI'' then 1 else 0 end)=1 then ''I''
                    when a.payee_type = ''PCA'' then ''C''
                    when a.payee_type = ''EFT'' then ''N''
                    when a.payee_type = ''PMM'' then ''M''
                    when a.payee_type = ''PRS'' then ''R''
                    when a.payee_type = ''PDD'' then ''D''
                    when a.payee_type = ''IFT'' then ''I''
                    else null end) as  payment_identifier,


             nvl(Ll.v_chq_amt,0)  AS cheuqe_amt,
             to_char(sysdate,''dd-mm-yyyy'') as payment_gen_date,  -- value date

              CASE WHEN ct.description=''Member'' AND nvl(L.pay_to_general_type_id,''MBR'')!=''HSL'' THEN--This is added for hyundai requirement
              CASE WHEN a.tpa_nhcp_cheques_issued_to=''TPA'' THEN B.TPA_NAME ELSE 
              (CASE WHEN b.enrol_type_id=''COR'' THEN (CASE WHEN b.tpa_cheque_issued_general_type=''IQI'' THEN ttk_util_pkg.fn_decrypt(a.payee_name)
              WHEN B.tpa_cheque_issued_general_type=''IQC'' THEN tgr.group_name end)
              ELSE ttk_util_pkg.fn_decrypt(a.payee_name) END)END   ELSE hospi.hosp_name END  as beneficiary_name,

            ---  a.address1||'', ''||a.address2||'', ''||a.address3 AS address,
              null address,
              null address1,
              null address2,
              null address3,
              null city,
              null state,
              null pincode,

              case when
              (CASE WHEN ct.description=''Member'' AND nvl(L.pay_to_general_type_id,''MBR'')!=''HSL'' THEN--This is added for hyundai requirement
               CASE WHEN a.tpa_nhcp_cheques_issued_to=''TPA'' THEN ''' ||
                    tpa_rec.account_number ||
                    ''' ELSE 
              (CASE WHEN b.enrol_type_id=''COR'' THEN (CASE WHEN b.tpa_cheque_issued_general_type=''IQI'' THEN  ttk_util_pkg.fn_decrypt(p.bank_account_no)
              WHEN B.tpa_cheque_issued_general_type=''IQC'' THEN ttk_util_pkg.fn_decrypt(r.bank_account_no) END)
              ELSE ttk_util_pkg.fn_decrypt(p.bank_account_no) END)END  
                ELSE 
                  CASE l.pymnt_to_type_id WHEN ''PTN'' THEN ttk_util_pkg.fn_decrypt(pa.account_number) 
                                          ELSE ttk_util_pkg.fn_decrypt(q.account_number) 
                  END 
                end)=''NA'' then null else

              (CASE WHEN ct.description=''Member'' AND nvl(L.pay_to_general_type_id,''MBR'')!=''HSL'' THEN--This is added for hyundai requirement
               CASE WHEN a.tpa_nhcp_cheques_issued_to=''TPA'' THEN ''' ||
                    tpa_rec.account_number ||
                    ''' ELSE 
              (CASE WHEN b.enrol_type_id=''COR'' THEN (CASE WHEN b.tpa_cheque_issued_general_type=''IQI'' THEN ttk_util_pkg.fn_decrypt(p.bank_account_no)
               WHEN B.tpa_cheque_issued_general_type=''IQC'' THEN ttk_util_pkg.fn_decrypt(r.bank_account_no) END)
               ELSE ttk_util_pkg.fn_decrypt(p.bank_account_no) END)END 
                 ELSE 
                   CASE l.pymnt_to_type_id WHEN ''PTN'' THEN ttk_util_pkg.fn_decrypt(pa.account_number) 
                                           ELSE ttk_util_pkg.fn_decrypt(q.account_number) 
                   END
                 end) end
               as account_num,

            ttk_util_pkg.fn_decrypt(  CASE WHEN ct.description=''Member'' AND nvl(L.pay_to_general_type_id,''MBR'')!=''HSL'' THEN--This is added for hyundai requirement
              CASE WHEN a.tpa_nhcp_cheques_issued_to=''TPA'' THEN '''' ELSE 
              (CASE WHEN b.enrol_type_id=''COR'' THEN (CASE WHEN b.tpa_cheque_issued_general_type=''IQI'' THEN e.email_id
              WHEN B.tpa_cheque_issued_general_type=''IQC'' THEN tgr.notify_email_id end)
              ELSE e.email_id END)END  ELSE hospi.primary_email_id END ) as email_id,

              '' Your Claim payment has been processed by Vidal Health TPA Pvt Ltd. for NEFT transaction and the amount has been credited to your bank account. Details of payments will be sent by VHTPA shortly. Please get in touch with VHTPA for any further clarification'' as email_body,
              to_char(ttk_util_pkg.fn_decrypt(tba.account_number)) as debit_account_number,
              ''VHTPA - ''||l.settlement_number as narration_crn,

         ttk_util_pkg.fn_decrypt( CASE WHEN ct.description=''Member'' AND nvl(L.pay_to_general_type_id,''MBR'')!=''HSL'' THEN--This is added for hyundai requirement
              CASE WHEN a.tpa_nhcp_cheques_issued_to=''TPA'' THEN ''' ||
                    tpa_rec.bank_ifsc ||
                    ''' ELSE 
              (CASE WHEN b.enrol_type_id=''COR'' THEN (CASE WHEN b.tpa_cheque_issued_general_type=''IQI'' THEN p.bank_ifsc
              WHEN B.tpa_cheque_issued_general_type=''IQC'' THEN r.bank_ifsc end)
              ELSE p.bank_ifsc END)END  
                ELSE 
                  CASE l.pymnt_to_type_id WHEN ''PTN'' THEN pa.bank_ifsc 
                                          ELSE q.bank_ifsc 
                  END
                END )  as receiver_ifsc,

             ---//**
             to_char(case when
            ttk_util_pkg.fn_decrypt( (CASE WHEN ct.description=''Member'' AND nvl(L.pay_to_general_type_id,''MBR'')!=''HSL'' THEN--This is added for hyundai requirement
             CASE WHEN a.tpa_nhcp_cheques_issued_to=''TPA'' THEN ''' ||
                    tpa_rec.account_type ||
                    ''' ELSE 
             (CASE WHEN b.enrol_type_id=''COR'' THEN (CASE WHEN b.tpa_cheque_issued_general_type=''IQI'' THEN p.account_name
              WHEN B.tpa_cheque_issued_general_type=''IQC'' THEN r.account_name end)
              ELSE p.account_name END)END  
                ELSE 
                  CASE l.pymnt_to_type_id WHEN ''PTN'' THEN pa.account_type 
                                          ELSE q.account_type 
                  END
                END))=''SB'' then 10
              when
              ttk_util_pkg.fn_decrypt((CASE WHEN ct.description=''Member'' AND nvl(L.pay_to_general_type_id,''MBR'')!=''HSL'' THEN--This is added for hyundai requirement
              CASE WHEN a.tpa_nhcp_cheques_issued_to=''TPA'' THEN ''' ||
                    tpa_rec.account_type ||
                    ''' ELSE 
              (CASE WHEN b.enrol_type_id=''COR'' THEN (CASE WHEN b.tpa_cheque_issued_general_type=''IQI'' THEN p.account_name
              WHEN B.tpa_cheque_issued_general_type=''IQC'' THEN r.account_name end)
              ELSE p.account_name END)END  
                ELSE 
                  CASE l.pymnt_to_type_id WHEN ''PTN'' THEN pa.account_type 
                                          ELSE q.account_type 
                  END
                END))=''CA'' then 11
              when
             ttk_util_pkg.fn_decrypt((CASE WHEN ct.description=''Member'' AND nvl(L.pay_to_general_type_id,''MBR'')!=''HSL'' THEN--This is added for hyundai requirement
             CASE WHEN a.tpa_nhcp_cheques_issued_to=''TPA'' THEN ''' ||
                    tpa_rec.account_type ||
                    ''' ELSE 
             (CASE WHEN b.enrol_type_id=''COR'' THEN (CASE WHEN b.tpa_cheque_issued_general_type=''IQI'' THEN p.account_name
              WHEN B.tpa_cheque_issued_general_type=''IQC'' THEN r.account_name end)
              ELSE p.account_name END)END  
                ELSE 
                  CASE l.pymnt_to_type_id WHEN ''PTN'' THEN pa.account_type 
                                          ELSE q.account_type 
                  END
                END))=''CC'' then 13
             when
             ttk_util_pkg.fn_decrypt( (CASE WHEN ct.description=''Member'' AND nvl(L.pay_to_general_type_id,''MBR'')!=''HSL'' THEN--This is added for hyundai requirement
             CASE WHEN a.tpa_nhcp_cheques_issued_to=''TPA'' THEN ''' ||
                    tpa_rec.account_type || ''' ELSE 
             (CASE WHEN b.enrol_type_id=''COR'' THEN (CASE WHEN b.tpa_cheque_issued_general_type=''IQI'' THEN p.account_name
              WHEN B.tpa_cheque_issued_general_type=''IQC'' THEN r.account_name end)
              ELSE p.account_name END)END  
                ELSE 
                  CASE l.pymnt_to_type_id WHEN ''PTN'' THEN pa.account_type 
                                          ELSE q.account_type 
                  END 
                END))=''NRI'' then 40
              else null end) as receiver_ac_type ,

             ---//**
            ---  null as receiver_ac_type,
              k.office_name as print_branch,
            --- (SELECT office_name FROM app.tpa_office_info WHERE office_code = SUBSTR(a.claim_settlement_no,1,3) AND ROWNUM = 1) as print_pay_loc,
              NULL as a,
              to_char(sysdate,''dd-mm-yyyy'') as instrument_date,
              k.office_name as ttk_branch,
              h.ins_comp_name,
              ---substr(b.policy_number,1,6) as do_number,
              h.ins_comp_code_number as do_number,
              c.tpa_enrollment_id as ttk_id,
              b.policy_number,
              b.enrol_type_id,
              TGR.GROUP_NAME,
              c.tpa_enrollment_id,
              d.insured_name as mem_name,
              TEMA.ADDRESS_1||'' ''||TEMA.ADDRESS_2||'' ''||TEMA.ADDRESS_3 AS INSURED_ADDRESS,
              d.employee_no,
              l.mem_name as claimant_name,
              rc.relship_description as Relationship,
             /* CASE WHEN b.policy_sub_general_type_id=''PNF'' THEN c.mem_tot_sum_insured
                 ELSE d.family_tot_sum_insured END as total_sum_insured,*/
              null as total_sum_insured,
              a.claim_type,
              hospi.empanel_number as empanel_number,
              nvl(hosa.hosp_name,hospi.hosp_name) AS hosp_name,
              NVL(hosa.city_name, city.city_description) AS Hosp_city,
              CASE WHEN ad.discharge_cond_general_type_id = ''DCD'' THEN ''Y'' ELSE ''N'' END AS death_claim_yn ,
              l.claim_number,
              l.settlement_number as claim_settlement_number ,
              to_char(a.claim_aprv_date,''dd-mm-yyyy'') as claim_settled_date,
             --- a.claim_amount,
              null as claim_amount,
              a.approved_amount as loss_settled_amt,
              cc.check_num,
              to_char(cc.check_date,''dd-mm-yyyy'') AS check_date,
              a.approved_amount  - TDS.check_amount  AS tds_amt, -- TDS
              ' || v_batch_seq_id ||
                    ' AS batch_no,
              a.claim_seq_id as unique_claim_identifier,

              CASE WHEN a.hosp_seq_id IS NOT NULL THEN ''H''
              ELSE CASE WHEN a.ENROL_TYPE_ID IN (''IND'',''ING'') THEN ''I'' WHEN a.ENROL_TYPE_ID =''COR'' THEN ''C'' ELSE ''N'' END   END  AS chq_drawee,

             ttk_util_pkg.fn_decrypt( CASE WHEN ct.description=''Member'' AND nvl(L.pay_to_general_type_id,''MBR'')!=''HSL'' THEN--This is added for hyundai requirement
              (CASE WHEN b.enrol_type_id=''COR'' THEN (CASE WHEN b.tpa_cheque_issued_general_type=''IQI'' THEN p.account_name
              WHEN B.tpa_cheque_issued_general_type=''IQC'' THEN r.account_name end)
              ELSE P.account_name END)   
                ELSE 
                  CASE l.pymnt_to_type_id WHEN ''PTN'' THEN pa.account_type 
                                          ELSE q.account_type 
                  END 
                end) as account_type,

             ttk_util_pkg.fn_decrypt( CASE WHEN ct.description=''Member'' AND nvl(L.pay_to_general_type_id,''MBR'')!=''HSL'' THEN--This is added for hyundai requirement
             (CASE WHEN b.enrol_type_id=''COR'' THEN (CASE WHEN b.tpa_cheque_issued_general_type=''IQI'' THEN p.bank_micr
              WHEN B.tpa_cheque_issued_general_type=''IQC'' THEN r.bank_micr end)
              ELSE p.bank_micr END)   
                ELSE 
                  CASE l.pymnt_to_type_id WHEN ''PTN'' THEN pa.bank_micr 
                                          ELSE q.bank_micr 
                  END
                END) AS MICR_CODE

         FROM app.tpa_claims_payment a
              LEFT OUTER JOIN app.tpa_enr_policy b ON (a.policy_seq_id = b.policy_seq_id)
              LEFT OUTER JOIN app.tpa_enr_policy_member c ON (a.member_seq_id = c.member_seq_id)
              LEFT OUTER JOIN app.tpa_enr_policy_group d  ON (D.policy_group_seq_id = C.policy_group_seq_id)
              --JOIN clm_general_details l ON (l.claim_seq_id = a.claim_seq_id)
              --JOIN clm_enroll_details e ON (l.claim_seq_id = e.claim_seq_id)
              JOIN clm_authorization_details l ON (l.claim_seq_id = a.claim_seq_id)
               --LEFT OUTER JOIN app.clm_inward ci ON (l.claims_inward_seq_id = ci.claims_inward_seq_id)
              LEFT OUTER JOIN app.tpa_ins_info h ON (a.ins_seq_id = h.ins_seq_id)
              LEFT OUTER JOIN app.tpa_address i ON(h.tpa_office_seq_id = i.tpa_office_seq_id)
              LEFT OUTER JOIN app.tpa_city_code j ON (i.city_type_id = j.city_type_id)
              LEFT OUTER JOIN app.tpa_office_info k ON (h.tpa_office_seq_id = k.tpa_office_seq_id)
              LEFT OUTER JOIN sum_tab Ll ON (A.payment_seq_id = Ll.payment_seq_id)
              --LEFT OUTER JOIN app.assign_users f ON (l.claim_seq_id = f.claim_seq_id and l.last_assign_user_seq_id = f.assign_users_seq_id)
              LEFT OUTER JOIN app.tpa_general_code gc ON (c.gender_general_type_id = gc.general_type_id)
              LEFT OUTER JOIN app.tpa_relationship_code rc ON (c.relship_type_id = rc.relship_type_id)
              LEFT OUTER JOIN app.clm_hospital_details hosa ON (l.claim_seq_id = hosa.claim_seq_id)
              LEFT OUTER JOIN app.tpa_hosp_info hospi ON (hosa.hosp_seq_id = hospi.hosp_seq_id)
              LEFT OUTER JOIN app.tpa_hosp_address ha ON (hospi.hosp_seq_id = ha.hosp_seq_id)
              LEFT OUTER JOIN app.tpa_city_code city ON (ha.city_type_id = city.city_type_id)
              LEFT OUTER JOIN app.tpa_enr_bank_dtls P  ON (d.BANK_SEQ_ID=p.BANK_SEQ_ID)
              LEFT OUTER JOIN app.tpa_enr_bank_dtls r  ON (b.bank_seq_id=r.bank_seq_id)--ADDED FOR KOC1103
              LEFT OUTER JOIN app.tpa_hosp_account_details q ON(hospi.hosp_seq_id=q.hosp_seq_id)
              LEFT OUTER JOIN app.tpa_payment_checks_details pcd ON (a.payment_seq_id = pcd.payment_seq_id and pcd.v_csr_flag=1)
              LEFT OUTER JOIN app.tpa_claims_check cc ON (pcd.claims_chk_seq_id = cc.claims_chk_seq_id and cc.v_csr_flag=1)
              LEFT OUTER JOIN tpa_general_code ct ON (l.claim_type = ct.general_type_id )
              --- LEFT OUTER JOIN app.ailment_details ald  ON (a.claim_seq_id = ald.claim_seq_id)
              LEFT OUTER JOIN app.tpa_clm_tds_details TDS  ON (a.claim_seq_id = TDS.claim_seq_id)
              LEFT OUTER JOIN FIN_APP.TPA_DEBIT_NOTE_CLAIMS_ASSOC TDNC ON (a.CLAIM_SEQ_ID=TDNC.CLAIM_SEQ_ID)
              LEFT OUTER JOIN FIN_APP.TPA_DEBIT_NOTE  TDN ON(TDNC.DEBIT_SEQ_ID=TDN.DEBIT_SEQ_ID)
              LEFT OUTER JOIN APP.TPA_GROUP_REGISTRATION TGR ON (b.GROUP_REG_SEQ_ID=TGR.GROUP_REG_SEQ_ID)
              LEFT OUTER JOIN APP.TPA_ENR_MEM_ADDRESS TEMA ON (d.ENR_ADDRESS_SEQ_ID=TEMA.ENR_ADDRESS_SEQ_ID)
              LEFT OUTER JOIN app.tpa_float_account tfa on (tfa.float_seq_id=a.float_seq_id)
              left outer join app.TPA_BANK_ACCOUNTS tba on (tba.BANK_ACC_SEQ_ID=tfa.BANK_ACC_SEQ_ID)
              left outer join app.tpa_bank_master tebn on (tba.bank_seq_id=tebn.bank_seq_id)
              left outer join app.ailment_details ad ON (a.claim_seq_id = ad.claim_seq_id)
              WHERE a.float_seq_id = :v_float_seq_id ' ||
                    regexp_replace(v_where, 'D\.', 'A.') ||
                    ' AND a.claim_payment_status = ''READY_TO_BANK'') ';
      /*  WHERE a.float_seq_id = '||v_float_seq_id||' and a.payment_seq_id= '||v_payment_seq_id||
      'and a.claim_payment_status=''READY_TO_BANK''';*/
   ELSIF (v_bank_type = 'QATAR') THEN
      v_filename := 'DEFL' || '-' ||substr(v_acc_num,-3,3)||'-'||
                    TO_CHAR(v_batch_date, 'DDMMYYYY-HH24MISS')||'-1';
                    
    v_sql_str:= 
    'select CASE WHEN '''||v_payment_type||''' IN (''TPTI'',''TPTE'') THEN ''TPT''
                 WHEN '''||v_payment_type||''' IN (''MGC'') THEN ''Manager''''s Cheque''
     ELSE '''||v_payment_type||''' END
    as Payment_Type,
       a.APPROVED_AMOUNT as Transfer_Amount,
       TBA.ACCOUNT_NUMBER  ins_comp_ac_no,
       TBM.IBAN_NO,
       CASE WHEN cad.CLAIM_TYPE=''CTM'' THEN
           (case when  enr.tpa_cheque_issued_general_type=''IQC'' THEN GR.GROUP_NAME  
                 WHEN enr.tpa_cheque_issued_general_type=''IQI'' THEN tepg.insured_name
            END ) 
        ELSE 
		 CASE WHEN cad.CLAIM_TYPE=''CNH'' THEN
                 (case when NVL(cad.pymnt_to_type_id,''HOS'') =''PTN'' THEN
				 pi.partner_name
				 ELSE
				 HD.HOSP_NAME END)
		END		 
        END as benf_name,
       MD.ADDRESS_1 as member_address,
       MD.ADDRESS_2 as member_address2,
       MD.ADDRESS_3 as member_address3,
       CC.COUNTRY_NAME,
       cad.converted_amount_currency_type as Debit_Curr,
       cad.req_amt_currency_type as Tra_Curr, 
      CASE WHEN cad.CLAIM_TYPE=''CTM'' THEN
           (case when  enr.tpa_cheque_issued_general_type=''IQC'' THEN ttk_util_pkg.fn_decrypt(cbdt.bank_name)  
                 WHEN enr.tpa_cheque_issued_general_type=''IQI'' THEN ttk_util_pkg.fn_decrypt(mbdt.BANK_NAME)
            END ) 
        ELSE 
          CASE WHEN cad.CLAIM_TYPE=''CNH'' THEN
                 (case when NVL(cad.pymnt_to_type_id,''HOS'') =''PTN'' THEN
				 ttk_util_pkg.fn_decrypt(PAD.BANK_NAME)
				 ELSE
				 ttk_util_pkg.fn_decrypt(HAD.BANK_NAME) END)
          END 
     END as benf_bank_name,
       CASE WHEN cad.CLAIM_TYPE=''CTM'' THEN 
           (case when  enr.tpa_cheque_issued_general_type=''IQC'' THEN ttk_util_pkg.fn_decrypt(cbdt.BANK_IFSC)  
                 WHEN enr.tpa_cheque_issued_general_type=''IQI'' THEN ttk_util_pkg.fn_decrypt(mbdt.BANK_IFSC)
            END )             
        ELSE
        
          CASE WHEN cad.CLAIM_TYPE=''CNH'' THEN
                 (case when NVL(cad.pymnt_to_type_id,''HOS'') =''PTN'' THEN
				 ttk_util_pkg.fn_decrypt(PAD.BANK_IFSC)
				 ELSE
				 ttk_util_pkg.fn_decrypt(HAD.BANK_IFSC) END)
                 
             END 
        END   as benf_swift_code,
       CASE WHEN cad.CLAIM_TYPE=''CTM'' THEN 
         (case when enr.tpa_cheque_issued_general_type=''IQC'' THEN (ttk_util_pkg.fn_decrypt (cbdt.bank_micr))
                     when enr.tpa_cheque_issued_general_type=''IQI'' THEN (ttk_util_pkg.fn_decrypt (mbdt.bank_micr)) 
                END)
         ELSE 
         CASE WHEN cad.CLAIM_TYPE=''CNH'' THEN
                 (case when NVL(cad.pymnt_to_type_id,''HOS'') =''PTN'' THEN
				 ttk_util_pkg.fn_decrypt(PAD.bank_micr)
				 ELSE
				 ttk_util_pkg.fn_decrypt(HAD.bank_micr) END)
             END   
           END as benf_acc_number,      
       CASE WHEN cad.CLAIM_TYPE=''CTM'' THEN 
            (case when enr.tpa_cheque_issued_general_type=''IQC'' THEN CCC.CITY_DESCRIPTION
                  when enr.tpa_cheque_issued_general_type=''IQI'' THEN TCC.CITY_DESCRIPTION  
             END)
       ELSE
       CASE WHEN cad.CLAIM_TYPE=''CNH'' THEN
                 (case when NVL(cad.pymnt_to_type_id,''HOS'') =''PTN'' THEN
				 tpd.address_1
				 ELSE
				 THA.ADDRESS_1 END)
             END 
            
        END  as benf_bank_add1,
       CASE WHEN cad.CLAIM_TYPE=''CTM'' THEN
       (case when enr.tpa_cheque_issued_general_type=''IQC'' THEN CSC.STATE_NAME
             when enr.tpa_cheque_issued_general_type=''IQI'' THEN TSC.STATE_NAME  
        END)
        ELSE
           CASE WHEN cad.CLAIM_TYPE=''CNH'' THEN
                 (case when NVL(cad.pymnt_to_type_id,''HOS'') =''PTN'' THEN
				 tpd.address_2
				 ELSE
				 THA.ADDRESS_2 END)
             END 
        END as benf_bank_add2,
       case when cad.CLAIM_TYPE=''CTM'' THEN 
         (case when enr.tpa_cheque_issued_general_type=''IQC'' THEN UPPER(SUBSTR (MCC.short_name,1,2))
             when enr.tpa_cheque_issued_general_type=''IQI'' THEN UPPER(SUBSTR (ICC.short_name,1,2)) 
        END)  
         ELSE 
         CASE WHEN cad.CLAIM_TYPE=''CNH'' THEN
                 (case when NVL(cad.pymnt_to_type_id,''HOS'') =''PTN'' THEN
				 SUBSTR(PCD.short_name,1,2)
				 ELSE
				SUBSTR(BCC.short_name,1,2) END)
             END 
         END as benf_bank_coun_code,
        TO_CHAR( TO_DATE ('''||v_batch_date||''',''DD-MM-YYYY'')+2) as Value_Date,
       ''OUR'' as it_charg,
       null as  pay_det1,
       null as  pay_det2,
       cad.claim_number as cus_ref_num,
     CASE WHEN '''||v_pur_of_rem||''' =''SUPP'' THEN ''14/SUPP''
          WHEN '''||v_pur_of_rem||''' =''PFLB'' THEN ''19/PFLB Medical Claims'' 
     END 
     as per_rem
from fin_app.tpa_claims_payment a
       join fin_app.tpa_float_account tfa on (a.FLOAT_SEQ_ID=TFA.FLOAT_SEQ_ID)
       left outer join tpa_bank_accounts tba on (TFA.BANK_ACC_SEQ_ID=TBA.BANK_ACC_SEQ_ID)
       left outer join FIN_APP.TPA_BANK_MASTER tbm on (TBM.BANK_SEQ_ID=TBA.BANK_SEQ_ID)
       left outer join APP.CLM_AUTHORIZATION_DETAILS cad on (CAD.CLAIM_SEQ_ID=a.CLAIM_SEQ_ID)
       left outer join APP.TPA_ENR_POLICY_MEMBER tpm on (TPM.MEMBER_SEQ_ID=CAD.MEMBER_SEQ_ID)
       left outer join APP.TPA_ENR_MEM_ADDRESS md on (TPM.ENR_ADDRESS_SEQ_ID=MD.ENR_ADDRESS_SEQ_ID)
       left outer join TPA_COUNTRY_CODE cc on (MD.COUNTRY_ID=CC.COUNTRY_ID)
       left outer join tpa_enr_policy enr on (CAD.POLICY_SEQ_ID=ENR.POLICY_SEQ_ID)
       left outer join tpa_enr_policy_group tepg on (tepg.policy_group_seq_id=tpm.policy_group_seq_id)
       left outer join tpa_enr_bank_dtls cbdt on (ENR.BANK_SEQ_ID=CBDT.BANK_SEQ_ID)
       left outer join tpa_enr_bank_dtls mbdt on (TEPG.BANK_SEQ_ID=MBDT.BANK_SEQ_ID)
       left outer join TPA_CITY_CODE tcc on (MBDT.CITY_TYPE_ID=TCC.CITY_TYPE_ID)
       left outer join TPA_STATE_CODE tsc on (MBDT.STATE_TYPE_ID=TSC.STATE_TYPE_ID)
       left outer join TPA_COUNTRY_CODE icc on (TSC.COUNTRY_ID=ICC.COUNTRY_ID)
       left outer join TPA_CITY_CODE Ccc on (CBDT.CITY_TYPE_ID=CCC.CITY_TYPE_ID)
       left outer join TPA_STATE_CODE Csc on (CBDT.STATE_TYPE_ID=CSC.STATE_TYPE_ID)
       left outer join TPA_COUNTRY_CODE mcc on (TSC.COUNTRY_ID=MCC.COUNTRY_ID)
       left outer join APP.CLM_HOSPITAL_DETAILS hd on (CAD.CLAIM_SEQ_ID=HD.CLAIM_SEQ_ID)
       left outer join APP.TPA_HOSP_ACCOUNT_DETAILS had on (HD.HOSP_SEQ_ID=HAD.HOSP_SEQ_ID)
       left outer join app.TPA_HOSP_ADDRESS tha on (HAD.HOSP_SEQ_ID=THA.HOSP_SEQ_ID)
       left outer join TPA_COUNTRY_CODE bcc on (THA.COUNTRY_ID=BCC.COUNTRY_ID)
       left outer join TPA_GROUP_REGISTRATION gr on (gr.GROUP_REG_SEQ_ID=enr.GROUP_REG_SEQ_ID)
	 LEFT OUTER JOIN TPA_PARTNER_INFO pi ON (cad.ptnr_seq_id=pi.ptnr_seq_id)
	 LEFT OUTER JOIN TPA_PARTNER_ACCOUNT_DETAILS pad ON (pi.ptnr_seq_id=pad.ptnr_seq_id)
       LEFT OUTER JOIN TPA_PARTNER_ADDRESS  tpd on (pad.ptnr_bank_seq_id=tpd.ptnr_bank_seq_id)
       LEFT OUTER JOIN TPA_COUNTRY_CODE pcd on (tpd.country_id=bcc.country_id)
        WHERE a.float_seq_id = :v_float_seq_id ' ||
                    regexp_replace(v_where, 'D\.', 'A.') ||
                    ' AND a.claim_payment_status = ''READY_TO_BANK'' ';                  
    ELSE
      v_filename := 'ENBD' || '-' ||
                    TO_CHAR(v_batch_date, 'DDMMYYYY-HH24MISS') || '-' ||
                    v_added_by;
      v_sql_str  := 'WITH sum_tab as ( SELECT D.payment_seq_id, (a.tot_disc_gross_amount-a.tot_patient_share_amount - a.tot_approved_amount) as v_rej_amt,
            a.tot_discount_amount AS v_disc_amt,
            /*SUM( CASE WHEN C.apply_discount_yn = ''Y'' THEN (C.REQUESTED_AMOUNT * NVL(C.discount_percnt,0))/100
            ELSE 0 END ) AS v_disc_amt,*/ 
            --D.Approved_Amount AS v_pay_amt,
            --nvl(e.check_amount, D.Approved_Amount) AS v_chq_amt,
            nvl(c.check_amount, a.tot_approved_amount) AS v_chq_amt,
            a.tot_approved_amount AS v_pay_amt,
            --c.check_amount AS v_chq_amt,
           (a.tot_disc_gross_amount-a.tot_patient_share_amount) AS requested_amount,
            --SUM (CASE WHEN b.bill_date NOT BETWEEN trunc(a.date_of_admission) AND trunc(a.date_of_discharge) THEN c.allowed_amount ELSE 0 END)  pre_post_amount,
            --SUM (CASE WHEN ward_type_id IN (''ROO'',''NUC'') THEN c.allowed_amount ELSE 0 END ) AS ROOM_CHARGES,
            --SUM (CASE WHEN ward_type_id IN (''ICU'',''ICC'',''ICN'',''ICR'') THEN c.allowed_amount ELSE 0 END ) AS ICU_CHARGES,
            --SUM (CASE WHEN ward_type_id IN (''PRO'') THEN c.allowed_amount ELSE 0 END ) AS PROFESSIONAL_CHARGES,
            --SUM (CASE WHEN ward_type_id IN (''LAI'') THEN c.allowed_amount ELSE 0 END ) AS LAB_CHARGES,
            --SUM (CASE WHEN ward_type_id IN (''PHA'',''MED'') THEN c.allowed_amount ELSE 0 END ) AS PHARMACY_CHARGES
            NULL AS pre_post_amount,
            NULL AS ROOM_CHARGES,
            NULL AS ICU_CHARGES,
            NULL AS PROFESSIONAL_CHARGES,
            NULL AS LAB_CHARGES,
            NULL AS PHARMACY_CHARGES
            FROM clm_authorization_details A 
              INNER JOIN tpa_claims_payment D ON (A.claim_seq_id = D.claim_seq_id)
              LEFT OUTER JOIN tpa_payment_checks_details E ON (d.payment_seq_id = e.payment_seq_id)
              LEFT OUTER JOIN tpa_claims_check C on (e.claims_chk_seq_id = c.claims_chk_seq_id)
              WHERE D.float_seq_id = :v_float_seq_id ' ||
                    v_where || ' GROUP BY D.payment_seq_id,D.Approved_Amount, nvl(c.check_amount, D.Approved_Amount))
              
        SELECT a.payment_seq_id,
              a.claim_payment_status ,' ||
                    to_char(v_batch_seq_id) || ' AS batch_no,
              ''' || v_bank_advice_file_name ||
                    ''' AS save_file_name,
              to_number(nvl(Ll.v_rej_amt,0))  AS tot_disallow_amt,
              to_number(nvl(Ll.v_disc_amt,0))  AS tot_discount_amt,
              to_number(nvl(Ll.v_pay_amt,0))  AS tot_payable_amt,
              to_number(nvl(Ll.v_chq_amt,0))  AS cheuqe_amt,
              to_number(CASE WHEN fin_payment_adv_slno.NEXTVAL > 199999
                                  THEN fin_payment_adv_slno.CURRVAL+50001
                                  ELSE fin_payment_adv_slno.CURRVAL END  ) AS slno,
              CASE WHEN a.hosp_seq_id IS NOT NULL THEN ''H''
                   ELSE CASE WHEN a.ENROL_TYPE_ID IN (''IND'',''ING'') THEN ''I'' WHEN a.ENROL_TYPE_ID =''COR'' THEN ''C'' ELSE ''N'' END
              END AS chq_drawee,
              ttk_util_pkg.fn_decrypt(a.payee_name) as payee_name, --Modified for koc11ed
              a.address1||'', ''||a.address2||'',''||a.address3 AS address,
              a.address1,
              a.address2,
              a.address3,
              null as address4,
              null as address5,
              null as address6,
              a.city,
              a.state,
              to_number(a.pincode) AS pincode,
              b.policy_number,
              c.tpa_enrollment_id,
              d.insured_name as mem_name ,
              d.employee_no,
              c.certificate_no,
              l.mem_name as claimant_name,
              --l.in_patient_no as ipno,
              null as ipno,
              l.settlement_number as claim_settlement_number ,
              a.claim_amount,
              ''PLS CONTACT US FOR FURTHER DETAILS'' AS pay_adv1,
              ''ENCASHMENT OF CHEQUE DISCHARGES THE LIABILITY OF INSURER UNDER THE SAID CLAIM'' AS pay_adv2,
              --f.remarks as dis_allow_reason1,
              null as dis_allow_reason2,
              null as dis_allow_reason3,
              null as dis_allow_reason4,
              null as dis_allow_reason5,
              i.address_1||i.address_2||i.address_3 AS addr1,
              i.address_1,
              i.address_2,
              i.address_3,
              j.city_description,
              to_number(i.pin_code) as pin_code,
              k.off_phone_no_1,
              k.office_fax_no_1,
              h.ins_comp_name,
              1 as do_lost,
              k.email_id,--not required to modfiy for koc11ed
              n.account_number AS UTIACC_NUM,
              ''DXB''||k.office_code||''PAY1'' AS product_name,
              ''Vidal Health TPA Pvt. Ltd'' AS TTK_Name,
              o.office_name AS Location,
                            CASE WHEN ct.description=''Member'' AND nvl(L.pay_to_general_type_id,''MBR'')!=''HSL'' THEN--This is added for hyundai requirement    -- 3 fields added for CR  KOC1108--same 3 fields modified for koc1103 for parmanent solution
              CASE WHEN a.tpa_nhcp_cheques_issued_to=''TPA'' THEN ''' ||
                    tpa_rec.account_number ||
                    ''' ELSE 
              (CASE WHEN b.enrol_type_id=''COR'' THEN (CASE WHEN b.tpa_cheque_issued_general_type=''IQI'' THEN ttk_util_pkg.fn_decrypt(p.bank_account_no)
              WHEN B.tpa_cheque_issued_general_type=''IQC'' THEN ttk_util_pkg.fn_decrypt(r.bank_account_no) END)
              ELSE ttk_util_pkg.fn_decrypt(p.bank_account_no) END)END 
              ELSE 
                CASE l.pymnt_to_type_id WHEN ''PTN'' THEN ttk_util_pkg.fn_decrypt(pa.account_number) 
                                        ELSE ttk_util_pkg.fn_decrypt(q.account_number) 
                END 
              end as account_num, --Modified for koc11ed
              CASE WHEN ct.description=''Member'' AND nvl(L.pay_to_general_type_id,''MBR'')!=''HSL'' THEN--This is added for hyundai requirement
              CASE WHEN a.tpa_nhcp_cheques_issued_to=''TPA'' THEN ''' ||
                    tpa_rec.account_type ||
                    ''' ELSE 
              (CASE WHEN b.enrol_type_id=''COR'' THEN (CASE WHEN b.tpa_cheque_issued_general_type=''IQI'' THEN p.account_name
              WHEN B.tpa_cheque_issued_general_type=''IQC'' THEN r.account_name end)
              ELSE P.account_name END)END 
              ELSE 
                CASE l.pymnt_to_type_id WHEN ''PTN'' THEN pa.account_type 
                                        ELSE q.account_type 
                END 
              end as account_type,
              CASE WHEN ct.description=''Member'' AND nvl(L.pay_to_general_type_id,''MBR'')!=''HSL'' THEN--This is added for hyundai requirement
              CASE WHEN a.tpa_nhcp_cheques_issued_to=''TPA'' THEN ''' ||
                    tpa_rec.bank_micr ||
                    ''' ELSE 
              (CASE WHEN b.enrol_type_id=''COR'' THEN (CASE WHEN b.tpa_cheque_issued_general_type=''IQI'' THEN ttk_util_pkg.fn_decrypt(p.bank_micr)
              WHEN B.tpa_cheque_issued_general_type=''IQC'' THEN ttk_util_pkg.fn_decrypt(r.bank_micr) end)
              ELSE ttk_util_pkg.fn_decrypt(p.bank_micr) END)END 
              ELSE 
                CASE l.pymnt_to_type_id WHEN ''PTN'' THEN pa.bank_micr 
                                        ELSE q.bank_micr 
                END 
              END AS MICR_CODE,--Modified for koc11ed
              CASE WHEN ct.description=''Member'' AND nvl(L.pay_to_general_type_id,''MBR'')!=''HSL'' THEN--This is added for hyundai requirement
              CASE WHEN a.tpa_nhcp_cheques_issued_to=''TPA'' THEN ''' ||
                    tpa_rec.bank_ifsc ||
                    ''' ELSE 
             (CASE WHEN b.enrol_type_id=''COR'' THEN (CASE WHEN b.tpa_cheque_issued_general_type=''IQI'' THEN ttk_util_pkg.fn_decrypt(p.bank_ifsc)
              WHEN B.tpa_cheque_issued_general_type=''IQC'' THEN ttk_util_pkg.fn_decrypt(r.bank_ifsc) end)
              ELSE ttk_util_pkg.fn_decrypt(p.bank_ifsc) END)END
              ELSE 
                CASE l.pymnt_to_type_id WHEN ''PTN'' THEN pa.bank_ifsc 
                                          ELSE q.bank_ifsc 
                  END  
              END AS IFSC_CODE, --Modified for koc11ed
              --pl.office_name AS Processed_Location
              FROM tpa_claims_payment a JOIN tpa_enr_policy b ON ( a.policy_seq_id = b.policy_seq_id )
              JOIN tpa_enr_policy_member c ON (a.member_seq_id = c.member_seq_id)
              JOIN tpa_enr_policy_group d ON (D.policy_group_seq_id = C.policy_group_seq_id)
              --JOIN clm_general_details l ON (l.claim_seq_id = a.claim_seq_id)
              --JOIN clm_enroll_details e ON (l.claim_seq_id = e.claim_seq_id)
              JOIN clm_authorization_details l ON (l.claim_seq_id = a.claim_seq_id)
              JOIN tpa_ins_info h ON (a.ins_seq_id = h.ins_seq_id)
              JOIN tpa_address i ON(h.tpa_office_seq_id = i.tpa_office_seq_id)
              JOIN tpa_city_code j ON (i.city_type_id = j.city_type_id)
              JOIN tpa_office_info k ON (h.tpa_office_seq_id = k.tpa_office_seq_id)
              LEFT OUTER JOIN tpa_office_info o ON (substr(a.claim_settlement_no ,1,3) = o.office_code)
              JOIN tpa_float_account m ON (m.float_seq_id = a.float_seq_id)
              JOIN tpa_bank_accounts n ON (n.bank_acc_seq_id = m.bank_acc_seq_id)
              --JOIN clm_inward ci ON (l.claims_inward_seq_id = ci.claims_inward_seq_id)--ADDED FOR KOC1103
              LEFT OUTER JOIN tpa_general_code ct ON (l.claim_type = ct.general_type_id )
              LEFT OUTER JOIN app.clm_hospital_details hosa ON (l.claim_seq_id = hosa.claim_seq_id)--KOC1103
              LEFT OUTER JOIN tpa_hosp_info hospi ON (hosa.hosp_seq_id = hospi.hosp_seq_id)--KOC1103
              LEFT OUTER JOIN tpa_hosp_address ha ON (hospi.hosp_seq_id = ha.hosp_seq_id)--KOC1103
              LEFT OUTER JOIN tpa_enr_bank_dtls r  ON (b.bank_seq_id=r.bank_seq_id)--ADDED FOR KOC1103
              LEFT OUTER JOIN tpa_enr_bank_dtls P  ON (D.BANK_SEQ_ID=P.BANK_SEQ_ID)--ADDED FOR KOC1103
              LEFT OUTER JOIN tpa_hosp_account_details q ON(hospi.hosp_seq_id=q.hosp_seq_id) --ADDED FOR KOC1103
              LEFT OUTER JOIN sum_tab Ll ON (A.payment_seq_id = Ll.payment_seq_id)
              --LEFT OUTER JOIN assign_users f ON (l.claim_seq_id = f.claim_seq_id and l.last_assign_user_seq_id = f.assign_users_seq_id)
              --LEFT OUTER JOIN tpa_office_info pl ON (f.tpa_office_seq_id = pl.tpa_office_seq_id)
              LEFT OUTER JOIN tpa_partner_info pi ON (a.ptnr_seq_id=pi.ptnr_seq_id)
              LEFT OUTER JOIN tpa_partner_account_details pa ON (pi.ptnr_seq_id=pa.ptnr_seq_id)
              WHERE a.float_seq_id = :v_float_seq_id ' ||
                    regexp_replace(v_where, 'D\.', 'A.') ||
                    ' AND a.claim_payment_status = ''READY_TO_BANK'' ';
    END IF;
    v_count_of_payments := str_tab.COUNT;
    --getting no_of_transactions/payemts count made to READY_TO_BANK.
    if v_bank_type in ('0', '2', '3', '99') then
      v_sql_str := v_sql_str || ' where AQ=1';
    else
      v_sql_str := v_sql_str;
    end if;

    IF str_tab.FIRST IS NOT NULL THEN
      IF str_tab.COUNT <= 8 AND v_bank_type ='QATAR' THEN
        CASE str_tab.COUNT
          WHEN 1 THEN
            OPEN v_resultset FOR v_sql_str
              USING v_float_seq_id, str_tab(1);
          WHEN 2 THEN
            OPEN v_resultset FOR v_sql_str
              USING v_float_seq_id, str_tab(1), str_tab(2);
          WHEN 3 THEN
            OPEN v_resultset FOR v_sql_str
              USING v_float_seq_id, str_tab(1), str_tab(2), str_tab(3);
          WHEN 4 THEN
            OPEN v_resultset FOR v_sql_str
              USING v_float_seq_id, str_tab(1), str_tab(2), str_tab(3), str_tab(4);
          WHEN 5 THEN
            OPEN v_resultset FOR v_sql_str
              USING v_float_seq_id, str_tab(1), str_tab(2), str_tab(3), str_tab(4), str_tab(5);
          WHEN 6 THEN
            OPEN v_resultset FOR v_sql_str
              USING v_float_seq_id, str_tab(1), str_tab(2), str_tab(3), str_tab(4), str_tab(5), str_tab(6);
          WHEN 7 THEN
            OPEN v_resultset FOR v_sql_str
              USING v_float_seq_id, str_tab(1), str_tab(2), str_tab(3), str_tab(4), str_tab(5), str_tab(6), str_tab(7);
          WHEN 8 THEN
            OPEN v_resultset FOR v_sql_str
              USING v_float_seq_id, str_tab(1), str_tab(2), str_tab(3), str_tab(4), str_tab(5), str_tab(6), str_tab(7), str_tab(8);
        END CASE;
        
      ELSIF   str_tab.COUNT <= 8 AND v_bank_type !='QATAR' THEN
      
             CASE str_tab.COUNT
          WHEN 1 THEN
            OPEN v_resultset FOR v_sql_str
              USING v_float_seq_id, str_tab(1)/*, v_float_seq_id*/;--, str_tab(1);
          WHEN 2 THEN
            OPEN v_resultset FOR v_sql_str
              USING v_float_seq_id, str_tab(1), str_tab(2), v_float_seq_id, str_tab(1), str_tab(2);
          WHEN 3 THEN
            OPEN v_resultset FOR v_sql_str
              USING v_float_seq_id, str_tab(1), str_tab(2), str_tab(3), v_float_seq_id, str_tab(1), str_tab(2), str_tab(3);
          WHEN 4 THEN
            OPEN v_resultset FOR v_sql_str
              USING v_float_seq_id, str_tab(1), str_tab(2), str_tab(3), str_tab(4), v_float_seq_id, str_tab(1), str_tab(2), str_tab(3), str_tab(4);
          WHEN 5 THEN
            OPEN v_resultset FOR v_sql_str
              USING v_float_seq_id, str_tab(1), str_tab(2), str_tab(3), str_tab(4), str_tab(5), v_float_seq_id, str_tab(1), str_tab(2), str_tab(3), str_tab(4), str_tab(5);
          WHEN 6 THEN
            OPEN v_resultset FOR v_sql_str
              USING v_float_seq_id, str_tab(1), str_tab(2), str_tab(3), str_tab(4), str_tab(5), str_tab(6), v_float_seq_id, str_tab(1), str_tab(2), str_tab(3), str_tab(4), str_tab(5), str_tab(6);
          WHEN 7 THEN
            OPEN v_resultset FOR v_sql_str
              USING v_float_seq_id, str_tab(1), str_tab(2), str_tab(3), str_tab(4), str_tab(5), str_tab(6), str_tab(7), v_float_seq_id, str_tab(1), str_tab(2), str_tab(3), str_tab(4), str_tab(5), str_tab(6), str_tab(7);
          WHEN 8 THEN
            OPEN v_resultset FOR v_sql_str
              USING v_float_seq_id, str_tab(1), str_tab(2), str_tab(3), str_tab(4), str_tab(5), str_tab(6), str_tab(7), str_tab(8), v_float_seq_id, str_tab(1), str_tab(2), str_tab(3), str_tab(4), str_tab(5), str_tab(6), str_tab(7), str_tab(8);
        END CASE;
     ELSIF str_tab.COUNT > 8 AND v_bank_type ='QATAR' THEN
        OPEN v_resultset FOR v_sql_str
          USING v_float_seq_id;
      ELSE 
        OPEN v_resultset FOR v_sql_str
          USING v_float_seq_id,v_float_seq_id;    
      END IF;
    ELSE
      OPEN v_resultset FOR v_sql_str
        USING v_float_seq_id, v_float_seq_id;
    END IF;
  
    UPDATE tpa_bank_advice_batch A
       SET A.no_of_transactions = v_count_of_payments,
           A.file_name          = v_filename,
           A.updated_date       = SYSDATE,
           a.updated_by         = v_added_by
     WHERE batch_seq_id = v_batch_seq_id;
  
    --update the status to sent_to_bank to the respective claims.
    IF str_tab.FIRST IS NOT NULL THEN
      FORALL i IN str_tab.FIRST .. str_tab.LAST
        UPDATE tpa_claims_payment a
           SET A.claim_payment_status = 'SENT_TO_BANK',
               A.bank_advice_batch    = bank_advice_batch_seq.CURRVAL,
               A.updated_date         = SYSDATE,
               a.updated_by           = v_added_by
         WHERE payment_seq_id = TO_NUMBER(str_tab(i));
    END IF;
  
    v_rows_processed := str_tab.LAST;
    COMMIT;
  END generate_payment_advice;
  ---================================================================================================================
  --this procedure is used to generate detail ms excel sheet for payment advices.
  PROCEDURE generate_payment_advice_dtl(v_payment_seq_id IN VARCHAR2,
                                        v_float_seq_id   IN tpa_float_account.float_seq_id%TYPE,
                                        v_resultset      OUT SYS_REFCURSOR) IS
    str_tab   ttk_util_pkg.str_table_type;
    v_where   VARCHAR2(1000);
    v_sql_str VARCHAR2(8000);
    i         NUMBER(2) := 0;
  BEGIN
    str_tab := ttk_util_pkg.parse_str(v_payment_seq_id);

    IF (str_tab.FIRST IS NOT NULL) THEN
      IF str_tab.COUNT <= 8 THEN
        FOR i in str_tab.FIRST .. str_tab.LAST LOOP
          v_where := v_where || ' OR D.payment_seq_id = :bind_tab_' || i;
        END LOOP;
      ELSE
        v_where := ' OR D.payment_seq_id IN ( ' ||
                   REPLACE(SUBSTR(v_payment_seq_id,
                                  2,
                                  LENGTH(v_payment_seq_id) - 2),
                           '|',
                           ',') || ') ';
      END IF;
    END IF;
  
    IF v_where IS NOT NULL THEN
      v_where := ' AND (' || substr(v_where, 4) || ')';
    END IF;
  
    v_sql_str := 'SELECT D.bank_advice_batch as Batch_no, cad.settlement_number,cad.invoice_number as bill_no,
          (cad.tot_disc_gross_amount-cad.tot_patient_share_amount - cad.tot_approved_amount)  as v_rej_amt, cad.remarks, ROWNUM as SlNo
        FROM app.clm_authorization_details cad 
            INNER JOIN tpa_claims_payment D ON (CAD.claim_seq_id = D.claim_seq_id)
            WHERE (Cad.Final_App_Amount-cad.tot_net_amount) >= 0 AND D.float_seq_id = :v_float_seq_id ' ||
                 v_where;
  
    IF str_tab.FIRST IS NOT NULL THEN
      IF str_tab.COUNT <= 8 THEN
        CASE str_tab.COUNT
          WHEN 1 THEN
            OPEN v_resultset FOR v_sql_str
              USING v_float_seq_id, str_tab(1);
          WHEN 2 THEN
            OPEN v_resultset FOR v_sql_str
              USING v_float_seq_id, str_tab(1), str_tab(2);
          WHEN 3 THEN
            OPEN v_resultset FOR v_sql_str
              USING v_float_seq_id, str_tab(1), str_tab(2), str_tab(3);
          WHEN 4 THEN
            OPEN v_resultset FOR v_sql_str
              USING v_float_seq_id, str_tab(1), str_tab(2), str_tab(3), str_tab(4);
          WHEN 5 THEN
            OPEN v_resultset FOR v_sql_str
              USING v_float_seq_id, str_tab(1), str_tab(2), str_tab(3), str_tab(4), str_tab(5);
          WHEN 6 THEN
            OPEN v_resultset FOR v_sql_str
              USING v_float_seq_id, str_tab(1), str_tab(2), str_tab(3), str_tab(4), str_tab(5), str_tab(6);
          WHEN 7 THEN
            OPEN v_resultset FOR v_sql_str
              USING v_float_seq_id, str_tab(1), str_tab(2), str_tab(3), str_tab(4), str_tab(5), str_tab(6), str_tab(7);
          WHEN 8 THEN
            OPEN v_resultset FOR v_sql_str
              USING v_float_seq_id, str_tab(1), str_tab(2), str_tab(3), str_tab(4), str_tab(5), str_tab(6), str_tab(7), str_tab(8);
        END CASE;
      ELSE
        OPEN v_resultset FOR v_sql_str
          USING v_float_seq_id;
      END IF;
    ELSE
      OPEN v_resultset FOR v_sql_str
        USING v_float_seq_id;
    END IF;
  END generate_payment_advice_dtl;
  --============================================================================================================================
  --this procedure is used to view the batches generated already for payment_advice.
  PROCEDURE view_payment_advice(v_float_seq_id        IN TPA_FLOAT_ACCOUNT.float_seq_id%TYPE,
                                v_file_name           IN OUT TPA_BANK_ADVICE_BATCH.file_name%TYPE,
                                v_batch_number        IN TPA_BANK_ADVICE_BATCH.batch_seq_id%TYPE,
                                v_claim_settlement_no IN OUT tpa_claims_payment.claim_settlement_no%TYPE,
                                v_batch_date          IN VARCHAR2,
                                v_sort_var            IN VARCHAR2,
                                v_sort_order          IN VARCHAR2,
                                v_start_num           IN NUMBER,
                                v_end_num             IN NUMBER,
                                v_added_by            IN NUMBER,
                                v_resultset           OUT SYS_REFCURSOR) IS
    v_sql_str            VARCHAR2(32000);
    v_clm_settlement_str VARCHAR2(1000);
    v_clm_where_str      VARCHAR2(1000);
    p_batch_date         DATE := TO_DATE(v_batch_date, 'DD/MM/YYYY');
  BEGIN

    IF v_file_name IS NOT NULL THEN
      v_file_name := UPPER(v_file_name) || '%';
    END IF;

    IF v_claim_settlement_no IS NOT NULL THEN
      v_claim_settlement_no := upper(v_claim_settlement_no);
      v_clm_settlement_str  := ' JOIN tpa_claims_payment c ON (a.batch_seq_id = c.bank_advice_batch ) ';
      v_clm_where_str       := ' AND ( :v_claim_settlement_no IS NULL OR C.claim_settlement_no = :v_claim_settlement_no )';

    END IF;

    v_sql_str := 'SELECT A.batch_seq_id,
      A.batch_date,
      A.batch_file_no,
      A.file_name,
      A.bank_seq_id,
      B.bank_name,
      A.added_by
      FROM tpa_bank_advice_batch A JOIN tpa_bank_master B ON (A.bank_seq_id = B.bank_seq_id)
      ' || v_clm_settlement_str || '
      WHERE A.float_seq_id = :v_float_seq_id
      AND ( :v_file_name IS NULL OR A.file_name LIKE :v_file_name)
      AND ( :v_batch_number IS NULL OR A.batch_seq_id = :v_batch_number)
      AND ( :p_batch_date IS NULL OR TRUNC(A.batch_date) = :p_batch_date )
      ' || v_clm_where_str;

    v_sql_str := v_sql_str || ' UNION ALL
    SELECT A.batch_seq_id,
      A.batch_date,
      A.batch_file_no,
      A.file_name||''-''||''Detail'',
      A.bank_seq_id,
      B.bank_name,
      A.added_by
      FROM tpa_bank_advice_batch A JOIN tpa_bank_master B ON (A.bank_seq_id = B.bank_seq_id)
      ' || v_clm_settlement_str || '
      WHERE (A.file_name LIKE ''ENBD%'' OR A.file_name LIKE ''BOA%'' OR A.file_name LIKE ''DEFL%'' OR A.file_name LIKE ''ALK%'' OR A.file_name LIKE ''QNBA%'' )  AND A.float_seq_id = :v_float_seq_id --Changed condition for KOC1220
      AND ( :v_file_name IS NULL OR A.file_name LIKE :v_file_name )
      AND ( :v_batch_number IS NULL OR A.batch_seq_id = :v_batch_number )
      AND ( :p_batch_date IS NULL OR TRUNC(A.batch_date) = :p_batch_date )
      ' || v_clm_where_str;

    v_sql_str := v_sql_str || ' UNION ALL
    SELECT A.batch_seq_id,
      A.batch_date,
      A.batch_file_no,
      A.file_name||''-''||''Consolidated'',
      A.bank_seq_id,
      B.bank_name,
      A.added_by
      FROM tpa_bank_advice_batch A JOIN tpa_bank_master B ON (A.bank_seq_id = B.bank_seq_id)
      ' || v_clm_settlement_str || '
      WHERE A.float_seq_id = :v_float_seq_id --Changed condition for KOC1220
      AND ( :v_file_name IS NULL OR A.file_name LIKE :v_file_name )
      AND ( :v_batch_number IS NULL OR A.batch_seq_id = :v_batch_number )
      AND ( :p_batch_date IS NULL OR TRUNC(A.batch_date) = :p_batch_date ) 
      ' || v_clm_where_str;
	  
	v_sql_str := v_sql_str || ' UNION ALL
    SELECT A.batch_seq_id,
      A.batch_date,
      A.batch_file_no,
      A.file_name||''-''||''CSV'',
      A.bank_seq_id,
      B.bank_name,
      A.added_by
      FROM tpa_bank_advice_batch A JOIN tpa_bank_master B ON (A.bank_seq_id = B.bank_seq_id)
      ' || v_clm_settlement_str || '
      WHERE (A.file_name LIKE ''DEFL%'' OR A.file_name LIKE ''ALK%'' OR A.file_name LIKE ''QNBA%'') AND A.float_seq_id = :v_float_seq_id --Changed condition for KOC1220
      AND ( :v_file_name IS NULL OR A.file_name LIKE :v_file_name )
      AND ( :v_batch_number IS NULL OR A.batch_seq_id = :v_batch_number )
      AND ( :p_batch_date IS NULL OR TRUNC(A.batch_date) = :p_batch_date )
      ' || v_clm_where_str;
   

   v_sql_str := v_sql_str || ' UNION ALL
    SELECT A.batch_seq_id,
      A.batch_date,
      A.batch_file_no,
      A.file_name||''-''||''SummaryPDF'',
      A.bank_seq_id,
      B.bank_name,
      A.added_by
      FROM tpa_bank_advice_batch A JOIN tpa_bank_master B ON (A.bank_seq_id = B.bank_seq_id)
      ' || v_clm_settlement_str || '
      WHERE (A.file_name LIKE ''DEFL%'' OR A.file_name LIKE ''ALK%'' OR A.file_name LIKE ''QNBA%'') AND A.float_seq_id = :v_float_seq_id --Changed condition for KOC1220
      AND ( :v_file_name IS NULL OR A.file_name LIKE :v_file_name )
      AND ( :v_batch_number IS NULL OR A.batch_seq_id = :v_batch_number )
      AND ( :p_batch_date IS NULL OR TRUNC(A.batch_date) = :p_batch_date )
      ' || v_clm_where_str;


   v_sql_str := v_sql_str || ' UNION ALL
    SELECT A.batch_seq_id,
      A.batch_date,
      A.batch_file_no,
      A.file_name||''-''||''SummaryEXCEL'',
      A.bank_seq_id,
      B.bank_name,
      A.added_by
      FROM tpa_bank_advice_batch A JOIN tpa_bank_master B ON (A.bank_seq_id = B.bank_seq_id)
      ' || v_clm_settlement_str || '
      WHERE (A.file_name LIKE ''DEFL%'' OR A.file_name LIKE ''ALK%'' OR A.file_name LIKE ''QNBA%'') AND A.float_seq_id = :v_float_seq_id --Changed condition for KOC1220
      AND ( :v_file_name IS NULL OR A.file_name LIKE :v_file_name )
      AND ( :v_batch_number IS NULL OR A.batch_seq_id = :v_batch_number )
      AND ( :p_batch_date IS NULL OR TRUNC(A.batch_date) = :p_batch_date )
      ' || v_clm_where_str;

    v_sql_str := 'SELECT * FROM
                     (SELECT A.*,DENSE_RANK() OVER (ORDER BY ' ||
                 v_sort_var || ' ' || v_sort_order ||
                 ',ROWNUM)
                      Q FROM (' || v_sql_str ||
                 ') A ) WHERE  Q>= :v_start_num  AND Q<=  :v_end_num ';
    IF v_claim_settlement_no IS NULL THEN
      OPEN v_resultset FOR v_sql_str
        USING v_float_seq_id, v_file_name, v_file_name, v_batch_number, v_batch_number, p_batch_date, p_batch_date,
              v_float_seq_id, v_file_name, v_file_name, v_batch_number, v_batch_number, p_batch_date, p_batch_date,
              v_float_seq_id, v_file_name, v_file_name, v_batch_number, v_batch_number, p_batch_date, p_batch_date,
              v_float_seq_id, v_file_name, v_file_name, v_batch_number, v_batch_number, p_batch_date, p_batch_date,
              v_float_seq_id, v_file_name, v_file_name, v_batch_number, v_batch_number, p_batch_date, p_batch_date,
              v_float_seq_id, v_file_name, v_file_name, v_batch_number, v_batch_number, p_batch_date, p_batch_date,
              v_start_num, v_end_num;
    ELSE
      OPEN v_resultset FOR v_sql_str
        USING  v_float_seq_id, v_file_name, v_file_name, v_batch_number, v_batch_number, p_batch_date, p_batch_date, v_claim_settlement_no, v_claim_settlement_no,
               v_float_seq_id, v_file_name, v_file_name, v_batch_number, v_batch_number, p_batch_date, p_batch_date, v_claim_settlement_no, v_claim_settlement_no,
               v_float_seq_id, v_file_name, v_file_name, v_batch_number, v_batch_number, p_batch_date, p_batch_date, v_claim_settlement_no, v_claim_settlement_no,
               v_float_seq_id, v_file_name, v_file_name, v_batch_number, v_batch_number, p_batch_date, p_batch_date, v_claim_settlement_no, v_claim_settlement_no,
               v_float_seq_id, v_file_name, v_file_name, v_batch_number, v_batch_number, p_batch_date, p_batch_date, v_claim_settlement_no, v_claim_settlement_no,
               v_float_seq_id, v_file_name, v_file_name, v_batch_number, v_batch_number, p_batch_date, p_batch_date, v_claim_settlement_no, v_claim_settlement_no,
               v_start_num, v_end_num;
    END IF;
  END view_payment_advice;
  --====================================================================================================================================
  --this procedure is used to generate the list of payment advice.
  PROCEDURE select_payment_advice_list(v_float_seQ_id IN TPA_FLOAT_ACCOUNT.float_seq_id%Type,
                                       --v_bank_seq_id             IN     TPA_BANK_MASTER.bank_seq_id%TYPE,
                                       v_float_name    IN TPA_FLOAT_ACCOUNT.float_account_name%TYPE,
                                       v_office_seq_id IN TPA_OFFICE_INFO.tpa_office_seq_id%TYPE,
                                       v_bank_acc_no   IN TPA_BANK_ACCOUNTS.account_number%TYPE,
                                       v_added_by      IN NUMBER,
                                       v_curency_type  IN VARCHAR2,
                                       v_payment_to    IN VARCHAR2,
						   v_vol_base_type IN VARCHAR2,
                                       v_sort_var      IN VARCHAR2,
                                       v_sort_order    IN VARCHAR2,
                                       v_start_num     IN NUMBER,
                                       v_end_num       IN NUMBER,
                                      
                                       result_set      OUT SYS_REFCURSOR) IS
    v_sql_str VARCHAR2(32600);
    TYPE bind_tab_type IS TABLE OF VARCHAR2(250) INDEX BY BINARY_INTEGER;
    bind_tab      bind_tab_type;
    i             NUMBER(2) := 0;
    v_bank_seq_id TPA_BANK_MASTER.bank_seq_id%TYPE;

  BEGIN

    SELECT BA.Bank_Seq_Id
      INTO v_bank_seq_id
      FROM tpa_bank_accounts BA
      JOIN tpa_float_account FA
        ON (BA.Bank_Acc_Seq_Id = FA.Bank_Acc_Seq_Id)
     WHERE FA.FLOAT_SEQ_ID = v_float_seQ_id;

    v_sql_str := 'with shrtfall as (select max(sd.shortfall_seq_id) sh_seq_id,cad.claim_seq_id
                       from clm_authorization_details cad
                       join shortfall_details sd on (cad.claim_seq_id = sd.claim_seq_id)
                       group by cad.claim_seq_id
                      )
    
    SELECT  A.payment_seq_id,
        F.float_seq_id,
        gd.req_amt_currency_type,
        gd.CONVERTED_FINAL_APPROVED_AMT,
        A.claim_settlement_no,
        B.tpa_enrollment_id,
        B.mem_name,
        K.description  AS claim_type,
        A.claim_aprv_date,
        ttk_util_pkg.fn_decrypt(A.payee_name) as in_favour_of,-- Modified for koc11ed
        A.approved_amount,
        H.bank_name as ho,
        J.bank_name AS BO,
        N.abbrevation_code,
        gd.clm_received_date as claim_recv_date,
        gr.group_name as corporate_name,
        F.current_balance,
	      CASE WHEN '''||v_payment_to ||'''=''USD'' THEN 
              gd.Pay_Amt_In_Usd -(CASE WHEN fa.DISC_PERC IS NOT NULL THEN  round((A.approved_amount*(fa.DISC_PERC/100))/3.64,2) ELSE 0 END )      
         WHEN '''||v_payment_to ||'''=''EUR'' THEN
              gd.Pay_Amt_In_Euro -(CASE WHEN fa.DISC_PERC IS NOT NULL THEN  round((A.approved_amount*(fa.DISC_PERC/100))/gd.conv_rate_in_euro,2) ELSE 0 END ) 
         WHEN '''||v_payment_to ||'''=''GBP'' THEN 
              gd.Pay_Amt_In_Gbp   - (CASE WHEN fa.DISC_PERC IS NOT NULL THEN  round((A.approved_amount*(fa.DISC_PERC/100))/gd.Conv_Rate_In_Gbp,2) ELSE 0 END )
      END 
            as usd_amount,
         '''||v_payment_to||''' as Selected_currency,
         CASE WHEN fa.DISC_PERC IS NOT NULL THEN  A.approved_amount*(fa.DISC_PERC/100) ELSE 0 END DISC_AMOUNT,
        A.approved_amount -(CASE WHEN fa.DISC_PERC IS NOT NULL THEN  A.approved_amount*(fa.DISC_PERC/100) ELSE 0 END ) AMT_PAID_AF_DISC,
          CASE WHEN clmb.CLM_TYPE_GEN_TYPE_ID=''CNH'' AND SRTFLL_RECEIVED_DATE IS NULL THEN
             CASE WHEN (SYSDATE-clmb.RECEIVED_DATE) BETWEEN FA.FST_FROM_DAYS AND FA.FST_TO_DAYS THEN 
                ''Y'' ELSE ''N'' END 
                 WHEN clmb.CLM_TYPE_GEN_TYPE_ID=''CNH'' AND SRTFLL_RECEIVED_DATE IS NOT NULL THEN 
                CASE WHEN (SYSDATE-SRTFLL_RECEIVED_DATE) BETWEEN FA.FST_FROM_DAYS AND FA.FST_TO_DAYS THEN 
                ''Y'' ELSE ''N'' END 
            ELSE ''N'' END AS FAST_TRACK,
           CASE WHEN clmb.CLM_TYPE_GEN_TYPE_ID=''CNH'' AND SRTFLL_RECEIVED_DATE IS NULL THEN 
              CASE WHEN (SYSDATE-clmb.RECEIVED_DATE) BETWEEN FA.FST_FROM_DAYS AND FA.FST_TO_DAYS+1 THEN 
               TO_CHAR(FA.FST_TO_DAYS-TRUNC(SYSDATE-clmb.RECEIVED_DATE)) ||'' DAYS REMAINING FOR PAYMENT'' ELSE ''N'' END 
               WHEN clmb.CLM_TYPE_GEN_TYPE_ID=''CNH'' AND SRTFLL_RECEIVED_DATE IS NOT NULL THEN     
              CASE WHEN (SYSDATE-SRTFLL_RECEIVED_DATE) BETWEEN FA.FST_FROM_DAYS AND FA.FST_TO_DAYS+1 THEN
               TO_CHAR(FA.FST_TO_DAYS-TRUNC(SYSDATE-SRTFLL_RECEIVED_DATE)) ||'' DAYS REMAINING FOR PAYMENT'' ELSE ''N'' END
               ELSE ''Not Avialable'' END  AS FAST_TRACK_MESSEGE,
                 (to_date(SYSDATE,''dd-mm-yyyy'') - to_date(gd.clm_received_date,''dd-mm-yyyy'')) AS claim_age,
            CASE WHEN A.HOSP_SEQ_ID is not null then o.Payment_Dur_Agr 
                 WHEN A.PTNR_SEQ_ID is not null then pi.Payment_Dur_Agr end Payment_Dur_Agr
       
       
        FROM tpa_claims_payment A LEFT OUTER JOIN tpa_enr_policy_member B ON (A.member_seq_id = B.member_seq_id)
        JOIN app.clm_authorization_details gd on (gd.settlement_number=a.claim_settlement_no)
        JOIN APP.CLM_BATCH_UPLOAD_DETAILS clmb ON (clmb.CLM_BATCH_SEQ_ID=gd.CLM_BATCH_SEQ_ID)
        JOIN tpa_enr_policy E ON (A.policy_seq_id = E.policy_seq_id )
        JOIN tpa_float_account F ON (A.float_seq_id = F.float_seq_id)
        LEFT OUTER JOIN tpa_bank_accounts G ON (F.bank_acc_seq_id = G.bank_acc_seq_id)
        LEFT OUTER JOIN tpa_bank_master  H ON (H.bank_seq_id = G.bank_seq_id)
        LEFT OUTER JOIN (SELECT bank_seq_id FROM tpa_bank_master ) I ON (I.bank_seq_id = H.ho_id)
        LEFT OUTER JOIN tpa_bank_master J ON (J.bank_seq_id = I.bank_seq_id)
        LEFT OUTER JOIN tpa_general_code K ON (K.general_type_id = A.claim_type)
        --LEFT OUTER JOIN tpa_group_registration L ON (L.group_reg_seq_id = A.group_reg_seq_id)
        LEFT OUTER JOIN tpa_office_info M ON (G.tpa_office_seq_id= M.tpa_office_seq_id)
        JOIN TPA_INS_INFO N ON (F.ins_seq_id=N.ins_seq_id)
        LEFT OUTER JOIN tpa_enr_policy_group pg ON (pg.Policy_Group_Seq_Id = b.Policy_Group_Seq_Id)
        LEFT OUTER JOIN tpa_group_registration gr ON (gr.Group_Reg_Seq_Id = pg.Group_Reg_Seq_Id)
        LEFT OUTER JOIN shrtfall sh on (sh.claim_seq_id=a.claim_Seq_id)
        left join shortfall_details sd on (sh.sh_seq_id=sd.shortfall_seq_id)
        LEFT OUTER JOIN APP.TPA_FASTTRACT_DISC_DETAILS FA ON (FA.HOSP_SEQ_ID=a.HOSP_SEQ_ID AND FA.DISC_MODE=''FAST'' AND FA.STATUS=''ACT''
        AND gd.DATE_OF_HOSPITALIZATION between fa.START_DATE and fa.end_date)
        LEFT OUTER JOIN APP.TPA_FASTTRACT_DISC_DETAILS VD ON (VD.HOSP_SEQ_ID=a.HOSP_SEQ_ID AND VD.DISC_MODE=''VOL'' AND VD.STATUS=''ACT'')
        LEFT OUTER JOIN APP.TPA_HOSP_INFO o ON (o.HOSP_SEQ_ID=a.HOSP_SEQ_ID)
        LEFT OUTER JOIN APP.TPA_PARTNER_INFO pi ON (pi.PTNR_SEQ_ID=a.PTNR_SEQ_ID)
        WHERE A.float_seq_id = :v_float_seq_id  AND A.deleted_yn = ''N''
        AND A.claim_payment_status  = ''READY_TO_BANK'' and a.payee_type NOT IN(''EFT'')';

    IF (v_bank_seq_id) IS NOT NULL THEN
      v_sql_str := v_sql_str ||
                   ' AND  H.bank_seq_id  IN ( SELECT bank_seq_id FROM tpa_bank_master
                                                          START WITH bank_seq_id = :v_bank_seq_id
                                                          CONNECT BY PRIOR bank_seq_id = ho_id )';
      i := i + 1;
      bind_tab(i) := v_bank_seq_id;
    END IF;
    IF (v_float_name) IS NOT NULL THEN
      v_sql_str := v_sql_str ||
                   ' AND F.float_account_name LIKE :v_float_name';
      i := i + 1;
      bind_tab(i) := UPPER(v_float_name) || '%';
    END IF;
    IF (v_office_seq_id) IS NOT NULL THEN
      v_sql_str := v_sql_str ||
                   ' AND M.tpa_office_seq_id =  :v_office_seq_id ';
      i := i + 1;
      bind_tab(i) := v_office_seq_id;
    END IF;
     ---added for currency conversion 
    IF (v_curency_type) IS NOT NULL THEN
      IF v_curency_type='QAR' THEN
          v_sql_str := v_sql_str || ' AND nvl(gd.req_amt_currency_type,''QAR'') = :v_curency_type ';
          i := i + 1;
          bind_tab(i) := v_curency_type;
      ELSIF v_curency_type!='QAR' THEN 
          v_sql_str := v_sql_str || ' AND gd.req_amt_currency_type != :v_curency_type ';
          i := i + 1;
          bind_tab(i) := v_curency_type;
      END IF;    
    END IF;
    
    IF (v_bank_acc_no) IS NOT NULL THEN
      v_sql_str := v_sql_str ||
                   ' AND G.account_number LIKE :v_bank_acc_no ';
      i := i + 1;
      bind_tab(i) := v_bank_acc_no || '%';
    END IF;
    
    --Volume Base Discount Search Based On select Criteria
   IF v_vol_base_type='MNPD' THEN
    
     v_sql_str := v_sql_str ||' AND VD.DISC_TYPE= :v_vol_base_type ';
      i := i + 1;
      bind_tab(i) := v_vol_base_type ;
    
    ELSIF v_vol_base_type='ANPD' THEN
    
      v_sql_str := v_sql_str ||'AND VD.DISC_TYPE= :v_vol_base_type ';
      i := i + 1;
      bind_tab(i) := v_vol_base_type ;
    
    ELSIF v_vol_base_type='NONE' THEN
    
      v_sql_str := v_sql_str ||'AND (A.hosp_seq_id not in (select distinct hosp_seq_id from app.tpa_fasttract_disc_details where DISC_MODE=''VOL'' AND STATUS=''ACT'') OR A.HOSP_SEQ_ID IS NULL)';

    END IF;
   ------   
    v_sql_str := 'SELECT * FROM
                 (SELECT A.*,DENSE_RANK() OVER (ORDER BY ' ||
                 v_sort_var || ' ' || v_sort_order ||
                 ',ROWNUM)
                  Q FROM (' || v_sql_str ||
                 ') A ) WHERE  Q>= :v_start_num  AND Q<=  :v_end_num ';
    IF bind_tab.FIRST IS NOT NULL THEN
      CASE bind_tab.COUNT
        WHEN 1 THEN
          OPEN result_set FOR v_sql_str
            USING v_float_seq_id, bind_tab(1), v_start_num, v_end_num;
        WHEN 2 THEN
          OPEN result_set FOR v_sql_str
            USING v_float_seq_id, bind_tab(1), bind_tab(2), v_start_num, v_end_num;
        WHEN 3 THEN
          OPEN result_set FOR v_sql_str
            USING v_float_seq_id, bind_tab(1), bind_tab(2), bind_tab(3), v_start_num, v_end_num;
        WHEN 4 THEN
          OPEN result_set FOR v_sql_str
            USING v_float_seq_id, bind_tab(1), bind_tab(2), bind_tab(3), bind_tab(4), v_start_num, v_end_num;
      WHEN 5 THEN
          OPEN result_set FOR v_sql_str
            USING v_float_seq_id, bind_tab(1), bind_tab(2), bind_tab(3), bind_tab(4),bind_tab(5), v_start_num, v_end_num;
      WHEN 6 THEN
          OPEN result_set FOR v_sql_str
            USING v_float_seq_id, bind_tab(1), bind_tab(2), bind_tab(3), bind_tab(4),bind_tab(5),bind_tab(6), v_start_num, v_end_num;
      WHEN 7 THEN
          OPEN result_set FOR v_sql_str
            USING v_float_seq_id, bind_tab(1), bind_tab(2), bind_tab(3), bind_tab(4),bind_tab(5),bind_tab(6),bind_tab(7), v_start_num, v_end_num;       
     END CASE;
    ELSE
      OPEN result_set FOR v_sql_str
        USING v_float_seq_id, v_start_num, v_end_num;
    END IF;

  END select_payment_advice_list;
  /*==============================================================================================
     Name       : select_eft_payment_advice_list
     Created on : 17-05-12
     Created By : Ibrahim Sayyed
     Company    : RCS Technologies
     Added for  : KOC1103
     Comments   : This procedure is used to fetch the eft payment claims
  ============================================================================================== */
  PROCEDURE select_eft_payment_advice_list(v_float_seQ_id IN TPA_FLOAT_ACCOUNT.float_seq_id%Type,
                                           --v_bank_seq_id             IN     TPA_BANK_MASTER.bank_seq_id%TYPE,
                                           v_float_name    IN TPA_FLOAT_ACCOUNT.float_account_name%TYPE,
                                           v_office_seq_id IN TPA_OFFICE_INFO.tpa_office_seq_id%TYPE,
                                           v_bank_acc_no   IN TPA_BANK_ACCOUNTS.account_number%TYPE,
                                           v_added_by      IN NUMBER,
                                           v_curency_type  IN VARCHAR2,
                                           v_payment_to    IN VARCHAR2,
 							 v_vol_base_type IN VARCHAR2,
                                           v_sort_var      IN VARCHAR2,
                                           v_sort_order    IN VARCHAR2,
                                           v_start_num     IN NUMBER,
                                           v_end_num       IN NUMBER,
                                           result_set      OUT SYS_REFCURSOR) IS
    v_sql_str VARCHAR2(32600);
    TYPE bind_tab_type IS TABLE OF VARCHAR2(250) INDEX BY BINARY_INTEGER;
    bind_tab      bind_tab_type;
    i             NUMBER(2) := 0;
    v_bank_seq_id TPA_BANK_MASTER.bank_seq_id%TYPE;
   
  BEGIN

    SELECT BA.Bank_Seq_Id
      INTO v_bank_seq_id
      FROM tpa_bank_accounts BA
      JOIN tpa_float_account FA
        ON (BA.Bank_Acc_Seq_Id = FA.Bank_Acc_Seq_Id)
     WHERE FA.FLOAT_SEQ_ID = v_float_seQ_id;

    v_sql_str := 'with shrtfall as (select max(sd.shortfall_seq_id) sh_seq_id,cad.claim_seq_id
                       from clm_authorization_details cad
                       join shortfall_details sd on (cad.claim_seq_id = sd.claim_seq_id)
                       group by cad.claim_seq_id
                      )
    
    
     SELECT  A.payment_seq_id,
        nvl(gd.req_amt_currency_type,''-'') as req_amt_currency_type ,
        trunc(gd.CONVERTED_FINAL_APPROVED_AMT,2) CONVERTED_FINAL_APPROVED_AMT,
        F.float_seq_id,
        A.claim_settlement_no,
        B.tpa_enrollment_id,
        B.mem_name,
        K.description  AS claim_type,
        A.claim_aprv_date,
        ttk_util_pkg.fn_decrypt(A.payee_name) as in_favour_of, --Modified for koc11ed
        A.approved_amount,
        H.bank_name as ho,
        J.bank_name AS BO,
        N.abbrevation_code,
        gd.clm_received_date as claim_recv_date,
        gr.group_name as corporate_name,
        F.current_balance,
	  CASE WHEN '''||v_payment_to ||'''=''USD'' THEN 
              Pay_Amt_In_Usd -(CASE WHEN (round(sysdate - gd.clm_received_date))<= fa.FST_TO_DAYS THEN  round((A.approved_amount*(fa.DISC_PERC/100))/3.64,2) ELSE 0 END )      
         WHEN '''||v_payment_to ||'''=''EUR'' THEN
              Pay_Amt_In_Euro -(CASE WHEN (round(sysdate - gd.clm_received_date))<= fa.FST_TO_DAYS THEN  round((A.approved_amount*(fa.DISC_PERC/100))/conv_rate_in_euro,2) ELSE 0 END ) 
         WHEN '''||v_payment_to ||'''=''GBP'' THEN 
              Pay_Amt_In_Gbp   - (CASE WHEN (round(sysdate - gd.clm_received_date))<= fa.FST_TO_DAYS THEN  round((A.approved_amount*(fa.DISC_PERC/100))/Conv_Rate_In_Gbp,2) ELSE 0 END )
      END 
            as usd_amount,
        '''||v_payment_to ||''' as Selected_currency,
        CASE WHEN(round(sysdate - gd.clm_received_date))<= fa.FST_TO_DAYS THEN  A.approved_amount*(fa.DISC_PERC/100) ELSE 0 END DISC_AMOUNT,
        A.approved_amount -(CASE WHEN (round(sysdate - gd.clm_received_date))<= fa.FST_TO_DAYS THEN  A.approved_amount*(fa.DISC_PERC/100) ELSE 0 END ) AMT_PAID_AF_DISC,
          CASE WHEN clmb.CLM_TYPE_GEN_TYPE_ID=''CNH'' AND SRTFLL_RECEIVED_DATE IS NULL THEN
             CASE WHEN (SYSDATE-clmb.RECEIVED_DATE) BETWEEN FA.FST_FROM_DAYS AND FA.FST_TO_DAYS THEN 
                ''Y'' ELSE ''N'' END 
                 WHEN clmb.CLM_TYPE_GEN_TYPE_ID=''CNH'' AND SRTFLL_RECEIVED_DATE IS NOT NULL THEN 
                CASE WHEN (SYSDATE-SRTFLL_RECEIVED_DATE) BETWEEN FA.FST_FROM_DAYS AND FA.FST_TO_DAYS THEN 
                ''Y'' ELSE ''N'' END 
            ELSE ''N'' END AS FAST_TRACK,
           CASE WHEN clmb.CLM_TYPE_GEN_TYPE_ID=''CNH'' AND SRTFLL_RECEIVED_DATE IS NULL THEN 
              CASE WHEN (SYSDATE-clmb.RECEIVED_DATE) BETWEEN FA.FST_FROM_DAYS AND FA.FST_TO_DAYS+1 THEN 
                TO_CHAR(FA.FST_TO_DAYS-TRUNC(SYSDATE-clmb.RECEIVED_DATE)) ||'' DAYS REMAINING FOR PAYMENT'' ELSE ''N'' END 
               WHEN clmb.CLM_TYPE_GEN_TYPE_ID=''CNH'' AND SRTFLL_RECEIVED_DATE IS NOT NULL THEN     
              CASE WHEN (SYSDATE-SRTFLL_RECEIVED_DATE) BETWEEN FA.FST_FROM_DAYS AND FA.FST_TO_DAYS+1 THEN
               TO_CHAR(FA.FST_TO_DAYS-TRUNC(SYSDATE-SRTFLL_RECEIVED_DATE)) ||'' DAYS REMAINING FOR PAYMENT'' ELSE ''N'' END
               ELSE ''Not Available'' END  AS FAST_TRACK_MESSEGE,
                 (to_date(SYSDATE,''dd-mm-yyyy'') - to_date(gd.clm_received_date,''dd-mm-yyyy'')) AS claim_age,
             CASE WHEN A.HOSP_SEQ_ID is not null then o.Payment_Dur_Agr 
             WHEN A.PTNR_SEQ_ID is not null then pi.Payment_Dur_Agr end Payment_Dur_Agr
         
        FROM tpa_claims_payment A JOIN tpa_enr_policy_member B ON (A.member_seq_id = B.member_seq_id)
        JOIN app.clm_authorization_details gd on (gd.settlement_number=a.claim_settlement_no)
        JOIN APP.CLM_BATCH_UPLOAD_DETAILS clmb ON (clmb.CLM_BATCH_SEQ_ID=gd.CLM_BATCH_SEQ_ID)
        JOIN tpa_enr_policy E ON (A.policy_seq_id = E.policy_seq_id )
        JOIN tpa_float_account F ON (A.float_seq_id = F.float_seq_id)
        LEFT OUTER JOIN tpa_bank_accounts G ON (F.bank_acc_seq_id = G.bank_acc_seq_id)
        LEFT OUTER JOIN tpa_bank_master  H ON (H.bank_seq_id = G.bank_seq_id)
        LEFT OUTER JOIN (SELECT bank_seq_id FROM tpa_bank_master ) I ON (I.bank_seq_id = H.ho_id)
        LEFT OUTER JOIN tpa_bank_master J ON (J.bank_seq_id = I.bank_seq_id)
        LEFT OUTER JOIN tpa_general_code K ON (K.general_type_id = A.claim_type)
        --LEFT OUTER JOIN tpa_group_registration L ON (L.group_reg_seq_id = A.group_reg_seq_id)
        LEFT OUTER JOIN tpa_office_info M ON (G.tpa_office_seq_id= M.tpa_office_seq_id)
        JOIN TPA_INS_INFO N ON (F.ins_seq_id=N.ins_seq_id)
        LEFT OUTER JOIN tpa_enr_policy_group pg ON (pg.Policy_Group_Seq_Id = b.Policy_Group_Seq_Id)
        LEFT OUTER JOIN tpa_group_registration gr ON (gr.Group_Reg_Seq_Id = pg.Group_Reg_Seq_Id)
        LEFT OUTER JOIN shrtfall sh on (sh.claim_seq_id=a.claim_Seq_id)
        left join shortfall_details sd on (sh.sh_seq_id=sd.shortfall_seq_id)
        LEFT OUTER JOIN APP.TPA_FASTTRACT_DISC_DETAILS FA ON (FA.HOSP_SEQ_ID=a.HOSP_SEQ_ID AND FA.DISC_MODE=''FAST'' AND FA.STATUS=''ACT''
        AND gd.DATE_OF_HOSPITALIZATION between fa.START_DATE and fa.end_date)
        LEFT OUTER JOIN APP.TPA_FASTTRACT_DISC_DETAILS VD ON (VD.HOSP_SEQ_ID=a.HOSP_SEQ_ID AND VD.DISC_MODE=''VOL'' AND VD.STATUS=''ACT'')
        LEFT OUTER JOIN APP.TPA_HOSP_INFO o ON (A.HOSP_SEQ_ID=o.HOSP_SEQ_ID)
        LEFT OUTER JOIN APP.TPA_PARTNER_INFO pi ON (pi.PTNR_SEQ_ID=a.PTNR_SEQ_ID)
        WHERE A.float_seq_id = :v_float_seq_id  AND A.deleted_yn = ''N''
        AND A.claim_payment_status  = ''READY_TO_BANK'' AND a.payee_type=''EFT'''; --

    IF (v_bank_seq_id) IS NOT NULL THEN
      v_sql_str := v_sql_str ||
                   ' AND  H.bank_seq_id  IN ( SELECT bank_seq_id FROM tpa_bank_master
                                                          START WITH bank_seq_id = :v_bank_seq_id
                                                          CONNECT BY PRIOR bank_seq_id = ho_id )';
      i := i + 1;
      bind_tab(i) := v_bank_seq_id;
    END IF;
    IF (v_float_name) IS NOT NULL THEN
      v_sql_str := v_sql_str ||
                   ' AND F.float_account_name LIKE :v_float_name';
      i := i + 1;
      bind_tab(i) := UPPER(v_float_name) || '%';
    END IF;
    IF (v_office_seq_id) IS NOT NULL THEN
      v_sql_str := v_sql_str ||
                   ' AND M.tpa_office_seq_id =  :v_office_seq_id ';
      i := i + 1;
      bind_tab(i) := v_office_seq_id;
    END IF;
    ---added for currency conversion 
    IF (v_curency_type) IS NOT NULL  AND v_curency_type !='ANY' THEN
      IF v_curency_type='QAR' THEN
          v_sql_str := v_sql_str || ' AND nvl(gd.req_amt_currency_type,''QAR'') = :v_curency_type ';
          i := i + 1;
          bind_tab(i) := v_curency_type;
      ELSIF v_curency_type='OTQ' THEN 
          v_sql_str := v_sql_str || ' AND gd.req_amt_currency_type != :v_curency_type ';
          i := i + 1;
          bind_tab(i) := 'QAR';
      ELSE
         v_sql_str := v_sql_str || ' AND gd.req_amt_currency_type = :v_curency_type ';
          i := i + 1;
          bind_tab(i) := v_curency_type;   
      END IF;    
    END IF;
    
    IF (v_bank_acc_no) IS NOT NULL THEN
      v_sql_str := v_sql_str ||
                   ' AND G.account_number LIKE :v_bank_acc_no ';
      i := i + 1;
      bind_tab(i) := v_bank_acc_no || '%';
    END IF;
    
  --Volume Base Discount Search Based On select Criteria
   IF v_vol_base_type='MNPD' THEN
    
     v_sql_str := v_sql_str ||' AND VD.DISC_TYPE= :v_vol_base_type';
      i := i + 1;
      bind_tab(i) := 'MNPD' ;
    
    ELSIF v_vol_base_type='ANPD' THEN
    
      v_sql_str := v_sql_str ||'AND VD.DISC_TYPE= :v_vol_base_type';
      i := i + 1;
      bind_tab(i) := 'ANPD';
    
    ELSIF v_vol_base_type='NONE' THEN
    
      v_sql_str := v_sql_str ||'AND (A.hosp_seq_id not in (select distinct hosp_seq_id from app.tpa_fasttract_disc_details where DISC_MODE=''VOL'') OR A.HOSP_SEQ_ID IS NULL)';

    END IF;
   ------   
    
    v_sql_str := 'SELECT * FROM
                 (SELECT A.*,DENSE_RANK() OVER (ORDER BY ' ||
                 v_sort_var || ' ' || v_sort_order ||
                 ',ROWNUM)
                  Q FROM (' || v_sql_str ||
                 ') A ) WHERE  Q>= :v_start_num  AND Q<=  :v_end_num ';
    IF bind_tab.FIRST IS NOT NULL THEN
      CASE bind_tab.COUNT
        WHEN 1 THEN
          OPEN result_set FOR v_sql_str
            USING v_float_seq_id, bind_tab(1), v_start_num, v_end_num;
        WHEN 2 THEN
          OPEN result_set FOR v_sql_str
            USING v_float_seq_id, bind_tab(1), bind_tab(2), v_start_num, v_end_num;
        WHEN 3 THEN
          OPEN result_set FOR v_sql_str
            USING v_float_seq_id, bind_tab(1), bind_tab(2), bind_tab(3), v_start_num, v_end_num;
        WHEN 4 THEN
          OPEN result_set FOR v_sql_str
            USING v_float_seq_id, bind_tab(1), bind_tab(2), bind_tab(3), bind_tab(4), v_start_num, v_end_num;
      WHEN 5 THEN
          OPEN result_set FOR v_sql_str
            USING v_float_seq_id, bind_tab(1), bind_tab(2), bind_tab(3), bind_tab(4),bind_tab(5), v_start_num, v_end_num;
     WHEN 6 THEN
          OPEN result_set FOR v_sql_str
            USING v_float_seq_id, bind_tab(1), bind_tab(2), bind_tab(3), bind_tab(4),bind_tab(5),bind_tab(6), v_start_num, v_end_num;
     WHEN 7 THEN
          OPEN result_set FOR v_sql_str
            USING v_float_seq_id, bind_tab(1), bind_tab(2), bind_tab(3), bind_tab(4),bind_tab(5),bind_tab(6),bind_tab(7) ,v_start_num, v_end_num;
      END CASE;
    ELSE
      OPEN result_set FOR v_sql_str
        USING v_float_seq_id, v_start_num, v_end_num;
    END IF;

  END select_eft_payment_advice_list;
  --========================================================================================================
  PROCEDURE manual_batch_list(v_payment_seq_id IN VARCHAR2,
                              v_resultset      OUT SYS_REFCURSOR) IS
    str_tab   ttk_util_pkg.str_table_type;
    v_where   VARCHAR2(32000);
    v_sql_str VARCHAR2(32000);
  BEGIN
    str_tab := ttk_util_pkg.parse_str(v_payment_seq_id);
    IF (str_tab.FIRST IS NOT NULL) THEN
      IF str_tab.COUNT <= 8 THEN
        FOR i in str_tab.FIRST .. str_tab.LAST LOOP
          v_where := v_where || ' OR B.payment_seq_id = :bind_tab_' || i;
        END LOOP;
      ELSE
        v_where := ' OR B.payment_seq_id IN ( ' ||
                   REPLACE(SUBSTR(v_payment_seq_id,
                                  2,
                                  LENGTH(v_payment_seq_id) - 2),
                           '|',
                           ',') || ') ';
      END IF;
    END IF;

    IF v_where IS NOT NULL THEN
      v_where := ' WHERE  (' || substr(v_where, 4) || ') AND ';
    ELSE
      v_where := ' WHERE ';
    END IF;

    v_sql_str := 'SELECT A.batch_number,
        TO_CHAR(A.batch_date,''DD/MM/YYYY'') AS batch_date,
        A.number_of_cheques,
        A.batch_amount
        FROM tpa_batch_master A JOIN tpa_claims_payment B ON (A.batch_number = B.batch_number_manual) ' ||
                 v_where ||
                 '  A.deleted_yn = ''N'' GROUP BY A.batch_number,A.batch_date,A.number_of_cheques,A.batch_amount';

    IF str_tab.FIRST IS NOT NULL AND str_tab.COUNT <= 8 THEN
      CASE str_tab.COUNT
        WHEN 1 THEN
          OPEN v_resultset FOR v_sql_str
            USING str_tab(1);
        WHEN 2 THEN
          OPEN v_resultset FOR v_sql_str
            USING str_tab(1), str_tab(2);
        WHEN 3 THEN
          OPEN v_resultset FOR v_sql_str
            USING str_tab(1), str_tab(2), str_tab(3);
        WHEN 4 THEN
          OPEN v_resultset FOR v_sql_str
            USING str_tab(1), str_tab(2), str_tab(3), str_tab(4);
        WHEN 5 THEN
          OPEN v_resultset FOR v_sql_str
            USING str_tab(1), str_tab(2), str_tab(3), str_tab(4), str_tab(5);
        WHEN 6 THEN
          OPEN v_resultset FOR v_sql_str
            USING str_tab(1), str_tab(2), str_tab(3), str_tab(4), str_tab(5), str_tab(6);
        WHEN 7 THEN
          OPEN v_resultset FOR v_sql_str
            USING str_tab(1), str_tab(2), str_tab(3), str_tab(4), str_tab(5), str_tab(6), str_tab(7);
        WHEN 8 THEN
          OPEN v_resultset FOR v_sql_str
            USING str_tab(1), str_tab(2), str_tab(3), str_tab(4), str_tab(5), str_tab(6), str_tab(7), str_tab(8);
      END CASE;
    ELSE
      OPEN v_resultset FOR v_sql_str;
    END IF;
  END manual_batch_list;
  -- ==========================================================================================================================================
  -- this procedure is used to generate the invoices to the insurance company excel sheet
  PROCEDURE generate_ind_invoice_list(v_fin_policy_seq_id IN VARCHAR2,
                                      v_enrol_type        IN VARCHAR2,
                                      v_batch_date        IN DATE,
                                      v_added_by          IN NUMBER,
                                      v_resultset         OUT SYS_REFCURSOR) IS
    v_rows_processed tpa_inv_batch.no_of_transations%TYPE;
    v_batch_name     tpa_inv_batch.batch_name%TYPE;
    v_batch_seq_id   tpa_inv_batch.batch_seq_id%TYPE;
    str_tab          ttk_util_pkg.str_table_type;
    --    v_fin_seq_ids            VARCHAR2(200) := REPLACE(SUBSTR( v_fin_policy_seq_id,2,LENGTH (v_fin_policy_seq_id )-2),'|',',');
    v_sql_str VARCHAR2(4000);
    v_where   VARCHAR2(1000);
  BEGIN
    --this is used for Enrollment of policy of individual invoice.
    str_tab := ttk_util_pkg.parse_str(v_fin_policy_seq_id);

    IF (str_tab.FIRST IS NOT NULL) THEN
      IF str_tab.COUNT <= 8 THEN
        FOR i in str_tab.FIRST .. str_tab.LAST LOOP
          v_where := v_where || ' OR A.fin_policy_seq_id = :bind_tab_' || i;
        END LOOP;
      ELSE
        v_where := ' OR A.fin_policy_seq_id IN ( ' ||
                   REPLACE(SUBSTR(v_fin_policy_seq_id,
                                  2,
                                  LENGTH(v_fin_policy_seq_id) - 2),
                           '|',
                           ',') || ') ';
      END IF;
    END IF;

    IF v_where IS NOT NULL THEN
      v_where := ' (' || substr(v_where, 4) || ') ';
    END IF;

    IF (v_enrol_type = 'IND') THEN
      v_batch_name := 'IND' || '-' ||
                      TO_CHAR(v_batch_date, 'DDMMYYYY-HHMI') || '-' ||
                      v_added_by;

      v_sql_str := 'SELECT
        0 as inv_type,
        D.office_code,
        B.abbrevation_code,
        C.enrol_description,
        B.ins_comp_code_number AS BODO,
        E.policy_number,
        F.insured_name,
        F.tpa_enrollment_number,
        COUNT(1) AS dependents,
        TO_CHAR(e.policy_issue_date,''dd/mm/yyyy'') as pol_issued_date,
        A.sum_insured,
        A.net_premium,
        (H.commission_to_tpa * A.NET_PREMIUM)/100 AS tpa_comm,
        null as tpa_adddt,
        i.cust_endorsement_number,
        i.endorsement_number,
        TO_CHAR(i.received_date,''dd/mm/yyyy'') AS cust_rcvd_dt,
        TO_CHAR(i.effective_date,''dd/mm/yyyy'') AS cust_eff_dt,
        :v_batch_name as batch_name,
        (CEIL(MONTHS_BETWEEN(E.effective_to_date,E.effective_from_date))/12) AS TENURE
        FROM tpa_fin_policy_details A JOIN tpa_ins_info B ON (A.ins_seq_id = B.ins_seq_id)
        JOIN Tpa_Enrolment_Type_Code C ON (A.enrol_type_id = C.enrol_type_id)
        JOIN tpa_office_info D ON (A.tpa_office_seq_id = D.tpa_office_seq_id)
        JOIN tpa_enr_policy E ON (E.policy_seq_id = A.policy_seq_id)
        JOIN tpa_enr_policy_group F ON (E.policy_seq_id = F.policy_seq_id)
        LEFT OUTER JOIN tpa_enr_policy_member G ON (F.policy_group_seq_id = G.policy_group_seq_id)
        LEFT OUTER JOIN tpa_ins_assoc_off_product H ON (A.ins_seq_id = H.ins_seq_id AND A.product_seq_id = H.product_seq_id )
        LEFT OUTER JOIN tpa_enr_endorsements I ON (I.endorsement_seq_id = a.endorsement_seq_id)
        WHERE ' || v_where || '
        AND F.deleted_yn = ''N''
        AND G.deleted_yn = ''N''
        AND H.enrol_type_id = :v_enrol_type
        AND A.enrol_type_id = :v_enrol_type
        AND E.policy_issue_date >= H.valid_from
        AND E.effective_to_date <= NVL( H.valid_to,E.effective_to_date )
        AND G.status_general_type_id != ''POC''
        GROUP BY  D.office_code,B.abbrevation_code,C.enrol_description,B.ins_comp_code_number ,
                 E.policy_number,F.insured_name,F.tpa_enrollment_number,E.policy_issue_date,
                 A.sum_insured,A.net_premium,A.commision_to_tpa,F.deleted_yn,G.deleted_yn
                 ,E.effective_from_date,E.effective_to_date,H.commission_to_tpa,A.net_premium ,i.cust_endorsement_number,
                  i.endorsement_number,TO_CHAR(i.received_date,''dd/mm/yyyy''),TO_CHAR(i.effective_date,''dd/mm/yyyy'') ';

      --this part is used for enrollment of corporate ,individual as group and non corporate.
    ELSIF (v_enrol_type = 'COR') OR (v_enrol_type = 'ING') OR
          (v_enrol_type = 'NCR') THEN
      v_batch_name := 'GROUP' || '-' ||
                      TO_CHAR(v_batch_date, 'DDMMYYYY-HHMI') || '-' ||
                      v_added_by;

      v_sql_str := 'SELECT
          0 as inv_type,
          D.office_code,
          B.abbrevation_code,
          C.enrol_description,
          B.ins_comp_code_number AS BODO,
          E.policy_number,
          i.group_name,
          i.group_id,
          COUNT(1) AS dependents,
          TO_CHAR(E.policy_issue_date,''dd/mm/yyyy'') as pol_issued_date,
          A.sum_insured,
          A.net_premium,
          (H.commission_to_tpa * A.net_premium)/100 AS tpa_comm,
          null as tpa_adddt,
          J.cust_endorsement_number,
          J.endorsement_number,
          TO_CHAR(J.received_date,''dd/mm/yyyy'') AS cust_rcvd_dt,
          TO_CHAR(J.effective_date,''dd/mm/yyyy'') AS cust_eff_dt,
          :v_batch_name as batch_name,
          (CEIL(MONTHS_BETWEEN(E.effective_to_date,E.effective_from_date))/12) AS TENURE
          FROM tpa_fin_policy_details A JOIN tpa_ins_info B ON (A.ins_seq_id = B.ins_seq_id)
          JOIN Tpa_Enrolment_Type_Code C ON (A.enrol_type_id = C.enrol_type_id)
          JOIN tpa_office_info D ON (A.tpa_office_seq_id = D.tpa_office_seq_id)
          JOIN tpa_enr_policy E ON (E.policy_seq_id = A.policy_seq_id)
          JOIN tpa_enr_policy_group F ON (E.policy_seq_id = F.policy_seq_id)
          LEFT OUTER JOIN tpa_ins_assoc_off_product H ON (A.ins_seq_id = H.ins_seq_id AND A.product_seq_id = H.product_seq_id )
          LEFT OUTER JOIN tpa_group_registration I ON(E.group_reg_seq_id = I.group_reg_seq_id)
          LEFT OUTER JOIN tpa_enr_endorsements J ON (J.endorsement_seq_id = A.endorsement_seq_id)
          WHERE ' || v_where || '
          AND F.deleted_yn = ''N''
          AND H.enrol_type_id = :v_enrol_type
          AND A.enrol_type_id = :v_enrol_type
          AND E.policy_issue_date >= H.valid_from
          AND E.effective_to_date <= NVL( H.valid_to,E.effective_to_date )
          AND F.deleted_yn = ''N''
          GROUP BY  D.office_code, B.abbrevation_code, C.enrol_description, B.ins_comp_code_number ,
                   E.policy_number, E.policy_issue_date, A.sum_insured, A.net_premium, A.commision_to_tpa, F.deleted_yn,
                   E.effective_from_date,E.effective_to_date,H.commission_to_tpa,A.net_premium,i.group_name,i.group_id ,J.cust_endorsement_number ,
                   J.endorsement_number, TO_CHAR(J.received_date,''dd/mm/yyyy'') , TO_CHAR(J.effective_date,''dd/mm/yyyy'') ';
    END IF;

    --confirming all selected policies are get invoiced

    v_rows_processed := str_tab.COUNT;
    --insert as a batch record.
    INSERT INTO tpa_inv_batch
      (batch_seq_id,
       batch_date,
       no_of_transations,
       batch_name,
       added_date,
       added_by)
    VALUES
      (inv_batch_seq.NEXTVAL,
       SYSDATE,
       v_rows_processed,
       v_batch_name,
       SYSDATE,
       v_added_by)
    RETURNING batch_seq_id INTO v_batch_seq_id;

    --updating these records already invoiced to the batch.
    FORALL i IN str_tab.FIRST .. str_tab.LAST
      UPDATE tpa_fin_policy_details a
         SET a.inv_flag = 'Y', a.batch_seq_id = v_batch_seq_id
       WHERE A.fin_policy_seq_id = TO_NUMBER(str_tab(i));

    IF str_tab.FIRST IS NOT NULL AND str_tab.COUNT <= 8 THEN
      CASE str_tab.COUNT
        WHEN 1 THEN
          OPEN v_resultset FOR v_sql_str
            USING v_batch_name, str_tab(1), v_enrol_type, v_enrol_type;
        WHEN 2 THEN
          OPEN v_resultset FOR v_sql_str
            USING v_batch_name, str_tab(1), str_tab(2), v_enrol_type, v_enrol_type;
        WHEN 3 THEN
          OPEN v_resultset FOR v_sql_str
            USING v_batch_name, str_tab(1), str_tab(2), str_tab(3), v_enrol_type, v_enrol_type;
        WHEN 4 THEN
          OPEN v_resultset FOR v_sql_str
            USING v_batch_name, str_tab(1), str_tab(2), str_tab(3), str_tab(4), v_enrol_type, v_enrol_type;
        WHEN 5 THEN
          OPEN v_resultset FOR v_sql_str
            USING v_batch_name, str_tab(1), str_tab(2), str_tab(3), str_tab(4), str_tab(5), v_enrol_type, v_enrol_type;
        WHEN 6 THEN
          OPEN v_resultset FOR v_sql_str
            USING v_batch_name, str_tab(1), str_tab(2), str_tab(3), str_tab(4), str_tab(5), str_tab(6), v_enrol_type, v_enrol_type;
        WHEN 7 THEN
          OPEN v_resultset FOR v_sql_str
            USING v_batch_name, str_tab(1), str_tab(2), str_tab(3), str_tab(4), str_tab(5), str_tab(6), str_tab(7), v_enrol_type, v_enrol_type;
        WHEN 8 THEN
          OPEN v_resultset FOR v_sql_str
            USING v_batch_name, str_tab(1), str_tab(2), str_tab(3), str_tab(4), str_tab(5), str_tab(6), str_tab(7), str_tab(8), v_enrol_type, v_enrol_type;
      END CASE;
    ELSE
      OPEN v_resultset FOR v_sql_str
        USING v_batch_name, v_enrol_type, v_enrol_type;
    END IF;
    COMMIT;
  END generate_ind_invoice_list;
  --====================================================================================================================================================
  --this procedure is used to batch view already generated.
  PROCEDURE view_inv_batch(v_batch_name IN VARCHAR2,
                           v_from_date  IN VARCHAR2,
                           v_to_date    IN VARCHAR2,
                           v_added_by   IN NUMBER,
                           v_invoice_number IN VARCHAR2,
                           v_group_id   IN VARCHAR2,
                           v_group_name IN VARCHAR2,
                           v_policy_num IN VARCHAR2,
                           v_inv_cred   IN VARCHAR2,
                           v_sort_var   IN VARCHAR2,
                           v_sort_order IN VARCHAR2,
                           v_start_num  IN NUMBER,
                           v_end_num    IN NUMBER,
                           result_set   OUT SYS_REFCURSOR) IS
    v_batch_from_date DATE := to_date(v_from_date, 'DD/MM/YYYY');
    v_batch_to_date   DATE := to_date(v_to_date, 'DD/MM/YYYY');
    v_sql_str         VARCHAR2(4000);
    TYPE bind_tab_type IS TABLE OF VARCHAR2(250) INDEX BY BINARY_INTEGER;
    bind_tab         bind_tab_type;
    i                NUMBER(2) := 0;
    v_where          VARCHAR2(4000);
  BEGIN
    
  
    
   v_sql_str := 'SELECT batch_seq_id,I.group_reg_seq_id,R.GROUP_ID,R.GROUP_NAME,batch_date,no_of_policies,batch_name,
                         INVOICE_NUMBER,INV_NO_PERIOD_1,INV_NO_PERIOD_2,
                         INV_NO_PERIOD_3,INV_NO_PERIOD_4, policy_number
                  FROM
                  (SELECT A.batch_seq_id,
                          I.group_reg_seq_id,
                          A.batch_date,
                          A.no_of_transations AS no_of_policies,
                          A.batch_name,
                          I.INVOICE_NUMBER,
                          I.INV_NO_PERIOD_1,
                          I.INV_NO_PERIOD_2,
                          I.INV_NO_PERIOD_3,
                          I.INV_NO_PERIOD_4,
                          pol.policy_number
                          FROM tpa_inv_batch A
                          LEFT OUTER JOIN TPA_FIN_INVOICE I ON (A.INVOICE_SEQ_ID=I.INVOICE_SEQ_ID)
                          LEFT OUTER JOIN TPA_ENR_POLICY POL ON(POL.POLICY_SEQ_ID= I.POLICY_SEQ_ID)
                  UNION ALL 
                  SELECT A.batch_seq_id,
                         I.group_reg_seq_id,
                          A.batch_date,
                          A.no_of_transations AS no_of_policies,
                          A.BATCH_NAME_PDF AS batch_name,
                          I.INVOICE_NUMBER,
                          I.INV_NO_PERIOD_1,
                          I.INV_NO_PERIOD_2,
                          I.INV_NO_PERIOD_3,
                          I.INV_NO_PERIOD_4,
                          pol.policy_number
                          FROM tpa_inv_batch A
                          LEFT OUTER JOIN TPA_FIN_INVOICE I ON (A.INVOICE_SEQ_ID=I.INVOICE_SEQ_ID)
                          LEFT OUTER JOIN TPA_ENR_POLICY POL ON(POL.POLICY_SEQ_ID= I.POLICY_SEQ_ID)
                          ) I
                 JOIN APP.TPA_GROUP_REGISTRATION R ON (I.GROUP_REG_SEQ_ID=R.GROUP_REG_SEQ_ID) ';
                
         IF v_inv_cred ='INV' THEN
           v_sql_str := 'SELECT * FROM ('||v_sql_str||' WHERE INVOICE_NUMBER LIKE ''INV%'')';
         ELSIF v_inv_cred ='CN'  THEN
           v_sql_str := 'SELECT * FROM ('||v_sql_str||'  WHERE INVOICE_NUMBER LIKE ''CN%'')';
         END IF;
         
      
    IF (v_batch_name) IS NOT NULL THEN
      v_where := v_where ||
                   ' AND batch_name = :v_batch_name ';
      i := i + 1;
      bind_tab(i) := v_batch_name ;
    END IF;
    
    IF (v_batch_from_date) IS NOT NULL THEN
      v_where := v_where ||
                   ' AND TRUNC( batch_date  ) >= :v_batch_from_date ';
      i := i + 1;
      bind_tab(i) := v_batch_from_date ;
    END IF;
    
    IF (v_batch_to_date) IS NOT NULL THEN
      v_where := v_where ||
                   ' AND TRUNC(batch_date)  <= :v_batch_to_date ';
      i := i + 1;
      bind_tab(i) := v_batch_to_date;
    END IF;
    
    IF (v_invoice_number) IS NOT NULL THEN
      v_where := v_where ||
                   ' AND (INVOICE_NUMBER = :v_invoice_number OR INV_NO_PERIOD_1 = :v_invoice_number OR INV_NO_PERIOD_2 = :v_invoice_number OR
                         INV_NO_PERIOD_3 = :v_invoice_number OR INV_NO_PERIOD_4 = :v_invoice_number ) ';
      i := i + 1;
      bind_tab(i) := v_invoice_number ;
      i := i + 1;
      bind_tab(i) := v_invoice_number ;
      i := i + 1;
      bind_tab(i) := v_invoice_number ;
      i := i + 1;
      bind_tab(i) := v_invoice_number ;
      i := i + 1;
      bind_tab(i) := v_invoice_number ;
    END IF;
    
    IF v_group_id IS NOT NULL THEN
      v_where := v_where ||
                   ' AND GROUP_ID = :v_group_id ';
      i := i + 1;
      bind_tab(i) := v_group_id;
    END IF;
    
    IF (v_group_name) IS NOT NULL THEN
      v_where := v_where ||
                   ' AND GROUP_NAME  = :v_group_name ';
      i := i + 1;
      bind_tab(i) := v_group_name;
    END IF;
    
    IF v_policy_num IS NOT NULL THEN
      v_where := v_where ||
                   ' AND POLICY_NUMBER = :v_policy_num ';
      i := i + 1;
      bind_tab(i) := v_policy_num;
    END IF;
    
    IF v_where IS NOT NULL THEN
      v_where   := ' WHERE '|| SUBSTR(v_where,5);
      v_sql_str := v_sql_str ||v_where;
    END IF;
    
    v_sql_str := 'SELECT * FROM
                 (SELECT A.*,DENSE_RANK() OVER (ORDER BY ' ||
                 v_sort_var || ' ' || v_sort_order ||
                 ',ROWNUM)
                  Q FROM (' || v_sql_str ||
                 ') A ) WHERE  Q>= :v_start_num  AND Q<=  :v_end_num ';

         

    IF bind_tab.FIRST IS NOT NULL THEN
      CASE bind_tab.COUNT
        WHEN 1 THEN
          OPEN result_set FOR v_sql_str
            USING bind_tab(1),v_start_num,v_end_num;
        WHEN 2 THEN
          OPEN result_set FOR v_sql_str
            USING bind_tab(1), bind_tab(2),v_start_num,v_end_num;
        WHEN 3 THEN
          OPEN result_set FOR v_sql_str
            USING bind_tab(1), bind_tab(2), bind_tab(3),v_start_num,v_end_num;
        WHEN 4 THEN
          OPEN result_set FOR v_sql_str
            USING bind_tab(1), bind_tab(2), bind_tab(3), bind_tab(4),v_start_num,v_end_num;
        WHEN 5 THEN
          OPEN result_set FOR v_sql_str
            USING bind_tab(1), bind_tab(2), bind_tab(3), bind_tab(4), bind_tab(5),v_start_num,v_end_num;
        WHEN 6 THEN
          OPEN result_set FOR v_sql_str
            USING bind_tab(1), bind_tab(2), bind_tab(3), bind_tab(4), bind_tab(5),bind_tab(6),v_start_num,v_end_num;
        WHEN 7 THEN
          OPEN result_set FOR v_sql_str
            USING bind_tab(1), bind_tab(2), bind_tab(3), bind_tab(4), bind_tab(5),bind_tab(6),bind_tab(7),v_start_num,v_end_num;
        WHEN 8 THEN
          OPEN result_set FOR v_sql_str
            USING bind_tab(1), bind_tab(2), bind_tab(3), bind_tab(4), bind_tab(5),bind_tab(6),bind_tab(7),bind_tab(8),v_start_num,v_end_num;
        WHEN 9 THEN
          OPEN result_set FOR v_sql_str
            USING bind_tab(1), bind_tab(2), bind_tab(3), bind_tab(4), bind_tab(5),bind_tab(6),bind_tab(7),bind_tab(8),bind_tab(9),v_start_num,v_end_num;
        WHEN 10 THEN
          OPEN result_set FOR v_sql_str
            USING bind_tab(1), bind_tab(2), bind_tab(3), bind_tab(4), bind_tab(5),bind_tab(6),bind_tab(7),bind_tab(8),bind_tab(9),bind_tab(10),v_start_num,v_end_num;        
        WHEN 11 THEN
          OPEN result_set FOR v_sql_str
            USING bind_tab(1), bind_tab(2), bind_tab(3), bind_tab(4), bind_tab(5),bind_tab(6),bind_tab(7),bind_tab(8),bind_tab(9),bind_tab(10),bind_tab(11),v_start_num,v_end_num; 
      END CASE;
    ELSE
      OPEN result_set FOR v_sql_str USING v_start_num,v_end_num;
    END IF;
    
  END view_inv_batch;
  --======================================================================================================================================
  --the functionality is here check the all input info from procedure against database.
  --if it is holds true in all case then update the cheque no,cheque date into claims check table.
  --update the claim status to paid ie (sent_to_bank).
  --insert a cheque payment rec into tpa_claims_check.
  --insert into intermediatory table of respective payment_seq_id.
  PROCEDURE payment_advice_upload(v_cheque_number  IN tpa_claims_check.check_num%TYPE,
                                  v_cheque_amt     IN tpa_claims_check.check_amount%TYPE,
                                  v_cheque_date    IN tpa_claims_check.check_date%TYPE,
                                  v_batch_number   IN tpa_bank_advice_batch.batch_seq_id%TYPE,
                                  v_claim_settl_no IN tpa_claims_payment.claim_settlement_no%TYPE,
                                  v_payee_name     IN tpa_claims_payment.payee_name%TYPE,
                                  v_added_by       IN NUMBER) IS
    v_status          NUMBER(10);
    v_claim_chk_id    NUMBER(20);
    v_counter         NUMBER(20);
    v_counter1        NUMBER(20);
    v_errmsg          VARCHAR(2000);
    v_errnum          NUMBER(20);
    v_payment_seq_id  Tpa_claims_payment.payment_seq_id%TYPE;
    v_float_seq_id    tpa_claims_payment.float_seq_id%TYPE;
    v_bank_acc_seq_id tpa_float_account.bank_acc_seq_id%TYPE;
    v_ctr             number(10);
    v_ins_name        tpa_ins_info.ins_comp_name%type; ---koc_ins_mail
    v_notify_tipe_id  tpa_ins_info.notify_type_id%type; ---koc_ins_mail
    v_msg_str         VARCHAR2(1000); ---koc_ins_mail
    v_clm_type        varchar2(5); ---koc_ins_mail
    v_remarks           VARCHAR2(4000);
     
    
     Cursor Settelment_number_Info Is
     SELECT a.claim_payment_status,a.approved_amount,a.payee_type,a.bank_advice_batch,a.payment_seq_id,a.float_seq_id 
     FROM tpa_claims_payment a     
     WHERE a.claim_settlement_no= v_claim_settl_no;
      
    Settelment_number_Rec Settelment_number_Info%ROWTYPE;  
    
  BEGIN
    --validate it
    IF (v_claim_settl_no IS NOT NULL AND v_batch_number IS NOT NULL AND  v_payee_name IS NOT NULL AND v_cheque_amt IS NOT NULL AND v_cheque_date IS NOT NULL) THEN
     
      ---Added Newly For error log Modification
     open Settelment_number_Info;
       fetch Settelment_number_Info into Settelment_number_rec;
         close Settelment_number_Info;
   
      IF Settelment_number_rec.Claim_Payment_Status='SENT_TO_BANK' and Settelment_number_rec.Approved_Amount=v_cheque_amt and Settelment_number_rec.Payee_Type='PCA' AND Settelment_number_rec.Bank_Advice_Batch=v_batch_number THEN
        -- to check is cheque date after claim settled date. If not pop error.
        SELECT COUNT(1)
          INTO v_counter
          FROM tpa_claims_payment
         WHERE payment_seq_id = Settelment_number_rec.Payment_Seq_Id
           AND TRUNC(claim_aprv_date) > v_cheque_date;
        IF (v_counter > 0) THEN
          INSERT INTO TPA_PAYMENT_ADVICE_ERROR_LOG
            (payment_log_id,
             claim_settlement_no,
             remarks,
             added_by,
             added_date)
          VALUES
            (tpa_payment_adv_error_log_seq.NEXTVAL,
             v_claim_settl_no,
             v_errnum || ' ' || v_errmsg || ' ' ||
             'CHEQUE DATE is LESS than SETTLED DATE.',
             v_added_by,
             SYSDATE);
          COMMIT;
          RAISE_APPLICATION_ERROR(-20252,
                                  'CHEQUE DATE is LESS than SETTLED DATE');
        END IF;
        --getting bank_acc_number to check the cheque number issued to the bank_account.
        SELECT a.bank_acc_seq_id
          INTO v_bank_acc_seq_id
          FROM tpa_float_account a
         WHERE a.float_seq_id = Settelment_number_rec.float_seq_id;
        --checking the cheque number issued to this account_number else display error

        --this query gives info abt the check number is already issued or not.
        FLOAT_ACCOUNTS_PKG.cheque_nos_issued_yn(v_bank_acc_seq_id,
                                                v_cheque_number,
                                                v_counter1);
        IF (v_counter1 >= 1) THEN
          -- Following statement is to allow upload if cheque is re-issued.
          SELECT COUNT(1)
            INTO v_counter1
            FROM tpa_claims_payment p
            JOIN tpa_payment_checks_details pc
              ON p.payment_seq_id = pc.payment_seq_id
            JOIN tpa_claims_check cc
              ON pc.claims_chk_seq_id = cc.claims_chk_seq_id
            JOIN tpa_float_account f
              on p.float_seq_id = f.float_seq_id
           WHERE cc.check_num = v_cheque_number
             AND cc.check_status = 'CSR'
             AND f.BANK_ACC_SEQ_ID = v_bank_acc_seq_id;
          IF v_counter1 = 0 THEN
            -- Following statement is to allow upload if cheque is a consolidated one.
            WITH prev_pymt AS
             (SELECT DISTINCT p.group_reg_seq_id,
                              p.hosp_seq_id,
                              p.tpa_cheque_issued_general_type,
                              p.tpa_nhcp_cheques_issued_to
                FROM tpa_claims_payment p
                JOIN tpa_payment_checks_details pc
                  ON p.payment_seq_id = pc.payment_seq_id
                JOIN tpa_claims_check cc
                  ON pc.claims_chk_seq_id = cc.claims_chk_seq_id
               WHERE cc.check_num = v_cheque_number
                 AND p.bank_advice_batch = v_batch_number)
            SELECT COUNT(1)
              INTO v_counter1
              FROM tpa_claims_payment a
              JOIN prev_pymt b
                ON (a.group_reg_seq_id = b.group_reg_seq_id AND
                   a.tpa_cheque_issued_general_type IN ('IQC', 'IQL','IQI') AND
                   b.tpa_cheque_issued_general_type IN ('IQC', 'IQL','IQI'))
                OR (a.hosp_seq_id = b.hosp_seq_id AND
                   a.tpa_nhcp_cheques_issued_to =
                   b.tpa_nhcp_cheques_issued_to AND
                   a.tpa_nhcp_cheques_issued_to = 'HOS')
             WHERE a.payment_seq_id = Settelment_number_rec.Payment_Seq_Id
               AND a.bank_advice_batch = v_batch_number;
          END IF;
          IF v_counter1 = 0 THEN
            RAISE_APPLICATION_ERROR(-20213,
                                    'cannot issue same cheque to the same bank account');
          END IF;
        END IF;

        --insert the cheques table
        -- kocdup
        select count(1)
          into v_ctr
          from fin_app.tpa_payment_checks_details
         where payment_seq_id = Settelment_number_rec.Payment_Seq_Id;

        if v_ctr > 0 then
          for jk in (select claims_chk_seq_id
                       from fin_app.tpa_payment_checks_details
                      where payment_seq_id = Settelment_number_rec.Payment_Seq_Id) loop
            update tpa_payment_checks_details
               set v_csr_flag = 0
             where payment_seq_id = Settelment_number_rec.Payment_Seq_Id
               and claims_chk_seq_id = jk.claims_chk_seq_id
            returning claims_chk_seq_id INTO v_claim_chk_id;

            update tpa_claims_check
               set v_csr_flag = 0,
                   check_num=v_cheque_number
             where claims_chk_seq_id = v_claim_chk_id;
          end loop;
        end if;
        -- kocdup

        --update the claim status to payments table
        UPDATE tpa_claims_payment
           SET claim_payment_status = 'PAID',
                --payee_type = 'PCA',
                updated_date = sysdate
         WHERE payment_seq_id = Settelment_number_rec.Payment_Seq_Id;
       
        GENERATE_MAIL_PKG.proc_form_message('FINANCE_PAYMENT_PAD',
                                            Settelment_number_rec.Payment_Seq_Id,
                                            v_added_by,
                                            v_dest_msg_seq_id); --Added for CR - KOC1025
        --END IF;--koc_ins_mail
      ELSIF v_claim_settl_no IS NOT NULL AND v_batch_number IS NOT NULL AND v_payee_name IS NOT NULL AND v_cheque_amt IS NOT NULL THEN
        --create table to store error message for the respective payment id.
        --using sqlerrm,sqlcode of oracle.
        v_errmsg := SQLERRM;
        v_errnum := SQLCODE;
        
        IF Settelment_number_Rec.Claim_Payment_Status IS NULL THEN
          v_remarks:= ' Given Settlement Number is not valid ';         
        END IF;
        
        IF Settelment_number_Rec.Claim_Payment_Status!='SENT_TO_BANK'  THEN
          v_remarks:= ' The Claims which are SENT_TO_BANK will be processed for Payment .The current status is :'||Settelment_number_Rec.Claim_Payment_Status;         
        END IF;
        
        IF Settelment_number_Rec.Approved_Amount !=v_cheque_amt  THEN
          v_remarks:=v_remarks||' ; '||'Mismatch in cheque amount';
        END IF;
        
        IF Settelment_number_Rec.Payee_Type!='PCA' THEN
          v_remarks:=v_remarks||' ; '||'Mismatch in Payment Method ';
        END IF;
        
        IF Settelment_number_Rec.Bank_Advice_Batch!=v_batch_number THEN
           v_remarks:=v_remarks||' ; '||'Mismatch in Batch Number ';
        END IF;
        
        IF v_errmsg IS NOT NULL AND v_errnum IS NOT NULL AND v_errnum!=0 THEN
          v_remarks:=v_remarks||' ; '||v_errmsg;
        END IF;
        
        INSERT INTO TPA_PAYMENT_ADVICE_ERROR_LOG
          (payment_log_id,
           claim_settlement_no,
           remarks,
           added_by,
           added_date)
        VALUES
          (tpa_payment_adv_error_log_seq.NEXTVAL,
           v_claim_settl_no,
           v_remarks,
           v_added_by,
           SYSDATE);
        COMMIT;
        RAISE_APPLICATION_ERROR(-20253,
                                v_remarks);
      END IF; --end if of v_status error log data
    ELSIF v_claim_settl_no IS NULL OR v_batch_number IS NULL OR v_payee_name IS NULL OR v_cheque_amt IS NULL  OR v_cheque_date IS NULL THEN
      
      IF v_claim_settl_no IS NULL THEN
       v_remarks:=v_remarks ||'Claim Settlement Number cannot be Blank';
      END IF;
     
     IF v_batch_number IS NULL THEN
       v_remarks:=v_remarks ||'Batch Number cannot be Blank';
     END IF; 
     
     IF v_payee_name IS NULL THEN
       v_remarks:=v_remarks ||'payee name cannot be Blank';
     END IF;
     
     IF v_cheque_amt IS NULL THEN
       v_remarks:=v_remarks ||'Cheque Amount cannot be Blank';
     END IF; 
     
     IF v_cheque_number IS NULL THEN
       v_remarks:=v_remarks ||'Cheque Number cannot be Blank';
     END IF;
     
     IF v_cheque_date IS NULL THEN
       v_remarks:=v_remarks ||'Cheque Date cannot be Blank';
     END IF;
     
     
      RAISE_APPLICATION_ERROR(-20247, v_remarks);
    END IF; --end if for excel data is null
    COMMIT;
  END payment_advice_upload;
--======================================================================================================================================
/*Author:      Prasanna Kumar R J, SPAN Infotech.
  Description: This procedure extracts data from an XML input and calls payment_advice_upload
               to update, and complete, payment advice transaction.
*/
  PROCEDURE upload_payment_advice (
                                    v_payment_advice_doc  IN   CLOB,
                                    v_log_file            OUT  CLOB,
                                    v_sys_ref             OUT SYS_REFCURSOR
                                  )
  IS
    v_doc                      DBMS_XMLDOM.DOMDocument;
    v_ndoc                     DBMS_XMLDOM.DOMNode;
    v_root_node                DBMS_XMLDOM.DOMNode;
    v_node_parent              DBMS_XMLDOM.DOMNode;
    v_parent_node_list         dbms_xmldom.DOMNodeList;
    v_attrs                    dbms_xmldom.domnamednodemap;
    v_attrs_node               DBMS_XMLDOM.DOMNode;
    v_child_node_list          DBMS_XMLDOM.DOMNodeList;
    v_child_node               DBMS_XMLDOM.DOMNode;
    v_finance_xml              xmltype;
    v_check_num                tpa_claims_check.check_num%TYPE;
    v_check_amount             tpa_claims_check.check_amount%TYPE;
    v_check_date               tpa_claims_check.check_date%TYPE;
    v_batch_seq_id             tpa_claims_payment.bank_advice_batch%TYPE;
    v_claim_settlement_no      tpa_claims_payment.claim_settlement_no%TYPE;
    v_payee_name               tpa_claims_payment.payee_name%TYPE;
    v_added_by                 tpa_claims_check.added_by%TYPE;
-- The following vairables are used for EFT Upload.
    v_enrollmentid             tpa_enr_policy_member.tpa_enrollment_id%TYPE;
    v_empbankname              VARCHAR2(100);
    v_empbankbranch            VARCHAR2(100);
    v_empacctno                VARCHAR2(100);
    v_empemail                 VARCHAR2(100);
    v_flag                     VARCHAR2(3);
    v_fin_log_seq_id           NUMBER;
    v varchar2(100);
    v_elem                     DBMS_XMLDOM.DOMElement;
    l_text_content             VARCHAR2(32767);
    l_length                   NUMBER;
	v_batchnumber              VARCHAR2(500);

    cursor fin_logs (v_batchnumber VARCHAR2)is 
     select * from FINANCE_LOGS 
     where batch_number = v_batchnumber ;

	 v_text    clob;


  BEGIN
    v_finance_xml      := XMLTYPE.createXML(v_payment_advice_doc);
    v_doc              := DBMS_XMLDOM.newDOMDocument(v_finance_xml);
    v_ndoc             := DBMS_XMLDOM.makeNode(v_doc);
    v_root_node        := DBMS_XMLDOM.getFirstChild(v_ndoc);
    v                  := DBMS_XMLDOM.getNodeValue(DBMS_XMLDOM.getFirstChild(v_ndoc)); -- GETTING THE ROOT NODE ie. batch
    v_parent_node_list := dbms_xmldom.getChildNodes(v_root_node); -- GET all the nodes in BATCH
    FOR pi IN 0 .. dbms_xmldom.getLength(v_parent_node_list) - 1 LOOP
      v_node_parent := DBMS_XMLDOM.item(v_parent_node_list, pi);
      IF dbms_xmldom.getNodeNAME(v_node_parent) = 'policy' THEN
        v_elem            := dbms_xmldom.makeelement(v_node_parent);
        v_child_node_list := dbms_xmldom.getelementsbytagname(v_elem,
                                                              'payments');
        FOR ci IN 0 .. dbms_xmldom.getLength(v_child_node_list) - 1 LOOP
          v_child_node   := DBMS_XMLDOM.item(v_child_node_list, ci);
          l_text_content := l_text_content ||
                            DBMS_XMLDOM.GetNodeValue(v_child_node);
          BEGIN
            IF dbms_xmldom.getNodeNAME(v_child_node) = 'payments' THEN
              v_attrs := DBMS_XMLDOM.getAttributes(v_child_node);
              FOR curr_attr IN 0 .. dbms_xmldom.getlength(v_attrs) - 1 LOOP
                v_attrs_node := dbms_xmldom.ITEM(v_attrs, curr_attr);
                CASE dbms_xmldom.getNodeNAME(v_attrs_node)
                  WHEN 'settlementnumber' THEN
                    v_claim_settlement_no := dbms_xmldom.getnodevalue(v_attrs_node);
                  WHEN 'chequeno' THEN
                    v_check_num := dbms_xmldom.getnodevalue(v_attrs_node);
                  WHEN 'chequedate' THEN
                    v_check_date := TO_DATE(dbms_xmldom.getnodevalue(v_attrs_node),
                                            'dd/mm/yyyy');
                  WHEN 'chequeamt' THEN
                    v_check_amount := dbms_xmldom.getnodevalue(v_attrs_node);
                  WHEN 'batchnumber' THEN
                    v_batch_seq_id := dbms_xmldom.getnodevalue(v_attrs_node);
                  WHEN 'payeename' THEN
                    v_payee_name := dbms_xmldom.getnodevalue(v_attrs_node);
                  WHEN 'empbankname' THEN
                    v_empbankname := dbms_xmldom.getnodevalue(v_attrs_node);
                  WHEN 'empbankbranch' THEN
                    v_empbankbranch := dbms_xmldom.getnodevalue(v_attrs_node);
                  WHEN 'empaccountnumber' THEN
                    v_empacctno := dbms_xmldom.getnodevalue(v_attrs_node);
                  WHEN 'empemailid' THEN
                    v_empemail := dbms_xmldom.getnodevalue(v_attrs_node);
                  ELSE
                    NULL;
                END CASE;
              END LOOP;
              IF v_flag = 'BNK' THEN
                -- UPLOAD Payment advice.
                FLOAT_ACCOUNTS_PKG.payment_advice_upload(v_check_num,
                                                         v_check_amount,
                                                         v_check_date,
                                                         v_batch_seq_id,
                                                         v_claim_settlement_no,
                                                         v_payee_name,
                                                         v_Added_by);
              ELSIF v_flag = 'EFT' THEN
                -- UPDATE EFT payment details

                EFT_payment_advice_upload(v_check_num,
                                          v_check_amount,
                                          v_check_date,
                                          v_batch_seq_id,
                                          v_claim_settlement_no,
                                          v_empacctno,
                                          v_empbankname,
                                          v_empbankbranch,
                                          v_payee_name,
                                          v_added_by); --added for koc1103

                /*UPDATE tpa_claims_payment--removed for koc1103
                SET payee_name      = v_payee_name,
                    emp_bank_name   = v_empbankname,
                    emp_bank_branch = v_empbankbranch,
                    emp_acct_number = v_empacctno,
                    emp_email       = v_empemail
                WHERE claim_settlement_no = v_claim_settlement_no
                  AND claim_seq_id IS NOT NULL;*/
              END IF;
            END IF;
            save_finance_logs(v_fin_log_seq_id,
                              v_batch_seq_id,
                              sqlcode,
                              sqlerrm,
                              'FIN',
                              v_flag,
                              v_claim_settlement_no,
                              null,
                              null,
                              null,
                              null,
					v_batchnumber,
                              1);
          exception
            when others then
              save_finance_logs(v_fin_log_seq_id,
                                v_batch_seq_id,
                                sqlcode,
                                sqlerrm,
                                'FIN',
                                v_flag,
                                v_claim_settlement_no,
                                null,
                                null,
                                null,
                                null,
					v_batchnumber,
                                1);
          END;
        END LOOP;
      ELSIF dbms_xmldom.getNodeNAME(v_node_parent) = 'filedetail' THEN
        v_attrs := DBMS_XMLDOM.getAttributes(v_node_parent);
        FOR curr_attr IN 0 .. dbms_xmldom.getlength(v_attrs) - 1 LOOP
          v_attrs_node := dbms_xmldom.ITEM(v_attrs, curr_attr);
          CASE dbms_xmldom.getNodeNAME(v_attrs_node)
		   WHEN 'batchnumber' THEN
             v_batchnumber := dbms_xmldom.getnodevalue(v_attrs_node);
            WHEN 'uploadedby' THEN
              v_added_by := dbms_xmldom.getnodevalue(v_attrs_node);
            WHEN 'insuranceabbrev' THEN
              v_flag := dbms_xmldom.getnodevalue(v_attrs_node);
            ELSE
              NULL;
          END CASE;
        END LOOP;
      END IF;
    END LOOP;
    dbms_xmldom.freeDocument(v_doc);
    for i in fin_logs(v_batchnumber) loop
      v_log_file := v_log_file || ' ' || 'Claim Settlement No :' ||
                    i.claim_settlement_no || ' ' ||
                    substr(i.error_message, 11) || chr(13);
    end loop;
    
    OPEN v_sys_ref for select 1 as failed_count from dual;
    COMMIT;
  END upload_payment_advice;
  /*==============================================================================================
    Name       : EFT_payment_advice_upload
    Created on :
    Created By : Ibrahim Sayyed
    Company    : RCS Technologies
    Added for  : KOC1105
    Comments   : This procedure is used to  upload the transaction details for EFT payments
  ============================================================================================== */
  PROCEDURE EFT_payment_advice_upload( --ADDED FOR KOC1103
                                      v_tran_num        IN tpa_claims_check.check_num%TYPE,
                                      v_tran_amt        IN tpa_claims_check.check_amount%TYPE,
                                      v_tran_date       IN tpa_claims_check.check_date%TYPE,
                                      v_batch_number    IN tpa_bank_advice_batch.batch_seq_id%TYPE,
                                      v_claim_settl_no  IN tpa_claims_payment.claim_settlement_no%TYPE,
                                      v_emp_acct_number IN tpa_claims_payment.emp_acct_number%TYPE,
                                      v_emp_bank_name   IN tpa_claims_payment.claim_settlement_no%TYPE,
                                      v_emp_bank_branch IN tpa_claims_payment.emp_bank_branch%TYPE,
                                      v_payee_name      IN tpa_claims_payment.payee_name%TYPE,
                                      v_added_by        IN NUMBER) IS
    v_status            NUMBER(10);
    v_counter           NUMBER(10);
    v_float_seq_id      tpa_claims_payment.float_seq_id%TYPE;
    v_errmsg            VARCHAR(2000);
    v_errnum            NUMBER(20);
    v_claims_chk_seq_id tpa_claims_check.claims_chk_seq_id%TYPE;
    v_remarks           VARCHAR2(4000);

  Cursor Settelment_number_Info Is
     SELECT a.claim_payment_status,a.approved_amount,a.payee_type,a.bank_advice_batch,a.payment_seq_id 
     FROM tpa_claims_payment a     
     WHERE a.claim_settlement_no= v_claim_settl_no;
      
  Settelment_number_Rec Settelment_number_Info%ROWTYPE;      
  BEGIN

    IF v_claim_settl_no IS NOT NULL AND v_payee_name IS NOT NULL AND v_tran_amt IS NOT NULL and v_batch_number IS NOT NULL and v_tran_date IS NOT NULL THEN
      
      OPEN Settelment_number_Info;
        FETCH Settelment_number_Info INTO Settelment_number_Rec;
          CLOSE Settelment_number_Info;
  
     IF Settelment_number_Rec.Claim_Payment_Status='SENT_TO_BANK' AND Settelment_number_Rec.Payee_Type='EFT' AND Settelment_number_Rec.Approved_Amount = v_tran_amt AND  Settelment_number_Rec.Bank_Advice_Batch=v_batch_number THEN
        SELECT COUNT(1)
          INTO v_counter
          FROM tpa_claims_payment
         WHERE payment_seq_id = Settelment_number_Rec.Payment_Seq_Id
           AND TRUNC(claim_aprv_date) > v_tran_date;
        IF v_counter > 0 THEN
          INSERT INTO TPA_PAYMENT_ADVICE_ERROR_LOG
            (payment_log_id,
             claim_settlement_no,
             remarks,
             added_by,
             added_date)
          VALUES
            (tpa_payment_adv_error_log_seq.NEXTVAL,
             v_claim_settl_no,
             v_errnum || ' ' || v_errmsg || ' ' ||
             'CHEQUE DATE is LESS than SETTLED DATE.',
             v_added_by,
             SYSDATE);
          COMMIT;
          RAISE_APPLICATION_ERROR(-20252,
                                  'CHEQUE DATE is LESS than SETTLED DATE');
        END IF;
        SELECT claims_chk_seq_id
          INTO v_claims_chk_seq_id
          FROM tpa_payment_checks_details
         where payment_seq_id = Settelment_number_Rec.Payment_Seq_Id
           and v_csr_flag = 1;
        UPDATE tpa_claims_check
           SET check_num    = v_tran_num,
               check_date   = v_tran_date,
               check_status = 'CSI', --koc1175
               check_amount = v_tran_amt,
               UPDATED_BY   = v_added_by,
               updated_date = sysdate
         where claims_chk_seq_id = v_claims_chk_seq_id;
        UPDATE tpa_claims_payment
           SET claim_payment_status = 'PAID',
              -- payee_name           = v_payee_name, there is no validation on payee name directly we are updating
                                                      --what ever they will give from xls file (Confirmed by manju sir)--venu babu
               emp_bank_name        = v_emp_bank_name,
               emp_bank_branch      = v_emp_bank_branch,
               emp_acct_number      = v_emp_acct_number,
               updated_date         = sysdate
         WHERE claim_settlement_no = v_claim_settl_no
           AND claim_seq_id IS NOT NULL;

        --koc_ins_mail
        /*    IF v_ins_name LIKE 'CIGNA%' AND v_notify_tipe_id='NIC' and v_clm_type='CTM' THEN
           for msg_str in (SELECT grp.ins_seq_id,ins.ins_comp_name,grp.msg_id,ins.notify_type_id FROM clm_enroll_details B
           JOIN clm_general_details C ON (B.CLAIM_SEQ_ID = C.CLAIM_SEQ_ID)
           JOIN TPA_CLAIMS_PAYMENT CP ON(CP.CLAIM_SEQ_ID=C.CLAIM_SEQ_ID)
           JOIN tpa_ins_info ins on (ins.ins_seq_id = b.ins_seq_id)
           JOIN app.source_message_custom_grp grp on (grp.ins_seq_id=b.ins_seq_id)
           WHERE CP.PAYMENT_SEQ_ID = v_payment_seq_id) loop

            v_msg_str := v_msg_str||','||msg_str.msg_id;
            v_notify_tipe_id := msg_str.notify_type_id;

          end loop;
           if (v_msg_str) like '%CIGNA_CLM_SETTLE_EMAIL_PO%' and v_notify_tipe_id = 'NIC' then
           GENERATE_MAIL_PKG.proc_generate_message_cigna('CIGNA_CLM_SETTLE_EMAIL_PO',v_payment_seq_id,v_added_by,v_dest_msg_seq_id);  --koc_ins_mail
           end if;
           if (v_msg_str) like '%CIGNA_CLM_SETTLE_EMAIL_AD%' and v_notify_tipe_id = 'NIC' then
           GENERATE_MAIL_PKG.proc_generate_message_cigna('CIGNA_CLM_SETTLE_EMAIL_AD',v_payment_seq_id,v_added_by,v_dest_msg_seq_id);  --koc_ins_mail
           end if;
        ELSE*/

        /*GENERATE_MAIL_PKG.proc_form_message('FINANCE_PAYMENT_EFT',
                                            v_payment_seq_id,
                                            v_added_by,
                                            v_dest_msg_seq_id); --koc1175
        
        
        open clm_sts_cur;
        fetch clm_sts_cur into v_nwt_type;
        close clm_sts_cur;
        
        IF v_nwt_type = 'CTM' THEN
          GENERATE_MAIL_PKG.proc_form_message('FINANCE_PAYMENT_EFT_MR',
                                              v_payment_seq_id,
                                              v_added_by,
                                              v_dest_msg_seq_id);
        END IF;*/
        --END IF;--koc_ins_mail

     ELSIF v_claim_settl_no IS NOT NULL OR v_payee_name IS NOT NULL OR v_tran_amt IS NOT NULL  THEN
        --create table to store error message for the respective payment id.
        --using sqlerrm,sqlcode of oracle.
        v_errmsg := SQLERRM;
        v_errnum := SQLCODE;
        
          IF Settelment_number_Rec.Claim_Payment_Status is null  THEN
           v_remarks:= 'This Settlement Number  is not valid';         
          END IF;
          
          IF Settelment_number_Rec.Claim_Payment_Status!='SENT_TO_BANK'  THEN
           v_remarks:= 'This Settlement  Number status is :'||Settelment_number_Rec.Claim_Payment_Status;         
          END IF;
        
          IF Settelment_number_Rec.Approved_Amount != v_tran_amt THEN
            v_remarks:=v_remarks||' ; '||'Mismatch in cheque amount';
          END IF;
        
          IF Settelment_number_Rec.Payee_Type!='EFT' THEN
            v_remarks:=v_remarks||' ; '||'Mismatch in Payment Method ';
          END IF;
          
          IF Settelment_number_Rec.Bank_Advice_Batch!=v_batch_number THEN
            v_remarks:=v_remarks||' ; '||'Mismatch in Batch Number ';
          END IF;
        
          IF v_errmsg IS NOT NULL AND v_errnum IS NOT NULL AND v_errnum!='0' THEN
            v_remarks:=v_remarks||' ; '||v_errmsg;
          END IF;
        
        INSERT INTO TPA_PAYMENT_ADVICE_ERROR_LOG
          (payment_log_id,
           claim_settlement_no,
           remarks,
           added_by,
           added_date)
        VALUES
          (tpa_payment_adv_error_log_seq.NEXTVAL,
           v_claim_settl_no,
           v_remarks,
           v_added_by,
           SYSDATE);
        COMMIT;
        RAISE_APPLICATION_ERROR(-20253, v_remarks);
                               
      END IF; --end if of v_status error log data
   
    ELSIF v_claim_settl_no IS NULL OR v_payee_name IS NULL OR v_tran_amt IS NULL OR v_batch_number IS NULL OR v_tran_date IS NULL THEN
     
     IF v_claim_settl_no IS NULL THEN
       v_remarks:=v_remarks ||'Claim Settlement Number cannot be Blank';
     END IF;
     
     IF v_batch_number IS NULL THEN
       v_remarks:=v_remarks ||'Batch Number cannot be Blank';
     END IF; 
     
     IF v_payee_name IS NULL THEN
       v_remarks:=v_remarks ||'payee name cannot be Blank';
     END IF;
     
     IF v_tran_amt IS NULL THEN
       v_remarks:=v_remarks ||'Cheque Amount cannot be Blank';
     END IF; 
     
     IF v_tran_num  IS NULL THEN
      v_remarks:=v_remarks ||'Cheque Number cannot be Blank';
     END IF;
     
     IF v_tran_date  IS NULL THEN
       v_remarks:=v_remarks ||'Cheque Date cannot be Blank';
     END IF;
     
      
      RAISE_APPLICATION_ERROR(-20247, v_remarks);
    
    END IF; --end if for excel data is null
    COMMIT;

  END EFT_payment_advice_upload;
  --======================================================================================================================================

  --this procedure will executes daily,it will store data of all float accounts
  --it is using in generating float balance.

  --====================================================================================================
  -- modified by S.V.SREERAJ -- FOR PERFORMANCE
  -- Modified date : 15-03-2008
  PROCEDURE cheque_nos_issued_yn(v_bank_acc_seq_id IN tpa_bank_accounts.bank_acc_seq_id%TYPE,
                                 v_check_num       IN tpa_claims_check.check_num%TYPE,
                                 v_result          OUT NUMBER) IS
    v_ctr NUMBER;

    CURSOR get_float_ids IS
      SELECT COUNT(1)
        FROM tpa_float_account a
        JOIN tpa_claims_payment b
          ON (a.float_seq_id = b.float_seq_id)
        JOIN tpa_payment_checks_details c
          ON (b.payment_seq_id = c.payment_seq_id)
        JOIN tpa_claims_check d
          ON (c.claims_chk_seq_id = d.claims_chk_seq_id)
       WHERE a.bank_acc_seq_id = v_bank_acc_seq_id
         AND b.claim_payment_status = 'PAID'
         AND d.check_num = v_check_num;

  BEGIN
    OPEN get_float_ids;
    FETCH get_float_ids
      INTO v_ctr;
    CLOSE get_float_ids;

    IF v_ctr > 0 THEN
      v_result := 1;
    ELSE
      v_result := 0;
    END IF;

  END cheque_nos_issued_yn;
  --====================================================================================================
  -- modified by S.V.SREERAJ -- FOR PERFORMANCE
  -- Modified date : 15-04-2008
  -- Name modified from print_check to manual_print_check Modified by venu
  PROCEDURE manual_print_check(v_payment_seq_id IN VARCHAR2,
                        v_float_seq_id   IN TPA_FLOAT_ACCOUNT.float_seq_id%TYPE,
                        v_cheque_number  IN tpa_claims_check.check_num%TYPE,
                        v_payment_method IN TPA_CLAIMS_PAYMENT.payee_type%TYPE,
                        v_added_by       IN NUMBER,
                        v_rows_processed OUT INTEGER,
                        v_resultset      OUT SYS_REFCURSOR) IS

    i                 NUMBER(10) := 0;
    p_cheque_number   tpa_claims_check.check_num%TYPE;
    v_count           NUMBER(20) := 0;
    v_batch_number    tpa_batch_master.batch_number%TYPE;
    v_bank_acc_seq_id TPA_BANK_ACCOUNTS.BANK_ACC_SEQ_ID%TYPE;
    v_counter         NUMBER(20);
    v_counter1        NUMBER(20);
    v_flag            NUMBER(20);
    v_chq_seq_id      NUMBER(20);
    v_sum             tpa_float_account.current_balance%TYPE;
    v_approved_amt    tpa_claims_payment.approved_amount%TYPE;
    v_batch_date      tpa_claims_check.check_date%TYPE;
    v_no_of_cheques   NUMBER(20);

    v_counter2 NUMBER(20);

    v_payment_seq_id_list VARCHAR2(32767) := REPLACE(SUBSTR(v_payment_seq_id,
                                                           2,
                                                           LENGTH(v_payment_seq_id) - 2),
                                                    '|',
                                                    ',');

    TYPE payment_cheques_type IS RECORD(
      payment_seq_id    tpa_claims_payment.payment_seq_id%TYPE,
      cheque_number     tpa_claims_check.check_num%TYPE,
      cheque_amount     tpa_claims_check.check_amount%TYPE,
      group_reg_seq_id  tpa_claims_payment.group_reg_seq_id%TYPE,
      hosp_seq_id       tpa_hosp_info.hosp_seq_id%type,
      issue_cheque_to   tpa_claims_payment.tpa_cheque_issued_general_type%TYPE,
      hosp_issue_cheque tpa_claims_payment.tpa_nhcp_cheques_issued_to%type,
      claim_appr_amount tpa_claims_payment.approved_amount%TYPE,
      claim_seq_id      tpa_claims_payment.claim_seq_id%TYPE,
      payee_name        tpa_claims_payment.payee_name%type);

    TYPE payment_corp_table1 IS TABLE OF payment_cheques_type INDEX BY BINARY_INTEGER;
    TYPE seq_tab_type IS TABLE OF tpa_payment_checks_details.payment_seq_id%TYPE INDEX BY BINARY_INTEGER;
    TYPE cheque_num_tab_type IS TABLE OF tpa_claims_check.check_num%TYPE INDEX BY BINARY_INTEGER;

    seq_tab        seq_tab_type;
    cheque_num_tab cheque_num_tab_type;

    v_table_index  payment_corp_table1;
    v_table_index1 payment_corp_table1;

    str_tab  ttk_util_pkg.str_table_type;
    str_tab1 ttk_util_pkg.str_table_type;
    -- for tds calculation
    split_amt_tab  split_amt_type;
    split_perc_tab split_amt_type;
    v_exist_yn     VARCHAR2(1) := 'N';
 
CURSOR Get_Payment_seq(v_batch NUMBER) IS 
SELECT TO_CHAR(WM_CONCAT(PAYMENT_SEQ_ID)),tpa_cheque_issued_general_type
    FROM tpa_claims_payment
 WHERE batch_number_manual=v_batch
 GROUP BY tpa_cheque_issued_general_type;
 v_final_string     VARCHAR2(30000);
 v_sql_str1         VARCHAR2(4000);
 v_sqlstr2          VARCHAR2(4000);
 o_cheque_number   fin_app.tpa_claims_check.check_num%type;
 v_zeros_count           NUMBER(10):=0;

  BEGIN

    IF (v_payment_method = 'PMM') THEN
      -- PAYMENT MANUAL
      str_tab1 := ttk_util_pkg.parse_str(v_payment_seq_id);
      IF str_tab.COUNT > 999 THEN
        RAISE_APPLICATION_ERROR(-20684,
                                'Maximum selection allowed is 950. ');
      END IF;
      OPEN v_resultset FOR ' SELECT COUNT(1)
         FROM ( SELECT A.payment_seq_id FROM tpa_claims_payment A
         WHERE A.payment_seq_id IN (' || v_payment_seq_id_list || ') AND a.Claim_Payment_Status=''PAID'')';
      FETCH v_resultset
        INTO v_counter2;
      CLOSE v_resultset;

      IF v_counter2 > 0 THEN
        RAISE_APPLICATION_ERROR(-20244, 'Claim(s) already PAID');
      END IF;
      
       OPEN v_resultset FOR 'SELECT count(1) FROM tpa_claims_payment A
         WHERE A.payment_seq_id IN (' || v_payment_seq_id_list || ') AND a.claim_type=''CNH''';
      FETCH v_resultset
        INTO v_counter2;
      CLOSE v_resultset;
      
      
      IF v_counter2 > 0 THEN
        RAISE_APPLICATION_ERROR(-20965, 'Currently Manual cheque is only for Member/Reiumbersment claims');
      END IF;

      INSERT INTO tpa_batch_master
        (batch_number, added_by, added_date)
      VALUES
        (batch_master_seq.NEXTVAL, v_added_by, SYSDATE)
      RETURNING batch_number INTO v_batch_number;

      --getting bank_acc_number to check the check number issued to the bank_account.
      SELECT a.bank_acc_seq_id
        INTO v_bank_acc_seq_id
        FROM tpa_float_account a
       WHERE a.float_seq_id = v_float_seq_id;

      str_tab := str_tab1;

      OPEN v_resultset FOR ' SELECT a.payment_seq_id,
                             NULL AS cheque_number,
                             a.approved_amount,
                             a.group_reg_seq_id,
                             a.Hosp_Seq_Id,
                             a.tpa_cheque_issued_general_type,
                             a.tpa_nhcp_cheques_issued_to,
                             a.approved_amount,
                             a.claim_seq_id,
                             ttk_util_pkg.fn_decrypt(a.payee_name) as payee_name
          FROM tpa_claims_payment a
          WHERE a.payment_seq_id IN (' || v_payment_seq_id_list || ')';
      FETCH v_resultset BULK COLLECT
        INTO v_table_index;
      CLOSE v_resultset;

      v_table_index1 := v_table_index;

      p_cheque_number := v_cheque_number;
      o_cheque_number := CASE WHEN substr(v_cheque_number,1,1)=0 THEN 'Y' ELSE 'N' END;
      v_zeros_count := length(v_cheque_number)-length(ltrim(v_cheque_number,'0'));
      --start comparision b/w two tables
      FOR i IN v_table_index.FIRST .. v_table_index.LAST LOOP
        FOR j IN v_table_index1.FIRST .. v_table_index1.LAST LOOP
          --checking the check number issued to this account_number else display error
          SELECT COUNT(1)
            INTO v_counter
            FROM tpa_cheque_series b
           WHERE p_cheque_number BETWEEN chk_start_num AND chk_end_num
             AND b.bank_acc_seq_id = v_bank_acc_seq_id;

          IF (v_counter = 1) THEN
            --this query gives info abt the check number is already issued or not.
            FLOAT_ACCOUNTS_PKG.cheque_nos_issued_yn(v_bank_acc_seq_id,
                                                    p_cheque_number,
                                                    v_counter1);
            IF (v_counter1 >= 1) THEN
              RAISE_APPLICATION_ERROR(-20213,
                                      'cannot be issued same check to the same bank account');
            ELSIF (v_counter1 = 0) THEN
              IF (v_table_index(i).group_reg_seq_id IS NULL AND v_table_index(i)
                 .hosp_seq_id IS NULL) THEN
                IF (v_table_index(i)
                   .payment_seq_id = v_table_index1(j).payment_seq_id AND v_table_index1(j)
                   .cheque_number IS NULL) THEN
                  v_table_index1(j).cheque_number := CASE WHEN o_cheque_number='Y' and substr(p_cheque_number,1,1)!=0 THEN lpad(p_cheque_number,(length(v_cheque_number)),'0') ELSE p_cheque_number END;
                  v_count := v_count + 1;
                END IF;
              END IF;
              IF (v_table_index(i)
                 .group_reg_seq_id IS NOT NULL AND
                  NVL(v_table_index1(J).issue_cheque_to, 'IQI') IN
                  ('IQC', 'IQL') AND v_table_index(i).hosp_seq_id IS NULL) THEN
                IF (v_table_index1(j)
                   .group_reg_seq_id = v_table_index(i).group_reg_seq_id AND v_table_index1(j)
                   .cheque_number IS NULL AND
                    NVL(v_table_index1(i).issue_cheque_to, 'IQI') IN
                    ('IQC', 'IQL')) THEN
                  v_table_index1(j).cheque_number := CASE WHEN o_cheque_number='Y' and substr(p_cheque_number,1,1)!=0 THEN lpad(p_cheque_number,(length(v_cheque_number)),'0') ELSE p_cheque_number END;
                  v_count := v_count + 1;
                END IF;
              END IF;
              --issue cheque diff to payments even cor but if IQI
              IF (v_table_index(i)
                 .group_reg_seq_id IS NOT NULL AND
                  NVL(v_table_index1(J).issue_cheque_to, 'IQI') = 'IQI' AND v_table_index(i)
                 .hosp_seq_id IS NULL) THEN
                IF (v_table_index(i)
                   .payee_name = v_table_index1(j).payee_name AND v_table_index1(j)
                   .cheque_number IS NULL) THEN
                  v_table_index1(j).cheque_number := CASE WHEN o_cheque_number='Y' and substr(p_cheque_number,1,1)!=0 THEN lpad(p_cheque_number,(length(v_cheque_number)),'0') ELSE p_cheque_number END;
                  v_count := v_count + 1;
                END IF;
              END IF;

              --this info gives the NHCP cliams  cheque is issued to hospital name

              IF (v_table_index(i).hosp_seq_id IS NOT NULL AND v_table_index1(i)
                 .hosp_issue_cheque = 'HOS') THEN
                IF (v_table_index1(j)
                   .hosp_seq_id = v_table_index(i).hosp_seq_id AND v_table_index1(j)
                   .cheque_number IS NULL) THEN
                  v_table_index1(j).cheque_number := CASE WHEN o_cheque_number='Y' and substr(p_cheque_number,1,1)!=0 THEN lpad(p_cheque_number,(length(v_cheque_number)),'0') ELSE p_cheque_number END;
                  v_count := v_count + 1;
                END IF;
              END IF;
              --this info gives the NHCP cliams  cheque is issued to managament name
              IF (v_table_index(i).hosp_seq_id IS NOT NULL AND v_table_index1(i)
                 .hosp_issue_cheque = 'MAN') THEN
                IF (v_table_index(i)
                   .payment_seQ_id = v_table_index1(j).payment_seQ_id AND v_table_index1(j)
                   .cheque_number IS NULL) THEN
                  v_table_index1(j).cheque_number := CASE WHEN o_cheque_number='Y' and substr(p_cheque_number,1,1)!=0 THEN lpad(p_cheque_number,(length(v_cheque_number)),'0') ELSE p_cheque_number END;
                  v_count := v_count + 1;
                END IF;
              END IF;
            END IF; --end of v_counter1
          ELSE
            RAISE_APPLICATION_ERROR(-20212,
                                    'check number  is not in database/not issued to this bank account');
          END IF; --END OF V_COUNTER
        END LOOP; --end of jth loop
        IF (v_count >= 1) THEN
          p_cheque_number := p_cheque_number + 1;
        END IF;
        v_count := 0;
      END LOOP; --end of ith loop

      -- For TDS deduction added by S.V.Sreeraj
      --==========================================
      /* FOR i IN v_table_index1.first .. v_table_index1.last
      LOOP
        IF (v_table_index1(i).hosp_seq_id IS NOT  NULL AND v_table_index1(i).hosp_issue_cheque IN ('HOS','MAN')) THEN
          get_tds_amount(v_table_index1(i).claim_seq_id, v_table_index1(i).hosp_seq_id , v_table_index1(i).cheque_amount,split_amt_tab,split_perc_tab, v_exist_yn);

          IF v_exist_yn = 'N' THEN
            save_clm_tds_details( v_table_index1(i).payment_seq_id,
                                  v_table_index1(i).claim_seq_id,
                                  v_table_index1(i).claim_appr_amount,
                                  v_table_index1(i).cheque_amount,
                                  split_amt_tab,
                                  split_perc_tab,
                                  'C',
                                  v_added_by);
          END IF;
        END IF;
      END LOOP;*/

      --insert the chqeque nos into tpa_claims_check
      FOR i IN v_table_index1.FIRST .. v_table_index1.LAST LOOP
        IF (v_table_index1(i).payment_seQ_id IS NOT NULL AND v_table_index1(i)
           .cheque_number IS NOT NULL) THEN
          --check this no is issued with this batch.
          SELECT COUNT(1)
            INTO v_flag
            FROM tpa_claims_check a
           WHERE a.batch_number = v_batch_number
             AND a.check_num = v_table_index1(i).cheque_number;

          --if already issued then please update the check amount
          IF (v_flag >= 1) THEN

            UPDATE tpa_claims_check a
               SET a.check_amount =
                   (a.check_amount + v_table_index1(i).cheque_amount)
             WHERE a.batch_number = v_batch_number
               AND a.check_num = v_table_index1(i).cheque_number;

            --get the claims_chk_seq_id
            SELECT a.claims_chk_seq_id
              INTO v_chq_seq_id
              FROM tpa_claims_check a
             WHERE a.batch_number = v_batch_number
               AND a.check_num = v_table_index1(i).cheque_number;

            --insert into duplicate record to tpa_payment_check_details
            --printed cheques for  particular payments information is stored.
            INSERT INTO tpa_payment_checks_details
              (payment_check_seq_id,
               payment_seq_id,
               claims_chk_seq_id,
               added_by,
               Added_date)
            VALUES
              (claims_payment_check_seq.NEXTVAL,
               v_table_index1(i).payment_seQ_id,
               v_chq_seq_id,
               v_added_by,
               SYSDATE);

            --please insert the new cheque record inot tpa_claims_check
          ELSIF (v_flag = 0) THEN
            --printed cheques information stored

            INSERT INTO tpa_claims_check
              (claims_chk_seq_id,
               check_num,
               check_amount,
               check_date,
               check_status,
               courier_delivery_date,
               added_by,
               added_date,
               batch_number,
               PAYMENT_TYPE) --koc1175
            VALUES
              (claims_chk_seq.NEXTVAL,
               v_table_index1(i).cheque_number,
               (v_table_index1(i).cheque_amount),
               SYSDATE,
               'CSI',
               SYSDATE,
               V_added_by,
               SYSDATE,
               v_batch_number,
               'PMM'); --koc1175
            --printed cheques for  particular payments information is stored.
            INSERT INTO tpa_payment_checks_details
              (payment_check_seq_id,
               payment_seq_id,
               claims_chk_seq_id,
               added_by,
               added_date)
            VALUES
              (claims_payment_check_seq.NEXTVAL,
               v_table_index1(i).payment_seQ_id,
               claims_chk_seq.CURRVAL,
               v_added_by,
               SYSDATE);
          END IF;
        END IF;
      END LOOP; --insertion completed.

      --get batch number after insertion into cheques table

      /* SELECT COUNT(1),SUM(c.approved_amount),sum(check_amount),TRUNC(MAX(check_date))
         INTO v_no_of_cheques,v_approved_amt,v_sum, v_batch_date
      FROM tpa_claims_check a
      JOIN tpa_payment_checks_details b ON (a.claims_chk_seq_id=b.claims_chk_seq_id)
      JOIN tpa_claims_payment c ON(b.payment_seq_id=c.payment_seq_id)
      WHERE a.batch_number = v_batch_number;*/

      SELECT MAX(ctr), SUM(approved_amount), TRUNC(max(check_date))
        INTO v_no_of_cheques, v_approved_amt, v_batch_date
        FROM (SELECT count(DISTINCT a.claims_chk_seq_id) over(PARTITION BY 1) ctr,
                     c.approved_amount,
                     a.check_date
                FROM tpa_claims_check a
                JOIN tpa_payment_checks_details b
                  ON (a.claims_chk_seq_id = b.claims_chk_seq_id)
                JOIN tpa_claims_payment c
                  ON (b.payment_seq_id = c.payment_seq_id)
               WHERE a.batch_number = v_batch_number);

      SELECT SUM(a.check_amount)
        INTO v_sum
        FROM tpa_claims_check a
       WHERE a.batch_number = v_batch_number;

      --these updation should only occur when batch number creation
      IF (v_no_of_cheques > 0) THEN

        --updating current balance
        UPDATE tpa_float_account
           SET current_balance =
               (current_balance - v_approved_amt)
         WHERE float_seq_id = v_float_seq_id;
        --updating the balance of  the account number.

        UPDATE tpa_bank_accounts
           SET bank_balance =
               (bank_balance - v_approved_amt)
         WHERE bank_acc_seq_id = v_bank_acc_seq_id;

        --cursor get payment ids
        OPEN v_resultset FOR
          SELECT a.payment_seq_id, b.check_num
            FROM tpa_payment_checks_details a
            JOIN tpa_claims_check b
              on (a.claims_chk_seq_id = b.claims_chk_seq_id)
           WHERE b.batch_number = v_batch_number;
        FETCH v_resultset BULK COLLECT
          INTO seq_tab, cheque_num_tab;
        CLOSE v_resultset;

        IF seq_tab.FIRST IS NOT NULL THEN
          FORALL i IN seq_tab.FIRST .. seq_tab.LAST
            UPDATE tpa_claims_payment a
               SET a.claim_payment_status = 'PAID',
                   A.payee_type           = v_payment_method,
                   A.batch_number_manual  = v_batch_number
             WHERE A.payment_seq_id = seq_tab(i);

          FOR i IN seq_tab.FIRST .. seq_tab.LAST --Added for CR - KOC1025
           LOOP
            GENERATE_MAIL_PKG.proc_form_message('FINANCE_PAYMENT_CHQ',
                                                seq_tab(i),
                                                v_added_by,
                                                v_dest_msg_seq_id);
          END LOOP;

          FORALL i IN cheque_num_tab.FIRST .. cheque_num_tab.LAST
            UPDATE tpa_cheque_series
               SET issued_yn = 'Y'
             WHERE cheque_num_tab(i) BETWEEN chk_start_num AND chk_end_num
               AND bank_acc_seq_id = v_bank_acc_seq_id;
        END IF;

        --values are updated to respective batch number.
        UPDATE tpa_batch_master
           SET batch_date        = v_batch_date,
               number_of_cheques = v_no_of_cheques,
               batch_amount      = v_sum
         WHERE batch_number = v_batch_number;

      END IF; --validation of batch number

      --displaying cheque information into pdf style as per uti/citi bank cheque leaf format.
  FOR I IN (SELECT TO_CHAR(WM_CONCAT(PAYMENT_SEQ_ID)) AS PAYMENT_SEQ_ID,tpa_cheque_issued_general_type FROM tpa_claims_payment
                   WHERE batch_number_manual=v_batch_number  GROUP BY tpa_cheque_issued_general_type) LOOP

   IF I.TPA_CHEQUE_ISSUED_GENERAL_TYPE ='IQI' THEN
         v_sql_str1:=
           'select payee_name, member_id,approved_amount,
                         case when cnt<=7 then APP_AMT_WORD else   SUBSTR(APP_AMT_WORD,1,INSTR(APP_AMT_WORD,'' '',1,8)) end as amt1,
                         case when cnt<=7 then null else SUBSTR(APP_AMT_WORD,INSTR(APP_AMT_WORD,'' '',1,8)) end AS AMT2,
                         check_num,check_date,account_number,member_name,mobile_no,vishwa from 
           (SELECT ttk_util_pkg.fn_decrypt(a.payee_name) as payee_name,
               g.tpa_enrollment_number as member_id,
               SUM(a.approved_amount) approved_amount,
               TTK_UTIL_PKG.NUM_TO_WORD_CONV(SUM(a.approved_amount)) AS APP_AMT_WORD,
                REGEXP_COUNT(TTK_UTIL_PKG.NUM_TO_WORD_CONV(SUM(a.approved_amount)),'' '') as cnt ,c.check_num,
               to_char(c.check_date, ''DD-MON-YYYY'') AS check_date,
               e.account_number,
               g.insured_name AS member_name,
               nvl(ttk_util_pkg.fn_decrypt(pr.mobile_no),''Not Available'') AS mobile_no,
               --nvl(ttk_util_pkg.fn_decrypt(pr.email_id),''Not Available'') as email_id,
               --to_char(pr.pin_code),
               --nvl(pci.city_description,''Not Available'')  as city_name,
              -- nvl(pst.state_name,''Not Available'') as state_name, 
               --nvl(pcc.country_name,''Not Available'') as country_name,
               --nvl(pr.address_1,''Not Available'') as address,
               '||v_no_of_cheques||' as vishwa
          FROM tpa_claims_payment A
          JOIN tpa_enr_policy p on (a.policy_seq_id=p.policy_seq_id)
          JOIN tpa_enr_policy_group g on (p.policy_seq_id=g.policy_seq_id)
          JOIN tpa_enr_policy_member m on (g.policy_group_seq_id=m.policy_group_seq_id and a.member_seq_id=m.member_seq_id)
          JOIN tpa_enr_mem_address pr on (pr.enr_address_seq_id=g.enr_address_seq_id)
          --LEFT OUTER JOIN tpa_city_code pci on (pr.city_type_id=pci.city_type_id)
          --JOIN tpa_state_code pst on (pr.state_type_id=pst.state_type_id)
          --JOIN tpa_country_code pcc on (pr.country_id=pcc.country_id)
          JOIN tpa_payment_checks_details b ON (a.payment_seq_id = b.payment_seq_id)
          JOIN tpa_claims_check C ON (b.claims_chk_seq_id = c.claims_chk_seq_id)
          JOIN tpa_float_account D ON (D.float_seq_id = a.float_seq_id)
          JOIN tpa_bank_accounts E ON (d.bank_acc_seq_id = e.bank_acc_seq_id)
          LEFT OUTER JOIN tpa_clm_tds_details f ON (a.payment_seq_id = f.payment_seq_id)
         WHERE c.check_status = ''CSI'' and A.TPA_CHEQUE_ISSUED_GENERAL_TYPE=''IQI'' AND c.batch_number IN ( ' ||v_batch_number||' )'||'
         GROUP BY c.check_num,
                  ttk_util_pkg.fn_decrypt(a.payee_name),
                  e.account_number,
                  c.check_date,
                  g.insured_name,
                  ttk_util_pkg.fn_decrypt(pr.mobile_no),
                  --ttk_util_pkg.fn_decrypt(pr.email_id),
                  --pr.pin_code,
                  --pci.city_description,
                  --pst.state_name,
                  --pcc.country_name,
                  --pr.address_1,
                  g.tpa_enrollment_number) ';
         
   ELSIF I.TPA_CHEQUE_ISSUED_GENERAL_TYPE='IQC' THEN
         
         V_SQLSTR2:=
         
         'select payee_name, member_id,approved_amount,
                         case when cnt<=7 then APP_AMT_WORD else   SUBSTR(APP_AMT_WORD,1,INSTR(APP_AMT_WORD,'' '',1,8)) end as amt1,
                         case when cnt<=7 then null else SUBSTR(APP_AMT_WORD,INSTR(APP_AMT_WORD,'' '',1,8)) end AS AMT2,
                         check_num,check_date,account_number,member_name,mobile_no,vishwa from
                         (SELECT ttk_util_pkg.fn_decrypt(a.payee_name) as payee_name,
               GROUP_ID as member_id,
               SUM(a.approved_amount) approved_amount,
               TTK_UTIL_PKG.NUM_TO_WORD_CONV(SUM(a.approved_amount)) AS APP_AMT_WORD,
               REGEXP_COUNT(TTK_UTIL_PKG.NUM_TO_WORD_CONV(SUM(a.approved_amount)),'' '') as cnt,
               c.check_num,
               to_char(c.check_date, ''DD-MON-YYYY'') AS check_date,
               e.account_number,
               gr.group_name as member_name,
               to_char(gad.OFFICE_PHONE1) as mobile_no,
               --gr.hr_email_id as email_id,
               --to_char(gad.pin_code) as pin_code,
               --nvl(gci.city_description,''Not Available'') as city_name,
               --nvl(gst.state_name,''Not Available'') as state_name,
               --nvl(gcc.country_name,''Not Available'') as country_name,
               --nvl(gad.address_1,''Not Available'') as address,
               '||v_no_of_cheques||' as vishwa
               
          FROM tpa_claims_payment A
          JOIN tpa_enr_policy p on (a.policy_seq_id=p.policy_seq_id)
          JOIN TPA_GROUP_REGISTRATION Gr ON (gr.group_reg_seq_id=p.group_reg_seq_id)
          JOIN TPA_ADDRESS gad ON (gr.group_reg_seq_id=gad.group_reg_seq_id)
          LEFT OUTER JOIN tpa_city_code gci on (gad.city_type_id=gci.city_type_id)
          JOIN tpa_state_code gst on (gad.state_type_id=gst.state_type_id)
          JOIN tpa_country_code gcc on (gad.country_id=gcc.country_id)
          JOIN tpa_payment_checks_details b ON (a.payment_seq_id = b.payment_seq_id)
          JOIN tpa_claims_check C ON (b.claims_chk_seq_id = c.claims_chk_seq_id)
          JOIN tpa_float_account D ON (D.float_seq_id = a.float_seq_id)
          JOIN tpa_bank_accounts E ON (d.bank_acc_seq_id = e.bank_acc_seq_id)
          LEFT OUTER JOIN tpa_clm_tds_details f ON (a.payment_seq_id = f.payment_seq_id)
         WHERE c.check_status = ''CSI'' and A.TPA_CHEQUE_ISSUED_GENERAL_TYPE=''IQC'' AND c.batch_number = ( '||v_batch_number||')'||'
         GROUP BY c.check_num,
                  ttk_util_pkg.fn_decrypt(a.payee_name),
                  e.account_number,
                  c.check_date,
                  --gci.city_description,
                  --gst.state_name,
                  --gcc.country_name,
                  --gad.address_1,
                  gad.office_phone1,
                  --gr.hr_email_id,
                  gr.group_name,
                  --gad.pin_code,
                  GROUP_ID)';
      ELSE
           NULL;
      END IF;          
  END LOOP; 
  
v_final_string:= CASE WHEN v_sql_str1 is not null and V_SQLSTR2 is not null then
                        
                        v_sql_str1 ||' union all ' ||V_SQLSTR2
                        
                      WHEN v_sql_str1 is not null and V_SQLSTR2 is null then
                        
                        v_sql_str1
                      WHEN v_sql_str1 is null and V_SQLSTR2 is not null then
                        
                          V_SQLSTR2 end;
                          
 v_final_string:= v_final_string ||' ORDER BY check_num ASC ';
   
open v_resultset FOR v_final_string;  
      COMMIT;
      v_rows_processed := str_tab.COUNT;
    ELSE
      RAISE_APPLICATION_ERROR(-20211,
                              'enter correct payment method manual');
    END IF;
  END manual_print_check;
  --=============================================================================
  -- modified by S.V.SREERAJ -- FOR BETTER PERFORMANCE
  -- Modified date : 03-03-2008

  PROCEDURE set_fund_transfer(v_payment_seq_id IN VARCHAR2,
                              v_float_seq_id   IN TPA_FLOAT_ACCOUNT.float_seq_id%TYPE,
                              v_remarks        IN VARCHAR2,
                              v_payment_method IN TPA_CLAIMS_PAYMENT.payee_type%TYPE,
                              v_added_by       IN NUMBER,
                              v_rows_processed OUT INTEGER) IS
    v_counter2 NUMBER(20);

    CURSOR payment_cur(c_payment_id tpa_claims_payment.payment_seq_id%TYPE) IS
      SELECT a.payment_seq_id, a.approved_amount
        FROM tpa_claims_payment a
       WHERE a.payment_seq_id = c_payment_id;

    TYPE amt_tab_type IS TABLE OF NUMBER(16, 2) INDEX BY BINARY_INTEGER;
    amt_tab amt_tab_type;

    i                     NUMBER(10) := 0;
    v_payment_seq_id_list VARCHAR2(32767) := REPLACE(SUBSTR(v_payment_seq_id,
                                                           2,
                                                           LENGTH(v_payment_seq_id) - 2),
                                                    '|',
                                                    ',');
    c_payment_id          tpa_claims_payment.payment_seq_id%TYPE;
    v_batch_number        tpa_batch_master.batch_number%TYPE;
    v_bank_acc_seq_id     TPA_BANK_ACCOUNTS.BANK_ACC_SEQ_ID%TYPE;
    v_no_of_cheques       NUMBER(20);
    v_batch_amount        tpa_claims_check.check_amount%TYPE;
    str_tab               ttk_util_pkg.str_table_type;
    str_tab1              ttk_util_pkg.str_table_type;
    v_ctr                 number(2);
    v_claims_chk_seq_id   tpa_claims_check.claims_chk_seq_id%type;
    v_resultset           SYS_REFCURSOR;


  BEGIN

    str_tab := ttk_util_pkg.parse_str(v_payment_seq_id);

    IF str_tab.COUNT > 999 THEN
      RAISE_APPLICATION_ERROR(-20684, 'Maximum selection allowed is 950. ');
    END IF;

    INSERT INTO tpa_batch_master
      (batch_number, added_by, added_date)
    VALUES
      (batch_master_seq.NEXTVAL, v_added_by, SYSDATE)
    RETURNING batch_number INTO v_batch_number;

    SELECT a.bank_acc_seq_id
      INTO v_bank_acc_seq_id
      FROM tpa_float_account a
     WHERE a.float_seq_id = v_float_seq_id;

    EXECUTE IMMEDIATE ' SELECT a.payment_seq_id,a.approved_amount
          FROM tpa_claims_payment a
          WHERE a.payment_seq_id IN (' ||
                      v_payment_seq_id_list || ') ' BULK COLLECT
      INTO str_tab1, amt_tab;

    FOR i IN amt_tab.FIRST .. amt_tab.LAST LOOP
      select count(1)
        into v_ctr
        from fin_app.tpa_claims_check hj
        left outer join fin_app.tpa_payment_checks_details hy
          on (hj.claims_chk_seq_id = hy.claims_chk_seq_id)
       where hy.payment_seq_id = str_tab(i)
         and hy.v_csr_flag = 1;
      if v_ctr >= 1 then

        update tpa_payment_checks_details
           set v_csr_flag = 0
         where payment_seq_id = str_tab1(i)
           and v_csr_flag = 1
        returning claims_chk_seq_id into v_claims_chk_seq_id;

        update tpa_claims_check
           set v_csr_flag = 0, check_status = 'CSR'
         where claims_chk_seq_id = v_claims_chk_seq_id;

      end if; -- alredy records
      --printed cheques information stored
      INSERT INTO tpa_claims_check
        (claims_chk_seq_id,
         check_num,
         check_amount,
         check_date,
         check_status,
         courier_delivery_date,
         batch_number,
         added_by,
         added_date,
         PAYMENT_TYPE) --koc1175
      VALUES
        (claims_chk_seq.NEXTVAL,
         NULL,
         amt_tab(i),
         SYSDATE,
         'CSI', --koc1175 CHANGED CHECK STATUS CSC TO CSI
         SYSDATE,
         v_batch_number,
         v_added_by,
         SYSDATE,
         'EFT'); --koc1175

      --printed cheques for  particular payments information is stored.
      INSERT INTO tpa_payment_checks_details
        (payment_check_seq_id,
         payment_seq_id,
         claims_chk_seq_id,
         added_by,
         added_date)
      VALUES
        (claims_payment_check_seq.NEXTVAL,
         str_tab1(i),
         claims_chk_seq.CURRVAL,
         v_added_by,
         SYSDATE);

    END LOOP;

    --get check amount
    SELECT COUNT(1), SUM(check_amount) INTO  v_no_of_cheques, v_batch_amount
        FROM tpa_claims_check a WHERE a.batch_number  = v_batch_number ;

      --updating current balance
      UPDATE tpa_float_account a SET
          a.current_balance    = (current_balance - v_batch_amount),
          a.updated_by         = v_added_by,
          a.updated_date       = SYSDATE
           WHERE float_seq_id = v_float_seq_id;
      --updating the balance of  the account number.
      UPDATE tpa_bank_accounts a SET
          a.bank_balance       = (bank_balance - v_batch_amount),
          a.updated_by         = v_added_by,
          a.updated_date       = SYSDATE
          WHERE bank_acc_seq_id = v_bank_acc_seq_id ;
      --cursor get payment ids
      FORALL I IN str_tab.FIRST .. str_tab.LAST
        UPDATE tpa_claims_payment a SET
          --  a.claim_payment_status = 'PAID', --MODIFIED FOR CR KOC1103
          a.claim_payment_status = 'READY_TO_BANK',
          A.payee_type           = 'EFT',
          A.batch_number_manual  = v_batch_number,
          A.Remarks              = v_remarks,
          a.updated_by           = v_added_by,
          a.updated_date         = SYSDATE
          WHERE A.payment_seq_id = str_tab(I) ;--AND a.claim_payment_status = 'PENDING';

      IF str_tab.COUNT != SQL%ROWCOUNT THEN
        RAISE_APPLICATION_ERROR(-20244,'Claim(s) already PAID');
      END IF;
      --values are updated to respective batch number.
      UPDATE tpa_batch_master a SET
        a.batch_date          = TRUNC( SYSDATE ),
        a.number_of_cheques   = v_no_of_cheques,
        a.batch_amount        = v_batch_amount,
        a.updated_by          = v_added_by,
        a.updated_date        = SYSDATE
        WHERE batch_number    = v_batch_number;

   /*   FOR I IN str_tab.FIRST .. str_tab.LAST  --Added for CR - KOC1025
      LOOP
        GENERATE_MAIL_PKG.proc_form_message ( 'FINANCE_PAYMENT_EFT', str_tab(I), v_added_by, v_dest_msg_seq_id);
      END LOOP;  */--koc1175

      COMMIT;

      v_rows_processed  := str_tab.COUNT;
  END set_fund_transfer;

  --===================================================================================================
  /* Author     : R. J. Prasanna Kumar, SPAN Infotech.
     Description: This procedure gives list of debit notes created under a perticular float account.
  */
  PROCEDURE get_debit_note_list(v_float_seq_id   IN TPA_FLOAT_ACCOUNT.float_seq_id%TYPE,
                                v_debit_status   IN TPA_DEBIT_NOTE.debit_status_general_type_id%TYPE,
                                v_debit_note_num IN TPA_DEBIT_NOTE.debit_note_number%TYPE,
                                v_from_date      IN VARCHAR2,
                                v_to_date        IN VARCHAR2,
                                v_flag           IN VARCHAR2,
                                v_sort_var       IN VARCHAR2,
                                v_sort_order     IN VARCHAR2,
                                v_start_num      IN NUMBER,
                                v_end_num        IN NUMBER,
                                v_result_set     OUT SYS_REFCURSOR) IS
    v_sql_stmt VARCHAR2(2000);
    TYPE bind_tab_type IS TABLE OF VARCHAR2(250) INDEX BY BINARY_INTEGER;
    bind_tab bind_tab_type;
    i        NUMBER(2) := 0;
  BEGIN
    v_sql_stmt := 'SELECT a.debit_seq_id, a.debit_note_number, a.debit_date, a.debit_amount,
                         a.debit_status_general_type_id, b.description,a.final_date
                    FROM tpa_debit_note a LEFT OUTER JOIN tpa_general_code b
                          ON (a.debit_status_general_type_id = b.general_type_id)';
    IF v_flag = 'Payments' THEN
      -- Then needs to list only debit notes with claims dep.amt.=claims app.amt.
      i := i + 1;
      bind_tab(i) := v_float_seq_id;
      v_sql_stmt := 'WITH debits_for_payment AS
          (SELECT B.debit_seq_id FROM tpa_claims_payment A
            JOIN  ( SELECT claim_seq_id, SUM(deposited_amount) AS total_dep_amt
                   FROM tpa_debit_claims_transaction GROUP BY claim_seq_id ) dep_dtl
                ON ( A.claim_seq_id = dep_dtl.claim_seq_id AND A.approved_amount = dep_dtl.total_dep_amt)
                JOIN tpa_debit_note_claims_assoc B ON (A.claim_seq_id = B.claim_seq_id)
              WHERE A.claim_payment_status = ''DEBIT_NOTE_ATTACHED''
                AND A.float_seq_id = :v_float_seq_id AND A.deleted_yn = ''N'' GROUP BY B.debit_seq_id ) ' ||
                    v_sql_stmt ||
                    'JOIN debits_for_payment c ON (a.debit_seq_id = c.debit_seq_id)';
    END IF;
    i := i + 1;
    bind_tab(i) := v_float_seq_id;
    i := i + 1;
    bind_tab(i) := v_debit_status;
    v_sql_stmt := v_sql_stmt ||
                  ' WHERE a.float_seq_id = :v_float_seq_id AND a.debit_status_general_type_id = :v_debit_status';
    IF v_from_date IS NOT NULL THEN
      i := i + 1;
      bind_tab(i) := to_date(v_from_date, 'dd/mm/yyyy');
      v_sql_stmt := v_sql_stmt || ' AND a.debit_date >= :v_from_date';
    END IF;
    IF v_to_date IS NOT NULL THEN
      i := i + 1;
      bind_tab(i) := to_date(v_to_date, 'dd/mm/yyyy') + 1;
      v_sql_stmt := v_sql_stmt || ' AND a.debit_date <= :v_to_date';
    END IF;
    IF v_debit_note_num IS NOT NULL THEN
      i := i + 1;
      bind_tab(i) := v_debit_note_num || '%';
      v_sql_stmt := v_sql_stmt ||
                    ' AND a.debit_note_number LIKE :v_debit_note_num';
    END IF;

    v_sql_stmt := 'SELECT * FROM
                  (SELECT A.*,DENSE_RANK() OVER (ORDER BY '||v_sort_var||' '||v_sort_order||',ROWNUM)
                   Q FROM (' ||v_sql_stmt|| ') A ) WHERE  Q>= :v_start_num  AND Q<= :v_end_num ';

    IF bind_tab.FIRST IS NOT NULL THEN
      CASE bind_tab.COUNT
        WHEN 1 THEN
          OPEN v_result_set FOR v_sql_stmt
            USING bind_tab(1), v_start_num, v_end_num;
        WHEN 2 THEN
          OPEN v_result_set FOR v_sql_stmt
            USING bind_tab(1), bind_tab(2), v_start_num, v_end_num;
        WHEN 3 THEN
          OPEN v_result_set FOR v_sql_stmt
            USING bind_tab(1), bind_tab(2), bind_tab(3), v_start_num, v_end_num;
        WHEN 4 THEN
          OPEN v_result_set FOR v_sql_stmt
            USING bind_tab(1), bind_tab(2), bind_tab(3), bind_tab(4), v_start_num, v_end_num;
        WHEN 5 THEN
          OPEN v_result_set FOR v_sql_stmt
            USING bind_tab(1), bind_tab(2), bind_tab(3), bind_tab(4), bind_tab(5), v_start_num, v_end_num;
        WHEN 6 THEN
          OPEN v_result_set FOR v_sql_stmt
            USING bind_tab(1), bind_tab(2), bind_tab(3), bind_tab(4), bind_tab(5), bind_tab(6), v_start_num, v_end_num;
      END CASE;
    ELSE
      OPEN v_result_set FOR v_sql_stmt
        USING v_start_num, v_end_num;
    END IF;

  END get_debit_note_list;
  --===================================================================================================
  /* Author     : R. J. Prasanna Kumar, SPAN Infotech.
     Description: This procedure gives detail of a perticular debit note.
  */
  PROCEDURE get_debit_note_details(v_debit_seq_id IN TPA_DEBIT_NOTE.debit_seq_id%TYPE,
                                   v_user_seq_id  IN NUMBER,
                                   v_result_set   OUT SYS_REFCURSOR) IS
  BEGIN

      OPEN v_result_set FOR--ADDED FLOAT SEQ_ID FOR KOC1163
        SELECT debit_seq_id, float_seq_id,debit_note_number, debit_date, debit_status_general_type_id, debit_amount, remarks,final_date
          FROM tpa_debit_note
            WHERE debit_seq_id = v_debit_seq_id;

  END get_debit_note_details;
--===================================================================================================
/* Author     : R. J. Prasanna Kumar, SPAN Infotech.
   Description: This procedure is used to insert/update a record to/from TPA_DEBIT_NOTE table.
*/
  PROCEDURE debit_note_save(
    v_float_seq_id   IN  TPA_FLOAT_ACCOUNT.float_seq_id%TYPE,
    v_debit_seq_id   IN  OUT TPA_DEBIT_NOTE.debit_seq_id%TYPE,
    v_debit_date     IN  TPA_DEBIT_NOTE.debit_date%TYPE,    
    v_debit_status   IN  TPA_DEBIT_NOTE.debit_status_general_type_id%TYPE,
    v_debit_amount   IN  TPA_DEBIT_NOTE.debit_amount%TYPE,
    v_remarks        IN  TPA_DEBIT_NOTE.Remarks%TYPE,
    v_added_by       IN  NUMBER,
    v_final_date     IN  TPA_DEBIT_NOTE.FINAL_DATE%TYPE,
    v_row_processed  OUT INTEGER
  )
  IS
    v_debit_note_num TPA_DEBIT_NOTE.DEBIT_NOTE_NUMBER%TYPE;
  BEGIN
    -- Concatinate, insurance code and tpa location, to debit note number (if exists)
    SELECT COUNT(1)
      INTO v_row_processed
      FROM tpa_float_account a
      JOIN tpa_ins_info b
        ON (a.Ins_Seq_Id = b.ins_seq_id)
      JOIN tpa_office_info c
        ON (b.tpa_office_seq_id = c.tpa_office_seq_id)
     WHERE a.float_seq_id = v_float_seq_id;

    IF v_row_processed > 0 THEN
      SELECT b.abbrevation_code || '-' || c.office_code || '-DEBIT-NOTE-'
        INTO v_debit_note_num
        FROM tpa_float_account a
        JOIN tpa_ins_info b
          ON (a.Ins_Seq_Id = b.ins_seq_id)
        JOIN tpa_office_info c
          ON (b.tpa_office_seq_id = c.tpa_office_seq_id)
       WHERE a.float_seq_id = v_float_seq_id;
    ELSE
      v_debit_note_num := 'DEBIT-NOTE-';
    END IF;

    IF nvl(v_debit_seq_id,0) = 0 THEN  -- Then it is for creating new debit note.
       INSERT INTO TPA_DEBIT_NOTE (debit_seq_id, float_seq_id, debit_note_number,
                   debit_date, debit_status_general_type_id, debit_amount,
                   remarks, added_by, added_date)
       VALUES (DEBIT_NOTE_SEQ.NEXTVAL, v_float_seq_id, v_debit_note_num||to_char(DEBIT_NOTE_SEQ.CURRVAL),
                v_debit_date , v_debit_status, 0,
               v_remarks, v_added_by, SYSDATE) RETURNING debit_seq_id INTO v_debit_seq_id ;
    ELSE
      SELECT COUNT(1)
        INTO v_row_processed
        FROM tpa_debit_note_claims_assoc
       WHERE debit_seq_id = v_debit_seq_id;

      IF (v_debit_status = 'DFL' AND v_row_processed > 0) OR
         v_debit_status != 'DFL' THEN
        UPDATE TPA_DEBIT_NOTE
           SET debit_date                   = v_debit_date,
               debit_status_general_type_id = v_debit_status,
               -- debit_amount = v_debit_amount,
               remarks      = v_remarks,
               updated_by   = v_added_by,
               final_date   = trim(v_final_date),
               updated_date = SYSDATE
         WHERE debit_seq_id = v_debit_seq_id;
      ELSE
        raise_application_error(-20255,
                                'Associate at least a claim to a debit note to make final.');
      END IF;
    END IF;
    --number of rows updated/inserted
    v_row_processed := SQL%ROWCOUNT;
    COMMIT;
  END debit_note_save;
  --===================================================================================================
  /* Author     : R. J. Prasanna Kumar, SPAN Infotech.
     Description: This procedure gives list of claims associated with a perticular debit notes
                  OR not associated to any debit note (for associating it to a debit note).
  */
  PROCEDURE get_debit_claims_list(v_float_seq_id    IN TPA_FLOAT_ACCOUNT.float_seq_id%TYPE,
                                  v_debit_seq_id    IN TPA_DEBIT_NOTE.debit_seq_id%TYPE,
                                  v_claim_Settle_No IN TPA_CLAIMS_PAYMENT.Claim_Settlement_No%TYPE,
                                  v_Enrollment_Id   IN CLM_ENROLL_DETAILS.tpa_enrollment_id%TYPE,
                                  v_claimant_name   IN CLM_ENROLL_DETAILS.claimant_name%TYPE,
                                  v_claim_type      IN CLM_INWARD.claim_general_type_id%TYPE,
                                  v_policy_type     IN CLM_ENROLL_DETAILS.enrol_type_id%TYPE,
                                  v_Payee           IN TPA_CLAIMS_PAYMENT.Payee_Name%TYPE,
                                  v_payment_mode    IN TPA_CLAIMS_PAYMENT.payee_type%TYPE, --koc1163
                                  v_Assoc_UnAssoc   IN VARCHAR2, -- DBA - Associated DBU - Unassociated
                                  v_sort_var        IN OUT VARCHAR2,
                                  v_sort_order      IN OUT VARCHAR2,
                                  v_start_num       IN OUT NUMBER,
                                  v_end_num         IN OUT NUMBER,
                                  v_result_set      OUT SYS_REFCURSOR) IS
    v_sql_stmt VARCHAR2(4000);
    TYPE bind_tab_type IS TABLE OF VARCHAR2(250) INDEX BY BINARY_INTEGER;
    bind_tab         bind_tab_type;
    i                NUMBER(2) := 0;
    v_tpa_account_no VARCHAR2(100); --balley
    v_tpa_ifsc       VARCHAR2(60); --balley

    CURSOR tpa_bank_details IS
      SELECT ad.account_number, ad.bank_ifsc
        FROM fin_app.tpa_account_details ad;
    tpa_rec tpa_bank_details%rowtype; --balley
    
  BEGIN
    v_sort_var   := case WHEN v_sort_var IS NULL THEN 'CLAIM_SEQ_ID' ELSE v_sort_var END;
    v_sort_order := case WHEN v_sort_order IS NULL THEN 'ASC' ELSE v_sort_order END;
    v_start_num  := case WHEN v_start_num IS NULL THEN 1 ELSE v_start_num END;
    v_end_num    := case WHEN v_end_num IS NULL THEN 101 ELSE v_end_num END;
    
    OPEN tpa_bank_details;
    FETCH tpa_bank_details
      INTO v_tpa_account_no, v_tpa_ifsc;
    CLOSE tpa_bank_details;

    --select d.account_number,d.bank_ifsc into v_tpa_account_no,v_tpa_ifsc from fin_app.tpa_account_details d;--balley
    v_sql_stmt := 'SELECT a.claim_seq_id,             a.claim_settlement_no,        cad.tpa_enrollment_id,
             cad.mem_name ,  cad.Claim_Type,
             a.claim_aprv_date,           ttk_util_pkg.fn_decrypt(a.payee_name) as in_favour_of, a.approved_amount,
             (CASE WHEN a.claim_type=''CTM'' AND nvl(Cad.claim_type,''MBR'')!=''HSL'' THEN--added for hyundai requirement
                CASE WHEN a.tpa_nhcp_cheques_issued_to=''TPA'' THEN ''' ||
                  v_tpa_account_no ||
                  ''' ELSE 
               (CASE WHEN h.enrol_type_id=''COR'' THEN (CASE WHEN h.tpa_cheque_issued_general_type=''IQI'' THEN ttk_util_pkg.fn_decrypt(i.bank_account_no) ELSE ttk_util_pkg.fn_decrypt(j.bank_account_no) END)
                ELSE ttk_util_pkg.fn_decrypt(i.bank_account_no) END)END 
             ELSE ttk_util_pkg.fn_decrypt(l.account_number) end) as account_num,  --Modified for koc11ed

             (CASE WHEN a.claim_type=''CTM'' AND nvl(Cad.claim_type,''MBR'')!=''HSL'' THEN--added for hyundai requirement
               CASE WHEN a.tpa_nhcp_cheques_issued_to=''TPA'' THEN ''' ||
                  v_tpa_ifsc ||
                  ''' ELSE 
               (CASE WHEN h.enrol_type_id=''COR'' THEN (CASE WHEN h.tpa_cheque_issued_general_type=''IQI'' THEN ttk_util_pkg.fn_decrypt(i.bank_ifsc) ELSE ttk_util_pkg.fn_decrypt(j.bank_ifsc) END)
                ELSE ttk_util_pkg.fn_decrypt(i.bank_ifsc) END)END
             ELSE ttk_util_pkg.fn_decrypt(l.bank_ifsc) end) as ifsc  --Modified for eft

         FROM tpa_claims_payment a 
             LEFT OUTER JOIN clm_authorization_details cad ON (a.claim_seq_id = cad.claim_seq_id)
             LEFT OUTER JOIN  tpa_enr_policy_member M  ON(cad.member_seq_id=M.member_seq_id)
             LEFT OUTER JOIN tpa_enr_policy_group  g  ON(M.policy_group_seq_id=g.policy_group_seq_id)
             LEFT OUTER JOIN tpa_enr_policy  h  ON(g.policy_seq_id=h.policy_seq_id)
             LEFT OUTER JOIN tpa_enr_bank_dtls i  ON(g.bank_seq_id=i.bank_seq_id)
             LEFT OUTER JOIN tpa_enr_bank_dtls j ON(h.bank_seq_id=j.bank_seq_id)
             LEFT OUTER JOIN tpa_hosp_info k ON(a.hosp_seq_id=k.hosp_seq_id)
             LEFT OUTER JOIN tpa_hosp_account_details l ON(k.hosp_seq_id=l.hosp_seq_id)';
    IF v_Assoc_UnAssoc = 'DBA' THEN
      -- Then get only those claims associated to a debit note.
      i := i + 1;
      bind_tab(i) := v_debit_seq_id;
      v_sql_stmt := v_sql_stmt ||
                    ' JOIN tpa_debit_note_claims_assoc f ON (a.claim_seq_id = f.claim_seq_id AND f.debit_seq_id = :v_debit_seq_id)';
    END IF;
    i := i + 1;
    bind_tab(i) := v_float_seq_id;
    v_sql_stmt := v_sql_stmt || ' WHERE a.float_seq_id = :v_float_seq_id';

    IF v_Assoc_UnAssoc = 'DBU' THEN
      -- Then get only those claims not associated to any debit note.
      v_sql_stmt := v_sql_stmt ||
                    ' AND a.claim_payment_status = ''PENDING''';
    END IF;
    IF v_claim_Settle_No IS NOT NULL THEN
      i := i + 1;
      bind_tab(i) := v_claim_Settle_No || '%';
      v_sql_stmt := v_sql_stmt ||
                    ' AND a.Claim_Settlement_No LIKE :v_claim_Settle_No';
    END IF;
    IF v_Enrollment_Id IS NOT NULL THEN
      i := i + 1;
      bind_tab(i) := v_Enrollment_Id || '%';
      v_sql_stmt := v_sql_stmt ||
                    ' AND cad.tpa_enrollment_id  LIKE :v_Enrollment_Id';
    END IF;
    IF v_claimant_name IS NOT NULL THEN
      i := i + 1;
      bind_tab(i) := v_claimant_name || '%';
      v_sql_stmt := v_sql_stmt ||
                    ' AND cad.mem_name  LIKE :v_claimant_name';
    END IF;
    IF v_claim_type IS NOT NULL THEN
      i := i + 1;
      bind_tab(i) := v_claim_type;
      v_sql_stmt := v_sql_stmt || ' AND cad.claim_type  = :v_claim_type';
    END IF;
    IF v_policy_type IS NOT NULL THEN
      i := i + 1;
      bind_tab(i) := v_policy_type;
      v_sql_stmt := v_sql_stmt || ' AND h.enrol_type_id = :v_policy_type';
    END IF;
    IF v_Payee IS NOT NULL THEN
      i := i + 1;
      bind_tab(i) := v_Payee || '%';
      v_sql_stmt := v_sql_stmt ||
                    ' AND ttk_util_pkg.fn_decrypt(a.payee_name) LIKE :v_Payee';
    END IF;
    IF v_payment_mode = 'EFT' THEN
      --Changes done for CR KOC1163
      v_sql_stmt := 'SELECT * FROM
                  (SELECT A.*,DENSE_RANK() OVER (ORDER BY ' ||
                    v_sort_var || ' ' || v_sort_order ||
                    ',ROWNUM)
                   Q FROM (' || v_sql_stmt ||
                    ') A WHERE A.account_num IS NOT NULL AND A.account_num<>''NA'' AND a.ifsc is not null) WHERE  Q>= :v_start_num  AND Q<= :v_end_num ';
    ELSIF v_payment_mode = 'PCA' THEN
      v_sql_stmt := 'SELECT * FROM
                  (SELECT A.*,DENSE_RANK() OVER (ORDER BY ' ||
                    v_sort_var || ' ' || v_sort_order ||
                    ',ROWNUM)
                   Q FROM (' || v_sql_stmt ||
                    ') A WHERE A.account_num IS  NULL OR A.account_num=''NA''OR a.ifsc is null ) WHERE  Q>= :v_start_num  AND Q<= :v_end_num ';
    ELSIF v_payment_mode IS NULL THEN
      v_sql_stmt := 'SELECT * FROM
                  (SELECT A.*,DENSE_RANK() OVER (ORDER BY ' ||
                    v_sort_var || ' ' || v_sort_order ||
                    ',ROWNUM)
                   Q FROM (' || v_sql_stmt ||
                    ') A ) WHERE  Q>= :v_start_num  AND Q<= :v_end_num ';
    END IF;
    IF bind_tab.FIRST IS NOT NULL THEN
      CASE bind_tab.COUNT
        WHEN 1 THEN
          OPEN v_result_set FOR v_sql_stmt
            USING bind_tab(1), v_start_num, v_end_num;
        WHEN 2 THEN
          OPEN v_result_set FOR v_sql_stmt
            USING bind_tab(1), bind_tab(2), v_start_num, v_end_num;
        WHEN 3 THEN
          OPEN v_result_set FOR v_sql_stmt
            USING bind_tab(1), bind_tab(2), bind_tab(3), v_start_num, v_end_num;
        WHEN 4 THEN
          OPEN v_result_set FOR v_sql_stmt
            USING bind_tab(1), bind_tab(2), bind_tab(3), bind_tab(4), v_start_num, v_end_num;
        WHEN 5 THEN
          OPEN v_result_set FOR v_sql_stmt
            USING bind_tab(1), bind_tab(2), bind_tab(3), bind_tab(4), bind_tab(5), v_start_num, v_end_num;
        WHEN 6 THEN
          OPEN v_result_set FOR v_sql_stmt
            USING bind_tab(1), bind_tab(2), bind_tab(3), bind_tab(4), bind_tab(5), bind_tab(6), v_start_num, v_end_num;
        WHEN 7 THEN
          OPEN v_result_set FOR v_sql_stmt
            USING bind_tab(1), bind_tab(2), bind_tab(3), bind_tab(4), bind_tab(5), bind_tab(6), bind_tab(7), v_start_num, v_end_num;
        WHEN 8 THEN
          OPEN v_result_set FOR v_sql_stmt
            USING bind_tab(1), bind_tab(2), bind_tab(3), bind_tab(4), bind_tab(5), bind_tab(6), bind_tab(7), bind_tab(8), v_start_num, v_end_num;
      END CASE;
    ELSE
      OPEN v_result_set FOR v_sql_stmt
        USING v_start_num, v_end_num;
    END IF;

  END get_debit_claims_list;
  --===================================================================================================
  /* Author     : R. J. Prasanna Kumar, SPAN Infotech.
     Description: This procedure is used to save the allocation of debit note and claims
                  OR remove their association.
  */
  PROCEDURE save_debit_note_claims_assoc(v_debit_seq_id  IN TPA_DEBIT_NOTE.debit_seq_id%TYPE,
                                         v_claim_seq_ids IN VARCHAR2,
                                         v_Assoc_UnAssoc IN VARCHAR2, -- DBA - Associated DBU - Unassociated
                                         v_added_by      IN NUMBER,
                                         v_row_processed OUT INTEGER) IS
    str_tab ttk_util_pkg.str_table_type;
  BEGIN
    str_tab := ttk_util_pkg.parse_str(v_claim_seq_ids);
    IF v_Assoc_UnAssoc = 'DBA' THEN
      -- Then assocaite claims to a debit note.
      FORALL i IN str_tab.FIRST .. str_tab.LAST
        INSERT INTO TPA_DEBIT_NOTE_CLAIMS_ASSOC
          (debit_claim_assoc_seq_id,
           debit_seq_id,
           claim_seq_id,
           added_by,
           added_date)
        VALUES
          (DEBIT_NOTE_CLAIM_ASSOC_SEQ.NEXTVAL,
           v_debit_seq_id,
           str_tab(i),
           v_added_by,
           SYSDATE);
      -- Update payment status of a claim so that it won't be picked thru regular payment
      -- while it is associated with a debit note.
      FORALL i IN str_tab.FIRST .. str_tab.LAST
        UPDATE tpa_claims_payment
           SET claim_payment_status = 'DEBIT_NOTE_ATTACHED'
         WHERE claim_seq_id = str_tab(i);
    ELSE
      -- Else remove the assocaition between claims and a debit note.
      FORALL i IN str_tab.FIRST .. str_tab.LAST
        DELETE FROM TPA_DEBIT_NOTE_CLAIMS_ASSOC
         WHERE debit_seq_id = v_debit_seq_id
           AND claim_seq_id = str_tab(i);
      -- Update payment status of a claim so that it can be picked thru regular payment
      FORALL i IN str_tab.FIRST .. str_tab.LAST
        UPDATE tpa_claims_payment
           SET claim_payment_status = 'PENDING'
         WHERE claim_seq_id = str_tab(i);
    END IF;
    --number of rows updated/inserted
    v_row_processed := SQL%ROWCOUNT;

    -- update sum of associated claims approved amount as debit amount.
    UPDATE tpa_debit_note
       SET debit_amount =
           (SELECT SUM(approved_amount)
              FROM tpa_claims_payment a
              JOIN tpa_debit_note_claims_assoc b
                ON (a.claim_seq_id = b.claim_seq_id AND
                   b.debit_seq_id = v_debit_seq_id))
     WHERE debit_seq_id = v_debit_seq_id;
    COMMIT;

  END save_debit_note_claims_assoc;
  --===================================================================================================
  /* Author     : R. J. Prasanna Kumar, SPAN Infotech.
     Description: This procedure lists debit notes along with deposit details
                  belonging to a perticular float account.
  */
  PROCEDURE get_debit_note_deposit_details(v_float_seq_id     IN TPA_FLOAT_ACCOUNT.float_seq_id%TYPE,
                                           v_float_trn_seq_id IN TPA_FLOAT_TRANSACTION.float_trn_seq_id%TYPE,
                                           v_result_set       OUT SYS_REFCURSOR) IS
  BEGIN
    OPEN v_result_set FOR
    -- To get total deposit amount of each debit note.
      WITH total_dep_amts AS
       (SELECT a.debit_seq_id,
               SUM(deposited_debit_amount) AS total_dep_amt,
               MAX(debit_note_trans_seq_id) AS debit_note_trans_seq_id
          FROM tpa_debit_note_transaction a
          JOIN tpa_debit_note b
            ON (a.debit_seq_id = b.debit_seq_id)
         WHERE b.float_seq_id = v_float_seq_id
         GROUP BY a.debit_seq_id),
      -- To get deposit amount of each debit note during a perticular transaction.
      trans_dep_amts AS
       (SELECT a.debit_seq_id, SUM(deposited_debit_amount) AS trans_dep_amt
          FROM tpa_debit_note_transaction a
          JOIN tpa_debit_note b
            ON (a.debit_seq_id = b.debit_seq_id)
         WHERE a.float_trn_seq_id = v_float_trn_seq_id
         GROUP BY a.debit_seq_id),
      -- To get info is all claims under a debit note is paid or not.
      trans_status AS
       (SELECT a.debit_seq_id,
               SUM(CASE
                     WHEN b.claim_seq_id IS NULL THEN
                      0
                     ELSE
                      1
                   END) AS NumOf_INP
          FROM tpa_debit_note_claims_assoc a
          LEFT OUTER JOIN tpa_claims_payment b
            ON (a.claim_seq_id = b.claim_seq_id AND
               b.claim_payment_status != 'PAID')
         GROUP BY a.debit_seq_id)

      SELECT a.debit_seq_id,
             a.debit_note_number,
             a.debit_amount,
             b.debit_note_trans_seq_id,
             b.total_dep_amt,
             (a.debit_amount - nvl(b.total_dep_amt, 0)) AS Amt_pending,
             c.trans_dep_amt,
             CASE
               WHEN d.NumOf_INP = 0 THEN
                'Y'
               ELSE
                'N'
             END AS Tran_complete_yn
        FROM tpa_debit_note a
        LEFT OUTER JOIN total_dep_amts b
          ON (a.debit_seq_id = b.debit_seq_id)
        LEFT OUTER JOIN trans_dep_amts c
          ON (a.debit_seq_id = c.debit_seq_id)
        LEFT OUTER JOIN trans_status d
          ON (a.debit_seq_id = d.debit_seq_id)
       WHERE debit_status_general_type_id = 'DFL'
         AND a.debit_date <=
             (SELECT flt_trn_date
                FROM tpa_float_transaction
               WHERE float_trn_seq_id = v_float_trn_seq_id)
         AND a.float_seq_id = v_float_seq_id;

  END get_debit_note_deposit_details;
  --===================================================================================================
  /* Author     : R. J. Prasanna Kumar, SPAN Infotech.
     Description: This procedure saves to db a deposit transaction of a debit note.
  */
  PROCEDURE save_debit_note_deposit_dtl(v_float_trn_seq_id IN TPA_FLOAT_TRANSACTION.float_trn_seq_id%TYPE,
                                        v_debit_seq_id     IN TPA_DEBIT_NOTE.debit_seq_id%TYPE,
                                        v_deposited_amt    IN TPA_DEBIT_NOTE_TRANSACTION.deposited_debit_amount%TYPE,
                                        v_flag             IN VARCHAR2,
                                        v_added_by         IN NUMBER) IS
    v_deposit_amt TPA_DEBIT_NOTE_TRANSACTION.deposited_debit_amount%TYPE := v_deposited_amt;
  BEGIN

    IF v_flag != 'ADD' THEN
      -- Then it is withdraw and it is stored as -ve amount in the table
      --- To check debit note dep. amt. is not less than that of its claims amounts in a transation.
      SELECT sum(deposited_debit_amount) - v_deposited_amt
        INTO v_deposit_amt
        FROM tpa_debit_note_transaction
       WHERE float_trn_seq_id = v_float_trn_seq_id
         AND debit_seq_id = v_debit_seq_id;

      SELECT v_deposit_amt - SUM(nvl(a.deposited_amount, 0))
        INTO v_deposit_amt
        FROM tpa_debit_note_transaction b
        LEFT OUTER JOIN tpa_debit_claims_transaction a
          ON (a.debit_note_trans_seq_id = b.debit_note_trans_seq_id)
       WHERE b.float_trn_seq_id = v_float_trn_seq_id
         AND b.debit_seq_id = v_debit_seq_id;

      IF v_deposit_amt >= 0 THEN
        v_deposit_amt := v_deposited_amt * (-1);
      ELSE
        raise_application_error(-20256,
                                'Debit Note trans. amt. cannot go below its claim amounts.');
      END IF;
    END IF;
    IF v_deposit_amt IS NOT NULL THEN
      INSERT INTO TPA_DEBIT_NOTE_TRANSACTION
        (debit_note_trans_seq_id,
         float_trn_seq_id,
         debit_seq_id,
         deposited_debit_amount,
         added_by,
         added_date)
      VALUES
        (DEBIT_NOTE_TRANS_SEQ.NEXTVAL,
         v_float_trn_seq_id,
         v_debit_seq_id,
         v_deposit_amt,
         v_added_by,
         SYSDATE);
    END IF;
  END save_debit_note_deposit_dtl;
  --===================================================================================================
  /* Author     : R. J. Prasanna Kumar, SPAN Infotech.
     Description: This procedure lists claims along with deposit details
                  belonging to a perticular debit note.
  */
  PROCEDURE get_claims_deposit_details(v_debit_seq_id     IN TPA_DEBIT_NOTE.debit_seq_id%TYPE,
                                       v_float_trn_seq_id IN TPA_FLOAT_TRANSACTION.float_trn_seq_id%TYPE,
                                       v_result_set       OUT SYS_REFCURSOR) IS
  BEGIN
    OPEN v_result_set FOR
    -- To get total deposit amount of each claim.
      WITH total_dep_amts AS
       (SELECT b.claim_seq_id, SUM(b.deposited_amount) AS total_dep_amt
          FROM tpa_debit_note_claims_assoc a
          JOIN tpa_debit_claims_transaction b
            ON (a.claim_seq_id = b.claim_seq_id)
         WHERE a.debit_seq_id = v_debit_seq_id
         GROUP BY b.claim_seq_id),
      -- To get deposit amount of each claim during a perticular transaction.
      trans_dep_amts AS
       (SELECT b.claim_seq_id, SUM(b.deposited_amount) AS trans_dep_amt
          FROM tpa_debit_note_claims_assoc a
          JOIN tpa_debit_claims_transaction b
            ON (a.claim_seq_id = b.claim_seq_id)
          JOIN tpa_debit_note_transaction c
            ON (b.debit_note_trans_seq_id = c.debit_note_trans_seq_id)
         WHERE c.float_trn_seq_id = v_float_trn_seq_id
           AND a.debit_seq_id = v_debit_seq_id
         GROUP BY b.claim_seq_id)
      SELECT a.claim_seq_id,
             b.claim_settlement_no,
             b.approved_amount,
             c.total_dep_amt,
             (b.approved_amount - nvl(c.total_dep_amt, 0)) AS Amt_pending,
             d.trans_dep_amt,
             CASE
               WHEN claim_payment_status = 'PAID' THEN
                'Y'
               ELSE
                'N'
             END AS Tran_complete_yn
        FROM tpa_debit_note_claims_assoc a
        LEFT OUTER JOIN tpa_claims_payment b
          ON (a.claim_seq_id = b.claim_seq_id)
        LEFT OUTER JOIN total_dep_amts c
          ON (a.claim_seq_id = c.claim_seq_id)
        LEFT OUTER JOIN trans_dep_amts d
          ON (a.claim_seq_id = d.claim_seq_id)
       WHERE a.debit_seq_id = v_debit_seq_id;

  END get_claims_deposit_details;
  --===================================================================================================
  /* Author     : R. J. Prasanna Kumar, SPAN Infotech.
     Description: This procedure saves to db a deposit transaction of a claim.
  */
  PROCEDURE save_claims_deposit_dtl(v_debit_note_trans_seq_id IN TPA_DEBIT_NOTE_TRANSACTION.debit_note_trans_seq_id%TYPE,
                                    v_claim_seq_id            IN TPA_DEBIT_CLAIMS_TRANSACTION.claim_seq_id%TYPE,
                                    v_deposited_amt           IN TPA_DEBIT_CLAIMS_TRANSACTION.deposited_amount%TYPE,
                                    v_flag                    IN VARCHAR2,
                                    v_added_by                IN NUMBER) IS
    v_deposit_amt TPA_DEBIT_CLAIMS_TRANSACTION.deposited_amount%TYPE := v_deposited_amt;
  BEGIN

    IF v_flag != 'ADD' THEN
      -- Then it is withdraw and it is stored as -ve amount in the table
      v_deposit_amt := v_deposit_amt * (-1);
    END IF;

    IF v_deposit_amt IS NOT NULL THEN
      INSERT INTO TPA_DEBIT_CLAIMS_TRANSACTION
        (debit_claim_trans_seq_id,
         debit_note_trans_seq_id,
         claim_seq_id,
         deposited_amount,
         added_by,
         added_date)
      VALUES
        (DEBIT_CLAIM_TRANS_SEQ.NEXTVAL,
         v_debit_note_trans_seq_id,
         v_claim_seq_id,
         v_deposit_amt,
         v_added_by,
         SYSDATE);
    END IF;
  END save_claims_deposit_dtl;
  --===================================================================================================
  /* Author     : R. J. Prasanna Kumar, SPAN Infotech.
     Description: This procedure deletes debit note if there is no claim associated with it.
  */
  PROCEDURE delete_debit_notes(v_debit_seq_id  IN VARCHAR2,
                               v_added_by      IN NUMBER,
                               v_row_processed OUT INTEGER) IS
    str_tab ttk_util_pkg.str_table_type;
  BEGIN
    str_tab := ttk_util_pkg.parse_str(v_debit_seq_id);

    FORALL i IN str_tab.FIRST .. str_tab.LAST
      DELETE FROM TPA_DEBIT_NOTE WHERE debit_seq_id = str_tab(i);

    IF SQL%ROWCOUNT != STR_TAB.COUNT THEN
      raise_application_error(-20254,
                              'Cannot delete a Debit Note while claim(s) are associated');
    END IF;

    --number of rows updated/inserted
    v_row_processed := SQL%ROWCOUNT;
    COMMIT;
  END delete_debit_notes;
  --===================================================================================================
  /* Author     : Ramakrishna K M, SPAN Infotech.
     Description: This procedure searches the invoice.
  */
  PROCEDURE select_invoices_dtl_list(v_invoice_number             IN TPA_FIN_INVOICE.invoice_number%TYPE,
                                     v_from_date                  IN VARCHAR2,
                                     v_to_date                    IN VARCHAR2,
                                     v_inv_status_general_type_id IN TPA_FIN_INVOICE.inv_status_general_type_id%TYPE,
                                  	 v_group_id                   IN app.tpa_group_registration.group_id%type,
                                     v_group_name                 IN app.tpa_group_registration.group_name%type,
                                     v_policy_number              IN app.tpa_enr_policy.policy_number%type,
                                     v_sort_var                   IN VARCHAR2,
                                     v_sort_order                 IN VARCHAR2,
                                     v_start_num                  IN NUMBER,
                                     v_end_num                    IN NUMBER,
                                     v_added_by                   IN NUMBER,
                                     v_result_set                 OUT SYS_REFCURSOR) IS
    TYPE bind_tab_type IS TABLE OF VARCHAR2(250) INDEX BY BINARY_INTEGER;
    v_inv_start_date DATE := TO_DATE(v_from_date, 'dd/mm/yyyy');
    v_inv_to_date    DATE := TO_DATE(v_to_date, 'dd/mm/yyyy');
    v_sql_str        VARCHAR2(4000);
    v_where          VARCHAR2(2000);
    bind_tab         bind_tab_type;
    i                NUMBER(2) := 0;
  BEGIN
    v_sql_str := 'SELECT A.invoice_seq_id,
       A.invoice_number,
       A.inv_from_date,
       A.inv_to_date,
       A.inv_status_general_type_id,
       B.description AS status,
       --(SELECT COUNT(1) FROM tpa_fin_policy_details WHERE invoice_seq_id = A.invoice_seq_id) AS NumOfPolicies,
       IB.NO_OF_TRANSATIONS,
       reg.group_id,
       reg.group_name,
       pol.policy_number
       FROM tpa_fin_invoice A JOIN tpa_general_code B ON (A.inv_status_general_type_id=B.general_type_id)
       LEFT OUTER JOIN tpa_inv_batch IB ON (A.INVOICE_SEQ_ID=IB.INVOICE_SEQ_ID) 
       LEFT OUTER JOIN tpa_group_registration REG ON (A.Group_Reg_Seq_Id = REG.Group_Reg_Seq_Id)
       LEFT OUTER JOIN tpa_enr_policy pol ON (pol.policy_seq_id = a.policy_seq_id) ';

    IF v_invoice_number IS NOT NULL THEN
      v_where := v_where || ' AND invoice_number LIKE :v_invoice_number ';
      i := i + 1;
      bind_tab(i) := v_invoice_number || '%';
    END IF;
    IF v_inv_start_date IS NOT NULL THEN
      v_where := v_where || ' AND inv_from_date  >= :v_inv_start_date ';
      i := i + 1;
      bind_tab(i) := v_inv_start_date;
    END IF;
    IF v_inv_to_date IS NOT NULL THEN
      v_where := v_where || ' AND inv_to_date  <= :v_inv_to_date ';
      i := i + 1;
      bind_tab(i) := v_inv_to_date;
    END IF;
    IF v_inv_status_general_type_id IS NOT NULL THEN
      v_where := v_where ||
                 ' AND inv_status_general_type_id  = :v_inv_status_general_type_id ';
      i := i + 1;
      bind_tab(i) := v_inv_status_general_type_id;
    END IF;
    
    IF v_group_id IS NOT NULL THEN
      v_where     := v_where||' AND reg.group_id = :v_group_id ';
      i           := i + 1;
      bind_tab(i) := TRIM(upper(v_group_id)); 
    END IF;
    IF v_group_name IS NOT NULL THEN
      v_where     := v_where||' AND reg.group_name LIKE :v_group_name ';
      i           := i + 1;
      bind_tab(i) := '%'||upper(TRIM(v_group_name))||'%';
    END IF;
    IF v_policy_number IS NOT NULL THEN
      v_where     := v_where||' AND pol.POLICY_NUMBER = :v_policy_number ';
      i           := i + 1;
      bind_tab(i) := upper(trim(v_policy_number));
    END IF;
    
    IF v_where IS NOT NULL THEN
      v_where := ' WHERE ' || SUBSTR(v_where, 5);
    END IF;
    v_sql_str := v_sql_str || v_where;

    v_sql_str := 'SELECT * FROM
            (SELECT A.*,DENSE_RANK() OVER (ORDER BY ' ||
                 v_sort_var || ' ' || v_sort_order || ',ROWNUM) Q FROM (' ||
                 v_sql_str ||
                 ') A )
             WHERE  Q>= :v_start_num AND Q<= :v_end_num ';
    IF bind_tab.FIRST IS NOT NULL THEN
      CASE bind_tab.COUNT
        WHEN 1 THEN
          OPEN v_result_set FOR v_sql_str
            USING bind_tab(1), v_start_num, v_end_num;
        WHEN 2 THEN
          OPEN v_result_set FOR v_sql_str
            USING bind_tab(1), bind_tab(2), v_start_num, v_end_num;
        WHEN 3 THEN
          OPEN v_result_set FOR v_sql_str
            USING bind_tab(1), bind_tab(2), bind_tab(3), v_start_num, v_end_num;
        WHEN 4 THEN
          OPEN v_result_set FOR v_sql_str
            USING bind_tab(1), bind_tab(2), bind_tab(3), bind_tab(4), v_start_num, v_end_num;
        WHEN 5 THEN
          OPEN v_result_set FOR v_sql_str
            USING bind_tab(1), bind_tab(2), bind_tab(3), bind_tab(4),bind_tab(5), v_start_num, v_end_num;          
        WHEN 6 THEN
          OPEN v_result_set FOR v_sql_str
            USING bind_tab(1), bind_tab(2), bind_tab(3), bind_tab(4),bind_tab(5),bind_tab(6), v_start_num, v_end_num; 
        WHEN 7 THEN
          OPEN v_result_set FOR v_sql_str
            USING bind_tab(1), bind_tab(2), bind_tab(3), bind_tab(4),bind_tab(5),bind_tab(6), bind_tab(7), v_start_num, v_end_num;
      END CASE;
    ELSE
      OPEN v_result_set FOR v_sql_str
        USING v_start_num, v_end_num;
    END IF;
  END select_invoices_dtl_list;
  --===================================================================================================
  /* Author     : Ramakrishna K M, SPAN Infotech.
     Description: This procedure fetch the invoice information.
  */
  PROCEDURE select_invoices_dtl(v_invoice_seq_id IN TPA_FIN_INVOICE.invoice_seq_id%TYPE,
                                v_added_by       IN NUMBER,
                                v_result_set     OUT SYS_REFCURSOR) IS
  BEGIN
    OPEN v_result_set FOR
      SELECT A.invoice_seq_id,
             A.invoice_number,
             A.inv_from_date,
             A.inv_to_date,
             A.inv_status_general_type_id,
             A.include_old_yn,
             (SELECT batch_seq_id
                FROM tpa_fin_policy_details c
               WHERE c.invoice_seq_id = A.invoice_seq_id
                 AND rownum = 1) AS batch_seq_id,
            a.group_reg_seq_id,
            gr.group_name,gr.group_id,a.policy_seq_id,EP.POLICY_NUMBER,
            A.INV_GEN_PERIOD,A.DUE_DATE_1,A.DUE_DATE_2,A.DUE_DATE_3,A.DUE_DATE_4,
            CASE WHEN IB.BATCH_SEQ_ID IS NULL THEN 'N' ELSE 'Y' END AS INV_GEN_YN,
            A.INVOICE_TYPE AS inv_type
        FROM tpa_fin_invoice A
        JOIN tpa_general_code B
          ON (A.inv_status_general_type_id = B.general_type_id)
        JOIN app.tpa_group_registration gr ON (a.group_reg_seq_id=gr.group_reg_seq_id)  
        JOIN APP.TPA_ENR_POLICY EP ON (A.POLICY_SEQ_ID=EP.POLICY_SEQ_ID)
        LEFT OUTER JOIN tpa_inv_batch IB ON (A.INVOICE_SEQ_ID=IB.INVOICE_SEQ_ID)
       WHERE a.invoice_seq_id = v_invoice_seq_id;

  END select_invoices_dtl;
  --===================================================================================================
  /* Author     : R. J. Prasanna Kumar, SPAN Infotech.
     Description: This procedure is used to save details of an invoice.
  */
  PROCEDURE save_invoice_dtl(v_invoice_seq_id             IN OUT TPA_FIN_INVOICE.invoice_seq_id%TYPE,
                             v_inv_from_date              IN TPA_FIN_INVOICE.inv_from_date%TYPE,
                             v_inv_to_date                IN TPA_FIN_INVOICE.inv_to_date%TYPE,
                             v_inv_status_general_type_id IN TPA_FIN_INVOICE.inv_status_general_type_id%TYPE,
                             v_include_old_yn             IN TPA_FIN_INVOICE.include_old_yn%TYPE,
                             v_added_by                   IN TPA_FIN_INVOICE.added_by%TYPE,
                             v_group_reg_seq_id           IN tpa_fin_policy_details.group_reg_seq_id%TYPE,
                             v_policy_seq_id              IN tpa_enr_policy.policy_seq_id%TYPE,
                             v_inv_gen_period             IN tpa_fin_invoice.inv_gen_period%TYPE, 
                             v_due_date_1                 IN DATE,
                             v_due_date_2                 IN DATE,
                             v_due_date_3                 IN DATE,
                             v_due_date_4                 IN DATE,
                             v_inv_type                   IN VARCHAR2,
                             v_row_processed              OUT INTEGER) IS
  
  BEGIN
    
    IF nvl(v_invoice_seq_id, 0) = 0 THEN
      --- it is for creating new invoice details.
      INSERT INTO tpa_fin_invoice
        (invoice_seq_id,
         invoice_number,
         inv_from_date,
         inv_to_date,
         inv_status_general_type_id,
         include_old_yn,
         added_by,
         added_date,
         group_reg_seq_id,
         policy_seq_id,
         inv_gen_period,
         inv_no_period_1,
         inv_no_period_2,
         inv_no_period_3,
         inv_no_period_4,
         DUE_DATE_1,
         DUE_DATE_2,
         DUE_DATE_3,
         DUE_DATE_4,
         INVOICE_TYPE,
         TRANS_REF_NUM
         )
      VALUES
        (FIN_INVOICE_SEQ.NEXTVAL,
         CASE WHEN v_inv_type = 'ADD' THEN 'INV-' ELSE 'CN-' END || to_char(FIN_INVOICE_SEQ.CURRVAL),
         v_inv_from_date,
         v_inv_to_date,
         v_inv_status_general_type_id,
         v_include_old_yn,
         v_added_by,
         SYSDATE,
         v_group_reg_seq_id,
         v_policy_seq_id,
         v_inv_gen_period,
         CASE WHEN v_inv_type = 'ADD' THEN 'INV-'||
                   CASE WHEN v_inv_gen_period IN ('QTR','HLF') THEN to_char(FIN_INVOICE_SEQ.CURRVAL)||'/A'
                        ELSE to_char(FIN_INVOICE_SEQ.CURRVAL) END
              ELSE 'CN-'||to_char(FIN_INVOICE_SEQ.CURRVAL)
                END,
         CASE WHEN v_inv_type = 'ADD' AND v_inv_gen_period IN ('QTR','HLF') THEN 'INV-'||to_char(FIN_INVOICE_SEQ.CURRVAL)||'/B'
              ELSE NULL END, 
         CASE WHEN v_inv_type = 'ADD' AND v_inv_gen_period IN ('QTR') THEN 'INV-'||to_char(FIN_INVOICE_SEQ.CURRVAL)||'/C'
              ELSE NULL END,       
         CASE WHEN v_inv_type = 'ADD' AND v_inv_gen_period IN ('QTR') THEN 'INV-'||to_char(FIN_INVOICE_SEQ.CURRVAL)||'/D'
              ELSE NULL END,     
         v_due_date_1,
         v_due_date_2,
         v_due_date_3,
         v_due_date_4,
         v_inv_type,
         '088'||LPAD(FIN_APP.INVOICE_ERP_SEQUENCE_VAL.NEXTVAL,10,0)||TO_CHAR(SYSDATE,'MMYYYY')  
           )
      RETURNING invoice_seq_id INTO v_invoice_seq_id;
      
    ELSE
      --  it is for updating existing invoice.
     

      IF (v_inv_status_general_type_id = 'DFL' AND v_policy_seq_id > 0) OR
         v_inv_status_general_type_id != 'DFL' THEN
        UPDATE tpa_fin_invoice
           SET inv_status_general_type_id = v_inv_status_general_type_id,
               include_old_yn             = v_include_old_yn,
               inv_from_date              = v_inv_from_date,
               inv_to_date                = v_inv_to_date,
               updated_by   = v_added_by,
               updated_date = SYSDATE,
               group_reg_seq_id = v_group_reg_seq_id,
               policy_seq_id    = v_policy_seq_id,
               inv_gen_period   = v_inv_gen_period,
               inv_no_period_1  = CASE WHEN v_inv_gen_period IN ('QTR','HLF') THEN invoice_number||'/A' ELSE invoice_number END,
               inv_no_period_2  = CASE WHEN v_inv_gen_period IN ('QTR','HLF') THEN invoice_number||'/B' ELSE NULL END,
               inv_no_period_3  = CASE WHEN v_inv_gen_period IN ('QTR')   THEN invoice_number||'/C' ELSE NULL END,
               inv_no_period_4  = CASE WHEN v_inv_gen_period IN ('QTR')   THEN invoice_number||'/D' ELSE NULL END,
               DUE_DATE_1       = v_due_date_1,
               DUE_DATE_2       = v_due_date_2,
               DUE_DATE_3       = v_due_date_3,
               DUE_DATE_4       = v_due_date_4,
               INVOICE_TYPE     = v_inv_type
         WHERE invoice_seq_id = v_invoice_seq_id;
      ELSE
        raise_application_error(-20258,
                                'Associate at least a policy to an invoice to make it final.');
      END IF;
    END IF;
    
   IF v_inv_type = 'ADD' THEN  
    IF v_include_old_yn = 'N' THEN
          FOR j IN (SELECT M.MEMBER_SEQ_ID
                        FROM APP.TPA_ENR_POLICY EP 
                        JOIN APP.TPA_ENR_POLICY_GROUP PG ON (EP.POLICY_SEQ_ID=PG.POLICY_SEQ_ID)
                        JOIN APP.TPA_ENR_POLICY_MEMBER M ON (PG.POLICY_GROUP_SEQ_ID=M.POLICY_GROUP_SEQ_ID)
                        WHERE EP.POLICY_SEQ_ID = v_policy_seq_id
                          AND TRUNC(M.ADDED_DATE) BETWEEN v_inv_from_date AND v_inv_to_date
                          AND M.DELETED_YN = 'N' 
                          AND NVL(M.INV_TO_BE_GEN_YN,'N') = 'Y'
                          )
          LOOP
            UPDATE app.tpa_enr_policy_member m 
              SET m.INV_CURNT_SEQ_ID  = v_invoice_seq_id
            WHERE m. member_seq_id = j.member_seq_id;
          END LOOP;
    ELSE
           FOR j IN (SELECT M.MEMBER_SEQ_ID
                        FROM APP.TPA_ENR_POLICY EP 
                        JOIN APP.TPA_ENR_POLICY_GROUP PG ON (EP.POLICY_SEQ_ID=PG.POLICY_SEQ_ID)
                        JOIN APP.TPA_ENR_POLICY_MEMBER M ON (PG.POLICY_GROUP_SEQ_ID=M.POLICY_GROUP_SEQ_ID)
                        WHERE EP.POLICY_SEQ_ID = v_policy_seq_id
                          AND M.DELETED_YN = 'N' AND NVL(M.INV_TO_BE_GEN_YN,'N') = 'Y'
                          AND TRUNC(M.ADDED_DATE) <= v_inv_to_date)
            LOOP
              UPDATE app.tpa_enr_policy_member m 
                SET m.INV_CURNT_SEQ_ID  = v_invoice_seq_id
              WHERE m. member_seq_id = j.member_seq_id;
           END LOOP;
    END IF; 
   ELSE
          FOR j IN (SELECT M.MEMBER_SEQ_ID
                       FROM APP.TPA_ENR_POLICY EP 
                       JOIN APP.TPA_ENR_POLICY_GROUP PG ON (EP.POLICY_SEQ_ID=PG.POLICY_SEQ_ID)
                       JOIN APP.TPA_ENR_POLICY_MEMBER M ON (PG.POLICY_GROUP_SEQ_ID=M.POLICY_GROUP_SEQ_ID)
                        WHERE EP.POLICY_SEQ_ID = v_policy_seq_id
                          AND ((TRUNC(M.DATE_OF_EXIT) <= TRUNC(v_inv_from_date-EP.MEM_CANCL_DAYS) AND NVL(M.CRN_TO_BE_GEN_ON_CNCL_YN,'N') = 'Y' AND get_mem_clm_inp_cnt(M.MEMBER_SEQ_ID) = 0)/* OR (NVL(M.CRN_TO_BE_GEN_YN,'N') = 'Y')*/)
                          AND M.DELETED_YN = 'N' 
                      )
          LOOP
            UPDATE app.tpa_enr_policy_member m 
              SET m.CRN_CURNT_SEQ_ID  = v_invoice_seq_id
            WHERE m. member_seq_id = j.member_seq_id;
          END LOOP;
    
    END IF; 

    --number of rows updated/inserted
    v_row_processed := SQL%ROWCOUNT;
    COMMIT;

  END save_invoice_dtl;
  --=============================================================================================================================================
  --dispalying all the list to be invoiced.
  PROCEDURE select_inv_policy_list(v_group_reg_seq_id  IN tpa_fin_policy_details.group_reg_seq_id%TYPE,
                                   v_IND_YN            IN VARCHAR2,
                                   v_COR_YN            IN VARCHAR2,
                                   v_ING_YN            IN VARCHAR2,
                                   v_NCR_YN            IN VARCHAR2,
                                   v_tpa_office_seq_id IN tpa_office_info.tpa_office_seq_id%TYPE,
                                   v_from_date         IN VARCHAR2,
                                   v_to_date           IN VARCHAR2,
                                   v_Assoc_UnAssoc     IN VARCHAR2, -- DBA - Associated DBU - Unassociated
                                   v_invoice_seq_id    IN TPA_FIN_INVOICE.invoice_seq_id%TYPE,
                                   v_include_old_yn    IN TPA_FIN_INVOICE.include_old_yn%TYPE,
                                   v_added_by          IN NUMBER,
                                   v_inv_type          IN VARCHAR2,
                                   v_sort_var          IN VARCHAR2,
                                   v_sort_order        IN VARCHAR2,
                                   v_start_num         IN NUMBER,
                                   v_end_num           IN NUMBER,
                                   v_result_set        OUT SYS_REFCURSOR) IS
    v_sql_str       VARCHAR2(10000);
    v_enrol_type_id VARCHAR2(40) := '(';
    TYPE bind_tab_type IS TABLE OF VARCHAR2(250) INDEX BY BINARY_INTEGER;
    bind_tab bind_tab_type;
    i        NUMBER(2) := 0;
  BEGIN
    
  IF v_inv_type = 'DEL' THEN 
    v_sql_str := 'WITH CLAIM_DATA AS
                  (SELECT C.POLICY_SEQ_ID,
                         TO_CHAR(C.POLICY_ISSUE_DATE,''DD/MM/YYYY'') AS POLICY_ISSUE_DATE,
                         C.POLICY_NUMBER,
                         P.PRODUCT_NAME,
                         c.Effective_From_Date,
                         C.EFFECTIVE_TO_DATE,
                         m.date_of_inception,
                         M.DATE_OF_EXIT,
                         M.MEM_TOTAL_PREMIUM,
                         FLOAT_ACCOUNTS_PKG.get_claimed_amount(M.MEMBER_SEQ_ID) AS CLM_AMOUNT,
                         ROUND(((TRUNC(C.EFFECTIVE_TO_DATE) - TRUNC(M.DATE_OF_EXIT))+1)* 
                          (NVL(M.MEM_TOTAL_PREMIUM,0)/((TRUNC(c.effective_to_date)- 
                          CASE WHEN c.Effective_From_Date > m.date_of_inception THEN TRUNC(c.Effective_From_Date) 
                               ELSE TRUNC(m.date_of_inception) END)+1)),2) AS PRO_RTA_PREMIUM,
                            
                            (CASE WHEN C.logic_type_id = ''SC1'' 
                                       THEN CASE WHEN FLOAT_ACCOUNTS_PKG.get_claimed_amount(M.MEMBER_SEQ_ID) > ROUND(((TRUNC(C.EFFECTIVE_TO_DATE) - TRUNC(M.DATE_OF_EXIT)) + CASE WHEN TRUNC(M.DATE_OF_INCEPTION) = TRUNC(M.DATE_OF_EXIT) THEN 1 ELSE 0 END)* 
                                                      NVL(M.MEM_TOTAL_PREMIUM,0)/((TRUNC(C.effective_to_date)- CASE WHEN C.Effective_From_Date > m.date_of_inception THEN TRUNC(C.Effective_From_Date) ELSE TRUNC(m.date_of_inception) END)+1),2) 
                                                      THEN 0
                                                 ELSE
                                                      ROUND(((TRUNC(C.EFFECTIVE_TO_DATE) - TRUNC(M.DATE_OF_EXIT)) + CASE WHEN TRUNC(M.DATE_OF_INCEPTION) = TRUNC(M.DATE_OF_EXIT) THEN 1 ELSE 0 END)* 
                                                      NVL(M.MEM_TOTAL_PREMIUM,0)/((TRUNC(C.effective_to_date)- CASE WHEN C.Effective_From_Date > m.date_of_inception THEN TRUNC(C.Effective_From_Date) ELSE TRUNC(m.date_of_inception) END)+1),2) 
                                                      - FLOAT_ACCOUNTS_PKG.get_claimed_amount(M.MEMBER_SEQ_ID)
                                                 END
                                                 
                                  WHEN C.logic_type_id = ''SC2'' 
                                       THEN CASE WHEN FLOAT_ACCOUNTS_PKG.get_mem_clm_cnt(M.MEMBER_SEQ_ID) > 0 THEN 0
                                                 ELSE ROUND(((TRUNC(C.EFFECTIVE_TO_DATE) - TRUNC(M.DATE_OF_EXIT))+1)* 
                                                   NVL(M.MEM_TOTAL_PREMIUM,0)/((TRUNC(C.effective_to_date)- CASE WHEN C.Effective_From_Date > m.date_of_inception THEN TRUNC(C.Effective_From_Date) ELSE TRUNC(m.date_of_inception) END)+1),2)
                                            END 
                                  WHEN C.logic_type_id = ''SC3'' 
                                       THEN CASE WHEN FLOAT_ACCOUNTS_PKG.get_mem_clm_cnt(M.MEMBER_SEQ_ID) > 0 THEN
                                              ROUND(((TRUNC(C.EFFECTIVE_TO_DATE) - TRUNC(M.DATE_OF_EXIT))+1)* 
                                                   NVL(M.MEM_TOTAL_PREMIUM,0)/((TRUNC(C.effective_to_date)- 
                                                   CASE WHEN C.Effective_From_Date > m.date_of_inception THEN TRUNC(C.Effective_From_Date) 
                                                        ELSE TRUNC(m.date_of_inception) END)+1),2) END 
                                  
                                  WHEN C.logic_type_id = ''SC4'' 
                                       THEN CASE WHEN FLOAT_ACCOUNTS_PKG.get_claimed_amount(M.MEMBER_SEQ_ID) > ROUND(((TRUNC(C.EFFECTIVE_TO_DATE) - TRUNC(M.DATE_OF_EXIT))+1)* 
                                                                                                                NVL(M.MEM_TOTAL_PREMIUM,0)/((TRUNC(C.effective_to_date)- 
                                                                                                                CASE WHEN C.Effective_From_Date > m.date_of_inception THEN TRUNC(C.Effective_From_Date)
                                                                                                                     ELSE TRUNC(m.date_of_inception) END)+1),2) THEN 0
                                                 ELSE ROUND(((TRUNC(C.EFFECTIVE_TO_DATE) - TRUNC(M.DATE_OF_EXIT))+1)* 
                                                   NVL(M.MEM_TOTAL_PREMIUM,0)/((TRUNC(C.effective_to_date)- 
                                                   CASE WHEN C.Effective_From_Date > m.date_of_inception THEN TRUNC(C.Effective_From_Date) 
                                                        ELSE TRUNC(m.date_of_inception) END)+1),2) END 
                                END) * (F.COMMISSION_TO_TPA/100) AS COMMISSION_AMT,
                         F.COMMISSION_TO_TPA        
                  FROM TPA_ENR_POLICY C 
                  JOIN TPA_GROUP_REGISTRATION G ON ( C.GROUP_REG_SEQ_ID = G.GROUP_REG_SEQ_ID)
                  JOIN TPA_INS_PRODUCT P ON (C.PRODUCT_SEQ_ID=P.PRODUCT_SEQ_ID)
                  JOIN TPA_INS_INFO D ON (C.INS_SEQ_ID = D.INS_SEQ_ID)
                  JOIN TPA_OFFICE_INFO E ON (C.TPA_OFFICE_SEQ_ID = E.TPA_OFFICE_SEQ_ID )
                  JOIN TPA_INS_ASSOC_OFF_PRODUCT F ON (F.INS_SEQ_ID = C.INS_SEQ_ID AND C.PRODUCT_SEQ_ID = F.PRODUCT_SEQ_ID AND F.ENROL_TYPE_ID = C.ENROL_TYPE_ID)
                  JOIN APP.TPA_ENR_POLICY_GROUP PG ON (C.POLICY_SEQ_ID=PG.POLICY_SEQ_ID)
                  JOIN APP.TPA_ENR_POLICY_MEMBER M ON (PG.POLICY_GROUP_SEQ_ID=M.POLICY_GROUP_SEQ_ID )
                  WHERE C.POLICY_ISSUE_DATE BETWEEN F.VALID_FROM AND NVL(F.VALID_TO, C.POLICY_ISSUE_DATE )
                  AND M.DELETED_YN = ''N''
                  AND C.COMPLETED_YN = ''Y''
                  --AND NVL(M.CRN_TO_BE_GEN_YN,''N'') = ''Y''
                  AND M.INV_LNKED_SEQ_IDS IS NOT NULL
                  AND M.CRN_CURNT_SEQ_ID IS NULL
                  AND NVL(M.MEM_TOTAL_PREMIUM,0) != 0';

    
    IF (v_group_reg_seq_id) IS NOT NULL THEN
      i := i + 1;
      bind_tab(i) := v_group_reg_seq_id;
      v_sql_str := v_sql_str ||
                   ' AND C.group_reg_seq_id = :v_group_reg_seq_id';
    END IF;

    IF v_IND_YN = 'Y' THEN
      v_enrol_type_id := v_enrol_type_id || '''IND'',';
    END IF;
    IF v_COR_YN = 'Y' THEN
      v_enrol_type_id := v_enrol_type_id || '''COR'',';
    END IF;
    IF v_ING_YN = 'Y' THEN
      v_enrol_type_id := v_enrol_type_id || '''ING'',';
    END IF;
    IF v_NCR_YN = 'Y' THEN
      v_enrol_type_id := v_enrol_type_id || '''NCR'',';
    END IF;

    IF length(v_enrol_type_id) > 5 THEN
      v_sql_str := v_sql_str || ' AND C.enrol_type_id IN ' ||
                   substr(v_enrol_type_id, 1, (length(v_enrol_type_id)) - 1) || ')';
    END IF;

    IF (v_tpa_office_seq_id) IS NOT NULL THEN
      i := i + 1;
      bind_tab(i) := v_tpa_office_seq_id;
      v_sql_str := v_sql_str ||
                   ' AND E.tpa_office_seq_id = :v_tpa_office_seq_id';
    END IF;
    
    --IF v_include_old_yn = 'N' AND v_Assoc_UnAssoc != 'DBA' THEN
    IF v_from_date IS NOT NULL THEN
      i := i + 1;
      bind_tab(i) := TRUNC(to_date(v_from_date, 'DD/MM/YYYY'));
      v_sql_str := v_sql_str || ' AND ((to_date(TRUNC(M.DATE_OF_EXIT), ''DD/MM/YYYY'') <=  to_date(:v_from_date, ''DD/MM/YYYY'') - C.MEM_CANCL_DAYS AND NVL(M.CRN_TO_BE_GEN_ON_CNCL_YN,''N'') = ''Y'' AND FLOAT_ACCOUNTS_PKG.get_mem_clm_inp_cnt(M.MEMBER_SEQ_ID) = 0) /*OR (NVL(M.CRN_TO_BE_GEN_YN,''N'') = ''Y'')*/)';
    END IF;
    
    
    v_sql_str := v_sql_str || ' )
                                SELECT POLICY_SEQ_ID,
                                       POLICY_ISSUE_DATE,
                                       POLICY_NUMBER,
                                       PRODUCT_NAME,
                                       EFFECTIVE_FROM_DATE,
                                       EFFECTIVE_TO_DATE,
                                       SUM(CLM_AMOUNT) AS CLM_AMOUNT,
                                       SUM(PRO_RTA_PREMIUM-CLM_AMOUNT) AS NET_PREMIUM,
                                       SUM(COMMISSION_TO_TPA) AS COMMISSION,
                                       SUM(COMMISSION_AMT) AS COMMISSION_AMT
                                FROM CLAIM_DATA CD
                                --WHERE CD.PRO_RTA_PREMIUM > CLM_AMOUNT
                                GROUP BY POLICY_SEQ_ID,
                                       POLICY_ISSUE_DATE,
                                       POLICY_NUMBER,
                                       PRODUCT_NAME,
                                       EFFECTIVE_FROM_DATE,
                                       EFFECTIVE_TO_DATE';

    v_sql_str := 'SELECT * FROM
                  (SELECT A.*,DENSE_RANK() OVER (ORDER BY ' ||
                 v_sort_var || ' ' || v_sort_order ||
                 ',ROWNUM)
                   Q FROM (' || v_sql_str ||
                 ') A ) WHERE  Q>= :v_start_num  AND Q<= :v_end_num ';
           

    IF bind_tab.FIRST IS NOT NULL THEN
      CASE bind_tab.COUNT
        WHEN 1 THEN
          OPEN v_result_set FOR v_sql_str
            USING bind_tab(1), v_start_num, v_end_num;
        WHEN 2 THEN
          OPEN v_result_set FOR v_sql_str
            USING bind_tab(1), bind_tab(2), v_start_num, v_end_num;
        WHEN 3 THEN
          OPEN v_result_set FOR v_sql_str
            USING bind_tab(1), bind_tab(2), bind_tab(3), v_start_num, v_end_num;
        WHEN 4 THEN
          OPEN v_result_set FOR v_sql_str
            USING bind_tab(1), bind_tab(2), bind_tab(3), bind_tab(4), v_start_num, v_end_num;
        WHEN 5 THEN
          OPEN v_result_set FOR v_sql_str
            USING bind_tab(1), bind_tab(2), bind_tab(3), bind_tab(4), bind_tab(5), v_start_num, v_end_num;
      END CASE;
    ELSE
      OPEN v_result_set FOR v_sql_str
        USING v_start_num, v_end_num;
    END IF;
  ELSE
    v_sql_str := 'SELECT C.POLICY_SEQ_ID,
                         TO_CHAR(C.POLICY_ISSUE_DATE,''DD/MM/YYYY''),
                         C.POLICY_NUMBER,
                         P.PRODUCT_NAME,
                         SUM(NVL(M.MEM_TOTAL_PREMIUM,0)) AS NET_PREMIUM,
                         F.COMMISSION_TO_TPA AS COMMISSION,
                         SUM(NVL(M.MEM_TOTAL_PREMIUM,0)) * (F.COMMISSION_TO_TPA/100) AS COMMISSION_AMT
                  FROM TPA_ENR_POLICY C 
                  JOIN TPA_GROUP_REGISTRATION G ON ( C.GROUP_REG_SEQ_ID = G.GROUP_REG_SEQ_ID)
                  JOIN TPA_INS_PRODUCT P ON (C.PRODUCT_SEQ_ID=P.PRODUCT_SEQ_ID)
                  JOIN TPA_INS_INFO D ON (C.INS_SEQ_ID = D.INS_SEQ_ID)
                  JOIN TPA_OFFICE_INFO E ON (C.TPA_OFFICE_SEQ_ID = E.TPA_OFFICE_SEQ_ID )
                  JOIN TPA_INS_ASSOC_OFF_PRODUCT F ON (F.INS_SEQ_ID = C.INS_SEQ_ID AND C.PRODUCT_SEQ_ID = F.PRODUCT_SEQ_ID AND F.ENROL_TYPE_ID = C.ENROL_TYPE_ID)
                  JOIN APP.TPA_ENR_POLICY_GROUP PG ON (C.POLICY_SEQ_ID=PG.POLICY_SEQ_ID)
                  JOIN APP.TPA_ENR_POLICY_MEMBER M ON (PG.POLICY_GROUP_SEQ_ID=M.POLICY_GROUP_SEQ_ID )
                  WHERE C.POLICY_ISSUE_DATE BETWEEN F.VALID_FROM AND NVL(F.VALID_TO, C.POLICY_ISSUE_DATE )
                  AND M.DELETED_YN = ''N''
                  AND C.COMPLETED_YN = ''Y''
                  AND NVL(M.INV_TO_BE_GEN_YN,''N'') = ''Y''
                  AND M.INV_CURNT_SEQ_ID IS NULL
                  AND NVL(M.MEM_TOTAL_PREMIUM,0) != 0';

    
    IF (v_group_reg_seq_id) IS NOT NULL THEN
      i := i + 1;
      bind_tab(i) := v_group_reg_seq_id;
      v_sql_str := v_sql_str ||
                   ' AND C.group_reg_seq_id = :v_group_reg_seq_id';
    END IF;

    IF v_IND_YN = 'Y' THEN
      v_enrol_type_id := v_enrol_type_id || '''IND'',';
    END IF;
    IF v_COR_YN = 'Y' THEN
      v_enrol_type_id := v_enrol_type_id || '''COR'',';
    END IF;
    IF v_ING_YN = 'Y' THEN
      v_enrol_type_id := v_enrol_type_id || '''ING'',';
    END IF;
    IF v_NCR_YN = 'Y' THEN
      v_enrol_type_id := v_enrol_type_id || '''NCR'',';
    END IF;

    IF length(v_enrol_type_id) > 5 THEN
      v_sql_str := v_sql_str || ' AND C.enrol_type_id IN ' ||
                   substr(v_enrol_type_id, 1, (length(v_enrol_type_id)) - 1) || ')';
    END IF;

    IF (v_tpa_office_seq_id) IS NOT NULL THEN
      i := i + 1;
      bind_tab(i) := v_tpa_office_seq_id;
      v_sql_str := v_sql_str ||
                   ' AND E.tpa_office_seq_id = :v_tpa_office_seq_id';
    END IF;
    
    --IF v_include_old_yn = 'N' AND v_Assoc_UnAssoc != 'DBA' THEN
    IF v_from_date IS NOT NULL AND v_include_old_yn = 'N' THEN
      i := i + 1;
      bind_tab(i) := to_date(v_from_date, 'DD/MM/YYYY');
      v_sql_str := v_sql_str || ' AND TRUNC(M.added_date) >= :v_from_date';
    END IF;
    IF v_to_date IS NOT NULL THEN
      i := i + 1;
      bind_tab(i) := to_date(v_to_date, 'DD/MM/YYYY');
      v_sql_str := v_sql_str || ' AND TRUNC(M.added_date) <= :v_to_date';
    END IF;
    
    v_sql_str := v_sql_str || ' GROUP BY C.POLICY_SEQ_ID,C.POLICY_ISSUE_DATE,C.POLICY_NUMBER,P.PRODUCT_NAME,F.COMMISSION_TO_TPA';

    v_sql_str := 'SELECT * FROM
                  (SELECT A.*,DENSE_RANK() OVER (ORDER BY ' ||
                 v_sort_var || ' ' || v_sort_order ||
                 ',ROWNUM)
                   Q FROM (' || v_sql_str ||
                 ') A ) WHERE  Q>= :v_start_num  AND Q<= :v_end_num ';


    IF bind_tab.FIRST IS NOT NULL THEN
      CASE bind_tab.COUNT
        WHEN 1 THEN
          OPEN v_result_set FOR v_sql_str
            USING bind_tab(1), v_start_num, v_end_num;
        WHEN 2 THEN
          OPEN v_result_set FOR v_sql_str
            USING bind_tab(1), bind_tab(2), v_start_num, v_end_num;
        WHEN 3 THEN
          OPEN v_result_set FOR v_sql_str
            USING bind_tab(1), bind_tab(2), bind_tab(3), v_start_num, v_end_num;
        WHEN 4 THEN
          OPEN v_result_set FOR v_sql_str
            USING bind_tab(1), bind_tab(2), bind_tab(3), bind_tab(4), v_start_num, v_end_num;
        WHEN 5 THEN
          OPEN v_result_set FOR v_sql_str
            USING bind_tab(1), bind_tab(2), bind_tab(3), bind_tab(4), bind_tab(5), v_start_num, v_end_num;
      END CASE;
    ELSE
      OPEN v_result_set FOR v_sql_str
        USING v_start_num, v_end_num;
    END IF;
   END IF;
  END select_inv_policy_list;
  --===================================================================================================
  /* Author     : R. J. Prasanna Kumar, SPAN Infotech.
     Description: This procedure is used to save the allocation of invoice to few policies
                  OR remove their association.
  */
  /*PROCEDURE save_inv_policy_assoc(v_invoice_seq_id  IN TPA_FIN_INVOICE.invoice_seq_id%TYPE,
                                  v_fin_pol_seq_ids IN VARCHAR2,
                                  v_Assoc_UnAssoc   IN VARCHAR2, -- DBA - Associated DBU - Unassociated
                                  v_added_by        IN NUMBER,
                                  v_row_processed   OUT INTEGER) IS
    
    CURSOR cur_inv_dtls IS
      SELECT I.INV_FROM_DATE,I.INV_TO_DATE,I.INCLUDE_OLD_YN
      FROM TPA_FIN_INVOICE I
      WHERE I.INVOICE_SEQ_ID = v_invoice_seq_id;
    
    str_tab ttk_util_pkg.str_table_type;
    v_inv_from_dt                 DATE;
    v_inv_to_dt                   DATE;
    V_INCLUDE_OLD_YN              VARCHAR2(5);
  
  BEGIN

   OPEN  cur_inv_dtls;
   FETCH cur_inv_dtls INTO v_inv_from_dt,v_inv_to_dt,V_INCLUDE_OLD_YN;
   CLOSE cur_inv_dtls;
   
   
    str_tab := ttk_util_pkg.parse_str(v_fin_pol_seq_ids);
    IF v_Assoc_UnAssoc = 'DBA' THEN
      -- Then assocaite policies to an invoice.
      
        \*FORALL i IN str_tab.FIRST .. str_tab.LAST
          UPDATE tpa_fin_policy_details
             SET invoice_seq_id = v_invoice_seq_id,
                 updated_by     = v_added_by,
                 updated_date   = SYSDATE
           WHERE fin_policy_seq_id = str_tab(i);*\
      IF V_INCLUDE_OLD_YN = 'N' THEN
          FOR i IN str_tab.FIRST .. str_tab.LAST 
            LOOP
              FOR j IN (SELECT M.MEMBER_SEQ_ID
                        FROM APP.TPA_ENR_POLICY EP 
                        JOIN APP.TPA_ENR_POLICY_GROUP PG ON (EP.POLICY_SEQ_ID=PG.POLICY_SEQ_ID)
                        JOIN APP.TPA_ENR_POLICY_MEMBER M ON (PG.POLICY_GROUP_SEQ_ID=M.POLICY_GROUP_SEQ_ID)
                        WHERE EP.POLICY_SEQ_ID = str_tab(i)
                          AND TRUNC(M.ADDED_DATE) BETWEEN v_inv_from_dt AND v_inv_to_dt
                          AND M.DELETED_YN = 'N' AND NVL(M.INVOICE_GEN_YN,'N') = 'N')
                LOOP
                  UPDATE app.tpa_enr_policy_member m 
                    SET m.invoice_seq_id = v_invoice_seq_id
                  WHERE m. member_seq_id = j.member_seq_id;
              END LOOP;
              
            UPDATE tpa_fin_invoice i
             SET i.POLICY_SEQ_ID = str_tab(i)
            WHERE I.INVOICE_SEQ_ID = v_invoice_seq_id;
          
          END LOOP; 
        ELSE
           FOR i IN str_tab.FIRST .. str_tab.LAST 
            LOOP
              FOR j IN (SELECT M.MEMBER_SEQ_ID
                        FROM APP.TPA_ENR_POLICY EP 
                        JOIN APP.TPA_ENR_POLICY_GROUP PG ON (EP.POLICY_SEQ_ID=PG.POLICY_SEQ_ID)
                        JOIN APP.TPA_ENR_POLICY_MEMBER M ON (PG.POLICY_GROUP_SEQ_ID=M.POLICY_GROUP_SEQ_ID)
                        WHERE EP.POLICY_SEQ_ID = str_tab(i)
                          AND M.DELETED_YN = 'N' AND NVL(M.INVOICE_GEN_YN,'N') = 'N'
                          AND TRUNC(M.ADDED_DATE) <= v_inv_to_dt)
                LOOP
                  UPDATE app.tpa_enr_policy_member m 
                    SET m.invoice_seq_id = v_invoice_seq_id
                  WHERE m. member_seq_id = j.member_seq_id;
              END LOOP;
              
              UPDATE tpa_fin_invoice i
             SET i.POLICY_SEQ_ID = str_tab(i)
            WHERE I.INVOICE_SEQ_ID = v_invoice_seq_id;
            
          END LOOP; 
        END IF; 
        
     
    ELSE-------------But unassociate not required 
    
      -- Else remove the assocaition between policies and an invoice.
      \*FORALL i IN str_tab.FIRST .. str_tab.LAST
        UPDATE tpa_fin_policy_details
           SET invoice_seq_id = NULL,
               updated_by     = v_added_by,
               updated_date   = SYSDATE
         WHERE fin_policy_seq_id = str_tab(i);*\
      IF V_INCLUDE_OLD_YN = 'N' THEN
          FOR i IN str_tab.FIRST .. str_tab.LAST 
            LOOP
              FOR j IN (SELECT M.MEMBER_SEQ_ID
                        FROM APP.TPA_ENR_POLICY EP 
                        JOIN APP.TPA_ENR_POLICY_GROUP PG ON (EP.POLICY_SEQ_ID=PG.POLICY_SEQ_ID)
                        JOIN APP.TPA_ENR_POLICY_MEMBER M ON (PG.POLICY_GROUP_SEQ_ID=M.POLICY_GROUP_SEQ_ID)
                        WHERE EP.POLICY_SEQ_ID = str_tab(i)
                          AND M.DELETED_YN = 'N' AND NVL(M.INVOICE_GEN_YN,'N') = 'N'
                          AND TRUNC(M.ADDED_DATE) BETWEEN v_inv_from_dt AND v_inv_to_dt)
                LOOP
                  UPDATE app.tpa_enr_policy_member m 
                    SET m.invoice_seq_id = NULL
                  WHERE m. member_seq_id = j.member_seq_id;
              END LOOP;
              
              UPDATE tpa_fin_invoice i
             SET i.POLICY_SEQ_ID = str_tab(i)
            WHERE I.INVOICE_SEQ_ID = v_invoice_seq_id;
            
          END LOOP; 
        ELSE
           FOR i IN str_tab.FIRST .. str_tab.LAST 
            LOOP
              FOR j IN (SELECT M.MEMBER_SEQ_ID
                        FROM APP.TPA_ENR_POLICY EP 
                        JOIN APP.TPA_ENR_POLICY_GROUP PG ON (EP.POLICY_SEQ_ID=PG.POLICY_SEQ_ID)
                        JOIN APP.TPA_ENR_POLICY_MEMBER M ON (PG.POLICY_GROUP_SEQ_ID=M.POLICY_GROUP_SEQ_ID)
                        WHERE EP.POLICY_SEQ_ID = str_tab(i)
                          AND M.DELETED_YN = 'N' AND NVL(M.INVOICE_GEN_YN,'N') = 'N'
                          AND TRUNC(M.ADDED_DATE) <= v_inv_to_dt)
                LOOP
                  UPDATE app.tpa_enr_policy_member m 
                    SET m.invoice_seq_id = NULL
                  WHERE m. member_seq_id = j.member_seq_id;
              END LOOP;
              
              UPDATE tpa_fin_invoice i
             SET i.POLICY_SEQ_ID = str_tab(i)
            WHERE I.INVOICE_SEQ_ID = v_invoice_seq_id;
            
          END LOOP; 
        END IF;       
         
    END IF;
    --number of rows updated/inserted
    v_row_processed := SQL%ROWCOUNT;
    COMMIT;

  END save_inv_policy_assoc;*/
  --===================================================================================================
  /* Author     : R. J. Prasanna Kumar, SPAN Infotech.
     Description: This procedure is used to save the allocation of invoice to all selected uninvoiced
                  policies OR remove their association.
  */
  PROCEDURE save_inv_policy_assoc_all(v_group_reg_seq_id  IN tpa_fin_policy_details.group_reg_seq_id%TYPE,
                                      v_IND_YN            IN VARCHAR2,
                                      v_COR_YN            IN VARCHAR2,
                                      v_ING_YN            IN VARCHAR2,
                                      v_NCR_YN            IN VARCHAR2,
                                      v_tpa_office_seq_id IN tpa_office_info.tpa_office_seq_id%TYPE,
                                      v_from_date         IN VARCHAR2,
                                      v_to_date           IN VARCHAR2,
                                      v_Assoc_UnAssoc     IN VARCHAR2, -- DBA - Associate DBU - Unassociate
                                      v_invoice_seq_id    IN TPA_FIN_INVOICE.invoice_seq_id%TYPE,
                                      v_include_old_yn    IN TPA_FIN_INVOICE.include_old_yn%TYPE,
                                      v_added_by          IN NUMBER,
                                      v_row_processed     OUT INTEGER) IS
    v_sql_str       VARCHAR2(4000);
    v_enrol_type_id VARCHAR2(40) := '(';
    TYPE bind_tab_type IS TABLE OF VARCHAR2(250) INDEX BY BINARY_INTEGER;
    bind_tab bind_tab_type;
    i        NUMBER(2) := 0;
  BEGIN
/*
    IF (v_ins_seq_id) IS NOT NULL THEN
      v_sql_str := v_sql_str ||
                   ' AND ins_seq_id IN ( SELECT ins_seq_id FROM  tpa_ins_info
                                                    START WITH ins_seq_id = ' ||
                   to_char(v_ins_seq_id) ||
                   'CONNECT BY PRIOR ins_seq_id =  ins_parent_seq_id )';
    END IF;

    IF v_IND_YN = 'Y' THEN
      v_enrol_type_id := v_enrol_type_id || '''IND'',';
    END IF;
    IF v_COR_YN = 'Y' THEN
      v_enrol_type_id := v_enrol_type_id || '''COR'',';
    END IF;
    IF v_ING_YN = 'Y' THEN
      v_enrol_type_id := v_enrol_type_id || '''ING'',';
    END IF;
    IF v_NCR_YN = 'Y' THEN
      v_enrol_type_id := v_enrol_type_id || '''NCR'',';
    END IF;

    IF length(v_enrol_type_id) > 5 THEN
      v_sql_str := v_sql_str || ' AND enrol_type_id IN ' ||
                   substr(v_enrol_type_id, 1, (length(v_enrol_type_id)) - 1) || ')';
    END IF;

    IF (v_tpa_office_seq_id) IS NOT NULL THEN
      v_sql_str := v_sql_str || ' AND tpa_office_seq_id = ' ||
                   to_char(v_tpa_office_seq_id);
    END IF;
    IF v_include_old_yn = 'N' AND v_Assoc_UnAssoc = 'DBA' THEN
      v_sql_str := v_sql_str || ' AND TRUNC(added_date) >= TO_DATE(''' ||
                   v_from_date || ''',''DD/MM/YYYY'')';
    END IF;
    IF v_to_date IS NOT NULL THEN
      v_sql_str := v_sql_str || ' AND TRUNC(added_date) <= TO_DATE(''' ||
                   v_to_date || ''',''DD/MM/YYYY'')';
    END IF;
    IF v_Assoc_UnAssoc != 'DBA' THEN
      v_sql_str := v_sql_str || ' AND invoice_seq_id = ' ||
                   to_char(v_invoice_seq_id);
    ELSE
      v_sql_str := v_sql_str ||
                   ' AND invoice_seq_id IS NULL AND inv_flag = ''N''';
    END IF;
    
    

    IF v_Assoc_UnAssoc = 'DBA' THEN
      -- Then assocaite policies to an invoice.
      v_sql_str := 'UPDATE tpa_fin_policy_details SET invoice_seq_id = ' ||
                   to_char(v_invoice_seq_id) || ', updated_by  = ' ||
                   to_char(v_added_by) || ', updated_date = SYSDATE WHERE ' ||
                   substr(v_sql_str, 6);
    ELSE
      -- Else remove the assocaition between policies and an invoice.
      v_sql_str := 'UPDATE tpa_fin_policy_details SET invoice_seq_id  = NULL, updated_by  = ' ||
                   to_char(v_added_by) ||
                   ', updated_date = SYSDATE  WHERE ' ||
                   substr(v_sql_str, 6);
    END IF;
*/ 
    
    v_sql_str := ' SELECT m.member_seq_id
                   FROM tpa_fin_policy_details B JOIN tpa_enr_policy C ON (C.policy_seq_id = B.policy_seq_id)
                        JOIN tpa_ins_info D ON (B.ins_seq_id = D.ins_seq_id)
                        JOIN tpa_office_info E ON (B.tpa_office_seq_id = E.tpa_office_seq_id )
                        JOIN tpa_ins_assoc_off_product F ON (F.ins_seq_id = B.ins_seq_id AND B.product_seq_id = F.product_seq_id
                                                           AND F.enrol_type_id = B.enrol_type_id)
                        JOIN APP.TPA_ENR_POLICY_GROUP PG ON (C.POLICY_SEQ_ID=PG.POLICY_SEQ_ID)
                        JOIN APP.TPA_ENR_POLICY_MEMBER M ON (PG.POLICY_GROUP_SEQ_ID=M.POLICY_GROUP_SEQ_ID )
                        LEFT OUTER JOIN tpa_group_registration G ON ( B.group_reg_seq_id = G.group_reg_seq_id)
                        LEFT OUTER JOIN tpa_fin_invoice fi ON (B.invoice_seq_id = fi.invoice_seq_id)
                     WHERE C.policy_issue_date BETWEEN F.valid_from AND NVL(F.valid_to, C.policy_issue_date )
                        AND m.deleted_yn = ''N''
                        AND NVL(M.INVOICE_GEN_YN,''N'') = ''N''
                        AND NVL(M.MEM_TOTAL_PREMIUM,0) != 0';

    
    IF (v_group_reg_seq_id) IS NOT NULL THEN
      i := i + 1;
      bind_tab(i) := v_group_reg_seq_id;
      v_sql_str := v_sql_str ||
                   ' AND C.group_reg_seq_id = :v_group_reg_seq_id';
    END IF;

    IF v_IND_YN = 'Y' THEN
      v_enrol_type_id := v_enrol_type_id || '''IND'',';
    END IF;
    IF v_COR_YN = 'Y' THEN
      v_enrol_type_id := v_enrol_type_id || '''COR'',';
    END IF;
    IF v_ING_YN = 'Y' THEN
      v_enrol_type_id := v_enrol_type_id || '''ING'',';
    END IF;
    IF v_NCR_YN = 'Y' THEN
      v_enrol_type_id := v_enrol_type_id || '''NCR'',';
    END IF;

    IF length(v_enrol_type_id) > 5 THEN
      v_sql_str := v_sql_str || ' AND B.enrol_type_id IN ' ||
                   substr(v_enrol_type_id, 1, (length(v_enrol_type_id)) - 1) || ')';
    END IF;

    IF (v_tpa_office_seq_id) IS NOT NULL THEN
      i := i + 1;
      bind_tab(i) := v_tpa_office_seq_id;
      v_sql_str := v_sql_str ||
                   ' AND E.tpa_office_seq_id = :v_tpa_office_seq_id';
    END IF;
    
    --IF v_include_old_yn = 'N' AND v_Assoc_UnAssoc != 'DBA' THEN
    IF v_from_date IS NOT NULL THEN
      i := i + 1;
      bind_tab(i) := to_date(v_from_date, 'DD/MM/YYYY');
      v_sql_str := v_sql_str || ' AND M.added_date >= :v_from_date';
    END IF;
    IF v_to_date IS NOT NULL THEN
      i := i + 1;
      bind_tab(i) := to_date(v_to_date, 'DD/MM/YYYY');
      v_sql_str := v_sql_str || ' AND M.added_date <= :v_to_date';
    END IF;
    
    v_sql_str := ' AND member_seq_id IN ( '||v_sql_str||')';
    
    
    IF v_Assoc_UnAssoc = 'DBA' THEN
      -- Then assocaite policies to an invoice.
      v_sql_str := 'UPDATE tpa_enr_policy_member 
                      SET invoice_seq_id = ' || to_char(v_invoice_seq_id) || 
                       ', updated_by  = ' || to_char(v_added_by) || 
                       ', updated_date = SYSDATE 
                   WHERE ' ||
                   substr(v_sql_str, 6);
    ELSE
      -- Else remove the assocaition between policies and an invoice.
      v_sql_str := 'UPDATE tpa_enr_policy_member 
                      SET invoice_seq_id = ' || NULL || 
                       ', updated_by  = ' || to_char(v_added_by) || 
                       ', updated_date = SYSDATE 
                   WHERE ' ||
                   substr(v_sql_str, 6);
    END IF;

    EXECUTE IMMEDIATE v_sql_str;
    --number of rows updated/inserted
    v_row_processed := SQL%ROWCOUNT;
    COMMIT;

  END save_inv_policy_assoc_all;
  --===================================================================================================
  PROCEDURE get_new_inv_from_date(--v_group_reg_seq_id  IN tpa_fin_policy_details.group_reg_seq_id%TYPE,
                                  v_new_inv_from_date OUT DATE ) IS
  BEGIN
    SELECT MAX(GR.INV_AUTO_STRT_DATE) + 1
      INTO v_new_inv_from_date
      FROM TPA_GROUP_REGISTRATION GR
      WHERE GR.GROUP_REG_SEQ_ID = 0;
      
    IF v_new_inv_from_date IS NULL THEN
      v_new_inv_from_date := TRUNC(SYSDATE) -
                             to_number(to_char(SYSDATE, 'dd')) + 1;
    END IF;
  END get_new_inv_from_date;
  --===================================================================================================
  PROCEDURE tpa_commission(v_inv_policy_seq_id     IN VARCHAR2,
                           v_start_date            IN VARCHAR2,
                           v_end_date              IN VARCHAR2,
                           v_added_by              IN NUMBER,
                           --Individual_Enrl_cur     OUT SYS_REFCURSOR,
                           --Individual_End_cur      OUT SYS_REFCURSOR,
                           --Corporate_Enrl_cur      OUT SYS_REFCURSOR, --commented in cr0229
                           --Corporate_End_cur       OUT SYS_REFCURSOR,
                           --Non_Corp_Enrl_cur       OUT SYS_REFCURSOR,
                           --Non_Corp_End_cur        OUT SYS_REFCURSOR,
                           --Ind_as_group_Enrl_cur   OUT SYS_REFCURSOR,
                           --Ind_as_group_End_cur    OUT SYS_REFCURSOR,
                           --start_date_cur          OUT SYS_REFCURSOR,
                           --bo_do_cur               OUT SYS_REFCURSOR,
                           --summary_cur             OUT SYS_REFCURSOR,
                           --policy_type_summary_cur OUT SYS_REFCURSOR,
                           corp_dtl_premium_cur    OUT SYS_REFCURSOR, 
                           corp_mem_clm_inp_cur    OUT SYS_REFCURSOR, 
                           v_batch_seq_id          OUT tpa_inv_batch.batch_seq_id%TYPE)

   IS
    -- v_from_date            DATE := to_date( v_start_date,'dd/mm/yyyy');
    -- v_to_date              DATE := to_date( v_end_date,'dd/mm/yyyy');
    
    CURSOR cur_inv_dtls(v_invoice_seq_id NUMBER) IS
      SELECT I.INV_FROM_DATE,I.INV_TO_DATE,NVL(I.INCLUDE_OLD_YN,'N') AS INCLUDE_OLD_YN,I.INVOICE_TYPE
      FROM TPA_FIN_INVOICE I
      WHERE I.INVOICE_SEQ_ID = v_invoice_seq_id;
      
    CURSOR cur_pol_info(V_POLICY_SEQ_ID  NUMBER) IS
      SELECT ep.logic_type_id,ep.clm_admn_chrgs,NVL(ep.mem_cancl_days,90) AS mem_cancl_days,          
             ep.mat_premum_from_age,ep.mat_premum_to_age       
      FROM APP.TPA_ENR_POLICY EP
      WHERE EP.POLICY_SEQ_ID = V_POLICY_SEQ_ID;  
    
    rec_pol_info                  cur_pol_info%ROWTYPE;         
    v_inv_from_dt                 DATE;
    v_inv_to_dt                   DATE;
    V_INCLUDE_OLD_YN              VARCHAR2(5);
    
    v_no_of_transations tpa_inv_batch.no_of_transations%TYPE;
    v_batch_name        tpa_inv_batch.batch_name%TYPE;
    str_tab             ttk_util_pkg.str_table_type;
    v_inv_type                    VARCHAR2(10);
    v_tot_premium                 number(20,2);--cr0229
    
  BEGIN

  str_tab := ttk_util_pkg.parse_str(v_inv_policy_seq_id);
   
   OPEN  cur_inv_dtls(str_tab(1));
   FETCH cur_inv_dtls INTO v_inv_from_dt,v_inv_to_dt,V_INCLUDE_OLD_YN,V_INV_TYPE;
   CLOSE cur_inv_dtls;
   
   OPEN  cur_pol_info(str_tab(2));
   FETCH cur_pol_info INTO rec_pol_info;
   CLOSE cur_pol_info;
   
  IF V_INV_TYPE = 'ADD' THEN 
   IF V_INCLUDE_OLD_YN = 'N' THEN
    /*OPEN Corporate_Enrl_cur FOR
      SELECT IV.INVOICE_NUMBER,
             --CASE WHEN h.prod_general_type_id = 'PST' THEN 'S' ELSE 'U' END AS INV_TYPE,
             G.DESCRIPTION AS INV_TYPE,
             c.office_code AS "LOC",
             'Groups' AS "Type",
             EP.Policy_Number AS "PolicyNo",
             D.ABBREVATION_CODE AS "INS",
             GR.Group_Name AS "Name",
             COUNT(M.MEMBER_SEQ_ID) AS "Lives",
             to_char(EP.Effective_From_Date, 'dd/mm/yyyy') as "Start Date",
             SUM(NVL(M.MEM_TOT_SUM_INSURED, 0)) AS "Sum Insured",
             ROUND(SUM(NVL(ABS(NVL(M.INV_CRN_AMNT,M.MEM_TOTAL_PREMIUM) - NVL(M.CHNG_IN_AMNT,0) ), 0)),2) AS "Premium",
            (SUM(NVL(ABS(NVL(M.INV_CRN_AMNT,M.MEM_TOTAL_PREMIUM) - NVL(M.CHNG_IN_AMNT,0) ), 0)) * (f.commission_to_tpa / 100)) AS "TPA",
             round(Months_between(EP.EFFECTIVE_TO_DATE, EP.Effective_From_Date)) / 12 AS "Tenure",
             to_char(EP.EFFECTIVE_TO_DATE, 'dd/mm/yyyy') AS EXPIRY_DATE,
             EP.Groupid || EP.Sub_Group_Id AS ID,
             f.Commission_To_Tpa,
              NULL AS CLM_AMOUNT,
              NULL AS Return_Premium,
             IV.INVOICE_TYPE,
             SUM(CASE WHEN m.gender_general_type_id = 'MAL' THEN (NVL(nvl(EP.ip_op_premium_per_ind,EP.pol_total_excmat_premium),0))
                  WHEN m.Gender_General_Type_Id = 'FEM' AND m.Marital_Status_Id ='MRD' 
                       AND M.MEM_AGE BETWEEN rec_pol_info.mat_premum_from_age AND rec_pol_info.mat_premum_to_age 
                       THEN (NVL(nvl(EP.ip_op_premium_per_ind,EP.pol_total_excmat_premium),0) + NVL(nvl(EP.mat_premium_per_ind,EP.pol_total_mat_premium),0))
                  ELSE (NVL(nvl(EP.ip_op_premium_per_ind,EP.pol_total_excmat_premium),0))  
                END) as "Member_Annual_Premium"
        FROM APP.TPA_ENR_POLICY_MEMBER M 
        JOIN FIN_APP.TPA_FIN_INVOICE IV ON (M.INV_CURNT_SEQ_ID = IV.INVOICE_SEQ_ID)
        JOIN tpa_enr_policy EP ON (IV.POLICY_SEQ_ID=EP.POLICY_SEQ_ID)
        JOIN APP.TPA_GROUP_REGISTRATION  GR ON (EP.GROUP_REG_SEQ_ID=GR.GROUP_REG_SEQ_ID)
        JOIN tpa_office_info C ON (c.Tpa_Office_Seq_Id = C.Tpa_Office_Seq_Id)
        JOIN tpa_ins_info D ON (EP.INS_SEQ_ID = D.INS_SEQ_ID)
        JOIN TPA_INS_ASSOC_OFF_PRODUCT F ON (F.INS_SEQ_ID = EP.INS_SEQ_ID AND EP.PRODUCT_SEQ_ID = F.PRODUCT_SEQ_ID AND F.ENROL_TYPE_ID = EP.ENROL_TYPE_ID)
        JOIN tpa_ins_product H ON (EP.product_seq_id = h.product_seq_id)
        JOIN APP.TPA_GENERAL_CODE G ON (IV.INV_GEN_PERIOD=G.GENERAL_TYPE_ID)
        WHERE IV.INVOICE_SEQ_ID = str_tab(1)
           AND TRUNC(M.ADDED_DATE) BETWEEN v_inv_from_dt AND v_inv_to_dt 
           AND EP.deleted_yn = 'N' 
           AND EP.enrol_type_id = 'COR' 
           AND M.DELETED_YN = 'N' 
           AND NVL(M.INV_TO_BE_GEN_YN,'N') = 'Y'
        GROUP BY h.prod_general_type_id,c.office_code,D.ABBREVATION_CODE,
                 EP.Policy_Number,GR.Group_Name,EP.Effective_From_Date,EP.EFFECTIVE_TO_DATE,
                 EP.Groupid,EP.Sub_Group_Id,f.Commission_To_Tpa,IV.INVOICE_NUMBER,IV.INV_GEN_PERIOD,
                 G.DESCRIPTION,IV.INVOICE_TYPE
        ORDER BY IV.INVOICE_NUMBER ;*/ --commented in CR0229
        
     ------------------- CR0229 ----------------
  EXECUTE IMMEDIATE 'SELECT ROUND(SUM(NVL(ABS(NVL(M.INV_CRN_AMNT,M.MEM_TOTAL_PREMIUM) - NVL(M.CHNG_IN_AMNT,0) ), 0)),2) AS "Premium"
                      FROM APP.TPA_ENR_POLICY_MEMBER M 
                      JOIN FIN_APP.TPA_FIN_INVOICE IV ON (M.INV_CURNT_SEQ_ID = IV.INVOICE_SEQ_ID)
                      JOIN tpa_enr_policy EP ON (IV.POLICY_SEQ_ID=EP.POLICY_SEQ_ID)
                     WHERE IV.INVOICE_SEQ_ID = :V_INVOICE_SEQID
                       AND TRUNC(M.ADDED_DATE) BETWEEN :v_inv_from_dt AND :v_inv_to_dt 
                       AND EP.deleted_yn = ''N'' AND EP.enrol_type_id = ''COR'' AND M.DELETED_YN = ''N'' AND NVL(M.INV_TO_BE_GEN_YN,''N'') = ''Y''' INTO v_tot_premium 
                     USING str_tab(1),v_inv_from_dt,v_inv_to_dt;  
    ------------------------------------------------
    
  OPEN corp_dtl_premium_cur FOR
   WITH renewal_mem AS (
     SELECT EP.policy_number,
             PG.employee_no,
             PG.insured_name,
             M.tpa_enrollment_id,
             M.mem_name,
             D.relship_description,
             E.description as gender,
             --decode(EP.POLICY_SUB_GENERAL_TYPE_ID,'PFL',PG.FLOATER_SUM_INSURED,M.mem_tot_sum_insured) AS mem_tot_sum_insured,
             row_number() over (PARTITION BY PG.employee_no ORDER BY M.tpa_enrollment_id) rn,
             PG.FLOATER_SUM_INSURED, --M.mem_tot_sum_insured AS mem_sum_insured, 
             EP.POLICY_SUB_GENERAL_TYPE_ID,
             case when EP.POLICY_SUB_GENERAL_TYPE_ID='PFL' and D.relship_description='Principal'  then K.SUM_INSURED else M.mem_tot_sum_insured end as mem_sum_insured,
             M.mem_age,
             TO_CHAR(M.mem_dob,'DD/MM/YYYY') as mem_dob,
             PG.department,
             TO_CHAR(PG.date_of_joining,'DD/MM/YYYY') as date_of_joining,
             M.photo_present_yn,
             F.address_1||F.address_2||F.address_3 as address,
             J.CITY_DESCRIPTION,
             --F.city_type_id,
             H.state_name,
             F.pin_code,
             ttk_util_pkg.fn_decrypt(G.bank_account_no) as bank_account_no, --//ED
             M.domicilary_limit,
             ttk_util_pkg.fn_decrypt(F.email_id) as email_id, --//ED
             ttk_util_pkg.fn_decrypt(F.mobile_no) as mobile_no, --//ED
             PG.certificate_no,
             ttk_util_pkg.fn_decrypt(PG.creditcard_no) as creditcard_no,--//ED
             to_char(case when M.date_of_inception<ep.effective_from_date then ep.effective_from_date else m.date_of_inception end,'DD/MM/YYYY') AS date_of_inception, -- changed for prod. fix
             to_char(M.date_of_exit,'DD/MM/YYYY') AS date_of_exit,
             M.member_remarks AS policy_remarks,
             PG.tpa_enrollment_number,
             M.member_seq_id,
             case when M.MARITAL_STATUS_ID='MRD' THEN 'Married'
             ELSE 'Single' END AS M_STATUS,
             CASE  WHEN M.status_general_type_id = 'POA' THEN 'Active'
             ELSE 'Cancelled' end as status,
             to_char(EP.ADDED_DATE,'DD/MM/YYYY'),
              to_char(M.CARD_PRN_DATE,'dd/mm/yyyy') as CARD_PRN_DATE,
             case when M.card_prn_count!=0 then 'Y' 
             ELSE 'N' END AS CARD_PRINTED,
             M.EMIRATE_ID,
             M.PASSPORT_NUMBER,
             N.DESCRIPTION,
             M.CARD_PRN_COUNT,
             gc.DESCRIPTION as network_type,
             to_char(M.ADDED_DATE,'dd/mm/yyyy') as adate,
			 M.VIP_YN,
      K.SUM_INSURED-K.utilised_sum_insured as AVA_SUM_INSURED,L.GROUP_NAME,
      ROUND(ABS(NVL(M.INV_CRN_AMNT,M.MEM_TOTAL_PREMIUM) - NVL(M.CHNG_IN_AMNT,0) ),2) AS MEM_TOTAL_PREMIUM,
      ROUND(ABS(NVL(M.INV_CRN_AMNT,M.MEM_TOTAL_PREMIUM) - NVL(M.CHNG_IN_AMNT,0) ),2)/(select decode(IV.INV_GEN_PERIOD,'QTR',4,'HLF',2,1) from TPA_FIN_INVOICE iv where iv.invoice_seq_id=str_tab(1)) as Premium_Instalment ,-- CR0229
      NULL AS CLM_AMOUNT,
      NULL AS Return_Premium,
      V_INV_TYPE as INVOICE_TYPE,
       CASE WHEN M.gender_general_type_id = 'MAL' THEN (NVL(nvl(EP.ip_op_premium_per_ind,EP.pol_total_excmat_premium),0))
            WHEN M.Gender_General_Type_Id = 'FEM' AND M.Marital_Status_Id ='MRD' 
                 AND M.MEM_AGE BETWEEN rec_pol_info.mat_premum_from_age AND rec_pol_info.mat_premum_to_age 
                  THEN (NVL(nvl(EP.ip_op_premium_per_ind,EP.pol_total_excmat_premium),0) + NVL(nvl(EP.mat_premium_per_ind,EP.pol_total_mat_premium),0))
            ELSE (NVL(nvl(EP.ip_op_premium_per_ind,EP.pol_total_excmat_premium),0))  
       end as "Member_Annual_Premium"
      FROM TPA_ENR_POLICY EP JOIN TPA_ENR_POLICY_GROUP PG ON (EP.Policy_Seq_Id = PG.policy_seq_id)
      JOIN TPA_ENR_POLICY_MEMBER M ON (PG.policy_group_seq_id = M.policy_group_seq_id)
      join tpa_group_registration l on (PG.group_reg_seq_id=l.group_reg_seq_id)
      JOIN TPA_RELATIONSHIP_CODE D ON (M.relship_type_id=D.relship_type_id)
      JOIN TPA_GENERAL_CODE E ON (E.general_type_id=M.gender_general_type_id)
      LEFT OUTER JOIN TPA_ENR_MEM_ADDRESS F ON (F.enr_address_seq_id = m.enr_address_seq_id)
      LEFT OUTER JOIN TPA_ENR_BANK_DTLS G ON (G.bank_seq_id = PG.bank_seq_id)
      LEFT OUTER JOIN TPA_STATE_CODE H ON (H.state_type_id=F.state_type_id)
      LEFT OUTER JOIN APP.TPA_CITY_CODE J ON (J.CITY_TYPE_ID=F.CITY_TYPE_ID)
      LEFT OUTER JOIN APP.TPA_NATIONALITIES_CODE N ON (N.NATIONALITY_ID=M.NATIONALITY_ID)
      left outer JOIN TPA_INS_PRODUCT TIP ON (EP.PRODUCT_SEQ_ID=TIP.PRODUCT_SEQ_ID)
      left outer join tpa_general_code GC ON (GC.GENERAL_TYPE_ID=TIP.PRODUCT_CAT_TYPE_ID)
      left outer JOIN app.tpa_enr_balance K ON (M.policy_group_seq_id=K.policy_group_seq_id)-- and CASE WHEN EP.Policy_Sub_General_Type_Id= 'PNF' THEN M.MEMBER_SEQ_ID=K.MEMBER_SEQ_ID)
      WHERE M.INV_CURNT_SEQ_ID = str_tab(1)
        AND EP.enrol_type_id = 'COR'  
        AND (M.mem_general_type_id != 'PFL' AND M.member_seq_id = k.member_seq_id OR k.member_seq_id IS NULL OR M.member_seq_id IS NULL)
        AND TRUNC(M.ADDED_DATE) BETWEEN v_inv_from_dt AND v_inv_to_dt 
        AND EP.deleted_yn='N'
        AND M.deleted_yn='N'
        AND NVL(M.INV_TO_BE_GEN_YN,'N') = 'Y'
      )

      --SELECT * FROM renewal_mem WHERE rec_number BETWEEN str_tab(2) AND str_tab(2)+9;--64999;
      SELECT b.*, CASE WHEN POLICY_SUB_GENERAL_TYPE_ID = 'PFL' AND rn = 1 THEN FLOATER_SUM_INSURED
                  ELSE mem_sum_insured END AS mem_tot_sum_insured FROM
        (SELECT A.*, DENSE_RANK() OVER (ORDER BY employee_no, MEMBER_SEQ_ID, ROWNUM)
           Q FROM renewal_mem A ) b ;
           
     OPEN corp_mem_clm_inp_cur FOR
       SELECT NULL AS TPA_ENROLLMENT_ID,
              NULL AS MEM_NAME,
              NULL AS CLM_AMOUNT,
              NULL AS claim_status
       FROM DUAL; 
             
  ELSE
    /*OPEN Corporate_Enrl_cur FOR
      SELECT IV.INVOICE_NUMBER,
             --CASE WHEN h.prod_general_type_id = 'PST' THEN 'S' ELSE 'U' END AS INV_TYPE,
             G.DESCRIPTION AS INV_TYPE,
             c.office_code AS "LOC",
             'Groups' AS "Type",
             EP.Policy_Number AS "PolicyNo",
             D.ABBREVATION_CODE AS "INS",
             GR.Group_Name AS "Name",
             COUNT(M.MEMBER_SEQ_ID) AS "Lives",
             to_char(EP.Effective_From_Date, 'dd/mm/yyyy') as "Start Date",
             SUM(NVL(M.MEM_TOT_SUM_INSURED, 0)) AS "Sum Insured",
             ROUND(SUM(NVL(ABS(NVL(M.INV_CRN_AMNT,M.MEM_TOTAL_PREMIUM) - NVL(M.CHNG_IN_AMNT,0) ), 0)),2) AS "Premium",
            (SUM(NVL(ABS(NVL(M.INV_CRN_AMNT,M.MEM_TOTAL_PREMIUM) - NVL(M.CHNG_IN_AMNT,0) ), 0)) * (f.commission_to_tpa / 100)) AS "TPA",
             round(Months_between(EP.EFFECTIVE_TO_DATE, EP.Effective_From_Date)) / 12 AS "Tenure",
             to_char(EP.EFFECTIVE_TO_DATE, 'dd/mm/yyyy') AS EXPIRY_DATE,
             EP.Groupid || EP.Sub_Group_Id AS ID,
             f.Commission_To_Tpa,
              NULL AS CLM_AMOUNT,
              NULL AS Return_Premium,
             IV.INVOICE_TYPE,
             SUM(CASE WHEN m.gender_general_type_id = 'MAL' THEN (NVL(nvl(EP.ip_op_premium_per_ind,EP.pol_total_excmat_premium),0))
                  WHEN m.Gender_General_Type_Id = 'FEM' AND m.Marital_Status_Id ='MRD' 
                      AND M.MEM_AGE BETWEEN rec_pol_info.mat_premum_from_age AND rec_pol_info.mat_premum_to_age 
                      THEN (NVL(nvl(EP.ip_op_premium_per_ind,EP.pol_total_excmat_premium),0) + NVL(nvl(EP.mat_premium_per_ind,EP.pol_total_mat_premium),0))
                  ELSE (NVL(nvl(EP.ip_op_premium_per_ind,EP.pol_total_excmat_premium),0)) 
                 END) as "Member_Annual_Premium"
        FROM APP.TPA_ENR_POLICY_MEMBER M 
        JOIN FIN_APP.TPA_FIN_INVOICE IV ON (M.INV_CURNT_SEQ_ID = IV.INVOICE_SEQ_ID)
        JOIN tpa_enr_policy EP ON (IV.POLICY_SEQ_ID=EP.POLICY_SEQ_ID)
        JOIN APP.TPA_GROUP_REGISTRATION  GR ON (EP.GROUP_REG_SEQ_ID=GR.GROUP_REG_SEQ_ID)
        JOIN tpa_office_info C ON (c.Tpa_Office_Seq_Id = C.Tpa_Office_Seq_Id)
        JOIN tpa_ins_info D ON (EP.INS_SEQ_ID = D.INS_SEQ_ID)
        JOIN TPA_INS_ASSOC_OFF_PRODUCT F ON (F.INS_SEQ_ID = EP.INS_SEQ_ID AND EP.PRODUCT_SEQ_ID = F.PRODUCT_SEQ_ID AND F.ENROL_TYPE_ID = EP.ENROL_TYPE_ID)
        JOIN tpa_ins_product H ON (EP.product_seq_id = h.product_seq_id)
        JOIN APP.TPA_GENERAL_CODE G ON (IV.INV_GEN_PERIOD=G.GENERAL_TYPE_ID)
        WHERE IV.invoice_seq_id = str_tab(1)
           AND TRUNC(M.ADDED_DATE) <= v_inv_to_dt 
           AND EP.enrol_type_id = 'COR' 
           AND EP.deleted_yn = 'N' 
           AND M.DELETED_YN = 'N' 
           AND NVL(M.INV_TO_BE_GEN_YN,'N') = 'Y'
        GROUP BY h.prod_general_type_id,c.office_code,D.ABBREVATION_CODE,
                 EP.Policy_Number,GR.Group_Name,EP.Effective_From_Date,EP.EFFECTIVE_TO_DATE,
                 EP.Groupid,EP.Sub_Group_Id,f.Commission_To_Tpa,IV.INVOICE_NUMBER,
                 IV.INV_GEN_PERIOD,G.DESCRIPTION,IV.INVOICE_TYPE,gender_general_type_id,Marital_Status_Id,mem_age
        ORDER BY IV.INVOICE_NUMBER ;*/ -- commented in CR0229
   -------------- CR0229 ---------------------------
   EXECUTE IMMEDIATE 'SELECT ROUND(SUM(NVL(ABS(NVL(M.INV_CRN_AMNT,M.MEM_TOTAL_PREMIUM) - NVL(M.CHNG_IN_AMNT,0) ), 0)),2) AS "Premium"
                        FROM APP.TPA_ENR_POLICY_MEMBER M 
                        JOIN FIN_APP.TPA_FIN_INVOICE IV ON (M.INV_CURNT_SEQ_ID = IV.INVOICE_SEQ_ID)
                        JOIN tpa_enr_policy EP ON (IV.POLICY_SEQ_ID=EP.POLICY_SEQ_ID)
                       WHERE IV.invoice_seq_id = :v_invoice_seqid
                         AND TRUNC(M.ADDED_DATE) <= :v_inv_to_dt 
                         AND EP.enrol_type_id = ''COR''  AND EP.deleted_yn = ''N'' AND M.DELETED_YN = ''N'' AND NVL(M.INV_TO_BE_GEN_YN,''N'') = ''Y''' INTO v_tot_premium
                       USING str_tab(1),v_inv_to_dt;
   -------------------------------------------------     
     
  OPEN corp_dtl_premium_cur FOR
   WITH renewal_mem AS (
     SELECT EP.policy_number,
             PG.employee_no,
             PG.insured_name,
             M.tpa_enrollment_id,
             M.mem_name,
             D.relship_description,
             E.description as gender,
             --decode(EP.POLICY_SUB_GENERAL_TYPE_ID,'PFL',PG.FLOATER_SUM_INSURED,M.mem_tot_sum_insured) AS mem_tot_sum_insured,
             row_number() over (PARTITION BY PG.employee_no ORDER BY M.tpa_enrollment_id) rn,
             PG.FLOATER_SUM_INSURED, --M.mem_tot_sum_insured AS mem_sum_insured, 
             EP.POLICY_SUB_GENERAL_TYPE_ID,
             case when EP.POLICY_SUB_GENERAL_TYPE_ID='PFL' and D.relship_description='Principal'  then K.SUM_INSURED else M.mem_tot_sum_insured end as mem_sum_insured,
             M.mem_age,
             TO_CHAR(M.mem_dob,'DD/MM/YYYY') as mem_dob,
             PG.department,
             TO_CHAR(PG.date_of_joining,'DD/MM/YYYY') as date_of_joining,
             M.photo_present_yn,
             F.address_1||F.address_2||F.address_3 as address,
             J.CITY_DESCRIPTION,
             --F.city_type_id,
             H.state_name,
             F.pin_code,
             ttk_util_pkg.fn_decrypt(G.bank_account_no) as bank_account_no, --//ED
             M.domicilary_limit,
             ttk_util_pkg.fn_decrypt(F.email_id) as email_id, --//ED
             ttk_util_pkg.fn_decrypt(F.mobile_no) as mobile_no, --//ED
             PG.certificate_no,
             ttk_util_pkg.fn_decrypt(PG.creditcard_no) as creditcard_no,--//ED
             to_char(case when M.date_of_inception<ep.effective_from_date then ep.effective_from_date else m.date_of_inception end,'DD/MM/YYYY') AS date_of_inception, -- changed for prod. fix
             to_char(M.date_of_exit,'DD/MM/YYYY') AS date_of_exit,
             M.member_remarks AS policy_remarks,
             PG.tpa_enrollment_number,
             M.member_seq_id,
             case when M.MARITAL_STATUS_ID='MRD' THEN 'Married'
             ELSE 'Single' END AS M_STATUS,
             CASE  WHEN M.status_general_type_id = 'POA' THEN 'Active'
             ELSE 'Cancelled' end as status,
             to_char(EP.ADDED_DATE,'DD/MM/YYYY'),
              to_char(M.CARD_PRN_DATE,'dd/mm/yyyy') as CARD_PRN_DATE,
             case when M.card_prn_count!=0 then 'Y' 
             ELSE 'N' END AS CARD_PRINTED,
             M.EMIRATE_ID,
             M.PASSPORT_NUMBER,
             N.DESCRIPTION,
             M.CARD_PRN_COUNT,
             gc.DESCRIPTION as network_type,
             to_char(M.ADDED_DATE,'dd/mm/yyyy') as adate,
			 M.VIP_YN,
      K.SUM_INSURED-K.utilised_sum_insured as AVA_SUM_INSURED,L.GROUP_NAME,
      ROUND(ABS(NVL(M.INV_CRN_AMNT,M.MEM_TOTAL_PREMIUM) - NVL(M.CHNG_IN_AMNT,0) ),2) AS MEM_TOTAL_PREMIUM,
      ROUND(ABS(NVL(M.INV_CRN_AMNT,M.MEM_TOTAL_PREMIUM) - NVL(M.CHNG_IN_AMNT,0) ),2)/(select decode(IV.INV_GEN_PERIOD,'QTR',4,'HLF',2,1) from TPA_FIN_INVOICE iv where iv.invoice_seq_id=str_tab(1)) as Premium_Instalment,-- CR0229
      NULL AS CLM_AMOUNT,
      NULL AS Return_Premium,
      V_INV_TYPE as INVOICE_TYPE,
       CASE WHEN M.gender_general_type_id = 'MAL' THEN (NVL(nvl(EP.ip_op_premium_per_ind,EP.pol_total_excmat_premium),0))
            WHEN M.Gender_General_Type_Id = 'FEM' AND M.Marital_Status_Id ='MRD' 
                 AND M.MEM_AGE BETWEEN rec_pol_info.mat_premum_from_age AND rec_pol_info.mat_premum_to_age 
                  THEN (NVL(nvl(EP.ip_op_premium_per_ind,EP.pol_total_excmat_premium),0) + NVL(nvl(EP.mat_premium_per_ind,EP.pol_total_mat_premium),0))
            ELSE (NVL(nvl(EP.ip_op_premium_per_ind,EP.pol_total_excmat_premium),0))  
       end as "Member_Annual_Premium"
      FROM TPA_ENR_POLICY ep JOIN TPA_ENR_POLICY_GROUP pg ON (EP.Policy_Seq_Id = PG.policy_seq_id)
      JOIN TPA_ENR_POLICY_MEMBER M ON (PG.policy_group_seq_id = M.policy_group_seq_id)
      join tpa_group_registration l on (PG.group_reg_seq_id=l.group_reg_seq_id)
      JOIN TPA_RELATIONSHIP_CODE D ON (M.relship_type_id=D.relship_type_id)
      JOIN TPA_GENERAL_CODE E ON (E.general_type_id=M.gender_general_type_id)
      LEFT OUTER JOIN TPA_ENR_MEM_ADDRESS F ON (F.enr_address_seq_id = m.enr_address_seq_id)
      LEFT OUTER JOIN TPA_ENR_BANK_DTLS G ON (G.bank_seq_id = PG.bank_seq_id)
      LEFT OUTER JOIN TPA_STATE_CODE H ON (H.state_type_id=F.state_type_id)
      LEFT OUTER JOIN APP.TPA_CITY_CODE J ON (J.CITY_TYPE_ID=F.CITY_TYPE_ID)
      LEFT OUTER JOIN APP.TPA_NATIONALITIES_CODE N ON (N.NATIONALITY_ID=M.NATIONALITY_ID)
      left outer JOIN TPA_INS_PRODUCT TIP ON (EP.PRODUCT_SEQ_ID=TIP.PRODUCT_SEQ_ID)
      left outer join tpa_general_code GC ON (GC.GENERAL_TYPE_ID=TIP.PRODUCT_CAT_TYPE_ID)
      left outer JOIN app.tpa_enr_balance K ON (M.policy_group_seq_id=K.policy_group_seq_id)-- and CASE WHEN EP.Policy_Sub_General_Type_Id= 'PNF' THEN M.MEMBER_SEQ_ID=K.MEMBER_SEQ_ID)
       WHERE M.INV_CURNT_SEQ_ID = str_tab(1)
         AND ep.enrol_type_id = 'COR'  
         AND (m.mem_general_type_id != 'PFL' AND m.member_seq_id = k.member_seq_id OR k.member_seq_id IS NULL OR m.member_seq_id IS NULL)
         AND TRUNC(m.ADDED_DATE)<= v_inv_to_dt 
         AND EP.deleted_yn='N'
         AND m.deleted_yn='N'
         AND NVL(m.INV_TO_BE_GEN_YN,'N') = 'Y'
      )

      --SELECT * FROM renewal_mem WHERE rec_number BETWEEN str_tab(2) AND str_tab(2)+9;--64999;
      SELECT b.*, CASE WHEN POLICY_SUB_GENERAL_TYPE_ID = 'PFL' AND rn = 1 THEN FLOATER_SUM_INSURED
                  ELSE mem_sum_insured END AS mem_tot_sum_insured FROM
        (SELECT A.*, DENSE_RANK() OVER (ORDER BY employee_no, MEMBER_SEQ_ID, ROWNUM)
           Q FROM renewal_mem A ) b ;
           
     OPEN corp_mem_clm_inp_cur FOR
       SELECT NULL AS TPA_ENROLLMENT_ID,
              NULL AS MEM_NAME,
              NULL AS CLM_AMOUNT,
              NULL AS claim_status
       FROM DUAL;       
  END IF;

  UPDATE tpa_fin_invoice i 
     SET i.tot_premium  = v_tot_premium,
         i.inv_gen_date = sysdate
   WHERE i.invoice_seq_id=str_tab(1);

 ELSE
   
  --Credit Note
 
   /*OPEN Corporate_Enrl_cur FOR
      
WITH CLAIM_DATA AS
(SELECT IV.INVOICE_NUMBER,
             --CASE WHEN h.prod_general_type_id = 'PST' THEN 'S' ELSE 'U' END AS INV_TYPE,
             G.DESCRIPTION AS INV_TYPE,
             c.office_code AS LOC,
             'Groups' AS Type,
             EP.Policy_Number AS PolicyNo,
             D.ABBREVATION_CODE AS INS,
             GR.Group_Name AS Name,
             (M.MEMBER_SEQ_ID) AS Lives,
             to_char(EP.Effective_From_Date, 'dd/mm/yyyy') as Start_Date,
             (NVL(M.MEM_TOT_SUM_INSURED, 0)) AS Sum_Insured,
             ROUND((NVL(M.MEM_TOTAL_PREMIUM, 0)),2) AS Total_Premium,
               
             FLOAT_ACCOUNTS_PKG.get_claimed_amount(M.MEMBER_SEQ_ID) AS CLM_AMOUNT,
             
             ROUND(((EP.EFFECTIVE_TO_DATE - M.DATE_OF_EXIT) + CASE WHEN M.DATE_OF_INCEPTION = M.DATE_OF_EXIT THEN 1 ELSE 0 END)* 
              NVL(M.MEM_TOTAL_PREMIUM,0)/((EP.effective_to_date- 
              CASE WHEN EP.Effective_From_Date > m.date_of_inception THEN EP.Effective_From_Date 
                   ELSE m.date_of_inception END)+1),2) AS PRO_RTA_PREMIUM,
              
             (CASE WHEN NVL(M.CRN_TO_BE_GEN_ON_CNCL_YN,'N') = 'Y'AND M.STATUS_GENERAL_TYPE_ID = 'POC' 
                       AND TRUNC(M.DATE_OF_EXIT) <= TRUNC(v_inv_from_dt-EP.mem_cancl_days) THEN       
                 (CASE WHEN EP.logic_type_id = 'SC1' 
                                            THEN CASE WHEN FLOAT_ACCOUNTS_PKG.get_claimed_amount(M.MEMBER_SEQ_ID) > ROUND(((EP.EFFECTIVE_TO_DATE - M.DATE_OF_EXIT) + CASE WHEN M.DATE_OF_INCEPTION = M.DATE_OF_EXIT THEN 1 ELSE 0 END)* 
                                                           NVL(M.MEM_TOTAL_PREMIUM,0)/((EP.effective_to_date- CASE WHEN EP.Effective_From_Date > M.date_of_inception THEN EP.Effective_From_Date ELSE M.date_of_inception END)+1),2) 
                                                        THEN 0
                                                      ELSE
                                                        ROUND(((EP.EFFECTIVE_TO_DATE - M.DATE_OF_EXIT) + CASE WHEN M.DATE_OF_INCEPTION = M.DATE_OF_EXIT THEN 1 ELSE 0 END)* 
                                                        NVL(M.MEM_TOTAL_PREMIUM,0)/((EP.effective_to_date- CASE WHEN EP.Effective_From_Date > M.date_of_inception THEN EP.Effective_From_Date ELSE M.date_of_inception END)+1),2) 
                                                        - FLOAT_ACCOUNTS_PKG.get_claimed_amount(M.MEMBER_SEQ_ID) END
                                      WHEN EP.logic_type_id = 'SC2' 
                                           THEN CASE WHEN FLOAT_ACCOUNTS_PKG.get_mem_clm_cnt(M.MEMBER_SEQ_ID) > 0 THEN 0
                                                     ELSE ROUND(((EP.EFFECTIVE_TO_DATE - M.DATE_OF_EXIT) + CASE WHEN M.DATE_OF_INCEPTION = M.DATE_OF_EXIT THEN 1 ELSE 0 END)* 
                                                       NVL(M.MEM_TOTAL_PREMIUM,0)/((EP.effective_to_date- CASE WHEN EP.Effective_From_Date > M.date_of_inception THEN EP.Effective_From_Date ELSE M.date_of_inception END)+1),2)
                                                END 
                                      WHEN EP.logic_type_id = 'SC3' 
                                           THEN CASE WHEN FLOAT_ACCOUNTS_PKG.get_mem_clm_cnt(M.MEMBER_SEQ_ID) > 0 THEN
                                                    ROUND(((EP.EFFECTIVE_TO_DATE - M.DATE_OF_EXIT) + CASE WHEN M.DATE_OF_INCEPTION = M.DATE_OF_EXIT THEN 1 ELSE 0 END)* 
                                                       NVL(M.MEM_TOTAL_PREMIUM,0)/((EP.effective_to_date- 
                                                       CASE WHEN EP.Effective_From_Date > M.date_of_inception THEN EP.Effective_From_Date 
                                                            ELSE M.date_of_inception END)+1),2) END 
                                      
                                      WHEN EP.logic_type_id = 'SC4' 
                                           THEN CASE WHEN FLOAT_ACCOUNTS_PKG.get_claimed_amount(M.MEMBER_SEQ_ID) > ROUND(((EP.EFFECTIVE_TO_DATE - M.DATE_OF_EXIT) + CASE WHEN M.DATE_OF_INCEPTION = M.DATE_OF_EXIT THEN 1 ELSE 0 END)* 
                                                                                                                    NVL(M.MEM_TOTAL_PREMIUM,0)/((EP.effective_to_date- 
                                                                                                                    CASE WHEN EP.Effective_From_Date > M.date_of_inception THEN EP.Effective_From_Date 
                                                                                                                         ELSE M.date_of_inception END)+1),2) THEN 0
                                                     ELSE ROUND(((EP.EFFECTIVE_TO_DATE - M.DATE_OF_EXIT) + CASE WHEN M.DATE_OF_INCEPTION = M.DATE_OF_EXIT THEN 1 ELSE 0 END)* 
                                                       NVL(M.MEM_TOTAL_PREMIUM,0)/((EP.effective_to_date- 
                                                       CASE WHEN EP.Effective_From_Date > M.date_of_inception THEN EP.Effective_From_Date 
                                                            ELSE M.date_of_inception END)+1),2) END
                   END) 
                  ELSE 0 END + CASE WHEN NVL(M.INV_TO_BE_GEN_YN,'N') = 'Y' THEN 0 
                                    ELSE CASE WHEN NVL(M.CRN_TO_BE_GEN_YN,'N') = 'Y' THEN  
                                                   (NVL(M.INV_CRN_AMNT,0) - NVL(CHNG_IN_AMNT,0)) 
                                              ELSE 0 END END) AS Return_Premium, 
             ROUND( (CASE WHEN NVL(M.CRN_TO_BE_GEN_ON_CNCL_YN,'N') = 'Y'AND M.STATUS_GENERAL_TYPE_ID = 'POC'
                               AND TRUNC(M.DATE_OF_EXIT) <= TRUNC(v_inv_from_dt-EP.mem_cancl_days) THEN       
                 (CASE WHEN EP.logic_type_id = 'SC1' 
                                            THEN CASE WHEN FLOAT_ACCOUNTS_PKG.get_claimed_amount(M.MEMBER_SEQ_ID) > ROUND(((EP.EFFECTIVE_TO_DATE - M.DATE_OF_EXIT) + CASE WHEN M.DATE_OF_INCEPTION = M.DATE_OF_EXIT THEN 1 ELSE 0 END)* 
                                                           NVL(M.MEM_TOTAL_PREMIUM,0)/((EP.effective_to_date- CASE WHEN EP.Effective_From_Date > M.date_of_inception THEN EP.Effective_From_Date ELSE M.date_of_inception END)+1),2) 
                                                        THEN 0
                                                      ELSE
                                                        ROUND(((EP.EFFECTIVE_TO_DATE - M.DATE_OF_EXIT) + CASE WHEN M.DATE_OF_INCEPTION = M.DATE_OF_EXIT THEN 1 ELSE 0 END)* 
                                                        NVL(M.MEM_TOTAL_PREMIUM,0)/((EP.effective_to_date- CASE WHEN EP.Effective_From_Date > M.date_of_inception THEN EP.Effective_From_Date ELSE M.date_of_inception END)+1),2) 
                                                        - FLOAT_ACCOUNTS_PKG.get_claimed_amount(M.MEMBER_SEQ_ID) END
                                      WHEN EP.logic_type_id = 'SC2' 
                                           THEN CASE WHEN FLOAT_ACCOUNTS_PKG.get_mem_clm_cnt(M.MEMBER_SEQ_ID) > 0 THEN 0
                                                     ELSE ROUND(((EP.EFFECTIVE_TO_DATE - M.DATE_OF_EXIT) + CASE WHEN M.DATE_OF_INCEPTION = M.DATE_OF_EXIT THEN 1 ELSE 0 END)* 
                                                       NVL(M.MEM_TOTAL_PREMIUM,0)/((EP.effective_to_date- CASE WHEN EP.Effective_From_Date > M.date_of_inception THEN EP.Effective_From_Date ELSE M.date_of_inception END)+1),2)
                                                END 
                                      WHEN EP.logic_type_id = 'SC3' 
                                           THEN CASE WHEN FLOAT_ACCOUNTS_PKG.get_mem_clm_cnt(M.MEMBER_SEQ_ID) > 0 THEN
                                                    ROUND(((EP.EFFECTIVE_TO_DATE - M.DATE_OF_EXIT) + CASE WHEN M.DATE_OF_INCEPTION = M.DATE_OF_EXIT THEN 1 ELSE 0 END)* 
                                                       NVL(M.MEM_TOTAL_PREMIUM,0)/((EP.effective_to_date- 
                                                       CASE WHEN EP.Effective_From_Date > M.date_of_inception THEN EP.Effective_From_Date 
                                                            ELSE M.date_of_inception END)+1),2) END 
                                      
                                      WHEN EP.logic_type_id = 'SC4' 
                                           THEN CASE WHEN FLOAT_ACCOUNTS_PKG.get_claimed_amount(M.MEMBER_SEQ_ID) > ROUND(((EP.EFFECTIVE_TO_DATE - M.DATE_OF_EXIT) + CASE WHEN M.DATE_OF_INCEPTION = M.DATE_OF_EXIT THEN 1 ELSE 0 END)* 
                                                                                                                    NVL(M.MEM_TOTAL_PREMIUM,0)/((EP.effective_to_date- 
                                                                                                                    CASE WHEN EP.Effective_From_Date > M.date_of_inception THEN EP.Effective_From_Date 
                                                                                                                         ELSE M.date_of_inception END)+1),2) THEN 0
                                                     ELSE ROUND(((EP.EFFECTIVE_TO_DATE - M.DATE_OF_EXIT) + CASE WHEN M.DATE_OF_INCEPTION = M.DATE_OF_EXIT THEN 1 ELSE 0 END)* 
                                                       NVL(M.MEM_TOTAL_PREMIUM,0)/((EP.effective_to_date- 
                                                       CASE WHEN EP.Effective_From_Date > M.date_of_inception THEN EP.Effective_From_Date 
                                                            ELSE M.date_of_inception END)+1),2) END
                   END) 
                  ELSE 0 END + CASE WHEN NVL(M.INV_TO_BE_GEN_YN,'N') = 'Y' THEN 0 
                                    ELSE CASE WHEN NVL(M.CRN_TO_BE_GEN_YN,'N') = 'Y' THEN 
                                                   (NVL(M.INV_CRN_AMNT,0) - NVL(CHNG_IN_AMNT,0)) 
                                              ELSE 0 END END),2) AS TPA,
             round(Months_between(EP.EFFECTIVE_TO_DATE, EP.Effective_From_Date)) / 12 AS Tenure,
             to_char(EP.EFFECTIVE_TO_DATE, 'dd/mm/yyyy') AS EXPIRY_DATE,
             EP.Groupid || EP.Sub_Group_Id AS ID,
             f.Commission_To_Tpa,
             IV.INVOICE_TYPE,
           (CASE WHEN m.gender_general_type_id = 'MAL' THEN (NVL(nvl(EP.ip_op_premium_per_ind,EP.pol_total_excmat_premium),0))
                              WHEN m.Gender_General_Type_Id = 'FEM' AND m.Marital_Status_Id ='MRD' 
                                   AND M.MEM_AGE BETWEEN rec_pol_info.mat_premum_from_age AND rec_pol_info.mat_premum_to_age 
                                       THEN (NVL(nvl(EP.ip_op_premium_per_ind,EP.pol_total_excmat_premium),0) + NVL(nvl(EP.mat_premium_per_ind,EP.pol_total_mat_premium),0))
                                ELSE (NVL(nvl(EP.ip_op_premium_per_ind,EP.pol_total_excmat_premium),0))   END) as Member_Annual_Premium
        FROM APP.TPA_ENR_POLICY_MEMBER M 
        JOIN FIN_APP.TPA_FIN_INVOICE IV ON (M.CRN_CURNT_SEQ_ID = IV.INVOICE_SEQ_ID)
        JOIN tpa_enr_policy EP ON (IV.POLICY_SEQ_ID=EP.POLICY_SEQ_ID)
        JOIN APP.TPA_GROUP_REGISTRATION  GR ON (EP.GROUP_REG_SEQ_ID=GR.GROUP_REG_SEQ_ID)
        INNER JOIN tpa_office_info C ON (c.Tpa_Office_Seq_Id = C.Tpa_Office_Seq_Id)
        INNER JOIN tpa_ins_info D ON (EP.INS_SEQ_ID = D.INS_SEQ_ID)
        JOIN TPA_INS_ASSOC_OFF_PRODUCT F ON (F.INS_SEQ_ID = EP.INS_SEQ_ID AND EP.PRODUCT_SEQ_ID = F.PRODUCT_SEQ_ID AND F.ENROL_TYPE_ID = EP.ENROL_TYPE_ID)
        JOIN tpa_ins_product H ON (EP.product_seq_id = h.product_seq_id)
        LEFT OUTER JOIN APP.TPA_GENERAL_CODE G ON (IV.INV_GEN_PERIOD=G.GENERAL_TYPE_ID)
        WHERE IV.invoice_seq_id = str_tab(1)
           AND ((TRUNC(M.DATE_OF_EXIT) <= TRUNC(v_inv_from_dt-rec_pol_info.mem_cancl_days) AND NVL(M.CRN_TO_BE_GEN_ON_CNCL_YN,'N') = 'Y' AND FLOAT_ACCOUNTS_PKG.get_mem_clm_inp_cnt(M.MEMBER_SEQ_ID) = 0) OR (NVL(M.CRN_TO_BE_GEN_YN,'N') = 'Y'))
           AND EP.enrol_type_id = 'COR' 
           AND EP.deleted_yn = 'N' 
           AND M.DELETED_YN = 'N')
 SELECT INVOICE_NUMBER,
        INV_TYPE,
        LOC,
        Type,
        PolicyNo,
        INS,
        Name,
        COUNT(Lives) AS Lives,
        Start_Date AS "Start Date",
        SUM(Sum_Insured) AS "Sum Insured",
        SUM(Total_Premium) AS "Premium",
        SUM(CLM_AMOUNT) AS CLM_AMOUNT,
        SUM(Return_Premium) AS "Return_Premium",
        SUM(TPA) AS TPA,
        Tenure,
        EXPIRY_DATE,
        ID,
        COMMISSION_TO_TPA,
        INVOICE_TYPE,
        sum(Member_Annual_Premium) as Member_Annual_Premium
    FROM CLAIM_DATA CD       
    --WHERE CD.PRO_RTA_PREMIUM > CLM_AMOUNT
    GROUP BY INVOICE_NUMBER,
            INV_TYPE,
            LOC,
            Type,
            PolicyNo,
            INS,
            Name,
            Start_Date,Sum_Insured,Tenure,EXPIRY_DATE,ID,COMMISSION_TO_TPA,INVOICE_TYPE;*/ -- commented in CR0229


  OPEN corp_dtl_premium_cur FOR
   WITH renewal_mem AS (
     SELECT EP.policy_number,
             employee_no,
             B.insured_name,
             M.tpa_enrollment_id,
             M.mem_name,
             D.relship_description,
             E.description as gender,
             --decode(EP.POLICY_SUB_GENERAL_TYPE_ID,'PFL',B.FLOATER_SUM_INSURED,M.mem_tot_sum_insured) AS mem_tot_sum_insured,
             row_number() over (PARTITION BY B.employee_no ORDER BY M.tpa_enrollment_id) rn,
             B.FLOATER_SUM_INSURED, --M.mem_tot_sum_insured AS mem_sum_insured, 
             EP.POLICY_SUB_GENERAL_TYPE_ID,
             case when EP.POLICY_SUB_GENERAL_TYPE_ID='PFL' and D.relship_description='Principal'  then K.SUM_INSURED else M.mem_tot_sum_insured end as mem_sum_insured,
             M.mem_age,
             TO_CHAR(M.mem_dob,'DD/MM/YYYY') as mem_dob,
             B.department,
             TO_CHAR(B.date_of_joining,'DD/MM/YYYY') as date_of_joining,
             M.photo_present_yn,
             F.address_1||F.address_2||F.address_3 as address,
             J.CITY_DESCRIPTION,
             --F.city_type_id,
             H.state_name,
             F.pin_code,
             ttk_util_pkg.fn_decrypt(G.bank_account_no) as bank_account_no, --//ED
             M.domicilary_limit,
             ttk_util_pkg.fn_decrypt(F.email_id) as email_id, --//ED
             ttk_util_pkg.fn_decrypt(F.mobile_no) as mobile_no, --//ED
             B.certificate_no,
             ttk_util_pkg.fn_decrypt(B.creditcard_no) as creditcard_no,--//ED
             to_char(M.date_of_inception,'DD/MM/YYYY') AS date_of_inception,
             to_char(M.date_of_exit,'DD/MM/YYYY') AS date_of_exit,
             M.member_remarks AS policy_remarks,
             B.tpa_enrollment_number,
             M.member_seq_id,
             case when M.MARITAL_STATUS_ID='MRD' THEN 'Married'
             ELSE 'Single' END AS M_STATUS,
             CASE  WHEN M.status_general_type_id = 'POA' THEN 'Active'
             ELSE 'Cancelled' end as status,
             to_char(EP.ADDED_DATE,'DD/MM/YYYY'),
              to_char(M.CARD_PRN_DATE,'dd/mm/yyyy') as CARD_PRN_DATE,
             case when M.card_prn_count!=0 then 'Y' 
             ELSE 'N' END AS CARD_PRINTED,
             M.EMIRATE_ID,
             M.PASSPORT_NUMBER,
             N.DESCRIPTION,
             M.CARD_PRN_COUNT,
             gc.DESCRIPTION as network_type,
             to_char(M.ADDED_DATE,'dd/mm/yyyy') as adate,
			 M.VIP_YN,
      K.SUM_INSURED-K.utilised_sum_insured as AVA_SUM_INSURED,L.GROUP_NAME,
      ROUND(M.MEM_TOTAL_PREMIUM,2) AS MEM_TOTAL_PREMIUM,
      null as Premium_Instalment,-- CR0229
      FLOAT_ACCOUNTS_PKG.get_claimed_amount(M.MEMBER_SEQ_ID) AS CLM_AMOUNT,
      (CASE WHEN NVL(M.CRN_TO_BE_GEN_ON_CNCL_YN,'N') = 'Y'AND M.STATUS_GENERAL_TYPE_ID = 'POC' 
                 AND TRUNC(M.DATE_OF_EXIT) <= TRUNC(v_inv_from_dt-TRUNC(EP.mem_cancl_days)) THEN       
                 (CASE WHEN EP.logic_type_id = 'SC1' ------******************************************************************
                                            THEN CASE WHEN FLOAT_ACCOUNTS_PKG.get_claimed_amount(M.MEMBER_SEQ_ID) > ROUND(((TRUNC(EP.EFFECTIVE_TO_DATE) - TRUNC(M.DATE_OF_EXIT)) + CASE WHEN GREATEST(TRUNC(EP.EFFECTIVE_FROM_DATE), TRUNC(M.DATE_OF_INCEPTION)) = TRUNC(M.DATE_OF_EXIT) THEN 1 ELSE 0 END)* --
                                                           NVL(M.MEM_TOTAL_PREMIUM,0)/((TRUNC(EP.effective_to_date)- CASE WHEN EP.Effective_From_Date > M.date_of_inception THEN TRUNC(EP.Effective_From_Date) ELSE TRUNC(M.date_of_inception) END)+1),2) 
                                                        THEN 0
                                                      ELSE
                                                        ROUND(((TRUNC(EP.EFFECTIVE_TO_DATE) - TRUNC(M.DATE_OF_EXIT)) + CASE WHEN GREATEST(TRUNC(EP.EFFECTIVE_FROM_DATE), TRUNC(M.DATE_OF_INCEPTION)) = TRUNC(M.DATE_OF_EXIT) THEN 1 ELSE 0 END)* 
                                                        NVL(M.MEM_TOTAL_PREMIUM,0)/((TRUNC(EP.effective_to_date)- CASE WHEN EP.Effective_From_Date > M.date_of_inception THEN TRUNC(EP.Effective_From_Date) ELSE TRUNC(M.date_of_inception) END)+1),2) 
                                                        - FLOAT_ACCOUNTS_PKG.get_claimed_amount(M.MEMBER_SEQ_ID) END
                                      WHEN EP.logic_type_id = 'SC2' 
                                           THEN CASE WHEN FLOAT_ACCOUNTS_PKG.get_mem_clm_cnt(M.MEMBER_SEQ_ID) > 0 THEN 0
                                                     ELSE ROUND(((TRUNC(EP.EFFECTIVE_TO_DATE) - TRUNC(M.DATE_OF_EXIT)) + CASE WHEN GREATEST(TRUNC(EP.EFFECTIVE_FROM_DATE), TRUNC(M.DATE_OF_INCEPTION)) = TRUNC(M.DATE_OF_EXIT) THEN 1 ELSE 0 END)* 
                                                       NVL(M.MEM_TOTAL_PREMIUM,0)/((TRUNC(EP.effective_to_date)- CASE WHEN EP.Effective_From_Date > M.date_of_inception THEN TRUNC(EP.Effective_From_Date) ELSE TRUNC(M.date_of_inception) END)+1),2)
                                                END 
                                      WHEN EP.logic_type_id = 'SC3' 
                                           THEN CASE WHEN FLOAT_ACCOUNTS_PKG.get_mem_clm_cnt(M.MEMBER_SEQ_ID) > 0 THEN
                                                    ROUND(((TRUNC(EP.EFFECTIVE_TO_DATE) - TRUNC(M.DATE_OF_EXIT)) + CASE WHEN GREATEST(TRUNC(EP.EFFECTIVE_FROM_DATE), TRUNC(M.DATE_OF_INCEPTION)) = M.DATE_OF_EXIT THEN 1 ELSE 0 END)* 
                                                       NVL(M.MEM_TOTAL_PREMIUM,0)/((TRUNC(EP.effective_to_date)- 
                                                       CASE WHEN EP.Effective_From_Date > M.date_of_inception THEN TRUNC(EP.Effective_From_Date) 
                                                            ELSE TRUNC(M.date_of_inception) END)+1),2) END 
                                      
                                      WHEN EP.logic_type_id = 'SC4' 
                                           THEN CASE WHEN FLOAT_ACCOUNTS_PKG.get_claimed_amount(M.MEMBER_SEQ_ID) > ROUND(((TRUNC(EP.EFFECTIVE_TO_DATE) - TRUNC(M.DATE_OF_EXIT)) + CASE WHEN GREATEST(TRUNC(EP.EFFECTIVE_FROM_DATE), TRUNC(M.DATE_OF_INCEPTION)) = TRUNC(M.DATE_OF_EXIT) THEN 1 ELSE 0 END)* 
                                                                                                                    NVL(M.MEM_TOTAL_PREMIUM,0)/((TRUNC(EP.effective_to_date)- 
                                                                                                                    CASE WHEN EP.Effective_From_Date > M.date_of_inception THEN TRUNC(EP.Effective_From_Date)
                                                                                                                         ELSE TRUNC(M.date_of_inception) END)+1),2) THEN 0
                                                     ELSE ROUND(((TRUNC(EP.EFFECTIVE_TO_DATE) - TRUNC(M.DATE_OF_EXIT)) + CASE WHEN GREATEST(TRUNC(EP.EFFECTIVE_FROM_DATE), TRUNC(M.DATE_OF_INCEPTION)) = TRUNC(M.DATE_OF_EXIT) THEN 1 ELSE 0 END)* 
                                                       NVL(M.MEM_TOTAL_PREMIUM,0)/((TRUNC(EP.effective_to_date)- 
                                                       CASE WHEN EP.Effective_From_Date > M.date_of_inception THEN TRUNC(EP.Effective_From_Date) 
                                                            ELSE TRUNC(M.date_of_inception) END)+1),2) END
                   END) 
                  ELSE 0 END /*+ CASE WHEN NVL(M.INV_TO_BE_GEN_YN,'N') = 'Y' THEN 0 
                                    ELSE CASE WHEN NVL(M.CRN_TO_BE_GEN_YN,'N') = 'Y' THEN 
                                                   (NVL(M.INV_CRN_AMNT,0) - NVL(CHNG_IN_AMNT,0)) 
                                              ELSE 0 END END*/) AS Return_Premium,
                                      
      V_INV_TYPE as INVOICE_TYPE,
       							
CASE WHEN M.gender_general_type_id = 'MAL' THEN (NVL(nvl(EP.ip_op_premium_per_ind,EP.pol_total_excmat_premium),0))
                              WHEN M.Gender_General_Type_Id = 'FEM' AND M.Marital_Status_Id ='MRD' 
                                   AND M.MEM_AGE BETWEEN rec_pol_info.mat_premum_from_age AND rec_pol_info.mat_premum_to_age 
                                       THEN (NVL(nvl(EP.ip_op_premium_per_ind,EP.pol_total_excmat_premium),0) + NVL(nvl(EP.mat_premium_per_ind,EP.pol_total_mat_premium),0))
                                ELSE (NVL(nvl(EP.ip_op_premium_per_ind,EP.pol_total_excmat_premium),0))								  END as "Member_Annual_Premium"
      
      FROM TPA_ENR_POLICY EP JOIN TPA_ENR_POLICY_GROUP B ON (EP.Policy_Seq_Id = B.policy_seq_id)
      JOIN TPA_ENR_POLICY_MEMBER M ON (B.policy_group_seq_id = M.policy_group_seq_id)
      join tpa_group_registration l on (B.group_reg_seq_id=l.group_reg_seq_id)
      JOIN TPA_RELATIONSHIP_CODE D ON (M.relship_type_id=D.relship_type_id)
      JOIN TPA_GENERAL_CODE E ON (E.general_type_id=M.gender_general_type_id)
      LEFT OUTER JOIN TPA_ENR_MEM_ADDRESS F ON (F.enr_address_seq_id = m.enr_address_seq_id)
      LEFT OUTER JOIN TPA_ENR_BANK_DTLS G ON (G.bank_seq_id = b.bank_seq_id)
      LEFT OUTER JOIN TPA_STATE_CODE H ON (H.state_type_id=F.state_type_id)
      LEFT OUTER JOIN APP.TPA_CITY_CODE J ON (J.CITY_TYPE_ID=F.CITY_TYPE_ID)
      LEFT OUTER JOIN APP.TPA_NATIONALITIES_CODE N ON (N.NATIONALITY_ID=M.NATIONALITY_ID)
      left outer JOIN TPA_INS_PRODUCT TIP ON (EP.PRODUCT_SEQ_ID=TIP.PRODUCT_SEQ_ID)
      left outer join tpa_general_code GC ON (GC.GENERAL_TYPE_ID=TIP.PRODUCT_CAT_TYPE_ID)
      left outer JOIN app.tpa_enr_balance K ON (M.policy_group_seq_id=K.policy_group_seq_id)-- and CASE WHEN EP.Policy_Sub_General_Type_Id= 'PNF' THEN M.MEMBER_SEQ_ID=K.MEMBER_SEQ_ID)
      WHERE M.CRN_CURNT_SEQ_ID = str_tab(1)
        AND EP.enrol_type_id = 'COR'  
        AND (M.mem_general_type_id != 'PFL' AND M.member_seq_id = k.member_seq_id OR k.member_seq_id IS NULL OR M.member_seq_id IS NULL)
        AND ((TRUNC(M.DATE_OF_EXIT) <= TRUNC(v_inv_from_dt-rec_pol_info.mem_cancl_days) AND NVL(M.CRN_TO_BE_GEN_ON_CNCL_YN,'N') = 'Y' AND get_mem_clm_inp_cnt(M.MEMBER_SEQ_ID) = 0) /*OR (NVL(M.CRN_TO_BE_GEN_YN,'N') = 'Y')*/)        
        AND B.deleted_yn='N'
        AND M.deleted_yn='N'
        --AND M.STATUS_GENERAL_TYPE_ID = 'POC'
        AND M.INV_LNKED_SEQ_IDS IS NOT NULL
      )

      --SELECT * FROM renewal_mem WHERE rec_number BETWEEN str_tab(2) AND str_tab(2)+9;--64999;
      SELECT b.*, CASE WHEN POLICY_SUB_GENERAL_TYPE_ID = 'PFL' AND rn = 1 THEN FLOATER_SUM_INSURED
                  ELSE mem_sum_insured END AS mem_tot_sum_insured FROM
        (SELECT A.*, DENSE_RANK() OVER (ORDER BY employee_no, MEMBER_SEQ_ID, ROWNUM)
           Q FROM renewal_mem A ) b ;
           
    OPEN corp_mem_clm_inp_cur FOR
       SELECT M.TPA_ENROLLMENT_ID,
              M.MEM_NAME,
              to_char(FLOAT_ACCOUNTS_PKG.get_claimed_amount(M.MEMBER_SEQ_ID)) AS CLM_AMOUNT,
              'In-progress/Required information' AS claim_status
       FROM APP.TPA_ENR_POLICY EP 
       JOIN APP.TPA_ENR_POLICY_GROUP PG ON (EP.POLICY_SEQ_ID=PG.POLICY_SEQ_ID)
       JOIN APP.TPA_ENR_POLICY_MEMBER M ON (PG.POLICY_GROUP_SEQ_ID=M.POLICY_GROUP_SEQ_ID)
        WHERE EP.POLICY_SEQ_ID = str_tab(2)
          AND M.STATUS_GENERAL_TYPE_ID = 'POC'
          AND ((TRUNC(M.DATE_OF_EXIT) <= TRUNC(v_inv_from_dt-rec_pol_info.mem_cancl_days)AND NVL(M.CRN_TO_BE_GEN_ON_CNCL_YN,'N') = 'Y') OR (NVL(M.CRN_TO_BE_GEN_ON_CNCL_YN,'N') = 'N'))
          AND M.DELETED_YN = 'N' 
          --AND NVL(M.INVOICE_GEN_YN_DEL,'N') = 'N'
          --AND M.INVOICE_SEQ_ID_ADD IS NOT NULL
          AND NVL(M.MEM_TOTAL_PREMIUM,0) != 0
          AND get_mem_clm_inp_cnt(M.MEMBER_SEQ_ID) > 0;      
           
  
 END IF; 
    
   IF v_inv_type = 'ADD' THEN
    v_batch_name := 'BATCH-' ||str_tab(1)||'-'||
                    REPLACE((v_start_date || '-' || v_end_date), '/', '');
                     
    SELECT COUNT(1)
      INTO v_no_of_transations
      FROM app.tpa_enr_policy_member A
     WHERE a.inv_curnt_seq_id = str_tab(1);
   ELSE
     v_batch_name := 'BATCH-' ||str_tab(1)||'-'||
                    REPLACE((v_start_date ), '/', '');
     SELECT COUNT(1)
      INTO v_no_of_transations
      FROM app.tpa_enr_policy_member A
     WHERE a.crn_curnt_seq_id = str_tab(1);
   END IF;
   
    INSERT INTO tpa_inv_batch
      (batch_seq_id,
       batch_date,
       no_of_transations,
       batch_name,
       added_date,
       added_by,
       batch_name_pdf,
       invoice_seq_id)
    VALUES
      (inv_batch_seq.NEXTVAL,
       SYSDATE,
       v_no_of_transations,
       v_batch_name,
       SYSDATE,
       v_added_by,
       v_batch_name||'.pdf',
       str_tab(1))
    RETURNING batch_seq_id INTO v_batch_seq_id;

    /*UPDATE tpa_fin_policy_details a
       SET a.inv_flag = 'Y', a.batch_seq_id = v_batch_seq_id
     WHERE A.invoice_seq_id = v_invoice_seq_id
       AND A.inv_flag = 'N';*/
   IF v_inv_type = 'ADD' THEN    
    IF V_INCLUDE_OLD_YN = 'N' THEN
      FOR j IN (SELECT M.MEMBER_SEQ_ID,ROUND(ABS(NVL(M.INV_CRN_AMNT,M.MEM_TOTAL_PREMIUM) - NVL(M.CHNG_IN_AMNT,0) ),2) AS INV_CRN_AMNT
                FROM APP.TPA_ENR_POLICY EP 
                JOIN APP.TPA_ENR_POLICY_GROUP PG ON (EP.POLICY_SEQ_ID=PG.POLICY_SEQ_ID)
                JOIN APP.TPA_ENR_POLICY_MEMBER M ON (PG.POLICY_GROUP_SEQ_ID=M.POLICY_GROUP_SEQ_ID)
                WHERE EP.POLICY_SEQ_ID = str_tab(2)
                  AND M.INV_CURNT_SEQ_ID = str_tab(1)
                  AND TRUNC(M.ADDED_DATE) BETWEEN v_inv_from_dt AND v_inv_to_dt
                  AND M.DELETED_YN = 'N' 
                  AND NVL(M.INV_TO_BE_GEN_YN,'N') = 'Y'
                 )
          LOOP
            UPDATE app.tpa_enr_policy_member m 
              SET M.INV_GEN_YN        = 'Y',
                  M.INV_TO_BE_GEN_YN  = NULL,
                  M.INV_CRN_AMNT      = M.MEM_TOTAL_PREMIUM,
                  M.INV_AMOUNT        = J.INV_CRN_AMNT,
                  M.INV_CURNT_SEQ_ID  = NULL,
                  M.INV_LNKED_SEQ_IDS = CASE WHEN INV_LNKED_SEQ_IDS IS NULL THEN TO_CHAR(str_tab(1)) ELSE INV_LNKED_SEQ_IDS||'|'||TO_CHAR(str_tab(1)) END,
                  M.UPDATED_FRM_MODL  = 'Invoicing Generation'
            WHERE M. MEMBER_SEQ_ID = J.MEMBER_SEQ_ID;
       END LOOP;
          
     ELSE
       FOR j IN (SELECT M.MEMBER_SEQ_ID,ROUND(ABS(NVL(M.INV_CRN_AMNT,M.MEM_TOTAL_PREMIUM) - NVL(M.CHNG_IN_AMNT,0) ),2) AS INV_CRN_AMNT
                FROM APP.TPA_ENR_POLICY EP 
                JOIN APP.TPA_ENR_POLICY_GROUP PG ON (EP.POLICY_SEQ_ID=PG.POLICY_SEQ_ID)
                JOIN APP.TPA_ENR_POLICY_MEMBER M ON (PG.POLICY_GROUP_SEQ_ID=M.POLICY_GROUP_SEQ_ID)
                WHERE EP.POLICY_SEQ_ID = str_tab(2)
                  AND M.INV_CURNT_SEQ_ID = str_tab(1)
                  AND TRUNC(M.ADDED_DATE) <= v_inv_to_dt
                  AND M.DELETED_YN = 'N' 
                  AND NVL(M.INV_TO_BE_GEN_YN,'N') = 'Y'
                 )
          LOOP
            UPDATE app.tpa_enr_policy_member m 
              SET M.INV_GEN_YN        = 'Y',
                  M.INV_TO_BE_GEN_YN  = NULL,
                  M.INV_CRN_AMNT      = M.MEM_TOTAL_PREMIUM,
                  M.INV_AMOUNT        = J.INV_CRN_AMNT,
                  M.INV_CURNT_SEQ_ID  = NULL,
                  M.INV_LNKED_SEQ_IDS = CASE WHEN INV_LNKED_SEQ_IDS IS NULL THEN TO_CHAR(str_tab(1)) ELSE INV_LNKED_SEQ_IDS||'|'||TO_CHAR(str_tab(1)) END,
                  M.UPDATED_FRM_MODL  = 'Invoicing Generation'
            WHERE M. MEMBER_SEQ_ID = J.MEMBER_SEQ_ID;
       END LOOP;
       
     END IF;    
   ELSE
     FOR j IN (WITH CLM_DETAILS AS
                  (SELECT M.MEMBER_SEQ_ID,
                  (CASE WHEN NVL(M.CRN_TO_BE_GEN_ON_CNCL_YN,'N') = 'Y'AND M.STATUS_GENERAL_TYPE_ID = 'POC' 
                             AND TRUNC(M.DATE_OF_EXIT) <= TRUNC(v_inv_from_dt-EP.mem_cancl_days) THEN       
                       (CASE WHEN EP.logic_type_id = 'SC1' 
                                                  THEN CASE WHEN FLOAT_ACCOUNTS_PKG.get_claimed_amount(M.MEMBER_SEQ_ID) > ROUND(((TRUNC(EP.EFFECTIVE_TO_DATE) - TRUNC(M.DATE_OF_EXIT)) + CASE WHEN TRUNC(M.DATE_OF_INCEPTION) = TRUNC(M.DATE_OF_EXIT) THEN 1 ELSE 0 END)* 
                                                                 NVL(M.MEM_TOTAL_PREMIUM,0)/((TRUNC(EP.effective_to_date) - CASE WHEN EP.Effective_From_Date > M.date_of_inception THEN TRUNC(EP.Effective_From_Date) ELSE TRUNC(M.date_of_inception) END)+1),2) 
                                                              THEN 0
                                                            ELSE
                                                              ROUND(((TRUNC(EP.EFFECTIVE_TO_DATE) - TRUNC(M.DATE_OF_EXIT)) + CASE WHEN TRUNC(M.DATE_OF_INCEPTION) = TRUNC(M.DATE_OF_EXIT) THEN 1 ELSE 0 END)* 
                                                              NVL(M.MEM_TOTAL_PREMIUM,0)/((TRUNC(EP.effective_to_date)- CASE WHEN EP.Effective_From_Date > M.date_of_inception THEN TRUNC(EP.Effective_From_Date) ELSE TRUNC(M.date_of_inception) END)+1),2) 
                                                              - FLOAT_ACCOUNTS_PKG.get_claimed_amount(M.MEMBER_SEQ_ID) END
                                            WHEN EP.logic_type_id = 'SC2' 
                                                 THEN CASE WHEN FLOAT_ACCOUNTS_PKG.get_mem_clm_cnt(M.MEMBER_SEQ_ID) > 0 THEN 0
                                                           ELSE ROUND(((TRUNC(EP.EFFECTIVE_TO_DATE) - TRUNC(M.DATE_OF_EXIT)) + CASE WHEN TRUNC(M.DATE_OF_INCEPTION) = TRUNC(M.DATE_OF_EXIT) THEN 1 ELSE 0 END)* 
                                                             NVL(M.MEM_TOTAL_PREMIUM,0)/((TRUNC(EP.effective_to_date)- CASE WHEN EP.Effective_From_Date > M.date_of_inception THEN TRUNC(EP.Effective_From_Date) ELSE TRUNC(M.date_of_inception) END)+1),2)
                                                      END 
                                            WHEN EP.logic_type_id = 'SC3' 
                                                 THEN CASE WHEN FLOAT_ACCOUNTS_PKG.get_mem_clm_cnt(M.MEMBER_SEQ_ID) > 0 THEN
                                                          ROUND(((TRUNC(EP.EFFECTIVE_TO_DATE) - TRUNC(M.DATE_OF_EXIT)) + CASE WHEN TRUNC(M.DATE_OF_INCEPTION) = TRUNC(M.DATE_OF_EXIT) THEN 1 ELSE 0 END)* 
                                                             NVL(M.MEM_TOTAL_PREMIUM,0)/((TRUNC(EP.effective_to_date)- 
                                                             CASE WHEN EP.Effective_From_Date > M.date_of_inception THEN TRUNC(EP.Effective_From_Date) 
                                                                  ELSE TRUNC(M.date_of_inception) END)+1),2) END 
                                            
                                            WHEN EP.logic_type_id = 'SC4' 
                                                 THEN CASE WHEN FLOAT_ACCOUNTS_PKG.get_claimed_amount(M.MEMBER_SEQ_ID) > ROUND(((TRUNC(EP.EFFECTIVE_TO_DATE) - TRUNC(M.DATE_OF_EXIT)) + CASE WHEN TRUNC(M.DATE_OF_INCEPTION) = TRUNC(M.DATE_OF_EXIT) THEN 1 ELSE 0 END)* 
                                                                                                                          NVL(M.MEM_TOTAL_PREMIUM,0)/((EP.effective_to_date- 
                                                                                                                          CASE WHEN EP.Effective_From_Date > M.date_of_inception THEN TRUNC(EP.Effective_From_Date)
                                                                                                                               ELSE TRUNC(M.date_of_inception) END)+1),2) THEN 0
                                                           ELSE ROUND(((TRUNC(EP.EFFECTIVE_TO_DATE) - TRUNC(M.DATE_OF_EXIT)) + CASE WHEN TRUNC(M.DATE_OF_INCEPTION) = TRUNC(M.DATE_OF_EXIT) THEN 1 ELSE 0 END)* 
                                                             NVL(M.MEM_TOTAL_PREMIUM,0)/((EP.effective_to_date- 
                                                             CASE WHEN EP.Effective_From_Date > M.date_of_inception THEN TRUNC(EP.Effective_From_Date)
                                                                  ELSE TRUNC(M.date_of_inception) END)+1),2) END
                         END) 
                      ELSE 0 END) AS MEM_CNCL_PREIUM,
                     CASE WHEN NVL(M.INV_TO_BE_GEN_YN,'N') = 'Y' THEN 0 
                          ELSE CASE WHEN NVL(M.CRN_TO_BE_GEN_YN,'N') = 'Y' THEN (NVL(M.INV_CRN_AMNT,0) - NVL(CHNG_IN_AMNT,0)) 
                                    ELSE 0 END END AS REFUND_PREIUM,
                            
                     CASE WHEN TRUNC(M.DATE_OF_EXIT) <= TRUNC(v_inv_from_dt-EP.mem_cancl_days) 
                               AND NVL(M.CRN_TO_BE_GEN_ON_CNCL_YN,'N') = 'Y' AND NVL(M.CRN_GEN_ON_CNCL_YN,'N') = 'N' THEN 'Y' 
                           ELSE 'N' END AS MEM_CNCL_CRN_GEN_YN
                             
                   FROM APP.TPA_ENR_POLICY EP 
                   JOIN APP.TPA_ENR_POLICY_GROUP PG ON (EP.POLICY_SEQ_ID=PG.POLICY_SEQ_ID)
                   JOIN APP.TPA_ENR_POLICY_MEMBER M ON (PG.POLICY_GROUP_SEQ_ID=M.POLICY_GROUP_SEQ_ID)
                    WHERE EP.POLICY_SEQ_ID = str_tab(2)
                      AND M.CRN_CURNT_SEQ_ID = str_tab(1)
                      AND ((TRUNC(M.DATE_OF_EXIT) <= TRUNC(v_inv_from_dt-EP.mem_cancl_days) AND NVL(M.CRN_TO_BE_GEN_ON_CNCL_YN,'N') = 'Y' AND get_mem_clm_inp_cnt(M.MEMBER_SEQ_ID) = 0) /*OR (NVL(M.CRN_TO_BE_GEN_YN,'N') = 'Y')*/)
                      AND M.DELETED_YN = 'N'
                      AND M.INV_LNKED_SEQ_IDS IS NOT NULL
                      )
                  SELECT MEMBER_SEQ_ID,MEM_CNCL_PREIUM,REFUND_PREIUM,MEM_CNCL_CRN_GEN_YN
                  FROM CLM_DETAILS CD
                 )
          LOOP
            UPDATE app.tpa_enr_policy_member m 
              SET M.CRN_GEN_YN        = CASE WHEN J.REFUND_PREIUM != 0 THEN 'Y' ELSE CRN_GEN_YN END,
                  M.CRN_TO_BE_GEN_YN  = CASE WHEN J.REFUND_PREIUM != 0 THEN NULL ELSE CRN_TO_BE_GEN_YN END,
                  M.CRN_GEN_ON_CNCL_YN = J.MEM_CNCL_CRN_GEN_YN,
                  M.CRN_TO_BE_GEN_ON_CNCL_YN = CASE WHEN J.MEM_CNCL_CRN_GEN_YN = 'Y' THEN NULL ELSE CRN_TO_BE_GEN_ON_CNCL_YN END,
                  M.INV_CRN_AMNT      = CASE WHEN NVL(J.MEM_CNCL_PREIUM,0) != 0 AND J.REFUND_PREIUM = 0 THEN M.INV_CRN_AMNT ELSE M.MEM_TOTAL_PREMIUM END,
                  M.CRN_AMOUNT        = J.REFUND_PREIUM + J.MEM_CNCL_PREIUM,
                  M.CRN_CURNT_SEQ_ID  = NULL,
                  M.CRN_LNKED_SEQ_IDS = CASE WHEN CRN_LNKED_SEQ_IDS IS NULL THEN TO_CHAR(str_tab(1)) ELSE CRN_LNKED_SEQ_IDS||'|'||TO_CHAR(str_tab(1)) END,
                  M.UPDATED_FRM_MODL  = 'Credit Note Generation'
            WHERE m. member_seq_id = j.member_seq_id;
       END LOOP;
   END IF;
  
   
    COMMIT;
  END tpa_commission;
  --===================================================================================================
  PROCEDURE get_bank_advice_save_file_name(v_batch_file_no         IN tpa_bank_advice_batch.batch_file_no%TYPE,
                                           v_bank_advice_file_name OUT VARCHAR2) IS
    CURSOR file_name_cur IS
      SELECT A.bank_advice_file_name
        FROM tpa_bank_advice_batch A
       WHERE A.file_name = v_batch_file_no;
  BEGIN
    OPEN file_name_cur;
    FETCH file_name_cur
      INTO v_bank_advice_file_name;
    CLOSE file_name_cur;

  END get_bank_advice_save_file_name;
  --===================================================================================================

  -- this procedure is used to display list of paid claims records from tpa_claims_payment.
  PROCEDURE select_batch_claims_list(v_float_seq_id        IN TPA_CLAIMS_PAYMENT.float_seq_id%TYPE,
                                     v_from_date           IN VARCHAR2,
                                     v_to_date             IN VARCHAR2,
                                     v_claim_settlement_no IN TPA_CLAIMS_PAYMENT.claim_settlement_no%TYPE,
                                     v_payment_type        IN VARCHAR2, --ADDED FOR KOC1103
                                     v_sort_var            IN VARCHAR2,
                                     v_sort_order          IN VARCHAR2,
                                     v_start_num           IN NUMBER,
                                     v_end_num             IN NUMBER,
                                     v_added_by            IN NUMBER,
                                     result_set            OUT SYS_REFCURSOR) IS
    v_sql_str VARCHAR2(4000);
    --v_start_date           DATE  :=  TO_DATE(v_from_date,'dd/mm/yyyy');
    --v_end_date             DATE  :=  TO_DATE(v_to_date,'dd/mm/yyyy');
    TYPE bind_tab_type IS TABLE OF VARCHAR2(250) INDEX BY BINARY_INTEGER;
    bind_tab         bind_tab_type;
    i                BINARY_INTEGER := 0;
    v_notify_tipe_id varchar2(3) := 'N'; --koc_ins_mail
    v_ins_name       varchar2(100); --koc_ins_mail
  BEGIN

    --koc_ins_mail
    /*IF v_float_seq_id IS NOT NULL THEN
     select DISTINCT ii.ins_comp_name,nvl(ii.notify_type_id,'N') into v_ins_name,v_notify_tipe_id from
     clm_enroll_details ed join clm_general_details gd on(ed.claim_seq_id=gd.claim_seq_id)
     join tpa_claims_payment p on (p.claim_seq_id=gd.claim_seq_id)
     join tpa_ins_info ii on(ii.ins_seq_id=ed.ins_seq_id)
     JOIN TPA_FLOAT_ACCOUNT FA ON (FA.FLOAT_SEQ_ID=P.FLOAT_SEQ_ID)
     where FA.FLOAT_SEQ_ID=v_float_seq_id;
    end if;*/
    --koc_ins_mail
    --dispaly only non logically deleted records
    IF v_payment_type = 'PCA' THEN
      v_sql_str := 'SELECT  A.payment_seq_id,
        A.claim_settlement_no,
        X.tpa_enrollment_id AS tpa_enrollment_id,
        X.mem_name AS mem_name,
        K.description  AS claim_type,
        A.claim_aprv_date,
        ttk_util_pkg.fn_decrypt(a.payee_name) as in_favour_of,
        a.approved_amount,
        o.check_num,
        case when ''' || v_ins_name ||
                   ''' like ''CIGNA%'' AND ''' || v_notify_tipe_id ||
                   '''= ''NIC'' then ''Y'' else ''N'' end as CIGNA_YN,-- koc_ins_mail
        p.tds_process_yn
        FROM tpa_claims_payment A
        JOIN clm_authorization_details X ON ( A.claim_seq_id = X.claim_seq_id )
        LEFT OUTER JOIN tpa_general_code K ON (K.general_type_id = A.claim_type)
        LEFT OUTER JOIN tpa_payment_checks_details N ON(A.payment_seq_id=N.payment_seq_id)
        LEFT OUTER JOIN tpa_claims_check O ON(N.claims_chk_seq_id=O.claims_chk_seq_id)
        LEFT OUTER JOIN tpa_hosp_info p ON (a.hosp_seq_id = p.hosp_seq_id)
        WHERE A.float_seq_id = :v_float_seq_id
        AND A.claim_payment_status =''PAID''
        AND o.check_status = ''CSI''';
    ELSIF v_payment_type = 'EFT' THEN
      --added for koc1103
      v_sql_str := 'SELECT  A.payment_seq_id,
        A.claim_settlement_no,
        X.tpa_enrollment_id AS tpa_enrollment_id,
        X.mem_name AS mem_name,
        K.description  AS claim_type,
        A.claim_aprv_date,
        ttk_util_pkg.fn_decrypt(a.payee_name) as in_favour_of,
        a.approved_amount,
        ''EFT-''||o.check_num check_num,
        case when ''' || v_ins_name ||
                   ''' like ''CIGNA%'' AND ''' || v_notify_tipe_id ||
                   '''= ''NIC'' then ''Y'' else ''N'' end as CIGNA_YN,-- koc_ins_mail
        p.tds_process_yn
        FROM tpa_claims_payment A
        JOIN clm_authorization_details X ON ( A.claim_seq_id = X.claim_seq_id )
        LEFT OUTER JOIN tpa_general_code K ON (K.general_type_id = A.claim_type)
        LEFT OUTER JOIN tpa_payment_checks_details N ON(A.payment_seq_id=N.payment_seq_id)
        LEFT OUTER JOIN tpa_claims_check O ON(N.claims_chk_seq_id=O.claims_chk_seq_id)
        LEFT OUTER JOIN tpa_hosp_info p ON (a.hosp_seq_id = p.hosp_seq_id)
        WHERE A.float_seq_id = :v_float_seq_id
        AND A.claim_payment_status =''PAID''
        AND o.check_status in (''CSI'',''CSC'') and a.payee_type=''EFT'''; --koc1175 change check status CSC TO CSI
    END IF;

    IF v_from_date IS NOT NULL THEN
      v_sql_str := v_sql_str || ' AND O.check_date >= :v_from_date ';
      i := i + 1;
      bind_tab(i) := to_date(v_from_date, 'dd/mm/yyyy');
    END IF;
    IF v_to_date IS NOT NULL THEN
      v_sql_str := v_sql_str || ' AND O.check_date <= :v_to_date';
      i := i + 1;
      bind_tab(i) := to_date(v_to_date, 'dd/mm/yyyy');
    END IF;
    IF v_claim_settlement_no IS NOT NULL THEN
      v_sql_str := v_sql_str ||
                   ' AND A.claim_settlement_no = :v_claim_settlement_no';
      i := i + 1;
      bind_tab(i) := UPPER(v_claim_settlement_no);
    END IF;

    v_sql_str := 'SELECT * FROM
        (SELECT A.*, DENSE_RANK() OVER (ORDER BY ' ||
                 v_sort_var || ' ' || v_sort_order || ', ROWNUM)
        Q FROM (' || v_sql_str ||
                 ') A ) WHERE Q>= :v_start_num AND Q<= :v_end_num ';

    IF bind_tab.FIRST IS NOT NULL THEN
      CASE bind_tab.COUNT
        WHEN 1 THEN
          OPEN result_set FOR v_sql_str
            USING v_float_seq_id, bind_tab(1), v_start_num, v_end_num;
        WHEN 2 THEN
          OPEN result_set FOR v_sql_str
            USING v_float_seq_id, bind_tab(1), bind_tab(2), v_start_num, v_end_num;
        WHEN 3 THEN
          OPEN result_set FOR v_sql_str
            USING v_float_seq_id, bind_tab(1), bind_tab(2), bind_tab(3), v_start_num, v_end_num;
      END CASE;
    ELSE

      OPEN result_set FOR v_sql_str
        USING v_float_seq_id, v_from_date, v_to_date, v_start_num, v_end_num;
    END IF;
  END select_batch_claims_list;
  /*==============================================================================================
     Name       : get_tds_amount
     Created on : 10-JUN-09
     Created By : S.V.Sreeraj
     Company    : SPAN Infotech (India) Pvt. Ltd.
     Comments   : This is to get the approved amount after deduction the TDS.
  ============================================================================================== */
  /*PROCEDURE get_tds_amount(
    v_claim_seq_id       IN tpa_claims_payment.claim_seq_id%TYPE,
    v_hosp_seq_id        IN tpa_claims_payment.hosp_seq_id%TYPE,
    v_approved_amount    IN OUT tpa_claims_payment.approved_amount%TYPE,
    split_amt_tab        IN OUT split_amt_type,
    split_perc_tab       IN OUT split_amt_type,
    v_exist_yn           IN OUT VARCHAR2,
    v_date               IN DATE := trunc(SYSDATE)
  )
  IS

    TYPE attribute_tab_type IS TABLE OF VARCHAR2(3) INDEX BY BINARY_INTEGER;

    attribute_tab          attribute_tab_type;

    CURSOR tds_cursor IS SELECT b.tds_atr_type_id, b.calculation,c.order_no,b.applicable_rate_percent
      FROM TPA_HOSP_INFO a JOIN TDS_CATEGORY_RATE b ON (a.tds_subcat_type_id = b.tds_subcat_type_id)
      JOIN TDS_ATTRIBUTES c ON (b.tds_atr_type_id = c.tds_atr_type_id)
      WHERE a.hosp_seq_id = v_hosp_seq_id AND b.rev_date_from <= v_date
      AND ( b.rev_date_to IS NULL OR b.rev_date_to >= v_date ) --AND A.TDS_PROCESS_YN = 'Y'
      ORDER BY c.order_no;

    CURSOR attribute_cur IS SELECT c.tds_atr_type_id
      FROM TDS_ATTRIBUTES c ORDER BY c.order_no;

    CURSOR det_cur IS SELECT * FROM (SELECT a.approved_amount,a.check_amount
       FROM tpa_clm_tds_details A WHERE A.claim_seq_id = v_claim_seq_id
        ORDER BY a.added_date DESC ) WHERE rownum = 1;

    det_rec         det_cur%ROWTYPE;
    v_str           VARCHAR2(1000);
    v_ctr           PLS_INTEGER;
    v_check_amount  TPA_CLM_TDS_DETAILS.check_amount%TYPE;
  BEGIN
    OPEN det_cur;
    FETCH det_cur INTO det_rec;
    CLOSE det_cur;

    IF det_rec.approved_amount IS NULL OR  det_rec.approved_amount != v_approved_amount  THEN

      v_exist_yn := 'N';

      OPEN attribute_cur;
      FETCH attribute_cur BULK COLLECT INTO attribute_tab;
      CLOSE attribute_cur;

      FOR i IN attribute_tab.FIRST .. attribute_tab.LAST
      LOOP
        split_amt_tab(attribute_tab(i)):= 0;
        split_perc_tab(attribute_tab(i)):= 0;
      END LOOP;

      FOR r IN tds_cursor
      LOOP
        split_perc_tab(r.tds_atr_type_id) := r.applicable_rate_percent;

        v_str := REPLACE(r.calculation,'AMT',v_approved_amount);

        IF r.calculation IS NOT NULL THEN
          FOR i IN 1 .. r.order_no - 1
          LOOP
            v_str := REPLACE(v_str,attribute_tab(i),split_amt_tab(attribute_tab(i)));
          END LOOP;
        END IF;
        EXECUTE IMMEDIATE 'select '||v_str||' from dual' INTO split_amt_tab(r.tds_atr_type_id);
        split_amt_tab(r.tds_atr_type_id) := ROUND(split_amt_tab(r.tds_atr_type_id),0);
        v_approved_amount := v_approved_amount - NVL(split_amt_tab(r.tds_atr_type_id),0);
      END LOOP;
    ELSE
      v_approved_amount := det_rec.check_amount;
      v_exist_yn := 'Y';
    END IF;

  END get_tds_amount;*/

  PROCEDURE get_tds_amount(v_claim_seq_id    IN tpa_claims_payment.claim_seq_id%TYPE,
                           v_hosp_seq_id     IN tpa_claims_payment.hosp_seq_id%TYPE,
                           v_approved_amount IN OUT tpa_claims_payment.approved_amount%TYPE,
                           split_amt_tab     IN OUT split_amt_type,
                           split_perc_tab    IN OUT split_amt_type,
                           v_exist_yn        IN OUT VARCHAR2,
                           v_date            IN DATE := trunc(SYSDATE)) IS

    TYPE attribute_tab_type IS TABLE OF VARCHAR2(3) INDEX BY BINARY_INTEGER;

    attribute_tab attribute_tab_type;

    CURSOR tds_cursor IS
      SELECT b.tds_atr_type_id, c.order_no, b.applicable_rate_percent
        FROM TPA_HOSP_INFO a
        JOIN TDS_CATEGORY_RATE b
          ON (a.tds_subcat_type_id = b.tds_subcat_type_id)
        JOIN TDS_ATTRIBUTES c
          ON (b.tds_atr_type_id = c.tds_atr_type_id)
       WHERE a.hosp_seq_id = v_hosp_seq_id
         AND b.rev_date_from <= v_date
         AND (b.rev_date_to IS NULL OR b.rev_date_to >= v_date)
       ORDER BY c.order_no;
    ---opdforhs
    CURSOR policy_cur IS
      SELECT ep.hcu_pay_to_general_type,
             ep.tpa_name,
             gd.claim_sub_general_type_id
        FROM tpa_enr_policy ep
        JOIN clm_enroll_details ed
          on (ep.policy_seq_id = ed.policy_seq_id)
        JOIN clm_general_details gd
          ON (gd.claim_seq_id = ed.claim_seq_id)
       WHERE gd.claim_seq_id = v_claim_seq_id;

    policy_rec policy_cur%rowtype;

    CURSOR hcu_tds_cursor IS
      SELECT b.tds_atr_type_id, c.order_no, b.applicable_rate_percent
        FROM TDS_HOSP_SUB_CATEGORY a
        JOIN TDS_CATEGORY_RATE b
          ON (a.tds_subcat_type_id = b.tds_subcat_type_id)
        JOIN TDS_ATTRIBUTES c
          ON (b.tds_atr_type_id = c.tds_atr_type_id)
       WHERE a.tds_subcat_name = 'HEALTHCHECKUP'
         AND b.rev_date_from <= v_date
         AND (b.rev_date_to IS NULL OR b.rev_date_to >= v_date)
       ORDER BY c.order_no;

    ---opdforhs
    CURSOR attribute_cur IS
      SELECT c.tds_atr_type_id FROM TDS_ATTRIBUTES c ORDER BY c.order_no;

    CURSOR det_cur IS
      SELECT *
        FROM (SELECT A.tpa_clm_tds_detail_seq_id,
                     a.approved_amount,
                     a.check_amount
                FROM tpa_clm_tds_details A
               WHERE A.claim_seq_id = v_claim_seq_id
               ORDER BY a.added_date DESC)
       WHERE rownum = 1;

    det_rec        det_cur%ROWTYPE;
    v_str          VARCHAR2(1000);
    v_ctr          PLS_INTEGER;
    v_check_amount TPA_CLM_TDS_DETAILS.check_amount%TYPE := v_approved_amount;
  BEGIN
    OPEN det_cur;
    FETCH det_cur
      INTO det_rec;
    CLOSE det_cur;

    OPEN policy_cur;
    FETCH policy_cur
      INTO policy_rec;
    CLOSE policy_cur;

    IF det_rec.approved_amount IS NULL OR
       det_rec.approved_amount != v_approved_amount THEN
      IF det_rec.approved_amount IS NOT NULL THEN
        UPDATE tpa_clm_tds_details A
           SET A.updated_yn = 'D'
         WHERE A.claim_seq_id = v_claim_seq_id;
      END IF;
      v_exist_yn := 'N';

      OPEN attribute_cur;
      FETCH attribute_cur BULK COLLECT
        INTO attribute_tab;
      CLOSE attribute_cur;

      FOR i IN attribute_tab.FIRST .. attribute_tab.LAST LOOP
        split_amt_tab(attribute_tab(i)) := 0;
        split_perc_tab(attribute_tab(i)) := 0;
      END LOOP;
      --opdforhs
      IF policy_rec.claim_sub_general_type_id = 'HCU' AND
         policy_rec.hcu_pay_to_general_type = 'TPA' THEN
        FOR r IN hcu_tds_cursor LOOP
          split_perc_tab(r.tds_atr_type_id) := r.applicable_rate_percent;

          IF r.applicable_rate_percent > 0 THEN
            split_amt_tab(r.tds_atr_type_id) := ROUND(v_approved_amount *
                                                      r.applicable_rate_percent / 100,
                                                      0);
          END IF;

          v_check_amount := v_check_amount -
                            NVL(split_amt_tab(r.tds_atr_type_id), 0);
        END LOOP;
      ELSE
        --opdforhs

        FOR r IN tds_cursor LOOP
          split_perc_tab(r.tds_atr_type_id) := r.applicable_rate_percent;

          IF r.applicable_rate_percent > 0 THEN
            split_amt_tab(r.tds_atr_type_id) := ROUND(v_approved_amount *
                                                      r.applicable_rate_percent / 100,
                                                      0);
          END IF;

          v_check_amount := v_check_amount -
                            NVL(split_amt_tab(r.tds_atr_type_id), 0);
        END LOOP;
      END IF; --opdforhs
    ELSE
      v_check_amount := det_rec.check_amount;
      v_exist_yn     := 'Y';
    END IF;
    v_approved_amount := v_check_amount;

  END get_tds_amount;
  /*==============================================================================================
     Name       : SAVE_CLM_TDS_DETAILS
     Created on : 10-JUN-09
     Created By : S.V.Sreeraj
     Company    : SPAN Infotech (India) Pvt. Ltd.
     Comments   :
  ============================================================================================== */
  PROCEDURE save_clm_tds_details(v_payment_seq_id  IN TPA_CLM_TDS_DETAILS.payment_seq_id%TYPE,
                                 v_claim_seq_id    IN TPA_CLM_TDS_DETAILS.claim_seq_id%TYPE,
                                 v_approved_amount IN TPA_CLM_TDS_DETAILS.approved_amount%TYPE,
                                 v_check_amount    IN TPA_CLM_TDS_DETAILS.check_amount%TYPE,
                                 split_amt_tab     IN split_amt_type,
                                 split_perc_tab    IN split_amt_type,
                                 v_payment_type    IN TPA_CLM_TDS_DETAILS.payment_type%TYPE, --  'C'means check, 'P' -- Payment advice
                                 v_added_by        IN TPA_CLM_TDS_DETAILS.added_by%TYPE) IS
  BEGIN
    INSERT INTO tpa_clm_tds_details
      (tpa_clm_tds_detail_seq_id,
       payment_seq_id,
       claim_seq_id,
       approved_amount,
       check_amount,
       bat_perc,
       bat_amt,
       edc_perc,
       edc_amt,
       sur_perc,
       sur_amt,
       ms1_perc,
       ms1_amt,
       ms2_perc,
       ms2_amt,
       payment_type,
       updated_yn,
       added_date,
       added_by)
    VALUES
      (tpa_clm_tds_detail_seq.nextval,
       v_payment_seq_id,
       v_claim_seq_id,
       v_approved_amount,
       v_check_amount,
       split_perc_tab('BAT'),
       split_amt_tab('BAT'),
       split_perc_tab('EDC'),
       split_amt_tab('EDC'),
       split_perc_tab('SUR'),
       split_amt_tab('SUR'),
       split_perc_tab('MS1'),
       split_amt_tab('MS1'),
       split_perc_tab('MS2'),
       split_amt_tab('MS2'),
       v_payment_type,
       'N',
       SYSDATE,
       v_added_by);

  END save_clm_tds_details;
  /*==============================================================================================
     Name       : SAVE_REPORT_MASTER
     Created on : 10-aug-09
     Created By : S.V.Sreeraj
     Company    : SPAN Infotech (India) Pvt. Ltd.
     Comments   : For inserting records to the flat table used for report purpose, through schedular
  ============================================================================================== */

  PROCEDURE save_report_master(v_start_date IN DATE, v_end_date IN DATE) IS
  BEGIN
    UPDATE TPA_CLM_TDS_DETAILS a
       SET a.updated_yn = 'I'
     WHERE a.added_date BETWEEN v_start_date AND v_end_date
       AND a.updated_yn IN ('N', 'D');

    INSERT INTO tpa_tds_report_master
      (tds_report_master_seq_id,
       application,
       generated_date,
       ins_comp_id,
       ins_comp_name,
       ins_comp_location,
       hosp_code,
       tpa_enrollment_id,
       ttk_branch,
       claim_number,
       claim_settlement_number,
       payee_name,
       insured_name,
       claimant_name,
       policy_number,
       cheque_issued_by,
       mode_of_payment,
       corporate_name,
       ind_or_group,
       claim_app_amt,
       tds_category,
       base_tax_perc,
       surcharge_perc,
       edu_cess_perc,
       ms1_perc,
       ms2_perc,
       base_tax,
       surcharge,
       edu_cess,
       tds_amt,
       cheque_amt,
       cheque_number,
       cheque_date,
       cheque_status,
       bank_transfer_date,
       bank_transfer_acct_number,
       float_acct_number,
       float_account_name,
       bank_acct_number,
       bank_name,
       tax_deduction_acct_no,
       added_date,
       added_by)
      SELECT tds_report_master_seq.Nextval, aa.*
        FROM (SELECT 'V2' application,
                     trunc(d.added_date) AS generated_date,
                     e.abbrevation_code,
                     e.ins_comp_name,
                     s.city_description,
                     g.empanel_number,
                     j.tpa_enrollment_id,
                     l.office_name,
                     m.claim_number,
                     a.claim_settlement_no,
                     ttk_util_pkg.fn_decrypt(a.payee_name),
                     j.employee_name,
                     j.claimant_name,
                     j.policy_number,
                     t.description, /*(cheque_issued_by)*/
                     CASE
                       WHEN d.payment_type = 'C' THEN
                        'Cheque'
                       ELSE
                        'Payment Advice'
                     END AS mode_of_payment,
                     u.group_name,
                     CASE
                       WHEN a.group_reg_seq_id IS NULL THEN
                        'Individual'
                       Else
                        'Group'
                     END AS ind_or_group,
                     a.approved_amount AS claim_app_amt,
                     v.tds_subcat_name,
                     d.bat_perc,
                     d.sur_perc,
                     d.edc_perc,
                     d.ms1_perc,
                     d.ms2_perc,
                     d.bat_amt,
                     d.sur_amt,
                     d.edc_amt,
                     (d.approved_amount - d.check_amount) AS tds_amt,
                     d.check_amount,
                     o.check_num,
                     o.check_date,
                     o.check_status,
                     NULL bank_transfer_date,
                     NULL bank_transfer_acct_number,
                     p.float_account_number,
                     p.float_account_name,
                     c.account_number,
                     q.bank_name,
                     l.tax_deduction_acct_no,
                     SYSDATE added_date,
                     d.added_by
                FROM TPA_CLAIMS_PAYMENT A
                JOIN TPA_FLOAT_ACCOUNT B
                  ON (a.float_seq_id = b.float_seq_id)
                JOIN TPA_BANK_ACCOUNTS c
                  ON (b.bank_acc_seq_id = c.bank_acc_seq_id)
                JOIN TPA_CLM_TDS_DETAILS d
                  ON (a.payment_seq_id = d.payment_seq_id)
                JOIN TPA_INS_INFO e
                  ON (a.ins_seq_id = e.ins_seq_id)
                JOIN TPA_HOSP_INFO g
                  ON (a.hosp_seq_id = g.hosp_seq_id)
                JOIN TPA_HOSP_ADDRESS h
                  ON (g.hosp_seq_id = h.hosp_seq_id)
                JOIN TPA_CITY_CODE i
                  ON (h.city_type_id = i.city_type_id)
                JOIN CLM_ENROLL_DETAILS J
                  ON (a.claim_seq_id = j.claim_seq_id)
                JOIN TPA_ENR_POLICY k
                  ON (j.policy_seq_id = k.policy_seq_id)
                JOIN TPA_OFFICE_INFO l
                  ON (k.tpa_office_seq_id = l.tpa_office_seq_id)
                JOIN CLM_GENERAL_DETAILS m
                  ON (a.claim_seq_id = m.claim_seq_id)
                LEFT OUTER JOIN TPA_PAYMENT_CHECKS_DETAILS n
                  ON (a.payment_seq_id = n.payment_seq_id)
                LEFT OUTER JOIN TPA_CLAIMS_CHECK o
                  ON (n.claims_chk_seq_id = o.claims_chk_seq_id AND
                     o.check_status = 'CSI')
                LEFT OUTER JOIN TPA_FLOAT_ACCOUNT p
                  ON (a.float_seq_id = p.float_seq_id)
                JOIN TPA_BANK_MASTER q
                  ON (c.bank_seq_id = q.bank_seq_id)
                LEFT OUTER JOIN TPA_ADDRESS R
                  ON (E.ins_seq_id = R.ins_seq_id)
                LEFT OUTER JOIN TPA_CITY_CODE s
                  ON (r.city_type_id = s.city_type_id)
                LEFT OUTER JOIN tpa_general_code t
                  ON (a.tpa_cheque_issued_general_type = t.general_type_id)
                LEFT OUTER JOIN tpa_group_registration u
                  ON (a.group_reg_seq_id = u.group_reg_seq_id)
                LEFT OUTER JOIN tds_hosp_sub_category v
                  ON (g.tds_subcat_type_id = v.tds_subcat_type_id)
               WHERE d.added_date BETWEEN v_start_date AND v_end_date
                 AND d.updated_yn = 'I'
                 AND (a.claim_payment_status = 'PAID' AND
                     o.check_status = 'CSI' OR
                     a.claim_payment_status = 'SENT_TO_BANK' AND
                     o.check_status IS NULL)) aa;

    UPDATE TPA_CLM_TDS_DETAILS a
       SET a.updated_yn = 'Y'
     WHERE a.added_date BETWEEN v_start_date AND v_end_date
       AND a.updated_yn = 'I';
    COMMIT;
  END save_report_master;
  /*==============================================================================================
     Name       : save_tpa_float_group_assoc
     Created on : 29-SEP-09
     Created By : S.V.Sreeraj
     Company    : SPAN Infotech (India) Pvt. Ltd.
     Comments   : save groups float account association
  ============================================================================================== */
  PROCEDURE save_tpa_float_group_assoc(v_float_seq_id     IN tpa_float_group_assoc.float_seq_id%TYPE,
                                       v_group_reg_seq_id IN tpa_float_group_assoc.group_reg_seq_id%TYPE,
                                       v_policy_number    IN tpa_float_group_assoc.policy_number%TYPE, --added by chiranjibi
                                       v_added_by         IN tpa_float_group_assoc.added_by%TYPE,
                                       v_rows_processed   IN OUT NUMBER) IS
    v_ctr PLS_INTEGER;

    CURSOR float_cur IS
      SELECT a.ins_seq_id, a.float_status, a.float_type
        FROM tpa_float_account a
       WHERE a.float_seq_id = v_float_seq_id;

    float_rec float_cur%ROWTYPE;

    CURSOR group_reg_cur IS
      SELECT COUNT(1)
        FROM tpa_float_group_assoc a
        JOIN tpa_float_account b
          ON (a.float_seq_id = b.float_seq_id)
       WHERE b.ins_seq_id = float_rec.ins_seq_id
         AND a.group_reg_seq_id = v_group_reg_seq_id
         AND b.float_type = float_rec.float_type
         AND b.float_status = 'ASA'
         AND a.float_seq_id = v_float_seq_id;

  BEGIN
    OPEN float_cur;
    FETCH float_cur
      INTO float_rec;
    CLOSE float_cur;

    OPEN group_reg_cur;
    FETCH group_reg_cur
      INTO v_ctr;
    CLOSE group_reg_cur;

    IF v_ctr > 0 THEN
      raise_application_error(-20763,
                              'Group is already associated to an active float account.');
    END IF;

    INSERT INTO tpa_float_group_assoc
      (tpa_float_group_assoc_seq,
       float_seq_id,
       group_reg_seq_id,
       policy_number,
       added_date,
       added_by)
    VALUES
      (tpa_float_group_assoc_seq.nextval,
       v_float_seq_id,
       v_group_reg_seq_id,
       v_policy_number,
       SYSDATE,
       v_added_by);

    v_rows_processed := SQL%ROWCOUNT;
    COMMIT;
  END save_tpa_float_group_assoc;
  /*==============================================================================================
     Name       : delete_tpa_float_group_assoc
     Created on : 29-SEP-09
     Created By : S.V.Sreeraj
     Company    : SPAN Infotech (India) Pvt. Ltd.
     Comments   : deletion of associated groups
  ============================================================================================== */
  PROCEDURE delete_tpa_float_group_assoc(v_tpa_float_group_assoc_seq IN tpa_float_group_assoc.tpa_float_group_assoc_seq%TYPE,
                                         v_rows_processed            OUT NUMBER) IS
    CURSOR float_cur IS
      SELECT COUNT(1)
        FROM tpa_claims_payment a
        JOIN tpa_float_group_assoc b
          ON (a.float_seq_id = b.float_seq_id)
       WHERE b.tpa_float_group_assoc_seq = v_tpa_float_group_assoc_seq
         AND a.claim_payment_status = 'PENDING';

    v_ctr PLS_INTEGER;
  BEGIN
    SELECT COUNT(1)
      INTO v_ctr
      FROM tpa_float_transaction A
      JOIN tpa_float_group_assoc b
        ON (a.float_seq_id = b.float_seq_id)
     WHERE b.tpa_float_group_assoc_seq = v_tpa_float_group_assoc_seq;

    IF v_ctr = 0 THEN
      OPEN float_cur;
      FETCH float_cur
        INTO v_ctr;
      CLOSE float_cur;
    END IF;

    IF v_ctr > 0 THEN
      raise_application_error(-20764,
                              'Active transactions exist for this group.');
    ELSE
      DELETE FROM tpa_float_group_assoc a
       WHERE a.tpa_float_group_assoc_seq = v_tpa_float_group_assoc_seq;
      v_rows_processed := SQL%ROWCOUNT;
      COMMIT;
    END IF;

  END delete_tpa_float_group_assoc;

  /*==============================================================================================
     Name       : select_float_group_assoc
     Created on : 29-SEP-09
     Created By : S.V.Sreeraj
     Company    : SPAN Infotech (India) Pvt. Ltd.
     Comments   : display float account group association
  ============================================================================================== */
  PROCEDURE select_float_group_assoc(v_float_seq_id IN tpa_float_account.float_seq_id%TYPE,
                                     v_result_set   OUT SYS_REFCURSOR) IS

  BEGIN
    OPEN v_result_set FOR
      SELECT a.tpa_float_group_assoc_seq,
             b.group_id,
             b.group_name,
             a.policy_number as policy_no
        FROM tpa_float_group_assoc a
        JOIN tpa_group_registration b
          ON (a.group_reg_seq_id = b.group_reg_seq_id)
       WHERE a.float_seq_id = v_float_seq_id
       ORDER BY b.group_id;

  END select_float_group_assoc;

  --===========================================================================================
  FUNCTION get_date_of_inception(v_tpa_enrollment_id IN tpa_enr_policy_member.tpa_enrollment_id%TYPE,
                                 v_policy_seq_id     IN tpa_enr_policy.policy_seq_id%TYPE,
                                 v_ins_seq_id        IN tpa_enr_policy.ins_seq_id%TYPE)
    RETURN VARCHAR2 DETERMINISTIC IS
    v_date_of_inception   DATE;
    v_ctr                 NUMBER;
    v_effective_from_date DATE;

    CURSOR inception_cur IS
      SELECT MIN(date_of_inception), MIN(effective_from_date), MAX(ctr)
        FROM (SELECT a.member_seq_id,
                     b.policy_group_seq_id,
                     a.date_of_inception,
                     c.policy_seq_id,
                     c.effective_from_date,
                     c.prev_policy_seq_id,
                     COUNT(1) over(PARTITION BY 1) AS ctr
                FROM tpa_enr_policy_member A
                JOIN tpa_enr_policy_group b
                  ON (a.policy_group_seq_id = b.policy_group_seq_id)
                JOIN tpa_enr_policy c
                  ON (b.policy_seq_id = c.policy_seq_id)
               WHERE a.tpa_enrollment_id = v_tpa_enrollment_id
                 AND c.ins_head_office_seq_id = v_ins_seq_id
                 AND a.deleted_yn = 'N'
                 AND b.deleted_yn = 'N');
  BEGIN
    OPEN inception_cur;
    FETCH inception_cur
      INTO v_date_of_inception, v_effective_from_date, v_ctr;
    CLOSE inception_cur;

    IF nvl(v_ctr, 0) <= 1 THEN
      RETURN NULL;
    ELSE
      RETURN CASE WHEN v_date_of_inception < v_effective_from_date THEN to_char(v_effective_from_date,
                                                                                'dd/mm/yyyy') ELSE to_char(v_date_of_inception,
                                                                                                           'dd/mm/yyyy') END;
    END IF;
  END get_date_of_inception;
  --===========================================================================================
  PROCEDURE generate_oi_payment_advice(v_payment_seq_id IN VARCHAR2,
                                       v_float_seq_id   IN tpa_float_account.float_seq_id%TYPE,
                                       v_bank_type      IN VARCHAR2, -- '0' for CITI, '1' for UTI and '2' for ICICI bank
                                       v_batch_date     IN DATE,
                                       v_added_by       IN NUMBER,
                                       v_rows_processed OUT INTEGER,
                                       v_resultset      OUT SYS_REFCURSOR) IS
    v_filename                   VARCHAR2(50);
    v_bank_seq_id                tpa_bank_master.bank_seq_id%TYPE;
    v_count_of_payments          tpa_claims_payment.payment_seq_id%TYPE;
    v_batch_seq_id               tpa_bank_advice_batch.batch_seq_id%TYPE;
    v_bank_advice_file_name      tpa_bank_advice_batch.bank_advice_file_name%TYPE;
    str_tab                      ttk_util_pkg.str_table_type;
    v_where                      VARCHAR2(2000);
    v_sql_str                    VARCHAR2(30000);
    i                            NUMBER(2) := 0;
    v_tds_str                    VARCHAR2(2000);
    v_claim_seq_id               tpa_claims_payment.claim_seq_id%TYPE;
    v_hosp_seq_id                tpa_claims_payment.hosp_seq_id%TYPE;
    v_cheque_amount              tpa_claims_payment.approved_amount%TYPE;
    v_appr_amount                tpa_claims_payment.approved_amount%TYPE;
    v_tds_payment_seq_id         tpa_claims_payment.payment_seq_id%TYPE;
    split_amt_tab                Float_Accounts_Pkg.split_amt_type;
    split_perc_tab               Float_Accounts_Pkg.split_amt_type;
    v_exist_yn                   VARCHAR2(1) := 'N';
    v_tpa_nhcp_cheques_issued_to tpa_claims_payment.tpa_nhcp_cheques_issued_to%TYPE;

    CURSOR tpa_bank_details IS
      SELECT ad.bank_name,
             ad.account_number,
             ad.branch_name,
             ad.bank_micr,
             ad.bank_ifsc,
             ad.account_type
        FROM fin_app.tpa_account_details ad;
    tpa_rec tpa_bank_details%rowtype; --balley

  BEGIN
    OPEN tpa_bank_details;
    FETCH tpa_bank_details
      INTO tpa_rec;
    CLOSE tpa_bank_details;

    str_tab := ttk_util_pkg.parse_str(v_payment_seq_id);

    SELECT A.bank_seq_id
      INTO v_bank_seq_id
      FROM tpa_bank_accounts a
      JOIN tpa_float_account b
        ON (a.bank_acc_seq_id = b.bank_acc_seq_id)
     WHERE b.float_seq_id = v_float_seq_id;

    IF (str_tab.FIRST IS NOT NULL) THEN
      IF str_tab.COUNT <= 8 THEN
        FOR i in str_tab.FIRST .. str_tab.LAST LOOP
          v_where := v_where || ' OR D.payment_seq_id = :bind_tab_' || i;
        END LOOP;
      ELSE
        v_where := ' OR D.payment_seq_id IN ( ' ||
                   REPLACE(SUBSTR(v_payment_seq_id,
                                  2,
                                  LENGTH(v_payment_seq_id) - 2),
                           '|',
                           ',') || ') ';
      END IF;
    END IF;

    IF v_where IS NOT NULL THEN
      v_where := ' AND (' || substr(v_where, 4) || ')';
    END IF;

    IF v_bank_type = '1' THEN
      INSERT INTO tpa_bank_advice_batch
        (batch_seq_id,
         batch_date,
         batch_file_no,
         bank_seq_id,
         float_seq_id,
         added_by,
         added_date,
         bank_advice_file_name)
      VALUES
        (bank_advice_batch_seq.NEXTVAL,
         v_batch_date,
         'FILE_NO' || bank_advice_batch_file_seq.NEXTVAL,
         v_bank_seq_id,
         v_float_seq_id,
         v_added_by,
         SYSDATE,
         'VHTPA' || '_' || TO_CHAR(v_batch_date, 'YYYYMMDD') || '_' ||
         bank_adv_batch_file_name_slno.NEXTVAL)
      RETURNING batch_seq_id, bank_advice_file_name INTO v_batch_seq_id, v_bank_advice_file_name;
    ELSIF v_bank_type = '4' THEN
      INSERT INTO tpa_bank_advice_batch
        (batch_seq_id,
         batch_date,
         batch_file_no,
         bank_seq_id,
         float_seq_id,
         added_by,
         added_date,
         bank_advice_file_name)
      VALUES
        (bank_advice_batch_seq.NEXTVAL,
         v_batch_date,
         'FILE_NO' || bank_advice_batch_file_seq.NEXTVAL,
         v_bank_seq_id,
         v_float_seq_id,
         v_added_by,
         SYSDATE,
         'VHTPA' || '_' || TO_CHAR(v_batch_date, 'YYYYMMDD') || '_' ||
         bank_adv_batch_file_name_slno.NEXTVAL)
      RETURNING batch_seq_id, bank_advice_file_name INTO v_batch_seq_id, v_bank_advice_file_name;
    ELSE
      INSERT INTO tpa_bank_advice_batch
        (batch_seq_id,
         batch_date,
         batch_file_no,
         bank_seq_id,
         float_seq_id,
         added_by,
         added_date)
      VALUES
        (bank_advice_batch_seq.NEXTVAL,
         v_batch_date,
         'FILE_NO' || bank_advice_batch_file_seq.NEXTVAL,
         v_bank_seq_id,
         v_float_seq_id,
         v_added_by,
         SYSDATE)
      RETURNING batch_seq_id INTO v_batch_seq_id;
    END IF;
    --if bank_type is CITIBANK

    v_tds_str := ' SELECT a.payment_seq_id ,a.claim_seq_id ,a.hosp_seq_id, a.approved_amount, A.tpa_nhcp_cheques_issued_to
      FROM tpa_claims_payment a  WHERE a.float_seq_id = :v_float_seq_id ' ||
                 regexp_replace(v_where, 'D\.', 'A.') ||
                 ' AND a.claim_payment_status  = ''READY_TO_BANK''';

    IF str_tab.FIRST IS NOT NULL THEN
      IF str_tab.COUNT <= 8 THEN
        CASE str_tab.COUNT
          WHEN 1 THEN
            OPEN v_resultset FOR v_tds_str
              USING v_float_seq_id, str_tab(1);
          WHEN 2 THEN
            OPEN v_resultset FOR v_tds_str
              USING v_float_seq_id, str_tab(1), str_tab(2);
          WHEN 3 THEN
            OPEN v_resultset FOR v_tds_str
              USING v_float_seq_id, str_tab(1), str_tab(2), str_tab(3);
          WHEN 4 THEN
            OPEN v_resultset FOR v_tds_str
              USING v_float_seq_id, str_tab(1), str_tab(2), str_tab(3), str_tab(4);
          WHEN 5 THEN
            OPEN v_resultset FOR v_tds_str
              USING v_float_seq_id, str_tab(1), str_tab(2), str_tab(3), str_tab(4), str_tab(5);
          WHEN 6 THEN
            OPEN v_resultset FOR v_tds_str
              USING v_float_seq_id, str_tab(1), str_tab(2), str_tab(3), str_tab(4), str_tab(5), str_tab(6);
          WHEN 7 THEN
            OPEN v_resultset FOR v_tds_str
              USING v_float_seq_id, str_tab(1), str_tab(2), str_tab(3), str_tab(4), str_tab(5), str_tab(6), str_tab(7);
          WHEN 8 THEN
            OPEN v_resultset FOR v_tds_str
              USING v_float_seq_id, str_tab(1), str_tab(2), str_tab(3), str_tab(4), str_tab(5), str_tab(6), str_tab(7), str_tab(8);
        END CASE;
      ELSE
        OPEN v_resultset FOR v_tds_str
          USING v_float_seq_id;
      END IF;
    END IF;
    LOOP
      FETCH v_resultset
        INTO v_tds_payment_seq_id,
             v_claim_seq_id,
             v_hosp_seq_id,
             v_appr_amount,
             v_tpa_nhcp_cheques_issued_to;
      EXIT WHEN v_resultset%NOTFOUND OR v_resultset%NOTFOUND IS NULL;
      IF v_hosp_seq_id IS NOT NULL AND
         v_tpa_nhcp_cheques_issued_to IN ('HOS', 'MAN') THEN
        v_cheque_amount := v_appr_amount;

        Float_Accounts_Pkg.get_tds_amount(v_claim_seq_id,
                                          v_hosp_seq_id,
                                          v_cheque_amount,
                                          split_amt_tab,
                                          split_perc_tab,
                                          v_exist_yn);
        IF v_exist_yn = 'N' THEN
          Float_Accounts_Pkg.save_clm_tds_details(v_tds_payment_seq_id,
                                                  v_claim_seq_id,
                                                  v_appr_amount,
                                                  v_cheque_amount,
                                                  split_amt_tab,
                                                  split_perc_tab,
                                                  'P',
                                                  v_added_by);
        END IF;
        --opdforhs
      ELSIF v_hosp_seq_id IS NULL AND v_tpa_nhcp_cheques_issued_to = 'TPA' THEN
        v_cheque_amount := v_appr_amount;

        get_tds_amount(v_claim_seq_id,
                       v_hosp_seq_id,
                       v_cheque_amount,
                       split_amt_tab,
                       split_perc_tab,
                       v_exist_yn);
        IF v_exist_yn = 'N' THEN
          save_clm_tds_details(v_tds_payment_seq_id,
                               v_claim_seq_id,
                               v_appr_amount,
                               v_cheque_amount,
                               split_amt_tab,
                               split_perc_tab,
                               'P',
                               v_added_by);
        END IF;
        --opdforhs
      END IF;
    END LOOP;
    CLOSE v_resultset;

    v_filename := CASE
                    WHEN v_bank_type = '0' THEN
                     'CITI-'
                    WHEN v_bank_type = '1' THEN
                     'UTI-'
                    WHEN v_bank_type = '2' THEN
                     'ICICI-'
                    WHEN v_bank_type = '3' THEN
                     'HDFC-'
                  END || TO_CHAR(v_batch_date, 'DDMMYYYY-HH24MISS') || '-' ||
                  v_added_by;

    v_sql_str := 'WITH bill_tab AS (
          SELECT a.claim_seq_id, C.requested_amount,C.allowed_amount,C.number_of_days,
          c.ward_type_id , b.bill_date,trunc(a.date_of_admission) AS date_of_admission,
          trunc(a.date_of_discharge) AS date_of_discharge,
          d.payment_seq_id,d.float_seq_id ,b.clm_bill_seq_id
          FROM clm_general_details a JOIN clm_bill_header B ON (a.claim_seq_id = b.claim_seq_id )
          JOIN clm_bill_details C ON (B.clm_bill_seq_id = C.clm_bill_seq_id)
          JOIN tpa_claims_payment D ON (B.claim_seq_id = D.claim_seq_id)
          WHERE D.float_seq_id = :v_float_seq_id ' ||
                 v_where || '
          and claim_payment_status  = ''READY_TO_BANK''),
      ward_tab AS (
        SELECT claim_seq_id,payment_seq_id,
         SUM (CASE WHEN  c.ward_type_id IN (''ROO'') THEN requested_amount ELSE 0 END) AS room_requested_amt,
         SUM (CASE WHEN  c.ward_type_id IN (''ROO'') THEN allowed_amount ELSE 0 END) AS room_allowed_amt,
         SUM (CASE WHEN  c.ward_type_id IN (''ROO'') THEN number_of_days ELSE 0 END) AS room_number_of_days,
         SUM (CASE WHEN  c.ward_type_id IN (''ICU'',''ICR'') THEN requested_amount ELSE 0 END) AS icu_requested_amt,
         SUM (CASE WHEN  c.ward_type_id IN (''ICU'',''ICR'') THEN allowed_amount ELSE 0 END) AS icu_allowed_amt,
         SUM (CASE WHEN  c.ward_type_id IN (''ICU'',''ICR'') THEN number_of_days ELSE 0 END) AS icu_number_of_days,
         SUM (CASE WHEN  c.ward_type_id IN (''REF'') THEN requested_amount ELSE 0 END) AS reg_requested_amt,
         SUM (CASE WHEN  c.ward_type_id IN (''REF'') THEN allowed_amount ELSE 0 END) AS reg_allowed_amt,
         SUM (CASE WHEN  c.ward_type_id IN (''LAI'') THEN requested_amount ELSE 0 END) AS lab_requested_amt,
         SUM (CASE WHEN  c.ward_type_id IN (''LAI'') THEN allowed_amount ELSE 0 END) AS lab_allowed_amt,
         SUM (CASE WHEN  c.ward_type_id IN (''FDC'') THEN requested_amount ELSE 0 END) AS food_requested_amt,
         SUM (CASE WHEN  c.ward_type_id IN (''FDC'') THEN allowed_amount ELSE 0 END) AS food_allowed_amt,
         SUM (CASE WHEN  c.ward_type_id IN (''OTC'',''OCM'',''OTM'') THEN requested_amount ELSE 0 END) AS ot_requested_amt,
         SUM (CASE WHEN  c.ward_type_id IN (''OTC'',''OCM'',''OTM'') THEN allowed_amount ELSE 0 END) AS ot_allowed_amt,
         SUM (CASE WHEN  c.ward_type_id IN (''MED'',''PHA'') THEN requested_amount ELSE 0 END) AS med_requested_amt,
         SUM (CASE WHEN  c.ward_type_id IN (''MED'',''PHA'') THEN allowed_amount ELSE 0 END) AS med_allowed_amt,
         SUM (CASE WHEN  c.ward_type_id IN (''NUC'',''ICN'') THEN requested_amount ELSE 0 END) AS nursing_requested_amt,
         SUM (CASE WHEN  c.ward_type_id IN (''NUC'',''ICN'') THEN allowed_amount ELSE 0 END) AS nursing_allowed_amt,
         SUM (CASE WHEN  c.ward_type_id IN (''CON'',''HVC'') THEN requested_amount ELSE 0 END) AS doctor_fee_requested_amt,
         SUM (CASE WHEN  c.ward_type_id IN (''CON'',''HVC'') THEN allowed_amount ELSE 0 END) AS doctor_fee_allowed_amt,
         MIN(CASE WHEN c.bill_date < c.date_of_admission THEN c.bill_date ELSE NULL END) pre_hosp_from,
         MAX(CASE WHEN c.bill_date < c.date_of_admission THEN c.bill_date ELSE NULL END) pre_hosp_to,
         MIN(CASE WHEN c.bill_date > c.date_of_discharge THEN c.bill_date ELSE NULL END) post_hosp_from,
         MAX(CASE WHEN c.bill_date > c.date_of_discharge THEN c.bill_date ELSE NULL END) post_hosp_to,
         SUM(CASE WHEN c.bill_date < c.date_of_admission THEN c.requested_amount ELSE 0 END) pre_hosp_requested,
         SUM(CASE WHEN c.bill_date < c.date_of_admission THEN c.allowed_amount ELSE 0 END) pre_hosp_allowed,
         SUM(CASE WHEN c.bill_date > c.date_of_discharge THEN c.requested_amount ELSE 0 END) post_hosp_requested,
         SUM(CASE WHEN c.bill_date > c.date_of_discharge THEN c.allowed_amount ELSE 0 END) post_hosp_allowed
         FROM  bill_tab c GROUP BY payment_seq_id,claim_seq_id ),

      icd_tab AS
        (SELECT d.claim_seq_id,d.payment_seq_id, rtrim (xmlagg (xmlelement (e, e.icd_code || '','')).extract (''//text()''), '','') icd_codes
          FROM tpa_claims_payment d JOIN icd_pcs_detail e ON (d.claim_seq_id = e.claim_seq_id)
          WHERE d.float_seq_id = :v_float_seq_id ' ||
                 v_where || '
            and claim_payment_status  = ''READY_TO_BANK'' GROUP BY d.payment_seq_id,d.claim_seq_id )

      SELECT * from (
       SELECT dense_rank() over (partition by a.claim_seq_id order by l.ailment_details_seq_id,rownum desc) as AQ,
         c.policy_number,
          to_char(c.policy_effective_from,''dd/mm/yyyy'') AS policy_effective_from,
          to_char(c.policy_effective_to,''dd/mm/yyyy'') AS  policy_effective_to,
          c.policy_holder_name,
          CASE WHEN g.address_1 IS NOT NULL THEN g.address_1
             ||CASE WHEN g.address_2 IS NOT NULL THEN '',''||g.address_2 END
             ||CASE WHEN g.address_3 IS NOT NULL THEN '',''||g.address_3 END
             ||CASE WHEN g.city_type_id IS NOT NULL THEN '',''||g.city_type_id END END
             AS address_of_insured,

          g.address_1,
          g.address_2,
          g.address_3,
          g.city_type_id,
          c.claimant_name,
          c.mem_total_sum_insured,
          d.relship_description,
          c.mem_age,
          CASE WHEN c.gender_general_type_id = ''MAL'' THEN ''Male'' ELSE ''Female'' END AS gender,
          h.dev_officer_name,
          ''016'' AS tpa_code,
          --b.claim_number AS unique_claim_identifier,
          b.claim_seq_id AS unique_claim_identifier,
          CASE WHEN b.pat_enroll_detail_seq_id IS NOT NULL THEN ''CASH LESS'' ELSE ''REIMBURSEMENT'' END AS tpa_claim_code,
          --CASE WHEN b.pat_enroll_detail_seq_id IS NOT NULL THEN to_char(b.entered_date,''dd/mm/yyyy hh:mi am'') ELSE to_char(c.decision_date,''dd/mm/yyyy hh:mi am'') END AS intimation_date, -- use the same for loss_date
          CASE WHEN b.pat_enroll_detail_seq_id IS NOT NULL THEN to_char(v.decision_date,''dd/mm/yyyy'') ELSE to_char(b.added_date,''dd/mm/yyyy'') END AS intimation_date, -- use the same for loss_date
          nvl(i.address_1,g.address_1) AS claimant_address_1,
          nvl(i.address_2,g.address_2) AS claimant_address_2,
          nvl(i.address_3,g.address_3) AS claimant_address_3,
          nvl(i.city_type_id,g.city_type_id) AS claimant_city,
          nvl(j.state_name,w.state_name) AS claimant_state,
          i.pin_code AS claimant_pincode,
          nvl(k.country_name,x.country_name) AS claimant_country,
          CASE WHEN l.discharge_cond_general_type_id = ''DCD'' THEN ''Y'' ELSE ''N'' END AS death_claim_yn ,
          m.hosp_name,
          m.city_name AS hosp_city,
          to_char(b.date_of_admission,''dd/mm/yyyy'') AS date_of_admission,
          to_char(b.date_of_discharge,''dd/mm/yyyy'') AS date_of_discharge,
          trunc(b.date_of_discharge - b.date_of_admission) AS number_of_days,
          l.ailment_description,
          a.icd_codes,
          b.treating_dr_name,
          b.requested_amount AS claimed_amt,
          -- room
          o.room_requested_amt,
          o.room_number_of_days,
          o.room_allowed_amt,
          CASE WHEN o.room_allowed_amt > 0 THEN o.room_number_of_days ELSE 0 END AS app_room_number_of_days,
          --icu
          o.icu_requested_amt,
          o.icu_number_of_days,
          CASE WHEN o.icu_allowed_amt > 0 THEN o.icu_number_of_days ELSE 0 END AS app_icu_number_of_days,
          o.icu_allowed_amt,
          -- registration
          o.reg_requested_amt,
          o.reg_allowed_amt,
          --lab
          o.lab_requested_amt,
          o.lab_allowed_amt,
          -- food
          o.food_requested_amt,
          o.food_allowed_amt,
          -- ot
          o.ot_requested_amt,
          o.ot_allowed_amt,
          -- medicine
          o.med_requested_amt,
          o.med_allowed_amt,
          --nursing
          o.nursing_requested_amt,
          o.nursing_allowed_amt,
          --doctor
          o.doctor_fee_requested_amt,
          o.doctor_fee_allowed_amt,
          to_char(o.pre_hosp_from,''dd/mm/yyyy'') AS pre_hosp_from,
          to_char(o.pre_hosp_to,''dd/mm/yyyy'') AS pre_hosp_to,
          o.pre_hosp_requested,
          o.pre_hosp_allowed,
          (o.pre_hosp_to - o.pre_hosp_from) + 1 AS pre_hosp_days,
          to_char(o.post_hosp_from,''dd/mm/yyyy'') AS post_hosp_from,
          to_char(o.post_hosp_to,''dd/mm/yyyy'') AS post_hosp_to,
          o.post_hosp_requested,
          o.post_hosp_allowed,
          (o.post_hosp_to - o.post_hosp_from) + 1 AS post_hosp_days,
          --r.check_num,
          null as check_num,
          --to_char(r.check_date,''dd/mm/yyyy'') AS check_date,
          null as check_date,
          --r.check_amount,
          nvl(tds.check_amount,U.approved_amount) AS check_amount,
          --r.in_favour_of,
          ttk_util_pkg.fn_decrypt(U.payee_name) AS in_favour_of,
          t.office_name AS printing_location,



 ----added for KOC1186
 CASE WHEN (CASE WHEN GC.description=''Member'' AND nvl(B.pay_to_general_type_id,''MBR'')!=''HSL'' THEN--This is added for hyundai requirement
              CASE WHEN U.tpa_nhcp_cheques_issued_to=''TPA'' THEN ''' ||
                 tpa_rec.account_number ||
                 ''' ELSE 
              (CASE WHEN h.enrol_type_id=''COR'' THEN (CASE WHEN h.tpa_cheque_issued_general_type=''IQI'' THEN ttk_util_pkg.fn_decrypt(bd.bank_account_no)
              WHEN h.tpa_cheque_issued_general_type=''IQC'' THEN ttk_util_pkg.fn_decrypt(bdK.bank_account_no) END)
              ELSE ttk_util_pkg.fn_decrypt(bd.bank_account_no) END)END 
              ELSE ttk_util_pkg.fn_decrypt(had.account_number) end) IS  NULL OR
              (CASE WHEN GC.description=''Member'' AND nvl(B.pay_to_general_type_id,''MBR'')!=''HSL'' THEN--This is added for hyundai requirement
               CASE WHEN U.tpa_nhcp_cheques_issued_to=''TPA'' THEN ''' ||
                 tpa_rec.account_number ||
                 ''' ELSE 
              (CASE WHEN h.enrol_type_id=''COR'' THEN (CASE WHEN h.tpa_cheque_issued_general_type=''IQI'' THEN ttk_util_pkg.fn_decrypt(bd.bank_account_no)
              WHEN h.tpa_cheque_issued_general_type=''IQC'' THEN ttk_util_pkg.fn_decrypt(bdK.bank_account_no) END)
              ELSE ttk_util_pkg.fn_decrypt(bd.bank_account_no) END)END 
              ELSE ttk_util_pkg.fn_decrypt(had.account_number) end=''NA'' ) THEN ''D'' ELSE ''N'' END  AS transaction_type,

 CASE WHEN (CASE WHEN GC.description=''Member'' AND nvl(B.pay_to_general_type_id,''MBR'')!=''HSL'' THEN--This is added for hyundai requirement
               CASE WHEN U.tpa_nhcp_cheques_issued_to=''TPA'' THEN ''' ||
                 tpa_rec.account_number ||
                 ''' ELSE 
              (CASE WHEN h.enrol_type_id=''COR'' THEN (CASE WHEN h.tpa_cheque_issued_general_type=''IQI'' THEN ttk_util_pkg.fn_decrypt(BD.bank_account_no)
              WHEN h.tpa_cheque_issued_general_type=''IQC'' THEN ttk_util_pkg.fn_decrypt(BDK.bank_account_no) END)
              ELSE ttk_util_pkg.fn_decrypt(BD.bank_account_no) END)END 
              ELSE ttk_util_pkg.fn_decrypt(had.account_number) end)=''NA'' THEN NULL
 ELSE (CASE WHEN GC.description=''Member'' AND nvl(B.pay_to_general_type_id,''MBR'')!=''HSL'' THEN--This is added for hyundai requirement
              CASE WHEN U.tpa_nhcp_cheques_issued_to=''TPA'' THEN ''' ||
                 tpa_rec.account_number ||
                 ''' ELSE 
              (CASE WHEN h.enrol_type_id=''COR'' THEN (CASE WHEN h.tpa_cheque_issued_general_type=''IQI'' THEN ttk_util_pkg.fn_decrypt(BD.bank_account_no)
              WHEN h.tpa_cheque_issued_general_type=''IQC'' THEN ttk_util_pkg.fn_decrypt(BDK.bank_account_no) END)
              ELSE ttk_util_pkg.fn_decrypt(BD.bank_account_no) END) END 
              ELSE ttk_util_pkg.fn_decrypt(had.account_number) end) END as account_no_of_beneficiary,

  ttk_util_pkg.fn_decrypt(CASE WHEN GC.description=''Member'' AND nvl(B.pay_to_general_type_id,''MBR'')!=''HSL'' THEN--This is added for hyundai requirement
             CASE WHEN U.tpa_nhcp_cheques_issued_to=''TPA'' THEN ''' ||
                 tpa_rec.bank_ifsc || ''' ELSE 
             (CASE WHEN h.enrol_type_id=''COR'' THEN (CASE WHEN h.tpa_cheque_issued_general_type=''IQI'' THEN BD.bank_ifsc
              WHEN h.tpa_cheque_issued_general_type=''IQC'' THEN BDK.bank_ifsc end)
              ELSE BD.bank_ifsc END)END 
              ELSE had.bank_ifsc END) AS IFSC_CODE,
 ----added for KOC1186


          t.office_name AS payable_location,
          NULL AS bank_ref_code,' || v_batch_seq_id ||
                 '  AS batch_no,
          CASE WHEN U.address1 IS NOT NULL THEN U.address1
             ||CASE WHEN U.address2 IS NOT NULL THEN '',''||U.address2 END
             ||CASE WHEN U.address3 IS NOT NULL THEN '',''||U.address3 END END AS address_of_beneficiary,
          b.total_app_amount AS settled_amount,
          NULL AS serial_no_of_claimant,
          h.policy_agent_code,
          b.claim_settlement_number AS claim_remarks
          FROM icd_tab a JOIN clm_general_details b ON (a.claim_seq_id = b.claim_seq_id)
          JOIN clm_enroll_details c ON (b.claim_seq_id = c.claim_seq_id)
          JOIN tpa_relationship_code d ON (c.relship_type_id = d.relship_type_id)
          JOIN tpa_enr_policy_member e ON (c.member_seq_id = e.member_seq_id)
          JOIN tpa_enr_policy_group f ON (e.policy_group_seq_id = f.policy_group_seq_id)
          JOIN tpa_enr_policy h ON (c.policy_seq_id = h.policy_seq_id)
          LEFT OUTER JOIN tpa_enr_mem_address g ON (f.enr_address_seq_id = g.enr_address_seq_id)
          LEFT OUTER JOIN tpa_enr_mem_address i ON (e.enr_address_seq_id = i.enr_address_seq_id)
          LEFT OUTER JOIN tpa_state_code j ON (i.state_type_id = j.state_type_id)
          LEFT OUTER JOIN tpa_country_code k ON (i.country_id = k.country_id)
          LEFT OUTER JOIN tpa_state_code w on (g.state_type_id = w.state_type_id)
          LEFT OUTER JOIN tpa_country_code x ON (g.country_id = x.country_id)
          JOIN ailment_details l ON (b.claim_seq_id = l.claim_seq_id)
          LEFT OUTER JOIN app.clm_hospital_details M ON (b.claim_seq_id = m.claim_seq_id)
          LEFT OUTER JOIN ward_tab o ON (a.payment_seq_id = o.payment_seq_id)
          LEFT OUTER JOIN tpa_payment_checks_details q ON (a.payment_seq_id = q.payment_seq_id and q.v_csr_flag=1)
          --LEFT OUTER JOIN tpa_claims_check r ON (q.claims_chk_seq_id = r.claims_chk_seq_id)
          JOIN tpa_office_info t ON (h.tpa_office_seq_id = t.tpa_office_seq_id)
          JOIN tpa_claims_payment U ON (a.payment_seq_id = U.payment_seq_id)
          LEFT OUTER JOIN pat_enroll_details v ON (b.pat_enroll_detail_seq_id =v.pat_enroll_detail_seq_id)
          LEFT OUTER JOIN tpa_clm_tds_details tds ON (U.payment_seq_id = tds.payment_seq_id)
          -----added for KOC1186
          LEFT OUTER JOIN clm_inward IC ON (b.claims_inward_seq_id = IC.claims_inward_seq_id)
          LEFT OUTER JOIN tpa_general_code GC ON (IC.claim_general_type_id = GC.general_type_id)
          LEFT OUTER JOIN tpa_enr_bank_dtls BD ON (f.BANK_SEQ_ID=BD.BANK_SEQ_ID)
          LEFT OUTER JOIN tpa_enr_bank_dtls BDK ON (h.bank_seq_id=BDK.bank_seq_id)
          LEFT OUTER JOIN app.clm_hospital_details cha ON (b.claim_seq_id = cha.claim_seq_id)
          LEFT OUTER JOIN tpa_hosp_info hi ON (cha.hosp_seq_id = hi.hosp_seq_id)
          LEFT OUTER JOIN tpa_hosp_account_details had ON(had.hosp_seq_id=hi.hosp_seq_id))';
    ----added for KOC1186

    ---save_to_temp( v_sql_str);
    --getting no_of_transactions/payemts count made to READY_TO_BANK.
    v_count_of_payments := str_tab.COUNT;
    v_sql_str           := v_sql_str || ' where AQ=1';

    IF str_tab.FIRST IS NOT NULL THEN
      IF str_tab.COUNT <= 8 THEN
        CASE str_tab.COUNT
          WHEN 1 THEN
            OPEN v_resultset FOR v_sql_str
              USING v_float_seq_id, str_tab(1), v_float_seq_id, str_tab(1);
          WHEN 2 THEN
            OPEN v_resultset FOR v_sql_str
              USING v_float_seq_id, str_tab(1), str_tab(2), v_float_seq_id, str_tab(1), str_tab(2);
          WHEN 3 THEN
            OPEN v_resultset FOR v_sql_str
              USING v_float_seq_id, str_tab(1), str_tab(2), str_tab(3), v_float_seq_id, str_tab(1), str_tab(2), str_tab(3);
          WHEN 4 THEN
            OPEN v_resultset FOR v_sql_str
              USING v_float_seq_id, str_tab(1), str_tab(2), str_tab(3), str_tab(4), v_float_seq_id, str_tab(1), str_tab(2), str_tab(3), str_tab(4);
          WHEN 5 THEN
            OPEN v_resultset FOR v_sql_str
              USING v_float_seq_id, str_tab(1), str_tab(2), str_tab(3), str_tab(4), str_tab(5), v_float_seq_id, str_tab(1), str_tab(2), str_tab(3), str_tab(4), str_tab(5);
          WHEN 6 THEN
            OPEN v_resultset FOR v_sql_str
              USING v_float_seq_id, str_tab(1), str_tab(2), str_tab(3), str_tab(4), str_tab(5), str_tab(6), v_float_seq_id, str_tab(1), str_tab(2), str_tab(3), str_tab(4), str_tab(5), str_tab(6);
          WHEN 7 THEN
            OPEN v_resultset FOR v_sql_str
              USING v_float_seq_id, str_tab(1), str_tab(2), str_tab(3), str_tab(4), str_tab(5), str_tab(6), str_tab(7), v_float_seq_id, str_tab(1), str_tab(2), str_tab(3), str_tab(4), str_tab(5), str_tab(6), str_tab(7);
          WHEN 8 THEN
            OPEN v_resultset FOR v_sql_str
              USING v_float_seq_id, str_tab(1), str_tab(2), str_tab(3), str_tab(4), str_tab(5), str_tab(6), str_tab(7), str_tab(8), v_float_seq_id, str_tab(1), str_tab(2), str_tab(3), str_tab(4), str_tab(5), str_tab(6), str_tab(7), str_tab(8);
        END CASE;
      ELSE
        OPEN v_resultset FOR v_sql_str
          USING v_float_seq_id, v_float_seq_id;
      END IF;
    ELSE
      OPEN v_resultset FOR v_sql_str
        USING v_float_seq_id, v_float_seq_id;
    END IF;

    UPDATE tpa_bank_advice_batch A
       SET A.no_of_transactions = v_count_of_payments,
           A.file_name          = v_filename,
           A.updated_date       = SYSDATE,
           a.updated_by         = v_added_by
     WHERE batch_seq_id = v_batch_seq_id;

    --update the status to sent_to_bank to the respective claims.
    IF str_tab.FIRST IS NOT NULL THEN
      FORALL i IN str_tab.FIRST .. str_tab.LAST
        UPDATE tpa_claims_payment a
           SET A.claim_payment_status = 'SENT_TO_BANK',
               A.bank_advice_batch    = bank_advice_batch_seq.CURRVAL,
               A.updated_date         = SYSDATE,
               a.updated_by           = v_added_by
         WHERE payment_seq_id = TO_NUMBER(str_tab(i));
    END IF;

    v_rows_processed := str_tab.LAST;
    COMMIT;
  END generate_oi_payment_advice;
  /*==============================================================================================
    Name       : generate_boi_payment_advice
    Created on : 01-10-2012
    Created By : Ibrahim Sayyed
    Company    : RCS Technologies
    Added for  : KOC1220
    Comments   : This procedure is used to generate xlreport for payment advice
  ============================================================================================== */
  PROCEDURE generate_boa_payment_advice(v_payment_seq_id IN VARCHAR2,
                                        v_float_seq_id   IN tpa_float_account.float_seq_id%TYPE,
                                        v_resultset      OUT SYS_REFCURSOR) IS
    v_bank_seq_id                tpa_bank_master.bank_seq_id%TYPE;
    v_count_of_payments          tpa_claims_payment.payment_seq_id%TYPE;
    v_batch_seq_id               tpa_bank_advice_batch.batch_seq_id%TYPE;
    str_tab                      ttk_util_pkg.str_table_type;
    v_where                      VARCHAR2(2000);
    v_sql_str                    VARCHAR2(32767);
    i                            NUMBER(2) := 0;
    v_tds_str                    VARCHAR2(2000);
    v_claim_seq_id               tpa_claims_payment.claim_seq_id%TYPE;
    v_hosp_seq_id                tpa_claims_payment.hosp_seq_id%TYPE;
    v_cheque_amount              tpa_claims_payment.approved_amount%TYPE;
    v_appr_amount                tpa_claims_payment.approved_amount%TYPE;
    v_tds_payment_seq_id         tpa_claims_payment.payment_seq_id%TYPE;
    v_exist_yn                   VARCHAR2(1) := 'N';
    v_tpa_nhcp_cheques_issued_to tpa_claims_payment.tpa_nhcp_cheques_issued_to%TYPE;

    CURSOR tpa_bank_details IS
      SELECT ad.bank_name,
             ad.account_number,
             ad.branch_name,
             ad.bank_micr,
             ad.bank_ifsc,
             ad.account_type
        FROM fin_app.tpa_account_details ad;
    tpa_rec tpa_bank_details%rowtype; --balley

  BEGIN
    OPEN tpa_bank_details;
    FETCH tpa_bank_details
      INTO tpa_rec;
    CLOSE tpa_bank_details;

    str_tab := ttk_util_pkg.parse_str(v_payment_seq_id);

    SELECT A.bank_seq_id
      INTO v_bank_seq_id
      FROM tpa_bank_accounts a
      JOIN tpa_float_account b
        ON (a.bank_acc_seq_id = b.bank_acc_seq_id)
     WHERE b.float_seq_id = v_float_seq_id;

    IF (str_tab.FIRST IS NOT NULL) THEN
      IF str_tab.COUNT <= 8 THEN
        FOR i in str_tab.FIRST .. str_tab.LAST LOOP
          v_where := v_where || ' OR D.payment_seq_id = :bind_tab_' || i;
        END LOOP;
      ELSE
        v_where := ' OR D.payment_seq_id IN ( ' ||
                   REPLACE(SUBSTR(v_payment_seq_id,
                                  2,
                                  LENGTH(v_payment_seq_id) - 2),
                           '|',
                           ',') || ') ';
      END IF;
    END IF;

    IF v_where IS NOT NULL THEN
      v_where := ' AND (' || substr(v_where, 4) || ')';
    END IF;

    v_sql_str := 'WITH sum_tab as
         ( SELECT D.payment_seq_id, SUM(C.rejected_amount) as v_rej_amt,
            SUM( CASE WHEN C.apply_discount_yn = ''Y'' THEN (C.REQUESTED_AMOUNT * NVL(C.discount_percnt,0))/100
            ELSE 0 END ) AS v_disc_amt, D.Approved_Amount AS v_pay_amt,
            --nvl(e.check_amount, D.Approved_Amount) AS v_chq_amt,
            nvl(c.check_amount, a.tot_approved_amount) AS v_chq_amt,
            SUM (CASE WHEN b.bill_date NOT BETWEEN trunc(a.date_of_admission) AND trunc(a.date_of_discharge) THEN c.allowed_amount ELSE 0 END)  pre_post_amount,
            SUM (c.requested_amount) AS requested_amount,
            SUM (CASE WHEN ward_type_id IN (''ROO'',''NUC'') THEN c.allowed_amount ELSE 0 END ) AS ROOM_CHARGES,
            SUM (CASE WHEN ward_type_id IN (''ICU'',''ICC'',''ICN'',''ICR'') THEN c.allowed_amount ELSE 0 END ) AS ICU_CHARGES,
            SUM (CASE WHEN ward_type_id IN (''PRO'') THEN c.allowed_amount ELSE 0 END ) AS PROFESSIONAL_CHARGES,
            SUM (CASE WHEN ward_type_id IN (''LAI'') THEN c.allowed_amount ELSE 0 END ) AS LAB_CHARGES,
            SUM (CASE WHEN ward_type_id IN (''PHA'',''MED'') THEN c.allowed_amount ELSE 0 END ) AS PHARMACY_CHARGES
          FROM clm_general_details A INNER JOIN clm_bill_header B ON (A.claim_seq_id = B.claim_seq_id)
              INNER JOIN clm_bill_details C ON (B.clm_bill_seq_id = C.clm_bill_seq_id)
              INNER JOIN tpa_claims_payment D ON (A.claim_seq_id = D.claim_seq_id)
              LEFT OUTER JOIN TPA_CLM_TDS_DETAILS E ON (d.payment_seq_id = e.payment_seq_id)
              WHERE D.float_seq_id = :v_float_seq_id ' ||
                 v_where ||
                 ' GROUP BY D.payment_seq_id,D.Approved_Amount, nvl(e.check_amount, D.Approved_Amount))

            select boa.*,to_char(rownum) as slno from(
          SELECT  dense_rank() over (partition by a.claim_seq_id order by ald.ailment_details_seq_id,rownum desc) as AQ,
              a.payment_seq_id,
              a.claim_payment_status ,
              to_char(a.bank_advice_batch) AS batch_no,--koc1220-A
              NULL AS save_file_name,
              nvl(Ll.v_rej_amt,0)  AS tot_disallow_amt,
              nvl(Ll.v_disc_amt,0)  AS tot_discount_amt,
              nvl(Ll.v_pay_amt,0)  AS tot_payable_amt,
              to_char(nvl(Ll.v_chq_amt,0))  AS cheuqe_amt,               -- Transaction Amount --koc1220
              to_char(rownum) AS slmno,
              CASE WHEN a.hosp_seq_id IS NOT NULL THEN ''H''
                     ELSE CASE WHEN a.ENROL_TYPE_ID IN (''IND'',''ING'') THEN ''I'' WHEN a.ENROL_TYPE_ID =''COR'' THEN ''C'' ELSE ''N'' END
                END  AS chq_drawee,
              ttk_util_pkg.fn_decrypt(a.payee_name) AS payee_name ,                         --Receiving Party Name
              SUBSTR(a.address1||'', ''||a.address2||'',''||a.address3,1,35) AS address,  --Receiving Party Address 1
              SUBSTR(a.address1,1,35)   AS address1,                                                --Receiving Party Address 2
              a.address2,
              a.address3,
              null as address4,
              null as address5,
              null as address6,
              a.city,                                                        --Receiving Party City Name
              a.state,
              NULL AS recv_party_state_code,--Receiving Party State Code
              a.pincode,                                                     --Receiving Party Zip / Postal Code
              b.policy_number,
              c.tpa_enrollment_id,
              d.insured_name as mem_name,
              d.employee_no,
              c.certificate_no,
              l.mem_name as claimant_name,
              --l.in_patient_no as ipno,
              null as ipno,
              l.settlement_number as claim_settlement_number ,                       --Receiving Party ID
              a.claim_amount,
              ''PLEASE CONTACT Vidal Health TPA Pvt. Ltd FOR FURTHER DETAILS. ANY DISAGREEMENT CALL /WRITE WITHIN 10 DAYS.TOLL FREE  080-40539789'' AS pay_adv1,
              ''ENCASHMENT OF CHEQUE DISCHARGES THE LIABILITY OF INSURER UNDER THE SAID CLAIM'' AS pay_adv2,
              f.remarks as dis_allow_reason1,
              null as dis_allow_reason2,
              null as dis_allow_reason3,
              null as dis_allow_reason4,
              null as dis_allow_reason5,
              i.address_1||i.address_2||i.address_3 AS addr1,
              i.address_1,
              i.address_2,
              i.address_3,
              j.city_description,
              i.pin_code,
              k.off_phone_no_1,
              k.office_fax_no_1,
              h.ins_comp_name,
              1 as do_lost,
              k.email_id,
              NULL AS UTIACC_NUM,
              ''DXB''||k.office_code||''PAY1'' as product_name, h.ins_comp_code_number,
              l.claim_number, k.office_code,
              gc.description, to_char(c.mem_age) as mem_age,
               rc.relship_description as Relationship,
              to_char(b.effective_from_date,''dd-mm-yyyy'') AS effective_from_date,--koc1220-A
              to_char(b.effective_to_date,''dd-mm-yyyy'') AS effective_to_date,--koc1220-A
              to_char(ci.rcvd_date,''dd-mm-yyyy'') AS rcvd_date,--koc1220-A
              to_char(ci.rcvd_date,''dd-mm-yyyy'') AS clm_rcvd_dt,--koc1220-A
              --b.total_sum_insured,
              nvl(to_char(CASE WHEN b.policy_sub_general_type_id=''PNF'' THEN c.mem_tot_sum_insured
                 ELSE d.family_tot_sum_insured END),0) as total_sum_insured, --KOC1220
              b.tpa_cheque_issued_general_type,
              to_char(l.date_of_admission,''dd-mm-yyyy'') AS date_of_admission,--koc1220-A
              to_char(l.date_of_discharge,''dd-mm-yyyy'') AS date_of_discharge,--koc1220-A
              to_char((trunc(l.date_of_discharge)-trunc(l.date_of_admission))) AS NoOfDays, --KOC1220
              nvl(hosa.hosp_name,hospi.hosp_name) AS hosp_name,
              NVL(hosa.city_name, city.city_description) AS Hosp_place,
              cc.check_num,       --Check Number
              to_char(cc.check_date,''dd-mm-yyyy'') AS check_date,--koc1220-A
              ct.description AS Claim_Type,
--koc1220-A
              nvl(SUBSTR((CASE WHEN a.payee_type=''PCA'' THEN ''NA'' WHEN a.payee_type=''EFT''  THEN
              (CASE WHEN ct.description=''Member'' AND nvl(L.pay_to_general_type_id,''MBR'')!=''HSL'' THEN--This is added for hyundai requirement
                CASE WHEN a.tpa_nhcp_cheques_issued_to=''TPA'' THEN ''' ||
                 tpa_rec.bank_name ||
                 ''' ELSE 
              (CASE WHEN b.enrol_type_id=''COR'' THEN (CASE WHEN b.tpa_cheque_issued_general_type=''IQI'' THEN ttk_util_pkg.fn_decrypt(p.bank_name)
              WHEN B.tpa_cheque_issued_general_type=''IQC'' THEN ttk_util_pkg.fn_decrypt(r.bank_name) END)
              ELSE ttk_util_pkg.fn_decrypt(p.bank_name) END)END 
              ELSE ttk_util_pkg.fn_decrypt(q.bank_name) END) END),1,33),'''') as cust_bank_name,      --Receiving Bank Name

              nvl((CASE WHEN a.payee_type=''PCA'' THEN ''NA'' WHEN a.payee_type=''EFT''  THEN
              (CASE WHEN ct.description=''Member'' AND nvl(L.pay_to_general_type_id,''MBR'')!=''HSL'' THEN--This is added for hyundai requirement
              CASE WHEN a.tpa_nhcp_cheques_issued_to=''TPA'' THEN ''' ||
                 tpa_rec.account_number ||
                 ''' ELSE 
              (CASE WHEN b.enrol_type_id=''COR'' THEN (CASE WHEN b.tpa_cheque_issued_general_type=''IQI'' THEN ttk_util_pkg.fn_decrypt(p.bank_account_no)
              WHEN B.tpa_cheque_issued_general_type=''IQC'' THEN ttk_util_pkg.fn_decrypt(r.bank_account_no) END)
              ELSE ttk_util_pkg.fn_decrypt(p.bank_account_no) END) END 
              ELSE ttk_util_pkg.fn_decrypt(q.account_number) END) END),'''') as account_num,    --Receiving Bank Account Number
--koc1220-A
              (CASE WHEN a.payee_type=''PCA'' THEN ''NA'' WHEN a.payee_type=''EFT''  THEN
              (CASE WHEN ct.description=''Member'' AND nvl(L.pay_to_general_type_id,''MBR'')!=''HSL'' THEN--This is added for hyundai requirement
               CASE WHEN a.tpa_nhcp_cheques_issued_to=''TPA'' THEN ''' ||
                 tpa_rec.account_type ||
                 ''' ELSE 
              (CASE WHEN b.enrol_type_id=''COR'' THEN (CASE WHEN b.tpa_cheque_issued_general_type=''IQI'' THEN ttk_util_pkg.fn_decrypt(p.account_name)
              WHEN B.tpa_cheque_issued_general_type=''IQC'' THEN ttk_util_pkg.fn_decrypt(r.account_name) end)
              ELSE ttk_util_pkg.fn_decrypt(P.account_name) END)END
              ELSE ttk_util_pkg.fn_decrypt(q.account_type) end) END) as account_type,

              (CASE WHEN a.payee_type=''PCA'' THEN ''NA'' WHEN a.payee_type=''EFT''  THEN
              (CASE WHEN ct.description=''Member'' AND nvl(L.pay_to_general_type_id,''MBR'')!=''HSL'' THEN--This is added for hyundai requirement
               CASE WHEN a.tpa_nhcp_cheques_issued_to=''TPA'' THEN ''' ||
                 tpa_rec.bank_micr ||
                 ''' ELSE 
              (CASE WHEN b.enrol_type_id=''COR'' THEN (CASE WHEN b.tpa_cheque_issued_general_type=''IQI'' THEN ttk_util_pkg.fn_decrypt(p.bank_micr)
              WHEN B.tpa_cheque_issued_general_type=''IQC'' THEN ttk_util_pkg.fn_decrypt(r.bank_micr) end)
              ELSE ttk_util_pkg.fn_decrypt(p.bank_micr) END)END 
              ELSE ttk_util_pkg.fn_decrypt(q.bank_micr) END) END)AS MICR_CODE,

             (CASE WHEN a.payee_type=''PCA'' THEN ''NA'' WHEN a.payee_type=''EFT''  THEN
             (CASE WHEN ct.description=''Member'' AND nvl(L.pay_to_general_type_id,''MBR'')!=''HSL'' THEN--This is added for hyundai requirement
               CASE WHEN a.tpa_nhcp_cheques_issued_to=''TPA'' THEN ''' ||
                 tpa_rec.bank_ifsc ||
                 ''' ELSE 
             (CASE WHEN b.enrol_type_id=''COR'' THEN (CASE WHEN b.tpa_cheque_issued_general_type=''IQI'' THEN ttk_util_pkg.fn_decrypt(p.bank_ifsc)
              WHEN B.tpa_cheque_issued_general_type=''IQC'' THEN ttk_util_pkg.fn_decrypt(r.bank_ifsc) end)
              ELSE ttk_util_pkg.fn_decrypt(p.bank_ifsc) END)END 
              ELSE ttk_util_pkg.fn_decrypt(q.bank_ifsc) END) END) AS IFSC_CODE,           --Receiving Bank ID / Sort code

              NULL AS  Rcv_Bank_Qualifier,                  --Receiving Bank Qualifier
              NULL AS  RCV_Bank_Address,                    --Receiving Bank SWIFT Addres
              NULL AS  Rcv_bank_Branch_Num,                --Receiving Bank Branch Number
              ''INDIA'' AS Rcv_Bank_City,                   --ReceivingBank City Name
              ''IN''    AS Rcv_Bank_Country_Code,   --Receiving Bank ISO Country Code
--koc1220-A
              nvl(to_char(CASE WHEN c.mem_general_type_id = ''PFL'' THEN d.floater_tot_bonus ELSE c.mem_tot_bonus END),0) AS bonus, --KOC1220
  --            bons.bonus,
              ald.ailment_description AS ailment,
--koc1220-A
              case when nvl(to_char(CASE WHEN tpa_nhcp_cheques_issued_to =''HOS'' AND hospi.hosp_seq_id IS NOT NULL THEN
                     nvl(Ll.v_chq_amt,0) ELSE 0 END ),0) > 0 then
                        to_char(CASE WHEN tpa_nhcp_cheques_issued_to =''HOS'' AND hospi.hosp_seq_id IS NOT NULL THEN
                      nvl(Ll.v_chq_amt,0) ELSE 0 END ) else
              to_char(CASE WHEN NVL(tpa_nhcp_cheques_issued_to,''*'') !=''HOS'' THEN nvl(Ll.v_chq_amt,0) ELSE 0 END)
              end AS EFT,
--koc1220-A
 --             to_char(CASE WHEN tpa_nhcp_cheques_issued_to =''HOS'' AND hospi.hosp_seq_id IS NOT NULL THEN
 --                       nvl(Ll.v_chq_amt,0) ELSE 0 END )AS Qtm_Disbursed_Cashless, --koc1220
 --             to_char(CASE WHEN NVL(tpa_nhcp_cheques_issued_to,''*'') !=''HOS'' THEN nvl(Ll.v_chq_amt,0) ELSE 0 END) AS Qtm_Disbursed_Reimb, --koc1220
              NULL AS Trans_ref_num, k.office_name,
              FLOAT_ACCOUNTS_PKG.get_Rej_billno(l.claim_seq_id) as Bill_no,
              (SELECT office_name FROM tpa_office_info WHERE office_code = SUBSTR(a.claim_settlement_no,1,3) AND ROWNUM = 1) as print_pay_loc,
              --l.requested_amount,  ---for KOC647  ...RJP
              -------------------------------------------------From Here
              CASE WHEN A.PAYEE_TYPE=''EFT'' THEN ''N''  ELSE ''D'' END AS payment_type, -- Payment Type ADDED FOR KOC1103
              to_char(a.approved_amount) approved_amount , -- Gross Amount
              to_char(ll.pre_post_amount) pre_post_amount, -- Quantum disbursed - pre/ post hospitalization --koc122

--koc1220-A
             to_char(c.date_of_inception,''dd-mm-yyyy'') as date_of_inception,
--koc1220-A              --FLOAT_ACCOUNTS_PKG.get_date_of_inception ( c.tpa_enrollment_id  , a.policy_seq_id , b.ins_head_office_seq_id  ) as date_of_inception, -- Date of inception of first policy
              batch_report_pkg.get_comp_icds(a.claim_seq_id) AS icd_codes, -- ICD code
              to_char(ll.requested_amount) AS bill_requested_amount, -- Total billed amount for period of hospitalization  KOC1220
              nvl(to_char(a.approved_amount  - TDS.check_amount),0)  AS tds_amt, -- TDS koc1220 --koc1220-A
              to_char(ll.room_charges) as room_charges, -- Room/ Board/ nursing charges --koc1220
              to_char(ll.icu_charges) as icu_charges, -- ICU charges --koc1220
              TO_CHAR(ll.professional_charges) AS professional_charges , -- Professional fees --koc1220
              to_char(ll.lab_charges) as lab_charges , -- Lab/ investigation charges --koc1220
              to_char(ll.pharmacy_charges) as pharmacy_charges, -- Pharmacy charges    --koc1220
              to_char(a.approved_amount - ( ll.room_charges + ll.icu_charges + ll.professional_charges + ll.lab_charges + ll.pharmacy_charges )) AS other_charges, -- Other charges --koc1220
              --l.total_app_amount - nvl(l.serv_tax_calc_amount,0) AS Claim_Amt_NoST,
              --to_char(l.serv_tax_calc_amount)  AS Service_Tax,
              Ll.v_chq_amt AS Net_Amount,
              ''TRN'' AS record_type,                            --Record Type
              (CASE WHEN a.payee_type=''PCA'' THEN ''PBD'' WHEN a.payee_type=''EFT'' THEN ''ACH'' END) AS transaction_type,  --Transaction Type
              NULL AS  Alternate_Trans_Type,                     --Alternate Transaction Type
              NULL AS  US_ACH_company_id,                        --U.S. ACH Company ID
              ''6215'' AS branch_Code,                           --Branch Code
              ''70209011''     AS Originator_acn_no,                     --Originator A/C
              NULL     AS ABA_Routing_Num,                       --ABA Routing Number for US
              ''INR''  AS Originator_ACN_Cur,                    --Originator A/C Currency
              ''PAY''  AS Transaction_Indicator,                 --Transaction Indicator
              ''C''    AS Transaction_Handling_Code,             --Transaction Handling Code
              ''S''    AS Posting_Indicator,                     --Posting Indicator
              NULL     AS Consolidate_Ref,                       --Consolidated Reference
              NULL     AS Priority_Indicator,                    --Priority Indicator
              --to_char(fin_payment_adv_uniqu_ref.nextval) AS Transaction_Ref, --Transaction Reference
              NULL     AS Rcv_Part_Mail_Handling_Code,                          --Receiving Party Mail Handling Code
              ''Vidal Health TPA Pvt. Ltd'' AS Ordering_Party_Name,            --Ordering Party Name
              NULL     AS ordering_party_ID,                                    --Ordering Party ID
              ''Vidal Health TPA Pvt. Ltd'' AS Ordering_Party_Addres1,         --Ordering Party Address 1
              ''Bangalore''                  AS  Ordering_Party_Addres2,        --Ordering Party Address 2
              ''Bangalore''                  AS  Ordering_Party_City,           --Ordering Party City Name
              NULL                           AS  Ordering_Party_State,          --Ordering Party State Code
              NULL                           AS  Ordering_Party_Zip,            --Ordering Party Zip / Postal Code
              ''IN''                         AS Ordering_party_Country_Code,    --Ordering Party ISO Country Code
              ''INR''                        AS Trans_Currency_Code,            --Transaction Currency Code
              TO_CHAR(SYSDATE,''YYYYMMDD'')  AS  payment_value_day,             --Payment Value Date
              NULL AS Trans_Desc,                                               --Transaction Description
              ''OUR'' AS Charge_Indicator,                                         --Charge Indicator
              nvl(Ll.v_chq_amt,0)  AS cal_cheque_amount,            --KOC1220
              ''0'' as cal_num,                                                  --KOC1220
--koc1220-A
              case when h.ins_comp_code_number||'''' like ''500%'' then
                substr(h.ins_comp_code_number||'''',1,4)
                else substr(h.ins_comp_code_number||'''',1,2) end as ro_code,
               DN.DEBIT_NOTE_NUMBER,
               to_char(DN.DEBIT_DATE,''dd-mm-yyyy'') as DEBIT_DATE,
               '''' AS UIIC_CORE_CLAIM_NO,
               CASE WHEN A.CLAIM_TYPE=''CNH'' OR 
                 (ct.description=''Member'' AND L.CLAIM_SUB_GENERAL_TYPE_ID=''OPD'' AND nvl(L.pay_to_general_type_id,''MBR'')=''HSL'') THEN hospi.Pan_Number
                 ELSE '''' END AS PAN_NUMBER
--koc1220-A


         FROM tpa_claims_payment a JOIN tpa_enr_policy b ON (a.policy_seq_id = b.policy_seq_id)
              JOIN tpa_enr_policy_member c ON (a.member_seq_id = c.member_seq_id)
              JOIN tpa_enr_policy_group d ON (D.policy_group_seq_id = C.policy_group_seq_id)
              JOIN clm_general_details l ON (l.claim_seq_id = a.claim_seq_id)
              JOIN clm_enroll_details e ON (l.claim_seq_id = e.claim_seq_id)
              JOIN clm_inward ci ON (l.claims_inward_seq_id = ci.claims_inward_seq_id)
              JOIN tpa_ins_info h ON (a.ins_seq_id = h.ins_seq_id)
              JOIN tpa_address i ON(h.tpa_office_seq_id = i.tpa_office_seq_id)
              JOIN tpa_city_code j ON (i.city_type_id = j.city_type_id)
              JOIN tpa_office_info k ON (h.tpa_office_seq_id = k.tpa_office_seq_id)
              LEFT OUTER JOIN sum_tab Ll ON (A.payment_seq_id = Ll.payment_seq_id)
              LEFT OUTER JOIN tpa_debit_note dn ON (DN.FLOAT_SEQ_ID = A.FLOAT_SEQ_ID)  --koc1220-A
              LEFT OUTER JOIN assign_users f ON (l.claim_seq_id = f.claim_seq_id and l.last_assign_user_seq_id = f.assign_users_seq_id)
              LEFT OUTER JOIN tpa_general_code gc ON (c.gender_general_type_id = gc.general_type_id)
              LEFT OUTER JOIN tpa_relationship_code rc ON (c.relship_type_id = rc.relship_type_id)
              LEFT OUTER JOIN app.clm_hospital_details hosa ON (l.claim_seq_id = hosa.claim_seq_id)
              LEFT OUTER JOIN tpa_hosp_info hospi ON (hosa.hosp_seq_id = hospi.hosp_seq_id)
              LEFT OUTER JOIN tpa_hosp_address ha ON (hospi.hosp_seq_id = ha.hosp_seq_id)
              LEFT OUTER JOIN tpa_city_code city ON (ha.city_type_id = city.city_type_id)
              LEFT OUTER JOIN tpa_enr_bank_dtls P  ON (d.BANK_SEQ_ID=p.BANK_SEQ_ID)
              LEFT OUTER JOIN tpa_enr_bank_dtls r  ON (b.bank_seq_id=r.bank_seq_id)--ADDED FOR KOC1103
              LEFT OUTER JOIN tpa_hosp_account_details q ON(hospi.hosp_seq_id=q.hosp_seq_id)
         --     LEFT OUTER JOIN syn_hosp_ifsc_details  Q  ON (Q.EMPANEL_NUM=HOSPI.EMPANEL_NUMBER)  --Created FOR CR KOC1108 Temporarily and removed for parmanently cr koc1103
              LEFT OUTER JOIN tpa_payment_checks_details pcd ON (a.payment_seq_id = pcd.payment_seq_id and pcd.v_csr_flag=1)
              LEFT OUTER JOIN tpa_claims_check cc ON (pcd.claims_chk_seq_id = cc.claims_chk_seq_id and cc.v_csr_flag=1)
              LEFT OUTER JOIN tpa_general_code ct ON (l.claim_type = ct.general_type_id )
              --LEFT OUTER JOIN tpa_enr_balance bons ON (d.policy_group_seq_id = bons.policy_group_seq_id AND ( c.mem_general_type_id = ''PFL'' AND bons.member_seq_id IS NULL OR c.mem_general_type_id != ''PFL'' AND c.member_seq_id = bons.member_seq_id))
              LEFT OUTER JOIN ailment_details ald  ON (a.claim_seq_id = ald.claim_seq_id)
              LEFT OUTER JOIN tpa_clm_tds_details TDS  ON (a.claim_seq_id = TDS.claim_seq_id)
              WHERE a.float_seq_id = :v_float_seq_id ' ||
                 regexp_replace(v_where, 'D\.', 'A.') ||
                 ') boa where boa.AQ=1 order by to_number(slno)';

    --getting no_of_transactions/payemts count made to READY_TO_BANK.
    IF str_tab.FIRST IS NOT NULL THEN
      IF str_tab.COUNT <= 8 THEN
        CASE str_tab.COUNT
          WHEN 1 THEN
            OPEN v_resultset FOR v_sql_str
              USING v_float_seq_id, str_tab(1), v_float_seq_id, str_tab(1);
          WHEN 2 THEN
            OPEN v_resultset FOR v_sql_str
              USING v_float_seq_id, str_tab(1), str_tab(2), v_float_seq_id, str_tab(1), str_tab(2);
          WHEN 3 THEN
            OPEN v_resultset FOR v_sql_str
              USING v_float_seq_id, str_tab(1), str_tab(2), str_tab(3), v_float_seq_id, str_tab(1), str_tab(2), str_tab(3);
          WHEN 4 THEN
            OPEN v_resultset FOR v_sql_str
              USING v_float_seq_id, str_tab(1), str_tab(2), str_tab(3), str_tab(4), v_float_seq_id, str_tab(1), str_tab(2), str_tab(3), str_tab(4);
          WHEN 5 THEN
            OPEN v_resultset FOR v_sql_str
              USING v_float_seq_id, str_tab(1), str_tab(2), str_tab(3), str_tab(4), str_tab(5), v_float_seq_id, str_tab(1), str_tab(2), str_tab(3), str_tab(4), str_tab(5);
          WHEN 6 THEN
            OPEN v_resultset FOR v_sql_str
              USING v_float_seq_id, str_tab(1), str_tab(2), str_tab(3), str_tab(4), str_tab(5), str_tab(6), v_float_seq_id, str_tab(1), str_tab(2), str_tab(3), str_tab(4), str_tab(5), str_tab(6);
          WHEN 7 THEN
            OPEN v_resultset FOR v_sql_str
              USING v_float_seq_id, str_tab(1), str_tab(2), str_tab(3), str_tab(4), str_tab(5), str_tab(6), str_tab(7), v_float_seq_id, str_tab(1), str_tab(2), str_tab(3), str_tab(4), str_tab(5), str_tab(6), str_tab(7);
          WHEN 8 THEN
            OPEN v_resultset FOR v_sql_str
              USING v_float_seq_id, str_tab(1), str_tab(2), str_tab(3), str_tab(4), str_tab(5), str_tab(6), str_tab(7), str_tab(8), v_float_seq_id, str_tab(1), str_tab(2), str_tab(3), str_tab(4), str_tab(5), str_tab(6), str_tab(7), str_tab(8);
        END CASE;
      ELSE
        OPEN v_resultset FOR v_sql_str
          USING v_float_seq_id, v_float_seq_id;
      END IF;
    ELSE
      OPEN v_resultset FOR v_sql_str
        USING v_float_seq_id, v_float_seq_id;
    END IF;
  END generate_boa_payment_advice;
  --===========================================================================================
  function boa_unique(v_id number) return number is
    v_out number;
  begin
    if v_id is not null then
      select to_char(fin_payment_adv_uniqu_ref.nextval)
        into v_out
        from dual;
      return v_out;
    end if;
  end;
  --==========================================================================================
  PROCEDURE select_corporate_list(v_policy_number     IN tpa_enr_policy.policy_number%TYPE, --added by chiranjibi      
                                  v_group_id          IN tpa_group_registration.group_id%TYPE,
                                  v_group_name        IN tpa_group_registration.group_name%TYPE,
                                  v_tpa_office_seq_id IN tpa_office_info.tpa_office_seq_id%TYPE,
                                  v_enrol_type_id     IN tpa_enr_policy.enrol_type_id%TYPE,
                                  v_sort_var          IN VARCHAR2 := 'group_name',
                                  v_sort_order        IN VARCHAR2 := 'ASC',
                                  v_start_num         IN NUMBER := 1,
                                  v_end_num           IN NUMBER := 25,
                                  result_set          OUT SYS_REFCURSOR) IS
    v_sql_str VARCHAR2(2000);
    v_type    tpa_group_registration.group_general_type_id%TYPE;

    TYPE search_tab_type IS TABLE OF VARCHAR2(250) INDEX BY BINARY_INTEGER;
    search_tab search_tab_type;
    i          NUMBER(2) := 0;
    v_where    VARCHAR2(1000);
  BEGIN

    v_sql_str := 'SELECT
      A.group_reg_seq_id,
      DECODE(NVL(a.office_number,''000''),''000'',a.group_id,a.group_id||''-''||a.office_number) group_id,
      A.group_name ,
      B.office_name ,
      A.parent_group_seq_id,
      tep.policy_number as policy_no 
      FROM tpa_group_registration A JOIN tpa_office_info B ON (A.tpa_office_seq_id = B.tpa_office_seq_id)
      left outer join tpa_enr_policy tep ON (tep.group_reg_seq_id = A.group_reg_seq_id)';

    IF v_enrol_type_id IS NOT NULL THEN
      SELECT DECODE(v_enrol_type_id,
                    'ING',
                    'IAG',
                    'COR',
                    'CRP',
                    v_enrol_type_id)
        INTO v_type
        FROM dual;
      v_where := v_where || ' AND A.group_general_type_id = :v_type ';
      i := i + 1;
      search_tab(i) := v_type;
    END IF;

    IF v_group_id IS NOT NULL THEN
      v_where := v_where || ' AND A.group_id LIKE :v_group_id';
      i := i + 1;
      search_tab(i) := UPPER(v_group_id) || '%';
    END IF;

    IF v_policy_number IS NOT NULL THEN
      v_where := v_where || ' AND tep.policy_number LIKE :v_policy_number';
      i := i + 1;
      search_tab(i) := UPPER(v_policy_number) || '%';
    END IF;

    IF v_group_name IS NOT NULL THEN
      v_where := v_where || ' AND A.group_name LIKE :v_group_name';
      i := i + 1;
      search_tab(i) := '%' || UPPER(v_group_name) || '%';
    END IF;
    IF v_tpa_office_seq_id IS NOT NULL THEN
      v_where := v_where ||
                 ' AND A.tpa_office_seq_id = :v_tpa_office_seq_id';
      i := i + 1;
      search_tab(i) := v_tpa_office_seq_id;
    END IF;

    IF v_where IS NOT NULL THEN
      v_sql_str := v_sql_str || ' WHERE ' || substr(v_where, 5);
    END IF;

    v_sql_str := 'SELECT * FROM
            (SELECT A.*,DENSE_RANK() OVER (ORDER BY ' ||
                 v_sort_var || ' ' || v_sort_order || ',ROWNUM)
            Q FROM (' || v_sql_str ||
                 ') A ) WHERE  Q>= :v_start_num AND Q<= :v_end_num ';

    IF search_tab.FIRST IS NOT NULL THEN
      CASE search_tab.COUNT
        WHEN 1 THEN
          OPEN result_set FOR v_sql_str
            USING search_tab(1), v_start_num, v_end_num;
        WHEN 2 THEN
          OPEN result_set FOR v_sql_str
            USING search_tab(1), search_tab(2), v_start_num, v_end_num;
        WHEN 3 THEN
          OPEN result_set FOR v_sql_str
            USING search_tab(1), search_tab(2), search_tab(3), v_start_num, v_end_num;
        WHEN 4 THEN
          OPEN result_set FOR v_sql_str
            USING search_tab(1), search_tab(2), search_tab(3), search_tab(4), v_start_num, v_end_num;
        WHEN 5 THEN
          OPEN result_set FOR v_sql_str
            USING search_tab(1), search_tab(2), search_tab(3), search_tab(4), search_tab(5), v_start_num, v_end_num;
        WHEN 6 THEN
          OPEN result_set FOR v_sql_str
            USING search_tab(1), search_tab(2), search_tab(3), search_tab(4), search_tab(5), search_tab(6), v_start_num, v_end_num;
      END CASE;
    ELSE
      OPEN result_set FOR v_sql_str
        USING v_start_num, v_end_num;
    END IF;
  END select_corporate_list;
  --==========================================================================================================================================================================================
  PROCEDURE save_finance_logs(V_FIN_LOG_SEQ_ID    IN FINANCE_LOGS.FIN_LOG_SEQ_ID%TYPE,
                              V_TPA_BATCH_SEQ_ID  IN finance_logs.fin_batch_seq_id%TYPE,
                              V_ERROR_NO          IN FINANCE_LOGS.ERROR_NO%TYPE,
                              V_ERROR_MESSAGE     IN FINANCE_LOGS.ERROR_MESSAGE%TYPE,
                              V_ERROR_TYPE        IN FINANCE_LOGS.ERROR_TYPE%TYPE,
                              V_UPLOAD_TYPE       IN FINANCE_LOGS.UPLOAD_TYPE%TYPE,
                              V_CLM_SETTLEMENT_NO IN FINANCE_LOGS.claim_settlement_no%TYPE,
                              v_policy_no         IN FINANCE_LOGS.policy_number%TYPE,
                              v_enrolment_number  IN FINANCE_LOGS.enrollment_id%TYPE,
                              v_employee_no       IN FINANCE_LOGS.employee_no%TYPE,
                              v_empanel_number    IN FINANCE_LOGS.empanelment_no%TYPE,
					          v_batch_number      IN FINANCE_LOGS.batch_number%TYPE,
                              V_ADDED_BY          IN FINANCE_LOGS.ADDED_BY%TYPE) IS
    PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN
    INSERT INTO FINANCE_LOGS
      (FIN_LOG_SEQ_ID,
       FIN_BATCH_SEQ_ID,
       claim_settlement_no,
       ERROR_LOGGED_DATE,
       ERROR_NO,
       ERROR_MESSAGE,
       ERROR_TYPE,
       UPLOAD_TYPE,
       policy_number,
       enrollment_id,
       employee_no,
       empanelment_no,
	   batch_number,
       ADDED_BY,
       ADDED_DATE)
    VALUES
      (FIN_LOG_SEQ.NEXTVAL,
       V_tpa_batch_seq_id,
       V_CLM_SETTLEMENT_NO,
       SYSDATE,
       v_error_no,
       v_error_message,
       'FIN', ----tariff
       V_UPLOAD_TYPE,
       v_policy_no,
       v_enrolment_number,
       v_employee_no,
       v_empanel_number,
	     v_batch_number,
       V_ADDED_BY,
       SYSDATE);

    COMMIT;

  END save_finance_logs;
  --=========================================================================================================================================================================================    
  -- modified by S.V.SREERAJ -- FOR PERFORMANCE
  -- Modified date : 15-04-2008
  PROCEDURE print_ENBD_check(v_payment_seq_id IN VARCHAR2,
                             v_float_seq_id   IN TPA_FLOAT_ACCOUNT.float_seq_id%TYPE,
                             v_added_by       IN NUMBER,
                             v_batch_date     IN DATE,
                             v_rows_processed OUT INTEGER,
                             v_resultset      OUT SYS_REFCURSOR,
                             v_conresultset   OUT SYS_REFCURSOR,
                             v_file_name      IN VARCHAR2) IS
    v_filename                    VARCHAR2(50);
    v_bank_seq_id                 tpa_bank_master.bank_seq_id%TYPE;
    v_count_of_payments           tpa_claims_payment.payment_seq_id%TYPE;
    v_batch_seq_id                tpa_bank_advice_batch.batch_seq_id%TYPE;
    v_bank_advice_file_name       tpa_bank_advice_batch.bank_advice_file_name%TYPE;
    str_tab                       ttk_util_pkg.str_table_type;
    v_where                       VARCHAR2(32767);
    v_sql_str                     VARCHAR2(32767);
    i                             NUMBER(2) := 0;
    v_tds_str                     VARCHAR2(2000);
    v_consql_str                  VARCHAR2(32767);
    v_claim_seq_id                tpa_claims_payment.claim_seq_id%TYPE;
    v_hosp_seq_id                 tpa_claims_payment.hosp_seq_id%TYPE;
    v_cheque_amount               tpa_claims_payment.approved_amount%TYPE;
    v_appr_amount                 tpa_claims_payment.approved_amount%TYPE;
    v_tds_payment_seq_id          tpa_claims_payment.payment_seq_id%TYPE;
    split_amt_tab                 split_amt_type;
    split_perc_tab                split_amt_type;
    v_exist_yn                    VARCHAR2(1) := 'N';
    v_tpa_nhcp_cheques_issued_to  tpa_claims_payment.tpa_nhcp_cheques_issued_to%TYPE;
    v_unique                      varchar2(50);
    v_Beneficiary_Payment_Details varchar2(4000);
    v_Beneficiary_Bank            varchar2(400);
    v_Beneficiary_name            varchar2(400);
    v_Beneficiary_account_number  varchar2(400);
    v_count                       NUMBER := 0;
    v_count1                      NUMBER;
    v_ac_no                       VARCHAR2(3);
    CURSOR tpa_bank_details IS
      SELECT ad.bank_name,
             ad.account_number,
             ad.branch_name,
             ad.bank_micr,
             ad.bank_ifsc,
             ad.account_type
        FROM fin_app.tpa_account_details ad;
    tpa_rec tpa_bank_details%rowtype; --balley

  BEGIN

    OPEN tpa_bank_details;
    FETCH tpa_bank_details
      INTO tpa_rec;
    CLOSE tpa_bank_details;

    str_tab := ttk_util_pkg.parse_str(v_payment_seq_id);

    SELECT A.bank_seq_id
      INTO v_bank_seq_id
      FROM tpa_bank_accounts a
      JOIN tpa_float_account b
        ON (a.bank_acc_seq_id = b.bank_acc_seq_id)
     WHERE b.float_seq_id = v_float_seq_id;

    IF (str_tab.FIRST IS NOT NULL) THEN
      IF str_tab.COUNT <= 8 THEN
        FOR i in str_tab.FIRST .. str_tab.LAST LOOP
          v_where := v_where || ' OR D.payment_seq_id = :bind_tab_' || i;
        END LOOP;
      ELSE
        v_where := ' OR D.payment_seq_id IN ( ' ||
                   REPLACE(SUBSTR(v_payment_seq_id,
                                  2,
                                  LENGTH(v_payment_seq_id) - 2),
                           '|',
                           ',') || ') ';
      END IF;
    END IF;

    IF v_where IS NOT NULL THEN
      v_where := ' AND (' || substr(v_where, 4) || ')';
    END IF;

    INSERT INTO tpa_bank_advice_batch
      (batch_seq_id,
       batch_date,
       batch_file_no,
       bank_seq_id,
       float_seq_id,
       added_by,
       added_date,
       bank_advice_file_name)
    VALUES
      (bank_advice_batch_seq.NEXTVAL,
       v_batch_date,
       'FILE_NO' || bank_advice_batch_file_seq.NEXTVAL,
       v_bank_seq_id,
       v_float_seq_id,
       v_added_by,
       SYSDATE,
       'DXB' || '_' || TO_CHAR(v_batch_date, 'YYYYMMDD') || '_' ||
       bank_adv_batch_file_name_slno.NEXTVAL)
    RETURNING batch_seq_id, bank_advice_file_name INTO v_batch_seq_id, v_bank_advice_file_name;
    --if bank_type is CITIBANK

    v_tds_str := ' SELECT a.payment_seq_id ,a.claim_seq_id ,a.hosp_seq_id, a.approved_amount, A.tpa_nhcp_cheques_issued_to
      FROM tpa_claims_payment a  WHERE a.float_seq_id = :v_float_seq_id ' ||
                 regexp_replace(v_where, 'D\.', 'A.') ||
                 ' AND a.claim_payment_status  = ''READY_TO_BANK''';

    IF str_tab.FIRST IS NOT NULL THEN
      IF str_tab.COUNT <= 8 THEN
        CASE str_tab.COUNT
          WHEN 1 THEN
            OPEN v_resultset FOR v_tds_str
              USING v_float_seq_id, str_tab(1);
          WHEN 2 THEN
            OPEN v_resultset FOR v_tds_str
              USING v_float_seq_id, str_tab(1), str_tab(2);
          WHEN 3 THEN
            OPEN v_resultset FOR v_tds_str
              USING v_float_seq_id, str_tab(1), str_tab(2), str_tab(3);
          WHEN 4 THEN
            OPEN v_resultset FOR v_tds_str
              USING v_float_seq_id, str_tab(1), str_tab(2), str_tab(3), str_tab(4);
          WHEN 5 THEN
            OPEN v_resultset FOR v_tds_str
              USING v_float_seq_id, str_tab(1), str_tab(2), str_tab(3), str_tab(4), str_tab(5);
          WHEN 6 THEN
            OPEN v_resultset FOR v_tds_str
              USING v_float_seq_id, str_tab(1), str_tab(2), str_tab(3), str_tab(4), str_tab(5), str_tab(6);
          WHEN 7 THEN
            OPEN v_resultset FOR v_tds_str
              USING v_float_seq_id, str_tab(1), str_tab(2), str_tab(3), str_tab(4), str_tab(5), str_tab(6), str_tab(7);
          WHEN 8 THEN
            OPEN v_resultset FOR v_tds_str
              USING v_float_seq_id, str_tab(1), str_tab(2), str_tab(3), str_tab(4), str_tab(5), str_tab(6), str_tab(7), str_tab(8);
        END CASE;
      ELSE
        OPEN v_resultset FOR v_tds_str
          USING v_float_seq_id;
      END IF;
    END IF;
    CLOSE v_resultset;
    v_count_of_payments := str_tab.COUNT;

    v_consql_str := 'select 
 Beneficiary_Bank,
 Beneficiary_name,
 Beneficiary_account_number,
 to_char(wm_concat(Beneficiary_Payment_Details)) as Beneficiary_Payment_Details
  from (select tcp.tpa_cheque_issued_general_type,
               tcp.tpa_nhcp_cheques_issued_to,
               CASE
                 WHEN tcp.claim_type = ''CTM'' THEN
                  (CASE
                    WHEN e.enrol_type_id = ''COR'' THEN
                     (CASE
                       WHEN e.tpa_cheque_issued_general_type = ''IQI'' THEN
                        ttk_util_pkg.fn_decrypt(t.BANK_NAME)
                       WHEN e.tpa_cheque_issued_general_type = ''IQC'' THEN
                        ttk_util_pkg.fn_decrypt(s.BANK_NAME)
                     END)
                    ELSE
                     ttk_util_pkg.fn_decrypt(t.BANK_NAME)
                  END)
                 ELSE
                   CASE ca.pymnt_to_type_id WHEN ''PTN'' THEN ttk_util_pkg.fn_decrypt(pa.bank_name) 
                                           ELSE ttk_util_pkg.fn_decrypt(w.bank_name) 
                   END
               end as Beneficiary_Bank,

               ttk_util_pkg.fn_decrypt(tcp.payee_name) as Beneficiary_name,
               nvl(cc.check_amount,tcp.approved_amount) as Pay_Amount,
               ''QAR'' as Pay_Currency,
               CASE
                 WHEN tcp.claim_type = ''CTM'' THEN
                  (CASE
                    WHEN e.enrol_type_id = ''COR'' THEN
                     (CASE
                       WHEN e.tpa_cheque_issued_general_type = ''IQI'' THEN
                        ttk_util_pkg.fn_decrypt(t.bank_account_no)
                       WHEN e.tpa_cheque_issued_general_type = ''IQC'' THEN
                        ttk_util_pkg.fn_decrypt(S.bank_account_no)
                     END)
                    ELSE
                     ttk_util_pkg.fn_decrypt(t.bank_account_no)
                  END)
                 ELSE
                   CASE ca.pymnt_to_type_id WHEN ''PTN'' THEN ttk_util_pkg.fn_decrypt(pa.account_number) 
                                        ELSE ttk_util_pkg.fn_decrypt(w.account_number) 
                   END
               end as Beneficiary_account_number,
               tcp.claim_settlement_no as Beneficiary_Payment_Details

          from fin_app.tpa_claims_payment tcp
          LEFT OUTER JOIN app.clm_authorization_details ca on (ca.claim_seq_id=tcp.claim_seq_id)
          LEFT OUTER JOIN tpa_enr_policy_member B
            ON (tcp.member_seq_id = B.member_seq_id)
          LEFT OUTER JOIN tpa_enr_policy E
            ON (tcp.policy_seq_id = E.policy_seq_id)
          LEFT OUTER JOIN tpa_enr_policy_group R
            ON (B.policy_group_seq_id = R.policy_group_seq_id)
          LEFT OUTER JOIN tpa_enr_bank_dtls S
            ON (E.bank_seq_id = S.bank_seq_id)
          LEFT OUTER JOIN tpa_enr_bank_dtls T
            ON (R.bank_seq_id = T.bank_seq_id)
          LEFT OUTER JOIN fin_app.tpa_payment_checks_details pcd
            on (tcp.payment_seq_id = pcd.payment_seq_id and pcd.v_csr_flag = 1)
          LEFT OUTER JOIN fin_app.tpa_claims_check cc
            on (pcd.claims_chk_seq_id = cc.claims_chk_seq_id and cc.v_csr_flag = 1)
          LEFT OUTER JOIN fin_app.tpa_float_account tfa
            on (tcp.float_seq_id = tfa.float_seq_id)
          left outer join fin_app.tpa_bank_accounts ba
            on (tfa.bank_acc_seq_id = ba.bank_acc_seq_id)
          LEFT OUTER JOIN tpa_bank_master h
            ON (h.bank_seq_id = ba.bank_seq_id)
          left outer join app.tpa_enr_bank_dtls bd
            on (ba.bank_seq_id = bd.bank_seq_id)
          left outer join APP.TPA_IFSC_CODE_DETAILS fc
            on (bd.branch_seq_id = fc.branch_seq_id)
          LEFT OUTER JOIN tpa_group_registration L
            ON (L.group_reg_seq_id = tcp.group_reg_seq_id)
          LEFT OUTER JOIN cheque_template N
            ON (H.cheque_template_id = N.cheque_template_id)
          LEFT OUTER JOIN tpa_hosp_info O
            ON (tcp.hosp_seq_id = O.hosp_seq_id)
          LEFT OUTER JOIN tpa_hosp_account_details W
            ON (O.hosp_seq_id = w.hosp_seq_id)
          LEFT OUTER JOIN tpa_partner_info pi ON (tcp.ptnr_seq_id=pi.ptnr_seq_id)
          LEFT OUTER JOIN tpa_partner_account_details pa ON (pi.ptnr_seq_id=pa.ptnr_seq_id)
    WHERE tcp.float_seq_id = :v_float_seq_id ' ||
                    regexp_replace(v_where, 'D\.', 'tcp.') ||
                    ' AND tcp.claim_payment_status  = ''READY_TO_BANK'')
 group by Beneficiary_name,
          Beneficiary_Bank,
          Beneficiary_account_number';

    IF str_tab.FIRST IS NOT NULL THEN
      IF str_tab.COUNT <= 8 THEN
        CASE str_tab.COUNT
          WHEN 1 THEN
            OPEN v_conresultset FOR v_consql_str
              USING v_float_seq_id, str_tab(1);
          WHEN 2 THEN
            OPEN v_conresultset FOR v_consql_str
              USING v_float_seq_id, str_tab(1), str_tab(2);
          WHEN 3 THEN
            OPEN v_conresultset FOR v_consql_str
              USING v_float_seq_id, str_tab(1), str_tab(2), str_tab(3);
          WHEN 4 THEN
            OPEN v_conresultset FOR v_consql_str
              USING v_float_seq_id, str_tab(1), str_tab(2), str_tab(3), str_tab(4);
          WHEN 5 THEN
            OPEN v_conresultset FOR v_consql_str
              USING v_float_seq_id, str_tab(1), str_tab(2), str_tab(3), str_tab(4), str_tab(5);
          WHEN 6 THEN
            OPEN v_conresultset FOR v_consql_str
              USING v_float_seq_id, str_tab(1), str_tab(2), str_tab(3), str_tab(4), str_tab(5), str_tab(6);
          WHEN 7 THEN
            OPEN v_conresultset FOR v_consql_str
              USING v_float_seq_id, str_tab(1), str_tab(2), str_tab(3), str_tab(4), str_tab(5), str_tab(6), str_tab(7);
          WHEN 8 THEN
            OPEN v_conresultset FOR v_consql_str
              USING v_float_seq_id, str_tab(1), str_tab(2), str_tab(3), str_tab(4), str_tab(5), str_tab(6), str_tab(7), str_tab(8);
        END CASE;
      ELSE
        OPEN v_conresultset FOR v_consql_str
          USING v_float_seq_id;
      END IF;
    END IF;

    LOOP
      FETCH v_conresultset
        INTO v_Beneficiary_Bank,
             v_Beneficiary_name,
             v_Beneficiary_account_number,
             v_Beneficiary_Payment_Details;
      EXIT WHEN v_conresultset%NOTFOUND OR v_conresultset%NOTFOUND IS NULL;
      execute immediate ' update fin_app.tpa_claims_payment cp set cp.trans_ref_no = ' ||
                        FLOAT_ACCOUNTS_PKG.boa_unique(2) ||
                        ' where cp.claim_settlement_no in (' || '''' ||
                        replace(v_Beneficiary_Payment_Details, ',', ''',''') || '''' || ') ';
    END LOOP;
    CLOSE v_conresultset;

    v_sql_str := 'select rownum as slno,
       case when (CASE WHEN tcp.claim_type=''CTM'' 
                  THEN (CASE WHEN e.enrol_type_id=''COR'' 
                             THEN (CASE WHEN e.tpa_cheque_issued_general_type=''IQI'' 
                                        THEN ttk_util_pkg.fn_decrypt(t.BANK_NAME) 
                                        WHEN e.tpa_cheque_issued_general_type=''IQC'' 
                                        THEN ttk_util_pkg.fn_decrypt(s.BANK_NAME) END) 
                             ELSE ttk_util_pkg.fn_decrypt(t.BANK_NAME) END) 
                  ELSE 
                    CASE ca.pymnt_to_type_id WHEN ''PTN'' THEN ttk_util_pkg.fn_decrypt(pa.bank_name) 
                                        ELSE ttk_util_pkg.fn_decrypt(w.bank_name) 
                    END
            end) = ''Emirates NBD'' THEN ''TR''
   Else ''OB'' end as pay_mode,
       CASE WHEN tcp.claim_type=''CTM'' 
                  THEN (CASE WHEN e.enrol_type_id=''COR'' 
                             THEN (CASE WHEN e.tpa_cheque_issued_general_type=''IQI'' 
                                        THEN ttk_util_pkg.fn_decrypt(t.BANK_NAME) 
                                        WHEN e.tpa_cheque_issued_general_type=''IQC'' 
                                        THEN ttk_util_pkg.fn_decrypt(s.BANK_NAME) END) 
                             ELSE ttk_util_pkg.fn_decrypt(t.BANK_NAME) END) 
                  ELSE 
                    CASE ca.pymnt_to_type_id WHEN ''PTN'' THEN ttk_util_pkg.fn_decrypt(pa.bank_name) 
                                        ELSE ttk_util_pkg.fn_decrypt(w.bank_name) 
                    END
            end as Beneficiary_Bank,

       ttk_util_pkg.fn_decrypt(tcp.payee_name) as Beneficiary_name,
       nvl(cc.check_amount,tcp.approved_amount) as Pay_Amount,
       ''QAR'' as Pay_Currency,
        CASE WHEN tcp.claim_type=''CTM'' THEN
         (CASE WHEN e.enrol_type_id=''COR'' THEN
          (CASE WHEN e.tpa_cheque_issued_general_type=''IQI'' THEN ttk_util_pkg.fn_decrypt(t.bank_account_no)
           WHEN e.tpa_cheque_issued_general_type=''IQC'' THEN ttk_util_pkg.fn_decrypt(S.bank_account_no) 
           END)
         ELSE ttk_util_pkg.fn_decrypt(t.bank_account_no) END)
          ELSE 
            CASE ca.pymnt_to_type_id WHEN ''PTN'' THEN ttk_util_pkg.fn_decrypt(pa.account_number) 
                                        ELSE ttk_util_pkg.fn_decrypt(w.account_number) 
            END
          end as Beneficiary_account_number,

       tcp.address1||tcp.address2||tcp.address3 as Beneficiary_Address,
       CASE WHEN tcp.claim_type=''CTM'' THEN
              (CASE WHEN e.enrol_type_id=''COR'' THEN (CASE WHEN e.tpa_cheque_issued_general_type=''IQI'' THEN ttk_util_pkg.fn_decrypt(ema.email_id)
              WHEN e.tpa_cheque_issued_general_type=''IQC'' THEN l.notify_email_id end)
              ELSE ttk_util_pkg.fn_decrypt(ema.email_id) END)ELSE ttk_util_pkg.fn_decrypt(o.primary_email_id) END as Bene_Email_Id,
       tcp.claim_settlement_no as Beneficiary_Payment_Details,
       null as Payable_Country,
       null as BeneBank_BIC_Code,
       ' || v_batch_seq_id ||
                 ' as Route_Code,
       null as Sort_Code,
       null as SWIFT_Code, 
       null as Charge_type,
       null as Transaction_Type,
       null as Payment_Type,
       null as Payment_Link,
       to_char(tcp.trans_ref_no) as Transaction_Reference,
       null as Account_debit_date
 from fin_app.tpa_claims_payment tcp 
 LEFT OUTER JOIN app.clm_authorization_details ca on (ca.claim_seq_id=tcp.claim_seq_id)
LEFT OUTER JOIN tpa_enr_policy_member B ON(tcp.member_seq_id = B.member_seq_id)
LEFT OUTER JOIN tpa_enr_policy E ON(tcp.policy_seq_id = E.policy_seq_id )
LEFT OUTER JOIN tpa_enr_policy_group R ON(B.policy_group_seq_id=R.policy_group_seq_id)
LEFT OUTER JOIN TPA_ENR_MEM_ADDRESS EMA ON (b.enr_address_seq_id = ema.enr_address_seq_id)
LEFT OUTER JOIN tpa_enr_bank_dtls S ON(E.bank_seq_id=S.bank_seq_id)
LEFT OUTER JOIN tpa_enr_bank_dtls T ON(R.bank_seq_id=T.bank_seq_id)
LEFT OUTER JOIN fin_app.tpa_payment_checks_details pcd on (tcp.payment_seq_id = pcd.payment_seq_id and pcd.v_csr_flag = 1)
LEFT OUTER JOIN fin_app.tpa_claims_check cc on (pcd.claims_chk_seq_id = cc.claims_chk_seq_id and cc.v_csr_flag = 1)
LEFT OUTER JOIN fin_app.tpa_float_account tfa on (tcp.float_seq_id = tfa.float_seq_id)
left outer join fin_app.tpa_bank_accounts ba on (tfa.bank_acc_seq_id = ba.bank_acc_seq_id)
LEFT OUTER JOIN tpa_bank_master  h ON (h.bank_seq_id = ba.bank_seq_id)
left outer join app.tpa_enr_bank_dtls bd on (ba.bank_seq_id = bd.bank_seq_id)
left outer join APP.TPA_IFSC_CODE_DETAILS fc on (bd.branch_seq_id = fc.branch_seq_id)
LEFT OUTER JOIN tpa_group_registration L ON (L.group_reg_seq_id = tcp.group_reg_seq_id)
LEFT OUTER JOIN cheque_template N ON (H.cheque_template_id = N.cheque_template_id)
LEFT OUTER JOIN tpa_hosp_info O ON (tcp.hosp_seq_id=O.hosp_seq_id)
LEFT OUTER JOIN tpa_hosp_account_details W ON(O.hosp_seq_id=w.hosp_seq_id)
LEFT OUTER JOIN tpa_partner_info pi ON (tcp.ptnr_seq_id=pi.ptnr_seq_id)
LEFT OUTER JOIN tpa_partner_account_details pa ON (pi.ptnr_seq_id=pa.ptnr_seq_id)
WHERE tcp.float_seq_id = :v_float_seq_id ' ||
                 regexp_replace(v_where, 'D\.', 'tcp.') ||
                 ' AND tcp.claim_payment_status  = ''READY_TO_BANK''';

    IF v_where IS NOT NULL THEN
      v_where := ' AND (' || substr(v_where, 4) || ')';
    END IF;

    IF str_tab.FIRST IS NOT NULL THEN
      IF str_tab.COUNT <= 8 THEN
        CASE str_tab.COUNT
          WHEN 1 THEN
            OPEN v_resultset FOR v_sql_str
              USING v_float_seq_id, str_tab(1);
          WHEN 2 THEN
            OPEN v_resultset FOR v_sql_str
              USING v_float_seq_id, str_tab(1), str_tab(2);
          WHEN 3 THEN
            OPEN v_resultset FOR v_sql_str
              USING v_float_seq_id, str_tab(1), str_tab(2), str_tab(3);
          WHEN 4 THEN
            OPEN v_resultset FOR v_sql_str
              USING v_float_seq_id, str_tab(1), str_tab(2), str_tab(3), str_tab(4);
          WHEN 5 THEN
            OPEN v_resultset FOR v_sql_str
              USING v_float_seq_id, str_tab(1), str_tab(2), str_tab(3), str_tab(4), str_tab(5);
          WHEN 6 THEN
            OPEN v_resultset FOR v_sql_str
              USING v_float_seq_id, str_tab(1), str_tab(2), str_tab(3), str_tab(4), str_tab(5), str_tab(6);
          WHEN 7 THEN
            OPEN v_resultset FOR v_sql_str
              USING v_float_seq_id, str_tab(1), str_tab(2), str_tab(3), str_tab(4), str_tab(5), str_tab(6), str_tab(7);
          WHEN 8 THEN
            OPEN v_resultset FOR v_sql_str
              USING v_float_seq_id, str_tab(1), str_tab(2), str_tab(3), str_tab(4), str_tab(5), str_tab(6), str_tab(7), str_tab(8);
        END CASE;
      ELSE
        OPEN v_resultset FOR v_tds_str
          USING v_float_seq_id;
      END IF;
    END IF;

    IF v_where IS NOT NULL THEN
      v_where := ' AND (' || substr(v_where, 8);
    END IF;

    v_consql_str :=  --- ENBD
      'select 
    tpa_cheque_issued_general_type,
    case when BANK_NAME IN (''EMIRATES NBD'', ''EMIRATES ISLAMIC BANK'') THEN
      ''TR''
    else
      ''OB''
    end as pay_mode,
    Beneficiary_Bank,
     substr(Beneficiary_name, 1, 60) as Beneficiary_name,
     --to_char(sum(pay_amount), ''9999999D00'') as pay_amount,
     pay_amount,
     count(Beneficiary_Payment_Details) as no_of_claims,
     Pay_Currency,
     Beneficiary_account_number,
     REGEXP_REPLACE(REPLACE(Beneficiary_Address, '','','' ''), ''[^ A-Za-z0-9]'') as Beneficiary_Address,
     Bene_Email_Id,
     Beneficiary_Country as Beneficiary_Country,
     Beneficiary_Payment_Details,
     null Payable_Country,
     null as BeneBank_BIC_Code,
     null/*Route_Code*/ as Route_Code,
     null as Sort_Code,
     null as SWIFT_Code,
     null as Charge_type,
     null as Transaction_Type,
     null as Payment_Type,
     null as Payment_Link,
     to_char(wm_concat(distinct Transaction_Reference)) as Transaction_Reference,
     null as Account_debit_date
      from (select tcp.tpa_cheque_issued_general_type,
                   tcp.tpa_nhcp_cheques_issued_to,
                   /*CASE
                     WHEN tcp.claim_type = ''CTM'' THEN
                      (CASE
                        WHEN e.enrol_type_id = ''COR'' THEN
                         (CASE
                           WHEN e.tpa_cheque_issued_general_type = ''IQI'' THEN
                            ttk_util_pkg.fn_decrypt(fc.bank_id)
                           WHEN e.tpa_cheque_issued_general_type = ''IQC'' THEN
                            ttk_util_pkg.fn_decrypt(fc.bank_id)
                         END)
                        ELSE
                         ttk_util_pkg.fn_decrypt(fc.bank_id)
                      END)
                     ELSE
                      ttk_util_pkg.fn_decrypt(fc.bank_id)
                   end*/
                   h.bank_id as Beneficiary_Bank,
                   UPPER(h.BANK_NAME) AS BANK_NAME,
                   NVL(o.hosp_name, clh.hosp_name) as Beneficiary_name,
                   nvl(cc.check_amount,tcp.approved_amount) as Pay_Amount,
                   ''QAR'' as Pay_Currency,
                   CASE
                     WHEN tcp.claim_type = ''CTM'' THEN
                      (CASE
                        WHEN e.enrol_type_id = ''COR'' THEN
                         (CASE
                           WHEN e.tpa_cheque_issued_general_type = ''IQI'' THEN
                            ttk_util_pkg.fn_decrypt(w.bank_ifsc)
                           WHEN e.tpa_cheque_issued_general_type = ''IQC'' THEN
                            ttk_util_pkg.fn_decrypt(w.bank_ifsc)
                         END)
                        ELSE
                         ttk_util_pkg.fn_decrypt(w.bank_ifsc)
                      END)
                     ELSE
                      ttk_util_pkg.fn_decrypt(w.bank_ifsc)
                   end as Beneficiary_account_number,

                   tha.address_1 || tha.address_2 || tha.address_3 as Beneficiary_Address,
                   ttk_util_pkg.fn_decrypt(o.primary_email_id) as Bene_Email_Id,
                   ''Batch No. '||v_batch_seq_id/*tcp.batch_number_manual*/||' Unique Trans Ref. ''||tcp.trans_ref_no as Beneficiary_Payment_Details,
                   --null as Payable_Country,
                   null as BeneBank_BIC_Code,
                   --'||v_batch_seq_id||' as Route_Code,
                   null as Route_Code,
                   null as Sort_Code,
                   null as SWIFT_Code,
                   to_char(2) as Charge_type,
                   null as Transaction_Type,
                   null as Payment_Type,
                   null as Payment_Link,
                   tcp.trans_ref_no as Transaction_Reference,
                   null as Account_debit_date,
                   ''Qatar'' as Beneficiary_Country
  from fin_app.tpa_claims_payment tcp
  LEFT OUTER JOIN tpa_enr_policy_member B
    ON (tcp.member_seq_id = B.member_seq_id)
  LEFT OUTER JOIN tpa_enr_policy E
    ON (tcp.policy_seq_id = E.policy_seq_id)
  LEFT OUTER JOIN tpa_enr_policy_group R
    ON (B.policy_group_seq_id = R.policy_group_seq_id)
  LEFT OUTER JOIN tpa_enr_bank_dtls S
    ON (E.bank_seq_id = S.bank_seq_id)
  LEFT OUTER JOIN tpa_enr_bank_dtls T
    ON (R.bank_seq_id = T.bank_seq_id)
  LEFT OUTER JOIN fin_app.tpa_payment_checks_details pcd
    on (tcp.payment_seq_id = pcd.payment_seq_id and pcd.v_csr_flag = 1)
  LEFT OUTER JOIN fin_app.tpa_claims_check cc
    on (pcd.claims_chk_seq_id = cc.claims_chk_seq_id and cc.v_csr_flag = 1)
  LEFT OUTER JOIN fin_app.tpa_float_account tfa
    on (tcp.float_seq_id = tfa.float_seq_id)
  /*left outer join fin_app.tpa_bank_accounts ba
    on (tfa.bank_acc_seq_id = ba.bank_acc_seq_id)*/

-------------------------------------
  LEFT JOIN app.clm_authorization_details clm
    ON (clm.claim_seq_id = tcp.claim_seq_id)
  LEFT JOIN app.clm_hospital_details clh
    ON (clh.claim_seq_id = clm.claim_seq_id)
  LEFT OUTER JOIN tpa_hosp_info O
    ON (clh.hosp_seq_id = O.hosp_seq_id)
  LEFT JOIN app.tpa_hosp_address tha
    ON (tha.hosp_seq_id = o.hosp_seq_id)
  LEFT JOIN app.tpa_hosp_account_details bd
    ON (bd.hosp_seq_id = clh.hosp_seq_id)


  LEFT OUTER JOIN tpa_bank_master h
    ON (h.bank_seq_id = bd.bank_seq_id)

  LEFT OUTER JOIN tpa_group_registration L
    ON (L.group_reg_seq_id = tcp.group_reg_seq_id)
  LEFT OUTER JOIN cheque_template N
    ON (H.cheque_template_id = N.cheque_template_id)
  LEFT OUTER JOIN tpa_hosp_info O
            ON (tcp.hosp_seq_id = O.hosp_seq_id)	
  LEFT OUTER JOIN tpa_hosp_account_details W
    ON (O.hosp_seq_id = w.hosp_seq_id)
  LEFT OUTER JOIN tpa_partner_info pi ON (tcp.ptnr_seq_id=pi.ptnr_seq_id)
  LEFT OUTER JOIN tpa_partner_account_details pa ON (pi.ptnr_seq_id=pa.ptnr_seq_id)
    WHERE tcp.float_seq_id = :v_float_seq_id '|| regexp_replace(v_where,'D\.','tcp.')||' AND tcp.claim_payment_status  = ''READY_TO_BANK'')
    group by Beneficiary_name,
          Beneficiary_Bank,
          Pay_Currency,
          Beneficiary_account_number,
          Beneficiary_Address,
          Bene_Email_Id,
          tpa_cheque_issued_general_type,
          Route_Code,
          BANK_NAME,
          Beneficiary_Payment_Details,
          pay_amount,
          Beneficiary_Country';

   ---ENBD CHECK PRINT

    IF str_tab.FIRST IS NOT NULL THEN
      IF str_tab.COUNT <= 8 THEN
        CASE str_tab.COUNT
          WHEN 1 THEN
            OPEN v_conresultset FOR v_consql_str
              USING v_float_seq_id, str_tab(1);
          WHEN 2 THEN
            OPEN v_conresultset FOR v_consql_str
              USING v_float_seq_id, str_tab(1), str_tab(2);
          WHEN 3 THEN
            OPEN v_conresultset FOR v_consql_str
              USING v_float_seq_id, str_tab(1), str_tab(2), str_tab(3);
          WHEN 4 THEN
            OPEN v_conresultset FOR v_consql_str
              USING v_float_seq_id, str_tab(1), str_tab(2), str_tab(3), str_tab(4);
          WHEN 5 THEN
            OPEN v_conresultset FOR v_consql_str
              USING v_float_seq_id, str_tab(1), str_tab(2), str_tab(3), str_tab(4), str_tab(5);
          WHEN 6 THEN
            OPEN v_conresultset FOR v_consql_str
              USING v_float_seq_id, str_tab(1), str_tab(2), str_tab(3), str_tab(4), str_tab(5), str_tab(6);
          WHEN 7 THEN
            OPEN v_conresultset FOR v_consql_str
              USING v_float_seq_id, str_tab(1), str_tab(2), str_tab(3), str_tab(4), str_tab(5), str_tab(6), str_tab(7);
          WHEN 8 THEN
            OPEN v_conresultset FOR v_consql_str
              USING v_float_seq_id, str_tab(1), str_tab(2), str_tab(3), str_tab(4), str_tab(5), str_tab(6), str_tab(7), str_tab(8);
        END CASE;
      ELSE
        OPEN v_conresultset FOR v_consql_str
          USING v_float_seq_id;
      END IF;
    END IF;

    v_rows_processed := str_tab.last;
    COMMIT;

      /*SELECT substr(b.account_number, -3) into v_ac_no
      FROM tpa_float_account A
      JOIN tpa_bank_accounts B ON (A.bank_acc_seq_id = B.bank_acc_seq_id)
      where a.float_seq_id = v_float_seq_id;*/

      --v_filename := 'ENBD'||'-'||v_ac_no||'-'||to_char(sysdate, 'DDMMYYYY-HH12MISS')||'-'||1;
    IF substr(v_file_name, 1, 4) = 'ENBD' THEN
      v_filename := v_file_name||'-1';
    ELSE
      v_filename := 'ENBD' || '-' ||
                  TO_CHAR(v_batch_date, 'DDMMYYYY-HH24MISS') || '-' ||
                  v_added_by;
    END IF;

    UPDATE tpa_bank_advice_batch A
       SET A.no_of_transactions = v_count_of_payments,
           A.file_name          = v_filename,
           A.updated_date       = SYSDATE,
           a.updated_by         = v_added_by
     WHERE batch_seq_id = v_batch_seq_id;

    --update the status to sent_to_bank to the respective claims.
    IF str_tab.FIRST IS NOT NULL THEN
      FORALL i IN str_tab.FIRST .. str_tab.LAST
        UPDATE tpa_claims_payment a
           SET A.claim_payment_status = 'SENT_TO_BANK',
               A.bank_advice_batch    = bank_advice_batch_seq.CURRVAL,
               A.updated_date         = SYSDATE,
               a.updated_by           = v_added_by

         WHERE payment_seq_id = TO_NUMBER(str_tab(i));

         UPDATE tpa_claims_payment t
         SET t.enbd_gen_count = 1
         WHERE t.float_seq_id = v_float_seq_id;
    END IF;

    v_rows_processed := str_tab.last;

 commit;

 END print_ENBD_check;
  --=============================================================================================
  PROCEDURE print_ENBD_Consolidated_check(v_payment_seq_id IN VARCHAR2,
                                          v_float_seq_id   IN TPA_FLOAT_ACCOUNT.float_seq_id%TYPE,
                                          v_added_by       IN NUMBER,
                                          v_batch_date     IN DATE,
                                          v_rows_processed OUT INTEGER,
                                          v_resultset      OUT SYS_REFCURSOR) IS

    v_filename                   VARCHAR2(50);
    v_bank_seq_id                tpa_bank_master.bank_seq_id%TYPE;
    v_count_of_payments          tpa_claims_payment.payment_seq_id%TYPE;
    v_batch_seq_id               tpa_bank_advice_batch.batch_seq_id%TYPE;
    v_bank_advice_file_name      tpa_bank_advice_batch.bank_advice_file_name%TYPE;
    str_tab                      ttk_util_pkg.str_table_type;
    v_where                      VARCHAR2(2000);
    v_sql_str                    VARCHAR2(32767);
    i                            NUMBER(2) := 0;
    v_tds_str                    VARCHAR2(2000);
    v_claim_seq_id               tpa_claims_payment.claim_seq_id%TYPE;
    v_hosp_seq_id                tpa_claims_payment.hosp_seq_id%TYPE;
    v_cheque_amount              tpa_claims_payment.approved_amount%TYPE;
    v_appr_amount                tpa_claims_payment.approved_amount%TYPE;
    v_tds_payment_seq_id         tpa_claims_payment.payment_seq_id%TYPE;
    split_amt_tab                split_amt_type;
    split_perc_tab               split_amt_type;
    v_exist_yn                   VARCHAR2(1) := 'N';
    v_tpa_nhcp_cheques_issued_to tpa_claims_payment.tpa_nhcp_cheques_issued_to%TYPE;
    v_unique                     varchar2(50);

    CURSOR tpa_bank_details IS
      SELECT ad.bank_name,
             ad.account_number,
             ad.branch_name,
             ad.bank_micr,
             ad.bank_ifsc,
             ad.account_type
        FROM fin_app.tpa_account_details ad;
    tpa_rec tpa_bank_details%rowtype; --balley

  BEGIN

    OPEN tpa_bank_details;
    FETCH tpa_bank_details
      INTO tpa_rec;
    CLOSE tpa_bank_details;

    str_tab := ttk_util_pkg.parse_str(v_payment_seq_id);

    SELECT A.bank_seq_id
      INTO v_bank_seq_id
      FROM tpa_bank_accounts a
      JOIN tpa_float_account b
        ON (a.bank_acc_seq_id = b.bank_acc_seq_id)
     WHERE b.float_seq_id = v_float_seq_id;

    IF (str_tab.FIRST IS NOT NULL) THEN
      IF str_tab.COUNT <= 8 THEN
        FOR i in str_tab.FIRST .. str_tab.LAST LOOP
          v_where := v_where || ' OR D.payment_seq_id = :bind_tab_' || i;
        END LOOP;
      ELSE
        v_where := ' OR D.payment_seq_id IN ( ' ||
                   REPLACE(SUBSTR(v_payment_seq_id,
                                  2,
                                  LENGTH(v_payment_seq_id) - 2),
                           '|',
                           ',') || ') ';
      END IF;
    END IF;

    IF v_where IS NOT NULL THEN
      v_where := ' AND (' || substr(v_where, 4) || ')';
    END IF;
    v_tds_str := ' SELECT a.payment_seq_id ,a.claim_seq_id ,a.hosp_seq_id, a.approved_amount, A.tpa_nhcp_cheques_issued_to
      FROM tpa_claims_payment a  WHERE a.float_seq_id = :v_float_seq_id ' ||
                 regexp_replace(v_where, 'D\.', 'A.') ||
                 ' AND a.claim_payment_status  = ''READY_TO_BANK''';

    IF str_tab.FIRST IS NOT NULL THEN
      IF str_tab.COUNT <= 8 THEN
        CASE str_tab.COUNT
          WHEN 1 THEN
            OPEN v_resultset FOR v_tds_str
              USING v_float_seq_id, str_tab(1);
          WHEN 2 THEN
            OPEN v_resultset FOR v_tds_str
              USING v_float_seq_id, str_tab(1), str_tab(2);
          WHEN 3 THEN
            OPEN v_resultset FOR v_tds_str
              USING v_float_seq_id, str_tab(1), str_tab(2), str_tab(3);
          WHEN 4 THEN
            OPEN v_resultset FOR v_tds_str
              USING v_float_seq_id, str_tab(1), str_tab(2), str_tab(3), str_tab(4);
          WHEN 5 THEN
            OPEN v_resultset FOR v_tds_str
              USING v_float_seq_id, str_tab(1), str_tab(2), str_tab(3), str_tab(4), str_tab(5);
          WHEN 6 THEN
            OPEN v_resultset FOR v_tds_str
              USING v_float_seq_id, str_tab(1), str_tab(2), str_tab(3), str_tab(4), str_tab(5), str_tab(6);
          WHEN 7 THEN
            OPEN v_resultset FOR v_tds_str
              USING v_float_seq_id, str_tab(1), str_tab(2), str_tab(3), str_tab(4), str_tab(5), str_tab(6), str_tab(7);
          WHEN 8 THEN
            OPEN v_resultset FOR v_tds_str
              USING v_float_seq_id, str_tab(1), str_tab(2), str_tab(3), str_tab(4), str_tab(5), str_tab(6), str_tab(7), str_tab(8);
        END CASE;
      ELSE
        OPEN v_resultset FOR v_tds_str
          USING v_float_seq_id;
      END IF;
    END IF;
    CLOSE v_resultset;
    v_count_of_payments := str_tab.COUNT;

    v_sql_str := 'select 
    tpa_cheque_issued_general_type,
    case when Beneficiary_Bank = ''Emirates NBD'' THEN ''TR''
   Else ''OB'' end as pay_mode,
 Beneficiary_Bank,
 Beneficiary_name,
 sum(pay_amount) as pay_amount,
 count(Beneficiary_Payment_Details) as no_of_claims,
 Pay_Currency,
 Beneficiary_account_number,
 Beneficiary_Address,
 Bene_Email_Id,
 to_char(wm_concat(Beneficiary_Payment_Details)) as Beneficiary_Payment_Details,
 length(to_char(wm_concat(Beneficiary_Payment_Details))),
 null as Payable_Country,
 null as BeneBank_BIC_Code,
 Route_Code as Route_Code,
 null as Sort_Code,
 null as SWIFT_Code,
 null as Charge_type,
 null as Transaction_Type,
 null as Payment_Type,
 null as Payment_Link,
 FLOAT_ACCOUNTS_PKG.boa_unique(2) as Transaction_Reference,
 null as Account_debit_date
  from (select tcp.tpa_cheque_issued_general_type,
               tcp.tpa_nhcp_cheques_issued_to,
               CASE
                 WHEN tcp.claim_type = ''CTM'' THEN
                  (CASE
                    WHEN e.enrol_type_id = ''COR'' THEN
                     (CASE
                       WHEN e.tpa_cheque_issued_general_type = ''IQI'' THEN
                        ttk_util_pkg.fn_decrypt(t.BANK_NAME)
                       WHEN e.tpa_cheque_issued_general_type = ''IQC'' THEN
                        ttk_util_pkg.fn_decrypt(s.BANK_NAME)
                     END)
                    ELSE
                     ttk_util_pkg.fn_decrypt(t.BANK_NAME)
                  END)
                 ELSE
                  ttk_util_pkg.fn_decrypt(W.BANK_NAME)
               end as Beneficiary_Bank,

               ttk_util_pkg.fn_decrypt(tcp.payee_name) as Beneficiary_name,
               nvl(cc.check_amount,tcp.approved_amount) as Pay_Amount,
               ''QAR'' as Pay_Currency,
               CASE
                 WHEN tcp.claim_type = ''CTM'' THEN
                  (CASE
                    WHEN e.enrol_type_id = ''COR'' THEN
                     (CASE
                       WHEN e.tpa_cheque_issued_general_type = ''IQI'' THEN
                        ttk_util_pkg.fn_decrypt(t.bank_account_no)
                       WHEN e.tpa_cheque_issued_general_type = ''IQC'' THEN
                        ttk_util_pkg.fn_decrypt(S.bank_account_no)
                     END)
                    ELSE
                     ttk_util_pkg.fn_decrypt(t.bank_account_no)
                  END)
                 ELSE
                  ttk_util_pkg.fn_decrypt(W.account_number)
               end as Beneficiary_account_number,

               tcp.address1 || tcp.address2 || tcp.address3 as Beneficiary_Address,
               null as Bene_Email_Id,
               tcp.claim_settlement_no as Beneficiary_Payment_Details,
               null as Payable_Country,
               null as BeneBank_BIC_Code,
               tcp.bank_advice_batch as Route_Code,
               --null as Route_Code,
               null as Sort_Code,
               null as SWIFT_Code,
               null as Charge_type,
               null as Transaction_Type,
               null as Payment_Type,
               null as Payment_Link,
               null as Transaction_Reference,
               null as Account_debit_date
          from fin_app.tpa_claims_payment tcp
          LEFT OUTER JOIN tpa_enr_policy_member B
            ON (tcp.member_seq_id = B.member_seq_id)
          LEFT OUTER JOIN tpa_enr_policy E
            ON (tcp.policy_seq_id = E.policy_seq_id)
          LEFT OUTER JOIN tpa_enr_policy_group R
            ON (B.policy_group_seq_id = R.policy_group_seq_id)
          LEFT OUTER JOIN tpa_enr_bank_dtls S
            ON (E.bank_seq_id = S.bank_seq_id)
          LEFT OUTER JOIN tpa_enr_bank_dtls T
            ON (R.bank_seq_id = T.bank_seq_id)
          LEFT OUTER JOIN fin_app.tpa_payment_checks_details pcd
            on (tcp.payment_seq_id = pcd.payment_seq_id and pcd.v_csr_flag = 1)
          LEFT OUTER JOIN fin_app.tpa_claims_check cc
            on (pcd.claims_chk_seq_id = cc.claims_chk_seq_id and cc.v_csr_flag = 1)
          LEFT OUTER JOIN fin_app.tpa_float_account tfa
            on (tcp.float_seq_id = tfa.float_seq_id)
          left outer join fin_app.tpa_bank_accounts ba
            on (tfa.bank_acc_seq_id = ba.bank_acc_seq_id)
          LEFT OUTER JOIN tpa_bank_master h
            ON (h.bank_seq_id = ba.bank_seq_id)
          left outer join app.tpa_enr_bank_dtls bd
            on (ba.bank_seq_id = bd.bank_seq_id)
          left outer join APP.TPA_IFSC_CODE_DETAILS fc
            on (bd.branch_seq_id = fc.branch_seq_id)
          LEFT OUTER JOIN tpa_group_registration L
            ON (L.group_reg_seq_id = tcp.group_reg_seq_id)
          LEFT OUTER JOIN cheque_template N
            ON (H.cheque_template_id = N.cheque_template_id)
          LEFT OUTER JOIN tpa_hosp_info O
            ON (tcp.hosp_seq_id = O.hosp_seq_id)
          LEFT OUTER JOIN tpa_hosp_account_details W
            ON (O.hosp_seq_id = w.hosp_seq_id)
    WHERE tcp.float_seq_id = :v_float_seq_id ' ||
                 regexp_replace(v_where, 'D\.', 'tcp.') ||
                 ' AND tcp.claim_payment_status  = ''READY_TO_BANK'')
 group by Beneficiary_name,
          Beneficiary_Bank,
          Pay_Currency,
          Beneficiary_account_number,
          Beneficiary_Address,
          Bene_Email_Id,
          tpa_cheque_issued_general_type,
          Route_Code';

    IF v_where IS NOT NULL THEN
      v_where := ' AND (' || substr(v_where, 4) || ')';
    END IF;
    IF str_tab.FIRST IS NOT NULL THEN
      IF str_tab.COUNT <= 8 THEN
        CASE str_tab.COUNT
          WHEN 1 THEN
            OPEN v_resultset FOR v_sql_str
              USING v_float_seq_id, str_tab(1);
          WHEN 2 THEN
            OPEN v_resultset FOR v_sql_str
              USING v_float_seq_id, str_tab(1), str_tab(2);
          WHEN 3 THEN
            OPEN v_resultset FOR v_sql_str
              USING v_float_seq_id, str_tab(1), str_tab(2), str_tab(3);
          WHEN 4 THEN
            OPEN v_resultset FOR v_sql_str
              USING v_float_seq_id, str_tab(1), str_tab(2), str_tab(3), str_tab(4);
          WHEN 5 THEN
            OPEN v_resultset FOR v_sql_str
              USING v_float_seq_id, str_tab(1), str_tab(2), str_tab(3), str_tab(4), str_tab(5);
          WHEN 6 THEN
            OPEN v_resultset FOR v_sql_str
              USING v_float_seq_id, str_tab(1), str_tab(2), str_tab(3), str_tab(4), str_tab(5), str_tab(6);
          WHEN 7 THEN
            OPEN v_resultset FOR v_sql_str
              USING v_float_seq_id, str_tab(1), str_tab(2), str_tab(3), str_tab(4), str_tab(5), str_tab(6), str_tab(7);
          WHEN 8 THEN
            OPEN v_resultset FOR v_sql_str
              USING v_float_seq_id, str_tab(1), str_tab(2), str_tab(3), str_tab(4), str_tab(5), str_tab(6), str_tab(7), str_tab(8);
        END CASE;
      ELSE
        OPEN v_resultset FOR v_tds_str
          USING v_float_seq_id;
      END IF;
    END IF;

    /* IF str_tab.FIRST IS NOT NULL THEN
      FORALL i IN str_tab.FIRST..str_tab.LAST
        UPDATE tpa_claims_payment a SET
              A.claim_payment_status = 'SENT_TO_BANK',
              A.bank_advice_batch    = bank_advice_batch_seq.CURRVAL ,
              A.updated_date         = SYSDATE,
              a.updated_by           = v_added_by
              WHERE payment_seq_id = TO_NUMBER(str_tab(i));
    END IF;  */
    v_rows_processed := str_tab.last;
    COMMIT;
  END print_ENBD_Consolidated_check;
  --========================================================================================================================
  -- Update File Name with increment by 1 after download ENBD/DETAIL/NORMAL file in VIEW PAYMENT DETAILS
  --------------------------------------------------------------------------------------------------- 
  PROCEDURE count_enbd_list (p_float_seq_id IN NUMBER,
                             p_file_name    IN VARCHAR2
                            )
  AS
    v_cnt   NUMBER;
    v_count VARCHAR2(5);
    v_ac_no VARCHAR2(3);
    v_file_name VARCHAR2(50);
    v_name      VARCHAR2(40);

    CURSOR file_cur(v_file_name VARCHAR2) IS
      select t.file_name, t.batch_seq_id, t.updated_date
      from tpa_bank_advice_batch t
      where t.file_name  = v_file_name
      and t.float_seq_id = p_float_seq_id;

    chk_file_name file_cur%ROWTYPE;

  BEGIN
    IF instr(p_file_name,'-', 1, 5) != 0 THEN
      v_file_name := substr(p_file_name,1, (instr(p_file_name,'-', 1, 5)-1));
    ELSE
      v_file_name := p_file_name;
    END IF;

    OPEN file_cur (v_file_name);
    FETCH file_cur INTO chk_file_name;
    CLOSE file_cur;

    IF v_file_name = chk_file_name.file_name THEN

      select substr(file_name, 26) INTO v_count
      from tpa_bank_advice_batch
      where file_name  = v_file_name; 


        v_cnt := to_number(v_count) + 1;

        update tpa_bank_advice_batch a
        set file_name = substr(file_name,1, 25)||to_char(v_cnt),
            updated_date = to_date(sysdate, 'DD-MM-RRRR')
        where file_name = v_file_name
        and float_seq_id = p_float_seq_id
        and batch_seq_id = chk_file_name.batch_seq_id
        returning file_name into v_name;
    END IF;

    commit;

  END count_enbd_list; 
--==================================================================================================
--Added for Finance Payment Softcopy Upload 
--added on 30-01-2018  
--venu babu
--===============================================================================================
PROCEDURE payment_upload_details (v_claim_settlement_no IN VARCHAR2,
                                  v_float_seq_id        IN TPA_FLOAT_ACCOUNT.float_seq_id%TYPE,
                                  v_currency_type       IN VARCHAR2,
                                  v_payment_method      IN TPA_CLAIMS_PAYMENT.payee_type%TYPE,
                                  v_payment_to          IN  VARCHAR2,
                                  v_rows_processed      OUT INTEGER,
                                  v_result              OUT SYS_REFCURSOR)
  IS
  str_tab               ttk_util_pkg.str_table_type := ttk_util_pkg.parse_str(v_claim_settlement_no);
  
   CURSOR chk_setlmnt_no( v_settlement_number clm_authorization_details.settlement_number%type,
                          v_float_seq_id      TPA_FLOAT_ACCOUNT.float_seq_id%TYPE,
                          v_currency_type     clm_authorization_details.currency_type%TYPE ) 
          is
          select count(1) from  tpa_claims_payment a
          JOIN CLM_AUTHORIZATION_DETAILS B ON (A.CLAIM_SEQ_ID=B.CLAIM_SEQ_ID)
          where a.claim_settlement_no=  v_settlement_number 
          and a.float_seq_id=v_float_seq_id
          AND b.req_amt_currency_type = v_currency_type ;  
    
   CURSOR chk_setlmnt_no_any_curr( v_settlement_number clm_authorization_details.settlement_number%type,
                          	     v_float_seq_id      TPA_FLOAT_ACCOUNT.float_seq_id%TYPE)
          is
          select count(1) from  tpa_claims_payment a
          where a.claim_settlement_no= v_settlement_number
          and a.float_seq_id=v_float_seq_id
           ;
          
   CURSOR tpa_bank_details IS
        SELECT ad.account_number, ad.bank_ifsc
        FROM fin_app.tpa_account_details ad;
    
  cursor chk_payment_status ( v_settlement_number clm_authorization_details.settlement_number%type) is
       SELECT COUNT(1) 
             FROM tpa_claims_payment A
             WHERE claim_payment_status = 'PENDING' AND 
             A.CLAIM_SETTLEMENT_NO= v_settlement_number ;
                      
cursor settlement_payment_status ( v_settlement_number clm_authorization_details.settlement_number%type)is
       SELECT a.claim_payment_status 
       FROM tpa_claims_payment A 
       WHERE A.CLAIM_SETTLEMENT_NO= v_settlement_number ;      
                       
CURSOR Get_dup_count (v_batch number) is
      select SETTELMENT_NO,count(1)
      from FIN_APP.FIN_APP_TEMP_TABLE where batch_number=v_batch
      group by SETTELMENT_NO
      having count(1)>1;


        
v_sql_str                        VARCHAR2(32767);
v_claim_settlement_no1           VARCHAR2(32767);
v_out                            VARCHAR2(32767);
v_str                            VARCHAR2(32767);
v_tpa_account_no                 VARCHAR2(100);
v_tpa_ifsc                       VARCHAR2(60);
i                                NUMBER(10) := 0;
v_payment_seq_id_list            VARCHAR2(32767);
v_cnt                            NUMBER(10);
v_msg                            VARCHAR2(1000);
v_settlement_no_status           VARCHAR2(100);
v_batch_number                   NUMBER(30):=0;
v_count                          NUMBER(20);
v_settel_ment                    NUMBER(30);
type dup_settelement_numbers is table oF Get_dup_count%ROWTYPE INDEX BY BINARY_INTEGER;
duplicate_count dup_settelement_numbers;
BEGIN  
  
 delete from fin_app.fin_app_temp_table where added_date<sysdate ;
  
 v_batch_number :=fin_app.payment_batch_log.nextval;

IF str_tab.FIRST IS NOT NULL THEN
  
    FORALL  i IN str_tab.FIRST .. str_tab.LAST   
        
      insert into fin_app.fin_app_temp_table (SETTELMENT_NO,BATCH_NUMBER,ADDED_DATE)
          values 
       ( str_tab(i),v_batch_number,sysdate);
   
    open Get_dup_count(v_batch_number);
      fetch Get_dup_count bulk collect into duplicate_count;
        close Get_dup_count;
   
END IF;

       IF str_tab.FIRST IS NOT NULL THEN
         IF v_currency_type='ANY' THEN
            FOR  i IN str_tab.FIRST .. str_tab.LAST LOOP          
               open chk_setlmnt_no_any_curr(str_tab(i),v_float_seq_id);
               fetch chk_setlmnt_no_any_curr into v_cnt;
               close chk_setlmnt_no_any_curr;
               
            IF v_cnt>0 THEN  
                  open chk_payment_status(str_tab(i));
                  fetch chk_payment_status into v_cnt;
                  close chk_payment_status;
                IF v_cnt = 1 then          
                  v_msg:='SUCCESS';
                    v_claim_settlement_no1:=v_claim_settlement_no1||'|'||str_tab(i);
                 ELSE
                  open settlement_payment_status(str_tab(i));
                  fetch settlement_payment_status into v_settlement_no_status;
                  close settlement_payment_status;  
                 if v_settlement_no_status='PAID' then 
                 v_msg:='SETTLEMENT NUMBER ALREADY PAID';
                 else 
                 v_msg:='SETTLEMENT NUMBER UNDER  '||v_settlement_no_status;
                 end if;  
                END IF;
              
             ELSE
                v_msg:='SETTLEMENT NUMBER NOT LINKED TO THIS FLOAT OR CURRENCY TYPE IS NOT MATCHING';
            END IF;
        
          INSERT INTO fin_app.BATCH_UPLOAD_ERROR_LOG(ERROR_LOG_SEQ_ID,BATCH_NUMBER,SETTELMENT_NUMBER,PAYEE_TYPE,added_date,ERROR_MESG)
            VALUES (fin_app.batch_upload_seq.NEXTVAL,v_batch_number,str_tab(i),v_payment_method,sysdate,v_msg);
        
        END loop;
        
        ELSE
            FOR  i IN str_tab.FIRST .. str_tab.LAST LOOP          
               open chk_setlmnt_no(str_tab(i),v_float_seq_id,v_currency_type);
               fetch chk_setlmnt_no into v_cnt;
               close chk_setlmnt_no;
               
          
          IF v_cnt>0 THEN  
                open chk_payment_status(str_tab(i));
                fetch chk_payment_status into v_cnt;
                close chk_payment_status;
              IF v_cnt = 1 then          
                v_msg:='SUCCESS';
                  v_claim_settlement_no1:=v_claim_settlement_no1||'|'||str_tab(i);
               ELSE
                open settlement_payment_status(str_tab(i));
                fetch settlement_payment_status into v_settlement_no_status;
                close settlement_payment_status;  
               if v_settlement_no_status='PAID' then 
               v_msg:='SETTLEMENT NUMBER ALREADY PAID';
               else 
               v_msg:='SETTLEMENT NUMBER UNDER  '||v_settlement_no_status;
               end if;  
              END IF;
            
           ELSE
              v_msg:='SETTLEMENT NUMBER NOT LINKED TO THIS FLOAT OR CURRENCY TYPE IS NOT MATCHING';
          END IF;
        
          INSERT INTO fin_app.BATCH_UPLOAD_ERROR_LOG(ERROR_LOG_SEQ_ID,BATCH_NUMBER,SETTELMENT_NUMBER,PAYEE_TYPE,added_date,ERROR_MESG)
            VALUES (fin_app.batch_upload_seq.NEXTVAL,v_batch_number,str_tab(i),v_payment_method,sysdate,v_msg);
        
        END loop;
      END IF;
        
         V_OUT:=v_claim_settlement_no1||'|';
         
         v_rows_processed:=v_batch_number;
         
        IF  duplicate_count.count>0  then     
              for i in duplicate_count.first..duplicate_count.last loop
              
              update fin_app.Batch_Upload_Error_Log e 
              set ERROR_MESG='DUPLICATE CLAIM SETTELEMENT NUMBER'
              where rowid NOT IN (select max(rowid) 
                                    from fin_app.Batch_Upload_Error_Log 
                                    where BATCH_NUMBER=v_batch_number and 
                                    ERROR_MESG='SUCCESS' and SETTELMENT_NUMBER in (select t.SETTELMENT_NO
                                                                                from fin_app.fin_app_temp_table t
                                                                                  where batch_number=v_batch_number )
                                    group by SETTELMENT_NUMBER,ERROR_MESG
                                    having count(1)>1) and e.ERROR_MESG='SUCCESS' and e.BATCH_NUMBER=v_batch_number
                                    AND SETTELMENT_NUMBER=duplicate_count(I).SETTELMENT_NO ;
               
              update fin_app.Batch_Upload_Error_Log e 
              set ERROR_MESG='DUPLICATE CLAIM SETTELEMENT NUMBER'
              where rowid NOT IN (select max(rowid) 
                                    from fin_app.Batch_Upload_Error_Log 
                                    where BATCH_NUMBER=v_batch_number and 
                                    ERROR_MESG like 'SETTLEMENT NUMBER ALREADY PAID%' and SETTELMENT_NUMBER in (select t.SETTELMENT_NO
                                                                                from fin_app.fin_app_temp_table t
                                                                                where batch_number=v_batch_number)
                                    group by SETTELMENT_NUMBER,ERROR_MESG
                                    having count(1)>1) and e.ERROR_MESG like 'SETTLEMENT NUMBER ALREADY PAID%' and e.BATCH_NUMBER=v_batch_number
                                    AND SETTELMENT_NUMBER=duplicate_count(I).SETTELMENT_NO ;
             
              update fin_app.Batch_Upload_Error_Log e 
              set ERROR_MESG='DUPLICATE CLAIM SETTELEMENT NUMBER'
              where rowid NOT IN (select max(rowid) 
                                    from fin_app.Batch_Upload_Error_Log 
                                    where BATCH_NUMBER=v_batch_number and 
                                    ERROR_MESG like 'SETTLEMENT NUMBER NOT LINKED TO THIS FLOAT OR CURRENCY TYPE IS NOT MATCHING%' and SETTELMENT_NUMBER in (select t.SETTELMENT_NO
                                                                                from fin_app.fin_app_temp_table t
                                                                                where batch_number=v_batch_number)
                                    group by SETTELMENT_NUMBER,ERROR_MESG
                                    having count(1)>1) and e.ERROR_MESG like 'SETTLEMENT NUMBER NOT LINKED TO THIS FLOAT OR CURRENCY TYPE IS NOT MATCHING%' and e.BATCH_NUMBER=v_batch_number 
                                    AND SETTELMENT_NUMBER=duplicate_count(I).SETTELMENT_NO;   
                                                     
              update fin_app.Batch_Upload_Error_Log e 
              set ERROR_MESG='DUPLICATE CLAIM SETTELEMENT NUMBER'
              where rowid NOT IN (select max(rowid) 
                                    from fin_app.Batch_Upload_Error_Log 
                                    where BATCH_NUMBER=v_batch_number and 
                                    ERROR_MESG like 'SETTLEMENT NUMBER UNDER%' and SETTELMENT_NUMBER in (select t.SETTELMENT_NO
                                                                                from fin_app.fin_app_temp_table t
                                                                                where batch_number=v_batch_number)
                                    group by SETTELMENT_NUMBER,ERROR_MESG
                                    having count(1)>1) and e.ERROR_MESG like 'SETTLEMENT NUMBER UNDER%' and e.BATCH_NUMBER=v_batch_number 
                                    AND SETTELMENT_NUMBER=duplicate_count(I).SETTELMENT_NO;        
              
                                  
              end loop;
         commit;
         END IF;
         
            
          v_payment_seq_id_list  := replace (replace('('''||REPLACE(SUBSTR(V_OUT,2,
                                          LENGTH(v_claim_settlement_no)-2) ,'|',''',''')||''')',')',''),'(','');
        
        END IF;
    v_sql_str:= 'SELECT  gd.req_amt_currency_type ,
       trunc(gd.CONVERTED_FINAL_APPROVED_AMT,2) CONVERTED_FINAL_APPROVED_AMT,
       A.payment_seq_id,
        A.claim_settlement_no,
        B.tpa_enrollment_id,
        B.mem_name,
        K.description  AS claim_type,
        A.claim_aprv_date,
        ttk_util_pkg.fn_decrypt(a.payee_name) as in_favour_of,
        a.approved_amount,
        F.current_balance,
        H.bank_name AS HO,
        J.bank_name AS BO,
        M.office_code ,
        W.REVIEW_YN as REVIEW_YN,
        N.template_name,
        o.tds_process_yn,
        L.GROUP_NAME AS corporate_name,
        GD.CLM_RECEIVED_DATE AS CLAIM_RECV_DATE,
        CASE WHEN a.claim_type=''CTM'' /*AND nvl(gd.pay_to_general_type_id,''MBR'')!=''HSL'' */THEN
        --CASE WHEN a.tpa_nhcp_cheques_issued_to=''TPA'' THEN ''' ||
                 v_tpa_account_no ||
                 ''' ELSE
         (CASE WHEN e.enrol_type_id=''COR'' THEN
          (CASE WHEN e.tpa_cheque_issued_general_type=''IQI'' THEN ttk_util_pkg.fn_decrypt(t.bank_account_no)
           WHEN e.tpa_cheque_issued_general_type=''IQC'' THEN ttk_util_pkg.fn_decrypt(S.bank_account_no)
           END)
         ELSE ttk_util_pkg.fn_decrypt(t.bank_account_no) END)
          --END  as account_num,
          ELSE ttk_util_pkg.fn_decrypt(W.account_number) end as account_num,

        CASE WHEN a.claim_type=''CTM''/* AND nvl(gd.pay_to_general_type_id,''MBR'')!=''HSL''*/ THEN --added for hyundai requirement
        --CASE WHEN a.tpa_nhcp_cheques_issued_to=''TPA'' THEN ''' ||
                 v_tpa_ifsc ||
                 ''' ELSE
        (CASE WHEN e.enrol_type_id=''COR'' THEN (CASE WHEN e.tpa_cheque_issued_general_type=''IQI'' THEN ttk_util_pkg.fn_decrypt(t.bank_ifsc)
        WHEN e.tpa_cheque_issued_general_type=''IQC'' THEN ttk_util_pkg.fn_decrypt(S.bank_ifsc) END)
         ELSE ttk_util_pkg.fn_decrypt(t.bank_ifsc) END)--END as ifsc
        ELSE  ttk_util_pkg.fn_decrypt(W.bank_ifsc) end as ifsc,
        CASE WHEN '''||v_payment_to||'''=''USD'' THEN  nvl(gd.pay_amt_in_usd,0) 
             WHEN '''||v_payment_to||'''=''GBP'' THEN  nvl(gd.PAY_AMT_IN_GBP,0)
             WHEN '''||v_payment_to||'''=''EUR'' THEN  nvl(gd.PAY_AMT_IN_EURO,0) END  
          as USD_AMOUNT,
          CASE WHEN A.HOSP_SEQ_ID is not null then o.Payment_Dur_Agr 
               WHEN A.PTNR_SEQ_ID is not null then pi.Payment_Dur_Agr end Payment_Dur_Agr ,
         '''||v_payment_to ||''' as Selected_currency,
         (to_date(SYSDATE,''dd-mm-yyyy'') - to_date(gd.clm_received_date,''dd-mm-yyyy'')) AS claim_age,
         CASE WHEN round(sysdate - clm_received_date) <= fa.FST_TO_DAYS then  round((a.approved_amount* fa.DISC_PERC)/100,2 ) else 0 end as DISC_AMOUNT,
             CASE WHEN round(sysdate - clm_received_date) <= fa.FST_TO_DAYS then A.approved_amount - round((a.approved_amount* fa.DISC_PERC)/100,2 ) else A.approved_amount end  as AMT_PAID_AF_DISC
        FROM tpa_claims_payment A JOIN tpa_enr_policy_member B ON(A.member_seq_id = B.member_seq_id)
        JOIN clm_authorization_details gd on (gd.claim_seq_id=a.claim_seq_id)--added for hyundai requirement
        JOIN tpa_enr_policy E ON(A.policy_seq_id = E.policy_seq_id )
        JOIN tpa_float_account F ON(A.float_seq_id = F.float_seq_id)
        JOIN tpa_bank_accounts g ON(f.bank_acc_seq_id = g.bank_acc_seq_id)
        JOIN tpa_bank_master  h ON (h.bank_seq_id = g.bank_seq_id)
        LEFT OUTER JOIN (SELECT bank_SEQ_ID FROM tpa_bank_master ) I ON(i.bank_seq_id = H.ho_id)
        LEFT OUTER JOIN tpa_bank_master J ON (J.bank_seq_id = I.bank_seq_id)
        JOIN tpa_general_code K ON (K.general_type_id = A.claim_type)
        LEFT OUTER JOIN tpa_group_registration L ON (L.group_reg_seq_id = A.group_reg_seq_id)
        LEFT OUTER JOIN tpa_office_info M ON (M.Tpa_Office_Seq_Id=g.tpa_office_seq_id)
        LEFT OUTER JOIN cheque_template N ON (H.cheque_template_id = N.cheque_template_id)
        LEFT OUTER JOIN tpa_enr_policy_group R ON(B.policy_group_seq_id=R.policy_group_seq_id)
        LEFT OUTER JOIN tpa_enr_bank_dtls S ON(E.bank_seq_id=S.bank_seq_id)
        LEFT OUTER JOIN tpa_enr_bank_dtls T ON(R.bank_seq_id=T.bank_seq_id)
        LEFT OUTER JOIN tpa_hosp_info O ON(a.hosp_seq_id=O.hosp_seq_id)
        LEFT OUTER JOIN tpa_hosp_account_details W ON(O.hosp_seq_id=w.hosp_seq_id)
        LEFT OUTER JOIN tpa_partner_info pi on (pi.Ptnr_Seq_Id=a.Ptnr_Seq_Id)
        LEFT OUTER JOIN APP.TPA_FASTTRACT_DISC_DETAILS FA ON (FA.HOSP_SEQ_ID=a.HOSP_SEQ_ID AND FA.DISC_MODE=''FAST''
        AND FA.STATUS=''ACT'' AND gd.DATE_OF_HOSPITALIZATION between fa.START_DATE and fa.end_date)
        where a.float_seq_id='||v_float_seq_id||' and a.claim_settlement_no in ('||v_payment_seq_id_list||')
              AND a.claim_payment_status=''PENDING'''; 
        
        OPEN v_result FOR v_sql_str;
        
        
END  payment_upload_details;
--==================================================================================================
procedure batch_log
       (v_indate   in varchar2,
        v_outdate  in varchar2,
        v_flag     in varchar2,      --P --payment-- A --PAYMENT ADVICE-- D--DEBIT NOTE
        v_result   out sys_refcursor)
is
begin  
IF v_flag='P' THEN 
open v_result for 
select batch_number as log_batch_number,settelment_number,payee_type,to_char(added_date,'DD-MM-YYYY') added_date,error_mesg 
        from fin_app.BATCH_UPLOAD_ERROR_LOG
where  trunc(ADDED_DATE) between to_date(v_indate,'dd/mm/yyyy') and to_date(v_outdate,'dd/mm/yyyy')
order by added_date desc;
ELSIF v_flag='PA' THEN 
open v_result for 
select batch_number as log_batch_number,settelment_number,payee_type,to_char(added_date,'DD-MM-YYYY') added_date,error_mesg
       from fin_app.PAYMENT_ERROR_LOG
where  trunc(ADDED_DATE) between to_date(v_indate,'dd/mm/yyyy') and to_date(v_outdate,'dd/mm/yyyy')
order by added_date desc;
END IF;
END batch_log;
--===============================================================================
--Added for Finance Payment Advice Softcopy Upload 
--added on 30-01-2018
--venu babu
--====================================================================================
/*PROCEDURE payment_advice_upload_details(
                             v_claim_settlement_no IN VARCHAR2,
                             v_float_seq_id   IN TPA_FLOAT_ACCOUNT.float_seq_id%TYPE,
                             v_added_by       IN NUMBER,
                             v_batch_date     IN DATE,
                             v_currency_type  IN clm_authorization_details.currency_type%TYPE,
                             v_rows_processed OUT INTEGER,
                             v_resultset      OUT SYS_REFCURSOR,
                             v_conresultset   OUT SYS_REFCURSOR,
                             v_file_name      IN VARCHAR2) IS
    v_filename                    VARCHAR2(50);
    v_bank_seq_id                 tpa_bank_master.bank_seq_id%TYPE;
    v_count_of_payments           tpa_claims_payment.payment_seq_id%TYPE;
    v_batch_seq_id                tpa_bank_advice_batch.batch_seq_id%TYPE;
    v_bank_advice_file_name       tpa_bank_advice_batch.bank_advice_file_name%TYPE;
    str_tab                       ttk_util_pkg.str_table_type;
    v_where                       VARCHAR2(32767);
    v_sql_str                     VARCHAR2(32767);
    i                             NUMBER(2) := 0;
    v_tds_str                     VARCHAR2(32767);
    v_consql_str                  VARCHAR2(32767);
    v_claim_seq_id                tpa_claims_payment.claim_seq_id%TYPE;
    v_hosp_seq_id                 tpa_claims_payment.hosp_seq_id%TYPE;
    v_cheque_amount               tpa_claims_payment.approved_amount%TYPE;
    v_appr_amount                 tpa_claims_payment.approved_amount%TYPE;
    v_tds_payment_seq_id          tpa_claims_payment.payment_seq_id%TYPE;
    TYPE split_amt_type IS TABLE OF NUMBER INDEX BY VARCHAR2(3);
    split_amt_tab                 split_amt_type;
    split_perc_tab                split_amt_type;
    v_exist_yn                    VARCHAR2(1) := 'N';
    v_tpa_nhcp_cheques_issued_to  tpa_claims_payment.tpa_nhcp_cheques_issued_to%TYPE;
    v_unique                      varchar2(50);
    v_Beneficiary_Payment_Details varchar2(4000);
    v_Beneficiary_Bank            varchar2(400);
    v_Beneficiary_name            varchar2(400);
    v_Beneficiary_account_number  varchar2(400);
    v_count                       NUMBER := 0;
    v_count1                      NUMBER;
    v_ac_no                       VARCHAR2(3);
    v_settlement_no_status        varchar2(100);
    CURSOR tpa_bank_details IS
      SELECT ad.bank_name,
             ad.account_number,
             ad.branch_name,
             ad.bank_micr,
             ad.bank_ifsc,
             ad.account_type
        FROM fin_app.tpa_account_details ad;
    tpa_rec tpa_bank_details%rowtype; --balley

   CURSOR chk_setlmnt_no( v_settlement_number clm_authorization_details.settlement_number%type,
                        v_float_seq_id   TPA_FLOAT_ACCOUNT.float_seq_id%TYPE,
                        v_currency_type clm_authorization_details.currency_type%TYPE ) 
          is
          select count(*) from  tpa_claims_payment a
          join APP.CLM_AUTHORIZATION_DETAILS b on(a.claim_seq_id=b.claim_seq_id)
          where a.claim_settlement_no= v_settlement_number 
          and a.float_seq_id=v_float_seq_id
          AND b.req_amt_currency_type = v_currency_type;   
    v_cnt number;
    v_msg varchar2(1000);
    
     cursor chk_payment_status ( v_settlement_number clm_authorization_details.settlement_number%type) 
                     is
                     SELECT COUNT(*) FROM tpa_claims_payment A
                      WHERE claim_payment_status in ( 'READY_TO_BANK') AND 
                      A.CLAIM_SETTLEMENT_NO=v_settlement_number;
                      

cursor settlement_payment_status 
( v_settlement_number clm_authorization_details.settlement_number%type)
is
SELECT a.claim_payment_status FROM tpa_claims_payment A 
WHERE A.CLAIM_SETTLEMENT_NO=v_settlement_number;                       
  
  BEGIN
      
    OPEN tpa_bank_details;
    FETCH tpa_bank_details
      INTO tpa_rec;
    CLOSE tpa_bank_details;
  
    str_tab := ttk_util_pkg.parse_str(v_claim_settlement_no);
                IF str_tab.COUNT > 500 THEN
                   RAISE_APPLICATION_ERROR(-20837, 'Maximum selection allowed is 500. ');
                END IF;
  
    SELECT A.bank_seq_id
      INTO v_bank_seq_id
      FROM tpa_bank_accounts a
      JOIN tpa_float_account b
        ON (a.bank_acc_seq_id = b.bank_acc_seq_id)
     WHERE b.float_seq_id = v_float_seq_id;
  
    IF (str_tab.FIRST IS NOT NULL) THEN
      IF str_tab.COUNT <= 8 THEN
        FOR i in str_tab.FIRST .. str_tab.LAST LOOP
          v_where := v_where || ' OR D.claim_settlement_no = :bind_tab_' || i;
        END LOOP;
      ELSE
        v_where := ' OR D.claim_settlement_no IN ( ' ||
                   replace (replace('('''||REPLACE(SUBSTR(v_claim_settlement_no,2,
                                          LENGTH(v_claim_settlement_no)-2) ,'|',''',''')||''')',')',''),'(','') || ') ';
      END IF;
    END IF;
  
    IF v_where IS NOT NULL THEN
      v_where := ' AND (' || substr(v_where, 4) || ')';
    END IF;
  
    INSERT INTO tpa_bank_advice_batch
      (batch_seq_id,
       batch_date,
       batch_file_no,
       bank_seq_id,
       float_seq_id,
       added_by,
       added_date,
       bank_advice_file_name)
    VALUES
      (bank_advice_batch_seq.NEXTVAL,
       v_batch_date,
       'FILE_NO' || bank_advice_batch_file_seq.NEXTVAL,
       v_bank_seq_id,
       v_float_seq_id,
       v_added_by,
       SYSDATE,
       'DXB' || '_' || TO_CHAR(v_batch_date, 'YYYYMMDD') || '_' ||
       bank_adv_batch_file_name_slno.NEXTVAL)
    RETURNING batch_seq_id, bank_advice_file_name INTO v_batch_seq_id, v_bank_advice_file_name;
    --if bank_type is CITIBANK
  
    v_tds_str := ' SELECT a.payment_seq_id ,a.claim_seq_id ,a.hosp_seq_id, a.approved_amount, A.tpa_nhcp_cheques_issued_to
      FROM tpa_claims_payment a  WHERE a.float_seq_id = :v_float_seq_id ' ||
                 regexp_replace(v_where, 'D\.', 'A.') ||
                 ' AND a.claim_payment_status  = ''READY_TO_BANK''';
  
    IF str_tab.FIRST IS NOT NULL THEN
      IF str_tab.COUNT <= 8 THEN
        CASE str_tab.COUNT
          WHEN 1 THEN
            OPEN v_resultset FOR v_tds_str
              USING v_float_seq_id, str_tab(1);
          WHEN 2 THEN
            OPEN v_resultset FOR v_tds_str
              USING v_float_seq_id, str_tab(1), str_tab(2);
          WHEN 3 THEN
            OPEN v_resultset FOR v_tds_str
              USING v_float_seq_id, str_tab(1), str_tab(2), str_tab(3);
          WHEN 4 THEN
            OPEN v_resultset FOR v_tds_str
              USING v_float_seq_id, str_tab(1), str_tab(2), str_tab(3), str_tab(4);
          WHEN 5 THEN
            OPEN v_resultset FOR v_tds_str
              USING v_float_seq_id, str_tab(1), str_tab(2), str_tab(3), str_tab(4), str_tab(5);
          WHEN 6 THEN
            OPEN v_resultset FOR v_tds_str
              USING v_float_seq_id, str_tab(1), str_tab(2), str_tab(3), str_tab(4), str_tab(5), str_tab(6);
          WHEN 7 THEN
            OPEN v_resultset FOR v_tds_str
              USING v_float_seq_id, str_tab(1), str_tab(2), str_tab(3), str_tab(4), str_tab(5), str_tab(6), str_tab(7);
          WHEN 8 THEN
            OPEN v_resultset FOR v_tds_str
              USING v_float_seq_id, str_tab(1), str_tab(2), str_tab(3), str_tab(4), str_tab(5), str_tab(6), str_tab(7), str_tab(8);
        END CASE;
      ELSE
        OPEN v_resultset FOR v_tds_str
          USING v_float_seq_id;
      END IF;
    END IF;
    CLOSE v_resultset;
    v_count_of_payments := str_tab.COUNT;
  
    v_consql_str := 'select 
                     Beneficiary_Bank,
                     Beneficiary_name,
                     Beneficiary_account_number,
                     wm_concat(Beneficiary_Payment_Details) as Beneficiary_Payment_Details
                     from (select tcp.tpa_cheque_issued_general_type,
                     tcp.tpa_nhcp_cheques_issued_to,
                     CASE
                     WHEN tcp.claim_type = ''CTM'' THEN
                          (CASE
                            WHEN e.enrol_type_id = ''COR'' THEN
                                (CASE
                                   WHEN e.tpa_cheque_issued_general_type = ''IQI'' THEN
                                    ttk_util_pkg.fn_decrypt(t.BANK_NAME)
                                   WHEN e.tpa_cheque_issued_general_type = ''IQC'' THEN
                                     ttk_util_pkg.fn_decrypt(s.BANK_NAME)
                                  END)
                            ELSE
                             ttk_util_pkg.fn_decrypt(t.BANK_NAME)
                            END)
                    ELSE
                     ttk_util_pkg.fn_decrypt(W.BANK_NAME)
                    end as Beneficiary_Bank,
               
                    ttk_util_pkg.fn_decrypt(tcp.payee_name) as Beneficiary_name,
                    nvl(cc.check_amount,tcp.approved_amount) as Pay_Amount,
                    ''QAR'' as Pay_Currency,
                    CASE
                     WHEN tcp.claim_type = ''CTM'' THEN
                          (CASE
                            WHEN e.enrol_type_id = ''COR'' THEN
                                 (CASE
                                   WHEN e.tpa_cheque_issued_general_type = ''IQI'' THEN
                                    ttk_util_pkg.fn_decrypt(t.bank_account_no)
                                   WHEN e.tpa_cheque_issued_general_type = ''IQC'' THEN
                                    ttk_util_pkg.fn_decrypt(S.bank_account_no)
                                  END)
                         ELSE
                            ttk_util_pkg.fn_decrypt(t.bank_account_no)
                         END)
                 ELSE
                  ttk_util_pkg.fn_decrypt(W.account_number)
                 end as Beneficiary_account_number,
                 tcp.claim_settlement_no as Beneficiary_Payment_Details
              
            from fin_app.tpa_claims_payment tcp
            LEFT OUTER JOIN tpa_enr_policy_member B ON (tcp.member_seq_id = B.member_seq_id)
            LEFT OUTER JOIN tpa_enr_policy E ON (tcp.policy_seq_id = E.policy_seq_id)
            LEFT OUTER JOIN tpa_enr_policy_group R ON (B.policy_group_seq_id = R.policy_group_seq_id)
            LEFT OUTER JOIN tpa_enr_bank_dtls S ON (E.bank_seq_id = S.bank_seq_id)
            LEFT OUTER JOIN tpa_enr_bank_dtls T ON (R.bank_seq_id = T.bank_seq_id)
            LEFT OUTER JOIN fin_app.tpa_payment_checks_details pcd on (tcp.payment_seq_id = pcd.payment_seq_id and pcd.v_csr_flag = 1)
            LEFT OUTER JOIN fin_app.tpa_claims_check cc on (pcd.claims_chk_seq_id = cc.claims_chk_seq_id and cc.v_csr_flag = 1)
            LEFT OUTER JOIN fin_app.tpa_float_account tfa on (tcp.float_seq_id = tfa.float_seq_id)
            left outer join fin_app.tpa_bank_accounts ba on (tfa.bank_acc_seq_id = ba.bank_acc_seq_id)
            LEFT OUTER JOIN tpa_bank_master h ON (h.bank_seq_id = ba.bank_seq_id)
            left outer join app.tpa_enr_bank_dtls bd on (ba.bank_seq_id = bd.bank_seq_id)
            left outer join APP.TPA_IFSC_CODE_DETAILS fc on (bd.branch_seq_id = fc.branch_seq_id)
            LEFT OUTER JOIN tpa_group_registration L ON (L.group_reg_seq_id = tcp.group_reg_seq_id)
            LEFT OUTER JOIN cheque_template N ON (H.cheque_template_id = N.cheque_template_id)
            LEFT OUTER JOIN tpa_hosp_info O ON (tcp.hosp_seq_id = O.hosp_seq_id)
            LEFT OUTER JOIN tpa_hosp_account_details W ON (O.hosp_seq_id = w.hosp_seq_id)
      WHERE tcp.float_seq_id = :v_float_seq_id ' ||
                      regexp_replace(v_where, 'D\.', 'tcp.') ||
                      ' AND tcp.claim_payment_status  = ''READY_TO_BANK'')
   group by Beneficiary_name,
            Beneficiary_Bank,
            Beneficiary_account_number';
  
    IF str_tab.FIRST IS NOT NULL THEN
      IF str_tab.COUNT <= 8 THEN
        CASE str_tab.COUNT
          WHEN 1 THEN
            OPEN v_conresultset FOR v_consql_str
              USING v_float_seq_id, str_tab(1);
          WHEN 2 THEN
            OPEN v_conresultset FOR v_consql_str
              USING v_float_seq_id, str_tab(1), str_tab(2);
          WHEN 3 THEN
            OPEN v_conresultset FOR v_consql_str
              USING v_float_seq_id, str_tab(1), str_tab(2), str_tab(3);
          WHEN 4 THEN
            OPEN v_conresultset FOR v_consql_str
              USING v_float_seq_id, str_tab(1), str_tab(2), str_tab(3), str_tab(4);
          WHEN 5 THEN
            OPEN v_conresultset FOR v_consql_str
              USING v_float_seq_id, str_tab(1), str_tab(2), str_tab(3), str_tab(4), str_tab(5);
          WHEN 6 THEN
            OPEN v_conresultset FOR v_consql_str
              USING v_float_seq_id, str_tab(1), str_tab(2), str_tab(3), str_tab(4), str_tab(5), str_tab(6);
          WHEN 7 THEN
            OPEN v_conresultset FOR v_consql_str
              USING v_float_seq_id, str_tab(1), str_tab(2), str_tab(3), str_tab(4), str_tab(5), str_tab(6), str_tab(7);
          WHEN 8 THEN
            OPEN v_conresultset FOR v_consql_str
              USING v_float_seq_id, str_tab(1), str_tab(2), str_tab(3), str_tab(4), str_tab(5), str_tab(6), str_tab(7), str_tab(8);
        END CASE;
      ELSE
        OPEN v_conresultset FOR v_consql_str
          USING v_float_seq_id;
      END IF;
    END IF;
  
    LOOP
      FETCH v_conresultset
        INTO v_Beneficiary_Bank,
             v_Beneficiary_name,
             v_Beneficiary_account_number,
             v_Beneficiary_Payment_Details;
      EXIT WHEN v_conresultset%NOTFOUND OR v_conresultset%NOTFOUND IS NULL;
       execute immediate ' update fin_app.tpa_claims_payment cp set cp.trans_ref_no = ' ||
                        FLOAT_ACCOUNTS_PKG.boa_unique(2) ||
                        ' where cp.claim_settlement_no in (' || '''' ||
                        replace(v_Beneficiary_Payment_Details, ',', ''',''') || '''' || ') ';
                        
                        COMMIT;
    END LOOP;
   
    CLOSE v_conresultset;
  
    v_sql_str := 'select rownum as slno,
                    case when 
                          (CASE WHEN tcp.claim_type=''CTM'' THEN
                                (CASE WHEN e.enrol_type_id=''COR'' THEN
                                      (CASE WHEN e.tpa_cheque_issued_general_type=''IQI'' THEN
                                                 ttk_util_pkg.fn_decrypt(t.BANK_NAME) 
                                            WHEN e.tpa_cheque_issued_general_type=''IQC'' THEN 
                                                 ttk_util_pkg.fn_decrypt(s.BANK_NAME) 
                                            END) 
                                 ELSE 
                                      ttk_util_pkg.fn_decrypt(t.BANK_NAME) END) 
                                 ELSE ttk_util_pkg.fn_decrypt(W.BANK_NAME) 
                                 end) = ''Emirates NBD'' THEN ''TR''
                                 Else 
                                   ''OB''
                    end as pay_mode,
                  CASE WHEN tcp.claim_type=''CTM'' THEN
                        (CASE WHEN e.enrol_type_id=''COR'' THEN
                                  (CASE WHEN e.tpa_cheque_issued_general_type=''IQI'' THEN
                                               ttk_util_pkg.fn_decrypt(t.BANK_NAME) 
                                        WHEN e.tpa_cheque_issued_general_type=''IQC'' THEN
                                               ttk_util_pkg.fn_decrypt(s.BANK_NAME) 
                                   END) 
                         ELSE 
                           ttk_util_pkg.fn_decrypt(t.BANK_NAME) 
                         END) 
                  ELSE 
                    ttk_util_pkg.fn_decrypt(W.BANK_NAME) 
                  end as Beneficiary_Bank,
                  ttk_util_pkg.fn_decrypt(tcp.payee_name) as Beneficiary_name,
                  nvl(cc.check_amount,tcp.approved_amount) as Pay_Amount,
                  ''QAR'' as Pay_Currency,
                 CASE WHEN tcp.claim_type=''CTM'' THEN
                     (CASE WHEN e.enrol_type_id=''COR'' THEN
                           (CASE WHEN e.tpa_cheque_issued_general_type=''IQI'' THEN ttk_util_pkg.fn_decrypt(t.bank_account_no)
                                 WHEN e.tpa_cheque_issued_general_type=''IQC'' THEN ttk_util_pkg.fn_decrypt(S.bank_account_no) 
                            END)
                      ELSE 
                        ttk_util_pkg.fn_decrypt(t.bank_account_no)
                      END)
                ELSE 
                  ttk_util_pkg.fn_decrypt(W.account_number) 
                end as Beneficiary_account_number,
                tcp.address1||tcp.address2||tcp.address3 as Beneficiary_Address,
                CASE WHEN tcp.claim_type=''CTM'' THEN
                    (CASE WHEN e.enrol_type_id=''COR'' THEN (CASE WHEN e.tpa_cheque_issued_general_type=''IQI'' THEN ttk_util_pkg.fn_decrypt(ema.email_id)
                          WHEN e.tpa_cheque_issued_general_type=''IQC'' THEN l.notify_email_id 
                     end)
                ELSE 
                  ttk_util_pkg.fn_decrypt(ema.email_id) 
                END)
                ELSE ttk_util_pkg.fn_decrypt(o.primary_email_id) 
                END as Bene_Email_Id,
               tcp.claim_settlement_no as Beneficiary_Payment_Details,
               null as Payable_Country,
               null as BeneBank_BIC_Code,
               ' || v_batch_seq_id ||
                         ' as Route_Code,
               null as Sort_Code,
               null as SWIFT_Code, 
               null as Charge_type,
               null as Transaction_Type,
               null as Payment_Type,
               null as Payment_Link,
               to_char(tcp.trans_ref_no) as Transaction_Reference,
               null as Account_debit_date
               from fin_app.tpa_claims_payment tcp 
              LEFT OUTER JOIN tpa_enr_policy_member B ON(tcp.member_seq_id = B.member_seq_id)
              LEFT OUTER JOIN tpa_enr_policy E ON(tcp.policy_seq_id = E.policy_seq_id )
              LEFT OUTER JOIN tpa_enr_policy_group R ON(B.policy_group_seq_id=R.policy_group_seq_id)
              LEFT OUTER JOIN TPA_ENR_MEM_ADDRESS EMA ON (b.enr_address_seq_id = ema.enr_address_seq_id)
              LEFT OUTER JOIN tpa_enr_bank_dtls S ON(E.bank_seq_id=S.bank_seq_id)
              LEFT OUTER JOIN tpa_enr_bank_dtls T ON(R.bank_seq_id=T.bank_seq_id)
              LEFT OUTER JOIN fin_app.tpa_payment_checks_details pcd on (tcp.payment_seq_id = pcd.payment_seq_id and pcd.v_csr_flag = 1)
              LEFT OUTER JOIN fin_app.tpa_claims_check cc on (pcd.claims_chk_seq_id = cc.claims_chk_seq_id and cc.v_csr_flag = 1)
              LEFT OUTER JOIN fin_app.tpa_float_account tfa on (tcp.float_seq_id = tfa.float_seq_id)
              left outer join fin_app.tpa_bank_accounts ba on (tfa.bank_acc_seq_id = ba.bank_acc_seq_id)
              LEFT OUTER JOIN tpa_bank_master  h ON (h.bank_seq_id = ba.bank_seq_id)
              left outer join app.tpa_enr_bank_dtls bd on (ba.bank_seq_id = bd.bank_seq_id)
              left outer join APP.TPA_IFSC_CODE_DETAILS fc on (bd.branch_seq_id = fc.branch_seq_id)
              LEFT OUTER JOIN tpa_group_registration L ON (L.group_reg_seq_id = tcp.group_reg_seq_id)
              LEFT OUTER JOIN cheque_template N ON (H.cheque_template_id = N.cheque_template_id)
              LEFT OUTER JOIN tpa_hosp_info O ON (tcp.hosp_seq_id=O.hosp_seq_id)
              LEFT OUTER JOIN tpa_hosp_account_details W ON(O.hosp_seq_id=w.hosp_seq_id)
              WHERE tcp.float_seq_id = :v_float_seq_id ' ||
                               regexp_replace(v_where, 'D\.', 'tcp.') ||
                               ' AND tcp.claim_payment_status  = ''READY_TO_BANK''';
  
    IF v_where IS NOT NULL THEN
      v_where := ' AND (' || substr(v_where, 4) || ')';
    END IF;
  
    IF str_tab.FIRST IS NOT NULL THEN
      IF str_tab.COUNT <= 8 THEN
        CASE str_tab.COUNT
          WHEN 1 THEN
            OPEN v_resultset FOR v_sql_str
              USING v_float_seq_id, str_tab(1);
          WHEN 2 THEN
            OPEN v_resultset FOR v_sql_str
              USING v_float_seq_id, str_tab(1), str_tab(2);
          WHEN 3 THEN
            OPEN v_resultset FOR v_sql_str
              USING v_float_seq_id, str_tab(1), str_tab(2), str_tab(3);
          WHEN 4 THEN
            OPEN v_resultset FOR v_sql_str
              USING v_float_seq_id, str_tab(1), str_tab(2), str_tab(3), str_tab(4);
          WHEN 5 THEN
            OPEN v_resultset FOR v_sql_str
              USING v_float_seq_id, str_tab(1), str_tab(2), str_tab(3), str_tab(4), str_tab(5);
          WHEN 6 THEN
            OPEN v_resultset FOR v_sql_str
              USING v_float_seq_id, str_tab(1), str_tab(2), str_tab(3), str_tab(4), str_tab(5), str_tab(6);
          WHEN 7 THEN
            OPEN v_resultset FOR v_sql_str
              USING v_float_seq_id, str_tab(1), str_tab(2), str_tab(3), str_tab(4), str_tab(5), str_tab(6), str_tab(7);
          WHEN 8 THEN
            OPEN v_resultset FOR v_sql_str
              USING v_float_seq_id, str_tab(1), str_tab(2), str_tab(3), str_tab(4), str_tab(5), str_tab(6), str_tab(7), str_tab(8);
        END CASE;
      ELSE
        OPEN v_resultset FOR v_tds_str
          USING v_float_seq_id;
      END IF;
    END IF;
  
    IF v_where IS NOT NULL THEN
      v_where := ' AND (' || substr(v_where, 8);
    END IF;
  
    v_consql_str :=  --- ENBD
      'select tpa_cheque_issued_general_type,
       case when upper(BANK_NAME) IN (''EMIRATES NBD'', ''EMIRATES ISLAMIC BANK'') THEN
        ''TR''
       else
        ''OB''
       end as pay_mode,
       Beneficiary_Bank,
       substr(Beneficiary_name, 1, 60) as Beneficiary_name,
       sum(pay_amount) as pay_amount,
       count(Beneficiary_Payment_Details) as no_of_claims,
       Pay_Currency,
       Beneficiary_account_number,
       REGEXP_REPLACE(REPLACE(Beneficiary_Address, '','','' ''), ''[^ A-Za-z0-9]'') as Beneficiary_Address,
       Bene_Email_Id,
       Beneficiary_Payment_Details  Beneficiary_Payment_Details,
       --length(wm_concat(Beneficiary_Payment_Details)),
       --count(wm_concat(Beneficiary_Payment_Details),
       null as Payable_Country,
       null as BeneBank_BIC_Code,
       Route_Code as Route_Code,
       null as Sort_Code,
       null as SWIFT_Code,
       null as Charge_type,
       null as Transaction_Type,
       null as Payment_Type,
       null as Payment_Link,
       to_char(wm_concat(distinct Transaction_Reference)) as Transaction_Reference,
       null as Account_debit_date,
       Beneficiary_Country
      from (select tcp.tpa_cheque_issued_general_type,
               tcp.tpa_nhcp_cheques_issued_to,
               h.bank_id as Beneficiary_Bank,
               UPPER(h.BANK_NAME) AS BANK_NAME,
               intx.ttk_util_pkg.fn_decrypt(tcp.payee_name) as Beneficiary_name,
               nvl(cc.check_amount, tcp.approved_amount) as Pay_Amount,
               ''AED'' as Pay_Currency,
               CASE
                     WHEN tcp.claim_type = ''CTM'' THEN
                      (CASE
                        WHEN e.enrol_type_id = ''COR'' THEN
                         (CASE
                           WHEN e.tpa_cheque_issued_general_type = ''IQI'' THEN
                            ttk_util_pkg.fn_decrypt(w.bank_ifsc)
                           WHEN e.tpa_cheque_issued_general_type = ''IQC'' THEN
                            ttk_util_pkg.fn_decrypt(w.bank_ifsc)
                         END)
                        ELSE
                         ttk_util_pkg.fn_decrypt(w.bank_ifsc)
                      END)
                     ELSE
                      ttk_util_pkg.fn_decrypt(w.bank_ifsc)
                   end as Beneficiary_account_number,
               
               tcp.address1 || tcp.address2 || tcp.address3 as Beneficiary_Address,
               intx.ttk_util_pkg.fn_decrypt(o.primary_email_id) as Bene_Email_Id,
               ''Batch No. '||v_batch_seq_id\*tcp.batch_number_manual*\||' Unique Trans Ref. ''||tcp.trans_ref_no as Beneficiary_Payment_Details,
               null as Payable_Country,
               null as BeneBank_BIC_Code,
               --'||v_batch_seq_id||' as Route_Code,
               null as Route_Code,
               null             as Sort_Code,
               null             as SWIFT_Code,
               null             as Charge_type,
               null             as Transaction_Type,
               null             as Payment_Type,
               null             as Payment_Link,
               tcp.trans_ref_no as Transaction_Reference,
               null             as Account_debit_date,
               ''United Arab Emirates'' as Beneficiary_Country
            from fin_app.tpa_claims_payment tcp
          LEFT OUTER JOIN tpa_enr_policy_member B ON (tcp.member_seq_id = B.member_seq_id)
          LEFT OUTER JOIN tpa_enr_policy E ON (tcp.policy_seq_id = E.policy_seq_id)
          LEFT OUTER JOIN tpa_enr_policy_group R ON (B.policy_group_seq_id = R.policy_group_seq_id)
          LEFT OUTER JOIN tpa_enr_bank_dtls S ON (E.bank_seq_id = S.bank_seq_id)
          LEFT OUTER JOIN tpa_enr_bank_dtls T ON (R.bank_seq_id = T.bank_seq_id)
          LEFT OUTER JOIN fin_app.tpa_payment_checks_details pcd on (tcp.payment_seq_id = pcd.payment_seq_id and pcd.v_csr_flag = 1)
          LEFT OUTER JOIN fin_app.tpa_claims_check cc on (pcd.claims_chk_seq_id = cc.claims_chk_seq_id and cc.v_csr_flag = 1)
          LEFT OUTER JOIN fin_app.tpa_float_account tfa on (tcp.float_seq_id = tfa.float_seq_id)
          \*left outer join fin_app.tpa_bank_accounts ba on (tfa.bank_acc_seq_id = ba.bank_acc_seq_id)
          LEFT OUTER JOIN fin_app.tpa_bank_master h ON (h.bank_seq_id = ba.bank_seq_id)
          left outer join app.tpa_enr_bank_dtls bd on (ba.bank_seq_id = bd.bank_seq_id) 
          left outer join APP.TPA_IFSC_CODE_DETAILS fc on (bd.branch_seq_id = fc.branch_seq_id)*\
          LEFT OUTER JOIN tpa_group_registration L ON (L.group_reg_seq_id = tcp.group_reg_seq_id)
          \*LEFT OUTER JOIN cheque_template N ON (H.cheque_template_id = N.cheque_template_id)*\
          LEFT OUTER JOIN tpa_hosp_info O ON (tcp.hosp_seq_id = O.hosp_seq_id)
          LEFT OUTER JOIN tpa_hosp_account_details W ON (O.hosp_seq_id = w.hosp_seq_id)
          left join fin_app.tpa_bank_master h on (h.bank_seq_id=w.bank_seq_id)
          left outer join app.clm_authorization_details cd on(cd.claim_seq_id=tcp.claim_seq_id)
    WHERE tcp.float_seq_id = :v_float_seq_id '|| regexp_replace(v_where,'D\.','tcp.')||' AND tcp.claim_payment_status  = ''READY_TO_BANK'' AND cd.req_amt_currency_type='''||v_currency_type||''')
   group by Beneficiary_name,
          BANK_NAME,
          Beneficiary_Bank,
          Pay_Currency,
          Beneficiary_account_number,
          Beneficiary_Address,
          Bene_Email_Id,
          tpa_cheque_issued_general_type,
          Route_Code,Beneficiary_Country,Beneficiary_Payment_Details';
          
   ---ENBD CHECK PRINT
  
    IF str_tab.FIRST IS NOT NULL THEN
      IF str_tab.COUNT <= 8 THEN
        CASE str_tab.COUNT
          WHEN 1 THEN
            OPEN v_conresultset FOR v_consql_str
              USING v_float_seq_id, str_tab(1);
          WHEN 2 THEN
            OPEN v_conresultset FOR v_consql_str
              USING v_float_seq_id, str_tab(1), str_tab(2);
          WHEN 3 THEN
            OPEN v_conresultset FOR v_consql_str
              USING v_float_seq_id, str_tab(1), str_tab(2), str_tab(3);
          WHEN 4 THEN
            OPEN v_conresultset FOR v_consql_str
              USING v_float_seq_id, str_tab(1), str_tab(2), str_tab(3), str_tab(4);
          WHEN 5 THEN
            OPEN v_conresultset FOR v_consql_str
              USING v_float_seq_id, str_tab(1), str_tab(2), str_tab(3), str_tab(4), str_tab(5);
          WHEN 6 THEN
            OPEN v_conresultset FOR v_consql_str
              USING v_float_seq_id, str_tab(1), str_tab(2), str_tab(3), str_tab(4), str_tab(5), str_tab(6);
          WHEN 7 THEN
            OPEN v_conresultset FOR v_consql_str
              USING v_float_seq_id, str_tab(1), str_tab(2), str_tab(3), str_tab(4), str_tab(5), str_tab(6), str_tab(7);
          WHEN 8 THEN
            OPEN v_conresultset FOR v_consql_str
              USING v_float_seq_id, str_tab(1), str_tab(2), str_tab(3), str_tab(4), str_tab(5), str_tab(6), str_tab(7), str_tab(8);
        END CASE;
      ELSE
        OPEN v_conresultset FOR v_consql_str
          USING v_float_seq_id;
      END IF;
    END IF;
    
    
    v_rows_processed := str_tab.last;
    COMMIT;
  
    IF substr(v_file_name, 1, 4) = 'ENBD' THEN
      v_filename := v_file_name||'-1';
    ELSE
      v_filename := 'ENBD' || '-' ||
                  TO_CHAR(v_batch_date, 'DDMMYYYY-HH24MISS') || '-' ||
                  v_added_by;
    END IF;
    
    IF substr(v_file_name, 1, 4) = 'DEFL' THEN
      v_filename := v_file_name||'-1';
    ELSE
      v_filename := 'DEFL' || '-' ||
                  TO_CHAR(v_batch_date, 'DDMMYYYY-HH24MISS') || '-' ||
                  v_added_by;
    END IF;
    
    UPDATE tpa_bank_advice_batch A
       SET A.no_of_transactions = v_count_of_payments,
           A.file_name          = v_filename,
           A.updated_date       = SYSDATE,
           a.updated_by         = v_added_by
     WHERE batch_seq_id = v_batch_seq_id;
  
    --update the status to sent_to_bank to the respective claims.
     IF str_tab.FIRST IS NOT NULL THEN
      FOR  i IN str_tab.FIRST .. str_tab.LAST loop
         open chk_setlmnt_no (str_tab(i),v_float_seq_id,v_currency_type);
         fetch chk_setlmnt_no into v_cnt;
         close chk_setlmnt_no;
      IF  v_cnt>0 then 
             open chk_payment_status(str_tab(i));
             fetch chk_payment_status into v_cnt;
             close chk_payment_status;
        IF v_cnt = 0 then  
              UPDATE tpa_claims_payment a
              SET A.claim_payment_status = 'SENT_TO_BANK',
               A.bank_advice_batch    = bank_advice_batch_seq.CURRVAL,
               A.updated_date         = TO_DATE(SYSDATE, 'DD-MON-RRRR'),
               a.updated_by           = v_added_by
               
         WHERE claim_settlement_no = str_tab(i);
         
         UPDATE tpa_claims_payment t
         SET t.enbd_gen_count = 1
         WHERE t.float_seq_id = v_float_seq_id;
         v_msg:='success';
      ELSE
        ----added newly 
            open settlement_payment_status(str_tab(i));
            fetch settlement_payment_status into v_settlement_no_status;
            close settlement_payment_status;  
           if v_settlement_no_status='PAID' then 
           v_msg:='Settlement number alreay PAID ';
           elsif v_settlement_no_status='PAID' then 
             v_msg:='Settlement number under  '||v_settlement_no_status;
          elsif v_settlement_no_status='SENT_TO_BANK' then 
             v_msg:='For this Settlement number payment batch is genetaed  '||v_settlement_no_status;              
           else 
           v_msg:='Settlement number under  '||v_settlement_no_status;
       end if;
      END IF;
      
      ELSE
        v_msg:='Settlement numbr not linked to this float or currency type is not matching';
      END IF;
      INSERT INTO fin_app.PAYMENT_ERROR_LOG(error_log_seq_id,settelment_number,ADDED_DATE,FILE_NAME,error_mesg)
       VALUES(fin_app.Payment_advice_seq.NEXTVAL,str_tab(i),SYSDATE,v_filename,v_msg);       
      END LOOP;
      
    END IF;
    
    v_rows_processed := str_tab.last;
    
 commit;
END payment_advice_upload_details;*/

--===================================================================================
PROCEDURE payment_advice_upload_details (v_claim_settlement_no IN VARCHAR2,
                                         v_float_seq_id        IN TPA_FLOAT_ACCOUNT.float_seq_id%TYPE,
                                         v_currency_type       IN VARCHAR2,
                                         v_payment_method      IN TPA_CLAIMS_PAYMENT.payee_type%TYPE,
                                         v_payment_to          IN  VARCHAR2,
                                         v_rows_processed      OUT INTEGER,
                                         v_result              OUT SYS_REFCURSOR)
  IS
  str_tab               ttk_util_pkg.str_table_type := ttk_util_pkg.parse_str(v_claim_settlement_no);
  
   CURSOR chk_setlmnt_no( v_settlement_number clm_authorization_details.settlement_number%type,
                          v_float_seq_id      TPA_FLOAT_ACCOUNT.float_seq_id%TYPE,
                          v_currency_type     clm_authorization_details.currency_type%TYPE ) 
          is
          select count(1) from  tpa_claims_payment a
          JOIN CLM_AUTHORIZATION_DETAILS B ON (A.CLAIM_SEQ_ID=B.CLAIM_SEQ_ID)
          where a.claim_settlement_no=  v_settlement_number  
          and a.float_seq_id=v_float_seq_id
          AND b.req_amt_currency_type = v_currency_type AND a.payee_type=v_payment_method; 
          
    CURSOR chk_setlmnt_no_any_curr
                         (v_settlement_number clm_authorization_details.settlement_number%type,
                          v_float_seq_id      TPA_FLOAT_ACCOUNT.float_seq_id%TYPE
                          ) 
          is
          select count(1) from  tpa_claims_payment a
          where a.claim_settlement_no=  v_settlement_number 
          and a.float_seq_id=v_float_seq_id
          AND a.payee_type=v_payment_method;  
    
   CURSOR tpa_bank_details IS
        SELECT ad.account_number, ad.bank_ifsc
        FROM fin_app.tpa_account_details ad;
    
  cursor chk_payment_status ( v_settlement_number clm_authorization_details.settlement_number%type) is
       SELECT COUNT(1) 
             FROM tpa_claims_payment A
             WHERE claim_payment_status ='READY_TO_BANK' AND 
             A.CLAIM_SETTLEMENT_NO= v_settlement_number ;
                      
cursor settlement_payment_status ( v_settlement_number clm_authorization_details.settlement_number%type)is
SELECT a.claim_payment_status 
       FROM tpa_claims_payment A 
       WHERE A.CLAIM_SETTLEMENT_NO= v_settlement_number;    
       
CURSOR Get_dup_count (v_bat  NUMBER) is
      select SETTELMENT_NO,count(1)
      from FIN_APP.FIN_APP_TEMP_TABLE1 R WHERE R.BATCH_NUMBER=v_bat
      group by SETTELMENT_NO
      having count(1)>1;
       
	                            
         
v_sql_str                        VARCHAR2(32767);
v_claim_settlement_no1           VARCHAR2(32767);
v_out                            VARCHAR2(32767);
v_str                            VARCHAR2(32767);
v_tpa_account_no                 VARCHAR2(100); 
v_tpa_ifsc                       VARCHAR2(60); 
i                                NUMBER(10) := 0;
v_payment_seq_id_list            VARCHAR2(32767);
v_cnt                            NUMBER(10);
v_msg                            VARCHAR2(1000);
v_settlement_no_status           VARCHAR2(100);
v_batch_number                   NUMBER(30):=0;

type dup_settelement_numbers is table oF Get_dup_count%ROWTYPE INDEX BY BINARY_INTEGER;
duplicate_count dup_settelement_numbers;

BEGIN  

delete from fin_app.fin_app_temp_table1 where added_date<sysdate;

  v_batch_number :=fin_app.payment_advice_batch_log.nextval;
  
  
  
 IF v_claim_settlement_no IS NOT NULL THEN
   
     FORALL  i IN str_tab.FIRST .. str_tab.LAST  
          insert into fin_app.fin_app_temp_table1
          (SETTELMENT_NO,BATCH_NUMBER,ADDED_DATE)
           values 
            ( str_tab(i),v_batch_number,sysdate);
     
     
 commit;
 
    open Get_dup_count(v_batch_number);
      fetch Get_dup_count bulk collect into duplicate_count;
        close Get_dup_count;
    
END IF;
  
    IF str_tab.FIRST IS NOT NULL THEN
         
    IF v_currency_type='ANY' THEN  
     
     FOR  i IN str_tab.FIRST .. str_tab.LAST LOOP          
               open chk_setlmnt_no_any_curr(str_tab(i),v_float_seq_id);
               fetch chk_setlmnt_no_any_curr into v_cnt;
               close chk_setlmnt_no_any_curr;
               
          IF v_cnt>0 THEN  
                open chk_payment_status(str_tab(i));
                fetch chk_payment_status into v_cnt;
                close chk_payment_status;
              IF v_cnt = 1 then          
                v_msg:='SUCCESS';
                  v_claim_settlement_no1:=v_claim_settlement_no1||'|'||str_tab(i);
               ELSE
                open settlement_payment_status(str_tab(i));
                fetch settlement_payment_status into v_settlement_no_status;
                close settlement_payment_status;  
               if v_settlement_no_status='PAID' then 
               v_msg:='SETTLEMENT NUMBER ALREADY PAID';
               else 
               v_msg:='SETTLEMENT NUMBER UNDER '||v_settlement_no_status;
               end if;  
              END IF;
            
           ELSE
              v_msg:='SETTLEMENT NUMBER NOT LINKED TO THIS FLOAT OR CURRENCY TYPE IS NOT MATCHING OR PAYEE TYPE MISMATCHING';
          END IF;
        
          INSERT INTO fin_app.PAYMENT_ERROR_LOG(ERROR_LOG_SEQ_ID,BATCH_NUMBER,SETTELMENT_NUMBER,PAYEE_TYPE,added_date,ERROR_MESG)
            VALUES (FIN_APP.Payment_advice_seq.NEXTVAL,v_batch_number,str_tab(i),v_payment_method,sysdate,v_msg);
        
        END loop;
      ELSE  
       FOR  i IN str_tab.FIRST .. str_tab.LAST LOOP          
               open chk_setlmnt_no(str_tab(i),v_float_seq_id,v_currency_type);
               fetch chk_setlmnt_no into v_cnt;
               close chk_setlmnt_no;
               
          IF v_cnt>0 THEN  
                open chk_payment_status(str_tab(i));
                fetch chk_payment_status into v_cnt;
                close chk_payment_status;
              IF v_cnt = 1 then          
                v_msg:='SUCCESS';
                  v_claim_settlement_no1:=v_claim_settlement_no1||'|'||str_tab(i);
               ELSE
                open settlement_payment_status(str_tab(i));
                fetch settlement_payment_status into v_settlement_no_status;
                close settlement_payment_status;  
               if v_settlement_no_status='PAID' then 
               v_msg:='SETTLEMENT NUMBER ALREADY PAID';
               else 
               v_msg:='SETTLEMENT NUMBER UNDER '||v_settlement_no_status;
               end if;  
              END IF;
            
           ELSE
              v_msg:='SETTLEMENT NUMBER NOT LINKED TO THIS FLOAT OR CURRENCY TYPE IS NOT MATCHING OR PAYEE TYPE MISMATCHING';
          END IF;
        
          INSERT INTO fin_app.PAYMENT_ERROR_LOG(ERROR_LOG_SEQ_ID,BATCH_NUMBER,SETTELMENT_NUMBER,PAYEE_TYPE,added_date,ERROR_MESG)
            VALUES (FIN_APP.Payment_advice_seq.NEXTVAL,v_batch_number,str_tab(i),v_payment_method,sysdate,v_msg);
        
        END loop;
       END IF; 
        v_rows_processed := v_batch_number;
        
        IF  duplicate_count.count>0  then     
              for i in duplicate_count.first..duplicate_count.last loop
              
              update fin_app.PAYMENT_ERROR_LOG e 
              set ERROR_MESG='DUPLICATE CLAIM SETTELEMENT NUMBER'
              where rowid NOT IN (select max(rowid) 
                                    from fin_app.PAYMENT_ERROR_LOG 
                                    where BATCH_NUMBER=v_batch_number and 
                                    ERROR_MESG='SUCCESS' and SETTELMENT_NUMBER in (select t.SETTELMENT_NO
                                                                                from fin_app.fin_app_temp_table1 t
                                                                                where t.batch_number=v_batch_number)
                                    group by SETTELMENT_NUMBER,ERROR_MESG
                                    having count(1)>1) and e.ERROR_MESG='SUCCESS' and e.BATCH_NUMBER=v_batch_number
                                    AND SETTELMENT_NUMBER=duplicate_count(I).SETTELMENT_NO ;
               
              update fin_app.PAYMENT_ERROR_LOG e 
              set ERROR_MESG='DUPLICATE CLAIM SETTELEMENT NUMBER'
              where rowid NOT IN (select max(rowid) 
                                    from fin_app.PAYMENT_ERROR_LOG 
                                    where BATCH_NUMBER=v_batch_number and 
                                    ERROR_MESG like 'SETTLEMENT NUMBER ALREADY PAID%' and SETTELMENT_NUMBER in (select t.SETTELMENT_NO
                                                                                from fin_app.fin_app_temp_table1 t
                                                                                where t.batch_number=v_batch_number)
                                    group by SETTELMENT_NUMBER,ERROR_MESG
                                    having count(1)>1) and e.ERROR_MESG like 'SETTLEMENT NUMBER ALREADY PAID%' and e.BATCH_NUMBER=v_batch_number
                                    AND SETTELMENT_NUMBER=duplicate_count(I).SETTELMENT_NO ;
             
              update fin_app.PAYMENT_ERROR_LOG e 
              set ERROR_MESG='DUPLICATE CLAIM SETTELEMENT NUMBER'
              where rowid NOT IN (select max(rowid) 
                                    from fin_app.PAYMENT_ERROR_LOG 
                                    where BATCH_NUMBER=v_batch_number and 
                                    ERROR_MESG like 'SETTLEMENT NUMBER NOT LINKED TO THIS FLOAT OR CURRENCY TYPE IS NOT MATCHING%' and SETTELMENT_NUMBER in (select t.SETTELMENT_NO
                                                                                from fin_app.fin_app_temp_table1 t
                                                                                where t.batch_number=v_batch_number)
                                    group by SETTELMENT_NUMBER,ERROR_MESG
                                    having count(1)>1) and e.ERROR_MESG like 'SETTLEMENT NUMBER NOT LINKED TO THIS FLOAT OR CURRENCY TYPE IS NOT MATCHING%' and e.BATCH_NUMBER=v_batch_number 
                                    AND SETTELMENT_NUMBER=duplicate_count(I).SETTELMENT_NO;   
                                                     
              update fin_app.PAYMENT_ERROR_LOG e 
              set ERROR_MESG='DUPLICATE CLAIM SETTELEMENT NUMBER'
              where rowid NOT IN (select max(rowid) 
                                    from fin_app.PAYMENT_ERROR_LOG 
                                    where BATCH_NUMBER=v_batch_number and 
                                    ERROR_MESG like 'SETTLEMENT NUMBER UNDER%' and SETTELMENT_NUMBER in (select t.SETTELMENT_NO
                                                                                from fin_app.fin_app_temp_table1 t
                                                                                where t.batch_number=v_batch_number)
                                    group by SETTELMENT_NUMBER,ERROR_MESG
                                    having count(1)>1) and e.ERROR_MESG like 'SETTLEMENT NUMBER UNDER%' and e.BATCH_NUMBER=v_batch_number 
                                    AND SETTELMENT_NUMBER=duplicate_count(I).SETTELMENT_NO;        
              
                                  
              end loop;
              commit;
         END IF;
       
         V_OUT:=v_claim_settlement_no1||'|';
            
          v_payment_seq_id_list  := replace (replace('('''||REPLACE(SUBSTR(V_OUT,2,
                                          LENGTH(v_claim_settlement_no)-2) ,'|',''',''')||''')',')',''),'(','');
        
        END IF;
    v_sql_str:= 'SELECT  gd.req_amt_currency_type ,
                 trunc(gd.CONVERTED_FINAL_APPROVED_AMT,2) CONVERTED_FINAL_APPROVED_AMT,
                 A.payment_seq_id,
                 A.claim_settlement_no,
                 B.tpa_enrollment_id,
                 B.mem_name,
                 K.description  AS claim_type,
                 A.claim_aprv_date,
                 ttk_util_pkg.fn_decrypt(a.payee_name) as in_favour_of,
                 a.approved_amount,
                 F.current_balance,
                 H.bank_name AS HO,
                 J.bank_name AS BO,
                 M.office_code ,
                 N.template_name,
                 o.tds_process_yn,
                 L.GROUP_NAME AS corporate_name,
                 GD.CLM_RECEIVED_DATE AS CLAIM_RECV_DATE,
                 CASE WHEN a.claim_type=''CTM'' /*AND nvl(gd.pay_to_general_type_id,''MBR'')!=''HSL'' */THEN
                 --CASE WHEN a.tpa_nhcp_cheques_issued_to=''TPA'' THEN ''' ||
                 v_tpa_account_no ||
                 ''' ELSE
                 (CASE WHEN e.enrol_type_id=''COR'' THEN
                 (CASE WHEN e.tpa_cheque_issued_general_type=''IQI'' THEN ttk_util_pkg.fn_decrypt(t.bank_account_no)
                 WHEN e.tpa_cheque_issued_general_type=''IQC'' THEN ttk_util_pkg.fn_decrypt(S.bank_account_no)
                 END)
                 ELSE ttk_util_pkg.fn_decrypt(t.bank_account_no) END)
                 --END  as account_num,
                 ELSE ttk_util_pkg.fn_decrypt(W.account_number) end as account_num,
                 CASE WHEN a.claim_type=''CTM''/* AND nvl(gd.pay_to_general_type_id,''MBR'')!=''HSL''*/ THEN --added for hyundai requirement
                 --CASE WHEN a.tpa_nhcp_cheques_issued_to=''TPA'' THEN ''' ||
                 v_tpa_ifsc ||
                 ''' ELSE
                 (CASE WHEN e.enrol_type_id=''COR'' THEN (CASE WHEN e.tpa_cheque_issued_general_type=''IQI'' THEN ttk_util_pkg.fn_decrypt(t.bank_ifsc)
                 WHEN e.tpa_cheque_issued_general_type=''IQC'' THEN ttk_util_pkg.fn_decrypt(S.bank_ifsc) END)
                 ELSE ttk_util_pkg.fn_decrypt(t.bank_ifsc) END)--END as ifsc
                 ELSE  ttk_util_pkg.fn_decrypt(W.bank_ifsc) end as ifsc,
              CASE WHEN '''||v_payment_to||'''=''USD'' THEN  nvl(gd.pay_amt_in_usd,0) 
                   WHEN '''||v_payment_to||'''=''GBP'' THEN  nvl(gd.PAY_AMT_IN_GBP,0)
                   WHEN '''||v_payment_to||'''=''EUR'' THEN  nvl(gd.PAY_AMT_IN_EURO,0) END as USD_AMOUNT,
              CASE WHEN A.HOSP_SEQ_ID is not null then o.Payment_Dur_Agr 
                   WHEN A.PTNR_SEQ_ID is not null then pi.Payment_Dur_Agr end Payment_Dur_Agr,
              (to_date(SYSDATE,''dd-mm-yyyy'') - to_date(gd.clm_received_date,''dd-mm-yyyy'')) AS claim_age,
             '''||v_payment_to ||''' as Selected_currency,
             CASE WHEN round(sysdate - clm_received_date) <= fa.FST_TO_DAYS then  round((a.approved_amount* fa.DISC_PERC)/100,2 ) else 0 end as DISC_AMOUNT,
             CASE WHEN round(sysdate - clm_received_date) <= fa.FST_TO_DAYS then A.approved_amount - round((a.approved_amount* fa.DISC_PERC)/100,2 ) else A.approved_amount end  as AMT_PAID_AF_DISC
 
        FROM tpa_claims_payment A JOIN tpa_enr_policy_member B ON(A.member_seq_id = B.member_seq_id)
        JOIN clm_authorization_details gd on (gd.claim_seq_id=a.claim_seq_id)--added for hyundai requirement
        JOIN tpa_enr_policy E ON(A.policy_seq_id = E.policy_seq_id )
        JOIN tpa_float_account F ON(A.float_seq_id = F.float_seq_id)
        JOIN tpa_bank_accounts g ON(f.bank_acc_seq_id = g.bank_acc_seq_id)
        JOIN tpa_bank_master  h ON (h.bank_seq_id = g.bank_seq_id)
        LEFT OUTER JOIN (SELECT bank_SEQ_ID FROM tpa_bank_master ) I ON(i.bank_seq_id = H.ho_id)
        LEFT OUTER JOIN tpa_bank_master J ON (J.bank_seq_id = I.bank_seq_id)
        JOIN tpa_general_code K ON (K.general_type_id = A.claim_type)
        LEFT OUTER JOIN tpa_group_registration L ON (L.group_reg_seq_id = A.group_reg_seq_id)
        LEFT OUTER JOIN tpa_office_info M ON (M.Tpa_Office_Seq_Id=g.tpa_office_seq_id)
        LEFT OUTER JOIN cheque_template N ON (H.cheque_template_id = N.cheque_template_id)
        JOIN tpa_enr_policy_group R ON(B.policy_group_seq_id=R.policy_group_seq_id)
        LEFT OUTER JOIN tpa_enr_bank_dtls S ON(E.bank_seq_id=S.bank_seq_id)
        LEFT OUTER JOIN tpa_enr_bank_dtls T ON(R.bank_seq_id=T.bank_seq_id)
        LEFT OUTER JOIN tpa_hosp_info O ON(a.hosp_seq_id=O.hosp_seq_id)
        LEFT OUTER JOIN tpa_hosp_account_details W ON(O.hosp_seq_id=w.hosp_seq_id)
        LEFT OUTER JOIN tpa_partner_info pi on (pi.Ptnr_Seq_Id=a.Ptnr_Seq_Id)
        LEFT OUTER JOIN APP.TPA_FASTTRACT_DISC_DETAILS FA ON (FA.HOSP_SEQ_ID=a.HOSP_SEQ_ID AND FA.DISC_MODE=''FAST''
        AND FA.STATUS=''ACT'' AND gd.DATE_OF_HOSPITALIZATION between fa.START_DATE and fa.end_date)
        where a.float_seq_id='||v_float_seq_id||' and a.claim_settlement_no in ('||v_payment_seq_id_list||')
              AND a.claim_payment_status=''READY_TO_BANK'' and a.payee_type='''||v_payment_method||''''; 
        
        OPEN v_result FOR v_sql_str;
                
END  payment_advice_upload_details;
--====================================================================================
PROCEDURE Upload_Payment_Error_log (v_flag             IN   VARCHAR2,
                                    v_batch_number     IN   NUMBER,
                                    v_error_log_count OUT   SYS_REFCURSOR,
                                    v_error_log       OUT   SYS_REFCURSOR,
                                    v_error_log1       OUT   SYS_REFCURSOR
                                    )
  AS
  
  v_Advice_batch_number                NUMBER(30);
  v_succ_count                         NUMBER(30);
  v_fail_count                         NUMBER(30);
 
 -- Payment Related Cursors
  
    CURSOR Payment_Succes_Count(v_batch_number VARCHAR2) IS       
          SELECT NVL(COUNT(E.ERROR_MESG),0) 
          FROM FIN_APP.BATCH_UPLOAD_ERROR_LOG E
          WHERE E.ERROR_MESG='SUCCESS' AND E.BATCH_NUMBER=v_batch_number;
          
    CURSOR Payment_Failed_Count (v_batch_number VARCHAR2)  IS    
       SELECT NVL(COUNT(1),0) INTO v_fail_count
          FROM FIN_APP.BATCH_UPLOAD_ERROR_LOG E
          WHERE E.ERROR_MESG!='SUCCESS'
                AND E.BATCH_NUMBER=v_batch_number;  
   
 --Advice Related Cursors  
          
    CURSOR Payment_advice_Succes_Count(v_batch_number VARCHAR2) IS       
          SELECT NVL(COUNT(E.ERROR_MESG),0) 
          FROM FIN_APP.PAYMENT_ERROR_LOG E
          WHERE E.ERROR_MESG='SUCCESS' AND E.BATCH_NUMBER=v_batch_number;
          
          
    CURSOR Payment_advice_Failed_Count(v_batch_number VARCHAR2) IS    
          SELECT NVL(COUNT(1),0) 
          FROM FIN_APP.PAYMENT_ERROR_LOG E
          WHERE E.ERROR_MESG!='SUCCESS' 
            AND E.BATCH_NUMBER=v_batch_number;      
   
  BEGIN
    IF v_flag='P' THEN
     
      IF v_batch_number IS NOT NULL THEN
        
       OPEN Payment_Succes_Count(v_batch_number);
        FETCH Payment_Succes_Count INTO v_succ_count;
          CLOSE Payment_Succes_Count;
          
       OPEN Payment_Failed_Count(v_batch_number);
        FETCH Payment_Failed_Count INTO v_fail_count;
          CLOSE Payment_Failed_Count;
      
      END IF;   
      
  OPEN  v_error_log_count FOR
    SELECT   NVL(v_succ_count,0) AS SUCCESS_COUNT,NVL(v_fail_count,0) AS FAILED_COUNT,
             (NVL(v_succ_count,0)+NVL(v_fail_count,0)) AS TOTAL_COUNT 
         FROM DUAL;
  OPEN v_error_log FOR
    SELECT batch_number as log_batch_number,settelment_number,payee_type,to_char(added_date,'DD-MM-YYYY') added_date,error_mesg 
          FROM  FIN_APP.BATCH_UPLOAD_ERROR_LOG  WHERE BATCH_NUMBER=v_batch_number
          order by error_log_seq_id desc;
   OPEN v_error_log1 FOR
    SELECT batch_number as log_batch_number,settelment_number,payee_type,to_char(added_date,'DD-MM-YYYY') added_date,error_mesg 
          FROM  FIN_APP.BATCH_UPLOAD_ERROR_LOG  WHERE BATCH_NUMBER=v_batch_number
          order by error_log_seq_id desc;   
    
   ELSIF v_flag='PA' THEN
    
      IF v_batch_number IS NOT NULL THEN
        
       OPEN Payment_advice_Succes_Count(v_batch_number);
        FETCH Payment_advice_Succes_Count INTO v_succ_count;
          CLOSE Payment_advice_Succes_Count;

          
         OPEN Payment_advice_Failed_Count(v_batch_number);
           FETCH Payment_advice_Failed_Count INTO v_fail_count;
             CLOSE Payment_advice_Failed_Count;
          
      END IF;   
      
  OPEN  v_error_log_count FOR
    SELECT   NVL(v_succ_count,0) AS SUCCESS_COUNT,NVL(v_fail_count,0) AS FAILED_COUNT,
             (NVL(v_succ_count,0)+NVL(v_fail_count,0)) AS TOTAL_COUNT 
         FROM DUAL;
  OPEN v_error_log FOR
    SELECT batch_number as log_batch_number,settelment_number,payee_type,to_char(added_date,'DD-MM-YYYY') added_date,error_mesg 
           FROM  FIN_APP.PAYMENT_ERROR_LOG  WHERE BATCH_NUMBER=v_batch_number
           order by error_log_seq_id desc;
  OPEN v_error_log1 FOR
    SELECT batch_number as log_batch_number,settelment_number,payee_type,to_char(added_date,'DD-MM-YYYY') added_date,error_mesg
          FROM  FIN_APP.PAYMENT_ERROR_LOG  WHERE BATCH_NUMBER=v_batch_number
          order by error_log_seq_id desc;
   END IF;
      
        
END Upload_Payment_Error_log;
--========================================================================
--In Finance >> Payment Advice--while Generating Default & AL KHALIJI Formats 
--Added By venu babu(14-03-2018)
--=========================================================================
 PROCEDURE Gen_Detail_Cons_advice  (v_payment_seq_id IN CLOB,
                                    v_float_seq_id   IN tpa_float_account.float_seq_id%TYPE,
                                    v_added_by       IN NUMBER,
                                    v_batch_date     IN DATE,
                                    v_payment_type   IN VARCHAR2,
                                    v_pur_of_rem     IN VARCHAR2,
                                    v_pay_tras_to    IN VARCHAR2,
                                    v_bank_type      IN VARCHAR2,
                                    v_vol_base_type  IN VARCHAR2,
                                    v_deb_ban_seq_id IN VARCHAR2,
                                    v_rows_processed OUT INTEGER,
                                    v_resultset      OUT SYS_REFCURSOR,
                                    v_consolidated   OUT SYS_REFCURSOR
                                   ) 
AS
    v_filename                   VARCHAR2(50);
    v_bank_seq_id                tpa_bank_master.bank_seq_id%TYPE;
    v_count_of_payments          tpa_claims_payment.payment_seq_id%TYPE;
    v_batch_seq_id               tpa_bank_advice_batch.batch_seq_id%TYPE;
    v_bank_advice_file_name      tpa_bank_advice_batch.bank_advice_file_name%TYPE;
    str_tab                       ttk_util_pkg.str_table_type;
    v_where                      VARCHAR2(32767);
    v_sql_str                    VARCHAR2(32767);
    i                            NUMBER(2) := 0;
    v_exist_yn                   VARCHAR2(1) := 'N';
    v_unique                     varchar2(50);
    v_acc_num                    VARCHAR2(50);
    v_cons_str                   VARCHAR2(32767);
    
    TYPE TRANS_REF_NO IS TABLE OF fin_app.tpa_claims_payment.payee_name%TYPE INDEX BY BINARY_INTEGER;
    
    CURSOR Incurred_Currancy(v_payment_num   number) IS  
    SELECT cad.fnl_amt_currency_type 
           FROM clm_authorization_details cad
           JOIN tpa_claims_payment pay on (cad.claim_seq_id=pay.claim_seq_id)
           WHERE pay.payment_seq_id=TO_NUMBER(str_tab(i));
           
     V_PAYEE_NAME                 VARCHAR2(32767);
     v_payee_name_list            VARCHAR2(32767);
     v_payment_seq_list           varchar2(32767);
     TRANS_REF_Num                TRANS_REF_NO;
     v_colle_count                NUMBER(10);
     v_debit_iban_no              VARCHAR2(100);

BEGIN

  v_payment_seq_list := RTRIM(LTRIM (REPLACE(TO_CHAR(v_payment_seq_id),'|',','),','),',');
   
 str_tab := ttk_util_pkg.parse_leng_strng(v_payment_seq_id);
   
    SELECT A.bank_seq_id,A.ACCOUNT_NUMBER
      INTO v_bank_seq_id,v_acc_num
      FROM tpa_bank_accounts a
      JOIN tpa_float_account b
        ON (a.bank_acc_seq_id = b.bank_acc_seq_id)
     WHERE b.float_seq_id = v_float_seq_id;
  
 --- Added in CR-0311 added by venu babu    
     IF v_pay_tras_to ='QAR' THEN
      
        SELECT m.iban_no INTO v_debit_iban_no
         FROM fin_app.tpa_bank_master m where  m.Bank_Name= UPPER(v_deb_ban_seq_id);
     
     ELSIF v_pay_tras_to ='USD' THEN
     
        SELECT m.usd_iban_no INTO v_debit_iban_no
         FROM fin_app.tpa_bank_master m where m.Bank_Name= UPPER(v_deb_ban_seq_id);
     
     ELSIF v_pay_tras_to ='EUR' THEN
     
       SELECT m.euro_iban_no INTO v_debit_iban_no
        FROM fin_app.tpa_bank_master m where m.Bank_Name= UPPER(v_deb_ban_seq_id);
      
     ELSIF v_pay_tras_to ='GBP' THEN
      
      SELECT m.gbp_iban_no  INTO v_debit_iban_no
       FROM fin_app.tpa_bank_master m where m.Bank_Name= UPPER(v_deb_ban_seq_id);
     
     ELSIF v_pay_tras_to ='IIC' THEN
      
       SELECT m.iban_no INTO v_debit_iban_no
        FROM fin_app.tpa_bank_master m where  m.Bank_Name= UPPER(v_deb_ban_seq_id);
     
     END IF;
     
    IF (str_tab.FIRST IS NOT NULL) THEN
      IF str_tab.COUNT <= 8 THEN
        FOR i in str_tab.FIRST .. str_tab.LAST LOOP
          v_where := v_where || ' OR D.payment_seq_id = :bind_tab_' || i;
        END LOOP;
      ELSE
        v_where := ' OR D.payment_seq_id IN ( ' ||
                   REPLACE(SUBSTR(v_payment_seq_id,
                                  2,
                                  LENGTH(v_payment_seq_id) - 2),
                           '|',
                           ',') || ') ';
      END IF;
    END IF;
  
        
    IF v_where IS NOT NULL THEN
      v_where := ' AND (' || substr(v_where, 4) || ')';
    END IF;
    
  ---CRAETING BATCH FOR PAYMENT ADVICE
    IF v_bank_type = 'QATAR' THEN
      
      INSERT INTO tpa_bank_advice_batch
        (batch_seq_id,
         batch_date,
         batch_file_no,
         bank_seq_id,
         float_seq_id,
         added_by,
         added_date,
         bank_advice_file_name)
      VALUES
        (bank_advice_batch_seq.NEXTVAL,
         v_batch_date,
         'FILE_NO' || bank_advice_batch_file_seq.NEXTVAL,
         v_bank_seq_id,
         v_float_seq_id,
         v_added_by,
         SYSDATE,
         'DEFL' || '_' || TO_CHAR(v_batch_date, 'YYYYMMDD') || '_' ||
         bank_adv_batch_file_name_slno.NEXTVAL)
      RETURNING batch_seq_id, bank_advice_file_name INTO v_batch_seq_id, v_bank_advice_file_name;
   
   ELSIF v_bank_type = 'ALKHALIJI' THEN
    
    INSERT INTO tpa_bank_advice_batch
        (batch_seq_id,
         batch_date,
         batch_file_no,
         bank_seq_id,
         float_seq_id,
         added_by,
         added_date,
         bank_advice_file_name)
      VALUES
        (bank_advice_batch_seq.NEXTVAL,
         v_batch_date,
         'FILE_NO' || bank_advice_batch_file_seq.NEXTVAL,
         v_bank_seq_id,
         v_float_seq_id,
         v_added_by,
         SYSDATE,
         'ALKH' || '_' || TO_CHAR(v_batch_date, 'YYYYMMDD') || '_' ||
         bank_adv_batch_file_name_slno.NEXTVAL)
      RETURNING batch_seq_id, bank_advice_file_name INTO v_batch_seq_id, v_bank_advice_file_name;
   
   ELSIF v_bank_type = 'NATIONAL' THEN
    
    INSERT INTO tpa_bank_advice_batch
        (batch_seq_id,
         batch_date,
         batch_file_no,
         bank_seq_id,
         float_seq_id,
         added_by,
         added_date,
         bank_advice_file_name)
      VALUES
        (bank_advice_batch_seq.NEXTVAL,
         v_batch_date,
         'FILE_NO' || bank_advice_batch_file_seq.NEXTVAL,
         v_bank_seq_id,
         v_float_seq_id,
         v_added_by,
         SYSDATE,
         'QNBA' || '_' || TO_CHAR(v_batch_date, 'YYYYMMDD') || '_' ||
         bank_adv_batch_file_name_slno.NEXTVAL)
      RETURNING batch_seq_id, bank_advice_file_name INTO v_batch_seq_id, v_bank_advice_file_name;
   
   END IF;

    IF str_tab.FIRST IS NOT NULL THEN
      FORALL i IN str_tab.FIRST .. str_tab.LAST
        UPDATE tpa_claims_payment a
               SET A.bank_advice_batch    = bank_advice_batch_seq.CURRVAL
         WHERE payment_seq_id = TO_NUMBER(str_tab(i));
    END IF;
    
Apply_fast_and_vol_discounts(v_payment_seq_id,v_float_seq_id,v_batch_date,v_batch_seq_id,v_pay_tras_to,v_vol_base_type); 
    
     EXECUTE IMMEDIATE  'SELECT ttk_util_pkg.fn_decrypt(p.payee_name) from fin_app.tpa_claims_payment p
     where p.payment_seq_id IN ('||v_payment_seq_list||') AND p.claim_payment_status=''READY_TO_BANK''
     GROUP BY ttk_util_pkg.fn_decrypt(p.payee_name)' BULK COLLECT INTO TRANS_REF_Num ;
  
---Generating Transaction Reference Number For Consolidated 

     v_colle_count:=TRANS_REF_Num.COUNT;

  IF TRANS_REF_Num.COUNT IS NOT NULL and v_colle_count>0 THEN
      FOR I IN TRANS_REF_Num.FIRST..TRANS_REF_Num.LAST LOOP
        V_PAYEE_NAME:=TRANS_REF_Num(I);
        INSERT INTO FIN_APP.TRANS_REF_TABLE (BATCH_NUM,PAYEE_NAME,TRANS_NUM) VALUES (v_batch_seq_id,TRANS_REF_Num(I),PAYEE_TRANS_REF_NUM.NEXTVAL);
      END LOOP;
  END IF; 
  
  --- Generating File Name for all Formats
  IF v_bank_type ='QATAR' THEN
    
    v_filename := 'DEFL' || '-' ||substr(v_acc_num,-3,3)||'-'||
                    TO_CHAR(v_batch_date, 'DDMMYYYY-HH24MISS')||'-1';
  
  ELSIF v_bank_type = 'ALKHALIJI' AND v_pay_tras_to IN ('QAR','IIC') THEN
  
      v_filename := 'ALKL' || '-' ||substr(v_acc_num,-3,3)||'-'||
                    TO_CHAR(v_batch_date, 'DDMMYYYY-HH24MISS')||'-1';
                    
  ELSIF v_bank_type='ALKHALIJI' AND v_pay_tras_to IN ('USD','GBP','EUR') THEN
  
  v_filename := 'ALKF' || '-' ||substr(v_acc_num,-3,3)||'-'||
                    TO_CHAR(v_batch_date, 'DDMMYYYY-HH24MISS')||'-1';
  
  ELSIF v_bank_type='NATIONAL' AND v_pay_tras_to IN ('QAR','IIC','USD','GBP','EUR') THEN
  
  v_filename := 'QNBA' || '-' ||substr(v_acc_num,-3,3)||'-'||
                    TO_CHAR(v_batch_date, 'DDMMYYYY-HH24MISS')||'-1';
  
  END IF;
  
 --- Detail Report Query  For all Formats
 
 IF v_bank_type IN ( 'QATAR','ALKHALIJI','NATIONAL') THEN
  
                  
    v_sql_str:= 
    'select CASE WHEN '''||v_payment_type||''' IN (''TPTI'',''TPTE'') THEN ''TPT''
                 WHEN '''||v_payment_type||''' IN (''MGC'') THEN ''Manager''''s Cheque''
     ELSE '''||v_payment_type||''' END   as Payment_Type,
  
       case when '''||v_pay_tras_to||'''=''QAR'' THEN cad.final_app_amount - nvl(a.discount_amount,0) 
            when '''||v_pay_tras_to||'''=''USD'' THEN round((cad.final_app_amount - nvl(a.discount_amount,0))/3.64,2)
            when '''||v_pay_tras_to||'''=''IIC'' THEN  round((cad.final_app_amount - nvl(a.discount_amount,0))*cad.conversion_rate,2)
            when '''||v_pay_tras_to||'''=''EUR'' THEN   round(cad.PAY_AMT_IN_EURO-(nvl(a.discount_amount,0)/CONV_RATE_IN_EURO),2)
            when '''||v_pay_tras_to||'''=''GBP'' THEN   round(cad.PAY_AMT_IN_GBP -(nvl(a.discount_amount,0)/CONV_RATE_IN_GBP),2) 

           END as Transfer_Amount,
       case when '''||v_pay_tras_to||'''=''QAR'' THEN nvl(a.discount_amount,0) 
            when '''||v_pay_tras_to||'''=''USD'' THEN nvl(a.discount_amount,0)/3.64
            when '''||v_pay_tras_to||'''=''IIC'' THEN nvl(a.discount_amount,0)*nvl(cad.conversion_rate,1)
            when '''||v_pay_tras_to||'''=''EUR'' THEN nvl(a.discount_amount,0)/CONV_RATE_IN_EURO
            when '''||v_pay_tras_to||'''=''GBP'' THEN nvl(a.discount_amount,0)/CONV_RATE_IN_GBP END as disc_amt,
       case when '''||v_pay_tras_to||'''=''QAR'' THEN cad.final_app_amount 
            when '''||v_pay_tras_to||'''=''USD'' THEN NVL(cad.pay_amt_in_usd,round((cad.final_app_amount/3.64),2))
            when '''||v_pay_tras_to||'''=''IIC'' THEN  cad.converted_final_approved_amt 
            when '''||v_pay_tras_to||'''=''EUR'' THEN  cad.PAY_AMT_IN_EURO 
            when '''||v_pay_tras_to||'''=''GBP'' THEN  cad.PAY_AMT_IN_GBP END as Actual_Transfer_Amount,
         
       TBA.ACCOUNT_NUMBER  ins_comp_ac_no,
      '''||v_debit_iban_no||''' AS IBAN_NO,
       CASE WHEN cad.CLAIM_TYPE=''CTM'' THEN
          CASE WHEN NVL(clmb.claimfrom_gentype_id,''INSU'')!=''EMBA'' THEN
             (case when  A.TPA_CHEQUE_ISSUED_GENERAL_TYPE=''IQC'' THEN GR.GROUP_NAME  
                   WHEN  A.TPA_CHEQUE_ISSUED_GENERAL_TYPE=''IQI'' THEN tepg.insured_name
              END )
          ELSE
             EMB.EMBASSY_NAME
          END       
       ELSE 
		 CASE WHEN cad.CLAIM_TYPE=''CNH'' THEN
                 (case when NVL(cad.pymnt_to_type_id,''HOS'') =''PTN'' THEN
				 pi.partner_name
				 ELSE
				 HD.HOSP_NAME END)
		END		 
        END as benf_name,
       case when '''||v_pay_tras_to||'''=''USD'' THEN ''USD'' else ''QAR'' end as Debit_Curr,
       case when '''||v_pay_tras_to||'''=''QAR'' THEN ''QAR'' 
            when '''||v_pay_tras_to||'''=''USD'' THEN ''USD''
            when '''||v_pay_tras_to||'''=''IIC'' THEN  cad.req_amt_currency_type
            when '''||v_pay_tras_to||'''=''GBP'' THEN ''GBP''
            when '''||v_pay_tras_to||'''=''EUR'' THEN ''EUR''  
             END as Tra_Curr, 
      CASE WHEN cad.CLAIM_TYPE=''CTM'' THEN
        CASE WHEN NVL(clmb.claimfrom_gentype_id,''INSU'')=''LYVR'' THEN
               (case when  cad.payment_to=''IQC'' THEN ttk_util_pkg.fn_decrypt(cbdt.bank_name)  
                     WHEN  cad.payment_to=''IQI'' THEN ttk_util_pkg.fn_decrypt(mbdt.BANK_NAME)
                END )
             WHEN NVL(clmb.claimfrom_gentype_id,''INSU'')!=''EMBA'' THEN
               (case when  A.TPA_CHEQUE_ISSUED_GENERAL_TYPE=''IQC'' THEN ttk_util_pkg.fn_decrypt(cbdt.bank_name)  
                     WHEN  A.TPA_CHEQUE_ISSUED_GENERAL_TYPE=''IQI'' THEN ttk_util_pkg.fn_decrypt(mbdt.BANK_NAME)
                END ) 
        ELSE
         ttk_util_pkg.fn_decrypt(embb.BANK_NAME)
        END
      ELSE 
          CASE WHEN cad.CLAIM_TYPE=''CNH'' THEN
                 (case when NVL(cad.pymnt_to_type_id,''HOS'') =''PTN'' THEN
				 ttk_util_pkg.fn_decrypt(PAD.BANK_NAME)
				 ELSE
				 ttk_util_pkg.fn_decrypt(HAD.BANK_NAME) END)
          END 
     END as benf_bank_name,
       CASE WHEN cad.CLAIM_TYPE=''CTM'' THEN 
         CASE WHEN NVL(clmb.claimfrom_gentype_id,''INSU'')=''LYVR'' THEN
               (case when  cad.payment_to=''IQC'' THEN ttk_util_pkg.fn_decrypt(cbdt.BANK_IFSC)  
                     WHEN  cad.payment_to=''IQI'' THEN ttk_util_pkg.fn_decrypt(mbdt.BANK_IFSC)
                END )
              WHEN NVL(clmb.claimfrom_gentype_id,''INSU'')!=''EMBA'' THEN
             (case when  A.TPA_CHEQUE_ISSUED_GENERAL_TYPE=''IQC'' THEN UPPER(ttk_util_pkg.fn_decrypt(cbdt.BANK_IFSC))  
                   WHEN  A.TPA_CHEQUE_ISSUED_GENERAL_TYPE=''IQI'' THEN UPPER(ttk_util_pkg.fn_decrypt(mbdt.BANK_IFSC))
              END ) 
       ELSE     
        UPPER(ttk_util_pkg.fn_decrypt(embb.BANK_IFSC))     
       END                  
        ELSE
        
          CASE WHEN cad.CLAIM_TYPE=''CNH'' THEN
                 (case when NVL(cad.pymnt_to_type_id,''HOS'') =''PTN'' THEN
				 UPPER(ttk_util_pkg.fn_decrypt(PAD.BANK_IFSC))
				 ELSE
				 UPPER(ttk_util_pkg.fn_decrypt(HAD.BANK_IFSC)) END)
                 
             END 
        END   as benf_swift_code,
       CASE WHEN cad.CLAIM_TYPE=''CTM'' THEN 
         CASE WHEN NVL(clmb.claimfrom_gentype_id,''INSU'')=''LYVR'' THEN
               (case when  cad.payment_to=''IQC'' THEN (ttk_util_pkg.fn_decrypt (cbdt.bank_micr)) 
                     WHEN  cad.payment_to=''IQI'' THEN (ttk_util_pkg.fn_decrypt (mbdt.bank_micr))
                END )
              WHEN NVL(clmb.claimfrom_gentype_id,''INSU'')!=''EMBA'' THEN
             (case when A.TPA_CHEQUE_ISSUED_GENERAL_TYPE=''IQC'' THEN UPPER((ttk_util_pkg.fn_decrypt (cbdt.bank_micr)))
                   when A.TPA_CHEQUE_ISSUED_GENERAL_TYPE=''IQI'' THEN UPPER((ttk_util_pkg.fn_decrypt (mbdt.bank_micr))) 
              END)
         ELSE     
             UPPER(ttk_util_pkg.fn_decrypt (EMBB.BANK_MICR))  
         END 
       ELSE 
         CASE WHEN cad.CLAIM_TYPE=''CNH'' THEN
                 (case when NVL(cad.pymnt_to_type_id,''HOS'') =''PTN'' THEN
				 UPPER(ttk_util_pkg.fn_decrypt(PAD.bank_micr))
				 ELSE
				 UPPER(ttk_util_pkg.fn_decrypt(HAD.bank_micr)) END)
             END   
           END as benf_acc_number,      
       CASE WHEN cad.CLAIM_TYPE=''CTM'' THEN 
         CASE WHEN NVL(clmb.claimfrom_gentype_id,''INSU'')=''LYVR'' THEN
               (case when cad.payment_to=''IQC'' THEN 
                    CASE WHEN cbdt.ACCOUNT_IN_QATAR_YN=''N'' THEN cbdt.CITY_TYPE_ID ELSE  ccic.CITY_DESCRIPTION END
                  when cad.payment_to=''IQI'' THEN 
                    CASE WHEN mbdt.ACCOUNT_IN_QATAR_YN=''N'' THEN mbdt.CITY_TYPE_ID ELSE  mcic.CITY_DESCRIPTION END 
                 END) 
             WHEN NVL(clmb.claimfrom_gentype_id,''INSU'')!=''EMBA'' THEN
            (case when A.TPA_CHEQUE_ISSUED_GENERAL_TYPE=''IQC'' THEN 
                    CASE WHEN cbdt.ACCOUNT_IN_QATAR_YN=''N'' THEN cbdt.CITY_TYPE_ID ELSE  ccic.CITY_DESCRIPTION END
                  when A.TPA_CHEQUE_ISSUED_GENERAL_TYPE=''IQI'' THEN 
                    CASE WHEN mbdt.ACCOUNT_IN_QATAR_YN=''N'' THEN mbdt.CITY_TYPE_ID ELSE  mcic.CITY_DESCRIPTION END 
             END)
         ELSE    
           case when embb.ACCOUNT_IN_QATAR_YN=''N'' then embb.CITY_TYPE_ID else emcc.CITY_DESCRIPTION  end
         END 
       ELSE
       CASE WHEN cad.CLAIM_TYPE=''CNH'' THEN   
                 (case when NVL(cad.pymnt_to_type_id,''HOS'') =''PTN'' THEN
				  CASE WHEN pad.ACCOUNT_IN_QATAR_YN=''N'' THEN pcin.CITY_DESCRIPTION ELSE tpd.CITY_TYPE_ID   END 
				 ELSE
				  CASE WHEN had.ACCOUNT_IN_QATAR_YN =''N'' THEN tha.CITY_TYPE_ID ELSE hsci.CITY_DESCRIPTION  END
             END )
            
        END END  as benf_bank_add1,
       CASE WHEN cad.CLAIM_TYPE=''CTM'' THEN   
         CASE WHEN NVL(clmb.claimfrom_gentype_id,''INSU'')=''LYVR'' THEN
              (case when cad.payment_to=''IQC'' THEN 
                      CASE WHEN cbdt.ACCOUNT_IN_QATAR_YN=''N'' THEN cbdt.STATE_TYPE_ID ELSE  cstc.STATE_NAME END
                   when cad.payment_to=''IQI'' THEN
                     CASE WHEN mbdt.ACCOUNT_IN_QATAR_YN=''N'' THEN mbdt.STATE_TYPE_ID ELSE  mstc.STATE_NAME END 
               END)
              WHEN NVL(clmb.claimfrom_gentype_id,''INSU'')!=''EMBA'' THEN
             (case when A.TPA_CHEQUE_ISSUED_GENERAL_TYPE=''IQC'' THEN 
                      CASE WHEN cbdt.ACCOUNT_IN_QATAR_YN=''N'' THEN cbdt.STATE_TYPE_ID ELSE  cstc.STATE_NAME END
                   when A.TPA_CHEQUE_ISSUED_GENERAL_TYPE=''IQI'' THEN
                     CASE WHEN mbdt.ACCOUNT_IN_QATAR_YN=''N'' THEN mbdt.STATE_TYPE_ID ELSE  mstc.STATE_NAME END 
              END)
        ELSE
          embs.STATE_NAME
        END
        ELSE
           CASE WHEN cad.CLAIM_TYPE=''CNH'' THEN 
                 (case when NVL(cad.pymnt_to_type_id,''HOS'') =''PTN'' THEN
				   CASE WHEN pad.ACCOUNT_IN_QATAR_YN=''N'' THEN tpd.STATE_TYPE_ID ELSE pstc.STATE_NAME END
				 ELSE
				  CASE WHEN had.ACCOUNT_IN_QATAR_YN =''N'' THEN tha.STATE_TYPE_ID ELSE hsst.STATE_NAME END
             END )
        END END as benf_bank_add2, 
       case when cad.CLAIM_TYPE=''CTM'' THEN 
           CASE WHEN NVL(clmb.claimfrom_gentype_id,''INSU'')=''LYVR'' THEN
                (case when cad.payment_to=''IQC'' THEN UPPER(SUBSTR (ccuc.short_name,1,2))
                     when cad.payment_to=''IQI'' THEN UPPER(SUBSTR (mcuc.short_name,1,2)) 
                 END)
                WHEN NVL(clmb.claimfrom_gentype_id,''INSU'')!=''EMBA'' THEN
               (case when A.TPA_CHEQUE_ISSUED_GENERAL_TYPE=''IQC'' THEN ccuc.FIN_COUNTRY_CODE
                     when A.TPA_CHEQUE_ISSUED_GENERAL_TYPE=''IQI'' THEN mcuc.FIN_COUNTRY_CODE 
               END)  
            ELSE
                EMC.FIN_COUNTRY_CODE
            END    
         ELSE 
         CASE WHEN cad.CLAIM_TYPE=''CNH'' THEN
                 (case when NVL(cad.pymnt_to_type_id,''HOS'') =''PTN'' THEN
				 PCD.FIN_COUNTRY_CODE
				 ELSE
				  hpc.FIN_COUNTRY_CODE END)
             END 
         END as benf_bank_coun_code, 
       case when cad.CLAIM_TYPE=''CTM'' THEN 
           CASE WHEN NVL(clmb.claimfrom_gentype_id,''INSU'')=''LYVR'' THEN
               (case when cad.payment_to=''IQC'' THEN ccuc.COUNTRY_NAME
                     when cad.payment_to=''IQI'' THEN mcuc.COUNTRY_NAME
               END)
                WHEN NVL(clmb.claimfrom_gentype_id,''INSU'')!=''EMBA'' THEN
               (case when A.TPA_CHEQUE_ISSUED_GENERAL_TYPE=''IQC'' THEN ccuc.COUNTRY_NAME
                     when A.TPA_CHEQUE_ISSUED_GENERAL_TYPE=''IQI'' THEN mcuc.COUNTRY_NAME
               END)  
            ELSE
             EMC.COUNTRY_NAME
            END    
         ELSE 
         CASE WHEN cad.CLAIM_TYPE=''CNH'' THEN
                 (case when NVL(cad.pymnt_to_type_id,''HOS'') =''PTN'' THEN
				 PCD.COUNTRY_NAME
				 ELSE
				hpc.COUNTRY_NAME END)
             END 
         END as COUNTRY_NAME,
        TO_CHAR( TO_DATE ('''||v_batch_date||''',''DD-MM-YYYY'')+2) as Value_Date,
       ''OUR'' as it_charg,
       null as  pay_det1,
       null as  pay_det2,
       cad.claim_number as cus_ref_num,
     CASE WHEN '''||v_pur_of_rem||''' =''SUPP'' THEN ''14/SUPP''
          WHEN '''||v_pur_of_rem||''' =''PFLB'' THEN ''19/PFLB Medical Claims'' 
     END 
     as per_rem,
     '''||v_batch_seq_id||''' as batch_num,
     case when TTK_UTIL_PKG.FN_DECRYPT(A.payee_name)=ref.payee_name then ref.TRANS_NUM end as trans_ref_num
from fin_app.tpa_claims_payment a
       join fin_app.tpa_float_account tfa on (a.FLOAT_SEQ_ID=TFA.FLOAT_SEQ_ID)
       join tpa_bank_accounts tba on (TFA.BANK_ACC_SEQ_ID=TBA.BANK_ACC_SEQ_ID)
       join FIN_APP.TPA_BANK_MASTER tbm on (TBM.BANK_SEQ_ID=TBA.BANK_SEQ_ID)
       join APP.CLM_AUTHORIZATION_DETAILS cad on (CAD.CLAIM_SEQ_ID=a.CLAIM_SEQ_ID)
       JOIN APP.clm_batch_upload_details clmb on (clmb.clm_batch_seq_id=cad.clm_batch_seq_id)
       join tpa_enr_policy enr on (CAD.POLICY_SEQ_ID=ENR.POLICY_SEQ_ID)
       join TPA_ENR_POLICY_MEMBER tpm on (a.MEMBER_SEQ_ID=tpm.MEMBER_SEQ_ID)
       join tpa_enr_policy_group tepg on (tepg.policy_group_seq_id=tpm.policy_group_seq_id)
---Corporate Bank details Start
       left outer join tpa_enr_bank_dtls cbdt on (ENR.BANK_SEQ_ID=CBDT.BANK_SEQ_ID)
       left outer join TPA_CITY_CODE ccic on (cbdt.CITY_TYPE_ID=ccic.CITY_TYPE_ID)
       left outer join TPA_STATE_CODE cstc on (cbdt.STATE_TYPE_ID=cstc.STATE_TYPE_ID)
       left outer join TPA_COUNTRY_CODE ccuc on (cbdt.COUNTRY_TYPE_ID=ccuc.COUNTRY_ID)
------Corporate Ends
------Member Bank details Start
       left outer join tpa_enr_bank_dtls mbdt on (TEPG.BANK_SEQ_ID=MBDT.BANK_SEQ_ID)
       left outer join TPA_CITY_CODE mcic on (MBDT.CITY_TYPE_ID=mcic.CITY_TYPE_ID)
       left outer join TPA_STATE_CODE mstc on (MBDT.STATE_TYPE_ID=mstc.STATE_TYPE_ID)
       left outer join TPA_COUNTRY_CODE mcuc on (mbdt.COUNTRY_TYPE_ID=mcuc.COUNTRY_ID)
------Member Bank Details Ends       
       left outer join APP.CLM_HOSPITAL_DETAILS hd on (CAD.CLAIM_SEQ_ID=HD.CLAIM_SEQ_ID)
----Hospital Account details Starts       
       left outer join APP.TPA_HOSP_ACCOUNT_DETAILS had on (HD.HOSP_SEQ_ID=HAD.HOSP_SEQ_ID)
       left outer join app.TPA_HOSP_ADDRESS tha on (HAD.HOSP_BANK_SEQ_ID=THA.HOSP_BANK_SEQ_ID AND THA.HOSP_SEQ_ID IS NULL)
       left outer join TPA_CITY_CODE hsci on (tha.CITY_TYPE_ID=hsci.CITY_TYPE_ID)
       LEFT OUTER JOIN TPA_STATE_CODE hsst on (tha.STATE_TYPE_ID=hsst.STATE_TYPE_ID)
       left outer join TPA_COUNTRY_CODE hpc on (THA.COUNTRY_ID=hpc.COUNTRY_ID)
----Hospital Account details Ends       
       left outer join TPA_GROUP_REGISTRATION gr on (gr.GROUP_REG_SEQ_ID=enr.GROUP_REG_SEQ_ID)
-----Partner Account Details Start	     
       LEFT OUTER JOIN TPA_PARTNER_INFO pi ON (cad.ptnr_seq_id=pi.ptnr_seq_id)
	     LEFT OUTER JOIN TPA_PARTNER_ACCOUNT_DETAILS pad ON (pi.ptnr_seq_id=pad.ptnr_seq_id)
       LEFT OUTER JOIN TPA_PARTNER_ADDRESS  tpd on (pad.ptnr_bank_seq_id=tpd.ptnr_bank_seq_id)
       left outer join TPA_CITY_CODE pcin on (pcin.CITY_TYPE_ID=tpd.CITY_TYPE_ID)
       LEFT OUTER JOIN TPA_STATE_CODE pstc on (pstc.STATE_TYPE_ID=tpd.STATE_TYPE_ID)
       LEFT OUTER JOIN TPA_COUNTRY_CODE pcd on (tpd.country_id=pcd.country_id)
--------Partner Account Details ends       
       LEFT OUTER JOIN tpa_bank_advice_batch batc on (batc.batch_seq_id=a.bank_advice_batch)
       LEFT OUTER JOIN FIN_APP.trans_ref_table ref ON (ref.batch_num=batc.batch_seq_id) AND TTK_UTIL_PKG.FN_DECRYPT(a.payee_name)=ref.payee_name
 ---- Embassy Account details     
       LEFT OUTER JOIN APP.tpa_enr_embassy_registration EMB ON (EMB.embassy_seq_id=cad.embassy_seq_id)
       LEFT OUTER JOIN APP.tpa_enr_bank_dtls embb on (embb.bank_seq_id=emb.bank_seq_id)
       LEFT OUTER JOIN APP.TPA_COUNTRY_CODE EMC ON (emc.COUNTRY_ID=EMB.COUNTRY_ID)
       LEFT OUTER JOIN APP.tpa_city_code emcc on (emcc.CITY_TYPE_ID=embb.CITY_TYPE_ID)
       LEFT OUTER JOIN app.tpa_state_code embs on (embb.state_type_id=embs.state_type_id)
        WHERE a.float_seq_id = :v_float_seq_id ' ||
                    regexp_replace(v_where, 'D\.', 'A.') ||
                    ' AND a.claim_payment_status = ''READY_TO_BANK'' '; 
                    
 v_count_of_payments := str_tab.COUNT;
 

         IF str_tab.FIRST IS NOT NULL THEN
              IF str_tab.COUNT <= 8  THEN
                CASE str_tab.COUNT
                  WHEN 1 THEN  OPEN v_resultset FOR v_sql_str  USING v_float_seq_id, str_tab(1);
                  WHEN 2 THEN  OPEN v_resultset FOR v_sql_str  USING v_float_seq_id, str_tab(1), str_tab(2);
                  WHEN 3 THEN  OPEN v_resultset FOR v_sql_str  USING v_float_seq_id, str_tab(1), str_tab(2), str_tab(3);
                  WHEN 4 THEN  OPEN v_resultset FOR v_sql_str  USING v_float_seq_id, str_tab(1), str_tab(2), str_tab(3), str_tab(4);
                  WHEN 5 THEN  OPEN v_resultset FOR v_sql_str  USING v_float_seq_id, str_tab(1), str_tab(2), str_tab(3), str_tab(4), str_tab(5);
                  WHEN 6 THEN  OPEN v_resultset FOR v_sql_str  USING v_float_seq_id, str_tab(1), str_tab(2), str_tab(3), str_tab(4), str_tab(5), str_tab(6);
                  WHEN 7 THEN  OPEN v_resultset FOR v_sql_str  USING v_float_seq_id, str_tab(1), str_tab(2), str_tab(3), str_tab(4), str_tab(5), str_tab(6), str_tab(7);
                  WHEN 8 THEN  OPEN v_resultset FOR v_sql_str  USING v_float_seq_id, str_tab(1), str_tab(2), str_tab(3), str_tab(4), str_tab(5), str_tab(6), str_tab(7), str_tab(8);
                END CASE;
              ELSIF str_tab.COUNT > 8  THEN
                OPEN v_resultset FOR v_sql_str
                  USING v_float_seq_id;
              ELSE 
                OPEN v_resultset FOR v_sql_str
                  USING v_float_seq_id,v_float_seq_id;    
              END IF;
        END IF;  
END IF;

--- 1.2 )Default Format Consolidated Report Query

IF v_bank_type='QATAR' THEN

    v_cons_str :='  WITH DISC_TAB AS (SELECT BATCH_NUM,SUM(DISC_AMT) as vol_disc,HOSP_SEQ_ID
                        FROM TPA_MONTHLY_DISC_AMTS
                         WHERE BATCH_NUM='||v_batch_seq_id||'
                    GROUP BY HOSP_SEQ_ID,BATCH_NUM)
					    
    SELECT Payment_Type,UPPER(Iban_No) AS Iban_No,(Transfer_Amount-nvl(vol.vol_disc,0)) AS Transfer_Amount,Debit_Curr,Tra_Curr,Benf_name
                        ,country_name,Value_Date,Benf_Bank_name,UPPER(Benf_Swift_Code) AS Benf_Swift_Code,UPPER(Benf_Bank_Acc_number) AS Benf_Bank_Acc_number,benf_bank_add1,benf_bank_add2,
                    pay_det1,pay_det2,it_charg,per_rem,trans_ref_num,benf_bank_coun_code
                    FROM  
                   (SELECT Payment_Type,Iban_No,sum(Transfer_Amount) AS Transfer_Amount,Debit_Curr,Tra_Curr,Benf_name
                        ,country_name,Value_Date,Benf_Bank_name,Benf_Swift_Code,Benf_Bank_Acc_number,benf_bank_add1,benf_bank_add2,
                    pay_det1,pay_det2,it_charg,per_rem,trans_ref_num,benf_bank_coun_code
                    FROM 
                   (select  
                    CASE WHEN '''||v_payment_type||''' IN (''TPTI'',''TPTE'') THEN ''TPT''
                         WHEN '''||v_payment_type||''' IN (''MGC'') THEN ''Manager''''s Cheque''
                    ELSE '''||v_payment_type||''' END
                    as Payment_Type,     
                    '''||v_debit_iban_no||''' AS Iban_No ,
                    case when '''||v_pay_tras_to||'''=''QAR'' THEN ca.final_app_amount - nvl(tcp.discount_amount,0) 
                         when '''||v_pay_tras_to||'''=''USD'' THEN  round(nvl(ca.pay_amt_in_usd,round((ca.final_app_amount/3.64),2))-round(nvl(tcp.discount_amount,0)/3.64,2),2)
                         when '''||v_pay_tras_to||'''=''IIC'' THEN   round(ca.converted_final_approved_amt - round(nvl(tcp.discount_amount,0)*nvl(ca.conversion_rate,1),2),2) 
                         when '''||v_pay_tras_to||'''=''EUR'' THEN  round(ca.pay_amt_in_euro - (nvl(tcp.discount_amount,0)/conv_rate_in_euro),2)
                         when '''||v_pay_tras_to||'''=''GBP'' THEN  round(ca.Pay_Amt_In_Gbp - (nvl(tcp.discount_amount,0)/conv_rate_in_gbp),2)  END as Transfer_Amount,
                   
                    case when '''||v_pay_tras_to||'''=''USD'' THEN''USD'' ELSE ''QAR'' END as Debit_Curr,
                    case when '''||v_pay_tras_to||'''=''QAR'' THEN ''QAR'' 
                         when '''||v_pay_tras_to||'''=''USD'' THEN ''USD''
                         when '''||v_pay_tras_to||'''=''IIC'' THEN  NVL(ca.req_amt_currency_type,''QAR'') 
                         when '''||v_pay_tras_to||'''=''EUR'' THEN ''EUR''
                         when '''||v_pay_tras_to||'''=''GBP'' THEN ''GBP'' END as Tra_Curr,
                    ttk_util_pkg.fn_decrypt(tcp.payee_name) as Benf_name,
                    TO_CHAR( TO_DATE ('''||v_batch_date||''',''DD-MM-YYYY'')+2) as Value_Date,
                    CASE WHEN tcp.claim_type = ''CTM'' THEN
                        (CASE WHEN e.enrol_type_id = ''COR'' THEN
                            CASE WHEN NVL(clmb.claimfrom_gentype_id,''INSU'')!=''EMBA'' THEN
                              (CASE  WHEN TCP.TPA_CHEQUE_ISSUED_GENERAL_TYPE = ''IQI'' THEN  ttk_util_pkg.fn_decrypt(t.BANK_NAME)
                                     WHEN TCP.TPA_CHEQUE_ISSUED_GENERAL_TYPE = ''IQC'' THEN  ttk_util_pkg.fn_decrypt(s.BANK_NAME)  END)
                             ELSE
                                     ttk_util_pkg.fn_decrypt(embb.BANK_NAME)
                             END
                         ELSE ttk_util_pkg.fn_decrypt(t.BANK_NAME) END)
                    ELSE
                           CASE ca.pymnt_to_type_id WHEN ''PTN'' THEN ttk_util_pkg.fn_decrypt(pa.bank_name)  ELSE ttk_util_pkg.fn_decrypt(w.bank_name)  END
                   end as Benf_Bank_name,
                   CASE  WHEN tcp.claim_type = ''CTM'' THEN
                     (CASE WHEN e.enrol_type_id = ''COR'' THEN
                         CASE WHEN NVL(clmb.claimfrom_gentype_id,''INSU'')!=''EMBA'' THEN
                            (CASE WHEN TCP.TPA_CHEQUE_ISSUED_GENERAL_TYPE = ''IQI'' THEN  ttk_util_pkg.fn_decrypt(t.bank_ifsc)
                                  WHEN TCP.TPA_CHEQUE_ISSUED_GENERAL_TYPE = ''IQC'' THEN  ttk_util_pkg.fn_decrypt(S.bank_ifsc) END)
                        ELSE
                                ttk_util_pkg.fn_decrypt(embb.BANK_IFSC)  
                        END
                      ELSE ttk_util_pkg.fn_decrypt(t.bank_ifsc) END)
                    ELSE
                       CASE ca.pymnt_to_type_id WHEN ''PTN'' THEN ttk_util_pkg.fn_decrypt(pa.bank_ifsc) 
                                        ELSE ttk_util_pkg.fn_decrypt(w.bank_ifsc) 
                   END
                   end as Benf_Swift_Code,
                   CASE  WHEN tcp.claim_type = ''CTM'' THEN
                         (CASE WHEN e.enrol_type_id = ''COR'' THEN
                             CASE WHEN NVL(clmb.claimfrom_gentype_id,''INSU'')!=''EMBA'' THEN
                              (CASE WHEN TCP.TPA_CHEQUE_ISSUED_GENERAL_TYPE = ''IQI'' THEN  ttk_util_pkg.fn_decrypt(t.bank_micr)
                                    WHEN TCP.TPA_CHEQUE_ISSUED_GENERAL_TYPE = ''IQC'' THEN  ttk_util_pkg.fn_decrypt(S.Bank_Micr) END)
                            ELSE
                                      ttk_util_pkg.fn_decrypt(EMBB.BANK_MICR) 
                            END
                          
                          ELSE ttk_util_pkg.fn_decrypt(t.bank_micr) END)
                   ELSE
                      CASE ca.pymnt_to_type_id WHEN ''PTN'' THEN ttk_util_pkg.fn_decrypt(pa.bank_micr) 
                                               ELSE ttk_util_pkg.fn_decrypt(w.bank_micr) 
                   END
                  end as Benf_Bank_Acc_number,
                  CASE WHEN ca.CLAIM_TYPE=''CTM'' THEN 
                    CASE WHEN NVL(clmb.claimfrom_gentype_id,''INSU'')!=''EMBA'' THEN
                         (case when TCP.TPA_CHEQUE_ISSUED_GENERAL_TYPE=''IQC'' THEN 
                           CASE WHEN S.ACCOUNT_IN_QATAR_YN=''N'' THEN S.CITY_TYPE_ID  ELSE coci.city_description END
                               when TCP.TPA_CHEQUE_ISSUED_GENERAL_TYPE=''IQI'' THEN 
                           case when t.ACCOUNT_IN_QATAR_YN =''N'' THEN t.CITY_TYPE_ID ELSE meci.city_description END      
                          END)
                     ELSE
                          CASE WHEN embb.ACCOUNT_IN_QATAR_YN=''N'' THEN  embb.CITY_TYPE_ID ELSE emcc.city_description  END
                     END     
                          
                  ELSE
                   CASE WHEN ca.CLAIM_TYPE=''CNH'' THEN
                  (case when NVL(ca.pymnt_to_type_id,''HOS'') =''PTN'' THEN
                  CASE WHEN pa.ACCOUNT_IN_QATAR_YN=''N'' THEN paa.CITY_TYPE_ID  ELSE pacc.city_description END 
                  ELSE
                  CASE WHEN W.ACCOUNT_IN_QATAR_YN=''N'' THEN haa.CITY_TYPE_ID ELSE hacc.city_description END
                  END)
                  END 
            
                  END  as benf_bank_add1,
                  CASE WHEN ca.CLAIM_TYPE=''CTM'' THEN
                     CASE WHEN NVL(clmb.claimfrom_gentype_id,''INSU'')!=''EMBA'' THEN
                        (case when TCP.TPA_CHEQUE_ISSUED_GENERAL_TYPE=''IQC'' THEN 
                           CASE WHEN S.ACCOUNT_IN_QATAR_YN=''N'' THEN S.STATE_TYPE_ID  ELSE cors.STATE_NAME END
                             when TCP.TPA_CHEQUE_ISSUED_GENERAL_TYPE=''IQI'' THEN 
                               case when t.ACCOUNT_IN_QATAR_YN =''N'' THEN t.STATE_TYPE_ID ELSE mems.STATE_NAME END
                        END)
                     ELSE
                       CASE WHEN embb.ACCOUNT_IN_QATAR_YN=''N'' THEN embb.STATE_TYPE_ID ELSE embs.STATE_NAME END
                     END  
                  ELSE
                     CASE WHEN ca.CLAIM_TYPE=''CNH'' THEN
                 (case when NVL(ca.pymnt_to_type_id,''HOS'') =''PTN'' THEN 
                     CASE WHEN pa.ACCOUNT_IN_QATAR_YN=''N'' THEN  paa.STATE_TYPE_ID ELSE pas.STATE_NAME END
                       ELSE
                      CASE WHEN W.ACCOUNT_IN_QATAR_YN=''N'' THEN haa.STATE_TYPE_ID ELSE  has.STATE_NAME END
                       END)
                  END 
                  END as benf_bank_add2,
                  CASE WHEN ca.CLAIM_TYPE=''CTM'' THEN
                    CASE WHEN NVL(clmb.claimfrom_gentype_id,''INSU'')!=''EMBA'' THEN
                           (case when TCP.TPA_CHEQUE_ISSUED_GENERAL_TYPE=''IQC'' THEN corc.country_name
                                 when TCP.TPA_CHEQUE_ISSUED_GENERAL_TYPE=''IQI'' THEN memc.country_name
                                 END)
                   ELSE
                                 EMC.country_name
                   END
                  
                  ELSE
                      CASE WHEN ca.CLAIM_TYPE=''CNH'' THEN
                 (case when NVL(ca.pymnt_to_type_id,''HOS'') =''PTN'' THEN pac.country_name
                       ELSE
                       hac.country_name END)
                       END 
                        END as country_name,
        CASE WHEN ca.CLAIM_TYPE=''CTM'' THEN
            CASE WHEN NVL(clmb.claimfrom_gentype_id,''INSU'')!=''EMBA'' THEN
                   (case when TCP.TPA_CHEQUE_ISSUED_GENERAL_TYPE=''IQC'' THEN corc.FIN_COUNTRY_CODE
                         when TCP.TPA_CHEQUE_ISSUED_GENERAL_TYPE=''IQI'' THEN memc.FIN_COUNTRY_CODE
                                 END)
                   ELSE
                         EMC.FIN_COUNTRY_CODE
                   END
                 
                  ELSE
                      CASE WHEN ca.CLAIM_TYPE=''CNH'' THEN
                 (case when NVL(ca.pymnt_to_type_id,''HOS'') =''PTN'' THEN pac.FIN_COUNTRY_CODE
                       ELSE
                        hac.FIN_COUNTRY_CODE  END)
                       END 
                        END as benf_bank_coun_code,
                         ''OUR'' as it_charg,
                          null as pay_det1,
                          null as pay_det2,
             CASE WHEN '''||v_pur_of_rem||''' =''SUPP'' THEN ''14/SUPP''
                  WHEN '''||v_pur_of_rem||''' =''PFLB'' THEN ''19/PFLB Medical Claims'' 
               END 
               as per_rem,
               '''||v_batch_seq_id||''' as batch_num,
               case when TTK_UTIL_PKG.FN_DECRYPT(tcp.payee_name)=ref.payee_name then ref.TRANS_NUM end as trans_ref_num,
                 tcp.hosp_seq_id
          from fin_app.tpa_claims_payment tcp
          JOIN app.clm_authorization_details ca on (ca.claim_seq_id=tcp.claim_seq_id)
          JOIN APP.clm_batch_upload_details clmb on (clmb.clm_batch_seq_id=ca.clm_batch_seq_id)
          JOIN TPA_ENR_POLICY_MEMBER b ON (tcp.MEMBER_SEQ_ID=b.MEMBER_SEQ_ID)
          ----Corporate Bank details Start
          JOIN tpa_enr_policy E ON (tcp.policy_seq_id = E.policy_seq_id)
          LEFT OUTER JOIN tpa_enr_bank_dtls S ON (E.bank_seq_id = S.bank_seq_id)
          LEFT OUTER JOIN tpa_country_code corc ON (corc.country_id=s.country_type_id)
          LEFT OUTER JOIN tpa_state_code cors ON (s.state_type_id=cors.state_type_id)
          LEFT OUTER JOIN tpa_city_code coci on (s.city_type_id=coci.city_type_id)
       -------Corporate Bank Details End 
       -------Member Bank Details Start  
          JOIN tpa_enr_policy_group R ON (B.policy_group_seq_id = R.policy_group_seq_id)
          LEFT OUTER JOIN tpa_enr_bank_dtls T ON (R.bank_seq_id = T.bank_seq_id)
          LEFT OUTER JOIN tpa_country_code memc ON (memc.country_id=t.country_type_id)
          LEFT OUTER JOIN tpa_state_code mems ON (t.state_type_id=mems.state_type_id)
          LEFT OUTER JOIN tpa_city_code meci on (t.city_type_id=meci.city_type_id)
      -------Member Bank Details    
          LEFT OUTER JOIN fin_app.tpa_payment_checks_details pcd on (tcp.payment_seq_id = pcd.payment_seq_id and pcd.v_csr_flag = 1)
          LEFT OUTER JOIN fin_app.tpa_claims_check cc on (pcd.claims_chk_seq_id = cc.claims_chk_seq_id and cc.v_csr_flag = 1)
          LEFT OUTER JOIN fin_app.tpa_float_account tfa on (tcp.float_seq_id = tfa.float_seq_id)
          left outer join fin_app.tpa_bank_accounts ba on (tfa.bank_acc_seq_id = ba.bank_acc_seq_id)
          LEFT OUTER JOIN tpa_bank_master h ON (h.bank_seq_id = ba.bank_seq_id)
          left outer join app.tpa_enr_bank_dtls bd  on (ba.bank_seq_id = bd.bank_seq_id)
          LEFT OUTER JOIN tpa_group_registration L   ON (L.group_reg_seq_id = tcp.group_reg_seq_id)
       ---- Hospital Account Details Starts   
          LEFT OUTER JOIN tpa_hosp_info O  ON (tcp.hosp_seq_id = O.hosp_seq_id)
          LEFT OUTER JOIN tpa_hosp_account_details W  ON (O.hosp_seq_id = w.hosp_seq_id)
          LEFT OUTER JOIN tpa_hosp_address haa ON (W.HOSP_BANK_SEQ_ID=haa.HOSP_BANK_SEQ_ID)
          LEFT OUTER JOIN tpa_country_code hac ON (haa.country_id=hac.country_id)
          LEFT OUTER JOIN tpa_state_code has ON (haa.state_type_id=has.state_type_id)
          LEFT OUTER JOIN tpa_city_code hacc ON (haa.city_type_id=hacc.city_type_id)
        ---- Hospital Account Details Ends
        ---- Partner Account Details Starts 
         LEFT OUTER JOIN tpa_partner_info pi ON (tcp.ptnr_seq_id=pi.ptnr_seq_id)
          LEFT OUTER JOIN tpa_partner_account_details pa ON (pi.ptnr_seq_id=pa.ptnr_seq_id)
          LEFT OUTER JOIN tpa_partner_address paa ON (paa.PTNR_BANK_SEQ_ID=pa.PTNR_BANK_SEQ_ID)
          LEFT OUTER JOIN tpa_country_code pac ON (pac.country_id=paa.country_id)
          LEFT OUTER JOIN tpa_state_code pas ON (paa.state_type_id=pas.state_type_id)
          LEFT OUTER JOIN tpa_city_code pacc on (paa.city_type_id=pacc.city_type_id)
        --- partner Account Details Ends  
          LEFT OUTER JOIN tpa_bank_advice_batch batc on (batc.batch_seq_id=tcp.bank_advice_batch)
          LEFT OUTER JOIN FIN_APP.trans_ref_table ref ON (ref.batch_num=batc.batch_seq_id) AND TTK_UTIL_PKG.FN_DECRYPT(tcp.payee_name)=ref.payee_name
          LEFT OUTER JOIN APP.tpa_enr_embassy_registration EMB ON (EMB.embassy_seq_id=ca.embassy_seq_id)
          LEFT OUTER JOIN APP.tpa_enr_bank_dtls embb on (embb.bank_seq_id=emb.bank_seq_id)
          LEFT OUTER JOIN APP.TPA_COUNTRY_CODE EMC ON (emc.COUNTRY_ID=EMB.COUNTRY_ID)
          LEFT OUTER JOIN APP.tpa_city_code emcc on (emcc.CITY_TYPE_ID=embb.CITY_TYPE_ID)
          LEFT OUTER JOIN app.tpa_state_code embs on (embb.state_type_id=embs.state_type_id)
          
    WHERE tcp.float_seq_id = :v_float_seq_id ' ||
                    regexp_replace(v_where, 'D\.', 'tcp.') ||
                    ' AND tcp.claim_payment_status  = ''READY_TO_BANK'')
                      group by  Payment_Type,Iban_No,Debit_Curr,Tra_Curr,Benf_name,
                        country_name,Value_Date,Benf_Bank_name,Benf_Swift_Code,Benf_Bank_Acc_number,benf_bank_add1,benf_bank_add2
                  ,pay_det1,pay_det2,it_charg,per_rem,trans_ref_num,benf_bank_coun_code) A
                    LEFT OUTER JOIN DISC_TAB vol on (vol.hosp_seq_id=hosp_seq_id)';



    IF str_tab.FIRST IS NOT NULL THEN
      IF str_tab.COUNT <= 8 THEN
        CASE str_tab.COUNT
          WHEN 1 THEN  OPEN v_consolidated FOR v_cons_str USING v_float_seq_id, str_tab(1);
          WHEN 2 THEN  OPEN v_consolidated FOR v_cons_str USING v_float_seq_id, str_tab(1), str_tab(2);
          WHEN 3 THEN  OPEN v_consolidated FOR v_cons_str USING v_float_seq_id, str_tab(1), str_tab(2), str_tab(3);
          WHEN 4 THEN  OPEN v_consolidated FOR v_cons_str USING v_float_seq_id, str_tab(1), str_tab(2), str_tab(3), str_tab(4);
          WHEN 5 THEN  OPEN v_consolidated FOR v_cons_str USING v_float_seq_id, str_tab(1), str_tab(2), str_tab(3), str_tab(4), str_tab(5);
          WHEN 6 THEN  OPEN v_consolidated FOR v_cons_str USING v_float_seq_id, str_tab(1), str_tab(2), str_tab(3), str_tab(4), str_tab(5), str_tab(6);
          WHEN 7 THEN  OPEN v_consolidated FOR v_cons_str USING v_float_seq_id, str_tab(1), str_tab(2), str_tab(3), str_tab(4), str_tab(5), str_tab(6), str_tab(7);
          WHEN 8 THEN  OPEN v_consolidated FOR v_cons_str USING v_float_seq_id, str_tab(1), str_tab(2), str_tab(3), str_tab(4), str_tab(5), str_tab(6), str_tab(7), str_tab(8);
        END CASE;
      ELSIF str_tab.COUNT > 8  THEN
        OPEN v_consolidated FOR v_cons_str
          USING v_float_seq_id;
      ELSE 
        OPEN v_consolidated FOR v_cons_str
          USING v_float_seq_id,v_float_seq_id;    
      END IF;   
  END IF;

--Al khaliji Local Consolidated Report Query

ELSIF v_bank_type='ALKHALIJI' and v_pay_tras_to IN ('QAR','IIC') THEN
    
    v_cons_str :='WITH DISC_TAB AS (SELECT BATCH_NUM,SUM(DISC_AMT) as vol_disc,HOSP_SEQ_ID
                        FROM TPA_MONTHLY_DISC_AMTS
                         WHERE BATCH_NUM='||v_batch_seq_id||'
                    GROUP BY HOSP_SEQ_ID,BATCH_NUM)
    
       SELECT (Transfer_Amount - NVL(vol_disc,0)) AS Transfer_Amount,Tra_Curr,Benf_name,UPPER(Benf_Bank_name) AS Benf_Bank_name,benf_bank_add2,
                    UPPER(Benf_Swift_Code) AS Benf_Swift_Code,UPPER(Benf_Acc_number) AS Benf_Acc_number,benf_bank_add1,it_charg,per_rem,trans_ref_num,a.batch_num
                    FROM  
                 (SELECT sum(Transfer_Amount) AS Transfer_Amount,Tra_Curr,Benf_name,Benf_Bank_name,benf_bank_add2,
                    Benf_Swift_Code,Benf_Bank_Acc_number as Benf_Acc_number,benf_bank_add1,it_charg,per_rem,trans_ref_num,batch_num
                    FROM  
                   (select  
                    case when '''||v_pay_tras_to||'''=''QAR'' THEN ca.final_app_amount -nvl(tcp.discount_amount,0)
                         when '''||v_pay_tras_to||'''=''USD'' THEN  round(nvl(ca.pay_amt_in_usd,round((ca.final_app_amount/3.64),2))-round(nvl(tcp.discount_amount,0)/3.64,2),2)
                         when '''||v_pay_tras_to||'''=''IIC'' THEN  round(ca.converted_final_approved_amt-round(nvl(tcp.discount_amount,0)*nvl(ca.conversion_rate,1),2),2)
                         when '''||v_pay_tras_to||'''=''EUR'' THEN  round(ca.PAY_AMT_IN_EURO/ca.conv_rate_in_euro,2)
                         when '''||v_pay_tras_to||'''=''GBP'' THEN   round(ca.PAY_AMT_IN_GBP/ca.Conv_Rate_In_Gbp,2) END as Transfer_Amount,
                    case when '''||v_pay_tras_to||'''=''USD'' THEN ''USD'' ELSE ''QAR'' END as Debit_Curr,
                    case when '''||v_pay_tras_to||'''=''QAR'' THEN ''QAR'' 
                         when '''||v_pay_tras_to||'''=''USD'' THEN ''USD''
                         when '''||v_pay_tras_to||'''=''IIC'' THEN  ca.req_amt_currency_type END as Tra_Curr,
                    ttk_util_pkg.fn_decrypt(tcp.payee_name) as Benf_name,
                    CASE WHEN tcp.claim_type = ''CTM'' THEN
                        (CASE WHEN e.enrol_type_id = ''COR'' THEN
                            CASE WHEN NVL(clmb.claimfrom_gentype_id,''INSU'')!=''EMBA'' THEN
                              (CASE  WHEN TCP.TPA_CHEQUE_ISSUED_GENERAL_TYPE = ''IQI'' THEN  
                                ttk_util_pkg.fn_decrypt(t.BANK_IFSC)||''-''||ttk_util_pkg.fn_decrypt(t.BANK_NAME)
                                     WHEN TCP.TPA_CHEQUE_ISSUED_GENERAL_TYPE = ''IQC'' THEN  
                                       ttk_util_pkg.fn_decrypt(s.BANK_IFSC)||''-''||ttk_util_pkg.fn_decrypt(s.BANK_NAME)  END)
                             ELSE
                                     ttk_util_pkg.fn_decrypt(embb.BANK_IFSC)||''-''||ttk_util_pkg.fn_decrypt(embb.BANK_NAME)
                             END
                         ELSE ttk_util_pkg.fn_decrypt(t.BANK_IFSC)||''-''||ttk_util_pkg.fn_decrypt(t.BANK_NAME) END)
                    ELSE
                           CASE ca.pymnt_to_type_id WHEN ''PTN'' THEN 
                            ttk_util_pkg.fn_decrypt(pa.bank_ifsc)||''-''|| ttk_util_pkg.fn_decrypt(pa.bank_name) 
                              ELSE 
                                 ttk_util_pkg.fn_decrypt(w.bank_ifsc)||''-''||ttk_util_pkg.fn_decrypt(w.bank_name)  END
                   end as Benf_Bank_name,
                   CASE  WHEN tcp.claim_type = ''CTM'' THEN
                     (CASE WHEN e.enrol_type_id = ''COR'' THEN
                         CASE WHEN NVL(clmb.claimfrom_gentype_id,''INSU'')!=''EMBA'' THEN
                            (CASE WHEN TCP.TPA_CHEQUE_ISSUED_GENERAL_TYPE = ''IQI'' THEN  ttk_util_pkg.fn_decrypt(t.bank_ifsc)
                                  WHEN TCP.TPA_CHEQUE_ISSUED_GENERAL_TYPE = ''IQC'' THEN  ttk_util_pkg.fn_decrypt(S.bank_ifsc) END)
                        ELSE
                                ttk_util_pkg.fn_decrypt(embb.BANK_IFSC)  
                        END
                      ELSE ttk_util_pkg.fn_decrypt(t.bank_ifsc) END)
                    ELSE
                       CASE ca.pymnt_to_type_id WHEN ''PTN'' THEN ttk_util_pkg.fn_decrypt(pa.bank_ifsc) 
                                        ELSE ttk_util_pkg.fn_decrypt(w.bank_ifsc) 
                   END
                   end as Benf_Swift_Code,
                   CASE  WHEN tcp.claim_type = ''CTM'' THEN
                         (CASE WHEN e.enrol_type_id = ''COR'' THEN
                             CASE WHEN NVL(clmb.claimfrom_gentype_id,''INSU'')!=''EMBA'' THEN
                              (CASE WHEN TCP.TPA_CHEQUE_ISSUED_GENERAL_TYPE = ''IQI'' THEN  ttk_util_pkg.fn_decrypt(t.bank_micr)
                                    WHEN TCP.TPA_CHEQUE_ISSUED_GENERAL_TYPE = ''IQC'' THEN  ttk_util_pkg.fn_decrypt(S.Bank_Micr) END)
                            ELSE
                                      ttk_util_pkg.fn_decrypt(EMBB.BANK_MICR) 
                            END
                          
                          ELSE ttk_util_pkg.fn_decrypt(t.bank_micr) END)
                   ELSE
                      CASE ca.pymnt_to_type_id WHEN ''PTN'' THEN ttk_util_pkg.fn_decrypt(pa.bank_micr) 
                                               ELSE ttk_util_pkg.fn_decrypt(w.bank_micr) 
                   END
                  end as Benf_Bank_Acc_number,
                  CASE WHEN ca.CLAIM_TYPE=''CTM'' THEN 
                    CASE WHEN NVL(clmb.claimfrom_gentype_id,''INSU'')!=''EMBA'' THEN
                         (case when TCP.TPA_CHEQUE_ISSUED_GENERAL_TYPE=''IQC'' THEN 
                                CASE WHEN S.ACCOUNT_IN_QATAR_YN=''N'' THEN S.CITY_TYPE_ID ELSE corc.CITY_DESCRIPTION END
                               when TCP.TPA_CHEQUE_ISSUED_GENERAL_TYPE=''IQI'' THEN 
                                 CASE WHEN T.ACCOUNT_IN_QATAR_YN=''N'' THEN T.CITY_TYPE_ID  ELSE memc.city_description END
                          END)
                     ELSE
                          emcc.CITY_DESCRIPTION
                     END     
                          
                  ELSE
                   CASE WHEN ca.CLAIM_TYPE=''CNH'' THEN
                  (case when NVL(ca.pymnt_to_type_id,''HOS'') =''PTN'' THEN 
                        CASE WHEN PA.ACCOUNT_IN_QATAR_YN=''N'' THEN paa.CITY_TYPE_ID  ELSE pacc.CITY_DESCRIPTION END 
                  ELSE
                    CASE WHEN W.ACCOUNT_IN_QATAR_YN=''N'' THEN haa.CITY_TYPE_ID  ELSE hacc.CITY_DESCRIPTION END    END)
                  END 
            
                  END  as benf_bank_add1,----------------------------------
                  CASE WHEN ca.CLAIM_TYPE=''CTM'' THEN 
                    CASE WHEN NVL(clmb.claimfrom_gentype_id,''INSU'')!=''EMBA'' THEN
                         (case when TCP.TPA_CHEQUE_ISSUED_GENERAL_TYPE=''IQC'' THEN 
                                CASE WHEN S.ACCOUNT_IN_QATAR_YN=''N'' THEN S.STATE_TYPE_ID ELSE cors.STATE_NAME END
                               when TCP.TPA_CHEQUE_ISSUED_GENERAL_TYPE=''IQI'' THEN 
                                 CASE WHEN T.ACCOUNT_IN_QATAR_YN=''N'' THEN T.STATE_TYPE_ID  ELSE mems.STATE_NAME END
                          END)
                     ELSE
                          emcc.CITY_DESCRIPTION
                     END     
                          
                  ELSE
                   CASE WHEN ca.CLAIM_TYPE=''CNH'' THEN
                  (case when NVL(ca.pymnt_to_type_id,''HOS'') =''PTN'' THEN 
                        CASE WHEN PA.ACCOUNT_IN_QATAR_YN=''N'' THEN paa.STATE_TYPE_ID  ELSE pas.STATE_NAME END 
                  ELSE
                    CASE WHEN W.ACCOUNT_IN_QATAR_YN=''N'' THEN haa.STATE_TYPE_ID  ELSE has.STATE_NAME END    END)
                  END 
            
                  END  as benf_bank_add2,----------------------------------
                         ''OUR'' as it_charg,
             CASE WHEN '''||v_pur_of_rem||''' =''SUPP'' THEN ''14/SUPP''
                  WHEN '''||v_pur_of_rem||''' =''PFLB'' THEN ''19/PFLB Medical Claims'' 
               END as per_rem,
               '''||v_batch_seq_id||''' as batch_num,
               tcp.hosp_seq_id,
               case when TTK_UTIL_PKG.FN_DECRYPT(tcp.payee_name)=ref.payee_name then ref.TRANS_NUM end as trans_ref_num
          from fin_app.tpa_claims_payment tcp
          JOIN app.clm_authorization_details ca on (ca.claim_seq_id=tcp.claim_seq_id)
          JOIN APP.clm_batch_upload_details clmb on (clmb.clm_batch_seq_id=ca.clm_batch_seq_id)
          JOIN tpa_enr_policy_member B ON (tcp.member_seq_id = B.member_seq_id)
          JOIN tpa_enr_policy E ON (tcp.policy_seq_id = E.policy_seq_id)
          ---Corporate
          LEFT OUTER JOIN tpa_enr_bank_dtls S ON (E.bank_seq_id = S.bank_seq_id)
          LEFT OUTER JOIN tpa_city_code corc on (s.city_type_id=corc.city_type_id)
          LEFT OUTER JOIN tpa_state_code cors on (s.state_type_id=cors.state_type_id) 
          left outer join tpa_country_code cocc on (cocc.country_id=s.country_type_id)
          --------- 
          ---Member
          LEFT OUTER JOIN tpa_enr_policy_group R ON (B.policy_group_seq_id = R.policy_group_seq_id)
          LEFT OUTER JOIN tpa_enr_bank_dtls T ON (R.bank_seq_id = T.bank_seq_id)
          LEFT OUTER JOIN tpa_city_code memc on (t.city_type_id=memc.city_type_id)
          LEFT OUTER JOIN tpa_state_code mems on (t.state_type_id=mems.state_type_id) 
          left outer join tpa_country_code mecc on (mecc.country_id=t.country_type_id)
         ------
          LEFT OUTER JOIN fin_app.tpa_payment_checks_details pcd on (tcp.payment_seq_id = pcd.payment_seq_id and pcd.v_csr_flag = 1)
          LEFT OUTER JOIN fin_app.tpa_claims_check cc on (pcd.claims_chk_seq_id = cc.claims_chk_seq_id and cc.v_csr_flag = 1)
          LEFT OUTER JOIN fin_app.tpa_float_account tfa on (tcp.float_seq_id = tfa.float_seq_id)
          left outer join fin_app.tpa_bank_accounts ba on (tfa.bank_acc_seq_id = ba.bank_acc_seq_id)
          LEFT OUTER JOIN tpa_bank_master h ON (h.bank_seq_id = ba.bank_seq_id)
          left outer join app.tpa_enr_bank_dtls bd  on (ba.bank_seq_id = bd.bank_seq_id)
          LEFT OUTER JOIN tpa_group_registration L   ON (L.group_reg_seq_id = tcp.group_reg_seq_id)
          
          ---provider
          LEFT OUTER JOIN tpa_hosp_info O  ON (tcp.hosp_seq_id = O.hosp_seq_id)
          LEFT OUTER JOIN tpa_hosp_account_details W  ON (O.hosp_seq_id = w.hosp_seq_id)
          LEFT OUTER JOIN tpa_hosp_address haa ON (W.HOSP_BANK_SEQ_ID=haa.HOSP_BANK_SEQ_ID)
          LEFT OUTER JOIN tpa_country_code hac ON (haa.country_id=hac.country_id)
          LEFT OUTER JOIN tpa_state_code has ON (haa.state_type_id=has.state_type_id)
          LEFT OUTER JOIN tpa_city_code hacc ON (haa.city_type_id=hacc.city_type_id)
          
          --Partner
          LEFT OUTER JOIN tpa_partner_info pi ON (tcp.ptnr_seq_id=pi.ptnr_seq_id)
          LEFT OUTER JOIN tpa_partner_account_details pa ON (pi.ptnr_seq_id=pa.ptnr_seq_id)
          LEFT OUTER JOIN tpa_partner_address paa ON (paa.PTNR_BANK_SEQ_ID=pa.PTNR_BANK_SEQ_ID)
          LEFT OUTER JOIN tpa_country_code pac ON (pac.country_id=paa.country_id)
          LEFT OUTER JOIN tpa_state_code pas ON (paa.state_type_id=pas.state_type_id)
          LEFT OUTER JOIN tpa_city_code pacc on (paa.city_type_id=pacc.city_type_id)
          LEFT OUTER JOIN tpa_bank_advice_batch batc on (batc.batch_seq_id=tcp.bank_advice_batch)
          LEFT OUTER JOIN FIN_APP.trans_ref_table ref ON (ref.batch_num=batc.batch_seq_id) AND TTK_UTIL_PKG.FN_DECRYPT(tcp.payee_name)=ref.payee_name
          LEFT OUTER JOIN APP.tpa_enr_embassy_registration EMB ON (EMB.embassy_seq_id=ca.embassy_seq_id)
          LEFT OUTER JOIN APP.tpa_enr_bank_dtls embb on (embb.bank_seq_id=emb.bank_seq_id)
          LEFT OUTER JOIN APP.TPA_COUNTRY_CODE EMC ON (emc.COUNTRY_ID=EMB.COUNTRY_ID)
          LEFT OUTER JOIN APP.tpa_city_code emcc on (emcc.CITY_TYPE_ID=embb.CITY_TYPE_ID)
          LEFT OUTER JOIN app.tpa_state_code embs on (embb.state_type_id=embs.state_type_id)
    WHERE tcp.float_seq_id = :v_float_seq_id ' ||
                    regexp_replace(v_where, 'D\.', 'tcp.') ||
                    ' AND tcp.claim_payment_status  = ''READY_TO_BANK'')
                      group by  Debit_Curr,Tra_Curr,Benf_name,Benf_Bank_name,Benf_Swift_Code,Benf_Bank_Acc_number,benf_bank_add1
                  ,Benf_Bank_Acc_number,it_charg,per_rem,trans_ref_num,benf_bank_add2,batch_num)A 
                  LEFT OUTER JOIN DISC_TAB vol on (vol.hosp_seq_id=hosp_seq_id)';  

IF v_bank_type = 'ALKHALIJI' THEN
    IF str_tab.FIRST IS NOT NULL THEN
      IF str_tab.COUNT <= 8 AND v_bank_type = 'ALKHALIJI' THEN
        CASE str_tab.COUNT
          WHEN 1 THEN  OPEN v_consolidated FOR v_cons_str USING v_float_seq_id, str_tab(1);
          WHEN 2 THEN  OPEN v_consolidated FOR v_cons_str USING v_float_seq_id, str_tab(1), str_tab(2);
          WHEN 3 THEN  OPEN v_consolidated FOR v_cons_str USING v_float_seq_id, str_tab(1), str_tab(2), str_tab(3);
          WHEN 4 THEN  OPEN v_consolidated FOR v_cons_str USING v_float_seq_id, str_tab(1), str_tab(2), str_tab(3), str_tab(4);
          WHEN 5 THEN  OPEN v_consolidated FOR v_cons_str USING v_float_seq_id, str_tab(1), str_tab(2), str_tab(3), str_tab(4), str_tab(5);
          WHEN 6 THEN  OPEN v_consolidated FOR v_cons_str USING v_float_seq_id, str_tab(1), str_tab(2), str_tab(3), str_tab(4), str_tab(5), str_tab(6);
          WHEN 7 THEN  OPEN v_consolidated FOR v_cons_str USING v_float_seq_id, str_tab(1), str_tab(2), str_tab(3), str_tab(4), str_tab(5), str_tab(6), str_tab(7);
          WHEN 8 THEN  OPEN v_consolidated FOR v_cons_str USING v_float_seq_id, str_tab(1), str_tab(2), str_tab(3), str_tab(4), str_tab(5), str_tab(6), str_tab(7), str_tab(8);
        END CASE;
      ELSIF str_tab.COUNT > 8 AND v_bank_type = 'ALKHALIJI' THEN
        OPEN v_consolidated FOR v_cons_str
          USING v_float_seq_id;
      ELSE 
        OPEN v_consolidated FOR v_cons_str
          USING v_float_seq_id,v_float_seq_id;    
      END IF;   
  END IF;
END IF;

--Al khaliji Foriegn Consolidated Report Query

ELSIF v_bank_type='ALKHALIJI' and v_pay_tras_to IN ('USD','GBP','EUR') THEN
 v_cons_str :='WITH DISC_TAB AS (SELECT BATCH_NUM,SUM(DISC_AMT) as vol_disc,HOSP_SEQ_ID
                        FROM TPA_MONTHLY_DISC_AMTS
                         WHERE BATCH_NUM='||v_batch_seq_id||'
                    GROUP BY HOSP_SEQ_ID,BATCH_NUM)
            SELECT (Transfer_Amount - nvl(vol.vol_disc,0)) AS Transfer_Amount,Tra_Curr,Benf_name,
                  Benf_Bank_name,UPPER(Benf_Swift_Code) AS Benf_Swift_Code,UPPER(Benf_Acc_number) AS Benf_Acc_number,benf_bank_add1,
                  UPPER(Benf_Bank_Acc_number) AS Benf_Bank_Acc_number,it_charg,per_rem,trans_ref_num,pay_cat,benf_bank_add2,A.batch_num
                  FROM (

                 SELECT sum(Transfer_Amount)AS Transfer_Amount,Tra_Curr,Benf_name,
                         Benf_Bank_name,Benf_Swift_Code,Benf_Bank_Acc_number as Benf_Acc_number,benf_bank_add1,
                    Benf_Bank_Acc_number,it_charg,per_rem,trans_ref_num,pay_cat,benf_bank_add2,batch_num
                    FROM  
                   (select  
                     case when '''||v_pay_tras_to||'''=''USD'' THEN nvl(ca.pay_amt_in_usd-nvl((TCP.discount_amount/3.64),0),round((FINAL_APP_AMOUNT-TCP.discount_amount/3.64),2))
                          when '''||v_pay_tras_to||'''=''EUR'' THEN  ROUND(ca.PAY_AMT_IN_EURO-nvl(tcp.discount_amount/ca.conv_rate_in_euro,0),2) 
                          when '''||v_pay_tras_to||'''=''GBP'' THEN  ROUND(ca.PAY_AMT_IN_GBP-nvl((tcp.discount_amount/ca.conv_rate_in_gbp),0),2)  END as Transfer_Amount,
                     case when '''||v_pay_tras_to||'''=''USD'' THEN ''USD'' 
                          when '''||v_pay_tras_to||'''=''EUR'' THEN ''EUR'' 
                          when '''||v_pay_tras_to||'''=''GBP'' THEN ''GBP'' END as Tra_Curr,
                    ttk_util_pkg.fn_decrypt(tcp.payee_name) as Benf_name,
                    CASE WHEN tcp.claim_type = ''CTM'' THEN
                        (CASE WHEN e.enrol_type_id = ''COR'' THEN
                            CASE WHEN NVL(clmb.claimfrom_gentype_id,''INSU'')!=''EMBA'' THEN
                              (CASE  WHEN TCP.TPA_CHEQUE_ISSUED_GENERAL_TYPE = ''IQI'' THEN  ttk_util_pkg.fn_decrypt(t.BANK_NAME)
                                     WHEN TCP.TPA_CHEQUE_ISSUED_GENERAL_TYPE = ''IQC'' THEN  ttk_util_pkg.fn_decrypt(s.BANK_NAME)  END)
                             ELSE
                                     ttk_util_pkg.fn_decrypt(embb.BANK_NAME)
                             END
                         ELSE ttk_util_pkg.fn_decrypt(t.BANK_NAME) END)
                    ELSE
                           CASE ca.pymnt_to_type_id WHEN ''PTN'' THEN ttk_util_pkg.fn_decrypt(pa.bank_name)  ELSE ttk_util_pkg.fn_decrypt(w.bank_name)  END
                   end as Benf_Bank_name,
                   CASE  WHEN tcp.claim_type = ''CTM'' THEN
                     (CASE WHEN e.enrol_type_id = ''COR'' THEN
                         CASE WHEN NVL(clmb.claimfrom_gentype_id,''INSU'')!=''EMBA'' THEN
                            (CASE WHEN TCP.TPA_CHEQUE_ISSUED_GENERAL_TYPE = ''IQI'' THEN  ttk_util_pkg.fn_decrypt(t.bank_ifsc)
                                  WHEN TCP.TPA_CHEQUE_ISSUED_GENERAL_TYPE = ''IQC'' THEN  ttk_util_pkg.fn_decrypt(S.bank_ifsc) END)
                        ELSE
                                ttk_util_pkg.fn_decrypt(embb.BANK_IFSC)  
                        END
                      ELSE ttk_util_pkg.fn_decrypt(t.bank_ifsc) END)
                    ELSE
                       CASE ca.pymnt_to_type_id WHEN ''PTN'' THEN ttk_util_pkg.fn_decrypt(pa.bank_ifsc) 
                                        ELSE ttk_util_pkg.fn_decrypt(w.bank_ifsc) 
                   END
                   end as Benf_Swift_Code,
                   CASE  WHEN tcp.claim_type = ''CTM'' THEN
                         (CASE WHEN e.enrol_type_id = ''COR'' THEN
                             CASE WHEN NVL(clmb.claimfrom_gentype_id,''INSU'')!=''EMBA'' THEN
                              (CASE WHEN TCP.TPA_CHEQUE_ISSUED_GENERAL_TYPE = ''IQI'' THEN  ttk_util_pkg.fn_decrypt(t.bank_micr)
                                    WHEN TCP.TPA_CHEQUE_ISSUED_GENERAL_TYPE = ''IQC'' THEN  ttk_util_pkg.fn_decrypt(S.Bank_Micr) END)
                            ELSE
                                      ttk_util_pkg.fn_decrypt(EMBB.BANK_MICR) 
                            END
                          
                          ELSE ttk_util_pkg.fn_decrypt(t.bank_micr) END)
                   ELSE
                      CASE ca.pymnt_to_type_id WHEN ''PTN'' THEN ttk_util_pkg.fn_decrypt(pa.bank_micr) 
                                               ELSE ttk_util_pkg.fn_decrypt(w.bank_micr) 
                   END
                  end as Benf_Bank_Acc_number,
                  CASE WHEN ca.CLAIM_TYPE=''CTM'' THEN 
                    CASE WHEN NVL(clmb.claimfrom_gentype_id,''INSU'')!=''EMBA'' THEN
                         (case when TCP.TPA_CHEQUE_ISSUED_GENERAL_TYPE=''IQC'' THEN 
                              CASE WHEN S.ACCOUNT_IN_QATAR_YN=''N'' THEN S.state_type_id ELSE CST.state_name END
                               when TCP.TPA_CHEQUE_ISSUED_GENERAL_TYPE=''IQI'' THEN 
                              CASE WHEN T.ACCOUNT_IN_QATAR_YN=''N'' THEN T.state_type_id ELSE MST.state_name END   
                          END)
                     ELSE
                          embs.state_name
                     END     
                          
                  ELSE
                   CASE WHEN ca.CLAIM_TYPE=''CNH'' THEN
                  (case when NVL(ca.pymnt_to_type_id,''HOS'') =''PTN'' THEN
                  CASE WHEN PA.ACCOUNT_IN_QATAR_YN =''N'' THEN paa.state_type_id ELSE pas.state_name END
                  ELSE
                   CASE WHEN W.ACCOUNT_IN_QATAR_YN =''N'' THEN HAA.state_type_id ELSE has.state_name END
                  END  )
            
                  END  END as benf_bank_add1,
                  CASE WHEN ca.CLAIM_TYPE=''CTM'' THEN
                    CASE WHEN NVL(clmb.claimfrom_gentype_id,''INSU'')!=''EMBA'' THEN
                           (case when TCP.TPA_CHEQUE_ISSUED_GENERAL_TYPE=''IQC'' THEN 
                                              CCO.country_name
                                 when TCP.TPA_CHEQUE_ISSUED_GENERAL_TYPE=''IQI'' THEN 
                                          MCO.country_name
                                 END)
                   ELSE
                                 EMC.country_name
                   END
                  
                  ELSE
                      CASE WHEN ca.CLAIM_TYPE=''CNH'' THEN
                 (case when NVL(ca.pymnt_to_type_id,''HOS'') =''PTN'' THEN pac.country_name
                       ELSE
                       hac.country_name END)
                       END 
                        END as benf_bank_add2,
                         ''OUR'' as it_charg,
                          null as pay_det1,
                          null as pay_det2,
             CASE WHEN '''||v_pur_of_rem||''' =''SUPP'' THEN ''14/SUPP''
                  WHEN '''||v_pur_of_rem||''' =''PFLB'' THEN ''19/PFLB Medical Claims'' 
               END 
               as per_rem,'''||v_batch_seq_id||''' as batch_num,
               ''3-Merchandise insurance/Claims paid'' AS pay_cat,
               case when TTK_UTIL_PKG.FN_DECRYPT(tcp.payee_name)=ref.payee_name then ref.TRANS_NUM end as trans_ref_num
          from fin_app.tpa_claims_payment tcp
          JOIN app.clm_authorization_details ca on (ca.claim_seq_id=tcp.claim_seq_id)
          JOIN APP.clm_batch_upload_details clmb on (clmb.clm_batch_seq_id=ca.clm_batch_seq_id)
          ----------CORPORATE START
          JOIN tpa_enr_policy E ON (tcp.policy_seq_id = E.policy_seq_id)
          LEFT OUTER JOIN tpa_enr_bank_dtls S ON (E.bank_seq_id = S.bank_seq_id)
          JOIN TPA_ADDRESS GRAD ON (GRAD.GROUP_REG_SEQ_ID=E.GROUP_REG_SEQ_ID)
          LEFT OUTER JOIN tpa_city_code CCI on (CCI.city_type_id=GRAD.city_type_id)
          LEFT OUTER JOIN TPA_STATE_CODE  CST ON (CST.state_type_id=GRAD.state_type_id)
          LEFT OUTER JOIN TPA_COUNTRY_CODE CCO ON (CCO.country_id=GRAD.country_id)
          ----------CORPORATE ENDS
          ----- INDIVIDUAL START
          JOIN TPA_ENR_POLICY_MEMBER MEM ON (tcp.MEMBER_SEQ_ID=MEM.MEMBER_SEQ_ID)
          JOIN tpa_enr_policy_group R ON (MEM.POLICY_GROUP_SEQ_ID = R.POLICY_GROUP_SEQ_ID)
          LEFT OUTER JOIN tpa_enr_bank_dtls T ON (R.bank_seq_id = T.bank_seq_id)
          LEFT OUTER JOIN tpa_city_code MCI on (MCI.city_type_id=T.city_type_id)
          LEFT OUTER JOIN TPA_STATE_CODE  MST ON (MST.state_type_id=T.state_type_id)
          LEFT OUTER JOIN TPA_COUNTRY_CODE MCO ON (MCO.country_id=T.country_type_id)
          ------ INDIVIDUAL END 
          LEFT OUTER JOIN fin_app.tpa_payment_checks_details pcd on (tcp.payment_seq_id = pcd.payment_seq_id and pcd.v_csr_flag = 1)
          LEFT OUTER JOIN fin_app.tpa_claims_check cc on (pcd.claims_chk_seq_id = cc.claims_chk_seq_id and cc.v_csr_flag = 1)
          LEFT OUTER JOIN fin_app.tpa_float_account tfa on (tcp.float_seq_id = tfa.float_seq_id)
          left outer join fin_app.tpa_bank_accounts ba on (tfa.bank_acc_seq_id = ba.bank_acc_seq_id)
          LEFT OUTER JOIN tpa_bank_master h ON (h.bank_seq_id = ba.bank_seq_id)
          left outer join app.tpa_enr_bank_dtls bd  on (ba.bank_seq_id = bd.bank_seq_id)
          LEFT OUTER JOIN tpa_group_registration L   ON (L.group_reg_seq_id = tcp.group_reg_seq_id)
          ---- HOSPITAL ACCOUNT DETAILS STARTS
          LEFT OUTER JOIN tpa_hosp_info O  ON (tcp.hosp_seq_id = O.hosp_seq_id)
          LEFT OUTER JOIN tpa_hosp_account_details W  ON (O.hosp_seq_id = w.hosp_seq_id)
          LEFT OUTER JOIN tpa_hosp_address haa ON (w.HOSP_BANK_SEQ_ID=haa.HOSP_BANK_SEQ_ID)
          LEFT OUTER JOIN tpa_country_code hac ON (haa.country_id=hac.country_id)
          LEFT OUTER JOIN tpa_state_code has ON (haa.state_type_id=has.state_type_id)
          LEFT OUTER JOIN tpa_city_code hacc ON (haa.city_type_id=hacc.city_type_id)
          ---- HOSPITAL ACCOUNT DETAILS ENDS
          -----PARTNER ACCOUNT DETAILS STARTS
          LEFT OUTER JOIN tpa_partner_info pi ON (tcp.ptnr_seq_id=pi.ptnr_seq_id)
          LEFT OUTER JOIN tpa_partner_account_details pa ON (pi.ptnr_seq_id=pa.ptnr_seq_id)
          LEFT OUTER JOIN tpa_partner_address paa ON (paa.PTNR_BANK_SEQ_ID=pa.PTNR_BANK_SEQ_ID)
          LEFT OUTER JOIN tpa_country_code pac ON (pac.country_id=paa.country_id)
          LEFT OUTER JOIN tpa_state_code pas ON (paa.state_type_id=pas.state_type_id)
          LEFT OUTER JOIN tpa_city_code pacc on (paa.city_type_id=pacc.city_type_id)
          -----PARTNER ACCOUNT DETAILS ENDS
          LEFT OUTER JOIN tpa_bank_advice_batch batc on (batc.batch_seq_id=tcp.bank_advice_batch)
          LEFT OUTER JOIN FIN_APP.trans_ref_table ref ON (ref.batch_num=batc.batch_seq_id) AND TTK_UTIL_PKG.FN_DECRYPT(tcp.payee_name)=ref.payee_name
          LEFT OUTER JOIN APP.tpa_enr_embassy_registration EMB ON (EMB.embassy_seq_id=ca.embassy_seq_id)
          LEFT OUTER JOIN APP.tpa_enr_bank_dtls embb on (embb.bank_seq_id=emb.bank_seq_id)
          LEFT OUTER JOIN APP.TPA_COUNTRY_CODE EMC ON (emc.COUNTRY_ID=EMB.COUNTRY_ID)
          LEFT OUTER JOIN APP.tpa_city_code emcc on (emcc.CITY_TYPE_ID=embb.CITY_TYPE_ID)
          LEFT OUTER JOIN app.tpa_state_code embs on (embb.state_type_id=embs.state_type_id)
    WHERE tcp.float_seq_id = :v_float_seq_id ' ||
                    regexp_replace(v_where, 'D\.', 'tcp.') ||
                    ' AND tcp.claim_payment_status  = ''READY_TO_BANK'')
                      group by  Tra_Curr,Benf_name,Benf_Bank_name,Benf_Swift_Code,Benf_Bank_Acc_number,benf_bank_add1
                  ,Benf_Bank_Acc_number,it_charg,per_rem,trans_ref_num,pay_cat,benf_bank_add2,batch_num )A 
                   LEFT OUTER JOIN DISC_TAB vol on (vol.hosp_seq_id=hosp_seq_id)'; 

        IF str_tab.FIRST IS NOT NULL THEN
          IF str_tab.COUNT <= 8  THEN
            CASE str_tab.COUNT
              WHEN 1 THEN  OPEN v_consolidated FOR v_cons_str USING v_float_seq_id, str_tab(1);
              WHEN 2 THEN  OPEN v_consolidated FOR v_cons_str USING v_float_seq_id, str_tab(1), str_tab(2);
              WHEN 3 THEN  OPEN v_consolidated FOR v_cons_str USING v_float_seq_id, str_tab(1), str_tab(2), str_tab(3);
              WHEN 4 THEN  OPEN v_consolidated FOR v_cons_str USING v_float_seq_id, str_tab(1), str_tab(2), str_tab(3), str_tab(4);
              WHEN 5 THEN  OPEN v_consolidated FOR v_cons_str USING v_float_seq_id, str_tab(1), str_tab(2), str_tab(3), str_tab(4), str_tab(5);
              WHEN 6 THEN  OPEN v_consolidated FOR v_cons_str USING v_float_seq_id, str_tab(1), str_tab(2), str_tab(3), str_tab(4), str_tab(5), str_tab(6);
              WHEN 7 THEN  OPEN v_consolidated FOR v_cons_str USING v_float_seq_id, str_tab(1), str_tab(2), str_tab(3), str_tab(4), str_tab(5), str_tab(6), str_tab(7);
              WHEN 8 THEN  OPEN v_consolidated FOR v_cons_str USING v_float_seq_id, str_tab(1), str_tab(2), str_tab(3), str_tab(4), str_tab(5), str_tab(6), str_tab(7), str_tab(8);
            END CASE;
          ELSIF str_tab.COUNT > 8  THEN
            OPEN v_consolidated FOR v_cons_str
              USING v_float_seq_id;
          ELSE 
            OPEN v_consolidated FOR v_cons_str
              USING v_float_seq_id,v_float_seq_id;    
          END IF;   
      END IF;


ELSIF v_bank_type='NATIONAL' THEN 

v_cons_str :='WITH DISC_TAB AS (SELECT BATCH_NUM,SUM(DISC_AMT) as vol_disc,HOSP_SEQ_ID
                        FROM TPA_MONTHLY_DISC_AMTS
                         WHERE BATCH_NUM='||v_batch_seq_id||'
                    GROUP BY HOSP_SEQ_ID,BATCH_NUM)
                    
            SELECT (Transfer_Amount - nvl(vol.vol_disc,0)) AS Transfer_Amount,Tra_Curr,Benf_name,pay_reason,
                  Benf_Bank_name,UPPER(Benf_Swift_Code) AS Benf_Swift_Code,UPPER(Benf_Acc_number) AS Benf_Acc_number,benf_bank_add1,purpose_of_code,product_code,
                  UPPER(Benf_Bank_Acc_number) AS Benf_Bank_Acc_number,it_charg,trans_ref_num,benf_bank_add2,UPPER(Debit_iban_no) AS Debit_iban_no,Value_Date,Intermediary_Name,Clearing_Code
                  FROM (
                    
                 SELECT sum(Transfer_Amount)AS Transfer_Amount,Tra_Curr,Benf_name,Clearing_Code,Intermediary_Name,
                         Benf_Bank_name,Benf_Swift_Code,Benf_Bank_Acc_number as Benf_Acc_number,benf_bank_add1,pay_reason,purpose_of_code,
                    Benf_Bank_Acc_number,it_charg,trans_ref_num,benf_bank_add2,Debit_iban_no,Value_Date,
                    case when '''||v_pay_tras_to||''' =''QAR'' THEN CASE WHEN  Benf_Bank_name like ''QATAR NATIONAL%'' THEN ''BT''  ELSE ''LBT'' END
                         when '''||v_pay_tras_to||'''!=''QAR'' THEN ''TT''else null end  as product_code
                    FROM  
                   (select  
                     case when '''||v_pay_tras_to||'''=''USD'' THEN nvl(ca.pay_amt_in_usd-(nvl(TCP.discount_amount,0)/3.64),round((FINAL_APP_AMOUNT-nvl(TCP.discount_amount,0)/3.64),2))
                          when '''||v_pay_tras_to||'''=''EUR'' THEN  ROUND(ca.PAY_AMT_IN_EURO-(NVL(tcp.discount_amount,0)/ca.conv_rate_in_euro),2) 
                          when '''||v_pay_tras_to||'''=''GBP'' THEN  ROUND(ca.PAY_AMT_IN_GBP-(nvl(tcp.discount_amount,0)/ca.conv_rate_in_gbp),2) 
                          when '''||v_pay_tras_to||'''=''QAR'' THEN  (tcp.approved_amount -nvl(tcp.discount_amount,0))
                          when '''||v_pay_tras_to||'''=''IIC'' THEN  (tcp.approved_amount -nvl(tcp.discount_amount,0))/ca.conversion_rate END as Transfer_Amount,                       
                     case when '''||v_pay_tras_to||'''=''USD'' THEN ''USD'' 
                          when '''||v_pay_tras_to||'''=''EUR'' THEN ''EUR'' 
                          when '''||v_pay_tras_to||'''=''GBP'' THEN ''GBP''
                          when '''||v_pay_tras_to||'''=''QAR'' THEN ''QAR'' 
                          when '''||v_pay_tras_to||'''=''IIC'' THEN  ca.req_amt_currency_type  
                           END as Tra_Curr,
                    '''||v_debit_iban_no||''' as Debit_iban_no,
                    TO_CHAR( TO_DATE ('''||v_batch_date||''',''DD-MM-YYYY'')) as Value_Date,
                    ttk_util_pkg.fn_decrypt(tcp.payee_name) as Benf_name,
                    
                    CASE WHEN tcp.claim_type = ''CTM'' THEN
                        (CASE WHEN e.enrol_type_id = ''COR'' THEN
                            CASE WHEN NVL(clmb.claimfrom_gentype_id,''INSU'')!=''EMBA'' THEN
                              (CASE  WHEN TCP.TPA_CHEQUE_ISSUED_GENERAL_TYPE = ''IQI'' THEN  ttk_util_pkg.fn_decrypt(t.BANK_NAME)
                                     WHEN TCP.TPA_CHEQUE_ISSUED_GENERAL_TYPE = ''IQC'' THEN  ttk_util_pkg.fn_decrypt(s.BANK_NAME)  END)
                             ELSE
                                     ttk_util_pkg.fn_decrypt(embb.BANK_NAME)
                             END
                         ELSE ttk_util_pkg.fn_decrypt(t.BANK_NAME) END)
                    ELSE
                           CASE ca.pymnt_to_type_id WHEN ''PTN'' THEN ttk_util_pkg.fn_decrypt(pa.bank_name)  ELSE ttk_util_pkg.fn_decrypt(w.bank_name)  END
                   end as Benf_Bank_name,
                   CASE  WHEN tcp.claim_type = ''CTM'' THEN
                     (CASE WHEN e.enrol_type_id = ''COR'' THEN
                         CASE WHEN NVL(clmb.claimfrom_gentype_id,''INSU'')!=''EMBA'' THEN
                            (CASE WHEN TCP.TPA_CHEQUE_ISSUED_GENERAL_TYPE = ''IQI'' THEN  ttk_util_pkg.fn_decrypt(t.bank_ifsc)
                                  WHEN TCP.TPA_CHEQUE_ISSUED_GENERAL_TYPE = ''IQC'' THEN  ttk_util_pkg.fn_decrypt(S.bank_ifsc) END)
                        ELSE
                                ttk_util_pkg.fn_decrypt(embb.BANK_IFSC)  
                        END
                      ELSE ttk_util_pkg.fn_decrypt(t.bank_ifsc) END)
                    ELSE
                       CASE ca.pymnt_to_type_id WHEN ''PTN'' THEN ttk_util_pkg.fn_decrypt(pa.bank_ifsc) 
                                        ELSE ttk_util_pkg.fn_decrypt(w.bank_ifsc) 
                   END
                   end as Benf_Swift_Code,
                   CASE  WHEN tcp.claim_type = ''CTM'' THEN
                         (CASE WHEN e.enrol_type_id = ''COR'' THEN
                             CASE WHEN NVL(clmb.claimfrom_gentype_id,''INSU'')!=''EMBA'' THEN
                              (CASE WHEN TCP.TPA_CHEQUE_ISSUED_GENERAL_TYPE = ''IQI'' THEN  ttk_util_pkg.fn_decrypt(t.bank_micr)
                                    WHEN TCP.TPA_CHEQUE_ISSUED_GENERAL_TYPE = ''IQC'' THEN  ttk_util_pkg.fn_decrypt(S.Bank_Micr) END)
                            ELSE
                                      ttk_util_pkg.fn_decrypt(EMBB.BANK_MICR) 
                            END
                          
                          ELSE ttk_util_pkg.fn_decrypt(t.bank_micr) END)
                   ELSE
                      CASE ca.pymnt_to_type_id WHEN ''PTN'' THEN ttk_util_pkg.fn_decrypt(pa.bank_micr) 
                                               ELSE ttk_util_pkg.fn_decrypt(w.bank_micr) 
                   END
                  end as Benf_Bank_Acc_number,
                  CASE WHEN ca.CLAIM_TYPE=''CTM'' THEN 
                    CASE WHEN NVL(clmb.claimfrom_gentype_id,''INSU'')!=''EMBA'' THEN
                         (case when TCP.TPA_CHEQUE_ISSUED_GENERAL_TYPE=''IQC'' THEN 
                              CASE WHEN S.ACCOUNT_IN_QATAR_YN=''N'' THEN S.state_type_id ELSE CST.state_name END
                               when TCP.TPA_CHEQUE_ISSUED_GENERAL_TYPE=''IQI'' THEN 
                              CASE WHEN T.ACCOUNT_IN_QATAR_YN=''N'' THEN T.state_type_id ELSE MST.state_name END   
                          END)
                     ELSE
                          embs.state_name
                     END     
                          
                  ELSE
                   CASE WHEN ca.CLAIM_TYPE=''CNH'' THEN
                  (case when NVL(ca.pymnt_to_type_id,''HOS'') =''PTN'' THEN
                  CASE WHEN PA.ACCOUNT_IN_QATAR_YN =''N'' THEN paa.state_type_id ELSE pas.state_name END
                  ELSE
                   CASE WHEN W.ACCOUNT_IN_QATAR_YN =''N'' THEN HAA.state_type_id ELSE has.state_name END
                  END  )
            
                  END  END as benf_bank_add1,
                  CASE WHEN ca.CLAIM_TYPE=''CTM'' THEN
                    CASE WHEN NVL(clmb.claimfrom_gentype_id,''INSU'')!=''EMBA'' THEN
                           (case when TCP.TPA_CHEQUE_ISSUED_GENERAL_TYPE=''IQC'' THEN 
                                              CCO.country_name
                                 when TCP.TPA_CHEQUE_ISSUED_GENERAL_TYPE=''IQI'' THEN 
                                          MCO.country_name
                                 END)
                   ELSE
                                 EMC.country_name
                   END
                  
                  ELSE
                      CASE WHEN ca.CLAIM_TYPE=''CNH'' THEN
                 (case when NVL(ca.pymnt_to_type_id,''HOS'') =''PTN'' THEN pac.country_name
                       ELSE
                       hac.country_name END)
                       END 
                        END as benf_bank_add2,
                        ''OTHPAY'' as pay_reason,
                         ''OUR'' as it_charg,
               ''G0'' AS purpose_of_code,
               case when TTK_UTIL_PKG.FN_DECRYPT(tcp.payee_name)=ref.payee_name then ref.TRANS_NUM end as trans_ref_num
                 ,'''||v_batch_seq_id||''' as batch_num,
             ''NA'' as Intermediary_Name,
             ''NA'' as Clearing_Code            
                 
          from fin_app.tpa_claims_payment tcp
          JOIN app.clm_authorization_details ca on (ca.claim_seq_id=tcp.claim_seq_id)
          JOIN APP.clm_batch_upload_details clmb on (clmb.clm_batch_seq_id=ca.clm_batch_seq_id)
          ----------CORPORATE START
          JOIN tpa_enr_policy E ON (tcp.policy_seq_id = E.policy_seq_id)
          LEFT OUTER JOIN tpa_enr_bank_dtls S ON (E.bank_seq_id = S.bank_seq_id)
          JOIN TPA_ADDRESS GRAD ON (GRAD.GROUP_REG_SEQ_ID=E.GROUP_REG_SEQ_ID)
          LEFT OUTER JOIN tpa_city_code CCI on (CCI.city_type_id=GRAD.city_type_id)
          LEFT OUTER JOIN TPA_STATE_CODE  CST ON (CST.state_type_id=GRAD.state_type_id)
          LEFT OUTER JOIN TPA_COUNTRY_CODE CCO ON (CCO.country_id=GRAD.country_id)
          ----------CORPORATE ENDS
          ----- INDIVIDUAL START
          JOIN TPA_ENR_POLICY_MEMBER MEM ON (tcp.MEMBER_SEQ_ID=MEM.MEMBER_SEQ_ID)
          JOIN tpa_enr_policy_group R ON (MEM.POLICY_GROUP_SEQ_ID = R.POLICY_GROUP_SEQ_ID)
          LEFT OUTER JOIN tpa_enr_bank_dtls T ON (R.bank_seq_id = T.bank_seq_id)
          LEFT OUTER JOIN tpa_city_code MCI on (MCI.city_type_id=T.city_type_id)
          LEFT OUTER JOIN TPA_STATE_CODE  MST ON (MST.state_type_id=T.state_type_id)
          LEFT OUTER JOIN TPA_COUNTRY_CODE MCO ON (MCO.country_id=T.country_type_id)
          ------ INDIVIDUAL END 
          LEFT OUTER JOIN fin_app.tpa_payment_checks_details pcd on (tcp.payment_seq_id = pcd.payment_seq_id and pcd.v_csr_flag = 1)
          LEFT OUTER JOIN fin_app.tpa_claims_check cc on (pcd.claims_chk_seq_id = cc.claims_chk_seq_id and cc.v_csr_flag = 1)
          LEFT OUTER JOIN fin_app.tpa_float_account tfa on (tcp.float_seq_id = tfa.float_seq_id)
          left outer join fin_app.tpa_bank_accounts ba on (tfa.bank_acc_seq_id = ba.bank_acc_seq_id)
          LEFT OUTER JOIN tpa_bank_master h ON (h.bank_seq_id = ba.bank_seq_id)
          left outer join app.tpa_enr_bank_dtls bd  on (ba.bank_seq_id = bd.bank_seq_id)
          LEFT OUTER JOIN tpa_group_registration L   ON (L.group_reg_seq_id = tcp.group_reg_seq_id)
          ---- HOSPITAL ACCOUNT DETAILS STARTS
          LEFT OUTER JOIN tpa_hosp_info O  ON (tcp.hosp_seq_id = O.hosp_seq_id)
          LEFT OUTER JOIN tpa_hosp_account_details W  ON (O.hosp_seq_id = w.hosp_seq_id)
          LEFT OUTER JOIN tpa_hosp_address haa ON (w.HOSP_BANK_SEQ_ID=haa.HOSP_BANK_SEQ_ID)
          LEFT OUTER JOIN tpa_country_code hac ON (haa.country_id=hac.country_id)
          LEFT OUTER JOIN tpa_state_code has ON (haa.state_type_id=has.state_type_id)
          LEFT OUTER JOIN tpa_city_code hacc ON (haa.city_type_id=hacc.city_type_id)
          ---- HOSPITAL ACCOUNT DETAILS ENDS
          -----PARTNER ACCOUNT DETAILS STARTS
          LEFT OUTER JOIN tpa_partner_info pi ON (tcp.ptnr_seq_id=pi.ptnr_seq_id)
          LEFT OUTER JOIN tpa_partner_account_details pa ON (pi.ptnr_seq_id=pa.ptnr_seq_id)
          LEFT OUTER JOIN tpa_partner_address paa ON (paa.PTNR_BANK_SEQ_ID=pa.PTNR_BANK_SEQ_ID)
          LEFT OUTER JOIN tpa_country_code pac ON (pac.country_id=paa.country_id)
          LEFT OUTER JOIN tpa_state_code pas ON (paa.state_type_id=pas.state_type_id)
          LEFT OUTER JOIN tpa_city_code pacc on (paa.city_type_id=pacc.city_type_id)
          -----PARTNER ACCOUNT DETAILS ENDS
          LEFT OUTER JOIN tpa_bank_advice_batch batc on (batc.batch_seq_id=tcp.bank_advice_batch)
          LEFT OUTER JOIN FIN_APP.trans_ref_table ref ON (ref.batch_num=batc.batch_seq_id) AND TTK_UTIL_PKG.FN_DECRYPT(tcp.payee_name)=ref.payee_name
          LEFT OUTER JOIN APP.tpa_enr_embassy_registration EMB ON (EMB.embassy_seq_id=ca.embassy_seq_id)
          LEFT OUTER JOIN APP.tpa_enr_bank_dtls embb on (embb.bank_seq_id=emb.bank_seq_id)
          LEFT OUTER JOIN APP.TPA_COUNTRY_CODE EMC ON (emc.COUNTRY_ID=EMB.COUNTRY_ID)
          LEFT OUTER JOIN APP.tpa_city_code emcc on (emcc.CITY_TYPE_ID=embb.CITY_TYPE_ID)
          LEFT OUTER JOIN app.tpa_state_code embs on (embb.state_type_id=embs.state_type_id)
    WHERE tcp.float_seq_id = :v_float_seq_id ' ||
                    regexp_replace(v_where, 'D\.', 'tcp.') ||
                    ' AND tcp.claim_payment_status  = ''READY_TO_BANK'')
                      group by  Tra_Curr,Benf_name,Benf_Bank_name,Benf_Swift_Code,Benf_Bank_Acc_number,benf_bank_add1
                  ,it_charg,trans_ref_num,benf_bank_add2,Debit_iban_no,Value_Date,pay_reason,purpose_of_code,Intermediary_Name,Clearing_Code )A 
                   LEFT OUTER JOIN DISC_TAB vol on (vol.hosp_seq_id=hosp_seq_id)'; 

        IF str_tab.FIRST IS NOT NULL THEN
          IF str_tab.COUNT <= 8  THEN
            CASE str_tab.COUNT
              WHEN 1 THEN  OPEN v_consolidated FOR v_cons_str USING v_float_seq_id, str_tab(1);
              WHEN 2 THEN  OPEN v_consolidated FOR v_cons_str USING v_float_seq_id, str_tab(1), str_tab(2);
              WHEN 3 THEN  OPEN v_consolidated FOR v_cons_str USING v_float_seq_id, str_tab(1), str_tab(2), str_tab(3);
              WHEN 4 THEN  OPEN v_consolidated FOR v_cons_str USING v_float_seq_id, str_tab(1), str_tab(2), str_tab(3), str_tab(4);
              WHEN 5 THEN  OPEN v_consolidated FOR v_cons_str USING v_float_seq_id, str_tab(1), str_tab(2), str_tab(3), str_tab(4), str_tab(5);
              WHEN 6 THEN  OPEN v_consolidated FOR v_cons_str USING v_float_seq_id, str_tab(1), str_tab(2), str_tab(3), str_tab(4), str_tab(5), str_tab(6);
              WHEN 7 THEN  OPEN v_consolidated FOR v_cons_str USING v_float_seq_id, str_tab(1), str_tab(2), str_tab(3), str_tab(4), str_tab(5), str_tab(6), str_tab(7);
              WHEN 8 THEN  OPEN v_consolidated FOR v_cons_str USING v_float_seq_id, str_tab(1), str_tab(2), str_tab(3), str_tab(4), str_tab(5), str_tab(6), str_tab(7), str_tab(8);
            END CASE;
          ELSIF str_tab.COUNT > 8  THEN
            OPEN v_consolidated FOR v_cons_str
              USING v_float_seq_id;
          ELSE 
            OPEN v_consolidated FOR v_cons_str
              USING v_float_seq_id,v_float_seq_id;    
END IF; 
      END IF;
END IF; 

    UPDATE tpa_bank_advice_batch A
       SET A.no_of_transactions = v_count_of_payments,
           A.file_name          = v_filename,
           A.updated_date       = SYSDATE,
           a.updated_by          = v_added_by
     WHERE batch_seq_id = v_batch_seq_id;

    IF str_tab.FIRST IS NOT NULL THEN
      FORALL i IN str_tab.FIRST .. str_tab.LAST

                                        
        UPDATE tpa_claims_payment a
           SET A.claim_payment_status = 'SENT_TO_BANK',
               a.transfer_currency    = CASE WHEN v_pay_tras_to='QAR' THEN 'QAR'
                                             WHEN v_pay_tras_to='USD' THEN 'USD'
                                             WHEN v_pay_tras_to='EUR' THEN 'EUR'
                                             WHEN v_pay_tras_to='GBP' THEN 'GBP'
                                             WHEN v_pay_tras_to='IIC' THEN 
                                               (SELECT cad.fnl_amt_currency_type 
                                                  FROM clm_authorization_details cad
                                                  JOIN tpa_claims_payment pay on (cad.claim_seq_id=pay.claim_seq_id)
                                                  WHERE pay.payment_seq_id=TO_NUMBER(str_tab(i))) end ,
               A.updated_date         = SYSDATE,
               a.updated_by           = v_added_by
         WHERE payment_seq_id = TO_NUMBER(str_tab(i));
    END IF;

   Claims_Dump_Into_ERP(v_payment_seq_id,v_batch_seq_id,'ADD');
    v_rows_processed := str_tab.LAST;
    COMMIT;  
END Gen_Detail_Cons_advice;                                  
--===============================================================================================


PROCEDURE get_invoice_details(v_inv_policy_seq_id     IN VARCHAR2,
                              rec_invoice_details     OUT SYS_REFCURSOR)
  IS
  
  CURSOR cur_inv_dtls(v_invoice_seq_id NUMBER) IS
      SELECT I.INV_FROM_DATE,I.INV_TO_DATE,I.INCLUDE_OLD_YN,I.INVOICE_TYPE,I.TRANS_REF_NUM
      FROM TPA_FIN_INVOICE I
      WHERE I.INVOICE_SEQ_ID = v_invoice_seq_id;
    
  CURSOR cur_pol_info(V_POLICY_SEQ_ID  NUMBER) IS
      SELECT ep.logic_type_id,ep.clm_admn_chrgs,NVL(ep.mem_cancl_days,90) AS mem_cancl_days,          
             ep.mat_premum_from_age,ep.mat_premum_to_age       
      FROM APP.TPA_ENR_POLICY EP
      WHERE EP.POLICY_SEQ_ID = V_POLICY_SEQ_ID;  
    
    rec_pol_info                  cur_pol_info%ROWTYPE; 
    
    v_inv_from_dt                 DATE;
    v_inv_to_dt                   DATE;
    V_INCLUDE_OLD_YN              VARCHAR2(5);
    str_tab                       ttk_util_pkg.str_table_type;
    v_inv_type                    VARCHAR2(10);
    v_trns_ref_num                VARCHAR2(100);
        
 BEGIN

str_tab := ttk_util_pkg.parse_str(v_inv_policy_seq_id);
   
   OPEN  cur_inv_dtls(str_tab(1));
   FETCH cur_inv_dtls INTO v_inv_from_dt,v_inv_to_dt,V_INCLUDE_OLD_YN,v_inv_type,v_trns_ref_num;
   CLOSE cur_inv_dtls;
   
   OPEN  cur_pol_info(str_tab(2));
   FETCH cur_pol_info INTO rec_pol_info;
   CLOSE cur_pol_info;
   
IF v_inv_type = 'ADD' THEN   
 IF V_INCLUDE_OLD_YN = 'N' THEN  
      OPEN rec_invoice_details FOR
        WITH INV_DETAILS AS 
       (SELECT IV.INVOICE_SEQ_ID,IV.POLICY_SEQ_ID,IV.INV_GEN_PERIOD,IV.INV_NO_PERIOD_1 AS INVOICE_NUMBER,
               IV.INV_FROM_DATE,IV.INV_TO_DATE,IV.DUE_DATE_1 AS DUE_DATE
        FROM FIN_APP.TPA_FIN_INVOICE IV
        WHERE  IV.INVOICE_SEQ_ID = str_tab(1)
           AND IV.INV_NO_PERIOD_1 IS NOT NULL
        UNION ALL
        SELECT IV.INVOICE_SEQ_ID,IV.POLICY_SEQ_ID,IV.INV_GEN_PERIOD,IV.INV_NO_PERIOD_2 AS INVOICE_NUMBER,
               IV.INV_FROM_DATE,IV.INV_TO_DATE,IV.DUE_DATE_2 AS DUE_DATE
        FROM FIN_APP.TPA_FIN_INVOICE IV
        WHERE  IV.INVOICE_SEQ_ID = str_tab(1)
           AND IV.INV_NO_PERIOD_2 IS NOT NULL
        UNION ALL
        SELECT IV.INVOICE_SEQ_ID,IV.POLICY_SEQ_ID,IV.INV_GEN_PERIOD,IV.INV_NO_PERIOD_3 AS INVOICE_NUMBER,
               IV.INV_FROM_DATE,IV.INV_TO_DATE,IV.DUE_DATE_3 AS DUE_DATE
        FROM FIN_APP.TPA_FIN_INVOICE IV
        WHERE  IV.INVOICE_SEQ_ID = str_tab(1)
           AND IV.INV_NO_PERIOD_3 IS NOT NULL
        UNION ALL
        SELECT IV.INVOICE_SEQ_ID,IV.POLICY_SEQ_ID,IV.INV_GEN_PERIOD,IV.INV_NO_PERIOD_4 AS INVOICE_NUMBER,
               IV.INV_FROM_DATE,IV.INV_TO_DATE,IV.DUE_DATE_4 AS DUE_DATE
        FROM FIN_APP.TPA_FIN_INVOICE IV
        WHERE  IV.INVOICE_SEQ_ID = str_tab(1)
           AND IV.INV_NO_PERIOD_4 IS NOT NULL)
           
         SELECT I.INVOICE_NUMBER,
                TO_CHAR(SYSDATE,'DD/MM/YYYY') AS INVOICE_DATE,
                R.GROUP_NAME,R.GROUP_ID,B.POLICY_NUMBER,
                TO_CHAR(B.EFFECTIVE_FROM_DATE,'DD/MM/YYYY') AS EFFECTIVE_FROM_DATE,
                TO_CHAR(B.EFFECTIVE_TO_DATE,'DD/MM/YYYY') AS EFFECTIVE_TO_DATE,
                RA.ADDRESS_1||', '||CI.CITY_DESCRIPTION||' ,'||S.STATE_NAME||' - '||RA.PIN_CODE||' ,'||CO.COUNTRY_NAME AS CORP_ADDRESS,
                TO_CHAR(I.INV_FROM_DATE,'DD/MM/YYYY') AS INV_FROM_DATE,TO_CHAR(I.INV_TO_DATE,'DD/MM/YYYY') AS INV_TO_DATE,
                --A.NET_PREMIUM,
                --ttk_util_pkg.num_to_words(A.NET_PREMIUM) AS NET_PREMIUM_WRD,
                ROUND(SUM(NVL(ABS(NVL(M.INV_CRN_AMNT,M.MEM_TOTAL_PREMIUM) - NVL(M.CHNG_IN_AMNT,0) ), 0))/CASE I.INV_GEN_PERIOD WHEN 'QTR' THEN 4 WHEN 'HLF' THEN 2 ELSE 1 END,2) AS NET_PREMIUM,
                ttk_util_pkg.num_to_words(ROUND(SUM(NVL(ABS(NVL(M.INV_CRN_AMNT,M.MEM_TOTAL_PREMIUM) - NVL(M.CHNG_IN_AMNT,0) ), 0))/CASE I.INV_GEN_PERIOD WHEN 'QTR' THEN 4 WHEN 'HLF' THEN 2 ELSE 1 END,2)) AS NET_PREMIUM_WRD,
                TO_CHAR(I.DUE_DATE,'DD/MM/YYYY') AS DUE_DATE,
                d.ins_comp_name, TO_CHAR(ina.pin_code) AS pin_code, '(+974) '||ina.office_phone1 as office_phone1,
                ct.city_description,ins.state_name,inc.country_name,
                G.DESCRIPTION AS INV_GEN_PERIOD,
                v_inv_type as INVOICE_TYPE
        FROM INV_DETAILS I 
        JOIN tpa_enr_policy B ON (I.Policy_Seq_Id = B.Policy_Seq_Id AND B.deleted_yn = 'N')
        JOIN APP.TPA_GROUP_REGISTRATION R ON (B.GROUP_REG_SEQ_ID=R.GROUP_REG_SEQ_ID)
        JOIN APP.TPA_ENR_POLICY_GROUP PG ON (B.POLICY_SEQ_ID=PG.POLICY_SEQ_ID)
        JOIN APP.TPA_ENR_POLICY_MEMBER M ON (PG.POLICY_GROUP_SEQ_ID=M.POLICY_GROUP_SEQ_ID)
        JOIN APP.tpa_address RA ON (R.GROUP_REG_SEQ_ID=RA.GROUP_REG_SEQ_ID)
        JOIN APP.TPA_COUNTRY_CODE CO ON (RA.COUNTRY_ID=CO.COUNTRY_ID)
        JOIN APP.TPA_STATE_CODE S ON (RA.STATE_TYPE_ID=S.STATE_TYPE_ID)
        JOIN APP.TPA_CITY_CODE CI ON (RA.CITY_TYPE_ID=CI.CITY_TYPE_ID)
        JOIN tpa_office_info C ON (B.Tpa_Office_Seq_Id = C.Tpa_Office_Seq_Id)
        JOIN tpa_ins_info D ON (B.INS_SEQ_ID = D.INS_SEQ_ID)
        join app.tpa_address ina on (d.ins_seq_id = ina.ins_seq_id)
        join app.tpa_country_code inc on (ina.country_id=inc.country_id)
        join app.tpa_state_code ins on (ina.state_type_id=ins.state_type_id)
        join app.tpa_city_code ct on (ina.city_type_id=ct.city_type_id)
        JOIN APP.TPA_GENERAL_CODE G ON (I.INV_GEN_PERIOD=G.GENERAL_TYPE_ID)
        WHERE b.policy_seq_id = str_tab(2)
          AND i.INVOICE_SEQ_ID = str_tab(1)
          AND M.DELETED_YN = 'N' AND NVL(M.INV_TO_BE_GEN_YN,'N') = 'Y'
          AND TRUNC(M.ADDED_DATE) BETWEEN v_inv_from_dt AND v_inv_to_dt
          GROUP BY I.INVOICE_NUMBER,R.GROUP_NAME,R.GROUP_ID,B.POLICY_NUMBER,
                   B.EFFECTIVE_FROM_DATE,B.EFFECTIVE_TO_DATE,RA.ADDRESS_1,CI.CITY_DESCRIPTION,
                   S.STATE_NAME,RA.PIN_CODE,CO.COUNTRY_NAME,I.INV_FROM_DATE,I.INV_TO_DATE,I.DUE_DATE,
                   d.ins_comp_name, ina.pin_code,ina.office_phone1,ct.city_description,ins.state_name,
                   inc.country_name,I.INV_GEN_PERIOD,G.DESCRIPTION
        ORDER BY I.INVOICE_NUMBER ;
    ELSE
      OPEN rec_invoice_details FOR
       WITH INV_DETAILS AS 
       (SELECT IV.INVOICE_SEQ_ID,IV.POLICY_SEQ_ID,IV.INV_GEN_PERIOD,IV.INV_NO_PERIOD_1 AS INVOICE_NUMBER,
               IV.INV_FROM_DATE,IV.INV_TO_DATE,IV.DUE_DATE_1 AS DUE_DATE
        FROM FIN_APP.TPA_FIN_INVOICE IV
        WHERE  IV.INVOICE_SEQ_ID = str_tab(1)
           AND IV.INV_NO_PERIOD_1 IS NOT NULL
        UNION ALL
        SELECT IV.INVOICE_SEQ_ID,IV.POLICY_SEQ_ID,IV.INV_GEN_PERIOD,IV.INV_NO_PERIOD_2 AS INVOICE_NUMBER,
               IV.INV_FROM_DATE,IV.INV_TO_DATE,IV.DUE_DATE_2 AS DUE_DATE
        FROM FIN_APP.TPA_FIN_INVOICE IV
        WHERE  IV.INVOICE_SEQ_ID = str_tab(1)
           AND IV.INV_NO_PERIOD_2 IS NOT NULL
        UNION ALL
        SELECT IV.INVOICE_SEQ_ID,IV.POLICY_SEQ_ID,IV.INV_GEN_PERIOD,IV.INV_NO_PERIOD_3 AS INVOICE_NUMBER,
               IV.INV_FROM_DATE,IV.INV_TO_DATE,IV.DUE_DATE_3 AS DUE_DATE
        FROM FIN_APP.TPA_FIN_INVOICE IV
        WHERE  IV.INVOICE_SEQ_ID = str_tab(1)
           AND IV.INV_NO_PERIOD_3 IS NOT NULL
        UNION ALL
        SELECT IV.INVOICE_SEQ_ID,IV.POLICY_SEQ_ID,IV.INV_GEN_PERIOD,IV.INV_NO_PERIOD_4 AS INVOICE_NUMBER,
               IV.INV_FROM_DATE,IV.INV_TO_DATE,IV.DUE_DATE_4 AS DUE_DATE
        FROM FIN_APP.TPA_FIN_INVOICE IV
        WHERE  IV.INVOICE_SEQ_ID = str_tab(1)
           AND IV.INV_NO_PERIOD_4 IS NOT NULL)
           
         SELECT I.INVOICE_NUMBER,TO_CHAR(SYSDATE,'DD/MM/YYYY') AS INVOICE_DATE,
                R.GROUP_NAME,R.GROUP_ID,B.POLICY_NUMBER,
                TO_CHAR(B.EFFECTIVE_FROM_DATE,'DD/MM/YYYY') AS EFFECTIVE_FROM_DATE,
                TO_CHAR(B.EFFECTIVE_TO_DATE,'DD/MM/YYYY') AS EFFECTIVE_TO_DATE,
                RA.ADDRESS_1||', '||CI.CITY_DESCRIPTION||' ,'||S.STATE_NAME||' - '||RA.PIN_CODE||' ,'||CO.COUNTRY_NAME AS CORP_ADDRESS,
                TO_CHAR(I.INV_FROM_DATE,'DD/MM/YYYY') AS INV_FROM_DATE,TO_CHAR(I.INV_TO_DATE,'DD/MM/YYYY') AS INV_TO_DATE,
                --A.NET_PREMIUM,
                --ttk_util_pkg.num_to_words(A.NET_PREMIUM) AS NET_PREMIUM_WRD,
                ROUND(SUM(NVL(ABS(NVL(M.INV_CRN_AMNT,M.MEM_TOTAL_PREMIUM) - NVL(M.CHNG_IN_AMNT,0) ), 0))/CASE I.INV_GEN_PERIOD WHEN 'QTR' THEN 4 WHEN 'HLF' THEN 2 ELSE 1 END,2) AS NET_PREMIUM,
                ttk_util_pkg.num_to_words(ROUND(SUM(NVL(ABS(NVL(M.INV_CRN_AMNT,M.MEM_TOTAL_PREMIUM) - NVL(M.CHNG_IN_AMNT,0) ), 0))/CASE I.INV_GEN_PERIOD WHEN 'QTR' THEN 4 WHEN 'HLF' THEN 2 ELSE 1 END,2)) AS NET_PREMIUM_WRD,
                TO_CHAR(I.DUE_DATE,'DD/MM/YYYY') AS DUE_DATE,
                d.ins_comp_name, TO_CHAR(ina.pin_code) AS pin_code, '(+974) '||ina.office_phone1 as office_phone1,
                ct.city_description,ins.state_name,inc.country_name,
                G.DESCRIPTION AS INV_GEN_PERIOD,
                v_inv_type as INVOICE_TYPE
        FROM INV_DETAILS I 
        JOIN tpa_enr_policy B ON (I.Policy_Seq_Id = B.Policy_Seq_Id AND B.deleted_yn = 'N')
        JOIN APP.TPA_GROUP_REGISTRATION R ON (B.GROUP_REG_SEQ_ID=R.GROUP_REG_SEQ_ID)
        JOIN APP.TPA_ENR_POLICY_GROUP PG ON (B.POLICY_SEQ_ID=PG.POLICY_SEQ_ID)
        JOIN APP.TPA_ENR_POLICY_MEMBER M ON (PG.POLICY_GROUP_SEQ_ID=M.POLICY_GROUP_SEQ_ID)
        JOIN APP.tpa_address RA ON (R.GROUP_REG_SEQ_ID=RA.GROUP_REG_SEQ_ID)
        JOIN APP.TPA_COUNTRY_CODE CO ON (RA.COUNTRY_ID=CO.COUNTRY_ID)
        JOIN APP.TPA_STATE_CODE S ON (RA.STATE_TYPE_ID=S.STATE_TYPE_ID)
        JOIN APP.TPA_CITY_CODE CI ON (RA.CITY_TYPE_ID=CI.CITY_TYPE_ID)
        JOIN tpa_office_info C ON (B.Tpa_Office_Seq_Id = C.Tpa_Office_Seq_Id)
        JOIN tpa_ins_info D ON (B.INS_SEQ_ID = D.INS_SEQ_ID)
        join app.tpa_address ina on (d.ins_seq_id = ina.ins_seq_id)
        join app.tpa_country_code inc on (ina.country_id=inc.country_id)
        join app.tpa_state_code ins on (ina.state_type_id=ins.state_type_id)
        join app.tpa_city_code ct on (ina.city_type_id=ct.city_type_id)
        JOIN APP.TPA_GENERAL_CODE G ON (I.INV_GEN_PERIOD=G.GENERAL_TYPE_ID)
        WHERE b.policy_seq_id  = str_tab(2)
          AND i.INVOICE_SEQ_ID = str_tab(1)
          AND M.DELETED_YN = 'N' AND NVL(M.INV_TO_BE_GEN_YN,'N') = 'Y'
          AND TRUNC(M.ADDED_DATE) <= v_inv_to_dt
          GROUP BY I.INVOICE_NUMBER,R.GROUP_NAME,R.GROUP_ID,B.POLICY_NUMBER,
                   B.EFFECTIVE_FROM_DATE,B.EFFECTIVE_TO_DATE,RA.ADDRESS_1,CI.CITY_DESCRIPTION,
                   S.STATE_NAME,RA.PIN_CODE,CO.COUNTRY_NAME,I.INV_FROM_DATE,I.INV_TO_DATE,I.DUE_DATE,
                   d.ins_comp_name, ina.pin_code,ina.office_phone1,ct.city_description,ins.state_name,
                   inc.country_name,I.INV_GEN_PERIOD,G.DESCRIPTION
        ORDER BY I.INVOICE_NUMBER ;
    END IF;
  ELSE
   --IF rec_pol_info.logic_type_id IN ('SC1','SC4') THEN
    OPEN rec_invoice_details FOR
       WITH INV_DETAILS AS 
       (SELECT IV.INVOICE_SEQ_ID,IV.POLICY_SEQ_ID,IV.INV_GEN_PERIOD,IV.INV_NO_PERIOD_1 AS INVOICE_NUMBER,
               IV.INV_FROM_DATE,IV.INV_TO_DATE,IV.DUE_DATE_1 AS DUE_DATE
        FROM FIN_APP.TPA_FIN_INVOICE IV
        WHERE  IV.INVOICE_SEQ_ID = str_tab(1)
           AND IV.INV_NO_PERIOD_1 IS NOT NULL
        UNION ALL
        SELECT IV.INVOICE_SEQ_ID,IV.POLICY_SEQ_ID,IV.INV_GEN_PERIOD,IV.INV_NO_PERIOD_2 AS INVOICE_NUMBER,
               IV.INV_FROM_DATE,IV.INV_TO_DATE,IV.DUE_DATE_2 AS DUE_DATE
        FROM FIN_APP.TPA_FIN_INVOICE IV
        WHERE  IV.INVOICE_SEQ_ID = str_tab(1)
           AND IV.INV_NO_PERIOD_2 IS NOT NULL
        UNION ALL
        SELECT IV.INVOICE_SEQ_ID,IV.POLICY_SEQ_ID,IV.INV_GEN_PERIOD,IV.INV_NO_PERIOD_3 AS INVOICE_NUMBER,
               IV.INV_FROM_DATE,IV.INV_TO_DATE,IV.DUE_DATE_3 AS DUE_DATE
        FROM FIN_APP.TPA_FIN_INVOICE IV
        WHERE  IV.INVOICE_SEQ_ID = str_tab(1)
           AND IV.INV_NO_PERIOD_3 IS NOT NULL
        UNION ALL
        SELECT IV.INVOICE_SEQ_ID,IV.POLICY_SEQ_ID,IV.INV_GEN_PERIOD,IV.INV_NO_PERIOD_4 AS INVOICE_NUMBER,
               IV.INV_FROM_DATE,IV.INV_TO_DATE,IV.DUE_DATE_4 AS DUE_DATE
        FROM FIN_APP.TPA_FIN_INVOICE IV
        WHERE  IV.INVOICE_SEQ_ID = str_tab(1)
           AND IV.INV_NO_PERIOD_4 IS NOT NULL),
   CLM_DETAILS AS 
       ( SELECT EP.Policy_Seq_Id,TO_CHAR(SYSDATE,'DD/MM/YYYY') AS INVOICE_DATE,
                R.GROUP_NAME,R.GROUP_ID,EP.POLICY_NUMBER,
                TO_CHAR(EP.EFFECTIVE_FROM_DATE,'DD/MM/YYYY') AS EFFECTIVE_FROM_DATE,
                TO_CHAR(EP.EFFECTIVE_TO_DATE,'DD/MM/YYYY') AS EFFECTIVE_TO_DATE,
                RA.ADDRESS_1||', '||CI.CITY_DESCRIPTION||' ,'||S.STATE_NAME||' - '||RA.PIN_CODE||' ,'||CO.COUNTRY_NAME AS CORP_ADDRESS,
                
                
                d.ins_comp_name, TO_CHAR(ina.pin_code) AS pin_code, '(+974) '||ina.office_phone1 as office_phone1,
                ct.city_description,ins.state_name,inc.country_name,
                
                FLOAT_ACCOUNTS_PKG.get_claimed_amount(M.MEMBER_SEQ_ID) AS CLM_AMOUNT,
                ((TRUNC(EP.EFFECTIVE_TO_DATE) - TRUNC(M.DATE_OF_EXIT)) + CASE WHEN TRUNC(M.DATE_OF_INCEPTION) = TRUNC(M.DATE_OF_EXIT) THEN 1 ELSE 0 END)* 
                        NVL(M.MEM_TOTAL_PREMIUM,0)/((TRUNC(EP.effective_to_date)- 
                        CASE WHEN EP.Effective_From_Date > M.date_of_inception THEN TRUNC(EP.Effective_From_Date) 
                             ELSE TRUNC(M.date_of_inception) END)+1) AS PRO_RTA_PREMIUM,
                               
                 (CASE WHEN NVL(M.CRN_TO_BE_GEN_ON_CNCL_YN,'N') = 'Y'AND M.STATUS_GENERAL_TYPE_ID = 'POC' 
                            AND TRUNC(M.DATE_OF_EXIT) <= TRUNC(v_inv_from_dt-EP.mem_cancl_days) THEN       
                 (CASE WHEN EP.logic_type_id = 'SC1' 
                                            THEN CASE WHEN FLOAT_ACCOUNTS_PKG.get_claimed_amount(M.MEMBER_SEQ_ID) > ROUND(((TRUNC(EP.EFFECTIVE_TO_DATE) - TRUNC(M.DATE_OF_EXIT)) + CASE WHEN TRUNC(M.DATE_OF_INCEPTION) = TRUNC(M.DATE_OF_EXIT) THEN 1 ELSE 0 END)* 
                                                           NVL(M.MEM_TOTAL_PREMIUM,0)/((TRUNC(EP.effective_to_date)- CASE WHEN EP.Effective_From_Date > M.date_of_inception THEN TRUNC(EP.Effective_From_Date) ELSE TRUNC(M.date_of_inception) END)+1),2) 
                                                        THEN 0
                                                      ELSE
                                                        ROUND(((TRUNC(EP.EFFECTIVE_TO_DATE) - TRUNC(M.DATE_OF_EXIT)) + CASE WHEN TRUNC(M.DATE_OF_INCEPTION) = TRUNC(M.DATE_OF_EXIT) THEN 1 ELSE 0 END)* 
                                                        NVL(M.MEM_TOTAL_PREMIUM,0)/((TRUNC(EP.effective_to_date)- CASE WHEN EP.Effective_From_Date > M.date_of_inception THEN TRUNC(EP.Effective_From_Date) ELSE TRUNC(M.date_of_inception) END)+1),2) 
                                                        - FLOAT_ACCOUNTS_PKG.get_claimed_amount(M.MEMBER_SEQ_ID) END
                                      WHEN EP.logic_type_id = 'SC2' 
                                           THEN CASE WHEN FLOAT_ACCOUNTS_PKG.get_mem_clm_cnt(M.MEMBER_SEQ_ID) > 0 THEN 0
                                                     ELSE ROUND(((TRUNC(EP.EFFECTIVE_TO_DATE) - TRUNC(M.DATE_OF_EXIT)) + CASE WHEN TRUNC(M.DATE_OF_INCEPTION) = TRUNC(M.DATE_OF_EXIT) THEN 1 ELSE 0 END)* 
                                                       NVL(M.MEM_TOTAL_PREMIUM,0)/((TRUNC(EP.effective_to_date)- CASE WHEN EP.Effective_From_Date > M.date_of_inception THEN TRUNC(EP.Effective_From_Date) ELSE TRUNC(M.date_of_inception) END)+1),2)
                                                END 
                                      WHEN EP.logic_type_id = 'SC3' 
                                           THEN CASE WHEN FLOAT_ACCOUNTS_PKG.get_mem_clm_cnt(M.MEMBER_SEQ_ID) > 0 THEN
                                                    ROUND(((TRUNC(EP.EFFECTIVE_TO_DATE) - TRUNC(M.DATE_OF_EXIT)) + CASE WHEN TRUNC(M.DATE_OF_INCEPTION) = TRUNC(M.DATE_OF_EXIT) THEN 1 ELSE 0 END)* 
                                                       NVL(M.MEM_TOTAL_PREMIUM,0)/((TRUNC(EP.effective_to_date)- 
                                                       CASE WHEN EP.Effective_From_Date > M.date_of_inception THEN TRUNC(EP.Effective_From_Date) 
                                                            ELSE TRUNC(M.date_of_inception) END)+1),2) END 
                                      
                                      WHEN EP.logic_type_id = 'SC4' 
                                           THEN CASE WHEN FLOAT_ACCOUNTS_PKG.get_claimed_amount(M.MEMBER_SEQ_ID) > ROUND(((TRUNC(EP.EFFECTIVE_TO_DATE) - TRUNC(M.DATE_OF_EXIT)) + CASE WHEN TRUNC(M.DATE_OF_INCEPTION) = TRUNC(M.DATE_OF_EXIT) THEN 1 ELSE 0 END)* 
                                                                                                                    NVL(M.MEM_TOTAL_PREMIUM,0)/((TRUNC(EP.effective_to_date)- 
                                                                                                                    CASE WHEN EP.Effective_From_Date > M.date_of_inception THEN TRUNC(EP.Effective_From_Date) 
                                                                                                                         ELSE M.date_of_inception END)+1),2) THEN 0
                                                     ELSE ROUND(((TRUNC(EP.EFFECTIVE_TO_DATE) - TRUNC(M.DATE_OF_EXIT)) + CASE WHEN TRUNC(M.DATE_OF_INCEPTION) = TRUNC(M.DATE_OF_EXIT) THEN 1 ELSE 0 END)* 
                                                       NVL(M.MEM_TOTAL_PREMIUM,0)/((TRUNC(EP.effective_to_date)- 
                                                       CASE WHEN EP.Effective_From_Date > M.date_of_inception THEN TRUNC(EP.Effective_From_Date) 
                                                            ELSE TRUNC(M.date_of_inception) END)+1),2) END
                   END) 
                  ELSE 0 END /*+ CASE WHEN NVL(M.INV_TO_BE_GEN_YN,'N') = 'Y' THEN 0 
                                    ELSE CASE WHEN NVL(M.CRN_TO_BE_GEN_YN,'N') = 'Y' THEN  
                                                   (NVL(M.INV_CRN_AMNT,0) - NVL(CHNG_IN_AMNT,0)) 
                                              ELSE 0 END END*/) AS Return_Premium              
        FROM  tpa_enr_policy EP 
        JOIN APP.TPA_GROUP_REGISTRATION R ON (EP.GROUP_REG_SEQ_ID=R.GROUP_REG_SEQ_ID)
        JOIN APP.TPA_ENR_POLICY_GROUP PG ON (EP.POLICY_SEQ_ID=PG.POLICY_SEQ_ID)
        JOIN APP.TPA_ENR_POLICY_MEMBER M ON (PG.POLICY_GROUP_SEQ_ID=M.POLICY_GROUP_SEQ_ID)
        JOIN APP.tpa_address RA ON (R.GROUP_REG_SEQ_ID=RA.GROUP_REG_SEQ_ID)
        JOIN APP.TPA_COUNTRY_CODE CO ON (RA.COUNTRY_ID=CO.COUNTRY_ID)
        JOIN APP.TPA_STATE_CODE S ON (RA.STATE_TYPE_ID=S.STATE_TYPE_ID)
        JOIN APP.TPA_CITY_CODE CI ON (RA.CITY_TYPE_ID=CI.CITY_TYPE_ID)
        JOIN tpa_office_info C ON (EP.Tpa_Office_Seq_Id = C.Tpa_Office_Seq_Id)
        JOIN tpa_ins_info D ON (EP.INS_SEQ_ID = D.INS_SEQ_ID)
        join app.tpa_address ina on (d.ins_seq_id = ina.ins_seq_id)
        join app.tpa_country_code inc on (ina.country_id=inc.country_id)
        join app.tpa_state_code ins on (ina.state_type_id=ins.state_type_id)
        join app.tpa_city_code ct on (ina.city_type_id=ct.city_type_id)
        WHERE EP.policy_seq_id  = str_tab(2)
          AND EP.deleted_yn = 'N'
          --AND M.STATUS_GENERAL_TYPE_ID = 'POC'
          AND M.DELETED_YN = 'N'
          AND ((TRUNC(M.DATE_OF_EXIT) <= TRUNC(v_inv_from_dt-rec_pol_info.mem_cancl_days) AND NVL(M.CRN_TO_BE_GEN_ON_CNCL_YN,'N') = 'Y' AND FLOAT_ACCOUNTS_PKG.get_mem_clm_inp_cnt(M.MEMBER_SEQ_ID) = 0) /*OR (NVL(M.CRN_TO_BE_GEN_YN,'N') = 'Y')*/)
          AND M.CRN_CURNT_SEQ_ID = str_tab(1)
          AND M.INV_LNKED_SEQ_IDS IS NOT NULL
          AND NVL(M.MEM_TOTAL_PREMIUM,0) != 0
           )
       SELECT I.INVOICE_NUMBER,
              G.DESCRIPTION AS INV_GEN_PERIOD,
              TO_CHAR(I.INV_FROM_DATE,'DD/MM/YYYY') AS INV_FROM_DATE,
              TO_CHAR(I.INV_TO_DATE,'DD/MM/YYYY') AS INV_TO_DATE,
              TO_CHAR(I.DUE_DATE,'DD/MM/YYYY') AS DUE_DATE,
              TO_CHAR(SYSDATE,'DD/MM/YYYY') AS INVOICE_DATE,
              CD.GROUP_ID,
              CD.GROUP_NAME,
              CD.POLICY_NUMBER,
              CD.EFFECTIVE_FROM_DATE,
              CD.EFFECTIVE_TO_DATE,
              ROUND(SUM(Return_Premium) /
               	    CASE I.INV_GEN_PERIOD WHEN 'QTR' THEN 4 WHEN 'HLF' THEN 2 ELSE 1 END,2) AS NET_PREMIUM,
              ttk_util_pkg.num_to_words(ROUND(SUM(NVL(PRO_RTA_PREMIUM - CLM_AMOUNT, 0))/CASE I.INV_GEN_PERIOD WHEN 'QTR' THEN 4 WHEN 'HLF' THEN 2 ELSE 1 END,2)) AS NET_PREMIUM_WRD,
              CD.CORP_ADDRESS,
              I.INV_FROM_DATE,I.INV_TO_DATE,I.DUE_DATE,
              CD.ins_comp_name, CD.pin_code,CD.office_phone1,CD.city_description,CD.state_name,CD.country_name,
              I.INV_GEN_PERIOD,G.DESCRIPTION,
              v_inv_type as INVOICE_TYPE
       FROM INV_DETAILS I 
       JOIN CLM_DETAILS CD ON (I.Policy_Seq_Id = CD.Policy_Seq_Id )
       LEFT OUTER JOIN APP.TPA_GENERAL_CODE G ON (I.INV_GEN_PERIOD=G.GENERAL_TYPE_ID)
       WHERE  i.INVOICE_SEQ_ID = str_tab(1)
          --AND PRO_RTA_PREMIUM > CLM_AMOUNT 
       GROUP BY I.INVOICE_NUMBER,CD.GROUP_NAME,CD.POLICY_NUMBER,
                   CD.EFFECTIVE_FROM_DATE,CD.EFFECTIVE_TO_DATE,CD.CORP_ADDRESS,I.INV_FROM_DATE,I.INV_TO_DATE,I.DUE_DATE,
                   CD.ins_comp_name, CD.pin_code,CD.office_phone1,CD.city_description,CD.state_name,
                   CD.country_name,I.INV_GEN_PERIOD,G.DESCRIPTION,CD.GROUP_ID
        ORDER BY I.INVOICE_NUMBER ;
  --END IF;
 END IF; 
  
 END get_invoice_details; 
--===============================================================================================
FUNCTION get_claimed_amount (v_member_seq_id        IN NUMBER)
  RETURN NUMBER
  IS
  
  
  CURSOR cur_claim_amnt IS
   SELECT SUM(NVL(CA.FINAL_APP_AMOUNT,0)),CA.POLICY_SEQ_ID AS POLICY_SEQ_ID,NVL(M.SWITCH_POL_YN,'N') AS SWITCH_POL_YN
   FROM APP.CLM_AUTHORIZATION_DETAILS CA
   JOIN APP.TPA_ENR_POLICY_MEMBER M ON (CA.MEMBER_SEQ_ID = M.MEMBER_SEQ_ID)
   WHERE CA.MEMBER_SEQ_ID = v_member_seq_id
     AND CA.CLM_STATUS_TYPE_ID = 'APR'
   GROUP BY CA.POLICY_SEQ_ID,SWITCH_POL_YN;
     
   v_CLAIMED_AMNT              NUMBER(15,5);
   V_POLICY_SEQ_ID             NUMBER(30);
   V_SWITCH_POL_YN             VARCHAR2(5);
   
   CURSOR cur_pol_info(V_POLICY_SEQ_ID  NUMBER) IS
      SELECT ep.logic_type_id,ep.clm_admn_chrgs,NVL(ep.mem_cancl_days,90) AS mem_cancl_days,          
             ep.mat_premum_from_age,ep.mat_premum_to_age       
      FROM APP.TPA_ENR_POLICY EP
      WHERE EP.POLICY_SEQ_ID = V_POLICY_SEQ_ID;  
    
    rec_pol_info                  cur_pol_info%ROWTYPE; 
   
BEGIN
  
  OPEN  cur_claim_amnt;
  FETCH cur_claim_amnt INTO v_CLAIMED_AMNT,V_POLICY_SEQ_ID,V_SWITCH_POL_YN;
  CLOSE cur_claim_amnt;
  
  OPEN  cur_pol_info(V_POLICY_SEQ_ID);
  FETCH cur_pol_info INTO rec_pol_info;
  CLOSE cur_pol_info;
  
  v_CLAIMED_AMNT := v_CLAIMED_AMNT + (v_CLAIMED_AMNT * (CASE WHEN V_SWITCH_POL_YN = 'N' THEN rec_pol_info.clm_admn_chrgs ELSE 0 END/100));
  
  RETURN(ROUND(NVL(v_CLAIMED_AMNT,0),2));

END get_claimed_amount;
--===============================================================================================
FUNCTION get_mem_clm_inp_cnt (v_member_seq_id        IN NUMBER)
  RETURN NUMBER
  IS
  
  CURSOR cur_claim_cnt IS
   SELECT COUNT(1)
   FROM APP.CLM_AUTHORIZATION_DETAILS CA
   WHERE CA.MEMBER_SEQ_ID = v_member_seq_id
     AND CA.CLM_STATUS_TYPE_ID IN ('INP','REQ');
     
   v_cnt              NUMBER(10);
   
BEGIN
  
  OPEN  cur_claim_cnt;
  FETCH cur_claim_cnt INTO v_cnt;
  CLOSE cur_claim_cnt;
  
  
  
  RETURN(v_cnt);

END get_mem_clm_inp_cnt;
--===============================================================================================
FUNCTION get_mem_clm_cnt (v_member_seq_id        IN NUMBER)
  RETURN NUMBER
  IS
  
  CURSOR cur_claim_cnt IS
   SELECT COUNT(1)
   FROM APP.CLM_AUTHORIZATION_DETAILS CA
   WHERE CA.MEMBER_SEQ_ID = v_member_seq_id
     AND CA.CLM_STATUS_TYPE_ID IN ('INP','REQ','APR');
     
   v_cnt              NUMBER(10);
   
BEGIN
  
  OPEN  cur_claim_cnt;
  FETCH cur_claim_cnt INTO v_cnt;
  CLOSE cur_claim_cnt;
  
  
  
  RETURN(v_cnt);

END get_mem_clm_cnt;
--===============================================================================================
-- Applying Fast Track and Volume base Discount For Finance Payment Advice Generation
--added date 21-03-2018, venu babu
--==================================================================================================
PROCEDURE Apply_fast_and_vol_discounts (v_payment_seq_id   IN VARCHAR,
                                        v_float_seq_id     IN NUMBER,
                                        v_batch_date       IN VARCHAR2,
                                        v_batch_seq_id     IN NUMBER,
                                        v_pay_tras_to      IN VARCHAR2,
                                        v_vol_base_type    IN VARCHAR2)
AS

CURSOR GET_FASTTRACT_DISC_DETAILS (P_PAYMENT_SEQ_ID NUMBER) IS
 WITH SHORTFALL AS ( SELECT MAX(SHORTFALL_SEQ_ID) AS SHORTFALL_SEQ_ID,CLAIM_SEQ_ID 
                             FROM SHORTFALL_DETAILS 
                             GROUP BY CLAIM_SEQ_ID)
                         SELECT  CASE WHEN CAD.CLAIM_TYPE='CNH' AND SD.SRTFLL_RECEIVED_DATE IS NULL THEN
                                    CASE WHEN (SYSDATE-CAD.CLM_RECEIVED_DATE) BETWEEN FD.FST_FROM_DAYS AND FD.FST_TO_DAYS THEN
                                              FD.DISC_PERC ELSE NULL END 
                                      WHEN CAD.CLAIM_TYPE='CNH' AND SD.SRTFLL_RECEIVED_DATE IS NOT NULL THEN 
                                          CASE WHEN (SYSDATE-SD.SRTFLL_RECEIVED_DATE) BETWEEN FD.FST_FROM_DAYS AND FD.FST_TO_DAYS THEN
                                           FD.DISC_PERC ELSE NULL END
                                      ELSE NULL END AS DISC_PERC,
                                          CASE WHEN CAD.CLAIM_TYPE='CNH' AND SD.SRTFLL_RECEIVED_DATE IS NULL THEN
                                        CASE WHEN (SYSDATE-CAD.CLM_RECEIVED_DATE) BETWEEN FD.FST_FROM_DAYS AND FD.FST_TO_DAYS THEN
                                              (CAD.FINAL_APP_AMOUNT*(FD.DISC_PERC/100)) ELSE NULL END 
                                          WHEN CAD.CLAIM_TYPE='CNH' AND SD.SRTFLL_RECEIVED_DATE IS NOT NULL THEN 
                                       CASE WHEN (SYSDATE-SD.SRTFLL_RECEIVED_DATE) BETWEEN FD.FST_FROM_DAYS AND FD.FST_TO_DAYS THEN
                                         (CAD.FINAL_APP_AMOUNT*(FD.DISC_PERC/100)) ELSE NULL END
                                       ELSE NULL END AS DISC_AMT
                                       FROM CLM_AUTHORIZATION_DETAILS CAD
                                      JOIN TPA_CLAIMS_PAYMENT PAY ON (CAD.CLAIM_SEQ_ID=PAY.CLAIM_SEQ_ID)
                                      JOIN CLM_HOSPITAL_DETAILS CHD ON (CHD.CLAIM_SEQ_ID=CAD.CLAIM_SEQ_ID)
                                      LEFT OUTER JOIN APP.TPA_FASTTRACT_DISC_DETAILS FD ON (FD.HOSP_SEQ_ID=CHD.HOSP_SEQ_ID AND FD.STATUS='ACT' AND FD.DISC_MODE='FAST'
                                      AND CAD.CLM_RECEIVED_DATE BETWEEN FD.START_DATE AND FD.END_DATE +1)
                                      LEFT OUTER JOIN SHORTFALL SS ON (SS.CLAIM_SEQ_ID=CAD.CLAIM_SEQ_ID)
                                      LEFT OUTER JOIN SHORTFALL_DETAILS SD ON (SS.SHORTFALL_SEQ_ID=SD.SHORTFALL_SEQ_ID)
                                 WHERE PAY.PAYMENT_SEQ_ID=P_PAYMENT_SEQ_ID and pay.claim_payment_status='READY_TO_BANK';

 
CURSOR GET_MON_VOLBASE_DISC_DETAILS(V_BT_NO NUMBER,PAY_SEQ_ID NUMBER) IS
   WITH DISC_AMT AS 
      (SELECT SUM(TR.APPR_AMT_WT_FASD) AS PREV_BATCH_AMOUNT,SUM(TR.DISC_AMT) AS DISCOUNT_AMOUNT,TR.HOSP_SEQ_ID,TR.PAID_MON_YEAR
          FROM FIN_APP.TPA_MONTHLY_DISC_AMTS TR
          LEFT OUTER JOIN APP.TPA_FASTTRACT_DISC_DETAILS FA ON (TR.HOSP_SEQ_ID=FA.HOSP_SEQ_ID AND FA.STATUS='ACT' AND FA.DISC_TYPE='VOL')
      WHERE TR.ADDED_DATE BETWEEN FA.START_DATE AND FA.END_DATE AND BATCH_NUM !=V_BT_NO and tr.DISC_TYPE='MON'
      GROUP BY TR.HOSP_SEQ_ID,TR.PAID_MON_YEAR)
              
        SELECT SUM(P.APPROVED_AMOUNT) AS APPR_IN_QAR ,SUM(P.APPROVED_AMOUNT-NVL(P.DISCOUNT_AMOUNT,0)) APPR_AMT,FA.DISC_PERC,
               P.HOSP_SEQ_ID,TO_CHAR(C.DATE_OF_HOSPITALIZATION,'MM-YYYY')PAY_MON_YEAR,
               CASE WHEN FA.DISC_PERC IS NOT NULL AND SUM(P.APPROVED_AMOUNT-NVL(P.DISCOUNT_AMOUNT,0))+NVL(SUM(V.PREV_BATCH_AMOUNT),0)
                 BETWEEN FA.DISC_VOL_AMT_ST AND FA.DISC_VOL_AMT_ED THEN 
                (SUM(P.APPROVED_AMOUNT-NVL(P.DISCOUNT_AMOUNT,0))-(SUM(P.APPROVED_AMOUNT-NVL(P.DISCOUNT_AMOUNT,0))*FA.DISC_PERC/100)) 
             ELSE 
               SUM(P.APPROVED_AMOUNT-NVL(P.DISCOUNT_AMOUNT,0)) 
             END AS PAYABLE_IN_QAR,
             CASE WHEN FA.DISC_PERC IS NOT NULL AND SUM(P.APPROVED_AMOUNT-NVL(P.DISCOUNT_AMOUNT,0))+NVL(SUM(V.PREV_BATCH_AMOUNT),0)
                 BETWEEN FA.DISC_VOL_AMT_ST AND FA.DISC_VOL_AMT_ED THEN 
                CASE WHEN v_pay_tras_to='QAR' THEN 
                          (SUM(P.APPROVED_AMOUNT-NVL(P.DISCOUNT_AMOUNT,0))-(SUM(P.APPROVED_AMOUNT-NVL(P.DISCOUNT_AMOUNT,0))*FA.DISC_PERC/100))
                     WHEN v_pay_tras_to='USD' THEN 
                          (SUM(C.PAY_AMT_IN_USD -(NVL(P.DISCOUNT_AMOUNT,0)/3.64))-((SUM(P.APPROVED_AMOUNT-NVL(P.DISCOUNT_AMOUNT,0))*FA.DISC_PERC/100))/3.64)
                     WHEN v_pay_tras_to='EUR' THEN
                          (SUM(C.PAY_AMT_IN_EURO -(NVL(P.DISCOUNT_AMOUNT,0)/C.CONV_RATE_IN_EURO))-((SUM(P.APPROVED_AMOUNT-NVL(P.DISCOUNT_AMOUNT,0))*FA.DISC_PERC/100))/C.CONV_RATE_IN_EURO)
                     WHEN v_pay_tras_to='GBP' THEN
                          (SUM(C.PAY_AMT_IN_GBP -(NVL(P.DISCOUNT_AMOUNT,0)/C.CONV_RATE_IN_GBP))-((SUM(P.APPROVED_AMOUNT-NVL(P.DISCOUNT_AMOUNT,0))*FA.DISC_PERC/100))/C.CONV_RATE_IN_GBP)    
                      WHEN v_pay_tras_to='IIC' THEN
                           (SUM(C.CONVERTED_FINAL_APPROVED_AMT -(NVL(P.DISCOUNT_AMOUNT,0)/C.CONVERSION_RATE))-((SUM(P.APPROVED_AMOUNT-NVL(P.DISCOUNT_AMOUNT,0))*FA.DISC_PERC/100))/C.CONVERSION_RATE)     
                 END   
             ELSE
               CASE WHEN v_pay_tras_to='QAR' THEN  
                         SUM(P.APPROVED_AMOUNT-NVL(P.DISCOUNT_AMOUNT,0)) 
                     WHEN v_pay_tras_to='USD' THEN 
                         SUM(C.PAY_AMT_IN_USD - (NVL(P.DISCOUNT_AMOUNT,0)/3.64))
                     WHEN v_pay_tras_to='GBP' THEN 
                         SUM(C.PAY_AMT_IN_GBP-(NVL(P.DISCOUNT_AMOUNT,0)/C.CONV_RATE_IN_GBP))
                    WHEN v_pay_tras_to='EUR' THEN 
                         SUM(C.PAY_AMT_IN_EURO - (NVL(P.DISCOUNT_AMOUNT,0)/C.CONV_RATE_IN_EURO))
                    WHEN v_pay_tras_to='IIC' THEN 
                         SUM(C.CONVERTED_FINAL_APPROVED_AMT -(NVL(P.DISCOUNT_AMOUNT,0)/C.CONVERSION_RATE) )     
                 END         
             END AS PAYABLE_IN_TRANSFER_CURRENCY,
             CASE WHEN FA.DISC_PERC IS NOT NULL AND SUM(P.APPROVED_AMOUNT-NVL(P.DISCOUNT_AMOUNT,0))+NVL(SUM(V.PREV_BATCH_AMOUNT),0)
                  BETWEEN FA.DISC_VOL_AMT_ST AND FA.DISC_VOL_AMT_ED THEN 
                CASE WHEN (SUM(P.APPROVED_AMOUNT-NVL(P.DISCOUNT_AMOUNT,0))*FA.DISC_PERC/100)-(V.DISCOUNT_AMOUNT)>0 THEN
                        (SUM(P.APPROVED_AMOUNT-NVL(P.DISCOUNT_AMOUNT,0))*FA.DISC_PERC/100)-(V.DISCOUNT_AMOUNT)
                   WHEN (SUM(P.APPROVED_AMOUNT-NVL(P.DISCOUNT_AMOUNT,0))*FA.DISC_PERC/100)-(V.DISCOUNT_AMOUNT)<0 THEN
                        (SUM(P.APPROVED_AMOUNT-NVL(P.DISCOUNT_AMOUNT,0))*FA.DISC_PERC/100)-(V.DISCOUNT_AMOUNT) END
              ELSE 0 END AS DISCOUNT
FROM TPA_CLAIMS_PAYMENT P
JOIN CLM_AUTHORIZATION_DETAILS C ON (P.CLAIM_SEQ_ID=C.CLAIM_SEQ_ID AND P.HOSP_SEQ_ID IS NOT NULL)
LEFT OUTER JOIN APP.TPA_FASTTRACT_DISC_DETAILS FA ON (FA.HOSP_SEQ_ID=P.HOSP_SEQ_ID) 
LEFT OUTER JOIN DISC_AMT V ON (V.PAID_MON_YEAR=TO_CHAR(DATE_OF_HOSPITALIZATION,'MM-YYYY'))
WHERE P.PAYMENT_SEQ_ID=PAY_SEQ_ID AND FA.DISC_TYPE='VOL' AND FA.STATUS='ACT' AND C.DATE_OF_HOSPITALIZATION BETWEEN FA.START_DATE AND FA.END_DATE
GROUP BY P.HOSP_SEQ_ID,FA.DISC_PERC,FA.DISC_VOL_AMT_ST,FA.DISC_VOL_AMT_ED,V.DISCOUNT_AMOUNT,PAY_AMT_IN_EURO,CONVERSION_RATE,CONV_RATE_IN_EURO,CONV_RATE_IN_GBP,
PAY_AMT_IN_USD,PAY_AMT_IN_GBP,CONVERTED_FINAL_APPROVED_AMT,TO_CHAR(C.DATE_OF_HOSPITALIZATION,'MM-YYYY');

     TYPE  MONWISE_VOL_BASE IS RECORD (
     CLAIM_APPR_AMT_IN_QAR 	NUMBER(20,2),
     APPR_AMT_WT_FASD       NUMBER(20,2),
     DISC_PER               NUMBER(20),
     HOSP_SEQ_ID            NUMBER(30),
     PAID_MON_YEAR          VARCHAR2(30),
     APPR_AMT_WT_VLBD       NUMBER(20,2),
     TRANSFER_AMT_ASP_CURR  NUMBER(20,2),
     DISC_AMT               NUMBER(20) );
                            
     MONWISE_VOL_BASE_REC   MONWISE_VOL_BASE;      
     
     TYPE MONTHWISE_VOL_BASE_DISC IS TABLE OF MONWISE_VOL_BASE_REC%TYPE;

     MONTH_VOL_DISC               MONTHWISE_VOL_BASE_DISC;  

     str_tab                      ttk_util_pkg.str_table_type;
     v_payment_seq_list           VARCHAR2(30000); 
     v_bank_type                  VARCHAR2(30):='QATAR'; 
     v_bank_seq_id                NUMBER(30);
     v_acc_num                    VARCHAR2(500);
     v_bank_advice_file_name      VARCHAR2(500);
     v_cnt                        number(10);
     v_disc_amt                   number(10,2);
     v_disc_per                   number(10,2);
BEGIN
    v_payment_seq_list := RTRIM(LTRIM (REPLACE(v_payment_seq_id,'|',','),','),',');
    
    str_tab := ttk_util_pkg.parse_str(v_payment_seq_id);

-- Fast Track Discounts Calculation

   IF str_tab.FIRST IS NOT NULL THEN
      FOR i IN str_tab.FIRST .. str_tab.LAST LOOP
          v_cnt:=TO_NUMBER(str_tab(i));
        open Get_Fasttract_Disc_Details(v_cnt);
             fetch Get_Fasttract_Disc_Details into v_disc_per,v_disc_amt;
                   close Get_Fasttract_Disc_Details;
     
            UPDATE tpa_claims_payment a
               SET A.discount_percent =v_disc_per,
                A.discount_amount =v_disc_amt 
            WHERE a.payment_seq_id = v_cnt;
      END LOOP;
   END IF;
   
---Volume Base Discount Calculation
FOR J IN str_tab.FIRST .. str_tab.LAST  LOOP
 
 -- Month Wise 
 IF v_vol_base_type='MNPD' THEN
   
 
 EXECUTE IMMEDIATE 'WITH DISC_AMT AS 
      (SELECT SUM(TR.APPR_AMT_WT_FASD) AS PREV_BATCH_AMOUNT,SUM(TR.DISC_AMT) AS DISCOUNT_AMOUNT,TR.HOSP_SEQ_ID,TR.PAID_MON_YEAR
          FROM FIN_APP.TPA_MONTHLY_DISC_AMTS TR
          LEFT OUTER JOIN APP.TPA_FASTTRACT_DISC_DETAILS FA ON (TR.HOSP_SEQ_ID=FA.HOSP_SEQ_ID AND FA.STATUS=''ACT'' AND FA.DISC_TYPE=''VOL'')
      WHERE TR.ADDED_DATE BETWEEN FA.START_DATE AND FA.END_DATE AND BATCH_NUM !='||v_batch_seq_id||' and tr.DISC_TYPE=''MON''
      GROUP BY TR.HOSP_SEQ_ID,TR.PAID_MON_YEAR)
              
        SELECT SUM(P.APPROVED_AMOUNT) AS CLAIM_APPR_AMT_IN_QAR ,
               SUM(P.APPROVED_AMOUNT-NVL(P.DISCOUNT_AMOUNT,0)) APPR_AMT_WT_FASD,
               FA.DISC_PERC AS DISC_PER,
               P.HOSP_SEQ_ID,
               TO_CHAR(C.DATE_OF_HOSPITALIZATION,''MM-YYYY'') AS PAID_MON_YEAR,
               CASE WHEN FA.DISC_PERC IS NOT NULL AND SUM(P.APPROVED_AMOUNT-NVL(P.DISCOUNT_AMOUNT,0))+NVL(SUM(V.PREV_BATCH_AMOUNT),0)
                 BETWEEN FA.DISC_VOL_AMT_ST AND FA.DISC_VOL_AMT_ED THEN 
                 (SUM(P.APPROVED_AMOUNT-NVL(P.DISCOUNT_AMOUNT,0))-(SUM(P.APPROVED_AMOUNT-NVL(P.DISCOUNT_AMOUNT,0))*FA.DISC_PERC/100)) 
               ELSE 
                SUM(P.APPROVED_AMOUNT-NVL(P.DISCOUNT_AMOUNT,0)) 
               END AS APPR_AMT_WT_VLBD,
               CASE WHEN FA.DISC_PERC IS NOT NULL AND SUM(P.APPROVED_AMOUNT-NVL(P.DISCOUNT_AMOUNT,0))+NVL(SUM(V.PREV_BATCH_AMOUNT),0)
                 BETWEEN FA.DISC_VOL_AMT_ST AND FA.DISC_VOL_AMT_ED THEN 
                  CASE WHEN '''||v_pay_tras_to||'''=''QAR'' THEN 
                            (SUM(P.APPROVED_AMOUNT-NVL(P.DISCOUNT_AMOUNT,0))-(SUM(P.APPROVED_AMOUNT-NVL(P.DISCOUNT_AMOUNT,0))*FA.DISC_PERC/100))
                       WHEN '''||v_pay_tras_to||'''=''USD'' THEN 
                            (SUM(C.PAY_AMT_IN_USD -(NVL(P.DISCOUNT_AMOUNT,0)/3.64))-((SUM(P.APPROVED_AMOUNT-NVL(P.DISCOUNT_AMOUNT,0))*FA.DISC_PERC/100))/3.64)
                       WHEN '''||v_pay_tras_to||'''=''EUR'' THEN
                            (SUM(C.PAY_AMT_IN_EURO -(NVL(P.DISCOUNT_AMOUNT,0)/C.CONV_RATE_IN_EURO))-((SUM(P.APPROVED_AMOUNT-NVL(P.DISCOUNT_AMOUNT,0))*FA.DISC_PERC/100))/C.CONV_RATE_IN_EURO)
                       WHEN '''||v_pay_tras_to||'''=''GBP'' THEN
                            (SUM(C.PAY_AMT_IN_GBP -(NVL(P.DISCOUNT_AMOUNT,0)/C.CONV_RATE_IN_GBP))-((SUM(P.APPROVED_AMOUNT-NVL(P.DISCOUNT_AMOUNT,0))*FA.DISC_PERC/100))/C.CONV_RATE_IN_GBP)    
                        WHEN '''||v_pay_tras_to||'''=''IIC'' THEN
                             (SUM(C.CONVERTED_FINAL_APPROVED_AMT -(NVL(P.DISCOUNT_AMOUNT,0)/C.CONVERSION_RATE))-((SUM(P.APPROVED_AMOUNT-NVL(P.DISCOUNT_AMOUNT,0))*FA.DISC_PERC/100))/C.CONVERSION_RATE)     
                   END   
               ELSE
                CASE WHEN '''||v_pay_tras_to||'''=''QAR'' THEN  
                         SUM(P.APPROVED_AMOUNT-NVL(P.DISCOUNT_AMOUNT,0)) 
                     WHEN '''||v_pay_tras_to||'''=''USD'' THEN 
                         SUM(C.PAY_AMT_IN_USD - (NVL(P.DISCOUNT_AMOUNT,0)/3.64))
                     WHEN '''||v_pay_tras_to||'''=''GBP'' THEN 
                         SUM(C.PAY_AMT_IN_GBP-(NVL(P.DISCOUNT_AMOUNT,0)/C.CONV_RATE_IN_GBP))
                    WHEN '''||v_pay_tras_to||'''=''EUR'' THEN 
                         SUM(C.PAY_AMT_IN_EURO - (NVL(P.DISCOUNT_AMOUNT,0)/C.CONV_RATE_IN_EURO))
                    WHEN '''||v_pay_tras_to||'''=''IIC'' THEN 
                         SUM(C.CONVERTED_FINAL_APPROVED_AMT -(NVL(P.DISCOUNT_AMOUNT,0)/C.CONVERSION_RATE) )     
                END         
              END AS TRANSFER_AMT_ASP_CURR,
              CASE WHEN FA.DISC_PERC IS NOT NULL AND SUM(P.APPROVED_AMOUNT-NVL(P.DISCOUNT_AMOUNT,0))+NVL(SUM(V.PREV_BATCH_AMOUNT),0)
                  BETWEEN FA.DISC_VOL_AMT_ST AND FA.DISC_VOL_AMT_ED THEN 
                CASE WHEN (SUM(P.APPROVED_AMOUNT-NVL(P.DISCOUNT_AMOUNT,0))*FA.DISC_PERC/100)-NVL(V.DISCOUNT_AMOUNT,0)>0 THEN
                        (SUM(P.APPROVED_AMOUNT-NVL(P.DISCOUNT_AMOUNT,0))*FA.DISC_PERC/100)-NVL(V.DISCOUNT_AMOUNT,0)
                   WHEN (SUM(P.APPROVED_AMOUNT-NVL(P.DISCOUNT_AMOUNT,0))*FA.DISC_PERC/100)-NVL(V.DISCOUNT_AMOUNT,0)<0 THEN
                        (SUM(P.APPROVED_AMOUNT-NVL(P.DISCOUNT_AMOUNT,0))*FA.DISC_PERC/100)-NVL(V.DISCOUNT_AMOUNT,0) END
              ELSE 0 END AS DISC_AMT
FROM TPA_CLAIMS_PAYMENT P
JOIN CLM_AUTHORIZATION_DETAILS C ON (P.CLAIM_SEQ_ID=C.CLAIM_SEQ_ID AND P.HOSP_SEQ_ID IS NOT NULL)
LEFT OUTER JOIN APP.TPA_FASTTRACT_DISC_DETAILS FA ON (FA.HOSP_SEQ_ID=P.HOSP_SEQ_ID) 
LEFT OUTER JOIN DISC_AMT V ON (V.PAID_MON_YEAR=TO_CHAR(DATE_OF_HOSPITALIZATION,''MM-YYYY''))
WHERE P.PAYMENT_SEQ_ID IN('||v_payment_seq_list || ')AND FA.DISC_MODE=''VOL'' AND FA.STATUS=''ACT'' AND C.DATE_OF_HOSPITALIZATION BETWEEN FA.START_DATE AND FA.END_DATE
GROUP BY P.HOSP_SEQ_ID,FA.DISC_PERC,FA.DISC_VOL_AMT_ST,FA.DISC_VOL_AMT_ED,V.DISCOUNT_AMOUNT,PAY_AMT_IN_EURO,CONVERSION_RATE,CONV_RATE_IN_EURO,CONV_RATE_IN_GBP,
 PAY_AMT_IN_USD,PAY_AMT_IN_GBP,CONVERTED_FINAL_APPROVED_AMT,TO_CHAR(C.DATE_OF_HOSPITALIZATION,''MM-YYYY'')' BULK COLLECT INTO MONTH_VOL_DISC;
 
 
  FORALL I IN  MONTH_VOL_DISC.FIRST..MONTH_VOL_DISC.LAST
    INSERT INTO FIN_APP.TPA_MONTHLY_DISC_AMTS
    (SEQ_ID,
    DISC_TYPE,
    DISC_PER,
    DISC_AMT,
    HOSP_SEQ_ID,
    PAID_MON_YEAR,
    BATCH_NUM,
    APPR_AMT_WT_FASD,
    ADDED_DATE,
    APPR_AMT_WT_VLBD,
    CLAIM_APPR_AMT_IN_QAR,
    TRANS_CURR,
    TRANSFER_AMT_ASP_CURR)
    VALUES
    (FIN_APP.disc_type_Seq.NEXTVAL,
    'MON',
    MONTH_VOL_DISC(i).DISC_PER,
    MONTH_VOL_DISC(i).DISC_AMT,
    MONTH_VOL_DISC(i).HOSP_SEQ_ID,
    MONTH_VOL_DISC(i).PAID_MON_YEAR,
    v_batch_seq_id,
    MONTH_VOL_DISC(i).APPR_AMT_WT_FASD,
    SYSDATE,
    MONTH_VOL_DISC(i).APPR_AMT_WT_VLBD,
    MONTH_VOL_DISC(i).CLAIM_APPR_AMT_IN_QAR,
    v_pay_tras_to,
    MONTH_VOL_DISC(i).TRANSFER_AMT_ASP_CURR);

  
 -- Anullay 
 /*ELSIF v_vol_base_type ='ANPD' THEN
  FOR I IN GET_MON_VOLBASE_DISC_DETAILS(v_batch_seq_id,str_tab(j)) LOOP
    INSERT INTO FIN_APP.TPA_MONTHLY_DISC_AMTS
    (SEQ_ID,DISC_TYPE,DISC_PER,DISC_AMT,HOSP_SEQ_ID,PAID_MON_YEAR,BATCH_NUM,APPR_AMT_WT_FASD,ADDED_DATE,APPR_AMT_WT_VLBD)
    VALUES
    (FIN_APP.disc_type_Seq.NEXTVAL,'ANUL',i.DISC_PERC,i.DISCOUNT,i.HOSP_SEQ_ID,i.PAY_MON_YEAR,v_batch_seq_id,i.APPR_AMT,sysdate,i.PAYABLE_IN_QAR);
  END LOOP; */
 END IF; 
END LOOP; 
 
END apply_fast_and_vol_discounts;
--=================================================================================================

--===========================================================================================
PROCEDURE finance_cheque_no_upld_err_log(v_batch_number in VARCHAR2,
                                         v_failed_count out SYS_REFCURSOR)
AS

 BEGIN
   
   OPEN v_failed_count for
    SELECT count(1)  as failed_count
      from fin_app.FINANCE_LOGS f 
      where f.batch_number= v_batch_number AND 
   UPPER(ERROR_MESSAGE) NOT LIKE UPPER('ORA-0000: normal, successful completion%');
 
 END  finance_cheque_no_upld_err_log;
  --=================================================================
  --search list of settlementNo to change status
  --Qatar support>>finance
  --FinanceStatusCorrection
  --*******************************************
  PROCEDURE settlement_list(p_settlement            IN   tpa_claims_payment.claim_settlement_no%TYPE,
                            p_payment_method        IN   VARCHAR2,
                            p_claim_type            IN   VARCHAR2,
                            p_advice_batchno        IN   TPA_BANK_ADVICE_BATCH.batch_seq_id%TYPE,
                            p_advice_batch_date     IN   VARCHAR2,
                            p_finance_status        IN   tpa_claims_payment.claim_payment_status%TYPE :='SENT_TO_BANK',   
                            p_sort_var              IN   VARCHAR2,
                            p_sort_order            IN   VARCHAR2,
                            p_start_num             IN   NUMBER,
                            p_end_num               IN   NUMBER,
                            result_set              OUT SYS_REFCURSOR
                           )IS
   
   v_string         VARCHAR2(32767);
   TYPE bind_tab_type IS TABLE OF VARCHAR2(250) INDEX BY BINARY_INTEGER;
   bind_tab      bind_tab_type;
   i             NUMBER(2) := 0;
   
   BEGIN
     v_string := 'SELECT cp.claim_settlement_no,
                          pm.tpa_enrollment_id,
                          gr.group_name,
                          ttk_util_pkg.fn_decrypt(cp.payee_name) payee_name,
                          cp.approved_amount AS Approved_Amt_QAR, 
                          ca.req_amt_currency_type,
                          ca.CONVERTED_FINAL_APPROVED_AMT AS Approved_Amt_Incurred_Currency
       
                     FROM tpa_claims_payment cp
                     JOIN tpa_payment_checks_details pc ON (pc.payment_seq_id = cp.payment_seq_id AND pc.v_csr_flag=1)
                     JOIN clm_authorization_details ca ON (cp.claim_seq_id = ca.claim_seq_id)
                     JOIN clm_batch_upload_details cb  ON (cb.clm_batch_seq_id=ca.clm_batch_seq_id)
                     JOIN tpa_enr_policy_member pm ON (pm.member_seq_id=cp.member_seq_id)
                     --JOIN tpa_enr_policy_group pg ON (pg.policy_group_seq_id=pm.policy_group_seq_id)
                     JOIN tpa_group_registration gr ON (gr.group_reg_seq_id=cp.group_reg_seq_id)
                LEFT JOIN TPA_BANK_ADVICE_BATCH ba ON(ba.batch_seq_id=cp.bank_advice_batch)     
                    WHERE cp.deleted_yn = ''N'' ';
                    
     IF p_settlement IS NOT NULL THEN
        v_string := v_string||' AND cp.claim_settlement_no = :p_settlement';
        i:=i+1;
        bind_tab(i):= p_settlement ;
     END IF;
     IF p_payment_method IS NOT NULL THEN
        v_string := v_string||' AND cp.payee_type = :p_payment_method';
        i:=i+1;
        bind_tab(i):= p_payment_method ;
     END IF;
     IF p_claim_type IS NOT NULL THEN
       IF p_claim_type ='PTN' THEN 
          v_string := v_string||' and cp.claim_type=''CNH'' and nvl(ca.PYMNT_TO_TYPE_ID,''PRV'') = :p_claim_type'; 
       ELSE 
          v_string := v_string||' AND cp.claim_type=:p_claim_type' ;
       END IF; 
        i:=i+1;
        bind_tab(i):= p_claim_type ;
     END IF;
     IF p_advice_batchno IS NOT NULL THEN
        v_string := v_string||' AND ba.batch_seq_id = :p_advice_batchno';
        i:=i+1;
        bind_tab(i):= p_advice_batchno ;
     END IF;
     IF p_advice_batch_date IS NOT NULL THEN
        v_string := v_string||' AND trunc(ba.batch_date) = :p_advice_batch_date';
        i:=i+1;
        bind_tab(i):= to_date(p_advice_batch_date,'dd/mm/yyyy') ;
     END IF;
     IF p_finance_status IS NOT NULL THEN
        v_string := v_string||' AND cp.claim_payment_status = :p_finance_status';
        i:=i+1;
        bind_tab(i):= p_finance_status ;
     END IF;
     v_string := 'SELECT * FROM
                 (SELECT A.*,DENSE_RANK() OVER (ORDER BY ' ||p_sort_var || ' ' || p_sort_order ||
                 ',ROWNUM)Q FROM (' || v_string ||') A ) WHERE  Q>= :p_start_num  AND Q<=  :p_end_num ';
    
    IF bind_tab.FIRST IS NOT NULL THEN
      CASE bind_tab.COUNT 
        WHEN 1 THEN OPEN result_set FOR v_string USING bind_tab(1), p_start_num, p_end_num;
        WHEN 2 THEN OPEN result_set FOR v_string USING bind_tab(1), bind_tab(2), p_start_num, p_end_num;
        WHEN 3 THEN OPEN result_set FOR v_string USING bind_tab(1), bind_tab(2), bind_tab(3), p_start_num, p_end_num;
        WHEN 4 THEN OPEN result_set FOR v_string USING bind_tab(1), bind_tab(2), bind_tab(3), bind_tab(4), p_start_num, p_end_num;
        WHEN 5 THEN OPEN result_set FOR v_string USING bind_tab(1), bind_tab(2), bind_tab(3), bind_tab(4),bind_tab(5),p_start_num, p_end_num;
        WHEN 6 THEN OPEN result_set FOR v_string USING bind_tab(1), bind_tab(2), bind_tab(3), bind_tab(4),bind_tab(5),bind_tab(6), p_start_num, p_end_num;
      END CASE;
    ELSE
      OPEN result_set FOR v_string USING p_start_num, p_end_num;
    END IF;
     
  END settlement_list;                         
 --================================================================== 
 PROCEDURE bringback_to_pending (p_settlement_no      IN  VARCHAR2,--|1180059384|1180060438||
                                 p_added_by           IN  NUMBER,
                                 p_remarks            IN  VARCHAR2,
                                 result_cnt           OUT NUMBER
                                )IS
                                
   CURSOR contact_cur IS SELECT contact_name FROM tpa_user_contacts WHERE contact_seq_id =p_added_by;
   v_contact_rec       contact_cur%ROWTYPE;
   
   str_tab               ttk_util_pkg.str_table_type := ttk_util_pkg.parse_str(p_settlement_no);
   v_err_log             VARCHAR2(32767) DEFAULT NULL;
   v_batchno             NUMBER(32);
   v_claims_chk_seq_id   NUMBER;
   v_bank_acc_seq_id     NUMBER;
   v_count               INTEGER:=0;
   v_str                 VARCHAR2(32767):=NULL;
   
   BEGIN
      
      FOR i in  str_tab.first..str_tab.last LOOP
        FOR rec IN (SELECT cp.payment_seq_id,cp.claim_settlement_no,cp.claim_payment_status,cp.bank_advice_batch,cp.float_seq_id,cp.approved_amount
                    FROM fin_app.tpa_claims_payment cp WHERE cp.claim_settlement_no= str_tab(i)) LOOP
            BEGIN
                  ---- delete for check issue ----
            delete from fin_app.tpa_payment_checks_details d where d.payment_seq_id=rec.payment_seq_id AND d.v_csr_flag= 1 returning d.claims_chk_seq_id into v_claims_chk_seq_id;
            delete from fin_app.tpa_claims_check r where r.claims_chk_seq_id = v_claims_chk_seq_id;
                  ---- update float balnace ----
            update fin_app.tpa_float_account f
               set f.current_balance = f.current_balance + rec.approved_amount
             where f.float_seq_id = rec.float_seq_id returning f.bank_acc_seq_id into  v_bank_acc_seq_id;
             
            update fin_app.tpa_bank_accounts b
               set b.bank_balance= b.bank_balance + rec.approved_amount
             where b.bank_acc_seq_id = v_bank_acc_seq_id;
                  ---- change status ----
            OPEN  contact_cur;
            FETCH contact_cur INTO v_contact_rec;
            CLOSE contact_cur;
            
            v_str :='STATUS CHANGED ON : '||to_char(SYSDATE,'dd/mm/rrrr hh:mi:ss')||CHR(10)||
                    'CHANGED BY : '||v_contact_rec.contact_name||CHR(10)||
                    'CHANGED FROM : '||rec.claim_payment_status ||' TO PENDING'||CHR(10)||
                    'REMARKS : '||p_remarks;
                      
            update fin_app.tpa_claims_payment pay  
               set pay.claim_payment_status='PENDING',
                   pay.changed_status_log = pay.changed_status_log||chr(10)||v_str
             where pay.claim_settlement_no=rec.claim_settlement_no AND pay.payment_seq_id=rec.payment_seq_id;
         
         V_COUNT:=V_COUNT+SQL%ROWCOUNT; 
         EXCEPTION
          WHEN OTHERS THEN
            save_finance_logs(NULL,NULL,SQLCODE,SQLERRM,'STATUS_CHANGE',NULL,rec.claim_settlement_no,NULL,NULL,NULL,NULL,NULL,p_added_by);
            ROLLBACK;
         END;   
        END LOOP;
      END LOOP;
   Claims_Dump_Into_ERP(p_settlement_no,NULL,'DEL');   
     COMMIT; 
     result_cnt := V_COUNT;
 END bringback_to_pending;
--===========================================================================================
--For Finance >> Payments>> Manual print check
--Existing print_check procedure was renamed to manual_print_check and this new print check was modifed
--===========================================================================================
PROCEDURE print_check (v_payment_seq_id IN VARCHAR2,
                       v_float_seq_id   IN TPA_FLOAT_ACCOUNT.float_seq_id%TYPE,
                       v_cheque_number  IN tpa_claims_check.check_num%TYPE,
                       v_payment_method IN TPA_CLAIMS_PAYMENT.payee_type%TYPE,
                       v_added_by       IN NUMBER,
                       v_batch_date     IN DATE,
                       v_rows_processed OUT INTEGER,
                       v_resultset      OUT SYS_REFCURSOR) IS

    i                 NUMBER(10) := 0;
    p_cheque_number   tpa_claims_check.check_num%TYPE;
    v_count           NUMBER(20) := 0;
    v_batch_number    tpa_batch_master.batch_number%TYPE;
    v_bank_acc_seq_id TPA_BANK_ACCOUNTS.BANK_ACC_SEQ_ID%TYPE;
    v_counter         NUMBER(20);
    v_counter1        NUMBER(20);
    v_flag            NUMBER(20);
    v_chq_seq_id      NUMBER(20);
    v_sum             tpa_float_account.current_balance%TYPE;
    v_approved_amt    tpa_claims_payment.approved_amount%TYPE;
    v_no_of_cheques   NUMBER(20);

    v_counter2 NUMBER(20);

    v_payment_seq_id_list VARCHAR2(32767) := REPLACE(SUBSTR(v_payment_seq_id,
                                                           2,
                                                           LENGTH(v_payment_seq_id) - 2),
                                                    '|',
                                                    ',');

    TYPE payment_cheques_type IS RECORD
    (
      payee_seq_id      tpa_claims_payment.payee_seq_id%type,
      cheque_amount     tpa_claims_check.check_amount%TYPE,
      group_reg_seq_id  tpa_claims_payment.group_reg_seq_id%TYPE,
      issue_cheque_to   tpa_claims_payment.tpa_cheque_issued_general_type%TYPE
     
      );

    TYPE payment_corp_table1 IS TABLE OF payment_cheques_type INDEX BY BINARY_INTEGER;
    TYPE seq_tab_type IS TABLE OF tpa_payment_checks_details.payment_seq_id%TYPE INDEX BY BINARY_INTEGER;
    TYPE cheque_num_tab_type IS TABLE OF tpa_claims_check.check_num%TYPE INDEX BY BINARY_INTEGER;

    seq_tab          seq_tab_type;
    cheque_num_tab   cheque_num_tab_type;
    v_table_index    payment_corp_table1;
    str_tab1          ttk_util_pkg.str_table_type;

 v_final_string     VARCHAR2(30000);
 v_sql_str1         VARCHAR2(4000);
 v_sqlstr2          VARCHAR2(4000);

 o_cheque_number    fin_app.tpa_claims_check.check_num%type;
 v_zeros_count      NUMBER(10):=0;
 v_file_name        fin_app.tpa_batch_master.file_name%type; 

  BEGIN

    IF (v_payment_method = 'PMM') THEN
      str_tab1 := ttk_util_pkg.parse_str(v_payment_seq_id);
      IF str_tab1.COUNT > 999 THEN
        RAISE_APPLICATION_ERROR(-20684,'Maximum selection allowed is 950. ');
      END IF;
      
      OPEN v_resultset FOR 'SELECT count(1) FROM tpa_claims_payment A
         WHERE A.payment_seq_id IN (' || v_payment_seq_id_list || ') AND a.claim_payment_status=''PAID''';
         FETCH v_resultset INTO v_counter2;
            CLOSE v_resultset;
            
      IF v_counter2 > 0 THEN
        RAISE_APPLICATION_ERROR(-20244, 'Claim(s) already PAID');
      END IF;
     
       OPEN v_resultset FOR 'SELECT count(1) FROM tpa_claims_payment A
         WHERE A.payment_seq_id IN (' || v_payment_seq_id_list || ') AND a.claim_type=''CNH''';
         FETCH v_resultset INTO v_counter2;
            CLOSE v_resultset;
      
      
      IF v_counter2 > 0 THEN
        RAISE_APPLICATION_ERROR(-20965, 'Currently Manual cheque is only for Member/Reiumbersment claims');
      END IF;

      INSERT INTO tpa_batch_master
        (batch_number, added_by, added_date)
      VALUES
        (batch_master_seq.NEXTVAL, v_added_by, SYSDATE)
      RETURNING batch_number INTO v_batch_number;

      FORALL i IN str_tab1.FIRST .. str_tab1.LAST
           UPDATE tpa_claims_payment a
               SET A.batch_number_manual  = batch_master_seq.currval
             WHERE A.payment_seq_id = str_tab1(i);
    
      --getting bank_acc_number to check the check number issued to the bank_account.
      SELECT a.bank_acc_seq_id
        INTO v_bank_acc_seq_id
        FROM tpa_float_account a
       WHERE a.float_seq_id = v_float_seq_id;
       
     OPEN v_resultset FOR 'SELECT  payee_seq_id as payee_name,
                                   sum(a.approved_amount) AS tot_amt,
                                   a.group_reg_seq_id,
                                   a.tpa_cheque_issued_general_type as cheq_issue
                                   
      FROM tpa_claims_payment a
      WHERE a.payment_seq_id IN (' || v_payment_seq_id_list || ')
      GROUP BY payee_seq_id,a.tpa_cheque_issued_general_type,a.group_reg_seq_id';
      FETCH v_resultset BULK COLLECT
        INTO v_table_index;
      CLOSE v_resultset;
 
    p_cheque_number:= v_cheque_number;
    
    o_cheque_number := CASE WHEN substr(v_cheque_number,1,1)=0 THEN 'Y' ELSE 'N' END;

 
    FOR I IN v_table_index.FIRST..v_table_index.LAST LOOP
      
       
        
       INSERT INTO FIN_APP.TPA_MANUAL_PRINT_CHECK_REF 
        (PAYEE_NAME,PAYABLE_AMT,GRP_REG_SEQ,TPA_CHEQ_ISSUE_GEN,MANUAL_BATCH_NO,CHEQUE_NUMBER,ADDED_DATE)
        VALUES
        (v_table_index(i).payee_seq_id,v_table_index(i).cheque_amount,v_table_index(i).group_reg_seq_id ,v_table_index(i).issue_cheque_to,v_batch_number,
        p_cheque_number,SYSDATE);
        
         p_cheque_number := p_cheque_number+1;
         
         p_cheque_number:= CASE WHEN o_cheque_number='Y' and substr(p_cheque_number,1,1)!=0 THEN 
                                     lpad(p_cheque_number,(length(v_cheque_number)),'0') 
                                ELSE p_cheque_number END;

    END LOOP;    
     
          --checking the check number issued to this account_number else display error
          SELECT COUNT(1)
            INTO v_counter
            FROM tpa_cheque_series b
           WHERE v_cheque_number BETWEEN chk_start_num AND chk_end_num
             AND b.bank_acc_seq_id = v_bank_acc_seq_id;

          IF (v_counter = 1) THEN
            --this query gives info abt the check number is already issued or not.
            FLOAT_ACCOUNTS_PKG.cheque_nos_issued_yn(v_bank_acc_seq_id,
                                                    v_cheque_number,
                                                    v_counter1);
            IF (v_counter1 >= 1) THEN
              RAISE_APPLICATION_ERROR(-20213,
                                      'cannot be issued same check to the same bank account');
            ELSIF (v_counter1 = 0) THEN
                         null;
            END IF;
          ELSE
            RAISE_APPLICATION_ERROR(-20212,
                                    'check number  is not in database/not issued to this bank account');
          END IF;
       

      --insert the chqeque nos into tpa_claims_check
      FOR lvar IN (select MREF.cheque_number,PAY.Payment_Seq_Id,mref.payable_amt 
                   from FIN_APP.TPA_MANUAL_PRINT_CHECK_REF MREF
                   join FIN_APP.TPA_CLAIMS_PAYMENT PAY ON (MREF.MANUAL_BATCH_NO=PAY.BATCH_NUMBER_MANUAL)
                   where MREF.manual_batch_no= v_batch_number AND mref.payee_name=pay.payee_seq_id) LOOP
        IF ( lvar.payment_seq_id IS NOT NULL AND lvar.cheque_number IS NOT NULL) THEN
          --check this no is issued with this batch.
          SELECT COUNT(1)
            INTO v_flag
            FROM tpa_claims_check a
           WHERE a.batch_number = v_batch_number
             AND a.check_num = lvar.cheque_number;

          --if already issued then please update the check amount
          IF (v_flag >= 1) THEN

            UPDATE tpa_claims_check a
               SET a.check_amount = lvar.payable_amt
             WHERE a.batch_number = v_batch_number
               AND a.check_num =  lvar.cheque_number;

            --get the claims_chk_seq_id
            SELECT a.claims_chk_seq_id
              INTO v_chq_seq_id
              FROM tpa_claims_check a
             WHERE a.batch_number = v_batch_number
               AND a.check_num =  lvar.cheque_number;

            --insert into duplicate record to tpa_payment_check_details
            --printed cheques for  particular payments information is stored.
            INSERT INTO tpa_payment_checks_details
              (payment_check_seq_id,
               payment_seq_id,
               claims_chk_seq_id,
               added_by,
               Added_date)
            VALUES
              (claims_payment_check_seq.NEXTVAL,
               lvar.payment_seQ_id,
               v_chq_seq_id,
               v_added_by,
               SYSDATE);

          ELSIF (v_flag = 0) THEN

            INSERT INTO tpa_claims_check
              (claims_chk_seq_id,
               check_num,
               check_amount,
               check_date,
               check_status,
               courier_delivery_date,
               added_by,
               added_date,
               batch_number,
               PAYMENT_TYPE) 
            VALUES
              (claims_chk_seq.NEXTVAL,
               lvar.cheque_number,
               lvar.payable_amt,
               SYSDATE,
               'CSI',
               SYSDATE,
               V_added_by,
               SYSDATE,
               v_batch_number,
               'PMM'); 
            --printed cheques for  particular payments information is stored.
            INSERT INTO tpa_payment_checks_details
              (payment_check_seq_id,
               payment_seq_id,
               claims_chk_seq_id,
               added_by,
               added_date)
            VALUES
              (claims_payment_check_seq.NEXTVAL,
               lvar.payment_seq_id,
               claims_chk_seq.CURRVAL,
               v_added_by,
               SYSDATE);
          END IF;
        END IF;
      END LOOP; 


      SELECT COUNT(1),SUM(PAYABLE_AMT)
        INTO v_no_of_cheques, v_approved_amt
         FROM FIN_APP.TPA_MANUAL_PRINT_CHECK_REF MREF 
      WHERE MREF.MANUAL_BATCH_NO = v_batch_number;

      --these updation should only occur when batch number creation
      IF (v_no_of_cheques > 0) THEN

        --updating current balance
        UPDATE tpa_float_account
           SET current_balance =
               (current_balance - v_approved_amt)
         WHERE float_seq_id = v_float_seq_id;

        --updating the balance of  the account number.
        UPDATE tpa_bank_accounts
           SET bank_balance =
               (bank_balance - v_approved_amt)
         WHERE bank_acc_seq_id = v_bank_acc_seq_id;

        --cursor get payment ids
        OPEN v_resultset FOR
          SELECT a.payment_seq_id, b.check_num
            FROM tpa_payment_checks_details a
            JOIN tpa_claims_check b
              on (a.claims_chk_seq_id = b.claims_chk_seq_id)
           WHERE b.batch_number = v_batch_number;
        FETCH v_resultset BULK COLLECT
          INTO seq_tab, cheque_num_tab;
        CLOSE v_resultset;

        IF seq_tab.FIRST IS NOT NULL THEN
          FORALL i IN seq_tab.FIRST .. seq_tab.LAST
            UPDATE tpa_claims_payment a
               SET a.claim_payment_status = 'PAID',
                   A.payee_type           = v_payment_method
             WHERE A.payment_seq_id = seq_tab(i);

          FOR i IN seq_tab.FIRST .. seq_tab.LAST --Added for CR - KOC1025
           LOOP
            GENERATE_MAIL_PKG.proc_form_message('FINANCE_PAYMENT_CHQ',
                                                seq_tab(i),
                                                v_added_by,
                                                v_dest_msg_seq_id);
          END LOOP;

          FORALL i IN cheque_num_tab.FIRST .. cheque_num_tab.LAST
            UPDATE tpa_cheque_series
               SET issued_yn = 'Y'
             WHERE cheque_num_tab(i) BETWEEN chk_start_num AND chk_end_num
               AND bank_acc_seq_id = v_bank_acc_seq_id;
        END IF;

        --values are updated to respective batch number.
        UPDATE tpa_batch_master
           SET batch_date        = v_batch_date,
               number_of_cheques = v_no_of_cheques,
               batch_amount      = v_approved_amt,
               file_name         = 'ClaimCheque_'||v_batch_number||'_'||TO_CHAR(v_batch_date, 'DDMMYYYY')
         WHERE batch_number = v_batch_number RETURNING file_name INTO v_file_name;

      END IF; 

      --displaying cheque information into pdf style as per uti/citi bank cheque leaf format.
  FOR I IN (SELECT TO_CHAR(WM_CONCAT(PAYMENT_SEQ_ID)) AS PAYMENT_SEQ_ID,tpa_cheque_issued_general_type FROM tpa_claims_payment
                   WHERE batch_number_manual=v_batch_number  GROUP BY tpa_cheque_issued_general_type) LOOP

  IF I.TPA_CHEQUE_ISSUED_GENERAL_TYPE ='IQI' THEN
         v_sql_str1:=
           'select payee_name, member_id,approved_amount,
                         case when cnt<=7 then APP_AMT_WORD else   SUBSTR(APP_AMT_WORD,1,INSTR(APP_AMT_WORD,'' '',1,8)) end as amt1,
                         case when cnt<=7 then null else SUBSTR(APP_AMT_WORD,INSTR(APP_AMT_WORD,'' '',1,8)) end AS AMT2,
                         check_num,check_date,account_number,member_name,mobile_no,vishwa,file_name from 
           (SELECT ttk_util_pkg.fn_decrypt(a.payee_name) as payee_name,
               g.tpa_enrollment_number as member_id,
               SUM(a.approved_amount) approved_amount,
               TTK_UTIL_PKG.NUM_TO_WORD_CONV(SUM(a.approved_amount)) AS APP_AMT_WORD,
                REGEXP_COUNT(TTK_UTIL_PKG.NUM_TO_WORD_CONV(SUM(a.approved_amount)),'' '') as cnt ,c.check_num,
               to_char(c.check_date, ''DD-MON-YYYY'') AS check_date,
               e.account_number,
               g.insured_name AS member_name,
               nvl(ttk_util_pkg.fn_decrypt(pr.mobile_no),''Not Available'') AS mobile_no,
               '||v_no_of_cheques||' as vishwa,
               '''||v_file_name||''' as file_name
          FROM tpa_claims_payment A
          JOIN tpa_enr_policy p on (a.policy_seq_id=p.policy_seq_id)
          JOIN tpa_enr_policy_group g on (p.policy_seq_id=g.policy_seq_id)
          JOIN tpa_enr_policy_member m on (g.policy_group_seq_id=m.policy_group_seq_id and a.member_seq_id=m.member_seq_id)
          JOIN tpa_enr_mem_address pr on (pr.enr_address_seq_id=g.enr_address_seq_id)
          JOIN tpa_payment_checks_details b ON (a.payment_seq_id = b.payment_seq_id)
          JOIN tpa_claims_check C ON (b.claims_chk_seq_id = c.claims_chk_seq_id)
          JOIN tpa_float_account D ON (D.float_seq_id = a.float_seq_id)
          JOIN tpa_bank_accounts E ON (d.bank_acc_seq_id = e.bank_acc_seq_id)
          LEFT OUTER JOIN tpa_clm_tds_details f ON (a.payment_seq_id = f.payment_seq_id)
         WHERE c.check_status = ''CSI'' and A.TPA_CHEQUE_ISSUED_GENERAL_TYPE=''IQI'' AND c.batch_number = ( ' ||v_batch_number||' )'||'
         GROUP BY c.check_num,
                  ttk_util_pkg.fn_decrypt(a.payee_name),
                  e.account_number,
                  c.check_date,
                  g.insured_name,
                  ttk_util_pkg.fn_decrypt(pr.mobile_no),
                  g.tpa_enrollment_number) ';
         
   ELSIF I.TPA_CHEQUE_ISSUED_GENERAL_TYPE='IQC' THEN
         
         V_SQLSTR2:=
         
         'select payee_name, member_id,approved_amount,
                         case when cnt<=7 then APP_AMT_WORD else   SUBSTR(APP_AMT_WORD,1,INSTR(APP_AMT_WORD,'' '',1,8)) end as amt1,
                         case when cnt<=7 then null else SUBSTR(APP_AMT_WORD,INSTR(APP_AMT_WORD,'' '',1,8)) end AS AMT2,
                         check_num,check_date,account_number,member_name,mobile_no,vishwa,file_name from
             (SELECT ttk_util_pkg.fn_decrypt(a.payee_name) as payee_name,
               GROUP_ID as member_id,
               SUM(a.approved_amount) approved_amount,
               TTK_UTIL_PKG.NUM_TO_WORD_CONV(SUM(a.approved_amount)) AS APP_AMT_WORD,
               REGEXP_COUNT(TTK_UTIL_PKG.NUM_TO_WORD_CONV(SUM(a.approved_amount)),'' '') as cnt,
               c.check_num,
               to_char(c.check_date, ''DD-MON-YYYY'') AS check_date,
               e.account_number,
               gr.group_name as member_name,
               to_char(gad.OFFICE_PHONE1) as mobile_no,
               '||v_no_of_cheques||' as vishwa,
               '''||v_file_name||''' as file_name
          FROM tpa_claims_payment A
          JOIN tpa_enr_policy p on (a.policy_seq_id=p.policy_seq_id)
          JOIN TPA_GROUP_REGISTRATION Gr ON (gr.group_reg_seq_id=p.group_reg_seq_id)
          JOIN TPA_ADDRESS gad ON (gr.group_reg_seq_id=gad.group_reg_seq_id)
          LEFT OUTER JOIN tpa_city_code gci on (gad.city_type_id=gci.city_type_id)
          JOIN tpa_state_code gst on (gad.state_type_id=gst.state_type_id)
          JOIN tpa_country_code gcc on (gad.country_id=gcc.country_id)
          JOIN tpa_payment_checks_details b ON (a.payment_seq_id = b.payment_seq_id)
          JOIN tpa_claims_check C ON (b.claims_chk_seq_id = c.claims_chk_seq_id)
          JOIN tpa_float_account D ON (D.float_seq_id = a.float_seq_id)
          JOIN tpa_bank_accounts E ON (d.bank_acc_seq_id = e.bank_acc_seq_id)
          LEFT OUTER JOIN tpa_clm_tds_details f ON (a.payment_seq_id = f.payment_seq_id)
         WHERE c.check_status = ''CSI'' and A.TPA_CHEQUE_ISSUED_GENERAL_TYPE=''IQC'' AND c.batch_number = ( '||v_batch_number||')'||'
         GROUP BY c.check_num,
                  ttk_util_pkg.fn_decrypt(a.payee_name),
                  e.account_number,
                  c.check_date,
                  gad.office_phone1,
                  gr.group_name,
                  GROUP_ID)';
      ELSE
           NULL;
      END IF;          
  END LOOP; 
  
v_final_string:= CASE WHEN v_sql_str1 is not null and V_SQLSTR2 is not null then
                        v_sql_str1 ||' union all ' ||V_SQLSTR2
                      WHEN v_sql_str1 is not null and V_SQLSTR2 is null then
                        v_sql_str1
                      WHEN v_sql_str1 is null and V_SQLSTR2 is not null then
                          V_SQLSTR2 end;
                          
 v_final_string:= v_final_string ||' ORDER BY check_num ASC ';
      
open v_resultset FOR v_final_string;  
      v_rows_processed := str_tab1.COUNT;
    COMMIT;
    ELSE
      RAISE_APPLICATION_ERROR(-20211,
                              'enter correct payment method manual');
    END IF;
  END print_check;
--===========================================================================================
 ---- Manual Cheque Generation Report Log
PROCEDURE view_manual_check_rpt(v_float_seq_id        IN TPA_FLOAT_ACCOUNT.float_seq_id%TYPE,
                                v_file_name           IN OUT TPA_BANK_ADVICE_BATCH.file_name%TYPE,
                                v_batch_number        IN TPA_BANK_ADVICE_BATCH.batch_seq_id%TYPE,
                                v_claim_settlement_no IN OUT tpa_claims_payment.claim_settlement_no%TYPE,
                                v_batch_date          IN VARCHAR2,
                                v_sort_var            IN VARCHAR2,
                                v_sort_order          IN VARCHAR2,
                                v_start_num           IN NUMBER,
                                v_end_num             IN NUMBER,
                                v_resultset           OUT SYS_REFCURSOR) IS
  
     v_sql_str            VARCHAR2(32000);
     v_where              VARCHAR2(2000);
     v_clm_settlement_str VARCHAR2(1000);
     v_clm_where_str      VARCHAR2(1000);
     p_batch_date         DATE := TO_DATE(v_batch_date, 'DD/MM/YYYY');
     TYPE bind_tab_type IS TABLE OF VARCHAR2(250) INDEX BY BINARY_INTEGER ;
	   bind_tab                             bind_tab_type;
     i                                    NUMBER(2) := 0;

  BEGIN
    IF v_file_name IS NOT NULL THEN
      v_file_name := UPPER(v_file_name) || '%';
    END IF;
    
    IF v_claim_settlement_no IS NOT NULL THEN
      v_claim_settlement_no := upper(v_claim_settlement_no);
      v_clm_where_str       := ' AND ( :v_claim_settlement_no IS NULL OR b.claim_settlement_no = :v_claim_settlement_no )';

    END IF;
    
    v_sql_str := 'SELECT distinct
      ''BatchReport_''||A.batch_number||''.pdf'' as File_name,
      A.batch_number,
      a.batch_date
      FROM tpa_batch_master A JOIN tpa_claims_payment b ON  (a.batch_number = b.batch_number_manual) 
      WHERE a.file_name IS NOT NULL 
      AND b.float_seq_id = :v_float_seq_id
      AND ( :v_file_name IS NULL OR upper(A.file_name) LIKE :v_file_name OR instr(''BATCHREPORT_''||a.batch_number, rtrim(:v_file_name,''%''))>0 )
      AND ( :v_batch_number IS NULL OR A.batch_number = :v_batch_number)
      AND ( :p_batch_date IS NULL OR TRUNC(A.batch_date) = :p_batch_date )
      AND ( :v_claim_settlement_no IS NULL OR b.claim_settlement_no = :v_claim_settlement_no )
	    
     UNION ALL
     
	    SELECT distinct
      A.file_name||''.pdf'' as File_name,
      A.batch_number,
      a.batch_date
      FROM tpa_batch_master A JOIN tpa_claims_payment b ON  (a.batch_number = b.batch_number_manual) 
      WHERE a.file_name IS NOT NULL 
      AND b.float_seq_id = :v_float_seq_id
      AND ( :v_file_name IS NULL OR upper(A.file_name) LIKE :v_file_name OR instr(''BATCHREPORT_''||a.batch_number, rtrim(:v_file_name,''%''))>0 )
      AND ( :v_batch_number IS NULL OR A.batch_number = :v_batch_number)
      AND ( :p_batch_date IS NULL OR TRUNC(A.batch_date) = :p_batch_date )
      AND ( :v_claim_settlement_no IS NULL OR b.claim_settlement_no = :v_claim_settlement_no )';
  
   v_sql_str := 'SELECT * FROM
                     (SELECT A.*,DENSE_RANK() OVER (ORDER BY ' ||
                 v_sort_var|| ' ' || v_sort_order ||
                 ',ROWNUM)
                      Q FROM (' || v_sql_str ||
                 ') A ) WHERE  Q>= :v_start_num  AND Q<=  :v_end_num '; 
                 
      OPEN v_resultset FOR v_sql_str
        USING  v_float_seq_id,v_file_name, v_file_name,v_file_name, v_batch_number, v_batch_number, p_batch_date, p_batch_date, v_claim_settlement_no, v_claim_settlement_no,
               v_float_seq_id,v_file_name, v_file_name,v_file_name, v_batch_number, v_batch_number, p_batch_date, p_batch_date, v_claim_settlement_no, v_claim_settlement_no,
               v_start_num, v_end_num;
               
END view_manual_check_rpt;
--===================================================================================================
--Added For Oracle ERP data Integration Purpose
--Added on 20-12-2019
--==================================================================================================
PROCEDURE Claims_Dump_Into_ERP (v_payment_seq_id   IN VARCHAR,
                         v_pay_adv_batch    IN NUMBER,
                         v_flag             IN VARCHAR2
                        )
 AS
  v_payment_seq_list    VARCHAR2(32767);
  
  TYPE Claims_consolid_info IS RECORD
  (
  v_payee_seq_id  fin_app.tpa_claims_payment.payee_seq_id%type,
  v_appr_amount   fin_app.tpa_claims_payment.approved_amount%type,
  v_supplier_code app.tpa_hosp_info.erp_supplier_id%type,
  v_customer_code app.tpa_hosp_info.erp_customer_id%type
  ); 
  
  TYPE Claims_cons_Payment_Info IS TABLE OF Claims_consolid_info INDEX BY BINARY_INTEGER;
 
  Claims_cons_Payment_Rec       Claims_cons_Payment_Info;
   
  TYPE Claims_Details_info IS RECORD
  (
  v_settelment_no  fin_app.tpa_claims_payment.claim_settlement_no%type,
  v_appr_amount    fin_app.tpa_claims_payment.approved_amount%type,
  v_hosp_name      app.tpa_hosp_info.hosp_name%type,
  v_empanel_num    app.tpa_hosp_info.empanel_number%type
  );
 
  TYPE Claims_detail_Payment_Info IS TABLE OF Claims_Details_info INDEX BY BINARY_INTEGER;

  Claims_detail_Payment_Rec      Claims_detail_Payment_Info;
  
   TYPE Reverted_Claims_Details_info IS RECORD
  (
  v_settelment_no  fin_app.tpa_claims_payment.claim_settlement_no%type,
  v_appr_amount    fin_app.tpa_claims_payment.approved_amount%type,
  v_hosp_name      app.tpa_hosp_info.hosp_name%type,
  v_empanel_num    app.tpa_hosp_info.empanel_number%type,
  v_batch_number   fin_app.tpa_claims_payment.bank_advice_batch%type
  );
  
  TYPE Rev_Claims_detail_Payment_Info IS TABLE OF Reverted_Claims_Details_info INDEX BY BINARY_INTEGER;

  Rev_Claims_detail_Payment_Rec Rev_Claims_detail_Payment_Info;
   
BEGIN

 v_payment_seq_list := RTRIM(LTRIM (REPLACE(v_payment_seq_id,'|',','),','),',');
 
IF v_flag='ADD' THEN   -- While Generating Payment Advice it is ADD
       
   EXECUTE IMMEDIATE 'SELECT Payee_Seq_Id, SUM(Approved_Amount) AS APP_AMOUNT,GR.ERP_SUPPLIER_ID,GR.ERP_CUSTOMER_ID 
                         FROM  Tpa_Claims_Payment PAY
                     join tpa_hosp_info gr on (pay.Hosp_Seq_Id=gr.Hosp_Seq_Id)
                     WHERE pay.Claim_Type=''CNH'' AND pay.PAYMENT_SEQ_ID IN ('||v_payment_seq_list||' ) 
                    GROUP BY Payee_Seq_Id,GR.ERP_SUPPLIER_ID,GR.ERP_CUSTOMER_ID' 
                    BULK COLLECT INTO Claims_cons_Payment_Rec;
--Consolidted format                    
  IF Claims_cons_Payment_Rec.COUNT>0 AND Claims_cons_Payment_Rec.FIRST IS NOT NULL THEN
    FOR inf in Claims_cons_Payment_Rec.FIRST..Claims_cons_Payment_Rec.LAST LOOP
      INSERT INTO FIN_APP.ORA_ERP_CLAIM_CONSOL_PAYMENT 
      (TRANS_REF_NUM,SUPPLIER_NUM,CUSTOMER_NUM,CURRENCY_CODE,NET_CLM_PAID_AMT,DOCUMENT_DATE,DUE_DATE,BATCH_REF_ID,PAYEE_SEQ_ID)
      VALUES
      ('088'|| LPAD(FIN_APP.FINACE_ERP_SEQUENCE_VAL.NEXTVAL,10,'0')||TO_CHAR(SYSDATE,'MMYYYY'),
       Claims_cons_Payment_Rec(inf).v_supplier_code, Claims_cons_Payment_Rec(inf).v_customer_code,'QAR',
       Claims_cons_Payment_Rec(inf).v_appr_amount, SYSDATE, SYSDATE,v_pay_adv_batch,Claims_cons_Payment_Rec(inf).v_payee_seq_id);
    END LOOP;
  END IF;               

 EXECUTE IMMEDIATE 'select Pay.Claim_Settlement_No,Pay.Approved_Amount,Hi.Hosp_Name,Hi.Empanel_Number
                    from Tpa_Claims_Payment pay
                    join Tpa_hosp_info hi on (Pay.Hosp_Seq_Id=Hi.Hosp_Seq_Id)
                    where pay.PAYMENT_SEQ_ID in ('||v_payment_seq_list||') and pay.claim_type=''CNH'''
                    BULK COLLECT INTO Claims_detail_Payment_Rec;
 --Details format                     
  IF Claims_detail_Payment_Rec.COUNT>0 AND Claims_detail_Payment_Rec.FIRST IS NOT NULL THEN
    FOR rec IN Claims_detail_Payment_Rec.FIRST..Claims_detail_Payment_Rec.LAST LOOP
      INSERT INTO FIN_APP.ORA_ERP_CLAIM_PAYMENT_DTLS
      (BATCH_ID,PROVIDER_ID,PROVIDER_NAME,CLAIM_NUMBER,CLAIM_AMT,CURRENCY_CODE,PAYMENT_ADV_DATE,REVERTED_YN)
      VALUES
      (v_pay_adv_batch,Claims_detail_Payment_Rec(rec).v_empanel_num , Claims_detail_Payment_Rec(rec).v_hosp_name,
       Claims_detail_Payment_Rec(rec).v_settelment_no,Claims_detail_Payment_Rec(rec).v_appr_amount,'QAR' ,SYSDATE,'N' 
      );
    END LOOP;
  END IF;         
           
 ELSIF v_flag='DEL' THEN -- While doing Bring back to pending it is DEL
  
  EXECUTE IMMEDIATE 'select Pay.Claim_Settlement_No,Pay.Approved_Amount,Hi.Hosp_Name,
                      Hi.Empanel_Number,pay.bank_advice_batch
                    from Tpa_Claims_Payment pay
                    join Tpa_hosp_info hi on (Pay.Hosp_Seq_Id=Hi.Hosp_Seq_Id)
                    where pay.claim_settlement_no in ('''||v_payment_seq_list||''') and pay.claim_type=''CNH'''
                    BULK COLLECT INTO Rev_Claims_detail_Payment_Rec;
   --Details format                  
   IF Rev_Claims_detail_Payment_Rec.COUNT>0 AND Rev_Claims_detail_Payment_Rec.FIRST IS NOT NULL THEN
    
     FOR rec IN Rev_Claims_detail_Payment_Rec.FIRST..Rev_Claims_detail_Payment_Rec.LAST LOOP
       INSERT INTO FIN_APP.ORA_ERP_CLAIM_PAYMENT_DTLS
       (BATCH_ID,PROVIDER_ID,PROVIDER_NAME,CLAIM_NUMBER,CLAIM_AMT,CURRENCY_CODE,PAYMENT_ADV_DATE,REVERTED_YN)
       VALUES
       (Rev_Claims_detail_Payment_Rec(rec).v_batch_number,Rev_Claims_detail_Payment_Rec(rec).v_empanel_num , Rev_Claims_detail_Payment_Rec(rec).v_hosp_name,
        Rev_Claims_detail_Payment_Rec(rec).v_settelment_no,Rev_Claims_detail_Payment_Rec(rec).v_appr_amount,'QAR' ,SYSDATE,'Y' 
        );
     END LOOP;
  
   END IF;                 
 END IF;   
END Claims_Dump_Into_ERP;
--===================================================================================================
PROCEDURE Invoice_Dump_Into_ERP (v_invoice_seq_id VARCHAR2,
                                 v_policy_seq_id  VARCHAR2,
                                 v_mod_flag       VARCHAR2,
                                 v_success_YN OUT VARCHAR2)
  AS
  CURSOR Get_Inv_Premium_Details IS
   SELECT POL.POLICY_NUMBER,SUM(mem.inv_amount) AS TOTAL_PREMIUM,SUM(CASE WHEN mem.gender_general_type_id='MAL' THEN 0 
          WHEN mem.gender_general_type_id='FEM' AND marital_status_id='MRD' THEN MEM.Mem_Mat_Pro_Rata_Preim END ) AS MAT_PREMIUM,
          GREG.ERP_CUSTOMER_ID,GREG.ERP_SUPPLIER_ID,POL.EFFECTIVE_FROM_DATE,POL.EFFECTIVE_TO_DATE,mem.inv_curnt_seq_id
    FROM TPA_ENR_POLICY_MEMBER MEM
     JOIN TPA_ENR_POLICY_GROUP GR ON (MEM.POLICY_GROUP_SEQ_ID=GR.POLICY_GROUP_SEQ_ID)
     JOIN TPA_ENR_POLICY POL ON (GR.POLICY_SEQ_ID=POL.POLICY_SEQ_ID)
     JOIN TPA_GROUP_REGISTRATION GREG ON (POL.GROUP_REG_SEQ_ID=GREG.GROUP_REG_SEQ_ID)
   WHERE POL.POLICY_SEQ_ID = v_policy_seq_id AND MEM.Inv_Lnked_Seq_Ids like '%'|| v_invoice_seq_id ||'%'
   GROUP BY POL.POLICY_NUMBER,GREG.ERP_CUSTOMER_ID,GREG.ERP_SUPPLIER_ID,POL.EFFECTIVE_FROM_DATE,POL.EFFECTIVE_TO_DATE
   ,mem.inv_curnt_seq_id;  
   
  CURSOR Get_Inv_payment_cond IS
  SELECT INV.INV_GEN_PERIOD,INV.DUE_DATE_1,INV.DUE_DATE_2,INV.DUE_DATE_3,INV.DUE_DATE_4,INV.TRANS_REF_NUM 
    FROM FIN_APP.TPA_FIN_INVOICE INV WHERE INV.INVOICE_SEQ_ID = v_invoice_seq_id;
    
   Get_Inv_payment_Rec Get_Inv_payment_cond%ROWType;
   
 CURSOR Get_Crn_Premium_Details IS
  SELECT POL.POLICY_NUMBER,(0 - SUM(MEM.CRN_AMOUNT)) AS TOTAL_REFUND,
          GREG.ERP_CUSTOMER_ID,GREG.ERP_SUPPLIER_ID,POL.EFFECTIVE_FROM_DATE,POL.EFFECTIVE_TO_DATE
    FROM TPA_ENR_POLICY_MEMBER MEM
     JOIN TPA_ENR_POLICY_GROUP GR ON (MEM.POLICY_GROUP_SEQ_ID=GR.POLICY_GROUP_SEQ_ID)
     JOIN TPA_ENR_POLICY POL ON (GR.POLICY_SEQ_ID=POL.POLICY_SEQ_ID)
     JOIN TPA_GROUP_REGISTRATION GREG ON (POL.GROUP_REG_SEQ_ID=GREG.GROUP_REG_SEQ_ID)
   WHERE POL.POLICY_SEQ_ID = v_policy_seq_id AND MEM.CRN_LNKED_SEQ_IDS = v_invoice_seq_id
   GROUP BY POL.POLICY_NUMBER,GREG.ERP_CUSTOMER_ID,GREG.ERP_SUPPLIER_ID,POL.EFFECTIVE_FROM_DATE,POL.EFFECTIVE_TO_DATE;    

 Get_Crn_Premium_Det_Rec Get_Crn_Premium_Details%ROWTYPE;
 
 CURSOR Get_Endorsement_No IS
 SELECT wm_concat(endorsement_number) AS endorsement_number  FROM (
   SELECT distinct edr.cust_endorsement_number as endorsement_number  
  FROM tpa_enr_endorsements edr
  JOIN tpa_enr_endorse_dtl EDT on (edr.endorsement_seq_id=edt.endorsement_seq_id)
  join tpa_enr_policy_member mem on (edt.member_seq_id=mem.member_seq_id)
  where mem.inv_lnked_seq_ids LIKE '%'||v_invoice_seq_id||'%' ); 
  
 Get_Endorsement_No_Rec            Get_Endorsement_No%ROWTYPE; 
 
BEGIN
  
 IF v_mod_flag='INV' THEN
   
    FOR I IN Get_Inv_Premium_Details LOOP
      
     OPEN Get_Endorsement_No;
       FETCH Get_Endorsement_No INTO Get_Endorsement_No_Rec;
         CLOSE Get_Endorsement_No;
      
      OPEN Get_Inv_payment_cond;
          FETCH Get_Inv_payment_cond INTO Get_Inv_payment_Rec;
                CLOSE Get_Inv_payment_cond;
  
        INSERT INTO APP.ORA_ERP_PREMIUM_DTLS
         (TRANS_REF_NUM,SUPPLIER_NUM,CUSTOMER_NUM,CURRENCY_CODE,GROSS_PREMIUM_AMT,MTI_PREMIUM_AMT,
          NET_PREMIUM_AMT,DOCUMENT_DATE,POLICY_NUMBER,ENDORSMENT_NUM,INCEPTION_DATE,DATE_OF_EXIT,INV_REF_SEQ_ID,ADD_TYPE)
        VALUES
          (Get_Inv_payment_Rec.Trans_Ref_Num,I.ERP_SUPPLIER_ID, I.ERP_CUSTOMER_ID,'QAR',I.TOTAL_PREMIUM,I.MAT_PREMIUM,
           I.TOTAL_PREMIUM,SYSDATE,I.POLICY_NUMBER,TO_CHAR(Get_Endorsement_No_Rec.Endorsement_Number),I.EFFECTIVE_FROM_DATE,I.EFFECTIVE_TO_DATE,v_invoice_seq_id,'INVOICE');
    
     IF Get_Inv_payment_Rec.Inv_Gen_Period IN ('IMD','ANL') THEN
        
        INSERT INTO APP.ORA_ERP_PREMIUM_INSTALLM_DTLS
        (TRANS_REF_NUM,INSTALLMENT_NUM,DUE_DATE,INSTALL_AMT,INSTALL_AMT_PER)
        VALUES
        (Get_Inv_payment_Rec.Trans_Ref_Num,1,Get_Inv_payment_Rec.Due_Date_1,I.TOTAL_PREMIUM,100);
     
     ELSIF Get_Inv_payment_Rec.Inv_Gen_Period='QTR' THEN  
     
        INSERT ALL 
         INTO APP.ORA_ERP_PREMIUM_INSTALLM_DTLS (TRANS_REF_NUM,INSTALLMENT_NUM,DUE_DATE,INSTALL_AMT,INSTALL_AMT_PER)  VALUES(Get_Inv_payment_Rec.Trans_Ref_Num,1,Get_Inv_payment_Rec.Due_Date_1,I.TOTAL_PREMIUM/4,25)
         INTO APP.ORA_ERP_PREMIUM_INSTALLM_DTLS (TRANS_REF_NUM,INSTALLMENT_NUM,DUE_DATE,INSTALL_AMT,INSTALL_AMT_PER) VALUES(Get_Inv_payment_Rec.Trans_Ref_Num,2,Get_Inv_payment_Rec.Due_Date_2,I.TOTAL_PREMIUM/4,25)
         INTO APP.ORA_ERP_PREMIUM_INSTALLM_DTLS (TRANS_REF_NUM,INSTALLMENT_NUM,DUE_DATE,INSTALL_AMT,INSTALL_AMT_PER) VALUES(Get_Inv_payment_Rec.Trans_Ref_Num,3,Get_Inv_payment_Rec.Due_Date_3,I.TOTAL_PREMIUM/4,25)
         INTO APP.ORA_ERP_PREMIUM_INSTALLM_DTLS (TRANS_REF_NUM,INSTALLMENT_NUM,DUE_DATE,INSTALL_AMT,INSTALL_AMT_PER) VALUES(Get_Inv_payment_Rec.Trans_Ref_Num,4,Get_Inv_payment_Rec.Due_Date_4,I.TOTAL_PREMIUM/4,25)
       SELECT * FROM DUAL;
     
     ELSIF Get_Inv_payment_Rec.Inv_Gen_Period='HLF' THEN
      
      INSERT ALL 
         INTO APP.ORA_ERP_PREMIUM_INSTALLM_DTLS (TRANS_REF_NUM,INSTALLMENT_NUM,DUE_DATE,INSTALL_AMT,INSTALL_AMT_PER) VALUES (Get_Inv_payment_Rec.Trans_Ref_Num,1,Get_Inv_payment_Rec.Due_Date_1,I.TOTAL_PREMIUM/2,50)
         INTO APP.ORA_ERP_PREMIUM_INSTALLM_DTLS (TRANS_REF_NUM,INSTALLMENT_NUM,DUE_DATE,INSTALL_AMT,INSTALL_AMT_PER) VALUES (Get_Inv_payment_Rec.Trans_Ref_Num,2,Get_Inv_payment_Rec.Due_Date_2,I.TOTAL_PREMIUM/2,50)
          SELECT * FROM DUAL;
          
     END IF;
   END LOOP;
   
    v_success_YN := 'Y' ;
     
 ELSIF v_mod_flag='CRN' THEN
 
   FOR I IN Get_Crn_Premium_Details LOOP
     
      OPEN Get_Inv_payment_cond;
        FETCH Get_Inv_payment_cond INTO Get_Inv_payment_Rec;
          CLOSE Get_Inv_payment_cond;
        
      INSERT INTO APP.ORA_ERP_PREMIUM_DTLS
         (TRANS_REF_NUM,SUPPLIER_NUM,CUSTOMER_NUM,CURRENCY_CODE,GROSS_PREMIUM_AMT,
          NET_PREMIUM_AMT,DOCUMENT_DATE,POLICY_NUMBER,ENDORSMENT_NUM,INCEPTION_DATE,DATE_OF_EXIT,INV_REF_SEQ_ID,ADD_TYPE)
        VALUES
          (Get_Inv_payment_Rec.Trans_Ref_Num,I.ERP_SUPPLIER_ID, I.ERP_CUSTOMER_ID,'QAR',I.TOTAL_REFUND,
           I.TOTAL_REFUND,SYSDATE,I.POLICY_NUMBER,NULL,I.EFFECTIVE_FROM_DATE,I.EFFECTIVE_TO_DATE,v_invoice_seq_id,'CREDIT');
    
      INSERT INTO APP.ORA_ERP_PREMIUM_INSTALLM_DTLS (TRANS_REF_NUM,INSTALLMENT_NUM,DUE_DATE,INSTALL_AMT,INSTALL_AMT_PER)
       VALUES (Get_Inv_payment_Rec.Trans_Ref_Num,1,NULL,-I.TOTAL_REFUND,100);
   
   END LOOP;
    v_success_YN := 'Y' ;
  END IF;
 EXCEPTION
   WHEN OTHERS THEN
      v_success_YN := 'N' ;    
END Invoice_Dump_Into_ERP;
--====================================================================================================

END FLOAT_ACCOUNTS_PKG;

/

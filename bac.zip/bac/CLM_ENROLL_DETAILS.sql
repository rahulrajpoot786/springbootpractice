--------------------------------------------------------
--  DDL for Synonymn CLM_ENROLL_DETAILS
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."CLM_ENROLL_DETAILS" FOR "APP"."CLM_ENROLL_DETAILS";

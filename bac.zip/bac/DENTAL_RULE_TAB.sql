--------------------------------------------------------
--  DDL for Synonymn DENTAL_RULE_TAB
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."DENTAL_RULE_TAB" FOR "APP"."DENTAL_RULE_TAB";

--------------------------------------------------------
--  DDL for Synonymn IDX_ENRBALANCE_MEMSEQ
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."IDX_ENRBALANCE_MEMSEQ" FOR "APP"."IDX_ENRBALANCE_MEMSEQ";

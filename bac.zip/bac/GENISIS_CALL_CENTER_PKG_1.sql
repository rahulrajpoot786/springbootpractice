--------------------------------------------------------
--  DDL for Package GENISIS_CALL_CENTER_PKG
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "VENUBABU"."GENISIS_CALL_CENTER_PKG" IS

--===============================================================================================================
 --   Name       : CALL CENTER IVR 
 --   Created on : 10-05-2017
 --   Created By :JAMUNA
 --   Comments   : This Package is created for call_center IVR CR and cal_center module CR
--===============================================================================================================

PROCEDURE PAT_CLM_MOB_DTL_SEARCH (
P_MOBILE          IN VARCHAR2 ,
P_IVR_NO          IN VARCHAR2 ,--2 CLAIM 1 PREAUTH
P_PREAUTH_NUMBER  IN VARCHAR2,
P_CLAIM_NUMBER    IN VARCHAR2,
P_OUT_RESULT1     OUT  SYS_REFCURSOR);

--===============================================================================================================
PROCEDURE WEBSERVICE_ENROLLMENT_NO(
P_ENROLLMENT_NO TPA_ENR_POLICY_GROUP.TPA_ENROLLMENT_NUMBER%TYPE,
P_ENROLL_HISTORY  OUT XMLTYPE
);
--===============================================================================================================
PROCEDURE SELECT_ENROLL_SEARCH_PROC(
P_TPA_ENROLLMENT_ID IN TPA_ENR_POLICY_MEMBER.TPA_ENROLLMENT_ID%TYPE,
P_mobile_no         IN  TPA_ENR_MEM_ADDRESS.mobile_no%TYPE,
P_employee_no       IN  TPA_ENR_POLICY_GROUP.employee_no%TYPE,
P_insured_name      IN  TPA_ENR_POLICY_GROUP.insured_name%TYPE,
P_SORT_VAR          IN VARCHAR2,
P_SORT_ORDER        IN VARCHAR2,   --ASC/DESC                                 
P_START_NUM         IN NUMBER,
P_END_NUM           IN NUMBER, 
P_FLAG              IN VARCHAR2,
P_CORPORATE         IN TPA_GROUP_REGISTRATION.GROUP_NAME%TYPE,
P_POLICY_NUMBER     IN TPA_ENR_POLICY.POLICY_NUMBER%TYPE,
P_EMIRATE_ID        IN TPA_ENR_POLICY_MEMBER.EMIRATE_ID%TYPE,
P_EMAIL		  IN VARCHAR2,
P_OUT_RESULT        OUT SYS_REFCURSOR
);
--===============================================================================================================
PROCEDURE SELECT_POLICY_DTL_PROC(
P_MEMBER_SEQ_ID tpa_enr_policy_member.member_seq_id%TYPE,
P_OUT_RESULT        OUT SYS_REFCURSOR
);
--===============================================================================================================
PROCEDURE SEARCH_POLICY_PROC(
P_POLICY_NUMBER    IN TPA_ENR_POLICY.POLICY_NUMBER%TYPE,
P_mobile_no         IN  TPA_ENR_MEM_ADDRESS.mobile_no%TYPE,
P_employee_no       IN  TPA_ENR_POLICY_GROUP.employee_no%TYPE,
P_insured_name      IN  TPA_ENR_POLICY_GROUP.insured_name%TYPE,
P_SORT_VAR          IN VARCHAR2,
P_SORT_ORDER        IN VARCHAR2,   --ASC/DESC                                 
P_START_NUM         IN NUMBER,
P_END_NUM           IN NUMBER, 
P_OUT_RESULT        OUT SYS_REFCURSOR
)  ;
--===============================================================================================================

PROCEDURE SEARCH_PREAUTH_PROC(
P_PRE_AUTH_NUMBER    IN PAT_ENROLL_DETAILS.PRE_AUTH_NUMBER%TYPE,
P_TPA_ENROLLMENT_ID IN TPA_ENR_POLICY_MEMBER.TPA_ENROLLMENT_ID%TYPE,
P_MOBILE_NO         IN  TPA_ENR_MEM_ADDRESS.mobile_no%TYPE,
P_MEM_NAME          IN  TPA_ENR_POLICY_MEMBER.MEM_NAME%TYPE,
P_CORPORATE         IN TPA_GROUP_REGISTRATION.GROUP_NAME%TYPE, 
P_SORT_VAR          IN VARCHAR2,
P_SORT_ORDER        IN VARCHAR2,   --ASC/DESC                                 
P_START_NUM         IN NUMBER,
P_END_NUM           IN NUMBER, 
P_employee_no       IN  TPA_ENR_POLICY_GROUP.employee_no%TYPE,
P_POLICY_NUMBER     IN TPA_ENR_POLICY.POLICY_NUMBER%TYPE,
P_FLAG              IN VARCHAR2,
P_EMIRATE_ID        IN TPA_ENR_POLICY_MEMBER.EMIRATE_ID%TYPE,
P_EMAIL             IN VARCHAR2,
P_OUT_RESULT        OUT SYS_REFCURSOR
)  ;
--===============================================================================================================
PROCEDURE SELECT_PREAUTH_DTL(
P_PAT_GENERAL_SEQ_ID  IN PAT_GENERAL_DETAILS.PAT_GEN_DETAIL_SEQ_ID%TYPE,
P_OUT_RESULT        OUT SYS_REFCURSOR
);

--===============================================================================================================
PROCEDURE SEARCH_CLAIM_PROC(
P_CLAIM_NUMBER      IN CLM_GENERAL_DETAILS.CLAIM_NUMBER%TYPE,
P_TPA_ENROLLMENT_ID IN TPA_ENR_POLICY_MEMBER.TPA_ENROLLMENT_ID%TYPE,
P_MOBILE_NO         IN  TPA_ENR_MEM_ADDRESS.mobile_no%TYPE,
P_MEM_NAME          IN  TPA_ENR_POLICY_MEMBER.MEM_NAME%TYPE,
P_CORPORATE         IN TPA_GROUP_REGISTRATION.GROUP_NAME%TYPE, 
P_SORT_VAR          IN VARCHAR2,
P_SORT_ORDER        IN VARCHAR2,   --ASC/DESC                                 
P_START_NUM         IN NUMBER,
P_END_NUM           IN NUMBER, 
P_employee_no       IN  TPA_ENR_POLICY_GROUP.employee_no%TYPE,
P_POLICY_NUMBER     IN TPA_ENR_POLICY.POLICY_NUMBER%TYPE,
P_FLAG              IN VARCHAR2,
P_EMIRATE_ID        IN TPA_ENR_POLICY_MEMBER.EMIRATE_ID%TYPE,
P_EMAIL             IN VARCHAR2,
P_OUT_RESULT        OUT SYS_REFCURSOR
);

--===============================================================================================================
PROCEDURE SELECT_CLAIM_DTL(
P_CLAIM_SEQ_ID IN CLM_GENERAL_DETAILS.CLAIM_SEQ_ID%TYPE,
P_OUT_RESULT        OUT SYS_REFCURSOR
);

--===============================================================================================================
PROCEDURE CLM_DISALLOWED_AMT_PROC (
P_CLAIM_SEQ_ID IN CLM_GENERAL_DETAILS.CLAIM_SEQ_ID%TYPE,
P_OUT_RESULT        OUT SYS_REFCURSOR
);
--===============================================================================================================
PROCEDURE SELECT_PREAUTHS_DTLS(
P_MEMBER_SEQ_ID  IN tpa_enr_policy_member.MEMBER_SEQ_ID%TYPE,
P_OUT_RESULT        OUT SYS_REFCURSOR
);
--===============================================================================================================
PROCEDURE SELECT_CLAIMS_DTLS(
P_MEMBER_SEQ_ID  IN tpa_enr_policy_member.MEMBER_SEQ_ID%TYPE,
P_OUT_RESULT        OUT SYS_REFCURSOR
);
--===============================================================================================================
PROCEDURE CLM_CHECK_DETAILS_PROC (
P_CLAIM_SEQ_ID IN CLM_GENERAL_DETAILS.CLAIM_SEQ_ID%TYPE,
P_OUT_RESULT        OUT SYS_REFCURSOR
);
--===============================================================================================================

PROCEDURE CLAIM_SHORTFALL_LIST(
P_CLAIM_SEQ_ID IN CLM_GENERAL_DETAILS.CLAIM_SEQ_ID%TYPE,
P_OUT_RESULT        OUT SYS_REFCURSOR
);
--===============================================================================================================
 PROCEDURE CLAIM_SHORTFALL_QUESTIONS(
P_SHORT_FALL_SEQ_ID       IN  shortfall_details.shortfall_seq_id%TYPE,
P_OUT_RESULT        OUT SYS_REFCURSOR
  );
--===============================================================================================================

PROCEDURE INITIAL_PERIOD_EXCL_DTL_PROC(
P_MEMBER_SEQ_ID  IN tpa_enr_policy_member.MEMBER_SEQ_ID%TYPE,
P_ENROL_TYPE_ID  IN TPA_ENR_POLICY.ENROL_TYPE_ID%TYPE,
P_OUT_RESULT        OUT SYS_REFCURSOR
);

--===============================================================================================================
PROCEDURE IMPORTANE_NOTES_PROC(
P_MEMBER_SEQ_ID  IN tpa_enr_policy_member.MEMBER_SEQ_ID%TYPE,
P_ENROL_TYPE_ID  IN TPA_ENR_POLICY.ENROL_TYPE_ID%TYPE,
P_OUT_RESULT     OUT SYS_REFCURSOR
);
--===============================================================================================================
PROCEDURE SEARCH_FINANCE_DTL_PROC(
P_CLAIM_PAT_NUMBER  IN CLM_GENERAL_DETAILS.CLAIM_NUMBER%TYPE,
P_TPA_ENROLLMENT_ID IN TPA_ENR_POLICY_MEMBER.TPA_ENROLLMENT_ID%TYPE,
P_MOBILE_NO         IN  TPA_ENR_MEM_ADDRESS.mobile_no%TYPE,
P_MEM_NAME          IN  TPA_ENR_POLICY_MEMBER.MEM_NAME%TYPE,
P_CORPORATE         IN TPA_GROUP_REGISTRATION.GROUP_NAME%TYPE,
P_employee_no       IN  TPA_ENR_POLICY_GROUP.employee_no%TYPE,
P_POLICY_NUMBER     IN TPA_ENR_POLICY.POLICY_NUMBER%TYPE,
P_FLAG              IN VARCHAR2,
P_SORT_VAR          IN VARCHAR2,
P_SORT_ORDER        IN VARCHAR2,   --ASC/DESC                                 
P_START_NUM         IN NUMBER,
P_END_NUM           IN NUMBER,
P_EMIRATE_ID        IN TPA_ENR_POLICY_MEMBER.EMIRATE_ID%TYPE,
P_EMAIL             IN VARCHAR2, 
P_OUT_RESULT        OUT SYS_REFCURSOR
);

--===============================================================================================================
PROCEDURE SELECT_DATA_FOR_CARD_PRINT (
P_POLICY_GROUP_SEQ_ID  IN  TPA_ENR_POLICY_GROUP.POLICY_GROUP_SEQ_ID%type,
P_OUT_RESULT        OUT SYS_REFCURSOR);
--===============================================================================================================
PROCEDURE PREAUTH_SHORTFALL_LIST(
P_PAT_GEN_DETAIL_SEQ_ID IN SHORTFALL_DETAILS.PAT_GEN_DETAIL_SEQ_ID%TYPE,
P_OUT_RESULT           OUT SYS_REFCURSOR
);
--===============================================================================================================
PROCEDURE COURIER_DETAILS_LIST_PROC(
  P_COURIER_ID        IN COURIER_DETAILS.COURIER_ID%TYPE,
  P_CONSIGNMENT_NO    IN COURIER_DETAILS.DOCKET_NUMBER%TYPE,
  P_TPA_OFFICE_SEQ_ID  IN TPA_OFFICE_INFO.TPA_OFFICE_SEQ_ID%TYPE,
  P_SORT_VAR          IN VARCHAR2,
  P_SORT_ORDER        IN VARCHAR2,   --ASC/DESC                                 
  P_START_NUM         IN NUMBER,
  P_END_NUM           IN NUMBER, 
  P_OUT_RESULT        OUT SYS_REFCURSOR);
--===============================================================================================================
PROCEDURE EMPANLED_HOSPITAL_LIST_PROC(
P_TYPE  IN VARCHAR2,
P_HOSPITAL_NAME  IN TPA_HOSP_INFO.HOSP_NAME%TYPE,
P_STATE_ID       IN  TPA_HOSP_ADDRESS.STATE_TYPE_ID%TYPE,
P_CITY_TYPE_ID   IN  TPA_HOSP_ADDRESS.CITY_TYPE_ID%TYPE,
P_LOCATION       IN VARCHAR2,
P_SORT_VAR        IN VARCHAR2,
P_SORT_ORDER      IN VARCHAR2,   --ASC/DESC                                 
P_START_NUM       IN NUMBER,
P_END_NUM        IN NUMBER,
P_OUT_RESULT        OUT SYS_REFCURSOR);
--===============================================================================================================
PROCEDURE PASSWORD_VALIDATION_PROC(
P_USER_ID IN  TPA_LOGIN_INFO.USER_ID%TYPE,
P_PASSWORD IN TPA_LOGIN_INFO.PASSWORD%TYPE,
P_OUT_RESULT OUT VARCHAR2);


--===============================================================================================================
 PROCEDURE current_status( v_seq_id  IN NUMBER,
                           v_mode    IN NUMBER,
                           v_status OUT NUMBER);
--============================================================================================================
PROCEDURE ICD_ACTIVITY_DETAILS (V_PRE_CLAIM_NUMBER   IN  VARCHAR2,
                                V_MODE               IN  VARCHAR2,
                                V_DIAG_CURSOR        OUT SYS_REFCURSOR,
                                V_ACTIVITY_CUR       OUT SYS_REFCURSOR);

--====================================================================================================
PROCEDURE VIEW_PRE_AUTH_CLM_DOCS (V_MODE      in VARCHAR2,
                                  V_SEQ_ID    IN NUMBER,
                                  V_RESULTSET OUT SYS_REFCURSOR);
--===================================================================================================
PROCEDURE SELECT_PRE_CLM_DOC (V_SEQ_ID IN NUMBER,
                             	V_MOB_YN     IN VARCHAR2,
                              V_FILE   OUT PAT_CLM_DOCS_TAB.IMAGE_FILE%TYPE,
                              V_FILE_NAME OUT PAT_CLM_DOCS_TAB.FILE_NAME%TYPE);
 --==========================
PROCEDURE Update_member_Contact_det (v_member_seq_id    IN   NUMBER,
                                     v_mobile_no        IN   app.tpa_enr_mem_address.mobile_no%type,
                                     v_email            IN   app.tpa_enr_mem_address.email_id%type,
                                     v_passport_no      IN   app.tpa_enr_policy_member.passport_number%type,
                                     v_qatar_id         IN   app.tpa_enr_policy_member.emirate_id%type,
                                     v_ref_cur          OUT  SYS_REFCURSOR);
--=========================
END GENISIS_CALL_CENTER_PKG;

/

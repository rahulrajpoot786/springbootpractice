--------------------------------------------------------
--  DDL for Procedure ELIGIBILITY_LOG_PROC
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "VENUBABU"."ELIGIBILITY_LOG_PROC" 
( 
  v_login_from      VARCHAR2,---'PARTNER','PROVIDER','PBM'
  v_enrollment_id   VARCHAR2,
  v_benefit_type    VARCHAR2,
  v_treatment_date  VARCHAR2,
  v_eligible_yn     VARCHAR2,
  v_hosp_seq_id     NUMBER,   --- for PBM,Provider, Alhali WS-- HOSP_SEQ_ID FOR PARTNER -- user seq id
  v_encounter_type  IN  NUMBER,
  v_ptr_provider_name   IN  VARCHAR2,
  v_estimated_cost  NUMBER,
  v_country_id      TPA_COUNTRY_CODE.COUNTRY_ID%TYPE,
  v_currency_id     TPA_CURRENCY_CODE.CURRENCY_ID%TYPE,
  v_added_by        NUMBER,
  v_log_seq_id   OUT   NUMBER,
  v_loger_name      VARCHAR2,
  v_empanel_no      VARCHAR2,
  v_event_no        VARCHAR2,
  v_reason_for_rejection VARCHAR2 DEFAULT NULL 
  ) IS
PRAGMA AUTONOMOUS_TRANSACTION;
V_ERRM VARCHAR2(100);
BEGIN
  INSERT INTO EXTERNAL_LOGIN_LOGS
  (log_seq_id,
  login_from,
  login_date,
  enrollment_id,
  benefit_type,
  treatment_date,
  eligible_yn,
  REASON_FOR_REJECTION,
  hosp_seq_id,
  encounter_type,
  ptr_provider_name,
  estimated_cost,
  country_id,
  currency_id,
  added_by,
  added_date,
  event_no,
  EMPANEL_NO,
  loger_name)
  VALUES
  (EXTERNAL_LOGIN_LOGS_SEQ.NEXTVAL,
  v_login_from,
  sysdate,
  v_enrollment_id,
  v_benefit_type,
  v_treatment_date,
  v_eligible_yn,
  v_reason_for_rejection,
  v_hosp_seq_id,
  v_encounter_type,
  v_ptr_provider_name,
  v_estimated_cost,
  v_country_id,
  v_currency_id,
  v_added_by,
  SYSDATE,
  v_event_no,
  v_empanel_no,
  v_loger_name) RETURNING log_seq_id INTO v_log_seq_id;
  
  IF v_login_from ='PARTNER' THEN
    UPDATE EXTERNAL_LOGIN_LOGS SET hosp_seq_id=NULL 
    WHERE log_seq_id=v_log_seq_id;
  END IF;
  
  COMMIT;
/*  EXCEPTION
    WHEN OTHERS THEN
      V_ERRM :=SQLERRM;
      INSERT INTO EXTERNAL_LOGIN_LOGS(REASON_FOR_REJECTION ) VALUES (V_ERRM);
      COMMIT;*/
  END;

/

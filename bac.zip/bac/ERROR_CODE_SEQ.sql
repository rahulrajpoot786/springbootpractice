--------------------------------------------------------
--  DDL for Synonymn ERROR_CODE_SEQ
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."ERROR_CODE_SEQ" FOR "APP"."ERROR_CODE_SEQ";

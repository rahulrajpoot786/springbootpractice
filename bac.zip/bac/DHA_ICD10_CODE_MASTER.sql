--------------------------------------------------------
--  DDL for Synonymn DHA_ICD10_CODE_MASTER
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."DHA_ICD10_CODE_MASTER" FOR "APP"."DHA_ICD10_CODE_MASTER";

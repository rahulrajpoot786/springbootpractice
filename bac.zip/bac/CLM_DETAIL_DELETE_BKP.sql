--------------------------------------------------------
--  DDL for Synonymn CLM_DETAIL_DELETE_BKP
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."CLM_DETAIL_DELETE_BKP" FOR "APP"."CLM_DETAIL_DELETE_BKP";

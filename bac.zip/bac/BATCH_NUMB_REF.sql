--------------------------------------------------------
--  DDL for Sequence BATCH_NUMB_REF
--------------------------------------------------------

   CREATE SEQUENCE  "VENUBABU"."BATCH_NUMB_REF"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 121 CACHE 20 NOORDER  NOCYCLE ;

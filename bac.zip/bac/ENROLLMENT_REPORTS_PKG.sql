--------------------------------------------------------
--  DDL for Synonymn ENROLLMENT_REPORTS_PKG
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."ENROLLMENT_REPORTS_PKG" FOR "APP"."ENROLLMENT_REPORTS_PKG";

--------------------------------------------------------
--  DDL for Synonymn FIN_UPLOAD_EFT
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."FIN_UPLOAD_EFT" FOR "INTX"."FIN_UPLOAD_EFT";

--------------------------------------------------------
--  DDL for Synonymn IDX_NCCI_HOSP_SECOND_COL
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."IDX_NCCI_HOSP_SECOND_COL" FOR "APP"."IDX_NCCI_HOSP_SECOND_COL";

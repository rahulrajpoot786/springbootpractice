--------------------------------------------------------
--  DDL for Synonymn GET_ASSOCIATED_ID
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."GET_ASSOCIATED_ID" FOR "INTX"."GET_ASSOCIATED_ID";

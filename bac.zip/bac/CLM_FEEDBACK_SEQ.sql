--------------------------------------------------------
--  DDL for Synonymn CLM_FEEDBACK_SEQ
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."CLM_FEEDBACK_SEQ" FOR "APP"."CLM_FEEDBACK_SEQ";

--------------------------------------------------------
--  DDL for Package ACCOUNT_INFO_PKG
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "VENUBABU"."ACCOUNT_INFO_PKG" IS

  -- Author  : kSREERAJ_SV
  -- Created : 7/26/2007 4:35:37 PM
  -- Purpose : Account info module
  TYPE filter_tab_type IS TABLE OF VARCHAR2(100) INDEX BY BINARY_INTEGER;

--======================================================================================================
  PROCEDURE select_member_list(
    search_tab      IN account_info_pkg.filter_tab_type,
    v_sort_var      IN VARCHAR2 ,
    v_sort_order    IN VARCHAR2,
    v_start_num     IN NUMBER ,
    v_end_num       IN NUMBER , 
    v_added_by      IN  NUMBER,         
    result_set      OUT SYS_REFCURSOR
  );
--======================================================================================================
  PROCEDURE select_enrollment_list (
    v_policy_group_seq_id      IN tpa_enr_policy_group.policy_group_seq_id%TYPE,
    result_set                 OUT SYS_REFCURSOR
  );
--======================================================================================================
  PROCEDURE select_endorsement_list (
    v_policy_seq_id                      IN  tpa_enr_endorsements.policy_seq_id%TYPE,
    v_result_set                         OUT SYS_REFCURSOR
  );
--======================================================================================================
PROCEDURE select_member_list(
    v_policy_group_seq_id   IN tpa_enr_policy_group.policy_group_seq_id%TYPE,
    result_set              OUT SYS_REFCURSOR
  );
--======================================================================================================
   PROCEDURE select_history_list (
    v_history_type                        IN VARCHAR2, --  HPR-> Pre-Authorization , POL->Policy , HCL-> Claims
    v_tpa_enrollment_id                   IN PAT_ENROLL_DETAILS.tpa_enrollment_id%TYPE,
    v_start_date                          IN VARCHAR2,
    v_end_date                            IN VARCHAR2,
    v_sort_var                            IN VARCHAR2,
    v_sort_order                          IN VARCHAR2 ,
    v_start_num                           IN NUMBER ,
    v_end_num                             IN NUMBER ,
    result_set                            OUT SYS_REFCURSOR
  );
--======================================================================================================
  PROCEDURE select_policy (
    v_policy_seq_id                IN  tpa_enr_policy_member.member_seq_id%TYPE,
    v_policy_group_seq_id          IN tpa_enr_policy_group.policy_group_seq_id%TYPE,
    v_enrol_type_id                IN  tpa_enr_policy.enrol_type_id%TYPE,
    v_result_set                   OUT SYS_REFCURSOR
  );
--======================================================================================================
  PROCEDURE create_policy_xml (
    v_member_seq_id                IN  tpa_enr_policy_member.member_seq_id%TYPE,
    v_policy_history_doc           OUT XMLTYPE
  );
--======================================================================================================
  PROCEDURE create_preauth_xml (
    v_pat_gen_detail_seq_id                 IN  pat_general_details.pat_gen_detail_seq_id%TYPE,
    v_pat_enroll_detail_seq_id              IN pat_enroll_details.pat_enroll_detail_seq_id%TYPE,
    v_preauth_history_doc                   OUT XMLTYPE
   );
--======================================================================================================
  PROCEDURE create_claim_xml (
    v_claim_seq_id                          IN clm_general_details.claim_seq_id%TYPE,
    v_clm_enroll_detail_seq_id              IN clm_enroll_details.clm_enroll_detail_seq_id%TYPE,
    v_claim_history_doc                     OUT XMLTYPE
   );
--======================================================================================================
  PROCEDURE select_enrollment(
    v_policy_group_seq_id      IN tpa_enr_policy_group.policy_group_seq_id%TYPE,
    result_set                 OUT SYS_REFCURSOR
  );
--==============================================================================================
  PROCEDURE create_citi_enrol_hist_xml (
    v_citibank_enr_seq_id             IN  citibank_enr_history.citibank_enr_seq_id %TYPE,
    v_citienrol_history_doc           OUT XMLTYPE
  );
--==============================================================================================
PROCEDURE create_citi_clm_hist_xml (
    v_citibank_clm_seq_id           IN  citibank_clm_history.citibank_clm_seq_id %TYPE,
    v_citiclm_history_doc           OUT XMLTYPE
  );
--==============================================================================================
 function get_gen_desc(v_type_id in varchar2, v_code in varchar2)
    return varchar2 ;
 --========================================================================================
 Procedure select_member_buffer_list(v_policy_number   IN Tpa_enr_policy.Policy_Number%TYPE,
                                    v_enrollment_no    IN Tpa_enr_policy_group.Tpa_Enrollment_Number%TYPE,
                                    v_emp_name         IN Tpa_enr_policy_member.Mem_Name%TYPE,
                                    v_enrollment_id    IN Tpa_enr_policy_member.Tpa_Enrollment_Id%TYPE,
                                    v_mem_name         IN Tpa_enr_policy_member.Mem_Name%TYPE,
                                    v_group_id         IN Tpa_enr_policy.Groupid%TYPE,
                                    v_sort_var         IN VARCHAR2,
                                    v_sort_order       IN VARCHAR2,
                                    v_start_num        IN NUMBER ,
                                    v_end_num          IN NUMBER ,
                                    v_result_set       OUT SYS_REFCURSOR);
 --======================================================================================
 PROCEDURE save_mem_buffer_details(v_mem_buff_seqid           IN OUT Tpa_enr_mem_buff_dtls.MEM_BUFF_SEQID%TYPE ,
                                  v_policy_seq_id            IN  Tpa_enr_mem_buff_dtls.POLICY_SEQ_ID%TYPE ,
                                  v_policy_group_seq_id       IN  Tpa_enr_mem_buff_dtls.POLICY_GROUP_SEQ_ID%TYPE ,
                                  v_member_seq_id             IN  Tpa_enr_mem_buff_dtls.MEMBER_SEQ_ID%TYPE ,
                                  v_reference_no             IN  Tpa_enr_mem_buff_dtls.REFERENCE_NO%TYPE ,
                                  v_buffer_added_date         IN  Tpa_enr_mem_buff_dtls.BUFFER_ADDED_DATE%TYPE ,
                                  v_buffer_mode               IN  Tpa_enr_mem_buff_dtls.BUFFER_MODE%TYPE ,
                                  v_hr_appr_buffer           IN  Tpa_enr_mem_buff_dtls.Hr_Appr_Buffer%TYPE,
                                  v_buffer_amt               IN  Tpa_enr_mem_buff_dtls.BUFFER_AMT%TYPE ,
                                  v_approved_by               IN  Tpa_enr_mem_buff_dtls.APPROVED_BY%TYPE ,
                                  v_remarks                   IN  Tpa_enr_mem_buff_dtls.REMARKS%TYPE ,
                                  v_added_by                 IN  Tpa_enr_mem_buff_dtls.ADDED_BY%TYPE ,
                                  v_ava_cor_buffer           IN  Tpa_enr_mem_buff_dtls.Ava_Cor_Buffer%TYPE,
                                  v_ava_fam_buffer           IN  tpa_enr_mem_buff_dtls.ava_fam_buffer%TYPE,
                                  v_ava_mem_buffer           IN  tpa_enr_mem_buff_dtls.ava_mem_buffer%TYPE,
                                  v_claim_type               IN  tpa_enr_mem_buff_dtls.claim_type%TYPE,
                                  v_buffer_type              IN  tpa_enr_mem_buff_dtls.Buffer_Type%TYPE,
                                  v_alert                    OUT VARCHAR2,
                                  v_rows_processed           OUT Number);
--===========================================================================================================
  FUNCTION buffer_pa_clm_yn(v_member_seq_id           IN tpa_enr_mem_buff_dtls.member_seq_id%TYPE,
                            v_policy_grp_seq_id       IN tpa_enr_mem_buff_dtls.policy_group_seq_id%TYPE,
                            v_policy_seq_id           IN tpa_enr_mem_buff_dtls.policy_seq_id%TYPE)
  RETURN NUMBER;
--===========================================================================================================
/* PROCEDURE select_buff_mem_list (v_policy_seq_id          IN tpa_enr_mem_buff_dtls.policy_seq_id%TYPE,
                                 v_policy_group_seq_id    IN tpa_enr_mem_buff_dtls.policy_group_seq_id%TYPE,
                                 v_member_seq_id          IN tpa_enr_mem_buff_dtls.member_seq_id%TYPE,
                                 v_mem_buff_seq_id        IN tpa_enr_mem_buff_dtls.mem_buff_seqid%TYPE,
                                 v_sort_var               IN VARCHAR2,
                                 v_sort_order             IN VARCHAR2,
                                 v_start_num              IN NUMBER ,
                                 v_end_num                IN NUMBER ,
                                 v_result_set             OUT SYS_REFCURSOR);*/
--===========================================================================================================
 PROCEDURE select_buff_mem_list (v_policy_seq_id           IN tpa_enr_mem_buff_dtls.policy_seq_id%TYPE:=NULL,
                                 v_policy_group_seq_id    IN tpa_enr_mem_buff_dtls.policy_group_seq_id%TYPE:=NULL,
                                 v_member_seq_id          IN tpa_enr_mem_buff_dtls.member_seq_id%TYPE:= NULL,
                                 v_mem_buff_seq_id        IN tpa_enr_mem_buff_dtls.mem_buff_seqid%TYPE,
                                 v_sort_var               IN VARCHAR2,
                                 v_sort_order             IN VARCHAR2,
                                 v_start_num              IN NUMBER,
                                 v_end_num                IN NUMBER,
                                 v_result_set             OUT SYS_REFCURSOR);
--=============================================================================================================
 PROCEDURE select_add_buffer    (v_policy_seq_id          IN Tpa_enr_mem_buff_dtls.policy_seq_id%TYPE,
                                v_policy_group_seq_id    IN Tpa_enr_mem_buff_dtls.policy_group_seq_id%TYPE,
                                v_member_seq_id          IN Tpa_enr_mem_buff_dtls.member_seq_id%TYPE,
                                v_claim_type             IN  OUT tpa_enr_mem_buff_dtls.claim_type%TYPE,
                                v_buffer_type            IN  OUT tpa_enr_mem_buff_dtls.Buffer_Type%TYPE,
                                v_enrollment_id          OUT VARCHAR2,
                                v_ava_cor_buffer         OUT NUMBER,
                                v_ava_fam_buffer         OUT NUMBER,
                                v_mem_buffer             OUT NUMBER);
--=============================================================================================================
 PROCEDURE get_buffer_utilised_rpt( v_policy_seq_id          IN Tpa_enr_mem_buff_dtls.policy_seq_id%TYPE,
                                   v_policy_group_seq_id    IN Tpa_enr_mem_buff_dtls.policy_group_seq_id%TYPE,
                                   v_member_seq_id          IN Tpa_enr_mem_buff_dtls.member_seq_id%TYPE,
                                   v_sort_var               IN VARCHAR2,
                                   v_sort_order             IN VARCHAR2,
                                   v_start_num              IN NUMBER,
                                   v_end_num                IN NUMBER,
                                   v_result_set             OUT SYS_REFCURSOR );
--==============================================================================================================
PROCEDURE select_medical_add_buffer    (v_policy_seq_id          IN Tpa_enr_mem_buff_dtls.policy_seq_id%TYPE,
                                v_policy_group_seq_id    IN Tpa_enr_mem_buff_dtls.policy_group_seq_id%TYPE,
                                v_member_seq_id          IN Tpa_enr_mem_buff_dtls.member_seq_id%TYPE,
                                v_claim_type             IN  tpa_enr_mem_buff_dtls.claim_type%TYPE,
                                v_buffer_type            IN  tpa_enr_mem_buff_dtls.Buffer_Type%TYPE,
                                v_enrollment_id          OUT VARCHAR2,
                                v_ava_cor_buffer         OUT NUMBER,
                                v_ava_fam_buffer         OUT NUMBER,
                                v_mem_buffer             OUT NUMBER) ;
--==============================================================================================================
PROCEDURE select_critical_add_buffer(v_policy_seq_id          IN Tpa_enr_mem_buff_dtls.policy_seq_id%TYPE,
                                v_policy_group_seq_id    IN Tpa_enr_mem_buff_dtls.policy_group_seq_id%TYPE,
                                v_member_seq_id          IN Tpa_enr_mem_buff_dtls.member_seq_id%TYPE,
                                v_claim_type             IN  tpa_enr_mem_buff_dtls.claim_type%TYPE,
                                v_buffer_type            IN  tpa_enr_mem_buff_dtls.Buffer_Type%TYPE,
                                v_enrollment_id          OUT VARCHAR2,
                                v_ava_cor_buffer         OUT NUMBER,
                                v_ava_fam_buffer         OUT NUMBER,
                                v_mem_buffer             OUT NUMBER) ;
--==============================================================================================================
                                
PROCEDURE select_crit_corp_add_buffer    (v_policy_seq_id          IN Tpa_enr_mem_buff_dtls.policy_seq_id%TYPE,
                                v_policy_group_seq_id    IN Tpa_enr_mem_buff_dtls.policy_group_seq_id%TYPE,
                                v_member_seq_id          IN Tpa_enr_mem_buff_dtls.member_seq_id%TYPE,
                                v_claim_type             IN  tpa_enr_mem_buff_dtls.claim_type%TYPE,
                                v_buffer_type            IN  tpa_enr_mem_buff_dtls.Buffer_Type%TYPE,
                                v_enrollment_id          OUT VARCHAR2,
                                v_ava_cor_buffer         OUT NUMBER,
                                v_ava_fam_buffer         OUT NUMBER,
                                v_mem_buffer             OUT NUMBER) ;
--==============================================================================================================
PROCEDURE select_crit_med_add_buffer    (v_policy_seq_id          IN Tpa_enr_mem_buff_dtls.policy_seq_id%TYPE,
                                v_policy_group_seq_id    IN Tpa_enr_mem_buff_dtls.policy_group_seq_id%TYPE,
                                v_member_seq_id          IN Tpa_enr_mem_buff_dtls.member_seq_id%TYPE,
                                v_claim_type             IN  tpa_enr_mem_buff_dtls.claim_type%TYPE,
                                v_buffer_type            IN  tpa_enr_mem_buff_dtls.Buffer_Type%TYPE,
                                v_enrollment_id          OUT VARCHAR2,
                                v_ava_cor_buffer         OUT NUMBER,
                                v_ava_fam_buffer         OUT NUMBER,
                                v_mem_buffer             OUT NUMBER);
--==============================================================================================================
                                
                                
PROCEDURE save_medical_mem_buff_dtls(v_mem_buff_seqid        IN OUT Tpa_enr_mem_buff_dtls.MEM_BUFF_SEQID%TYPE ,
                                  v_policy_seq_id            IN  Tpa_enr_mem_buff_dtls.POLICY_SEQ_ID%TYPE ,
                                  v_policy_group_seq_id      IN  Tpa_enr_mem_buff_dtls.POLICY_GROUP_SEQ_ID%TYPE ,
                                  v_member_seq_id            IN  Tpa_enr_mem_buff_dtls.MEMBER_SEQ_ID%TYPE ,
                                  v_reference_no             IN  Tpa_enr_mem_buff_dtls.REFERENCE_NO%TYPE ,
                                  v_buffer_added_date        IN  Tpa_enr_mem_buff_dtls.BUFFER_ADDED_DATE%TYPE ,
                                  v_buffer_mode              IN  Tpa_enr_mem_buff_dtls.BUFFER_MODE%TYPE ,
                                  v_hr_appr_buffer           IN  Tpa_enr_mem_buff_dtls.Hr_Appr_Buffer%TYPE,
                                  v_buffer_amt               IN  Tpa_enr_mem_buff_dtls.BUFFER_AMT%TYPE ,
                                  v_approved_by              IN  Tpa_enr_mem_buff_dtls.APPROVED_BY%TYPE ,
                                  v_remarks                  IN  Tpa_enr_mem_buff_dtls.REMARKS%TYPE ,
                                  v_added_by                 IN  Tpa_enr_mem_buff_dtls.ADDED_BY%TYPE ,
                                  v_ava_cor_buffer           IN  Tpa_enr_mem_buff_dtls.Ava_Cor_Buffer%TYPE,
                                  v_ava_fam_buffer           IN  tpa_enr_mem_buff_dtls.ava_fam_buffer%TYPE,
                                  v_ava_mem_buffer           IN  tpa_enr_mem_buff_dtls.ava_mem_buffer%TYPE,
                                  v_claim_type               IN  tpa_enr_mem_buff_dtls.claim_type%TYPE,
                                  v_buffer_type              IN  tpa_enr_mem_buff_dtls.Buffer_Type%TYPE,
                                  v_alert                    OUT VARCHAR2,
                                  v_rows_processed           OUT Number);
--==============================================================================================================
PROCEDURE save_crit_mem_buff_dtls(v_mem_buff_seqid        IN OUT Tpa_enr_mem_buff_dtls.MEM_BUFF_SEQID%TYPE ,
                                  v_policy_seq_id            IN  Tpa_enr_mem_buff_dtls.POLICY_SEQ_ID%TYPE ,
                                  v_policy_group_seq_id      IN  Tpa_enr_mem_buff_dtls.POLICY_GROUP_SEQ_ID%TYPE ,
                                  v_member_seq_id            IN  Tpa_enr_mem_buff_dtls.MEMBER_SEQ_ID%TYPE ,
                                  v_reference_no             IN  Tpa_enr_mem_buff_dtls.REFERENCE_NO%TYPE ,
                                  v_buffer_added_date        IN  Tpa_enr_mem_buff_dtls.BUFFER_ADDED_DATE%TYPE ,
                                  v_buffer_mode              IN  Tpa_enr_mem_buff_dtls.BUFFER_MODE%TYPE ,
                                  v_hr_appr_buffer           IN  Tpa_enr_mem_buff_dtls.Hr_Appr_Buffer%TYPE,
                                  v_buffer_amt               IN  Tpa_enr_mem_buff_dtls.BUFFER_AMT%TYPE ,
                                  v_approved_by              IN  Tpa_enr_mem_buff_dtls.APPROVED_BY%TYPE ,
                                  v_remarks                  IN  Tpa_enr_mem_buff_dtls.REMARKS%TYPE ,
                                  v_added_by                 IN  Tpa_enr_mem_buff_dtls.ADDED_BY%TYPE ,
                                  v_ava_cor_buffer           IN  Tpa_enr_mem_buff_dtls.Ava_Cor_Buffer%TYPE,
                                  v_ava_fam_buffer           IN  tpa_enr_mem_buff_dtls.ava_fam_buffer%TYPE,
                                  v_ava_mem_buffer           IN  tpa_enr_mem_buff_dtls.ava_mem_buffer%TYPE,
                                  v_claim_type               IN  tpa_enr_mem_buff_dtls.claim_type%TYPE,
                                  v_buffer_type              IN  tpa_enr_mem_buff_dtls.Buffer_Type%TYPE,
                                  v_alert                    OUT VARCHAR2,
                                  v_rows_processed           OUT Number);
--==============================================================================================================
                                  
PROCEDURE save_crit_med_mem_buff_dtls(v_mem_buff_seqid        IN OUT Tpa_enr_mem_buff_dtls.MEM_BUFF_SEQID%TYPE ,
                                  v_policy_seq_id            IN  Tpa_enr_mem_buff_dtls.POLICY_SEQ_ID%TYPE ,
                                  v_policy_group_seq_id      IN  Tpa_enr_mem_buff_dtls.POLICY_GROUP_SEQ_ID%TYPE ,
                                  v_member_seq_id            IN  Tpa_enr_mem_buff_dtls.MEMBER_SEQ_ID%TYPE ,
                                  v_reference_no             IN  Tpa_enr_mem_buff_dtls.REFERENCE_NO%TYPE ,
                                  v_buffer_added_date        IN  Tpa_enr_mem_buff_dtls.BUFFER_ADDED_DATE%TYPE ,
                                  v_buffer_mode              IN  Tpa_enr_mem_buff_dtls.BUFFER_MODE%TYPE ,
                                  v_hr_appr_buffer           IN  Tpa_enr_mem_buff_dtls.Hr_Appr_Buffer%TYPE,
                                  v_buffer_amt               IN  Tpa_enr_mem_buff_dtls.BUFFER_AMT%TYPE ,
                                  v_approved_by              IN  Tpa_enr_mem_buff_dtls.APPROVED_BY%TYPE ,
                                  v_remarks                  IN  Tpa_enr_mem_buff_dtls.REMARKS%TYPE ,
                                  v_added_by                 IN  Tpa_enr_mem_buff_dtls.ADDED_BY%TYPE ,
                                  v_ava_cor_buffer           IN  Tpa_enr_mem_buff_dtls.Ava_Cor_Buffer%TYPE,
                                  v_ava_fam_buffer           IN  tpa_enr_mem_buff_dtls.ava_fam_buffer%TYPE,
                                  v_ava_mem_buffer           IN  tpa_enr_mem_buff_dtls.ava_mem_buffer%TYPE,
                                  v_claim_type               IN  tpa_enr_mem_buff_dtls.claim_type%TYPE,
                                  v_buffer_type              IN  tpa_enr_mem_buff_dtls.Buffer_Type%TYPE,
                                  v_alert                    OUT VARCHAR2,
                                  v_rows_processed           OUT Number);
--==============================================================================================================
PROCEDURE save_crit_corp_mem_buff_dtls(v_mem_buff_seqid        IN OUT Tpa_enr_mem_buff_dtls.MEM_BUFF_SEQID%TYPE ,
                                  v_policy_seq_id            IN  Tpa_enr_mem_buff_dtls.POLICY_SEQ_ID%TYPE ,
                                  v_policy_group_seq_id      IN  Tpa_enr_mem_buff_dtls.POLICY_GROUP_SEQ_ID%TYPE ,
                                  v_member_seq_id            IN  Tpa_enr_mem_buff_dtls.MEMBER_SEQ_ID%TYPE ,
                                  v_reference_no             IN  Tpa_enr_mem_buff_dtls.REFERENCE_NO%TYPE ,
                                  v_buffer_added_date        IN  Tpa_enr_mem_buff_dtls.BUFFER_ADDED_DATE%TYPE ,
                                  v_buffer_mode              IN  Tpa_enr_mem_buff_dtls.BUFFER_MODE%TYPE ,
                                  v_hr_appr_buffer           IN  Tpa_enr_mem_buff_dtls.Hr_Appr_Buffer%TYPE,
                                  v_buffer_amt               IN  Tpa_enr_mem_buff_dtls.BUFFER_AMT%TYPE ,
                                  v_approved_by              IN  Tpa_enr_mem_buff_dtls.APPROVED_BY%TYPE ,
                                  v_remarks                  IN  Tpa_enr_mem_buff_dtls.REMARKS%TYPE ,
                                  v_added_by                 IN  Tpa_enr_mem_buff_dtls.ADDED_BY%TYPE ,
                                  v_ava_cor_buffer           IN  Tpa_enr_mem_buff_dtls.Ava_Cor_Buffer%TYPE,
                                  v_ava_fam_buffer           IN  tpa_enr_mem_buff_dtls.ava_fam_buffer%TYPE,
                                  v_ava_mem_buffer           IN  tpa_enr_mem_buff_dtls.ava_mem_buffer%TYPE,
                                  v_claim_type               IN  tpa_enr_mem_buff_dtls.claim_type%TYPE,
                                  v_buffer_type              IN  tpa_enr_mem_buff_dtls.Buffer_Type%TYPE,
                                  v_alert                    OUT VARCHAR2,
                                  v_rows_processed           OUT Number) ;                                  
END account_info_pkg;

/

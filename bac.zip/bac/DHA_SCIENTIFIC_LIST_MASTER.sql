--------------------------------------------------------
--  DDL for Synonymn DHA_SCIENTIFIC_LIST_MASTER
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."DHA_SCIENTIFIC_LIST_MASTER" FOR "APP"."DHA_SCIENTIFIC_LIST_MASTER";

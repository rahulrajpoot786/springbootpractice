--------------------------------------------------------
--  DDL for Package DISPLAY_OF_BENEFITS
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "VENUBABU"."DISPLAY_OF_BENEFITS" 
AS
/*
PROCEDURE save_policy_data_info (
                                 V_RULE_BENEFIT_SEQ_ID  IN OUT TPA_RULE_BENEFIT.RULE_BENEFIT_SEQ_ID%TYPE,
								                 V_PROD_POLICY_SEQ_ID   IN     TPA_RULE_BENEFIT.POLICY_SEQ_ID%TYPE,
                                 V_BENEFIT_NAME         IN     TPA_RULE_BENEFIT.BENEFIT_NAME%TYPE,
                                 V_SUB_BENF_NAME        IN     TPA_RULE_BENEFIT.SUB_BENF_NAME%TYPE,
								                 V_SUB_BENF_SEQ_ID      IN     TPA_MASTER_SUBBENEFIT.SUB_BENF_SEQ_ID%TYPE,
                                 V_COVERAGE_PAY_VAL     IN     TPA_RULE_BENEFIT.COVERAGE_PAY_VAL%TYPE,
								                 V_COVERAGE             IN     TPA_RULE_BENEFIT.COVERAGE%TYPE,
                                 V_LIMIT                IN     TPA_RULE_BENEFIT.LIMIT%TYPE,
                                 V_COPAY                IN     TPA_RULE_BENEFIT.COPAY%TYPE,
								                 V_DEDUCTABLE           IN     TPA_RULE_BENEFIT.DEDUCTABLE%TYPE,
								                 V_MEM_WAITING          IN     TPA_RULE_BENEFIT.MEM_WAITING%TYPE,
                                 V_SESSION_ALLOWED      IN     TPA_RULE_BENEFIT.SESSION_ALLOWED%TYPE,
                             --- V_PROV_WISE_LIMIT      IN     TPA_RULE_BENEFIT.PROV_WISE_LIMIT%TYPE,
                                 V_TYPE_MODE            IN     TPA_RULE_BENEFIT.TYPE_MODE%TYPE,
                                 V_OTHER_REMARKS        IN     TPA_RULE_BENEFIT.OTHER_REMARKS%TYPE,
                                 V_ADDED_BY             IN     NUMBER,
								                 V_ROWS_PROCESSED        OUT    NUMBER
								                );
                                
----*******************************

PROCEDURE display_policy_info  (
                                v_prod_policy_seq_id    IN   Tpa_Ins_Prod_Policy.prod_policy_seq_id%TYPE,
                                result_set              OUT  sys_refcursor,
                                overall_remarks         OUT  sys_refcursor
                              );

-----******************************

                                
PROCEDURE select_benefit_limit (
                                v_policy_seq_id            IN  APP.tpa_enr_policy.policy_seq_id%TYPE,
                                v_member_seq_id            IN  APP.tpa_enr_policy_member.member_seq_id%TYPE,
                                v_request_type             IN  VARCHAR2,
                                v_seq_id                   IN  APP.clm_authorization_details.claim_seq_id%TYPE,
                                v_benefit_type             in  varchar2,
                                v_result_set               OUT SYS_REFCURSOR,
                                v_policy_details           OUT SYS_REFCURSOR,
                                v_available_sum_insured    OUT SYS_REFCURSOR,
                               v_overall_remark           OUT SYS_REFCURSOR
                                ) ;  
                                
                                
------******************************

FUNCTION get_utilized_amt_act_icd
                              (
                                v_policy_seq_id            IN  APP.tpa_enr_policy.policy_seq_id%TYPE,
                                v_member_seq_id            IN  APP.tpa_enr_policy_member.member_seq_id%TYPE,
                                v_master_activity_code     IN  APP.tpa_activity_master_details.master_activity_code%TYPE,
                                v_sub_benf_name            IN VARCHAR2,
                                v_request_type             IN  VARCHAR2,
                                v_seq_id                   IN  APP.clm_authorization_details.claim_seq_id%type
                              )
RETURN number;

-------************************************

FUNCTION get_utilize_amt_benfit_type
                              (
                                v_policy_seq_id            IN  APP.tpa_enr_policy.policy_seq_id%TYPE,
                                v_member_seq_id            IN  APP.tpa_enr_policy_member.member_seq_id%TYPE,
                                v_benefit_type             IN  VARCHAR2,
                                v_request_type             IN  VARCHAR2,
                                v_seq_id                   IN  App.clm_authorization_details.claim_seq_id%TYPE
                              )
RETURN number;


-------------------**********************************************

FUNCTION   get_utilized_amt_act_icd_clm
                    (v_policy_seq_id            IN  app.tpa_enr_policy.policy_seq_id%TYPE,
                     v_member_seq_id            IN  app.tpa_enr_policy_member.member_seq_id%TYPE,
                     v_master_activity_code     IN  app.tpa_activity_master_details.master_activity_code%TYPE,
                     v_sub_benf_name            IN VARCHAR2,
                     v_request_type             IN  varchar2,
                     v_seq_id                   IN app.clm_authorization_details.claim_seq_id%type
                     )
RETURN number;

---------------------************************************************

FUNCTION get_utilized_amt_act_icd_benf
                    (v_policy_seq_id            IN  app.tpa_enr_policy.policy_seq_id%TYPE,
                     v_member_seq_id            IN  app.tpa_enr_policy_member.member_seq_id%TYPE,
                     ---v_master_activity_code     IN  app.tpa_activity_master_details.master_activity_code%TYPE,
                     v_benefit_type             IN  varchar2,
                     v_request_type             IN  varchar2,
                     v_seq_id                   IN app.clm_authorization_details.claim_seq_id%type
                     )
RETURN number;

-----------------------*************************************************

FUNCTION get_utilised_amt_med   (
                                v_policy_seq_id            IN  APP.tpa_enr_policy.policy_seq_id%TYPE,
                                v_member_seq_id            IN  APP.tpa_enr_policy_member.member_seq_id%TYPE,
                                 v_request_type             IN  varchar2,
                                 v_seq_id                   IN app.clm_authorization_details.claim_seq_id%type
                               )
RETURN number ;

  --------------**********per policy*************---------------
FUNCTION get_utilized_out_area_policy 
                    (v_policy_seq_id            IN  app.tpa_enr_policy.policy_seq_id%TYPE,
                     v_member_seq_id            IN  app.tpa_enr_policy_member.member_seq_id%TYPE,
                     v_benefit_type             IN  varchar2,
                     v_request_type             IN  varchar2,
                     v_seq_id                   IN app.clm_authorization_details.claim_seq_id%type
                     )
RETURN number;
  --------------***************per claim***********---------------

FUNCTION get_utilized_amt_out_area
                    (v_policy_seq_id            IN  app.tpa_enr_policy.policy_seq_id%TYPE,
                     v_member_seq_id            IN  app.tpa_enr_policy_member.member_seq_id%TYPE,
                	--v_master_activity_code     IN  APP.tpa_activity_master_details.master_activity_code%TYPE,
                     v_benefit_type             IN  varchar2,
                     v_request_type             IN  varchar2,
                     v_seq_id                   IN app.clm_authorization_details.claim_seq_id%type
                     )
RETURN number;

-----------*****************pre existing condition_per_policy****-------------
FUNCTION get_utilized_amt_ped_policy
                    (v_policy_seq_id            IN  app.tpa_enr_policy.policy_seq_id%TYPE,
                     v_member_seq_id            IN  app.tpa_enr_policy_member.member_seq_id%TYPE,
                	--v_master_activity_code     IN  APP.tpa_activity_master_details.master_activity_code%TYPE,
                     v_request_type             IN  varchar2,
                     v_seq_id                   IN app.clm_authorization_details.claim_seq_id%type
                     )
RETURN number;   


---------*******pre existing condition_per_clm*******-------------------

FUNCTION get_utilized_amt_ped
                    (v_policy_seq_id            IN  app.tpa_enr_policy.policy_seq_id%TYPE,
                     v_member_seq_id            IN  app.tpa_enr_policy_member.member_seq_id%TYPE,
                	--v_master_activity_code     IN  APP.tpa_activity_master_details.master_activity_code%TYPE,
                     v_benefit_type             IN  varchar2,
                     v_request_type             IN  varchar2,
                     v_seq_id                   IN app.clm_authorization_details.claim_seq_id%type
                     )
RETURN number;                     

----------------------------**********************************************

PROCEDURE overall_remarks
                        (
                          v_prod_policy_seq_id       IN  APP.tpa_enr_policy.policy_seq_id%TYPE,
                          v_overall_remarks          IN  VARCHAR2,
                          v_rows_processed           OUT number
                        );*/
-------------------------------------------------------------------------------------------------------
PROCEDURE get_policy_tob(v_policy_seq_id              IN TPA_INS_PROD_POLICY_RULES.PROD_POLICY_RULE_SEQ_ID%TYPE,
                         v_member_seq_id              IN TPA_ENR_POLICY_MEMBER.MEMBER_SEQ_ID%TYPE,
                         v_module_flag                IN VARCHAR2,
                         v_seq_id                     IN NUMBER,
                         v_benefit_type               IN OUT VARCHAR2,
                         result_set                   OUT SYS_REFCURSOR,
                         v_policy_details             OUT SYS_REFCURSOR
                         );        
------------------------------------------------------------------------------------------------------
FUNCTION get_utlized_amnt (v_member_seq_id            IN tpa_enr_policy_member.member_seq_id%TYPE,
                           v_seq_id                   IN NUMBER,
                           v_cond_seq_id              IN app.tpa_rule_condition_mstr.cond_seq_id%TYPE,
                           v_mstr_code                IN tpa_activity_master_details.master_activity_code%TYPE,
                           v_mstr_code_flag           IN VARCHAR2,
                           v_module_flag              IN VARCHAR2,
                           v_benefit_flag             IN VARCHAR2)
 RETURN NUMBER;
                               
END DISPLAY_OF_BENEFITS ;

/

--------------------------------------------------------
--  DDL for Synonymn GN_NEW_MAIN_TRANS_DOWNLOAD_SEQ
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."GN_NEW_MAIN_TRANS_DOWNLOAD_SEQ" FOR "APP"."GN_NEW_MAIN_TRANS_DOWNLOAD_SEQ";

--------------------------------------------------------
--  DDL for Synonymn IDX_ENRPOLICY_POLICYNOINSSEQ
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."IDX_ENRPOLICY_POLICYNOINSSEQ" FOR "APP"."IDX_ENRPOLICY_POLICYNOINSSEQ";

REM INSERTING into VENUBABU.CRUSERS
SET DEFINE OFF;
Insert into VENUBABU.CRUSERS (NAME,EMPNO,DOJ,OFFMAIL,PERSMAIL,PROJ,MOB,ROLE,SKILLSET,PASS) values ('Asad','Intern012','2020-01-09','asad.ansari@vidalhealth.com','asad0728@yahoo.com','CR Tracker',7259640214,'dev','Python | Java | x86','ansari');

--------------------------------------------------------
--  DDL for Synonymn IDX_ENRPOLICY_PREVPOLICYSEQ
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."IDX_ENRPOLICY_PREVPOLICYSEQ" FOR "APP"."IDX_ENRPOLICY_PREVPOLICYSEQ";

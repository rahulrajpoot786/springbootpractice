--------------------------------------------------------
--  DDL for Synonymn DESTINATION_MESSAGE_RCPT_SEQ
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."DESTINATION_MESSAGE_RCPT_SEQ" FOR "APP"."DESTINATION_MESSAGE_RCPT_SEQ";

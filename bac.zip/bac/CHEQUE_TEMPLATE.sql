--------------------------------------------------------
--  DDL for Synonymn CHEQUE_TEMPLATE
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."CHEQUE_TEMPLATE" FOR "APP"."CHEQUE_TEMPLATE";

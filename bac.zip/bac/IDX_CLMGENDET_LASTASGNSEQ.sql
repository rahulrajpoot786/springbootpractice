--------------------------------------------------------
--  DDL for Synonymn IDX_CLMGENDET_LASTASGNSEQ
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."IDX_CLMGENDET_LASTASGNSEQ" FOR "APP"."IDX_CLMGENDET_LASTASGNSEQ";

--------------------------------------------------------
--  DDL for Synonymn BENF_LIVES_SEQ_ID
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."BENF_LIVES_SEQ_ID" FOR "APP"."BENF_LIVES_SEQ_ID";

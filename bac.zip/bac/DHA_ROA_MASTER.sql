--------------------------------------------------------
--  DDL for Synonymn DHA_ROA_MASTER
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."DHA_ROA_MASTER" FOR "APP"."DHA_ROA_MASTER";

--------------------------------------------------------
--  DDL for Synonymn FIN_PAYMENT_ADV_UNIQU_REF
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."FIN_PAYMENT_ADV_UNIQU_REF" FOR "FIN_APP"."FIN_PAYMENT_ADV_UNIQU_REF";

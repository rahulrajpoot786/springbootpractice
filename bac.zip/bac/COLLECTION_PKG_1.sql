--------------------------------------------------------
--  DDL for Package COLLECTION_PKG
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "VENUBABU"."COLLECTION_PKG" IS

  -- Author  : RANJAN
  -- Created : 19-Mar-19 18:30:48 18:30:48 
  -- Purpose : collection module under finance
----***************************************************************************
  PROCEDURE SEARCH_POLICY_LIST(P_MODE                IN OUT VARCHAR2,
                               P_GROUP_NAME          IN     VARCHAR2,
                               P_GROUP_ID            IN     VARCHAR2,
                               P_POLICY_NO           IN     VARCHAR2,
                               P_POLICY_STATUS       IN     VARCHAR2,
                               P_SORT_VAR            IN     VARCHAR2,
                               P_SORD_ORDER          IN     VARCHAR2,
                               P_START_NUM           IN     NUMBER,
                               P_END_NUM             IN     NUMBER,
                               P_DTL_RESULT          OUT    SYS_REFCURSOR,
                               P_TOT_RESULT          OUT    SYS_REFCURSOR
                              );
 --+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
 PROCEDURE GET_INVOICE_LIST (P_POLICY_SEQ_ID      IN     TPA_ENR_POLICY.POLICY_SEQ_ID%TYPE,--6115653
                             P_POLICY_RES         OUT    SYS_REFCURSOR,-- policy details
                             P_DTL_RESULT         OUT    SYS_REFCURSOR,-- detail report
                             P_TOT_RESULT         OUT    SYS_REFCURSOR -- total data
                            );
 --+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  PROCEDURE SAVE_COLLECTION(P_COLLECTION_SEQ_ID       IN OUT TPA_COLLECTION_DTL.COLLECTION_SEQ_ID%TYPE,
                            P_INVOICE_SEQ_ID          IN     TPA_COLLECTION_DTL.INVOICE_SEQ_ID%TYPE,
                            P_INVOICE_NUMBER          IN     TPA_COLLECTION_DTL.INVOICE_NUMBER%TYPE,
                            P_RECEIVED_AMOUNT         IN     TPA_COLLECTION_DTL.RECEIVED_AMOUNT%TYPE,
                            P_DUE_AMOUNT              IN     TPA_COLLECTION_DTL.DUE_AMOUNT%TYPE,
                            P_AMT_RECEIVED_DATE       IN     VARCHAR2,
                            P_TRANSACTION_REF_NO      IN     TPA_COLLECTION_DTL.TRANSACTION_REF_NO%TYPE,
                            P_ADDED_BY                IN     TPA_COLLECTION_DTL.ADDED_BY%TYPE,
                            P_UPLOAD_FILE_NAME        IN     TPA_COLLECTION_DTL.UPLOAD_FILE_NAME%TYPE,
                            P_UPLOAD_FILE             IN     TPA_COLLECTION_DTL.UPLOAD_FILE%TYPE,
                            P_ROWPROCESSED            OUT    INTEGER
                            );
 --++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  PROCEDURE REVERSE_COLLECTION(P_COLLECTION_SEQ_ID     IN  TPA_COLLECTION_DTL.COLLECTION_SEQ_ID%TYPE,
                              P_DELETE_RMK            IN  VARCHAR2,
                              P_ADDED_BY              IN  TPA_COLLECTION_DTL.ADDED_BY%TYPE,
                              P_ROWPROCESSED          OUT INTEGER
                              ); 
 --+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
 PROCEDURE COLLECTION_LIST (P_INVOICE_SEQ_ID       IN     TPA_COLLECTION_DTL.INVOICE_SEQ_ID%TYPE,
                            P_INVOICE_NUMBER       IN     TPA_COLLECTION_DTL.INVOICE_NUMBER%TYPE,
                            P_COL_LIST             OUT    SYS_REFCURSOR,
                            P_INV_DTL              OUT    SYS_REFCURSOR
                           );
 --++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
 PROCEDURE COLLECTION_REPORT(P_POLICY_SEEQ_ID IN   TPA_FIN_INVOICE.POLICY_SEQ_ID%TYPE,
                             P_RESULT       OUT  SYS_REFCURSOR
                            );      
----***************************************************************************
END COLLECTION_PKG;

/

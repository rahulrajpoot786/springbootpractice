--------------------------------------------------------
--  DDL for Synonymn IDX_ENRMEMBUFF_MEMSEQ
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."IDX_ENRMEMBUFF_MEMSEQ" FOR "APP"."IDX_ENRMEMBUFF_MEMSEQ";

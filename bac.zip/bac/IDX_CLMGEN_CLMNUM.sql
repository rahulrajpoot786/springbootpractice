--------------------------------------------------------
--  DDL for Synonymn IDX_CLMGEN_CLMNUM
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."IDX_CLMGEN_CLMNUM" FOR "APP"."IDX_CLMGEN_CLMNUM";

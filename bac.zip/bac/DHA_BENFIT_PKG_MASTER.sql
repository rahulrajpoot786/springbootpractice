--------------------------------------------------------
--  DDL for Synonymn DHA_BENFIT_PKG_MASTER
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."DHA_BENFIT_PKG_MASTER" FOR "APP"."DHA_BENFIT_PKG_MASTER";

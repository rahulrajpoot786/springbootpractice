--------------------------------------------------------
--  DDL for Synonymn CODE_CLEANUP_WORKFLOW
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."CODE_CLEANUP_WORKFLOW" FOR "APP"."CODE_CLEANUP_WORKFLOW";

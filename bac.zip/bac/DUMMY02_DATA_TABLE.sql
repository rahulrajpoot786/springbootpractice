REM INSERTING into VENUBABU.DUMMY02
SET DEFINE OFF;
Insert into VENUBABU.DUMMY02 (COL1,COL2,COL3) values ('A','B','C');
Insert into VENUBABU.DUMMY02 (COL1,COL2,COL3) values ('C','A','B');
Insert into VENUBABU.DUMMY02 (COL1,COL2,COL3) values ('A','A','B');
Insert into VENUBABU.DUMMY02 (COL1,COL2,COL3) values ('V','V','V');

--------------------------------------------------------
--  DDL for Synonymn BANK_GUARANTEE_SEQ
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."BANK_GUARANTEE_SEQ" FOR "APP"."BANK_GUARANTEE_SEQ";

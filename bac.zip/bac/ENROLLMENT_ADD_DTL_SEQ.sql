--------------------------------------------------------
--  DDL for Synonymn ENROLLMENT_ADD_DTL_SEQ
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."ENROLLMENT_ADD_DTL_SEQ" FOR "APP"."ENROLLMENT_ADD_DTL_SEQ";

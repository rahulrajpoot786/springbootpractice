--------------------------------------------------------
--  DDL for Synonymn IDX_MEMCARDDTL_ENROLLMENTID
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."IDX_MEMCARDDTL_ENROLLMENTID" FOR "APP"."IDX_MEMCARDDTL_ENROLLMENTID";

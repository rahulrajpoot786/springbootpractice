--------------------------------------------------------
--  DDL for Synonymn AUTH_TRAN_D
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."AUTH_TRAN_D" FOR "APP"."AUTH_TRAN_D";

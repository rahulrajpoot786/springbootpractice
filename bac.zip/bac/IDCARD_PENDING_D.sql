--------------------------------------------------------
--  DDL for Synonymn IDCARD_PENDING_D
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."IDCARD_PENDING_D" FOR "IDCARD"."IDCARD_PENDING_D";

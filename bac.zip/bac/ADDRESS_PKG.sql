--------------------------------------------------------
--  DDL for Package Body ADDRESS_PKG
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "VENUBABU"."ADDRESS_PKG" 
IS
--     Author     : Raghavendra M.K.
--    Created     :
--    Project     : TTK.
--  Description   :	Package has the procedures required to process the address.
--  History of Changes:     Date   --   User -- Description
--                      2nd-Oct-2005--	Raghu  -- Created.
--
--
--
--
--


--    This procedure is used to INSERT and UPDATE the Hospital address.

       PROCEDURE PR_HOSPITAL_ADDRESS_SAVE (
        V_Addr_Seq_Id                       IN OUT TPA_HOSP_ADDRESS.ADDR_SEQ_ID%TYPE,
        V_Hosp_Seq_Id                      IN TPA_HOSP_INFO.HOSP_SEQ_ID%TYPE,
        V_Address_1                        IN TPA_HOSP_ADDRESS.ADDRESS_1%TYPE,
        V_Address_2                        IN TPA_HOSP_ADDRESS.ADDRESS_2%TYPE,
        V_Address_3                        IN TPA_HOSP_ADDRESS.ADDRESS_3%TYPE,
        V_City_Type_Id                     IN TPA_HOSP_ADDRESS.City_Type_Id%TYPE,
        V_State_Type_Id                    IN TPA_HOSP_ADDRESS.STATE_TYPE_ID%TYPE,
        V_Pin_Code                         IN TPA_HOSP_ADDRESS.PIN_CODE%TYPE,
        V_Country_Id                       IN TPA_HOSP_ADDRESS.COUNTRY_ID%TYPE,
        V_Landmarks                        IN TPA_HOSP_ADDRESS.LANDMARKS%TYPE,
        V_User_ID                          IN  NUMBER,
        v_rows_processed                   OUT  NUMBER
     )
     IS
     BEGIN

         -- If ID is zero (0), then it is INSERT  operation. otherwise UPDATE operation.
         IF V_Addr_Seq_Id = 0
      THEN
        INSERT INTO  TPA_HOSP_ADDRESS (
          ADDR_SEQ_ID,
          HOSP_SEQ_ID,
          HOSP_BANK_SEQ_ID,
          HOSP_GNRL_SEQ_ID,
          ADDRESS_1,
          ADDRESS_2,
          ADDRESS_3,
          CITY_TYPE_ID,
          STATE_TYPE_ID,
          COUNTRY_ID,
          PIN_CODE,
          LANDMARKS,
          ADDED_BY,
          ADDED_DATE
        ) VALUES (
          tpa_hosp_address_seq.NEXTVAL,
          V_HOSP_SEQ_ID,
          NULL,    -- V_HOSP_BANK_SEQ_ID   -- This will be valued while inserting from Bank Address.
          NULL,    --  V_HOSP_GNRL_SEQ_ID,  --> This will be valued while inserting PO Address.
          V_ADDRESS_1,
          V_ADDRESS_2,
          V_ADDRESS_3,
          V_CITY_TYPE_ID,
          V_STATE_TYPE_ID,
          V_COUNTRY_ID,
          V_PIN_CODE,
          V_LANDMARKS,
          V_User_Id,
          SYSDATE
        )RETURNING ADDR_SEQ_ID INTO V_Addr_Seq_Id;
      ELSE  -- Update the address.
        UPDATE TPA_HOSP_ADDRESS
        SET
          ADDRESS_1                       = V_ADDRESS_1,
          ADDRESS_2                       = V_ADDRESS_2,
          ADDRESS_3                       = V_ADDRESS_3,
          CITY_TYPE_ID                    = V_CITY_TYPE_ID,
          STATE_TYPE_ID                   = V_STATE_TYPE_ID,
          COUNTRY_ID                      = V_COUNTRY_ID,
          PIN_CODE                        = V_PIN_CODE,
          LANDMARKS                       = V_LANDMARKS,
          UPDATED_BY                      = V_User_Id,
          UPDATED_DATE                    = SYSDATE
        WHERE ADDR_SEQ_ID                   = V_ADDR_SEQ_ID ;
--          AND  HOSP_SEQ_ID      = V_HOSP_SEQ_ID ;

      END IF;
 v_rows_processed  := SQL%ROWCOUNT;
    END;

-- **************************************************************************

--    This procedure is used to INSERT and UPDATE the Bank address.
     PROCEDURE PR_HOSPITAL_BANK_ADDRESS_SAVE (
        V_Addr_Seq_Id                 IN OUT TPA_HOSP_ADDRESS.ADDR_SEQ_ID%TYPE,
        V_HOSP_BANK_SEQ_ID                 IN TPA_HOSP_ADDRESS.HOSP_BANK_SEQ_ID%TYPE,
        V_Address_1                        IN TPA_HOSP_ADDRESS.ADDRESS_1%TYPE,
        V_Address_2                        IN TPA_HOSP_ADDRESS.ADDRESS_2%TYPE,
        V_Address_3                        IN TPA_HOSP_ADDRESS.ADDRESS_3%TYPE,
        V_City_Type_Id                     IN TPA_HOSP_ADDRESS.City_Type_Id%TYPE,
        V_State_Type_Id                    IN TPA_HOSP_ADDRESS.STATE_TYPE_ID%TYPE,
        V_Pin_Code                         IN TPA_HOSP_ADDRESS.PIN_CODE%TYPE,
        V_Country_Id                       IN TPA_HOSP_ADDRESS.COUNTRY_ID%TYPE,
        v_branch_seq_id                    IN NUMBER,
        V_User_ID                          IN  NUMBER,
        v_rows_processed                    OUT  NUMBER
     )
     IS
     BEGIN

        -- If ID is zero (0), then it is INSERT  operation. otherwise UPDATE operation.
         IF V_Addr_Seq_Id = 0
      THEN
        INSERT INTO  TPA_HOSP_ADDRESS (
          ADDR_SEQ_ID,
          HOSP_SEQ_ID,
          HOSP_BANK_SEQ_ID,
          HOSP_GNRL_SEQ_ID,
          ADDRESS_1,
          ADDRESS_2,
          ADDRESS_3,
          CITY_TYPE_ID,
          STATE_TYPE_ID,
          COUNTRY_ID,
          PIN_CODE,
          BRANCH_SEQ_ID,
          ADDED_BY,
          ADDED_DATE
        ) VALUES (
          tpa_hosp_address_seq.NEXTVAL,
          NULL,          -- V_HOSP_SEQ_ID. --> This will be valued while inserting Hospital Address.
          V_HOSP_BANK_SEQ_ID ,
          NULL,              --  V_HOSP_GNRL_SEQ_ID,  --> This will be valued while inserting PO Address.
          V_ADDRESS_1,
          V_ADDRESS_2,
          V_ADDRESS_3,
          V_CITY_TYPE_ID,
          V_STATE_TYPE_ID,
          V_COUNTRY_ID,
          V_PIN_CODE,
          v_branch_seq_id,
          V_User_Id,
          SYSDATE
        )RETURNING ADDR_SEQ_ID INTO V_Addr_Seq_Id;
      ELSE     -- Else Update
        UPDATE TPA_HOSP_ADDRESS
        SET
          ADDRESS_1                       = V_ADDRESS_1,
          ADDRESS_2                       = V_ADDRESS_2,
          ADDRESS_3                       = V_ADDRESS_3,
          CITY_TYPE_ID                    = V_CITY_TYPE_ID,
          STATE_TYPE_ID                   = V_STATE_TYPE_ID,
          COUNTRY_ID                      = V_COUNTRY_ID,
          HOSP_BANK_SEQ_ID                =V_HOSP_BANK_SEQ_ID,
          PIN_CODE                        = V_PIN_CODE,
          BRANCH_SEQ_ID                   = v_branch_seq_id,
          UPDATED_BY                      = V_User_Id,
          UPDATED_DATE                    = SYSDATE
        WHERE ADDR_SEQ_ID                   = V_ADDR_SEQ_ID;
      END IF;
 v_rows_processed  := SQL%ROWCOUNT;
    END;
-- **************************************************************************
--    This procedure is used to INSERT and UPDATE the Purchase Order address.
   PROCEDURE PR_HOSPITAL_PO_ADDRESS_SAVE (
        V_Addr_Seq_Id                 IN OUT TPA_HOSP_ADDRESS.ADDR_SEQ_ID%TYPE,
        V_HOSP_GNRL_SEQ_ID                 IN TPA_HOSP_ADDRESS.HOSP_GNRL_SEQ_ID%TYPE,
        V_Address_1                        IN TPA_HOSP_ADDRESS.ADDRESS_1%TYPE,
        V_Address_2                        IN TPA_HOSP_ADDRESS.ADDRESS_2%TYPE,
        V_Address_3                        IN TPA_HOSP_ADDRESS.ADDRESS_3%TYPE,
        V_City_Type_Id                     IN TPA_HOSP_ADDRESS.City_Type_Id%TYPE,
        V_State_Type_Id                    IN TPA_HOSP_ADDRESS.STATE_TYPE_ID%TYPE,
        V_Pin_Code                         IN TPA_HOSP_ADDRESS.PIN_CODE%TYPE,
        V_Country_Id                       IN TPA_HOSP_ADDRESS.COUNTRY_ID%TYPE,
        V_User_ID                          IN  NUMBER,
        v_rows_processed                    OUT  NUMBER
    )
     IS
     BEGIN
         -- If ID is zero (0), then it is INSERT  operation. otherwise UPDATE operation.
         IF V_Addr_Seq_Id = 0
      THEN
        INSERT INTO  TPA_HOSP_ADDRESS (
          ADDR_SEQ_ID,
          HOSP_SEQ_ID,
          HOSP_BANK_SEQ_ID,
          HOSP_GNRL_SEQ_ID,
          ADDRESS_1,
          ADDRESS_2,
          ADDRESS_3,
          CITY_TYPE_ID,
          STATE_TYPE_ID,
          COUNTRY_ID,
          PIN_CODE,
          ADDED_BY,
          ADDED_DATE
        ) VALUES (
          tpa_hosp_address_seq.NEXTVAL,
          NULL ,   -- V_HOSP_SEQ_ID  --> This field is valued only for Hospital address.
          NULL,    -- V_HOSP_BANK_SEQ_ID   -- This will be valued while inserting from Bank Address.
          V_HOSP_GNRL_SEQ_ID,
          V_ADDRESS_1,
          V_ADDRESS_2,
          V_ADDRESS_3,
          V_CITY_TYPE_ID,
          V_STATE_TYPE_ID,
          V_COUNTRY_ID,
          V_PIN_CODE,
          V_User_Id,
          SYSDATE
        )RETURNING ADDR_SEQ_ID INTO V_Addr_Seq_Id;
      ELSE  -- Else Update
        UPDATE TPA_HOSP_ADDRESS
        SET
          ADDRESS_1                       = V_ADDRESS_1,
          ADDRESS_2                       = V_ADDRESS_2,
          ADDRESS_3                       = V_ADDRESS_3,
          CITY_TYPE_ID                    = V_CITY_TYPE_ID,
          STATE_TYPE_ID                   = V_STATE_TYPE_ID,
          COUNTRY_ID                      = V_COUNTRY_ID,
          PIN_CODE                        = V_PIN_CODE,
          UPDATED_BY                      = V_User_Id,
          UPDATED_DATE                    = SYSDATE
        WHERE ADDR_SEQ_ID                  = V_ADDR_SEQ_ID;
      END IF;
 v_rows_processed  := SQL%ROWCOUNT;
    END;
-- **************************************************************************

-- *******************************PARTNER LOGIN ******************************* 

--    This procedure is used to INSERT and UPDATE the Partner address.
	
	
	  PROCEDURE PR_PARTNER_ADDRESS_SAVE (
        V_Addr_Seq_Id                       IN OUT TPA_PARTNER_ADDRESS.ADDR_SEQ_ID%TYPE,
        v_ptnr_seq_id                      IN tpa_partner_info.PTNR_SEQ_ID%TYPE,
        V_Address_1                        IN TPA_PARTNER_ADDRESS.ADDRESS_1%TYPE,
        V_Address_2                        IN TPA_PARTNER_ADDRESS.ADDRESS_2%TYPE,
        V_Address_3                        IN TPA_PARTNER_ADDRESS.ADDRESS_3%TYPE,
        V_City_Type_Id                     IN TPA_PARTNER_ADDRESS.City_Type_Id%TYPE,
        V_State_Type_Id                    IN TPA_PARTNER_ADDRESS.STATE_TYPE_ID%TYPE,
        V_Pin_Code                         IN TPA_PARTNER_ADDRESS.PIN_CODE%TYPE,
        V_Country_Id                       IN TPA_PARTNER_ADDRESS.COUNTRY_ID%TYPE,
        --V_Landmarks                        IN TPA_PARTNER_ADDRESS.LANDMARKS%TYPE,
        v_added_by                          IN  NUMBER,
        v_rows_processed                   OUT  NUMBER
     )
     IS
     BEGIN

         -- If ID is zero (0), then it is INSERT  operation. otherwise UPDATE operation.
         IF NVL(V_Addr_Seq_Id,0) = 0
      THEN

        INSERT INTO  TPA_PARTNER_ADDRESS (
          ADDR_SEQ_ID,
          PTNR_SEQ_ID,
          PTNR_BANK_SEQ_ID,
          PTNR_GNRL_SEQ_ID,
          ADDRESS_1,
          ADDRESS_2,
          ADDRESS_3,
          CITY_TYPE_ID,
          STATE_TYPE_ID,
          COUNTRY_ID,
          PIN_CODE,
       -- LANDMARKS,
          ADDED_BY,
          ADDED_DATE
        ) VALUES (
          TPA_PARTNER_ADDRESS_SEQ.NEXTVAL,
          v_ptnr_seq_id,
          NULL,    -- V_PTNR_BANK_SEQ_ID -- This will be valued while inserting from Bank Address.
          NULL,    --  V_PTNR_GNRL_SEQ_ID,  --> This will be valued while inserting PO Address.
          V_ADDRESS_1,
          V_ADDRESS_2,
          V_ADDRESS_3,
          V_CITY_TYPE_ID,
          V_STATE_TYPE_ID,
          V_COUNTRY_ID,
          V_PIN_CODE,
          --V_LANDMARKS,
          v_added_by,
          SYSDATE
        )
          RETURNING ADDR_SEQ_ID INTO V_Addr_Seq_Id;
      ELSE  -- Update the address.
    
        UPDATE TPA_PARTNER_ADDRESS
        SET
          ADDRESS_1                       = V_ADDRESS_1,
          ADDRESS_2                       = V_ADDRESS_2,
          ADDRESS_3                       = V_ADDRESS_3,
          CITY_TYPE_ID                    = V_CITY_TYPE_ID,
          STATE_TYPE_ID                   = V_STATE_TYPE_ID,
          COUNTRY_ID                      = V_COUNTRY_ID,
          PIN_CODE                        = V_PIN_CODE,
          --LANDMARKS                       = V_LANDMARKS,
          UPDATED_BY                      = v_added_by,
          UPDATED_DATE                    = SYSDATE
        WHERE ADDR_SEQ_ID                   = V_ADDR_SEQ_ID ;


      END IF;
 v_rows_processed  := SQL%ROWCOUNT;
    END PR_PARTNER_ADDRESS_SAVE;
    
    
    -- **************************************************************************
--    This procedure is used to INSERT and UPDATE the Bank address.

PROCEDURE PR_PARTNER_BANK_ADDRESS_SAVE (
        V_Addr_Seq_Id                      IN OUT TPA_PARTNER_ADDRESS.ADDR_SEQ_ID%TYPE,
        V_PTNR_BANK_SEQ_ID                 IN TPA_PARTNER_ADDRESS.PTNR_BANK_SEQ_ID%TYPE,
        V_Address_1                        IN TPA_PARTNER_ADDRESS.ADDRESS_1%TYPE,
        V_Address_2                        IN TPA_PARTNER_ADDRESS.ADDRESS_2%TYPE,
        V_Address_3                        IN TPA_PARTNER_ADDRESS.ADDRESS_3%TYPE,
        V_City_Type_Id                     IN TPA_PARTNER_ADDRESS.City_Type_Id%TYPE,
        V_State_Type_Id                    IN TPA_PARTNER_ADDRESS.STATE_TYPE_ID%TYPE,
        V_Pin_Code                         IN TPA_PARTNER_ADDRESS.PIN_CODE%TYPE,
        V_Country_Id                       IN TPA_PARTNER_ADDRESS.COUNTRY_ID%TYPE,
        v_added_by                          IN  NUMBER,
        v_rows_processed                    OUT  NUMBER
     )
     IS
     BEGIN

        -- If ID is zero (0), then it is INSERT  operation. otherwise UPDATE operation.
         IF nvl(V_Addr_Seq_Id,0) = 0
      THEN
   
        INSERT INTO  TPA_PARTNER_ADDRESS (
          ADDR_SEQ_ID,
          PTNR_SEQ_ID,
          PTNR_BANK_SEQ_ID,
          PTNR_GNRL_SEQ_ID,
          ADDRESS_1,
          ADDRESS_2,
          ADDRESS_3,
          CITY_TYPE_ID,
          STATE_TYPE_ID,
          COUNTRY_ID,
          PIN_CODE,
          ADDED_BY,
          ADDED_DATE
        ) VALUES (
          TPA_PARTNER_ADDRESS_SEQ.NEXTVAL,
          NULL,          -- V_PTNR_SEQ_ID. --> This will be valued while inserting Partner Address.
          V_PTNR_BANK_SEQ_ID ,
          NULL,              --  V_PTNR_GNRL_SEQ_ID,  --> This will be valued while inserting PO Address.
          V_ADDRESS_1,
          V_ADDRESS_2,
          V_ADDRESS_3,
          V_CITY_TYPE_ID,
          V_STATE_TYPE_ID,
          V_COUNTRY_ID,
          V_PIN_CODE,
          v_added_by,
          SYSDATE
        )RETURNING ADDR_SEQ_ID INTO V_Addr_Seq_Id;
      ELSE     -- Else Update
  
        UPDATE TPA_PARTNER_ADDRESS
        SET
          ADDRESS_1                       = V_ADDRESS_1,
          ADDRESS_2                       = V_ADDRESS_2,
          ADDRESS_3                       = V_ADDRESS_3,
          CITY_TYPE_ID                    = V_CITY_TYPE_ID,
          STATE_TYPE_ID                   = V_STATE_TYPE_ID,
          COUNTRY_ID                      = V_COUNTRY_ID,
          PIN_CODE                        = V_PIN_CODE,
          UPDATED_BY                      = v_added_by,
          UPDATED_DATE                    = SYSDATE
        WHERE ADDR_SEQ_ID                   = V_ADDR_SEQ_ID;
      END IF;
 v_rows_processed  := SQL%ROWCOUNT;
    END PR_PARTNER_BANK_ADDRESS_SAVE;
	
  
  -- **************************************************************************	
--    This procedure is used to INSERT and UPDATE the Purchase Order address.
	
	PROCEDURE PR_PARTNER_PO_ADDRESS_SAVE (
        V_Addr_Seq_Id                      IN OUT TPA_PARTNER_ADDRESS.ADDR_SEQ_ID%TYPE,
        V_PTNR_GNRL_SEQ_ID                 IN TPA_PARTNER_ADDRESS.PTNR_GNRL_SEQ_ID%TYPE,
        V_Address_1                        IN TPA_PARTNER_ADDRESS.ADDRESS_1%TYPE,
        V_Address_2                        IN TPA_PARTNER_ADDRESS.ADDRESS_2%TYPE,
        V_Address_3                        IN TPA_PARTNER_ADDRESS.ADDRESS_3%TYPE,
        V_City_Type_Id                     IN TPA_PARTNER_ADDRESS.City_Type_Id%TYPE,
        V_State_Type_Id                    IN TPA_PARTNER_ADDRESS.STATE_TYPE_ID%TYPE,
        V_Pin_Code                         IN TPA_PARTNER_ADDRESS.PIN_CODE%TYPE,
        V_Country_Id                       IN TPA_PARTNER_ADDRESS.COUNTRY_ID%TYPE,
        v_added_by                          IN  NUMBER,
        v_rows_processed                    OUT  NUMBER
    )
     IS
     BEGIN
         -- If ID is zero (0), then it is INSERT  operation. otherwise UPDATE operation.
         /*insert into lala(a) values(V_Addr_Seq_Id);*/
         IF nvl(V_Addr_Seq_Id,0) = 0
      THEN
     
        INSERT INTO  TPA_PARTNER_ADDRESS (
          ADDR_SEQ_ID,
          PTNR_SEQ_ID,
          PTNR_BANK_SEQ_ID,
          PTNR_GNRL_SEQ_ID,
          ADDRESS_1,
          ADDRESS_2,
          ADDRESS_3,
          CITY_TYPE_ID,
          STATE_TYPE_ID,
          COUNTRY_ID,
          PIN_CODE,
          ADDED_BY,
          ADDED_DATE
        ) VALUES (
          TPA_PARTNER_ADDRESS_SEQ.NEXTVAL,
          NULL ,   -- V_PTNR_SEQ_ID  --> This field is valued only for Partner address.
          NULL,    -- V_PTNR_BANK_SEQ_ID   -- This will be valued while inserting from Bank Address.
          V_PTNR_GNRL_SEQ_ID,
          V_ADDRESS_1,
          V_ADDRESS_2,
          V_ADDRESS_3,
          V_CITY_TYPE_ID,
          V_STATE_TYPE_ID,
          V_COUNTRY_ID,
          V_PIN_CODE,
          v_added_by,
          SYSDATE
        )RETURNING ADDR_SEQ_ID INTO V_Addr_Seq_Id;
      ELSE  -- Else Update
        UPDATE TPA_PARTNER_ADDRESS
        SET
          ADDRESS_1                       = V_ADDRESS_1,
          ADDRESS_2                       = V_ADDRESS_2,
          ADDRESS_3                       = V_ADDRESS_3,
          CITY_TYPE_ID                    = V_CITY_TYPE_ID,
          STATE_TYPE_ID                   = V_STATE_TYPE_ID,
          COUNTRY_ID                      = V_COUNTRY_ID,
          PIN_CODE                        = V_PIN_CODE,
          UPDATED_BY                      = v_added_by,
          UPDATED_DATE                    = SYSDATE
        WHERE ADDR_SEQ_ID                  = V_ADDR_SEQ_ID;
      END IF;
 v_rows_processed  := SQL%ROWCOUNT;
   

END PR_PARTNER_PO_ADDRESS_SAVE;

END;

/

--------------------------------------------------------
--  DDL for Synonymn CITYBANK_INS_XML
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."CITYBANK_INS_XML" FOR "APP"."CITYBANK_INS_XML";

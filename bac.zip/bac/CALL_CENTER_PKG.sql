--------------------------------------------------------
--  DDL for Synonymn CALL_CENTER_PKG
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."CALL_CENTER_PKG" FOR "APP"."CALL_CENTER_PKG";

--------------------------------------------------------
--  DDL for Synonymn AUTHORISATION_D
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."AUTHORISATION_D" FOR "APP"."AUTHORISATION_D";

--------------------------------------------------------
--  DDL for Synonymn BUFFERREQUESTED
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."BUFFERREQUESTED" FOR "APP"."BUFFERREQUESTED";

--------------------------------------------------------
--  DDL for Package HOSPITAL_MOU
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "VENUBABU"."HOSPITAL_MOU" 
IS
  PROCEDURE pr_mou_save(v_hosp_seq_id tpa_hosp_empanel_status.hosp_seq_id%TYPE,
                        v_mou  IN XMLTYPE,
                        v_added_by tpa_hosp_mou.added_by%TYPE
                        );
end HOSPITAL_MOU;

/

--------------------------------------------------------
--  DDL for Synonymn BENEFIT_CAT_DETAILS
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."BENEFIT_CAT_DETAILS" FOR "APP"."BENEFIT_CAT_DETAILS";

--------------------------------------------------------
--  DDL for Synonymn IDADMIN_PKG
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."IDADMIN_PKG" FOR "INTX"."IDADMIN_PKG";

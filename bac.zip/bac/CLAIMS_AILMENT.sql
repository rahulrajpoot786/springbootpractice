--------------------------------------------------------
--  DDL for Synonymn CLAIMS_AILMENT
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."CLAIMS_AILMENT" FOR "APP"."CLAIMS_AILMENT";

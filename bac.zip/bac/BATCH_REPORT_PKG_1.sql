--------------------------------------------------------
--  DDL for Package BATCH_REPORT_PKG
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "VENUBABU"."BATCH_REPORT_PKG" is

  -- Author  : GOVARDHANA_RG
  -- Created : 8/12/2006 12:59:01 PM
  -- Purpose : generate report for batch .
  -- Modified by S.V.Sreeraj on 14-feb-2007

--========================================================================================
   PROCEDURE batch_report_list(
   where_clause              IN  VARCHAR2,
   result_set                 OUT SYS_REFCURSOR
 );
--==========================================================================================
  PROCEDURE covering_letter(
    v_batch_number          IN  VARCHAR2,
    resultset               OUT  SYS_REFCURSOR
  );
--===========================================================================================
  PROCEDURE bank_transaction_report(
    where_clause                IN  VARCHAR2,
    result_set                  OUT SYS_REFCURSOR
  );
--============================================================================================
  PROCEDURE float_transaction_report(
    where_clause                IN  VARCHAR2,
    result_set                  OUT SYS_REFCURSOR
  );
--===========================================================================================
  PROCEDURE reconcilation_report(
    where_clause              IN  VARCHAR2,
    result_set                OUT  SYS_REFCURSOR
  );
--===============================================================================================
  PROCEDURE EFT_claims_details_report(
     where_clause              IN  VARCHAR2,
     result_set                 OUT SYS_REFCURSOR
  );
--===============================================================================================
    PROCEDURE CITI_claims_details_report(
     where_clause IN  VARCHAR2,
     result_set   OUT SYS_REFCURSOR
  );
--================================================================================================
  PROCEDURE claims_details_report(
    where_clause               IN  VARCHAR2,
    result_set                OUT  SYS_REFCURSOR
  );
--================================================================================================
 /*  PROCEDURE float_statement_report(
    where_clause    IN  VARCHAR2,
    result_set      OUT SYS_REFCURSOR
  );
--===============================================================================================================
  PROCEDURE float_statement_summary(
    where_clause    IN  VARCHAR2,
    result_set      OUT SYS_REFCURSOR
  );*/
--====================================================================================================================
  FUNCTION get_ailments(
    v_calims_seq_id           NUMBER ) RETURN VARCHAR2 DETERMINISTIC;

--========================================================================================
  PROCEDURE claims_pending_report(
    where_clause               IN  VARCHAR2,
    v_result_set                OUT  SYS_REFCURSOR
  );
--==================================================================================================
PROCEDURE Policy_bank_dtl_report(
     where_clause              IN  VARCHAR2,
     v_result_set              OUT SYS_REFCURSOR
  );
--==================================================================================================
PROCEDURE Hosp_bank_dtl_report(
     where_clause              IN  VARCHAR2,
     v_result_set              OUT SYS_REFCURSOR
  );    
--================================================================================================
  PROCEDURE EFT_claims_pending_report(
     where_clause              IN  VARCHAR2,
     v_result_set                 OUT SYS_REFCURSOR
  );
  --================================================================================================
  PROCEDURE get_batch_list (
     v_float_acct_num IN  tpa_float_account.float_account_number%TYPE,
     v_batch_number   IN  tpa_batch_master.batch_number%TYPE,
     v_str_date       IN  VARCHAR2,
     v_end_date       IN  VARCHAR2,
     v_identifier     IN  VARCHAR2,
     v_sort_var       IN  VARCHAR2,
     v_sort_order     IN  VARCHAR2,
     v_start_num      IN  NUMBER ,
     v_end_num        IN  NUMBER ,
     v_result_set      OUT SYS_REFCURSOR
  );
--================================================================================================
  PROCEDURE EFT_Covering_letter(
     where_clause    IN  VARCHAR2,
     v_cov_letter     OUT SYS_REFCURSOR
  );
--================================================================================================
  PROCEDURE EFT_Cov_letter_Annexure (
     where_clause    IN  VARCHAR2,
     v_abn_bank      OUT SYS_REFCURSOR,
     v_deutsche_bank OUT SYS_REFCURSOR,
     v_hdfc_bank     OUT SYS_REFCURSOR,
     v_axis_bank     OUT SYS_REFCURSOR
  );
--================================================================================================
  PROCEDURE tpa_commission_report(
    where_clause            IN VARCHAR2,
    Individual_Enrl_cur     OUT SYS_REFCURSOR ,
    Individual_End_cur      OUT SYS_REFCURSOR ,
    Group_Enrl_cur          OUT SYS_REFCURSOR ,
    Group_End_cur           OUT SYS_REFCURSOR ,
    summary_cur             OUT SYS_REFCURSOR ,
    invoice_cur             OUT SYS_REFCURSOR
);
--================================================================================================
  FUNCTION get_billno(
    v_claim_seq_id      IN NUMBER ) RETURN VARCHAR2 DETERMINISTIC;
--================================================================================================
  FUNCTION get_hospitalization(
    v_claim_seq_id      IN NUMBER ,
    v_date_of_admission IN DATE := NULL,
    v_date_of_discharge IN DATE := NULL ) RETURN VARCHAR2 DETERMINISTIC ;
--================================================================================================
  FUNCTION get_icds(
     v_calims_seq_id           NUMBER ) RETURN VARCHAR2 DETERMINISTIC;
--================================================================================================
  PROCEDURE Get_76_col_rpt_data (
    FilterValues  IN VARCHAR2,
    v_resultset    OUT SYS_REFCURSOR
  );
--================================================================================================
  PROCEDURE A76_col_debit_note_rpt (
      FilterValues  IN VARCHAR2,
      v_resultset   OUT SYS_REFCURSOR
    );
--================================================================================================
--==================================================================================
--This Procedure is used to generate a Covering Letter for issued cheques.
  PROCEDURE cheque_covering_letter(
    v_payment_seq_id          IN  VARCHAR2,
    resultset                OUT  SYS_REFCURSOR
  );
--================================================================================================
--This Procedure is used to generate a Address Label for issued cheques.
  PROCEDURE address_label(
    v_payment_seq_id          IN  VARCHAR2,
    resultset                OUT  SYS_REFCURSOR
  );
  --================================================================================================
  PROCEDURE fut_gen_claims_details_report(
     where_clause IN  VARCHAR2,
     result_set   OUT SYS_REFCURSOR
  );
--================================================================================================
  PROCEDURE claim_computation (
    v_payment_seq_id          IN  VARCHAR2,
    v_resultset       OUT SYS_REFCURSOR
  );
 --================================================================================================
 PROCEDURE claim_computation_lineitems(
    v_payment_seq_id    IN  VARCHAR2,
    v_resultset       OUT SYS_REFCURSOR
  );
 --================================================================================================
 FUNCTION get_comp_icds(
     v_claims_seq_id           NUMBER ) RETURN VARCHAR2 DETERMINISTIC;
 --================================================================================================
  /*PROCEDURE tds_fund_transfer_rpt (
    v_from_date               IN VARCHAR2,
    v_to_date                 IN VARCHAR2,
    v_account_number          IN TPA_BANK_ACCOUNTS.account_number%TYPE,
    v_resultset               OUT SYS_REFCURSOR
  );*/
 --================================================================================================
  PROCEDURE tds_daily_rpt (v_resultset  OUT sys_refcursor);
 --================================================================================================
  PROCEDURE tds_detail_report (
    v_search_str             IN VARCHAR2,
    v_result_set             OUT SYS_REFCURSOR
  );
 --================================================================================================
  PROCEDURE daily_transfer_summary_report(
   v_search_str             IN VARCHAR2,
   v_result_set             OUT SYS_REFCURSOR
  );
 --================================================================================================
  PROCEDURE monthly_remit_sumary_report(
   v_search_str             IN VARCHAR2,
   v_result_set             OUT SYS_REFCURSOR
  );
--================================================================================================
  PROCEDURE annexure_i26q_report(
   v_search_str             IN VARCHAR2,
   v_result_set             OUT SYS_REFCURSOR
  );
 --================================================================================================
  PROCEDURE challan_details_q_report(
   v_search_str             IN VARCHAR2,
   v_result_set             OUT SYS_REFCURSOR
  );
  --================================================================================================
  PROCEDURE print_cheque_info(
    v_batch_number       IN  tpa_claims_check.batch_number%TYPE,
    v_resultset          OUT SYS_REFCURSOR
  );
--================================================================================================
PROCEDURE send_mediclaim_computation(v_where_clause VARCHAR2,v_added_by number);
--================================================================================================
   PROCEDURE debit_note_for_ibm_daksh (where_clause IN VARCHAR2,
  V_MR_DN_FORMAT           OUT SYS_REFCURSOR);
--========================================================================================================
FUNCTION GET_ICD_CODE (v_claim_seq_id TPA_CLAIMS_PAYMENT.claim_seq_id%TYPE)
  RETURN VARCHAR2;
--========================================================================================================

FUNCTION leap_year_indicator (p_date IN VARCHAR2 DEFAULT TO_CHAR(SYSDATE, 'YYYY'))
  RETURN VARCHAR2;
--========================================================================================================
PROCEDURE REVENUE_INVOICE_REPORT (p_date IN VARCHAR2,
                                  p_resultset OUT SYS_REFCURSOR
                                 );
--=========================================================================================================                     
PROCEDURE generate_crncy_exchng_rpt(where_clause              IN  VARCHAR2,
                                    result_set                OUT SYS_REFCURSOR
                                    ); 
--=======================================================================================================
PROCEDURE select_crncy_exchng_dtl  (v_upld_date                          IN DATE,
                                    v_country_id                         IN NUMBER,
                                    v_sort_var                           IN  VARCHAR2,
                                    v_sort_order                         IN  VARCHAR2 ,
                                    v_start_num                          IN  NUMBER ,
                                    v_end_num                            IN  NUMBER ,
                                    result_set                           OUT SYS_REFCURSOR
                                    );
--========================================================================================================  
PROCEDURE Claims_setteled_report (where_clause              IN  VARCHAR2,
                                    result_set                OUT SYS_REFCURSOR
                                  ); 
--==========================================================================================================
PROCEDURE Claims_inprogress_report(where_clause              IN  VARCHAR2,
                                    result_set                OUT SYS_REFCURSOR
                                    ); 
--===========================================================================================================
PROCEDURE Claims_Outstanding_report(where_clause              IN  VARCHAR2,
                                    result_set                OUT SYS_REFCURSOR
                                    ); 
--============================================================================================================
PROCEDURE claims_routine_report(
     where_clause              IN  VARCHAR2,
     v_result_set             OUT SYS_REFCURSOR);
--================================================Audit Claim Report==================================================  
PROCEDURE audit_claim_report(v_audit_status         IN VARCHAR2,
                             v_provider_name        IN VARCHAR2,
                             v_batch_no             IN VARCHAR2,        
                             v_claim_number         IN VARCHAR2,
                             v_settlement_number    IN VARCHAR2,
                             v_member_name          IN VARCHAR2,
                             v_enrollment_id        IN VARCHAR2,
                             v_clm_status           IN VARCHAR2,
                             v_policy_number        IN VARCHAR2,
                             v_clm_recv_from_dt     IN VARCHAR2,
                             v_clm_recv_to_dt       IN VARCHAR2,
                             v_clm_proc_from_dt     IN VARCHAR2,
                             v_clm_proc_to_dt       IN VARCHAR2,
                             v_claim_type           IN VARCHAR2,
                             v_treatment_from_dt    IN VARCHAR2,
                             v_treatment_to_dt      IN VARCHAR2,
                             v_result_set           OUT SYS_REFCURSOR
                            );
--================================================Audit Preapproval Report==================================================  
PROCEDURE audit_preauth_report(v_provider_name        IN VARCHAR2,
                               v_preapproval_no       IN VARCHAR2,
                               v_authorization_no     IN VARCHAR2,
                               v_member_name          IN VARCHAR2,
                               v_enrollment_id        IN VARCHAR2,
                               v_pat_status           IN VARCHAR2,
                               v_policy_number        IN VARCHAR2,
                               v_pat_recv_from_dt     IN VARCHAR2,
                               v_pat_recv_to_dt       IN VARCHAR2,
                               v_pat_proc_from_dt     IN VARCHAR2,
                               v_pat_proc_to_dt       IN VARCHAR2,
                               v_treatment_from_dt    IN VARCHAR2,
                               v_treatment_to_dt      IN VARCHAR2,
                               v_result_set           OUT SYS_REFCURSOR
                              );    
--============================================================================================================                            
--========================================================================
 PROCEDURE clm_pending_summary_report(p_search_base         IN   VARCHAR2,
                                      result_network        OUT SYS_REFCURSOR,
                                      result_member         OUT SYS_REFCURSOR,
                                      result_partner        OUT SYS_REFCURSOR
                                     );
--==================================================================================================                                  
END batch_report_pkg;

/

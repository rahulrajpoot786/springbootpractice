--------------------------------------------------------
--  DDL for Package Body CLAIM_PKG
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "VENUBABU"."CLAIM_PKG" 
is
--===============================================================================
--===============================================================================
v_dependent_count               NUMBER(20)  := 0;
v_error_message                 Error_Log.Error_Message%TYPE;
v_upload_error_message          VARCHAR2(32767):= NULL; -- Global Variable for Collect Error
v_added_by                      NUMBER;
v_clm_seq_id                    NUMBER;
--===============================================================================
PROCEDURE select_claim_details (
     v_claim_seq_id                              IN  clm_authorization_details.claim_seq_id%type,
     v_clm_result_set                            OUT SYS_REFCURSOR ,
     v_diag_result_set                           OUT SYS_REFCURSOR ,
     v_activity_result_set                       OUT SYS_REFCURSOR ,
     v_observ_result_set                         OUT SYS_REFCURSOR ,
     v_shortfall_details                         OUT SYS_REFCURSOR ,
	   v_pat_count                                 OUT SYS_REFCURSOR ,
     v_clm_count                                 OUT SYS_REFCURSOR )

IS

-- CURSOR FOR TAKING TOT_DISALLOWED VALUES FROM ACTIVITY TABLE
cursor cal_tot_disal_amt_cur IS
   select sum(p.disallowed_amount) as disallowed_amount
   from pat_activity_details p
   where p.claim_seq_id = v_claim_seq_id;
   
 v_cur_dis_amt cal_tot_disal_amt_cur%rowtype;
 
CURSOR clinician_cur IS
   SELECT hd.hosp_seq_id,ad.clinician_id from  clm_authorization_details ad
   join clm_hospital_details hd on (hd.claim_seq_id=ad.claim_seq_id)
   WHERE ad.claim_seq_id=v_claim_seq_id;
   
   cln_rec    clinician_cur%rowtype;

CURSOR clinician_count_cur(v_clinician_id varchar2,v_hosp_seq_id number )IS
   SELECT count(1) FROM app.tpa_hosp_professionals hp
   WHERE hp.professional_id=v_clinician_id AND hp.hosp_seq_id=v_hosp_seq_id;
   
   v_count  number(10);
   
 CURSOR clm_cur IS
    SELECT pad.date_of_hospitalization,pad.member_seq_id,hd.hosp_seq_id,b.submission_type_id,pad.tpa_enrollment_id  ---need alkoot id for count in claim screen
      FROM clm_authorization_details pad JOIN clm_hospital_details hd on (pad.claim_seq_id=hd.claim_seq_id)
      JOIN clm_batch_upload_details b ON (pad.clm_batch_seq_id=b.clm_batch_seq_id)
     WHERE pad.claim_seq_id = v_claim_seq_id ;
  ----------------- 
 cursor unit_cur is 
     select bb.CLAIM_SEQ_ID,aa.GRANULAR_UNIT,bb.QUANTITY,bb.UNIT_TYPE,bb.POSOLOGY_DURATION 
      from pat_activity_details bb 
      join tpa_pharmacy_master_details aa on aa.ACTIVITY_CODE =bb.code 
     where bb.CLAIM_SEQ_ID=v_claim_seq_id; 
 -----------------------------     
 clm_rec  clm_cur%rowtype;
CURSOR clm_dup_cur(v_member_seq_id pat_authorization_details.member_seq_id%type) IS
    SELECT pad.date_of_hospitalization
      FROM clm_authorization_details pad
     WHERE pad.member_seq_id = v_member_seq_id
       AND pad.claim_seq_id != nvl(v_claim_seq_id, 0)
     ORDER BY pad.date_of_hospitalization desc;
     
 v_alert  varchar2(1000):=null; 
 
CURSOR provider_networks(v_hosp_seq_id  tpa_hosp_info.hosp_seq_id%type) is 
select to_char(wm_concat(case when n.network_yn='Y' then n.network_type end )) as eligible_networks from tpa_hosp_info i join app.tpa_hosp_network n on (i.hosp_seq_id=n.hosp_seq_id)
where i.hosp_seq_id = v_hosp_seq_id;

 CURSOR prev_appr_cur IS  SELECT COUNT(1) FROM ( SELECT a.claim_seq_id, a.parent_claim_seq_id,a.clm_status_type_id
      FROM clm_authorization_details a
      START WITH a.claim_seq_id = v_claim_seq_id CONNECT BY a.claim_seq_id = PRIOR a.parent_claim_seq_id ) aa
      WHERE aa.CLM_STATUS_TYPE_ID = 'APR' AND aa.claim_seq_id != v_claim_seq_id ;

 
 CURSOR srtfll_cur IS
    SELECT sd.srtfll_status_general_type_id
    FROM SHORTFALL_DETAILS sd
    WHERE sd.shortfall_seq_id = (SELECT MAX(S.SHORTFALL_SEQ_ID)
                                 FROM SHORTFALL_DETAILS s
                                 WHERE S.CLAIM_SEQ_ID = v_claim_seq_id
                                )
    AND sd.CLAIM_SEQ_ID = v_claim_seq_id;

v_shrtfll_status        VARCHAR2(10);   
pro_network  provider_networks%rowtype;
v_appr_count                        NUMBER(10);

CURSOR pat_inv_status IS
   SELECT inv_status FROM
    (SELECT inv_status FROM app.tpa_fraud_inv_details WHERE claim_seq_id = v_claim_seq_id order by inv_seq_id desc)
   WHERE rownum =1;
   
 CURSOR Parent_Claim_Number IS
  select cc.claim_number
    from clm_authorization_details cc
    where cc.claim_seq_id in
    (select cad.claim_seq_id
    from clm_authorization_details cad 
    start with cad.claim_seq_id=v_claim_seq_id
    connect by cad.claim_seq_id=prior cad.parent_claim_seq_id) and cc.parent_claim_seq_id is null;
    
 CURSOR GET_RESUBMISSION_COUNT (v_clm_num  NUMBER)IS  
  SELECT * FROM (SELECT LEVEL AS LV
        FROM CLM_AUTHORIZATION_DETAILS CAD 
         START WITH CAD.CLAIM_SEQ_ID=v_clm_num
        CONNECT BY CAD.CLAIM_SEQ_ID=PRIOR CAD.PARENT_CLAIM_SEQ_ID
         ORDER BY LEVEL DESC);    
    
v_inv_status tpa_fraud_inv_details.inv_status%TYPE; 
v_msg                               VARCHAR2(1000);
v_tot_units                         number(10);
v_parent_claim_no                   VARCHAR2(30);
v_submission_count                  NUMBER(3);

BEGIN
  
  OPEN srtfll_cur;
  FETCH srtfll_cur INTO v_shrtfll_status;
  CLOSE srtfll_cur;
  
  open clinician_cur;
  fetch clinician_cur into cln_rec;
  close clinician_cur;
  
  open clinician_count_cur(cln_rec.clinician_id,cln_rec.hosp_seq_id);
  fetch clinician_count_cur into v_count;
  close clinician_count_cur;
  
  open clm_cur;
  fetch clm_cur into clm_rec;
  close clm_cur;
  
  OPEN prev_appr_cur;
  FETCH prev_appr_cur INTO v_appr_count;
  CLOSE prev_appr_cur;

  OPEN Parent_Claim_Number;
    FETCH Parent_Claim_Number INTO v_parent_claim_no;
      CLOSE Parent_Claim_Number;
      
   OPEN GET_RESUBMISSION_COUNT(v_claim_seq_id);
     FETCH GET_RESUBMISSION_COUNT into v_submission_count;
       CLOSE GET_RESUBMISSION_COUNT;   
  
  /*FOR rec IN clm_dup_cur(clm_rec.member_seq_id) LOOP
    IF trunc(rec.date_of_hospitalization) = trunc(clm_rec.date_of_hospitalization)  THEN
      v_alert:='Duplicate Claim ';
    END IF;
  END LOOP;*/ --commented as per Dr.Yasmin
 
  open provider_networks(clm_rec.hosp_seq_id);
  fetch provider_networks into pro_network;
  close provider_networks;
 

 OPEN cal_tot_disal_amt_cur;
 FETCH cal_tot_disal_amt_cur INTO v_cur_dis_amt;
 CLOSE cal_tot_disal_amt_cur;
 

 OPEN cal_tot_disal_amt_cur;
 FETCH cal_tot_disal_amt_cur INTO v_cur_dis_amt;
 CLOSE cal_tot_disal_amt_cur;
 
  open pat_inv_status;
  fetch pat_inv_status into v_inv_status;
  close pat_inv_status;
 

  v_msg:=NULL;           
for unit_rec in unit_cur loop


if unit_rec.UNIT_TYPE='LOSE' THEN
v_tot_units:= unit_rec.QUANTITY;
elsif unit_rec.UNIT_TYPE='PCKG' THEN
v_tot_units:=unit_rec.GRANULAR_UNIT*unit_rec.QUANTITY;
end if;
if v_tot_units>=270 then
v_msg:=case when v_msg IS NOT NULL then case when v_msg like '%Number of quantities exceeds limit%' then v_msg else v_msg||';'||'Number of quantities exceeds limit' end else 'Number of quantities exceeds limit' end;
end if;

if unit_rec.POSOLOGY_DURATION>=60 then

v_msg:=case when v_msg IS NOT NULL then case when v_msg like '%Duration of medication exceeds limit%' then v_msg else v_msg||';'||'Duration of medication exceeds limit' end else 'Duration of medication exceeds limit' end;
end if;
end loop;

 OPEN v_clm_result_set FOR 
  select pad.claim_seq_id,
          pad.clm_batch_seq_id,
          pad.pat_auth_seq_id,
          pad.parent_claim_seq_id,
          pbud.batch_no,
          case when v_alert is not null then v_alert else null end  as clm_dup,
          pad.invoice_number,
          pbud.received_date as clm_received_date,
          pbud.source_type_id,
          case when nvl(v_count,0)=0 then 'Clinician is not exist under this provider, please check with network department.' end as clinician_status,
          pad.date_of_hospitalization,
          pad.date_of_discharge,
          pad.claim_sub_type,
          pad.member_seq_id,
          nvl(tepm.tpa_enrollment_id,pad.tpa_enrollment_id) as tpa_enrollment_id,
          pad.claim_number,
          ad.claim_number as parent_claim_number,
          pad.settlement_number,
          tepm.mem_name ||' '|| tepm.mem_last_name||' '|| tepm.family_name as mem_name,  ----
          pad.mem_age,
          pad.ins_seq_id,
          hd.hosp_seq_id,
          pad.policy_seq_id,
          case when ep.policy_number is not null then (ep.policy_number||'('||ip.product_cat_type_id||')') end as policy_number,
          case when ep.enrol_type_id='COR' then case when gr.group_id is not null then  (gr.group_name||'('||gr.group_id||')') end else null end as  corp_name,
          pbud.tpa_office_aeq_id,
          ep.enrol_type_id,
          pad.emirate_id,
          pad.encounter_type_id,
          pad.encounter_start_type,
          pad.encounter_end_type,
          pad.encounter_facility_id,
          pad.maternity_allowed_amt,
          pad.tot_gross_amount,
          pad.tot_discount_amount,
          pad.tot_disc_gross_amount,
          pad.tot_patient_share_amount,
          case when (nvl(pad.ucr_flag,'N')='N' and nvl(pad.ri_copar_flag,'N')='N') then 
                   CASE WHEN SIGN (pad.tot_disc_gross_amount-nvl(pad.tot_patient_share_amount,0)) = -1 THEN 0
                        ELSE (pad.tot_disc_gross_amount-(nvl(pad.tot_patient_share_amount,0)+nvl(pad.manual_disallow_amt,0))) END 
               else pad.tot_net_amount end as tot_net_amount,
          --pad.tot_net_amount,--========
          case when (nvl(pad.ucr_flag,'N')='N' and nvl(pad.ri_copar_flag,'N')='N') then
             case when nvl(pad.completed_yn,'N')='Y'then 
                     CASE WHEN SIGN ((pad.tot_disc_gross_amount-nvl(pad.tot_patient_share_amount,0))-nvl(pad.final_app_amount,0)) = -1 THEN 0
                          ELSE (pad.tot_disc_gross_amount-nvl(pad.tot_patient_share_amount,0))-nvl(pad.final_app_amount,0) END
                  else CASE WHEN SIGN((pad.tot_disc_gross_amount-nvl(pad.tot_patient_share_amount,0))-nvl(pad.tot_approved_amount,0)) = -1 THEN 0
                            ELSE (pad.tot_disc_gross_amount-nvl(pad.tot_patient_share_amount,0))-nvl(pad.tot_approved_amount,0) END
                  end 
             else v_cur_dis_amt.disallowed_amount   end as dis_allowed_amount,
          --v_cur_dis_amt.disallowed_amount AS dis_allowed_amount,
          pad.tot_allowed_amount,
          nvl(pad.tot_approved_amount,0) as total_app_amount,
          nvl(pad.final_app_amount,0) as final_app_amount,
          pad.currency_type,
          /*case when pad.tot_approved_amount>0 then 'APR'
               when pad.tot_approved_amount<1  then 'REJ'
                
            ELSE pad.clm_status_type_id END AS clm_status_type_id,*/
          pad.clm_status_type_id AS clm_status_type_id,
          pad.maternity_yn,
          pad.manual_process_req_yn,
          pad.denial_reason,
          pad.remarks,
          pad.completed_yn,
          pad.tot_approved_amount,
          pad.clinician_id,
		   pad.dur_ailment,
          pad.duration_flag,
          case when pad.member_seq_id is null then 'Patient is not a covered member' end as mem_alert,
         case when pbud.network_yn='Y' then  nvl(thi.hosp_name,hd.hosp_name) else hd.hosp_name end as hosp_name ,
         tha.address_1 || ' ' || tha.address_2 || ' ' || tha.address_3 as hosp_address,
         case when hd.hosp_seq_id is not null then nvl(thi.hosp_licenc_numb,hd.provider_id)||'('||thi.primary_network||')' else nvl(thi.hosp_licenc_numb,hd.provider_id) end as provider_id,
         thi.hosp_licenc_numb as hosp_id,
         thi.primary_network,
         tii.ins_comp_name,
         tii.ins_comp_code_number as payer_id,
         account_info_pkg.get_gen_desc(tepm.gender_general_type_id,'G') AS gender,
         /*case when pbud.network_yn='Y' then thp.contact_name||decode(thp.contact_name,null,thp.contact_name,'('||thp.professional_id||')') else hd.clinician_name end as clinician_name,*/
         nvl(case when pbud.network_yn='Y' then thp.contact_name||decode(thp.contact_name,null,thp.contact_name,'('||thp.professional_id||')') else hd.clinician_name end,hd.clinician_name) as clinician_name,
         pad.presenting_complaints,
         pad.medical_opinion_remarks,
         pad.system_of_medicine_type_id,
         pad.accident_related_type_id,
         pad.priority_general_type_id,
         pbud.network_yn as network_yn,
         pad.requested_amount,
         hd.city_type_id,
         tcc.city_description,
         sc.state_name,
         cc.country_name,
         hd.state_type_id,
         hd.country_type_id,
         hd.address_1 as provider_address,
         hd.pin_code,
         /*NVL(pbud.Benefit_Type,*/pad.benifit_type as benifit_types,
         pad.gravida,
         pad.para,
         pad.live,
         pad.abortion,
         pad.currency_type,
         apad.auth_number as auth_number,
         apad.pat_received_date,
         apad.tot_approved_amount as pat_approved_amount,
         apad.pre_auth_number as Pre_Auth_Number,
         'Y' as fresh_yn,
         pbud.clm_type_gen_type_id as claim_type,
         case when nvl(pad.parent_claim_seq_id,0)!=0  then 'N' ELSE 'Y' END AS fresh_ynm,
         ep.effective_from_date as policy_start_date,
         ep.effective_to_date as policy_end_date,
         nc.description as nationality,
         --nvl(pad.ava_sum_insured,(nvl(eb.sum_insured,0) - nvl(eb.utilised_sum_insured,0))) AS ava_sum_insured,
         CASE WHEN pad.completed_yn = 'Y' THEN nvl(eb.sum_insured,0) - nvl(eb.utilised_sum_insured,0)
              WHEN ( clm_rec.submission_type_id != 'DTR' OR clm_rec.submission_type_id  = 'DTR' AND v_appr_count = 0 )
                   AND eb.sum_insured >= (nvl(eb.sum_insured,0) - (nvl(eb.utilised_sum_insured,0) + NVL( DECODE(pad.final_app_amount,0,NULL,pad.final_app_amount),NVL(pad.pat_approved_amount,0)))) 
                   THEN  (nvl(eb.sum_insured,0) - (nvl(eb.utilised_sum_insured,0) + NVL( DECODE(pad.final_app_amount,0,NULL,pad.final_app_amount), NVL(pad.pat_approved_amount,0))))
             WHEN ( clm_rec.submission_type_id != 'DTR' OR clm_rec.submission_type_id  = 'DTR' AND v_appr_count = 0 )
             AND eb.sum_insured < (nvl(eb.sum_insured,0) - (nvl(eb.utilised_sum_insured,0) + NVL( DECODE(pad.final_app_amount,0,NULL,pad.final_app_amount),NVL(pad.pat_approved_amount,0)))) THEN eb.sum_insured
             WHEN clm_rec.submission_type_id  = 'DTR' AND eb.sum_insured >= ( nvl(eb.sum_insured,0) - (nvl(eb.utilised_sum_insured,0) + NVL(pad.final_app_amount,0))) THEN nvl(eb.sum_insured,0) - (nvl(eb.utilised_sum_insured,0) + NVL(pad.final_app_amount,0))
             WHEN clm_rec.submission_type_id  = 'DTR' AND eb.sum_insured < ( nvl(eb.sum_insured,0) - (nvl(eb.utilised_sum_insured,0) + NVL(pad.final_app_amount,0))) THEN eb.sum_insured
             END  AS ava_sum_insured,
         eb.sum_insured,
         pbud.submission_type_id,
         pbud.claimfrom_gentype_id,
         pad.re_submission_remarks,
         pad.final_remarks,
         pad.override_remarks,
         ip.product_name,
         uc.contact_name as assigned_to,
         pro_network.eligible_networks as eligible_networks,

         pad.ucr_flag ucr_flag,
         pad.ri_copar_flag ri_copar_flag,
         to_char(tepm.date_of_inception, 'DD/MM/YYYY') as clm_mem_insp_date, --Insure Date
         to_char(tepm.date_of_exit,'DD/MM/YYYY') as clm_mem_exit_date,
         case when nvl(tepm.vip_yn,'N')='N' then 'No' else 'Yes' end as vip_yn,
         tii.payer_authority ,-- for payer authority display
       
         pad.takaful_ref_no,
         case when tii.ins_comp_code_number = 'INS022' then
           'Y'
         else
           'N'
         end as ins_flag,
         
         nvl(pad.fnl_amt_currency_type,cur.currency_id) as fnl_amt_currency_type, ----
         
         thi.remarks as PROVIDER_SPECIFIC_REMARKS,
         ----clinician warning---- 
         case when nvl(v_count,0)=0 and pbud.network_yn = 'Y' and hd.hosp_seq_id is not null and pad.tpa_enrollment_id is not null and nvl(pad.completed_yn,'N') = 'N'then 
             'Claims moved to In-Progress state. Please enter an empanelled Clinician Detail to complete the Claims process.' 
         end as clinician_warning,
    ---------------------------------------------------------------   
      pad.lmp_date,
      pad.conception_type,
	    pad.dur_ailment as dur_ailment,
      pad.duration_flag as duration_flag,
      CASE WHEN pad.benifit_type IN ('MTI', 'OMTI', 'IMTI') THEN authorization_pkg.get_nat_concp_valid_msg(pad.member_seq_id,'CLM',pad.conception_type)
           ELSE null END as mat_alert_msg,
         nvl(pad.REQ_AMT_CURRENCY_TYPE,cur.currency_id) AS REQ_AMT_CURRENCY_TYPE,
         pad.CONVERTED_AMOUNT,
         pad.CONVERTED_AMOUNT_CURRENCY_TYPE,
         pad.CONVERSION_RATE,
         nvl(pad.REQ_AMT_CURRENCY_TYPE,cur.currency_id) as REQ_AMT_CURRENCY_TYPE1,
         pad.converted_final_approved_amt,
         pad.oth_tpa_ref_no,
         NVL(pbud.process_type,'RGL') AS process_type,
         pad.pymnt_to_type_id,
         pad.ptnr_seq_id,
         pbud.partner_name,
         cc.country_id,
		 od.ORTHO_SEQ_ID,
	   pad.treatment_type as treatment_type,
     od.SOURCE_SEQ_ID,
     od.DENTO_CLASS_I,
     od.DENTO_CLASS_II,
     od.DENTO_CLASS_II_TEXT,
     od.DENTO_CLASS_III,
     od.DENTO_CLASS_III_TEXT,
     od.SKELE_CLASS_I,
     od.SKELE_CLASS_II,
     od.SKELE_CLASS_III,
     od.OVERJET_MM,
     od.REV_OVERJET_MM,
     od.REV_OVERJET_YN,
     od.CROSSBITE_ANT,
     od.CROSSBITE_POST,
     od.CROSSBITE_BETW,
     od.OPENBIT_ANT,
     od.OPENBIT_POST,
     od.OPENBIT_LATE,
     od.CONT_POINT_DISP,
     od.OVERBIT_DEEP as OVERBITE,
     od.OVERBIT_PATA,
     od.OVERBIT_GING,
     od.HYPO_QUAD1,
     od.HYPO_QUAD2,
     od.HYPO_QUAD3,
     od.HYPO_QUAD4,
     od.OTHERS_IMPEDED,
     od.OTHERS_IMPACT,
     od.OTHERS_SUBMERG,
     od.OTHERS_SUPERNUM,
     od.OTHERS_RETAINE,
     od.OTHERS_ECTOPIC,
     od.OTHERS_CRANIO,
     od.AC_MARKS,
     od.Iotn_Remark as IOTN,
     pad.delvry_mod_type,
     od.crossbite_ant_mm,
     od.crossbite_prst_mm,
     od.crossbite_betw_mm,
     od.cont_point_disp_mm,
         apad.req_amt_currency_type as pat_req_currency_typ,
         pad.delvry_mod_type,
     pad.event_no as event_no,
     apad.req_amt_currency_type as pat_req_currency_typ,
         lp.prod_policy_seq_id, ---newly added for policy tob
     pad.internal_remarks,
     CASE WHEN pad.clm_status_type_id IN ('APR','REJ','PCN','PCO') THEN  
                   to_char(pad.completed_date,'dd/mm/yyyy hh:mi Am') END as decision_date,
  CASE WHEN pad.clm_status_type_id  IN ('APR','REJ','PCN','PCO') THEN 
           nvl((select contact_name from app.tpa_user_contacts c where c.contact_seq_id= pad.processed_by),uc.contact_name)
            end as processed_by,
            pad.embassy_seq_id as payment_to_emb,
            pad.pay_amt_in_usd as usd_amount,
            apad.req_amt_currency_type as pat_inc_curr,
            apad.converted_amount_currency_type as Pat_req_curr,
            apad.converted_final_approved_amt as pat_inc_amnt,
            case when pad.status_code_id is not null and nvl(pad.suspect_veri_check,'N')='N' then 'Y' else 'N' end as fraud_yn,
            case when pad.clm_status_type_id in( 'APR','PCO','PCN','REJ') then 'Y' else 'N' end clm_complete,
           NVL(pad.suspect_veri_check,'N') AS suspect_veri_check,
      pad.iban_number,
      pad.bank_name,
      pad.pay_made_for as payment_made_for,
    pad.common_file_number AS common_file_no,
      NVL(PAD.MAT_COMPLCTON_YN,'N') AS MAT_COMPLCTON_YN,
           nvl(uc.vip_clm_rej,'N') vip_clm_rej,
           au.assigned_to_user,
           UC.TPA_OFFICE_SEQ_ID,
           PAD.CLM_STATUS_TYPE_ID||'-'||NVL(v_shrtfll_status, CASE WHEN NVL(PAD.PARENT_CLAIM_SEQ_ID, 0) > 0 THEN 'ENH' END) AS IN_PROGESS_STATUS,
     CASE WHEN (SYSDATE-pad.clm_received_date)BETWEEN  fas.fst_from_days AND fas.fst_to_days AND pad.claim_type='CNH' 
       THEN 'Y' ELSE 'N' END AS Fast_Track           
           ,pad.pay_amt_in_euro
           ,pad.pay_amt_in_gbp 
           ,pad.pay_amt_in_euro
           ,pad.pay_amt_in_gbp,
      CASE WHEN v_inv_status = 'FD' and  pad.status_code_id = 'SUSP' THEN 'Y' ELSE 'N' END
      AS fraud_det_yn,
      v_msg as alt_msg ,NVL(PAD.AUDIT_STATUS, 'NCH') AS AUDIT_STATUS,
     PAD.AUDIT_REMARKS AS CLM_AUDIT_REMARKS,
     CA.AUDIT_REMARKS,
      (select a.relship_description from app.tpa_relationship_code a where a.relship_type_id = tepm.relship_type_id) relationship_desc,                 
      case when pad.benifit_type in('MTI','IMTI','OMTI') then case when  tepm.RELSHIP_TYPE_ID IN('NSF', 'YSP') THEN 'Y' ELSE 'N' END else null end AS COLOUR_YN ,
      tepm.member_remarks,
      v_parent_claim_no as Parent_Claim_No,
      (v_submission_count -1) AS Submission_Count                                                             
                
                                                                    
    from clm_authorization_details pad
    LEFT JOIN (SELECT MAX(CAD.CLM_AUDIT_SEQ_ID) AS CLM_AUDIT_SEQ_ID, CAD.CLM_SEQ_ID, CAD.AUDIT_DATE
                           FROM APP.CLM_AUDIT_DATA CAD
                           WHERE CAD.AUDIT_DATE = (SELECT MAX(CAD1.AUDIT_DATE)
                                                   FROM APP.CLM_AUDIT_DATA CAD1
                                                   WHERE CAD.CLM_SEQ_ID = CAD1.CLM_SEQ_ID
                                                  )
                           GROUP BY CAD.CLM_SEQ_ID, CAD.AUDIT_DATE
                          ) CAD ON CAD.CLM_SEQ_ID = PAD.CLAIM_SEQ_ID
    LEFT JOIN APP.CLM_AUDIT_DATA CA ON CA.CLM_AUDIT_SEQ_ID = CAD.CLM_AUDIT_SEQ_ID
    left join ORTHODONTIC_DETAILS_TAB od on (od.source_seq_id = pad.claim_seq_id)
    left outer join clm_batch_upload_details pbud   on (pad.clm_batch_seq_id = pbud.clm_batch_seq_id)
    left outer join clm_authorization_details ad on (ad.claim_seq_id=pad.parent_claim_seq_id)
    left outer join clm_hospital_details hd         on (hd.claim_seq_id=pad.claim_seq_id)
    left outer join tpa_enr_policy ep               on (ep.policy_seq_id=pad.policy_seq_id)
    left outer join tpa_ins_product ip              on (ip.product_seq_id=ep.product_seq_id)
    left outer join tpa_group_registration gr       on (gr.group_reg_seq_id=ep.group_reg_seq_id)
    left outer join tpa_enr_policy_member tepm      on (pad.member_seq_id=tepm.member_seq_id)
    left outer join tpa_enr_policy_group pg         on (pg.policy_group_seq_id=tepm.policy_group_seq_id)
    left outer join tpa_hosp_info thi               on (hd.hosp_seq_id = thi.hosp_seq_id)
    left outer join tpa_hosp_address tha            on (thi.hosp_seq_id = tha.hosp_seq_id)
    left outer join tpa_ins_info tii                on (pad.ins_seq_id = tii.ins_seq_id)
    left outer join tpa_hosp_professionals thp      on (pad.clinician_id=thp.professional_id and thp.hosp_seq_id=hd.hosp_seq_id)
   left outer join  tpa_country_code cc             on (cc.country_id=hd.country_type_id)
    left outer join tpa_state_code sc               on (sc.state_type_id=hd.state_type_id)
    left outer join tpa_city_code tcc               on (tcc.city_type_id=hd.city_type_id)
    left outer join tpa_nationalities_code nc       on (nc.nationality_id=tepm.nationality_id)
    LEFT OUTER JOIN tpa_enr_balance eb              on (pg.policy_group_seq_id = eb.policy_group_seq_id)
    LEFT OUTER JOIN pat_authorization_details apad  on (apad.pat_auth_seq_id=pad.pat_auth_seq_id)
	LEFT OUTER JOIN assign_users au                 on  (au.assign_users_seq_id=pad.assign_user_seq_id)
    left outer join tpa_user_contacts uc            on (uc.contact_seq_id=au.assigned_to_user)
    left outer join tpa_user_contacts uca           on (uca.contact_seq_id=pad.updated_by)
    left join tpa_currency_code cur on(tha.country_id = cur.country_id )
	left outer join tpa_ins_prod_policy lp  on(lp.policy_seq_id = pad.policy_seq_id)   ---newly added for policy tob
    left outer join shortfall_details sd on (pad.claim_seq_id=sd.claim_seq_id)
    left outer join app.tpa_fasttract_disc_details fas on (fas.hosp_seq_id=hd.hosp_seq_id)
    where pad.claim_seq_id = v_claim_seq_id
    and  (tepm.mem_general_type_id != 'PFL' AND tepm.member_seq_id = eb.member_seq_id OR eb.member_seq_id IS NULL OR tepm.member_seq_id IS NULL);

 OPEN v_diag_result_set FOR 
       select dd.diag_seq_id,
             dd.claim_seq_id,
             tic.icd_code as diagnosys_code,
             dd.primary_ailment_yn,
             tic.icd10_seq_id as icd_code_seq_id,
             tic.short_desc as icd_description
        from diagnosys_details dd
        left outer join tpa_icd10_master_details tic on (dd.icd_code_seq_id=tic.icd10_seq_id)
       where dd.claim_seq_id =v_claim_seq_id
   order by dd.diag_seq_id;
  
  OPEN v_activity_result_set FOR 
  
    select ad.activity_dtl_seq_id,
       ad.claim_seq_id,
       ad.activity_id,
       ad.start_date,
       ad.s_no,
       ad.activity_type,
       ad.code as code,
       ad.quantity,
       ad.copay_amount as p_copay_amt,
       case when (nvl(clm.ucr_flag,'N')='N' and nvl(clm.ri_copar_flag,'N')='N') then  
         nvl(ad.disc_gross_amount,0)-(nvl(patient_share_amount,0)+nvl(ad.out_of_pocket_amount,0)) 
       else 
         ad.net_amount end as net_amount,
       --ad.net_amount as NET_AMOUNT,
       --ad.disallowed_amount as dis_allowed_amount,
       case when (nvl(clm.ucr_flag,'N')='N' and nvl(clm.ri_copar_flag,'N')='N') then 
                 ((nvl(ad.disc_gross_amount,0)-nvl(ad.patient_share_amount,0))-nvl(ad.approved_amount,0)) 
              else 
                nvl(ad.disallowed_amount,0) end as dis_allowed_amount,
       ad.clinician_id,
       ad.allow_yn,
       case when ad.remarks like ';%' then substr(ad.remarks,2) else ad.remarks end as remarks,
       nvl(tamd.activity_description,md.activity_description) as activity_description,
       ad.activity_seq_id,
       account_info_pkg.get_gen_desc(ad.modifier,'G') AS modifier,
       case when ad.unit_type='PCKG' THEN 'Package'
            when ad.unit_type='LOSE' THEN 'Loose' 
            when ad.unit_type='NA' THEN 'NA' else null end as unit_type,
       ad.gross_amount,
       ad.discount_amount,
       ad.disc_gross_amount,
       clm.ucr_flag,
       ad.patient_share_amount as patient_share_amount,
       ad.copay_amount as copay_amount,
       --(case when ad.denial_code='error' then ad.denial_desc else tdc.denial_description end) as denial_desc,
       case when ad.denial_code like ';%' then replace(substr(ad.denial_code,2),'-','ALK') else replace(ad.denial_code,'-','ALK-') end as denial_code,
       case when ad.denial_desc like ';%' then substr(ad.denial_desc,2) else ad.denial_desc end as denial_desc,
       ad.allowed_amount,
       ad.approved_amount approved_amt,
       ad.out_of_pocket_amount,
       ad.co_ins_amount,
       ad.approvd_quantity  as approved_quantity,
       ad.unit_price,
       ad.override_yn,
       ad.override_remarks,
       case when ad.provider_net_amount>=0 then
         ad.provider_net_amount
       else
         ad.disc_gross_amount
       end as provider_net_amount,
       ad.copay_amount,
       ad.benifit_deductible,
       ad.copay_perc,
       ad.ucr,
       ad.copay_deduct_flag,
       case when ad.prior_authid is not null then ad.prior_authid
         else
           '-'
       end as preauthno,
       clm.claim_seq_id,
       d.tooth_no_required as tooth_req_yn,/*
	   case when ad.activity_type_id='DRG' then
       case when (select count(1) from tpa_pharmacy_master_details where activity_code=ad.code)>0 then 'N' else 'Y' end end 
       as*/ null as  new_pharmacy_yn,
       nvl(ad.internal_desc, tamd.short_description) as internal_desc,
       ad.internal_code  --- added in internal cr
       
      from pat_activity_details ad
      left join clm_authorization_details clm          on (clm.claim_seq_id = ad.claim_seq_id)
      left outer join tpa_activity_master_details tamd on (ad.code=tamd.activity_code)
      left outer join tpa_pharmacy_master_details md on (md.activity_code =ad.code and ad.start_date between md.start_date and md.end_date)
      left join dental_rule_tab d                 on (d.cdt_code = ad.code)
      --left outer join tpa_denial_codes tdc on (ad.denial_code=tdc.denial_code)
     where ad.claim_seq_id = v_claim_seq_id
     order by ad.activity_dtl_seq_id;
       
  OPEN v_observ_result_set FOR 
       select od.observation_seq_id,
       od.activity_dtl_seq_id,
       od.value,
       od.observation_type_id as type,
       od.obs_value_type_id as value_type_id,
       od.observation_code_id as code 
  from pat_observation_details od
  join pat_activity_details ad on (od.activity_dtl_seq_id=ad.activity_dtl_seq_id)
 where ad.claim_seq_id =v_claim_seq_id;
 
 OPEN v_shortfall_details FOR
   select a.claim_seq_id,
       a.pat_auth_seq_id,
       b.shortfall_seq_id,
       b.shortfall_id,
       c.description as shortfall_type,
       DECODE(b.srtfll_status_general_type_id,'OPN','Open','RES','Responded','CLS','Closed','ORD','Overridden') AS srtfll_status_general_type_id,
      /* CASE WHEN b.srtfll_status_general_type_id IN ('CLS', 'RES') THEN*/
         to_char(b.srtfll_received_date, 'DD/MM/RRRR HH:MI:SS AM') as srtfll_received_date,
      /* ELSE*/
         to_char(b.srtfll_sent_date, 'DD/MM/RRRR HH:MI:SS AM') 
       /*END*/ as srtfll_sent_date
       
  from clm_authorization_details a
  join shortfall_details b on (a.claim_seq_id=b.claim_seq_id)
  join tpa_general_code c on (c.general_type_id=b.srtfll_general_type_id)
 where a.claim_seq_id =v_claim_seq_id
 order by b.shortfall_seq_id desc; 
 
 ------------*******DISPLAY PRE_AUTH AND CLAIM COUNT IN CLAIM GENERAL SCREEN******--------------
 
 OPEN v_pat_count  FOR 
 SELECT  count(1)   as pat_count , sum(case status_code_id when 'SUSP' then 1 else 0 end) as cfd_tag_cnt  -- added in CFD CR
   FROM pat_authorization_details a 
 WHERE  a.member_seq_id = clm_rec.member_seq_id 
  AND  a.pre_auth_number is not null  and a.pat_enhanced_yn = 'N';-----newly change due to renewal policy
 
 
 OPEN v_clm_count  FOR 
 SELECT count(1)  as clm_count , sum(case status_code_id when 'SUSP' then 1 else 0 end) as cfd_tag_cnt -- added in CFD CR 
   FROM clm_authorization_details  a 
 WHERE  a.member_seq_id = clm_rec.member_seq_id and a.claim_number is not null;-----newly change due to renewal policy

-----------------********************************* 
      
END select_claim_details;
--===============================================================================
PROCEDURE select_claim (
    v_claim_seq_id                    IN  clm_authorization_details.claim_seq_id%type,
    result_set                           OUT SYS_REFCURSOR  )
IS

BEGIN
 OPEN result_set FOR 
  select ad.auth_number,cad.*,cbud.*,hd.*
  from clm_authorization_details cad
  left outer join clm_hospital_details hd on (hd.claim_seq_id=cad.claim_seq_id)
  left outer join pat_authorization_details ad on (ad.pat_auth_seq_id=cad.pat_auth_seq_id)
  left outer join clm_batch_upload_details cbud
    on (cad.clm_batch_seq_id = cbud.clm_batch_seq_id)
  where cad.claim_seq_id=v_claim_seq_id;
    
END select_claim;  
--===============================================================================

PROCEDURE save_clm_details(V_CLAIM_SEQ_ID               IN OUT CLM_AUTHORIZATION_DETAILS.CLAIM_SEQ_ID%type,
                           V_CLM_BATCH_SEQ_ID           IN CLM_AUTHORIZATION_DETAILS.CLM_BATCH_SEQ_ID%type,
                           V_PAT_AUTH_SEQ_ID            IN CLM_AUTHORIZATION_DETAILS.PAT_AUTH_SEQ_ID%type,
                           V_PARENT_CLAIM_SEQ_ID        IN CLM_AUTHORIZATION_DETAILS.PARENT_CLAIM_SEQ_ID%type,
                           V_CLAIM_NUMBER               IN OUT CLM_AUTHORIZATION_DETAILS.CLAIM_NUMBER%type,
                           V_CLAIM_FILE_NUMBER          IN CLM_AUTHORIZATION_DETAILS.CLAIM_FILE_NUMBER%type,
                           V_SETTLEMENT_NUMBER          IN CLM_AUTHORIZATION_DETAILS.SETTLEMENT_NUMBER%type,
                           V_CLM_RECEIVED_DATE          IN CLM_AUTHORIZATION_DETAILS.CLM_RECEIVED_DATE%type,
                           V_SOURCE_TYPE_ID             IN CLM_AUTHORIZATION_DETAILS.SOURCE_TYPE_ID%type,
                           V_HOSPITALIZATION_DATE       IN CLM_AUTHORIZATION_DETAILS.DATE_OF_HOSPITALIZATION%type,
                           V_DISCHARGE_DATE             IN CLM_AUTHORIZATION_DETAILS.DATE_OF_DISCHARGE%type,
                           V_CLAIM_TYPE                 IN CLM_AUTHORIZATION_DETAILS.CLAIM_TYPE%type,
                           V_CLAIM_SUB_TYPE             IN CLM_AUTHORIZATION_DETAILS.CLAIM_SUB_TYPE%type,
                           V_MEMBER_SEQ_ID              IN CLM_AUTHORIZATION_DETAILS.MEMBER_SEQ_ID%type,
                           V_TPA_ENROLLMENT_ID          IN CLM_AUTHORIZATION_DETAILS.TPA_ENROLLMENT_ID%type,
                           V_MEM_NAME                   IN CLM_AUTHORIZATION_DETAILS.MEM_NAME%type,
                           V_MEM_AGE                    IN CLM_AUTHORIZATION_DETAILS.MEM_AGE%type,
                           V_INS_SEQ_ID                 IN CLM_AUTHORIZATION_DETAILS.INS_SEQ_ID%type,
                           V_POLICY_SEQ_ID              IN CLM_AUTHORIZATION_DETAILS.POLICY_SEQ_ID%type,
                           V_ENROL_TYPE_ID              IN CLM_AUTHORIZATION_DETAILS.ENROL_TYPE_ID%type,
                           V_EMIRATE_ID                 IN CLM_AUTHORIZATION_DETAILS.EMIRATE_ID%type,
                           V_ENCOUNTER_TYPE_ID          IN CLM_AUTHORIZATION_DETAILS.ENCOUNTER_TYPE_ID%type,
                           V_ENCOUNTER_START_TYPE       IN CLM_AUTHORIZATION_DETAILS.ENCOUNTER_START_TYPE%type,
                           V_ENCOUNTER_END_TYPE         IN CLM_AUTHORIZATION_DETAILS.ENCOUNTER_END_TYPE%type,
                           V_ENCOUNTER_FACILITY_ID      IN CLM_AUTHORIZATION_DETAILS.ENCOUNTER_FACILITY_ID%type,
                           V_PAYER_ID                   IN CLM_AUTHORIZATION_DETAILS.PAYER_ID%type,
                           V_AVA_SUM_INSURED            IN CLM_AUTHORIZATION_DETAILS.AVA_SUM_INSURED%type,
                           V_CURRENCY_TYPE              IN CLM_AUTHORIZATION_DETAILS.CURRENCY_TYPE%type,
                           V_CLM_STATUS_TYPE_ID         IN CLM_AUTHORIZATION_DETAILS.CLM_STATUS_TYPE_ID%type,
                           V_REMARKS                    IN CLM_AUTHORIZATION_DETAILS.REMARKS%type,
                           V_INVOICE_NUMBER             IN CLM_AUTHORIZATION_DETAILS.INVOICE_NUMBER%type,
                           V_REQUESTED_AMOUNT           IN CLM_AUTHORIZATION_DETAILS.REQUESTED_AMOUNT%type,
                           V_CLINICIAN_ID               IN CLM_AUTHORIZATION_DETAILS.CLINICIAN_ID%type,
                           V_SYSTEM_OF_MEDICINE_TYPE_ID IN CLM_AUTHORIZATION_DETAILS.SYSTEM_OF_MEDICINE_TYPE_ID%type,
                           V_ACCIDENT_RELATED_TYPE_ID   IN CLM_AUTHORIZATION_DETAILS.ACCIDENT_RELATED_TYPE_ID%type,
                           V_PRIORITY_GENERAL_TYPE_ID   IN CLM_AUTHORIZATION_DETAILS.PRIORITY_GENERAL_TYPE_ID%type,
                           V_NETWORK_YN                 IN CLM_AUTHORIZATION_DETAILS.NETWORK_YN%type,
                           V_BENIFIT_TYPE               IN CLM_AUTHORIZATION_DETAILS.BENIFIT_TYPE%type,
                           V_GRAVIDA                    IN CLM_AUTHORIZATION_DETAILS.GRAVIDA%type,
                           V_PARA                       IN CLM_AUTHORIZATION_DETAILS.PARA%type,
                           V_LIVE                       IN CLM_AUTHORIZATION_DETAILS.LIVE%type,
                           V_ABORTION                   IN CLM_AUTHORIZATION_DETAILS.ABORTION%type,
                           V_PRESENTING_COMPLAINTS      IN CLM_AUTHORIZATION_DETAILS.PRESENTING_COMPLAINTS%type,
                           V_MEDICAL_OPINION_REMARKS    IN CLM_AUTHORIZATION_DETAILS.MEDICAL_OPINION_REMARKS%type,
                           V_HOSP_SEQ_ID                IN CLM_HOSPITAL_DETAILS.HOSP_SEQ_ID%type,
                           V_HOSP_NAME                  IN CLM_HOSPITAL_DETAILS.HOSP_NAME%type,
                           V_ADDRESS_1                  IN CLM_HOSPITAL_DETAILS.ADDRESS_1%type,
                           V_CITY_TYPE_ID               IN CLM_HOSPITAL_DETAILS.CITY_TYPE_ID%type,
                           V_STATE_TYPE_ID              IN CLM_HOSPITAL_DETAILS.STATE_TYPE_ID%type,
                           V_PIN_CODE                   IN CLM_HOSPITAL_DETAILS.PIN_CODE%type,
                           V_OFF_PHONE_NO_1             IN CLM_HOSPITAL_DETAILS.OFF_PHONE_NO_1%type,
                           V_OFFICE_FAX_NO              IN CLM_HOSPITAL_DETAILS.OFFICE_FAX_NO%type,
                           V_PROVIDER_ID                IN CLM_HOSPITAL_DETAILS.PROVIDER_ID%type,
                           V_COUNTRY_TYPE_ID            IN CLM_HOSPITAL_DETAILS.COUNTRY_TYPE_ID%type,
                           v_clinician_name             IN CLM_HOSPITAL_DETAILS.CLINICIAN_NAME%type,
                           V_ADDED_BY                   IN CLM_AUTHORIZATION_DETAILS.ADDED_BY%type,
                           V_RI_COPAR_FLAG              IN CLM_AUTHORIZATION_DETAILS.RI_COPAR_FLAG%TYPE,
                           V_UCR_FLAG                   IN CLM_AUTHORIZATION_DETAILS.UCR_FLAG%TYPE,
                           V_TAK_REF_NO                 IN CLM_AUTHORIZATION_DETAILS.TAKAFUL_REF_NO%TYPE,
                           v_nat_conception             IN CLM_AUTHORIZATION_DETAILS.conception_type%type:= null,
                           v_lmp                        IN CLM_AUTHORIZATION_DETAILS.lmp_date%type:= null,
						              V_REQ_AMT_CURRENCY_TYPE      IN CLM_AUTHORIZATION_DETAILS.Req_Amt_Currency_Type%TYPE:=NULL, 
                           V_CONVERTED_AMOUNT           IN CLM_AUTHORIZATION_DETAILS.Converted_Amount%TYPE:=NULL,  
                           v_CONVERTED_AMT_CURRENCY_TYPE  IN CLM_AUTHORIZATION_DETAILS.Converted_Amount_Currency_Type%TYPE:=NULL,
                           V_CONVERSION_RATE            IN CLM_AUTHORIZATION_DETAILS.Conversion_Rate%TYPE:=NULL, 
                           v_process_type               IN CLM_AUTHORIZATION_DETAILS.process_type%TYPE,
                           v_oth_tpa_ref_no             IN CLM_AUTHORIZATION_DETAILS.oth_tpa_ref_no%TYPE:=NULL, 
                           v_treatmet_type              IN CLM_AUTHORIZATION_DETAILS.treatment_type%type := null,
                           v_mode_of_delvry             IN clm_authorization_details.delvry_mod_type%TYPE :=NULL,
                           v_event_no                   IN CLM_AUTHORIZATION_DETAILS.EVENT_NO%TYPE,
                           v_embassy_seq_id             IN CLM_AUTHORIZATION_DETAILS.EMBASSY_SEQ_ID%TYPE,
                           v_bank_name                  IN CLM_AUTHORIZATION_DETAILS.BANK_NAME%TYPE,
                           v_iban_no                    IN CLM_AUTHORIZATION_DETAILS.IBAN_NUMBER%TYPE,
                           v_pay_made_for               IN CLM_AUTHORIZATION_DETAILS.PAY_MADE_FOR%TYPE,
						               v_MAT_COMPLCTON_YN           IN CLM_AUTHORIZATION_DETAILS.MAT_COMPLCTON_YN%TYPE,
                           V_ROWS_PROCESSED             OUT NUMBER
                           ) is
                           
  v_dest_msg_seq_id VARCHAR2(250);

  CURSOR mem_cur IS
    SELECT tepm.date_of_inception,
           tepm.date_of_exit,
           tepm.mem_name,
           tepm.mem_age,
           tcc.short_name,
           tsc.state_type_id,
           tepg.policy_group_seq_id,
           tepg.policy_seq_id,
           ep.enrol_type_id,
           tepm.member_seq_id,
           tepm.vip_yn
      FROM tpa_enr_policy ep join tpa_enr_policy_group tepg on(ep.policy_seq_id=tepg.policy_seq_id)
      JOIN tpa_enr_policy_member tepm
        ON (tepg.policy_group_seq_id = tepm.policy_group_seq_id)
      LEFT OUTER JOIN tpa_enr_mem_address tema
        ON (tepg.enr_address_seq_id = tema.enr_address_seq_id)
      LEFT OUTER JOIN tpa_country_code tcc
        ON (tema.country_id = tcc.country_id)
      LEFT OUTER JOIN tpa_state_code tsc
        ON (tema.state_type_id = tsc.state_type_id)
     WHERE tepm.Member_Seq_Id = v_member_seq_id;

  CURSOR clm_cur IS
    SELECT cad.date_of_hospitalization,
           cad.source_type_id,
           cad.benifit_type
      FROM clm_authorization_details cad
     WHERE cad.member_seq_id = v_member_seq_id
       AND cad.claim_seq_id != nvl(v_claim_seq_id, 0)
     ORDER BY cad.date_of_hospitalization desc;
     
   CURSOR clm_amnt_cur IS
    SELECT cad.requested_amount,cad.tot_patient_share_amount,cad.pat_auth_seq_id,cad.converted_amount
    ,cad.common_file_number
      FROM clm_authorization_details cad
     WHERE cad.claim_seq_id = nvl(v_claim_seq_id, 0);
   
  
  cursor pat_cur is select * from app.pat_authorization_details a
  where a.pat_auth_seq_id=v_pat_auth_seq_id;
  
  CURSOR clm_batch_cur is
  select D.SUBMISSION_TYPE_ID 
   from app.clm_batch_upload_details d where d.clm_batch_seq_id = v_clm_batch_seq_id;
  
  cursor prior_authid is select count(1) from app.pat_activity_details pc where pc.claim_seq_id=v_claim_seq_id;
 ----added for currency conversion 
     
 CURSOR cur_hosp_currency_id IS
   SELECT CO.COUNTRY_NAME,CU.CURRENCY_ID
    FROM APP.TPA_HOSP_INFO THI
    JOIN TPA_HOSP_ADDRESS THA ON (THI.HOSP_SEQ_ID = THA.HOSP_SEQ_ID)
    JOIN TPA_COUNTRY_CODE CO ON (THA.COUNTRY_ID=CO.COUNTRY_ID)
    JOIN TPA_CURRENCY_CODE CU ON (CO.COUNTRY_ID=CU.COUNTRY_ID)   
   WHERE THI.HOSP_SEQ_ID = V_HOSP_SEQ_ID;
   
  CURSOR cur_corp_pol(vip_yn varchar2) IS
   SELECT case when nvl(vip_yn,'N')='Y' then gt.vip_pre_aprvl_limit_yn else gt.non_vip_pre_aprvl_limit_yn end as pre_aprvl_limit_yn,
          case when nvl(vip_yn,'N')='Y' then gt.vip_pre_aprvl_limit else gt.non_vip_pre_aprvl_limit end as pre_aprvl_limit,
          case when nvl(vip_yn,'N')='Y' then gt.vip_mdt_srvce_pre_aprvl_yn else gt.non_vip_mdt_srvce_pre_aprvl_yn end as pre_aprvl_mdt_srvc_yn 
        FROM tpa_enr_policy GH
        JOIN tpa_ins_prod_policy GT ON (GH.policy_seq_id=GT.policy_seq_id)
     WHERE GH.policy_seq_id=v_policy_seq_id;
     
  CURSOR cur_ind_pol(vip_yn varchar2) IS   
     SELECT case when nvl(vip_yn,'N')='Y' then tipp.vip_pre_aprvl_limit_yn else tipp.non_vip_pre_aprvl_limit_yn end as pre_aprvl_limit_yn,
            case when nvl(vip_yn,'N')='Y' then tipp.vip_pre_aprvl_limit else tipp.non_vip_pre_aprvl_limit end as pre_aprvl_limit,
            case when nvl(vip_yn,'N')='Y' then tipp.vip_mdt_srvce_pre_aprvl_yn else tipp.non_vip_mdt_srvce_pre_aprvl_yn end as pre_aprvl_mdt_srvc_yn
     FROM tpa_enr_policy tep
     LEFT OUTER JOIN tpa_ins_product tip on (tip.product_seq_id=tep.product_seq_id)
     LEFT OUTER JOIN tpa_ins_prod_policy tipp on (tipp.product_seq_id=tip.product_seq_id)
     WHERE tep.policy_seq_id=v_policy_seq_id;
  
 rec_hosp_currency_id            cur_hosp_currency_id%ROWTYPE;
 
 cursor currency_con is 
 select to_number(jk.qar_per_unit) as aed_per_unit
   from app.TPA_CURRENCY_CONV_RATES jk
  where jk.CONV_SEQ_ID =
        (select max(jk.CONV_SEQ_ID)
          from app.TPA_CURRENCY_CONV_RATES jk
         where jk.currency_code = NVL(v_req_amt_currency_type,rec_hosp_currency_id.currency_id)
           and to_date(jk.conversion_date, 'DD/MM/RRRR') =to_date(V_DISCHARGE_DATE,'DD/MM/RRRR'));
    

 cursor currency_exist_as_per_date is 
 select count(1) 
   from APP.TPA_CURRENCY_CONV_RATES jk
  where to_date(jk.conversion_date, 'DD/MM/RR') =to_date(V_DISCHARGE_DATE,'DD/MM/RR')
    and jk.currency_code = NVL(v_req_amt_currency_type,rec_hosp_currency_id.currency_id);   
    v_cur_exch_cnt number;
    
 CURSOR event_cur IS
  select count(p.event_no)
  from clm_authorization_details p
  where p.event_no = trim(v_event_no);
  
  CURSOR vip_nvip_cursor(v_clm_seq_id number) IS 
         select b.VIP_YN
                from clm_authorization_details a join tpa_enr_policy_member b on(a.MEMBER_SEQ_ID=b.MEMBER_SEQ_ID)
                     where a.claim_seq_id = v_clm_seq_id;
     
 vip_nvip_rec tpa_enr_policy_member.VIP_YN%TYPE;
 
 
 CURSOR Common_File_Number is
  Select cad.common_file_number
   from clm_authorization_details cad
   where cad.claim_seq_id=V_CLAIM_SEQ_ID; 
 
 CURSOR Resub_Common_File_Number IS
  Select cad.common_file_number
   from clm_authorization_details cad
   where cad.claim_seq_id=V_Parent_Claim_Seq_Id;
   
 CURSOR check_Common_File_Number(file_number  VARCHAR2) IS
  SELECT max(substr(cad.common_file_number,13))
   from clm_authorization_details cad
   where cad.common_file_number LIKE file_number||'%';
      
event_num          VARCHAR2(15);
v_event_num        VARCHAR2(15);
v_event_len        NUMBER;

    
 currency_con_rec currency_con%rowtype;
 v_conv_QAR_amnt   NUMBER(20,2);
 
  clm_rec clm_cur%ROWTYPE;
  clm_amnt_rec clm_amnt_cur%ROWTYPE;
  mem_rec         mem_cur%ROWTYPE;
  pat_rec         pat_cur%ROWTYPE;
  batch_rec       clm_batch_cur%ROWTYPE; 
  v_denial_reason clm_authorization_details.denial_reason%type;
  v_pat_approved_amount   clm_authorization_details.pat_approved_amount%type;
  v_pat_benft_type        pat_authorization_details.benifit_type%type;
  v_clm_status           varchar2(100);
  v_pat_hosp_seq_id      number;
  
  v_pre_approval_limit_yn      varchar2(1);
  v_pre_approval_limit         number(10,2);
  v_pre_aprvl_mdt_srvc_yn      varchar2(1);
  v_source_type_id1       varchar2(5);
  v_denial_code           clm_authorization_details.denial_code%type;
  v_denial_remarks        clm_authorization_details.denial_reason%type;
  v_reg_authority               app.tpa_hosp_info.regist_authority%type;
  v_prior_authid_cnt number;
  v_mem_alert    varchar2(100);
  v_seq_id        NUMBER(10);
  v_spec_char_cnt    NUMBER;
  v_common_file_number          VARCHAR2(100);
  v_file_num                    VARCHAR2(300);

  v_old_claim_num   number;
  v_mat_cnt              integer;
  
BEGIN

IF NVL(V_CLAIM_NUMBER,'NA')!='NA' THEN
authorization_pkg.reassign_user(null,'|'||v_claim_seq_id||'|',null,v_added_by,null,v_seq_id);
END IF;

 IF NVL(v_claim_seq_id, 0) != 0 then 
    update clm_authorization_details pad
        SET pad.denial_reason= NULL,
            pad.denial_code  = NULL,
            pad.remarks      = NULL
        where pad.claim_seq_id=v_claim_seq_id;
  end if;

  OPEN mem_cur;
  FETCH mem_cur
    INTO mem_rec;
  CLOSE mem_cur;
  
  
 OPEN clm_batch_cur;
 FETCH clm_batch_cur INTO batch_rec;
 CLOSE clm_batch_cur;
 
 
 OPEN clm_amnt_cur;
 FETCH clm_amnt_cur INTO clm_amnt_rec;
 close clm_amnt_cur;
 
 /*OPEN clm_cur;
 FETCH clm_cur INTO clm_rec;
 CLOSE clm_cur;*/ -- commented by venu, we are not using this cursors information on 25/02/2019
 
 ----added for currency conversion 
  IF v_hosp_seq_id IS NOT NULL THEN
    OPEN  cur_hosp_currency_id;
    FETCH cur_hosp_currency_id INTO rec_hosp_currency_id;
    CLOSE cur_hosp_currency_id;
  END IF;
  
  OPEN currency_exist_as_per_date;
  FETCH currency_exist_as_per_date INTO v_cur_exch_cnt;
  close currency_exist_as_per_date;
  
  IF NVL(v_req_amt_currency_type,rec_hosp_currency_id.currency_id)=v_converted_amt_currency_type THEN 
     v_conv_QAR_amnt:=v_requested_amount;
  ELSE
   IF  v_conversion_rate IS NOT NULL   THEN 
       v_conv_QAR_amnt:=v_requested_amount*v_conversion_rate;
   ELSE
    IF v_cur_exch_cnt=0 THEN 
       RAISE_APPLICATION_ERROR(-20405,'As per the date there is no rate existing for this Currency in softcopy');
    END IF ;
     OPEN  currency_con;
     FETCH currency_con INTO currency_con_rec;
     CLOSE currency_con;
     v_conv_QAR_amnt:= v_requested_amount*currency_con_rec.aed_per_unit;
   END IF ;
  END IF; 
   
  if V_CLAIM_SEQ_ID is not null then 
    select ad.completed_yn into v_clm_status from app.clm_authorization_details ad where ad.claim_seq_id=v_claim_seq_id;
   if nvl(v_clm_status,'N')='Y' then 
      RAISE_APPLICATION_ERROR(-20107,'You cannot perform this action through a completed Claim.');
   end if;
  end if; 
   if v_source_type_id = 'ECL' then 
      v_source_type_id1 := 'ECLM';
   else 
     v_source_type_id1 := v_source_type_id1;
   end if;
  IF v_source_type_id = 'ECLM' THEN
    IF mem_rec.member_seq_id IS NULL THEN
      v_denial_reason := 'ELIG-001';
    ELSIF v_hospitalization_date < mem_rec.date_of_inception THEN
      v_denial_reason := 'ELIG-006';
    ELSIF v_hospitalization_date > mem_rec.Date_Of_Exit THEN
      v_denial_reason := 'ELIG-005';
    END IF;
   /*IF NVL(V_PARENT_CLAIM_SEQ_ID,0)=0 THEN
    FOR rec IN clm_cur LOOP
      IF trunc(rec.date_of_hospitalization) = trunc(v_hospitalization_date) THEN
        v_denial_reason := 'DUPL-001';
      END IF;
    END LOOP;
   END IF;*/--commented as per Dr.Yasmin
  ELSE
    IF mem_rec.member_seq_id IS NULL THEN
      --RAISE_APPLICATION_ERROR(-20370, 'Patient is not a covered member');
      v_mem_alert:= 'Patient is not a covered member';
      v_denial_code  := 'ELIG-001';
      v_denial_remarks := 'Patient is not a covered member';
      v_denial_reason  := 'Patient is not a covered member';
    
    END IF;
  END IF;
  
  IF V_MEMBER_SEQ_ID IS NOT NULL THEN 
  IF mem_rec.enrol_type_id='COR' THEN
   OPEN  cur_corp_pol(mem_rec.vip_yn);
   FETCH cur_corp_pol INTO v_pre_approval_limit_yn,v_pre_approval_limit,v_pre_aprvl_mdt_srvc_yn;
   CLOSE cur_corp_pol;
  ELSE
   OPEN  cur_ind_pol(mem_rec.vip_yn);
   FETCH cur_ind_pol INTO v_pre_approval_limit_yn,v_pre_approval_limit,v_pre_aprvl_mdt_srvc_yn;
   CLOSE cur_ind_pol;
  
 END IF;
 END IF;
 
 IF V_PAT_AUTH_SEQ_ID is not null then
   open pat_cur;
   fetch pat_cur into pat_rec;
   close  pat_cur;
 END IF;
 
 ----added for prior authid check
 open prior_authid;
   fetch prior_authid into v_prior_authid_cnt;
   close  prior_authid;
 
 IF V_CLAIM_TYPE ='CNH' THEN 
  IF NVL(v_pre_approval_limit_yn,'N')='Y' and  (v_conv_QAR_amnt-nvl(clm_amnt_rec.tot_patient_share_amount,0))> v_pre_approval_limit THEN 
    IF (v_conv_QAR_amnt-nvl(clm_amnt_rec.tot_patient_share_amount,0))> v_pre_approval_limit 
        AND/* v_prior_authid_cnt=0*/ V_PAT_AUTH_SEQ_ID is null THEN
          --RAISE_APPLICATION_ERROR(-20394, 'Authorization number is mandatory for Network Claim');
           
                v_denial_remarks  := 'Prior approval is required and was not obtained';
                v_denial_code  := 'AUTH-001';
         
     ELSIF (v_conv_QAR_amnt-nvl(clm_amnt_rec.tot_patient_share_amount,0))> v_pre_approval_limit 
        AND V_PAT_AUTH_SEQ_ID IS NOT NULL THEN
        
              v_pat_approved_amount:=pat_rec.tot_approved_amount;
             IF (pat_rec.benifit_type != v_benifit_type) OR 
                (pat_rec.hosp_seq_id != v_hosp_seq_id and pat_rec.hosp_seq_id is not null and nvl(V_NETWORK_YN,'N')='Y' ) THEN
                 RAISE_APPLICATION_ERROR(-20392,'Please check Pre_auth and claims Benefit_Type/provider is not matching');
             END IF;
                 IF v_benifit_type IN ('MTI', 'OMTI', 'IMTI') THEN
                   IF (V_GRAVIDA!=pat_rec.gravida) OR (V_PARA !=pat_rec.para ) OR (V_LIVE !=pat_rec.live) OR (V_ABORTION !=pat_rec.abortion) then
                         RAISE_APPLICATION_ERROR(-20393,'Please check Pre_auth and claims maternity(gravida/para/live/abortion) values are not matching');
                   END IF;
                 END IF;
               IF pat_rec.system_of_medicine_type_id!=v_system_of_medicine_type_id THEN
                    RAISE_APPLICATION_ERROR(-20425,'Please check the system of medicine is not matching in Pre_auth and what ever you selected in claim level');
               END IF;
    END IF;
   ELSE
         IF V_PAT_AUTH_SEQ_ID IS NOT NULL THEN
   
                 v_pat_approved_amount:=pat_rec.tot_approved_amount;
                IF (pat_rec.benifit_type != v_benifit_type) OR 
                   (pat_rec.hosp_seq_id != v_hosp_seq_id and pat_rec.hosp_seq_id is not null  and nvl(V_NETWORK_YN,'N')='Y' ) THEN
                    RAISE_APPLICATION_ERROR(-20392,'Please check Pre_auth and claims Benefit_Type/provider is not matching');
                END IF;
               IF v_benifit_type IN ('MTI', 'OMTI', 'IMTI') THEN
                 IF (V_GRAVIDA!=pat_rec.gravida) OR (V_PARA !=pat_rec.para ) OR (V_LIVE !=pat_rec.live) OR (V_ABORTION !=pat_rec.abortion) then
                    RAISE_APPLICATION_ERROR(-20393,'Please check Pre_auth and claims maternity(gravida/para/live/abortion) values are not matching');
                 END IF;
               END IF;
			  
               IF pat_rec.system_of_medicine_type_id!=v_system_of_medicine_type_id THEN
                    RAISE_APPLICATION_ERROR(-20425,'Please check the system of medicine is not matching in Pre_auth and what ever you selected in claim level');
               END IF;			  
          ELSE
            --RAISE_APPLICATION_ERROR(-20394, 'Authorization number is mandatory for Network Claim');
                /*v_denial_remarks  := 'Prior approval is required and was not obtained';
                v_denial_code  := 'AUTH-001';*/
                null;
         END IF;  
  END IF;
 END IF; 
 
    if  V_HOSP_SEQ_ID is not null then 
           select thi.regist_authority
             into v_reg_authority
             from app.tpa_hosp_info thi
            where thi.hosp_seq_id = V_HOSP_SEQ_ID;
     end if;
  
  IF NVL(v_claim_seq_id, 0) = 0 THEN
    -- If Event is not generated or Existing Event Number
    IF v_event_no IS NOT NULL THEN
      SELECT count(1) INTO v_spec_char_cnt FROM DUAL
      WHERE REGEXP_LIKE(v_event_no, '^\d+(\\d+)?$', '');
      
      IF v_spec_char_cnt = 0 THEN
        RAISE_APPLICATION_ERROR(-20916, 'Event Number should be number format .');
      END IF;
      
      SELECT length(v_event_no) INTO v_event_len
      FROM DUAL;
      
      IF v_event_len != 7 THEN
        RAISE_APPLICATION_ERROR(-20919, 'Event Number Length should be 7 .');
      END IF;
      
      /*open event_cur;
      fetch event_cur into event_num;
      close event_cur;*/
      
      /*select rpad((s.LAST_NUMBER - 1), 7, 0) INTO v_event_num
        from all_sequences s
        where s.SEQUENCE_NAME = UPPER('event_ref_no_seq')
        and s.SEQUENCE_OWNER = 'APP';*/
    
      /*IF event_num > 0 THEN
        RAISE_APPLICATION_ERROR(-20914, 'Given Event Number is Already assinged to other Preaproval/ Claim.');
      END IF;*/
      
      /*IF trim(v_event_no) > v_event_num and batch_rec.submission_type_id='DTC' THEN
        RAISE_APPLICATION_ERROR(-20915, 'Given Event Number is not valid.');
      END IF;*/
      
      /*IF v_pat_auth_seq_id IS NOT NULL THEN
        Select count(p.event_no) Into v_event_num
        From Pat_Authorization_Details p
        Where p.pat_auth_seq_id = v_pat_auth_seq_id;
        
        IF v_event_num = 0 THEN
          RAISE_APPLICATION_ERROR(-20918, 'Event Reference Number is not available for the given Pre-Approval Number.');
        END IF;
      END IF;
      
      IF v_pat_auth_seq_id IS NOT NULL THEN
        Select count(p.event_no) Into v_event_num
        From Pat_Authorization_Details p
        Where p.pat_auth_seq_id = v_pat_auth_seq_id
        And p.event_no = trim(v_event_no);
        
        IF v_event_num = 0 THEN
          RAISE_APPLICATION_ERROR(-20917, 'Given Event Number is not matching with Pre Appoval.');
        END IF;
      END IF;*/
      
    END IF;
    
      IF v_claim_number IS NULL and batch_rec.submission_type_id='DTC' THEN
        v_claim_number      := authorization_pkg.generate_id_numbers('CL', mem_rec.short_name , mem_rec.state_type_id, v_claim_number);
      ELSIF v_claim_number IS NULL and batch_rec.submission_type_id='DTR' THEN
        v_claim_number      := authorization_pkg.generate_id_numbers('RS', mem_rec.short_name , mem_rec.state_type_id, v_claim_number);
      
      END IF;
      
       
     IF  clm_amnt_rec.common_file_number IS NULL AND batch_rec.submission_type_id='DTR' THEN
         OPEN Resub_Common_File_Number;
          FETCH Resub_Common_File_Number INTO v_common_file_number;
            CLOSE Resub_Common_File_Number;
     END IF;  
   
   
INSERT INTO clm_authorization_details
  (claim_seq_id,
   clm_batch_seq_id,
   pat_auth_seq_id,
   parent_claim_seq_id,
   claim_number,
   claim_file_number,
   settlement_number,
   clm_received_date,
   source_type_id,
   date_of_hospitalization,
   date_of_discharge,
   claim_type,
   claim_sub_type,
   member_seq_id,
   tpa_enrollment_id,
   mem_name,
   mem_age,
   ins_seq_id,
   policy_seq_id,
   enrol_type_id,
   emirate_id,
   encounter_type_id,
   encounter_start_type,
   encounter_end_type,
   encounter_facility_id,
   ava_sum_insured,
   currency_type,
   clm_status_type_id,
   denial_reason,
   remarks,
   added_by,
   added_date,
   invoice_number,
   requested_amount,
   clinician_id,
   system_of_medicine_type_id,
   accident_related_type_id,
   priority_general_type_id,
   network_yn,
   benifit_type,
   gravida,
   para,
   live,
   abortion,
   presenting_complaints,
   medical_opinion_remarks,
   payer_id ,
   denial_code,
   pat_approved_amount,
   RI_COPAR_FLAG,
   ucr_flag,
   TAKAFUL_REF_NO,
   conception_type,
   lmp_date,
   REQ_AMT_CURRENCY_TYPE,
   CONVERTED_AMOUNT,
   CONVERTED_AMOUNT_CURRENCY_TYPE,
   CONVERSION_RATE,
   process_type,
   oth_tpa_ref_no,
   treatment_type,
   delvry_mod_type,
   event_no,
   embassy_seq_id,
   MAT_COMPLCTON_YN,
   maternity_yn,
   re_submission_remarks,
   common_file_number
   )
VALUES
  (clm_authorization_detail_seq.nextval,
   v_clm_batch_seq_id,
   v_pat_auth_seq_id,
   v_parent_claim_seq_id,
   v_claim_number,
   v_claim_file_number,
   v_settlement_number,
   v_clm_received_date,
   v_source_type_id1,
   v_hospitalization_date,
   v_discharge_date,
   v_claim_type,
   v_claim_sub_type,
   v_member_seq_id,
   v_tpa_enrollment_id,
   v_mem_name,
   v_mem_age,
   v_ins_seq_id,
   v_policy_seq_id,
   mem_rec.enrol_type_id,--v_enrol_type_id,
   v_emirate_id,
   v_encounter_type_id,
   v_encounter_start_type,
   v_encounter_end_type,
   v_encounter_facility_id,
   v_ava_sum_insured,
   v_currency_type,
   nvl(v_clm_status_type_id,'INP'),
   v_denial_remarks,
   v_remarks,
   v_added_by,
   sysdate,
   v_invoice_number,
   v_requested_amount,
   v_clinician_id,
   v_system_of_medicine_type_id,
   v_accident_related_type_id,
   v_priority_general_type_id,
   v_network_yn,
   v_benifit_type,
   v_gravida,
   v_para,
   v_live,
   v_abortion,
   v_presenting_complaints,
   v_medical_opinion_remarks,
   v_payer_id,
   v_denial_code,
   v_pat_approved_amount,
   V_RI_COPAR_FLAG,
   V_UCR_FLAG,
   V_TAK_REF_NO,
   v_nat_conception,
   v_lmp,
   NVL(v_req_amt_currency_type,rec_hosp_currency_id.currency_id),
   v_conv_QAR_amnt,
   v_CONVERTED_AMT_CURRENCY_TYPE,
   NVL(NVL(v_conversion_rate,currency_con_rec.aed_per_unit),0),
   NVL(v_process_type,'RGL'),
   v_oth_tpa_ref_no,
   v_treatmet_type ,
   v_mode_of_delvry ,
   v_event_no,
   v_embassy_seq_id,
   case when V_PAT_AUTH_SEQ_ID is not null then pat_rec.mat_complcton_yn else  v_MAT_COMPLCTON_YN end,
   case when nvl(v_benifit_type,'A') IN ('MTI', 'OMTI', 'IMTI') THEN 'Y' ELSE 'N' end,
   v_remarks,
   v_common_file_number ) returning claim_seq_id into v_claim_seq_id;
  
    insert into clm_hospital_details c
      (clm_hosp_assoc_seq_id,
       claim_seq_id,
       hosp_seq_id,
       hosp_name,
       address_1,
       city_type_id,
       state_type_id,
       pin_code,
       off_phone_no_1,
       office_fax_no,
       remarks,
       added_by,
       added_date,
       provider_id,
       country_type_id,
       clinician_name)
    values
      (clm_hosp_dtl_hosp_assoc_seq.nextval,
       v_claim_seq_id,
       v_hosp_seq_id,
       v_hosp_name,
       v_address_1,
       v_city_type_id,
       v_state_type_id,
       v_pin_code,
       v_off_phone_no_1,
       v_office_fax_no,
       v_remarks,
       v_added_by,
       sysdate,
       v_provider_id,
       v_country_type_id,
       v_clinician_name);
	   

      
      /*IF V_CLAIM_TYPE = 'CNH' THEN 
         GENERATE_MAIL_PKG.proc_generate_message('CLAIM_RECEIVED_NHCP',
                                          v_claim_seq_id,
                                          v_added_by,
                                          v_dest_msg_seq_id);
                                          
         GENERATE_MAIL_PKG.proc_generate_message('CLAIM_MR_RECEIVED',
                                          v_claim_seq_id,
                                          v_added_by,
                                          v_dest_msg_seq_id);*/
                                          
      IF V_CLAIM_TYPE = 'CTM' THEN 
        GENERATE_MAIL_PKG.proc_generate_message('CLAIM_MR_RECEIVED',
                                          v_claim_seq_id,
                                          v_added_by,
                                          v_dest_msg_seq_id);
      END IF;
      
      OPEN vip_nvip_cursor(v_claim_seq_id);
      fetch vip_nvip_cursor into vip_nvip_rec;
      close  vip_nvip_cursor;
      
      IF NVL(vip_nvip_rec,'N')='Y' AND  V_CLAIM_TYPE = 'CTM' and v_claim_seq_id is not null THEN
        GENERATE_MAIL_PKG.proc_generate_message('VIP_MEM_CLM_UPLOADED',v_claim_seq_id,v_added_by,v_dest_msg_seq_id);
      END IF;
  

  if v_pat_auth_seq_id is not null then 
    update pat_authorization_details pad 
    set pad.claim_seq_id = v_claim_seq_id,
        pad.updated_by   = v_added_by,
        pad.updated_date = sysdate
   where pad.pat_auth_seq_id=v_pat_auth_seq_id ;
   
  end if;
  
  
  
  ELSE
   ---- for dental fixes ---- 
   SELECT COUNT(1) INTO v_mat_cnt FROM DIAGNOSYS_DETAILS D 
   WHERE D.CLAIM_SEQ_ID = v_claim_seq_id AND D.PRIMARY_AILMENT_YN = 'Y';
   
   IF v_mat_cnt > 0 THEN
     select COUNT(1) INTO v_mat_cnt
     from diagnosys_details dd
     join tpa_icd10_master_details tic on (dd.diagnosys_code=tic.icd_code and dd.primary_ailment_yn='Y' AND tic.benefit_type = 'DNTL')
     WHERE dd.claim_seq_id = v_claim_seq_id;
  
     IF (V_BENIFIT_TYPE = 'DNTL' AND v_mat_cnt = 0) OR (V_BENIFIT_TYPE != 'DNTL' AND v_mat_cnt > 0) THEN
       RAISE_APPLICATION_ERROR(-20323,'Ailment does not belogs to the selected benefit type, please select appropriate benefit type!');
     END IF;
   END IF;
   -------------------------- 
   ---------- CR0248(Benefit type restriction for meternity icd) ---------
   v_mat_cnt:=0;
   select count(1) into v_mat_cnt
   from diagnosys_details dd 
   join tpa_icd_codes tic on (dd.diagnosys_code=tic.icd_code and dd.primary_ailment_yn='Y' and tic.master_icd_code='Z34.90')
   WHERE DD.Claim_Seq_Id = v_claim_seq_id;
   
   IF v_mat_cnt > 0 AND V_BENIFIT_TYPE NOT IN ('IMTI','OMTI','MTI') THEN
     RAISE_APPLICATION_ERROR(-20323,'Ailment does not belogs to the selected benefit type, please select appropriate benefit type!');
   END IF;  
   ------------------------------------------------------------------------ 
   IF v_claim_number IS NULL THEN  
          authorization_pkg.reassign_user(null,'|'||v_claim_seq_id||'|',null,v_added_by,'AUT',v_seq_id);
    END IF;
  
      IF v_claim_number IS NULL AND batch_rec.Submission_Type_Id='DTC' THEN
        v_claim_number      := authorization_pkg.generate_id_numbers('CL', mem_rec.short_name , mem_rec.state_type_id, v_claim_number);
      ELSIF v_claim_number IS NULL and batch_rec.submission_type_id='DTR' THEN
        v_claim_number      := authorization_pkg.generate_id_numbers('RS', mem_rec.short_name , mem_rec.state_type_id, v_claim_number);
        
      END IF;
   
   OPEN Common_File_Number;
      FETCH Common_File_Number INTO v_common_file_number ;
        CLOSE Common_File_Number;
        
    IF v_common_file_number IS NULL AND batch_rec.Submission_Type_Id='DTC' THEN
       v_common_file_number := authorization_pkg.generate_id_numbers('CFN', null , null, null);
       
       update APP.TPA_SEQ_NO_GEN_DETAILS c
       set c.clm_file_no_max=v_common_file_number;
    
    ELSIF  clm_amnt_rec.common_file_number IS NULL AND batch_rec.submission_type_id='DTR' THEN
         OPEN Resub_Common_File_Number;
          FETCH Resub_Common_File_Number INTO v_common_file_number;
            CLOSE Resub_Common_File_Number;
    END IF;
      
   if clm_amnt_rec.pat_auth_seq_id !=v_pat_auth_seq_id  and nvl(v_pat_auth_seq_id,0) > 0 Then 
       update pat_authorization_details pad 
          set pad.claim_seq_id = null,
          pad.updated_by   = v_added_by,
          pad.updated_date = sysdate
     where pad.pat_auth_seq_id = clm_amnt_rec.pat_auth_seq_id;
   elsif nvl(clm_amnt_rec.pat_auth_seq_id,0) != nvl(v_pat_auth_seq_id,0)  and nvl(v_pat_auth_seq_id,0) = 0 Then  
     update pat_authorization_details pad 
          set pad.claim_seq_id = null,
          pad.updated_by   = v_added_by,
          pad.updated_date = sysdate
     where pad.pat_auth_seq_id = clm_amnt_rec.pat_auth_seq_id;
   end if;
   ---Event Number
   IF v_event_no IS NOT NULL THEN
     
     SELECT count(1) INTO v_spec_char_cnt FROM DUAL
     WHERE REGEXP_LIKE(v_event_no, '^\d+(\\d+)?$', '');
      
     IF v_spec_char_cnt = 0 THEN
       RAISE_APPLICATION_ERROR(-20916, 'Event Number should be number format .');
     END IF;
     
     SELECT length(v_event_no) INTO v_event_len
      FROM DUAL;
      
     IF v_event_len != 7 THEN
       RAISE_APPLICATION_ERROR(-20919, 'Event Number Length should be 7 .');
     END IF;
      
     /*Select Count(c.event_no) Into event_num
      From Clm_Authorization_Details c
      Where c.claim_seq_id != v_claim_seq_id
      And c.event_no = trim(v_event_no);*/
     
      /*select rpad((s.LAST_NUMBER - 1), 7, 0) INTO v_event_num
      from all_sequences s
      where s.SEQUENCE_NAME = UPPER('event_ref_no_seq')
      and s.SEQUENCE_OWNER = 'APP';
     
      IF to_number(trim(v_event_no)) > v_event_num AND batch_rec.Submission_Type_Id='DTC' THEN
        RAISE_APPLICATION_ERROR(-20915, 'Given Event Number is not valid.');
      END IF;*/
     
      /*IF event_num > 0 THEN
        RAISE_APPLICATION_ERROR(-20914, 'Given Event Number is Already assinged to other Preaproval/ Claim.');
      END IF;*/
      
      /*IF v_pat_auth_seq_id IS NOT NULL THEN
        Select count(p.event_no) Into v_event_num
        From Pat_Authorization_Details p
        Where p.pat_auth_seq_id = v_pat_auth_seq_id;
        
        IF v_event_num = 0 THEN
          RAISE_APPLICATION_ERROR(-20918, 'Event Reference Number is not available for the given Pre-Approval Number.');
        END IF;
      END IF;
      
      IF v_pat_auth_seq_id IS NOT NULL THEN
        Select count(p.event_no) Into v_event_num
        From Pat_Authorization_Details p
        Where p.pat_auth_seq_id = v_pat_auth_seq_id
        And p.event_no = trim(v_event_no);
        
        IF v_event_num = 0 THEN
          RAISE_APPLICATION_ERROR(-20917, 'Given Event Number is not matching with Pre Appoval.');
        END IF;
      END IF;*/
    END IF;
   select claim_number into v_old_claim_num from clm_authorization_details where claim_seq_id=v_claim_seq_id ;
   UPDATE clm_authorization_details
      SET clm_batch_seq_id           = v_clm_batch_seq_id,
          pat_auth_seq_id            = v_pat_auth_seq_id,
          parent_claim_seq_id        = v_parent_claim_seq_id,
          claim_number               = v_claim_number,
          claim_file_number          = v_claim_file_number,
          settlement_number          = v_settlement_number,
          clm_received_date          = v_clm_received_date,
          source_type_id             = v_source_type_id1,
          date_of_hospitalization    = v_hospitalization_date,
          date_of_discharge          = v_discharge_date,
          claim_type                 = v_claim_type,
          claim_sub_type             = v_claim_sub_type,
          member_seq_id              = v_member_seq_id,
          tpa_enrollment_id          = v_tpa_enrollment_id,
          mem_name                   = v_mem_name,
          mem_age                    = v_mem_age,
          ins_seq_id                 = v_ins_seq_id,
          policy_seq_id              = v_policy_seq_id,
          enrol_type_id              = mem_rec.enrol_type_id,--v_enrol_type_id,
          emirate_id                 = v_emirate_id,
          encounter_type_id          = v_encounter_type_id,
          encounter_start_type       = v_encounter_start_type,
          encounter_end_type         = v_encounter_end_type,
          encounter_facility_id      = v_encounter_facility_id,
          ava_sum_insured            = v_ava_sum_insured,
          currency_type              = v_currency_type,
          clm_status_type_id         = nvl(v_clm_status_type_id,'INP'),
          denial_reason              = v_denial_remarks,
          remarks                    = v_remarks,
          re_submission_remarks      = case when  batch_rec.submission_type_id='DTR' THEN v_remarks ELSE NULL END,
          updated_by                 = v_added_by,
          updated_date               = sysdate,
          invoice_number             = v_invoice_number,
          requested_amount           = v_requested_amount,
          clinician_id               = v_clinician_id,
          system_of_medicine_type_id = v_system_of_medicine_type_id,
          accident_related_type_id   = v_accident_related_type_id,
          priority_general_type_id   = v_priority_general_type_id,
          network_yn                 = v_network_yn,
          benifit_type               = v_benifit_type,
          gravida                    = v_gravida,
          para                       = v_para,
          live                       = v_live,
          abortion                   = v_abortion,
          presenting_complaints      = v_presenting_complaints,
          medical_opinion_remarks    = v_medical_opinion_remarks,
          payer_id                   = v_payer_id,
          denial_code                = v_denial_code,
          pat_approved_amount        = v_pat_approved_amount,
          RI_COPAR_FLAG              = V_RI_COPAR_FLAG,
          UCR_FLAG                   = V_UCR_FLAG,
          TAKAFUL_REF_NO             = V_TAK_REF_NO,
          conception_type            = v_nat_conception,
          lmp_date                   = v_lmp,
          REQ_AMT_CURRENCY_TYPE      = NVL(v_req_amt_currency_type,rec_hosp_currency_id.currency_id),  
          CONVERTED_AMOUNT           = v_conv_QAR_amnt,  
          CONVERTED_AMOUNT_CURRENCY_TYPE  = v_CONVERTED_AMT_CURRENCY_TYPE,
          CONVERSION_RATE            = NVL(NVL(v_conversion_rate,currency_con_rec.aed_per_unit),1),
          PROCESS_TYPE               = NVL(v_process_type,'RGL'),
          oth_tpa_ref_no             = v_oth_tpa_ref_no,
          treatment_type             = v_treatmet_type,
          delvry_mod_type	           = v_mode_of_delvry,
          CAL_ACT_YN                 = 'N',
          event_no                   = v_event_no,
          embassy_seq_id             =v_embassy_seq_id,
          bank_name                  =v_bank_name,
          iban_number                = v_iban_no,
          pay_made_for               = v_pay_made_for,
          common_file_number         = v_common_file_number,
          MAT_COMPLCTON_YN           = case when V_PAT_AUTH_SEQ_ID is not null then pat_rec.mat_complcton_yn else  v_MAT_COMPLCTON_YN end,
          maternity_yn               = case when nvl(v_benifit_type,'A') IN ('MTI', 'OMTI', 'IMTI') THEN 'Y' ELSE 'N' end
         WHERE claim_seq_id = v_claim_seq_id;
         
      IF v_old_claim_num is  null and v_claim_number IS NOT NULL and sql%rowcount=1 THEN
      OPEN vip_nvip_cursor(v_claim_seq_id);
      fetch vip_nvip_cursor into vip_nvip_rec;
      close  vip_nvip_cursor;      

      IF NVL(vip_nvip_rec,'N')='Y' AND  V_CLAIM_TYPE = 'CTM' and v_claim_seq_id is not null THEN
        GENERATE_MAIL_PKG.proc_generate_message('VIP_MEM_CLM_UPLOADED',v_claim_seq_id,v_added_by,v_dest_msg_seq_id);
      END IF;
      END IF;

    update clm_hospital_details chd
       set hosp_seq_id      = v_hosp_seq_id,
           hosp_name        = v_hosp_name,
           address_1        = v_address_1,
           city_type_id     = v_city_type_id,
           state_type_id    = v_state_type_id,
           pin_code         = v_pin_code,
           off_phone_no_1   = v_off_phone_no_1,
           office_fax_no    = v_office_fax_no,
           remarks          = v_remarks,
           updated_by       = v_added_by,
           updated_date     = sysdate,
           provider_id      = v_provider_id,
           country_type_id  = v_country_type_id,
           clinician_name   = v_clinician_name
     where chd.claim_seq_id = v_claim_seq_id;

  if v_pat_auth_seq_id is not null then 
    update pat_authorization_details pad 
    set pad.claim_seq_id = v_claim_seq_id,
        pad.updated_by   = v_added_by,
        pad.updated_date = sysdate
   where pad.pat_auth_seq_id=v_pat_auth_seq_id ;
  end if;
 
  
  END IF;
  v_claim_seq_id:=v_claim_seq_id;

  v_prod_policy_rule_seq_id := pat_xml_load_pkg.get_prod_pol_seq_id(mem_rec.policy_seq_id,
                                                                    'POL');

  pat_xml_load_pkg.execute_global_rules('C',
                                        v_claim_seq_id,
                                        v_member_seq_id,
                                        v_prod_policy_rule_seq_id);
  
  
  if v_denial_code is not null then 
    update clm_authorization_details pad
        SET pad.denial_reason= case when pad.denial_reason is null then v_denial_remarks else case when pad.denial_code like '%'||v_denial_code||'%' then pad.denial_reason else (pad.denial_reason||';'||v_denial_remarks) end end,
            pad.denial_code  = case when pad.denial_code is null then v_denial_code else case when pad.denial_code  like '%'||v_denial_code||'%' then pad.denial_code else (pad.denial_code||';'||v_denial_code) end end,
            pad.remarks      = case when pad.remarks is null then v_denial_remarks else case when pad.denial_code like '%'||v_denial_code||'%' then pad.remarks else (pad.remarks||';'||v_denial_remarks) end end
        where pad.claim_seq_id=v_claim_seq_id;
  end if;
  
  /*IF V_CLAIM_TYPE = 'CNH' THEN
    GENERATE_MAIL_PKG.proc_generate_message('CLAIM_RECEIVED_NHCP',
                                          v_claim_seq_id,
                                          v_added_by,
                                          v_dest_msg_seq_id);
                                          
    GENERATE_MAIL_PKG.proc_generate_message('CLAIM_RECEIVED_CNH',
                                          v_claim_seq_id,
                                          v_added_by,
                                          v_dest_msg_seq_id);*/
                                          
  IF V_CLAIM_TYPE = 'CTM' THEN
    GENERATE_MAIL_PKG.proc_generate_message('CLAIM_MR_RECEIVED',
                                          v_claim_seq_id,
                                          v_added_by,
                                          v_dest_msg_seq_id);
  END IF;
  commit;
  
END save_clm_details;
--===============================================================================

PROCEDURE calculate_authorization(v_claim_seq_id               IN  clm_authorization_details.claim_seq_id%type,
                                  v_hosp_seq_id                IN  clm_hospital_details.hosp_seq_id%TYPE,
                                  v_allowed_amount             OUT clm_authorization_details.tot_allowed_amount%type,
                                  v_result_set                 OUT SYS_REFCURSOR,
                                  v_added_by                   IN  NUMBER
                                  )
IS

v_patient_share_amt Pat_Activity_Details.Patient_Share_Amount%TYPE;
v_approved_amount   Pat_Activity_Details.Approved_Amount%TYPE;
v_allowed_amt       Pat_Activity_Details.Allowed_Amount%TYPE;
v_Copay_amnt        NUMBER(10,2);
v_Patient_share     NUMBER(10,2);
v_Net_amnt          NUMBER(10,2);
v_Allowed_amnt      NUMBER(10,2);
v_Approved_amnt     NUMBER(10,2);
v_Disallowed_amnt   NUMBER(10, 2);
v_copay_perc        NUMBER;
v_non_network_co_pay NUMBER;

CURSOR act_cur IS
SELECT SUM(NVL(pa.gross_amount,0)) as tot_gross_amount
      ,SUM(NVL(pa.discount_amount,0)) as tot_discount_amount
      ,SUM(NVL(pa.disc_gross_amount,0)) as tot_disc_gross_amount
      ,SUM(NVL(pa.patient_share_amount,0)) as tot_patient_share_amount
      ,SUM(NVL(pa.net_amount,0)) as tot_net_amount
      ,SUM(NVL(pa.allowed_amount,0)) as tot_allowed_amount
      ,SUM(NVL(pa.approved_amount,0)) as tot_approved_amount
      ,SUM(NVL(pa.ucr, 0))            as tot_ucr_amount
      ,SUM(NVL(pa.out_of_pocket_amount,0)) as manual_disallow_amt
 FROM pat_activity_details pa
WHERE pa.claim_seq_id=v_claim_seq_id;

 CURSOR clm_cur IS
  SELECT cad.denial_reason,cad.parent_claim_seq_id,cad.denial_code,cad.remarks,cad.completed_yn,cad.member_seq_id,cad.pat_auth_seq_id,
     to_date(cad.date_of_hospitalization,'dd/mm/rrrr') as hospitalization_date,cad.claim_type,cad.network_yn,
     cad.benifit_type,cad.hlt_chkp_copay_perc,cad.hlt_chkp_deductbl,cad.hlt_chkp_cpay_deduct_flag,
	 CASE  WHEN cad.duration_flag = 'DAYS'  THEN CASE WHEN  cad.DUR_AILMENT > (cad.date_of_hospitalization-mem.date_of_inception) THEN 'Y' ELSE 'N' END 
           WHEN cad.duration_flag = 'MONTHS' THEN CASE WHEN cad.DUR_AILMENT> trunc(months_between(cad.date_of_hospitalization,mem.date_of_inception)) THEN 'Y' ELSE 'N' END
           WHEN cad.duration_flag = 'YEARS' THEN CASE WHEN cad.DUR_AILMENT> trunc(months_between(cad.date_of_hospitalization,mem.date_of_inception)/12) THEN 'Y' ELSE 'N' END END AS PED,
     to_date(cad.date_of_discharge,'dd/mm/rrrr') as date_of_discharge,cad.req_amt_currency_type,
     cad.conversion_rate,NVL(cad.process_type,'RGL') AS process_type,cad.system_of_medicine_type_id as sys_med,
     NVL(CAD.MAT_COMPLCTON_YN,'N') AS MAT_COMPLCTON_YN,
     cad.encounter_type_id,
     cad.tpa_enrollment_id,
     cad.policy_seq_id     
     FROM clm_authorization_details cad
     JOIN tpa_enr_policy_member mem ON (cad.member_seq_id=mem.member_seq_id)     
     WHERE cad.claim_seq_id=v_claim_seq_id;

CURSOR enrol_type IS
select ep.enrol_type_id,ep.policy_seq_id,pm.vip_yn,(ad.requested_amount-nvl(ad.tot_patient_share_amount,0)) as net_amount 
from app.tpa_enr_policy ep 
join app.clm_authorization_details ad on (ep.policy_seq_id=ad.policy_seq_id)
join app.tpa_enr_policy_member pm on (pm.member_seq_id = ad.member_seq_id)
where ad.claim_seq_id=v_claim_seq_id;   


enrol_rec                  enrol_type%rowtype;  
act_rec                    act_cur%ROWTYPE;
clm_rec                    clm_cur%ROWTYPE;
v_remarks                  varchar2(100);
v_chronic_count            number(10);
v_pre_approval_limit_yn    varchar2(1);
v_pre_approval_limit       number(10);
v_pre_aprvl_mdt_srvc_yn    varchar2(1);
v_pat_yn                   varchar2(1):='N';
--v_hosp_seq_id        number(10);
v_fina_allowed_amount    number;
v_ri_copar number;
v_xml xmltype;   ---- Copar Value
cnt number;
v_copar_val NUMBER;
v_flage CHAR(1);
v_check_ricopar_yn   CHAR(1);
v_ucr_flag           varchar2(1);
-- Cursor for fetch IR-COPAR VAlue from xml file

CURSOR check_flag_cur IS
   SELECT C.RI_COPAR_FLAG AS RI_COPAR_FLAG,c.ucr_flag 
   FROM CLM_AUTHORIZATION_DETAILS C
   WHERE C.CLAIM_SEQ_ID = v_claim_seq_id;

cursor ir_cur (v_Prod_Policy_Rule_Seq_Id NUMBER) is
  select extractValue(value(li), '/condition/@dynValue') v_ri_copar
   from app.tpa_ins_prod_policy_rules,
       table(XMLSequence(extract(PROD_POLICY_RULE,
                                 'clauses/clause[@name="Ri-Copar"]//condition'))) li
  where existsNode(PROD_POLICY_RULE, 'clauses/clause[@name="Ri-Copar"]') = 1
  and prod_policy_rule_seq_id = v_Prod_Policy_Rule_Seq_Id;
 
 c2 ir_cur%rowtype;
 
 CURSOR cond_fun_phy IS
  SELECT  d.cond_fun  AS cond_fun
  FROM tpa_ins_prod_pol_clauses B
  JOIN tpa_ins_prod_pol_coverages C
    ON (b.clause_seq_id = c.clause_seq_id)
  JOIN tpa_ins_prod_pol_conditions D
    ON (c.coverage_seq_id = d.coverage_seq_id)
 where B.prod_policy_rule_seq_id= v_Prod_Policy_Rule_Seq_Id
 --AND d.cond_val = 'A|'||'97001'
 and b.clause_id!='cls.1'
 and d.cond_fun like '%check_op_physiotherapy%';
 
 c3 cond_fun_phy%ROWTYPE;
 
 cursor cur_ucr  is
    select 
       ad.activity_dtl_seq_id,
       ad.ucr,
       ad.ri_copar,
       clm.ucr_flag,
       clm.ri_copar_flag,
       ad.copay_deduct_flag,
       clm.claim_seq_id,
       ad.copay_perc,
       ad.copay_amount,
       AD.DISC_GROSS_AMOUNT,
       ad.benifit_deductible,
       ad.rule_limit,
       ad.approved_amount,
       ad.copy_max_flag,
       ad.benifit_copay,
       ad.non_network_co_pay,     ----
       ad.approvd_quantity,
       ad.quantity,
       case when length(ad.code)>15 then 'Y' else 'N' end as parmcy_yn
      from pat_activity_details ad
      left join clm_authorization_details clm          on (clm.claim_seq_id = ad.claim_seq_id)
      left outer join tpa_activity_master_details tamd on (ad.code=tamd.activity_code)
      left outer join tpa_pharmacy_master_details md on (md.activity_code =ad.code)
      left outer join tpa_denial_codes tdc on (ad.denial_code=tdc.denial_code)
     where ad.claim_seq_id =v_claim_seq_id
     order by s_no;
     
  CURSOR cur_corp_pol(vip_yn varchar2) IS
   SELECT case when nvl(vip_yn,'N')='Y' then gt.vip_pre_aprvl_limit_yn else gt.non_vip_pre_aprvl_limit_yn end as pre_aprvl_limit_yn,
          case when nvl(vip_yn,'N')='Y' then gt.vip_pre_aprvl_limit else gt.non_vip_pre_aprvl_limit end as pre_aprvl_limit,
          case when nvl(vip_yn,'N')='Y' then gt.vip_mdt_srvce_pre_aprvl_yn else gt.non_vip_mdt_srvce_pre_aprvl_yn end as pre_aprvl_mdt_srvc_yn  
        FROM tpa_enr_policy GH
        JOIN tpa_ins_prod_policy GT ON (GH.policy_seq_id=GT.policy_seq_id)
     WHERE GH.policy_seq_id=enrol_rec.policy_seq_id;
     
  CURSOR cur_ind_pol(vip_yn varchar2) IS   
     SELECT case when nvl(vip_yn,'N')='Y' then tipp.vip_pre_aprvl_limit_yn else tipp.non_vip_pre_aprvl_limit_yn end as pre_aprvl_limit_yn,
            case when nvl(vip_yn,'N')='Y' then tipp.vip_pre_aprvl_limit else tipp.non_vip_pre_aprvl_limit end as pre_aprvl_limit,
            case when nvl(vip_yn,'N')='Y' then tipp.vip_mdt_srvce_pre_aprvl_yn else tipp.non_vip_mdt_srvce_pre_aprvl_yn end as pre_aprvl_mdt_srvc_yn
     FROM tpa_enr_policy tep
     LEFT OUTER JOIN tpa_ins_product tip on (tip.product_seq_id=tep.product_seq_id)
     LEFT OUTER JOIN tpa_ins_prod_policy tipp on (tipp.product_seq_id=tip.product_seq_id)
     WHERE tep.policy_seq_id=enrol_rec.policy_seq_id; 
  
  CURSOR upd_pharma_cur IS
    Select code, pa.activity_seq_id
    From pat_activity_details pa
    Join clm_authorization_details cl ON (cl.claim_seq_id = pa.claim_seq_id)
    Where cl.claim_seq_id = v_claim_seq_id
    And pa.code  = 'PHARMA';
    
  CURSOR Claim_General_details IS
     SELECT c.benifit_type,c.policy_seq_id 
       FROM CLM_AUTHORIZATION_DETAILS C
       WHERE C.CLAIM_SEQ_ID=v_claim_seq_id; 
    
    cursor exclude_auth_001_cur is           
    select distinct(nvl(tad.master_activity_code,tamd.master_activity_code)) as master_Activity_code,  pad.ACTIVITY_DTL_SEQ_ID,pad.code,pad.DENIAL_CODE,nvl(tad.service_seq_id,tamd.service_seq_id) as service_seq_id 
                   from clm_authorization_details clm join pat_activity_details pad on (clm.claim_seq_id=pad.claim_seq_id) 
                                                      left join APP.TPA_ACTIVITY_DETAILS tad on (pad.code = tad.ACTIVITY_CODE)
                                                      left join APP.TPA_ACTIVITY_MASTER_DETAILS tamd on (pad.code = tamd.ACTIVITY_CODE) 
                                                      where clm.claim_seq_id =v_claim_seq_id;
 
 upd_pharma_rec   upd_pharma_cur%ROWTYPE; 
  
 CURSOR Claim_Submission_Type IS
   SELECT bat.submission_type_id,cad.benifit_type 
     FROM CLM_AUTHORIZATION_DETAILS CAD
     JOIN CLM_BATCH_UPLOAD_DETAILS BAT ON (CAD.CLM_BATCH_SEQ_ID=BAT.CLM_BATCH_SEQ_ID)
     WHERE CAD.CLAIM_SEQ_ID=v_claim_seq_id;
     
  CURSOR op_cons_cnt IS
      SELECT COUNT(1)
                 FROM  APP.PAT_ACTIVITY_DETAILS A
                 JOIN  APP.TPA_ACTIVITY_MASTER_DETAILS B ON (A.CODE=B.ACTIVITY_CODE)
                 WHERE A.CLAIM_SEQ_ID = v_claim_seq_id 
                 AND B.MASTER_ACTIVITY_CODE = '9' 
                 AND NVL(A.OVERRIDE_YN,'N') = 'N';			   
 v_op_cons_cnt   number(10);
 
 CURSOR HOSP_PRSNT_CUR 
 IS
 SELECT hosp_seq_id
 FROM APP.clm_hospital_details A
 WHERE A.CLAIM_SEQ_ID = v_claim_seq_id;
 
 v_hosp_id        tpa_hosp_info.hosp_seq_id%type; 
 
 CURSOR GET_RESUBMISSION_TIME (v_clm_num  NUMBER)IS  
  SELECT * FROM (SELECT CAD.CLAIM_SEQ_ID,LEVEL AS LV
        FROM CLM_AUTHORIZATION_DETAILS CAD 
         START WITH CAD.CLAIM_SEQ_ID=v_clm_num
        CONNECT BY CAD.CLAIM_SEQ_ID=PRIOR CAD.PARENT_CLAIM_SEQ_ID
         ORDER BY LEVEL DESC); 
         
 GET_RESUBMISSION_TIME_REC         GET_RESUBMISSION_TIME%ROWTYPE;    
 v_ucr_amount cur_ucr%ROWTYPE;
 v_patient_share_amount number;
 v_net_amt number;
 v_ucr  number;     ----
 v_appr_amt number;
 v_copay   number;
 v_benifit_final_deduct     NUMBER(16,2):=0;
 v_seq_id                   NUMBER(10);
 v_act_count                NUMBER;
 v_benefit_type             VARCHAR2(30);
 v_policy_seq_id            NUMBER(30);
 v_submission_type          VARCHAR2(30);
 v_benifit_type             VARCHAR2(30);
 v_drug_cnt                 NUMBER(3);
 
BEGIN

authorization_pkg.reassign_user(null,'|'||v_claim_seq_id||'|',null,v_added_by,null,v_seq_id);

    
    OPEN clm_cur;
    FETCH clm_cur INTO clm_rec;
    CLOSE clm_cur;
    
    IF nvl(clm_rec.Completed_Yn,'N')='Y' THEN
        RAISE_APPLICATION_ERROR(-20107,'You cannot perform this action through a completed Claim.');
    END IF;
    
    OPEN HOSP_PRSNT_CUR;
    FETCH HOSP_PRSNT_CUR INTO v_hosp_id;
    CLOSE HOSP_PRSNT_CUR;
     
    OPEN enrol_type;
    FETCH enrol_type INTO enrol_rec;
    CLOSE enrol_type;
    
    OPEN upd_pharma_cur;
    FETCH upd_pharma_cur INTO upd_pharma_rec;
    CLOSE upd_pharma_cur;
    
    IF upd_pharma_rec.code = 'PHARMA' AND upd_pharma_rec.activity_seq_id IS NULL THEN
      Update pat_activity_details p
      Set p.activity_seq_id = (Select md.act_mas_dtl_seq_id
                               From tpa_activity_master_details md
                               Where md.activity_code = 'PHARMA'
                              )
      Where p.code = 'PHARMA'
      And p.claim_seq_id = v_claim_seq_id;
    END IF;
    
    
     IF enrol_rec.enrol_type_id='IND' THEN
       v_prod_policy_rule_seq_id:=authorization_pkg.get_prod_pol_seq_id(enrol_rec.policy_seq_id,'IND');
     ELSE
       v_prod_policy_rule_seq_id:=authorization_pkg.get_prod_pol_seq_id(enrol_rec.policy_seq_id,'POL');
     END IF; 
    
  IF enrol_rec.policy_seq_id IS NOT NULL THEN  
   IF enrol_rec.enrol_type_id='COR' THEN
     OPEN  cur_corp_pol(enrol_rec.vip_yn);
     FETCH cur_corp_pol INTO v_pre_approval_limit_yn,v_pre_approval_limit,v_pre_aprvl_mdt_srvc_yn;
     CLOSE cur_corp_pol;
   ELSE
     OPEN  cur_ind_pol(enrol_rec.vip_yn);
     FETCH cur_ind_pol INTO v_pre_approval_limit_yn,v_pre_approval_limit,v_pre_aprvl_mdt_srvc_yn;
     CLOSE cur_ind_pol;
  END IF;
 END IF;
    
    IF clm_rec.claim_type='CNH' and nvl(v_pre_approval_limit_yn,'N')='Y' and enrol_rec.net_amount<= v_pre_approval_limit THEN
      v_pat_yn:='N';
    ELSE 
      v_pat_yn:='Y';
    END IF;
      update pat_activity_details ad
      set 
      ad.denial_code= case when (nvl(ad.override_yn,'N')='N' and ad.denial_code is not null) then null 
                          when (nvl(ad.override_yn,'N')='Y' and ad.denial_code is not null) then ad.denial_code else null end,
      ad.remarks=null,
      ad.denial_desc=case when (nvl(ad.override_yn,'N')='N' and ad.denial_code is not null) then null
                          when (nvl(ad.override_yn,'N')='Y' and ad.denial_code is not null) then ad.denial_desc else null end,
      ad.patient_share_amount=null/*case when nvl(ad.override_yn,'N')='N' then 0 else ad.patient_share_amount end*/,
      ad.allowed_amount=null,
      ad.approved_amount=null,ad.copay_perc=null,
      ad.benifit_copay=null, ad.benifit_deductible = null, ad.copay_amount=null,ad.rule_limit=null,
      ad.approvd_quantity = case when nvl(ad.phy_yn,'N')='Y' then ad.quantity else ad.approvd_quantity end,
      ad.denial_by_rule_cond_id_dtls = NULL,
      ad.denial_by_rule_proc_dtls = NULL,
      ad.denial_by_resons = NULL,
	    ad.provider_copay=null,
      ad.deduct_amount=null, 
      ad.Prov_Copay_flag=null,
      ad.Prov_Copay_Perc=null,
      ad.copay_deduct_flag=null
      where ad.claim_seq_id=v_claim_seq_id;/* and nvl(ad.override_yn,'N')='N'*/ 
      
      update diagnosys_details dd 
      set dd.denial_reason=null,
          dd.remarks=null,dd.rule_limit=null,dd.rule_copay=null,dd.deduct=0,dd.copay=null,
          dd.copay_persent = NULL,dd.copay_limit=null
       where dd.claim_seq_id=v_claim_seq_id;
       
      update clm_authorization_details pad
      set pad.benefit_limit=null,
          pad.benefit_copay=null,
          pad.tot_allowed_amount=null,
          pad.tot_approved_amount=null,
          pad.tot_patient_share_amount=null,
		  pad.sys_med_yn = null,
		  pad.sys_med_limit=null,
          pad.area_cover_yn = NULL,
          pad.area_cov_rule_reg_id = NULL,
          pad.area_rule_limit = NULL,
          pad.out_area_cover_yn = NULL,
          pad.out_area_cov_rule_reg_id = NULL,
          pad.in_out_area_covr_yn = NULL,
          pad.in_out_amnt_perc = NULL,
		  pad.MATERNITY_YN = null,
          pad.deductable = NULL
          where pad.claim_seq_id = v_claim_seq_id;
     
   
    IF clm_rec.Denial_Reason is not null or clm_rec.denial_code is not null THEN
      for i in exclude_auth_001_cur loop
           UPDATE pat_activity_details pad
               SET pad.denial_desc  =case when (i.master_activity_code in ('9','9.01','63') or (i.service_seq_id=14 and i.master_activity_code='0000-000000-0000')) AND (clm_rec.denial_code like '%AUTH-001%')  then ttk_util_pkg.replace_fun('AUTH-001', clm_rec.denial_code,clm_rec.Denial_Reason) else clm_rec.Denial_Reason  end,
                   pad.denial_code  =case when (i.master_activity_code in ('9','9.01','63') or (i.service_seq_id=14 and i.master_activity_code='0000-000000-0000')) AND (clm_rec.denial_code like '%AUTH-001%') then  ttk_util_pkg.replace_fun('AUTH-001', clm_rec.denial_code,clm_rec.denial_code) else clm_rec.denial_code end,
                   pad.remarks      =case when (i.master_activity_code in ('9','9.01','63') or (i.service_seq_id=14 and i.master_activity_code='0000-000000-0000')) AND (clm_rec.denial_code like '%AUTH-001%') then  ttk_util_pkg.replace_fun('AUTH-001', clm_rec.denial_code,clm_rec.remarks) else clm_rec.remarks end,
                   pad.tpa_denial_desc  =case when (i.master_activity_code in ('9','9.01','63') or (i.service_seq_id=14 and i.master_activity_code='0000-000000-0000')) AND (clm_rec.denial_code like '%AUTH-001%')  then ttk_util_pkg.replace_fun('AUTH-001', clm_rec.denial_code,clm_rec.Denial_Reason) else clm_rec.Denial_Reason  end,
                   pad.tpa_denial_code  =case when (i.master_activity_code in ('9','9.01','63') or (i.service_seq_id=14 and i.master_activity_code='0000-000000-0000')) AND (clm_rec.denial_code like '%AUTH-001%') then  ttk_util_pkg.replace_fun('AUTH-001', clm_rec.denial_code,clm_rec.denial_code) else clm_rec.denial_code end,
                   pad.updated_by   = v_added_by,
                   pad.updated_date = SYSDATE,
                   pad.denial_by_rule_proc_dtls = TRIM(BOTH ';' FROM (pad.denial_by_rule_proc_dtls||';'||CHR(10)||'claim_pkg.calculate_authorization'))
             WHERE pad.claim_seq_id = v_claim_seq_id and nvl(pad.override_yn,'N')='N'and pad.activity_dtl_seq_id = i.activity_dtl_seq_id;                     
    end loop;
    end if; 
    commit; 
    
  /*  select count(1) into v_chronic_count
     from app.clm_authorization_details d 
     join app.diagnosys_details dd on (d.claim_seq_id=dd.claim_seq_id and d.benifit_type='OPTS')
    join app.tpa_day_care_icd c on (c.icd_code=dd.diagnosys_code AND dd.primary_ailment_yn='Y')
     where d.claim_seq_id=v_claim_seq_id;*/
     
    --chronic count, we are not using Commented by venu ,commented on 26/02/2019
    
    --pat_xml_load_pkg.check_ddc_rule(v_claim_seq_id,'CLM',v_added_by); 
    pat_xml_load_pkg.check_lmrp_rules(v_claim_seq_id,'CLM',v_added_by);-- comented as per Dr.yasmin/ Enabled on 19th Aug 2017
    pat_xml_load_pkg.check_ncci_hosp_phy_rules(v_claim_seq_id,v_hosp_seq_id,'CLM',v_added_by);
    --pat_xml_load_pkg.check_mue_rules(v_claim_seq_id,'CLM',v_added_by);--comented as per Dr.yasmin
    pat_xml_load_pkg.execute_diag_rule(v_claim_seq_id,'CLM' ,v_prod_policy_rule_seq_id  ,v_added_by);     
    pat_xml_load_pkg.execute_sec_icd_mat_rule(v_claim_seq_id,'CLM' ,v_prod_policy_rule_seq_id  ,v_added_by); --- ( gender validation for Maternity secondary ICD)CR062CR0179     
    IF clm_rec.MAT_COMPLCTON_YN = 'Y' THEN
     pat_xml_load_pkg.exec_mat_comp_rule(v_claim_seq_id,'CLM' ,v_prod_policy_rule_seq_id  ,v_added_by); 
    END IF;
    
    --if v_chronic_count=0 then
    pat_xml_load_pkg.execute_activity_rule(v_claim_seq_id,'CLM'  ,v_prod_policy_rule_seq_id  ,v_added_by  );        
    pat_xml_load_pkg.check_duplicate_activity(v_claim_seq_id,'CLM',v_added_by);
    --end if;
    pat_xml_load_pkg.check_add_on_rules(v_claim_seq_id,'CLM',v_added_by);
    IF clm_rec.claim_type='CNH' AND clm_rec.process_type != 'DBL' THEN 
    pat_xml_load_pkg.check_tariff_rule(v_claim_seq_id,'CLM',v_added_by);
    end if;
    IF v_pat_yn='Y' and clm_rec.claim_type='CNH' and clm_rec.pat_auth_seq_id is not null THEN
    pat_xml_load_pkg.check_network_clm_rule(v_claim_seq_id,v_added_by);
    END IF;
    
    IF NVL(v_pre_aprvl_mdt_srvc_yn,'N') ='Y' AND clm_rec.claim_type='CNH' and clm_rec.pat_auth_seq_id is null THEN
     pat_xml_load_pkg.execute_pre_aprvl_rule(v_claim_seq_id,v_added_by);
    END IF;
    
    IF clm_rec.ped='Y' THEN
    pat_xml_load_pkg.execute_ped_rule(v_claim_seq_id ,'CLM' ,v_prod_policy_rule_seq_id ,V_ADDED_BY );
    END IF;
    
    IF clm_rec.sys_med !='SAL' THEN
    pat_xml_load_pkg.execute_sys_medicine(v_claim_seq_id ,'CLM' ,v_prod_policy_rule_seq_id ,v_added_by);
    END IF;	
 
    pat_xml_load_pkg.check_physiotherapy_pd(v_claim_seq_id,'CLM',v_added_by);
    
    
    select count(1) into v_drug_cnt
     from pat_activity_details d 
     where d.claim_seq_id=v_claim_seq_id and d.activity_type=5;
    
    -----++++++Clinical Rules ++++++++++++++++++++++++++++++
    IF clm_rec.encounter_type_id not in (3,4) and v_drug_cnt>0 THEN
    hosp_pbm_pkg.check_mdcl_necessity_rules_1(v_claim_seq_id,'CLM',v_added_by);	
    hosp_pbm_pkg.check_therapeutic_rule_2(v_claim_seq_id,'CLM',v_added_by);
    hosp_pbm_pkg.check_ci_icd_ddc_rules_3(v_claim_seq_id,'CLM',v_added_by);
    hosp_pbm_pkg.check_ci_ddc_ddc_rules_3(v_claim_seq_id,'CLM',v_added_by);
    hosp_pbm_pkg.check_age_band_rule_4(v_claim_seq_id,'CLM',v_added_by);
    hosp_pbm_pkg.check_gender_rule_5(v_claim_seq_id,'CLM',v_added_by);
    hosp_pbm_pkg.priliminary_check_rule_6(v_claim_seq_id,'CLM',v_added_by);
    hosp_pbm_pkg.check_refill_to_soon_7(v_claim_seq_id,'CLM' ,CLM_rec.member_seq_id,v_added_by);
    hosp_pbm_pkg.check_mat_icd_ddc_rule_8(v_claim_seq_id,'CLM',v_added_by);
    END if;
    ----++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
   IF clm_rec.benifit_type = 'DNTL' THEN
      /*select count(1) into v_act_count
      from pat_activity_details p
      join dental_rule_tab d on d.cdt_code = p.code
      where p.claim_seq_id = v_claim_seq_id;*/
      
      IF nvl(v_act_count, 0) = 0 THEN
        authorization_pkg.check_overal_limit(v_claim_seq_id, 'CLM', v_prod_policy_rule_seq_id);
      END IF;
   END IF;
    ----- FREE FOLLOW UP PERIOD FOR ACTIVITY WISE AND CONSULATION 
    IF  UPPER(clm_rec.benifit_type) in ('OMTI','OPTS') THEN
          OPEN op_cons_cnt;
          FETCH op_cons_cnt INTO v_op_cons_cnt;
          CLOSE op_cons_cnt;
        IF v_op_cons_cnt > 0 THEN 
         pat_xml_load_pkg.cons_followup_period (v_claim_seq_id,'CLM',v_prod_policy_rule_seq_id,clm_rec.policy_seq_id,clm_rec.member_seq_id,v_hosp_id,clm_rec.benifit_type,clm_rec.tpa_enrollment_id,clm_rec.hospitalization_date,v_added_by);
        END IF;
      pat_xml_load_pkg.act_followup_period(v_claim_seq_id,'CLM',clm_rec.policy_seq_id,clm_rec.member_seq_id,v_hosp_id,clm_rec.tpa_enrollment_id,clm_rec.hospitalization_date,v_added_by);
    END IF;
     
   ----++++++
    pat_xml_load_pkg.calculate_allowed_amount(v_claim_seq_id,'CLM');
   IF clm_rec.claim_type='CNH' THEN
   pat_xml_load_pkg.check_pat_amounts_in_clm(v_claim_seq_id,v_added_by);
   pat_xml_load_pkg.check_vip_nvip_limit(v_claim_seq_id,v_added_by,clm_rec.claim_type,clm_rec.pat_auth_seq_id);
   END IF;
    OPEN  act_cur;
    FETCH act_cur INTO act_rec;
    CLOSE act_cur;
    
    UPDATE clm_authorization_details A
    SET a.tot_gross_amount           = act_rec.tot_gross_amount,
        a.tot_discount_amount        = act_rec.tot_discount_amount,
        a.tot_disc_gross_amount      = act_rec.tot_disc_gross_amount,
        a.tot_patient_share_amount   = act_rec.tot_patient_share_amount,
        a.tot_net_amount             = act_rec.tot_net_amount,
        a.tot_allowed_amount         = act_rec.tot_allowed_amount,
        a.tot_approved_amount        = act_rec.tot_approved_amount
        --a.clm_status_type_id         = 'INP' 
   WHERE a.Claim_Seq_Id           = v_claim_seq_id
   RETURNING a.tot_allowed_amount INTO v_allowed_amount;
  
 
 -- authorization_pkg.check_activity_limits(v_claim_seq_id,'CLM',null,v_added_by,v_remarks,v_fina_allowed_amount);

---commented on 19/02/2019 in Qatar we are not using ri copar & ucr flag (Venu)
/*  
  OPEN check_flag_cur;
  FETCH check_flag_cur INTO v_check_ricopar_yn,v_ucr_flag;
  CLOSE check_flag_cur;
  
  OPEN cond_fun_phy;
  FETCH cond_fun_phy INTO c3;
  CLOSE cond_fun_phy;
  
  --IF c3.cond_fun not like 'check_op_physiotherapy%' THEN--
  
  IF clm_rec.claim_type='CTM' and nvl(clm_rec.network_yn,'N')='Y' 
    and (nvl(v_check_ricopar_yn,'N')='Y' or nvl(v_ucr_flag,'N')='Y') THEN 
  ----------============-----------
  OPEN ir_cur(v_Prod_Policy_Rule_Seq_Id);
  FETCH ir_cur INTO c2;
  CLOSE ir_cur;
  
  
   v_copar_val := CASE WHEN v_check_ricopar_yn = 'Y' THEN REGEXP_Replace(c2.v_ri_copar,'[^0-9]') ELSE 0 END;
   
   UPDATE pat_activity_details pad
      SET pad.ri_copar  = v_copar_val
   WHERE pad.claim_seq_id  = v_claim_seq_id
   AND pad.claim_seq_id = v_claim_seq_id;
   
   OPEN  act_cur;
    FETCH act_cur INTO act_rec;
    CLOSE act_cur;
    
    UPDATE clm_authorization_details A
    SET a.tot_gross_amount           = act_rec.tot_gross_amount,
        a.tot_discount_amount        = act_rec.tot_discount_amount,
        a.tot_disc_gross_amount      = act_rec.tot_disc_gross_amount,
        a.tot_patient_share_amount   = act_rec.tot_patient_share_amount,
        a.tot_net_amount             = act_rec.tot_net_amount,
        a.tot_allowed_amount         = act_rec.tot_allowed_amount, 
        a.tot_approved_amount        = act_rec.tot_approved_amount,
        a.final_app_amount           = act_rec.tot_allowed_amount
        --a.clm_status_type_id         = 'INP' 
   WHERE a.Claim_Seq_Id           = v_claim_seq_id
   RETURNING a.tot_allowed_amount INTO v_allowed_amount;
       
   
  --------================----------    
  UPDATE pat_activity_details pad
               SET pad.denial_desc  = replace(pad.denial_desc,';;',';')
                   WHERE pad.claim_seq_id = v_claim_seq_id;
  
 
 -- UCR AND RI-COPAR CALCULATION---
  ---------------------------------------
  
 
   FOR i IN cur_ucr LOOP
    
  IF i.ucr_flag = 'Y' AND i.ri_copar_flag = 'Y' THEN
    --v_copay_perc := i.copay_amount/i.disc_gross_amount * 100;
    IF nvl(i.ucr, 0) = 0 then
      v_Copay_amnt := 0;
    ELSE
      
      v_Copay_amnt := i.ucr * i.benifit_copay/100;
    END IF;
  
  IF i.copay_deduct_flag = 'MIN' THEN
    
     ---- for non_network co_pay ----
   v_ucr := nvl(i.ucr,0) - nvl(least( i.benifit_deductible,v_Copay_amnt ),0);
   v_non_network_co_pay := nvl(nvl(v_ucr,0) * nvl(i.non_network_co_pay,0),0)/100;
   ---------------------------------- 
    
    v_Patient_share       := least( i.benifit_deductible,v_Copay_amnt ) + v_non_network_co_pay;       ----
    v_Patient_share       := case when i.ucr <= 0 then
                                0
                              else
                                case when (((i.ucr-NVL(v_Patient_share, 0))*(nvl(i.ri_copar,0)/100))+ NVL(v_Patient_share, 0)) <= 0 then
                                  0
                                else
                                  (((i.ucr-NVL(v_Patient_share, 0))*(nvl(i.ri_copar,0)/100))+ NVL(v_Patient_share, 0))
                                end
                              end;
  
  ELSIF i.copay_deduct_flag = 'MAX' THEN
   ---- for non_network co_pay ----
   v_ucr := nvl(i.ucr,0) - nvl(greatest( i.benifit_deductible,v_Copay_amnt ),0);
   v_non_network_co_pay := nvl(nvl(v_ucr,0) * nvl(i.non_network_co_pay,0),0)/100;
   ---------------------------------- 
    v_Patient_share       := greatest( i.benifit_deductible,v_Copay_amnt ) + v_non_network_co_pay; ----
    v_Patient_share       := case when i.ucr <= 0 then
                               0
                             else
                               case when (((i.ucr-NVL(v_Patient_share, 0))*(nvl(i.ri_copar,0)/100))+ NVL(v_Patient_share, 0)) <= 0 then
                                 0
                               else
                                (((i.ucr-NVL(v_Patient_share, 0))*(nvl(i.ri_copar,0)/100))+ NVL(v_Patient_share, 0))
                               end
                             end;
  
  
  ELSE
    IF nvl(i.ucr, 0) = 0 then
      v_copay_perc := 0;
    ELSE 
      v_copay_perc := i.copay_amount/i.disc_gross_amount * 100;--
    END IF;
    
    v_Copay_amnt := case when i.parmcy_yn ='Y' then 
    case when nvl(i.copy_max_flag,'N')='N' then 
      i.ucr * nvl(i.benifit_copay,v_copay_perc)/100 nvl(i.copay_perc, i.benifit_copay)/100 
      else i.copay_amount end
    else i.ucr * nvl(i.benifit_copay,0)/100 
    end;
    --v_Patient_share   := (i.copay_amount) + ((i.ucr - i.copay_amount) * i.ri_copar/100);
     ---- for non_network co_pay ----
   v_ucr := nvl(i.ucr,0) - nvl(v_Copay_amnt,0);
   v_non_network_co_pay := nvl(nvl(v_ucr,0) * nvl(i.non_network_co_pay,0),0)/100;
   ----------------------------------  
   v_Patient_share := case when  (((i.ucr - v_Copay_amnt) - v_non_network_co_pay) * nvl(i.ri_copar,0)/100)<= 0 then  ----
                         0 --+ v_non_network_co_pay ----
                       else
                         v_Copay_amnt + (((i.ucr - v_Copay_amnt) - v_non_network_co_pay) * nvl(i.ri_copar,0)/100) + v_non_network_co_pay   ----
                       end;
  END IF;  

  v_Net_amnt                :=  CASE WHEN i.ucr-NVL(v_Patient_share, 0) <= 0 THEN
                                  0
                                ELSE
                                  i.ucr- NVL(v_Patient_share, 0)
                                END;
  v_Allowed_amnt            := case when i.copay_amount > i.ucr or i.approved_amount <= 0 then
                                 0
                               else 
                                 NVL(v_Net_amnt, 0) end;
  v_Approved_amnt           := case when i.copay_amount > i.ucr or i.approved_amount <= 0 then
                                 0
                               else v_Net_amnt end;
  v_Disallowed_amnt         := case when i.DISC_GROSS_AMOUNT - i.ucr <= 0 then
                                 0
                               else
                                 i.DISC_GROSS_AMOUNT - i.ucr
                               end;



 ELSIF i.ucr_flag = 'Y' AND i.ri_copar_flag = 'N' THEN 
 
  IF i.copay_deduct_flag = 'MIN' THEN
   IF i.ucr = 0 THEN
     v_Copay_amnt := 0;
   ELSE
     
    v_Copay_amnt       := i.ucr * i.benifit_copay/100;
   END IF;
   ---- for non_network co_pay ----
   v_ucr := nvl(i.ucr,0) - nvl(least(v_Copay_amnt, i.benifit_deductible),0);
   v_non_network_co_pay := nvl(nvl(v_ucr,0) * nvl(i.non_network_co_pay,0),0)/100;
   ----------------------------------  
    v_Patient_share    := least(v_Copay_amnt, i.benifit_deductible) + v_non_network_co_pay;--(least( i.benifit_copay,v_Copay_amnt));
    
  ELSIF i.copay_deduct_flag = 'MAX' THEN
   IF i.ucr = 0 THEN
     v_Copay_amnt := 0;
   ELSE
    v_Copay_amnt      := i.ucr * i.benifit_copay/100;
   END IF;
    ---- for non_network co_pay ----
   v_ucr := nvl(i.ucr,0) - nvl(greatest(v_Copay_amnt,i.benifit_deductible),0);
   v_non_network_co_pay := nvl(nvl(v_ucr,0) * nvl(i.non_network_co_pay,0),0)/100;
   ----------------------------------
    v_Patient_share   := greatest(v_Copay_amnt,i.benifit_deductible) + v_non_network_co_pay;
  ELSE
    IF i.ucr = 0 THEN
     v_Copay_amnt := 0;
    ELSE
     v_copay_perc := i.copay_amount/i.disc_gross_amount * 100;--
     v_Copay_amnt := case when i.parmcy_yn ='Y' then case
                       when nvl(i.copy_max_flag,'N')='N' then
                         i.ucr * nvl(v_copay_perc, i.benifit_copay)/100
                       else i.copay_amount end
                     else i.ucr * nvl(i.benifit_copay,0)/100
                     end;
    ---- for non_network co_pay ----
   v_ucr := nvl(i.ucr,0) - nvl(v_Copay_amnt,0);
   v_non_network_co_pay := nvl(nvl(v_ucr,0) * nvl(i.non_network_co_pay,0),0)/100;
   ----------------------------------
     v_Patient_share := v_Copay_amnt + v_non_network_co_pay;
    END IF;
  END IF;

  v_Net_amnt                := CASE WHEN i.ucr - nvl(v_Patient_share, 0) <= 0 THEN
                                 0
                               ELSE
                                 i.ucr - nvl(v_Patient_share, 0)
                               END;
  v_Allowed_amnt            := case when i.copay_amount > i.ucr or i.approved_amount <= 0 then 0
                               else  NVL(v_Net_amnt, 0) end;
  v_Approved_amnt           := case when i.copay_amount > i.ucr or i.approved_amount <= 0 then 0
                               else v_Net_amnt end;
  v_Disallowed_amnt         := case when i.DISC_GROSS_AMOUNT - i.ucr <= 0 then
                                 0
                               else
                                 i.DISC_GROSS_AMOUNT - i.ucr
                               end;


  ELSIF i.ucr_flag = 'N' AND i.ri_copar_flag = 'Y' THEN
      
  v_appr_amt := (i.disc_gross_amount/i.quantity)*i.approvd_quantity;      
   IF i.copay_deduct_flag = 'MIN' THEN
    --v_copay_perc      := i.copay_amount/i.disc_gross_amount*100; ---abc
    v_copay           := v_appr_amt * i.benifit_copay / 100;
    v_Copay_amnt      := least(v_copay,i.benifit_deductible);--least((i.DISC_GROSS_AMOUNT* nvl(v_copay_perc, 0)/100), i.rule_limit);
    ---- for non_network co_pay ----
    --v_ucr := nvl(v_appr_am ti.disc_gross_amount,0) - nvl(least(v_Copay_amnt, i.benifit_deductible),0);
    v_ucr := nvl(v_appr_amt,0) - nvl(v_Copay_amnt, 0);  -- 600 - 20 = 580
    v_non_network_co_pay := nvl(nvl(v_ucr,0) * nvl(i.non_network_co_pay,0),0)/100; --580*10/100 = 58
    ----------------------------------
    v_Patient_share       := least(v_Copay_amnt, i.benifit_deductible) + v_non_network_co_pay;--least( i.benifit_copay,v_Copay_amnt );
    --20+58=78
    v_Patient_share       := (((v_appr_amt - NVL(v_Patient_share, 0))*(nvl(i.ri_copar,0)/100)))+v_Patient_share; --78*10/100=7.8+78=85.8
    
    
  ELSIF i.copay_deduct_flag = 'MAX' THEN
    --v_copay_perc      := i.copay_amount/i.disc_gross_amount*100;
    v_copay           := v_appr_amt * i.benifit_copay / 100;
    v_Copay_amnt      := greatest(v_copay,i.benifit_deductible);--greatest((i.DISC_GROSS_AMOUNT* nvl(v_copay_perc, 0)/100), i.rule_limit);
    ---- for non_network co_pay ----
    --v_ucr := nvl(v_appr_amt i.disc_gross_amount,0) - nvl(greatest(v_Copay_amnt, i.benifit_deductible),0);
    v_ucr := nvl(v_appr_amt,0) - nvl(v_Copay_amnt, 0);
    v_non_network_co_pay := nvl(nvl(v_ucr,0) * nvl(i.non_network_co_pay,0),0)/100;
    ----------------------------------
    v_Patient_share       := greatest(v_Copay_amnt, i.benifit_deductible) + v_non_network_co_pay;--greatest( i.benifit_copay,v_Copay_amnt );
    v_Patient_share       := (((i.DISC_GROSS_AMOUNT-NVL(v_Patient_share, 0))*(nvl(i.ri_copar,0)/100))+v_Patient_share);
  ELSE
    --v_copay           := i.copay_amount/v_appr_amt*100;
    v_Copay_amnt := case when i.copy_max_flag='N' then null else i.copay_amount end;
     ---- for non_network co_pay ----
    --v_ucr := nvl(v_appr_amti.disc_gross_amount,0) - nvl(i.copay_amount,0);
    v_ucr := nvl(v_appr_amt,0) - nvl(v_Copay_amnt,0);
    v_non_network_co_pay := nvl(nvl(v_ucr,0) * nvl(i.non_network_co_pay,0),0)/100;
    ----------------------------------
    v_Patient_share   := (i.copay_amount) + ((v_appr_amt i.disc_gross_amount - i.copay_amount - v_non_network_co_pay) * nvl(i.ri_copar,0)/100) + v_non_network_co_pay; 
    
  END IF;
  v_Net_amnt                := CASE WHEN i.Disc_Gross_Amount - nvl(v_Patient_share, 0) < 0 THEN
                                 0
                               ELSE
                                 v_appr_amt i.Disc_Gross_Amount - nvl(v_Patient_share, 0)
                               END;
  
  IF i.approved_amount <= 0 THEN
       v_Allowed_amnt := 0;
  ELSE
    IF v_Net_amnt>i.rule_limit THEN
       v_Allowed_amnt   :=  i.rule_limit;
    ELSE
       v_Allowed_amnt   :=  NVL(v_Net_amnt, 0);
    END IF;
  END IF;  
  
  --APPROVED AMOUONT
  IF i.approved_amount <= 0 THEN
     v_Approved_amnt := 0;
  ELSE
    IF v_Net_amnt > i.rule_limit THEN
       v_Approved_amnt   :=  i.rule_limit;
    ELSE
     v_Approved_amnt     := NVL(v_Allowed_amnt, 0);
    END IF;
  END IF;
   
  
  v_Disallowed_amnt       := i.DISC_GROSS_AMOUNT - NVL(v_Patient_share, 0) - NVL(v_Allowed_amnt, 0);
  
  END IF;

  
      update pat_activity_details k
         set k.copay_amount = nvl(CASE WHEN (i.ucr_flag = 'N' AND i.ri_copar_flag = 'Y') AND (i.copay_deduct_flag = 'MAX' OR i.copay_deduct_flag = 'MIN') THEN v_copay ELSE v_Copay_amnt END,k.copay_amount),
         k.patient_share_amount= nvl(v_Patient_share,k.patient_share_amount),
         k.allowed_amount = nvl(case when i.rule_limit < v_Allowed_amnt then i.rule_limit else v_Allowed_amnt end,k.allowed_amount),
         k.approved_amount = nvl(case when i.rule_limit < v_Approved_amnt then i.rule_limit else v_Approved_amnt end,k.approved_amount),
         k.net_amount= nvl(v_Net_amnt,k.net_amount),
         k.disallowed_amount = nvl(v_Disallowed_amnt,k.disallowed_amount)
       where k.activity_dtl_seq_id = i.activity_dtl_seq_id
       and k.claim_seq_id = v_claim_seq_id;

    END LOOP;
 --------------
 END IF;*/
 
  ----- FOR CLAIM RESUBMISSION RULE
 OPEN Claim_Submission_Type;
   FETCH Claim_Submission_Type INTO v_submission_type,v_benifit_type;
     CLOSE Claim_Submission_Type;
     
 OPEN GET_RESUBMISSION_TIME(v_claim_seq_id);
   FETCH GET_RESUBMISSION_TIME INTO GET_RESUBMISSION_TIME_REC;
      CLOSE GET_RESUBMISSION_TIME;
           
  pat_xml_load_pkg.check_policy_date_valid(v_claim_seq_id ,'CLM' ,v_added_by);      
  IF  v_submission_type='DTC' THEN   
      authorization_pkg.check_activity_limits(v_claim_seq_id,'CLM',null,v_added_by,v_remarks,v_fina_allowed_amount);
 END IF;
 -- Area Of Coverage Rule
 pat_xml_load_pkg.exec_area_cov_rule(v_claim_seq_id,'CLM',v_Prod_Policy_Rule_Seq_Id,v_added_by);
 --END IF;

 IF  v_submission_type='DTR' AND (GET_RESUBMISSION_TIME_REC.LV - 1 )>2  THEN   
      update pat_activity_details pad 
           set pad.remarks     = case when pad.remarks is null then 'Only 2 Resubmissions  allowed for a claim ' else pad.remarks||';'||' Only 2 Resubmissions  allowed for a claim ' end, 
           pad.denial_code = case when pad.denial_code is null then 'RECL-001' else case when pad.denial_code like '%'||'RECL-001'||'%' then pad.denial_code else pad.denial_code||';'||'RECL-001' end end,
           pad.denial_desc = case when pad.denial_desc is null then ' Only 2 Resubmissions  allowed for a claim ' else case when pad.denial_code like '%'||'RECL-001'||'%' then pad.denial_desc else pad.denial_desc||';'||'Only 2 Resubmissions  allowed for a claim ' end end,
           pad.tpa_denial_code = case when pad.tpa_denial_code is null then 'RECL-001' else case when pad.tpa_denial_code like '%'||'AUTH-005'||'%' then pad.tpa_denial_code else pad.tpa_denial_code||';'||'RECL-001' end end,
           pad.tpa_denial_desc = case when pad.tpa_denial_desc is null then ' Only 2 Resubmissions  allowed for a claim ' else case when pad.tpa_denial_code like '%'||'RECL-001'||'%' then pad.tpa_denial_desc else pad.tpa_denial_desc||';'||' Only 2 Resubmissions  allowed for a claim ' end end,
           pad.denial_by_rule_proc_dtls    = TRIM(BOTH ';' FROM (pad.denial_by_rule_proc_dtls||';'||CHR(10)||'claim_pkg.calculate_authorization'))
           where pad.claim_seq_id= v_claim_seq_id and nvl(pad.override_yn,'N')='N';
 END IF;
 
  IF  v_submission_type='DTR' THEN   
     authorization_pkg.Check_Resub_Activity_Limits(v_claim_seq_id,v_benifit_type,v_added_by);
 END IF;
 
 pat_xml_load_pkg.execute_global_amnt_rules('C',v_claim_seq_id,clm_rec.member_seq_id,v_Prod_Policy_Rule_Seq_Id);
 
 IF clm_rec.network_yn='Y'  THEN
   
   OPEN Claim_General_details;
     FETCH Claim_General_details INTO v_benefit_type,v_policy_seq_id;
        CLOSE Claim_General_details;
        
   AUTHORIZATION_PKG.Provider_Benifit_eligibility(v_claim_seq_id,'CLM',v_benefit_type,v_hosp_seq_id,v_policy_seq_id);
 END IF;
 
    OPEN  act_cur;
    FETCH act_cur INTO act_rec;
    CLOSE act_cur;
    
    IF clm_rec.benifit_type = 'HEAC' THEN
      IF clm_rec.hlt_chkp_cpay_deduct_flag = 'MIN' THEN
        v_benifit_final_deduct := least(NVL(clm_rec.hlt_chkp_deductbl,0),NVL(act_rec.tot_disc_gross_amount*(NVL(clm_rec.hlt_chkp_copay_perc,0)/100),0));
      ELSIF clm_rec.hlt_chkp_cpay_deduct_flag = 'MAX' THEN
        v_benifit_final_deduct := greatest(NVL(clm_rec.hlt_chkp_deductbl,0),NVL(act_rec.tot_disc_gross_amount*(NVL(clm_rec.hlt_chkp_copay_perc,0)/100),0));
      ELSIF clm_rec.hlt_chkp_cpay_deduct_flag = 'BOTH' THEN
        v_benifit_final_deduct := NVL((act_rec.tot_disc_gross_amount-NVL(clm_rec.hlt_chkp_deductbl,0))*(NVL(clm_rec.hlt_chkp_copay_perc,0)/100),0) + NVL(clm_rec.hlt_chkp_deductbl,0);
      END IF;
    END IF;
    
    
     UPDATE PAT_ACTIVITY_DETAILS PAD
    SET PAD.DENIAL_CODE = TRIM(';' FROM PAD.DENIAL_CODE ),
        PAD.DENIAL_DESC = TRIM(';' FROM PAD.DENIAL_DESC)
    WHERE CLAIM_SEQ_ID =v_claim_seq_id;
    
    UPDATE clm_authorization_details A
    SET a.tot_gross_amount           = act_rec.tot_gross_amount,
        a.tot_discount_amount        = act_rec.tot_discount_amount,
        a.tot_disc_gross_amount      = act_rec.tot_disc_gross_amount,
        a.tot_patient_share_amount   = act_rec.tot_patient_share_amount + v_benifit_final_deduct,
        a.tot_net_amount             = greatest(act_rec.tot_net_amount - v_benifit_final_deduct,0),
        a.tot_allowed_amount         = greatest(act_rec.tot_allowed_amount - v_benifit_final_deduct,0), 
        a.tot_approved_amount        = greatest(act_rec.tot_approved_amount -v_benifit_final_deduct,0),
        a.final_app_amount           = greatest(act_rec.tot_allowed_amount - v_benifit_final_deduct,0),
        a.CONVERTED_FINAL_APPROVED_AMT = case when to_number(clm_rec.conversion_rate) <>0 
                                           then act_rec.tot_allowed_amount / to_number(clm_rec.conversion_rate)
                                          else act_rec.tot_allowed_amount end ,
        --a.clm_status_type_id         = 'INP',
        a.cal_act_yn                 = 'Y',
        a.pay_amt_in_usd             =  (greatest(act_rec.tot_allowed_amount - v_benifit_final_deduct,0)/3.64),
        a.manual_disallow_amt        = act_rec.manual_disallow_amt
   WHERE a.Claim_Seq_Id           = v_claim_seq_id
   RETURNING a.tot_allowed_amount INTO v_allowed_amount;
  ---------------------------------------
  commit;
 
 OPEN v_result_set FOR 
  SELECT SUM(NVL(pa.gross_amount,0)) as tot_gross_amount
      ,SUM(NVL(pa.discount_amount,0)) as tot_discount_amount
      ,SUM(NVL(pa.disc_gross_amount,0)) as tot_disc_gross_amount
      ,SUM(NVL(pa.patient_share_amount,0))+v_benifit_final_deduct as tot_patient_share_amount
      ,greatest(SUM(NVL(pa.net_amount,0)) -v_benifit_final_deduct,0) as tot_net_amount
      ,greatest(SUM(NVL(pa.allowed_amount,0)) -v_benifit_final_deduct,0) as tot_allowed_amount
      ,greatest(SUM(NVL(pa.Approved_Amount,0)) -v_benifit_final_deduct,0) as tot_approved_amount

  FROM pat_activity_details pa
  WHERE pa.claim_seq_id=v_claim_seq_id
  AND pa.allow_yn='Y';

  
END calculate_authorization;
--===============================================================================
PROCEDURE save_settlement(v_claim_seq_id               IN clm_authorization_details.claim_seq_id%TYPE,
                          v_member_seq_id              IN clm_authorization_details.member_seq_id%TYPE,
                          v_settlement_number          IN OUT clm_authorization_details.settlement_number%TYPE,
                          v_admission_date             IN clm_authorization_details.date_of_hospitalization%type,
                          v_allowed_amount             IN clm_authorization_details.Tot_Allowed_Amount%TYPE,
                          v_source_type_id             IN clm_authorization_details.source_type_id%TYPE,
                          v_clm_status_type_id         IN OUT clm_authorization_details.clm_status_type_id%TYPE,
                          v_remarks                    IN clm_authorization_details.remarks%type,
                          v_added_by                   IN NUMBER,
                          v_fnl_amt_currency_type      In varchar2,----
                          v_clm_remark                 IN clm_authorization_details.final_remarks%TYPE,
                          v_internal_remarks           IN VARCHAR2,
                          v_rows_processed             OUT NUMBER,
                          v_rechceck_remarks           IN CLM_AUTHORIZATION_DETAILS.AUDIT_REMARKS%TYPE)
IS

v_dest_msg_seq_id VARCHAR2(250);
CURSOR mem_cur IS
SELECT a.date_of_inception,a.date_of_exit,a.member_seq_id,b.policy_group_seq_id,c.policy_seq_id,c.policy_sub_general_type_id,
c.enrol_type_id,tcc.short_name,
tsc.state_type_id FROM tpa_enr_policy_member a
JOIN tpa_enr_policy_group b on (a.policy_group_seq_id=b.policy_group_seq_id)
JOIN tpa_enr_policy c on (b.policy_seq_id=c.policy_seq_id)
left outer JOIN tpa_enr_mem_address tema ON (b.enr_address_seq_id = tema.enr_address_seq_id)
left outer JOIN tpa_country_code tcc  ON (tema.country_id = tcc.country_id)
left outer JOIN tpa_state_code tsc  ON (tema.state_type_id = tsc.state_type_id)
WHERE a.member_seq_id=v_member_seq_id;


pol_mem_rec             mem_cur%ROWTYPE;


 CURSOR clm_cur IS
      SELECT A.completed_yn , b.tpa_office_aeq_id , A.claim_number, A.Settlement_Number ,
         a.claim_type , a.clm_status_type_id ,
         e.member_seq_id, e.mem_general_type_id ,a.tot_approved_amount ,e.policy_group_seq_id,
        (k.sum_insured - k.utilised_sum_insured) AS ava_sum_insured ,
         k.balance_seq_id , b.submission_type_id,a.pat_approved_amount ,
         k.utilised_sum_insured,
         k.sum_insured, 
         l.tpa_office_seq_id AS policy_tpa_office_seq_id ,l.endorsement_seq_id ,
         a.date_of_hospitalization, l.effective_from_date as policy_effective_from , L.enrol_type_id , a.requested_amount,a.converted_amount,
         o.discount_amount,
         CASE WHEN l.enrol_type_id = 'COR' THEN l.admin_status_general_type_id ELSE n.prod_status_general_type_id END AS rule_execution_status,
         L.policy_sub_general_type_id,
         a.date_of_discharge,
         a.pat_auth_seq_id,k.restrict_amt,k.used_restrict_amt,(k.restrict_amt-k.used_restrict_amt) as ava_res_amt, 
         l.policy_seq_id,
         n.product_seq_id,e.mem_age,
         e.date_of_inception,
        /* for clinician validation  */                                                                      
         a.clinician_id, 
         hs.hosp_seq_id,
         b.network_yn,
         a.si_deduct_type,
         a.req_amt_currency_type,
         a.conversion_rate,
         a.pymnt_to_type_id,
         nvl(a.process_type,'RGL') as process_type,
         nvl(a.cal_act_yn,'Y') as cal_act_yn,
         a.benifit_type,
         a.status_code_id,    ---- ADDED IN CFD(FRAUD) CR
         a.risk_level,          ---- ADDED IN CFD(FRAUD) CR
         a.override_by     ---- ADDED IN CFD(FRAUD) CR
        -------------------- 
         FROM clm_authorization_details a
         JOIN clm_batch_upload_details b ON (a.clm_batch_seq_id=b.clm_batch_seq_id)
         LEFT OUTER JOIN clm_hospital_details hs ON (A.claim_seq_id = hs.claim_seq_id) 
         LEFT OUTER JOIN tpa_enr_policy_member E ON (a.member_seq_id = e.member_seq_id)
         LEFT OUTER JOIN tpa_enr_policy_group gr ON (gr.policy_group_seq_id = e.policy_group_seq_id)   
         LEFT OUTER JOIN pat_authorization_details h ON (a.pat_auth_seq_id = h.pat_auth_seq_id)
         LEFT OUTER JOIN tpa_enr_balance k ON (e.policy_group_seq_id = k.policy_group_seq_id /*AND k.balance_seq_id = v_balance_seq_id*/ )
         LEFT OUTER JOIN tpa_enr_policy  L ON (a.policy_seq_id = l.policy_seq_id )
         LEFT OUTER JOIN tpa_ins_product n ON (l.product_seq_id = n.product_seq_id)
         LEFT OUTER JOIN pat_activity_details O ON (A.claim_seq_id = O.claim_seq_id)
         WHERE ( E.mem_general_type_id != 'PFL' AND A.member_seq_id = K.member_seq_id OR K.member_seq_id IS NULL OR A.member_seq_id IS NULL ) 
         AND a.claim_seq_id  = v_claim_seq_id /*AND NVL( h.pat_enhanced_yn,'N' ) = 'N'*/;

clm_rec  clm_cur%rowtype;
CURSOR floater_cur(v_policy_group_seq_id    tpa_enr_policy_group.policy_group_seq_id%type)
 IS 
SELECT a.policy_group_seq_id,
       SUM(A.mem_sum_insured) AS sum_insured,
       b.sum_insured as tot_sum_insured,
       b.utilised_sum_insured  FROM tpa_enr_mem_insured a
JOIN tpa_enr_balance b on (a.policy_group_seq_id=b.policy_group_seq_id)
WHERE a.policy_group_seq_id=v_policy_group_seq_id
--AND a.policy_date<=v_admission_date
GROUP BY a.policy_group_seq_id,b.sum_insured,b.utilised_sum_insured;

CURSOR nonfloater_cur(v_member_seq_id    tpa_enr_policy_member.member_seq_id%type)
 IS 
SELECT a.member_seq_id,
       SUM(A.mem_sum_insured) AS sum_insured,
       b.sum_insured as tot_sum_insured,
       b.utilised_sum_insured
       
FROM tpa_enr_mem_insured a
JOIN tpa_enr_balance b on (a.member_seq_id=b.member_seq_id)
WHERE a.member_seq_id=v_member_seq_id
--AND a.policy_date<=v_admission_date
GROUP BY a.member_seq_id,b.sum_insured,b.utilised_sum_insured;

CURSOR prev_appr_cur IS  SELECT COUNT(1) FROM ( SELECT a.claim_seq_id, a.parent_claim_seq_id,a.clm_status_type_id
      FROM clm_authorization_details a START WITH a.claim_seq_id = v_claim_seq_id CONNECT BY a.claim_seq_id = PRIOR a.parent_claim_seq_id ) aa
      WHERE aa.clm_status_type_id = 'APR' AND aa.claim_seq_id != v_claim_seq_id ;

CURSOR shortfall_count IS 
SELECT COUNT(1)  FROM APP.shortfall_details s where 
 s.srtfll_status_general_type_id='OPN' and s.claim_seq_id=v_claim_seq_id ;
-------------- for clinician validation -----------------
CURSOR clinician_count_cur(v_clinician_id varchar2,v_hosp_seq_id number )IS
   SELECT count(1) FROM app.tpa_hosp_professionals hp
   WHERE hp.professional_id=v_clinician_id AND hp.hosp_seq_id=v_hosp_seq_id;
-----------------------------------------------------------

Cursor icd_cur IS
 Select count(1) as icd_count
 From diagnosys_details d
 Where d.claim_seq_id = v_claim_seq_id
 And d.primary_ailment_yn = 'Y';
 
CURSOR clm_icd_cur IS
Select d.diagnosys_code, c.benifit_type
From diagnosys_details d
Join clm_authorization_details c on (c.claim_seq_id = d.claim_seq_id)
Where d.claim_seq_id = v_claim_seq_id
And d.primary_ailment_yn = 'Y'; 

CURSOR icd_benefit_cur(v_diagnosys_code VARCHAR2) IS
  Select ic.benefit_type
  From tpa_icd10_master_details ic
  Where ic.icd_code = upper(v_diagnosys_code);
  
  
CURSOR Get_Currency_Rates(v_dis_dt date) IS  
SELECT A.EUR,B.GBP FROM
       (select QAR_PER_UNIT EUR 
               from APP.TPA_CURRENCY_CONV_RATES 
               where  CURRENCY_CODE = 'EUR' AND trunc(UPLOADED_DATE)=v_dis_dt) A,
        (select QAR_PER_UNIT GBP 
                from APP.TPA_CURRENCY_CONV_RATES 
                where  CURRENCY_CODE = 'GBP' AND trunc(UPLOADED_DATE)=v_dis_dt) B;

  
  
v_icd_benefit        icd_benefit_cur%ROWTYPE;
icd_count            icd_cur%ROWTYPE;
clm_icd_rec          clm_icd_cur%ROWTYPE;
sum_rec              floater_cur%rowtype;
v_ava_sum_insured    tpa_enr_balance.utilised_sum_insured%type;
v_app_amount         pat_authorization_details.final_app_amount%type;
v_reason             pat_authorization_details.remarks%type;
v_denial_reason      pat_authorization_details.denial_reason%type;
v_compleated_yn      varchar2(5);
v_status             VARCHAR2(60):= 'PENDING';
v_appr_count         number;
v_sum                clm_authorization_details.ava_sum_insured%TYPE:=0;
v_count              number(10);
v_final_remarks      VARCHAR2(2000);
v_seq_id              number(10);
v_euro                number(20,8);
v_gbp                 number(20,8);
v_utilised_amount     NUMBER(30,2);
----- ADDED IN CFD CR 
CURSOR inv_status IS SELECT * FROM (SELECT inv_status FROM app.tpa_fraud_inv_details WHERE claim_seq_id = v_claim_seq_id ORDER BY inv_seq_id DESC) WHERE ROWNUM=1;
v_inv_status app.tpa_fraud_inv_details.inv_status%TYPE;

BEGIN

authorization_pkg.reassign_user(null,'|'||v_claim_seq_id||'|',null,v_added_by,null,v_seq_id);

  OPEN mem_cur;
  FETCH mem_cur INTO pol_mem_rec;
  CLOSE mem_cur;
  
  OPEN clm_cur;
  FETCH clm_cur INTO clm_rec;
  CLOSE clm_cur;
  
  OPEN prev_appr_cur;
  FETCH prev_appr_cur INTO v_appr_count;
  CLOSE prev_appr_cur;
  
  IF clm_rec.Completed_Yn='Y' THEN
    RAISE_APPLICATION_ERROR(-20152,'You cannot perform this action through a completed Claim.');
  END IF;
  
  IF NVL(clm_rec.cal_act_yn,'Y') = 'N' THEN
    RAISE_APPLICATION_ERROR(-20288,'Modification happened, re-calculate activity once again.');
  END IF;
  --Commented to remove clinician validation (Manju Sir)
   ---- for clinician validation ----
  /*If clm_rec.network_yn = 'Y' Then
    IF clm_rec.Process_Type = 'RGL' THEN
      open clinician_count_cur(clm_rec.clinician_id,clm_rec.hosp_seq_id);
      fetch clinician_count_cur into v_count;
      close clinician_count_cur;
      
      if v_count = 0 \*and clm_rec.completed_yn != 'Y'*\ then 
        v_clm_status_type_id:='INP';
      end if;
    ELSE
      IF NVL(clm_rec.pymnt_to_type_id,'NA') = 'PRV' THEN
        open clinician_count_cur(clm_rec.clinician_id,clm_rec.hosp_seq_id);
        fetch clinician_count_cur into v_count;
        close clinician_count_cur;
        
        if v_count = 0 \*and clm_rec.completed_yn != 'Y'*\ then 
          v_clm_status_type_id:='INP';
        end if;
     END IF;   
    END IF;
  End If;   */
  ------------------------------------------ 
  -----ICD
   OPEN icd_cur;
   FETCH icd_cur INTO icd_count;
   CLOSE icd_cur;
   
   IF v_clm_status_type_id = 'APR' AND icd_count.icd_count = 0 THEN
     RAISE_APPLICATION_ERROR(-20923,'Primary ICD required to complete the preauth/ claim.');
   END IF;
   
   IF v_clm_status_type_id = 'APR' THEN
     OPEN clm_icd_cur;
     FETCH clm_icd_cur INTO clm_icd_rec;
     CLOSE clm_icd_cur;
   
     OPEN icd_benefit_cur(clm_icd_rec.diagnosys_code);
     FETCH icd_benefit_cur INTO v_icd_benefit;
     CLOSE icd_benefit_cur;
      
     IF v_icd_benefit.benefit_type = 'DNTL' THEN
       IF clm_icd_rec.benifit_type != v_icd_benefit.benefit_type THEN
         RAISE_APPLICATION_ERROR(-20323,'Ailment does not belogs to the selected benefit type, please select appropriate benefit type!');
       END IF;
     END IF;
   END IF;
   ---ICD End
   
  open shortfall_count;
  fetch shortfall_count into v_count;
  close shortfall_count;
  
  IF v_count>0 and v_clm_status_type_id ='APR'then 
    RAISE_APPLICATION_ERROR(-20387,'Please close the opened shortfall before complete the Pre_auth/Claim.');
  END IF;
  
  IF v_count=0 and v_clm_status_type_id='REQ' THEN 
    RAISE_APPLICATION_ERROR(-20957,'You can not change the status to required information without Raising Shortfall.');
  END IF;
  
  IF v_count>0 and v_clm_status_type_id='INP' THEN 
    RAISE_APPLICATION_ERROR(-20958,'You can not change the status to inprogress without closing Shortfall.');
  END IF;
          ----- ADDED IN CFD (COUNT FRAUD CR)
  OPEN inv_status;
  FETCH inv_status INTO v_inv_status;
  CLOSE inv_status;
  
  IF (clm_rec.status_code_id = 'SUSP' AND clm_rec.risk_level = 'HR') AND (v_inv_status IS NULL  OR v_inv_status = 'II') AND (v_clm_status_type_id = 'APR') THEN
      RAISE_APPLICATION_ERROR (-20412, 'Claims/Pre-approval is tagged with Suspicion and High Risk, Need CFD Clearance to Proceed further');
  END IF;
  
  IF v_clm_status_type_id NOT IN ('INP','REJ') AND clm_rec.override_by IS NULL AND (clm_rec.status_code_id  = 'SUSP' AND clm_rec.risk_level = 'HR' AND v_inv_status = 'FD')  THEN
      RAISE_APPLICATION_ERROR (-20413, 'Claims/Pre-approval cannot be Approved as Fraudulence detected after Investigation');
  END IF;
  
  IF pol_mem_rec.policy_sub_general_type_id='PFL' THEN
    OPEN floater_cur(pol_mem_rec.policy_group_seq_id);
    FETCH floater_cur INTO sum_rec;
    CLOSE floater_cur;
  ELSIF  pol_mem_rec.policy_sub_general_type_id='PNF' THEN
    OPEN nonfloater_cur(pol_mem_rec.member_seq_id);
    FETCH nonfloater_cur INTO sum_rec;
    CLOSE nonfloater_cur;
  END IF; 
  
  v_ava_sum_insured:=(NVL(sum_rec.sum_insured,0)-NVL(sum_rec.utilised_sum_insured,0)) ;  
     
    IF v_clm_status_type_id='APR' THEN
      IF v_allowed_amount<=v_ava_sum_insured THEN
         v_app_amount:=v_allowed_amount;
      ELSE 
         RAISE_APPLICATION_ERROR(-20737,'Sufficient Balance doesnot exist');
      END IF;   
    ELSIF v_clm_status_type_id IN ('REJ','REQ','PCN','PCO') THEN
          v_app_amount:=0;
    END IF; 
    
     IF v_app_amount > clm_rec.converted_amount then
      v_app_amount:= clm_rec.converted_amount;
       v_final_remarks:='Total Approved Amount should be less than or equal to Requested Amount';
     else 
       v_app_amount :=v_app_amount;
     end if;
  IF v_settlement_number IS NULL and v_clm_status_type_id IN ('APR','REJ','PCO','PCN') THEN
     v_settlement_number:=authorization_pkg.generate_id_numbers('STC',nvl(pol_mem_rec.short_name,'UAE'),nvl(pol_mem_rec.state_type_id,'DXB'),clm_rec.claim_number,clm_rec.claim_type);
  END IF;
 
  v_compleated_yn:=CASE WHEN v_clm_status_type_id IN ('APR','REJ','PCO','PCN') THEN 'Y'
                        ELSE 'N' END;
  --Check Claim User Aproval Limit to Approve
  IF v_clm_status_type_id = 'APR' AND v_added_by != 1 THEN
    authorization_pkg.check_approval_limit(v_added_by, v_allowed_amount,'CLM');
  END IF;
  
  
  open Get_Currency_Rates(to_date(clm_rec.date_of_discharge,'dd-mm-yy'));
    fetch Get_Currency_Rates into v_euro,v_gbp;
      close Get_Currency_Rates;
 
   UPDATE clm_authorization_details a
     SET A.final_app_amount       = NVL(v_app_amount,final_app_amount),
         a.CONVERTED_FINAL_APPROVED_AMT = NVL(CASE WHEN to_number(clm_rec.conversion_rate) = 0 THEN 0
                                                ELSE v_app_amount / to_number(clm_rec.conversion_rate) END,
                                              CONVERTED_FINAL_APPROVED_AMT),
         a.fnl_amt_currency_type  = v_fnl_amt_currency_type,
         a.clm_status_type_id     = v_clm_status_type_id,
         a.final_remarks          = --case when v_final_remarks is not null then 
                                      trim(both ';' from v_final_remarks ||';'||v_clm_remark||';'||NVL(v_remarks,v_reason)),
                                    --else NVL(v_remarks,v_reason)
                                    --end,
         a.denial_reason          = v_denial_reason,
         A.Settlement_Number      = v_settlement_number,
         A.completed_yn           = v_compleated_yn,
         a.updated_by             = v_added_by,
         a.updated_date           = SYSDATE,
         a.decision_date          = case when v_clm_status_type_id IN ('APR','REJ','PCO') then sysdate ELSE NULL end,
         a.completed_date         = case when v_clm_status_type_id IN ('APR','REJ','PCO') then sysdate ELSE NULL end,
         a.tot_approved_amount    = CASE WHEN v_clm_status_type_id IN ('REQ','REJ') THEN 0 ELSE tot_approved_amount END,
         a.tot_allowed_amount     = CASE WHEN v_clm_status_type_id IN ('REQ','REJ') THEN 0 ELSE tot_allowed_amount END,
         a.internal_remarks       = v_internal_remarks,
         a.processed_by           = case when v_clm_status_type_id IN ('APR','REJ','PCO') then v_added_by else null end,
         a.pay_amt_in_usd         = case when  a.final_app_amount is not null then (NVL(v_app_amount,final_app_amount)/3.64) else null end,
         A.Pay_Amt_In_Euro        = case when a.final_app_amount is not null and v_euro is not null then a.final_app_amount/v_euro else null end,
         a.pay_amt_in_gbp         = case when a.final_app_amount is not null and v_gbp is not null then a.final_app_amount/v_gbp else null end,
         a.conv_rate_in_euro      = case when v_euro is not null then v_euro else null end,
         a.conv_rate_in_gbp       = case when v_gbp is not null then v_gbp else null end,
         a.audit_remarks          = v_rechceck_remarks,
         a.audit_status           = CASE WHEN NVL(v_compleated_yn, 'N') = 'Y' AND a.audit_status = 'RCR' THEN 'CKD' ELSE a.audit_status END
     WHERE A.Claim_Seq_Id         = v_Claim_Seq_Id;
     
    IF v_clm_status_type_id IN ('REQ','REJ') THEN  
      UPDATE Pat_Activity_Details pa
        SET pa.allowed_amount  = 0,
            pa.approved_amount = 0,
            pa.updated_date    = sysdate
      WHERE pa.claim_seq_id = v_claim_seq_id; 
    END IF;
  
  if v_compleated_yn='Y' and v_clm_status_type_id='APR' then
   save_claims_payment (
              v_claim_seq_id   ,
              v_status ,
              pol_mem_rec.Enrol_Type_Id ,
              clm_rec.Policy_Seq_Id ,
              v_member_seq_id ,
              clm_rec.claim_type  ,
              v_added_by
            );
  end if;
  
          if v_compleated_yn='Y' and v_clm_status_type_id='APR' then
              IF clm_rec.submission_type_id != 'DTR' OR (clm_rec.submission_type_id = 'DTR' AND v_appr_count = 0 ) THEN
               v_sum   :=  NVL(clm_rec.tot_approved_amount,0) - NVL(clm_rec.pat_approved_amount,0)    ;
              ELSE
               v_sum   :=  NVL(clm_rec.tot_approved_amount,0);
              END IF;
         
             if (clm_rec.claim_type='CTM') or (clm_rec.claim_type='CNH' and nvl(clm_rec.pat_auth_seq_id,0)=0)  then
               
                UPDATE tpa_enr_balance a SET
                a.utilised_sum_insured   = case when NVL(clm_rec.si_deduct_type,'WSI') = 'OSI' then a.utilised_sum_insured
                                                else  case when nvl(a.utilised_sum_insured,0)=0  then v_sum else a.utilised_sum_insured + v_sum end
                                                  end,
                a.updated_by             = v_added_by,
                a.updated_date           = SYSDATE
                WHERE a.balance_seq_id = clm_rec.balance_seq_id RETURN A.UTILISED_SUM_INSURED INTO v_utilised_amount;
             else
               UPDATE tpa_enr_balance a SET
                a.utilised_sum_insured   = case when nvl(a.utilised_sum_insured,0)=0  then v_sum else a.utilised_sum_insured + v_sum end,
                a.updated_by             = v_added_by,
                a.updated_date           = SYSDATE
                WHERE a.balance_seq_id = clm_rec.balance_seq_id RETURN A.UTILISED_SUM_INSURED INTO v_utilised_amount;
             end if; 
 
 ----Tracking Sum insured Details
  
  INSERT INTO APP.sum_ins_track (CLAIM_PRE_NUMBER, MEMBER_SEQ_ID,UTILISED_SUM_INS,APPR_AMOUNT,PAT_APPR_AMOUNT,ADDED_DATE,MODULE_FLAG,CLAIM_STATUS,UPDATED_SI)
    VALUES (v_settlement_number , v_member_seq_id, clm_rec.utilised_sum_insured,v_allowed_amount,clm_rec.pat_approved_amount,SYSDATE,'CLAIM',v_clm_status_type_id,v_utilised_amount);
  
 end if;  
   v_rows_processed:=SQL%ROWCOUNT;
 
COMMIT;
   
END save_settlement;
--===============================================================================
PROCEDURE create_claim_xml (
    v_claim_seq_id                       IN  clm_authorization_details.claim_seq_id%type,
    v_claim_history_doc                   OUT clob
   )
   IS

  
     CURSOR claim_cur IS
       SELECT pad.pre_auth_number as pre_auth_number,
              sou.description AS source_description,
              to_char(cad.clm_received_date,'dd/mm/yyyy') as received_date,
              to_char(cad.date_of_hospitalization,'dd/mm/yyyy hh:mi:ss AM') as date_of_admission,
              cad.id_payer id_payer,
              cad.member_seq_id ,
              cad.mem_name,
              cad.mem_age,
              cad.emirate_id,
              tetc.description as encounter_type_id,
              tetd.description as encounter_start_type,
              cad.encounter_facility_id,
              tii.ins_comp_code_number as payer_id,
              cad.settlement_number,
              chd.hosp_seq_id,
              to_char(cad.date_of_discharge,'dd/mm/yyyy hh:mi:ss AM') as date_of_discharge,
              null AS Autorization_type,
              cad.tot_gross_amount,
              cad.tot_discount_amount,
              cad.tot_disc_gross_amount,
              cad.tot_patient_share_amount,
              (cad.tot_disc_gross_amount-nvl(cad.tot_patient_share_amount,0)) as tot_net_amount,
              cad.tot_allowed_amount,
              account_info_pkg.get_gen_desc(cad.clm_status_type_id,'G') as status,
              case when nvl(cad.network_yn,'N')='Y' then  thi.hosp_name else chd.hosp_name end as hosp_name,
              thi.empanel_number,
              cad.ava_sum_insured,
              tii.ins_comp_name as payer_name,
              cad.tpa_enrollment_id,
              tha.address_1||' '||tha.address_2||' '||tha.address_3||' '||tha.pin_code as provider_details,
              thi.hosp_licenc_numb as provider_id,
              tetd.description as start_type,
              teta.description as end_type,
              nvl(tdc.denial_description,cad.denial_reason) denial_reason,
              cad.final_remarks as remarks,
              cad.final_app_amount,
              ben.description as Treatment_cat_type,
              nvl(uca.contact_name,uc.contact_name) as assigned_to,
              cad.clinician_id,
              chd.clinician_name,
              cad.internal_remarks,
              case when NVL(cad.suspect_veri_check,'N')='N' then  irc.status_desc  
                   when NVL(cad.suspect_veri_check,'N')='Y' and cad.status_code_id ='SUSP' then 'Suspected Fraud - Verified'
                     when NVL(cad.suspect_veri_check,'N')='Y' and cad.status_code_id ='ALKT' then 'Alkoot Clarification - Verified'
                       when NVL(cad.suspect_veri_check,'N')='Y' and cad.status_code_id ='PROV' then 'Provider Clarification - Verified' end
                            as internal_remarks_status,
			sym.description AS system_of_med,
              pad.auth_number as authorization_number,
              cad.event_no,
              cad.invoice_number,
              to_date(cad.lmp_date,'DD-MM-YYYY') as Date_of_lmp,
              case when cad.claim_type='CNH' THEN 'NETWORK' 
                   when cad.claim_type='CTM' THEN 'MEMBER' END as claim_type,
              case when cad.process_type='RGL' THEN 'Regullar'
                   when cad.process_type='DBL' THEN 'Direct-Billing' END AS process_type,
              case when cad.conception_type='NAT' THEN 'Natural'
                   when cad.conception_type='AST' THEN 'Assisted' END AS conception_type,
              case when cbat.submission_type_id='DTC' THEN 'Claim Submission'
                   when cbat.submission_type_id='DTR' THEN 'Claim Re_Submisssion' END as submission_type,
              cad.claim_number,
              CASE WHEN cad.benifit_type='DNTL' THEN dntl.description ELSE NULL END as dental_teat_type  ,
              
            CASE  WHEN epm.vip_yn='Y' THEN 'YES'
                  WHEN epm.vip_yn='N' THEN 'NO'                          END as vip,
            CASE  WHEN cad.DELVRY_MOD_TYPE='LSS' THEN 'LSCS'
                  WHEN cad.DELVRY_MOD_TYPE='NOR' THEN 'Normal'          END as mode_of_delivery,
            CASE  WHEN cad.BENIFIT_TYPE='DNTL' THEN 'DENTAL'
                  WHEN cad.BENIFIT_TYPE='OPTS' THEN 'OUT-PATIENT'
                  WHEN cad.BENIFIT_TYPE='OPTC' THEN 'OPTICAL'
                  WHEN cad.BENIFIT_TYPE='IMTI' THEN 'IN-PATIENT MATERNITY'
                  WHEN cad.BENIFIT_TYPE='IPT' THEN 'IN-PATIENT'
                  WHEN cad.BENIFIT_TYPE='HEAC' THEN 'HEALTH CHECK-UP'
                  WHEN cad.BENIFIT_TYPE='DAYC' THEN 'DAYCARE'
                  WHEN cad.BENIFIT_TYPE='OMTI' THEN 'OUT-PATIENT MATERNITY'
                  WHEN cad.BENIFIT_TYPE='IEMA' THEN 'INTERNATIONAL EMERGENCY MEDICAL ASSISTANCE'
                  WHEN cad.BENIFIT_TYPE='PAHC' THEN 'PALLIATIVE AND HOSPICE CARE BENEFIT'
                  WHEN cad.BENIFIT_TYPE='LSS' THEN 'LSCS'
                  WHEN cad.BENIFIT_TYPE='IPRE' THEN 'IN-PATIENT REHABILITATION'
                                                                         END as BENIFIT_TYPE,
                
                  NVL(cAD.MAT_COMPLCTON_YN,'N') AS MAT_COMPLCTON_YN                 
             
        FROM clm_authorization_details cad
        JOIN clm_hospital_details chd on (cad.claim_seq_id=chd.claim_seq_id)
        left outer JOIN clm_batch_upload_details cbat on (cbat.clm_batch_seq_id=cad.clm_batch_seq_id)
        left outer join tpa_hosp_info thi ON (chd.hosp_seq_id=thi.hosp_seq_id)
        left outer join tpa_hosp_address tha on (thi.hosp_seq_id=tha.hosp_seq_id)
        left outer join tpa_ins_info tii ON (cad.ins_seq_id=tii.ins_seq_id)
        left outer join tpa_encounter_type_codes tetc ON (cad.encounter_type_id=tetc.encounter_seq_id and tetc.header_type='ENCOUNTER_TYPE')
        left outer join tpa_general_code tgc on (tetc.category_type=tgc.general_type_id)
        left outer join tpa_encounter_type_codes tetD ON (cad.encounter_start_type=tetD.encounter_seq_id and tetD.header_type='ENCOUNTER_START_TYPE')
        left outer join tpa_encounter_type_codes tetA ON (cad.encounter_end_type=tetA.encounter_seq_id and tetA.header_type='ENCOUNTER_END_TYPE')
        left outer join tpa_encounter_type_codes dntl ON (cad.treatment_type=dntl.encounter_seq_id and dntl.header_type='DNTL_ENCOUNTER_TYPE')
        left outer join tpa_denial_codes tdc on (cad.denial_code=tdc.denial_code)
        left outer join tpa_user_contacts uc on (uc.contact_seq_id=cad.added_by)
        left outer join tpa_user_contacts uca on (uca.contact_seq_id=cad.updated_by)
        left outer join tpa_general_code ben on (ben.general_type_id=cad.benifit_type)
        left outer join tpa_general_code sou on (sou.general_type_id=cbat.source_type_id)
        left outer join app.tpa_internal_remark_stat_code irc on((cad.status_code_id)=(irc.status_code_id))
        left outer join tpa_general_code sym on (sym.general_type_id=cad.system_of_medicine_type_id)
        left outer join pat_authorization_details pad on (pad.pat_auth_seq_id=cad.pat_auth_seq_id) 
        left outer join app.tpa_enr_policy_member epm on (epm.member_seq_id=cad.member_seq_id)
       WHERE cad.claim_seq_id=v_claim_seq_id;
       
         
      CURSOR act_cur IS 
      SELECT    pat.*,case when pat.activity_type='5' AND PAT.CODE != 'PHARMA' then md.short_description 
       when  pat.activity_type='5' AND PAT.CODE = 'PHARMA' then m.short_description
      else m.short_description end as act_desc,tdc.denial_description 
      FROM pat_activity_details pat 
      left outer JOIN tpa_activity_master_details m ON (pat.activity_seq_id=m.act_mas_dtl_seq_id)
      left outer JOIN tpa_pharmacy_master_details md ON (pat.activity_seq_id=md.act_mas_dtl_seq_id)
      left outer JOIN tpa_denial_codes tdc ON (pat.denial_code=tdc.denial_code)
      WHERE pat.claim_seq_id=v_claim_seq_id;
      
      CURSOR diag_cur IS 
      SELECT    dd.*,tic.short_desc as icd_description     
      FROM diagnosys_details dd 
      left outer join tpa_icd10_master_details tic on (dd.diagnosys_code=tic.icd_code)
      WHERE dd.claim_seq_id=v_claim_seq_id;
      
      CURSOR observ_cur(v_activity_dtl_seq_id pat_observation_details.activity_dtl_seq_id%type) IS 
      SELECT   account_info_pkg.get_gen_desc( pod.observation_type_id,'G') type,
      pod.observation_code_id,pod.value,
      account_info_pkg.get_gen_desc( pod.obs_value_type_id,'G') as value_type     
      FROM pat_observation_details pod
      WHERE pod.activity_dtl_seq_id =v_activity_dtl_seq_id;
      
      CURSOR Claim_Payment_Details IS
      select ttk_util_pkg.fn_decrypt(pay.payee_name) as payee_name,
          nvl(cc.check_num,'-') as check_num,cc.check_amount,
          nvl(pay.payee_type,'-') as payee_type,to_char(cc.check_date,'dd-mm-yyyy') as check_date,
          pay.claim_payment_status as check_status ,
          '-' as consignment_num,'-' as consignment_prov , '-' as dispatched_date,
          cad.req_amt_currency_type,
          pay.transfer_currency
        from fin_app.tpa_claims_payment pay
        left outer join  app.clm_authorization_details cad on (pay.claim_seq_id=cad.claim_seq_id)
        left outer join fin_app.tpa_payment_checks_details pcad on (pcad.payment_seq_id=pay.payment_seq_id)
        left outer join fin_app.tpa_claims_check cc on (cc.claims_chk_seq_id=pcad.claims_chk_seq_id)
        where pay.claim_seq_id=v_claim_seq_id;  
     
   
      v_rec_user                   claim_cur%ROWTYPE;
      act_rec                      act_cur%ROWTYPE;
      diag_rec                     diag_cur%ROWTYPE;
      observ_rec                   observ_cur%ROWTYPE;
      payee_details                Claim_Payment_Details%ROWTYPE;
      v_claim_doc                  DBMS_XMLDOM.DOMDocument;
      v_claim_root_node            DBMS_XMLDOM.DOMNode;
      v_elem                       DBMS_XMLDOM.DOMElement;
      v_elem1                      DBMS_XMLDOM.DOMElement;
      v_node                       DBMS_XMLDOM.DOMNode;
      v_parent_node                DBMS_XMLDOM.DOMNODE;
      v_activity_node              DBMS_XMLDOM.DOMNODE;
      v_observ_node              DBMS_XMLDOM.DOMNODE;
      v_diag_node                DBMS_XMLDOM.DOMNODE;
      v_payment_node             DBMS_XMLDOM.DOMNODE;
      v_root_node          DBMS_XMLDOM.DOMNode;
      v_ctr                NUMBER := 1 ;
      v_xml                xmltype;
 
   BEGIN
     
      OPEN claim_cur;
      FETCH claim_cur INTO v_rec_user;
      CLOSE claim_cur;

      v_claim_doc := dbms_xmldom.newDOMDocument;
      dbms_xmldom.setVersion( v_claim_doc, '1.0' );
      v_claim_root_node := dbms_xmldom.makeNode(v_claim_doc);

      v_elem := dbms_xmldom.createElement( v_claim_doc, 'claimhistory' );
      v_node := dbms_xmldom.makeNode( v_elem );
      v_claim_root_node := dbms_xmldom.appendChild( v_claim_root_node, v_node );

      v_elem := dbms_xmldom.createElement(v_claim_doc, 'claimdetails');
      dbms_xmldom.setAttribute(v_elem,'claimnumber',v_rec_user.claim_number);
      dbms_xmldom.setAttribute(v_elem,'source',v_rec_user.source_description);
      dbms_xmldom.setAttribute(v_elem,'recieveddate',v_rec_user.received_date);
      dbms_xmldom.setAttribute(v_elem,'admissiondate',v_rec_user.date_of_admission);
      dbms_xmldom.setAttribute(v_elem,'idpayer',v_rec_user.id_payer);
      dbms_xmldom.setAttribute(v_elem,'memname',v_rec_user.mem_name);
      dbms_xmldom.setAttribute(v_elem,'memberid',v_rec_user.tpa_enrollment_id);
      dbms_xmldom.setAttribute(v_elem,'age',v_rec_user.mem_age);
      dbms_xmldom.setAttribute(v_elem,'emirateid',v_rec_user.emirate_id);
      dbms_xmldom.setAttribute(v_elem,'encountertype',v_rec_user.encounter_type_id);
      dbms_xmldom.setAttribute(v_elem,'encstarttype',v_rec_user.start_type);
      dbms_xmldom.setAttribute(v_elem,'treatmenttype',v_rec_user.dental_teat_type);
      dbms_xmldom.setAttribute(v_elem,'encendtype', v_rec_user.end_type);
      dbms_xmldom.setAttribute(v_elem,'encfacilityid', v_rec_user.encounter_facility_id);
      dbms_xmldom.setAttribute(v_elem,'payerid', v_rec_user.payer_id);
      dbms_xmldom.setAttribute(v_elem,'settlementno', v_rec_user.settlement_number);
      dbms_xmldom.setAttribute(v_elem,'discharegedate', v_rec_user.date_of_discharge);
      dbms_xmldom.setAttribute(v_elem,'providername', v_rec_user.hosp_name);
      dbms_xmldom.setAttribute(v_elem,'providerdetails', v_rec_user.provider_details);
      dbms_xmldom.setAttribute(v_elem,'empanenumber', v_rec_user.empanel_number);
      dbms_xmldom.setAttribute(v_elem,'authorizationtype', v_rec_user.autorization_type);
      dbms_xmldom.setAttribute(v_elem,'grossamt', v_rec_user.tot_gross_amount);
      dbms_xmldom.setAttribute(v_elem,'netamt', v_rec_user.tot_net_amount);
      dbms_xmldom.setAttribute(v_elem,'patientshare', v_rec_user.tot_patient_share_amount);
      dbms_xmldom.setAttribute(v_elem,'approvedamt', v_rec_user.final_app_amount);
      dbms_xmldom.setAttribute(v_elem,'clinicianid', v_rec_user.clinician_id);
      dbms_xmldom.setAttribute(v_elem,'clinicianname', v_rec_user.clinician_name);
      dbms_xmldom.setAttribute(v_elem,'internalremarks', v_rec_user.internal_remarks);
      dbms_xmldom.setAttribute(v_elem,'status', v_rec_user.status);      
      dbms_xmldom.setAttribute(v_elem,'avasuminsured', v_rec_user.ava_sum_insured);
      dbms_xmldom.setAttribute(v_elem,'payername', v_rec_user.payer_name);
      dbms_xmldom.setAttribute(v_elem,'providerid', v_rec_user.provider_id);
      dbms_xmldom.setAttribute(v_elem,'denialreason', v_rec_user.denial_reason);
      dbms_xmldom.setAttribute(v_elem,'remarks', v_rec_user.remarks);
      dbms_xmldom.setAttribute(v_elem,'trmtcatype', v_rec_user.treatment_cat_type);
      dbms_xmldom.setAttribute(v_elem,'sysmed', v_rec_user.system_of_med);
      dbms_xmldom.setAttribute(v_elem,'authnumber', v_rec_user.authorization_number);
      dbms_xmldom.setAttribute(v_elem,'event_no', v_rec_user.event_no);
      dbms_xmldom.setAttribute(v_elem,'dlmp', v_rec_user.date_of_lmp);
      dbms_xmldom.setAttribute(v_elem,'invoice', v_rec_user.invoice_number);
      dbms_xmldom.setAttribute(v_elem,'cliamtype', v_rec_user.claim_type);
      dbms_xmldom.setAttribute(v_elem,'processtype', v_rec_user.submission_type);
      dbms_xmldom.setAttribute(v_elem,'conception', v_rec_user.conception_type);
      dbms_xmldom.setAttribute(v_elem,'submission', v_rec_user.process_type);
      dbms_xmldom.setAttribute(v_elem,'assignto', v_rec_user.assigned_to);
      dbms_xmldom.setAttribute(v_elem,'internalremarksstatus',v_rec_user.internal_remarks_status);
      dbms_xmldom.setAttribute(v_elem,'preauthno', v_rec_user.pre_auth_number);
      dbms_xmldom.setAttribute(v_elem,'vip', v_rec_user.vip);
      dbms_xmldom.setAttribute(v_elem,'modeofdelivery', v_rec_user.mode_of_delivery);
	    dbms_xmldom.setAttribute(v_elem,'benifittype', v_rec_user.benifit_type);
      dbms_xmldom.setAttribute(v_elem,'matcomplctonyn', v_rec_user.MAT_COMPLCTON_YN);
      
      
      
      v_node := dbms_xmldom.makeNode( v_elem );
      v_parent_node := dbms_xmldom.appendChild( v_claim_root_node, v_node );
 
    for act_rec IN act_cur LOOP
      v_elem := dbms_xmldom.createElement(v_claim_doc, 'activitydetails');
      dbms_xmldom.setAttribute(v_elem,'actid',act_rec.code);
      dbms_xmldom.setAttribute(v_elem,'actcode',act_rec.code);
      dbms_xmldom.setAttribute(v_elem,'actdesc',act_rec.act_desc);
      dbms_xmldom.setAttribute(v_elem,'modifier',nvl(act_rec.modifier,'-NA-'));
      dbms_xmldom.setAttribute(v_elem,'unittype',nvl(act_rec.unit_type,'-NA-'));
      dbms_xmldom.setAttribute(v_elem,'qty',nvl(act_rec.quantity,'0'));
      dbms_xmldom.setAttribute(v_elem,'apprqty',nvl(act_rec.approvd_quantity,'0'));
      dbms_xmldom.setAttribute(v_elem,'startdate',act_rec.start_date);
      dbms_xmldom.setAttribute(v_elem,'gross',nvl(act_rec.gross_amount,0));
      dbms_xmldom.setAttribute(v_elem,'disc',nvl(act_rec.discount_amount,0));
      dbms_xmldom.setAttribute(v_elem,'discgross',nvl(act_rec.disc_gross_amount,0));
      dbms_xmldom.setAttribute(v_elem,'patientshare',nvl(act_rec.patient_share_amount,0));
      dbms_xmldom.setAttribute(v_elem,'copay',nvl(act_rec.copay_amount,0));
      dbms_xmldom.setAttribute(v_elem,'ded',nvl(act_rec.deduct_amount,0));
      dbms_xmldom.setAttribute(v_elem,'net',nvl(act_rec.net_amount,0));
      dbms_xmldom.setAttribute(v_elem,'appramt',act_rec.approved_amount);
      dbms_xmldom.setAttribute(v_elem,'allowedamt',act_rec.allowed_amount);
      dbms_xmldom.setAttribute(v_elem,'denialcode',NVL(act_rec.denial_code,'-NA-'));
      dbms_xmldom.setAttribute(v_elem,'denialdesc',NVL(act_rec.denial_description,'-NA-'));
      dbms_xmldom.setAttribute(v_elem,'remarks',NVL(act_rec.remarks,'-NA-'));
      dbms_xmldom.setAttribute(v_elem,'currency',NVL(act_rec.currency_type,'-NA-'));
      dbms_xmldom.setAttribute(v_elem,'copayperc',NVL(act_rec.copay_perc,0));
      dbms_xmldom.setAttribute(v_elem,'actdtlseqid',act_rec.activity_dtl_seq_id);
      dbms_xmldom.setAttribute(v_elem,'toothnum', act_rec.tooth_no);
      v_node := dbms_xmldom.makeNode( v_elem );
      v_activity_node := dbms_xmldom.appendChild( v_parent_node, v_node );
    
    for observ_rec in observ_cur(act_rec.Activity_Dtl_Seq_Id) loop
      v_elem := dbms_xmldom.createElement(v_claim_doc, 'observationdetails');    
      dbms_xmldom.setAttribute(v_elem,'type',observ_rec.type);
      dbms_xmldom.setAttribute(v_elem,'code',observ_rec.observation_code_id);
      dbms_xmldom.setAttribute(v_elem,'value',observ_rec.value);
      dbms_xmldom.setAttribute(v_elem,'valuetype',observ_rec.value_type);
      v_node := dbms_xmldom.makeNode( v_elem );
      v_observ_node := dbms_xmldom.appendChild( v_activity_node, v_node );      
  
      end loop;      
     end loop;
      
      for diag_rec in diag_cur loop
      v_elem := dbms_xmldom.createElement(v_claim_doc, 'diagnosysdetails');
      dbms_xmldom.setAttribute(v_elem,'diagcode',diag_rec.diagnosys_code);
      dbms_xmldom.setAttribute(v_elem,'description',diag_rec.icd_description);
      dbms_xmldom.setAttribute(v_elem,'primary',case when diag_rec.primary_ailment_yn='Y' then 'Yes' else 'No' end);
      dbms_xmldom.setAttribute(v_elem,'copay',diag_rec.copay);
      dbms_xmldom.setAttribute(v_elem,'denailreason',diag_rec.denial_reason);
      dbms_xmldom.setAttribute(v_elem,'remarks',diag_rec.remarks);
      v_node := dbms_xmldom.makeNode( v_elem );
      v_diag_node := dbms_xmldom.appendChild( v_parent_node, v_node );
      end loop;  
      
      for payee_details in Claim_Payment_Details loop
      v_elem := dbms_xmldom.createElement(v_claim_doc, 'paymentdetails');
      dbms_xmldom.setAttribute(v_elem,'payee_name',payee_details.payee_name);
      dbms_xmldom.setAttribute(v_elem,'check_num',payee_details.check_num);
      dbms_xmldom.setAttribute(v_elem,'check_amount',payee_details.check_amount);
      dbms_xmldom.setAttribute(v_elem,'payee_type',payee_details.payee_type);
      dbms_xmldom.setAttribute(v_elem,'check_date',payee_details.check_date);
      dbms_xmldom.setAttribute(v_elem,'check_status',payee_details.check_status);
      dbms_xmldom.setAttribute(v_elem,'consignment_num',payee_details.consignment_num);
      dbms_xmldom.setAttribute(v_elem,'consignment_prov',payee_details.consignment_prov);
      dbms_xmldom.setAttribute(v_elem,'dispatched_date',payee_details.dispatched_date);
      dbms_xmldom.setAttribute(v_elem,'incurred_currency',payee_details.Req_Amt_Currency_Type);
      dbms_xmldom.setAttribute(v_elem,'transferred_currency',payee_details.transfer_currency);
      v_node := dbms_xmldom.makeNode( v_elem );
      v_payment_node := dbms_xmldom.appendChild( v_parent_node, v_node );
      end loop;      
   
       
     v_xml  := dbms_xmldom.getxmltype(v_claim_doc);
     v_claim_history_doc:=v_xml.getclobval();
  
    
     dbms_xmldom.freeDocument(v_claim_doc);
   END create_claim_xml;
--===============================================================================
PROCEDURE save_clm_batch_details(v_clm_batch_seq_id  in out clm_batch_upload_details.clm_batch_seq_id%type,
                                 v_batch_no          in out clm_batch_upload_details.batch_no%type,
                                 v_sender_id         in clm_batch_upload_details.sender_id%type,
                                 v_receiver_id       in clm_batch_upload_details.receiver_id%type,
                                 v_received_date     in clm_batch_upload_details.received_date%type,
                                 v_record_count      in clm_batch_upload_details.record_count%type,
                                 v_batch_tot_amount  in clm_batch_upload_details.batch_tot_amount%type,
                                 v_tpa_office_aeq_id in clm_batch_upload_details.tpa_office_aeq_id%type,
                                 v_batch_status_type in clm_batch_upload_details.batch_status_type%type,
                                 v_benefit_type      in clm_batch_upload_details.benefit_type%type,
                                 v_claim_type        in clm_batch_upload_details.clm_type_gen_type_id%type,
                                 v_submission_type   in clm_batch_upload_details.submission_type_id%type,
                                 v_currency_type     in clm_batch_upload_details.currency_type%type,
                                 v_source_type       in clm_batch_upload_details.source_type_id%type,
                                 v_override          in clm_batch_upload_details.batch_override%type,
                                 v_network_yn        in clm_batch_upload_details.network_yn%type,
                                 v_provider_name     in clm_batch_upload_details.provider_name%type,
                                 v_clm_from          in clm_batch_upload_details.claimfrom_gentype_id%type,
                                 v_added_by          in clm_batch_upload_details.added_by%type,
                                 v_process_type      in clm_batch_upload_details.process_type%type,
                                 v_pymnt_to_type_id  in clm_batch_upload_details.pymnt_to_type_id%type,
                                 v_partner_name      in clm_batch_upload_details.partner_name%type) IS
                                

CURSOR batch_cur(v_result VARCHAR2, v_length NUMBER) IS SELECT substr((d.batch_no),1,v_length)
                                          FROM clm_batch_upload_details d
                                          WHERE d.clm_batch_seq_id in (
                                        SELECT MAX(a.clm_batch_seq_id)--substr(MAX(d.batch_no),1,19)
                                         FROM clm_batch_upload_details a
                                         WHERE a.batch_no LIKE v_result||'%');
                                         
CURSOR encounter_cur IS SELECT case when c.general_type_id ='OPTS' then 'OP'
                                            when c.general_type_id ='IPT' then 'IP'
                                            when c.general_type_id = 'HEAC' then 'HC'
                                            when c.general_type_id = 'DAYC' then 'DC' 
                                            when c.general_type_id IN ('MTI', 'OMTI', 'IMTI') then 'MN'
                                            when c.general_type_id = 'DNTL' then 'DN'  
                                            when c.general_type_id = 'OPTC' then  'OC' end
                                          FROM tpa_general_code c
                                         WHERE c.header_type='BENIFIT_TYPE' 
                                         and c.general_type_id =v_benefit_type;                                        
   v_result            varchar2(1000);
   v_last_number       varchar2(100);
   v_flag              varchar2(10);
   v_clm_count         number;
   v_requested_amount  number;
   v_batch_num               NUMBER;
   v_batch_num_incr          NUMBER;
   v_track                   VARCHAR2(32000);
   
   

Cursor batch_status_cur is 
select ud.batch_status_type,ud.batch_tot_amount 
       from app.clm_batch_upload_details ud 
       where ud.clm_batch_seq_id=v_clm_batch_seq_id;

status_rec    batch_status_cur%rowtype;   

CURSOR batch_len_cur(v_clm_type VARCHAR2) IS
  select max(length(b.batch_no))
  from clm_batch_upload_details b
  where b.clm_batch_seq_id in (
  select max(d.clm_batch_seq_id)
  from app.clm_batch_upload_details d
  where d.batch_no like v_clm_type||'%'
 /* and d.batch_no not like '%R'*/
  and to_date(d.added_date, 'DD-MM-RRRR') = to_date(sysdate, 'DD-MM-RRRR'));

--DTR  
CURSOR dtr_batch_len_cur IS
  select max(length(d.batch_no))
  FROM APP.clm_batch_upload_details d
  where d.clm_batch_seq_id in (select max(b.clm_batch_seq_id) 
  from clm_batch_upload_details b
  where /*b.batch_no like '%R'
  and*/ to_date(b.added_date, 'DD-MM-RRRR') = to_date(sysdate, 'DD-MM-RRRR'));
  
CURSOR ptr_batch_len_cur(v_clm_type VARCHAR2) IS
  select max(length(b.batch_no))
  from clm_batch_upload_details b
  where b.clm_batch_seq_id in (select max(d.clm_batch_seq_id)
                               from app.clm_batch_upload_details d
                               where d.batch_no like v_clm_type||'-00001-'||'%'
                               and to_date(d.added_date, 'DD-MM-RRRR') = to_date(sysdate, 'DD-MM-RRRR')
                              );
      
v_batch_len         number;
BEGIN

  open batch_status_cur;
  fetch batch_status_cur into status_rec;
  close batch_status_cur;
  
  IF NVL(status_rec.batch_status_type,'INP')='COMP' and nvl(v_override,'N')='N' THEN
    RAISE_APPLICATION_ERROR(-20390,'You cannot perform this action through a completed Batch.');
  END IF;
  
  
  
  IF NVL(v_clm_batch_seq_id, 0) = 0 THEN
    IF v_submission_type = 'DTR' THEN
      OPEN dtr_batch_len_cur;
      FETCH dtr_batch_len_cur INTO v_batch_len;
      CLOSE dtr_batch_len_cur;
    ELSIF v_pymnt_to_type_id = 'PTN' THEN
      OPEN ptr_batch_len_cur(case when v_claim_type = 'CNH' then 'NC' else 'MR' end);
      FETCH ptr_batch_len_cur INTO v_batch_len;
      CLOSE ptr_batch_len_cur;
    ELSE  
      OPEN batch_len_cur(case when v_claim_type = 'CNH' then 'NC-'||TRIM(V_SENDER_ID) else 'MR-00001' end);
      FETCH batch_len_cur INTO v_batch_len;
      CLOSE batch_len_cur;
    END IF;
    
    IF v_batch_no IS NULL THEN
      IF v_claim_type = 'CNH' AND v_network_yn = 'Y' AND NVL(v_process_type,'RGL') = 'RGL' THEN
        v_result:= 'NC'||'-'||substr(lpad(v_sender_id,length(v_sender_id),0),-length(v_sender_id))||'-'||to_char(sysdate,'ddmmyyyy')||'-';
      ELSIF v_claim_type = 'CNH' AND v_network_yn = 'Y' AND NVL(v_process_type,'RGL') = 'DBL' THEN  
       IF v_claim_type = 'CNH' AND v_network_yn = 'Y' AND v_pymnt_to_type_id = 'PRV' THEN
        v_result:= 'NC'||'-'||substr(lpad(v_sender_id,length(v_sender_id),0),-length(v_sender_id))||'-'||to_char(sysdate,'ddmmyyyy')||'-'; 
       ELSIF v_claim_type = 'CNH' AND v_network_yn = 'Y' AND v_pymnt_to_type_id = 'PTN' THEN
        v_result:= 'NC'||'-'||'00001'||'-'||to_char(sysdate,'ddmmyyyy')||'-';
        v_track := 'v_result 1: '||v_result;
       END IF;
      ELSE
        v_result:= 'MR'||'-'||'00001'||'-'||to_char(sysdate,'ddmmyyyy')||'-';
      END IF;
      
      OPEN batch_cur(v_result, v_batch_len);
      FETCH batch_cur INTO v_last_number;
      CLOSE batch_cur;
      v_track := v_track||CHR(10)||'v_last_number 1: '||v_last_number||CHR(10)||'v_batch_len: '||v_batch_len;
      v_last_number := trim(trailing '-' from v_last_number);
      v_track := v_track||CHR(10)||'v_last_number 2: '||v_last_number;
      
      IF  v_last_number IS NOT NULL AND v_last_number LIKE 'MR%' THEN-------------------FIXING FOR BATCH NO GENERATION
        
        IF v_last_number like '%R' THEN 
          
          v_batch_num   :=  to_number(REPLACE(SUBSTR(v_last_number,19),'-R',''))  ;
      
        ELSE
          
          v_batch_num   :=  to_number(SUBSTR(v_last_number,19));
      
        END IF;
   
      END IF;
      
      OPEN encounter_cur;
      FETCH encounter_cur INTO v_flag;
      CLOSE encounter_cur;
      
      v_track := v_track||CHR(10)||'v_flag : '||v_flag;
      
      IF v_last_number IS NULL THEN
        v_result := v_result || '01';
        v_track := v_track||CHR(10)||'v_result2: '||v_result;
      ELSE
        if v_last_number like '%R' Then
         v_last_number := TRIM(TRAILING 'R' FROM v_last_number);
         v_last_number := trim(trailing '-' from v_last_number);
         --v_result := v_result ||lpad(TO_NUMBER(SUBSTR(v_last_number,INSTR(v_last_number, '-', -1, 1) + 1,(INSTR(v_last_number, '-', 1, 4) - INSTR(v_last_number, '-', 1, 3)) - 1)) +1,2,'0');
        END IF;
        IF v_last_number LIKE 'MR%' THEN 
           IF v_batch_num <= 8 THEN     -------------------FIXING FOR BATCH NO GENERATION
             v_batch_num_incr := v_batch_num + 1;
             v_result  :=  v_result||'0'||to_CHAR(v_batch_num_incr);
           ELSE 
             v_batch_num_incr := v_batch_num + 1;
             v_result  :=  v_result||to_CHAR(v_batch_num_incr);
           END IF;
           
         ELSE 
         
            v_result := v_result ||lpad(TO_NUMBER(substr(v_last_number,-2,2))+1,2,'0');
            
        END IF;
        
      END IF;
      IF v_submission_type='DTR' then
       --v_batch_no:=v_result||'-'||v_flag||'-'||'R';
       v_batch_no:=v_result||'-'||'R';
      ELSE
      --v_batch_no:=v_result||'-'||v_flag;
      v_batch_no:=v_result;
      v_track := v_track||CHR(10)||'v_batch_no :'||v_batch_no;
      END IF;
    END IF;
    
    INSERT INTO clm_batch_upload_details
      (CLM_BATCH_SEQ_ID,
       BATCH_NO,
       SENDER_ID,
       RECEIVER_ID,
       RECEIVED_DATE,
       TRANSACTION_DATE,
       RECORD_COUNT,
       DISPOSITION_FLAG,
       BATCH_TOT_AMOUNT,
       TPA_OFFICE_AEQ_ID,
       BATCH_STATUS_TYPE,
       clm_type_gen_type_id,
       submission_type_id,
       ADDED_BY,
       ADDED_DATE,
       CURRENCY_TYPE,
       SOURCE_TYPE_ID,
       benefit_type,
       network_yn,
       provider_name,
       claimfrom_gentype_id,
       process_type,
       pymnt_to_type_id,
       partner_name)
    VALUES
      (clm_batch_upload_detail_SEQ.Nextval,
       V_BATCH_NO,
       V_SENDER_ID,
       V_RECEIVER_ID,
       V_RECEIVED_DATE,
       SYSDATE,
       V_RECORD_COUNT,
       'TEST',
       V_BATCH_TOT_AMOUNT,
       V_TPA_OFFICE_AEQ_ID,
       V_BATCH_STATUS_TYPE,
       v_claim_type,
       v_submission_type,
       V_ADDED_BY,
       SYSDATE,
       v_currency_type,
       v_source_type,
       v_benefit_type,
       v_network_yn,
       v_provider_name,
       v_clm_from,
       NVL(v_process_type,'RGL'),
       v_pymnt_to_type_id,
       v_partner_name) RETURNING CLM_BATCH_SEQ_ID INTO v_clm_batch_seq_id;
       
       IF v_pymnt_to_type_id = 'PTN' THEN
         prc_track_error(v_clm_batch_seq_id, v_track, 'BATCH');
       END IF;
       
  ELSE
    
    if v_batch_status_type='COMP' and nvl(v_override,'N')='N' then 
      select count(1) into v_clm_count from app.clm_authorization_details ad 
      where ad.clm_batch_seq_id=v_clm_batch_seq_id;
      
      select sum(ad.requested_amount) into v_requested_amount from app.clm_authorization_details ad 
      where ad.clm_batch_seq_id=v_clm_batch_seq_id;
     if v_requested_amount!=status_rec.batch_tot_amount then 
        RAISE_APPLICATION_ERROR(-20388,'Claims total amount should be equal to batch total amount.');
     end if;
      if v_clm_count != v_record_count then
       RAISE_APPLICATION_ERROR(-20389,'Entered Claims count should be equal to no of calims recieved count to complete the batch.');
      end if;
     
    end if;
    UPDATE clm_batch_upload_details set
       SENDER_ID             = V_SENDER_ID,
       RECEIVER_ID           = V_RECEIVER_ID,
       RECEIVED_DATE         = V_RECEIVED_DATE,
       RECORD_COUNT          = V_RECORD_COUNT,
       BATCH_TOT_AMOUNT      = V_BATCH_TOT_AMOUNT,
       TPA_OFFICE_AEQ_ID     = V_TPA_OFFICE_AEQ_ID,
       BATCH_STATUS_TYPE     = V_BATCH_STATUS_TYPE,
       clm_type_gen_type_id  = v_claim_type,
       submission_type_id    = v_submission_type, 
       UPDATED_DATE          = SYSDATE,
       UPDATED_BY            = v_added_by,
       CURRENCY_TYPE         = v_currency_type,
       SOURCE_TYPE_ID        = v_source_type,
       batch_override        = v_override,
       benefit_type          = v_benefit_type,
       network_yn            = v_network_yn,
       provider_name         = v_provider_name,
       claimfrom_gentype_id  = v_clm_from,
       process_type          = NVL(v_process_type,'RGL'),
       pymnt_to_type_id      = v_pymnt_to_type_id,
       partner_name          = v_partner_name
       WHERE clm_batch_seq_id = v_clm_batch_seq_id;
    
  END IF;

END save_clm_batch_details;
--===============================================================================
FUNCTION generate_id_numbers (
    v_flag                           IN VARCHAR2,
    v_country_id                     IN VARCHAR2,
    v_state_id                       IN VARCHAR2,
    v_number                         IN VARCHAR2,  -- CAN BE PREAUTH NUMBER OR SHORTFALL_ID OR INVESTIGATION_ID
    v_claim_type                     IN VARCHAR2 := NULL
  ) RETURN VARCHAR2
  IS
--    PRAGMA AUTONOMOUS_TRANSACTION ;
    v_office_code                    tpa_office_info.office_code%TYPE;
    v_result                         VARCHAR2(60);
    v_last_number                    VARCHAR2(60);
    v_settlement_flag                VARCHAR2(4);

    CURSOR pa_cur(v_result VARCHAR2) IS SELECT MAX(pre_auth_number)
                                          FROM pat_authorization_details
                                         WHERE pre_auth_number LIKE v_result||'%';

 
    CURSOR clm_cur(v_result VARCHAR2) IS SELECT MAX(claim_number )
                                          FROM clm_authorization_details
                                         WHERE claim_number  LIKE v_result||'%';

   
  
    CURSOR settlement_cur (v_result VARCHAR2) IS SELECT MAX(a.SETTLEMENT_NUMBER )
                                          FROM clm_authorization_details A
                                         WHERE a.SETTLEMENT_NUMBER  LIKE v_result||'%';
    CURSOR file_number_cur (v_result VARCHAR2) IS SELECT MAX(a.claim_file_number)
                                          FROM clm_general_details A
                                         WHERE a.claim_file_number  LIKE v_result||'%';

   CURSOR shortfall_cur IS SELECT MAX(a.shortfall_id)
                                  FROM shortfall_details a
                                 WHERE a.shortfall_id LIKE v_number||'-S%';
   
  BEGIN
    

    IF v_flag = 'PA' THEN -- PREAUTH NUMBER
      v_result := v_country_id||'-'||v_state_id||'-'||to_char(SYSDATE,'mmyy')||'-'||v_flag||'-';

      OPEN pa_cur(v_result);
      FETCH pa_cur INTO v_last_number;
      CLOSE pa_cur;

      IF v_last_number IS NULL THEN
        v_result := v_result || '0000001';
      ELSE
        v_result := v_result ||LPAD(TO_NUMBER(SUBSTR(v_last_number,-7))+1,7,'0');
      END IF;
    ELSIF v_flag = 'AT' THEN    -- AUTHORIZATION NUMBER
      v_result := REPLACE(v_number,'-PA-','-AT-');
    ELSIF v_flag = 'CNH' THEN    -- AUTHORIZATION NUMBER
      v_result := REPLACE(v_number,'-CL-','-CH-');
    ELSIF v_flag = 'CTM' THEN    -- AUTHORIZATION NUMBER
      v_result := REPLACE(v_number,'-CL-','-CR-');
    ELSIF v_flag IN ('STC','STA') THEN  -- SETTLEMENT NUMBER
      IF v_claim_type = 'CNH' THEN
        v_settlement_flag := 'CH';
        TTK_UTIL_PKG.reset_id_flag(v_office_code||'NHCP_SETTLEMENT','N');
      ELSE
        v_settlement_flag := 'CR';
        TTK_UTIL_PKG.reset_id_flag(v_office_code||'MR_SETTLMENT','N');
      END IF;
      IF v_flag = 'STA' THEN
        v_settlement_flag := 'A'||SUBSTR(v_settlement_flag,2);
      END IF;

      v_result := v_country_id||'-'||v_state_id||'-'||to_char(SYSDATE,'mmyy')||'-'||v_settlement_flag||'-';

      OPEN settlement_cur(v_result);
      FETCH settlement_cur INTO v_last_number;
      CLOSE settlement_cur;

      IF v_last_number IS NULL THEN
        v_result := v_result || '0000001';
      ELSE
        v_result := v_result ||LPAD(TO_NUMBER(SUBSTR(v_last_number,-7))+1,7,'0');
      END IF;

    ELSIF v_flag = 'FL' THEN          -- FILE NUMBER IN CLAIMS

      v_result := v_office_code||'-'||to_char(SYSDATE,'mmyy')||'-'||v_flag||'-';
      TTK_UTIL_PKG.reset_id_flag(v_office_code||'FILENUMBER','N');
      OPEN file_number_cur( v_result );
      FETCH file_number_cur INTO v_last_number;
      CLOSE file_number_cur;

      IF v_last_number IS NULL THEN
        v_result := v_result || '0000001';
      ELSE
        v_result := v_result ||LPAD(TO_NUMBER(SUBSTR(v_last_number,-7))+1,7,'0');
      END IF;
      --TTK_UTIL_PKG.reset_id_flag(v_office_code||'FILENUMBER','Y');
    ELSIF v_flag = 'CL' OR v_flag = 'AM' THEN   -- CLAIM NUMBER OR AMMENDMENT

      v_result := v_country_id||'-'||v_state_id||'-'||to_char( SYSDATE,'mmyy' )||'-'||v_flag||'-';
     

      OPEN clm_cur(v_result);
      FETCH clm_cur INTO v_last_number;
      CLOSE clm_cur;

      IF v_last_number IS NULL THEN
        v_result := v_result || '0000001';
      ELSE
        v_result := v_result ||LPAD(TO_NUMBER(SUBSTR(v_last_number,-7))+1,7,'0');
      END IF;
     ELSIF v_flag = 'STH' THEN  -- Shortfall

      OPEN shortfall_cur;
      FETCH shortfall_cur INTO v_result ;
      CLOSE shortfall_cur;

      IF v_result IS NULL THEN
        v_result := v_number||'-S01';
      ELSE
        v_result := SUBSTR(v_result,1, length(v_result) - 2)|| lpad(to_number( SUBSTR(v_result,-2) ) + 1,2,'0');
      END IF;
  
    END IF;
    RETURN v_result;
  END generate_id_numbers;
--===============================================================================
PROCEDURE select_clm_batch_details(v_clm_batch_seq_id IN clm_batch_upload_details.clm_batch_seq_id%type,
                                   result_set         OUT SYS_REFCURSOR,
                                   batch_clms         OUT SYS_REFCURSOR) IS

 
CURSOR Shortfall_info IS
  SELECT s.srtfll_sent_date 
      FROM CLM_AUTHORIZATION_DETAILS C
         JOIN SHORTFALL_DETAILS S ON (C.CLAIM_SEQ_ID=S.CLAIM_SEQ_ID)
      WHERE C.CLM_BATCH_SEQ_ID=v_clm_batch_seq_id
      ORDER BY s.shortfall_seq_id DESC;
      
 v_rec_date     DATE;     
BEGIN
  
 OPEN Shortfall_info;
   FETCH Shortfall_info INTO v_rec_date;
     CLOSE Shortfall_info;
     
  OPEN result_set FOR
    select d.clm_batch_seq_id,
           d.batch_no,
           d.sender_id,
           d.receiver_id ,
           d.received_date,
           d.transaction_date,
           d.record_count,
           d.disposition_flag,
           d.batch_tot_amount,
           d.tpa_office_aeq_id,
           d.batch_status_type ,
           d.benefit_type,
           d.clm_type_gen_type_id,
           d.submission_type_id,
           d.currency_type,
           d.source_type_id,
           d.batch_override,
           d.network_yn,
           d.provider_name,
           d.claimfrom_gentype_id as claim_from,
           case when d.batch_status_type='COMP' THEN 'Y' ELSE 'N' END AS COMPLETED_YN,
           NVL(d.process_type,'RGL') AS process_type,
           d.partner_name,
           d.pymnt_to_type_id,
           CASE WHEN d.clm_type_gen_type_id='CNH' AND v_rec_date IS NULL THEN
             CASE WHEN (SYSDATE-d.received_date) BETWEEN f.fst_from_days AND f.fst_to_days THEN 
                'Y' ELSE 'N' END 
                 WHEN d.clm_type_gen_type_id='CNH' AND v_rec_date IS NOT NULL THEN 
                CASE WHEN (sysdate-v_rec_date) BETWEEN f.fst_from_days AND f.fst_to_days THEN 
                'Y' ELSE 'N' END 
            ELSE 'N' END AS Fast_Track,
           CASE WHEN d.clm_type_gen_type_id='CNH' AND v_rec_date IS NULL THEN 
              CASE WHEN (SYSDATE-d.received_date) BETWEEN f.fst_from_days AND f.fst_to_days+1 THEN 
                to_char(f.fst_to_days-trunc(SYSDATE-d.received_date)) ||' Days Remaining For Payment' ELSE 'N' END 
               WHEN d.clm_type_gen_type_id='CNH' AND v_rec_date IS NOT NULL THEN     
              CASE WHEN (SYSDATE-v_rec_date) BETWEEN f.fst_from_days AND f.fst_to_days+1 THEN
                to_char(f.fst_to_days-trunc(sysdate-v_rec_date)) ||' Days Remaining For Payment' ELSE 'N' END
               ELSE 'N' end  AS Fast_Track_Messege

      from clm_batch_upload_details d
      LEFT OUTER JOIN app.tpa_hosp_info i on (i.hosp_licenc_numb=d.sender_id)
      LEFT OUTER JOIN app.tpa_fasttract_disc_details f on (i.hosp_seq_id=f.hosp_seq_id AND f.disc_mode='FAST'
      and d.received_date between f.start_date and f.end_date+1 and f.status='ACT')
      where d.clm_batch_seq_id = v_clm_batch_seq_id;
   
   OPEN batch_clms FOR
    select ad.invoice_number,
           ad.claim_seq_id,
           round(ad.requested_amount,2)  as requested_amount,----newly added round
           ad.member_seq_id,
           ad.tpa_enrollment_id,
           ad.re_submission_remarks as remarks,
           ad.claim_number,
           ad.parent_claim_seq_id,
           cad.claim_number as parent_claim_number
       from clm_batch_upload_details d join clm_authorization_details ad on (d.clm_batch_seq_id=ad.clm_batch_seq_id)
       left outer join clm_authorization_details cad on (ad.parent_claim_seq_id=cad.claim_seq_id)
       where d.clm_batch_seq_id = v_clm_batch_seq_id
       order by ad.claim_seq_id desc;

END select_clm_batch_details;
--===============================================================================
PROCEDURE add_batch_clms(
        v_claim_seq_id                  in  out clm_authorization_details.claim_seq_id%type,
        v_clm_batch_seq_id              in  clm_authorization_details.clm_batch_seq_id%type,
        v_parent_claim_seq_id           in  OUT clm_authorization_details.parent_claim_seq_id%type,
        v_clm_received_date             in  clm_authorization_details.clm_received_date%type,
        v_claim_type                    in  clm_authorization_details.claim_type%type,
        v_benifit_type                  in  clm_authorization_details.benifit_type%type,
        v_invoice_number                in  clm_authorization_details.invoice_number%type,
        v_requested_amount              in  clm_authorization_details.requested_amount%type,
        v_tot_amount                    in  number,
        v_provider_id                   in  clm_hospital_details.provider_id%type,
        v_member_seq_id                 in  clm_authorization_details.member_seq_id%type,
        v_tpa_enrollmemnt_id            in  clm_authorization_details.tpa_enrollment_id%type,
        v_remarks                       in  clm_authorization_details.re_submission_remarks%type, 
        v_added_by                      in  clm_authorization_details.added_by%type,
        v_pymnt_to_type_id              in  clm_authorization_details.pymnt_to_type_id%type,
        v_ptnr_seq_id                   in  clm_authorization_details.ptnr_seq_id%type,
        v_rows_processed                out number) is
  
  Cursor batch_tot_amount is 
  select round(ud.batch_tot_amount,2) as batch_tot_amount,ud.record_count,ud.batch_status_type,
  ud.submission_type_id,ud.batch_override,ud.network_yn 
  from app.clm_batch_upload_details ud 
  where ud.clm_batch_seq_id=v_clm_batch_seq_id;   ----newly added round
  
  batch_rec    batch_tot_amount%rowtype;
  v_clm_count     number;
  v_total_amount  number;
  v_count         number;
  v_clm_status    varchar2(100);
  v_hosp_seq_id   number;
  v_prev_claim_seq_id clm_authorization_details.parent_claim_seq_id%type;
  cursor get_hos_seq_no is 
  select i.hosp_seq_id  from app.tpa_hosp_info i where i.hosp_licenc_numb=trim(v_provider_id);
  
  cursor Clamis_Count is
  select COUNT(1) 
  from clm_authorization_details cad 
  where cad.clm_status_type_id in ('APR','REJ','PCO')
  AND cad.claim_seq_id=v_claim_seq_id;
  
  cursor Clami_Conversion_Rate is
  select cad.conversion_rate 
  from clm_authorization_details cad 
  where  cad.claim_seq_id=v_claim_seq_id;
  
  v_claim_count            NUMBER;
  v_claim_con              NUMBER;
  
  BEGIN

     open batch_tot_amount;
     fetch batch_tot_amount into batch_rec;
     close batch_tot_amount ;
     
     OPEN Clamis_Count;
       FETCH Clamis_Count INTO v_claim_count;
         CLOSE Clamis_Count;
     
     IF v_claim_count>0 THEN
       RAISE_APPLICATION_ERROR(-20289,'You cannot perform this action through a completed claim.');
     END IF;
     
     IF NVL(batch_rec.batch_status_type,'INP')='COMP' and nvl(batch_rec.batch_override,'N')='N' THEN
      RAISE_APPLICATION_ERROR(-20390,'You cannot perform this action through a completed Batch.');
     END IF;  
    
    if v_clm_batch_seq_id is not null and nvl(v_claim_seq_id,0)=0 then
    select count(1) into v_clm_count from app.clm_authorization_details ad 
      where ad.clm_batch_seq_id=v_clm_batch_seq_id;
     if nvl(v_clm_count,0)>=batch_rec.record_count then
       RAISE_APPLICATION_ERROR(-20389,'Entered Claims count should be equal to no of calims recieved count to complete the batch.');
     end if;
    
     v_total_amount:=nvl(v_tot_amount,0)+nvl(round(v_requested_amount,2),0);  ----newly added round
    if  nvl(v_total_amount,0)>batch_rec.batch_tot_amount then
          RAISE_APPLICATION_ERROR(-20388,'Claims total amount should be equal to batch total amount.');
    end if;
    if v_invoice_number is not null then 
    select count(1) into v_count from clm_authorization_details ad where ad.clm_batch_seq_id=v_clm_batch_seq_id
    and trim(ad.invoice_number)=trim(v_invoice_number);
    end if;
    
    if v_count>0 then 
    RAISE_APPLICATION_ERROR(-20391,'Duplicate invocenumber.');
    end if;
    
    end if; 
    
    if v_provider_id is not null and nvl(batch_rec.network_yn,'N')='Y'then 
     open get_hos_seq_no ;
     fetch get_hos_seq_no into v_hosp_seq_id;
     close get_hos_seq_no;
      --select i.hosp_seq_id into v_hosp_seq_id from app.tpa_hosp_info i where i.hosp_licenc_numb=trim(v_provider_id);
    end if;
   
    IF NVL(v_claim_seq_id,0)=0 THEN
        
      INSERT INTO clm_authorization_details 
        (claim_seq_id,
         clm_batch_seq_id,
         parent_claim_seq_id,
         clm_received_date,
         member_seq_id,
         tpa_enrollment_id,
         claim_type,
         benifit_type,
         added_by,
         added_date,
         invoice_number,
         requested_amount,
         re_submission_remarks,
         clm_status_type_id,
         pymnt_to_type_id,
         ptnr_seq_id)
     VALUES (
          clm_authorization_detail_seq.nextval,
          v_clm_batch_seq_id,
          v_parent_claim_seq_id,
          v_clm_received_date,
          v_member_seq_id,
          v_tpa_enrollmemnt_id,
          v_claim_type,
          v_benifit_type,
          v_added_by,
          sysdate,
          v_invoice_number,
           round(v_requested_amount,2),  ----newly added round
          v_remarks,
          'INP',
          v_pymnt_to_type_id,
          v_ptnr_seq_id) returning claim_seq_id into v_claim_seq_id ;
    
    
    
    insert into clm_hospital_details 
      (clm_hosp_assoc_seq_id,
       claim_seq_id,
       hosp_seq_id,
       added_by,
       added_date,
       provider_id)
    values
      (clm_hosp_dtl_hosp_assoc_seq.nextval,
       v_claim_seq_id,
       v_hosp_seq_id,
       v_added_by,
       sysdate,
       v_provider_id);
    
    IF batch_rec.submission_type_id='DTR' AND v_parent_claim_seq_id IS NOT NULL THEN 
      copy_previous_claim(v_claim_seq_id,v_parent_claim_seq_id,v_clm_batch_seq_id,round(v_requested_amount,2),v_added_by);  -----newly added round
    END IF; 
    
    ELSE
      
      SELECT  a.parent_claim_seq_id
       INTO v_prev_claim_seq_id 
              FROM clm_authorization_details a WHERE a.claim_seq_id = v_claim_seq_id;
    v_total_amount:=nvl(round(v_requested_amount,2),0)/*+nvl(v_requested_amount,0)*/; -----newly added round
    if  nvl(v_total_amount,0)>batch_rec.batch_tot_amount then
          RAISE_APPLICATION_ERROR(-20388,'Claims total amount should be equal to batch total amount.');
    end if;
    if v_prev_claim_seq_id != v_parent_claim_seq_id then 
      delete_claim_records(v_claim_seq_id);
    end if;
    
    open Clami_Conversion_Rate;
      fetch Clami_Conversion_Rate into v_claim_con;
       close Clami_Conversion_Rate;
       
    UPDATE clm_authorization_details SET
         parent_claim_seq_id   = v_parent_claim_seq_id,
         clm_received_date     = v_clm_received_date ,
         claim_type            = v_claim_type,
         /*member_seq_id         = v_member_seq_id,
         tpa_enrollment_id     = v_tpa_enrollmemnt_id,   
         benifit_type          = v_benifit_type,*/--commented by venu
         updated_by            = v_added_by,
         updated_date          = sysdate,
         invoice_number        = v_invoice_number,
         requested_amount      = v_requested_amount,-----newly added round
         converted_amount      = v_requested_amount*v_claim_con,
         re_submission_remarks = v_remarks,
         clm_status_type_id    = 'INP',
         pymnt_to_type_id      = v_pymnt_to_type_id,
         ptnr_seq_id           = v_ptnr_seq_id
     WHERE claim_seq_id = v_claim_seq_id;
      
    
    update clm_hospital_details set
        claim_seq_id    = v_claim_seq_id,
        hosp_seq_id     = v_hosp_seq_id,
        updated_by      = v_added_by,
        updated_date    = sysdate,
        provider_id     = v_provider_id
        where claim_seq_id = v_claim_seq_id;
     IF batch_rec.submission_type_id='DTR' AND v_parent_claim_seq_id IS NOT NULL THEN 
      copy_previous_claim(v_claim_seq_id,v_parent_claim_seq_id,v_clm_batch_seq_id,round(v_requested_amount,2),v_added_by);   -----newly added round 
     END IF; 
    
    END IF;
     
    commit;
  END add_batch_clms;
--===============================================================================
PROCEDURE select_clm_batch_list (
    v_batch_no                           IN  clm_batch_upload_details.batch_no%type,
    v_provider_id                        IN  clm_batch_upload_details.sender_id%type,
    v_received_date                      IN  varchar2,
    V_to_date                            IN  varchar2,
    v_batch_status_type                  IN  clm_batch_upload_details.batch_status_type%TYPE,
    v_clm_type                           IN  clm_batch_upload_details.clm_type_gen_type_id%type,
    v_clm_mode                           IN  clm_authorization_details.source_type_id%type,
    v_submission_type                    IN  clm_batch_upload_details.Submission_Type_Id%TYPE,
    v_sort_var                           IN  VARCHAR2,
    v_sort_order                         IN  VARCHAR2 ,
    v_start_num                          IN  NUMBER ,
    v_end_num                            IN  NUMBER ,
    v_added_by                           IN  NUMBER,
    v_process_type                       in clm_batch_upload_details.process_type%type,
    result_set                           OUT SYS_REFCURSOR
  )
  IS

    v_sql_str                            VARCHAR2(10000) ;
    TYPE bind_tab_type IS TABLE OF VARCHAR2(250) INDEX BY BINARY_INTEGER ;
    bind_tab                             bind_tab_type;
    i                                    NUMBER(2) := 0;
    v_where                              VARCHAR2(2000);
   
    v_clm_received_date clm_batch_upload_details.received_date%type:=TO_DATE(v_received_date, 'dd/mm/yyyy');
    v_clm_to_date  date:=case when V_to_date is not null then to_date(V_to_date,'dd/mm/yyyy') else sysdate end;
    
 BEGIN
    
    
    v_sql_str :=
     'select ud.batch_no,
           ud.clm_batch_seq_id,
           case when ud.network_yn=''N'' then ud.provider_name else hi.hosp_name end as hosp_name,
           ud.received_date,
           ud.transaction_date,
           case when ud.submission_type_id=''DTC'' then ''Claim Submission'' 
               when ud.submission_type_id=''DTR'' then ''Claim Re-Submission'' end as submission_type,
           case when ud.clm_type_gen_type_id=''CTM'' then ''MEMBER'' ELSE ''NETWORK'' END AS CLAIM_TYPE,
           NVL(pt.description,''Regular'') as process_type,
           case when (SYSDATE-ud.received_date) between fd.fst_from_days and fd.fst_to_days then ''Y'' else ''N'' end as Fasttrack_yn,
           case when (SYSDATE-ud.received_date) between fd.fst_from_days and fd.fst_to_days then to_char(fd.fst_to_days-trunc(SYSDATE-ud.received_date)) ||'' Days Remaining For payment'' else ''N'' end as Fasttrack_mesg             
    from clm_batch_upload_details ud 
    left outer join tpa_hosp_info hi on (hi.hosp_licenc_numb=ud.sender_id) 
    left outer join tpa_general_code pt on (pt.general_type_id=ud.process_type)
    left outer join Tpa_Fasttract_Disc_Details fd on (fd.hosp_seq_id=hi.hosp_seq_id
    and ud.received_date between fd.start_date and fd.end_date and fd.status=''ACT'' and fd.Disc_Mode=''FAST'')';

    IF v_batch_no IS NOT NULL THEN
      v_where := v_where  ||' AND ud.batch_no = :v_batch_no ';
       i := i+1;
       bind_tab(i) := (v_batch_no);
    END IF;

  

    IF v_provider_id IS NOT NULL THEN
      v_where := v_where  ||' AND ud.sender_id = :v_provider_id';
      i := i+1;
      bind_tab(i) := UPPER(v_provider_id);
    END IF;


    IF v_clm_received_date IS NOT NULL THEN
      v_where := v_where  ||' AND ud.received_date between :v_clm_received_date_1 and :v_clm_received_date_2';
      i := i+1;
      bind_tab(i) := v_clm_received_date;
      i := i+1;
      bind_tab(i) := v_clm_to_date + 1;
      
    END IF;
    

  
    
   /* IF v_pat_received_date IS NOT NULL THEN
      v_where := v_where  ||' AND pad.pat_received_date  BETWEEN :v_pat_received_date_1 AND :v_pat_received_date_2 ';
      i := i+1;
      bind_tab(i) := v_pat_received_date;
      i := i+1;
      bind_tab(i) := v_pat_received_date + 1;
    END IF;*/

       
    IF v_batch_status_type IS NOT NULL THEN
      v_where := v_where  ||' AND ud.batch_status_type = :v_batch_status_type';
       i := i+1;
       bind_tab(i) := UPPER(v_batch_status_type);
    END IF;
    
    IF v_clm_type IS NOT NULL THEN
       v_where := v_where  || ' AND ud.clm_type_gen_type_id = :v_clm_type';
       i := i+1;
       bind_tab(i) := UPPER(v_clm_type); 
    END IF;
    
    IF v_clm_mode IS NOT NULL THEN
      v_where := v_where  ||' AND ud.source_type_id = :v_clm_mode';
      i := i+1;
      bind_tab(i) := v_clm_mode;
    END IF;
  
    IF v_submission_type IS NOT NULL THEN
      v_where := v_where  ||' AND ud.Submission_Type_Id = :v_submission_type';
      i := i+1;
      bind_tab(i) := v_submission_type;
    END IF;
    
    IF v_process_type IS NOT NULL THEN
      v_where := v_where  || ' AND NVL(ud.process_type,''RGL'') = :v_process_type ';
       i := i+1;
       bind_tab(i) := v_process_type;
   END IF;
    
    IF v_where IS NOT NULL THEN
      v_where   := ' WHERE '|| SUBSTR(v_where,5);
      v_sql_str := v_sql_str ||v_where;
    END IF;
    

    v_sql_str := 'SELECT * FROM
        (SELECT A.*,DENSE_RANK() OVER (ORDER BY '||v_sort_var||' '||v_sort_order||',ROWNUM)
        Q FROM (' ||v_sql_str|| ') A ) WHERE  Q>= :v_start_num AND Q<= :v_end_num ';


    IF bind_tab.FIRST IS NOT NULL THEN
       CASE bind_tab.COUNT
         WHEN 1  THEN OPEN result_set FOR v_sql_str USING bind_tab(1), v_start_num , v_end_num ;
         WHEN 2  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2), v_start_num , v_end_num ;
         WHEN 3  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2) ,bind_tab(3) , v_start_num , v_end_num ;
         WHEN 4  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) , v_start_num , v_end_num ;
         WHEN 5  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5) , v_start_num , v_end_num ;
         WHEN 6  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5) ,bind_tab(6) ,v_start_num , v_end_num ;
         WHEN 7  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5) ,bind_tab(6) ,bind_tab(7) ,v_start_num , v_end_num ;
         WHEN 8  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5) ,bind_tab(6) ,bind_tab(7) ,bind_tab(8) ,v_start_num , v_end_num ;
       END CASE;
     ELSE
       OPEN result_set FOR v_sql_str USING v_start_num , v_end_num ;
     END IF;

  END select_clm_batch_list;
--===============================================================================
PROCEDURE select_claims_list (
    v_invoice_number                     IN  clm_authorization_details.invoice_number%type,
    v_batch_no                           IN  clm_batch_upload_details.batch_no%type,
    v_policy_number                      IN  tpa_enr_policy.policy_number%type,
    v_claim_number                       IN  clm_authorization_details.claim_number%type,
    v_claim_type                         IN  clm_batch_upload_details.clm_type_gen_type_id%type,
    v_received_date                      IN  varchar2,
    v_settlement_number                  IN  clm_authorization_details.settlement_number%TYPE,
    v_tpa_enrollment_id                  IN  clm_authorization_details.tpa_enrollment_id%type,
    v_mem_name                           IN  clm_authorization_details.mem_name%type,
    v_clm_status_type_id                 IN  clm_authorization_details.clm_status_type_id%type,
    v_provider_id                        IN  clm_hospital_details.provider_id%type,
    v_ins_seq_id                         IN  clm_authorization_details.ins_seq_id%type,
    v_clm_mode                           IN  clm_authorization_details.source_type_id%type,
    v_global_mem_id                      IN  tpa_enr_policy_member.global_net_member_id%type,
    v_assign_user                        IN    VARCHAR2,
    v_other_user                         IN    VARCHAR2,
    v_added_by                           IN  NUMBER,
    v_process_type                       IN  clm_authorization_details.process_type%type,
    v_srtfll_status_type                 IN  Shortfall_Details.Srtfll_Status_General_Type_Id%TYPE,
    v_event_no                           IN  clm_authorization_details.event_no%TYPE,
    v_common_file_num                    IN  VARCHAR2,
    v_internal_remark_stat               IN  clm_authorization_details.status_code_id%type,
    v_partner_seq_id                     IN  clm_authorization_details.ptnr_seq_id%type,
    v_benifit_type                       IN  clm_authorization_details.benifit_type%type,
    v_req_amt_oper                       IN  VARCHAR2,
    v_req_amount                         IN  VARCHAR2,
    v_linked_pre_no                      IN  VARCHAR2,
    v_qatar_id                           IN  tpa_enr_policy_member.emirate_id%type,
    v_inp_status                         IN  VARCHAR2,
    v_risk_level                         IN  clm_authorization_details.risk_level%type,
    v_inv_status                         IN  tpa_fraud_inv_details.inv_status%type,
    v_fast_disc                          IN  VARCHAR2,
    v_pr_from                            IN  VARCHAR2,
    v_pr_to                              IN  VARCHAR2,
    v_sort_var                           IN  VARCHAR2,
    v_sort_order                         IN  VARCHAR2 ,
    v_start_num                          IN  VARCHAR2 ,
    v_end_num                            IN  VARCHAR2 ,
    result_set                           OUT SYS_REFCURSOR,
    v_priority_flag                      IN  VARCHAR2,
    v_audit_status                       IN  VARCHAR2
  )
  IS

    v_sql_str                            VARCHAR2(10000) ;
    TYPE bind_tab_type IS TABLE OF VARCHAR2(250) INDEX BY BINARY_INTEGER ;
    bind_tab                             bind_tab_type;
    i                                    NUMBER(2) := 0;
    v_where                              VARCHAR2(2000);
    v_shr_rec_date                       DATE;
    v_clm_received_date clm_batch_upload_details.received_date%type:=TO_DATE(v_received_date, 'dd/mm/yyyy');
    v_inp_status1                        VARCHAR2(10);
  BEGIN
    v_sql_str :=
     'with shrtfll as (select max(s.shortfall_seq_id) AS shortfall_seq_id,c.claim_seq_id
                       from clm_authorization_details c
                       join shortfall_details s on (c.claim_seq_id = s.claim_seq_id)
                       --where (s.srtfll_status_general_type_id = '''||v_srtfll_status_type||''' or '''||v_srtfll_status_type||''' is null)
                       group by c.claim_seq_id
                      ),
      inv_staus as (select max(inv_seq_id) as inv_seq_id ,claim_seq_id from tpa_fraud_inv_details group by claim_seq_id)
      select a.batch_no,
            b.claim_number,
            replace(b.invoice_number,'',#'','', #'') as invoice_number,
            b.claim_seq_id,
            a.clm_batch_seq_id,
            nvl(g.tpa_enrollment_id,b.tpa_enrollment_id) as tpa_enrollment_id,
            a.clm_type_gen_type_id,
            g.mem_name||'' ''|| g.mem_last_name||'' ''|| g.family_name as mem_name,
            case when a.network_yn=''N'' then c.hosp_name else nvl(c.hosp_name,d.hosp_name) end as hosp_name,
            f.contact_name,
            a.received_date,
            gc.description,
            case when a.submission_type_id=''DTC'' then ''Claim Submission'' 
               when a.submission_type_id=''DTR'' then ''Claim Re-Submission'' end as submission_type,
            tg.description as claim_type,
            a.benefit_type AS benefit_types,
            g.global_net_member_id as TPA_ALTERNATE_ID,
            d.remarks as PROVIDER_SPECIFIC_REMARKS,
            NVL(pt.description,''Regular'') as process_type,
            f.TPA_OFFICE_SEQ_ID,
            case when sd.srtfll_status_general_type_id = ''RES'' then ''Y'' else ''N'' end as SHRTFALL_YN,
            case when sd.srtfll_status_general_type_id = ''RES'' then  to_char(sd.updated_date, ''DD/MM/RRRR HH:MI:SS AM'') end srtfll_updated_date,
            nvl(b.event_no, '' '') as event_no,
            case when b.STATUS_CODE_ID is not null then ''Y'' else ''N'' end as FRAUD_YN,
            case when b.status_code_id is not null and nvl(b.suspect_veri_check,''N'') =''Y'' 
                 THEN CASE b.status_code_id WHEN ''ALKT'' THEN ''Alkoot clarification - Verified''
                                        WHEN ''SUSP'' THEN ''Suspected claim - Verified''
                                        WHEN ''PROV'' THEN ''Provider clarification - Verified'' end
            when b.status_code_id is not null and  nvl(b.suspect_veri_check,''N'') =''N'' THEN  fr.status_desc end as status_desc,
            b.status_code_id,
            NVL(b.suspect_veri_check,''N'') as suspect_veri_check,
            b.converted_amount,
            nvl(g.emirate_id,b.emirate_id) as qatar_id,
            B.CLM_STATUS_TYPE_ID||''-''||'||''''||v_inp_status||'''' ||' AS IN_PROGESS_STATUS,
            CASE WHEN a.clm_type_gen_type_id=''CNH'' AND SRTFLL_RECEIVED_DATE IS NULL THEN
             CASE WHEN (SYSDATE-a.received_date) BETWEEN fa.fst_from_days AND fa.fst_to_days THEN 
                ''Y'' ELSE ''N'' END 
                 WHEN a.clm_type_gen_type_id=''CNH'' AND SRTFLL_RECEIVED_DATE IS NOT NULL THEN 
                CASE WHEN (sysdate-SRTFLL_RECEIVED_DATE) BETWEEN fa.fst_from_days AND fa.fst_to_days THEN 
                ''Y'' ELSE ''N'' END 
           ELSE ''N'' END AS Fast_Track,
           CASE WHEN a.clm_type_gen_type_id=''CNH'' AND SRTFLL_RECEIVED_DATE IS NULL THEN 
              CASE WHEN (SYSDATE-a.received_date) BETWEEN fa.fst_from_days AND fa.fst_to_days+1 THEN 
                to_char(fa.fst_to_days-trunc(SYSDATE-a.received_date)) ||'' Days Remaining For Payment'' ELSE ''N'' END 
               WHEN a.clm_type_gen_type_id=''CNH'' AND SRTFLL_RECEIVED_DATE IS NOT NULL THEN     
              CASE WHEN (SYSDATE-SRTFLL_RECEIVED_DATE) BETWEEN fa.fst_from_days AND fa.fst_to_days+1 THEN
                to_char(fa.fst_to_days-trunc(sysdate-SRTFLL_RECEIVED_DATE)) ||'' Days Remaining For Payment'' ELSE ''N'' END
               ELSE ''N'' end  AS Fast_Track_Messege,
                 CASE WHEN B.clm_status_type_id IN(''INP'',''REQ'') THEN TRUNC(SYSDATE-b.Clm_Received_Date) ELSE NULL END as claim_age,
                 d.Payment_Dur_Agr,
            nvl(reg.priority_corporate_yn,''N'') priority_corporate,
            ''priorityCorp'' as GROUPIMAGENAME,
            ''Priority Coporate'' as GROUPIMAGETITLE,
            case when b.clm_status_type_id =''APR'' THEN b.final_app_amount else null end as approved_amount,
            case when a.submission_type_id=''DTC'' then ''N'' 
                 when a.submission_type_id=''DTR'' then ''Y'' end as resubmission_flag              
                       
    from clm_batch_upload_details a join clm_authorization_details b on (a.clm_batch_seq_id=b.clm_batch_seq_id and a.batch_status_type=''COMP'')
    left outer join tpa_enr_policy_member g on (g.member_seq_id=b.member_seq_id)
    left outer join tpa_enr_policy e on (e.policy_seq_id=b.policy_seq_id)
    left outer join clm_hospital_details c on (c.claim_seq_id=b.claim_seq_id)
    left outer join tpa_hosp_info d on (d.hosp_seq_id=c.hosp_seq_id)
    left outer join assign_users au on (au.assign_users_seq_id=b.assign_user_seq_id)
    left outer join tpa_user_contacts f on (f.contact_seq_id=au.assigned_to_user)
    left outer join tpa_general_code gc on (gc.general_type_id=b.clm_status_type_id)
    left outer join tpa_general_code tg on (tg.general_type_id=a.clm_type_gen_type_id)
    left outer join tpa_general_code pt on (pt.general_type_id=a.process_type)
    left join shrtfll sh ON (sh.claim_seq_id = b.claim_seq_id)
    left join shortfall_details sd on (sh.shortfall_seq_id=sd.shortfall_seq_id)
    left outer join tpa_internal_remark_stat_code fr on (fr.status_code_id=b.status_code_id)
    left outer join pat_authorization_details pad on (pad.pat_auth_seq_id=b.pat_auth_seq_id)
    left outer join inv_staus inv on (inv.claim_seq_id=b.claim_seq_id)
    left outer join tpa_fraud_inv_details tfi on (tfi.inv_seq_id=inv.inv_seq_id)
    left outer join app.tpa_fasttract_disc_details fa on (fa.hosp_seq_id=c.hosp_seq_id  AND 
     FA.DISC_MODE=''FAST'' AND FA.STATUS=''ACT'' AND b.CLM_RECEIVED_DATE  between fa.START_DATE and fa.end_date + 1 )
    left outer join tpa_enr_policy_group epg on(epg.policy_group_seq_id = g.policy_group_seq_id)
    left outer join tpa_group_registration reg on(reg.group_reg_seq_id = epg.group_reg_seq_id)';
     
     IF v_invoice_number IS NOT NULL THEN
       v_where := v_where  ||' AND upper(trim(replace(b.invoice_number, '' '',''''))) like :v_invoice_number';
       i := i+1;
       bind_tab(i) := '%'||UPPER(trim(replace(v_invoice_number, ' ','')))||'%';
     END IF;
    
    IF v_batch_no IS NOT NULL THEN
      v_where := v_where  ||' AND a.batch_no = :v_batch_no';
       i := i+1;
       bind_tab(i) := (v_batch_no);
    END IF;

    IF v_policy_number IS NOT NULL THEN
      v_where := v_where  ||' AND e.policy_number = :v_policy_number';
       i := i+1;
       bind_tab(i) := UPPER(v_policy_number);
    END IF;

    IF v_claim_number IS NOT NULL THEN
      v_where := v_where  ||' AND b.claim_number = :v_claim_number';
      i := i+1;
      bind_tab(i) := UPPER(v_claim_number);
    END IF;
    
    IF v_claim_type IS NOT NULL THEN
      v_where := v_where  ||' AND a.clm_type_gen_type_id = :v_claim_type';
      i := i+1;
      bind_tab(i) := UPPER(v_claim_type);
    END IF;

    IF v_clm_received_date IS NOT NULL THEN
      v_where := v_where  ||' AND a.received_date LIKE :v_clm_received_date';
      i := i+1;
      bind_tab(i) := v_clm_received_date||'%';
    END IF;
    
    IF v_settlement_number IS NOT NULL THEN
      v_where := v_where  ||' AND b.settlement_number = :v_settlement_number';
      i := i+1;
      bind_tab(i) := UPPER(v_settlement_number);
    END IF;
  
         
    IF v_tpa_enrollment_id IS NOT NULL THEN
      v_where := v_where  ||' AND g.tpa_enrollment_id = :v_tpa_enrollment_id';
       i := i+1;
       bind_tab(i) := UPPER(v_tpa_enrollment_id);
    END IF;
    
   IF v_mem_name IS NOT NULL THEN
      v_where := v_where  ||' AND g.mem_name = :v_mem_name';
       i := i+1;
       bind_tab(i) := UPPER(v_mem_name);
   END IF;
   
   IF v_clm_status_type_id IS NOT NULL THEN
      v_where := v_where  ||' AND b.clm_status_type_id = :v_clm_status_type_id';
       i := i+1;
       bind_tab(i) := UPPER(v_clm_status_type_id);
   END IF;
   
    IF v_provider_id IS NOT NULL THEN
      v_where := v_where  || ' AND d.hosp_licenc_numb = :v_provider_id ';
       i := i+1;
       bind_tab(i) := UPPER(v_provider_id);
    END IF;
    IF v_ins_seq_id IS NOT NULL THEN
      v_where := v_where  || ' AND b.ins_seq_id = :v_ins_seq_id ';
       i := i+1;
       bind_tab(i) := v_ins_seq_id;
   END IF; 
   
   IF v_clm_mode IS NOT NULL THEN
      v_where := v_where  || ' AND a.source_type_id = :v_clm_mode ';
       i := i+1;
       bind_tab(i) := v_clm_mode;
   END IF; 
   
   IF v_global_mem_id IS NOT NULL THEN
      v_where := v_where  || ' AND g.global_net_member_id = :v_global_mem_id ';
       i := i+1;
       bind_tab(i) := v_global_mem_id;
   END IF; 
   
   IF v_process_type IS NOT NULL THEN
      v_where := v_where  || ' AND NVL(b.process_type,''RGL'') = :v_process_type ';
       i := i+1;
       bind_tab(i) := v_process_type;
   END IF;
   
   IF v_event_no IS NOT NULL THEN
      v_where := v_where  ||' AND trim(b.event_no) = :v_event_number';
      i := i+1;
      bind_tab(i) := UPPER(v_event_no);
    END IF;
    
    IF v_clm_status_type_id = 'REQ' AND v_srtfll_status_type IN ('OPN', 'RES') THEN
      v_where := v_where  || ' AND (sd.srtfll_status_general_type_id) = :v_srtfll_sts_type ';
      i := i+1;
      bind_tab(i) := v_srtfll_status_type;
    END IF;
    
   IF v_assign_user = 'SLF' THEN
      v_where := v_where  ||' AND au.assigned_to_user  = :v_added_by ';
       i := i+1;
       bind_tab(i) := v_added_by;
    ELSIF v_assign_user = 'OTH' THEN
      
	  IF v_other_user IS NULL THEN
     v_where := v_where  ||' AND au.assigned_to_user  != :v_added_by ';
       i := i+1;
       bind_tab(i) := v_added_by;
    ELSE   
       v_where := v_where  ||' AND f.contact_name  = :v_other_user ';
     i := i+1;
       bind_tab(i) := v_other_user;
    END IF; 
	  
	  
    ELSIF v_assign_user = 'UAS' THEN
      v_where := v_where  ||' AND au.assigned_to_user IS NULL ';
    END IF;
    
    IF v_other_user IS NOT NULL THEN
     v_where := v_where  ||' AND f.contact_name  = :v_other_user ';
     i := i+1;
       bind_tab(i) := v_other_user;
    END IF;
    
    IF v_common_file_num IS NOT NULL THEN
      v_where := v_where  ||' AND b.common_file_number  = :v_common_file_num ';
       i := i+1;
       bind_tab(i) := v_common_file_num;
    
    END IF;   
   
   IF v_internal_remark_stat IS NOT NULL THEN 
      IF UPPER(v_internal_remark_stat)='NON'  THEN
         v_where := v_where  ||' and b.status_code_id IS NULL';
         i:=i+1;
         ELSE 
         v_where := v_where  ||' and upper(b.status_code_id) = :v_internal_remark_stat /*and NVL(b.suspect_veri_check,''N'') = ''N''*/  ';
         i:=i+1;
         bind_tab(i) := UPPER(trim(v_internal_remark_stat)); 
    END IF;
    END IF;
    
    IF v_partner_seq_id IS NOT NULL THEN
     v_where := v_where  ||' AND b.ptnr_seq_id  = :v_partner_seq_id ';
     i := i+1;
       bind_tab(i) := v_partner_seq_id;
    END IF;
    
    IF v_benifit_type IS NOT NULL THEN
     v_where := v_where  ||' AND b.benifit_type  = :v_benifit_type ';
     i := i+1;
       bind_tab(i) := v_benifit_type;
    END IF;
    
    IF v_req_amt_oper IS NOT NULL THEN
       IF v_req_amount IS NOT NULL THEN
         v_where := v_where  ||' AND b.requested_amount  '|| v_req_amt_oper ||' :v_req_amount ';
         i := i+1;
           bind_tab(i) := v_req_amount;
       END IF;
    END IF;
    
    IF v_linked_pre_no IS NOT NULL THEN
     v_where := v_where  ||' AND pad.pre_auth_number = :v_linked_pre_no ';
     i := i+1;
       bind_tab(i) := v_linked_pre_no;
    END IF;
    ---------------- CR0218(Search by QatarID) -----------------------
    IF v_qatar_id IS NOT NULL THEN
      v_where := v_where  ||' AND g.emirate_id = :v_qatar_id';
       i := i+1;
       bind_tab(i) := UPPER(v_qatar_id);
    END IF;
    ------------------------------------------------------------------
    --===============CR0247====================================
    IF v_inp_status IS NOT NULL THEN
      IF v_inp_status = 'FRH' THEN
         v_inp_status1 := '0';
         v_where := v_where  ||' AND NVL(B.PARENT_CLAIM_SEQ_ID, 0) = 0 AND NVL(SD.CLAIM_SEQ_ID, 0) = :v_inp_status ';
      ELSIF v_inp_status = 'ENH' THEN
         v_inp_status1 := '0';
         v_where := v_where  ||' AND NVL(B.PARENT_CLAIM_SEQ_ID, 0) != :v_inp_status ';
      ELSIF v_inp_status = 'RES' THEN
         v_inp_status1 := 'RES';
         v_where := v_where  ||' AND B.CLM_STATUS_TYPE_ID = ''INP'' AND SD.SRTFLL_STATUS_GENERAL_TYPE_ID = :v_inp_status ';
      END IF;
      i := i+1;
      bind_tab(i) := UPPER(v_inp_status1);
    END IF;
    
    IF v_priority_flag IS NOT NULL THEN
     IF v_priority_flag ='OPC' THEN    --- Only priority corporate claims 
     v_where  := v_where ||' AND NVL(reg.priority_corporate_yn,''N'')=''Y'' ';
     END IF;
     
     IF v_priority_flag ='NPC' THEN    --- No priority corporate claims
     v_where  := v_where ||' AND NVL(reg.priority_corporate_yn,''N'')=''N'' ';
     END IF;
    END IF;
    --=========================================================
    ----- Added in CFD Cr
    IF v_risk_level IS NOT NULL THEN
      v_where := v_where  ||' AND b.risk_level = :v_risk_level';
       i := i+1;
       bind_tab(i) := v_risk_level;
    END IF;
    IF v_inv_status IS NOT NULL THEN
      v_where := v_where  ||' AND tfi.inv_status = :v_inv_status';
       i := i+1;
       bind_tab(i) := v_inv_status;
    END IF;
    ------------------------------------------------------
    IF v_audit_status IS NOT NULL THEN
      v_where := v_where  ||' AND NVL(B.AUDIT_STATUS, ''NCH'') = :audit_status ';
      i := i+1;
      bind_tab(i) := v_audit_status;
    END IF;
    
    IF v_where IS NOT NULL THEN
      v_where   := ' WHERE '|| SUBSTR(v_where,5);
      v_sql_str := v_sql_str ||v_where;
    END IF;
    
      -- Added In Fast Track cr

    IF v_fast_disc IS NOT NULL THEN
      IF v_fast_disc='DISC' THEN
        v_sql_str:='SELECT * FROM ('|| v_sql_str || ') WHERE NVL(Fast_Track,''N'')=''Y'''; 
      ELSIF v_fast_disc='PRVA' THEN
        IF v_pr_from IS NOT NULL AND v_pr_to IS NOT NULL THEN
          v_sql_str:='SELECT * FROM ('|| v_sql_str || ') WHERE  nvl(claim_age,0) between '||v_pr_from|| 'and '||v_pr_to ;
        ELSIF v_pr_from IS NOT NULL AND v_pr_to IS NULL THEN
          v_sql_str:='SELECT * FROM ('|| v_sql_str || ') WHERE  nvl(claim_age,0)  >= '||v_pr_from|| '';
        ELSIF  v_pr_from IS NULL AND v_pr_to IS NOT NULL THEN
          v_sql_str:=' SELECT * FROM ('|| v_sql_str || ') WHERE  nvl(claim_age,0) <= '||v_pr_to ||'';
        END IF;
      END IF;
    END IF;

    v_sql_str := 'SELECT * FROM
        (SELECT A.*,DENSE_RANK() OVER (ORDER BY '||v_sort_var||' '||v_sort_order||',ROWNUM)
        Q FROM (' ||v_sql_str|| ') A ) WHERE  Q>= :v_start_num AND Q<= :v_end_num ';


    IF bind_tab.FIRST IS NOT NULL THEN
       CASE bind_tab.COUNT
         WHEN 1  THEN OPEN result_set FOR v_sql_str USING bind_tab(1), v_start_num , v_end_num ;
         WHEN 2  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2), v_start_num , v_end_num ;
         WHEN 3  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) , v_start_num , v_end_num ;
         WHEN 4  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) , v_start_num , v_end_num ;
         WHEN 5  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5), v_start_num , v_end_num ;
         WHEN 6  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6), v_start_num , v_end_num ;
         WHEN 7  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6),bind_tab(7), v_start_num , v_end_num ;
         WHEN 8  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6),bind_tab(7),bind_tab(8), v_start_num , v_end_num ;
         WHEN 9  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6),bind_tab(7),bind_tab(8),bind_tab(9), v_start_num , v_end_num ;
         WHEN 10 THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6),bind_tab(7),bind_tab(8),bind_tab(9),bind_tab(10), v_start_num , v_end_num ;
         WHEN 11 THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6),bind_tab(7),bind_tab(8),bind_tab(9),bind_tab(10),bind_tab(11), v_start_num , v_end_num ;
         WHEN 12 THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6),bind_tab(7),bind_tab(8),bind_tab(9),bind_tab(10),bind_tab(11),bind_tab(12), v_start_num , v_end_num ;
         WHEN 13 THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6),bind_tab(7),bind_tab(8),bind_tab(9),bind_tab(10),bind_tab(11),bind_tab(12), bind_tab(13), v_start_num , v_end_num ;
         WHEN 14 THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6),bind_tab(7),bind_tab(8),bind_tab(9),bind_tab(10),bind_tab(11),bind_tab(12), bind_tab(13),bind_tab(14), v_start_num , v_end_num ;
         WHEN 15 THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6),bind_tab(7),bind_tab(8),bind_tab(9),bind_tab(10),bind_tab(11),bind_tab(12), bind_tab(13),bind_tab(14),bind_tab(15), v_start_num , v_end_num ;
         WHEN 16 THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6),bind_tab(7),bind_tab(8),bind_tab(9),bind_tab(10),bind_tab(11),bind_tab(12), bind_tab(13),bind_tab(14),bind_tab(15), bind_tab(16), v_start_num , v_end_num ;
         WHEN 17 THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6),bind_tab(7),bind_tab(8),bind_tab(9),bind_tab(10),bind_tab(11),bind_tab(12), bind_tab(13),bind_tab(14),bind_tab(15), bind_tab(16), bind_tab(17), v_start_num , v_end_num ;
         WHEN 18 THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6),bind_tab(7),bind_tab(8),bind_tab(9),bind_tab(10),bind_tab(11),bind_tab(12), bind_tab(13),bind_tab(14),bind_tab(15), bind_tab(16), bind_tab(17), bind_tab(18), v_start_num , v_end_num ;
         WHEN 19 THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6),bind_tab(7),bind_tab(8),bind_tab(9),bind_tab(10),bind_tab(11),bind_tab(12), bind_tab(13),bind_tab(14),bind_tab(15), bind_tab(16), bind_tab(17), bind_tab(18), bind_tab(19), v_start_num , v_end_num ;
         WHEN 20 THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6),bind_tab(7),bind_tab(8),bind_tab(9),bind_tab(10),bind_tab(11),bind_tab(12), bind_tab(13),bind_tab(14),bind_tab(15), bind_tab(16), bind_tab(17), bind_tab(18), bind_tab(19), bind_tab(20), v_start_num , v_end_num ;
	       WHEN 21 THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6),bind_tab(7),bind_tab(8),bind_tab(9),bind_tab(10),bind_tab(11),bind_tab(12), bind_tab(13),bind_tab(14),bind_tab(15), bind_tab(16), bind_tab(17), bind_tab(18), bind_tab(19), bind_tab(20), bind_tab(21), v_start_num , v_end_num ; 
         WHEN 22 THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6),bind_tab(7),bind_tab(8),bind_tab(9),bind_tab(10),bind_tab(11),bind_tab(12), bind_tab(13),bind_tab(14),bind_tab(15), bind_tab(16), bind_tab(17), bind_tab(18), bind_tab(19), bind_tab(20), bind_tab(21), bind_tab(22), v_start_num , v_end_num ; 
END CASE;
     ELSE
       OPEN result_set FOR v_sql_str USING v_start_num , v_end_num ;
     END IF;

  END select_claims_list;
--===============================================================================
PROCEDURE save_claims_payment (
    v_claim_seq_id                       IN  TPA_CLAIMS_PAYMENT.claim_seq_id%TYPE,
    v_status                             IN  TPA_CLAIMS_PAYMENT.claim_payment_status%TYPE,
    v_enrol_type_id                      IN  TPA_ENR_POLICY.enrol_type_id%TYPE,
    v_policy_seq_id                      IN  TPA_ENR_POLICY.Policy_Seq_Id%TYPE,
    v_member_seq_id                      IN  TPA_ENR_POLICY_MEMBER.Member_Seq_Id%TYPE,
    v_claim_general_type_id              IN  clm_authorization_details.claim_type%TYPE,
    v_added_by                           IN  TPA_CLAIMS_PAYMENT.added_by%TYPE
  )
  IS

  -- If the Claim is NHCP
   CURSOR cur_get_nhcp ( v_claim_seq_id NUMBER ) IS
    SELECT CASE WHEN nvl(a.issue_cheques_type_id,'HOS') = 'HOS' THEN b.hosp_name ELSE a.management_name END AS payee_name,
         P.address_1,
         P.address_2,
         P.address_3,
         d.state_name,
         e.city_description,
         f.country_name AS country,
         P.pin_code,
         b.off_phone_no_1,
         b.office_fax_no fax_no,
         a.issue_cheques_type_id AS issue_cheques_type_id ,
         b.hosp_seq_id,
         b.hosp_seq_id as payee_seq_id
    FROM tpa_hosp_account_details a JOIN tpa_hosp_info b ON (a.hosp_seq_id = b.hosp_seq_id)
         JOIN clm_hospital_details c ON (b.hosp_seq_id = c.hosp_seq_id)
         JOIN tpa_hosp_address P ON (b.hosp_seq_id = p.hosp_seq_id)
         LEFT OUTER JOIN tpa_state_code d ON ( p.state_type_id = d.state_type_id )
         LEFT OUTER JOIN tpa_city_code e ON ( p.city_type_id = e.city_type_id )
         LEFT OUTER JOIN tpa_country_code f ON (p.country_id = f.country_id)
         WHERE c.claim_seq_id = v_claim_seq_id;

 --opdforhs
   CURSOR cur_get_hcu ( v_claim_seq_id NUMBER ) IS
    SELECT CASE WHEN a.hcu_pay_to_general_type = 'TPA' THEN a.tpa_name  END AS payee_name,
         P.address_1,
         P.address_2,
         P.address_3,
         d.state_name,
         e.city_description,
         f.country_name AS country,
         P.pin_code,
         i.off_phone_no_1,
         i.office_fax_no_1 fax_no,
         a.hcu_pay_to_general_type AS issue_cheques_type_id ,
         null as hosp_seq_id,
         null as payee_seq_id
    FROM tpa_enr_policy a JOIN clm_authorization_details b ON (a.policy_seq_id = b.policy_seq_id)
         join clm_batch_upload_details c on (c.clm_batch_seq_id=b.clm_batch_seq_id)
         JOIN tpa_office_info i ON (i.tpa_office_seq_id=c.tpa_office_aeq_id)
         JOIN tpa_address P ON (i.tpa_office_seq_id = p.tpa_office_seq_id)
         LEFT OUTER JOIN tpa_state_code d ON ( p.state_type_id = d.state_type_id )
         LEFT OUTER JOIN tpa_city_code e ON ( p.city_type_id = e.city_type_id )
         LEFT OUTER JOIN tpa_country_code f ON (p.country_id = f.country_id)
         WHERE b.claim_seq_id = v_claim_seq_id;

  -- If the Claim is MR Individual, Individual as Group, Non-Corporate
  CURSOR cur_get_mr_individual IS
    SELECT b.insured_name payee_name, P.address_1, P.address_2,  P.address_3, F.state_name, P.city_type_id city_description,
         g.country_name AS country,   P.pin_code,   P.off_phone_no_1,   P.fax_no ,
         NULL AS issue_cheques_type_id , NULL AS hosp_seq_id, b.policy_group_seq_id as payee_seq_id
         FROM tpa_enr_policy a JOIN tpa_enr_policy_group b ON (a.policy_seq_id = b.policy_seq_id)
         JOIN tpa_enr_policy_member c ON (b.policy_group_seq_id = c.policy_group_seq_id)
         JOIN tpa_enr_mem_address P ON (b.enr_address_seq_id = p.enr_address_seq_id)
         LEFT OUTER JOIN tpa_state_code F ON ( P.state_type_id = f.state_type_id )
         LEFT OUTER JOIN tpa_country_code g ON ( p.country_id = g.country_id )
         WHERE a.policy_seq_id = v_policy_seq_id  AND c.member_seq_id  = v_member_seq_id ;

  CURSOR cur_get_mr_location IS
    SELECT CASE WHEN g.group_reg_seq_id IS NULL THEN B.group_name ELSE r.group_name END AS payee_name ,
         CASE WHEN g.group_reg_seq_id IS NULL THEN P.address_1 ELSE m.address_1 END AS address_1 ,
         CASE WHEN g.group_reg_seq_id IS NULL THEN P.address_2 ELSE m.address_2 END AS address_2 ,
         CASE WHEN g.group_reg_seq_id IS NULL THEN P.address_3 ELSE m.address_3 END AS address_3 ,
         CASE WHEN g.group_reg_seq_id IS NULL THEN F.state_name ELSE n.state_name END AS state_name ,
         CASE WHEN g.group_reg_seq_id IS NULL THEN C.city_description ELSE o.city_description END AS city_description ,
         CASE WHEN g.group_reg_seq_id IS NULL THEN aa.country_name ELSE bb.country_name END AS country ,
         CASE WHEN g.group_reg_seq_id IS NULL THEN P.pin_code ELSE m.pin_code END AS pin_code ,
         CASE WHEN g.group_reg_seq_id IS NULL THEN B.office_number ELSE r.office_number END AS off_phone_no_1 ,
         NULL fax_no,
         NULL AS issue_cheques_type_id , NULL AS hosp_seq_id,
         r.group_reg_seq_id as payee_seq_id
         FROM tpa_enr_policy a JOIN tpa_enr_policy_group g ON (a.policy_seq_id = g.policy_seq_id)
         JOIN tpa_enr_policy_member H ON (g.policy_group_seq_id = h.policy_group_seq_id)
         LEFT OUTER JOIN tpa_group_registration r ON ( g.group_reg_seq_id = r.group_reg_seq_id )
         LEFT OUTER JOIN tpa_group_registration b ON ( a.group_reg_seq_id = b.group_reg_seq_id )
         LEFT OUTER JOIN tpa_address P ON (b.group_reg_seq_id = p.group_reg_seq_id)
         LEFT OUTER JOIN tpa_state_code F ON ( P.state_type_id = f.state_type_id )
         LEFT OUTER JOIN tpa_city_code C ON ( C.city_type_id = P.city_type_id )
         LEFT OUTER JOIN tpa_country_code aa ON ( p.country_id = aa.country_id )
         LEFT OUTER JOIN tpa_address m ON (r.group_reg_seq_id = m.group_reg_seq_id)
         LEFT OUTER JOIN tpa_state_code n ON ( m.state_type_id = n.state_type_id )
         LEFT OUTER JOIN tpa_city_code o ON ( m.city_type_id = o.city_type_id )
         LEFT OUTER JOIN tpa_country_code bb ON ( m.country_id = bb.country_id )
         WHERE h.member_seq_id = v_member_seq_id;


   -- If the claim is from the corporate
    CURSOR cur_get_policy_cheque IS
     SELECT a.tpa_cheque_issued_general_type
      FROM tpa_enr_policy a  WHERE  a.policy_seq_id = v_policy_seq_id  ;

     -- Cheque to be issued in the name of the corporate
     CURSOR cur_get_corporate_info IS
         SELECT B.group_name AS payee_name,  P.address_1,  P.address_2,   P.address_3,  F.state_name,  C.city_description,
           aa.country_name AS country,     P.pin_code,   B.office_number off_phone_no_1,  NULL fax_no,
           NULL AS issue_cheques_type_id , NULL AS hosp_seq_id,b.group_reg_seq_id AS payee_seq_id
           FROM tpa_enr_policy a JOIN tpa_group_registration b ON (a.group_reg_seq_id = b.group_reg_seq_id)
           JOIN tpa_address P ON (b.group_reg_seq_id = p.group_reg_seq_id)
           LEFT OUTER JOIN tpa_state_code F ON ( P.state_type_id = f.state_type_id )
           LEFT OUTER JOIN tpa_city_code C ON ( C.city_type_id = P.city_type_id )
           LEFT OUTER JOIN tpa_country_code aa ON ( p.country_id = aa.country_id )
           WHERE a.policy_seq_id  = v_policy_seq_id ;


       rule_rec_payee  cur_get_nhcp%ROWTYPE;
       
     CURSOR cur_paymnt_to_id IS
       SELECT ca.pymnt_to_type_id,ptnr_seq_id
       FROM clm_authorization_details ca
       WHERE ca.claim_seq_id = v_claim_seq_id;
       
   CURSOR cur_get_ptnr_dtl ( v_claim_seq_id NUMBER ) IS
    SELECT p.partner_name AS payee_name,
         Pa.address_1,
         Pa.address_2,
         Pa.address_3,
         d.state_name,
         e.city_description,
         f.country_name AS country,
         pa.pin_code,
         p.off_phone_no_1,
         p.office_fax_no fax_no,
         NULL AS issue_cheques_type_id ,
         NULL as hosp_seq_id,
         ca.ptnr_seq_id as payee_seq_id
     FROM clm_authorization_details ca 
     JOIN tpa_partner_info p ON (ca.ptnr_seq_id = p.ptnr_seq_id)
     JOIN tpa_partner_account_details a ON (p.ptnr_seq_id=a.ptnr_seq_id)
     JOIN tpa_partner_address pa ON (p.ptnr_seq_id = pa.ptnr_seq_id)
     LEFT OUTER JOIN tpa_state_code d ON ( pa.state_type_id = d.state_type_id )
     LEFT OUTER JOIN tpa_city_code e ON ( pa.city_type_id = e.city_type_id )
     LEFT OUTER JOIN tpa_country_code f ON (pa.country_id = f.country_id)
     WHERE ca.claim_seq_id = v_claim_seq_id;  
     
     Cursor Embassy_Details is
     SELECT ba.claimfrom_gentype_id,emb.embassy_name,cad.embassy_seq_id 
            from clm_batch_upload_details ba
            join clm_authorization_details cad on (ba.clm_batch_seq_id=cad.clm_batch_seq_id)
            LEFT OUTER JOIN tpa_enr_embassy_registration emb on (emb.embassy_seq_id=cad.embassy_seq_id)
            WHERE cad.claim_seq_id=v_claim_seq_id;
     
     rec_get_ptnr_dtl          cur_get_ptnr_dtl%ROWTYPE;
       
       v_cheque_issue          VARCHAR2(3);
       v_pymnt_to_type_id      VARCHAR2(10);
       v_ptnr_seq_id           NUMBER(20);
       v_embassy_name          VARCHAR2(500);
       v_claim_from            VARCHAR2(100);
       v_embassy_seq_id        NUMBER(30);

  BEGIN

      OPEN  cur_paymnt_to_id;
      FETCH cur_paymnt_to_id INTO v_pymnt_to_type_id,v_ptnr_seq_id;
      CLOSE cur_paymnt_to_id;
    
      IF  v_claim_general_type_id = 'CNH'  THEN  -- NETWORK CLAIM
        IF NVL(v_pymnt_to_type_id,'NA') = 'PTN' THEN
          OPEN   cur_get_ptnr_dtl ( v_claim_seq_id );
          FETCH  cur_get_ptnr_dtl INTO rule_rec_payee ;
          CLOSE  cur_get_ptnr_dtl;
          IF rule_rec_payee.payee_name IS NULL OR rule_rec_payee.address_1 IS NULL THEN
            raise_application_error(-20407, 'Please enter partner address before completing the Claim ');
          END IF;
        ELSE
          
          OPEN   cur_get_nhcp ( v_claim_seq_id );
          FETCH  cur_get_nhcp INTO rule_rec_payee ;
          CLOSE  cur_get_nhcp;
          IF rule_rec_payee.payee_name IS NULL OR rule_rec_payee.address_1 IS NULL THEN
            raise_application_error(-20176, 'Please correct hospital address before completing the Claim ');
          END IF;
         END IF;
       ELSIF  v_claim_general_type_id = 'CTM'  THEN -- MEMBER CLAIM
          IF v_enrol_type_id IN  ('IND','ING','NCR') THEN
            OPEN  cur_get_mr_individual ;
            FETCH cur_get_mr_individual INTO rule_rec_payee ;
            CLOSE cur_get_mr_individual;

            IF rule_rec_payee.payee_name IS NULL /*OR rule_rec_payee.address_1 IS NULL*/ THEN
              raise_application_error(-20177, 'Please correct payee address before completing the Claim ');
            END IF;

          ELSIF  v_enrol_type_id = 'COR' THEN
          
          OPEN Embassy_Details;
            FETCH Embassy_Details INTO v_claim_from,v_embassy_name,v_embassy_seq_id;
              CLOSE Embassy_Details;  
          
          
            OPEN cur_get_policy_cheque;
            FETCH cur_get_policy_cheque INTO v_cheque_issue;
            CLOSE cur_get_policy_cheque;

            -- issue cheques to Corporate
            IF v_cheque_issue = 'IQC' THEN
              OPEN cur_get_corporate_info;
              FETCH  cur_get_corporate_info INTO rule_rec_payee ;
              CLOSE cur_get_corporate_info;
              IF rule_rec_payee.payee_name IS NULL /*OR rule_rec_payee.address_1 IS NULL*/ THEN
                raise_application_error(-20178, 'Please correct corporate address before completing the Claim ');
              END IF;
            ELSIF  v_cheque_issue = 'IQI'  THEN -- issue cheques to Individual
              OPEN cur_get_mr_individual ;
              FETCH  cur_get_mr_individual INTO rule_rec_payee ;
              CLOSE cur_get_mr_individual;
              IF rule_rec_payee.payee_name IS NULL /*OR rule_rec_payee.address_1 IS NULL*/ THEN
                raise_application_error(-20177, 'Please correct payee address before completing the Claim ');
              END IF;
            ELSIF  v_cheque_issue = 'IQL'  THEN -- issue cheques to Individual
              OPEN cur_get_mr_location ;
              FETCH  cur_get_mr_location INTO rule_rec_payee ;
              CLOSE cur_get_mr_location;
              IF rule_rec_payee.payee_name IS NULL /*OR rule_rec_payee.address_1 IS NULL*/ THEN
                raise_application_error(-20177, 'Please correct payee address before completing the Claim ');
              END IF;
            END IF;
          END IF;
       END IF;

      INSERT INTO tpa_claims_payment (
        payment_seq_id,
        claim_settlement_no,
        claim_payment_status,
        claim_amount,
        claim_type,
        claim_aprv_date,
        approved_amount,
        ins_seq_id,
        deleted_yn,
        policy_seq_id,
        member_seq_id,
        group_reg_seq_id,
        address1,
        address2,
        address3,
        state ,
        city ,
        pincode ,
        country,
        email_id ,
        phone1,
        phone2,
        home_phone,
        mob_num,
        fax_no,
        enrol_type_id,
        claim_seq_id,
        claim_file_number,
        added_by,
        added_date,
        payee_name ,
        tpa_cheque_issued_general_type,
        hosp_seq_id,
        tpa_nhcp_cheques_issued_to,
        ptnr_seq_id ,
        payee_seq_id )
    SELECT
      tpa_claims_payment_seq.NEXTVAL ,
      a.settlement_number ,
      v_status,
      a.requested_amount,--a.tot_disc_gross_amount-nvl(a.tot_patient_share_amount,0),
      a.claim_type,
      a.decision_date,
      a.final_app_amount,
      a.ins_seq_id,
      'N',
      a.policy_seq_id,
      a.member_seq_id,
      CASE WHEN v_cheque_issue = 'IQL' THEN NVL(X.group_reg_seq_id,ep.group_reg_seq_id) ELSE x.group_reg_seq_id END,
      rule_rec_payee.Address_1,
      rule_rec_PAYEE.Address_2,
      rule_rec_payee.Address_3,
      rule_rec_payee.State_Name,
      rule_rec_payee.CITY_DESCRIPTION,
      rule_rec_payee.Pin_Code,
      rule_rec_payee.country,
      NULL email_id ,
      rule_rec_payee.Off_Phone_No_1,
      NULL off_phone_no_2,
      NULL res_phone_no,
      NULL mobile_no,
      rule_rec_payee.Fax_No,
      EP.enrol_type_id ,
      a.claim_seq_id,
      a.claim_file_number,
      v_added_by,
      SYSDATE,
     -- rule_rec_payee.Payee_Name,
     CASE WHEN NVL(v_claim_from,'INSU')!='EMBA' THEN ttk_util_pkg.fn_encrypt(rule_rec_payee.Payee_Name) ELSE ttk_util_pkg.fn_encrypt(v_embassy_name) end, --//ED
      v_cheque_issue,
      rule_rec_payee.hosp_seq_id ,
      rule_rec_payee.issue_cheques_type_id,
      v_ptnr_seq_id,
      CASE WHEN NVL(v_claim_from,'INSU')!='EMBA' THEN (rule_rec_payee.payee_seq_id) ELSE (v_embassy_seq_id) end --//ED,
      FROM clm_authorization_details A 
      JOIN clm_batch_upload_details b ON ( a.clm_batch_seq_id = b.clm_batch_seq_id )
      JOIN tpa_enr_policy_member D ON ( a.member_seq_id = d.member_seq_id )
      JOIN tpa_enr_policy_group X ON (d.policy_group_seq_id = X.policy_group_seq_id )
      JOIN TPA_ENR_POLICY EP ON (EP.POLICY_SEQ_ID=A.POLICY_SEQ_ID)
      LEFT OUTER JOIN tpa_general_code K ON ( a.claim_type = K.general_type_id )
   WHERE a.claim_seq_id = v_claim_seq_id ;

  END save_claims_payment;
--===============================================================================
PROCEDURE select_clm_shortfall_list (
    v_shortfall_id                       IN  shortfall_details.shortfall_id%type,
    v_invoice_number                     IN  clm_authorization_details.invoice_number%type,
    v_batch_no                           IN  clm_batch_upload_details.batch_no%type,
    v_policy_number                      IN  tpa_enr_policy.policy_number%type,
    v_claim_number                       IN  clm_authorization_details.claim_number%type,
    v_claim_type                         IN  clm_batch_upload_details.clm_type_gen_type_id%type,
    v_settlement_number                  IN  clm_authorization_details.settlement_number%TYPE,
    v_tpa_enrollment_id                  IN  clm_authorization_details.tpa_enrollment_id%type,
    v_status_type_id                     IN  shortfall_details.srtfll_status_general_type_id%type,
    v_sort_var                           IN  VARCHAR2,
    v_sort_order                         IN  VARCHAR2 ,
    v_start_num                          IN  NUMBER ,
    v_end_num                            IN  NUMBER ,
    v_added_by                           IN  NUMBER,
    v_qatar_id                           IN  tpa_enr_policy_member.emirate_id%type,
    result_set                           OUT SYS_REFCURSOR
  )
  IS

    v_sql_str                            VARCHAR2(10000) ;
    TYPE bind_tab_type IS TABLE OF VARCHAR2(250) INDEX BY BINARY_INTEGER ;
    bind_tab                             bind_tab_type;
    i                                    NUMBER(2) := 0;
    v_where                              VARCHAR2(2000);
    
  BEGIN
    v_sql_str :=
     'select a.batch_no,
            b.claim_number,
            b.invoice_number,
            b.claim_seq_id,
            a.clm_batch_seq_id,
            b.tpa_enrollment_id,
            a.clm_type_gen_type_id,
            b.mem_name,
            nvl(c.hosp_name,d.hosp_name) as hosp_name,
            f.contact_name,
            sd.srtfll_received_date as received_date,
            gc.description as status,
            tg.description as claim_type,
            sd.shortfall_seq_id,
            sd.shortfall_id,
            e.policy_number,
            b.emirate_id qatar_id
            
    from clm_batch_upload_details a left outer join clm_authorization_details b on (a.clm_batch_seq_id=b.clm_batch_seq_id)
    join shortfall_details sd on (sd.claim_seq_id=b.claim_seq_id)
    left outer join tpa_enr_policy e on (e.policy_seq_id=b.policy_seq_id)
    left outer join clm_hospital_details c on (c.claim_seq_id=b.claim_seq_id)
    left outer join tpa_hosp_info d on (d.hosp_seq_id=c.hosp_seq_id)
    left outer join tpa_user_contacts f on (f.contact_seq_id=sd.added_by)
    left outer join tpa_general_code gc on (gc.general_type_id=sd.srtfll_status_general_type_id)
    left outer join tpa_general_code tg on (tg.general_type_id=a.clm_type_gen_type_id)';

     IF v_shortfall_id IS NOT NULL THEN
      v_where := v_where  ||' AND sd.shortfall_id = :v_shortfall_id';
       i := i+1;
       bind_tab(i) := UPPER(v_shortfall_id);
     END IF;
     
     IF v_invoice_number IS NOT NULL THEN
      v_where := v_where  ||' AND b.invoice_number = :v_invoice_number';
       i := i+1;
       bind_tab(i) := UPPER(v_invoice_number);
     END IF;
    
    IF v_batch_no IS NOT NULL THEN
      v_where := v_where  ||' AND a.batch_no = :v_batch_no';
       i := i+1;
       bind_tab(i) := UPPER(v_batch_no);
    END IF;

    IF v_policy_number IS NOT NULL THEN
      v_where := v_where  ||' AND e.policy_number = :v_policy_number';
       i := i+1;
       bind_tab(i) := UPPER(v_policy_number);
    END IF;

    IF v_claim_number IS NOT NULL THEN
      v_where := v_where  ||' AND b.claim_number = :v_claim_number';
      i := i+1;
      bind_tab(i) := UPPER(v_claim_number);
    END IF;
    
    IF v_claim_type IS NOT NULL THEN
      v_where := v_where  ||' AND b.claim_type = :v_claim_type';
      i := i+1;
      bind_tab(i) := UPPER(v_claim_type);
    END IF;

    
    IF v_settlement_number IS NOT NULL THEN
      v_where := v_where  ||' AND b.settlement_number = :v_settlement_number';
      i := i+1;
      bind_tab(i) := UPPER(v_settlement_number);
    END IF;
  
         
    IF v_tpa_enrollment_id IS NOT NULL THEN
      v_where := v_where  ||' AND b.tpa_enrollment_id = :v_tpa_enrollment_id';
       i := i+1;
       bind_tab(i) := UPPER(v_tpa_enrollment_id);
    END IF;
  
    IF v_status_type_id IS NOT NULL THEN
      v_where := v_where  ||' AND b.clm_status_type_id = :v_clm_status_type_id';
       i := i+1;
       bind_tab(i) := UPPER(v_status_type_id);
    END IF;
    ------------------- CR0218(Search by QatarID)------------------
    IF v_qatar_id IS NOT NULL THEN
      v_where := v_where  ||' AND b.emirate_id = :v_qatar_id';
       i := i+1;
       bind_tab(i) := UPPER(v_qatar_id);
    END IF;
    -------------------------------------------------------------- 
    IF v_where IS NOT NULL THEN
      v_where   := ' WHERE '|| SUBSTR(v_where,5);
      v_sql_str := v_sql_str ||v_where;
    END IF;


    v_sql_str := 'SELECT * FROM
        (SELECT A.*,DENSE_RANK() OVER (ORDER BY '||v_sort_var||' '||v_sort_order||',ROWNUM)
        Q FROM (' ||v_sql_str|| ') A ) WHERE  Q>= :v_start_num AND Q<= :v_end_num ';

    IF bind_tab.FIRST IS NOT NULL THEN
       CASE bind_tab.COUNT
         WHEN 1  THEN OPEN result_set FOR v_sql_str USING bind_tab(1), v_start_num , v_end_num ;
         WHEN 2  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2), v_start_num , v_end_num ;
         WHEN 3  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) , v_start_num , v_end_num ;
         WHEN 4  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) , v_start_num , v_end_num ;
         WHEN 5  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5), v_start_num , v_end_num ;
         WHEN 6  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6), v_start_num , v_end_num ;
         WHEN 7  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6),bind_tab(7), v_start_num , v_end_num ;
         WHEN 8  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6),bind_tab(7),bind_tab(8), v_start_num , v_end_num ;
         WHEN 9  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6),bind_tab(7),bind_tab(8),bind_tab(9), v_start_num , v_end_num ;
         WHEN 10  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6),bind_tab(7),bind_tab(8),bind_tab(9), bind_tab(10), v_start_num , v_end_num ;
         WHEN 11  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6),bind_tab(7),bind_tab(8),bind_tab(9), bind_tab(10), bind_tab(11), v_start_num , v_end_num ;
       END CASE;
     ELSE
       OPEN result_set FOR v_sql_str USING v_start_num , v_end_num ;
     END IF;

  END select_clm_shortfall_list;
--===============================================================================
PROCEDURE select_preauth_list (
    v_member_seq_id                  IN  pat_authorization_details.member_seq_id%TYPE,
    v_auth_number                    IN  pat_authorization_details.auth_number%TYPE,
    v_hosp_name                      IN  tpa_hosp_info.hosp_name%TYPE,
    v_start_date                     IN  VARCHAR2,
    v_end_date                       IN  VARCHAR2,
    v_tpa_office_seq_id              IN  tpa_office_info.tpa_office_seq_id%TYPE,
    v_sort_var                       IN  VARCHAR2 ,
    v_sort_order                     IN  VARCHAR2,
    v_start_num                      IN  NUMBER,
    v_end_num                        IN  NUMBER,
    v_added_by                       IN  NUMBER,
    result_set                       OUT SYS_REFCURSOR,
    v_claim_seq_id                   IN NUMBER := NULL
  )
  IS
    TYPE bind_tab_type IS TABLE OF VARCHAR2(250) INDEX BY BINARY_INTEGER ;
    bind_tab                         bind_tab_type;
    i                                NUMBER(2) := 0;
    v_sql_str                        VARCHAR2(4000);
    v_where                          VARCHAR2(2000);
    v_from_date                      DATE := to_date(v_start_date,'dd/mm/yyyy');
    v_to_date                        DATE := to_date(v_end_date,'dd/mm/yyyy');
  
  CURSOR cur_clm_dtl IS
    SELECT NVL(b.process_type,'RGL') AS process_type,NVL(ca.network_yn,'N') AS network_yn
    FROM clm_authorization_details ca
    JOIN clm_batch_upload_details b ON (ca.clm_batch_seq_id=b.clm_batch_seq_id)
    WHERE ca.claim_seq_id = v_claim_seq_id;
    
  rec_clm_dtl       cur_clm_dtl%ROWTYPE;  
  BEGIN
    
  OPEN  cur_clm_dtl;
  FETCH cur_clm_dtl INTO rec_clm_dtl;
  CLOSE cur_clm_dtl;

IF rec_clm_dtl.process_type = 'DBL' THEN
    v_sql_str :=
       'SELECT
        a.pat_auth_seq_id,
        A.auth_number,
        A.Mem_Name,
        a.hospitalization_date,
        B.hosp_seq_id,
        NVL(B.hosp_name,nd.provider_name) as hosp_name,
        i.address_1,
        i.address_2,
        i.address_3,
        J.state_name,
        K.city_description,
        i.pin_code,
        b.off_phone_no_1,
        b.off_phone_no_2,
        ttk_util_pkg.fn_decrypt(b.primary_email_id) as primary_email_id, 
        a.pat_received_date,
        a.tot_approved_amount ,
        n.empanel_description ,
        O.country_name,
        b.empanel_number,
        a.req_amt_currency_type,
        a.req_amt_currency_type as pat_inc_curr,
        a.converted_amount_currency_type as PAT_REQ_CURR,
        a.converted_final_approved_amt as pat_inc_amnt
       FROM pat_authorization_details A 
      LEFT OUTER JOIN tpa_hosp_info B ON (a.hosp_seq_id = b.hosp_seq_id )
      LEFT OUTER JOIN tpa_enr_policy_member D ON ( a.member_seq_id = d.member_seq_id )
      LEFT OUTER JOIN tpa_hosp_address I ON ( b.hosp_seq_id = i.hosp_seq_id )
      LEFT OUTER JOIN tpa_state_code J ON (I.state_type_id = J.state_type_id)
      LEFT OUTER JOIN tpa_city_code K ON (I.city_type_id = K.city_type_id )
      LEFT OUTER JOIN tpa_ins_info L ON (a.ins_seq_id = l.ins_seq_id )
      LEFT OUTER JOIN tpa_country_code O ON (I.country_id = O.country_id)
      LEFT OUTER JOIN tpa_hosp_empanel_status P ON (b.hosp_seq_id = P.hosp_seq_id)
      LEFT OUTER JOIN tpa_hosp_empanel_status_code N ON (P.empanel_status_type_id = n.empanel_status_type_id )
      LEFT OUTER JOIN pat_non_network_details nd ON (nd.pat_auth_seq_id=a.pat_auth_seq_id)';
 
 ELSE --------- Regular
   v_sql_str :=
       'SELECT
        a.pat_auth_seq_id,
        A.auth_number,
        A.Mem_Name,
        a.hospitalization_date,
        B.hosp_seq_id,
        B.hosp_name ,
        i.address_1,
        i.address_2,
        i.address_3,
        J.state_name,
        K.city_description,
        i.pin_code,
        b.off_phone_no_1,
        b.off_phone_no_2,
        ttk_util_pkg.fn_decrypt(b.primary_email_id) as primary_email_id, 
        a.pat_received_date,
        a.tot_approved_amount ,
        n.empanel_description ,
        O.country_name,
        b.empanel_number,
        a.req_amt_currency_type,
         a.req_amt_currency_type as pat_inc_curr,
        a.converted_amount_currency_type as PAT_REQ_CURR,
        a.converted_final_approved_amt as pat_inc_amnt
       FROM pat_authorization_details A join tpa_hosp_info B ON (a.hosp_seq_id = b.hosp_seq_id AND a.pat_status_type_id = ''APR'' AND a.pat_enhanced_yn = ''N'' AND a.completed_yn = ''Y'')
      LEFT OUTER JOIN tpa_enr_policy_member D ON ( a.member_seq_id = d.member_seq_id )
      LEFT OUTER JOIN tpa_hosp_address I ON ( b.hosp_seq_id = i.hosp_seq_id )
      LEFT OUTER JOIN tpa_state_code J ON (I.state_type_id = J.state_type_id)
      LEFT OUTER JOIN tpa_city_code K ON (I.city_type_id = K.city_type_id )
      LEFT OUTER JOIN tpa_ins_info L ON (a.ins_seq_id = l.ins_seq_id )
      LEFT OUTER JOIN tpa_country_code O ON (I.country_id = O.country_id)
      LEFT OUTER JOIN tpa_hosp_empanel_status P ON (b.hosp_seq_id = P.hosp_seq_id)
      LEFT OUTER JOIN tpa_hosp_empanel_status_code N ON (P.empanel_status_type_id = n.empanel_status_type_id )';
 
 END IF;
 
    IF v_member_seq_id IS NOT NULL THEN
      v_where := v_where ||' AND A.member_seq_id  = :v_member_seq_id';
      i := i+1;
      bind_tab(i) := v_member_seq_id;
    END IF;
    IF v_auth_number IS NOT NULL THEN
      v_where := v_where ||' AND A.auth_number  = :v_auth_number';
      i := i+1;
      bind_tab(i) := upper(v_auth_number);
    END IF;
    IF v_hosp_name IS NOT NULL AND rec_clm_dtl.process_type != 'DBL' THEN
      v_where := v_where ||' AND B.hosp_name  LIKE :v_hosp_name';
      i := i+1;
      bind_tab(i) := UPPER(v_hosp_name)||'%';
    END IF;
     IF v_from_date IS NOT NULL THEN
      v_where := v_where || ' AND A.hospitalization_date >= :v_from_date ';
      i := i+1;
      bind_tab(i) := v_from_date;
    END IF;
    IF v_to_date IS NOT NULL THEN
      v_where := v_where ||' AND TRUNC(A.hospitalization_date) <= :v_to_date ';
      i := i+1;
      bind_tab(i) := v_to_date;
    END IF;
    
    IF rec_clm_dtl.process_type = 'DBL' /*AND rec_clm_dtl.network_yn = 'N' */THEN
      v_where := v_where ||' AND a.pat_status_type_id = ''APR'' AND a.pat_enhanced_yn = ''N'' AND a.completed_yn = ''Y''';
    END IF;
    
    v_where := v_where || ' AND ( A.claim_seq_id IS NULL and 0 = ( SELECT COUNT(1) FROM clm_authorization_details CGD 
                      WHERE cgd.pat_auth_seq_id = a.pat_auth_seq_id
                       AND ( CGD.completed_yn = ''N'' OR cgd.clm_status_type_id NOT IN (''REJ'',''PCO'')))
    OR A.claim_seq_id = :v_claim_seq_id ) ';
    v_where := ' WHERE '|| SUBSTR(v_where,5);
    v_sql_str := v_sql_str ||v_where;

    v_sql_str := 'SELECT * FROM
          (SELECT A.*, DENSE_RANK() OVER (ORDER BY '||v_sort_var||' '||v_sort_order||',ROWNUM)
          Q FROM (' ||v_sql_str|| ') A ) WHERE Q>= :v_start_num  AND Q<= :v_end_num ';
    IF bind_tab.FIRST IS NOT NULL THEN
       CASE bind_tab.COUNT
         WHEN 1 THEN OPEN result_set FOR v_sql_str USING bind_tab(1),v_claim_seq_id,v_start_num, v_end_num ;
         WHEN 2 THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),v_claim_seq_id, v_start_num , v_end_num ;
         WHEN 3 THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,v_claim_seq_id, v_start_num , v_end_num ;
         WHEN 4 THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,v_claim_seq_id,v_start_num ,v_end_num ;
         WHEN 5 THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5) ,v_claim_seq_id,v_start_num , v_end_num ;
       END CASE;
    ELSE
      OPEN result_set FOR v_sql_str USING v_start_num , v_end_num ;
    END IF;

  END select_preauth_list;
--===============================================================================
PROCEDURE delete_batch_claims(v_seq_id             IN clm_authorization_details.claim_seq_id%TYPE,
                              v_batch_seq_id       IN clm_batch_upload_details.clm_batch_seq_id%type,
                              v_rows_processed     OUT NUMBER) IS



cursor clm_delete_cur is 
select * from app.clm_batch_upload_details bd where bd.clm_batch_seq_id=v_batch_seq_id;
clm_rec           clm_delete_cur%ROWTYPE;       

BEGIN
  
   open clm_delete_cur;
   fetch clm_delete_cur into clm_rec;
   close clm_delete_cur;
  
    IF NVL(clm_rec.batch_status_type,'INP')='COMP' AND NVL(clm_rec.batch_override,'N')='Y' THEN
       RAISE_APPLICATION_ERROR(-20390,'You cannot perform this action through a completed Batch.');
    ELSE
      delete from app.assign_users a where a.claim_seq_id=v_seq_id;
      delete from app.pat_activity_details a where a.claim_seq_id=v_seq_id;
      delete from app.diagnosys_details d where d.claim_seq_id=v_seq_id;
      delete from clm_hospital_details hd where hd.claim_seq_id=v_seq_id;
      DELETE FROM clm_authorization_details ad 
      WHERE ad.claim_seq_id = v_seq_id and ad.clm_batch_seq_id=v_batch_seq_id;
   END IF;
  
 v_rows_processed := SQL%ROWCOUNT;
 
 COMMIT;
END delete_batch_claims;
--===============================================================================
PROCEDURE copy_previous_claim (
    v_claim_seq_id                    IN OUT clm_authorization_details.claim_seq_id%TYPE,
    v_parent_claim_seq_id             IN OUT clm_authorization_details.parent_claim_seq_id%TYPE,
    v_claim_batch_seq_id              IN clm_batch_upload_details.clm_batch_seq_id%TYPE ,
    v_requested_amount                IN clm_authorization_details.requested_amount%TYPE,
    v_added_by                        IN NUMBER
  )
  IS
    CURSOR prev_amd_cur IS SELECT COUNT(1)
      FROM clm_authorization_details A JOIN clm_batch_upload_details B ON ( a.clm_batch_seq_id = b.clm_batch_seq_id )
      WHERE a.parent_claim_seq_id = v_parent_claim_seq_id
      AND a.claim_seq_id != NVL( v_claim_seq_id , 0 )
      AND (a.clm_status_type_id = 'INP' OR  a.clm_status_type_id = 'REQ' OR a.completed_yn = 'N' );

    CURSOR claim_cur IS 
     SELECT
      A.Event_No,A.Delvry_Mod_Type, A.clm_batch_seq_id ,a.parent_claim_seq_id, A.claim_number ,A.claim_file_number , A.Pat_Auth_Seq_Id ,
      A.auth_number ,A.Source_Type_Id ,a.ins_seq_id,a.remarks as pat_remarks,  
      A.Date_Of_Hospitalization,A.Date_Of_Discharge,
      A.Settlement_Number  , a.pat_approved_amount, n.gender_general_type_id, 
      a.member_seq_id ,    a.tpa_enrollment_id ,a.policy_seq_id,f.enrol_type_id,
      a.mem_age ,a.mem_name ,n.emirate_id,d.clinician_name,  
      b.clm_type_gen_type_id ,D.hosp_seq_id ,D.Provider_Id ,       D.hosp_name ,        D.address_1
      ,D.address_2 ,       D.address_3 ,d.city_type_id,d.state_type_id,d.country_type_id,D.state_name ,       D.city_name ,       D.pin_code ,       D.off_phone_no_1,
      D.off_phone_no_2 ,D.office_fax_no,    D.remarks , 
      a.clm_status_type_id ,a.invoice_number,a.clinician_id,a.requested_amount,
      a.network_yn,a.benifit_type,a.GRAVIDA,
      a.PARA, a.LIVE,a.ABORTION,a.PRESENTING_COMPLAINTS,a.MEDICAL_OPINION_REMARKS,
      n.mem_general_type_id,a.encounter_type_id,a.encounter_start_type,a.encounter_end_type,
      a.encounter_facility_id,a.payer_id,a.ava_sum_insured,a.currency_type,
      a.system_of_medicine_type_id,a.accident_related_type_id,a.priority_general_type_id,
      a.REQ_AMT_CURRENCY_TYPE,a.CONVERTED_AMOUNT,a.CONVERTED_AMOUNT_CURRENCY_TYPE,a.CONVERSION_RATE,NVL(A.PROCESS_TYPE,'RGL') AS PROCESS_TYPE,a.oth_tpa_ref_no,
      a.common_file_number,b.submission_type_id,a.treatment_type,a.dur_ailment,a.duration_flag,
      a.lmp_date,a.conception_type
      ,a.embassy_seq_id,
      NVL(A.MAT_COMPLCTON_YN,'N') AS MAT_COMPLCTON_YN
      FROM clm_authorization_details A JOIN clm_batch_upload_details B ON (A.CLM_BATCH_SEQ_ID = B.CLM_BATCH_SEQ_ID )
      LEFT OUTER JOIN clm_hospital_details D ON ( a.claim_seq_id = d.claim_seq_id )
      LEFT OUTER JOIN tpa_enr_policy f ON ( a.policy_seq_id = f.policy_seq_id )
      LEFT OUTER JOIN pat_authorization_details k ON (a.pat_auth_seq_id = k.pat_auth_seq_id AND k.pat_enhanced_yn = 'N')
      LEFT OUTER JOIN tpa_enr_policy_member n ON (a.member_seq_id = n.member_seq_id)
      LEFT OUTER JOIN tpa_enr_policy_group o ON (n.policy_group_seq_id = o.policy_group_seq_id)
      WHERE a.claim_seq_id = v_parent_claim_seq_id AND a.completed_yn = 'Y';

     CURSOR activity_cur IS 
       SELECT DISTINCT b.activity_dtl_seq_id,B.CLAIM_SEQ_ID
       FROM clm_authorization_details a JOIN pat_activity_details b ON ( a.claim_seq_id = b.claim_seq_id )
       WHERE b.claim_seq_id = v_parent_claim_seq_id AND ( b.disc_gross_amount-nvl(b.patient_share_amount,0) - nvl(b.allowed_amount,0) >0 );
     claim_rec                     claim_cur%ROWTYPE;

    CURSOR balance_cur IS 
      SELECT B.balance_seq_id,b.policy_group_seq_id,a.mem_general_type_id 
      FROM tpa_enr_policy_member a JOIN tpa_enr_balance b ON (a.policy_group_seq_id = b.policy_group_seq_id)
      WHERE a.member_seq_id = claim_rec.member_seq_id  AND ( a.mem_general_type_id = 'PNF' AND b.member_seq_id = claim_rec.member_seq_id OR
                                         a.mem_general_type_id != 'PNF' AND b.member_seq_id IS NULL );

   CURSOR prev_appr_cur IS  SELECT COUNT(1) FROM
     ( SELECT a.claim_seq_id, a.parent_claim_seq_id,a.clm_status_type_id
      FROM clm_authorization_details a START WITH a.claim_seq_id = v_parent_claim_seq_id CONNECT BY a.claim_seq_id = PRIOR a.parent_claim_seq_id ) aa
      WHERE aa.clm_status_type_id = 'APR'  ;
      
   CURSOR Current_Batch_Details IS
   SELECT cad.requested_amount,ba.claimfrom_gentype_id,ba.received_date,cad.re_submission_remarks
       FROM clm_batch_upload_details  ba 
       JOIN clm_authorization_details cad on (ba.clm_batch_seq_id=cad.clm_batch_seq_id)
       where ba.clm_batch_seq_id=v_claim_batch_seq_id AND cad.claim_seq_id=v_claim_seq_id;
       
   CURSOR Parent_Batch_Details IS
   SELECT ba.claimfrom_gentype_id
       FROM clm_batch_upload_details  ba 
       JOIN clm_authorization_details cad on (ba.clm_batch_seq_id=cad.clm_batch_seq_id)
       where cad.claim_seq_id=v_parent_claim_seq_id; 
   
   CURSOR Dental_iotn_Config IS
   select * 
          from ORTHODONTIC_DETAILS_TAB o 
          where o.Source_Seq_Id=v_parent_claim_seq_id and o.source_from='CLM';       
       
    balance_rec                   balance_cur%ROWTYPE;

    v_prev_parent_seq_id          clm_general_details.parent_claim_seq_id%TYPE;
    v_copy_flag                   CHAR(1) := 'N';
    v_rows_processed              NUMBER(2);
    v_clm_hosp_assoc_seq_id       clm_hospital_association.clm_hosp_assoc_seq_id%TYPE;
    v_add_hosp_dtl_seq_id         clm_hospital_additional_dtl.add_hosp_dtl_seq_id%TYPE;
    v_ava_sum_insured             NUMBER(12,2);
    v_ava_cum_bonus               NUMBER(12,2);
    v_pat_act_dtl_seq_id          pat_activity_details.activity_dtl_seq_id%TYPE;
    v_ctr                         NUMBER(2);
    v_re_open_type                clm_general_details.re_open_type%TYPE := 'AMC';
    v_reqd_buff_amt               NUMBER(16,2);
    v_prev_appr_count             PLS_INTEGER := 0;
    v_flag                        VARCHAR2(3);
    v_balance_buffer              NUMBER(16,2);
    v_balance_med_buffer          NUMBER(16,2);
    v_balance_crit_buffer         NUMBER(16,2);
    v_balance_crit_corp_buffer    NUMBER(16,2);
    v_balance_crit_med_buffer     NUMBER(16,2);
    v_buffer_deleted_yn           VARCHAR2(1) := 'N';
    v_hospital_details_verify     VARCHAR2(10);
    v_claim_number                varchar2(60);
    v_act_count                   number;
    V_ALERT                       VARCHAR2(100);
    v_req_amt                     NUMBER(30,2);
    v_current_claim_from          VARCHAR2(30);
    v_parent_claim_form           VARCHAR2(30);
    v_rec_date                    date;
    Dental_iotn                   Dental_iotn_Config%rowtype;
    v_resub_remarks               VARCHAR2(1000);
  BEGIN
   
    OPEN prev_amd_cur ;
    FETCH prev_amd_cur INTO v_ctr;
    CLOSE prev_amd_cur ;
    
    
     OPEN Current_Batch_Details;
      FETCH Current_Batch_Details INTO v_req_amt,v_current_claim_from,v_rec_date,v_resub_remarks;
        CLOSE Current_Batch_Details;
        
     OPEN Parent_Batch_Details;
      FETCH Parent_Batch_Details INTO v_parent_claim_form;
        CLOSE Parent_Batch_Details;
        
     IF v_current_claim_from !=v_parent_claim_form  THEN
           raise_application_error (-20161,'Re Submission can not submit for diffrent claim form type');
     END IF;
      
    IF v_ctr > 0 THEN
      raise_application_error (-20160, 'New Ammendment cannot be entered before completing Existing Ammendment ');
    END IF;
    
   

    IF NVL(v_claim_seq_id,0) = 0 THEN
      v_copy_flag := 'Y';
    ELSE
      SELECT a.parent_claim_seq_id ,c.clm_hosp_assoc_seq_id 
         INTO v_prev_parent_seq_id ,  v_clm_hosp_assoc_seq_id 
         FROM clm_authorization_details a JOIN clm_batch_upload_details b ON ( a.clm_batch_seq_id = b.clm_batch_seq_id )
         LEFT OUTER JOIN clm_hospital_details c ON ( a.claim_seq_id = c.claim_seq_id )
         WHERE a.claim_seq_id = v_claim_seq_id ;
    END IF;
    IF v_claim_seq_id IS NOT NULL THEN
      SELECT COUNT(1) into v_act_count from app.pat_activity_details ad where ad.claim_seq_id = v_claim_seq_id;
      if v_act_count=0 then
        v_copy_flag:='Y';
      end if;
    end if;
    OPEN claim_cur;
      FETCH claim_cur INTO claim_rec;
      CLOSE claim_cur;
   
   IF v_copy_flag = 'Y' THEN
      -- LOCKING Parent Claim
      TTK_UTIL_PKG.reset_id_flag(v_parent_claim_seq_id||'-CLM','Y');

      IF claim_rec.claim_number IS NULL THEN
        raise_application_error(-20187,' Cannot create Ammendment , Parent Claim is set back to confirmation state. ');
      END IF;


      UPDATE clm_batch_upload_details A SET
        a.clm_type_gen_type_id = claim_rec.clm_type_gen_type_id
        WHERE a.clm_batch_seq_id = v_claim_batch_seq_id ;

    /*  IF claim_rec.clm_status_type_id = 'REJ' THEN
        v_re_open_type := 'RJC';  -- RE-OPEN REJECTED
      ELSIF claim_rec.clm_status_type_id = 'PCO' THEN
        v_re_open_type := 'CDD';  -- RE-OPEN CLOSED
      ELSE
        v_re_open_type := 'AMC';  -- RE-OPEN CLOSED
      END IF;*/

         save_clm_details (v_claim_seq_id,
                           v_claim_batch_seq_id,
                           claim_rec.pat_auth_seq_id,
                           v_parent_claim_seq_id,
                           v_claim_number,--claim_number
                           null,--claim_filenumber
                           null,--V_SETTLEMENT_NUMBER 
                           v_rec_date, --CLM_RECEIVED_DATE 
                           claim_rec.source_type_id,
                           claim_rec.date_of_hospitalization,
                           claim_rec.date_of_discharge,
                           claim_rec.clm_type_gen_type_id,
                           null,--CLAIM_SUB_TYPE
                           claim_rec.member_seq_id,
                           claim_rec.tpa_enrollment_id,
                           claim_rec.mem_name,
                           claim_rec.mem_age,
                           claim_rec.ins_seq_id,
                           claim_rec.policy_seq_id,
                           claim_rec.enrol_type_id,
                           claim_rec.emirate_id,
                           claim_rec.encounter_type_id,
                           claim_rec.encounter_start_type,
                           claim_rec.encounter_end_type,
                           claim_rec.encounter_facility_id,
                           claim_rec.payer_id,
                           claim_rec.ava_sum_insured,
                           claim_rec.currency_type,
                           'INP' ,---------V_CLM_STATUS_TYPE_ID
                           v_resub_remarks,
                           claim_rec.invoice_number,
                           v_req_amt,--claim_rec.requested_amount,
                           claim_rec.clinician_id,
                           claim_rec.system_of_medicine_type_id,
                           claim_rec.accident_related_type_id,
                           claim_rec.priority_general_type_id,
                           claim_rec.network_yn,
                           claim_rec.benifit_type,
                           claim_rec.GRAVIDA,
                           claim_rec.PARA,
                           claim_rec.LIVE,
                           claim_rec.ABORTION,
                           claim_rec.PRESENTING_COMPLAINTS,
                           claim_rec.MEDICAL_OPINION_REMARKS,
                           claim_rec.HOSP_SEQ_ID,
                           claim_rec.HOSP_NAME,
                           claim_rec.ADDRESS_1,
                           claim_rec.CITY_TYPE_ID,
                           claim_rec.STATE_TYPE_ID,
                           claim_rec.PIN_CODE,
                           claim_rec.OFF_PHONE_NO_1,
                           claim_rec.office_fax_no,
                           claim_rec.PROVIDER_ID,
                           claim_rec.COUNTRY_TYPE_ID,
                           claim_rec.clinician_name,
                           v_added_by,
                           null,
                           NULL,
                           null,			
                           claim_rec.conception_type,
                           claim_rec.lmp_date,
                           claim_rec.REQ_AMT_CURRENCY_TYPE,
                           claim_rec.CONVERTED_AMOUNT,
                           claim_rec.CONVERTED_AMOUNT_CURRENCY_TYPE,
                           claim_rec.CONVERSION_RATE,	
                           claim_rec.Process_Type,	
                           claim_rec.oth_tpa_ref_no,
                           claim_rec.treatment_type,
		                       claim_rec.delvry_mod_type,
                           claim_rec.event_no,
                           claim_rec.embassy_seq_id,
                           NULL,
                           NULL,
                           NULL,
						   claim_rec.MAT_COMPLCTON_YN,
                           v_rows_processed
                           );

         v_ctr := 0;
          --For Copying Dental iotn Configuration 
         IF claim_rec.benifit_type='DNTL' THEN
            
         OPEN Dental_iotn_Config;
           FETCH Dental_iotn_Config INTO Dental_iotn;
             CLOSE Dental_iotn_Config;
             
            INSERT INTO ORTHODONTIC_DETAILS_TAB
                        (ORTHO_SEQ_ID,
                        SOURCE_SEQ_ID,
                        SOURCE_FROM,
                        DENTO_CLASS_I,
                        DENTO_CLASS_II,
                        DENTO_CLASS_II_TEXT,
                        DENTO_CLASS_III,
                        SKELE_CLASS_I,
                        SKELE_CLASS_II,
                        SKELE_CLASS_III,
                        OVERJET_MM,
                        REV_OVERJET_MM,
                        REV_OVERJET_YN,
                        CROSSBITE_ANT,
                        CROSSBITE_POST,
                        CROSSBITE_BETW,
                        OPENBIT_ANT,
                        OPENBIT_POST,
                        OPENBIT_LATE,
                        CONT_POINT_DISP,
                        OVERBIT_DEEP,
                        OVERBIT_PATA,
                        OVERBIT_GING,
                        HYPO_QUAD1,
                        HYPO_QUAD2,
                        HYPO_QUAD3,
                        HYPO_QUAD4,
                        OTHERS_IMPEDED,
                        OTHERS_IMPACT,
                        OTHERS_SUBMERG,
                        OTHERS_SUPERNUM,
                        OTHERS_RETAINE,
                        OTHERS_ECTOPIC,
                        OTHERS_CRANIO,
                        AC_MARKS,
                        CROSSBITE_ANT_MM,
                        CROSSBITE_PRST_MM,
                        CROSSBITE_BETW_MM,
                        CONT_POINT_DISP_MM,
                        DENTO_CLASS_III_TEXT,
                        IOTN_REMARK) VALUES 
                        (
                        null,
                        v_claim_seq_id,
                        Dental_iotn.SOURCE_FROM,
                        Dental_iotn.DENTO_CLASS_I,
                        Dental_iotn.DENTO_CLASS_II,
                        Dental_iotn.DENTO_CLASS_II_TEXT,
                        Dental_iotn.DENTO_CLASS_III,
                        Dental_iotn.SKELE_CLASS_I,
                        Dental_iotn.SKELE_CLASS_II,
                        Dental_iotn.SKELE_CLASS_III,
                        Dental_iotn.OVERJET_MM,
                        Dental_iotn.REV_OVERJET_MM,
                        Dental_iotn.REV_OVERJET_YN,
                        Dental_iotn.CROSSBITE_ANT,
                        Dental_iotn.CROSSBITE_POST,
                        Dental_iotn.CROSSBITE_BETW,
                        Dental_iotn.OPENBIT_ANT,
                        Dental_iotn.OPENBIT_POST,
                        Dental_iotn.OPENBIT_LATE,
                        Dental_iotn.CONT_POINT_DISP,
                        Dental_iotn.OVERBIT_DEEP,
                        Dental_iotn.OVERBIT_PATA,
                        Dental_iotn.OVERBIT_GING,
                        Dental_iotn.HYPO_QUAD1,
                        Dental_iotn.HYPO_QUAD2,
                        Dental_iotn.HYPO_QUAD3,
                        Dental_iotn.HYPO_QUAD4,
                        Dental_iotn.OTHERS_IMPEDED,
                        Dental_iotn.OTHERS_IMPACT,
                        Dental_iotn.OTHERS_SUBMERG,
                        Dental_iotn.OTHERS_SUPERNUM,
                        Dental_iotn.OTHERS_RETAINE,
                        Dental_iotn.OTHERS_ECTOPIC,
                        Dental_iotn.OTHERS_CRANIO,
                        Dental_iotn.AC_MARKS,
                        Dental_iotn.CROSSBITE_ANT_MM,
                        Dental_iotn.CROSSBITE_PRST_MM,
                        Dental_iotn.CROSSBITE_BETW_MM,
                        Dental_iotn.CONT_POINT_DISP_MM,
                        Dental_iotn.DENTO_CLASS_III_TEXT,
                        Dental_iotn.Iotn_Remark
                        );
            
           
         END IF;
         
         --Copying PED Details
         
          UPDATE CLM_AUTHORIZATION_DETAILS D
            SET D.DUR_AILMENT=claim_rec.dur_ailment,
                D.DURATION_FLAG=claim_rec.duration_flag
          WHERE D.CLAIM_SEQ_ID=v_claim_seq_id;     
         --Copying diagnosis details
          FOR I IN (SELECT * FROM diagnosys_details dd
                      WHERE dd.claim_seq_id = v_parent_claim_seq_id) loop 
            INSERT INTO diagnosys_details(diag_seq_id,claim_seq_id,icd_code_seq_id,diagnosys_code,primary_ailment_yn,added_by,added_date)
            VALUES (diagnosys_detail_seq.nextval,v_claim_seq_id,I.icd_code_seq_id,I.diagnosys_code,I.primary_ailment_yn,v_added_by,sysdate);
           
           END LOOP;
          
         --Copying activity details 
          FOR I IN (SELECT * FROM pat_activity_details d
                      WHERE d.claim_seq_id = v_parent_claim_seq_id 
                      AND ((nvl(d.disc_gross_amount,0))-nvl(d.approved_amount,0))>0)
          LOOP
          INSERT INTO pat_activity_details(activity_dtl_seq_id,claim_seq_id,Activity_Seq_Id,activity_id,s_no,start_date,activity_type,code,
                      unit_type,modifier,internal_code,package_id,bundle_id,quantity,gross_amount,discount_amount,disc_gross_amount,patient_share_amount,
                      copay_amount,co_ins_amount,deduct_amount,out_of_pocket_amount,net_amount,allowed_amount,approved_amount,allow_yn,denial_code,
                      remarks,added_by,added_date,denial_desc,approvd_quantity,unit_price,provider_net_amount,mem_service_desc,tooth_no,carry_for_yn )
          VALUES (pat_activity_detail_seq.nextval,v_claim_seq_id,i.activity_seq_id,i.activity_id,i.s_no,i.start_date,i.activity_type,i.code,i.unit_type,
                 i.modifier,i.internal_code,i.package_id,i.bundle_id,i.quantity,i.gross_amount,i.discount_amount,i.disc_gross_amount,i.patient_share_amount,i.copay_amount,
                 i.co_ins_amount,i.deduct_amount,i.out_of_pocket_amount,i.net_amount,i.allowed_amount,i.allowed_amount,i.allow_yn,i.denial_code,i.remarks,v_added_by,
                 SYSDATE,i.denial_desc,i.approvd_quantity,i.unit_price,i.provider_net_amount,i.mem_service_desc,i.tooth_no,'Y');
            
          update app.clm_authorization_details a
          set a.cal_act_yn='N'
          WHERE a.claim_seq_id=v_claim_seq_id;
          
          
           FOR J IN (SELECT * FROM app.pat_observation_details od 
               where od.activity_dtl_seq_id=i.activity_dtl_seq_id) loop
              INSERT INTO pat_observation_details(observation_seq_id,activity_dtl_seq_id,observation_type_id,observation_code_id,value,
                  obs_value_type_id,added_by,added_date,remarks )
           VALUES (pat_observation_detail_seq.Nextval,j.activity_dtl_seq_id,j.observation_type_id,j.observation_code_id,j.value,j.obs_value_type_id,
                  v_added_by,sysdate,j.remarks);
           END LOOP;   
        
         v_ctr := v_ctr + 1;
        END LOOP;

         
         /*FOR i IN activity_cur
         LOOP
           SELECT app.pat_activity_detail_seq.NEXTVAL
             INTO v_pat_act_dtl_seq_id FROM dual;

           INSERT INTO clm_bill_details ( clm_bill_dtl_seq_id , clm_bill_seq_id , description ,
              ward_type_id ,room_type_id , number_of_days , requested_amount , allow_yn , allowed_amount , rejected_amount ,
              remarks  , discount_percnt, apply_discount_yn, ward_max_amount ,HOSP_ROOM_SEQ_ID,  added_by ,added_date )

           SELECT clm_bill_dtl_seq.NEXTVAL, v_clm_bill_seq_id , description ,
              ward_type_id , room_type_id , number_of_days , CASE WHEN I.bill_included_yn = 'Y' AND NVL(rejected_amount,0) > 0 THEN rejected_amount ELSE requested_amount  END , NVL(allow_yn,'N') ,
              0, CASE WHEN I.bill_included_yn = 'Y' AND NVL(rejected_amount,0) > 0 THEN rejected_amount ELSE requested_amount  END ,
              remarks  , discount_percnt, apply_discount_yn, ward_max_amount ,HOSP_ROOM_SEQ_ID, v_added_by, SYSDATE FROM clm_bill_details
               WHERE clm_bill_seq_id = i.clm_bill_seq_id AND ( rejected_amount > 0 OR i.bill_included_yn = 'N' OR requested_amount - NVL(allowed_amount,0) > 0 );

           -- To reject ammendment for a claim which is not having any rejected amount.
           v_ctr := v_ctr + 1;
         END LOOP ;

         IF v_ctr = 0 THEN
           raise_application_error (-20161,'You cannot create an ammendment for this claim ');
         END IF;

        IF claim_rec.pat_auth_seq_id IS NOT NULL THEN
           UPDATE pat_authorization_details a SET
             a.claim_seq_id =
                 ( SELECT cc.claim_seq_id FROM clm_authorization_details cc
                                    WHERE cc.parent_claim_seq_id IS NULL
                                      START WITH cc.claim_seq_id = v_claim_seq_id
                                      CONNECT BY cc.claim_seq_id = PRIOR parent_claim_seq_id ),
             a.updated_by = v_added_by,
             a.updated_date = SYSDATE
             WHERE a.pat_auth_seq_id = claim_rec.pat_auth_seq_id AND
               a.claim_seq_id IS NULL;
        END IF;*/
      END IF;
  END copy_previous_claim;
--=================================================================================
PROCEDURE select_prev_claim (
    v_member_seq_id              IN  clm_authorization_details.member_seq_id%TYPE,
    v_claim_type                 IN VARCHAR2,
    v_hosp_lic_id                IN VARCHAR2,
    v_sub_cat                    IN VARCHAR2,
    v_payment_to                 IN VARCHAR2,
    v_result_set                 OUT SYS_REFCURSOR
  )
  IS
   v_sqlstr                      varchar2(4000);
   v_where                       varchar2(1000);
   I                             NUMBER:=0;
   dyn_var                       DBMS_UTILITY.uncl_array;
   v_hosp_seq_id                 NUMBER(30);
   
   CURSOR GET_HOSP_SEQ_ID IS
     SELECT I.HOSP_SEQ_ID FROM TPA_HOSP_INFO I 
     WHERE I.HOSP_LICENC_NUMB=v_hosp_lic_id;
   
  BEGIN
    


IF NVL(v_sub_cat,'RGL')='RGL' THEN
 

  IF v_hosp_lic_id IS NOT NULL THEN
  OPEN GET_HOSP_SEQ_ID;
    FETCH GET_HOSP_SEQ_ID INTO v_hosp_seq_id;
      CLOSE GET_HOSP_SEQ_ID;
  END IF;   

  IF v_hosp_seq_id is not null then 
       v_where :=v_where||' AND cah.hosp_seq_id =: v_hosp_seq_id';
       i:=i+1;
      dyn_var(i):=v_hosp_seq_id;
  END IF;
  
  
 v_sqlstr:='SELECT A.claim_seq_id,A.claim_number,A.requested_amt,A.appr_amt,A.Converted_Amount,A.Final_App_Amount
       FROM 
      (SELECT cad.claim_seq_id,cad.claim_number,sum(case when nvl(pad.provider_net_amount,0)!=0 And nvl(pad.disc_gross_amount,0)!=0 then
                   least (pad.provider_net_amount,pad.disc_gross_amount)
                   when nvl(pad.provider_net_amount,0)=0 And nvl(pad.disc_gross_amount,0)!=0 then 
                   pad.disc_gross_amount  end) as requested_amt,sum(pad.allowed_amount) as appr_amt,
                   cad.Converted_Amount,cad.Final_App_Amount
      from clm_authorization_details cad
           left outer join clm_hospital_details cah on (cad.claim_seq_id=cah.claim_seq_id)
           JOIN pat_activity_details pad on (pad.claim_seq_id=cad.claim_seq_id)
           where cad.claim_seq_id in(
              SELECT A.claim_seq_id FROM
                    (SELECT cad.claim_seq_id 
                              from clm_authorization_details cad
                              left outer join tpa_claims_payment pa on (cad.claim_seq_id = pa.claim_seq_id)
                              where cad.claim_type='''||v_claim_type||''' and ((cad.clm_status_type_id = ''APR'' AND pa.claim_payment_status NOT IN( ''PENDING'',''READY_TO_BANK''))or cad.clm_status_type_id = ''REJ'' )
                               AND cad.member_seq_id ='''|| v_member_seq_id||''') A
               MINUS
                     (SELECT cad.parent_claim_seq_id
                         from clm_authorization_details cad
                         where cad.parent_claim_seq_id in
                            ((SELECT c.claim_seq_id
                               from clm_authorization_details c
                               left outer join tpa_claims_payment p on (c.claim_seq_id = p.claim_seq_id)
                               where c.member_seq_id = '''||v_member_seq_id||''' 
                              AND c.claim_type='''||v_claim_type ||''' AND c.completed_yn = ''Y'' and ((c.clm_status_type_id = ''APR''  AND p.claim_payment_status NOT IN( ''PENDING'',''READY_TO_BANK'')) OR (c.clm_status_type_id = ''REJ''))
                              ))))'
                              ||case when v_where is not null then v_where end||'
                               group by cad.claim_seq_id,cad.claim_number,cad.Converted_Amount,cad.Final_App_Amount) A
                               where (A.Converted_Amount-A.Final_App_Amount)>0 OR (A.requested_amt-A.appr_amt)>0';
  



  IF dyn_var.FIRST IS NOT NULL THEN
    CASE dyn_var.COUNT WHEN 1 THEN  
     OPEN v_result_set FOR v_sqlstr USING dyn_var(1); END CASE;  
  ELSE 
      OPEN v_result_set FOR v_sqlstr;  
  END IF;
 
ELSIF nvl(v_sub_cat,'RGL')='DBL' THEN

  IF v_payment_to='PRV' THEN
    OPEN GET_HOSP_SEQ_ID;
    FETCH GET_HOSP_SEQ_ID INTO v_hosp_seq_id;
      CLOSE GET_HOSP_SEQ_ID;
  ELSIF v_payment_to='PTN' THEN    
      v_hosp_seq_id:=v_hosp_lic_id;
   END IF;
      
  IF v_hosp_seq_id is not null AND v_payment_to='PRV' then 
       v_where :=v_where||' AND cah.hosp_seq_id =: v_hosp_seq_id';
       i:=i+1;
      dyn_var(i):=v_hosp_seq_id;
  ELSIF v_hosp_seq_id is not null AND v_payment_to='PTN' then 
     v_where :=v_where||' AND cad.ptnr_seq_id =: v_hosp_seq_id';
       i:=i+1;
      dyn_var(i):=v_hosp_seq_id;
  END IF;
  
  v_sqlstr:='SELECT A.claim_seq_id,A.claim_number,A.requested_amt,A.appr_amt,A.Converted_Amount,A.Final_App_Amount
       FROM 
      (SELECT cad.claim_seq_id,cad.claim_number,sum(case when nvl(pad.provider_net_amount,0)!=0 And nvl(pad.disc_gross_amount,0)!=0 then
                   least (pad.provider_net_amount,pad.disc_gross_amount)
                   when nvl(pad.provider_net_amount,0)=0 And nvl(pad.disc_gross_amount,0)!=0 then 
                   pad.disc_gross_amount  end) as requested_amt,sum(pad.allowed_amount) as appr_amt,
                   cad.Converted_Amount,cad.Final_App_Amount
      from clm_authorization_details cad
           left outer join clm_hospital_details cah on (cad.claim_seq_id=cah.claim_seq_id)
           JOIN pat_activity_details pad on (pad.claim_seq_id=cad.claim_seq_id)
           where cad.claim_seq_id in(
              SELECT A.claim_seq_id FROM
                    (SELECT cad.claim_seq_id 
                              from clm_authorization_details cad
                              left outer join tpa_claims_payment pa on (cad.claim_seq_id = pa.claim_seq_id)
                              where cad.clm_status_type_id = ''APR'' 
                              and cad.claim_type='''||v_claim_type||''' and pa.claim_payment_status NOT IN( ''PENDING'',''READY_TO_BANK'')
                               AND cad.member_seq_id ='''|| v_member_seq_id||''') A
               MINUS
                     (SELECT cad.parent_claim_seq_id
                         from clm_authorization_details cad
                         where cad.parent_claim_seq_id in
                            ((SELECT c.claim_seq_id
                               from clm_authorization_details c
                               left outer join tpa_claims_payment p on (c.claim_seq_id = p.claim_seq_id)
                               where c.member_seq_id = '''||v_member_seq_id||'''and c.clm_status_type_id = ''APR''  
                              AND c.claim_type='''||v_claim_type ||''' AND c.completed_yn = ''Y'' and p.claim_payment_status NOT IN( ''PENDING'',''READY_TO_BANK'')))))'
                              ||case when v_where is not null then v_where end||'
                               group by cad.claim_seq_id,cad.claim_number,cad.Converted_Amount,cad.Final_App_Amount) A
                               where (A.Converted_Amount-A.Final_App_Amount)>0 OR (A.requested_amt-A.appr_amt)>0';
  
   IF dyn_var.FIRST IS NOT NULL THEN
    CASE dyn_var.COUNT WHEN 1 THEN  
     OPEN v_result_set FOR v_sqlstr USING dyn_var(1); END CASE;  
  ELSE 
      OPEN v_result_set FOR v_sqlstr;  
  END IF;
 END IF; 
    /*
 WITH claims AS
       ( SELECT zz.batch_no, X.claim_seq_id , zz.clm_type_gen_type_id
             FROM clm_authorization_details X 
             JOIN tpa_claims_payment pay ON (X.Claim_Seq_Id=pay.claim_seq_id)
             LEFT OUTER JOIN clm_authorization_details z ON ( x.claim_seq_id = z.parent_claim_seq_id )
             LEFT OUTER JOIN clm_batch_upload_details zz ON (x.clm_batch_seq_id = zz.clm_batch_seq_id)
             WHERE x.member_seq_id =v_member_seq_id  
             AND ( x.clm_status_type_id = 'APR' AND pay.claim_payment_status!='PENDING')  AND x.completed_yn = 'Y'
              AND ( (x.tot_disc_gross_amount-nvl(x.tot_patient_share_amount,0)) - NVL(x.tot_approved_amount,0) ) > 0  \*AND ( z.claim_seq_id IS NULL OR zz.batch_status_type = 'INP')*\)

      SELECT aa.*
              FROM (
             SELECT DISTINCT claim_seq_id,pat_auth_seq_id, claim_number
             FROM clm_authorization_details a WHERE claim_seq_id IN
             (SELECT MAX(claim_seq_id) AS claim_seq_id FROM claims WHERE clm_type_gen_type_id = 'CNH'  GROUP BY batch_no )
             UNION
             SELECT DISTINCT claim_seq_id,pat_auth_seq_id,claim_number
             FROM clm_authorization_details a WHERE claim_seq_id IN
             (SELECT claim_seq_id FROM claims WHERE clm_type_gen_type_id = 'CTM' )
             ) AA
             LEFT OUTER JOIN pat_authorization_details c ON (aa.pat_auth_seq_id = c.pat_auth_seq_id AND c.pat_enhanced_yn = 'N')
             WHERE c.pat_auth_seq_id IS NULL
                 OR ( c.pat_status_type_id = 'APR' AND c.completed_yn = 'Y' AND
                    ( c.claim_seq_id IN ( SELECT cc.claim_seq_id FROM clm_authorization_details cc
                        WHERE cc.parent_claim_seq_id IS NULL
                          START WITH cc.claim_seq_id = c.claim_seq_id
                          CONNECT BY cc.claim_seq_id = PRIOR parent_claim_seq_id)
                     OR c.claim_seq_id IS NULL)
                     );*/

  END select_prev_claim;
--=================================================================================
PROCEDURE delete_claim_records (
    v_claim_seq_id                  IN OUT clm_authorization_details.claim_seq_id%TYPE
  )
  IS
  v_rows number(10);

  BEGIN

    DELETE FROM clm_hospital_details b WHERE b.claim_seq_id = v_claim_seq_id ;
    DELETE FROM diagnosys_details a WHERE a.claim_seq_id = v_claim_seq_id ;
    DELETE FROM pat_observation_details b WHERE b.activity_dtl_seq_id in (select ad.activity_dtl_seq_id from pat_activity_details ad where ad.claim_seq_id = v_claim_seq_id);
    DELETE FROM pat_activity_details ad where ad.claim_seq_id= v_claim_seq_id;
    DELETE FROM clm_authorization_details a WHERE a.claim_seq_id = v_claim_seq_id ;

    v_claim_seq_id := NULL;
  commit;
  END delete_claim_records;
--===============================================================================
PROCEDURE override_claim (
    v_claim_seq_id                  IN  clm_authorization_details.claim_seq_id%TYPE,
    v_added_by                      IN NUMBER,
    v_override_remarks              IN clm_authorization_details.override_remarks%TYPE,
    v_rows_processed                OUT NUMBER
  )
  IS

 Cursor fin_clm is 
 select count(1) from fin_app.tpa_claims_payment p where p.claim_seq_id=v_claim_seq_id
 and p.claim_payment_status!='PENDING';
 
 Cursor clm_cur is 
 SELECT k.balance_seq_id,a.* from clm_authorization_details a
         JOIN clm_batch_upload_details b ON (a.clm_batch_seq_id=b.clm_batch_seq_id)
         LEFT OUTER JOIN tpa_enr_policy_member E ON (a.member_seq_id = e.member_seq_id)
         LEFT OUTER JOIN tpa_enr_policy_group gr ON (gr.policy_group_seq_id = e.policy_group_seq_id)   
         LEFT OUTER JOIN tpa_enr_balance k ON (e.policy_group_seq_id = k.policy_group_seq_id /*AND k.balance_seq_id = v_balance_seq_id*/ )
         WHERE ( E.mem_general_type_id != 'PFL' AND A.member_seq_id = K.member_seq_id OR K.member_seq_id IS NULL OR A.member_seq_id IS NULL ) 
         AND a.claim_seq_id  = v_claim_seq_id ;
  v_count   number;
  clm_rec  clm_cur%rowtype;
  v_sum                clm_authorization_details.ava_sum_insured%TYPE;
  v_seq_id            number(10);
   
  BEGIN
  
  authorization_pkg.reassign_user(null,'|'||v_claim_seq_id||'|',null,v_added_by,null,v_seq_id);

      OPEN fin_clm;
      FETCH fin_clm INTO v_count;
      CLOSE fin_clm;
      
      OPEN clm_cur;
      FETCH clm_cur INTO clm_rec;
      CLOSE clm_cur;
      
     if (clm_rec.claim_type='CTM') or (clm_rec.claim_type='CNH' and nvl(clm_rec.pat_auth_seq_id,0)=0)  then
         IF clm_rec.final_app_amount>0 and clm_rec.clm_status_type_id = 'APR' THEN
          v_sum   := CASE WHEN NVL(clm_rec.si_deduct_type,'WSI') = 'OSI' THEN 0
                          ELSE clm_rec.final_app_amount END;
         END IF;
     else
        IF clm_rec.final_app_amount>0 and clm_rec.clm_status_type_id = 'APR' THEN
         v_sum   := clm_rec.final_app_amount-clm_rec.pat_approved_amount ;
        END IF;
     end if;
      /*if v_sum> 0 then 
       v_sum :=v_sum;
      else 
        v_sum :=0;
      end if;*/
     IF v_count>0 THEN
          RAISE_APPLICATION_ERROR(-20395,'Claim presents in Finance so you Cannot Override.');
     else 
       DELETE FROM fin_app.tpa_claims_payment cp where cp.claim_seq_id= v_claim_seq_id;
     
        UPDATE clm_authorization_details cd 
        SET cd.completed_yn        = 'N',
            cd.clm_status_type_id  ='INP',
            cd.decision_date       = null,
            cd.completed_date      = null,
            cd.override_by         = v_added_by,
            cd.override_date       = sysdate,
            cd.override_remarks    = v_override_remarks,
            cd.audit_status        = case when cd.audit_status = 'CKD' then 'RCR' else cd.audit_status end
        where cd.claim_seq_id      = v_claim_seq_id;
     
       UPDATE tpa_enr_balance a SET
               a.utilised_sum_insured   = a.utilised_sum_insured - nvl(v_sum,0) ,
               a.updated_by             = v_added_by,
               a.updated_date           = SYSDATE
               WHERE a.balance_seq_id = clm_rec.balance_seq_id;
     
     
     
     END IF;
     v_rows_processed := SQL%ROWCOUNT; 
    commit;

  END override_claim;
--===============================================================================
PROCEDURE control_reject_claims (p_seq_id              IN Clm_Authorization_Details.Claim_Seq_Id%TYPE,
                                 p_denial_code         IN Clm_Authorization_Details.Denial_Code%TYPE,
                                 p_med_opn_remarks     IN Clm_Authorization_Details.Medical_Opinion_Remarks%TYPE,
                                 p_ovrd_remarks        IN Clm_Authorization_Details.Override_Remarks%TYPE,
                                 p_final_remarks       IN Clm_Authorization_Details.Final_Remarks%TYPE,
                                 p_added_by            IN Clm_Authorization_Details.Added_By%Type,
                                 p_internal_remarks    IN Clm_Authorization_Details.Internal_Remarks%Type
                                 )
AS
  CURSOR denial_cur IS
    SELECT d.denial_code, d.denial_description
    FROM Tpa_Denial_Codes d
    WHERE d.denial_code = p_denial_code;
    
  v_denial_cur denial_cur%ROWTYPE;
  
  CURSOR clm_den_code_cur IS
    SELECT p.denial_code
    FROM Pat_Activity_Details p
    WHERE p.claim_seq_id = p_seq_id;
    
    v_clm_den_code_cur clm_den_code_cur%ROWTYPE;
    
   CURSOR Claim_settelment_num IS
    SELECT c.settlement_number,c.claim_type,c.claim_number,ma.state_type_id,cc.short_name,C.COMPLETED_YN 
    FROM APP.CLM_AUTHORIZATION_DETAILS C
    JOIN TPA_ENR_POLICY_MEMBER M ON (C.MEMBER_SEQ_ID=M.MEMBER_SEQ_ID)
    JOIN TPA_ENR_MEM_ADDRESS MA ON (M.ENR_ADDRESS_SEQ_ID=MA.ENR_ADDRESS_SEQ_ID)
    JOIN TPA_COUNTRY_CODE CC ON (CC.COUNTRY_ID=MA.COUNTRY_ID)
    WHERE C.CLAIM_SEQ_ID=p_seq_id;  
   
    Claim_settelment_rec	Claim_settelment_num%rowtype;
  
    v_seq_id           number(10);
BEGIN
  
    OPEN Claim_settelment_num;
     FETCH Claim_settelment_num INTO Claim_settelment_rec;
      CLOSE Claim_settelment_num;  
  
  IF NVL(Claim_settelment_rec.Completed_Yn,'N')='Y' THEN
   RAISE_APPLICATION_ERROR(-20107,'You cannot perform this action through a completed Claim.'); 
  END IF;
  
  IF Claim_settelment_rec.Settlement_Number IS NULL THEN
     Claim_settelment_rec.Settlement_Number:=authorization_pkg.generate_id_numbers('STC',nvl(Claim_settelment_rec.short_name,'UAE'),nvl(Claim_settelment_rec.state_type_id,'DXB'),Claim_settelment_rec.claim_number,Claim_settelment_rec.Claim_Type);
  END IF;
  
  authorization_pkg.reassign_user(null,'|'||p_seq_id||'|',null,p_added_by,null,v_seq_id);

  OPEN denial_cur;
  FETCH denial_cur INTO v_denial_cur;
  CLOSE denial_cur;
  
  OPEN clm_den_code_cur;
  FETCH clm_den_code_cur INTO v_clm_den_code_cur;
  CLOSE clm_den_code_cur;
  
  --IF INSTR(nvl(v_clm_den_code_cur.denial_code, 0), p_denial_code) = 0 THEN
  -- When ever we are rejecting a claim intentionally all activity approved amounts are updating to "0"
    UPDATE Pat_Activity_Details pa
    SET pa.allowed_amount = 0,
        pa.approved_amount = 0,
        pa.denial_code = case when pa.denial_code is null then p_denial_code else case when pa.denial_code like '%'||p_denial_code||'%' then pa.denial_code else pa.denial_code||';'||p_denial_code end end,
        pa.denial_desc = case when pa.denial_desc is null then v_denial_cur.denial_description else case when pa.denial_desc like '%'||v_denial_cur.denial_description||'%' then pa.denial_desc else pa.denial_desc||';'||v_denial_cur.denial_description end end,
        pa.tpa_denial_code = CASE WHEN pa.tpa_denial_code IS NOT NULL THEN pa.tpa_denial_code||';'||v_denial_cur.denial_code ELSE v_denial_cur.denial_code END,
        pa.tpa_denial_desc = CASE WHEN pa.tpa_denial_desc IS NOT NULL THEN pa.tpa_denial_desc||';'||v_denial_cur.denial_description ELSE v_denial_cur.denial_description END
    
    WHERE pa.Claim_Seq_Id = p_seq_id;
      
 -- END IF;
 
  UPDATE Clm_Authorization_Details clm
    SET clm.tot_approved_amount = 0,
        clm.final_app_amount = 0,
        clm.clm_status_type_id = 'REJ',
        clm.completed_yn = 'Y',
        clm.completed_date = sysdate,
        clm.converted_final_approved_amt = 0,
        clm.pay_amt_in_usd=null,
        clm.medical_opinion_remarks = NULL,
        clm.override_remarks        = p_ovrd_remarks,
        clm.final_remarks           = p_final_remarks||','||p_med_opn_remarks,
        clm.settlement_number       = Claim_settelment_rec.Settlement_Number,
        clm.internal_remarks        = p_internal_remarks,
        clm.denial_code=p_denial_code,
        clm.processed_by = p_added_by
    WHERE clm.claim_seq_id = p_seq_id;
  COMMIT;  
END control_reject_claims;
--===========================================================================================================================
PROCEDURE online_clm_submit(v1_batch_seq_id                          IN VARCHAR2,
                            v1_hosp_seq_id                          IN VARCHAR2,
                            v1_added_by                              IN VARCHAR2,
                            v1_sl_no                                IN VARCHAR2,
                            v1_invoice_num                          IN VARCHAR2,
                            v1_mem_name                              IN VARCHAR2,
                            v1_mem_id                                IN VARCHAR2,
                            v1_pre_auth_num                          IN VARCHAR2,
                            v1_hospitalization                      IN VARCHAR2,
                            v1_discharge                            IN VARCHAR2,
                            v1_med_type                              IN VARCHAR2,
                            v1_benefit_type                          IN VARCHAR2,
                            v1_encounter_type                        IN VARCHAR2,
                            v1_clinician_id                          IN VARCHAR2 := 'N/A',
                            v1_clinician_name                        IN VARCHAR2 := 'N/A',
                            v1_sympton                              IN VARCHAR2,
                            v1_prim_diag_code                        IN VARCHAR2,
                            v1_prim_diag_desc                        IN VARCHAR2,
                            v1_secn_diag_code1                      IN VARCHAR2,
                            v1_secn_diag_code2                      IN VARCHAR2,
                            v1_secn_diag_code3                      IN VARCHAR2,
                            v1_secn_diag_code4                      IN VARCHAR2,
                            v1_secn_diag_code5                      IN VARCHAR2,
                            v1_first_ins_dt                          IN VARCHAR2,
                            v1_first_report_dt                      IN VARCHAR2,
                            v1_service_dt                            IN VARCHAR2,
                            v_activity_type_id                      IN VARCHAR2,
                            v1_inter_ser_code                        IN VARCHAR2,
                            v1_service_desc                          IN VARCHAR2,
                            v1_act_code                              IN VARCHAR2,
                            v1_act_req_amt                          IN VARCHAR2,
                            v1_act_qnt                              IN VARCHAR2,
                            v1_tooth_no                              IN VARCHAR2,
                            v1_lmp_date                              IN VARCHAR2,
                            v1_con_nature                            IN VARCHAR2,
                            v1_observation                          IN VARCHAR2,
                            v1_event_no                               IN VARCHAR2
                           )
AS
  parent_not_found        EXCEPTION;
  PRAGMA EXCEPTION_INIT (parent_not_found, -2291);
   
  str_tab                 ttk_util_pkg.str_table_type;
  v_icdcode               VARCHAR2(500);
  v_claim_seq_id          NUMBER;
  v_tooth_count           NUMBER;
  v_icd_count             NUMBER;
  v_unq_icd               VARCHAR2(500);
  

  
  CURSOR pat_cur(v_pre_auth_num  VARCHAR2) IS
    SELECT pa.pat_auth_seq_id, pa.pre_auth_number, pa.auth_number, pa.benifit_type,
           pa.encounter_type_id, pa.encounter_start_type,
           pa.hospitalization_date, pa.discharge_date, pa.lmp_date,
           pa.member_seq_id,pa.system_of_medicine_type_id, pa.conception_type
           
    FROM Pat_Authorization_Details pa
    WHERE pa.pre_auth_number = v_pre_auth_num;
    
  pat_rec                    pat_cur%ROWTYPE;
  
  --To Check Preauth with corresponding Provider and Memebr
  CURSOR pat_det_cur(v_mem_seq_id NUMBER,v_hosp_seq_id NUMBER,v_pre_auth_num VARCHAR2) IS
    SELECT COUNT(pa.auth_number) as auth_number
    FROM Pat_Authorization_Details pa
    WHERE pa.pre_auth_number = v_pre_auth_num
    AND pa.member_seq_id = v_mem_seq_id
    AND pa.hosp_seq_id = v_hosp_seq_id
    AND pa.pat_status_type_id = 'APR';
    
  pat_det_count      NUMBER;
  
  CURSOR clm_seq_cur(v_invoice_num VARCHAR2) IS
    Select c.claim_seq_id into v_clm_seq_id
      From clm_authorization_details c
      Where c.clm_batch_seq_id = v1_batch_seq_id
      And c.invoice_number = trim(v_invoice_num);
      
  CURSOR pat_clm_seq_cur(v_pat_seq_id NUMBER) IS
    Select c.claim_seq_id into v_clm_seq_id
     From clm_authorization_details c
     Where c.clm_batch_seq_id = v1_batch_seq_id
     And c.pat_auth_seq_id = v_pat_seq_id;
  
  CURSOR preauth_cur(v_mem_seq_id NUMBER,v_hosp_seq_id NUMBER,v_pre_auth_num VARCHAR2) IS
    SELECT pa.hosp_seq_id, pa.member_seq_id, pa.tpa_enrollment_id
    FROM Pat_Authorization_Details pa
    WHERE pa.pre_auth_number = v_pre_auth_num
    AND pa.pat_status_type_id = 'APR';
    
  preauth_rec    preauth_cur%ROWTYPE;  
  CURSOR pat_clm_cur(v_pat_seq_id NUMBER, v_batch_seq_id NUMBER, v_member_id VARCHAR2, v_hosp_seq_id NUMBER) IS
      SELECT --trim(TRAILING  ',' FROM c.invoice_number) as invoice_number,
             c.invoice_number,
             c.pat_auth_seq_id,
             p.pre_auth_number,
             p.system_of_medicine_type_id, p.mem_name,
             p.hospitalization_date,
             p.discharge_date,
             p.benifit_type,
             p.encounter_type_id,
             c.presenting_complaints,
             c.tpa_enrollment_id,
             c.clm_batch_seq_id
             
      FROM pat_authorization_details p
      JOIN clm_authorization_details c ON (p.pat_auth_seq_id = c.pat_auth_seq_id)
      JOIN Clm_Hospital_Details ch ON (c.claim_seq_id = ch.claim_seq_id)
      WHERE c.pat_auth_seq_id = v_pat_seq_id
      AND c.clm_batch_seq_id = v_batch_seq_id
      --AND c.tpa_enrollment_id = v_member_id
      AND ch.hosp_seq_id = v_hosp_seq_id;
      
    pat_clm_rec            pat_clm_cur%ROWTYPE;
  
  --Batch
  clm_batch_rec     clm_batch_upload_details%rowtype;
  clm_rec           clm_authorization_details%rowtype;
  clm_hosp_rec      clm_hospital_details%rowtype;
  diag_rec          diagnosys_details%rowtype;
  activity_rec      pat_activity_details%rowtype;
  observation_rec   pat_observation_details%rowtype;
  --v_hosp_seq_id     tpa_hosp_info.hosp_seq_id%TYPE;
  v_ins_seq_id      tpa_ins_info.ins_seq_id%TYPE;
  v_icd             VARCHAR2(1000);
  v_activity_count      number(4);
  v_prod_policy_rule_seq_id       tpa_ins_prod_policy_rules.prod_policy_rule_seq_id%type;
  v_auth_count                    NUMBER;
  
  cursor encounter_cur(l_benifit_type VARCHAR2, l_encounter_type VARCHAR2) is
    select nvl(ec.encounter_seq_id, 0)
    from tpa_encounter_type_codes ec
    where ec.header_type = 'ENCOUNTER_TYPE'
    and UPPER(ec.description) like '%'||UPPER(l_encounter_type)||'%'
    and ec.benefit_gen_type_id = l_benifit_type;
    
   v_encounter_seq_id NUMBER;
 
   v_batch_no                   varchar2(500);
   v_batch_tot_amount           number;
   --v_count                      number:=1;
   v_count1                     number;
   v_count2                     number;
   l_benifit_type               VARCHAR2(500);
   
   --Claim
  v_authorization_type          varchar2(500);
  v_payerid             tpa_ins_info.tpa_payer_id%type;
  i                     number(4):=0;
  j                     number(4):=0;
  v_activity_net        number;
  v_cnt                 number := 0;
  v_cnt1                 number := 0;
  v_type                varchar2(500);
  v_commet              varchar2(4000);
  v_observ_seq_id       NUMBER;
  v_act_seq_id          NUMBER;
  --v_clm_seq_id          NUMBER;
  v_batch_cnt           NUMBER;
  v_seq_id_dum          NUMBER;
  v_tooth_num           VARCHAR2(500);
  
  v_policy_group_seq_id tpa_enr_policy_group.policy_group_seq_id%TYPE;
  
  CURSOR hosp_cur(v_hosp_seq_id  NUMBER) IS
    SELECT t.hosp_seq_id, t.hosp_name, ha.address_1, ha.city_type_id, ha.state_type_id, ha.pin_code, t.primary_network,
           t.off_phone_no_1, t.office_fax_no, t.empanel_number
    FROM Tpa_Hosp_Info t
    JOIN tpa_hosp_address ha   ON (ha.hosp_seq_id = t.hosp_seq_id)
    WHERE t.hosp_seq_id = v_hosp_seq_id;
    
  hosp_rec hosp_cur%ROWTYPE;
  
  cursor pol_mem_cur (v_mem_id app.tpa_enr_policy_member.tpa_enrollment_id%type, v_hospitalization_dt VARCHAR2)is 
    select tem.member_seq_id, tem.mem_name,tem.mem_age,tep.policy_seq_id,tep.enrol_type_id,
           tep.ins_seq_id, tem.emirate_id, 
        (nvl(f.sum_insured,0) - nvl(f.utilised_sum_insured,0)) AS ava_sum_insured
    from app.tpa_enr_policy_member tem
    join app.tpa_enr_policy_group teg      on (tem.policy_group_seq_id = teg.policy_group_seq_id)
    join app.tpa_enr_policy tep            on (teg.policy_seq_id = tep.policy_seq_id)
    left join tpa_enr_balance F            on (teg.policy_group_seq_id = f.policy_group_seq_id)
    where tem.tpa_enrollment_id = trim(v_mem_id)
    and v_hospitalization_dt between tem.date_of_inception and tem.date_of_exit
    and ( tem.mem_general_type_id != 'PFL' 
    and tem.member_seq_id = F.member_seq_id 
    or F.member_seq_id IS NULL OR tem.member_seq_id IS NULL );
    -------
    cursor exist_mem_cur(v_mem_id VARCHAR2) is
     select tem.member_seq_id, tem.mem_name,tem.mem_age,tep.policy_seq_id,tep.enrol_type_id,
           tep.ins_seq_id, tem.emirate_id, 
        (nvl(f.sum_insured,0) - nvl(f.utilised_sum_insured,0)) AS ava_sum_insured
    from app.tpa_enr_policy_member tem
    join app.tpa_enr_policy_group teg      on (tem.policy_group_seq_id = teg.policy_group_seq_id)
    join app.tpa_enr_policy tep            on (teg.policy_seq_id = tep.policy_seq_id)
    left join tpa_enr_balance F            on (teg.policy_group_seq_id = f.policy_group_seq_id)
    where tem.member_seq_id = (select max(t.member_seq_id)
                               from tpa_enr_policy_member t
                               where t.tpa_enrollment_id = trim(v_mem_id)
                              )
    and ( tem.mem_general_type_id != 'PFL' 
    and tem.member_seq_id = F.member_seq_id
    or F.member_seq_id IS NULL OR tem.member_seq_id IS NULL );
  
    pol_mem_rec      pol_mem_cur%rowtype;
    exist_mem_rec    exist_mem_cur%ROWTYPE;
    v_result_set      sys_refcursor;
  
  
  --Activity  
  Cursor act_cur(v_act_code  VARCHAR2) IS
    SELECT a.activity_type_seq_id, a.activity_code, a.unit_price
    FROM Tpa_Activity_Master_Details a
    WHERE a.activity_code = trim(UPPER(v_act_code));
    
  act_rec                 act_cur%ROWTYPE;
  
  -------tariff------  
  CURSOR clm_tariff_cur(v_seq_id pat_activity_details.claim_seq_id%type) IS
    SELECT hd.hosp_seq_id,
           tip.product_cat_type_id,
           tep.ins_seq_id,
           tep.group_reg_seq_id,
           pad.claim_seq_id,pad.claim_type,
           pad.network_yn,
           pad.policy_seq_id,
           tep.tariff_type_id
           
    FROM clm_authorization_details pad
    JOIN clm_hospital_details hd ON (hd.claim_seq_id=pad.claim_seq_id)
    JOIN tpa_enr_policy tep      ON (pad.policy_seq_id=tep.policy_seq_id)
    JOIN tpa_ins_product tip     ON (tep.product_seq_id=tip.product_seq_id)
    WHERE pad.claim_seq_id= v_seq_id;

  clm_tariff_rec             clm_tariff_cur%ROWTYPE;
  
  cursor act_tariff_cur(v_hosp_seq number,v_ins_seq_id number,v_network_type varchar2,
                        v_act_code varchar2,v_start_date date,v_service_dt DATE,v_inter_ser_code VARCHAR2) is 
     select  thtd.gross_amount ,
             thtd.disc_amount,
             thtd.gross_amount- thtd.disc_amount as disc_gross_amount,
             thtd.bundle_id,
             thtd.package_id,
             thtd.internal_code,
             tamd.act_mas_dtl_seq_id as activity_seq_id,
             tamd.activity_code,
             tatc.activity_type_id,
             thtd.start_date,
             thtd.end_date,
             thtd.internal_desc
             
    from tpa_activity_master_details tamd
    JOIN tpa_activity_type_codes tatc ON (tamd.activity_type_seq_id=tatc.activity_type_seq_id)
    JOIN tpa_hosp_tariff_details thtd ON (tamd.act_mas_dtl_seq_id=thtd.activity_seq_id)
    WHERE thtd.hosp_seq_id=v_hosp_seq
    AND thtd.ins_seq_id=v_ins_seq_id
    AND thtd.network_type=v_network_type
    --AND v_start_date BETWEEN  thtd.start_date AND NVL(thtd.end_date,v_start_date)
    AND tamd.activity_code=upper(trim(v_act_code))
    AND thtd.internal_code = upper(trim(v_inter_ser_code))
    and to_date(v_service_dt, 'DD-MM-RRRR') between trunc(thtd.start_date) and trunc(nvl(thtd.end_date, sysdate));
    --AND thtd.end_date IS NULL OR TO_CHAR(thtd.end_date, 'DD-MON-RRRR') > TO_CHAR(SYSDATE, 'DD-MON-RRRR');
    
  act_tariff_rec act_tariff_cur%ROWTYPE;

  --provider_rec   provider_network%rowtype;
  
  v_product_network_type    varchar2(500);
  v_count                   number(10) := 0;
  v_count3                  number;
  v_tariff_ins_seq_id           number(10);
  v_tariff_count                number(10);
  v_tpa_ins_seq_id              number(10);
  v_activity_type_seq_id        number(10);
  v_err_seq_id                  number;
  v_row_processed               number;
  v_clm_batch_seq_id            NUMBER;
  v_sys_of_medicine             VARCHAR2(500);
  v_diag_clm_seq_id             NUMBER;
  v_invoice_count               NUMBER;
  l_encounter_type              VARCHAR2(500);
  l_con_nature                  VARCHAR2(500);
-------tariff------
  CURSOR PHARMACY_DISCOUNT(v_hosp_seq number) IS
    SELECT A.DISC_PERCENT 
    FROM app.tpa_hosp_tariff_details a 
    WHERE a.acitivity_type_seq_id=5
    AND a.hosp_seq_id=v_hosp_seq; 
 
    V_PHARMACY_DISC               NUMBER; 

  CURSOR clin_name_cur(v_clinician_id varchar2,v_hosp_seq_id NUMBER) IS
    select md.contact_name, md.professional_id
    from tpa_hosp_professionals md
    where md.hosp_seq_id = v_hosp_seq_id
    and UPPER(md.professional_id) = v_clinician_id;

  clin_name_rec clin_name_cur%ROWTYPE;
  
  --Diagnosys
  
  CURSOR diag_cur(v_diag_code VARCHAR2) IS
    select d.icd10_seq_id
    from tpa_icd10_master_details d
    where d.icd_code = UPPER(trim(v_diag_code));
  
  diag_record diag_cur%ROWTYPE;
  
  CURSOR clm_details_cur(v_hosp_seq_id  NUMBER,v_invoice_num VARCHAR2) IS
    SELECT c.claim_seq_id, c.invoice_number, c.tpa_enrollment_id,
           c.system_of_medicine_type_id, c.mem_name,
           --p.code,
           c.date_of_hospitalization,
           c.benifit_type,
           c.encounter_type_id,
           c.clm_batch_seq_id,
           c.presenting_complaints
           
    FROM clm_authorization_details c
    --JOIN pat_activity_details p ON (c.claim_seq_id = p.claim_seq_id)
    JOIN diagnosys_details d ON (d.claim_seq_id = c.claim_seq_id)
    LEFT JOIN clm_hospital_details ch on (c.claim_seq_id = ch.claim_seq_id)
    WHERE c.invoice_number = trim(v_invoice_num)
    AND ch.hosp_seq_id = v_hosp_seq_id
    AND c.clm_batch_seq_id = v1_batch_seq_id;
    
  clm_details_rec clm_details_cur%ROWTYPE;
  
  CURSOR diagnosys_cur(v_invoice VARCHAR2) IS
    SELECT UPPER(to_char(wm_concat(d.diagnosys_code))) as prim_diag_code
    FROM Diagnosys_Details d
    JOIN Clm_Authorization_Details c ON (c.claim_seq_id = d.claim_seq_id)
    WHERE c.invoice_number = v_invoice
    And c.clm_batch_seq_id = v1_batch_seq_id
    And d.primary_ailment_yn = 'Y';
    
  CURSOR clm_all_diag_cur(v_invoice VARCHAR2) IS
    SELECT UPPER(to_char(wm_concat(d.diagnosys_code))) as diag_code
    FROM Diagnosys_Details d
    JOIN Clm_Authorization_Details c ON (c.claim_seq_id = d.claim_seq_id)
    WHERE c.invoice_number = v_invoice
    And c.clm_batch_seq_id = v1_batch_seq_id
    And d.primary_ailment_yn = 'N';
    
  CURSOR pat_diagnosys_cur(v_pat_seq_id NUMBER) IS
    SELECT UPPER(to_char(wm_concat(d.diagnosys_code))) as prim_diag_code
    FROM Diagnosys_Details d
    JOIN Clm_Authorization_Details c ON (c.claim_seq_id = d.claim_seq_id)
    JOIN Pat_Authorization_Details p ON (p.pat_auth_seq_id = c.pat_auth_seq_id)
    WHERE p.pat_auth_seq_id = v_pat_seq_id
    And c.clm_batch_seq_id = v1_batch_seq_id
    And d.primary_ailment_yn = 'Y';
    
  CURSOR pat_all_diag_cur(v_pat_seq_id NUMBER) IS
    SELECT UPPER(to_char(wm_concat(d.diagnosys_code))) as diag_code
    FROM Diagnosys_Details d
    JOIN Clm_Authorization_Details c ON (c.claim_seq_id = d.claim_seq_id)
    JOIN Pat_Authorization_Details p ON (p.pat_auth_seq_id = c.pat_auth_seq_id)
    WHERE p.pat_auth_seq_id = v_pat_seq_id
    And c.clm_batch_seq_id = v1_batch_seq_id
    And d.primary_ailment_yn = 'N';
  
  all_diag_rec        clm_all_diag_cur%ROWTYPE;
  diagnosys_rec       diagnosys_cur%ROWTYPE;
  
  CURSOR chk_diag_cur(v_clm_seq VARCHAR2, v_icd_code VARCHAR2) IS
    SELECT UPPER(d.diagnosys_code) as diag_code
    FROM Diagnosys_Details d
    JOIN Clm_Authorization_Details c ON (c.claim_seq_id = d.claim_seq_id)
    WHERE c.claim_seq_id = v_clm_seq
    And c.clm_batch_seq_id = v1_batch_seq_id
    And d.diagnosys_code = UPPER(v_icd_code);
    
  chk_diag_rec             chk_diag_cur%ROWTYPE;
    
  Cursor batch_details(v_batch_seq_id NUMBER) is
  select c.received_date,c.source_type_id 
    from clm_batch_upload_details c
    where c.clm_batch_seq_id=v_batch_seq_id;
  
  CURSOR chk_act_cur(v_inter_ser_code VARCHAR2,v_hosp_seq_id NUMBER) IS
    select m.activity_code
    from tpa_hosp_tariff_details t
    join tpa_activity_master_details m on (m.act_mas_dtl_seq_id = t.activity_seq_id)
    WHERE t.hosp_seq_id = v_hosp_seq_id
    AND UPPER(t.internal_code) = UPPER(TRIM(v_inter_ser_code));
    
  v_mstr_act_code  VARCHAR2(500);
  
  CURSOR chk_dntl_cur(v_dntl_act_code VARCHAR2) IS
    select d.tooth_no_required
    from dental_rule_tab d
    where UPPER(trim(d.cdt_code)) = UPPER(trim(v_dntl_act_code));
    
  v_tooth_req_yn VARCHAR2(500);
  
  CURSOR chk_tooth_cur(v_tooth_no VARCHAR2) IS
    select t.tooth_code
    from tpa_tooth_number t
    where t.tooth_code in (v_tooth_no);
    
  chk_tooth_rec  VARCHAR2(500);
  v_tooth_num_chk VARCHAR2(500);
  
  CURSOR cur_ins_info IS
  select ii.ins_seq_id 
  from app.tpa_ins_info ii 
  where ii.ins_comp_code_number='ALK01';
    
  CURSOR pat_sts_cur(v_pat_seq NUMBER) IS
    SELECT c.claim_number, c.completed_yn, c.claim_seq_id
    FROM pat_authorization_details p
    JOIN clm_authorization_details c ON ((c.pat_auth_seq_id = p.pat_auth_seq_id) AND (c.claim_seq_id = p.claim_seq_id))
    Where c.pat_auth_seq_id = v_pat_seq;

  ststus_rec           pat_sts_cur%ROWTYPE;
  
  CURSOR benefit_cur(v_icd_code VARCHAR2) IS
    Select t.benefit_type
    From Tpa_Icd10_Master_Details t
    Where t.icd_code = v_icd_code;
  
  v_icd_benefit        benefit_cur%ROWTYPE;
  
 /* err_parm  NUMBER;*/
  v_activity_code    VARCHAR2(500);
  l_benifit_type1    VARCHAR2(500);
  v_leap_year          NUMBER;
  v_spec_char_cnt     NUMBER;
  v_date1            NUMBER := 0;
  v_date2            NUMBER := 0;
  v_date3            NUMBER := 0;
  v_char_form        CHAR(1);
  v_qnt_cnt          NUMBER;
  v_event            NUMBER;
  v_event_len        NUMBER;
  v_clin_id_cnt      NUMBER;
  v_auth_hosp_count  NUMBER;
  v_auth_mem_count   NUMBER;
  v_auth_status      NUMBER;
  v_assign_auth_count NUMBER;
  
  
  v_batch_seq_id                   Clm_Authorization_Details.Clm_Batch_Seq_Id%TYPE;
  v_hosp_seq_id                     Tpa_Hosp_Info.Hosp_Seq_Id%TYPE;
  v_added_by                       NUMBER;
  v_sl_no                           NUMBER;
  v_invoice_num                     Clm_Authorization_Details.Invoice_Number%TYPE;
  v_mem_name                       Clm_Authorization_Details.Mem_Name%TYPE;
  v_mem_id                         Clm_Authorization_Details.Tpa_Enrollment_Id%TYPE;
  v_pre_auth_num                   Pat_Authorization_Details.Pre_Auth_Number%TYPE;
  v_hospitalization                 Clm_Authorization_Details.Date_Of_Hospitalization%TYPE;---
  v_discharge                       Clm_Authorization_Details.Date_Of_Discharge%TYPE;-----
  v_med_type                       VARCHAR2(500);
  v_benefit_type                   VARCHAR2(500);
  v_encounter_type                 VARCHAR2(500);
  v_clinician_id                   Clm_Authorization_Details.Clinician_Id%TYPE;
  v_clinician_name                 VARCHAR2(500);
  v_sympton                         VARCHAR2(2000);
  v_prim_diag_code                 Diagnosys_Details.diagnosys_code%TYPE;
  v_prim_diag_desc                 tpa_icd_codes.icd_description%TYPE;
  v_secn_diag_code1                 Diagnosys_Details.diagnosys_code%TYPE;
  v_secn_diag_code2                 Diagnosys_Details.diagnosys_code%TYPE;
  v_secn_diag_code3                 Diagnosys_Details.diagnosys_code%TYPE;
  v_secn_diag_code4                 Diagnosys_Details.diagnosys_code%TYPE;
  v_secn_diag_code5                 Diagnosys_Details.diagnosys_code%TYPE;
  v_first_ins_dt                   DATE;--
  v_first_report_dt                 DATE;---
  v_service_dt                     DATE;---
  v_inter_ser_code                 VARCHAR2(500);
  v_service_desc                   VARCHAR2(2000);
  v_act_code                       Pat_Activity_Details.Code%TYPE;
  v_act_req_amt                     Pat_Activity_Details.Disc_Gross_Amount%TYPE;
  v_act_qnt                         Pat_Activity_Details.Quantity%TYPE;
  v_tooth_no                       Pat_Activity_Details.Tooth_No%TYPE;
  v_lmp_date                       Pat_Authorization_Details.Lmp_Date%TYPE;----
  v_con_nature                     VARCHAR2(500);
  v_observation                     VARCHAR2(2000);
  p_err_count                      NUMBER(10);
  v_orcl_err_msg                   VARCHAR2(4000);
  v_orcl_err_code                  VARCHAR2(4000);
  v_event_no                       VARCHAR2(500);
  v_event_num                      VARCHAR2(250);
  v_pat_event_num                  VARCHAR2(250);
  p_sucess_count                   NUMBER;
  p_err_log                         SYS_REFCURSOR;

    err_parm                        varchar2(100);
    
 BEGIN

 
  v_upload_error_message := null;
  
  IF nvl(v1_batch_seq_id,0) = 0 THEN create_error_log(-20021, 'Batch Not available.', v_dependent_count); END IF; 
  
  IF nvl(v_batch_seq_id,0) = 0 THEN
    BEGIN v_batch_seq_id :=TRIM(TO_NUMBER(v1_batch_seq_id)); 
    EXCEPTION WHEN OTHERS THEN create_error_log(-20021, 'Batch seq id invalid.');
    END;
  
    BEGIN v_hosp_seq_id :=TRIM(TO_NUMBER(v1_hosp_seq_id));
    EXCEPTION WHEN OTHERS THEN create_error_log(-20021, 'Hospital seq id invalid.');
    END;
  
    BEGIN v_added_by :=TRIM(TO_NUMBER(v1_added_by));
    EXCEPTION WHEN OTHERS THEN create_error_log(-20021, 'Added by invalid.');
    END;
  
    BEGIN v_sl_no :=TRIM(TO_NUMBER(v1_sl_no));
    EXCEPTION WHEN OTHERS THEN create_error_log(-20021, 'Sl no invalid.');
    END;
  
    BEGIN v_encounter_type :=TRIM(v1_encounter_type);
    EXCEPTION WHEN OTHERS THEN create_error_log(-20021, 'Encounter type invalid.');
    END;
  
    BEGIN v_act_req_amt :=TRIM(TO_NUMBER(v1_act_req_amt));
    EXCEPTION WHEN OTHERS THEN create_error_log(-20021, 'Requested amount invalid.');
    END;

    BEGIN v_act_qnt :=TRIM(TO_NUMBER(v1_act_qnt));
    EXCEPTION WHEN OTHERS THEN create_error_log(-20021, 'Quantity should be number format.');
    END;
  
    BEGIN v_hospitalization := TO_DATE(TRIM(v1_hospitalization),'DD/MM/YYYY');
    EXCEPTION WHEN OTHERS THEN create_error_log(-20021, 'Hospitalization date is invalid.');
    END;
  
    BEGIN v_discharge := TO_DATE(TRIM(v1_discharge),'DD/MM/YYYY');
    EXCEPTION WHEN OTHERS THEN create_error_log(-20021, 'Hospitalization date is invalid.');
    END;
  
    BEGIN v_first_ins_dt := TO_DATE(TRIM(v1_first_ins_dt),'DD/MM/YYYY');
    EXCEPTION WHEN OTHERS THEN create_error_log(-20021, 'First ins date is invalid.');
    END;
    
    BEGIN v_first_report_dt := TO_DATE(TRIM(v1_first_report_dt),'DD/MM/YYYY');
    EXCEPTION WHEN OTHERS THEN create_error_log(-20021, 'First report date is invalid.');
    END;
    
    BEGIN v_service_dt := TO_DATE(TRIM(v1_service_dt),'DD/MM/YYYY');
    EXCEPTION WHEN OTHERS THEN create_error_log(-20021, 'Service date is invalid.');
    END;
    
    BEGIN v_lmp_date := TO_DATE(TRIM(v1_lmp_date),'DD/MM/YYYY');
    EXCEPTION WHEN OTHERS THEN create_error_log(-20021, 'LMP date is invalid.');
    END;
    -----------------
    
    BEGIN v_invoice_num := UPPER(TRIM(REPLACE(v1_invoice_num, ' ','')));
    EXCEPTION 
      WHEN VALUE_ERROR THEN create_error_log(-20021, 'Size is too large for INVOICE NO. field.');
      WHEN OTHERS THEN create_error_log(-20021, 'INVOICE NO. invalid.');
    END;
    
    BEGIN v_mem_name := UPPER(TRIM(v1_mem_name));
    EXCEPTION 
      WHEN VALUE_ERROR THEN create_error_log(-20021, 'Size is too large for MEMBER NAME field.');
      WHEN OTHERS THEN create_error_log(-20021, 'MEMBER NAME invalid.');
    END;
    
    BEGIN v_mem_id := UPPER(TRIM(v1_mem_id));
    EXCEPTION 
      WHEN VALUE_ERROR THEN create_error_log(-20021, 'Size is too large for MEMBER ID field.');
      WHEN OTHERS THEN create_error_log(-20021, 'MEMBER ID invalid.');
    END;
    
    BEGIN v_pre_auth_num := UPPER(TRIM(v1_pre_auth_num));
    EXCEPTION 
      WHEN VALUE_ERROR THEN create_error_log(-20021, 'Size is too large for PreApproval No. field.');
      WHEN OTHERS THEN create_error_log(-20021, 'PreApproval No. invalid.');
    END;
    
    BEGIN v_med_type := UPPER(TRIM(v1_med_type));
    EXCEPTION 
      WHEN VALUE_ERROR THEN create_error_log(-20021, 'Size is too large for SYSTEM OF MEDICINE field.');
      WHEN OTHERS THEN create_error_log(-20021, 'Batch seq id invalid.');
    END;
    
    BEGIN v_clinician_id := UPPER(TRIM(v1_clinician_id));
    EXCEPTION 
      WHEN VALUE_ERROR THEN create_error_log(-20021, 'Size is too large for CLINICIAN ID field.');
      WHEN OTHERS THEN create_error_log(-20021, 'CLINICIAN ID invalid.');
    END;
    
    BEGIN v_clinician_name := UPPER(TRIM(v1_clinician_name));
    EXCEPTION 
      WHEN VALUE_ERROR THEN create_error_log(-20021, 'Size is too large for CLINICIAN NAME field.');
      WHEN OTHERS THEN create_error_log(-20021, 'CLINICIAN NAME invalid.');
    END;
    
    BEGIN v_benefit_type := UPPER(TRIM(v1_benefit_type));
    EXCEPTION 
      WHEN VALUE_ERROR THEN create_error_log(-20021, 'Size is too large for BENEFIT TYPE field.');
      WHEN OTHERS THEN create_error_log(-20021, 'BENEFIT TYPE invalid.');
    END;
    
    BEGIN v_encounter_type := UPPER(TRIM(v1_encounter_type));
    EXCEPTION 
      WHEN VALUE_ERROR THEN create_error_log(-20021, 'Size is too large for ENCOUNTER TYPE field.');
      WHEN OTHERS THEN create_error_log(-20021, 'ENCOUNTER TYPE invalid.');
    END;
    
    BEGIN v_sympton := UPPER(TRIM(v1_sympton));
    EXCEPTION 
      WHEN VALUE_ERROR THEN create_error_log(-20021, 'Size is too large for SYMPTOMS field.');
      WHEN OTHERS THEN create_error_log(-20021, 'SYMPTOMS invalid.');
    END;
    
    BEGIN v_prim_diag_code := UPPER(TRIM(v1_prim_diag_code));
    EXCEPTION 
      WHEN VALUE_ERROR THEN create_error_log(-20021, 'Size is too large for PRINCIPAL ICD CODE field.');
      WHEN OTHERS THEN create_error_log(-20021, 'PRINCIPAL ICD CODE invalid.');
    END;
    
    BEGIN v_prim_diag_desc := UPPER(TRIM(v1_prim_diag_desc));
    EXCEPTION 
      WHEN VALUE_ERROR THEN create_error_log(-20021, 'Size is too large for ICD DESCRIPTION field.');
      WHEN OTHERS THEN create_error_log(-20021, 'ICD DESCRIPTION invalid.');
    END;
    
    BEGIN v_secn_diag_code1 := UPPER(TRIM(v1_secn_diag_code1));
    EXCEPTION 
      WHEN VALUE_ERROR THEN create_error_log(-20021, 'Size is too large for SECONDARY ICD CODE 1 field.');
      WHEN OTHERS THEN create_error_log(-20021, 'SECONDARY ICD CODE 1 invalid.');
    END;
    
    BEGIN v_secn_diag_code2 := UPPER(TRIM(v1_secn_diag_code2));
    EXCEPTION 
      WHEN VALUE_ERROR THEN create_error_log(-20021, 'Size is too large for SECONDARY ICD CODE 2 field.');
      WHEN OTHERS THEN create_error_log(-20021, 'SECONDARY ICD CODE 2 invalid.');
    END;
    
    BEGIN v_secn_diag_code3 := UPPER(TRIM(v1_secn_diag_code3));
    EXCEPTION 
      WHEN VALUE_ERROR THEN create_error_log(-20021, 'Size is too large for SECONDARY ICD CODE 3 field.');
      WHEN OTHERS THEN create_error_log(-20021, 'SECONDARY ICD CODE 3 invalid.');
    END;
    
    BEGIN v_secn_diag_code4 := UPPER(TRIM(v1_secn_diag_code4));
    EXCEPTION 
      WHEN VALUE_ERROR THEN create_error_log(-20021, 'Size is too large for SECONDARY ICD CODE 4 field.');
      WHEN OTHERS THEN create_error_log(-20021, 'SECONDARY ICD CODE 4 invalid.');
    END;
    
    BEGIN v_secn_diag_code5 := UPPER(TRIM(v1_secn_diag_code5));
    EXCEPTION 
      WHEN VALUE_ERROR THEN create_error_log(-20021, 'Size is too large for SECONDARY ICD CODE 5 field.');
      WHEN OTHERS THEN create_error_log(-20021, 'SECONDARY ICD CODE 5 invalid.');
    END;
    
    BEGIN v_inter_ser_code := UPPER(TRIM(v1_inter_ser_code));
    EXCEPTION 
      WHEN VALUE_ERROR THEN create_error_log(-20021, 'Size is too large for INTERNAL  SERVICE CODE field.');
      WHEN OTHERS THEN create_error_log(-20021, 'INTERNAL  SERVICE CODE invalid.');
    END;
    
    BEGIN v_service_desc := UPPER(TRIM(v1_service_desc));
    EXCEPTION 
      WHEN VALUE_ERROR THEN create_error_log(-20021, 'Size is too large for SERVICE DESCRIPTION field.');
      WHEN OTHERS THEN create_error_log(-20021, 'SERVICE DESCRIPTION invalid.');
    END;
    
    BEGIN v_act_code := UPPER(TRIM(v1_act_code));
    EXCEPTION 
      WHEN VALUE_ERROR THEN create_error_log(-20021, 'Size is too large for CPT CODE field.');
      WHEN OTHERS THEN create_error_log(-20021, 'CPT CODE invalid.');
    END;
    
    BEGIN v_tooth_no := UPPER(TRIM(replace(v1_tooth_no,' ','')));
    EXCEPTION 
      WHEN VALUE_ERROR THEN create_error_log(-20021, 'Size is too large for Tooth Number field.');
      WHEN OTHERS THEN create_error_log(-20021, 'Tooth Number invalid.');
    END;
    
    BEGIN v_con_nature := UPPER(TRIM(v1_con_nature));
    EXCEPTION 
      WHEN VALUE_ERROR THEN create_error_log(-20021, 'Size is too large for Nature Of Conception field.');
      WHEN OTHERS THEN create_error_log(-20021, 'Nature Of Conception invalid.');
    END;
    
    BEGIN v_observation := UPPER(TRIM(v1_observation));
    EXCEPTION 
      WHEN VALUE_ERROR THEN create_error_log(-20021, 'Size is too large for OBSERVATION field.');
      WHEN OTHERS THEN create_error_log(-20021, 'OBSERVATION invalid.');
    END;
    
    v_event_no := trim(v1_event_no);
    
    l_benifit_type := case when trim(v_benefit_type) IN ('IN PATIENT', 'IN-PATIENT', 'INPATIENT', 'IPT') then 'IPT'
                           when trim(v_benefit_type) IN ('OUT PATIENT', 'OUT-PATIENT','OUTPATIENT') then 'OPTS'
                           when trim(v_benefit_type) IN ('Optical', 'OPTICAL', 'OPTC') then 'OPTC'
                           when trim(v_benefit_type) IN ('OP MATERNITY', 'MTI')  then 'OMTI'
                           when trim(v_benefit_type) IN ('IP MATERNITY', 'MTI')  then 'IMTI'
                           when trim(v_benefit_type) IN ('Dental', 'DENTAL', 'DNTL') then 'DNTL'
                           when trim(v_benefit_type) IN ('Health Check-up', 'HEALTH CHECK-UP', 'HEAC') then 'HEAC'
                           when trim(v_benefit_type) IN ('Day Care', 'DAY CARE', 'DAYC') then 'DAYC'
                      end;
                      
    l_benifit_type1 := l_benifit_type;--case when l_benifit_type IN ('OMTI', 'IMTI') then 'MTI' else l_benifit_type end;
    
    l_encounter_type := case when trim(v_encounter_type) = 'OP NO-EMERGENCY' AND l_benifit_type IN ('OPTS', 'OMTI', 'OPTC', 'DNTL', 'MTI') then
                                'No Bed + No Emergency room'
                              when trim(v_encounter_type) = 'OP EMERGENCY' AND l_benifit_type IN ('OPTS', 'OMTI', 'OPTC', 'DNTL', 'MTI') then
                                'No Bed + Emergency room'
                              when trim(v_encounter_type) = 'IP NO-EMERGENCY' AND l_benifit_type IN ('IPT', 'IMTI', 'MTI') then
                                'Inpatient Bed + No Emergency room'
                              when trim(v_encounter_type) = 'IP EMERGENCY' AND l_benifit_type IN ('IPT', 'IMTI', 'MTI') then
                                'Inpatient Bed + emergency room'
                         end;
    
    v_sys_of_medicine := case TRIM(v_med_type) when UPPER('Ayurvedic') Then 'SAY'
                                               when UPPER('Homeopathy') Then 'SAH'
                                               when UPPER('Acupuncture') Then 'SAA'
                                               when UPPER('Chiropractic') Then 'SAC'
                                               when UPPER('Naturopathy') Then 'SAN'
                                               when UPPER('Osteopathy') Then 'SAO'
                                               when UPPER('Chinese Herbal Medicine') Then 'SACH'
                                               when UPPER('Podiatry') Then 'SAP'
                                               when UPPER('Allopathy') Then 'SAL'
                                               end;
    
    l_con_nature := CASE WHEN trim(v_con_nature) = UPPER('Natural') THEN 'NAT'
                         WHEN trim(v_con_nature) = UPPER('Assisted') THEN 'AST'
                    END;
                    
    IF v_mem_name IS NULL THEN create_error_log(-20021, 'Member Name Cannot be Blank.', v_dependent_count); END IF; 
    IF v_mem_id IS NULL THEN create_error_log(-20021, 'Member ID Cannot be Blank.', v_dependent_count); END IF;
    IF v_med_type IS NULL THEN create_error_log(-20021, 'System Of Medicine Field Cannot be Blank.', v_dependent_count); END IF;
    IF v_prim_diag_code IS NULL THEN create_error_log(-20021, 'Primary/ Principal ICD Code is Required.', v_dependent_count);  END IF;
    IF v_prim_diag_desc IS NULL THEN create_error_log(-20021, 'ICD Description is Required', v_dependent_count); END IF;
    IF v_activity_type_id IS NULL THEN create_error_log(-20021, 'Activity Type can not be blank.', v_dependent_count); END IF;
    IF v_activity_type_id IS NOT NULL AND trim(UPPER(v_activity_type_id)) NOT IN ('ACTIVITY', 'DRUG') THEN create_error_log(-20021, 'Activity Type value should be Activity or Drug.', v_dependent_count); END IF;
    IF v_inter_ser_code IS NULL AND v_activity_type_id !='Drug' THEN create_error_log(-20021, 'Internal Code cannot be Blank.', v_dependent_count); END IF;
    IF v_invoice_num IS NULL THEN create_error_log(-20021, 'Invoice Number is required to Submit a Claim.', v_dependent_count); END IF;
    --IF v_clinician_id IS NULL THEN create_error_log(-20021, 'Clinician ID Required for Claim', v_dependent_count);   END IF;
    IF v_hospitalization IS NULL  THEN create_error_log(-20021, 'Treatment date cannot be blank .', v_dependent_count);  END IF;
    IF v_act_req_amt IS NULL THEN create_error_log(-20021, 'Claimed Amount is Required', v_dependent_count); END IF;  
    IF v_act_qnt IS NULL THEN create_error_log(-20021, 'Quantity field cannot be blank', v_dependent_count); END IF;
    IF v_observation IS NULL THEN create_error_log(-20021, 'Observation field cannot be blank', v_dependent_count);  END IF;
    IF v_sympton IS NULL THEN create_error_log(-20021, 'Symptons Required.', v_dependent_count);  END IF;
    IF v_service_dt IS NULL THEN create_error_log(-20021, 'Service Date is required.', v_dependent_count); END IF;
    IF l_benifit_type IN ('MTI', 'IMTI', 'IPT') THEN IF v_discharge IS NULL THEN create_error_log(-20021, 'Discharge date is  Required to upload a claim.', v_dependent_count);    END IF;  END IF;



    IF l_benifit_type IS NULL OR v_benefit_type IS NULL OR l_benifit_type NOT IN ('IPT','OPTS','OPTC ','OMTI', 'IMTI', 'MTI', 'DNTL', 'HEAC', 'DAYC', 'OPTC') THEN
      create_error_log(-20021, 'Benefit Type is Required/ Benifit_Type format is not correct', v_dependent_count);
    END IF;
    
    IF v_encounter_type IS NULL OR trim(v_encounter_type) NOT IN ('IP EMERGENCY', 'IP NO-EMERGENCY','OP EMERGENCY', 'OP NO-EMERGENCY') THEN
      create_error_log(-20021, 'Encounter Type is Required/ Encounter_Type format is not correct', v_dependent_count);
    END IF;
  
 
 -- Dr. Yasmin
  /*IF v_clinician_id IS NOT NULL THEN
    select count(md.contact_seq_id) into v_clin_id_cnt
    from tpa_hosp_professionals md
    where md.hosp_seq_id = v_hosp_seq_id
    and md.professional_id = trim(v_clinician_id);
    
    IF v_clin_id_cnt = 0 THEN
      err_parm := '-20021';
      create_error_log(-20021, 'Invalid Clinician ID for Claim', v_dependent_count);
    END IF;
    
  END IF;*/

  

    IF v_invoice_num IS NOT NULL THEN
      --SELECT count(1) INTO v_spec_char_cnt FROM dual WHERE v_invoice_num = regexp_replace(v_invoice_num,'[^[:alnum:]/-]');
       SELECT count(1) INTO v_spec_char_cnt FROM dual WHERE NOT regexp_like(v_invoice_num, '[.,;&'']'); 
      IF v_spec_char_cnt = 0 THEN
        --create_error_log(-20021, 'Special character not allowed for Invoice Number .', v_dependent_count);
        create_error_log(-20021, '.,;&'' not allowed for Invoice Number .', v_dependent_count);
      END IF;
    END IF;
  
  ---------------------- DATE VALIDATION--------------------
    IF v_hospitalization IS NOT NULL AND (substr(trim(v_hospitalization), 1, 5) = '29-02' OR substr(trim(v_hospitalization), 1, 5) = '29/02') THEN
      v_leap_year := fn_leap_year(trim(v_hospitalization));
      IF v_leap_year = 0 THEN
        create_error_log(-20021, v_hospitalization||' (Date of Treatment) is not a leap year ', v_dependent_count);
      END IF;
    END IF;
  
  /*IF v_leap_year != 0  THEN
    IF TO_DATE(trim(v_hospitalization), 'DD-MM-RRRR') > TO_DATE(SYSDATE, 'DD-MM-RRRR') THEN
      create_error_log(-20021, 'Date should be less than or equal to Current Date', v_dependent_count);
    END IF;
  END IF;*/
  
    IF v_discharge IS NOT NULL AND (substr(trim(v_discharge), 1, 5) = '29-02' OR substr(trim(v_discharge), 1, 5) = '29/02') THEN --(length(substr(v_discharge, (instr(v_discharge, '-', 1, 2) + 1))) = 4 OR length(substr(v_discharge, (instr(v_discharge, '/', 1, 2) + 1))) = 4) AND (substr(v_discharge, 1, 5) = '29-02' OR substr(v_discharge, 1, 5) = '29/02') THEN  
      v_leap_year := fn_leap_year(trim(v_discharge));
      IF v_leap_year = 0 THEN
      create_error_log(-20021, v_discharge||' (Discharge Date) is not a leap year ', v_dependent_count);
      END IF;
    END IF;
    
    IF nvl(v_leap_year, 0) != 1 THEN
      IF TO_DATE(trim(v_hospitalization), 'DD-MM-RRRR') > TO_DATE(trim(v_discharge), 'DD-MM-RRRR') THEN
        create_error_log(-20021, 'Date of Discharge cannot be less than Date of Treatment/Admission.', v_dependent_count);
      END IF;
    END IF;
  
    IF v_service_dt IS NOT NULL AND (substr(trim(v_service_dt), 1, 5) = '29-02' OR substr(trim(v_service_dt), 1, 5) = '29/02') THEN--(length(substr(v_service_dt, (instr(v_service_dt, '-', 1, 2) + 1))) = 4 OR length(substr(v_service_dt, (instr(v_service_dt, '/', 1, 2) + 1))) = 4) AND (substr(v_service_dt, 1, 5) = '29-02' OR substr(v_service_dt, 1, 5) = '29/02') THEN  
      v_leap_year := fn_leap_year(trim(v_service_dt));
      IF v_leap_year = 0 THEN
      create_error_log(-20021, v_service_dt||' (Service Date) is not a leap year ', v_dependent_count);
      END IF;
    END IF;
  
  /*IF v_service_dt IS NOT NULL AND (substr(trim(v_service_dt), 1, 5) != '29-02' OR substr(trim(v_service_dt), 1, 5) != '29/02') THEN
    IF nvl(v_leap_year, 0) != 1 THEN
      IF TO_DATE(trim(v_service_dt), 'DD-MM-RRRR') > TO_DATE(trim(sysdate), 'DD-MM-RRRR') THEN
        create_error_log(-20021, 'Service Date cannot be future date.', v_dependent_count);
      END IF;
    END IF;
  END IF;*/
  
  /*IF v_hospitalization IS NOT NULL AND (substr(trim(v_hospitalization), 1, 5) != '29-02' OR substr(trim(v_hospitalization), 1, 5) != '29/02') THEN
    IF nvl(v_leap_year, 0) != 1 THEN
      IF TO_DATE(trim(v_hospitalization), 'DD-MM-RRRR') > TO_DATE(trim(sysdate), 'DD-MM-RRRR') THEN
        create_error_log(-20021, 'Treatment cannot be future date.', v_dependent_count);
      END IF;
    END IF;
  END IF;*/

    IF v_first_ins_dt IS NOT NULL  AND (substr(v_first_ins_dt, 1, 5) = '29-02' OR substr(v_first_ins_dt, 1, 5) = '29/02') THEN  
      v_leap_year := fn_leap_year(trim(v_first_ins_dt));
      IF v_leap_year = 0 THEN
      create_error_log(-20021, v_first_ins_dt||' (First Incident Date) is not a leap year ', v_dependent_count);
      END IF;
    END IF;
  
    IF v_first_report_dt IS NOT NULL /*(length(substr(v_first_report_dt, (instr(v_first_report_dt, '-', 1, 2) + 1))) = 4 OR length(substr(v_first_report_dt, (instr(v_first_report_dt, '/', 1, 2) + 1))) = 4)*/ AND substr(v_first_report_dt, 1, 5) = '29-02' OR substr(v_first_report_dt, 1, 5) = '29/02' THEN  
      v_leap_year := fn_leap_year(trim(v_first_report_dt));
      IF v_leap_year = 0 THEN
      create_error_log(-20021, v_first_report_dt||' (First  Reported Date) is not a leap year ', v_dependent_count);
      END IF;
    END IF;
  ----------------------------
   IF v_tooth_no IS NOT NULL THEN
     select count(1) into v_spec_char_cnt -- 1 ('1,2;3')
     from dual
     where regexp_like(v_tooth_no,'[[:punct:]]'); 
      
     IF v_spec_char_cnt > 0 THEN
       SELECT count(1) INTO v_tooth_count --0 ('1,2;3')
       FROM dual 
       WHERE trim(v_tooth_no) = regexp_replace(trim(v_tooth_no),'[^[:alnum:],]');
       
       IF v_tooth_count = 0 THEN
         create_error_log(-20021, 'Tooth number should be comma(,) format', v_dependent_count);
       END IF;
     END IF;      
   END IF;
  --SK
  /*IF l_benifit_type = 'DNTL' THEN
    OPEN chk_act_cur(v_inter_ser_code,v_hosp_seq_id);
    FETCH chk_act_cur INTO v_mstr_act_code;
    CLOSE chk_act_cur;
    
    OPEN chk_dntl_cur(v_mstr_act_code);
    FETCH chk_dntl_cur INTO v_tooth_req_yn;
    CLOSE chk_dntl_cur;
    
    IF v_tooth_req_yn = 'Y' AND v_tooth_no IS NULL THEN create_error_log(-20021, 'Tooth no Required .', v_dependent_count);    END IF;

    
    IF v_tooth_no IS NOT NULL THEN
      select count(1) into v_spec_char_cnt -- 1 ('1,2;3')
      from dual
      where   regexp_like(v_tooth_no,'[[:space:]]')
      or regexp_like(v_tooth_no,'[[:punct:]]'); 
      
      IF v_spec_char_cnt > 0 THEN
        SELECT count(1) INTO v_tooth_count --0 ('1,2;3')
        FROM dual 
        WHERE trim(v_tooth_no) = regexp_replace(trim(v_tooth_no),'[^[:alnum:],]');

      END IF;      
    END IF;

    
    IF v_tooth_no IS NOT NULL AND v_tooth_req_yn  = 'Y' THEN
      IF v_spec_char_cnt > 0 THEN
        IF v_tooth_count = 0 THEN
          create_error_log(-20021, 'Require '','' for multiple tooth number .', v_dependent_count);
        ELSE
          str_tab := ttk_util_pkg.parse_str(trim(replace('|'||v_tooth_no||'|', ',', '|')));
          for toothCode in str_tab.first.. str_tab.last loop
            v_tooth_num_chk := str_tab(toothCode);
            OPEN chk_tooth_cur(v_tooth_num_chk);
            FETCH chk_tooth_cur INTO chk_tooth_rec;
            CLOSE chk_tooth_cur;
            
            IF nvl(chk_tooth_rec, 'NA') != (v_tooth_num_chk) THEN
              create_error_log(-20021,v_tooth_num_chk||' tooth number is not valid .', v_dependent_count);
            END IF;

          end loop;

        END IF;

      ELSE
        IF v_tooth_no IS NOT NULL THEN
          str_tab := ttk_util_pkg.parse_str(trim(replace('|'||v_tooth_no||'|', ',', '|')));
          for toothCode in str_tab.first.. str_tab.last loop
            v_tooth_num_chk := str_tab(toothCode);
            OPEN chk_tooth_cur(v_tooth_num_chk);
            FETCH chk_tooth_cur INTO chk_tooth_rec;
            CLOSE chk_tooth_cur;
              
            IF nvl(chk_tooth_rec, 'NA') != (v_tooth_num_chk) THEN
              create_error_log(-20021,v_tooth_num_chk||' tooth number is not valid .', v_dependent_count);
            END IF;

          end loop;

        END IF;

      END IF;

    END IF;    
    
  END IF;*/
  
  --Date of LMP
  
    IF l_benifit_type IN ('OMTI', 'IMTI', 'MTI') THEN
      IF v_lmp_date IS NOT NULL /*(length(substr(v_lmp_date, (instr(v_lmp_date, '-', 1, 2) + 1))) = 4 OR length(substr(v_lmp_date, (instr(v_lmp_date, '/', 1, 2) + 1))) = 4)*/ AND (substr(v_lmp_date, 1, 5) = '29-02' OR substr(v_lmp_date, 1, 5) = '29/02') THEN  
        v_leap_year := fn_leap_year(trim(v_lmp_date));
        IF NVL(v_leap_year, 0) != 1 THEN
           create_error_log(-20021, v_lmp_date||' Date of LMP is not a leap year ', v_dependent_count);
        END IF;
      END IF;

    END IF;
  
    /*IF l_benifit_type IN ('OMTI', 'IMTI', 'MTI') THEN
      IF v_lmp_date IS NOT NULL AND (substr(trim(v_lmp_date), 1, 5) != '29-02' OR substr(trim(v_lmp_date), 1, 5) != '29/02') THEN
        IF nvl(v_leap_year, 0) != 1 THEN
          IF TO_DATE(trim(v_lmp_date), 'DD-MM-RRRR') > TO_DATE(trim(v_hospitalization), 'DD-MM-RRRR') THEN
            create_error_log(-20021, 'Date of LMP cannot be greater than Treatment date.', v_dependent_count);
          END IF;
        END IF;

      END IF;
    END IF;*/
  --Dr. Yasmin
  /*IF l_benifit_type IN ('OMTI', 'IMTI', 'MTI') THEN
    IF v_con_nature IS NULL THEN
      create_error_log(-20021, 'Nature of Conception can not be blank .', v_dependent_count);
    END IF;
  END IF;*/

  
    IF v_service_desc IS NULL THEN
        create_error_log(-20021, 'Service Description can not be blank .', v_dependent_count);
    END IF;
  
    OPEN hosp_cur(v_hosp_seq_id);
    FETCH hosp_cur INTO hosp_rec;
    CLOSE hosp_cur;
  
  
    open pol_mem_cur(v_mem_id, v_hospitalization);
    fetch pol_mem_cur into pol_mem_rec;
    close pol_mem_cur;
    ----
    open exist_mem_cur(v_mem_id);
    fetch exist_mem_cur into exist_mem_rec;
    close exist_mem_cur;    
  
    OPEN pat_cur(v_pre_auth_num);
    FETCH pat_cur INTO pat_rec;
    CLOSE pat_cur;
  
  ---Event No
    IF v_event_no IS NOT NULL THEN
        SELECT count(1) INTO v_qnt_cnt FROM DUAL
        WHERE v_event_no = regexp_replace(v_event_no,'[^[:alnum:]]');
        --REGEXP_LIKE(v_event_no, '^\d+(\\d+)?$', '');
      
        IF v_qnt_cnt = 0 THEN
          err_parm := '-20021';
          create_error_log(-20021, 'Event Number should be number format .', v_dependent_count);
        END IF;
        
      SELECT length(trim(v_event_no)) INTO v_event_len
      FROM DUAL;
        
      IF v_event_len != 7 THEN
        err_parm := '-20021';
        create_error_log(-20021, 'Event reference Number should be 7 digits .', v_dependent_count);
      END IF;

      
      select rpad((s.LAST_NUMBER - 1), 7, 0) INTO v_event_num
      from all_sequences s
      where s.SEQUENCE_NAME = UPPER('event_ref_no_seq')
      and s.SEQUENCE_OWNER = 'APP';
      
      IF v_event_num < trim(v_event_no) THEN
        create_error_log(-20021, 'Given Event Number is not valid.', v_dependent_count);
      END IF;
    END IF;
    
  --Claim-----
    OPEN clin_name_cur(v_clinician_id,v_hosp_seq_id);
    FETCH clin_name_cur INTO clin_name_rec;
    CLOSE clin_name_cur;
  
    clm_rec.claim_id := null;
    clm_rec.tpa_enrollment_id:= v_mem_id;
    clm_rec.member_seq_id := nvl(pol_mem_rec.member_seq_id, exist_mem_rec.member_seq_id);
    --clm_hosp_rec.provider_id := hosp_rec.Empanel_Number;
    clm_rec.emirate_id := pol_mem_rec.emirate_id;
    --clm_rec.tot_gross_amount := v_tot_req_amt;
    clm_rec.tot_patient_share_amount := 0;
    --clm_rec.tot_net_amount := v_tot_req_amt;
    clm_rec.encounter_facility_id := null;
    
    IF clm_rec.member_seq_id IS NULL THEN
      create_error_log(-20021, 'Invalid Member ID', v_dependent_count);
    END IF;
  
    IF l_benifit_type IN ('IMTI', 'OMTI', 'OPTC', 'DNTL') THEN
      l_benifit_type := CASE WHEN l_benifit_type = 'IMTI' THEN 'IPT'
                             WHEN l_benifit_type = 'OMTI' THEN 'OPTS'
                             WHEN l_benifit_type = 'OPTC' AND substr(trim(v_encounter_type), 1, 2) = 'OP' THEN 'OPTS'
                             --WHEN l_benifit_type = 'OPTC' AND substr(trim(v_encounter_type), 1, 2) = 'IP' THEN 'IPT'
                             WHEN l_benifit_type = 'DNTL' AND substr(trim(v_encounter_type), 1, 2) = 'OP' THEN 'OPTS'
                             WHEN l_benifit_type = 'DNTL' AND substr(trim(v_encounter_type), 1, 2) = 'IP' THEN 'IPT'
                         END;
    END IF;
  
    OPEN encounter_cur (l_benifit_type, l_encounter_type);
    FETCH encounter_cur INTO v_encounter_seq_id;
    CLOSE encounter_cur;
  
 
    OPEN act_cur(v_act_code);
    FETCH act_cur INTO act_rec;
    CLOSE act_cur;
  
    IF v_activity_type_id='Drug' THEN
      act_rec.unit_price:=(v_act_req_amt)/(v_act_qnt);
    END IF;
  END IF;

IF v_activity_type_id='Drug' THEN
    act_rec.unit_price:=(v_act_req_amt)/(v_act_qnt);
END IF;
  
     IF v_activity_type_id='Activity' THEN
        IF v_act_code IS NOT NULL THEN
          IF act_rec.activity_code IS NULL THEN
            err_parm := '-20021';
            create_error_log(-20021, 'Invalid  Activity Code.', v_dependent_count);
          END IF;
        END IF;
     END IF; 
   
     IF v_pre_auth_num IS NULL THEN
         clm_rec.encounter_type_id := v_encounter_seq_id;
         clm_rec.benifit_type := l_benifit_type1;
       IF v_upload_error_message IS NULL THEN
         clm_rec.date_of_hospitalization := to_date(v_hospitalization, 'DD-MM-RRRR');
         clm_rec.date_of_discharge := to_date(nvl(v_discharge,v_hospitalization), 'DD-MM-RRRR');
         clm_rec.lmp_date := to_date(v_lmp_date, 'DD-MM-RRRR');
       END IF;
     END IF;
  
     clm_batch_rec.transaction_date := to_date(sysdate, 'DD-MM-RRRR');
   --clm_rec.encounter_start_type := v_encounter_seq_id;
   --clm_rec.encounter_end_type := v_encounter_seq_id;
     clm_rec.id_payer:= pol_mem_rec.ins_seq_id;
     clm_rec.auth_number := pat_rec.auth_number;
  
  
    OPEN  cur_ins_info;
    FETCH cur_ins_info INTO v_tpa_ins_seq_id;
    CLOSE cur_ins_info;
   
  
    IF v_tariff_count>0 THEN 
      v_tariff_ins_seq_id:=clm_tariff_rec.Ins_Seq_Id;
    ELSE 
      v_tariff_ins_seq_id:=v_tpa_ins_seq_id;
    END IF;   
   
    OPEN clm_details_cur(v_hosp_seq_id,v_invoice_num);
    FETCH clm_details_cur INTO clm_details_rec;
    CLOSE clm_details_cur;
    
      
    -- Check Condition for Claim without preauth
      IF v_pre_auth_num IS NULL THEN
        
        OPEN diagnosys_cur(v_invoice_num);
        FETCH diagnosys_cur INTO diagnosys_rec;
        CLOSE diagnosys_cur;
        
        /*OPEN clm_all_diag_cur(v_invoice_num);
        FETCH clm_all_diag_cur INTO all_diag_rec;
        CLOSE clm_all_diag_cur;*/
        
        --v_icd := UPPER(trim(trailing ',' from (v_secn_diag_code1||','||v_secn_diag_code2||','||v_secn_diag_code3||','||v_secn_diag_code4||','||v_secn_diag_code5)));
        
          IF trim(clm_details_rec.invoice_number) = trim(v_invoice_num) AND
             trim(clm_details_rec.tpa_enrollment_id) = trim(v_mem_id) AND
             trim(clm_details_rec.date_of_hospitalization) = trim(clm_rec.date_of_hospitalization) AND
             trim(clm_details_rec.benifit_type) = trim(l_benifit_type1) AND
             trim(clm_details_rec.encounter_type_id) = trim(v_encounter_seq_id) AND
             trim(clm_details_rec.clm_batch_seq_id) = trim(v_batch_seq_id) AND
             --UPPER(clm_details_rec.mem_name) = UPPER(v_mem_name) AND
             trim(clm_details_rec.system_of_medicine_type_id) = trim(v_sys_of_medicine) AND
             diagnosys_rec.prim_diag_code IN (v_prim_diag_code) THEN
             --diagnosys_rec.diag_code IN (v_icd) AND 
             --trim(clm_details_rec.presenting_complaints) = v_sympton THEN
               v_count2 := 1;
          ELSE
            v_count2 := 0;
            
            IF trim(clm_details_rec.invoice_number) = trim(v_invoice_num) THEN
              
              IF trim(clm_details_rec.tpa_enrollment_id) != trim(v_mem_id) THEN
                create_error_log(-20021, 'MEMBER ID should be same for '||v_invoice_num||' Invoce Number', v_dependent_count);
              END IF;
              
              IF trim(clm_details_rec.benifit_type) != trim(l_benifit_type1) THEN
                create_error_log(-20021, 'Benifit Type ID should be same for '||v_invoice_num||' Invoce Number', v_dependent_count);
              END IF;
              
              IF trim(clm_details_rec.encounter_type_id) != trim(v_encounter_seq_id) THEN
                create_error_log(-20021, 'Encounter Type ID should be same for '||v_invoice_num||' Invoce Number', v_dependent_count);
              END IF;
              
              IF trim(clm_details_rec.date_of_hospitalization) != trim(clm_rec.date_of_hospitalization) THEN
                create_error_log(-20021, 'DATE OF TREATMENT /ADMISSION should be same for '||v_invoice_num||' Invoce Number', v_dependent_count);
              END IF;
              
              IF trim(clm_details_rec.system_of_medicine_type_id) != trim(v_sys_of_medicine) THEN
                create_error_log(-20021, 'SYSTEM OF MEDICINE should be same for '||v_invoice_num||' Invoce Number', v_dependent_count);
              END IF;
              
              IF diagnosys_rec.prim_diag_code NOT IN (v_prim_diag_code) THEN
                create_error_log(-20021, 'Principal ICD should be same for '||v_invoice_num||' Invoce Number', v_dependent_count);
              END IF;
              
              /*IF (v_secn_diag_code1 IS NOT NULL OR v_secn_diag_code2 IS NOT NULL OR v_secn_diag_code3 IS NOT NULL OR v_secn_diag_code4 IS NOT NULL OR v_secn_diag_code5 IS NOT NULL) THEN
                IF all_diag_rec.diag_code NOT IN (v_icd) THEN
                 create_error_log(-20021, 'All Secondary ICD should be same for '||v_invoice_num||' Invoce Number', v_dependent_count);
                END IF;
              END IF;*/
              
              --SK
              /*IF trim(clm_details_rec.presenting_complaints) != v_sympton THEN
                create_error_log(-20021, 'Symptoms should be same for '||v_invoice_num||' Invoce Number', v_dependent_count);
              END IF;
              
              IF diagnosys_rec.diag_code NOT IN (v_icd) THEN
                create_error_log(-20021, 'All ICD should be same for '||v_invoice_num||' Invoce Number', v_dependent_count);
              END IF;*/
            END IF;
          END IF;
          
        IF v_count2 = 0 THEN
          SELECT COUNT(1) INTO v_batch_cnt
          FROM Clm_Authorization_Details c
          WHERE c.clm_batch_seq_id = v_batch_seq_id;
        END IF;
        -- If Event is assosiated with other Claim (For New Claim)
        /*select count(event_no) into v_event
        from clm_authorization_details c
        where c.event_no = trim(v_event_no)
        and c.invoice_number != trim(v_invoice_num);
      
        IF v_event > 0 THEN
          err_parm := '-20021';
          create_error_log(-20021, 'Event Number already associate with other Claim/ Pre Aproval .', v_dependent_count);
        END IF;*/
      --END IF;
    
    --- Preauth Number Validation for Existing Claim
    --IF v_pre_auth_num IS NOT NULL THEN
    ELSE
      OPEN pat_sts_cur(pat_rec.pat_auth_seq_id);
      FETCH pat_sts_cur INTO ststus_rec;
      CLOSE pat_sts_cur;
      
      SELECT COUNT(1) INTO v_auth_count
       FROM pat_authorization_details p
       WHERE p.pat_auth_seq_id = pat_rec.pat_auth_seq_id;

       
       IF v_auth_count = 0 THEN
         create_error_log(-20021, 'Preauth does not exist in database .', v_dependent_count);
       END IF;

       
       IF v_auth_count > 0 THEN
         SELECT COUNT(1) INTO v_auth_status
         FROM pat_authorization_details p
         WHERE p.pat_auth_seq_id = pat_rec.pat_auth_seq_id
         AND p.pat_status_type_id = 'APR';

       
         IF v_auth_status = 0 THEN
           create_error_log(-20021, 'PreApproval status is in Rejected/ Cancelled/ Inprogress .', v_dependent_count);
         END IF;

       END IF;

  
       IF v_auth_count > 0 THEN
         SELECT COUNT(1) INTO v_auth_hosp_count
         FROM pat_authorization_details p
         WHERE p.pat_auth_seq_id = pat_rec.pat_auth_seq_id
         AND p.hosp_seq_id = v_hosp_seq_id;

         
         IF v_auth_hosp_count = 0 THEN
           create_error_log(-20021, 'Provider is not matchig with Preauth Number- '||v_pre_auth_num||'.', v_dependent_count);
         END IF;

       END IF;

       
       IF v_auth_count > 0 THEN
         SELECT COUNT(1) INTO v_auth_mem_count
         FROM pat_authorization_details p
         WHERE p.pat_auth_seq_id = pat_rec.pat_auth_seq_id
         AND p.tpa_enrollment_id = v_mem_id;

         
         IF v_auth_mem_count = 0 THEN
           create_error_log(-20021, 'Member ID is not matchig with Preauth Number: '||v_pre_auth_num||'.', v_dependent_count);
         END IF;

       END IF;
    
       IF v_auth_count > 0 THEN
         SELECT COUNT(1) INTO v_assign_auth_count
         FROM clm_authorization_details c
         WHERE c.pat_auth_seq_id = pat_rec.pat_auth_seq_id
         AND c.claim_seq_id != nvl(ststus_rec.claim_seq_id, 0)
         AND c.clm_batch_seq_id != v_batch_seq_id;

         IF v_auth_count > 0 THEN
           IF v_assign_auth_count > 0 THEN
             create_error_log(-20021, 'Preauth is already assigned to other Claim .', v_dependent_count);
           END IF;

         END IF;

       END IF;

       
       -- If Event is not exist for linked Pre-Approval
       /*IF v_event_no IS NOT NULL THEN
         IF v_auth_count > 0 THEN
           Select count(p.event_no) Into v_pat_event_num
           From Pat_Authorization_Details p
           Where p.pat_auth_seq_id = pat_rec.pat_auth_seq_id;

            
           IF v_pat_event_num = 0 THEN
             create_error_log(-20021, 'Event Reference Number is not available for the given Pre-Approval Number', v_dependent_count);
           END IF;

      
           IF v_pat_event_num > 0 THEN
             Select count(p.event_no) Into v_event_num
             From Pat_Authorization_Details p
             Where p.pat_auth_seq_id = pat_rec.pat_auth_seq_id
             And p.event_no = v_event_no;

              
             IF v_event_num = 0 THEN
               create_error_log(-20021, 'Given Event Number is not matching with Pre Appoval.', v_dependent_count);
             END IF;

          END IF;

        END IF;
        
        select count(event_no) into v_event
        from clm_authorization_details c
        where c.event_no = trim(v_event_no)
        and c.invoice_number != pat_rec.pat_auth_seq_id;
    
        IF v_event > 0 THEN
          err_parm := '-20021';
          create_error_log(-20021, 'Event Number already associate with other Claim/ Pre Aproval .', v_dependent_count);
        END IF;
        v_event := null;
      END IF;*/
    
       --- Whether Claim is same or not based on Preauth Number
       OPEN pat_clm_cur(pat_rec.pat_auth_seq_id, v_batch_seq_id, v_mem_id, v_hosp_seq_id);
       FETCH pat_clm_cur INTO pat_clm_rec;
       CLOSE pat_clm_cur;
       
       OPEN pat_diagnosys_cur(pat_rec.pat_auth_seq_id);
       FETCH pat_diagnosys_cur INTO diagnosys_rec;
       CLOSE pat_diagnosys_cur;
       
       /*OPEN pat_all_diag_cur(pat_rec.pat_auth_seq_id);
       FETCH pat_all_diag_cur INTO all_diag_rec;
       CLOSE pat_all_diag_cur;*/
       
       --v_icd := UPPER(trim(trailing ',' from (v_prim_diag_code||','||v_secn_diag_code1||','||v_secn_diag_code2||','||v_secn_diag_code3||','||v_secn_diag_code4||','||v_secn_diag_code5)));
       
       IF pat_clm_rec.pre_auth_number = v_pre_auth_num AND
          pat_clm_rec.tpa_enrollment_id = v_mem_id AND
          --pat_clm_rec.system_of_medicine_type_id = v_sys_of_medicine AND
          pat_clm_rec.clm_batch_seq_id = v_batch_seq_id AND
          --pat_clm_rec.presenting_complaints = v_sympton AND
          diagnosys_rec.prim_diag_code IN (v_prim_diag_code) THEN
            v_count2 := 1;
            --v_invoice_num := case when instr(pat_clm_rec.invoice_number, v_invoice_num) = 0 then pat_clm_rec.invoice_number||', '||v_invoice_num else nvl(pat_clm_rec.invoice_number, v_invoice_num) end ;
       ELSE
         v_count2 := 0;
         IF pat_clm_rec.pre_auth_number = v_pre_auth_num THEN
           IF pat_clm_rec.tpa_enrollment_id != v_mem_id THEN
             create_error_log(-20021, 'Member should be same as pre PreAppoval Number -'||v_pre_auth_num||'.', v_dependent_count);
           END IF;

           
           /*IF pat_clm_rec.system_of_medicine_type_id != v_sys_of_medicine THEN
             create_error_log(-20021, 'System of Medicine should be same as pre PreAppoval Number -'||v_pre_auth_num||'.', v_dependent_count);
           END IF;*/

           
           IF diagnosys_rec.prim_diag_code NOT IN (v_prim_diag_code) THEN
             create_error_log(-20021, 'All Principal ICD should be same for Preapproval Number - '||v_pre_auth_num, v_dependent_count);
           END IF;

            /*IF (v_secn_diag_code1 IS NOT NULL OR v_secn_diag_code2 IS NOT NULL OR v_secn_diag_code3 IS NOT NULL OR v_secn_diag_code4 IS NOT NULL OR v_secn_diag_code5 IS NOT NULL) THEN
              IF all_diag_rec.diag_code NOT IN (v_icd) THEN
               create_error_log(-20021, 'All Secondary ICD should be same for '||v_invoice_num||' Invoce Number', v_dependent_count);
              END IF;
            END IF;*/
            
           --SK
           /*IF pat_clm_rec.presenting_complaints != v_sympton THEN
             create_error_log(-20021, 'Symptoms should be same as pre PreAppoval Number -'||v_pre_auth_num||'.', v_dependent_count);
           END IF;
           
           IF diagnosys_rec.diag_code NOT IN (v_icd) THEN
             create_error_log(-20021, ' All ICD should be same as pre PreAppoval Number -'||v_pre_auth_num||'.', v_dependent_count);
           END IF;*/
         ELSE
           --Check Preauth for Duplicate Invoice for same hospital
           clm_rec.date_of_hospitalization := nvl(pat_rec.hospitalization_date, v_hospitalization);
           clm_rec.date_of_discharge       := pat_rec.discharge_date;
           clm_rec.benifit_type            := pat_rec.benifit_type;
           clm_rec.encounter_type_id       := pat_rec.encounter_type_id;
           clm_rec.lmp_date                := pat_rec.lmp_date;
           v_sys_of_medicine               := pat_rec.system_of_medicine_type_id;
           l_con_nature                    := pat_rec.conception_type;
           --clm_rec.member_seq_id           := pat_rec.member_seq_id;
         END IF;
       END IF; 
    END IF;
    
    -- Check Duplicate Invoice
    
      With HOSP_IVOICE_DATA As
    (Select ','||CA.INVOICE_NUMBER||',' As INVOICE_NUMBER
     From APP.CLM_AUTHORIZATION_DETAILS CA
     Join APP.CLM_HOSPITAL_DETAILS H On (CA.CLAIM_SEQ_ID=H.CLAIM_SEQ_ID)
     Where  H.HOSP_SEQ_ID = v_hosp_seq_id
     and ca.clm_batch_seq_id != v_batch_seq_id
    )
    Select count(1) into v_cnt1
    From HOSP_IVOICE_DATA
    Where INVOICE_NUMBER LIKE '%,'||trim(v_invoice_num)||',%';
     
    IF v_cnt1 > 0 THEN
      create_error_log(-20021, 'Invoice Number -'||v_invoice_num||' is already uploaded for this provider.', v_dependent_count);
    END IF;
    ----
    IF v_pre_auth_num IS NOT NULL THEN
      With HOSP_IVOICE_DATA As
    (Select ','||CA.INVOICE_NUMBER||',' As INVOICE_NUMBER
     From APP.CLM_AUTHORIZATION_DETAILS CA
     Join APP.CLM_HOSPITAL_DETAILS H On (CA.CLAIM_SEQ_ID=H.CLAIM_SEQ_ID)
     Where  H.HOSP_SEQ_ID = v_hosp_seq_id
     and ca.clm_batch_seq_id = v_batch_seq_id
     and ca.pat_auth_seq_id != pat_rec.pat_auth_seq_id
    )
    Select count(1) into v_cnt
    From HOSP_IVOICE_DATA
    Where INVOICE_NUMBER LIKE '%,'||trim(v_invoice_num)||',%'
    and v_pre_auth_num is not null;
        
      IF v_cnt > 0 THEN
        create_error_log(-20021, 'Invoice Number -'||v_invoice_num||' has linked two different pre-auth in the same batch, Hence unable to upload the claim.', v_dependent_count);
      END IF; 
      
      -- If PreAuth is linked to other claim in different Batch
      select count(1) into v_cnt
      from clm_authorization_details c
      left join clm_hospital_details ch on (c.claim_seq_id = ch.claim_seq_id)
      where c.clm_batch_seq_id != v_batch_seq_id
      and c.pat_auth_seq_id = pat_rec.pat_auth_seq_id
      and v_pre_auth_num is not null;
          
      IF v_cnt > 0 THEN
        create_error_log(-20021, 'Preapproval -'||v_pre_auth_num||' has linked for Claim Number: '||ststus_rec.claim_number||' in different batch, Hence unable to upload the claim.', v_dependent_count);
      END IF; 
    END IF;
    ---- Invoice--- 
    IF v_count2 = 0 THEN
      IF v_pre_auth_num IS NULL THEN
           With HOSP_IVOICE_DATA As
           (Select ','||CA.INVOICE_NUMBER||',' As INVOICE_NUMBER
           From APP.CLM_AUTHORIZATION_DETAILS CA
           Join APP.CLM_HOSPITAL_DETAILS H On (CA.CLAIM_SEQ_ID=H.CLAIM_SEQ_ID)
           Where  H.HOSP_SEQ_ID = v_hosp_seq_id
           and ca.clm_batch_seq_id = v_batch_seq_id
          )
          Select count(1) into v_cnt
          From HOSP_IVOICE_DATA
          Where INVOICE_NUMBER LIKE '%,'||trim(v_invoice_num)||',%'
          and v_pre_auth_num is null;
          
          IF v_cnt > 0 THEN
            create_error_log(-20021, 'Invoice Number -'||v_invoice_num||' Can not be duplicate for same batch.', v_dependent_count);
          END IF;
      END IF;
      
      IF v_pre_auth_num IS NOT NULL THEN
          select count(1) into v_cnt
          from clm_authorization_details c
          left join clm_hospital_details ch on (c.claim_seq_id = ch.claim_seq_id)
          where c.pat_auth_seq_id = pat_rec.pat_auth_seq_id
          and c.clm_batch_seq_id != v_batch_seq_id
          and v_pre_auth_num is not null;
          
          IF v_cnt > 0 THEN
            create_error_log(-20021, 'Pre-approval no. '||v_pre_auth_num||' has linked to for claim no.: '||ststus_rec.claim_number|| 'in another batch,hence unable to process this claim.', v_dependent_count);
          END IF;
      END IF;      
    END IF; 
    --------Duplicate Invoice End
    
    --Diagnosys
    IF v_prim_diag_code IS NOT NULL THEN
      diag_record.icd10_seq_id := null;
      OPEN diag_cur(v_prim_diag_code);
      FETCH diag_cur INTO diag_record;
      CLOSE diag_cur;
        
      IF diag_record.icd10_seq_id IS NULL THEN
        create_error_log(-20021, v_prim_diag_code||' Principal ICD Code is not valid.', v_dependent_count);
      END IF;

    END IF;

    
    IF v_secn_diag_code1 IS NOT NULL THEN
      diag_record.icd10_seq_id := null;
      OPEN diag_cur(v_secn_diag_code1);
      FETCH diag_cur INTO diag_record;
      CLOSE diag_cur;
        
      IF diag_record.icd10_seq_id IS NULL THEN
        create_error_log(-20021, v_secn_diag_code1||' Secondary ICD Code is not valid.', v_dependent_count);
      END IF;

    END IF;

    
    IF v_secn_diag_code2 IS NOT NULL THEN
      diag_record.icd10_seq_id := null;
      OPEN diag_cur(v_secn_diag_code2);
      FETCH diag_cur INTO diag_record;
      CLOSE diag_cur;
        
      IF diag_record.icd10_seq_id IS NULL THEN
        create_error_log(-20021, v_secn_diag_code2||' Secondary ICD Code is not valid.', v_dependent_count);
      END IF;

    END IF;

    
    IF v_secn_diag_code3 IS NOT NULL THEN
      diag_record.icd10_seq_id := null;
      OPEN diag_cur(v_secn_diag_code3);
      FETCH diag_cur INTO diag_record;
      CLOSE diag_cur;
        
      IF diag_record.icd10_seq_id IS NULL THEN
        create_error_log(-20021, v_secn_diag_code3||' Secondary ICD Code is not valid.', v_dependent_count);
      END IF;

    END IF;

    
    IF v_secn_diag_code4 IS NOT NULL THEN
      diag_record.icd10_seq_id := null;
      OPEN diag_cur(v_secn_diag_code4);
      FETCH diag_cur INTO diag_record;
      CLOSE diag_cur;
        
      IF diag_record.icd10_seq_id IS NULL THEN
        create_error_log(-20021, v_secn_diag_code4||' Secondary ICD Code is not valid.', v_dependent_count);
      END IF;

    END IF;

    
    IF v_secn_diag_code5 IS NOT NULL THEN
      diag_record.icd10_seq_id := null;
      OPEN diag_cur(v_secn_diag_code5);
      FETCH diag_cur INTO diag_record;
      CLOSE diag_cur;
        
      IF diag_record.icd10_seq_id IS NULL THEN
        create_error_log(-20021, v_secn_diag_code5||' Secondary ICD Code is not valid.', v_dependent_count);
      END IF;

    END IF;
    
    ---Benefit With ICD
    IF v_count2 = 0 THEN
      OPEN benefit_cur(v_prim_diag_code);
      FETCH benefit_cur INTO v_icd_benefit;
      CLOSE benefit_cur;
      
      IF v_icd_benefit.benefit_type = 'DNTL' THEN
        IF v_icd_benefit.benefit_type !=  nvl(l_benifit_type1, l_benifit_type) THEN
          create_error_log(-20021, 'Ailment does not belogs to the selected benefit type, please select Dental benefit type.', v_dependent_count);
        END IF;
      END IF;
    END IF;    
    --*******************  
    --Activity 
    IF v_activity_type_id='Activity' THEN
     -------Check Internal Code Detials is Valid or not--------------
       IF v_inter_ser_code IS NOT NULL THEN
         select count(m.activity_code) into v_count3
          from tpa_activity_master_details m
          where m.act_mas_dtl_seq_id = 
               (
                select distinct t.activity_seq_id 
                from tpa_hosp_tariff_details t
                where t.hosp_seq_id = v_hosp_seq_id
                and UPPER(t.internal_code) = UPPER(trim(v_inter_ser_code))
               );
               
           IF v_count3 = 0 THEN
              create_error_log(-20021, 'Given Internal Code is not valid.', v_dependent_count);
           END IF;
         
       
           IF v_count3 > 0 THEN
              IF v_upload_error_message IS NULL THEN
                IF v_act_code is null and v_inter_ser_code is not null then
                  select count(m.activity_code) into v_activity_count
                  from tpa_activity_master_details m
                  where m.act_mas_dtl_seq_id = 
                      (
                       select distinct t.activity_seq_id 
                       from tpa_hosp_tariff_details t
                       where t.hosp_seq_id = v_hosp_seq_id
                       and UPPER(t.internal_code) = UPPER(trim(v_inter_ser_code))
                       and to_date(trim(v_service_dt), 'DD-MM-RRRR') between trunc(t.start_date) and trunc(nvl(t.end_date, sysdate))
                      );
              
                ELSIF v_act_code is not null and v_inter_ser_code is not null then
                  select count(m.activity_code) into v_activity_count
                  from tpa_activity_master_details m
                  where m.act_mas_dtl_seq_id = 
                      (
                      select distinct t.activity_seq_id 
                      from tpa_hosp_tariff_details t
                      where t.hosp_seq_id = v_hosp_seq_id
                      and UPPER(t.internal_code) = UPPER(trim(v_inter_ser_code))---------=======
                      and to_date(trim(v_service_dt), 'DD-MM-RRRR') between trunc(t.start_date) and trunc(nvl(t.end_date, sysdate))
                      )
                    and m.activity_code = trim(v_act_code);
                END IF;
             
             IF v_activity_count = 0 THEN
                create_error_log(-20021, 'Activity Code/ Internal Code is not valid as per admission date with uploaded Tariff.', v_dependent_count);
             ELSE
               IF v_upload_error_message IS NULL THEN        
                 select m.activity_code, m.act_mas_dtl_seq_id into v_activity_code, v_activity_type_seq_id
                  from tpa_activity_master_details m
                  where m.act_mas_dtl_seq_id = 
                        (
                         select distinct t.activity_seq_id 
                         from tpa_hosp_tariff_details t
                         where t.hosp_seq_id = v_hosp_seq_id
                         and UPPER(t.internal_code) = UPPER(trim(v_inter_ser_code))
                         and to_date(trim(v_service_dt), 'DD-MM-RRRR') between trunc(t.start_date) and trunc(nvl(t.end_date, sysdate))
                        );
                END IF;
             END IF;
           END IF;
        END IF;
      END IF;
   END IF;   
      --===========================     
      
    IF v_upload_error_message IS NULL THEN
      
      open batch_details(v_batch_seq_id);
      fetch batch_details into clm_batch_rec.received_date,clm_batch_rec.source_type_id;
      close batch_details;
      
      IF v_count2 = 0 THEN  
         v_clm_seq_id := null;
         begin  
          -- Update Batch Total Amount and Total Number of Batch
            Update clm_batch_upload_details b
            Set b.batch_tot_amount = nvl(b.batch_tot_amount, 0) + nvl(v_act_req_amt, 0),
                b.record_count     = nvl(b.record_count, 0) + 1
            Where b.clm_batch_seq_id = v_batch_seq_id; 
                
            
            
            
            clm_xml_load_pkg.save_clm_details( v_clm_seq_id,
                                         v_batch_seq_id,
                                         pat_rec.pat_auth_seq_id,
                                         clm_rec.parent_claim_seq_id,
                                         clm_rec.claim_number,
                                         clm_rec.claim_file_number,
                                         null,--clm_rec.settlement_number,
                                         clm_batch_rec.received_date,
                                         clm_batch_rec.source_type_id, 
                                         clm_rec.date_of_hospitalization, 
                                         nvl(clm_rec.date_of_discharge,clm_rec.date_of_hospitalization), 
                                         'CNH',
                                         clm_rec.claim_sub_type,  
                                         clm_rec.member_seq_id, 
                                         clm_rec.tpa_enrollment_id,
                                         pol_mem_rec.mem_name, 
                                         pol_mem_rec.mem_age,  
                                         pol_mem_rec.ins_seq_id, 
                                         pol_mem_rec.policy_seq_id,
                                         pol_mem_rec.enrol_type_id,
                                         pol_mem_rec.emirate_id, 
                                         --clm_rec.encounter_type_id,
                                         case when NVL(pat_rec.encounter_type_id, pat_rec.encounter_start_type) != v_encounter_seq_id then NVL(pat_rec.encounter_type_id, pat_rec.encounter_start_type) else clm_rec.encounter_type_id end,
                                         clm_rec.encounter_start_type,
                                         nvl(clm_rec.encounter_end_type,'1'), 
                                         clm_rec.encounter_facility_id, 
                                          null,--V_PAYER_ID
                                          pol_mem_rec.ava_sum_insured,--V_AVA_SUM_INSURED
                                          'QAR',--V_CURRENCY_TYPE
                                          'INP',--V_CLM_STATUS_TYPE_ID
                                          clm_rec.remarks,
                                          v_invoice_num,
                                          v_act_req_amt, --V_REQUESTED_AMOUNT
                                          nvl(nvl(clin_name_rec.professional_id,v_clinician_id),'NA'),
                                          v_sys_of_medicine,--V_SYSTEM_OF_MEDICINE_TYPE_ID
                                          null,--V_ACCIDENT_RELATED_TYPE_ID
                                          null,--V_PRIORITY_GENERAL_TYPE_ID
                                          'Y',--V_NETWORK_YN
                                          --clm_rec.benifit_type,
                                          case when pat_rec.benifit_type != l_benifit_type1 then pat_rec.benifit_type else clm_rec.benifit_type end,
                                          null,--V_GRAVIDA
                                          null,--V_PARA
                                          null,--V_LIVE
                                          null,--V_ABORTION
                                          v_sympton,--V_PRESENTING_COMPLAINTS
                                          null,--V_MEDICAL_OPINION_REMARKS
                                          v_hosp_seq_id,
                                          hosp_rec.hosp_name,
                                          hosp_rec.address_1,
                                          hosp_rec.city_type_id,
                                          hosp_rec.state_type_id,
                                          hosp_rec.pin_code,
                                          hosp_rec.off_phone_no_1,
                                          hosp_rec.office_fax_no,
                                          hosp_rec.Empanel_Number,
                                          clm_hosp_rec.country_type_id,
                                          nvl(nvl(clin_name_rec.contact_name,v_clinician_name),'NA'),
                                          1,
                                          v_type,
                                          v_commet,
                                          v_first_ins_dt,
                                          v_first_report_dt,
                                          nvl(clm_rec.lmp_date, v_lmp_date),
                                          l_con_nature,
                                          clm_rec.auth_number,
                                          1,
                                          v_event_no,
                                          v_row_processed);
                                              
                                              
              Update clm_authorization_details c
              Set c.converted_amount  =nvl(c.converted_amount, 0) + nvl(v_act_req_amt, 0)
              Where c.clm_batch_seq_id = v_batch_seq_id
              And c.invoice_number = trim(v_invoice_num)
              And c.claim_seq_id = v_clm_seq_id;
              
              authorization_pkg.reassign_user(null,'|'||v_clm_seq_id||'|',null,1,'AUT',v_seq_id_dum);
              
           exception
             when parent_not_found then
                create_error_log(-20021, 'Corrections to be made in other line items, Hence unable to process. ', v_dependent_count);
             when others then
                v_error_message := sqlerrm||CHR(10)||sqlcode;
                create_error_log(-20021, v_error_message, v_dependent_count);
           end;
      END IF;
        
     -- ICD and Activity
     IF v_count2 > 0 THEN
       IF v_pre_auth_num IS NULL THEN
         OPEN clm_seq_cur(v_invoice_num);
         FETCH clm_seq_cur INTO v_clm_seq_id;
         CLOSE clm_seq_cur;
       ELSE
         OPEN pat_clm_seq_cur(pat_rec.pat_auth_seq_id);
         FETCH pat_clm_seq_cur INTO v_clm_seq_id;
         CLOSE pat_clm_seq_cur;
       END IF;
      -- Update Batch Total Amount and Total Number of Batch
        Update clm_batch_upload_details b
        Set b.batch_tot_amount = nvl(b.batch_tot_amount, 0) + nvl(v_act_req_amt, 0)
        Where b.clm_batch_seq_id = v_batch_seq_id;
         
        Update clm_authorization_details c
        Set c.requested_amount = nvl(c.requested_amount, 0) + nvl(v_act_req_amt, 0),
            c.converted_amount  =nvl(c.requested_amount, 0) + nvl(v_act_req_amt, 0),
            c.presenting_complaints = case when c.presenting_complaints is null then v_sympton else c.presenting_complaints end
        Where c.clm_batch_seq_id = v_batch_seq_id
        And c.claim_seq_id = v_clm_seq_id;
        
        --Update Invoice Number is Preauth is not null
        IF v_pre_auth_num IS NOT NULL THEN
          Update clm_authorization_details c
          Set c.invoice_number = case when instr(c.invoice_number, v_invoice_num) = 0 then c.invoice_number||','||v_invoice_num else nvl(c.invoice_number, v_invoice_num) end
          Where c.claim_seq_id = v_clm_seq_id
          And c.pat_auth_seq_id = pat_rec.pat_auth_seq_id
          And c.clm_batch_seq_id = v_batch_seq_id;
        END IF;
        
     --END IF;
    END IF; 
     -- ICD
     -- ICD
     IF v_upload_error_message IS NULL THEN
       begin
         v_icdcode := case when v_prim_diag_code  is not null then v_prim_diag_code end||
                      case when v_secn_diag_code1 is not null then '|'||v_secn_diag_code1 end||
                      case when v_secn_diag_code2 is not null then '|'||v_secn_diag_code2 end||
                      case when v_secn_diag_code3 is not null then '|'||v_secn_diag_code3 end||
                      case when v_secn_diag_code4 is not null then '|'||v_secn_diag_code4 end||
                      case when v_secn_diag_code5 is not null then '|'||v_secn_diag_code5 end;
                      
         str_tab := ttk_util_pkg.parse_str('|'||v_icdcode||'|');
         
         for icdCode in str_tab.first.. str_tab.last loop
           open chk_diag_cur(v_clm_seq_id, str_tab(icdCode));
           fetch chk_diag_cur into chk_diag_rec;
           close chk_diag_cur;
           
           v_unq_icd := case when instr(nvl(chk_diag_rec.diag_code, 'NA'), str_tab(icdCode)) = 0 then str_tab(icdCode) end;
           
           if v_unq_icd is not null then
             diag_rec.icd_code_seq_id:=pat_xml_load_pkg.get_associated_id('ICD', str_tab(icdCode));
             diag_rec.diag_seq_id := 0;
             
             SELECT CASE WHEN TO_CHAR(COUNT(d.primary_ailment_yn)) = 0 THEN 'Y' ELSE 'N' END INTO diag_rec.primary_ailment_yn
                FROM Diagnosys_Details d
                WHERE d.claim_seq_id = v_clm_seq_id
                AND d.diagnosys_code = v_prim_diag_code;
                
             pat_xml_load_pkg.save_diagnosys_details(diag_rec.diag_seq_id ,
                                                     null,
                                                     v_clm_seq_id,
                                                     diag_rec.icd_code_seq_id,
                                                     v_unq_icd,
                                                     diag_rec.primary_ailment_yn,
                                                     1);
                                                     
         end if;
         select count(d.diagnosys_code) into v_icd_count from Diagnosys_Details d
           where d.claim_seq_id = v_clm_seq_id;
         exit when v_icd_count = 5;
       end loop;
       
       exception
         when parent_not_found then
           create_error_log(-20021, 'Corrections to be made in other line items, Hence unable to process. ', v_dependent_count);
         when others then
           v_error_message := sqlerrm||CHR(10)||sqlcode;
           create_error_log(-20021, v_error_message, v_dependent_count);            
       end;
      END IF;   
      --End ICD 
      ------------
      -- Activity     
      OPEN act_tariff_cur(v_hosp_seq_id, pol_mem_rec.ins_seq_id, hosp_rec.primary_network, v_activity_code, clm_rec.date_of_hospitalization,v_service_dt,v_inter_ser_code);
      FETCH act_tariff_cur INTO act_tariff_rec;
      CLOSE act_tariff_cur;
        
      v_type := null;  
      activity_rec.code := null;
      activity_rec.activity_seq_id := null;
      activity_rec.quantity := null;
      activity_rec.net_amount := null;
      activity_rec.clinician_id := null;
          
      v_type := act_rec.activity_type_seq_id;
      activity_rec.code := NVL(v_act_code, v_activity_code);
      activity_rec.activity_seq_id := v_activity_type_seq_id;
      activity_rec.quantity := v_act_qnt;
      activity_rec.net_amount := 0;
      activity_rec.clinician_id := clin_name_rec.professional_id;
      v_commet := null;
      activity_rec.unit_type := 1;
        
      activity_rec.Clinician_Remarks:=pat_xml_load_pkg.validate_clinician(v_hosp_seq_id,activity_rec.clinician_id); 
      activity_rec.activity_seq_id:=pat_xml_load_pkg.get_associated_id('ACT',activity_rec.code);
                      
        
      IF v_upload_error_message IS NULL THEN
        begin
          IF v_tooth_no IS NOT NULL THEN
            v_tooth_num := replace(v_tooth_no, ',', '|');
          END IF;
            
          IF v_upload_error_message IS NULL THEN
             pat_xml_load_pkg.save_activity_details(
                            activity_rec.activity_dtl_seq_id,
                            null,
                            v_clm_seq_id,
                            activity_rec.Activity_Seq_Id,
                            activity_rec.activity_id,
                            trim(v_act_qnt),
                            nvl(to_date(v_service_dt, 'DD-MM-RR'), to_date(act_tariff_rec.start_date, 'DD-MM-RR')),
                            act_tariff_rec.activity_type_id,
                            CASE WHEN v_activity_type_id='Activity' THEN activity_rec.code
                             WHEN v_activity_type_id='Drug' THEN NVL(v_act_code,'PHARMA') END,
                            activity_rec.unit_type,
                            activity_rec.modifier,
                            --act_tariff_rec.internal_code,
                            trim(v_inter_ser_code),
                            act_tariff_rec.package_id,
                            act_tariff_rec.bundle_id,
                            activity_rec.quantity,
                            act_tariff_rec.gross_amount* trim(v_act_qnt), --Gross Amount
                            act_tariff_rec.disc_amount * trim(v_act_qnt), -- Discount Amouont
                            (act_tariff_rec.gross_amount - act_tariff_rec.disc_amount) * trim(v_act_qnt), -- Disc Gross Amount
                            --case when v_activity_type_seq_id=5 then (((nvl(v_act_req_amt, act_tariff_rec.gross_amount))*(activity_rec.quantity))- nvl(act_tariff_rec.disc_amount, 0)) else v_act_req_amt end,
                            0,
                            activity_rec.copay_amount,
                            activity_rec.co_ins_amount,
                            activity_rec.deduct_amount,
                            activity_rec.out_of_pocket_amount,
                            v_act_req_amt,
                            activity_rec.allowed_amount,
                            activity_rec.clinician_id,
                            'Y',
                            activity_rec.denial_code,
                            activity_rec.remarks,
                            activity_rec.Clinician_Remarks,
                            act_rec.unit_price, --Unit_Price
                            1,
                            activity_rec.PRIOR_AUTHID,
                            trim(v_tooth_num),
        CASE WHEN v_activity_type_id='Activity' THEN act_tariff_rec.internal_desc
                                 WHEN v_activity_type_id='Drug' THEN v_service_desc  END,
                            v_activity_type_id,
                            act_tariff_rec.gross_amount,
                            v_act_req_amt,
                            act_tariff_rec.disc_amount
                            );
                                        
              
         END IF;
        exception
          when parent_not_found then
            create_error_log(-20021, 'Corrections to be made in other line items, Hence unable to process. ', v_dependent_count);
          when others then
            v_error_message := sqlerrm||CHR(10)||sqlcode;
            create_error_log(-20021, v_error_message, v_dependent_count);
        end;
      END IF;
       IF v_upload_error_message IS NULL THEN
         begin    
           IF v_observation IS NOT NULL THEN
             SELECT MAX(p.activity_dtl_seq_id) INTO v_act_seq_id
             FROM Pat_Activity_Details p
             WHERE p.claim_seq_id = v_clm_seq_id;
                     
             pat_xml_load_pkg.save_observation_details(v_observ_seq_id,
                                                       v_act_seq_id,
                                                       'eRx',
                                                       '8',
                                                       v_observation,
                                                       'Reference',
                                                       1);
                     
           END IF;

          exception
            when parent_not_found then
              create_error_log(-20021, 'Corrections to be made in other line items, Hence unable to process. ', v_dependent_count);
            when others then
              v_error_message := sqlerrm||CHR(10)||sqlcode;
              create_error_log(-20021, v_error_message, v_dependent_count);

          end;
       END IF;
    END IF;
     
    IF v_upload_error_message IS NOT NULL THEN
      save_error_log(v_err_seq_id,
                     v1_sl_no,
                     v1_invoice_num,
                     v1_mem_name,
                     v1_mem_id,
                     v_pre_auth_num,
                     v1_hospitalization,
                     v1_discharge,
                     v_med_type,
                     v1_benefit_type,
                     v1_encounter_type,
                     v1_clinician_id,
                     v1_clinician_name,
                     v1_sympton,
                     v1_prim_diag_code,
                     v1_prim_diag_desc,
                     v1_secn_diag_code1,
                     v1_secn_diag_code2,
                     v1_secn_diag_code3,
                     v1_secn_diag_code4,
                     v1_secn_diag_code5,
                     v1_first_ins_dt,
                     v1_first_report_dt,
                     v1_service_dt,
                     v1_inter_ser_code,
                     v1_service_desc,
                     v1_act_code,
                     v1_act_req_amt,
                     v1_act_qnt,
                     v1_tooth_no,
                     v1_lmp_date,
                     v1_con_nature,
                     v1_observation,  
                     NULL,
                     v_upload_error_message,
                     v1_batch_seq_id,
                     1,
                     v1_event_no
                    );
                        
    END IF;

    
 EXCEPTION 
   WHEN OTHERS THEN
     v_orcl_err_msg  := SQLERRM;
     v_orcl_err_code := SQLCODE;
     
     save_error_log(v_err_seq_id,
                     v1_sl_no,
                     v1_invoice_num,
                     v1_mem_name,
                     v1_mem_id,
                     v_pre_auth_num,
                     v1_hospitalization,
                     v1_discharge,
                     v_med_type,
                     v1_benefit_type,
                     v1_encounter_type,
                     v1_clinician_id,
                     v1_clinician_name,
                     v1_sympton,
                     v1_prim_diag_code,
                     v1_prim_diag_desc,
                     v1_secn_diag_code1,
                     v1_secn_diag_code2,
                     v1_secn_diag_code3,
                     v1_secn_diag_code4,
                     v1_secn_diag_code5,
                     v1_first_ins_dt,
                     v1_first_report_dt,
                     v1_service_dt,
                     v1_inter_ser_code,
                     v1_service_desc,
                     v1_act_code,
                     v1_act_req_amt,
                     v1_act_qnt,
                     v1_tooth_no,
                     v1_lmp_date,
                     v1_con_nature,
                     v1_observation,  
                     NULL,
                     TRIM(BOTH ';' FROM (v_upload_error_message||';'||v_orcl_err_code||';'||v_orcl_err_msg)),
                     v1_batch_seq_id,
                     1,
                     v1_event_no
                    ); 
    
  online_clm_submitted_data(v1_batch_seq_id,
                              p_err_log,
                              p_err_count,
                              p_sucess_count
                             );
     
  -- Delete Batch if any Claim got fail
    IF p_err_count > 0 THEN
      delt_failed_batch(v_batch_seq_id, v_added_by);
    END IF;                  
  commit;  
END online_clm_submit;

--============================================================================================================
PROCEDURE online_batch_create(p_batch_no      OUT Clm_Batch_Upload_Details.Batch_No%TYPE,
                              p_bat_seq_id    IN OUT NUMBER,    
                              p_sender_id     IN Clm_Batch_Upload_Details.Sender_Id%TYPE,
                              p_recever_id    IN Clm_Batch_Upload_Details.Receiver_Id%TYPE,
                              p_added_by      IN Clm_Batch_Upload_Details.Added_By%TYPE,
                              v_rec_date      IN clm_authorization_details.clm_received_date%Type,
                              v_source_type   IN VARCHAR2    
                             )
AS
  v_batch_no Clm_Batch_Upload_Details.Batch_No%TYPE;
  v_batch_tot_amount         NUMBER(12, 2);
  v_benefit_type             VARCHAR2(10);
  CURSOR hosp_cur IS
    SELECT th.hosp_name, th.hosp_licenc_numb
    FROM Tpa_Hosp_Info th
    WHERE th.hosp_seq_id = p_sender_id;
    
  hosp_rec hosp_cur%ROWTYPE;
BEGIN
  
  v_added_by := NULL;
  v_added_by := p_added_by; --Required for Mail
  
  OPEN hosp_cur;
  FETCH hosp_cur INTO hosp_rec;
  CLOSE hosp_cur;
  
  clm_xml_load_pkg.save_clm_batch_details( p_bat_seq_id,
                                           p_batch_no,
                                           hosp_rec.hosp_licenc_numb,
                                           'ALK01',
                                          CASE WHEN v_source_type='PCLM' THEN v_rec_date
                                               WHEN v_source_type='PLCL' THEN SYSDATE END,
                                           0,
                                           v_batch_tot_amount,
                                           '1',
                                           'COMP',
                                           v_benefit_type,
                                           'CNH',
                                           'DTC',
                                           'QAR',
                                           v_source_type,
                                           1
                                          );
  
END online_batch_create;
--=============================================================================================================
PROCEDURE online_clm_submitted_data(p_batch_no      IN NUMBER,
                                    p_err_log       OUT SYS_REFCURSOR,
                                    p_err_count     OUT NUMBER,
                                    p_sucess_count  OUT NUMBER
                                   )
AS
  v_err_seq_id NUMBER;
  v_dest_msg_seq_id NUMBER;
  v_count        NUMBER;
  l_added_by     NUMBER;
BEGIN
  
  select count(er.err_seq_id) INTO p_err_count
  from app.error_log er
  where er.error_source = p_batch_no;
  
  OPEN p_err_log FOR
    select er.sl_no,
           er.invoice,
           er.mem_name,
           er.enrollment_id,
           er.preapptoval_no,
           er.date_of_treatmemt,
           er.date_of_discharge,
           er.system_of_medicine,
           er.benefit_type,
           er.encounter_type,
           er.clinician_id,
           er.clinician_name,
           er.symptoms,
           er.principal_icd_code,
           er.icd_description,
           er.secondary_icd_code1,
           er.secondary_icd_code2,
           er.secondary_icd_code3,
           er.secondary_icd_code4,
           er.secondary_icd_code5,
           er.first_incident_date,
           er.first_reported_date,
           er.service_date,
		       er.Activity_Type,
           er.internal_service_code,
           er.service_description,
           er.cpt_code,
           er.amount_claimed,
           er.quantity,
           er.tooth_no as tooth_number,
           er.lmp_date as DATE_OF_LMP,
           er.con_nature as NATURE_OF_CONCEPTION,
           er.currency,
           er.observation,
           er.error_message,
           er.service_date,
           er.activity_type,
           er.tooth_no,
           er.lmp_date as date_of_lmp,
           er.con_nature as Nature_Of_Conception,
           er.event_no as Event_ref_nO
           
    from app.error_log er
    where er.error_source = p_batch_no
    order by er.sl_no asc;
  
  select count(c.claim_seq_id) INTO p_sucess_count
  from clm_authorization_details c
  join pat_activity_details p on (p.claim_seq_id = c.claim_seq_id)
  where c.clm_batch_seq_id = p_batch_no;
  
  IF nvl(p_sucess_count, 0) > 0 THEN
    select count(er.added_by) into v_count
    from app.error_log er
    where er.error_source = p_batch_no;
    
    IF v_count = 0 THEN
      l_added_by := v_added_by;
    ELSE
      select distinct er.added_by into l_added_by
      from app.error_log er
      where er.error_source = p_batch_no;
    END IF;
          
    --generate_mail_pkg.proc_generate_message('ECLAIM_RECEIVED', p_batch_no, l_added_by, v_dest_msg_seq_id);
  END IF;
  
  -- Delete Batch if any Claim got fail
    IF p_err_count > 0 THEN
      delt_failed_batch(p_batch_no, v_added_by);
    END IF; 
END online_clm_submitted_data;
--==============================================================================================================
PROCEDURE search_claims_list (v_submit_from_date                   IN  VARCHAR2,
                              v_submit_to_date                     IN  VARCHAR2,
                              v_from_date                          IN  VARCHAR2,
                              v_to_date                            IN VARCHAR2,
                              v_mem_name                           IN  clm_authorization_details.mem_name%type,
                              v_clm_status_type_id                 IN  clm_authorization_details.clm_status_type_id%type,
                              v_invoice_number                     IN  clm_authorization_details.invoice_number%type,
                              v_batch_number                       IN  clm_batch_upload_details.batch_no%TYPE,
                              v_tpa_enrollment_id                  IN  app.tpa_enr_policy_member.tpa_enrollment_id%type,
                              v_claim_number                       IN  clm_authorization_details.claim_number%type,
                              v_hosp_empanel_no                    IN  VARCHAR2,
                              v_event_no                           IN  pat_authorization_details.event_no%TYPE,
                              v_srtfll_status_type                 IN  VARCHAR2,
                              v_emirate_id                         IN  app.tpa_enr_policy_member.emirate_id%type,
                              v_inp_status                         IN  VARCHAR2,
                              v_sort_var                           IN  VARCHAR2,
                              v_sort_order                         IN  VARCHAR2 ,
                              v_start_num                          IN  VARCHAR2 ,
                              v_end_num                            IN  VARCHAR2 ,
                              result_set                           OUT SYS_REFCURSOR
                             )
AS
    v_sql_str                            VARCHAR2(10000) ;
    TYPE bind_tab_type IS TABLE OF VARCHAR2(250) INDEX BY BINARY_INTEGER ;
    bind_tab                             bind_tab_type;
    i                                    NUMBER(2) := 0;
    v_where                              VARCHAR2(2000);
    
    v_date_from                          date:=to_date(v_from_date,'dd/mm/yyyy');
    v_date_upto                          date:=to_date(v_to_date,'dd/mm/yyyy'); 
    v_sub_frm_date                       date:=to_date(v_submit_from_date,'dd/mm/yyyy');
    v_sub_to_date                        date:=to_date(v_submit_to_date,'dd/mm/yyyy');
    v_date_diff                          NUMBER;
    v_inp_status1                        VARCHAR2(10);
BEGIN
  
  v_sql_str :=
    'with shrtfll as (select max(s.shortfall_seq_id) shortfall_seq_id, s.claim_seq_id
                       from clm_authorization_details c
                       join shortfall_details s on (c.claim_seq_id = s.claim_seq_id)
                       group by s.claim_seq_id
                      )
    select b.claim_seq_id,
            a.clm_batch_seq_id,
            to_char(a.received_date,''dd/mm/yyyy hh:mi Am'') as received_date,
            b.mem_name,
            b.tpa_enrollment_id,
            b.claim_number,
            a.batch_no,
            replace(b.invoice_number,'',#'','', #'') as invoice_number,
            ec.description AS benefit_type,
            gc.description as claim_status,
            b.settlement_number,
            g.emirate_id,
            nvl(b.requested_amount, 0) as claimed_amount,
            to_char(b.date_of_hospitalization, ''DD/MM/RRRR'') as treatment_date,
            case when sd.srtfll_status_general_type_id = ''RES'' then ''Y'' else ''N'' end as SHRTFALL_YN,
            case when sd.srtfll_status_general_type_id = ''RES'' then to_char(sd.updated_date, ''DD/MM/RRRR HH:MI:SS AM'') end srtfll_updated_date,
            nvl(b.event_no, '' '') as event_no,
            CASE WHEN clm_status_type_id in (''APR'',''REJ'',''PCO'') THEN  
                   to_char(b.completed_date,''dd/mm/yyyy hh:mi Am'') END as decision_date,
            B.CLM_STATUS_TYPE_ID||''-''||'||''''||v_inp_status||'''' ||' AS IN_PROGESS_STATUS
            
    from clm_batch_upload_details a
    join clm_authorization_details b on (a.clm_batch_seq_id=b.clm_batch_seq_id and a.batch_status_type=''COMP'')
    left outer join tpa_enr_policy_member g on (g.member_seq_id=b.member_seq_id)
    left outer join tpa_enr_policy e on (e.policy_seq_id=b.policy_seq_id)
    left outer join clm_hospital_details c on (c.claim_seq_id=b.claim_seq_id)
    left outer join tpa_hosp_info d on (d.hosp_seq_id=c.hosp_seq_id)
    left outer join tpa_user_contacts f on (f.contact_seq_id=b.added_by)
    left outer join tpa_general_code gc on (gc.general_type_id=b.clm_status_type_id)
    left outer join tpa_general_code tg on (tg.general_type_id=a.clm_type_gen_type_id)
    left outer join tpa_general_code ec on (b.benifit_type = ec.general_type_id)
    left join shrtfll sh ON (sh.claim_seq_id = b.claim_seq_id)
    left join shortfall_details sd on (sh.shortfall_seq_id=sd.shortfall_seq_id)
    where d.empanel_number = :v_hosp_empanel_no and a.source_type_id  in (''PLCL'',''PCLM'',''E_LM'',''INTL'')';
    
    
    IF v_invoice_number IS NOT NULL THEN
       v_where := v_where  ||' AND upper(trim(replace(b.invoice_number, '' '',''''))) like :v_invoice_number';
       i := i+1;
       bind_tab(i) := '%'||UPPER(trim(replace(v_invoice_number, ' ','')))||'%';
     END IF;
    
    
    IF v_claim_number IS NOT NULL THEN
      v_where := v_where  ||' AND b.claim_number = :v_claim_number';
      i := i+1;
      bind_tab(i) := UPPER(v_claim_number);
    END IF;
    
    IF v_date_from IS NOT NULL AND v_date_upto IS NULL THEN
      v_where := v_where  ||' AND trunc(b.clm_received_date) BETWEEN :v_from_date AND :v_to_date ';
      i := i+1;
      bind_tab(i) := v_date_from;
      i := i+1;
      bind_tab(i) := v_date_from + 7;
      
    ELSIF v_date_from IS NOT NULL AND v_date_upto IS NOT NULL THEN
      v_where := v_where  ||' AND trunc(b.clm_received_date) BETWEEN :v_from_date AND :v_to_date ';
      i := i+1;
      bind_tab(i) := v_date_from;
      i := i+1;
      bind_tab(i) := v_date_upto;
    
    ELSIF v_date_from IS NULL AND v_date_upto IS NOT NULL THEN
      v_where := v_where  ||' AND trunc(b.clm_received_date) BETWEEN :v_to_date AND :v_to_date1 ';
      i := i+1;
      bind_tab(i) := v_date_upto;
      i := i+1;
      bind_tab(i) := v_date_upto - 7;
      
    END IF;
    
    IF v_sub_frm_date IS NOT NULL AND v_sub_to_date IS NULL THEN
      v_where := v_where  ||' AND trunc(b.date_of_hospitalization) BETWEEN :received_date AND :received_date1';
      i := i+1;
      bind_tab(i) := (v_sub_frm_date);
      v_date_diff := to_date(sysdate, 'DD-MM-RRRR') - to_date(v_sub_frm_date, 'DD-MM-RRRR');
      i := i+1;
      bind_tab(i) := (v_sub_frm_date) + v_date_diff;
     
     
    END IF;
    
    IF v_sub_frm_date IS NOT NULL AND v_sub_to_date IS NOT NULL THEN
      v_where := v_where  ||' AND trunc(b.date_of_hospitalization) BETWEEN :received_date AND :received_date1 ';
      i := i+1;
      bind_tab(i) := UPPER(v_sub_frm_date);
      i := i+1;
      bind_tab(i) := UPPER(v_sub_to_date);
    END IF;
    
    IF v_sub_to_date IS NOT NULL AND v_sub_frm_date IS NULL THEN
      v_where := v_where  ||' AND trunc(b.date_of_discharge) BETWEEN :received_date AND :received_date1';
      i := i+1;
      bind_tab(i) := v_sub_to_date - 7;
      i := i+1;
      bind_tab(i) := v_sub_to_date;
    END IF;
    
    IF v_tpa_enrollment_id IS NOT NULL THEN
      v_where := v_where  ||' AND g.tpa_enrollment_id = :v_tpa_enrollment_id';
      i := i+1;
      bind_tab(i) := UPPER(v_tpa_enrollment_id);
    END IF;
    ---------------- CR0218 (search with QatarID)------------
    IF v_emirate_id IS NOT NULL THEN
      v_where := v_where  ||' AND g.emirate_id = :v_emirate_id';
      i := i+1;
      bind_tab(i) := UPPER(v_emirate_id);
    END IF;
    ---------------------------------------------------------
    IF v_batch_number IS NOT NULL THEN
      v_where := v_where  ||' AND a.batch_no = :v_batch_num';
       i := i+1;
       bind_tab(i) := UPPER(v_batch_number);
    END IF;
    
    
    IF v_mem_name IS NOT NULL THEN
      v_where := v_where  ||' AND g.mem_name = :v_mem_name';
       i := i+1;
       bind_tab(i) := UPPER(v_mem_name);
    END IF;
   
    IF v_clm_status_type_id IS NOT NULL THEN
      v_where := v_where  ||' AND b.clm_status_type_id = :v_clm_status_type_id';
      i := i+1;
      bind_tab(i) := UPPER(v_clm_status_type_id);
    END IF;
    
    IF v_srtfll_status_type IN ('OPN', 'RES') THEN
      v_where := v_where  || ' AND (sd.srtfll_status_general_type_id) = :v_srtfll_sts_type ';
      i := i+1;
      bind_tab(i) := v_srtfll_status_type;
    END IF;
    --===============CR0247====================================
    IF v_inp_status IS NOT NULL THEN
      IF v_inp_status = 'FRH' THEN
         v_inp_status1 := '0';
         v_where := v_where  ||' AND NVL(B.PARENT_CLAIM_SEQ_ID, 0) = 0 AND NVL(SD.CLAIM_SEQ_ID, 0) = :v_inp_status ';
      ELSIF v_inp_status = 'ENH' THEN
         v_inp_status1 := '0';
         v_where := v_where  ||' AND NVL(B.PARENT_CLAIM_SEQ_ID, 0) != :v_inp_status ';
      ELSIF v_inp_status = 'RES' THEN
         v_inp_status1 := 'RES';
         v_where := v_where  ||' AND B.CLM_STATUS_TYPE_ID = ''INP'' AND SD.SRTFLL_STATUS_GENERAL_TYPE_ID = :v_inp_status ';
      END IF;
      i := i+1;
      bind_tab(i) := UPPER(v_inp_status1);
    END IF;
    --=========================================================
    IF v_event_no IS NOT NULL THEN
      v_where := v_where  ||' AND b.event_no = :v_event_num ';
      i := i+1;
      bind_tab(i) := v_event_no;
    END IF;
     v_where := v_where||' AND   b.CLAIM_TYPE =''CNH''';
    IF v_where IS NOT NULL THEN
      v_where   := ' AND '|| SUBSTR(v_where,5);
      v_sql_str := v_sql_str ||v_where;
    END IF;
    
    v_sql_str := 'SELECT * FROM
        (SELECT A.*,DENSE_RANK() OVER (ORDER BY '||v_sort_var||' '||v_sort_order||',ROWNUM)
        Q FROM (' ||v_sql_str|| ') A ) WHERE  Q>= :v_start_num AND Q<= :v_end_num ';
    
    IF bind_tab.FIRST IS NOT NULL THEN
       CASE bind_tab.COUNT
         WHEN 1  THEN OPEN result_set FOR v_sql_str USING v_hosp_empanel_no,bind_tab(1), v_start_num , v_end_num ;
         WHEN 2  THEN OPEN result_set FOR v_sql_str USING v_hosp_empanel_no,bind_tab(1),bind_tab(2), v_start_num , v_end_num ;
         WHEN 3  THEN OPEN result_set FOR v_sql_str USING v_hosp_empanel_no,bind_tab(1),bind_tab(2),bind_tab(3) , v_start_num , v_end_num ;
         WHEN 4  THEN OPEN result_set FOR v_sql_str USING v_hosp_empanel_no,bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) , v_start_num , v_end_num ;
         WHEN 5  THEN OPEN result_set FOR v_sql_str USING v_hosp_empanel_no,bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5), v_start_num , v_end_num ;
         WHEN 6  THEN OPEN result_set FOR v_sql_str USING v_hosp_empanel_no,bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6), v_start_num , v_end_num ;
         WHEN 7  THEN OPEN result_set FOR v_sql_str USING v_hosp_empanel_no,bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6),bind_tab(7), v_start_num , v_end_num ;
         WHEN 8  THEN OPEN result_set FOR v_sql_str USING v_hosp_empanel_no,bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6),bind_tab(7),bind_tab(8), v_start_num , v_end_num ;
         WHEN 9  THEN OPEN result_set FOR v_sql_str USING v_hosp_empanel_no,bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6),bind_tab(7),bind_tab(8),bind_tab(9), v_start_num , v_end_num ;
         WHEN 10 THEN OPEN result_set FOR v_sql_str USING v_hosp_empanel_no,bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6),bind_tab(7),bind_tab(8),bind_tab(9),bind_tab(10), v_start_num , v_end_num ;
         WHEN 11 THEN OPEN result_set FOR v_sql_str USING v_hosp_empanel_no,bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6),bind_tab(7),bind_tab(8),bind_tab(9),bind_tab(10), bind_tab(11), v_start_num , v_end_num ;
         WHEN 12 THEN OPEN result_set FOR v_sql_str USING v_hosp_empanel_no,bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6),bind_tab(7),bind_tab(8),bind_tab(9),bind_tab(10), bind_tab(11), bind_tab(12), v_start_num , v_end_num ;
         WHEN 13 THEN OPEN result_set FOR v_sql_str USING v_hosp_empanel_no,bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6),bind_tab(7),bind_tab(8),bind_tab(9),bind_tab(10),bind_tab(11), bind_tab(12),bind_tab(13), v_start_num , v_end_num ;
         WHEN 14 THEN OPEN result_set FOR v_sql_str USING v_hosp_empanel_no,bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6),bind_tab(7),bind_tab(8),bind_tab(9),bind_tab(10),bind_tab(11), bind_tab(12),bind_tab(13), bind_tab(14), v_start_num , v_end_num ;
         WHEN 15 THEN OPEN result_set FOR v_sql_str USING v_hosp_empanel_no,bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6),bind_tab(7),bind_tab(8),bind_tab(9),bind_tab(10),bind_tab(11), bind_tab(12),bind_tab(13), bind_tab(14), bind_tab(15), v_start_num , v_end_num ;
         WHEN 16 THEN OPEN result_set FOR v_sql_str USING v_hosp_empanel_no,bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6),bind_tab(7),bind_tab(8),bind_tab(9),bind_tab(10),bind_tab(11), bind_tab(12),bind_tab(13), bind_tab(14), bind_tab(15), bind_tab(16), v_start_num , v_end_num ;
         WHEN 17 THEN OPEN result_set FOR v_sql_str USING v_hosp_empanel_no,bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6),bind_tab(7),bind_tab(8),bind_tab(9),bind_tab(10),bind_tab(11), bind_tab(12),bind_tab(13), bind_tab(14), bind_tab(15), bind_tab(16), bind_tab(17), v_start_num , v_end_num ;
         
       END CASE;
     ELSE
       OPEN result_set FOR v_sql_str USING v_hosp_empanel_no,v_start_num , v_end_num ;
     END IF;
END search_claims_list;
--==============================================================================================================================================================================
PROCEDURE get_claim_details(p_clm_seq_id       IN Clm_Authorization_Details.Claim_Seq_Id%TYPE,
                            clm_resultset      OUT SYS_REFCURSOR,
                            diag_resultset     OUT SYS_REFCURSOR,
                            act_resultset      OUT SYS_REFCURSOR,
                            shrtfall_resutlset OUT SYS_REFCURSOR
                           )
AS

cursor hosp_cur 
is
select hosp_seq_id 
from Clm_Hospital_Details
where claim_seq_id = p_clm_seq_id;

rec hosp_cur%rowtype;



BEGIN

open hosp_cur;
fetch hosp_cur into rec;
close hosp_cur;

if rec.hosp_seq_id is not null then 
-------*********for provider
 OPEN clm_resultset FOR
   SELECT c.settlement_number,
          c.claim_seq_id,
       c.claim_number,
       b.batch_no,
       initcap(gcc.description) as clm_status,
       c.clm_status_type_id as clm_status_id,
       g.description,
       th.hosp_name,
       th.hosp_licenc_numb,
       case when th.off_phone_no_1 is not null  and th.off_phone_no_2 is not null then 
                 th.off_phone_no_1||' / '||th.off_phone_no_2
       else
         nvl(th.off_phone_no_1, th.off_phone_no_2)
       end as contact_no, --Provider
       ttk_util_pkg.fn_decrypt(th.primary_email_id) as primary_email_id,
       c.mem_name,
       m.emirate_id,
       po.policy_number,
       to_char(m.mem_dob, 'DD/MM/RRRR') as mem_dob,
       case m.gender_general_type_id
         when 'MAL' then 'Male'
         when 'FEM' then 'Female'
       else
         'Others'
       end as gender,
       to_char(c.date_of_hospitalization, 'DD/MM/RRRR') as date_of_treatment,
       gc.description as benefit_type,
       to_char(c.clm_received_date,'dd/mm/rrrr hh:mi AM') as submission_date,
       to_char(c.completed_date,'dd/mm/rrrr hh:mi AM') as decision_date,
       c.tpa_enrollment_id
       
    FROM Clm_Authorization_Details c
    LEFT JOIN Shortfall_Details sh ON (c.claim_seq_id = sh.claim_seq_id)
    JOIN Clm_Batch_Upload_Details b ON (c.clm_batch_seq_id = b.clm_batch_seq_id)
    JOIN Clm_Hospital_Details ch ON (ch.claim_seq_id = c.claim_seq_id)
    JOIN Tpa_Hosp_Info th ON (th.hosp_seq_id = ch.hosp_seq_id)
    JOIN Tpa_General_Code g ON (g.general_type_id = c.clm_status_type_id)
    JOIN Tpa_General_Code gc ON (gc.general_type_id = c.benifit_type)
    JOIN Tpa_General_Code gcc ON (gcc.general_type_id = c.clm_status_type_id)
    JOIN Tpa_Enr_Policy_Member m ON (m.member_seq_id = c.member_seq_id)
    JOIN Tpa_Enr_Policy po ON (po.policy_seq_id = c.policy_seq_id)
    WHERE c.claim_seq_id = p_clm_seq_id;
    
  OPEN diag_resultset FOR
    SELECT i.diagnosys_code,
         j.short_desc icd_description,
         i.primary_ailment_yn as primary_ailment_yn,
         i.icd_code_seq_id,
         i.diag_seq_id
         
    FROM clm_authorization_details A
    LEFT OUTER JOIN diagnosys_details I
      ON (I.claim_seq_id = a.claim_seq_id)
    LEFT OUTER JOIN tpa_icd10_master_details J
      ON (i.diagnosys_code = j.icd_code)
    WHERE a.claim_seq_id = p_clm_seq_id
    GROUP BY i.primary_ailment_yn,i.diagnosys_code, j.short_desc, i.icd_code_seq_id,
         i.diag_seq_id
    ORDER BY primary_ailment_yn DESC;
         
  OPEN act_resultset FOR
     SELECT
      ad.activity_dtl_seq_id,
      ad.code as activity_code,
      nvl(tamd.activity_description,md.activity_description) as activity_description,
      nvl(ad.gross_amount,0) gross_amount ,
      nvl(ad.approved_amount,0) as approved_amt,
      nvl(ad.discount_amount,0) discount_amount,
      ad.quantity,
      nvl((nvl(ad.net_amount,0)-nvl(ad.patient_share_amount,0)), 0) as net_amount,
      case when nvl(ad.approved_amount, 0) > 0 AND clm.clm_status_type_id = 'APR' then
             'Approved'
           when nvl(ad.approved_amount, 0) <= 0 AND clm.clm_status_type_id = 'APR' then
             'Rejected'
           when clm.clm_status_type_id = 'REJ' then
             'Rejected'
      else
        'Inprogress'
      end as status,
      nvl(ad.patient_share_amount, 0) as patient_share,
      nvl(ad.disc_gross_amount, 0) as disc_gross_amount,
      ad.posology_duration as duration,
      ad.denial_code||' - '||ad.denial_desc as denial,
      nvl(ad.denial_desc, '-') as remarks,
      ad.internal_code,
      ad.unit_price
      
   from pat_activity_details ad
   left join clm_authorization_details clm on (clm.claim_seq_id = ad.claim_seq_id)
   left outer join tpa_activity_master_details tamd on (ad.code=tamd.activity_code)
   left outer join tpa_pharmacy_master_details md   on (ad.code = md.activity_code /*and ad.start_date between md.start_date and md.end_date*/)
   where ad.claim_seq_id = p_clm_seq_id
   --and nvl(activity_type,0) <>'5'
   order by s_no;
   
  OPEN shrtfall_resutlset FOR
    select to_char(s.srtfll_sent_date,'dd/mm/yyyy hh:mi AM') as srtfll_sent_date,
           s.shortfall_id,
           s.shortfall_seq_id,
           g.description as srtfll_general_type_id,
           ge.description as srtfll_status_general_type_id,
           to_char(s.srtfll_received_date,'dd/mm/yyyy HH:MI:SS AM') as srtfll_received_date
    from app.shortfall_details s 
    left outer join app.tpa_general_code g on (s.srtfll_general_type_id = g.general_type_id)
    left outer join app.tpa_general_code ge on (s.srtfll_status_general_type_id = ge.general_type_id) 
    where s.claim_seq_id = p_clm_seq_id;
    
    
else 
 ------******change for partner    
    OPEN clm_resultset FOR
    SELECT c.settlement_number,
          c.claim_seq_id,
       c.claim_number,
       b.batch_no,
       initcap(gcc.description) as clm_status,
       c.clm_status_type_id as clm_status_id,
       g.description,
        ch.hosp_name,--change for partner
       '' as hosp_licenc_numb,--change for partner  
       '' contact_no, --Provider---change for partner  
       '' as primary_email_id,----change for partner  
       c.mem_name,
       m.emirate_id,
       po.policy_number,
       to_char(m.mem_dob, 'DD/MM/RRRR') as mem_dob,
       case m.gender_general_type_id
         when 'MAL' then 'Male'
         when 'FEM' then 'Female'
       else
         'Others'
       end as gender,
       to_char(c.date_of_hospitalization, 'DD/MM/RRRR') as date_of_treatment,
       gc.description as benefit_type,
       to_char(c.clm_received_date,'dd/mm/rrrr hh:mi AM') as submission_date,
       to_char(c.completed_date,'dd/mm/rrrr hh:mi AM') as decision_date,
       c.tpa_enrollment_id
       
    FROM Clm_Authorization_Details c
   LEFT JOIN Shortfall_Details sh ON (c.claim_seq_id = sh.claim_seq_id)
    JOIN Clm_Batch_Upload_Details b ON (c.clm_batch_seq_id = b.clm_batch_seq_id)
   JOIN Clm_Hospital_Details ch ON (ch.claim_seq_id = c.claim_seq_id)
   -- JOIN Tpa_Hosp_Info th ON (th.hosp_seq_id = ch.hosp_seq_id)
    JOIN Tpa_General_Code g ON (g.general_type_id = c.clm_status_type_id)
    JOIN Tpa_General_Code gc ON (gc.general_type_id = c.benifit_type)
    JOIN Tpa_General_Code gcc ON (gcc.general_type_id = c.clm_status_type_id)
    JOIN Tpa_Enr_Policy_Member m ON (m.member_seq_id = c.member_seq_id)
    JOIN Tpa_Enr_Policy po ON (po.policy_seq_id = c.policy_seq_id)
    WHERE c.claim_seq_id = p_clm_seq_id;
    
  OPEN diag_resultset FOR
    SELECT i.diagnosys_code,
         j.short_desc icd_description,
         i.primary_ailment_yn as primary_ailment_yn,
         i.icd_code_seq_id,
         i.diag_seq_id
         
    FROM clm_authorization_details A
    LEFT OUTER JOIN diagnosys_details I
      ON (I.claim_seq_id = a.claim_seq_id)
    LEFT OUTER JOIN tpa_icd10_master_details J
      ON (i.diagnosys_code = j.icd_code)
    WHERE a.claim_seq_id = p_clm_seq_id
    GROUP BY i.primary_ailment_yn,i.diagnosys_code, j.short_desc, i.icd_code_seq_id,
         i.diag_seq_id
    ORDER BY primary_ailment_yn DESC;
         
  OPEN act_resultset FOR
     SELECT
      ad.activity_dtl_seq_id,
      ad.code as activity_code,
      nvl(tamd.activity_description,md.activity_description) as activity_description,
      nvl(ad.gross_amount,0) gross_amount ,
      nvl(ad.approved_amount,0) as approved_amt,
      nvl(ad.discount_amount,0) discount_amount,
      ad.quantity,
      nvl((nvl(ad.net_amount,0)-nvl(ad.patient_share_amount,0)), 0) as net_amount,
      case when nvl(ad.approved_amount, 0) > 0 AND clm.clm_status_type_id = 'APR' then
             'Approved'
           when nvl(ad.approved_amount, 0) <= 0 AND clm.clm_status_type_id = 'APR' then
             'Rejected'
           when clm.clm_status_type_id = 'REJ' then
             'Rejected'
      else
        'Inprogress'
      end as status,
      nvl(ad.patient_share_amount, 0) as patient_share,
      nvl(ad.disc_gross_amount, 0) as disc_gross_amount,
      ad.posology_duration as duration,
      ad.denial_code||' - '||ad.denial_desc as denial,
      nvl(ad.denial_desc, '-') as remarks,
      ad.internal_code,
      ad.unit_price
      
   from pat_activity_details ad
   left join clm_authorization_details clm on (clm.claim_seq_id = ad.claim_seq_id)
   left outer join tpa_activity_master_details tamd on (ad.code=tamd.activity_code)
   left outer join tpa_pharmacy_master_details md   on (ad.code = md.activity_code /*and ad.start_date between md.start_date and md.end_date*/)
   where ad.claim_seq_id = p_clm_seq_id
   and nvl(activity_type,0) <>'5'
   order by s_no;
   
  OPEN shrtfall_resutlset FOR
    select to_char(s.srtfll_sent_date,'dd/mm/yyyy hh:mi AM') as srtfll_sent_date,
           s.shortfall_id,
           s.shortfall_seq_id,
           g.description as srtfll_general_type_id,
           ge.description as srtfll_status_general_type_id,
           to_char(s.srtfll_received_date,'dd/mm/yyyy hh:mi AM') as srtfll_received_date
    from app.shortfall_details s 
    left outer join app.tpa_general_code g on (s.srtfll_general_type_id = g.general_type_id)
    left outer join app.tpa_general_code ge on (s.srtfll_status_general_type_id = ge.general_type_id) 
    where s.claim_seq_id = p_clm_seq_id;
    
    end if;
     
END get_claim_details;
--===========================================================================================================
PROCEDURE get_shortfall_details (p_shortfall_seq_id IN shortfall_details.shortfall_seq_id%TYPE,
                                 p_resultset        OUT SYS_REFCURSOR
                                )
AS
BEGIN
  OPEN p_resultset FOR
    SELECT sd.shortfall_id,
           decode(cl.clm_status_type_id, 'INP', 'In-Progress', 'APR', 'Approved', 'REJ', 'Rejected', 'REQ', 'Required Additional Information') as status,
           to_char(sysdate, 'DD/MM/RRRR') as generated_date,
           case when h.hosp_seq_id is not null then  upper(h.hosp_name) else upper(ch.hosp_name) end  as prov_name,---newly changed for partner
           case when h.off_phone_no_1 is not null  and h.off_phone_no_2 is not null then 
              h.off_phone_no_1||' / '||h.off_phone_no_2
           else
              nvl(h.off_phone_no_1, h.off_phone_no_2)
           end as contact_no,
           h.hosp_licenc_numb as licence_no,
           ttk_util_pkg.fn_decrypt(h.primary_email_id) as prov_email,
           cl.mem_name as patient_name,
           m.tpa_enrollment_id as alkoot_id,
           to_char(m.mem_dob, 'DD/MM/RRRR') as dob,
           decode(m.gender_general_type_id, 'MAL', 'Male', 'FEM', 'Female', 'Other') as gender,
           g.description as benefit_type,
           to_char(cl.date_of_hospitalization, 'DD/MM/RRRR') as treatment_date,
           po.policy_number,
           c.contact_name as processed_by,
           cl.claim_number,
           decode(sd.srtfll_status_general_type_id, 'OPN', 'Open', 'CLS', 'Closed', 'RES', 'Responded') as shortfall_status
         
    FROM Shortfall_Details sd
    LEFT JOIN Clm_Authorization_Details cl ON (cl.claim_seq_id = sd.claim_seq_id)
    LEFT JOIN Clm_Hospital_Details ch   ON (ch.claim_seq_id = cl.claim_seq_id)
    LEFT JOIN Tpa_Hosp_Info h ON (h.hosp_seq_id = ch.hosp_seq_id)
    LEFT JOIN Tpa_Enr_Policy_Member m ON (cl.member_seq_id = m.member_seq_id)
    LEFT JOIN Tpa_Enr_Policy po ON (po.policy_seq_id = cl.policy_seq_id)
    JOIN Tpa_User_Contacts c ON (cl.added_by = c.contact_seq_id)
    JOIN Tpa_General_Code g ON (g.general_type_id = cl.benifit_type)
    WHERE sd.shortfall_seq_id = p_shortfall_seq_id;
    
END get_shortfall_details;
--=============================================================================================
PROCEDURE save_error_log(P_ERR_SEQ_ID              IN Error_Log.Err_Seq_Id%TYPE,
                         P_SL_NO                   IN Error_Log.Sl_No%TYPE,
                         P_INVOICE_NO              IN Error_Log.Invoice%TYPE,
                         P_MEM_NAME                IN Error_Log.Mem_Name%TYPE,
                         P_ENROLLMENT_ID           IN Error_Log.Enrollment_Id%TYPE,
                         P_PREAPPTOVAL_NO          IN Error_Log.Preapptoval_No%TYPE,
                         P_DATE_OF_TREATMEMT       IN Error_Log.Date_Of_Treatmemt%TYPE,
                         P_DATE_OF_DISCHARGE       IN Error_Log.Date_Of_Discharge%TYPE,
                         P_SYSTEM_OF_MEDICINE      IN Error_Log.System_Of_Medicine%TYPE,
                         P_BENEFIT_TYPE            IN Error_Log.Benefit_Type%TYPE,
                         P_ENCOUNTER_TYPE          IN Error_Log.Encounter_Type%TYPE,
                         P_CLINICIAN_ID            IN Error_Log.Clinician_Id%TYPE,
                         P_CLINICIAN_NAME          IN Error_Log.Clinician_Name%TYPE,
                         P_SYMPTOMS                IN Error_Log.Symptoms%TYPE,
                         P_PRINCIPAL_ICD_CODE      IN Error_Log.Principal_Icd_Code%TYPE,
                         P_ICD_DESCRIPTION         IN Error_Log.Icd_Description%TYPE,
                         P_SECONDARY_ICD_CODE1     IN Error_Log.Secondary_Icd_Code1%TYPE,
                         P_SECONDARY_ICD_CODE2     IN Error_Log.Secondary_Icd_Code2%TYPE,
                         P_SECONDARY_ICD_CODE3     IN Error_Log.Secondary_Icd_Code3%TYPE,
                         P_SECONDARY_ICD_CODE4     IN Error_Log.Secondary_Icd_Code4%TYPE,
                         P_SECONDARY_ICD_CODE5     IN Error_Log.Secondary_Icd_Code5%TYPE,
                         P_FIRST_INCIDENT_DATE     IN Error_Log.First_Incident_Date%TYPE,
                         P_FIRST_REPORTED_DATE     IN Error_Log.First_Reported_Date%TYPE,
                         P_SERVICE_DATE            IN Error_Log.Service_Date%TYPE,
                         P_INTERNAL_SERVICE_CODE  IN Error_Log.Internal_Service_Code%TYPE,
                         P_SERVICE_DESCRIPTION     IN Error_Log.Service_Description%TYPE,
                         P_CPT_CODE                IN Error_Log.Cpt_Code%TYPE,
                         P_AMOUNT_CLAIMED          IN Error_Log.Amount_Claimed%TYPE,
                         P_QUANTITY                IN VARCHAR2,--Error_Log.Quantity%TYPE,
                         P_TOOTH_NO                IN VARCHAR2,--Error_Log.Tooth_No%TYPE,
                         P_LMP_DATE                IN VARCHAR2,--Error_Log.Lmp_Date%TYPE,
                         P_CON_NATURE              IN VARCHAR2,--Error_Log.Con_Nature%TYPE,
                         P_OBSERVATION             IN Error_Log.Observation%TYPE,
                         P_ERROR_CODE              IN Error_Log.Error_Code%TYPE,
                         P_ERROR_MESSAGE           IN Error_Log.Error_Message%TYPE,
                         P_ERROR_SOURCE            IN Error_Log.Error_Source%TYPE,
                         P_ADDED_BY                IN Error_Log.Added_By%TYPE,
                         P_EVENT_NO                IN Error_Log.Event_No%TYPE
                        )
AS
  PRAGMA AUTONOMOUS_TRANSACTION;
  v_seq_id NUMBER;
  v_sl_no  NUMBER;
BEGIN
  
    SELECT COUNT(err.err_seq_id) INTO v_sl_no
    FROM app.error_log err
    WHERE err.error_source = P_ERROR_SOURCE;
    
  --IF nvl(v_sl_no, 0) = 0 THEN
    
    SELECT NVL(MAX(err.err_seq_id), 0) INTO v_seq_id
    FROM app.error_log err;
    
    INSERT INTO app.error_log err (ERR_SEQ_ID,
                                   SL_NO,
                                   INVOICE,
                                   MEM_NAME,
                                   ENROLLMENT_ID,
                                   PREAPPTOVAL_NO,
                                   DATE_OF_TREATMEMT,
                                   DATE_OF_DISCHARGE,
                                   SYSTEM_OF_MEDICINE,
                                   BENEFIT_TYPE,
                                   ENCOUNTER_TYPE,
                                   CLINICIAN_ID,
                                   CLINICIAN_NAME,
                                   SYMPTOMS,
                                   PRINCIPAL_ICD_CODE,
                                   ICD_DESCRIPTION,
                                   SECONDARY_ICD_CODE1,
                                   SECONDARY_ICD_CODE2,
                                   SECONDARY_ICD_CODE3,
                                   SECONDARY_ICD_CODE4,
                                   SECONDARY_ICD_CODE5,
                                   FIRST_INCIDENT_DATE,
                                   FIRST_REPORTED_DATE,
                                   SERVICE_DATE,
                                   INTERNAL_SERVICE_CODE,
                                   SERVICE_DESCRIPTION,
                                   CPT_CODE,
                                   AMOUNT_CLAIMED,
                                   QUANTITY,
                                   OBSERVATION,
                                   ERROR_CODE,
                                   ERROR_MESSAGE,
                                   ERROR_SOURCE,
                                   ADDED_BY,
                                   ADDED_DATE,
                                   TOOTH_NO,
                                   LMP_DATE,
                                   CON_NATURE,
                                   EVENT_NO
                                   )
    VALUES (V_SEQ_ID + 1,
            TRUNC(P_SL_NO),
            P_INVOICE_NO,
            P_MEM_NAME,
            P_ENROLLMENT_ID,
            P_PREAPPTOVAL_NO,
            P_DATE_OF_TREATMEMT,
            P_DATE_OF_DISCHARGE,
            P_SYSTEM_OF_MEDICINE,
            P_BENEFIT_TYPE,
            P_ENCOUNTER_TYPE,
            P_CLINICIAN_ID,
            P_CLINICIAN_NAME,
            P_SYMPTOMS,
            P_PRINCIPAL_ICD_CODE,
            P_ICD_DESCRIPTION,
            P_SECONDARY_ICD_CODE1,
            P_SECONDARY_ICD_CODE2,
            P_SECONDARY_ICD_CODE3,
            P_SECONDARY_ICD_CODE4,
            P_SECONDARY_ICD_CODE5,
            P_FIRST_INCIDENT_DATE,
            P_FIRST_REPORTED_DATE,
            P_SERVICE_DATE,
            P_INTERNAL_SERVICE_CODE,
            P_SERVICE_DESCRIPTION,
            P_CPT_CODE,
            P_AMOUNT_CLAIMED,
            P_QUANTITY,
            P_OBSERVATION,
            P_ERROR_CODE,
            P_ERROR_MESSAGE,
            P_ERROR_SOURCE,
            P_ADDED_BY,
            SYSDATE,
            P_TOOTH_NO,
            P_LMP_DATE,
            P_CON_NATURE,
            P_EVENT_NO
            );
         
  COMMIT;
END save_error_log;
--==============================================================================
PROCEDURE create_error_log (
    v_error_no                           IN NUMBER,
    v_error_message                      IN VARCHAR2,
    v_error_type                         IN VARCHAR := NULL,
    v_dependent_count                    IN NUMBER  := NULL
  )
  IS
    v_error_log_seq_id                   NUMBER(20);
    v_err_type                           CHAR(1);
  BEGIN
      -- STORING ERROR LOG
    IF v_error_no = 0 THEN
       v_err_type := 'C';  --CORRECT
    ELSE
      v_err_type := 'E';  -- ERROR
    END IF;

   v_upload_error_message := TRIM(BOTH ';' FROM (v_upload_error_message||';'||v_error_message));
    
  END create_error_log;
--=============================================================================
PROCEDURE select_onl_docs(v_claim_seq_id                    IN clm_authorization_details.claim_seq_id%TYPE,
          	              v_doc                             OUT clm_batch_upload_details.onl_mob_clm_docmnts%TYPE,
                          v_onl_doc_typ                     OUT clm_batch_upload_details.onl_doc_typ%TYPE)
 IS
  CURSOR clm_dtls IS
    SELECT b.onl_mob_clm_docmnts,onl_doc_typ
    FROM clm_batch_upload_details b
    JOIN clm_authorization_details c ON(b.clm_batch_seq_id=c.clm_batch_seq_id)
    WHERE c.claim_seq_id = v_claim_seq_id;
    
 BEGIN
   OPEN  clm_dtls;
   FETCH clm_dtls INTO v_doc,v_onl_doc_typ;
   CLOSE clm_dtls;
 END select_onl_docs;                          
--============================================================================== 
--Check Leap year
--===============================================================================
FUNCTION fn_leap_year (p_year IN VARCHAR2) RETURN NUMBER
  IS
    v_day NUMBER;
    v_year VARCHAR2(4);
    v_res  NUMBER;
    v_substr  VARCHAR2(11);
    v_len     NUMBER;
  BEGIN
    IF p_year IS NULL THEN
      v_year := TO_CHAR(SYSDATE, 'RRRR');
    ELSE
      v_len  := LENGTH(p_year);
      IF v_len = 11 THEN
        v_substr := SUBSTR(p_year, 8);
      ELSIF v_len = 10 THEN
        v_substr := SUBSTR(p_year, 7);
      END IF;
      v_year := TO_CHAR(v_substr);
    END IF;
    
    SELECT CASE
             WHEN ( MOD(v_year, 4) = 0 AND MOD(v_year, 100) <> 0 ) OR
                  ( MOD(v_year, 400) = 0 ) THEN 1
             ELSE 0
            END INTO v_day
    FROM DUAL;
    
     IF v_day = 1 THEN 
        --RETURN TRUE; 
        v_res := 1;
        RETURN v_res;
     ELSE 
        --RETURN FALSE;
        v_res := 0;
        RETURN v_res;
     END IF;
  END fn_leap_year;
--=========================================================================================
PROCEDURE delt_failed_batch(p_batch_seq_id IN Clm_Batch_Upload_Details.Clm_Batch_Seq_Id%TYPE,
                            p_deleted_by   IN NUMBER)
AS
   v_fin_cnt                  NUMBER;       
   
   CURSOR clm_cur IS
    Select c.claim_seq_id,
           c.clm_batch_seq_id,
           c.invoice_number,
           c.assign_user_seq_id,
           c.pat_auth_seq_id
           
    From Clm_Authorization_Details c
    Left Join Pat_Authorization_Details p On (p.pat_auth_seq_id = c.pat_auth_seq_id)
    Where c.clm_batch_seq_id = p_batch_seq_id;
    
    --Batch Details
    Cursor clm_batch_cur IS
      Select b.*
      From app.clm_batch_upload_details b
      Where b.clm_batch_seq_id = p_batch_seq_id;
    
    clm_batch_rec   clm_batch_cur%ROWTYPE;
    
    --Claim Details
    Cursor clm_details_cur IS
      Select c.claim_seq_id,
             c.clm_batch_seq_id,
             c.pat_auth_seq_id,
             c.claim_number,
             c.settlement_number,
             c.clm_received_date,
             c.source_type_id,
             c.date_of_hospitalization,
             c.date_of_discharge,
             c.claim_type,
             c.claim_sub_type,
             c.member_seq_id,
             c.tpa_enrollment_id,
             c.mem_name,
             c.mem_age,
             c.ins_seq_id,
             c.policy_seq_id,
             c.emirate_id,
             c.encounter_type_id,
             c.ava_sum_insured,
             c.currency_type,
             c.clm_status_type_id,
             c.added_by,
             c.added_date,
             c.invoice_number,
             c.requested_amount,
             c.clinician_id,
             c.system_of_medicine_type_id,
             c.network_yn,
             c.benifit_type,
             c.presenting_complaints,
             c.medical_opinion_remarks,
             c.pat_approved_amount,
             c.Lmp_Date,
             c.Conception_Type,
             c.first_incident_date,
             c.first_reported_date,
             c.AUTH_NUMBER,
             c.CONVERSION_RATE,
             c.req_amt_currency_type,
             c.SOURCE_FROM,
             c.event_no,
             c.tot_gross_amount,
             c.tot_discount_amount,
             c.tot_disc_gross_amount,
             c.tot_patient_share_amount,
             c.tot_net_amount,
             c.tot_allowed_amount,
             c.tot_approved_amount
                        
      From app.clm_authorization_details c
      Where c.clm_batch_seq_id = p_batch_seq_id;
    
    --clm_details_rec   clm_details_cur%ROWTYPE;
    TYPE clm_typ IS TABLE OF clm_details_cur%ROWTYPE;
    clm_obj      clm_typ;
    --Claim Hospital Details
    Cursor clm_hosp_cur IS
      Select ch.clm_hosp_assoc_seq_id,
             ch.claim_seq_id,
             ch.hosp_seq_id,
             ch.hosp_name,
             ch.address_1,
             ch.city_type_id,
             ch.state_type_id,
             ch.pin_code,
             ch.off_phone_no_1,
             ch.office_fax_no,
             ch.remarks,
             ch.added_by,
             ch.added_date,
             ch.provider_id,
             ch.country_type_id,
             ch.clinician_name
             
      From app.clm_hospital_details ch
      Join clm_authorization_details c ON (ch.claim_seq_id = c.claim_seq_id)
      Where c.clm_batch_seq_id = p_batch_seq_id;
      
    clm_hosp_rec      clm_hosp_cur%ROWTYPE;
    
    --Claim Diagnosys Details
    Cursor diag_cur IS
      Select d.diag_seq_id,
             d.pat_auth_seq_id,
             d.claim_seq_id,
             d.icd_code_seq_id,
             d.diagnosys_code,
             d.primary_ailment_yn,
             d.remarks,
             d.added_by,
             d.added_date
             
      From app.diagnosys_details d
      Join app.clm_authorization_details c ON (c.claim_seq_id = d.claim_seq_id)
      Where c.clm_batch_seq_id = p_batch_seq_id;
      
    --diag_rec    diag_cur%ROWTYPE;
    TYPE diag_typ IS TABLE OF diag_cur%ROWTYPE;
    diag_obj      diag_typ;
    --Claim Shortfall Details
    Cursor shortfll_cur IS
      Select s.shortfall_seq_id,
             s.pat_gen_detail_seq_id,
             s.claim_seq_id,
             s.shortfall_id,
             s.srtfll_general_type_id,
             s.srtfll_sent_date,
             s.srtfll_reason_general_type_id,
             s.remarks,
             s.shortfall_questions,
             s.added_by,
             s.added_date,
             s.updated_date,
             s.updated_by,             
             s.reminder_count,
             s.closed_date,
             s.shortfall_raised_by,
             s.uploaded_file
             
      From app.shortfall_details s
      Join app.clm_authorization_details c ON (c.claim_seq_id = s.claim_seq_id)
      Where c.clm_batch_seq_id = p_batch_seq_id;
      
    --shortfll_rec    shortfll_cur%ROWTYPE; 
    TYPE shrtfll_typ IS TABLE OF shortfll_cur%ROWTYPE;
    shrtfll_obj      shrtfll_typ;
    --Claim Activity Details
    Cursor act_details_cur IS
      Select p.activity_dtl_seq_id,
             p.pat_auth_seq_id,
             p.claim_seq_id,
             p.activity_id,
             p.activity_seq_id,
             p.s_no,
             p.start_date,
             p.activity_type,
             p.code,
             p.unit_type,
             p.clinician_id,
             p.internal_code,
             p.quantity,
             p.allow_yn,
             p.gross_amount,
             p.discount_amount,
             p.disc_gross_amount,
             p.copay_perc,
             p.copay_amount,
             p.deduct_amount,
             p.patient_share_amount,
             p.net_amount,
             p.allowed_amount,
             p.approved_amount,
             p.currency_type,
             p.denial_code,
             p.remarks,
             p.added_by,
             p.added_date,
             p.updated_by,
             p.updated_date,
             p.service_type,
             p.service_code,
             p.benifit_deductible,
             p.unit_discount_amount,
             p.benifit_copay,
             p.override_yn,
             p.override_remarks,
             p.disallowed_amount,
             p.tooth_no,
             p.internal_desc
             
      From app.pat_activity_details p
      Join app.clm_authorization_details c ON (c.claim_seq_id = p.claim_seq_id)
      Where c.clm_batch_seq_id = p_batch_seq_id;
      
    --act_details_rec   act_details_cur%ROWTYPE;
    TYPE act_typ IS TABLE OF act_details_cur%ROWTYPE;
    act_obj      act_typ;
    
    
    --Claim Observation Details
    Cursor observation_cur IS
      Select o.*
      From app.pat_observation_details o
      Join app.pat_activity_details p ON (o.activity_dtl_seq_id = p.activity_dtl_seq_id)
      Join app.clm_authorization_details c ON (c.claim_seq_id = p.claim_seq_id)
      Where c.clm_batch_seq_id = p_batch_seq_id;
      
    TYPE obsrv_typ IS TABLE OF observation_cur%ROWTYPE;
    obsrv_obj      obsrv_typ;
 
  v_count NUMBER;
    
BEGIN
  Select Count(1) INTO v_count
  From Clm_Batch_Upload_Details cb
  Where cb.clm_batch_seq_id = p_batch_seq_id;
  
  IF v_count > 0 THEN
    Select count(1)  INTO v_fin_cnt
    From Clm_Authorization_Details c
    Join Tpa_Claims_Payment cp ON cp.claim_seq_id = c.claim_seq_id
    Where c.clm_batch_seq_id = p_batch_seq_id
    And c.clm_status_type_id = 'APR';
    
    IF v_fin_cnt > 0 THEN
      RAISE_APPLICATION_ERROR(-20020, 'Cannot Delete for Completed Claim .');
    END IF;
   
    --Batch
    INSERT INTO app.clm_batch_delete_bkp (CLM_BATCH_SEQ_ID,
                                          BATCH_NO,
                                          SENDER_ID,
                                          RECEIVER_ID,
                                          RECEIVED_DATE,
                                          TRANSACTION_DATE,
                                          RECORD_COUNT,
                                          DISPOSITION_FLAG,
                                          BATCH_TOT_AMOUNT,
                                          TPA_OFFICE_AEQ_ID,
                                          BATCH_STATUS_TYPE,
                                          CLM_TYPE_GEN_TYPE_ID,
                                          SUBMISSION_TYPE_ID,
                                          ADDED_BY,
                                          ADDED_DATE,
                                          UPDATED_DATE,
                                          UPDATED_BY,
                                          CURRENCY_TYPE,
                                          SOURCE_TYPE_ID,
                                          BATCH_OVERRIDE,
                                          BENEFIT_TYPE,
                                          NETWORK_YN,
                                          PROVIDER_NAME,
                                          XML_FILE,
                                          FILE_ID,
                                          CLAIMFROM_GENTYPE_ID,
                                          PROCESS_TYPE,
                                          ONL_MOB_CLM_DOCMNTS,
                                          PARTNER_NAME,
                                          PYMNT_TO_TYPE_ID,
                                          ONL_DOC_TYP,
                                          CLM_XML_FILE,
                                          XML_SEQ_ID
                                          )
    SELECT  CLM_BATCH_SEQ_ID,
            BATCH_NO,
            SENDER_ID,
            RECEIVER_ID,
            RECEIVED_DATE,
            TRANSACTION_DATE,
            RECORD_COUNT,
            DISPOSITION_FLAG,
            BATCH_TOT_AMOUNT,
            TPA_OFFICE_AEQ_ID,
            BATCH_STATUS_TYPE,
            CLM_TYPE_GEN_TYPE_ID,
            SUBMISSION_TYPE_ID,
            ADDED_BY,
            ADDED_DATE,
            UPDATED_DATE,
            UPDATED_BY,
            CURRENCY_TYPE,
            SOURCE_TYPE_ID,
            BATCH_OVERRIDE,
            BENEFIT_TYPE,
            NETWORK_YN,
            PROVIDER_NAME,
            XML_FILE,
            FILE_ID,
            CLAIMFROM_GENTYPE_ID,
            PROCESS_TYPE,
            ONL_MOB_CLM_DOCMNTS,
            PARTNER_NAME,
            PYMNT_TO_TYPE_ID,
            ONL_DOC_TYP,
            CLM_XML_FILE,
            XML_SEQ_ID
            
 FROM app.clm_batch_upload_details b
    WHERE b.clm_batch_seq_id = p_batch_seq_id;
    
    --Hospital/Provider
    Insert Into app.clm_hospital_delete_bkp (clm_hosp_assoc_seq_id,
                                             claim_seq_id,
                                             hosp_seq_id,
                                             hosp_name,
                                             address_1,
                                             city_type_id,
                                             state_type_id,
                                             pin_code,
                                             off_phone_no_1,
                                             office_fax_no,
                                             remarks,
                                             added_by,
                                             added_date,
                                             provider_id,
                                             country_type_id,
                                             clinician_name
                                            )
                                          Select ch.clm_hosp_assoc_seq_id,
                                                 ch.claim_seq_id,
                                                 ch.hosp_seq_id,
                                                 ch.hosp_name,
                                                 ch.address_1,
                                                 ch.city_type_id,
                                                 ch.state_type_id,
                                                 ch.pin_code,
                                                 ch.off_phone_no_1,
                                                 ch.office_fax_no,
                                                 ch.remarks,
                                                 ch.added_by,
                                                 ch.added_date,
                                                 ch.provider_id,
                                                 ch.country_type_id,
                                                 ch.clinician_name
                                                 
                                            From clm_hospital_details ch
                                            Join app.clm_authorization_details c ON (ch.claim_seq_id = c.claim_seq_id)
                                            Where c.clm_batch_seq_id = p_batch_seq_id;
    
    -- Claim  
    OPEN clm_details_cur;
    FETCH clm_details_cur BULK COLLECT INTO clm_obj;
    CLOSE clm_details_cur;
    
    FORALL i IN clm_obj.FIRST.. clm_obj.LAST
      INSERT INTO app.upld_claim_bkp(claim_seq_id,
                                    clm_batch_seq_id,
                                    pat_auth_seq_id,
                                    claim_number,
                                    settlement_number,
                                    clm_received_date,
                                    source_type_id,
                                    date_of_hospitalization,
                                    date_of_discharge,
                                    claim_type,
                                    claim_sub_type,
                                    member_seq_id,
                                    tpa_enrollment_id,
                                    mem_name,
                                    mem_age,
                                    ins_seq_id,
                                    policy_seq_id,
                                    emirate_id,
                                    encounter_type_id,
                                    ava_sum_insured,
                                    currency_type,
                                    clm_status_type_id,
                                    added_by,
                                    added_date,
                                    invoice_number,
                                    requested_amount,
                                    clinician_id,
                                    system_of_medicine_type_id,
                                    network_yn,
                                    benifit_type,
                                    presenting_complaints,
                                    medical_opinion_remarks,
                                    pat_approved_amount,
                                    Lmp_Date,
                                    Conception_Type,
                                    first_incident_date,
                                    first_reported_date,
                                    AUTH_NUMBER,
                                    CONVERSION_RATE,
                                    req_amt_currency_type,
                                    SOURCE_FROM,
                                    event_no,
                                    tot_gross_amount,
                                    tot_discount_amount,
                                    tot_disc_gross_amount,
                                    tot_patient_share_amount,
                                    tot_net_amount,
                                    tot_allowed_amount,
                                    tot_approved_amount)
      VALUES (clm_obj(i).claim_seq_id,
              clm_obj(i).clm_batch_seq_id,
              clm_obj(i).pat_auth_seq_id,
              clm_obj(i).claim_number,
              clm_obj(i).settlement_number,
              clm_obj(i).clm_received_date,
              clm_obj(i).source_type_id,
              clm_obj(i).date_of_hospitalization,
              clm_obj(i).date_of_discharge,
              clm_obj(i).claim_type,
              clm_obj(i).claim_sub_type,
              clm_obj(i).member_seq_id,
              clm_obj(i).tpa_enrollment_id,
              clm_obj(i).mem_name,
              clm_obj(i).mem_age,
              clm_obj(i).ins_seq_id,
              clm_obj(i).policy_seq_id,
              clm_obj(i).emirate_id,
              clm_obj(i).encounter_type_id,
              clm_obj(i).ava_sum_insured,
              clm_obj(i).currency_type,
              clm_obj(i).clm_status_type_id,
              clm_obj(i).added_by,
              clm_obj(i).added_date,
              clm_obj(i).invoice_number,
              clm_obj(i).requested_amount,
              clm_obj(i).clinician_id,
              clm_obj(i).system_of_medicine_type_id,
              clm_obj(i).network_yn,
              clm_obj(i).benifit_type,
              clm_obj(i).presenting_complaints,
              clm_obj(i).medical_opinion_remarks,
              clm_obj(i).pat_approved_amount,
              clm_obj(i).Lmp_Date,
              clm_obj(i).Conception_Type,
              clm_obj(i).first_incident_date,
              clm_obj(i).first_reported_date,
              clm_obj(i).AUTH_NUMBER,
              clm_obj(i).CONVERSION_RATE,
              clm_obj(i).req_amt_currency_type,
              clm_obj(i).SOURCE_FROM,
              clm_obj(i).event_no,
              clm_obj(i).tot_gross_amount,
              clm_obj(i).tot_discount_amount,
              clm_obj(i).tot_disc_gross_amount,
              clm_obj(i).tot_patient_share_amount,
              clm_obj(i).tot_net_amount,
              clm_obj(i).tot_allowed_amount,
              clm_obj(i).tot_approved_amount);
      
    --- Diagnosys
    OPEN diag_cur;
    FETCH diag_cur BULK COLLECT INTO diag_obj;
    CLOSE diag_cur;
    
    FORALL i IN diag_obj.FIRST.. diag_obj.LAST
      INSERT INTO clm_diagnosys_bkp(diag_seq_id,
                                    pat_auth_seq_id,
                                    claim_seq_id,
                                    icd_code_seq_id,
                                    diagnosys_code,
                                    primary_ailment_yn,
                                    remarks,
                                    added_by,
                                    added_date
                                   )
      VALUES (diag_obj(i).diag_seq_id,
              diag_obj(i).pat_auth_seq_id,
              diag_obj(i).claim_seq_id,
              diag_obj(i).icd_code_seq_id,
              diag_obj(i).diagnosys_code,
              diag_obj(i).primary_ailment_yn,
              diag_obj(i).remarks,
              diag_obj(i).added_by,
              diag_obj(i).added_date);
      
    ---Shortfall
    OPEN shortfll_cur;
    FETCH shortfll_cur BULK COLLECT INTO shrtfll_obj;
    CLOSE shortfll_cur;
    
    FORALL i IN shrtfll_obj.FIRST.. shrtfll_obj.LAST
      INSERT INTO app.shortfall_details_bkp(shortfall_seq_id,
                                            pat_gen_detail_seq_id,
                                            claim_seq_id,
                                            shortfall_id,
                                            srtfll_general_type_id,
                                            srtfll_sent_date,
                                            srtfll_reason_general_type_id,
                                            remarks,
                                            shortfall_questions,
                                            added_by,
                                            added_date,
                                            updated_date,
                                            updated_by,             
                                            reminder_count,
                                            closed_date,
                                            shortfall_raised_by,
                                            uploaded_file)
                                            
      VALUES (shrtfll_obj(i).shortfall_seq_id,
              shrtfll_obj(i).pat_gen_detail_seq_id,
              shrtfll_obj(i).claim_seq_id,
              shrtfll_obj(i).shortfall_id,
              shrtfll_obj(i).srtfll_general_type_id,
              shrtfll_obj(i).srtfll_sent_date,
              shrtfll_obj(i).srtfll_reason_general_type_id,
              shrtfll_obj(i).remarks,
              shrtfll_obj(i).shortfall_questions,
              shrtfll_obj(i).added_by,
              shrtfll_obj(i).added_date,
              shrtfll_obj(i).updated_date,
              shrtfll_obj(i).updated_by,             
              shrtfll_obj(i).reminder_count,
              shrtfll_obj(i).closed_date,
              shrtfll_obj(i).shortfall_raised_by,
              shrtfll_obj(i).uploaded_file);
      
    ---Activity
    OPEN act_details_cur;
    FETCH act_details_cur BULK COLLECT INTO act_obj;
    CLOSE act_details_cur;
    
    FORALL i IN act_obj.FIRST.. act_obj.LAST
      INSERT INTO app.pat_activity_delete_bkp(activity_dtl_seq_id,
                                              pat_auth_seq_id,
                                              claim_seq_id,
                                              activity_id,
                                              activity_seq_id,
                                              s_no,
                                              start_date,
                                              activity_type,
                                              code,
                                              unit_type,
                                              clinician_id,
                                              internal_code,
                                              quantity,
                                              allow_yn,
                                              gross_amount,
                                              discount_amount,
                                              disc_gross_amount,
                                              copay_perc,
                                              copay_amount,
                                              deduct_amount,
                                              patient_share_amount,
                                              net_amount,
                                              allowed_amount,
                                              approved_amount,
                                              currency_type,
                                              denial_code,
                                              remarks,
                                              added_by,
                                              added_date,
                                              updated_by,
                                              updated_date,
                                              service_type,
                                              service_code,
                                              benifit_deductible,
                                              unit_discount_amount,
                                              benifit_copay,
                                              override_yn,
                                              override_remarks,
                                              disallowed_amount,
                                              tooth_no,
                                              internal_desc)
      VALUES (act_obj(i).activity_dtl_seq_id,
              act_obj(i).pat_auth_seq_id,
              act_obj(i).claim_seq_id,
              act_obj(i).activity_id,
              act_obj(i).activity_seq_id,
              act_obj(i).s_no,
              act_obj(i).start_date,
              act_obj(i).activity_type,
              act_obj(i).code,
              act_obj(i).unit_type,
              act_obj(i).clinician_id,
              act_obj(i).internal_code,
              act_obj(i).quantity,
              act_obj(i).allow_yn,
              act_obj(i).gross_amount,
              act_obj(i).discount_amount,
              act_obj(i).disc_gross_amount,
              act_obj(i).copay_perc,
              act_obj(i).copay_amount,
              act_obj(i).deduct_amount,
              act_obj(i).patient_share_amount,
              act_obj(i).net_amount,
              act_obj(i).allowed_amount,
              act_obj(i).approved_amount,
              act_obj(i).currency_type,
              act_obj(i).denial_code,
              act_obj(i).remarks,
              act_obj(i).added_by,
              act_obj(i).added_date,
              act_obj(i).updated_by,
              act_obj(i).updated_date,
              act_obj(i).service_type,
              act_obj(i).service_code,
              act_obj(i).benifit_deductible,
              act_obj(i).unit_discount_amount,
              act_obj(i).benifit_copay,
              act_obj(i).override_yn,
              act_obj(i).override_remarks,
              act_obj(i).disallowed_amount,
              act_obj(i).tooth_no,
              act_obj(i).internal_desc);
      
    ---Observation
    OPEN observation_cur;
    FETCH observation_cur BULK COLLECT INTO obsrv_obj;
    CLOSE observation_cur;
    
    FORALL i IN obsrv_obj.FIRST.. obsrv_obj.LAST
      INSERT INTO app.pat_observation_delete_bkp
      VALUES obsrv_obj (i);
      
    -------------------------------------------------
    
    OPEN clm_details_cur;
    FETCH clm_details_cur BULK COLLECT INTO clm_obj;
    CLOSE clm_details_cur;
    
    
    FORALL i IN clm_obj.FIRST.. clm_obj.LAST
       Update Clm_Authorization_Details c
       Set c.assign_user_seq_id = null
       Where c.claim_seq_id = clm_obj(i).claim_seq_id;
    
    FORALL i IN clm_obj.FIRST.. clm_obj.LAST
       --IF clm_obj(3).pat_auth_seq_id IS NOT NULL THEN
         Update Clm_Authorization_Details a
         set a.auth_number = null,
             a.pat_auth_seq_id = null
         where a.claim_seq_id = clm_obj(i).claim_seq_id;
       --END IF;
    FORALL i IN clm_obj.FIRST.. clm_obj.LAST   
         Update pat_authorization_details p
         set p.claim_seq_id = null
         where p.claim_seq_id = clm_obj(i).claim_seq_id;
    
    FORALL i IN clm_obj.FIRST.. clm_obj.LAST   
       Delete from Assign_Users u
       Where u.claim_seq_id = clm_obj(i).claim_seq_id;
    
    FORALL i IN clm_obj.FIRST.. clm_obj.LAST  
       Delete From Pat_Observation_Details od
       Where od.activity_dtl_seq_id in 
            (Select ad.activity_dtl_seq_id
             From pat_activity_details ad
             Where ad.claim_seq_id = clm_obj(i).claim_seq_id);
    
    FORALL i IN clm_obj.FIRST.. clm_obj.LAST        
       Delete From Pat_Activity_Details ad
       Where ad.claim_seq_id = clm_obj(i).claim_seq_id;
    
    FORALL i IN clm_obj.FIRST.. clm_obj.LAST    
       Delete From Diagnosys_Details d 
       Where d.claim_seq_id = clm_obj(i).claim_seq_id;
    
    FORALL i IN clm_obj.FIRST.. clm_obj.LAST   
       Delete from Shortfall_Details s
       Where s.claim_seq_id = clm_obj(i).claim_seq_id;
    
    FORALL i IN clm_obj.FIRST.. clm_obj.LAST  
       Delete From Clm_Hospital_Details h 
       Where h.claim_seq_id = clm_obj(i).claim_seq_id;
    
    FORALL i IN clm_obj.FIRST.. clm_obj.LAST   
       Delete Clm_Authorization_Details cl
       Where cl.clm_batch_seq_id = clm_obj(i).clm_batch_seq_id;
       
    FORALL i IN clm_obj.FIRST.. clm_obj.LAST   
       Delete Clm_Batch_Upload_Details b 
       Where b.clm_batch_seq_id = clm_obj(i).clm_batch_seq_id;
    
    commit;
  END IF;
  
END delt_failed_batch;
--===============================================================================================
--Converting Claim Upload xls into xml Conversion

--================================================================================================
PROCEDURE Online_Claim_submit_xml (v_clm_in_xl       IN XMLTYPE,
                                   p_bat_seq_id     OUT VARCHAR2,
                                   v_batch_number  OUT VARCHAR2
                                  )
  AS
  v_clm_details     CLM_AUTHORIZATION_DETAILS%ROWTYPE;
  v_act_details     PAT_ACTIVITY_DETAILS%ROWTYPE;
  v_diag_details    DIAGNOSYS_DETAILS%ROWTYPE;
  v_clm_upload_doc  DBMS_XMLDOM.DOMDocument;
  v_parent_node     DBMS_XMLDOM.DOMNode;
  v_child_node      DBMS_XMLDOM.DOMNode;
  v_hosp_node       DBMS_XMLDOM.DOMNodeList;
  v_clm_nodes       DBMS_XMLDOM.DOMNodeList;
  v_element         DBMS_XMLDOM.DOMElement;
  v_element1        DBMS_XMLDOM.DOMELement;
  v_sys_med         VARCHAR2(100);
  v_enr_id          VARCHAR2(100);
  v_nat_concep      VARCHAR2(100);
  v_pre_auth_num    VARCHAR2(100);
  v_prim_icd        VARCHAR2(100); 
  v_prim_icd_desc   VARCHAR2(2000);
  v_fisr_icd        VARCHAR2(500);
  v_secn_icd        VARCHAR2(500);
  v_thir_icd        VARCHAR2(500);
  v_four_icd        VARCHAR2(500);
  v_fift_icd        VARCHAR2(500); 
  v_hos_seq_id      VARCHAR2(500);
  v_added_by        VARCHAR2(500);
  v_rec_date        VARCHAR2(500);
  v_source_type     VARCHAR2(500);
  v_batch_no        VARCHAR2(500);
  v_hosp_name       VARCHAR2(1000);
  v_hosp_licence    VARCHAR2(200);
  v_observation     VARCHAR2(500);
  v_encounter_type  VARCHAR2(500);
  v_date_of_hosp    VARCHAR2(500);
  v_date_of_dis     VARCHAR2(500);
  v_lmp_date        VARCHAR2(500);
  v_first_incident_date  VARCHAR2(500);
  v_first_reported_date  VARCHAR2(500);
  v_start_date           VARCHAR2(500);
  v_sl_no                VARCHAR2(500);
  v_Clinician_name       VARCHAR2(3000);
  v_xml_rec_count        VARCHAR2(100);
  v_prim_icd_cm        VARCHAR2(500); 
  v_fisr_icd_cm        VARCHAR2(500);
  v_secn_icd_cm        VARCHAR2(500);
  v_thir_icd_cm        VARCHAR2(500);
  v_four_icd_cm       VARCHAR2(500);
  v_fift_icd_cm        VARCHAR2(500);
  v_err_seq_id         number(10);
  v_succ_count         NUMBER(10);
  v_fail_count         NUMBER(10);
  v_error_log          SYS_REFCURSOR;
  
  CURSOR hosp_cur IS
    SELECT th.hosp_name, th.hosp_licenc_numb
           FROM Tpa_Hosp_Info th
           WHERE th.hosp_seq_id = v_hos_seq_id;
    
  CURSOR icd_convers_cur(v_icd varchar2) is
    SELECT m.icd_cm  
           FROM APP.TPA_ICD_AM_DETAILS m
           WHERE m.Icd_Am=v_icd;  
           
   v_xml_seq_id  NUMBER(10);
   v_sql_code                      VARCHAR2(100);
   v_sql_msg                       VARCHAR2(4000);
    v_start_time           NUMBER;
    V_LG_SEQ_ID            NUMBER(10);
    v_rec_cnt              NUMBER(10):= 0;
          
 BEGIN
   /*
   BEGIN
   claim_bulk_upload.claim_upload(v_xml_seq_id => v_xml_seq_id,v_clm_in_xl => v_clm_in_xl,v_added_by => 1);
    EXCEPTION
      WHEN OTHERS THEN
        v_sql_code := SQLCODE;
        v_sql_msg  := SQLERRM;
        claim_bulk_upload_test.save_exception_log(v_xml_seq_id => v_xml_seq_id,v_clm_xml_seq_id => NULL,
                                                  v_sql_code => v_sql_code,
                                                  v_sql_msg => v_sql_msg,v_bulk_eror_msg => NULL,v_added_by => 1);
   
   END; *//*
INSERT INTO INTX.TEMP_CLM_BULK_UPLD_LOGS(LOG_SEQ_ID,XML_SEQ_ID,ADDED_DATE) 
                                 VALUES (app.TEMP_BULK_CLM_SEQ.NEXTVAL,v_xml_seq_id,SYSDATE)
                                 RETURNING LOG_SEQ_ID INTO V_LG_SEQ_ID;
COMMIT;*/
   v_start_time := DBMS_UTILITY.get_time;
 
  
  v_clm_upload_doc := Dbms_xmldom.newDOMDocument(v_clm_in_xl);
    v_hosp_node :=Dbms_xmldom.getElementsByTagName(v_clm_upload_doc,'claimsUpload');
    
 for v_parent_list in 0.. dbms_xmldom.getlength(v_hosp_node) - 1 loop
   
   v_parent_node:=Dbms_xmldom.item(v_hosp_node,v_parent_list);
   v_element :=Dbms_xmldom.makeElement(v_parent_node);
   
   v_hos_seq_id  := Dbms_Xmldom.getAttribute(v_element,'hospSeqId');
   v_added_by    :=Dbms_Xmldom.getAttribute(v_element,'addedBy');
   v_rec_date    :=Dbms_xmldom.getAttribute(v_element,'receivedDate');
   v_source_type :=Dbms_Xmldom.getAttribute(v_element,'sourceType');
  -- v_xml_rec_count :=Dbms_Xmldom.getAttribute(v_element,'count');
   
   OPEN hosp_cur;
   FETCH hosp_cur INTO v_hosp_name,v_hosp_licence;
   CLOSE hosp_cur;
   
   clm_xml_load_pkg.save_clm_batch_details( p_bat_seq_id,
                                            v_batch_no,
                                            v_hosp_licence,
                                            'ALK01',
                                            CASE WHEN v_source_type='PCLM' THEN to_date(rtrim(v_rec_date,'.0'),'RRRR-MM-DD HH24:MI:SS')
                                                 WHEN v_source_type='PLCL' THEN SYSDATE END,
                                            NULL,--v_xml_rec_count,
                                            NULL,
                                            '1',
                                            'COMP',
                                            NULL,
                                           'CNH',
                                           'DTC',
                                           'QAR',
                                           v_source_type,
                                           1
                                          );
    
   
   save_time_details(V_LG_SEQ_ID,'BATCH_END',v_start_time);
   
                                         
   select cbu.batch_no into v_batch_number
    from clm_batch_upload_details cbu where cbu.clm_batch_seq_id=p_bat_seq_id;   
  /*  
   update APP.clm_batch_upload_details
     set clm_xml_file=v_clm_in_xl
   where  clm_batch_seq_id=p_bat_seq_id;    */
   
   INSERT INTO APP.temp_clm_uploaded_xml(v_clm_file,v_batch_no,HOSP_SEQ_ID) VALUES  (v_clm_in_xl,p_bat_seq_id,v_hos_seq_id);                                 
   
  end loop; 
  
  v_clm_nodes :=Dbms_xmldom.getElementsByTagName(v_element,'claimsData');
  
   v_start_time := DBMS_UTILITY.get_time;
   
  for v_claim_index in 0..dbms_xmldom.getlength(v_clm_nodes) - 1 loop
    v_rec_cnt       := 1;
    v_child_node:=Dbms_xmldom.item(v_clm_nodes,v_claim_index);
    v_element1:=Dbms_xmldom.makeElement(v_child_node);
    --Reseting All VAriables
      v_clm_details.clinician_id:= null;
      v_Clinician_name :=null;
      v_sys_med:=null;
      v_clm_details.invoice_number:=null;
      v_enr_id:=null;
      v_clm_details.mem_name:=null;
      v_clm_details.benifit_type:=null;
      v_clm_details.event_no:=null;
      v_nat_concep :=null;
      v_pre_auth_num:=null;
      v_clm_details.presenting_complaints:=null;
      v_encounter_type:=null;
      v_clm_details.event_no:=null;
      ---icds
       v_prim_icd:=null;
      v_prim_icd_desc:=null;
      v_fisr_icd:=null;
      v_secn_icd:=null;
      v_thir_icd:=null;
      v_four_icd:=null;
      v_fift_icd:=null;
      --coversion icds
      v_fisr_icd_cm:=null;
      v_secn_icd_cm:=null;
      v_thir_icd_cm:=null;
      v_four_icd_cm:=null;
      v_fift_icd_cm:=null;
      v_prim_icd_cm:=null;
      ---
      v_act_details.quantity:=null;
      v_act_details.activity_type_id:=null;
      v_act_details.gross_amount:=null;
      v_act_details.code:=null;
      v_act_details.internal_code:=null;
      v_act_details.internal_desc:=null;
      v_act_details.tooth_no:=null;
      v_observation:=null;
      v_date_of_hosp :=null;
      v_date_of_dis:=null;
      v_lmp_date:=null;
      v_first_incident_date:=null;
      v_first_reported_date:=null;
      v_start_date:=null;
    
    --claim Details
      v_clm_details.clinician_id:=Dbms_xmldom.getAttribute(v_element1,'clinicianId');
      v_Clinician_name :=Dbms_xmldom.getAttribute(v_element1,'clinicianName');
      v_sys_med:=Dbms_xmldom.getAttribute(v_element1,'sysOfMed');
      v_clm_details.invoice_number:=Dbms_xmldom.getAttribute(v_element1,'invNo');
      v_enr_id:=Dbms_xmldom.getAttribute(v_element1,'memId');
      v_clm_details.mem_name:=Dbms_xmldom.getAttribute(v_element1,'memName');
      v_clm_details.benifit_type:=Dbms_xmldom.getAttribute(v_element1,'benType');
      v_clm_details.event_no:=Dbms_xmldom.getAttribute(v_element1,'evntRefNo');
      v_nat_concep := Dbms_xmldom.getAttribute(v_element1,'natOfConep');
      v_pre_auth_num:=Dbms_xmldom.getAttribute(v_element1,'preAprNo');
      v_clm_details.presenting_complaints:=Dbms_Xmldom.getAttribute(v_element1,'symptoms');
      v_encounter_type:=Dbms_xmldom.getAttribute(v_element1,'encType');
      v_clm_details.event_no:=Dbms_Xmldom.getAttribute(v_element1,'evntRefNo');
     
           
    --DIAGNONYSYS RELATED
      v_prim_icd:=Dbms_xmldom.getAttribute(v_element1,'princiICdCode');
      v_prim_icd_desc:=Dbms_xmldom.getAttribute(v_element1,'princiICDesc');
      v_fisr_icd:=Dbms_xmldom.getAttribute(v_element1,'secIcd1');
      v_secn_icd:=Dbms_xmldom.getAttribute(v_element1,'secIcd2');
      v_thir_icd:=Dbms_xmldom.getAttribute(v_element1,'secIcd3');
      v_four_icd:=Dbms_xmldom.getAttribute(v_element1,'secIcd4');
      v_fift_icd:=Dbms_xmldom.getAttribute(v_element1,'secIcd5');
      
    --ACTIVITY RELATED
      v_act_details.quantity:=Dbms_xmldom.getAttribute(v_element1,'qty');
      v_act_details.activity_type_id:=Dbms_xmldom.getAttribute(v_element1,'actType');
      v_act_details.gross_amount:=Dbms_xmldom.getAttribute(v_element1,'amntClmnd');
      v_act_details.code:=Dbms_xmldom.getAttribute(v_element1,'cptCode');
      v_act_details.internal_code:=Dbms_xmldom.getAttribute(v_element1,'internalCode');
      v_act_details.internal_desc:=Dbms_xmldom.getAttribute(v_element1,'servDesc');
      v_act_details.tooth_no:=Dbms_Xmldom.getAttribute(v_element1,'toothNo');
      v_observation:=Dbms_xmldom.getAttribute(v_element1,'observtn');
      
      --ALL DATE RELATED FIELDS
      v_date_of_hosp :=Dbms_xmldom.getAttribute(v_element1,'dtOfTrtmt');
      v_date_of_dis:=Dbms_xmldom.getAttribute(v_element1,'dtDisch');
      v_lmp_date:=Dbms_xmldom.getAttribute(v_element1,'dtOfLMP');
      v_first_incident_date:=Dbms_Xmldom.getAttribute(v_element1,'firstIncDt');
      v_first_reported_date:=Dbms_Xmldom.getAttribute(v_element1,'firstRepDt');
      v_start_date:=Dbms_Xmldom.getAttribute(v_element1,'servDt');
      v_sl_no:=NVL(v_sl_no,0)+1;
      
----converting icd_am to icd_cms

   IF v_prim_icd IS NOT NULL THEN
     open icd_convers_cur (trim(v_prim_icd));
       fetch icd_convers_cur into v_prim_icd_cm;
        close icd_convers_cur;
   END IF;
   
   
   IF v_fisr_icd IS NOT NULL THEN
     open icd_convers_cur(trim(v_fisr_icd));
       fetch icd_convers_cur into v_fisr_icd_cm;
        close icd_convers_cur;
   END IF;
   
   
   IF v_secn_icd IS NOT NULL THEN
   open icd_convers_cur(trim(v_secn_icd));
       fetch icd_convers_cur into v_secn_icd_cm;
        close icd_convers_cur;
   END IF;
   
   
   IF v_thir_icd IS NOT NULL THEN
     open icd_convers_cur(trim(v_thir_icd));
       fetch icd_convers_cur into v_thir_icd_cm;
        close icd_convers_cur;
   END IF;
   
   
   IF v_four_icd IS NOT NULL THEN
     open icd_convers_cur(trim(v_four_icd));
       fetch icd_convers_cur into v_four_icd_cm;
        close icd_convers_cur;
   END IF;
   
   
   IF v_fift_icd IS NOT NULL THEN
     open icd_convers_cur(trim(v_fift_icd));
       fetch icd_convers_cur into v_fift_icd_cm;
        close icd_convers_cur;
   END IF;
   
     
      
      online_clm_submit(p_bat_seq_id,
                        v_hos_seq_id,
                        v_added_by,
                        v_sl_no,
                        v_clm_details.invoice_number,
                        v_clm_details.mem_name,
                        v_enr_id,
                        v_pre_auth_num,
                        v_date_of_hosp,
                        v_date_of_dis,
                        trim(v_sys_med),
                        v_clm_details.benifit_type,
                        v_encounter_type,
                        v_clm_details.clinician_id,
                        v_Clinician_name,
                        v_clm_details.presenting_complaints,
                        trim(NVL(v_prim_icd_cm,v_prim_icd)),
                        v_prim_icd_desc,
                        trim(NVL(v_fisr_icd_cm,v_fisr_icd)),
                        trim(NVL(v_secn_icd_cm,v_secn_icd)),
                        trim(NVL(v_thir_icd_cm,v_thir_icd)),
                        trim(NVL(v_four_icd_cm,v_four_icd)),
                        trim(NVL(v_fift_icd_cm,v_fift_icd)),
                        v_first_incident_date,
                        v_first_reported_date,
                        v_start_date,
                        v_act_details.activity_type_id,
                        v_act_details.internal_code,
                        v_act_details.internal_desc,
                        v_act_details.code,
                        v_act_details.gross_amount,
                        v_act_details.quantity,
                        v_act_details.tooth_no,
                        v_lmp_date,
                        v_nat_concep,
                        v_observation,
                        v_clm_details.event_no
                        );
   
   save_time_details(V_LG_SEQ_ID,'CLM_CNT' ,v_rec_cnt);
   
   end loop; 
   
   save_time_details(V_LG_SEQ_ID,'CLM_UPLD' ,v_start_time);
   
  exception
  when others then
   v_error_message := sqlerrm||CHR(10)||sqlcode;
   Create_error_log(-20021, v_error_message, v_dependent_count);


IF v_upload_error_message IS NOT NULL THEN
      save_error_log(v_err_seq_id,
                     v_sl_no,
                      v_clm_details.invoice_number,
                      v_clm_details.mem_name,
                     v_enr_id,
                     v_pre_auth_num,
                     v_date_of_hosp,
                     v_date_of_dis,
                     v_sys_med,
                     v_clm_details.benifit_type,
                     v_encounter_type,
                     v_clm_details.clinician_id,
                     null,
                     v_clm_details.presenting_complaints,
                     v_prim_icd_cm,
                     v_prim_icd_desc,
                     v_fisr_icd_cm,
                     v_secn_icd_cm,
                     v_thir_icd_cm,
                     v_four_icd_cm,
                     v_fift_icd_cm,
                     v_first_incident_date,
                     v_first_reported_date,
                     v_start_date,
                     v_act_details.internal_code,
                     v_act_details.internal_desc,
                     v_act_details.code,
                     v_act_details.gross_amount,
                     v_act_details.quantity,
                     v_act_details.tooth_no,
                     v_lmp_date,
                     v_nat_concep,
                     v_observation,	
                     v_error_message,
                     v_upload_error_message,
                     p_bat_seq_id,
                     1,
                     null
                    );
                    
   online_clm_submitted_data(p_bat_seq_id,v_error_log,v_fail_count, v_succ_count);  
    END IF;
   
 END Online_Claim_submit_xml; 
 --====================================================================================================
 PROCEDURE Claim_Payment_Details (v_claim_seq_id      IN NUMBER,
                                  v_result_set        OUT SYS_REFCURSOR)
  AS
 BEGIN
   OPEN V_RESULT_SET FOR
    SELECT TTK_UTIL_PKG.FN_DECRYPT(PAY.PAYEE_NAME) as PAYEE_NAME,
          nvl(CC.CHECK_NUM,'-') as CHECK_NUM,CC.CHECK_AMOUNT,
          nvl(GEN.DESCRIPTION,'-') as PAYEE_TYPE,to_char(CC.CHECK_DATE,'DD-MM-YYYY') as CHECK_DATE,
         pay.claim_payment_status as CHECK_STATUS ,
          '-' AS CONSIGNMENT_NUM,'-' AS CONSIGNMENT_PROV , '-' AS DISPATCHED_DATE,
          cad.req_amt_currency_type AS INCURRED_CURRENCY,
          pay.transfer_currency AS TRANSFERRED_CURRENCY
        FROM FIN_APP.TPA_CLAIMS_PAYMENT PAY
        LEFT OUTER JOIN  APP.CLM_AUTHORIZATION_DETAILS CAD ON (PAY.CLAIM_SEQ_ID=CAD.CLAIM_SEQ_ID)
        LEFT OUTER JOIN FIN_APP.TPA_PAYMENT_CHECKS_DETAILS PCAD ON (PCAD.PAYMENT_SEQ_ID=PAY.PAYMENT_SEQ_ID)
        LEFT OUTER JOIN FIN_APP.TPA_CLAIMS_CHECK CC ON (CC.CLAIMS_CHK_SEQ_ID=PCAD.CLAIMS_CHK_SEQ_ID)
        LEFT OUTER JOIN APP.TPA_GENERAL_CODE GEN ON (GEN.GENERAL_TYPE_ID=PAY.PAYEE_TYPE)
        WHERE PAY.CLAIM_SEQ_ID=v_claim_seq_id  /*and cc.check_status='CSI'*/;
         
 END;                                 
--======================================================================================================
PROCEDURE save_time_details(v_LOG_seq_id            IN NUMBER,
                            v_flag                  IN VARCHAR2,
                            v_start_time            IN NUMBER)
IS
PRAGMA AUTONOMOUS_TRANSACTION;
BEGIN
  
  IF v_flag = 'XML_READ' THEN
    UPDATE INTX.TEMP_CLM_BULK_UPLD_LOGS X
      SET X.xml_read_end_time = (dbms_utility.get_time - v_start_time)/100
    WHERE X.LOG_SEQ_ID = v_LOG_seq_id;
  ELSIF v_flag = 'BATCH_END' THEN
    UPDATE INTX.TEMP_CLM_BULK_UPLD_LOGS X
     SET X.batch_end_time = (dbms_utility.get_time - v_start_time)/100
    WHERE X.LOG_SEQ_ID = v_LOG_seq_id;
  ELSIF v_flag = 'CLM_CNT' THEN  
    UPDATE INTX.TEMP_CLM_BULK_UPLD_LOGS X
     SET X.CLAIM_UPLD_CNT = NVL(CLAIM_UPLD_CNT,0) + v_start_time
    WHERE X.LOG_SEQ_ID = v_LOG_seq_id;
  ELSIF v_flag = 'CLM_UPLD' THEN  
    UPDATE INTX.TEMP_CLM_BULK_UPLD_LOGS X
     SET X.clm_upld_time = (dbms_utility.get_time - v_start_time)/100
    WHERE X.LOG_SEQ_ID = v_LOG_seq_id;
  
  END IF;
    
 COMMIT;   
    
END save_time_details;

-------------------------------------------------------
PROCEDURE internal_remark_stat_save(v_pat_clm_seq_id     IN NUMBER,
                                    v_code          IN VARCHAR2,
                                    v_user_id       IN VARCHAR2,
                                    v_code_remarks  IN VARCHAR2,
                                    v_suspect_veri_check IN CHAR,
                                    v_risk_level         IN VARCHAR2,  --- added in CFD module Cr
                                    v_mode               IN VARCHAR2,  --- added in CFD module Cr
                                    v_rows_processed     OUT NUMBER     --- added in CFD module Cr
                                    )
IS
CURSOR USER_INFO_CUR IS  
            select li.user_id,uc.contact_seq_id,uc.user_general_type_id,uc.contact_name from 
                tpa_login_info li join tpa_user_contacts uc on (li.contact_seq_id=uc.contact_seq_id)
                                      where li.user_id=trim(v_user_id);

user_info_rec USER_INFO_CUR%ROWTYPE;

v_completed_yn VARCHAR2(2);
v_status   VARCHAR2(5);
v_seq_id    NUMBER(10);
v_clm_type VARCHAR2(5);
v_int_status varchar2(5);
v_dest_msg_seq_id VARCHAR2(250);
BEGIN
    
  IF v_mode = 'PAT' THEN
       SELECT completed_yn,pat_status_type_id,status_code_id into v_completed_yn,v_status,v_int_status from pat_authorization_details  where pat_auth_seq_id = v_pat_clm_seq_id;
    
    IF v_status not in( 'APR','PCO','PCN','REJ')/* and (v_completed_yn='N' or  v_completed_yn is null)*/ and v_code is not null THEN
     OPEN USER_INFO_CUR;
     FETCH  USER_INFO_CUR INTO user_info_rec;
     CLOSE USER_INFO_CUR;
     
          authorization_pkg.reassign_user('|'||v_pat_clm_seq_id||'|',null,null,user_info_rec.contact_seq_id,null,v_seq_id);
  
           update pat_authorization_details 
            set STATUS_CODE_ID = upper(v_code),
                CODE_ADDED_BY  = user_info_rec.contact_seq_id,
                CODE_REMARKS   = case when v_code_remarks is null then code_remarks else v_code_remarks end,  
                RISK_LEVEL     = v_risk_level,                                  
                CODE_ADDED_DATE=SYSDATE,
                SUSPECT_VERI_CHECK = case when v_int_status <> 'SUSP' THEN TRIM(v_suspect_veri_check) ELSE SUSPECT_VERI_CHECK END WHERE pat_auth_seq_id = v_pat_clm_seq_id;
                
             v_rows_processed := SQL%ROWCOUNT;
             commit;
     
         IF v_int_status IS NULL AND v_code = 'SUSP' then
             GENERATE_MAIL_PKG.proc_generate_message('PAT_SUSPECT_TAG',
                                                      v_pat_clm_seq_id,
                                                      user_info_rec.contact_seq_id,
                                                      v_dest_msg_seq_id);
         END IF;
     END IF;
           
  ELSIF v_mode = 'CLM' THEN
    
    SELECT completed_yn,clm_status_type_id,claim_type,status_code_id into v_completed_yn,v_status,v_clm_type,v_int_status from clm_authorization_details clm where clm.claim_seq_id=v_pat_clm_seq_id;
    
         IF v_status not in( 'APR','PCO','PCN','REJ')/* and (v_completed_yn='N' or  v_completed_yn is null)*/ and v_code is not null THEN
           OPEN USER_INFO_CUR;
           FETCH  USER_INFO_CUR INTO user_info_rec;
           CLOSE USER_INFO_CUR;
           
          authorization_pkg.reassign_user(null,'|'||v_pat_clm_seq_id||'|',null,user_info_rec.contact_seq_id,null,v_seq_id);
         
    update clm_authorization_details 
    set STATUS_CODE_ID = upper(v_code),
        CODE_ADDED_BY  = user_info_rec.contact_seq_id,
                CODE_REMARKS   = case when v_code_remarks is null then code_remarks else v_code_remarks end,    
                RISK_LEVEL     = v_risk_level,
        CODE_ADDED_DATE=SYSDATE,
                SUSPECT_VERI_CHECK = case when v_int_status <> 'SUSP' THEN TRIM(v_suspect_veri_check) ELSE SUSPECT_VERI_CHECK END WHERE claim_seq_id=v_pat_clm_seq_id;
                                                                             
                    v_rows_processed := SQL%ROWCOUNT;
     commit;
           
               IF v_int_status IS NULL AND v_code = 'SUSP' and (v_risk_level IN ('LR','IR','HR') and v_clm_type = 'CTM') OR (v_risk_level = 'HR' and v_clm_type = 'CNH')   then
                     IF v_clm_type = 'CNH' THEN
                       GENERATE_MAIL_PKG.proc_generate_message('NETCLM_SUSPECT_TAG',
                                                                v_pat_clm_seq_id,
                                                                user_info_rec.contact_seq_id,
                                                                v_dest_msg_seq_id);
                     ELSIF v_clm_type = 'CTM' THEN
                        GENERATE_MAIL_PKG.proc_generate_message('RECLM_SUSPECT_TAG',
                                                                v_pat_clm_seq_id,
                                                                user_info_rec.contact_seq_id,
                                                                v_dest_msg_seq_id);
     END IF;
                END IF;
           END IF;
     END IF;

END  internal_remark_stat_save;
-------------------------------------------------------------------------------------------------
PROCEDURE dn_ld_clm_dtls(   p_member_seq_id         IN        clm_Authorization_Details.member_seq_id%TYPE,
                            p_flag                  IN        VARCHAR2, 
                            v_alkood_id             IN        tpa_enr_policy_member.tpa_enrollment_id%TYPE,
                            v_policy_seq_id         IN        tpa_enr_policy.policy_seq_id%TYPE,
                            v_benefit_type          IN        clm_Authorization_Details.Benifit_Type%TYPE,
                            pat_clm_resultset       OUT       SYS_REFCURSOR
                          )
                               
   as

     begin
     if p_flag ='CLM' THEN
          open pat_clm_resultset for
           with primary_icd as(
            SELECT ca.claim_seq_id,
            listagg(dd.DIAGNOSYS_CODE,'/') within group (order by DIAGNOSYS_CODE) SECONDARY_ICD_CODE,
            listagg(y.SHORT_DESC,'/') within group (order by DIAGNOSYS_CODE) SECONDARY_ICD_CODE_DESCRIPTION
            FROM app.clm_authorization_details ca               
            join  APP.diagnosys_details DD  on ca.claim_seq_id=dd.claim_seq_id
            left JOIN  APP.TPA_ICD10_MASTER_DETAILS Y ON (DD.diagnosys_code=Y.ICD_CODE)
            WHERE DD.PRIMARY_AILMENT_YN='N'
            and ca.tpa_enrollment_id=v_alkood_id and ca.policy_seq_id =v_policy_seq_id
            and (ca.benifit_type =v_benefit_type or v_benefit_type is null)
            group by ca.claim_seq_id
            )
        select
     ep.policy_number,
     EPM.tpa_enrollment_id ALKOOT_ID,
   --pad.tpa_enrollment_id ALKOOT_ID,
     tepm.mem_name ||' '|| tepm.mem_last_name||' '|| tepm.family_name as MEMBER_NAME,
     NVL(CC.COUNTRY_NAME, dc.COUNTRY_NAME) PROVIDER_COUNTRY,
     NVL(thi.hosp_name,hd.HOSP_NAME) NAME_OF_PROVIDER,
   --NVL(CC.COUNTRY_NAME, dc.COUNTRY_NAME) PROVIDER_COUNTRY,
      --dC.COUNTRY_NAME PROVIDER_COUNTRY, 
     PAD.INVOICE_NUMBER,
   --to_char(PD.START_DATE,'dd/mm/yyyy  hh:mm:ss AM')  SERVICE_DATE,
      --to_char(PD.START_DATE,'dd/mm/yyyy  hh:mm:ss AM')  SERVICE_DATE,
    -- PAD.CLM_RECEIVED_DATE SERVICE_DATE,
       ( SELECT 
               TO_CHAR(replace(wm_concat(DIAGNOSYS_CODE),',','/')) 
                 --DIAGNOSYS_CODE             
                 FROM APP.diagnosys_details DD 
                 join app.clm_authorization_details ca on ca.claim_seq_id=dd.claim_seq_id
                 left JOIN  APP.TPA_ICD10_MASTER_DETAILS Y ON (DD.diagnosys_code=Y.ICD_CODE)                 
                WHERE DD.PRIMARY_AILMENT_YN='Y'
                and ca.member_seq_id=pad.member_seq_id and ca.claim_seq_id=pad.claim_seq_id ) PRIMARY_ICD_CODE,
        ( SELECT                 
                listagg(y.SHORT_DESC,'/') within group (order by SHORT_DESC)
                 FROM APP.diagnosys_details DD 
                 join app.clm_authorization_details ca on ca.claim_seq_id=dd.claim_seq_id
                 left JOIN  APP.TPA_ICD10_MASTER_DETAILS Y ON (DD.diagnosys_code=Y.ICD_CODE)                 
                WHERE DD.PRIMARY_AILMENT_YN='Y'
                and ca.member_seq_id=pad.member_seq_id and ca.claim_seq_id=pad.claim_seq_id ) PRIMARY_ICD_CODE_DESCRIPTION,
     pi.SECONDARY_ICD_CODE,
     pi.SECONDARY_ICD_CODE_DESCRIPTION,
     to_char(PD.START_DATE,'dd/mm/yyyy  hh:mm:ss AM')  SERVICE_DATE,
     pd.code ACTIVITY_CODE,
     am.short_description ACTIVITY_DESCRIPTION,
     pd.INTERNAL_CODE INTERNAL_CODE,
     pd.INTERNAL_DESC INTERNAL_DESCRIPTION,
    -- pd.INTERNAL_CODE INTERNAL_CODE,
    -- pd.INTERNAL_DESC INTERNAL_DESCRIPTION,
     pd.TOOTH_NO TOOTH_NUMBER,
    -- to_char(pad.LMP_DATE ,'dd/mm/yyyy  hh:mm:ss AM')  DATE_OF_LMP
         case when pad.BENIFIT_TYPE IN ('MTI','IMTI','OMTI') THEN TO_CHAR(pad.LMP_DATE,'DD-MM-RRRR') ELSE NULL END AS DATE_OF_LMP,
    -- pad.lmp_date  DATE_OF_LMP,
     GC.DESCRIPTION as BENEFIT_TYPE,
      to_char(PAD.clm_RECEIVED_DATE,'dd/mm/yyyy  hh:mm:ss AM')  CLAIM_RECEIVED_DATE_AND_TIME,
   --  pad.CLM_RECEIVED_DATE CLAIM_RECEIVED_DATE,
     pad.claim_number CLAIM_NUMBER,
     nvl(pd.PROVIDER_NET_AMOUNT,0) AMOUNT_CLAIMED,
     nvl(pd.APPROVED_AMOUNT,0)  AMOUNT_APPROVED,
     (pd.disc_gross_amount-nvl(pd.patient_share_amount,0))-nvl(pd.APPROVED_AMOUNT,0) DISALLOWED_AMOUNT,
     --(pd.DISC_GROSS_AMOUNT-pd.APPROVED_AMOUNT-PD.PATIENT_SHARE_AMOUNT) DISALLOWED_AMOUNT,
    -- (pd.PROVIDER_NET_AMOUNT-pd.APPROVED_AMOUNT) DISALLOWED_AMOUNT,
      PD.PATIENT_SHARE_AMOUNT PATIENT_SHARE,
     case
        when pad.clm_status_type_id = 'INP' then 'In progress'
        when pad.clm_status_type_id = 'APR' then 'Approved'
        when pad.clm_status_type_id = 'REJ' then 'REJECTED'
        when pad.clm_status_type_id = 'REQ' then 'Required Information'
        when pad.clm_status_type_id = 'PCN' then 'Cancelled'
        when pad.clm_status_type_id = 'PCO' then 'Closed'
    end as STATUS,
   -- CASE WHEN PAD.PAT_AUTH_SEQ_ID IS NULL THEN 'NO' ELSE 'YES' END 
       cad.PRE_AUTH_NUMBER LINKED_PRE_APPROVAL,
       --TRIM(BOTH ';' FROM pd.DENIAL_DESC) as REJECTED_REASON, 
       PAD.INTERNAL_REMARKS INTERNAL_REMARK,
    case when PAD.FINAL_REMARKS is null then PAD.FINAL_REMARKS else
       REPLACE(PAD.FINAL_REMARKS,';',',')||'.' end as FINAL_REMARK,
       --REPLACE(PAD.FINAL_REMARKS,';',',')||'.' end as FINAL_REMARK,
       TRIM(BOTH ';' FROM pd.DENIAL_DESC) as REJECTED_REASON,
        to_char(PAD.UPDATED_DATE,'dd/mm/yyyy  hh:mm:ss AM')  PROCESSED_DATE_AND_TIME,
       -- to_char(PAD.COMPLETED_DATE,'dd/mm/yyyy  hh:mm:ss AM')  PROCESSED_DATE_AND_TIME,
     -- PAD.COMPLETED_DATE PROCESSED_DATE,
      UC.CONTACT_NAME PROCESSED_BY,
      pad.settlement_number SETTLEMENT_NUMBER,
      CP.CLAIM_PAYMENT_STATUS PAYMENT_STATUS
                                                                              
    from clm_authorization_details pad
    LEFT  JOIN pat_authorization_details cad   ON (cad.CLAIM_SEQ_ID=PAD.CLAIM_SEQ_ID)
    LEFT  JOIN FIN_APP.tpa_claims_payment CP ON (CP.CLAIM_SEQ_ID=PAD.CLAIM_SEQ_ID)
    left outer join clm_batch_upload_details pbud   on (pad.clm_batch_seq_id = pbud.clm_batch_seq_id)
    left outer join clm_hospital_details hd         on (hd.claim_seq_id=pad.claim_seq_id)
    left outer join tpa_enr_policy ep               on (ep.policy_seq_id=pad.policy_seq_id)
    left outer join tpa_enr_policy_member tepm      on (pad.member_seq_id=tepm.member_seq_id)
    left outer join tpa_enr_policy_group pg         on (pg.policy_group_seq_id=tepm.policy_group_seq_id)
    left outer join tpa_hosp_info thi               on (hd.hosp_seq_id = thi.hosp_seq_id)
    left outer join tpa_hosp_address tha            on (thi.hosp_seq_id = tha.hosp_seq_id)
    left outer join tpa_ins_info tii                on (pad.ins_seq_id = tii.ins_seq_id)
  ----  left outer join tpa_hosp_professionals thp      on (pad.clinician_id=thp.professional_id and thp.hosp_seq_id=hd.hosp_seq_id)
    left outer join  tpa_country_code cc             on (cc.country_id=hd.country_type_id)
     left outer join  tpa_country_code dc             on (dc.country_id=tha.COUNTRY_ID)
    LEFT OUTER JOIN assign_users au                 on  (au.assign_users_seq_id=pad.assign_user_seq_id)
    left outer join tpa_user_contacts uc            on (uc.contact_seq_id=au.assigned_to_user)
    left outer join tpa_user_contacts uca           on (uca.contact_seq_id=pad.updated_by)
    left outer join app.pat_activity_details pd on(pad.claim_seq_id=pd.claim_seq_id)
    left outer join app.tpa_activity_master_details  am on(am.ACTIVITY_CODE=pd.code)
    LEFT join app.tpa_general_code gc on(gc.GENERAL_TYPE_ID=PAD.BENIFIT_TYPE)  
    left join primary_icd pi on pi.claim_seq_id=pad.claim_seq_id
    left join APP.TPA_ENR_POLICY_MEMBER EPM on (EPM.MEMBER_SEQ_ID=pad.MEMBER_SEQ_ID)
    where pad.tpa_enrollment_id=v_alkood_id and pad.policy_seq_id =v_policy_seq_id
    and (pad.benifit_type =v_benefit_type or v_benefit_type is null)
    ORDER BY pd.ACTIVITY_DTL_SEQ_ID ASC ;
 
  ELSE 
  OPEN  pat_clm_resultset for 
       with primary_icd as(
            SELECT ca.PAT_AUTH_SEQ_ID,
            listagg(dd.DIAGNOSYS_CODE,'/') within group (order by DIAGNOSYS_CODE) SECONDARY_ICD_CODE,
            listagg(y.SHORT_DESC,'/') within group (order by DIAGNOSYS_CODE) SECONDARY_ICD_CODE_DESCRIPTION
            FROM app.pat_authorization_details ca               
            join  APP.diagnosys_details DD  on ca.PAT_AUTH_SEQ_ID=dd.PAT_AUTH_SEQ_ID
            left JOIN  APP.TPA_ICD10_MASTER_DETAILS Y ON (DD.diagnosys_code=Y.ICD_CODE)
            WHERE DD.PRIMARY_AILMENT_YN='N'
            and ca.tpa_enrollment_id=v_alkood_id and ca.policy_seq_id =v_policy_seq_id
            and (ca.benifit_type =v_benefit_type or v_benefit_type is null)
            group by ca.PAT_AUTH_SEQ_ID
            )
 select
     ep.policy_number,
     EPM.tpa_enrollment_id ALKOOT_ID,
     --pad.tpa_enrollment_id ALKOOT_ID,
     pad.mem_name as MEMBER_NAME,
     nvl(CC.COUNTRY_NAME,cd.COUNTRY_NAME) PROVIDER_COUNTRY, 
     NVL(thi.hosp_name,HD.PROVIDER_NAME) NAME_OF_PROVIDER,
    -- NVL(CC.COUNTRY_NAME, dc.COUNTRY_NAME) PROVIDER_COUNTRY,
    --nvl(CC.COUNTRY_NAME,cd.COUNTRY_NAME) PROVIDER_COUNTRY, 
    --CC.COUNTRY_NAME PROVIDER_COUNTRY, 
    --to_char(PD.START_DATE,'dd/mm/yyyy  hh:mm:ss AM')  SERVICE_DATE,
     -- to_char(PD.START_DATE,'dd/mm/yyyy  hh:mm:ss AM')  SERVICE_DATE,
   --  PAD.PAT_RECEIVED_DATE SERVICE_DATE,
   to_char(PAD.PAT_RECEIVED_DATE,'dd/mm/yyyy  hh:mm:ss AM')  PRE_APPROVAL_RECEIVED_DATE,
   pad.PRE_AUTH_NUMBER PRE_APPROVAL_NUMBER,
       ( SELECT 
                TO_CHAR(replace(wm_concat(DIAGNOSYS_CODE),',','/')) 
                 --DIAGNOSYS_CODE             
                 FROM APP.diagnosys_details DD 
                 join app.pat_authorization_details ca on ca.PAT_AUTH_SEQ_ID=dd.PAT_AUTH_SEQ_ID
                 left JOIN  APP.TPA_ICD10_MASTER_DETAILS Y ON (DD.diagnosys_code=Y.ICD_CODE)                 
                WHERE DD.PRIMARY_AILMENT_YN='Y'
                and ca.member_seq_id=pad.member_seq_id and ca.PAT_AUTH_SEQ_ID=pad.PAT_AUTH_SEQ_ID ) PRIMARY_ICD_CODE,
        ( SELECT                 
                listagg(y.SHORT_DESC,'/') within group (order by SHORT_DESC)
                 FROM APP.diagnosys_details DD 
                 join app.pat_authorization_details ca on ca.PAT_AUTH_SEQ_ID=dd.PAT_AUTH_SEQ_ID
                 left JOIN  APP.TPA_ICD10_MASTER_DETAILS Y ON (DD.diagnosys_code=Y.ICD_CODE)                 
                WHERE DD.PRIMARY_AILMENT_YN='Y'
                and ca.member_seq_id=pad.member_seq_id and ca.PAT_AUTH_SEQ_ID=pad.PAT_AUTH_SEQ_ID ) PRIMARY_ICD_CODE_DESCRIPTION,
           pi.SECONDARY_ICD_CODE,
            pi.SECONDARY_ICD_CODE_DESCRIPTION,
            to_char(PD.START_DATE,'dd/mm/yyyy  hh:mm:ss AM')  SERVICE_DATE,
            pd.code ACTIVITY_CODE,
           -- pad.PRE_AUTH_NUMBER PRE_APPROVAL_NUMBER,
       am.short_description ACTIVITY_DESCRIPTION,
     --pad.PRE_AUTH_NUMBER PRE_APPROVAL_NUMBER,
     pd.INTERNAL_CODE INTERNAL_CODE,
      pd.INTERNAL_DESC INTERNAL_DESCRIPTION,
     pd.TOOTH_NO TOOTH_NUMBER,
     --to_char(pad.LMP_DATE ,'dd/mm/yyyy  hh:mm:ss AM')  DATE_OF_LMP
     case when pad.BENIFIT_TYPE IN ('MTI','IMTI','OMTI') THEN TO_CHAR(pad.LMP_DATE,'DD-MM-RRRR') ELSE NULL END AS DATE_OF_LMP,
     GC.DESCRIPTION as BENEFIT_TYPE,
    --to_char(PAD.PAT_RECEIVED_DATE,'dd/mm/yyyy  hh:mm:ss AM')  PRE_APPROVAL_RECEIVED_DATE,
    -- pad.PAT_RECEIVED_DATE PAT_RECEIVED_DATE,
    nvl(pd.DISC_GROSS_AMOUNT,0) AMOUNT_REQUESTED,
     nvl(pd.APPROVED_AMOUNT,0) AMOUNT_APPROVED,
     --pad.AUTH_NUMBER AUTHORIZATION_NUMBER,
     --nvl(pd.DISC_GROSS_AMOUNT,0) AMOUNT_REQUESTED,
     --nvl(pd.APPROVED_AMOUNT,0)  AMOUNT_APPROVED,
     (pd.disc_gross_amount-nvl(pd.patient_share_amount,0))-nvl(pd.APPROVED_AMOUNT,0) DISALLOWED_AMOUNT,
     --(pd.DISC_GROSS_AMOUNT-pd.APPROVED_AMOUNT-PD.PATIENT_SHARE_AMOUNT) DISALLOWED_AMOUNT,
    PD.PATIENT_SHARE_AMOUNT PATIENT_SHARE,
     case
        when pad.PAT_STATUS_TYPE_ID = 'INP' then 'In progress'
        when pad.PAT_STATUS_TYPE_ID = 'APR' then 'Approved'
        when pad.PAT_STATUS_TYPE_ID = 'REJ' then 'REJECTED'
        when pad.PAT_STATUS_TYPE_ID = 'REQ' then 'Required Information'
        when pad.PAT_STATUS_TYPE_ID = 'PCN' then 'Cancelled'
        when pad.PAT_STATUS_TYPE_ID = 'PCO' then 'Closed'
    end as STATUS,
    --CASE WHEN PAD.PAT_AUTH_SEQ_ID IS NULL THEN 'NO' ELSE 'YES' END 
       cad.CLAIM_NUMBER LINKED_CLAIM,
      --PAD.CLAIM_SEQ_ID LINKED_CLAIM_1,
      pad.AUTH_NUMBER AUTHORIZATION_NUMBER,
      --TRIM(BOTH ';' FROM pd.DENIAL_DESC) as REJECTED_REASON,
       PAD.INTERNAL_REMARKS INTERNAL_REMARK,
       case when  PAD.MEDICAL_OPINION_REMARKS is null then pad.MEDICAL_OPINION_REMARKS else
        REPLACE(PAD.MEDICAL_OPINION_REMARKS,';',',')||'.' end as FINAL_REMARK,
       --REPLACE(PAD.MEDICAL_OPINION_REMARKS,';',',')||'.' FINAL_REMARK,
       TRIM(BOTH ';' FROM pd.DENIAL_DESC) as REJECTED_REASON,
        to_char(PAD.UPDATED_DATE,'dd/mm/yyyy  hh:mm:ss AM')  PROCESSED_DATE_AND_TIME,
     -- to_char(PAD.COMPLETED_DATE,'dd/mm/yyyy  hh:mm:ss AM')  PROCESSED_DATE,
     -- PAD.COMPLETED_DATE PROCESSED_DATE,
      UC.CONTACT_NAME PROCESSED_BY
    
      from pat_authorization_details pad
    left join clm_authorization_details cad  on (cad.CLAIM_SEQ_ID=PAD.CLAIM_SEQ_ID)
    left join ORTHODONTIC_DETAILS_TAB od on (od.source_seq_id = pad.PAT_AUTH_SEQ_ID)
    left outer join app.pat_non_network_details hd  on (hd.PAT_AUTH_SEQ_ID=pad.PAT_AUTH_SEQ_ID)
    left outer join tpa_enr_policy ep               on (ep.policy_seq_id=pad.policy_seq_id)
    left outer join tpa_hosp_info thi               on (PAD.hosp_seq_id = thi.hosp_seq_id)
    left outer join  tpa_country_code cc             on (cc.country_id=hd.country_type_id)
    LEFT OUTER JOIN assign_users au                 on  (au.assign_users_seq_id=pad.assign_user_seq_id)
    left outer join tpa_user_contacts uc            on (uc.contact_seq_id=au.assigned_to_user)
    left outer join tpa_ins_prod_policy lp  on(lp.policy_seq_id = pad.policy_seq_id)   ---newly added for policy tob
    left outer join app.pat_activity_details pd on(pad.PAT_AUTH_SEQ_ID=pd.PAT_AUTH_SEQ_ID)
    left outer join app.tpa_activity_master_details  am on(am.ACTIVITY_CODE=pd.code)
    left outer join tpa_hosp_address tha            on (thi.hosp_seq_id = tha.hosp_seq_id)
    LEFT join app.tpa_general_code gc on(gc.GENERAL_TYPE_ID=PAD.BENIFIT_TYPE) 
     left outer join  tpa_country_code cd            on (cd.country_id=tha.COUNTRY_ID)
     left join primary_icd pi on pi.PAT_AUTH_SEQ_ID=pad.PAT_AUTH_SEQ_ID
     left join APP.TPA_ENR_POLICY_MEMBER EPM on (EPM.MEMBER_SEQ_ID=pad.MEMBER_SEQ_ID)
     --left outer join  tpa_country_code cd             on (cd.COUNTRY_ID=tha.COUNTRY_ID)
     
  where pad.tpa_enrollment_id=v_alkood_id and pad.policy_seq_id =v_policy_seq_id
  and (pad.benifit_type =v_benefit_type or v_benefit_type is null)
  ORDER BY pd.ACTIVITY_DTL_SEQ_ID ASC;
  end if;
  end dn_ld_clm_dtls;
------------------------------------------------------
 PROCEDURE clm_and_pat_his_dtl(   p_claim_SEQ_ID       in       clm_Authorization_Details.claim_seq_id%TYPE,
                                   p_flag                in     varchar2,   
                                   pat_clm_resultset         OUT       SYS_REFCURSOR)
                               
   as

     begin
     if p_flag ='CLM' THEN
          open pat_clm_resultset for
        with primary_icd as(
            SELECT ca.claim_seq_id,
            listagg(dd.DIAGNOSYS_CODE,'/') within group (order by DIAGNOSYS_CODE) SECONDARY_ICD_CODE,
            listagg(y.SHORT_DESC,'/') within group (order by DIAGNOSYS_CODE) SECONDARY_ICD_CODE_DESCRIPTION
            FROM app.clm_authorization_details ca               
            join  APP.diagnosys_details DD  on ca.claim_seq_id=dd.claim_seq_id
            left JOIN  APP.TPA_ICD10_MASTER_DETAILS Y ON (DD.diagnosys_code=Y.ICD_CODE)
            WHERE DD.PRIMARY_AILMENT_YN='N'
            and ca.claim_seq_id=p_claim_SEQ_ID
            group by ca.claim_seq_id
            )
            select
     ep.policy_number,
     EPM.tpa_enrollment_id ALKOOT_ID,
   --pad.tpa_enrollment_id ALKOOT_ID,
     tepm.mem_name ||' '|| tepm.mem_last_name||' '|| tepm.family_name as MEMBER_NAME,
     NVL(CC.COUNTRY_NAME, dc.COUNTRY_NAME) PROVIDER_COUNTRY,
     NVL(thi.hosp_name,hd.HOSP_NAME) NAME_OF_PROVIDER,
     --NVL(CC.COUNTRY_NAME, dc.COUNTRY_NAME) PROVIDER_COUNTRY,
     PAD.INVOICE_NUMBER,
     --to_char(PD.START_DATE,'dd/mm/yyyy  hh:mm:ss AM') SERVICE_DATE,
     --PAD.CLM_RECEIVED_DATE SERVICE_DATE,

      ( SELECT
--to_char(replace(wm_concat(DIAGNOSYS_CODE),',','/'))
                 DIAGNOSYS_CODE
                 FROM APP.diagnosys_details DD
                 join app.clm_authorization_details ca on ca.claim_seq_id=dd.claim_seq_id
                 left JOIN  APP.TPA_ICD10_MASTER_DETAILS Y ON (DD.diagnosys_code=Y.ICD_CODE)
                WHERE DD.PRIMARY_AILMENT_YN='Y'
                and ca.member_seq_id=pad.member_seq_id and ca.claim_seq_id=pad.claim_seq_id ) PRIMARY_ICD_CODE,
        ( SELECT
                listagg(y.SHORT_DESC,'/') within group (order by SHORT_DESC)
                 FROM APP.diagnosys_details DD
                 join app.clm_authorization_details ca on ca.claim_seq_id=dd.claim_seq_id
                 left JOIN  APP.TPA_ICD10_MASTER_DETAILS Y ON (DD.diagnosys_code=Y.ICD_CODE)
                WHERE DD.PRIMARY_AILMENT_YN='Y'
                and ca.member_seq_id=pad.member_seq_id and ca.claim_seq_id=pad.claim_seq_id ) PRIMARY_ICD_CODE_DESCRIPTION,

           pi.SECONDARY_ICD_CODE,
           pi.SECONDARY_ICD_CODE_DESCRIPTION,
           to_char(PD.START_DATE,'dd/mm/yyyy  hh:mm:ss AM') SERVICE_DATE,
      pd.code ACTIVITY_CODE,
     am.ACTIVITY_description ACTIVITY_DESCRIPTION,
     pd.INTERNAL_CODE,
     pd.INTERNAL_DESC INTERNAL_DESCRIPTION,
     pd.TOOTH_NO TOOTH_NUMBER,
      case when pad.BENIFIT_TYPE IN ('MTI','IMTI','OMTI') THEN TO_CHAR(pad.LMP_DATE,'DD-MM-RRRR') ELSE NULL END AS DATE_OF_LMP,
    -- to_char(pad.LMP_DATE ,'dd/mm/yyyy  hh:mm:ss AM') DATE_OF_LMP,
    -- pad.lmp_date  DATE_OF_LMP,
     GC.DESCRIPTION as BENEFIT_TYPE,
      to_char(PAD.CLM_RECEIVED_DATE,'dd/mm/yyyy  hh:mm:ss AM') CLAIM_RECEIVED_DATE_AND_TIME,
   --  pad.CLM_RECEIVED_DATE CLAIM_RECEIVED_DATE,
     pad.claim_number CLAIM_NUMBER,
     nvl(pd.PROVIDER_NET_AMOUNT,0) AMOUNT_CLAIMED,
     nvl(pd.APPROVED_AMOUNT,0)  AMOUNT_APPROVED,
(pd.disc_gross_amount-nvl(pd.patient_share_amount,0))-nvl(pd.APPROVED_AMOUNT,0) DISALLOWED_AMOUNT,
--(pd.DISC_GROSS_AMOUNT-pd.APPROVED_AMOUNT-PD.PATIENT_SHARE_AMOUNT) DISALLOWED_AMOUNT,
      PD.PATIENT_SHARE_AMOUNT PATIENT_SHARE,
     case
        when pad.clm_status_type_id = 'INP' then 'In progress'
        when pad.clm_status_type_id = 'APR' then 'Approved'
        when pad.clm_status_type_id = 'REJ' then 'REJECTED'
        when pad.clm_status_type_id = 'REQ' then 'Required Information'
        when pad.clm_status_type_id = 'PCN' then 'Cancelled'
        when pad.clm_status_type_id = 'PCO' then 'Closed'
    end as STATUS,
   -- CASE WHEN PAD.PAT_AUTH_SEQ_ID IS NULL THEN 'NO' ELSE 'YES' END
       cad.PRE_AUTH_NUMBER LINKED_PRE_APPROVAL,
      --TRIM(BOTH ';' FROM pd.DENIAL_DESC) as REJECTED_REASON,
       PAD.INTERNAL_REMARKS INTERNAL_REMARK,
       case when PAD.FINAL_REMARKS is null then PAD.FINAL_REMARKS else 
       REPLACE(PAD.FINAL_REMARKS,';',',')||'.' end as FINAL_REMARK,
     --REPLACE(PAD.FINAL_REMARKS,';',',')||'.' end as FINAL_REMARK,
     TRIM(BOTH ';' FROM pd.DENIAL_DESC) as REJECTED_REASON,
       to_char(PAD.UPDATED_DATE,'dd/mm/yyyy  hh:mm:ss AM') PROCESSED_DATE_AND_TIME,
    --  PAD.COMPLETED_DATE PROCESSED_DATE,
       UC.CONTACT_NAME PROCESSED_BY,
       pad.settlement_number SETTLEMENT_NUMBER,
       CP.CLAIM_PAYMENT_STATUS PAYMENT_STATUS

    from app.clm_authorization_details pad
    LEFT  JOIN app.pat_authorization_details cad   ON (cad.CLAIM_SEQ_ID=PAD.CLAIM_SEQ_ID)
    LEFT  JOIN FIN_APP.tpa_claims_payment CP ON (CP.CLAIM_SEQ_ID=PAD.CLAIM_SEQ_ID)
    left outer join app.clm_batch_upload_details pbud  on (pad.clm_batch_seq_id = pbud.clm_batch_seq_id)
    left outer join app.clm_hospital_details hd         on (hd.claim_seq_id=pad.claim_seq_id)
    left outer join app.tpa_enr_policy ep               on (ep.policy_seq_id=pad.policy_seq_id)
    left outer join app.tpa_enr_policy_member tepm      on (pad.member_seq_id=tepm.member_seq_id)
    left outer join app.tpa_enr_policy_group pg         on (pg.policy_group_seq_id=tepm.policy_group_seq_id)
    left outer join app.tpa_hosp_info thi               on (hd.hosp_seq_id = thi.hosp_seq_id)
    left outer join app.tpa_hosp_address tha            on (thi.hosp_seq_id = tha.hosp_seq_id)
    left outer join app.tpa_ins_info tii                on (pad.ins_seq_id = tii.ins_seq_id)
    left outer join app.tpa_hosp_professionals thp      on (pad.clinician_id=thp.professional_id and thp.hosp_seq_id=hd.hosp_seq_id)
    left outer join  app.tpa_country_code cc            on (cc.country_id=hd.country_type_id)
     left outer join  app.tpa_country_code dc             on (dc.country_id=tha.COUNTRY_ID)
    LEFT OUTER JOIN app.assign_users au                 on (au.assign_users_seq_id=pad.assign_user_seq_id)
    left outer join app.tpa_user_contacts uc            on (uc.contact_seq_id=au.assigned_to_user)
    left outer join app.tpa_user_contacts uca           on (uca.contact_seq_id=pad.updated_by)
    left outer join app.pat_activity_details pd on(pad.claim_seq_id=pd.claim_seq_id)
    left outer join app.tpa_activity_master_details  am on(am.ACTIVITY_CODE=pd.code)
    LEFT join app.tpa_general_code gc on(gc.GENERAL_TYPE_ID=PAD.BENIFIT_TYPE)
    left join primary_icd pi on pi.claim_seq_id=pad.claim_seq_id
    left join APP.TPA_ENR_POLICY_MEMBER EPM on (EPM.MEMBER_SEQ_ID=pad.MEMBER_SEQ_ID)
    where PAD.claim_SEQ_ID=p_claim_SEQ_ID
    ORDER BY pd.ACTIVITY_DTL_SEQ_ID ASC;
 
  ELSIF p_flag ='PAT' THEN
  OPEN  pat_clm_resultset for  
   with primary_icd as(
            SELECT ca.PAT_AUTH_SEQ_ID,
            listagg(dd.DIAGNOSYS_CODE,'/') within group (order by DIAGNOSYS_CODE) SECONDARY_ICD_CODE,
            listagg(y.SHORT_DESC,'/') within group (order by DIAGNOSYS_CODE) SECONDARY_ICD_CODE_DESCRIPTION
            FROM app.pat_authorization_details ca               
            join  APP.diagnosys_details DD  on ca.PAT_AUTH_SEQ_ID=dd.PAT_AUTH_SEQ_ID
            left JOIN  APP.TPA_ICD10_MASTER_DETAILS Y ON (DD.diagnosys_code=Y.ICD_CODE)
            WHERE DD.PRIMARY_AILMENT_YN='N'
            and ca.PAT_AUTH_SEQ_ID=p_claim_SEQ_ID
            group by ca.PAT_AUTH_SEQ_ID
            )
 select
     ep.policy_number,
     EPM.tpa_enrollment_id ALKOOT_ID,
   --PAD.tpa_enrollment_id ALKOOT_ID,
     pad.mem_name as MEMBER_NAME,
     nvl(CC.COUNTRY_NAME,cd.COUNTRY_NAME) PROVIDER_COUNTRY,
     NVL(thi.hosp_name,HD.PROVIDER_NAME) NAME_OF_PROVIDER,
     to_char(PAD.PAT_RECEIVED_DATE,'dd/mm/yyyy  hh:mm:ss AM')  PREAUTH_RECEIVED_DATE_AND_TIME,
   --NVL(CC.COUNTRY_NAME, dc.COUNTRY_NAME) PROVIDER_COUNTRY,
   --nvl(CC.COUNTRY_NAME,cd.COUNTRY_NAME) PROVIDER_COUNTRY, 
   --to_char(PD.START_DATE,'dd/mm/yyyy  hh:mm:ss AM')  SERVICE_DATE,
   --to_char(PAD.PAT_RECEIVED_DATE,'dd/mm/yyyy  hh:mm:ss AM')  SERVICE_DATE,
   --PAD.PAT_RECEIVED_DATE SERVICE_DATE,
   pad.PRE_AUTH_NUMBER PRE_APPROVAL_NUMBER,
       ( SELECT 
                --to_char(replace(wm_concat(DIAGNOSYS_CODE),',','/'))
                DIAGNOSYS_CODE                
                 FROM APP.diagnosys_details DD 
                 join app.pat_authorization_details ca on ca.PAT_AUTH_SEQ_ID=dd.PAT_AUTH_SEQ_ID
                 left JOIN  APP.TPA_ICD10_MASTER_DETAILS Y ON (DD.diagnosys_code=Y.ICD_CODE)                 
                WHERE DD.PRIMARY_AILMENT_YN='Y'
                and ca.member_seq_id=pad.member_seq_id and ca.PAT_AUTH_SEQ_ID=pad.PAT_AUTH_SEQ_ID ) PRIMARY_ICD_CODE,
        ( SELECT                 
                listagg(y.SHORT_DESC,'/') within group (order by SHORT_DESC)
                 FROM APP.diagnosys_details DD 
                 join app.pat_authorization_details ca on ca.PAT_AUTH_SEQ_ID=dd.PAT_AUTH_SEQ_ID
                 left JOIN  APP.TPA_ICD10_MASTER_DETAILS Y ON (DD.diagnosys_code=Y.ICD_CODE)                 
                WHERE DD.PRIMARY_AILMENT_YN='Y'
                and ca.member_seq_id=pad.member_seq_id and ca.PAT_AUTH_SEQ_ID=pad.PAT_AUTH_SEQ_ID ) PRIMARY_ICD_CODE_DESCRIPTION,
  
            pi.SECONDARY_ICD_CODE,
            pi.SECONDARY_ICD_CODE_DESCRIPTION,
          --pad.PRE_AUTH_NUMBER PRE_APPROVAL_NUMBER,
            to_char(PD.START_DATE,'dd/mm/yyyy  hh:mm:ss AM')  SERVICE_DATE,
            pd.code ACTIVITY_CODE,
            am.ACTIVITY_description ACTIVITY_DESCRIPTION,
            pd.INTERNAL_CODE INTERNAL_CODE,
            pd.INTERNAL_DESC  INTERNAL_DESCRIPTION,
            pd.TOOTH_NO TOOTH_NUMBER,
     case when pad.BENIFIT_TYPE IN ('MTI','IMTI','OMTI') THEN TO_CHAR(pad.LMP_DATE,'DD-MM-RRRR') ELSE NULL END AS DATE_OF_LMP,
     --pad.LMP_DATE  DATE_OF_LMP,
     --to_char(pad.LMP_DATE ,'dd/mm/yyyy  hh:mm:ss AM')  DATE_OF_LMP,
     GC.DESCRIPTION as BENEFIT_TYPE,
    --to_char(PAD.PAT_RECEIVED_DATE,'dd/mm/yyyy  hh:mm:ss AM')  PREAUTH_RECEIVED_DATE_AND_TIME,
    --pad.PAT_RECEIVED_DATE PAT_RECEIVED_DATE,
    -- pad.AUTH_NUMBER AUTHORIZATION_NUMBER,
     nvl(pd.DISC_GROSS_AMOUNT,0) AMOUNT_requested,
     nvl(pd.APPROVED_AMOUNT,0)  AMOUNT_APPROVED,
     (pd.disc_gross_amount-nvl(pd.patient_share_amount,0))-nvl(pd.APPROVED_AMOUNT,0) DISALLOWED_AMOUNT,
     --(pd.DISC_GROSS_AMOUNT-pd.APPROVED_AMOUNT-PD.PATIENT_SHARE_AMOUNT) DISALLOWED_AMOUNT,
     --(pd.PROVIDER_NET_AMOUNT-pd.APPROVED_AMOUNT) DISALLOWED_AMOUNT,
    PD.PATIENT_SHARE_AMOUNT PATIENT_SHARE,
     case
        when pad.PAT_STATUS_TYPE_ID = 'INP' then 'In progress'
        when pad.PAT_STATUS_TYPE_ID = 'APR' then 'Approved'
        when pad.PAT_STATUS_TYPE_ID = 'REJ' then 'REJECTED'
        when pad.PAT_STATUS_TYPE_ID = 'REQ' then 'Required Information'
        when pad.PAT_STATUS_TYPE_ID = 'PCN' then 'Cancelled'
        when pad.PAT_STATUS_TYPE_ID = 'PCO' then 'Closed'
    end as STATUS,
   -- CASE WHEN PAD.PAT_AUTH_SEQ_ID IS NULL THEN 'NO' ELSE 'YES' END 
        cad.CLAIM_NUMBER LINKED_CLAIM,
        pad.AUTH_NUMBER AUTHORIZATION_NUMBER,
        --TRIM(BOTH ';' FROM pd.DENIAL_DESC) as REJECTED_REASON, 
        PAD.INTERNAL_REMARKS INTERNAL_REMARK,
    case when  pad.MEDICAL_OPINION_REMARKS is null then pad.MEDICAL_OPINION_REMARKS else
        REPLACE(PAD.MEDICAL_OPINION_REMARKS,';',',')||'.' end as FINAL_REMARK,
        TRIM(BOTH ';' FROM pd.DENIAL_DESC) as REJECTED_REASON,
        to_char(PAD.UPDATED_DATE,'dd/mm/yyyy  hh:mm:ss AM')  PROCESSED_DATE_AND_TIME,
       --to_char(PAD.COMPLETED_DATE,'dd/mm/yyyy  hh:mm:ss AM')  PROCESSED_DATE,
     -- PAD.COMPLETED_DATE PROCESSED_DATE,
        UC.CONTACT_NAME PROCESSED_BY
    
      from pat_authorization_details pad
       left join clm_authorization_details cad  on (cad.CLAIM_SEQ_ID=PAD.CLAIM_SEQ_ID)
     left join ORTHODONTIC_DETAILS_TAB od on (od.source_seq_id = pad.PAT_AUTH_SEQ_ID)
    left outer join app.pat_non_network_details hd  on (hd.PAT_AUTH_SEQ_ID=pad.PAT_AUTH_SEQ_ID)
    left outer join tpa_enr_policy ep               on (ep.policy_seq_id=pad.policy_seq_id)
    left outer join tpa_hosp_info thi               on (PAD.hosp_seq_id = thi.hosp_seq_id)
    left outer join  tpa_country_code cc            on (cc.country_id=hd.country_type_id)
    LEFT OUTER JOIN assign_users au                 on  (au.assign_users_seq_id=pad.assign_user_seq_id)
    left outer join tpa_user_contacts uc            on (uc.contact_seq_id=au.assigned_to_user)
    left outer join tpa_ins_prod_policy lp  on(lp.policy_seq_id = pad.policy_seq_id)   ---newly added for policy tob
    left outer join app.pat_activity_details pd on(pad.PAT_AUTH_SEQ_ID=pd.PAT_AUTH_SEQ_ID)
    left outer join app.tpa_activity_master_details  am on(am.ACTIVITY_CODE=pd.code)
    left outer join tpa_hosp_address tha            on (thi.hosp_seq_id = tha.hosp_seq_id)
    left outer join  tpa_country_code cd            on (cd.country_id=tha.COUNTRY_ID)
    LEFT join app.tpa_general_code gc on(gc.GENERAL_TYPE_ID=PAD.BENIFIT_TYPE) 
    left join primary_icd pi on pi.PAT_AUTH_SEQ_ID=pad.PAT_AUTH_SEQ_ID
     left join APP.TPA_ENR_POLICY_MEMBER EPM on (EPM.MEMBER_SEQ_ID=pad.MEMBER_SEQ_ID)
    where PAD.PAT_AUTH_SEQ_ID=p_claim_SEQ_ID
    ORDER BY pd.ACTIVITY_DTL_SEQ_ID ASC;
  end if;
  end clm_and_pat_his_dtl;

---------------------------------------------------
--===================== ADDED IN CFD MODULE CR =============== ---------
PROCEDURE select_cfd_pat_clm_list (
     v_claim_number                       IN  clm_authorization_details.claim_number%type,
     v_batch_no                           IN  clm_batch_upload_details.batch_no%type,
     v_provider_id                        IN  clm_hospital_details.provider_id%type,
     v_claim_type                         IN  clm_batch_upload_details.clm_type_gen_type_id%type,
     v_int_remarks                        IN  clm_authorization_details.status_code_id%type,
     v_settlement_number                  IN  clm_authorization_details.settlement_number%TYPE,
     v_policy_number                      IN  tpa_enr_policy.policy_number%type,
     v_partner_seq_id                     IN  clm_authorization_details.ptnr_seq_id%type,
     v_process_type                       IN  clm_authorization_details.process_type%type,
     v_risk_level                         IN  clm_authorization_details.risk_level%type,
     v_tpa_enrollment_id                  IN  clm_authorization_details.tpa_enrollment_id%type,
     v_mem_name                           IN  clm_authorization_details.mem_name%type,
     v_benifit_type                       IN  clm_authorization_details.benifit_type%type,
     v_pre_auth_number                    IN  pat_authorization_details.pre_auth_number%type,
     v_auth_number                        IN  pat_authorization_details.auth_number%type,
     v_invoice_number                     IN  clm_authorization_details.invoice_number%type,
     v_status_type_id                     IN  clm_authorization_details.clm_status_type_id%type,
     v_enr_type                           IN  tpa_enr_policy.enrol_type_id%TYPE,
     v_mode                               IN  clm_authorization_details.source_type_id%type,
     v_inv_status                         IN  tpa_fraud_inv_details.inv_status%type,
     v_sort_var                           IN  VARCHAR2,
     v_sort_order                         IN  VARCHAR2 ,
     v_start_num                          IN  VARCHAR2 ,
     v_end_num                            IN  VARCHAR2 ,
     result_set                           OUT SYS_REFCURSOR
  )
  IS
    v_sql_str                            VARCHAR2(10000) ;
    TYPE bind_tab_type IS TABLE OF VARCHAR2(250) INDEX BY BINARY_INTEGER ;
    bind_tab                             bind_tab_type;
    i                                    NUMBER(2) := 0;
    v_where                              VARCHAR2(2000);

  BEGIN
    IF v_mode = 'CLM' THEN
            v_sql_str :=
              'with inv_status as 
                    (select max(inv_seq_id) as inv_seq_id,claim_seq_id from tpa_fraud_inv_details group by claim_seq_id)
               select cad.claim_seq_id as seq_id,
                    cad.claim_number pat_clm_no,
                    nvl(tepm.tpa_enrollment_id,cad.tpa_enrollment_id) as tpa_enrollment_id,
                    tepm.mem_name||'' ''|| tepm.mem_last_name||'' ''|| tepm.family_name as mem_name,
                    case when a.network_yn=''N'' then chd.hosp_name else nvl(chd.hosp_name,thi.hosp_name) end as hosp_name,
                    gc.description pat_clm_status ,
                    gc1.description claim_type,
                    case tep.enrol_type_id when ''COR'' then ''Corporate''
                                         when ''IND'' then ''Individual''
                                         else null end pol_type,
                    case upper(cad.status_code_id)   when ''SUSP'' then ''Suspected Fruad''
                                                   when ''ALKT'' then ''Alkoot Clarification''
                                                   when ''PROV'' then ''Provider Clarification'' else null end as internal_remaks_status,
                    case cad.risk_level when ''LR'' then ''Low Risk''
                                      when ''IR'' then ''Intermediate Risk''
                                      when ''HR'' then ''High Risk'' else null end risk_level ,
                    cad.status_code_id as status_code_id                                
                               
            from clm_batch_upload_details a join clm_authorization_details cad on (a.clm_batch_seq_id=cad.clm_batch_seq_id and a.batch_status_type=''COMP'')
            left outer join tpa_enr_policy_member tepm on (tepm.member_seq_id=cad.member_seq_id)
            left outer join tpa_enr_policy tep on (tep.policy_seq_id=cad.policy_seq_id)
            left outer join clm_hospital_details chd on (chd.claim_seq_id=cad.claim_seq_id)
            left outer join tpa_hosp_info thi on (thi.hosp_seq_id=chd.hosp_seq_id)
            left outer join tpa_general_code gc on (gc.general_type_id=cad.clm_status_type_id)
            left outer join tpa_general_code gc1 on (gc1.general_type_id=a.clm_type_gen_type_id)
            left outer join inv_status inv on (inv.claim_seq_id = cad.claim_seq_id)
            left outer join tpa_fraud_inv_details tfi on (tfi.inv_seq_id=inv.inv_seq_id)';
  ELSIF v_mode = 'PAT' THEN
             v_sql_str := 
              'with inv_status as 
                    (select max(inv_seq_id) as inv_seq_id,pat_auth_seq_id from tpa_fraud_inv_details group by pat_auth_seq_id)
                 select pad.pat_auth_seq_id as seq_id,
                 pad.pre_auth_number pat_clm_no,
                 nvl(thi.hosp_name,nd.provider_name)  as hosp_name,
                 tepm.mem_name||'' ''|| tepm.mem_last_name||'' ''|| tepm.family_name as mem_name,
                 nvl(tepm.tpa_enrollment_id,pad.tpa_enrollment_id) as tpa_enrollment_id,
                case tep.enrol_type_id when ''COR'' then ''Corporate''
                                       when ''IND'' then ''Individual''
                                       else null end pol_type,
                tgc.description pat_clm_status ,
                null as claim_type,
                 case upper(pad.status_code_id)      when ''SUSP'' then ''Suspected Fraud''
                                                     when ''ALKT'' then ''Alkoot Clarification''
                                                     when ''PROV'' then ''Provider Clarification'' else null end as internal_remaks_status,
                      case pad.risk_level when ''LR'' then ''Low Risk''
                                          when ''IR'' then ''Intermediate Risk''
                                          when ''HR'' then ''High Risk'' else null end risk_level,
             CASE WHEN pad.parent_pat_auth_seq_id is not null 
                  and nvl(pad.parent_pat_auth_seq_id,0) != 0
                  and pad.pat_enhanced_yn = ''N''   then
                  ''Y''
                  ELSE
                  ''N''
                  END AS enhanced_preauthyn,
                pad.pat_enhanced_yn,
                pad.status_code_id as status_code_id  
            from pat_authorization_details pad
            left outer join tpa_hosp_info thi on (pad.hosp_seq_id=thi.hosp_seq_id)
            join tpa_enr_policy_member tepm on (pad.member_seq_id=tepm.member_seq_id)
            join tpa_enr_policy_group tepg on (tepm.policy_group_seq_id=tepg.policy_group_seq_id)
            join tpa_enr_policy tep on (tepg.policy_seq_id=tep.policy_seq_id)
            left outer join tpa_general_code tgc on (tgc.general_type_id=pad.pat_status_type_id)
            left outer join app.tpa_partner_info ptr on (ptr.ptnr_seq_id = pad.ptnr_seq_id)  ---newly added
            left outer join pat_non_network_details nd on (nd.pat_auth_seq_id=pad.pat_auth_seq_id)
            left outer join inv_status inv on (inv.pat_auth_seq_id = pad.pat_auth_seq_id)
            left outer join tpa_fraud_inv_details tfi on (tfi.inv_seq_id=inv.inv_seq_id)';
   END IF;
   
   IF v_mode = 'CLM' THEN
       IF v_invoice_number IS NOT NULL THEN
         v_where := v_where  ||' AND upper(trim(replace(cad.invoice_number, '' '',''''))) like :v_invoice_number';
         i := i+1;
         bind_tab(i) := '%'||UPPER(trim(replace(v_invoice_number, ' ','')))||'%';
       END IF;
       
      IF v_claim_type IS NOT NULL THEN
        v_where := v_where  ||' AND a.clm_type_gen_type_id = :v_claim_type';
        i := i+1;
        bind_tab(i) := UPPER(v_claim_type);
      END IF;

      IF v_batch_no IS NOT NULL THEN
        v_where := v_where  ||' AND a.batch_no = :v_batch_no';
         i := i+1;
         bind_tab(i) := (v_batch_no);
      END IF;
      
      IF v_process_type IS NOT NULL THEN
        v_where := v_where  || ' AND NVL(cad.process_type,''RGL'') = :v_process_type ';
         i := i+1;
         bind_tab(i) := v_process_type;
      END IF;
     
      
      IF v_partner_seq_id IS NOT NULL THEN
       v_where := v_where  ||' AND cad.ptnr_seq_id  = :v_partner_seq_id ';
       i := i+1;
         bind_tab(i) := v_partner_seq_id;
      END IF;
      
         
     IF v_status_type_id IS NOT NULL THEN
        v_where := v_where  ||' AND cad.clm_status_type_id = :v_status_type_id';
         i := i+1;
         bind_tab(i) := UPPER(v_status_type_id);
     END IF;
     
     IF v_risk_level IS NOT NULL THEN
        v_where := v_where  ||' AND cad.risk_level = :v_risk_level';
        i := i+1;
        bind_tab(i) := v_risk_level;
      END IF;
      
    IF v_benifit_type IS NOT NULL THEN
     v_where := v_where  ||' AND cad.benifit_type  = :v_benifit_type ';
     i := i+1;
       bind_tab(i) := v_benifit_type;
    END IF;
    
     IF v_claim_number IS NOT NULL THEN
      v_where := v_where  ||' AND cad.claim_number = trim(:v_claim_number)';
      i := i+1;
      bind_tab(i) := UPPER(v_claim_number);
    END IF;

    IF v_settlement_number IS NOT NULL THEN
      v_where := v_where  ||' AND cad.settlement_number = :v_settlement_number';
      i := i+1;
      bind_tab(i) := UPPER(v_settlement_number);
    END IF;
      
  ELSIF v_mode = 'PAT' THEN
     
      IF v_process_type IS NOT NULL THEN
          v_where := v_where  || ' AND NVL(pad.process_type,''RGL'') = :v_process_type ';
           i := i+1;
           bind_tab(i) := v_process_type;
       END IF;
       
        
       IF v_risk_level IS NOT NULL THEN
          v_where := v_where  ||' AND pad.risk_level = :v_risk_level';
          i := i+1;
          bind_tab(i) := v_risk_level;
        END IF;
        
        IF v_partner_seq_id IS NOT NULL THEN
         v_where := v_where  ||' AND pad.ptnr_seq_id  = :v_partner_seq_id ';
         i := i+1;
           bind_tab(i) := v_partner_seq_id;
        END IF;
        
       IF v_status_type_id IS NOT NULL THEN
          v_where := v_where  ||' AND pad.pat_status_type_id = :v_status_type_id';
           i := i+1;
           bind_tab(i) := UPPER(v_status_type_id);
       END IF;
       
       IF v_benifit_type IS NOT NULL THEN
          v_where := v_where  ||' AND pad.benifit_type  = :v_benifit_type ';
          i := i+1;
          bind_tab(i) := v_benifit_type;
       END IF;
       
        IF v_pre_auth_number IS NOT NULL THEN
         v_where := v_where  ||' AND pad.pre_auth_number = trim(:v_pre_auth_number) ';
         i := i+1;
           bind_tab(i) := v_pre_auth_number;
        END IF;
        
       IF v_auth_number IS NOT NULL THEN
         v_where := v_where  ||' AND pad.auth_number = :v_auth_number ';
         i := i+1;
           bind_tab(i) := v_auth_number;
        END IF;
      END IF;
         ----- COMMON FIELDS FOR BOTH MODES
          IF v_policy_number IS NOT NULL THEN
            v_where := v_where  ||' AND tep.policy_number = :v_policy_number';
             i := i+1;
             bind_tab(i) := UPPER(v_policy_number);
          END IF;

          IF v_tpa_enrollment_id IS NOT NULL THEN
            v_where := v_where  ||' AND tepm.tpa_enrollment_id = :v_tpa_enrollment_id';
             i := i+1;
             bind_tab(i) := UPPER(v_tpa_enrollment_id);
          END IF;
          
         IF v_mem_name IS NOT NULL THEN
            v_where := v_where  ||' AND tepm.mem_name = :v_mem_name';
             i := i+1;
             bind_tab(i) := UPPER(v_mem_name);
         END IF;
         
          IF v_provider_id IS NOT NULL THEN
            v_where := v_where  || ' AND thi.hosp_licenc_numb = :v_provider_id ';
             i := i+1;
             bind_tab(i) := UPPER(v_provider_id);
          END IF;
          
          IF v_enr_type IN ('IND', 'COR') THEN
            v_where := v_where  || ' AND (tep.enrol_type_id) = :v_enroll_id ';
            i := i+1;
            bind_tab(i) := v_enr_type;
          END IF;
         
          IF v_inv_status IS NOT NULL THEN
            v_where := v_where  || ' AND (tfi.inv_status) = :v_inv_status ';
            i := i+1;
            bind_tab(i) := v_inv_status;
          END IF;
          
       IF v_where IS NOT NULL THEN
         v_where   := ' WHERE '|| SUBSTR(v_where,5);
         v_sql_str := v_sql_str ||v_where;
      END IF;
      
      IF v_mode = 'CLM' THEN
        v_sql_str := 'SELECT * FROM
            (SELECT A.*,DENSE_RANK() OVER (ORDER BY '||v_sort_var||' '||v_sort_order||',ROWNUM)
            Q FROM (' ||v_sql_str|| ') A WHERE status_code_id in (''SUSP'')) WHERE  Q>= :v_start_num AND Q<= :v_end_num ';
     
       ELSIF v_mode = 'PAT' THEN
          v_sql_str := 'SELECT * FROM
            (SELECT A.*,DENSE_RANK() OVER (ORDER BY '||v_sort_var||' '||v_sort_order||',ROWNUM)
            Q FROM (' ||v_sql_str|| ') A WHERE status_code_id in (''SUSP'') and PAT_ENHANCED_YN = ''N'') WHERE  Q>= :v_start_num AND Q<= :v_end_num ';
         
      END IF;

    IF bind_tab.FIRST IS NOT NULL THEN
       CASE bind_tab.COUNT
         WHEN 1  THEN OPEN result_set FOR v_sql_str USING bind_tab(1), v_start_num , v_end_num ;
         WHEN 2  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2), v_start_num , v_end_num ;
         WHEN 3  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) , v_start_num , v_end_num ;
         WHEN 4  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) , v_start_num , v_end_num ;
         WHEN 5  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5), v_start_num , v_end_num ;
         WHEN 6  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6), v_start_num , v_end_num ;
         WHEN 7  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6),bind_tab(7), v_start_num , v_end_num ;
         WHEN 8  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6),bind_tab(7),bind_tab(8), v_start_num , v_end_num ;
         WHEN 9  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6),bind_tab(7),bind_tab(8),bind_tab(9), v_start_num , v_end_num ;
         WHEN 10 THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6),bind_tab(7),bind_tab(8),bind_tab(9),bind_tab(10), v_start_num , v_end_num ;
         WHEN 11 THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6),bind_tab(7),bind_tab(8),bind_tab(9),bind_tab(10),bind_tab(11), v_start_num , v_end_num ;
         WHEN 12 THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6),bind_tab(7),bind_tab(8),bind_tab(9),bind_tab(10),bind_tab(11),bind_tab(12), v_start_num , v_end_num ;
         WHEN 13 THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6),bind_tab(7),bind_tab(8),bind_tab(9),bind_tab(10),bind_tab(11),bind_tab(12), bind_tab(13), v_start_num , v_end_num ;
         WHEN 14 THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6),bind_tab(7),bind_tab(8),bind_tab(9),bind_tab(10),bind_tab(11),bind_tab(12), bind_tab(13),bind_tab(14), v_start_num , v_end_num ;
         WHEN 15 THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6),bind_tab(7),bind_tab(8),bind_tab(9),bind_tab(10),bind_tab(11),bind_tab(12), bind_tab(13),bind_tab(14),bind_tab(15), v_start_num , v_end_num ;
         WHEN 16 THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6),bind_tab(7),bind_tab(8),bind_tab(9),bind_tab(10),bind_tab(11),bind_tab(12), bind_tab(13),bind_tab(14),bind_tab(15), bind_tab(16), v_start_num , v_end_num ;
         WHEN 17 THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6),bind_tab(7),bind_tab(8),bind_tab(9),bind_tab(10),bind_tab(11),bind_tab(12), bind_tab(13),bind_tab(14),bind_tab(15), bind_tab(16), bind_tab(17), v_start_num , v_end_num ;
       END CASE;
     ELSE
       OPEN result_set FOR v_sql_str USING v_start_num , v_end_num ;
     END IF;

  END select_cfd_pat_clm_list;
--===================================================================================================
 ------------- INVESTIGATION STATUS SAVE -------------------
PROCEDURE save_inv_status(
                           v_mode                IN      char,
                           v_seq_id              IN      clm_authorization_details.claim_seq_id%type,
                           v_inv_status          IN      tpa_fraud_inv_details.inv_status%type,
                           v_inv_out_category    IN      tpa_fraud_inv_details.inv_out_category%type,
                           v_amt_util_for_inv    IN      tpa_fraud_inv_details.amt_util_for_inv%type,
                           v_amount_saved        IN      tpa_fraud_inv_details.amount_saved%type,
                           v_cfd_remarks         IN      tpa_fraud_inv_details.cfd_remarks%type,
                           v_inv_start_date      IN      varchar2,
                           v_added_by            IN      tpa_fraud_inv_details.added_by%type,
                           v_rows_processed      OUT     number
                           )
IS
 CURSOR clm_type_cur IS SELECT claim_type FROM app.clm_authorization_details 
                                          WHERE claim_seq_id = v_seq_id ;
        v_clm_type VARCHAR2(3);
 CURSOR inv_stauts_cur(V_MODE VARCHAR2) IS SELECT * from (SELECT inv_status FROM app.tpa_fraud_inv_details 
                                        WHERE CASE WHEN v_mode = 'PAT' THEN pat_auth_seq_id 
                                                   WHEN v_mode = 'CLM' THEN claim_seq_id END = v_seq_id ORDER BY inv_seq_id DESC);
        v_old_inv_status app.tpa_fraud_inv_details.inv_status%TYPE;
        v_dest_msg_seq_id VARCHAR2(250);
        v_completed_yn VARCHAR2(2);
        v_status   VARCHAR2(5);
BEGIN
   IF v_mode = 'PAT' THEN
      SELECT completed_yn,pat_status_type_id into v_completed_yn,v_status from pat_authorization_details  where pat_auth_seq_id = v_seq_id;
      IF v_status not in( 'APR','PCO','PCN','REJ') then
         OPEN inv_stauts_cur (V_MODE);
         FETCH inv_stauts_cur INTO v_old_inv_status;
         CLOSE inv_stauts_cur;
       INSERT INTO APP.TPA_FRAUD_INV_DETAILS( inv_seq_id ,
                                              pat_auth_seq_id,
                                              inv_status ,
                                              inv_out_category ,
                                              amt_util_for_inv ,
                                              amount_saved ,
                                              cfd_remarks ,
                                              inv_start_date ,
                                              added_date ,
                                              added_by 
                                            )
                                      VALUES  
                                            (app.tpa_inv_seq.nextval,
                                             v_seq_id,
                                             v_inv_status,
                                             v_inv_out_category,
                                             v_amt_util_for_inv,
                                             v_amount_saved,
                                             v_cfd_remarks,
                                             to_date(v_inv_start_date,'DD/MM/YYYY'),
                                             SYSDATE,
                                             v_added_by ) ;
                                             
                           v_rows_processed := SQL%ROWCOUNT;
                                             
             UPDATE pat_authorization_details pad 
                SET suspect_veri_check = CASE WHEN v_inv_status IN ('CA','PCA','FD') THEN 'Y'
                                              ELSE NULL END
                WHERE pad.pat_auth_seq_id = v_seq_id;
           END IF;
    ELSIF  v_mode = 'CLM' THEN
           SELECT completed_yn,clm_status_type_id into v_completed_yn,v_status from clm_authorization_details  where claim_seq_id = v_seq_id;
       IF v_status not in( 'APR','PCO','PCN','REJ') then
         OPEN inv_stauts_cur (V_MODE);
         FETCH inv_stauts_cur INTO v_old_inv_status;
         CLOSE inv_stauts_cur;
         INSERT INTO APP.TPA_FRAUD_INV_DETAILS( inv_seq_id ,
                                              claim_seq_id,
                                              inv_status ,
                                              inv_out_category ,
                                              amt_util_for_inv ,
                                              amount_saved ,
                                              cfd_remarks ,
                                              inv_start_date ,
                                              added_date ,
                                              added_by 
                                            )
                                      VALUES  
                                            (app.tpa_inv_seq.nextval,
                                             v_seq_id,
                                             v_inv_status,
                                             v_inv_out_category,
                                             v_amt_util_for_inv,
                                             v_amount_saved,
                                             v_cfd_remarks,
                                             to_date(v_inv_start_date,'DD/MM/YYYY'),
                                             SYSDATE,
                                             v_added_by ) ;
                                             
                       v_rows_processed := SQL%ROWCOUNT;
                                             
            UPDATE clm_authorization_details cad 
                SET suspect_veri_check = CASE WHEN v_inv_status IN ('CA','PCA','FD') THEN 'Y'
                                              ELSE NULL END
                WHERE cad.claim_seq_id = v_seq_id  ;
      END IF;
      END IF;    
                
      
  COMMIT;
         IF v_mode = 'PAT' AND nvl(v_old_inv_status,'Y') <> v_inv_status and v_inv_status <> 'II'   THEN
            GENERATE_MAIL_PKG.proc_generate_message('CFD_PAT_CONFIRM',
                                                     v_seq_id,
                                                     v_added_by,
                                                     v_dest_msg_seq_id);
         ELSIF v_mode = 'CLM' AND  nvl(v_old_inv_status,'Y') <> v_inv_status and v_inv_status <> 'II' THEN
           OPEN clm_type_cur;
           FETCH clm_type_cur INTO v_clm_type;
           CLOSE clm_type_cur;

            IF v_clm_type = 'CNH' THEN
               GENERATE_MAIL_PKG.proc_generate_message('CFD_NETCLM_CONFIRM',
                                                        v_seq_id,
                                                        v_added_by,
                                                        v_dest_msg_seq_id);
            ELSIF v_clm_type = 'CTM' THEN
               GENERATE_MAIL_PKG.proc_generate_message('CFD_RECLM_CONFIRM',
                                                      v_seq_id,
                                                      v_added_by,
                                                      v_dest_msg_seq_id);
            END IF;
        END IF;
END save_inv_status;
--================================================================================================
--- added in CFD cr for showing internal & investigation deatils --------------
PROCEDURE  select_int_inv_details(v_mode           IN  VARCHAR2,
                                  v_pat_clm_seq_id IN  NUMBER,
                                  v_int_rem_cur    OUT SYS_REFCURSOR,
                                  v_inv_stat_cur   OUT SYS_REFCURSOR
                                 )
 IS 

  CURSOR inv_status_cur IS 
                           SELECT CASE  inv_status WHEN 'II' THEN 'Investigation In-progress'
                                          WHEN 'CA' THEN 'Cleared for Approval'
                                          WHEN 'PCA' THEN 'Partially Cleared For Approval'
                                          WHEN 'FD' THEN 'Fraud Detected' 
                                          ELSE NULL END cur_inv_status,
                                  CASE inv_out_category  WHEN 'MOF' THEN 'Misrepresentation Of Facts'
                                                             WHEN 'CBMP' THEN 'Collision Between Member And Provider'
                                                             WHEN 'AAUP' THEN 'Abuse And Undocumented Services'
                                                             WHEN 'PB' THEN 'Phantom Billing'
                                                             WHEN 'DB' THEN 'Duplicate Billing'
                                                             WHEN 'UOS' THEN 'Unbundling Of Services'
                                                             WHEN 'OU' THEN 'Overutilization'
                                                             ELSE NULL END cur_inv_out_category,
                                        inv_status,
                                        inv_out_category,
                                        amt_util_for_inv,
                                        amount_saved,
                                        cfd_remarks,
                                        inv_start_date,
                                   CASE WHEN inv_status IN ('CA','PCA','FD') THEN added_date ELSE NULL END inv_dec_date
                                                        FROM 
                                                             (SELECT tfv.inv_status,
                                                                     tfv.inv_out_category,
                                                                     tfv.amt_util_for_inv,
                                                                     tfv.amount_saved,
                                                                     tfv.cfd_remarks,
                                                                     tfv.added_date,
                                                                     tfv.inv_start_date
                                                                     FROM app.tpa_fraud_inv_details tfv WHERE CASE v_mode WHEN 'PAT' THEN tfv.pat_auth_seq_id ELSE tfv.claim_seq_id END = v_pat_clm_seq_id ORDER BY inv_seq_id DESC ) WHERE rownum=1;
     
           inv_str_rec inv_status_cur%ROWTYPE;
     
  CURSOR inv_star_date IS SELECT * FROM (SELECT a.inv_start_date FROM app.tpa_fraud_inv_details a 
                                                               WHERE CASE v_mode WHEN 'PAT' THEN a.pat_auth_seq_id ELSE a.claim_seq_id END = v_pat_clm_seq_id AND
                                                                     a.inv_start_date IS NOT NULL AND a.inv_status = 'II' ORDER BY a.inv_seq_id DESC ) WHERE rownum=1;
         v_inv_sta_date app.tpa_fraud_inv_details.inv_start_date%TYPE;                                                                  
     
BEGIN
  
  OPEN inv_status_cur ;
  FETCH inv_status_cur INTO inv_str_rec;
  CLOSE inv_status_cur;
  
  OPEN inv_star_date ;
  FETCH inv_star_date INTO v_inv_sta_date;
  CLOSE inv_star_date;
                     ---- For current investion/Internal remarks information
  IF v_mode = 'PAT' THEN 
         OPEN v_int_rem_cur FOR
             SELECT li.contact_name AS code_added_by,
                    to_char(code_added_date,'dd/mm/yyyy hh:mi AM') code_added_date,
                    status_code_id,
                    risk_level,
                    CASE UPPER(pad.status_code_id) WHEN 'SUSP' THEN 'Suspected Fraud'
                                                   WHEN 'ALKT' THEN 'Alkoot Clarification'
                                                   WHEN 'PROV' THEN 'Provider Clarification' ELSE NULL END AS  int_remk_status,
                    pad.code_remarks,
                    CASE WHEN pad.pat_status_type_id in('APR','REJ','PCO','PCN') THEN 'Y' ELSE 'N' END AS completed_yn,
                    CASE WHEN pad.status_code_id IS NOT NULL THEN 'Y' ELSE 'N' END AS fraud_yn,
                    NVL(pad.suspect_veri_check,'N') AS suspect_veri_check,
                    CASE pad.risk_level WHEN 'LR' THEN 'Low Risk'
                                        WHEN 'IR' THEN 'Intermediate Risk'
                                        WHEN 'HR' THEN 'High Risk' ELSE NULL END risk_level_desc,
                    inv_str_rec.cur_inv_status as cur_inv_status ,
                    inv_str_rec.cur_inv_out_category as cur_inv_out_category,
                    inv_str_rec.inv_status as inv_status,
                    inv_str_rec.inv_out_category as inv_out_category,
                    inv_str_rec.amt_util_for_inv as amt_util_for_inv,
                    inv_str_rec.amount_saved as amount_saved,
                    inv_str_rec.cfd_remarks as cfd_remarks,
                    inv_str_rec.inv_start_date as inv_start_date,
                    trunc(inv_str_rec.inv_dec_date) - trunc(v_inv_sta_date) as inv_tat                       
                    FROM pat_authorization_details pad JOIN tpa_user_contacts li ON(li.contact_seq_id=pad.code_added_by)
                    WHERE pad.pat_auth_seq_id=v_pat_clm_seq_id;
                    
   ELSIF v_mode = 'CLM' THEN 
   
        OPEN v_int_rem_cur FOR
           SELECT li.contact_name as code_added_by,
                  to_char(code_added_date,'dd/mm/yyyy hh:mi AM') code_added_date,
                  status_code_id,
                  risk_level,
                  CASE UPPER(clm.status_code_id) WHEN 'SUSP' THEN 'Suspected Fraud'
                                                 WHEN 'ALKT' THEN 'Alkoot Clarification'
                                                 WHEN 'PROV' THEN 'Provider Clarification' ELSE NULL END  int_remk_status,
                  clm.code_remarks,
                  CASE WHEN clm.clm_status_type_id in('APR','REJ','PCO','PCN') THEN 'Y' ELSE 'N' END AS completed_yn,
                  CASE WHEN clm.status_code_id IS NOT NULL THEN 'Y' ELSE 'N' END AS fraud_yn,
                  CASE clm.risk_level WHEN 'LR' THEN 'Low Risk'
                                      WHEN 'IR' THEN 'Intermediate Risk'
                                      WHEN 'HR' THEN 'High Risk' ELSE NULL END risk_level_desc,
                  NVL(clm.suspect_veri_check,'N') AS suspect_veri_check,
                  inv_str_rec.cur_inv_status as cur_inv_status ,
                  inv_str_rec.cur_inv_out_category as cur_inv_out_category,
                  inv_str_rec.inv_status as inv_status,
                  inv_str_rec.inv_out_category as inv_out_category,
                  inv_str_rec.amt_util_for_inv as amt_util_for_inv,
                  inv_str_rec.amount_saved as amount_saved,
                  inv_str_rec.cfd_remarks as cfd_remarks,
                  inv_str_rec.inv_start_date as inv_start_date,
                  trunc(inv_str_rec.inv_dec_date) - trunc(v_inv_sta_date) as inv_tat                       
                  FROM clm_authorization_details clm JOIN tpa_user_contacts li on(li.contact_seq_id=clm.code_added_by)
                  WHERE clm.claim_seq_id=v_pat_clm_seq_id;
      
 END IF;
                 ------- For getting investigation log inforimation
            OPEN v_inv_stat_cur FOR
                 SELECT  tfv.inv_seq_id ,
                         CASE  tfv.inv_status WHEN 'II' THEN 'Investigation In-progress'
                                          WHEN 'CA' THEN 'Cleared for Approval'
                                          WHEN 'PCA' THEN 'Partially Cleared For Approval'
                                          WHEN 'FD' THEN 'Fraud Detected' 
                                          ELSE NULL END inv_status,
                 
                         CASE tfv.inv_out_category WHEN 'MOF' THEN 'Misrepresentation Of Facts'
                                               WHEN 'CBMP' THEN 'Collision Between Member And Provider'
                                               WHEN 'AAUP' THEN 'Abuse And Undocumented Services'
                                               WHEN 'PB' THEN 'Phantom Billing'
                                               WHEN 'DB' THEN 'Duplicate Billing'
                                               WHEN 'UOS' THEN 'Unbundling Of Services'
                                               WHEN 'OU' THEN 'Overutilization'
                                               ELSE NULL END inv_out_category,
                         tfv.amt_util_for_inv,
                         tfv.amount_saved,
                         tfv.cfd_remarks,
                         CASE WHEN tfv.inv_status = 'II' and tfv.inv_start_date IS NOT NULL THEN to_char(tfv.inv_start_date,'dd/mm/yyyy') ELSE NULL END inv_start_date,
                         to_char(tfv.added_date,'dd/mm/yyyy') added_date,
                         tuc.contact_name as added_by
                   FROM app.tpa_fraud_inv_details tfv JOIN app.tpa_user_contacts tuc ON (tfv.added_by = tuc.contact_seq_id)
                                                      WHERE CASE v_mode WHEN 'PAT' THEN tfv.pat_auth_seq_id ELSE tfv.claim_seq_id END = v_pat_clm_seq_id order by tfv.inv_seq_id desc ;
                       
END  select_int_inv_details;
--=====================================================================================================
 --CR-0322ClaimDetailedReport
 ----****************************************
PROCEDURE select_clm_rpt_list(v_fromdate                            IN   VARCHAR2 ,
                              v_toDate                              IN   VARCHAR2 ,
                              v_fromdate1                           IN   VARCHAR2 ,
                              v_toDate1                             IN   VARCHAR2 ,
                              v_patientName                         IN  clm_authorization_details.mem_name%type,
                              v_status                              IN  tpa_general_code.description%type,
                              v_invoice_number                      IN  clm_authorization_details.invoice_number%type,
                              v_batch_no                            in  varchar2,
                              v_memberId                            IN  clm_authorization_details.tpa_enrollment_id%type,
                              v_claim_number                        IN  clm_authorization_details.claim_number%type,
                              v_benifit_type                        in varchar2,
                              v_ref_no                              IN  clm_authorization_details.EVENT_NO%type,
                              v_qatar_id                            IN  varchar2,
                              v_pay_ref_no                          IN VARCHAR2,
                              V_HOSP_SEQ_ID                         IN  pat_authorization_details.hosp_seq_id%type,
                              v_rpt_id                              IN  VARCHAR2,
                              v_sort_var                            IN  VARCHAR2,
                              v_sort_order                          IN  VARCHAR2 ,
                              v_start_num                           IN  NUMBER ,
                              v_end_num                             IN  NUMBER ,
                              result_set                            OUT SYS_REFCURSOR
                             )IS
                             
    v_sql_str                            VARCHAR2(10000) ;
    TYPE bind_tab_type IS TABLE OF VARCHAR2(250) INDEX BY BINARY_INTEGER ;
    bind_tab                             bind_tab_type;
    i                                    NUMBER(2) := 0;
    v_where                              VARCHAR2(2000);
  
    v_fdate    clm_authorization_details.date_of_hospitalization%type:=to_date(v_fromdate,'dd/mm/yyyy');
    v_to_date  clm_authorization_details.date_of_discharge%type  :=to_date(v_toDate,'dd/mm/yyyy')+1;
    v_fdate1   clm_authorization_details.CLM_RECEIVED_DATE%type:=to_date(v_fromdate1,'dd/mm/yyyy');
    v_to_date1 clm_authorization_details.CLM_RECEIVED_DATE%type  :=to_date(v_toDate1,'dd/mm/yyyy')+1;

    
    
  BEGIN

   IF v_rpt_id = 'CDR' THEN
    v_sql_str :='SELECT TO_CHAR(CAD.CLM_RECEIVED_DATE,''DD/MM/YYYY'') AS CLM_RECEIVED_DATE,
                        TO_CHAR(CAD.DATE_OF_HOSPITALIZATION,''DD/MM/YYYY'') AS DATE_OF_HOSPITALIZATION,
                        b.BATCH_NO,
                        CAD.INVOICE_NUMBER,
                        CAD.EVENT_NO,
                        CAD.TPA_ENROLLMENT_ID,
                        CAD.EMIRATE_ID,
                        CAD.MEM_NAME,
                        CAD.CLAIM_NUMBER,
                        case when Cad.benifit_type = ''OPTS'' then ''Out-Patient'' 
                             when Cad.benifit_type = ''OPTC'' then ''Optical''
                             when Cad.benifit_type = ''IMTI'' then ''In-Patient Maternity''
                             when Cad.benifit_type = ''OMTI''  then ''Out-Patient Maternity''
                             when Cad.benifit_type = ''IPT'' then ''In-Patient''
                             when Cad.benifit_type = ''DNTL'' then ''Dental''
                             when Cad.benifit_type = ''HEAC'' then ''Health Check-up''
                             when Cad.benifit_type = ''DAYC'' then ''Daycare'' end as BENIFIT_TYPE ,
                        EC.DESCRIPTION AS CLM_STATUS_TYPE_ID,
                        /*C.INTERNAL_CODE,
                        case when length(c.code) > 14 then 
                             regexp_substr(mas.Short_Description,''[^,]+'')
                        else c.internal_desc end as INTERNAL_DESC,
                        C.PROVIDER_NET_AMOUNT as PAT_APPROVED_AMOUNT,
                        C.GROSS_AMOUNT AS TOT_GROSS_AMOUNT,
                        C.DISCOUNT_AMOUNT AS TOT_DISCOUNT_AMOUNT,
                        C.PATIENT_SHARE_AMOUNT AS TOT_PATIENT_SHARE_AMOUNT,
                        case when (nvl(cad.ucr_flag,''N'')=''N'' and nvl(cad.ri_copar_flag,''N'')=''N'') then (nvl(c.disc_gross_amount,0)-nvl(c.patient_share_amount,0))-nvl(c.approved_amount,0) 
                        else nvl(c.disallowed_amount,0) end  AS DISALLOWED_AMOUNT,
                        C.APPROVED_AMOUNT AS TOT_APPROVED_AMOUNT,
                        CASE WHEN C.OVERRIDE_YN = ''Y'' AND (C.DISC_GROSS_AMOUNT - C.PATIENT_SHARE_AMOUNT) > 0 THEN
                          CASE WHEN (C.DISC_GROSS_AMOUNT - C.PATIENT_SHARE_AMOUNT) = C.ALLOWED_AMOUNT THEN
                            NULL
                          ELSE 
                            C.DENIAL_DESC
                          END
                        ELSE 
                           C.DENIAL_DESC
                        END AS DENIAL_DESC,*/
                        --C.DENIAL_DESC,
                        CAD.TOT_APPROVED_AMOUNT,
                        f.CHECK_NUM AS PAYMENT_REFRENCE_NUMBER,
                        TO_CHAR(f.CHECK_DATE,''DD/MM/YYYY'') AS CHECK_DATE,
                        DECODE(CP.CLAIM_PAYMENT_STATUS, ''READY_TO_BANK'', ''READY TO BANK'', ''SENT_TO_BANK'', ''SENT TO BANK'', ''PENDING'', ''PENDING'',''PAID'',''PAID'') AS CLAIM_PAYMENT_STATUS

                    from CLM_AUTHORIZATION_DETAILS cad left outer join clm_batch_upload_details b on (b.clm_batch_seq_id=cad.clm_batch_seq_id and b.batch_status_type=''COMP'')
                    --left outer join PAT_ACTIVITY_DETAILS C on (c.CLAIM_SEQ_ID=Cad.CLAIM_SEQ_ID)
                    left outer join tpa_claims_payment cp on (cad.claim_seq_id=cp.claim_seq_id)
                    left outer join tpa_payment_checks_details pcd on (cp.payment_seq_id=pcd.payment_seq_id)
                    left outer join tpa_claims_check f on (pcd.claims_chk_seq_id=f.claims_chk_seq_id)
                    left outer join tpa_enr_policy e on (e.policy_seq_id=cad.policy_seq_id)
                    left outer join clm_hospital_details HD on (HD.claim_seq_id=cad.claim_seq_id)
                    left outer join tpa_general_code ec on (Cad.CLM_STATUS_TYPE_ID = ec.general_type_id)
                    left outer join tpa_hosp_info thi on (thi.hosp_seq_id=HD.hosp_seq_id)
                    --left join APP.Tpa_Activity_Master_Details mas on (mas.Activity_Code=c.code)
                    ';
    
    ELSE 
     v_sql_str :=' SELECT TO_CHAR(CAD.CLM_RECEIVED_DATE,''DD/MM/YYYY'') AS CLM_RECEIVED_DATE,
                          TO_CHAR(CAD.DATE_OF_HOSPITALIZATION,''DD/MM/YYYY'') AS DATE_OF_HOSPITALIZATION,
                          b.BATCH_NO,
                          cad.INVOICE_NUMBER,
                          cad.EVENT_NO,
                          CAD.TPA_ENROLLMENT_ID,
                          cad.EMIRATE_ID,
                          cad.MEM_NAME,
                          case when Cad.benifit_type = ''OPTS'' then ''Out-Patient'' 
                          when Cad.benifit_type = ''OPTC'' then ''Optical''
                          when Cad.benifit_type = ''IMTI'' then ''In-Patient Maternity''
                          when Cad.benifit_type = ''OMTI''  then ''Out-Patient Maternity''
                          when Cad.benifit_type = ''IPT'' then ''In-Patient''
                          when Cad.benifit_type = ''DNTL'' then ''Dental''
                          when Cad.benifit_type = ''HEAC'' then ''Health Check-up''
                          when Cad.benifit_type = ''DAYC'' then ''Daycare'' end as BENIFIT_TYPE ,
                          cad.CLAIM_NUMBER,
                          EC.DESCRIPTION AS CLM_STATUS_TYPE_ID,
                          cad.REQUESTED_AMOUNT as PAT_APPROVED_AMOUNT,
                          cad.TOT_GROSS_AMOUNT,
                          cad.TOT_DISCOUNT_AMOUNT,
                          cad.TOT_PATIENT_SHARE_AMOUNT,
                          case when (nvl(cad.ucr_flag,''N'')=''N'' and nvl(cad.ri_copar_flag,''N'')=''N'') then
                            case when nvl(cad.completed_yn,''N'')=''Y''then 
                               CASE WHEN SIGN ((cad.tot_disc_gross_amount-nvl(cad.tot_patient_share_amount,0))-nvl(cad.final_app_amount,0)) = -1 THEN 0
                               ELSE (cad.tot_disc_gross_amount-nvl(cad.tot_patient_share_amount,0))-nvl(cad.final_app_amount,0) END
                            else CASE WHEN SIGN((cad.tot_disc_gross_amount-nvl(cad.tot_patient_share_amount,0))-nvl(cad.tot_approved_amount,0)) = -1 THEN 0
                                 ELSE (cad.tot_disc_gross_amount-nvl(cad.tot_patient_share_amount,0))-nvl(cad.tot_approved_amount,0) END
                          end end AS DISALLOWED_AMOUNT,
                          cad.TOT_APPROVED_AMOUNT,
                          F.CHECK_NUM AS PAYMENT_REFRENCE_NUMBER,
                          TO_CHAR(f.CHECK_DATE,''DD/MM/YYYY'') AS CHECK_DATE


                    FROM  clm_authorization_details cad 
                     join clm_batch_upload_details b on (b.clm_batch_seq_id=cad.clm_batch_seq_id and b.batch_status_type=''COMP'')
                     --join APP.CLM_BATCH_UPLOAD_DETAILS b on (b.CLM_BATCH_SEQ_ID=cad.CLM_BATCH_SEQ_ID)
                     left outer join tpa_claims_payment cp on (cad.claim_seq_id=cp.claim_seq_id)
                     left outer join FIN_APP.TPA_PAYMENT_CHECKS_DETAILS n on (n.PAYMENT_SEQ_ID=CP.PAYMENT_SEQ_ID)
                     left outer  join FIN_APP.tpa_claims_check f on (n.CLAIMS_CHK_SEQ_ID=f.CLAIMS_CHK_SEQ_ID)
                     left outer join tpa_general_code ec on (Cad.CLM_STATUS_TYPE_ID = ec.general_type_id)
                     left outer join clm_hospital_details HD on (HD.claim_seq_id=cad.claim_seq_id)
                     left outer join tpa_hosp_info thi on (thi.hosp_seq_id=HD.hosp_seq_id)';

      END IF;
    
    v_where := v_where ||' AND b.source_type_id in (''PLCL'',''PCLM'',''E_LM'',''INTL'') ';
    
    IF v_benifit_type IS NOT NULL THEN
      -- like changed to =
      v_where := v_where ||' AND Cad.BENIFIT_TYPE = :v_benifit_type ';
       i := i+1;
       bind_tab(i) := v_benifit_type;
    END IF;
  
    IF V_HOSP_SEQ_ID IS NOT NULL THEN
      -- like changed to =
      v_where := v_where ||' AND thi.hosp_seq_id = :V_HOSP_SEQ_ID ';
       i := i+1;
       bind_tab(i) := V_HOSP_SEQ_ID;
    END IF;
     
    IF v_to_date IS NOT NULL THEN 
          v_where := v_where  ||' AND Cad.DATE_OF_HOSPITALIZATION<=:v_to_date';
          i:=i+1;
         bind_tab(i) := v_to_date;
    END IF;
  
    IF v_fdate IS NOT NULL THEN
          v_where := v_where  ||' AND  Cad.DATE_OF_HOSPITALIZATION >=:v_fdate';
          i:=i+1;
         bind_tab(i) := v_fdate;
    END IF;
  
    IF v_to_date1 IS NOT NULL THEN 
          v_where := v_where  ||' AND cad.CLM_RECEIVED_DATE<=:v_to_date1';
          i:=i+1;
         bind_tab(i) := v_to_date1;
    END IF;
  
    IF v_fdate1 IS NOT NULL THEN
          v_where := v_where  ||' AND  cad.CLM_RECEIVED_DATE>=:v_fdate1';
          i:=i+1;
         bind_tab(i) := v_fdate1;
    END IF;
       
    IF v_patientName IS NOT NULL THEN
        -- like changed to =
        v_where := v_where  ||' AND trim(Cad.mem_name) LIKE :v_patientName';
         i := i+1;
         bind_tab(i) := UPPER(v_patientName)||'%';
    END IF;
  
    IF v_qatar_id IS NOT NULL THEN
        -- like changed to =
        v_where := v_where  ||' AND trim(Cad.EMIRATE_ID) LIKE :v_qatar_id';
         i := i+1;
         bind_tab(i) := UPPER(v_qatar_id)||'%';
    END IF;
  
    IF v_pay_ref_no IS NOT NULL THEN
        -- like changed to =
        v_where := v_where  ||' AND trim(F.CHECK_NUM) LIKE :v_pay_ref_no';
         i := i+1;
         bind_tab(i) := UPPER(v_pay_ref_no)||'%';
    END IF;
  
   IF v_invoice_number IS NOT NULL THEN
      -- like changed to =
      v_where := v_where  ||' AND cad.invoice_number =:v_invoice_number';
       i := i+1;
       bind_tab(i) := v_invoice_number;
   END IF;
   IF v_claim_number IS NOT NULL THEN
      -- like changed to =
      v_where := v_where ||' AND cad.claim_number = :v_claim_number ';
       i := i+1;
       bind_tab(i) := v_claim_number;
   END IF;
  
   IF v_batch_no IS NOT NULL THEN
      -- like changed to =
      v_where := v_where ||' AND B.BATCH_NO = :v_batch_no ';
       i := i+1;
       bind_tab(i) := v_batch_no;
   END IF;

   IF v_memberId IS NOT NULL THEN
      -- like changed to =
      v_where := v_where  ||' AND Cad.tpa_enrollment_id = :v_memberId ';
       i := i+1;
       bind_tab(i) := UPPER(v_memberId);
   END IF;
  
    
  IF v_status IS NOT NULL  THEN
      -- like changed to =
     v_where := v_where||' AND cad.CLM_STATUS_TYPE_ID = :v_status ';
      i := i+1;
     bind_tab(i) :=v_status;
  END IF;
  
  IF v_ref_no IS NOT NULL  THEN
      -- like changed to =
     v_where := v_where||' AND Cad.EVENT_NO = :v_ref_no ';
    i := i+1;
    bind_tab(i) :=v_ref_no;
  END IF;
     
   -- v_where := v_where||' AND   cad.SOURCE_TYPE_ID =''PLCL''';
    v_where := v_where||' AND   cad.CLAIM_TYPE =''CNH''';
    
    
  IF v_where IS NOT NULL THEN
      v_where   := ' WHERE '||SUBSTR(v_where,5);
      v_sql_str := v_sql_str ||v_where;
  END IF;
  --dbms_output.put_line(v_sql_str);

  
   v_sql_str := 'SELECT * FROM
                (SELECT A.*,DENSE_RANK() OVER (ORDER BY '||v_sort_var||' '||v_sort_order||',ROWNUM)
                Q FROM (' ||v_sql_str|| ') A ) WHERE  Q>= :v_start_num AND Q<= :v_end_num 
                ORDER BY CLAIM_NUMBER';
     -- dbms_output.put_line(v_sql_str);
     
    IF bind_tab.FIRST IS NOT NULL THEN
       CASE bind_tab.COUNT
       
        WHEN 1  THEN OPEN result_set FOR v_sql_str USING bind_tab(1), v_start_num , v_end_num ;
        WHEN 2  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2), v_start_num , v_end_num ;
        WHEN 3  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2) ,bind_tab(3) , v_start_num , v_end_num ;
        WHEN 4  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) , v_start_num , v_end_num ;
        WHEN 5  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5), v_start_num , v_end_num ;
        WHEN 6  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6), v_start_num , v_end_num ;
        WHEN 7  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6),bind_tab(7), v_start_num , v_end_num ;
        WHEN 8  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6),bind_tab(7),bind_tab(8), v_start_num , v_end_num ;
         
        END CASE;
     ELSE
       OPEN result_set FOR v_sql_str USING v_start_num , v_end_num ;
       
     END IF;
     
 END select_clm_rpt_list;
 --=============================================================================
  --CR-0322ClaimDetailedReport
 ----****************************************
 PROCEDURE PRVDR_CLM_RPT(v_input_list IN  VARCHAR2,
                          v_result_set  OUT SYS_REFCURSOR
                        )IS
                         
    str_tab    ttk_util_pkg.str_table_type;
    
  BEGIN
     str_tab := ttk_util_pkg.parse_str ( v_input_list );
     IF str_tab(6) IS NULL THEN
        str_tab(6) := to_char(SYSDATE,'dd/mm/yyyy');
     END IF;
     IF str_tab(4) IS NULL THEN
        str_tab(4) := to_char(SYSDATE,'dd/mm/yyyy');
     END IF;
     IF str_tab(1) = 'CDR' THEN
       OPEN v_result_set FOR
    	 
         WITH ICD_CODE_VW AS (SELECT CLAIM_SEQ_ID, TO_CHAR(LISTAGG(DIAGNOSYS_CODE, ',') WITHIN GROUP(ORDER BY DIAG_SEQ_ID)) AS DIAGNOSYS_CODE
                              FROM (SELECT CL.CLAIM_SEQ_ID, ICD.DIAGNOSYS_CODE, ICD.DIAG_SEQ_ID
                                    FROM DIAGNOSYS_DETAILS ICD
                                    JOIN CLM_AUTHORIZATION_DETAILS CL ON CL.CLAIM_SEQ_ID = ICD.CLAIM_SEQ_ID
                                    JOIN CLM_HOSPITAL_DETAILS HS ON HS.CLAIM_SEQ_ID = CL.CLAIM_SEQ_ID
                                    WHERE ICD.PRIMARY_AILMENT_YN != 'Y'
                                    AND (str_tab(2) IS NULL OR HS.HOSP_SEQ_ID = str_tab(2))
                                    ORDER BY ICD.DIAG_SEQ_ID
                                   )
                                   GROUP BY CLAIM_SEQ_ID
                              ) -- Added Query for CR-0293
                          
         SELECT TO_CHAR(CAD.CLM_RECEIVED_DATE,'DD/MM/YYYY') AS CLM_RECEIVED_DATE,
                TO_CHAR(CAD.DATE_OF_HOSPITALIZATION,'DD/MM/YYYY') AS DATE_OF_HOSPITALIZATION,
                b.BATCH_NO,
                CAD.INVOICE_NUMBER,
                CAD.EVENT_NO,
                CAD.TPA_ENROLLMENT_ID AS MEMBER_ID,
                CAD.EMIRATE_ID,
                CAD.MEM_NAME,
                CAD.CLAIM_NUMBER,
                case when Cad.benifit_type = 'OPTS' then 'Out-Patient' 
                            when Cad.benifit_type = 'OPTC' then 'Optical'
                            when Cad.benifit_type = 'IMTI' then 'In-Patient Maternity'
                            when Cad.benifit_type = 'OMTI'  then 'Out-Patient Maternity'
                            when Cad.benifit_type = 'IPT' then 'In-Patient'
                            when Cad.benifit_type = 'DNTL' then 'Dental'
                            when Cad.benifit_type = 'HEAC' then 'Health Check-up'
                            when Cad.benifit_type = 'DAYC' then 'Daycare' end as BENIFIT_TYPE ,
                EC.DESCRIPTION AS CLM_STATUS_TYPE_ID,
                C.INTERNAL_CODE,
                /*case when length(c.code) > 14 then 
                                              regexp_substr(mas.Short_Description,'[^,]+')
                                          else
                                         c.internal_desc end as INTERNAL_DESC,*/
                C.PROVIDER_NET_AMOUNT as PAT_APPROVED_AMOUNT,
                C.GROSS_AMOUNT AS TOT_GROSS_AMOUNT,
                C.DISCOUNT_AMOUNT AS TOT_DISCOUNT_AMOUNT,
                C.PATIENT_SHARE_AMOUNT AS TOT_PATIENT_SHARE_AMOUNT,
                case when (nvl(cad.ucr_flag,'N')='N' and nvl(cad.ri_copar_flag,'N')='N') then (nvl(c.disc_gross_amount,0)-nvl(c.patient_share_amount,0))-nvl(c.approved_amount,0) 
                              else nvl(c.disallowed_amount,0) end AS DIS_ALLOWED_AMOUNT,
                C.APPROVED_AMOUNT AS TOT_APPROVED_AMOUNT,
                CASE WHEN C.OVERRIDE_YN = 'Y' AND (C.DISC_GROSS_AMOUNT - C.PATIENT_SHARE_AMOUNT) > 0 THEN
                   CASE WHEN (C.DISC_GROSS_AMOUNT - C.PATIENT_SHARE_AMOUNT) = C.ALLOWED_AMOUNT THEN
                      NULL
                   ELSE 
                      C.DENIAL_DESC
                   END
                ELSE
                   C.DENIAL_DESC
                END AS DENIAL_DESC,
                C.DENIAL_DESC AS INTERNAL_SERVICE_CODE,
                f.CHECK_NUM AS PAYMENT_REFRENCE_NUMBER,
                TO_CHAR(f.CHECK_DATE,'DD/MM/YYYY') AS CHECK_DATE,
                C.CLAIM_SEQ_ID,
                DECODE(CP.CLAIM_PAYMENT_STATUS, 'READY_TO_BANK', 'READY TO BANK', 'SENT_TO_BANK', 'SENT TO BANK', 'PENDING', 'PENDING', 'PAID', 'PAID') AS CLAIM_PAYMENT_STATUS,
                ---- Added Column for CR-0293
                ROWNUM AS SLNO,
                PA.PRE_AUTH_NUMBER AS PREAPPROVAL_NO,
                TO_CHAR(CAD.DATE_OF_DISCHARGE, 'DD/MM/RRRR') AS DATE_OF_DISCHARGE,
                G.DESCRIPTION AS SYSTEM_OF_MEDICINE,
                E.DESCRIPTION AS ENCOUNTER_TYPE,
                CAD.CLINICIAN_ID,
                PR.CONTACT_NAME AS CLINICIAN_NAME,
                CAD.PRESENTING_COMPLAINTS AS SYMPTOMS,
                D.DIAGNOSYS_CODE AS PRINCIPAL_ICD_CODE,
                NVL(I.ICD_DESCRIPTION,IMD.SHORT_DESC) AS ICD_DESCRIPTION,
                NVL(REGEXP_SUBSTR (IC.DIAGNOSYS_CODE, '[^,]+', 1, 1), '') AS SECONDARY_ICD_CODE_1,
                NVL(REGEXP_SUBSTR (IC.DIAGNOSYS_CODE, '[^,]+', 1, 2), '') AS SECONDARY_ICD_CODE_2,
                NVL(REGEXP_SUBSTR (IC.DIAGNOSYS_CODE, '[^,]+', 1, 3), '') AS SECONDARY_ICD_CODE_3,
                NVL(REGEXP_SUBSTR (IC.DIAGNOSYS_CODE, '[^,]+', 1, 4), '') AS SECONDARY_ICD_CODE_4,
                NVL(REGEXP_SUBSTR (IC.DIAGNOSYS_CODE, '[^,]+', 1, 5), '') AS SECONDARY_ICD_CODE_5,
                TO_CHAR(CAD.FIRST_INCIDENT_DATE, 'DD/MM/RRRR') AS FIRST_INCIDENT_DATE,
                TO_CHAR(CAD.FIRST_REPORTED_DATE, 'DD/MM/RRRR') AS FIRST_REPORTED_DATE,
                TO_CHAR(C.START_DATE, 'DD/MM/RRRR') AS SERVICE_DATE,
                CASE WHEN C.ACTIVITY_TYPE_ID = 'ACT' THEN 'Activity'
                     WHEN C.ACTIVITY_TYPE_ID = 'DRG' THEN 'Drug'
                END AS ACTIVITY_TYPE,
                C.INTERNAL_DESC AS SERVICE_DESCRIPTION,
                C.CODE AS CPT_CODE,
                C.TOOTH_NO AS TOOTH_NUMBER,
                TO_CHAR(CAD.LMP_DATE, 'DD/MM/RRRR') AS DATE_OF_LMP,
                CASE WHEN CAD.CONCEPTION_TYPE = 'NAT' THEN 'Natural'
                     WHEN CAD.CONCEPTION_TYPE = 'AST' THEN 'Assisted'
                END AS NATURE_OF_CONCEPTION,
                --OBS.REMARKS AS OBSERVATION, --commented as cnf. by Venu 
                C.QUANTITY,
                CAD.FINAL_REMARKS AS FINAL_REMARKS
      
          from CLM_AUTHORIZATION_DETAILS cad  
          join clm_batch_upload_details b on (b.clm_batch_seq_id=cad.clm_batch_seq_id and b.batch_status_type='COMP')
          left outer join clm_hospital_details HD on (HD.claim_seq_id=cad.claim_seq_id)
          LEFT JOIN pat_authorization_details pa ON pa.claim_seq_id = cad.claim_seq_id -- CR-0293
          LEFT JOIN TPA_GENERAL_CODE G ON G.GENERAL_TYPE_ID = CAD.SYSTEM_OF_MEDICINE_TYPE_ID
          LEFT JOIN TPA_HOSP_PROFESSIONALS PR ON (PR.PROFESSIONAL_ID = CAD.CLINICIAN_ID AND pr.hosp_seq_id=hd.hosp_seq_id)
          LEFT JOIN TPA_ENCOUNTER_TYPE_CODES E ON E.ENCOUNTER_SEQ_ID = CAD.ENCOUNTER_TYPE_ID AND E.HEADER_TYPE = 'ENCOUNTER_TYPE'
          LEFT JOIN DIAGNOSYS_DETAILS D ON D.CLAIM_SEQ_ID = CAD.CLAIM_SEQ_ID AND D.PRIMARY_AILMENT_YN = 'Y'
          LEFT JOIN TPA_ICD_CODES I ON I.ICD_CODE = D.DIAGNOSYS_CODE
          LEFT JOIN TPA_ICD10_MASTER_DETAILS IMD ON IMD.ICD_CODE = D.DIAGNOSYS_CODE
          LEFT JOIN ICD_CODE_VW IC ON IC.CLAIM_SEQ_ID = D.CLAIM_SEQ_ID
          left outer join PAT_ACTIVITY_DETAILS C on (c.CLAIM_SEQ_ID=Cad.CLAIM_SEQ_ID)
          --LEFT JOIN PAT_OBSERVATION_DETAILS OBS ON OBS.ACTIVITY_DTL_SEQ_ID = C.ACTIVITY_DTL_SEQ_ID --commented as cnf. by Venu
          left outer join tpa_claims_payment cp on (cad.claim_seq_id=cp.claim_seq_id)
          left outer join tpa_payment_checks_details pcd on (cp.payment_seq_id=pcd.payment_seq_id)
          left outer join tpa_claims_check f on (pcd.claims_chk_seq_id=f.claims_chk_seq_id)
          left outer join tpa_enr_policy e on (e.policy_seq_id=cad.policy_seq_id)
          left outer join tpa_general_code ec on (Cad.CLM_STATUS_TYPE_ID = ec.general_type_id)
          left outer join tpa_hosp_info thi on (thi.hosp_seq_id=HD.hosp_seq_id)
         WHERE (str_tab(2) IS NULL OR THI.HOSP_SEQ_ID=str_tab(2))
           AND (str_tab(3) is null or  CAD.DATE_OF_HOSPITALIZATION >= to_date(str_tab(3),'dd/mm/yyyy') and CAD.DATE_OF_HOSPITALIZATION <= to_date(str_tab(4),'dd/mm/yyyy')+1)
           AND (str_tab(5) is null or CAD.CLM_RECEIVED_DATE >= to_date(str_tab(5),'dd/mm/yyyy') and CAD.CLM_RECEIVED_DATE <= to_date(str_tab(6),'dd/mm/yyyy')+1)
           AND (str_tab(7) IS NULL OR  CAD.MEM_NAME=str_tab(7))
           AND ( str_tab(8) IS NULL OR CAD.CLM_STATUS_TYPE_ID=str_tab(8))
           AND ( str_tab(9) IS NULL OR CAD.INVOICE_NUMBER=str_tab(9))
           AND ( str_tab(10) IS NULL OR b.BATCH_NO=str_tab(10))
           AND (str_tab(11) IS NULL OR  CAD.TPA_ENROLLMENT_ID=str_tab(11))
           AND ( str_tab(12) IS NULL OR CAD.CLAIM_NUMBER=str_tab(12))
           AND (str_tab(13) IS NULL OR  CAD.BENIFIT_TYPE=str_tab(13))
           AND (str_tab(14) IS NULL OR  CAD.EVENT_NO=str_tab(14))
           AND (str_tab(15) IS NULL OR  CAD.EMIRATE_ID=str_tab(15))
           AND (str_tab(16) IS NULL OR  F.CHECK_NUM=str_tab(16))
           AND   cad.CLAIM_TYPE ='CNH'
           AND b.SOURCE_TYPE_ID in ('PLCL','PCLM','E_LM','INTL')
           order by C.CLAIM_SEQ_ID
              --AND CAD.SOURCE_TYPE_ID ='PLCL'
            ;
       
	 ELSE
     OPEN v_result_set FOR
       SELECT TO_CHAR(CAD.CLM_RECEIVED_DATE,'DD/MM/YYYY') AS CLM_RECEIVED_DATE,
              TO_CHAR(CAD.DATE_OF_HOSPITALIZATION,'DD/MM/YYYY') AS DATE_OF_HOSPITALIZATION,
              b.BATCH_NO,
              cad.INVOICE_NUMBER,
              cad.EVENT_NO,
              CAD.TPA_ENROLLMENT_ID,
              cad.EMIRATE_ID,
              cad.MEM_NAME,
              cad.CLAIM_NUMBER,
              case when Cad.benifit_type = 'OPTS' then 'Out-Patient' 
                          when Cad.benifit_type = 'OPTC' then 'Optical'
                          when Cad.benifit_type = 'IMTI' then 'In-Patient Maternity'
                          when Cad.benifit_type = 'OMTI'  then 'Out-Patient Maternity'
                          when Cad.benifit_type = 'IPT' then 'In-Patient'
                          when Cad.benifit_type = 'DNTL' then 'Dental'
                          when Cad.benifit_type = 'HEAC' then 'Health Check-up'
                          when Cad.benifit_type = 'DAYC' then 'Daycare' end as BENIFIT_TYPE ,

              EC.DESCRIPTION AS CLM_STATUS_TYPE_ID,
              cad.REQUESTED_AMOUNT AS PAT_APPROVED_AMOUNT,
              cad.TOT_GROSS_AMOUNT,
              cad.TOT_DISCOUNT_AMOUNT,
              cad.TOT_PATIENT_SHARE_AMOUNT,
              case when (nvl(cad.ucr_flag,'N')='N' and nvl(cad.ri_copar_flag,'N')='N') then
                 case when nvl(cad.completed_yn,'N')='Y'then 
                      CASE WHEN SIGN ((cad.tot_disc_gross_amount-nvl(cad.tot_patient_share_amount,0))-nvl(cad.final_app_amount,0)) = -1 THEN 0
                      ELSE (cad.tot_disc_gross_amount-nvl(cad.tot_patient_share_amount,0))-nvl(cad.final_app_amount,0) END
                 else CASE WHEN SIGN((cad.tot_disc_gross_amount-nvl(cad.tot_patient_share_amount,0))-nvl(cad.tot_approved_amount,0)) = -1 THEN 0
                      ELSE (cad.tot_disc_gross_amount-nvl(cad.tot_patient_share_amount,0))-nvl(cad.tot_approved_amount,0) END
              end end AS DIS_ALLOWED_AMOUNT,
              cad.TOT_APPROVED_AMOUNT,
              F.CHECK_NUM AS PAYMENT_REFRENCE_NUMBER,
              TO_CHAR(f.CHECK_DATE,'DD/MM/YYYY') AS CHECK_DATE,
              Cad.CLAIM_SEQ_ID

        FROM  clm_authorization_details cad 
        join clm_batch_upload_details b on (b.clm_batch_seq_id=cad.clm_batch_seq_id and b.batch_status_type='COMP')
         --join APP.CLM_BATCH_UPLOAD_DETAILS b on (b.CLM_BATCH_SEQ_ID=cad.CLM_BATCH_SEQ_ID)
        left outer join tpa_claims_payment cp on (cad.claim_seq_id=cp.claim_seq_id)
        left outer join FIN_APP.TPA_PAYMENT_CHECKS_DETAILS n on (n.PAYMENT_SEQ_ID=CP.PAYMENT_SEQ_ID)
        left outer  join FIN_APP.tpa_claims_check f on (n.CLAIMS_CHK_SEQ_ID=f.CLAIMS_CHK_SEQ_ID)
        left outer join tpa_general_code ec on (Cad.CLM_STATUS_TYPE_ID = ec.general_type_id)
        left outer join clm_hospital_details HD on (HD.claim_seq_id=cad.claim_seq_id)
        left outer join tpa_hosp_info thi on (thi.hosp_seq_id=HD.hosp_seq_id)
       WHERE (str_tab(2) IS NULL OR THI.HOSP_SEQ_ID=str_tab(2))
         AND (str_tab(3) is null or  CAD.DATE_OF_HOSPITALIZATION >= to_date(str_tab(3),'dd/mm/yyyy') and CAD.DATE_OF_HOSPITALIZATION <= to_date(str_tab(4),'dd/mm/yyyy')+1)
         AND (str_tab(5) is null or CAD.CLM_RECEIVED_DATE >= to_date(str_tab(5),'dd/mm/yyyy') and CAD.CLM_RECEIVED_DATE <= to_date(str_tab(6),'dd/mm/yyyy')+1)
         AND (str_tab(7) IS NULL OR  CAD.MEM_NAME=str_tab(7))
         AND (str_tab(8) IS NULL OR CAD.CLM_STATUS_TYPE_ID=str_tab(8))
         AND (str_tab(9) IS NULL OR CAD.INVOICE_NUMBER=str_tab(9))
         AND (str_tab(10) IS NULL OR b.BATCH_NO=str_tab(10))
         AND (str_tab(11) IS NULL OR  CAD.TPA_ENROLLMENT_ID=str_tab(11))
         AND (str_tab(12) IS NULL OR CAD.CLAIM_NUMBER=str_tab(12))
         AND (str_tab(13) IS NULL OR  CAD.BENIFIT_TYPE=str_tab(13))
         AND (str_tab(14) IS NULL OR  CAD.EVENT_NO=str_tab(14))
         AND (str_tab(15) IS NULL OR  CAD.EMIRATE_ID=str_tab(15))
         AND (str_tab(16) IS NULL OR  F.CHECK_NUM=str_tab(16))
         AND cad.CLAIM_TYPE ='CNH'
         AND b.SOURCE_TYPE_ID in ('PLCL','PCLM','E_LM','INTL')
       order by Cad.CLAIM_SEQ_ID
           --AND CAD.SOURCE_TYPE_ID ='PLCL'
           ;
   
   END IF;
   
 END PRVDR_CLM_RPT;
--============================================================================================================================
end  claim_pkg;

/

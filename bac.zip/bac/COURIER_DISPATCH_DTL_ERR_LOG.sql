--------------------------------------------------------
--  DDL for Synonymn COURIER_DISPATCH_DTL_ERR_LOG
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."COURIER_DISPATCH_DTL_ERR_LOG" FOR "APP"."COURIER_DISPATCH_DTL_ERR_LOG";

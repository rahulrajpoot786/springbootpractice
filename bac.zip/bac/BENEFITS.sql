--------------------------------------------------------
--  DDL for Synonymn BENEFITS
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."BENEFITS" FOR "APP"."BENEFITS";

--------------------------------------------------------
--  DDL for Synonymn CITIBANK_ENR_HISTORY
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."CITIBANK_ENR_HISTORY" FOR "APP"."CITIBANK_ENR_HISTORY";

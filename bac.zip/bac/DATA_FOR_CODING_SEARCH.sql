--------------------------------------------------------
--  DDL for Synonymn DATA_FOR_CODING_SEARCH
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."DATA_FOR_CODING_SEARCH" FOR "APP"."DATA_FOR_CODING_SEARCH";

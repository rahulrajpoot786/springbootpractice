--------------------------------------------------------
--  DDL for Synonymn IDX_CITIBANK_ENR_HISTORY
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."IDX_CITIBANK_ENR_HISTORY" FOR "APP"."IDX_CITIBANK_ENR_HISTORY";

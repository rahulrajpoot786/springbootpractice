--------------------------------------------------------
--  DDL for Package Body FINGER_PRINT_PKG
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "VENUBABU"."FINGER_PRINT_PKG" 
iS
--============================================================================================
PROCEDURE SAVE_FING_PRINT(
                        V_PROVIDER_ID            IN VARCHAR2,                
                        V_USER_ID                IN VARCHAR2 ,
                        V_FNGPRINT               IN BLOB,
                        V_ROW_PROCESSED         OUT NUMBER
                                           )
AS
   
CURSOR CHECK_FIN_REG IS
        SELECT FIN_PRINT_YN
        FROM APP.TPA_LOGIN_INFO
        WHERE USER_ID=V_USER_ID;

V_FIN_REG      CHAR(1);

BEGIN
OPEN CHECK_FIN_REG;
  FETCH CHECK_FIN_REG INTO V_FIN_REG;
    CLOSE CHECK_FIN_REG;

 IF NVL(V_FIN_REG,'N')= 'Y' THEN
  Raise_application_error(-20226,'User already registerd for finger print');
 END IF; 

 IF V_FIN_REG ='N' THEN
   IF V_FNGPRINT IS NOT NULL AND V_USER_ID IS NOT NULL THEN
       UPDATE APP.TPA_LOGIN_INFO LI
            SET    LI.FINGER_PRINT= V_FNGPRINT,
                   LI.FIN_PRINT_YN='Y'
            WHERE  LI.USER_ID=V_USER_ID;
   END IF;

END IF;


     V_ROW_PROCESSED:=SQL%ROWCOUNT;
     COMMIT;

END SAVE_FING_PRINT;
--==============================================================================================
PROCEDURE SELECT_FINGER_PRINT ( V_PROVIDE_ID   IN VARCHAR2,
                                RESULT_SET     OUT SYS_REFCURSOR                
                               )
AS

BEGIN

IF V_PROVIDE_ID IS NOT NULL THEN

OPEN RESULT_SET FOR
'SELECT L.CONTACT_SEQ_ID as SEQ_ID,L.FINGER_PRINT as FINGER_PRINT FROM 
TPA_LOGIN_INFO L JOIN 
TPA_USER_CONTACTS C ON (L.CONTACT_SEQ_ID=C.CONTACT_SEQ_ID) JOIN 
TPA_HOSP_INFO H ON (C.HOSP_SEQ_ID=H.HOSP_SEQ_ID)
WHERE C.USER_GENERAL_TYPE_ID=''HOS'' AND H.EMPANEL_NUMBER='''||V_PROVIDE_ID||'''';
ELSE

Raise_application_error (-20227,'Please enter the provider id');    

END IF;

END;
--=======================================================================================================
PROCEDURE GET_CREDENTIALS ( V_CONTACT_ID   IN VARCHAR2,
                             RESULT_SET     OUT SYS_REFCURSOR                
                           )
AS

BEGIN

IF V_CONTACT_ID IS NOT NULL THEN

OPEN RESULT_SET FOR
'SELECT L.USER_ID as USER_ID,TTK_UTIL_PKG.FN_DECRYPT(L.PASSWORD) as PASS_WORD FROM 
TPA_LOGIN_INFO L  
WHERE L.CONTACT_SEQ_ID='''||V_CONTACT_ID||'''';   
END IF;

END GET_CREDENTIALS;
--========================================
PROCEDURE SAVE_MEM_FING_PRINT(          
                              V_MEMBER_ID              IN VARCHAR2 ,
                              V_FNGPRINT               IN BLOB,
                              V_ROW_PROCESSED         OUT NUMBER
                                           )
AS
  
CURSOR CHECK_FIN_REG IS
        SELECT COUNT(1)
        FROM tpa_enr_policy_member m
        WHERE m.member_seq_id = (select max(member_seq_id)
                                       from tpa_enr_policy_member
                                       where tpa_enrollment_id=trim(V_MEMBER_ID));
                                       
 CURSOR CHECK_MEM_SEQ_ID IS
        select max(member_seq_id)
               from tpa_enr_policy_member
            where tpa_enrollment_id=trim(V_MEMBER_ID);

V_FIN_REG           VARCHAR2(5);
V_MEM_SEQ_ID_RE      VARCHAR2(50);
BEGIN

OPEN CHECK_FIN_REG;
  FETCH CHECK_FIN_REG INTO V_FIN_REG;
    CLOSE CHECK_FIN_REG;
   
  OPEN CHECK_MEM_SEQ_ID;
  FETCH CHECK_MEM_SEQ_ID INTO V_MEM_SEQ_ID_RE;
    CLOSE CHECK_MEM_SEQ_ID; 
    

  IF V_FIN_REG =1 THEN
       UPDATE APP.TPA_ENR_POLICY_MEMBER M
            SET    M.MEM_FIN_PRINT= V_FNGPRINT,
                   M.FIN_PRINT ='Y'
            WHERE  M.MEMBER_SEQ_ID = V_MEM_SEQ_ID_RE;
  ELSE
  RAISE_APPLICATION_ERROR (-20426,'Member is invalid');
   END IF;

     V_ROW_PROCESSED:=SQL%ROWCOUNT;
     COMMIT;

END SAVE_MEM_FING_PRINT;
--========================================
PROCEDURE SELECT_MEM_FIN_PRINT (V_MEMBER_ID IN TPA_ENR_POLICY_MEMBER.tpa_enrollment_id%type,
                                 RESULT_SET OUT   SYS_REFCURSOR)
as
CURSOR CHECK_FIN_PRINT IS
select  COUNT(1)
FROM TPA_ENR_POLICY_MEMBER M
WHERE  m.member_seq_id = (select max(member_seq_id)
                                       from tpa_enr_policy_member
                                       where tpa_enrollment_id=V_MEMBER_ID) AND MEM_FIN_PRINT IS NOT NULL;

CURSOR CHECK_MEMBER IS
select  COUNT(1)
FROM TPA_ENR_POLICY_MEMBER M
WHERE M.TPA_ENROLLMENT_ID= V_MEMBER_ID /*AND M.STATUS_GENERAL_TYPE_ID='POA'*/;

CURSOR CHECK_MEM_SEQ_ID IS
 select max(member_seq_id)
        from tpa_enr_policy_member
        where tpa_enrollment_id=V_MEMBER_ID;

V_COUNT                 NUMBER;
V_VALID                 NUMBER;
V_MEM_SEQ_ID_RE      VARCHAR2(50);
BEGIN
OPEN CHECK_FIN_PRINT;
 FETCH CHECK_FIN_PRINT INTO V_COUNT;
   CLOSE CHECK_FIN_PRINT;
   
   OPEN CHECK_MEMBER;
     FETCH CHECK_MEMBER INTO V_VALID;
      CLOSE CHECK_MEMBER;
      
    OPEN CHECK_MEM_SEQ_ID;
     FETCH CHECK_MEM_SEQ_ID INTO V_MEM_SEQ_ID_RE;
      CLOSE CHECK_MEM_SEQ_ID;
	  
	  IF V_VALID=0 THEN
	  RAISE_APPLICATION_ERROR(-20920 ,'Enrollement Id is In_Valid Or Memebr is Cancelled');
	  END IF;
  
	 IF V_COUNT=1 THEN 
	   OPEN RESULT_SET FOR 
	   'SELECT MEM_FIN_PRINT
			  FROM TPA_ENR_POLICY_MEMBER
			  WHERE member_seq_id='''||V_MEM_SEQ_ID_RE||'''';
	 ELSE
	 RAISE_APPLICATION_ERROR(-20921,'Please Register finger print');      
	 END IF;
 END SELECT_MEM_FIN_PRINT;

END FINGER_PRINT_PKG;

/

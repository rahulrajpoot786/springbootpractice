--------------------------------------------------------
--  DDL for Synonymn DISCOUNT_TEMP
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."DISCOUNT_TEMP" FOR "APP"."DISCOUNT_TEMP";

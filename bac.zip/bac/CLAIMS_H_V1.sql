--------------------------------------------------------
--  DDL for Synonymn CLAIMS_H_V1
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."CLAIMS_H_V1" FOR "TTKEXT"."CLAIMS_H_V1";

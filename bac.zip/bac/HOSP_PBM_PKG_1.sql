--------------------------------------------------------
--  DDL for Package HOSP_PBM_PKG
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "VENUBABU"."HOSP_PBM_PKG" 

IS

v_prod_policy_rule_seq_id   tpa_ins_prod_policy_rules.prod_policy_rule_seq_id%type;

--=======================================================================================================                               
PROCEDURE select_pbm_drug_list (
    v_search_flag              IN VARCHAR2,--CODE,DESC,
    v_search_data              IN OUT VARCHAR2,
    v_sort_var                 IN OUT VARCHAR2 ,
    v_sort_order               IN OUT VARCHAR2,
    v_start_num                IN OUT NUMBER  ,
    v_end_num                  IN OUT NUMBER  ,
    v_hosp_date                IN VARCHAR2 ,
    v_result_set               OUT SYS_REFCURSOR
  );
---=================================================================================================
PROCEDURE select_pbm_icd_list (
    v_search_flag              IN VARCHAR2,--CODE,DESC
    v_search_data             IN OUT VARCHAR2, 
    v_sort_var                 IN OUT VARCHAR2 ,
    v_sort_order               IN OUT VARCHAR2,
    v_start_num                IN OUT NUMBER  ,
    v_end_num                  IN OUT NUMBER  ,
    v_result_set               OUT SYS_REFCURSOR
  );
---=====================================================================================
PROCEDURE select_pbm_clin_list (
    v_search_mode              IN OUT  VARCHAR2,--ID ,NAME
    v_search_data              IN  OUT VARCHAR2,
    v_sort_var                 IN OUT VARCHAR2 ,
    v_sort_order               IN OUT VARCHAR2,
    v_start_num                IN OUT NUMBER  ,
    v_end_num                  IN OUT NUMBER  ,
    v_result_set               OUT SYS_REFCURSOR
  );
---====================================rules===============================================

PROCEDURE check_mdcl_necessity_rules_1(v_seq_id                       IN pat_activity_details.pat_auth_seq_id%TYPE,
                                     v_mode                         IN VARCHAR2,
                                     v_added_by                     IN NUMBER);
  
----===============================================================================
PROCEDURE check_therapeutic_rule_2(v_seq_id   IN pat_authorization_details.pat_auth_seq_id%TYPE,
                                 v_mode     IN VARCHAR2,
                                 v_added_by IN NUMBER);
--===================================================================================
PROCEDURE check_ci_icd_ddc_rules_3(v_seq_id                       IN pat_activity_details.pat_auth_seq_id%TYPE,
                             v_mode                         IN VARCHAR2,
                             v_added_by                     IN NUMBER);         
--===================================================================================
PROCEDURE check_ci_ddc_ddc_rules_3(v_seq_id                       IN pat_activity_details.pat_auth_seq_id%TYPE,
                             v_mode                         IN VARCHAR2,
                             v_added_by                     IN NUMBER);  
---=========================================================================================
PROCEDURE check_ci_ddc_ddc_generic(v_seq_id                       IN pat_activity_details.pat_auth_seq_id%TYPE,
                                   v_mode                         IN VARCHAR2,
                                   v_added_by                     IN NUMBER);                                                      
---------------------------------------------------------------------------------------------------------------------------------
PROCEDURE check_age_band_rule_4(v_seq_id                       IN pat_activity_details.pat_auth_seq_id%TYPE,
                              v_mode                         IN VARCHAR2,
                              v_added_by                     IN NUMBER);     
---==========================================================================================
PROCEDURE check_gender_rule_5(v_seq_id   IN pat_authorization_details.pat_auth_seq_id%TYPE,
                            v_mode     IN VARCHAR2,
                            v_added_by IN NUMBER);                                                                  
--=================================================================================
PROCEDURE priliminary_check_rule_6(v_seq_id   IN pat_authorization_details.pat_auth_seq_id%TYPE,
                         v_mode     IN VARCHAR2,
                         v_added_by IN NUMBER);

--=======================================================================================
PROCEDURE check_refill_to_soon_7(v_seq_id            IN pat_authorization_details.pat_auth_seq_id%TYPE,
                               v_mode              IN VARCHAR2,
                               v_member_seq_id     IN number,
                               v_added_by          IN NUMBER );
---==================================================================================      
PROCEDURE check_mat_icd_ddc_rule_8(v_seq_id   IN pat_authorization_details.pat_auth_seq_id%TYPE,
                                   v_mode     IN VARCHAR2,
                                   v_added_by IN NUMBER) ;

-------========================rules=================================================
---=====================================================================================
PROCEDURE save_pbm_pat (v_pat_auth_seq_id            in out pat_authorization_details.pat_auth_seq_id%type,
                           v_hospitalization_date       in varchar2,--pat_authorization_details.hospitalization_date%type,
                           v_tpa_enrollment_id          in pat_authorization_details.tpa_enrollment_id%type,
                           v_quatar_id                  in varchar2,
                           v_pre_auth_number            in out pat_authorization_details.pre_auth_number%type,
                           v_hosp_seq_id                in pat_authorization_details.hosp_seq_id%type,
                           v_clinician_id               in pat_authorization_details.clinician_id%type,
                           v_clinician_name             In pat_non_network_details.clinician_name%type,
                           v_event_no                   in pat_authorization_details.event_no%type,
                           v_added_by                   in number
                           ) ;
--======================================================================================
PROCEDURE save_diagnosys_details(
  v_diag_seq_id       IN OUT diagnosys_details.diag_seq_id%type,
  v_pat_auth_seq_id   IN diagnosys_details.pat_auth_seq_id%type,
  v_icd_code_seq_id   IN diagnosys_details.icd_code_seq_id%type,
  v_diagnosys_code    IN diagnosys_details.diagnosys_code%type,
  v_added_by          IN diagnosys_details.added_by%type 
  );
---=================================================================================
PROCEDURE save_activity_details(
    v_activity_dtl_seq_id     IN OUT pat_activity_details.activity_dtl_seq_id%TYPE,
    v_pat_auth_seq_id         IN  pat_activity_details.pat_auth_seq_id%TYPE,
    v_activity_seq_id         IN  tpa_pharmacy_master_details.act_mas_dtl_seq_id%TYPE,
    v_unit_type               IN  pat_activity_details.unit_type%TYPE,
    v_quantity                IN  pat_activity_details.quantity%TYPE,
    v_duration_days           IN  pat_activity_details.posology_duration%TYPE,
    v_allow_yn                IN  pat_activity_details.allow_yn%TYPE:='Y',
    v_added_by                IN  pat_activity_details.added_by%TYPE,
    v_approve_yn              IN  pat_activity_details.approve_yn%TYPE:='Y'
    );

-------=========================================================================
PROCEDURE select_pat_auth_details (
    v_pat_auth_seq_id                           IN  pat_authorization_details.pat_auth_seq_id%type,
    v_auth_result_set                           OUT SYS_REFCURSOR ,
    v_diag_result_set                           OUT SYS_REFCURSOR ,
    v_activity_result_set                       OUT SYS_REFCURSOR );
--========================================================================================
PROCEDURE delete_diagnosys_details(v_seq_id             IN pat_authorization_details.pat_auth_seq_id%TYPE,
                                   v_diag_seq_id        IN diagnosys_details.diag_seq_id%type,
                                   v_rows_processed     OUT NUMBER);
---=======================================================================================
PROCEDURE delete_activity_details(v_seq_id                       IN pat_authorization_details.pat_auth_seq_id%TYPE,
                                  v_activity_dtl_seq_id          IN pat_activity_details.activity_dtl_seq_id%type,
                                  v_rows_processed               OUT NUMBER) ;
------=====================================================================================
PROCEDURE calculate_authorization(v_pat_auth_seq_id            IN  pat_authorization_details.pat_auth_seq_id%type,
                                  v_hosp_seq_id                IN  pat_authorization_details.hosp_seq_id%TYPE,
                                  v_allowed_amount             OUT  pat_authorization_details.Tot_Allowed_Amount%TYPE,
                                  v_added_by                   IN  NUMBER
                                  );
--=========================================================================================
PROCEDURE save_authorization(v_pat_auth_seq_id                 IN pat_authorization_details.Pat_Auth_Seq_Id%TYPE,
                             v_member_seq_id                   IN pat_authorization_details.member_seq_id%TYPE,
                             v_auth_number                     IN OUT pat_authorization_details.Auth_Number%TYPE,
                             v_admission_date                  IN pat_authorization_details.hospitalization_date%type,
                             v_allowed_amount                  IN pat_authorization_details.Tot_Allowed_Amount%TYPE,
                             v_pat_status_type_id              IN OUT pat_authorization_details.Pat_Status_Type_Id%TYPE,
                             v_added_by                        IN  NUMBER,
                             v_rows_processed                  OUT NUMBER);
--=========================================================================================
PROCEDURE generate_authorization(v_pat_auth_seq_id                 IN pat_authorization_details.Pat_Auth_Seq_Id%TYPE,
                                 v_added_by                        IN  NUMBER);
--==============================================================================
PROCEDURE comp_preauth (v_pat_auth_seq_id                 IN pat_authorization_details.Pat_Auth_Seq_Id%TYPE,
                        v_added_by                        IN  NUMBER);
--==========================================================================================
FUNCTION get_prod_pol_seq_id(v_seq_id IN pat_general_details.pat_gen_detail_seq_id%type,
                             v_flag in varchar2 
                             ) RETURN NUMBER ;
--=======================================================================================
----------PBM FIXES-----------
--=========================================================================================
  PROCEDURE select_preauth_list (
  v_authorizationId                     IN  pat_authorization_details.auth_number%type ,
  v_fromdate							              IN   VARCHAR2 ,
  v_toDate							                IN	 VARCHAR2 ,
	v_patientName						              IN  pat_authorization_details.mem_name%type,
	v_clinicianName						            IN	pat_non_network_details.clinician_name%type,
	v_memberId							              IN	pat_authorization_details.tpa_enrollment_id%type,
	v_qutar_id                            IN  tpa_enr_policy_member.emirate_id%TYPE,
	v_status							                IN	tpa_general_code.description%type,
  v_pre_auth_number                     IN  pat_authorization_details.pre_auth_number%type ,
	v_ref_no							                IN  pat_authorization_details.EVENT_NO%type,
  v_sort_var                            IN  VARCHAR2,
  v_sort_order                          IN  VARCHAR2 ,
  v_start_num                           IN  NUMBER ,
  v_end_num                             IN  NUMBER ,
  v_added_by                            IN  NUMBER,
  V_HOSP_SEQ_ID                         IN  pat_authorization_details.hosp_seq_id%type,
  v_inp_status                          IN  VARCHAR2,
  result_set                            OUT SYS_REFCURSOR
  );
--=========================================================================================
----------PBM FIXES-----------
--=========================================================================================
PROCEDURE validate_enrollment_id (
      v_tpa_enrollment_id                  IN  OUT  pat_enroll_details.tpa_enrollment_id%TYPE,
      v_date_of_hosp                       IN  varchar2,
      v_event_no                           IN VARCHAR2,
      v_hosp_seq_id                        IN  tpa_hosp_info.hosp_seq_id%TYPE,
      v_member_details                      OUT SYS_REFCURSOR);

--=========================================================================================
PROCEDURE select_activity_code(v_hosp_seq_id               IN tpa_hosp_info.hosp_seq_id%TYPE,
                               v_tpa_enrollment_id         IN tpa_enr_policy_member.tpa_enrollment_id%type,
                               v_activity_code             IN tpa_pharmacy_master_details.activity_code%type,
                               v_activity_datee             IN  varchar2,
                               v_unit_type                  IN PAT_ACTIVITY_DETAILS.unit_type%type, 
                               v_tariff_result             OUT SYS_REFCURSOR);
--==============================================================================
PROCEDURE pmb_websrvc_proc     (wb_ip_xml        IN XMLTYPE,
                                wb_resp_xml      IN XMLTYPE,
                                v_process_type   IN VARCHAR2,
                                v_seq_id         IN NUMBER, -- preauth or claim seq id based on flag
                                v_added_by       IN NUMBER
                                );                               
--=========================================================================================
procedure save_pbm_clm(v_pat_auth_seq_id            IN  pat_authorization_details.pat_auth_seq_id%type,
                        v_res                       in varchar2,
                        v_invoice_number             IN  clm_authorization_details.INVOICE_NUMBER%TYPE,
                         v_result_set               OUT SYS_REFCURSOR
						 );
--=========================================================================================
PROCEDURE save_clm_diagnosys_details(
  --v_diag_seq_id       IN OUT diagnosys_details.diag_seq_id%type,
  v_pat_auth_seq_id   IN diagnosys_details.pat_auth_seq_id%type,
   v_claim_seq_id     IN diagnosys_details.CLAIM_SEQ_ID%type
  );
--====================================================================================
PROCEDURE save_clm_activity_details(
    v_res     IN varchar2,
    v_pat_auth_seq_id         IN  pat_activity_details.pat_auth_seq_id%TYPE,
	v_claim_seq_id			  IN  pat_activity_details.claim_seq_id%TYPE
   
   );
--============================================================================================

PROCEDURE calculate_clm_authorization(v_claim_seq_id               IN  clm_authorization_details.claim_seq_id%type,
                                  v_hosp_seq_id                IN  clm_hospital_details.hosp_seq_id%TYPE,
                                  v_allowed_amount             OUT clm_authorization_details.tot_allowed_amount%type,
                                 -- v_result_set                 OUT SYS_REFCURSOR,
                                  v_added_by                   IN  NUMBER
                                  );
--==========================================================================================================
PROCEDURE PBM_CLM_DRUG_RPT (
    v_input_list IN  VARCHAR2,
    v_result_set  OUT SYS_REFCURSOR
  );
--==========================================================================================================
procedure pbm_clm_status(v_pat_auth_seq_id            IN  pat_authorization_details.pat_auth_seq_id%type,
                         v_num                       out  varchar2);
--======================================================================================================
PROCEDURE select_claim_rpt_list(
  --V_HOSP_SEQ_ID                         IN  pat_authorization_details.hosp_seq_id%type,
  v_fromdate							              IN   VARCHAR2 ,
  v_toDate							                IN	 VARCHAR2 ,
  v_fromdate1							              IN   VARCHAR2 ,
  v_toDate1							                IN	 VARCHAR2 ,
	v_patientName						              IN  clm_authorization_details.mem_name%type,
	v_status							                IN	tpa_general_code.description%type,
	v_invoice_number									    IN  clm_authorization_details.invoice_number%type,
	v_claim_number										    IN  clm_authorization_details.claim_number%type,
	v_memberId											      IN  clm_authorization_details.tpa_enrollment_id%type,
	v_ref_no											        IN  clm_authorization_details.EVENT_NO%type,
	v_auth_number                         IN  clm_authorization_details.auth_number%type,
	v_clm_pay_status									    IN VARCHAR2,
	v_pre_auth_number                     IN  pat_authorization_details.pre_auth_number%type ,
  ----------
 v_batch_no                            IN  clm_batch_upload_details.batch_no%type default null,
  v_clm_payment_status                  IN  TPA_CLAIMS_PAYMENT.CLAIM_PAYMENT_STATUS%type default null,
  v_pay_ref_num                         IN  FIN_APP.tpa_claims_check.CHECK_NUM%type default null,
  ---------  
	v_sort_var                            IN  VARCHAR2,
  v_sort_order                          IN  VARCHAR2 ,
  v_start_num                           IN  NUMBER ,
  v_end_num                             IN  NUMBER ,
  V_HOSP_SEQ_ID                         IN  pat_authorization_details.hosp_seq_id%type,
  v_rpt_id                              IN  VARCHAR2,
  --v_added_by                            IN  NUMBER,
  result_set                            OUT SYS_REFCURSOR
  );
  --==================================================================================
  procedure save_pbm_clm_file(v_pat_auth_seq_id            IN  pat_authorization_details.pat_auth_seq_id%type,
                       v_file_name               in varchar2,
                        v_gentype_id              in MOU_DOCS_INFO1.FILE_NAME%TYPE,
                        v_image_data              in MOU_DOCS_INFO1.IMAGE_FILE%TYPE,
                        v_rows_processed OUT NUMBER);
--====================================================================================
PROCEDURE select_claim_list(
  v_fromdate							              IN   VARCHAR2 ,
  v_toDate							                IN	 VARCHAR2 ,
  v_fromdate1							              IN   VARCHAR2 ,
  v_toDate1							                IN	 VARCHAR2 ,
	v_patientName						              IN  clm_authorization_details.mem_name%type,
  v_auth_number                         IN  clm_authorization_details.auth_number%type,
  v_invoice_number									    IN  clm_authorization_details.invoice_number%type,
  v_memberId											      IN  clm_authorization_details.tpa_enrollment_id%type,
  v_claim_number										    IN  clm_authorization_details.claim_number%type,
  v_clm_pay_status									    IN VARCHAR2,
	v_status							                IN	tpa_general_code.description%type,
	v_ref_no											        IN  clm_authorization_details.EVENT_NO%type,
  v_batch_number                        IN  clm_batch_upload_details.batch_no%type,
	v_sort_var                            IN  VARCHAR2,
  v_sort_order                          IN  VARCHAR2 ,
  v_start_num                           IN  NUMBER ,
  v_end_num                             IN  NUMBER ,
  V_HOSP_SEQ_ID                         IN  pat_authorization_details.hosp_seq_id%type,
  v_qatar_id                            IN  clm_authorization_details.emirate_id%type,
  v_inp_status                          IN  VARCHAR2,
  result_set                            OUT SYS_REFCURSOR
  );
  --============================================================================
PROCEDURE SELECT_CLAIM_DETAILS(
                                V_CLAIM_SEQ_ID  IN  clm_authorization_details.CLAIM_SEQ_ID%type,
                                v_pre_auth_seq_id IN pat_authorization_details.pat_auth_seq_id%type,
                                V_RESULT        OUT SYS_REFCURSOR,
                                v_diag_result_set  OUT SYS_REFCURSOR ,
                                v_activity_result_set  OUT SYS_REFCURSOR,
                                v_pre_auth_result_set  OUT SYS_REFCURSOR
                                );
 --=====================================================================
 PROCEDURE get_mem_benifit_details(v_tpa_enrollment_id                  IN  PAT_ENROLL_DETAILS.tpa_enrollment_id%TYPE,
                                  v_benefit_type                       IN  PAT_AUTHORIZATION_DETAILS.Benifit_Type%TYPE,                                     
                                  v_hosp_seq_id                        IN  TPA_HOSP_INFO.HOSP_SEQ_ID%TYPE,
                                  v_result_set                         OUT SYS_REFCURSOR,
                                  v_warning                            OUT VARCHAR2/*,
                                  v_network_check                      OUT SYS_REFCURSOR*/);
--==================================================================================
PROCEDURE check_mat_fda_risk_rule(v_seq_id   IN pat_authorization_details.pat_auth_seq_id%TYPE,
                                  v_mode     IN VARCHAR2,
                                  v_added_by IN NUMBER) ;

--==================================================================================



END hosp_pbm_pkg;

/

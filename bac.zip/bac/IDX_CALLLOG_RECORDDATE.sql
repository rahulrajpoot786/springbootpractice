--------------------------------------------------------
--  DDL for Synonymn IDX_CALLLOG_RECORDDATE
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."IDX_CALLLOG_RECORDDATE" FOR "APP"."IDX_CALLLOG_RECORDDATE";

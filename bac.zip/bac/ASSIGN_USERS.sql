--------------------------------------------------------
--  DDL for Synonymn ASSIGN_USERS
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."ASSIGN_USERS" FOR "APP"."ASSIGN_USERS";

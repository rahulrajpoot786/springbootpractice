--------------------------------------------------------
--  DDL for Synonymn AUDIT_XML_TAB
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."AUDIT_XML_TAB" FOR "APP"."AUDIT_XML_TAB";

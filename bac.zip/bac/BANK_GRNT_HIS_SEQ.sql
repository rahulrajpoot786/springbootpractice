--------------------------------------------------------
--  DDL for Synonymn BANK_GRNT_HIS_SEQ
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."BANK_GRNT_HIS_SEQ" FOR "APP"."BANK_GRNT_HIS_SEQ";

--------------------------------------------------------
--  DDL for Synonymn CLM_HOSPITAL_ASSOCIATION
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."CLM_HOSPITAL_ASSOCIATION" FOR "APP"."CLM_HOSPITAL_ASSOCIATION";

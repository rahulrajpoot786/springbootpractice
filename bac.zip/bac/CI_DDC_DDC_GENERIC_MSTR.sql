--------------------------------------------------------
--  DDL for Synonymn CI_DDC_DDC_GENERIC_MSTR
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."CI_DDC_DDC_GENERIC_MSTR" FOR "APP"."CI_DDC_DDC_GENERIC_MSTR";

--------------------------------------------------------
--  DDL for Synonymn CLM_ENROLL_DETAIL_SEQ
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."CLM_ENROLL_DETAIL_SEQ" FOR "APP"."CLM_ENROLL_DETAIL_SEQ";

--------------------------------------------------------
--  DDL for Synonymn IDX_INSASSOFFPROD_INPRENRTY
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."IDX_INSASSOFFPROD_INPRENRTY" FOR "APP"."IDX_INSASSOFFPROD_INPRENRTY";

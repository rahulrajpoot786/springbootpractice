--------------------------------------------------------
--  DDL for Synonymn GN_PAT_MAIN_TRANS_DOWNLOAD_SEQ
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."GN_PAT_MAIN_TRANS_DOWNLOAD_SEQ" FOR "APP"."GN_PAT_MAIN_TRANS_DOWNLOAD_SEQ";

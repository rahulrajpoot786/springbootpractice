--------------------------------------------------------
--  DDL for Synonymn EXTERNAL_LOGIN_LOGS_SEQ
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."EXTERNAL_LOGIN_LOGS_SEQ" FOR "INTX"."EXTERNAL_LOGIN_LOGS_SEQ";

--------------------------------------------------------
--  DDL for Package ADMINISTRATION_PKG
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "VENUBABU"."ADMINISTRATION_PKG" is


  -- Author  : SREERAJ_SV
  -- Created : 3/19/2006 11:22:57 AM
  -- Purpose : Administration Module
-------------------------------
  CURSOR user_cur(v_contact_seq_id TPA_USER_CONTACTS.contact_seq_id%TYPE) IS
    SELECT A.contact_seq_id, A.user_general_type_id, COALESCE(a.tpa_office_seq_id ,a.ins_seq_id , a.hosp_seq_id , a.group_reg_seq_id ) seq_id,
      b.role_seq_id,c.privilege
      FROM tpa_user_contacts A JOIN tpa_user_roles B ON (A.contact_seq_id = B.contact_seq_id)
      JOIN tpa_roles_code C ON (B.role_seq_id = C.role_seq_id)
      WHERE A.contact_seq_id = v_contact_seq_id;
-------------------------------
  TYPE user_cur_type IS TABLE OF  user_cur%ROWTYPE INDEX BY BINARY_INTEGER;



 --==============================================================================================
  PROCEDURE save_tpa_office(
    v_tpa_office_seq_id                  IN  OUT TPA_OFFICE_INFO.tpa_office_seq_id%TYPE,
    v_tpa_office_general_type_id         IN  TPA_OFFICE_INFO.tpa_office_general_type_id%TYPE,
    v_office_code                        IN  TPA_OFFICE_INFO.office_code%TYPE,
    v_office_name                        IN  TPA_OFFICE_INFO.office_name%TYPE,
    v_std_code                           IN  TPA_OFFICE_INFO.std_code%TYPE,
    v_tpa_parent_seq_id                  IN  TPA_OFFICE_INFO.tpa_parent_seq_id%TYPE,
    v_email_id                           IN  TPA_OFFICE_INFO.email_id%TYPE,
    v_alt_email_id                       IN  TPA_OFFICE_INFO.alt_email_id%TYPE,
    v_off_phone_no_1                     IN  TPA_OFFICE_INFO.off_phone_no_1%TYPE,
    v_off_phone_no_2                     IN  TPA_OFFICE_INFO.off_phone_no_2%TYPE,
    v_office_fax_no_1                    IN  TPA_OFFICE_INFO.office_fax_no_1%TYPE,
    v_office_fax_no_2                    IN  TPA_OFFICE_INFO.office_fax_no_2%TYPE,
    v_toll_free_no                       IN  TPA_OFFICE_INFO.toll_free_no%TYPE,
    v_active_yn                          IN  TPA_OFFICE_INFO.active_yn%TYPE,
    -----------------------
    v_addr_seq_id                        IN  OUT TPA_ADDRESS.addr_seq_id%TYPE,
    v_address_1                          IN  TPA_ADDRESS.address_1%TYPE,
    v_address_2                          IN  TPA_ADDRESS.address_2%TYPE,
    v_address_3                          IN  TPA_ADDRESS.address_3%TYPE,
    v_state_type_id                      IN  TPA_ADDRESS.state_type_id%TYPE,
    v_city_type_id                       IN  TPA_ADDRESS.city_type_id%TYPE,
    v_pin_code                           IN  TPA_ADDRESS.pin_code%TYPE,
    v_country_id                         IN  TPA_ADDRESS.country_id%TYPE,
    -----------------------
    v_pan_number                         IN  TPA_OFFICE_INFO.pan_number%TYPE,
    v_tax_deduction_acct_no              IN  TPA_OFFICE_INFO.tax_deduction_acct_no%TYPE,
    v_added_by                           IN  TPA_OFFICE_INFO.added_by%TYPE,
    v_rows_processed                     IN  OUT NUMBER
  );
 --==============================================================================================
  PROCEDURE select_tpa_office_list (
    v_tpa_parent_seq_id            IN TPA_OFFICE_INFO.tpa_parent_seq_id%TYPE,
    v_start_num                    IN NUMBER,
    v_end_num                      IN NUMBER,
    v_level                        IN NUMBER,  -- 1 - for Head Office,  2 - for Second Level Nodes, 3 -  for Leaf Nodes
    result_set                     OUT SYS_REFCURSOR
  );
 --==============================================================================================
   PROCEDURE select_tpa_office (
    v_tpa_office_seq_id            IN TPA_OFFICE_INFO.tpa_parent_seq_id%TYPE,
    result_set                     OUT SYS_REFCURSOR
  );
 --==============================================================================================
  PROCEDURE delete_office(
    v_tpa_office_seq_id           IN tpa_office_info.tpa_office_seq_id%TYPE,
    v_added_by                    IN NUMBER,
    v_rows_processed              OUT NUMBER
  );
 --==============================================================================================
  PROCEDURE save_office_properties (
    v_tpa_office_seq_id                  IN  TPA_OFFICE_INFO.tpa_office_seq_id%TYPE,
    v_pa_limit                           IN  TPA_OFFICE_INFO.pa_limit%TYPE,
    v_claim_limit                        IN  TPA_OFFICE_INFO.claim_limit%TYPE,
    v_pa_allowed_yn                      IN  TPA_OFFICE_INFO.pa_allowed_yn%TYPE,
    v_claim_allowed_yn                   IN  TPA_OFFICE_INFO.claim_allowed_yn%TYPE,
    v_card_print_yn                      IN  TPA_OFFICE_INFO.card_print_yn%TYPE,
    v_enroll_process_yn                  IN  TPA_OFFICE_INFO.enroll_process_yn%TYPE,
    v_added_by                           IN  NUMBER,
    v_rows_processed                     IN  OUT NUMBER
  );
 --==============================================================================================
  PROCEDURE select_office_properties(
    v_tpa_office_seq_id            IN TPA_OFFICE_INFO.tpa_parent_seq_id%TYPE,
    result_set                     OUT SYS_REFCURSOR
  );
 --==============================================================================================
   ----------------------------------------------------------------------------------------------------------------------------
  -- Screen  -  Administration -> Policies -> General
  ----------------------------------------------------------------------------------------------------------------------------
  PROCEDURE select_admin_policy(
    v_prod_policy_seq_id          IN tpa_ins_prod_policy.prod_policy_seq_id%TYPE,
    v_added_by                    IN NUMBER,
    result_set                    OUT SYS_REFCURSOR
  );
  ----------------------------------------------------------------------------------------------------------------------------
  -- Screen  - Administration -> Policies
  ----------------------------------------------------------------------------------------------------------------------------
  PROCEDURE select_admin_policy_list(
    search_tab      IN policy_enrollment_pkg.filter_tab_type,
    v_sort_var      IN VARCHAR2 ,
    v_sort_order    IN VARCHAR2,
    v_start_num     IN NUMBER,
    v_end_num       IN NUMBER,
    v_added_by      IN NUMBER,
    result_set      OUT SYS_REFCURSOR
  );
  ----------------------------------------------------------------------------------------------------------------------------
  -- Screen  - Administration -> Policies -> General (List of Policies) -> Save
  ----------------------------------------------------------------------------------------------------------------------------
   PROCEDURE save_admin_policy (
    v_policy_seq_id                      IN  TPA_ENR_POLICY.policy_seq_id%TYPE,
    v_group_branch_seq_id                IN  TPA_ENR_POLICY.group_branch_seq_id%TYPE,
    v_gen_enrid_general_type_id          IN  TPA_ENR_POLICY.gen_enrid_general_type_id%TYPE,
    v_cheque_issued_general_type         IN  TPA_ENR_POLICY.tpa_cheque_issued_general_type%TYPE,
    v_card_clearance_days                IN  TPA_ENR_POLICY.card_clearance_days%TYPE,
    v_claim_clearance_days               IN  TPA_ENR_POLICY.claim_clearance_days%TYPE,
    v_pa_clearance_hours                 IN  TPA_ENR_POLICY.pa_clearance_hours%TYPE,
    v_admin_status_general_type_id       IN  TPA_ENR_POLICY.admin_status_general_type_id%TYPE,
    v_buffer_allowed_yn                  IN  TPA_ENR_POLICY.buffer_allowed_yn%TYPE,
    v_admin_auth_general_type_id         IN  TPA_ENR_POLICY.admin_auth_general_type_id%TYPE,
    v_buffer_alloc_general_type_id       IN  TPA_ENR_POLICY.buffer_alloc_general_type_id%TYPE,
    v_template_id                        IN  NUMBER ,
    v_dv_reqd_general_type_id            IN  TPA_INS_PROD_POLICY.dv_reqd_general_type_id%TYPE,
    v_tenure                             IN  TPA_INS_PROD_POLICY.Tenure%TYPE,
    v_stop_preauth_yn                    IN  TPA_INS_PROD_POLICY.stop_preauth_yn%TYPE,
    v_stop_claim_yn                      IN  TPA_INS_PROD_POLICY.stop_claim_yn%TYPE,
    v_added_by                           IN  NUMBER,
    v_mem_buffer_yn                      IN  TPA_ENR_POLICY.Member_Buffer_Yn%TYPE:='N', --KOCIBM
    v_OPD_BENEFITS_YN                    IN  TPA_INS_PROD_POLICY.OPD_BENEFITS_YN%TYPE,--KOC1286
    V_CBH_SUMINS_YN                      IN tpa_enr_policy.cbh_sumins_yn%type,    --KOC1270
    V_CONV_SUMINS_YN                     IN tpa_enr_policy.cbh_sumins_yn%type,   --KOC1270
    V_CTL_SUMINS_YN                      IN tpa_enr_policy.Critical_Sumins_Yn%type,    --koc1273
    V_SURVIVAL_PRD                       IN tpa_enr_policy.survival_prd%type,          --koc1273
 --KOC1274A
    v_pat_allowed_yn                     in tpa_ins_prod_policy.pat_allowed_yn%type,
    v_clm_allowed_yn                     in tpa_ins_prod_policy.clm_allowed_yn%type,
    v_pat_to_mail_id                     in tpa_ins_prod_policy.pat_to_mail_id%type,
    v_pat_cc_mail_id                     in tpa_ins_prod_policy.pat_cc_mail_id%type,
    v_clm_to_mail_id                     in tpa_ins_prod_policy.clm_to_mail_id%type,
    v_clm_cc_mail_id                     in tpa_ins_prod_policy.clm_cc_mail_id%type,
--koc1274a
    v_hcu_pay_to_type_id                 IN tpa_enr_policy.hcu_pay_to_general_type%type,----opdforhs
    v_tpa_name                           IN tpa_enr_policy.tpa_name%type, ----opdforhs
    V_BROKER_GROUP_ID                    IN tpa_enr_policy.BROKER_GROUP_ID%type,  --koc1347_new
    V_BROKER_YN                          IN tpa_enr_policy.BROKER_YN%type,  --koc1347_new
    v_hr_appr_req_yn                     IN tpa_enr_policy.Hr_Appr_Required_Yn%TYPE,
    v_rows_processed                     IN  OUT NUMBER,
    V_AUTH_PRODUCT_CODE                  IN tpa_enr_policy.AUTH_PRODUCT_CODE%type,
    v_co_ins                             IN tpa_enr_policy.co_ins%type,
    v_Deductable                         IN tpa_enr_policy.Deductable%TYPE,
    v_pol_Class                          IN tpa_enr_policy.pol_class%type,
    v_pol_plan                           IN tpa_enr_policy.pol_plan%type,
    v_Maternity_yn                       IN tpa_enr_policy.Maternity_Yn%TYPE,
    v_Maternity_Co_Pay                   IN tpa_enr_policy.Maternity_Co_Pay%TYPE,
    v_Optical_yn                         IN tpa_enr_policy.Optical_Yn%TYPE,
    v_Optical_Co_Pay                     IN tpa_enr_policy.optical_co_pay%type,
    v_Dental_yn                          IN tpa_enr_policy.dental_yn%type,
    v_Dental_Co_Pay                      IN tpa_enr_policy.dental_co_pay%type,
    v_Eligibility_yn                     IN tpa_enr_policy.eligibility_yn%type,
    v_IP_OP_Services                     IN tpa_enr_policy.ip_op_services%type,
    v_Pharmaceutical                     in tpa_enr_policy.pharmaceutical%type,
    v_opts_pat_limit                     IN tpa_enr_policy.opts_pat_limit%type,
    v_stop_pre_date                      IN tpa_ins_prod_policy.stop_preauth_date%type,
    v_stop_clm_date	                 IN tpa_ins_prod_policy.stop_clm_date%type       
   );
 --==============================================================================================
  PROCEDURE select_buffer_list (
    v_prod_policy_seq_id                  IN  TPA_INS_PROD_POLICY.prod_policy_seq_id%TYPE,
    v_sort_var                            IN VARCHAR2:='buffer_seq_id' ,
    v_sort_order                          IN VARCHAR2,
    v_start_num                           IN NUMBER,
    v_end_num                             IN NUMBER,
    v_added_by                            IN NUMBER,
    result_set                            OUT SYS_REFCURSOR
  );
 --==============================================================================================
  PROCEDURE select_buffer_details (
    v_buffer_seq_id                       IN  TPA_ENR_BUFFER_DETAILS.buffer_seq_id%TYPE,
    v_policy_seq_id                       IN  TPA_ENR_BUFFER_DETAILS.policy_seq_id%TYPE,
    v_added_by                            IN NUMBER,
    result_set                            OUT SYS_REFCURSOR
  );
 --==============================================================================================
PROCEDURE save_buffer_details (
    v_buffer_seq_id                      IN  OUT TPA_ENR_BUFFER_DETAILS.buffer_seq_id%TYPE,
    v_prod_policy_seq_id                 IN  TPA_INS_PROD_POLICY.prod_policy_seq_id%TYPE,
    v_buffer_added_date                  IN  TPA_ENR_BUFFER_DETAILS.buffer_added_date%TYPE,
    v_buffer_mode_general_type_id        IN  TPA_ENR_BUFFER_DETAILS.buffer_mode_general_type_id%TYPE,
    v_buffer_amount                      IN  TPA_ENR_BUFFER_DETAILS.buffer_amount%TYPE,
    v_reference_no                       IN  TPA_ENR_BUFFER_DETAILS.reference_no%TYPE,
    v_remarks                            IN  TPA_ENR_BUFFER_DETAILS.remarks%TYPE,
    v_buffer_alloc_amount                IN  TPA_ENR_BUFFER_DETAILS.buffer_alloc_amount%TYPE,
    v_med_buff_amount                    IN  TPA_ENR_BUFFER_DETAILS.Med_Buffer_Amount%type,
    v_critical_buff_amount               IN  TPA_ENR_BUFFER_DETAILS.CRITICAL_BUFF_AMOUNT%TYPE,
    v_critical_corp_buff_amount          IN  TPA_ENR_BUFFER_DETAILS.Critical_Corp_Buff_Amount%type,
    v_critical_med_buff_amount           IN  TPA_ENR_BUFFER_DETAILS.Critical_Med_Buff_Amount%type,
    v_med_buff_alloc_amount              IN  TPA_ENR_BUFFER_DETAILS.Med_Buff_Alloc_Amount%TYPE,
    v_critical_buff_alloc_amount         IN  TPA_ENR_BUFFER_DETAILS.CRIT_BUFF_ALLOC_AMOUNT%type,
    v_critical_corp_alloc_amount         IN  TPA_ENR_BUFFER_DETAILS.Crit_Corp_buff_Alloc_Amount%type,
    v_critical_med_alloc_amount          IN  TPA_ENR_BUFFER_DETAILS.Crit_Med_buff_Alloc_Amount%type,
    v_added_by                           IN  TPA_ENR_BUFFER_DETAILS.added_by%TYPE,
    v_alert                              OUT VARCHAR2,
    v_rows_processed                     IN  OUT NUMBER);
 --==============================================================================================
   PROCEDURE get_buffer_decription (
    v_prod_policy_seq_id                  IN  tpa_ins_prod_policy.prod_policy_seq_id%TYPE,
    result_set                            OUT SYS_REFCURSOR
  );
 --===============================================================================
  -- Author  : SUNIL_M
  -- Created : 14/11/2006 6:38:45 PM
  -- Purpose :

--===============================================================================
 PROCEDURE generate_renewal_members(
    v_policy_seq_id      IN VARCHAR2,
    results_set          OUT SYS_REFCURSOR
  );
--==============================================================================
   FUNCTION get_utilised_buffer_amount(
    v_policy_seq_id             IN  tpa_enr_policy.policy_seq_id%TYPE,
    v_policy_group_seq_id       IN  tpa_enr_policy_group.policy_group_seq_id%TYPE,
    v_member_seq_id             IN  tpa_enr_policy_member.member_seq_id%TYPE,
    v_buffer_type               IN  CHAR
  ) RETURN NUMBER;
--==============================================================================
  PROCEDURE save_prod_policy_clauses(
    v_clause_seq_id                      IN  OUT TPA_PROD_POLICY_CLAUSES.clause_seq_id%TYPE,
    v_prod_policy_seq_id                 IN  TPA_PROD_POLICY_CLAUSES.prod_policy_seq_id%TYPE,
    v_clause_yn                          IN  TPA_PROD_POLICY_CLAUSES.clause_yn%TYPE,
    v_clause_number                      IN  TPA_PROD_POLICY_CLAUSES.clause_number%TYPE,
    v_clause_description                 IN  TPA_PROD_POLICY_CLAUSES.clause_description%TYPE,
    v_added_by                           IN  TPA_PROD_POLICY_CLAUSES.added_by%TYPE,
    v_clause_type                        IN  TPA_PROD_POLICY_CLAUSES.clause_type%TYPE, --Added for koc1179
    v_clause_sub_type                    IN  TPA_PROD_POLICY_CLAUSES.clause_sub_type%TYPE,--Added for koc1179
    v_rows_processed                     IN  OUT NUMBER
  );
--==============================================================================
  PROCEDURE select_prod_policy_clauses (
    v_prod_policy_seq_id                 IN  TPA_PROD_POLICY_CLAUSES.prod_policy_seq_id%TYPE,
    v_identifier                         IN VARCHAR2,
    v_resultset                          OUT SYS_REFCURSOR
  );
--==============================================================================
  PROCEDURE delete_clauses (
    v_seq_ids                            IN  VARCHAR2,
    v_added_by                           IN  NUMBER,
    v_rows_processed                     IN  OUT NUMBER
  );
--==============================================================================
  PROCEDURE update_finance_status( v_seq_id IN NUMBER, v_flag  IN VARCHAR2 ,v_added_by  IN NUMBER );
--==============================================================================
PROCEDURE update_preath_n_claims(
    v_policy_seq_id                   IN tpa_enr_policy.policy_seq_id%TYPE ,
    v_buffer_alloc_amount             IN tpa_enr_policy.buffer_alloc_amount%TYPE,
    v_buffer_alloc_gen_type_id        IN tpa_enr_policy.buffer_alloc_general_type_id%TYPE ,
    v_policy_sub_general_type_id      IN tpa_enr_policy.policy_sub_general_type_id%TYPE,
    v_total_buffer_amount             IN TPA_ENR_POLICY.total_buffer_amount%TYPE := NULL,
    v_total_med_buffer_amount         IN TPA_ENR_POLICY.Tot_Med_Buff_Amount%TYPE := NULL,
    v_tot_crit_buffer_amount          IN TPA_ENR_POLICY.Tot_Crit_Buff_Amount%TYPE := NULL,
    v_total_crit_corp_buff_amount     IN TPA_ENR_POLICY.Tot_Crit_corp_Buff_Amount%TYPE := NULL,
    v_total_crit_med_buff_amount      IN  TPA_ENR_POLICY.TOT_CRIT_MED_BUFF_AMOUNT%TYPE := NULL ,
    v_med_buffer_alloc_amount         IN TPA_ENR_POLICY.Med_Buff_Alloc_Amount%TYPE := NULL,
    v_critical_buffer_alloc_amount    IN TPA_ENR_POLICY.Crit_Buff_Alloc_Amount%TYPE := NULL,
    v_critical_corp_alloc_amount      IN TPA_ENR_POLICY.Crit_Corp_Buff_Alloc_Amount%TYPE := NULL    ,
    v_critical_med_alloc_amount       IN TPA_ENR_POLICY.Crit_Med_Buff_Alloc_Amount%TYPE := NULL ,
    v_alert                           OUT VARCHAR2
  );
 --==============================================================================================
 -- Author  : Ramakrishna K M
  -- Created : 24/12/2007
  -- Purpose : Used in Adminsitration-.Policies->WebConfig->Web Login Links List
  --===============================================================================
 PROCEDURE select_weblogin_link_list(
    v_prod_policy_seq_id                IN   tpa_ins_prod_policy.prod_policy_seq_id%TYPE,
    v_sort_var                          IN   VARCHAR2,
    v_sort_order                        IN   VARCHAR2,
    v_start_num                         IN   NUMBER,
    v_end_num                           IN   NUMBER,
    v_added_by                          IN   NUMBER,
    result_set                          OUT  SYS_REFCURSOR
  );
  --===============================================================================
  -- Author  : Ramakrishna K M
  -- Created : 24/12/2007
  -- Purpose : Used in Adminsitration-.Policies->WebConfig->Web Login Links Details

--===============================================================================
 PROCEDURE select_weblogin_link_details(
    v_weblink_seq_id                  IN  weblogin_links.weblink_seq_id%TYPE,
    result_set                        OUT SYS_REFCURSOR
  );
--===============================================================================
  -- Author  : Ramakrishna K M
  -- Created : 24/12/2007
  -- Purpose : Used in Adminsitration-.Policies->WebConfig->Web Login Links Save
  --===============================================================================
  PROCEDURE save_weblogin_link_details(
    v_weblink_seq_id                  IN  OUT weblogin_links.weblink_seq_id%TYPE,
    v_prod_policy_seq_id              IN  tpa_ins_prod_policy.prod_policy_seq_id%TYPE,
    v_show_web_link_yn                IN  weblogin_links.show_web_link_yn%TYPE,
    v_link_description                IN  weblogin_links.link_description%TYPE,
    v_link_general_type_id            IN  weblogin_links.link_general_type_id%TYPE,
    v_link_order_number               IN  weblogin_links.link_order_number%TYPE,
    v_link_path                       IN  weblogin_links.link_path%TYPE,
    v_pre_report_general_type_id      IN  weblogin_links.pre_report_general_type_id%TYPE,
    v_added_by                        IN  NUMBER,
    v_rows_processed                  OUT INTEGER
  );
  --===============================================================================
  -- Author  : Ramakrishna K M
  -- Created : 24/12/2007
  -- Purpose : Used in Adminsitration-.Policies->WebConfig->Web Login Links Delete
  --===============================================================================
  PROCEDURE weblogin_link_delete (
      v_weblink_seq_id                IN  VARCHAR2, -- conacatenated string of weblink seq id |seq_id1|seq_id1|....|
      v_added_by                      IN  NUMBER,
      v_rows_processed                OUT INTEGER
   );
 --==============================================================================
 PROCEDURE save_weblogin_config(
    v_webconfig_seq_id                   IN  OUT WEBLOGIN_CONFIG.webconfig_seq_id%TYPE,
    v_prod_policy_seq_id                 IN  WEBLOGIN_CONFIG.prod_policy_seq_id%TYPE,
    v_policy_seq_id                      IN  WEBLOGIN_CONFIG.policy_seq_id%TYPE,
    v_modification_allowed_days          IN  WEBLOGIN_CONFIG.modification_allowed_days%TYPE,
    v_grp_cnt_add_general_type_id        IN  WEBLOGIN_CONFIG.grp_cnt_add_general_type_id%TYPE,
    v_emp_add_general_type_id            IN  WEBLOGIN_CONFIG.emp_add_general_type_id%TYPE,
    v_policy_default_sum_insured         IN  WEBLOGIN_CONFIG.policy_default_sum_insured%TYPE,
    v_opd_limit_sum_insured              IN  WEBLOGIN_CONFIG.opd_limit_sum_insured%TYPE,
    v_inception_date_gen_type_id         IN  WEBLOGIN_CONFIG.inception_date_general_type_id%TYPE,
    v_add_sum_ins_general_type_id        IN  WEBLOGIN_CONFIG.add_sum_ins_general_type_id%TYPE,
    v_grp_cnt_cancel_gen_type_id         IN  WEBLOGIN_CONFIG.grp_cnt_cancel_general_type_id%TYPE,
    v_soft_upl_general_type_id           IN  WEBLOGIN_CONFIG.soft_upl_general_type_id%TYPE,
    v_added_by                           IN  WEBLOGIN_CONFIG.added_by%TYPE,
    v_send_mail_general_type_id          IN  WEBLOGIN_CONFIG.send_mail_general_type_id%TYPE,
    v_pwd_general_type_id                IN  WEBLOGIN_CONFIG.pwd_general_type_id%TYPE,
    v_window_period                      IN  WEBLOGIN_CONFIG.window_period%TYPE,
    v_mail_general_type_id               IN  WEBLOGIN_CONFIG.mail_general_type_id%TYPE,
    v_int_access_gen_type_id             IN  WEBLOGIN_CONFIG.intimation_access_gen_type_id%TYPE,
    v_notification_details               IN  WEBLOGIN_CONFIG.notification_details%TYPE,
    v_report_from                        IN  WEBLOGIN_CONFIG.report_from%TYPE,
    v_report_to                          IN  WEBLOGIN_CONFIG.report_to%TYPE,
    v_online_ass_gen_type_id             IN  WEBLOGIN_CONFIG.online_assistance_gen_type_id%TYPE,
    v_Password_Validity                  IN  WEBLOGIN_CONFIG.password_validity%TYPE,
    v_Show_Allert_Days                   IN  WEBLOGIN_CONFIG.show_allert_days%TYPE,
    v_online_rating_gen_type_id          IN  WEBLOGIN_CONFIG.online_rating_gen_type_id%TYPE,
    v_relship_comb_gen_type_id           IN  WEBLOGIN_CONFIG.relship_comb_gen_type_id%TYPE,--FOR KOC1084 CR
    v_first_login_window_period          IN  WEBLOGIN_CONFIG.first_login_window_period%TYPE,--FOR KOC1091 CR
    v_delete_time_frame                  IN weblogin_config.deletion_time_frame%TYPE, --koc1160
    v_inlaws_count                       IN weblogin_config.inlaws_count%TYPE, --koc1160
    v_opt_general_type_id                IN  CHAR,  --KOC1216
    V_DEFAULT_PREMIUM                    IN  NUMBER, --KOC1216
    V_WRONG_ATTEMPTS                     IN WEBLOGIN_CONFIG.WRONG_ATTEMPTS%TYPE,      --KOC1257
    v_wellness_login_type_id             IN weblogin_config.wellness_login_type_id%TYPE,--KOC1349
    v_gen_type_id                        IN weblogin_config.gen_type_id%type,
    v_rows_processed                     IN  OUT NUMBER
    );
  --==============================================================================
   PROCEDURE select_weblogin_config (
     v_prod_policy_seq_id                 IN  WEBLOGIN_CONFIG.prod_policy_seq_id%TYPE,
     v_added_by                           IN  WEBLOGIN_CONFIG.added_by%TYPE,
     v_result_set                         OUT SYS_REFCURSOR
   );
  --==============================================================================
  PROCEDURE save_weblogin_mem_config(
    v_policy_mem_config_seq_id           IN  WEBLOGIN_POLICY_MEM_CONFIG.policy_mem_config_seq_id%TYPE,
    v_policy_seq_id                      IN  WEBLOGIN_POLICY_MEM_CONFIG.policy_seq_id%TYPE,
    v_prod_policy_seq_id                 IN  WEBLOGIN_POLICY_MEM_CONFIG.prod_policy_seq_id%TYPE,
    v_pol_mem_field_type_id              IN  WEBLOGIN_POLICY_MEM_CONFIG.pol_mem_field_type_id%TYPE,
    v_field_status_general_type_id       IN  WEBLOGIN_POLICY_MEM_CONFIG.field_status_general_type_id%TYPE,
    v_added_by                           IN  WEBLOGIN_POLICY_MEM_CONFIG.added_by%TYPE
  );
  --==============================================================================
    PROCEDURE select_policy_mem_config (
    v_prod_policy_seq_id                 IN  WEBLOGIN_POLICY_MEM_CONFIG.prod_policy_seq_id%TYPE,
    v_result_set                         OUT SYS_REFCURSOR
  );
  --==============================================================================
  -- Author  : Ramakrishna K M
  -- Created : 25/02/2008
  -- Purpose : Used in Adminsitration-.Policies->WebConfig->Ins.Company Information
  --===============================================================================
  PROCEDURE select_ins_comp_info (
      v_prod_policy_seq_id                 IN  WEBLOGIN_INS_INFORMATION.prod_policy_seq_id%TYPE,
      v_result_set                         OUT SYS_REFCURSOR
  );
 --==============================================================================================
 --==============================================================================================
 -- Author  : Ramakrishna K M
  -- Created : 25/02/2008
  -- Purpose : Used in Adminsitration-.Policies->WebConfig->Ins.Company Information
  --===============================================================================
  PROCEDURE save_ins_comp_info (
    v_ins_info_seq_id                    IN  WEBLOGIN_INS_INFORMATION.ins_info_seq_id%TYPE,
    v_prod_policy_seq_id                 IN  WEBLOGIN_INS_INFORMATION.prod_policy_seq_id%TYPE,
    v_policy_seq_id                      IN  WEBLOGIN_INS_INFORMATION.Policy_Seq_Id%TYPE,
    v_ins_comp_information               IN  WEBLOGIN_INS_INFORMATION.ins_comp_information%TYPE,
    v_added_by                           IN  WEBLOGIN_INS_INFORMATION.added_by%TYPE,
    v_rows_processed                     IN  OUT NUMBER
  );
  --==============================================================================================
    --kocnewhosp
    -- Author  : Kishor kumar 
  -- Created : 06/04/2014
    PROCEDURE save_hos_comp_info (
    v_hos_info_seq_id                    IN  WEBLOGIN_HOSP_INFORMATION.SEQ_ID%TYPE,
    v_hosp_information               IN  WEBLOGIN_HOSP_INFORMATION.HOSP_INFORMATION%TYPE,
    v_added_by                           IN  WEBLOGIN_HOSP_INFORMATION.added_by%TYPE,
    v_rows_processed                     IN  OUT NUMBER
  );
  --==============================================================================================
  PROCEDURE save_policy_relationship(
    v_relship_ids                        IN  VARCHAR2,
    v_prod_policy_seq_id                 IN  TPA_PROD_POLICY_RELATIONSHIP.prod_policy_seq_id%TYPE,
    v_policy_seq_id                      IN  OUT TPA_PROD_POLICY_RELATIONSHIP.policy_seq_id%TYPE,
    v_added_by                           IN  TPA_PROD_POLICY_RELATIONSHIP.added_by%TYPE,
    v_rows_processed                     IN  OUT NUMBER
  );
--==============================================================================================
  PROCEDURE select_relship_list (
    v_prod_policy_seq_id    IN OUT tpa_ins_prod_policy.prod_policy_seq_id%TYPE,
    v_result_set            OUT SYS_REFCURSOR
  );
--==============================================================================================
  PROCEDURE select_plan_list(
    v_seq_id                             IN NUMBER,
    v_flag                               IN VARCHAR2, -- 'PRD' -- PRODUCT, 'POL' -- POLICY, 'GRP' -- GROUP REGISTRATION
    v_sort_var                           IN  VARCHAR2,
    v_sort_order                         IN  VARCHAR2,
    v_start_num                          IN  NUMBER ,
    v_end_num                            IN  NUMBER ,
    v_added_by                           IN  NUMBER,
    v_result_set                         OUT SYS_REFCURSOR
  );
--==========================================================================================
  PROCEDURE select_prod_plan(
    v_prod_plan_seq_id                   IN tpa_ins_product_plan.prod_plan_seq_id%TYPE ,
    v_result_set                         OUT SYS_REFCURSOR
  );
--==========================================================================================
  PROCEDURE save_product_plan(
    v_prod_plan_seq_id                   IN  OUT TPA_INS_PRODUCT_PLAN.prod_plan_seq_id%TYPE,
    v_prod_plan_name                     IN  TPA_INS_PRODUCT_PLAN.prod_plan_name%TYPE,
    v_plan_amount                        IN  TPA_INS_PRODUCT_PLAN.plan_amount%TYPE,
    v_product_seq_id                     IN  TPA_INS_PRODUCT_PLAN.product_seq_id%TYPE,
    v_scheme_id                          IN  TPA_INS_PRODUCT_PLAN.scheme_id%TYPE,
    v_plan_code                          IN  TPA_INS_PRODUCT_PLAN.plan_code%TYPE,
    v_group_reg_seq_id                   IN  TPA_INS_PRODUCT_PLAN.group_reg_seq_id%TYPE,
    v_policy_seq_id                      IN  TPA_INS_PRODUCT_PLAN.policy_seq_id%TYPE,
    v_from_age                           IN  TPA_INS_PRODUCT_PLAN.from_age%TYPE,
    v_to_age                             IN  TPA_INS_PRODUCT_PLAN.to_age%TYPE,
    v_plan_premium                       IN  TPA_INS_PRODUCT_PLAN.plan_premium%TYPE,
    v_cash_benefit_amt                   IN  TPA_INS_PRODUCT_PLAN.cash_benefit_amt%TYPE,
    v_benefit_allowed_days               IN  TPA_INS_PRODUCT_PLAN.benefit_allowed_days%TYPE,
    v_benefit_general_type_id            IN  TPA_INS_PRODUCT_PLAN.benefit_general_type_id%TYPE,
    v_added_by                           IN  TPA_INS_PRODUCT_PLAN.added_by%TYPE,
    v_rows_processed                     IN  OUT NUMBER
  );
--==========================================================================================
  PROCEDURE select_clause_doc_list(
    v_prod_policy_seq_id                IN   tpa_ins_prod_policy.prod_policy_seq_id%TYPE,
    v_sort_var                          IN   VARCHAR2,
    v_sort_order                        IN   VARCHAR2,
    v_start_num                         IN   NUMBER,
    v_end_num                           IN   NUMBER,
    v_added_by                          IN   NUMBER,
    result_set                          OUT  SYS_REFCURSOR
  );
--==========================================================================================
  PROCEDURE select_clause_doc_details(
    v_clauses_doc_seq_id              IN  tpa_prod_policy_clauses_doc.clauses_doc_seq_id%TYPE,
    result_set                        OUT SYS_REFCURSOR
  );
--==========================================================================================
  PROCEDURE save_clause_doc_details(
    v_clauses_doc_seq_id              IN  OUT tpa_prod_policy_clauses_doc.clauses_doc_seq_id%TYPE,
    v_prod_policy_seq_id              IN  tpa_prod_policy_clauses_doc.prod_policy_seq_id%TYPE,
    v_doc_name                        IN  tpa_prod_policy_clauses_doc.doc_name%TYPE,
    v_doc_path                        IN  tpa_prod_policy_clauses_doc.doc_path%TYPE,
    v_added_by                        IN  NUMBER,
    v_rows_processed                  OUT INTEGER
  );
--==========================================================================================
  PROCEDURE clause_doc_delete (
      v_clauses_doc_seq_id            IN  VARCHAR2, -- conacatenated string of clause doc seq id |seq_id1|seq_id1|....|
      v_added_by                      IN  NUMBER,
      v_rows_processed                OUT INTEGER
   );
--==========================================================================================
  PROCEDURE select_emp_without_sum_list (
    v_search_str               IN VARCHAR2,
    result_set                 OUT SYS_REFCURSOR
  );
--==========================================================================================
  PROCEDURE select_serv_tax_revision_list (
    v_result_set                  OUT SYS_REFCURSOR
  );
--==========================================================================================
  PROCEDURE select_serv_tax_revision_dtl (
    v_service_tax_seq_id  IN service_tax_config.serv_tax_seq_id%TYPE,
    v_result_set                  OUT SYS_REFCURSOR
  );
--==========================================================================================
  PROCEDURE save_serv_tax_revision_dtl (
    v_service_tax_seq_id       IN OUT service_tax_config.serv_tax_seq_id%TYPE,
    v_rev_date_from            IN VARCHAR2,
    v_applicable_rate_percent  IN service_tax_config.applicable_rate_percent%TYPE,
    v_added_by                 IN service_tax_config.added_by%TYPE,
    v_rows_processed           OUT NUMBER
  );
--==========================================================================================
  PROCEDURE get_disease_codes (
    v_clause_seq_id      IN TPA_PROD_POLICY_CLAUSES.CLAUSE_SEQ_ID%TYPE,
    v_prod_policy_seq_id IN TPA_INS_PROD_POLICY.PROD_POLICY_SEQ_ID%TYPE,
    v_general_code       IN TPA_GENERAL_CODE.GENERAL_TYPE_ID%TYPE,
    v_Assoc_UnAssoc      IN VARCHAR2, -- DBA - Associated DBU - Unassociated
    v_Code_Description   IN TPA_INS_SPECIFIC_CODE.CODE_DESCRIPTION%TYPE,
    v_result_set   OUT SYS_REFCURSOR
  );
--===================================================================================================
  PROCEDURE clause_disease_binding (
    v_clause_seq_id        IN TPA_PROD_POLICY_CLAUSES.CLAUSE_SEQ_ID%TYPE,
    specific_code_seq      IN VARCHAR2,
    v_Assoc_UnAssoc        IN VARCHAR2, -- DBA - Associated DBU - Unassociated
    v_added_by             IN  NUMBER,
    v_rows_processed       OUT INTEGER
  );
--===================================================================================================
  PROCEDURE select_show_cust_msg(
    v_prod_policy_seq_id                IN   tpa_ins_prod_policy.prod_policy_seq_id%TYPE,
    v_result_set                        OUT SYS_REFCURSOR
  );
--===================================================================================================
  PROCEDURE save_show_cust_msg(
    v_prod_policy_seq_id                IN tpa_ins_prod_policy.prod_policy_seq_id%TYPE,
    v_show_cust_msg                     IN tpa_enr_policy.show_cust_msg%TYPE,
    v_message                           IN tpa_enr_policy.message%TYPE,
    v_added_by                          IN tpa_enr_policy.added_by%TYPE,
    v_rows_processed                    OUT NUMBER
  );
--===================================================================================================
  PROCEDURE select_copay_approved_amt(
    v_prod_policy_seq_id                IN   tpa_ins_prod_policy.prod_policy_seq_id%TYPE,
    v_result_set                        OUT SYS_REFCURSOR
  );
--===================================================================================================
  PROCEDURE save_copay_approved_amt(
    v_prod_policy_seq_id                IN tpa_ins_prod_policy.prod_policy_seq_id%TYPE,
    v_copay_approved_amt                IN tpa_ins_prod_policy.copay_approved_amt%TYPE,
    v_added_by                          IN tpa_ins_prod_policy.added_by%TYPE,
    V_rgn_bsd_prm_config                IN tpa_ins_prod_policy.regn_bsd_prm_config%TYPE,--KOC1284
    v_rows_processed                    OUT NUMBER
  );

--===================================================================================================
--KOC1270





--===================================================================================================
  PROCEDURE save_product_cash_benefit(
    v_ins_cash_benefit_seq_id            IN  OUT TPA_INS_CASH_BENEFIT.ins_cash_benefit_seq_id%TYPE,
    v_flag                               IN  varchar2,--'HCB' hospital cash Benefit; 'CONV_BENEF' convalance benefit
    v_prod_plan_name                     IN  TPA_INS_CASH_BENEFIT.cash_benefit_plan_name%TYPE,
    v_product_seq_id                     IN  TPA_INS_CASH_BENEFIT.product_seq_id%TYPE,
    v_scheme_id                          IN  TPA_INS_CASH_BENEFIT.scheme_id%TYPE,
    v_plan_code                          IN  TPA_INS_CASH_BENEFIT.cash_benefit_plan_code%TYPE,
    v_group_reg_seq_id                   IN  TPA_INS_CASH_BENEFIT.group_reg_seq_id%TYPE,
    v_policy_seq_id                      IN  TPA_INS_CASH_BENEFIT.policy_seq_id%TYPE,
    v_from_age                           IN  TPA_INS_CASH_BENEFIT.from_age%TYPE,
    v_to_age                             IN  TPA_INS_CASH_BENEFIT.to_age%TYPE,
    v_added_by                           IN  TPA_INS_CASH_BENEFIT.added_by%TYPE,
    v_room_amt                           IN  TPA_INS_CASH_BENEFIT.Room_Amt%TYPE,
    v_acc_amt                            IN  TPA_INS_CASH_BENEFIT.acc_amt%TYPE,
    v_icu_amt                            IN  TPA_INS_CASH_BENEFIT.icu_amt%TYPE,
    v_conv_amt                           IN  TPA_INS_CASH_BENEFIT.conv_amt%TYPE,
    v_room_days_claim                    IN  TPA_INS_CASH_BENEFIT.room_days_claim%TYPE,
    v_acc_days_claim                     IN  TPA_INS_CASH_BENEFIT.acc_days_claim%TYPE,
    v_icu_days_claim                     IN  TPA_INS_CASH_BENEFIT.icu_days_claim%TYPE,
    v_conv_days_claim                    IN  TPA_INS_CASH_BENEFIT.conv_days_claim%TYPE,
    V_ROOM_PER_SI                        IN  TPA_INS_CASH_BENEFIT.ROOM_PER_SI%TYPE,
    V_ACC_PER_SI                         IN  TPA_INS_CASH_BENEFIT.ACC_PER_SI%TYPE,
    V_ICU_PER_SI                         IN  TPA_INS_CASH_BENEFIT.ICU_PER_SI%TYPE,
    V_CONV_PER_SI                        IN  TPA_INS_CASH_BENEFIT.CONV_PER_SI%TYPE,
    V_POLICY_DAYS                        IN  TPA_INS_CASH_BENEFIT.POLICY_DAYS%TYPE,
    v_rows_processed                     IN  OUT NUMBER
    );
--===================================================================================================
 PROCEDURE select_prod_cash_benefit(
    v_ins_cash_benefit_seq_id            IN TPA_INS_CASH_BENEFIT.INS_CASH_BENEFIT_SEQ_ID%TYPE ,
    v_flag                               IN varchar2, --'HCB' hospital cash Benefit; 'CONV_BENEF' convalance benefit
    v_result_set                         OUT SYS_REFCURSOR
  );
--===================================================================================================
PROCEDURE select_cash_benefit_list(
    v_seq_id                             IN NUMBER, -- prod_policy_seq_id
    v_flag                               IN VARCHAR2, -- 'PRD' -- PRODUCT, 'POL' -- POLICY
    v_cash_benefit_flg                   IN VARCHAR2, --'HCB' hospital cash Benefit; 'CONV_BENEF' convalance benefit
    v_sort_var                           IN  VARCHAR2,
    v_sort_order                         IN  VARCHAR2,
    v_start_num                          IN  NUMBER ,
    v_end_num                            IN  NUMBER ,
    v_added_by                           IN  NUMBER,
    v_result_set                         OUT SYS_REFCURSOR
  );
--KOC1270
 --================================================================================

 PROCEDURE save_dom_config(
       v_prod_policy_seq_id              IN OUT tpa_ins_prod_policy.prod_policy_seq_id%TYPE,
       v_dom_config_type                 IN tpa_ins_prod_policy.dom_config_type%TYPE,--'ENR'-enrollment,'PRD' -- PRODUCT, 'POL' -- POLICY
       v_added_by                        IN tpa_ins_prod_policy.added_by%TYPE,
       v_alert                           OUT Tpa_Enr_Policy.Remarks%TYPE ); --koc1285
 --========================================================================
 PROCEDURE select_dom_config(
    v_prod_policy_seq_id                IN   tpa_ins_prod_policy.prod_policy_seq_id%TYPE,
    v_result_set                        OUT SYS_REFCURSOR );--koc1285


      PROCEDURE si_restriction_rel (
          v_prod_policy_seq_id     IN Tpa_ins_prod_policy.prod_policy_seq_id%TYPE,
          v_si_restrc_yn           IN Tpa_ins_prod_policy.si_restrict_yn%TYPE:='N',
          v_si_relation            IN Tpa_ins_prod_policy.si_relation%TYPE,
          v_si_restrc_amt          IN Tpa_ins_prod_policy.si_restrict_amt%TYPE,
          v_si_restrc_perc         IN Tpa_ins_prod_policy.si_restrict_perc%TYPE,
          v_si_flag                IN Tpa_ins_prod_policy.si_type%TYPE,
          v_si_restrc_level        IN Tpa_ins_prod_policy.si_rest_level%TYPE,
          v_rest_age               IN Tpa_Ins_Prod_Policy.Rest_Age%TYPE,
          v_rest_age_amt           IN Tpa_Ins_Prod_Policy.Rest_Age_Amt%TYPE,
          v_added_by               IN Tpa_ins_prod_policy.added_by%TYPE,
          v_rows_processed         OUT NUMBER,
          v_alert                  OUT VARCHAR2 );
--===================================================================================================
  PROCEDURE select_si_restriction_rel(
         v_prod_policy_seq_id                IN   tpa_ins_prod_policy.prod_policy_seq_id%TYPE,
         v_result_set                        OUT SYS_REFCURSOR );
--================================================================================================
PROCEDURE save_copay_max_limit(
        v_prod_policy_seq_id                IN tpa_ins_prod_policy.prod_policy_seq_id%TYPE,
        v_copay_yn                          IN tpa_ins_prod_policy.copay_yn%TYPE:='N',
        v_copay_approved_amt                IN tpa_ins_prod_policy.copay_approved_amt%TYPE,
        v_copay_perc                        IN tpa_ins_prod_policy.copay_perc%TYPE,
        v_added_by                          IN tpa_ins_prod_policy.added_by%TYPE,
        V_rgn_bsd_prm_config                IN tpa_ins_prod_policy.regn_bsd_prm_config%TYPE,--KOC1284
        v_rows_processed                    OUT NUMBER );
--=================================================================================================

PROCEDURE save_product_critical_benefit(
    V_CRITICAL_CONFIG_SEQ_ID             IN  OUT CRITICAL_ILLNESS_CONFIG.CRITICAL_ILLNESS_CONFIG_SEQ_ID%TYPE,
    V_FRM_AGE                            IN  CRITICAL_ILLNESS_CONFIG.FRM_AGE%TYPE,
    V_TO_AGE                             IN  CRITICAL_ILLNESS_CONFIG.TO_AGE%TYPE,
    V_AGE_OPTR                           IN  CRITICAL_ILLNESS_CONFIG.AGE_OPTR%TYPE,
    V_AMOUNT                             IN  CRITICAL_ILLNESS_CONFIG.AMOUNT%TYPE,
    V_SURV_PRD                           IN  CRITICAL_ILLNESS_CONFIG.SURV_PRD%TYPE,
    V_group_reg_seq_id                   IN  CRITICAL_ILLNESS_CONFIG.group_reg_seq_id%TYPE,
    V_policy_seq_id                      IN  CRITICAL_ILLNESS_CONFIG.policy_seq_id%TYPE,
    V_product_seq_id                     IN  CRITICAL_ILLNESS_CONFIG.product_seq_id%TYPE,
    V_CRITICAL_GRP                       IN  CRITICAL_ILLNESS_CONFIG.CRITICAL_GRP%TYPE,
    V_NO_OF_TIMES                        IN  CRITICAL_ILLNESS_CONFIG.NO_OF_TIMES%TYPE,
    V_SUM_INS_PER                        IN  CRITICAL_ILLNESS_CONFIG.SUM_INS_PER%TYPE,
    V_WAITING_PERIOD                     IN  CRITICAL_ILLNESS_CONFIG.WAITING_PERIOD%TYPE,
    v_rows_processed                     OUT NUMBER
    );
--===================================================================================================


---koc 1179
PROCEDURE save_shortfall_email_config
  (v_config_seq_id              IN OUT     SHORTFALL_EMAIL_CONFIG.CONFIG_SEQ_ID%TYPE,
   v_prod_policy_seq_id            IN      SHORTFALL_EMAIL_CONFIG.PROD_POLICY_SEQ_ID%TYPE,
   v_remidner_letter_days          IN      SHORTFALL_EMAIL_CONFIG.REMINDER_LETTER_DAYS%TYPE,
   v_closer_notice_days            IN      SHORTFALL_EMAIL_CONFIG.CLOSER_NOTICE_DAYS%TYPE,
   v_approval_closer_days          IN      SHORTFALL_EMAIL_CONFIG.APPROVAL_CLOSER_DAYS%TYPE,
   v_claim_closer_letter_days      IN      SHORTFALL_EMAIL_CONFIG.claim_closer_letter_days%TYPE,
   v_clm_docs_submit_in_days       IN      SHORTFALL_EMAIL_CONFIG.clm_docs_submit_in_days%TYPE,
   v_clm_intimation_days           IN      SHORTFALL_EMAIL_CONFIG.clm_intimation_days%TYPE,
   v_regrett_letter_days           IN      SHORTFALL_EMAIL_CONFIG.regrett_letter_days%TYPE,
   v_added_by                      IN      SHORTFALL_EMAIL_CONFIG.ADDED_BY%TYPE,
   v_Post_Hosp_Days                IN      SHORTFALL_EMAIL_CONFIG.Post_Hosp_Days%TYPE);

--===================================================================================================
-- koc 1179
PROCEDURE select_shortfall_email_config
  (v_prod_policy_seq_id  IN OUT    SHORTFALL_EMAIL_CONFIG.PROD_POLICY_SEQ_ID%TYPE,
   v_result_set          OUT       SYS_REFCURSOR);
--===================================================================================================

function prod_policy_clauses_exist( v_seq_id  IN  NUMBER,v_type varchar2) RETURN NUMBER;
--===================================================================================================

function get_max_restrict_amt(v_policy_seq_id        IN tpa_enr_policy.policy_seq_id%type,
                              v_policy_group_seq_id  IN tpa_enr_policy_group.policy_group_seq_id%type,
                              v_member_seq_id        IN tpa_enr_policy_member.member_seq_id%type,
                              v_flag                 IN CHAR) return number ;
--===================================================================================================
                              
function get_max_restrict_amt_rel(v_policy_seq_id    IN tpa_enr_policy.policy_seq_id%type,
                              v_policy_group_seq_id  IN tpa_enr_policy_group.policy_group_seq_id%type,
                              v_member_seq_id        IN tpa_enr_policy_member.member_seq_id%type,
                              v_flag                 IN CHAR)return number;

PROCEDURE  save_buffer_level_limits(v_buff_level_seq_id    IN OUT tpa_enr_buffer_level_config.buff_level_seq_id%type,
                                    v_prod_policy_seq_id        IN tpa_enr_policy.policy_seq_id%type,
                                    v_buffer_type          IN tpa_enr_buffer_level_config.buffer_type%type,
                                    v_level_type           IN tpa_enr_buffer_level_config.Level_Type%TYPE,
                                    v_level_limit          IN tpa_enr_buffer_level_config.Level_Limit%TYPE,
                                    v_remarks              IN tpa_enr_buffer_level_config.Remarks%TYPE,
                                    v_added_by             IN tpa_enr_buffer_level_config.added_by%type,
                                    v_alert                              OUT VARCHAR2,
                                    v_rows_processed       OUT NUMBER) ;
                              
--===================================================================================================
PROCEDURE  del_buffer_level_limits(v_buff_level_seq_ids   IN varchar2,
                                   v_prod_policy_seq_id        IN tpa_enr_buffer_level_config.prod_policy_seq_id%TYPE,
                                   v_buffer_type          IN tpa_enr_buffer_level_config.buffer_type%type,
                                   v_added_by             IN tpa_enr_buffer_level_config.added_by%type,
                                   v_rows_processed       OUT NUMBER);
--===================================================================================================
PROCEDURE  select_buff_level_limits_list(v_prod_policy_seq_id      IN tpa_enr_buffer_level_config.prod_policy_seq_id%TYPE,
                                      v_added_by             IN tpa_enr_buffer_level_config.added_by%type,
                                      v_result_set           OUT SYS_REFCURSOR);
--===================================================================================================
PROCEDURE  select_buff_level_limit(v_buff_level_seq_id       IN tpa_enr_buffer_level_config.buff_level_seq_id%TYPE,
                                   v_result_set              OUT SYS_REFCURSOR);
--===================================================================================================
                                                                      
  --===============================================================================
  -- Author  : KISHOR KUMAR S.H
  -- Created : 14/05/2014
  -- Purpose : Used in Adminsitration-.Configuration->Hospital Configuration->Web Login Links Save
  --===============================================================================
    PROCEDURE save_weblogin_hosp_links(
     v_weblink_seq_id                  IN  OUT WEBLOGIN_HOSP_LINKS.weblink_seq_id%TYPE,
    v_prod_policy_seq_id              IN  tpa_hosp_info.hosp_seq_id%TYPE,
    v_show_web_link_yn                IN  WEBLOGIN_HOSP_LINKS.show_web_link_yn%TYPE,
    v_link_description                IN  WEBLOGIN_HOSP_LINKS.link_description%TYPE,
    v_link_order_number               IN  WEBLOGIN_HOSP_LINKS.link_order_number%TYPE,
    v_link_path                       IN  WEBLOGIN_HOSP_LINKS.link_path%TYPE,
    v_added_by                        IN  NUMBER,
    v_rows_processed                  OUT INTEGER
  );
  
--==============================================================================================
  -- Author  : Kishor Kumar
  -- Created : 15/04/2014
  -- Purpose : Used in Adminsitration-.Policies->WebConfig->Web Login Links Select
  --===============================================================================
 
    PROCEDURE select_weblogin_hosplink_list(
    v_sort_var                          IN   VARCHAR2,
    v_sort_order                        IN   VARCHAR2,
    v_start_num                         IN   NUMBER,
    v_end_num                           IN   NUMBER,
    v_added_by                          IN   NUMBER,
    result_set                          OUT  SYS_REFCURSOR
  );
  
      --===============================================================================
  -- Author  : KISHOR KUMAR S H
  -- Created : 15/05/2014
  -- Purpose : Used in Adminsitration-.cONFIGURATION->Web Login Links Delete
  --===============================================================================
  PROCEDURE web_hosp_link_delete (
      v_weblink_seq_id                IN  VARCHAR2, -- conacatenated string of weblink seq id |seq_id1|seq_id1|....|
      v_added_by                      IN  NUMBER,
      v_rows_processed                OUT INTEGER
   );
  --===============================================================================
PROCEDURE save_pre_approval_limit(
    v_prod_policy_seq_id                IN tpa_ins_prod_policy.prod_policy_seq_id%TYPE,
    v_vip_pre_aprvl_limit_yn            IN tpa_ins_prod_policy.VIP_PRE_APRVL_LIMIT_YN%TYPE,
    v_vip_aprvl_limit                   IN tpa_ins_prod_policy.VIP_PRE_APRVL_LIMIT%TYPE,
    v_vip_mdt_srvce_pre_aprvl_yn        IN tpa_ins_prod_policy.VIP_MDT_SRVCE_PRE_APRVL_YN%TYPE,
    v_non_vip_pre_aprvl_limit_yn        IN tpa_ins_prod_policy.NON_VIP_PRE_APRVL_LIMIT_YN%TYPE,
    v_non_vip_aprvl_limit               IN tpa_ins_prod_policy.NON_VIP_PRE_APRVL_LIMIT%TYPE,
    v_non_vip_mdt_srv_pre_aprvl_yn      IN tpa_ins_prod_policy.NON_VIP_MDT_SRVCE_PRE_APRVL_YN%TYPE,
    v_added_by                          IN tpa_ins_prod_policy.added_by%TYPE,
    v_rows_processed                    OUT NUMBER
  );
--================================================================================
 PROCEDURE select_pre_approval_limit(
    v_prod_policy_seq_id                IN   tpa_ins_prod_policy.prod_policy_seq_id%TYPE,
    v_result_set                        OUT SYS_REFCURSOR
  );
 --=================================================================================================
PROCEDURE save_policy_tob_doc (v_prod_policy_seq_id         IN  tpa_ins_prod_policy.prod_policy_seq_id%TYPE,
                               v_pol_tob_doc                IN  TPA_ENR_POLICY.POL_TOB_DOC%TYPE,
                               v_row_processed              OUT NUMBER);
                                
 --=================================================================================================
PROCEDURE select_policy_tob_doc (v_prod_policy_seq_id         IN  tpa_ins_prod_policy.prod_policy_seq_id%TYPE,
                                 v_pol_tob_doc                OUT TPA_ENR_POLICY.POL_TOB_DOC%TYPE);
 --=================================================================================================                                  
PROCEDURE delete_policy_tob_doc (v_prod_policy_seq_id         IN  tpa_ins_prod_policy.prod_policy_seq_id%TYPE,
                                 v_row_processed              OUT NUMBER);
--==============================================================================================
 PROCEDURE save_benefit_buffer(p_seq_id                     IN  NUMBER,
                               p_dntl_buffer_limit          IN  tpa_ins_prod_policy.dntl_buffer_limit%TYPE,
                               p_optc_buffer_limit          IN  tpa_ins_prod_policy.optc_buffer_limit%TYPE,
                               p_opts_buffer_limit          IN  tpa_ins_prod_policy.opts_buffer_limit%TYPE,
                               p_opts_pharma_buffer_limit   IN  tpa_ins_prod_policy.opts_pharma_buffer_limit%TYPE,
                               p_omti_buffer_limit          IN  tpa_ins_prod_policy.omti_buffer_limit%TYPE,
                               p_added_by                   IN  tpa_ins_prod_policy.added_by%TYPE,
                               p_row_procesed               OUT NUMBER 
                              );                                 
---=====================================================================================================
PROCEDURE gen_renewal_mbrs_admin(
    v_policy_seq_id      IN VARCHAR2,
    v_status             IN VARCHAR2,
    results_set          OUT SYS_REFCURSOR
  );
 
--------------------------------------------------------------------------------------------------------

END ADMINISTRATION_PKG;

/

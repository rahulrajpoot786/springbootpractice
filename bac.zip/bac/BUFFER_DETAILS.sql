--------------------------------------------------------
--  DDL for Synonymn BUFFER_DETAILS
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."BUFFER_DETAILS" FOR "APP"."BUFFER_DETAILS";

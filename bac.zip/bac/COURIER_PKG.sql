--------------------------------------------------------
--  DDL for Synonymn COURIER_PKG
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."COURIER_PKG" FOR "APP"."COURIER_PKG";

--------------------------------------------------------
--  DDL for Sequence CLM_PAT_FRAUD_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "VENUBABU"."CLM_PAT_FRAUD_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1 CACHE 20 NOORDER  NOCYCLE ;

--------------------------------------------------------
--  DDL for Synonymn HR_FILE_SEQ
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."HR_FILE_SEQ" FOR "APP"."HR_FILE_SEQ";

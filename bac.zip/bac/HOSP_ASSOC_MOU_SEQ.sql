--------------------------------------------------------
--  DDL for Synonymn HOSP_ASSOC_MOU_SEQ
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."HOSP_ASSOC_MOU_SEQ" FOR "APP"."HOSP_ASSOC_MOU_SEQ";

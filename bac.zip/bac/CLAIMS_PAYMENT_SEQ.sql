--------------------------------------------------------
--  DDL for Synonymn CLAIMS_PAYMENT_SEQ
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."CLAIMS_PAYMENT_SEQ" FOR "APP"."CLAIMS_PAYMENT_SEQ";

--------------------------------------------------------
--  DDL for Synonymn ALHALI_COV_BENFT_FACTOR
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."ALHALI_COV_BENFT_FACTOR" FOR "APP"."ALHALI_COV_BENFT_FACTOR";

--------------------------------------------------------
--  DDL for Synonymn IDX_END_ENDNUM
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."IDX_END_ENDNUM" FOR "APP"."IDX_END_ENDNUM";

--------------------------------------------------------
--  DDL for Synonymn CRITICAL_ILLNESS_CONFIG
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."CRITICAL_ILLNESS_CONFIG" FOR "APP"."CRITICAL_ILLNESS_CONFIG";

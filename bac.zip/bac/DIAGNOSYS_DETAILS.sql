--------------------------------------------------------
--  DDL for Synonymn DIAGNOSYS_DETAILS
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."DIAGNOSYS_DETAILS" FOR "APP"."DIAGNOSYS_DETAILS";

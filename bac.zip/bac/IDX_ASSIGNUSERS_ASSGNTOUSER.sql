--------------------------------------------------------
--  DDL for Synonymn IDX_ASSIGNUSERS_ASSGNTOUSER
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."IDX_ASSIGNUSERS_ASSGNTOUSER" FOR "APP"."IDX_ASSIGNUSERS_ASSGNTOUSER";

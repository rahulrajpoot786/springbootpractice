--------------------------------------------------------
--  DDL for Synonymn DHPO_SH_TRANSACTIONS_SEQ
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."DHPO_SH_TRANSACTIONS_SEQ" FOR "APP"."DHPO_SH_TRANSACTIONS_SEQ";

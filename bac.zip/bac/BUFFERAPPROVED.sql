--------------------------------------------------------
--  DDL for Synonymn BUFFERAPPROVED
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."BUFFERAPPROVED" FOR "APP"."BUFFERAPPROVED";

--------------------------------------------------------
--  DDL for Synonymn DHA_TARIF_PROVIDER_COST
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."DHA_TARIF_PROVIDER_COST" FOR "APP"."DHA_TARIF_PROVIDER_COST";

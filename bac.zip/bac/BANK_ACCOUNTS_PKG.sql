--------------------------------------------------------
--  DDL for Synonymn BANK_ACCOUNTS_PKG
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."BANK_ACCOUNTS_PKG" FOR "APP"."BANK_ACCOUNTS_PKG";

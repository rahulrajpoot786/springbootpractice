--------------------------------------------------------
--  DDL for Synonymn COURIER_RECEIPT_DTL_ERR_LOG
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."COURIER_RECEIPT_DTL_ERR_LOG" FOR "APP"."COURIER_RECEIPT_DTL_ERR_LOG";

--------------------------------------------------------
--  DDL for Package Body HOSP_PBM_PKG
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "VENUBABU"."HOSP_PBM_PKG" 
  
IS



PROCEDURE select_pbm_drug_list (
    v_search_flag              IN VARCHAR2,--CODE,DESC,
    v_search_data              IN OUT VARCHAR2,
    v_sort_var                 IN OUT VARCHAR2 ,
    v_sort_order               IN OUT VARCHAR2,
    v_start_num                IN OUT NUMBER  ,
    v_end_num                  IN OUT NUMBER  ,
    v_hosp_date                IN VARCHAR2 ,
    v_result_set               OUT SYS_REFCURSOR
  )
  IS
  v_str                      VARCHAR2(2000);
  v_count  number;
  v_hosp_date1   Date:=to_date(v_hosp_date,'dd/mm/rrrr');
  BEGIN

    v_sort_var   := CASE WHEN  v_sort_var IS NULL  then 'SEARCH_DATA' ELSE v_sort_var END;
    v_sort_order := CASE WHEN v_sort_order IS NULL THEN 'ASC' ELSE v_sort_order END;
    v_start_num  := CASE WHEN v_start_num IS NULL THEN 1 ELSE v_start_num END;
    v_end_num    := CASE WHEN v_end_num IS NULL THEN 101 ELSE v_end_num END;

    --v_act_code         := CASE WHEN v_act_code IS NOT NULL THEN UPPER(v_act_code)||'%' ELSE v_act_code END;
    v_search_data      := CASE WHEN v_search_data IS NOT NULL THEN '%'||UPPER(replace(v_search_data,' ','%'))||'%' ELSE v_search_data END;

    SELECT count(1) into v_count
             FROM tpa_pharmacy_master_details md
             WHERE ( UPPER(v_search_data) IS NULL OR (md.activity_description) LIKE UPPER(v_search_data))
             AND md.start_date <= v_hosp_date1 and nvl(md.end_date,v_hosp_date1) >=v_hosp_date1;
     
     if v_count>0 then
     v_str := 
      'SELECT DISTINCT * FROM (SELECT (md.activity_code||''#''||md.activity_description||''#''||md.granular_unit) as search_data
       FROM tpa_pharmacy_master_details md
       where md.activity_type_seq_id = 5 
       AND (:v_search_data IS NULL OR upper(md.activity_description) LIKE :v_search_data )
       AND md.start_date <= :v_hosp_date1 and nvl(md.end_date,:v_hosp_date1) >=:v_hosp_date1)';  
       
      else  
         v_str := 
      'SELECT DISTINCT * FROM (SELECT (md.activity_code||''#''||md.activity_description||''#''||md.granular_unit) as search_data
       FROM tpa_pharmacy_master_details md
       where md.activity_type_seq_id = 5 
       AND (:v_search_data IS NULL OR upper(md.activity_description) LIKE :v_search_data ))';  
      end if;
       
  v_str := 'SELECT * FROM
      (SELECT A.*, DENSE_RANK() OVER (ORDER BY '||v_sort_var||' '||v_sort_order||',ROWNUM) Q FROM (' ||v_str|| ') A )
       WHERE  Q>= :v_start_num  AND Q<= :v_end_num ';
 
   IF v_count>0 then
      OPEN v_result_set FOR v_str USING v_search_data, v_search_data ,v_hosp_date1,v_hosp_date1,v_hosp_date1, v_start_num, v_end_num;
   else 
      OPEN v_result_set FOR v_str USING v_search_data, v_search_data , v_start_num, v_end_num;
   end if;

   
  
END select_pbm_drug_list;
                                 
------================================================================
PROCEDURE select_pbm_icd_list (
    v_search_flag              IN VARCHAR2,--CODE,DESC
    v_search_data             IN OUT VARCHAR2, 
    v_sort_var                 IN OUT VARCHAR2 ,
    v_sort_order               IN OUT VARCHAR2,
    v_start_num                IN OUT NUMBER  ,
    v_end_num                  IN OUT NUMBER  ,
    v_result_set               OUT SYS_REFCURSOR
  )
  IS
  v_str                      VARCHAR2(2000);
  
  BEGIN

    v_sort_var   := CASE WHEN v_sort_var IS NULL and v_search_flag ='CODE' THEN 'icd_code' WHEN v_sort_var IS NULL and v_search_flag ='DESC' then 'LONG_DESC' ELSE v_sort_var END;
    v_sort_order := CASE WHEN v_sort_order IS NULL THEN 'ASC' ELSE v_sort_order END;
    v_start_num  := CASE WHEN v_start_num IS NULL THEN 1 ELSE v_start_num END;
    v_end_num    := CASE WHEN v_end_num IS NULL THEN 101 ELSE v_end_num END;

    v_search_data         := CASE WHEN v_search_data IS NOT NULL THEN '%'||UPPER(replace(v_search_data,' ','%'))||'%' ELSE v_search_data END;
--    v_description      := CASE WHEN v_description IS NOT NULL THEN '%'||UPPER(replace(v_description,' ','%'))||'%' ELSE v_description END;

 
 if v_search_flag ='CODE' then 
 v_str := 
      'SELECT DISTINCT * FROM (SELECT md.icd10_seq_id||''#''||md.icd_code as search_data,md.icd_code
       FROM tpa_icd10_master_details md
       where  (:v_search_data IS NULL OR upper(md.icd_code) LIKE :v_search_data ))';
    
    v_str := 'SELECT * FROM
      (SELECT A.*, DENSE_RANK() OVER (ORDER BY '||v_sort_var||' '||v_sort_order||',ROWNUM) Q FROM (' ||v_str|| ') A )
       WHERE  Q>= :v_start_num  AND Q<= :v_end_num ';
 
    OPEN v_result_set FOR v_str USING v_search_data, v_search_data, v_start_num, v_end_num;
  
  
  else 
     v_str := 
      'SELECT DISTINCT * FROM (SELECT md.icd10_seq_id||''#''||md.LONG_DESC as search_data,md.LONG_DESC
       FROM tpa_icd10_master_details md
       where  (:v_search_data IS NULL OR upper(md.LONG_DESC) LIKE :v_search_data ))';   
      
    v_str := 'SELECT * FROM
      (SELECT A.*, DENSE_RANK() OVER (ORDER BY '||v_sort_var||' '||v_sort_order||',ROWNUM) Q FROM (' ||v_str|| ') A )
       WHERE  Q>= :v_start_num  AND Q<= :v_end_num ';
   
 
    OPEN v_result_set FOR v_str USING v_search_data, v_search_data , v_start_num, v_end_num;
  
  
  
  end if;   
      
  
END select_pbm_icd_list;
---===========================================================================
PROCEDURE select_pbm_clin_list (
    v_search_mode              IN OUT VARCHAR2,--ID ,NAME
    v_search_data              IN OUT  VARCHAR2,
    v_sort_var                 IN OUT VARCHAR2 ,
    v_sort_order               IN OUT VARCHAR2,
    v_start_num                IN OUT NUMBER  ,
    v_end_num                  IN OUT NUMBER  ,
    v_result_set               OUT SYS_REFCURSOR
  )
  IS
  v_str                      VARCHAR2(2000);
  
  BEGIN

    v_sort_var   := CASE WHEN v_sort_var IS NULL then  'SEARCH_DATA' ELSE v_sort_var END;
    v_sort_order := CASE WHEN v_sort_order IS NULL THEN 'ASC' ELSE v_sort_order END;
    v_start_num  := CASE WHEN v_start_num IS NULL THEN 1 ELSE v_start_num END;
    v_end_num    := CASE WHEN v_end_num IS NULL THEN 101 ELSE v_end_num END;
    v_search_data  := CASE WHEN v_search_data IS NOT NULL THEN UPPER(v_search_data)||'%' ELSE v_search_data END;

 if v_search_mode='ID' THEN
      v_str := 
      'SELECT DISTINCT * FROM (SELECT (md.CLINI_SEQ_ID||''#''||md.clinitian_id) as search_data
       FROM dha_clinicians_list_master md
       where  (:v_search_data IS NULL OR upper(md.clinitian_id) LIKE :v_search_data ))';
       --dbms_output.put_line(v_str);
      elsif v_search_mode='NAME' then
      v_str := 
      'SELECT DISTINCT * FROM (SELECT (md.CLINI_SEQ_ID||''#''||md.professional_name) as search_data
       FROM dha_clinicians_list_master md
       where  (:v_search_data IS NULL OR upper(md.professional_name) LIKE :v_search_data ))';
end if;
      
    
    v_str := 'SELECT * FROM
      (SELECT A.*, DENSE_RANK() OVER (ORDER BY '||v_sort_var||' '||v_sort_order||',ROWNUM) Q FROM (' ||v_str|| ') A )
       WHERE  Q>= :v_start_num  AND Q<= :v_end_num ';
       --dbms_output.put_line(v_str);
 
    OPEN v_result_set FOR v_str USING v_search_data, v_search_data, v_start_num, v_end_num;
  
  
  
END select_pbm_clin_list;


---==================================================================
PROCEDURE check_mdcl_necessity_rules_1(v_seq_id                       IN pat_activity_details.pat_auth_seq_id%TYPE,
                                     v_mode                         IN VARCHAR2,
                                     v_added_by                     IN NUMBER)
IS
CURSOR lmrp_cur(v_activity_code  tpa_ddc_lmrp_master_details.ddc%TYPE)
IS
SELECT TI.ICD_CODES as icd_code,NVL(TI.REVIEW_YN,'N') AS REVIEW_YN
FROM APP.TPA_PHARMACY_MASTER_DETAILS P
JOIN APP.CLINICL_THRPTIC_CLASS_MSTR T ON (P.THERAPTIC_CLASS_ID=T.THERAPTIC_CLASS_ID)
JOIN APP.CLINICL_THRPTIC_ICD_MSTR TI ON (T.THERAPTIC_CLASS_ID=TI.THERAPTIC_CLASS_ID)
WHERE P.activity_code=v_activity_code;


CURSOR review_count_cur(v_activity_code  tpa_ddc_lmrp_master_details.ddc%TYPE)
IS
SELECT count(*)
FROM APP.TPA_PHARMACY_MASTER_DETAILS P
JOIN APP.CLINICL_THRPTIC_CLASS_MSTR T ON (P.THERAPTIC_CLASS_ID=T.THERAPTIC_CLASS_ID)
JOIN APP.CLINICL_THRPTIC_ICD_MSTR TI ON (T.THERAPTIC_CLASS_ID=TI.THERAPTIC_CLASS_ID)
JOIN APP.DIAGNOSYS_DETAILS DD ON (DD.DIAGNOSYS_CODE = TI.ICD_CODES)
WHERE P.activity_code=v_activity_code and ((v_mode='PAT' and  dd.pat_auth_seq_id = v_seq_id) or (v_mode='CLM' and  dd.claim_seq_id = v_seq_id))  
and NVL(TI.REVIEW_YN,'N')='N';

CURSOR ddc_count_cur(v_activity_code  tpa_ddc_lmrp_master_details.ddc%TYPE)
IS
SELECT COUNT(1) FROM TPA_PHARMACY_MASTER_DETAILS tlmd
WHERE tlmd.activity_code=v_activity_code;

CURSOR pat_diag_cur IS
SELECT wm_concat(dd.diagnosys_code) AS icd_codes FROM diagnosys_details dd
WHERE dd.pat_auth_seq_id=v_seq_id;

CURSOR pat_act_cur IS
SELECT pad.code,pad.activity_dtl_seq_id,pad.override_yn FROM pat_activity_details pad
WHERE pad.pat_auth_seq_id=v_seq_id
and pad.activity_type='5' AND pad.code!='S5001';
--AND pad.remarks IS NULL;

CURSOR clm_diag_cur IS
SELECT wm_concat(dd.diagnosys_code) AS icd_codes FROM diagnosys_details dd
WHERE dd.claim_seq_id=v_seq_id;

CURSOR clm_act_cur IS
SELECT pad.code,pad.activity_dtl_seq_id,pad.override_yn FROM pat_activity_details pad
WHERE pad.claim_seq_id=v_seq_id
and pad.activity_type='5' and pad.code !='S5001';
--AND pad.remarks IS NULL;

lmrp_rec                         lmrp_cur%ROWTYPE;
diag_rec                         pat_diag_cur%ROWTYPE;
TYPE v_array IS TABLE OF VARCHAR2(30);
diag_array                v_array:=v_array();
j                        number:=1;
v_exist_count            number;  
ddc_count               number;
v_review_yn             VARCHAR2(10):= 'N';
v_review_count         number:=0;

BEGIN
  

IF v_mode='PAT' THEN
  
  OPEN pat_diag_cur;
  FETCH pat_diag_cur INTO diag_rec;
  CLOSE pat_diag_cur;
  
  for i in (Select column_value as val from table(cast(ttk_mail_pkg.parse(diag_rec.icd_codes,',') as strings))) loop
    diag_array.extend;
    diag_array(j):=i.val;
    j:=j+1;
  end loop;
  
 for act_rec IN   pat_act_cur LOOP  
    v_exist_count:=0;
    v_review_yn  :='N';
    v_review_count:=0;
   IF NVL(act_rec.override_yn,'N')='N' THEN 
    OPEN  ddc_count_cur(act_rec.code);
    FETCH ddc_count_cur INTO ddc_count;
    CLOSE ddc_count_cur;
    
    OPEN  review_count_cur(act_rec.code);
    FETCH review_count_cur INTO v_review_count;
    CLOSE review_count_cur;
   
     IF  ddc_count>0 THEN
      FOR lmrp_rec IN lmrp_cur(act_rec.code) LOOP      
         IF lmrp_rec.icd_code member of diag_array THEN
          v_exist_count:=v_exist_count+1;
          IF lmrp_rec.review_yn = 'Y' AND v_review_yn = 'N' THEN
           v_review_yn := 'Y';
          END IF;
         END IF; 
      END LOOP;     
     END IF;
    IF ddc_count>0 AND v_exist_count=0 THEN
      UPDATE pat_activity_details pad
         SET pad.denial_code                 = case when pad.denial_code like '%MED-IND%' then pad.denial_code else pad.denial_code||';'||'MED-IND'end,
             pad.denial_desc                 = case when pad.denial_code like '%MED-IND%' then pad.denial_desc else pad.denial_desc||';'||'Drug not medically indicated as per standard practice' end,
             pad.remarks                     = case when pad.denial_code like '%MED-IND%' then pad.remarks else pad.denial_desc||';'||'Drug not medically indicated as per standard practice' end,
             pad.tpa_denial_code             = case when pad.tpa_denial_code like '%MED-IND%' then pad.tpa_denial_code else pad.tpa_denial_code||';'||'MED-IND'end,
             pad.tpa_denial_desc             = case when pad.tpa_denial_code like '%MED-IND%' then pad.tpa_denial_desc else pad.tpa_denial_desc||';'||'Drug not medically indicated as per standard practice' end,
             pad.updated_by                  = v_added_by,
             pad.updated_date                = SYSDATE,
             pad.denial_by_rule_proc_dtls    = TRIM(BOTH ';' FROM (pad.denial_by_rule_proc_dtls||';'||CHR(10)||'hosp_pbm_pkg.check_mdcl_necessity_rules_1')),
             pad.denial_by_resons            = TRIM(BOTH ';' FROM (pad.denial_by_resons||';'||CHR(10)||'ICD not matching with DDC.'))
       WHERE pad.activity_dtl_seq_id=act_rec.activity_dtl_seq_id 
        AND pad.activity_dtl_seq_id NOT IN (SELECT pa.activity_dtl_seq_id
                                                      FROM APP.PAT_ACTIVITY_DETAILS PA
                                                      JOIN APP.CLINICL_MAT_ICD_DDC_MSTR MI ON (PA.CODE=MI.DDC_CODE) 
                                                      JOIN APP.TPA_ICD10_MASTER_DETAILS IM ON (IM.ICD_CODE=MI.ICD_CODE)
                                                      JOIN APP.DIAGNOSYS_DETAILS D ON (IM.ICD10_SEQ_ID=D.ICD_CODE_SEQ_ID)
                                                      WHERE PA.PAT_AUTH_SEQ_ID = v_seq_id
                                                      and D.PAT_AUTH_SEQ_ID = v_seq_id
                                                      AND pa.activity_type='5');
    ELSIF ddc_count>0 AND v_exist_count>0 AND v_review_yn='Y' and v_review_count=0 THEN
      UPDATE pat_activity_details pad
         SET pad.denial_code                 = case when pad.denial_code like '%REV-MAN%' then pad.denial_code else pad.denial_code||';'||'REV-MAN'end,
             pad.denial_desc                 = case when pad.denial_code like '%REV-MAN%' then pad.denial_desc else pad.denial_desc||';'||'To be manually reviewed' end,
             pad.remarks                     = case when pad.denial_code like '%REV-MAN%' then pad.remarks else pad.denial_desc||';'||'To be manually reviewed' end,
             pad.tpa_denial_code             = case when pad.tpa_denial_code like '%REV-MAN%' then pad.tpa_denial_code else pad.tpa_denial_code||';'||'REV-MAN'end,
             pad.tpa_denial_desc             = case when pad.tpa_denial_code like '%REV-MAN%' then pad.tpa_denial_desc else pad.tpa_denial_desc||';'||'To be manually reviewed' end,
             pad.updated_by                  = v_added_by,
             pad.updated_date                = SYSDATE,
             pad.denial_by_rule_proc_dtls    = TRIM(BOTH ';' FROM (pad.denial_by_rule_proc_dtls||';'||CHR(10)||'hosp_pbm_pkg.check_mdcl_necessity_rules_1')),
             pad.denial_by_resons            = TRIM(BOTH ';' FROM (pad.denial_by_resons||';'||CHR(10)||'ICD not matching with DDC and under review'))
      WHERE pad.activity_dtl_seq_id=act_rec.activity_dtl_seq_id
      AND pad.activity_dtl_seq_id NOT IN (SELECT pa.activity_dtl_seq_id
                                                      FROM APP.PAT_ACTIVITY_DETAILS PA
                                                      JOIN APP.CLINICL_MAT_ICD_DDC_MSTR MI ON (PA.CODE=MI.DDC_CODE) 
                                                      JOIN APP.TPA_ICD10_MASTER_DETAILS IM ON (IM.ICD_CODE=MI.ICD_CODE)
                                                      JOIN APP.DIAGNOSYS_DETAILS D ON (IM.ICD10_SEQ_ID=D.ICD_CODE_SEQ_ID)
                                                      WHERE PA.PAT_AUTH_SEQ_ID = v_seq_id
                                                      and D.PAT_AUTH_SEQ_ID = v_seq_id
                                                      AND pa.activity_type='5');  
    END IF;
  END IF;  
 END LOOP;
 ELSIF v_mode='CLM' THEN
 
  OPEN clm_diag_cur;
  FETCH clm_diag_cur INTO diag_rec;
  CLOSE clm_diag_cur;
  
  for i in (Select column_value as val from table(cast(ttk_mail_pkg.parse(diag_rec.icd_codes,',') as strings))) loop
    diag_array.extend;
    diag_array(j):=i.val;
    j:=j+1;
  end loop;
  
 for act_rec IN   clm_act_cur LOOP  
    v_exist_count:=0;
    v_review_yn  :='N';
    v_review_count:=0;
   IF NVL(act_rec.override_yn,'N')='N' THEN 
    OPEN  ddc_count_cur(act_rec.code);
    FETCH ddc_count_cur INTO ddc_count;
    CLOSE ddc_count_cur;
    
    OPEN  review_count_cur(act_rec.code);
    FETCH review_count_cur INTO v_review_count;
    CLOSE review_count_cur;
   
     IF  ddc_count>0 THEN
      FOR lmrp_rec IN lmrp_cur(act_rec.code) LOOP      
         IF lmrp_rec.icd_code member of diag_array THEN
          v_exist_count:=v_exist_count+1;
          IF lmrp_rec.review_yn = 'Y' AND v_review_yn = 'N' THEN
           v_review_yn := 'Y';
          END IF;
         END IF; 
      END LOOP;     
     END IF;
    
    IF ddc_count>0 AND v_exist_count=0 THEN
      UPDATE pat_activity_details pad
         SET pad.denial_code                 = case when pad.denial_code like '%MED-IND%' then pad.denial_code else pad.denial_code||';'||'MED-IND'end,
             pad.denial_desc                 = case when pad.denial_code like '%MED-IND%' then pad.denial_desc else pad.denial_desc||';'||'Drug not medically indicated as per standard practice' end,
             pad.remarks                     = case when pad.denial_code like '%MED-IND%' then pad.remarks else pad.denial_desc||';'||'Drug not medically indicated as per standard practice' end,
             pad.tpa_denial_code             = case when pad.tpa_denial_code like '%MED-IND%' then pad.tpa_denial_code else pad.tpa_denial_code||';'||'MED-IND'end,
             pad.tpa_denial_desc             = case when pad.tpa_denial_code like '%MED-IND%' then pad.tpa_denial_desc else pad.tpa_denial_desc||';'||'Drug not medically indicated as per standard practice' end,
             pad.updated_by                  = v_added_by,
             pad.updated_date                = SYSDATE,
             pad.denial_by_rule_proc_dtls    = TRIM(BOTH ';' FROM (pad.denial_by_rule_proc_dtls||';'||CHR(10)||'hosp_pbm_pkg.check_mdcl_necessity_rules_1')),
             pad.denial_by_resons            = TRIM(BOTH ';' FROM (pad.denial_by_resons||';'||CHR(10)||'ICD not matching with DDC.'))
       WHERE pad.activity_dtl_seq_id=act_rec.activity_dtl_seq_id
       AND pad.activity_dtl_seq_id NOT IN (SELECT pa.activity_dtl_seq_id
                                                      FROM APP.PAT_ACTIVITY_DETAILS PA
                                                      JOIN APP.CLINICL_MAT_ICD_DDC_MSTR MI ON (PA.CODE=MI.DDC_CODE) 
                                                      JOIN APP.TPA_ICD10_MASTER_DETAILS IM ON (IM.ICD_CODE=MI.ICD_CODE)
                                                      JOIN APP.DIAGNOSYS_DETAILS D ON (IM.ICD10_SEQ_ID=D.ICD_CODE_SEQ_ID)
                                                      WHERE PA.Claim_Seq_Id = v_seq_id
                                                      and D.Claim_Seq_Id = v_seq_id
                                                      AND pa.activity_type='5') ;
    ELSIF ddc_count>0 AND v_exist_count>0 AND v_review_yn='Y' and v_review_count=0 THEN
      UPDATE pat_activity_details pad
         SET pad.denial_code                 = case when pad.denial_code like '%REV-MAN%' then pad.denial_code else pad.denial_code||';'||'REV-MAN'end,
             pad.denial_desc                 = case when pad.denial_code like '%REV-MAN%' then pad.denial_desc else pad.denial_desc||';'||'To be manually reviewed' end,
             pad.remarks                     = case when pad.denial_code like '%REV-MAN%' then pad.remarks else pad.denial_desc||';'||'To be manually reviewed' end,
             pad.tpa_denial_code             = case when pad.tpa_denial_code like '%REV-MAN%' then pad.tpa_denial_code else pad.tpa_denial_code||';'||'REV-MAN'end,
             pad.tpa_denial_desc             = case when pad.tpa_denial_code like '%REV-MAN%' then pad.tpa_denial_desc else pad.tpa_denial_desc||';'||'To be manually reviewed' end,
             pad.updated_by                  = v_added_by,
             pad.updated_date                = SYSDATE,
             pad.denial_by_rule_proc_dtls    = TRIM(BOTH ';' FROM (pad.denial_by_rule_proc_dtls||';'||CHR(10)||'hosp_pbm_pkg.check_mdcl_necessity_rules_1')),
             pad.denial_by_resons            = TRIM(BOTH ';' FROM (pad.denial_by_resons||';'||CHR(10)||'ICD not matching with DDC and under review'))
      WHERE pad.activity_dtl_seq_id=act_rec.activity_dtl_seq_id
      AND pad.activity_dtl_seq_id NOT IN (SELECT pa.activity_dtl_seq_id
                                                      FROM APP.PAT_ACTIVITY_DETAILS PA
                                                      JOIN APP.CLINICL_MAT_ICD_DDC_MSTR MI ON (PA.CODE=MI.DDC_CODE) 
                                                      JOIN APP.TPA_ICD10_MASTER_DETAILS IM ON (IM.ICD_CODE=MI.ICD_CODE)
                                                      JOIN APP.DIAGNOSYS_DETAILS D ON (IM.ICD10_SEQ_ID=D.ICD_CODE_SEQ_ID)
                                                      WHERE PA.Claim_Seq_Id = v_seq_id
                                                      and D.Claim_Seq_Id = v_seq_id
                                                      AND pa.activity_type='5') ;  
    END IF;
  END IF; 
 END LOOP;
 END IF;
  
END check_mdcl_necessity_rules_1;
--====================================================================
PROCEDURE check_therapeutic_rule_2(v_seq_id   IN pat_authorization_details.pat_auth_seq_id%TYPE,
                                 v_mode     IN VARCHAR2,
                                 v_added_by IN NUMBER) IS

CURSOR cur_pat_cur IS
 WITH PAT AS
  (SELECT a.activity_dtl_seq_id,ROW_NUMBER() OVER (PARTITION BY m.atc_code,a.start_date ORDER BY a.unit_price) AS min_sal_asc_seq_id
   FROM pat_activity_details a 
   JOIN TPA_PHARMACY_MASTER_DETAILS m ON (a.code=m.activity_code) 
   WHERE a.pat_auth_seq_id=v_seq_id AND a.code!='S5001'
   AND a.activity_type='5'
   --AND a.denial_code IS NULL 
   AND nvl(a.unit_price,0)>0 and m.atc_code is not null)
 SELECT activity_dtl_seq_id
 FROM PAT P
 WHERE P.min_sal_asc_seq_id != 1;
 
CURSOR cur_clm_cur IS
 WITH CLM AS
  (SELECT a.activity_dtl_seq_id,ROW_NUMBER() OVER (PARTITION BY m.atc_code,a.start_date ORDER BY a.unit_price) AS min_sal_asc_seq_id
   FROM pat_activity_details a 
   JOIN TPA_PHARMACY_MASTER_DETAILS m ON (a.code=m.activity_code) 
   WHERE a.claim_seq_id=v_seq_id AND a.code!='S5001'
   AND a.activity_type='5'
   --AND a.denial_code IS NULL 
   AND nvl(a.unit_price,0)>0 and m.atc_code is not null)
 SELECT activity_dtl_seq_id
 FROM CLM P
 WHERE P.min_sal_asc_seq_id != 1;

 TYPE typ_tbl IS TABLE OF cur_pat_cur%ROWTYPE INDEX BY PLS_INTEGER;
 pat_rec      typ_tbl;
 clm_rec      typ_tbl;

BEGIN

  IF v_mode = 'PAT' THEN
   
      OPEN  cur_pat_cur;
      FETCH cur_pat_cur BULK COLLECT INTO pat_rec;
      CLOSE cur_pat_cur;
      
      FORALL i IN 1..pat_rec.COUNT
        UPDATE pat_activity_details pad
           SET pad.denial_code                 = case when pad.denial_code is null then 'AUTH-007' else case when pad.denial_code like '%'||'AUTH-007'||'%' then pad.denial_code else pad.denial_code||';'||'AUTH-007' end end,
               pad.denial_desc                 = case when pad.denial_desc is null then 'Drug duplicate therapy' else case when pad.denial_code like '%'||'AUTH-007'||'%' then pad.denial_desc else pad.denial_desc||';'||'Drug duplicate therapy' end end,
               pad.remarks                     = case when pad.remarks is null then 'Drug duplicate therapy' else case when pad.denial_code like '%'||'AUTH-007'||'%' then pad.denial_desc else pad.denial_desc||';'||'Drug duplicate therapy' end end,
               pad.tpa_denial_code             = case when pad.tpa_denial_code is null then 'AUTH-007' else case when pad.tpa_denial_code like '%'||'AUTH-007'||'%' then pad.tpa_denial_code else pad.tpa_denial_code||';'||'AUTH-007' end end,
               pad.tpa_denial_desc             = case when pad.tpa_denial_desc is null then 'Drug duplicate therapy' else case when pad.tpa_denial_code like '%'||'AUTH-007'||'%' then pad.tpa_denial_desc else pad.tpa_denial_desc||';'||'Drug duplicate therapy' end end,
               pad.updated_by                  = v_added_by,
               --pad.allowed_amount              = 0,
               --pad.approved_amount             = 0,
               pad.updated_date                = SYSDATE,
               pad.denial_by_rule_proc_dtls    = TRIM(BOTH ';' FROM (pad.denial_by_rule_proc_dtls||';'||CHR(10)||'hosp_pbm_pkg.check_therapeutic_rule_2')),
               pad.denial_by_resons            = TRIM(BOTH ';' FROM (pad.denial_by_resons||';'||CHR(10)||'Drug duplicate therapy.'))
         WHERE pad.pat_auth_seq_id = v_seq_id 
           AND nvl(pad.override_yn,'N')='N'
           AND pad.activity_dtl_seq_id = pat_rec(i).activity_dtl_seq_id ;
  ELSE         
      
      OPEN  cur_clm_cur;
      FETCH cur_clm_cur BULK COLLECT INTO clm_rec;
      CLOSE cur_clm_cur;
      
      FORALL i IN 1..clm_rec.COUNT
        UPDATE pat_activity_details pad
           SET pad.denial_code                 = case when pad.denial_code is null then 'AUTH-007' else case when pad.denial_code like '%'||'AUTH-007'||'%' then pad.denial_code else pad.denial_code||';'||'AUTH-007' end end,
               pad.denial_desc                 = case when pad.denial_desc is null then 'Drug duplicate therapy' else case when pad.denial_code like '%'||'AUTH-007'||'%' then pad.denial_desc else pad.denial_desc||';'||'Drug duplicate therapy' end end,
               pad.remarks                     = case when pad.remarks is null then 'Drug duplicate therapy' else case when pad.denial_code like '%'||'AUTH-007'||'%' then pad.denial_desc else pad.denial_desc||';'||'Drug duplicate therapy' end end,
               pad.tpa_denial_code             = case when pad.tpa_denial_code is null then 'AUTH-007' else case when pad.tpa_denial_code like '%'||'AUTH-007'||'%' then pad.tpa_denial_code else pad.tpa_denial_code||';'||'AUTH-007' end end,
               pad.tpa_denial_desc             = case when pad.tpa_denial_desc is null then 'Drug duplicate therapy' else case when pad.tpa_denial_code like '%'||'AUTH-007'||'%' then pad.tpa_denial_desc else pad.tpa_denial_desc||';'||'Drug duplicate therapy' end end,
               pad.updated_by                  = v_added_by,
               --pad.allowed_amount              = 0,
               --pad.approved_amount             = 0,
               pad.updated_date                = SYSDATE,
               pad.denial_by_rule_proc_dtls    = TRIM(BOTH ';' FROM (pad.denial_by_rule_proc_dtls||';'||CHR(10)||'hosp_pbm_pkg.check_therapeutic_rule_2')),
               pad.denial_by_resons            = TRIM(BOTH ';' FROM (pad.denial_by_resons||';'||CHR(10)||'Drug duplicate therapy.'))
         WHERE pad.claim_seq_id = v_seq_id 
           AND nvl(pad.override_yn,'N')='N'
           AND pad.activity_dtl_seq_id = clm_rec(i).activity_dtl_seq_id ;
  END IF;
END check_therapeutic_rule_2;
---==================================================================================
PROCEDURE check_ci_icd_ddc_rules_3(v_seq_id                       IN pat_activity_details.pat_auth_seq_id%TYPE,
                               v_mode                         IN VARCHAR2,
                               v_added_by                     IN NUMBER)
IS

   CURSOR ci_pat_cur(v_activity_code  tpa_ddc_lmrp_master_details.ddc%TYPE)
    IS
    SELECT COUNT(1)
    FROM APP.TPA_PHARMACY_MASTER_DETAILS PM
    JOIN APP.CLINICL_CI_GEN_CODE_MSTR GC ON (PM.CI_GENRIC_CODE=GC.GENRIC_CODE)
    JOIN APP.CLINICL_CI_DISEASE_MSTR DS ON (GC.GENRIC_CODE=DS.GENRIC_CODE)
    JOIN APP.CLINICL_CI_ICD_MSTR IM ON (DS.CI_DISEASE_CODE=IM.CI_DISEASE_CODE)
    JOIN APP.TPA_ICD10_MASTER_DETAILS CM ON (IM.ICD_CODES=CM.ICD_CODE)
    JOIN APP.DIAGNOSYS_DETAILS D ON (D.ICD_CODE_SEQ_ID=CM.ICD10_SEQ_ID)
    WHERE PM.ACTIVITY_CODE = v_activity_code
      and D.PAT_AUTH_SEQ_ID=v_seq_id;

   CURSOR ci_clm_cur(v_activity_code  tpa_ddc_lmrp_master_details.ddc%TYPE)
    IS
    SELECT COUNT(1)
    FROM APP.TPA_PHARMACY_MASTER_DETAILS PM
    JOIN APP.CLINICL_CI_GEN_CODE_MSTR GC ON (PM.CI_GENRIC_CODE=GC.GENRIC_CODE)
    JOIN APP.CLINICL_CI_DISEASE_MSTR DS ON (GC.GENRIC_CODE=DS.GENRIC_CODE)
    JOIN APP.CLINICL_CI_ICD_MSTR IM ON (DS.CI_DISEASE_CODE=IM.CI_DISEASE_CODE)
    JOIN APP.TPA_ICD10_MASTER_DETAILS CM ON (IM.ICD_CODES=CM.ICD_CODE)
    JOIN APP.DIAGNOSYS_DETAILS D ON (D.ICD_CODE_SEQ_ID=CM.ICD10_SEQ_ID)
    WHERE PM.ACTIVITY_CODE = v_activity_code
      and D.CLAIM_SEQ_ID=v_seq_id;
      
      
    CURSOR pat_act_cur IS
    SELECT pad.code,pad.activity_dtl_seq_id,pad.override_yn 
    FROM pat_activity_details pad
    WHERE pad.pat_auth_seq_id=v_seq_id 
    and pad.activity_type='5';


    CURSOR clm_act_cur IS
    SELECT pad.code,pad.activity_dtl_seq_id,pad.override_yn 
    FROM pat_activity_details pad
    WHERE pad.claim_seq_id=v_seq_id 
    and pad.activity_type='5';


v_pat_ci_cnt            NUMBER;
v_clm_ci_cnt            NUMBER;


BEGIN
  
IF v_mode='PAT' THEN
  
   
 for act_rec IN   pat_act_cur LOOP  
    OPEN  ci_pat_cur(act_rec.code);
    FETCH ci_pat_cur INTO v_pat_ci_cnt;
    CLOSE ci_pat_cur;
   
    IF v_pat_ci_cnt>0 THEN
      UPDATE pat_activity_details pad
         SET pad.denial_code                 = case when pad.denial_code like '%SURC-004%' then pad.denial_code else pad.denial_code||';'||'SURC-004'end,
             pad.denial_desc                 = case when pad.denial_code like '%SURC-004%' then pad.denial_desc else pad.denial_desc||';'||'Severe drug - diaganosis contraindication' end,
             pad.remarks                     = case when pad.denial_code like '%SURC-004%' then pad.remarks else pad.denial_desc||';'||'Severe drug - diaganosis contraindication' end,
             pad.tpa_denial_code             = case when pad.tpa_denial_code like '%SURC-004%' then pad.tpa_denial_code else pad.tpa_denial_code||';'||'SURC-004'end,
             pad.tpa_denial_desc             = case when pad.tpa_denial_code like '%SURC-004%' then pad.tpa_denial_desc else pad.tpa_denial_desc||';'||'Severe drug - diaganosis contraindication' end,
             pad.updated_by                  = v_added_by,
             pad.updated_date                = SYSDATE,
             pad.denial_by_rule_proc_dtls    = TRIM(BOTH ';' FROM (pad.denial_by_rule_proc_dtls||';'||CHR(10)||'hosp_pbm_pkg.check_ci_icd_ddc_rules_3')),
             pad.denial_by_resons            = TRIM(BOTH ';' FROM (pad.denial_by_resons||';'||CHR(10)||'Severe drug - diaganosis contraindication.'))
      WHERE pad.activity_dtl_seq_id=act_rec.activity_dtl_seq_id
         AND nvl(pad.override_yn,'N')='N';
    END IF;
 END LOOP;
 ELSIF v_mode='CLM' THEN
 for act_rec IN   clm_act_cur LOOP  
    OPEN  ci_clm_cur(act_rec.code);
    FETCH ci_clm_cur INTO v_clm_ci_cnt;
    CLOSE ci_clm_cur;
   
    IF v_clm_ci_cnt>0 THEN
      UPDATE pat_activity_details pad
         SET pad.denial_code                 = case when pad.denial_code like '%SURC-004%' then pad.denial_code else pad.denial_code||';'||'SURC-004'end,
             pad.denial_desc                 = case when pad.denial_code like '%SURC-004%' then pad.denial_desc else pad.denial_desc||';'||'Severe drug - diaganosis contraindication' end,
             pad.remarks                     = case when pad.denial_code like '%SURC-004%' then pad.remarks else pad.denial_desc||';'||'Severe drug - diaganosis contraindication' end,
             pad.tpa_denial_code             = case when pad.tpa_denial_code like '%SURC-004%' then pad.tpa_denial_code else pad.tpa_denial_code||';'||'SURC-004'end,
             pad.tpa_denial_desc             = case when pad.tpa_denial_code like '%SURC-004%' then pad.tpa_denial_desc else pad.tpa_denial_desc||';'||'Severe drug - diaganosis contraindication' end,
             pad.updated_by                  = v_added_by,
             pad.updated_date                = SYSDATE,
             pad.denial_by_rule_proc_dtls    = TRIM(BOTH ';' FROM (pad.denial_by_rule_proc_dtls||';'||CHR(10)||'hosp_pbm_pkg.check_ci_icd_ddc_rules_3')),
             pad.denial_by_resons            = TRIM(BOTH ';' FROM (pad.denial_by_resons||';'||CHR(10)||'Severe drug - diaganosis contraindication.'))
      WHERE pad.activity_dtl_seq_id=act_rec.activity_dtl_seq_id
        AND nvl(pad.override_yn,'N')='N';
    END IF;
 END LOOP;
 END IF;
  
END check_ci_icd_ddc_rules_3;        
---------------------------------------------------------------------------------------------------------------------------------
PROCEDURE check_ci_ddc_ddc_rules_3(v_seq_id                       IN pat_activity_details.pat_auth_seq_id%TYPE,
                                   v_mode                         IN VARCHAR2,
                                   v_added_by                     IN NUMBER)
 IS                              
 CURSOR cur_pat(v_ddc_code     VARCHAR2)
 IS
 SELECT a.activity_dtl_seq_id
  FROM APP.PAT_ACTIVITY_DETAILS a               
    WHERE  EXISTS (SELECT pa.code
    FROM APP.PAT_ACTIVITY_DETAILS PA 
    JOIN APP.CLINICL_CI_DDC_DDC_MSTR D ON (PA.CODE = D.PAT_CLM_DDC_CODE)
    --JOIN APP.CLINICL_CI_DDC_DDC_MSTR DI ON (PA.CODE = DI.CI_DDC_CODE)
    where pat_auth_seq_id=v_seq_id
    and d.ci_ddc_code=a.code
    and pa.code = v_ddc_code)  
    and pat_auth_seq_id=v_seq_id;
    
 CURSOR cur_clm(v_ddc_code     VARCHAR2)
   IS
   SELECT a.activity_dtl_seq_id
    FROM APP.PAT_ACTIVITY_DETAILS a               
      WHERE  EXISTS (SELECT pa.code
      FROM APP.PAT_ACTIVITY_DETAILS PA 
      JOIN APP.CLINICL_CI_DDC_DDC_MSTR D ON (PA.CODE = D.PAT_CLM_DDC_CODE)
      --JOIN APP.CLINICL_CI_DDC_DDC_MSTR DI ON (PA.CODE = DI.CI_DDC_CODE)
      where claim_seq_id=v_seq_id
      and d.ci_ddc_code=a.code
      and pa.code = v_ddc_code)  
      and claim_seq_id=v_seq_id;  
      
    v_pat_activity_dtl_seq_id                            NUMBER;
    v_clm_activity_dtl_seq_id                            NUMBER;  
      
BEGIN
  IF v_mode='PAT' THEN
    FOR i IN (SELECT pad.code,pad.activity_dtl_seq_id,pad.override_yn 
              FROM pat_activity_details pad
              WHERE pad.pat_auth_seq_id=v_seq_id 
              AND pad.activity_type='5'          
              ) LOOP
       
       v_pat_activity_dtl_seq_id := 0;
       OPEN  cur_pat(i.code);
       FETCH cur_pat INTO v_pat_activity_dtl_seq_id; 
       CLOSE cur_pat;
      
      IF NVL(v_pat_activity_dtl_seq_id,0) > 0 THEN
        UPDATE pat_activity_details pad
           SET pad.denial_code                 = case when pad.denial_code like '%SURC-001%' then pad.denial_code else pad.denial_code||';'||'SURC-001'end,
               pad.denial_desc                 = case when pad.denial_code like '%SURC-001%' then pad.denial_desc else pad.denial_desc||';'||'Severe drug - drug interaction' end,
               pad.remarks                     = case when pad.denial_code like '%SURC-001%' then pad.remarks else pad.denial_desc||';'||'Severe drug - drug interaction' end,
               pad.tpa_denial_code             = case when pad.tpa_denial_code like '%SURC-001%' then pad.tpa_denial_code else pad.tpa_denial_code||';'||'SURC-001'end,
               pad.tpa_denial_desc             = case when pad.tpa_denial_code like '%SURC-001%' then pad.tpa_denial_desc else pad.tpa_denial_desc||';'||'Severe drug - drug interaction' end,
               pad.updated_by                  = v_added_by,
               pad.updated_date                = SYSDATE,
               pad.denial_by_rule_proc_dtls    = TRIM(BOTH ';' FROM (pad.denial_by_rule_proc_dtls||';'||CHR(10)||'hosp_pbm_pkg.check_ci_ddc_ddc_rules_3.')),
               pad.denial_by_resons            = TRIM(BOTH ';' FROM (pad.denial_by_resons||';'||CHR(10)||'Severe drug - drug interaction.'))
          WHERE pad.activity_dtl_seq_id IN (v_pat_activity_dtl_seq_id,i.activity_dtl_seq_id)
            AND nvl(pad.override_yn,'N')='N';
      END IF;
    END LOOP;
  ELSE
    FOR i IN (SELECT pad.code,pad.activity_dtl_seq_id,pad.override_yn 
              FROM pat_activity_details pad
              WHERE pad.claim_seq_id=v_seq_id 
              AND pad.activity_type='5'          
              ) LOOP
       
       v_clm_activity_dtl_seq_id := 0;
       OPEN  cur_clm(i.code);
       FETCH cur_clm INTO v_clm_activity_dtl_seq_id; 
       CLOSE cur_clm;
      
      IF NVL(v_clm_activity_dtl_seq_id,0) > 0 THEN
        UPDATE pat_activity_details pad
           SET pad.denial_code                 = case when pad.denial_code like '%SURC-001%' then pad.denial_code else pad.denial_code||';'||'SURC-001'end,
               pad.denial_desc                 = case when pad.denial_code like '%SURC-001%' then pad.denial_desc else pad.denial_desc||';'||'Severe drug - drug interaction' end,
               pad.remarks                     = case when pad.denial_code like '%SURC-001%' then pad.remarks else pad.denial_desc||';'||'Severe drug - drug interaction' end,
               pad.tpa_denial_code             = case when pad.tpa_denial_code like '%SURC-001%' then pad.tpa_denial_code else pad.tpa_denial_code||';'||'SURC-001'end,
               pad.tpa_denial_desc             = case when pad.tpa_denial_code like '%SURC-001%' then pad.tpa_denial_desc else pad.tpa_denial_desc||';'||'Severe drug - drug interaction' end,
               pad.updated_by                  = v_added_by,
               pad.updated_date                = SYSDATE,
               pad.denial_by_rule_proc_dtls    = TRIM(BOTH ';' FROM (pad.denial_by_rule_proc_dtls||';'||CHR(10)||'hosp_pbm_pkg.check_ci_ddc_ddc_rules_3.')),
               pad.denial_by_resons            = TRIM(BOTH ';' FROM (pad.denial_by_resons||';'||CHR(10)||'Severe drug - drug interaction.'))
          WHERE pad.activity_dtl_seq_id IN (v_clm_activity_dtl_seq_id,i.activity_dtl_seq_id)
            AND nvl(pad.override_yn,'N')='N';
      END IF;
    END LOOP;
  END IF;
END check_ci_ddc_ddc_rules_3;
------------------------------------------------------------------------------------------------------
PROCEDURE check_ci_ddc_ddc_generic(v_seq_id                       IN pat_activity_details.pat_auth_seq_id%TYPE,
                                   v_mode                         IN VARCHAR2,
                                   v_added_by                     IN NUMBER) is 
 
  CURSOR pat_act_cur IS
    SELECT pad.code, pad.activity_dtl_seq_id,pad.override_yn
      FROM pat_activity_details pad
     WHERE pad.pat_auth_seq_id = v_seq_id
     ORDER BY pad.activity_dtl_seq_id;

  CURSOR clm_act_cur IS
    SELECT pad.code, pad.activity_dtl_seq_id,pad.override_yn
      FROM pat_activity_details pad
     WHERE pad.claim_seq_id = v_seq_id
     ORDER BY pad.activity_dtl_seq_id;



  CURSOR generic_code_cur(v_act_code IN tpa_activity_master_details.activity_code%TYPE) IS
    SELECT m.common_gen1,m.common_gen2
      FROM app.tpa_pharmacy_master_details  md
      join app.ci_ddc_ddc_generic_mstr m on (md.ci_genric_code=m.common_gen1)
     WHERE md.activity_code = trim(v_act_code);

  CURSOR generic_count_cur(v_act_code IN tpa_activity_master_details.activity_code%TYPE) IS
    SELECT count(1)
      FROM app.tpa_pharmacy_master_details  md
      join app.ci_ddc_ddc_generic_mstr m on (md.ci_genric_code=m.common_gen1)
     WHERE md.activity_code = trim(v_act_code);
   
  cursor pat_get_sec_gen_cur(ci_2nd_gen_code ci_ddc_ddc_generic_mstr.common_gen2%type) is 
  select a.activity_dtl_seq_id,a.code from pat_activity_details a 
  join app.tpa_pharmacy_master_details md on (a.code=md.activity_code)
  where md.ci_genric_code=ci_2nd_gen_code and a.pat_auth_seq_id=v_seq_id;

  cursor clm_get_sec_gen_cur(ci_2nd_gen_code ci_ddc_ddc_generic_mstr.common_gen2%type) is 
  select a.activity_dtl_seq_id,a.code from pat_activity_details a 
  join app.tpa_pharmacy_master_details md on (a.code=md.activity_code)
  where md.ci_genric_code=ci_2nd_gen_code and a.claim_seq_id=v_seq_id;    

  v_count           number;
BEGIN

 
  IF v_mode = 'PAT' THEN
  
    FOR act_rec in (SELECT pad.code,pad.activity_dtl_seq_id,pad.override_yn 
              FROM pat_activity_details pad
              WHERE pad.pat_auth_seq_id=v_seq_id 
              AND pad.activity_type='5') LOOP
      
      --IF nvl(act_rec.override_yn,'N')='N' THEN
        OPEN generic_count_cur(act_rec.code);
        FETCH generic_count_cur INTO v_count;
        CLOSE generic_count_cur;
      
        IF v_count > 0 THEN
                            
            FOR i in generic_code_cur(act_rec.code) LOOP
               for j in pat_get_sec_gen_cur (i.common_gen2) loop
                  UPDATE pat_activity_details pad
                   SET pad.denial_code                 = case when pad.denial_code like '%SURC-001%' then pad.denial_code else pad.denial_code||';'||'SURC-001'end,
                       pad.denial_desc                 = case when pad.denial_code like '%SURC-001%' then pad.denial_desc else pad.denial_desc||';'||'Drug '||j.code||'has Severe interactions with drug '||act_rec.code end,
                       pad.remarks                     = case when pad.denial_code like '%SURC-001%' then pad.remarks else pad.denial_desc||';'||'Drug '||j.code||'has Severe interactions with drug '||act_rec.code end,
                       pad.tpa_denial_code             = case when pad.tpa_denial_code like '%SURC-001%' then pad.tpa_denial_code else pad.tpa_denial_code||';'||'SURC-001'end,
                       pad.tpa_denial_desc             = case when pad.tpa_denial_code like '%SURC-001%' then pad.tpa_denial_desc else pad.tpa_denial_desc||';'||'Drug '||j.code||'has Severe interactions with drug '||act_rec.code end,
                       pad.updated_by                  = v_added_by,
                       pad.updated_date                = SYSDATE,
                       pad.denial_by_rule_proc_dtls    = TRIM(BOTH ';' FROM (pad.denial_by_rule_proc_dtls||';'||CHR(10)||'hosp_pbm_pkg.check_ci_ddc_ddc_generic.')),
                       pad.denial_by_resons            = TRIM(BOTH ';' FROM (pad.denial_by_resons||';'||CHR(10)||'Severe drug - drug interaction.'))
                  WHERE pad.activity_dtl_seq_id = j.activity_dtl_seq_id AND nvl(pad.override_yn,'N')='N';
               end loop;
              
            END LOOP;
          END IF;
       --END IF;
      END LOOP;
 ELSIF v_mode = 'CLM' THEN
   FOR act_rec in (SELECT pad.code,pad.activity_dtl_seq_id,pad.override_yn 
              FROM pat_activity_details pad
              WHERE pad.claim_seq_id=v_seq_id 
              AND pad.activity_type='5') LOOP
              
              
      --IF nvl(act_rec.override_yn,'N')='N' THEN
        OPEN generic_count_cur(act_rec.code);
        FETCH generic_count_cur INTO v_count;
        CLOSE generic_count_cur;
      
        IF v_count > 0 THEN
                            
            FOR i in generic_code_cur(act_rec.code) LOOP
               for j in clm_get_sec_gen_cur (i.common_gen2) loop
                  UPDATE pat_activity_details pad
                   SET pad.denial_code                 = case when pad.denial_code like '%SURC-001%' then pad.denial_code else pad.denial_code||';'||'SURC-001'end,
                       pad.denial_desc                 = case when pad.denial_code like '%SURC-001%' then pad.denial_desc else pad.denial_desc||';'||'Drug '||j.code||'has Severe interactions with drug '||act_rec.code end,
                       pad.remarks                     = case when pad.denial_code like '%SURC-001%' then pad.remarks else pad.denial_desc||';'||'Drug '||j.code||'has Severe interactions with drug '||act_rec.code end,
                       pad.tpa_denial_code             = case when pad.tpa_denial_code like '%SURC-001%' then pad.tpa_denial_code else pad.tpa_denial_code||';'||'SURC-001'end,
                       pad.tpa_denial_desc             = case when pad.tpa_denial_code like '%SURC-001%' then pad.tpa_denial_desc else pad.tpa_denial_desc||';'||'Drug '||j.code||'has Severe interactions with drug '||act_rec.code end,
                       pad.updated_by                  = v_added_by,
                       pad.updated_date                = SYSDATE,
                       pad.denial_by_rule_proc_dtls    = TRIM(BOTH ';' FROM (pad.denial_by_rule_proc_dtls||';'||CHR(10)||'hosp_pbm_pkg.check_ci_ddc_ddc_generic.')),
                       pad.denial_by_resons            = TRIM(BOTH ';' FROM (pad.denial_by_resons||';'||CHR(10)||'Severe drug - drug interaction.'))
                  WHERE pad.activity_dtl_seq_id = j.activity_dtl_seq_id AND nvl(pad.override_yn,'N')='N';
               end loop;
              
            END LOOP;
          END IF;
       --END IF;
      END LOOP;
  END IF;

END check_ci_ddc_ddc_generic;                               
---------------------------------------------------------------------------------------------------------------------------------                               
PROCEDURE check_age_band_rule_4(v_seq_id                     IN pat_activity_details.pat_auth_seq_id%TYPE,
                              v_mode                         IN VARCHAR2,
                              v_added_by                     IN NUMBER)
IS

 CURSOR cur_ddc_age_allow_yn(V_ACTIVITY_CODE VARCHAR2,v_mem_age    NUMBER) IS
   SELECT C.Activity_Code,M.AGE_FROM,M.AGE_TO,NVL(FLAGS,'Y') AS ALLOW_YN
    FROM APP.CLINICL_AGE_BAND_MSTR M 
    JOIN (
    WITH C1 AS
     (select t.Activity_Code,
             T.AGE_0_1,
             T.AGE_2_6,
             T.AGE_7_12,
             T.AGE_13_18,
             T.AGE_19_150
        from APP.TPA_PHARMACY_MASTER_DETAILS t
       WHERE T.ACTIVITY_CODE = V_ACTIVITY_CODE)
    SELECT *
      FROM C1
      UNPIVOT(FLAGS FOR AGE_BAND IN(AGE_0_1 AS '0-1',
                                            AGE_2_6 AS '2-6',
                                            AGE_7_12 AS '7-12',
                                            AGE_13_18 AS '13-18',
                                            AGE_19_150 AS '19-150'))) C ON (C.AGE_BAND = M.AGE_BAND)
    WHERE v_mem_age BETWEEN M.AGE_FROM AND M.AGE_TO;

  rec_ddc_age_allow_yn             cur_ddc_age_allow_yn%ROWTYPE;   


BEGIN
  
  IF v_mode='PAT' THEN
     FOR i IN (SELECT PA.ACTIVITY_DTL_SEQ_ID,PA.CODE,M.MEM_AGE
               FROM APP.PAT_ACTIVITY_DETAILS PA
               JOIN APP.PAT_AUTHORIZATION_DETAILS P ON (PA.PAT_AUTH_SEQ_ID=P.PAT_AUTH_SEQ_ID)
               JOIN APP.TPA_ENR_POLICY_MEMBER M ON (P.MEMBER_SEQ_ID=M.MEMBER_SEQ_ID)
               WHERE PA.PAT_AUTH_SEQ_ID = v_seq_id
                 and pa.activity_type='5' and pa.code!='S5001')
       LOOP
         
        OPEN  cur_ddc_age_allow_yn(I.CODE,I.MEM_AGE);
        FETCH cur_ddc_age_allow_yn INTO rec_ddc_age_allow_yn;
        CLOSE cur_ddc_age_allow_yn;
        
        IF rec_ddc_age_allow_yn.allow_yn = 'N' THEN
         UPDATE pat_activity_details pad
            SET pad.denial_code                 = case when pad.denial_code like '%AGE-IND%' then pad.denial_code else pad.denial_code||';'||'AGE-IND'end,
                pad.denial_desc                 = case when pad.denial_code like '%AGE-IND%' then pad.denial_desc else pad.denial_desc||';'||'Drug inconsistent with the patient''s given Age' end,
                pad.remarks                     = case when pad.denial_code like '%AGE-IND%' then pad.remarks else pad.denial_desc||';'||'Drug inconsistent with the patient''s given Age' end,
                pad.tpa_denial_code             = case when pad.tpa_denial_code like '%AGE-IND%' then pad.tpa_denial_code else pad.tpa_denial_code||';'||'AGE-IND'end,
                pad.tpa_denial_desc             = case when pad.tpa_denial_code like '%AGE-IND%' then pad.tpa_denial_desc else pad.tpa_denial_desc||';'||'Drug inconsistent with the patient''s given Age' end,
                pad.updated_by                  = v_added_by,
                pad.updated_date                = SYSDATE,
                pad.denial_by_rule_proc_dtls    = TRIM(BOTH ';' FROM (pad.denial_by_rule_proc_dtls||';'||CHR(10)||'hosp_pbm_pkg.check_age_band_rule_4.')),
                pad.denial_by_resons            = TRIM(BOTH ';' FROM (pad.denial_by_resons||';'||CHR(10)||'Drug not allowed for this age band.'))
          WHERE pad.activity_dtl_seq_id=i.activity_dtl_seq_id
            AND nvl(pad.override_yn,'N')='N'; 
        END IF;
        
     END LOOP;
  ELSE
    FOR i IN (SELECT PA.ACTIVITY_DTL_SEQ_ID,PA.CODE,M.MEM_AGE
               FROM APP.PAT_ACTIVITY_DETAILS PA
               JOIN APP.CLM_AUTHORIZATION_DETAILS C ON (PA.CLAIM_SEQ_ID=C.CLAIM_SEQ_ID)
               JOIN APP.TPA_ENR_POLICY_MEMBER M ON (C.MEMBER_SEQ_ID=M.MEMBER_SEQ_ID)
               WHERE PA.CLAIM_SEQ_ID = v_seq_id
               and pa.activity_type='5' AND pa.code!='S5001')
       LOOP
         
        OPEN  cur_ddc_age_allow_yn(I.CODE,I.MEM_AGE);
        FETCH cur_ddc_age_allow_yn INTO rec_ddc_age_allow_yn;
        CLOSE cur_ddc_age_allow_yn;
        
        IF rec_ddc_age_allow_yn.allow_yn = 'N' THEN
        UPDATE pat_activity_details pad
            SET pad.denial_code                 = case when pad.denial_code like '%AGE-IND%' then pad.denial_code else pad.denial_code||';'||'AGE-IND'end,
                pad.denial_desc                 = case when pad.denial_code like '%AGE-IND%' then pad.denial_desc else pad.denial_desc||';'||'Drug inconsistent with the patient''s given Age' end,
                pad.remarks                     = case when pad.denial_code like '%AGE-IND%' then pad.remarks else pad.denial_desc||';'||'Drug inconsistent with the patient''s given Age' end,
                pad.tpa_denial_code             = case when pad.tpa_denial_code like '%AGE-IND%' then pad.tpa_denial_code else pad.tpa_denial_code||';'||'AGE-IND'end,
                pad.tpa_denial_desc             = case when pad.tpa_denial_code like '%AGE-IND%' then pad.tpa_denial_desc else pad.tpa_denial_desc||';'||'Drug inconsistent with the patient''s given Age' end,
                pad.updated_by                  = v_added_by,
                pad.updated_date                = SYSDATE,
                pad.denial_by_rule_proc_dtls    = TRIM(BOTH ';' FROM (pad.denial_by_rule_proc_dtls||';'||CHR(10)||'hosp_pbm_pkg.check_age_band_rule_4.')),
                pad.denial_by_resons            = TRIM(BOTH ';' FROM (pad.denial_by_resons||';'||CHR(10)||'Drug not allowed for this age band.'))
          WHERE pad.activity_dtl_seq_id=i.activity_dtl_seq_id
            AND nvl(pad.override_yn,'N')='N';  
        END IF;
        
     END LOOP;
  END IF;
END check_age_band_rule_4;
---=========================================================================
PROCEDURE check_gender_rule_5(v_seq_id   IN pat_authorization_details.pat_auth_seq_id%TYPE,
                            v_mode     IN VARCHAR2,
                            v_added_by IN NUMBER) IS

  
CURSOR pat_ddc_cur(v_activity_dtl_seq_id  pat_activity_details.activity_dtl_seq_id%type) IS 
select a.gender from tpa_pharmacy_master_details a join pat_activity_details b on (a.act_mas_dtl_seq_id = b.activity_seq_id) 
where b.activity_dtl_seq_id=v_activity_dtl_seq_id and b.pat_auth_seq_id=v_seq_id;


CURSOR clm_ddc_cur(v_activity_dtl_seq_id  pat_activity_details.activity_dtl_seq_id%type) IS 
select a.gender from tpa_pharmacy_master_details a join pat_activity_details b on (a.act_mas_dtl_seq_id = b.activity_seq_id) 
where b.activity_dtl_seq_id=v_activity_dtl_seq_id and b.claim_seq_id=v_seq_id;


CURSOR pat_gender_cur is select decode(m.gender_general_type_id,'FEM','FEMALE','MAL','MALE','BOTH') as gender from app.pat_authorization_details ad
join tpa_enr_policy_member m on (ad.member_seq_id=m.member_seq_id) 
where ad.pat_auth_seq_id=v_seq_id;

CURSOR clm_gender_cur is select decode(m.gender_general_type_id,'FEM','FEMALE','MAL','MALE','BOTH') as gender from app.clm_authorization_details ad
join tpa_enr_policy_member m on (ad.member_seq_id=m.member_seq_id) 
where ad.claim_seq_id=v_seq_id;


 ddc_rec   pat_ddc_cur%rowtype;
 v_count   number:=0;
 
 v_gender       varchar2(10);

BEGIN

  IF v_mode = 'PAT' THEN
    
    OPEN pat_gender_cur;
    FETCH pat_gender_cur INTO v_gender;
    CLOSE pat_gender_cur;
    
    
    
    for i in (select code,ACTIVITY_DTL_SEQ_ID from pat_activity_details a where a.pat_auth_seq_id=v_seq_id
               and a.activity_type='5') loop
    
       OPEN pat_ddc_cur(I.ACTIVITY_DTL_SEQ_ID);
       FETCH pat_ddc_cur INTO ddc_rec;
       CLOSE pat_ddc_cur;
       
      
   IF ddc_rec.gender is null or ddc_rec.gender='BOTH' THEN 
      null;
   ELSIF  ddc_rec.gender != v_gender then
              
       UPDATE pat_activity_details pad
          SET pad.denial_code                = case when pad.denial_code is null then 'GEN-IND' else case when pad.denial_code like '%'||'GEN-IND'||'%' then pad.denial_code else pad.denial_code||';'||'GEN-IND' end end,
              pad.denial_desc                = case when pad.denial_desc is null then 'Drug inconsistent with the patient''s Gender' else case when pad.denial_code like '%'||'GEN-IND'||'%' then pad.denial_desc else pad.denial_desc||';'||'Drug inconsistent with the patient''s Gender' end end,
              pad.remarks                    = case when pad.remarks is null then 'Drug inconsistent with the patient''s Gender' else case when pad.denial_code like '%'||'GEN-IND'||'%' then pad.denial_desc else pad.denial_desc||';'||'Drug inconsistent with the patient''s Gender' end end,
              pad.tpa_denial_code             = case when pad.tpa_denial_code like '%GEN-IND%' then pad.tpa_denial_code else pad.tpa_denial_code||';'||'GEN-IND'end,
              pad.tpa_denial_desc             = case when pad.tpa_denial_code like '%GEN-IND%' then pad.tpa_denial_desc else pad.tpa_denial_desc||';'||'Drug inconsistent with the patient''s Gender' end,
              pad.updated_by                 = v_added_by,
              pad.updated_date               = SYSDATE,
              pad.denial_by_rule_proc_dtls   = TRIM(BOTH ';' FROM (pad.denial_by_rule_proc_dtls||';'||CHR(10)||'hosp_pbm_pkg.check_gender_rule_5')),
              pad.denial_by_resons           = TRIM(BOTH ';' FROM (pad.denial_by_resons||';'||CHR(10)||'Gender DDC missmatch.'))
         WHERE pad.activity_dtl_seq_id = i.activity_dtl_seq_id
           AND pad.code = i.code
           and pad.pat_auth_seq_id = v_seq_id
           and nvl(pad.override_yn,'N')='N'; 
           
       
    END IF;
    END LOOP;
  ELSIF v_mode = 'CLM' THEN
       
       OPEN clm_gender_cur;
       FETCH clm_gender_cur INTO v_gender;
       CLOSE clm_gender_cur;
       
       for i in (select code,ACTIVITY_DTL_SEQ_ID from pat_activity_details a where a.Claim_Seq_Id=v_seq_id
               and a.activity_type='5') loop
    
       OPEN clm_ddc_cur(I.ACTIVITY_DTL_SEQ_ID);
       FETCH clm_ddc_cur INTO ddc_rec;
       CLOSE clm_ddc_cur;
       
     IF ddc_rec.gender is null or ddc_rec.gender='BOTH' THEN 
       null;
    
      ELSIF  ddc_rec.gender != v_gender then
              
         UPDATE pat_activity_details pad
          SET pad.denial_code                = case when pad.denial_code is null then 'GEN-IND' else case when pad.denial_code like '%'||'GEN-IND'||'%' then pad.denial_code else pad.denial_code||';'||'GEN-IND' end end,
              pad.denial_desc                = case when pad.denial_desc is null then 'Drug inconsistent with the patient''s Gender' else case when pad.denial_code like '%'||'GEN-IND'||'%' then pad.denial_desc else pad.denial_desc||';'||'Drug inconsistent with the patient''s Gender' end end,
              pad.remarks                    = case when pad.remarks is null then 'Drug inconsistent with the patient''s Gender' else case when pad.denial_code like '%'||'GEN-IND'||'%' then pad.denial_desc else pad.denial_desc||';'||'Drug inconsistent with the patient''s Gender' end end,
              pad.tpa_denial_code             = case when pad.tpa_denial_code like '%GEN-IND%' then pad.tpa_denial_code else pad.tpa_denial_code||';'||'GEN-IND'end,
              pad.tpa_denial_desc             = case when pad.tpa_denial_code like '%GEN-IND%' then pad.tpa_denial_desc else pad.tpa_denial_desc||';'||'Drug inconsistent with the patient''s Gender' end,
              pad.updated_by                 = v_added_by,
              pad.updated_date               = SYSDATE,
              pad.denial_by_rule_proc_dtls   = TRIM(BOTH ';' FROM (pad.denial_by_rule_proc_dtls||';'||CHR(10)||'hosp_pbm_pkg.check_gender_rule_5')),
              pad.denial_by_resons           = TRIM(BOTH ';' FROM (pad.denial_by_resons||';'||CHR(10)||'Gender DDC missmatch.'))
         WHERE pad.activity_dtl_seq_id = i.activity_dtl_seq_id
           AND pad.code = i.code
           and pad.claim_seq_id = v_seq_id 
           and nvl(pad.override_yn,'N')='N'; 
    END IF;
   END LOOP;
  END IF;
END check_gender_rule_5;

--------------====================rules=======================================
PROCEDURE priliminary_check_rule_6(v_seq_id   IN pat_authorization_details.pat_auth_seq_id%TYPE,
                         v_mode     IN VARCHAR2,
                         v_added_by IN NUMBER)
                         IS

  
CURSOR pat_ddc_cur(v_activity_dtl_seq_id  pat_activity_details.activity_dtl_seq_id%type) IS 
select a.exclution_yn from tpa_pharmacy_master_details a join pat_activity_details b on (a.act_mas_dtl_seq_id = b.activity_seq_id) 
where b.activity_dtl_seq_id=v_activity_dtl_seq_id and b.pat_auth_seq_id=v_seq_id;


CURSOR clm_ddc_cur(v_activity_dtl_seq_id  pat_activity_details.activity_dtl_seq_id%type) IS 
select a.exclution_yn from tpa_pharmacy_master_details a join pat_activity_details b on (a.act_mas_dtl_seq_id = b.activity_seq_id) 
where b.activity_dtl_seq_id=v_activity_dtl_seq_id and b.claim_seq_id=v_seq_id;



 ddc_rec   pat_ddc_cur%rowtype;
 v_count   number:=0;

BEGIN

  IF v_mode = 'PAT' THEN
    for i in (select * from pat_activity_details a where a.pat_auth_seq_id=v_seq_id
               and a.activity_type='5' and a.code!='S5001') loop
    
       OPEN pat_ddc_cur(I.ACTIVITY_DTL_SEQ_ID);
       FETCH pat_ddc_cur INTO ddc_rec;
       CLOSE pat_ddc_cur;
       
      
  /*select count(1) into v_count from tpa_pharmacy_master_details tamd
  JOIN tpa_activity_type_codes tatc ON (tamd.activity_type_seq_id=tatc.activity_type_seq_id)
  WHERE tamd.activity_code=upper(i.code)
  AND tamd.start_date <=i.start_date  and nvl(tamd.end_date,i.start_date) >=i.start_date;  
     
      IF nvl(V_COUNT,0) = 0 THEN 
        UPDATE pat_activity_details pad
           SET pad.denial_code  = case when pad.denial_code is null then 'NCOV-003' else case when pad.denial_code like '%'||'NCOV-003'||'%' then pad.denial_code else pad.denial_code||';'||'NCOV-003' end end,
               pad.denial_desc  = case when pad.denial_desc is null then 'Drug Discontinued,Service(s) is (are) not covered' else case when pad.denial_code like '%'||'NCOV-003'||'%' then pad.denial_desc else pad.denial_desc||';'||'Drug Discontinued,Service(s) is (are) not covered' end end,
               pad.remarks      = case when pad.remarks is null then 'Drug Discontinued,Service(s) is (are) not covered' else case when pad.denial_code like '%'||'NCOV-003'||'%' then pad.denial_desc else pad.denial_desc||';'||'Drug Discontinued,Service(s) is (are) not covered' end end,
               pad.updated_by   = v_added_by,
               pad.updated_date = SYSDATE
         WHERE pad.activity_dtl_seq_id = i.activity_dtl_seq_id
           AND trim(pad.code) = i.code
           and pad.pat_auth_seq_id = v_seq_id and nvl(pad.override_yn,'N')='N'; 
       ELS*/IF nvl(ddc_rec.exclution_yn,'N')='Y' THEN  
      
              
        UPDATE pat_activity_details pad
           SET pad.denial_code  = case when pad.denial_code is null then 'NCOV-003' else case when pad.denial_code like '%'||'NCOV-003'||'%' then pad.denial_code else pad.denial_code||';'||'NCOV-003' end end,
               pad.denial_desc  = case when pad.denial_desc is null then 'Drug excluded,Service(s) is (are) not covered' else case when pad.denial_code like '%'||'NCOV-003'||'%' then pad.denial_desc else pad.denial_desc||';'||'Drug excluded,Service(s) is (are) not covered' end end,
               pad.remarks      = case when pad.remarks is null then 'Drug excluded,Service(s) is (are) not covered' else case when pad.denial_code like '%'||'NCOV-003'||'%' then pad.denial_desc else pad.denial_desc||';'||'Drug excluded,Service(s) is (are) not covered' end end,
               pad.updated_by   = v_added_by,
               pad.updated_date = SYSDATE,
               pad.tpa_denial_code = case when pad.tpa_denial_code is null then 'NCOV-003' else case when pad.tpa_denial_code like '%'||'NCOV-003'||'%' then pad.tpa_denial_code else pad.tpa_denial_code||';'||'NCOV-003' end end,
               pad.tpa_denial_desc = case when pad.tpa_denial_desc is null then 'Drug excluded,Service(s) is (are) not covered' else case when pad.tpa_denial_code like '%'||'NCOV-003'||'%' then pad.tpa_denial_desc else pad.tpa_denial_desc||';'||'Drug excluded,Service(s) is (are) not covered' end end,
               --pad.tpa_denial_remarks = case when pad.tpa_denial_remarks is null then 'Drug excluded,Service(s) is (are) not covered' else case when pad.tpa_denial_code like '%'||'NCOV-003'||'%' then pad.tpa_denial_desc else pad.tpa_denial_desc||';'||'Drug excluded,Service(s) is (are) not covered' end end,
               pad.denial_by_rule_proc_dtls    = TRIM(BOTH ';' FROM (pad.denial_by_rule_proc_dtls||';'||CHR(10)||'hosp_pbm_pkg.priliminary_check_rule_6')),
               pad.denial_by_resons            = TRIM(BOTH ';' FROM (pad.denial_by_resons||';'||CHR(10)||'Exclution_yn flag is Y.'))        
         WHERE pad.activity_dtl_seq_id = i.activity_dtl_seq_id
           AND trim(pad.code) = i.code
           and pad.pat_auth_seq_id = v_seq_id and nvl(pad.override_yn,'N')='N'; 
           
       
      END IF;
    END LOOP;
  ELSIF v_mode = 'CLM' THEN
       for i in (select * from pat_activity_details a where a.Claim_Seq_Id=v_seq_id
               and a.activity_type='5' and a.code!='S5001') loop
    
       OPEN clm_ddc_cur(I.ACTIVITY_DTL_SEQ_ID);
       FETCH clm_ddc_cur INTO ddc_rec;
       CLOSE clm_ddc_cur;
       
     /*select count(1) into v_count from tpa_pharmacy_master_details tamd
      JOIN tpa_activity_type_codes tatc ON (tamd.activity_type_seq_id=tatc.activity_type_seq_id)
      WHERE tamd.activity_code=upper(i.code)
       AND tamd.start_date <=i.start_date  and nvl(tamd.end_date,i.start_date) >=i.start_date; 
      
      IF nvl(V_COUNT,0) = 0 THEN 
        UPDATE pat_activity_details pad
           SET pad.denial_code  = case when pad.denial_code is null then 'NCOV-003' else case when pad.denial_code like '%'||'NCOV-003'||'%' then pad.denial_code else pad.denial_code||';'||'NCOV-003' end end,
               pad.denial_desc  = case when pad.denial_desc is null then 'Drug Discontinued,Service(s) is (are) not covered' else case when pad.denial_code like '%'||'NCOV-003'||'%' then pad.denial_desc else pad.denial_desc||';'||'Drug Discontinued,Service(s) is (are) not covered' end end,
               pad.remarks      = case when pad.remarks is null then 'Drug Discontinued,Service(s) is (are) not covered' else case when pad.denial_code like '%'||'NCOV-003'||'%' then pad.denial_desc else pad.denial_desc||';'||'Drug Discontinued,Service(s) is (are) not covered' end end,
               pad.updated_by   = v_added_by,
               pad.updated_date = SYSDATE
         WHERE pad.activity_dtl_seq_id = i.activity_dtl_seq_id
           AND trim(pad.code) = i.code
           and pad.claim_seq_id = v_seq_id and nvl(pad.override_yn,'N')='N'; 
       
      ELS*/IF nvl(ddc_rec.exclution_yn,'N')='Y' THEN  
              
        UPDATE pat_activity_details pad
           SET pad.denial_code  = case when pad.denial_code is null then 'NCOV-003' else case when pad.denial_code like '%'||'NCOV-003'||'%' then pad.denial_code else pad.denial_code||';'||'NCOV-003' end end,
               pad.denial_desc  = case when pad.denial_desc is null then 'Drug excluded,Service(s) is (are) not covered' else case when pad.denial_code like '%'||'NCOV-003'||'%' then pad.denial_desc else pad.denial_desc||';'||'Drug excluded,Service(s) is (are) not covered' end end,
               pad.remarks      = case when pad.remarks is null then 'Drug excluded,Service(s) is (are) not covered' else case when pad.denial_code like '%'||'NCOV-003'||'%' then pad.denial_desc else pad.denial_desc||';'||'Drug excluded,Service(s) is (are) not covered' end end,
               pad.updated_by   = v_added_by,
               pad.updated_date = SYSDATE,
               pad.tpa_denial_code = case when pad.tpa_denial_code is null then 'NCOV-003' else case when pad.tpa_denial_code like '%'||'NCOV-003'||'%' then pad.tpa_denial_code else pad.tpa_denial_code||';'||'NCOV-003' end end,
               pad.tpa_denial_desc = case when pad.tpa_denial_desc is null then 'Drug excluded,Service(s) is (are) not covered' else case when pad.tpa_denial_code like '%'||'NCOV-003'||'%' then pad.tpa_denial_desc else pad.tpa_denial_desc||';'||'Drug excluded,Service(s) is (are) not covered' end end,
               --pad.tpa_denial_remarks = case when pad.tpa_denial_remarks is null then 'Drug excluded,Service(s) is (are) not covered' else case when pad.tpa_denial_code like '%'||'NCOV-003'||'%' then pad.tpa_denial_desc else pad.tpa_denial_desc||';'||'Drug excluded,Service(s) is (are) not covered' end end,
               pad.denial_by_rule_proc_dtls    = TRIM(BOTH ';' FROM (pad.denial_by_rule_proc_dtls||';'||CHR(10)||'hosp_pbm_pkg.priliminary_check_rule_6')),
               pad.denial_by_resons            = TRIM(BOTH ';' FROM (pad.denial_by_resons||';'||CHR(10)||'Exclution_yn flag is Y.'))        
         WHERE pad.activity_dtl_seq_id = i.activity_dtl_seq_id
           AND trim(pad.code) = i.code
           and pad.claim_seq_id = v_seq_id and nvl(pad.override_yn,'N')='N'; 
           
       
       END IF;
       
    END LOOP;
    

  
  END IF;
END priliminary_check_rule_6;
----------===========================================================================
PROCEDURE check_refill_to_soon_7(v_seq_id            IN pat_authorization_details.pat_auth_seq_id%TYPE,
                               v_mode              IN VARCHAR2,
                               v_member_seq_id     IN number,
                               v_added_by          IN NUMBER ) IS

  
CURSOR pat_ddc_cur(v_activity_dtl_seq_id  pat_activity_details.activity_dtl_seq_id%type,v_code varchar2) IS 
select max(b.activity_dtl_seq_id) as pre_activity_dtl_seq_id from pat_activity_details b join pat_authorization_details ad on (b.pat_auth_seq_id=ad.pat_auth_seq_id) 
where b.activity_dtl_seq_id != v_activity_dtl_seq_id and b.pat_auth_seq_id != v_seq_id and 
ad.member_seq_id = v_member_seq_id
and ad.pat_enhanced_yn = 'N'  -------NEWLY ADDED
and b.code = v_code;

CURSOR clm_pbm_ddc_cur(v_activity_dtl_seq_id  pat_activity_details.activity_dtl_seq_id%type,v_code varchar2) IS 
select max(b.activity_dtl_seq_id) as pre_activity_dtl_seq_id 
from app.pat_activity_details b join app.clm_authorization_details ad on (b.claim_seq_id=ad.claim_seq_id) 
where b.activity_dtl_seq_id != v_activity_dtl_seq_id and b.claim_seq_id != v_seq_id and 
ad.member_seq_id = v_member_seq_id
and b.code = v_code;

cursor pre_presc_cur(v_activity_dtl_seq_id  pat_activity_details.activity_dtl_seq_id%type) is select * from pat_activity_details a
where a.activity_dtl_seq_id = v_activity_dtl_seq_id;


--CURSOR clm_ddc_cur(v_activity_dtl_seq_id  pat_activity_details.activity_dtl_seq_id%type) IS 
--select a.* from tpa_pharmacy_master_details a join pat_activity_details b on (a.act_mas_dtl_seq_id = b.activity_seq_id) 
--where b.activity_dtl_seq_id=v_activity_dtl_seq_id and b.claim_seq_id= v_seq_id;



 ddc_rec       pat_ddc_cur%rowtype;
 prev_ddc_rec  pre_presc_cur%rowtype;
 v_count   number:=0;
 
 v_target_date       date;
 clm_ddc_rec clm_pbm_ddc_cur%rowtype;

BEGIN

  IF v_mode = 'PAT' THEN
    for i in (select a.activity_dtl_seq_id,a.code,start_date from pat_activity_details a where a.pat_auth_seq_id=v_seq_id
               and a.activity_type='5') loop
    
       OPEN pat_ddc_cur(I.ACTIVITY_DTL_SEQ_ID,i.code);
       FETCH pat_ddc_cur INTO ddc_rec;
       CLOSE pat_ddc_cur;
       
       OPEN pre_presc_cur(ddc_rec.pre_activity_dtl_seq_id);
       FETCH pre_presc_cur INTO prev_ddc_rec;
       CLOSE pre_presc_cur;
       
       v_target_date := prev_ddc_rec.start_date + ((nvl(prev_ddc_rec.posology_duration,0)* 0.90)-1);
      
    --IF v_target_date > i.start_date THEN
    IF i.start_date between prev_ddc_rec.start_date and v_target_date then
                     
        UPDATE pat_activity_details pad
           SET pad.denial_code  = case when pad.denial_code is null then 'MNEC-005' else case when pad.denial_code like '%'||'MNEC-005'||'%' then pad.denial_code else pad.denial_code||';'||'MNEC-005' end end,
               pad.denial_desc  = case when pad.denial_desc is null then 'Service/supply may be appropriate, but too frequent' else case when pad.denial_code like '%'||'MNEC-005'||'%' then pad.denial_desc else pad.denial_desc||';'||'Service/supply may be appropriate, but too frequent' end end,
               pad.remarks      = case when pad.remarks is null then 'Service/supply may be appropriate, but too frequent' else case when pad.denial_code like '%'||'MNEC-005'||'%' then pad.denial_desc else pad.denial_desc||';'||'Service/supply may be appropriate, but too frequent' end end,
               pad.tpa_denial_code  = case when pad.tpa_denial_code is null then 'MNEC-005' else case when pad.tpa_denial_code like '%'||'MNEC-005'||'%' then pad.tpa_denial_code else pad.tpa_denial_code||';'||'MNEC-005' end end,
               pad.tpa_denial_desc  = case when pad.tpa_denial_desc is null then 'Service/supply may be appropriate, but too frequent' else case when pad.tpa_denial_code like '%'||'MNEC-005'||'%' then pad.tpa_denial_desc else pad.tpa_denial_desc||';'||'Service/supply may be appropriate, but too frequent' end end,
               pad.updated_by   = v_added_by,
               pad.updated_date = SYSDATE,
               pad.denial_by_rule_proc_dtls    = TRIM(BOTH ';' FROM (pad.denial_by_rule_proc_dtls||';'||CHR(10)||'hosp_pbm_pkg.check_refill_to_soon')),
               pad.denial_by_resons            = TRIM(BOTH ';' FROM (pad.denial_by_resons||';'||CHR(10)||'Service/supply may be appropriate, but too frequent.'))
         WHERE pad.activity_dtl_seq_id = i.activity_dtl_seq_id
           AND (pad.code) = i.code
           and pad.pat_auth_seq_id = v_seq_id and nvl(pad.override_yn,'N')='N'; 
           
       
    END IF;
    END LOOP;
  ELSIF v_mode = 'CLM' THEN
    for i in (select a.activity_dtl_seq_id,a.code,start_date from pat_activity_details a where a.CLAIM_SEQ_ID=v_seq_id
               and a.activity_type='5') loop
    
       OPEN clm_pbm_ddc_cur(I.ACTIVITY_DTL_SEQ_ID,i.code);
       FETCH clm_pbm_ddc_cur INTO clm_ddc_rec;
       CLOSE clm_pbm_ddc_cur;
       
       OPEN pre_presc_cur(clm_ddc_rec.pre_activity_dtl_seq_id);
       FETCH pre_presc_cur INTO prev_ddc_rec;
       CLOSE pre_presc_cur;
       
       v_target_date := prev_ddc_rec.start_date + ((nvl(prev_ddc_rec.posology_duration,0)* 0.90)-1);
      
    --IF v_target_date > i.start_date THEN
    IF i.start_date between prev_ddc_rec.start_date and v_target_date then
                     
        UPDATE pat_activity_details pad
           SET pad.denial_code  = case when pad.denial_code is null then 'MNEC-005' else case when pad.denial_code like '%'||'MNEC-005'||'%' then pad.denial_code else pad.denial_code||';'||'MNEC-005' end end,
               pad.denial_desc  = case when pad.denial_desc is null then 'Service/supply may be appropriate, but too frequent' else case when pad.denial_code like '%'||'MNEC-005'||'%' then pad.denial_desc else pad.denial_desc||';'||'Service/supply may be appropriate, but too frequent' end end,
               pad.remarks      = case when pad.remarks is null then 'Service/supply may be appropriate, but too frequent' else case when pad.denial_code like '%'||'MNEC-005'||'%' then pad.denial_desc else pad.denial_desc||';'||'Service/supply may be appropriate, but too frequent' end end,
               pad.tpa_denial_code  = case when pad.tpa_denial_code is null then 'MNEC-005' else case when pad.tpa_denial_code like '%'||'MNEC-005'||'%' then pad.tpa_denial_code else pad.tpa_denial_code||';'||'MNEC-005' end end,
               pad.tpa_denial_desc  = case when pad.tpa_denial_desc is null then 'Service/supply may be appropriate, but too frequent' else case when pad.tpa_denial_code like '%'||'MNEC-005'||'%' then pad.tpa_denial_desc else pad.tpa_denial_desc||';'||'Service/supply may be appropriate, but too frequent' end end,
               pad.updated_by   = v_added_by,
               pad.updated_date = SYSDATE,
               pad.denial_by_rule_proc_dtls    = TRIM(BOTH ';' FROM (pad.denial_by_rule_proc_dtls||';'||CHR(10)||'hosp_pbm_pkg.check_refill_to_soon')),
               pad.denial_by_resons            = TRIM(BOTH ';' FROM (pad.denial_by_resons||';'||CHR(10)||'Service/supply may be appropriate, but too frequent.'))
         WHERE pad.activity_dtl_seq_id = i.activity_dtl_seq_id
           AND (pad.code) = i.code
           and pad.CLAIM_SEQ_ID = v_seq_id and nvl(pad.override_yn,'N')='N'; 
           
       
    END IF;
    END LOOP;
  END IF;
END check_refill_to_soon_7;         
---==================================================================================      
PROCEDURE check_mat_icd_ddc_rule_8(v_seq_id   IN pat_authorization_details.pat_auth_seq_id%TYPE,
                                   v_mode     IN VARCHAR2,
                                   v_added_by IN NUMBER) 
IS

CURSOR lmrp_cur(v_activity_code  tpa_ddc_lmrp_master_details.ddc%TYPE)
IS
SELECT TI.ICD_CODES as icd_code,NVL(TI.REVIEW_YN,'N') AS REVIEW_YN
FROM APP.TPA_PHARMACY_MASTER_DETAILS P
JOIN APP.CLINICL_THRPTIC_CLASS_MSTR T ON (P.THERAPTIC_CLASS_ID=T.THERAPTIC_CLASS_ID)
JOIN APP.CLINICL_THRPTIC_ICD_MSTR TI ON (T.THERAPTIC_CLASS_ID=TI.THERAPTIC_CLASS_ID)
WHERE P.activity_code=v_activity_code;


CURSOR pat_diag_cur IS
SELECT wm_concat(dd.diagnosys_code) AS icd_codes FROM diagnosys_details dd
WHERE dd.pat_auth_seq_id=v_seq_id;

CURSOR clm_diag_cur IS
SELECT wm_concat(dd.diagnosys_code) AS icd_codes FROM diagnosys_details dd
WHERE dd.claim_seq_id=v_seq_id;

lmrp_rec                         lmrp_cur%ROWTYPE;
diag_rec                         pat_diag_cur%ROWTYPE;
TYPE v_array IS TABLE OF VARCHAR2(30);
diag_array                v_array:=v_array();
j                        number:=1;
v_exist_count            number; 

v_count    number:=0;
BEGIN
    IF v_mode = 'PAT' THEN
      
    SELECT count(1) into v_count from (
    select d.diagnosys_code
    FROM APP.CLINICL_MAT_ICD_DDC_MSTR MI 
    JOIN APP.TPA_ICD10_MASTER_DETAILS IM ON (IM.ICD_CODE=MI.ICD_CODE)
    JOIN APP.DIAGNOSYS_DETAILS D ON (IM.ICD10_SEQ_ID=D.ICD_CODE_SEQ_ID)
    WHERE  D.PAT_AUTH_SEQ_ID = v_seq_id);
    
    
    OPEN pat_diag_cur;
    FETCH pat_diag_cur INTO diag_rec;
    CLOSE pat_diag_cur;
  
    for i in (Select column_value as val from table(cast(ttk_mail_pkg.parse(diag_rec.icd_codes,',') as strings))) loop
      diag_array.extend;
      diag_array(j):=i.val;
      j:=j+1;
    end loop;
    
    
    IF v_count>0 THEN
      FOR i IN (SELECT pa.activity_dtl_seq_id,pa.code
                FROM APP.PAT_ACTIVITY_DETAILS PA
                WHERE pa.pat_auth_seq_id = v_seq_id
                  AND pa.activity_dtl_seq_id NOT IN (SELECT pa.activity_dtl_seq_id
                                                      FROM APP.PAT_ACTIVITY_DETAILS PA
                                                      JOIN APP.CLINICL_MAT_ICD_DDC_MSTR MI ON (PA.CODE=MI.DDC_CODE) 
                                                      JOIN APP.TPA_ICD10_MASTER_DETAILS IM ON (IM.ICD_CODE=MI.ICD_CODE)
                                                      JOIN APP.DIAGNOSYS_DETAILS D ON (IM.ICD10_SEQ_ID=D.ICD_CODE_SEQ_ID)
                                                      WHERE PA.PAT_AUTH_SEQ_ID = v_seq_id
                                                      and D.PAT_AUTH_SEQ_ID = v_seq_id
                                                      AND pa.activity_type='5')          
                  AND pa.activity_type='5'
              ) LOOP
              
              
              v_exist_count:=0;
            FOR lmrp_rec IN lmrp_cur(i.code) LOOP      
             IF lmrp_rec.icd_code member of diag_array THEN
              v_exist_count:=v_exist_count+1;
              
             END IF; 
            END LOOP;
           
          If v_exist_count=0 then   
          UPDATE pat_activity_details pad
             SET pad.denial_code                 = case when pad.denial_code is null then 'MAT-IND' else case when pad.denial_code like '%'||'MAT-IND'||'%' then pad.denial_code else pad.denial_code||';'||'MAT-IND' end end,
                 pad.denial_desc                 = case when pad.denial_desc is null then 'Drug not medically indicated as per standard practice' else case when pad.denial_code like '%'||'MAT-IND'||'%' then pad.denial_desc else pad.denial_desc||';'||'Drug not medically indicated as per standard practice' end end,
                 pad.remarks                     = case when pad.remarks is null then 'Drug not medically indicated as per standard practice' else case when pad.denial_code like '%'||'MAT-IND'||'%' then pad.denial_desc else pad.denial_desc||';'||'Drug not medically indicated as per standard practice' end end,
                 pad.tpa_denial_code             = case when pad.tpa_denial_code is null then 'MAT-IND' else case when pad.tpa_denial_code like '%'||'MAT-IND'||'%' then pad.tpa_denial_code else pad.tpa_denial_code||';'||'MAT-IND' end end,
                 pad.tpa_denial_desc             = case when pad.tpa_denial_desc is null then 'Drug not medically indicated as per standard practice' else case when pad.tpa_denial_code like '%'||'MAT-IND'||'%' then pad.tpa_denial_desc else pad.tpa_denial_desc||';'||'Drug not medically indicated as per standard practice' end end,
                 pad.updated_by                  = v_added_by,
                 pad.updated_date                = SYSDATE,
                 pad.denial_by_rule_proc_dtls    = TRIM(BOTH ';' FROM (pad.denial_by_rule_proc_dtls||';'||CHR(10)||'hosp_pbm_pkg.check_mat_icd_ddc_rule_8')),
                 pad.denial_by_resons            = TRIM(BOTH ';' FROM (pad.denial_by_resons||';'||CHR(10)||'ICD and DDC combination not allowed.'))
          WHERE pad.activity_dtl_seq_id = i.activity_dtl_seq_id
            and nvl(pad.override_yn,'N')='N';    
           end if; 
      END LOOP;
      END IF;        
    ELSE
      
       SELECT count(1) into v_count from (
        select d.diagnosys_code
        FROM APP.CLINICL_MAT_ICD_DDC_MSTR MI 
        JOIN APP.TPA_ICD10_MASTER_DETAILS IM ON (IM.ICD_CODE=MI.ICD_CODE)
        JOIN APP.DIAGNOSYS_DETAILS D ON (IM.ICD10_SEQ_ID=D.ICD_CODE_SEQ_ID)
        WHERE  D.Claim_Seq_Id = v_seq_id);  
        
        OPEN clm_diag_cur;
        FETCH clm_diag_cur INTO diag_rec;
        CLOSE clm_diag_cur;
        
        for i in (Select column_value as val from table(cast(ttk_mail_pkg.parse(diag_rec.icd_codes,',') as strings))) loop
          diag_array.extend;
          diag_array(j):=i.val;
          j:=j+1;
        end loop;
     
          
      
      IF v_count>0 then 
      FOR i IN (SELECT pa.activity_dtl_seq_id,pa.code
                FROM APP.PAT_ACTIVITY_DETAILS PA
                WHERE pa.Claim_Seq_Id = v_seq_id
                  AND pa.activity_dtl_seq_id NOT IN (SELECT pa.activity_dtl_seq_id
                                                      FROM APP.PAT_ACTIVITY_DETAILS PA
                                                      JOIN APP.CLINICL_MAT_ICD_DDC_MSTR MI ON (PA.CODE=MI.DDC_CODE) 
                                                      JOIN APP.TPA_ICD10_MASTER_DETAILS IM ON (IM.ICD_CODE=MI.ICD_CODE)
                                                      JOIN APP.DIAGNOSYS_DETAILS D ON (IM.ICD10_SEQ_ID=D.ICD_CODE_SEQ_ID)
                                                      WHERE PA.Claim_Seq_Id = v_seq_id
                                                      and D.Claim_Seq_Id = v_seq_id
                                                      AND pa.activity_type='5') 
                AND pa.activity_type='5'
               ) LOOP
               v_exist_count:=0;
               
                FOR lmrp_rec IN lmrp_cur(i.code) LOOP      
                 IF lmrp_rec.icd_code member of diag_array THEN
                  v_exist_count:=v_exist_count+1;
                  
                 END IF; 
                 END LOOP;
               
               
          If v_exist_count = 0 then
          UPDATE pat_activity_details pad
             SET pad.denial_code                 = case when pad.denial_code is null then 'MAT-IND' else case when pad.denial_code like '%'||'MAT-IND'||'%' then pad.denial_code else pad.denial_code||';'||'MAT-IND' end end,
                 pad.denial_desc                 = case when pad.denial_desc is null then 'Drug not medically indicated as per standard practice' else case when pad.denial_code like '%'||'MAT-IND'||'%' then pad.denial_desc else pad.denial_desc||';'||'Drug not medically indicated as per standard practice' end end,
                 pad.remarks                     = case when pad.remarks is null then 'Drug not medically indicated as per standard practice' else case when pad.denial_code like '%'||'MAT-IND'||'%' then pad.denial_desc else pad.denial_desc||';'||'Drug not medically indicated as per standard practice' end end,
                 pad.tpa_denial_code             = case when pad.tpa_denial_code is null then 'MAT-IND' else case when pad.tpa_denial_code like '%'||'MAT-IND'||'%' then pad.tpa_denial_code else pad.tpa_denial_code||';'||'MAT-IND' end end,
                 pad.tpa_denial_desc             = case when pad.tpa_denial_desc is null then 'Drug not medically indicated as per standard practice' else case when pad.tpa_denial_code like '%'||'MAT-IND'||'%' then pad.tpa_denial_desc else pad.tpa_denial_desc||';'||'Drug not medically indicated as per standard practice' end end,
                 pad.updated_by                  = v_added_by,
                 pad.updated_date                = SYSDATE,
                 pad.denial_by_rule_proc_dtls    = TRIM(BOTH ';' FROM (pad.denial_by_rule_proc_dtls||';'||CHR(10)||'hosp_pbm_pkg.check_mat_icd_ddc_rule_8')),
                 pad.denial_by_resons            = TRIM(BOTH ';' FROM (pad.denial_by_resons||';'||CHR(10)||'ICD and DDC combination not allowed.'))
          WHERE pad.activity_dtl_seq_id = i.activity_dtl_seq_id
            and nvl(pad.override_yn,'N')='N';    
         end if; 
      END LOOP; 
     END IF;
    END IF;
END check_mat_icd_ddc_rule_8; 
---==================================================================================
PROCEDURE save_pbm_pat( v_pat_auth_seq_id               in out pat_authorization_details.pat_auth_seq_id%type,
                           v_hospitalization_date       in varchar2,--pat_authorization_details.hospitalization_date%type,
                           v_tpa_enrollment_id          in pat_authorization_details.tpa_enrollment_id%type,
                           v_quatar_id                  in varchar2,
                           v_pre_auth_number            in out pat_authorization_details.pre_auth_number%type,
                           v_hosp_seq_id                in pat_authorization_details.hosp_seq_id%type,
                           v_clinician_id               in pat_authorization_details.clinician_id%type,
                           v_clinician_name             In pat_non_network_details.clinician_name%type,
                           v_event_no                   in pat_authorization_details.event_no%type,
                           v_added_by                   in number
                           ) is

  CURSOR mem_cur(v_member_seq_id  number) IS
    SELECT tepm.date_of_inception,
           tepm.date_of_exit,
           tepm.mem_name,
           tepm.mem_age,
           tcc.short_name,
           tsc.state_type_id,
           tepg.policy_group_seq_id,
           tepg.policy_seq_id,
           tepm.member_seq_id,
           ep.ins_seq_id,
           ep.enrol_type_id,
           nvl(eb.sum_insured,0) - nvl(eb.utilised_sum_insured,0) AS ava_sum_insured,
           EB.SUM_INSURED,
           tepm.vip_yn,
           reg.corp_vip_yn
      FROM tpa_enr_policy ep 
      JOIN tpa_enr_policy_group tepg on (ep.policy_seq_id=tepg.policy_seq_id)
      JOIN tpa_enr_policy_member tepm
        ON (tepg.policy_group_seq_id = tepm.policy_group_seq_id)
     LEFT OUTER JOIN tpa_enr_mem_address tema
        ON (tepg.enr_address_seq_id = tema.enr_address_seq_id)
     LEFT OUTER JOIN tpa_country_code tcc
        ON (tema.country_id = tcc.country_id)
     LEFT OUTER JOIN tpa_state_code tsc
        ON (tema.state_type_id = tsc.state_type_id)
     LEFT OUTER JOIN tpa_enr_balance eb ON (tepg.policy_group_seq_id = eb.policy_group_seq_id)
     LEFT OUTER JOIN tpa_group_registration reg ON(tepg.group_reg_seq_id = reg.group_reg_seq_id)
     WHERE tepm.Member_Seq_Id = v_member_seq_id 
     and  (tepm.mem_general_type_id != 'PFL' AND tepm.member_seq_id = eb.member_seq_id OR eb.member_seq_id IS NULL OR tepm.member_seq_id IS NULL);



  CURSOR pat_cur IS
    SELECT pad.completed_yn,pad.pat_status_type_id
      FROM pat_authorization_details pad
     WHERE pad.pat_auth_seq_id = v_pat_auth_seq_id;
     
  CURSOR clinician_cur IS
   SELECT hp.hosp_seq_id,hp.professional_id,hp.valid_from_date,hp.valid_to_date FROM app.tpa_hosp_professionals hp
   WHERE hp.professional_id=v_clinician_id;
 
 CURSOR clinician_count_cur IS
   SELECT count(1) FROM app.tpa_hosp_professionals hp
   WHERE hp.professional_id=v_clinician_id AND hp.hosp_seq_id= v_hosp_seq_id;
   
 CURSOR prev_balance_cur(v_member_seq_id number) IS SELECT b.balance_seq_id , b.sum_insured  ,b.utilised_sum_insured ,
        a.policy_group_seq_id ,a.mem_general_type_id 
      FROM tpa_enr_policy_member a JOIN tpa_enr_balance b ON (a.policy_group_seq_id = b.policy_group_seq_id )
      JOIN tpa_enr_policy c ON (b.policy_seq_id = c.policy_seq_id)
      WHERE a.member_seq_id = v_member_seq_id
      AND (a.mem_general_type_id = 'PFL' AND b.member_seq_id IS NULL
               OR a.mem_general_type_id != 'PFL' AND b.member_seq_id = v_member_seq_id );

   pat_rec pat_cur%ROWTYPE;
   v_count          number(10);
   clin_rec        clinician_cur%rowtype;
   mem_rec         mem_cur%ROWTYPE;
   balance_rec                  prev_balance_cur%ROWTYPE;
   v_denial_reason pat_authorization_details.denial_reason%type;
   v_denial_code     pat_authorization_details.denial_code%type;
   v_parent_pat_rcvd_date   pat_authorization_details.pat_received_date%type;
   v_parent_completed_yn    varchar2(2);
   v_pat_status_type_id     pat_authorization_details.pat_status_type_id%type;
   v_parent_app_sum_insured pat_general_details.app_sum_insured%TYPE;
   V_shortfall_count       number;
   v_denial_codes          VARCHAR2(250);
   v_dest_msg_seq_id      number;
   v_benifit_type        varchar2(100):='OPTS';
   
   v_member_seq_id     number;
   v_seq_id          NUMBER;
   
   CURSOR vip_nvip_cursor(v_pat_seq_id number)IS 
   select b.vip_yn from pat_authorization_Details a join   tpa_enr_policy_member b
   on ( a.MEMBER_SEQ_ID=b.MEMBER_SEQ_ID) where a.pat_auth_seq_id =  v_pat_seq_id;
   
   vip_nvip_rec           tpa_enr_polIcy_member.VIP_YN%TYPE;
   
   CURSOR get_member_seq is 
    SELECT trim(a.member_seq_id)
    FROM   tpa_enr_policy_member A
    JOIN tpa_enr_policy_group B ON (A.policy_group_seq_id = B.policy_group_seq_id)
    JOIN tpa_enr_policy C ON (B.policy_seq_id = C.policy_seq_id and nvl(c.completed_yn,'N')='Y')
    WHERE ((a.tpa_enrollment_id =v_tpa_enrollment_id))
    AND ( to_date(v_hospitalization_date,'dd/mm/yyyy') BETWEEN C.effective_from_date AND C.effective_to_date+1);

BEGIN

  
  --select max(pm.member_seq_id) into v_member_seq_id  from tpa_enr_policy_member pm where (pm.tpa_enrollment_id =v_tpa_enrollment_id) or (pm.global_net_member_id= v_tpa_enrollment_id);

  OPEN get_member_seq;
  FETCH get_member_seq INTO v_member_seq_id;
  CLOSE get_member_seq;
  
  OPEN mem_cur(v_member_seq_id);
  FETCH mem_cur
    INTO mem_rec;
  CLOSE mem_cur;
  
  OPEN pat_cur;
  FETCH pat_cur
    INTO pat_rec;
  CLOSE pat_cur;

 /* OPEN clinician_cur;
  FETCH clinician_cur
    INTO clin_rec;
  CLOSE clinician_cur;
  
  OPEN clinician_count_cur;
  FETCH clinician_count_cur
    INTO v_count;
  CLOSE clinician_count_cur;
  
    OPEN prev_balance_cur(v_member_seq_id);
    FETCH prev_balance_cur INTO balance_rec;
    CLOSE prev_balance_cur;*/-- we are not using these 3 cursor  commented by venu 10/07/2019
   
  IF pat_rec.completed_yn = 'Y' THEN
    RAISE_APPLICATION_ERROR(-20107,
                            'You cannot perform this action through a completed Claim.');
  END IF;
    
  IF mem_rec.member_seq_id IS NULL THEN
    RAISE_APPLICATION_ERROR(-20370, 'Patient is not a covered member');
 
  END IF;
  
  IF NVL(V_PAT_AUTH_SEQ_ID, 0) = 0 THEN
    IF v_pre_auth_number IS NULL THEN
       v_pre_auth_number := authorization_pkg.generate_id_numbers('PA',
                                               mem_rec.short_name,
                                               mem_rec.state_type_id,
                                               v_pre_auth_number);
    END IF;
  
    INSERT INTO PAT_AUTHORIZATION_DETAILS
      (pat_auth_seq_id,
       pat_received_date,
       discharge_date,
       source_type_id,
       hospitalization_date,
       member_seq_id,
       tpa_enrollment_id,
       pre_auth_number,
       mem_name,
       mem_age,
       ins_seq_id,
       hosp_seq_id,
       policy_seq_id,
       enrol_type_id,
       tpa_office_seq_id,
       emirate_id,
       encounter_type_id,
       encounter_facility_id,
       encounter_start_type,
       encounter_end_type,
       pat_status_type_id,
       clinician_id,
       added_by,
       added_date,
       benifit_type,
       pbm_yn,
       AVA_SUM_INSURED,
       SYSTEM_OF_MEDICINE_TYPE_ID,
       PAT_ENHANCED_YN,
       AUTHORIZED_BY,
       process_type,
	   CONVERSION_RATE,
	   event_no,
       CURRENCY_TYPE,
       Converted_Amount_Currency_Type,
       Req_Amt_Currency_Type,
       parent_pat_auth_seq_id,
       priority_general_type_id
      )
    VALUES
      (pat_auth_detail_seq.nextval,
       sysdate,--v_pat_received_date,
       to_date(v_hospitalization_date,'dd/mm/rrrr'),--v_discharge_date,
       'PBML',--v_source_type_id,
       to_date(v_hospitalization_date,'dd/mm/rrrr'),
       v_member_seq_id,
       v_tpa_enrollment_id,
       v_pre_auth_number,
       mem_rec.mem_name,
       mem_rec.mem_age,
       mem_rec.ins_seq_id,--v_ins_seq_id,
       v_hosp_seq_id,
       mem_rec.policy_seq_id,
       mem_rec.enrol_type_id,
       1,
       v_quatar_id,--null,--v_emirate_id,
       1,
       null,
       1,
       1,
       'INP',
       v_clinician_id,
       1,
       SYSDATE,
       v_benifit_type,
       'Y',
       mem_rec.ava_sum_insured,
       'SAL',
       'N',
       1,
       'RGL',
       1,
		v_event_no,
       'QAR',
       'QAR',
       'QAR',
       0,
       case when mem_rec.vip_yn='Y' or NVL(mem_rec.corp_vip_yn,'CVN')='CVY' then 'HIG' else 'MID' END
       )
      RETURNING pat_auth_seq_id INTO v_pat_auth_seq_id;
      
/*      IF v_pat_auth_seq_id IS NOT NULL  THEN
      OPEN vip_nvip_cursor(v_pat_auth_seq_id);
      fetch vip_nvip_cursor into vip_nvip_rec;
      close  vip_nvip_cursor;
      
      IF NVL(vip_nvip_rec,'N')='Y' and v_pat_auth_seq_id is not null and v_pre_auth_number is not null THEN
        GENERATE_MAIL_PKG.proc_generate_message('VIP_PAT_UPLOADED',v_pat_auth_seq_id,v_added_by,v_dest_msg_seq_id);
      END IF;
      END IF;
*/
  IF v_benifit_type IN('IPT','IMTI') THEN
  GENERATE_MAIL_PKG.proc_generate_message('IN-PATIENT_PREAPPROVAL',
                                          v_pat_auth_seq_id,
                                          v_added_by,
                                          v_dest_msg_seq_id);
  END IF;
    --IF v_network_yn = 'N' then
      INSERT INTO PAT_NON_NETWORK_DETAILS
        (PAT_NON_NETWORK_SEQ_ID,
         PAT_AUTH_SEQ_ID,
         ADDED_BY,
         ADDED_DATE,
         CLINICIAN_ID,
         CLINICIAN_NAME)
      values
        (PAT_NON_NETWORK_DETAILS_SEQ.nextval,
         v_pat_auth_seq_id,
         v_added_by,
         sysdate,
         v_clinician_id,
         v_clinician_name
         );
         
     
 
  ELSE
  
    UPDATE pat_authorization_details
       SET discharge_date       =	       to_date(v_hospitalization_date,'dd/mm/rrrr'),
       source_type_id           =	       'PBML',
       hospitalization_date     =	       to_date(v_hospitalization_date,'dd/mm/rrrr'),
       member_seq_id            =	       v_member_seq_id,
       tpa_enrollment_id        =	       v_tpa_enrollment_id,
       pre_auth_number          =	       v_pre_auth_number,
       mem_name                 =	       mem_rec.mem_name,
       mem_age                  =	       mem_rec.mem_age,
       ins_seq_id               =	       mem_rec.ins_seq_id,
       hosp_seq_id              =	       v_hosp_seq_id,
       policy_seq_id            =	       mem_rec.policy_seq_id,
       tpa_office_seq_id        =	       1,
       encounter_type_id        =	       1,
       encounter_start_type     =	       1,
       encounter_end_type       =	       1,
       pat_status_type_id       =	       'INP',
       clinician_id             =	       v_clinician_id,
       updated_by               =	       1,
       updated_date             =	       SYSDATE,
       benifit_type	            =     'OPTS',
       pbm_yn                   =   'Y',
       AUTHORIZED_BY            = 1,
       process_type             ='RGL',
       CONVERSION_RATE          =1,
       event_no                 =   v_event_no,
       CURRENCY_TYPE            ='QAR',
       Converted_Amount_Currency_Type='QAR',
       Req_Amt_Currency_Type='QAR',
       priority_general_type_id = case when mem_rec.vip_yn='Y' or NVL(mem_rec.corp_vip_yn,'CVN')='CVY' then 'HIG' else 'MID' END
     WHERE pat_auth_seq_id  = v_pat_auth_seq_id;
  
  update PAT_NON_NETWORK_DETAILS set
          clinician_id   =  v_clinician_id,
          clinician_name =  v_clinician_name
       where pat_auth_seq_id = v_pat_auth_seq_id;
  
  end if;
  authorization_pkg.reassign_user('|'||v_pat_auth_seq_id||'|',null,null,1,'AUT',v_seq_id);
  v_prod_policy_rule_seq_id := get_prod_pol_seq_id(mem_rec.policy_seq_id,
                                                   'POL');
 
  pat_xml_load_pkg.execute_global_rules('P',
                                        v_pat_auth_seq_id,
                                        v_member_seq_id,
                                        v_prod_policy_rule_seq_id);

  commit;
END save_pbm_pat;
--======================================================================
PROCEDURE save_diagnosys_details(
  v_diag_seq_id       IN OUT diagnosys_details.diag_seq_id%type,
  v_pat_auth_seq_id   IN diagnosys_details.pat_auth_seq_id%type,
  v_icd_code_seq_id   IN diagnosys_details.icd_code_seq_id%type,
  v_diagnosys_code    IN diagnosys_details.diagnosys_code%type,
  v_added_by          IN diagnosys_details.added_by%type 
  )
  IS
  
  
 CURSOR pat_cur IS
 SELECT pad.pat_auth_seq_id,
       pad.pat_batch_seq_id,
       pad.claim_seq_id,
       pad.member_seq_id,       
       pad.final_app_amount,
       pad.denial_reason,
       pad.completed_yn, pad.benifit_type
  FROM pat_authorization_details pad
  WHERE pad.pat_auth_seq_id=v_pat_auth_seq_id;
  

  
  pat_rec              pat_cur%ROWTYPE;
  v_prod_pol_rule_seq_id       tpa_ins_prod_policy_rules.prod_policy_rule_seq_id%type;
  
  CURSOR diag_cur IS
  SELECT count(1)
  FROM diagnosys_details dd
  WHERE dd.pat_auth_seq_id=v_pat_auth_seq_id
  AND dd.diag_seq_id!=nvl(v_diag_seq_id,0)
  AND dd.diagnosys_code=TRIM(upper(v_diagnosys_code));
  
  CURSOR primary_cur IS
  SELECT count(1)
  FROM diagnosys_details dd
  WHERE dd.pat_auth_seq_id=v_pat_auth_seq_id
  AND dd.diag_seq_id!=NVL(v_diag_seq_id,0)
  AND dd.primary_ailment_yn='Y';
  
   CURSOR icd_benefit_cur IS
  Select ic.benefit_type
  From tpa_icd10_master_details ic
  Where ic.icd_code = upper(v_diagnosys_code);
  
  v_icd_benefit          icd_benefit_cur%ROWTYPE;
  
  CURSOR icd_mti_benefit_cur IS 
  Select dig.diagnosys_code,micd.icd_code_seq_id 
  from diagnosys_details dig join pat_authorization_details pat on(pat.pat_auth_seq_id=dig.pat_auth_seq_id)
                           left outer join tpa_icd_codes micd on(micd.icd_code=dig.diagnosys_code and micd.master_icd_code='Z34.90')
  where pat.pat_auth_seq_id=v_pat_auth_seq_id and dig.primary_ailment_yn='Y';
  
  icd_mti_benefit icd_mti_benefit_cur%rowtype;
  v_diag_count           number(2);
  v_primary              number(2);
  v_priamry_yn        diagnosys_details.Primary_Ailment_Yn%TYPE;
 
BEGIN 

  if v_pat_auth_seq_id is not null then
   OPEN pat_cur;
   FETCH pat_cur INTO pat_rec;
   CLOSE pat_cur;
  end if;   
  IF pat_rec.completed_yn='Y' THEN
    RAISE_APPLICATION_ERROR(-20107,'You cannot perform this action through a completed Claim.');
  END IF;
  
  OPEN diag_cur;
  FETCH diag_cur INTO v_diag_count;
  CLOSE diag_cur;
  
  OPEN primary_cur;
  FETCH primary_cur INTO v_primary;
  CLOSE primary_cur;
  
  IF NVL(v_priamry_yn,'N')='Y' AND v_primary>0 THEN
        RAISE_APPLICATION_ERROR(-20379,'Primary Diagnosis already Exists!');
  END IF;       

  /*IF v_icd_benefit.benefit_type = 'DNTL' \*AND NVL(v_priamry_yn,'N')='Y'*\ THEN
    IF v_icd_benefit.benefit_type != pat_rec.benifit_type THEN
      RAISE_APPLICATION_ERROR(-20323,'Ailment does not belogs to the selected benefit type, please select appropriate benefit type!');
    END IF;
  END IF;*/
  ---

  IF v_diag_count>0 THEN
    RAISE_APPLICATION_ERROR(-20374,'Diagnosis code already Exists!');
  END IF;
  
  v_priamry_yn:= case when v_primary =0 then 'Y' else 'N' end;
   
  IF NVL(v_diag_seq_id,0)=0 THEN
    
    INSERT INTO diagnosys_details(
                diag_seq_id,
                pat_auth_seq_id,
                icd_code_seq_id,
                diagnosys_code,
                primary_ailment_yn,
                added_by,
                added_date)
          VALUES (
                diagnosys_detail_seq.nextval,
                v_pat_auth_seq_id,
                v_icd_code_seq_id,
                UPPER(TRIM(v_diagnosys_code)),
                v_priamry_yn,
                v_added_by,
                SYSDATE) RETURNING DIAG_SEQ_ID INTO v_diag_seq_id;
   ELSE
     
      UPDATE diagnosys_details SET
          PAT_AUTH_SEQ_ID      =  V_PAT_AUTH_SEQ_ID,
          icd_code_seq_id      =  v_icd_code_seq_id,
          diagnosys_code       =  upper(v_diagnosys_code),
          primary_ailment_yn   =  v_priamry_yn,
          updated_by           =  v_added_by,
          updated_date         =  sysdate
    WHERE DIAG_SEQ_ID =v_diag_seq_id;
    
  END IF;
  
  --Dental ICD
  OPEN icd_benefit_cur;
  FETCH icd_benefit_cur INTO v_icd_benefit;
  CLOSE icd_benefit_cur;
  
  IF v_icd_benefit.benefit_type = 'DNTL' AND NVL(v_priamry_yn,'N')='Y' THEN
    IF v_icd_benefit.benefit_type != pat_rec.benifit_type THEN
      
      Update Pat_Authorization_Details p
      Set p.benifit_type = 'DNTL',
          p.treatment_type  = 2
      Where p.pat_auth_seq_id = v_pat_auth_seq_id;
      
    END IF;
  END IF;
  
  open icd_mti_benefit_cur;
  fetch icd_mti_benefit_cur into icd_mti_benefit;
  close icd_mti_benefit_cur;
  
  IF icd_mti_benefit.diagnosys_code IS NOT NULL AND icd_mti_benefit.icd_code_seq_id IS NOT NULL THEN
    UPDATE pat_authorization_details p
    SET p.benifit_type ='OMTI'
    where p.pat_auth_seq_id=v_pat_auth_seq_id;
  END IF;
  --v_rows_processed:=SQL%ROWCOUNT;
 COMMIT;
  
END save_diagnosys_details;
----===================================================================
PROCEDURE save_activity_details(
    v_activity_dtl_seq_id     IN OUT pat_activity_details.activity_dtl_seq_id%TYPE,
    v_pat_auth_seq_id         IN  pat_activity_details.pat_auth_seq_id%TYPE,
    v_activity_seq_id         IN  tpa_pharmacy_master_details.act_mas_dtl_seq_id%TYPE,
    v_unit_type               IN  pat_activity_details.unit_type%TYPE,
    v_quantity                IN  pat_activity_details.quantity%TYPE,
    v_duration_days           IN  pat_activity_details.posology_duration%TYPE,
    v_allow_yn                IN  pat_activity_details.allow_yn%TYPE:='Y',
    v_added_by                IN  pat_activity_details.added_by%TYPE,
    v_approve_yn              IN  pat_activity_details.approve_yn%TYPE:='Y'
   )
 IS
 v_prod_pol_rule_seq_id       tpa_ins_prod_policy_rules.prod_policy_rule_seq_id%type;
 
    
 
 CURSOR act_cur IS
  SELECT max(pad.s_no) max_sno
  FROM pat_activity_details pad
  WHERE pad.pat_auth_seq_id=v_pat_auth_seq_id;
  
  
  
  CURSOR pat_diag_cur IS
  SELECT count(1) 
  FROM diagnosys_details dd
  WHERE dd.pat_auth_seq_id=v_pat_auth_seq_id;
  
  
  
  CURSOR pat_cur IS
 SELECT pad.pat_auth_seq_id,
       pad.pat_batch_seq_id,
       pad.claim_seq_id,
       pad.member_seq_id,       
       pad.final_app_amount,
       pad.denial_reason,
       pad.completed_yn,
       pad.source_type_id,
       pad.hosp_seq_id,
       trunc(pad.hospitalization_date) as hospitalization_date 
  FROM pat_authorization_details pad
  WHERE pad.pat_auth_seq_id=v_pat_auth_seq_id;
 
 
  
 pat_rec              pat_cur%ROWTYPE;
 act_rec              act_cur%ROWTYPE;
 v_s_no               NUMBER;
 v_diag_count         NUMBER;
 
 v_copay_per          number:=0;
 v_rule_limit         number:=null;
 v_prior_authid    varchar2(100);
 v_check_ucr_yn   CHAR(1);
 
 
 CURSOR PHARMACY_DISCOUNT(v_hosp_seq number) IS
 SELECT A.DISC_PERCENT FROM app.tpa_hosp_tariff_details a where a.acitivity_type_seq_id=5 and a.hosp_seq_id=v_hosp_seq; 

 
  V_PHARMACY_DISC               NUMBER;
  v_count                       number;
   
   
    v_claim_seq_id              pat_activity_details.claim_seq_id%TYPE;
    v_activity_id               pat_activity_details.activity_id%TYPE;
    v_start_date                pat_activity_details.start_date%TYPE;
    v_activity_type             pat_activity_details.activity_type%TYPE:=5;
    v_modifier                  pat_activity_details.modifier%TYPE;
    v_internal_code             pat_activity_details.internal_code%TYPE;
    v_package_id                pat_activity_details.package_id%TYPE;
    v_bundle_id                 pat_activity_details.bundle_id%TYPE;
    v_gross_amount              pat_activity_details.gross_amount%TYPE;
    v_discount_amount           pat_activity_details.discount_amount%TYPE;
    v_disc_gross_amount         pat_activity_details.disc_gross_amount%TYPE;
    v_patient_share_amount      pat_activity_details.patient_share_amount%TYPE;
    v_copay_amount              pat_activity_details.copay_amount%TYPE;
    v_co_ins_amount             pat_activity_details.co_ins_amount%TYPE;
    v_deduct_amount             pat_activity_details.deduct_amount%TYPE;
    v_out_of_pocket_amount      pat_activity_details.out_of_pocket_amount%TYPE;
    v_net_amount                pat_activity_details.net_amount%TYPE;
    v_allowed_amount            pat_activity_details.allowed_amount%TYPE;
    v_approved_amount           pat_activity_details.approved_amount%TYPE;
    v_posology                  pat_activity_details.posology%TYPE;
    v_req_amount                pat_activity_details.provider_net_amount%TYPE;
    v_denial_desc               pat_activity_details.denial_desc%TYPE;
    v_service_type              pat_activity_details.service_type%TYPE:='ACD';
    v_service_code              pat_activity_details.service_code%TYPE;
    v_ucr                       pat_activity_details.ucr%TYPE DEFAULT NULL;
    v_denial_res_dis            pat_activity_details.denial_res_dis%TYPE DEFAULT NULL;
    v_override_yn               pat_activity_details.override_yn%type;
    v_override_remarks          pat_activity_details.override_remarks%TYPE;
    v_approved_quantity         pat_activity_details.approvd_quantity%type:=v_quantity;
    v_unit_price                pat_activity_details.unit_price%type;
    v_denial_code               pat_activity_details.denial_code%TYPE;
    v_remarks                   pat_activity_details.remarks%TYPE;
    v_code                      pat_activity_details.code%TYPE;
    v_moph_codes                tpa_pharmacy_master_details.moph_codes%TYPE;
    
 cursor ddc_code is select m.activity_code,m.moph_codes from tpa_pharmacy_master_details m where m.act_mas_dtl_seq_id= v_activity_seq_id;
   
   
BEGIN
  
 
  
  IF v_pat_auth_seq_id IS NOT NULL THEN 
   OPEN pat_diag_cur;
   FETCH pat_diag_cur INTO v_diag_count;
   CLOSE pat_diag_cur;
  END IF;
  
  if v_pat_auth_seq_id is not null then
   OPEN pat_cur;
   FETCH pat_cur INTO pat_rec;
   CLOSE pat_cur;
   if pat_rec.pat_auth_seq_id is not null then 
    
  select pa.pre_auth_number into v_prior_authid from app.pat_authorization_details pa where pa.pat_auth_seq_id=pat_rec.pat_auth_seq_id;
  
  end if ;
 
  end if;
  
  v_start_date:=pat_rec.hospitalization_date;
  
  open ddc_code;
  fetch ddc_code into v_code,v_moph_codes;
  close ddc_code;
  
  
  IF pat_rec.completed_yn='Y' THEN
    RAISE_APPLICATION_ERROR(-20107,'You cannot perform this action through a completed Claim.');
  END IF;
  
  IF v_diag_count<1 THEN
    RAISE_APPLICATION_ERROR(-20380,'Please add atleast one Diagnosis');
  END IF;
  
  
   if v_activity_type=5 then
    select count(1) into v_count from tpa_pharmacy_master_details tamd
    JOIN tpa_activity_type_codes tatc ON (tamd.activity_type_seq_id=tatc.activity_type_seq_id)
    WHERE tamd.activity_code=upper(v_code)
    AND tamd.start_date <= pat_rec.hospitalization_date and nvl(tamd.end_date,pat_rec.hospitalization_date) >=pat_rec.hospitalization_date; 
     
   end if;
   
   if v_activity_type = 5 then 
     
     OPEN PHARMACY_DISCOUNT(pat_rec.hosp_seq_id);
     FETCH PHARMACY_DISCOUNT INTO V_PHARMACY_DISC;
     CLOSE PHARMACY_DISCOUNT;
     
     IF v_unit_type='LOSE' THEN
    if v_count>0 then
       select 
            tamd.unit_price as unit_price,
           (tamd.unit_price * v_approved_quantity) as gross_amount ,
           ((tamd.unit_price*NVL(v_pharmacy_disc,0))/100) as disc_amount,
           --((tamd.unit_price*NVL(v_pharmacy_disc,0))/100) as unit_discount,
           (tamd.unit_price * v_approved_quantity)- (((tamd.unit_price*NVL(v_pharmacy_disc,0))/100)*v_approved_quantity) as disc_gross_amount
          into v_unit_price,v_gross_amount,v_discount_amount,v_disc_gross_amount
    from tpa_pharmacy_master_details tamd
    JOIN tpa_activity_type_codes tatc ON (tamd.activity_type_seq_id=tatc.activity_type_seq_id)
    WHERE tamd.activity_code=upper(v_code)
    AND tamd.start_date <= pat_rec.hospitalization_date and nvl(tamd.end_date,pat_rec.hospitalization_date) >=pat_rec.hospitalization_date;
   else
     select 
           tamd.unit_price as unit_price,
           (tamd.unit_price * v_approved_quantity) as gross_amount ,
           ((tamd.unit_price*NVL(v_pharmacy_disc,0))/100) as disc_amount,
           --((tamd.unit_price*NVL(v_pharmacy_disc,0))/100) as unit_discount,
           (tamd.unit_price * v_approved_quantity)- (((tamd.unit_price*NVL(v_pharmacy_disc,0))/100)*v_approved_quantity) as disc_gross_amount
          into v_unit_price,v_gross_amount,v_discount_amount,v_disc_gross_amount
    from tpa_pharmacy_master_details tamd
    JOIN tpa_activity_type_codes tatc ON (tamd.activity_type_seq_id=tatc.activity_type_seq_id)
    WHERE tamd.activity_code=upper(v_code) and tamd.act_mas_dtl_seq_id in (
    select  max(tamd.act_mas_dtl_seq_id)
    from tpa_pharmacy_master_details tamd
    JOIN tpa_activity_type_codes tatc ON (tamd.activity_type_seq_id=tatc.activity_type_seq_id)
    WHERE tamd.activity_code=upper(v_code)) ;
   end if;
  ELSE
    if v_count>0 then
    select 
            tamd.PACKAGE_PRICE as unit_price,
           (tamd.PACKAGE_PRICE * v_approved_quantity) as gross_amount ,
           ((tamd.PACKAGE_PRICE*NVL(v_pharmacy_disc,0))/100) as disc_amount,
           --((tamd.unit_price*NVL(v_pharmacy_disc,0))/100) as unit_discount,
           (tamd.PACKAGE_PRICE * v_approved_quantity)- (((tamd.PACKAGE_PRICE*NVL(v_pharmacy_disc,0))/100)*v_approved_quantity) as disc_gross_amount
          into v_unit_price,v_gross_amount,v_discount_amount,v_disc_gross_amount
    from tpa_pharmacy_master_details tamd
    JOIN tpa_activity_type_codes tatc ON (tamd.activity_type_seq_id=tatc.activity_type_seq_id)
    WHERE tamd.activity_code=upper(v_code)
    AND tamd.start_date <= pat_rec.hospitalization_date and nvl(tamd.end_date,pat_rec.hospitalization_date) >=pat_rec.hospitalization_date;
    ELSE
     select 
           tamd.PACKAGE_PRICE as unit_price,
           (tamd.PACKAGE_PRICE * v_approved_quantity) as gross_amount ,
           ((tamd.PACKAGE_PRICE*NVL(v_pharmacy_disc,0))/100) as disc_amount,
           --((tamd.unit_price*NVL(v_pharmacy_disc,0))/100) as unit_discount,
           (tamd.PACKAGE_PRICE * v_approved_quantity)- (((tamd.PACKAGE_PRICE*NVL(v_pharmacy_disc,0))/100)*v_approved_quantity) as disc_gross_amount
          into v_unit_price,v_gross_amount,v_discount_amount,v_disc_gross_amount
    from tpa_pharmacy_master_details tamd
    JOIN tpa_activity_type_codes tatc ON (tamd.activity_type_seq_id=tatc.activity_type_seq_id)
    WHERE tamd.activity_code=upper(v_code) and tamd.act_mas_dtl_seq_id in (
    select  max(tamd.act_mas_dtl_seq_id)
    from tpa_pharmacy_master_details tamd
    JOIN tpa_activity_type_codes tatc ON (tamd.activity_type_seq_id=tatc.activity_type_seq_id)
    WHERE tamd.activity_code=upper(v_code)) ;
   end if;
  END IF;
  END IF;
  
  
  IF NVL(v_activity_dtl_seq_id,0)=0 THEN
    
  
    if v_pat_auth_seq_id is not null then
     OPEN act_cur;
     FETCH act_cur INTO act_rec;
     CLOSE act_cur;
    
    end if;
    v_s_no:=NVL(act_rec.max_sno,0)+1;
    
    
    INSERT INTO pat_activity_details(
                activity_dtl_seq_id,
                pat_auth_seq_id,
                claim_seq_id,
                Activity_Seq_Id,
                activity_id,
                s_no,
                start_date,
                activity_type,
                code,
                unit_type,
                modifier,
                internal_code,
                package_id,
                bundle_id,
                quantity,
                gross_amount,
                discount_amount,
                disc_gross_amount,
                patient_share_amount,
                co_ins_amount,
                deduct_amount,
                out_of_pocket_amount,
                net_amount,
                allowed_amount,
                approved_amount,
                allow_yn,
                denial_code,
                remarks,
                added_by,
                added_date,
                denial_desc,
                approvd_quantity,
                unit_price,
                unit_discount_amount,
                provider_copay,
                override_yn,
                override_remarks,
                approve_yn,
                posology_duration,
                posology,
                provider_net_amount,
				        prior_authid,
                service_type,
                service_code,
                service_remarks,
                ucr,
                ri_copar,
                denial_res_dis,
                CURRENCY_TYPE,
                CONVERTED_ACITIVTY_AMT,
                MOPH_CODES,
                discount_amount_new
                )
          VALUES (
                pat_activity_detail_seq.nextval,
                v_pat_auth_seq_id,
                v_claim_seq_id,
                v_Activity_Seq_Id,
                v_activity_id,
                v_s_no,
                v_start_date,
                v_activity_type,
                UPPER(TRIM(v_code)),
                v_unit_type,
                v_modifier,
                v_internal_code,
                v_package_id,
                v_bundle_id,
                v_quantity,
                v_gross_amount,
                0, -- added in discount exclusion cr on 13/08/2019
                v_gross_amount,
                v_patient_share_amount,
                v_co_ins_amount,
                v_deduct_amount,
                v_out_of_pocket_amount,
                v_disc_gross_amount,--v_net_amount,
                v_allowed_amount,
                v_approved_amount,
                NVL(v_allow_yn,'Y'),
                v_denial_code,
                v_remarks,
                v_added_by,
                SYSDATE,
                v_denial_desc,
                v_approved_quantity,
                v_unit_price,
                nvl(v_discount_amount,0)/v_quantity,
                v_copay_amount,
                v_override_yn,
                v_override_remarks,
                v_approve_yn,
                v_duration_days,
                v_posology,
                v_req_amount,
				        v_prior_authid,
                v_service_type,
                v_service_code,
                case when nvl(v_service_type,'ACD') != 'ACD' then v_remarks else null end, 
                CASE WHEN v_check_ucr_yn = 'Y' THEN v_ucr ELSE 0 END,--Changed by priyadarshan
                NULL,
                v_denial_res_dis,
                'QAR',
                v_unit_price,
                NVL(v_moph_codes,v_code),
                v_discount_amount
                  ) RETURNING activity_dtl_seq_id INTO v_activity_dtl_seq_id;
   
  
   ELSE
     
      UPDATE pat_activity_details SET
          pat_auth_seq_id       =  v_pat_auth_seq_id,
          claim_seq_id          =  v_claim_seq_id,
          Activity_Seq_Id       =  v_Activity_Seq_Id,    
          start_date            =  v_start_date,
          activity_type         =  v_activity_type,
          code                  =  UPPER(TRIM(v_code)),
          unit_type             =  v_unit_type,
          modifier              =  v_modifier,
          internal_code         =  v_internal_code,
          package_id            =  v_package_id,
          bundle_id             =  v_bundle_id,
          quantity              =  v_quantity,
          gross_amount          =  v_gross_amount,
          discount_amount       =  0,-- added in discount exclusion cr on 13/08/2019
          disc_gross_amount     =  v_gross_amount,
          patient_share_amount  =  v_patient_share_amount,
          copay_perc            =  v_copay_per,
          provider_copay        =  v_copay_amount,
          co_ins_amount         =  v_co_ins_amount,
          deduct_amount         =  v_deduct_amount,
          out_of_pocket_amount  =  v_out_of_pocket_amount,
          net_amount            =  v_net_amount,
          allowed_amount        =  v_allowed_amount,
          approved_amount       =  v_approved_amount,
          allow_yn              =  NVL(v_allow_yn,'Y'),
          denial_code           =  v_denial_code,
          remarks               =  null,
          denial_desc           =  v_denial_desc,
          updated_by            =  v_added_by,
          updated_date          =  SYSDATE,
          approvd_quantity      =  v_approved_quantity,
          unit_price            =  v_unit_price,
          rule_limit            =  v_rule_limit,
          unit_discount_amount  =  (nvl(v_discount_amount,0)/v_quantity),
          override_yn           =  nvl(v_override_yn,'N'),
          override_remarks      =  v_override_remarks,
          approve_yn            =  v_approve_yn,
          posology_duration     =  v_duration_days,
          posology              =  v_posology,
          service_type          =  v_service_type,
          service_code          =  v_service_code,
          service_remarks       =  case when nvl(v_service_type,'ACD') != 'ACD' then v_remarks else null end, ----
          ucr                   =  CASE WHEN v_check_ucr_yn = 'Y' THEN v_ucr ELSE 0 END,
          denial_res_dis        = v_denial_res_dis,
          CURRENCY_TYPE         ='QAR',
          CONVERTED_ACITIVTY_AMT=v_unit_price,
          MOPH_CODES            = NVL(v_moph_codes,v_code),
          discount_amount_new   = v_discount_amount
      WHERE activity_dtl_seq_id =  v_activity_dtl_seq_id;


 END IF;
  --v_rows_processed:=SQL%ROWCOUNT;
  COMMIT;
END save_activity_details;

--=====================================================================
PROCEDURE select_pat_auth_details (
    v_pat_auth_seq_id                           IN  pat_authorization_details.pat_auth_seq_id%type,
    v_auth_result_set                           OUT SYS_REFCURSOR ,
    v_diag_result_set                           OUT SYS_REFCURSOR ,
    v_activity_result_set                       OUT SYS_REFCURSOR )

IS
CURSOR clinician_cur IS
   SELECT ad.hosp_seq_id,ad.clinician_id from  pat_authorization_details ad  WHERE ad.pat_auth_seq_id=v_pat_auth_seq_id;
   
   cln_rec    clinician_cur%rowtype;
   

CURSOR clinician_count_cur(v_clinician_id varchar2,v_hosp_seq_id number )IS
   SELECT count(1) FROM app.tpa_hosp_professionals hp
   WHERE hp.professional_id=v_clinician_id AND hp.hosp_seq_id=v_hosp_seq_id;

CURSOR pat_cur IS
    SELECT pad.hospitalization_date,pad.member_seq_id,pad.hosp_seq_id,nd.provider_id
      FROM pat_authorization_details pad 
      join pat_non_network_details nd on (pad.pat_auth_seq_id=nd.pat_auth_seq_id)
     WHERE pad.pat_auth_seq_id = v_pat_auth_seq_id;
     

CURSOR pat_dup_cur(v_member_seq_id pat_authorization_details.member_seq_id%type) IS
    SELECT pad.hospitalization_date
      FROM pat_authorization_details pad
     WHERE pad.member_seq_id = v_member_seq_id
       AND pad.pat_auth_seq_id != nvl(v_pat_auth_seq_id, 0)
     ORDER BY pad.hospitalization_date desc;  
  
CURSOR provider_networks(v_hosp_seq_id  tpa_hosp_info.hosp_seq_id%type) is 
select to_char(wm_concat(case when n.network_yn='Y' then n.network_type end )) as eligible_networks from tpa_hosp_info i join app.tpa_hosp_network n on (i.hosp_seq_id=n.hosp_seq_id)
join tpa_general_code gc on (gc.general_type_id=n.network_type)
where i.hosp_seq_id = v_hosp_seq_id;

pro_network  provider_networks%rowtype;

   v_count  number(10);
   v_alert  varchar2(1000):=null;
   pat_rec  pat_cur%rowtype; 
   
  
CURSOR pharmacy_cur IS 
 select b.disc_percent from app.PAT_AUTHORIZATION_DETAILS a join app.tpa_hosp_tariff_details b on (a.hosp_seq_id=b.HOSP_SEQ_ID)
 where b.acitivity_type_seq_id=5 
 AND a.HOSPITALIZATION_DATE BETWEEN  b.start_date AND NVL(b.end_date,a.HOSPITALIZATION_DATE)
 and a.pat_auth_seq_id=v_pat_auth_seq_id;
 

v_pharmacy_rec                number(10);

   CURSOR srtfll_cur IS
    SELECT sd.srtfll_status_general_type_id
    FROM SHORTFALL_DETAILS sd
    WHERE sd.shortfall_seq_id = (SELECT MAX(S.SHORTFALL_SEQ_ID)
                                 FROM SHORTFALL_DETAILS s
                                 WHERE S.PAT_GEN_DETAIL_SEQ_ID = v_pat_auth_seq_id
                                )
    AND sd.PAT_GEN_DETAIL_SEQ_ID = v_pat_auth_seq_id;
    
  v_shrtfll_status  VARCHAR2(10);
 /* cursor pbm_cur is
  select p.auth_number,a.ACTIVITY_DTL_SEQ_ID,A.denial_code,
 case when a.approved_amount >0 then 'Approved' else 'Rejected' end as activity_status 
  from APP.PAT_AUTHORIZATION_DETAILS p,APP.PAT_ACTIVITY_DETAILS a
  where a.PAT_AUTH_SEQ_ID=p.PAT_AUTH_SEQ_ID and a.PAT_AUTH_SEQ_ID = v_pat_auth_seq_id;

  pbm_rec pbm_cur%rowtype;
  v_result varchar2(50);*/

BEGIN
  OPEN srtfll_cur;
  FETCH srtfll_cur INTO v_shrtfll_status;
  CLOSE srtfll_cur;
  
  open clinician_cur;
  fetch clinician_cur into cln_rec;
  close clinician_cur;

 /* open pbm_cur;
  fetch pbm_cur into pbm_rec;
  close pbm_cur;*/

  open clinician_count_cur(cln_rec.clinician_id,cln_rec.hosp_seq_id);
  fetch clinician_count_cur into v_count;
  close clinician_count_cur;
  
  open pat_cur;
  fetch pat_cur into pat_rec;
  close pat_cur;
  
  /*FOR rec IN pat_dup_cur(pat_rec.member_seq_id) LOOP
    IF trunc(rec.hospitalization_date) = trunc(pat_rec.hospitalization_date)  THEN
      v_alert:='Duplicate Pre_auth ';
    END IF;
  END LOOP;*/--commented as per dr.Yasmin
  
  open provider_networks(pat_rec.hosp_seq_id);
  fetch provider_networks into pro_network;
  close provider_networks;
  
    open pharmacy_cur ; 
     fetch pharmacy_cur into v_pharmacy_rec ;
     close pharmacy_cur;
     
 OPEN v_auth_result_set FOR 
  select pad.pat_auth_seq_id,
          pad.pat_batch_seq_id,
          pad.claim_seq_id,
          case when v_alert is not null then v_alert else null end  as dup_pat,
          pad.parent_pat_auth_seq_id,
          NVL(to_char(pad.appeal_date, 'DD/MM/RRRR HH12:MI:SS AM'), to_char(pad.pat_received_date, 'DD/MM/RRRR HH12:MI:SS AM')) as pat_received_date,
          pad.source_type_id,
          case when nvl(v_count,0)=0 then 'Clinician is not exist under this provider, please check with network department.' end as clinician_status,
          to_char(pad.hospitalization_date,'dd/mm/yyyy') as hospitalization_date,
          to_char(pad.hospitalization_date,'dd/mm/yyyy') as prescreption_date,
          pad.discharge_date,
          pad.claim_sub_type,
          pad.member_seq_id,
          tepm.tpa_enrollment_id,
          null as quatar_id,
          pad.pre_auth_number,
          pad.auth_number,
          pad.mem_name,
          pad.mem_age,
          to_char(tepm.mem_dob,'dd/mm/yyyy') as mem_dob,
          pad.ins_seq_id,
          pad.hosp_seq_id,
          pad.policy_seq_id,
          (ep.policy_number||'('||ip.product_cat_type_id||')') as policy_number,
          (gr.group_name||'('||gr.group_id||')') as corp_name,
          pad.tpa_office_seq_id,
          pad.assign_user_seq_id,
          ep.enrol_type_id,
          pad.emirate_id,
          pad.authorization_id,
          pad.encounter_type_id,
          pad.encounter_start_type,
          pad.encounter_end_type,
          pad.encounter_facility_id,
          pad.authorization_type_id,
          pad.maternity_allowed_amt,
          nvl(pad.ava_sum_insured,(nvl(eb.sum_insured,0) - nvl(eb.utilised_sum_insured,0)))  as ava_sum_insured, 
          TO_CHAR(pad.tot_gross_amount) AS tot_gross_amount,
          pad.tot_discount_amount,
          pad.tot_disc_gross_amount,
          pad.tot_patient_share_amount,
          (nvl(pad.tot_disc_gross_amount,0)-nvl(pad.tot_patient_share_amount,0)) as tot_net_amount,
          pad.tot_allowed_amount,
          case when (pad.tot_disc_gross_amount-nvl(pad.tot_patient_share_amount,0))-nvl(pad.tot_approved_amount,0)>0 then
             (pad.tot_disc_gross_amount-nvl(pad.tot_patient_share_amount,0))-nvl(pad.tot_approved_amount,0) else 0 end  as dis_allowed_amount,
          nvl(pad.tot_approved_amount,0) as final_app_amount,
          pad.pat_enhanced_yn,
          pad.currency_type,
          /*case when pad.tot_approved_amount>0 then 'APR'
               when pad.tot_approved_amount<1  then 'REJ'
                
            ELSE pad.pat_status_type_id END AS pat_status_type_id,*/
          pad.pat_status_type_id AS pat_status_type_id,
          gg.description as pat_status_type_desc,
          pad.maternity_yn,
          pad.manual_process_req_yn,
          pad.denial_reason,
          pad.remarks,
          pad.completed_yn,
          to_char(pad.completed_date, 'DD/MM/RRRR HH12:MI AM') as decision_date,
          pad.added_by,
          to_char(pad.added_date,'dd/mm/yyyy hh12:mi AM') as transaction_date,
          pad.updated_by,
          pad.updated_date,
          pad.tot_approved_amount,
          nd.clinician_id,
          nd.clinician_name,
         nvl(thi.hosp_name,nd.provider_name) as hosp_name,
         tha.address_1 || ' ' || tha.address_2 || ' ' || tha.address_3 as hosp_address,
         case when pad.hosp_seq_id is not null then nvl(thi.hosp_licenc_numb,nd.provider_id)||'('||thi.primary_network||')' else nvl(thi.hosp_licenc_numb,nd.provider_id) end as provider_id,
         thi.primary_network,
         tii.ins_comp_name,
         tii.ins_comp_code_number as payer_id,
         account_info_pkg.get_gen_desc(tepm.gender_general_type_id,'G') AS gender,
         case when nvl(pad.network_yn,'N')='Y' then thp.contact_name||decode(thp.contact_name,null,thp.contact_name,'('||thp.professional_id||')') else nd.clinician_name end   as clinician_name,
         pad.presenting_complaints,
         pad.medical_opinion_remarks,
         pad.system_of_medicine_type_id,
         pad.accident_related_type_id,
         pad.priority_general_type_id,
         pad.network_yn,
         pad.requested_amount,
         nd.city_type_id,
         tcc.city_description,
         sc.state_name,
         cc.country_name,
         nd.state_type_id,
         nd.country_type_id,
         nd.provider_address,
         nd.pincode,
         pad.benifit_type as benifit_types,
         pad.gravida,
         pad.para,
         pad.live,
         pad.abortion,
         pad.currency_type,
         case when nvl(pad.parent_pat_auth_seq_id,0)!=0  then 'N' ELSE 'Y' END AS fresh_yn,
         ep.effective_from_date as policy_start_date,
         ep.effective_to_date as policy_end_date,
         nc.description as nationality,
         --nvl(eb.sum_insured,0) - nvl(eb.utilised_sum_insured,0) AS ava_sum_insured,
         eb.sum_insured,
         ip.product_name,
         tii.payer_authority,
         uc.contact_name as assigned_to,
         pro_network.eligible_networks as eligible_networks,
         to_char(tepm.date_of_inception, 'DD/MM/YYYY') as pat_mem_insp_date, --Insure Date
         case when nvl(tepm.vip_yn,'N')='N' then 'No' else 'Yes' end as vip_yn,

         pad.Oral_diagnosis as Oraldiagnosis,
         pad.Oral_services as Oralservices,
         pad.Orala_Aproved_amount as OralaAprovedamount,
         pad.Oral_system_Status as OralORsystemStatus,
         pad.Oral_diagnosis_revised as OralDiagnosisRevised,
         pad.Oral_services_revised as OralServicesRevised,
         pad.Orala_Aproved_amount_revised as OralaAprovedAmountRevised,
         nvl(thi.hosp_licenc_numb,nd.provider_id) as hospital_id,
         null as erx_ref,
         null as comments,
         pad.event_no,
         PAD.PAT_STATUS_TYPE_ID||'-'||COALESCE(v_shrtfll_status, CASE WHEN PAD.APPEAL_YN = 'Y' THEN 'APL' END, (CASE WHEN NVL(PAD.PARENT_PAT_AUTH_SEQ_ID, 0) > 0 THEN 'ENH' END)) AS IN_PROGESS_STATUS,
         PAD.APPEAL_REMARK,
         CASE WHEN length(dc.image_file) > 0 THEN 'Y' ELSE 'N' END AS docs_available_yn,
         PAD.TOT_DISC_GROSS_AMOUNT
          
    
    from pat_authorization_details pad
    left join pat_clm_docs_tab dc on dc.pat_clm_seq_id = pad.pat_auth_seq_id
    join tpa_enr_policy ep on (ep.policy_seq_id=pad.policy_seq_id)
    join tpa_ins_product ip on (ip.product_seq_id=ep.product_seq_id)
    left outer join tpa_group_registration gr on (gr.group_reg_seq_id=ep.group_reg_seq_id)
    left outer join tpa_enr_policy_member tepm ON (pad.member_seq_id=tepm.member_seq_id)
    left outer join tpa_enr_policy_group pg on (pg.policy_group_seq_id=tepm.policy_group_seq_id)
    left outer join tpa_hosp_info thi
      on (pad.hosp_seq_id = thi.hosp_seq_id)
    left outer join tpa_hosp_address tha
      on (thi.hosp_seq_id = tha.hosp_seq_id)
    join tpa_ins_info tii
      on (pad.ins_seq_id = tii.ins_seq_id)
    left outer join tpa_hosp_professionals thp 
      ON (pad.clinician_id=thp.professional_id and pad.hosp_seq_id=thp.hosp_seq_id)
    left outer join pat_non_network_details nd
      ON (nd.pat_auth_seq_id=pad.pat_auth_seq_id)
    left outer join  tpa_country_code cc
      ON (cc.country_id=nd.country_type_id)
    left outer join tpa_state_code sc 
      ON (sc.state_type_id=nd.state_type_id)
    left outer join tpa_city_code tcc
      ON (tcc.city_type_id=nd.city_type_id)
    left outer join tpa_nationalities_code nc on (nc.nationality_id=tepm.nationality_id)
    LEFT OUTER JOIN tpa_enr_balance eb ON (pg.policy_group_seq_id = eb.policy_group_seq_id)
    left outer join tpa_user_contacts uc on (uc.contact_seq_id=pad.added_by)
    LEFT OUTER JOIN tpa_general_code gg ON (pad.pat_status_type_id=gg.general_type_id)
    where pad.pat_auth_seq_id IN( v_pat_auth_seq_id)
    and  (tepm.mem_general_type_id != 'PFL' AND tepm.member_seq_id = eb.member_seq_id OR eb.member_seq_id IS NULL OR tepm.member_seq_id IS NULL);

 OPEN v_diag_result_set FOR 
       select dd.diag_seq_id,
             dd.pat_auth_seq_id,
             tic.icd_code as diagnosys_code,
             case when nvl(dd.primary_ailment_yn,'N')='Y' then 'Principal' else 'Secondary' end as primary_ailment_yn,
             tic.icd10_seq_id as icd_code_seq_id,
             tic.short_desc as icd_description
        from diagnosys_details dd
        left outer join tpa_icd10_master_details tic on (dd.diagnosys_code=tic.icd_code)
       where dd.pat_auth_seq_id =v_pat_auth_seq_id
   order by dd.diag_seq_id;
  
  OPEN v_activity_result_set FOR 
       select ad.activity_dtl_seq_id,
       ad.pat_auth_seq_id,
       ad.activity_id,
       ad.start_date,
       ad.s_no,
       ad.activity_type,
       ad.code as code,
       ad.quantity,
       (ad.disc_gross_amount-nvl(ad.patient_share_amount,0)) as net_amount,
       ad.clinician_id,
       ad.allow_yn,
       case when ad.remarks like ';%' then substr(ad.remarks,2) else ad.remarks end as remarks,
       md.ACTIVITY_DESCRIPTION as activity_description,--md.drug_name_pbm as activity_description,
       ad.activity_seq_id,
       account_info_pkg.get_gen_desc(ad.modifier,'G') AS modifier,
       case when ad.unit_type='PCKG' THEN 'Package'
            when ad.unit_type='LOSE' THEN 'Loose' 
            when ad.unit_type='NA' THEN 'NA' else null end as unit_type,
       ad.gross_amount,
       ad.discount_amount,
       ad.disc_gross_amount,
      case when ad.unit_type='PCKG' THEN
      ((md.package_price)- nvl((v_pharmacy_rec*nvl(md.PACKAGE_PRICE,0)/100),0))*ad.quantity
       else
       ad.disc_gross_amount end as req_amount,
       ad.posology_duration as duration_days,
       ad.patient_share_amount,
       --(case when ad.denial_code='error' then ad.denial_desc else tdc.denial_description end) as denial_desc,
       case when ad.denial_code like ';%' then substr(ad.denial_code,2) else ad.denial_code end as denial_code,
       case when ad.denial_desc like ';%' then substr(ad.denial_desc,2) else ad.denial_desc end as denial_desc,
       ad.allowed_amount,
       ad.approved_amount approved_amt,
       ad.out_of_pocket_amount,
       ad.co_ins_amount,
       ad.approvd_quantity  as approved_quantity,
       ad.unit_price,
       ad.override_yn,
       ad.override_remarks,
       ad.service_type,
       ad.service_code,
       case when (nvl(ad.disc_gross_amount,0)-nvl(ad.patient_share_amount,0))-nvl(ad.approved_amount,0)>0
        then (nvl(ad.disc_gross_amount,0)-nvl(patient_share_amount,0))-nvl(ad.approved_amount,0) else 0 end  as dis_allowed_amount,
        case when ad.approved_amount >0 then 'Approved' else 'Rejected' end as activity_status,
       to_char(PAT_RECEIVED_DATE,'dd/mm/yyyy') as date_approval,
        null as mi_ref,
        null as erx_ref,
        null as erx_instructions,
        ad.added_by as added_by        
      from  pat_activity_details ad
      left outer join tpa_pharmacy_master_details md on (ad.activity_seq_id = md.act_mas_dtl_seq_id)
      left outer join  pat_authorization_details pa on (ad.PAT_AUTH_SEQ_ID=pa.PAT_AUTH_SEQ_ID) 
      where  ad.pat_auth_seq_id = v_pat_auth_seq_id
     order by s_no;

/* for i in pbm_cur 
 loop
IF i.activity_status='Approved'  THEN--AND I.denial_code IS NULL
v_result:='APR';
EXIT;
ELSE
v_result :='REJ';
END IF; 
 end loop;

 IF v_result='APR' THEN
   update pat_authorization_details pad set pad.PAT_STATUS_TYPE_ID='APR',pad.completed_yn='Y'
   WHERE pad.auth_number  = pbm_rec.auth_number;
  else
   update pat_authorization_details pad set pad.PAT_STATUS_TYPE_ID='REJ',pad.completed_yn='Y'
   WHERE pad.auth_number  = pbm_rec.auth_number;
  end if;*/

END select_pat_auth_details;
---===========================================================================
PROCEDURE delete_diagnosys_details(v_seq_id             IN pat_authorization_details.pat_auth_seq_id%TYPE,
                                   v_diag_seq_id        IN diagnosys_details.diag_seq_id%type,
                                   v_rows_processed     OUT NUMBER) IS
CURSOR pat_diag_cur IS
SELECT pad.pat_status_type_id,pad.completed_yn
FROM pat_authorization_details pad
WHERE pad.pat_auth_seq_id = v_seq_id;



pat_rec           pat_diag_cur%ROWTYPE;       

BEGIN
  
 
   OPEN pat_diag_cur;
   FETCH pat_diag_cur INTO pat_rec;
   CLOSE pat_diag_cur;
   
   IF pat_rec.Pat_Status_Type_Id IN ('APR','REJ') and pat_rec.Completed_Yn='Y' THEN
     RAISE_APPLICATION_ERROR(-20376,'You cannot delete diagnosis details , Until Preauth/Claim Status is Compleate');
   ELSE
      DELETE FROM diagnosys_details dd 
      WHERE dd.diag_seq_id = v_diag_seq_id;
   END IF;
 
 
  
 v_rows_processed := SQL%ROWCOUNT;
 
 COMMIT;
END delete_diagnosys_details;
--===========================================================
PROCEDURE delete_activity_details(v_seq_id                       IN pat_authorization_details.pat_auth_seq_id%TYPE,
                                  v_activity_dtl_seq_id          IN pat_activity_details.activity_dtl_seq_id%type,
                                  v_rows_processed               OUT NUMBER) 
IS
CURSOR pat_act_cur IS
SELECT pad.pat_status_type_id,pad.completed_yn,ad.gross_amount,ad.discount_amount,ad.disc_gross_amount,ad.patient_share_amount,
ad.net_amount,ad.allowed_amount,ad.approved_amount
FROM pat_authorization_details pad join pat_activity_details ad on (pad.pat_auth_seq_id=ad.pat_auth_seq_id)
WHERE pad.pat_auth_seq_id = v_seq_id and ad.activity_dtl_seq_id=v_activity_dtl_seq_id;


pat_rec           pat_act_cur%ROWTYPE;       

BEGIN
  
 
   
   OPEN pat_act_cur;
   FETCH pat_act_cur INTO pat_rec;
   CLOSE pat_act_cur;
   
   IF pat_rec.Pat_Status_Type_Id IN ('APR','REJ') and pat_rec.Completed_Yn='Y' THEN
     RAISE_APPLICATION_ERROR(-20377,'You cannot delete Activity details , Until Preauth/Claim Status is Complete');
    ELSE
      update pat_authorization_details ad 
      set ad.tot_gross_amount         = nvl(ad.tot_gross_amount,0)-nvl(pat_rec.gross_amount,0),
          ad.tot_discount_amount      = nvl(ad.tot_discount_amount,0)-nvl(pat_rec.discount_amount,0),
          ad.tot_disc_gross_amount    = nvl(ad.tot_disc_gross_amount,0)-nvl(pat_rec.disc_gross_amount,0),
          ad.tot_patient_share_amount = nvl(ad.tot_patient_share_amount,0)-nvl(pat_rec.patient_share_amount,0),
          ad.tot_net_amount           = nvl(ad.tot_net_amount,0)-nvl(pat_rec.net_amount,0),
          ad.tot_allowed_amount       = nvl(ad.tot_allowed_amount,0)-nvl(pat_rec.allowed_amount,0),
          ad.tot_approved_amount      = nvl(ad.tot_approved_amount,0)-nvl(pat_rec.approved_amount,0) 
        where ad.pat_auth_seq_id=v_seq_id;
      
      DELETE pat_observation_details d 
      WHERE d.activity_dtl_seq_id=v_activity_dtl_seq_id;
      
      DELETE FROM pat_activity_details pad
      WHERE pad.activity_dtl_seq_id=v_activity_dtl_seq_id;
   END IF;
  
  v_rows_processed:=SQL%ROWCOUNT;
  COMMIT;
END delete_activity_details;

-----==========================================================================
PROCEDURE calculate_authorization(v_pat_auth_seq_id            IN  pat_authorization_details.pat_auth_seq_id%type,
                                  v_hosp_seq_id                IN  pat_authorization_details.hosp_seq_id%TYPE,
                                  v_allowed_amount             OUT  pat_authorization_details.Tot_Allowed_Amount%TYPE,
                                  v_added_by                   IN  NUMBER
                                  )
IS



CURSOR act_cur IS
SELECT SUM(NVL(pa.gross_amount,0)) as tot_gross_amount
      ,SUM(NVL(pa.discount_amount,0)) as tot_discount_amount
      ,SUM(NVL(pa.disc_gross_amount,0)) as tot_disc_gross_amount
      ,SUM(NVL(pa.patient_share_amount,0)) as tot_patient_share_amount
      ,SUM(NVL(pa.net_amount,0)) as tot_net_amount
      ,SUM(NVL(pa.allowed_amount,0)) as tot_allowed_amount
      ,SUM(NVL(pa.approved_amount,0)) as tot_approved_amount

 FROM pat_activity_details pa
WHERE pa.pat_auth_seq_id=v_pat_auth_seq_id
AND pa.allow_yn='Y';

CURSOR pat_cur IS
  SELECT pad.denial_reason,pad.denial_code,pad.remarks,pad.completed_yn,pad.member_seq_id,
   to_date(pad.hospitalization_date,'dd/mm/rrrr') as hospitalization_date,pad.network_yn,pad.benifit_type  
     FROM pat_authorization_details pad
     WHERE pad.pat_auth_seq_id=v_pat_auth_seq_id;
 
CURSOR enrol_type IS
select ep.enrol_type_id,ep.policy_seq_id from app.tpa_enr_policy ep join app.pat_authorization_details ad on (ep.policy_seq_id=ad.policy_seq_id)
where ad.pat_auth_seq_id=v_pat_auth_seq_id;

enrol_rec   enrol_type%rowtype;
act_rec                    act_cur%ROWTYPE;
pat_rec                    pat_cur%ROWTYPE;

CURSOR floater_cur(v_policy_group_seq_id    tpa_enr_policy_group.policy_group_seq_id%type,v_admission_date   date)
 IS 
SELECT a.policy_group_seq_id,
       SUM(A.mem_sum_insured) AS sum_insured,
       b.sum_insured as tot_sum_insured,
       b.utilised_sum_insured  FROM tpa_enr_mem_insured a
JOIN tpa_enr_balance b on (a.policy_group_seq_id=b.policy_group_seq_id)
WHERE a.policy_group_seq_id=v_policy_group_seq_id
AND a.policy_date<=v_admission_date
GROUP BY a.policy_group_seq_id,b.sum_insured,b.utilised_sum_insured;

CURSOR nonfloater_cur(v_member_seq_id    tpa_enr_policy_member.member_seq_id%type,v_admission_date   date)
 IS 
SELECT a.member_seq_id,
       SUM(A.mem_sum_insured) AS sum_insured,
       b.sum_insured as tot_sum_insured,
       b.utilised_sum_insured
       
FROM tpa_enr_mem_insured a
JOIN tpa_enr_balance b on (a.policy_group_seq_id=b.policy_group_seq_id)
WHERE a.member_seq_id=v_member_seq_id
AND a.policy_date<=v_admission_date
GROUP BY a.member_seq_id,b.sum_insured,b.utilised_sum_insured;
sum_rec              floater_cur%rowtype;

CURSOR mem_cur (v_member_seq_id    tpa_enr_policy_member.member_seq_id%type) IS
SELECT a.date_of_inception,a.date_of_exit,a.member_seq_id,b.policy_group_seq_id,c.policy_seq_id,c.policy_sub_general_type_id FROM tpa_enr_policy_member a
JOIN tpa_enr_policy_group b on (a.policy_group_seq_id=b.policy_group_seq_id)
JOIN tpa_enr_policy c on (b.policy_seq_id=c.policy_seq_id)
WHERE a.member_seq_id=v_member_seq_id;

CURSOR pat_act_cur IS
SELECT pad.activity_dtl_seq_id,
       pad.pat_auth_seq_id,
       pad.allowed_amount,
       pad.approved_amount
      FROM pat_activity_details pad
      where pad.pat_auth_seq_id=v_pat_auth_seq_id;

mem_rec              mem_cur%ROWTYPE;
v_ava_sum_insured    tpa_enr_balance.utilised_sum_insured%type;
v_remarks            varchar2(100);
v_max_act            number(10);
v_member_seq_id      number(10);
v_chronic_count      number(10);
v_final_allowed_amount  number;

BEGIN
    
    OPEN pat_cur;
    FETCH pat_cur INTO pat_rec;
    CLOSE pat_cur;
    
    open mem_cur(pat_rec.member_seq_id);
    fetch mem_cur into mem_rec;
    close mem_cur;
     
    IF mem_rec.policy_sub_general_type_id='PFL' THEN
      OPEN floater_cur(mem_rec.policy_group_seq_id,pat_rec.hospitalization_date);
      FETCH floater_cur INTO sum_rec;
      CLOSE floater_cur;
    ELSIF  mem_rec.policy_sub_general_type_id='PNF' THEN
      OPEN nonfloater_cur(mem_rec.member_seq_id,pat_rec.hospitalization_date);
      FETCH nonfloater_cur INTO sum_rec;
      CLOSE nonfloater_cur;
    END IF; 
    v_ava_sum_insured:=(NVL(sum_rec.sum_insured,0)-NVL(sum_rec.utilised_sum_insured,0)) ;  

    --IF NVL(v_prod_policy_rule_seq_id,0)=0 THEN 
    OPEN enrol_type;
    FETCH enrol_type INTO enrol_rec;
    CLOSE enrol_type;
    --END IF;
     IF enrol_rec.enrol_type_id='IND' THEN
       v_prod_policy_rule_seq_id:=authorization_pkg.get_prod_pol_seq_id(enrol_rec.policy_seq_id,'IND');
     ELSE
       v_prod_policy_rule_seq_id:=authorization_pkg.get_prod_pol_seq_id(enrol_rec.policy_seq_id,'POL');
     END IF; 
    
   IF pat_rec.Completed_Yn='Y' THEN
    RAISE_APPLICATION_ERROR(-20107,'You cannot perform this action through a completed Claim.');
   END IF;
   
   
   --IF pat_rec.Denial_Reason is null THEN
     
     update pat_activity_details ad set 
      ad.denial_code=case when (nvl(ad.override_yn,'N')='N' and ad.denial_desc is not null) or (nvl(ad.override_yn,'N')='Y' and ad.denial_desc is not null) then null else ad.denial_code end,
      ad.remarks=null,
      ad.denial_desc=case when (nvl(ad.override_yn,'N')='N' and ad.denial_desc is not null) or (nvl(ad.override_yn,'N')='Y' and ad.denial_desc is not null) then null else ad.denial_desc end,
      ad.patient_share_amount=case when nvl(ad.override_yn,'N')='N' then 0 else ad.patient_share_amount end,
      ad.allowed_amount=null,
      ad.approved_amount=null 
      where ad.pat_auth_seq_id=v_pat_auth_seq_id 
      and nvl(ad.override_yn,'N')='N' and nvl(ad.service_type,'ACD')='ACD';
      
      update diagnosys_details dd 
      set dd.denial_reason=null,
          dd.remarks=null
       where dd.pat_auth_seq_id=v_pat_auth_seq_id;
       
      update pat_authorization_details pad
      set pad.benefit_limit=null,
          pad.benefit_copay=null,
          pad.tot_allowed_amount=null,
          pad.tot_approved_amount=null
          where pad.pat_auth_seq_id = v_pat_auth_seq_id;
      
   
    IF pat_rec.Denial_Reason is not null THEN
      UPDATE pat_activity_details pad
               SET pad.denial_desc  = pat_rec.Denial_Reason,
                   pad.denial_code  = pat_rec.denial_code,
                   pad.remarks      = pat_rec.remarks,
                   pad.updated_by   = v_added_by,
                   pad.updated_date = SYSDATE
             WHERE pad.pat_auth_seq_id = v_pat_auth_seq_id;
    end if;
    commit; 
   /* select count(1) into v_chronic_count from  
    app.pat_authorization_details d join app.diagnosys_details dd on (d.pat_auth_seq_id=dd.pat_auth_seq_id and d.benifit_type='OPTS')
    join app.tpa_day_care_icd c on (c.icd_code=dd.diagnosys_code and dd.primary_ailment_yn='Y') where d.pat_auth_seq_id=v_pat_auth_seq_id;*/
    -- commented by venu babu we are not using v_chronic_count variable
    -------pbm rules----------------------------------------
    check_mdcl_necessity_rules_1(v_pat_auth_seq_id,'PAT',v_added_by);	
    check_therapeutic_rule_2(v_pat_auth_seq_id,'PAT',v_added_by);
    check_ci_icd_ddc_rules_3(v_pat_auth_seq_id,'PAT',v_added_by);
    check_ci_ddc_ddc_generic(v_pat_auth_seq_id,'PAT',v_added_by);
    check_age_band_rule_4(v_pat_auth_seq_id,'PAT',v_added_by);
    check_gender_rule_5(v_pat_auth_seq_id,'PAT',v_added_by);
    priliminary_check_rule_6(v_pat_auth_seq_id,'PAT',v_added_by);
    check_refill_to_soon_7(v_pat_auth_seq_id,'PAT' ,pat_rec.member_seq_id,v_added_by);
    check_mat_icd_ddc_rule_8(v_pat_auth_seq_id,'PAT',v_added_by);
    check_mat_fda_risk_rule(v_pat_auth_seq_id,'PAT',v_added_by);
    pat_xml_load_pkg.execute_sec_icd_mat_rule(v_pat_auth_seq_id,'PAT' ,v_prod_policy_rule_seq_id  ,v_added_by);
    -------pbm rules----------------------------------------
    pat_xml_load_pkg.check_duplicate_activity(v_pat_auth_seq_id,'PAT',v_added_by);
    --pat_xml_load_pkg.check_ddc_rule(v_pat_auth_seq_id,'PAT',v_added_by);
    pat_xml_load_pkg.execute_diag_rule(v_pat_auth_seq_id,'PAT' ,v_prod_policy_rule_seq_id  ,v_added_by);     
    pat_xml_load_pkg.execute_activity_rule(v_pat_auth_seq_id,'PAT',v_prod_policy_rule_seq_id  ,v_added_by  );
            
    IF pat_rec.benifit_type='DNTL' THEN
    authorization_pkg.check_overal_limit(v_pat_auth_seq_id,'PAT',v_prod_policy_rule_seq_id);
    END IF;
    pat_xml_load_pkg.admin_activity_rule('PAT',v_pat_auth_seq_id);
    pat_xml_load_pkg.calculate_allowed_amount( v_pat_auth_seq_id,'PAT');

    OPEN act_cur;
    FETCH act_cur INTO act_rec;
    CLOSE act_cur;
     
    UPDATE pat_authorization_details A
    SET a.tot_gross_amount           = act_rec.tot_gross_amount,
        a.tot_discount_amount        = act_rec.tot_discount_amount,
        a.tot_disc_gross_amount      = act_rec.tot_disc_gross_amount,
        a.tot_patient_share_amount   = act_rec.tot_patient_share_amount,
        a.tot_net_amount             = act_rec.tot_net_amount,
        a.tot_allowed_amount         = act_rec.tot_allowed_amount,
        a.tot_approved_amount        = act_rec.tot_approved_amount,
        a.remarks                    = v_remarks
   WHERE a.pat_auth_seq_id           = v_pat_auth_seq_id
   RETURNING a.tot_approved_amount INTO v_allowed_amount;

  pat_xml_load_pkg.execute_global_amnt_rules('P',v_pat_auth_seq_id,pat_rec.member_seq_id,v_Prod_Policy_Rule_Seq_Id);
  authorization_pkg.check_pat_approved(v_pat_auth_seq_id,v_added_by);
  pat_xml_load_pkg.check_policy_date_valid(v_pat_auth_seq_id ,'PAT' ,v_added_by);
  authorization_pkg.check_activity_limits(v_pat_auth_seq_id,'PAT',v_allowed_amount,v_added_by,v_remarks,v_final_allowed_amount);
  
   
  UPDATE pat_activity_details pad
               SET pad.denial_desc  = replace(pad.denial_desc,';;',';')
                   WHERE pad.pat_auth_seq_id = v_pat_auth_seq_id ;
  
 commit;
     
 
END calculate_authorization;
--=============================================================================
PROCEDURE save_authorization(v_pat_auth_seq_id                 IN pat_authorization_details.Pat_Auth_Seq_Id%TYPE,
                             v_member_seq_id                   IN pat_authorization_details.member_seq_id%TYPE,
                             v_auth_number                     IN OUT pat_authorization_details.Auth_Number%TYPE,
                             v_admission_date                  IN pat_authorization_details.hospitalization_date%type,
                             v_allowed_amount                  IN pat_authorization_details.Tot_Allowed_Amount%TYPE,
                             v_pat_status_type_id              IN OUT pat_authorization_details.Pat_Status_Type_Id%TYPE,
                             v_added_by                        IN  NUMBER,
                             v_rows_processed                  OUT NUMBER)
IS

CURSOR mem_cur IS
SELECT a.date_of_inception,a.date_of_exit,a.member_seq_id,b.policy_group_seq_id,c.policy_seq_id,c.policy_sub_general_type_id FROM tpa_enr_policy_member a
JOIN tpa_enr_policy_group b on (a.policy_group_seq_id=b.policy_group_seq_id)
JOIN tpa_enr_policy c on (b.policy_seq_id=c.policy_seq_id)
WHERE a.member_seq_id=v_member_seq_id;

mem_rec             mem_cur%ROWTYPE;

CURSOR pat_cur IS
SELECT * FROM pat_authorization_details pad
WHERE pad.pat_auth_seq_id=v_pat_auth_seq_id;

pat_rec  pat_cur%rowtype;
CURSOR floater_cur(v_policy_group_seq_id    tpa_enr_policy_group.policy_group_seq_id%type)
 IS 
SELECT a.policy_group_seq_id,
       SUM(A.mem_sum_insured) AS sum_insured,
       b.sum_insured as tot_sum_insured,
       b.utilised_sum_insured  FROM tpa_enr_mem_insured a
JOIN tpa_enr_balance b on (a.policy_group_seq_id=b.policy_group_seq_id)
WHERE a.policy_group_seq_id=v_policy_group_seq_id
--AND a.policy_date<=v_admission_date
GROUP BY a.policy_group_seq_id,b.sum_insured,b.utilised_sum_insured;

CURSOR nonfloater_cur(v_member_seq_id    tpa_enr_policy_member.member_seq_id%type)
 IS 
SELECT a.member_seq_id,
       SUM(A.mem_sum_insured) AS sum_insured,
       b.sum_insured as tot_sum_insured,
       b.utilised_sum_insured
       
FROM tpa_enr_mem_insured a
JOIN tpa_enr_balance b on (a.member_seq_id=b.member_seq_id)
WHERE a.member_seq_id=v_member_seq_id
--AND a.policy_date<=v_admission_date
GROUP BY a.member_seq_id,b.sum_insured,b.utilised_sum_insured;

CURSOR shortfall_count IS 
SELECT COUNT(1)  FROM APP.shortfall_details s where 
 s.srtfll_status_general_type_id='OPN' and s.pat_gen_detail_seq_id=v_pat_auth_seq_id ;
  

sum_rec              floater_cur%rowtype;
v_ava_sum_insured    tpa_enr_balance.utilised_sum_insured%type;
v_app_amount         pat_authorization_details.final_app_amount%type;
v_reason             pat_authorization_details.remarks%type;
v_denial_reason      pat_authorization_details.denial_reason%type;
v_count              number(10);
v_dest_msg_seq_id    VARCHAR2(250);
v_out_preauth xmltype;
V_MODIFIED_DATE      NUMBER;
BEGIN
  
  OPEN mem_cur;
  FETCH mem_cur INTO mem_rec;
  CLOSE mem_cur;
  
  OPEN pat_cur;
  FETCH pat_cur INTO pat_rec;
  CLOSE pat_cur;
  
  IF pat_rec.Completed_Yn='Y' THEN
    RAISE_APPLICATION_ERROR(-20107,'You cannot perform this action through a completed Claim.');
  END IF;
  
  open shortfall_count;
  fetch shortfall_count into v_count;
  close shortfall_count;
  
  IF v_count>0 and v_pat_status_type_id ='APR'then 
    RAISE_APPLICATION_ERROR(-20387,'Please close the opened shortfall before complete the Pre_auth/Claim.');
  END IF;
   
   IF mem_rec.policy_sub_general_type_id='PFL' THEN
    OPEN floater_cur(mem_rec.policy_group_seq_id);
    FETCH floater_cur INTO sum_rec;
    CLOSE floater_cur;
   ELSIF  mem_rec.policy_sub_general_type_id='PNF' THEN
    OPEN nonfloater_cur(mem_rec.member_seq_id);
    FETCH nonfloater_cur INTO sum_rec;
    CLOSE nonfloater_cur;
  END IF; 
  
  v_ava_sum_insured:=(NVL(sum_rec.sum_insured,0)-NVL(sum_rec.utilised_sum_insured,0)) ;  
     
    IF v_pat_status_type_id='APR' THEN
      IF v_allowed_amount<=v_ava_sum_insured THEN
         v_app_amount:=v_allowed_amount; 
      ELSE 
         RAISE_APPLICATION_ERROR(-20737,'Sufficient Balance doesnot exist');
      END IF;   
    ELSIF v_pat_status_type_id='REJ' THEN
          v_app_amount:=0;
    END IF; 
    
 
  IF v_auth_number IS NULL THEN
    v_auth_number:=authorization_pkg.generate_id_numbers('AT','QAT',NULL,pat_rec.pre_auth_number);
  END IF;
  
   
   UPDATE pat_authorization_details a
     SET A.final_app_amount   = v_app_amount,
         a.CONVERTED_FINAL_APPROVED_AMT   = v_app_amount,
         a.pat_status_type_id = v_pat_status_type_id ,
         a.denial_reason      = v_denial_reason,
         A.auth_number        = v_auth_number,
         A.completed_yn       = case when v_pat_status_type_id IN ('REJ','CAN','APR') THEN 'Y' ELSE 'N' END,
         a.completed_date     = case when v_pat_status_type_id IN ('REJ','CAN','APR') THEN sysdate end,
         a.updated_by         = v_added_by,
         a.updated_date       = SYSDATE,
         a.authorized_by      = 1,
         a.processed_by       =  case when v_pat_status_type_id IN ('REJ','CAN','APR') THEN 1 else null end
     WHERE A.pat_auth_seq_id  = v_pat_auth_seq_id;
     
     update APP.TPA_USER_CONTACTS set prefix_general_type_id=null
     where CONTACT_SEQ_ID=1;
 
 IF v_pat_status_type_id='APR' then
 
 /*v_out_preauth:= pat_xml_load_pkg.upload_priorAuth_xml(v_pat_auth_seq_id);
 
 update pat_upload_dhpo_dtls d 
 set d.upload_file = v_out_preauth,
     d.added_by    = v_added_by,
     d.added_date  = sysdate ,
     d.up_load_status='N'
  where d.pat_seq_id = v_pat_auth_seq_id;*/
 
 IF mem_rec.policy_sub_general_type_id='PFL' THEN    
   UPDATE tpa_enr_balance b
   SET b.utilised_sum_insured = nvl(b.utilised_sum_insured,0) + v_app_amount,
       b.updated_by           = v_added_by,
       b.updated_date         = SYSDATE
   WHERE b.policy_group_seq_id = mem_rec.policy_group_seq_id;
 ELSIF mem_rec.policy_sub_general_type_id='PNF' THEN  
  UPDATE tpa_enr_balance b
   SET b.utilised_sum_insured = nvl(b.utilised_sum_insured,0) + v_app_amount,
       b.updated_by           = v_added_by,
       b.updated_date         = SYSDATE
   WHERE b.member_seq_id      = mem_rec.member_seq_id; 
 END IF;
 END IF;
 
 v_rows_processed:=SQL%ROWCOUNT;
 
 IF v_rows_processed > 0 THEN
   SELECT NVL(COUNT(FIRST_MODIFIED_DATE), 0) INTO V_MODIFIED_DATE
   FROM PAT_AUTHORIZATION_DETAILS P
   WHERE P.PAT_AUTH_SEQ_ID = v_pat_auth_seq_id;
   
   IF V_MODIFIED_DATE = 0 THEN
     UPDATE PAT_AUTHORIZATION_DETAILS P
     SET P.FIRST_MODIFIED_DATE = SYSDATE
     WHERE P.PAT_AUTH_SEQ_ID = v_pat_auth_seq_id;
   END IF;
 END IF;
 
COMMIT; 

  
    
  
END save_authorization;
--=============================================================================
PROCEDURE generate_authorization(v_pat_auth_seq_id                 IN pat_authorization_details.Pat_Auth_Seq_Id%TYPE,
                                 v_added_by                        IN  NUMBER)
IS


CURSOR pat_cur IS
SELECT pad.pat_status_type_id,pad.Completed_Yn,
       pad.hosp_seq_id,pad.tot_approved_amount,pad.member_seq_id,
       pad.auth_number,pad.hospitalization_date,i.amount_limit
FROM pat_authorization_details pad
LEFT OUTER JOIN app.tpa_hosp_info i ON (pad.hosp_seq_id=i.hosp_seq_id)
WHERE pad.pat_auth_seq_id=v_pat_auth_seq_id;

CURSOR tot_req_amount IS
  SELECT sum(p.disc_gross_amount)
  FROM Pat_Activity_Details p
  Where p.pat_auth_seq_id = v_pat_auth_seq_id;
  
v_tot_req_amount          NUMBER(15,2);

 pat_rec  pat_cur%rowtype;
 v_allowed_amount         number;
 v_rows_processed         number;
 
   CURSOR vip_nvip_cursor(v_pat_seq_id number)IS 
   select b.vip_yn from pat_authorization_Details a join   tpa_enr_policy_member b
   on ( a.MEMBER_SEQ_ID=b.MEMBER_SEQ_ID) where a.pat_auth_seq_id =  v_pat_seq_id;
   
   vip_nvip_rec           tpa_enr_polIcy_member.VIP_YN%TYPE;
   v_pre_auth_number      PAT_AUTHORIZATION_DETAILS.PRE_AUTH_NUMBER%TYPE;
   v_dest_msg_seq_id      DESTINATION_MESSAGE.DEST_MSG_SEQ_ID%TYPE;
BEGIN
  
 
  
  OPEN pat_cur;
  FETCH pat_cur INTO pat_rec;
  CLOSE pat_cur;
  
  IF pat_rec.Completed_Yn='Y' THEN
    RAISE_APPLICATION_ERROR(-20107,'You cannot perform this action through a completed Claim.');
  END IF;
     
  calculate_authorization(v_pat_auth_seq_id,pat_rec.hosp_seq_id,v_allowed_amount,v_added_by);
  
  OPEN tot_req_amount;
  FETCH tot_req_amount INTO v_tot_req_amount;
  CLOSE tot_req_amount;
  
  UPDATE pat_authorization_details a
  Set a.REQUESTED_AMOUNT   = v_tot_req_amount,
      a.CONVERTED_AMOUNT   = v_tot_req_amount,
      a.conversion_rate    = 1
  Where a.pat_auth_seq_id = v_pat_auth_seq_id;
 
SELECT PRE_AUTH_NUMBER INTO  v_pre_auth_number FROM PAT_AUTHORIZATION_DETAILS WHERE PAT_AUTH_SEQ_ID=v_pat_auth_seq_id;
     IF v_pat_auth_seq_id IS NOT NULL  THEN
      OPEN vip_nvip_cursor(v_pat_auth_seq_id);
      fetch vip_nvip_cursor into vip_nvip_rec;
      close  vip_nvip_cursor;
      
      IF NVL(vip_nvip_rec,'N')='Y' and v_pat_auth_seq_id is not null and v_pre_auth_number is not null THEN
        GENERATE_MAIL_PKG.proc_generate_message('VIP_PAT_UPLOADED',v_pat_auth_seq_id,v_added_by,v_dest_msg_seq_id);
        GENERATE_MAIL_PKG.proc_generate_message('VIP_PREAPPROVAL',v_pat_auth_seq_id,v_added_by,v_dest_msg_seq_id);
      END IF;
      END IF;
 
  Commit;
  
END generate_authorization;
--==============================================================================
PROCEDURE comp_preauth (v_pat_auth_seq_id                 IN pat_authorization_details.Pat_Auth_Seq_Id%TYPE,
                        v_added_by                        IN  NUMBER)
 IS
  
  CURSOR pat_cur IS
    SELECT pad.pat_status_type_id,pad.Completed_Yn,
           pad.hosp_seq_id,pad.tot_approved_amount,pad.member_seq_id,
           pad.auth_number,pad.hospitalization_date,i.amount_limit,
           i.OPTS_LIMIT,i.OPTC_LIMIT,i.DNTL_LIMIT,i.OMTI_LIMIT,pad.benifit_type,pad.policy_seq_id
    FROM pat_authorization_details pad
    LEFT OUTER JOIN app.tpa_hosp_info i ON (pad.hosp_seq_id=i.hosp_seq_id)
    WHERE pad.pat_auth_seq_id=v_pat_auth_seq_id;

 cursor unit_cur is 
     select bb.PAT_AUTH_SEQ_ID,aa.GRANULAR_UNIT,bb.QUANTITY,bb.UNIT_TYPE,bb.POSOLOGY_DURATION 
     from pat_activity_details bb 
     join tpa_pharmacy_master_details aa on aa.ACTIVITY_CODE =bb.code 
     where bb.PAT_AUTH_SEQ_ID=v_pat_auth_seq_id;  

 cursor stop_pat_cur(v_hosp_date date) is
    SELECT 
         case when tepg.stop_pat_clm_process_yn='Y' and trunc(v_hosp_date)>=trunc(tepg.recieved_after) then 'Y' end as emp_stop_yn,
         case when tepm.stop_pat_clm_process_yn='Y' and trunc(v_hosp_date)>=trunc(tepm.recieved_after) then 'Y' end as mem_stop_yn,
         case when tipp.stop_preauth_yn='Y' and trunc(v_hosp_date)>=trunc(tipp.stop_preauth_date) then 'Y' end as pol_stop_yn,
         case when i.stop_preauth_yn='Y' and trunc(v_hosp_date)>=trunc(i.stop_preauth_date) then 'Y' end as pro_stop_yn
      FROM pat_authorization_details pad  
      JOIN tpa_enr_policy_member tepm ON (pad.member_seq_id = tepm.member_seq_id)
      JOIN tpa_enr_policy_group tepg  ON (tepg.policy_group_seq_id = tepm.policy_group_seq_id)
      LEFT OUTER JOIN tpa_ins_prod_policy tipp ON (tepg.policy_seq_id = tipp.policy_seq_id)
      LEFT OUTER JOIN app.tpa_hosp_info i ON (pad.hosp_seq_id=i.hosp_seq_id)
      WHERE pad.pat_auth_seq_id = v_pat_auth_seq_id;


 pat_rec  pat_cur%rowtype;
 stop_rec stop_pat_cur%rowtype;
 v_allowed_amount         number;
 v_rows_processed         number;
 v_tot_act_cnt            NUMBER(10);
 v_tot_act_fail_cnt       NUMBER(10);
 v_tot_act_revw_cnt       NUMBER(10);
 v_tot_act_apr_cnt        NUMBER(10);
 v_denial_cd_cnt          NUMBER(10);
 v_benifit_limit          NUMBER(15,2);
 V_MED_STATUS            CHAR:=null;
 v_tot_units              number:=null;

 BEGIN
   
  OPEN  pat_cur;
  FETCH pat_cur INTO pat_rec;--this is also required, since after calculate allowed amount req
  CLOSE pat_cur; 
  
  OPEN stop_pat_cur(pat_rec.hospitalization_date);
  FETCH stop_pat_cur INTO stop_rec;
  CLOSE stop_pat_cur;
          
for unit_rec in unit_cur loop

if unit_rec.UNIT_TYPE='LOSE' THEN
v_tot_units:= unit_rec.QUANTITY;
elsif unit_rec.UNIT_TYPE='PCKG' THEN
v_tot_units:=unit_rec.GRANULAR_UNIT*unit_rec.QUANTITY;
end if;

if v_tot_units>=270 then
V_MED_STATUS:= CASE WHEN V_MED_STATUS!='Y' or V_MED_STATUS is null  THEN 'Y'  ELSE V_MED_STATUS END; 
end if;
--if unit_rec.POSOLOGY_DURATION>=60 then
--V_MED_STATUS:= CASE WHEN V_MED_STATUS!='Y' or V_MED_STATUS is null THEN 'Y' ELSE V_MED_STATUS END;
--end if;
end loop; 
  
  SELECT COUNT(1) INTO v_tot_act_cnt
  FROM app.pat_activity_details a 
  WHERE a.pat_auth_seq_id = v_pat_auth_seq_id;
  
  SELECT COUNT(1) INTO v_tot_act_revw_cnt
  FROM app.pat_activity_details a 
  WHERE a.pat_auth_seq_id = v_pat_auth_seq_id
    AND a.edit_rank LIKE '%2%';
    
  SELECT COUNT(1) INTO v_tot_act_fail_cnt
  FROM app.pat_activity_details a 
  WHERE a.pat_auth_seq_id = v_pat_auth_seq_id
    AND a.edit_rank LIKE '%1%';
    
  SELECT COUNT(1) INTO v_tot_act_apr_cnt
  FROM app.pat_activity_details a 
  WHERE a.pat_auth_seq_id = v_pat_auth_seq_id
    AND (a.edit_rank IS NULL OR a.denial_code IS NOT NULL);  
    
  SELECT COUNT(1) INTO v_denial_cd_cnt
  FROM app.pat_activity_details a 
  WHERE a.pat_auth_seq_id = v_pat_auth_seq_id
    AND a.denial_code is not null AND a.edit_rank IS NULL;
    
   v_benifit_limit:= nvl((CASE WHEN pat_rec.benifit_type ='DNTL' THEN pat_rec.dntl_limit
                           WHEN pat_rec.benifit_type ='OPTS' THEN pat_rec.opts_limit
                           WHEN pat_rec.benifit_type ='OPTC' THEN pat_rec.optc_limit 
                           WHEN pat_rec.benifit_type ='OMTI' THEN pat_rec.omti_limit else 0 END),0);
       
  pat_rec.pat_status_type_id := CASE WHEN v_tot_act_fail_cnt = v_tot_act_cnt THEN 'REJ'
                                     WHEN v_denial_cd_cnt = v_tot_act_cnt and NVL(pat_rec.tot_approved_amount,0) = 0 THEN 'REJ'
                                     WHEN v_denial_cd_cnt = v_tot_act_cnt and NVL(pat_rec.tot_approved_amount,0) > 0 THEN 'INP'
                                     WHEN v_tot_act_revw_cnt > 0 THEN 'INP'
                                     when V_MED_STATUS='Y' THEN 'INP'
                                     WHEN NVL(pat_rec.tot_approved_amount,0) > 0 AND NVL(pat_rec.tot_approved_amount,0) > v_benifit_limit THEN 'INP'--NVL(pat_rec.amount_limit,1000) THEN 'INP'
                                     WHEN NVL(pat_rec.tot_approved_amount,0) > 0 and v_tot_act_apr_cnt > 0 THEN 'APR'
                                       ELSE 'INP' END;
   ----- stop preauth cr
  IF (stop_rec.pol_stop_yn = 'Y' OR stop_rec.emp_stop_yn = 'Y' OR stop_rec.mem_stop_yn = 'Y' OR stop_rec.pro_stop_yn = 'Y') AND pat_rec.pat_status_type_id = 'APR' THEN
        pat_rec.pat_status_type_id := 'INP';
  END IF;
  
  IF pat_rec.pat_status_type_id NOT IN ('INP')  THEN
      save_authorization(v_pat_auth_seq_id,pat_rec.member_seq_id,pat_rec.auth_number,pat_rec.hospitalization_date,pat_rec.tot_approved_amount,pat_rec.pat_status_type_id,v_added_by,v_rows_processed);
  END IF; 
END comp_preauth;
--==============================================================================FUNCTION get_prod_pol_seq_id(v_seq_id IN pat_general_details.pat_gen_detail_seq_id%type,
FUNCTION get_prod_pol_seq_id(v_seq_id IN pat_general_details.pat_gen_detail_seq_id%type,
                             v_flag in varchar2 
                             ) RETURN NUMBER IS


  CURSOR pat_cur IS
     SELECT pad.policy_seq_id,tep.enrol_type_id
     FROM pat_authorization_details pad
     JOiN tpa_enr_policy tep ON (pad.policy_seq_id=tep.policy_seq_id)
     WHERE pad.pat_auth_seq_id=v_seq_id;

  CURSOR clm_cur IS
     SELECT cad.policy_seq_id,tep.enrol_type_id
     FROM clm_authorization_details cad
     JOiN tpa_enr_policy tep ON (cad.policy_seq_id=tep.policy_seq_id)
     WHERE cad.claim_seq_id=v_seq_id;

pat_rec                         pat_cur%rowtype;
v_prod_policy_rule_seq_id        tpa_ins_prod_policy_rules.prod_policy_rule_seq_id%TYPE;
v_result_set                     SYS_REFCURSOR;


BEGIN

if v_flag='PAT' THEN

    OPEN pat_cur;
    FETCH pat_cur INTO pat_rec;
    CLOSE pat_cur;

ELSIF v_flag='CLM' THEN
    OPEN clm_cur;
    FETCH clm_cur INTO pat_rec;
    CLOSE clm_cur;
ELSIF v_flag='POL' THEN

      pat_rec.Policy_Seq_Id:=v_seq_id;
      pat_rec.enrol_type_id:='COR';
ELSIF v_flag='IND' THEN

      pat_rec.Policy_Seq_Id:=v_seq_id;
      pat_rec.enrol_type_id:='IND';      
END IF;

 IF pat_rec.enrol_type_id='COR' THEN
    OPEN v_result_set FOR
       'SELECT gm.prod_policy_rule_seq_id
        FROM tpa_enr_policy GH
        JOIN tpa_ins_prod_policy GT ON (GH.policy_seq_id=GT.policy_seq_id)
        JOIN tpa_ins_prod_policy_rules GM ON (GT.prod_policy_seq_id=GM.prod_policy_seq_id)
     WHERE GH.policy_seq_id=:v_policy_seq_id
     order by gm.prod_policy_rule_seq_id desc' USING pat_rec.policy_seq_id;

     FETCH v_result_set INTO v_prod_policy_rule_seq_id;
     CLOSE v_result_set;
 ELSE
     OPEN v_result_set FOR
    'SELECT gm.prod_policy_rule_seq_id
     FROM tpa_enr_policy tep
     LEFT OUTER JOIN tpa_ins_product tip on (tip.product_seq_id=tep.product_seq_id)
     LEFT OUTER JOIN tpa_ins_prod_policy tipp on (tipp.product_seq_id=tip.product_seq_id)
     JOIN tpa_ins_prod_policy_rules GM on  (tipp.prod_policy_seq_id=GM.prod_policy_seq_id)
     WHERE tep.policy_seq_id=:v_policy_seq_id
     order by gm.prod_policy_rule_seq_id desc '  USING pat_rec.policy_seq_id;

     FETCH v_result_set into v_prod_policy_rule_seq_id;
     CLOSE v_result_set;
 END IF;
 

return v_prod_policy_rule_seq_id;

END get_prod_pol_seq_id;
--======================================================================================

PROCEDURE select_preauth_list (
  v_authorizationId                     IN  pat_authorization_details.auth_number%type ,
  v_fromdate							              IN   VARCHAR2 ,
  v_toDate							                IN	 VARCHAR2 ,
	v_patientName						              IN  pat_authorization_details.mem_name%type,
	v_clinicianName						            IN	pat_non_network_details.clinician_name%type,
	v_memberId							              IN	pat_authorization_details.tpa_enrollment_id%type,
	v_qutar_id                            IN  tpa_enr_policy_member.emirate_id%TYPE,
	v_status							                IN	tpa_general_code.description%type,
  v_pre_auth_number                     IN  pat_authorization_details.pre_auth_number%type ,
	v_ref_no							                IN  pat_authorization_details.EVENT_NO%type,
  v_sort_var                            IN  VARCHAR2,
  v_sort_order                          IN  VARCHAR2 ,
  v_start_num                           IN  NUMBER ,
  v_end_num                             IN  NUMBER ,
  v_added_by                            IN  NUMBER,
  V_HOSP_SEQ_ID                         IN  pat_authorization_details.hosp_seq_id%type,
  v_inp_status                          IN  VARCHAR2,
  result_set                            OUT SYS_REFCURSOR
  )
  IS
	v_sql_str                            VARCHAR2(10000) ;
	TYPE bind_tab_type IS TABLE OF VARCHAR2(250) INDEX BY BINARY_INTEGER ;
    bind_tab                             bind_tab_type;
    i                                    NUMBER(2) := 0;
    v_where                              VARCHAR2(2000);
    v_stat                               VARCHAR2(20):=null;
  
    v_fdate   pat_authorization_details.hospitalization_date%type:=to_date(v_fromdate,'dd/mm/yyyy');
    v_to_date pat_authorization_details.discharge_date%type  :=to_date(v_toDate,'dd/mm/yyyy');
    v_inp_status1                        VARCHAR2(5);
--  l_sort_var VARCHAR2(30);
--   v_seq_id  VARCHAR2(30);
    
    
  BEGIN
 
   v_sql_str :='with shrtfll as (select max(s.shortfall_seq_id) shortfall_seq_id, s.pat_gen_detail_seq_id
                       from pat_authorization_details p
                       join shortfall_details s on (p.pat_auth_seq_id = s.pat_gen_detail_seq_id)
                       group by s.pat_gen_detail_seq_id
                      )
               SELECT    pad.pat_auth_seq_id as pre_auth_seq_id,
                  pad.pre_auth_number as pre_auth_number,
                  pad.tpa_enrollment_id as tpa_enrollment_id ,
                  pad.emirate_id as quatar_id ,
                 -- thi.hosp_name as  clinician_name ,
                 C.CLINICIAN_NAME as  clinician_name ,
                  to_char(hospitalization_date,''dd/mm/yyyy hh:mi Am'')  as hospitalization_date ,
                  NVL(pad.AUTH_NUMBER,'' '') as auth_number,pad.mem_name as MEM_NAME,
                  --case when pad.completed_yn=''Y'' and pad.pat_status_type_id in (''APR'',''REJ'') then ''Completed'' 
                  case when pad.completed_yn=''Y'' and pad.pat_status_type_id =''APR'' then ''Approved''
                  when pad.completed_yn=''Y'' and pad.pat_status_type_id =''REJ'' then ''Rejected''
                  when pad.pat_status_type_id=''REQ'' THEN ''Shortfall''
                  when pad.completed_yn=''Y'' and pad.pat_status_type_id=''PCN'' THEN ''Cancelled''
                  when pad.completed_yn=''N'' and (pad.pat_status_type_id =''APR'' OR pad.pat_status_type_id =''PCN'' OR pad.pat_status_type_id =''REQ''  OR pad.pat_status_type_id =''INP'' OR pad.pat_status_type_id =''REJ'') then ''In Progress'' end   as status,
                  NVL(pad.EVENT_NO,'' '') AS EVENT_NO,
                  to_char(pad.completed_date,''dd/mm/yyyy hh:mi Am'')  as decision_date,
                  PAD.PAT_STATUS_TYPE_ID||''-''||'||''''||v_inp_status||'''' ||' AS IN_PROGESS_STATUS,
                  pad.claim_seq_id,
                  pad.appeal_count,
                  PAD.PAT_STATUS_TYPE_ID
                FROM
                    pat_authorization_details pad  
                  LEFT OUTER JOIN  tpa_hosp_info thi on(pad.hosp_seq_id=thi.hosp_seq_id)
                  LEFT OUTER JOIN PAT_NON_NETWORK_DETAILS C ON(PAD.CLINICIAN_ID=C.CLINICIAN_ID and pad.PAT_AUTH_SEQ_ID=C.PAT_AUTH_SEQ_ID)
                  left join shrtfll sh ON (sh.pat_gen_detail_seq_id = pad.pat_auth_seq_id)
                  left join shortfall_details sd on (sh.shortfall_seq_id=sd.shortfall_seq_id)';


	IF v_authorizationId IS NOT NULL THEN
      -- like changed to =
      v_where := v_where ||' AND pad.auth_number = :v_authorizationId ';
       i := i+1;
       bind_tab(i) := v_authorizationId;
    END IF;
    
    IF V_HOSP_SEQ_ID IS NOT NULL THEN
      -- like changed to =
      v_where := v_where ||' AND thi.hosp_seq_id = :V_HOSP_SEQ_ID ';
       i := i+1;
       bind_tab(i) := V_HOSP_SEQ_ID;
    END IF;

       
  IF v_to_date IS NOT NULL THEN 
        v_where := v_where  ||' AND pad.discharge_date<=:v_to_date';
        i:=i+1;
       bind_tab(i) := v_to_date;
  END IF;
  
 IF v_fdate IS NOT NULL THEN
        v_where := v_where  ||' AND  pad.hospitalization_date>=:v_fdate';
        i:=i+1;
       bind_tab(i) := v_fdate;
  END IF;
       
 IF v_patientName IS NOT NULL THEN
      -- like changed to =
      v_where := v_where  ||' AND trim(pad.mem_name) LIKE:v_patientName';
       i := i+1;
       bind_tab(i) := UPPER(v_patientName)||'%';
  END IF;
 IF v_clinicianName IS NOT NULL THEN
      -- like changed to =
      v_where := v_where  ||' AND thi.hosp_name LIKE:v_clinicianName';
       i := i+1;
       bind_tab(i) := UPPER(v_clinicianName)||'%';
  END IF;
 IF v_memberId IS NOT NULL THEN
      -- like changed to =
      v_where := v_where  ||' AND pad.tpa_enrollment_id = :v_memberId ';
       i := i+1;
       bind_tab(i) := UPPER(v_memberId);
  END IF;
  IF v_qutar_id IS NOT NULL THEN
      -- like changed to =
      v_where := v_where  ||' AND pad.emirate_id LIKE:v_qutar_id';
       i := i+1;
       bind_tab(i) := UPPER(v_qutar_id)||'%';
  END IF;
    
	IF v_status IS NOT NULL  THEN
      -- like changed to =
     v_where := v_where||' AND pad.pat_status_type_id = :v_status ';
    i := i+1;
    bind_tab(i) :=v_status;
  END IF;
  
  IF v_ref_no IS NOT NULL  THEN
      -- like changed to =
     v_where := v_where||' AND pad.EVENT_NO = :v_ref_no ';
    i := i+1;
    bind_tab(i) :=v_ref_no;
  END IF;
  
  
	IF v_pre_auth_number IS NOT NULL THEN
      -- like changed to =
      v_where := v_where ||' AND pad.pre_auth_number = :v_pre_auth_number ';
       i := i+1;
       bind_tab(i) := v_pre_auth_number;
    END IF;
  
  --===============CR0247====================================
    IF v_inp_status IS NOT NULL THEN
      IF v_inp_status = 'FRH' THEN
         v_inp_status1 := '0';
         v_where := v_where  ||' AND NVL(PAD.PARENT_PAT_AUTH_SEQ_ID, 0) = 0 AND NVL(PAD.APPEAL_YN, ''N'') = ''N'' AND NVL(SD.PAT_GEN_DETAIL_SEQ_ID, 0) = :v_inp_status ';
      ELSIF v_inp_status = 'APL' THEN
         v_inp_status1 := 'Y';
         v_where := v_where  ||' AND PAD.APPEAL_YN = :v_inp_status ';
      ELSIF v_inp_status = 'ENH' THEN
         v_inp_status1 := '0';
         v_where := v_where  ||' AND NVL(PAD.PARENT_PAT_AUTH_SEQ_ID, 0) != :v_inp_status ';
      ELSIF v_inp_status = 'RES' THEN
         v_inp_status1 := 'RES';
         v_where := v_where  ||' AND PAD.PAT_STATUS_TYPE_ID = ''INP'' AND SD.SRTFLL_STATUS_GENERAL_TYPE_ID = :v_inp_status ';
      END IF;
      i := i+1;
      bind_tab(i) := UPPER(v_inp_status1);
    END IF;
    --=========================================================
    v_where := v_where||' and pad.pbm_yn=''Y'' ' ||' and pad.pat_enhanced_yn=''N'' '; ----NEWLY ADDED FOR PRE AUTH ENHANCEMENT
    
    
  IF v_where IS NOT NULL THEN
      v_where   := ' WHERE '||SUBSTR(v_where,5);
      v_sql_str := v_sql_str ||v_where;
  END IF;
  --dbms_output.put_line(v_sql_str);

	
	  v_sql_str := 'SELECT * FROM
        (SELECT A.*,DENSE_RANK() OVER (ORDER BY '||v_sort_var||' '||v_sort_order||',ROWNUM)
        Q FROM (' ||v_sql_str|| ') A ) WHERE  Q>= :v_start_num AND Q<= :v_end_num ';
  

    IF bind_tab.FIRST IS NOT NULL THEN
       CASE bind_tab.COUNT
       
        WHEN 1  THEN OPEN result_set FOR v_sql_str USING bind_tab(1), v_start_num , v_end_num ;
        WHEN 2  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2), v_start_num , v_end_num ;
        WHEN 3  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2) ,bind_tab(3) , v_start_num , v_end_num ;
        WHEN 4  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) , v_start_num , v_end_num ;
        WHEN 5  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5), v_start_num , v_end_num ;
        WHEN 6  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6), v_start_num , v_end_num ;
        WHEN 7  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6),bind_tab(7), v_start_num , v_end_num ;
        WHEN 8  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6),bind_tab(7),bind_tab(8), v_start_num , v_end_num ;
         
        END CASE;
     ELSE
       OPEN result_set FOR v_sql_str USING v_start_num , v_end_num ;
       
     END IF;
END select_preauth_list;
--==============================================================================
--==============================================================================
-------------------------------PBMFIXES
--==============================================================================
PROCEDURE validate_enrollment_id (
      v_tpa_enrollment_id                  IN  OUT  pat_enroll_details.tpa_enrollment_id%TYPE,
      v_date_of_hosp                       IN  varchar2,
      v_event_no                           IN VARCHAR2,
      v_hosp_seq_id                        IN  tpa_hosp_info.hosp_seq_id%TYPE,
      v_member_details                      OUT SYS_REFCURSOR)

IS

v_result_set                              SYS_REFCURSOR;
v_mem_status_type                         VARCHAR2(10);
v_eff_from_date                           date;
v_eff_to_date                             date;
v_member_seq_id               tpa_enr_policy_member.member_seq_id%type;
v_policy_group_seq_id                     tpa_enr_policy_group.policy_group_seq_id%TYPE;


      v_event_len            NUMBER;
      v_spec_char_cnt        NUMBER;
      V_COMPLETED_YN         VARCHAR2(10);
      v_event_num            VARCHAR2(15);
      v_date_of_exit         date;
      v_inception_date       DATE;
v_policy_seq_id                           tpa_enr_policy.policy_seq_id%TYPE;
v_stop_pat_yn                             tpa_ins_prod_policy.stop_preauth_yn%TYPE;
v_stop_pat_date                           tpa_ins_prod_policy.stop_preauth_date%TYPE;

CURSOR stop_pol_cur (v_pol_id tpa_enr_policy.policy_seq_id%TYPE) IS SELECT  stop_preauth_yn,stop_preauth_date  FROM app.tpa_ins_prod_policy  WHERE policy_seq_id = v_pol_id;

CURSOR stop_pro_cur  IS SELECT stop_preauth_yn,stop_preauth_date FROM app.tpa_hosp_info WHERE hosp_seq_id = v_hosp_seq_id;

CURSOR mem_stop_cur (v_mem_seq_id tpa_enr_policy_member.member_seq_id%TYPE) IS
                                                 SELECT stop_pat_clm_process_yn ,recieved_after 
                                                 FROM app.tpa_enr_policy_member tepm
                                                 WHERE tepm.member_seq_id = v_mem_seq_id; 
CURSOR emp_stop_cur (v_emp_id tpa_enr_policy_group.policy_group_seq_id%TYPE) IS
                                                 SELECT stop_pat_clm_process_yn ,recieved_after 
                                                 FROM app.tpa_enr_policy_group tepg
                                                 WHERE tepg.policy_group_seq_id = v_emp_id; 
BEGIN

OPEN v_result_set  FOR

  SELECT trim(a.member_seq_id),a.status_general_type_id,c.effective_from_date,c.effective_to_date,a.date_of_exit,C.COMPLETED_YN, a.date_of_inception,c.policy_seq_id,b.policy_group_seq_id
  FROM   tpa_enr_policy_member A
  JOIN tpa_enr_policy_group B ON (A.policy_group_seq_id = B.policy_group_seq_id)
  JOIN tpa_enr_policy C ON (B.policy_seq_id = C.policy_seq_id and nvl(c.completed_yn,'N')='Y')
  WHERE (a.tpa_enrollment_id=v_tpa_enrollment_id or a.emirate_id=v_tpa_enrollment_id)
  AND ( to_date(v_date_of_hosp,'dd/mm/yyyy') BETWEEN C.effective_from_date AND C.effective_to_date+1);
  FETCH v_result_set INTO v_member_seq_id,v_mem_status_type,v_eff_from_date,v_eff_to_date,v_date_of_exit,V_COMPLETED_YN, v_inception_date,v_policy_seq_id,v_policy_group_seq_id;

CLOSE v_result_set;

OPEN stop_pol_cur(v_policy_seq_id);
FETCH stop_pol_cur INTO v_stop_pat_yn,v_stop_pat_date;
CLOSE stop_pol_cur;

IF v_member_seq_id IS NULL THEN
  RAISE_APPLICATION_ERROR(-20265,'Please enter a valid Vidal Id');
END IF;

IF v_event_no IS NULL THEN
IF v_mem_status_type = 'POC' THEN
  RAISE_APPLICATION_ERROR(-20271,'Vidal Id Is Not Active');
END IF;
END IF;
IF to_date(v_date_of_hosp,'dd/mm/yyyy') < v_eff_from_date OR to_date(v_date_of_hosp,'dd/mm/yyyy') > v_eff_to_date THEN
  RAISE_APPLICATION_ERROR(-20272,'Date of Adimission not between policy period');
END IF;
 IF V_COMPLETED_YN = 'N' THEN
        RAISE_APPLICATION_ERROR(-20921, 'Policy event not completed .');
      END IF;

IF v_stop_pat_yn='Y' AND trunc(sysdate) >= trunc(v_stop_pat_date) THEN
   RAISE_APPLICATION_ERROR(-20414,'Member is not covered as the contract between Corporate & Al Koot is on hold');
END IF;

OPEN emp_stop_cur(v_policy_group_seq_id);
FETCH emp_stop_cur INTO v_stop_pat_yn,v_stop_pat_date;
CLOSE emp_stop_cur;

IF v_stop_pat_yn='Y' AND trunc(sysdate) >= trunc(v_stop_pat_date) THEN
   RAISE_APPLICATION_ERROR(-20417,'Member is not eligible for treatment as the contract between member & Al Koot is on hold');
END IF;

OPEN mem_stop_cur(v_member_seq_id);
FETCH mem_stop_cur INTO v_stop_pat_yn,v_stop_pat_date;
CLOSE mem_stop_cur;

IF v_stop_pat_yn='Y' AND trunc(sysdate) >= trunc(v_stop_pat_date) THEN
   RAISE_APPLICATION_ERROR(-20417,'Member is not eligible for treatment as the contract between member & Al Koot is on hold');
END IF;

OPEN stop_pro_cur ;
FETCH stop_pro_cur INTO v_stop_pat_yn,v_stop_pat_date;
CLOSE stop_pro_cur;

IF v_stop_pat_yn='Y' AND trunc(sysdate) >= trunc(v_stop_pat_date) THEN
   RAISE_APPLICATION_ERROR(-20416,'The eligibility check option is disabled since the contract between your facility & Al Koot is on hold');
END IF;


IF v_event_no IS NOT NULL THEN
      /*open event_cur;
      fetch event_cur into event_num;
      close event_cur;*/
      
      SELECT count(1) INTO v_spec_char_cnt FROM DUAL
      WHERE REGEXP_LIKE(v_event_no, '^\d+(\\d+)?$', '');
      
      IF v_spec_char_cnt = 0 THEN
        RAISE_APPLICATION_ERROR(-20916, 'Event Number should be number format .');
      END IF;
      
      SELECT length(trim(v_event_no)) INTO v_event_len
      FROM DUAL;
      
      IF v_event_len != 7 THEN
        RAISE_APPLICATION_ERROR(-20919, 'Event Number Length should be 7 .');
      END IF;
        
      select rpad((s.LAST_NUMBER - 1), 7, 0) INTO v_event_num
      from all_sequences s
      where s.SEQUENCE_NAME = UPPER('event_ref_no_seq')
      and s.SEQUENCE_OWNER = 'APP';
    
      /*IF event_num > 0 THEN
        RAISE_APPLICATION_ERROR(-20914, 'Given Event Number is Already assinged to other Preaproval/ Claim.');
      END IF;*/
      
      
      
      /*IF to_number(trim(v_event_no)) > v_event_num THEN
        RAISE_APPLICATION_ERROR(-20915, 'Given Event Number is not valid.');
      END IF;*/
    END IF;
OPEN v_member_details  FOR
   
 SELECT  tpm.member_seq_id as member_seq_id,tpm.tpa_enrollment_id as tpa_enrollment_id ,tpm.emirate_id  ,to_char(tpm.mem_dob,'dd/mm/yyyy')as mem_dob,tins.ins_comp_code_number as ins_cmp_code,
         CASE WHEN tpm.gender_general_type_id LIKE 'M%' THEN 'M'
              WHEN tpm.gender_general_type_id LIKE 'F%' THEN 'F'
                ELSE 'O' END AS gender_general_type_id
  FROM  tpa_enr_policy_member tpm
  JOIN APP.tpa_enr_policy_group tepg on(tpm.policy_group_seq_id=tepg.policy_group_seq_id)
  JOIN tpa_enr_policy tnp on(tepg.policy_seq_id=tnp.policy_seq_id)
  JOIN  APP.TPA_INS_INFO tins on(tins.ins_seq_id=tnp.ins_seq_id)
  where (tpm.tpa_enrollment_id= v_tpa_enrollment_id
  or tpm.emirate_id=v_tpa_enrollment_id)
  and to_date(v_date_of_hosp,'dd/mm/yyyy') between tnp.effective_from_date and tnp.effective_to_date+1;
 
  


END validate_enrollment_id;

--==============================================================================
PROCEDURE select_activity_code(v_hosp_seq_id               IN tpa_hosp_info.hosp_seq_id%TYPE,
                               v_tpa_enrollment_id         IN tpa_enr_policy_member.tpa_enrollment_id%type,
                               v_activity_code             IN tpa_pharmacy_master_details.activity_code%type,
                               v_activity_datee            IN  varchar2,
                               v_unit_type                 IN PAT_ACTIVITY_DETAILS.unit_type%type, 
                               v_tariff_result             OUT SYS_REFCURSOR)
  
IS
v_activity_date   pat_activity_details.start_date%TYPE  :=to_date(v_activity_datee,'dd/mm/yyyy');



CURSOR mem_cur IS
SELECT tip.product_cat_type_id,tep.ins_seq_id,tep.group_reg_seq_id, tep.policy_seq_id,tep.tariff_type_id
FROM app.tpa_enr_policy_member tem
JOIN app.tpa_enr_policy_group teg ON (tem.policy_group_seq_id = teg.policy_group_seq_id)
JOIN tpa_enr_policy tep ON (teg.policy_seq_id=tep.policy_seq_id)
JOIN tpa_ins_product tip ON (tep.product_seq_id=tip.product_seq_id)
WHERE tem.tpa_enrollment_id = v_tpa_enrollment_id;

mem_rec             mem_cur%ROWTYPE;


CURSOR pharmacy_cur IS 
SELECT i.disc_percent FROM app.tpa_hosp_tariff_details i where i.acitivity_type_seq_id=5 and i.hosp_seq_id=v_hosp_seq_id
 AND v_activity_date BETWEEN  i.start_date AND NVL(i.end_date,v_activity_date);



v_product_network_type    varchar2(20);
v_count   number(10);
v_tariff_ins_seq_id           number(10);
v_tariff_count                number(10);
v_tpa_ins_seq_id              number(10);
v_activity_type_seq_id        number(10);
v_pharmacy_rec                number(10);


BEGIN
  
 
 OPEN mem_cur;
 FETCH mem_cur INTO mem_rec;
 CLOSE mem_cur;
 
  IF mem_rec.Ins_Seq_Id IS NOT NULL THEN 
   SELECT COUNT(1) INTO v_tariff_count from tpa_hosp_tariff_details d 
   where d.ins_seq_id=mem_rec.Ins_Seq_Id and d.hosp_seq_id=v_hosp_seq_id;
 END IF; 

    open pharmacy_cur ; 
     fetch pharmacy_cur into v_pharmacy_rec ;
     close pharmacy_cur;
     
    if v_unit_type = 'LOSE' then
    OPEN v_tariff_result FOR 
       select 
          nvl(tamd.act_mas_dtl_seq_id,(select act_mas_dtl_seq_id from tpa_pharmacy_master_details md where md.activity_code=upper(v_activity_code) and rownum=1)) as activity_seq_id,
          tamd.unit_price as gross_amount   ,
          nvl(v_pharmacy_rec*(nvl(tamd.unit_price,0)/100),0)as unit_discount,
          tamd.activity_code,tamd.activity_type_seq_id,to_char(tamd.start_date,'DD/MM/YYYY') AS start_date,
          NVL(tamd.moph_codes,tamd.activity_code) AS moph_codes
    from app.tpa_pharmacy_master_details tamd
    JOIN tpa_activity_type_codes tatc ON (tamd.activity_type_seq_id=tatc.activity_type_seq_id)
    WHERE tamd.activity_code=upper(v_activity_code)
    AND v_activity_date BETWEEN  tamd.start_date AND NVL(tamd.end_date,v_activity_date);
    --dbms_output.put_line('v_count is'||v_count);
    else
      OPEN v_tariff_result FOR 
       select 
          nvl(tamd.act_mas_dtl_seq_id,(select act_mas_dtl_seq_id from tpa_pharmacy_master_details md where md.activity_code=upper(v_activity_code) and rownum=1 )) as activity_seq_id,
          tamd.PACKAGE_PRICE as gross_amount   ,
          nvl(v_pharmacy_rec*(nvl(tamd.PACKAGE_PRICE,0)/100),0)as unit_discount,
          tamd.activity_code,tamd.activity_type_seq_id,to_char(tamd.start_date,'DD/MM/YYYY') AS start_date,
          NVL(tamd.moph_codes,tamd.activity_code) AS moph_codes
    from app.tpa_pharmacy_master_details tamd
    JOIN tpa_activity_type_codes tatc ON (tamd.activity_type_seq_id=tatc.activity_type_seq_id)
    WHERE tamd.activity_code=upper(v_activity_code)
    AND v_activity_date BETWEEN  tamd.start_date AND NVL(tamd.end_date,v_activity_date);
    end if;
  
  
END select_activity_code;
--==============================================================================
PROCEDURE pmb_websrvc_proc (wb_ip_xml        IN XMLTYPE,
                            wb_resp_xml      IN XMLTYPE,
                            v_process_type   IN VARCHAR2,
                            v_seq_id         IN NUMBER, -- preauth or claim seq id based on flag
                            v_added_by       IN NUMBER
                            )
 IS
  
  CURSOR cur_xml_values IS
    SELECT S.responce_id,CASE WHEN TRIM(UPPER(s.resp_flag)) = 'TRUE' THEN 'T' ELSE 'F' END AS resp_flag
                  FROM XMLTABLE('//return'
                                PASSING wb_resp_xml
                                COLUMNS 
                                  responce_id  VARCHAR2(100) PATH 'responseId',
                                  resp_flag    VARCHAR2(100) PATH 'success'
                                )S;
                                
   rec_xml_values             cur_xml_values%ROWTYPE;
   v_orcl_err_msg             VARCHAR2(2000);
   v_orcl_err_code            VARCHAR2(200);
   
   
BEGIN

 OPEN  cur_xml_values;
 FETCH cur_xml_values INTO rec_xml_values;
 CLOSE cur_xml_values;
 
 IF v_process_type = 'PAT' THEN
   INSERT INTO app.tpa_pbm_wesrvc_logs(log_seq_id,responce_id,reponce_flag,
                                       pat_auth_seq_id,claim_seq_id,process_type,
                                       input_xml,responce_xml,added_by,
                                       input_clob,responce_clob)
                               VALUES (app.pbm_log_seq_id.nextval,rec_xml_values.responce_id,rec_xml_values.resp_flag,
                                       v_seq_id,NULL,v_process_type,
                                       wb_ip_xml,wb_resp_xml,v_added_by,
                                       wb_ip_xml.getclobval(),wb_resp_xml.getclobval());
   
  FOR i IN (SELECT S.*
                  FROM XMLTABLE('//claimEdits'
                                PASSING wb_resp_xml
                                COLUMNS 
                                  pat_seq_id  VARCHAR2(100) PATH 'claimId',
                                  act_code    VARCHAR2(100) PATH 'activityCode',
                                  denial_code VARCHAR2(100) PATH 'editCode',
                                  denial_desc VARCHAR2(100) PATH 'editComment',
                                  edit_rank   VARCHAR2(100) PATH 'editRank'
                                ) S
             )
       LOOP
       IF i.denial_code IS NOT NULL THEN  
        UPDATE app.pat_activity_details pa
         SET pa.denial_code               = CASE WHEN pa.denial_code IS NULL THEN i.denial_code 
                                                 WHEN pa.denial_code LIKE '%'||i.denial_code||'%' THEN pa.denial_code 
                                                  ELSE pa.denial_code||';'||i.denial_code END,
             pa.denial_desc               = CASE WHEN pa.denial_code IS NULL THEN i.denial_desc 
                                                 WHEN pa.denial_code LIKE '%'||i.denial_code||'%' THEN pa.denial_desc 
                                                  ELSE pa.denial_desc||';'||i.denial_desc END,
             pa.remarks                   = CASE WHEN pa.denial_code IS NULL THEN i.denial_desc 
                                                 WHEN pa.denial_code LIKE '%'||i.denial_code||'%' THEN pa.remarks 
                                                  ELSE pa.remarks||';'||i.denial_desc END,                                                    
             pa.dimnsion_hlth_denial_code = CASE WHEN pa.dimnsion_hlth_denial_code IS NULL THEN i.denial_code 
                                                 WHEN pa.dimnsion_hlth_denial_code LIKE '%'||i.denial_code||'%' THEN pa.dimnsion_hlth_denial_code 
                                                  ELSE pa.dimnsion_hlth_denial_code||';'||i.denial_code END,
             pa.dimnsion_hlth_denial_desc = CASE WHEN pa.dimnsion_hlth_denial_code IS NULL THEN i.denial_desc 
                                                 WHEN pa.dimnsion_hlth_denial_code LIKE '%'||i.denial_code||'%' THEN pa.dimnsion_hlth_denial_desc 
                                                  ELSE pa.dimnsion_hlth_denial_desc||';'||i.denial_desc END,
             pa.denial_by_rule_proc_dtls    = TRIM(BOTH ';' FROM (pa.denial_by_rule_proc_dtls||';'||CHR(10)||'hosp_pbm_pkg.pmb_websrvc_proc')),
             pa.denial_by_resons            = TRIM(BOTH ';' FROM (pa.denial_by_resons||';'||CHR(10)||'Clinical rule validation.')),
             pa.edit_rank                   = CASE WHEN edit_rank LIKE '%2%' THEN edit_rank ELSE i.edit_rank END,
             pa.approved_amount             = CASE WHEN i.edit_rank LIKE '%1%' THEN 0 ELSE pa.approved_amount END,
             pa.allowed_amount              = CASE WHEN i.edit_rank LIKE '%1%' THEN 0 ELSE pa.allowed_amount END,
             pa.pbm_wb_srvc_exec_yn         = 'Y'
       WHERE pa.pat_auth_seq_id = v_seq_id  
         AND pa.moph_codes = i.act_code
         AND nvl(pa.override_yn,'N')='N';      
      END IF;                           
   END LOOP;           
 ELSE
   INSERT INTO app.tpa_pbm_wesrvc_logs(log_seq_id,responce_id,reponce_flag,
                                       pat_auth_seq_id,claim_seq_id,process_type,
                                       input_xml,responce_xml,added_by,
                                       input_clob,responce_clob)
                               VALUES (app.pbm_log_seq_id.nextval,rec_xml_values.responce_id,rec_xml_values.resp_flag,
                                       NULL,v_seq_id,v_process_type,
                                       wb_ip_xml,wb_resp_xml,v_added_by,
                                       wb_ip_xml.getclobval(),wb_resp_xml.getclobval());
   FOR i IN (SELECT S.*
                  FROM XMLTABLE('//claimEdits'
                                PASSING wb_resp_xml
                                COLUMNS 
                                  clm_seq_id  VARCHAR2(100) PATH 'claimId',
                                  act_code    VARCHAR2(100) PATH 'activityCode',
                                  denial_code VARCHAR2(100) PATH 'editCode',
                                  denial_desc VARCHAR2(100) PATH 'editComment',
                                  edit_rank   VARCHAR2(100) PATH 'editRank'
                                ) S
             )
       LOOP
       IF i.denial_code IS NOT NULL THEN    
        UPDATE app.pat_activity_details pa
         SET pa.denial_code               = CASE WHEN pa.denial_code IS NULL THEN i.denial_code 
                                                 WHEN pa.denial_code LIKE '%'||i.denial_code||'%' THEN pa.denial_code 
                                                  ELSE pa.denial_code||';'||i.denial_code END,
             pa.denial_desc               = CASE WHEN pa.denial_code IS NULL THEN i.denial_desc 
                                                 WHEN pa.denial_code LIKE '%'||i.denial_code||'%' THEN pa.denial_desc 
                                                  ELSE pa.denial_desc||';'||i.denial_desc END,
             pa.remarks                   = CASE WHEN pa.denial_code IS NULL THEN i.denial_desc 
                                                 WHEN pa.denial_code LIKE '%'||i.denial_code||'%' THEN pa.remarks 
                                                  ELSE pa.remarks||';'||i.denial_desc END,  
             pa.dimnsion_hlth_denial_code = CASE WHEN pa.dimnsion_hlth_denial_code IS NULL THEN i.denial_code 
                                                 WHEN pa.dimnsion_hlth_denial_code LIKE '%'||i.denial_code||'%' THEN pa.dimnsion_hlth_denial_code 
                                                  ELSE pa.dimnsion_hlth_denial_code||';'||i.denial_code END,
             pa.dimnsion_hlth_denial_desc = CASE WHEN pa.dimnsion_hlth_denial_code IS NULL THEN i.denial_desc 
                                                 WHEN pa.dimnsion_hlth_denial_code LIKE '%'||i.denial_code||'%' THEN pa.dimnsion_hlth_denial_desc 
                                                  ELSE pa.dimnsion_hlth_denial_desc||';'||i.denial_desc END,
             pa.denial_by_rule_proc_dtls    = TRIM(BOTH ';' FROM (pa.denial_by_rule_proc_dtls||';'||CHR(10)||'hosp_pbm_pkg.pmb_websrvc_proc')),
             pa.denial_by_resons            = TRIM(BOTH ';' FROM (pa.denial_by_resons||';'||CHR(10)||'Clinical rule validation.')),
             pa.edit_rank                   = CASE WHEN edit_rank LIKE '%2%' THEN edit_rank ELSE i.edit_rank END,
             pa.approved_amount             = CASE WHEN i.edit_rank LIKE '%1%' THEN 0 ELSE pa.approved_amount END,
             pa.allowed_amount              = CASE WHEN i.edit_rank LIKE '%1%' THEN 0 ELSE pa.allowed_amount END,
             pa.pbm_wb_srvc_exec_yn         = 'Y'
       WHERE pa.claim_seq_id = v_seq_id  
         AND pa.moph_codes = i.act_code
         AND nvl(pa.override_yn,'N')='N';  
      END IF;                                    
   END LOOP;  
 END IF;
 
 EXCEPTION 
   WHEN OTHERS THEN
     v_orcl_err_msg  := SQLERRM;
     v_orcl_err_code := SQLCODE;
     INSERT INTO app.tpa_pbm_wesrvc_eror_logs(log_seq_id,responce_id,reponce_flag,
                                              pat_auth_seq_id,claim_seq_id,process_type,
                                              input_xml,responce_xml,added_by,eroor_msg,error_code,
                                              input_clob,responce_clob)
                                       VALUES (app.pbm_eror_log_seq_id.nextval,rec_xml_values.responce_id,rec_xml_values.resp_flag,
                                               NULL,v_seq_id,v_process_type,
                                               wb_ip_xml,wb_resp_xml,v_added_by,v_orcl_err_msg,v_orcl_err_code,
                                               wb_ip_xml.getclobval(),wb_resp_xml.getclobval());
     
   COMMIT;
END pmb_websrvc_proc;
--============================================================================== 
procedure save_pbm_clm(v_pat_auth_seq_id            IN  pat_authorization_details.pat_auth_seq_id%type,
                        v_res                       in varchar2,
                        v_invoice_number             IN  clm_authorization_details.INVOICE_NUMBER%TYPE,
                        v_result_set               OUT SYS_REFCURSOR
						 )
						 is
              v_clm_batch_seq_id                 clm_batch_upload_details.clm_batch_seq_id%TYPE;
               v_claim_seq_id                   clm_authorization_details.claim_seq_id%TYPE;
               v_clm_batch_no                    clm_batch_upload_details.batch_no%TYPE;
                v_provider_id                     varchar2(100);
                v_provider_name                   varchar2(100);
						 
						 cursor pbm_pat_cur is
						 select * from pat_authorization_details p
						 where p.pat_auth_seq_id = v_pat_auth_seq_id;
						 
						 pbm_pat_rec pbm_pat_cur%rowtype;
						 
						 cursor pbm_clm_cur is
						 select * from clm_authorization_details c
						 where c.pat_auth_seq_id = v_pat_auth_seq_id;
						 
						 pbm_clm_rec pbm_clm_cur%rowtype;
						 
  
						  Cursor batch_status_cur is 
						  select ud.batch_status_type,ud.batch_tot_amount,UD.submission_type_id 
                          from app.clm_batch_upload_details ud 
                          where ud.clm_batch_seq_id=v_clm_batch_seq_id;

                         status_rec    batch_status_cur%rowtype;   
						 
						   v_batch_no                varchar2(100);
               v_count                   NUMBER;
               v_claim_number varchar2(25);
                          
                           
                           
--  CURSOR mem_cur IS
--    SELECT tepm.date_of_inception,
--           tepm.date_of_exit,
--           tepm.mem_name,
--           tepm.mem_age,
--           tcc.short_name,
--           tsc.state_type_id,
--           tepg.policy_group_seq_id,
--           tepg.policy_seq_id,
--           tepm.member_seq_id,
--           ep.ins_seq_id,
--           ep.enrol_type_id,
--           nvl(eb.sum_insured,0) - nvl(eb.utilised_sum_insured,0) AS ava_sum_insured,
--           EB.SUM_INSURED
--      FROM tpa_enr_policy ep 
--      JOIN tpa_enr_policy_group tepg on (ep.policy_seq_id=tepg.policy_seq_id)
--      JOIN tpa_enr_policy_member tepm
--        ON (tepg.policy_group_seq_id = tepm.policy_group_seq_id)
--     LEFT OUTER JOIN tpa_enr_mem_address tema
--        ON (tepg.enr_address_seq_id = tema.enr_address_seq_id)
--     LEFT OUTER JOIN tpa_country_code tcc
--        ON (tema.country_id = tcc.country_id)
--     LEFT OUTER JOIN tpa_state_code tsc
--        ON (tema.state_type_id = tsc.state_type_id)
--     LEFT OUTER JOIN tpa_enr_balance eb ON (tepg.policy_group_seq_id = eb.policy_group_seq_id)
--     WHERE tepm.Member_Seq_Id = pbm_clm_rec.member_seq_id 
--     and  (tepm.mem_general_type_id != 'PFL' AND tepm.member_seq_id = eb.member_seq_id OR eb.member_seq_id IS NULL OR tepm.member_seq_id IS NULL);
--     mem_rec         mem_cur%ROWTYPE;
						   
               v_req_amt   number(15,2):=0;
               v_fin_req_amt number(15,2):=0;
               j               number:=1;
                str_tab         DBMS_UTILITY.uncl_array;
                V_ROWS_PROCESSED   number;
                V_CLINICIAN_NAME VARCHAR2(100);
                v_allowed_amount    number(15,2):=0;
                
                CURSOR provider_networks(v_hosp_seq_id  tpa_hosp_info.hosp_seq_id%type) is 
select to_char(wm_concat(case when n.network_yn='Y' then n.network_type end )) as eligible_networks from tpa_hosp_info i join app.tpa_hosp_network n on (i.hosp_seq_id=n.hosp_seq_id)
where i.hosp_seq_id = pbm_pat_rec.hosp_seq_id;
pro_network  provider_networks%rowtype;


cursor cal_tot_disal_amt_cur IS
   select sum(p.disallowed_amount) as disallowed_amount
   from pat_activity_details p
   where p.claim_seq_id = v_claim_seq_id;
   
 v_cur_dis_amt cal_tot_disal_amt_cur%rowtype;
   
v_appr_count NUMBER;
 v_alert  varchar2(1000):=null;
 v_seq_id  varchar2(10);
 
 
 BEGIN
 open  batch_status_cur;
  fetch batch_status_cur into status_rec;
  close batch_status_cur;
  
  OPEN pbm_clm_cur;
  FETCH pbm_clm_cur
    INTO pbm_clm_rec;
  CLOSE pbm_clm_cur;
  
  open pbm_pat_cur;
  fetch pbm_pat_cur into pbm_pat_rec;
  close pbm_pat_cur;
  
--  OPEN mem_cur;
--  FETCH mem_cur
--    INTO mem_rec;
--  CLOSE mem_cur;
  
  
  IF NVL(status_rec.batch_status_type,'INP')='COMP' THEN
    RAISE_APPLICATION_ERROR(-20390,'You cannot perform this action through a completed Batch.');
  END IF;
  
  IF pbm_clm_rec.completed_yn = 'Y' or  pbm_clm_rec.claim_seq_id is not null THEN
    RAISE_APPLICATION_ERROR(-20107,
                            'You cannot perform this action through a completed Claim.');
  END IF;
  
--  IF pbm_clm_rec.claim_seq_id is not null  THEN
--    RAISE_APPLICATION_ERROR(-20107,
--                            'You cannot perform this action through a Claim already processed.');
--  END IF;
  
    select a.HOSP_LICENC_NUMB,a.HOSP_NAME ,C.CLINICIAN_NAME into v_provider_id,v_provider_name,V_CLINICIAN_NAME from APP.TPA_HOSP_INFO a join APP.PAT_AUTHORIZATION_DETAILS b on (a.hosp_seq_id=b.hosp_seq_id)
JOIN PAT_NON_NETWORK_DETAILS C ON (B.PAT_AUTH_SEQ_ID=C.PAT_AUTH_SEQ_ID)
where b.PAT_AUTH_SEQ_ID=v_pat_auth_seq_id;
   



  j:=1;
  for i in (Select column_value as val from table(cast(ttk_mail_pkg.parse(v_res,'|') as strings))) loop
      str_tab(j):=i.val;
      
     
     -- j:=j+1;
  --  end loop;
  	 select ALLOWED_AMOUNT into v_req_amt from pat_activity_details--v_activity_dtl_seq_id,
	where pat_auth_seq_id=v_pat_auth_seq_id and activity_dtl_seq_id=str_tab(j);
  j:=j+1;
  v_fin_req_amt:=v_fin_req_amt+v_req_amt;
  end loop;
  
  	claim_pkg.save_clm_batch_details(v_clm_batch_seq_id,v_batch_no,v_provider_id,'ALK01',SYSDATE,1,v_fin_req_amt,1,'COMP','OPTS','CNH','DTC','QAR','PBCL','N','Y',v_provider_name,'INSU',1,'RGL',NULL,NULL);

											   

  
     -- IF v_clm_batch_seq_id IS NOT NULL AND nvl(v_claim_seq_id,0)=0 THEN
        IF v_invoice_number IS NOT NULL THEN 
           With HOSP_IVOICE_DATA As
           (Select ','||CA.INVOICE_NUMBER||',' As INVOICE_NUMBER
           From APP.CLM_AUTHORIZATION_DETAILS CA
           Join APP.CLM_HOSPITAL_DETAILS H On (CA.CLAIM_SEQ_ID=H.CLAIM_SEQ_ID)
           Where  H.HOSP_SEQ_ID = pbm_pat_rec.HOSP_SEQ_ID
           --and ca.clm_batch_seq_id = v_clm_batch_seq_id
          )
          Select count(1) into v_count
          From HOSP_IVOICE_DATA
          Where INVOICE_NUMBER LIKE '%,'||trim(v_invoice_number)||',%';--ad.clm_batch_seq_id=v_clm_batch_seq_id
          --AND TRIM(ad.invoice_number)=TRIM(v_invoice_number);
        END IF;
        
        IF v_count>0 THEN 
          RAISE_APPLICATION_ERROR(-20391,'Duplicate invocenumber.');
        END IF;
--      END IF;
--    END IF;  
    
   -- IF NVL(v_claim_seq_id,0)=0 THEN
    
    claim_pkg.save_clm_details(V_CLAIM_SEQ_ID,
V_CLM_BATCH_SEQ_ID,
v_pat_auth_seq_id,
NULL,
v_claim_number,
NULL,
NULL,
SYSDATE,
'PBCL',
pbm_pat_rec.HOSPITALIZATION_DATE,
 pbm_pat_rec.discharge_DATE,
 'CNH',
 NULL,
 pbm_pat_rec.member_seq_id,
 pbm_pat_rec.tpa_enrollment_id,
 pbm_pat_rec.mem_name,
 pbm_pat_rec.mem_age,
 pbm_pat_rec.ins_seq_id,
 pbm_pat_rec.policy_seq_id,
 pbm_pat_rec.enrol_type_id,
 pbm_pat_rec.emirate_id,
 pbm_pat_rec.ENCOUNTER_TYPE_ID,
 pbm_pat_rec.ENCOUNTER_START_TYPE,
 pbm_pat_rec.ENCOUNTER_END_TYPE,
 pbm_pat_rec.ENCOUNTER_FACILITY_ID,
 NULL,
 pbm_pat_rec.ava_sum_insured,
 pbm_pat_rec.CURRENCY_TYPE,
 'INP',
 NULL,
 v_invoice_number,
 v_fin_req_amt,
 pbm_pat_rec.clinician_id,
 pbm_pat_rec.SYSTEM_OF_MEDICINE_TYPE_ID,
 pbm_pat_rec.ACCIDENT_RELATED_TYPE_ID,
 NULL,
 'Y',
 pbm_pat_rec.benifit_type,
 pbm_pat_rec.GRAVIDA,
 pbm_pat_rec.PARA,
 pbm_pat_rec.LIVE,
 pbm_pat_rec.ABORTION,
 pbm_pat_rec.PRESENTING_COMPLAINTS,
  pbm_pat_rec.MEDICAL_OPINION_REMARKS,
   pbm_pat_rec.HOSP_SEQ_ID,
   v_provider_name,
   NULL,
   NULL,
   NULL,
   NULL,
   NULL,
   NULL,
   v_provider_id,
   NULL,
   V_CLINICIAN_NAME,
   1,--pbm_pat_rec.ADDED_BY,
   NULL,
   NULL,
   NULL,
   pbm_pat_rec.conception_type,
   pbm_pat_rec.lmp_date,
   pbm_pat_rec.Req_Amt_Currency_Type,
   pbm_pat_rec.Converted_Amount,
   pbm_pat_rec.Converted_Amount_Currency_Type,
   1,--pbm_pat_rec.Conversion_Rate,
   pbm_pat_rec.process_type,
    pbm_pat_rec.oth_tpa_ref_no,
	pbm_pat_rec.delvry_mod_type,
	pbm_pat_rec.treatment_type,
	pbm_pat_rec.EVENT_NO,
  null,
  null,
  null,
  null,
  'N',
  null,
  null,
	V_ROWS_PROCESSED);
   
 
 
 

  
  update pat_authorization_details set claim_seq_id=v_claim_seq_id
  where pat_auth_seq_id = v_pat_auth_seq_id;
  
  UPDATE APP.CLM_AUTHORIZATION_DETAILS SET assign_user_seq_id= pbm_pat_rec.assign_user_seq_id
  WHERE CLAIM_SEQ_ID=v_claim_seq_id;
  
 --intx.authorization_pkg.reassign_user(v_claim_seq_id,null,null,1,null,v_seq_id);
 INTX.authorization_pkg.reassign_user(null,'|'||v_claim_seq_id||'|',null,1,'SUP',v_Seq_id);
  
 

save_clm_diagnosys_details(v_pat_auth_seq_id,v_claim_seq_id);
save_clm_activity_details(v_res,v_pat_auth_seq_id,v_claim_seq_id);
calculate_clm_authorization(v_claim_seq_id,pbm_pat_rec.hosp_seq_id,v_allowed_amount,pbm_clm_rec.added_by);


COMMIT;


open v_result_set for
select a.CLAIM_NUMBER,a.CLM_BATCH_SEQ_ID,a.INVOICE_NUMBER,a.CLAIM_TYPE,a.CLM_STATUS_TYPE_ID,a.CLM_RECEIVED_DATE,
a.converted_amount  as TOT_ALLOWED_AMOUNT,a.claim_seq_id,b.BATCH_NO,a.mem_name,c.policy_number,a.CLINICIAN_ID,d.CLINICIAN_NAME 
from CLM_AUTHORIZATION_DETAILS a 
join  APP.CLM_BATCH_UPLOAD_DETAILS b on (a.CLM_BATCH_SEQ_ID=b.CLM_BATCH_SEQ_ID)
join tpa_enr_policy c on (a.policy_seq_id=c.policy_seq_id)
join PAT_NON_NETWORK_DETAILS d on (a.PAT_AUTH_SEQ_ID=d.PAT_AUTH_SEQ_ID)
where a.claim_seq_id=v_claim_seq_id;

end save_pbm_clm;
--============================================================================
PROCEDURE save_clm_diagnosys_details(
  --v_diag_seq_id       IN OUT diagnosys_details.diag_seq_id%type,
  v_pat_auth_seq_id   IN diagnosys_details.pat_auth_seq_id%type,
   v_claim_seq_id     IN diagnosys_details.CLAIM_SEQ_ID%type
  )
  IS
  
  CURSOR clm_dia_cur IS
  select * from diagnosys_details
  where pat_auth_seq_id=v_pat_auth_seq_id;
  
  clm_dia_rec clm_dia_cur%rowtype;
  
  
 CURSOR clm_cur IS
 SELECT pad.pat_auth_seq_id,
 
       pad.clm_batch_seq_id,
       pad.claim_seq_id,
       pad.member_seq_id,       
       pad.final_app_amount,
       pad.denial_reason,
       pad.completed_yn
  FROM clm_authorization_details pad
  WHERE pad.claim_seq_id=v_claim_seq_id;
  

  
  clm_rec              clm_cur%ROWTYPE;
  v_prod_pol_rule_seq_id       tpa_ins_prod_policy_rules.prod_policy_rule_seq_id%type;
  
  CURSOR diag_cur IS
  SELECT count(1)
  FROM diagnosys_details dd
  WHERE dd.claim_seq_id=v_claim_seq_id
  AND dd.diag_seq_id!=nvl(clm_dia_rec.diag_seq_id,0)--nvl(v_diag_seq_id,0)
  AND dd.diagnosys_code=TRIM(upper(clm_dia_rec.diagnosys_code));
  
  CURSOR primary_cur IS
  SELECT count(1)
  FROM diagnosys_details dd
  WHERE dd.claim_seq_id=v_claim_seq_id
  AND dd.diag_seq_id!=NVL(clm_dia_rec.diag_seq_id,0)--NVL(v_diag_seq_id,0)
  AND dd.primary_ailment_yn='Y';
  
  v_diag_count           number(2);
  v_primary              number(2);
  v_priamry_yn        diagnosys_details.Primary_Ailment_Yn%TYPE;
  v_diag_seq_id      diagnosys_details.diag_seq_id%type;
 
BEGIN 
  OPEN clm_dia_cur;
   FETCH clm_dia_cur INTO clm_dia_rec;
  CLOSE clm_dia_cur;

  if v_claim_seq_id is not null then
   OPEN clm_cur;
   FETCH clm_cur INTO clm_rec;
   CLOSE clm_cur;
  end if;   
  IF clm_rec.completed_yn='Y' THEN
    RAISE_APPLICATION_ERROR(-20107,'You cannot perform this action through a completed Claim.');
  END IF;
  

  
  OPEN diag_cur;
  FETCH diag_cur INTO v_diag_count;
  CLOSE diag_cur;
  
  OPEN primary_cur;
  FETCH primary_cur INTO v_primary;
  CLOSE primary_cur;
  
  IF NVL(v_priamry_yn,'N')='Y' AND v_primary>0 THEN
        RAISE_APPLICATION_ERROR(-20379,'Primary Diagnosis already Exists!');
  END IF;       

  
  
  IF v_diag_count>0 THEN
    RAISE_APPLICATION_ERROR(-20374,'Diagnosis code already Exists!');
  END IF;
 
   
  v_priamry_yn:= case when v_primary =0 then 'Y' else 'N' end;
  
  for i in clm_dia_cur
  loop
   
  IF NVL(v_diag_seq_id,0)=0 THEN
  
  
   -- IF NVL(clm_dia_rec.diag_seq_id,0)=0 THEN
    INSERT INTO diagnosys_details(
                diag_seq_id,
				        claim_seq_id,
                pat_auth_seq_id,
                icd_code_seq_id,
                diagnosys_code,
                primary_ailment_yn,
                added_by,
                added_date
                )
          VALUES (
                diagnosys_detail_seq.nextval,
               v_claim_seq_id,
                 null,
                i.icd_code_seq_id,
                UPPER(TRIM(i.diagnosys_code)),
                i.PRIMARY_AILMENT_YN,
                i.added_by,
                SYSDATE
                ) ;--RETURNING DIAG_SEQ_ID INTO v_diag_seq_id;
   ELSE
     
      UPDATE diagnosys_details SET
          PAT_AUTH_SEQ_ID      =  V_PAT_AUTH_SEQ_ID,
          icd_code_seq_id      =  clm_dia_rec.icd_code_seq_id,
          diagnosys_code       =  upper(clm_dia_rec.diagnosys_code),
          primary_ailment_yn   =  clm_dia_rec.PRIMARY_AILMENT_YN,
          updated_by           =  clm_dia_rec.added_by,
          updated_date         =  sysdate
    WHERE DIAG_SEQ_ID =v_diag_seq_id;
    
  END IF;
  end loop;
  --v_rows_processed:=SQL%ROWCOUNT;
 COMMIT;
  
END save_clm_diagnosys_details;
--====================================================================================

PROCEDURE save_clm_activity_details(v_res                     IN varchar2,
                                    v_pat_auth_seq_id         IN  pat_activity_details.pat_auth_seq_id%TYPE,
	                                  v_claim_seq_id			      IN  pat_activity_details.claim_seq_id%TYPE)
 IS

 CURSOR act_cur IS
  SELECT COUNT(1) CLM_ACT_CNT
  FROM pat_activity_details pad
  WHERE pad.claim_seq_id=v_claim_seq_id;
  
  CURSOR pat_diag_cur IS
  SELECT count(1) 
  FROM diagnosys_details dd
  WHERE dd.claim_seq_id=v_claim_seq_id;
  
  CURSOR pat_cur IS
 SELECT pad.pat_auth_seq_id,
       pad.clm_batch_seq_id,
       pad.claim_seq_id,
       pad.member_seq_id,       
       pad.final_app_amount,
       pad.denial_reason,
       pad.completed_yn,
       pad.source_type_id,
       --pad.hosp_seq_id,
       trunc(pad.date_of_hospitalization) as hospitalization_date 
  FROM clm_authorization_details pad
  WHERE pad.claim_seq_id=v_claim_seq_id;
  
 pat_rec              pat_cur%ROWTYPE;
 act_rec              act_cur%ROWTYPE;
 v_diag_count         NUMBER;
 
BEGIN

  IF v_claim_seq_id IS NOT NULL THEN 
   OPEN  pat_diag_cur;
   FETCH pat_diag_cur INTO v_diag_count;
   CLOSE pat_diag_cur;
  END IF;
  
   OPEN act_cur;
   FETCH act_cur INTO act_rec;
   CLOSE act_cur;
  
  if v_claim_seq_id is not null then
   OPEN pat_cur;
   FETCH pat_cur INTO pat_rec;
   CLOSE pat_cur;
  end if;
  
  IF pat_rec.completed_yn='Y' THEN
    RAISE_APPLICATION_ERROR(-20107,'You cannot perform this action through a completed Claim.');
  END IF;
  
  IF v_diag_count<1 THEN
    RAISE_APPLICATION_ERROR(-20380,'Please add atleast one Diagnosis');
  END IF;
  
  FOR i IN (SELECT ROW_NUMBER() OVER (ORDER BY PA.ACTIVITY_DTL_SEQ_ID) AS SL_NO,
                   PA.*
            FROM APP.PAT_ACTIVITY_DETAILS PA 
            WHERE PA.PAT_AUTH_SEQ_ID = v_pat_auth_seq_id
            AND PA.ACTIVITY_DTL_SEQ_ID IN (Select column_value as val from table(cast(ttk_mail_pkg.parse(v_res,'|') as strings)))) loop
  
  IF act_rec.clm_act_cnt =0 AND v_claim_seq_id IS NOT NULL THEN
    INSERT INTO pat_activity_details(
                activity_dtl_seq_id,
                --pat_auth_seq_id,
                claim_seq_id,
                Activity_Seq_Id,
                activity_id,
                s_no,
                start_date,
                activity_type,
                code,
                unit_type,
                modifier,
                internal_code,
                package_id,
                bundle_id,
                quantity,
                gross_amount,
                discount_amount,
                disc_gross_amount,
                patient_share_amount,
                co_ins_amount,
                deduct_amount,
                out_of_pocket_amount,
                net_amount,
                allowed_amount,
                approved_amount,
                allow_yn,
                denial_code,
                remarks,
                added_by,
                added_date,
                denial_desc,
                approvd_quantity,
                unit_price,
                unit_discount_amount,
                provider_copay,
                override_yn,
                override_remarks,
                approve_yn,
                posology_duration,
                posology,
                provider_net_amount,
				        --prior_authid,
                service_type,
                service_code,
                service_remarks,
                ucr,
                ri_copar,
                denial_res_dis,
                CONVERTED_ACITIVTY_AMT,
                MOPH_CODES,
                discount_amount_new)
          VALUES (
                pat_activity_detail_seq.nextval,
                --v_pat_auth_seq_id,
                v_claim_seq_id,
                i.activity_seq_id,
                i.activity_id,
                i.sl_no,
                i.start_date,
                i.activity_type,
                i.code,
                i.unit_type,
                i.modifier,
                i.internal_code,
                i.package_id,
                i.bundle_id,
                i.quantity,
                i.gross_amount,
                i.discount_amount,
                i.disc_gross_amount,
                i.patient_share_amount,
                i.co_ins_amount,
                i.deduct_amount,
                i.out_of_pocket_amount,
                i.disc_gross_amount,--v_net_amount,
                i.allowed_amount,
                i.approved_amount,
                i.allow_yn,
                i.denial_code,
                i.remarks,
                i.added_by,
                SYSDATE,
                i.denial_desc,
                i.approvd_quantity,
                i.unit_price,
                i.unit_discount_amount,
                i.copay_amount,
                i.override_yn,
                i.override_remarks,
                i.approve_yn,
                i.posology_duration,
                i.posology,
                i.disc_gross_amount,
                i.service_type,
                i.service_code,
                i.service_remarks, 
                i.ucr,--Changed by priyadarshan
                NULL,
                i.denial_res_dis,
                i.unit_price,
                i.moph_codes,
                i.discount_amount_new);
     END IF;
 END LOOP;
 
 update APP.TPA_USER_CONTACTS set prefix_general_type_id=null
     where CONTACT_SEQ_ID=1;
  --v_rows_processed:=SQL%ROWCOUNT;
  
  COMMIT;
END save_clm_activity_details;
--=========================================================================================

--===============================================================================================================
PROCEDURE calculate_clm_authorization(v_claim_seq_id               IN  clm_authorization_details.claim_seq_id%type,
                                  v_hosp_seq_id                IN  clm_hospital_details.hosp_seq_id%TYPE,
                                  v_allowed_amount             OUT clm_authorization_details.tot_allowed_amount%type,
                                  --v_result_set                 OUT SYS_REFCURSOR,
                                  v_added_by                   IN  NUMBER
                                  )
IS

v_patient_share_amt Pat_Activity_Details.Patient_Share_Amount%TYPE;
v_approved_amount   Pat_Activity_Details.Approved_Amount%TYPE;
v_allowed_amt       Pat_Activity_Details.Allowed_Amount%TYPE;
v_Copay_amnt        NUMBER(10,2);
v_Patient_share     NUMBER(10,2);
v_Net_amnt          NUMBER(10,2);
v_Allowed_amnt      NUMBER(10,2);
v_Approved_amnt     NUMBER(10,2);
v_Disallowed_amnt   NUMBER(10, 2);
v_copay_perc        NUMBER;
v_non_network_co_pay NUMBER;

CURSOR act_cur IS
SELECT SUM(NVL(pa.gross_amount,0)) as tot_gross_amount
      ,SUM(NVL(pa.discount_amount,0)) as tot_discount_amount
      ,SUM(NVL(pa.disc_gross_amount,0)) as tot_disc_gross_amount
      ,SUM(NVL(pa.patient_share_amount,0)) as tot_patient_share_amount
      ,SUM(NVL(pa.net_amount,0)) as tot_net_amount
      ,SUM(NVL(pa.allowed_amount,0)) as tot_allowed_amount
      ,SUM(NVL(pa.approved_amount,0)) as tot_approved_amount
      ,SUM(NVL(pa.ucr, 0))            as tot_ucr_amount
 FROM pat_activity_details pa
WHERE pa.claim_seq_id=v_claim_seq_id;

 CURSOR clm_cur IS
  SELECT cad.denial_reason,cad.parent_claim_seq_id,cad.denial_code,cad.remarks,cad.completed_yn,cad.member_seq_id,cad.pat_auth_seq_id,
     to_date(cad.date_of_hospitalization,'dd/mm/rrrr') as hospitalization_date,cad.claim_type,cad.network_yn,
     cad.benifit_type,cad.hlt_chkp_copay_perc,cad.hlt_chkp_deductbl,cad.hlt_chkp_cpay_deduct_flag,
	 CASE  WHEN cad.duration_flag = 'DAYS'  THEN CASE WHEN  cad.DUR_AILMENT > (cad.date_of_hospitalization-mem.date_of_inception) THEN 'Y' ELSE 'N' END 
           WHEN cad.duration_flag = 'MONTHS' THEN CASE WHEN cad.DUR_AILMENT> trunc(months_between(cad.date_of_hospitalization,mem.date_of_inception)) THEN 'Y' ELSE 'N' END
           WHEN cad.duration_flag = 'YEARS' THEN CASE WHEN cad.DUR_AILMENT> trunc(months_between(cad.date_of_hospitalization,mem.date_of_inception)/12) THEN 'Y' ELSE 'N' END END AS PED,
     to_date(cad.date_of_discharge,'dd/mm/rrrr') as date_of_discharge,cad.req_amt_currency_type,
     cad.conversion_rate,NVL(cad.process_type,'RGL') AS process_type
     FROM clm_authorization_details cad
     JOIN tpa_enr_policy_member mem ON (cad.member_seq_id=mem.member_seq_id)     
     WHERE cad.claim_seq_id=v_claim_seq_id;
   
   CURSOR enrol_type IS
select ep.enrol_type_id,ep.policy_seq_id,pm.vip_yn,(ad.requested_amount-nvl(ad.tot_patient_share_amount,0)) as net_amount 
from app.tpa_enr_policy ep 
join app.clm_authorization_details ad on (ep.policy_seq_id=ad.policy_seq_id)
join app.tpa_enr_policy_member pm on (pm.member_seq_id = ad.member_seq_id)
where ad.claim_seq_id=v_claim_seq_id; 

enrol_rec                  enrol_type%rowtype;

  CURSOR cur_corp_pol(vip_yn varchar2) IS
   SELECT case when nvl(vip_yn,'N')='Y' then gt.vip_pre_aprvl_limit_yn else gt.non_vip_pre_aprvl_limit_yn end as pre_aprvl_limit_yn,
          case when nvl(vip_yn,'N')='Y' then gt.vip_pre_aprvl_limit else gt.non_vip_pre_aprvl_limit end as pre_aprvl_limit,
          case when nvl(vip_yn,'N')='Y' then gt.vip_mdt_srvce_pre_aprvl_yn else gt.non_vip_mdt_srvce_pre_aprvl_yn end as pre_aprvl_mdt_srvc_yn  
        FROM tpa_enr_policy GH
        JOIN tpa_ins_prod_policy GT ON (GH.policy_seq_id=GT.policy_seq_id)
     WHERE GH.policy_seq_id=enrol_rec.policy_seq_id;
     
  CURSOR cur_ind_pol(vip_yn varchar2) IS   
     SELECT case when nvl(vip_yn,'N')='Y' then tipp.vip_pre_aprvl_limit_yn else tipp.non_vip_pre_aprvl_limit_yn end as pre_aprvl_limit_yn,
            case when nvl(vip_yn,'N')='Y' then tipp.vip_pre_aprvl_limit else tipp.non_vip_pre_aprvl_limit end as pre_aprvl_limit,
            case when nvl(vip_yn,'N')='Y' then tipp.vip_mdt_srvce_pre_aprvl_yn else tipp.non_vip_mdt_srvce_pre_aprvl_yn end as pre_aprvl_mdt_srvc_yn
     FROM tpa_enr_policy tep
     LEFT OUTER JOIN tpa_ins_product tip on (tip.product_seq_id=tep.product_seq_id)
     LEFT OUTER JOIN tpa_ins_prod_policy tipp on (tipp.product_seq_id=tip.product_seq_id)
     WHERE tep.policy_seq_id=enrol_rec.policy_seq_id; 
 
act_rec                    act_cur%ROWTYPE;
clm_rec                    clm_cur%ROWTYPE;
v_remarks                  varchar2(100);
v_pre_approval_limit_yn    varchar2(1);
v_pre_approval_limit       number(10);
v_pre_aprvl_mdt_srvc_yn    varchar2(1);
v_pat_yn                   varchar2(1):='N';
v_final_allowed_amount  number;
--v_chronic_count            number(10);

BEGIN
 
    OPEN clm_cur;
    FETCH clm_cur INTO clm_rec;
    CLOSE clm_cur;
    
   
    OPEN enrol_type;
    FETCH enrol_type INTO enrol_rec;
    CLOSE enrol_type;
    
     IF nvl(clm_rec.Completed_Yn,'N')='Y' THEN
        RAISE_APPLICATION_ERROR(-20107,'You cannot perform this action through a completed Claim.');
     END IF;
     IF enrol_rec.enrol_type_id='IND' THEN
       v_prod_policy_rule_seq_id:=authorization_pkg.get_prod_pol_seq_id(enrol_rec.policy_seq_id,'IND');
     ELSE
       v_prod_policy_rule_seq_id:=authorization_pkg.get_prod_pol_seq_id(enrol_rec.policy_seq_id,'POL');
     END IF; 
    
  IF enrol_rec.policy_seq_id IS NOT NULL THEN  
   IF enrol_rec.enrol_type_id='COR' THEN
     OPEN  cur_corp_pol(enrol_rec.vip_yn);
     FETCH cur_corp_pol INTO v_pre_approval_limit_yn,v_pre_approval_limit,v_pre_aprvl_mdt_srvc_yn;
     CLOSE cur_corp_pol;
   ELSE
     OPEN  cur_ind_pol(enrol_rec.vip_yn);
     FETCH cur_ind_pol INTO v_pre_approval_limit_yn,v_pre_approval_limit,v_pre_aprvl_mdt_srvc_yn;
     CLOSE cur_ind_pol;
  END IF;
 END IF;   
    IF clm_rec.claim_type='CNH' and nvl(v_pre_approval_limit_yn,'N')='Y' and enrol_rec.net_amount<= v_pre_approval_limit THEN
      v_pat_yn:='N';
    ELSE 
      v_pat_yn:='Y';
    END IF;
      update pat_activity_details ad
      set 
      ad.denial_code=case when (nvl(ad.override_yn,'N')='N' and ad.denial_code is not null) then null 
                          when (nvl(ad.override_yn,'N')='Y' and ad.denial_code is not null) then ad.denial_code else null end,
      ad.remarks=null,
      ad.denial_desc=case when (nvl(ad.override_yn,'N')='N' and ad.denial_code is not null) then null
                          when (nvl(ad.override_yn,'N')='Y' and ad.denial_code is not null) then ad.denial_desc else null end,
      ad.patient_share_amount=null/*case when nvl(ad.override_yn,'N')='N' then 0 else ad.patient_share_amount end*/,
      ad.allowed_amount=null,
      ad.approved_amount=null,ad.copay_perc=null,
      ad.benifit_copay=null, ad.benifit_deductible = null, ad.copay_amount=null,ad.rule_limit=null,
      ad.approvd_quantity = case when nvl(ad.phy_yn,'N')='Y' then ad.quantity else ad.approvd_quantity end,
      ad.denial_by_rule_cond_id_dtls = NULL,
      ad.denial_by_rule_proc_dtls = NULL,
      ad.denial_by_resons = NULL,
    ad.provider_copay=null,
      ad.Prov_Copay_flag=null,
      ad.Prov_Copay_Perc=null
      where ad.claim_seq_id=v_claim_seq_id/* and nvl(ad.override_yn,'N')='N'*/ 
      and nvl(ad.pbm_wb_srvc_exec_yn,'N') = 'N';
      
      update diagnosys_details dd 
      set dd.denial_reason=null,
          dd.remarks=null,dd.rule_limit=null,dd.rule_copay=null,dd.deduct=0,dd.copay=null,dd.copay_limit=null,
          dd.copay_persent = NULL
       where dd.claim_seq_id=v_claim_seq_id;
       
      update clm_authorization_details pad
      set pad.benefit_limit=null,
          pad.benefit_copay=null,
          pad.tot_allowed_amount=null,
          pad.tot_approved_amount=null,
          pad.tot_patient_share_amount=null,
      pad.sys_med_yn = null,
      pad.sys_med_limit=null,
          pad.area_cover_yn = NULL,
          pad.area_cov_rule_reg_id = NULL,
          pad.area_rule_limit = NULL,
          pad.out_area_cover_yn = NULL,
          pad.out_area_cov_rule_reg_id = NULL,
          pad.in_out_area_covr_yn = NULL,
          pad.in_out_amnt_perc = NULL
          where pad.claim_seq_id = v_claim_seq_id;
     
   
    IF clm_rec.Denial_Reason is not null or clm_rec.denial_code is not null THEN
      UPDATE pat_activity_details pad
               SET pad.denial_desc  = clm_rec.Denial_Reason,
                   pad.denial_code  = clm_rec.denial_code,
                   pad.remarks      = clm_rec.remarks,
                   pad.updated_by   = v_added_by,
                   pad.updated_date = SYSDATE,
                   pad.denial_by_rule_proc_dtls = TRIM(BOTH ';' FROM (pad.denial_by_rule_proc_dtls||';'||CHR(10)||'claim_pkg.calculate_authorization'))
             WHERE pad.claim_seq_id = v_claim_seq_id and nvl(pad.override_yn,'N')='N';
    end if; 
    commit; 
--    select count(1) into v_chronic_count from  
--    app.clm_authorization_details d join app.diagnosys_details dd on (d.claim_seq_id=dd.claim_seq_id and d.benifit_type='OPTS')
--    join app.tpa_day_care_icd c on (c.icd_code=dd.diagnosys_code AND dd.primary_ailment_yn='Y') where d.claim_seq_id=v_claim_seq_id;
--    

   -------pbm rules----------------------------------------
    check_mdcl_necessity_rules_1(v_claim_seq_id,'CLM',v_added_by);	
    check_therapeutic_rule_2(v_claim_seq_id,'CLM',v_added_by);
    check_ci_icd_ddc_rules_3(v_claim_seq_id,'CLM',v_added_by);
    check_ci_ddc_ddc_generic(v_claim_seq_id,'CLM',v_added_by);
    check_age_band_rule_4(v_claim_seq_id,'CLM',v_added_by);
    check_gender_rule_5(v_claim_seq_id,'CLM',v_added_by);
    priliminary_check_rule_6(v_claim_seq_id,'CLM',v_added_by);
    check_refill_to_soon_7(v_claim_seq_id,'CLM' ,CLM_rec.member_seq_id,v_added_by);
    check_mat_icd_ddc_rule_8(v_claim_seq_id,'CLM',v_added_by);
    -------pbm rules----------------------------------------
    pat_xml_load_pkg.check_duplicate_activity(v_claim_seq_id,'CLM',v_added_by);
    pat_xml_load_pkg.check_ddc_rule(v_claim_seq_id,'CLM',v_added_by);
    pat_xml_load_pkg.execute_diag_rule(v_claim_seq_id,'CLM' ,v_prod_policy_rule_seq_id  ,v_added_by);     
    pat_xml_load_pkg.execute_activity_rule(v_claim_seq_id,'CLM',v_prod_policy_rule_seq_id  ,v_added_by  );        
   
    pat_xml_load_pkg.calculate_allowed_amount( v_claim_seq_id,'CLM');
    
    OPEN  act_cur;
    FETCH act_cur INTO act_rec;
    CLOSE act_cur;
    
    UPDATE clm_authorization_details A
    SET a.tot_gross_amount           = act_rec.tot_gross_amount,
        a.tot_discount_amount        = act_rec.tot_discount_amount,
        a.tot_disc_gross_amount      = act_rec.tot_disc_gross_amount,
        a.tot_patient_share_amount   = act_rec.tot_patient_share_amount,
        a.tot_net_amount             = act_rec.tot_net_amount,
        a.tot_allowed_amount         = act_rec.tot_allowed_amount,
        a.tot_approved_amount        = act_rec.tot_approved_amount,
        a.clm_status_type_id         = 'INP' 
   WHERE a.Claim_Seq_Id           = v_claim_seq_id
   RETURNING a.tot_allowed_amount INTO v_allowed_amount;
   
   pat_xml_load_pkg.execute_global_amnt_rules('C',v_claim_seq_id,clm_rec.member_seq_id,v_Prod_Policy_Rule_Seq_Id);
  --authorization_pkg.check_pat_approved(v_claim_seq_id,v_added_by);
  authorization_pkg.check_activity_limits(v_claim_seq_id,'CLM',v_allowed_amount,v_added_by,v_remarks,v_final_allowed_amount);
  
   
  UPDATE pat_activity_details pad
               SET pad.denial_desc  = replace(pad.denial_desc,';;',';')
                   WHERE pad.CLAIM_SEQ_ID = v_claim_seq_id;
  
 commit;
 
 END calculate_clm_authorization;
 --=========================================================================================
 PROCEDURE PBM_CLM_DRUG_RPT (
    v_input_list IN  VARCHAR2,
    v_result_set  OUT SYS_REFCURSOR
  )
  IS
    str_tab    ttk_util_pkg.str_table_type;
  BEGIN
    str_tab := ttk_util_pkg.parse_str ( v_input_list );
     IF str_tab(8) IS NULL THEN
        str_tab(8) := to_char(SYSDATE,'dd/mm/yyyy');
     END IF;
     IF str_tab(12) IS NULL THEN
        str_tab(12) := to_char(SYSDATE,'dd/mm/yyyy');
     END IF;
     IF str_tab(1) = 'drugSubmissionId' OR str_tab(1) = 'drugPaymentId' OR str_tab(1) = 'drugDispenseId' THEN
      IF str_tab(15) = 'PD' THEN

     OPEN v_result_set FOR
select a.TPA_ENROLLMENT_ID AS ALKOOT_ID
    ,a.PRE_AUTH_NUMBER AS PRE_APPROVAL_NUMBER
    ,a.AUTH_NUMBER AS AUTHORIZATION_NUMBER,
   /* B.REQUESTED_AMOUNT AS REQUESTED_AMOUNT*/
   C.GROSS_AMOUNT AS REQUESTED_AMOUNT
    ,B.CLAIM_NUMBER AS CLAIM_NUMBER,
    A.MEM_NAME AS PATIENT_NAME,
    case when b.completed_yn='Y' and b.CLM_STATUS_TYPE_ID ='APR' then 'Approved'
                  when b.completed_yn='Y' and b.CLM_STATUS_TYPE_ID ='REJ' then 'Rejected'
                  when b.CLM_STATUS_TYPE_ID='REQ' THEN 'Shortfall'
                  When b.CLM_STATUS_TYPE_ID='INP' then 'In Progress' end   AS status,
     case when b.claim_seq_id is not null then 'PA Apprvd and Dispensed'--v_clm_pay_status
                  when b.claim_seq_id is  null then 'PA Apprvd not Dispensed'
                    end  AS DISPENSE_STATUS,
    B.INVOICE_NUMBER AS INVOICE_NUMBER,
    --NULL AS EVENT_REFERENCE_NUMBER,
    --C.PATIENT_SHARE_AMOUNT,
    C.DISALLOWED_AMOUNT AS DISALLOWED_AMOUNT,
    C.DISCOUNT_AMOUNT AS DISCOUNT_AMOUNT,
    NULL AS PAYMENT_REFRENCE_NUMBER,
    M.ACTIVITY_DESCRIPTION AS DRUG_DESCRIPTION,
    C.QUANTITY AS QUANTITY,
    C.DENIAL_DESC AS DENIAL_REASON,
   -- NULL AS STATUS_DISPENSE,
   case when b.completed_yn='Y' and b.CLM_STATUS_TYPE_ID ='APR' then  C.APPROVED_AMOUNT
                  when b.completed_yn='Y' and b.CLM_STATUS_TYPE_ID ='REJ' then C.APPROVED_AMOUNT
                  when b.completed_yn='Y' and b.CLM_STATUS_TYPE_ID not in ('REJ','APR') then null end as APPROVED_AMOUNT,
                  --B.TOT_APPROVED_AMOUNT as APPROVED_AMOUNT,
    --C.APPROVED_AMOUNT,
    TO_CHAR(B.DATE_OF_HOSPITALIZATION,'DD/MM/YYYY') AS PRESCRIPTION_DATE,
    TO_CHAR(B.CLM_RECEIVED_DATE,'DD/MM/YYYY') AS DISPENSED_DATE,
    c.PATIENT_SHARE_AMOUNT,
    case when b.claim_type='CTM' THEN 0 
                   when b.claim_type ='CNH' THEN c.disc_gross_amount END AS AGREED_AMOUNT,
    A.EVENT_NO AS EVENT_REFERENCE_NUMBER,
    CD.BATCH_NO
 FROM    APP.PAT_ACTIVITY_DETAILS c  LEFT OUTER JOIN
                 CLM_authorization_details b ON (C.CLAIM_SEQ_ID=b.claim_seq_id)
                 LEFT OUTER JOIN APP.CLM_BATCH_UPLOAD_DETAILS CD ON(CD.CLM_BATCH_SEQ_ID=B.CLM_BATCH_SEQ_ID)
                  LEFT OUTER JOIN  pat_authorization_details a on (b.PAT_AUTH_SEQ_ID=a.PAT_AUTH_SEQ_ID)

                  LEFT OUTER JOIN  tpa_hosp_info d on(a.hosp_seq_id=d.hosp_seq_id) 
                  --left outer join diagnosys_details dd on (dd.claim_seq_id=cad.claim_seq_id)
        --left outer join tpa_icd10_master_details tic on (CAD.BENIFIT_TYPE=tic.BENEFIT_TYPE)
        left outer join TPA_PHARMACY_MASTER_DETAILS M on (C.CODE=M.ACTIVITY_CODE)
          left outer join FIN_APP.TPA_CLAIMS_PAYMENT z on (b.claim_seq_id=z.CLAIM_SEQ_ID and z.policy_seq_id=a.policy_seq_id)
           left outer join FIN_APP.TPA_PAYMENT_CHECKS_DETAILS n on (n.PAYMENT_SEQ_ID=z.PAYMENT_SEQ_ID)
          left outer  join FIN_APP.tpa_claims_check f on (n.CLAIMS_CHK_SEQ_ID=f.CLAIMS_CHK_SEQ_ID)
    WHERE D.EMPANEL_NUMBER=str_tab(2)
    AND ( str_tab(3) IS NULL OR B.INVOICE_NUMBER=str_tab(3))
    AND ( str_tab(4) IS NULL OR a.TPA_ENROLLMENT_ID=str_tab(4) )
    AND ( str_tab(5) IS NULL OR B.CLAIM_NUMBER=str_tab(5))
    AND ( str_tab(6) IS NULL OR B.CLM_STATUS_TYPE_ID=str_tab(6))
    AND 
  (str_tab(7) is null or trunc(b.CLM_RECEIVED_DATE) between to_date(str_tab(7),'dd/mm/yyyy') and to_date(str_tab(8),'dd/mm/yyyy')+1)
  AND (str_tab(9) IS NULL OR  B.MEM_NAME=str_tab(9))
  AND (str_tab(10) IS NULL OR  A.EVENT_NO=str_tab(10))
  AND 
  (str_tab(11) is null or  trunc(b.date_of_hospitalization) between to_date(str_tab(11),'dd/mm/yyyy') and to_date(str_tab(12),'dd/mm/yyyy')+1)
  AND (str_tab(13) IS NULL OR  B.AUTH_NUMBER=str_tab(13))
  AND (str_tab(14) IS NULL OR  A.PRE_AUTH_NUMBER=str_tab(14))
  AND --(str_tab(15) IS NULL OR  
  c.claim_seq_id is not null--)
  and a.pbm_yn='Y'
  order by  A.PRE_AUTH_NUMBER ; ---addded by lalatendu
  ELSE
  OPEN v_result_set FOR
select a.TPA_ENROLLMENT_ID AS ALKOOT_ID
    ,a.PRE_AUTH_NUMBER AS PRE_APPROVAL_NUMBER
    ,a.AUTH_NUMBER AS AUTHORIZATION_NUMBER,
   /* B.REQUESTED_AMOUNT AS REQUESTED_AMOUNT*/
   C.GROSS_AMOUNT AS REQUESTED_AMOUNT
    ,B.CLAIM_NUMBER AS CLAIM_NUMBER,
    a.MEM_NAME AS PATIENT_NAME,
    case when b.completed_yn='Y' and b.CLM_STATUS_TYPE_ID ='APR' then 'Approved'
                  when b.completed_yn='Y' and b.CLM_STATUS_TYPE_ID ='REJ' then 'Rejected'
                  when b.CLM_STATUS_TYPE_ID='REQ' THEN 'Shortfall'
                  When b.CLM_STATUS_TYPE_ID='INP' then 'In Progress' end   AS status,
     case when b.claim_seq_id is not null then 'PA Apprvd and Dispensed'--v_clm_pay_status
                  when b.claim_seq_id is  null then 'PA Apprvd not Dispensed'
                    end  AS DISPENSE_STATUS,
    B.INVOICE_NUMBER AS INVOICE_NUMBER,
    --NULL AS EVENT_REFERENCE_NUMBER,
    --C.PATIENT_SHARE_AMOUNT,
    C.DISALLOWED_AMOUNT AS DISALLOWED_AMOUNT,
    C.DISCOUNT_AMOUNT AS DISCOUNT_AMOUNT,
    NULL AS PAYMENT_REFRENCE_NUMBER,
    M.ACTIVITY_DESCRIPTION AS DRUG_DESCRIPTION,
    C.QUANTITY AS QUANTITY,
    C.DENIAL_DESC AS DENIAL_REASON,
   -- NULL AS STATUS_DISPENSE,
    case when b.completed_yn='Y' and b.CLM_STATUS_TYPE_ID ='APR' then  C.APPROVED_AMOUNT
                  when b.completed_yn='Y' and b.CLM_STATUS_TYPE_ID ='REJ' then C.APPROVED_AMOUNT
                  when b.completed_yn='Y' and b.CLM_STATUS_TYPE_ID not in ('REJ','APR') then null end as APPROVED_AMOUNT,
   -- C.APPROVED_AMOUNT,
    TO_CHAR(a.HOSPITALIZATION_date,'DD/MM/YYYY') AS PRESCRIPTION_DATE,
    TO_CHAR(B.CLM_RECEIVED_DATE,'DD/MM/YYYY') AS DISPENSED_DATE,
    c.PATIENT_SHARE_AMOUNT,
    case when b.claim_type='CTM' THEN 0 
                   when b.claim_type ='CNH' THEN c.disc_gross_amount END AS AGREED_AMOUNT,
    A.EVENT_NO AS EVENT_REFERENCE_NUMBER,
    CD.BATCH_NO
    FROM    APP.PAT_ACTIVITY_DETAILS c  LEFT OUTER JOIN
                 CLM_authorization_details b ON (C.CLAIM_SEQ_ID=b.claim_seq_id)
                 LEFT OUTER JOIN APP.CLM_BATCH_UPLOAD_DETAILS CD ON(CD.CLM_BATCH_SEQ_ID=B.CLM_BATCH_SEQ_ID)
                  LEFT OUTER JOIN  pat_authorization_details a on (C.PAT_AUTH_SEQ_ID=a.PAT_AUTH_SEQ_ID)

                  LEFT OUTER JOIN  tpa_hosp_info d on(a.hosp_seq_id=d.hosp_seq_id) 
                  --left outer join diagnosys_details dd on (dd.claim_seq_id=cad.claim_seq_id)
        --left outer join tpa_icd10_master_details tic on (CAD.BENIFIT_TYPE=tic.BENEFIT_TYPE)
        left outer join TPA_PHARMACY_MASTER_DETAILS M on (C.CODE=M.ACTIVITY_CODE)
           left outer join FIN_APP.TPA_CLAIMS_PAYMENT z on (b.claim_seq_id=z.CLAIM_SEQ_ID and z.policy_seq_id=a.policy_seq_id)
           left outer join FIN_APP.TPA_PAYMENT_CHECKS_DETAILS n on (n.PAYMENT_SEQ_ID=z.PAYMENT_SEQ_ID)
          left outer  join FIN_APP.tpa_claims_check f on (n.CLAIMS_CHK_SEQ_ID=f.CLAIMS_CHK_SEQ_ID)
    WHERE a.PAT_STATUS_TYPE_ID !='REJ' AND D.EMPANEL_NUMBER=str_tab(2)
    AND ( str_tab(3) IS NULL OR B.INVOICE_NUMBER=str_tab(3))
    AND ( str_tab(4) IS NULL OR a.TPA_ENROLLMENT_ID=str_tab(4) )
    AND ( str_tab(5) IS NULL OR B.CLAIM_NUMBER=str_tab(5))
    AND ( str_tab(6) IS NULL OR B.CLM_STATUS_TYPE_ID=str_tab(6))
    AND 
  (str_tab(7) is null or trunc(b.CLM_RECEIVED_DATE) between to_date(str_tab(7),'dd/mm/yyyy') and to_date(str_tab(8),'dd/mm/yyyy')+1)
  AND (str_tab(9) IS NULL OR  B.MEM_NAME=str_tab(9))
  AND (str_tab(10) IS NULL OR  A.EVENT_NO=str_tab(10))
  AND 
  (str_tab(11) is null or  trunc(b.date_of_hospitalization) between to_date(str_tab(11),'dd/mm/yyyy') and to_date(str_tab(12),'dd/mm/yyyy')+1)
  AND (str_tab(13) IS NULL OR  B.AUTH_NUMBER=str_tab(13))
  AND (str_tab(14) IS NULL OR  A.PRE_AUTH_NUMBER=str_tab(14))
  AND --(str_tab(15) IS NULL OR  
  A.claim_seq_id is  null--)
  and a.pbm_yn='Y'
  AND  A.PAT_STATUS_TYPE_ID!='INP'
 order by  A.PRE_AUTH_NUMBER ; ---addded by lalatendu;
  END IF;
   IF str_tab(1) = 'drugSubmissionId' OR str_tab(1) = 'drugPaymentId'   THEN
  --IF str_tab(15) = 'PD' THEN

     OPEN v_result_set FOR
select B.TPA_ENROLLMENT_ID AS ALKOOT_ID
    ,a.PRE_AUTH_NUMBER AS PRE_APPROVAL_NUMBER
    ,a.AUTH_NUMBER AS AUTHORIZATION_NUMBER,
    /*B.REQUESTED_AMOUNT AS REQUESTED_AMOUNT*/
    --C.GROSS_AMOUNT AS REQUESTED_AMOUNT
    c.provider_net_amount REQUESTED_AMOUNT,
    B.CLAIM_NUMBER AS CLAIM_NUMBER,
    B.MEM_NAME AS PATIENT_NAME,
    case when b.completed_yn='Y' and b.CLM_STATUS_TYPE_ID ='APR' then 'Approved'
                  when b.completed_yn='Y' and b.CLM_STATUS_TYPE_ID ='REJ' then 'Rejected'
                  when b.CLM_STATUS_TYPE_ID='REQ' THEN 'Shortfall'
                  When b.CLM_STATUS_TYPE_ID='INP' then 'In Progress' end   AS status,
     case when b.claim_seq_id is not null then 'PA Apprvd and Dispensed'--v_clm_pay_status
                  when b.claim_seq_id is  null then 'PA Apprvd not Dispensed'
                    end  AS DISPENSE_STATUS,
    B.INVOICE_NUMBER AS INVOICE_NUMBER,
    --NULL AS EVENT_REFERENCE_NUMBER,
    --C.PATIENT_SHARE_AMOUNT,
    C.DISALLOWED_AMOUNT AS DISALLOWED_AMOUNT,
    C.DISCOUNT_AMOUNT AS DISCOUNT_AMOUNT,
    F.CHECK_NUM AS PAYMENT_REFRENCE_NUMBER,
    case when c.CODE!='PHARMA' THEN 
                case when c.INTERNAL_CODE is not null then nvl(tamd.ACTIVITY_DESCRIPTION,m.ACTIVITY_DESCRIPTION)
                     when  c.INTERNAL_CODE is null and c.moph_Codes is not null then mm.ACTIVITY_DESCRIPTION
                     when  c.INTERNAL_CODE is null and c.INTERNAL_CODE is null then c.INTERNAL_DESC
                     end
    when c.CODE='PHARMA' then c.INTERNAL_DESC END  AS DRUG_DESCRIPTION,
    C.QUANTITY AS QUANTITY,
    C.DENIAL_DESC AS DENIAL_REASON,
   -- NULL AS STATUS_DISPENSE,
    case when b.completed_yn='Y' and b.CLM_STATUS_TYPE_ID ='APR' then  C.APPROVED_AMOUNT
                  when b.completed_yn='Y' and b.CLM_STATUS_TYPE_ID ='REJ' then C.APPROVED_AMOUNT
                  when b.completed_yn='Y' and b.CLM_STATUS_TYPE_ID not in ('REJ','APR') then null end as APPROVED_AMOUNT,
    --C.APPROVED_AMOUNT,
    TO_CHAR(B.DATE_OF_HOSPITALIZATION,'DD/MM/YYYY') AS PRESCRIPTION_DATE,
    TO_CHAR(B.CLM_RECEIVED_DATE,'DD/MM/YYYY') AS DISPENSED_DATE,
    c.PATIENT_SHARE_AMOUNT,
    case when b.claim_type='CTM' THEN 0 
                   when b.claim_type ='CNH' THEN c.disc_gross_amount END AS AGREED_AMOUNT,
    B.EVENT_NO AS EVENT_REFERENCE_NUMBER,
    CD.BATCH_NO
 FROM    APP.PAT_ACTIVITY_DETAILS c  LEFT OUTER JOIN
                 CLM_authorization_details b ON (C.CLAIM_SEQ_ID=b.claim_seq_id)
                 LEFT OUTER JOIN APP.CLM_BATCH_UPLOAD_DETAILS CD ON(CD.CLM_BATCH_SEQ_ID=B.CLM_BATCH_SEQ_ID)
                  LEFT OUTER JOIN  pat_authorization_details a on (b.PAT_AUTH_SEQ_ID=a.PAT_AUTH_SEQ_ID)
                  LEFT OUTER JOIN CLM_HOSPITAL_DETAILS CHD ON(CHD.CLAIM_SEQ_ID=b.CLAIM_SEQ_ID)
                  LEFT OUTER JOIN  tpa_hosp_info d on(CHD.hosp_seq_id=d.hosp_seq_id) 
                  --left outer join diagnosys_details dd on (dd.claim_seq_id=cad.claim_seq_id)
        --left outer join tpa_icd10_master_details tic on (CAD.BENIFIT_TYPE=tic.BENEFIT_TYPE)
        left outer join TPA_PHARMACY_MASTER_DETAILS M on (C.CODE=M.ACTIVITY_CODE)
          left outer join FIN_APP.TPA_CLAIMS_PAYMENT z on (b.claim_seq_id=z.CLAIM_SEQ_ID and z.policy_seq_id=B.policy_seq_id)
           left outer join FIN_APP.TPA_PAYMENT_CHECKS_DETAILS n on (n.PAYMENT_SEQ_ID=z.PAYMENT_SEQ_ID)
          left outer  join FIN_APP.tpa_claims_check f on (n.CLAIMS_CHK_SEQ_ID=f.CLAIMS_CHK_SEQ_ID)
          left outer join TPA_PHARMACY_MASTER_DETAILS mm on(c.moph_codes=mm.moph_codes)
          left outer join tpa_activity_master_details tamd on(c.code=tamd.activity_code)
    WHERE D.EMPANEL_NUMBER=str_tab(2)
    AND ( str_tab(3) IS NULL OR B.INVOICE_NUMBER=str_tab(3))
    AND ( str_tab(4) IS NULL OR B.TPA_ENROLLMENT_ID=str_tab(4) )
    AND ( str_tab(5) IS NULL OR B.CLAIM_NUMBER=str_tab(5))
    AND ( str_tab(6) IS NULL OR B.CLM_STATUS_TYPE_ID=str_tab(6))
    AND 
  (str_tab(7) is null or trunc(b.CLM_RECEIVED_DATE) between to_date(str_tab(7),'dd/mm/yyyy') and to_date(str_tab(8),'dd/mm/yyyy')+1)
  AND (str_tab(9) IS NULL OR  B.MEM_NAME=str_tab(9))
  AND (str_tab(10) IS NULL OR  B.EVENT_NO=str_tab(10))
  AND 
  (str_tab(11) is null or  trunc(b.date_of_hospitalization) between to_date(str_tab(11),'dd/mm/yyyy') and to_date(str_tab(12),'dd/mm/yyyy')+1)
  AND (str_tab(13) IS NULL OR  B.AUTH_NUMBER=str_tab(13))
  AND (str_tab(14) IS NULL OR  A.PRE_AUTH_NUMBER=str_tab(14))
  AND --(str_tab(15) IS NULL OR  
  c.claim_seq_id is not null--)
  AND (str_tab(16) IS NULL OR CD.BATCH_NO = str_tab(16))
  AND (str_tab(17) IS NULL OR F.CHECK_NUM = str_tab(17))
  and (a.pbm_yn='Y' OR CD.SOURCE_TYPE_ID='PBCL')
  order by  B.CLAIM_NUMBER ; ---addded by lalatendu;

  end if;
  
ELSE 
IF str_tab(15) = 'PD' THEN
OPEN v_result_set FOR
  select a.TPA_ENROLLMENT_ID AS ALKOOT_ID
    ,a.PRE_AUTH_NUMBER AS PRE_APPROVAL_NUMBER
    ,a.AUTH_NUMBER AS AUTHORIZATION_NUMBER,
    B.REQUESTED_AMOUNT AS REQUESTED_AMOUNT
    ,B.CLAIM_NUMBER AS CLAIM_NUMBER,
    A.MEM_NAME AS PATIENT_NAME,
    case when b.completed_yn='Y' and b.CLM_STATUS_TYPE_ID ='APR' then 'Approved'
                  when b.completed_yn='Y' and b.CLM_STATUS_TYPE_ID ='REJ' then 'Rejected'
                  when b.CLM_STATUS_TYPE_ID='REQ' THEN 'Shortfall'
                  When b.CLM_STATUS_TYPE_ID='INP' then 'In Progress' end   AS status,
     case when b.claim_seq_id is not null then 'PA Apprvd and Dispensed'--v_clm_pay_status
                  when b.claim_seq_id is  null then 'PA Apprvd not Dispensed'
                    end  AS DISPENSE_STATUS,
    B.INVOICE_NUMBER AS INVOICE_NUMBER,
    --NULL AS EVENT_REFERENCE_NUMBER,
    --C.PATIENT_SHARE_AMOUNT,
    case when (nvl(b.ucr_flag,'N')='N' and nvl(b.ri_copar_flag,'N')='N') then
             case when nvl(b.completed_yn,'N')='Y'then 
                     CASE WHEN SIGN ((b.tot_disc_gross_amount-nvl(b.tot_patient_share_amount,0))-nvl(b.final_app_amount,0)) = -1 THEN 0
                          ELSE (b.tot_disc_gross_amount-nvl(b.tot_patient_share_amount,0))-nvl(b.final_app_amount,0) END
                  else CASE WHEN SIGN((b.tot_disc_gross_amount-nvl(b.tot_patient_share_amount,0))-nvl(b.tot_approved_amount,0)) = -1 THEN 0
                            ELSE (b.tot_disc_gross_amount-nvl(b.tot_patient_share_amount,0))-nvl(b.tot_approved_amount,0) END
                  end end AS DISALLOWED_AMOUNT,
   B.TOT_DISCOUNT_AMOUNT  AS DISCOUNT_AMOUNT,
    NULL AS PAYMENT_REFRENCE_NUMBER,
    null as DRUG_DESCRIPTION,
   -- tic.short_desc AS DRUG_DESCRIPTION,
    NULL AS QUANTITY,
   NULL AS DENIAL_REASON,
   -- NULL AS STATUS_DISPENSE,
   case when b.completed_yn='Y' and b.CLM_STATUS_TYPE_ID ='APR' then  B.TOT_APPROVED_AMOUNT
                  when b.completed_yn='Y' and b.CLM_STATUS_TYPE_ID ='REJ' then B.TOT_APPROVED_AMOUNT
                  when b.completed_yn='Y' and b.CLM_STATUS_TYPE_ID not in ('REJ','APR') then null end as APPROVED_AMOUNT,
                  --B.TOT_APPROVED_AMOUNT as APPROVED_AMOUNT,
    TO_CHAR(A.HOSPITALIZATION_DATE,'DD/MM/YYYY') AS PRESCRIPTION_DATE,
    TO_CHAR(B.CLM_RECEIVED_DATE,'DD/MM/YYYY') AS DISPENSED_DATE,
    B.TOT_PATIENT_SHARE_AMOUNT as PATIENT_SHARE_AMOUNT,
    B.TOT_DISC_GROSS_AMOUNT AS AGREED_AMOUNT,
   
    A.EVENT_NO AS EVENT_REFERENCE_NUMBER,
    CD.BATCH_NO
     from APP.PAT_AUTHORIZATION_DETAILS a 
  right outer  JOIN APP.CLM_AUTHORIZATION_DETAILS B ON(a.pat_auth_seq_id=B.pat_auth_seq_id)
  join app.clm_batch_upload_details cd ON(B.CLM_BATCH_SEQ_ID=CD.CLM_BATCH_SEQ_ID)
   --left outer JOIN APP.PAT_ACTIVITY_DETAILS C ON (B.PAT_AUTH_SEQ_ID=C.PAT_AUTH_SEQ_ID)
   left outer JOIN  TPA_HOSP_INFO D ON (A.HOSP_SEQ_ID=D.HOSP_SEQ_ID)
   LEFT OUTER JOIN tpa_claims_payment E ON (B.CLAIM_SEQ_ID=E.CLAIM_SEQ_ID)
  /*  left outer join diagnosys_details dd on (dd.claim_seq_id=b.claim_seq_id)
        left outer join tpa_icd10_master_details tic on (dd.diagnosys_code=tic.icd_code)*/
    WHERE D.EMPANEL_NUMBER=str_tab(2)
    AND ( str_tab(3) IS NULL OR B.INVOICE_NUMBER=str_tab(3))
    AND ( str_tab(4) IS NULL OR a.TPA_ENROLLMENT_ID=str_tab(4) )
    AND ( str_tab(5) IS NULL OR B.CLAIM_NUMBER=str_tab(5))
    AND ( str_tab(6) IS NULL OR B.CLM_STATUS_TYPE_ID=str_tab(6))
    AND 
  (str_tab(7) is null or b.CLM_RECEIVED_DATE >= to_date(str_tab(7),'dd/mm/yyyy') and b.CLM_RECEIVED_DATE <= to_date(str_tab(8),'dd/mm/yyyy')+1)
  AND (str_tab(9) IS NULL OR  B.MEM_NAME=str_tab(9))
  AND (str_tab(10) IS NULL OR  A.EVENT_NO=str_tab(10))
  AND 
  (str_tab(11) is null or  a.hospitalization_date >= to_date(str_tab(11),'dd/mm/yyyy') and a.hospitalization_date <= to_date(str_tab(12),'dd/mm/yyyy')+1)
  AND (str_tab(13) IS NULL OR  a.AUTH_NUMBER=str_tab(13))
  AND (str_tab(14) IS NULL OR  A.PRE_AUTH_NUMBER=str_tab(14))
  AND --(str_tab(15) IS NULL OR  E.CLAIM_PAYMENT_STATUS=str_tab(15))
  b.claim_seq_id is not  null
  and a.pbm_yn='Y' and b.claim_number is not null 
  order by  A.PRE_AUTH_NUMBER ; ---addded by lalatendu;
  else
  OPEN v_result_set FOR
  select a.TPA_ENROLLMENT_ID AS ALKOOT_ID
    ,a.PRE_AUTH_NUMBER AS PRE_APPROVAL_NUMBER
    ,a.AUTH_NUMBER AS AUTHORIZATION_NUMBER,
    B.REQUESTED_AMOUNT AS REQUESTED_AMOUNT
    ,B.CLAIM_NUMBER AS CLAIM_NUMBER,
    A.MEM_NAME AS PATIENT_NAME,
    case when b.completed_yn='Y' and b.CLM_STATUS_TYPE_ID ='APR' then 'Approved'
                  when b.completed_yn='Y' and b.CLM_STATUS_TYPE_ID ='REJ' then 'Rejected'
                  when b.CLM_STATUS_TYPE_ID='REQ' THEN 'Shortfall'
                  When b.CLM_STATUS_TYPE_ID='INP' then 'In Progress' end   AS status,
     case when b.claim_seq_id is not null then 'PA Apprvd and Dispensed'--v_clm_pay_status
                  when b.claim_seq_id is  null then 'PA Apprvd not Dispensed'
                    end  AS DISPENSE_STATUS,
    B.INVOICE_NUMBER AS INVOICE_NUMBER,
    --NULL AS EVENT_REFERENCE_NUMBER,
    --C.PATIENT_SHARE_AMOUNT,
    case when (nvl(b.ucr_flag,'N')='N' and nvl(b.ri_copar_flag,'N')='N') then
             case when nvl(b.completed_yn,'N')='Y'then 
                     CASE WHEN SIGN ((b.tot_disc_gross_amount-nvl(b.tot_patient_share_amount,0))-nvl(b.final_app_amount,0)) = -1 THEN 0
                          ELSE (b.tot_disc_gross_amount-nvl(b.tot_patient_share_amount,0))-nvl(b.final_app_amount,0) END
                  else CASE WHEN SIGN((b.tot_disc_gross_amount-nvl(b.tot_patient_share_amount,0))-nvl(b.tot_approved_amount,0)) = -1 THEN 0
                            ELSE (b.tot_disc_gross_amount-nvl(b.tot_patient_share_amount,0))-nvl(b.tot_approved_amount,0) END
                  end end AS DISALLOWED_AMOUNT,
   B.TOT_DISCOUNT_AMOUNT  AS DISCOUNT_AMOUNT,
    NULL AS PAYMENT_REFRENCE_NUMBER,
    null as DRUG_DESCRIPTION,
   -- tic.short_desc AS DRUG_DESCRIPTION,
    NULL AS QUANTITY,
   NULL AS DENIAL_REASON,
   -- NULL AS STATUS_DISPENSE,
   case when b.completed_yn='Y' and b.CLM_STATUS_TYPE_ID ='APR' then  B.TOT_APPROVED_AMOUNT
                  when b.completed_yn='Y' and b.CLM_STATUS_TYPE_ID ='REJ' then B.TOT_APPROVED_AMOUNT
                  when b.completed_yn='Y' and b.CLM_STATUS_TYPE_ID not in ('REJ','APR') then null end as APPROVED_AMOUNT,
                  --B.TOT_APPROVED_AMOUNT as APPROVED_AMOUNT,
    TO_CHAR(A.HOSPITALIZATION_DATE,'DD/MM/YYYY') AS PRESCRIPTION_DATE,
    TO_CHAR(B.CLM_RECEIVED_DATE,'DD/MM/YYYY') AS DISPENSED_DATE,
    B.TOT_PATIENT_SHARE_AMOUNT as PATIENT_SHARE_AMOUNT,
    B.TOT_DISC_GROSS_AMOUNT AS AGREED_AMOUNT,
   
    A.EVENT_NO AS EVENT_REFERENCE_NUMBER,
    CD.BATCH_NO
     from APP.PAT_AUTHORIZATION_DETAILS a 
  right outer  JOIN APP.CLM_AUTHORIZATION_DETAILS B ON(a.pat_auth_seq_id=B.pat_auth_seq_id)
   join app.clm_batch_upload_details cd ON(B.CLM_BATCH_SEQ_ID=CD.CLM_BATCH_SEQ_ID)
   --left outer JOIN APP.PAT_ACTIVITY_DETAILS C ON (B.PAT_AUTH_SEQ_ID=C.PAT_AUTH_SEQ_ID)
   left outer JOIN  TPA_HOSP_INFO D ON (A.HOSP_SEQ_ID=D.HOSP_SEQ_ID)
   LEFT OUTER JOIN tpa_claims_payment E ON (B.CLAIM_SEQ_ID=E.CLAIM_SEQ_ID)
  /*  left outer join diagnosys_details dd on (dd.claim_seq_id=b.claim_seq_id)
        left outer join tpa_icd10_master_details tic on (dd.diagnosys_code=tic.icd_code)*/
    WHERE a.PAT_STATUS_TYPE_ID !='REJ' AND D.EMPANEL_NUMBER=str_tab(2)
    AND ( str_tab(3) IS NULL OR B.INVOICE_NUMBER=str_tab(3))
    AND ( str_tab(4) IS NULL OR a.TPA_ENROLLMENT_ID=str_tab(4) )
    AND ( str_tab(5) IS NULL OR B.CLAIM_NUMBER=str_tab(5))
    AND ( str_tab(6) IS NULL OR B.CLM_STATUS_TYPE_ID=str_tab(6))
    AND 
  (str_tab(7) is null or b.CLM_RECEIVED_DATE >= to_date(str_tab(7),'dd/mm/yyyy') and b.CLM_RECEIVED_DATE <= to_date(str_tab(8),'dd/mm/yyyy')+1)
  AND (str_tab(9) IS NULL OR  B.MEM_NAME=str_tab(9))
  AND (str_tab(10) IS NULL OR  A.EVENT_NO=str_tab(10))
  AND 
  (str_tab(11) is null or  a.hospitalization_date >= to_date(str_tab(11),'dd/mm/yyyy') and a.hospitalization_date <= to_date(str_tab(12),'dd/mm/yyyy')+1)
  AND (str_tab(13) IS NULL OR  a.AUTH_NUMBER=str_tab(13))
  AND (str_tab(14) IS NULL OR  A.PRE_AUTH_NUMBER=str_tab(14))
  AND --(str_tab(15) IS NULL OR  
  b.claim_seq_id is  null--)
  and a.pbm_yn='Y' 
   AND  A.PAT_STATUS_TYPE_ID!='INP'
   order by  A.PRE_AUTH_NUMBER ; ---addded by lalatendu  ;
  end if;
    IF str_tab(1) = 'clmPaymentId' OR str_tab(1) = 'clmSubmissionId' then 
   OPEN v_result_set FOR
  select B.TPA_ENROLLMENT_ID AS ALKOOT_ID
    ,a.PRE_AUTH_NUMBER AS PRE_APPROVAL_NUMBER
    ,a.AUTH_NUMBER AS AUTHORIZATION_NUMBER,
    B.REQUESTED_AMOUNT AS REQUESTED_AMOUNT
    ,B.CLAIM_NUMBER AS CLAIM_NUMBER,
    B.MEM_NAME AS PATIENT_NAME,
    case when b.completed_yn='Y' and b.CLM_STATUS_TYPE_ID ='APR' then 'Approved'
                  when b.completed_yn='Y' and b.CLM_STATUS_TYPE_ID ='REJ' then 'Rejected'
                  when b.CLM_STATUS_TYPE_ID='REQ' THEN 'Shortfall'
                  When b.CLM_STATUS_TYPE_ID='INP' then 'In Progress' end   AS status,
     case when b.claim_seq_id is not null then 'PA Apprvd and Dispensed'--v_clm_pay_status
                  when b.claim_seq_id is  null then 'PA Apprvd not Dispensed'
                    end  AS DISPENSE_STATUS,
    B.INVOICE_NUMBER AS INVOICE_NUMBER,
    --NULL AS EVENT_REFERENCE_NUMBER,
    --C.PATIENT_SHARE_AMOUNT,
    case when (nvl(b.ucr_flag,'N')='N' and nvl(b.ri_copar_flag,'N')='N') then
             case when nvl(b.completed_yn,'N')='Y'then 
                     CASE WHEN SIGN ((b.tot_disc_gross_amount-nvl(b.tot_patient_share_amount,0))-nvl(b.final_app_amount,0)) = -1 THEN 0
                          ELSE (b.tot_disc_gross_amount-nvl(b.tot_patient_share_amount,0))-nvl(b.final_app_amount,0) END
                  else CASE WHEN SIGN((b.tot_disc_gross_amount-nvl(b.tot_patient_share_amount,0))-nvl(b.tot_approved_amount,0)) = -1 THEN 0
                            ELSE (b.tot_disc_gross_amount-nvl(b.tot_patient_share_amount,0))-nvl(b.tot_approved_amount,0) END
                  end end AS DISALLOWED_AMOUNT,
   B.TOT_DISCOUNT_AMOUNT  AS DISCOUNT_AMOUNT,
    F.CHECK_NUM AS PAYMENT_REFRENCE_NUMBER,
    null as DRUG_DESCRIPTION,
   -- tic.short_desc AS DRUG_DESCRIPTION,
    NULL AS QUANTITY,
   NULL AS DENIAL_REASON,
   -- NULL AS STATUS_DISPENSE,
   case when b.completed_yn='Y' and b.CLM_STATUS_TYPE_ID ='APR' then  B.TOT_APPROVED_AMOUNT
                  when b.completed_yn='Y' and b.CLM_STATUS_TYPE_ID ='REJ' then B.TOT_APPROVED_AMOUNT
                  when b.completed_yn='Y' and b.CLM_STATUS_TYPE_ID not in ('REJ','APR') then null end as APPROVED_AMOUNT,
                  --B.TOT_APPROVED_AMOUNT as APPROVED_AMOUNT,
    TO_CHAR(B.DATE_OF_HOSPITALIZATION,'DD/MM/YYYY') AS PRESCRIPTION_DATE,
    TO_CHAR(B.CLM_RECEIVED_DATE,'DD/MM/YYYY') AS DISPENSED_DATE,
    B.TOT_PATIENT_SHARE_AMOUNT as PATIENT_SHARE_AMOUNT,
    B.TOT_DISC_GROSS_AMOUNT AS AGREED_AMOUNT,
   
    B.EVENT_NO AS EVENT_REFERENCE_NUMBER,
    CD.BATCH_NO,
    Z.CLAIM_PAYMENT_STATUS
     from APP.PAT_AUTHORIZATION_DETAILS a 
  right outer  JOIN APP.CLM_AUTHORIZATION_DETAILS B ON(a.pat_auth_seq_id=B.pat_auth_seq_id)
  join app.clm_batch_upload_details cd ON(B.CLM_BATCH_SEQ_ID=CD.CLM_BATCH_SEQ_ID)
  LEFT OUTER JOIN APP.CLM_HOSPITAL_DETAILS CHD ON(B.CLAIM_SEQ_ID=CHD.CLAIM_SEQ_ID)
   --left outer JOIN APP.PAT_ACTIVITY_DETAILS C ON (B.PAT_AUTH_SEQ_ID=C.PAT_AUTH_SEQ_ID)
   left outer JOIN  TPA_HOSP_INFO D ON (CHD.HOSP_SEQ_ID=D.HOSP_SEQ_ID)
   --LEFT OUTER JOIN tpa_claims_payment E ON (B.CLAIM_SEQ_ID=E.CLAIM_SEQ_ID)
    left outer join FIN_APP.TPA_CLAIMS_PAYMENT z on (B.claim_seq_id=z.CLAIM_SEQ_ID and z.policy_seq_id=B.policy_seq_id)
           left outer join FIN_APP.TPA_PAYMENT_CHECKS_DETAILS n on (n.PAYMENT_SEQ_ID=z.PAYMENT_SEQ_ID)
          left outer  join FIN_APP.tpa_claims_check f on (n.CLAIMS_CHK_SEQ_ID=f.CLAIMS_CHK_SEQ_ID)
  /*  left outer join diagnosys_details dd on (dd.claim_seq_id=b.claim_seq_id)
        left outer join tpa_icd10_master_details tic on (dd.diagnosys_code=tic.icd_code)*/
    WHERE D.EMPANEL_NUMBER=str_tab(2)
    AND ( str_tab(3) IS NULL OR B.INVOICE_NUMBER=str_tab(3))
    AND ( str_tab(4) IS NULL OR B.TPA_ENROLLMENT_ID=str_tab(4) )
    AND ( str_tab(5) IS NULL OR B.CLAIM_NUMBER=str_tab(5))
    AND ( str_tab(6) IS NULL OR B.CLM_STATUS_TYPE_ID=str_tab(6))
    AND 
  (str_tab(7) is null or b.CLM_RECEIVED_DATE >= to_date(str_tab(7),'dd/mm/yyyy') and b.CLM_RECEIVED_DATE <= to_date(str_tab(8),'dd/mm/yyyy')+1)
  AND (str_tab(9) IS NULL OR  B.MEM_NAME=str_tab(9))
  AND (str_tab(10) IS NULL OR  B.EVENT_NO=str_tab(10))
  AND 
  (str_tab(11) is null or  B.DATE_OF_HOSPITALIZATION >= to_date(str_tab(11),'dd/mm/yyyy') and B.DATE_OF_HOSPITALIZATION <= to_date(str_tab(12),'dd/mm/yyyy')+1)
  AND (str_tab(13) IS NULL OR  a.AUTH_NUMBER=str_tab(13))
  AND (str_tab(14) IS NULL OR  A.PRE_AUTH_NUMBER=str_tab(14))
  AND --(str_tab(15) IS NULL OR  
  b.claim_seq_id is not  null--)
  AND (str_tab(16) IS NULL OR CD.BATCH_NO=str_tab(16))
  AND (str_tab(17) IS NULL OR F.CHECK_NUM=str_tab(17))
  AND (str_tab(18) IS NULL OR z.CLAIM_PAYMENT_STATUS=str_tab(18))
  and (a.pbm_yn='Y' OR CD.SOURCE_TYPE_ID='PBCL') 
  order by  B.CLAIM_NUMBER ; ---addded by lalatendu;
  end if;
END IF;
    



END PBM_CLM_DRUG_RPT;
--========================================================================================================================
procedure pbm_clm_status(v_pat_auth_seq_id            IN  pat_authorization_details.pat_auth_seq_id%type,
                          v_num                       out  varchar2)
is
 cursor pbm_clm_cur is
						 select c.claim_seq_id from clm_authorization_details c
						 where c.pat_auth_seq_id = v_pat_auth_seq_id;
						 
						 pbm_clm_rec pbm_clm_cur%rowtype;
             
             
             begin
              v_num:='N';
                open pbm_clm_cur;
  fetch pbm_clm_cur into pbm_clm_rec;
  close pbm_clm_cur;
    IF   pbm_clm_rec.claim_seq_id is not null THEN
     v_num:='Y';

  END IF;
  
  end pbm_clm_status;
  --==================================================================================================
  PROCEDURE select_claim_rpt_list(
  --V_HOSP_SEQ_ID                         IN  pat_authorization_details.hosp_seq_id%type,
  v_fromdate							              IN   VARCHAR2 ,
  v_toDate							                IN	 VARCHAR2 ,
  v_fromdate1							              IN   VARCHAR2 ,
  v_toDate1							                IN	 VARCHAR2 ,
	v_patientName						              IN  clm_authorization_details.mem_name%type,
	v_status							                IN	tpa_general_code.description%type,
	v_invoice_number									    IN  clm_authorization_details.invoice_number%type,
	v_claim_number										    IN  clm_authorization_details.claim_number%type,
	v_memberId											      IN  clm_authorization_details.tpa_enrollment_id%type,
	v_ref_no											        IN  clm_authorization_details.EVENT_NO%type,
	v_auth_number                         IN  clm_authorization_details.auth_number%type,
	v_clm_pay_status									    IN VARCHAR2,
	v_pre_auth_number                     IN  pat_authorization_details.pre_auth_number%type ,
 ----------
  v_batch_no                            IN  clm_batch_upload_details.batch_no%type default null,
  v_clm_payment_status                  IN  TPA_CLAIMS_PAYMENT.CLAIM_PAYMENT_STATUS%type default null,
  v_pay_ref_num                         IN  FIN_APP.tpa_claims_check.CHECK_NUM%type default null,
  ----------
	v_sort_var                            IN  VARCHAR2,  
  v_sort_order                          IN  VARCHAR2 ,
  v_start_num                           IN  NUMBER ,
  v_end_num                             IN  NUMBER ,
  V_HOSP_SEQ_ID                         IN  pat_authorization_details.hosp_seq_id%type,
  v_rpt_id                              IN  VARCHAR2,
  --v_added_by                            IN  NUMBER,
  result_set                            OUT SYS_REFCURSOR
  )
  IS
	v_sql_str                            VARCHAR2(10000) ;
	TYPE bind_tab_type IS TABLE OF VARCHAR2(250) INDEX BY BINARY_INTEGER ;
    bind_tab                             bind_tab_type;
    i                                    NUMBER(2) := 0;
    v_where                              VARCHAR2(2000);
    v_stat                               VARCHAR2(20):=null;
  
    v_fdate   clm_authorization_details.date_of_hospitalization%type:=to_date(v_fromdate,'dd/mm/yyyy');
    v_to_date clm_authorization_details.date_of_discharge%type  :=to_date(v_toDate,'dd/mm/yyyy')+1;
	v_fdate1   clm_authorization_details.CLM_RECEIVED_DATE%type:=to_date(v_fromdate1,'dd/mm/yyyy');
    v_to_date1 clm_authorization_details.CLM_RECEIVED_DATE%type  :=to_date(v_toDate1,'dd/mm/yyyy')+1;
--  l_sort_var VARCHAR2(30);
--   v_seq_id  VARCHAR2(30);
    
    
  BEGIN
  IF v_rpt_id = 'drugSubmissionId' OR v_rpt_id = 'drugPaymentId' OR v_rpt_id = 'drugDispenseId' THEN
  v_sql_str :='SELECT  cad.CLAIM_NUMBER AS CLAIM_NUMBER,
                       CAD.tpa_enrollment_id as tpa_enrollment_id ,
                       CAD.mem_name as MEM_NAME,
                      pad.pre_auth_number as pre_auth_number,
                      cad.INVOICE_NUMBER AS INVOICE_NUMBER,
                      pad.pat_auth_seq_id as pre_auth_seq_id,
                      case when cad.completed_yn=''Y'' and cad.CLM_STATUS_TYPE_ID =''APR'' then ''Approved''
                  when cad.completed_yn=''Y'' and cad.CLM_STATUS_TYPE_ID =''REJ'' then ''Rejected''
                  when cad.CLM_STATUS_TYPE_ID=''REQ'' THEN ''Shortfall''
                  When cad.CLM_STATUS_TYPE_ID=''INP'' then ''In Progress'' end   as status ,
                  to_char(CAD.DATE_OF_HOSPITALIZATION,''dd/mm/yyyy'')  as PRESCRIPTION_DATE ,
                  case when c.CODE!=''PHARMA'' THEN 
                                    case when c.INTERNAL_CODE is not null then nvl(tamd.ACTIVITY_DESCRIPTION,m.ACTIVITY_DESCRIPTION)
                                                                    when  c.INTERNAL_CODE is null and c.moph_Codes is not null then mm.ACTIVITY_DESCRIPTION
                                                                    when  c.INTERNAL_CODE is null and c.INTERNAL_CODE is null then c.INTERNAL_DESC
                                                                    end
                                 when c.CODE=''PHARMA'' then c.INTERNAL_DESC END  AS DRUG_DESCRIPTION,
                  C.QUANTITY AS QUANTITY,
                  pad.auth_number,
                  /*cad.REQUESTED_AMOUNT AS REQUESTED_AMOUNT*/
                  --C.GROSS_AMOUNT AS REQUESTED_AMOUNT,
                  C.PROVIDER_NET_AMOUNT AS REQUESTED_AMOUNT,---pbm_claim_bulk_upload
                   case when cad.claim_seq_id is not null then ''PA Apprvd and Dispensed''--v_clm_pay_status
                  when cad.claim_seq_id is  null then ''PA Apprvd not Dispensed''
                    end as Dispensed_status,
                   CAD.event_no AS EVENT_REFERENCE_NUMBER,
                    C.DENIAL_DESC AS DENIAL_REASON,
                  cad.emirate_id as quatar_id ,
                  thi.hosp_name as  clinician_name ,
                   case when CAD.completed_yn=''Y'' and CAD.CLM_STATUS_TYPE_ID =''APR'' then  C.APPROVED_AMOUNT
                  when CAD.completed_yn=''Y'' and CAD.CLM_STATUS_TYPE_ID =''REJ'' then C.APPROVED_AMOUNT
                  when CAD.completed_yn=''Y'' and CAD.CLM_STATUS_TYPE_ID not in (''REJ'',''APR'') then null end as APPROVED_AMOUNT,
                  -- C.APPROVED_AMOUNT,
                  --C.DISALLOWED_AMOUNT AS DISALLOWED_AMOUNT,
                  (c.DISC_GROSS_AMOUNT- nvl(c.PATIENT_SHARE_AMOUNT,0)-c.ALLOWED_AMOUNT) as DISALLOWED_AMOUNT, 
                  C.DISCOUNT_AMOUNT AS DISCOUNT_AMOUNT,
                  F.CHECK_NUM AS PAYMENT_REFRENCE_NUMBER,
                  to_char(cad.CLM_RECEIVED_DATE,''dd/mm/yyyy'') AS DISPENSED_DATE,
--                  CAD.TOT_PATIENT_SHARE_AMOUNT as PATIENT_SHARE_AMOUNT,
--                   cad.TOT_DISC_GROSS_AMOUNT AS AGRD_AMT
                   c.PATIENT_SHARE_AMOUNT,
                   case when cad.claim_type=''CTM'' THEN 0 
                   when cad.claim_type =''CNH'' THEN c.disc_gross_amount END AS  AGRD_AMT,
                     nvl(z.CLAIM_PAYMENT_STATUS,''NA'') as CLAIM_PAYMENT_STATUS,
                     bat.BATCH_NO as batch_number-------
                   FROM    APP.PAT_ACTIVITY_DETAILS c  LEFT OUTER JOIN
                 CLM_authorization_details CAD ON (C.CLAIM_SEQ_ID=CAD.claim_seq_id)
                  LEFT OUTER JOIN  pat_authorization_details pad on (C.PAT_AUTH_SEQ_ID=pad.PAT_AUTH_SEQ_ID OR CAD.PAT_AUTH_SEQ_ID=PAD.PAT_AUTH_SEQ_ID)
                  LEFT OUTER JOIN CLM_HOSPITAL_DETAILS THD ON(CAD.CLAIM_SEQ_ID=THD.CLAIM_SEQ_ID)
                  LEFT OUTER JOIN  tpa_hosp_info thi on(THD.hosp_seq_id=thi.hosp_seq_id) 
                  --left outer join diagnosys_details dd on (dd.claim_seq_id=cad.claim_seq_id)
        --left outer join tpa_icd10_master_details tic on (CAD.BENIFIT_TYPE=tic.BENEFIT_TYPE)
        left outer join TPA_PHARMACY_MASTER_DETAILS M on (C.CODE=M.ACTIVITY_CODE)
          left outer join FIN_APP.TPA_CLAIMS_PAYMENT z on (cad.claim_seq_id=z.CLAIM_SEQ_ID and z.policy_seq_id=CAD.policy_seq_id)
           left outer join FIN_APP.TPA_PAYMENT_CHECKS_DETAILS n on (n.PAYMENT_SEQ_ID=z.PAYMENT_SEQ_ID)
          left outer  join FIN_APP.tpa_claims_check f on (n.CLAIMS_CHK_SEQ_ID=f.CLAIMS_CHK_SEQ_ID)--(dd.diagnosys_code=tic.icd_code)
           join app.clm_batch_upload_details bat on(cad.CLM_BATCH_SEQ_ID=bat.CLM_BATCH_SEQ_ID)
           left outer join TPA_PHARMACY_MASTER_DETAILS mm on(c.moph_codes=mm.moph_codes)
           left outer join tpa_activity_master_details tamd on(c.code=tamd.ACTIVITY_CODE) ';-----------
        IF v_clm_pay_status IS NOT NULL  THEN
   if v_clm_pay_status = 'PD' THEN
      -- like changed to =
    v_where := v_where||' AND cad.claim_seq_id is not null ';
   elsif v_clm_pay_status = 'PND' THEN
    v_where := v_where||' AND cad.claim_seq_id is  null and pad.pat_STATUS_TYPE_ID != ''REJ''';
   end if;
  END IF;
  
  IF v_rpt_id = 'drugSubmissionId' OR v_rpt_id = 'drugPaymentId' then 
      -- like changed to =
    v_where := v_where||' AND cad.claim_seq_id is not null ';
   
  END IF;
  
  ELSE 
        v_sql_str :=' SELECT  cad.CLAIM_NUMBER AS CLAIM_NUMBER,
                       CAD.tpa_enrollment_id as tpa_enrollment_id ,
                       CAD.mem_name as MEM_NAME,
                      pad.pre_auth_number as pre_auth_number,
                      cad.INVOICE_NUMBER AS INVOICE_NUMBER,
                      pad.pat_auth_seq_id as pre_auth_seq_id,
                      case when cad.completed_yn=''Y'' and cad.CLM_STATUS_TYPE_ID =''APR'' then ''Approved''
                  when cad.completed_yn=''Y'' and cad.CLM_STATUS_TYPE_ID =''REJ'' then ''Rejected''
                  when cad.CLM_STATUS_TYPE_ID=''REQ'' THEN ''Shortfall''
                  When cad.CLM_STATUS_TYPE_ID=''INP'' then ''In Progress'' end   as status ,
                  to_char(CAD.DATE_OF_HOSPITALIZATION,''dd/mm/yyyy'')  as PRESCRIPTION_DATE ,
                  null as DRUG_DESCRIPTION,
                  --tic.short_desc AS DRUG_DESCRIPTION,
                  --C.QUANTITY AS QUANTITY,
                  null AS QUANTITY,
                  pad.auth_number,
                  cad.REQUESTED_AMOUNT AS REQUESTED_AMOUNT,
                   case when cad.claim_seq_id is not null then ''PA Apprvd and Dispensed''--v_clm_pay_status
                  when cad.claim_seq_id is  null then ''PA Apprvd not Dispensed''
                    end as Dispensed_status,
                   CAD.event_no AS EVENT_REFERENCE_NUMBER,
                    --C.DENIAL_DESC AS DENIAL_REASON,
                    null AS DENIAL_REASON,
                  cad.emirate_id as quatar_id ,
                  thi.hosp_name as  clinician_name ,
                  case when Cad.completed_yn=''Y'' and Cad.CLM_STATUS_TYPE_ID =''APR'' then Cad.TOT_APPROVED_AMOUNT
                  when Cad.completed_yn=''Y'' and Cad.CLM_STATUS_TYPE_ID =''REJ'' then Cad.TOT_APPROVED_AMOUNT
                  when Cad.completed_yn=''Y'' and Cad.CLM_STATUS_TYPE_ID not in (''REJ'',''APR'') then null end as APPROVED_AMOUNT,
                  --B.TOT_APPROVED_AMOUNT as APPROVED_AMOUNT,
                  --Cad.TOT_APPROVED_AMOUNT as APPROVED_AMOUNT,
                  --C.DISALLOWED_AMOUNT AS DISALLOWED_AMOUNT,
                  case when (nvl(cad.ucr_flag,''N'')=''N'' and nvl(cad.ri_copar_flag,''N'')=''N'') then
             case when nvl(cad.completed_yn,''N'')=''Y''then 
                     CASE WHEN SIGN ((cad.tot_disc_gross_amount-nvl(cad.tot_patient_share_amount,0))-nvl(cad.final_app_amount,0)) = -1 THEN 0
                          ELSE (cad.tot_disc_gross_amount-nvl(cad.tot_patient_share_amount,0))-nvl(cad.final_app_amount,0) END
                  else CASE WHEN SIGN((cad.tot_disc_gross_amount-nvl(cad.tot_patient_share_amount,0))-nvl(cad.tot_approved_amount,0)) = -1 THEN 0
                            ELSE (cad.tot_disc_gross_amount-nvl(cad.tot_patient_share_amount,0))-nvl(cad.tot_approved_amount,0) END
                  end end AS DISALLOWED_AMOUNT,
                  Cad.TOT_DISCOUNT_AMOUNT AS DISCOUNT_AMOUNT,
                  F.CHECK_NUM AS PAYMENT_REFRENCE_NUMBER,
                  to_char(cad.CLM_RECEIVED_DATE,''dd/mm/yyyy'') AS DISPENSED_DATE,
                  CAD.TOT_PATIENT_SHARE_AMOUNT as PATIENT_SHARE_AMOUNT,
                   cad.TOT_DISC_GROSS_AMOUNT AS AGRD_AMT,
--                   c.PATIENT_SHARE_AMOUNT,
--                   NULL AS AGRD_AMT,
                     nvl(z.CLAIM_PAYMENT_STATUS,''NA'') as CLAIM_PAYMENT_STATUS,
                     bat.BATCH_NO as batch_number--------
                  FROM --APP.PAT_ACTIVITY_DETAILS c LEFT OUTER JOIN
                    pat_authorization_details pad  
                    right OUTER JOIN CLM_authorization_details CAD ON (PAD.PAT_AUTH_SEQ_ID=CAD.PAT_AUTH_SEQ_ID AND PAD.PAT_AUTH_SEQ_ID =CAD.PAT_AUTH_SEQ_ID  )
                  LEFT OUTER JOIN CLM_HOSPITAL_DETAILS THD ON(CAD.CLAIM_SEQ_ID=THD.CLAIM_SEQ_ID)
                  LEFT OUTER JOIN  tpa_hosp_info thi on(thd.hosp_seq_id=thi.hosp_seq_id)
--                  left outer join diagnosys_details dd on (dd.claim_seq_id=cad.claim_seq_id)
--        left outer join tpa_icd10_master_details tic on (dd.diagnosys_code=tic.icd_code)
             left outer join FIN_APP.TPA_CLAIMS_PAYMENT z on (cad.claim_seq_id=z.CLAIM_SEQ_ID and z.policy_seq_id=cad.policy_seq_id)
           left outer join FIN_APP.TPA_PAYMENT_CHECKS_DETAILS n on (n.PAYMENT_SEQ_ID=z.PAYMENT_SEQ_ID)
          left outer  join FIN_APP.tpa_claims_check f on (n.CLAIMS_CHK_SEQ_ID=f.CLAIMS_CHK_SEQ_ID)
          join app.clm_batch_upload_details bat on(cad.CLM_BATCH_SEQ_ID=bat.CLM_BATCH_SEQ_ID)';------
          IF v_clm_pay_status IS NOT NULL  THEN
           if v_clm_pay_status = 'PD' THEN
              -- like changed to =
            v_where := v_where||' AND cad.claim_seq_id is not null ';
           elsif v_clm_pay_status = 'PND' THEN
            v_where := v_where||' AND cad.claim_seq_id is  null and pad.pat_STATUS_TYPE_ID != ''REJ''';
           end if;
          END IF;
          
          IF v_rpt_id = 'clmPaymentId' OR v_rpt_id = 'clmSubmissionId' then 
      -- like changed to =
            v_where := v_where||' AND cad.claim_seq_id is not null ';
   
  END IF;
  
      END IF;
    
	IF v_auth_number IS NOT NULL THEN
      -- like changed to =
      v_where := v_where ||' AND pad.auth_number = :v_auth_number ';
       i := i+1;
       bind_tab(i) := v_auth_number;
    END IF;
	
	IF V_HOSP_SEQ_ID IS NOT NULL THEN
      -- like changed to =
      v_where := v_where ||' AND thi.hosp_seq_id = :V_HOSP_SEQ_ID ';
       i := i+1;
       bind_tab(i) := V_HOSP_SEQ_ID;
    END IF;
    

       
  IF v_to_date IS NOT NULL THEN 
        v_where := v_where  ||' AND CAD.DATE_OF_HOSPITALIZATION<=:v_to_date';
        i:=i+1;
       bind_tab(i) := v_to_date;
  END IF;
  
 IF v_fdate IS NOT NULL THEN
        v_where := v_where  ||' AND  CAD.DATE_OF_HOSPITALIZATION >=:v_fdate';
        i:=i+1;
       bind_tab(i) := v_fdate;
  END IF;
  
  IF v_to_date1 IS NOT NULL THEN 
        v_where := v_where  ||' AND cad.CLM_RECEIVED_DATE<=:v_to_date1';
        i:=i+1;
       bind_tab(i) := v_to_date1;
  END IF;
  
 IF v_fdate1 IS NOT NULL THEN
        v_where := v_where  ||' AND  cad.CLM_RECEIVED_DATE>=:v_fdate1';
        i:=i+1;
       bind_tab(i) := v_fdate1;
  END IF;
       
 IF v_patientName IS NOT NULL THEN
      -- like changed to =
      v_where := v_where  ||' AND trim(cad.mem_name) LIKE :v_patientName';
       i := i+1;
       bind_tab(i) := UPPER(v_patientName)||'%';
  END IF;
   IF v_invoice_number IS NOT NULL THEN
      -- like changed to =
      v_where := v_where  ||' and cad.invoice_number =:v_invoice_number';
       i := i+1;
       bind_tab(i) := v_invoice_number;
  END IF;
  IF v_claim_number IS NOT NULL THEN
      -- like changed to =
      v_where := v_where ||' AND cad.claim_number = :v_claim_number ';
       i := i+1;
       bind_tab(i) := v_claim_number;
    END IF;
	
	IF v_pre_auth_number IS NOT NULL THEN
      -- like changed to =
      v_where := v_where ||' AND pad.pre_auth_number = :v_pre_auth_number ';
       i := i+1;
       bind_tab(i) := v_pre_auth_number;
    END IF;

 IF v_memberId IS NOT NULL THEN
      -- like changed to =
      v_where := v_where  ||' AND cad.tpa_enrollment_id = :v_memberId ';
       i := i+1;
       bind_tab(i) := UPPER(v_memberId);
  END IF;
  
    
	IF v_status IS NOT NULL  THEN
      -- like changed to =
     v_where := v_where||' AND cad.CLM_STATUS_TYPE_ID = :v_status ';
    i := i+1;
    bind_tab(i) :=v_status;
  END IF;
  
  IF v_ref_no IS NOT NULL  THEN
      -- like changed to =
     v_where := v_where||' AND cad.EVENT_NO = :v_ref_no ';
    i := i+1;
    bind_tab(i) :=v_ref_no;
  END IF;
  ------------
  IF v_batch_no IS NOT NULL THEN
    v_where := v_where||' AND bat.BATCH_NO = :v_batch_no ';
    i := i+1;
    bind_tab(i) := TRIM(v_batch_no);
  END IF;
  
  IF v_pay_ref_num  IS NOT NULL THEN
    v_where :=v_where||' AND f.CHECK_NUM = :v_pay_ref_num  ';
    i := i+1;
    bind_tab(i) := TRIM(v_pay_ref_num);
  END IF;
  
  IF v_clm_payment_status IS NOT NULL THEN
    v_where :=v_where||' AND  z.CLAIM_PAYMENT_STATUS = :v_clm_payment_status ';
    i:= i+1;
    bind_tab(i) := TRIM(v_clm_payment_status);
  END IF;
  ---------------
    v_where := v_where||' and (pad.pbm_yn=''Y'' or bat.source_type_id=''PBCL'') /* AND  pad.PAT_STATUS_TYPE_ID!=''INP''*/';
    
    
  IF v_where IS NOT NULL THEN
      v_where   := ' WHERE '||SUBSTR(v_where,5);
      v_sql_str := v_sql_str ||v_where;
  END IF;
  --dbms_output.put_line(v_sql_str);

	
	  v_sql_str := 'SELECT * FROM
        (SELECT A.*,DENSE_RANK() OVER (ORDER BY '||v_sort_var||' '||v_sort_order||',ROWNUM)
        Q FROM (' ||v_sql_str|| ') A ) WHERE  Q>= :v_start_num AND Q<= :v_end_num 
        ORDER BY pre_auth_number';
     -- dbms_output.put_line(v_sql_str);
     
     


    IF bind_tab.FIRST IS NOT NULL THEN
       CASE bind_tab.COUNT
       
        WHEN 1  THEN OPEN result_set FOR v_sql_str USING bind_tab(1), v_start_num , v_end_num ;
        WHEN 2  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2), v_start_num , v_end_num ;
        WHEN 3  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2) ,bind_tab(3) , v_start_num , v_end_num ;
        WHEN 4  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) , v_start_num , v_end_num ;
        WHEN 5  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5), v_start_num , v_end_num ;
        WHEN 6  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6), v_start_num , v_end_num ;
        WHEN 7  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6),bind_tab(7), v_start_num , v_end_num ;
        WHEN 8  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6),bind_tab(7),bind_tab(8), v_start_num , v_end_num ;
        ---------
        WHEN 9  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6),bind_tab(7),bind_tab(8), bind_tab(9) , v_start_num  , v_end_num ;
        WHEN 10 THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6),bind_tab(7),bind_tab(8), bind_tab(9) , bind_tab(10) , v_start_num , v_end_num ;
        WHEN 11 THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6),bind_tab(7),bind_tab(8), bind_tab(9) , bind_tab(10) , bind_tab(11), v_start_num , v_end_num ;
        ----------- 
        END CASE;
     ELSE
       OPEN result_set FOR v_sql_str USING v_start_num , v_end_num ;
       
     END IF;
     

END select_claim_rpt_list;
--=========================================================================================
procedure save_pbm_clm_file(v_pat_auth_seq_id            IN  pat_authorization_details.pat_auth_seq_id%type,
                       v_file_name               in varchar2,
                        v_gentype_id              in MOU_DOCS_INFO1.FILE_NAME%TYPE,
                        v_image_data              in MOU_DOCS_INFO1.IMAGE_FILE%TYPE,
                        v_rows_processed OUT NUMBER)
                        
                        is
                        
                        cursor pbm_pat_cur is
						 select * from pat_authorization_details p
						 where p.pat_auth_seq_id = v_pat_auth_seq_id;
						 
						 pbm_pat_rec pbm_pat_cur%rowtype;
             v_docs_path    VARCHAR2(100);
             
                        begin
                        
                        open pbm_pat_cur;
                        fetch pbm_pat_cur into pbm_pat_rec;
                        close pbm_pat_cur;
       IF v_image_data IS NOT NULL THEN
      hospital_empanel_pkg.save_mou_docs_info1(0,
                                               v_pat_auth_seq_id,
                                               v_gentype_id ,
                                               v_docs_path,
                                               v_file_name,
                                               pbm_pat_rec.added_by,
                                               v_image_data,
                                               pbm_pat_rec.hosp_seq_id,
                                               V_ROWS_PROCESSED
                                              );
  END IF;
  end save_pbm_clm_file;
  --============================================================================
   PROCEDURE select_claim_list(
  v_fromdate							              IN   VARCHAR2 ,
  v_toDate							                IN	 VARCHAR2 ,
  v_fromdate1							              IN   VARCHAR2 ,
  v_toDate1							                IN	 VARCHAR2 ,
	v_patientName						              IN  clm_authorization_details.mem_name%type,
  v_auth_number                         IN  clm_authorization_details.auth_number%type,
  v_invoice_number									    IN  clm_authorization_details.invoice_number%type,
  v_memberId											      IN  clm_authorization_details.tpa_enrollment_id%type,
  v_claim_number										    IN  clm_authorization_details.claim_number%type,
  v_clm_pay_status									    IN VARCHAR2,
	v_status							                IN	tpa_general_code.description%type,
	v_ref_no											        IN  clm_authorization_details.EVENT_NO%type,
  v_batch_number                        IN  clm_batch_upload_details.batch_no%type,
	v_sort_var                            IN  VARCHAR2,
  v_sort_order                          IN  VARCHAR2 ,
  v_start_num                           IN  NUMBER ,
  v_end_num                             IN  NUMBER ,
  V_HOSP_SEQ_ID                         IN  pat_authorization_details.hosp_seq_id%type,
  v_qatar_id                            IN  clm_authorization_details.emirate_id%type,
  v_inp_status                          IN  VARCHAR2,
  result_set                            OUT SYS_REFCURSOR
  )
  IS
	v_sql_str                            VARCHAR2(10000) ;
	TYPE bind_tab_type IS TABLE OF VARCHAR2(250) INDEX BY BINARY_INTEGER ;
    bind_tab                             bind_tab_type;
    i                                    NUMBER(2) := 0;
    v_where                              VARCHAR2(2000);
    v_stat                               VARCHAR2(20):=null;
    v_inp_status1                        VARCHAR2(10);
    v_fdate   clm_authorization_details.date_of_hospitalization%type:=to_date(v_fromdate,'dd/mm/yyyy');
    v_to_date clm_authorization_details.date_of_hospitalization%type  :=to_date(v_toDate,'dd/mm/yyyy')+1;
	v_fdate1   clm_authorization_details.CLM_RECEIVED_DATE%type:=to_date(v_fromdate1,'dd/mm/yyyy');
    v_to_date1 clm_authorization_details.CLM_RECEIVED_DATE%type  :=to_date(v_toDate1,'dd/mm/yyyy')+1;
--  l_sort_var VARCHAR2(30);
--   v_seq_id  VARCHAR2(30);
    
    
  BEGIN
        v_sql_str :=' with shrtfll as (select max(s.shortfall_seq_id) shortfall_seq_id, s.claim_seq_id
                       from clm_authorization_details c
                       join shortfall_details s on (c.claim_seq_id = s.claim_seq_id)
                       group by s.claim_seq_id
                      )
                      SELECT  cad.CLAIM_NUMBER AS CLAIM_NUMBER,
                       cad.tpa_enrollment_id as tpa_enrollment_id ,
                       cad.mem_name as MEM_NAME,
                      pad.pre_auth_number as pre_auth_number,
                      cad.INVOICE_NUMBER AS INVOICE_NUMBER,
                      pad.pat_auth_seq_id as pre_auth_seq_id,
                      case when cad.completed_yn=''Y'' and cad.CLM_STATUS_TYPE_ID =''APR'' then ''Approved''
                  when cad.completed_yn=''Y'' and cad.CLM_STATUS_TYPE_ID =''REJ'' then ''Rejected''
                  when cad.CLM_STATUS_TYPE_ID=''REQ'' THEN ''Shortfall''
                  When cad.CLM_STATUS_TYPE_ID=''INP'' then ''In Progress'' end   as status ,
                  to_char(cad.DATE_OF_HOSPITALIZATION,''dd/mm/yyyy'')  as PRESCRIPTION_DATE ,
                 -- tic.short_desc AS DRUG_DESCRIPTION,
                 null as DRUG_DESCRIPTION,
                  --C.QUANTITY AS QUANTITY,
                  null AS QUANTITY,
                  pad.auth_number,
                  cad.REQUESTED_AMOUNT AS REQUESTED_AMOUNT,
                 -- case when k.CLAIM_PAYMENT_STATUS=''PAID'' then k.CLAIM_PAYMENT_STATUS
                ---  else ''PENDING'' END AS payment_status,
                NVL(k.CLAIM_PAYMENT_STATUS,''NA'') AS payment_status,
--                   case when cad.claim_seq_id is not null then ''PA Apprvd and Dispensed''--v_clm_pay_status
--                  when cad.claim_seq_id is  null then ''PA Apprvd not Dispensed''
--                    end as payment_status,
                   cad.event_no AS EVENT_REFERENCE_NUMBER,
                    --C.DENIAL_DESC AS DENIAL_REASON,
                    null AS DENIAL_REASON,
                  cad.emirate_id as qatar_id ,
                  thi.hosp_name as  clinician_name ,
                  case when CAD.completed_yn=''Y'' and CAD.CLM_STATUS_TYPE_ID =''APR'' then  Cad.TOT_APPROVED_AMOUNT
                  when CAD.completed_yn=''Y'' and CAD.CLM_STATUS_TYPE_ID =''REJ'' then Cad.TOT_APPROVED_AMOUNT
                  when CAD.completed_yn=''Y'' and CAD.CLM_STATUS_TYPE_ID not in (''REJ'',''APR'') then 0 
                  when nvl(CAD.completed_yn,''N'')=''N'' and CAD.CLM_STATUS_TYPE_ID in (''REQ'',''INP'') then NVL(Cad.TOT_APPROVED_AMOUNT,0)  
                    end as APPROVED_AMOUNT,
                 
                   --Cad.TOT_APPROVED_AMOUNT as APPROVED_AMOUNT,
                  --C.DISALLOWED_AMOUNT AS DISALLOWED_AMOUNT,
                  null AS DISALLOWED_AMOUNT,
                  Cad.TOT_DISCOUNT_AMOUNT AS DISCOUNT_AMOUNT,
                  pad.event_no AS PAYMENT_REFRENCE_NUMBER,
                  to_char(cad.CLM_RECEIVED_DATE,''dd/mm/yyyy HH12:MI AM'') AS DISPENSED_DATE,--submission date
                  CAD.TOT_PATIENT_SHARE_AMOUNT as PATIENT_SHARE_AMOUNT,
                   cad.TOT_DISC_GROSS_AMOUNT AS AGRD_AMT,
                   cad.claim_seq_id,
                   cad.SETTLEMENT_NUMBER,
                   to_char(cad.decision_date,''dd/mm/yyyy HH12:MI AM'') as decision_date,
--                   c.PATIENT_SHARE_AMOUNT,
--                   NULL AS AGRD_AMT,
                     bat.BATCH_NO as batch_number,
                  CAD.CLM_STATUS_TYPE_ID||''-''||'||''''||v_inp_status||'''' ||' AS IN_PROGESS_STATUS
                  
                  FROM --APP.PAT_ACTIVITY_DETAILS c LEFT OUTER JOIN
                    pat_authorization_details pad  
                    RIGHT OUTER JOIN CLM_authorization_details CAD ON (PAD.PAT_AUTH_SEQ_ID=CAD.PAT_AUTH_SEQ_ID AND PAD.PAT_AUTH_SEQ_ID =CAD.PAT_AUTH_SEQ_ID  )
                    left outer join clm_hospital_details chd on(cad.claim_seq_id=chd.claim_seq_id)
                  LEFT OUTER JOIN  tpa_hosp_info thi on(chd.hosp_seq_id=thi.hosp_seq_id)
                  LEFT OUTER JOIN  tpa_claims_payment k on(k.claim_seq_id=cad.claim_seq_id)
--                  left outer join diagnosys_details dd on (dd.claim_seq_id=cad.claim_seq_id)
--        left outer join tpa_icd10_master_details tic on (dd.diagnosys_code=tic.icd_code)
          join clm_batch_upload_details bat on(cad.CLM_BATCH_SEQ_ID=bat.CLM_BATCH_SEQ_ID)
          left join shrtfll sh ON (sh.claim_seq_id = cad.claim_seq_id)
          left join shortfall_details sd on (sh.shortfall_seq_id=sd.shortfall_seq_id)';
        
      
    
	IF v_auth_number IS NOT NULL THEN
      -- like changed to =
      v_where := v_where ||' AND pad.auth_number = :v_auth_number ';
       i := i+1;
       bind_tab(i) := v_auth_number;
    END IF;
	
	IF V_HOSP_SEQ_ID IS NOT NULL THEN
      -- like changed to =
      v_where := v_where ||' AND thi.hosp_seq_id = :V_HOSP_SEQ_ID ';
       i := i+1;
       bind_tab(i) := V_HOSP_SEQ_ID;
    END IF;
    

       
  IF v_to_date IS NOT NULL THEN 
        v_where := v_where  ||' AND cad.DATE_OF_HOSPITALIZATION<=:v_to_date';
        i:=i+1;
       bind_tab(i) := v_to_date;
  END IF;
  
 IF v_fdate IS NOT NULL THEN
        v_where := v_where  ||' AND  cad.DATE_OF_HOSPITALIZATION >=:v_fdate';
        i:=i+1;
       bind_tab(i) := v_fdate;
  END IF;
  
  IF v_to_date1 IS NOT NULL THEN 
        v_where := v_where  ||' AND cad.CLM_RECEIVED_DATE<=:v_to_date1';
        i:=i+1;
       bind_tab(i) := v_to_date1;
  END IF;
  
 IF v_fdate1 IS NOT NULL THEN
        v_where := v_where  ||' AND  cad.CLM_RECEIVED_DATE>=:v_fdate1';
        i:=i+1;
       bind_tab(i) := v_fdate1;
  END IF;
       
 IF v_patientName IS NOT NULL THEN
      -- like changed to =
      v_where := v_where  ||' AND trim(cad.mem_name) LIKE :v_patientName';
       i := i+1;
       bind_tab(i) := UPPER(v_patientName)||'%';
  END IF;
   IF v_invoice_number IS NOT NULL THEN
      -- like changed to =
      v_where := v_where  ||' AND cad.invoice_number =:v_invoice_number';
       i := i+1;
       bind_tab(i) := v_invoice_number;
  END IF;
  IF v_claim_number IS NOT NULL THEN
      -- like changed to =
      v_where := v_where ||' AND cad.claim_number = :v_claim_number ';
       i := i+1;
       bind_tab(i) := v_claim_number;
    END IF;
	


  IF v_memberId IS NOT NULL THEN
      -- like changed to =
      v_where := v_where  ||' AND cad.tpa_enrollment_id = :v_memberId ';
       i := i+1;
       bind_tab(i) := UPPER(v_memberId);
  END IF;
  ------------------- Cr0218(search by qatarID)--------------------------
  IF v_qatar_id IS NOT NULL THEN
      v_where := v_where  ||' AND cad.emirate_id = :v_qatar_id ';
      i := i+1;
      bind_tab(i) := UPPER(v_qatar_id);
  END IF;
  -----------------------------------------------------  
	IF v_status IS NOT NULL  THEN
      -- like changed to =
     v_where := v_where||' AND cad.CLM_STATUS_TYPE_ID = :v_status ';
    i := i+1;
    bind_tab(i) :=v_status;
  END IF;
  
  IF v_ref_no IS NOT NULL  THEN
      -- like changed to =
     v_where := v_where||' AND cad.EVENT_NO = :v_ref_no ';
    i := i+1;
    bind_tab(i) :=v_ref_no;
  END IF;
  
  -- IF v_clm_pay_status = 'PA'   THEN
   IF v_clm_pay_status IS NOT NULL  THEN
      -- like changed to =
      v_where := v_where||' AND TRIM(k.CLAIM_PAYMENT_STATUS) = :v_clm_pay_status  ';   ----FOR ALL STATUS
      i := i+1;
      bind_tab(i) := v_clm_pay_status;

   END IF;
  
  IF v_batch_number IS NOT NULL THEN
    v_where := v_where||' AND bat.BATCH_NO = :v_batch_number ';
    i :=i+1;
    bind_tab(i) := v_batch_number;
   END IF;   
   --===============CR0247====================================
    IF v_inp_status IS NOT NULL THEN
      IF v_inp_status = 'FRH' THEN
         v_inp_status1 := '0';
         v_where := v_where  ||' AND NVL(CAD.PARENT_CLAIM_SEQ_ID, 0) = 0 AND NVL(SD.CLAIM_SEQ_ID, 0) = :v_inp_status ';
      ELSIF v_inp_status = 'ENH' THEN
         v_inp_status1 := '0';
         v_where := v_where  ||' AND NVL(CAD.PARENT_CLAIM_SEQ_ID, 0) != :v_inp_status ';
      ELSIF v_inp_status = 'RES' THEN
         v_inp_status1 := 'RES';
         v_where := v_where  ||' AND CAD.CLM_STATUS_TYPE_ID = ''INP'' AND SD.SRTFLL_STATUS_GENERAL_TYPE_ID = :v_inp_status ';
      END IF;
      i := i+1;
      bind_tab(i) := UPPER(v_inp_status1);
    END IF;
    --=========================================================
    v_where := v_where||' and (pad.pbm_yn=''Y'' or UPPER(bat.source_type_id)=''PBCL'') ';
    
    
  IF v_where IS NOT NULL THEN
      v_where   := ' WHERE '||SUBSTR(v_where,5);
      v_sql_str := v_sql_str ||v_where;
  END IF;
  --dbms_output.put_line(v_sql_str);

	
	  v_sql_str := 'SELECT * FROM
        (SELECT A.*,DENSE_RANK() OVER (ORDER BY '||v_sort_var||' '||v_sort_order||',ROWNUM)
        Q FROM (' ||v_sql_str|| ') A ) WHERE  Q>= :v_start_num AND Q<= :v_end_num ';
     
   

    IF bind_tab.FIRST IS NOT NULL THEN
       CASE bind_tab.COUNT
       
        WHEN 1  THEN OPEN result_set FOR v_sql_str USING bind_tab(1), v_start_num , v_end_num ;
        WHEN 2  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2), v_start_num , v_end_num ;
        WHEN 3  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2) ,bind_tab(3) , v_start_num , v_end_num ;
        WHEN 4  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) , v_start_num , v_end_num ;
        WHEN 5  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5), v_start_num , v_end_num ;
        WHEN 6  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6), v_start_num , v_end_num ;
        WHEN 7  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6),bind_tab(7), v_start_num , v_end_num ;
        WHEN 8  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6),bind_tab(7),bind_tab(8), v_start_num , v_end_num ;
        WHEN 9  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6),bind_tab(7),bind_tab(8),bind_tab(9), v_start_num , v_end_num ;
        WHEN 10 THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6),bind_tab(7),bind_tab(8),bind_tab(9), bind_tab(10) , v_start_num , v_end_num ;
        WHEN 11 THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6),bind_tab(7),bind_tab(8),bind_tab(9), bind_tab(10), bind_tab(11) , v_start_num , v_end_num ;
        WHEN 12 THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6),bind_tab(7),bind_tab(8),bind_tab(9), bind_tab(10), bind_tab(11) ,bind_tab(12), v_start_num , v_end_num ;
        END CASE;
     ELSE
       OPEN result_set FOR v_sql_str USING v_start_num , v_end_num ;
       
     END IF;
     

END select_claim_list;
--====================================================================================================
PROCEDURE SELECT_CLAIM_DETAILS(
                                V_CLAIM_SEQ_ID  IN  clm_authorization_details.CLAIM_SEQ_ID%type,
                                v_pre_auth_seq_id IN pat_authorization_details.pat_auth_seq_id%type,
                                V_RESULT        OUT SYS_REFCURSOR,
                                v_diag_result_set  OUT SYS_REFCURSOR ,
                                v_activity_result_set  OUT SYS_REFCURSOR,
                                v_pre_auth_result_set  OUT SYS_REFCURSOR
                                )
                                IS
CURSOR pharmacy_cur IS 
 select b.disc_percent from app.clm_authorization_details a join clm_hospital_details chd on(chd.claim_seq_id=a.claim_seq_id)
 join app.tpa_hosp_tariff_details b on (chd.hosp_seq_id=b.HOSP_SEQ_ID)
 where b.acitivity_type_seq_id=5 
 AND a.date_of_hospitalization BETWEEN  b.start_date AND NVL(b.end_date,a.date_of_hospitalization)
 and a.claim_seq_id=V_CLAIM_SEQ_ID;
 
 v_pharmacy_rec                number(10);
                                
                                BEGIN
                                open V_RESULT for
                                select a.CLAIM_NUMBER,a.CLM_BATCH_SEQ_ID,a.INVOICE_NUMBER,a.CLAIM_TYPE,a.CLM_STATUS_TYPE_ID,to_char(a.CLM_RECEIVED_DATE, 'DD/MM/RRRR HH12:MI AM') as CLM_RECEIVED_DATE,
                                a.TOT_ALLOWED_AMOUNT,a.claim_seq_id,b.BATCH_NO,a.mem_name,c.policy_number,a.CLINICIAN_ID,d.CLINICIAN_NAME,A.SETTLEMENT_NUMBER,
                                a.requested_amount,
                                initcap(g.description) as claim_status
                                
                                from CLM_AUTHORIZATION_DETAILS a 
                                join  APP.CLM_BATCH_UPLOAD_DETAILS b on (a.CLM_BATCH_SEQ_ID=b.CLM_BATCH_SEQ_ID)
                                join tpa_enr_policy c on (a.policy_seq_id=c.policy_seq_id)
                                join clm_hospital_details d on (d.claim_seq_id=a.claim_seq_id)
                                --join PAT_NON_NETWORK_DETAILS d on (a.PAT_AUTH_SEQ_ID=d.PAT_AUTH_SEQ_ID)
                                join tpa_general_code g on g.general_type_id = a.clm_status_type_id
                                where a.claim_seq_id=V_CLAIM_SEQ_ID;
                                
                                 OPEN v_diag_result_set FOR 
                                 select dd.diag_seq_id,
                                       dd.pat_auth_seq_id,
                                       tic.icd_code as diagnosys_code,
                                       case when nvl(dd.primary_ailment_yn,'N')='Y' then 'Principal' else 'Secondary' end as primary_ailment_yn,
                                       tic.icd10_seq_id as icd_code_seq_id,
                                       tic.short_desc as icd_description
                                  from diagnosys_details dd
                                  left outer join tpa_icd10_master_details tic on (dd.diagnosys_code=tic.icd_code)
                                 where dd.claim_seq_id =V_CLAIM_SEQ_ID
                             order by dd.diag_seq_id;
                             
                                 open pharmacy_cur ; 
                                 fetch pharmacy_cur into v_pharmacy_rec ;
                                 close pharmacy_cur;
                             
                             OPEN v_activity_result_set FOR
                              select
                               case when ad.CODE!='PHARMA' THEN 
                                    case when ad.INTERNAL_CODE is not null then nvl(mm.activity_description,md.activity_description)
                                    when  ad.INTERNAL_CODE is null and ad.moph_Codes is not null then tamd.ACTIVITY_DESCRIPTION
                                    when  ad.INTERNAL_CODE is null and ad.INTERNAL_CODE is null then ad.INTERNAL_DESC
                                                                    end
                                 when ad.CODE='PHARMA' then ad.INTERNAL_DESC END as activity_description,
                             case when ad.approved_amount >0 then 'Approved' else 'Rejected' end as activity_status,
                             ad.quantity,
                             case when ad.unit_type='PCKG' THEN 'Package'
                             when ad.unit_type='LOSE' THEN 'Loose' 
                             when ad.unit_type='NA' THEN 'NA' else null end as unit_type,
                             --case when ad.unit_type='PCKG' THEN
                             --(NVL((md.package_price),0)- nvl((nvl(v_pharmacy_rec,0)*nvl(md.PACKAGE_PRICE,0)/100),0))*ad.quantity
                             --else
                             --ad.disc_gross_amount end as req_amount,
                             ad.disc_gross_amount req_amount,
                             ad.patient_share_amount,
                             ad.approved_amount approved_amt,
                             ad.posology_duration as duration_days,
                             case when ad.denial_code like ';%' then substr(ad.denial_code,2) else ad.denial_code end as denial_code,
                             case when nvl(ad.remarks,ad.DENIAL_DESC) like ';%' then substr(ad.remarks,2) else nvl(ad.remarks,ad.denial_desc) end as remarks,
                             clm.clm_received_date  as date_approval
                             from  pat_activity_details ad                              
                              left outer join tpa_pharmacy_master_details md on (ad.code = md.activity_code)
                              left outer join  clm_authorization_Details clm on (ad.claim_seq_id=CLM.claim_seq_id)
                              left outer join tpa_pharmacy_master_details tamd on(ad.moph_codes=tamd.moph_codes)
                              left outer join tpa_activity_master_details mm on(ad.code=mm.activity_code) 
                              where  ad.claim_seq_id =V_CLAIM_SEQ_ID;
                              
                             open v_pre_auth_result_set for
                             select pad.pre_auth_number,
                                    pad.auth_number,
                                    to_char(pad.hospitalization_date,'dd/mm/yyyy') as prescreption_date,
                                    to_char(pad.added_date,'dd/mm/yyyy hh12:mi AM') as transaction_date,
                                    nd.clinician_id,
                                    pad.tpa_enrollment_id as alkoot_id,
                                    ins.ins_comp_name,
                                    to_char(pad.completed_date, 'DD/MM/RRRR HH12:MI AM') as decision_date,
                                    pad.event_no as event_reference_no       
                             from pat_authorization_details pad left outer join pat_non_network_details nd ON (nd.pat_auth_seq_id=pad.pat_auth_seq_id)
                                                                left outer join tpa_ins_info ins on(ins.ins_seq_id=pad.ins_seq_id)
                             where pad.pat_auth_seq_id= v_pre_auth_seq_id;
                                  
                               
end SELECT_CLAIM_DETAILS;
--=========================================================
--cr-0323EligibilityCheckForPBM
-- get eligibility details
--*************************************
PROCEDURE get_mem_benifit_details(v_tpa_enrollment_id                  IN  PAT_ENROLL_DETAILS.tpa_enrollment_id%TYPE,
                                  v_benefit_type                       IN  PAT_AUTHORIZATION_DETAILS.Benifit_Type%TYPE,                                     
                                  v_hosp_seq_id                        IN  TPA_HOSP_INFO.HOSP_SEQ_ID%TYPE,
                                  v_result_set                         OUT SYS_REFCURSOR,
                                  v_warning                            OUT VARCHAR2/*,
                                  v_network_check                      OUT SYS_REFCURSOR*/)
IS 
benefit_type           varchar2(30);
--v_enroll_type          varchar2(30);
v_provider_network     varchar2(30);

CURSOR enroll_type_cur IS
  select tep.enrol_type_id,tep.policy_seq_id, count(tep.enrol_type_id) as cnt
  from app.tpa_enr_policy tep
  join app.tpa_enr_policy_group teg on (tep.policy_seq_id = teg.policy_seq_id) 
  join app.tpa_enr_policy_member tem on(teg.policy_group_seq_id = tem.policy_group_seq_id)
 where  (tem.tpa_enrollment_id=v_tpa_enrollment_id or tem.emirate_id=v_tpa_enrollment_id)
  and sysdate between tep.effective_from_date and tep.effective_to_date+1
 group by tep.enrol_type_id,tep.policy_seq_id;
 
CURSOR Eligible_benifits IS
 select wm_concat(a.benifit_type) 
 from 
 (select distinct hc.benifit_type as benifit_type
  from app.tpa_enr_policy tep
  join app.tpa_enr_policy_group teg
    on (tep.policy_seq_id = teg.policy_seq_id) 
  join app.tpa_enr_policy_member tem
 on(teg.policy_group_seq_id = tem.policy_group_seq_id)
 join app.tpa_ins_prod_hosp_copay hc on (hc.policy_seq_id=tep.policy_seq_id)
 join app.tpa_ins_assoc_prod_hosp ph on (hc.prod_policy_seq_id=ph.prod_policy_seq_id 
                                            and ph.status_general_type_id='ASL' and ph.hosp_seq_id=v_hosp_seq_id)
 where ( tem.tpa_enrollment_id=v_tpa_enrollment_id) and sysdate between tep.effective_from_date and tep.effective_to_date and hc.hosp_seq_id=v_hosp_seq_id or tem.emirate_id=v_tpa_enrollment_id) a;
                                        
 
v_enroll_type enroll_type_cur%ROWTYPE;
v_hosp_ben    VARCHAR2(32000);
v_policy_seq_id   NUMBER(10);
v_policy_number   VARCHAR2(100);
v_elg_cnt       NUMBER(10);
v_benefit_limit NUMBER(10);


CURSOR PREVIOUS_POLICY_NUMBER(v_policy_seq_id number) IS
    SELECT ENR.POLICY_NUMBER 
    FROM tpa_enr_policy enr
    WHERE ENR.PREV_POLICY_SEQ_ID is null
    START WITH ENR.POLICY_SEQ_ID=v_policy_seq_id
    CONNECT BY enr.POLICY_SEQ_ID = PRIOR PREV_POLICY_SEQ_ID;
    
CURSOR Curr_Policy_seq_id IS
  select tep.policy_seq_id
  from app.tpa_enr_policy tep
  join app.tpa_enr_policy_group teg on (tep.policy_seq_id = teg.policy_seq_id) 
  join app.tpa_enr_policy_member tem on(teg.policy_group_seq_id = tem.policy_group_seq_id)
  where  tem.tpa_enrollment_id=v_tpa_enrollment_id and sysdate between tep.effective_from_date and tep.effective_to_date+1;
                                             
CURSOR CR_BENEFIT_YA (cv_policy_seq_id IN app.tpa_enr_policy.policy_seq_id%TYPE)
IS
SELECT COUNT(1) AS CNT
FROM app.tpa_enr_policy tep
      INNER JOIN app.tpa_ins_prod_hosp_copay hc on (hc.policy_seq_id=tep.policy_seq_id)
      INNER JOIN app.tpa_ins_assoc_prod_hosp ph on (hc.prod_policy_seq_id=ph.prod_policy_seq_id
                                            and ph.status_general_type_id='ASL' and ph.hosp_seq_id=v_hosp_seq_id)
WHERE tep.policy_seq_id=v_policy_seq_id AND hc.benifit_type IS NOT NULL;
LV_CR_BENEFIT_YA CR_BENEFIT_YA%ROWTYPE;

--------------getting_limits
CURSOR Optical_limit_cur(v_cur_policy_seq number) IS
       SELECT SUM(nvl(s.used_amount, r.used_amount)) FROM
         ( SELECT b.approved_amount AS used_amount , b.Pat_Auth_Seq_Id, a.claim_seq_id
               FROM pat_authorization_details a
               left outer join app.clm_authorization_details x on (a.pat_auth_seq_id = x.pat_auth_seq_id)-----PROD FIXING
               JOIN pat_activity_details b ON (a.pat_auth_seq_id = b.pat_auth_seq_id AND A.pat_status_type_id != 'PCN' AND A.pat_status_type_id != 'REJ' )
               JOIN tpa_activity_details G ON (b.code = g.activity_code)
               --JOIN tpa_activity_details gg ON (g.master_activity_code = gg.master_activity_code )
               WHERE (A.Tpa_Enrollment_Id = v_tpa_enrollment_id or a.emirate_id=v_tpa_enrollment_id)
               AND NVL(A.Pat_Enhanced_Yn,'N') = 'N'
               --AND gg.activity_code = 'V2020'
               and a.policy_seq_id=v_cur_policy_seq
               AND ((a.benifit_type='OPTC' AND g.master_activity_code='9')OR g.master_activity_code IN ('V2020','92015')) AND nvl(b.optc_payable,'EXC')='INC'
               AND (a.claim_seq_id IS NULL OR (a.claim_seq_id IS NOT NULL AND x.clm_status_type_id IN ('INP', 'REQ') 
               ))
               --AND a.hospitalization_date >= v_start_date AND A.Discharge_Date <= v_end_date 
               ) r
          FULL OUTER JOIN
           ( SELECT b.approved_amount AS used_amount , a.claim_seq_id
               FROM clm_authorization_details A 
               JOIN pat_activity_details b ON (a.claim_seq_id = b.claim_seq_id AND A.CLM_STATUS_TYPE_ID != 'PCN' AND A.CLM_STATUS_TYPE_ID != 'REJ' )-----***
               JOIN tpa_activity_details G ON (b.code = g.activity_code)
               --JOIN tpa_activity_details gg ON (g.master_activity_code = gg.master_activity_code )
               WHERE (A.Tpa_Enrollment_Id = v_tpa_enrollment_id or a.emirate_id=v_tpa_enrollment_id)
               --AND gg.activity_code = 'V2020'
               and a.policy_seq_id = v_cur_policy_seq
               AND ((a.benifit_type='OPTC' AND g.master_activity_code='9')OR g.master_activity_code IN ('V2020','92015')) AND nvl(b.optc_payable,'EXC')='INC'
               AND (A.PAT_AUTH_SEQ_ID IS NULL OR (A.PAT_AUTH_SEQ_ID IS NOT NULL AND A.clm_status_type_id = 'APR'))-- Fixing for used amount
               --AND A.date_of_hospitalization  >= v_start_date AND A.date_of_discharge  <= v_end_date 
               ) s
               ON ( r.claim_seq_id = s.claim_seq_id );
              
          
        CURSOR dental_limit_cur(v_cur_policy_seq number) IS
        SELECT SUM(nvl(s.used_amount, r.used_amount)) FROM
         ( SELECT CASE WHEN  a.claim_seq_id IS NOT NULL AND x.clm_status_type_id in ('INP','REQ') THEN  
                  b.approved_amount 
                  ELSE CASE WHEN NVL(A.CLAIM_SEQ_ID,0) = 0 THEN b.approved_amount END
                  END AS used_amount , b.Pat_Auth_Seq_Id, a.claim_seq_id 
               FROM pat_authorization_details a
               left outer join app.clm_authorization_details x on (a.pat_auth_seq_id = x.pat_auth_seq_id)
               JOIN pat_activity_details b ON (a.pat_auth_seq_id = b.pat_auth_seq_id AND A.pat_status_type_id != 'PCN' AND A.pat_status_type_id != 'REJ' )
               JOIN tpa_activity_details G ON (b.code = g.activity_code)
               WHERE (A.Tpa_Enrollment_Id = v_tpa_enrollment_id or a.emirate_id=v_tpa_enrollment_id)  
               AND NVL(A.Pat_Enhanced_Yn,'N') = 'N' 
               --AND g.activity_code LIKE 'D%'
               and a.policy_seq_id = v_cur_policy_seq
               and a.benifit_type='DNTL'
               and b.approved_amount>0
               ) r
          FULL OUTER JOIN
           ( SELECT CASE WHEN A.PAT_AUTH_SEQ_ID IS NOT NULL AND A.clm_status_type_id IN ('INP','REQ') THEN NULL
                    ELSE CASE WHEN NVL(A.PAT_AUTH_SEQ_ID,0) = 0 THEN   b.approved_amount 
                             WHEN A.PAT_AUTH_SEQ_ID IS NOT NULL AND A.clm_status_type_id IN ('APR') THEN   b.approved_amount  END
                    END AS used_amount , a.claim_seq_id 
               FROM clm_authorization_details A 
               JOIN pat_activity_details b ON (a.claim_seq_id = b.claim_seq_id AND A.CLM_STATUS_TYPE_ID != 'PCN' AND A.CLM_STATUS_TYPE_ID != 'REJ' )
               JOIN tpa_activity_details G ON (b.code = g.activity_code)
               WHERE (A.Tpa_Enrollment_Id = v_tpa_enrollment_id or a.emirate_id=v_tpa_enrollment_id)   
               --AND g.activity_code LIKE 'D%' 
               and a.policy_seq_id = v_cur_policy_seq
               and a.benifit_type='DNTL'
               ) s
               ON ( r.claim_seq_id = s.claim_seq_id );
   
    CURSOR maternity_oplimit_cur(v_cur_policy_seq number) IS
       SELECT SUM(nvl(s.used_amount, r.used_amount)) FROM
         ( SELECT  CASE WHEN  a.claim_seq_id IS NOT NULL AND x.clm_status_type_id in ('INP','REQ') THEN  
                  A.Tot_Allowed_Amount 
                  ELSE CASE WHEN NVL(A.CLAIM_SEQ_ID,0) = 0 THEN A.Tot_Allowed_Amount END
                  END AS used_amount , A.Pat_Auth_Seq_Id, a.claim_seq_id
           FROM pat_authorization_details a
           left outer join app.clm_authorization_details x on (a.pat_auth_seq_id = x.pat_auth_seq_id)
            WHERE a.pat_auth_seq_id IN
               (SELECT distinct a.pat_auth_seq_id    
               FROM pat_authorization_details a
               JOIN diagnosys_details b ON (a.pat_auth_seq_id = b.pat_auth_seq_id AND A.pat_status_type_id != 'PCN' AND A.pat_status_type_id != 'REJ' )
               JOIN tpa_icd_codes G ON (b.diagnosys_code = g.icd_code)
               JOIN tpa_icd_codes gg ON (g.master_icd_code = gg.master_icd_code )
               WHERE (A.Tpa_Enrollment_Id = v_tpa_enrollment_id or a.emirate_id=v_tpa_enrollment_id)
               AND  NVL(A.Pat_Enhanced_Yn,'N') = 'N'  
               AND gg.icd_code = 'Z34.90'
               and a.encounter_type_id in ('1','2')
               AND a.benifit_type = 'OMTI'
               AND NVL(A.MAT_COMPLCTON_YN,'N') = 'N'
               ) )r
          FULL OUTER JOIN
           ( SELECT CASE WHEN A.PAT_AUTH_SEQ_ID IS NOT NULL AND A.clm_status_type_id IN ('INP','REQ') THEN NULL
                    ELSE CASE WHEN NVL(A.PAT_AUTH_SEQ_ID,0) = 0 THEN   A.Tot_Allowed_Amount 
                             WHEN A.PAT_AUTH_SEQ_ID IS NOT NULL AND A.clm_status_type_id IN ('APR') THEN   A.Tot_Allowed_Amount  END
                    END  /*A.Tot_Allowed_Amount*/ AS used_amount , a.claim_seq_id
             FROM clm_authorization_details A 
              WHERE a.claim_seq_id IN  
               (SELECT distinct a.claim_seq_id  
               FROM clm_authorization_details A 
               JOIN diagnosys_details b ON (a.claim_seq_id = b.claim_seq_id AND A.CLM_STATUS_TYPE_ID != 'PCN' AND A.CLM_STATUS_TYPE_ID != 'REJ' )
               JOIN tpa_icd_codes G ON (b.diagnosys_code = g.icd_code)
               JOIN tpa_icd_codes gg ON (g.master_icd_code = gg.master_icd_code )
               WHERE (A.Tpa_Enrollment_Id = v_tpa_enrollment_id or a.emirate_id=v_tpa_enrollment_id)  
               AND gg.icd_code = 'Z34.90'
               and a.encounter_type_id in ('1','2')
               AND NVL(A.MAT_COMPLCTON_YN,'N') = 'N'
               AND a.benifit_type = 'OMTI'
               )) s
               ON ( r.claim_seq_id = s.claim_seq_id );
              
             
       CURSOR maternity_Iplimit_cur(v_cur_policy_seq number) IS
       SELECT SUM(nvl(s.used_amount, r.used_amount)) FROM
         ( SELECT  CASE WHEN  a.claim_seq_id IS NOT NULL AND x.clm_status_type_id in ('INP','REQ') THEN  
                  A.Tot_Allowed_Amount 
                  ELSE CASE WHEN NVL(A.CLAIM_SEQ_ID,0) = 0 THEN A.Tot_Allowed_Amount END
                  END AS used_amount , A.Pat_Auth_Seq_Id, a.claim_seq_id
           FROM pat_authorization_details a
           left outer join app.clm_authorization_details x on (a.pat_auth_seq_id = x.pat_auth_seq_id)
            WHERE a.pat_auth_seq_id IN
               (SELECT distinct a.pat_auth_seq_id    
               FROM pat_authorization_details a
               JOIN diagnosys_details b ON (a.pat_auth_seq_id = b.pat_auth_seq_id AND A.pat_status_type_id != 'PCN' AND A.pat_status_type_id != 'REJ' )
               JOIN tpa_icd_codes G ON (b.diagnosys_code = g.icd_code)
               JOIN tpa_icd_codes gg ON (g.master_icd_code = gg.master_icd_code )
               WHERE (A.Tpa_Enrollment_Id = v_tpa_enrollment_id or a.emirate_id=v_tpa_enrollment_id)
               and a.policy_seq_id = v_cur_policy_seq
               AND  NVL(A.Pat_Enhanced_Yn,'N') = 'N'  
               AND gg.icd_code = 'Z34.90'
               and a.encounter_type_id in ('3','4','1','2')
               AND a.benifit_type in  ('IMTI','OMTI')
               AND NVL(A.MAT_COMPLCTON_YN,'N') = 'N'
               ) )r
          FULL OUTER JOIN
           ( SELECT CASE WHEN A.PAT_AUTH_SEQ_ID IS NOT NULL AND A.clm_status_type_id IN ('INP','REQ') THEN NULL
                    ELSE CASE WHEN NVL(A.PAT_AUTH_SEQ_ID,0) = 0 THEN   A.Tot_Allowed_Amount 
                             WHEN A.PAT_AUTH_SEQ_ID IS NOT NULL AND A.clm_status_type_id IN ('APR') THEN   A.Tot_Allowed_Amount  END
                    END  /*A.Tot_Allowed_Amount*/ AS used_amount , a.claim_seq_id
             FROM clm_authorization_details A 
              WHERE a.claim_seq_id IN  
               (SELECT distinct a.claim_seq_id  
               FROM clm_authorization_details A 
               JOIN diagnosys_details b ON (a.claim_seq_id = b.claim_seq_id AND A.CLM_STATUS_TYPE_ID != 'PCN' AND A.CLM_STATUS_TYPE_ID != 'REJ' )
               JOIN tpa_icd_codes G ON (b.diagnosys_code = g.icd_code)
               JOIN tpa_icd_codes gg ON (g.master_icd_code = gg.master_icd_code )
               WHERE (A.Tpa_Enrollment_Id = v_tpa_enrollment_id or a.emirate_id=v_tpa_enrollment_id)
               and a.policy_seq_id = v_cur_policy_seq
               AND gg.icd_code = 'Z34.90'
               and a.encounter_type_id in ('3','4')
               AND NVL(A.MAT_COMPLCTON_YN,'N') = 'N'
               AND a.benifit_type IN ('IMTI','OMTI')
               )) s
               ON ( r.claim_seq_id = s.claim_seq_id );
               
   CURSOR oplimit_cur(v_cur_policy_seq number) IS
     SELECT SUM(nvl(s.used_amount, r.used_amount)) FROM
         ( SELECT b.approved_amount AS used_amount , b.Pat_Auth_Seq_Id, a.claim_seq_id
               FROM pat_authorization_details a
               left outer join app.clm_authorization_details x on (a.pat_auth_seq_id = x.pat_auth_seq_id)
               JOIN pat_activity_details b ON (a.pat_auth_seq_id = b.pat_auth_seq_id AND A.pat_status_type_id != 'PCN' AND A.pat_status_type_id != 'REJ' )
               JOIN tpa_activity_details G ON (b.code = g.activity_code)
               --JOIN tpa_activity_details gg ON (g.master_activity_code = gg.master_activity_code )
               WHERE (A.Tpa_Enrollment_Id = v_tpa_enrollment_id or a.emirate_id=v_tpa_enrollment_id)
               AND NVL(A.Pat_Enhanced_Yn,'N') = 'N'
               AND g.master_activity_code = '0000-000000-0000'
               and a.policy_seq_id=v_cur_policy_seq
               and a.benifit_type='OPTS'
               AND (a.claim_seq_id IS NULL OR (a.claim_seq_id IS NOT NULL AND x.clm_status_type_id IN ('INP', 'REQ') 
               ))
               --AND a.hospitalization_date >= v_start_date AND A.Discharge_Date <= v_end_date 
               ) r
          FULL OUTER JOIN
           ( SELECT b.approved_amount AS used_amount , a.claim_seq_id
               FROM clm_authorization_details A 
               JOIN pat_activity_details b ON (a.claim_seq_id = b.claim_seq_id AND A.CLM_STATUS_TYPE_ID != 'PCN' AND A.CLM_STATUS_TYPE_ID != 'REJ' )
               JOIN tpa_activity_details G ON (b.code = g.activity_code)
               --JOIN tpa_activity_details gg ON (g.master_activity_code = gg.master_activity_code )
               WHERE (A.Tpa_Enrollment_Id = v_tpa_enrollment_id or a.emirate_id=v_tpa_enrollment_id)
               AND g.master_activity_code = '0000-000000-0000'
               and a.policy_seq_id = v_cur_policy_seq
               and a.benifit_type='OPTS'
               AND (A.PAT_AUTH_SEQ_ID IS NULL OR (A.PAT_AUTH_SEQ_ID IS NOT NULL AND A.clm_status_type_id = 'APR'))-- Fixing for used amount
               --AND A.date_of_hospitalization  >= v_start_date AND A.date_of_discharge  <= v_end_date 
               ) s
               ON ( r.claim_seq_id = s.claim_seq_id );
                       
           v_limit    number(10):=0;
           v_visits   number(10):=0;
             
  CURSOR get_benefit_limit_cur(v_seq tpa_ins_prod_policy_rules.prod_policy_rule_seq_id%type,v_si number) is 
      select tep.policy_seq_id,
             max(case when d.cond_id = 'cnd.18.1.8' and c.coverage_pay_val = 1 then  to_char(v_si) when d.cond_id = 'cnd.18.1.8' and c.coverage_pay_val = 3 then nvl(replace(case when d.cond_id = 'cnd.18.1.8' then REGEXP_SUBSTR(d.cond_fun, '[^,]+', 1, 3) else null end, ''''), to_char(v_si)) END) Maternity_limit,
             max(case when d.cond_id = 'cnd.20.1.2' and c.coverage_pay_val = 1 then to_char(v_si)  when d.cond_id = 'cnd.20.1.2' and c.coverage_pay_val = 3 then nvl(replace(case when d.cond_id = 'cnd.20.1.2' then REGEXP_SUBSTR(d.cond_fun, '[^,]+', 1, 3) else null end, ''''), to_char(v_si)) END) dental_limit, 
             max(case when d.cond_id = 'cnd.11.1.2' and c.coverage_pay_val = 1 then to_char(v_si) when d.cond_id = 'cnd.11.1.2' and c.coverage_pay_val = 3 then nvl(replace(case when d.cond_id = 'cnd.11.1.2' then REGEXP_SUBSTR(d.cond_fun, '[^,]+', 1, 3) else null end, ''''), to_char(v_si)) END) Optical_limit,
             nvl(max(case when d.cond_id = 'cnd.18.1.8' and c.coverage_pay_val = 3 then nvl(replace(case when d.cond_id = 'cnd.18.1.8' then REGEXP_SUBSTR(d.cond_fun, '[^,]+', 1, 27) else null end, ''''), '0')end ),'0') as Maternity_flag,
             nvl(max(case when d.cond_id = 'cnd.20.1.2' and c.coverage_pay_val = 3 then nvl(replace(case when d.cond_id = 'cnd.20.1.2' then replace(REGEXP_SUBSTR(d.cond_fun, '[^,]+', 1, 10),')') else null end, ''''), '0') end ),'0') as dental_flag,
             nvl(max(case when d.cond_id = 'cnd.11.1.2' and c.coverage_pay_val = 3 then nvl(replace(case when d.cond_id = 'cnd.11.1.2' then replace(REGEXP_SUBSTR(d.cond_fun, '[^,]+', 1, 10),')') else null end, ''''), '0') end ),'0') as Optical_flag,
             nvl(max(case when d.cond_id = 'cnd.18.1.8' then  c.coverage_pay_val else 0 end) ,  '0') maternity_coverage,
             nvl(max(case when d.cond_id = 'cnd.20.1.2' then c.coverage_pay_val else 0  end), '0') dental_coverage, 
             nvl(max(case when d.cond_id = 'cnd.11.1.2' then c.coverage_pay_val else 0 end), '0') Optical_coverage,
             
             max(CASE when d.cond_id = 'cnd.19.3.1' and c.coverage_pay_val = 3 THEN REPLACE(REGEXP_SUBSTR(d.cond_fun, '[^,]+', 1, 3), '''') END) pharma_limit,
             max(CASE when d.cond_id = 'cnd.19.3.1' and c.coverage_pay_val = 3 THEN REPLACE(REGEXP_SUBSTR(d.cond_fun, '[^,]+', 1, 7), '''') END) maxpharma_limit,
             max(case when d.cond_id = 'cnd.19.3.1' and c.coverage_pay_val = 3 THEN REPLACE(REGEXP_SUBSTR(d.cond_fun, '[^,]+', 1, 8), '''')end )AS pharma_flag,
             nvl(max(case when d.cond_id = 'cnd.19.3.1' then c.coverage_pay_val else 0 end), '0') pharma_coverage,
             max(CASE when d.cond_id = 'cnd.19.8.1' and c.coverage_pay_val = 3 THEN REPLACE(REGEXP_SUBSTR(d.cond_fun, '[^,]+', 1, 3), '''') END) op_limit,
             max(case when d.cond_id = 'cnd.19.8.1' and c.coverage_pay_val = 3 THEN replace(REPLACE(REGEXP_SUBSTR(d.cond_fun, '[^,]+', 1, 10), ''''),')')end )AS op_flag,
             nvl(max(case when d.cond_id = 'cnd.19.8.1' then c.coverage_pay_val else 0 end), '0') op_coverage
             
      FROM app.tpa_enr_policy tep
      left join app.tpa_ins_prod_policy tipp ON (tep.policy_seq_id = tipp.policy_seq_id)
      join app.tpa_ins_prod_policy_rules tippr on (tippr.prod_policy_seq_id = tipp.prod_policy_seq_id)
      join app.tpa_ins_prod_pol_clauses B on (b.prod_policy_rule_seq_id = tippr.prod_policy_rule_seq_id)
      JOIN app.tpa_ins_prod_pol_coverages C ON (B.clause_seq_id = c.clause_seq_id)
      JOIN app.tpa_ins_prod_pol_conditions d ON (c.coverage_seq_id = d.coverage_seq_id)
     
     WHERE  d.cond_id in ('cnd.11.1.2','cnd.20.1.2','cnd.27.1.1','cnd.18.1.8','cnd.19.3.1','cnd.19.8.1') 
     and tippr.prod_policy_rule_seq_id=v_seq
     group by tep.policy_seq_id ;

CURSOR curr_mem_si IS
  select tem.mem_tot_sum_insured,
         CASE WHEN v_benefit_type = 'DNTL' THEN pp.dntl_buffer_limit
              WHEN v_benefit_type = 'OPTC' THEN pp.optc_buffer_limit
              WHEN v_benefit_type = 'OPTS' THEN nvl(pp.opts_pharma_buffer_limit,pp.opts_buffer_limit) 
              WHEN v_benefit_type = 'OMTI' THEN pp.omti_buffer_limit
         END AS buffer_limit
                
  from app.tpa_enr_policy tep
  join app.tpa_enr_policy_group teg on (tep.policy_seq_id = teg.policy_seq_id) 
  join app.tpa_enr_policy_member tem on(teg.policy_group_seq_id = tem.policy_group_seq_id)
  JOIN tpa_ins_prod_policy pp ON (pp.policy_seq_id = tep.policy_seq_id)
  where  (tem.tpa_enrollment_id=v_tpa_enrollment_id or tem.emirate_id=v_tpa_enrollment_id)
  and sysdate between tep.effective_from_date and tep.effective_to_date+1;
v_mem_rec   curr_mem_si%ROWTYPE;
   
 benefit_limit_rec   get_benefit_limit_cur%rowtype;
 v_prod_policy_rule_seq_id       tpa_ins_prod_policy_rules.prod_policy_rule_seq_id%type:=null;
 v_ava_limit   number:=0;
 --v_mem_si  number:=0;
 v_limit_flag       VARCHAR2(5);
BEGIN
  
  --delete from test_claim;commit;
  --insert into test_claim(claim_number) values(v_tpa_enrollment_id||'@'||v_benefit_type); commit;
    
  open enroll_type_cur;
  fetch enroll_type_cur into v_enroll_type;
  close enroll_type_cur;

  open curr_mem_si;
  fetch curr_mem_si into v_mem_rec;
  close curr_mem_si;

  OPEN CR_BENEFIT_YA(v_enroll_type.policy_seq_id);
  FETCH CR_BENEFIT_YA INTO LV_CR_BENEFIT_YA;
  CLOSE CR_BENEFIT_YA;

  IF LV_CR_BENEFIT_YA.CNT > 0 THEN
   open  Eligible_benifits;
   fetch Eligible_benifits into v_hosp_ben;
   close Eligible_benifits;
  END IF;

  open PREVIOUS_POLICY_NUMBER(v_enroll_type.policy_seq_id);
  fetch PREVIOUS_POLICY_NUMBER into v_policy_number;
  close PREVIOUS_POLICY_NUMBER;

  IF v_enroll_type.cnt > 1 then
    raise_application_error (-20402, 'More than one Values Returning');
  END IF;
  v_prod_policy_rule_seq_id:=intx.authorization_pkg.get_prod_pol_seq_id(v_enroll_type.policy_seq_id,'POL');


  open get_benefit_limit_cur(v_prod_policy_rule_seq_id,v_mem_rec.mem_tot_sum_insured);
  fetch get_benefit_limit_cur into benefit_limit_rec;
  close get_benefit_limit_cur;

  select hi.primary_network into v_provider_network from tpa_hosp_info hi where hosp_seq_id = v_hosp_seq_id;
  select case when v_benefit_type = 'IPT' then 'In-Patient'
              when v_benefit_type = 'OPTS'  then 'Out-Patient' 
              when v_benefit_type = 'OPTC'  then 'Optical'
              when v_benefit_type ='IMTI' then 'In-Patient Maternity'
              when v_benefit_type ='OMTI' then 'Out-Patient Maternity'
              when v_benefit_type = 'DNTL'  then 'Dental' 
              when v_benefit_type = 'HEAC'  then 'Health Check Up' 
              when v_benefit_type = 'DAYC'  then 'Daycare' 
          end as v_benefit_type into benefit_type from dual; 


  IF v_benefit_type='OPTS'  THEN
    v_limit_flag:=benefit_limit_rec.pharma_flag;
    IF nvl(benefit_limit_rec.pharma_flag,'NA')!='PC' and nvl(benefit_limit_rec.pharma_coverage,0)!=2  THEN 
      open  oplimit_cur(v_enroll_type.policy_seq_id);
      fetch oplimit_cur into v_limit;
      close oplimit_cur;
    END IF;
     v_ava_limit:= coalesce(least(coalesce(benefit_limit_rec.pharma_limit,benefit_limit_rec.maxpharma_limit),coalesce(benefit_limit_rec.maxpharma_limit,benefit_limit_rec.pharma_limit)),benefit_limit_rec.op_limit,v_mem_rec.mem_tot_sum_insured)-nvl(v_limit,0);
     
  ELSIF v_benefit_type='OPTC'  THEN 
    v_limit_flag:=coalesce(benefit_limit_rec.pharma_flag,benefit_limit_rec.op_flag,'NA');
    IF coalesce(benefit_limit_rec.pharma_flag,benefit_limit_rec.op_flag,'NA')!='PC' and nvl(benefit_limit_rec.optical_coverage,0)!=2  THEN 
      open Optical_limit_cur(v_enroll_type.policy_seq_id);
      fetch Optical_limit_cur into v_limit;
      close Optical_limit_cur;
     END IF;
     v_ava_limit:= benefit_limit_rec.optical_limit-nvl(v_limit,0);
      
  ELSIF v_benefit_type='DNTL'  THEN
    v_limit_flag:=benefit_limit_rec.dental_flag;
    IF nvl(benefit_limit_rec.dental_flag,'NA')!='PC' and nvl(benefit_limit_rec.dental_coverage,0)!=2 THEN 
      open dental_limit_cur(v_enroll_type.policy_seq_id);
      fetch dental_limit_cur into v_limit;
      close dental_limit_cur;
     END IF; 
     v_ava_limit:= benefit_limit_rec.dental_limit-nvl(v_limit,0);
   
  ELSIF v_benefit_type = 'OMTI'   THEN
    v_limit_flag:=benefit_limit_rec.maternity_flag;
    IF nvl(benefit_limit_rec.maternity_flag,'NA')!='PC' and nvl(benefit_limit_rec.maternity_coverage,0)!=2  THEN 
      open maternity_Iplimit_cur(v_enroll_type.policy_seq_id);
      fetch maternity_Iplimit_cur into v_limit;
      close maternity_Iplimit_cur;
    END IF;
     v_ava_limit:= benefit_limit_rec.maternity_limit-(nvl(v_limit,0));

  END IF;

  IF  v_ava_limit IS NOT NULL AND v_benefit_type in ('OMTI','IMTI','DNTL','OPTC','OPTS')then
     --raise_application_error (-20967, 'Patient Eligible for availing '|| case when v_benefit_type='IMTI' then 'IP Maternity' when v_benefit_type='OMTI' then 'OP Maternity' else benefit_type end||' Benefit :'||' No.Benefit limit is exhausted');
     v_warning := CASE WHEN nvl(v_ava_limit,0) <=0 THEN
                            'Patient is not eligible for availing '||benefit_type|| ' benefit as the ' ||benefit_type|| ' limit is fully exhausted'
                       WHEN nvl(v_ava_limit,0)< v_mem_rec.buffer_limit AND v_limit_flag ='PP' THEN 
                            'Please take the prior approval as there is only minimal balance limit available for '||benefit_type
                       ELSE NULL END;
                      
  END IF;
 

  IF v_enroll_type.enrol_type_id = 'COR' THEN
    OPEN v_result_set FOR
       SELECT hi.primary_network,
              c.tpa_enrollment_id,
              c.emirate_id,
              c.member_seq_id,
              c.mem_name,
              b.insured_name,
              c.mem_age,
              c.mem_dob,
              decode(c.gender_general_type_id,'MAL','MALE','FEMALE') as gender,
              d.ins_comp_name as payer_name,
              d.ins_seq_id,
              nvl(v_warning,
              case when v_hosp_ben is null then
             --case when ','||v_hosp_ben||',' like '%,'||v_benefit_type||',%' THEN 
                case when v_benefit_type IN ('IMTI', 'OMTI') and h.eligible_yn='Y' and nvl(v_ava_limit,0)>0 then 
                  case when (c.gender_general_type_id='FEM' and nvl(c.marital_status_id,'SNG')='MRD' and c.relship_type_id in ('NSF','YSP')) then --changed in CR-0180 & CR-0182 
                       'YES' 
                  else 
                       'NO'
                  end 
                else 
                  case when h.eligible_yn='Y' and v_benefit_type NOT IN ('IPT', 'OPTS') and nvl(v_ava_limit,0)>0 then 'YES' 
                       when h.eligible_yn='Y' and v_benefit_type  IN ('IPT', 'OPTS') THEN 'YES'
                  else 
                       'NO'
                  end
                end
              ELSE
               case when ','||v_hosp_ben||',' like '%,'||v_benefit_type||',%' THEN 
                case when v_benefit_type IN ('IMTI', 'OMTI') and h.eligible_yn='Y' then 
                 case when (c.gender_general_type_id='FEM' and nvl(c.marital_status_id,'SNG')='MRD' and c.relship_type_id in ('NSF','YSP')) then --changed in Cr-0180 & CR-0182
                      'YES' 
                 else 
                      'NO'
                 end 
                else 
                 case when h.eligible_yn='Y' and v_benefit_type NOT IN ('IPT', 'OPTS') and nvl(v_ava_limit,0)>0 then 'YES' 
                      when h.eligible_yn='Y' and v_benefit_type  IN ('IPT', 'OPTS') THEN 'YES'
                 else 
                   'NO'
                 end
                end
               ELSE 'NO'
               end 
              END) as eligibility,
              '' as deductible,
              h.copay_perc as co_participation,
              --null as applicable_procedure,
              '-' as exclusions,
              h.authorization_req_yn,
              i.pat_intimation_id,
              tip.product_cat_type_id as productType,
              --null as tob
              case when nvl(c.vip_yn,'N') = 'Y' then nvl(to_char(f.vip_pre_aprvl_limit),'Nil')
                   when nvl(c.vip_yn,'N') = 'N' then nvl(to_char(f.non_vip_pre_aprvl_limit),'Nil') end as pre_apprvl_limit,
              case when nvl(h.eligible_yn,'N')='N' or ((c.gender_general_type_id='MAL' or nvl(c.marital_status_id,'SNG')!='MRD'or c.relship_type_id not in ('NSF','YSP')) and v_benefit_type IN ('IMTI', 'OMTI')) THEN 'Member is not eligible for this Benefit type. ' else null end ||    
              case when hi.primary_network != v_provider_network THEN 'Member is not eligible for this Network type. ' else null end||
              case when v_hosp_ben is not null then
                case when ','||v_hosp_ben||',' like ',%'||v_benefit_type||',%' then NULL else 'Provider is not covered for given Benifit type' end end
                as elig_denial_reason,
              hi.hosp_name,hi.off_phone_no_1,hi.office_fax_no,hi.hosp_licenc_numb,hi.std_code,
              a.policy_number as policy_no,
              to_char(a.effective_from_date, 'DD/MM/RRRR') as policy_st_dt,
              to_char(a.effective_to_date, 'DD/MM/RRRR') as policy_en_dt,
              NVL(v_policy_number,'-') as INITIAL_POLICY_NO,
              case when a.opts_pat_limit is not null and hi.opts_pat_limit is not null then least(a.opts_pat_limit,hi.opts_pat_limit)
              else coalesce(a.opts_pat_limit,hi.opts_pat_limit) end as opts_pat_limit,
              CASE WHEN c.date_of_inception<a.effective_from_date THEN to_char(a.effective_from_date, 'DD/MM/RRRR') ELSE to_char(c.date_of_inception, 'DD/MM/RRRR') END as member_st_dt,
              to_char(c.date_of_exit, 'DD/MM/RRRR') as member_en_dt,
              CASE WHEN NVL(c.renew_yn,'N') = 'Y' and renc.tpa_enrollment_id is not null THEN to_char(ren.effective_from_date,'dd-mm-yyyy') ELSE 'NA' END as Renew_Policy_Start_date,
              CASE WHEN NVL(c.renew_yn,'N') = 'Y' and renc.tpa_enrollment_id is not null THEN to_char(ren.effective_to_date,'dd-mm-yyyy') ELSE 'NA' END as Renew_Policy_End_date  
            
       FROM tpa_enr_policy a join tpa_enr_policy_group b ON (a.policy_seq_id=b.policy_seq_id)
       JOIN tpa_enr_policy_member c on (b.policy_group_seq_id=c.policy_group_seq_id)
       LEFT OUTER JOIN tpa_ins_info d on (d.ins_seq_id=a.ins_seq_id)
       LEFT OUTER JOIN tpa_ins_product e on (a.product_seq_id=e.product_seq_id)
       LEFT OUTER JOIN tpa_ins_prod_policy f ON (a.policy_seq_id=f.policy_seq_id)
       LEFT OUTER JOIN tpa_ins_prod_policy_rules g on (g.prod_policy_seq_id=f.prod_policy_seq_id)
       LEFT OUTER JOIN tpa_ins_prod_pol_benefits h on (h.prod_policy_rule_seq_id=g.prod_policy_rule_seq_id and upper(h.benefit_name) = upper(CASE WHEN v_benefit_type IN ('IMTI', 'OMTI') THEN 'Maternity' ELSE benefit_type END))
       left outer join pat_intimation_details i on (i.member_seq_id=c.member_seq_id)
       left outer join prov_payer_association pp on (d.ins_seq_id = pp.ins_seq_id)
       left join tpa_ins_product tip on (a.product_seq_id = tip.product_seq_id)
       left outer join tpa_hosp_info hi on (pp.hosp_seq_id = hi.hosp_seq_id)
       left outer join tpa_enr_policy ren on (ren.prev_policy_seq_id = a.policy_seq_id)
       left outer join tpa_enr_policy_group renb ON (ren.policy_seq_id=renb.policy_seq_id)
       left outer JOIN tpa_enr_policy_member renc on (renb.policy_group_seq_id=renc.policy_group_seq_id and renc.tpa_enrollment_id=v_tpa_enrollment_id)
       where (c.tpa_enrollment_id=v_tpa_enrollment_id or c.emirate_id=v_tpa_enrollment_id) --emirate_id validation added in cr0218
         and sysdate between a.effective_from_date and a.effective_to_date+1
        and hi.hosp_seq_id=v_hosp_seq_id order by a.policy_seq_id desc;
   ELSIF v_enroll_type.enrol_type_id != 'COR' THEN
   OPEN v_result_set FOR
       SELECT hi.primary_network,
              c.tpa_enrollment_id,
              c.member_seq_id,
              c.mem_name,
              b.insured_name,
              c.mem_age,
              c.mem_dob,
              decode(c.gender_general_type_id,'MAL','MALE','FEMALE') as gender,
              d.ins_comp_name as payer_name,
              d.ins_seq_id,
              case when v_benefit_type IN ('IMTI', 'OMTI') and h.eligible_yn='Y' and nvl(v_ava_limit,0)>0 then case when (c.gender_general_type_id='FEM' and nvl(c.marital_status_id,'SNG')='MRD' and c.relship_type_id in ('NSF','YSP')) then 'Y' else 'N' end  
                  else 
                    case when h.eligible_yn='Y' and v_benefit_type NOT IN ('IPT', 'OPTS') and nvl(v_ava_limit,0)>0 then 'YES' 
                      when h.eligible_yn='Y' and v_benefit_type  IN ('IPT', 'OPTS') THEN 'YES' 
                      else 'NO' end 
                        end as eligibility,
              '-' as deductible,
              h.copay_perc as co_participation,
              --null as applicable_procedure,
              '-' as exclusions,
              h.authorization_req_yn,
              i.pat_intimation_id,
              tip.product_cat_type_id as productType,
              case when c.vip_yn = 'Y' then f.vip_pre_aprvl_limit
                   when c.vip_yn = 'N' then f.non_vip_pre_aprvl_limit end as pre_apprvl_limit,
              --null as tob
              case when nvl(h.eligible_yn,'N')='N' or (v_benefit_type IN ('MTI', 'OMTI', 'IMTI') and c.gender_general_type_id!='FEM' or nvl(c.marital_status_id,'SNG')!='MRD' or c.relship_type_id not in ('NSF','YSP')) THEN 'member is not eligible for this benefit type ' else null end ||   --changed in CR-0180 & CR-0182
               case when hi.primary_network != v_provider_network THEN 'member is not eligible for this network type ' else null end as elig_denial_reason     
              , NULL as INITIAL_POLICY_NO ,
              case when a.opts_pat_limit is not null and hi.opts_pat_limit is not null then least(a.opts_pat_limit,hi.opts_pat_limit)
              else coalesce(a.opts_pat_limit,hi.opts_pat_limit) end as opts_pat_limit,
              CASE WHEN c.date_of_inception<a.effective_from_date THEN to_char(a.effective_from_date, 'DD/MM/RRRR') ELSE to_char(c.date_of_inception, 'DD/MM/RRRR') END as member_st_dt,
              to_char(c.date_of_exit, 'DD/MM/RRRR') as member_en_dt,
              CASE WHEN NVL(c.renew_yn,'N') = 'Y' THEN to_char(ren.effective_from_date,'dd-mm-yyyy') ELSE 'NA' END as Renew_Policy_Start_date,
              CASE WHEN NVL(c.renew_yn,'N') = 'Y' THEN to_char(ren.effective_to_date,'dd-mm-yyyy') ELSE 'NA' END as Renew_Policy_End_date
       FROM tpa_enr_policy a join tpa_enr_policy_group b ON (a.policy_seq_id=b.policy_seq_id)
       JOIN tpa_enr_policy_member c on (b.policy_group_seq_id=c.policy_group_seq_id)
       LEFT OUTER JOIN tpa_ins_info d on (d.ins_seq_id=a.ins_seq_id)
       LEFT OUTER JOIN tpa_ins_product e on (a.product_seq_id=e.product_seq_id)
       LEFT OUTER JOIN tpa_ins_prod_policy f ON (e.product_seq_id=f.product_seq_id)
       LEFT OUTER JOIN tpa_ins_prod_policy_rules g on (g.prod_policy_seq_id=f.prod_policy_seq_id)
       LEFT OUTER JOIN tpa_ins_prod_pol_benefits h on (h.prod_policy_rule_seq_id=g.prod_policy_rule_seq_id and h.benefit_name = CASE WHEN v_benefit_type IN ('IMTI', 'OMTI') THEN 'Maternity' ELSE benefit_type END)
       left outer join pat_intimation_details i on (i.member_seq_id=c.member_seq_id)
       left outer join prov_payer_association pp on (d.ins_seq_id = pp.ins_seq_id)
       left join tpa_ins_product tip on (a.product_seq_id = tip.product_seq_id)
       left outer join tpa_hosp_info hi on (pp.hosp_seq_id = hi.hosp_seq_id)
       left outer join tpa_enr_policy ren on (ren.prev_policy_seq_id = a.policy_seq_id)
       where (c.tpa_enrollment_id=v_tpa_enrollment_id or c.emirate_id=v_tpa_enrollment_id) and hi.hosp_seq_id=v_hosp_seq_id ;

   END IF;
/*      OPEN v_network_check FOR 
       select hn.network_type, hn.network_yn
        from app.tpa_hosp_network hn,app.tpa_general_code gc
       where gc.general_type_id=hn.network_type and hn.hosp_seq_id = v_hosp_seq_id
       order by gc.sort_no;*/
  
 END get_mem_benifit_details;
--====================================================================================================
PROCEDURE check_mat_fda_risk_rule(v_seq_id   IN pat_authorization_details.pat_auth_seq_id%TYPE,
                                  v_mode     IN VARCHAR2,
                                  v_added_by IN NUMBER) 
IS
 CURSOR pat_mat_fda_risk_cur IS SELECT b.activity_dtl_seq_id,case when fda_maternity_drug IN ('NOT AVAILABLE','C') then 'REV-MAN'
                                                                  when fda_maternity_drug IN ('D','X') then 'MATCON-001' end as denial_code,
                                                             case when fda_maternity_drug IN ('NOT AVAILABLE','C') then 'To be manually reviewed'
                                                                  when fda_maternity_drug IN ('D','X') then 'Drug contraindicated in maternity' end as denial_desc
                                        FROM app.tpa_pharmacy_master_details a join app.pat_activity_details b on (a.activity_code = b.code)
                                              join app.diagnosys_details c on (c.pat_auth_seq_id = b.pat_auth_seq_id)
                                              join app.tpa_icd_codes d on (c.diagnosys_code = d.icd_code) 
                                       where b.pat_auth_seq_id = v_seq_id and
                                             a.fda_maternity_drug is not null and
                                             d.mat_fda_yn = 'Y';
                                             
 CURSOR clm_mat_fda_risk_cur IS SELECT distinct b.activity_dtl_seq_id,case when fda_maternity_drug IN ('NOT AVAILABLE','C') then 'REV-MAN'
                                                                           when fda_maternity_drug IN ('D','X') then 'MATCON-001' end as denial_code,
                                                                      case when fda_maternity_drug IN ('NOT AVAILABLE','C') then 'To be manually reviewed'
                                                                           when fda_maternity_drug IN ('D','X') then 'Drug contraindicated in maternity' end as denial_desc
                                        FROM app.tpa_pharmacy_master_details a join app.pat_activity_details b on (a.activity_code = b.code)
                                              join app.diagnosys_details c on (c.claim_seq_id = b.claim_seq_id)
                                              join app.tpa_icd_codes d on (c.diagnosys_code = d.icd_code) 
                                       where b.claim_seq_id = v_seq_id and
                                             a.fda_maternity_drug is not null and
                                             d.mat_fda_yn = 'Y';                                            
BEGIN
  
  IF v_mode = 'PAT' THEN
    
     FOR i in pat_mat_fda_risk_cur LOOP
            UPDATE pat_activity_details pad
             SET pad.denial_code                 = case when pad.denial_code is null then i.denial_code else case when pad.denial_code like '%'||i.denial_code||'%' then pad.denial_code else pad.denial_code||';'||i.denial_code end end,
                 pad.denial_desc                 = case when pad.denial_desc is null then i.denial_desc else case when pad.denial_code like '%'||i.denial_code||'%' then pad.denial_desc else pad.denial_desc||';'||i.denial_desc end end,
                 pad.remarks                     = case when pad.remarks is null then i.denial_desc else case when pad.denial_code like '%'||i.denial_code||'%' then pad.denial_desc else pad.denial_desc||';'||i.denial_desc end end,
                 pad.tpa_denial_code             = case when pad.tpa_denial_code is null then i.denial_code else case when pad.tpa_denial_code like '%'||i.denial_code||'%' then pad.tpa_denial_code else pad.tpa_denial_code||';'||i.denial_code end end,
                 pad.tpa_denial_desc             = case when pad.tpa_denial_desc is null then i.denial_desc else case when pad.tpa_denial_code like '%'||i.denial_code||'%' then pad.tpa_denial_desc else pad.tpa_denial_desc||';'||i.denial_desc end end,
                 pad.updated_by                  = v_added_by,
                 pad.updated_date                = SYSDATE,
                 pad.denial_by_rule_proc_dtls    = TRIM(BOTH ';' FROM (pad.denial_by_rule_proc_dtls||';'||CHR(10)||'hosp_pbm_pkg.check_mat_fda_risk_rule')),
                 pad.denial_by_resons            = TRIM(BOTH ';' FROM (pad.denial_by_resons||';'||CHR(10)||'ICD and DDC combination not allowed based FDA Pregenancy risk categories.'))
          WHERE pad.activity_dtl_seq_id = i.activity_dtl_seq_id
            and nvl(pad.override_yn,'N')='N';    
     END LOOP;  
         
  ELSIF v_mode = 'CLM' THEN
    
    FOR i in clm_mat_fda_risk_cur LOOP
           UPDATE pat_activity_details pad
             SET pad.denial_code                 = case when pad.denial_code is null then i.denial_code else case when pad.denial_code like '%'||i.denial_code||'%' then pad.denial_code else pad.denial_code||';'||i.denial_code end end,
                 pad.denial_desc                 = case when pad.denial_desc is null then i.denial_desc else case when pad.denial_code like '%'||i.denial_code||'%' then pad.denial_desc else pad.denial_desc||';'||i.denial_desc end end,
                 pad.remarks                     = case when pad.remarks is null then i.denial_desc else case when pad.denial_code like '%'||i.denial_code||'%' then pad.denial_desc else pad.denial_desc||';'||i.denial_desc end end,
                 pad.tpa_denial_code             = case when pad.tpa_denial_code is null then i.denial_code else case when pad.tpa_denial_code like '%'||i.denial_code||'%' then pad.tpa_denial_code else pad.tpa_denial_code||';'||i.denial_code end end,
                 pad.tpa_denial_desc             = case when pad.tpa_denial_desc is null then i.denial_desc else case when pad.tpa_denial_code like '%'||i.denial_code||'%' then pad.tpa_denial_desc else pad.tpa_denial_desc||';'||i.denial_desc end end,
                 pad.updated_by                  = v_added_by,
                 pad.updated_date                = SYSDATE,
                 pad.denial_by_rule_proc_dtls    = TRIM(BOTH ';' FROM (pad.denial_by_rule_proc_dtls||';'||CHR(10)||'hosp_pbm_pkg.check_mat_fda_risk_rule')),
                 pad.denial_by_resons            = TRIM(BOTH ';' FROM (pad.denial_by_resons||';'||CHR(10)||'ICD and DDC combination not allowed based FDA Pregenancy risk categories.'))
          WHERE pad.activity_dtl_seq_id = i.activity_dtl_seq_id
            and nvl(pad.override_yn,'N')='N';    
                
          END LOOP;      
  END IF;
  
 END check_mat_fda_risk_rule; 
--====================================================================================================

END hosp_pbm_pkg;

/

--------------------------------------------------------
--  DDL for Synonymn HOSPITAL_ADMIN_TARIFF_PKG
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."HOSPITAL_ADMIN_TARIFF_PKG" FOR "APP"."HOSPITAL_ADMIN_TARIFF_PKG";

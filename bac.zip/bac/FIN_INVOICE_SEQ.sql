--------------------------------------------------------
--  DDL for Synonymn FIN_INVOICE_SEQ
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."FIN_INVOICE_SEQ" FOR "FIN_APP"."FIN_INVOICE_SEQ";

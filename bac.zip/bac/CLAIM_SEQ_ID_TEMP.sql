--------------------------------------------------------
--  DDL for Synonymn CLAIM_SEQ_ID_TEMP
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."CLAIM_SEQ_ID_TEMP" FOR "APP"."CLAIM_SEQ_ID_TEMP";

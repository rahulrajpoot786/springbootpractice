--------------------------------------------------------
--  DDL for Package Body HOSPITAL_PKG
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "VENUBABU"."HOSPITAL_PKG" 
is

PROCEDURE create_preauth_xml (
    v_pat_gen_detail_seq_id                 IN  pat_general_details.pat_gen_detail_seq_id%TYPE,
    v_hosp_seq_id                           IN Tpa_Hosp_Info.Hosp_Seq_Id%type,
    v_preauth_history_doc                   OUT XMLTYPE
   )
   IS
     CURSOR preauth_cur IS
       SELECT
         B.pre_auth_number,
         D.description AS preauth_type,
         to_char(A.pat_received_date,'dd/mm/yyyy hh:mi AM') AS pat_received_date ,
         to_char(A.likely_date_of_hospitalization ,'dd/mm/yyyy hh:mi AM')  AS likely_date_of_hospitalization,
         A.prev_approved_amount ,
         A.pat_requested_amount ,
         A.treating_dr_name ,
         E.office_name,
         A.remarks ,
         G.tpa_enrollment_id,
         G.mem_name ,
         B.policy_number,
         I.ins_comp_name,
         J.product_name,
         B.insured_name,
         B.Phone_1,
         a.phone_no_in_hospitalisation ,
         k.description AS ins_term_status,
         L.enrol_description,
         M.Description AS policy_sub_type,
         TO_CHAR(b.policy_effective_from ,'DD/MM/YYYY') AS policy_effective_from,
         TO_CHAR(b.policy_effective_to ,'DD/MM/YYYY') AS policy_effective_to,
         TO_CHAR(F.ACTUAL_POLICY_START_DATE ,'DD/MM/YYYY') AS actual_policy_effective_from,  --policy renewal
         TO_CHAR(F.ACTUAL_POLICY_END_DATE ,'DD/MM/YYYY') AS actual_policy_effective_to,   --policy renwal
        -- pre_auth_pkg.get_available_sum(a.pat_gen_detail_seq_id,NULL,'SUM') AS  ava_sum_insured,
         --pre_auth_pkg.get_available_sum(a.pat_gen_detail_seq_id,NULL,'BONUS') AS ava_cum_bonus,

         NN2.pre_auth_buffer_app_amount AS buffer_ava_amount,

         A.app_cum_bonus ,
         NN2.pre_auth_buffer_app_amount AS buffer_app_amount ,
         to_char(N.buffer_approved_date ,'dd/mm/yyyy hh:mi AM') AS buffer_approved_date,
         O.hosp_name,
         O.rating ,
         O.empanel_number,
         Q.city_description,
         R.state_name,
         B.auth_number,
         b.mem_total_sum_insured ,
         A.total_app_amount,
       case A.COMPLETED_YN when 'Y' THEN v.description
       else case b.Pat_Status_General_Type_Id
       when 'APR' then 'In-Progress'
       when 'REJ' then 'In-Progress'
       when 'PCN' then 'In-Progress'
       else V.description end end AS app_status,
         to_char( B.decision_date ,'dd/mm/yyyy hh:mi AM') AS completed_date ,
         W.contact_name,
         a.authorization_remarks AS app_remarks,
         X.description AS reason ,
         AN.provisional_diagnosis ,
         A.Pat_Enhanced_Yn ,
         a.likely_date_of_hospitalization + nvl(an.duration_of_hospitalization,0) AS probable_date_of_discharge,
         ev.event_name,
         (SELECT COUNT(1) FROM shortfall_details ss WHERE ss.pat_gen_detail_seq_id = a.pat_gen_detail_seq_id ) AS shortfall_count,
         CASE WHEN a.parent_gen_detail_seq_id IS NOT NULL THEN 'Yes' ELSE 'No' END AS Enhanced_Yn,
         DECODE(G.diabetes_cover_yn ,'Y','Yes','No') AS diabetes_cover_yn, --For KOC1010
         DECODE(G.hypertension_cover_yn ,'Y','Yes','No') AS hypertension_cover_yn, --For KOC1010
         F.zone_code ,
         A.COMPLETED_YN,
          case A.COMPLETED_YN when 'Y' THEN v.description
       else case b.Pat_Status_General_Type_Id
       when 'APR' then 'INP'
       when 'REJ' then 'INP'
       when 'PCN' then 'INP'
       else V.description end end as status_type,
         a.pat_gen_detail_seq_id as seqid    ,
         i.notify_type_id as auth_type_id ,
         CASE WHEN i.ins_comp_name like 'CIGNA%' THEN 'Y' ELSE 'N' END AS CIGNA_YN
         FROM pat_general_details A JOIN pat_enroll_details B ON (A.pat_enroll_detail_seq_id = b.pat_enroll_detail_seq_id AND A.PAT_ENHANCED_YN='N')
         LEFT OUTER JOIN tpa_general_code D ON (A.pat_general_type_id = D.general_type_id)
         LEFT OUTER JOIN tpa_office_info E ON (b.tpa_office_seq_id = e.tpa_office_seq_id)
         LEFT OUTER JOIN tpa_enr_policy F ON (B.policy_seq_id=F.policy_seq_id) --For KOC1010
         LEFT OUTER JOIN tpa_enr_policy_member G ON (B.member_seq_id = G.member_seq_id)
         LEFT OUTER JOIN tpa_ins_info I ON (B.ins_seq_id = I.ins_seq_id)
         LEFT OUTER JOIN tpa_ins_product J ON (B.product_seq_id = J.product_seq_id)
         LEFT OUTER JOIN tpa_general_code K ON (b.ins_status_general_type_id = k.general_type_id)
         LEFT OUTER JOIN tpa_enrolment_type_code L ON (b.enrol_type_id = L.enrol_type_id)
         LEFT OUTER JOIN tpa_general_code M ON (b.policy_sub_general_type_id = M.general_type_id)
         LEFT OUTER JOIN buffer_details N ON (a.last_buffer_detail_seq_id = N.buff_detail_seq_id )
         LEFT OUTER JOIN buffer_header NN2 ON ( N.buffer_hdr_seq_id  = NN2.buffer_hdr_seq_id )
         LEFT OUTER JOIN tpa_hosp_info O ON (B.hosp_seq_id = O.hosp_seq_id)
         LEFT OUTER JOIN tpa_hosp_address P ON (O.hosp_seq_id = P.hosp_seq_id)
         LEFT OUTER JOIN tpa_city_code Q ON (P.city_type_id = Q.city_type_id)
         LEFT OUTER JOIN tpa_state_code R ON (P.state_type_id = R.state_type_id)
         LEFT OUTER JOIN assign_users T ON (a.last_assign_user_seq_id = T.assign_users_seq_id)
         LEFT OUTER JOIN tpa_general_code V ON (B.pat_status_general_type_id = V.general_type_id)
         LEFT OUTER JOIN tpa_user_contacts W ON (T.assigned_to_user = W.contact_seq_id)
         LEFT OUTER JOIN tpa_general_code X ON (B.rson_general_type_id = X.general_type_id)
         LEFT OUTER JOIN ailment_details AN ON (A.pat_gen_detail_seq_id = AN.pat_gen_detail_seq_id)
         LEFT OUTER JOIN tpa_event ev ON (A.event_seq_id = ev.event_seq_id)
         LEFT OUTER JOIN tpa_enr_balance bl ON (g.policy_group_seq_id = bl.policy_group_seq_id)

         WHERE A.pat_gen_detail_seq_id = v_pat_gen_detail_seq_id and b.hosp_seq_id=v_hosp_seq_id;

    CURSOR icd_pcs_cur IS SELECT
      A.icd_pcs_seq_id,
      A.ped_code_id,
      NVL(c.ped_description,'Others - '||A.other_desc) AS ailment_desc ,
      A.icd_code,
      A.primary_ailment_yn,
      NULL AS pkg_rate ,
      G.maximum_allowed_amount AS validated_amt,
      G.approved_amount AS itemized_app_amount,
      D.proc_seq_id,
      D.pkg_seq_id,
      a.hospital_general_type_id ,
      H.description AS hospitalization_type ,
      A.frequency_of_visit ,
      A.no_of_visits ,
      DECODE (a.pat_duration_general_type_id,'DTD','Days','DTW','Weeks','DTM','Months','Years') AS duration,
      NVL(E.NAME ,F.proc_description) AS NAME
      FROM icd_pcs_detail A LEFT OUTER JOIN tpa_ped_code C ON (A.ped_code_id = C.ped_code_id)
      LEFT OUTER JOIN pat_package_procedures D ON ( A.icd_pcs_seq_id = D.icd_pcs_seq_id )
      LEFT OUTER JOIN tpa_hosp_tariff_item E ON (d.pkg_seq_id = e.pkg_seq_id)
      LEFT OUTER JOIN tpa_hosp_procedure_code F ON (D.proc_seq_id = F.proc_seq_id)
      LEFT OUTER JOIN ailment_caps G ON ( a.icd_pcs_seq_id = G.icd_pcs_seq_id )
      LEFT OUTER JOIN tpa_general_code H ON (a.hospital_general_type_id = h.general_type_id)
      WHERE A.pat_gen_detail_seq_id  = v_pat_gen_detail_seq_id  ORDER BY A.icd_pcs_seq_id ;

    CURSOR narration_cur IS SELECT
     A.reference_date,
     A.remarks,
     B.contact_name
     FROM pat_log A JOIN tpa_user_contacts B ON (a.added_by = b.contact_seq_id)
     WHERE pat_gen_detail_seq_id = v_pat_gen_detail_seq_id AND pat_log_general_type_id = 'NAR';

      v_rec_user                   preauth_cur%ROWTYPE;
      v_prev_icd_rec               icd_pcs_cur%ROWTYPE;
      rec                          icd_pcs_cur%ROWTYPE;
      v_preauth_doc        DBMS_XMLDOM.DOMDocument;
      v_preauth_root_node  DBMS_XMLDOM.DOMNode;
      v_elem               DBMS_XMLDOM.DOMElement;
      v_elem1              DBMS_XMLDOM.DOMElement;
      v_node               DBMS_XMLDOM.DOMNode;
      v_parent_node        DBMS_XMLDOM.DOMNODE;
      v_root_node          DBMS_XMLDOM.DOMNode;
      v_ctr                NUMBER := 1 ;
      v_flag               CHAR(1) := 'N';
      v_name               VARCHAR2(2000);
--      v_buf                VARCHAR2(10000);
   BEGIN
      OPEN preauth_cur;
      FETCH preauth_cur INTO v_rec_user;
      CLOSE preauth_cur;

      v_preauth_doc := dbms_xmldom.newDOMDocument;
      dbms_xmldom.setVersion( v_preauth_doc, '1.0' );
      v_preauth_root_node := dbms_xmldom.makeNode(v_preauth_doc);

      v_elem := dbms_xmldom.createElement( v_preauth_doc, 'preauthorizationhistory' );
      v_node := dbms_xmldom.makeNode( v_elem );
      v_preauth_root_node := dbms_xmldom.appendChild( v_preauth_root_node, v_node );
---
      v_elem := dbms_xmldom.createElement(v_preauth_doc, 'preauthorizationdetails');
      dbms_xmldom.setAttribute(v_elem,'preauthnumber',v_rec_user.pre_auth_number);
      dbms_xmldom.setAttribute(v_elem,'preauthtype',v_rec_user.preauth_type);
      dbms_xmldom.setAttribute(v_elem,'recieveddate',v_rec_user.pat_received_date);
      dbms_xmldom.setAttribute(v_elem,'admissiondate',v_rec_user.likely_date_of_hospitalization);
      dbms_xmldom.setAttribute(v_elem,'prevapprovedamount',v_rec_user.prev_approved_amount);
      dbms_xmldom.setAttribute(v_elem,'requestedamount',v_rec_user.pat_requested_amount);
      dbms_xmldom.setAttribute(v_elem,'treatingdoctorname',v_rec_user.treating_dr_name);
      dbms_xmldom.setAttribute(v_elem,'ttkbranch',v_rec_user.office_name);
      dbms_xmldom.setAttribute(v_elem,'remarks',v_rec_user.Remarks);
      dbms_xmldom.setAttribute(v_elem,'enhanced',v_rec_user.enhanced_yn);
      dbms_xmldom.setAttribute(v_elem,'dateofdischarge', TO_CHAR(v_rec_user.probable_date_of_discharge,'DD/MM/YYYY'));
      dbms_xmldom.setAttribute(v_elem,'workflow', v_rec_user.event_name);
      dbms_xmldom.setAttribute(v_elem,'completed', v_rec_user.completed_yn);
      dbms_xmldom.setAttribute(v_elem,'cignastatus',v_rec_user.cigna_yn);
      dbms_xmldom.setAttribute(v_elem,'statusid',v_rec_user.status_type);
      dbms_xmldom.setAttribute(v_elem,'authorizationnumber',v_rec_user.auth_number);
      dbms_xmldom.setAttribute(v_elem,'seqid',v_rec_user.seqid);
      dbms_xmldom.setAttribute(v_elem,'authtypeid',v_rec_user.auth_type_id);






      v_node := dbms_xmldom.makeNode(v_elem);
      v_parent_node := dbms_xmldom.appendChild( v_preauth_root_node, v_node);
--------
      v_elem := dbms_xmldom.createElement(v_preauth_doc, 'shortfall');
      dbms_xmldom.setAttribute( v_elem,'shortfall',CASE WHEN v_rec_user.shortfall_count > 0 THEN 'Y' ELSE 'N' END);
      dbms_xmldom.setAttribute( v_elem, 'seq_id', v_pat_gen_detail_seq_id);
      v_node := dbms_xmldom.makeNode(v_elem);
      v_parent_node := dbms_xmldom.appendChild( v_preauth_root_node, v_node);
--------
      v_elem := dbms_xmldom.createElement(v_preauth_doc, 'claimantdetails');
      dbms_xmldom.setAttribute(v_elem,'enrollmentid',v_rec_user.tpa_enrollment_id);
      dbms_xmldom.setAttribute(v_elem,'diabetes_cover_yn',v_rec_user.diabetes_cover_yn);  --For KOC1010
      dbms_xmldom.setAttribute(v_elem,'hypertension_cover_yn',v_rec_user.hypertension_cover_yn); --For KOC1010
      dbms_xmldom.setAttribute(v_elem,'claimantname',v_rec_user.mem_name);
      v_node := dbms_xmldom.makeNode(v_elem);
      v_parent_node := dbms_xmldom.appendChild( v_preauth_root_node, v_node);
-------------

      v_elem := dbms_xmldom.createElement( v_preauth_doc, 'policydetails');
      dbms_xmldom.setAttribute(v_elem,'policynumber',v_rec_user.policy_number);
      dbms_xmldom.setAttribute(v_elem,'inscompname',v_rec_user.ins_comp_name);
      dbms_xmldom.setAttribute(v_elem,'policyholder',v_rec_user.insured_name);
      dbms_xmldom.setAttribute(v_elem,'phone',v_rec_user.phone_1);
      dbms_xmldom.setAttribute(v_elem,'productname',v_rec_user.product_name);
      dbms_xmldom.setAttribute(v_elem,'termstatus',v_rec_user.ins_term_status);
      dbms_xmldom.setAttribute(v_elem,'policytype',v_rec_user.enrol_description);
      dbms_xmldom.setAttribute(v_elem,'policysubtype',v_rec_user.policy_sub_type);
      dbms_xmldom.setAttribute(v_elem,'startdate',v_rec_user.policy_effective_from);
      dbms_xmldom.setAttribute(v_elem,'enddate',v_rec_user.policy_effective_to);
      dbms_xmldom.setAttribute(v_elem,'actualstartdate',v_rec_user.ACTUAL_POLICY_EFFECTIVE_FROM); --policy renewal
      dbms_xmldom.setAttribute(v_elem,'actualenddate',v_rec_user.ACTUAL_POLICY_EFFECTIVE_TO);  --policy renewal
      dbms_xmldom.setAttribute(v_elem,'availablebufferamount',v_rec_user.buffer_ava_amount );
      --dbms_xmldom.setAttribute(v_elem,'availablebonus',v_rec_user.ava_cum_bonus);
      dbms_xmldom.setAttribute(v_elem,'zonecode',v_rec_user.zone_code);
      v_node := dbms_xmldom.makeNode(v_elem);
      v_parent_node := dbms_xmldom.appendChild( v_preauth_root_node, v_node);

-----------
      v_elem := dbms_xmldom.createElement(v_preauth_doc, 'icdpcscodingdetails');
      v_node := dbms_xmldom.makeNode(v_elem);
      v_root_node := dbms_xmldom.appendChild( v_preauth_root_node, v_node);

      v_elem := dbms_xmldom.createElement(v_preauth_doc, 'provisionaldiagnosis');
      dbms_xmldom.setAttribute(v_elem,'description',v_rec_user.Provisional_Diagnosis);
      v_node := dbms_xmldom.makeNode(v_elem);
      v_parent_node := dbms_xmldom.appendChild( v_root_node, v_node);

     OPEN icd_pcs_cur;
     FETCH icd_pcs_cur INTO rec;
     WHILE icd_pcs_cur%FOUND
     LOOP
        IF v_prev_icd_rec.icd_pcs_seq_id IS NULL THEN
           v_prev_icd_rec := rec;
           v_name := rec.NAME;
           v_flag := 'Y';
        ELSE
          IF rec.icd_pcs_seq_id = v_prev_icd_rec.icd_pcs_seq_id THEN
            v_name := v_name ||','|| rec.NAME;
          ELSE
            v_elem := dbms_xmldom.createElement(v_preauth_doc, 'record');
            dbms_xmldom.setAttribute(v_elem,'id',v_ctr);
            dbms_xmldom.setAttribute(v_elem,'ailment',v_prev_icd_rec.ailment_desc);
            dbms_xmldom.setAttribute(v_elem,'icdcode',v_prev_icd_rec.icd_code);
            dbms_xmldom.setAttribute(v_elem,'pckageorprocedure',v_name);
            dbms_xmldom.setAttribute(v_elem,'packagerate',v_prev_icd_rec.pkg_rate);
            dbms_xmldom.setAttribute(v_elem,'validatedamount',v_prev_icd_rec.validated_amt);
            dbms_xmldom.setAttribute(v_elem,'approvedamount',v_prev_icd_rec.itemized_app_amount);
            dbms_xmldom.setAttribute(v_elem,'hospitalizationtype',v_prev_icd_rec.hospital_general_type_id);
            dbms_xmldom.setAttribute(v_elem,'hospitalizationdescription',v_prev_icd_rec.hospitalization_type);
            dbms_xmldom.setAttribute(v_elem,'frequency','(Freq :'||v_prev_icd_rec.frequency_of_visit||' '||v_prev_icd_rec.duration ||') (No.:'||v_prev_icd_rec.no_of_visits||')');
            v_node := dbms_xmldom.makeNode(v_elem);
            v_parent_node := dbms_xmldom.appendChild( v_root_node, v_node);
            v_prev_icd_rec := rec;
            v_name := rec.NAME;
            v_ctr := v_ctr + 1;
          END IF;
        END IF;
        FETCH icd_pcs_cur INTO rec;
      END LOOP;
      IF v_flag = 'Y' THEN
        v_elem := dbms_xmldom.createElement(v_preauth_doc, 'record');
        dbms_xmldom.setAttribute(v_elem,'id',v_ctr);
        dbms_xmldom.setAttribute(v_elem,'ailment',rec.ailment_desc);
        dbms_xmldom.setAttribute(v_elem,'icdcode',rec.icd_code);
        dbms_xmldom.setAttribute(v_elem,'pckageorprocedure',v_name);
        dbms_xmldom.setAttribute(v_elem,'packagerate',rec.pkg_rate);
        dbms_xmldom.setAttribute(v_elem,'validatedamount',rec.validated_amt);
        dbms_xmldom.setAttribute(v_elem,'approvedamount',rec.itemized_app_amount);
        dbms_xmldom.setAttribute(v_elem,'hospitalizationtype',rec.hospital_general_type_id);
        dbms_xmldom.setAttribute(v_elem,'hospitalizationdescription',rec.hospitalization_type);
        dbms_xmldom.setAttribute(v_elem,'frequency','(Freq :'||rec.frequency_of_visit||' '||rec.duration ||') (No.:'||rec.no_of_visits||')');
        v_node := dbms_xmldom.makeNode(v_elem);
        v_parent_node := dbms_xmldom.appendChild( v_root_node, v_node);
      END IF;
      CLOSE icd_pcs_cur;
------------
      v_elem := dbms_xmldom.createElement(v_preauth_doc, 'hospitaldetails');
      dbms_xmldom.setAttribute(v_elem,'hospitalname',v_rec_user.hosp_name);
      dbms_xmldom.setAttribute(v_elem,'hospitalgrade',v_rec_user.rating);
      dbms_xmldom.setAttribute(v_elem,'empanelnumber',v_rec_user.empanel_number);
      dbms_xmldom.setAttribute(v_elem,'city',v_rec_user.city_description);
      dbms_xmldom.setAttribute(v_elem,'state',v_rec_user.state_name);
      v_node := dbms_xmldom.makeNode(v_elem);
      v_parent_node := dbms_xmldom.appendChild( v_preauth_root_node, v_node);
------------

      v_elem := dbms_xmldom.createElement(v_preauth_doc, 'authorizationdetails');
      dbms_xmldom.setAttribute(v_elem,'authoriztionnumber',v_rec_user.auth_number);
      dbms_xmldom.setAttribute(v_elem,'totalsuminsured',v_rec_user.mem_total_sum_insured);
      --dbms_xmldom.setAttribute(v_elem,'availablesuminsured',v_rec_user.ava_sum_insured);
      --dbms_xmldom.setAttribute(v_elem,'availablebonus',v_rec_user.ava_cum_bonus);
      dbms_xmldom.setAttribute(v_elem,'requestedamount',v_rec_user.pat_requested_amount);
      dbms_xmldom.setAttribute(v_elem,'prevapprovedamount',v_rec_user.prev_approved_amount);
      dbms_xmldom.setAttribute(v_elem,'approvedamount',v_rec_user.total_app_amount);

      v_node := dbms_xmldom.makeNode(v_elem);
      v_parent_node := dbms_xmldom.appendChild( v_preauth_root_node, v_node);
-----------
      v_elem := dbms_xmldom.createElement(v_preauth_doc, 'bufferamount');
      dbms_xmldom.setAttribute(v_elem,'availablebufferamount',v_rec_user.buffer_ava_amount );
      dbms_xmldom.setAttribute(v_elem,'approvedbufferamount',v_rec_user.buffer_app_amount );
      dbms_xmldom.setAttribute(v_elem,'bufferapproveddate',v_rec_user.buffer_approved_date);

      v_node := dbms_xmldom.makeNode(v_elem);
      v_parent_node := dbms_xmldom.appendChild( v_preauth_root_node, v_node);
---------
      v_elem := dbms_xmldom.createElement(v_preauth_doc, 'approvalstatus');
      dbms_xmldom.setAttribute(v_elem,'status',v_rec_user.app_status);
      dbms_xmldom.setAttribute(v_elem,'approvedby',v_rec_user.contact_name);
      dbms_xmldom.setAttribute(v_elem,'approveddate',v_rec_user.completed_date);
      dbms_xmldom.setAttribute(v_elem,'remarks',v_rec_user.app_remarks);
      dbms_xmldom.setAttribute(v_elem,'reason',v_rec_user.reason);

      v_node := dbms_xmldom.makeNode(v_elem);
      v_parent_node := dbms_xmldom.appendChild( v_preauth_root_node, v_node);
-------
      v_elem := dbms_xmldom.createElement(v_preauth_doc, 'narrationdetails');
      v_node := dbms_xmldom.makeNode(v_elem);
      v_root_node := dbms_xmldom.appendChild( v_preauth_root_node, v_node);

     v_ctr := 1;

     FOR nar_rec IN narration_cur
     LOOP
        v_elem := dbms_xmldom.createElement(v_preauth_doc, 'record');
        dbms_xmldom.setAttribute(v_elem,'id',v_ctr);
        dbms_xmldom.setAttribute(v_elem,'referencedate',nar_rec.reference_date);
        dbms_xmldom.setAttribute(v_elem,'remarks',nar_rec.remarks);
        dbms_xmldom.setAttribute(v_elem,'user',nar_rec.contact_name);
        v_node := dbms_xmldom.makeNode(v_elem);
        v_parent_node := dbms_xmldom.appendChild( v_root_node, v_node);
        v_ctr := v_ctr + 1;
      END LOOP;

      v_preauth_history_doc := dbms_xmldom.getxmltype(v_preauth_doc);

     dbms_xmldom.freeDocument(v_preauth_doc);
   END create_preauth_xml;
--============================================================================================================


PROCEDURE create_claim_xml (
    v_claim_seq_id                          IN clm_general_details.claim_seq_id%TYPE,
    v_hosp_seq_id                           IN  tpa_hosp_info.hosp_seq_id%type,
    v_claim_history_doc                     OUT XMLTYPE
   )
   IS
     CURSOR pre_post_cur IS
       WITH bill_det AS ( SELECT b.bill_date, c.date_of_admission, c.date_of_discharge
         FROM clm_bill_header b JOIN clm_general_details c ON (b.claim_seq_id = c.claim_seq_id)
         WHERE b.claim_seq_id = v_claim_seq_id )
       SELECT (SELECT COUNT(1) FROM bill_det a WHERE trunc(a.bill_date) < trunc(a.date_of_admission)) AS pre_count,
              (SELECT COUNT(1) FROM bill_det a WHERE trunc(a.bill_date) > trunc(a.date_of_discharge)) AS post_count,
              (SELECT COUNT(1) FROM bill_det a WHERE trunc(a.bill_date) BETWEEN trunc(a.date_of_admission) AND trunc(a.date_of_discharge)) AS hosp_count
              FROM dual;


     CURSOR claim_cur IS
       SELECT
         A.claim_seq_id,
         b.tpa_enrollment_id,
         b.claimant_name,
         ab.description AS gender,
         b.mem_age,
         TO_CHAR(b.date_of_inception,'DD/MM/YYYY') AS date_of_inception ,
         TO_CHAR(b.date_of_exit,'DD/MM/YYYY') AS date_of_exit,
         TO_CHAR(al.ACTUAL_POLICY_START_DATE,'DD/MM/YYYY') AS actual_date_of_inception , --policy renewal
         TO_CHAR(al.ACTUAL_POLICY_END_DATE,'DD/MM/YYYY') AS actual_date_of_exit,   --policy renewal
         b.mem_total_sum_insured ,
         --pre_auth_pkg.get_available_sum(NULL,a.claim_seq_id,'SUM') AS ava_sum_insured,
         o.buffer_ava_amount ,
         AR.pre_auth_buffer_app_amount ,
         p.claim_app_buffer_amount ,
         TO_CHAR( NVL(o.buffer_approved_date ,aq.buffer_approved_date), 'dd/mm/yyyy hh:mi AM' ) AS buffer_approved_date,
         --pre_auth_pkg.get_available_sum(NULL,a.claim_seq_id,'BONUS') AS ava_cum_bonus,
         b.employee_no,
         b.policy_holder_name,
         ac.relship_description ,
         b.claimant_phone_number ,
         a.claim_number,
         a.claim_file_number,
         ad.description AS request_type,
         d.description AS claim_type,
         ae.description AS claim_sub_type,
         TO_CHAR(ak.call_recorded_date,'dd/mm/yyyy hh:mi AM' ) AS intimation_date,
         af.description AS mode_type,
         TO_CHAR(c.rcvd_date,'dd/mm/yyyy hh:mi AM' ) AS rcvd_date,
         a.requested_amount,
         a.treating_dr_name,
         a.in_patient_no,
         e.office_name,
         z.contact_name,
         ah.office_name AS processing_branch,
         a.claims_remarks ,
         b.policy_number,
         i.ins_comp_name,
         b.phone_1 ,
         CASE WHEN b.ins_status_general_type_id = 'TPR' THEN 'Renewal' ELSE 'Fresh' END AS term_status,
         CASE WHEN b.enrol_type_id = 'IND' THEN 'Individual'
              WHEN b.enrol_type_id = 'ING' THEN 'Individual As Group'
              WHEN b.enrol_type_id = 'COR' THEN 'Corporate'
              WHEN b.enrol_type_id = 'NCR' THEN 'Non-Corporate' END AS policy_type,
         CASE WHEN b.policy_sub_general_type_id = 'PNF' THEN 'Non-Floater'
              WHEN b.policy_sub_general_type_id = 'PFL' THEN 'Floater'
              WHEN b.policy_sub_general_type_id = 'PFN' THEN 'Floater + Non-Floater'
              WHEN b.policy_sub_general_type_id = 'PFL' THEN 'Floater with Restriction' END AS policy_sub_type,
         TO_CHAR(b.policy_effective_from,'DD/MM/YYYY') AS policy_effective_from,
         TO_CHAR(b.policy_effective_to,'DD/MM/YYYY') AS policy_effective_to,
         NVL(s.hosp_name,q.hosp_name ) AS hosp_name ,
         s.empanel_number ,
         NVL(U.city_description , q.city_name ) AS city_name ,
         NVL(v.state_name , q.state_name ) AS state_name ,
         s.rating ,
         a.claim_settlement_number ,
         a.total_app_amount,
         ai.max_allowed_amount ,
         a.pat_approved_amount ,
         case a.COMPLETED_YN when 'Y' THEN  y.description
             else case b.clm_status_general_type_id
                 when 'APR' then 'In-Progress'
                 when 'REJ' then 'In-Progress'
                 when 'PCO' then 'In-Progress'
                 else y.description end end AS status,
         a.permission_sought_from,
         TO_CHAR(b.decision_date,'dd/mm/yyyy hh:mi AM' ) AS decision_date,
         aj.description AS reason_type,
         x.remarks ,
         am.product_name,
         AN.provisional_diagnosis,
         TO_CHAR(a.date_of_admission,'dd/mm/yyyy HH:MI AM') AS date_of_admission,
         TO_CHAR(a.date_of_discharge,'dd/mm/yyyy HH:MI AM') AS date_of_discharge,
         (SELECT COUNT(1) FROM shortfall_details ss WHERE ss.claim_seq_id = a.claim_seq_id ) AS shortfall_count,
         al.zone_code,
         DECODE(G.diabetes_cover_yn ,'Y','Yes','No') AS diabetes_cover_yn, --For KOC1010
         DECODE(G.hypertension_cover_yn ,'Y','Yes','No') AS hypertension_cover_yn ,
         a.completed_yn,
         a.claim_seq_id as seqid,
         i.notify_type_id as auth_type_id,
         CASE WHEN i.ins_comp_name like 'CIGNA%' THEN 'Y' ELSE 'N' END AS CIGNA_YN,
         case a.COMPLETED_YN when 'Y' THEN  y.description
             else case b.clm_status_general_type_id
                 when 'APR' then 'INP'
                 when 'REJ' then 'INP'
                 when 'PCO' then 'INP'
                 else y.description end end AS  status_type
         FROM clm_general_details A JOIN clm_enroll_details B ON ( A.claim_seq_id = b.claim_seq_id )
         JOIN clm_inward C ON ( a.claims_inward_seq_id = c.claims_inward_seq_id and c.claim_general_type_id='CNH')
         LEFT OUTER JOIN tpa_general_code D ON ( C.claim_general_type_id = D.general_type_id )
         LEFT OUTER JOIN tpa_office_info E ON (C.tpa_office_seq_id = e.tpa_office_seq_id)
         LEFT OUTER JOIN tpa_enr_policy_member G ON (B.member_seq_id = G.member_seq_id)
         LEFT OUTER JOIN tpa_ins_info I ON (B.ins_seq_id = I.ins_seq_id)
         LEFT OUTER JOIN tpa_general_code K ON (b.clm_status_general_type_id = k.general_type_id)
         LEFT OUTER JOIN buffer_details O ON (a.last_buffer_detail_seq_id = o.buff_detail_seq_id )
         LEFT OUTER JOIN buffer_header P ON (o.buffer_hdr_seq_id  = p.buffer_hdr_seq_id )
         JOIN clm_hospital_association Q ON ( A.claim_seq_id = Q.claim_seq_id )
         LEFT OUTER JOIN tpa_hosp_info S ON (Q.hosp_seq_id = S.hosp_seq_id)
         LEFT OUTER JOIN tpa_hosp_address T ON (S.hosp_seq_id = T.hosp_seq_id)
         LEFT OUTER JOIN tpa_city_code U ON (T.city_type_id = U.city_type_id)
         LEFT OUTER JOIN tpa_state_code V ON (T.state_type_id = V.state_type_id)
         LEFT OUTER JOIN assign_users X ON (a.last_assign_user_seq_id  = X.assign_users_seq_id)
         LEFT OUTER JOIN tpa_general_code Y ON (B.clm_status_general_type_id = Y.general_type_id)
         LEFT OUTER JOIN tpa_user_contacts Z ON (X.assigned_to_user = Z.contact_seq_id)
         LEFT OUTER JOIN tpa_general_code AA ON (B.Rson_General_Type_Id = AA.general_type_id)
         LEFT OUTER JOIN tpa_general_code AB ON (b.gender_general_type_id = ab.general_type_id )
         LEFT OUTER JOIN tpa_relationship_code AC ON (b.relship_type_id = AC.relship_type_id )
         LEFT OUTER JOIN tpa_general_code AD ON ( C.document_general_type_id = ad.general_type_id )
         LEFT OUTER JOIN tpa_general_code AE ON ( A.claim_sub_general_type_id = AE.general_type_id )
         LEFT OUTER JOIN tpa_general_code AF ON ( A.mode_general_type_id  = AF.general_type_id )
         LEFT OUTER JOIN tpa_office_info ah ON ( z.tpa_office_seq_id = ah.tpa_office_seq_id )
         LEFT OUTER JOIN ( SELECT SUM(approved_amount) AS appr_amt, SUM(maximum_allowed_amount) AS max_allowed_amount , claim_seq_id
                           FROM ailment_caps XXX JOIN icd_pcs_detail YYY ON ( XXX.icd_pcs_seq_id = YYY.icd_pcs_seq_id ) WHERE YYY.claim_seq_id = v_claim_seq_id
                           GROUP BY claim_seq_id ) AI
                           ON ( A.claim_seq_id = AI.claim_seq_id )
         LEFT OUTER JOIN tpa_general_code aj ON ( b.rson_general_type_id = aj.general_type_id )
         LEFT OUTER JOIN tpa_call_log AK ON (a.call_log_seq_id = ak.call_log_seq_id )
         LEFT OUTER JOIN tpa_enr_policy AL ON (b.policy_seq_id = al.policy_seq_id)
         LEFT OUTER JOIN tpa_ins_product AM ON ( al.product_seq_id = am.product_seq_id )
         LEFT OUTER JOIN ailment_details AN ON (A.claim_seq_id = AN.claim_seq_id)
         LEFT OUTER JOIN pat_general_details AP ON (A.pat_enroll_detail_seq_id = AP.pat_enroll_detail_seq_id)
         LEFT OUTER JOIN buffer_details AQ ON (AP.last_buffer_detail_seq_id = AQ.buff_detail_seq_id )
         LEFT OUTER JOIN buffer_header AR ON (AQ.buffer_hdr_seq_id  = AR.buffer_hdr_seq_id )
         LEFT OUTER JOIN tpa_claims_payment AT ON (a.claim_seq_id = AT.claim_seq_id)
         LEFT OUTER JOIN tpa_payment_checks_details AU ON (AT.payment_seq_id = AU.payment_seq_id)
         LEFT OUTER JOIN tpa_claims_check AV ON (AU.claims_chk_seq_id = AV.claims_chk_seq_id)
         LEFT OUTER JOIN tpa_general_code AW ON (AV.check_status = AW.general_type_id)
         WHERE A.claim_seq_id  = v_claim_seq_id  and q.hosp_seq_id=v_hosp_seq_id;

    CURSOR cheque_cur IS
         SELECT AW.description AS cheque_status,
         TO_CHAR(AV.check_date,'dd/mm/yyyy hh:mi AM') AS check_date,
         CASE WHEN AT.PAYEE_TYPE='EFT' THEN 'EFT-'||TO_CHAR(AV.check_num) ELSE TO_CHAR(AV.check_num) END AS check_num,--KOC1103
         CASE WHEN AT.CLAIM_PAYMENT_STATUS='PAID' THEN AV.check_amount ELSE NULL END AS check_amount ,--ADDED FOR KOC1103
         (td.approved_amount - td.check_amount) AS tds_amount,
         ttk_util_pkg.fn_decrypt( AT.payee_name) as payee_name --//ED
         FROM tpa_claims_payment AT LEFT OUTER JOIN tpa_payment_checks_details AU ON (AT.payment_seq_id = AU.payment_seq_id)
         LEFT OUTER JOIN tpa_claims_check AV ON (AU.claims_chk_seq_id = AV.claims_chk_seq_id)
         LEFT OUTER JOIN tpa_general_code AW ON (AV.check_status = AW.general_type_id)
         LEFT OUTER JOIN tpa_clm_tds_details td ON (td.claim_seq_id=AT.claim_seq_id)
         WHERE AT.claim_seq_id  = v_claim_seq_id  ;
    cheque_rec              cheque_cur%ROWTYPE;
    CURSOR icd_pcs_cur IS SELECT
      A.icd_pcs_seq_id,
      A.ped_code_id,
      NVL(c.ped_description,'Others - '||A.other_desc) AS ailment_desc ,
      A.icd_code,
      A.primary_ailment_yn,
      NULL AS pkg_rate ,
      G.maximum_allowed_amount AS validated_amt,
      G.approved_amount AS itemized_app_amount,
      D.proc_seq_id,
      D.pkg_seq_id,
      a.hospital_general_type_id ,
      H.description AS hospitalization_type ,
      A.frequency_of_visit ,
      A.no_of_visits ,
      DECODE (a.pat_duration_general_type_id,'DTD','Days','DTW','Weeks','DTM','Months','Years') AS duration,
      NVL(E.NAME ,F.proc_description) AS NAME
      FROM icd_pcs_detail A LEFT OUTER JOIN tpa_ped_code C ON (A.ped_code_id = C.ped_code_id)
      LEFT OUTER JOIN pat_package_procedures D ON ( A.icd_pcs_seq_id = D.icd_pcs_seq_id )
      LEFT OUTER JOIN tpa_hosp_tariff_item E ON (d.pkg_seq_id = e.pkg_seq_id)
      LEFT OUTER JOIN tpa_hosp_procedure_code F ON (D.proc_seq_id = F.proc_seq_id)
      LEFT OUTER JOIN ailment_caps G ON ( a.icd_pcs_seq_id = G.icd_pcs_seq_id )
      LEFT OUTER JOIN tpa_general_code H ON (a.hospital_general_type_id = h.general_type_id)
      WHERE A.claim_seq_id  = v_claim_seq_id  ORDER BY A.icd_pcs_seq_id ;

    CURSOR narration_cur IS SELECT
      A.reference_date,
      A.remarks,
      B.contact_name
      FROM pat_log A JOIN tpa_user_contacts B ON (a.added_by = b.contact_seq_id)
      WHERE A.claim_seq_id = v_claim_seq_id AND pat_log_general_type_id = 'NAR';


      v_rec_user                   claim_cur%ROWTYPE;
      v_prev_icd_rec               icd_pcs_cur%ROWTYPE;
      rec                          icd_pcs_cur%ROWTYPE;


      v_preauth_doc        DBMS_XMLDOM.DOMDocument;
      v_preauth_root_node  DBMS_XMLDOM.DOMNode;
      v_elem               DBMS_XMLDOM.DOMElement;
      v_node               DBMS_XMLDOM.DOMNode;
      v_parent_node        DBMS_XMLDOM.DOMNODE;
      v_root_node          DBMS_XMLDOM.DOMNode;
      v_ctr                NUMBER := 1 ;
      v_name               VARCHAR2(2000);
      v_flag               CHAR(1) := 'N';
      pre_post_rec         pre_post_cur%ROWTYPE;
   BEGIN
      OPEN pre_post_cur;
      FETCH pre_post_cur INTO pre_post_rec;
      CLOSE pre_post_cur;

      OPEN claim_cur;
      FETCH claim_cur INTO v_rec_user;
      CLOSE claim_cur;

      v_preauth_doc := dbms_xmldom.newDOMDocument;
      dbms_xmldom.setVersion( v_preauth_doc, '1.0' );
      v_preauth_root_node := dbms_xmldom.makeNode(v_preauth_doc);

      v_elem := dbms_xmldom.createElement( v_preauth_doc, 'claimshistory' );
      v_node := dbms_xmldom.makeNode( v_elem );
      v_preauth_root_node := dbms_xmldom.appendChild( v_preauth_root_node, v_node );
---
      v_elem := dbms_xmldom.createElement(v_preauth_doc, 'claimantdetails');
      dbms_xmldom.setAttribute(v_elem,'enrollmentid',v_rec_user.tpa_enrollment_id);
      dbms_xmldom.setAttribute(v_elem,'claimantname',v_rec_user.claimant_name);
      dbms_xmldom.setAttribute(v_elem,'gender',v_rec_user.gender);
      dbms_xmldom.setAttribute(v_elem,'age',v_rec_user.mem_age);
      dbms_xmldom.setAttribute(v_elem,'dateofinception',v_rec_user.date_of_inception);
      dbms_xmldom.setAttribute(v_elem,'dateofexit',v_rec_user.date_of_exit);
      dbms_xmldom.setAttribute(v_elem,'totalsuminsured',v_rec_user.mem_total_sum_insured);
      --dbms_xmldom.setAttribute(v_elem,'availablesum',v_rec_user.ava_sum_insured);
      dbms_xmldom.setAttribute(v_elem,'availablebuffer',NVL(v_rec_user.claim_app_buffer_amount,v_rec_user.pre_auth_buffer_app_amount) );
     -- dbms_xmldom.setAttribute(v_elem,'availablebonus',v_rec_user.ava_cum_bonus);
      dbms_xmldom.setAttribute(v_elem,'employeeno',v_rec_user.employee_no);
      dbms_xmldom.setAttribute(v_elem,'employeename',v_rec_user.policy_holder_name);
      dbms_xmldom.setAttribute(v_elem,'relationship',v_rec_user.relship_description);
      dbms_xmldom.setAttribute(v_elem,'claimantphone',v_rec_user.claimant_phone_number);
      dbms_xmldom.setAttribute(v_elem,'diabetes_cover_yn',v_rec_user.diabetes_cover_yn); --For KOC1010
      dbms_xmldom.setAttribute(v_elem,'hypertension_cover_yn',v_rec_user.hypertension_cover_yn);--For KOC1010

      v_node := dbms_xmldom.makeNode(v_elem);
      v_parent_node := dbms_xmldom.appendChild( v_preauth_root_node, v_node);
--------

      v_elem := dbms_xmldom.createElement(v_preauth_doc, 'claimdetails');
      dbms_xmldom.setAttribute(v_elem,'claimnumber', v_rec_user.claim_number);
      dbms_xmldom.setAttribute(v_elem,'claimfileno', v_rec_user.claim_file_number);
      dbms_xmldom.setAttribute(v_elem,'requesttype', v_rec_user.request_type);
      dbms_xmldom.setAttribute(v_elem,'claimtype', v_rec_user.claim_type);
      dbms_xmldom.setAttribute(v_elem,'claimsubtype',v_rec_user.claim_sub_type);
      dbms_xmldom.setAttribute(v_elem,'intimationdate',v_rec_user.intimation_date);
      dbms_xmldom.setAttribute(v_elem,'mode',v_rec_user.mode_type);
      dbms_xmldom.setAttribute(v_elem,'rcvddate',v_rec_user.rcvd_date);
      dbms_xmldom.setAttribute(v_elem,'requestedamount',v_rec_user.requested_amount);
      dbms_xmldom.setAttribute(v_elem,'doctorname',v_rec_user.treating_dr_name);
      dbms_xmldom.setAttribute(v_elem,'inpatiantname',v_rec_user.in_patient_no);
      dbms_xmldom.setAttribute(v_elem,'ttkbranch',v_rec_user.office_name);
      dbms_xmldom.setAttribute(v_elem,'assignedto',v_rec_user.contact_name);
      dbms_xmldom.setAttribute(v_elem,'processingbranch',v_rec_user.processing_branch);
      dbms_xmldom.setAttribute(v_elem,'dateofadmission',v_rec_user.date_of_admission);
      dbms_xmldom.setAttribute(v_elem,'dateofdischarge',v_rec_user.date_of_discharge);
      dbms_xmldom.setAttribute(v_elem,'claimsremarks',v_rec_user.claims_remarks);
      dbms_xmldom.setAttribute(v_elem,'completed',v_rec_user.completed_yn);
      dbms_xmldom.setAttribute(v_elem,'cignastatus',v_rec_user.cigna_yn);
      dbms_xmldom.setAttribute(v_elem,'authorizationnumber',v_rec_user.claim_settlement_number);
      dbms_xmldom.setAttribute(v_elem,'statusid',v_rec_user.status_type);
      dbms_xmldom.setAttribute(v_elem,'seqid',v_rec_user.seqid);
      dbms_xmldom.setAttribute(v_elem,'authtypeid',v_rec_user.auth_type_id);




      dbms_xmldom.setAttribute(v_elem,'prehospitalization',pre_post_rec.pre_count); -- if > 0 means Yes Else No.
      dbms_xmldom.setAttribute(v_elem,'posthospitalization',pre_post_rec.post_count);-- if > 0 means Yes Else No.
      dbms_xmldom.setAttribute(v_elem,'hospitalization',pre_post_rec.hosp_count );-- if > 0 means Yes Else No.
      v_node := dbms_xmldom.makeNode(v_elem);
      v_parent_node := dbms_xmldom.appendChild( v_preauth_root_node, v_node);

      v_elem := dbms_xmldom.createElement(v_preauth_doc, 'chequeinformation');
      v_node := dbms_xmldom.makeNode(v_elem);
      v_root_node := dbms_xmldom.appendChild( v_preauth_root_node, v_node);

--------
      v_elem := dbms_xmldom.createElement(v_preauth_doc, 'shortfall');
      dbms_xmldom.setAttribute( v_elem,'shortfall',CASE WHEN v_rec_user.shortfall_count > 0 THEN 'Y' ELSE 'N' END);
      dbms_xmldom.setAttribute( v_elem, 'seq_id', v_claim_seq_id);
      v_node := dbms_xmldom.makeNode(v_elem);
      v_parent_node := dbms_xmldom.appendChild( v_preauth_root_node, v_node);
--------



      OPEN cheque_cur;
      FETCH cheque_cur INTO cheque_rec;
      WHILE cheque_cur%FOUND
      LOOP
        v_elem := dbms_xmldom.createElement(v_preauth_doc, 'record');
        dbms_xmldom.setAttribute(v_elem,'id', v_ctr);
        dbms_xmldom.setAttribute(v_elem,'checknumber',cheque_rec.check_num);
        dbms_xmldom.setAttribute(v_elem,'checkdate',cheque_rec.check_date);
        dbms_xmldom.setAttribute(v_elem,'checkamount',cheque_rec.check_amount);
        dbms_xmldom.setAttribute(v_elem,'tdsamount',cheque_rec.tds_amount);
        dbms_xmldom.setAttribute(v_elem,'chequestatus',cheque_rec.cheque_status);
        dbms_xmldom.setAttribute(v_elem,'payeename',cheque_rec.payee_name);
        v_node := dbms_xmldom.makeNode(v_elem);
        v_parent_node := dbms_xmldom.appendChild( v_root_node, v_node);
        FETCH cheque_cur INTO cheque_rec;
        v_ctr := v_ctr + 1;
      END LOOP;
-------------

      v_elem := dbms_xmldom.createElement(v_preauth_doc, 'policydetails');
      dbms_xmldom.setAttribute(v_elem,'policynumber',v_rec_user.policy_number);
      dbms_xmldom.setAttribute(v_elem,'zonecode',v_rec_user.zone_code); --For KOC1010
      dbms_xmldom.setAttribute(v_elem,'inscompname',v_rec_user.ins_comp_name);
      dbms_xmldom.setAttribute(v_elem,'policyholder',v_rec_user.policy_holder_name);
      dbms_xmldom.setAttribute(v_elem,'phone',v_rec_user.phone_1);
      dbms_xmldom.setAttribute(v_elem,'termstatus',v_rec_user.term_status);
      dbms_xmldom.setAttribute(v_elem,'policytype',v_rec_user.policy_type);
      dbms_xmldom.setAttribute(v_elem,'policysubtype',v_rec_user.policy_sub_type);
      dbms_xmldom.setAttribute(v_elem,'startdate',v_rec_user.policy_effective_from);
      dbms_xmldom.setAttribute(v_elem,'enddate',v_rec_user.policy_effective_to);
      dbms_xmldom.setAttribute(v_elem,'actualstartdate',v_rec_user.ACTUAL_DATE_OF_INCEPTION);  --policy renewal
      dbms_xmldom.setAttribute(v_elem,'actualenddate',v_rec_user.ACTUAL_DATE_OF_EXIT);  --policy renewal
      dbms_xmldom.setAttribute(v_elem,'availablebufferamount',v_rec_user.buffer_ava_amount );
      --dbms_xmldom.setAttribute(v_elem,'availablebonus',v_rec_user.ava_cum_bonus);
      dbms_xmldom.setAttribute(v_elem,'productname',v_rec_user.product_name);
      v_node := dbms_xmldom.makeNode(v_elem);
      v_parent_node := dbms_xmldom.appendChild( v_preauth_root_node, v_node);

-----------
      v_elem := dbms_xmldom.createElement(v_preauth_doc, 'icdpcscodingdetails');
      v_node := dbms_xmldom.makeNode(v_elem);
      v_root_node := dbms_xmldom.appendChild( v_preauth_root_node, v_node);

      v_elem := dbms_xmldom.createElement(v_preauth_doc, 'provisionaldiagnosis');
      dbms_xmldom.setAttribute(v_elem,'description',v_rec_user.Provisional_Diagnosis);
      v_node := dbms_xmldom.makeNode(v_elem);
      v_parent_node := dbms_xmldom.appendChild( v_root_node, v_node);

     v_ctr := 1;
     OPEN icd_pcs_cur;
     FETCH icd_pcs_cur INTO rec;
     WHILE icd_pcs_cur%FOUND
     LOOP
        IF v_prev_icd_rec.icd_pcs_seq_id IS NULL THEN
           v_prev_icd_rec := rec;
           v_name := rec.NAME;
           v_flag := 'Y';
        ELSE
          IF rec.icd_pcs_seq_id = v_prev_icd_rec.icd_pcs_seq_id THEN
            v_name := v_name ||','|| rec.NAME;
          ELSE
            v_elem := dbms_xmldom.createElement(v_preauth_doc, 'record');
            dbms_xmldom.setAttribute(v_elem,'id',v_ctr);
            dbms_xmldom.setAttribute(v_elem,'ailment',v_prev_icd_rec.ailment_desc);
            dbms_xmldom.setAttribute(v_elem,'icdcode',v_prev_icd_rec.icd_code);
            dbms_xmldom.setAttribute(v_elem,'pckageorprocedure',v_name);
            dbms_xmldom.setAttribute(v_elem,'packagerate',v_prev_icd_rec.pkg_rate);
            dbms_xmldom.setAttribute(v_elem,'validatedamount',v_prev_icd_rec.validated_amt);
            dbms_xmldom.setAttribute(v_elem,'approvedamount',v_prev_icd_rec.itemized_app_amount);
            dbms_xmldom.setAttribute(v_elem,'hospitalizationtype',v_prev_icd_rec.hospital_general_type_id);
            dbms_xmldom.setAttribute(v_elem,'hospitalizationdescription',v_prev_icd_rec.hospitalization_type);
            dbms_xmldom.setAttribute(v_elem,'frequency','(Freq:'||v_prev_icd_rec.frequency_of_visit||' '||v_prev_icd_rec.duration ||') (No.:'||v_prev_icd_rec.no_of_visits||')');
            v_node := dbms_xmldom.makeNode(v_elem);
            v_parent_node := dbms_xmldom.appendChild( v_root_node, v_node);
            v_prev_icd_rec := rec;
            v_name := rec.NAME;
            v_ctr := v_ctr + 1;
          END IF;
        END IF;
        FETCH icd_pcs_cur INTO rec;
      END LOOP;
      IF v_flag = 'Y' THEN
        v_elem := dbms_xmldom.createElement(v_preauth_doc, 'record');
        dbms_xmldom.setAttribute(v_elem,'id',v_ctr);
        dbms_xmldom.setAttribute(v_elem,'ailment',rec.ailment_desc);
        dbms_xmldom.setAttribute(v_elem,'icdcode',rec.icd_code);
        dbms_xmldom.setAttribute(v_elem,'pckageorprocedure',v_name);
        dbms_xmldom.setAttribute(v_elem,'packagerate',rec.pkg_rate);
        dbms_xmldom.setAttribute(v_elem,'validatedamount',rec.validated_amt);
        dbms_xmldom.setAttribute(v_elem,'approvedamount',rec.itemized_app_amount);
        dbms_xmldom.setAttribute(v_elem,'hospitalizationtype',rec.hospital_general_type_id);
        dbms_xmldom.setAttribute(v_elem,'hospitalizationdescription',rec.hospitalization_type);
        dbms_xmldom.setAttribute(v_elem,'frequency','(Freq:'||rec.frequency_of_visit||' '||rec.duration ||') (No.:'||rec.no_of_visits||')');
        v_node := dbms_xmldom.makeNode(v_elem);
        v_parent_node := dbms_xmldom.appendChild( v_root_node, v_node);
      END IF;
      CLOSE icd_pcs_cur;
------------
      v_elem := dbms_xmldom.createElement(v_preauth_doc, 'hospitaldetails');
      dbms_xmldom.setAttribute(v_elem,'hospitalname',v_rec_user.hosp_name);
      dbms_xmldom.setAttribute(v_elem,'hospitalgrade',v_rec_user.rating);
      dbms_xmldom.setAttribute(v_elem,'empanelnumber',v_rec_user.empanel_number);
      dbms_xmldom.setAttribute(v_elem,'city',v_rec_user.city_name);
      dbms_xmldom.setAttribute(v_elem,'state',v_rec_user.state_name);
      v_node := dbms_xmldom.makeNode(v_elem);
      v_parent_node := dbms_xmldom.appendChild( v_preauth_root_node, v_node);
------------

      v_elem := dbms_xmldom.createElement(v_preauth_doc, 'settlementdetails');
      dbms_xmldom.setAttribute(v_elem,'settlementnumber',v_rec_user.claim_settlement_number);
      dbms_xmldom.setAttribute(v_elem,'totalsuminsured',v_rec_user.mem_total_sum_insured);
      --dbms_xmldom.setAttribute(v_elem,'availablesuminsured',v_rec_user.ava_sum_insured);
      --dbms_xmldom.setAttribute(v_elem,'availablebonus',v_rec_user.ava_cum_bonus);
      dbms_xmldom.setAttribute(v_elem,'requestedamount',v_rec_user.requested_amount);

      dbms_xmldom.setAttribute(v_elem,'preauthapprovedamount',v_rec_user.pat_approved_amount);
      dbms_xmldom.setAttribute(v_elem,'approvedamount',v_rec_user.total_app_amount );

      v_node := dbms_xmldom.makeNode(v_elem);
      v_parent_node := dbms_xmldom.appendChild( v_preauth_root_node, v_node);
-----------
      v_elem := dbms_xmldom.createElement(v_preauth_doc, 'bufferamount');
      dbms_xmldom.setAttribute(v_elem,'availablebufferamount',v_rec_user.buffer_ava_amount);
      dbms_xmldom.setAttribute(v_elem,'approvedbufferamount', NVL(v_rec_user.claim_app_buffer_amount, v_rec_user.pre_auth_buffer_app_amount ));
      dbms_xmldom.setAttribute(v_elem,'bufferapproveddate',v_rec_user.buffer_approved_date );

      v_node := dbms_xmldom.makeNode(v_elem);
      v_parent_node := dbms_xmldom.appendChild( v_preauth_root_node, v_node);
---------
      v_elem := dbms_xmldom.createElement(v_preauth_doc, 'approvalstatus');
      dbms_xmldom.setAttribute(v_elem,'status',v_rec_user.status);
      dbms_xmldom.setAttribute(v_elem,'approvedby',v_rec_user.contact_name);
      dbms_xmldom.setAttribute(v_elem,'approveddate',v_rec_user.decision_date);
      dbms_xmldom.setAttribute(v_elem,'remarks',v_rec_user.remarks);
      dbms_xmldom.setAttribute(v_elem,'reason',v_rec_user.reason_type);

      v_node := dbms_xmldom.makeNode(v_elem);
      v_parent_node := dbms_xmldom.appendChild( v_preauth_root_node, v_node);
-------
      v_elem := dbms_xmldom.createElement(v_preauth_doc, 'narrationdetails');
      v_node := dbms_xmldom.makeNode(v_elem);
      v_root_node := dbms_xmldom.appendChild( v_preauth_root_node, v_node);

     v_ctr := 1;
     FOR nar_rec IN narration_cur
     LOOP
        v_elem := dbms_xmldom.createElement(v_preauth_doc, 'record');
        dbms_xmldom.setAttribute(v_elem,'id', v_ctr);
        dbms_xmldom.setAttribute(v_elem,'referencedate',nar_rec.reference_date);
        dbms_xmldom.setAttribute(v_elem,'remarks',nar_rec.remarks);
        dbms_xmldom.setAttribute(v_elem,'user',nar_rec.contact_name);
        v_node := dbms_xmldom.makeNode(v_elem);
        v_parent_node := dbms_xmldom.appendChild( v_root_node, v_node);
        v_ctr := v_ctr + 1;
      END LOOP;

      v_claim_history_doc := dbms_xmldom.getxmltype( v_preauth_doc );

     dbms_xmldom.freeDocument(v_preauth_doc);

   END create_claim_xml;
--============================================================================================================


/*PROCEDURE select_claims_list (
    v_claim_number                   IN  clm_general_details.claim_number%TYPE,
    v_auth_number                    IN  CLM_GENERAL_DETAILS.CLAIM_SETTLEMENT_NUMBER%TYPE,
    v_tpa_enrollment_id              IN  clm_enroll_details.tpa_enrollment_id%TYPE,
    v_clm_status_general_type_id     IN  clm_enroll_details.clm_status_general_type_id%TYPE,
    v_policy_number                  IN  clm_enroll_details.policy_number%TYPE,
    v_date_of_admission                  IN  VARCHAR2,
    v_clm_rcvd_date                      IN  VARCHAR2,
    v_start_date                         IN  VARCHAR2,
    v_end_date                           IN  VARCHAR2,
    v_hosp_seq_id                    IN  TPA_HOSP_INFO.Hosp_Seq_Id%type,
    v_patient_name                   IN clm_enroll_details.claimant_name%type,--kocnewHosp
    v_discharge_date                 IN  VARCHAR2,--kocnewHosp
    v_sort_var                       IN  VARCHAR2,
    v_sort_order                     IN  VARCHAR2,
    v_start_num                      IN  NUMBER ,
    v_end_num                        IN  NUMBER ,
    result_set                       OUT SYS_REFCURSOR
  )
  IS


    TYPE bind_tab_type IS TABLE OF VARCHAR2(250) INDEX BY BINARY_INTEGER ;
    bind_tab                             bind_tab_type;
    i                                    NUMBER(2) := 0;
    v_where                              VARCHAR2(2000);
    v_sql_str                            VARCHAR2(4000);
    v_cnt                                NUMBER(5);
    v_admission_date                     date:=to_date(v_date_of_admission,'DD/MM/YYYY');
    v_received_date                      date:=to_date(v_clm_rcvd_date,'DD/MM/YYYY');
    v_clm_rcvd_start_date                date:=to_date(v_start_date,'DD/MM/YYYY');
    v_clm_rcvd_end_date                  date:=to_date(v_end_date,'DD/MM/YYYY');
    v_date_of_discharge                  date:=to_date(v_discharge_date,'DD/MM/YYYY');

  BEGIN
    v_sql_str :=
       'SELECT
       A.claim_number ,
       B.tpa_enrollment_id ,
       H.hosp_name ,
       b.claimant_name,
       F.contact_name,
       A.date_of_admission ,
       G.auth_number ,
       A.claim_seq_id,
       B.clm_enroll_detail_seq_id,
       G.pat_enroll_detail_seq_id ,
       H.clm_hosp_assoc_seq_id ,
       B.policy_seq_id,
       B.member_seq_id,
       C.tpa_office_seq_id,
       I.buffer_allowed_yn ,
       E.assign_users_seq_id,
       CASE WHEN E.pat_status_general_type_id = ''REQ'' THEN
          CASE WHEN ( SELECT COUNT(1) FROM shortfall_details S  WHERE S.claim_seq_id = a.claim_seq_id
           AND (s.srtfll_status_general_type_id = ''CLS'' OR s.srtfll_status_general_type_id = ''ORD'')) > 1 THEN ''Y'' ELSE ''N'' END
          ELSE ''N'' END AS shrtfall_yn,
       CASE WHEN a.parent_claim_seq_id IS NULL THEN ''N'' ELSE ''Y'' END ammendment_yn ,
       I.Group_Branch_Seq_Id ,
       CASE WHEN j.event_owner = ''C'' THEN ''Y'' ELSE ''N'' END AS coding_review_yn,
       account_info_pkg.get_gen_desc(B.clm_status_general_type_id,''G'') AS CLM_STATUS,A.DATE_OF_DISCHARGE
      FROM clm_general_details A JOIN clm_enroll_details B ON (A.claim_seq_id = b.claim_seq_id)
      JOIN clm_inward C ON ( a.claims_inward_seq_id = c.claims_inward_seq_id AND C.CLAIM_GENERAL_TYPE_ID=''CNH'')
      LEFT OUTER JOIN assign_users E ON (A.last_assign_user_seq_id   = E.assign_users_seq_id)
      LEFT OUTER JOIN tpa_user_contacts F ON (E.assigned_to_user = F.contact_seq_id)
      LEFT OUTER JOIN pat_enroll_details G ON (A.pat_enroll_detail_seq_id  = G.pat_enroll_detail_seq_id)
      JOIN clm_hospital_association H ON (A.claim_seq_id = H.claim_seq_id and h.hosp_seq_id=:v_hosp_seq_id)
      LEFT OUTER JOIN tpa_enr_policy I ON ( B.policy_seq_id = I.policy_seq_id  )
      LEFT OUTER JOIN tpa_event j ON (a.event_seq_id = j.event_seq_id)
      ';
    IF v_clm_status_general_type_id IS NOT NULL THEN
      IF v_clm_status_general_type_id ='PAID' THEN
       v_where := 'join tpa_claims_payment tcp on (a.claim_seq_id=tcp.claim_seq_id)
                    WHERE  TCP.claim_payment_status=:v_clm_status_general_type_id';
      ELSE
       v_where := v_where   ||' AND B.clm_status_general_type_id  = :v_clm_status_general_type_id ';
      END IF;
       i := i+1;
       bind_tab(i) := v_clm_status_general_type_id;
    END IF;

    IF v_claim_number IS NOT NULL THEN
      v_where := v_where   ||' AND A.claim_number = :v_claim_number';
       i := i+1;
       bind_tab(i) := UPPER(v_claim_number);
    END IF;

    IF v_auth_number IS NOT NULL THEN
      v_where := v_where   ||' AND A.CLAIM_SETTLEMENT_NUMBER = :v_auth_number';
       i := i+1;
       bind_tab(i) := UPPER(v_auth_number);
    END IF;


    IF v_tpa_enrollment_id IS NOT NULL THEN

       v_where := v_where   ||' AND B.tpa_enrollment_id = :v_tpa_enrollment_id';
       i := i+1;
       bind_tab(i) := UPPER(v_tpa_enrollment_id);
    END IF;
    IF v_policy_number IS NOT NULL THEN

       v_where := v_where   ||' AND B.policy_number  = :v_policy_number';
       i := i+1;
       bind_tab(i) := UPPER(v_policy_number);
    END IF;


    IF v_date_of_admission IS NOT NULL THEN
       v_where := v_where   ||' AND trunc(a.date_of_admission)  = :v_admission_date';
       i := i+1;
       bind_tab(i) := v_admission_date;
    END IF;

    IF v_clm_rcvd_date IS NOT NULL THEN
       v_where := v_where   ||' AND trunc(c.rcvd_date)  = :v_received_date ';
       i := i+1;
       bind_tab(i) := v_received_date;
    END IF;

    --kocnewHosp1
     IF v_patient_name IS NOT NULL THEN

       v_where := v_where   ||' AND B.claimant_name  like :v_patient_name';
       i := i+1;
       bind_tab(i) := '%'|| UPPER(v_patient_name) ||'%';
    END IF;

    IF v_discharge_date IS NOT NULL THEN
       v_where := v_where   ||' AND trunc(A.Date_Of_Discharge)  = :v_date_of_discharge ';
       i := i+1;
       bind_tab(i) := v_date_of_discharge;
    END IF;

-- for dashborad link v_clm_rcvd_date should be null and start_date and end_date should not be null

    IF v_start_date IS NOT NULL THEN
       v_where := v_where   ||' AND trunc(c.rcvd_date)  >= :v_clm_rcvd_start_date ';
       i := i+1;
       bind_tab(i) := v_clm_rcvd_start_date;
    END IF;

    IF v_end_date IS NOT NULL THEN
       v_where := v_where   ||' AND trunc(c.rcvd_date)  <= :v_clm_rcvd_end_date ';
       i := i+1;
       bind_tab(i) := v_clm_rcvd_end_date;
    END IF;

    v_where := v_where   ||' AND C.inward_status_general_type_id = ''IWC''';

    IF v_where IS NOT NULL THEN
     IF v_clm_status_general_type_id ='PAID' THEN
       v_where:=v_where;
     else
      v_where   := ' WHERE '|| SUBSTR(v_where,5);
     END IF;
    END IF;

    v_sql_str := v_sql_str ||v_where;

    v_sql_str := 'SELECT * FROM
          (SELECT A.*, DENSE_RANK() OVER (ORDER BY '||v_sort_var||' '||v_sort_order||',ROWNUM)
          Q FROM (' ||v_sql_str|| ') A ) WHERE Q>= :v_start_num  AND Q<=  :v_end_num ';


    IF bind_tab.FIRST IS NOT NULL THEN
       CASE bind_tab.COUNT
         WHEN 1  THEN OPEN result_set FOR v_sql_str USING v_hosp_seq_id,bind_tab(1) , v_start_num , v_end_num ;
         WHEN 2  THEN OPEN result_set FOR v_sql_str USING v_hosp_seq_id,bind_tab(1),bind_tab(2), v_start_num , v_end_num ;
         WHEN 3  THEN OPEN result_set FOR v_sql_str USING v_hosp_seq_id,bind_tab(1),bind_tab(2) ,bind_tab(3) , v_start_num , v_end_num ;
         WHEN 4  THEN OPEN result_set FOR v_sql_str USING v_hosp_seq_id,bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) , v_start_num , v_end_num ;
         WHEN 5  THEN OPEN result_set FOR v_sql_str USING v_hosp_seq_id,bind_tab(1),bind_tab(2) ,bind_tab(3),bind_tab(4),bind_tab(5) , v_start_num , v_end_num ;
         WHEN 6  THEN OPEN result_set FOR v_sql_str USING v_hosp_seq_id,bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6) ,v_start_num , v_end_num ;
         WHEN 7  THEN OPEN result_set FOR v_sql_str USING v_hosp_seq_id,bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) , bind_tab(5),bind_tab(6),bind_tab(7),v_start_num , v_end_num ;
         WHEN 8  THEN OPEN result_set FOR v_sql_str USING v_hosp_seq_id,bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) , bind_tab(5),bind_tab(6),bind_tab(7),bind_tab(8),v_start_num , v_end_num ;
         WHEN 9  THEN OPEN result_set FOR v_sql_str USING v_hosp_seq_id,bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) , bind_tab(5),bind_tab(6),bind_tab(7),bind_tab(8),bind_tab(9),v_start_num , v_end_num ;
         WHEN 10  THEN OPEN result_set FOR v_sql_str USING v_hosp_seq_id,bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) , bind_tab(5),bind_tab(6),bind_tab(7),bind_tab(8),bind_tab(9),bind_tab(10),v_start_num , v_end_num ;
         WHEN 11  THEN OPEN result_set FOR v_sql_str USING v_hosp_seq_id,bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) , bind_tab(5),bind_tab(6),bind_tab(7),bind_tab(8),bind_tab(9),bind_tab(10),bind_tab(11),v_start_num , v_end_num ;


         END CASE;
     ELSE
       OPEN result_set FOR v_sql_str USING v_hosp_seq_id,v_start_num , v_end_num ;
     END IF;

  END select_claims_list;*/

--============================================================================================================

/*PROCEDURE select_pre_auth_list (
    v_pre_auth_number                    IN  PAT_ENROLL_DETAILS.pre_auth_number%TYPE,
    v_auth_number                        IN  PAT_ENROLL_DETAILS.AUTH_NUMBER%TYPE,
    v_tpa_enrollment_id                  IN  PAT_ENROLL_DETAILS.tpa_enrollment_id%TYPE,
    v_pat_status_general_type_id         IN  PAT_ENROLL_DETAILS.pat_status_general_type_id%TYPE,
    v_policy_number                      IN  PAT_ENROLL_DETAILS.Policy_Number%TYPE,
    v_date_of_admission                  IN  VARCHAR2,
    v_pat_rcvd_date                      IN  VARCHAR2,
    v_start_date                         IN  VARCHAR2,
    v_end_date                           IN  VARCHAR2,
    v_hosp_seq_id                        IN  TPA_HOSP_INFO.HOSP_SEQ_ID%TYPE,
    v_pateint_name                       IN pat_enroll_details.claimant_name%TYPE,
    v_sort_var                           IN  VARCHAR2,
    v_sort_order                         IN  VARCHAR2 ,
    v_start_num                          IN  NUMBER ,
    v_end_num                            IN  NUMBER ,
    result_set                           OUT SYS_REFCURSOR
  )
  IS

    v_sql_str                            VARCHAR2(4000) ;
    v_lower_limit                        PAT_REQUESTED_AMOUNT_CODE.amount_lower_level%TYPE;
    v_upper_limit                        PAT_REQUESTED_AMOUNT_CODE.amount_upper_level%TYPE;
    TYPE bind_tab_type IS TABLE OF VARCHAR2(250) INDEX BY BINARY_INTEGER ;
    bind_tab                             bind_tab_type;
    i                                    NUMBER(2) := 0;
    v_where                              VARCHAR2(2000);
    v_max_event_seq_id                   tpa_event.event_seq_id%TYPE;
    v_admission_date                     date:=to_date(v_date_of_admission,'DD/MM/YYYY');
    v_received_date                      date:=to_date(v_pat_rcvd_date,'DD/MM/YYYY');
    v_pat_rcvd_start_date                date:=to_date(v_start_date,'DD/MM/YYYY');
    v_pat_rcvd_end_date                  date:=to_date(v_end_date,'DD/MM/YYYY');

  BEGIN
    v_sql_str :=
    ' SELECT
       a.pat_enroll_detail_seq_id ,
       b.pat_gen_detail_seq_id ,
       a.pre_auth_number ,
       C.hosp_seq_id,
       C.hosp_name,
       a.tpa_enrollment_id ,
       a.claimant_name ,
       E.assigned_to_user ,
       E.pat_status_general_type_id ,
       F.contact_name,
       B.pat_received_date,
       b.pat_priority_general_type_id ,
       b.pat_enhanced_yn ,
       CASE WHEN A.pat_status_general_type_id = ''APR'' AND B.completed_yn = ''Y'' AND A.claim_id IS NULL AND B.pat_enhanced_yn = ''N'' THEN ''Y'' ELSE ''N'' END AS enhance_icon_yn,
       b.review_count ,
       b.required_review_count ,
       b.event_seq_id ,
       a.policy_seq_id,
       a.ins_seq_id ,
       A.member_seq_id ,
       g.buffer_allowed_yn,
       b.parent_gen_detail_seq_id,
       CASE WHEN b.parent_gen_detail_seq_id IS NOT NULL THEN ''Y'' ELSE ''N'' END show_band_yn ,
       CASE WHEN ( SELECT COUNT(1) FROM shortfall_details S  WHERE S.pat_gen_detail_seq_id  = b.pat_gen_detail_seq_id
           AND (s.srtfll_status_general_type_id IN (''RES''))) > 0 THEN ''Y'' ELSE ''N'' END AS shrtfall_yn,
       CASE WHEN G.completed_yn = ''Y'' AND G.endorsement_seq_id IS NULL THEN ''Y'' ELSE ''N'' END AS ready_to_process_yn ,
       E.assign_users_seq_id,
       A.tpa_office_seq_id ,
       b.pre_auth_dms_reference_id,
       G.Group_Branch_Seq_Id  ,
       CASE WHEN i.event_owner = ''C'' THEN ''Y'' ELSE ''N'' END AS coding_review_yn ,
       CASE WHEN B.completed_yn = ''Y'' AND a.pat_status_general_type_id = ''REJ'' THEN ''Y'' ELSE ''N'' END AS reject_complete_yn,
       account_info_pkg.get_gen_desc(A.pat_status_general_type_id,''G'') AS PAT_STATUS
       FROM pat_enroll_details A JOIN pat_general_details B ON (a.pat_enroll_detail_seq_id = b.pat_enroll_detail_seq_id and b.pat_enhanced_yn = ''N'')
       JOIN tpa_hosp_info C ON (A.hosp_seq_id = C.hosp_seq_id AND c.hosp_seq_id=:v_hosp_seq_id)
       LEFT OUTER JOIN assign_users E ON (B.last_assign_user_seq_id  = E.assign_users_seq_id)
       LEFT OUTER JOIN tpa_user_contacts F ON (E.assigned_to_user = F.contact_seq_id)
       LEFT OUTER JOIN tpa_enr_policy G ON (A.policy_seq_id = G.policy_seq_id)
       LEFT OUTER JOIN tpa_group_registration H ON (a.group_reg_seq_id = h.group_reg_seq_id)
       LEFT OUTER JOIN tpa_event i ON (b.event_seq_id = i.event_seq_id)
       LEFT OUTER JOIN TPA_CALL_PAT_INTIMATION ci ON (ci.member_seq_id = a.member_seq_id)
       ';

    IF v_pre_auth_number IS NOT NULL THEN
      v_where := v_where  ||' AND A.pre_auth_number = :v_pre_auth_number ';
       i := i+1;
       bind_tab(i) := UPPER(v_pre_auth_number);
    END IF;

    IF v_auth_number IS NOT NULL THEN
      v_where := v_where  ||' AND A.auth_number = :v_auth_number ';
       i := i+1;
       bind_tab(i) := UPPER(v_auth_number);
    END IF;

    IF v_tpa_enrollment_id IS NOT NULL THEN
      v_where := v_where  ||' AND A.tpa_enrollment_id = :v_tpa_enrollment_id';
       i := i+1;
       bind_tab(i) := UPPER(v_tpa_enrollment_id);
    END IF;



    IF v_policy_number IS NOT NULL THEN
      v_where := v_where  ||' AND A.policy_number = :v_policy_number';
      i := i+1;
      bind_tab(i) := UPPER(v_policy_number);
    END IF;



    IF v_pat_status_general_type_id IS NOT NULL THEN
      v_where := v_where  ||' AND A.pat_status_general_type_id = :v_pat_status_general_type_id ';
       i := i+1;
       bind_tab(i) := v_pat_status_general_type_id;
    END IF;

  IF v_date_of_admission IS NOT NULL THEN
       v_where := v_where   ||' AND trunc(a.DATE_OF_HOSPITALIZATION)  = :v_admission_date';
       i := i+1;
       bind_tab(i) := v_admission_date;
    END IF;

    IF v_pat_rcvd_date IS NOT NULL THEN
       v_where := v_where   ||' AND trunc(B.PAT_RECEIVED_DATE)  = :v_received_date ';
       i := i+1;
       bind_tab(i) := v_received_date;
    END IF;

    --KOCnEWhOSP1
    IF v_pateint_name IS NOT NULL THEN
      v_where := v_where  ||' AND A.claimant_name like :v_pateint_name';
      i := i+1;
      bind_tab(i) := '%'|| UPPER(v_pateint_name) ||'%';
    END IF;

-- for dashborad link v_pat_rcvd_date should be null and start_date and end_date should not be null
    IF v_start_date IS NOT NULL THEN
       v_where := v_where   ||' AND trunc(B.PAT_RECEIVED_DATE)  >= :v_pat_rcvd_start_date ';
       i := i+1;
       bind_tab(i) := v_pat_rcvd_start_date;
    END IF;

    IF v_end_date IS NOT NULL THEN
       v_where := v_where   ||' AND trunc(B.PAT_RECEIVED_DATE)  <= :v_pat_rcvd_end_date ';
       i := i+1;
       bind_tab(i) := v_pat_rcvd_end_date;
    END IF;

    IF v_where IS NOT NULL THEN
      v_where   := ' WHERE '|| SUBSTR(v_where,5);
      v_sql_str := v_sql_str ||v_where;
    END IF;



    v_sql_str := 'SELECT * FROM
        (SELECT A.*,DENSE_RANK() OVER (ORDER BY '||v_sort_var||' '||v_sort_order||',ROWNUM)
        Q FROM (' ||v_sql_str|| ') A ) WHERE  Q>= :v_start_num AND Q<= :v_end_num ';

dbms_output.put_line(v_sql_str);
    IF bind_tab.FIRST IS NOT NULL THEN
       CASE bind_tab.COUNT
         WHEN 1  THEN OPEN result_set FOR v_sql_str USING v_hosp_seq_id,bind_tab(1), v_start_num , v_end_num ;
         WHEN 2  THEN OPEN result_set FOR v_sql_str USING v_hosp_seq_id,bind_tab(1),bind_tab(2), v_start_num , v_end_num ;
         WHEN 3  THEN OPEN result_set FOR v_sql_str USING v_hosp_seq_id,bind_tab(1),bind_tab(2) ,bind_tab(3) , v_start_num , v_end_num ;
         WHEN 4  THEN OPEN result_set FOR v_sql_str USING v_hosp_seq_id,bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) , v_start_num , v_end_num ;
         WHEN 5  THEN OPEN result_set FOR v_sql_str USING v_hosp_seq_id,bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) , bind_tab(5),v_start_num , v_end_num ;
         WHEN 6  THEN OPEN result_set FOR v_sql_str USING v_hosp_seq_id,bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) , bind_tab(5),bind_tab(6),v_start_num , v_end_num ;
         WHEN 7  THEN OPEN result_set FOR v_sql_str USING v_hosp_seq_id,bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) , bind_tab(5),bind_tab(6),bind_tab(7),v_start_num , v_end_num ;
         WHEN 8  THEN OPEN result_set FOR v_sql_str USING v_hosp_seq_id,bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) , bind_tab(5),bind_tab(6),bind_tab(7),bind_tab(8),v_start_num , v_end_num ;
         WHEN 9  THEN OPEN result_set FOR v_sql_str USING v_hosp_seq_id,bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) , bind_tab(5),bind_tab(6),bind_tab(7),bind_tab(8),bind_tab(9),v_start_num , v_end_num ;
         WHEN 10  THEN OPEN result_set FOR v_sql_str USING v_hosp_seq_id,bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) , bind_tab(5),bind_tab(6),bind_tab(7),bind_tab(8),bind_tab(9),bind_tab(10),v_start_num , v_end_num ;
         END CASE;
     ELSE
       OPEN result_set FOR v_sql_str USING v_hosp_seq_id,v_start_num , v_end_num ;
     END IF;

  END select_pre_auth_list;*/

--============================================================================================================

PROCEDURE select_enrollment_id_list (
    v_tpa_enrollment_id                  IN  PAT_ENROLL_DETAILS.tpa_enrollment_id%TYPE,
    v_policy_number                      IN  PAT_ENROLL_DETAILS.policy_number%TYPE,
    v_sort_var                           IN VARCHAR2,
    v_sort_order                         IN VARCHAR2,
    v_start_num                          IN NUMBER ,
    v_end_num                            IN NUMBER,
    v_current_record_yn                  IN CHAR  ,
    result_set                           OUT SYS_REFCURSOR
  )
  IS
    v_sql_str                            VARCHAR2(6000);
    v_creditcard_no                      tpa_enr_policy_group.creditcard_no%TYPE;
    v_where                              VARCHAR2(3000);
    TYPE bind_tab_type IS TABLE OF VARCHAR2(250) INDEX BY BINARY_INTEGER ;
    bind_tab                             bind_tab_type;
    i                                    NUMBER(2) := 0;
    v_id_selected_yn                     VARCHAR2(1) := 'N';
  BEGIN

    v_sql_str :=
         ' SELECT
          A.member_seq_id,
          A.policy_group_seq_id,
          A.tpa_enrollment_id,
          A.mem_name,
          B.insured_name ,
          A.gender_general_type_id,
          A.relship_type_id,
          D.description gender,
          A.mem_age,
          C.policy_number,
          C.ins_seq_id,
          E.ins_comp_name,
          E.ins_comp_code_number ,
          C.group_reg_seq_id,
          F.group_name,
          F.group_id||CASE WHEN F.office_number IS NULL OR F.office_number = ''000'' THEN  NULL ELSE ''-''||F.office_number END group_id ,
          A.date_of_inception,
          A.date_of_exit,
          CASE WHEN a.mem_general_type_id = ''PFL'' THEN B.floater_sum_insured ELSE a.mem_tot_sum_insured END AS mem_tot_sum_insured ,
          NULL AS  avail_sum_insured ,
          A.category_general_type_id,
          G.description category,
          C.enrol_type_id,
          C.product_seq_id,
          C.policy_sub_general_type_id,
          C.ins_status_general_type_id,
          C.tpa_status_general_type_id,
          CASE WHEN H.mobile_no IS NULL THEN H.res_phone_no ELSE ttk_util_pkg.fn_decrypt(H.mobile_no) END AS phone,--modified for koc11ed
          C.effective_from_date,
          C.effective_to_date,
          C.policy_seq_id ,
          c.buffer_allowed_yn ,
          c.total_buffer_amount ,
          c.ins_head_office_seq_id,
          C.ins_scheme||''/''|| A.certificate_no AS scheme_or_certficate ,
          B.employee_no ,
          a.deleted_yn AS member_deleted_yn,
          c.deleted_yn AS policy_deleted_yn,
          b.deleted_yn AS family_deleted_yn,
          a.renew_yn,
          c.prev_policy_seq_id,
          c.completed_yn ,
          ttk_util_pkg.fn_decrypt(i.email_id) email_id, --modified column for koc11ed
          a.ins_customer_code,
          b.certificate_no,
          c.ins_scheme,
          ttk_util_pkg.fn_decrypt(b.creditcard_no)  as creditcard_no  --modified column for koc11ed
         FROM tpa_enr_policy_member A JOIN tpa_enr_policy_group B ON (A.policy_group_seq_id = B.policy_group_seq_id)
         JOIN tpa_enr_policy C ON (B.policy_seq_id = C.policy_seq_id )
         JOIN tpa_general_code D ON (A.gender_general_type_id = D.general_type_id)
         JOIN tpa_ins_info E ON (C.ins_seq_id = E.ins_seq_id)
         LEFT OUTER JOIN tpa_group_registration F ON (C.group_reg_seq_id = F.group_reg_seq_id)
         LEFT OUTER JOIN tpa_general_code G ON (A.category_general_type_id = G.general_type_id)
         LEFT OUTER JOIN tpa_enr_mem_address H ON (A.enr_address_seq_id = H.enr_address_seq_id)
         LEFT OUTER JOIN tpa_enr_mem_address I ON (B.enr_address_seq_id = I.enr_address_seq_id) ';

       IF v_tpa_enrollment_id IS NOT NULL THEN
         v_where := v_where ||' AND A.tpa_enrollment_id = :v_tpa_enrollment_id ';
         i := i+1;
         bind_tab(i) := UPPER(v_tpa_enrollment_id) ;
         v_id_selected_yn := 'Y';
       END IF;

        IF v_policy_number IS NOT NULL THEN
         IF v_current_record_yn = 'Y' THEN
         v_where := v_where  ||' AND C.policy_number = :v_policy_number AND (TRUNC(SYSDATE) BETWEEN C.EFFECTIVE_FROM_DATE AND C.EFFECTIVE_TO_DATE)';
         ELSE
         v_where := v_where  ||' AND C.policy_number = :v_policy_number ';
         END IF;
         i := i+1;
         bind_tab(i) := UPPER(v_policy_number) ;
       END IF;

       v_where := ' WHERE '|| SUBSTR(v_where,5);
       v_sql_str := ' WITH all_members AS ('||v_sql_str ||v_where||' )';


       v_sql_str := v_sql_str ||' SELECT * FROM all_members WHERE member_deleted_yn = ''N'' AND policy_deleted_yn = ''N''  AND family_deleted_yn = ''N'' AND completed_yn = ''Y''';

       IF v_policy_number IS NULL THEN
         v_sql_str := v_sql_str ||' AND renew_yn = ''N''';
       END IF;

       IF v_current_record_yn = 'N' AND v_policy_number IS NULL  THEN
        v_sql_str := v_sql_str||
        'UNION
          SELECT B.* FROM all_members A JOIN all_members B ON (A.prev_policy_seq_id = B.policy_seq_id  AND A.renew_yn = ''N'')
         WHERE B.renew_yn = ''Y'' AND B.member_deleted_yn = ''N'' AND B.policy_deleted_yn = ''N''  AND B.family_deleted_yn = ''N''';
       END IF;

       v_sql_str := 'SELECT * FROM
            (SELECT A.*,DENSE_RANK() OVER (ORDER BY '||v_sort_var||' '||v_sort_order||',ROWNUM)
            Q FROM (' ||v_sql_str||') A ) WHERE Q>= :v_start_num  AND Q<= :v_end_num ' ;

       CASE bind_tab.COUNT
         WHEN 1  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),v_start_num,v_end_num ;
         WHEN 2  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2) , v_start_num , v_end_num ;
        END CASE;

  END select_enrollment_id_list;
--============================================================================================================

PROCEDURE select_enrollment_id (
    v_member_seq_id                      IN  PAT_ENROLL_DETAILS.tpa_enrollment_id%TYPE,
    result_set                           OUT SYS_REFCURSOR
  )
  IS

  BEGIN

    OPEN result_set FOR
         SELECT
          A.member_seq_id,
          A.policy_group_seq_id,
          A.tpa_enrollment_id,
          A.mem_name,
          B.insured_name ,
          A.gender_general_type_id,
          A.relship_type_id,
          D.description gender,
          A.mem_age,
          C.policy_number,
          C.ins_seq_id,
          E.ins_comp_name,
          E.ins_comp_code_number ,
          C.group_reg_seq_id,
          F.group_name,
          F.group_id||CASE WHEN F.office_number IS NULL OR F.office_number = '000' THEN  NULL ELSE '-'||F.office_number END group_id ,
          A.date_of_inception,
          A.date_of_exit,
          CASE WHEN a.mem_general_type_id = 'PFL' THEN B.floater_sum_insured ELSE a.mem_tot_sum_insured END AS mem_tot_sum_insured ,
          NULL AS  avail_sum_insured ,
          A.category_general_type_id, -------
          G.description category,     -------
          C.enrol_type_id,
          C.product_seq_id,  ------
          C.policy_sub_general_type_id,
          C.ins_status_general_type_id,
          C.tpa_status_general_type_id,
          CASE WHEN H.mobile_no IS NULL THEN H.res_phone_no ELSE ttk_util_pkg.fn_decrypt(H.mobile_no) END AS phone,--modified column for koc11ed
          C.effective_from_date,
          C.effective_to_date,
          C.policy_seq_id ,
          c.buffer_allowed_yn ,
          c.total_buffer_amount ,
          c.ins_head_office_seq_id,
          C.ins_scheme||'/'|| A.certificate_no AS scheme_or_certficate ,
          B.employee_no ,
          a.deleted_yn AS member_deleted_yn,
          c.deleted_yn AS policy_deleted_yn,
          b.deleted_yn AS family_deleted_yn,
          a.renew_yn,
          c.prev_policy_seq_id,
          c.completed_yn ,
          ttk_util_pkg.fn_decrypt(i.email_id) email_id ,--modified column for koc11ed
          a.ins_customer_code,
          b.certificate_no,
          c.ins_scheme,
          ttk_util_pkg.fn_decrypt(b.creditcard_no) as creditcard_no, --modified column for koc11ed
          A.VIP_YN -- ADDED FOR CR KOC1136
         FROM tpa_enr_policy_member A JOIN tpa_enr_policy_group B ON (A.policy_group_seq_id = B.policy_group_seq_id)
         JOIN tpa_enr_policy C ON (B.policy_seq_id = C.policy_seq_id )
         JOIN tpa_general_code D ON (A.gender_general_type_id = D.general_type_id)
         JOIN tpa_ins_info E ON (C.ins_seq_id = E.ins_seq_id)
         LEFT OUTER JOIN tpa_group_registration F ON (C.group_reg_seq_id = F.group_reg_seq_id)
         LEFT OUTER JOIN tpa_general_code G ON (A.category_general_type_id = G.general_type_id)
         LEFT OUTER JOIN tpa_enr_mem_address H ON (A.enr_address_seq_id = H.enr_address_seq_id)
         LEFT OUTER JOIN tpa_enr_mem_address I ON (B.enr_address_seq_id = I.enr_address_seq_id)
         WHERE a.member_seq_id = v_member_seq_id ;

  END select_enrollment_id;
 --============================================================================================================

/*PROCEDURE save_claim (
    -- CLM_ENROLL_DETAILS
    v_clm_enroll_detail_seq_id           IN  OUT CLM_ENROLL_DETAILS.clm_enroll_detail_seq_id%TYPE,
    v_claim_seq_id                       IN  OUT CLM_ENROLL_DETAILS.claim_seq_id%TYPE,
    v_gender_general_type_id             IN  CLM_ENROLL_DETAILS.gender_general_type_id%TYPE,
    v_member_seq_id                      IN  CLM_ENROLL_DETAILS.member_seq_id%TYPE,
    v_tpa_enrollment_id                  IN  CLM_ENROLL_DETAILS.tpa_enrollment_id%TYPE,
    v_policy_seq_id                      IN  CLM_ENROLL_DETAILS.policy_seq_id%TYPE,
    v_policy_holder_name                 IN  CLM_ENROLL_DETAILS.policy_holder_name%TYPE,
    v_employee_no                        IN  CLM_ENROLL_DETAILS.employee_no%TYPE,
    v_employee_name                      IN  CLM_ENROLL_DETAILS.employee_name%TYPE,
    v_mem_age                            IN  CLM_ENROLL_DETAILS.mem_age%TYPE,
    v_claimant_name                      IN  CLM_ENROLL_DETAILS.claimant_name%TYPE,
    v_date_of_inception                  IN  CLM_ENROLL_DETAILS.date_of_inception%TYPE,
    v_date_of_exit                       IN  CLM_ENROLL_DETAILS.date_of_exit%TYPE,
    v_relship_type_id                    IN  CLM_ENROLL_DETAILS.relship_type_id%TYPE,
    v_policy_number                      IN  CLM_ENROLL_DETAILS.policy_number%TYPE,
    v_claimant_phone_number              IN  CLM_ENROLL_DETAILS.claimant_phone_number%TYPE,
    v_mem_total_sum_insured              IN  CLM_ENROLL_DETAILS.mem_total_sum_insured%TYPE,
    v_enrol_type_id                      IN  CLM_ENROLL_DETAILS.enrol_type_id%TYPE,
    v_policy_sub_general_type_id         IN  CLM_ENROLL_DETAILS.policy_sub_general_type_id%TYPE,
    v_phone_1                            IN  CLM_ENROLL_DETAILS.phone_1%TYPE,
    v_policy_effective_from              IN  CLM_ENROLL_DETAILS.policy_effective_from%TYPE,
    v_policy_effective_to                IN  CLM_ENROLL_DETAILS.policy_effective_to%TYPE,
    v_ins_status_general_type_id         IN  CLM_ENROLL_DETAILS.ins_status_general_type_id%TYPE,
    v_ins_seq_id                         IN  CLM_ENROLL_DETAILS.ins_seq_id%TYPE,
    v_group_reg_seq_id                   IN  CLM_ENROLL_DETAILS.group_reg_seq_id%TYPE,
-----CLM_GENERAL_DETAILS
    v_claims_inward_seq_id               IN  out CLM_GENERAL_DETAILS.claims_inward_seq_id%TYPE,
    v_requested_amount                   IN  CLM_GENERAL_DETAILS.requested_amount%TYPE,
    v_pat_enroll_detail_seq_id           IN  CLM_GENERAL_DETAILS.pat_enroll_detail_seq_id%TYPE,
    v_auth_number                        IN  CLM_GENERAL_DETAILS.auth_number%TYPE,
    v_request_general_type_id            IN  CLM_GENERAL_DETAILS.request_general_type_id%TYPE,
    v_claim_sub_general_type_id          IN  CLM_GENERAL_DETAILS.claim_sub_general_type_id%TYPE,
    v_reason_for_dom                     IN  clm_general_details.DOM_REASON_GEN_TYPE_ID%type,--KOC1285
    v_doctor_certified_YN                IN  CLM_GENERAL_DETAILS.DOC_CERT_DOM_YN%type,--KOC1285
    v_mode_general_type_id               IN  CLM_GENERAL_DETAILS.mode_general_type_id%TYPE,
    v_treating_dr_name                   IN  CLM_GENERAL_DETAILS.treating_dr_name%TYPE,
    v_in_patient_no                      IN  CLM_GENERAL_DETAILS.in_patient_no%TYPE,
    v_claims_remarks                     IN  CLM_GENERAL_DETAILS.claims_remarks%TYPE,
    v_ava_sum_insured                    IN  OUT CLM_GENERAL_DETAILS.ava_sum_insured%TYPE,
    v_ava_cum_bonus                      IN  OUT CLM_GENERAL_DETAILS.ava_cum_bonus%TYPE,
    v_date_of_admission                  IN  CLM_GENERAL_DETAILS.date_of_admission%TYPE,
    v_date_of_discharge                  IN  CLM_GENERAL_DETAILS.date_of_discharge%TYPE,
    v_parent_claim_seq_id                IN  OUT CLM_GENERAL_DETAILS.parent_claim_seq_id%TYPE,
----CLM_HOSPITAL_ASSOCIATION
    v_clm_hosp_assoc_seq_id              IN  OUT CLM_HOSPITAL_ASSOCIATION.clm_hosp_assoc_seq_id%TYPE,
    v_hosp_seq_id                        IN  CLM_HOSPITAL_ASSOCIATION.hosp_seq_id%TYPE,
    v_empanel_number                     IN  CLM_HOSPITAL_ASSOCIATION.empanel_number%TYPE,
    v_hosp_name                          IN  OUT CLM_HOSPITAL_ASSOCIATION.hosp_name%TYPE,
    v_address_1                          IN  OUT CLM_HOSPITAL_ASSOCIATION.address_1%TYPE,
    v_address_2                          IN  OUT CLM_HOSPITAL_ASSOCIATION.address_2%TYPE,
    v_address_3                          IN  OUT CLM_HOSPITAL_ASSOCIATION.address_3%TYPE,
    v_state_name                         IN  OUT CLM_HOSPITAL_ASSOCIATION.state_name%TYPE,
    v_city_name                          IN  OUT CLM_HOSPITAL_ASSOCIATION.city_name%TYPE,
    v_pin_code                           IN  OUT CLM_HOSPITAL_ASSOCIATION.pin_code%TYPE,
    v_off_phone_no_1                     IN  OUT CLM_HOSPITAL_ASSOCIATION.off_phone_no_1%TYPE,
    v_off_phone_no_2                     IN  OUT CLM_HOSPITAL_ASSOCIATION.off_phone_no_2%TYPE,
    v_office_fax_no                      IN  OUT CLM_HOSPITAL_ASSOCIATION.office_fax_no%TYPE,
    v_remarks                            IN  CLM_HOSPITAL_ASSOCIATION.remarks%TYPE,
    v_serv_tax_rgn_number                IN  CLM_HOSPITAL_ASSOCIATION.serv_tax_rgn_number%TYPE,
-----CLM_HOSPITAL_ADDITIONAL_DTL
    v_prev_hosp_claim_seq_id             IN  OUT CLM_GENERAL_DETAILS.prev_hosp_claim_seq_id%TYPE,
    v_claim_dms_reference_id             IN  CLM_GENERAL_DETAILS.claim_dms_reference_id%TYPE,
    v_pat_approved_amount                IN  CLM_GENERAL_DETAILS.pat_approved_amount%TYPE,
    v_re_open_type                       IN  CLM_GENERAL_DETAILS.re_open_type%TYPE,
    v_doctor_registration_no             IN  CLM_GENERAL_DETAILS.doctor_registration_no%TYPE,
    v_email_id                           IN  CLM_ENROLL_DETAILS.email_id%TYPE,
    v_notification_phone_number          IN  CLM_ENROLL_DETAILS.notification_phone_number%TYPE,
    v_ins_scheme                         IN  PAT_ENROLL_DETAILS.ins_scheme%TYPE,
    v_certificate_no                     IN  PAT_ENROLL_DETAILS.certificate_no%TYPE,
    v_ins_customer_code                  IN  PAT_ENROLL_DETAILS.ins_customer_code%TYPE,
    v_insur_ref_number                   IN  CLM_GENERAL_DETAILS.Insur_Ref_Number%TYPE, --insur-ref-number
    v_added_by                           IN  CLM_HOSPITAL_ADDITIONAL_DTL.added_by%TYPE,
    v_rows_processed                     IN  OUT NUMBER,
    v_last_buffer_detail_seq_id          IN  buffer_details.buff_detail_seq_id%TYPE := NULL,
    v_parent_modif_mode_value            IN  CLM_ENROLL_DETAILS.modification_mode_value%TYPE := NULL,
    v_tpa_office_seq_id                  IN OUT CLM_INWARD.tpa_office_seq_id%TYPE  ,
    v_received_date                      IN clm_inward.rcvd_date%type)

  IS
    v_last_buff_detail_seq_id            buffer_details.buff_detail_seq_id%TYPE := v_last_buffer_detail_seq_id;
    v_discrepancy_present_yn             CLM_GENERAL_DETAILS.discrepancy_present_yn%TYPE;
    v_claim_settlement_number            CLM_GENERAL_DETAILS.claim_settlement_number%TYPE;
    v_call_log_seq_id                    CLM_GENERAL_DETAILS.call_log_seq_id%TYPE;
    v_data_discrepancy_present_yn        CHAR(1) := 'N';

    dis_name_yn                          CHAR(1);
    dis_gend_yn                          CHAR(1);
    dis_age_yn                           CHAR(1);
    dis_policy_num_yn                    CHAR(1);
    dis_policy_holder_yn                 CHAR(1);
    v_call_type                          VARCHAR2(3):= 'EXT';
    v_prev_member_seq_id                 clm_enroll_details.member_seq_id%TYPE;
    v_check_member_seq_id                tpa_enr_policy_member.member_seq_id%TYPE;
    v_modification_mode_value            pat_enroll_details.modification_mode_value%TYPE;
    v_change_mode_value                  pat_enroll_details.modification_mode_value%TYPE;
    v_effective_from_date                tpa_enr_policy.effective_from_date%TYPE;
    v_effective_to_date                  tpa_enr_policy.effective_to_date%TYPE;
    v_prev_policy_number                 tpa_enr_policy.policy_number%TYPE;
    v_prev_date_of_exit                  tpa_enr_policy_member.date_of_exit%TYPE;
    v_old_prev_hosp_claim_seq_id         CLM_GENERAL_DETAILS.prev_hosp_claim_seq_id%TYPE; -- patchtogo
    v_event_seq_id                       CLM_GENERAL_DETAILS.event_seq_id%TYPE;
    CURSOR pat_cur IS SELECT a.member_seq_id
      FROM pat_enroll_details a WHERE a.pat_enroll_detail_seq_id = v_pat_enroll_detail_seq_id ;

    CURSOR prev_claim_cur (v_claim_seq_id NUMBER ) IS SELECT a.member_seq_id
      FROM clm_enroll_details a WHERE a.claim_seq_id = v_claim_seq_id ;

    CURSOR prev_hosp_cur IS
       SELECT hosp_regist_number, contact_name,  off_phone_no_1,
          number_of_beds,     fully_equipped_yn,  v_added_by,   SYSDATE
          FROM clm_hospital_additional_dtl a
          WHERE a.clm_hosp_assoc_seq_id = ( SELECT b.clm_hosp_assoc_seq_id FROM clm_hospital_association b
                                            WHERE b.claim_seq_id = v_prev_hosp_claim_seq_id );

    CURSOR hosp_additional_dtl_cur IS
      SELECT a.add_hosp_dtl_seq_id FROM clm_hospital_additional_dtl a
        WHERE a.clm_hosp_assoc_seq_id = v_clm_hosp_assoc_seq_id ;

    CURSOR mem_info_cur IS SELECT a.date_of_inception,a.date_of_exit,c.effective_from_date
      ,c.effective_to_date, c.policy_number ,nvl(a.mem_tot_sum_insured,b.floater_sum_insured) AS mem_tot_sum_insured,
      c.policy_sub_general_type_id
      FROM tpa_enr_policy_member a JOIN tpa_enr_policy_group b ON (a.policy_group_seq_id = b.policy_group_seq_id)
      JOIN tpa_enr_policy c ON (b.policy_seq_id = c.policy_seq_id)
      WHERE a.member_seq_id = v_member_seq_id;

    mem_info_rec                            mem_info_cur%ROWTYPE;
    prev_hosp_rec                           prev_hosp_cur%ROWTYPE;
    v_add_hosp_dtl_seq_id                   clm_hospital_additional_dtl.add_hosp_dtl_seq_id%TYPE;
    v_rcvd_date                             clm_inward.rcvd_date%TYPE:=to_date(v_received_date,'dd/mm/yyyy');
    v_ctr                                   PLS_INTEGER;

    --TO CALL INWARD ENTRY PROCEDURE

    v_barcode_no                       CLM_INWARD.barcode_no%TYPE;
    v_source_general_type_id           CLM_INWARD.source_general_type_id%TYPE:='OLN';
    v_inward_ins_seq_id                CLM_INWARD.inward_ins_seq_id%TYPE;
    v_corporate_name                   CLM_INWARD.corporate_name%TYPE;
    v_inward_stat_general_type_id      CLM_INWARD.inward_status_general_type_id%TYPE:='IWC';
    v_courier_seq_id                   CLM_INWARD.courier_seq_id%TYPE;
    v_shortfall_id                     CLM_INWARD.shortfall_id%TYPE;
    v_claim_number                     CLM_INWARD.claim_number%TYPE;
    v_document_general_type_id         CLM_INWARD.document_general_type_id%TYPE:='DTC';


  BEGIN

CLAIMS_PKG.save_clm_inward_entry(
                  V_CLAIMS_INWARD_SEQ_ID,
                  V_TPA_OFFICE_SEQ_ID,
                  V_BARCODE_NO,
                  V_DOCUMENT_GENERAL_TYPE_ID,
                  V_RCVD_DATE,
                  V_SOURCE_GENERAL_TYPE_ID,
                  'CNH',
                  V_REQUESTED_AMOUNT,
                  V_MEMBER_SEQ_ID,
                  V_TPA_ENROLLMENT_ID,
                  V_CLAIMANT_NAME,
                  V_POLICY_SEQ_ID,
                  V_POLICY_NUMBER,
                  V_INWARD_INS_SEQ_ID,
                  V_CORPORATE_NAME,
                  V_POLICY_HOLDER_NAME,
                  V_EMPLOYEE_NO,
                  V_EMPLOYEE_NAME,
                  V_INWARD_STAT_GENERAL_TYPE_ID,
                  V_REMARKS,
                  V_COURIER_SEQ_ID,
                  V_PARENT_CLAIM_SEQ_ID,
                  V_CLAIM_NUMBER,
                  V_SHORTFALL_ID,
                  v_claim_seq_id,
                  V_CLM_ENROLL_DETAIL_SEQ_ID,
                  V_EMAIL_ID,
                  V_NOTIFICATION_PHONE_NUMBER,
                  V_INS_SCHEME,
                  V_CERTIFICATE_NO,
                  V_INS_CUSTOMER_CODE,
                  V_ADDED_BY,
                  V_ROWS_PROCESSED );


  claims_pkg.claims_freeze(v_claim_seq_id,NULL,'S'); --KOCBJJ
    IF NVL( v_claim_seq_id ,0) != 0  THEN
       SELECT CASE WHEN nvl(ce.member_seq_id,0) = nvl(v_member_seq_id,0) THEN cg.call_log_seq_id
              ELSE NULL END INTO v_call_log_seq_id
       FROM clm_enroll_details ce INNER JOIN clm_general_details cg ON ce.claim_seq_id = cg.claim_seq_id
       AND ce.claim_seq_id = v_claim_seq_id;
         IF v_call_log_seq_id IS NULL THEN
            claims_pkg.unassoc_claim_intimation(v_claim_seq_id,v_call_log_seq_id,v_added_by,v_rows_processed);--KOC1349
         END IF;
    END IF;


    IF NVL( v_claim_seq_id ,0) = 0  THEN
      SELECT a.document_general_type_id, A.tpa_office_seq_id , a.rcvd_date
        INTO v_document_general_type_id , v_tpa_office_seq_id ,  v_rcvd_date
        FROM clm_inward a WHERE a.claims_inward_seq_id = v_claims_inward_seq_id ;

      IF v_document_general_type_id = 'DTA' THEN
        v_call_type := 'INT';
      END IF;
    ELSE
      --locking CLAIM
      TTK_UTIL_PKG.reset_id_flag(v_claim_seq_id||'-CLM','Y');
      --reassigning user
      pre_auth_pkg.reassign_user (  NULL , v_claim_seq_id ,NULL , v_added_by , 'AUT');

      SELECT a.parent_claim_seq_id, b.member_seq_id, a.last_buffer_detail_seq_id , b.modification_mode_value ,
        c.effective_from_date, c.effective_to_date,c.policy_number , A.prev_hosp_claim_seq_id , d.date_of_exit, e.rcvd_date ,
        a.event_seq_id
        INTO v_parent_claim_seq_id, v_prev_member_seq_id , v_last_buff_detail_seq_id  , v_modification_mode_value,
        v_effective_from_date,v_effective_to_date,v_prev_policy_number , v_old_prev_hosp_claim_seq_id ,v_prev_date_of_exit ,v_rcvd_date ,
        v_event_seq_id
        FROM clm_general_details a JOIN clm_enroll_details b ON (a.claim_seq_id = b.claim_seq_id)
        LEFT OUTER JOIN tpa_enr_policy c ON (b.policy_seq_id = c.policy_seq_id)
        LEFT OUTER JOIN tpa_enr_policy_member d ON ( b.member_seq_id = d.member_seq_id )
        JOIN clm_inward e ON (a.claims_inward_seq_id = e.claims_inward_seq_id)
        WHERE a.claim_seq_id = v_claim_seq_id ;
    END IF;

    IF v_modification_mode_value > 0 THEN

      OPEN mem_info_cur;
      FETCH mem_info_cur INTO mem_info_rec;
      CLOSE mem_info_cur;

      IF v_policy_effective_from = mem_info_rec.effective_from_date
            AND v_policy_effective_to = mem_info_rec.effective_to_date
            AND v_policy_number = mem_info_rec.policy_number
            AND v_date_of_exit = mem_info_rec.date_of_exit
            AND nvl(v_mem_total_sum_insured,0) = nvl(mem_info_rec.mem_tot_sum_insured,0)
            AND v_policy_sub_general_type_id = mem_info_rec.policy_sub_general_type_id THEN

        IF policy_enrollment_pkg.check_enrollment_change ( v_modification_mode_value,  2)> 0 THEN
            v_change_mode_value := nvl(v_change_mode_value,0) + 2 ;
        END IF;
        IF policy_enrollment_pkg.check_enrollment_change ( v_modification_mode_value,  8) > 0 THEN
           v_change_mode_value := nvl(v_change_mode_value,0) + 8 ;
        END IF;

        IF policy_enrollment_pkg.check_enrollment_change ( v_modification_mode_value,  32)> 0 THEN
            v_change_mode_value := nvl(v_change_mode_value,0) + 32 ;
        END IF;

        IF policy_enrollment_pkg.check_enrollment_change ( v_modification_mode_value,  64) > 0 THEN
           v_change_mode_value := nvl(v_change_mode_value,0) + 64 ;
        END IF;

        IF trunc(v_date_of_admission) BETWEEN greatest(v_policy_effective_from, v_date_of_inception) AND v_date_of_exit THEN

          IF policy_enrollment_pkg.check_enrollment_change ( v_modification_mode_value, 1) > 0 THEN
            v_change_mode_value := nvl(v_change_mode_value,0) + 1 ;
          END IF;
          IF policy_enrollment_pkg.check_enrollment_change ( v_modification_mode_value, 4) > 0 THEN
            v_change_mode_value := nvl(v_change_mode_value,0) + 4 ;
          END IF;
        END IF;
      END IF;
    END IF;

    IF NVL( v_claim_seq_id ,0) != 0  THEN
      pre_auth_pkg.check_clm_completed ( v_claim_seq_id , NULL,'APP', v_added_by );
    END IF;
    IF v_pat_enroll_detail_seq_id IS NOT NULL THEN
      OPEN pat_cur;
      FETCH pat_cur INTO v_check_member_seq_id;
      CLOSE pat_cur;
      IF nvl(v_member_seq_id,0) != nvl(v_check_member_seq_id,0) THEN
        raise_application_error(-20197,'Member selected for Preauth and that of Claim are different');
      END IF;
      -- if preauth was previously associated to another claim,
      -- this part is to delete buffer records of the previous claim
      IF NVL( v_claim_seq_id ,0) = 0 AND v_parent_claim_seq_id IS NULL THEN

        SELECT COUNT(1) INTO v_ctr
           FROM clm_general_details a JOIN clm_enroll_details b ON (a.claim_seq_id = b.claim_seq_id)
           WHERE a.pat_enroll_detail_seq_id = v_pat_enroll_detail_seq_id
           AND ( a.completed_yn = 'N' OR b.clm_status_general_type_id NOT IN ('REJ','PCO'));
        IF v_ctr > 0 THEN
          raise_application_error(-20182,'Associated Preauth is overridden/re-associated to another claim, please re-associate preauth.');
        END IF;

        FOR rec IN (SELECT a.claim_seq_id FROM clm_general_details a
                     WHERE a.pat_enroll_detail_seq_id = v_pat_enroll_detail_seq_id
                     ORDER BY a.claim_seq_id DESC)
        LOOP
          pre_auth_pkg.delete_claim_buffer(rec.claim_seq_id);
        END LOOP;
      END IF;
    END IF;

    IF v_parent_claim_seq_id IS NULL THEN
      IF v_member_seq_id IS NOT NULL THEN
          pre_auth_pkg.check_discrepancy(
                  v_member_seq_id ,
                  v_claimant_name,
                  v_mem_age  ,
                  v_gender_general_type_id  ,
                  v_policy_holder_name  ,
                  v_policy_number  ,
                  dis_name_yn ,
                  dis_gend_yn ,
                  dis_age_yn ,
                  dis_policy_num_yn ,
                  dis_policy_holder_yn );
        IF dis_name_yn = 'Y' OR  dis_gend_yn = 'Y' OR  dis_age_yn = 'Y' OR   dis_policy_num_yn = 'Y' OR  dis_policy_holder_yn = 'Y' THEN
          v_data_discrepancy_present_yn := 'Y';
        END IF;
      END IF;

      claims_pkg.check_conflict (
              v_claim_seq_id ,
              v_clm_enroll_detail_seq_id ,
              v_policy_seq_id ,
              v_enrol_type_id  ,
              v_tpa_enrollment_id  ,
              v_group_reg_seq_id  ,
              v_employee_no  ,
              v_hosp_seq_id  ,
              v_policy_effective_from ,
              v_policy_effective_to ,
              v_date_of_admission  ,
              v_requested_amount  ,
              v_date_of_discharge,
              v_rcvd_date,
              v_data_discrepancy_present_yn ,
              v_discrepancy_present_yn ,
              v_added_by  ,
              v_member_seq_id
            );
    ELSE
      OPEN prev_claim_cur(v_parent_claim_seq_id);
      FETCH prev_claim_cur INTO v_check_member_seq_id;
      CLOSE prev_claim_cur;
      IF v_member_seq_id != v_check_member_seq_id THEN
        raise_application_error(-20198,'Member selected for this ammendment and previous claim are different');
      END IF;
      IF NVL(v_claim_seq_id,0) = 0 THEN
        SELECT discrepancy_present_yn INTO v_discrepancy_present_yn
           FROM clm_general_details a
          WHERE a.claim_seq_id = v_parent_claim_seq_id ;
      END IF;
    END IF;
    IF v_prev_hosp_claim_seq_id IS NOT NULL THEN
      OPEN prev_claim_cur(v_prev_hosp_claim_seq_id);
      FETCH prev_claim_cur INTO v_check_member_seq_id;
      CLOSE prev_claim_cur;
      IF v_member_seq_id != v_check_member_seq_id THEN
        raise_application_error(-20199,'Member selected for this claim and previous hospitalisation are different');
      END IF;
    END IF;

    claims_pkg.save_general_details(
        v_claim_seq_id  ,
        v_claims_inward_seq_id  ,
        v_member_seq_id ,
        v_requested_amount  ,
        v_pat_enroll_detail_seq_id ,
        v_auth_number     ,
        v_pat_approved_amount ,
        v_request_general_type_id  ,
        v_claim_sub_general_type_id ,
        v_reason_for_dom,--KOC1285
        v_doctor_certified_YN,--KOC1285
        v_call_log_seq_id   ,
        v_mode_general_type_id  ,
        v_treating_dr_name   ,
        v_in_patient_no    ,
        v_claims_remarks   ,
        NULL  ,
        NULL  ,
        NULL  ,
        v_discrepancy_present_yn  ,
        v_date_of_admission   ,
        v_date_of_discharge    ,
        v_parent_claim_seq_id   ,
        v_claim_settlement_number  ,
        v_prev_hosp_claim_seq_id ,
        v_hosp_seq_id,
        v_claim_dms_reference_id ,
        v_policy_seq_id ,
        v_re_open_type ,
        v_doctor_registration_no,
        v_insur_ref_number, --insur-ref-number
        v_last_buff_detail_seq_id,
        v_added_by        ,
        v_rows_processed
      );

     claims_pkg.save_clm_enroll(
        v_clm_enroll_detail_seq_id  ,
        v_claim_seq_id   ,
        v_gender_general_type_id ,
        v_member_seq_id ,
        v_tpa_enrollment_id ,
        v_policy_seq_id  ,
        v_policy_holder_name ,
        v_employee_no  ,
        v_employee_name  ,
        v_mem_age  ,
        v_claimant_name ,
        v_date_of_inception  ,
        v_date_of_exit  ,
        v_relship_type_id  ,
        v_policy_number  ,
        v_claimant_phone_number ,
        v_mem_total_sum_insured ,
        v_enrol_type_id  ,
        v_policy_sub_general_type_id ,
        v_phone_1   ,
        v_policy_effective_from  ,
        v_policy_effective_to  ,
        v_ins_status_general_type_id ,
        v_ins_seq_id     ,
        v_group_reg_seq_id ,
        v_email_id ,
        v_notification_phone_number,
        v_ins_scheme,
        v_certificate_no,
        v_ins_customer_code,
        v_added_by        ,
        v_rows_processed  ,
        v_change_mode_value,
        v_parent_modif_mode_value
        );

    IF v_claim_sub_general_type_id NOT IN ('CSD','HCU') THEN -- ie No hospital details for Domociliary
      claims_pkg.save_hospital_association (
          v_clm_hosp_assoc_seq_id ,
          v_claim_seq_id ,
          v_hosp_seq_id  ,
          v_empanel_number  ,
          v_hosp_name  ,
          v_address_1 ,
          v_address_2  ,
          v_address_3  ,
          v_state_name ,
          v_city_name ,
          v_pin_code  ,
          v_off_phone_no_1 ,
          v_off_phone_no_2 ,
          v_office_fax_no  ,
          v_remarks   ,
          v_serv_tax_rgn_number,
          v_added_by  ,
          v_rows_processed
        );

      IF v_prev_hosp_claim_seq_id IS NOT NULL AND v_hosp_seq_id IS NULL
        AND ( v_old_prev_hosp_claim_seq_id IS NULL OR v_old_prev_hosp_claim_seq_id !=  v_prev_hosp_claim_seq_id ) THEN

         OPEN hosp_additional_dtl_cur;
         FETCH hosp_additional_dtl_cur INTO v_add_hosp_dtl_seq_id;
         CLOSE hosp_additional_dtl_cur;

         OPEN  prev_hosp_cur;
         FETCH prev_hosp_cur INTO prev_hosp_rec;
         CLOSE prev_hosp_cur;

         v_add_hosp_dtl_seq_id := NVL(v_add_hosp_dtl_seq_id,0);

         claims_pkg.save_hosp_additional_dtl(
            v_add_hosp_dtl_seq_id,
            v_clm_hosp_assoc_seq_id ,
            prev_hosp_rec.hosp_regist_number ,
            prev_hosp_rec.contact_name  ,
            prev_hosp_rec.off_phone_no_1 ,
            prev_hosp_rec.number_of_beds ,
            prev_hosp_rec.fully_equipped_yn ,
            v_added_by ,
            v_rows_processed
          );
      END IF;

    END IF;
    IF v_call_type = 'EXT' THEN
      COMMIT;
    END IF;
  END save_claim;*/

--============================================================================================================
PROCEDURE pat_clm_file_upload (
    v_tpa_enrollment_id       IN TPA_ENR_POLICY_MEMBER.TPA_ENROLLMENT_ID%TYPE,
    v_policy_number           IN TPA_ENR_POLICY.POLICY_NUMBER%TYPE,
    v_file_name               IN VARCHAR2,
    v_mode                    IN CHAR , --  'PAT','CLM'
    v_document_type           IN CHAR,
    v_remarks                 IN VARCHAR2,
    v_hosp_seq_id             IN tpa_hosp_info.hosp_seq_id%type,
    v_rows_processed          OUT number
  )
  IS
  cursor mem_cur is
  SELECT  count(1)
        FROM tpa_enr_policy A
        INNER JOIN tpa_enr_policy_group B ON ( A.policy_seq_id = B.Policy_Seq_Id )
        INNER JOIN tpa_enr_policy_member C ON (B.policy_group_seq_id = C.Policy_Group_Seq_Id)
       WHERE (C.tpa_enrollment_id = upper(trim(v_tpa_enrollment_id)) )
             AND a.completed_yn = 'Y'
             AND A.deleted_yn = 'N'
             AND C.deleted_yn = 'N'
             and b.deleted_yn='N'
             AND A.Policy_Status_General_Type_Id != 'POC'
             AND c.status_general_type_id != 'POC';

 v_count number(2);

  BEGIN

  open  mem_cur;
  fetch mem_cur into v_count;
  close mem_cur;

 if v_count=0 then
   raise_application_error(-20834,'Please Enter Valid Vidal/TTK id.');
 end if;

  insert into tpa_pat_clm_file_upload
         (pat_clm_file_seq_id,
          tpa_enrollment_id,
          file_name,
          pat_clm_type,
          policy_number,
          document_type,
          remarks,
          added_by,
          added_date)
  values (tpa_pat_clm_file_seq.nextval,
         v_tpa_enrollment_id,
         v_file_name,
         v_mode,
         v_policy_number,
         v_document_type,
         v_remarks,
         v_hosp_seq_id,
         sysdate);

  v_rows_processed:=sql%rowcount;

  commit;
  END pat_clm_file_upload;
--============================================================================================================

PROCEDURE select_pat_clm_file_upload (
    v_tpa_enrollment_id       IN VARCHAR2,
    v_mode                    IN CHAR , --  'PAT','CLM'
    v_hosp_seq_id             IN tpa_hosp_info.hosp_seq_id%type,
    v_start_date              IN VARCHAR2,
    v_end_date                IN VARCHAR2,
    v_sort_var                IN VARCHAR2,
    v_sort_order              IN VARCHAR2,
    v_start_num               IN NUMBER ,
    v_end_num                 IN NUMBER ,
    v_result_set              OUT sys_refcursor
  )
  IS
    TYPE bind_tab_type IS TABLE OF VARCHAR2(250) INDEX BY BINARY_INTEGER ;
    bind_tab                             bind_tab_type;
    i                                    NUMBER(2) := 0;
    v_where                              VARCHAR2(2000);
    v_sql_str                            VARCHAR2(4000);
    v_cnt                                NUMBER(5);
    v_from_date                          date:=to_date(v_start_date,'dd/mm/yyyy');
    v_to_date                            date:=to_date(v_end_date,'dd/mm/yyyy');

  BEGIN

  v_sql_str:=' select a.tpa_enrollment_id,
         a.file_name,
         a.pat_clm_type,
         a.added_by as hosp_seq_id,
         A.policy_number,
         A.document_type,
         A.remarks,
   from tpa_pat_clm_file_upload a  ';


  IF v_tpa_enrollment_id IS NOT NULL THEN
      v_where := v_where   ||' AND A.tpa_enrollment_id = :v_tpa_enrollment_id';
       i := i+1;
       bind_tab(i) := UPPER(v_tpa_enrollment_id);
    END IF;


    IF v_mode IS NOT NULL THEN

       v_where := v_where   ||' AND A.pat_clm_type = :v_mode';
       i := i+1;
       bind_tab(i) := UPPER(v_mode);
    END IF;
    IF v_hosp_seq_id IS NOT NULL THEN

       v_where := v_where   ||' AND a.added_by  = :v_hosp_seq_id';
       i := i+1;
       bind_tab(i) := UPPER(v_hosp_seq_id);
    END IF;



    IF v_start_date IS NOT NULL THEN
       v_where := v_where   ||' AND trunc(a.added_date) >= :v_from_date ';
       i := i+1;
       bind_tab(i) := v_from_date;
    END IF;


    IF v_end_date IS NOT NULL THEN
       v_where := v_where   ||' AND trunc(a.added_date) <= :v_to_date ';
       i := i+1;
       bind_tab(i) := v_to_date;
    END IF;

    IF v_where IS NOT NULL THEN
      v_where   := ' WHERE '|| SUBSTR(v_where,5);
    END IF;
    v_sql_str := v_sql_str ||v_where;

    v_sql_str := 'SELECT * FROM
          (SELECT A.*, DENSE_RANK() OVER (ORDER BY '||v_sort_var||' '||v_sort_order||',ROWNUM)
          Q FROM (' ||v_sql_str|| ') A ) WHERE Q>= :v_start_num  AND Q<=  :v_end_num ';


    IF bind_tab.FIRST IS NOT NULL THEN
       CASE bind_tab.COUNT
         WHEN 1  THEN OPEN v_result_set FOR v_sql_str USING bind_tab(1) , v_start_num , v_end_num ;
         WHEN 2  THEN OPEN v_result_set FOR v_sql_str USING bind_tab(1),bind_tab(2), v_start_num , v_end_num ;
         WHEN 3  THEN OPEN v_result_set FOR v_sql_str USING bind_tab(1),bind_tab(2) ,bind_tab(3) , v_start_num , v_end_num ;
         WHEN 4  THEN OPEN v_result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) , v_start_num , v_end_num ;
         WHEN 5  THEN OPEN v_result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5), v_start_num , v_end_num ;
         END CASE;
     ELSE
       OPEN v_result_set FOR v_sql_str USING v_start_num , v_end_num ;
     END IF;



 END select_pat_clm_file_upload;
--============================================================================================================

PROCEDURE bills_pending_rpt(
    v_input_list        IN  VARCHAR2,
    v_result_set      OUT SYS_REFCURSOR
  )
  IS
      str_tab    ttk_util_pkg.str_table_type;

  BEGIN
 
     str_tab := ttk_util_pkg.parse_str ( v_input_list );

     OPEN v_result_set FOR

       SELECT D.employee_no,
              D.insured_name AS emp_name,
              A.claimant_name AS claimant_name,
              A.Tpa_Enrollment_Id AS ttk_id,
              A.Pre_Auth_Number,
              TO_CHAR(B.PAT_RECEIVED_DATE,'DD/MM/YYYY HH:MI AM') AS PAT_RECEIVED_DATE,
              B.PAT_REQUESTED_AMOUNT,
              CASE WHEN B.pat_general_type_id = 'REG' THEN 'Regular'
                   WHEN B.pat_general_type_id = 'MAN' THEN 'Manual'
              ELSE 'Manual-Regular' END AS preauth_type,
              TO_CHAR(B.likely_date_of_hospitalization,'DD/MM/YYYY HH:MI AM') AS DOA,
              TO_CHAR(B.likely_date_of_hospitalization  + nvl(F.duration_of_hospitalization,0) ,'DD/MM/YYYY') AS DOD,
              CASE WHEN B.total_app_amount > 0 THEN TRIM( TO_CHAR( B.total_app_amount, '99G99G99G999D99' ) )||' ( '||substr(ttk_util_pkg.num_to_words(B.total_app_amount),2)||')'
                   ELSE ' ' END AS authorised_amt,
              TO_CHAR(A.decision_date,'DD/MM/YYYY HH:MI AM') AS authorised_date,
              H.Hosp_Name,
              F.AILMENT_DESCRIPTION AS ailment,
              E.utilised_buff_amount,
              d.department
       FROM pat_enroll_details A
       JOIN pat_general_details B ON(A.Pat_Enroll_Detail_Seq_Id=B.Pat_Enroll_Detail_Seq_Id AND  B.Pat_Enhanced_Yn='N')
       JOIN tpa_enr_policy_member C ON(A.Member_Seq_Id=C.Member_Seq_Id)
       JOIN tpa_enr_policy_group D ON(C.Policy_Group_Seq_Id=D.Policy_Group_Seq_Id)
       LEFT OUTER JOIN ailment_details F ON(F.Pat_Gen_Detail_Seq_Id=B.Pat_Gen_Detail_Seq_Id)
       JOIN tpa_hosp_info H ON (A.hosp_seq_id = H.hosp_seq_id and h.hosp_seq_id=str_tab(1))
       LEFT OUTER JOIN tpa_enr_balance E ON ((C.Member_Seq_Id = E.Member_Seq_Id AND C.mem_general_type_id = 'PNF') OR
                                             (C.Policy_Group_Seq_Id = E.Policy_Group_Seq_Id AND C.mem_general_type_id != 'PNF'))
       WHERE A.Claim_Id IS NULL AND A.Pat_Status_General_Type_Id='APR'
       AND B.Completed_Yn='Y'
       AND trunc(b.pat_received_date) between to_date(str_tab(2),'dd/mm/yyyy') and  to_date(str_tab(3),'dd/mm/yyyy');
  END bills_pending_rpt;

--============================================================================================================

PROCEDURE Claims_Summary_Rpt(
    v_input_list        IN  VARCHAR2,
    v_clm_rslt_set      OUT SYS_REFCURSOR
  )
  IS
    str_tab    ttk_util_pkg.str_table_type;
  BEGIN
 
    str_tab := ttk_util_pkg.parse_str ( v_input_list );

     --=======Claim Summary
    OPEN v_clm_rslt_set FOR
    SELECT    SUM(tot_rcv_claims) AS tot_rcv_claims,SUM(aprove_clms) AS aprove_clms,SUM(inp_clms)  AS inp_clms,SUM(rejected_clms) AS rejected_clms,
     SUM(closed_clms) AS closed_clms,SUM(shrt_fal_clms) AS shrt_fal_clms,SUM(settled_clms) AS  settled_clms, SUM(pending_clms) AS pending_clms,
                      SUM(requested_amount) AS requested_amount,SUM(aproved_amount) AS aproved_amount,SUM(inp_amount) AS inp_amount,
                 SUM(rejected_amount)AS rejected_amount,SUM(closed_amount) AS closed_amount,SUM(shortfal_amount) AS shortfal_amount,SUM(settled_amount) as settled_amount,SUM(bill_pending_amount) AS bill_pending_amount
     FROM (
        (SELECT COUNT(*) AS tot_rcv_claims,0 aprove_clms,0 inp_clms,0 AS rejected_clms,0 AS closed_clms,0 AS shrt_fal_clms,0 AS  settled_clms,0 AS pending_clms,
                SUM(a.requested_amount) AS requested_amount,0 AS aproved_amount,0 AS inp_amount, 0 AS rejected_amount,0 AS closed_amount,0 AS shortfal_amount,0 as settled_amount,0 AS bill_pending_amount
         FROM clm_general_details a
         JOIN clm_enroll_details  b                ON(a.claim_seq_id            =b.claim_seq_id)
         join clm_hospital_association f on (a.claim_seq_id=f.claim_seq_id and f.hosp_seq_id=str_tab(1) )
         JOIN clm_inward          c                ON(a.claims_inward_seq_id    =c.claims_inward_seq_id AND C.CLAIM_GENERAL_TYPE_ID='CNH')
         JOIN tpa_enr_policy_member d              ON(b.member_seq_id           =d.member_seq_id)
         JOIN tpa_enr_policy_group e               ON(d.policy_group_seq_id=e.policy_group_seq_id)
         WHERE  trunc(c.rcvd_date) between   to_date(str_tab(2),'dd/mm/yyyy')  AND to_date(str_tab(3),'dd/mm/yyyy'))

    UNION ALL
        --======Approved Claims
         (SELECT 0 AS tot_rcv_claims,COUNT(*) AS aprove_clms,0 AS inp_clms,0 AS rejected_clms,0 AS closed_clms,0 AS shrt_fal_clms,0 AS  settled_clms,0 AS pending_clms,
                 0 AS requested_amount,SUM(a.total_app_amount) AS aproved_amount,0 AS inp_amount, 0 AS rejected_amount,0 AS closed_amount,0 AS shortfal_amount,0 as settled_amount,0 AS bill_pending_amount
         FROM clm_general_details a
         JOIN clm_enroll_details  b                ON(a.claim_seq_id            =b.claim_seq_id)
         JOIN clm_inward          c                ON(a.claims_inward_seq_id    =c.claims_inward_seq_id AND C.CLAIM_GENERAL_TYPE_ID='CNH')
         join clm_hospital_association f on (a.claim_seq_id=f.claim_seq_id and f.hosp_seq_id=str_tab(1) )
         JOIN tpa_enr_policy_member d              ON(b.member_seq_id           =d.member_seq_id)
         JOIN tpa_enr_policy_group e               ON(d.policy_group_seq_id=e.policy_group_seq_id)
         WHERE trunc(c.rcvd_date) between   to_date(str_tab(2),'dd/mm/yyyy')  AND to_date(str_tab(3),'dd/mm/yyyy') AND b.clm_status_general_type_id='APR' AND a.completed_yn='Y')

    UNION ALL
          --======Under process Claims
         (SELECT 0 AS tot_rcv_claims,0 AS aprove_clms,count(*) AS inp_clms,0 AS rejected_clms,0 AS closed_clms,0 AS shrt_fal_clms,0 AS  settled_clms,0 AS pending_clms,
                 0 AS requested_amount,0 AS aproved_amount,SUM(a.requested_amount) AS inp_amount, 0 AS rejected_amount,0 AS closed_amount,0 AS shortfal_amount,0 as settled_amount,0 AS bill_pending_amount
         FROM clm_general_details a
         JOIN clm_enroll_details  b                ON(a.claim_seq_id            =b.claim_seq_id)
         JOIN clm_inward          c                ON(a.claims_inward_seq_id    =c.claims_inward_seq_id AND C.CLAIM_GENERAL_TYPE_ID='CNH')
         join clm_hospital_association f on (a.claim_seq_id=f.claim_seq_id and f.hosp_seq_id=str_tab(1) )
         JOIN tpa_enr_policy_member d              ON(b.member_seq_id           =d.member_seq_id)
         JOIN tpa_enr_policy_group e               ON(d.policy_group_seq_id=e.policy_group_seq_id)
         WHERE  trunc(c.rcvd_date) between   to_date(str_tab(2),'dd/mm/yyyy')  AND to_date(str_tab(3),'dd/mm/yyyy') AND( b.clm_status_general_type_id='INP' OR (b.clm_status_general_type_id='APR' AND a.completed_yn='N')))

    UNION ALL
         --======Rejected Claims
         (SELECT 0 AS tot_rcv_claims,0 AS aprove_clms,0 AS inp_clms,COUNT(*) AS rejected_clms,0 AS closed_clms,0 AS shrt_fal_clms,0 AS  settled_clms,0 AS pending_clms,
                 0 AS requested_amount,0 AS aproved_amount,0 AS inp_amount, SUM(a.requested_amount) AS rejected_amount,0 AS closed_amount,0 AS shortfal_amount,0 as settled_amount,0 AS bill_pending_amount
          FROM clm_general_details a
         JOIN clm_enroll_details  b                ON(a.claim_seq_id            =b.claim_seq_id)
         JOIN clm_inward          c                ON(a.claims_inward_seq_id    =c.claims_inward_seq_id AND C.CLAIM_GENERAL_TYPE_ID='CNH')
         join clm_hospital_association f on (a.claim_seq_id=f.claim_seq_id and f.hosp_seq_id=str_tab(1) )
         JOIN tpa_enr_policy_member d              ON(b.member_seq_id           =d.member_seq_id)
         JOIN tpa_enr_policy_group e               ON(d.policy_group_seq_id=e.policy_group_seq_id)
         WHERE  trunc(c.rcvd_date) between   to_date(str_tab(2),'dd/mm/yyyy')  AND to_date(str_tab(3),'dd/mm/yyyy') AND b.clm_status_general_type_id='REJ')
    UNION ALL
    --======Closed Claims
         (SELECT 0 AS tot_rcv_claims,0 AS aprove_clms,0 AS inp_clms,0 AS rejected_clms,COUNT(*) AS closed_clms,0 AS shrt_fal_clms,0 AS  settled_clms,0 AS pending_clms,
                 0 AS requested_amount,0 AS aproved_amount,0 AS inp_amount, 0 AS rejected_amount,SUM(a.requested_amount) AS closed_amount,0 AS shortfal_amount,0 as settled_amount,0 AS bill_pending_amount
          FROM clm_general_details a
         JOIN clm_enroll_details  b                ON(a.claim_seq_id            =b.claim_seq_id)
         JOIN clm_inward          c                ON(a.claims_inward_seq_id    =c.claims_inward_seq_id AND C.CLAIM_GENERAL_TYPE_ID='CNH')
         join clm_hospital_association f on (a.claim_seq_id=f.claim_seq_id and f.hosp_seq_id=str_tab(1) )
         JOIN tpa_enr_policy_member d              ON(b.member_seq_id           =d.member_seq_id)
         JOIN tpa_enr_policy_group e               ON(d.policy_group_seq_id=e.policy_group_seq_id)
         WHERE  trunc(c.rcvd_date) between   to_date(str_tab(2),'dd/mm/yyyy')  AND to_date(str_tab(3),'dd/mm/yyyy') AND b.clm_status_general_type_id='PCO')

    UNION ALL
    --======Shortfall Claims
         (SELECT 0 AS tot_rcv_claims,0 AS aprove_clms,0 AS inp_clms,0 AS rejected_clms,0 AS closed_clms,COUNT(*) AS shrt_fal_clms,0 AS  settled_clms,0 AS pending_clms,
                 0 AS requested_amount,0 AS aproved_amount,0 AS inp_amount, 0 AS rejected_amount,0 AS closed_amount,SUM(a.requested_amount) AS shortfal_amount,0 as settled_amount,0 AS bill_pending_amount
         FROM clm_general_details a
         JOIN clm_enroll_details  b                ON(a.claim_seq_id            =b.claim_seq_id)
         JOIN clm_inward          c                ON(a.claims_inward_seq_id    =c.claims_inward_seq_id AND C.CLAIM_GENERAL_TYPE_ID='CNH')
         join clm_hospital_association f on (a.claim_seq_id=f.claim_seq_id and f.hosp_seq_id=str_tab(1) )
         JOIN tpa_enr_policy_member d              ON(b.member_seq_id           =d.member_seq_id)
         JOIN tpa_enr_policy_group e               ON(d.policy_group_seq_id=e.policy_group_seq_id)
         WHERE trunc(c.rcvd_date) between   to_date(str_tab(2),'dd/mm/yyyy')  AND to_date(str_tab(3),'dd/mm/yyyy') AND b.clm_status_general_type_id='REQ')

   UNION ALL
   --======Settled Claims
         (SELECT 0 AS tot_rcv_claims,0 AS aprove_clms,0 AS inp_clms,0 AS rejected_clms,0 AS closed_clms,0 AS shrt_fal_clms,COUNT(*) AS  settled_clms,0 AS pending_clms,
                0 AS requested_amount,0 AS aproved_amount,0 AS inp_amount, 0 AS rejected_amount,0 AS closed_amount,0 AS shortfal_amount,SUM(a.total_app_amount)  as settled_amount,0 AS bill_pending_amount
         FROM clm_general_details a
         JOIN clm_enroll_details  b                ON(a.claim_seq_id            =b.claim_seq_id)
         JOIN tpa_claims_payment  f                ON(a.claim_seq_id=f.claim_seq_id)
         JOIN clm_inward          c                ON(a.claims_inward_seq_id    =c.claims_inward_seq_id AND C.CLAIM_GENERAL_TYPE_ID='CNH')
         join clm_hospital_association g on (a.claim_seq_id=g.claim_seq_id and g.hosp_seq_id=str_tab(1) )
         JOIN tpa_enr_policy_member d              ON(b.member_seq_id           =d.member_seq_id)
         JOIN tpa_enr_policy_group e               ON(d.policy_group_seq_id=e.policy_group_seq_id)
         WHERE trunc(c.rcvd_date) between   to_date(str_tab(2),'dd/mm/yyyy')  AND to_date(str_tab(3),'dd/mm/yyyy') AND b.clm_status_general_type_id='APR' AND f.claim_payment_status='PAID')
   UNION ALL
   --======Bill pending Claims
         (SELECT 0 AS tot_rcv_claims,0 AS aprove_clms,0 AS inp_clms,0 AS rejected_clms,0 AS closed_clms,0 AS shrt_fal_clms,0 AS  settled_clms,COUNT(*) AS pending_clms,
                 0 AS requested_amount,0 AS aproved_amount,0 AS inp_amount, 0 AS rejected_amount,0 AS closed_amount,0 AS shortfal_amount,0 AS settled_amount,SUM(a.total_app_amount) AS bill_pending_amount
         FROM clm_general_details a
         JOIN clm_enroll_details  b                ON(a.claim_seq_id            =b.claim_seq_id)
         JOIN tpa_claims_payment  f                ON(a.claim_seq_id=f.claim_seq_id)
         JOIN clm_inward          c                ON(a.claims_inward_seq_id    =c.claims_inward_seq_id AND C.CLAIM_GENERAL_TYPE_ID='CNH')
         join clm_hospital_association g on (a.claim_seq_id=g.claim_seq_id and g.hosp_seq_id=str_tab(1) )
         JOIN tpa_enr_policy_member d              ON(b.member_seq_id           =d.member_seq_id)
         JOIN tpa_enr_policy_group e               ON(d.policy_group_seq_id=e.policy_group_seq_id)
         WHERE  trunc(c.rcvd_date) between   to_date(str_tab(2),'dd/mm/yyyy')  AND to_date(str_tab(3),'dd/mm/yyyy') AND b.clm_status_general_type_id='APR' AND f.claim_payment_status!='PAID'));

 END Claims_Summary_Rpt;
--============================================================================================================
PROCEDURE  Claims_Detailed_Rpt (
    v_input_list IN  VARCHAR2,
    v_result_set  OUT SYS_REFCURSOR
  )
  IS
     str_tab    ttk_util_pkg.str_table_type;
  BEGIN
     str_tab := ttk_util_pkg.parse_str ( v_input_list );
 

     OPEN v_result_set FOR

       SELECT D.employee_no,
              D.insured_name AS emp_name,
              A.claimant_name AS claimant_name,
              A.Tpa_Enrollment_Id AS ttk_id,
              B.Claim_Number,
              to_char(i.rcvd_date,'DD/MM/YYYY') AS Clm_rcvd_date,
              B.Requested_Amount,
              to_char(B.Date_Of_Admission,'DD/MM/YYYY') AS DOA,
              to_char(B.Date_Of_Discharge,'DD/MM/YYYY') AS DOD,
              'Network' AS Claim_type,
            --  case when clm_status_general_type_id ='REJ'  AND A.CLM_INS_STATUS='INP' THEN ACCOUNT_INFO_PKG.get_gen_desc('INSR','G') ELSE O.description end AS Clm_Status_General_Type_Id,
              B.claim_settlement_number AS claim_settlement_no,
              to_char(A.decision_date,'DD/MM/YYYY') AS clm_settlement_date,
              b.total_app_amount as final_approval_amount,
              k.check_num,
              to_char(K.check_date,'DD/MM/YYYY') AS check_date,
              nvl(tds.check_amount,g.approved_amount) AS check_amount,
              H.Hosp_Name,
              F.AILMENT_DESCRIPTION AS ailment,
              E.sum_insured,
              (E.sum_insured - E.utilised_sum_insured) AS Balance_SI,
              E.utilised_buff_amount,
              d.department
       FROM clm_enroll_details A
             JOIN clm_general_details B ON (A.claim_seq_id =B.claim_seq_id)
             JOIN clm_inward i ON (b.claims_inward_seq_id = i.claims_inward_seq_id and i.claim_general_type_id='CNH')
             JOIN tpa_enr_policy_member C ON (A.Member_Seq_Id=C.Member_Seq_Id)
             JOIN tpa_enr_policy_group D ON (C.Policy_Group_Seq_Id=D.Policy_Group_Seq_Id)
             LEFT OUTER JOIN clm_ins_intimation_details cii ON (cii.claim_seq_id=B.claim_seq_id)
             LEFT OUTER JOIN ailment_details F ON (F.claim_seq_id=B.claim_seq_id)
             JOIN clm_hospital_association L ON (B.Claim_Seq_Id = L.Claim_Seq_Id )
             JOIN tpa_hosp_info H ON (L.hosp_seq_id = H.hosp_seq_id and h.hosp_seq_id=str_tab(1))
             LEFT OUTER JOIN tpa_claims_payment G ON (B.Claim_Seq_Id = G.Claim_Seq_Id)
             LEFT OUTER JOIN tpa_payment_checks_details J ON (G.payment_seq_id = J.payment_seq_id)
             LEFT OUTER JOIN tpa_claims_check K ON (J.claims_chk_seq_id = K.claims_chk_seq_id)
             LEFT OUTER JOIN tpa_clm_tds_details tds ON (G.payment_seq_id = tds.payment_seq_id)
             JOIN tpa_enr_balance E ON ((C.Member_Seq_Id = E.Member_Seq_Id AND C.mem_general_type_id = 'PNF') OR
                                                   (C.Policy_Group_Seq_Id = E.Policy_Group_Seq_Id AND C.mem_general_type_id != 'PNF'))
             LEFT OUTER JOIN tpa_general_code O ON(A.clm_status_general_type_id=O.general_type_id)
         WHERE  trunc(i.rcvd_date) BETWEEN to_date(str_tab(2),'dd/mm/yyyy') AND to_date(str_tab(3),'dd/mm/yyyy');
  END Claims_Detailed_Rpt;
--============================================================================================================
PROCEDURE forgot_password(
    v_empanel_id       IN       tpa_hosp_info.empanel_number%type,
    v_userid           IN       tpa_user_contacts.employee_number%TYPE,
    v_result           OUT VARCHAR2 )
  IS

   CURSOR GET_HOSP_PWD_CUR IS
           SELECT A.CONTACT_SEQ_ID
          FROM TPA_LOGIN_INFO A
              INNER JOIN TPA_USER_CONTACTS B ON(A.CONTACT_SEQ_ID=B.CONTACT_SEQ_ID)
          WHERE A.USER_ID = v_userid
              AND A.ACTIVE_YN= 'Y' ;

  V_SEQ_ID    TPA_LOGIN_INFO.CONTACT_SEQ_ID%TYPE;
  v_dest_msg_seq_id            DESTINATION_MESSAGE.DEST_MSG_SEQ_ID%TYPE;

  BEGIN
   
   OPEN GET_HOSP_PWD_CUR;
   FETCH GET_HOSP_PWD_CUR INTO V_SEQ_ID;
   CLOSE GET_HOSP_PWD_CUR;

    IF  V_SEQ_ID IS NULL THEN
      v_result:='Please Enter Correct User Id/Empanel Id.';
    ELSE
      UPDATE TPA_LOGIN_INFO A
      SET A.PASSWORD_GENERATED_DATE=SYSDATE
      WHERE A.CONTACT_SEQ_ID=V_SEQ_ID;

         GENERATE_MAIL_PKG.proc_generate_message ('FORGOT_PASSWORD_PROV', V_SEQ_ID,1,v_dest_msg_seq_id );
    END IF;
END forgot_password;
--============================================================================================================
procedure Dashboard_preauth(
    v_input_list        IN  VARCHAR2,
    v_result_set       OUT SYS_REFCURSOR)
is

 str_tab    ttk_util_pkg.str_table_type;


begin

 str_tab := ttk_util_pkg.parse_str ( v_input_list );

open v_result_set for
select sum(inp_preauths) as inprogress,sum(shortfal_preauths) as shortfalls,sum (closed_preauths) as closed ,sum(reject_preauths) as rejected ,sum(apr_preauths) as approved,sum(total_preauths) as Received
from (
SELECT 0 AS inp_preauths,0 as shortfal_preauths,0 as closed_preauths,0 as reject_preauths,0 AS apr_preauths,count(1) as total_preauths
              FROM pat_authorization_details A  
              LEFT OUTER JOIN tpa_enr_policy_member C ON(A.Member_Seq_Id=C.Member_Seq_Id)
              LEFT OUTER JOIN tpa_enr_policy_group D ON(C.Policy_Group_Seq_Id=D.Policy_Group_Seq_Id)
              WHERE a.pat_enhanced_yn ='N'  and a.hosp_seq_id=str_tab(1)
              AND trunc(a.pat_received_date) >= to_date(str_tab(2),'dd/mm/yyyy')
              AND trunc(a.pat_received_date) <= to_date(str_tab(3),'dd/mm/yyyy')
union all
SELECT count(1) AS inp_preauths,0 as shortfal_preauths,0 as closed_preauths,0 as reject_preauths,0 AS apr_preauths,0 as total_preauths
              FROM pat_authorization_details A  
              LEFT OUTER JOIN tpa_enr_policy_member C ON(A.Member_Seq_Id=C.Member_Seq_Id)
              LEFT OUTER JOIN tpa_enr_policy_group D ON(C.Policy_Group_Seq_Id=D.Policy_Group_Seq_Id)
              WHERE a.Pat_Enhanced_Yn='N'  and a.hosp_seq_id=str_tab(1)
              AND trunc(a.pat_received_date) >= to_date(str_tab(2),'dd/mm/yyyy')
              AND trunc(a.pat_received_date) <= to_date(str_tab(3),'dd/mm/yyyy')
              AND A.Pat_Status_Type_Id='INP'
union all
SELECT 0 AS inp_preauths, count(1) as shortfal_preauths,0 as closed_preauths,0 as reject_preauths,0 AS apr_preauths,0 as total_preauths
              FROM pat_authorization_details A 
              LEFT OUTER JOIN tpa_enr_policy_member C ON(A.Member_Seq_Id=C.Member_Seq_Id)
              LEFT OUTER JOIN tpa_enr_policy_group D ON(C.Policy_Group_Seq_Id=D.Policy_Group_Seq_Id)
              WHERE a.Pat_Enhanced_Yn='N'  and a.hosp_seq_id=str_tab(1)
              AND trunc(a.pat_received_date) >= to_date(str_tab(2),'dd/mm/yyyy')
              AND trunc(a.pat_received_date) <= to_date(str_tab(3),'dd/mm/yyyy')
              AND A.Pat_Status_Type_Id='REQ'
union all
SELECT 0 AS inp_preauths,0 as shortfal_preauths,count(1) as closed_preauths,0 as reject_preauths,0 AS apr_preauths,0 as total_preauths
              FROM pat_authorization_details A  
              LEFT OUTER JOIN tpa_enr_policy_member C ON(A.Member_Seq_Id=C.Member_Seq_Id)
              LEFT OUTER JOIN tpa_enr_policy_group D ON(C.Policy_Group_Seq_Id=D.Policy_Group_Seq_Id)
              WHERE a.Pat_Enhanced_Yn='N'  and a.hosp_seq_id=str_tab(1)
              AND trunc(a.pat_received_date) >= to_date(str_tab(2),'dd/mm/yyyy')
              AND trunc(a.pat_received_date) <= to_date(str_tab(3),'dd/mm/yyyy')
              AND A.Pat_Status_Type_Id='PCN'
union all
SELECT 0 AS inp_preauths,0 as shortfal_preauths,0 as closed_preauths,count(1) as reject_preauths,0 AS apr_preauths,0 as total_preauths
              FROM pat_authorization_details A  
              LEFT OUTER JOIN tpa_enr_policy_member C ON(A.Member_Seq_Id=C.Member_Seq_Id)
              LEFT OUTER JOIN tpa_enr_policy_group D ON(C.Policy_Group_Seq_Id=D.Policy_Group_Seq_Id)
              WHERE a.Pat_Enhanced_Yn='N'  and a.hosp_seq_id=str_tab(1)
              AND trunc(a.pat_received_date) >= to_date(str_tab(2),'dd/mm/yyyy')
              AND trunc(a.pat_received_date) <= to_date(str_tab(3),'dd/mm/yyyy')
              AND A.Pat_Status_Type_Id='REJ'
union all
SELECT 0 AS inp_preauths,0 as shortfal_preauths,0 as closed_preauths,0 as reject_preauths,count(1) AS apr_preauths,0 as total_preauths
              FROM pat_authorization_details A  
              LEFT OUTER JOIN tpa_enr_policy_member C ON(A.Member_Seq_Id=C.Member_Seq_Id)
              LEFT OUTER JOIN tpa_enr_policy_group D ON(C.Policy_Group_Seq_Id=D.Policy_Group_Seq_Id)
              WHERE a.Pat_Enhanced_Yn='N'  and a.hosp_seq_id=str_tab(1)
              AND trunc(a.pat_received_date) >= to_date(str_tab(2),'dd/mm/yyyy')
              AND trunc(a.pat_received_date) <= to_date(str_tab(3),'dd/mm/yyyy')
              AND A.Pat_Status_Type_Id='APR');

end Dashboard_preauth;
--============================================================================================================


procedure Dashboard_claims(
    v_input_list        IN  VARCHAR2,
    v_result_set       OUT SYS_REFCURSOR)
is

 str_tab    ttk_util_pkg.str_table_type;


begin

 str_tab := ttk_util_pkg.parse_str ( v_input_list );

open v_result_set for
select sum(inp_claims) as inprogress,sum(shortfal_claims) as shortfalls,sum (closed_claims) as closed ,sum(reject_claims) as rejected ,sum(apr_claims) as approved,sum(total_claims) as Received,sum(paid) as paid
from (

SELECT 0 AS inp_claims,0 as shortfal_claims,0 as closed_claims,0 as reject_claims,0 AS apr_claims,count(1) as total_claims,0 as paid
          FROM clm_authorization_details a
         join clm_hospital_details f on (a.claim_seq_id=f.claim_seq_id and f.hosp_seq_id=str_tab(1) )
         LEFT OUTER  JOIN tpa_enr_policy_member d              ON(a.member_seq_id           =d.member_seq_id)
         LEFT OUTER  JOIN tpa_enr_policy_group e               ON(d.policy_group_seq_id=e.policy_group_seq_id)
         WHERE  trunc(a.clm_received_date) >=   to_date(str_tab(2),'dd/mm/yyyy')
         AND trunc(a.clm_received_date) <= to_date(str_tab(3),'dd/mm/yyyy')

union all
SELECT count(1) AS inp_claims,0 as shortfal_claims,0 as closed_claims,0 as reject_claims,0 AS apr_claims,0 as total_claims,0 as paid
          FROM clm_authorization_details a
         join clm_hospital_details f on (a.claim_seq_id=f.claim_seq_id and f.hosp_seq_id=str_tab(1) )
         LEFT OUTER  JOIN tpa_enr_policy_member d              ON(a.member_seq_id           =d.member_seq_id)
         LEFT OUTER  JOIN tpa_enr_policy_group e               ON(d.policy_group_seq_id=e.policy_group_seq_id)
         WHERE  trunc(a.clm_received_date) >=   to_date(str_tab(2),'dd/mm/yyyy')
         AND trunc(a.clm_received_date) <= to_date(str_tab(3),'dd/mm/yyyy')
         AND a.clm_status_type_id='INP'
union all
SELECT 0 AS inp_claims,count(1) as shortfal_claims,0 as closed_claims,0 as reject_claims,0 AS apr_claims,0 as total_claims,0 as paid
          FROM clm_authorization_details a
         join clm_hospital_details f on (a.claim_seq_id=f.claim_seq_id and f.hosp_seq_id=str_tab(1) )
         LEFT OUTER  JOIN tpa_enr_policy_member d              ON(a.member_seq_id           =d.member_seq_id)
         LEFT OUTER  JOIN tpa_enr_policy_group e               ON(d.policy_group_seq_id=e.policy_group_seq_id)
         WHERE  trunc(a.clm_received_date) >=   to_date(str_tab(2),'dd/mm/yyyy')
         AND trunc(a.clm_received_date) <= to_date(str_tab(3),'dd/mm/yyyy')
         AND a.clm_status_type_id='REQ'
union all
SELECT 0 AS inp_claims,0 as shortfal_claims,count(1) as closed_claims,0 as reject_claims,0 AS apr_claims,0 as total_claims,0 as paid
          FROM clm_authorization_details a
         join clm_hospital_details f on (a.claim_seq_id=f.claim_seq_id and f.hosp_seq_id=str_tab(1) )
         LEFT OUTER  JOIN tpa_enr_policy_member d              ON(a.member_seq_id           =d.member_seq_id)
         LEFT OUTER  JOIN tpa_enr_policy_group e               ON(d.policy_group_seq_id=e.policy_group_seq_id)
         WHERE  trunc(a.clm_received_date) >=   to_date(str_tab(2),'dd/mm/yyyy')
         AND trunc(a.clm_received_date) <= to_date(str_tab(3),'dd/mm/yyyy')
         AND a.clm_status_type_id='PCO'
union all
SELECT 0 AS inp_claims,0 as shortfal_claims,0 as closed_claims,count(1) as reject_claims,0 AS apr_claims,0 as total_claims,0 as paid
          FROM clm_authorization_details a
         join clm_hospital_details f on (a.claim_seq_id=f.claim_seq_id and f.hosp_seq_id=str_tab(1) )
         LEFT OUTER  JOIN tpa_enr_policy_member d              ON(a.member_seq_id           =d.member_seq_id)
         LEFT OUTER  JOIN tpa_enr_policy_group e               ON(d.policy_group_seq_id=e.policy_group_seq_id)
         WHERE  trunc(a.clm_received_date) >=   to_date(str_tab(2),'dd/mm/yyyy')
         AND trunc(a.clm_received_date) <= to_date(str_tab(3),'dd/mm/yyyy')
         AND a.clm_status_type_id='REJ'
union all
SELECT 0 AS inp_claims,0 as shortfal_claims,0 as closed_claims,0 as reject_claims,COUNT(1) AS apr_claims,0 as total_claims,0 as paid
          FROM clm_authorization_details a
         join clm_hospital_details f on (a.claim_seq_id=f.claim_seq_id and f.hosp_seq_id=str_tab(1) )
         LEFT OUTER  JOIN tpa_enr_policy_member d              ON(a.member_seq_id           =d.member_seq_id)
         LEFT OUTER  JOIN tpa_enr_policy_group e               ON(d.policy_group_seq_id=e.policy_group_seq_id)
         WHERE  trunc(a.clm_received_date) >=   to_date(str_tab(2),'dd/mm/yyyy')
         AND trunc(a.clm_received_date) <= to_date(str_tab(3),'dd/mm/yyyy')
         AND a.clm_status_type_id='APR'

UNION ALL
SELECT 0 AS inp_claims,0 as shortfal_claims,0 as closed_claims,0 as reject_claims,0 AS apr_claims,0 as total_claims,COUNT(1) as paid_claims
          FROM clm_authorization_details a
         join clm_hospital_details f on (a.claim_seq_id=f.claim_seq_id and f.hosp_seq_id=str_tab(1) )
         LEFT OUTER  JOIN tpa_enr_policy_member d              ON(a.member_seq_id           =d.member_seq_id)
         LEFT OUTER  JOIN tpa_enr_policy_group e               ON(d.policy_group_seq_id=e.policy_group_seq_id)
         join tpa_claims_payment g on (a.claim_seq_id=g.claim_seq_id)
         WHERE  trunc(a.clm_received_date) >=   to_date(str_tab(2),'dd/mm/yyyy')
         AND trunc(a.clm_received_date) <= to_date(str_tab(3),'dd/mm/yyyy')
         AND a.clm_status_type_id='APR'
         and g.claim_payment_status='PAID'   );

end Dashboard_claims;
--============================================================================================================


procedure dash_board_claims (v_hosp_seq_id tpa_hosp_info.hosp_seq_id%type,
                             v_frm_date IN VARCHAR2,
                             v_todate   IN VARCHAR2,
                             v_out_xml     out xmltype) is



v_from_date                  varchar2(10):=CASE WHEN v_frm_date is null
                                                THEN
                                                 -- to_char(trunc(sysdate,'year'),'dd/mm/yyyy')
                                                 --to_char(add_months(trunc(sysdate, 'mm'), -1),'dd/mm/yyyy')
                                                 to_char(trunc(sysdate,'MM'),'dd/mm/yyyy')
                                                 ELSE v_frm_date

                                                END;
v_to_date                    varchar2(10):=CASE WHEN v_todate is null
                                                THEN
                                                to_char(sysdate,'dd/mm/yyyy')
                                                 ELSE v_todate
                                                END;

v_input                varchar2(40);
v_cursor               sys_refcursor;

/*type ref_cur_rec is record (

TOT_RCV_CLAIMS         number(12,2),
APROVE_CLMS            number(12,2),
INP_CLMS               number(12,2),
REJECTED_CLMS          number(12,2),
CLOSED_CLMS            number(12,2),
SHRT_FAL_CLMS          number(12,2),
SETTLED_CLMS           number(12,2),
PENDING_CLMS           number(12,2),
REQUESTED_AMOUNT       number(12,2),
APROVED_AMOUNT         number(12,2),
INP_AMOUNT             number(12,2),
REJECTED_AMOUNT        number(12,2),
CLOSED_AMOUNT          number(12,2),
SHORTFAL_AMOUNT        number(12,2),
SETTLED_AMOUNT         number(12,2),
BILL_PENDING_AMOUNT    number(12,2)) ;*/

type ref_cur_rec is record (

inprogress                 number(12,2),
shortfalls                 number(12,2),
closed                     number(12,2),
rejected                   number(12,2),
approved                   number(12,2),
received                   number(12,2),
paid_claims                number(12,2));

type ref_cur_table is table of ref_cur_rec;

v_result                ref_cur_table;


      v_doc                DBMS_XMLDOM.DOMDocument;
      v_elem               DBMS_XMLDOM.DOMElement;
      v_node               DBMS_XMLDOM.DOMNode;
      v_parent_node        DBMS_XMLDOM.DOMNODE;
      v_root_node          DBMS_XMLDOM.DOMNode;

begin

v_input:='|'||v_hosp_seq_id||'|'||v_from_date||'|'||v_to_date||'|';

 Dashboard_claims(v_input,v_cursor);

      v_doc := dbms_xmldom.newDOMDocument;
      dbms_xmldom.setVersion( v_doc, '1.0' );
      v_root_node := dbms_xmldom.makeNode(v_doc);

      v_elem := dbms_xmldom.createElement( v_doc, 'hospital' );
      v_node := dbms_xmldom.makeNode( v_elem );
      v_root_node := dbms_xmldom.appendChild( v_root_node, v_node );

      v_elem := dbms_xmldom.createElement(v_doc, 'claims');


 fetch v_cursor bulk collect into v_result;

       fOR i in v_result.First..v_result.Last Loop

      dbms_xmldom.setattribute(v_elem,'inprogress',v_result(i).inprogress);
      dbms_xmldom.setattribute(v_elem,'shortfalls',v_result(i).shortfalls);
      dbms_xmldom.setattribute(v_elem,'closed',v_result(i).closed);
      dbms_xmldom.setattribute(v_elem,'rejected',v_result(i).rejected);
      dbms_xmldom.setattribute(v_elem,'approved',v_result(i).approved);
      dbms_xmldom.setattribute(v_elem,'paid',v_result(i).paid_claims);
      dbms_xmldom.setattribute(v_elem,'received',v_result(i).received);
      dbms_xmldom.setattribute(v_elem,'startdate',v_from_date);
      dbms_xmldom.setattribute(v_elem,'enddate',v_to_date);

/*
      dbms_xmldom.setAttribute(v_elem,'TOT_RCV_CLAIMS',v_result(i).TOT_RCV_CLAIMS);
      dbms_xmldom.setAttribute(v_elem,'APROVE_CLMS',v_result(i).APROVE_CLMS);
      dbms_xmldom.setAttribute(v_elem,'INP_CLMS',v_result(i).INP_CLMS);
      dbms_xmldom.setAttribute(v_elem,'REJECTED_CLMS',v_result(i).REJECTED_CLMS);
      dbms_xmldom.setAttribute(v_elem,'CLOSED_CLMS',v_result(i).CLOSED_CLMS);
      dbms_xmldom.setAttribute(v_elem,'SHRT_FAL_CLMS',v_result(i).SHRT_FAL_CLMS);
      dbms_xmldom.setAttribute(v_elem,'SETTLED_CLMS',v_result(i).SETTLED_CLMS);
      dbms_xmldom.setAttribute(v_elem,'PENDING_CLMS',v_result(i).PENDING_CLMS);
      dbms_xmldom.setAttribute(v_elem,'REQUESTED_AMOUNT',v_result(i).REQUESTED_AMOUNT);
       dbms_xmldom.setAttribute(v_elem,'APROVED_AMOUNT',v_result(i).APROVED_AMOUNT);
      dbms_xmldom.setAttribute(v_elem,'INP_AMOUNT',v_result(i).INP_AMOUNT);
      dbms_xmldom.setAttribute(v_elem,'REJECTED_AMOUNT',v_result(i).REJECTED_AMOUNT);
      dbms_xmldom.setAttribute(v_elem,'CLOSED_AMOUNT',v_result(i).CLOSED_AMOUNT);
      dbms_xmldom.setAttribute(v_elem,'SHORTFAL_AMOUNT',v_result(i).SHORTFAL_AMOUNT);
      dbms_xmldom.setAttribute(v_elem,'SETTLED_AMOUNT',v_result(i).SETTLED_AMOUNT);
      dbms_xmldom.setAttribute(v_elem,'BILL_PENDING_AMOUNT',v_result(i).BILL_PENDING_AMOUNT);
 */

 END LOOP;

   close v_cursor;
  v_node := dbms_xmldom.makeNode(v_elem);
  v_parent_node := dbms_xmldom.appendChild( v_root_node, v_node);

   v_out_xml := dbms_xmldom.getxmltype(v_doc);

   dbms_xmldom.freeDocument(v_doc);
end dash_board_claims;


----============================================================================================================
procedure dash_board_preauth (v_hosp_seq_id tpa_hosp_info.hosp_seq_id%type,
                              v_frm_date IN VARCHAR2,
                              v_todate   IN VARCHAR2,
                              v_out_xml     out xmltype) is



v_from_date                  varchar2(10):=CASE WHEN v_frm_date is null
                                                THEN
                                                --  to_char(trunc(sysdate,'year'),'dd/mm/yyyy')
                                                to_char(sysdate,'dd/mm/yyyy')
                                                ELSE v_frm_date
                                                END;
v_to_date                    varchar2(10):=CASE WHEN v_todate is null
                                                THEN
                                                     to_char(sysdate,'dd/mm/yyyy')
                                                ELSE v_todate
                                                END;
--v_from_date                  varchar2(10):=to_char(trunc(sysdate,'year'),'dd/mm/yyyy');
--v_to_date                    varchar2(10):=to_char(sysdate,'dd/mm/yyyy');

v_input                varchar2(40);
v_cursor               sys_refcursor;

type ref_cur_rec is record (

inprogress                 number(12,2),
shortfalls                 number(12,2),
closed                     number(12,2),
rejected                   number(12,2),
approved                   number(12,2),
received                   number(12,2)) ;


type ref_cur_table is table of ref_cur_rec;

v_result                ref_cur_table;


      v_doc                DBMS_XMLDOM.DOMDocument;
      v_elem               DBMS_XMLDOM.DOMElement;
      v_node               DBMS_XMLDOM.DOMNode;
      v_parent_node        DBMS_XMLDOM.DOMNODE;
      v_root_node          DBMS_XMLDOM.DOMNode;

begin

v_input:='|'||v_hosp_seq_id||'|'||v_from_date||'|'||v_to_date||'|';

 Dashboard_preauth(v_input,v_cursor);

      v_doc := dbms_xmldom.newDOMDocument;
      dbms_xmldom.setVersion( v_doc, '1.0' );
      v_root_node := dbms_xmldom.makeNode(v_doc);

      v_elem := dbms_xmldom.createElement( v_doc, 'hospital' );
      v_node := dbms_xmldom.makeNode( v_elem );
      v_root_node := dbms_xmldom.appendChild( v_root_node, v_node );

      v_elem := dbms_xmldom.createElement(v_doc, 'preauths');


 fetch v_cursor bulk collect into v_result;

       fOR i in v_result.First..v_result.Last Loop

      dbms_xmldom.setattribute(v_elem,'inprogress',v_result(i).inprogress);
      dbms_xmldom.setattribute(v_elem,'shortfalls',v_result(i).shortfalls);
      dbms_xmldom.setattribute(v_elem,'closed',v_result(i).closed);
      dbms_xmldom.setattribute(v_elem,'rejected',v_result(i).rejected);
      dbms_xmldom.setattribute(v_elem,'approved',v_result(i).approved);
      dbms_xmldom.setattribute(v_elem,'received',v_result(i).received);
      dbms_xmldom.setattribute(v_elem,'startdate',v_from_date);
      dbms_xmldom.setattribute(v_elem,'enddate',v_to_date);
   END LOOP;

   close v_cursor;
  v_node := dbms_xmldom.makeNode(v_elem);
  v_parent_node := dbms_xmldom.appendChild( v_root_node, v_node);

   v_out_xml := dbms_xmldom.getxmltype(v_doc);

   dbms_xmldom.freeDocument(v_doc);
end dash_board_preauth;

--=====================================================================
procedure dash_board_pat_clm (v_hosp_seq_id tpa_hosp_info.hosp_seq_id%type,
                              v_out_xml     out xmltype) is

v_from_date                  varchar2(10):=to_char(trunc(sysdate,'year'),'dd/mm/yyyy');
v_to_date                    varchar2(10):=to_char(sysdate,'dd/mm/yyyy');

v_input                varchar2(40);
v_cursor               sys_refcursor;

type ref_cur_rec is record (

inprogress                 number(12,2),
shortfalls                 number(12,2),
closed                     number(12,2),
rejected                   number(12,2),
approved                   number(12,2),
received                   number(12,2)) ;


type ref_cur_table is table of ref_cur_rec;

v_result                ref_cur_table;


      v_doc                DBMS_XMLDOM.DOMDocument;
      v_elem               DBMS_XMLDOM.DOMElement;
      v_node               DBMS_XMLDOM.DOMNode;
      v_parent_node        DBMS_XMLDOM.DOMNODE;
      v_root_node          DBMS_XMLDOM.DOMNode;

begin

v_input:='|'||v_hosp_seq_id||'|'||v_from_date||'|'||v_to_date||'|';

 Dashboard_preauth(v_input,v_cursor);

      v_doc := dbms_xmldom.newDOMDocument;
      dbms_xmldom.setVersion( v_doc, '1.0' );
      v_root_node := dbms_xmldom.makeNode(v_doc);

      v_elem := dbms_xmldom.createElement( v_doc, 'hospital' );
      v_node := dbms_xmldom.makeNode( v_elem );
      v_root_node := dbms_xmldom.appendChild( v_root_node, v_node );

      v_elem := dbms_xmldom.createElement(v_doc, 'preauths');


 fetch v_cursor bulk collect into v_result;

       fOR i in v_result.First..v_result.Last Loop

      dbms_xmldom.setattribute(v_elem,'inprogress',v_result(i).inprogress);
      dbms_xmldom.setattribute(v_elem,'shortfalls',v_result(i).shortfalls);
      dbms_xmldom.setattribute(v_elem,'closed',v_result(i).closed);
      dbms_xmldom.setattribute(v_elem,'rejected',v_result(i).rejected);
      dbms_xmldom.setattribute(v_elem,'approved',v_result(i).approved);
      dbms_xmldom.setattribute(v_elem,'received',v_result(i).received);
   END LOOP;

   close v_cursor;

  v_node := dbms_xmldom.makeNode(v_elem);
  v_parent_node := dbms_xmldom.appendChild( v_root_node, v_node);


 Dashboard_claims(v_input,v_cursor);

   v_elem := dbms_xmldom.createElement(v_doc, 'claims');


 fetch v_cursor bulk collect into v_result;

       fOR i in v_result.First..v_result.Last Loop

      dbms_xmldom.setattribute(v_elem,'inprogress',v_result(i).inprogress);
      dbms_xmldom.setattribute(v_elem,'shortfalls',v_result(i).shortfalls);
      dbms_xmldom.setattribute(v_elem,'closed',v_result(i).closed);
      dbms_xmldom.setattribute(v_elem,'rejected',v_result(i).rejected);
      dbms_xmldom.setattribute(v_elem,'approved',v_result(i).approved);
      dbms_xmldom.setattribute(v_elem,'received',v_result(i).received);

 END LOOP;

   close v_cursor;

  v_node := dbms_xmldom.makeNode(v_elem);
  v_parent_node := dbms_xmldom.appendChild( v_root_node, v_node);

   v_out_xml := dbms_xmldom.getxmltype(v_doc);

   dbms_xmldom.freeDocument(v_doc);
end dash_board_pat_clm;
--============================================================================================================
--Author : Kishor Kumar
--Date   : 13/.5/2014
--kocnewhosp1
procedure select_hosp_details(
    v_input_list        IN  VARCHAR2,
    v_flag              IN  VARCHAR2,
    v_result_set       OUT SYS_REFCURSOR)
    IS
  BEGIN
    OPEN v_result_set FOR
    SELECT Hosp_Name,t.empanel_number,ts.state_name,tc.city_description as city,tpa_regist_date
    ,th.address_1||th.address_2||th.address_3 as address,th.pin_code,t.off_phone_no_1,cc.country_name as country,
    ttk_util_pkg.fn_decrypt(oi.email_id) as hosp_email
    FROM tpa_hosp_info t
    left outer join tpa_hosp_address th on t.hosp_seq_id=th.hosp_seq_id
    left outer join tpa_city_code tc on th.city_type_id=tc.city_type_id
    left outer join tpa_state_code ts on tc.state_type_id=ts.state_type_id 
    left outer join tpa_country_code cc on ts.country_id = cc.country_id
    left outer join Tpa_Office_Info oi on (oi.tpa_office_seq_id=t.tpa_office_seq_id)
    where t.empanel_number = UPPER(v_input_list) and t.hosp_catagory = v_flag;
    
end SELECT_HOSP_DETAILS;
  --========================================================================================
 --   Name        : select_pre_auth_list
 --   Created on  : 18/11/2015
 --   Created By  : chiranjibi
 --   Comments    : provider login preauth search screen
  --========================================================================================

  PROCEDURE select_pre_auth_list (
    v_hosp_empanel_no                    IN  TPA_HOSP_INFO.EMPANEL_NUMBER%TYPE,
    v_pre_auth_number                    IN  pat_authorization_details.pre_auth_number%TYPE,
    v_from_date                          IN  VARCHAR2,
    v_to_date                            IN  VARCHAR2,
    v_claimant_name                      IN  pat_authorization_details.mem_name%TYPE,
    v_authorization_no                   IN  pat_authorization_details.auth_number%type,
    v_docs_name                          IN  tpa_hosp_professionals.contact_name%TYPE,
    v_tpa_enrollment_id                  IN  pat_authorization_details.tpa_enrollment_id%TYPE,
    v_benefit_type                       IN  VARCHAR2,
    v_pat_status_general_type_id         IN  pat_authorization_details.pat_status_type_id%TYPE,
    v_pl_preauth_refno                   IN  pat_authorization_details.pl_preauth_refno%type,
    v_emirate_id                         IN  app.tpa_enr_policy_member.emirate_id%type,  
    v_event_no                           IN  pat_authorization_details.event_no%TYPE,
    v_sort_var                           IN  VARCHAR2,
    v_sort_order                         IN  VARCHAR2 ,
    v_start_num                          IN  VARCHAR2 ,
    v_end_num                            IN  VARCHAR2 ,
    v_srtfll_status_type                 IN  Shortfall_Details.Srtfll_Status_General_Type_Id%TYPE,
    v_inp_status                         IN  VARCHAR2,
    result_set                           OUT SYS_REFCURSOR
    
  )
  IS

    v_sql_str                            VARCHAR2(10000) ;
    v_lower_limit                        PAT_REQUESTED_AMOUNT_CODE.amount_lower_level%TYPE;
    v_upper_limit                        PAT_REQUESTED_AMOUNT_CODE.amount_upper_level%TYPE;
    TYPE bind_tab_type IS TABLE OF VARCHAR2(250) INDEX BY BINARY_INTEGER ;
    bind_tab                             bind_tab_type;
    i                                    NUMBER(2) := 0;
    v_where                              VARCHAR2(2000);
    v_max_event_seq_id                   tpa_event.event_seq_id%TYPE;
    v_frm_date                           clm_inward.rcvd_date%TYPE:=to_date(v_from_date,'dd/mm/yyyy');
    v_to_data                            clm_inward.rcvd_date%TYPE:=to_date(v_to_date,'dd/mm/yyyy');
    v_docs_name1                         VARCHAR2(50);
    v_inp_status1                        VARCHAR2(5);
  BEGIN

    v_sql_str :=
     'with shrtfll as (select max(s.shortfall_seq_id) shortfall_seq_id, s.pat_gen_detail_seq_id
                       from pat_authorization_details p
                       join shortfall_details s on (p.pat_auth_seq_id = s.pat_gen_detail_seq_id)
                       --where (s.srtfll_status_general_type_id = '''||v_srtfll_status_type||''' or '''||v_srtfll_status_type||''' is null)
                       group by s.pat_gen_detail_seq_id
                      )
       select distinct(nd.clinician_name) as treating_doctor,
       pad.pat_auth_seq_id,
       pad.pat_batch_seq_id,
       pad.parent_pat_auth_seq_id,
       pad.pre_auth_number,
       CASE WHEN pad.pat_status_type_id IN (''APR'',''REJ'') THEN 
             nvl(pad.auth_number,'' '') 
             ELSE NULL END
               auth_number, 
       pad.pat_status_type_id as preauth_status,
       to_char(pad.pat_received_date,''dd/mm/yyyy hh:mi Am'') as pat_received_date,
       tep.policy_number,
       tepm.tpa_customer_id,
       nvl(thi.hosp_name,nd.provider_name) as hosp_name,
       tepm.member_seq_id,
       tepm.mem_name,
       tepm.tpa_enrollment_id,
       tepm.emirate_id,
       pad.hospitalization_date,
       pad.discharge_date,
       case when pad.benifit_type = ''OPTS'' then ''Out-Patient'' 
            when pad.benifit_type = ''OPTC'' then ''Optical''
            when pad.benifit_type = ''IMTI'' then ''In-Patient Maternity''
            when pad.benifit_type = ''OMTI''  then ''Out-Patient Maternity''
            when pad.benifit_type = ''IPT'' then ''In-Patient''
            when pad.benifit_type = ''DNTL'' then ''Dental''
            when pad.benifit_type = ''HEAC'' then ''Health Check-up''
            when pad.benifit_type = ''DAYC'' then ''Daycare'' end as benefit_type,       
       tgc.description as pat_status_type_id,
       nvl(pl_preauth_refno,''-'') as pat_auth_ref,
       pad.file_name,
       case when pad.pat_status_type_id = ''APR'' and clm.pat_auth_seq_id is null then
         ''Y''
       else
         ''N''
       end as Enhanced, -- Added for Enhancement Case
       case when sd.srtfll_status_general_type_id = ''RES'' then ''Y'' else ''N'' end as SHRTFALL_YN,
       case when sd.srtfll_status_general_type_id = ''RES'' then to_char(sd.updated_date, ''DD/MM/RRRR HH:MI:SS AM'') end srtfll_updated_date,
	   nvl(pad.event_no, '' '') as event_no,
     CASE WHEN pat_status_type_id in (''APR'',''REJ'',''PCN'',''PCO'') THEN  
                   to_char(pad.completed_date,''dd/mm/yyyy hh:mi Am'') END as decision_date,
      CASE WHEN pad.parent_pat_auth_seq_id is not null 
        and nvl(pad.parent_pat_auth_seq_id,0) != 0 
        and  pad.pat_enhanced_yn = ''N'' 
           THEN
         ''Y''
           ELSE
             ''N''
             END AS ENHANCED_PREAUTHYN,
      CASE WHEN pad.parent_pat_auth_seq_id is not null 
        and nvl(pad.parent_pat_auth_seq_id,0) != 0 
        and  pad.pat_enhanced_yn = ''N''  
        and upper(pad.source_type_id) = ''PLPR'' 
        and nvl(pad.SUCCESS_ENH_YN,''Y'') = ''N'' THEN 
        ''Y''    
        ELSE
           case when pad.pat_status_type_id = ''APR'' and clm.pat_auth_seq_id is null then
             ''Y''
             ELSE
            ''N'' 
            END 
        END AS submitYN,    ----For Enhancement edit case (newly added)
        PAD.PAT_STATUS_TYPE_ID||''-''||'||''''||v_inp_status||'''' ||' AS IN_PROGESS_STATUS,
        pad.claim_seq_id,
        PAD.APPEAL_COUNT
            
        
  from pat_authorization_details pad
  left join clm_authorization_details clm on (pad.pat_auth_seq_id = clm.pat_auth_seq_id)
  left outer join tpa_hosp_info thi on (pad.hosp_seq_id=thi.hosp_seq_id)
  join tpa_enr_policy_member tepm on (pad.member_seq_id=tepm.member_seq_id)
  join tpa_enr_policy_group tepg on (tepm.policy_group_seq_id=tepg.policy_group_seq_id)
  join tpa_enr_policy tep on (tepg.policy_seq_id=tep.policy_seq_id)
  left outer join tpa_user_contacts tuc on (tuc.contact_seq_id=pad.added_by)
  left outer join tpa_general_code tgc on (pad.pat_status_type_id = tgc.general_type_id)
  left outer join pat_non_network_details nd on (nd.pat_auth_seq_id=pad.pat_auth_seq_id)
  left outer join tpa_general_code ec on (pad.benifit_type = ec.general_type_id)
  left outer join tpa_hosp_professionals p on (pad.clinician_id = p.professional_id)
  left join shrtfll sh ON (sh.pat_gen_detail_seq_id = pad.pat_auth_seq_id)
  left join shortfall_details sd on (sh.shortfall_seq_id=sd.shortfall_seq_id)
  where thi.empanel_number = :v_hosp_empanel_no and NVL(pad.PBM_YN, ''N'') = ''N'' and pad.pat_enhanced_yn=''N'''  ;
      
    IF v_tpa_enrollment_id IS NOT NULL THEN
      v_where := v_where  ||' AND pad.tpa_enrollment_id = :v_tpa_enrollment_id';
       i := i+1;
       bind_tab(i) := UPPER(v_tpa_enrollment_id);
    END IF;
    
    IF v_pre_auth_number IS NOT NULL THEN
      v_where := v_where  ||' AND pad.pre_auth_number = :v_pre_auth_number';
       i := i+1;
       bind_tab(i) := TRIM(v_pre_auth_number);
    END IF;

    
    IF v_claimant_name IS NOT NULL THEN
      v_where := v_where  ||' AND pad.mem_name LIKE :v_claimant_name';
      i := i+1;
      bind_tab(i) := UPPER(v_claimant_name)||'%';
    END IF;

    IF v_frm_date IS NOT NULL AND  v_to_data IS NULL THEN
      v_where := v_where  ||' AND trunc(pad.pat_received_date) = :v_from_date /*BETWEEN :v_from_date AND :v_from_date1*/ ';
      i := i+1;
      bind_tab(i) := v_frm_date;
      /*i := i+1;
      bind_tab(i) := v_frm_date + 7;*/
    END IF;
    
    IF v_frm_date IS NOT NULL AND  v_to_data IS NOT NULL THEN
      v_where := v_where  ||' AND trunc(pad.pat_received_date)  BETWEEN :v_frm_date AND :v_to_data ';
      i := i+1;
      bind_tab(i) := v_frm_date;
      i := i+1;
      bind_tab(i) := v_to_data;
    END IF;
    
    IF v_to_data IS NOT NULL AND v_frm_date IS NULL THEN
      v_where := v_where  ||' AND trunc(pad.pat_received_date)  BETWEEN :v_to_date AND :v_to_date1 ';
      i := i+1;
      bind_tab(i) := v_to_data-7;
      i := i+1;
      bind_tab(i) := v_to_data ;
    END IF;
    
    IF v_pat_status_general_type_id IS NOT NULL THEN
       v_where := v_where  ||' AND pad.pat_status_type_id = :v_pat_status_general_type_id ';
       i := i+1;
       bind_tab(i) := v_pat_status_general_type_id;
    END IF; 

    IF v_authorization_no IS NOT NULL THEN
       v_where := v_where  ||' AND pad.auth_number = :v_authorization_no ';
       i := i+1;
       bind_tab(i) := v_authorization_no;
    END IF;     

    IF v_benefit_type IS NOT NULL THEN
       v_where := v_where  ||' AND pad.benifit_type = :v_benefit_type ';
       i := i+1;
       bind_tab(i) := v_benefit_type;
    END IF;
    ---newly added sreenivasulu
     IF v_pl_preauth_refno IS NOT NULL THEN
       v_where := v_where  ||' AND pad.pl_preauth_refno = :v_pl_preauth_refno ';
       i := i+1;
       bind_tab(i) := upper(v_pl_preauth_refno);
    END IF;
    ---newly added by sreenivasulu 
                              
     IF v_emirate_id IS NOT NULL THEN
       v_where := v_where  ||' AND tepm.emirate_id = :v_emirate_id ';
       i := i+1;
       bind_tab(i) := v_emirate_id;
    END IF;
    
    IF v_docs_name IS NOT NULL THEN
       v_where := v_where  ||' AND (UPPER(P.contact_name) LIKE :v_docs_name OR UPPER(nd.clinician_name) LIKE :v_docs_name1)';
       i := i+1;
       bind_tab(i) := UPPER(v_docs_name)||'%';
       v_docs_name1 := v_docs_name;
       i := i+1;
       bind_tab(i) := UPPER(v_docs_name1)||'%';
    END IF;
    
    IF v_event_no IS NOT NULL THEN
      v_where := v_where  ||' AND pad.event_no = :v_event_num ';
      i := i+1;
      bind_tab(i) := v_event_no;
    END IF;
    
    IF v_srtfll_status_type IN ('OPN', 'RES') THEN
      v_where := v_where  || ' AND (sd.srtfll_status_general_type_id) = :v_srtfll_sts_type ';
      i := i+1;
      bind_tab(i) := v_srtfll_status_type;
    END IF;
    
    --===============CR0247====================================
    IF v_inp_status IS NOT NULL THEN
      IF v_inp_status = 'FRH' THEN
         v_inp_status1 := '0';
         v_where := v_where  ||' AND NVL(PAD.PARENT_PAT_AUTH_SEQ_ID, 0) = 0 AND NVL(PAD.APPEAL_YN, ''N'') = ''N'' AND NVL(SD.PAT_GEN_DETAIL_SEQ_ID, 0) = :v_inp_status ';
      ELSIF v_inp_status = 'APL' THEN
         v_inp_status1 := 'Y';
         v_where := v_where  ||' AND NVL(PAD.APPEAL_YN, ''N'') = :v_inp_status ';
      ELSIF v_inp_status = 'ENH' THEN
         v_inp_status1 := '0';
         v_where := v_where  ||' AND NVL(PAD.PARENT_PAT_AUTH_SEQ_ID, 0) != :v_inp_status ';
      ELSIF v_inp_status = 'RES' THEN
         v_inp_status1 := 'RES';
         v_where := v_where  ||' AND PAD.PAT_STATUS_TYPE_ID = ''INP'' AND SD.SRTFLL_STATUS_GENERAL_TYPE_ID = :v_inp_status ';
      END IF;
      i := i+1;
      bind_tab(i) := UPPER(v_inp_status1);
    END IF;
    --=========================================================
    
    IF v_where IS NOT NULL THEN
       --v_where   := ' WHERE '|| SUBSTR(v_where,5);
      v_sql_str := v_sql_str ||v_where;
    END IF;
    
--    v_where := v_where||' AND  PAD.SOURCE_TYPE_ID =''PLPR''';
  
    v_sql_str := 'SELECT * FROM
        (SELECT A.*,DENSE_RANK() OVER (ORDER BY '||v_sort_var||' '||v_sort_order||',ROWNUM)
        Q FROM (' ||v_sql_str|| ') A ) WHERE  Q>= :v_start_num AND Q<= :v_end_num ';
  
    IF bind_tab.FIRST IS NOT NULL THEN
       CASE bind_tab.COUNT
         WHEN 1  THEN OPEN result_set FOR v_sql_str USING v_hosp_empanel_no,bind_tab(1), v_start_num , v_end_num ;
         WHEN 2  THEN OPEN result_set FOR v_sql_str USING v_hosp_empanel_no,bind_tab(1),bind_tab(2), v_start_num , v_end_num ;
         WHEN 3  THEN OPEN result_set FOR v_sql_str USING v_hosp_empanel_no,bind_tab(1),bind_tab(2) ,bind_tab(3) , v_start_num , v_end_num ;
         WHEN 4  THEN OPEN result_set FOR v_sql_str USING v_hosp_empanel_no,bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) , v_start_num , v_end_num ;
         WHEN 5  THEN OPEN result_set FOR v_sql_str USING v_hosp_empanel_no,bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5), v_start_num , v_end_num ;
         WHEN 6  THEN OPEN result_set FOR v_sql_str USING v_hosp_empanel_no,bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6), v_start_num , v_end_num ;
         WHEN 7  THEN OPEN result_set FOR v_sql_str USING v_hosp_empanel_no,bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6),bind_tab(7), v_start_num , v_end_num ;
         WHEN 8  THEN OPEN result_set FOR v_sql_str USING v_hosp_empanel_no,bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6),bind_tab(7),bind_tab(8), v_start_num , v_end_num ;
         WHEN 9  THEN OPEN result_set FOR v_sql_str USING v_hosp_empanel_no,bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6),bind_tab(7),bind_tab(8),bind_tab(9), v_start_num , v_end_num ;
         WHEN 10 THEN OPEN result_set FOR v_sql_str USING v_hosp_empanel_no,bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6),bind_tab(7),bind_tab(8),bind_tab(9),bind_tab(10), v_start_num , v_end_num ;
         WHEN 11 THEN OPEN result_set FOR v_sql_str USING v_hosp_empanel_no,bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6),bind_tab(7),bind_tab(8),bind_tab(9),bind_tab(10),bind_tab(11), v_start_num , v_end_num ;
         WHEN 12 THEN OPEN result_set FOR v_sql_str USING v_hosp_empanel_no,bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6),bind_tab(7),bind_tab(8),bind_tab(9),bind_tab(10),bind_tab(11),bind_tab(12), v_start_num , v_end_num ;
         WHEN 13 THEN OPEN result_set FOR v_sql_str USING v_hosp_empanel_no,bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6),bind_tab(7),bind_tab(8),bind_tab(9),bind_tab(10),bind_tab(11),bind_tab(12), bind_tab(13), v_start_num , v_end_num ;
         WHEN 14 THEN OPEN result_set FOR v_sql_str USING v_hosp_empanel_no,bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6),bind_tab(7),bind_tab(8),bind_tab(9),bind_tab(10),bind_tab(11),bind_tab(12), bind_tab(13), bind_tab(14), v_start_num , v_end_num ;
         WHEN 15 THEN OPEN result_set FOR v_sql_str USING v_hosp_empanel_no,bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6),bind_tab(7),bind_tab(8),bind_tab(9),bind_tab(10),bind_tab(11),bind_tab(12), bind_tab(13), bind_tab(14), bind_tab(15), v_start_num , v_end_num ;
        END CASE;
     ELSE
       OPEN result_set FOR v_sql_str USING v_hosp_empanel_no,v_start_num , v_end_num ;
     END IF;
  END select_pre_auth_list;
 --==================================================================================
 --   Name        : select_preauth_details
 --   Created on  : 18/11/2015
 --   Created By  : chiranjibi
 --   Comments    : provider login preauth details data will fetch for a preauth number
--========================================================================================
PROCEDURE select_preauth_details ( v_hosp_empanel_no          tpa_hosp_info.empanel_number%type,
                                   v_pat_auth_seq_id          pat_authorization_details.pat_auth_seq_id%type,
                                   result_set                 OUT SYS_REFCURSOR 
                                 ) IS
   BEGIN

    OPEN result_set FOR 
    select distinct(p.contact_name) as treating_doctor,
       'fresh' as preauth_type,             
    /*select case when pad.parent_pat_auth_seq_id is null then 'Fresh'
                when pad.parent_pat_auth_seq_id is null then 'Enhancement' END as preauth_type,*/
       to_char(pad.pat_received_date,'dd/mm/yyyy hh:mi Am') as pat_received_date,
       to_char(pad.hospitalization_date,'dd/mm/yyyy hh:mi Am') as hospitalization_date,    
       case when pad.benifit_type = 'OPTS' then 'Out-Patient' 
            when pad.benifit_type = 'OPTC' then 'Optical'
            when pad.benifit_type = 'MTI' then 'Maternity'
            when pad.benifit_type = 'IMTI' then 'In-Patient Maternity'
            when pad.benifit_type = 'OMTI'  then 'Out-Patient Maternity'
            when pad.benifit_type = 'IPT' then 'Inpatient'
            when pad.benifit_type = 'DNTL' then 'Dental'
            when pad.benifit_type = 'HEAC' then 'Health Check-up'
            when pad.benifit_type = 'DAYC' then 'Daycare' end as benefit_type,
       (select pa.final_app_amount from pat_authorization_details pa where pa.pat_auth_seq_id = pad.parent_pat_auth_seq_id) as previous_approved_amt,
       (pad.tot_disc_gross_amount-pad.tot_patient_share_amount) as requested_amt,
       'DUBAI' as vidal_branch,  
       to_char(pad.discharge_date,'dd/mm/yyyy hh:mi Am') as discharge_date,
       tepm.tpa_enrollment_id,
       tepg.insured_name as beneficiary_name,
       nvl(thi.hosp_name,nd.provider_name) as hosp_name,
       thi.empanel_number,
       sc.state_name as state_type_id,
       cc.city_description as city_type_id,        
       pad.auth_number,
       tepm.emirate_id,
       tgc.description as pat_status_type_id,
       to_char(pad.completed_date,'dd/mm/yyyy hh:mi Am') as completed_date        
  from pat_authorization_details pad
  left outer join tpa_hosp_info thi on (pad.hosp_seq_id=thi.hosp_seq_id)
  left outer join tpa_hosp_address ha on (thi.hosp_seq_id = ha.hosp_seq_id)
  join tpa_enr_policy_member tepm on (pad.member_seq_id=tepm.member_seq_id)
  join tpa_enr_policy_group tepg on (tepm.policy_group_seq_id=tepg.policy_group_seq_id)
  join tpa_enr_policy tep on (tepg.policy_seq_id=tep.policy_seq_id)
  left outer join tpa_user_contacts tuc on (tuc.contact_seq_id=pad.added_by)
  left outer join tpa_general_code tgc on (pad.pat_status_type_id = tgc.general_type_id)
  left outer join pat_non_network_details nd on (nd.pat_auth_seq_id=pad.pat_auth_seq_id)
  left outer join tpa_general_code ec on (pad.benifit_type = ec.general_type_id)
  left outer join tpa_hosp_professionals p on (pad.clinician_id = p.professional_id)
  left outer join tpa_state_code sc on (ha.state_type_id = sc.state_type_id)
  left outer join tpa_city_code cc on (ha.city_type_id = cc.city_type_id)
  where thi.empanel_number = v_hosp_empanel_no and pad.pat_auth_seq_id = v_pat_auth_seq_id;
 END select_preauth_details; 
--======================================================================================================================================
 --   Name        : select_claims_list
 --   Created on  : 18/11/2015
 --   Created By  : chiranjibi
 --   Comments    : provider login claims search screen
--========================================================================================
PROCEDURE select_claims_list (
    v_hosp_empanel_no                    IN  TPA_HOSP_INFO.EMPANEL_NUMBER%TYPE,
    v_from_date                          IN  VARCHAR2,
    v_to_date                            IN  VARCHAR2,
    v_mem_name                           IN  clm_authorization_details.mem_name%type,
    v_tpa_enrollment_id                  IN  clm_authorization_details.tpa_enrollment_id%type,
    v_claim_number                       IN  clm_authorization_details.claim_number%type,
    v_invoice_number                     IN  clm_authorization_details.invoice_number%type,
    v_claim_type                         IN  clm_batch_upload_details.clm_type_gen_type_id%type,
    v_batch_no                           IN  clm_batch_upload_details.batch_no%type,
    v_benefit_type                       IN  VARCHAR2,
    v_clm_status_type_id                 IN  clm_authorization_details.clm_status_type_id%type,
    v_check_num                          IN  tpa_claims_check.check_num%TYPE,
    v_emirate_id                         IN  app.tpa_enr_policy_member.emirate_id%type,
    v_sort_var                           IN  VARCHAR2,
    v_sort_order                         IN  VARCHAR2 ,
    v_start_num                          IN  NUMBER ,
    v_end_num                            IN  NUMBER ,
    result_set                           OUT SYS_REFCURSOR
  )
  IS

    v_sql_str                            VARCHAR2(10000) ;
    TYPE bind_tab_type IS TABLE OF VARCHAR2(250) INDEX BY BINARY_INTEGER ;
    bind_tab                             bind_tab_type;
    i                                    NUMBER(2) := 0;
    v_where                              VARCHAR2(2000);
    
    v_date_from                          date:=to_date(v_from_date,'dd/mm/yyyy');
    v_date_upto                          date:=to_date(v_to_date,'dd/mm/yyyy'); 
  
  BEGIN
    v_sql_str :=
    'select b.claim_seq_id,
            a.clm_batch_seq_id,
            to_char(a.received_date,''dd/mm/yyyy hh:mi Am'') as received_date,
            b.mem_name,
            b.tpa_enrollment_id,
            b.claim_number,
            tg.description as claim_type,
            a.batch_no,
            b.invoice_number,
            ec.description AS benefit_type,
            gc.description as claim_status,
            b.settlement_number,
            g.emirate_id,
            nvl(cc.check_num,''N/A'') cheque_no
    from clm_batch_upload_details a join clm_authorization_details b on (a.clm_batch_seq_id=b.clm_batch_seq_id and a.batch_status_type=''COMP'')
    left outer join tpa_claims_payment cp on (b.claim_seq_id=cp.claim_seq_id)
    left outer join tpa_payment_checks_details pcd on (cp.payment_seq_id=pcd.payment_seq_id)
    left outer join tpa_claims_check cc on (pcd.claims_chk_seq_id=cc.claims_chk_seq_id)
    left outer join tpa_enr_policy_member g on (g.member_seq_id=b.member_seq_id)
    left outer join tpa_enr_policy e on (e.policy_seq_id=b.policy_seq_id)
    left outer join clm_hospital_details c on (c.claim_seq_id=b.claim_seq_id)
    left outer join tpa_hosp_info d on (d.hosp_seq_id=c.hosp_seq_id)
    left outer join tpa_user_contacts f on (f.contact_seq_id=b.added_by)
    left outer join tpa_general_code gc on (gc.general_type_id=b.clm_status_type_id)
    left outer join tpa_general_code tg on (tg.general_type_id=a.clm_type_gen_type_id)
    left outer join tpa_general_code ec on (b.benifit_type = ec.general_type_id)
    where d.empanel_number = :v_hosp_empanel_no';

    IF v_invoice_number IS NOT NULL THEN
      v_where := v_where  ||' AND b.invoice_number = :v_invoice_number';
      i := i+1;
      bind_tab(i) := UPPER(v_invoice_number);
    END IF;
    
    IF v_batch_no IS NOT NULL THEN
      v_where := v_where  ||' AND a.batch_no = :v_batch_no';
       i := i+1;
       bind_tab(i) := UPPER(v_batch_no);
    END IF;


    IF v_claim_number IS NOT NULL THEN
      v_where := v_where  ||' AND b.claim_number = :v_claim_number';
      i := i+1;
      bind_tab(i) := UPPER(v_claim_number);
    END IF;
    
    IF v_claim_type IS NOT NULL THEN
      v_where := v_where  ||' AND b.claim_type = :v_claim_type';
      i := i+1;
      bind_tab(i) := UPPER(v_claim_type);
    END IF;
   
    IF v_from_date IS NOT NULL THEN
      v_where := v_where  ||' AND a.received_date  BETWEEN :v_from_date AND :v_from_date1 ';
      i := i+1;
      bind_tab(i) := v_date_from;
      i := i+1;
      bind_tab(i) := v_date_from + 7;
    END IF;
    
    IF v_from_date IS NOT NULL AND  v_to_date IS NOT NULL THEN
      v_where := v_where  ||' AND a.received_date  BETWEEN :v_from_date AND v_to_date ';
      i := i+1;
      bind_tab(i) := v_date_from;
      i := i+1;
      bind_tab(i) := v_date_upto;
    END IF;
    
    IF v_to_date IS NOT NULL THEN
      v_where := v_where  ||' AND a.received_date  BETWEEN :v_to_date AND :v_to_date1 ';
      i := i+1;
      bind_tab(i) := v_date_upto-7;
      i := i+1;
      bind_tab(i) := v_date_upto ;
    END IF;
  
    IF v_check_num IS NOT NULL THEN
      v_where := v_where  ||' AND cc.check_num = :v_check_num';
      i := i+1;
      bind_tab(i) := UPPER(v_check_num);
    END IF;
  
  
  ---newly added by sreenivasulu 
    IF v_emirate_id IS NOT NULL THEN
      v_where := v_where  ||' AND g.emirate_id = :v_emirate_id';
      i := i+1;
      bind_tab(i) := UPPER(v_emirate_id);
    END IF;
         
    IF v_tpa_enrollment_id IS NOT NULL THEN
      v_where := v_where  ||' AND g.tpa_enrollment_id = :v_tpa_enrollment_id';
       i := i+1;
       bind_tab(i) := UPPER(v_tpa_enrollment_id);
    END IF;
  
   IF v_mem_name IS NOT NULL THEN
      v_where := v_where  ||' AND g.mem_name = :v_mem_name';
       i := i+1;
       bind_tab(i) := UPPER(v_mem_name);
   END IF;
   
   IF v_clm_status_type_id IS NOT NULL THEN
      v_where := v_where  ||' AND b.clm_status_type_id = :v_clm_status_type_id';
       i := i+1;
       bind_tab(i) := UPPER(v_clm_status_type_id);
   END IF;
   
   IF v_benefit_type IS NOT NULL THEN
       v_where := v_where  ||' AND b.benifit_type = :v_benefit_type ';
       i := i+1;
       bind_tab(i) := v_benefit_type;
    END IF;
    
    IF v_where IS NOT NULL THEN
      --v_where   := ' WHERE '|| SUBSTR(v_where,5);
      v_sql_str := v_sql_str ||v_where;
    END IF;


    v_sql_str := 'SELECT * FROM
        (SELECT A.*,DENSE_RANK() OVER (ORDER BY '||v_sort_var||' '||v_sort_order||',ROWNUM)
        Q FROM (' ||v_sql_str|| ') A ) WHERE  Q>= :v_start_num AND Q<= :v_end_num ';


    IF bind_tab.FIRST IS NOT NULL THEN
       CASE bind_tab.COUNT
         WHEN 1  THEN OPEN result_set FOR v_sql_str USING v_hosp_empanel_no,bind_tab(1), v_start_num , v_end_num ;
         WHEN 2  THEN OPEN result_set FOR v_sql_str USING v_hosp_empanel_no,bind_tab(1),bind_tab(2), v_start_num , v_end_num ;
         WHEN 3  THEN OPEN result_set FOR v_sql_str USING v_hosp_empanel_no,bind_tab(1),bind_tab(2),bind_tab(3) , v_start_num , v_end_num ;
         WHEN 4  THEN OPEN result_set FOR v_sql_str USING v_hosp_empanel_no,bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) , v_start_num , v_end_num ;
         WHEN 5  THEN OPEN result_set FOR v_sql_str USING v_hosp_empanel_no,bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5), v_start_num , v_end_num ;
         WHEN 6  THEN OPEN result_set FOR v_sql_str USING v_hosp_empanel_no,bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6), v_start_num , v_end_num ;
         WHEN 7  THEN OPEN result_set FOR v_sql_str USING v_hosp_empanel_no,bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6),bind_tab(7), v_start_num , v_end_num ;
         WHEN 8  THEN OPEN result_set FOR v_sql_str USING v_hosp_empanel_no,bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6),bind_tab(7),bind_tab(8), v_start_num , v_end_num ;
         WHEN 9  THEN OPEN result_set FOR v_sql_str USING v_hosp_empanel_no,bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6),bind_tab(7),bind_tab(8),bind_tab(9), v_start_num , v_end_num ;
         WHEN 10 THEN OPEN result_set FOR v_sql_str USING v_hosp_empanel_no,bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6),bind_tab(7),bind_tab(8),bind_tab(9),bind_tab(10), v_start_num , v_end_num ;
         WHEN 11 THEN OPEN result_set FOR v_sql_str USING v_hosp_empanel_no,bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6),bind_tab(7),bind_tab(8),bind_tab(9),bind_tab(10),bind_tab(11), v_start_num , v_end_num ;
       END CASE;
     ELSE
       OPEN result_set FOR v_sql_str USING v_hosp_empanel_no,v_start_num , v_end_num ;
     END IF;

  END select_claims_list;
--==================================================================================
 --   Name        : select_shortfall_details
 --   Created on  : 18/11/2015
 --   Created By  : chiranjibi
 --   Comments    : provider login claims search screen
--========================================================================================
PROCEDURE select_shortfall_details ( v_pat_auth_seq_id          pat_authorization_details.pat_auth_seq_id%type,
                                     result_set                 OUT SYS_REFCURSOR 
                                   ) IS
   BEGIN
    OPEN result_set FOR                    
        select to_char(s.srtfll_sent_date,'dd/mm/yyyy hh:mi Am') as srtfll_sent_date,
               s.shortfall_id,
               s.shortfall_seq_id,
               g.description as srtfll_general_type_id,
               ge.description as srtfll_status_general_type_id,
               to_char(s.srtfll_received_date,'dd/mm/yyyy hh:mi Am') as srtfll_received_date,
               NVL(s.docs_status,'N') AS docs_status
          from app.shortfall_details s 
          left outer join app.tpa_general_code g on (s.srtfll_general_type_id = g.general_type_id)
          left outer join app.tpa_general_code ge on (s.srtfll_status_general_type_id = ge.general_type_id) 
         where s.pat_gen_detail_seq_id = v_pat_auth_seq_id;

 END select_shortfall_details;  
--======================================================================
PROCEDURE select_chkwise_report(v_check_num       IN VARCHAR2,
                                result_set        OUT SYS_REFCURSOR 
                                ) IS
 BEGIN
    OPEN result_set FOR                                
select ck.check_num,
       to_char(ck.check_date,'dd/mm/yyyy hh:mi Am') as check_date,
       ck.check_amount,
       ck.check_status,
       ttk_util_pkg.fn_decrypt(cc.payee_name) AS PAYEE_NAME,
       to_char(cad.date_of_hospitalization,'dd/mm/yyyy hh:mi Am') as date_of_hospitalization,
       gc.description as benefit_type,
       cb.batch_no ,
       cad.invoice_number as Invoice_no,
       to_char(cad.clm_received_date,'dd/mm/yyyy hh:mi Am') as clm_received_date,
       cad.mem_name,
       (cad.tot_disc_gross_amount - cad.tot_patient_share_amount) as requested_amt,
       cad.tot_discount_amount,
       null as deductable_amt,
       null as co_pay,
       cad.tot_net_amount,
       cad.tot_allowed_amount,
       null as rson_diff,
       cad.remarks
  from fin_app.tpa_claims_check ck
  left outer join fin_app.tpa_payment_checks_details cd
    on (ck.claims_chk_seq_id = cd.claims_chk_seq_id)
  left outer join fin_app.tpa_claims_payment cc
    on (cd.payment_seq_id = cc.payment_seq_id)
  left outer join app.clm_authorization_details cad
    on (cc.claim_seq_id = cad.claim_seq_id)
  left outer join app.clm_batch_upload_details cb
    on (cad.clm_batch_seq_id = cb.clm_batch_seq_id)  
  left outer join app.tpa_encounter_type_codes tc
    on (cad.encounter_type_id = tc.encounter_seq_id and
       tc.header_type = 'ENCOUNTER_TYPE')
  left outer join app.tpa_general_code gc
    on (tc.benefit_gen_type_id = gc.general_type_id)
 where ck.check_num = v_check_num /*'11111'*/
;
END select_chkwise_report;
--============================================================================
PROCEDURE select_invoicewise_report(v_invoice_no       IN VARCHAR2,
                                    v_hosp_empanel_no  IN  TPA_HOSP_INFO.EMPANEL_NUMBER%TYPE,
                                    result_set         OUT SYS_REFCURSOR 
                                    ) IS
 BEGIN
    OPEN result_set FOR                                
    select cad.invoice_number,
           null as batch_name,
           cb.batch_no,
           cad.mem_name as patient_name,
           to_char(cad.date_of_hospitalization,'dd/mm/yyyy hh:mi Am')as date_of_hospitalization,
           to_char(cad.clm_received_date,'dd/mm/yyyy hh:mi Am') as clm_received_date,
           (cad.tot_disc_gross_amount - cad.tot_patient_share_amount) as requested_amt,
           cad.tot_discount_amount,
           null as deductable_amt,
           null as co_pay,
           cad.tot_net_amount,
           cad.tot_allowed_amount,
           null as rson_diff,
           tgc.description as clm_status_type_id,
           ck.check_num,
           to_char(ck.check_date,'dd/mm/yyyy hh:mi Am') as check_date
      from app.clm_authorization_details cad
      join app.clm_batch_upload_details cb on (cad.clm_batch_seq_id = cb.clm_batch_seq_id)
      left outer join fin_app.tpa_claims_payment cc   on (cad.claim_seq_id = cc.claim_seq_id)
      left outer join fin_app.tpa_payment_checks_details cd   on (cc.payment_seq_id = cd.payment_seq_id)
      left outer join fin_app.tpa_claims_check ck   on (cd.claims_chk_seq_id = ck.claims_chk_seq_id)
      left outer join app.tpa_encounter_type_codes tc  on (cad.encounter_type_id = tc.encounter_seq_id and tc.header_type = 'ENCOUNTER_TYPE')
      left outer join app.tpa_general_code gc on (tc.benefit_gen_type_id = gc.general_type_id)
      left outer join tpa_general_code tgc on (tgc.general_type_id= cad.clm_status_type_id)  
      left outer join app.clm_hospital_details ch on (cad.claim_seq_id = ch.claim_seq_id) 
      left outer join app.tpa_hosp_info hi on (ch.hosp_seq_id = hi.hosp_seq_id)
     where hi.empanel_number = v_hosp_empanel_no and cad.invoice_number = v_invoice_no;
END select_invoicewise_report;
--======================================================================================================================================
 --   Name        : select_claims_list
 --   Created on  : 07/12/2015
 --   Created By  : chiranjibi
 --   Comments    : provider login batch reconcilation summary
--========================================================================================
PROCEDURE select_batch_recon_summary (
    v_hosp_empanel_no                    IN  TPA_HOSP_INFO.EMPANEL_NUMBER%TYPE,
    v_from_date                          IN  VARCHAR2,
    v_to_date                            IN  VARCHAR2,
    v_batch_no                           IN  clm_batch_upload_details.batch_no%TYPE,
    v_sort_var                           IN  VARCHAR2,
    v_sort_order                         IN  VARCHAR2 ,
    v_start_num                          IN  NUMBER ,
    v_end_num                            IN  NUMBER ,
    result_set                           OUT SYS_REFCURSOR
  )
  IS

    v_sql_str                            VARCHAR2(10000) ;
    TYPE bind_tab_type IS TABLE OF VARCHAR2(250) INDEX BY BINARY_INTEGER ;
    bind_tab                             bind_tab_type;
    i                                    NUMBER(2) := 0;
    v_where                              VARCHAR2(2000);
    
  v_date_from                          date:=to_date(v_from_date,'dd/mm/yyyy');
  v_date_upto                          date:=to_date(v_to_date,'dd/mm/yyyy'); 
  
  
  BEGIN
    IF v_to_date IS NULL THEN
       v_date_upto := trunc(SYSDATE);
     END IF;
     
    v_sql_str :=
    'select  max(clm_batch_seq_id) as clm_batch_seq_id,
             max(batch_received_date) as batch_received_date,
             max(batch_no) as batch_no,
             max(empanel_number) as empanel_number,
             sum(invoice_number) as no_of_invoices,
             sum(claimed_amt) as claimed_amt,
             max(Approved) as Approved,
             max(Rejected) as Rejected,
             max(Shortfall) as Shortfall,
             max(inprogress) as inprogress,
             max(Closed) as Closed
             from 
     (select cb.clm_batch_seq_id,cb.received_date as batch_received_date,
            cb.batch_no,d.empanel_number,count(cad.invoice_number) as invoice_number,
            sum((cad.tot_disc_gross_amount-cad.tot_patient_share_amount)) as claimed_amt,
            case when cad.clm_status_type_id = ''APR'' Then count(*) end as Approved,
            case when cad.clm_status_type_id = ''REJ'' Then count(*) end as Rejected,
            case when cad.clm_status_type_id = ''REQ'' Then count(*) end as Shortfall,
            case when cad.clm_status_type_id = ''INP'' Then count(*) end as inprogress,
            case when cad.clm_status_type_id = ''PCO'' Then count(*) end as Closed    
     from app.clm_batch_upload_details cb 
     join app.clm_authorization_details cad on (cb.clm_batch_seq_id = cad.clm_batch_seq_id)
     left outer join clm_hospital_details c on (cad.claim_seq_id = c.claim_seq_id)
     left outer join tpa_hosp_info d on (d.hosp_seq_id=c.hosp_seq_id)
     group by cb.clm_batch_seq_id,cb.received_date,cb.batch_no,d.empanel_number,cad.clm_status_type_id
     having d.empanel_number = :v_hosp_empanel_no ';
    
    IF v_batch_no IS NOT NULL THEN
      v_where := v_where  ||' AND cb.batch_no = :v_batch_no';
       i := i+1;
       bind_tab(i) := UPPER(v_batch_no);
    END IF;
 
    IF v_from_date IS NOT NULL THEN
      v_where := v_where  ||' AND trunc(cb.received_date)  BETWEEN :v_from_date AND :v_to_date ';
      i := i+1;
      bind_tab(i) := v_date_from;
      i := i+1;
      bind_tab(i) := v_date_upto;
    END IF;
    
      v_sql_str := v_sql_str ||v_where||' )group by clm_batch_seq_id';
    
    v_sql_str := 'SELECT * FROM
        (SELECT A.*,DENSE_RANK() OVER (ORDER BY '||v_sort_var||' '||v_sort_order||',ROWNUM)
        Q FROM (' ||v_sql_str|| ') A ) WHERE  Q>= :v_start_num AND Q<= :v_end_num ';


    IF bind_tab.FIRST IS NOT NULL THEN
       CASE bind_tab.COUNT
         WHEN 1  THEN OPEN result_set FOR v_sql_str USING v_hosp_empanel_no,bind_tab(1), v_start_num , v_end_num ;
         WHEN 2  THEN OPEN result_set FOR v_sql_str USING v_hosp_empanel_no,bind_tab(1),bind_tab(2), v_start_num , v_end_num ;
         WHEN 3  THEN OPEN result_set FOR v_sql_str USING v_hosp_empanel_no,bind_tab(1),bind_tab(2),bind_tab(3), v_start_num , v_end_num ;
       END CASE;
     ELSE
       OPEN result_set FOR v_sql_str USING v_hosp_empanel_no,v_start_num , v_end_num ;
     END IF;

  END select_batch_recon_summary;
--======================================================================================================================================
 --   Name        : select_claims_list
 --   Created on  : 07/12/2015
 --   Created By  : chiranjibi
 --   Comments    : provider login batch reconcilation summary report
 --                 it will show the details claims data while click on number link
--========================================================================================
PROCEDURE select_batch_recon_smry_rpt (
    v_clm_batch_seq_id                   IN  clm_batch_upload_details.clm_batch_seq_id%TYPE,
    v_flag                               IN  VARCHAR2,
    v_hosp_empanel_no                    IN  TPA_HOSP_INFO.EMPANEL_NUMBER%TYPE,
    result_set                           OUT SYS_REFCURSOR
  )
  IS
  
  BEGIN

    IF v_flag = 'TTL' THEN
    OPEN result_set for
    select to_char(cad.clm_received_date,'dd/mm/yyyy hh:mi Am') as clm_received_date,
       cad.invoice_number,
       cb.batch_no,
       to_char(cad.date_of_hospitalization,'dd/mm/yyyy hh:mi Am') as date_of_hospitalization,
       cad.mem_name as patient_name,
       (cad.tot_disc_gross_amount - cad.tot_patient_share_amount) as claimed_amt,
       case
         when cad.clm_status_type_id != 'APR' Then
          'NA'
         when cad.clm_status_type_id = 'APR' Then
          to_char(cad.tot_approved_amount)
       end as Approved_amt
  from app.clm_batch_upload_details cb
  join app.clm_authorization_details cad
    on (cb.clm_batch_seq_id = cad.clm_batch_seq_id)
  join app.clm_hospital_details ch 
    on (cad.claim_seq_id = ch.claim_seq_id) 
  join app.tpa_hosp_info hi 
    on (ch.hosp_seq_id = hi.hosp_seq_id)
  where cb.clm_batch_seq_id = v_clm_batch_seq_id and hi.empanel_number = v_hosp_empanel_no ;
 ELSE
  OPEN result_set for
    select to_char(cad.clm_received_date,'dd/mm/yyyy hh:mi Am') as clm_received_date,
       cad.invoice_number,
       cb.batch_no,
       to_char(cad.date_of_hospitalization,'dd/mm/yyyy hh:mi Am') as date_of_hospitalization,
       cad.mem_name as patient_name,
       (cad.tot_disc_gross_amount - cad.tot_patient_share_amount) as claimed_amt,
       case
         when cad.clm_status_type_id != 'APR' Then
          'NA'
         when cad.clm_status_type_id = 'APR' Then
          to_char(cad.tot_approved_amount)
       end as Approved_amt
  from app.clm_batch_upload_details cb
  join app.clm_authorization_details cad
    on (cb.clm_batch_seq_id = cad.clm_batch_seq_id)
  join app.clm_hospital_details ch 
    on (cad.claim_seq_id = ch.claim_seq_id) 
  join app.tpa_hosp_info hi 
    on (ch.hosp_seq_id = hi.hosp_seq_id)
  where cb.clm_batch_seq_id = v_clm_batch_seq_id and hi.empanel_number = v_hosp_empanel_no and cad.clm_status_type_id = v_flag;
 END IF; 
  END select_batch_recon_smry_rpt;
--======================================================================================================================================
 --   Name        : select_claims_list
 --   Created on  : 08/12/2015
 --   Created By  : chiranjibi
 --   Comments    : provider login batch invoice repot
--========================================================================================
PROCEDURE select_batch_invoice_list (
    v_hosp_empanel_no                    IN  TPA_HOSP_INFO.EMPANEL_NUMBER%TYPE,
    v_from_date                          IN  VARCHAR2,
    v_to_date                            IN  VARCHAR2,
    v_batch_no                           IN  clm_batch_upload_details.batch_no%TYPE,
    v_sort_var                           IN  VARCHAR2,
    v_sort_order                         IN  VARCHAR2 ,
    v_start_num                          IN  NUMBER ,
    v_end_num                            IN  NUMBER ,
    result_set                           OUT SYS_REFCURSOR
  )
  IS

    v_sql_str                            VARCHAR2(10000) ;
    TYPE bind_tab_type IS TABLE OF VARCHAR2(250) INDEX BY BINARY_INTEGER ;
    bind_tab                             bind_tab_type;
    i                                    NUMBER(2) := 0;
    v_where                              VARCHAR2(2000);
    
    v_date_from                          date:=to_date(v_from_date,'dd/mm/yyyy');
    v_date_upto                          date:=to_date(v_to_date,'dd/mm/yyyy'); 

  BEGIN
    IF v_to_date IS NULL THEN
       v_date_upto := trunc(SYSDATE);
     END IF;
     
    v_sql_str :=
'select rownum as sl_no,
        cb.batch_no,
       ii.ins_comp_name,
       cad.invoice_number,
       to_char(cad.date_of_hospitalization,''dd/mm/yyyy hh:mi Am'') as date_of_hospitalization,
       to_char(cad.clm_received_date,''dd/mm/yyyy hh:mi Am'') as clm_received_date,
       cad.mem_name as patient_name,
       (cad.tot_disc_gross_amount - cad.tot_patient_share_amount) as claimed_amt,
       cad.tot_net_amount,
       cad.tot_approved_amount,
       gc.description as clm_status_type_id
  from app.clm_authorization_details cad 
  join clm_batch_upload_details cb
    on (cad.clm_batch_seq_id = cb.clm_batch_seq_id)
  join tpa_ins_info ii
    on (cad.ins_seq_id = ii.ins_seq_id)
  join app.clm_hospital_details ch 
    on (cad.claim_seq_id = ch.claim_seq_id) 
  join app.tpa_hosp_info hi 
    on (ch.hosp_seq_id = hi.hosp_seq_id)
  left outer join tpa_general_code gc on (gc.general_type_id=cad.clm_status_type_id)     
 where hi.empanel_number = :v_hosp_empanel_no';
     
    IF v_batch_no IS NOT NULL THEN
      v_where := v_where  ||' AND cb.batch_no = :v_batch_no';
       i := i+1;
       bind_tab(i) := UPPER(v_batch_no);
    END IF;
 
    IF v_from_date IS NOT NULL THEN
      v_where := v_where  ||' AND trunc(cb.received_date)  BETWEEN :v_from_date AND :v_to_date ';
      i := i+1;
      bind_tab(i) := v_date_from;
      i := i+1;
      bind_tab(i) := v_date_upto;
    END IF;
    
    IF v_where IS NOT NULL THEN
      --v_where   := ' WHERE '|| SUBSTR(v_where,5);
      v_sql_str := v_sql_str ||v_where;
    END IF;

    v_sql_str := 'SELECT * FROM
        (SELECT A.*,DENSE_RANK() OVER (ORDER BY '||v_sort_var||' '||v_sort_order||',ROWNUM)
        Q FROM (' ||v_sql_str|| ') A ) WHERE  Q>= :v_start_num AND Q<= :v_end_num ';


    IF bind_tab.FIRST IS NOT NULL THEN
       CASE bind_tab.COUNT
         WHEN 1  THEN OPEN result_set FOR v_sql_str USING v_hosp_empanel_no,bind_tab(1), v_start_num , v_end_num ;
         WHEN 2  THEN OPEN result_set FOR v_sql_str USING v_hosp_empanel_no,bind_tab(1),bind_tab(2), v_start_num , v_end_num ;
         WHEN 3  THEN OPEN result_set FOR v_sql_str USING v_hosp_empanel_no,bind_tab(1),bind_tab(2),bind_tab(3), v_start_num , v_end_num ;
       END CASE;
     ELSE
       OPEN result_set FOR v_sql_str USING v_hosp_empanel_no,v_start_num , v_end_num ;
     END IF;

  END select_batch_invoice_list;

--======================================================================================================================================
 --   Name        : select_claims_list
 --   Created on  : 08/12/2015
 --   Created By  : chiranjibi
 --   Comments    : provider login batch invoice repot
--========================================================================================
PROCEDURE select_batch_invoice_rpt (
    v_hosp_empanel_no                    IN  TPA_HOSP_INFO.EMPANEL_NUMBER%TYPE,                         
    v_invoice_no                         IN  clm_authorization_details.invoice_number%TYPE,
    result_set                           OUT SYS_REFCURSOR
  )
  IS
    
  BEGIN
    open result_set for
 select rownum as sl_no,
       ii.ins_comp_name,
       cad.invoice_number,
       to_char(cad.date_of_hospitalization,'dd/mm/yyyy hh:mi Am')  as date_of_hospitalization,
       ec.description as benefit_type,
       to_char(cad.clm_received_date,'dd/mm/yyyy hh:mi Am') as clm_received_date,
       null as service_code,
       null as service_name,
       cad.mem_name as patient_name,
       (cad.tot_disc_gross_amount - cad.tot_patient_share_amount) as claimed_amt,
       cad.tot_discount_amount as disc_amt,
       null as copay_amt,
       cad.tot_net_amount,
       cad.tot_approved_amount,
       null as diff_amt,
       dd.diagnosys_code as diagnosys_code,
       imd.short_desc as diagnosys,
       gc.description as clm_status_type_id,
       cc.check_num,
       to_char(cc.check_date,'dd/mm/yyyy hh:mi Am') as check_date,
       cc.check_amount,
       cad.remarks
  from app.clm_authorization_details cad 
  join clm_batch_upload_details cb
    on (cad.clm_batch_seq_id = cb.clm_batch_seq_id)
  join tpa_ins_info ii
    on (cad.ins_seq_id = ii.ins_seq_id)
  join app.clm_hospital_details ch 
    on (cad.claim_seq_id = ch.claim_seq_id) 
  join app.tpa_hosp_info hi 
    on (ch.hosp_seq_id = hi.hosp_seq_id)
  join app.diagnosys_details dd
    on (cad.claim_seq_id = dd.claim_seq_id and dd.primary_ailment_yn = 'Y')
  left outer join app.tpa_icd10_master_details imd
    on (dd.diagnosys_code = imd.icd_code)
  left outer join tpa_general_code ec 
    on (cad.benifit_type = ec.general_type_id)    
  left outer join fin_app.tpa_claims_payment tcp
    on (cad.claim_seq_id = tcp.claim_seq_id)
  left outer join fin_app.tpa_payment_checks_details cd
    on (tcp.payment_seq_id = cd.payment_seq_id)
  left outer join fin_app.tpa_claims_check cc
    on (cd.claims_chk_seq_id = cc.claims_chk_seq_id)
  left outer join tpa_general_code gc on (gc.general_type_id=cad.clm_status_type_id)  
 where hi.empanel_number = v_hosp_empanel_no and cad.invoice_number = v_invoice_no
 order by rownum;
  END select_batch_invoice_rpt;
--======================================================================================================================================
 --   Name        : select_claims_list
 --   Created on  : 08/12/2015
 --   Created By  : chiranjibi
 --   Comments    : provider login overdue repot
--========================================================================================
PROCEDURE select_overdue_rpt (
    v_hosp_empanel_no                    IN  TPA_HOSP_INFO.EMPANEL_NUMBER%TYPE,
    v_from_date                          IN  VARCHAR2,
    v_to_date                            IN  VARCHAR2,
    v_invoice_no                         IN  clm_authorization_details.invoice_number%TYPE,
    result_set                           OUT SYS_REFCURSOR,
    v_sort_var                           IN  VARCHAR2 default null,
    v_sort_order                         IN  VARCHAR2 default null,
    v_start_num                          IN  NUMBER default null,
    v_end_num                            IN  NUMBER default null
  )
  IS

    v_sql_str                            VARCHAR2(10000) ;
    TYPE bind_tab_type IS TABLE OF VARCHAR2(250) INDEX BY BINARY_INTEGER ;
    bind_tab                             bind_tab_type;
    i                                    NUMBER(2) := 0;
    v_where                              VARCHAR2(2000);
    
    v_date_from                          date:=to_date(v_from_date,'dd/mm/yyyy');
    v_date_upto                          date:=to_date(v_to_date,'dd/mm/yyyy'); 

  BEGIN
     IF v_to_date IS NULL THEN
       v_date_upto := trunc(SYSDATE);
     END IF;
    v_sql_str :=
       'select to_char(cad.clm_received_date,''dd/mm/yyyy hh:mi Am'') as clm_received_date,
               cad.invoice_number,
               to_char(cad.date_of_hospitalization,''dd/mm/yyyy hh:mi Am'') as date_of_hospitalization,
               cad.mem_name as patient_name,
               ii.ins_comp_name,
               (cad.tot_disc_gross_amount - cad.tot_patient_share_amount) as claimed_amt,
               to_char((cad.clm_received_date + 50),''dd/mm/yyyy hh:mi Am'') as due_date,
               (trunc(sysdate) - trunc(cad.clm_received_date + 50)) over_due_by
       from app.clm_authorization_details cad
       join tpa_ins_info ii
       on (cad.ins_seq_id = ii.ins_seq_id)
       join app.clm_hospital_details ch 
       on (cad.claim_seq_id = ch.claim_seq_id) 
       join app.tpa_hosp_info hi 
       on (ch.hosp_seq_id = hi.hosp_seq_id)  
       where hi.empanel_number = :v_hosp_empanel_no ';
     
    IF v_invoice_no IS NOT NULL THEN
      v_where := v_where  ||' AND cad.invoice_number = :v_invoice_no';
       i := i+1;
       bind_tab(i) := UPPER(v_invoice_no);
    END IF;
 
    IF v_from_date IS NOT NULL THEN
      v_where := v_where  ||' AND trunc(cad.clm_received_date)  BETWEEN :v_from_date AND :v_to_date ';
      i := i+1;
      bind_tab(i) := v_date_from;
      i := i+1;
      bind_tab(i) := v_date_upto;
    END IF;
    
    IF v_where IS NOT NULL THEN
      --v_where   := ' WHERE '|| SUBSTR(v_where,5);
      v_sql_str := v_sql_str ||v_where;
    END IF;
    
 IF v_start_num IS NOT NULL THEN
    v_sql_str := 'SELECT * FROM
        (SELECT A.*,DENSE_RANK() OVER (ORDER BY '||v_sort_var||' '||v_sort_order||',ROWNUM)
        Q FROM (' ||v_sql_str|| ') A ) WHERE  Q>= :v_start_num AND Q<= :v_end_num ';


    IF bind_tab.FIRST IS NOT NULL THEN
       CASE bind_tab.COUNT
         WHEN 1  THEN OPEN result_set FOR v_sql_str USING v_hosp_empanel_no,bind_tab(1), v_start_num , v_end_num ;
         WHEN 2  THEN OPEN result_set FOR v_sql_str USING v_hosp_empanel_no,bind_tab(1),bind_tab(2), v_start_num , v_end_num ;
         WHEN 3  THEN OPEN result_set FOR v_sql_str USING v_hosp_empanel_no,bind_tab(1),bind_tab(2),bind_tab(3), v_start_num , v_end_num ;
       END CASE;
     ELSE
       OPEN result_set FOR v_sql_str USING v_hosp_empanel_no,v_start_num , v_end_num ;
     END IF;
 ELSE 
   
    IF bind_tab.FIRST IS NOT NULL THEN
       CASE bind_tab.COUNT
         WHEN 1  THEN OPEN result_set FOR v_sql_str USING v_hosp_empanel_no,bind_tab(1);
         WHEN 2  THEN OPEN result_set FOR v_sql_str USING v_hosp_empanel_no,bind_tab(1),bind_tab(2) ;
         WHEN 3  THEN OPEN result_set FOR v_sql_str USING v_hosp_empanel_no,bind_tab(1),bind_tab(2),bind_tab(3) ;
       END CASE;
     ELSE
       OPEN result_set FOR v_sql_str USING v_hosp_empanel_no ;
     END IF;
END IF;
  END select_overdue_rpt;
--======================================================================================================================================
 --   Name        : select_claims_list
 --   Created on  : 08/12/2015
 --   Created By  : chiranjibi
 --   Comments    : provider login account dash board
--========================================================================================
PROCEDURE dashboard_account (
    v_hosp_empanel_no                    IN  TPA_HOSP_INFO.EMPANEL_NUMBER%TYPE,
    v_from_date                          IN  VARCHAR2,
    v_to_date                            IN  VARCHAR2,
    result_set                           OUT SYS_REFCURSOR
  )
  IS
  v_date_from                          date:=to_date(v_from_date,'dd/mm/yyyy');
  v_date_upto                          date:=to_date(v_to_date,'dd/mm/yyyy'); 
  
  BEGIN
    
    IF v_to_date IS NULL THEN
       v_date_upto := trunc(SYSDATE);
     END IF;
   open result_set for
         select sum(nvl(Approved_amt,0)+nvl(Rejected_amt,0)+nvl(Shortfall_amt,0)+nvl(inprogress_amt,0)+nvl(settled_amt,0)) as opening_amt,
        max(Approved_amt) as Approved_amt,
        max(Rejected_amt) as Rejected_amt,
        max(Shortfall_amt) as Shortfall_amt,
        max(inprogress_amt) as inprogress_amt,
        max(Closed_amt) as Close_amt,
        max(settled_amt) as settled_amt,
        (sum(nvl(Approved_amt,0)+nvl(Rejected_amt,0)+nvl(Shortfall_amt,0)+nvl(inprogress_amt,0)+nvl(settled_amt,0))-max(nvl(settled_amt,0))) as Closed_Amt,
       to_char(v_date_from,'dd/mm/yyyy') as from_date,
       to_char(v_date_upto,'dd/mm/yyyy') as to_date
    from(
        select max(Approved) as Approved_amt,
               max(Rejected) as Rejected_amt,
               max(Shortfall) as Shortfall_amt,
               max(inprogress) as inprogress_amt,
               max(Closed) as Closed_amt,
               max(settled) as settled_amt
       from(
select 
null as Approved,
case when cad.clm_status_type_id = 'REJ' Then sum((cad.tot_disc_gross_amount-cad.tot_patient_share_amount)-cad.tot_approved_amount) end as Rejected,
case when cad.clm_status_type_id = 'REQ' Then sum(cad.tot_disc_gross_amount-cad.tot_patient_share_amount) end as Shortfall,
case when cad.clm_status_type_id = 'INP' Then sum(cad.tot_disc_gross_amount-cad.tot_patient_share_amount) end as inprogress,
case when cad.clm_status_type_id = 'PCO' Then sum(cad.tot_disc_gross_amount-cad.tot_patient_share_amount-cad.tot_approved_amount) end as Closed,
null as settled      
from app.clm_authorization_details cad join app.clm_hospital_details ch on (cad.claim_seq_id = ch.claim_seq_id)
join app.tpa_hosp_info hi on (ch.hosp_seq_id = hi.hosp_seq_id)
where hi.empanel_number = v_hosp_empanel_no/*'UAE-DXB-CPC-0031'*/
and cad.clm_received_date between v_date_from and v_date_upto
group by cad.clm_status_type_id
union 
select sum(Approved) as Approved,
       null as Rejected,
       null as Shortfall,
       null as inprogress,
       null as Closed,
       max(settled) as settled from(
select case when cad.clm_status_type_id = 'APR' AND tcp.claim_payment_status != 'PAID' Then sum(cad.tot_approved_amount)end as Approved,
case when cad.clm_status_type_id = 'APR' AND tcp.claim_payment_status = 'PAID' Then sum(cad.tot_approved_amount)end as settled
from app.clm_authorization_details cad join app.clm_hospital_details ch on (cad.claim_seq_id = ch.claim_seq_id)
join app.tpa_hosp_info hi on (ch.hosp_seq_id = hi.hosp_seq_id)
join fin_app.tpa_claims_payment tcp on (cad.claim_seq_id = tcp.claim_seq_id)
where hi.empanel_number = v_hosp_empanel_no /*'UAE-DXB-HOS-0054'*/
and cad.clm_received_date between v_date_from and v_date_upto
group by cad.clm_status_type_id,tcp.claim_payment_status) ));

END dashboard_account;
---==================================================================================
 --   Name        : Prov_rpt_dwnl_history
 --   Created on  : 22/12/2015
 --   Created By  : chiranjibi
 --   Comments    : provider login downloaded report history will store
--======================================================================================================
PROCEDURE Prov_rpt_dwnl_history (
 v_hosp_empanel_no          IN tpa_hosp_info.empanel_number%type,
 v_prov_rpt_downl_name       IN provider_repot_history.prov_rpt_downl_name%type,
 v_prov_rpt_downl_status     IN provider_repot_history.prov_rpt_downl_status%type,
 v_prov_rpt_downl_by         IN provider_repot_history.prov_rpt_downl_by%type,
 v_prov_rpt_downl_data       IN provider_repot_history.prov_rpt_downl_data%type default null,
 v_rows_processed           OUT number
  )
  IS
  v_hosp_seq_id     number;
  BEGIN
   v_hosp_seq_id := get_associated_id('HOS',v_hosp_empanel_no);
  insert into provider_repot_history
         (prov_rpt_downl_seq_id,
          hosp_seq_id,
          prov_rpt_downl_name,
          prov_rpt_downl_date,
          prov_rpt_downl_status,
          prov_rpt_downl_by,
          prov_rpt_downl_data)
  values (prov_rpt_downl_seq.nextval,
          v_hosp_seq_id,
          v_prov_rpt_downl_name,
          sysdate,
          v_prov_rpt_downl_status,
          v_prov_rpt_downl_by,
          v_prov_rpt_downl_data);

  v_rows_processed:=sql%rowcount;

  commit;
  END Prov_rpt_dwnl_history;
--==================================================================================
 --   Name        : select_prov_dwnl_rpt_details
 --   Created on  : 23/12/2015
 --   Created By  : chiranjibi
 --   Comments    : provider login preauth details data will fetch for a preauth number
--========================================================================================
PROCEDURE select_prov_dwnl_rpt_details ( v_hosp_empanel_no          IN tpa_hosp_info.empanel_number%type,
                                         v_added_by                 IN provider_repot_history.prov_rpt_downl_by%type,
                                         result_set                 OUT SYS_REFCURSOR 
                                       ) IS
   v_hosp_seq_id     number;
  BEGIN

   v_hosp_seq_id := get_associated_id('HOS',v_hosp_empanel_no);

    OPEN result_set FOR
    select * from ( 
         select to_char(r.prov_rpt_downl_date,'dd-mm-yyyy')as report_date,
                to_char(r.prov_rpt_downl_date,'hh:mi am')as report_time,
                r.prov_rpt_downl_name,
                r.prov_rpt_downl_status
           from provider_repot_history r
           where r.hosp_seq_id = v_hosp_seq_id and prov_rpt_downl_by = v_added_by
           order by r.prov_rpt_downl_date desc)
           where rownum<6;
END select_prov_dwnl_rpt_details; 
--===================================================================
FUNCTION get_associated_id(v_flag           VARCHAR2,
                           v_value          VARCHAR2)
RETURN VARCHAR2
IS

CURSOR hosp_cur IS
SELECT thi.hosp_seq_id FROM tpa_hosp_info thi
where thi.empanel_number=upper(trim(v_value));

v_result         VARCHAR2(100);

BEGIN
  IF v_flag='HOS' THEN
    OPEN hosp_cur;
    FETCH hosp_cur INTO v_result;
    CLOSE hosp_cur;
  END IF;  
    RETURN v_result;
END get_associated_id;
--======================================================================
PROCEDURE select_clinician_list (
    v_clinician_id             IN OUT tpa_hosp_professionals.professional_id%TYPE,
    v_clinician_name           IN OUT tpa_hosp_professionals.contact_name%TYPE,
    v_provider_id              IN OUT tpa_hosp_info.hosp_licenc_numb%TYPE,
    v_hosp_name                IN OUT tpa_hosp_info.hosp_name%TYPE,
    v_sort_var                 IN OUT VARCHAR2 ,
    v_sort_order               IN OUT VARCHAR2,
    v_start_num                IN OUT NUMBER  ,
    v_end_num                  IN OUT NUMBER  ,
    v_added_by                 IN NUMBER,
    v_hosp_seq_id              IN NUMBER,
    v_result_set               OUT SYS_REFCURSOR
  )
  IS
    v_str                      VARCHAR2(2000);
    
    cursor prov_cur is 
      select hi.provider_type_id from app.tpa_hosp_info hi 
      where hi.hosp_seq_id = v_hosp_seq_id;
    
    v_prov_type               varchar2(40);
    
  BEGIN

    v_sort_var   := CASE WHEN v_sort_var IS NULL THEN 'PROFESSIONAL_ID' ELSE v_sort_var END;
    v_sort_order := CASE WHEN v_sort_order IS NULL THEN 'ASC' ELSE v_sort_order END;
    v_start_num  := CASE WHEN v_start_num IS NULL THEN 1 ELSE v_start_num END;
    v_end_num    := CASE WHEN v_end_num IS NULL THEN 2000 ELSE v_end_num END;

    v_clinician_id        := CASE WHEN v_clinician_id IS NOT NULL THEN UPPER(v_clinician_id)||'%' ELSE v_clinician_id END;
    v_clinician_name      := CASE WHEN v_clinician_name IS NOT NULL THEN '%'||UPPER(v_clinician_name)||'%' ELSE v_clinician_name END;
    
    v_provider_id         := CASE WHEN v_provider_id IS NOT NULL THEN UPPER(v_provider_id)||'%' ELSE v_provider_id END;
    v_hosp_name           := CASE WHEN v_hosp_name IS NOT NULL THEN '%'||UPPER(v_hosp_name)||'%' ELSE v_hosp_name END;
    
    OPEN prov_cur;
    FETCH prov_cur into v_prov_type;
    CLOSE prov_cur;
    
    
    IF v_prov_type in ('PHR','OPT','DCN') THEN
    v_str :=
        'SELECT
         p.contact_seq_id ,p.professional_id ,p.contact_name 
         FROM tpa_hosp_professionals p left outer join tpa_hosp_info i on (i.hosp_seq_id=p.hosp_seq_id)
         WHERE( :v_clinician_id IS NULL OR p.professional_id LIKE :v_clinician_id )
         AND ( :v_clinician_name IS NULL OR UPPER(p.contact_name) LIKE :v_clinician_name )
         AND (:v_provider_id IS NULL OR i.empanel_number LIKE :v_provider_id )
         AND ( :v_hosp_name IS NULL OR UPPER(i.hosp_name) LIKE :v_hosp_name )  ';
        
    v_str := 'SELECT * FROM
      (SELECT A.*, DENSE_RANK() OVER (ORDER BY '||v_sort_var||' '||v_sort_order||',ROWNUM) Q FROM (' ||v_str|| ') A )
       WHERE  Q>= :v_start_num  AND Q<= :v_end_num ';

    OPEN v_result_set FOR v_str USING v_clinician_id, v_clinician_id, v_clinician_name, v_clinician_name , v_provider_id , v_provider_id , v_hosp_name , v_hosp_name, v_start_num, v_end_num;
   
   ELSIF v_prov_type in ('HOS','CPC','SPC','DEN') THEN
     
     v_str :=
       ' SELECT
         p.contact_seq_id ,p.professional_id ,p.contact_name,gc.general_type_id CONSULTAITON,csm.specialty_id speciality 
         FROM tpa_hosp_professionals p left outer join tpa_hosp_info i on (i.hosp_seq_id=p.hosp_seq_id)
         left outer join tpa_general_code gc on (p.consult_gen_type=gc.general_type_id)
         left outer join app.dha_clnsn_specialties_master csm on (csm.specialty_id=p.speciality_id)
         WHERE (i.hosp_seq_id = :v_hosp_seq_id )
         AND ( :v_clinician_id1 IS NULL OR p.professional_id LIKE :v_clinician_id1 )
         AND ( :v_clinician_name1 IS NULL OR UPPER(p.contact_name) LIKE :v_clinician_name1 )
         AND ( :v_provider_id1 IS NULL OR i.empanel_number LIKE :v_provider_id1 )
         AND ( :v_hosp_name1 IS NULL OR UPPER(i.hosp_name) LIKE :v_hosp_name1 )  ';
          
    v_str := 'SELECT * FROM
      (SELECT A.*, DENSE_RANK() OVER (ORDER BY '||v_sort_var||' '||v_sort_order||',ROWNUM) Q FROM (' ||v_str|| ') A )
       WHERE  Q>= :v_start_num  AND Q<= :v_end_num ';

    OPEN v_result_set FOR v_str USING v_hosp_seq_id, v_clinician_id, v_clinician_id, v_clinician_name, v_clinician_name , v_provider_id , v_provider_id , v_hosp_name , v_hosp_name, v_start_num, v_end_num;
  END IF;
  
  END select_clinician_list;
--====================================================================================
procedure Dashboard_batch_no(
    v_input_list        IN  VARCHAR2,
    v_result_set       OUT SYS_REFCURSOR)
is

 str_tab    ttk_util_pkg.str_table_type;


begin

 str_tab := ttk_util_pkg.parse_str ( v_input_list );

open v_result_set for
select sum(inp_claims) as inprogress,sum(shortfal_claims) as shortfalls,sum (closed_claims) as closed ,sum(reject_claims) as rejected ,sum(apr_claims) as approved,
str_tab(2) as batch,sum(total_claims) as Received 
from (

SELECT 0 AS inp_claims,0 as shortfal_claims,0 as closed_claims,0 as reject_claims,0 AS apr_claims,count(1) as total_claims
          FROM clm_authorization_details a
      JOIN APP.CLM_BATCH_UPLOAD_DETAILS B ON (A.CLM_BATCH_SEQ_ID=B.CLM_BATCH_SEQ_ID)
         join clm_hospital_details f on (a.claim_seq_id=f.claim_seq_id and f.hosp_seq_id=str_tab(1) )
         LEFT OUTER  JOIN tpa_enr_policy_member d              ON(a.member_seq_id           =d.member_seq_id)
         LEFT OUTER  JOIN tpa_enr_policy_group e               ON(d.policy_group_seq_id=e.policy_group_seq_id)
         WHERE  B.BATCH_NO=str_tab(2)

union all
SELECT count(1) AS inp_claims,0 as shortfal_claims,0 as closed_claims,0 as reject_claims,0 AS apr_claims,0 as total_claims
          FROM clm_authorization_details a
      JOIN APP.CLM_BATCH_UPLOAD_DETAILS B ON (A.CLM_BATCH_SEQ_ID=B.CLM_BATCH_SEQ_ID)
         join clm_hospital_details f on (a.claim_seq_id=f.claim_seq_id and f.hosp_seq_id=str_tab(1) )
         LEFT OUTER  JOIN tpa_enr_policy_member d              ON(a.member_seq_id           =d.member_seq_id)
         LEFT OUTER  JOIN tpa_enr_policy_group e               ON(d.policy_group_seq_id=e.policy_group_seq_id)
         WHERE  B.BATCH_NO=str_tab(2)
         AND a.clm_status_type_id='INP'
union all
SELECT 0 AS inp_claims,count(1) as shortfal_claims,0 as closed_claims,0 as reject_claims,0 AS apr_claims,0 as total_claims
          FROM clm_authorization_details a
      JOIN APP.CLM_BATCH_UPLOAD_DETAILS B ON (A.CLM_BATCH_SEQ_ID=B.CLM_BATCH_SEQ_ID)
         join clm_hospital_details f on (a.claim_seq_id=f.claim_seq_id and f.hosp_seq_id=str_tab(1) )
         LEFT OUTER  JOIN tpa_enr_policy_member d              ON(a.member_seq_id           =d.member_seq_id)
         LEFT OUTER  JOIN tpa_enr_policy_group e               ON(d.policy_group_seq_id=e.policy_group_seq_id)
         WHERE  B.BATCH_NO=str_tab(2)
         AND a.clm_status_type_id='REQ'
union all
SELECT 0 AS inp_claims,0 as shortfal_claims,count(1) as closed_claims,0 as reject_claims,0 AS apr_claims,0 as total_claims
          FROM clm_authorization_details a
      JOIN APP.CLM_BATCH_UPLOAD_DETAILS B ON (A.CLM_BATCH_SEQ_ID=B.CLM_BATCH_SEQ_ID)
         join clm_hospital_details f on (a.claim_seq_id=f.claim_seq_id and f.hosp_seq_id=str_tab(1) )
         LEFT OUTER  JOIN tpa_enr_policy_member d              ON(a.member_seq_id           =d.member_seq_id)
         LEFT OUTER  JOIN tpa_enr_policy_group e               ON(d.policy_group_seq_id=e.policy_group_seq_id)
         WHERE  B.BATCH_NO=str_tab(2)
         AND a.clm_status_type_id='PCO'
union all
SELECT 0 AS inp_claims,0 as shortfal_claims,0 as closed_claims,count(1) as reject_claims,0 AS apr_claims,0 as total_claims
          FROM clm_authorization_details a
      JOIN APP.CLM_BATCH_UPLOAD_DETAILS B ON (A.CLM_BATCH_SEQ_ID=B.CLM_BATCH_SEQ_ID)
         join clm_hospital_details f on (a.claim_seq_id=f.claim_seq_id and f.hosp_seq_id=str_tab(1) )
         LEFT OUTER  JOIN tpa_enr_policy_member d              ON(a.member_seq_id           =d.member_seq_id)
         LEFT OUTER  JOIN tpa_enr_policy_group e               ON(d.policy_group_seq_id=e.policy_group_seq_id)
         WHERE  B.BATCH_NO=str_tab(2)
         AND a.clm_status_type_id='REJ'
union all
SELECT 0 AS inp_claims,0 as shortfal_claims,0 as closed_claims,0 as reject_claims,COUNT(1) AS apr_claims,0 as total_claims
          FROM clm_authorization_details a
      JOIN APP.CLM_BATCH_UPLOAD_DETAILS B ON (A.CLM_BATCH_SEQ_ID=B.CLM_BATCH_SEQ_ID)
         join clm_hospital_details f on (a.claim_seq_id=f.claim_seq_id and f.hosp_seq_id=str_tab(1) )
         LEFT OUTER  JOIN tpa_enr_policy_member d              ON(a.member_seq_id           =d.member_seq_id)
         LEFT OUTER  JOIN tpa_enr_policy_group e               ON(d.policy_group_seq_id=e.policy_group_seq_id)
         WHERE  B.BATCH_NO=str_tab(2)
         AND a.clm_status_type_id='APR'

);

end Dashboard_batch_no;
--======================================================================

procedure dash_board_batch_no (v_hosp_seq_id tpa_hosp_info.hosp_seq_id%type,
                              v_group_id IN VARCHAR2,
                              v_out_xml     out xmltype) is






v_input                varchar2(40);
v_cursor               sys_refcursor;

type ref_cur_rec is record (

inprogress                 number(12,2),
shortfalls                 number(12,2),
closed                     number(12,2),
rejected                   number(12,2),
approved                   number(12,2),
batch                      varchar2(50),
received                   number(12,2)) ;


type ref_cur_table is table of ref_cur_rec;

v_result                ref_cur_table;


      v_doc                DBMS_XMLDOM.DOMDocument;
      v_elem               DBMS_XMLDOM.DOMElement;
      v_node               DBMS_XMLDOM.DOMNode;
      v_parent_node        DBMS_XMLDOM.DOMNODE;
      v_root_node          DBMS_XMLDOM.DOMNode;

begin

v_input:='|'||v_hosp_seq_id||'|'||v_group_id||'|';

 Dashboard_batch_no(v_input,v_cursor);

      v_doc := dbms_xmldom.newDOMDocument;
      dbms_xmldom.setVersion( v_doc, '1.0' );
      v_root_node := dbms_xmldom.makeNode(v_doc);

      v_elem := dbms_xmldom.createElement( v_doc, 'hospital' );
      v_node := dbms_xmldom.makeNode( v_elem );
      v_root_node := dbms_xmldom.appendChild( v_root_node, v_node );

      v_elem := dbms_xmldom.createElement(v_doc, 'batchno');


 fetch v_cursor bulk collect into v_result;

       fOR i in v_result.First..v_result.Last Loop

         dbms_xmldom.setattribute(v_elem,'inprogress',v_result(i).inprogress);
      dbms_xmldom.setattribute(v_elem,'shortfalls',v_result(i).shortfalls);
      dbms_xmldom.setattribute(v_elem,'closed',v_result(i).closed);
      dbms_xmldom.setattribute(v_elem,'rejected',v_result(i).rejected);
      dbms_xmldom.setattribute(v_elem,'approved',v_result(i).approved);
      dbms_xmldom.setattribute(v_elem,'received',v_result(i).received);
      dbms_xmldom.setattribute(v_elem,'batch',v_result(i).batch);
   /*   dbms_xmldom.setattribute(v_elem,'startdate',v_from_date);
      dbms_xmldom.setattribute(v_elem,'enddate',v_to_date);*/
      --dbms_xmldom.setattribute(v_elem,'startdate',v_group_id);
      --dbms_xmldom.setattribute(v_elem,'enddate',v_to_date);
   END LOOP;

   close v_cursor;
  v_node := dbms_xmldom.makeNode(v_elem);
  v_parent_node := dbms_xmldom.appendChild( v_root_node, v_node);
  
   

   v_out_xml := dbms_xmldom.getxmltype(v_doc);
    


   dbms_xmldom.freeDocument(v_doc);
   

end dash_board_batch_no;
--=================================================================================

PROCEDURE select_clm_rpt_list(
  --V_HOSP_SEQ_ID                         IN  pat_authorization_details.hosp_seq_id%type,
  v_fromdate                            IN   VARCHAR2 ,
  v_toDate                              IN   VARCHAR2 ,
  v_fromdate1                           IN   VARCHAR2 ,
  v_toDate1                             IN   VARCHAR2 ,
  v_patientName                         IN  clm_authorization_details.mem_name%type,
  v_status                              IN  tpa_general_code.description%type,
  v_invoice_number                      IN  clm_authorization_details.invoice_number%type,
  v_batch_no                        in  varchar2,
  v_memberId                            IN  clm_authorization_details.tpa_enrollment_id%type,
  v_claim_number                        IN  clm_authorization_details.claim_number%type,
  v_benifit_type                      in varchar2,
  v_ref_no                              IN  clm_authorization_details.EVENT_NO%type,
  v_qatar_id                        IN  varchar2,
  v_pay_ref_no                      IN VARCHAR2,
  v_sort_var                            IN  VARCHAR2,
  v_sort_order                          IN  VARCHAR2 ,
  v_start_num                           IN  NUMBER ,
  v_end_num                             IN  NUMBER ,
  V_HOSP_SEQ_ID                         IN  pat_authorization_details.hosp_seq_id%type,
  v_rpt_id                              IN  VARCHAR2,
  --v_added_by                            IN  NUMBER,
  result_set                            OUT SYS_REFCURSOR
  )
  IS
  v_sql_str                            VARCHAR2(10000) ;
  TYPE bind_tab_type IS TABLE OF VARCHAR2(250) INDEX BY BINARY_INTEGER ;
    bind_tab                             bind_tab_type;
    i                                    NUMBER(2) := 0;
    v_where                              VARCHAR2(2000);
   -- v_stat                               VARCHAR2(20):=null;
  
    v_fdate   clm_authorization_details.date_of_hospitalization%type:=to_date(v_fromdate,'dd/mm/yyyy');
    v_to_date clm_authorization_details.date_of_discharge%type  :=to_date(v_toDate,'dd/mm/yyyy')+1;
  v_fdate1   clm_authorization_details.CLM_RECEIVED_DATE%type:=to_date(v_fromdate1,'dd/mm/yyyy');
    v_to_date1 clm_authorization_details.CLM_RECEIVED_DATE%type  :=to_date(v_toDate1,'dd/mm/yyyy')+1;

    
    
  BEGIN

  IF v_rpt_id = 'CDR' THEN
  v_sql_str :='SELECT TO_CHAR(CAD.CLM_RECEIVED_DATE,''DD/MM/YYYY'') AS CLM_RECEIVED_DATE,
TO_CHAR(CAD.DATE_OF_HOSPITALIZATION,''DD/MM/YYYY'') AS DATE_OF_HOSPITALIZATION,
b.BATCH_NO,
CAD.INVOICE_NUMBER,
CAD.EVENT_NO,
CAD.TPA_ENROLLMENT_ID,
CAD.EMIRATE_ID,
CAD.MEM_NAME,
CAD.CLAIM_NUMBER,
case when Cad.benifit_type = ''OPTS'' then ''Out-Patient'' 
            when Cad.benifit_type = ''OPTC'' then ''Optical''
            when Cad.benifit_type = ''IMTI'' then ''In-Patient Maternity''
            when Cad.benifit_type = ''OMTI''  then ''Out-Patient Maternity''
            when Cad.benifit_type = ''IPT'' then ''In-Patient''
            when Cad.benifit_type = ''DNTL'' then ''Dental''
            when Cad.benifit_type = ''HEAC'' then ''Health Check-up''
            when Cad.benifit_type = ''DAYC'' then ''Daycare'' end as BENIFIT_TYPE ,
EC.DESCRIPTION AS CLM_STATUS_TYPE_ID,
C.INTERNAL_CODE,
case when length(c.code) > 14 then 
     regexp_substr(mas.Short_Description,''[^,]+'')
 else
   c.internal_desc end as INTERNAL_DESC,
C.PROVIDER_NET_AMOUNT as PAT_APPROVED_AMOUNT,
C.GROSS_AMOUNT AS TOT_GROSS_AMOUNT,
C.DISCOUNT_AMOUNT AS TOT_DISCOUNT_AMOUNT,
C.PATIENT_SHARE_AMOUNT AS TOT_PATIENT_SHARE_AMOUNT,
case when (nvl(cad.ucr_flag,''N'')=''N'' and nvl(cad.ri_copar_flag,''N'')=''N'') then (nvl(c.disc_gross_amount,0)-nvl(c.patient_share_amount,0))-nvl(c.approved_amount,0) 
              else nvl(c.disallowed_amount,0) end  AS DISALLOWED_AMOUNT,
C.APPROVED_AMOUNT AS TOT_APPROVED_AMOUNT,
CASE WHEN C.OVERRIDE_YN = ''Y'' AND (C.DISC_GROSS_AMOUNT - C.PATIENT_SHARE_AMOUNT) > 0 THEN
  CASE WHEN (C.DISC_GROSS_AMOUNT - C.PATIENT_SHARE_AMOUNT) = C.ALLOWED_AMOUNT THEN
    NULL
  ELSE 
    C.DENIAL_DESC
  END
ELSE 
   C.DENIAL_DESC
END AS DENIAL_DESC,
--C.DENIAL_DESC,
f.CHECK_NUM AS PAYMENT_REFRENCE_NUMBER,
TO_CHAR(f.CHECK_DATE,''DD/MM/YYYY'') AS CHECK_DATE,
DECODE(CP.CLAIM_PAYMENT_STATUS, ''READY_TO_BANK'', ''READY TO BANK'', ''SENT_TO_BANK'', ''SENT TO BANK'', ''PENDING'', ''PENDING'') AS CLAIM_PAYMENT_STATUS

from CLM_AUTHORIZATION_DETAILS cad left outer join clm_batch_upload_details b on (b.clm_batch_seq_id=cad.clm_batch_seq_id and b.batch_status_type=''COMP'')
left outer join PAT_ACTIVITY_DETAILS C on (c.CLAIM_SEQ_ID=Cad.CLAIM_SEQ_ID)
    left outer join tpa_claims_payment cp on (cad.claim_seq_id=cp.claim_seq_id)
    left outer join tpa_payment_checks_details pcd on (cp.payment_seq_id=pcd.payment_seq_id)
    left outer join tpa_claims_check f on (pcd.claims_chk_seq_id=f.claims_chk_seq_id)
	left outer join tpa_enr_policy e on (e.policy_seq_id=cad.policy_seq_id)
    left outer join clm_hospital_details HD on (HD.claim_seq_id=cad.claim_seq_id)
    left outer join tpa_general_code ec on (Cad.CLM_STATUS_TYPE_ID = ec.general_type_id)
    left outer join tpa_hosp_info thi on (thi.hosp_seq_id=HD.hosp_seq_id)
    left join APP.Tpa_Activity_Master_Details mas on (mas.Activity_Code=c.code)';
    
  ELSE 
        v_sql_str :=' SELECT TO_CHAR(CAD.CLM_RECEIVED_DATE,''DD/MM/YYYY'') AS CLM_RECEIVED_DATE,
TO_CHAR(CAD.DATE_OF_HOSPITALIZATION,''DD/MM/YYYY'') AS DATE_OF_HOSPITALIZATION,
b.BATCH_NO,
cad.INVOICE_NUMBER,
cad.EVENT_NO,
CAD.TPA_ENROLLMENT_ID,
cad.EMIRATE_ID,
cad.MEM_NAME,
case when Cad.benifit_type = ''OPTS'' then ''Out-Patient'' 
            when Cad.benifit_type = ''OPTC'' then ''Optical''
            when Cad.benifit_type = ''IMTI'' then ''In-Patient Maternity''
            when Cad.benifit_type = ''OMTI''  then ''Out-Patient Maternity''
            when Cad.benifit_type = ''IPT'' then ''In-Patient''
            when Cad.benifit_type = ''DNTL'' then ''Dental''
            when Cad.benifit_type = ''HEAC'' then ''Health Check-up''
            when Cad.benifit_type = ''DAYC'' then ''Daycare'' end as BENIFIT_TYPE ,
cad.CLAIM_NUMBER,
EC.DESCRIPTION AS CLM_STATUS_TYPE_ID,
cad.REQUESTED_AMOUNT as PAT_APPROVED_AMOUNT,
cad.TOT_GROSS_AMOUNT,
cad.TOT_DISCOUNT_AMOUNT,
cad.TOT_PATIENT_SHARE_AMOUNT,
case when (nvl(cad.ucr_flag,''N'')=''N'' and nvl(cad.ri_copar_flag,''N'')=''N'') then
             case when nvl(cad.completed_yn,''N'')=''Y''then 
                     CASE WHEN SIGN ((cad.tot_disc_gross_amount-nvl(cad.tot_patient_share_amount,0))-nvl(cad.final_app_amount,0)) = -1 THEN 0
                          ELSE (cad.tot_disc_gross_amount-nvl(cad.tot_patient_share_amount,0))-nvl(cad.final_app_amount,0) END
                  else CASE WHEN SIGN((cad.tot_disc_gross_amount-nvl(cad.tot_patient_share_amount,0))-nvl(cad.tot_approved_amount,0)) = -1 THEN 0
                            ELSE (cad.tot_disc_gross_amount-nvl(cad.tot_patient_share_amount,0))-nvl(cad.tot_approved_amount,0) END
                  end end AS DISALLOWED_AMOUNT,
cad.TOT_APPROVED_AMOUNT,
F.CHECK_NUM AS PAYMENT_REFRENCE_NUMBER,
TO_CHAR(f.CHECK_DATE,''DD/MM/YYYY'') AS CHECK_DATE


FROM  clm_authorization_details cad 
  join clm_batch_upload_details b on (b.clm_batch_seq_id=cad.clm_batch_seq_id and b.batch_status_type=''COMP'')

 --join APP.CLM_BATCH_UPLOAD_DETAILS b on (b.CLM_BATCH_SEQ_ID=cad.CLM_BATCH_SEQ_ID)
 left outer join tpa_claims_payment cp on (cad.claim_seq_id=cp.claim_seq_id)
           left outer join FIN_APP.TPA_PAYMENT_CHECKS_DETAILS n on (n.PAYMENT_SEQ_ID=CP.PAYMENT_SEQ_ID)
          left outer  join FIN_APP.tpa_claims_check f on (n.CLAIMS_CHK_SEQ_ID=f.CLAIMS_CHK_SEQ_ID)
          left outer join tpa_general_code ec on (Cad.CLM_STATUS_TYPE_ID = ec.general_type_id)
           left outer join clm_hospital_details HD on (HD.claim_seq_id=cad.claim_seq_id)
    left outer join tpa_hosp_info thi on (thi.hosp_seq_id=HD.hosp_seq_id)';
        
          
  
      END IF;
    
    v_where := v_where ||' AND b.source_type_id in (''PLCL'',''PCLM'',''E_LM'',''INTL'') ';
    
  IF v_benifit_type IS NOT NULL THEN
      -- like changed to =
      v_where := v_where ||' AND Cad.BENIFIT_TYPE = :v_benifit_type ';
       i := i+1;
       bind_tab(i) := v_benifit_type;
    END IF;
  
  IF V_HOSP_SEQ_ID IS NOT NULL THEN
      -- like changed to =
      v_where := v_where ||' AND thi.hosp_seq_id = :V_HOSP_SEQ_ID ';
       i := i+1;
       bind_tab(i) := V_HOSP_SEQ_ID;
    END IF;
    

       
  IF v_to_date IS NOT NULL THEN 
        v_where := v_where  ||' AND Cad.DATE_OF_HOSPITALIZATION<=:v_to_date';
        i:=i+1;
       bind_tab(i) := v_to_date;
  END IF;
  
 IF v_fdate IS NOT NULL THEN
        v_where := v_where  ||' AND  Cad.DATE_OF_HOSPITALIZATION >=:v_fdate';
        i:=i+1;
       bind_tab(i) := v_fdate;
  END IF;
  
  IF v_to_date1 IS NOT NULL THEN 
        v_where := v_where  ||' AND cad.CLM_RECEIVED_DATE<=:v_to_date1';
        i:=i+1;
       bind_tab(i) := v_to_date1;
  END IF;
  
 IF v_fdate1 IS NOT NULL THEN
        v_where := v_where  ||' AND  cad.CLM_RECEIVED_DATE>=:v_fdate1';
        i:=i+1;
       bind_tab(i) := v_fdate1;
  END IF;
       
 IF v_patientName IS NOT NULL THEN
      -- like changed to =
      v_where := v_where  ||' AND trim(Cad.mem_name) LIKE :v_patientName';
       i := i+1;
       bind_tab(i) := UPPER(v_patientName)||'%';
  END IF;
  
  IF v_qatar_id IS NOT NULL THEN
      -- like changed to =
      v_where := v_where  ||' AND trim(Cad.EMIRATE_ID) LIKE :v_qatar_id';
       i := i+1;
       bind_tab(i) := UPPER(v_qatar_id)||'%';
  END IF;
  
  IF v_pay_ref_no IS NOT NULL THEN
      -- like changed to =
      v_where := v_where  ||' AND trim(F.CHECK_NUM) LIKE :v_pay_ref_no';
       i := i+1;
       bind_tab(i) := UPPER(v_pay_ref_no)||'%';
  END IF;
  
   IF v_invoice_number IS NOT NULL THEN
      -- like changed to =
      v_where := v_where  ||' AND cad.invoice_number =:v_invoice_number';
       i := i+1;
       bind_tab(i) := v_invoice_number;
  END IF;
  IF v_claim_number IS NOT NULL THEN
      -- like changed to =
      v_where := v_where ||' AND cad.claim_number = :v_claim_number ';
       i := i+1;
       bind_tab(i) := v_claim_number;
    END IF;
  
  IF v_batch_no IS NOT NULL THEN
      -- like changed to =
      v_where := v_where ||' AND B.BATCH_NO = :v_batch_no ';
       i := i+1;
       bind_tab(i) := v_batch_no;
    END IF;

 IF v_memberId IS NOT NULL THEN
      -- like changed to =
      v_where := v_where  ||' AND Cad.tpa_enrollment_id = :v_memberId ';
       i := i+1;
       bind_tab(i) := UPPER(v_memberId);
  END IF;
  
    
  IF v_status IS NOT NULL  THEN
      -- like changed to =
     v_where := v_where||' AND cad.CLM_STATUS_TYPE_ID = :v_status ';
    i := i+1;
    bind_tab(i) :=v_status;
  END IF;
  
  IF v_ref_no IS NOT NULL  THEN
      -- like changed to =
     v_where := v_where||' AND Cad.EVENT_NO = :v_ref_no ';
    i := i+1;
    bind_tab(i) :=v_ref_no;
  END IF;
  

    
   -- v_where := v_where||' AND   cad.SOURCE_TYPE_ID =''PLCL''';
    v_where := v_where||' AND   cad.CLAIM_TYPE =''CNH''';
    
    
  IF v_where IS NOT NULL THEN
      v_where   := ' WHERE '||SUBSTR(v_where,5);
      v_sql_str := v_sql_str ||v_where;
  END IF;
  --dbms_output.put_line(v_sql_str);

  
   v_sql_str := 'SELECT * FROM
        (SELECT A.*,DENSE_RANK() OVER (ORDER BY '||v_sort_var||' '||v_sort_order||',ROWNUM)
        Q FROM (' ||v_sql_str|| ') A ) WHERE  Q>= :v_start_num AND Q<= :v_end_num 
        ORDER BY CLAIM_NUMBER';
     -- dbms_output.put_line(v_sql_str);
     
     


    IF bind_tab.FIRST IS NOT NULL THEN
       CASE bind_tab.COUNT
       
        WHEN 1  THEN OPEN result_set FOR v_sql_str USING bind_tab(1), v_start_num , v_end_num ;
        WHEN 2  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2), v_start_num , v_end_num ;
        WHEN 3  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2) ,bind_tab(3) , v_start_num , v_end_num ;
        WHEN 4  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) , v_start_num , v_end_num ;
        WHEN 5  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5), v_start_num , v_end_num ;
        WHEN 6  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6), v_start_num , v_end_num ;
        WHEN 7  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6),bind_tab(7), v_start_num , v_end_num ;
        WHEN 8  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6),bind_tab(7),bind_tab(8), v_start_num , v_end_num ;
         
        END CASE;
     ELSE
       OPEN result_set FOR v_sql_str USING v_start_num , v_end_num ;
       
     END IF;
     

END select_clm_rpt_list;
--==========================================================================
PROCEDURE select_PAT_rpt_list(
  v_pre_auth_number                     IN  pat_authorization_details.pre_auth_number%type ,
  v_fromdate                            IN   VARCHAR2 ,
  v_toDate                              IN   VARCHAR2 ,
  v_patientName                         IN  clm_authorization_details.mem_name%type,
  v_auth_number                         IN  clm_authorization_details.auth_number%type,
  V_DR_NAME               IN VARCHAR2,
  v_memberId                            IN  clm_authorization_details.tpa_enrollment_id%type,
  V_BENIFIT_TYPE              IN VARCHAR2,
  v_status                              IN  tpa_general_code.description%type,
  v_ref_no                              IN  PAT_authorization_details.EVENT_NO%type,
  V_QATAR_ID                            IN VARCHAR2,
  V_PL_REF_NO                              IN VARCHAR2,
  v_sort_var                            IN  VARCHAR2,
  v_sort_order                          IN  VARCHAR2 ,
  v_start_num                           IN  NUMBER ,
  v_end_num                             IN  NUMBER ,
  V_HOSP_SEQ_ID                         IN  pat_authorization_details.hosp_seq_id%type,
  v_rpt_id                              IN  VARCHAR2,
  --v_added_by                            IN  NUMBER,
  result_set                            OUT SYS_REFCURSOR
  )
  IS
  v_sql_str                            VARCHAR2(10000) ;
  TYPE bind_tab_type IS TABLE OF VARCHAR2(250) INDEX BY BINARY_INTEGER ;
    bind_tab                             bind_tab_type;
    i                                    NUMBER(2) := 0;
    v_where                              VARCHAR2(2000);
    --v_stat                               VARCHAR2(20):=null;
  
    v_fdate   PAT_authorization_details.hospitalization_date%type:=to_date(v_fromdate,'dd/mm/yyyy');
    v_to_date PAT_authorization_details.DISCHARGE_DATE%type  :=to_date(v_toDate,'dd/mm/yyyy')+1;
  v_docs_name1                         VARCHAR2(50);
  

 
  BEGIN
    
  -----PSR ---PREAUTH SUMMARY REPORT
  -----CSR----CLAIM SUMMARY REPORT

  IF v_rpt_id = 'PSR' THEN   
    v_sql_str :='select DISTINCT nd.CLINICIAN_NAME,pad.PRE_AUTH_NUMBER,pad.PL_PREAUTH_REFNO,pad.EVENT_NO,
                        TO_CHAR(pad.PAT_RECEIVED_DATE,''DD/MM/YYYY HH24:MI:SS'') AS  PAT_RECEIVED_DATE,
                        pad.MEM_NAME,
                        pad.TPA_ENROLLMENT_ID,
                        pad.EMIRATE_ID,
                        case when pad.benifit_type = ''OPTS'' then ''Out-Patient'' 
                             when pad.benifit_type = ''OPTC'' then ''Optical''
                             when pad.benifit_type = ''IMTI'' then ''In-Patient Maternity''
                             when pad.benifit_type = ''OMTI''  then ''Out-Patient Maternity''
                             when pad.benifit_type = ''IPT'' then ''In-Patient''
                             when pad.benifit_type = ''DNTL'' then ''Dental''
                             when pad.benifit_type = ''HEAC'' then ''Health Check-up''
                             when pad.benifit_type = ''DAYC'' then ''Daycare''
                        end as BENIFIT_TYPE,
                        EC.DESCRIPTION AS PAT_STATUS_TYPE_ID,
                        pad.TOT_GROSS_AMOUNT,
                        pad.TOT_DISCOUNT_AMOUNT,
                        pad.TOT_PATIENT_SHARE_AMOUNT,
                        case when (pad.tot_disc_gross_amount-nvl(pad.tot_patient_share_amount,0))-nvl(pad.tot_approved_amount,0)>0 then
                           (pad.tot_disc_gross_amount-nvl(pad.tot_patient_share_amount,0))-nvl(pad.tot_approved_amount,0) else 0 end  as DIS_ALLOWED_AMOUNT,
                        pad.TOT_APPROVED_AMOUNT,
                        pad.AUTH_NUMBER,
                        case when PAD.PAT_STATUS_TYPE_ID=''REQ'' then ''Required Information'' else ''No'' end as shortfall
                
                from APP.PAT_AUTHORIZATION_DETAILS pad
                --left outer join app.shortfall_details b on (b.PAT_GEN_DETAIL_SEQ_ID=pad.PAT_AUTH_SEQ_ID)
                left outer join pat_non_network_details nd on (nd.pat_auth_seq_id=pad.pat_auth_seq_id)
                left outer join tpa_general_code ec on (pad.PAT_STATUS_TYPE_ID = ec.general_type_id)
                --left outer join tpa_hosp_professionals p on (pad.clinician_id = p.professional_id)
                join tpa_hosp_info thi on (pad.hosp_seq_id=thi.hosp_seq_id)
                left outer join tpa_hosp_professionals p on (pad.clinician_id = p.professional_id AND  pad.UPDATED_BY=p.CONTACT_SEQ_ID)';
    
  ELSE 
    v_sql_str :='with clinician_details as 
                      (select nd.clinician_name, nd.clinician_id, p.pat_auth_seq_id
                       from pat_authorization_details p
                       left outer join pat_non_network_details nd on (nd.pat_auth_seq_id=p.pat_auth_seq_id 
                                                         and P.CLINICIAN_ID=nd.CLINICIAN_ID)
                      ) 
                 select /*DISTINCT nd.CLINICIAN_NAME,*/
                        cd.clinician_id,cd.clinician_name,
                        PAD.PRE_AUTH_NUMBER,PAD.PL_PREAUTH_REFNO,PAD.EVENT_NO,
                        TO_CHAR(pad.PAT_RECEIVED_DATE,''DD/MM/YYYY HH24:MI:SS'') AS  PAT_RECEIVED_DATE,
                        PAD.MEM_NAME,
                        PAD.TPA_ENROLLMENT_ID,
                        PAD.EMIRATE_ID,
                        case when pad.benifit_type = ''OPTS'' then ''Out-Patient'' 
                             when pad.benifit_type = ''OPTC'' then ''Optical''
                             when pad.benifit_type = ''IMTI'' then ''In-Patient Maternity''
                             when pad.benifit_type = ''OMTI''  then ''Out-Patient Maternity''
                             when pad.benifit_type = ''IPT'' then ''In-Patient''
                             when pad.benifit_type = ''DNTL'' then ''Dental''
                             when pad.benifit_type = ''HEAC'' then ''Health Check-up''
                             when pad.benifit_type = ''DAYC'' then ''Daycare''
                         end as BENIFIT_TYPE,
                         EC.DESCRIPTION AS PAT_STATUS_TYPE_ID,
                         c.INTERNAL_CODE,
                         case when length(c.code) > 14 then 
                              regexp_substr(mas.Short_Description,''[^,]+'')
                          else
                         c.internal_desc end as INTERNAL_DESC,
                         c.GROSS_AMOUNT AS TOT_GROSS_AMOUNT,
                         C.DISCOUNT_AMOUNT AS TOT_DISCOUNT_AMOUNT,
                         C.PATIENT_SHARE_AMOUNT AS TOT_PATIENT_SHARE_AMOUNT,
                         case when (nvl(c.disc_gross_amount,0)-nvl(c.patient_share_amount,0))-nvl(c.approved_amount,0)>0 then 
                                 (nvl(c.disc_gross_amount,0)-nvl(patient_share_amount,0))-nvl(c.approved_amount,0)
                         else
                            0
                         end AS DIS_ALLOWED_AMOUNT,
                         C.APPROVED_AMOUNT AS TOT_APPROVED_AMOUNT,
                         case when C.OVERRIDE_YN = ''Y'' AND (C.DISC_GROSS_AMOUNT - C.Patient_Share_Amount) > 0 then 
                           case when (C.DISC_GROSS_AMOUNT - C.Patient_Share_Amount) =  C.ALLOWED_AMOUNT then
                             NULL
                           else
                             C.DENIAL_DESC
                           end
                         else
                           C.DENIAL_DESC
                         end as DENIAL_BY_RESONS,
                         --C.DENIAL_DESC as DENIAL_BY_RESONS,
                         --C.DENIAL_BY_RESONS,
                         PAD.AUTH_NUMBER,
                         case when PAD.PAT_STATUS_TYPE_ID=''REQ'' then ''Required Information'' else ''No'' end as shortfall
                                    
                 from APP.PAT_AUTHORIZATION_DETAILS PAD
                 join  APP.PAT_ACTIVITY_DETAILS C   on (pad.PAT_AUTH_SEQ_ID = C.PAT_AUTH_SEQ_ID )  
                 left join APP.Tpa_Activity_Master_Details mas  on (mas.Activity_Code = c.code)
                 left join clinician_details cd    on (cd.pat_auth_seq_id = pad.pat_auth_seq_id)
                 left outer join tpa_general_code ec    on (pad.PAT_STATUS_TYPE_ID = ec.general_type_id)
                 join tpa_hosp_info thi    on (pad.hosp_seq_id = thi.hosp_seq_id)';
  END IF;
    
   v_where := v_where ||' AND pad.PBM_YN = ''N'' AND PAD.PAT_ENHANCED_YN = ''N'' ';
   
  IF v_auth_number IS NOT NULL THEN
      -- like changed to =
      v_where := v_where ||' AND pad.auth_number = :v_auth_number ';
       i := i+1;
       bind_tab(i) := v_auth_number;
    END IF;
  
  IF V_HOSP_SEQ_ID IS NOT NULL THEN
      -- like changed to =
      v_where := v_where ||' AND thi.hosp_seq_id = :V_HOSP_SEQ_ID ';
       i := i+1;
       bind_tab(i) := V_HOSP_SEQ_ID;
    END IF;
    

       
  IF v_to_date IS NOT NULL THEN 
        v_where := v_where  ||' AND pad.pat_received_date<=:v_to_date';
        i:=i+1;
       bind_tab(i) := v_to_date;
  END IF;
  
 IF v_fdate IS NOT NULL THEN
        v_where := v_where  ||' AND  pad.pat_received_date >=:v_fdate';
        i:=i+1;
       bind_tab(i) := v_fdate;
  END IF;
  
 
       
 IF v_patientName IS NOT NULL THEN
      -- like changed to =
      v_where := v_where  ||' AND trim(Pad.mem_name) LIKE :v_patientName';
       i := i+1;
       bind_tab(i) := UPPER(v_patientName)||'%';
  END IF;
  
    IF V_DR_NAME IS NOT NULL THEN
       v_where := v_where  ||' AND (UPPER(P.contact_name) LIKE upper(:V_DR_NAME) OR UPPER(nd.clinician_name) LIKE upper(:v_docs_name1))';
       i := i+1;
       bind_tab(i) := UPPER(V_DR_NAME)||'%';
       v_docs_name1 := V_DR_NAME;
       i := i+1;
       bind_tab(i) := UPPER(v_docs_name1)||'%';
    END IF;
 
 
  
  IF v_pre_auth_number IS NOT NULL THEN
      -- like changed to =
      v_where := v_where ||' AND pad.pre_auth_number = :v_pre_auth_number ';
       i := i+1;
       bind_tab(i) := v_pre_auth_number;
    END IF;

 IF v_memberId IS NOT NULL THEN
      -- like changed to =
      v_where := v_where  ||' AND Pad.tpa_enrollment_id = :v_memberId ';
       i := i+1;
       bind_tab(i) := UPPER(v_memberId);
  END IF;
  IF V_QATAR_ID IS NOT NULL THEN
      -- like changed to =
      v_where := v_where  ||' AND Pad.EMIRATE_ID = :V_QATAR_ID ';
       i := i+1;
       bind_tab(i) := UPPER(V_QATAR_ID);
  END IF;
  
  IF V_BENIFIT_TYPE IS NOT NULL THEN
      -- like changed to =
      v_where := v_where  ||' AND Pad.BENIFIT_TYPE = :V_BENIFIT_TYPE ';
       i := i+1;
       bind_tab(i) := UPPER(V_BENIFIT_TYPE);
  END IF;
  
    
  IF v_status IS NOT NULL  THEN
      -- like changed to =
     v_where := v_where||' AND pad.pat_STATUS_TYPE_ID = :v_status ';
    i := i+1;
    bind_tab(i) :=v_status;
  END IF;
  
  IF v_ref_no IS NOT NULL  THEN
      -- like changed to =
     v_where := v_where||' AND Pad.EVENT_NO = :v_ref_no ';
    i := i+1;
    bind_tab(i) :=v_ref_no;
  END IF;
  
  IF V_PL_REF_NO IS NOT NULL  THEN
      -- like changed to =
     v_where := v_where||' AND Pad.PL_PREAUTH_REFNO = :V_PL_REF_NO ';
    i := i+1;
    bind_tab(i) :=V_PL_REF_NO;
  END IF;
  

    
    --v_where := v_where||' AND  PAD.SOURCE_TYPE_ID =''PLPR''';
    
    
  IF v_where IS NOT NULL THEN
      v_where   := ' WHERE '||SUBSTR(v_where,5);
      v_sql_str := v_sql_str ||v_where;
  END IF;
  --dbms_output.put_line(v_sql_str);

  
    v_sql_str := 'SELECT * FROM
        (SELECT A.*,DENSE_RANK() OVER (ORDER BY '||v_sort_var||' '||v_sort_order||',ROWNUM)
        Q FROM (' ||v_sql_str|| ') A ) WHERE  Q>= :v_start_num AND Q<= :v_end_num 
        ORDER BY pre_auth_number';
     -- dbms_output.put_line(v_sql_str);
     
     


    IF bind_tab.FIRST IS NOT NULL THEN
       CASE bind_tab.COUNT
       
        WHEN 1  THEN OPEN result_set FOR v_sql_str USING bind_tab(1), v_start_num , v_end_num ;
        WHEN 2  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2), v_start_num , v_end_num ;
        WHEN 3  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2) ,bind_tab(3) , v_start_num , v_end_num ;
        WHEN 4  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) , v_start_num , v_end_num ;
        WHEN 5  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5), v_start_num , v_end_num ;
        WHEN 6  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6), v_start_num , v_end_num ;
        WHEN 7  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6),bind_tab(7), v_start_num , v_end_num ;
        WHEN 8  THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5),bind_tab(6),bind_tab(7),bind_tab(8), v_start_num , v_end_num ;
         
        END CASE;
     ELSE
       OPEN result_set FOR v_sql_str USING v_start_num , v_end_num ;
       
     END IF;
     

END select_PAT_rpt_list;
--=========================================================================
PROCEDURE PRVDR_PAT_RPT (
    v_input_list IN  VARCHAR2,
    v_result_set  OUT SYS_REFCURSOR
  )
  IS
    str_tab    ttk_util_pkg.str_table_type;
  BEGIN
    str_tab := ttk_util_pkg.parse_str ( v_input_list );
--     IF str_tab(8) IS NULL THEN
--        str_tab(8) := to_char(SYSDATE,'dd/mm/yyyy');
--     END IF;
  /*  IF str_tab(5) IS NULL THEN
      str_tab(5) := to_char(SYSDATE,'dd/mm/yyyy');
    END IF;*/

    IF str_tab(1) = 'PDR' THEN
	 
      OPEN v_result_set FOR
        with clinician_details as 
             (select nd.clinician_name, nd.clinician_id, p.pat_auth_seq_id
              from pat_authorization_details p
              left outer join pat_non_network_details nd on (nd.pat_auth_seq_id=p.pat_auth_seq_id 
                                                             and P.CLINICIAN_ID=nd.CLINICIAN_ID)
             )
            
        select  /*DISTINCT nd.CLINICIAN_NAME,*/
                /*+ use_nl(pad c nd mas) */
                cd.clinician_id,cd.clinician_name,
                PAD.PRE_AUTH_NUMBER,PAD.PL_PREAUTH_REFNO,PAD.EVENT_NO,
                TO_CHAR(pad.PAT_RECEIVED_DATE,'DD/MM/YYYY HH24:MI:SS') AS  PAT_RECEIVED_DATE,
                PAD.MEM_NAME,
                C.PAT_AUTH_SEQ_ID,
                PAD.TPA_ENROLLMENT_ID,
                PAD.EMIRATE_ID,
                case when pad.benifit_type = 'OPTS' then 'Out-Patient' 
                            when pad.benifit_type = 'OPTC' then 'Optical'
                            when pad.benifit_type = 'IMTI' then 'In-Patient Maternity'
                            when pad.benifit_type = 'OMTI'  then 'Out-Patient Maternity'
                            when pad.benifit_type = 'IPT' then 'In-Patient'
                            when pad.benifit_type = 'DNTL' then 'Dental'
                            when pad.benifit_type = 'HEAC' then 'Health Check-up'
                            when pad.benifit_type = 'DAYC' then 'Daycare' end as BENIFIT_TYPE,
               EC.DESCRIPTION AS PAT_STATUS_TYPE_ID,
               c.INTERNAL_CODE,
               case when length(c.code) > 14 then 
                              regexp_substr(mas.Short_Description,'[^,]+')
                          else
                         c.internal_desc end as INTERNAL_DESC,
               c.GROSS_AMOUNT AS TOT_GROSS_AMOUNT,
               C.DISCOUNT_AMOUNT AS TOT_DISCOUNT_AMOUNT,
               C.PATIENT_SHARE_AMOUNT AS TOT_PATIENT_SHARE_AMOUNT,
               case when (nvl(c.disc_gross_amount,0)-nvl(c.patient_share_amount,0))-nvl(c.approved_amount,0)>0 then 
                (nvl(c.disc_gross_amount,0)-nvl(patient_share_amount,0))-nvl(c.approved_amount,0)
               else 
                0
               end AS DIS_ALLOWED_AMOUNT,
               C.APPROVED_AMOUNT AS TOT_APPROVED_AMOUNT,
               CASE WHEN C.OVERRIDE_YN = 'Y' AND (C.DISC_GROSS_AMOUNT - C.PATIENT_SHARE_AMOUNT) > 0 THEN
                  CASE WHEN (C.DISC_GROSS_AMOUNT - C.PATIENT_SHARE_AMOUNT) = C.ALLOWED_AMOUNT THEN
                     NULL
                  ELSE 
                     C.DENIAL_DESC
                  END
                ELSE
                  C.DENIAL_DESC
                END AS DENIAL_BY_RESONS,
               --C.DENIAL_BY_RESONS,
               PAD.AUTH_NUMBER,
               case when PAD.PAT_STATUS_TYPE_ID='REQ'  then 
                'Required Information'
               else 
                'No' 
               end as shortfall

        from APP.PAT_AUTHORIZATION_DETAILS PAD
        left join APP.PAT_ACTIVITY_DETAILS C on (C.PAT_AUTH_SEQ_ID=pad.PAT_AUTH_SEQ_ID)
        left join tpa_activity_master_details mas on (c.code=mas.activity_code)
        --left outer join APP.TPA_HOSP_TARIFF_DETAILS c on (pad.ACTIVITY_SEQ_ID=c.ACTIVITY_SEQ_ID and b.HOSP_SEQ_ID=c.HOSP_SEQ_ID)
        --left outer join shortfall_details d on (PAD.PAT_AUTH_SEQ_ID=d.PAT_GEN_DETAIL_SEQ_ID)
        left join clinician_details cd on (cd.pat_auth_seq_id = pad.pat_auth_seq_id)
        --left outer join pat_non_network_details nd on (nd.pat_auth_seq_id=pad.pat_auth_seq_id AND PAD.CLINICIAN_ID=nd.CLINICIAN_ID)
        left outer join tpa_general_code ec on (pad.PAT_STATUS_TYPE_ID = ec.general_type_id)
        --left outer join tpa_hosp_professionals p on (pad.clinician_id = p.professional_id )
        join tpa_hosp_info thi on (pad.hosp_seq_id=thi.hosp_seq_id)
        
 
        WHERE thi.HOSP_SEQ_ID=str_tab(2)
        AND (str_tab(3) IS NULL  OR  PAD.PRE_AUTH_NUMBER=str_tab(3))
        AND (str_tab(4) is null  OR  PAD.pat_received_date >= to_date(str_tab(4),'dd/mm/yyyy') and PAD.pat_received_date <= to_date(str_tab(5),'dd/mm/yyyy')+1)
        AND (str_tab(6) IS NULL  OR  PAD.MEM_NAME=str_tab(6))
        AND (str_tab(7) IS NULL OR  PAD.AUTH_NUMBER=str_tab(7))
        AND (str_tab(8) IS NULL  OR (UPPER(cd.clinician_name) LIKE upper(str_tab(8)||'%') OR UPPER(cd.clinician_name) LIKE upper(str_tab(8)||'%')))
        AND (str_tab(9) IS NULL  OR  PAD.TPA_ENROLLMENT_ID=str_tab(9))
        AND (str_tab(10) IS NULL OR  PAD.BENIFIT_TYPE=str_tab(10))
        AND (str_tab(11) IS NULL OR  PAD.PAT_STATUS_TYPE_ID=str_tab(11))
        AND (str_tab(12) IS NULL OR  PAD.EVENT_NO=str_tab(12))
        AND (str_tab(13) IS NULL OR  PAD.EMIRATE_ID=str_tab(13))
        AND (str_tab(14) IS NULL OR  PAD.PL_PREAUTH_REFNO=str_tab(14))
        AND PAD.PBM_YN = 'N' AND  PAD.PAT_ENHANCED_YN = 'N' 
        order by C.PAT_AUTH_SEQ_ID;
   --AND PAD.SOURCE_TYPE_ID ='PLPR';
   
   ELSIF str_tab(1) = 'PSR' THEN
     OPEN v_result_set FOR
       select DISTINCT nd.CLINICIAN_NAME,pad.PRE_AUTH_NUMBER,pad.PL_PREAUTH_REFNO,pad.EVENT_NO,
              TO_CHAR(pad.PAT_RECEIVED_DATE,'DD/MM/YYYY HH24:MI:SS') AS  PAT_RECEIVED_DATE,
              pad.MEM_NAME,
              pad.TPA_ENROLLMENT_ID,
              pad.EMIRATE_ID,
              pad.PAT_AUTH_SEQ_ID,
              case when pad.benifit_type = 'OPTS' then 'Out-Patient' 
                          when pad.benifit_type = 'OPTC' then 'Optical'
                          when pad.benifit_type = 'IMTI' then 'In-Patient Maternity'
                          when pad.benifit_type = 'OMTI'  then 'Out-Patient Maternity'
                          when pad.benifit_type = 'IPT' then 'In-Patient'
                          when pad.benifit_type = 'DNTL' then 'Dental'
                          when pad.benifit_type = 'HEAC' then 'Health Check-up'
                          when pad.benifit_type = 'DAYC' then 'Daycare' end as BENIFIT_TYPE,
              EC.DESCRIPTION AS PAT_STATUS_TYPE_ID,
              pad.TOT_GROSS_AMOUNT,
              pad.TOT_DISCOUNT_AMOUNT,
              pad.TOT_PATIENT_SHARE_AMOUNT,
              case when (pad.tot_disc_gross_amount-nvl(pad.tot_patient_share_amount,0))-nvl(pad.tot_approved_amount,0)>0 then
                           (pad.tot_disc_gross_amount-nvl(pad.tot_patient_share_amount,0))-nvl(pad.tot_approved_amount,0) else 0 end  as DIS_ALLOWED_AMOUNT,
              pad.TOT_APPROVED_AMOUNT,
              pad.AUTH_NUMBER,
              case when PAD.PAT_STATUS_TYPE_ID='REQ'  then 
                'Required Information'
              else 
                'No'
              end as shortfall
       from APP.PAT_AUTHORIZATION_DETAILS pad
       --left outer join app.shortfall_details b on (b.PAT_GEN_DETAIL_SEQ_ID=pad.PAT_AUTH_SEQ_ID)
       left outer join pat_non_network_details nd on (nd.pat_auth_seq_id=pad.pat_auth_seq_id)
       left outer join tpa_general_code ec on (pad.PAT_STATUS_TYPE_ID = ec.general_type_id)
       --left outer join tpa_hosp_professionals p on (pad.clinician_id = p.professional_id)
       join tpa_hosp_info thi on (pad.hosp_seq_id=thi.hosp_seq_id)
       left outer join tpa_hosp_professionals p on (pad.clinician_id = p.professional_id AND  pad.UPDATED_BY=p.CONTACT_SEQ_ID)
       WHERE thi.HOSP_SEQ_ID=str_tab(2)
       AND (str_tab(3) IS NULL OR  PAD.PRE_AUTH_NUMBER=str_tab(3))
       AND
            (str_tab(4) is null or  PAD.pat_received_date >= to_date(str_tab(4),'dd/mm/yyyy') and PAD.pat_received_date <= to_date(str_tab(5),'dd/mm/yyyy')+1)
       AND (str_tab(6) IS NULL OR  PAD.MEM_NAME=str_tab(6))
       AND (str_tab(7) IS NULL OR  PAD.AUTH_NUMBER=str_tab(7))
       AND (str_tab(8) IS NULL OR (UPPER(P.contact_name) LIKE upper(str_tab(8)||'%') OR UPPER(nd.clinician_name) LIKE upper(str_tab(8)||'%')))
       AND (str_tab(9) IS NULL OR  PAD.TPA_ENROLLMENT_ID=str_tab(9))
       AND (str_tab(10) IS NULL OR  PAD.BENIFIT_TYPE=str_tab(10))
       AND (str_tab(11) IS NULL OR  PAD.PAT_STATUS_TYPE_ID=str_tab(11))
       AND (str_tab(12) IS NULL OR  PAD.EVENT_NO=str_tab(12))
       AND (str_tab(13) IS NULL OR  PAD.EMIRATE_ID=str_tab(13))
       AND (str_tab(14) IS NULL OR  PAD.PL_PREAUTH_REFNO=str_tab(14))
       AND PAD.PBM_YN = 'N' AND  PAD.PAT_ENHANCED_YN = 'N' 
       -- AND PAD.SOURCE_TYPE_ID ='PLPR'
       order by pad.PAT_AUTH_SEQ_ID;
   END IF;
   
 
   
   END PRVDR_PAT_RPT;
--=========================================================================
PROCEDURE PRVDR_CLM_RPT(v_input_list IN  VARCHAR2,
                          v_result_set  OUT SYS_REFCURSOR
                        )IS
                         
    str_tab    ttk_util_pkg.str_table_type;
  BEGIN
     str_tab := ttk_util_pkg.parse_str ( v_input_list );
     IF str_tab(6) IS NULL THEN
        str_tab(6) := to_char(SYSDATE,'dd/mm/yyyy');
     END IF;
     IF str_tab(4) IS NULL THEN
        str_tab(4) := to_char(SYSDATE,'dd/mm/yyyy');
     END IF;
     IF str_tab(1) = 'CDR' THEN
       OPEN v_result_set FOR
    	 
         WITH ICD_CODE_VW AS (SELECT CLAIM_SEQ_ID, TO_CHAR(LISTAGG(DIAGNOSYS_CODE, ',') WITHIN GROUP(ORDER BY DIAG_SEQ_ID)) AS DIAGNOSYS_CODE
                              FROM (SELECT CL.CLAIM_SEQ_ID, ICD.DIAGNOSYS_CODE, ICD.DIAG_SEQ_ID
                                    FROM DIAGNOSYS_DETAILS ICD
                                    JOIN CLM_AUTHORIZATION_DETAILS CL ON CL.CLAIM_SEQ_ID = ICD.CLAIM_SEQ_ID
                                    JOIN CLM_HOSPITAL_DETAILS HS ON HS.CLAIM_SEQ_ID = CL.CLAIM_SEQ_ID
                                    WHERE ICD.PRIMARY_AILMENT_YN != 'Y'
                                    AND (str_tab(2) IS NULL OR HS.HOSP_SEQ_ID = str_tab(2))
                                    ORDER BY ICD.DIAG_SEQ_ID
                                   )
                                   GROUP BY CLAIM_SEQ_ID
                              ) -- Added Query for CR-0293
                          
         SELECT TO_CHAR(CAD.CLM_RECEIVED_DATE,'DD/MM/YYYY') AS CLM_RECEIVED_DATE,
                TO_CHAR(CAD.DATE_OF_HOSPITALIZATION,'DD/MM/YYYY') AS DATE_OF_HOSPITALIZATION,
                b.BATCH_NO,
                CAD.INVOICE_NUMBER,
                CAD.EVENT_NO,
                CAD.TPA_ENROLLMENT_ID AS MEMBER_ID,
                CAD.EMIRATE_ID,
                CAD.MEM_NAME,
                CAD.CLAIM_NUMBER,
                case when Cad.benifit_type = 'OPTS' then 'Out-Patient' 
                            when Cad.benifit_type = 'OPTC' then 'Optical'
                            when Cad.benifit_type = 'IMTI' then 'In-Patient Maternity'
                            when Cad.benifit_type = 'OMTI'  then 'Out-Patient Maternity'
                            when Cad.benifit_type = 'IPT' then 'In-Patient'
                            when Cad.benifit_type = 'DNTL' then 'Dental'
                            when Cad.benifit_type = 'HEAC' then 'Health Check-up'
                            when Cad.benifit_type = 'DAYC' then 'Daycare' end as BENIFIT_TYPE ,
                EC.DESCRIPTION AS CLM_STATUS_TYPE_ID,
                C.INTERNAL_CODE,
                /*case when length(c.code) > 14 then 
                                              regexp_substr(mas.Short_Description,'[^,]+')
                                          else
                                         c.internal_desc end as INTERNAL_DESC,*/
                C.PROVIDER_NET_AMOUNT as PAT_APPROVED_AMOUNT,
                C.GROSS_AMOUNT AS TOT_GROSS_AMOUNT,
                C.DISCOUNT_AMOUNT AS TOT_DISCOUNT_AMOUNT,
                C.PATIENT_SHARE_AMOUNT AS TOT_PATIENT_SHARE_AMOUNT,
                case when (nvl(cad.ucr_flag,'N')='N' and nvl(cad.ri_copar_flag,'N')='N') then (nvl(c.disc_gross_amount,0)-nvl(c.patient_share_amount,0))-nvl(c.approved_amount,0) 
                              else nvl(c.disallowed_amount,0) end AS DIS_ALLOWED_AMOUNT,
                C.APPROVED_AMOUNT AS TOT_APPROVED_AMOUNT,
                CASE WHEN C.OVERRIDE_YN = 'Y' AND (C.DISC_GROSS_AMOUNT - C.PATIENT_SHARE_AMOUNT) > 0 THEN
                   CASE WHEN (C.DISC_GROSS_AMOUNT - C.PATIENT_SHARE_AMOUNT) = C.ALLOWED_AMOUNT THEN
                      NULL
                   ELSE 
                      C.DENIAL_DESC
                   END
                ELSE
                   C.DENIAL_DESC
                END AS DENIAL_DESC,
                C.DENIAL_DESC AS INTERNAL_SERVICE_CODE,
                f.CHECK_NUM AS PAYMENT_REFRENCE_NUMBER,
                TO_CHAR(f.CHECK_DATE,'DD/MM/YYYY') AS CHECK_DATE,
                C.CLAIM_SEQ_ID,
                DECODE(CP.CLAIM_PAYMENT_STATUS, 'READY_TO_BANK', 'READY TO BANK', 'SENT_TO_BANK', 'SENT TO BANK', 'PENDING', 'PENDING', 'PAID', 'PAID') AS CLAIM_PAYMENT_STATUS,
                ---- Added Column for CR-0293
                ROWNUM AS SLNO,
                PA.PRE_AUTH_NUMBER AS PREAPPROVAL_NO,
                TO_CHAR(CAD.DATE_OF_DISCHARGE, 'DD/MM/RRRR') AS DATE_OF_DISCHARGE,
                G.DESCRIPTION AS SYSTEM_OF_MEDICINE,
                E.DESCRIPTION AS ENCOUNTER_TYPE,
                CAD.CLINICIAN_ID,
                PR.CONTACT_NAME AS CLINICIAN_NAME,
                CAD.PRESENTING_COMPLAINTS AS SYMPTOMS,
                D.DIAGNOSYS_CODE AS PRINCIPAL_ICD_CODE,
                NVL(I.ICD_DESCRIPTION,IMD.SHORT_DESC) AS ICD_DESCRIPTION,
                NVL(REGEXP_SUBSTR (IC.DIAGNOSYS_CODE, '[^,]+', 1, 1), '') AS SECONDARY_ICD_CODE_1,
                NVL(REGEXP_SUBSTR (IC.DIAGNOSYS_CODE, '[^,]+', 1, 2), '') AS SECONDARY_ICD_CODE_2,
                NVL(REGEXP_SUBSTR (IC.DIAGNOSYS_CODE, '[^,]+', 1, 3), '') AS SECONDARY_ICD_CODE_3,
                NVL(REGEXP_SUBSTR (IC.DIAGNOSYS_CODE, '[^,]+', 1, 4), '') AS SECONDARY_ICD_CODE_4,
                NVL(REGEXP_SUBSTR (IC.DIAGNOSYS_CODE, '[^,]+', 1, 5), '') AS SECONDARY_ICD_CODE_5,
                TO_CHAR(CAD.FIRST_INCIDENT_DATE, 'DD/MM/RRRR') AS FIRST_INCIDENT_DATE,
                TO_CHAR(CAD.FIRST_REPORTED_DATE, 'DD/MM/RRRR') AS FIRST_REPORTED_DATE,
                TO_CHAR(C.START_DATE, 'DD/MM/RRRR') AS SERVICE_DATE,
                CASE WHEN C.ACTIVITY_TYPE_ID = 'ACT' THEN 'Activity'
                     WHEN C.ACTIVITY_TYPE_ID = 'DRG' THEN 'Drug'
                END AS ACTIVITY_TYPE,
                C.INTERNAL_DESC AS SERVICE_DESCRIPTION,
                C.CODE AS CPT_CODE,
                C.TOOTH_NO AS TOOTH_NUMBER,
                TO_CHAR(CAD.LMP_DATE, 'DD/MM/RRRR') AS DATE_OF_LMP,
                CASE WHEN CAD.CONCEPTION_TYPE = 'NAT' THEN 'Natural'
                     WHEN CAD.CONCEPTION_TYPE = 'AST' THEN 'Assisted'
                END AS NATURE_OF_CONCEPTION,
                --OBS.REMARKS AS OBSERVATION, --commented as cnf. by Venu 
                C.QUANTITY,
                CAD.FINAL_REMARKS AS FINAL_REMARKS
      
          from CLM_AUTHORIZATION_DETAILS cad  
          join clm_batch_upload_details b on (b.clm_batch_seq_id=cad.clm_batch_seq_id and b.batch_status_type='COMP')
          left outer join clm_hospital_details HD on (HD.claim_seq_id=cad.claim_seq_id)
          LEFT JOIN pat_authorization_details pa ON pa.claim_seq_id = cad.claim_seq_id -- CR-0293
          LEFT JOIN TPA_GENERAL_CODE G ON G.GENERAL_TYPE_ID = CAD.SYSTEM_OF_MEDICINE_TYPE_ID
          LEFT JOIN TPA_HOSP_PROFESSIONALS PR ON (PR.PROFESSIONAL_ID = CAD.CLINICIAN_ID AND pr.hosp_seq_id=hd.hosp_seq_id)
          LEFT JOIN TPA_ENCOUNTER_TYPE_CODES E ON E.ENCOUNTER_SEQ_ID = CAD.ENCOUNTER_TYPE_ID AND E.HEADER_TYPE = 'ENCOUNTER_TYPE'
          LEFT JOIN DIAGNOSYS_DETAILS D ON D.CLAIM_SEQ_ID = CAD.CLAIM_SEQ_ID AND D.PRIMARY_AILMENT_YN = 'Y'
          LEFT JOIN TPA_ICD_CODES I ON I.ICD_CODE = D.DIAGNOSYS_CODE
          LEFT JOIN TPA_ICD10_MASTER_DETAILS IMD ON IMD.ICD_CODE = D.DIAGNOSYS_CODE
          LEFT JOIN ICD_CODE_VW IC ON IC.CLAIM_SEQ_ID = D.CLAIM_SEQ_ID
          left outer join PAT_ACTIVITY_DETAILS C on (c.CLAIM_SEQ_ID=Cad.CLAIM_SEQ_ID)
          --LEFT JOIN PAT_OBSERVATION_DETAILS OBS ON OBS.ACTIVITY_DTL_SEQ_ID = C.ACTIVITY_DTL_SEQ_ID --commented as cnf. by Venu
          left outer join tpa_claims_payment cp on (cad.claim_seq_id=cp.claim_seq_id)
          left outer join tpa_payment_checks_details pcd on (cp.payment_seq_id=pcd.payment_seq_id)
          left outer join tpa_claims_check f on (pcd.claims_chk_seq_id=f.claims_chk_seq_id)
          left outer join tpa_enr_policy e on (e.policy_seq_id=cad.policy_seq_id)
          left outer join tpa_general_code ec on (Cad.CLM_STATUS_TYPE_ID = ec.general_type_id)
          left outer join tpa_hosp_info thi on (thi.hosp_seq_id=HD.hosp_seq_id)
         WHERE (str_tab(2) IS NULL OR THI.HOSP_SEQ_ID=str_tab(2))
           AND (str_tab(3) is null or  CAD.DATE_OF_HOSPITALIZATION >= to_date(str_tab(3),'dd/mm/yyyy') and CAD.DATE_OF_HOSPITALIZATION <= to_date(str_tab(4),'dd/mm/yyyy')+1)
           AND (str_tab(5) is null or CAD.CLM_RECEIVED_DATE >= to_date(str_tab(5),'dd/mm/yyyy') and CAD.CLM_RECEIVED_DATE <= to_date(str_tab(6),'dd/mm/yyyy')+1)
           AND (str_tab(7) IS NULL OR  CAD.MEM_NAME=str_tab(7))
           AND ( str_tab(8) IS NULL OR CAD.CLM_STATUS_TYPE_ID=str_tab(8))
           AND ( str_tab(9) IS NULL OR CAD.INVOICE_NUMBER=str_tab(9))
           AND ( str_tab(10) IS NULL OR b.BATCH_NO=str_tab(10))
           AND (str_tab(11) IS NULL OR  CAD.TPA_ENROLLMENT_ID=str_tab(11))
           AND ( str_tab(12) IS NULL OR CAD.CLAIM_NUMBER=str_tab(12))
           AND (str_tab(13) IS NULL OR  CAD.BENIFIT_TYPE=str_tab(13))
           AND (str_tab(14) IS NULL OR  CAD.EVENT_NO=str_tab(14))
           AND (str_tab(15) IS NULL OR  CAD.EMIRATE_ID=str_tab(15))
           AND (str_tab(16) IS NULL OR  F.CHECK_NUM=str_tab(16))
           AND   cad.CLAIM_TYPE ='CNH'
           AND b.SOURCE_TYPE_ID in ('PLCL','PCLM','E_LM','INTL')
           order by C.CLAIM_SEQ_ID
              --AND CAD.SOURCE_TYPE_ID ='PLCL'
            ;
       
	 ELSE
     OPEN v_result_set FOR
       SELECT TO_CHAR(CAD.CLM_RECEIVED_DATE,'DD/MM/YYYY') AS CLM_RECEIVED_DATE,
              TO_CHAR(CAD.DATE_OF_HOSPITALIZATION,'DD/MM/YYYY') AS DATE_OF_HOSPITALIZATION,
              b.BATCH_NO,
              cad.INVOICE_NUMBER,
              cad.EVENT_NO,
              CAD.TPA_ENROLLMENT_ID,
              cad.EMIRATE_ID,
              cad.MEM_NAME,
              cad.CLAIM_NUMBER,
              case when Cad.benifit_type = 'OPTS' then 'Out-Patient' 
                          when Cad.benifit_type = 'OPTC' then 'Optical'
                          when Cad.benifit_type = 'IMTI' then 'In-Patient Maternity'
                          when Cad.benifit_type = 'OMTI'  then 'Out-Patient Maternity'
                          when Cad.benifit_type = 'IPT' then 'In-Patient'
                          when Cad.benifit_type = 'DNTL' then 'Dental'
                          when Cad.benifit_type = 'HEAC' then 'Health Check-up'
                          when Cad.benifit_type = 'DAYC' then 'Daycare' end as BENIFIT_TYPE ,

              EC.DESCRIPTION AS CLM_STATUS_TYPE_ID,
              cad.REQUESTED_AMOUNT AS PAT_APPROVED_AMOUNT,
              cad.TOT_GROSS_AMOUNT,
              cad.TOT_DISCOUNT_AMOUNT,
              cad.TOT_PATIENT_SHARE_AMOUNT,
              case when (nvl(cad.ucr_flag,'N')='N' and nvl(cad.ri_copar_flag,'N')='N') then
                 case when nvl(cad.completed_yn,'N')='Y'then 
                      CASE WHEN SIGN ((cad.tot_disc_gross_amount-nvl(cad.tot_patient_share_amount,0))-nvl(cad.final_app_amount,0)) = -1 THEN 0
                      ELSE (cad.tot_disc_gross_amount-nvl(cad.tot_patient_share_amount,0))-nvl(cad.final_app_amount,0) END
                 else CASE WHEN SIGN((cad.tot_disc_gross_amount-nvl(cad.tot_patient_share_amount,0))-nvl(cad.tot_approved_amount,0)) = -1 THEN 0
                      ELSE (cad.tot_disc_gross_amount-nvl(cad.tot_patient_share_amount,0))-nvl(cad.tot_approved_amount,0) END
              end end AS DIS_ALLOWED_AMOUNT,
              cad.TOT_APPROVED_AMOUNT,
              F.CHECK_NUM AS PAYMENT_REFRENCE_NUMBER,
              TO_CHAR(f.CHECK_DATE,'DD/MM/YYYY') AS CHECK_DATE,
              Cad.CLAIM_SEQ_ID

        FROM  clm_authorization_details cad 
        join clm_batch_upload_details b on (b.clm_batch_seq_id=cad.clm_batch_seq_id and b.batch_status_type='COMP')
         --join APP.CLM_BATCH_UPLOAD_DETAILS b on (b.CLM_BATCH_SEQ_ID=cad.CLM_BATCH_SEQ_ID)
        left outer join tpa_claims_payment cp on (cad.claim_seq_id=cp.claim_seq_id)
        left outer join FIN_APP.TPA_PAYMENT_CHECKS_DETAILS n on (n.PAYMENT_SEQ_ID=CP.PAYMENT_SEQ_ID)
        left outer  join FIN_APP.tpa_claims_check f on (n.CLAIMS_CHK_SEQ_ID=f.CLAIMS_CHK_SEQ_ID)
        left outer join tpa_general_code ec on (Cad.CLM_STATUS_TYPE_ID = ec.general_type_id)
        left outer join clm_hospital_details HD on (HD.claim_seq_id=cad.claim_seq_id)
        left outer join tpa_hosp_info thi on (thi.hosp_seq_id=HD.hosp_seq_id)
       WHERE (str_tab(2) IS NULL OR THI.HOSP_SEQ_ID=str_tab(2))
         AND (str_tab(3) is null or  CAD.DATE_OF_HOSPITALIZATION >= to_date(str_tab(3),'dd/mm/yyyy') and CAD.DATE_OF_HOSPITALIZATION <= to_date(str_tab(4),'dd/mm/yyyy')+1)
         AND (str_tab(5) is null or CAD.CLM_RECEIVED_DATE >= to_date(str_tab(5),'dd/mm/yyyy') and CAD.CLM_RECEIVED_DATE <= to_date(str_tab(6),'dd/mm/yyyy')+1)
         AND (str_tab(7) IS NULL OR  CAD.MEM_NAME=str_tab(7))
         AND (str_tab(8) IS NULL OR CAD.CLM_STATUS_TYPE_ID=str_tab(8))
         AND (str_tab(9) IS NULL OR CAD.INVOICE_NUMBER=str_tab(9))
         AND (str_tab(10) IS NULL OR b.BATCH_NO=str_tab(10))
         AND (str_tab(11) IS NULL OR  CAD.TPA_ENROLLMENT_ID=str_tab(11))
         AND (str_tab(12) IS NULL OR CAD.CLAIM_NUMBER=str_tab(12))
         AND (str_tab(13) IS NULL OR  CAD.BENIFIT_TYPE=str_tab(13))
         AND (str_tab(14) IS NULL OR  CAD.EVENT_NO=str_tab(14))
         AND (str_tab(15) IS NULL OR  CAD.EMIRATE_ID=str_tab(15))
         AND (str_tab(16) IS NULL OR  F.CHECK_NUM=str_tab(16))
         AND cad.CLAIM_TYPE ='CNH'
         AND b.SOURCE_TYPE_ID in ('PLCL','PCLM','E_LM','INTL')
       order by Cad.CLAIM_SEQ_ID
           --AND CAD.SOURCE_TYPE_ID ='PLCL'
           ;
   
   END IF;
   
 END PRVDR_CLM_RPT;
   
   --===========================================================================
END hospital_pkg;

/

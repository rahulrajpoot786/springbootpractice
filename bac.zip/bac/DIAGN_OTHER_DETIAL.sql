--------------------------------------------------------
--  DDL for Synonymn DIAGN_OTHER_DETIAL
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."DIAGN_OTHER_DETIAL" FOR "APP"."DIAGN_OTHER_DETIAL";

--------------------------------------------------------
--  DDL for Synonymn DHA_HCPCS_CODE_MASTER
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."DHA_HCPCS_CODE_MASTER" FOR "APP"."DHA_HCPCS_CODE_MASTER";

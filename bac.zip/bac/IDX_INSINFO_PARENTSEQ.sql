--------------------------------------------------------
--  DDL for Synonymn IDX_INSINFO_PARENTSEQ
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."IDX_INSINFO_PARENTSEQ" FOR "APP"."IDX_INSINFO_PARENTSEQ";

--------------------------------------------------------
--  DDL for Synonymn DESTINATION_MESSAGE_RCPT_BAK
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."DESTINATION_MESSAGE_RCPT_BAK" FOR "APP"."DESTINATION_MESSAGE_RCPT_BAK";

--------------------------------------------------------
--  DDL for Synonymn IDX_LOGIN_HISTORY_GROUP_SEQ
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."IDX_LOGIN_HISTORY_GROUP_SEQ" FOR "APP"."IDX_LOGIN_HISTORY_GROUP_SEQ";

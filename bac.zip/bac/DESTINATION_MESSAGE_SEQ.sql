--------------------------------------------------------
--  DDL for Synonymn DESTINATION_MESSAGE_SEQ
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."DESTINATION_MESSAGE_SEQ" FOR "APP"."DESTINATION_MESSAGE_SEQ";

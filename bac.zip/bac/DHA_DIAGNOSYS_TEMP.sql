--------------------------------------------------------
--  DDL for Synonymn DHA_DIAGNOSYS_TEMP
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."DHA_DIAGNOSYS_TEMP" FOR "INTX"."DHA_DIAGNOSYS_TEMP";

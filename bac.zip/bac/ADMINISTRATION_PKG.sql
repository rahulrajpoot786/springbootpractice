--------------------------------------------------------
--  DDL for Package Body ADMINISTRATION_PKG
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "VENUBABU"."ADMINISTRATION_PKG" is

 --==============================================================================================
 --   Name       : SAVE_TPA_OFFICE
 --   Created on-19-MAR-06
 --   Created By- S.V.Sreeraj.
 --   Comments   :
 --==============================================================================================
  PROCEDURE save_tpa_office(
    v_tpa_office_seq_id                  IN  OUT TPA_OFFICE_INFO.tpa_office_seq_id%TYPE,
    v_tpa_office_general_type_id         IN  TPA_OFFICE_INFO.tpa_office_general_type_id%TYPE,
    v_office_code                        IN  TPA_OFFICE_INFO.office_code%TYPE,
    v_office_name                        IN  TPA_OFFICE_INFO.office_name%TYPE,
    v_std_code                           IN  TPA_OFFICE_INFO.std_code%TYPE,
    v_tpa_parent_seq_id                  IN  TPA_OFFICE_INFO.tpa_parent_seq_id%TYPE,
    v_email_id                           IN  TPA_OFFICE_INFO.email_id%TYPE,
    v_alt_email_id                       IN  TPA_OFFICE_INFO.alt_email_id%TYPE,
    v_off_phone_no_1                     IN  TPA_OFFICE_INFO.off_phone_no_1%TYPE,
    v_off_phone_no_2                     IN  TPA_OFFICE_INFO.off_phone_no_2%TYPE,
    v_office_fax_no_1                    IN  TPA_OFFICE_INFO.office_fax_no_1%TYPE,
    v_office_fax_no_2                    IN  TPA_OFFICE_INFO.office_fax_no_2%TYPE,
    v_toll_free_no                       IN  TPA_OFFICE_INFO.toll_free_no%TYPE,
    v_active_yn                          IN  TPA_OFFICE_INFO.active_yn%TYPE,
    -----------------------
    v_addr_seq_id                        IN  OUT TPA_ADDRESS.addr_seq_id%TYPE,
    v_address_1                          IN  TPA_ADDRESS.address_1%TYPE,
    v_address_2                          IN  TPA_ADDRESS.address_2%TYPE,
    v_address_3                          IN  TPA_ADDRESS.address_3%TYPE,
    v_state_type_id                      IN  TPA_ADDRESS.state_type_id%TYPE,
    v_city_type_id                       IN  TPA_ADDRESS.city_type_id%TYPE,
    v_pin_code                           IN  TPA_ADDRESS.pin_code%TYPE,
    v_country_id                         IN  TPA_ADDRESS.country_id%TYPE,
    -----------------------
    v_pan_number                         IN  TPA_OFFICE_INFO.pan_number%TYPE,
    v_tax_deduction_acct_no              IN  TPA_OFFICE_INFO.tax_deduction_acct_no%TYPE,
    v_added_by                           IN  TPA_OFFICE_INFO.added_by%TYPE,
    v_rows_processed                     IN  OUT NUMBER
  )
  IS
    v_old_tpa_parent_seq_id      tpa_office_info.tpa_parent_seq_id%TYPE;
    v_parent_general_type_id     tpa_office_info.tpa_office_general_type_id%TYPE;

    v_group_seq_id               TPA_GROUPS.group_seq_id%TYPE;

  BEGIN

    IF v_tpa_office_seq_id = 0  THEN
     -- Changing the parent to Zonal If it was a Branch Node.
      UPDATE tpa_office_info SET
        tpa_office_general_type_id = 'TZO'
       WHERE tpa_office_seq_id = v_tpa_parent_seq_id AND tpa_office_general_type_id = 'TBO';

      INSERT INTO tpa_office_info(
        tpa_office_seq_id,
        tpa_office_general_type_id,
        office_code,
        office_name,
        std_code,
        email_id,
        alt_email_id,
        tpa_parent_seq_id,
        off_phone_no_1,
        off_phone_no_2,
        office_fax_no_1,
        office_fax_no_2,
        toll_free_no,
        active_yn,
        pan_number,
        tax_deduction_acct_no,
        added_by,
        added_date )
      VALUES (
        tpa_office_info_seq.NEXTVAL,
        v_tpa_office_general_type_id,
        UPPER(v_office_code),
        UPPER(v_office_name),
        v_std_code,
        v_email_id,
        v_alt_email_id,
        v_tpa_parent_seq_id,
        v_off_phone_no_1,
        v_off_phone_no_2,
        v_office_fax_no_1,
        v_office_fax_no_2,
        v_toll_free_no,
        v_active_yn,
        v_pan_number,
        v_tax_deduction_acct_no,
        v_added_by,
        SYSDATE ) RETURNING tpa_office_seq_id INTO v_tpa_office_seq_id;

        --associating this branch to the default group.
        SELECT group_seq_id INTO v_group_seq_id
          FROM tpa_groups WHERE default_group_yn = 'Y';

        -- Inserting a default Group Branch for This TTK Office
        INSERT INTO tpa_group_branch (
          group_branch_seq_id, group_seq_id, tpa_office_seq_id, added_by,  added_date)
        VALUES (
          group_branch_seq_id.NEXTVAL, v_group_seq_id , v_tpa_office_seq_id ,  v_added_by , SYSDATE );

    ELSE
      SELECT tpa_parent_seq_id INTO v_old_tpa_parent_seq_id
        FROM tpa_office_info
       WHERE tpa_office_seq_id = v_tpa_office_seq_id;

       IF v_tpa_parent_seq_id IS NOT NULL THEN
         SELECT tpa_office_general_type_id INTO v_parent_general_type_id
           FROM tpa_office_info
          WHERE tpa_office_seq_id = v_tpa_parent_seq_id;

         IF v_tpa_office_general_type_id = 'TZO' AND v_parent_general_type_id != 'THO' THEN
           raise_application_error(-20047, 'Cannot Make a Zonal Office Report to a Office other than Head Office');
         END IF;
       END IF;

       IF v_tpa_office_seq_id = v_tpa_parent_seq_id THEN
         raise_application_error(-20046, 'An Office Cannot Report to That Office Itself');
       END IF;

      UPDATE tpa_office_info SET
        office_code                             = UPPER(v_office_code),
        office_name                             = UPPER(v_office_name),
        std_code                                = v_std_code,
        email_id                                = v_email_id,
        alt_email_id                            = v_alt_email_id,
        tpa_parent_seq_id                       = v_tpa_parent_seq_id,
        off_phone_no_1                          = v_off_phone_no_1,
        off_phone_no_2                          = v_off_phone_no_2,
        office_fax_no_1                         = v_office_fax_no_1,
        office_fax_no_2                         = v_office_fax_no_2,
        toll_free_no                            = v_toll_free_no,
        active_yn                               = v_active_yn,
        pan_number                              = v_pan_number,
        tax_deduction_acct_no                   = v_tax_deduction_acct_no,
        updated_by                              = v_added_by,
        updated_date                            = SYSDATE
        WHERE tpa_office_seq_id = v_tpa_office_seq_id;

      -- Changing the new parent node and old parent node if parent is modified.

      IF v_old_tpa_parent_seq_id != v_tpa_parent_seq_id THEN
        UPDATE tpa_office_info SET
          tpa_office_general_type_id = 'TZO'
         WHERE tpa_office_seq_id = v_tpa_parent_seq_id AND tpa_office_general_type_id = 'TBO';

        UPDATE tpa_office_info SET
            tpa_office_general_type_id = 'TBO'
           WHERE tpa_office_seq_id = v_old_tpa_parent_seq_id
           AND tpa_office_general_type_id = 'TZO'
           AND NOT EXISTS (SELECT 1
                             FROM tpa_office_info
                            WHERE tpa_parent_seq_id = v_old_tpa_parent_seq_id );
      END IF;
    END IF;
    v_rows_processed := SQL%ROWCOUNT;
    -- Saving the Adress Information
    contact_pkg.save_group_address (
        NVL(v_addr_seq_id,0),
        v_tpa_office_seq_id ,
        NULL,
        NULL,
        v_address_1 ,
        v_address_2 ,
        v_address_3 ,
        v_state_type_id ,
        v_city_type_id ,
        v_country_id ,
        v_pin_code  ,
        v_added_by,
        null,--isd
        null,--std
        null,--officephone1
        null--officephone2
      );

    COMMIT;
  END save_tpa_office;
  --====================================================================================================================
  PROCEDURE select_tpa_office_list (
    v_tpa_parent_seq_id            IN TPA_OFFICE_INFO.tpa_parent_seq_id%TYPE,
    v_start_num                    IN NUMBER,
    v_end_num                      IN NUMBER,
    v_level                        IN NUMBER,  -- 1 - for Head Office,  2 - for Second Level Nodes, 3 -  for Leaf Nodes
    result_set                     OUT SYS_REFCURSOR
  )
  IS
    v_sql_str       VARCHAR2(2000);
  BEGIN
    IF v_tpa_parent_seq_id IS NULL THEN
      v_sql_str  := 'SELECT A.*,B.description
                     FROM (SELECT  A.tpa_office_seq_id, A.office_name , A.tpa_office_general_type_id,
                            A.active_yn ,level L
                            FROM tpa_office_info A
                            START WITH tpa_parent_seq_id IS NULL
                           CONNECT BY PRIOR tpa_office_seq_id  = tpa_parent_seq_id) A
                           JOIN tpa_general_code B ON (A.tpa_office_general_type_id = B.general_type_id)';
    ELSE
      v_sql_str  := 'SELECT A.*,B.description
                     FROM (SELECT  A.tpa_office_seq_id, A.office_name , A.tpa_office_general_type_id,
                            A.active_yn, level L
                            FROM tpa_office_info A
                            START WITH tpa_office_seq_id  = '||TO_CHAR(v_tpa_parent_seq_id) ||
                           'CONNECT BY PRIOR tpa_office_seq_id  = tpa_parent_seq_id) A
                           JOIN tpa_general_code B ON (A.tpa_office_general_type_id = B.general_type_id)';
    END IF;
    v_sql_str := v_sql_str ||' AND L = '||v_level ;
    v_sql_str  := 'SELECT * FROM (SELECT A.* , DENSE_RANK() OVER (ORDER BY office_name,ROWNUM ASC ) Q FROM ('||v_sql_str||')A)
    WHERE Q >= '||to_char(v_start_num)||' AND Q <= '|| to_char(v_end_num);


    OPEN result_set FOR v_sql_str;
  END select_tpa_office_list;
  --====================================================================================================================
  PROCEDURE select_tpa_office (
    v_tpa_office_seq_id            IN TPA_OFFICE_INFO.tpa_parent_seq_id%TYPE,
    result_set                     OUT SYS_REFCURSOR
  )
  IS
  BEGIN
    OPEN result_set FOR
      SELECT
      A.tpa_office_seq_id ,
      A.tpa_office_general_type_id ,
      A.office_code,
      A.office_name ,
      A.std_code,
      A.email_id ,
      A.alt_email_id ,
      A.tpa_parent_seq_id ,
      A.general_type_id,
      A.off_phone_no_1,
      A.off_phone_no_2,
      A.office_fax_no_1,
      A.office_fax_no_2 ,
      A.toll_free_no ,
      A.active_yn ,
      B.addr_seq_id,
      B.address_1,
      B.address_2,
      B.address_3,
      B.state_type_id ,
      B.city_type_id ,
      B.pin_code ,
      B.country_id ,
      C.description,
      A.registration_number,
      a.pan_number,
      a.tax_deduction_acct_no
      FROM tpa_office_info A JOIN tpa_address B ON (A.tpa_office_seq_id = B.tpa_office_seq_id )
      JOIN tpa_general_code C ON (a.tpa_office_general_type_id = c.general_type_id)
      WHERE A.tpa_office_seq_id = v_tpa_office_seq_id ;
  END select_tpa_office;
 --==============================================================================================
 --   Name       : SAVE_ADDRESS
 --   Created on-19-MAR-06
 --   Created By-
 --   Comments   :
 --==============================================================================================
  PROCEDURE delete_office(
    v_tpa_office_seq_id           IN tpa_office_info.tpa_office_seq_id%TYPE,
    v_added_by                    IN NUMBER,
    v_rows_processed              OUT NUMBER
  )
  IS
    v_tpa_parent_seq_id            tpa_office_info.tpa_office_general_type_id%TYPE;
  BEGIN
    DELETE FROM tpa_address WHERE
      tpa_office_seq_id = v_tpa_office_seq_id;

    DELETE FROM tpa_group_branch
      WHERE tpa_office_seq_id = v_tpa_office_seq_id;

    DELETE FROM tpa_office_info
      WHERE tpa_office_seq_id = v_tpa_office_seq_id
      RETURNING  tpa_parent_seq_id
         INTO  v_tpa_parent_seq_id;

     v_rows_processed := SQL%ROWCOUNT;

    -- Updating the parent to BRANCH if no more nodes exist.
    IF v_rows_processed > 0 THEN
      UPDATE tpa_office_info SET
        tpa_office_general_type_id = 'TBO'
        WHERE tpa_office_seq_id = v_tpa_parent_seq_id AND tpa_office_general_type_id = 'TZO'
        AND NOT EXISTS (SELECT 1
                          FROM tpa_office_info
                         WHERE tpa_parent_seq_id = v_tpa_parent_seq_id );

    END IF;

    COMMIT;
  END delete_office;
  --==============================================================================================
  PROCEDURE save_office_properties (
    v_tpa_office_seq_id                  IN  TPA_OFFICE_INFO.tpa_office_seq_id%TYPE,
    v_pa_limit                           IN  TPA_OFFICE_INFO.pa_limit%TYPE,
    v_claim_limit                        IN  TPA_OFFICE_INFO.claim_limit%TYPE,
    v_pa_allowed_yn                      IN  TPA_OFFICE_INFO.pa_allowed_yn%TYPE,
    v_claim_allowed_yn                   IN  TPA_OFFICE_INFO.claim_allowed_yn%TYPE,
    v_card_print_yn                      IN  TPA_OFFICE_INFO.card_print_yn%TYPE,
    v_enroll_process_yn                  IN  TPA_OFFICE_INFO.enroll_process_yn%TYPE,
    v_added_by                           IN  NUMBER,
    v_rows_processed                     IN  OUT NUMBER
  )
  IS
  BEGIN
    UPDATE tpa_office_info SET
        pa_limit                                = v_pa_limit,
        claim_limit                             = v_claim_limit,
        pa_allowed_yn                           = v_pa_allowed_yn,
        claim_allowed_yn                        = v_claim_allowed_yn,
        card_print_yn                           = v_card_print_yn,
        enroll_process_yn                       = v_enroll_process_yn ,
        updated_by                              = v_added_by,
        updated_date                            = SYSDATE
        WHERE tpa_office_seq_id  = v_tpa_office_seq_id;
    v_rows_processed := SQL%ROWCOUNT;
    COMMIT;
  END save_office_properties;
  --==============================================================================================
  PROCEDURE select_office_properties(
    v_tpa_office_seq_id            IN TPA_OFFICE_INFO.tpa_parent_seq_id%TYPE,
    result_set                     OUT SYS_REFCURSOR
  )
  IS
  BEGIN
    OPEN result_set FOR
      SELECT
      A.tpa_office_seq_id,
      A.pa_limit,
      A.pa_allowed_yn,
      A.claim_allowed_yn,
      A.claim_limit,
      A.card_print_yn,
      A.enroll_process_yn
      FROM tpa_office_info A WHERE tpa_office_seq_id = v_tpa_office_seq_id;
  END select_office_properties;
  --==============================================================================================
  --==============================================================================================
  PROCEDURE select_admin_policy(
    v_prod_policy_seq_id          IN tpa_ins_prod_policy.prod_policy_seq_id%TYPE,
    v_added_by                    IN NUMBER,
    result_set                    OUT SYS_REFCURSOR
  )
  IS
  BEGIN
    OPEN result_set FOR
       SELECT
        A.enrol_batch_seq_id,
        D.ins_comp_name,
        A.ins_seq_id,
        D.ins_comp_code_number  ,

        C.group_id||'-'||lpad(nvl(a.sub_group_id,'000'),3,'0') AS group_id,
        C.group_id AS grp_id,
        C.group_name,
        --Insurance Related Information
        A.policy_number,
        A.ins_status_general_type_id,
        A.enrol_type_id,
        E.enrol_description,
        A.policy_sub_general_type_id,
        H.description AS policy_sub_type,
        A.effective_from_date,
        A.effective_to_date ,
        A.policy_issue_date ,
        A.product_seq_id,
        F.product_name,
        A.policy_status_general_type_id,
        I.description AS policy_status_description,
        A.admin_status_general_type_id,
        A.policy_rcvd_date ,
        A.tpa_office_seq_id ,
        J.office_name,
        A.group_branch_seq_id,
        A.gen_enrid_general_type_id,
        A.card_clearance_days,
        A.claim_clearance_days,
        A.pa_clearance_hours ,
        A.tpa_cheque_issued_general_type,
        A.policy_seq_id,
        C.group_reg_seq_id ,
        A.buffer_allowed_yn,
        A.admin_auth_general_type_id,
        A.buffer_alloc_general_type_id ,
        A.dms_reference_id,
        B.template_id,
        B.dv_reqd_general_type_id,
        b.tenure,
        b.Stop_Preauth_Yn,
        b.opd_benefits_yn, --koc1286
        b.stop_claim_yn,
        nvl(A.Member_Buffer_Yn,'N') AS Member_Buffer_Yn,  --KOCIBM
      --KOC1270
        nvl(a.CBH_SUMINS_YN,'N') as V_CBH_SUMINS_YN,
        NVL(a.CONV_SUMINS_YN,'N') AS V_CONV_SUMINS_YN,
      --KOC1270
        nvl(a.critical_sumins_yn,'N') as critical_sumins_yn, --koc1273
        a.broker_group_id, --koc1347_new
        nvl(a.broker_yn,'N') broker_yn, --koc1347_new
        nvl(a.survival_prd,'N') as survival_period_yn,  --koc1273
        pat_allowed_yn,
        clm_allowed_yn,
        pat_to_mail_id,
        pat_cc_mail_id,
        clm_to_mail_id,
        clm_cc_mail_id,
        a.hcu_pay_to_general_type, --opdforhs
        a.tpa_name, --opdforhs
        a.HR_APPR_REQUIRED_YN,
        F.authority_type,
        (case when a.auth_product_code is null then f.auth_product_code else a.auth_product_code end) as auth_product_code,            --display aothority product code
        a.co_ins,
        a.deductable as deductible,
        a.pol_plan as plan,
        a.pol_class as class,
        a.maternity_yn,
        a.maternity_co_pay as maternity_copay,
        a.dental_yn,
        a.dental_co_pay as dental_copay,
        a.optical_yn,
        a.optical_co_pay as optical_copay,
        a.pharmaceutical as pharmaceuticals,
        a.eligibility_yn as eligibility ,
        a.ip_op_services,
        a.line_of_business, --cr0229
        a.opts_pat_limit, -- cr0305
        b.stop_preauth_date,
        b.stop_clm_date
        

        FROM tpa_enr_policy A JOIN tpa_ins_prod_policy B ON (a.policy_seq_id = b.policy_seq_id)
        LEFT OUTER JOIN tpa_group_registration C ON (A.group_reg_seq_id = C.group_reg_seq_id )
        JOIN tpa_ins_info D ON (A.ins_seq_id = D.ins_seq_id)
        JOIN tpa_enrolment_type_code E ON (A.enrol_type_id = E.enrol_type_id)
        JOIN tpa_ins_product F ON (A.product_seq_id = F.product_seq_id)
        LEFT OUTER JOIN tpa_general_code H ON (A.policy_sub_general_type_id = H.general_type_id)
        LEFT OUTER JOIN tpa_general_code I ON (A.policy_status_general_type_id = I.general_type_id)
        LEFT OUTER JOIN tpa_office_info J ON (a.tpa_office_seq_id = J.tpa_office_seq_id)
        WHERE B.prod_policy_seq_id = v_prod_policy_seq_id  ;

  END select_admin_policy;
  --==============================================================================================
  PROCEDURE select_admin_policy_list(
    search_tab      IN policy_enrollment_pkg.filter_tab_type,
    v_sort_var      IN VARCHAR2,
    v_sort_order    IN VARCHAR2,
    v_start_num     IN NUMBER ,
    v_end_num       IN NUMBER,
    v_added_by      IN NUMBER,
    result_set      OUT SYS_REFCURSOR
  )
  IS
    TYPE bind_tab_type IS TABLE OF VARCHAR2(250) INDEX BY BINARY_INTEGER ;
    v_sql_str                            VARCHAR2(4000);
    v_where                              VARCHAR2(2000);
    bind_tab                             bind_tab_type;
    i                                    NUMBER(2) := 0;
  BEGIN

      v_sql_str :=
       'SELECT A.policy_seq_id,
          A.policy_number,
          C.ins_seq_id,
          C.ins_comp_name,
          A.enrol_type_id,
          E.enrol_description,
          b.group_id||''-''||lpad(nvl(a.sub_group_id,''000''),3,''0'') AS group_id,
          B.group_name,
          A.admin_status_general_type_id,
          F.description,
          D.office_name,
          G.prod_policy_seq_id
          FROM tpa_enr_policy A LEFT OUTER JOIN tpa_group_registration B ON (A.group_reg_seq_id = B.group_reg_seq_id)
          JOIN tpa_ins_info C ON (A.ins_seq_id = C.ins_seq_id)
          LEFT OUTER JOIN tpa_office_info D ON (A.tpa_office_seq_id = D.tpa_office_seq_id)
          JOIN tpa_enrolment_type_code E ON (A.enrol_type_id = E.enrol_type_id)
          LEFT OUTER JOIN tpa_general_code F ON (A.admin_status_general_type_id = F.general_type_id)
          JOIN tpa_ins_prod_policy G ON (A.policy_seq_id = G.policy_seq_id) ';

    IF search_tab.FIRST IS NOT NULL THEN
       IF search_tab(1) IS NOT NULL THEN
         v_where := v_where || ' AND A.policy_number LIKE :search_tab_1 ';
         i := i+1;
         bind_tab(i) := UPPER(search_tab(1))||'%';
       END IF;

       IF search_tab(2) IS NOT NULL THEN
         v_where := v_where || ' AND A.enrol_type_id  = :search_tab_2 ';
         i := i+1;
         bind_tab(i) := UPPER(search_tab(2));
       END IF;

       IF search_tab(3) IS NOT NULL THEN
         v_where := v_where || ' AND A.ins_head_office_seq_id  = :search_tab_3 ';
         i := i+1;
         bind_tab(i) := TO_CHAR(search_tab(3));
       END IF;

       IF search_tab(4) IS NOT NULL THEN
        v_where := v_where || ' AND A.tpa_office_seq_id = :search_tab_4 ';
        i := i+1;
        bind_tab(i) := TO_CHAR(search_tab(4));
       END IF;

       IF search_tab(5) IS NOT NULL THEN
         v_where := v_where || ' AND A.admin_status_general_type_id = :search_tab_5 ';
        i := i+1;
        bind_tab(i) := UPPER(search_tab(5));
       END IF;

       IF search_tab(6) IS NOT NULL THEN
         v_where := v_where || ' AND B.group_id LIKE :search_tab_6 ';
         i := i+1;
         bind_tab(i) := UPPER(search_tab(6))||'%';
       END IF;

       IF search_tab(7) IS NOT NULL THEN
         v_where := v_where || ' AND B.group_name LIKE :search_tab_7 ';
         i := i+1;
         bind_tab(i) := '%'||UPPER(search_tab(7))||'%';
       END IF;
    END IF;

    v_where :=  v_where ||' AND A.deleted_yn = ''N''' ;

    v_where := ' WHERE '|| SUBSTR(v_where,5);
    v_sql_str := v_sql_str ||v_where;

    v_sql_str := 'SELECT * FROM
      (SELECT A.*,DENSE_RANK() OVER (ORDER BY '||v_sort_var||' '||v_sort_order||' ,ROWNUM ) Q FROM (' ||v_sql_str|| ') A )
       WHERE  Q >= :v_start_num  AND Q <= :v_end_num ';

    IF bind_tab.FIRST IS NOT NULL THEN
       CASE bind_tab.COUNT
         WHEN 1 THEN OPEN result_set FOR v_sql_str USING bind_tab(1) , v_start_num , v_end_num ;
         WHEN 2 THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2), v_start_num , v_end_num ;
         WHEN 3 THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) , v_start_num , v_end_num ;
         WHEN 4 THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,v_start_num ,v_end_num ;
         WHEN 5 THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5) ,v_start_num , v_end_num ;
         WHEN 6 THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5) ,bind_tab(6)  ,v_start_num , v_end_num ;
         WHEN 7 THEN OPEN result_set FOR v_sql_str USING bind_tab(1),bind_tab(2),bind_tab(3) ,bind_tab(4) ,bind_tab(5) ,bind_tab(6) ,bind_tab(7)  ,v_start_num , v_end_num ;
       END CASE;
    ELSE
      OPEN result_set FOR v_sql_str USING  v_start_num , v_end_num ;
    END IF;

  END select_admin_policy_list;
--============================================================================================================================
  PROCEDURE save_admin_policy (
    v_policy_seq_id                      IN  TPA_ENR_POLICY.policy_seq_id%TYPE,
    v_group_branch_seq_id                IN  TPA_ENR_POLICY.group_branch_seq_id%TYPE,
    v_gen_enrid_general_type_id          IN  TPA_ENR_POLICY.gen_enrid_general_type_id%TYPE,
    v_cheque_issued_general_type         IN  TPA_ENR_POLICY.tpa_cheque_issued_general_type%TYPE,
    v_card_clearance_days                IN  TPA_ENR_POLICY.card_clearance_days%TYPE,
    v_claim_clearance_days               IN  TPA_ENR_POLICY.claim_clearance_days%TYPE,
    v_pa_clearance_hours                 IN  TPA_ENR_POLICY.pa_clearance_hours%TYPE,
    v_admin_status_general_type_id       IN  TPA_ENR_POLICY.admin_status_general_type_id%TYPE,
    v_buffer_allowed_yn                  IN  TPA_ENR_POLICY.buffer_allowed_yn%TYPE,
    v_admin_auth_general_type_id         IN  TPA_ENR_POLICY.admin_auth_general_type_id%TYPE,
    v_buffer_alloc_general_type_id       IN  TPA_ENR_POLICY.buffer_alloc_general_type_id%TYPE,
    v_template_id                        IN  NUMBER ,
    v_dv_reqd_general_type_id            IN  TPA_INS_PROD_POLICY.dv_reqd_general_type_id%TYPE,
    v_tenure                             IN  TPA_INS_PROD_POLICY.Tenure%TYPE,
    v_stop_preauth_yn                    IN  TPA_INS_PROD_POLICY.stop_preauth_yn%TYPE,
    v_stop_claim_yn                      IN  TPA_INS_PROD_POLICY.stop_claim_yn%TYPE,
    v_added_by                           IN  NUMBER,
    v_mem_buffer_yn                      IN  TPA_ENR_POLICY.Member_Buffer_Yn%TYPE:='N', --KOCIBM
    v_OPD_BENEFITS_YN                    IN  TPA_INS_PROD_POLICY.OPD_BENEFITS_YN%TYPE,--KOC1286
    V_CBH_SUMINS_YN                      IN tpa_enr_policy.cbh_sumins_yn%type,    --KOC1270
    V_CONV_SUMINS_YN                     IN tpa_enr_policy.cbh_sumins_yn%type,   --KOC1270
    V_CTL_SUMINS_YN                      IN tpa_enr_policy.Critical_Sumins_Yn%type,    --koc1273
    V_SURVIVAL_PRD                       IN tpa_enr_policy.survival_prd%type,          --koc1273
	 --KOC1274A
    v_pat_allowed_yn                     in tpa_ins_prod_policy.pat_allowed_yn%type,
    v_clm_allowed_yn                     in tpa_ins_prod_policy.clm_allowed_yn%type,
    v_pat_to_mail_id                     in tpa_ins_prod_policy.pat_to_mail_id%type,
    v_pat_cc_mail_id                     in tpa_ins_prod_policy.pat_cc_mail_id%type,
    v_clm_to_mail_id                     in tpa_ins_prod_policy.clm_to_mail_id%type,
    v_clm_cc_mail_id                     in tpa_ins_prod_policy.clm_cc_mail_id%type,
--koc1274a
    v_hcu_pay_to_type_id                 IN tpa_enr_policy.hcu_pay_to_general_type%type,----opdforhs
    v_tpa_name                           IN tpa_enr_policy.tpa_name%type, ----opdforhs
    V_BROKER_GROUP_ID                    IN tpa_enr_policy.BROKER_GROUP_ID%type,  --koc1347_new
    V_BROKER_YN                          IN tpa_enr_policy.BROKER_YN%type,  --koc1347_new
    v_hr_appr_req_yn                     IN tpa_enr_policy.Hr_Appr_Required_Yn%TYPE,
    v_rows_processed                     IN  OUT NUMBER,
    V_AUTH_PRODUCT_CODE                  IN tpa_enr_policy.AUTH_PRODUCT_CODE%type,-------for authority product code
  -----added for hos tob (venu babu)
    v_co_ins                             IN tpa_enr_policy.co_ins%type,
    v_Deductable                         IN tpa_enr_policy.Deductable%TYPE,
    v_pol_Class                          IN tpa_enr_policy.pol_class%type,
    v_pol_plan                           IN tpa_enr_policy.pol_plan%type,
    v_Maternity_yn                       IN tpa_enr_policy.Maternity_Yn%TYPE,
    v_Maternity_Co_Pay                   IN tpa_enr_policy.Maternity_Co_Pay%TYPE,
    v_Optical_yn                         IN tpa_enr_policy.Optical_Yn%TYPE,
    v_Optical_Co_Pay                     IN tpa_enr_policy.optical_co_pay%type,
    v_Dental_yn                          IN tpa_enr_policy.dental_yn%type,
    v_Dental_Co_Pay                      IN tpa_enr_policy.dental_co_pay%type,
    v_Eligibility_yn                     IN tpa_enr_policy.eligibility_yn%type,
    v_IP_OP_Services                     IN tpa_enr_policy.ip_op_services%type,
    v_Pharmaceutical                     in tpa_enr_policy.pharmaceutical%type,
    v_opts_pat_limit                     IN tpa_enr_policy.opts_pat_limit%type,
    v_stop_pre_date                      IN tpa_ins_prod_policy.stop_preauth_date%type,
    v_stop_clm_date	                 IN tpa_ins_prod_policy.stop_clm_date%type   
  )
  IS
    v_prev_alloc_type                    TPA_ENR_POLICY.buffer_alloc_general_type_id%TYPE;
    v_prev_dv_reqd_general_type_id       TPA_INS_PROD_POLICY.dv_reqd_general_type_id%TYPE;
    v_buffer_alloc_amount                TPA_ENR_POLICY.buffer_alloc_amount%TYPE;
    v_med_buff_alloc_amount              TPA_ENR_POLICY.buffer_alloc_amount%TYPE;
    v_crit_buff_alloc_amount             TPA_ENR_POLICY.buffer_alloc_amount%TYPE;
    v_crit_corp_buff_alloc_amount        TPA_ENR_POLICY.buffer_alloc_amount%TYPE;
    v_crit_med_buff_alloc_amount         TPA_ENR_POLICY.buffer_alloc_amount%TYPE;
    v_policy_sub_general_type_id         TPA_ENR_POLICY.policy_sub_general_type_id%TYPE;
    v_currently_uploading_yn             TPA_ENR_POLICY.currently_uploading_yn%TYPE;
    v_ctr                                PLS_INTEGER;
    CURSOR prev_cur IS SELECT a.buffer_alloc_general_type_id , b.dv_reqd_general_type_id ,
      a.buffer_alloc_amount, a.policy_sub_general_type_id, a.currently_uploading_yn,
      a.med_buff_alloc_amount,a.crit_buff_alloc_amount,a.crit_corp_buff_alloc_amount,a.crit_med_buff_alloc_amount
      FROM tpa_enr_policy a JOIN tpa_ins_prod_policy b ON (a.policy_seq_id = b.policy_seq_id)
       WHERE a.policy_seq_id = v_policy_seq_id;
    
    CURSOR prev_stop_cur IS SELECT a.stop_preauth_yn,a.stop_claim_yn,a.stop_preauth_date,a.stop_clm_date 
                            FROM tpa_ins_prod_policy a 
                            WHERE a.policy_seq_id = v_policy_seq_id;
    
    v_alert  varchar2(100);
    buff_rec                 claims_pkg.buff_type;
    v_result_set             sys_refcursor;
    stop_rec    prev_stop_cur%rowtype;  

  BEGIN
    OPEN prev_cur;
    FETCH prev_cur INTO v_prev_alloc_type, v_prev_dv_reqd_general_type_id ,v_buffer_alloc_amount,v_policy_sub_general_type_id,v_currently_uploading_yn,v_med_buff_alloc_amount,v_crit_buff_alloc_amount,v_crit_corp_buff_alloc_amount,v_crit_med_buff_alloc_amount;
    CLOSE prev_cur;
    
    OPEN prev_stop_cur;
    FETCH prev_stop_cur INTO stop_rec;
    CLOSE prev_stop_cur;
    -- check any uploading happening now.
    policy_enrollment_pkg.check_uploading(v_currently_uploading_yn);

    UPDATE tpa_enr_policy p SET
      group_branch_seq_id                     = v_group_branch_seq_id,
      gen_enrid_general_type_id               = v_gen_enrid_general_type_id,
      tpa_cheque_issued_general_type          = v_cheque_issued_general_type,
      card_clearance_days                     = v_card_clearance_days,
      claim_clearance_days                    = v_claim_clearance_days,
      pa_clearance_hours                      = v_pa_clearance_hours,
      admin_status_general_type_id            = v_admin_status_general_type_id,
      buffer_allowed_yn                       = v_buffer_allowed_yn,
      admin_auth_general_type_id              = v_admin_auth_general_type_id,
      buffer_alloc_general_type_id            = v_buffer_alloc_general_type_id,
      Member_Buffer_Yn                        = v_mem_buffer_yn,
      updated_by                              = v_added_by,
      updated_date                            = SYSDATE,
      CBH_SUMINS_YN                           = V_CBH_SUMINS_YN,--KOC1270
      CONV_SUMINS_YN                          = V_CONV_SUMINS_YN,--KOC1270
      Critical_Sumins_Yn                      = V_CTL_SUMINS_YN,  --koc1273
      BROKER_GROUP_ID                         = V_BROKER_GROUP_ID,     --koc1347_new               
      BROKER_YN                               = V_BROKER_YN,           --koc1347_new              
      SURVIVAL_PRD                            = V_SURVIVAL_PRD,   --koc1273
	    hcu_pay_to_general_type                 = v_hcu_pay_to_type_id,--opdforhs
      tpa_name                                = v_tpa_name, --opdforhs
      HR_APPR_REQUIRED_YN                     = v_hr_appr_req_yn,
      AUTH_PRODUCT_CODE                       = upper(V_AUTH_PRODUCT_CODE),-------for authority product code
     ----newly added for provider login tob
      co_ins                                  = v_co_ins,
      deductable                              = v_Deductable,
      pol_class    	                          = v_pol_Class,
      pol_plan                                = v_pol_plan,
      maternity_yn                            = v_Maternity_yn,
      maternity_co_pay                        = v_Maternity_Co_Pay,
      optical_yn        	                    = v_Optical_yn,
      optical_co_pay                          = v_Optical_Co_Pay,
      dental_yn                               = v_Dental_yn ,
      dental_co_pay                           = v_Dental_Co_Pay,
      eligibility_yn                          = v_Eligibility_yn,
      ip_op_services                          = v_IP_OP_Services,
      pharmaceutical                          = v_Pharmaceutical,
      opts_pat_limit                          = v_opts_pat_limit  --cr-0305
      
      WHERE policy_seq_id = v_policy_seq_id;

    UPDATE tpa_ins_prod_policy a SET
      a.group_branch_seq_id                   = v_group_branch_seq_id,
      a.template_id                           = v_template_id ,
      a.dv_reqd_general_type_id               = v_dv_reqd_general_type_id,
      a.tenure                                = v_tenure,
      a.updated_by                            = v_added_by,
      a.stop_preauth_yn                       = v_stop_preauth_yn,
      a.stop_claim_yn                         = v_stop_claim_yn ,
      a.OPD_BENEFITS_YN                       = v_OPD_BENEFITS_YN,  --koc1286
      a.updated_date                          = SYSDATE,
	    PAT_ALLOWED_YN                          = V_PAT_ALLOWED_YN,
      CLM_ALLOWED_YN                          = V_CLM_ALLOWED_YN,
      PAT_TO_MAIL_ID                          = V_PAT_TO_MAIL_ID,
      PAT_CC_MAIL_ID                          = V_PAT_CC_MAIL_ID,
      CLM_TO_MAIL_ID                          = V_CLM_TO_MAIL_ID,
      CLM_CC_MAIL_ID                          = V_CLM_CC_MAIL_ID,
      a.stop_preauth_date                     = v_stop_pre_date,
      a.stop_clm_date                         = v_stop_clm_date

      WHERE a.policy_seq_id = v_policy_seq_id;
      IF v_prev_dv_reqd_general_type_id != 'DVN' AND v_dv_reqd_general_type_id = 'DVN' THEN
        update_finance_status(v_policy_seq_id,'POL',v_added_by );
      END IF;
      
      ----- stop pre auth and claim log 
      IF nvl(stop_rec.stop_preauth_yn,v_stop_preauth_yn||'a') <> nvl(v_stop_preauth_yn,stop_rec.stop_preauth_yn||'a') OR nvl(trunc(v_stop_pre_date),stop_rec.stop_preauth_date+1)<>nvl(stop_rec.stop_preauth_date,trunc(v_stop_pre_date+1)) OR
         nvl(stop_rec.stop_claim_yn,v_stop_claim_yn||'a') <> nvl(v_stop_claim_yn,stop_rec.stop_claim_yn||'a') OR nvl(trunc(v_stop_clm_date),stop_rec.stop_clm_date+1)<>nvl(trunc(stop_rec.stop_clm_date),trunc(v_stop_clm_date+1)) THEN

          INSERT INTO app.stop_pre_clm_log (
                  stop_pat_clm_seq_id,
                  policy_seq_id,
                  old_stop_pat_yn,
                  old_stop_pat_date,
                  old_stop_clm_yn,
                  old_stop_clm_date,
                  stop_pat_yn,
                  stop_pat_date,
                  stop_clm_yn,
                  stop_clm_date,
                  screen_mode,
                  updated_by,
                  updated_date)
               VALUES  (
                  stop_pat_clm_seq.nextval,
                  v_policy_seq_id,
                  stop_rec.stop_preauth_yn,
                  stop_rec.stop_preauth_date,
                  stop_rec.stop_claim_yn,
                  stop_rec.stop_clm_date,
                  v_stop_preauth_yn,
                  v_stop_pre_date,
                  v_stop_claim_yn, 
                  v_stop_clm_date,
                  'POL',
                  v_added_by,
                  SYSDATE) ;
                      
      END IF;
      
      IF v_prev_alloc_type IS NOT NULL AND (v_buffer_alloc_general_type_id IS NULL OR v_prev_alloc_type!=NVL(v_buffer_alloc_general_type_id,'A')) THEN
        select count(1) into v_ctr from tpa_enr_balance a
        where a.policy_seq_id= v_policy_seq_id
        and ( a.utilised_buff_amount>0 OR
              a.utilised_med_buff_amount > 0 OR 
              a.utilised_crit_buff_amount > 0 OR 
              a.utilised_crit_corp_buff_amt > 0 OR
              a.utilised_crit_med_buff_amt > 0 );
        IF v_ctr > 0 THEN
        raise_application_error(-20261,'You Cannot change  the Buffer Allocation Type After Buffer Utilised.');
       END IF;
     END IF;
      /*IF v_prev_alloc_type = 'BAI' AND v_buffer_alloc_general_type_id = 'BAF' THEN
        -- checking for utilized buffer amount.
        
        SELECT COUNT(1) INTO v_ctr
        FROM ( SELECT SUM(a.utilised_buff_amount) utilised_buff_amount,
        SUM(a.utilised_med_buff_amount) utilised_med_buff_amount,
        SUM(a.utilised_crit_buff_amount) utilised_crit_buff_amount,
        SUM(a.utilised_crit_corp_buff_amt) utilised_crit_corp_buff_amt,
        SUM(a.utilised_crit_med_buff_amt) utilised_crit_med_buff_amt
         FROM tpa_enr_balance a
          JOIN tpa_enr_policy_group b ON (a.policy_group_seq_id = b.policy_group_seq_id)
          WHERE a.policy_seq_id = v_policy_seq_id AND b.deleted_yn = 'N'
          GROUP BY a.policy_group_seq_id HAVING (SUM(a.utilised_buff_amount) > 0 or
           SUM(a.utilised_med_buff_amount) > 0 or
           SUM(a.utilised_crit_buff_amount) > 0 or
           SUM(a.utilised_crit_corp_buff_amt) > 0 or
           SUM(a.utilised_crit_med_buff_amt)> 0   )) WHERE 
          (utilised_buff_amount > v_buffer_alloc_amount
          OR utilised_med_buff_amount >  v_med_buff_alloc_amount
          OR utilised_crit_buff_amount > v_crit_buff_alloc_amount    
          OR utilised_crit_corp_buff_amt > v_crit_corp_buff_alloc_amount
          OR utilised_crit_med_buff_amt >     v_crit_med_buff_alloc_amount);
        IF v_ctr > 0 THEN
          raise_application_error(-20145,'Buffer utilised amount exceeds the total buffer amount.');
        END IF;
        update_preath_n_claims ( v_policy_seq_id  , v_buffer_alloc_amount , v_buffer_alloc_general_type_id , v_policy_sub_general_type_id,  null, null,null,null, null,  v_med_buff_alloc_amount , v_crit_buff_alloc_amount,  v_crit_corp_buff_alloc_amount  ,v_crit_med_buff_alloc_amount,v_alert);
      
         UPDATE tpa_enr_balance a SET
           a.utilised_buff_amount = ( SELECT SUM(utilised_buff_amount)
                                  FROM tpa_enr_balance b WHERE a.policy_group_seq_id = b.policy_group_seq_id ),
            a.utilised_med_buff_amount = ( SELECT SUM(B.utilised_med_buff_amount)
                                  FROM tpa_enr_balance b WHERE a.policy_group_seq_id = b.policy_group_seq_id ),
            a.utilised_crit_buff_amount = ( SELECT SUM(B.utilised_crit_buff_amount)
                                  FROM tpa_enr_balance b WHERE a.policy_group_seq_id = b.policy_group_seq_id ),
            a.utilised_crit_corp_buff_amt = ( SELECT SUM(B.utilised_crit_corp_buff_amt)
                                  FROM tpa_enr_balance b WHERE a.policy_group_seq_id = b.policy_group_seq_id ),
           a.utilised_crit_med_buff_amt = ( SELECT SUM(B.utilised_crit_med_buff_amt)
                                  FROM tpa_enr_balance b WHERE a.policy_group_seq_id = b.policy_group_seq_id )
           WHERE a.policy_seq_id = v_policy_seq_id ;

      ELSIF v_prev_alloc_type IS NOT NULL AND v_buffer_alloc_general_type_id IS NULL THEN
        -- checking for utilized buffer amount.
        update_preath_n_claims ( v_policy_seq_id  , v_buffer_alloc_amount , v_buffer_alloc_general_type_id , v_policy_sub_general_type_id,  null, null,null,null, null,  v_med_buff_alloc_amount , v_crit_buff_alloc_amount,  v_crit_corp_buff_alloc_amount  ,v_crit_med_buff_alloc_amount,v_alert );

        UPDATE tpa_enr_balance a SET
           a.buffer_amount = 0,
           A.MED_BUFFER_AMOUNT=0,
           A.Critical_Buff_Amount=0,
           a.critical_corp_buff_amount=0,
           a.critical_med_buff_amount=0
           WHERE a.policy_seq_id = v_policy_seq_id ;

      ELSIF v_prev_alloc_type IS NULL AND v_buffer_alloc_general_type_id IS NOT NULL THEN
         
          UPDATE tpa_enr_balance a SET
             a.buffer_amount = case when v_buffer_alloc_amount is not null then v_buffer_alloc_amount else buffer_amount end ,
             A.med_buffer_amount = case when v_med_buff_alloc_amount is not null then v_med_buff_alloc_amount else med_buffer_amount end ,
             a.critical_buff_amount = case when v_crit_buff_alloc_amount is not null then v_crit_buff_alloc_amount else critical_buff_amount end ,
             a.critical_corp_buff_amount = case when v_crit_corp_buff_alloc_amount is not null then v_crit_corp_buff_alloc_amount else critical_corp_buff_amount end ,
             a.critical_med_buff_amount= case when v_crit_med_buff_alloc_amount is not null then v_crit_med_buff_alloc_amount else critical_med_buff_amount end 
             WHERE a.policy_seq_id = v_policy_seq_id ;
       
      ELSIF v_prev_alloc_type = 'BAF' AND v_buffer_alloc_general_type_id = 'BAI' THEN
                
        UPDATE tpa_enr_balance a SET
           a.utilised_buff_amount = get_utilised_buffer_amount(a.policy_seq_id,a.policy_group_seq_id,a.member_seq_id,'COR'),
           a.Utilised_Med_Buff_Amount = get_utilised_buffer_amount(a.policy_seq_id,a.policy_group_seq_id,a.member_seq_id,'MED'),
           a.Utilised_Crit_Buff_Amount =get_utilised_buffer_amount(a.policy_seq_id,a.policy_group_seq_id,a.member_seq_id,'CCRT'),
           a.Utilised_Crit_Corp_Buff_Amt = get_utilised_buffer_amount(a.policy_seq_id,a.policy_group_seq_id,a.member_seq_id,'CCOR'),
           a.Utilised_Crit_Med_Buff_Amt = get_utilised_buffer_amount(a.policy_seq_id,a.policy_group_seq_id,a.member_seq_id,'CMED')
           WHERE a.policy_seq_id = v_policy_seq_id ;

     END IF;   */   
      
    v_rows_processed := SQL%ROWCOUNT;
    COMMIT;
  END save_admin_policy;
--============================================================================================================================
  PROCEDURE select_buffer_list (
    v_prod_policy_seq_id                  IN TPA_INS_PROD_POLICY.prod_policy_seq_id%TYPE,
    v_sort_var                            IN VARCHAR2:='buffer_seq_id' ,
    v_sort_order                          IN VARCHAR2,
    v_start_num                           IN NUMBER ,
    v_end_num                             IN NUMBER,
    v_added_by                            IN NUMBER,
    result_set                            OUT SYS_REFCURSOR
  )
  IS
    v_sql_str                              VARCHAR2(4000);

  BEGIN

    v_sql_str :=
      'SELECT
       a.buffer_seq_id,
       a.policy_seq_id,
       a.reference_no ,
       a.buffer_added_date ,
       a.buffer_amount ,
       a.buffer_mode_general_type_id ,
       b.description AS buffer_mode ,
       C.total_buffer_amount,
       c.tot_med_buff_amount,
       c.tot_crit_buff_amount,
       c.tot_crit_corp_buff_amount,
       c.tot_crit_med_buff_amount ,
       a.med_buffer_amount,
       a.critical_corp_buff_amount,
       a.critical_med_buff_amount,
       a.critical_buff_amount
       FROM tpa_enr_buffer_details A LEFT OUTER JOIN tpa_general_code b ON (a.buffer_mode_general_type_id = b.general_type_id)
      JOIN tpa_enr_policy C ON (a.policy_seq_id = c.policy_seq_id)
      JOIN tpa_ins_prod_policy D ON (C.policy_seq_id = D.policy_seq_id)
      WHERE D.prod_policy_seq_id = :v_prod_policy_seq_id ';
      v_sql_str := 'SELECT * FROM
      (SELECT A.*,DENSE_RANK() OVER (ORDER BY '||v_sort_var||' '||v_sort_order||',ROWNUM) Q FROM (' ||v_sql_str|| ') A )
       WHERE  Q>= :v_start_num AND Q<= :v_end_num  ';

    OPEN result_set FOR v_sql_str USING v_prod_policy_seq_id, v_start_num, v_end_num;

  END select_buffer_list;
--============================================================================================================================
  PROCEDURE select_buffer_details (
    v_buffer_seq_id                       IN  TPA_ENR_BUFFER_DETAILS.buffer_seq_id%TYPE,
    v_policy_seq_id                       IN  TPA_ENR_BUFFER_DETAILS.policy_seq_id%TYPE,
    v_added_by                            IN  NUMBER,
    result_set                            OUT SYS_REFCURSOR
  )
  IS
    CURSOR last_buff_cur IS SELECT a.buffer_seq_id FROM tpa_enr_buffer_details a
         WHERE a.policy_seq_id = v_policy_seq_id ORDER BY a.buffer_added_date DESC ,a.buffer_seq_id DESC;

    last_buff_rec      last_buff_cur%ROWTYPE;

  BEGIN
    OPEN last_buff_cur;
    FETCH last_buff_cur INTO last_buff_rec;
    CLOSE last_buff_cur;

    OPEN result_set FOR
      SELECT
        a.buffer_seq_id ,
        a.policy_seq_id ,
        a.buffer_added_date ,
        b.admin_auth_general_type_id ,
        d.description AS authority ,
        b.buffer_alloc_general_type_id ,
        c.description AS allocation_descr,
        a.buffer_alloc_amount ,
        a.buffer_mode_general_type_id ,
        a.buffer_amount ,
        a.reference_no ,
        a.remarks,
        a.med_buffer_amount,
        a.crit_corp_buff_alloc_amount critical_corp_alloc_amount,
        a.crit_med_buff_alloc_amount critical_med_alloc_amount,
        a.med_buff_alloc_amount,
        a.critical_corp_buff_amount,
        a.critical_med_buff_amount,
        a.critical_buff_amount,
        a.crit_buff_alloc_amount critical_buff_alloc_amount,
        /*CASE WHEN a.buffer_seq_id = last_buff_rec.buffer_seq_id THEN 'Y' ELSE */'N' /*END*/ AS edit_yn
        FROM tpa_enr_buffer_details A JOIN tpa_enr_policy B ON ( A.policy_seq_id = B.policy_seq_id )
        LEFT OUTER JOIN tpa_general_code C ON (B.buffer_alloc_general_type_id = C.general_type_id )
        LEFT OUTER JOIN tpa_general_code D ON (b.admin_auth_general_type_id = d.general_type_id)
        WHERE a.buffer_seq_id = v_buffer_seq_id ;
   END select_buffer_details;

 --==============================================================================================
 --   Name       : SAVE_BUFFER_DETAILS
 --   Created on : -13-JUN-06
 --   Created By : - S.V.SREERAJ
 --   UPDATED BY : - Ram, Rcs Technologies
 --   updated_date : - 20-jun-2014
 --   updated_comments: modified for Hyundai Buffer(added medical ,critical illness buffer)
 --   Comments   : Buffer manipulation at policy level.
 --   Update part is removed from VSS version - 84
 --==============================================================================================
PROCEDURE save_buffer_details (
    v_buffer_seq_id                      IN  OUT TPA_ENR_BUFFER_DETAILS.buffer_seq_id%TYPE,
    v_prod_policy_seq_id                 IN  TPA_INS_PROD_POLICY.prod_policy_seq_id%TYPE,
    v_buffer_added_date                  IN  TPA_ENR_BUFFER_DETAILS.buffer_added_date%TYPE,
    v_buffer_mode_general_type_id        IN  TPA_ENR_BUFFER_DETAILS.buffer_mode_general_type_id%TYPE,
    v_buffer_amount                      IN  TPA_ENR_BUFFER_DETAILS.buffer_amount%TYPE,
    v_reference_no                       IN  TPA_ENR_BUFFER_DETAILS.reference_no%TYPE,
    v_remarks                            IN  TPA_ENR_BUFFER_DETAILS.remarks%TYPE,
    v_buffer_alloc_amount                IN  TPA_ENR_BUFFER_DETAILS.buffer_alloc_amount%TYPE,
    v_med_buff_amount                    IN  TPA_ENR_BUFFER_DETAILS.Med_Buffer_Amount%type,
    v_critical_buff_amount               IN  TPA_ENR_BUFFER_DETAILS.CRITICAL_BUFF_AMOUNT%TYPE,
    v_critical_corp_buff_amount          IN  TPA_ENR_BUFFER_DETAILS.Critical_Corp_Buff_Amount%type,
    v_critical_med_buff_amount           IN  TPA_ENR_BUFFER_DETAILS.Critical_Med_Buff_Amount%type,
    v_med_buff_alloc_amount              IN  TPA_ENR_BUFFER_DETAILS.Med_Buff_Alloc_Amount%TYPE,
    v_critical_buff_alloc_amount         IN  TPA_ENR_BUFFER_DETAILS.crit_buff_alloc_amount%type,
    v_critical_corp_alloc_amount         IN  TPA_ENR_BUFFER_DETAILS.crit_corp_buff_alloc_amount%type,
    v_critical_med_alloc_amount          IN  TPA_ENR_BUFFER_DETAILS.crit_med_buff_alloc_amount%type,
    v_added_by                           IN  TPA_ENR_BUFFER_DETAILS.added_by%TYPE,
    v_alert                              OUT VARCHAR2,
    v_rows_processed                     IN  OUT NUMBER)
  IS
    v_total_buffer_amount                TPA_ENR_BUFFER_DETAILS.buffer_amount%TYPE;
    v_prev_buffer_amount                 TPA_ENR_BUFFER_DETAILS.buffer_amount%TYPE;
    v_policy_seq_id                      TPA_ENR_POLICY.policy_seq_id%TYPE;
    v_admin_auth_general_type_id         TPA_ENR_POLICY.admin_auth_general_type_id%TYPE;
    v_buffer_alloc_general_type_id       TPA_ENR_POLICY.buffer_alloc_general_type_id%TYPE;
    v_add_amount                         TPA_ENR_BUFFER_DETAILS.buffer_amount%TYPE;
    v_ded_amount                         TPA_ENR_BUFFER_DETAILS.buffer_amount%TYPE;
    v_prev_buffer_general_type_id        TPA_ENR_BUFFER_DETAILS.Buffer_Mode_General_Type_Id%TYPE;
    v_prev_buffer_alloc_amount           TPA_ENR_BUFFER_DETAILS.Buffer_Alloc_Amount%TYPE;
    v_buffer_allowed_yn                  TPA_ENR_POLICY.Buffer_Allowed_Yn%TYPE;
    v_prev_policy_alloc_buffer           TPA_ENR_BUFFER_DETAILS.Buffer_Alloc_Amount%TYPE;
    v_prev_total_buffer_amount           TPA_ENR_BUFFER_DETAILS.buffer_amount%TYPE;
    v_policy_sub_general_type_id         TPA_ENR_POLICY.policy_sub_general_type_id%TYPE;
    v_currently_uploading_yn             TPA_ENR_POLICY.currently_uploading_yn%TYPE;
    v_prev_med_buffer_amount             TPA_ENR_BUFFER_DETAILS.Med_Buffer_Amount%TYPE;
    v_prev_med_buff_alloc_amount         TPA_ENR_BUFFER_DETAILS.Med_Buff_Alloc_Amount%TYPE;
    v_prev_crit_corp_buff_amount        TPA_ENR_BUFFER_DETAILS.Critical_Corp_Buff_Amount%TYPE;
    v_prev_crit_corp_alloc_amt          TPA_ENR_BUFFER_DETAILS.crit_corp_buff_alloc_amount%TYPE;
    v_total_med_buffer_amount            TPA_ENR_BUFFER_DETAILS.Med_Buffer_Amount%TYPE;
    v_total_crit_corp_buff_amount         TPA_ENR_BUFFER_DETAILS.Critical_Corp_Buff_Amount%TYPE;
    v_total_crit_med_buff_amount          TPA_ENR_BUFFER_DETAILS.CRITICAL_MED_BUFF_AMOUNT%TYPE;
    v_Tot_Crit_Buff_Amount                TPA_ENR_BUFFER_DETAILS.CRITICAL_BUFF_AMOUNT%TYPE;

    CURSOR last_buff_date_cur IS SELECT MAX(a.buffer_added_date)
       FROM tpa_enr_buffer_details a WHERE a.policy_seq_id = v_policy_seq_id
       AND a.buffer_seq_id != nvl(v_buffer_seq_id,0);

    v_last_date        DATE;
    
    CURSOR used_mem_buff_cur(v_policy_seq_id tpa_enr_policy.policy_seq_id%type) IS
    SELECT  SUM(nvl(b.mem_buffer_alloc,0)) AS used_mem_buff,
            SUM(nvl(b.mem_med_buffer_alloc,0)) AS  used_mem_med_buff,
            SUM(nvl(b.mem_crit_corp_buff_alloc,0)) AS  used_mem_crit_corp_buff,
            SUM(nvl(b.mem_crit_buff_alloc,0)) AS  used_mem_crit_buff,
            SUM(nvl(b.mem_crit_med_buff_alloc,0)) AS  used_mem_crit_med_buff
     FROM tpa_enr_policy_group a
    JOIN tpa_enr_policy_member b on (a.policy_group_seq_id=b.policy_group_seq_id)
    where a.policy_seq_id=v_policy_seq_id;
    
    used_mem_buff_rec             used_mem_buff_cur%ROWTYPE;
   
  BEGIN
/*delete from temp_ram;
  insert into temp_ram(remarks) values ('v_buffer_seq_id'||v_buffer_seq_id||CHR(13)||
'v_prod_policy_seq_id'||v_prod_policy_seq_id||CHR(13)||
'v_buffer_added_date'||v_buffer_added_date||CHR(13)||
'v_buffer_mode_general_type_id'||v_buffer_mode_general_type_id||CHR(13)||
'v_buffer_amount'||v_buffer_amount||CHR(13)||
'v_reference_no'||v_reference_no||CHR(13)||
'v_remarks'||v_remarks||CHR(13)||
'v_buffer_alloc_amount'||v_buffer_alloc_amount||CHR(13)||
'v_med_buff_amount'||v_med_buff_amount||CHR(13)||
'v_critical_buff_amount'||v_critical_buff_amount||CHR(13)||
'v_critical_corp_buff_amount'||v_critical_corp_buff_amount||CHR(13)||
'v_critical_med_buff_amount'||v_critical_med_buff_amount||CHR(13)||
'v_med_buff_alloc_amount'||v_med_buff_alloc_amount||CHR(13)||
'v_critical_buff_alloc_amount'||v_critical_buff_alloc_amount||CHR(13)||
'v_critical_corp_alloc_amount'||v_critical_corp_alloc_amount||CHR(13)||
'v_critical_med_alloc_amount'||v_critical_med_alloc_amount);
COMMIT;
*/

    SELECT a.policy_seq_id , b.buffer_alloc_amount, b.total_buffer_amount ,b.buffer_alloc_general_type_id , b.policy_sub_general_type_id, b.currently_uploading_yn
       INTO v_policy_seq_id , v_prev_policy_alloc_buffer , v_prev_total_buffer_amount , v_buffer_alloc_general_type_id , v_policy_sub_general_type_id, v_currently_uploading_yn
       FROM tpa_ins_prod_policy a JOIN tpa_enr_policy b ON ( a.policy_seq_id = b.policy_seq_id )
      WHERE a.prod_policy_seq_id = v_prod_policy_seq_id;

    -- check any uploading happening now.
    policy_enrollment_pkg.check_uploading(v_currently_uploading_yn);

    OPEN last_buff_date_cur;
    FETCH last_buff_date_cur INTO v_last_date;
    CLOSE last_buff_date_cur;

    IF v_buffer_added_date < v_last_date THEN
      raise_application_error(-20682,'Buffer added date should not be less than that of previous bufer record.');
    END IF;

    IF v_buffer_seq_id = 0 THEN
      INSERT INTO tpa_enr_buffer_details(
        buffer_seq_id,
        policy_seq_id,
        buffer_added_date,
        buffer_mode_general_type_id,
        buffer_amount,
        med_buffer_amount,
        critical_buff_amount,
        critical_corp_buff_amount,
        critical_med_buff_amount ,
        buffer_alloc_amount ,
        med_buff_alloc_amount,
        crit_buff_alloc_amount,
        crit_corp_buff_alloc_amount,
        crit_med_buff_alloc_amount ,
        reference_no,
        remarks,
        added_by,
        added_date)
      VALUES (
        buffer_details_seq.NEXTVAL ,
        v_policy_seq_id,
        v_buffer_added_date,
        v_buffer_mode_general_type_id,
        v_buffer_amount,
        v_med_buff_amount,
        v_critical_buff_amount,
        v_critical_corp_buff_amount ,
        v_critical_med_buff_amount,
        v_buffer_alloc_amount ,
        v_med_buff_alloc_amount,
        v_critical_buff_alloc_amount,
        v_critical_corp_alloc_amount,
        v_critical_med_alloc_amount ,
        v_reference_no,
        v_remarks,
        v_added_by,
        SYSDATE) RETURNING buffer_seq_id INTO v_buffer_seq_id;

        IF v_buffer_mode_general_type_id = 'ADD' THEN
          UPDATE tpa_enr_policy A SET
            A.total_buffer_amount = NVL(A.total_buffer_amount,0) + nvl(v_buffer_amount,0),
            A.Tot_Med_Buff_Amount = NVL(A.Tot_Med_Buff_Amount,0) + nvl(v_med_buff_amount,0),
            A.Tot_Crit_Buff_Amount = NVL(A.Tot_Crit_Buff_Amount,0) + nvl(v_critical_buff_amount,0),
            A.Tot_Crit_corp_Buff_Amount = NVL(A.Tot_Crit_corp_Buff_Amount,0) + nvl(v_critical_corp_buff_amount,0),
            A.Tot_Crit_med_Buff_Amount = NVL(A.Tot_Crit_med_Buff_Amount,0) + nvl(v_critical_med_buff_amount,0)
           WHERE policy_seq_id = v_policy_seq_id RETURNING total_buffer_amount,Tot_Med_Buff_Amount ,Tot_Crit_Buff_Amount,Tot_Crit_corp_Buff_Amount,tot_crit_med_buff_amount , buffer_allowed_yn , admin_auth_general_type_id, buffer_alloc_general_type_id
             INTO v_total_buffer_amount,v_total_med_buffer_amount,v_Tot_Crit_Buff_Amount,v_total_crit_corp_buff_amount,v_total_crit_med_buff_amount, v_buffer_allowed_yn, v_admin_auth_general_type_id, v_buffer_alloc_general_type_id;
        ELSIF v_buffer_mode_general_type_id = 'DED' THEN
          
          OPEN used_mem_buff_cur(v_policy_seq_id);
          FETCH used_mem_buff_cur INTO used_mem_buff_rec;
          CLOSE used_mem_buff_cur;         
         
                    
          UPDATE tpa_enr_policy A SET
            A.total_buffer_amount = NVL(total_buffer_amount,0) - nvl(v_buffer_amount ,0),
            A.Tot_Med_Buff_Amount = NVL(A.Tot_Med_Buff_Amount,0) - nvl(v_med_buff_amount,0),
            A.Tot_Crit_Buff_Amount = NVL(A.Tot_Crit_Buff_Amount,0) - nvl(v_critical_buff_amount,0),
            A.Tot_Crit_corp_Buff_Amount = NVL(A.Tot_Crit_corp_Buff_Amount,0) - nvl(v_critical_corp_buff_amount,0),
            a.tot_crit_med_buff_amount = nvl(a.tot_crit_med_buff_amount,0) - nvl(v_critical_med_buff_amount,0)
           WHERE policy_seq_id = v_policy_seq_id RETURNING total_buffer_amount,Tot_Med_Buff_Amount ,Tot_Crit_Buff_Amount,Tot_Crit_corp_Buff_Amount,tot_crit_med_buff_amount , buffer_allowed_yn , admin_auth_general_type_id, buffer_alloc_general_type_id
             INTO v_total_buffer_amount,v_total_med_buffer_amount,v_Tot_Crit_Buff_Amount,v_total_crit_corp_buff_amount,v_total_crit_med_buff_amount, v_buffer_allowed_yn, v_admin_auth_general_type_id, v_buffer_alloc_general_type_id;
          
          IF used_mem_buff_rec.used_mem_buff > NVL(v_total_buffer_amount,0) THEN
             v_alert:='You Cannot deduct the Normal corpus fund , As the amount is more than the Utilised Member Buffer of Normal Corpus fund.';
          ELSIF used_mem_buff_rec.used_mem_med_buff > NVL(v_total_med_buffer_amount,0)  THEN
            v_alert:='You Cannot deduct the Medical fund , As the amount is more than the Utilised Member Buffer of Normal Medical fund.';
          ELSIF used_mem_buff_rec.used_mem_crit_corp_buff > NVL(v_total_crit_corp_buff_amount,0) THEN
            v_alert:='You Cannot deduct the Critical corpus fund , As the amount is more than the Utilised Member Buffer of Critical Corpus fund.';
          ELSIF used_mem_buff_rec.used_mem_crit_med_buff > NVL(v_total_crit_med_buff_amount,0) THEN
            v_alert:='You Cannot deduct the Critical Medical fund , As the amount is more than the Utilised Member Buffer of Critical Medical fund.';
          ELSIF used_mem_buff_rec.used_mem_crit_buff > NVL(v_Tot_Crit_Buff_Amount,0) THEN
            v_alert:='You Cannot deduct the Critical illness fund , As the amount is more than the Utilised Member Buffer of Critical illness fund.';
          END IF; 
          
        END IF;

        IF v_total_buffer_amount < 0 THEN
          v_alert:='You Cannot deduct the Normal corpus fund , As the amount is more than the Available Normal Corpus fund.';
        ELSIF v_total_med_buffer_amount < 0  THEN
          v_alert:='You Cannot deduct the Medical fund , As the amount is more than the Available Medical fund.';
        ELSIF v_total_crit_corp_buff_amount < 0 THEN
          v_alert:='You Cannot deduct the Critical corpus fund , As the amount is more than the Available Critical Corpus fund.';
        ELSIF v_total_crit_med_buff_amount < 0 THEN
          v_alert:='You Cannot deduct the Critical Medical fund , As the amount is more than the Available Critical Medical fund.';
        ELSIF v_Tot_Crit_Buff_Amount <0 THEN
          v_alert:='You Cannot deduct the Critical illness fund , As the amount is more than the Available Critical illness fund.';
        END IF;
        
        IF v_alert is not null then
          rollback;
          return;
        END IF;

        IF (NVL( v_total_buffer_amount,0) = 0 AND v_buffer_alloc_amount > 0) OR 
          (NVL( v_total_med_buffer_amount,0) = 0 AND v_med_buff_alloc_amount > 0) OR
           (NVL( v_Tot_Crit_Buff_Amount,0) = 0 AND v_critical_buff_alloc_amount > 0) OR 
           (NVL( v_total_crit_med_buff_amount,0) = 0 AND v_critical_med_alloc_amount > 0) OR 
           (NVL( v_total_crit_corp_buff_amount,0) = 0 AND v_critical_corp_alloc_amount > 0)  
          THEN
          RAISE_APPLICATION_ERROR (-20692,'  Buffer amount is not entered/zero. ');
        END IF;

        IF NVl(v_buffer_alloc_amount,0) != 0 OR NVL( v_total_buffer_amount,0) != 0 OR 
          NVl(v_med_buff_alloc_amount,0) != 0 OR NVL( v_total_med_buffer_amount,0) != 0 OR 
          NVl(v_critical_corp_alloc_amount,0) != 0 OR NVL( v_total_crit_corp_buff_amount,0) != 0 OR
           NVl(v_critical_med_alloc_amount,0) != 0 OR NVL( v_total_crit_med_buff_amount,0) != 0 OR
           NVl(v_critical_buff_alloc_amount,0) != 0 OR NVL( v_Tot_Crit_Buff_Amount,0) != 0  THEN
          IF v_buffer_allowed_yn = 'N' OR v_admin_auth_general_type_id IS NULL OR v_buffer_alloc_general_type_id IS NULL THEN
            RAISE_APPLICATION_ERROR (-20097,'Buffer Information for this Policy is not entered');
          END IF;
        END IF;

        update_preath_n_claims (
                  v_policy_seq_id ,
                  v_buffer_alloc_amount ,
                  v_buffer_alloc_general_type_id ,
                  v_policy_sub_general_type_id ,
                  v_total_buffer_amount,
                  v_total_med_buffer_amount,
                  v_Tot_Crit_Buff_Amount,
                  v_total_crit_corp_buff_amount,
                  v_total_crit_med_buff_amount,
                  v_med_buff_alloc_amount,
                  v_critical_buff_alloc_amount,
                  v_critical_corp_alloc_amount,
                  v_critical_med_alloc_amount,
                  v_alert
                );

    END IF;
    
     IF v_alert is not null then 
       return;
     end if;
       
   /* IF v_buffer_alloc_amount > 0 OR v_med_buff_alloc_amount>0 OR 
      v_critical_corp_alloc_amount>0 OR v_critical_med_alloc_amount>0  OR
      v_critical_buff_alloc_amount >0 THEN    
  
*/     UPDATE tpa_enr_policy A SET
        a.buffer_alloc_amount = CASE WHEN v_buffer_alloc_amount>0 THEN CASE WHEN  v_total_buffer_amount<v_buffer_alloc_amount THEN v_total_buffer_amount ELSE   v_buffer_alloc_amount END ELSE CASE WHEN (v_total_buffer_amount< a.buffer_alloc_amount OR v_total_buffer_amount=v_buffer_alloc_amount)   THEN v_total_buffer_amount ELSE a.buffer_alloc_amount END END,
        a.med_buff_alloc_amount=CASE WHEN v_med_buff_alloc_amount>0 THEN CASE WHEN  v_total_med_buffer_amount<v_med_buff_alloc_amount THEN v_total_med_buffer_amount ELSE   v_med_buff_alloc_amount END ELSE CASE WHEN (v_total_med_buffer_amount< a.med_buff_alloc_amount OR v_total_med_buffer_amount=v_med_buff_alloc_amount)  THEN v_total_med_buffer_amount ELSE a.med_buff_alloc_amount END END,
        a.crit_corp_buff_alloc_amount=CASE WHEN v_critical_corp_alloc_amount>0 THEN CASE WHEN  v_total_crit_corp_buff_amount<v_critical_corp_alloc_amount THEN v_total_crit_corp_buff_amount ELSE   v_critical_corp_alloc_amount END ELSE CASE WHEN (v_total_crit_corp_buff_amount< a.crit_corp_buff_alloc_amount OR v_total_crit_corp_buff_amount=v_critical_corp_alloc_amount)  THEN v_total_crit_corp_buff_amount ELSE a.crit_corp_buff_alloc_amount END END,
        A.crit_med_buff_alloc_amount=CASE WHEN v_critical_med_alloc_amount>0 THEN CASE WHEN  v_total_crit_med_buff_amount<v_critical_med_alloc_amount THEN v_total_crit_med_buff_amount ELSE   v_critical_med_alloc_amount END ELSE CASE WHEN (v_total_crit_med_buff_amount< a.crit_med_buff_alloc_amount OR v_total_crit_med_buff_amount=v_critical_med_alloc_amount)  THEN v_total_crit_med_buff_amount ELSE a.crit_med_buff_alloc_amount END END,
        A.crit_buff_alloc_amount=CASE WHEN v_critical_buff_alloc_amount>0 THEN CASE WHEN  v_Tot_Crit_Buff_Amount<v_critical_buff_alloc_amount THEN v_Tot_Crit_Buff_Amount ELSE   v_critical_buff_alloc_amount END ELSE CASE WHEN (v_Tot_Crit_Buff_Amount< a.crit_buff_alloc_amount OR v_Tot_Crit_Buff_Amount=v_critical_buff_alloc_amount)  THEN v_Tot_Crit_Buff_Amount ELSE a.crit_buff_alloc_amount END END
        WHERE policy_seq_id = v_policy_seq_id;
    
      UPDATE tpa_enr_balance A SET
        a.buffer_amount = CASE WHEN v_buffer_alloc_amount>0 THEN CASE WHEN  v_total_buffer_amount<v_buffer_alloc_amount THEN v_total_buffer_amount ELSE   v_buffer_alloc_amount END ELSE CASE WHEN (v_total_buffer_amount< a.buffer_amount OR v_total_buffer_amount=v_buffer_alloc_amount)   THEN v_total_buffer_amount ELSE a.buffer_amount END END,
        a.med_buffer_amount=CASE WHEN v_med_buff_alloc_amount>0 THEN CASE WHEN  v_total_med_buffer_amount<v_med_buff_alloc_amount THEN v_total_med_buffer_amount ELSE   v_med_buff_alloc_amount END ELSE CASE WHEN (v_total_med_buffer_amount< a.med_buffer_amount OR v_total_med_buffer_amount=v_med_buff_alloc_amount)  THEN v_total_med_buffer_amount ELSE a.med_buffer_amount END END,
        a.Critical_Corp_Buff_Amount=CASE WHEN v_critical_corp_alloc_amount>0 THEN CASE WHEN  v_total_crit_corp_buff_amount<v_critical_corp_alloc_amount THEN v_total_crit_corp_buff_amount ELSE   v_critical_corp_alloc_amount END ELSE CASE WHEN (v_total_crit_corp_buff_amount< a.Critical_Corp_Buff_Amount OR v_total_crit_corp_buff_amount=v_critical_corp_alloc_amount)  THEN v_total_crit_corp_buff_amount ELSE a.Critical_Corp_Buff_Amount END END,
        A.Critical_Med_Buff_Amount=CASE WHEN v_critical_med_alloc_amount>0 THEN CASE WHEN  v_total_crit_med_buff_amount<v_critical_med_alloc_amount THEN v_total_crit_med_buff_amount ELSE   v_critical_med_alloc_amount END ELSE CASE WHEN (v_total_crit_med_buff_amount< a.Critical_Med_Buff_Amount OR v_total_crit_med_buff_amount=v_critical_med_alloc_amount)  THEN v_total_crit_med_buff_amount ELSE a.Critical_Med_Buff_Amount END END,
        A.CRITICAL_BUFF_AMOUNT=CASE WHEN v_critical_buff_alloc_amount>0 THEN CASE WHEN  v_Tot_Crit_Buff_Amount<v_critical_buff_alloc_amount THEN v_Tot_Crit_Buff_Amount ELSE   v_critical_buff_alloc_amount END ELSE CASE WHEN (v_Tot_Crit_Buff_Amount< a.CRITICAL_BUFF_AMOUNT OR v_Tot_Crit_Buff_Amount=v_critical_buff_alloc_amount)  THEN v_Tot_Crit_Buff_Amount ELSE a.CRITICAL_BUFF_AMOUNT END END
        WHERE a.policy_seq_id = v_policy_seq_id;
  /*  END IF;
*/
    v_rows_processed := SQL%ROWCOUNT;
    COMMIT;
  END save_buffer_details;

--============================================================================================================================
  PROCEDURE get_buffer_decription (
    v_prod_policy_seq_id                  IN  tpa_ins_prod_policy.prod_policy_seq_id%TYPE,
    result_set                            OUT SYS_REFCURSOR
  )
  IS
  BEGIN
    OPEN result_set FOR
      SELECT b.admin_auth_general_type_id , C.description AS authority,
             b.buffer_alloc_general_type_id , D.description AS allocation_descr
        FROM tpa_ins_prod_policy A JOIN tpa_enr_policy B ON (a.policy_seq_id = b.policy_seq_id)
        JOIN tpa_general_code C ON (B.Admin_Auth_General_Type_Id = c.general_type_id )
        JOIN tpa_general_code D ON (B.buffer_alloc_general_type_id = d.general_type_id )
        WHERE a.prod_policy_seq_id =  v_prod_policy_seq_id;
  END get_buffer_decription ;
--============================================================================================================================
  FUNCTION get_utilised_buffer_amount(
    v_policy_seq_id             IN  tpa_enr_policy.policy_seq_id%TYPE,
    v_policy_group_seq_id       IN  tpa_enr_policy_group.policy_group_seq_id%TYPE,
    v_member_seq_id             IN  tpa_enr_policy_member.member_seq_id%TYPE,
    v_buffer_type               IN  CHAR
  ) RETURN NUMBER
  IS
  v_utilised_buffer           NUMBER(12,2);     
  v_result_set           sys_refcursor;
  v_rec                  claims_pkg.buff_type;
  
  BEGIN
    
    IF v_member_seq_id IS NOT NULL THEN
      OPEN v_result_set FOR    SELECT
         SUM( nvl(a.Buff_App_Amt,b.Buff_App_Amt)) Buff_App_Amt,
         SUM(nvl(a.Med_Buff_App_Amt,b.Med_Buff_App_Amt)) Med_Buff_App_Amt,
         SUM(nvl(a.Crit_Buff_App_Amt,b.Crit_Buff_App_Amt)) Crit_Buff_App_Amt,
         SUM(nvl(a.Crit_Corp_Buff_App_Amt,b.Crit_Corp_Buff_App_Amt)) Crit_Corp_Buff_App_Amt,
         SUM(nvl(a.Crit_Med_Buff_App_Amt,b.Crit_Med_Buff_App_Amt))   Crit_Med_Buff_App_Amt 
        FROM
        ( SELECT a.pat_enroll_detail_seq_id ,d.Buff_App_Amt,d.Med_Buff_App_Amt,d.Crit_Buff_App_Amt,d.Crit_Corp_Buff_App_Amt,d.Crit_Med_Buff_App_Amt

         FROM  pat_enroll_details A JOIN pat_general_details B ON ( a.pat_enroll_detail_seq_id = b.pat_enroll_detail_seq_id AND b.pat_enhanced_yn = 'N')
         LEFT OUTER JOIN buffer_details c ON (B.last_buffer_detail_seq_id = c.buff_detail_seq_id)
         LEFT OUTER JOIN buffer_header d ON ( c.buffer_hdr_seq_id = d.buffer_hdr_seq_id )
         WHERE a.member_seq_id = v_member_seq_id
         
         AND ( b.completed_yn = 'N' OR ( a.pat_status_general_type_id ='APR' AND b.completed_yn = 'Y')))
         A FULL OUTER JOIN
         ( SELECT b.pat_enroll_detail_seq_id , d.Buff_App_Amt,d.Med_Buff_App_Amt,d.Crit_Buff_App_Amt,d.Crit_Corp_Buff_App_Amt,d.Crit_Med_Buff_App_Amt
          FROM  clm_enroll_details A JOIN clm_general_details B ON ( a.claim_seq_id = b.claim_seq_id )
         LEFT OUTER JOIN buffer_details c ON (B.last_buffer_detail_seq_id = c.buff_detail_seq_id)
         LEFT OUTER JOIN buffer_header d ON ( c.buffer_hdr_seq_id = d.buffer_hdr_seq_id )
         WHERE a.member_seq_id = v_member_seq_id            
         AND ( b.completed_yn = 'N' OR ( a.clm_status_general_type_id = 'APR' AND b.completed_yn = 'Y')))
          B ON (A.pat_enroll_detail_seq_id = B.pat_enroll_detail_seq_id ) ;


    ELSE
      OPEN v_result_set FOR  SELECT
         SUM( nvl(a.Buff_App_Amt,b.Buff_App_Amt)) Buff_App_Amt,
         SUM(nvl(a.Med_Buff_App_Amt,b.Med_Buff_App_Amt)) Med_Buff_App_Amt,
         SUM(nvl(a.Crit_Buff_App_Amt,b.Crit_Buff_App_Amt)) Crit_Buff_App_Amt,
         SUM(nvl(a.Crit_Corp_Buff_App_Amt,b.Crit_Corp_Buff_App_Amt)) Crit_Corp_Buff_App_Amt,
         SUM(nvl(a.Crit_Med_Buff_App_Amt,b.Crit_Med_Buff_App_Amt))   Crit_Med_Buff_App_Amt       
        FROM
        ( SELECT a.pat_enroll_detail_seq_id ,d.Buff_App_Amt,d.Med_Buff_App_Amt,d.Crit_Buff_App_Amt,d.Crit_Corp_Buff_App_Amt,d.Crit_Med_Buff_App_Amt
         FROM  pat_enroll_details A JOIN pat_general_details B ON ( a.pat_enroll_detail_seq_id = b.pat_enroll_detail_seq_id AND b.pat_enhanced_yn = 'N')
         LEFT OUTER JOIN buffer_details c ON (B.last_buffer_detail_seq_id = c.buff_detail_seq_id)
         LEFT OUTER JOIN buffer_header d ON ( c.buffer_hdr_seq_id = d.buffer_hdr_seq_id )
         JOIN tpa_enr_policy_member E ON (a.member_seq_id = E.member_seq_id AND e.deleted_yn = 'N' AND E.status_general_type_id != 'POC')
         WHERE E.policy_group_seq_id = v_policy_group_seq_id             
         AND ( b.completed_yn = 'N' OR ( a.pat_status_general_type_id ='APR' AND b.completed_yn = 'Y')) )
         A FULL OUTER JOIN
         ( SELECT b.pat_enroll_detail_seq_id , d.Buff_App_Amt,d.Med_Buff_App_Amt,d.Crit_Buff_App_Amt,d.Crit_Corp_Buff_App_Amt,d.Crit_Med_Buff_App_Amt 
         FROM  clm_enroll_details A JOIN clm_general_details B ON ( a.claim_seq_id = b.claim_seq_id )
         LEFT OUTER JOIN buffer_details c ON (B.last_buffer_detail_seq_id = c.buff_detail_seq_id)
         LEFT OUTER JOIN buffer_header d ON ( c.buffer_hdr_seq_id = d.buffer_hdr_seq_id )
         JOIN tpa_enr_policy_member E ON (a.member_seq_id = E.member_seq_id AND e.deleted_yn = 'N' AND E.status_general_type_id != 'POC')
         WHERE E.policy_group_seq_id = v_policy_group_seq_id                
         AND ( b.completed_yn = 'N' OR ( a.clm_status_general_type_id = 'APR' AND b.completed_yn = 'Y')))
          B ON (A.pat_enroll_detail_seq_id = B.pat_enroll_detail_seq_id ) ;

    END IF;
    
    FETCH v_result_set INTO v_rec;
    CLOSE v_result_set;
    IF v_buffer_type = 'COR' THEN
      v_utilised_buffer:=v_rec.buff_amt;
    ELSIF v_buffer_type = 'MED' THEN
      v_utilised_buffer:=v_rec.med_buff_amt;
    ELSIF v_buffer_type = 'CCRT' THEN
      v_utilised_buffer:=v_rec.crit_buff_amt;
    ELSIF v_buffer_type = 'CCOR' THEN
      v_utilised_buffer:=v_rec.crit_corp_buff_amt;
    ELSIF v_buffer_type = 'CMED' THEN
      v_utilised_buffer:=v_rec.crit_med_buff_amt;
    END IF;
    RETURN v_utilised_buffer;
    
  END get_utilised_buffer_amount;
--============================================================================================================================
--==========================================================================================
  PROCEDURE generate_renewal_members(
    v_policy_seq_id      IN VARCHAR2,
    results_set          OUT SYS_REFCURSOR
  )
  IS
    str_tab                    ttk_util_pkg.str_table_type;
  BEGIN
   str_tab      := ttk_util_pkg.parse_str ( v_policy_seq_id );
   
 OPEN results_set FOR 
  WITH renewal_mem AS (
     SELECT A.policy_number,
             B.employee_no,
             B.insured_name,
             C.tpa_enrollment_id,
             C.mem_name,
             D.relship_description,
             E.description as gender,
             --decode(a.POLICY_SUB_GENERAL_TYPE_ID,'PFL',B.FLOATER_SUM_INSURED,C.mem_tot_sum_insured) AS mem_tot_sum_insured,
             row_number() over (PARTITION BY B.employee_no ORDER BY C.tpa_enrollment_id) rk,-----alias change
             B.FLOATER_SUM_INSURED, --C.mem_tot_sum_insured AS mem_sum_insured, 
             a.POLICY_SUB_GENERAL_TYPE_ID,
             case when a.POLICY_SUB_GENERAL_TYPE_ID='PFL' and D.relship_description='Principal'  then K.SUM_INSURED else C.mem_tot_sum_insured end as mem_sum_insured,
             C.mem_age,
             TO_CHAR(C.mem_dob,'DD/MM/YYYY') as mem_dob,
             B.department,
             TO_CHAR(B.date_of_joining,'DD/MM/YYYY') as date_of_joining,
             C.photo_present_yn,
             F.address_1||F.address_2||F.address_3 as address,
             J.CITY_DESCRIPTION,
             --F.city_type_id,
             H.state_name,
             F.pin_code,
             ttk_util_pkg.fn_decrypt(G.bank_account_no) as bank_account_no, --//ED
             C.domicilary_limit,
             ttk_util_pkg.fn_decrypt(F.email_id) as email_id, --//ED
             ttk_util_pkg.fn_decrypt(F.mobile_no) as mobile_no, --//ED
             B.certificate_no,
             ttk_util_pkg.fn_decrypt(B.creditcard_no) as creditcard_no,--//ED
             to_char(C.date_of_inception,'DD/MM/YYYY') AS date_of_inception,
             to_char(C.date_of_exit,'DD/MM/YYYY') AS date_of_exit,
             C.member_remarks AS policy_remarks,
             B.tpa_enrollment_number,
             c.member_seq_id,
             case when C.MARITAL_STATUS_ID='MRD' THEN 'Married'
             ELSE 'Single' END AS M_STATUS,
             CASE  WHEN C.status_general_type_id = 'POA' THEN 'Active'
             ELSE 'Cancelled' end as status,
             to_char(A.ADDED_DATE,'DD/MM/YYYY'),
              to_char(C.CARD_PRN_DATE,'dd/mm/yyyy') as CARD_PRN_DATE,
             case when c.card_prn_count!=0 then 'Y' 
             ELSE 'N' END AS CARD_PRINTED,
             C.EMIRATE_ID,
             C.PASSPORT_NUMBER,
             N.DESCRIPTION,
             C.CARD_PRN_COUNT,
             gc.DESCRIPTION as network_type,
             to_char(C.ADDED_DATE,'dd/mm/yyyy') as adate,
			        C.VIP_YN,
              K.SUM_INSURED-K.utilised_sum_insured as AVA_SUM_INSURED,
              L.GROUP_NAME,
              co.country_name COUNTRY_ID,
               --F.COUNTRY_ID ,-------ADD FOR REPORT
             C.FAMILY_NAME, --------ADD FOR REPORT
             x.designation_description as DESIGNATION,   -------ADD FOR REPORT
             TO_CHAR(C.MEM_DOB_HIJRI,'DD/MM/YYYY') as MEM_DOB_HIJRI,  -------ADD FOR REPORT
             F.RESIDENCIAL_LOC,-------ADD FOR REPORT
             F.WORK_LOC,  -------ADD FOR REPORT
              c.mem_total_premium,
      (CASE WHEN c.gender_general_type_id = 'MAL' THEN (NVL(nvl(a.ip_op_premium_per_ind,a.pol_total_excmat_premium),0))
                  WHEN c.Gender_General_Type_Id = 'FEM' AND c.Marital_Status_Id ='MRD' 
                       AND c.MEM_AGE BETWEEN a.mat_premum_from_age AND a.mat_premum_to_age 
                       THEN (NVL(nvl(a.ip_op_premium_per_ind,a.pol_total_excmat_premium),0) + NVL(nvl(a.mat_premium_per_ind,a.pol_total_mat_premium),0))
                  ELSE (NVL(nvl(a.ip_op_premium_per_ind,a.pol_total_excmat_premium),0))  
                END) as annual_premium

      FROM TPA_ENR_POLICY A JOIN TPA_ENR_POLICY_GROUP B ON (A.Policy_Seq_Id = B.policy_seq_id)
      JOIN TPA_ENR_POLICY_MEMBER C ON (B.policy_group_seq_id = C.policy_group_seq_id)
      join tpa_group_registration l on (a.group_reg_seq_id=l.group_reg_seq_id)
      JOIN TPA_RELATIONSHIP_CODE D ON (C.relship_type_id=D.relship_type_id)
      JOIN TPA_GENERAL_CODE E ON (E.general_type_id=C.gender_general_type_id)
      LEFT OUTER JOIN TPA_ENR_MEM_ADDRESS F ON (F.enr_address_seq_id = c.enr_address_seq_id)
      LEFT OUTER JOIN TPA_ENR_BANK_DTLS G ON (G.bank_seq_id = b.bank_seq_id)
      LEFT OUTER JOIN TPA_STATE_CODE H ON (H.state_type_id=F.state_type_id)
      LEFT OUTER JOIN APP.TPA_CITY_CODE J ON (J.CITY_TYPE_ID=F.CITY_TYPE_ID)
      LEFT OUTER JOIN APP.TPA_NATIONALITIES_CODE N ON (N.NATIONALITY_ID=C.NATIONALITY_ID)
      left outer JOIN TPA_INS_PRODUCT TIP ON (a.PRODUCT_SEQ_ID=TIP.PRODUCT_SEQ_ID)
      left outer join tpa_general_code GC ON (GC.GENERAL_TYPE_ID=TIP.PRODUCT_CAT_TYPE_ID)
      left outer join tpa_designation_code x on (x.designation_type_id = b.designation)
      left outer join tpa_country_code co on(co.country_id = f.country_id)
      left outer JOIN app.tpa_enr_balance K ON (c.policy_group_seq_id=K.policy_group_seq_id)-- and CASE WHEN A.Policy_Sub_General_Type_Id= 'PNF' THEN C.MEMBER_SEQ_ID=K.MEMBER_SEQ_ID)
      WHERE A.enrol_type_id = 'COR'  
       and  (c.mem_general_type_id != 'PFL' AND c.member_seq_id = k.member_seq_id OR k.member_seq_id IS NULL OR c.member_seq_id IS NULL)
      AND A.policy_seq_id = str_tab(1)
      AND B.deleted_yn='N'
      AND C.deleted_yn='N'
      --AND C.status_general_type_id != 'POC'
      )

      --SELECT * FROM renewal_mem WHERE rec_number BETWEEN str_tab(2) AND str_tab(2)+9;--64999;
      SELECT b.*, CASE WHEN POLICY_SUB_GENERAL_TYPE_ID = 'PFL' AND rk = 1 THEN FLOATER_SUM_INSURED
                  ELSE mem_sum_insured END AS mem_tot_sum_insured,Q  rn FROM
        (SELECT A.*, DENSE_RANK() OVER (ORDER BY employee_no, MEMBER_SEQ_ID, ROWNUM)
           Q FROM renewal_mem A ) b WHERE Q>= str_tab(2) AND Q<= str_tab(3);

  END generate_renewal_members;
 --==============================================================================================
 --   Name       : SAVE_PROD_POLICY_CLAUSES
 --   Created on : 09-JUL-07
 --   Created By : S.V.Sreeraj
 --   Comments   : For saving condition clauses for a product or a group policy
 --   Rewrote   on : 30-jul-2007 -- S.V.Sreeraj as of chenge in table structure
 --==============================================================================================
   PROCEDURE save_prod_policy_clauses(
    v_clause_seq_id                      IN  OUT TPA_PROD_POLICY_CLAUSES.clause_seq_id%TYPE,
    v_prod_policy_seq_id                 IN  TPA_PROD_POLICY_CLAUSES.prod_policy_seq_id%TYPE,
    v_clause_yn                          IN  TPA_PROD_POLICY_CLAUSES.clause_yn%TYPE,
    v_clause_number                      IN  TPA_PROD_POLICY_CLAUSES.clause_number%TYPE,
    v_clause_description                 IN  TPA_PROD_POLICY_CLAUSES.clause_description%TYPE,
    v_added_by                           IN  TPA_PROD_POLICY_CLAUSES.added_by%TYPE,
    v_clause_type                        IN  TPA_PROD_POLICY_CLAUSES.clause_type%TYPE, --Added for koc1179
    v_clause_sub_type                    IN  TPA_PROD_POLICY_CLAUSES.clause_sub_type%TYPE,--Added for koc1179
    v_rows_processed                     IN  OUT NUMBER
  )
  IS
v_count       NUMBER(5); --Added for koc1179
  v_str         VARCHAR2(20); --Added for koc1179


cursor prev_clause_type_cur is --Added for koc1179
  select clause_type from  tpa_prod_policy_clauses a
      where a.clause_seq_id=v_clause_seq_id ;
prev_clause_type_rec prev_clause_type_cur%rowtype;

  BEGIN

--Added for koc1179
 SELECT COUNT(1) INTO v_count FROM tpa_prod_policy_clauses tpc
        WHERE tpc.clause_seq_id!=nvl(v_clause_seq_id ,0 ) AND tpc.prod_policy_seq_id=v_prod_policy_seq_id  and tpc.ACTIVE_YN='Y' AND tpc.clause_sub_type=v_clause_sub_type;

   IF v_clause_type='SRT' AND nvl(v_clause_seq_id ,0 )=0 AND v_count>0 THEN
        raise_application_error(-20859,'Already Clause Number associated with this shortfall Clause SubType ');
    ELSIF  v_clause_type='SRT'  AND v_count>0 and v_clause_seq_id>0 THEN
        raise_application_error(-20861,'Modification of Clause/Clause Subtype not allowed.');
   END IF;
--Added for koc1179

    IF nvl(v_clause_seq_id ,0 ) = 0  THEN
      INSERT INTO tpa_prod_policy_clauses(
        clause_seq_id,
        prod_policy_seq_id,
        clause_yn,
        clause_number,
        clause_description,
        active_yn,
        added_by,
        added_date ,
        clause_type,--Added for koc1179
        clause_sub_type)--Added for koc1179
      VALUES (
        tpa_prod_policy_clauses_seq.NEXTVAL,
        v_prod_policy_seq_id,
        v_clause_yn,
        v_clause_number,
        v_clause_description,
        'Y',
        v_added_by,
        SYSDATE ,
        v_clause_type, --Added for koc1179
        v_clause_sub_type) --Added for koc1179
      RETURNING clause_seq_id INTO v_clause_seq_id;

    ELSE
--Added for koc1179
    open  prev_clause_type_cur;
    fetch prev_clause_type_cur into prev_clause_type_rec;
    close prev_clause_type_cur;

  IF prev_clause_type_rec.CLAUSE_TYPE!=v_clause_type then
   raise_application_error(-20861,'Modification of Clause/Clause Subtype not allowed.');
 END IF;
--Added for koc1179

      UPDATE tpa_prod_policy_clauses SET
        clause_yn                               = v_clause_yn,
        clause_number                           = v_clause_number,
        clause_description                      = v_clause_description,
        updated_by                              = v_added_by,
        updated_date                            = SYSDATE,
        clause_type                             = v_clause_type, --Added for koc1179
        clause_sub_type                         = v_clause_sub_type--Added for koc1179
        WHERE clause_seq_id = v_clause_seq_id;
    END IF;
    v_rows_processed := SQL%ROWCOUNT;
    COMMIT;
  END save_prod_policy_clauses;
 --==============================================================================================
 --   Name       : SAVE_PROD_POLICY_CLAUSES
 --   Created on : 09-JUL-07
 --   Created By : S.V.Sreeraj
 --   Comments   : For saving condition clauses for a product or a group policy
 --==============================================================================================
 PROCEDURE select_prod_policy_clauses (
    v_prod_policy_seq_id                 IN  TPA_PROD_POLICY_CLAUSES.prod_policy_seq_id%TYPE,
    v_identifier                         IN VARCHAR2,
    v_resultset                          OUT SYS_REFCURSOR
  )
  IS
  BEGIN
    IF v_identifier = 'Clause' THEN
      OPEN v_resultset FOR
      SELECT
        a.clause_seq_id,
        a.clause_yn,
        a.clause_number,
        a.clause_description,
        a.prod_policy_seq_id,
        a.active_yn,
        NVL(b.description,'Others') AS  clause_type,  --Added for koc1179
        C.description AS  clause_sub_type_desc,  --Added for koc1179
        a.clause_sub_type  --Added for koc1179

        FROM tpa_prod_policy_clauses a
        LEFT OUTER JOIN tpa_general_code b ON(a.clause_type=b.general_type_id) --Added for koc1179
        LEFT OUTER JOIN tpa_general_code c ON(a.clause_sub_type=c.general_type_id) --Added for koc1179
        WHERE a.prod_policy_seq_id = v_prod_policy_seq_id AND a.active_yn = 'Y'
        AND a.clause_yn='Y'
        ORDER BY a.clause_number;
    ELSE
        OPEN v_resultset FOR
      SELECT
        a.clause_seq_id,
        a.clause_yn,
        a.clause_number,
        a.clause_description,
        a.prod_policy_seq_id,
        a.active_yn
        FROM tpa_prod_policy_clauses a
        WHERE a.prod_policy_seq_id = v_prod_policy_seq_id AND a.active_yn = 'Y'
        AND a.clause_yn='N'
        ORDER BY a.clause_number;
    END IF;

  END select_prod_policy_clauses;
 --==============================================================================================
 PROCEDURE delete_clauses (
    v_seq_ids                            IN  VARCHAR2,
    v_added_by                           IN  NUMBER,
    v_rows_processed                     IN  OUT NUMBER
  )
  IS
    v_ctr                      NUMBER(3);
    str_tab                    ttk_util_pkg.str_table_type;

 --Added for koc1179
cursor clause_type_cur(v_clause_seq_id number) is
    select clause_type from TPA_PROD_POLICY_CLAUSES a
    where a.CLAUSE_SEQ_ID=v_clause_seq_id;
clause_type_rec clause_type_cur%rowtype;
  --Added for koc1179

  BEGIN

--Added for koc1179

 str_tab      := ttk_util_pkg.parse_str ( v_seq_ids );

for i in str_tab.first..str_tab.last
loop

open clause_type_cur(str_tab(i));
fetch clause_type_cur into clause_type_rec;
close clause_type_cur;

if clause_type_rec.CLAUSE_TYPE='SRT' THEN
RAISE_APPLICATION_ERROR(-20860,'Configuared shortfall clauses Cannot be deleted.');
end if;

end loop;
--Added for koc1179

  forall i in str_tab.first..str_tab.last --Modified for koc1179
  update tpa_prod_policy_clauses a
  set   a.active_yn  = 'N',
        a.updated_by = v_added_by ,
        a.UPDATED_DATE = sysdate
  where a.clause_seq_id =str_tab(i);

  /*  EXECUTE IMMEDIATE ' UPDATE tpa_prod_policy_clauses A SET
      a.active_yn  = ''N'',
      a.updated_by = '||v_added_by ||',
      a.added_date = SYSDATE
      WHERE a.clause_seq_id IN (' || REPLACE(substr(v_seq_ids,2,length(v_seq_ids)-2 ), '|',',') ||')';
 */
  COMMIT;
  END delete_clauses;
 --==============================================================================================
  PROCEDURE update_finance_status( v_seq_id IN NUMBER, v_flag  IN VARCHAR2 , v_added_by  IN NUMBER )
  IS
  BEGIN
    IF v_flag = 'POL' THEN
      UPDATE tpa_claims_payment r SET
        r.claim_payment_status = 'PENDING',
        r.updated_by           = v_added_by,
        r.updated_date         = SYSDATE
        WHERE r.payment_seq_id IN ( SELECT a.payment_seq_id FROM tpa_claims_payment a JOIN clm_enroll_details b ON (a.claim_seq_id = b.claim_seq_id)
                                     WHERE a.claim_payment_status = 'VOUCHER PENDING'
                                     AND b.policy_seq_id = v_seq_id );

    ELSE
      UPDATE tpa_claims_payment r SET
        r.claim_payment_status = 'PENDING',
        r.updated_by           = v_added_by,
        r.updated_date         = SYSDATE
        WHERE r.payment_seq_id IN ( SELECT a.payment_seq_id FROM tpa_claims_payment a JOIN clm_enroll_details b ON (a.claim_seq_id = b.claim_seq_id)
                                     JOIN tpa_enr_policy c ON (b.policy_seq_id = c.policy_seq_id)
                                     WHERE a.claim_payment_status = 'VOUCHER PENDING'
                                     AND c.product_seq_id = v_seq_id AND c.enrol_type_id != 'COR');
    END IF;
  END update_finance_status;

--==============================================================================================
  PROCEDURE update_preath_n_claims(
    v_policy_seq_id                   IN tpa_enr_policy.policy_seq_id%TYPE ,
    v_buffer_alloc_amount             IN tpa_enr_policy.buffer_alloc_amount%TYPE,
    v_buffer_alloc_gen_type_id        IN tpa_enr_policy.buffer_alloc_general_type_id%TYPE ,
    v_policy_sub_general_type_id      IN tpa_enr_policy.policy_sub_general_type_id%TYPE,
    v_total_buffer_amount             IN TPA_ENR_POLICY.total_buffer_amount%TYPE := NULL,
    v_total_med_buffer_amount         IN TPA_ENR_POLICY.Tot_Med_Buff_Amount%TYPE := NULL,
    v_tot_crit_buffer_amount          IN TPA_ENR_POLICY.Tot_Crit_Buff_Amount%TYPE := NULL,
    v_total_crit_corp_buff_amount     IN TPA_ENR_POLICY.Tot_Crit_corp_Buff_Amount%TYPE := NULL,
    v_total_crit_med_buff_amount      IN  TPA_ENR_POLICY.TOT_CRIT_MED_BUFF_AMOUNT%TYPE := NULL ,
    v_med_buffer_alloc_amount         IN TPA_ENR_POLICY.Med_Buff_Alloc_Amount%TYPE := NULL,
    v_critical_buffer_alloc_amount    IN TPA_ENR_POLICY.crit_buff_alloc_amount%TYPE := NULL,
    v_critical_corp_alloc_amount      IN TPA_ENR_POLICY.crit_corp_buff_alloc_amount%TYPE := NULL    ,
    v_critical_med_alloc_amount       IN TPA_ENR_POLICY.crit_med_buff_alloc_amount%TYPE := NULL ,
    v_alert                           OUT VARCHAR2
  )
  IS
    CURSOR general_buffer_cur IS
      SELECT COUNT(1) FROM
       ( SELECT MAX(a.utilised_buff_amount) utilised_buff_amount,MAX(a.Utilised_Med_Buff_Amount) Utilised_Med_Buff_Amount,MAX(a.utilised_crit_corp_buff_amt) Utilised_Crit_corp_Buff_Amount,MAX(a.utilised_crit_med_buff_amt) Utilised_Crit_med_Buff_Amount,
          MAX(A.UTILISED_CRIT_BUFF_AMOUNT) UTILISED_CRIT_BUFF_AMOUNT
          FROM tpa_enr_balance a WHERE a.policy_seq_id = v_policy_seq_id
          GROUP BY a.policy_group_seq_id ) b
          WHERE ((b.utilised_buff_amount > nvl(v_buffer_alloc_amount,0) AND nvl(v_buffer_alloc_amount,0)>0) OR
                (b.Utilised_Med_Buff_Amount> nvl(v_med_buffer_alloc_amount,0) AND  nvl(v_med_buffer_alloc_amount,0)>0 ) OR
                (b.Utilised_Crit_corp_Buff_Amount > nvl(v_critical_corp_alloc_amount,0) AND nvl(v_critical_corp_alloc_amount,0)>0) OR
                (b.Utilised_Crit_med_Buff_Amount > nvl(v_critical_med_alloc_amount,0) AND nvl(v_critical_med_alloc_amount,0)>0) OR
                (b.Utilised_Crit_Buff_Amount > nvl(v_critical_buffer_alloc_amount,0) AND nvl(v_critical_buffer_alloc_amount,0)>0));

    CURSOR individual_buffer IS
      SELECT COUNT(1) FROM tpa_enr_balance A
            WHERE A.policy_seq_id = v_policy_seq_id
            AND  ((A.utilised_buff_amount > nvl(v_buffer_alloc_amount,0) AND nvl(v_buffer_alloc_amount,0)>0) OR
                (A.Utilised_Med_Buff_Amount> nvl(v_med_buffer_alloc_amount,0) AND  nvl(v_med_buffer_alloc_amount,0)>0 ) OR
                (A.UTILISED_CRIT_CORP_BUFF_AMT > nvl(v_critical_corp_alloc_amount,0) AND nvl(v_critical_corp_alloc_amount,0)>0) OR
                (A.UTILISED_CRIT_MED_BUFF_AMT > nvl(v_critical_med_alloc_amount,0) AND nvl(v_critical_med_alloc_amount,0)>0) OR
                (A.Utilised_Crit_Buff_Amount > nvl(v_critical_buffer_alloc_amount,0) AND nvl(v_critical_buffer_alloc_amount,0)>0));

    CURSOR general_total_cur IS
      ( SELECT SUM(a.utilised_buff_amount),SUM(a.Utilised_Med_Buff_Amount),SUM(a.utilised_crit_corp_buff_amt) ,SUM(a.utilised_crit_med_buff_amt) ,SUM(A.UTILISED_CRIT_BUFF_AMOUNT)
      FROM tpa_enr_balance a WHERE a.policy_seq_id = v_policy_seq_id ) ;

    CURSOR non_floater_total_buffer IS
      SELECT SUM(b.utilised_buff_amount) ,SUM(b.utilised_med_buff_amount) ,SUM(b.utilised_crit_corp_buff_amt),SUM(b.utilised_crit_med_buff_amt),SUM(B.UTILISED_CRIT_BUFF_AMOUNT) FROM
      ( SELECT DISTINCT a.policy_group_seq_id, a.utilised_buff_amount,a.utilised_med_buff_amount,a.utilised_crit_corp_buff_amt,a.utilised_crit_med_buff_amt,A.UTILISED_CRIT_BUFF_AMOUNT
        FROM tpa_enr_balance a WHERE a.policy_seq_id = v_policy_seq_id) B;
    v_used_buffer_amount              	             NUMBER(12,2);
    v_used_med_buffer_amount                         NUMBER(12,2);
    v_used_crit_corp_buffer_amount                   NUMBER(12,2);
    v_used_crit_med_buffer_amount                    NUMBER(12,2);
    v_used_crit_buffer_amount                        NUMBER(12,2);
    v_ctr              NUMBER(12,2);
    
    CURSOR bal_cur(v_policy_seq_id tpa_enr_balance.policy_seq_id%type) IS 
    SELECT nvl(a.buffer_amount,0) buffer_amount,nvl(a.med_buffer_amount,0) med_buffer_amount,nvl(a.critical_buff_amount,0) critical_buff_amount,nvl(a.critical_corp_buff_amount,0) critical_corp_buff_amount,nvl(a.critical_med_buff_amount,0) critical_med_buff_amount,
           nvl(a.utilised_buff_amount,0) utilised_buff_amount,nvl(a.utilised_med_buff_amount,0) utilised_med_buff_amount,nvl(a.utilised_crit_buff_amount,0) utilised_crit_buff_amount,nvl(a.utilised_crit_corp_buff_amt,0) utilised_crit_corp_buff_amt,nvl(a.utilised_crit_med_buff_amt,0) utilised_crit_med_buff_amt
           FROM tpa_enr_balance a
    where a.policy_seq_id=v_policy_seq_id
    order by a.policy_group_seq_id ;
    
    bal_rec  bal_cur%ROWTYPE;

  BEGIN
    IF v_buffer_alloc_amount > 0 OR v_med_buffer_alloc_amount>0 OR 
       v_critical_buffer_alloc_amount>0 OR v_critical_corp_alloc_amount>0 OR
       v_critical_med_alloc_amount>0 THEN
       
     FOR bal_rec IN bal_cur(v_policy_seq_id) LOOP
       IF v_buffer_alloc_amount > 0 AND bal_rec.Buffer_Amount>nvl(v_buffer_alloc_amount,0) AND bal_rec.Utilised_Buff_Amount>nvl(v_buffer_alloc_amount,0) THEN
         v_alert:='You cannot reduce the Normal Corpus Buffer Limit per Family/Individual, as the amount is less than the  Utilised Normal Corpus Buffer per Family/Individual.';
       ELSIF  v_med_buffer_alloc_amount>0 AND  bal_rec.med_buffer_amount>nvl(v_med_buffer_alloc_amount,0) AND bal_rec.utilised_med_buff_amount>nvl(v_med_buffer_alloc_amount,0) THEN
         v_alert:='You cannot reduce the Normal Medical Buffer Limit per Family/Individual, as the amount is less than the  Utilised Normal Medical Buffer per Family/Individual.';
       ELSIF v_critical_buffer_alloc_amount>0 AND   bal_rec.critical_buff_amount>nvl(v_critical_buffer_alloc_amount,0) AND bal_rec.utilised_crit_buff_amount>nvl(v_critical_buffer_alloc_amount,0) THEN
         v_alert:='You cannot reduce the Critical illness Buffer Limit per Family/Individual, as the amount is less than the  Utilised Critical illness Buffer per Family/Individual.';
       ELSIF v_critical_corp_alloc_amount>0 AND   bal_rec.critical_corp_buff_amount>nvl(v_critical_corp_alloc_amount,0) AND bal_rec.utilised_crit_corp_buff_amt>nvl(v_critical_corp_alloc_amount,0) THEN
         v_alert:='You cannot reduce the Critical Corpus Buffer Limit per Family/Individual, as the amount is less than the  Utilised Critical Corpus Buffer per Family/Individual.';
       ELSIF v_critical_med_alloc_amount>0 AND   bal_rec.critical_med_buff_amount>nvl(v_critical_med_alloc_amount,0) AND bal_rec.utilised_crit_med_buff_amt>nvl(v_critical_med_alloc_amount,0) THEN
         v_alert:='You cannot reduce the Critical Medical Buffer Limit per Family/Individual, as the amount is less than the  Utilised Critical Medical Buffer per Family/Individual.';
       END IF;
     IF v_alert is not null then
          rollback;
          return;
     END IF;
     END LOOP;
     
     
     
      IF v_buffer_alloc_gen_type_id = 'BAI' THEN
        OPEN  individual_buffer ;
        FETCH individual_buffer INTO v_ctr;
        CLOSE individual_buffer;
      ELSE
        OPEN general_buffer_cur ;
        FETCH general_buffer_cur INTO v_ctr;
        CLOSE general_buffer_cur;
      END IF;

      IF v_ctr > 0  THEN
        raise_application_error(-20145,'Buffer utilised amount exceeds the total buffer amount.');
      END IF;
    END IF;
          
    IF v_total_buffer_amount IS NOT NULL OR v_total_med_buffer_amount IS NOT NULL OR v_total_crit_corp_buff_amount IS NOT NULL OR v_total_crit_med_buff_amount IS NOT NULL  THEN
       IF v_policy_sub_general_type_id != 'PFL' AND v_buffer_alloc_gen_type_id = 'BAF' THEN
          OPEN non_floater_total_buffer ;
          FETCH non_floater_total_buffer INTO v_used_buffer_amount,v_used_med_buffer_amount,v_used_crit_corp_buffer_amount,v_used_crit_med_buffer_amount,v_used_crit_buffer_amount;
          CLOSE non_floater_total_buffer;
       ELSE
          OPEN general_total_cur ;
          FETCH general_total_cur INTO v_used_buffer_amount,v_used_med_buffer_amount,v_used_crit_corp_buffer_amount,v_used_crit_med_buffer_amount,v_used_crit_buffer_amount;
          CLOSE general_total_cur;
       END IF;
       IF NVL(v_used_buffer_amount,0) > v_total_buffer_amount OR  
          NVL(v_used_med_buffer_amount,0) > v_total_med_buffer_amount   OR  
          NVL(v_used_crit_corp_buffer_amount,0) > v_total_crit_corp_buff_amount   OR  
          NVL(v_used_crit_med_buffer_amount,0) > v_total_crit_med_buff_amount  OR  
          NVL(v_used_crit_buffer_amount,0) > v_tot_crit_buffer_amount THEN
          raise_application_error(-20145,'Buffer utilised amount exceeds the total buffer amount.');
       END IF;
    END IF;

  END update_preath_n_claims;

--==============================================================================================
  -- Author  : Ramakrishna K M
  -- Created : 24/12/2007
  -- Purpose : Used in Adminsitration-.Policies->WebConfig->Web Login Links List
  --===============================================================================
  PROCEDURE select_weblogin_link_list(
    v_prod_policy_seq_id                IN   tpa_ins_prod_policy.prod_policy_seq_id%TYPE,
    v_sort_var                          IN   VARCHAR2,
    v_sort_order                        IN   VARCHAR2,
    v_start_num                         IN   NUMBER,
    v_end_num                           IN   NUMBER,
    v_added_by                          IN   NUMBER,
    result_set                          OUT  SYS_REFCURSOR
  )
  IS
    v_sql_str   VARCHAR2 (4000);
  BEGIN
    --diaplay only non logically deleted records
    v_sql_str :=
      'SELECT A.weblink_seq_id,
             A.link_description,
             B.description AS TYPE,
             A.link_order_number
          FROM weblogin_links A LEFT OUTER JOIN tpa_general_code B ON (A.link_general_type_id = B.general_type_id)
          WHERE A.prod_policy_seq_id = :v_prod_policy_seq_id';

    v_sql_str :='SELECT * FROM
                    (SELECT A.*,DENSE_RANK() OVER (ORDER BY '|| v_sort_var|| ' '|| v_sort_order|| ',ROWNUM)
                      Q FROM ('|| v_sql_str|| ') A ) WHERE  Q>= :v_start_num  AND Q<= :v_end_num ';

    OPEN result_set FOR v_sql_str USING v_prod_policy_seq_id,v_start_num, v_end_num ;
  END select_weblogin_link_list;
--===========================================================================================
  -- Author  : Ramakrishna K M
  -- Created : 24/12/2007
  -- Purpose : Used in Adminsitration-.Policies->WebConfig->Web Login Links Details

--===============================================================================
 PROCEDURE select_weblogin_link_details(
    v_weblink_seq_id                  IN  weblogin_links.weblink_seq_id%TYPE,
    result_set                        OUT SYS_REFCURSOR
  )
  IS
  BEGIN
    OPEN result_set FOR
      SELECT A.weblink_seq_id,
             A.show_web_link_yn,
             A.link_description,
             A.link_general_type_id,
             A.link_order_number,
             A.link_path,
             A.pre_report_general_type_id
          FROM weblogin_links A
          WHERE A.weblink_seq_id = v_weblink_seq_id;
  END select_weblogin_link_details;

--==============================================================================================
-- Author  : Ramakrishna K M
  -- Created : 24/12/2007
  -- Purpose : Used in Adminsitration-.Policies->WebConfig->Web Login Links Save
  --===============================================================================
  PROCEDURE save_weblogin_link_details(
    v_weblink_seq_id                  IN  OUT weblogin_links.weblink_seq_id%TYPE,
    v_prod_policy_seq_id              IN  tpa_ins_prod_policy.prod_policy_seq_id%TYPE,
    v_show_web_link_yn                IN  weblogin_links.show_web_link_yn%TYPE,
    v_link_description                IN  weblogin_links.link_description%TYPE,
    v_link_general_type_id            IN  weblogin_links.link_general_type_id%TYPE,
    v_link_order_number               IN  weblogin_links.link_order_number%TYPE,
    v_link_path                       IN  weblogin_links.link_path%TYPE,
    v_pre_report_general_type_id      IN  weblogin_links.pre_report_general_type_id%TYPE,
    v_added_by                        IN  NUMBER,
    v_rows_processed                  OUT INTEGER
  )
  IS
    v_ctr_logo                        NUMBER(1);
    v_ctr_comp                        NUMBER(1);
    v_ctr_comp_text                   NUMBER(1);
    v_ctr_comp_image                   NUMBER(1);
  BEGIN

       IF v_link_general_type_id = 'WLG' THEN
         SELECT COUNT(1) INTO v_ctr_logo
         FROM weblogin_links A
         WHERE A.Prod_Policy_Seq_Id = v_prod_policy_seq_id
         AND A.WEBLINK_SEQ_ID != v_weblink_seq_id
         AND A.LINK_GENERAL_TYPE_ID = 'WLG';
       END IF;

       IF v_link_general_type_id = 'WLC' THEN
         SELECT COUNT(1) INTO v_ctr_comp
         FROM weblogin_links A
         WHERE A.Prod_Policy_Seq_Id = v_prod_policy_seq_id
         AND A.WEBLINK_SEQ_ID != v_weblink_seq_id
         AND A.LINK_GENERAL_TYPE_ID = 'WLC';
       END IF;

       IF v_link_general_type_id = 'WCT' THEN
         SELECT COUNT(1) INTO v_ctr_comp_text
         FROM weblogin_links A
         WHERE A.Prod_Policy_Seq_Id = v_prod_policy_seq_id
         AND A.WEBLINK_SEQ_ID != v_weblink_seq_id
         AND A.LINK_GENERAL_TYPE_ID = 'WCT';
       END IF;

       IF v_link_general_type_id = 'WCT' OR v_link_general_type_id = 'WLC' THEN
         SELECT COUNT(1) INTO v_ctr_comp_image
         FROM weblogin_links A
         WHERE A.Prod_Policy_Seq_Id = v_prod_policy_seq_id
         AND A.WEBLINK_SEQ_ID != v_weblink_seq_id
         AND A.LINK_GENERAL_TYPE_ID IN('WCT','WLC') ;
       END IF;

       IF v_ctr_logo > 0 THEN
        raise_application_error(-20551, ' Logo/CompanyName/Company Text already exists. ' );
      END IF;

      IF v_ctr_comp > 0 THEN
        raise_application_error(-20551, ' Logo/CompanyName/Company Text already exists. ' );
      END IF;

      IF v_ctr_comp_text > 0 THEN
        raise_application_error(-20551, ' Logo/CompanyName/Company Text already exists. ' );
      END IF;

      IF v_ctr_comp_image > 0 THEN
        raise_application_error(-20677, 'Company Name Image/Company Name Text already exists. ' );
      END IF;

       IF v_weblink_seq_id = 0 THEN
         INSERT INTO weblogin_links(
           weblink_seq_id,
           prod_policy_seq_id,
           show_web_link_yn,
           link_description,
           link_general_type_id,
           link_order_number,
           link_path,
           pre_report_general_type_id,
           added_by,
           added_date)
         VALUES(
           weblogin_links_seq.nextval,
           v_prod_policy_seq_id,
           v_show_web_link_yn,
           v_link_description,
           v_link_general_type_id,
           v_link_order_number,
           v_link_path,
           v_pre_report_general_type_id,
           v_added_by,
           SYSDATE ) RETURNING weblink_seq_id INTO v_weblink_seq_id;
       ELSE
           UPDATE weblogin_links SET
            show_web_link_yn           = v_show_web_link_yn,
            link_description           = v_link_description,
            link_general_type_id       = v_link_general_type_id,
            link_order_number          = v_link_order_number,
            link_path                  = v_link_path,
            pre_report_general_type_id = v_pre_report_general_type_id,
            updated_by                 = v_added_by,
            updated_date               = SYSDATE
        WHERE weblink_seq_id = v_weblink_seq_id AND prod_policy_seq_id = v_prod_policy_seq_id;
       END IF;
       v_rows_processed := SQL%ROWCOUNT;
       COMMIT;
  END save_weblogin_link_details;
  --===============================================================================
  -- Author  : Ramakrishna K M
  -- Created : 24/12/2007
  -- Purpose : Used in Adminsitration-.Policies->WebConfig->Web Login Links Delete
  --===============================================================================
  PROCEDURE weblogin_link_delete (
      v_weblink_seq_id                IN  VARCHAR2, -- conacatenated string of weblink seq id |seq_id1|seq_id1|....|
      v_added_by                      IN  NUMBER,
      v_rows_processed                OUT INTEGER
   )
   IS
    str_tab                    ttk_util_pkg.str_table_type;
  BEGIN
    str_tab := ttk_util_pkg.parse_str (v_weblink_seq_id);
    FOR i IN str_tab.FIRST .. str_tab.LAST
    LOOP
        DELETE FROM weblogin_links WHERE weblink_seq_id = TO_NUMBER (str_tab (i));
    END LOOP;
      --returns no.. of rows updated/inserted
    v_rows_processed := str_tab.LAST;
    COMMIT;
  END weblogin_link_delete;
 /*==============================================================================================
    Name       : SAVE_WEBLOGIN_CONFIG
    Created on : 03-JAN-08
    Created By : S.V.Sreeraj.
    Comments   : Administration - >policies ->web config
    modified by : Ravi for KOC1160
 ============================================================================================== */
  PROCEDURE save_weblogin_config(
    v_webconfig_seq_id                   IN  OUT WEBLOGIN_CONFIG.webconfig_seq_id%TYPE,
    v_prod_policy_seq_id                 IN  WEBLOGIN_CONFIG.prod_policy_seq_id%TYPE,
    v_policy_seq_id                      IN  WEBLOGIN_CONFIG.policy_seq_id%TYPE,
    v_modification_allowed_days          IN  WEBLOGIN_CONFIG.modification_allowed_days%TYPE,
    v_grp_cnt_add_general_type_id        IN  WEBLOGIN_CONFIG.grp_cnt_add_general_type_id%TYPE,
    v_emp_add_general_type_id            IN  WEBLOGIN_CONFIG.emp_add_general_type_id%TYPE,
    v_policy_default_sum_insured         IN  WEBLOGIN_CONFIG.policy_default_sum_insured%TYPE,
    v_opd_limit_sum_insured              IN  WEBLOGIN_CONFIG.opd_limit_sum_insured%TYPE,
    v_inception_date_gen_type_id         IN  WEBLOGIN_CONFIG.inception_date_general_type_id%TYPE,
    v_add_sum_ins_general_type_id        IN  WEBLOGIN_CONFIG.add_sum_ins_general_type_id%TYPE,
    v_grp_cnt_cancel_gen_type_id         IN  WEBLOGIN_CONFIG.grp_cnt_cancel_general_type_id%TYPE,
    v_soft_upl_general_type_id           IN  WEBLOGIN_CONFIG.soft_upl_general_type_id%TYPE,
    v_added_by                           IN  WEBLOGIN_CONFIG.added_by%TYPE,
    v_send_mail_general_type_id          IN  WEBLOGIN_CONFIG.send_mail_general_type_id%TYPE,
    v_pwd_general_type_id                IN  WEBLOGIN_CONFIG.pwd_general_type_id%TYPE,
    v_window_period                      IN  WEBLOGIN_CONFIG.window_period%TYPE,
    v_mail_general_type_id               IN  WEBLOGIN_CONFIG.mail_general_type_id%TYPE,
    v_int_access_gen_type_id             IN  WEBLOGIN_CONFIG.intimation_access_gen_type_id%TYPE,
    v_notification_details               IN  WEBLOGIN_CONFIG.notification_details%TYPE,
    v_report_from                        IN  WEBLOGIN_CONFIG.report_from%TYPE,
    v_report_to                          IN  WEBLOGIN_CONFIG.report_to%TYPE,
    v_online_ass_gen_type_id             IN  WEBLOGIN_CONFIG.online_assistance_gen_type_id%TYPE,
    v_Password_Validity                  IN  WEBLOGIN_CONFIG.password_validity%TYPE,
    v_Show_Allert_Days                   IN  WEBLOGIN_CONFIG.show_allert_days%TYPE,
    v_online_rating_gen_type_id          IN  WEBLOGIN_CONFIG.online_rating_gen_type_id%TYPE,
    v_relship_comb_gen_type_id           IN  WEBLOGIN_CONFIG.relship_comb_gen_type_id%TYPE,--FOR KOC1084 CR
    v_first_login_window_period          IN  WEBLOGIN_CONFIG.first_login_window_period%TYPE,--FOR KOC1091 CR
    v_delete_time_frame                  IN weblogin_config.deletion_time_frame%TYPE, --koc1160
    v_inlaws_count                       IN weblogin_config.inlaws_count%TYPE, --koc1160
    v_opt_general_type_id                IN  CHAR,  --KOC1216
    V_DEFAULT_PREMIUM                    IN  NUMBER, --KOC1216
    V_WRONG_ATTEMPTS                     IN WEBLOGIN_CONFIG.WRONG_ATTEMPTS%TYPE,      --KOC1257
    v_wellness_login_type_id             IN weblogin_config.wellness_login_type_id%TYPE,--KOC1349
    v_gen_type_id                        IN weblogin_config.gen_type_id%type,
	v_rows_processed                     IN  OUT NUMBER


  )
  IS
    CURSOR policy_cur IS SELECT a.domicilary_general_type_id, a.effective_to_date, a.currently_uploading_yn
       FROM tpa_enr_policy a
       WHERE a.policy_seq_id = v_policy_seq_id;

    policy_rec                            policy_cur%ROWTYPE;

  BEGIN
    OPEN policy_cur;
    FETCH policy_cur INTO policy_rec;
    CLOSE policy_cur;

    -- check any uploading happening now.
    policy_enrollment_pkg.check_uploading(policy_rec.currently_uploading_yn);


    IF policy_rec.domicilary_general_type_id IS NOT NULL AND nvl(v_opd_limit_sum_insured,0) = 0 THEN
      raise_application_error(-20556,'Please specify Domiciliary Treatment (OPD) limit');
    END IF;

    IF NVL(v_webconfig_seq_id,0) = 0 THEN
      INSERT INTO weblogin_config(
        webconfig_seq_id,
        prod_policy_seq_id,
        policy_seq_id,
        modification_allowed_days,
        grp_cnt_add_general_type_id,
        emp_add_general_type_id,
        policy_default_sum_insured,
        opd_limit_sum_insured,
        inception_date_general_type_id,
        add_sum_ins_general_type_id,
        grp_cnt_cancel_general_type_id,
        soft_upl_general_type_id,
        send_mail_general_type_id,
        pwd_general_type_id,
        window_period,
        mail_general_type_id,
        intimation_access_gen_type_id,
        effective_to_date,
        notification_details,
        report_from,
        report_to,
        online_assistance_gen_type_id,
        password_validity,        --for CR-KOC1019
        show_allert_days,         --for CR-KOC1019
        online_rating_gen_type_id, --for CR-KOC1027
        relship_comb_gen_type_id,----FOR KOC1084 CR
        first_login_window_period,--FOR KOC1091 CR
        added_by,
        added_date,
        deletion_time_frame,
        inlaws_count,
        webloginopt_in_out,  --KOC1216
        default_premium ,    --KOC1216
         wrong_attempts ,  --KOC1257
         wellness_login_type_id,
         gen_type_id
         )
      VALUES (
        weblogin_config_seq.NEXTVAL,
        v_prod_policy_seq_id,
        v_policy_seq_id,
        v_modification_allowed_days,
        v_grp_cnt_add_general_type_id,
        v_emp_add_general_type_id,
        v_policy_default_sum_insured,
        v_opd_limit_sum_insured,
        v_inception_date_gen_type_id,
        v_add_sum_ins_general_type_id,
        v_grp_cnt_cancel_gen_type_id,
        v_soft_upl_general_type_id,
        v_send_mail_general_type_id,
        v_pwd_general_type_id,
        v_window_period,
        v_mail_general_type_id,
        v_int_access_gen_type_id,
        policy_rec.effective_to_date,
        v_notification_details,
        v_report_from,
        v_report_to,
        v_online_ass_gen_type_id,
        v_password_validity,      --for CR-KOC1019
        v_Show_Allert_Days,       --for CR-KOC1019
        v_online_rating_gen_type_id, --for CR-KOC1027
        v_relship_comb_gen_type_id,--FOR KOC1084 CR
        v_first_login_window_period,--FOR KOC1091 CR
        v_added_by,
        SYSDATE,
        v_delete_time_frame, --koc1160
        v_inlaws_count, --koc1160
        v_opt_general_type_id,  --KOC1216
        V_DEFAULT_PREMIUM,  --KOC1216
        V_WRONG_ATTEMPTS ,      --KOC1257
        v_wellness_login_type_id,
        v_gen_type_id
        ) RETURNING webconfig_seq_id INTO v_webconfig_seq_id;

    ELSE
      UPDATE weblogin_config SET
        modification_allowed_days               = v_modification_allowed_days,
        grp_cnt_add_general_type_id             = v_grp_cnt_add_general_type_id,
        emp_add_general_type_id                 = v_emp_add_general_type_id,
        policy_default_sum_insured              = v_policy_default_sum_insured,
        opd_limit_sum_insured                   = v_opd_limit_sum_insured,
        inception_date_general_type_id          = v_inception_date_gen_type_id,
        add_sum_ins_general_type_id             = v_add_sum_ins_general_type_id,
        grp_cnt_cancel_general_type_id          = v_grp_cnt_cancel_gen_type_id,
        soft_upl_general_type_id                = v_soft_upl_general_type_id,
        send_mail_general_type_id               = v_send_mail_general_type_id,
        pwd_general_type_id                     = v_pwd_general_type_id ,
        window_period                           = v_window_period,
        mail_general_type_id                    = v_mail_general_type_id,
        intimation_access_gen_type_id           = v_int_access_gen_type_id,
        notification_details                    = v_notification_details,
        effective_to_date                       = policy_rec.effective_to_date,
        report_from                             = v_report_from,
        report_to                               = v_report_to,
        online_assistance_gen_type_id           = v_online_ass_gen_type_id,
        password_validity                       = v_password_validity,     --for CR-KOC1019
        show_allert_days                        = v_Show_Allert_Days,      --for CR-KOC1019
        online_rating_gen_type_id               = v_online_rating_gen_type_id, --for CR-KOC1027
        relship_comb_gen_type_id                = v_relship_comb_gen_type_id,--FOR KOC1084 CR
        first_login_window_period               = v_first_login_window_period,--FOR KOC1091 CR
        updated_by                              = v_added_by,
        updated_date                            = SYSDATE,
        deletion_time_frame                     = v_delete_time_frame, --koc1160
        inlaws_count                            = (case when v_relship_comb_gen_type_id='RCN' then null else v_inlaws_count end),       --koc1160
        webloginopt_in_out                      = v_opt_general_type_id,  --KOC1216
        DEFAULT_PREMIUM                         = V_DEFAULT_PREMIUM ,
        WRONG_ATTEMPTS                          = V_WRONG_ATTEMPTS  ,      --KOC1257
        wellness_login_type_id                  = v_wellness_login_type_id,
        gen_type_id                             = v_gen_type_id
       WHERE webconfig_seq_id = v_webconfig_seq_id;
    END IF;


    IF v_opd_limit_sum_insured > 0 THEN
      UPDATE TPA_ENR_POLICY A SET
        A.domicilary_limit = v_opd_limit_sum_insured
        WHERE A.policy_seq_id = v_policy_seq_id;
    END IF;
    v_rows_processed := SQL%ROWCOUNT;
    COMMIT;
  END save_weblogin_config;
 /*==============================================================================================
    Name       : SELECT_WEBLOGIN_CONFIG
    Created on : 03-JAN-08
    Created By : S.V.Sreeraj.
    Comments   : Administration - >policies ->web config
    Modified By : Ravi for KOC1160
 ============================================================================================== */
   PROCEDURE select_weblogin_config (
     v_prod_policy_seq_id                 IN  WEBLOGIN_CONFIG.prod_policy_seq_id%TYPE,
     v_added_by                           IN  WEBLOGIN_CONFIG.added_by%TYPE,
     v_result_set                         OUT SYS_REFCURSOR
   )
   IS
   BEGIN
     OPEN v_result_set FOR SELECT
       a.webconfig_seq_id  ,
       b.prod_policy_seq_id ,
       c.policy_seq_id   ,
       a.modification_allowed_days  ,
       a.grp_cnt_add_general_type_id ,
       a.emp_add_general_type_id  ,
       a.policy_default_sum_insured,
       c.domicilary_general_type_id,
       a.opd_limit_sum_insured ,
       a.inception_date_general_type_id ,
       a.add_sum_ins_general_type_id ,
       a.grp_cnt_cancel_general_type_id ,
       a.soft_upl_general_type_id ,
       c.policy_sub_general_type_id,
       d.description AS policy_sub_type,
       e.description AS dom_type,
       a.send_mail_general_type_id,
       a.pwd_general_type_id,
       a.window_period,
       a.mail_general_type_id,
       a.intimation_access_gen_type_id,
       a.notification_details,
       a.report_from,
       a.report_to,
       a.online_assistance_gen_type_id,
       a.password_validity,           --for CR-KOC1019
       a.show_allert_days,            --for CR-KOC1019
       a.online_rating_gen_type_id,    --for CR-KOC1027
       a.relship_comb_gen_type_id,    --for KOC1084 CR
       a.first_login_window_period,    --For KOC1091 CR
       a.deletion_time_frame, --koc1160
       a.inlaws_count,        --koc1160
       nvl(webloginopt_in_out,'WSN') as webloginopt_in_out,  --KOC1216
       A.DEFAULT_PREMIUM,    --KOC1216
       A.WRONG_ATTEMPTS ,      --KOC1257
       a.wellness_login_type_id, --KOC1349
       a.gen_type_id
       FROM tpa_ins_prod_policy b
       LEFT OUTER JOIN weblogin_config a ON (a.prod_policy_seq_id = b.prod_policy_seq_id)
       JOIN tpa_enr_policy c ON (b.policy_seq_id = c.policy_seq_id )
       JOIN tpa_general_code d ON (c.policy_sub_general_type_id = d.general_type_id )
       LEFT OUTER JOIN tpa_general_code e ON (c.domicilary_general_type_id = e.general_type_id )
       WHERE b.prod_policy_seq_id = v_prod_policy_seq_id ;
   END select_weblogin_config;
   /*==============================================================================================
    Name       : SAVE_WEBLOGIN_MEM_CONFIG
    Created on : 03-JAN-08
    Created By : S.V.Sreeraj.
    Comments   : Admin->policies->Web Config-> member details save
 ============================================================================================== */
  PROCEDURE save_weblogin_mem_config(
    v_policy_mem_config_seq_id           IN  WEBLOGIN_POLICY_MEM_CONFIG.policy_mem_config_seq_id%TYPE,
    v_policy_seq_id                      IN  WEBLOGIN_POLICY_MEM_CONFIG.policy_seq_id%TYPE,
    v_prod_policy_seq_id                 IN  WEBLOGIN_POLICY_MEM_CONFIG.prod_policy_seq_id%TYPE,
    v_pol_mem_field_type_id              IN  WEBLOGIN_POLICY_MEM_CONFIG.pol_mem_field_type_id%TYPE,
    v_field_status_general_type_id       IN  WEBLOGIN_POLICY_MEM_CONFIG.field_status_general_type_id%TYPE,
    v_added_by                           IN  WEBLOGIN_POLICY_MEM_CONFIG.added_by%TYPE
  )
  IS
    v_pol_seq_id                         WEBLOGIN_POLICY_MEM_CONFIG.policy_seq_id%TYPE:= v_policy_seq_id;
    CURSOR policy_cur IS SELECT a.policy_seq_id
       FROM tpa_ins_prod_policy a WHERE a.prod_policy_seq_id = v_prod_policy_seq_id;
  BEGIN
    IF NVL(v_policy_mem_config_seq_id,0) = 0  THEN
      IF nvl(v_pol_seq_id,0) = 0 THEN
        OPEN policy_cur;
        FETCH policy_cur INTO v_pol_seq_id;
        CLOSE policy_cur;
      END IF;
      INSERT INTO weblogin_policy_mem_config(
        policy_mem_config_seq_id,
        policy_seq_id,
        prod_policy_seq_id,
        pol_mem_field_type_id,
        field_status_general_type_id,
        added_by,
        added_date )
      VALUES (
        weblogin_mem_config_seq.NEXTVAL,
        v_pol_seq_id,
        v_prod_policy_seq_id,
        v_pol_mem_field_type_id,
        v_field_status_general_type_id,
        v_added_by,
        SYSDATE );

    ELSE
      UPDATE weblogin_policy_mem_config SET
        pol_mem_field_type_id                   = v_pol_mem_field_type_id,
        field_status_general_type_id            = v_field_status_general_type_id,
        updated_by                              = v_added_by,
        updated_date                            = SYSDATE
        WHERE policy_mem_config_seq_id = v_policy_mem_config_seq_id;
    END IF;

  END save_weblogin_mem_config;
 /*==============================================================================================
    Name       : SELECT_POLICY_MEM_CONFIG
    Created on : 03-JAN-08
    Created By : S.V.Sreeraj.
    Comments   : Admin->policies->Web Config-> member details
 ============================================================================================== */
 -- Point 1
  -- IF allow_deselect_yn = 'Y' then use The given SQL to load the cache
      -- SELECT A.GENERAL_TYPE_ID, A.DESCRIPTION FROM TPA_GENERAL_CODE A WHERE A.HEADER_TYPE = 'WEBLOGIN_MEM_CONFIG'
  -- IF allow_deselect_yn = 'N' then use The given SQL to load the cache
     -- SELECT A.GENERAL_TYPE_ID, A.DESCRIPTION FROM TPA_GENERAL_CODE A WHERE A.HEADER_TYPE = 'WEBLOGIN_MEM_CONFIG' AND A.GENERAL_TYPE_ID != 'MCE';
 --Point 2
  -- IF mandatory_yn = 'Yes' then Disable the DROP DOWN
  -- IF mandatory_yn = 'No' then Enable the DROP DOWN

  PROCEDURE select_policy_mem_config (
    v_prod_policy_seq_id                 IN  WEBLOGIN_POLICY_MEM_CONFIG.prod_policy_seq_id%TYPE,
    v_result_set                         OUT SYS_REFCURSOR
  )
  IS

    CURSOR policy_cur IS SELECT a.policy_sub_general_type_id
      FROM tpa_enr_policy a JOIN tpa_ins_prod_policy b ON (a.policy_seq_id = b.policy_seq_id)
      WHERE b.prod_policy_seq_id =  v_prod_policy_seq_id;
    policy_rec          policy_cur%ROWTYPE ;
  BEGIN
    OPEN policy_cur;
    FETCH policy_cur INTO policy_rec;
    CLOSE policy_cur;

    OPEN v_result_set FOR SELECT
        b.policy_mem_config_seq_id,
        a.pol_mem_field_type_id ,
        a.field_name,
        a.field_description,
        b.policy_seq_id,
        CASE WHEN a.mandatory_yn = 'Y' THEN 'Yes' ELSE 'No' END AS mandatory_yn,
        CASE WHEN a.mandatory_yn = 'Y' THEN 'MCE' ELSE b.field_status_general_type_id END AS field_status_general_type_id,
        CASE WHEN ( a.mandatory_yn = 'N' AND a.allow_edit_yn = 'Y' OR a.mandatory_yn = 'Y')
          AND NOT (a.pol_mem_field_type_id = 'SUB' AND policy_rec.policy_sub_general_type_id IN ('PFL','PNF'))
          /*AND NOT (a.pol_mem_field_type_id = 'SUM' AND policy_rec.policy_sub_general_type_id = 'PFL')*/ THEN 'Y' ELSE 'N' END AS allow_deselect_yn
        FROM weblogin_policy_member_fields a LEFT OUTER JOIN weblogin_policy_mem_config b ON (a.pol_mem_field_type_id = b.pol_mem_field_type_id AND  b.prod_policy_seq_id = v_prod_policy_seq_id );

  END select_policy_mem_config;
--==============================================================================================
  -- Author  : Ramakrishna K M
  -- Created : 25/02/2008
  -- Purpose : Used in Adminsitration-.Policies->WebConfig->Ins.Company Information
  --===============================================================================
  PROCEDURE select_ins_comp_info (
      v_prod_policy_seq_id                 IN  WEBLOGIN_INS_INFORMATION.prod_policy_seq_id%TYPE,
      v_result_set                         OUT SYS_REFCURSOR
  )
  IS
  BEGIN
    OPEN v_result_set FOR
      SELECT A.ins_info_seq_id,
             A.ins_comp_information,
             A.policy_seq_id,
             A.prod_policy_seq_id
      FROM WEBLOGIN_INS_INFORMATION A
      WHERE A.prod_policy_seq_id=v_prod_policy_seq_id;
  END select_ins_comp_info;
 --==============================================================================================
 -- Author  : Ramakrishna K M
  -- Created : 25/02/2008
  -- Purpose : Used in Adminsitration-.Policies->WebConfig->Ins.Company Information
  --===============================================================================
  PROCEDURE save_ins_comp_info (
    v_ins_info_seq_id                    IN  WEBLOGIN_INS_INFORMATION.ins_info_seq_id%TYPE,
    v_prod_policy_seq_id                 IN  WEBLOGIN_INS_INFORMATION.prod_policy_seq_id%TYPE,
    v_policy_seq_id                      IN  WEBLOGIN_INS_INFORMATION.Policy_Seq_Id%TYPE,
    v_ins_comp_information               IN  WEBLOGIN_INS_INFORMATION.ins_comp_information%TYPE,
    v_added_by                           IN  WEBLOGIN_INS_INFORMATION.added_by%TYPE,
    v_rows_processed                     IN  OUT NUMBER
  )
  IS
  v_pol_seq_id                         WEBLOGIN_INS_INFORMATION.policy_seq_id%TYPE:= v_policy_seq_id;
    CURSOR policy_cur IS SELECT a.policy_seq_id FROM tpa_ins_prod_policy a
       WHERE a.prod_policy_seq_id = v_prod_policy_seq_id;
  BEGIN
     IF NVL(v_ins_info_seq_id,0) = 0  THEN
       IF nvl(v_pol_seq_id,0) = 0 THEN
        OPEN policy_cur;
        FETCH policy_cur INTO v_pol_seq_id;
        CLOSE policy_cur;
      END IF;
      INSERT INTO WEBLOGIN_INS_INFORMATION(
        ins_info_seq_id,
        policy_seq_id,
        prod_policy_seq_id,
        ins_comp_information,
        added_by,
        added_date )
      VALUES (
        weblogin_ins_information_seq.nextval,
        v_pol_seq_id,
        v_prod_policy_seq_id,
        v_ins_comp_information,
        v_added_by,
        SYSDATE );

    ELSE
      UPDATE WEBLOGIN_INS_INFORMATION SET
        ins_comp_information                    = v_ins_comp_information,
        updated_by                              = v_added_by,
        updated_date                            = SYSDATE
        WHERE ins_info_seq_id = v_ins_info_seq_id;
    END IF;
    v_rows_processed := SQL%ROWCOUNT;
    COMMIT;
  END save_ins_comp_info;
  --==============================================================================================
  --KOCNEWHOSP
  --===============================================================================
  PROCEDURE save_hos_comp_info (
    v_hos_info_seq_id                    IN  WEBLOGIN_HOSP_INFORMATION.SEQ_ID%TYPE,
    v_hosp_information               IN  WEBLOGIN_HOSP_INFORMATION.HOSP_INFORMATION%TYPE,
    v_added_by                           IN  WEBLOGIN_HOSP_INFORMATION.added_by%TYPE,
    v_rows_processed                     IN  OUT NUMBER
  )
  IS
   BEGIN
     IF NVL(v_hos_info_seq_id,0) = 0  THEN
      INSERT INTO WEBLOGIN_HOSP_INFORMATION(
        seq_id,
        HOSP_information,added_by,added_date )
      VALUES ( WEBLOGIN_HOSP_INFO_seq_id.NEXTVAL,
        v_hosp_information,v_added_by,SYSDATE );
        END IF;

   
      /*UPDATE WEBLOGIN_HOSP_INFORMATION SET
        ins_comp_information                    = v_ins_comp_information,
        updated_by                              = v_added_by,
        updated_date                            = SYSDATE
        WHERE seq_id = v_ins_info_seq_id;*/
   
    v_rows_processed := SQL%ROWCOUNT;
    COMMIT;
  END save_hos_comp_info;
  
  --==============================================================================================
   /*==============================================================================================
    Name       : SAVE_POLICY_RELATIONSHIP
    Created on : 07-MAR-08
    Created By : S.V.Sreeraj.
    Comments   :
 ============================================================================================== */
  PROCEDURE save_policy_relationship(
    v_relship_ids                        IN  VARCHAR2,
    v_prod_policy_seq_id                 IN  TPA_PROD_POLICY_RELATIONSHIP.prod_policy_seq_id%TYPE,
    v_policy_seq_id                      IN  OUT TPA_PROD_POLICY_RELATIONSHIP.policy_seq_id%TYPE,
    v_added_by                           IN  TPA_PROD_POLICY_RELATIONSHIP.added_by%TYPE,
    v_rows_processed                     IN  OUT NUMBER
  )
  IS
    str_tab                              ttk_util_pkg.str_table_type := ttk_util_pkg.parse_str(v_relship_ids);
    v_ctr                                NUMBER(1);
  BEGIN

    IF v_policy_seq_id IS NULL THEN
      SELECT a.policy_seq_id  INTO v_policy_seq_id
         FROM tpa_ins_prod_policy a WHERE a.prod_policy_seq_id = v_prod_policy_seq_id ;
    END IF;

    IF str_tab.FIRST IS NOT NULL THEN
      DELETE FROM tpa_prod_policy_relationship a WHERE a.policy_seq_id = v_policy_seq_id ;
    END IF;

    IF str_tab.FIRST IS NOT NULL THEN
      FOR i IN str_tab.FIRST .. str_tab.COUNT/4
      LOOP
        IF str_tab(i*4) = 'EWM' THEN
          SELECT COUNT(1) INTO v_ctr FROM tpa_relationship_code a
            WHERE a.relship_type_id = str_tab(i*4-3) AND a.relship_group_type_id IN ('SPO');
          IF v_ctr = 0 THEN
            raise_application_error(-20666,'Date of marriage option cannot be selected for this relatioship.');
          END IF;
        ELSIF str_tab(i*4) = 'EMB' THEN
          SELECT COUNT(1) INTO v_ctr FROM tpa_relationship_code a
            WHERE a.relship_type_id = str_tab(i*4-3) AND a.relship_group_type_id IN ('NS1','ND1','NC1');
          IF v_ctr = 0 THEN
            raise_application_error(-20667,'Date of birth option cannot be selected for this relatioship.');
          END IF;

        END IF;
        INSERT INTO tpa_prod_policy_relationship(
          prod_pol_rel_seq_id,
          prod_policy_seq_id,
          policy_seq_id,
          relship_type_id,
          wp_restriction_yn,
          relship_window_period ,
          from_date_general_type_id,
          added_by,
          added_date)
        VALUES (
          tpa_prod_policy_relship_seq.NEXTVAL ,
          v_prod_policy_seq_id,
          v_policy_seq_id,
          str_tab(i*4-3),
          str_tab(i*4-2),
          str_tab(i*4-1),
          str_tab(i*4),
          v_added_by,
          SYSDATE );
      END LOOP;
    END IF;
    v_rows_processed := SQL%ROWCOUNT;
    COMMIT;
  END save_policy_relationship;
--=====================================================================================
  PROCEDURE select_relship_list (
    v_prod_policy_seq_id    IN OUT tpa_ins_prod_policy.prod_policy_seq_id%TYPE,
    v_result_set            OUT SYS_REFCURSOR
  )
  IS
    CURSOR prod_policy_cur IS SELECT a.policy_seq_id,c.abbrevation_code
      FROM tpa_ins_prod_policy a JOIN tpa_enr_policy b ON  (a.policy_seq_id = b.policy_seq_id)
      JOIN tpa_ins_info c ON (b.ins_seq_id = c.ins_seq_id)
      WHERE a.prod_policy_seq_id = v_prod_policy_seq_id ;

    prod_policy_rec    prod_policy_cur%ROWTYPE;

  BEGIN
    OPEN prod_policy_cur;
    FETCH prod_policy_cur INTO prod_policy_rec;
    CLOSE prod_policy_cur;

 /*OPEN v_result_set FOR SELECT
       c.relship_type_id,
       CASE WHEN d.prod_pol_rel_seq_id IS NOT NULL THEN 'Y' ELSE 'N' END AS selected_yn,
       nvl(d.wp_restriction_yn,'N') AS wp_restriction_yn,
       d.relship_window_period ,
       e.window_period AS policy_window_period,
       d.from_date_general_type_id ,
       c.insurance_relship_description AS relship_description
       FROM tpa_ins_prod_policy aa JOIN tpa_enr_policy a ON (a.policy_seq_id = aa.policy_seq_id)
       JOIN tpa_ins_info b ON (a.ins_seq_id = b.ins_seq_id)
       JOIN tpa_ins_relationship_mapping c ON (b.abbrevation_code = c.abbrevation_code)
       LEFT OUTER JOIN tpa_prod_policy_relationship d ON (c.relship_type_id = d.relship_type_id AND d.policy_seq_id = a.policy_seq_id)
       LEFT OUTER JOIN weblogin_config E ON (a.policy_seq_id = e.policy_seq_id)
       WHERE aa.prod_policy_seq_id = v_prod_policy_seq_id ; */

    OPEN v_result_set FOR SELECT
       b.relship_type_id,
       CASE WHEN d.prod_pol_rel_seq_id IS NOT NULL THEN 'Y' ELSE 'N' END AS selected_yn,
       nvl(d.wp_restriction_yn,'N') AS wp_restriction_yn,
       d.relship_window_period ,
       e.window_period AS policy_window_period,
       d.from_date_general_type_id ,
       b.insurance_relship_description AS relship_description
       FROM tpa_enr_policy a JOIN
       ( SELECT DISTINCT relship_type_id,insurance_relship_description,
       prod_policy_rec.policy_seq_id FROM tpa_ins_relationship_mapping WHERE abbrevation_code = prod_policy_rec.abbrevation_code ) B ON (A.Policy_Seq_Id = B.Policy_Seq_Id)
       LEFT OUTER JOIN tpa_prod_policy_relationship d ON (b.relship_type_id = d.relship_type_id AND d.policy_seq_id = a.policy_seq_id)
       LEFT OUTER JOIN weblogin_config E ON (a.policy_seq_id = e.policy_seq_id)
       WHERE a.policy_seq_id = prod_policy_rec.policy_seq_id ORDER BY b.insurance_relship_description;

  END select_relship_list;

 /*==============================================================================================
    Name       : SELECT_PRODUCT_PLAN_LIST
    Created on : 24-JUN-08
    Created By : S.V.Sreeraj.
    Comments   : The list of sum insured plan for policy/product/group
 ============================================================================================== */
  PROCEDURE select_plan_list(
    v_seq_id                             IN NUMBER, -- prod_policy_seq_id
    v_flag                               IN VARCHAR2, -- 'PRD' -- PRODUCT, 'POL' -- POLICY
    v_sort_var                           IN  VARCHAR2,
    v_sort_order                         IN  VARCHAR2,
    v_start_num                          IN  NUMBER ,
    v_end_num                            IN  NUMBER ,
    v_added_by                           IN  NUMBER,
    v_result_set                         OUT SYS_REFCURSOR
  )
  IS
    v_sql_str                            VARCHAR2(4000);
    v_internal_seq_id                    NUMBER(20);
    CURSOR prod_policy_cur IS SELECT a.policy_seq_id,a.product_seq_id
      FROM tpa_ins_prod_policy a WHERE a.prod_policy_seq_id = v_seq_id ;
    prod_policy_rec              prod_policy_cur%ROWTYPE ;

  BEGIN
    OPEN prod_policy_cur;
    FETCH prod_policy_cur INTO prod_policy_rec;
    CLOSE prod_policy_cur;

    IF v_flag = 'PRD' THEN
      v_internal_seq_id := prod_policy_rec.product_seq_id;
    ELSE
      v_internal_seq_id := prod_policy_rec.policy_seq_id;
    END IF;

    v_sql_str :=  ' SELECT
     a.prod_plan_seq_id,  a.prod_plan_name, a.plan_amount, a.plan_code,
     a.from_age, a.to_age ,a.plan_premium
     FROM tpa_ins_product_plan a WHERE '||
     CASE WHEN v_flag = 'PRD' THEN ' a.product_seq_id = :v_internal_seq_id AND a.policy_seq_id IS NULL '
       ELSE '  a.policy_seq_id  = :v_internal_seq_id AND a.product_seq_id IS NULL '
     END;

     v_sql_str := 'SELECT * FROM
        (SELECT A.*,DENSE_RANK() OVER (ORDER BY '||v_sort_var||' '||v_sort_order||',ROWNUM)
        Q FROM (' ||v_sql_str|| ') A ) WHERE  Q>= :v_start_num AND Q<= :v_end_num ';

     OPEN v_result_set FOR v_sql_str USING v_internal_seq_id, v_start_num , v_end_num ;

  END select_plan_list;
 /*==============================================================================================
    Name       : SELECT_PRODUCT_PLAN_LIST
    Created on : 24-JUN-08
    Created By : S.V.Sreeraj.
    Comments   : Sum insured plan selection
 ============================================================================================== */
  PROCEDURE select_prod_plan(
    v_prod_plan_seq_id                   IN tpa_ins_product_plan.prod_plan_seq_id%TYPE ,
    v_result_set                         OUT SYS_REFCURSOR
  )
  IS
  BEGIN
     OPEN v_result_set FOR
       SELECT
       a.prod_plan_seq_id,
       a.prod_plan_name,
       a.plan_amount,
       a.product_seq_id,
       a.scheme_id,
       a.plan_code,
       a.group_reg_seq_id,
       a.policy_seq_id,
       a.from_age,
       a.to_age,
       a.plan_premium,
       a.cash_benefit_amt,
       a.benefit_allowed_days,
       a.benefit_general_type_id
       FROM tpa_ins_product_plan a
       WHERE a.prod_plan_seq_id = v_prod_plan_seq_id;

  END select_prod_plan;
 /*==============================================================================================
    Name       : SAVE_PRODUCT_PLAN
    Created on : 24-JUN-08
    Created By : S.V.Sreeraj.
    Comments   : Save sum insured plan
 ============================================================================================== */

  PROCEDURE save_product_plan(
    v_prod_plan_seq_id                   IN  OUT TPA_INS_PRODUCT_PLAN.prod_plan_seq_id%TYPE,
    v_prod_plan_name                     IN  TPA_INS_PRODUCT_PLAN.prod_plan_name%TYPE,
    v_plan_amount                        IN  TPA_INS_PRODUCT_PLAN.plan_amount%TYPE,
    v_product_seq_id                     IN  TPA_INS_PRODUCT_PLAN.product_seq_id%TYPE,
    v_scheme_id                          IN  TPA_INS_PRODUCT_PLAN.scheme_id%TYPE,
    v_plan_code                          IN  TPA_INS_PRODUCT_PLAN.plan_code%TYPE,
    v_group_reg_seq_id                   IN  TPA_INS_PRODUCT_PLAN.group_reg_seq_id%TYPE,
    v_policy_seq_id                      IN  TPA_INS_PRODUCT_PLAN.policy_seq_id%TYPE,
    v_from_age                           IN  TPA_INS_PRODUCT_PLAN.from_age%TYPE,
    v_to_age                             IN  TPA_INS_PRODUCT_PLAN.to_age%TYPE,
    v_plan_premium                       IN  TPA_INS_PRODUCT_PLAN.plan_premium%TYPE,
    v_cash_benefit_amt                   IN  TPA_INS_PRODUCT_PLAN.cash_benefit_amt%TYPE,
    v_benefit_allowed_days               IN  TPA_INS_PRODUCT_PLAN.benefit_allowed_days%TYPE,
    v_benefit_general_type_id            IN  TPA_INS_PRODUCT_PLAN.benefit_general_type_id%TYPE,
    v_added_by                           IN  TPA_INS_PRODUCT_PLAN.added_by%TYPE,
    v_rows_processed                     IN  OUT NUMBER
  )
  IS

  BEGIN
    IF v_plan_premium > 0 AND v_policy_seq_id IS NULL THEN
      raise_application_error(-20732,'Premium is allowed only in policy plans');
    END IF;

    IF NVL(v_prod_plan_seq_id,0) = 0  THEN
      INSERT INTO tpa_ins_product_plan(
        prod_plan_seq_id,
        prod_plan_name,
        plan_amount,
        product_seq_id,
        scheme_id,
        plan_code,
        group_reg_seq_id,
        policy_seq_id,
        from_age,
        to_age,
        plan_premium,
        cash_benefit_amt,
        benefit_allowed_days,
        benefit_general_type_id,
        deleted_yn,
        added_by,
        added_date )
      VALUES (
        tpa_ins_product_plan_seq.NEXTVAL  ,
        v_prod_plan_name,
        v_plan_amount,
        v_product_seq_id,
        v_scheme_id,
        v_plan_code,
        v_group_reg_seq_id,
        v_policy_seq_id,
        v_from_age,
        v_to_age,
        v_plan_premium,
        v_cash_benefit_amt,
        v_benefit_allowed_days,
        v_benefit_general_type_id,
        'N',
        v_added_by,
        SYSDATE) RETURNING prod_plan_seq_id  INTO v_prod_plan_seq_id;

    ELSE
      UPDATE tpa_ins_product_plan SET
        prod_plan_name                          = v_prod_plan_name,
        plan_amount                             = v_plan_amount,
        product_seq_id                          = v_product_seq_id,
        scheme_id                               = v_scheme_id,
        plan_code                               = v_plan_code,
        group_reg_seq_id                        = v_group_reg_seq_id,
        policy_seq_id                           = v_policy_seq_id,
        from_age                                = v_from_age,
        to_age                                  = v_to_age,
        plan_premium                            = v_plan_premium,
        cash_benefit_amt                        = v_cash_benefit_amt,
        benefit_allowed_days                    = v_benefit_allowed_days,
        benefit_general_type_id                 = v_benefit_general_type_id,
        updated_by                              = v_added_by,
        updated_date                            = SYSDATE
        WHERE prod_plan_seq_id  = v_prod_plan_seq_id;
          END IF;
 /*======================================================================
   Created on   : 08-DEC-11
   Created By   : B.M.Manjunath
   Company Name : RCS Techonologies
   Comments     : KOC1122-- Modifyed  this (save_product_plan)procedure
                     for updating the product_plan_benefit type
                     to 'CBI' & 'CBF' for Floater policy.
 =======================================================================*/

        IF  v_benefit_general_type_id='CBI' then
          update tpa_ins_product_plan a set a.benefit_general_type_id='CBI'
where a.policy_seq_id =v_policy_seq_id  and a.policy_seq_id in
(select b.policy_seq_id from tpa_enr_policy b where b.policy_seq_id=v_policy_seq_id
and b.policy_sub_general_type_id='PFL');
        ELSE
          update tpa_ins_product_plan a set a.benefit_general_type_id='CBF'
where a.policy_seq_id =v_policy_seq_id  and a.policy_seq_id in
(select b.policy_seq_id from tpa_enr_policy b where b.policy_seq_id=v_policy_seq_id
and b.policy_sub_general_type_id='PFL');
    END IF;

   ---------------
    v_rows_processed := SQL%ROWCOUNT;
    COMMIT;
  END save_product_plan;

/*==============================================================================================
    Name       : select_clause_doc_list
    Created on : 26-AUG-08
    Created By : Ramakrishna K M.
    Comments   : Used for Fetching Associated Document list for the purpose of displaying in Callcenter
============================================================================================== */
  PROCEDURE select_clause_doc_list(
    v_prod_policy_seq_id                IN   tpa_ins_prod_policy.prod_policy_seq_id%TYPE,
    v_sort_var                          IN   VARCHAR2,
    v_sort_order                        IN   VARCHAR2,
    v_start_num                         IN   NUMBER,
    v_end_num                           IN   NUMBER,
    v_added_by                          IN   NUMBER,
    result_set                          OUT  SYS_REFCURSOR
  )
  IS
    v_sql_str   VARCHAR2 (4000);
  BEGIN
    --diaplay only non logically deleted records
    v_sql_str :=
      'SELECT A.clauses_doc_seq_id,
             A.prod_policy_seq_id,
             A.doc_name,
             A.doc_path
          FROM tpa_prod_policy_clauses_doc A
          WHERE A.prod_policy_seq_id = :v_prod_policy_seq_id';

    v_sql_str :='SELECT * FROM
                    (SELECT A.*,DENSE_RANK() OVER (ORDER BY '|| v_sort_var|| ' '|| v_sort_order|| ',ROWNUM)
                      Q FROM ('|| v_sql_str|| ') A ) WHERE  Q>= :v_start_num  AND Q<= :v_end_num ';

    OPEN result_set FOR v_sql_str USING v_prod_policy_seq_id,v_start_num, v_end_num ;
  END select_clause_doc_list;

/*==============================================================================================
    Name       : select_clause_doc_details
    Created on : 26-AUG-08
    Created By : Ramakrishna K M.
    Comments   : Used for Fetching Associated Document details for the purpose of displaying in Callcenter
============================================================================================== */
 PROCEDURE select_clause_doc_details(
    v_clauses_doc_seq_id              IN  tpa_prod_policy_clauses_doc.clauses_doc_seq_id%TYPE,
    result_set                        OUT SYS_REFCURSOR
  )
  IS
  BEGIN
    OPEN result_set FOR
      SELECT A.clauses_doc_seq_id,
             A.prod_policy_seq_id,
             A.doc_name,
             A.doc_path
          FROM tpa_prod_policy_clauses_doc A
          WHERE A.clauses_doc_seq_id=v_clauses_doc_seq_id;
  END select_clause_doc_details;

/*==============================================================================================
    Name       : save_clause_doc_details
    Created on : 26-AUG-08
    Created By : Ramakrishna K M.
    Comments   : Used for Associating Document to product/Policy for the purpose of displaying in Callcenter
============================================================================================== */
  PROCEDURE save_clause_doc_details(
    v_clauses_doc_seq_id              IN  OUT tpa_prod_policy_clauses_doc.clauses_doc_seq_id%TYPE,
    v_prod_policy_seq_id              IN  tpa_prod_policy_clauses_doc.prod_policy_seq_id%TYPE,
    v_doc_name                        IN  tpa_prod_policy_clauses_doc.doc_name%TYPE,
    v_doc_path                        IN  tpa_prod_policy_clauses_doc.doc_path%TYPE,
    v_added_by                        IN  NUMBER,
    v_rows_processed                  OUT INTEGER
  )
  IS

  BEGIN

       IF v_clauses_doc_seq_id = 0 THEN
         INSERT INTO tpa_prod_policy_clauses_doc(
           clauses_doc_seq_id,
           prod_policy_seq_id,
           doc_name,
           doc_path,
           added_by,
           added_date)
         VALUES(
           tpa_prod_pol_clauses_doc_seq.nextval,
           v_prod_policy_seq_id,
           v_doc_name,
           v_doc_path,
           v_added_by,
           SYSDATE ) RETURNING clauses_doc_seq_id INTO v_clauses_doc_seq_id;
       ELSE
           UPDATE tpa_prod_policy_clauses_doc SET
            doc_name                   = v_doc_name,
            doc_path                   = v_doc_path,
            updated_by                 = v_added_by,
            updated_date               = SYSDATE
        WHERE clauses_doc_seq_id = v_clauses_doc_seq_id AND prod_policy_seq_id = v_prod_policy_seq_id;
       END IF;
       v_rows_processed := SQL%ROWCOUNT;
       COMMIT;
  END save_clause_doc_details;
  /*==============================================================================================
    Name       : clause_doc_delete
    Created on : 26-AUG-08
    Created By : Ramakrishna K M.
    Comments   : Used for deleting Associated Documents to product/Policy
============================================================================================== */
  PROCEDURE clause_doc_delete (
      v_clauses_doc_seq_id            IN  VARCHAR2, -- conacatenated string of clause doc seq id |seq_id1|seq_id1|....|
      v_added_by                      IN  NUMBER,
      v_rows_processed                OUT INTEGER
   )
   IS
    str_tab                    ttk_util_pkg.str_table_type;
   BEGIN
    str_tab := ttk_util_pkg.parse_str (v_clauses_doc_seq_id);
    FOR i IN str_tab.FIRST .. str_tab.LAST
    LOOP
        DELETE FROM tpa_prod_policy_clauses_doc WHERE clauses_doc_seq_id = TO_NUMBER (str_tab (i));
    END LOOP;
      --returns no.. of rows updated/inserted
    v_rows_processed := str_tab.LAST;
    COMMIT;
  END clause_doc_delete;
 -- ==============================================================================================
  PROCEDURE select_emp_without_sum_list (
    v_search_str               IN VARCHAR2,
    result_set                 OUT SYS_REFCURSOR
  )

 /* Arguments order in concatenated string
  1. Flag
          VALUES
          1. 'SUM MISSING'  -- Families Without SI
          2. 'PAT_CLM'      -- Active Preauth and Claims
          3. 'BUFFER'       -- Buffer Utilisation
          4. 'UTILISED SUM' -- SI Utilisation

  2. prod_Policy_seq_id
  3. TPA_ENROLLMENT_NUMBER  --
   */


  IS
    v_search_tab   ttk_util_pkg.str_table_type := ttk_util_pkg.parse_str(v_search_str);
    CURSOR policy_cur IS SELECT b.policy_sub_general_type_id, b.policy_seq_id,
      b.buffer_alloc_general_type_id,B.MEMBER_BUFFER_YN
      FROM tpa_ins_prod_policy a JOIN tpa_enr_policy b ON (a.policy_seq_id = b.policy_seq_id)
      WHERE a.prod_policy_seq_id = v_search_tab(2)
      AND b.deleted_yn = 'N';

    policy_rec                   policy_cur%ROWTYPE;

    CURSOR family_cur IS SELECT a.policy_group_seq_id
      FROM tpa_enr_policy_group a
      WHERE a.tpa_enrollment_number = v_search_tab(3) AND a.policy_seq_id = policy_rec.policy_seq_id;


    family_rec                   family_cur%ROWTYPE;
  BEGIN
   --INSERT INTO TEMP_RAM(REMARKS) VALUES (v_search_str);
   --COMMIT;


    OPEN policy_cur;
    FETCH policy_cur INTO policy_rec;
    CLOSE policy_cur;

    IF v_search_tab(3) IS NOT NULL  THEN
      OPEN family_cur;
      FETCH family_cur INTO family_rec;
      CLOSE family_cur;
    END IF;

    IF v_search_tab(1) = 'SUM MISSING' THEN
      IF policy_rec.policy_sub_general_type_id = 'PNF' THEN
        OPEN result_set FOR SELECT DISTINCT
          b.tpa_enrollment_number,
          b.insured_name,
          b.order_number,
          b.certificate_no
          FROM tpa_enr_policy a JOIN tpa_enr_policy_group b ON (a.policy_seq_id = b.policy_seq_id)
          JOIN tpa_enr_policy_member c ON (b.policy_group_seq_id = c.policy_group_seq_id)
          WHERE a.policy_seq_id = policy_rec.policy_seq_id AND
          B.deleted_yn = 'N' AND C.deleted_yn = 'N' AND b.status_general_type_id != 'POC'
          AND c.status_general_type_id != 'POC' AND
          ( c.mem_tot_sum_insured IS NULL OR c.mem_tot_sum_insured = 0);

      ELSE
        OPEN result_set FOR SELECT
          b.tpa_enrollment_number,
          b.insured_name,
          b.order_number,
          b.certificate_no
          FROM tpa_enr_policy a JOIN tpa_enr_policy_group b ON (a.policy_seq_id = b.policy_seq_id)
          WHERE a.policy_seq_id = policy_rec.policy_seq_id AND
          B.deleted_yn = 'N' AND b.status_general_type_id != 'POC'
          AND (B.FAMILY_TOT_SUM_INSURED IS NULL OR B.FAMILY_TOT_SUM_INSURED = 0 )
          AND (B.floater_sum_insured  IS NULL OR B.floater_sum_insured  = 0 );
      END IF;
    ELSIF v_search_tab(1) = 'PAT_CLM' THEN
       OPEN result_set FOR
       SELECT nvl(s.tpa_enrollment_id,t.tpa_enrollment_id) AS tpa_enrollment_id,
       nvl(s.insured_name,t.insured_name) AS insured_name ,
       nvl(s.mem_name,t.mem_name) AS claimant_name,
       nvl(s.ailment_description,t.ailment_description ) AS ailment,
       nvl(s.RELSHIP_DESCRIPTION,t.RELSHIP_DESCRIPTION ) AS relationship,
       nvl(s.mem_tot_sum_insured,t.mem_tot_sum_insured) AS sum_insured,
       s.pre_auth_number,
       S.pat_requested_amount AS preauth_requested_amount,
       s.pat_status AS preauth_status,
       s.pat_app_amount AS preauth_approved_amount,
       t.claim_number,
       t.requested_amount AS claim_requested_amount,
       t.clm_status AS claim_status,
       t.clm_app_sum AS claim_approved_amount
       FROM (SELECT a.policy_number,a.policy_effective_from,a.policy_effective_to, A.pat_enroll_detail_seq_id,a.pre_auth_number ,nvl(c.mem_tot_sum_insured,d.family_tot_sum_insured) AS mem_tot_sum_insured ,b.pat_requested_amount,
             B.app_sum_insured AS pat_app_sum , B.app_cum_bonus AS pat_app_bonus,  case when pat_status_general_type_id ='REJ' AND B.COMPLETED_YN='N' AND pii.pat_ins_status='INP' THEN app.ACCOUNT_INFO_PKG.get_gen_desc('INSR','G') ELSE  g.description END  AS pat_status ,
             b.Total_App_Amount AS pat_app_amount,c.mem_name, d.insured_name, ailment_description ,
             F.RELSHIP_DESCRIPTION,
             a.tpa_enrollment_id
             FROM pat_enroll_details A JOIN pat_general_details B ON ( A.pat_enroll_detail_seq_id = B.pat_enroll_detail_seq_id )
             left outer join pat_ins_intimation_details pii on (a.PAT_ENROLL_DETAIL_SEQ_ID= pii.pat_auth_seq_id)
             JOIN tpa_enr_policy_member c ON (a.member_seq_id = c.member_seq_id)
             JOIN tpa_enr_policy_group d ON (c.policy_group_seq_id = d.policy_group_seq_id)
             LEFT OUTER JOIN ailment_details e ON (b.pat_gen_detail_seq_id = e.pat_gen_detail_seq_id  )
             LEFT OUTER JOIN TPA_RELATIONSHIP_CODE F ON (C.RELSHIP_TYPE_ID = F.RELSHIP_TYPE_ID)
             JOIN TPA_GENERAL_CODE G ON (a.pat_status_general_type_id = g.general_type_id)
             WHERE d.policy_seq_id = policy_rec.policy_seq_id
                AND ( v_search_tab(3) IS NULL  OR C.policy_group_seq_id =  family_rec.policy_group_seq_id )
                AND B.pat_enhanced_yn = 'N'
                AND A.pat_status_general_type_id NOT IN ('REJ','PCN')) S
          FULL OUTER JOIN
           (SELECT a.policy_number,a.policy_effective_from,a.policy_effective_to,B.claim_seq_id, B.app_sum_insured AS clm_app_sum, B.app_cum_bonus AS clm_app_bonus,
              case when clm_status_general_type_id ='REJ' AND B.COMPLETED_YN='N'  AND cii.CLM_INS_STATUS='INP' THEN app.ACCOUNT_INFO_PKG.get_gen_desc('INSR','G') ELSE h.description end AS clm_status ,b.parent_claim_seq_id , b.claim_number,
             b.pat_enroll_detail_seq_id ,d.mem_name, e.insured_name,b.requested_amount,
             b.total_app_amount AS clm_app_amount, a.member_seq_id,
             nvl(d.mem_tot_sum_insured,e.family_tot_sum_insured) AS mem_tot_sum_insured
             ,ailment_description ,
             G.RELSHIP_DESCRIPTION,
             a.tpa_enrollment_id
             FROM clm_enroll_details A JOIN clm_general_details B ON (A.claim_seq_id = B.claim_seq_id)
             left outer join clm_ins_intimation_details cii on (b.claim_seq_id=cii.claim_seq_id)
             JOIN clm_inward c ON (B.claims_inward_seq_id = c.claims_inward_seq_id)
             JOIN tpa_enr_policy_member d ON (a.member_seq_id = d.member_seq_id)
             JOIN tpa_enr_policy_group e ON (d.policy_group_seq_id = e.policy_group_seq_id)
             LEFT OUTER JOIN ailment_details f ON (a.claim_seq_id = f.claim_seq_id  )
             LEFT OUTER JOIN TPA_RELATIONSHIP_CODE G ON (D.RELSHIP_TYPE_ID = G.RELSHIP_TYPE_ID)
             JOIN TPA_GENERAL_CODE h ON (a.clm_status_general_type_id = h.general_type_id)
             WHERE e.policy_seq_id = policy_rec.policy_seq_id
             AND (v_search_tab(3) IS NULL  OR d.policy_group_seq_id =  family_rec.policy_group_seq_id )
             AND A.clm_status_general_type_id NOT IN ('PCO','REJ')
             AND B.claim_sub_general_type_id NOT IN  ('HCU','OPD','CBN')) T
               ON (s.pat_enroll_detail_seq_id = t.pat_enroll_detail_seq_id );

    ELSIF v_search_tab(1) = 'BUFFER' THEN
    
    IF policy_rec.MEMBER_BUFFER_YN = 'Y' THEN

        IF policy_rec.buffer_alloc_general_type_id = 'BAI' THEN
          
          OPEN result_set FOR 
           SELECT distinct b.tpa_enrollment_number,
                   b.insured_name,
                   c.tpa_enrollment_id,
                   c.mem_name,
                   nvl(d.used_buff_amount, 0) utilised_buff_amount,
                   case when pre_auth_pkg.get_buff_level_limit(a.policy_seq_id,'NRML','CORB',B.Level_Type)!=0 then  pre_auth_pkg.get_buff_level_limit(a.policy_seq_id,'NRML','CORB',B.Level_Type) else nvl(a.buffer_amount, 0) end buffer_amount,
                   case when pre_auth_pkg.get_buff_level_limit(a.policy_seq_id,'NRML','MEDB',B.Level_Type)!=0 then  pre_auth_pkg.get_buff_level_limit(a.policy_seq_id,'NRML','MEDB',B.Level_Type) else nvl(a.med_buffer_amount, 0)  end med_buffer_amount,
                   case when pre_auth_pkg.get_buff_level_limit(a.policy_seq_id,'CRTL','CRTB',B.Level_Type)!=0 then  pre_auth_pkg.get_buff_level_limit(a.policy_seq_id,'CRTL','CRTB',B.Level_Type) else nvl(a.critical_buff_amount, 0)  end critical_buff_amount,
                   case when pre_auth_pkg.get_buff_level_limit(a.policy_seq_id,'CRTL','CORB',B.Level_Type)!=0 then  pre_auth_pkg.get_buff_level_limit(a.policy_seq_id,'CRTL','CORB',B.Level_Type) else nvl(a.critical_corp_buff_amount, 0) end  critical_corp_buff_amount,
                   case when pre_auth_pkg.get_buff_level_limit(a.policy_seq_id,'CRTL','MEDB',B.Level_Type)!=0 then  pre_auth_pkg.get_buff_level_limit(a.policy_seq_id,'CRTL','MEDB',B.Level_Type) else nvl(a.critical_med_buff_amount, 0)  end critical_med_buff_amount,
                   nvl(d.used_med_buff_amt, 0) utilised_med_buff_amount,
                   nvl(d.used_crit_buff_amt, 0) utilised_crit_buff_amount,
                   nvl(d.used_crit_corp_buff_amt, 0) utilised_crit_corp_buff_amt,
                   nvl(d.used_crit_med_buff_amt, 0) utilised_crit_med_buff_amt

              FROM tpa_enr_balance a              
              JOIN tpa_enr_policy_group b
                ON (a.POLICY_GROUP_SEQ_ID = b.POLICY_GROUP_SEQ_ID)
              JOIN tpa_enr_policy_member c
                ON (B.POLICY_GROUP_SEQ_ID = c.POLICY_GROUP_SEQ_ID)
              JOIN tpa_enr_mem_buffer d on (c.member_seq_id=d.member_seq_id)
             WHERE a.policy_seq_id = policy_rec.policy_seq_id
               AND (v_search_tab(3) IS NULL OR
                   b.policy_group_seq_id = family_rec.policy_group_seq_id)
               AND (d.used_buff_amount > 0 or d.used_med_buff_amt > 0 or
                   d.used_crit_buff_amt > 0 or
                   d.used_crit_corp_buff_amt > 0 or
                   d.used_crit_med_buff_amt > 0)
               and b.deleted_yn = 'N'
               AND c.deleted_yn = 'N';

        ELSIF policy_rec.buffer_alloc_general_type_id = 'BAF' THEN
          OPEN result_set FOR 
          WITH fam_util_buff as (SELECT sum(nvl(d.used_buff_amount,0)) as used_buff_amount,
                       sum(nvl(d.used_med_buff_amt,0)) as used_med_buff_amt,
                       sum(nvl(d.used_crit_buff_amt,0)) as used_crit_buff_amt,
                       sum(nvl(d.used_crit_corp_buff_amt,0)) as used_crit_corp_buff_amt,
                       sum(nvl(d.used_crit_med_buff_amt,0)) as used_crit_med_buff_amt,
                       d.policy_group_seq_id                             
                 FROM tpa_enr_mem_buffer d 
               where d.policy_seq_id=policy_rec.policy_seq_id
               group by d.policy_group_seq_id )
             SELECT DISTINCT b.tpa_enrollment_number,
                        b.insured_name,
                        NULL AS tpa_enrollment_id,
                        NULL AS mem_name,
                        case when pre_auth_pkg.get_buff_level_limit(a.policy_seq_id,'NRML','CORB',B.Level_Type)!=0 then  pre_auth_pkg.get_buff_level_limit(a.policy_seq_id,'NRML','CORB',B.Level_Type) else nvl(a.buffer_amount, 0) end buffer_amount,
                       case when pre_auth_pkg.get_buff_level_limit(a.policy_seq_id,'NRML','MEDB',B.Level_Type)!=0 then  pre_auth_pkg.get_buff_level_limit(a.policy_seq_id,'NRML','MEDB',B.Level_Type) else nvl(a.med_buffer_amount, 0)  end med_buffer_amount,
                       case when pre_auth_pkg.get_buff_level_limit(a.policy_seq_id,'CRTL','CRTB',B.Level_Type)!=0 then  pre_auth_pkg.get_buff_level_limit(a.policy_seq_id,'CRTL','CRTB',B.Level_Type) else nvl(a.critical_buff_amount, 0)  end critical_buff_amount,
                       case when pre_auth_pkg.get_buff_level_limit(a.policy_seq_id,'CRTL','CORB',B.Level_Type)!=0 then  pre_auth_pkg.get_buff_level_limit(a.policy_seq_id,'CRTL','CORB',B.Level_Type) else nvl(a.critical_corp_buff_amount, 0) end  critical_corp_buff_amount,
                       case when pre_auth_pkg.get_buff_level_limit(a.policy_seq_id,'CRTL','MEDB',B.Level_Type)!=0 then  pre_auth_pkg.get_buff_level_limit(a.policy_seq_id,'CRTL','MEDB',B.Level_Type) else nvl(a.critical_med_buff_amount, 0)  end critical_med_buff_amount,
                        nvl(c.used_buff_amount, 0) utilised_buff_amount,
                        nvl(c.used_med_buff_amt, 0) utilised_med_buff_amount,
                        nvl(c.used_crit_buff_amt, 0) utilised_crit_buff_amount,
                        nvl(c.used_crit_corp_buff_amt, 0) utilised_crit_corp_buff_amt,
                        nvl(c.used_crit_med_buff_amt, 0) utilised_crit_med_buff_amt

          FROM tpa_enr_balance a
          JOIN tpa_enr_policy_group b
            ON (a.policy_group_seq_id = b.policy_group_seq_id)
          JOIN fam_util_buff C ON (b.policy_group_seq_id=c.policy_group_seq_id)
         WHERE a.policy_seq_id = policy_rec.policy_seq_id
           AND (v_search_tab(3) IS NULL OR
               b.policy_group_seq_id = family_rec.policy_group_seq_id)
           AND (c.used_buff_amount > 0 or c.used_med_buff_amt > 0 or
               c.used_crit_buff_amt > 0 or
               c.used_crit_corp_buff_amt > 0 or
               c.used_crit_med_buff_amt > 0)
           and b.deleted_yn = 'N';

        ELSE
         OPEN result_set FOR 
           SELECT NULL AS tpa_enrollment_number,
               NULL AS insured_name,
               NULL AS tpa_enrollment_id,
               NULL AS mem_name,
               NULL AS buffer_amount,
               NULL AS utilised_buff_amount,
               NULL AS med_buffer_amount,
               NULL AS critical_buff_amount,
               NULL AS critical_corp_buff_amount,
               NULL AS critical_med_buff_amount,
               NULL AS utilised_med_buff_amount,
               NULL AS utilised_crit_buff_amount,
               NULL AS utilised_crit_corp_buff_amt,
               NULL AS utilised_crit_med_buff_amt
          FROM tpa_enr_balance a
          JOIN tpa_enr_policy_group b
            ON (a.policy_group_seq_id = b.policy_group_seq_id)
          JOIN tpa_enr_policy_member c
            ON (b.policy_group_seq_id = c.policy_group_seq_id)
         WHERE a.policy_seq_id = policy_rec.policy_seq_id
           AND (v_search_tab(3) IS NULL OR
               b.policy_group_seq_id = family_rec.policy_group_seq_id)
           AND (a.utilised_buff_amount > 0 or a.utilised_med_buff_amount > 0 or
               a.utilised_crit_buff_amount > 0 or
               a.utilised_crit_corp_buff_amt > 0 or
               a.utilised_crit_med_buff_amt > 0)
           and b.deleted_yn = 'N'
           AND c.deleted_yn = 'N';

        END IF;
      ELSE
        IF policy_rec.buffer_alloc_general_type_id = 'BAI' THEN
          
          OPEN result_set FOR 
       with mem_util_buff as 
         (select a.member_seq_id,
                 sum(nvl(a.utilised_amount,0)) as utilised_amount,
                 sum(nvl(a.utilised_med_amount,0)) as utilised_med_amount,
                 sum(nvl(a.utilised_crit_amount,0)) as utilised_crit_amount,
                 sum(nvl(a.utilised_crit_corp_amount,0)) as utilised_crit_corp_amount,
                 sum(nvl(a.utilised_crit_med_amount,0)) as utilised_crit_med_amount
             
             from buffer_header a
             where a.policy_seq_id= policy_rec.policy_seq_id
             group by a.member_seq_id )
          SELECT distinct b.tpa_enrollment_number,
                 b.insured_name,
                 c.tpa_enrollment_id,
                 c.mem_name,
                 e.utilised_amount AS utilised_buff_amount,
                 case when pre_auth_pkg.get_buff_level_limit(a.policy_seq_id,'NRML','CORB',B.Level_Type)!=0 then  pre_auth_pkg.get_buff_level_limit(a.policy_seq_id,'NRML','CORB',B.Level_Type) else nvl(a.buffer_amount, 0) end buffer_amount,
                 case when pre_auth_pkg.get_buff_level_limit(a.policy_seq_id,'NRML','MEDB',B.Level_Type)!=0 then  pre_auth_pkg.get_buff_level_limit(a.policy_seq_id,'NRML','MEDB',B.Level_Type) else nvl(a.med_buffer_amount, 0)  end med_buffer_amount,
                 case when pre_auth_pkg.get_buff_level_limit(a.policy_seq_id,'CRTL','CRTB',B.Level_Type)!=0 then  pre_auth_pkg.get_buff_level_limit(a.policy_seq_id,'CRTL','CRTB',B.Level_Type) else nvl(a.critical_buff_amount, 0)  end critical_buff_amount,
                 case when pre_auth_pkg.get_buff_level_limit(a.policy_seq_id,'CRTL','CORB',B.Level_Type)!=0 then  pre_auth_pkg.get_buff_level_limit(a.policy_seq_id,'CRTL','CORB',B.Level_Type) else nvl(a.critical_corp_buff_amount, 0) end  critical_corp_buff_amount,
                 case when pre_auth_pkg.get_buff_level_limit(a.policy_seq_id,'CRTL','MEDB',B.Level_Type)!=0 then  pre_auth_pkg.get_buff_level_limit(a.policy_seq_id,'CRTL','MEDB',B.Level_Type) else nvl(a.critical_med_buff_amount, 0)  end critical_med_buff_amount,
                 e.utilised_med_amount         as utilised_med_buff_amount,
                 e.utilised_crit_amount        as utilised_crit_buff_amount,
                 e.utilised_crit_corp_amount   as utilised_crit_corp_buff_amt,
                 e.utilised_crit_med_amount    as utilised_crit_med_buff_amt
            FROM tpa_enr_balance a
            JOIN tpa_enr_policy_group b
              ON (a.policy_group_seq_id = b.policy_group_seq_id)
            JOIN tpa_enr_policy_member c
              ON (b.policy_group_seq_id = c.policy_group_seq_id)  
            join mem_util_buff e on (c.member_seq_id=e.member_seq_id)            
           WHERE a.policy_seq_id = policy_rec.policy_seq_id
            AND (v_search_tab(3) IS NULL  OR b.policy_group_seq_id =  family_rec.policy_group_seq_id )
            AND (e.utilised_amount > 0 or e.utilised_med_amount > 0 or
                 e.utilised_crit_amount > 0 or e.utilised_crit_corp_amount > 0 or
                 e.utilised_crit_med_amount > 0)
             and b.deleted_yn = 'N'
             AND c.deleted_yn = 'N';
             
        ELSIF policy_rec.buffer_alloc_general_type_id = 'BAF' THEN
          OPEN result_set FOR
            SELECT distinct b.tpa_enrollment_number,
               b.insured_name,
               NULL                          AS tpa_enrollment_id,
               NULL                          AS mem_name,
               a.utilised_buff_amount,
               case when pre_auth_pkg.get_buff_level_limit(a.policy_seq_id,'NRML','CORB',B.Level_Type)!=0 then  pre_auth_pkg.get_buff_level_limit(a.policy_seq_id,'NRML','CORB',B.Level_Type) else nvl(a.buffer_amount, 0) end buffer_amount,
                 case when pre_auth_pkg.get_buff_level_limit(a.policy_seq_id,'NRML','MEDB',B.Level_Type)!=0 then  pre_auth_pkg.get_buff_level_limit(a.policy_seq_id,'NRML','MEDB',B.Level_Type) else nvl(a.med_buffer_amount, 0)  end med_buffer_amount,
                 case when pre_auth_pkg.get_buff_level_limit(a.policy_seq_id,'CRTL','CRTB',B.Level_Type)!=0 then  pre_auth_pkg.get_buff_level_limit(a.policy_seq_id,'CRTL','CRTB',B.Level_Type) else nvl(a.critical_buff_amount, 0)  end critical_buff_amount,
                 case when pre_auth_pkg.get_buff_level_limit(a.policy_seq_id,'CRTL','CORB',B.Level_Type)!=0 then  pre_auth_pkg.get_buff_level_limit(a.policy_seq_id,'CRTL','CORB',B.Level_Type) else nvl(a.critical_corp_buff_amount, 0) end  critical_corp_buff_amount,
                 case when pre_auth_pkg.get_buff_level_limit(a.policy_seq_id,'CRTL','MEDB',B.Level_Type)!=0 then  pre_auth_pkg.get_buff_level_limit(a.policy_seq_id,'CRTL','MEDB',B.Level_Type) else nvl(a.critical_med_buff_amount, 0)  end critical_med_buff_amount,
               a.utilised_med_buff_amount,
               a.utilised_crit_buff_amount,
               a.utilised_crit_corp_buff_amt,
               a.utilised_crit_med_buff_amt
          FROM tpa_enr_balance a
          JOIN tpa_enr_policy_group b
            ON (a.policy_group_seq_id = b.policy_group_seq_id)
         WHERE a.policy_seq_id = policy_rec.policy_seq_id
           AND (v_search_tab(3) IS NULL OR
               b.policy_group_seq_id = family_rec.policy_group_seq_id)
           AND (a.utilised_buff_amount > 0 or a.utilised_med_buff_amount > 0 or
               a.utilised_crit_buff_amount > 0 or
               a.utilised_crit_corp_buff_amt > 0 or
               a.utilised_crit_med_buff_amt > 0)
           and b.deleted_yn = 'N';
           
         ELSE
         OPEN result_set FOR 
           SELECT NULL AS tpa_enrollment_number,
               NULL AS insured_name,
               NULL AS tpa_enrollment_id,
               NULL AS mem_name,
               NULL AS buffer_amount,
               NULL AS utilised_buff_amount,
               NULL AS med_buffer_amount,
               NULL AS critical_buff_amount,
               NULL AS critical_corp_buff_amount,
               NULL AS critical_med_buff_amount,
               NULL AS utilised_med_buff_amount,
               NULL AS utilised_crit_buff_amount,
               NULL AS utilised_crit_corp_buff_amt,
               NULL AS utilised_crit_med_buff_amt
          FROM tpa_enr_balance a
          JOIN tpa_enr_policy_group b
            ON (a.policy_group_seq_id = b.policy_group_seq_id)
          JOIN tpa_enr_policy_member c
            ON (b.policy_group_seq_id = c.policy_group_seq_id)
         WHERE a.policy_seq_id = policy_rec.policy_seq_id
           AND (v_search_tab(3) IS NULL OR
               b.policy_group_seq_id = family_rec.policy_group_seq_id)
           AND (a.utilised_buff_amount > 0 or a.utilised_med_buff_amount > 0 or
               a.utilised_crit_buff_amount > 0 or
               a.utilised_crit_corp_buff_amt > 0 or
               a.utilised_crit_med_buff_amt > 0)
           and b.deleted_yn = 'N'
           AND c.deleted_yn = 'N';

        END IF;
       END IF;
    ELSIF  v_search_tab(1) = 'UTILISED SUM' THEN
      IF policy_rec.policy_sub_general_type_id = 'PNF' THEN
        OPEN result_set FOR SELECT b.tpa_enrollment_number,b.insured_name,c.tpa_enrollment_id,c.mem_name,
           a.Sum_Insured,a.bonus,a.utilised_sum_insured,a.utilised_cum_bonus
           FROM  tpa_enr_balance a JOIN tpa_enr_policy_group b ON (a.policy_group_seq_id = b.policy_group_seq_id)
           JOIN tpa_enr_policy_member c ON(b.policy_group_seq_id = c.policy_group_seq_id)
           WHERE a.policy_seq_id = policy_rec.policy_seq_id
           AND (v_search_tab(3) IS NULL  OR b.policy_group_seq_id =  family_rec.policy_group_seq_id )
           AND a.Utilised_Sum_Insured > 0 and b.deleted_yn = 'N' AND c.deleted_yn = 'N';
      ELSE
        OPEN result_set FOR SELECT b.tpa_enrollment_number,b.insured_name,NULL AS tpa_enrollment_id, NULL AS mem_name,
           a.Sum_Insured,a.bonus,a.utilised_sum_insured,a.utilised_cum_bonus
           FROM  tpa_enr_balance a JOIN tpa_enr_policy_group b ON (a.policy_group_seq_id = b.policy_group_seq_id)
           WHERE a.policy_seq_id = policy_rec.policy_seq_id
           AND (v_search_tab(3) IS NULL  OR b.policy_group_seq_id =  family_rec.policy_group_seq_id )
           AND a.Utilised_Sum_Insured > 0 and b.deleted_yn = 'N' ;
      END IF;
    END IF;
  END select_emp_without_sum_list;
-- ==============================================================================================
 --   Name       : SELECT_CONFIG_REVISION_LIST
 --  Created on-  15-SEP-2010
 --  Created By-  Anil MK
 --  Comments   : To get Service Tax Configuration revision date
  PROCEDURE select_serv_tax_revision_list (
    v_result_set                  OUT SYS_REFCURSOR
  )
  IS
  BEGIN

      OPEN v_result_set FOR SELECT
           a.serv_tax_seq_id,
           a.rev_date_from,
           a.rev_date_to
      FROM
      service_tax_config a ORDER BY a.rev_date_from;

  END select_serv_tax_revision_list;
-- ==============================================================================================
 --   Name       : SELECT_SERV_TAX_REVISION_DTL
 --  Created on-  15-SEP-2010
 --  Created By-  Anil MK
 --  Comments   : To get Service Tax Configuration revision date details
-- ==============================================================================================
  PROCEDURE select_serv_tax_revision_dtl (
    v_service_tax_seq_id  IN service_tax_config.serv_tax_seq_id%TYPE,
    v_result_set                  OUT SYS_REFCURSOR
  )
  IS
  BEGIN

      OPEN v_result_set FOR SELECT
           a.serv_tax_seq_id,
           a.rev_date_from,
           a.rev_date_to,
           a.applicable_rate_percent
      FROM
      service_tax_config a
      WHERE a.serv_tax_seq_id=v_service_tax_seq_id;
  END;
-- ==============================================================================================
--   Name       : SAVE_SERV_TAX_REVISION_DTL
 --  Created on-  15-SEP-2010
 --  Created By-  Anil MK
 --  Comments   : To Save Service Tax Configuration details (KOC1015 A)
-- ==============================================================================================
  PROCEDURE save_serv_tax_revision_dtl (
    v_service_tax_seq_id       IN OUT service_tax_config.serv_tax_seq_id%TYPE,
    v_rev_date_from            IN VARCHAR2,
    v_applicable_rate_percent  IN service_tax_config.applicable_rate_percent%TYPE,
    v_added_by                 IN service_tax_config.added_by%TYPE,
    v_rows_processed           OUT NUMBER
  )
  IS

    v_ctr            PLS_INTEGER;
    CURSOR prev_cur IS SELECT a.rev_date_from  FROM service_tax_config a
         WHERE a.serv_tax_seq_id = v_service_tax_seq_id;

    prev_rec        prev_cur%ROWTYPE;

    v_from_date     DATE := to_date(v_rev_date_from,'dd/mm/yyyy');


  BEGIN
    SELECT COUNT(1) INTO v_ctr
    FROM service_tax_config st
    WHERE TO_DATE(st.rev_date_from,'dd/mm/yyyy') >= TO_DATE(v_from_date,'dd/mm/yyyy')
    AND st.serv_tax_seq_id != nvl(v_service_tax_seq_id,0) ;

    IF v_ctr > 0 THEN
      raise_application_error(-20781,'New revision start date should not be earlier to that of previous revisions');
    END IF;

    IF nvl(v_service_tax_seq_id,0) = 0 THEN

      UPDATE service_tax_config a
        SET a.rev_date_to = CASE WHEN a.rev_date_from < v_from_date
                                 THEN v_from_date - 1  ELSE a.rev_date_from END
        WHERE a.rev_date_to IS NULL;

      INSERT INTO service_tax_config(
             serv_tax_seq_id,
             rev_date_from,
             applicable_rate_percent,
             added_by,
             added_date
             )
      VALUES (
        SERV_TAX_SEQ_ID_SEQ.NEXTVAL,
        v_from_date,
        v_applicable_rate_percent,
        v_added_by,
        SYSDATE ) RETURNING serv_tax_seq_id INTO v_service_tax_seq_id;
    ELSE

       OPEN prev_cur;
       FETCH prev_cur INTO prev_rec;
       CLOSE prev_cur;

       IF prev_rec.rev_date_from != v_from_date THEN

         UPDATE service_tax_config a
            SET a.rev_date_to = CASE WHEN a.rev_date_from < v_from_date
                                     THEN v_from_date - 1  ELSE a.rev_date_from END
            WHERE a.rev_date_to = prev_rec.rev_date_from - 1;
      END IF;
      UPDATE service_tax_config SET
        rev_date_from                           = v_from_date,
        applicable_rate_percent                 = v_applicable_rate_percent,
        updated_by                              = v_added_by,
        updated_date                            = SYSDATE
        WHERE serv_tax_seq_id = v_service_tax_seq_id;
    END IF;
    v_rows_processed := SQL%ROWCOUNT;
    COMMIT;
  END save_serv_tax_revision_dtl;
-- ==============================================================================================
--   Name       : get_disease_codes
 --  Created on -  23-SEP-2010
 --  Created By -  R. J. Prasanna Kumar, SPAN Infotech.
 --  Comments   : This procedure gives list of Disease codes assigned / not assigned to a clause.
-- ==============================================================================================
  PROCEDURE get_disease_codes (
    v_clause_seq_id           IN TPA_PROD_POLICY_CLAUSES.CLAUSE_SEQ_ID%TYPE,
    v_prod_policy_seq_id      IN TPA_INS_PROD_POLICY.PROD_POLICY_SEQ_ID%TYPE,
    v_general_code            IN TPA_GENERAL_CODE.GENERAL_TYPE_ID%TYPE,
    v_Assoc_UnAssoc           IN VARCHAR2, -- DBA - Associated DBU - Unassociated
    v_Code_Description        IN TPA_INS_SPECIFIC_CODE.CODE_DESCRIPTION%TYPE,
    v_result_set              OUT SYS_REFCURSOR
  )
  IS
    v_ins_seq_id TPA_INS_INFO.INS_SEQ_ID%TYPE;
    v_Code_Desc TPA_INS_SPECIFIC_CODE.CODE_DESCRIPTION%TYPE;
  BEGIN
    IF v_Code_Description IS NULL THEN
       v_Code_Desc :='%';
    ELSE
        v_Code_Desc := UPPER('%'||v_Code_Description||'%');
    END IF;
      SELECT NVL(ip.ins_seq_id,ep.ins_head_office_seq_id) INTO v_ins_seq_id
        FROM TPA_INS_PROD_POLICY pp
             LEFT OUTER JOIN TPA_INS_PRODUCT ip ON pp.product_seq_id = ip.product_seq_id
             LEFT OUTER JOIN TPA_ENR_POLICY ep ON pp.policy_seq_id = ep.policy_seq_id
           WHERE pp.prod_policy_seq_id = v_prod_policy_seq_id;

      OPEN v_result_set FOR
        SELECT a.ins_specific_code_seq_id, a.code, a.code_description
          FROM TPA_INS_SPECIFIC_CODE a LEFT OUTER JOIN TPA_INS_SPECIFIC_MAP b
               ON a.ins_specific_code_seq_id = b.ins_specific_code_seq_id AND b.clause_seq_id = v_clause_seq_id
            WHERE a.ins_seq_id = v_ins_seq_id
              AND a.code_general_type_id = v_general_code
              AND UPPER(a.code_description) LIKE v_Code_Desc
              AND ((b.clause_seq_id IS NOT NULL AND v_Assoc_UnAssoc = 'DBA') OR
                   (b.clause_seq_id IS NULL AND v_Assoc_UnAssoc = 'DBU'));
  END get_disease_codes;
--===================================================================================================
--   Name       : clause_disease_binding
 --  Created on -  23-SEP-2010
 --  Created By -  R. J. Prasanna Kumar, SPAN Infotech.
 --  Comments   : This procedure associates Disease codes to a clause or unassociates from a clause based on the option.
--===================================================================================================
  PROCEDURE clause_disease_binding (
    v_clause_seq_id   IN TPA_PROD_POLICY_CLAUSES.CLAUSE_SEQ_ID%TYPE,
    specific_code_seq IN VARCHAR2,
    v_Assoc_UnAssoc   IN VARCHAR2, -- DBA - Associated DBU - Unassociated
    v_added_by        IN  NUMBER,
    v_rows_processed OUT INTEGER
  )
  IS
  str_tab  ttk_util_pkg.str_table_type;
  BEGIN
    str_tab      := ttk_util_pkg.parse_str (specific_code_seq);
    IF v_Assoc_UnAssoc = 'DBA' THEN -- Then assocaite diseases to a clause.
      FORALL i IN str_tab.FIRST .. str_tab.LAST
       INSERT INTO TPA_INS_SPECIFIC_MAP (INS_SPECIFIC_MAP_SEQ_ID, INS_SPECIFIC_CODE_SEQ_ID,
                   CLAUSE_SEQ_ID, ADDED_BY, ADDED_DATE)
       VALUES (TPA_INS_SPECIFIC_MAP_SEQ.NEXTVAL, str_tab(i), v_clause_seq_id,
                v_added_by, SYSDATE);
    ELSE -- Else remove the assocaition between diseases and clause.
      FORALL i IN str_tab.FIRST .. str_tab.LAST
       DELETE FROM TPA_INS_SPECIFIC_MAP
          WHERE CLAUSE_SEQ_ID = v_clause_seq_id
            AND INS_SPECIFIC_CODE_SEQ_ID = str_tab(i);
    END IF;
    --number of rows updated/inserted
    v_rows_processed := SQL%ROWCOUNT;
    COMMIT;

  END clause_disease_binding;
--===================================================================================================
/*==============================================================================================
    Name       : SELECT_SHOW_CUST_MSG
    Created on : 12-OCT-2010
    Created By : Ramakrishna K M.
    Comments   : Select Customised Message details used in Authorization Letter
 ============================================================================================== */
  PROCEDURE select_show_cust_msg(
    v_prod_policy_seq_id                IN   tpa_ins_prod_policy.prod_policy_seq_id%TYPE,
    v_result_set                        OUT SYS_REFCURSOR
  )
  IS
  BEGIN
     OPEN v_result_set FOR
       SELECT a.show_cust_msg,
              a.message
       FROM tpa_enr_policy a
       JOIN tpa_ins_prod_policy b ON (a.policy_seq_id=b.policy_seq_id)
       WHERE b.prod_policy_seq_id = v_prod_policy_seq_id;

  END select_show_cust_msg;
--===================================================================================================
  /*==============================================================================================
    Name       : SAVE_SHOW_CUST_MSG
    Created on : 12-OCT-2010
    Created By : Ramakrishna K M.
    Comments   : Save Customised Message details used in Authorization Letter
 ============================================================================================== */
  PROCEDURE save_show_cust_msg(
    v_prod_policy_seq_id                IN tpa_ins_prod_policy.prod_policy_seq_id%TYPE,
    v_show_cust_msg                     IN tpa_enr_policy.show_cust_msg%TYPE,
    v_message                           IN tpa_enr_policy.message%TYPE,
    v_added_by                          IN tpa_enr_policy.added_by%TYPE,
    v_rows_processed                    OUT NUMBER
  )
  IS
    v_policy_seq_id   tpa_enr_policy.policy_seq_id%TYPE;
  BEGIN
     SELECT b.policy_seq_id INTO v_policy_seq_id
     FROM tpa_enr_policy a
     JOIN tpa_ins_prod_policy b ON (a.policy_seq_id=b.policy_seq_id)
     WHERE b.prod_policy_seq_id = v_prod_policy_seq_id;

     UPDATE tpa_enr_policy SET
     show_cust_msg         = v_show_cust_msg,
     message               = v_message,
     updated_by            = v_added_by,
     updated_date          = SYSDATE
     WHERE policy_seq_id =  v_policy_seq_id;

     v_rows_processed := SQL%ROWCOUNT;
     COMMIT;

  END save_show_cust_msg;
--===================================================================================================
/*==============================================================================================
    Name       : SELECT_COPAY_APPROVED_AMT
    Created on : 24-JUN-2011
    Created By : Ramakrishna K M.
    Comments   : Select the Approved Amount value to use in the Copay Rule Execution
 ============================================================================================== */
  PROCEDURE select_copay_approved_amt(
    v_prod_policy_seq_id                IN   tpa_ins_prod_policy.prod_policy_seq_id%TYPE,
    v_result_set                        OUT SYS_REFCURSOR
  )
  IS
  BEGIN
     OPEN v_result_set FOR
      SELECT a.copay_yn,a.copay_approved_amt,
       --a.copay_fixed_amt,a.copay_level,
       a.copay_perc,a.regn_bsd_prm_config --KOC1284
       FROM tpa_ins_prod_policy a
       WHERE a.prod_policy_seq_id = v_prod_policy_seq_id;
  END select_copay_approved_amt;
--===================================================================================================
  /*==============================================================================================
    Name       : SAVE_COPAY_APPROVED_AMT
    Created on : 24-JUN-2011
    Created By : Ramakrishna K M.
    Comments   : Save the Approved Amount value to use in the Copay Rule Execution
 ============================================================================================== */
   PROCEDURE save_copay_approved_amt(
    v_prod_policy_seq_id                IN tpa_ins_prod_policy.prod_policy_seq_id%TYPE,
    v_copay_approved_amt                IN tpa_ins_prod_policy.copay_approved_amt%TYPE,
    v_added_by                          IN tpa_ins_prod_policy.added_by%TYPE,
    V_rgn_bsd_prm_config                IN tpa_ins_prod_policy.regn_bsd_prm_config%TYPE,--KOC1284
    v_rows_processed                    OUT NUMBER
  )
  IS
    v_policy_seq_id   tpa_enr_policy.policy_seq_id%TYPE;
  BEGIN

     UPDATE tpa_ins_prod_policy SET
     copay_approved_amt    = v_copay_approved_amt,
     updated_by            = v_added_by,
     updated_date          = SYSDATE,
     regn_bsd_prm_config   = V_rgn_bsd_prm_config
     WHERE prod_policy_seq_id =  v_prod_policy_seq_id;

     v_rows_processed := SQL%ROWCOUNT;
     COMMIT;

  END save_copay_approved_amt;
----==================================koc1285===========================================
PROCEDURE save_dom_config(
       v_prod_policy_seq_id              IN OUT tpa_ins_prod_policy.prod_policy_seq_id%TYPE,
       v_dom_config_type                 IN tpa_ins_prod_policy.dom_config_type%TYPE,
       v_added_by                        IN tpa_ins_prod_policy.added_by%TYPE,
       v_alert                           OUT Tpa_Enr_Policy.Remarks%TYPE )
  IS

  CURSOR cur_dom IS
         SELECT dom_config_type,policy_seq_id,product_seq_id FROM tpa_ins_prod_policy
          WHERE prod_policy_seq_id =  v_prod_policy_seq_id;

    dom_rec   cur_dom%ROWTYPE;

 CURSOR dom_clm_cor (v_policy_seq_id  tpa_enr_policy.policy_seq_id%TYPE) IS
     SELECT COUNT(1)
     FROM clm_enroll_details E
     JOIN clm_general_details G ON E.Claim_Seq_Id=G.Claim_Seq_Id
     WHERE policy_seq_id=v_policy_seq_id
     AND g.claim_sub_general_type_id='CSD' and e.enrol_type_id='COR';

  CURSOR dom_clm_ind (v_prod_seq_id  tpa_enr_policy.product_seq_id%TYPE) IS
     SELECT COUNT(1)
     FROM clm_enroll_details E
     JOIN clm_general_details G ON E.Claim_Seq_Id=G.Claim_Seq_Id
     JOIN tpa_enr_policy F ON E.Policy_Seq_Id=F.Policy_Seq_Id
     WHERE g.claim_sub_general_type_id='CSD' and e.enrol_type_id='IND'
     AND F.Product_Seq_Id=v_prod_seq_id ;

     v_ctr      NUMBER(10);

  BEGIN

       OPEN cur_dom;
       FETCH cur_dom INTO dom_rec;
       CLOSE cur_dom;
    IF v_dom_config_type IS NOT NULL THEN

      IF v_dom_config_type != nvl(dom_rec.dom_config_type,v_dom_config_type) THEN
         IF dom_rec.policy_seq_id IS NOT NULL THEN
             OPEN  dom_clm_cor(dom_rec.policy_seq_id);
             FETCH dom_clm_cor INTO v_ctr;
             CLOSE dom_clm_cor;
         ELSIF dom_rec.product_seq_id IS NOT NULL  THEN
             OPEN dom_clm_ind(dom_rec.product_seq_id);
             FETCH dom_clm_ind INTO v_ctr;
             CLOSE dom_clm_ind;
         END IF;

    IF v_ctr>0 THEN
         v_alert :='Active Preauth/Claims Exist for the Policy/Poduct Changes Cant Made';
      RETURN;
    END IF;
   END IF ;

     UPDATE tpa_ins_prod_policy p SET
             dom_config_type       = v_dom_config_type,
             updated_by            = v_added_by,
             updated_date          = SYSDATE
       WHERE prod_policy_seq_id =  v_prod_policy_seq_id;

     COMMIT;
  END IF;
  v_alert:=NULL;
  END save_dom_config;
  ---===========================================================================================
 PROCEDURE select_dom_config(
    v_prod_policy_seq_id                IN   tpa_ins_prod_policy.prod_policy_seq_id%TYPE,
    v_result_set                        OUT SYS_REFCURSOR ) IS
  BEGIN
     OPEN v_result_set FOR
       SELECT a.dom_config_type
       FROM tpa_ins_prod_policy a
       WHERE a.prod_policy_seq_id = v_prod_policy_seq_id;
  END select_dom_config;
 --===============================koc1285==============================================

PROCEDURE save_copay_max_limit(
        v_prod_policy_seq_id                IN tpa_ins_prod_policy.prod_policy_seq_id%TYPE,
        v_copay_yn                          IN tpa_ins_prod_policy.copay_yn%TYPE:='N',
        v_copay_approved_amt                IN tpa_ins_prod_policy.copay_approved_amt%TYPE,
        v_copay_perc                        IN tpa_ins_prod_policy.copay_perc%TYPE,
        v_added_by                          IN tpa_ins_prod_policy.added_by%TYPE,
        V_rgn_bsd_prm_config                IN tpa_ins_prod_policy.regn_bsd_prm_config%TYPE,--KOC1284
        v_rows_processed                    OUT NUMBER ) is

   CURSOR cur_pol IS
   SELECT tep.policy_seq_id,teb.sum_insured,teb.balance_seq_id,teb.policy_group_seq_id,tip.copay_perc

     FROM tpa_ins_prod_policy tip
     JOIN tpa_enr_policy tep  ON (tip.policy_seq_id=tep.policy_seq_id)
     JOIN tpa_enr_balance teb ON (tep.policy_seq_id=teb.policy_seq_id)
   WHERE tip.prod_policy_seq_id=v_prod_policy_seq_id;

  v_sum_ind             Tpa_ins_prod_policy.si_restrict_amt%TYPE;
  v_cnt                 NUMBER(10);

  BEGIN

   FOR jk IN cur_pol LOOP

      IF nvl(v_copay_approved_amt,0)>0 AND v_copay_perc IS NOT NULL THEN
           v_sum_ind := least(v_copay_approved_amt,(1-v_copay_perc/100)*jk.sum_insured);

     ELSIF  nvl(v_copay_approved_amt,0)>0 and v_copay_perc IS NULL THEN
            v_sum_ind :=  v_copay_approved_amt;
     ELSIF  nvl(v_copay_approved_amt,0)=0 and v_copay_perc IS NOT NULL THEN
            v_sum_ind := (1-v_copay_perc/100)*jk.sum_insured;
     END IF;

   SELECT COUNT(1) INTO v_cnt FROM tpa_enr_balance yt
     WHERE balance_seq_id = jk.balance_seq_id
     AND (v_sum_ind < yt.utilised_sum_insured);
    IF v_cnt > 0 THEN
          raise_application_error(-20145,'Buffer utilised amount exceeds the total buffer amount.');
        END IF;
   END LOOP;

    UPDATE tpa_ins_prod_policy
      SET  copay_yn                = v_copay_yn,
           copay_approved_amt      = NVL(v_copay_approved_amt,0),
           copay_perc              = v_copay_perc,
           updated_by              = v_added_by,
           updated_date            = SYSDATE,
           regn_bsd_prm_config   = V_rgn_bsd_prm_config
    WHERE prod_policy_seq_id=v_prod_policy_seq_id;

    v_rows_processed := SQL%ROWCOUNT;
     COMMIT;
   END save_copay_max_limit;
--=========================================================================================

--KOC1270
 /*==============================================================================================
    Name       : save_product_cash_benefit
    Created on : 20/05/2013
    Created By : sree krishna
    Comments   :
 ============================================================================================== */

  PROCEDURE save_product_cash_benefit(
    v_ins_cash_benefit_seq_id            IN  OUT TPA_INS_CASH_BENEFIT.ins_cash_benefit_seq_id%TYPE,
    v_flag                               IN  varchar2,--'HCB' hospital cash Benefit; 'CONV_BENEF' convalance benefit
    v_prod_plan_name                     IN  TPA_INS_CASH_BENEFIT.cash_benefit_plan_name%TYPE,
    v_product_seq_id                     IN  TPA_INS_CASH_BENEFIT.product_seq_id%TYPE,
    v_scheme_id                          IN  TPA_INS_CASH_BENEFIT.scheme_id%TYPE,
    v_plan_code                          IN  TPA_INS_CASH_BENEFIT.cash_benefit_plan_code%TYPE,
    v_group_reg_seq_id                   IN  TPA_INS_CASH_BENEFIT.group_reg_seq_id%TYPE,
    v_policy_seq_id                      IN  TPA_INS_CASH_BENEFIT.policy_seq_id%TYPE,
    v_from_age                           IN  TPA_INS_CASH_BENEFIT.from_age%TYPE,
    v_to_age                             IN  TPA_INS_CASH_BENEFIT.to_age%TYPE,
    v_added_by                           IN  TPA_INS_CASH_BENEFIT.added_by%TYPE,
    v_room_amt                           IN  TPA_INS_CASH_BENEFIT.Room_Amt%TYPE,
    v_acc_amt                            IN  TPA_INS_CASH_BENEFIT.acc_amt%TYPE,
    v_icu_amt                            IN  TPA_INS_CASH_BENEFIT.icu_amt%TYPE,
    v_conv_amt                           IN  TPA_INS_CASH_BENEFIT.conv_amt%TYPE,
    v_room_days_claim                    IN  TPA_INS_CASH_BENEFIT.room_days_claim%TYPE,
    v_acc_days_claim                     IN  TPA_INS_CASH_BENEFIT.acc_days_claim%TYPE,
    v_icu_days_claim                     IN  TPA_INS_CASH_BENEFIT.icu_days_claim%TYPE,
    v_conv_days_claim                    IN  TPA_INS_CASH_BENEFIT.conv_days_claim%TYPE,
    V_ROOM_PER_SI                        IN  TPA_INS_CASH_BENEFIT.ROOM_PER_SI%TYPE,
    V_ACC_PER_SI                         IN  TPA_INS_CASH_BENEFIT.ACC_PER_SI%TYPE,
    V_ICU_PER_SI                         IN  TPA_INS_CASH_BENEFIT.ICU_PER_SI%TYPE,
    V_CONV_PER_SI                        IN  TPA_INS_CASH_BENEFIT.CONV_PER_SI%TYPE,
    V_POLICY_DAYS                        IN  TPA_INS_CASH_BENEFIT.POLICY_DAYS%TYPE,
    v_rows_processed                     IN  OUT NUMBER
    )
  IS

  BEGIN



if v_flag = 'HCB' then

--koc1270 changed on 09082013
 for rec in (select * from TPA_INS_CASH_BENEFIT cb
  where (cb.product_seq_id = v_product_seq_id
  or cb.policy_seq_id = v_policy_seq_id)
  and cb.ins_cash_benefit_seq_id != v_ins_cash_benefit_seq_id)
  loop
  if (v_from_age between rec.from_age and rec.to_age) --koc1270 changed on 09082013
   or (v_to_age between  rec.from_age and rec.to_age) --koc1270 changed on 09082013
   or (v_from_age <= rec.from_age and v_to_age >= rec.to_age) then --koc1270 changed on 09082013
  raise_application_error(-20878,'plan exists with same age band');
  end if;
 end loop;
--koc1270 changed on 09082013

    IF NVL(v_ins_cash_benefit_seq_id,0) = 0  THEN
      INSERT INTO TPA_INS_CASH_BENEFIT(
        ins_cash_benefit_seq_id,
        cash_benefit_plan_name,
        product_seq_id,
        scheme_id,
        cash_benefit_plan_code,
        group_reg_seq_id,
        policy_seq_id,
        from_age,
        to_age,
        deleted_yn,
        added_by,
        added_date,
        ROOM_AMT,
        ACC_AMT,
        ICU_AMT,
        CONV_AMT,
        ROOM_DAYS_CLAIM,
        ACC_DAYS_CLAIM,
        ICU_DAYS_CLAIM,
        CONV_DAYS_CLAIM,
        ROOM_PER_SI,
        ACC_PER_SI,
        ICU_PER_SI,
        CONV_PER_SI,
        POLICY_DAYS
         )
      VALUES (
        tpa_ins_conv_benefit_seq.NEXTVAL,
        v_prod_plan_name,
        v_product_seq_id,
        v_scheme_id,
        v_plan_code,
        v_group_reg_seq_id,
        v_policy_seq_id,
        v_from_age,
        v_to_age,
        'N',
        v_added_by,
        SYSDATE,
        v_room_amt,
        v_acc_amt,
        v_icu_amt,
        v_conv_amt,
        v_room_days_claim,
        v_acc_days_claim,
        v_icu_days_claim,
        v_conv_days_claim,
        V_ROOM_PER_SI,
        V_ACC_PER_SI,
        V_ICU_PER_SI,
        V_CONV_PER_SI,
        V_POLICY_DAYS
         ) RETURNING ins_cash_benefit_seq_id INTO v_ins_cash_benefit_seq_id;

    ELSE
      UPDATE TPA_INS_CASH_BENEFIT SET
        cash_benefit_plan_name                  = v_prod_plan_name,
        product_seq_id                          = v_product_seq_id,
        scheme_id                               = v_scheme_id,
        cash_benefit_plan_code                  = v_plan_code,
        group_reg_seq_id                        = v_group_reg_seq_id,
        policy_seq_id                           = v_policy_seq_id,
        from_age                                = v_from_age,
        to_age                                  = v_to_age,
        updated_by                              = v_added_by,
        updated_date                            = SYSDATE,
        ROOM_AMT                                = v_room_amt,
        ACC_AMT                                 = v_acc_amt,
        ICU_AMT                                 = v_icu_amt,
        CONV_AMT                                = v_conv_amt,
        ROOM_DAYS_CLAIM                         = v_room_days_claim,
        ACC_DAYS_CLAIM                          = v_acc_days_claim,
        ICU_DAYS_CLAIM                          = v_icu_days_claim,
        CONV_DAYS_CLAIM                         = v_conv_days_claim,
        ROOM_PER_SI                             = V_ROOM_PER_SI,
        ACC_PER_SI                              = V_ACC_PER_SI,
        ICU_PER_SI                              = V_ICU_PER_SI,
        CONV_PER_SI                             = V_CONV_PER_SI,
        POLICY_DAYS                             = V_POLICY_DAYS
        WHERE ins_cash_benefit_seq_id           = v_ins_cash_benefit_seq_id;

   END IF;

elsif v_flag = 'CONV_BENEF' then

--koc1270 changed on 09082013
 for rec in (select * from tpa_ins_canvalescence_benefit cb
  where (cb.product_seq_id = v_product_seq_id
  or cb.policy_seq_id = v_policy_seq_id)
  and cb.ins_conv_benf_seq_id != v_ins_cash_benefit_seq_id)
  loop
  if (v_from_age between rec.from_age and rec.to_age)  --koc1270 changed on 09082013
   or (v_to_age between  rec.from_age and rec.to_age) --koc1270 changed on 09082013
   or (v_from_age <= rec.from_age and v_to_age >= rec.to_age) then --koc1270 changed on 09082013
  raise_application_error(-20878,'plan exists with same age band');  --koc1270 changed on 09082013
  end if;
 end loop;
--koc1270 changed on 09082013

IF NVL(v_ins_cash_benefit_seq_id,0) = 0  THEN
      INSERT INTO tpa_ins_canvalescence_benefit(
        ins_conv_benf_seq_id,
        conv_benf_plan_name,
        product_seq_id,
        scheme_id,
        conv_benf_plan_code,
        group_reg_seq_id,
        policy_seq_id,
        from_age,
        to_age,
        deleted_yn,
        added_by,
        added_date,
        CONV_AMT,
        CONV_DAYS_CLAIM,
        CONV_PER_SI,
        POLICY_DAYS
         )
      VALUES (
        tpa_ins_conv_benefit_seq.NEXTVAL,
        v_prod_plan_name,
        v_product_seq_id,
        v_scheme_id,
        v_plan_code,
        v_group_reg_seq_id,
        v_policy_seq_id,
        v_from_age,
        v_to_age,
        'N',
        v_added_by,
        SYSDATE,
        v_conv_amt,
        v_conv_days_claim,
        V_CONV_PER_SI,
        V_POLICY_DAYS
         ) RETURNING ins_conv_benf_seq_id INTO v_ins_cash_benefit_seq_id;

    ELSE
      UPDATE tpa_ins_canvalescence_benefit SET
        conv_benf_plan_name                     = v_prod_plan_name,
        product_seq_id                          = v_product_seq_id,
        scheme_id                               = v_scheme_id,
        conv_benf_plan_code                     = v_plan_code,
        group_reg_seq_id                        = v_group_reg_seq_id,
        policy_seq_id                           = v_policy_seq_id,
        from_age                                = v_from_age,
        to_age                                  = v_to_age,
        updated_by                              = v_added_by,
        updated_date                            = SYSDATE,
        CONV_AMT                                = v_conv_amt,
        CONV_DAYS_CLAIM                         = v_conv_days_claim,
        CONV_PER_SI                             = V_CONV_PER_SI,
        POLICY_DAYS                             = V_POLICY_DAYS
        WHERE ins_conv_benf_seq_id              = v_ins_cash_benefit_seq_id;

END IF;

end if;

end save_product_cash_benefit;

--===================================================================================================
/*==============================================================================================
    Name       : select_prod_cash_benefit
    Created on : 20/05/2013
    Created By : sree krishna
    Comments   : --KOC1270
 ============================================================================================== */
  PROCEDURE select_prod_cash_benefit(
    v_ins_cash_benefit_seq_id            IN TPA_INS_CASH_BENEFIT.INS_CASH_BENEFIT_SEQ_ID%TYPE ,
    v_flag                               IN varchar2, --'HCB' hospital cash Benefit; 'CONV_BENEF' convalance benefit
    v_result_set                         OUT SYS_REFCURSOR
  )
  IS

vcnt number(1):=0;

  BEGIN

if v_flag = 'HCB' then

     OPEN v_result_set FOR
       SELECT
       a.ins_cash_benefit_seq_id,
       a.cash_benefit_plan_name,
       a.product_seq_id,
       a.scheme_id,
       a.cash_benefit_plan_code,
       a.group_reg_seq_id,
       a.policy_seq_id,
       a.from_age,
       a.to_age,
       A.ROOM_AMT,
       A.ACC_AMT,
       A.ICU_AMT,
       A.CONV_AMT,
       A.ROOM_DAYS_CLAIM,
       A.ACC_DAYS_CLAIM,
       A.ICU_DAYS_CLAIM,
       A.CONV_DAYS_CLAIM,
       A.ROOM_PER_SI,
       A.ACC_PER_SI,
       A.ICU_PER_SI,
       A.CONV_PER_SI,
       A.POLICY_DAYS
       FROM TPA_INS_CASH_BENEFIT a
       WHERE a.ins_cash_benefit_seq_id = v_ins_cash_benefit_seq_id;


elsif  v_flag = 'CONV_BENEF' then

     OPEN v_result_set FOR
       SELECT
       a.ins_conv_benf_seq_id,
       a.conv_benf_plan_name,
       a.product_seq_id,
       a.scheme_id,
       a.conv_benf_plan_code,
       a.group_reg_seq_id,
       a.policy_seq_id,
       a.from_age,
       a.to_age,
       A.CONV_AMT,
       A.CONV_DAYS_CLAIM,
       A.CONV_PER_SI,
       A.POLICY_DAYS
       FROM tpa_ins_canvalescence_benefit a
       WHERE a.ins_conv_benf_seq_id = v_ins_cash_benefit_seq_id;

elsif  v_flag = 'CRITICAL_BENEFIT' then   --koc1273

     OPEN v_result_set FOR
       SELECT
       a.critical_illness_config_seq_id,
       a.frm_age,
       a.to_age,
       a.age_optr,
       a.amount,
       a.surv_prd,
       a.critical_grp,
       a.no_of_times,
       a.group_reg_seq_id,
       a.policy_seq_id,
       A.PRODUCT_SEQ_ID,
       a.SUM_INS_PER,
       A.WAITING_PERIOD

       FROM critical_illness_config a
       WHERE a.critical_illness_config_seq_id = v_ins_cash_benefit_seq_id;


 end if;

  END select_prod_cash_benefit;

  --===================================================================================================
   /*==============================================================================================
    Name       : select_cash_benefit_list
    Created on : 20-MAY-13
    Created By : SREE KRISHNA
    Comments   : The list of CASH_BENEFIT plan for policy/product/group  --KOC1270
 ============================================================================================== */
PROCEDURE select_cash_benefit_list(
    v_seq_id                             IN NUMBER, -- prod_policy_seq_id
    v_flag                               IN VARCHAR2, -- 'PRD' -- PRODUCT, 'POL' -- POLICY
    v_cash_benefit_flg                   IN VARCHAR2, --'HCB' hospital cash Benefit; 'CONV_BENEF' convalance benefit
    v_sort_var                           IN  VARCHAR2,
    v_sort_order                         IN  VARCHAR2,
    v_start_num                          IN  NUMBER ,
    v_end_num                            IN  NUMBER ,
    v_added_by                           IN  NUMBER,
    v_result_set                         OUT SYS_REFCURSOR
  )
  IS
    v_sql_str                            VARCHAR2(4000);
    v_internal_seq_id                    NUMBER(20);
    CURSOR prod_policy_cur IS SELECT a.policy_seq_id,a.product_seq_id
      FROM tpa_ins_prod_policy a WHERE a.prod_policy_seq_id = v_seq_id ;
    prod_policy_rec              prod_policy_cur%ROWTYPE ;

  BEGIN
    OPEN prod_policy_cur;
    FETCH prod_policy_cur INTO prod_policy_rec;
    CLOSE prod_policy_cur;

    IF v_flag = 'PRD' THEN
      v_internal_seq_id := prod_policy_rec.product_seq_id;
    ELSE
      v_internal_seq_id := prod_policy_rec.policy_seq_id;
    END IF;


if v_cash_benefit_flg = 'HCB' then

    v_sql_str :=  ' SELECT
    a.ins_cash_benefit_seq_id,a.cash_benefit_plan_name,a.cash_benefit_plan_code,
     a.from_age, a.to_age ,a.room_amt,A.ACC_AMT,A.ICU_AMT,A.CONV_AMT,A.ROOM_DAYS_CLAIM,
     A.ACC_DAYS_CLAIM,A.ICU_DAYS_CLAIM,A.CONV_DAYS_CLAIM,A.ROOM_PER_SI,A.ACC_PER_SI,A.ICU_PER_SI,
     CONV_PER_SI,A.POLICY_DAYS
          FROM TPA_INS_CASH_BENEFIT a WHERE '||
     CASE WHEN v_flag = 'PRD' THEN ' a.product_seq_id = :v_internal_seq_id AND a.policy_seq_id IS NULL '
       ELSE '  a.policy_seq_id  = :v_internal_seq_id AND a.product_seq_id IS NULL '
     END;

elsif v_cash_benefit_flg = 'CONV_BENEF' then

   v_sql_str :=  ' SELECT
    a.ins_conv_benf_seq_id,a.conv_benf_plan_name,a.conv_benf_plan_code,
     a.from_age, a.to_age ,A.CONV_AMT
          FROM tpa_ins_canvalescence_benefit a WHERE '||
     CASE WHEN v_flag = 'PRD' THEN ' a.product_seq_id = :v_internal_seq_id AND a.policy_seq_id IS NULL '
       ELSE '  a.policy_seq_id  = :v_internal_seq_id AND a.product_seq_id IS NULL '
     END;

elsif v_cash_benefit_flg = 'CRITICAL_BENEFIT' then --koc1273

   v_sql_str :=  ' SELECT  a.critical_illness_config_seq_id,a.frm_age,A.TO_AGE,
        a.no_of_times,A.AMOUNT
     FROM critical_illness_config a  WHERE '||
     CASE WHEN v_flag = 'PRD' THEN ' a.product_seq_id = :v_internal_seq_id AND a.policy_seq_id IS NULL '
       ELSE '  a.policy_seq_id  = :v_internal_seq_id AND a.product_seq_id IS NULL '
     END;


end if;
     v_sql_str := 'SELECT * FROM
        (SELECT A.*,DENSE_RANK() OVER (ORDER BY '||v_sort_var||' '||v_sort_order||',ROWNUM)
        Q FROM (' ||v_sql_str|| ') A ) WHERE  Q>= :v_start_num AND Q<= :v_end_num ';

     OPEN v_result_set FOR v_sql_str USING v_internal_seq_id, v_start_num , v_end_num ;

  END select_cash_benefit_list;
  --KOC1270

--===================================================================================================


  --==============================================================================================
  --  Name       : si_restriction_rel
  --  Created on : 28-may-2012
  --  Created By : ravikumar
  --  Comments   : to restrict the amount for relations at the floater level
 --==============================================================================================

PROCEDURE si_restriction_rel (
          v_prod_policy_seq_id     IN Tpa_ins_prod_policy.prod_policy_seq_id%TYPE,
          v_si_restrc_yn           IN Tpa_ins_prod_policy.si_restrict_yn%TYPE:='N',
          v_si_relation            IN Tpa_ins_prod_policy.si_relation%TYPE,
          v_si_restrc_amt          IN Tpa_ins_prod_policy.si_restrict_amt%TYPE,
          v_si_restrc_perc         IN Tpa_ins_prod_policy.si_restrict_perc%TYPE,
          v_si_flag                IN Tpa_ins_prod_policy.si_type%TYPE,
          v_si_restrc_level        IN Tpa_ins_prod_policy.si_rest_level%TYPE,
          v_rest_age               IN Tpa_Ins_Prod_Policy.Rest_Age%TYPE,
          v_rest_age_amt           IN Tpa_Ins_Prod_Policy.Rest_Age_Amt%TYPE,
          v_added_by               IN Tpa_ins_prod_policy.added_by%TYPE,
          v_rows_processed         OUT NUMBER,
          v_alert                  OUT VARCHAR2
           ) is

 CURSOR cur_pol IS
   SELECT tep.policy_seq_id,teb.sum_insured,teb.balance_seq_id,teb.policy_group_seq_id,
   si_restrict_yn,Rest_Age
     FROM tpa_ins_prod_policy tip
     JOIN tpa_enr_policy tep  ON (tip.policy_seq_id=tep.policy_seq_id)
     JOIN tpa_enr_balance teb ON (tep.policy_seq_id=teb.policy_seq_id)
   WHERE tip.prod_policy_seq_id=v_prod_policy_seq_id;


  CURSOR cur_rel IS
  SELECT gt.si_relation,gt.rest_age,gt.rest_age_amt,si_restrict_yn
  FROM tpa_ins_prod_policy gt
  WHERE prod_policy_seq_id=v_prod_policy_seq_id AND gt.si_restrict_yn='Y';

  pol_cur               cur_pol%ROWTYPE;
  v_sum_ind             Tpa_ins_prod_policy.si_restrict_amt%TYPE;
  v_cnt                 NUMBER(5);
  v_age_old             Tpa_Ins_Prod_Policy.Rest_Age%TYPE;
  v_age_amt_old         Tpa_Ins_Prod_Policy.Rest_Age_Amt%TYPE;
  v_rel_old             Tpa_ins_prod_policy.si_relation%TYPE;
  v_relation_diff       Tpa_ins_prod_policy.si_relation%TYPE;
  v_pat_sum             pat_general_details.app_sum_insured%TYPE;
  v_clm_sum             clm_general_details.app_sum_insured%TYPE;
  v_tot_sum             Tpa_enr_balance.Sum_Insured%TYPE;
  v_old_fpr_yn          Tpa_Ins_Prod_Policy.Si_Restrict_Yn%TYPE;
  v_utli_restamt        Tpa_enr_balance.Used_Restrict_Amt%TYPE;
  v_result_set          sys_refcursor;
  v_str_char            Tpa_ins_prod_policy.si_relation%TYPE;


  FUNCTION f_rel_diff (v_old_str    IN Tpa_ins_prod_policy.si_relation%TYPE,
                       v_new_str    IN Tpa_ins_prod_policy.si_relation%TYPE)

   RETURN VARCHAR2 IS

    v_bar         Tpa_ins_prod_policy.si_relation%TYPE;
    v_delimit     CHAR(1):=NULL;
    BEGIN

    FOR jk IN
        (WITH t1 AS (SELECT ''''||REPLACE(v_old_str,'|',' , ')||'''' str FROM dual),
              t2 AS (SELECT ''''||REPLACE(v_new_str,'|',' , ')||'''' str FROM dual)

SELECT REPLACE(TRIM(val),'''','') as val
  FROM t1,
       xmltable('/root/e/text()'
       passing xmltype('<root><e>' ||REPLACE(t1.str,', ','</e><e>') ||'</e></root>')
       columns val VARCHAR2(15) path '/')
  MINUS
   SELECT REPLACE(TRIM(val),'''','') as val
     FROM t2,
       xmltable('/root/e/text()'
       passing xmltype('<root><e>' || REPLACE(t2.str,', ','</e><e>')||'</e></root>')
       columns val VARCHAR2(15) path '/')) LOOP
     v_bar := v_bar||v_delimit||jk.val;
     v_delimit := '|';

     END LOOP;
     RETURN v_bar;
   END;


  BEGIN
    IF v_si_relation IS NOT NULL THEN
       v_str_char := ''''||REPLACE(v_si_relation,'|',''',''')||'''';
    END IF;

    OPEN cur_rel;
    FETCH cur_rel INTO v_rel_old,v_age_old,v_age_amt_old,v_old_fpr_yn ;
    CLOSE cur_rel;

    v_relation_diff := f_rel_diff(v_rel_old,v_si_relation);


    UPDATE tpa_ins_prod_policy
      SET si_restrict_yn      = v_si_restrc_yn,
          si_relation         = v_si_relation,
          si_restrict_amt     = v_si_restrc_amt,
          si_restrict_perc    = v_si_restrc_perc,
          si_type             = v_si_flag,
          si_rest_level       = v_si_restrc_level,
          updated_by          = v_added_by,
          updated_date        = SYSDATE,
          Rest_Age            = v_rest_age,
          Rest_Age_Amt        = v_rest_age_amt
    WHERE prod_policy_seq_id  = v_prod_policy_seq_id;


     FOR jk IN cur_pol LOOP

      IF nvl(v_si_restrc_amt,0)>0 AND v_si_restrc_perc IS NOT NULL THEN
        IF v_si_restrc_level='LL' THEN
           v_sum_ind := least(v_si_restrc_amt,(v_si_restrc_perc/100)*jk.sum_insured);
        ELSE
           v_sum_ind := greatest(v_si_restrc_amt,(v_si_restrc_perc/100)*jk.sum_insured);
        END IF;
     ELSIF  nvl(v_si_restrc_amt,0)>0 and v_si_restrc_perc IS NULL THEN
            v_sum_ind :=  v_si_restrc_amt;
     ELSIF  nvl(v_si_restrc_amt,0)=0 and v_si_restrc_perc IS NOT NULL THEN
            v_sum_ind := (v_si_restrc_perc/100)*jk.sum_insured;
     END IF;

    IF v_old_fpr_yn='Y' then
    --- do validations
     SELECT COUNT(1) INTO v_cnt FROM tpa_enr_balance yt
     WHERE balance_seq_id = jk.balance_seq_id
     AND (/*v_sum_ind < yt.utilised_sum_insured OR*/ v_sum_ind < yt.used_restrict_amt);

    IF v_cnt>0 THEN
     v_alert := 'Amount of Precentage Cannot Be Reduced Less Then Utilised Sum Insured.';
     Rollback;
     Return;
     --raise_application_error(-20055,' You are Not Allowed to Make These Modifications ');
    END IF;

   IF v_relation_diff IS NOT NULL THEN -- relation removed

    SELECT COUNT(1) INTO v_cnt FROM pat_enroll_details u
      JOIN tpa_enr_policy_group v ON (v.policy_seq_id=u.policy_seq_id)
      JOIN tpa_enr_policy_member w ON (w.policy_group_seq_id=v.policy_group_seq_id and w.member_seq_id=u.member_seq_id)
     WHERE w.policy_group_seq_id=jk.policy_group_seq_id AND regexp_instr(w.relship_type_id,v_relation_diff)>0;

    SELECT COUNT(1) INTO v_cnt FROM clm_enroll_details u
      JOIN tpa_enr_policy_group v ON (v.policy_seq_id=u.policy_seq_id)
      JOIN tpa_enr_policy_member w ON (w.policy_group_seq_id=v.policy_group_seq_id and w.member_seq_id=u.member_seq_id)
     WHERE w.policy_group_seq_id=jk.policy_group_seq_id AND regexp_instr(w.relship_type_id,v_relation_diff)>0;

   IF v_cnt>0 THEN
     v_alert := 'Active Pre-auth/Claims Exist For The Relations Configured.';
     Rollback;
     Return;
     --raise_application_error(-20055,' You are Not Allowed to Make These Modifications ');
   END IF;

   END IF;

   IF v_rest_age < v_age_old THEN   -- if age changed
     SELECT COUNT(1) INTO v_cnt FROM pat_enroll_details u
      JOIN tpa_enr_policy_group v ON (v.policy_seq_id=u.policy_seq_id)
      JOIN tpa_enr_policy_member w ON (w.policy_group_seq_id=v.policy_group_seq_id and w.member_seq_id=u.member_seq_id)
     WHERE w.policy_group_seq_id=jk.policy_group_seq_id --AND regexp_instr(relship_type_id,v_relation_diff)>0
     and u.mem_age>=v_age_old;

    SELECT COUNT(1) INTO v_cnt FROM clm_enroll_details u
      JOIN tpa_enr_policy_group v ON (v.policy_seq_id=u.policy_seq_id)
      JOIN tpa_enr_policy_member w ON (w.policy_group_seq_id=v.policy_group_seq_id and w.member_seq_id=u.member_seq_id)
     WHERE w.policy_group_seq_id=jk.policy_group_seq_id --AND regexp_instr(relship_type_id,v_relation_diff)>0
     and u.mem_age>=v_age_old;

    IF v_cnt>0 THEN
     v_alert := 'Active Pre-auth/Claims Exist For The Previous Age Configured.';
     Rollback;
     Return;
      --raise_application_error(-20055,' You are Not Allowed to Make These Modifications ');
    END IF;

    END IF;

   IF v_rest_age_amt < v_age_amt_old Then -- if age amount is changed

     SELECT SUM(x.app_sum_insured) INTO v_pat_sum
      FROM pat_enroll_details u
      JOIN pat_general_details x on (x.pat_enroll_detail_seq_id=u.pat_enroll_detail_seq_id and X.pat_enhanced_yn='N')
      JOIN tpa_enr_policy_group v ON (v.policy_seq_id=u.policy_seq_id)
      JOIN tpa_enr_policy_member w ON (w.policy_group_seq_id=v.policy_group_seq_id and w.member_seq_id=u.member_seq_id)
     WHERE w.policy_group_seq_id=jk.policy_group_seq_id AND u.claim_id IS NULL AND regexp_instr(w.relship_type_id,NVL(v_relation_diff,'HPO'))>=0
     and u.mem_age>=v_age_old;

    SELECT SUM(x.app_sum_insured-nvl(z.app_sum_insured,0)) INTO v_clm_sum
      FROM clm_enroll_details u
      JOIN clm_general_details x on (u.claim_seq_id=x.claim_seq_id)
      JOIN tpa_enr_policy_group v ON (v.policy_seq_id=u.policy_seq_id)
      JOIN tpa_enr_policy_member w ON (w.policy_group_seq_id=v.policy_group_seq_id and w.member_seq_id=u.member_seq_id)
      left outer join pat_general_details z on (x.pat_enroll_detail_seq_id=z.pat_enroll_detail_seq_id and z.pat_enhanced_yn='N')
     WHERE w.policy_group_seq_id=jk.policy_group_seq_id AND regexp_instr(w.relship_type_id,NVL(v_relation_diff,'HPO'))>=0
     and u.mem_age>=v_age_old;
     v_tot_sum := nvl(v_pat_sum,0)+nvl(v_clm_sum,0);

    IF v_tot_sum > v_rest_age_amt THEN
       v_alert := 'Amount Cannot Be Reduced Less Then Utilised Sum Insured.';
       Rollback;
       Return;
       -- raise_application_error(-20055,' You are Not Allowed to Make These Modifications ');
    END IF;
    END IF;

    UPDATE Tpa_enr_balance  teb
     SET    teb.restrict_amt     = v_sum_ind
     WHERE  teb.policy_seq_id    = jk.policy_seq_id
     AND teb.balance_seq_id      = jk.balance_seq_id;


 ELSIF NVl(v_old_fpr_yn,'N')='N' AND v_si_restrc_yn='Y' THEN

   OPEN v_result_set FOR
   ' SELECT SUM(nvl(x.app_sum_insured,0)) --INTO v_pat_sum
      FROM pat_enroll_details u
      JOIN pat_general_details x on (x.pat_enroll_detail_seq_id=u.pat_enroll_detail_seq_id and x.pat_enhanced_yn=''N'')
      JOIN tpa_enr_policy_group v ON (v.policy_seq_id=u.policy_seq_id)
      JOIN tpa_enr_policy_member w ON (w.policy_group_seq_id=v.policy_group_seq_id and w.member_seq_id=u.member_seq_id)
     WHERE w.policy_group_seq_id='||jk.policy_group_seq_id||' AND w.relship_type_id in ('||v_str_char||')';
   FETCH v_result_set INTO v_pat_sum;
   CLOSE v_result_set;

   OPEN v_result_set FOR
    'SELECT SUM(nvl(x.app_sum_insured,0)-nvl(z.app_sum_insured,0))
      FROM clm_enroll_details u
      JOIN clm_general_details x on (u.claim_seq_id=x.claim_seq_id)
      JOIN tpa_enr_policy_group v ON (v.policy_seq_id=u.policy_seq_id)
      JOIN tpa_enr_policy_member w ON (w.policy_group_seq_id=v.policy_group_seq_id and w.member_seq_id=u.member_seq_id)
      left outer join pat_general_details z on (x.pat_enroll_detail_seq_id=z.pat_enroll_detail_seq_id and z.pat_enhanced_yn=''N'')
     WHERE w.policy_group_seq_id='||jk.policy_group_seq_id ||' AND w.relship_type_id in ('||v_str_char||')';
   FETCH v_result_set INTO v_clm_sum;
   CLOSE v_result_set;

    v_utli_restamt := nvl(v_pat_sum,0)+nvl(v_clm_sum,0);

    IF v_sum_ind < v_utli_restamt THEN
      v_alert := 'Amount Cannot Be configured more Then Utilised Sum Insured.';
       Rollback;
       Return;
     END IF;

  IF NVl(v_rest_age,0)>0  THEN

   OPEN v_result_set FOR
   ' SELECT SUM(nvl(x.app_sum_insured,0)) --INTO v_pat_sum
      FROM pat_enroll_details u
      JOIN pat_general_details x on (x.pat_enroll_detail_seq_id=u.pat_enroll_detail_seq_id and x.pat_enhanced_yn=''N'')
      JOIN tpa_enr_policy_group v ON (v.policy_seq_id=u.policy_seq_id)
      JOIN tpa_enr_policy_member w ON (w.policy_group_seq_id=v.policy_group_seq_id and w.member_seq_id=u.member_seq_id)
     WHERE w.policy_group_seq_id='||jk.policy_group_seq_id||' AND w.relship_type_id in ('||v_str_char||')
     AND u.mem_age>='|| v_rest_age;
   FETCH v_result_set INTO v_pat_sum;
   CLOSE v_result_set;

   OPEN v_result_set FOR
    'SELECT SUM(nvl(x.app_sum_insured,0)-nvl(z.app_sum_insured,0)) --INTO v_clm_sum
      FROM clm_enroll_details u
      JOIN clm_general_details x on (u.claim_seq_id=x.claim_seq_id)
      JOIN tpa_enr_policy_group v ON (v.policy_seq_id=u.policy_seq_id)
      JOIN tpa_enr_policy_member w ON (w.policy_group_seq_id=v.policy_group_seq_id and w.member_seq_id=u.member_seq_id)
      left outer join pat_general_details z on (x.pat_enroll_detail_seq_id=z.pat_enroll_detail_seq_id and z.pat_enhanced_yn=''N'')
     WHERE w.policy_group_seq_id='||jk.policy_group_seq_id ||' AND w.relship_type_id in ('||v_str_char||')
     AND u.mem_age>='|| v_rest_age;
   FETCH v_result_set INTO v_clm_sum;
   CLOSE v_result_set;

  v_tot_sum := nvl(v_pat_sum,0)+nvl(v_clm_sum,0);

  IF v_tot_sum > v_rest_age_amt THEN
       v_alert := 'Age Restriction Amount Cannot Be configured more Then Utilised Sum Insured.';
       Rollback;
       Return;
     END IF;
 END IF;

   UPDATE Tpa_enr_balance  teb
     SET    teb.restrict_amt      = v_sum_ind,
            teb.used_restrict_amt = v_utli_restamt
     WHERE  teb.policy_seq_id     = jk.policy_seq_id
     AND teb.balance_seq_id       = jk.balance_seq_id;

  END IF;
     END LOOP;

     v_rows_processed :=SQL%ROWCOUNT;
     v_alert := NULL /*'Y'*/;
      COMMIT;

   END si_restriction_rel;

--==============================================================================================
  --  Name       : si_restriction_rel
  --  Created on : 01-may-2012
  --  Created By : ravikumar
  --  Comments   : to restrict the amount for relations at the floater level
 --==================================================================================
  PROCEDURE select_si_restriction_rel(
    v_prod_policy_seq_id                IN   tpa_ins_prod_policy.prod_policy_seq_id%TYPE,
    v_result_set                        OUT SYS_REFCURSOR )
  IS
  BEGIN
     OPEN v_result_set FOR
       SELECT a.si_restrict_yn,a.si_relation,a.si_restrict_amt,a.si_restrict_perc,a.si_rest_level,a.rest_age,a.rest_age_amt
       FROM tpa_ins_prod_policy a
       WHERE a.prod_policy_seq_id = v_prod_policy_seq_id;
  END select_si_restriction_rel;

 /*==============================================================================================
    Name       : save_product_critical_benefit
    Created on : 24-JUN-08
    Created By : sree krishna.
    Comments   : koc1273
 ============================================================================================== */

PROCEDURE save_product_critical_benefit(
    V_CRITICAL_CONFIG_SEQ_ID             IN  OUT CRITICAL_ILLNESS_CONFIG.CRITICAL_ILLNESS_CONFIG_SEQ_ID%TYPE,
    V_FRM_AGE                            IN  CRITICAL_ILLNESS_CONFIG.FRM_AGE%TYPE,
    V_TO_AGE                             IN  CRITICAL_ILLNESS_CONFIG.TO_AGE%TYPE,
    V_AGE_OPTR                           IN  CRITICAL_ILLNESS_CONFIG.AGE_OPTR%TYPE,
    V_AMOUNT                             IN  CRITICAL_ILLNESS_CONFIG.AMOUNT%TYPE,
    V_SURV_PRD                           IN  CRITICAL_ILLNESS_CONFIG.SURV_PRD%TYPE,
    V_group_reg_seq_id                   IN  CRITICAL_ILLNESS_CONFIG.group_reg_seq_id%TYPE,
    V_policy_seq_id                      IN  CRITICAL_ILLNESS_CONFIG.policy_seq_id%TYPE,
    V_product_seq_id                     IN  CRITICAL_ILLNESS_CONFIG.product_seq_id%TYPE,
    V_CRITICAL_GRP                       IN  CRITICAL_ILLNESS_CONFIG.CRITICAL_GRP%TYPE,
    V_NO_OF_TIMES                        IN  CRITICAL_ILLNESS_CONFIG.NO_OF_TIMES%TYPE,
    V_SUM_INS_PER                        IN  CRITICAL_ILLNESS_CONFIG.SUM_INS_PER%TYPE,
    V_WAITING_PERIOD                     IN  CRITICAL_ILLNESS_CONFIG.WAITING_PERIOD%TYPE,
    v_rows_processed                     OUT NUMBER
    )
  IS

  BEGIN

--insert into ram.temp_rem values('seq_id  : '||V_CRITICAL_CONFIG_SEQ_ID);

IF nvl(V_CRITICAL_CONFIG_SEQ_ID,0) = 0  THEN

      INSERT INTO CRITICAL_ILLNESS_CONFIG(
        CRITICAL_ILLNESS_CONFIG_SEQ_ID,
        FRM_AGE,
        TO_AGE,
        AGE_OPTR,
        AMOUNT,
        SURV_PRD,
        CRITICAL_GRP,
        NO_OF_TIMES,
        GROUP_REG_SEQ_ID,
        POLICY_SEQ_ID,
        product_seq_id,
        SUM_INS_PER,
        WAITING_PERIOD)
      VALUES (
        CRITICAL_ILLNESS_CONFIG_SEQ.NEXTVAL,
        V_FRM_AGE,
        V_TO_AGE,
        V_AGE_OPTR,
        V_AMOUNT,
        V_SURV_PRD,
        V_CRITICAL_GRP,
        V_NO_OF_TIMES,
        V_GROUP_REG_SEQ_ID,
        V_policy_seq_id,
        V_product_seq_id,
        V_SUM_INS_PER,
        V_WAITING_PERIOD) RETURNING CRITICAL_ILLNESS_CONFIG_SEQ_ID INTO V_CRITICAL_CONFIG_SEQ_ID;

   v_rows_processed := SQL%ROWCOUNT;

ELSE

      UPDATE CRITICAL_ILLNESS_CONFIG
         SET FRM_AGE          = V_FRM_AGE,
             TO_AGE           = V_TO_AGE,
             AMOUNT           = V_AMOUNT,
             SURV_PRD         = V_SURV_PRD,
             CRITICAL_GRP     = V_CRITICAL_GRP,
             NO_OF_TIMES      = V_NO_OF_TIMES,
             GROUP_REG_SEQ_ID = v_group_reg_seq_id,
             policy_seq_id    = V_policy_seq_id,
             product_seq_id   = V_product_seq_id,
             SUM_INS_PER      = V_SUM_INS_PER,
             WAITING_PERIOD   = V_WAITING_PERIOD
       WHERE CRITICAL_ILLNESS_CONFIG_SEQ_ID = V_CRITICAL_CONFIG_SEQ_ID;

   v_rows_processed := SQL%ROWCOUNT;

END IF;

END save_product_critical_benefit;
--koc1273

/*==============================================================================================
    Name       : save_shortfall_email_config
    Created on : 22-05-2012
    Created By : Ibrahim Sayyed
    Company    : RCS Technologies
    Added for  : KOC1179
    Modifeid by: RAM
    Modified date: 12-12-2013
    Comments   : This procedure is used to store shorfall email/letter configured days(according to this days
    1.Reminder request, 2. Closer notice to insured 3.Approval closer notice to insurer 4.Claim closer to insurer emails/letters will go)
  ============================================================================================== */
PROCEDURE save_shortfall_email_config
  (v_config_seq_id              IN OUT     SHORTFALL_EMAIL_CONFIG.CONFIG_SEQ_ID%TYPE,
   v_prod_policy_seq_id            IN      SHORTFALL_EMAIL_CONFIG.PROD_POLICY_SEQ_ID%TYPE,
   v_remidner_letter_days          IN      SHORTFALL_EMAIL_CONFIG.REMINDER_LETTER_DAYS%TYPE,
   v_closer_notice_days            IN      SHORTFALL_EMAIL_CONFIG.CLOSER_NOTICE_DAYS%TYPE,
   v_approval_closer_days          IN      SHORTFALL_EMAIL_CONFIG.APPROVAL_CLOSER_DAYS%TYPE,
   v_claim_closer_letter_days      IN      SHORTFALL_EMAIL_CONFIG.claim_closer_letter_days%TYPE,
   v_clm_docs_submit_in_days       IN      SHORTFALL_EMAIL_CONFIG.clm_docs_submit_in_days%TYPE,
   v_clm_intimation_days           IN      SHORTFALL_EMAIL_CONFIG.clm_intimation_days%TYPE,
   v_regrett_letter_days           IN      SHORTFALL_EMAIL_CONFIG.regrett_letter_days%TYPE,
   v_added_by                      IN      SHORTFALL_EMAIL_CONFIG.ADDED_BY%TYPE,
   v_Post_Hosp_Days                IN      SHORTFALL_EMAIL_CONFIG.Post_Hosp_Days%TYPE)
   IS
BEGIN
  IF NVL(v_config_seq_id,0)=0 THEN
    INSERT INTO shortfall_email_config(config_seq_id,prod_policy_seq_id,clm_intimation_days,clm_docs_submit_in_days,reminder_letter_days,closer_notice_days,approval_closer_days,claim_closer_letter_days,regrett_letter_days,added_date,added_by,POST_HOSP_DAYS)
           VALUES(SEQ_SHORTFALL_EMAIL_CONFIG.Nextval,v_prod_policy_seq_id,v_clm_intimation_days,v_clm_docs_submit_in_days,v_remidner_letter_days,v_closer_notice_days,v_approval_closer_days, v_claim_closer_letter_days,v_regrett_letter_days, SYSDATE,v_added_by,v_Post_Hosp_Days) RETURNING config_seq_id INTO v_config_seq_id ;
  ELSE
    UPDATE shortfall_email_config
    SET    clm_docs_submit_in_days              =   v_clm_docs_submit_in_days,
           clm_intimation_days                  =   v_clm_intimation_days,
           reminder_letter_days                 =   v_remidner_letter_days,
           closer_notice_days                   =   v_closer_notice_days,
           approval_closer_days                 =   v_approval_closer_days,
           claim_closer_letter_days             =   v_claim_closer_letter_days,
           regrett_letter_days                  =   v_regrett_letter_days,
           updated_date                         =   SYSDATE,
           updated_by                           =   v_added_by,
           Post_Hosp_Days                       =   v_Post_Hosp_Days
   WHERE config_seq_id=V_config_seq_id;

  END IF;
END save_shortfall_email_config;
/*==============================================================================================
    Name       : select_shortfall_email_config
    Created on : 22-05-2012
    Created By : Ibrahim Sayyed
    Company    : RCS Technologies
    Added for  : KOC1179
    Modifeid by: RAM
    Modified date: 12-12-2013
    Comments   : This procedure is used to store shorfall email/letter configured days(according to this days
    1.Reminder request, 2. Closer notice to insured 3.Approval closer notice to insurer 4.Claim closer to insurer emails/letters will go)
  ============================================================================================== */
PROCEDURE select_shortfall_email_config
  (v_prod_policy_seq_id  IN OUT    SHORTFALL_EMAIL_CONFIG.PROD_POLICY_SEQ_ID%TYPE,
   v_result_set          OUT       SYS_REFCURSOR)
  IS
BEGIN
  OPEN v_result_set FOR
  SELECT a.config_seq_id,
         a.prod_policy_seq_id,
         a.clm_docs_submit_in_days,
         a.reminder_letter_days,
         a.closer_notice_days,
         a.approval_closer_days,
         a.claim_closer_letter_days,
         a.clm_intimation_days,
         a.regrett_letter_days,
         a.post_hosp_days post_hospitalization
       from shortfall_email_config a where a.prod_policy_seq_id=v_prod_policy_seq_id;
END select_shortfall_email_config;
--========================================================================================================
function prod_policy_clauses_exist( v_seq_id  IN  NUMBER,v_type varchar2) RETURN NUMBER

IS

V_COUNT NUMBER(3):=0;

BEGIN

if v_type='POL' THEN

SELECT COUNT(1) INTO  V_COUNT
 FROM TPA_INS_PROD_POLICY AA,TPA_PROD_POLICY_CLAUSES B
  WHERE AA.PROD_POLICY_SEQ_ID=B.PROD_POLICY_SEQ_ID
  AND B.CLAUSE_TYPE='SRT'
  AND AA.POLICY_SEQ_ID=v_seq_id;

ELSIF v_type='PROD' THEN

SELECT COUNT(1) INTO  V_COUNT
   FROM TPA_PROD_POLICY_CLAUSES A

    WHERE A.PROD_POLICY_SEQ_ID=v_seq_id
    AND A.CLAUSE_TYPE='SRT';

END IF;

RETURN V_COUNT;

END prod_policy_clauses_exist;
--================================================================
--SUMINSURED RESTRICTION
function get_max_restrict_amt(v_policy_seq_id        IN tpa_enr_policy.policy_seq_id%type,
                              v_policy_group_seq_id  IN tpa_enr_policy_group.policy_group_seq_id%type,
                              v_member_seq_id        IN tpa_enr_policy_member.member_seq_id%type,
                              v_flag                 IN CHAR) return number
is



CURSOR cur_pol IS
   SELECT tip.si_restrict_yn,tip.si_restrict_amt,tip.si_restrict_perc,tip.copay_yn,tip.copay_perc,sum(teb.sum_insured) sum_insured,sum(teb.utilised_sum_insured) utilised_sum_insured
     FROM tpa_ins_prod_policy tip
     JOIN tpa_enr_policy tep  ON (tip.policy_seq_id=tep.policy_seq_id)
     JOIN tpa_enr_balance teb ON (tep.policy_seq_id=teb.policy_seq_id)
   WHERE tep.policy_seq_id=v_policy_seq_id  and teb.policy_group_seq_id=v_policy_group_seq_id
   and (v_member_seq_id is not null and teb.member_seq_id=v_member_seq_id or v_member_seq_id is null and teb.member_seq_id is null)
   group by tip.si_restrict_yn,tip.si_restrict_amt,tip.si_restrict_perc,tip.copay_yn,tip.copay_perc;

pol_rec               cur_pol%rowtype;
v_si_restrict_amt     tpa_ins_prod_policy.si_restrict_amt%type:=0;
v_copay_restrict_amt  tpa_ins_prod_policy.si_restrict_amt%type:=0;
v_max_restrict_amt    tpa_ins_prod_policy.si_restrict_amt%type;
v_tot_amt             tpa_ins_prod_policy.si_restrict_amt%type;

begin

open cur_pol;
fetch cur_pol into pol_rec;
close cur_pol;

if pol_rec.si_restrict_yn='Y' THEN
  IF nvl(pol_rec.si_restrict_amt,0)>0 AND pol_rec.si_restrict_perc IS NOT NULL THEN
      v_si_restrict_amt := least(pol_rec.si_restrict_amt,(pol_rec.si_restrict_perc/100)*pol_rec.sum_insured);
  ELSIF  nvl(pol_rec.si_restrict_amt,0)>0 and pol_rec.si_restrict_perc IS NULL THEN
      v_si_restrict_amt :=  pol_rec.si_restrict_amt;
  ELSIF  nvl(pol_rec.si_restrict_amt,0)=0 and pol_rec.si_restrict_perc IS NOT NULL THEN
      v_si_restrict_amt := (pol_rec.si_restrict_perc/100)*pol_rec.sum_insured;
  END IF;
ELSE
  v_si_restrict_amt:=0;
END IF;

IF pol_rec.copay_yn='Y' THEN
   if nvl(pol_rec.copay_perc,0)>0 then
    v_copay_restrict_amt:=(pol_rec.copay_perc/100)*pol_rec.sum_insured;
   END IF;
elsE
    v_copay_restrict_amt:=0;
END IF;

if v_si_restrict_amt>0 and v_copay_restrict_amt>0 then
   v_max_restrict_amt:=v_si_restrict_amt-v_copay_restrict_amt;
elsif v_si_restrict_amt=0 and v_copay_restrict_amt=0 then
   v_max_restrict_amt:=pol_rec.sum_insured;
elsif v_si_restrict_amt>0 and v_copay_restrict_amt=0 then
   v_max_restrict_amt:= v_si_restrict_amt;
elsif v_si_restrict_amt=0 and v_copay_restrict_amt>0 then
   v_max_restrict_amt:=pol_rec.sum_insured-v_copay_restrict_amt;
end if;

if v_flag='AB' THEN
   v_tot_amt:=v_max_restrict_amt-pol_rec.utilised_sum_insured;
ELSIF v_flag='RB' THEN
   v_tot_amt:=v_max_restrict_amt;
END IF;

return v_tot_amt;

END get_max_restrict_amt;
--============================================================================
PROCEDURE  save_buffer_level_limits(v_buff_level_seq_id    IN OUT tpa_enr_buffer_level_config.buff_level_seq_id%type,
                                    v_prod_policy_seq_id   IN tpa_enr_policy.policy_seq_id%type,
                                    v_buffer_type          IN tpa_enr_buffer_level_config.buffer_type%type,
                                    v_level_type           IN tpa_enr_buffer_level_config.Level_Type%TYPE,
                                    v_level_limit          IN tpa_enr_buffer_level_config.Level_Limit%TYPE,
                                    v_remarks              IN tpa_enr_buffer_level_config.Remarks%TYPE,
                                    v_added_by             IN tpa_enr_buffer_level_config.added_by%type,
                                    v_alert                              OUT VARCHAR2,
                                    v_rows_processed       OUT NUMBER) 
IS

CURSOR buffer_cur is
 select count(1) from tpa_enr_buffer_level_config a
 where a.prod_policy_seq_id=v_prod_policy_seq_id
 and buffer_type =v_buffer_type 
 and a.buff_level_seq_id!=nvl(v_buff_level_seq_id,0)
 and level_type=v_level_type;

CURSOR buffer_level_cur is
 select a.level_limit from tpa_enr_buffer_level_config a
 where a.buff_level_seq_id=v_buff_level_seq_id
 and buffer_type =v_buffer_type 
 and level_type=v_level_type;  


CURSOR buffer_detail_cur(v_policy_seq_id  tpa_enr_policy.policy_seq_id%type) is
 select b.buffer_seq_id,c.total_buffer_amount,c.tot_med_buff_amount,
 c.tot_crit_buff_amount,c.tot_crit_corp_buff_amount,c.tot_crit_med_buff_amount from  tpa_enr_buffer_details b
 join tpa_enr_policy c on (b.policy_seq_id=c.policy_seq_id)
 where b.policy_seq_id=v_policy_seq_id
 and (b.buffer_alloc_amount is not null 
     or b.crit_corp_buff_alloc_amount is not null 
     or b.med_buff_alloc_amount is not null 
     or b.crit_med_buff_alloc_amount is not null)
 order by b.added_date desc; 

 
  CURSOR bal_cur(v_policy_seq_id tpa_enr_balance.policy_seq_id%type) IS 
    SELECT nvl(a.buffer_amount,0) buffer_amount,nvl(a.med_buffer_amount,0) med_buffer_amount,nvl(a.critical_buff_amount,0) critical_buff_amount,nvl(a.critical_corp_buff_amount,0) critical_corp_buff_amount,nvl(a.critical_med_buff_amount,0) critical_med_buff_amount,
           nvl(a.utilised_buff_amount,0) utilised_buff_amount,nvl(a.utilised_med_buff_amount,0) utilised_med_buff_amount,nvl(a.utilised_crit_buff_amount,0) utilised_crit_buff_amount,nvl(a.utilised_crit_corp_buff_amt,0) utilised_crit_corp_buff_amt,nvl(a.utilised_crit_med_buff_amt,0) utilised_crit_med_buff_amt
           FROM tpa_enr_balance a
    where a.policy_seq_id=v_policy_seq_id
    order by a.policy_group_seq_id ;
    
  bal_rec  bal_cur%ROWTYPE;


  buffer_detail_rec  buffer_detail_cur%rowtype; 
  buffer_level_rec   buffer_level_cur%rowtype;                                                                              
  v_count            number;  
  v_policy_seq_id  tpa_enr_policy.policy_seq_id%type;

BEGIN
  
   SELECT a.policy_seq_id      INTO v_policy_seq_id 
       FROM tpa_ins_prod_policy a JOIN tpa_enr_policy b ON ( a.policy_seq_id = b.policy_seq_id )
      WHERE a.prod_policy_seq_id = v_prod_policy_seq_id;

  OPEN  buffer_cur;
  FETCH buffer_cur INTO v_count;
  CLOSE buffer_cur;
  
 IF  v_count>0 THEN
      raise_application_error(-20990,'Level is already Configured for the selected Buffer Type.');
 END IF;

   
 OPEN buffer_detail_cur(v_policy_seq_id);
 FETCH buffer_detail_cur INTO buffer_detail_rec;
 CLOSE buffer_detail_cur; 
 
 IF  buffer_detail_rec.buffer_seq_id is null  THEN
    v_alert:='Please Configure Buffer Amount First.';  
 ELSE
   IF v_buffer_type='NCOR' AND  v_level_limit>buffer_detail_rec.Total_Buffer_Amount THEN
     v_alert:='You cannot configure Normal Corpus Buffer Limit beyond the Available Normal Corpus Buffer Amount.'; 
   ELSIF v_buffer_type='NMED' AND  v_level_limit>buffer_detail_rec.tot_med_buff_amount THEN
     v_alert:='You cannot configure Medical Buffer Limit beyond the Available Medical Buffer Amount.';
   ELSIF v_buffer_type='CILN' AND  v_level_limit>buffer_detail_rec.tot_crit_buff_amount THEN
     v_alert:='You cannot configure Critical illness Buffer Limit beyond the Available Critical illness  Buffer Amount.';
   ELSIF v_buffer_type='CCOR' AND  v_level_limit>buffer_detail_rec.tot_crit_corp_buff_amount THEN
     v_alert:='You cannot configure Critical Corpus Buffer Limit beyond the Available Critical Corpus Buffer Amount.';
   ELSIF v_buffer_type='CMED' AND  v_level_limit>buffer_detail_rec.tot_crit_med_buff_amount THEN
     v_alert:='You cannot configure Critical Medical Buffer Limit beyond the Available Critical Medical Buffer Amount.';
   END IF;
 END IF;  
 
  FOR bal_rec IN bal_cur(v_policy_seq_id) LOOP
       IF  v_buffer_type='NCOR' AND  bal_rec.Buffer_Amount>nvl(v_level_limit,0) AND bal_rec.Utilised_Buff_Amount>nvl(v_level_limit,0) THEN
         v_alert:='You cannot reduce the Normal Corpus Buffer Level Limit , as the amount is less than the  Utilised Normal Corpus Buffer.';
       ELSIF  v_buffer_type='NMED' AND  bal_rec.med_buffer_amount>nvl(v_level_limit,0) AND bal_rec.utilised_med_buff_amount>nvl(v_level_limit,0) THEN
         v_alert:='You cannot reduce the Normal Medical Buffer Level Limit , as the amount is less than the  Utilised Normal Medical Buffer.';
       ELSIF  v_buffer_type='CILN' AND  bal_rec.critical_buff_amount>nvl(v_level_limit,0) AND bal_rec.utilised_crit_buff_amount>nvl(v_level_limit,0) THEN
         v_alert:='You cannot reduce the Critical illness Buffer Level Limit , as the amount is less than the  Utilised Critical illness Buffer.';
       ELSIF  v_buffer_type='CCOR' AND  bal_rec.critical_corp_buff_amount>nvl(v_level_limit,0) AND bal_rec.utilised_crit_corp_buff_amt>nvl(v_level_limit,0) THEN
         v_alert:='You cannot reduce the Critical Corpus Buffer Level Limit , as the amount is less than the  Utilised Critical Corpus Buffer.';
       ELSIF  v_buffer_type='CMED' AND  bal_rec.critical_med_buff_amount>nvl(v_level_limit,0) AND bal_rec.utilised_crit_med_buff_amt>nvl(v_level_limit,0) THEN
         v_alert:='You cannot reduce the Critical Medical Buffer Level Limit, as the amount is less than the  Utilised Critical Medical Buffer.';
       END IF;
   END LOOP;
     
 IF v_alert is not null then
      rollback;
      return;
 END IF; 
 
 
 IF NVL(v_buff_level_seq_id,0)=0 THEN
    
  INSERT INTO tpa_enr_buffer_level_config(
              buff_level_seq_id,
              prod_policy_seq_id,
              buffer_type,
              level_type,
              level_limit,
              remarks,
              added_by,
              added_date,
              policy_seq_id)
      VALUES ( tpa_enr_buff_level_seq.nextval,
               v_prod_policy_seq_id,
               v_buffer_type,
               v_level_type,
               v_level_limit,
               v_remarks,
               v_added_by,
               sysdate,
               v_policy_seq_id) RETURNING buff_level_seq_id INTO v_buff_level_seq_id;
               
                                
 ELSE    
  

   UPDATE tpa_enr_buffer_level_config
          SET buffer_type  = v_buffer_type,
              level_type   = v_level_type,
              level_limit  = v_level_limit,
              remarks      = v_remarks,
              updated_by   = v_added_by,
              updated_date = SYSDATE
   WHERE buff_level_seq_id = v_buff_level_seq_id;
   
 END IF;
v_rows_processed:=SQL%ROWCOUNT;
COMMIT;

END save_buffer_level_limits;
--============================================================================
PROCEDURE  del_buffer_level_limits(v_buff_level_seq_ids   IN VARCHAR2,
                                   v_prod_policy_seq_id        IN tpa_enr_buffer_level_config.prod_policy_seq_id%TYPE,
                                   v_buffer_type          IN tpa_enr_buffer_level_config.buffer_type%type,
                                   v_added_by             IN tpa_enr_buffer_level_config.added_by%type,
                                   v_rows_processed       OUT NUMBER)
IS


 
CURSOR clm_cur(v_policy_seq_id  tpa_enr_policy.policy_seq_id%type,
               v_buffer_type    tpa_enr_buffer_level_config.buffer_type%type) IS
SELECT COUNT(1) FROM clm_enroll_details a
JOIN clm_general_details b ON (a.claim_seq_id=b.claim_seq_id)
JOIN buffer_details c ON (b.claim_seq_id=c.claim_seq_id)
WHERE c.buffer_status_general_type_id='BAP'
and c.claim_type=case when (v_buffer_type='NCOR' OR v_buffer_type='NMED') THEN 'NRML' ELSE 'CRTL' END
and c.Buffer_Type=case when v_buffer_type='CILN' THEN 'CRTB' WHEN  (v_buffer_type='CCOR'  OR v_buffer_type='NCOR')  THEN 'CORB' ELSE 'MEDB' END
AND c.buffer_app_amount>0
and a.policy_seq_id=v_policy_seq_id;

CURSOR pat_cur(v_policy_seq_id  tpa_enr_policy.policy_seq_id%type,
              v_buffer_type    tpa_enr_buffer_level_config.buffer_type%type) IS
SELECT COUNT(1) FROM pat_enroll_details a
JOIN pat_general_details b ON (a.pat_enroll_detail_seq_id=b.pat_enroll_detail_seq_id and b.pat_enhanced_yn='N')
JOIN buffer_details c ON (b.Pat_Gen_Detail_Seq_Id=c.Pat_Gen_Detail_Seq_Id)
WHERE c.buffer_status_general_type_id='BAP'
AND c.buffer_app_amount>0
and c.claim_type=case when (v_buffer_type='NCOR' OR v_buffer_type='NMED') THEN 'NRML' ELSE 'CRTL' END
and c.Buffer_Type=case when v_buffer_type='CILN' THEN 'CRTB' WHEN  (v_buffer_type='CCOR'  OR v_buffer_type='NCOR')  THEN 'CORB' ELSE 'MEDB' END
and a.policy_seq_id=v_policy_seq_id; 

CURSOR get_buff_type_cur(v_buff_level_seq_id tpa_enr_buffer_level_config.buff_level_seq_id%type) IS
SELECT a.buffer_type FROM tpa_enr_buffer_level_config A
WHERE A.Buff_Level_Seq_Id=v_buff_level_seq_id;

v_pat_count      number;
v_clm_count      number;

str_tab          ttk_util_pkg.str_table_type;
v_policy_seq_id  tpa_enr_policy.policy_seq_id%type;

get_buff_type    get_buff_type_cur%rowtype;

BEGIN

str_tab:=ttk_util_pkg.parse_str(v_buff_level_seq_ids);

 SELECT a.policy_seq_id      INTO v_policy_seq_id 
       FROM tpa_ins_prod_policy a JOIN tpa_enr_policy b ON ( a.policy_seq_id = b.policy_seq_id )
      WHERE a.prod_policy_seq_id = v_prod_policy_seq_id;
 
IF str_tab.FIRST IS NOT NULL THEN  
 FOR i IN str_tab.FIRST..str_tab.LAST LOOP
   
 OPEN get_buff_type_cur(str_tab(i));
 FETCH get_buff_type_cur INTO get_buff_type;
 CLOSE get_buff_type_cur;
 
 OPEN pat_cur(v_policy_seq_id,get_buff_type.buffer_type) ;
 FETCH pat_cur INTO v_pat_count;
 CLOSE pat_cur;
 
 OPEN clm_cur(v_policy_seq_id,get_buff_type.buffer_type);
 FETCH clm_cur INto v_clm_count;
 CLOSE clm_cur;
 
 IF v_pat_count>0 OR  v_clm_count>0 THEN
   raise_application_error(-20993,'You cannot delete the limits as there are preauth/claims exist.');   
 END IF; 
  DELETE FROM tpa_enr_buffer_level_config A WHERE A.buff_level_seq_id=str_tab(i);
 END LOOP;
  
END IF  ;

v_rows_processed:=SQL%ROWCOUNT; 
COMMIT;

END del_buffer_level_limits;
--============================================================================
PROCEDURE  select_buff_level_limits_list(v_prod_policy_seq_id     IN tpa_enr_buffer_level_config.prod_policy_seq_id%TYPE,
                                      v_added_by             IN tpa_enr_buffer_level_config.added_by%type,
                                      v_result_set           OUT SYS_REFCURSOR)
IS


BEGIN
OPEN v_result_set FOR 
   SELECT a.buff_level_seq_id,
          a.prod_policy_seq_id,
          B.DESCRIPTION buffer_type,
          a.level_type,
          a.level_limit,
          a.remarks,
          b.general_type_id,
          C.DESCRIPTION AS level_DESC
   FROM tpa_enr_buffer_level_config a
   LEFT OUTER JOIN TPA_GENERAL_CODE B ON (A.BUFFER_TYPE=B.GENERAL_TYPE_ID)
   LEFT OUTER JOIN TPA_GENERAL_CODE C ON (A.LEVEL_TYPE=C.GENERAL_TYPE_ID)
   where a.prod_policy_seq_id=v_prod_policy_seq_id
   order by a.buff_level_seq_id desc;   

END select_buff_level_limits_list;
--============================================================================
PROCEDURE  select_buff_level_limit(v_buff_level_seq_id       IN tpa_enr_buffer_level_config.buff_level_seq_id%TYPE,
                                   v_result_set              OUT SYS_REFCURSOR)
IS


BEGIN
OPEN v_result_set FOR 
   SELECT a.buff_level_seq_id,
          a.prod_policy_seq_id,
          a.buffer_type,
          a.level_type,
          a.level_limit,
          a.remarks
   FROM tpa_enr_buffer_level_config a
   where a.buff_level_seq_id=v_buff_level_seq_id;

END select_buff_level_limit;
--============================================================================

--SUMINSURED RESTRICTION
function get_max_restrict_amt_rel(v_policy_seq_id        IN tpa_enr_policy.policy_seq_id%type,
                              v_policy_group_seq_id  IN tpa_enr_policy_group.policy_group_seq_id%type,
                              v_member_seq_id        IN tpa_enr_policy_member.member_seq_id%type,
                              v_flag                 IN CHAR) return number
is

CURSOR cur_pol IS
   SELECT tpm.relship_type_id,tip.si_restrict_yn,tip.si_restrict_amt,tip.si_restrict_perc,tip.copay_yn,tip.copay_perc,sum(teb.sum_insured) sum_insured,sum(teb.utilised_sum_insured) utilised_sum_insured
     FROM tpa_ins_prod_policy tip
     JOIN tpa_enr_policy tep  ON (tip.policy_seq_id=tep.policy_seq_id)
     JOIN tpa_enr_balance teb ON (tep.policy_seq_id=teb.policy_seq_id)
     JOIN tpa_enr_policy_member tpm ON (teb.policy_group_seq_id=tpm.policy_group_seq_id)
   WHERE tep.policy_seq_id=v_policy_seq_id  and teb.policy_group_seq_id=v_policy_group_seq_id
   and (v_member_seq_id is not null and tpm.member_seq_id=v_member_seq_id or v_member_seq_id is null and teb.member_seq_id is null)
   group by tip.si_restrict_yn,tip.si_restrict_amt,tip.si_restrict_perc,tip.copay_yn,tip.copay_perc,tpm.relship_type_id;
   
pol_rec               cur_pol%rowtype;
v_si_restrict_amt     tpa_ins_prod_policy.si_restrict_amt%type:=0;
v_copay_restrict_amt  tpa_ins_prod_policy.si_restrict_amt%type:=0;
v_max_restrict_amt    tpa_ins_prod_policy.si_restrict_amt%type;
v_tot_amt             tpa_ins_prod_policy.si_restrict_amt%type;
v_relation            Tpa_ins_prod_policy.si_relation%TYPE;

begin
  
open cur_pol;
fetch cur_pol into pol_rec;
close cur_pol; 
FOR jk IN
 (with t as 

(
  select si_relation str from tpa_ins_prod_policy where policy_seq_id=v_policy_seq_id and si_restrict_yn='Y'
)

select trim(x.column_value.extract('e/text()')) cols 
   from t t, table (xmlsequence(xmltype('<e><e>' || replace(t.str,'|','</e><e>')|| '</e></e>').extract('e/e'))) x) LOOP
   
   v_relation := jk.cols;
   
if pol_rec.si_restrict_yn='Y'  THEN
  IF pol_rec.relship_type_id=v_relation THEN
  IF nvl(pol_rec.si_restrict_amt,0)>0 AND pol_rec.si_restrict_perc IS NOT NULL THEN
      v_si_restrict_amt := least(pol_rec.si_restrict_amt,(pol_rec.si_restrict_perc/100)*pol_rec.sum_insured);
  ELSIF  nvl(pol_rec.si_restrict_amt,0)>0 and pol_rec.si_restrict_perc IS NULL THEN
      v_si_restrict_amt :=  pol_rec.si_restrict_amt;
  ELSIF  nvl(pol_rec.si_restrict_amt,0)=0 and pol_rec.si_restrict_perc IS NOT NULL THEN
      v_si_restrict_amt := (pol_rec.si_restrict_perc/100)*pol_rec.sum_insured;
  END IF;
  End IF;
ELSE
    v_si_restrict_amt:=0;
END IF;

 END LOOP;

IF pol_rec.copay_yn='Y' THEN
   if nvl(pol_rec.copay_perc,0)>0 then
    v_copay_restrict_amt:=(pol_rec.copay_perc/100)*pol_rec.sum_insured;
   END IF;
elsE
    v_copay_restrict_amt:=0;
END IF;

if v_si_restrict_amt>0 and v_copay_restrict_amt>0 then
   v_max_restrict_amt:=v_si_restrict_amt-v_copay_restrict_amt;
elsif v_si_restrict_amt=0 and v_copay_restrict_amt=0 then
   v_max_restrict_amt:=pol_rec.sum_insured;
elsif v_si_restrict_amt>0 and v_copay_restrict_amt=0 then
   v_max_restrict_amt:= v_si_restrict_amt;
elsif v_si_restrict_amt=0 and v_copay_restrict_amt>0 then
   v_max_restrict_amt:=pol_rec.sum_insured-v_copay_restrict_amt;
end if;

if v_flag='AB' THEN
   v_tot_amt:=v_max_restrict_amt-pol_rec.utilised_sum_insured;
ELSIF v_flag='RB' THEN
   v_tot_amt:=v_max_restrict_amt;
END IF;

return v_tot_amt;

END get_max_restrict_amt_rel;


  --===============================================================================
  -- Author  : KISHOR KUMAR S.H
  -- Created : 14/05/2014
  -- Purpose : Used in Adminsitration-.Configuration->Hospital Configuration->Web Login Links Save
  --===============================================================================
  PROCEDURE save_weblogin_hosp_links(
    v_weblink_seq_id                  IN  OUT WEBLOGIN_HOSP_LINKS.weblink_seq_id%TYPE,
    v_prod_policy_seq_id              IN  tpa_hosp_info.hosp_seq_id%TYPE,
    v_show_web_link_yn                IN  WEBLOGIN_HOSP_LINKS.show_web_link_yn%TYPE,
    v_link_description                IN  WEBLOGIN_HOSP_LINKS.link_description%TYPE,
    v_link_order_number               IN  WEBLOGIN_HOSP_LINKS.link_order_number%TYPE,
    v_link_path                       IN  WEBLOGIN_HOSP_LINKS.link_path%TYPE,
    v_added_by                        IN  NUMBER,
    v_rows_processed                  OUT INTEGER
  )
  IS
    v_ctr_logo                        NUMBER(1);
    v_ctr_comp                        NUMBER(1);
    v_ctr_comp_text                   NUMBER(1);
    v_ctr_comp_image                   NUMBER(1);
  BEGIN

       IF v_ctr_logo > 0 THEN
        raise_application_error(-20551, ' Logo/CompanyName/Company Text already exists. ' );
      END IF;

      IF v_ctr_comp > 0 THEN
        raise_application_error(-20551, ' Logo/CompanyName/Company Text already exists. ' );
      END IF;

      IF v_ctr_comp_text > 0 THEN
        raise_application_error(-20551, ' Logo/CompanyName/Company Text already exists. ' );
      END IF;

      IF v_ctr_comp_image > 0 THEN
        raise_application_error(-20677, 'Company Name Image/Company Name Text already exists. ' );
      END IF;

       IF v_weblink_seq_id = 0 THEN
         INSERT INTO WEBLOGIN_HOSP_LINKS(
           weblink_seq_id,
           hosp_seq_id,
           show_web_link_yn,
           link_description,
           link_order_number,
           link_path,
           added_by,
           added_date)
         VALUES(
           weblogin_links_seq.nextval,
           v_prod_policy_seq_id,
           v_show_web_link_yn,
           v_link_description,
           v_link_order_number,
           v_link_path,
           v_added_by,
           SYSDATE ) RETURNING weblink_seq_id INTO v_weblink_seq_id;
       ELSE
          /* UPDATE weblogin_links SET
            show_web_link_yn           = v_show_web_link_yn,
            link_description           = v_link_description,
            link_general_type_id       = v_link_general_type_id,
            link_order_number          = v_link_order_number,
            link_path                  = v_link_path,
            pre_report_general_type_id = v_pre_report_general_type_id,
            updated_by                 = v_added_by,
            updated_date               = SYSDATE
        WHERE weblink_seq_id = v_weblink_seq_id AND prod_policy_seq_id = v_prod_policy_seq_id;
        */
        dbms_output.put_line(v_prod_policy_seq_id);
       END IF;
       v_rows_processed := SQL%ROWCOUNT;
       COMMIT;
  END save_weblogin_hosp_links;
  
  --==============================================================================================
  -- Author  : Kishor Kumar
  -- Created : 15/04/2014
  -- Purpose : Used in Adminsitration-.Policies->WebConfig->Web Login Links Select
  --===============================================================================
  PROCEDURE select_weblogin_hosplink_list(
    v_sort_var                          IN   VARCHAR2,
    v_sort_order                        IN   VARCHAR2,
    v_start_num                         IN   NUMBER,
    v_end_num                           IN   NUMBER,
    v_added_by                          IN   NUMBER,
    result_set                          OUT  SYS_REFCURSOR
  )
  IS
    v_sql_str   VARCHAR2 (4000);
  BEGIN
    --diaplay only non logically deleted records
    v_sql_str :=
      'SELECT A.weblink_seq_id,
             A.link_description,
             A.link_description AS TYPE,
             A.link_order_number
          FROM WEBLOGIN_HOSP_LINKS A';

    v_sql_str :='SELECT * FROM
                    (SELECT A.*,DENSE_RANK() OVER (ORDER BY '|| v_sort_var|| ' '|| v_sort_order|| ',ROWNUM)
                      Q FROM ('|| v_sql_str|| ') A ) WHERE  Q>= :v_start_num  AND Q<= :v_end_num ';

    OPEN result_set FOR v_sql_str USING v_start_num, v_end_num ;
  END select_weblogin_hosplink_list;

  --===============================================================================
  -- Author  : KISHOR KUMAR S H
  -- Created : 15/05/2014
  -- Purpose : Used in Adminsitration-.cONFIGURATION->Web Login Links Delete
  --===============================================================================
  PROCEDURE web_hosp_link_delete (
      v_weblink_seq_id                IN  VARCHAR2, -- conacatenated string of weblink seq id |seq_id1|seq_id1|....|
      v_added_by                      IN  NUMBER,
      v_rows_processed                OUT INTEGER
   )
   IS
    str_tab                    ttk_util_pkg.str_table_type;
  BEGIN
    str_tab := ttk_util_pkg.parse_str (v_weblink_seq_id);
    FOR i IN str_tab.FIRST .. str_tab.LAST
    LOOP
        DELETE FROM weblogin_hosp_links WHERE weblink_seq_id = TO_NUMBER (str_tab (i));
    END LOOP;
      --returns no.. of rows updated/inserted
    v_rows_processed := str_tab.LAST;
    COMMIT;
  END web_hosp_link_delete;
---=================================================================================
PROCEDURE save_pre_approval_limit(
    v_prod_policy_seq_id                IN tpa_ins_prod_policy.prod_policy_seq_id%TYPE,
    v_vip_pre_aprvl_limit_yn            IN tpa_ins_prod_policy.VIP_PRE_APRVL_LIMIT_YN%TYPE,
    v_vip_aprvl_limit                   IN tpa_ins_prod_policy.VIP_PRE_APRVL_LIMIT%TYPE,
    v_vip_mdt_srvce_pre_aprvl_yn        IN tpa_ins_prod_policy.VIP_MDT_SRVCE_PRE_APRVL_YN%TYPE,
    v_non_vip_pre_aprvl_limit_yn        IN tpa_ins_prod_policy.NON_VIP_PRE_APRVL_LIMIT_YN%TYPE,
    v_non_vip_aprvl_limit               IN tpa_ins_prod_policy.NON_VIP_PRE_APRVL_LIMIT%TYPE,
    v_non_vip_mdt_srv_pre_aprvl_yn      IN tpa_ins_prod_policy.NON_VIP_MDT_SRVCE_PRE_APRVL_YN%TYPE,
    v_added_by                          IN tpa_ins_prod_policy.added_by%TYPE,
    v_rows_processed                    OUT NUMBER
  )
  IS
  BEGIN

     UPDATE tpa_ins_prod_policy SET
       vip_pre_aprvl_limit_yn	        =	v_vip_pre_aprvl_limit_yn,
       vip_pre_aprvl_limit		        = v_vip_aprvl_limit,
       vip_mdt_srvce_pre_aprvl_yn		  = v_vip_mdt_srvce_pre_aprvl_yn,
       non_vip_pre_aprvl_limit_yn		  = v_non_vip_pre_aprvl_limit_yn,
       non_vip_pre_aprvl_limit		    = v_non_vip_aprvl_limit,
       non_vip_mdt_srvce_pre_aprvl_yn	=	v_non_vip_mdt_srv_pre_aprvl_yn,
       updated_by                     = v_added_by,
       updated_date                   = SYSDATE
     WHERE prod_policy_seq_id =  v_prod_policy_seq_id;

     v_rows_processed := SQL%ROWCOUNT;
     COMMIT;

  END save_pre_approval_limit;
 --=============================================================================
 
 PROCEDURE select_pre_approval_limit(
    v_prod_policy_seq_id                IN   tpa_ins_prod_policy.prod_policy_seq_id%TYPE,
    v_result_set                        OUT SYS_REFCURSOR
  )
  IS
  BEGIN
     OPEN v_result_set FOR
      SELECT a.vip_pre_aprvl_limit_yn,
             a.vip_pre_aprvl_limit,
             a.vip_mdt_srvce_pre_aprvl_yn,
             a.non_vip_pre_aprvl_limit_yn,
             a.non_vip_pre_aprvl_limit,
             a.non_vip_mdt_srvce_pre_aprvl_yn
       FROM tpa_ins_prod_policy a
       WHERE a.prod_policy_seq_id = v_prod_policy_seq_id;
       
  END select_pre_approval_limit;
  
--=================================================================================================
PROCEDURE save_policy_tob_doc (v_prod_policy_seq_id         IN  tpa_ins_prod_policy.prod_policy_seq_id%TYPE,
                               v_pol_tob_doc                IN  TPA_ENR_POLICY.POL_TOB_DOC%TYPE,
                               v_row_processed              OUT NUMBER)
  IS
  
  CURSOR cur_pol_dtl IS
    SELECT ep.policy_seq_id
    FROM app.tpa_enr_policy ep
    JOIN app.tpa_ins_prod_policy pp ON (ep.policy_seq_id=pp.policy_seq_id)
    WHERE pp.prod_policy_seq_id = v_prod_policy_seq_id;
    
   rec_pol_dtl                   cur_pol_dtl%ROWTYPE;
 BEGIN
   
  OPEN  cur_pol_dtl;
  FETCH cur_pol_dtl INTO rec_pol_dtl;
  CLOSE cur_pol_dtl;
  
   UPDATE app.tpa_enr_policy p
    SET p.pol_tob_doc = v_pol_tob_doc
   WHERE p.policy_seq_id = rec_pol_dtl.policy_seq_id;
   
  v_row_processed := SQL%ROWCOUNT;
  COMMIT; 
 END save_policy_tob_doc;
--==================================================================================================
PROCEDURE select_policy_tob_doc (v_prod_policy_seq_id         IN  tpa_ins_prod_policy.prod_policy_seq_id%TYPE,
                                 v_pol_tob_doc                OUT TPA_ENR_POLICY.POL_TOB_DOC%TYPE)
  IS
  
  CURSOR cur_pol_dtl IS
    SELECT ep.policy_seq_id
    FROM app.tpa_enr_policy ep
    JOIN app.tpa_ins_prod_policy pp ON (ep.policy_seq_id=pp.policy_seq_id)
    WHERE pp.prod_policy_seq_id = v_prod_policy_seq_id;
    
   rec_pol_dtl                   cur_pol_dtl%ROWTYPE;
   
  CURSOR cur_pol_tob(v_policy_seq_id   NUMBER) IS
    SELECT p.pol_tob_doc
    FROM app.tpa_enr_policy p
    WHERE p.policy_seq_id = v_policy_seq_id;
    
 BEGIN
   
   OPEN  cur_pol_dtl;
   FETCH cur_pol_dtl INTO rec_pol_dtl;
   CLOSE cur_pol_dtl;
  
   OPEN  cur_pol_tob(rec_pol_dtl.policy_seq_id);
   FETCH cur_pol_tob INTO v_pol_tob_doc;
   CLOSE cur_pol_tob;
   
 END select_policy_tob_doc;
 --===================================================================================================
PROCEDURE delete_policy_tob_doc (v_prod_policy_seq_id         IN  tpa_ins_prod_policy.prod_policy_seq_id%TYPE,
                                   v_row_processed            OUT NUMBER)
                                  
  IS
  
   CURSOR cur_pol_dtl IS
    SELECT ep.policy_seq_id,ep.pol_tob_doc
    FROM app.tpa_enr_policy ep
    JOIN app.tpa_ins_prod_policy pp ON (ep.policy_seq_id=pp.policy_seq_id)
    WHERE pp.prod_policy_seq_id = v_prod_policy_seq_id;
    
   rec_pol_dtl                   cur_pol_dtl%ROWTYPE;
BEGIN
   
   OPEN  cur_pol_dtl;
   FETCH cur_pol_dtl INTO rec_pol_dtl;
   CLOSE cur_pol_dtl;
  
   IF rec_pol_dtl.pol_tob_doc IS NOT NULL THEN
    UPDATE app.tpa_enr_policy p
    SET p.pol_tob_doc = NULL
    WHERE p.policy_seq_id = rec_pol_dtl.policy_seq_id;
   END IF; 
   v_row_processed := NVL(SQL%ROWCOUNT,0);
   COMMIT; 
   
END delete_policy_tob_doc;
 --=========================================================================
 -- CR-0323EligibilityCheckForPBM
 -- to save buffer limit per benefit
 --***********************************************
 PROCEDURE save_benefit_buffer(p_seq_id                     IN  NUMBER,
                               p_dntl_buffer_limit          IN  tpa_ins_prod_policy.dntl_buffer_limit%TYPE,
                               p_optc_buffer_limit          IN  tpa_ins_prod_policy.optc_buffer_limit%TYPE,
                               p_opts_buffer_limit          IN  tpa_ins_prod_policy.opts_buffer_limit%TYPE,
                               p_opts_pharma_buffer_limit   IN  tpa_ins_prod_policy.opts_pharma_buffer_limit%TYPE,
                               p_omti_buffer_limit          IN  tpa_ins_prod_policy.omti_buffer_limit%TYPE,
                               p_added_by                   IN  tpa_ins_prod_policy.added_by%TYPE,
                               p_row_procesed               OUT NUMBER 
                              )IS 
                              
   CURSOR buffer_cur IS
     SELECT p.dntl_buffer_limit,p.opts_buffer_limit,p.opts_pharma_buffer_limit,
            p.optc_buffer_limit,p.omti_buffer_limit 
       FROM tpa_ins_prod_policy p
      WHERE p.prod_policy_seq_id = p_seq_id;
      
   v_buffer_rec    buffer_cur%ROWTYPE;    
       
   v_log       VARCHAR2(32767):=NULL;
   v_contact   VARCHAR2(32767);
   
   BEGIN
     SELECT contact_name INTO v_contact FROM tpa_user_contacts WHERE contact_seq_id =p_added_by;
     
     IF p_seq_id IS NOT NULL THEN
       
       OPEN  buffer_cur;
       FETCH buffer_cur INTO v_buffer_rec;
       CLOSE buffer_cur;
       
       IF nvl(v_buffer_rec.dntl_buffer_limit,-1) != nvl(p_dntl_buffer_limit,-1) THEN
        v_log := v_log||'Dental buffer limit changed from '||nvl(to_char(v_buffer_rec.dntl_buffer_limit),'NA')||' to '||nvl(to_char(p_dntl_buffer_limit),'NA')||chr(10);
       END IF;
       IF nvl(v_buffer_rec.optc_buffer_limit,-1) != nvl(p_optc_buffer_limit,-1) THEN
        v_log := v_log||'Optical buffer limit changed from '||nvl(to_char(v_buffer_rec.optc_buffer_limit),'NA')||' to '||nvl(to_char(p_optc_buffer_limit),'NA')||chr(10);
       END IF;
       IF nvl(v_buffer_rec.opts_buffer_limit,-1) != nvl(p_opts_buffer_limit,-1) THEN
        v_log := v_log||'Out-patient buffer limit changed from '||nvl(to_char(v_buffer_rec.opts_buffer_limit),'NA')||' to '||nvl(to_char(p_opts_buffer_limit),'NA')||chr(10);
       END IF;
       IF nvl(v_buffer_rec.opts_pharma_buffer_limit,-1) != nvl(p_opts_pharma_buffer_limit,-1) THEN
        v_log := v_log||'Prescription medications buffer limit changed from '||nvl(to_char(v_buffer_rec.opts_pharma_buffer_limit),'NA')||' to '||nvl(to_char(p_opts_pharma_buffer_limit),'NA')||chr(10);
       END IF;
       IF nvl(v_buffer_rec.omti_buffer_limit,-1) != nvl(p_omti_buffer_limit,-1) THEN
        v_log := v_log||'Out-patient maternity buffer limit changed from '||nvl(to_char(v_buffer_rec.omti_buffer_limit),'NA')||' to '||nvl(to_char(p_omti_buffer_limit),'NA')||chr(10);
       END IF;
       
       IF v_log IS NOT NULL THEN 
         
        v_log := 'Changed by '|| v_contact ||' on '||to_char(SYSDATE,'dd/mm/rrrr hh:mi:ss')||chr(10)||v_log;
        
        UPDATE tpa_ins_prod_policy p
           SET p.dntl_buffer_limit   = p_dntl_buffer_limit,
               p.optc_buffer_limit   = p_optc_buffer_limit,
               p.opts_buffer_limit   = p_opts_buffer_limit,
               p.opts_pharma_buffer_limit = p_opts_pharma_buffer_limit,
               p.omti_buffer_limit   = p_omti_buffer_limit,
               p.changed_buffer_limit = p.changed_buffer_limit||v_log
              
         WHERE p.prod_policy_seq_id= p_seq_id; 
         
        p_row_procesed := SQL%ROWCOUNT;
       END IF;
        
     END IF;  
       
 END save_benefit_buffer;
---------------------------------------------------------------------------------------------------------
PROCEDURE gen_renewal_mbrs_admin(
    v_policy_seq_id      IN VARCHAR2,
    v_status             IN VARCHAR2,--POA,POC,
    results_set          OUT SYS_REFCURSOR
  )
  IS
    str_tab                    ttk_util_pkg.str_table_type;
  BEGIN
   str_tab      := ttk_util_pkg.parse_str ( v_policy_seq_id );
   
 OPEN results_set FOR 
  WITH renewal_mem AS (
     SELECT A.policy_number,
             B.employee_no,
             B.insured_name,
             C.tpa_enrollment_id,
             C.mem_name,
             D.relship_description,
             E.description as gender,
             --decode(a.POLICY_SUB_GENERAL_TYPE_ID,'PFL',B.FLOATER_SUM_INSURED,C.mem_tot_sum_insured) AS mem_tot_sum_insured,
             row_number() over (PARTITION BY B.employee_no ORDER BY C.tpa_enrollment_id) rk,-----alias change
             B.FLOATER_SUM_INSURED, --C.mem_tot_sum_insured AS mem_sum_insured, 
             a.POLICY_SUB_GENERAL_TYPE_ID,
             case when a.POLICY_SUB_GENERAL_TYPE_ID='PFL' and D.relship_description='Principal'  then K.SUM_INSURED else C.mem_tot_sum_insured end as mem_sum_insured,
             C.mem_age,
             TO_CHAR(C.mem_dob,'DD/MM/YYYY') as mem_dob,
             B.department,
             TO_CHAR(B.date_of_joining,'DD/MM/YYYY') as date_of_joining,
             C.photo_present_yn,
             F.address_1||F.address_2||F.address_3 as address,
             J.CITY_DESCRIPTION,
             --F.city_type_id,
             H.state_name,
             F.pin_code,
             ttk_util_pkg.fn_decrypt(G.bank_account_no) as bank_account_no, --//ED
             C.domicilary_limit,
             ttk_util_pkg.fn_decrypt(F.email_id) as email_id, --//ED
             ttk_util_pkg.fn_decrypt(F.mobile_no) as mobile_no, --//ED
             B.certificate_no,
             ttk_util_pkg.fn_decrypt(B.creditcard_no) as creditcard_no,--//ED
             to_char(C.date_of_inception,'DD/MM/YYYY') AS date_of_inception,
             to_char(C.date_of_exit,'DD/MM/YYYY') AS date_of_exit,
             C.member_remarks AS policy_remarks,
             B.tpa_enrollment_number,
             c.member_seq_id,
             case when C.MARITAL_STATUS_ID='MRD' THEN 'Married'
             ELSE 'Single' END AS M_STATUS,
             CASE  WHEN C.status_general_type_id = 'POA' THEN 'Active'
             ELSE 'Cancelled' end as status,
             to_char(A.ADDED_DATE,'DD/MM/YYYY'),
              to_char(C.CARD_PRN_DATE,'dd/mm/yyyy') as CARD_PRN_DATE,
             case when c.card_prn_count!=0 then 'Y' 
             ELSE 'N' END AS CARD_PRINTED,
             C.EMIRATE_ID,
             C.PASSPORT_NUMBER,
             N.DESCRIPTION,
             C.CARD_PRN_COUNT,
             gc.DESCRIPTION as network_type,
             to_char(C.ADDED_DATE,'dd/mm/yyyy') as adate,
			        C.VIP_YN,
              K.SUM_INSURED-K.utilised_sum_insured as AVA_SUM_INSURED,
              L.GROUP_NAME,
              co.country_name COUNTRY_ID,
               --F.COUNTRY_ID ,-------ADD FOR REPORT
             C.FAMILY_NAME, --------ADD FOR REPORT
             x.designation_description as DESIGNATION,   -------ADD FOR REPORT
             TO_CHAR(C.MEM_DOB_HIJRI,'DD/MM/YYYY') as MEM_DOB_HIJRI,  -------ADD FOR REPORT
             F.RESIDENCIAL_LOC,-------ADD FOR REPORT
             F.WORK_LOC,  -------ADD FOR REPORT
              c.mem_total_premium,
      (CASE WHEN c.gender_general_type_id = 'MAL' THEN (NVL(nvl(a.ip_op_premium_per_ind,a.pol_total_excmat_premium),0))
                  WHEN c.Gender_General_Type_Id = 'FEM' AND c.Marital_Status_Id ='MRD' 
                       AND c.MEM_AGE BETWEEN a.mat_premum_from_age AND a.mat_premum_to_age 
                       THEN (NVL(nvl(a.ip_op_premium_per_ind,a.pol_total_excmat_premium),0) + NVL(nvl(a.mat_premium_per_ind,a.pol_total_mat_premium),0))
                  ELSE (NVL(nvl(a.ip_op_premium_per_ind,a.pol_total_excmat_premium),0))  
                END) as annual_premium

      FROM TPA_ENR_POLICY A JOIN TPA_ENR_POLICY_GROUP B ON (A.Policy_Seq_Id = B.policy_seq_id)
      JOIN TPA_ENR_POLICY_MEMBER C ON (B.policy_group_seq_id = C.policy_group_seq_id)
      join tpa_group_registration l on (a.group_reg_seq_id=l.group_reg_seq_id)
      JOIN TPA_RELATIONSHIP_CODE D ON (C.relship_type_id=D.relship_type_id)
      JOIN TPA_GENERAL_CODE E ON (E.general_type_id=C.gender_general_type_id)
      LEFT OUTER JOIN TPA_ENR_MEM_ADDRESS F ON (F.enr_address_seq_id = c.enr_address_seq_id)
      LEFT OUTER JOIN TPA_ENR_BANK_DTLS G ON (G.bank_seq_id = b.bank_seq_id)
      LEFT OUTER JOIN TPA_STATE_CODE H ON (H.state_type_id=F.state_type_id)
      LEFT OUTER JOIN APP.TPA_CITY_CODE J ON (J.CITY_TYPE_ID=F.CITY_TYPE_ID)
      LEFT OUTER JOIN APP.TPA_NATIONALITIES_CODE N ON (N.NATIONALITY_ID=C.NATIONALITY_ID)
      left outer JOIN TPA_INS_PRODUCT TIP ON (a.PRODUCT_SEQ_ID=TIP.PRODUCT_SEQ_ID)
      left outer join tpa_general_code GC ON (GC.GENERAL_TYPE_ID=TIP.PRODUCT_CAT_TYPE_ID)
      left outer join tpa_designation_code x on (x.designation_type_id = b.designation)
      left outer join tpa_country_code co on(co.country_id = f.country_id)
      left outer JOIN app.tpa_enr_balance K ON (c.policy_group_seq_id=K.policy_group_seq_id)-- and CASE WHEN A.Policy_Sub_General_Type_Id= 'PNF' THEN C.MEMBER_SEQ_ID=K.MEMBER_SEQ_ID)
      WHERE A.enrol_type_id = 'COR' and (c.status_general_type_id= v_status or v_status is null)
       and  (c.mem_general_type_id != 'PFL' AND c.member_seq_id = k.member_seq_id OR k.member_seq_id IS NULL OR c.member_seq_id IS NULL)
      AND A.policy_seq_id = str_tab(1)
      AND B.deleted_yn='N'
      AND C.deleted_yn='N'
      --AND C.status_general_type_id != 'POC'
      )

      --SELECT * FROM renewal_mem WHERE rec_number BETWEEN str_tab(2) AND str_tab(2)+9;--64999;
      SELECT b.*, CASE WHEN POLICY_SUB_GENERAL_TYPE_ID = 'PFL' AND rk = 1 THEN FLOATER_SUM_INSURED
                  ELSE mem_sum_insured END AS mem_tot_sum_insured,Q  rn FROM
        (SELECT A.*, DENSE_RANK() OVER (ORDER BY employee_no, MEMBER_SEQ_ID, ROWNUM)
           Q FROM renewal_mem A ) b WHERE Q>= str_tab(2) AND Q<= str_tab(3);

  END gen_renewal_mbrs_admin;
---=======================================================================================================
END ADMINISTRATION_PKG;

/

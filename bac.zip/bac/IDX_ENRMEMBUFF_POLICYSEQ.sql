--------------------------------------------------------
--  DDL for Synonymn IDX_ENRMEMBUFF_POLICYSEQ
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."IDX_ENRMEMBUFF_POLICYSEQ" FOR "APP"."IDX_ENRMEMBUFF_POLICYSEQ";

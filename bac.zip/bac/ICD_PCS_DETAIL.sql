--------------------------------------------------------
--  DDL for Synonymn ICD_PCS_DETAIL
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."ICD_PCS_DETAIL" FOR "APP"."ICD_PCS_DETAIL";

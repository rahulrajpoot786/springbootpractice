--------------------------------------------------------
--  DDL for Package Body ENROLLMENT_VALIDATION_PKG
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "VENUBABU"."ENROLLMENT_VALIDATION_PKG" IS



--  FUNCTION exec_field_fun
/**
  *  Function   : exec_field_fun
  *  Overview   : Subprogram for getting the value of a text node from the specified child
  *               of the element passed to this function.
  *               This function uses PL/SQL DOM API for getting the node value.
  *  Parameters :
  *   @element   - IN -  The DOM Element for the XML document.
  *   @name      - IN -  The node name.
  **/
-- =========================================================================================================================
  FUNCTION exec_field_fun ( v_fn_name VARCHAR2 )
  RETURN VARCHAR
  IS
     v_res VARCHAR2(30);

  BEGIN
    EXECUTE IMMEDIATE ' BEGIN :res := validation_field_data_pkg.'||v_fn_name||'; END;' USING OUT v_res;
    RETURN v_res;
  END exec_field_fun;

-- =========================================================================================================================
--  PROCEDURE validate_enrollment( v_id IN NUMBER, v_flag IN CHAR, v_out OUT XMLTYPE )
-- Pramater v_id  if v_flag = 'P' then v_id should be policy sesq_id if v_flag = 'E' then v_id should be enrollment_id
-- =========================================================================================================================
  /*PROCEDURE process_member(
    v_enrollment_xml            IN  XMLTYPE,
    v_mem_xml                   IN  OUT XMLTYPE ,
    v_policy_group_seq_id       IN  TPA_ENR_POLICY_GROUP.policy_group_seq_id%TYPE,
    v_flag                      IN CHAR,
    v_out_xml                   OUT XMLTYPE
  )
  IS
    v_enr_doc  DBMS_XMLDOM.DOMDocument;
    v_mem_doc  DBMS_XMLDOM.DOMDocument;
    v_mem_root_node DBMS_XMLDOM.DOMNode;
    v_enr_root_node DBMS_XMLDOM.DOMNode;
    v_node DBMS_XMLDOM.DOMNode;

    temp_mem_xml      XMLTYPE;

  BEGIN

    v_enr_doc := DBMS_XMLDOM.newDOMDocument(v_enrollment_xml);
    v_enr_root_node := DBMS_XMLDOM.makeNode(DBMS_XMLDOM.getDocumentElement(v_enr_doc));

    FOR mem_rec IN ( SELECT member_seq_id FROM tpa_enr_policy_member
                      WHERE policy_group_seq_id = v_policy_group_seq_id AND deleted_yn = 'N' AND status_general_type_id != 'POC')
    LOOP
      temp_mem_xml := v_mem_xml ;
      -- Setting Record valriables for Member
      validation_field_data_pkg.set_policy_details ('M', mem_rec.member_seq_id );

      process_xml('M', temp_mem_xml );
      set_attributes ('M',temp_mem_xml );

      v_mem_doc       := DBMS_XMLDOM.newDOMDocument(temp_mem_xml);
      v_mem_root_node := DBMS_XMLDOM.makeNode(DBMS_XMLDOM.getDocumentElement(v_mem_doc));

      v_mem_root_node := dbms_xmldom.importNode( v_enr_doc, v_mem_root_node ,TRUE);
      v_node          := dbms_xmldom.appendChild( v_enr_root_node, v_mem_root_node );
    END LOOP;
    v_out_xml := dbms_xmldom.getxmltype(v_enr_doc);

    dbms_xmldom.freeDocument(v_enr_doc);
  END process_member;*/

-- =========================================================================================================================
--  PROCEDURE validate_enrollment( v_id IN NUMBER, v_flag IN CHAR, v_out OUT XMLTYPE )
-- Pramater v_id  if v_flag = 'P' then v_id should be policy sesq_id if v_flag = 'E' then v_id should be enrollment_id
-- =========================================================================================================================
 PROCEDURE process_xml(v_flag  VARCHAR2, v_val_rule_xml IN OUT XMLTYPE)
 IS
    v_doc              DBMS_XMLDOM.DOMDocument;
    v_field_doc        DBMS_XMLDOM.DOMDocument;
    v_field_root_node  DBMS_XMLDOM.domnode;
    v_root_node        DBMS_XMLDOM.domnode;
    v_node             DBMS_XMLDOM.domnode;
    v_elem             DBMS_XMLDOM.DOMElement;
    v_clause_domlist   DBMS_XMLDOM.DOMNODELIST;
    v_clause_node      DBMS_XMLDOM.domnode;
    v_cov_node         DBMS_XMLDOM.domnode;
    v_con_node         DBMS_XMLDOM.domnode;
    v_cov_node_lst     DBMS_XMLDOM.domnodelist;
    v_con_node_lst     DBMS_XMLDOM.domnodelist;
    v_attrval          VARCHAR2 (1000);
    v_column_name      VARCHAR2 (1000);
    v_func_value       VARCHAR2 (1000);
    v_dyna_val         VARCHAR2 (1000);
    v_tab_pos          NUMBER(5);
    v_field_name       VARCHAR2(1000);


  BEGIN

    v_field_doc := DBMS_XMLDOM.newDOMDocument;
    v_root_node := dbms_xmldom.makeNode( v_field_doc );

    v_doc     := DBMS_XMLDOM.newDOMDocument(v_val_rule_xml);

    v_clause_domlist := DBMS_XMLDOM.getelementsbytagname( v_doc,'clause');

    FOR clause_node_index IN 0 .. DBMS_XMLDOM.getLength( v_clause_domlist) -1
    LOOP
      v_clause_node := DBMS_XMLDOM.item ( v_clause_domlist, clause_node_index);
      IF ( DBMS_XMLDOM.GETNODETYPE( v_clause_node ) <> DBMS_XMLDOM.COMMENT_NODE )THEN
        v_elem := DBMS_XMLDOM.makeelement( v_clause_node );
        v_cov_node_lst := DBMS_XMLDOM.getchildnodes ( v_clause_node );
        FOR cov_node_index IN 0 .. DBMS_XMLDOM.getLength( v_cov_node_lst ) -1
        LOOP
          v_cov_node := DBMS_XMLDOM.item ( v_cov_node_lst , cov_node_index );
          IF ( DBMS_XMLDOM.GETNODETYPE(v_cov_node) <> DBMS_XMLDOM.COMMENT_NODE )THEN
            v_elem := DBMS_XMLDOM.makeelement(v_cov_node);
            v_attrval := DBMS_XMLDOM.getattribute(v_elem,'name');
            dbms_output.put_line('cv = '||v_attrval);
            v_con_node_lst := DBMS_XMLDOM.getchildnodes ( v_cov_node );
            FOR con_node_index IN 0 .. DBMS_XMLDOM.getLength(v_con_node_lst) -1
            LOOP
              v_con_node := DBMS_XMLDOM.item (v_con_node_lst, con_node_index);
              IF ( DBMS_XMLDOM.GETNODETYPE(v_con_node) <> DBMS_XMLDOM.COMMENT_NODE )THEN
                v_elem := DBMS_XMLDOM.makeelement(v_con_node);
                -- Setting value for dyna value
                v_field_name := DBMS_XMLDOM.getattribute(v_elem,'field') ;
                v_dyna_val := DBMS_XMLDOM.getattribute(v_elem,'dynValue');
                v_dyna_val:= REPLACE( REPLACE( REPLACE( v_dyna_val,'(,','(NULL,' ) ,',)', ',NULL)' ) , ',,',',NULL,' ) ;
                IF v_dyna_val IS NOT NULL THEN
                  v_func_value :=  exec_field_fun(v_dyna_val);
                  DBMS_XMLDOM.setattribute(v_elem,'value',v_func_value);
                END IF;
                -- End Dyn value
                IF DBMS_XMLDOM.getattribute(v_elem,'source')='PACKAGE' THEN
                  -- Setting fieldData from business proceddure
                  v_attrval   := DBMS_XMLDOM.getattribute(v_elem,'method');
                  v_func_value :=  exec_field_fun(v_attrval);
                  DBMS_XMLDOM.setattribute(v_elem,'fieldData',v_func_value);
                ELSIF DBMS_XMLDOM.getattribute(v_elem,'source')='TABLE' THEN
                  -- Setting fieldData from table column
                  v_column_name := dbms_xmldom.getattribute(v_elem,'method');
                  v_tab_pos := instr(v_column_name,'.');
                  v_column_name := TRIM(substr(v_column_name,(v_tab_pos + 1)));

                  IF v_flag = 'M' THEN
                    v_func_value := validation_field_data_pkg.get_table_data ( 'VALIDATION_FIELD_DATA_PKG.VV_MEMBER_REC' ,v_column_name );
                  ELSE
                    v_func_value := validation_field_data_pkg.get_table_data ( 'VALIDATION_FIELD_DATA_PKG.VV_POLICY_REC' ,v_column_name );
                  END IF;
                  DBMS_XMLDOM.setattribute(v_elem,'fieldData', v_func_value);
                END IF;
              END IF;
            END LOOP;
          END IF;

     END LOOP;
   END IF;
  END LOOP;

  v_val_rule_xml := DBMS_XMLDOM.GETXMLTYPE(v_doc);

  IF v_val_rule_xml IS NOT NULL THEN
     -- doing auto selection
      pr_auto_select(v_val_rule_xml);
  END IF;

  DBMS_XMLDOM.freeDocument(v_field_doc);
  DBMS_XMLDOM.freeDocument(v_doc);
 END process_xml;

-- =========================================================================================================================
-- PROCEDURE validate_enrollment( v_id IN NUMBER, v_flag IN CHAR, v_out OUT XMLTYPE )
-- Pramater v_id  if v_flag = 'P' then v_id should be policy sesq_id if v_flag = 'E' then v_id should be policy_group_seq_id
-- =========================================================================================================================

  /*PROCEDURE validate_enrollment( v_id IN NUMBER, v_flag IN CHAR, v_out OUT XMLTYPE )
  IS

   v_prod_policy_rule_seq_id   tpa_ins_prod_policy_rules.prod_policy_rule_seq_id%TYPE;

   CURSOR cur_pol_val_rule IS  -- FOR POLICY
     SELECT extract(prod_policy_rule ,'/clauses/clause[@type="validation" and contains(@execution,"POL" )]') AS rule_data
        FROM tpa_ins_prod_policy_rules A
       WHERE A.prod_policy_rule_seq_id = v_prod_policy_rule_seq_id ;

   CURSOR cur_fam_val_rule IS  -- FOR GROUP
     SELECT XMLELEMENT("validation",extract(prod_policy_rule ,'/clauses/clause[@type="validation" and contains(@execution,"ENR" )]')) AS rule_data
        FROM tpa_ins_prod_policy_rules A
       WHERE A.prod_policy_rule_seq_id = v_prod_policy_rule_seq_id ;

   CURSOR cur_mem_val_rule IS  -- FOR MEMBER
     SELECT extract(prod_policy_rule ,'/clauses/clause[@type="validation" and contains(@execution,"MEM" )]') AS rule_data
        FROM tpa_ins_prod_policy_rules A
       WHERE A.prod_policy_rule_seq_id = v_prod_policy_rule_seq_id ;
--------- FOR GETTING PROD_POLICY_SEQ_ID
    CURSOR get_pol_cur IS    -- CORPORATE
       SELECT MAX(c.prod_policy_rule_seq_id)
         FROM tpa_enr_policy a JOIN tpa_ins_prod_policy b ON ( a.policy_seq_id = b.policy_seq_id )
         JOIN tpa_ins_prod_policy_rules c ON ( b.prod_policy_seq_id = c.prod_policy_seq_id )
         WHERE a.policy_seq_id = v_id ;

    CURSOR get_prod_cur IS -- OTHERS
       SELECT c.prod_policy_rule_seq_id
         FROM tpa_enr_policy a JOIN tpa_ins_prod_policy b ON ( a.product_seq_id = b.product_seq_id )
         JOIN tpa_ins_prod_policy_rules c ON ( b.prod_policy_seq_id = c.prod_policy_seq_id )
         WHERE a.policy_seq_id = v_id
         AND a.policy_issue_date >= c.valid_from AND a.policy_issue_date <= NVL(C.valid_to,a.policy_issue_date );

    CURSOR get_group_pol_cur IS -- CORPORATE  using policy_group_seq_id
       SELECT d.prod_policy_rule_seq_id
         FROM tpa_enr_policy_group a JOIN tpa_enr_policy b ON ( a.policy_seq_id = b.policy_seq_id )
         JOIN tpa_ins_prod_policy c ON ( b.policy_seq_id = c.policy_seq_id )
         JOIN tpa_ins_prod_policy_rules d ON ( c.prod_policy_seq_id = d.prod_policy_seq_id )
         WHERE a.policy_group_seq_id = v_id ;

    CURSOR get_group_prod_cur IS -- OTHERS  using policy_group_seq_id
       SELECT d.prod_policy_rule_seq_id
         FROM tpa_enr_policy_group a JOIN tpa_enr_policy b ON ( a.policy_seq_id = b.policy_seq_id )
         JOIN tpa_ins_prod_policy c ON ( b.product_seq_id = c.product_seq_id )
         JOIN tpa_ins_prod_policy_rules d ON ( c.prod_policy_seq_id = d.prod_policy_seq_id )
         WHERE a.policy_group_seq_id = v_id
         AND B.policy_issue_date >= D.valid_from AND B.policy_issue_date <= NVL(D.valid_to, B.policy_issue_date );


    v_pol_rule_xml     XMLTYPE;
    v_enr_rule_xml     XMLTYPE;
    v_mem_rule_xml     XMLTYPE;

    v_doc              DBMS_XMLDOM.DOMDocument;
    v_field_doc        DBMS_XMLDOM.DOMDocument;
    v_field_root_node  DBMS_XMLDOM.domnode;
    v_root_node        DBMS_XMLDOM.domnode;
    v_node             DBMS_XMLDOM.domnode;
    v_elem             DBMS_XMLDOM.DOMElement;

  BEGIN

    IF v_flag = 'P' THEN                                     --- POLICY
      -- Setting Record valriables for Policy
      validation_field_data_pkg.set_policy_details ('P',v_id );

      OPEN get_pol_cur;
      FETCH get_pol_cur INTO v_prod_policy_rule_seq_id;
      CLOSE get_pol_cur;

      IF v_prod_policy_rule_seq_id IS NULL THEN
        OPEN get_prod_cur;
        FETCH get_prod_cur INTO v_prod_policy_rule_seq_id;
        CLOSE get_prod_cur;
      END IF;

      IF v_prod_policy_rule_seq_id IS NULL THEN
      --=======================
        RETURN;
      --========================
        raise_application_error(-20511,'Rule is not defined ');
      END IF;

      OPEN cur_pol_val_rule ;
      FETCH cur_pol_val_rule INTO v_pol_rule_xml;
      CLOSE cur_pol_val_rule;

      IF v_pol_rule_xml IS NOT NULL THEN
        process_xml('P' , v_pol_rule_xml );
        set_attributes ('P',v_pol_rule_xml );
      END IF;

      UPDATE tpa_enr_policy
        SET validation_status = 'P'
        WHERE policy_seq_id = v_id;


    ELSIF v_flag = 'E' THEN                                  --- FAMILY
      -- Setting Record valriables for Family
      validation_field_data_pkg.set_policy_details ('E',v_id );

      OPEN get_group_pol_cur;
      FETCH get_group_pol_cur INTO v_prod_policy_rule_seq_id;
      CLOSE get_group_pol_cur;

      IF v_prod_policy_rule_seq_id IS NULL THEN
        OPEN get_group_prod_cur;
        FETCH get_group_prod_cur INTO v_prod_policy_rule_seq_id;
        CLOSE get_group_prod_cur;
      END IF;

      IF v_prod_policy_rule_seq_id IS NULL THEN
      --=================
        RETURN;
      --=================
        raise_application_error(-20511,'Rule is not defined ');
      END IF;

      OPEN cur_pol_val_rule ;
      FETCH cur_pol_val_rule INTO  v_pol_rule_xml;
      CLOSE cur_pol_val_rule;

      OPEN cur_fam_val_rule ;
      FETCH cur_fam_val_rule INTO v_enr_rule_xml;
      CLOSE cur_fam_val_rule;

      OPEN cur_mem_val_rule ;
      FETCH cur_mem_val_rule INTO  v_mem_rule_xml;
      CLOSE cur_mem_val_rule;

      IF v_pol_rule_xml IS NOT NULL THEN
        process_xml('P', v_pol_rule_xml );
        set_attributes ('P',v_pol_rule_xml );

        IF v_enr_rule_xml IS NOT NULL THEN
          process_xml('P', v_enr_rule_xml );
          set_attributes ('E',v_enr_rule_xml );
          combine_xml ( v_pol_rule_xml, v_enr_rule_xml);
        END IF;

        IF v_mem_rule_xml IS NOT NULL THEN
           process_member( v_pol_rule_xml, v_mem_rule_xml, v_id ,'E', v_pol_rule_xml );
        END IF;
       \* IF v_pol_rule_xml IS NOT NULL THEN
          -- doing auto selection
          pr_auto_select(v_pol_rule_xml);
        END IF;  *\

      END IF;
      UPDATE tpa_enr_policy_group
        SET validation_status = 'P'   -- FOR PASSED
        WHERE policy_group_seq_id = v_id;
      UPDATE tpa_enr_policy_member
        SET validation_status = 'P'  -- FOR PASSED
        WHERE policy_group_seq_id = v_id;
    END IF;
    COMMIT;
    v_out := v_pol_rule_xml ;

  END validate_enrollment;*/
-- ============================================================================
--  FUNCTION getChildTextNode
/**
  *  Function   : getChildTextNode
  *  Overview   : Subprogram for getting the value of a text node from the specified child
  *               of the element passed to this function.
  *               This function uses PL/SQL DOM API for getting the node value.
  *  Parameters :
  *   @element   - IN -  The DOM Element for the XML document.
  *   @name      - IN -  The node name.
  **/
-- ============================================================================
  FUNCTION getColumnValue(v_field_xml XMLTYPE,v_parent_elem_name IN VARCHAR2, v_elem_name IN VARCHAR2)
    RETURN VARCHAR2
  IS
    v_doc       DBMS_XMLDOM.DOMDocument;
    v_docelem   DBMS_XMLDOM.DOMElement;
    v_nodelist  DBMS_XMLDOM.DOMNodelist;
    v_node      DBMS_XMLDOM.DOMNode;
    v_elem      DBMS_XMLDOM.DOMElement;
    v_temp      VARCHAR2(100);
  BEGIN

    v_doc     := DBMS_XMLDOM.newDOMDocument(v_field_xml);
    v_docelem := DBMS_XMLDOM.getDocumentElement(v_doc);
    v_nodelist := DBMS_XMLDOM.getElementsByTagName(v_docelem, v_parent_elem_name);
    v_node := DBMS_XMLDOM.item(v_nodelist, 0);
    v_elem := DBMS_XMLDOM.makeElement(v_node);
    v_temp := getChildTextNode(v_elem,v_elem_name);

    DBMS_XMLDOM.freeDocument(v_doc);

    RETURN v_temp;
    --dbms_output.put_line('v_temp  '||v_temp);

  END  getColumnValue;
-- ============================================================================
-- ============================================================================
--  FUNCTION getChildTextNode
/**
  *  Function   : getChildTextNode
  *  Overview   : Subprogram for getting the value of a text node from the specified child
  *               of the element passed to this function.
  *               This function uses PL/SQL DOM API for getting the node value.
  *  Parameters :
  *   @element   - IN -  The DOM Element for the XML document.
  *   @name      - IN -  The node name.
  **/
-- ============================================================================

  FUNCTION getChildTextNode(
    element             IN DBMS_XMLDOM.DOMELEMENT,
    v_name              IN VARCHAR2
  ) RETURN VARCHAR2 DETERMINISTIC
  IS
    textNodeValue VARCHAR2(2048) := NULL;
    nodeList      DBMS_XMLDOM.DOMNODELIST;
    child         DBMS_XMLDOM.DOMNODE;
  BEGIN
    -- Access the element.
    nodeList := DBMS_XMLDOM.GETELEMENTSBYTAGNAME(element, v_name);

    IF ( dbms_xmldom.getlength(nodeList) > 0) THEN
      -- Manipulate the node list to get the node value.
      child := DBMS_XMLDOM.ITEM(nodeList, 0);
      child := DBMS_XMLDOM.GETFIRSTCHILD(child);
      textNodeValue := DBMS_XMLDOM.GETNODEVALUE(child);
    END IF;

    -- Return the node value.
    RETURN textNodeValue;

  END getChildTextNode;

--===============================================================================================================
  PROCEDURE combine_xml(
    v_parent_xml            IN  OUT XMLTYPE,
    v_child_xml             IN  XMLTYPE
  )
  IS
    v_parent_doc       DBMS_XMLDOM.DOMDocument;
    v_child_doc        DBMS_XMLDOM.DOMDocument;
    v_child_root_node  DBMS_XMLDOM.DOMNode;
    v_parent_root_node DBMS_XMLDOM.DOMNode;
    v_node DBMS_XMLDOM.DOMNode;

  BEGIN

    v_parent_doc      := DBMS_XMLDOM.newDOMDocument(v_parent_xml);
    v_parent_root_node:= DBMS_XMLDOM.makeNode(DBMS_XMLDOM.getDocumentElement(v_parent_doc));

    v_child_doc       := DBMS_XMLDOM.newDOMDocument(v_child_xml);
    v_child_root_node := DBMS_XMLDOM.makeNode(DBMS_XMLDOM.getDocumentElement(v_child_doc));

    v_child_root_node := dbms_xmldom.importNode( v_parent_doc,v_child_root_node,TRUE );
    v_node            := dbms_xmldom.appendChild( v_parent_root_node, v_child_root_node );

    v_parent_xml      := dbms_xmldom.getxmltype( v_parent_doc);

    DBMS_XMLDOM.freeDocument(v_parent_doc);
    DBMS_XMLDOM.freeDocument(v_child_doc);

  END combine_xml;
--=============================================================================================================
  PROCEDURE set_attributes( v_flag VARCHAR2, v_rule_xml  IN OUT xmltype)
  IS
    v_doc              DBMS_XMLDOM.DOMDocument;
    v_field_doc        DBMS_XMLDOM.DOMDocument;
    v_field_root_node  DBMS_XMLDOM.domnode;
    v_root_node        DBMS_XMLDOM.domnode;
    v_node             DBMS_XMLDOM.domnode;
    v_elem             DBMS_XMLDOM.DOMElement;
    v_field_xml        XMLTYPE;
  BEGIN
    v_field_doc := DBMS_XMLDOM.newDOMDocument;
    v_root_node := dbms_xmldom.makeNode(v_field_doc);

    IF v_flag = 'P' THEN
      v_elem := dbms_xmldom.createElement( v_field_doc, 'policy' );
      dbms_xmldom.setAttribute(v_elem,'policytype',validation_field_data_pkg.vv_policy_rec.enrol_type_id);
      dbms_xmldom.setAttribute(v_elem,'tpaofficeseqid',validation_field_data_pkg.vv_policy_rec.tpa_office_seq_id);
      dbms_xmldom.setAttribute(v_elem,'insseqid',validation_field_data_pkg.vv_policy_rec.ins_seq_id);
      dbms_xmldom.setAttribute(v_elem,'abbrevationcode',validation_field_data_pkg.vv_policy_rec.abbrevation_code);
      dbms_xmldom.setAttribute(v_elem,'inscompcodenumber',validation_field_data_pkg.vv_policy_rec.ins_comp_code_number);
      dbms_xmldom.setAttribute(v_elem,'batchnumber',validation_field_data_pkg.vv_policy_rec.batch_number);
      dbms_xmldom.setAttribute(v_elem,'policynumber',validation_field_data_pkg.vv_policy_rec.policy_number);
      dbms_xmldom.setAttribute(v_elem,'custendorementnumber',NULL);
    ELSIF v_flag = 'E' THEN
      v_elem := dbms_xmldom.createElement( v_field_doc, 'enrollment' );
      dbms_xmldom.setAttribute(v_elem,'tpaenrollmentnumber',validation_field_data_pkg.vv_policy_rec.tpa_enrollment_number);
      dbms_xmldom.setAttribute(v_elem,'employeeno',validation_field_data_pkg.vv_policy_rec.employee_no);
      dbms_xmldom.setAttribute(v_elem,'policyholder',validation_field_data_pkg.vv_policy_rec.insured_name);
    ELSE
      v_elem := dbms_xmldom.createElement( v_field_doc, 'member' );
      dbms_xmldom.setAttribute(v_elem,'tpaenrollmentid',validation_field_data_pkg.vv_member_rec.tpa_enrollment_id);
      dbms_xmldom.setAttribute(v_elem,'relationship',validation_field_data_pkg.vv_member_rec.relationship);
    END IF;
    v_node := dbms_xmldom.makeNode( v_elem );
    v_field_root_node := dbms_xmldom.appendChild( v_root_node, v_node );

    v_field_xml := DBMS_XMLDOM.GETXMLTYPE(v_field_doc);

    combine_xml( v_field_xml, v_rule_xml);
    v_rule_xml := v_field_xml;

    DBMS_XMLDOM.freeDocument(v_field_doc);
  END set_attributes;
  --========================================================================================
  PROCEDURE pr_auto_select(  v_merge_xml IN OUT XMLTYPE)
  IS
    v_doc              DBMS_XMLDOM.DOMDocument;
    v_elem             DBMS_XMLDOM.DOMElement;
    v_clause_domlist   DBMS_XMLDOM.DOMNODELIST;
    v_clause_node      DBMS_XMLDOM.domnode;
    v_cov_node         DBMS_XMLDOM.domnode;
    v_cov_node_lst     DBMS_XMLDOM.domnodelist;
    v_func_name        VARCHAR2 (100);
    v_func_value       VARCHAR2 (100);
  BEGIN
    v_doc            := DBMS_XMLDOM.newDOMDocument(v_merge_xml);
    v_clause_domlist := DBMS_XMLDOM.getelementsbytagname(v_doc,'clause');

    FOR clause_node_index IN 0 .. DBMS_XMLDOM.getLength(v_clause_domlist) -1
    LOOP
      v_clause_node := DBMS_XMLDOM.item (v_clause_domlist, clause_node_index);
      IF ( DBMS_XMLDOM.GETNODETYPE(v_clause_node) <> DBMS_XMLDOM.COMMENT_NODE )THEN
         v_elem := DBMS_XMLDOM.makeelement(v_clause_node);
         v_cov_node_lst := DBMS_XMLDOM.getchildnodes (v_clause_node);
         FOR cov_node_index IN 0 .. DBMS_XMLDOM.getLength(v_cov_node_lst) -1
         LOOP
            v_cov_node := DBMS_XMLDOM.item (v_cov_node_lst, cov_node_index);
            IF ( DBMS_XMLDOM.GETNODETYPE(v_cov_node) <> DBMS_XMLDOM.COMMENT_NODE )THEN
              v_elem := DBMS_XMLDOM.makeelement(v_cov_node);
              v_func_name := DBMS_XMLDOM.getattribute(v_elem,'autoselect');
              v_func_name := REPLACE( REPLACE( REPLACE( v_func_name,'(,','(NULL,' ) ,',)', ',NULL)' ) , ',,',',NULL,' ) ;
              IF v_func_name IS NOT NULL THEN
                 v_func_value :=  exec_field_fun(v_func_name);
                 DBMS_XMLDOM.setattribute(v_elem,'selected',v_func_value);
              END IF;
            END IF;
         END LOOP;
      END IF;
    END LOOP;
    v_merge_xml := dbms_xmldom.getxmltype( v_doc );
    dbms_xmldom.freeDocument( v_doc );
  END pr_auto_select;
END enrollment_validation_pkg;

/

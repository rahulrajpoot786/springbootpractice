--------------------------------------------------------
--  DDL for Synonymn CLAIMS_PKG_DATA_ENTRY
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."CLAIMS_PKG_DATA_ENTRY" FOR "INTX"."CLAIMS_PKG_DATA_ENTRY";

--------------------------------------------------------
--  DDL for Synonymn CLM_BILL_HEADER
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."CLM_BILL_HEADER" FOR "APP"."CLM_BILL_HEADER";

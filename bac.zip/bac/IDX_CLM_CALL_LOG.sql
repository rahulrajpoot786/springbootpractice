--------------------------------------------------------
--  DDL for Synonymn IDX_CLM_CALL_LOG
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."IDX_CLM_CALL_LOG" FOR "APP"."IDX_CLM_CALL_LOG";

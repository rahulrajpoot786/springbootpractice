--------------------------------------------------------
--  DDL for Synonymn CLM_FEEDBACK_INFO
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."CLM_FEEDBACK_INFO" FOR "APP"."CLM_FEEDBACK_INFO";

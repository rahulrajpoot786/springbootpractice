--------------------------------------------------------
--  DDL for Package Body DISPLAY_OF_BENEFITS
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "VENUBABU"."DISPLAY_OF_BENEFITS" 
AS

---*******procedure for saving data from policy level information********---------------------
--Commented as not required by Manas on 11th july 2018
/*
PROCEDURE SAVE_POLICY_DATA_INFO (
                                 V_RULE_BENEFIT_SEQ_ID  IN OUT TPA_RULE_BENEFIT.RULE_BENEFIT_SEQ_ID%TYPE,
								                 V_PROD_POLICY_SEQ_ID   IN     TPA_RULE_BENEFIT.POLICY_SEQ_ID%TYPE,
                                 V_BENEFIT_NAME         IN     TPA_RULE_BENEFIT.BENEFIT_NAME%TYPE,
                                 V_SUB_BENF_NAME        IN     TPA_RULE_BENEFIT.SUB_BENF_NAME%TYPE,
                                 V_SUB_BENF_SEQ_ID      IN     TPA_MASTER_SUBBENEFIT.SUB_BENF_SEQ_ID%TYPE,----SUB_BENF_DTL_SEQ_ID
								                 V_COVERAGE_PAY_VAL     IN     TPA_RULE_BENEFIT.COVERAGE_PAY_VAL%TYPE,
                                 V_COVERAGE             IN     TPA_RULE_BENEFIT.COVERAGE%TYPE,
								                 V_LIMIT                IN     TPA_RULE_BENEFIT.LIMIT%TYPE,
								                 V_COPAY                IN     TPA_RULE_BENEFIT.COPAY%TYPE,
								                 V_DEDUCTABLE           IN     TPA_RULE_BENEFIT.DEDUCTABLE%TYPE,
							                 	 V_MEM_WAITING          IN     TPA_RULE_BENEFIT.MEM_WAITING%TYPE,
							                	 V_SESSION_ALLOWED      IN     TPA_RULE_BENEFIT.SESSION_ALLOWED%TYPE,
							                	---- V_PROV_WISE_LIMIT      IN     TPA_RULE_BENEFIT.PROV_WISE_LIMIT%TYPE,
								                 V_TYPE_MODE            IN     TPA_RULE_BENEFIT.TYPE_MODE%TYPE,
								                 V_OTHER_REMARKS        IN     TPA_RULE_BENEFIT.OTHER_REMARKS%TYPE,
							                 	 V_ADDED_BY             IN     NUMBER,
                                 V_ROWS_PROCESSED       OUT    NUMBER
								                )
								
as

CURSOR POLICY_CUR
IS
SELECT A.Policy_Number,A.Policy_Seq_Id
FROM APP.TPA_ENR_POLICY a join Tpa_Ins_Prod_Policy b on (a.POLICY_SEQ_ID = b.POLICY_SEQ_ID)
WHERE  b.PROD_POLICY_SEQ_ID = V_PROD_POLICY_SEQ_ID;

NAME   POLICY_CUR%ROWTYPE;

-----------***********************************************************
--
--CURSOR ACTIVITY_ICD_CUR
--IS
--SELECT CASE WHEN ACTIVITY = 'A'  THEN  REGEXP_SUBSTR(ACTIVITY_CODE , '[^|]+', 1, 2) --REPLACE(ACTIVITY_CODE,'A|')
--            WHEN ICD      = 'D'  THEN REGEXP_SUBSTR(ICD_CODE , '[^|]+', 1, 2)
--			ELSE NULL
--            END  MASTER_CODE
--FROM TPA_SUBBENEFIT_DETAILS
--WHERE SUB_BENF_SEQ_ID  =  V_SUB_BENF_SEQ_ID;

--CURSOR ACTIVITY_ICD_CUR
--IS
--SELECT CASE WHEN ACTIVITY = 'A'  THEN  REPLACE(ACTIVITY_CODE , 'A|')
--            WHEN ICD      = 'D'  THEN  REPLACE(ICD_CODE , 'D|')
--			ELSE NULL
--            END  MASTER_CODE
--FROM APP.TPA_SUBBENEFIT_DETAILS
--WHERE SUB_BENF_SEQ_ID  = V_SUB_BENF_SEQ_ID;

CURSOR ACTIVITY_ICD_CUR
IS
SELECT CASE WHEN CODE_TYPE = 'A'  THEN  REPLACE(MASTER_CODE , 'A|')
            WHEN CODE_TYPE = 'D'  THEN  REPLACE(MASTER_CODE , 'D|')
			ELSE NULL
            END  MASTER
FROM APP.TPA_SUBBENEFIT_DETAILS
WHERE SUB_BENF_DTL_SEQ_ID  = V_SUB_BENF_SEQ_ID;

CODE   ACTIVITY_ICD_CUR%ROWTYPE;


begin

OPEN POLICY_CUR;
FETCH POLICY_CUR INTO NAME;
CLOSE POLICY_CUR;

OPEN  ACTIVITY_ICD_CUR;
FETCH ACTIVITY_ICD_CUR INTO CODE;
CLOSE ACTIVITY_ICD_CUR;


IF NVL(V_RULE_BENEFIT_SEQ_ID,0) =  0  THEN
  
   insert into 	APP.TPA_RULE_BENEFIT (
                                   RULE_BENEFIT_SEQ_ID,
								                   POLICY_SEQ_ID,
								                   POLICY_NUMBER,
								                   BENEFIT_NAME,
								                   SUB_BENF_NAME,
                                   MASTER_CODE,
                                   COVERAGE_PAY_VAL,
                                   COVERAGE,
								                   LIMIT,
								                   COPAY,
								                   DEDUCTABLE,
								                   MEM_WAITING,
								                   SESSION_ALLOWED,
								                  -- PROV_WISE_LIMIT,
								                   TYPE_MODE,
                                   OTHER_REMARKS,
                                   ADDED_BY,
                                   ADDED_DATE,
                                   SUB_BENF_DTL_SEQ_ID
								                 )
						           	VALUES
                                (
                                   TPA_RULE_BENEFIT_SEQ.NEXTVAL,
								                   NAME.POLICY_SEQ_ID,
								                   NAME.POLICY_NUMBER,
								                   V_BENEFIT_NAME,
								                   V_SUB_BENF_NAME,
								                   CODE.MASTER,
                                   V_COVERAGE_PAY_VAL,
								                   V_COVERAGE,
								                   V_LIMIT,
								                   V_COPAY,
								                   V_DEDUCTABLE,
								                   V_MEM_WAITING,
								                   V_SESSION_ALLOWED,
								                  --- V_PROV_WISE_LIMIT,
								                   V_TYPE_MODE,
								                   V_OTHER_REMARKS,
								                   V_ADDED_BY,
								                   SYSDATE,
                                   V_SUB_BENF_SEQ_ID
								                  )
								  returning RULE_BENEFIT_SEQ_ID into V_RULE_BENEFIT_SEQ_ID;
								  
								  
ELSE

    UPDATE   APP.TPA_RULE_BENEFIT	
     SET  RULE_BENEFIT_SEQ_ID      = V_RULE_BENEFIT_SEQ_ID,
		      POLICY_SEQ_ID            = NAME.POLICY_SEQ_ID,
		      POLICY_NUMBER            = NAME.POLICY_NUMBER,
	        BENEFIT_NAME             = V_BENEFIT_NAME,
	        SUB_BENF_NAME            = V_SUB_BENF_NAME,
		      MASTER_CODE              = CODE.MASTER,
  		    COVERAGE_PAY_VAL         = V_COVERAGE_PAY_VAL,
		      COVERAGE                 = V_COVERAGE,
		      LIMIT                    = V_LIMIT,
          COPAY					           = V_COPAY,
		      DEDUCTABLE               = V_DEDUCTABLE,
		      MEM_WAITING              = V_MEM_WAITING,
		      SESSION_ALLOWED          = V_SESSION_ALLOWED,
		      --PROV_WISE_LIMIT          = V_PROV_WISE_LIMIT,
		      TYPE_MODE                = V_TYPE_MODE,
		      OTHER_REMARKS            = V_OTHER_REMARKS,
		      updated_by               = V_ADDED_BY,
		      updated_date             = SYSDATE,
          SUB_BENF_DTL_SEQ_ID      = V_SUB_BENF_SEQ_ID
		  
	  	 where RULE_BENEFIT_SEQ_ID   =  V_RULE_BENEFIT_SEQ_ID;
		 
		 
END IF;

        V_ROWS_PROCESSED  := SQL%ROWCOUNT;
	  --  COMMIT; 

END SAVE_POLICY_DATA_INFO;	

---------------***********************************---------------------------
--------***********proicedure for dispay policy level benefit wise information********--------------------

PROCEDURE display_policy_info  (
                                v_prod_policy_seq_id    IN   Tpa_Ins_Prod_Policy.prod_policy_seq_id%type,
                                result_set              OUT  sys_refcursor,
                                overall_remarks         OUT  sys_refcursor      -------********************need to add in branch******     
                               )
      IS 
      
 CURSOR POLICY_CUR
IS
SELECT A.Policy_Number,A.Policy_Seq_Id
FROM APP.TPA_ENR_POLICY a JOIN app.Tpa_Ins_Prod_Policy b on (a.POLICY_SEQ_ID = b.POLICY_SEQ_ID)
WHERE  b.PROD_POLICY_SEQ_ID = V_PROD_POLICY_SEQ_ID;
 
POLICY_ID    POLICY_CUR%ROWTYPE;
      
 BEGIN
 
 
 OPEN POLICY_CUR;
 FETCH POLICY_CUR INTO POLICY_ID;
 CLOSE POLICY_CUR;
 
 
--   for i in (   select count(*) a from tpa_rule_benefit where policy_seq_id = policy_id.Policy_Seq_Id) loop
--   if i.a > 0 then  

      OPEN result_set FOR
       SELECT  r.rule_benefit_seq_id,
               r.policy_seq_id,
               r.policy_number,
               r.sub_benf_dtl_seq_id sub_benf_seq_id,
               r.benefit_name,
               r.sub_benf_name,
               r.master_code,
               r.coverage_pay_val,
               r.coverage,
               r.limit,
               r.copay,
               r.deductable,
               r.mem_waiting,
               r.session_allowed,
              -- r.prov_wise_limit,
               r.type_mode,
               r.other_remarks
               
        FROM APP.tpa_rule_benefit r
        WHERE r.policy_seq_id = policy_id.Policy_Seq_Id
        ORDER BY 4;
        
   -------********************need to add in branch******     
        
       OPEN overall_remarks FOR 
          SELECT r1.overall_remarks
            FROM  APP.tpa_enr_policy r1
            WHERE r1.policy_seq_id = policy_id.Policy_Seq_Id;
--       else 
      
--       
--        open result_set for 
--        select null 
--        from dual;
--        
--        end if;
        
--        end loop;
        
               
 END display_policy_info;   

-------------------************************************--------------------------
-----***********procedure for display of benefit information from policy***********------------------

PROCEDURE select_benefit_limit (
    v_policy_seq_id            IN  app.tpa_enr_policy.policy_seq_id%TYPE,
    v_member_seq_id            IN  app.tpa_enr_policy_member.member_seq_id%TYPE,
    v_request_type             IN  varchar2,
    v_seq_id                   IN  app.clm_authorization_details.claim_seq_id%type,
    v_benefit_type             in  varchar2,
    v_result_set               OUT SYS_REFCURSOR,
    v_policy_details           OUT SYS_REFCURSOR,
    v_available_sum_insured    OUT SYS_REFCURSOR,
    v_overall_remark           OUT SYS_REFCURSOR     -------********************need to add in branch******     
   )
IS

  CURSOR benefit_cur
  IS
  SELECT COUNT(*) 
  FROM  APP.tpa_rule_benefit 
  WHERE policy_seq_id = v_policy_seq_id;
 
  rec NUMBER(3);
 
   CURSOR amount_cur
  IS
  SELECT  eb.sum_insured  sum_insured,
        nvl(eb.utilised_sum_insured,0)  utilised_sum_insured,
        eb.sum_insured - nvl(eb.utilised_sum_insured,0) as available_sum_insured 
  FROM APP.tpa_enr_policy p
  LEFT JOIN APP.tpa_enr_policy_group pg
    ON (p.policy_seq_id = pg.policy_seq_id)
  LEFT JOIN APP.tpa_enr_policy_member pm
    ON (pm.policy_group_seq_id = pg.policy_group_seq_id)
  LEFT JOIN APP.tpa_enr_balance eb
    ON (eb.policy_group_seq_id = pg.policy_group_seq_id)
 WHERE pm.member_seq_id=v_member_seq_id
   AND (pm.mem_general_type_id != 'PFL' AND
       pm.member_seq_id = eb.member_seq_id OR eb.member_seq_id IS NULL OR
       pm.member_seq_id IS NULL) ;
       
  amount   amount_cur%rowtype;  
  
  CURSOR benefit_count 
  is
  select count(v_benefit_type)
  from dual;
  
  cnt number;
  
  benefit_type           varchar2(30); ---------add to commit in branch
  
BEGIN


--------add to commit in branch
 \*select case     when v_benefit_type = 'IPT'   then 'In-Patient'
                 when v_benefit_type = 'OPTS'  then 'Out-patient' 
                 when v_benefit_type = 'OPTC'  then 'Optical'
                 when v_benefit_type = 'IMTI'  then 'Maternity'
                 when v_benefit_type = 'OMTI'  then 'Maternity'
                 when v_benefit_type = 'MTI'   then 'Maternity'
                 when v_benefit_type = 'DNTL'  then 'Dental' 
                 when v_benefit_type = 'HEAC'  then 'Health Check Up' 
              -- when v_benefit_type = 'DAYC'  then 'Daycare' 
                 end as v_benefit_type into benefit_type from dual; *\

  OPEN benefit_cur;
  FETCH benefit_cur INTO rec;
  CLOSE benefit_cur;

  OPEN amount_cur;
  FETCH amount_cur into amount;
  CLOSE amount_cur;
  
  OPEN benefit_count;
  FETCH benefit_count INTO  cnt;
  CLOSE benefit_count;




IF cnt = 0 THEN 

IF rec > 0 then 

OPEN v_result_set FOR 
SELECT  r1.RULE_BENEFIT_SEQ_ID,
          r1.policy_seq_id,
          r1.POLICY_NUMBER,
          r1.BENEFIT_NAME,
          r1.SUB_BENF_NAME,
          r1.MASTER_CODE,
          CASE  WHEN   r1.COVERAGE_PAY_VAL = 1 THEN 'Pay'
                WHEN   r1.COVERAGE_PAY_VAL = 2 THEN 'Don'||''''||'t pay'
                WHEN   r1.COVERAGE_PAY_VAL = 3 THEN 'Pay Conditionally'
                END  COVERAGE_PAY_VAL,
          nvl(to_char(r1.COVERAGE),' ') COVERAGE,
          nvl(to_char(r1.LIMIT),' ') LIMIT,
          nvl(to_char(r1.copay),' ') copay,
          nvl(to_char(r1.DEDUCTABLE),' ') DEDUCTABLE,
          nvl(to_char(r1.MEM_WAITING),' ') MEM_WAITING,
          nvl(to_char(r1.SESSION_ALLOWED),' ') SESSION_ALLOWED,
          CASE WHEN r1.type_mode='PC' THEN 'Per Claim'
               WHEN r1.type_mode='PP' THEN 'Per Policy Period'
               ELSE 
               ' ' 
              END  type_mode,
         nvl(to_char(r1.OTHER_REMARKS),' ') OTHER_REMARKS,
          r1.ADDED_BY  ,                 
          r1.ADDED_DATE  ,               
          r1.UPDATED_BY   ,                  
          r1.UPDATED_DATE,
          ------------------------****utlilised limit ******--------------------------- need to add  in branch
   CASE WHEN r1.type_mode = 'PP'  THEN 
           CASE WHEN  r1.MASTER_CODE is not null AND r1.master_code not in ('CBF') THEN  -----1
                  CASE WHEN R1.LIMIT IS NOT NULL THEN 
                   CASE WHEN R1.LIMIT >NVL(get_utilized_amt_act_icd(v_policy_seq_id,v_member_seq_id, r1.MASTER_CODE,r1.SUB_BENF_NAME,v_request_type,v_seq_id),0) then
                      TO_CHAR (NVL(get_utilized_amt_act_icd(v_policy_seq_id,v_member_seq_id, r1.MASTER_CODE,r1.SUB_BENF_NAME,v_request_type,v_seq_id),0)) -----calculate the limit
                      ELSE 
                      TO_CHAR(r1.limit)
                      END
                   ELSE
                    TO_CHAR(0)  ---TO_CHAR(amount.utilised_sum_insured) ---LIMIT IS NOT GIVEN
                   END   
             ELSE  
                  CASE WHEN r1.sub_benf_name in ('Cash Benefit','International Emergency medical assistance',
                                                  'Palliative and hospice care benefit','In-Patient Rehabilitation',
                                                  'Health Check Up') then  --------2
                     CASE WHEN R1.LIMIT IS NOT NULL THEN
                          CASE WHEN R1.LIMIT > NVL(get_utilize_amt_benfit_type(v_policy_seq_id,v_member_seq_id,  r1.SUB_BENF_NAME,v_request_type,v_seq_id),0) then 
                             TO_CHAR(NVL(get_utilize_amt_benfit_type(v_policy_seq_id,v_member_seq_id,  r1.SUB_BENF_NAME,v_request_type,v_seq_id),0))
                          else
                             TO_CHAR(r1.limit)
                          END  
                      ELSE  
                        TO_CHAR(0)----TO_CHAR(amount.utilised_sum_insured) ---LIMIT IS NOT GIVEN 
                      END
                   ELSE   
                       CASE WHEN  r1.sub_benf_name in ('Alternative/Complementary Medicines') then   -----3
                          CASE WHEN R1.LIMIT IS NOT NULL THEN
                              CASE WHEN R1.LIMIT > NVL(get_utilised_amt_med(v_policy_seq_id,v_member_seq_id,v_request_type,v_seq_id),0) THEN
                                 TO_CHAR(NVL(get_utilised_amt_med(v_policy_seq_id,v_member_seq_id,v_request_type,v_seq_id),0))
                             ELSE
                                  TO_CHAR(r1.limit)
                              END
                          ELSE
                             TO_CHAR(0) ------TO_CHAR(amount.utilised_sum_insured) ---LIMIT IS NOT GIVEN 
                          END
                         ELSE
                            CASE WHEN  r1.sub_benf_name in ('Pre-existing Conditions') then   ---------4
                               CASE WHEN R1.LIMIT IS NOT NULL THEN
                                  CASE WHEN R1.LIMIT > NVL(get_utilized_amt_ped_policy(v_policy_seq_id,v_member_seq_id,v_request_type,v_seq_id),0) THEN
                                    TO_CHAR( NVL(get_utilized_amt_ped_policy(v_policy_seq_id,v_member_seq_id,v_request_type,v_seq_id),0))
                                   ELSE
                                      TO_CHAR (r1.limit)
                                   END ---'NA'    ---get_utilized_amt_ped_policy
                               ELSE
                                 TO_CHAR(0) ------TO_CHAR(amount.utilised_sum_insured) ---LIMIT IS NOT GIVEN 
                               END
                             ELSE
    ------------------*****************************************************************                         
                                CASE WHEN R1.BENEFIT_NAME  IN ('Area Of Coverage') and r1.SUB_BENF_NAME != 'Area of cover geo loc'  THEN   ---------5
								                    CASE WHEN R1.LIMIT IS NOT NULL THEN
									                     CASE WHEN R1.LIMIT > NVL(get_utilized_out_area_policy(v_policy_seq_id,v_member_seq_id,r1.SUB_BENF_NAME,v_request_type,v_seq_id),0) THEN
									                        TO_CHAR(NVL(get_utilized_out_area_policy(v_policy_seq_id,v_member_seq_id,r1.SUB_BENF_NAME,v_request_type,v_seq_id),0))
									                     ELSE
									                        TO_CHAR (r1.limit)
									                     END
									                  ELSE
									                        TO_CHAR(0)
								                    END
								                ELSE
								                  'NA' 
                                END  ----------5
--------------------------**************************************************************                                
                            END    -------4
                       END     -----3
                   END--------2
            END --------1
		        WHEN r1.type_mode = 'PC' THEN 
	    
		CASE WHEN R1.BENEFIT_NAME NOT IN ('Area Of Coverage','Pre-existing Conditions') then 
	         CASE WHEN R1.MASTER_CODE IS NOT NULL AND r1.master_code not in ('CBF') THEN
                 CASE WHEN R1.LIMIT IS NOT NULL THEN  
                   to_char( NVL(get_utilized_amt_act_icd_clm(v_policy_seq_id,v_member_seq_id, r1.MASTER_CODE, r1.SUB_BENF_NAME,v_request_type,v_seq_id),0))		
                  ELSE 
                    to_char(0) -- TO_CHAR(amount.utilised_sum_insured) 
                 END
		        ELSE 
            -----------------*****************************
               CASE WHEN R1.LIMIT IS NOT NULL THEN 
                 TO_CHAR (NVL(get_utilized_amt_act_icd_benf(v_policy_seq_id,v_member_seq_id, r1.SUB_BENF_NAME,v_request_type,v_seq_id),0))
                else
                 to_char(0) ---TO_CHAR(amount.utilised_sum_insured) 
                 END
              --------******************************
            END
            
            
    ELSE --------------********
      CASE WHEN R1.BENEFIT_NAME IN ('Area Of Coverage') and r1.SUB_BENF_NAME != 'Area of cover geo loc'  then 
           CASE WHEN R1.LIMIT IS NOT NULL THEN
               TO_CHAR(NVL(get_utilized_amt_out_area(v_policy_seq_id,v_member_seq_id,r1.SUB_BENF_NAME,v_request_type,v_seq_id),0))
           ELSE
              TO_CHAR(0)
            END
        ELSE
          CASE WHEN R1.BENEFIT_NAME IN ('Pre-existing Conditions') then 
             CASE WHEN R1.LIMIT IS NOT NULL THEN
               TO_CHAR(NVL(get_utilized_amt_ped(v_policy_seq_id,v_member_seq_id,r1.SUB_BENF_NAME,v_request_type,v_seq_id),0))
              ELSE
                TO_CHAR(0)
              END
          ELSE
             TO_CHAR(0)
           END 
         END
       END
    
           ELSE  
           ' '
            END    utilized_limit,
   ------------------------------------------ *****balance******------------------------------        
       CASE WHEN  r1.type_mode = 'PP' THEN  ----Per Policy Period 
             CASE WHEN  r1.MASTER_CODE is not null and r1.master_code not in ('CBF')  THEN  -------1
                CASE WHEN R1.LIMIT IS NOT NULL THEN 
                   CASE WHEN R1.LIMIT > NVL(get_utilized_amt_act_icd(v_policy_seq_id,v_member_seq_id,  r1.MASTER_CODE,r1.SUB_BENF_NAME,v_request_type,v_seq_id),0) THEN ----limit >sum of previous limit
                        to_char(NVL(r1.limit - NVL(get_utilized_amt_act_icd(v_policy_seq_id,v_member_seq_id,  r1.MASTER_CODE,r1.SUB_BENF_NAME,v_request_type,v_seq_id),0),0))
                     ELSE 
                         to_char(0)----- amount.available_sum_insured -  NVL(get_utilized_amt_benfit(v_policy_seq_id,v_member_seq_id,\*r1.MASTER_CODE,str_tab(i)*\ i.val,v_request_type,v_seq_id),0)) 
                      END
                    ELSE    
                      to_char(amount.available_sum_insured)
                   END
             ELSE   
                CASE WHEN r1.sub_benf_name in ('Cash Benefit','International Emergency medical assistance',
                                               'Palliative and hospice care benefit','In-Patient Rehabilitation',
                                               'Health Check Up') then  -------2
                     CASE WHEN R1.LIMIT IS NOT NULL THEN   
                        CASE WHEN R1.LIMIT >NVL(get_utilize_amt_benfit_type(v_policy_seq_id,v_member_seq_id,  r1.SUB_BENF_NAME,v_request_type,v_seq_id),0) THEN  ---- given limit > calculated limit
                          to_char(nvl( r1.limit - NVL(get_utilize_amt_benfit_type(v_policy_seq_id,v_member_seq_id,  r1.SUB_BENF_NAME,v_request_type,v_seq_id),0),0))
                        ELSE  
                         to_char(0)
                         END
                      ELSE   
                         to_char(amount.available_sum_insured)
                     END
                  ELSE  
                    CASE WHEN  r1.sub_benf_name in ('Alternative/Complementary Medicines') then  -----3 
                        CASE WHEN R1.LIMIT IS NOT NULL THEN 
                            CASE WHEN R1.LIMIT > NVL(get_utilised_amt_med(v_policy_seq_id,v_member_seq_id,v_request_type,v_seq_id),0) THEN
                             to_char( r1.limit - NVL(get_utilised_amt_med(v_policy_seq_id,v_member_seq_id,v_request_type,v_seq_id),0))
                            ELSE
                              to_char(0)
                            END---------
                         ELSE                
                         to_char(amount.available_sum_insured)
                         END
                     ELSE
                         CASE WHEN R1.BENEFIT_NAME IN ('Pre-existing Conditions') then  -----4
                           CASE WHEN R1.LIMIT IS NOT NULL THEN 
                                CASE WHEN R1.LIMIT > NVL(get_utilized_amt_ped_policy(v_policy_seq_id,v_member_seq_id,v_request_type,v_seq_id),0) THEN
                                   to_char( r1.limit -NVL(get_utilized_amt_ped_policy(v_policy_seq_id,v_member_seq_id,v_request_type,v_seq_id),0))
                                ELSE
                                   to_char(0)
                                END
                           ELSE                
                               to_char(amount.available_sum_insured)
                           END 
                        ELSE---------------------------
---------------------------*********************************************                        
                            CASE  WHEN R1.BENEFIT_NAME IN ('Area Of Coverage') and r1.SUB_BENF_NAME != 'Area of cover geo loc'  then  ---------5
							                 CASE WHEN R1.LIMIT IS NOT NULL THEN 
                                  CASE WHEN R1.LIMIT > NVL(get_utilized_out_area_policy(v_policy_seq_id,v_member_seq_id,r1.SUB_BENF_NAME,v_request_type,v_seq_id),0) THEN
                                      to_char( r1.limit -NVL(get_utilized_out_area_policy(v_policy_seq_id,v_member_seq_id,r1.SUB_BENF_NAME,v_request_type,v_seq_id),0))
                                  ELSE
                                      to_char(0)
                                  END---------
                               ELSE                
                                 to_char(amount.available_sum_insured)
                               END
                           
						                ELSE							  
                                to_char(amount.available_sum_insured) 
                            END  ---------5
                   END  -------4
              END  -----3
          END   -----2
	  END  -------1
-----------------------------------------------------        
       WHEN  r1.type_mode = 'PC'  THEN  
            
  --- CASE WHEN R1.BENEFIT_NAME NOT IN ('Pre-existing Conditions') THEN 
       CASE WHEN R1.BENEFIT_NAME NOT IN ('Area Of Coverage','Pre-existing Conditions') \*and r1.SUB_BENF_NAME != 'Area of cover geo loc' *\ then 
		     	CASE WHEN  r1.MASTER_CODE is not null and r1.master_code not in ('CBF')  THEN 
                CASE WHEN R1.LIMIT IS NOT NULL THEN 
                  to_char(R1.LIMIT)\*- NVL(get_utilized_amt_act_icd_clm(v_policy_seq_id,v_member_seq_id, r1.MASTER_CODE,v_request_type,v_seq_id),0)*\
                ELSE
                  to_char(amount.available_sum_insured)
                 END
              ELSE
              --------******************
                case when R1.LIMIT IS NOT NULL THEN
                 to_char(R1.LIMIT)  \*-  NVL(get_utilized_amt_act_icd_benf(v_policy_seq_id,v_member_seq_id, r1.SUB_BENF_NAME,v_request_type,v_seq_id),0)*\
                ELSE
                  to_char(amount.available_sum_insured)
                END
               --------******************
             END
       ELSE
        CASE WHEN R1.BENEFIT_NAME IN ('Area Of Coverage') and r1.SUB_BENF_NAME != 'Area of cover geo loc'  then 
           CASE WHEN R1.LIMIT IS NOT NULL THEN 
                TO_CHAR(R1.LIMIT)
           ELSE
             to_char(amount.available_sum_insured)
            END
         ELSE 
            CASE WHEN R1.BENEFIT_NAME  IN ('Pre-existing Conditions') THEN 
               CASE WHEN R1.LIMIT IS NOT NULL THEN 
                 TO_CHAR(R1.LIMIT)
               ELSE
                to_char(amount.available_sum_insured)
               END
            ELSE
              to_char(amount.available_sum_insured)
             END
          END
        END
    ---  END
     
              
          ELSE
           ' '
          End   balance       
            ---------------------------
	  FROM  Tpa_Rule_Benefit \*test2*\ R1
      WHERE r1.policy_seq_id=v_policy_seq_id -- or r1.BENEFIT_NAME  = benefit_type  ----add to commit in branch
      order by r1.BENEFIT_NAME,r1.SUB_BENF_DTL_SEQ_ID ;  ----add to commit in branch
      
    
----------*******benefit display************---------------

--  OPEN v_result_set for
--       select ' '  rule_benefit_seq_id,
--              ' '  policy_seq_id,
--              ' '  policy_number,
--              ' '  benefit_name,
--              ' '  sub_benf_name,
--              ' '  master_code,
--              ' '  coverage_pay_val,
--              ' '  coverage,
--              ' '  Limit,
--              ' '  copay,
--              ' '  deductable,
--              ' '  mem_waiting,
--              ' '  session_allowed,
--              ' '  prov_wise_limit,
--              ' '  type_mode,
--              ' '  other_remarks,
--              ' '  utilized_limit,
--              ' '  balance
--        from dual;


----------********policy_details*********-------------------   

     OPEN v_policy_details for 
    SELECT c.tpa_enrollment_id,
           to_char(a.policy_issue_date,'dd/mm/yyyy') policy_issue_date,
           a.policy_number,
           to_char(a.effective_from_date,'dd/mm/yyyy') effective_from_date,
           e.product_cat_type_id,
           to_char(a.effective_to_date,'dd/mm/yyyy') effective_to_date
     FROM APP.tpa_enr_policy A JOIN APP.tpa_enr_policy_group B ON (a.policy_seq_id=b.policy_seq_id)
                               JOIN APP.tpa_enr_policy_member c ON (b.policy_group_seq_id = c.policy_group_seq_id)
                    LEFT OUTER JOIN APP.tpa_ins_product e ON (a.product_seq_id=e.product_seq_id)
      WHERE c.member_seq_id = v_member_seq_id;
      
 ----------*******member sum insured info************------------------  

        OPEN v_available_sum_insured FOR  
  SELECT eb.sum_insured  sum_insured,
         nvl(eb.utilised_sum_insured,0) utilised_sum_insured,
         eb.sum_insured - nvl(eb.utilised_sum_insured,0) as available_sum_insured 
  FROM APP.tpa_enr_policy p
  LEFT JOIN APP.tpa_enr_policy_group pg
    ON (p.policy_seq_id = pg.policy_seq_id)
  LEFT JOIN APP.tpa_enr_policy_member pm
    ON (pm.policy_group_seq_id = pg.policy_group_seq_id)
  LEFT JOIN APP.tpa_enr_balance eb
    ON (eb.policy_group_seq_id = pg.policy_group_seq_id)
 WHERE pm.member_seq_id=v_member_seq_id
   AND (pm.mem_general_type_id != 'PFL' AND
       pm.member_seq_id = eb.member_seq_id OR eb.member_seq_id IS NULL OR
       pm.member_seq_id IS NULL) ;


------------**********overall remarks********----------
--

      OPEN v_overall_remark  FOR 
       SELECT nvl(to_char(a.overall_remarks),' ')  as overall_remarks
       FROM tpa_enr_policy  a
       where a.policy_seq_id=v_policy_seq_id; ----add to commit in branch
--       
       
ELSE


  OPEN v_result_set for
       select ' '  rule_benefit_seq_id,
              ' '  policy_seq_id,
              ' '  policy_number,
              ' '  benefit_name,
              ' '  sub_benf_name,
              ' '  master_code,
              ' '  coverage_pay_val,
              ' '  coverage,
              ' '  Limit,
              ' '  copay,
              ' '  deductable,
              ' '  mem_waiting,
              ' '  session_allowed,
             -- ' '  prov_wise_limit,
              ' '  type_mode,
              ' '  other_remarks,
              ' '  utilized_limit,
              ' '  balance
        from dual;
 ----------********policy_details*********-------------------   
     OPEN v_policy_details for 
    SELECT c.tpa_enrollment_id,
           to_char(a.policy_issue_date,'dd/mm/yyyy') policy_issue_date,
           a.policy_number,
           to_char(a.effective_from_date,'dd/mm/yyyy') effective_from_date,
           e.product_cat_type_id,
           to_char(a.effective_to_date,'dd/mm/yyyy') effective_to_date
     FROM APP.tpa_enr_policy A JOIN APP.tpa_enr_policy_group B ON (a.policy_seq_id=b.policy_seq_id)
                               JOIN APP.tpa_enr_policy_member c ON (b.policy_group_seq_id = c.policy_group_seq_id)
                    LEFT OUTER JOIN APP.tpa_ins_product e ON (a.product_seq_id=e.product_seq_id)
      WHERE c.member_seq_id = v_member_seq_id;

  ----------*******member sum insured info************------------------  

        OPEN v_available_sum_insured FOR  
  SELECT eb.sum_insured  sum_insured,
         nvl(eb.utilised_sum_insured,0) utilised_sum_insured,
         eb.sum_insured - nvl(eb.utilised_sum_insured,0) as available_sum_insured 
  FROM APP.tpa_enr_policy p
  LEFT JOIN APP.tpa_enr_policy_group pg
    ON (p.policy_seq_id = pg.policy_seq_id)
  LEFT JOIN APP.tpa_enr_policy_member pm
    ON (pm.policy_group_seq_id = pg.policy_group_seq_id)
  LEFT JOIN APP.tpa_enr_balance eb
    ON (eb.policy_group_seq_id = pg.policy_group_seq_id)
 WHERE pm.member_seq_id=v_member_seq_id
   AND (pm.mem_general_type_id != 'PFL' AND
       pm.member_seq_id = eb.member_seq_id OR eb.member_seq_id IS NULL OR
       pm.member_seq_id IS NULL) ;
       
     OPEN v_overall_remark  FOR 
       SELECT nvl(to_char(a.overall_remarks),' ')  as overall_remarks
       FROM tpa_enr_policy  a
       where a.policy_seq_id=v_policy_seq_id; 


END IF; 

ELSE

OPEN v_result_set FOR 
 SELECT  r1.RULE_BENEFIT_SEQ_ID,
          r1.policy_seq_id,
          r1.POLICY_NUMBER,
          r1.BENEFIT_NAME,
          r1.SUB_BENF_NAME,
          r1.MASTER_CODE,
          CASE  WHEN   r1.COVERAGE_PAY_VAL = 1 THEN 'Pay'
                WHEN   r1.COVERAGE_PAY_VAL = 2 THEN 'Don'||''''||'t pay'
                WHEN   r1.COVERAGE_PAY_VAL = 3 THEN 'Pay Conditionally'
                END  COVERAGE_PAY_VAL,
          nvl(to_char(r1.COVERAGE),' ') COVERAGE,
          nvl(to_char(r1.LIMIT),' ') LIMIT,
          nvl(to_char(r1.copay),' ') copay,
          nvl(to_char(r1.DEDUCTABLE),' ') DEDUCTABLE,
          nvl(to_char(r1.MEM_WAITING),' ') MEM_WAITING,
          nvl(to_char(r1.SESSION_ALLOWED),' ') SESSION_ALLOWED,
          CASE WHEN r1.type_mode='PC' THEN 'Per Claim'
               WHEN r1.type_mode='PP' THEN 'Per Policy Period'
               ELSE 
               ' ' 
              END  type_mode,
         nvl(to_char(r1.OTHER_REMARKS),' ') OTHER_REMARKS,
          r1.ADDED_BY  ,                 
          r1.ADDED_DATE  ,               
          r1.UPDATED_BY   ,                  
          r1.UPDATED_DATE,
          ------------------------****utlilised limit ******---------------------------
   CASE WHEN r1.type_mode = 'PP'  THEN 
           CASE WHEN  r1.MASTER_CODE is not null AND r1.master_code not in ('CBF') THEN  ------1
                  CASE WHEN R1.LIMIT IS NOT NULL THEN 
                   CASE WHEN R1.LIMIT >NVL(get_utilized_amt_act_icd(v_policy_seq_id,v_member_seq_id, r1.MASTER_CODE,r1.SUB_BENF_NAME,v_request_type,v_seq_id),0) then
                      TO_CHAR (NVL(get_utilized_amt_act_icd(v_policy_seq_id,v_member_seq_id, r1.MASTER_CODE,r1.SUB_BENF_NAME,v_request_type,v_seq_id),0)) -----calculate the limit
                      ELSE 
                      TO_CHAR(r1.limit)
                      END
                   ELSE
                    TO_CHAR(0)  ---TO_CHAR(amount.utilised_sum_insured) ---LIMIT IS NOT GIVEN
                   END   
             ELSE  
                  CASE WHEN r1.sub_benf_name in ('Cash Benefit','International Emergency medical assistance',
                                                  'Palliative and hospice care benefit','In-Patient Rehabilitation',
                                                  'Health Check Up') then  ---------2
                     CASE WHEN R1.LIMIT IS NOT NULL THEN
                          CASE WHEN R1.LIMIT > NVL(get_utilize_amt_benfit_type(v_policy_seq_id,v_member_seq_id,  r1.SUB_BENF_NAME,v_request_type,v_seq_id),0) then 
                             TO_CHAR(NVL(get_utilize_amt_benfit_type(v_policy_seq_id,v_member_seq_id,  r1.SUB_BENF_NAME,v_request_type,v_seq_id),0))
                          else
                             TO_CHAR(r1.limit)
                          END  
                      ELSE  
                        TO_CHAR(0)----TO_CHAR(amount.utilised_sum_insured) ---LIMIT IS NOT GIVEN 
                      END
                   ELSE   
                       CASE WHEN  r1.sub_benf_name in ('Alternative/Complementary Medicines') then  --------3
                          CASE WHEN R1.LIMIT IS NOT NULL THEN
                              CASE WHEN R1.LIMIT > NVL(get_utilised_amt_med(v_policy_seq_id,v_member_seq_id,v_request_type,v_seq_id),0) THEN
                                 TO_CHAR(NVL(get_utilised_amt_med(v_policy_seq_id,v_member_seq_id,v_request_type,v_seq_id),0))
                             ELSE
                                  TO_CHAR(r1.limit)
                              END
                          ELSE
                             TO_CHAR(0) ------TO_CHAR(amount.utilised_sum_insured) ---LIMIT IS NOT GIVEN 
                          END
                         ELSE
                            CASE WHEN  r1.sub_benf_name in ('Pre-existing Conditions') then    --------4
                               CASE WHEN R1.LIMIT IS NOT NULL THEN
                                  CASE WHEN R1.LIMIT > NVL(get_utilized_amt_ped_policy(v_policy_seq_id,v_member_seq_id,v_request_type,v_seq_id),0) THEN
                                    TO_CHAR( NVL(get_utilized_amt_ped_policy(v_policy_seq_id,v_member_seq_id,v_request_type,v_seq_id),0))
                                   ELSE
                                      TO_CHAR (r1.limit)
                                   END ---'NA'    ---get_utilized_amt_ped_policy
                               ELSE
                                 TO_CHAR(0) ------TO_CHAR(amount.utilised_sum_insured) ---LIMIT IS NOT GIVEN 
                               END
                             ELSE
    ------------------*****************************************************************                         
                                CASE WHEN R1.BENEFIT_NAME  IN ('Area Of Coverage') and r1.SUB_BENF_NAME != 'Area of cover geo loc'  THEN   ------5
								                    CASE WHEN R1.LIMIT IS NOT NULL THEN
									                     CASE WHEN R1.LIMIT > NVL(get_utilized_out_area_policy(v_policy_seq_id,v_member_seq_id,r1.SUB_BENF_NAME,v_request_type,v_seq_id),0) THEN
									                        TO_CHAR(NVL(get_utilized_out_area_policy(v_policy_seq_id,v_member_seq_id,r1.SUB_BENF_NAME,v_request_type,v_seq_id),0))
									                     ELSE
									                        TO_CHAR (r1.limit)
									                     END
									                  ELSE
									                        TO_CHAR(0)
								                    END
								                ELSE
								                  'NA' 
                                END    -------5
--------------------------**************************************************************                                
                            END   ------4
                       END    -----3   
                   END   -----2
            END  -----1
		        WHEN r1.type_mode = 'PC' THEN 
	    
		CASE WHEN R1.BENEFIT_NAME NOT IN ('Area Of Coverage','Pre-existing Conditions') then 
	         CASE WHEN R1.MASTER_CODE IS NOT NULL AND r1.master_code not in ('CBF') THEN
                 CASE WHEN R1.LIMIT IS NOT NULL THEN  
                   to_char( NVL(get_utilized_amt_act_icd_clm(v_policy_seq_id,v_member_seq_id, r1.MASTER_CODE, r1.SUB_BENF_NAME,v_request_type,v_seq_id),0))		
                  ELSE 
                    to_char(0) -- TO_CHAR(amount.utilised_sum_insured) 
                 END
		        ELSE 
            -----------------*****************************
               CASE WHEN R1.LIMIT IS NOT NULL THEN 
                 TO_CHAR (NVL(get_utilized_amt_act_icd_benf(v_policy_seq_id,v_member_seq_id, r1.SUB_BENF_NAME,v_request_type,v_seq_id),0))
                else
                 to_char(0) ---TO_CHAR(amount.utilised_sum_insured) 
                 END
              --------******************************
            END
            
            
    ELSE --------------********
      CASE WHEN R1.BENEFIT_NAME IN ('Area Of Coverage') and r1.SUB_BENF_NAME != 'Area of cover geo loc'  then 
           CASE WHEN R1.LIMIT IS NOT NULL THEN
               TO_CHAR(NVL(get_utilized_amt_out_area(v_policy_seq_id,v_member_seq_id,r1.SUB_BENF_NAME,v_request_type,v_seq_id),0))
           ELSE
              TO_CHAR(0)
            END
        ELSE
          CASE WHEN R1.BENEFIT_NAME IN ('Pre-existing Conditions') then 
             CASE WHEN R1.LIMIT IS NOT NULL THEN
               TO_CHAR(NVL(get_utilized_amt_ped(v_policy_seq_id,v_member_seq_id,r1.SUB_BENF_NAME,v_request_type,v_seq_id),0))
              ELSE
                TO_CHAR(0)
              END
          ELSE
             TO_CHAR(0)
           END 
         END
       END
    
           ELSE  
           ' '
            END    utilized_limit,
   ------------------------------------------ *****balance******------------------------------        
       CASE WHEN  r1.type_mode = 'PP' THEN  ----Per Policy Period 
             CASE WHEN  r1.MASTER_CODE is not null and r1.master_code not in ('CBF')  THEN ---------1
                CASE WHEN R1.LIMIT IS NOT NULL THEN 
                   CASE WHEN R1.LIMIT > NVL(get_utilized_amt_act_icd(v_policy_seq_id,v_member_seq_id,  r1.MASTER_CODE,r1.SUB_BENF_NAME,v_request_type,v_seq_id),0) THEN ----limit >sum of previous limit
                        to_char(NVL(r1.limit - NVL(get_utilized_amt_act_icd(v_policy_seq_id,v_member_seq_id,  r1.MASTER_CODE,r1.SUB_BENF_NAME,v_request_type,v_seq_id),0),0))
                     ELSE 
                         to_char(0)----- amount.available_sum_insured -  NVL(get_utilized_amt_benfit(v_policy_seq_id,v_member_seq_id,\*r1.MASTER_CODE,str_tab(i)*\ i.val,v_request_type,v_seq_id),0)) 
                      END
                    ELSE    
                      to_char(amount.available_sum_insured)
                   END
             ELSE   
                CASE WHEN r1.sub_benf_name in ('Cash Benefit','International Emergency medical assistance',
                                               'Palliative and hospice care benefit','In-Patient Rehabilitation',
                                               'Health Check Up') then ---------2
                     CASE WHEN R1.LIMIT IS NOT NULL THEN   
                        CASE WHEN R1.LIMIT >NVL(get_utilize_amt_benfit_type(v_policy_seq_id,v_member_seq_id,  r1.SUB_BENF_NAME,v_request_type,v_seq_id),0) THEN  ---- given limit > calculated limit
                          to_char(nvl( r1.limit - NVL(get_utilize_amt_benfit_type(v_policy_seq_id,v_member_seq_id,  r1.SUB_BENF_NAME,v_request_type,v_seq_id),0),0))
                        ELSE  
                         to_char(0)
                         END
                      ELSE   
                         to_char(amount.available_sum_insured)
                     END
                  ELSE  
                    CASE WHEN  r1.sub_benf_name in ('Alternative/Complementary Medicines') then  --------3
                        CASE WHEN R1.LIMIT IS NOT NULL THEN 
                            CASE WHEN R1.LIMIT > NVL(get_utilised_amt_med(v_policy_seq_id,v_member_seq_id,v_request_type,v_seq_id),0) THEN
                             to_char( r1.limit - NVL(get_utilised_amt_med(v_policy_seq_id,v_member_seq_id,v_request_type,v_seq_id),0))
                            ELSE
                              to_char(0)
                            END---------
                         ELSE                
                         to_char(amount.available_sum_insured)
                         END
                     ELSE
                         CASE WHEN R1.BENEFIT_NAME IN ('Pre-existing Conditions') then  -------------4
                           CASE WHEN R1.LIMIT IS NOT NULL THEN 
                                CASE WHEN R1.LIMIT > NVL(get_utilized_amt_ped_policy(v_policy_seq_id,v_member_seq_id,v_request_type,v_seq_id),0) THEN
                                   to_char( r1.limit -NVL(get_utilized_amt_ped_policy(v_policy_seq_id,v_member_seq_id,v_request_type,v_seq_id),0))
                                ELSE
                                   to_char(0)
                                END
                           ELSE                
                               to_char(amount.available_sum_insured)
                           END 
                        ELSE---------------------------
---------------------------*********************************************                        
                            CASE  WHEN R1.BENEFIT_NAME IN ('Area Of Coverage') and r1.SUB_BENF_NAME != 'Area of cover geo loc'  then  ----------5
							                 CASE WHEN R1.LIMIT IS NOT NULL THEN 
                                  CASE WHEN R1.LIMIT > NVL(get_utilized_out_area_policy(v_policy_seq_id,v_member_seq_id,r1.SUB_BENF_NAME,v_request_type,v_seq_id),0) THEN
                                      to_char( r1.limit -NVL(get_utilized_out_area_policy(v_policy_seq_id,v_member_seq_id,r1.SUB_BENF_NAME,v_request_type,v_seq_id),0))
                                  ELSE
                                      to_char(0)
                                  END---------
                               ELSE                
                                 to_char(amount.available_sum_insured)
                               END
                           
						                ELSE							  
                                to_char(amount.available_sum_insured) 
                            END  --------5
                   END--------4
              END------3
          END ------2
	  END -----1
-----------------------------------------------------        
       WHEN  r1.type_mode = 'PC'  THEN  
            
  --- CASE WHEN R1.BENEFIT_NAME NOT IN ('Pre-existing Conditions') THEN 
       CASE WHEN R1.BENEFIT_NAME NOT IN ('Area Of Coverage','Pre-existing Conditions') \*and r1.SUB_BENF_NAME != 'Area of cover geo loc' *\ then 
		     	CASE WHEN  r1.MASTER_CODE is not null and r1.master_code not in ('CBF')  THEN 
                CASE WHEN R1.LIMIT IS NOT NULL THEN 
                  to_char(R1.LIMIT)\*- NVL(get_utilized_amt_act_icd_clm(v_policy_seq_id,v_member_seq_id, r1.MASTER_CODE,v_request_type,v_seq_id),0)*\
                ELSE
                  to_char(amount.available_sum_insured)
                 END
              ELSE
              --------******************
                case when R1.LIMIT IS NOT NULL THEN
                 to_char(R1.LIMIT)  \*-  NVL(get_utilized_amt_act_icd_benf(v_policy_seq_id,v_member_seq_id, r1.SUB_BENF_NAME,v_request_type,v_seq_id),0)*\
                ELSE
                  to_char(amount.available_sum_insured)
                END
               --------******************
             END
       ELSE
        CASE WHEN R1.BENEFIT_NAME IN ('Area Of Coverage') and r1.SUB_BENF_NAME != 'Area of cover geo loc'  then 
           CASE WHEN R1.LIMIT IS NOT NULL THEN 
                TO_CHAR(R1.LIMIT)
           ELSE
             to_char(amount.available_sum_insured)
            END
         ELSE 
            CASE WHEN R1.BENEFIT_NAME  IN ('Pre-existing Conditions') THEN 
               CASE WHEN R1.LIMIT IS NOT NULL THEN 
                 TO_CHAR(R1.LIMIT)
               ELSE
                to_char(amount.available_sum_insured)
               END
            ELSE
              to_char(amount.available_sum_insured)
             END
          END
        END
    ---  END
     
              
          ELSE
           ' '
          End   balance      
            ---------------------------
	  FROM  Tpa_Rule_Benefit \*test2*\ R1
      WHERE r1.policy_seq_id=v_policy_seq_id AND  UPPER(r1.BENEFIT_NAME)  = v_benefit_type  ----add to commit in branch
      order by r1.BENEFIT_NAME,r1.SUB_BENF_DTL_SEQ_ID ;  ----add to commit in branch
      
  ------**************policy details info******------------ 
  
           OPEN v_policy_details for 
    SELECT c.tpa_enrollment_id,
           to_char(a.policy_issue_date,'dd/mm/yyyy') policy_issue_date,
           a.policy_number,
           to_char(a.effective_from_date,'dd/mm/yyyy') effective_from_date,
           e.product_cat_type_id,
           to_char(a.effective_to_date,'dd/mm/yyyy') effective_to_date
     FROM APP.tpa_enr_policy A JOIN APP.tpa_enr_policy_group B ON (a.policy_seq_id=b.policy_seq_id)
                               JOIN APP.tpa_enr_policy_member c ON (b.policy_group_seq_id = c.policy_group_seq_id)
                    LEFT OUTER JOIN APP.tpa_ins_product e ON (a.product_seq_id=e.product_seq_id)
      WHERE c.member_seq_id = v_member_seq_id;

  ----------*******member sum insured info************------------------  

        OPEN v_available_sum_insured FOR  
  SELECT eb.sum_insured  sum_insured,
         nvl(eb.utilised_sum_insured,0) utilised_sum_insured,
         eb.sum_insured - nvl(eb.utilised_sum_insured,0) as available_sum_insured 
  FROM APP.tpa_enr_policy p
  LEFT JOIN APP.tpa_enr_policy_group pg
    ON (p.policy_seq_id = pg.policy_seq_id)
  LEFT JOIN APP.tpa_enr_policy_member pm
    ON (pm.policy_group_seq_id = pg.policy_group_seq_id)
  LEFT JOIN APP.tpa_enr_balance eb
    ON (eb.policy_group_seq_id = pg.policy_group_seq_id)
 WHERE pm.member_seq_id=v_member_seq_id
   AND (pm.mem_general_type_id != 'PFL' AND
       pm.member_seq_id = eb.member_seq_id OR eb.member_seq_id IS NULL OR
       pm.member_seq_id IS NULL) ;
       
--------*******overall remarks*******-----------

 OPEN v_overall_remark  FOR 
       SELECT  nvl(to_char(a.overall_remarks),' ')  as overall_remarks
       FROM tpa_enr_policy  a
       where a.policy_seq_id=v_policy_seq_id;  ----add to commit in branch
      
END IF;

--   OPEN v_overall_remark  FOR 
--       SELECT  nvl(to_char(a.overall_remarks),' ')  as overall_remarks
--       FROM tpa_enr_policy  a
--       where a.policy_seq_id=v_policy_seq_id;  ----add to commit in branch 
   
          
END select_benefit_limit;

-----------**********************************************************-------------------
------*********To get the Utilized amount of  the paticular member for activity or icd code*******---------------------

FUNCTION get_utilized_amt_act_icd
                    (v_policy_seq_id            IN  app.tpa_enr_policy.policy_seq_id%TYPE,
                     v_member_seq_id            IN  app.tpa_enr_policy_member.member_seq_id%TYPE,
                     v_master_activity_code     IN  app.tpa_activity_master_details.master_activity_code%TYPE,
                     v_sub_benf_name            IN VARCHAR2,
                     v_request_type             IN  varchar2,
                     v_seq_id                   IN app.clm_authorization_details.claim_seq_id%type
                     )
RETURN number

IS

 v_utilized_amount number;

--******ACTIVITY 

CURSOR per_policy_act_cur IS
       SELECT SUM(nvl(s.used_amount, r.used_amount))  as utilized_amount1 FROM
         ( SELECT  distinct(b.approved_amount) AS used_amount , b.Pat_Auth_Seq_Id, a.claim_seq_id 
               FROM APP.pat_authorization_details a
               JOIN APP.pat_activity_details b ON (a.pat_auth_seq_id = b.pat_auth_seq_id AND A.pat_status_type_id != 'PCN' AND A.pat_status_type_id != 'REJ' )
               LEFT JOIN APP.tpa_activity_details g ON (b.code = g.activity_code)
               LEFT JOIN APP.tpa_activity_details gg ON (g.master_activity_code = gg.master_activity_code )
			         LEFT JOIN  APP.dental_rule_tab  dd on (dd.cdt_code = b.code)
               LEFT JOIN APP.tpa_activity_master_details m ON (b.code = m.ACTIVITY_CODE)
             ---  LEFT JOIN APP.tpa_activity_master_details ma ON (m.master_activity_code = ma.Master_Activity_Code)
           WHERE A.Member_Seq_Id = v_member_seq_id 
               AND (gg.activity_code in (v_master_activity_code)
               or dd.specific_service_code in (v_master_activity_code)
			    or dd.CDT_CODE  in (v_master_activity_code)
        or dd.master_code in (v_master_activity_code) 
			   or m.master_activity_code in (v_master_activity_code))
               AND a.claim_seq_id IS NULL 
               ) r
          FULL OUTER JOIN
           ( SELECT distinct(b.approved_amount) AS used_amount , a.claim_seq_id
               FROM APP.clm_authorization_details A 
               JOIN APP.pat_activity_details b ON (a.claim_seq_id = b.claim_seq_id AND A.CLM_STATUS_TYPE_ID != 'PCN' AND A.CLM_STATUS_TYPE_ID != 'REJ' )
               LEFT JOIN APP.tpa_activity_details g ON (b.code = g.activity_code)
               LEFT JOIN APP.tpa_activity_details gg ON (g.master_activity_code = gg.master_activity_code )
               LEFT JOIN  APP.dental_rule_tab  dd on (dd.cdt_code = b.code)
               LEFT JOIN APP.tpa_activity_master_details m ON (b.code = m.ACTIVITY_CODE)
               ---LEFT JOIN APP.tpa_activity_master_details ma ON (m.master_activity_code = ma.Master_Activity_Code)
                WHERE A.Member_Seq_Id = v_member_seq_id  
               AND (gg.activity_code in (v_master_activity_code) 
               or dd.specific_service_code in (v_master_activity_code)
			   or dd.CDT_CODE  in (v_master_activity_code)
           or dd.master_code in (v_master_activity_code) 
			   or m.master_activity_code in (v_master_activity_code)
               ))s
               ON ( r.claim_seq_id = s.claim_seq_id )
               WHERE (  NVL(r.Pat_Auth_Seq_Id,0) != NVL(v_seq_id,0)
                OR  NVL(s.claim_seq_id,0) != NVL(v_seq_id,0));
	


rec_get_utilized_amt1   per_policy_act_cur%rowtype;	

----*******ICD
				
	CURSOR per_policy_icd_cur 
	IS			
				SELECT SUM(nvl(s.used_amount, r.used_amount)) as utilized_amount2 FROM
         ( SELECT  distinct(a.tot_approved_amount) AS used_amount , b.Pat_Auth_Seq_Id, a.claim_seq_id
               FROM APP.pat_authorization_details a
               JOIN APP.diagnosys_details b ON (a.pat_auth_seq_id = b.pat_auth_seq_id AND A.pat_status_type_id != 'PCN' AND A.pat_status_type_id != 'REJ' )
               JOIN APP.tpa_icd_codes G ON (b.diagnosys_code = g.icd_code)
               JOIN APP.tpa_icd_codes gg ON (g.master_icd_code = gg.master_icd_code )
               WHERE  A.Member_Seq_Id = v_member_seq_id
               AND gg.icd_code in (v_master_activity_code)
               AND a.claim_seq_id IS NULL
                ) r
          FULL OUTER JOIN
           ( SELECT distinct(a.tot_approved_amount) AS used_amount , a.claim_seq_id
               FROM APP.clm_authorization_details A
               JOIN APP.diagnosys_details b ON (a.claim_seq_id = b.claim_seq_id AND A.CLM_STATUS_TYPE_ID != 'PCN' AND A.CLM_STATUS_TYPE_ID != 'REJ' )
               JOIN APP.tpa_icd_codes G ON (b.diagnosys_code = g.icd_code)
               JOIN APP.tpa_icd_codes gg ON (g.master_icd_code = gg.master_icd_code )
               WHERE A.Member_Seq_Id = v_member_seq_id
               AND gg.icd_code in (v_master_activity_code)
			      ) s
               ON ( r.claim_seq_id = s.claim_seq_id )
               WHERE (  NVL(r.Pat_Auth_Seq_Id,0) != NVL(v_seq_id,0)
                OR   NVL(s.claim_seq_id,0) != NVL(v_seq_id,0) ); 


rec_get_utilized_amt2   per_policy_icd_cur%rowtype;


CURSOR per_policy_icd_cur_chronic 
	IS			
				SELECT SUM(nvl(s.used_amount, r.used_amount)) as utilized_amount3 FROM
         ( SELECT  distinct(a.tot_approved_amount) AS used_amount , b.Pat_Auth_Seq_Id, a.claim_seq_id--,b.diagnosys_code
               FROM APP.pat_authorization_details a
               JOIN APP.diagnosys_details b ON (a.pat_auth_seq_id = b.pat_auth_seq_id AND A.pat_status_type_id != 'PCN' AND A.pat_status_type_id != 'REJ' )
              JOIN APP.Tpa_Day_Care_Icd G ON (b.diagnosys_code = g.icd_code)
              -- JOIN APP.Tpa_Day_Care_Icd gg ON (g.DAY_CARE_ICD_GROUP_ID = gg.DAY_CARE_ICD_GROUP_ID )
               WHERE  A.Member_Seq_Id = v_member_seq_id
               AND g.DAY_CARE_ICD_GROUP_ID in (v_master_activity_code)
               AND a.claim_seq_id IS NULL
                ) r
          FULL OUTER JOIN
           ( SELECT distinct(a.tot_approved_amount) AS used_amount , a.claim_seq_id,A.Pat_Auth_Seq_Id--,b.diagnosys_code
               FROM APP.clm_authorization_details A
               JOIN APP.diagnosys_details b ON (a.claim_seq_id = b.claim_seq_id AND A.CLM_STATUS_TYPE_ID != 'PCN' AND A.CLM_STATUS_TYPE_ID != 'REJ' )
               JOIN APP.Tpa_Day_Care_Icd G ON (b.diagnosys_code = g.icd_code)
              -- JOIN APP.Tpa_Day_Care_Icd gg ON (g.DAY_CARE_ICD_GROUP_ID = gg.DAY_CARE_ICD_GROUP_ID )
               WHERE A.Member_Seq_Id = v_member_seq_id
               AND g.DAY_CARE_ICD_GROUP_ID in (v_master_activity_code)
			      ) s
               ON ( r.claim_seq_id = s.claim_seq_id )
               WHERE (  NVL(r.Pat_Auth_Seq_Id,0) != NVL(v_seq_id,0)
                OR   NVL(s.claim_seq_id,0) != nvl(v_seq_id,0)); 
               
               
    rec_get_utilized_amt3   per_policy_icd_cur_chronic%rowtype;
 
 ------------normal  
    
    CURSOR per_policy_icd_cur_nor 
	IS			
				SELECT SUM(nvl(s.used_amount, r.used_amount)) as utilized_amount4 FROM
         ( SELECT  distinct(a.tot_approved_amount) AS used_amount , b.Pat_Auth_Seq_Id, a.claim_seq_id
               FROM APP.pat_authorization_details a
               JOIN APP.diagnosys_details b ON (a.pat_auth_seq_id = b.pat_auth_seq_id AND A.pat_status_type_id != 'PCN' AND A.pat_status_type_id != 'REJ' )
               JOIN APP.tpa_icd_codes G ON (b.diagnosys_code = g.icd_code)
               JOIN APP.tpa_icd_codes gg ON (g.master_icd_code = gg.master_icd_code )
               WHERE  A.Member_Seq_Id = v_member_seq_id
               AND A.DELVRY_MOD_TYPE  = 'NOR'
               AND B.diagnosys_code IN (SELECT ICD_CODE FROM  tpa_mat_ip_codes  WHERE icd_type='NRML')
               AND gg.icd_code in (v_master_activity_code)
               AND a.claim_seq_id IS NULL
                ) r
          FULL OUTER JOIN
           ( SELECT distinct(a.tot_approved_amount) AS used_amount , a.claim_seq_id
               FROM APP.clm_authorization_details A
               JOIN APP.diagnosys_details b ON (a.claim_seq_id = b.claim_seq_id AND A.CLM_STATUS_TYPE_ID != 'PCN' AND A.CLM_STATUS_TYPE_ID != 'REJ' )
               JOIN APP.tpa_icd_codes G ON (b.diagnosys_code = g.icd_code)
               JOIN APP.tpa_icd_codes gg ON (g.master_icd_code = gg.master_icd_code )
               WHERE A.Member_Seq_Id = v_member_seq_id
               AND A.DELVRY_MOD_TYPE  = 'NOR'
               AND B.diagnosys_code IN (SELECT ICD_CODE FROM  tpa_mat_ip_codes  WHERE icd_type='NRML')
               AND gg.icd_code in (v_master_activity_code)
			      ) s
               ON ( r.claim_seq_id = s.claim_seq_id )
               WHERE (  NVL(r.Pat_Auth_Seq_Id,0) != NVL(v_seq_id,0)
                OR   NVL(s.claim_seq_id,0) != NVL(v_seq_id,0) ); 
 
 rec_get_utilized_amt4  per_policy_icd_cur_nor%rowtype;  
 
 -------------********lscs*******
 
   
    CURSOR per_policy_icd_cur_lscs 
	IS			
				SELECT SUM(nvl(s.used_amount, r.used_amount)) as utilized_amount5 FROM
         ( SELECT  distinct(a.tot_approved_amount) AS used_amount , b.Pat_Auth_Seq_Id, a.claim_seq_id
               FROM APP.pat_authorization_details a
               JOIN APP.diagnosys_details b ON (a.pat_auth_seq_id = b.pat_auth_seq_id AND A.pat_status_type_id != 'PCN' AND A.pat_status_type_id != 'REJ' )
               JOIN APP.tpa_icd_codes G ON (b.diagnosys_code = g.icd_code)
               JOIN APP.tpa_icd_codes gg ON (g.master_icd_code = gg.master_icd_code )
               WHERE  A.Member_Seq_Id = v_member_seq_id
               AND A.DELVRY_MOD_TYPE  = 'LSS'
               AND   B.diagnosys_code IN (SELECT ICD_CODE FROM  tpa_mat_ip_codes  WHERE icd_type='LSCS')
                AND gg.icd_code in (v_master_activity_code)
               AND a.claim_seq_id IS NULL
                ) r
          FULL OUTER JOIN
           ( SELECT distinct(a.tot_approved_amount) AS used_amount , a.claim_seq_id
               FROM APP.clm_authorization_details A
               JOIN APP.diagnosys_details b ON (a.claim_seq_id = b.claim_seq_id AND A.CLM_STATUS_TYPE_ID != 'PCN' AND A.CLM_STATUS_TYPE_ID != 'REJ' )
               JOIN APP.tpa_icd_codes G ON (b.diagnosys_code = g.icd_code)
               JOIN APP.tpa_icd_codes gg ON (g.master_icd_code = gg.master_icd_code )
               WHERE A.Member_Seq_Id = v_member_seq_id
               AND A.DELVRY_MOD_TYPE  = 'LSS'
                AND B.diagnosys_code IN (SELECT ICD_CODE FROM  tpa_mat_ip_codes  WHERE icd_type='LSCS')
               AND gg.icd_code in (v_master_activity_code)
			      ) s
               ON ( r.claim_seq_id = s.claim_seq_id )
               WHERE (  NVL(r.Pat_Auth_Seq_Id,0) != NVL(v_seq_id,0)
                OR   NVL(s.claim_seq_id,0) != NVL(v_seq_id,0) ); 
 
 rec_get_utilized_amt5  per_policy_icd_cur_lscs%rowtype; 
 
 
 cursor per_policy_icd_cur_nor_act
 is 
         SELECT SUM(nvl(s.used_amount, r.used_amount))  as utilized_amount6 FROM
         ( SELECT  distinct(b.approved_amount) AS used_amount , b.Pat_Auth_Seq_Id, a.claim_seq_id 
               FROM APP.pat_authorization_details a
               JOIN APP.pat_activity_details b ON (a.pat_auth_seq_id = b.pat_auth_seq_id AND A.pat_status_type_id != 'PCN' AND A.pat_status_type_id != 'REJ' )
               LEFT JOIN APP.tpa_activity_details g ON (b.code = g.activity_code)
               LEFT JOIN APP.tpa_activity_details gg ON (g.master_activity_code = gg.master_activity_code )
			         LEFT JOIN  APP.dental_rule_tab  dd on (dd.cdt_code = b.code)
               LEFT JOIN APP.tpa_activity_master_details m ON (b.code = m.ACTIVITY_CODE)
             ---  LEFT JOIN APP.tpa_activity_master_details ma ON (m.master_activity_code = ma.Master_Activity_Code)
           WHERE A.Member_Seq_Id = v_member_seq_id 
              AND A.DELVRY_MOD_TYPE  = 'NOR'
              and b.code in (select activity_code  from tpa_mat_ip_codes where activity_type='NRML')
               AND a.claim_seq_id IS NULL 
               ) r
          FULL OUTER JOIN
           ( SELECT distinct(b.approved_amount) AS used_amount , a.claim_seq_id
               FROM APP.clm_authorization_details A 
               JOIN APP.pat_activity_details b ON (a.claim_seq_id = b.claim_seq_id AND A.CLM_STATUS_TYPE_ID != 'PCN' AND A.CLM_STATUS_TYPE_ID != 'REJ' )
               LEFT JOIN APP.tpa_activity_details g ON (b.code = g.activity_code)
               LEFT JOIN APP.tpa_activity_details gg ON (g.master_activity_code = gg.master_activity_code )
               LEFT JOIN  APP.dental_rule_tab  dd on (dd.cdt_code = b.code)
               LEFT JOIN APP.tpa_activity_master_details m ON (b.code = m.ACTIVITY_CODE)
               ---LEFT JOIN APP.tpa_activity_master_details ma ON (m.master_activity_code = ma.Master_Activity_Code)
                WHERE A.Member_Seq_Id = v_member_seq_id  
               and  A.DELVRY_MOD_TYPE  = 'NOR'
               and   b.code in (select activity_code  from tpa_mat_ip_codes where activity_type='NRML')
                 )s
               ON ( r.claim_seq_id = s.claim_seq_id )
               WHERE (  NVL(r.Pat_Auth_Seq_Id,0) !=NVL(v_seq_id,0)
                OR  NVL(s.claim_seq_id,0) != NVL(v_seq_id,0));
	
rec_get_utilized_amt6     per_policy_icd_cur_nor_act%rowtype;             
    
    cursor per_policy_icd_cur_lscs_act
 is 
         SELECT SUM(nvl(s.used_amount, r.used_amount))  as utilized_amount7 FROM
         ( SELECT  distinct(b.approved_amount) AS used_amount , b.Pat_Auth_Seq_Id, a.claim_seq_id 
               FROM APP.pat_authorization_details a
               JOIN APP.pat_activity_details b ON (a.pat_auth_seq_id = b.pat_auth_seq_id AND A.pat_status_type_id != 'PCN' AND A.pat_status_type_id != 'REJ' )
               LEFT JOIN APP.tpa_activity_details g ON (b.code = g.activity_code)
               LEFT JOIN APP.tpa_activity_details gg ON (g.master_activity_code = gg.master_activity_code )
			         LEFT JOIN  APP.dental_rule_tab  dd on (dd.cdt_code = b.code)
               LEFT JOIN APP.tpa_activity_master_details m ON (b.code = m.ACTIVITY_CODE)
             ---  LEFT JOIN APP.tpa_activity_master_details ma ON (m.master_activity_code = ma.Master_Activity_Code)
           WHERE A.Member_Seq_Id = v_member_seq_id 
              AND A.DELVRY_MOD_TYPE  = 'NOR'
              and b.code in (select activity_code  from tpa_mat_ip_codes where activity_type='NRML')
               AND a.claim_seq_id IS NULL 
               ) r
          FULL OUTER JOIN
           ( SELECT distinct(b.approved_amount) AS used_amount , a.claim_seq_id
               FROM APP.clm_authorization_details A 
               JOIN APP.pat_activity_details b ON (a.claim_seq_id = b.claim_seq_id AND A.CLM_STATUS_TYPE_ID != 'PCN' AND A.CLM_STATUS_TYPE_ID != 'REJ' )
               LEFT JOIN APP.tpa_activity_details g ON (b.code = g.activity_code)
               LEFT JOIN APP.tpa_activity_details gg ON (g.master_activity_code = gg.master_activity_code )
               LEFT JOIN  APP.dental_rule_tab  dd on (dd.cdt_code = b.code)
               LEFT JOIN APP.tpa_activity_master_details m ON (b.code = m.ACTIVITY_CODE)
               ---LEFT JOIN APP.tpa_activity_master_details ma ON (m.master_activity_code = ma.Master_Activity_Code)
                WHERE A.Member_Seq_Id = v_member_seq_id  
               and  A.DELVRY_MOD_TYPE  = 'NOR'
               and   b.code in (select activity_code  from tpa_mat_ip_codes where activity_type='NRML') 
                 )s
               ON ( r.claim_seq_id = s.claim_seq_id )
               WHERE (  NVL(r.Pat_Auth_Seq_Id,0) !=NVL(v_seq_id,0)
                OR  NVL(s.claim_seq_id,0) != NVL(v_seq_id,0));
	
rec_get_utilized_amt7     per_policy_icd_cur_lscs_act%rowtype;             
    
    
    
    CURSOR pat_count 
    IS
    SELECT COUNT(*)
    FROM app.pat_authorization_details
    where Pat_Auth_Seq_Id  =  nvl(v_seq_id,0) 
      and claim_seq_id IS NULL;
    
    rec_pat  number(5);
    
    CURSOR clm_count 
    IS
    SELECT COUNT(*)
    FROM app.clm_authorization_details
    where claim_seq_id  =  nvl(v_seq_id,0) 
    or Pat_Auth_Seq_Id  = nvl(v_seq_id,0);
    
    rec_clm number(5);
    
    
    
  v_icd_lsscs_count                  number:=0;
  v_act_lsscs_count                 number:=0;
  v_icd_nrml_count                  number:=0;
  v_act_nrml_count                  number:=0;
  v_lsscs_count                      number:=0;
  v_nrml_count                       number:=0;  
  v_icd_type                        VARCHAR2(10);
  v_act_type                        VARCHAR2(10);
  
  
 
--PRAGMA AUTONOMOUS_TRANSACTION;
     
BEGIN
 
  OPEN per_policy_act_cur;
  FETCH per_policy_act_cur INTO rec_get_utilized_amt1.utilized_amount1;
  CLOSE per_policy_act_cur;
  
  OPEN  per_policy_icd_cur;
  FETCH per_policy_icd_cur  INTO rec_get_utilized_amt2.utilized_amount2;
  CLOSE per_policy_icd_cur;
  
  OPEN per_policy_icd_cur_chronic;
  FETCH per_policy_icd_cur_chronic INTO rec_get_utilized_amt3.utilized_amount3 ;
  CLOSE per_policy_icd_cur_chronic;
  
  OPEN per_policy_icd_cur_nor;
  FETCH per_policy_icd_cur_nor INTO rec_get_utilized_amt4.utilized_amount4; 
  CLOSE per_policy_icd_cur_nor;
  
  OPEN per_policy_icd_cur_lscs;
  FETCH per_policy_icd_cur_lscs  INTO rec_get_utilized_amt5.utilized_amount5 ;
  CLOSE per_policy_icd_cur_lscs;
  
  OPEN per_policy_icd_cur_nor_act;
  FETCH per_policy_icd_cur_nor_act  INTO rec_get_utilized_amt6.utilized_amount6;
  CLOSE per_policy_icd_cur_nor_act;
  
  OPEN  per_policy_icd_cur_lscs_act;
  FETCH per_policy_icd_cur_lscs_act INTO rec_get_utilized_amt7.utilized_amount7;
  CLOSE per_policy_icd_cur_lscs_act;
  
  open  pat_count ;
  fetch pat_count into rec_pat;
  close pat_count;
  
  open  clm_count;
  fetch clm_count into rec_clm;
  close clm_count;
  
  
        --------********Maternity normal and lscs limit****************---------------------
       ----------------------------ICD, LSCS/Normal
     if v_master_activity_code = 'Z34.90' then 
     
      select count(*) into v_icd_lsscs_count
      from app.tpa_mat_ip_codes t 
      where t.icd_code in (select nvl(r.diagnosys_code, s.diagnosys_code)
                          from
                           (select dd.diagnosys_code,ad.pat_auth_seq_id, ad.claim_seq_id
                           from app.pat_authorization_details ad 
                           join diagnosys_details dd on (ad.pat_auth_seq_id=dd.pat_auth_seq_id)
                           where ad.member_seq_id= v_member_seq_id ---and ad.pat_auth_seq_id!=nvl(v_seq_id,0)
                             and  ad.claim_seq_id IS NULL
                            ) r
                            full join
                            (select dd.diagnosys_code,ad.pat_auth_seq_id, ad.claim_seq_id
                           from app.clm_authorization_details ad 
                           join diagnosys_details dd on (ad.pat_auth_seq_id=dd.pat_auth_seq_id)
                           where ad.member_seq_id= v_member_seq_id ---and ad.pat_auth_seq_id!=nvl(v_seq_id,0)
                             ) s
                          on (s.claim_seq_id = r.claim_seq_id)
                        ) 
       and t.icd_type='LSCS';
       
     \* select count(*) into v_icd_lsscs_count 
      from app.tpa_mat_ip_codes t 
      where t.icd_code in (select dd.diagnosys_code
                           from app.pat_authorization_details ad 
                           join diagnosys_details dd on (ad.pat_auth_seq_id=dd.pat_auth_seq_id)
                           where ad.member_seq_id= v_member_seq_id --and ad.pat_auth_seq_id!=nvl(v_seq_id,0)
                           and  ad.claim_seq_id IS NULL
                        ) 
       and t.icd_type='LSCS';*\
       
       
      select count(*)  into v_icd_nrml_count
      from app.tpa_mat_ip_codes t 
      where t.icd_code in (select nvl(r.diagnosys_code, s.diagnosys_code)
                          from
                           (select dd.diagnosys_code,ad.pat_auth_seq_id, ad.claim_seq_id
                           from app.pat_authorization_details ad 
                           join diagnosys_details dd on (ad.pat_auth_seq_id=dd.pat_auth_seq_id)
                           where ad.member_seq_id= v_member_seq_id ---and ad.pat_auth_seq_id!=nvl(v_seq_id,0)
                             and  ad.claim_seq_id IS NULL
                            ) r
                            full join
                            (select dd.diagnosys_code,ad.pat_auth_seq_id, ad.claim_seq_id
                           from app.clm_authorization_details ad 
                           join diagnosys_details dd on (ad.pat_auth_seq_id=dd.pat_auth_seq_id)
                           where ad.member_seq_id= v_member_seq_id ---and ad.pat_auth_seq_id!=nvl(v_seq_id,0)
                             ) s
                          on (s.claim_seq_id = r.claim_seq_id)
                        ) 
       and t.icd_type='NRML';
       
     \* select count(*) into v_icd_nrml_count
      from app.tpa_mat_ip_codes t 
      where t.icd_code in (select dd.diagnosys_code
                           from app.pat_authorization_details ad 
                           join diagnosys_details dd on (ad.pat_auth_seq_id=dd.pat_auth_seq_id)
                           where ad.member_seq_id= v_member_seq_id ---and ad.pat_auth_seq_id!=nvl(v_seq_id,0)
                             and  ad.claim_seq_id IS NULL
                        ) 
       and t.icd_type='NRML';*\
       
       v_icd_type := CASE WHEN v_icd_lsscs_count > 0 THEN 'LSCS'
                              WHEN v_icd_nrml_count > 0 THEN 'NRML' END;
       ------------------------ Activity, LSCS/Normal 
     select count(*) into  v_act_lsscs_count
    from app.tpa_mat_ip_codes t
    where t.activity_code in (select nvl(r.code, s.code)
                          from
                             (select a.code, ad.pat_auth_seq_id, ad.claim_seq_id
                              from app.pat_authorization_details ad
                              join pat_activity_details a on (a.pat_auth_seq_id=ad.pat_auth_seq_id)
                              where  ad.member_seq_id= v_member_seq_id-- and  ad.pat_auth_seq_id!=nvl(v_seq_id,0)
                              and ad.claim_seq_id IS NULL
                              ) r

                        full join
                            (select a.code, cl.pat_auth_seq_id, cl.claim_seq_id
                             from app.clm_authorization_details cl
                             join pat_activity_details a on (a.claim_seq_id=cl.claim_seq_id)
                             where  cl.member_seq_id= v_member_seq_id
                            ) s
                          on (s.claim_seq_id = r.claim_seq_id)
                        )
     and t.activity_type='LSCS'; 
       
      
       
    select count(1) into v_act_nrml_count
    from app.tpa_mat_ip_codes t
    where t.activity_code in (select nvl(r.code, s.code)
                          from
                             (select a.code, ad.pat_auth_seq_id, ad.claim_seq_id
                              from app.pat_authorization_details ad
                              join pat_activity_details a on (a.pat_auth_seq_id=ad.pat_auth_seq_id)
                              where  ad.member_seq_id= v_member_seq_id-- and  ad.pat_auth_seq_id!=nvl(v_seq_id,0)
                              and ad.claim_seq_id IS NULL
                              ) r

                        full join
                            (select a.code, cl.pat_auth_seq_id, cl.claim_seq_id
                             from app.clm_authorization_details cl
                             join pat_activity_details a on (a.claim_seq_id=cl.claim_seq_id)
                             where  cl.member_seq_id= v_member_seq_id
                            ) s
                          on (s.claim_seq_id = r.claim_seq_id)
                        )
and t.activity_type='NRML';

      \* select count(*) into v_act_lsscs_count 
       from app.tpa_mat_ip_codes t 
       where t.activity_code in (select a.code
                            from app.pat_authorization_details ad 
                            join pat_activity_details a on (a.pat_auth_seq_id=ad.pat_auth_seq_id)
                            where  ad.member_seq_id= v_member_seq_id-- and  ad.pat_auth_seq_id!=nvl(v_seq_id,0)
                              and ad.claim_seq_id IS NULL
                            ) 
        and t.activity_type='LSCS';*\
        
       \*select count(*) into v_act_nrml_count 
       from app.tpa_mat_ip_codes t 
       where t.activity_code in (select a.code
                            from app.pat_authorization_details ad 
                            join pat_activity_details a on (a.pat_auth_seq_id=ad.pat_auth_seq_id)
                            where ad.member_seq_id= v_member_seq_id --and ad.pat_auth_seq_id!=nvl(v_seq_id,0)
                            and ad.claim_seq_id IS NULL
                            ) 
        and t.activity_type='NRML';*\
        
       v_act_type := CASE WHEN v_act_lsscs_count > 0 THEN 'LSCS'
                          WHEN v_act_nrml_count > 0 THEN 'NRML' END; 
                          
            IF v_icd_type IS NOT NULL THEN
         IF v_icd_type = 'LSCS' THEN
           v_lsscs_count := v_icd_lsscs_count;
         ELSE
           v_nrml_count  := v_icd_nrml_count;
         END IF;
       ELSIF v_icd_type IS NULL AND v_act_type IS NOT NULL THEN
         IF v_act_type = 'LSCS' THEN
           v_lsscs_count := v_act_lsscs_count;
         ELSE
           v_nrml_count  := v_act_nrml_count;
         END IF;
       END IF;
       
   end if;
                          

                          
  
  --------------------------******************************************************
--  
  if v_master_activity_code = 'Z34.90' then 
     if v_sub_benf_name = 'Maternity Coverage(Normal Limit)'  then 
         if NVL(v_nrml_count,0) > 0 AND NVL(v_lsscs_count,0) = 0 then
          v_utilized_amount :=  nvl(rec_get_utilized_amt1.utilized_amount1,0) + nvl(rec_get_utilized_amt4.utilized_amount4,0) \*+ nvl(rec_get_utilized_amt6.utilized_amount6,0)*\+nvl(rec_get_utilized_amt3.utilized_amount3,0);
         else   
            --v_utilized_amount := 0;
             v_utilized_amount :=  nvl(rec_get_utilized_amt1.utilized_amount1,0) + nvl(rec_get_utilized_amt4.utilized_amount4,0) \*+ nvl(rec_get_utilized_amt6.utilized_amount6,0)*\+nvl(rec_get_utilized_amt3.utilized_amount3,0);
         end if;
       elsif v_sub_benf_name  ='Maternity Coverage(LSCS Limit)'  then 
           if NVL(v_nrml_count,0) = 0 AND NVL(v_lsscs_count,0) > 0 then
         v_utilized_amount := nvl(rec_get_utilized_amt1.utilized_amount1,0) + nvl(rec_get_utilized_amt5.utilized_amount5,0)+nvl(rec_get_utilized_amt3.utilized_amount3,0) \*+ nvl(rec_get_utilized_amt7.utilized_amount7,0)*\;
         ---- v_utilized_amount := 10;
          else   
         ---- v_utilized_amount := 20;
         v_utilized_amount := nvl(rec_get_utilized_amt1.utilized_amount1,0) + nvl(rec_get_utilized_amt5.utilized_amount5,0)+nvl(rec_get_utilized_amt3.utilized_amount3,0) \*+ nvl(rec_get_utilized_amt7.utilized_amount7,0)*\;
           end if;
       else
           v_utilized_amount := nvl(rec_get_utilized_amt1.utilized_amount1,0) + nvl(rec_get_utilized_amt2.utilized_amount2,0)+nvl(rec_get_utilized_amt3.utilized_amount3,0);
         end if;
    else     
  v_utilized_amount := nvl(rec_get_utilized_amt1.utilized_amount1,0) +nvl(rec_get_utilized_amt2.utilized_amount2,0)+nvl(rec_get_utilized_amt3.utilized_amount3,0);
    end if;
RETURN v_utilized_amount;
  
END get_utilized_amt_act_icd;

-----------------------**********************************************
------*********To get the amount of  the paticular member for *******---------------------

FUNCTION get_utilize_amt_benfit_type
                          (
                          v_policy_seq_id            IN  app.tpa_enr_policy.policy_seq_id%TYPE,
                          v_member_seq_id            IN  app.tpa_enr_policy_member.member_seq_id%TYPE,
                          v_benefit_type             IN  varchar2,
                          v_request_type             IN  varchar2,
                          v_seq_id                   IN app.clm_authorization_details.claim_seq_id%type
                          )
RETURN number

IS

 v_utilized_amount number;

CURSOR per_policy_benf_cur(benefit_type VARCHAR2)  IS
       SELECT SUM(nvl(s.used_amount, r.used_amount)) AS utilized_amount1
       FROM
         (SELECT DISTINCT(p.tot_approved_amount) as used_amount, po.policy_seq_id, p.member_seq_id, p.claim_seq_id, p.pat_auth_seq_id 
          From pat_authorization_details p
          JOIN tpa_enr_policy po on (p.policy_seq_id = po.policy_seq_id)
          WHERE p.policy_seq_id = v_policy_seq_id and p.member_seq_id = v_member_seq_id
		  AND  p.benifit_type = benefit_type
          AND p.pat_status_type_id NOT IN ('PCN', 'REJ')
          AND   p.claim_seq_id IS NULL
         ) r
       FULL OUTER JOIN
         (SELECT distinct(c.tot_approved_amount) as used_amount, po.policy_seq_id, c.member_seq_id, c.claim_seq_id
          from APP.clm_authorization_details c
          JOIN APP.tpa_enr_policy po on (c.policy_seq_id = po.policy_seq_id)
          WHERE c.policy_seq_id = v_policy_seq_id and c.member_seq_id = v_member_seq_id
          AND c.benifit_type = benefit_type
          AND c.clm_status_type_id NOT IN ('PCN', 'REJ')
         ) s
      -- ON (r.member_seq_id = s.member_seq_id)
      ON (r.claim_seq_id = s.claim_seq_id)
       WHERE  ( NVL(r.Pat_Auth_Seq_Id,0) != NVL(v_seq_id,0)
              OR NVL(s.claim_seq_id,0) != NVL(v_seq_id,0) );



   rec_get_utilized_amt1   per_policy_benf_cur%rowtype;

   benefit_type        varchar2(30);

---PRAGMA AUTONOMOUS_TRANSACTION;
     
BEGIN

 SELECT  CASE    WHEN v_benefit_type = 'Cash Benefit'                                THEN 'CB'
                 WHEN v_benefit_type = 'International Emergency medical assistance'  THEN 'IEMA' 
                 WHEN v_benefit_type = 'Palliative and hospice care benefit'         THEN 'PAHC'
                 WHEN v_benefit_type = 'In-Patient Rehabilitation'                   THEN 'IPRE'
                 WHEN v_benefit_type = 'Health Check Up'                             THEN 'HEAC'
                 END AS v_benefit_type INTO benefit_type FROM dual;
  
   OPEN  per_policy_benf_cur(benefit_type);
   FETCH per_policy_benf_cur INTO rec_get_utilized_amt1.utilized_amount1;
   CLOSE per_policy_benf_cur;
  
   v_utilized_amount:= nvl(rec_get_utilized_amt1.utilized_amount1,0) ;

   RETURN v_utilized_amount;
  
END get_utilize_amt_benfit_type;


-----**********************************new******************************----------------

FUNCTION get_utilized_amt_act_icd_clm
                    (v_policy_seq_id            IN  app.tpa_enr_policy.policy_seq_id%TYPE,
                     v_member_seq_id            IN  app.tpa_enr_policy_member.member_seq_id%TYPE,
                     v_master_activity_code     IN  app.tpa_activity_master_details.master_activity_code%TYPE,
                     v_sub_benf_name            IN VARCHAR2,
                     v_request_type             IN  varchar2,
                     v_seq_id                   IN app.clm_authorization_details.claim_seq_id%type
                     )
RETURN number


IS

 v_utilized_amount number;
 
 CURSOR per_policy_act_cur IS
       SELECT SUM(nvl(s.used_amount, r.used_amount))  as utilized_amount1 FROM
         ( SELECT  distinct(b.approved_amount) AS used_amount , b.Pat_Auth_Seq_Id, a.claim_seq_id,b.code 
               FROM APP.pat_authorization_details a
               JOIN APP.pat_activity_details b ON (a.pat_auth_seq_id = b.pat_auth_seq_id AND A.pat_status_type_id != 'PCN' AND A.pat_status_type_id != 'REJ' )
               LEFT JOIN APP.tpa_activity_details g ON (b.code = g.activity_code)
               LEFT JOIN APP.tpa_activity_details gg ON (g.master_activity_code = gg.master_activity_code )
			   LEFT JOIN  APP.dental_rule_tab  dd on (dd.cdt_code = b.code)
               LEFT JOIN APP.tpa_activity_master_details m ON (b.code = m.ACTIVITY_CODE)
             ---- LEFT JOIN APP.tpa_activity_master_details ma ON (m.master_activity_code = ma.Master_Activity_Code)
           WHERE A.Member_Seq_Id = v_member_seq_id 
               AND (gg.activity_code in (v_master_activity_code)
               or dd.specific_service_code in (v_master_activity_code)
			    or dd.CDT_CODE  in (v_master_activity_code)
            or dd.master_code in (v_master_activity_code) 
			   or m.master_activity_code in (v_master_activity_code))
               AND a.claim_seq_id IS NULL 
               ) r
          FULL OUTER JOIN
           ( SELECT distinct(b.approved_amount) AS used_amount , a.claim_seq_id,A.Pat_Auth_Seq_Id,b.code
               FROM APP.clm_authorization_details A 
               JOIN APP.pat_activity_details b ON (a.claim_seq_id = b.claim_seq_id AND A.CLM_STATUS_TYPE_ID != 'PCN' AND A.CLM_STATUS_TYPE_ID != 'REJ' )
               LEFT JOIN APP.tpa_activity_details g ON (b.code = g.activity_code)
               LEFT JOIN APP.tpa_activity_details gg ON (g.master_activity_code = gg.master_activity_code )
               LEFT JOIN  APP.dental_rule_tab  dd on (dd.cdt_code = b.code)
               LEFT JOIN APP.tpa_activity_master_details m ON (b.code = m.ACTIVITY_CODE)
              ----- LEFT JOIN APP.tpa_activity_master_details ma ON (m.master_activity_code = ma.Master_Activity_Code)
                WHERE A.Member_Seq_Id = v_member_seq_id  
               AND (gg.activity_code in (v_master_activity_code) 
               or dd.specific_service_code in (v_master_activity_code)
			   or dd.CDT_CODE  in (v_master_activity_code)
           or dd.master_code in (v_master_activity_code) 
			   or m.master_activity_code in (v_master_activity_code)
               )
)s
               ON ( r.claim_seq_id = s.claim_seq_id )
               WHERE (  NVL(r.Pat_Auth_Seq_Id,0)= NVL(v_seq_id,0)
                OR  NVL(s.claim_seq_id,0) = nvl(v_seq_id ,0)
                 OR NVL(S.Pat_Auth_Seq_Id,0)= NVL(v_seq_id,0));
	


rec_get_utilized_amt1   per_policy_act_cur%rowtype;	



	CURSOR per_policy_icd_cur 
	IS			
				SELECT SUM(nvl(s.used_amount, r.used_amount)) as utilized_amount2 FROM
         ( SELECT  distinct(a.tot_approved_amount) AS used_amount , b.Pat_Auth_Seq_Id, a.claim_seq_id,b.diagnosys_code
               FROM APP.pat_authorization_details a
               JOIN APP.diagnosys_details b ON (a.pat_auth_seq_id = b.pat_auth_seq_id AND A.pat_status_type_id != 'PCN' AND A.pat_status_type_id != 'REJ' )
               JOIN APP.tpa_icd_codes G ON (b.diagnosys_code = g.icd_code)
               JOIN APP.tpa_icd_codes gg ON (g.master_icd_code = gg.master_icd_code )
               WHERE  A.Member_Seq_Id = v_member_seq_id
               AND gg.icd_code in (v_master_activity_code)
               AND a.claim_seq_id IS NULL
                ) r
          FULL OUTER JOIN
           ( SELECT distinct(a.tot_approved_amount) AS used_amount , a.claim_seq_id,A.Pat_Auth_Seq_Id,b.diagnosys_code
               FROM APP.clm_authorization_details A
               JOIN APP.diagnosys_details b ON (a.claim_seq_id = b.claim_seq_id AND A.CLM_STATUS_TYPE_ID != 'PCN' AND A.CLM_STATUS_TYPE_ID != 'REJ' )
               JOIN APP.tpa_icd_codes G ON (b.diagnosys_code = g.icd_code)
               JOIN APP.tpa_icd_codes gg ON (g.master_icd_code = gg.master_icd_code )
               WHERE A.Member_Seq_Id = v_member_seq_id
               AND gg.icd_code in (v_master_activity_code)
			      ) s
               ON ( r.claim_seq_id = s.claim_seq_id )
               WHERE (  NVL(r.Pat_Auth_Seq_Id,0) = NVL(v_seq_id,0)
                OR   NVL(s.claim_seq_id,0) = nvl(v_seq_id,0)
               OR NVL(S.Pat_Auth_Seq_Id,0)= NVL(v_seq_id,0)); 


rec_get_utilized_amt2   per_policy_icd_cur%rowtype;


CURSOR per_policy_icd_cur_chronic 
	IS			
				SELECT SUM(nvl(s.used_amount, r.used_amount)) as utilized_amount3 FROM
         ( SELECT  distinct(a.tot_approved_amount) AS used_amount , b.Pat_Auth_Seq_Id, a.claim_seq_id--,b.diagnosys_code
               FROM APP.pat_authorization_details a
               JOIN APP.diagnosys_details b ON (a.pat_auth_seq_id = b.pat_auth_seq_id AND A.pat_status_type_id != 'PCN' AND A.pat_status_type_id != 'REJ' )
              JOIN APP.Tpa_Day_Care_Icd G ON (b.diagnosys_code = g.icd_code)
              -- JOIN APP.Tpa_Day_Care_Icd gg ON (g.DAY_CARE_ICD_GROUP_ID = gg.DAY_CARE_ICD_GROUP_ID )
               WHERE  A.Member_Seq_Id = v_member_seq_id
               AND g.DAY_CARE_ICD_GROUP_ID in (v_master_activity_code)
               AND a.claim_seq_id IS NULL
                ) r
          FULL OUTER JOIN
           ( SELECT distinct(a.tot_approved_amount) AS used_amount , a.claim_seq_id,A.Pat_Auth_Seq_Id--,b.diagnosys_code
               FROM APP.clm_authorization_details A
               JOIN APP.diagnosys_details b ON (a.claim_seq_id = b.claim_seq_id AND A.CLM_STATUS_TYPE_ID != 'PCN' AND A.CLM_STATUS_TYPE_ID != 'REJ' )
               JOIN APP.Tpa_Day_Care_Icd G ON (b.diagnosys_code = g.icd_code)
              -- JOIN APP.Tpa_Day_Care_Icd gg ON (g.DAY_CARE_ICD_GROUP_ID = gg.DAY_CARE_ICD_GROUP_ID )
               WHERE A.Member_Seq_Id = v_member_seq_id
               AND g.DAY_CARE_ICD_GROUP_ID in (v_master_activity_code)
			      ) s
               ON ( r.claim_seq_id = s.claim_seq_id )
               WHERE (  NVL(r.Pat_Auth_Seq_Id,0) = NVL(v_seq_id,0)
                OR   NVL(s.claim_seq_id,0) = nvl(v_seq_id,0)
               OR NVL(S.Pat_Auth_Seq_Id,0)= NVL(v_seq_id,0)); 


rec_get_utilized_amt3   per_policy_icd_cur_chronic%rowtype;


  CURSOR per_policy_icd_cur_nor 
	IS			
				SELECT SUM(nvl(s.used_amount, r.used_amount)) as utilized_amount4 FROM
         ( SELECT  distinct(a.tot_approved_amount) AS used_amount , b.Pat_Auth_Seq_Id, a.claim_seq_id
               FROM APP.pat_authorization_details a
               JOIN APP.diagnosys_details b ON (a.pat_auth_seq_id = b.pat_auth_seq_id AND A.pat_status_type_id != 'PCN' AND A.pat_status_type_id != 'REJ' )
               JOIN APP.tpa_icd_codes G ON (b.diagnosys_code = g.icd_code)
               JOIN APP.tpa_icd_codes gg ON (g.master_icd_code = gg.master_icd_code )
               WHERE  A.Member_Seq_Id = v_member_seq_id
               AND A.DELVRY_MOD_TYPE  = 'NOR'
               AND B.diagnosys_code IN (SELECT ICD_CODE FROM  tpa_mat_ip_codes  WHERE icd_type='NRML')
               AND gg.icd_code in (v_master_activity_code)
               AND a.claim_seq_id IS NULL
                ) r
          FULL OUTER JOIN
           ( SELECT distinct(a.tot_approved_amount) AS used_amount , a.claim_seq_id
               FROM APP.clm_authorization_details A
               JOIN APP.diagnosys_details b ON (a.claim_seq_id = b.claim_seq_id AND A.CLM_STATUS_TYPE_ID != 'PCN' AND A.CLM_STATUS_TYPE_ID != 'REJ' )
               JOIN APP.tpa_icd_codes G ON (b.diagnosys_code = g.icd_code)
               JOIN APP.tpa_icd_codes gg ON (g.master_icd_code = gg.master_icd_code )
               WHERE A.Member_Seq_Id = v_member_seq_id
               AND A.DELVRY_MOD_TYPE  = 'NOR'
               AND B.diagnosys_code IN (SELECT ICD_CODE FROM  tpa_mat_ip_codes  WHERE icd_type='NRML')
               AND gg.icd_code in (v_master_activity_code)
			      ) s
               ON ( r.claim_seq_id = s.claim_seq_id )
               WHERE (  NVL(r.Pat_Auth_Seq_Id,0) = NVL(v_seq_id,0)
                OR   NVL(s.claim_seq_id,0) = NVL(v_seq_id,0) ); 
 
 rec_get_utilized_amt4  per_policy_icd_cur_nor%rowtype;  
 
 -------------********lscs*******
 
   
    CURSOR per_policy_icd_cur_lscs 
	IS			
				SELECT SUM(nvl(s.used_amount, r.used_amount)) as utilized_amount5 FROM
         ( SELECT  distinct(a.tot_approved_amount) AS used_amount , b.Pat_Auth_Seq_Id, a.claim_seq_id
               FROM APP.pat_authorization_details a
               JOIN APP.diagnosys_details b ON (a.pat_auth_seq_id = b.pat_auth_seq_id AND A.pat_status_type_id != 'PCN' AND A.pat_status_type_id != 'REJ' )
               JOIN APP.tpa_icd_codes G ON (b.diagnosys_code = g.icd_code)
               JOIN APP.tpa_icd_codes gg ON (g.master_icd_code = gg.master_icd_code )
               WHERE  A.Member_Seq_Id = v_member_seq_id
               AND A.DELVRY_MOD_TYPE  = 'LSS'
               AND   B.diagnosys_code IN (SELECT ICD_CODE FROM  tpa_mat_ip_codes  WHERE icd_type='LSCS')
                AND gg.icd_code in (v_master_activity_code)
               AND a.claim_seq_id IS NULL
                ) r
          FULL OUTER JOIN
           ( SELECT distinct(a.tot_approved_amount) AS used_amount , a.claim_seq_id
               FROM APP.clm_authorization_details A
               JOIN APP.diagnosys_details b ON (a.claim_seq_id = b.claim_seq_id AND A.CLM_STATUS_TYPE_ID != 'PCN' AND A.CLM_STATUS_TYPE_ID != 'REJ' )
               JOIN APP.tpa_icd_codes G ON (b.diagnosys_code = g.icd_code)
               JOIN APP.tpa_icd_codes gg ON (g.master_icd_code = gg.master_icd_code )
               WHERE A.Member_Seq_Id = v_member_seq_id
               AND A.DELVRY_MOD_TYPE  = 'LSS'
                AND B.diagnosys_code IN (SELECT ICD_CODE FROM  tpa_mat_ip_codes  WHERE icd_type='LSCS')
               AND gg.icd_code in (v_master_activity_code)
			      ) s
               ON ( r.claim_seq_id = s.claim_seq_id )
               WHERE (  NVL(r.Pat_Auth_Seq_Id,0) = NVL(v_seq_id,0)
                OR   NVL(s.claim_seq_id,0) = NVL(v_seq_id,0) ); 
 
 rec_get_utilized_amt5  per_policy_icd_cur_lscs%rowtype; 


 v_icd_lsscs_count                  number:=0;
  v_act_lsscs_count                 number:=0;
  v_icd_nrml_count                  number:=0;
  v_act_nrml_count                  number:=0;
  v_lsscs_count                      number:=0;
  v_nrml_count                       number:=0;  
  v_icd_type                        VARCHAR2(10);
  v_act_type                        VARCHAR2(10);
  
---PRAGMA AUTONOMOUS_TRANSACTION;
     
BEGIN
  
  OPEN per_policy_act_cur;
  FETCH per_policy_act_cur INTO rec_get_utilized_amt1.utilized_amount1;
  CLOSE per_policy_act_cur;
  
  OPEN per_policy_icd_cur;
  FETCH per_policy_icd_cur INTO rec_get_utilized_amt2.utilized_amount2;
  CLOSE per_policy_icd_cur;
  
  open per_policy_icd_cur_chronic;
  fetch per_policy_icd_cur_chronic into rec_get_utilized_amt3.utilized_amount3 ;
  close per_policy_icd_cur_chronic;
  
  OPEN per_policy_icd_cur_nor;
  FETCH per_policy_icd_cur_nor INTO rec_get_utilized_amt4.utilized_amount4; 
  CLOSE per_policy_icd_cur_nor;
  
  OPEN per_policy_icd_cur_lscs;
  FETCH per_policy_icd_cur_lscs  INTO rec_get_utilized_amt5.utilized_amount5 ;
  CLOSE per_policy_icd_cur_lscs;
  
  
   if v_master_activity_code = 'Z34.90' then 
     
      select count(*) into v_icd_lsscs_count
      from app.tpa_mat_ip_codes t 
      where t.icd_code in (select nvl(r.diagnosys_code, s.diagnosys_code)
                          from
                           (select dd.diagnosys_code,ad.pat_auth_seq_id, ad.claim_seq_id
                           from app.pat_authorization_details ad 
                           join diagnosys_details dd on (ad.pat_auth_seq_id=dd.pat_auth_seq_id)
                           where ad.member_seq_id= v_member_seq_id ---and ad.pat_auth_seq_id!=nvl(v_seq_id,0)
                             and  ad.claim_seq_id IS NULL
                            ) r
                            full join
                            (select dd.diagnosys_code,ad.pat_auth_seq_id, ad.claim_seq_id
                           from app.clm_authorization_details ad 
                           join diagnosys_details dd on (ad.pat_auth_seq_id=dd.pat_auth_seq_id)
                           where ad.member_seq_id= v_member_seq_id ---and ad.pat_auth_seq_id!=nvl(v_seq_id,0)
                             ) s
                          on (s.claim_seq_id = r.claim_seq_id)
                        ) 
       and t.icd_type='LSCS';
       
     \* select count(*) into v_icd_lsscs_count 
      from app.tpa_mat_ip_codes t 
      where t.icd_code in (select dd.diagnosys_code
                           from app.pat_authorization_details ad 
                           join diagnosys_details dd on (ad.pat_auth_seq_id=dd.pat_auth_seq_id)
                           where ad.member_seq_id= v_member_seq_id --and ad.pat_auth_seq_id!=nvl(v_seq_id,0)
                           and  ad.claim_seq_id IS NULL
                        ) 
       and t.icd_type='LSCS';*\
       
       
      select count(*)  into v_icd_nrml_count
      from app.tpa_mat_ip_codes t 
      where t.icd_code in (select nvl(r.diagnosys_code, s.diagnosys_code)
                          from
                           (select dd.diagnosys_code,ad.pat_auth_seq_id, ad.claim_seq_id
                           from app.pat_authorization_details ad 
                           join diagnosys_details dd on (ad.pat_auth_seq_id=dd.pat_auth_seq_id)
                           where ad.member_seq_id= v_member_seq_id ---and ad.pat_auth_seq_id!=nvl(v_seq_id,0)
                             and  ad.claim_seq_id IS NULL
                            ) r
                            full join
                            (select dd.diagnosys_code,ad.pat_auth_seq_id, ad.claim_seq_id
                           from app.clm_authorization_details ad 
                           join diagnosys_details dd on (ad.pat_auth_seq_id=dd.pat_auth_seq_id)
                           where ad.member_seq_id= v_member_seq_id ---and ad.pat_auth_seq_id!=nvl(v_seq_id,0)
                             ) s
                          on (s.claim_seq_id = r.claim_seq_id)
                        ) 
       and t.icd_type='NRML';
       
     \* select count(*) into v_icd_nrml_count
      from app.tpa_mat_ip_codes t 
      where t.icd_code in (select dd.diagnosys_code
                           from app.pat_authorization_details ad 
                           join diagnosys_details dd on (ad.pat_auth_seq_id=dd.pat_auth_seq_id)
                           where ad.member_seq_id= v_member_seq_id ---and ad.pat_auth_seq_id!=nvl(v_seq_id,0)
                             and  ad.claim_seq_id IS NULL
                        ) 
       and t.icd_type='NRML';*\
       
       v_icd_type := CASE WHEN v_icd_lsscs_count > 0 THEN 'LSCS'
                              WHEN v_icd_nrml_count > 0 THEN 'NRML' END;
       ------------------------ Activity, LSCS/Normal 
     select count(*) into  v_act_lsscs_count
    from app.tpa_mat_ip_codes t
    where t.activity_code in (select nvl(r.code, s.code)
                          from
                             (select a.code, ad.pat_auth_seq_id, ad.claim_seq_id
                              from app.pat_authorization_details ad
                              join pat_activity_details a on (a.pat_auth_seq_id=ad.pat_auth_seq_id)
                              where  ad.member_seq_id= v_member_seq_id-- and  ad.pat_auth_seq_id!=nvl(v_seq_id,0)
                              and ad.claim_seq_id IS NULL
                              ) r

                        full join
                            (select a.code, cl.pat_auth_seq_id, cl.claim_seq_id
                             from app.clm_authorization_details cl
                             join pat_activity_details a on (a.claim_seq_id=cl.claim_seq_id)
                             where  cl.member_seq_id= v_member_seq_id
                            ) s
                          on (s.claim_seq_id = r.claim_seq_id)
                        )
     and t.activity_type='LSCS'; 
       
      
       
    select count(1) into v_act_nrml_count
    from app.tpa_mat_ip_codes t
    where t.activity_code in (select nvl(r.code, s.code)
                          from
                             (select a.code, ad.pat_auth_seq_id, ad.claim_seq_id
                              from app.pat_authorization_details ad
                              join pat_activity_details a on (a.pat_auth_seq_id=ad.pat_auth_seq_id)
                              where  ad.member_seq_id= v_member_seq_id-- and  ad.pat_auth_seq_id!=nvl(v_seq_id,0)
                              and ad.claim_seq_id IS NULL
                              ) r

                        full join
                            (select a.code, cl.pat_auth_seq_id, cl.claim_seq_id
                             from app.clm_authorization_details cl
                             join pat_activity_details a on (a.claim_seq_id=cl.claim_seq_id)
                             where  cl.member_seq_id= v_member_seq_id
                            ) s
                          on (s.claim_seq_id = r.claim_seq_id)
                        )
and t.activity_type='NRML';

      \* select count(*) into v_act_lsscs_count 
       from app.tpa_mat_ip_codes t 
       where t.activity_code in (select a.code
                            from app.pat_authorization_details ad 
                            join pat_activity_details a on (a.pat_auth_seq_id=ad.pat_auth_seq_id)
                            where  ad.member_seq_id= v_member_seq_id-- and  ad.pat_auth_seq_id!=nvl(v_seq_id,0)
                              and ad.claim_seq_id IS NULL
                            ) 
        and t.activity_type='LSCS';*\
        
       \*select count(*) into v_act_nrml_count 
       from app.tpa_mat_ip_codes t 
       where t.activity_code in (select a.code
                            from app.pat_authorization_details ad 
                            join pat_activity_details a on (a.pat_auth_seq_id=ad.pat_auth_seq_id)
                            where ad.member_seq_id= v_member_seq_id --and ad.pat_auth_seq_id!=nvl(v_seq_id,0)
                            and ad.claim_seq_id IS NULL
                            ) 
        and t.activity_type='NRML';*\
        
       v_act_type := CASE WHEN v_act_lsscs_count > 0 THEN 'LSCS'
                          WHEN v_act_nrml_count > 0 THEN 'NRML' END; 
                          
            IF v_icd_type IS NOT NULL THEN
         IF v_icd_type = 'LSCS' THEN
           v_lsscs_count := v_icd_lsscs_count;
         ELSE
           v_nrml_count  := v_icd_nrml_count;
         END IF;
       ELSIF v_icd_type IS NULL AND v_act_type IS NOT NULL THEN
         IF v_act_type = 'LSCS' THEN
           v_lsscs_count := v_act_lsscs_count;
         ELSE
           v_nrml_count  := v_act_nrml_count;
         END IF;
       END IF;
       
   end if;
                          

IF  NVL(v_seq_id ,0) !=  0 THEN 
 if v_master_activity_code = 'Z34.90' then 
     if v_sub_benf_name = 'Maternity Coverage(Normal Limit)'  then 
         if NVL(v_nrml_count,0) > 0 AND NVL(v_lsscs_count,0) = 0 then
          v_utilized_amount :=  nvl(rec_get_utilized_amt1.utilized_amount1,0) + nvl(rec_get_utilized_amt4.utilized_amount4,0) \*+ nvl(rec_get_utilized_amt6.utilized_amount6,0)*\+nvl(rec_get_utilized_amt3.utilized_amount3,0);
         else   
            --v_utilized_amount := 0;
             v_utilized_amount :=  nvl(rec_get_utilized_amt1.utilized_amount1,0) + nvl(rec_get_utilized_amt4.utilized_amount4,0) \*+ nvl(rec_get_utilized_amt6.utilized_amount6,0)*\+nvl(rec_get_utilized_amt3.utilized_amount3,0);
         end if;
       elsif v_sub_benf_name  ='Maternity Coverage(LSCS Limit)'  then 
           if NVL(v_nrml_count,0) = 0 AND NVL(v_lsscs_count,0) > 0 then
         v_utilized_amount := nvl(rec_get_utilized_amt1.utilized_amount1,0) + nvl(rec_get_utilized_amt5.utilized_amount5,0)+nvl(rec_get_utilized_amt3.utilized_amount3,0) \*+ nvl(rec_get_utilized_amt7.utilized_amount7,0)*\;
         ---- v_utilized_amount := 10;
          else   
         ---- v_utilized_amount := 20;
         v_utilized_amount := nvl(rec_get_utilized_amt1.utilized_amount1,0) + nvl(rec_get_utilized_amt5.utilized_amount5,0)+nvl(rec_get_utilized_amt3.utilized_amount3,0) \*+ nvl(rec_get_utilized_amt7.utilized_amount7,0)*\;
           end if;
       else
           v_utilized_amount := nvl(rec_get_utilized_amt1.utilized_amount1,0) + nvl(rec_get_utilized_amt2.utilized_amount2,0)+nvl(rec_get_utilized_amt3.utilized_amount3,0);
         end if;
    else     
  v_utilized_amount := nvl(rec_get_utilized_amt1.utilized_amount1,0) +nvl(rec_get_utilized_amt2.utilized_amount2,0)+nvl(rec_get_utilized_amt3.utilized_amount3,0);
    end if;  
    ELSE
 v_utilized_amount := 0;
 END IF;
  
 \* 
 IF  NVL(v_seq_id ,0) !=  0 THEN 
 v_utilized_amount :=  nvl(rec_get_utilized_amt1.utilized_amount1,0) + nvl(rec_get_utilized_amt2.utilized_amount2,0)+nvl(rec_get_utilized_amt3.utilized_amount3,0);
  ELSE
 v_utilized_amount := 0;
 END IF;*\

RETURN v_utilized_amount;
  
END get_utilized_amt_act_icd_clm;


----------------=================================================================

FUNCTION get_utilized_amt_act_icd_benf
                    (v_policy_seq_id            IN  app.tpa_enr_policy.policy_seq_id%TYPE,
                     v_member_seq_id            IN  app.tpa_enr_policy_member.member_seq_id%TYPE,
                    -- v_master_activity_code     IN  app.tpa_activity_master_details.master_activity_code%TYPE,
                     v_benefit_type             IN  varchar2,
                     v_request_type             IN  varchar2,
                     v_seq_id                   IN app.clm_authorization_details.claim_seq_id%type
                     )
RETURN number

IS

 v_utilized_amount number;
 
benefit_type        varchar2(30);

--******ACTIVITY 

CURSOR per_policy_act_cur(benefit_type VARCHAR2)  IS
       SELECT SUM(nvl(s.used_amount, r.used_amount))  as utilized_amount1 FROM
         ( SELECT  distinct(b.approved_amount) AS used_amount , b.Pat_Auth_Seq_Id, a.claim_seq_id ,b.code
               FROM APP.pat_authorization_details a
               JOIN APP.pat_activity_details b ON (a.pat_auth_seq_id = b.pat_auth_seq_id AND A.pat_status_type_id != 'PCN' AND A.pat_status_type_id != 'REJ' )
--               LEFT JOIN APP.tpa_activity_details g ON (b.code = g.activity_code)
--               LEFT JOIN APP.tpa_activity_details gg ON (g.master_activity_code = gg.master_activity_code )
--			         LEFT JOIN  APP.dental_rule_tab  dd on (dd.cdt_code = b.code)
--               LEFT JOIN APP.tpa_activity_master_details m ON (b.code = m.ACTIVITY_CODE)
--               LEFT JOIN APP.tpa_activity_master_details ma ON (m.master_activity_code = ma.Master_Activity_Code)
           WHERE A.Member_Seq_Id = v_member_seq_id 
                 and a.Benifit_Type = benefit_type
--               AND (gg.activity_code in (v_master_activity_code)
--               or dd.specific_service_code in (v_master_activity_code))
               AND a.claim_seq_id IS NULL 
               ) r
          FULL OUTER JOIN
           ( SELECT distinct(b.approved_amount) AS used_amount , a.claim_seq_id,A.Pat_Auth_Seq_Id,b.code
               FROM APP.clm_authorization_details A 
               JOIN APP.pat_activity_details b ON (a.claim_seq_id = b.claim_seq_id AND A.CLM_STATUS_TYPE_ID != 'PCN' AND A.CLM_STATUS_TYPE_ID != 'REJ' )
--               LEFT JOIN APP.tpa_activity_details g ON (b.code = g.activity_code)
--               LEFT JOIN APP.tpa_activity_details gg ON (g.master_activity_code = gg.master_activity_code )
--               LEFT JOIN  APP.dental_rule_tab  dd on (dd.cdt_code = b.code)
--               LEFT JOIN APP.tpa_activity_master_details m ON (b.code = m.ACTIVITY_CODE)
--               LEFT JOIN APP.tpa_activity_master_details ma ON (m.master_activity_code = ma.Master_Activity_Code)
                WHERE A.Member_Seq_Id = v_member_seq_id  
                   and a.Benifit_Type = benefit_type
--               AND (gg.activity_code in (v_master_activity_code) 
--               or dd.specific_service_code in (v_master_activity_code)
--               )
)s
               ON ( r.claim_seq_id = s.claim_seq_id )
               WHERE (  NVL(r.Pat_Auth_Seq_Id,0)= NVL(v_seq_id,0)
                OR  NVL(s.claim_seq_id,0) = NVL(v_seq_id,0)
                OR NVL(S.Pat_Auth_Seq_Id,0)= NVL(v_seq_id,0));
	


rec_get_utilized_amt1   per_policy_act_cur%rowtype;	


--PRAGMA AUTONOMOUS_TRANSACTION;
     
BEGIN
  
 SELECT  CASE    WHEN v_benefit_type = 'Cash Benefit'                                THEN 'CB'
                 WHEN v_benefit_type = 'International Emergency medical assistance'  THEN 'IEMA' 
                 WHEN v_benefit_type = 'Palliative and hospice care benefit'         THEN 'PAHC'
                 WHEN v_benefit_type = 'In-Patient Rehabilitation'                   THEN 'IPRE'
                 WHEN v_benefit_type = 'Health Check Up'                             THEN 'HEAC'
                 END AS v_benefit_type INTO benefit_type FROM dual;

   OPEN per_policy_act_cur(benefit_type);
  FETCH per_policy_act_cur INTO rec_get_utilized_amt1.utilized_amount1;
  CLOSE per_policy_act_cur;
  
 IF  NVL(v_seq_id ,0) !=  0 THEN 
 v_utilized_amount :=  nvl(rec_get_utilized_amt1.utilized_amount1,0);
 ELSE
 v_utilized_amount := 0;
 END IF;


RETURN v_utilized_amount;
  
END get_utilized_amt_act_icd_benf;

------------------------*******************************************************

function get_utilised_amt_med(
                                               v_policy_seq_id            IN  APP.tpa_enr_policy.policy_seq_id%TYPE,
                                               v_member_seq_id            IN  APP.tpa_enr_policy_member.member_seq_id%TYPE,
                                               v_request_type             IN  varchar2,
                                               v_seq_id                   IN app.clm_authorization_details.claim_seq_id%type
                                               )
return number 
is   

 v_utilized_amount number;
 
CURSOR per_policy_cursor is
SELECT SUM(nvl(s.used_amount, r.used_amount)) as utilized_amount1 FROM
         ( SELECT  DISTINCT A.tot_allowed_amount AS used_amount , b.Pat_Auth_Seq_Id, a.claim_seq_id,b.code 
               FROM pat_authorization_details a
               JOIN pat_activity_details b ON (a.pat_auth_seq_id = b.pat_auth_seq_id )
               LEFT JOIN tpa_activity_details  G ON (b.code = g.activity_code)
               LEFT JOIN tpa_activity_details gg ON (g.master_activity_code = gg.master_activity_code )
               LEFT JOIN tpa_activity_master_details M ON (b.code=m.activity_code)
               LEFT JOIN tpa_activity_master_details MM ON (m.master_activity_code=mm.master_activity_code)
               WHERE A.Member_Seq_Id =v_member_seq_id
               AND a.claim_seq_id IS NULL
               AND b.approved_amount >0
               AND a.system_of_medicine_type_id !='SAL'
               AND  A.pat_status_type_id IN ('APR','INP')
              -- AND a.hospitalization_date >= v_start_date AND A.Discharge_Date <= v_end_date
               ) r
          FULL OUTER JOIN
           ( SELECT DISTINCT A.tot_allowed_amount AS used_amount , a.claim_seq_id,a.pat_auth_seq_id,b.code
               FROM clm_authorization_details A 
               JOIN pat_activity_details b ON (a.claim_seq_id = b.claim_seq_id)
               LEFT JOIN tpa_activity_details  G ON (b.code = g.activity_code)
               LEFT JOIN tpa_activity_details gg ON (g.master_activity_code = gg.master_activity_code )
               LEFT JOIN tpa_activity_master_details M ON (b.code=m.activity_code)
               LEFT JOIN tpa_activity_master_details MM ON (m.master_activity_code = mm.master_activity_code)
               WHERE A.Member_Seq_Id = v_member_seq_id
			         AND b.approved_amount >0
               AND a.system_of_medicine_type_id !='SAL'
              -- AND A.date_of_hospitalization  >= v_start_date AND A.date_of_discharge  <= v_end_date
               AND A.CLM_STATUS_TYPE_ID IN ('APR','INP')) s
               ON ( r.claim_seq_id = s.claim_seq_id )
               WHERE (  NVL(r.Pat_Auth_Seq_Id,0) != NVL(v_seq_id,0)
                    or NVL(s.claim_seq_id,0) != nvl(v_seq_id,0));
                     
       rec_get_utilized_amt1   per_policy_cursor%rowtype;	
       
BEGIN

  OPEN per_policy_cursor;
  FETCH per_policy_cursor INTO rec_get_utilized_amt1.utilized_amount1;
  CLOSE per_policy_cursor;
  
  v_utilized_amount := nvl(rec_get_utilized_amt1.utilized_amount1,0);
  
  RETURN v_utilized_amount;
  
  END get_utilised_amt_med;
  
  --------------**********per policy*************---------------
  FUNCTION get_utilized_out_area_policy 
                    (v_policy_seq_id            IN  app.tpa_enr_policy.policy_seq_id%TYPE,
                     v_member_seq_id            IN  app.tpa_enr_policy_member.member_seq_id%TYPE,
                     v_benefit_type             IN  varchar2,
                     v_request_type             IN  varchar2,
                     v_seq_id                   IN app.clm_authorization_details.claim_seq_id%type
                     )
 RETURN number
 is
 
 CURSOR per_pol_ben_area_cur (benefit_type VARCHAR2)  IS
        SELECT SUM(nvl(s.used_amount, r.used_amount))  as utilized_amount1 FROM
         ( SELECT  DISTINCT(b.approved_amount)AS used_amount , b.Pat_Auth_Seq_Id, a.claim_seq_id ,b.code
               FROM APP.pat_authorization_details a
               JOIN APP.pat_activity_details b ON (a.pat_auth_seq_id = b.pat_auth_seq_id AND A.pat_status_type_id != 'PCN' AND A.pat_status_type_id != 'REJ' )
           WHERE A.Member_Seq_Id = v_member_seq_id 
              AND   (A.out_area_cover_yn = 'Y'
			  or (NVL(A.area_cover_yn,'N') = 'N' AND nvl(A.out_area_cover_yn,'N') = 'N' AND NVL(B.Override_Yn,'N') = 'Y'))
				 and a.Benifit_Type = benefit_type
               AND a.claim_seq_id IS NULL 
               ) r
          FULL OUTER JOIN
           ( SELECT DISTINCT(b.approved_amount) AS used_amount , a.claim_seq_id,A.Pat_Auth_Seq_Id,b.code
               FROM APP.clm_authorization_details A 
               JOIN APP.pat_activity_details b ON (a.claim_seq_id = b.claim_seq_id AND A.CLM_STATUS_TYPE_ID != 'PCN' AND A.CLM_STATUS_TYPE_ID != 'REJ' )
                WHERE A.Member_Seq_Id = v_member_seq_id  
                 AND   (A.out_area_cover_yn = 'Y'
				  or (NVL(A.area_cover_yn,'N') = 'N' AND nvl(A.out_area_cover_yn,'N') = 'N' AND NVL(B.Override_Yn,'N') = 'Y'))
				   and a.Benifit_Type = benefit_type
                )s
               ON ( r.claim_seq_id = s.claim_seq_id )
               WHERE (  NVL(r.Pat_Auth_Seq_Id,0)!= NVL(0,0)
                OR  NVL(s.claim_seq_id,0) != NVL(0,0)
               );
               
			rec_get_utilized_amt1  per_pol_ben_area_cur%rowtype;
      v_utilized_amount number;
      benefit_type  varchar2(30);
      
      
 begin
 
  SELECT  CASE   WHEN v_benefit_type = 'In-Patient Benefit'                          THEN 'IPT'
                 WHEN v_benefit_type = 'Out-Patient Benefit'                         THEN 'OPTS' 
                 WHEN v_benefit_type = 'In-Patient Maternity'                        THEN 'IMTI'
                 WHEN v_benefit_type = 'Out-Patient Maternity'                       THEN 'OMTI'
                 WHEN v_benefit_type = 'Optical Benefit'                             THEN 'OPTC'
				         WHEN v_benefit_type = 'Dental Benefit'                              THEN 'DNTL'
                 END AS v_benefit_type INTO benefit_type FROM dual;
 
 OPEN per_pol_ben_area_cur(benefit_type);
 FETCH per_pol_ben_area_cur INTO rec_get_utilized_amt1.utilized_amount1;
 CLOSE per_pol_ben_area_cur;
 
 v_utilized_amount := NVL(rec_get_utilized_amt1.utilized_amount1,0);
 
 RETURN v_utilized_amount;
 
 END;
  
  
  
  --------------***************Per Claim***********---------------
     
FUNCTION get_utilized_amt_out_area
                    (v_policy_seq_id            IN  app.tpa_enr_policy.policy_seq_id%TYPE,
                     v_member_seq_id            IN  app.tpa_enr_policy_member.member_seq_id%TYPE,
                	--v_master_activity_code     IN  APP.tpa_activity_master_details.master_activity_code%TYPE,
                     v_benefit_type             IN  varchar2,
                     v_request_type             IN  varchar2,
                     v_seq_id                   IN app.clm_authorization_details.claim_seq_id%type
                     )
RETURN number

is

 v_utilized_amount number;


CURSOR per_clm_ben_area_cur (benefit_type VARCHAR2)  IS
       SELECT SUM(nvl(s.used_amount, r.used_amount))  as utilized_amount1 FROM
         ( SELECT  DISTINCT(b.approved_amount)AS used_amount , b.Pat_Auth_Seq_Id, a.claim_seq_id ,b.code
               FROM APP.pat_authorization_details a
               JOIN APP.pat_activity_details b ON (a.pat_auth_seq_id = b.pat_auth_seq_id AND A.pat_status_type_id != 'PCN' AND A.pat_status_type_id != 'REJ' )
           WHERE A.Member_Seq_Id = v_member_seq_id 
             ---  or  b.OVERRIDE_YN = 'Y'
				 and a.Benifit_Type = benefit_type
               AND a.claim_seq_id IS NULL 
               ) r
          FULL OUTER JOIN
           ( SELECT DISTINCT(b.approved_amount) AS used_amount , a.claim_seq_id,A.Pat_Auth_Seq_Id,b.code
               FROM APP.clm_authorization_details A 
               JOIN APP.pat_activity_details b ON (a.claim_seq_id = b.claim_seq_id AND A.CLM_STATUS_TYPE_ID != 'PCN' AND A.CLM_STATUS_TYPE_ID != 'REJ' )
                WHERE A.Member_Seq_Id = v_member_seq_id  
                 ---- or b.OVERRIDE_YN = 'Y'
				   and a.Benifit_Type = benefit_type
                )s
               ON ( r.claim_seq_id = s.claim_seq_id )
               WHERE (  NVL(r.Pat_Auth_Seq_Id,0)= NVL(v_seq_id,0)
                OR  NVL(s.claim_seq_id,0) = NVL(v_seq_id,0)
                OR NVL(S.Pat_Auth_Seq_Id,0) = NVL(v_seq_id,0));
				
   rec_get_utilized_amt1   per_clm_ben_area_cur%rowtype;	

   CURSOR pat_area_cover_cur
   IS
   SELECT a.out_area_cover_yn,a.AREA_COVER_YN
   FROM APP.pat_authorization_details a
   WHERE a.pat_auth_seq_id = nvl(v_seq_id,0);
   
   pat_out_area_cover  varchar2(5);
   pat_area_cover      varchar2(5);
   
   CURSOR clm_area_cover_cur
   IS
   SELECT a.out_area_cover_yn,a.AREA_COVER_YN
   FROM app.Clm_Authorization_Details a
   WHERE a.claim_seq_id       = nvl(v_seq_id,0)
         OR a.pat_auth_seq_id = nvl(v_seq_id,0);
		 
   clm_out_area_cover  varchar2(5);
   clm_area_cover      varchar2(5);
  
   CURSOR  override_cur 
   IS
   SELECT a.Override_Yn
   from APP.Pat_Activity_Details a
   where a.Pat_Auth_Seq_Id = nvl(v_seq_id,0)
       OR a.claim_seq_id= nvl(v_seq_id,0);
  
   override varchar2(5); 
   
   benefit_type  varchar2(30);
   
  PRAGMA AUTONOMOUS_TRANSACTION;

BEGIN



 SELECT  CASE    WHEN v_benefit_type = 'In-Patient Benefit'                          THEN 'IPT'
                 WHEN v_benefit_type = 'Out-Patient Benefit'                         THEN 'OPTS' 
                 WHEN v_benefit_type = 'In-Patient Maternity'                        THEN 'IMTI'
                 WHEN v_benefit_type = 'Out-Patient Maternity'                       THEN 'OMTI'
                 WHEN v_benefit_type = 'Optical Benefit'                             THEN 'OPTC'
				         WHEN v_benefit_type = 'Dental Benefit'                              THEN 'DNTL'
                 END AS v_benefit_type INTO benefit_type FROM dual;

  OPEN  per_clm_ben_area_cur(benefit_type);
	FETCH per_clm_ben_area_cur INTO  rec_get_utilized_amt1.utilized_amount1;
	CLOSE per_clm_ben_area_cur;
	
  OPEN  pat_area_cover_cur;
	FETCH pat_area_cover_cur INTO pat_out_area_cover,pat_area_cover;
	CLOSE pat_area_cover_cur;
	
	OPEN  clm_area_cover_cur;
  FETCH clm_area_cover_cur  INTO clm_out_area_cover,clm_area_cover;
	CLOSE clm_area_cover_cur; 
  
  OPEN override_cur;
  FETCH override_cur INTO override;
  CLOSE override_cur;
	-------- ----***********************add to commit in branch
  if nvl(pat_area_cover,'N') = 'N' then 
	 IF NVL(pat_out_area_cover,'N') = 'Y' OR NVL(clm_out_area_cover,'N') = 'Y' OR NVL(override,'N') = 'Y'  then
	    v_utilized_amount :=  nvl(rec_get_utilized_amt1.utilized_amount1,0);
     ELSE
        v_utilized_amount := 0;
    END IF;
  ELSE
       v_utilized_amount := 0;
     END IF;
	

	 RETURN v_utilized_amount;
	
 END get_utilized_amt_out_area;
 
 ---------*********pre existing condition disease per policy*******--------
 
 FUNCTION get_utilized_amt_ped_policy
                    (v_policy_seq_id            IN  app.tpa_enr_policy.policy_seq_id%TYPE,
                     v_member_seq_id            IN  app.tpa_enr_policy_member.member_seq_id%TYPE,
                	--v_master_activity_code     IN  APP.tpa_activity_master_details.master_activity_code%TYPE,
                     v_request_type             IN  varchar2,
                     v_seq_id                   IN app.clm_authorization_details.claim_seq_id%type
                     )
 RETURN number
 
is

 CURSOR per_policy_ped_cursor   IS
       SELECT SUM(nvl(s.used_amount, r.used_amount)) AS used_amount
       FROM
         ( SELECT  A.tot_approved_amount AS used_amount , A.Pat_Auth_Seq_Id, a.claim_seq_id
               FROM pat_authorization_details A
               WHERE A.Member_Seq_Id = v_member_seq_id
                AND  A.Ped_App_Yn = 'Y' 
                AND A.pat_status_type_id NOT IN ('PCN', 'REJ') 
                AND A.claim_seq_id IS NULL
              --- AND a.hospitalization_date >= v_start_date AND A.Discharge_Date <= v_end_date
               ) r
          FULL OUTER JOIN
           ( SELECT A.tot_approved_amount AS used_amount ,A.Pat_Auth_Seq_Id, A.claim_seq_id
               FROM clm_authorization_details A
               WHERE A.Member_Seq_Id =v_member_seq_id
               AND  A.Ped_App_Yn = 'Y' 
               AND A.CLM_STATUS_TYPE_ID NOT IN ('PCN','REJ')
              -- AND A.date_of_hospitalization  >= v_start_date AND A.date_of_discharge  <= v_end_date
            ) s
            ON ( r.claim_seq_id = s.claim_seq_id )

               WHERE ( NVL(r.Pat_Auth_Seq_Id,0) != NVL(v_seq_id,0)
                OR  NVL(s.claim_seq_id,0) != nvl(v_seq_id,0) );
                
v_utilized_amount          number;
v_used_amount              NUMBER(10);                

BEGIN

OPEN  per_policy_ped_cursor;
FETCH per_policy_ped_cursor INTO v_used_amount;
CLOSE per_policy_ped_cursor;

v_utilized_amount := NVL(v_used_amount,0);
 
RETURN v_utilized_amount;
 
END get_utilized_amt_ped_policy;

 ---------*********pre existing condition disease Per Claim*******--------
 
FUNCTION get_utilized_amt_ped
                    (v_policy_seq_id            IN  app.tpa_enr_policy.policy_seq_id%TYPE,
                     v_member_seq_id            IN  app.tpa_enr_policy_member.member_seq_id%TYPE,
                	--v_master_activity_code     IN  APP.tpa_activity_master_details.master_activity_code%TYPE,
                     v_benefit_type             IN  varchar2,
                     v_request_type             IN  varchar2,
                     v_seq_id                   IN app.clm_authorization_details.claim_seq_id%type
                     )
RETURN number

is

v_utilized_amount          number;
v_used_amount              NUMBER(10);

 CURSOR per_ped_cursor   IS
       SELECT SUM(nvl(s.used_amount, r.used_amount)) AS used_amount
       FROM
         ( SELECT  a.tot_approved_amount AS used_amount , a.Pat_Auth_Seq_Id, a.claim_seq_id
               FROM pat_authorization_details a
               WHERE A.Member_Seq_Id = v_member_seq_id
              --  AND  a.Ped_App_Yn = 'Y' 
                AND A.pat_status_type_id NOT IN ('PCN', 'REJ')
                AND a.claim_seq_id IS NULL
              --- AND a.hospitalization_date >= v_start_date AND A.Discharge_Date <= v_end_date
               ) r
          FULL OUTER JOIN
           ( SELECT a.tot_approved_amount AS used_amount ,a.Pat_Auth_Seq_Id, a.claim_seq_id
               FROM clm_authorization_details A
               WHERE A.Member_Seq_Id =v_member_seq_id
              ---  AND  a.Ped_App_Yn = 'Y' 
                AND A.CLM_STATUS_TYPE_ID NOT IN ('PCN','REJ')
              -- AND A.date_of_hospitalization  >= v_start_date AND A.date_of_discharge  <= v_end_date
            ) s
            ON ( r.claim_seq_id = s.claim_seq_id )

               WHERE ( NVL(r.Pat_Auth_Seq_Id,0) = NVL(v_seq_id,0)
                OR  NVL(s.claim_seq_id,0) = nvl(v_seq_id,0)
                OR  NVL(s.Pat_Auth_Seq_Id,0) = nvl(v_seq_id,0) );
           

 \*CURSOR per_claim_act_cur IS
       SELECT SUM(NVL(a.Final_App_Amount , 0)) AS used_amount
             FROM clm_authorization_details A
             WHERE  A.claim_seq_id !=nvl(v_seq_id)
             AND  a.member_seq_id=rule_rec.member_seq_id
            AND A.clm_status_type_id NOT IN ('REJ','PCO');*\

 \*CURSOR per_pat_act_cur IS
       SELECT SUM(NVL(a.Final_App_Amount , 0)) AS used_amount
             FROM pat_authorization_details A
              WHERE  A.Pat_Auth_Seq_Id != rule_rec.seq_id
             AND  a.member_seq_id=rule_rec.member_seq_id
            AND A.pat_status_type_id NOT IN ('REJ','PCO');
            *\
 
 CURSOR pat_ped  
 is
 SELECT a.Ped_App_Yn 
 FROM APP.Pat_Authorization_Details a         
 where a.Pat_Auth_Seq_Id = nvl(v_seq_id,0)
 and a.Claim_Seq_Id  is null;
 
  rec_pat_ped   varchar2(5);
 
 CURSOR clm_ped  
 is
 SELECT a.Ped_App_Yn 
 FROM APP.Clm_Authorization_Details a  
 where a.Claim_Seq_Id = nvl(v_seq_id,0)
 or a.Pat_Auth_Seq_Id = nvl(v_seq_id,0);
 
  rec_clm_ped   varchar2(5);
   

begin

OPEN  per_ped_cursor;
FETCH per_ped_cursor INTO v_used_amount;
CLOSE per_ped_cursor;

OPEN  pat_ped;
FETCH pat_ped INTO rec_pat_ped;
CLOSE pat_ped;

OPEN  clm_ped;
FETCH clm_ped  INTO rec_clm_ped;
CLOSE clm_ped;


IF  NVL(rec_pat_ped,'N') = 'Y' OR NVL(rec_clm_ped,'N') = 'Y'  THEN 
v_utilized_amount := NVL(v_used_amount,0);
ELSE
v_utilized_amount := 0;
END IF;

RETURN  v_utilized_amount;

END  get_utilized_amt_ped;
 
-----------********************FOR OVERALL REMARKS******************  ----add to commit in branch

PROCEDURE overall_remarks
                        (
                          v_prod_policy_seq_id       IN  APP.tpa_enr_policy.policy_seq_id%TYPE,
                          v_overall_remarks          IN  VARCHAR2,
                          v_rows_processed           OUT number
                        )
is

CURSOR POLICY_CUR
IS
SELECT A.Policy_Seq_Id
FROM APP.TPA_ENR_POLICY a join Tpa_Ins_Prod_Policy b on (a.POLICY_SEQ_ID = b.POLICY_SEQ_ID)
WHERE  b.PROD_POLICY_SEQ_ID = V_PROD_POLICY_SEQ_ID;

v_policy_seq_id NUMBER(15);

BEGIN

OPEN POLICY_CUR;
FETCH POLICY_CUR INTO v_policy_seq_id;
CLOSE POLICY_CUR;

UPDATE  app.tpa_enr_policy 
set overall_remarks = v_overall_remarks
where policy_seq_id =  v_policy_seq_id;

v_rows_processed :=  SQL%ROWCOUNT;

commit;

END;*/

----------------------------------------------


-- FUNCTION check_area_cov_yn(v_hosp_country_id                   IN NUMBER,
--                           v_nationality_country_id            IN NUMBER,
--                           v_region_id                         IN NUMBER)
-- RETURN VARCHAR2
-- IS
--   CURSOR cur_act_country_list IS
--     SELECT DISTINCT l.country_id
--     FROM app.tpa_region_country_list l
--     WHERE l.region_id = v_region_id
--      AND l.country_id = v_hosp_country_id
--      AND NVL(l.nationality_yn,'N') = 'N';
--  
--  CURSOR cur_natl_country_list IS
--     SELECT DISTINCT l.country_id
--     FROM app.tpa_region_country_list l
--     WHERE l.region_id = v_region_id
--      AND l.country_id = v_nationality_country_id
--      AND v_hosp_country_id = v_nationality_country_id
--      AND NVL(l.nationality_yn,'N') = 'Y';
--     
--   rec_act_country_list         cur_act_country_list%ROWTYPE;   
--   rec_natl_country_list        cur_natl_country_list%ROWTYPE;
--   v_area_cov_yn                VARCHAR2(5);
--      
-- BEGIN
--   
--   OPEN  cur_act_country_list;
--   FETCH cur_act_country_list INTO rec_act_country_list;
--   CLOSE cur_act_country_list;
--   
--   IF rec_act_country_list.country_id IS NULL THEN
--     OPEN  cur_natl_country_list;
--     FETCH cur_natl_country_list INTO rec_natl_country_list;
--     CLOSE cur_natl_country_list;
--   END IF;
--   
--   v_area_cov_yn := CASE WHEN rec_act_country_list.country_id IS NULL 
--                              AND rec_natl_country_list.country_id IS NULL THEN 'N'
--                         ELSE 'Y' END;
--   
--   RETURN(NVL(v_area_cov_yn,'N'));
--   
-- END check_area_cov_yn;  
--####################################################################################################
PROCEDURE get_policy_tob(v_policy_seq_id              IN TPA_INS_PROD_POLICY_RULES.PROD_POLICY_RULE_SEQ_ID%TYPE,
                         v_member_seq_id              IN TPA_ENR_POLICY_MEMBER.MEMBER_SEQ_ID%TYPE,
                         v_module_flag                IN VARCHAR2,
                         v_seq_id                     IN NUMBER,
                         v_benefit_type               IN OUT VARCHAR2,
                         result_set                   OUT SYS_REFCURSOR,
                         v_policy_details             OUT SYS_REFCURSOR
                         )
 IS
 
  CURSOR policy_type_cur IS
    SELECT po.enrol_type_id
    FROM TPA_ENR_POLICY po
    WHERE po.policy_seq_id = v_policy_seq_id;
    
  CURSOR ind_rule_seq_id IS
    SELECT R.PROD_POLICY_RULE_SEQ_ID
    FROM TPA_ENR_POLICY P
    JOIN TPA_INS_PROD_POLICY PR ON PR.PRODUCT_SEQ_ID = P.PRODUCT_SEQ_ID
    JOIN TPA_INS_PROD_POLICY_RULES R ON (R.PROD_POLICY_SEQ_ID = PR.PROD_POLICY_SEQ_ID and sysdate BETWEEN r.VALID_FROM and nvl(r.VALID_TO,sysdate))
    WHERE P.POLICY_SEQ_ID = v_policy_seq_id;
  
  CURSOR cur_rule_seq_id IS
    SELECT r.prod_policy_rule_seq_id
     FROM APP.TPA_ENR_POLICY EP
     LEFT OUTER JOIN APP.TPA_INS_PROD_POLICY PP ON (EP.POLICY_SEQ_ID=PP.POLICY_SEQ_ID)
     LEFT OUTER JOIN APP.TPA_INS_PROD_POLICY_RULES R ON (PP.PROD_POLICY_SEQ_ID=R.PROD_POLICY_SEQ_ID)
    WHERE EP.POLICY_SEQ_ID = v_policy_seq_id;
    
   rec_rule_seq_id       cur_rule_seq_id%ROWTYPE; 
   v_enrl_type           VARCHAR2(10);
   

        -- Maternity not allowed for dependent(CR - 0182)
   CURSOR mem_cur IS
   SELECT M.RELSHIP_TYPE_ID,nvl(M.MARITAL_STATUS_ID,'SNG') MARITAL_STATUS_ID
     FROM TPA_ENR_POLICY_MEMBER M WHERE M.MEMBER_SEQ_ID=v_member_seq_id;
     
   v_mem_rec           mem_cur%rowtype;
        -------------------------------------------
        
 BEGIN
   
  OPEN policy_type_cur;
  FETCH policy_type_cur INTO v_enrl_type;
  CLOSE policy_type_cur;
  
  IF v_enrl_type = 'COR' THEN
    OPEN  cur_rule_seq_id;
    FETCH cur_rule_seq_id INTO rec_rule_seq_id;
    CLOSE cur_rule_seq_id;
  ELSE
    OPEN  ind_rule_seq_id;
    FETCH ind_rule_seq_id INTO rec_rule_seq_id;
    CLOSE ind_rule_seq_id;
  END IF;
  OPEN  mem_cur;
  FETCH mem_cur INTO v_mem_rec;
  CLOSE mem_cur;
  
 IF v_benefit_type IS NOT NULL THEN  
  OPEN result_set FOR
   WITH RULE_DATA AS
     (SELECT d.cond_fun,CD.COND_SEQ_ID,
             CL.CLAUSE_NAME,CV.COVRG_NAME,CD.COND_NAME,
        d.cond_fun,
       CASE CD.COND_SEQ_ID WHEN 1 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),'''',1)-1)
                           WHEN 4 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,3)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,3)+2),'''',1)-1)
                           WHEN 5 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,13)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,13)+2),'''',1)-1)
                           WHEN 6 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,23)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,23)+2),'''',1)-1)
                           WHEN 7 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,33)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,33)+2),'''',1)-1)
                           WHEN 8 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,43)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,43)+2),'''',1)-1)
                           WHEN 9 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,53)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,53)+2),'''',1)-1)  
                           WHEN 10 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,63)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,63)+2),'''',1)-1)
                           WHEN 26 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,3)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,3)+2),'''',1)-1)
                           WHEN 29 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)    
                           WHEN 30 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)
                           WHEN 31 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)
                           WHEN 32 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)    
                           WHEN 33 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)
                           WHEN 34 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)
                           WHEN 35 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)    
                           WHEN 36 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)
                           WHEN 37 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)      
                           WHEN 38 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)
                           WHEN 39 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)
                             
                           WHEN 68 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,3)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,3)+2),'''',1)-1)
                           
                           WHEN 117 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,1)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,1)+2),'''',1)-1)  
                           WHEN 118 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,1)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,1)+2),'''',1)-1)
                           WHEN 119 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,1)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,1)+2),'''',1)-1)  
                           WHEN 120 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,1)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,1)+2),'''',1)-1)
                           WHEN 121 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,1)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,1)+2),'''',1)-1)  
                           WHEN 122 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,1)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,1)+2),'''',1)-1)
                           WHEN 131 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,5)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,5)+2),'''',1)-1)
                           WHEN 133 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),'''',1)-1) 

                           WHEN 134 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,3)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,3)+2),'''',1)-1)
                           WHEN 135 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,3)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,3)+2),'''',1)-1)
                           WHEN 136 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)
                           WHEN 137 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)
                           WHEN 138 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)
                           
                           WHEN 139 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)
                           WHEN 211 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,7)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,7)+2),'''',1)-1)
                           WHEN 140 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),'''',1)-1)
                           WHEN 210 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,9)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,9)+2),'''',1)-1)
                           
                           WHEN 154 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)
                           WHEN 156 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)
                           WHEN 157 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)
                           WHEN 158 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)
                           
                           WHEN 159 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,6)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,6)+2),'''',1)-1)
                           WHEN 212 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)
                               
                           WHEN 167 THEN CASE WHEN v_mem_rec.relship_type_id NOT IN ('NSF','YSP') OR v_mem_rec.marital_status_id = 'SNG' THEN NULL  --changed in CR - 0182
                                         ELSE SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1) END
                           WHEN 168 THEN CASE WHEN v_mem_rec.relship_type_id NOT IN ('NSF','YSP') OR v_mem_rec.marital_status_id = 'SNG' THEN NULL  --changed in CR - 0182
                                         ELSE SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,3)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,3)+2),'''',1)-1) END
                           WHEN 169 THEN CASE WHEN v_mem_rec.relship_type_id NOT IN ('NSF','YSP') OR v_mem_rec.marital_status_id = 'SNG' THEN NULL  --changed in CR - 0182
                                         ELSE SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,3)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,3)+2),'''',1)-1) END
                           WHEN 170 THEN CASE WHEN v_mem_rec.relship_type_id NOT IN ('NSF','YSP') OR v_mem_rec.marital_status_id = 'SNG' THEN NULL  --changed in CR - 0182
                                         ELSE SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,3)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,3)+2),'''',1)-1) END
                           WHEN 171 THEN CASE WHEN v_mem_rec.relship_type_id NOT IN ('NSF','YSP') OR v_mem_rec.marital_status_id = 'SNG' THEN NULL  --changed in CR - 0182
                                         ELSE SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,3)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,3)+2),'''',1)-1) END
                           
                           WHEN 196 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)
                           WHEN 197 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)
                           WHEN 198 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)
                           WHEN 204 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)
                           WHEN 205 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,3)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,3)+2),'''',1)-1)
                           WHEN 206 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)
                           WHEN 207 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,5)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,5)+2),'''',1)-1)
                           WHEN 209 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,7)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,7)+2),'''',1)-1)
                           WHEN 216 THEN SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2,(INSTR(D.COND_FUN,',',1,3)-1 - INSTR(D.COND_FUN,',',1,2))-2)   
                           
                                  
         END AS LIMIT,
       
       CASE CD.COND_SEQ_ID WHEN 1 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,7)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,7)+2),'''',1)-1)
                      WHEN 4 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),'''',1)-1)
                      WHEN 5 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,14)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,14)+2),'''',1)-1)
                      WHEN 6 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,24)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,24)+2),'''',1)-1)
                      WHEN 7 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,34)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,34)+2),'''',1)-1)
                      WHEN 8 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,44)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,44)+2),'''',1)-1)
                      WHEN 9 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,54)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,54)+2),'''',1)-1)  
                      WHEN 10 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,64)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,64)+2),'''',1)-1)
                      WHEN 26 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,6)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,6)+2),'''',1)-1)
                      WHEN 27 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,1)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,1)+2),'''',1)-1)      
                      WHEN 29 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,5)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,5)+2),'''',1)-1)
                      WHEN 30 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,5)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,5)+2),'''',1)-1)
                      WHEN 31 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,5)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,5)+2),'''',1)-1)
                      WHEN 32 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,5)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,5)+2),'''',1)-1)    
                      WHEN 33 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,5)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,5)+2),'''',1)-1)
                      WHEN 34 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,5)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,5)+2),'''',1)-1)
                      WHEN 35 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,5)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,5)+2),'''',1)-1)
                      WHEN 36 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,5)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,5)+2),'''',1)-1)
                      WHEN 37 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,5)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,5)+2),'''',1)-1)
                      WHEN 38 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,5)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,5)+2),'''',1)-1)
                      WHEN 39 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,5)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,5)+2),'''',1)-1)
                      WHEN 50 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),'''',1)-1)
                      WHEN 51 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),'''',1)-1)
                      WHEN 52 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),'''',1)-1)
                      WHEN 53 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),'''',1)-1)
                      WHEN 54 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),'''',1)-1)             
                      WHEN 55 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),'''',1)-1)
                      WHEN 56 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),'''',1)-1)
                      WHEN 57 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),'''',1)-1)
                      WHEN 58 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),'''',1)-1)
                      WHEN 59 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),'''',1)-1)
                      WHEN 60 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),'''',1)-1)
                      WHEN 61 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),'''',1)-1)
                      WHEN 62 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),'''',1)-1)
                      WHEN 63 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),'''',1)-1)
                      WHEN 64 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),'''',1)-1)
                      WHEN 65 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),'''',1)-1)
                      WHEN 66 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),'''',1)-1)
                      WHEN 68 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,6)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,6)+2),'''',1)-1)
                      WHEN 69 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),'''',1)-1)
                      WHEN 70 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),'''',1)-1)
                      WHEN 71 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),'''',1)-1)
                      WHEN 72 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),'''',1)-1)
                      WHEN 73 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),'''',1)-1)
                      WHEN 74 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),'''',1)-1)
                      WHEN 75 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),'''',1)-1)    
                      WHEN 76 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),'''',1)-1)
                      WHEN 77 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),'''',1)-1)
                      WHEN 78 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),'''',1)-1)
                      WHEN 79 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),'''',1)-1)
                      WHEN 80 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),'''',1)-1)
                      WHEN 81 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),'''',1)-1)
                      WHEN 82 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),'''',1)-1)
                      WHEN 83 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),'''',1)-1)
                      WHEN 84 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),'''',1)-1)
                      WHEN 85 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),'''',1)-1)
                      WHEN 86 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),'''',1)-1)
                      WHEN 87 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),'''',1)-1)
                      WHEN 88 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,5)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,5)+2),'''',1)-1)
                      WHEN 89 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),'''',1)-1)
                      WHEN 90 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,5)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,5)+2),'''',1)-1)    
                      WHEN 91 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),'''',1)-1)
                      WHEN 92 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),'''',1)-1)
                      WHEN 93 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),'''',1)-1)
                      WHEN 94 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),'''',1)-1)
                      WHEN 95 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),'''',1)-1)
                      WHEN 96 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),'''',1)-1)
                      WHEN 97 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),'''',1)-1)
                      WHEN 98 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),'''',1)-1)
                      WHEN 99 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),'''',1)-1)
                      WHEN 100 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),'''',1)-1)
                      WHEN 101 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),'''',1)-1)
                      WHEN 102 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),'''',1)-1)
                      WHEN 103 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),'''',1)-1)
                      WHEN 104 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),'''',1)-1)    
                      WHEN 105 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,6)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,6)+2),'''',1)-1)    
                      WHEN 106 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,6)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,6)+2),'''',1)-1)
                      WHEN 107 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,6)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,6)+2),'''',1)-1)
                      WHEN 108 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,6)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,6)+2),'''',1)-1)
                      WHEN 109 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,6)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,6)+2),'''',1)-1)
                      WHEN 110 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,1)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,1)+2),'''',1)-1)
                      WHEN 111 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,1)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,1)+2),'''',1)-1)
                      WHEN 112 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,1)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,1)+2),'''',1)-1)
                      WHEN 113 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,1)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,1)+2),'''',1)-1)
                      WHEN 114 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,1)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,1)+2),'''',1)-1)
                      WHEN 115 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,1)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,1)+2),'''',1)-1)
                      WHEN 116 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,1)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,1)+2),'''',1)-1)
                      WHEN 117 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,6)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,6)+2),'''',1)-1)
                      
                      WHEN 131 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,9)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,9)+2),'''',1)-1)
                      
                      WHEN 133 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,6)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,6)+2),'''',1)-1)
                      WHEN 134 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,5)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,5)+2),'''',1)-1)                      
                      WHEN 135 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,5)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,5)+2),'''',1)-1)                        
                      WHEN 136 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,5)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,5)+2),'''',1)-1)                        
                      WHEN 137 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,5)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,5)+2),'''',1)-1)                        
                      WHEN 138 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,5)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,5)+2),'''',1)-1)                      
                      WHEN 141 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,1)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,1)+2),'''',1)-1)                        
                      WHEN 142 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,1)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,1)+2),'''',1)-1)                        
                      WHEN 143 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,1)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,1)+2),'''',1)-1)                        
                      WHEN 144 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,1)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,1)+2),'''',1)-1)                        
                      WHEN 145 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,1)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,1)+2),'''',1)-1)                        
                      WHEN 146 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,1)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,1)+2),'''',1)-1)                        
                      WHEN 147 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,1)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,1)+2),'''',1)-1)                        
                      WHEN 148 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,1)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,1)+2),'''',1)-1)                        
                      WHEN 149 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,1)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,1)+2),'''',1)-1)                        
                      WHEN 150 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,1)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,1)+2),'''',1)-1)                        
                      WHEN 151 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,1)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,1)+2),'''',1)-1)                        
                      WHEN 152 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,1)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,1)+2),'''',1)-1)                        
                      WHEN 153 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),'''',1)-1)                        
                      WHEN 154 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),'''',1)-1)
                      WHEN 155 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,1)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,1)+2),'''',1)-1) 
                      WHEN 156 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,8)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,8)+2),'''',1)-1)
                      WHEN 157 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,8)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,8)+2),'''',1)-1)
                      WHEN 158 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,8)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,8)+2),'''',1)-1)
                      
                      WHEN 167 THEN CASE WHEN v_mem_rec.relship_type_id NOT IN ('NSF','YSP') OR v_mem_rec.marital_status_id = 'SNG'  THEN NULL  --changed in CR - 0182
                                    ELSE SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,29)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,29)+2),'''',1)-1) END
                      WHEN 168 THEN CASE WHEN v_mem_rec.relship_type_id NOT IN ('NSF','YSP') OR v_mem_rec.marital_status_id = 'SNG'  THEN NULL  --changed in CR - 0182
                                    ELSE SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,18)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,18)+2),'''',1)-1) END
                      WHEN 169 THEN CASE WHEN v_mem_rec.relship_type_id NOT IN ('NSF','YSP') OR v_mem_rec.marital_status_id = 'SNG'  THEN NULL  --changed in CR - 0182
                                    ELSE SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,18)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,18)+2),'''',1)-1) END
                      WHEN 170 THEN CASE WHEN v_mem_rec.relship_type_id NOT IN ('NSF','YSP') OR v_mem_rec.marital_status_id = 'SNG'  THEN NULL  --changed in CR - 0182
                                    ELSE SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,10)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,10)+2),'''',1)-1) END
                      WHEN 171 THEN CASE WHEN v_mem_rec.relship_type_id NOT IN ('NSF','YSP') OR v_mem_rec.marital_status_id = 'SNG'  THEN NULL  --changed in CR - 0182
                                    ELSE SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,10)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,10)+2),'''',1)-1) END
                      
                      
                      WHEN 196 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,5)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,5)+2),'''',1)-1)      
                      WHEN 197 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,5)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,5)+2),'''',1)-1)      
                      WHEN 198 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,5)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,5)+2),'''',1)-1)      
                      WHEN 200 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,1)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,1)+2),'''',1)-1)      
                      WHEN 201 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,1)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,1)+2),'''',1)-1)      
                      WHEN 202 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,1)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,1)+2),'''',1)-1)      
                      WHEN 203 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,1)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,1)+2),'''',1)-1)      
                      WHEN 204 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,9)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,9)+2),'''',1)-1)      
                      WHEN 205 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,5)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,5)+2),'''',1)-1)      
                      WHEN 206 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),'''',1)-1)      
                      WHEN 207 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,8)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,8)+2),'''',1)-1)      
                      WHEN 208 THEN REGEXP_SUBSTR(D.COND_FUN,'[^('')]+',1,2)
                      WHEN 216 THEN substr(D.COND_FUN,instr(D.COND_FUN,',',1,5)+2,(instr(D.COND_FUN,',',1,6) - instr(D.COND_FUN,',',1,5))-3)
                          
                          
         END AS COPAY_PERC,
         
       CASE CD.COND_SEQ_ID WHEN 4 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,7)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,7)+2),'''',1)-1)
                           WHEN 5 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,17)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,17)+2),'''',1)-1)
                           WHEN 6 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,27)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,27)+2),'''',1)-1)
                           WHEN 7 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,37)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,37)+2),'''',1)-1)
                           WHEN 8 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,47)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,47)+2),'''',1)-1)
                           WHEN 9 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,57)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,57)+2),'''',1)-1)  
                           WHEN 10 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,67)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,67)+2),'''',1)-1)  
                           WHEN 26 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,8)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,8)+2),'''',1)-1)  
                           WHEN 29 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,7)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,7)+2),'''',1)-1)
                           WHEN 30 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,7)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,7)+2),'''',1)-1)
                           WHEN 31 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,7)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,7)+2),'''',1)-1)
                           WHEN 32 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,7)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,7)+2),'''',1)-1)      
                           WHEN 33 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,7)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,7)+2),'''',1)-1)
                           WHEN 34 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,7)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,7)+2),'''',1)-1)
                           WHEN 35 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,7)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,7)+2),'''',1)-1)
                           WHEN 36 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,7)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,7)+2),'''',1)-1)
                           WHEN 37 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,7)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,7)+2),'''',1)-1)
                           WHEN 38 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,7)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,7)+2),'''',1)-1)
                           WHEN 39 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,7)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,7)+2),'''',1)-1)
                           WHEN 68 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,8)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,8)+2),'''',1)-1)
                           WHEN 131 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,10)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,10)+2),'''',1)-1)  
                           
                           WHEN 133 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,7)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,7)+2),'''',1)-1)
                           WHEN 134 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,6)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,6)+2),'''',1)-1)                           
                           WHEN 135 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,6)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,6)+2),'''',1)-1)                             
                           WHEN 136 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,7)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,7)+2),'''',1)-1)                           
                           WHEN 137 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,7)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,7)+2),'''',1)-1)                          
                           WHEN 138 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,7)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,7)+2),'''',1)-1)                              
                           WHEN 156 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,8)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,8)+2),'''',1)-1)                              
                           WHEN 157 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,10)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,10)+2),'''',1)-1)                              
                           WHEN 158 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,10)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,10)+2),'''',1)-1)                              
                           WHEN 196 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,7)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,7)+2),'''',1)-1)
                           WHEN 197 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,7)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,7)+2),'''',1)-1)
                           WHEN 198 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,7)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,7)+2),'''',1)-1)
                           WHEN 205 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,6)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,6)+2),'''',1)-1)
                           WHEN 207 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,8)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,8)+2),'''',1)-1)
                           WHEN 216 THEN SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,7)+2,(INSTR(D.COND_FUN,',',1,8) - INSTR(D.COND_FUN,',',1,7))-3)   
        END AS DEDUCTABLE,
        CASE WHEN CL.CLAUSE_SEQ_ID = 12 AND (v_mem_rec.relship_type_id NOT IN ('NSF','YSP') OR v_mem_rec.marital_status_id = 'SNG' ) THEN 'Not Covered'  --CR-0180 & CR-0182
        ELSE CASE C.COVERAGE_PAY_VAL WHEN 1 THEN 'Pay'
                                     WHEN 2 THEN 'Don''t Pay'
             ELSE 'Pay Conditionally' END END AS RULE_CONFIG,
        
        CD.RULE_BY,
        CD.MASTER_CODE,
        CASE CD.COND_SEQ_ID WHEN 1 THEN CASE WHEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1) IS NOT NULL THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)  ||' '||CASE  REPLACE(REGEXP_SUBSTR(D.COND_FUN,'[^,()]+',1,5),'''') WHEN 'DD' THEN 'Days' WHEN 'MM' THEN 'Months' WHEN 'YY' THEN 'Years' ELSE NULL END END 
                            WHEN 24 THEN CASE WHEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1) IS NOT NULL THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)  ||' '||CASE  REPLACE(REGEXP_SUBSTR(D.COND_FUN,'[^,()]+',1,5),'''') WHEN 'DD' THEN 'Days' WHEN 'MM' THEN 'Months' WHEN 'YY' THEN 'Years' ELSE NULL END  END 
                            WHEN 50 THEN CASE WHEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1) IS NOT NULL THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)  ||' '||CASE  REPLACE(REGEXP_SUBSTR(D.COND_FUN,'[^,()]+',1,5),'''') WHEN 'DD' THEN 'Days' WHEN 'MM' THEN 'Months' WHEN 'YY' THEN 'Years' ELSE NULL END  END 
                            WHEN 51 THEN CASE WHEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1) IS NOT NULL THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)  ||' '||CASE  REPLACE(REGEXP_SUBSTR(D.COND_FUN,'[^,()]+',1,5),'''') WHEN 'DD' THEN 'Days' WHEN 'MM' THEN 'Months' WHEN 'YY' THEN 'Years' ELSE NULL END  END 
                            WHEN 52 THEN CASE WHEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1) IS NOT NULL THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)  ||' '||CASE  REPLACE(REGEXP_SUBSTR(D.COND_FUN,'[^,()]+',1,5),'''') WHEN 'DD' THEN 'Days' WHEN 'MM' THEN 'Months' WHEN 'YY' THEN 'Years' ELSE NULL END  END 
                            WHEN 53 THEN CASE WHEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1) IS NOT NULL THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)  ||' '||CASE  REPLACE(REGEXP_SUBSTR(D.COND_FUN,'[^,()]+',1,5),'''') WHEN 'DD' THEN 'Days' WHEN 'MM' THEN 'Months' WHEN 'YY' THEN 'Years' ELSE NULL END  END 
                            WHEN 54 THEN CASE WHEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1) IS NOT NULL THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)  ||' '||CASE  REPLACE(REGEXP_SUBSTR(D.COND_FUN,'[^,()]+',1,5),'''') WHEN 'DD' THEN 'Days' WHEN 'MM' THEN 'Months' WHEN 'YY' THEN 'Years' ELSE NULL END  END 
                            WHEN 55 THEN CASE WHEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1) IS NOT NULL THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)  ||' '||CASE  REPLACE(REGEXP_SUBSTR(D.COND_FUN,'[^,()]+',1,5),'''') WHEN 'DD' THEN 'Days' WHEN 'MM' THEN 'Months' WHEN 'YY' THEN 'Years' ELSE NULL END  END 
                            WHEN 56 THEN CASE WHEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1) IS NOT NULL THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)  ||' '||CASE  REPLACE(REGEXP_SUBSTR(D.COND_FUN,'[^,()]+',1,5),'''') WHEN 'DD' THEN 'Days' WHEN 'MM' THEN 'Months' WHEN 'YY' THEN 'Years' ELSE NULL END  END 
                            WHEN 57 THEN CASE WHEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1) IS NOT NULL THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)  ||' '||CASE  REPLACE(REGEXP_SUBSTR(D.COND_FUN,'[^,()]+',1,5),'''') WHEN 'DD' THEN 'Days' WHEN 'MM' THEN 'Months' WHEN 'YY' THEN 'Years' ELSE NULL END  END 
                            WHEN 58 THEN CASE WHEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1) IS NOT NULL THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)  ||' '||CASE  REPLACE(REGEXP_SUBSTR(D.COND_FUN,'[^,()]+',1,5),'''') WHEN 'DD' THEN 'Days' WHEN 'MM' THEN 'Months' WHEN 'YY' THEN 'Years' ELSE NULL END  END 
                            WHEN 59 THEN CASE WHEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1) IS NOT NULL THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)  ||' '||CASE  REPLACE(REGEXP_SUBSTR(D.COND_FUN,'[^,()]+',1,5),'''') WHEN 'DD' THEN 'Days' WHEN 'MM' THEN 'Months' WHEN 'YY' THEN 'Years' ELSE NULL END  END 
                            WHEN 60 THEN CASE WHEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1) IS NOT NULL THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)  ||' '||CASE  REPLACE(REGEXP_SUBSTR(D.COND_FUN,'[^,()]+',1,5),'''') WHEN 'DD' THEN 'Days' WHEN 'MM' THEN 'Months' WHEN 'YY' THEN 'Years' ELSE NULL END  END 
                            WHEN 61 THEN CASE WHEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1) IS NOT NULL THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)  ||' '||CASE  REPLACE(REGEXP_SUBSTR(D.COND_FUN,'[^,()]+',1,5),'''') WHEN 'DD' THEN 'Days' WHEN 'MM' THEN 'Months' WHEN 'YY' THEN 'Years' ELSE NULL END  END 
                            WHEN 62 THEN CASE WHEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1) IS NOT NULL THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)  ||' '||CASE  REPLACE(REGEXP_SUBSTR(D.COND_FUN,'[^,()]+',1,5),'''') WHEN 'DD' THEN 'Days' WHEN 'MM' THEN 'Months' WHEN 'YY' THEN 'Years' ELSE NULL END  END 
                            WHEN 63 THEN CASE WHEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1) IS NOT NULL THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)  ||' '||CASE  REPLACE(REGEXP_SUBSTR(D.COND_FUN,'[^,()]+',1,5),'''') WHEN 'DD' THEN 'Days' WHEN 'MM' THEN 'Months' WHEN 'YY' THEN 'Years' ELSE NULL END  END 
                            WHEN 64 THEN CASE WHEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1) IS NOT NULL THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)  ||' '||CASE  REPLACE(REGEXP_SUBSTR(D.COND_FUN,'[^,()]+',1,5),'''') WHEN 'DD' THEN 'Days' WHEN 'MM' THEN 'Months' WHEN 'YY' THEN 'Years' ELSE NULL END  END 
                            WHEN 65 THEN CASE WHEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1) IS NOT NULL THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)  ||' '||CASE  REPLACE(REGEXP_SUBSTR(D.COND_FUN,'[^,()]+',1,5),'''') WHEN 'DD' THEN 'Days' WHEN 'MM' THEN 'Months' WHEN 'YY' THEN 'Years' ELSE NULL END  END 
                            WHEN 66 THEN CASE WHEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1) IS NOT NULL THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)  ||' '||CASE  REPLACE(REGEXP_SUBSTR(D.COND_FUN,'[^,()]+',1,5),'''') WHEN 'DD' THEN 'Days' WHEN 'MM' THEN 'Months' WHEN 'YY' THEN 'Years' ELSE NULL END  END 
                            WHEN 67 THEN CASE WHEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1) IS NOT NULL THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)  ||' '||CASE  REPLACE(REGEXP_SUBSTR(D.COND_FUN,'[^,()]+',1,5),'''') WHEN 'DD' THEN 'Days' WHEN 'MM' THEN 'Months' WHEN 'YY' THEN 'Years' ELSE NULL END  END 
                            WHEN 69 THEN CASE WHEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1) IS NOT NULL THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)  ||' '||CASE  REPLACE(REGEXP_SUBSTR(D.COND_FUN,'[^,()]+',1,5),'''') WHEN 'DD' THEN 'Days' WHEN 'MM' THEN 'Months' WHEN 'YY' THEN 'Years' ELSE NULL END  END 
                            WHEN 70 THEN CASE WHEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1) IS NOT NULL THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)  ||' '||CASE  REPLACE(REGEXP_SUBSTR(D.COND_FUN,'[^,()]+',1,5),'''') WHEN 'DD' THEN 'Days' WHEN 'MM' THEN 'Months' WHEN 'YY' THEN 'Years' ELSE NULL END  END 
                            WHEN 71 THEN CASE WHEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1) IS NOT NULL THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)  ||' '||CASE  REPLACE(REGEXP_SUBSTR(D.COND_FUN,'[^,()]+',1,5),'''') WHEN 'DD' THEN 'Days' WHEN 'MM' THEN 'Months' WHEN 'YY' THEN 'Years' ELSE NULL END  END 
                            WHEN 72 THEN CASE WHEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1) IS NOT NULL THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)  ||' '||CASE  REPLACE(REGEXP_SUBSTR(D.COND_FUN,'[^,()]+',1,5),'''') WHEN 'DD' THEN 'Days' WHEN 'MM' THEN 'Months' WHEN 'YY' THEN 'Years' ELSE NULL END  END 
                            WHEN 73 THEN CASE WHEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1) IS NOT NULL THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)  ||' '||CASE  REPLACE(REGEXP_SUBSTR(D.COND_FUN,'[^,()]+',1,5),'''') WHEN 'DD' THEN 'Days' WHEN 'MM' THEN 'Months' WHEN 'YY' THEN 'Years' ELSE NULL END  END 
                            WHEN 74 THEN CASE WHEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1) IS NOT NULL THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)  ||' '||CASE  REPLACE(REGEXP_SUBSTR(D.COND_FUN,'[^,()]+',1,5),'''') WHEN 'DD' THEN 'Days' WHEN 'MM' THEN 'Months' WHEN 'YY' THEN 'Years' ELSE NULL END  END 
                            WHEN 75 THEN CASE WHEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1) IS NOT NULL THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)  ||' '||CASE  REPLACE(REGEXP_SUBSTR(D.COND_FUN,'[^,()]+',1,5),'''') WHEN 'DD' THEN 'Days' WHEN 'MM' THEN 'Months' WHEN 'YY' THEN 'Years' ELSE NULL END  END 
                            WHEN 76 THEN CASE WHEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1) IS NOT NULL THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)  ||' '||CASE  REPLACE(REGEXP_SUBSTR(D.COND_FUN,'[^,()]+',1,5),'''')WHEN 'DD' THEN 'Days' WHEN 'MM' THEN 'Months' WHEN 'YY' THEN 'Years' ELSE NULL END  END 
                            WHEN 77 THEN CASE WHEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1) IS NOT NULL THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)  ||' '||CASE  REPLACE(REGEXP_SUBSTR(D.COND_FUN,'[^,()]+',1,5),'''') WHEN 'DD' THEN 'Days' WHEN 'MM' THEN 'Months' WHEN 'YY' THEN 'Years' ELSE NULL END  END 
                            WHEN 78 THEN CASE WHEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1) IS NOT NULL THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)  ||' '||CASE  REPLACE(REGEXP_SUBSTR(D.COND_FUN,'[^,()]+',1,5),'''') WHEN 'DD' THEN 'Days' WHEN 'MM' THEN 'Months' WHEN 'YY' THEN 'Years' ELSE NULL END  END 
                            WHEN 79 THEN CASE WHEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1) IS NOT NULL THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)  ||' '||CASE  REPLACE(REGEXP_SUBSTR(D.COND_FUN,'[^,()]+',1,5),'''') WHEN 'DD' THEN 'Days' WHEN 'MM' THEN 'Months' WHEN 'YY' THEN 'Years' ELSE NULL END  END 
                            WHEN 80 THEN CASE WHEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1) IS NOT NULL THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)  ||' '||CASE  REPLACE(REGEXP_SUBSTR(D.COND_FUN,'[^,()]+',1,5),'''') WHEN 'DD' THEN 'Days' WHEN 'MM' THEN 'Months' WHEN 'YY' THEN 'Years' ELSE NULL END  END 
                            WHEN 81 THEN CASE WHEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1) IS NOT NULL THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)  ||' '||CASE  REPLACE(REGEXP_SUBSTR(D.COND_FUN,'[^,()]+',1,5),'''') WHEN 'DD' THEN 'Days' WHEN 'MM' THEN 'Months' WHEN 'YY' THEN 'Years' ELSE NULL END  END 
                            WHEN 82 THEN CASE WHEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1) IS NOT NULL THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)  ||' '||CASE  REPLACE(REGEXP_SUBSTR(D.COND_FUN,'[^,()]+',1,5),'''') WHEN 'DD' THEN 'Days' WHEN 'MM' THEN 'Months' WHEN 'YY' THEN 'Years' ELSE NULL END  END 
                            WHEN 83 THEN CASE WHEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1) IS NOT NULL THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)  ||' '||CASE  REPLACE(REGEXP_SUBSTR(D.COND_FUN,'[^,()]+',1,5),'''') WHEN 'DD' THEN 'Days' WHEN 'MM' THEN 'Months' WHEN 'YY' THEN 'Years' ELSE NULL END  END 
                            WHEN 84 THEN CASE WHEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1) IS NOT NULL THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)  ||' '||CASE  REPLACE(REGEXP_SUBSTR(D.COND_FUN,'[^,()]+',1,5),'''') WHEN 'DD' THEN 'Days' WHEN 'MM' THEN 'Months' WHEN 'YY' THEN 'Years' ELSE NULL END  END 
                            WHEN 85 THEN CASE WHEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1) IS NOT NULL THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)  ||' '||CASE  REPLACE(REGEXP_SUBSTR(D.COND_FUN,'[^,()]+',1,5),'''') WHEN 'DD' THEN 'Days' WHEN 'MM' THEN 'Months' WHEN 'YY' THEN 'Years' ELSE NULL END  END 
                            WHEN 86 THEN CASE WHEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1) IS NOT NULL THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)  ||' '||CASE  REPLACE(REGEXP_SUBSTR(D.COND_FUN,'[^,()]+',1,5),'''') WHEN 'DD' THEN 'Days' WHEN 'MM' THEN 'Months' WHEN 'YY' THEN 'Years' ELSE NULL END  END 
                            WHEN 87 THEN CASE WHEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1) IS NOT NULL THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)  ||' '||CASE  REPLACE(REGEXP_SUBSTR(D.COND_FUN,'[^,()]+',1,5),'''') WHEN 'DD' THEN 'Days' WHEN 'MM' THEN 'Months' WHEN 'YY' THEN 'Years' ELSE NULL END  END 
                            WHEN 88 THEN CASE WHEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,3)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+3),'''',1)-1) IS NOT NULL THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,3)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+3),'''',1)-1)  ||' '||CASE  REPLACE(REGEXP_SUBSTR(D.COND_FUN,'[^,()]+',1,6),'''') WHEN 'DD' THEN 'Days' WHEN 'MM' THEN 'Months' WHEN 'YY' THEN 'Years' ELSE NULL END  END 
                            WHEN 89 THEN CASE WHEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1) IS NOT NULL THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)  ||' '||CASE  REPLACE(REGEXP_SUBSTR(D.COND_FUN,'[^,()]+',1,5),'''') WHEN 'DD' THEN 'Days' WHEN 'MM' THEN 'Months' WHEN 'YY' THEN 'Years' ELSE NULL END  END 
                            WHEN 90 THEN CASE WHEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,3)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,3)+2),'''',1)-1) IS NOT NULL THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,3)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,3)+2),'''',1)-1)  ||' '||CASE  REPLACE(REGEXP_SUBSTR(D.COND_FUN,'[^,()]+',1,6),'''') WHEN 'DD' THEN 'Days' WHEN 'MM' THEN 'Months' WHEN 'YY' THEN 'Years' ELSE NULL END  END 
                            WHEN 91 THEN CASE WHEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1) IS NOT NULL THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)  ||' '||CASE  REPLACE(REGEXP_SUBSTR(D.COND_FUN,'[^,()]+',1,5),'''') WHEN 'DD' THEN 'Days' WHEN 'MM' THEN 'Months' WHEN 'YY' THEN 'Years' ELSE NULL END  END 
                            WHEN 92 THEN CASE WHEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1) IS NOT NULL THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)  ||' '||CASE  REPLACE(REGEXP_SUBSTR(D.COND_FUN,'[^,()]+',1,5),'''') WHEN 'DD' THEN 'Days' WHEN 'MM' THEN 'Months' WHEN 'YY' THEN 'Years' ELSE NULL END  END 
                            WHEN 93 THEN CASE WHEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1) IS NOT NULL THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)  ||' '||CASE  REPLACE(REGEXP_SUBSTR(D.COND_FUN,'[^,()]+',1,5),'''') WHEN 'DD' THEN 'Days' WHEN 'MM' THEN 'Months' WHEN 'YY' THEN 'Years' ELSE NULL END  END 
                            WHEN 94 THEN CASE WHEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1) IS NOT NULL THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)  ||' '||CASE  REPLACE(REGEXP_SUBSTR(D.COND_FUN,'[^,()]+',1,5),'''') WHEN 'DD' THEN 'Days' WHEN 'MM' THEN 'Months' WHEN 'YY' THEN 'Years' ELSE NULL END  END 
                            WHEN 95 THEN CASE WHEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1) IS NOT NULL THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)  ||' '||CASE  REPLACE(REGEXP_SUBSTR(D.COND_FUN,'[^,()]+',1,5),'''') WHEN 'DD' THEN 'Days' WHEN 'MM' THEN 'Months' WHEN 'YY' THEN 'Years' ELSE NULL END  END 
                            WHEN 96 THEN CASE WHEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1) IS NOT NULL THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)  ||' '||CASE  REPLACE(REGEXP_SUBSTR(D.COND_FUN,'[^,()]+',1,5),'''') WHEN 'DD' THEN 'Days' WHEN 'MM' THEN 'Months' WHEN 'YY' THEN 'Years' ELSE NULL END  END 
                            WHEN 97 THEN CASE WHEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1) IS NOT NULL THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)  ||' '||CASE  REPLACE(REGEXP_SUBSTR(D.COND_FUN,'[^,()]+',1,5),'''') WHEN 'DD' THEN 'Days' WHEN 'MM' THEN 'Months' WHEN 'YY' THEN 'Years' ELSE NULL END  END 
                            WHEN 98 THEN CASE WHEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1) IS NOT NULL THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)  ||' '||CASE  REPLACE(REGEXP_SUBSTR(D.COND_FUN,'[^,()]+',1,5),'''') WHEN 'DD' THEN 'Days' WHEN 'MM' THEN 'Months' WHEN 'YY' THEN 'Years' ELSE NULL END  END 
                            WHEN 99 THEN CASE WHEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1) IS NOT NULL THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)  ||' '||CASE  REPLACE(REGEXP_SUBSTR(D.COND_FUN,'[^,()]+',1,5),'''') WHEN 'DD' THEN 'Days' WHEN 'MM' THEN 'Months' WHEN 'YY' THEN 'Years' ELSE NULL END  END 
                            WHEN 100 THEN CASE WHEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1) IS NOT NULL THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)  ||' '||CASE  REPLACE(REGEXP_SUBSTR(D.COND_FUN,'[^,()]+',1,5),'''') WHEN 'DD' THEN 'Days' WHEN 'MM' THEN 'Months' WHEN 'YY' THEN 'Years' ELSE NULL END  END 
                            WHEN 101 THEN CASE WHEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1) IS NOT NULL THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)  ||' '||CASE  REPLACE(REGEXP_SUBSTR(D.COND_FUN,'[^,()]+',1,5),'''') WHEN 'DD' THEN 'Days' WHEN 'MM' THEN 'Months' WHEN 'YY' THEN 'Years' ELSE NULL END  END 
                            WHEN 102 THEN CASE WHEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1) IS NOT NULL THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)  ||' '||CASE  REPLACE(REGEXP_SUBSTR(D.COND_FUN,'[^,()]+',1,5),'''') WHEN 'DD' THEN 'Days' WHEN 'MM' THEN 'Months' WHEN 'YY' THEN 'Years' ELSE NULL END  END 
                            WHEN 103 THEN CASE WHEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1) IS NOT NULL THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)  ||' '||CASE  REPLACE(REGEXP_SUBSTR(D.COND_FUN,'[^,()]+',1,5),'''') WHEN 'DD' THEN 'Days' WHEN 'MM' THEN 'Months' WHEN 'YY' THEN 'Years' ELSE NULL END  END 
                            WHEN 104 THEN CASE WHEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1) IS NOT NULL THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)  ||' '||CASE  REPLACE(REGEXP_SUBSTR(D.COND_FUN,'[^,()]+',1,5),'''') WHEN 'DD' THEN 'Days' WHEN 'MM' THEN 'Months' WHEN 'YY' THEN 'Years' ELSE NULL END  END 
                            WHEN 111 THEN CASE WHEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,5)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,5)+2),'''',1)-1) IS NOT NULL THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,5)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,5)+2),'''',1)-1)  ||' '||CASE  REPLACE(REGEXP_SUBSTR(D.COND_FUN,'[^,()]+',1,8),'''') WHEN 'DD' THEN 'Days' WHEN 'MM' THEN 'Months' WHEN 'YY' THEN 'Years' ELSE NULL END  END 
                            WHEN 112 THEN CASE WHEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,6)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,6)+2),'''',1)-1) IS NOT NULL THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,6)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,6)+2),'''',1)-1)  ||' '||CASE  REPLACE(REGEXP_SUBSTR(D.COND_FUN,'[^,()]+',1,9),'''') WHEN 'DD' THEN 'Days' WHEN 'MM' THEN 'Months' WHEN 'YY' THEN 'Years' ELSE NULL END  END 
                            WHEN 131 THEN CASE WHEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,1)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,1)+2),'''',1)-1) IS NOT NULL THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,1)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,1)+2),'''',1)-1)  ||' '||CASE  REPLACE(REGEXP_SUBSTR(D.COND_FUN,'[^,()]+',1,4),'''') WHEN 'DD' THEN 'Days' WHEN 'MM' THEN 'Months' WHEN 'YY' THEN 'Years' ELSE NULL END  END 
                            WHEN 153 THEN CASE WHEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1) IS NOT NULL THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)  ||' '||CASE  REPLACE(REGEXP_SUBSTR(D.COND_FUN,'[^,()]+',1,5),'''') WHEN 'DD' THEN 'Days' WHEN 'MM' THEN 'Months' WHEN 'YY' THEN 'Years' ELSE NULL END  END 
                            WHEN 207 THEN CASE WHEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1) IS NOT NULL THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)  ||' '||CASE REPLACE( REGEXP_SUBSTR(D.COND_FUN,'[^,()]+',1,5),'''') WHEN 'DD' THEN 'Days' WHEN 'MM' THEN 'Months' WHEN 'YY' THEN 'Years' ELSE NULL END  END 
                            WHEN 209 THEN CASE WHEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,3)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,3)+2),'''',1)-1) IS NOT NULL THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,3)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,3)+2),'''',1)-1)  ||' '||CASE  REPLACE(REGEXP_SUBSTR(D.COND_FUN,'[^,()]+',1,6),'''') WHEN 'DD' THEN 'Days' WHEN 'MM' THEN 'Months' WHEN 'YY' THEN 'Years' ELSE NULL END  END 
                                                       
        
        END AS WAITING_PERIOD,
        
        CASE CD.COND_SEQ_ID WHEN 154 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,5)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,5)+2),'''',1)-1)
                            WHEN 206 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,5)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,5)+2),'''',1)-1)
                            
        END AS SESSIONS_BENIFIT,
        
        CASE CD.COND_SEQ_ID WHEN 26  THEN   SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,10)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,10)+2),'''',1)-1)  
                            WHEN 29  THEN   SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,9)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,9)+2),'''',1)-1)  
                            WHEN 30  THEN   SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,9)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,9)+2),'''',1)-1)  
                            WHEN 31  THEN   SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,9)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,9)+2),'''',1)-1)  
                            WHEN 32  THEN   SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,9)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,9)+2),'''',1)-1)  
                            WHEN 33  THEN   SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,9)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,9)+2),'''',1)-1)  
                            WHEN 34  THEN   SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,9)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,9)+2),'''',1)-1)  
                            WHEN 35  THEN   SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,9)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,9)+2),'''',1)-1)  
                            WHEN 36  THEN   SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,9)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,9)+2),'''',1)-1)  
                            WHEN 37  THEN   SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,9)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,9)+2),'''',1)-1)  
                            WHEN 38  THEN   SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,9)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,9)+2),'''',1)-1)  
                            WHEN 39  THEN   SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,9)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,9)+2),'''',1)-1)  
                            WHEN 68  THEN   SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,11)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,11)+2),'''',1)-1)  
                            WHEN 133  THEN   SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,13)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,13)+2),'''',1)-1)  
                            WHEN 134  THEN   SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,14)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,14)+2),'''',1)-1)  
                            WHEN 135  THEN   SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,15)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,15)+2),'''',1)-1)  
                            WHEN 136  THEN   SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,9)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,9)+2),'''',1)-1)  
                            WHEN 137  THEN   SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,9)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,9)+2),'''',1)-1)  
                            WHEN 138  THEN   SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,9)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,9)+2),'''',1)-1)  
                            
                            WHEN 139 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,3)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,3)+2),'''',1)-1)
                            WHEN 211 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,8)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,8)+2),'''',1)-1)
                            WHEN 140 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,5)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,5)+2),'''',1)-1)
                            WHEN 210 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,10)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,10)+2),'''',1)-1)
                             
                            WHEN 154  THEN   SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,6)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,6)+2),'''',1)-1)
                            WHEN 156  THEN   SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,13)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,13)+2),'''',1)-1)  
                            WHEN 157  THEN   SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,13)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,13)+2),'''',1)-1)   
                            WHEN 158  THEN   SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,13)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,13)+2),'''',1)-1)   
                            
                            WHEN 159 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,7)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,7)+2),'''',1)-1)
                            WHEN 212 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,3)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,3)+2),'''',1)-1)
                            
                            WHEN 167 THEN CASE WHEN v_mem_rec.relship_type_id NOT IN ('NSF','YSP') OR v_mem_rec.marital_status_id = 'SNG'  THEN NULL  --changed in CR - 0182
                                          ELSE SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,26)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,26)+2),'''',1)-1) END
                            WHEN 168 THEN CASE WHEN v_mem_rec.relship_type_id NOT IN ('NSF','YSP') OR v_mem_rec.marital_status_id = 'SNG'  THEN NULL  --changed in CR - 0182
                                          ELSE SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,15)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,15)+2),'''',1)-1) END
                            WHEN 169 THEN CASE WHEN v_mem_rec.relship_type_id NOT IN ('NSF','YSP') OR v_mem_rec.marital_status_id = 'SNG'  THEN NULL  --changed in CR - 0182
                                          ELSE SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,15)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,15)+2),'''',1)-1) END
                            WHEN 170 THEN CASE WHEN v_mem_rec.relship_type_id NOT IN ('NSF','YSP') OR v_mem_rec.marital_status_id = 'SNG'  THEN NULL  --changed in CR - 0182
                                          ELSE SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,38)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,38)+2),'''',1)-1) END
                            WHEN 171 THEN CASE WHEN v_mem_rec.relship_type_id NOT IN ('NSF','YSP') OR v_mem_rec.marital_status_id = 'SNG'  THEN NULL  --changed in CR - 0182
                                          ELSE SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,38)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,38)+2),'''',1)-1) END
                              
                            WHEN 196  THEN   SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,9)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,9)+2),'''',1)-1)       
                            WHEN 197  THEN   SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,9)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,9)+2),'''',1)-1)       
                            WHEN 198  THEN   SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,9)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,9)+2),'''',1)-1)       
                            WHEN 204  THEN   SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,7)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,7)+2),'''',1)-1)       
                            WHEN 205  THEN   SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,15)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,15)+2),'''',1)-1)       
                            WHEN 206  THEN   SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,6)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,6)+2),'''',1)-1)
                            WHEN 207  THEN   SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,13)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,13)+2),'''',1)-1)       
                            WHEN 209  THEN   SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,8)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,8)+2),'''',1)-1)       
                            WHEN 216  THEN   SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',-1,1)+2,2)
        END AS MODE_OF_BENIFIT,
        CL.SORT_NO,
        cd.sort_no as cond_sl_no
     
FROM tpa_ins_prod_pol_clauses B
JOIN tpa_ins_prod_pol_coverages C  ON (b.clause_seq_id = c.clause_seq_id)
JOIN tpa_ins_prod_pol_conditions D ON (c.coverage_seq_id = d.coverage_seq_id)  
JOIN APP.TPA_RULE_CONDITION_MSTR CD ON (CD.COND_ID=D.COND_ID)
JOIN APP.TPA_RULE_COVERAGE_MSTR CV ON (CD.COVRG_SEQ_ID=CV.COVRG_SEQ_ID)
JOIN APP.TPA_RULE_CLAUSE_MSTR CL ON (CL.CLAUSE_SEQ_ID=CV.CLAUSE_SEQ_ID)
where B.prod_policy_rule_seq_id=rec_rule_seq_id.prod_policy_rule_seq_id
AND CD.DISPLAY_YN = 'Y'
AND CL.BENEFIT_TYPE_ID = v_benefit_type 
)
SELECT R.COND_SEQ_ID,
       R.CLAUSE_NAME,
       R.COND_NAME,
       R.RULE_CONFIG,
       R.RULE_BY,
       R.MASTER_CODE,
       R.LIMIT,
       CASE WHEN R.COND_SEQ_ID IN (167,168,169,170,171) AND (v_mem_rec.relship_type_id NOT IN ('NSF','YSP') OR v_mem_rec.marital_status_id = 'SNG' ) THEN NULL  --changed in CR - 0182
       ELSE DISPLAY_OF_BENEFITS.get_utlized_amnt(v_member_seq_id,v_seq_id,R.COND_SEQ_ID,R.MASTER_CODE,R.RULE_BY,v_module_flag,NULL) END AS UTILIZED_AMNT,
         
       CASE WHEN R.COND_SEQ_ID IN (167,168,169,170,171) AND (v_mem_rec.relship_type_id NOT IN ('NSF','YSP') OR v_mem_rec.marital_status_id = 'SNG' ) THEN NULL  --changed in CR - 0182
       ELSE CASE /*WHEN MODE_OF_BENIFIT = 'PC' AND R.MASTER_CODE = 'D0150' AND R.RULE_BY = 'DNT' THEN
                                           TO_CHAR(CASE WHEN (R.LIMIT - DISPLAY_OF_BENEFITS.get_utlized_amnt(v_member_seq_id,v_seq_id,R.COND_SEQ_ID,R.MASTER_CODE,R.RULE_BY,v_module_flag,'PC')) >= 0 THEN
                                                             (R.LIMIT - DISPLAY_OF_BENEFITS.get_utlized_amnt(v_member_seq_id,v_seq_id,R.COND_SEQ_ID,R.MASTER_CODE,R.RULE_BY,v_module_flag,'PC')) 
                                                        ELSE 0 END)
            */WHEN MODE_OF_BENIFIT = 'PC' THEN TO_CHAR(R.LIMIT)
            WHEN MODE_OF_BENIFIT = 'PP' THEN TO_CHAR(CASE WHEN (R.LIMIT - DISPLAY_OF_BENEFITS.get_utlized_amnt(v_member_seq_id,v_seq_id,R.COND_SEQ_ID,R.MASTER_CODE,R.RULE_BY,v_module_flag,NULL)) >= 0 THEN
                                                             (R.LIMIT - DISPLAY_OF_BENEFITS.get_utlized_amnt(v_member_seq_id,v_seq_id,R.COND_SEQ_ID,R.MASTER_CODE,R.RULE_BY,v_module_flag,NULL)) 
                                                         WHEN DISPLAY_OF_BENEFITS.get_utlized_amnt(v_member_seq_id,v_seq_id,R.COND_SEQ_ID,R.MASTER_CODE,R.RULE_BY,v_module_flag,NULL) IS NULL THEN 
                                                             TO_NUMBER(R.LIMIT)
                                                        WHEN R.LIMIT IS NULL THEN NULL
                                                         ELSE 0 END)
                              ELSE TO_CHAR(R.LIMIT) END END AS BALNC_AMNT,
       R.COPAY_PERC,
       R.DEDUCTABLE,
       WAITING_PERIOD,
       SESSIONS_BENIFIT,
       CASE WHEN MODE_OF_BENIFIT = 'PC' THEN 'Per Claim' 
            WHEN MODE_OF_BENIFIT = 'PP' THEN 'Per Policy Period' 
            WHEN MODE_OF_BENIFIT = 'PD' AND R.COND_SEQ_ID IN (154,206) THEN 'Per Diagnosis'  
            WHEN MODE_OF_BENIFIT = 'PD' THEN 'Per Day' END AS MODE_OF_BENIFIT
FROM RULE_DATA R
ORDER BY R.SORT_NO,R.cond_sl_no;
 
ELSE
  OPEN result_set FOR
    WITH RULE_DATA AS
     (SELECT d.cond_fun,CD.COND_SEQ_ID,
             CL.CLAUSE_NAME,CV.COVRG_NAME,CD.COND_NAME,
        d.cond_fun,
       CASE CD.COND_SEQ_ID WHEN 1 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),'''',1)-1)
                           WHEN 4 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,3)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,3)+2),'''',1)-1)
                           WHEN 5 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,13)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,13)+2),'''',1)-1)
                           WHEN 6 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,23)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,23)+2),'''',1)-1)
                           WHEN 7 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,33)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,33)+2),'''',1)-1)
                           WHEN 8 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,43)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,43)+2),'''',1)-1)
                           WHEN 9 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,53)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,53)+2),'''',1)-1)  
                           WHEN 10 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,63)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,63)+2),'''',1)-1)
                           WHEN 26 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)
                           WHEN 29 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)    
                           WHEN 30 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)
                           WHEN 31 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)
                           WHEN 32 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)    
                           WHEN 33 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)
                           WHEN 34 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)
                           WHEN 35 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)    
                           WHEN 36 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)
                           WHEN 37 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)      
                           WHEN 38 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)
                           WHEN 39 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)
                             
                           WHEN 68 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,3)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,3)+2),'''',1)-1)
                           WHEN 117 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,1)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,1)+2),'''',1)-1)  
                           WHEN 118 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,1)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,1)+2),'''',1)-1)
                           WHEN 119 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,1)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,1)+2),'''',1)-1)  
                           WHEN 120 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,1)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,1)+2),'''',1)-1)
                           WHEN 121 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,1)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,1)+2),'''',1)-1)  
                           WHEN 122 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,1)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,1)+2),'''',1)-1)
                           WHEN 131 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,5)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,5)+2),'''',1)-1)
                           WHEN 133 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),'''',1)-1) 

                           WHEN 134 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,3)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,3)+2),'''',1)-1)
                           WHEN 135 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,3)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,3)+2),'''',1)-1)
                           WHEN 136 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)
                           WHEN 137 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)
                           WHEN 138 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)
                           
                           WHEN 139 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)
                           WHEN 211 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,7)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,7)+2),'''',1)-1)
                           WHEN 140 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),'''',1)-1)
                           WHEN 210 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,9)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,9)+2),'''',1)-1)
                           
                           WHEN 154 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)
                           WHEN 156 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)
                           WHEN 157 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)
                           WHEN 158 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)
                           
                           WHEN 159 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,6)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,6)+2),'''',1)-1)
                           WHEN 212 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)
                             
                           WHEN 167 THEN CASE WHEN v_mem_rec.relship_type_id NOT IN ('NSF','YSP') OR v_mem_rec.marital_status_id = 'SNG'  THEN NULL  --changed in CR - 0182
                                         ELSE SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1) END
                           WHEN 168 THEN CASE WHEN v_mem_rec.relship_type_id NOT IN ('NSF','YSP') OR v_mem_rec.marital_status_id = 'SNG'  THEN NULL  --changed in CR - 0182  
                                         ELSE SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,3)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,3)+2),'''',1)-1) END
                           WHEN 169 THEN CASE WHEN v_mem_rec.relship_type_id NOT IN ('NSF','YSP') OR v_mem_rec.marital_status_id = 'SNG'  THEN NULL  --changed in CR - 0182
                                         ELSE SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,3)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,3)+2),'''',1)-1) END
                           WHEN 170 THEN CASE WHEN v_mem_rec.relship_type_id NOT IN ('NSF','YSP') OR v_mem_rec.marital_status_id = 'SNG'  THEN NULL  --changed in CR - 0182
                                         ELSE SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,3)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,3)+2),'''',1)-1) END
                           WHEN 171 THEN CASE WHEN v_mem_rec.relship_type_id NOT IN ('NSF','YSP') OR v_mem_rec.marital_status_id = 'SNG'  THEN NULL  --changed in CR - 0182
                                         ELSE SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,3)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,3)+2),'''',1)-1) END
                           
                           WHEN 196 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)
                           WHEN 197 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)
                           WHEN 198 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)
                           WHEN 204 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)
                           WHEN 205 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,3)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,3)+2),'''',1)-1)
                           WHEN 206 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)
                           WHEN 207 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,5)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,5)+2),'''',1)-1)
                           WHEN 209 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,7)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,7)+2),'''',1)-1)
                           WHEN 216 THEN SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2,(INSTR(D.COND_FUN,',',1,3)-1 - INSTR(D.COND_FUN,',',1,2))-2)
                                  
         END AS LIMIT,
       
       CASE CD.COND_SEQ_ID WHEN 1 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,7)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,7)+2),'''',1)-1)
                      WHEN 4 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),'''',1)-1)
                      WHEN 5 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,14)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,14)+2),'''',1)-1)
                      WHEN 6 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,24)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,24)+2),'''',1)-1)
                      WHEN 7 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,34)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,34)+2),'''',1)-1)
                      WHEN 8 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,44)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,44)+2),'''',1)-1)
                      WHEN 9 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,54)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,54)+2),'''',1)-1)  
                      WHEN 10 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,64)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,64)+2),'''',1)-1)
                      WHEN 26 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,5)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,5)+2),'''',1)-1)
                      WHEN 27 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,1)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,1)+2),'''',1)-1)      
                      WHEN 29 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,5)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,5)+2),'''',1)-1)
                      WHEN 30 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,5)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,5)+2),'''',1)-1)
                      WHEN 31 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,5)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,5)+2),'''',1)-1)
                      WHEN 32 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,5)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,5)+2),'''',1)-1)    
                      WHEN 33 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,5)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,5)+2),'''',1)-1)
                      WHEN 34 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,5)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,5)+2),'''',1)-1)
                      WHEN 35 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,5)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,5)+2),'''',1)-1)
                      WHEN 36 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,5)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,5)+2),'''',1)-1)
                      WHEN 37 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,5)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,5)+2),'''',1)-1)
                      WHEN 38 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,5)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,5)+2),'''',1)-1)
                      WHEN 39 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,5)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,5)+2),'''',1)-1)
                      WHEN 50 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),'''',1)-1)
                      WHEN 51 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),'''',1)-1)
                      WHEN 52 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),'''',1)-1)
                      WHEN 53 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),'''',1)-1)
                      WHEN 54 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),'''',1)-1)             
                      WHEN 55 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),'''',1)-1)
                      WHEN 56 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),'''',1)-1)
                      WHEN 57 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),'''',1)-1)
                      WHEN 58 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),'''',1)-1)
                      WHEN 59 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),'''',1)-1)
                      WHEN 60 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),'''',1)-1)
                      WHEN 61 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),'''',1)-1)
                      WHEN 62 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),'''',1)-1)
                      WHEN 63 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),'''',1)-1)
                      WHEN 64 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),'''',1)-1)
                      WHEN 65 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),'''',1)-1)
                      WHEN 66 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),'''',1)-1)
                      WHEN 68 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,6)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,6)+2),'''',1)-1)
                      WHEN 69 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),'''',1)-1)
                      WHEN 70 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),'''',1)-1)
                      WHEN 71 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),'''',1)-1)
                      WHEN 72 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),'''',1)-1)
                      WHEN 73 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),'''',1)-1)
                      WHEN 74 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),'''',1)-1)
                      WHEN 75 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),'''',1)-1)    
                      WHEN 76 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),'''',1)-1)
                      WHEN 77 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),'''',1)-1)
                      WHEN 78 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),'''',1)-1)
                      WHEN 79 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),'''',1)-1)
                      WHEN 80 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),'''',1)-1)
                      WHEN 81 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),'''',1)-1)
                      WHEN 82 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),'''',1)-1)
                      WHEN 83 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),'''',1)-1)
                      WHEN 84 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),'''',1)-1)
                      WHEN 85 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),'''',1)-1)
                      WHEN 86 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),'''',1)-1)
                      WHEN 87 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),'''',1)-1)
                      WHEN 88 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,5)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,5)+2),'''',1)-1)
                      WHEN 89 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),'''',1)-1)
                      WHEN 90 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,5)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,5)+2),'''',1)-1)    
                      WHEN 91 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),'''',1)-1)
                      WHEN 92 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),'''',1)-1)
                      WHEN 93 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),'''',1)-1)
                      WHEN 94 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),'''',1)-1)
                      WHEN 95 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),'''',1)-1)
                      WHEN 96 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),'''',1)-1)
                      WHEN 97 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),'''',1)-1)
                      WHEN 98 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),'''',1)-1)
                      WHEN 99 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),'''',1)-1)
                      WHEN 100 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),'''',1)-1)
                      WHEN 101 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),'''',1)-1)
                      WHEN 102 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),'''',1)-1)
                      WHEN 103 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),'''',1)-1)
                      WHEN 104 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),'''',1)-1)    
                      WHEN 105 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,6)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,6)+2),'''',1)-1)    
                      WHEN 106 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,6)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,6)+2),'''',1)-1)
                      WHEN 107 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,6)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,6)+2),'''',1)-1)
                      WHEN 108 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,6)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,6)+2),'''',1)-1)
                      WHEN 109 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,6)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,6)+2),'''',1)-1)
                      WHEN 110 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,1)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,1)+2),'''',1)-1)
                      WHEN 111 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,1)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,1)+2),'''',1)-1)
                      WHEN 112 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,1)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,1)+2),'''',1)-1)
                      WHEN 113 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,1)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,1)+2),'''',1)-1)
                      WHEN 114 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,1)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,1)+2),'''',1)-1)
                      WHEN 115 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,1)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,1)+2),'''',1)-1)
                      WHEN 116 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,1)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,1)+2),'''',1)-1)
                      WHEN 117 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,6)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,6)+2),'''',1)-1)
                      WHEN 131 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,9)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,9)+2),'''',1)-1)
                      
                      WHEN 133 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,6)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,6)+2),'''',1)-1)
                      WHEN 134 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,5)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,5)+2),'''',1)-1)                      
                      WHEN 135 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,5)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,5)+2),'''',1)-1)                        
                      WHEN 136 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,5)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,5)+2),'''',1)-1)                        
                      WHEN 137 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,5)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,5)+2),'''',1)-1)                        
                      WHEN 138 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,5)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,5)+2),'''',1)-1)                      
                      WHEN 141 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,1)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,1)+2),'''',1)-1)                        
                      WHEN 142 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,1)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,1)+2),'''',1)-1)                        
                      WHEN 143 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,1)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,1)+2),'''',1)-1)                        
                      WHEN 144 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,1)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,1)+2),'''',1)-1)                        
                      WHEN 145 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,1)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,1)+2),'''',1)-1)                        
                      WHEN 146 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,1)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,1)+2),'''',1)-1)                        
                      WHEN 147 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,1)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,1)+2),'''',1)-1)                        
                      WHEN 148 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,1)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,1)+2),'''',1)-1)                        
                      WHEN 149 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,1)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,1)+2),'''',1)-1)                        
                      WHEN 150 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,1)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,1)+2),'''',1)-1)                        
                      WHEN 151 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,1)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,1)+2),'''',1)-1)                        
                      WHEN 152 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,1)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,1)+2),'''',1)-1)                        
                      WHEN 153 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),'''',1)-1)                        
                      WHEN 154 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),'''',1)-1)
                      WHEN 155 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,1)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,1)+2),'''',1)-1) 
                      WHEN 156 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,8)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,8)+2),'''',1)-1)
                      WHEN 157 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,8)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,8)+2),'''',1)-1)
                      WHEN 158 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,8)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,8)+2),'''',1)-1)
                      
                      WHEN 167 THEN CASE WHEN v_mem_rec.relship_type_id NOT IN ('NSF','YSP') OR v_mem_rec.marital_status_id = 'SNG'  THEN NULL  --changed in CR - 0182
                                    ELSE SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,29)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,29)+2),'''',1)-1) END
                      WHEN 168 THEN CASE WHEN v_mem_rec.relship_type_id NOT IN ('NSF','YSP') OR v_mem_rec.marital_status_id = 'SNG'  THEN NULL  --changed in CR - 0182
                                    ELSE SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,18)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,18)+2),'''',1)-1) END
                      WHEN 169 THEN CASE WHEN v_mem_rec.relship_type_id NOT IN ('NSF','YSP') OR v_mem_rec.marital_status_id = 'SNG'  THEN NULL  --changed in CR - 0182
                                    ELSE SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,18)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,18)+2),'''',1)-1) END
                      WHEN 170 THEN CASE WHEN v_mem_rec.relship_type_id NOT IN ('NSF','YSP') OR v_mem_rec.marital_status_id = 'SNG'  THEN NULL  --changed in CR - 0182
                                    ELSE SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,10)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,10)+2),'''',1)-1) END
                      WHEN 171 THEN CASE WHEN v_mem_rec.relship_type_id NOT IN ('NSF','YSP') OR v_mem_rec.marital_status_id = 'SNG'  THEN NULL  --changed in CR - 0182
                                    ELSE SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,10)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,10)+2),'''',1)-1) END
                      
                      WHEN 196 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,5)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,5)+2),'''',1)-1)      
                      WHEN 197 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,5)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,5)+2),'''',1)-1)      
                      WHEN 198 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,5)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,5)+2),'''',1)-1)      
                      WHEN 200 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,1)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,1)+2),'''',1)-1)      
                      WHEN 201 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,1)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,1)+2),'''',1)-1)      
                      WHEN 202 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,1)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,1)+2),'''',1)-1)      
                      WHEN 203 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,1)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,1)+2),'''',1)-1)      
                      WHEN 204 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,9)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,9)+2),'''',1)-1)      
                      WHEN 205 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,5)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,5)+2),'''',1)-1)      
                      WHEN 206 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,4)+2),'''',1)-1)      
                      WHEN 207 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,8)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,8)+2),'''',1)-1)      
                      WHEN 208 THEN REGEXP_SUBSTR(D.COND_FUN,'[^('')]+',1,2)
                      WHEN 216 THEN substr(D.COND_FUN,instr(D.COND_FUN,',',1,5)+2,(instr(D.COND_FUN,',',1,6) - instr(D.COND_FUN,',',1,5))-3)   
                          
         END AS COPAY_PERC,
         
       CASE CD.COND_SEQ_ID WHEN 4 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,7)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,7)+2),'''',1)-1)
                           WHEN 5 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,17)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,17)+2),'''',1)-1)
                           WHEN 6 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,27)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,27)+2),'''',1)-1)
                           WHEN 7 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,37)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,37)+2),'''',1)-1)
                           WHEN 8 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,47)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,47)+2),'''',1)-1)
                           WHEN 9 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,57)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,57)+2),'''',1)-1)  
                           WHEN 10 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,67)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,67)+2),'''',1)-1)  
                           WHEN 26 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,7)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,7)+2),'''',1)-1)  
                           WHEN 29 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,7)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,7)+2),'''',1)-1)
                           WHEN 30 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,7)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,7)+2),'''',1)-1)
                           WHEN 31 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,7)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,7)+2),'''',1)-1)
                           WHEN 32 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,7)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,7)+2),'''',1)-1)      
                           WHEN 33 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,7)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,7)+2),'''',1)-1)
                           WHEN 34 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,7)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,7)+2),'''',1)-1)
                           WHEN 35 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,7)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,7)+2),'''',1)-1)
                           WHEN 36 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,7)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,7)+2),'''',1)-1)
                           WHEN 37 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,7)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,7)+2),'''',1)-1)
                           WHEN 38 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,7)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,7)+2),'''',1)-1)
                           WHEN 39 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,7)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,7)+2),'''',1)-1)
                           WHEN 68 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,8)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,8)+2),'''',1)-1)
                           WHEN 131 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,10)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,10)+2),'''',1)-1)  
                           
                           WHEN 133 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,7)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,7)+2),'''',1)-1)
                           WHEN 134 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,6)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,6)+2),'''',1)-1)                           
                           WHEN 135 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,6)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,6)+2),'''',1)-1)                             
                           WHEN 136 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,7)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,7)+2),'''',1)-1)                           
                           WHEN 137 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,7)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,7)+2),'''',1)-1)                          
                           WHEN 138 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,7)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,7)+2),'''',1)-1)                              
                           WHEN 156 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,8)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,8)+2),'''',1)-1)                              
                           WHEN 157 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,10)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,10)+2),'''',1)-1)                              
                           WHEN 158 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,10)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,10)+2),'''',1)-1)                              
                           WHEN 196 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,7)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,7)+2),'''',1)-1)
                           WHEN 197 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,7)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,7)+2),'''',1)-1)
                           WHEN 198 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,7)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,7)+2),'''',1)-1)
                           WHEN 205 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,6)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,6)+2),'''',1)-1)
                           WHEN 207 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,8)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,8)+2),'''',1)-1)
                           WHEN 216 THEN SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,7)+2,(INSTR(D.COND_FUN,',',1,8) - INSTR(D.COND_FUN,',',1,7))-3)  
        END AS DEDUCTABLE,
        CASE WHEN CL.CLAUSE_SEQ_ID = 12 AND (v_mem_rec.relship_type_id NOT IN ('NSF','YSP') OR v_mem_rec.marital_status_id = 'SNG' ) THEN 'Not Covered'  --CR-0180 & CR-0182
        ELSE CASE C.COVERAGE_PAY_VAL WHEN 1 THEN 'Pay'
                                     WHEN 2 THEN 'Don''t Pay'
             ELSE 'Pay Conditionally' END END AS RULE_CONFIG,
        
        CD.RULE_BY,
        CD.MASTER_CODE,
        CASE CD.COND_SEQ_ID WHEN 1 THEN CASE WHEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1) IS NOT NULL THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)  ||' '||CASE  REPLACE(REGEXP_SUBSTR(D.COND_FUN,'[^,()]+',1,5),'''') WHEN 'DD' THEN 'Days' WHEN 'MM' THEN 'Months' WHEN 'YY' THEN 'Years' ELSE NULL END END 
                            WHEN 24 THEN CASE WHEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1) IS NOT NULL THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)  ||' '||CASE  REPLACE(REGEXP_SUBSTR(D.COND_FUN,'[^,()]+',1,5),'''') WHEN 'DD' THEN 'Days' WHEN 'MM' THEN 'Months' WHEN 'YY' THEN 'Years' ELSE NULL END  END 
                            WHEN 50 THEN CASE WHEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1) IS NOT NULL THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)  ||' '||CASE  REPLACE(REGEXP_SUBSTR(D.COND_FUN,'[^,()]+',1,5),'''') WHEN 'DD' THEN 'Days' WHEN 'MM' THEN 'Months' WHEN 'YY' THEN 'Years' ELSE NULL END  END 
                            WHEN 51 THEN CASE WHEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1) IS NOT NULL THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)  ||' '||CASE  REPLACE(REGEXP_SUBSTR(D.COND_FUN,'[^,()]+',1,5),'''') WHEN 'DD' THEN 'Days' WHEN 'MM' THEN 'Months' WHEN 'YY' THEN 'Years' ELSE NULL END  END 
                            WHEN 52 THEN CASE WHEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1) IS NOT NULL THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)  ||' '||CASE  REPLACE(REGEXP_SUBSTR(D.COND_FUN,'[^,()]+',1,5),'''') WHEN 'DD' THEN 'Days' WHEN 'MM' THEN 'Months' WHEN 'YY' THEN 'Years' ELSE NULL END  END 
                            WHEN 53 THEN CASE WHEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1) IS NOT NULL THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)  ||' '||CASE  REPLACE(REGEXP_SUBSTR(D.COND_FUN,'[^,()]+',1,5),'''') WHEN 'DD' THEN 'Days' WHEN 'MM' THEN 'Months' WHEN 'YY' THEN 'Years' ELSE NULL END  END 
                            WHEN 54 THEN CASE WHEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1) IS NOT NULL THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)  ||' '||CASE  REPLACE(REGEXP_SUBSTR(D.COND_FUN,'[^,()]+',1,5),'''') WHEN 'DD' THEN 'Days' WHEN 'MM' THEN 'Months' WHEN 'YY' THEN 'Years' ELSE NULL END  END 
                            WHEN 55 THEN CASE WHEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1) IS NOT NULL THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)  ||' '||CASE  REPLACE(REGEXP_SUBSTR(D.COND_FUN,'[^,()]+',1,5),'''') WHEN 'DD' THEN 'Days' WHEN 'MM' THEN 'Months' WHEN 'YY' THEN 'Years' ELSE NULL END  END 
                            WHEN 56 THEN CASE WHEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1) IS NOT NULL THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)  ||' '||CASE  REPLACE(REGEXP_SUBSTR(D.COND_FUN,'[^,()]+',1,5),'''') WHEN 'DD' THEN 'Days' WHEN 'MM' THEN 'Months' WHEN 'YY' THEN 'Years' ELSE NULL END  END 
                            WHEN 57 THEN CASE WHEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1) IS NOT NULL THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)  ||' '||CASE  REPLACE(REGEXP_SUBSTR(D.COND_FUN,'[^,()]+',1,5),'''') WHEN 'DD' THEN 'Days' WHEN 'MM' THEN 'Months' WHEN 'YY' THEN 'Years' ELSE NULL END  END 
                            WHEN 58 THEN CASE WHEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1) IS NOT NULL THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)  ||' '||CASE  REPLACE(REGEXP_SUBSTR(D.COND_FUN,'[^,()]+',1,5),'''') WHEN 'DD' THEN 'Days' WHEN 'MM' THEN 'Months' WHEN 'YY' THEN 'Years' ELSE NULL END  END 
                            WHEN 59 THEN CASE WHEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1) IS NOT NULL THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)  ||' '||CASE  REPLACE(REGEXP_SUBSTR(D.COND_FUN,'[^,()]+',1,5),'''') WHEN 'DD' THEN 'Days' WHEN 'MM' THEN 'Months' WHEN 'YY' THEN 'Years' ELSE NULL END  END 
                            WHEN 60 THEN CASE WHEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1) IS NOT NULL THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)  ||' '||CASE  REPLACE(REGEXP_SUBSTR(D.COND_FUN,'[^,()]+',1,5),'''') WHEN 'DD' THEN 'Days' WHEN 'MM' THEN 'Months' WHEN 'YY' THEN 'Years' ELSE NULL END  END 
                            WHEN 61 THEN CASE WHEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1) IS NOT NULL THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)  ||' '||CASE  REPLACE(REGEXP_SUBSTR(D.COND_FUN,'[^,()]+',1,5),'''') WHEN 'DD' THEN 'Days' WHEN 'MM' THEN 'Months' WHEN 'YY' THEN 'Years' ELSE NULL END  END 
                            WHEN 62 THEN CASE WHEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1) IS NOT NULL THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)  ||' '||CASE  REPLACE(REGEXP_SUBSTR(D.COND_FUN,'[^,()]+',1,5),'''') WHEN 'DD' THEN 'Days' WHEN 'MM' THEN 'Months' WHEN 'YY' THEN 'Years' ELSE NULL END  END 
                            WHEN 63 THEN CASE WHEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1) IS NOT NULL THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)  ||' '||CASE  REPLACE(REGEXP_SUBSTR(D.COND_FUN,'[^,()]+',1,5),'''') WHEN 'DD' THEN 'Days' WHEN 'MM' THEN 'Months' WHEN 'YY' THEN 'Years' ELSE NULL END  END 
                            WHEN 64 THEN CASE WHEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1) IS NOT NULL THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)  ||' '||CASE  REPLACE(REGEXP_SUBSTR(D.COND_FUN,'[^,()]+',1,5),'''') WHEN 'DD' THEN 'Days' WHEN 'MM' THEN 'Months' WHEN 'YY' THEN 'Years' ELSE NULL END  END 
                            WHEN 65 THEN CASE WHEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1) IS NOT NULL THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)  ||' '||CASE  REPLACE(REGEXP_SUBSTR(D.COND_FUN,'[^,()]+',1,5),'''') WHEN 'DD' THEN 'Days' WHEN 'MM' THEN 'Months' WHEN 'YY' THEN 'Years' ELSE NULL END  END 
                            WHEN 66 THEN CASE WHEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1) IS NOT NULL THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)  ||' '||CASE  REPLACE(REGEXP_SUBSTR(D.COND_FUN,'[^,()]+',1,5),'''') WHEN 'DD' THEN 'Days' WHEN 'MM' THEN 'Months' WHEN 'YY' THEN 'Years' ELSE NULL END  END 
                            WHEN 67 THEN CASE WHEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1) IS NOT NULL THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)  ||' '||CASE  REPLACE(REGEXP_SUBSTR(D.COND_FUN,'[^,()]+',1,5),'''') WHEN 'DD' THEN 'Days' WHEN 'MM' THEN 'Months' WHEN 'YY' THEN 'Years' ELSE NULL END  END 
                            WHEN 69 THEN CASE WHEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1) IS NOT NULL THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)  ||' '||CASE  REPLACE(REGEXP_SUBSTR(D.COND_FUN,'[^,()]+',1,5),'''') WHEN 'DD' THEN 'Days' WHEN 'MM' THEN 'Months' WHEN 'YY' THEN 'Years' ELSE NULL END  END 
                            WHEN 70 THEN CASE WHEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1) IS NOT NULL THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)  ||' '||CASE  REPLACE(REGEXP_SUBSTR(D.COND_FUN,'[^,()]+',1,5),'''') WHEN 'DD' THEN 'Days' WHEN 'MM' THEN 'Months' WHEN 'YY' THEN 'Years' ELSE NULL END  END 
                            WHEN 71 THEN CASE WHEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1) IS NOT NULL THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)  ||' '||CASE  REPLACE(REGEXP_SUBSTR(D.COND_FUN,'[^,()]+',1,5),'''') WHEN 'DD' THEN 'Days' WHEN 'MM' THEN 'Months' WHEN 'YY' THEN 'Years' ELSE NULL END  END 
                            WHEN 72 THEN CASE WHEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1) IS NOT NULL THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)  ||' '||CASE  REPLACE(REGEXP_SUBSTR(D.COND_FUN,'[^,()]+',1,5),'''') WHEN 'DD' THEN 'Days' WHEN 'MM' THEN 'Months' WHEN 'YY' THEN 'Years' ELSE NULL END  END 
                            WHEN 73 THEN CASE WHEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1) IS NOT NULL THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)  ||' '||CASE  REPLACE(REGEXP_SUBSTR(D.COND_FUN,'[^,()]+',1,5),'''') WHEN 'DD' THEN 'Days' WHEN 'MM' THEN 'Months' WHEN 'YY' THEN 'Years' ELSE NULL END  END 
                            WHEN 74 THEN CASE WHEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1) IS NOT NULL THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)  ||' '||CASE  REPLACE(REGEXP_SUBSTR(D.COND_FUN,'[^,()]+',1,5),'''') WHEN 'DD' THEN 'Days' WHEN 'MM' THEN 'Months' WHEN 'YY' THEN 'Years' ELSE NULL END  END 
                            WHEN 75 THEN CASE WHEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1) IS NOT NULL THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)  ||' '||CASE  REPLACE(REGEXP_SUBSTR(D.COND_FUN,'[^,()]+',1,5),'''') WHEN 'DD' THEN 'Days' WHEN 'MM' THEN 'Months' WHEN 'YY' THEN 'Years' ELSE NULL END  END 
                            WHEN 76 THEN CASE WHEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1) IS NOT NULL THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)  ||' '||CASE  REPLACE(REGEXP_SUBSTR(D.COND_FUN,'[^,()]+',1,5),'''')WHEN 'DD' THEN 'Days' WHEN 'MM' THEN 'Months' WHEN 'YY' THEN 'Years' ELSE NULL END  END 
                            WHEN 77 THEN CASE WHEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1) IS NOT NULL THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)  ||' '||CASE  REPLACE(REGEXP_SUBSTR(D.COND_FUN,'[^,()]+',1,5),'''') WHEN 'DD' THEN 'Days' WHEN 'MM' THEN 'Months' WHEN 'YY' THEN 'Years' ELSE NULL END  END 
                            WHEN 78 THEN CASE WHEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1) IS NOT NULL THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)  ||' '||CASE  REPLACE(REGEXP_SUBSTR(D.COND_FUN,'[^,()]+',1,5),'''') WHEN 'DD' THEN 'Days' WHEN 'MM' THEN 'Months' WHEN 'YY' THEN 'Years' ELSE NULL END  END 
                            WHEN 79 THEN CASE WHEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1) IS NOT NULL THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)  ||' '||CASE  REPLACE(REGEXP_SUBSTR(D.COND_FUN,'[^,()]+',1,5),'''') WHEN 'DD' THEN 'Days' WHEN 'MM' THEN 'Months' WHEN 'YY' THEN 'Years' ELSE NULL END  END 
                            WHEN 80 THEN CASE WHEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1) IS NOT NULL THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)  ||' '||CASE  REPLACE(REGEXP_SUBSTR(D.COND_FUN,'[^,()]+',1,5),'''') WHEN 'DD' THEN 'Days' WHEN 'MM' THEN 'Months' WHEN 'YY' THEN 'Years' ELSE NULL END  END 
                            WHEN 81 THEN CASE WHEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1) IS NOT NULL THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)  ||' '||CASE  REPLACE(REGEXP_SUBSTR(D.COND_FUN,'[^,()]+',1,5),'''') WHEN 'DD' THEN 'Days' WHEN 'MM' THEN 'Months' WHEN 'YY' THEN 'Years' ELSE NULL END  END 
                            WHEN 82 THEN CASE WHEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1) IS NOT NULL THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)  ||' '||CASE  REPLACE(REGEXP_SUBSTR(D.COND_FUN,'[^,()]+',1,5),'''') WHEN 'DD' THEN 'Days' WHEN 'MM' THEN 'Months' WHEN 'YY' THEN 'Years' ELSE NULL END  END 
                            WHEN 83 THEN CASE WHEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1) IS NOT NULL THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)  ||' '||CASE  REPLACE(REGEXP_SUBSTR(D.COND_FUN,'[^,()]+',1,5),'''') WHEN 'DD' THEN 'Days' WHEN 'MM' THEN 'Months' WHEN 'YY' THEN 'Years' ELSE NULL END  END 
                            WHEN 84 THEN CASE WHEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1) IS NOT NULL THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)  ||' '||CASE  REPLACE(REGEXP_SUBSTR(D.COND_FUN,'[^,()]+',1,5),'''') WHEN 'DD' THEN 'Days' WHEN 'MM' THEN 'Months' WHEN 'YY' THEN 'Years' ELSE NULL END  END 
                            WHEN 85 THEN CASE WHEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1) IS NOT NULL THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)  ||' '||CASE  REPLACE(REGEXP_SUBSTR(D.COND_FUN,'[^,()]+',1,5),'''') WHEN 'DD' THEN 'Days' WHEN 'MM' THEN 'Months' WHEN 'YY' THEN 'Years' ELSE NULL END  END 
                            WHEN 86 THEN CASE WHEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1) IS NOT NULL THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)  ||' '||CASE  REPLACE(REGEXP_SUBSTR(D.COND_FUN,'[^,()]+',1,5),'''') WHEN 'DD' THEN 'Days' WHEN 'MM' THEN 'Months' WHEN 'YY' THEN 'Years' ELSE NULL END  END 
                            WHEN 87 THEN CASE WHEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1) IS NOT NULL THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)  ||' '||CASE  REPLACE(REGEXP_SUBSTR(D.COND_FUN,'[^,()]+',1,5),'''') WHEN 'DD' THEN 'Days' WHEN 'MM' THEN 'Months' WHEN 'YY' THEN 'Years' ELSE NULL END  END 
                            WHEN 88 THEN CASE WHEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,3)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+3),'''',1)-1) IS NOT NULL THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,3)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+3),'''',1)-1)  ||' '||CASE  REPLACE(REGEXP_SUBSTR(D.COND_FUN,'[^,()]+',1,6),'''') WHEN 'DD' THEN 'Days' WHEN 'MM' THEN 'Months' WHEN 'YY' THEN 'Years' ELSE NULL END  END 
                            WHEN 89 THEN CASE WHEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1) IS NOT NULL THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)  ||' '||CASE  REPLACE(REGEXP_SUBSTR(D.COND_FUN,'[^,()]+',1,5),'''') WHEN 'DD' THEN 'Days' WHEN 'MM' THEN 'Months' WHEN 'YY' THEN 'Years' ELSE NULL END  END 
                            WHEN 90 THEN CASE WHEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,3)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,3)+2),'''',1)-1) IS NOT NULL THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,3)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,3)+2),'''',1)-1)  ||' '||CASE  REPLACE(REGEXP_SUBSTR(D.COND_FUN,'[^,()]+',1,6),'''') WHEN 'DD' THEN 'Days' WHEN 'MM' THEN 'Months' WHEN 'YY' THEN 'Years' ELSE NULL END  END 
                            WHEN 91 THEN CASE WHEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1) IS NOT NULL THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)  ||' '||CASE  REPLACE(REGEXP_SUBSTR(D.COND_FUN,'[^,()]+',1,5),'''') WHEN 'DD' THEN 'Days' WHEN 'MM' THEN 'Months' WHEN 'YY' THEN 'Years' ELSE NULL END  END 
                            WHEN 92 THEN CASE WHEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1) IS NOT NULL THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)  ||' '||CASE  REPLACE(REGEXP_SUBSTR(D.COND_FUN,'[^,()]+',1,5),'''') WHEN 'DD' THEN 'Days' WHEN 'MM' THEN 'Months' WHEN 'YY' THEN 'Years' ELSE NULL END  END 
                            WHEN 93 THEN CASE WHEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1) IS NOT NULL THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)  ||' '||CASE  REPLACE(REGEXP_SUBSTR(D.COND_FUN,'[^,()]+',1,5),'''') WHEN 'DD' THEN 'Days' WHEN 'MM' THEN 'Months' WHEN 'YY' THEN 'Years' ELSE NULL END  END 
                            WHEN 94 THEN CASE WHEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1) IS NOT NULL THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)  ||' '||CASE  REPLACE(REGEXP_SUBSTR(D.COND_FUN,'[^,()]+',1,5),'''') WHEN 'DD' THEN 'Days' WHEN 'MM' THEN 'Months' WHEN 'YY' THEN 'Years' ELSE NULL END  END 
                            WHEN 95 THEN CASE WHEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1) IS NOT NULL THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)  ||' '||CASE  REPLACE(REGEXP_SUBSTR(D.COND_FUN,'[^,()]+',1,5),'''') WHEN 'DD' THEN 'Days' WHEN 'MM' THEN 'Months' WHEN 'YY' THEN 'Years' ELSE NULL END  END 
                            WHEN 96 THEN CASE WHEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1) IS NOT NULL THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)  ||' '||CASE  REPLACE(REGEXP_SUBSTR(D.COND_FUN,'[^,()]+',1,5),'''') WHEN 'DD' THEN 'Days' WHEN 'MM' THEN 'Months' WHEN 'YY' THEN 'Years' ELSE NULL END  END 
                            WHEN 97 THEN CASE WHEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1) IS NOT NULL THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)  ||' '||CASE  REPLACE(REGEXP_SUBSTR(D.COND_FUN,'[^,()]+',1,5),'''') WHEN 'DD' THEN 'Days' WHEN 'MM' THEN 'Months' WHEN 'YY' THEN 'Years' ELSE NULL END  END 
                            WHEN 98 THEN CASE WHEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1) IS NOT NULL THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)  ||' '||CASE  REPLACE(REGEXP_SUBSTR(D.COND_FUN,'[^,()]+',1,5),'''') WHEN 'DD' THEN 'Days' WHEN 'MM' THEN 'Months' WHEN 'YY' THEN 'Years' ELSE NULL END  END 
                            WHEN 99 THEN CASE WHEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1) IS NOT NULL THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)  ||' '||CASE  REPLACE(REGEXP_SUBSTR(D.COND_FUN,'[^,()]+',1,5),'''') WHEN 'DD' THEN 'Days' WHEN 'MM' THEN 'Months' WHEN 'YY' THEN 'Years' ELSE NULL END  END 
                            WHEN 100 THEN CASE WHEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1) IS NOT NULL THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)  ||' '||CASE  REPLACE(REGEXP_SUBSTR(D.COND_FUN,'[^,()]+',1,5),'''') WHEN 'DD' THEN 'Days' WHEN 'MM' THEN 'Months' WHEN 'YY' THEN 'Years' ELSE NULL END  END 
                            WHEN 101 THEN CASE WHEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1) IS NOT NULL THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)  ||' '||CASE  REPLACE(REGEXP_SUBSTR(D.COND_FUN,'[^,()]+',1,5),'''') WHEN 'DD' THEN 'Days' WHEN 'MM' THEN 'Months' WHEN 'YY' THEN 'Years' ELSE NULL END  END 
                            WHEN 102 THEN CASE WHEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1) IS NOT NULL THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)  ||' '||CASE  REPLACE(REGEXP_SUBSTR(D.COND_FUN,'[^,()]+',1,5),'''') WHEN 'DD' THEN 'Days' WHEN 'MM' THEN 'Months' WHEN 'YY' THEN 'Years' ELSE NULL END  END 
                            WHEN 103 THEN CASE WHEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1) IS NOT NULL THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)  ||' '||CASE  REPLACE(REGEXP_SUBSTR(D.COND_FUN,'[^,()]+',1,5),'''') WHEN 'DD' THEN 'Days' WHEN 'MM' THEN 'Months' WHEN 'YY' THEN 'Years' ELSE NULL END  END 
                            WHEN 104 THEN CASE WHEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1) IS NOT NULL THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)  ||' '||CASE  REPLACE(REGEXP_SUBSTR(D.COND_FUN,'[^,()]+',1,5),'''') WHEN 'DD' THEN 'Days' WHEN 'MM' THEN 'Months' WHEN 'YY' THEN 'Years' ELSE NULL END  END 
                            WHEN 111 THEN CASE WHEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,5)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,5)+2),'''',1)-1) IS NOT NULL THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,5)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,5)+2),'''',1)-1)  ||' '||CASE  REPLACE(REGEXP_SUBSTR(D.COND_FUN,'[^,()]+',1,8),'''') WHEN 'DD' THEN 'Days' WHEN 'MM' THEN 'Months' WHEN 'YY' THEN 'Years' ELSE NULL END  END 
                            WHEN 112 THEN CASE WHEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,6)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,6)+2),'''',1)-1) IS NOT NULL THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,6)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,6)+2),'''',1)-1)  ||' '||CASE  REPLACE(REGEXP_SUBSTR(D.COND_FUN,'[^,()]+',1,9),'''') WHEN 'DD' THEN 'Days' WHEN 'MM' THEN 'Months' WHEN 'YY' THEN 'Years' ELSE NULL END  END 
                            WHEN 131 THEN CASE WHEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,1)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,1)+2),'''',1)-1) IS NOT NULL THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,1)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,1)+2),'''',1)-1)  ||' '||CASE  REPLACE(REGEXP_SUBSTR(D.COND_FUN,'[^,()]+',1,4),'''') WHEN 'DD' THEN 'Days' WHEN 'MM' THEN 'Months' WHEN 'YY' THEN 'Years' ELSE NULL END  END 
                            WHEN 153 THEN CASE WHEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1) IS NOT NULL THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)  ||' '||CASE  REPLACE(REGEXP_SUBSTR(D.COND_FUN,'[^,()]+',1,5),'''') WHEN 'DD' THEN 'Days' WHEN 'MM' THEN 'Months' WHEN 'YY' THEN 'Years' ELSE NULL END  END 
                            WHEN 207 THEN CASE WHEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1) IS NOT NULL THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,2)+2),'''',1)-1)  ||' '||CASE REPLACE( REGEXP_SUBSTR(D.COND_FUN,'[^,()]+',1,5),'''') WHEN 'DD' THEN 'Days' WHEN 'MM' THEN 'Months' WHEN 'YY' THEN 'Years' ELSE NULL END  END 
                            WHEN 209 THEN CASE WHEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,3)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,3)+2),'''',1)-1) IS NOT NULL THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,3)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,3)+2),'''',1)-1)  ||' '||CASE  REPLACE(REGEXP_SUBSTR(D.COND_FUN,'[^,()]+',1,6),'''') WHEN 'DD' THEN 'Days' WHEN 'MM' THEN 'Months' WHEN 'YY' THEN 'Years' ELSE NULL END  END 
                                                       
        
        END AS WAITING_PERIOD,
        
        CASE CD.COND_SEQ_ID WHEN 154  THEN   SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,5)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,5)+2),'''',1)-1)
                            WHEN 206  THEN   SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,5)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,5)+2),'''',1)-1)
        END AS SESSIONS_BENIFIT,
        
        CASE CD.COND_SEQ_ID WHEN 26  THEN   SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,9)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,9)+2),'''',1)-1)  
                            WHEN 29  THEN   SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,9)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,9)+2),'''',1)-1)  
                            WHEN 30  THEN   SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,9)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,9)+2),'''',1)-1)  
                            WHEN 31  THEN   SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,9)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,9)+2),'''',1)-1)  
                            WHEN 32  THEN   SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,9)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,9)+2),'''',1)-1)  
                            WHEN 33  THEN   SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,9)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,9)+2),'''',1)-1)  
                            WHEN 34  THEN   SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,9)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,9)+2),'''',1)-1)  
                            WHEN 35  THEN   SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,9)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,9)+2),'''',1)-1)  
                            WHEN 36  THEN   SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,9)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,9)+2),'''',1)-1)  
                            WHEN 37  THEN   SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,9)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,9)+2),'''',1)-1)  
                            WHEN 38  THEN   SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,9)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,9)+2),'''',1)-1)  
                            WHEN 39  THEN   SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,9)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,9)+2),'''',1)-1)  
                            WHEN 68  THEN   SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,11)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,11)+2),'''',1)-1)  
                            WHEN 133  THEN   SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,13)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,13)+2),'''',1)-1)  
                            WHEN 134  THEN   SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,14)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,14)+2),'''',1)-1)  
                            WHEN 135  THEN   SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,15)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,15)+2),'''',1)-1)  
                            WHEN 136  THEN   SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,9)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,9)+2),'''',1)-1)  
                            WHEN 137  THEN   SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,9)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,9)+2),'''',1)-1)  
                            WHEN 138  THEN   SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,9)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,9)+2),'''',1)-1)  
                            
                            WHEN 139 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,3)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,3)+2),'''',1)-1)
                            WHEN 211 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,8)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,8)+2),'''',1)-1)
                            WHEN 140 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,5)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,5)+2),'''',1)-1)
                            WHEN 210 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,10)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,10)+2),'''',1)-1)
                             
                            
                            WHEN 154  THEN   SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,6)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,6)+2),'''',1)-1)  
                            WHEN 156  THEN   SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,13)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,13)+2),'''',1)-1)  
                            WHEN 157  THEN   SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,13)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,13)+2),'''',1)-1)   
                            WHEN 158  THEN   SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,13)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,13)+2),'''',1)-1)   
                            
                            WHEN 159 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,7)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,7)+2),'''',1)-1)
                            WHEN 212 THEN SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,3)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,3)+2),'''',1)-1)
                            
                            WHEN 167 THEN CASE WHEN v_mem_rec.relship_type_id NOT IN ('NSF','YSP') OR v_mem_rec.marital_status_id = 'SNG'  THEN NULL  --changed in CR - 0182
                                          ELSE SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,26)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,26)+2),'''',1)-1) END
                            WHEN 168 THEN CASE WHEN v_mem_rec.relship_type_id NOT IN ('NSF','YSP') OR v_mem_rec.marital_status_id = 'SNG'  THEN NULL  --changed in CR - 0182
                                          ELSE SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,15)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,15)+2),'''',1)-1) END
                            WHEN 169 THEN CASE WHEN v_mem_rec.relship_type_id NOT IN ('NSF','YSP') OR v_mem_rec.marital_status_id = 'SNG'  THEN NULL  --changed in CR - 0182
                                          ELSE SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,15)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,15)+2),'''',1)-1) END
                            WHEN 170 THEN CASE WHEN v_mem_rec.relship_type_id NOT IN ('NSF','YSP') OR v_mem_rec.marital_status_id = 'SNG'  THEN NULL  --changed in CR - 0182
                                          ELSE SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,38)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,38)+2),'''',1)-1) END
                            WHEN 171 THEN CASE WHEN v_mem_rec.relship_type_id NOT IN ('NSF','YSP') OR v_mem_rec.marital_status_id = 'SNG'  THEN NULL  --changed in CR - 0182
                                          ELSE SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,38)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,38)+2),'''',1)-1) END
                              
                            WHEN 196  THEN   SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,9)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,9)+2),'''',1)-1)       
                            WHEN 197  THEN   SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,9)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,9)+2),'''',1)-1)       
                            WHEN 198  THEN   SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,9)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,9)+2),'''',1)-1)       
                            WHEN 204  THEN   SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,7)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,7)+2),'''',1)-1)       
                            WHEN 205  THEN   SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,15)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,15)+2),'''',1)-1)       
                            WHEN 206  THEN   SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,6)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,6)+2),'''',1)-1)
                            WHEN 207  THEN   SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,13)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,13)+2),'''',1)-1)       
                            WHEN 209  THEN   SUBSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,8)+2),1,INSTR(SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',1,8)+2),'''',1)-1)       
                            WHEN 216  THEN   SUBSTR(D.COND_FUN,INSTR(D.COND_FUN,',',-1,1)+2,2)
        END AS MODE_OF_BENIFIT,
        cd.sort_no as cond_sl_no
     
FROM tpa_ins_prod_pol_clauses B
JOIN tpa_ins_prod_pol_coverages C  ON (b.clause_seq_id = c.clause_seq_id)
JOIN tpa_ins_prod_pol_conditions D ON (c.coverage_seq_id = d.coverage_seq_id)  
JOIN APP.TPA_RULE_CONDITION_MSTR CD ON (CD.COND_ID=D.COND_ID)
JOIN APP.TPA_RULE_COVERAGE_MSTR CV ON (CD.COVRG_SEQ_ID=CV.COVRG_SEQ_ID)
JOIN APP.TPA_RULE_CLAUSE_MSTR CL ON (CL.CLAUSE_SEQ_ID=CV.CLAUSE_SEQ_ID)
where B.prod_policy_rule_seq_id=rec_rule_seq_id.prod_policy_rule_seq_id
AND CD.DISPLAY_YN = 'Y'
)
SELECT R.COND_SEQ_ID,
       R.CLAUSE_NAME,
       R.COND_NAME,
       R.RULE_CONFIG,
       R.RULE_BY,
       R.MASTER_CODE,
       R.LIMIT,
       CASE WHEN R.COND_SEQ_ID IN (167,168,169,170,171) AND (v_mem_rec.relship_type_id NOT IN ('NSF','YSP') OR v_mem_rec.marital_status_id = 'SNG' )THEN NULL  --changed in CR - 0182
       ELSE DISPLAY_OF_BENEFITS.get_utlized_amnt(v_member_seq_id,v_seq_id,R.COND_SEQ_ID,R.MASTER_CODE,R.RULE_BY,v_module_flag,NULL) END AS UTILIZED_AMNT,
       CASE WHEN R.COND_SEQ_ID IN (167,168,169,170,171) AND (v_mem_rec.relship_type_id NOT IN ('NSF','YSP') OR v_mem_rec.marital_status_id = 'SNG' ) THEN NULL  --changed in CR - 0182
       ELSE CASE /*WHEN MODE_OF_BENIFIT = 'PC' AND R.MASTER_CODE = 'D0150' AND R.RULE_BY = 'DNT' THEN
                                           TO_CHAR(CASE WHEN (R.LIMIT - DISPLAY_OF_BENEFITS.get_utlized_amnt(v_member_seq_id,v_seq_id,R.COND_SEQ_ID,R.MASTER_CODE,R.RULE_BY,v_module_flag,'PC')) >= 0 THEN
                                                             (R.LIMIT - DISPLAY_OF_BENEFITS.get_utlized_amnt(v_member_seq_id,v_seq_id,R.COND_SEQ_ID,R.MASTER_CODE,R.RULE_BY,v_module_flag,'PC')) 
                                                        ELSE 0 END)
            */WHEN MODE_OF_BENIFIT = 'PC' THEN TO_CHAR(R.LIMIT)
            WHEN MODE_OF_BENIFIT = 'PP' THEN TO_CHAR(CASE WHEN (R.LIMIT - DISPLAY_OF_BENEFITS.get_utlized_amnt(v_member_seq_id,v_seq_id,R.COND_SEQ_ID,R.MASTER_CODE,R.RULE_BY,v_module_flag,NULL)) >= 0 THEN
                                                             (R.LIMIT - DISPLAY_OF_BENEFITS.get_utlized_amnt(v_member_seq_id,v_seq_id,R.COND_SEQ_ID,R.MASTER_CODE,R.RULE_BY,v_module_flag,NULL)) 
                                                         WHEN DISPLAY_OF_BENEFITS.get_utlized_amnt(v_member_seq_id,v_seq_id,R.COND_SEQ_ID,R.MASTER_CODE,R.RULE_BY,v_module_flag,NULL) IS NULL THEN 
                                                             TO_NUMBER(R.LIMIT)
                                                         WHEN R.LIMIT IS NULL THEN NULL
                                                          ELSE 0 END)
                              ELSE TO_CHAR(R.LIMIT) END END AS BALNC_AMNT,
       R.COPAY_PERC,
       R.DEDUCTABLE,
       WAITING_PERIOD,
       SESSIONS_BENIFIT,
       CASE WHEN MODE_OF_BENIFIT = 'PC' THEN 'Per Claim' 
            WHEN MODE_OF_BENIFIT = 'PP' THEN 'Per Policy Period' 
            WHEN MODE_OF_BENIFIT = 'PD' AND R.COND_SEQ_ID IN (154,206) THEN 'Per Diagnosis'  
            WHEN MODE_OF_BENIFIT = 'PD' THEN 'Per Day' END AS MODE_OF_BENIFIT
FROM RULE_DATA R
ORDER BY R.CLAUSE_NAME,R.cond_sl_no;
END IF;
 
   OPEN v_policy_details for 
    SELECT a.policy_number,
           c.tpa_enrollment_id,
           e.product_cat_type_id,
           to_char(a.policy_issue_date,'dd/mm/yyyy') policy_issue_date,
           to_char(a.effective_from_date,'dd/mm/yyyy') effective_from_date,
           to_char(a.effective_to_date,'dd/mm/yyyy') effective_to_date,
           eb.sum_insured  sum_insured,
           nvl(eb.utilised_sum_insured,0) utilised_sum_insured,
           eb.sum_insured - nvl(eb.utilised_sum_insured,0) as available_sum_insured
     FROM APP.tpa_enr_policy A 
     JOIN APP.tpa_ins_product e ON (a.product_seq_id=e.product_seq_id)
     JOIN APP.tpa_enr_policy_group B ON (a.policy_seq_id=b.policy_seq_id)
     JOIN APP.tpa_enr_policy_member c ON (b.policy_group_seq_id = c.policy_group_seq_id)
     JOIN APP.tpa_enr_balance eb  ON (eb.policy_group_seq_id = B.policy_group_seq_id)
      WHERE c.member_seq_id = v_member_seq_id
       AND (C.mem_general_type_id != 'PFL' 
       AND C.member_seq_id = eb.member_seq_id OR eb.member_seq_id IS NULL OR C.member_seq_id IS NULL);
      
      
      
       
 END get_policy_tob;                         
------------------------------------------------------------------------------------------------------
FUNCTION get_utlized_amnt (v_member_seq_id            IN tpa_enr_policy_member.member_seq_id%TYPE,
                           v_seq_id                   IN NUMBER,
                           v_cond_seq_id              IN app.tpa_rule_condition_mstr.cond_seq_id%TYPE,
                           v_mstr_code                IN tpa_activity_master_details.master_activity_code%TYPE,
                           v_mstr_code_flag           IN VARCHAR2,
                           v_module_flag              IN VARCHAR2,
                           v_benefit_flag             IN VARCHAR2)
 RETURN NUMBER


 IS
-------********1********------
 CURSOR per_policy_act_cur IS
  SELECT SUM(utilised_amount)
     FROM (
       (SELECT NVL(SUM(nvl(s.used_amount, r.used_amount)),0) AS utilised_amount FROM
         ( SELECT b.approved_amount AS used_amount, b.Pat_Auth_Seq_Id, a.claim_seq_id  -----PROD FIXING 
               FROM pat_authorization_details a
               LEFT OUTER JOIN app.clm_authorization_details x on (a.pat_auth_seq_id = x.pat_auth_seq_id) -----PROD FIXING 
               JOIN pat_activity_details b ON (a.pat_auth_seq_id = b.pat_auth_seq_id AND A.pat_status_type_id != 'PCN' AND A.pat_status_type_id != 'REJ' )
               JOIN tpa_activity_details G ON (b.code = g.activity_code)
               WHERE A.Member_Seq_Id = v_member_seq_id 
               AND A.PAT_ENHANCED_YN = 'N'    -----NEWLY ADDED FOR PREAUTH ENHANCEMENT
               AND g.master_activity_code = v_mstr_code
               AND (a.claim_seq_id IS NULL OR (a.claim_seq_id IS NOT NULL AND x.clm_status_type_id IN ('INP', 'REQ') AND NVL(a.claim_seq_id, 0) != NVL(v_seq_id, 0)))-- Fixing for used amount
               ) r
          FULL OUTER JOIN
           ( SELECT b.approved_amount AS used_amount, a.claim_seq_id,A.Pat_Auth_Seq_Id   -----PROD FIXING 
               FROM clm_authorization_details A 
               JOIN pat_activity_details b ON (a.claim_seq_id = b.claim_seq_id AND A.CLM_STATUS_TYPE_ID != 'PCN' AND A.CLM_STATUS_TYPE_ID != 'REJ' )  -----PROD FIXING 
               JOIN tpa_activity_details G ON (b.code = g.activity_code)
               WHERE A.Member_Seq_Id = v_member_seq_id  
               AND g.master_activity_code = v_mstr_code
               AND (A.PAT_AUTH_SEQ_ID IS NULL OR (A.PAT_AUTH_SEQ_ID IS NOT NULL AND A.clm_status_type_id = 'APR'))
               ) s
               ON ( r.claim_seq_id = s.claim_seq_id )
      WHERE ( v_module_flag = 'P' AND NVL(r.Pat_Auth_Seq_Id,0) != NVL(v_seq_id,0) AND NVL(S.Pat_Auth_Seq_Id,0) != NVL(v_seq_id,0)
               OR  v_module_flag = 'C' AND NVL(s.claim_seq_id,0) != v_seq_id 
               OR  v_module_flag = 'A'))
   UNION ALL 
        --====  Changed
      (SELECT NVL(SUM(nvl(s.used_amount, r.used_amount)),0) AS utilised_amount FROM
         ( SELECT b.approved_amount AS used_amount, b.Pat_Auth_Seq_Id, a.claim_seq_id  -----PROD FIXING 
               FROM pat_authorization_details a
               LEFT OUTER JOIN app.clm_authorization_details x on (a.pat_auth_seq_id = x.pat_auth_seq_id) -----PROD FIXING 
               JOIN pat_activity_details b ON (a.pat_auth_seq_id = b.pat_auth_seq_id AND A.pat_status_type_id != 'PCN' AND A.pat_status_type_id != 'REJ' )
               JOIN tpa_activity_details G ON (b.code = g.activity_code)
               WHERE A.Member_Seq_Id = v_member_seq_id 
               AND A.PAT_ENHANCED_YN = 'N'    -----NEWLY ADDED FOR PREAUTH ENHANCEMENT
               AND g.master_activity_code = v_mstr_code AND A.PAT_STATUS_TYPE_ID = 'APR'
               AND (a.claim_seq_id IS NULL OR (x.clm_status_type_id IN ('INP', 'REQ') AND NVL(a.claim_seq_id, 0) != NVL(v_seq_id, 0)))-- Fixing for used amount
               AND v_module_flag != 'A'
               ) r
          FULL OUTER JOIN
           ( SELECT b.approved_amount AS used_amount, a.claim_seq_id,A.Pat_Auth_Seq_Id   -----PROD FIXING 
               FROM clm_authorization_details A 
               JOIN pat_activity_details b ON (a.claim_seq_id = b.claim_seq_id AND A.CLM_STATUS_TYPE_ID != 'PCN' AND A.CLM_STATUS_TYPE_ID != 'REJ' )  -----PROD FIXING 
               JOIN tpa_activity_details G ON (b.code = g.activity_code)
               WHERE A.Member_Seq_Id = v_member_seq_id  
               AND g.master_activity_code = v_mstr_code
               AND A.clm_status_type_id = 'APR'-- Fixing for used amount
               AND v_module_flag != 'A'
               ) s
               ON ( r.claim_seq_id = s.claim_seq_id )
      WHERE (v_module_flag = 'P' AND NVL(r.Pat_Auth_Seq_Id, 0) = NVL(v_seq_id,0) OR NVL(S.Pat_Auth_Seq_Id,0) = NVL(v_seq_id,0)
                   OR  v_module_flag = 'C' AND NVL(s.claim_seq_id, r.claim_seq_id) = NVL(v_seq_id, 0)
                   OR  v_module_flag = 'A')));

--------*********2**************
 CURSOR per_policy_icd_cur IS
  SELECT SUM(utilised_amount)
   FROM (
  SELECT NVL(SUM(nvl(s.used_amount, r.used_amount)),0) AS utilised_amount FROM
         ( SELECT A.Tot_Allowed_Amount AS used_amount, A.Pat_Auth_Seq_Id, a.claim_seq_id 
           FROM pat_authorization_details a 
           LEFT OUTER JOIN app.clm_authorization_details x on (a.pat_auth_seq_id = x.pat_auth_seq_id) -----PROD FIXING 
            where a.pat_auth_seq_id IN
              (SELECT DISTINCT a.pat_auth_seq_id 
               FROM pat_authorization_details a
               LEFT OUTER JOIN app.clm_authorization_details x on (a.pat_auth_seq_id = x.pat_auth_seq_id) -----ADDED
               JOIN diagnosys_details b ON (a.pat_auth_seq_id = b.pat_auth_seq_id AND A.pat_status_type_id != 'PCN' AND A.pat_status_type_id != 'REJ' )
               JOIN tpa_icd_codes G ON (b.diagnosys_code = g.icd_code)
               WHERE A.Member_Seq_Id = v_member_seq_id 
               AND A.PAT_ENHANCED_YN = 'N'    -----NEWLY ADDED FOR PREAUTH ENHANCEMENT
               AND G.MASTER_ICD_CODE = v_mstr_code
               AND (a.claim_seq_id IS NULL OR (a.claim_seq_id IS NOT NULL AND x.clm_status_type_id IN ('INP', 'REQ') AND NVL(a.claim_seq_id, 0) != NVL(v_seq_id, 0)))-- Fixing for used amount
               )) r
        FULL OUTER JOIN
           ( SELECT A.Tot_Allowed_Amount AS used_amount, a.claim_seq_id,A.Pat_Auth_Seq_Id   -----PROD FIXING 
               FROM clm_authorization_details A 
               where a.claim_seq_id IN
              (SELECT DISTINCT a.claim_seq_id
              FROM clm_authorization_details A 
               JOIN diagnosys_details b ON (a.claim_seq_id = b.claim_seq_id AND A.CLM_STATUS_TYPE_ID != 'PCN' AND A.CLM_STATUS_TYPE_ID != 'REJ' )
               JOIN tpa_icd_codes G ON (b.diagnosys_code = g.icd_code)
               WHERE A.Member_Seq_Id = v_member_seq_id  
               AND G.MASTER_ICD_CODE = v_mstr_code
               AND (A.PAT_AUTH_SEQ_ID IS NULL OR (A.PAT_AUTH_SEQ_ID IS NOT NULL AND A.clm_status_type_id = 'APR'))
               )) s
               ON ( r.claim_seq_id = s.claim_seq_id )
               WHERE ( v_module_flag = 'P' AND NVL(r.Pat_Auth_Seq_Id,0) != NVL(v_seq_id,0) AND NVL(S.Pat_Auth_Seq_Id,0) != NVL(v_seq_id,0)
                   OR  v_module_flag = 'C' AND NVL(s.claim_seq_id,0) != NVL(v_seq_id, 0) 
                   OR  v_module_flag = 'A')
      UNION ALL --=== Chabged
      
        (SELECT NVL(SUM(nvl(s.used_amount, r.used_amount)),0) AS utilised_amount FROM
         ( SELECT A.Tot_Allowed_Amount AS used_amount , A.Pat_Auth_Seq_Id, a.claim_seq_id 
           FROM pat_authorization_details a 
           where a.pat_auth_seq_id IN
              (SELECT DISTINCT a.pat_auth_seq_id 
               FROM pat_authorization_details a
               LEFT OUTER JOIN app.clm_authorization_details x on (a.pat_auth_seq_id = x.pat_auth_seq_id) -----PROD FIXING 
               JOIN diagnosys_details b ON (a.pat_auth_seq_id = b.pat_auth_seq_id AND A.pat_status_type_id != 'PCN' AND A.pat_status_type_id != 'REJ' )
               JOIN tpa_icd_codes G ON (b.diagnosys_code = g.icd_code)
               WHERE A.Member_Seq_Id = v_member_seq_id 
               AND G.MASTER_ICD_CODE = v_mstr_code
               AND A.PAT_STATUS_TYPE_ID = 'APR'
               AND (a.claim_seq_id IS NULL OR (x.clm_status_type_id IN ('INP', 'REQ') AND NVL(a.claim_seq_id, 0) != NVL(v_seq_id, 0)))-- Fixing for used amount
               AND v_module_flag != 'A'
               )) r
          FULL OUTER JOIN
           ( SELECT CASE WHEN A.CLM_STATUS_TYPE_ID IN ('APR') THEN (A.Tot_Allowed_Amount)ELSE NULL END AS used_amount , a.claim_seq_id,A.Pat_Auth_Seq_Id
               FROM clm_authorization_details A 
               where a.claim_seq_id IN
              (SELECT DISTINCT a.claim_seq_id
               FROM clm_authorization_details A 
               JOIN diagnosys_details b ON (a.claim_seq_id = b.claim_seq_id AND A.CLM_STATUS_TYPE_ID != 'PCN' AND A.CLM_STATUS_TYPE_ID != 'REJ' )
               JOIN tpa_icd_codes G ON (b.diagnosys_code = g.icd_code)
               WHERE A.Member_Seq_Id = v_member_seq_id  
               AND G.MASTER_ICD_CODE = v_mstr_code
               AND A.clm_status_type_id = 'APR'
               AND v_module_flag != 'A'
               )) s
               ON ( r.claim_seq_id = s.claim_seq_id )
               WHERE (v_module_flag = 'P' AND NVL(r.Pat_Auth_Seq_Id, 0) = NVL(v_seq_id,0) OR NVL(S.Pat_Auth_Seq_Id,0) = NVL(v_seq_id,0)
                   OR  v_module_flag = 'C' AND NVL(s.claim_seq_id,0) = NVL(v_seq_id, 0) 
                   OR  v_module_flag = 'A')));

---------*****************3********
CURSOR per_policy_icd_cur_chronic 
  IS    
   SELECT SUM(utilised_amount)
   FROM (    
    (SELECT NVL(SUM(nvl(s.used_amount, r.used_amount)),0) AS utilised_amount FROM
           ( SELECT A.Tot_Allowed_Amount AS used_amount, A.Pat_Auth_Seq_Id, a.claim_seq_id 
             FROM pat_authorization_details a 
              where a.pat_auth_seq_id IN
                (SELECT DISTINCT a.pat_auth_seq_id 
                 FROM pat_authorization_details a
                 LEFT OUTER JOIN app.clm_authorization_details x on (a.pat_auth_seq_id = x.pat_auth_seq_id) -----PROD FIXING 
                 JOIN diagnosys_details b ON (a.pat_auth_seq_id = b.pat_auth_seq_id AND A.pat_status_type_id != 'PCN' AND A.pat_status_type_id != 'REJ' )
                 JOIN APP.Tpa_Day_Care_Icd G ON (b.diagnosys_code = g.icd_code)
                 WHERE A.Member_Seq_Id = v_member_seq_id 
                 AND A.PAT_ENHANCED_YN = 'N'    -----NEWLY ADDED FOR PREAUTH ENHANCEMENT
                 AND g.day_care_icd_group_id = v_mstr_code
                 AND (a.claim_seq_id IS NULL OR (a.claim_seq_id IS NOT NULL AND x.clm_status_type_id IN ('INP', 'REQ') AND NVL(a.claim_seq_id, 0) != NVL(v_seq_id, 0)))-- Fixing for used amount
                 ) )r
            FULL OUTER JOIN
             ( SELECT A.Tot_Allowed_Amount AS used_amount, a.claim_seq_id,A.Pat_Auth_Seq_Id    -----PROD FIXING 
                 FROM clm_authorization_details A 
                 where a.claim_seq_id IN
                (SELECT DISTINCT a.claim_seq_id
                FROM clm_authorization_details A 
                 JOIN diagnosys_details b ON (a.claim_seq_id = b.claim_seq_id AND A.CLM_STATUS_TYPE_ID != 'PCN' AND A.CLM_STATUS_TYPE_ID != 'REJ' )
                 JOIN APP.Tpa_Day_Care_Icd G ON (b.diagnosys_code = g.icd_code)
                 WHERE A.Member_Seq_Id = v_member_seq_id  
                 AND g.day_care_icd_group_id = v_mstr_code 
                 AND (A.PAT_AUTH_SEQ_ID IS NULL OR (A.PAT_AUTH_SEQ_ID IS NOT NULL AND A.clm_status_type_id = 'APR'))
                 )) S
                 ON ( r.claim_seq_id = s.claim_seq_id )
                 WHERE ( v_module_flag = 'P' AND NVL(r.Pat_Auth_Seq_Id,0) != NVL(v_seq_id,0) AND NVL(S.Pat_Auth_Seq_Id,0) != NVL(v_seq_id,0)
                     OR  v_module_flag = 'C' AND NVL(s.claim_seq_id,0) != NVL(v_seq_id, 0) 
                     OR  v_module_flag = 'A'))
       UNION ALL -- Changed
           
           (SELECT NVL(SUM(nvl(s.used_amount, r.used_amount)),0) AS utilised_amount FROM
           ( SELECT CASE WHEN A.PAT_STATUS_TYPE_ID IN ('APR') THEN  (A.Tot_Allowed_Amount) ELSE NULL END  AS used_amount , A.Pat_Auth_Seq_Id, a.claim_seq_id 
             FROM pat_authorization_details a
              where a.pat_auth_seq_id IN
                (SELECT DISTINCT a.pat_auth_seq_id 
                 FROM pat_authorization_details a
                 LEFT OUTER JOIN app.clm_authorization_details x on (a.pat_auth_seq_id = x.pat_auth_seq_id) -----PROD FIXING
                 LEFT OUTER JOIN app.clm_authorization_details x on (a.pat_auth_seq_id = x.pat_auth_seq_id) -----PROD FIXING
                 JOIN diagnosys_details b ON (a.pat_auth_seq_id = b.pat_auth_seq_id AND A.pat_status_type_id != 'PCN' AND A.pat_status_type_id != 'REJ' )
                 JOIN APP.Tpa_Day_Care_Icd G ON (b.diagnosys_code = g.icd_code)
                 WHERE A.Member_Seq_Id = v_member_seq_id 
                 AND g.day_care_icd_group_id = v_mstr_code
                 AND A.PAT_STATUS_TYPE_ID = 'APR'
                 AND (a.claim_seq_id IS NULL OR (x.clm_status_type_id IN ('INP', 'REQ') AND NVL(a.claim_seq_id, 0) != NVL(v_seq_id, 0)))-- Fixing for used amount
                 AND v_module_flag != 'A'
                 )) r
            FULL OUTER JOIN
             ( SELECT CASE WHEN A.CLM_STATUS_TYPE_ID IN ('APR') THEN A.Tot_Allowed_Amount ELSE NULL END  AS used_amount , a.claim_seq_id,A.Pat_Auth_Seq_Id
                 FROM clm_authorization_details A 
                 where a.claim_seq_id IN
                (SELECT DISTINCT a.claim_seq_id
                FROM clm_authorization_details A 
                 JOIN diagnosys_details b ON (a.claim_seq_id = b.claim_seq_id AND A.CLM_STATUS_TYPE_ID != 'PCN' AND A.CLM_STATUS_TYPE_ID != 'REJ' )
                 JOIN APP.Tpa_Day_Care_Icd G ON (b.diagnosys_code = g.icd_code)
                 WHERE A.Member_Seq_Id = v_member_seq_id  
                 AND g.day_care_icd_group_id = v_mstr_code 
                 AND A.clm_status_type_id = 'APR'
                 AND v_module_flag != 'A'
                 )) S
                 ON ( r.claim_seq_id = s.claim_seq_id )
                 WHERE (v_module_flag = 'P' AND NVL(r.Pat_Auth_Seq_Id, 0) = NVL(v_seq_id,0) OR NVL(S.Pat_Auth_Seq_Id,0) = NVL(v_seq_id,0)
                     OR  v_module_flag = 'C' AND NVL(s.claim_seq_id,0) = NVL(v_seq_id, 0) 
                     OR  v_module_flag = 'A')));
                   
-------********4                   
  CURSOR per_policy_ovral_area_cur IS
       SELECT NVL(SUM(nvl(s.used_amount, r.used_amount)),0) FROM
         ( SELECT CASE WHEN  a.claim_seq_id IS NOT NULL AND x.clm_status_type_id in ('INP','REQ') THEN  
                  A.Tot_Allowed_Amount 
                  ELSE CASE WHEN NVL(A.CLAIM_SEQ_ID,0) = 0 THEN A.Tot_Allowed_Amount END
                  END AS used_amount/*(a.tot_allowed_amount) AS used_amount */, a.Pat_Auth_Seq_Id, a.claim_seq_id  -----PROD FIXING 
               FROM pat_authorization_details a
                LEFT OUTER JOIN app.clm_authorization_details x on (a.pat_auth_seq_id = x.pat_auth_seq_id) -----PROD FIXING 
               WHERE A.Member_Seq_Id = v_member_seq_id 
                 AND A.PAT_ENHANCED_YN = 'N'    -----NEWLY ADDED FOR PREAUTH ENHANCEMENT
                 AND a.out_area_cover_yn = 'Y'
              --   AND a.claim_seq_id IS NULL  -----PROD FIXING 
               ) r
          FULL OUTER JOIN
           ( SELECT CASE WHEN A.PAT_AUTH_SEQ_ID IS NOT NULL AND A.clm_status_type_id IN ('INP','REQ') THEN NULL
                    ELSE CASE WHEN NVL(A.PAT_AUTH_SEQ_ID,0) = 0 THEN A.FINAL_APP_AMOUNT 
                             WHEN A.PAT_AUTH_SEQ_ID IS NOT NULL AND A.clm_status_type_id IN ('APR') THEN  A.FINAL_APP_AMOUNT  END
                    END AS used_amount/*(A.FINAL_APP_AMOUNT) AS used_amount*/ , a.claim_seq_id,A.Pat_Auth_Seq_Id  -----PROD FIXING 
               FROM clm_authorization_details A 
               WHERE A.Member_Seq_Id = v_member_seq_id  
                 AND a.out_area_cover_yn = 'Y'
               ) s
               ON ( r.claim_seq_id = s.claim_seq_id )
               WHERE ( v_module_flag = 'P' AND NVL(r.Pat_Auth_Seq_Id,0) != NVL(v_seq_id,0) AND NVL(S.Pat_Auth_Seq_Id,0) != NVL(v_seq_id,0)
                   OR  v_module_flag = 'C' AND NVL(s.claim_seq_id,0) != v_seq_id 
                   OR  v_module_flag = 'A');
                                    
  ------*******5********
   
  CURSOR per_policy_benf_area_cur(v_benifit_type  VARCHAR2) IS
   SELECT SUM(utilised_amount)
  FROM 
     (
       (SELECT NVL(SUM(nvl(s.used_amount, r.used_amount)),0) AS utilised_amount FROM
         ( SELECT CASE WHEN  a.claim_seq_id IS NOT NULL AND x.clm_status_type_id in ('INP','REQ') THEN  
                  a.tot_allowed_amount 
                  ELSE CASE WHEN NVL(A.CLAIM_SEQ_ID,0) = 0 THEN a.tot_allowed_amount END
                  END AS used_amount/*(a.tot_allowed_amount) AS used_amount*/ , a.Pat_Auth_Seq_Id, a.claim_seq_id   -----PROD FIXING 
               FROM pat_authorization_details a
                LEFT OUTER JOIN app.clm_authorization_details x on (a.pat_auth_seq_id = x.pat_auth_seq_id) -----PROD FIXING 
               WHERE A.Member_Seq_Id = v_member_seq_id 
                 AND A.PAT_ENHANCED_YN = 'N'    -----NEWLY ADDED FOR PREAUTH ENHANCEMENT
                 AND a.out_area_cover_yn = 'Y'
                 AND a.benifit_type = v_benifit_type
                -- AND a.claim_seq_id IS NULL    -----PROD FIXING 
               ) r
          FULL OUTER JOIN
           ( SELECT CASE WHEN A.PAT_AUTH_SEQ_ID IS NOT NULL AND A.clm_status_type_id IN ('INP','REQ') THEN NULL
                    ELSE CASE WHEN NVL(A.PAT_AUTH_SEQ_ID,0) = 0 THEN A.FINAL_APP_AMOUNT 
                             WHEN A.PAT_AUTH_SEQ_ID IS NOT NULL AND A.clm_status_type_id IN ('APR') THEN  A.FINAL_APP_AMOUNT  END
                    END AS used_amount /*(A.FINAL_APP_AMOUNT) AS used_amount*/ , a.claim_seq_id,A.Pat_Auth_Seq_Id   -----PROD FIXING 
               FROM clm_authorization_details A 
               WHERE A.Member_Seq_Id = v_member_seq_id  
                 AND a.out_area_cover_yn = 'Y'
                 AND a.benifit_type = v_benifit_type
               ) s
               ON ( r.claim_seq_id = s.claim_seq_id )
               WHERE ( v_module_flag = 'P' AND NVL(r.Pat_Auth_Seq_Id,0) != NVL(v_seq_id,0) AND NVL(S.Pat_Auth_Seq_Id,0) != NVL(v_seq_id,0)
                   OR  v_module_flag = 'C' AND NVL(s.claim_seq_id,0) != v_seq_id 
                   OR  v_module_flag = 'A'))
                   
        UNION ALL
        
        (SELECT NVL(SUM(nvl(s.used_amount, r.used_amount)),0) AS utilised_amount FROM
         ( SELECT CASE WHEN A.PAT_STATUS_TYPE_ID IN ('APR') THEN  (a.tot_allowed_amount) ELSE NULL END  AS used_amount , a.Pat_Auth_Seq_Id, a.claim_seq_id 
               FROM pat_authorization_details a
               WHERE A.Member_Seq_Id = v_member_seq_id 
                 AND a.out_area_cover_yn = 'Y'
                 AND a.benifit_type = v_benifit_type
              ---   AND a.claim_seq_id IS NULL
               ) r
          FULL OUTER JOIN
           ( SELECT CASE WHEN  A.CLM_STATUS_TYPE_ID IN ('APR') THEN (A.FINAL_APP_AMOUNT) ELSE NULL END AS used_amount , a.claim_seq_id,A.Pat_Auth_Seq_Id
               FROM clm_authorization_details A 
               WHERE A.Member_Seq_Id = v_member_seq_id  
                 AND a.out_area_cover_yn = 'Y'
                 AND a.benifit_type = v_benifit_type
               ) s
               ON ( r.claim_seq_id = s.claim_seq_id )
               WHERE ( v_module_flag = 'P' AND NVL(r.Pat_Auth_Seq_Id,0) = NVL(v_seq_id,0)---- AND NVL(S.Pat_Auth_Seq_Id,0) != NVL(v_seq_id,0)
                   OR  v_module_flag = 'C' AND NVL(s.claim_seq_id,0) = v_seq_id 
                   OR  v_module_flag = 'A')));
                   
------******6*******------                   


  CURSOR per_policy_benf_utliz_cur(v_benifit_type  VARCHAR2) IS
    SELECT SUM(utilised_amount)
     FROM 
      (       
       (SELECT NVL(SUM(nvl(s.used_amount, r.used_amount)),0) AS utilised_amount FROM
         ( SELECT CASE WHEN  a.claim_seq_id IS NOT NULL AND x.clm_status_type_id in ('INP','REQ') THEN  
                  a.tot_allowed_amount 
                  ELSE CASE WHEN NVL(A.CLAIM_SEQ_ID,0) = 0 THEN a.tot_allowed_amount END
                  END AS used_amount/*(a.tot_allowed_amount) AS used_amount*/ , a.Pat_Auth_Seq_Id, a.claim_seq_id  -----PROD FIXING 
               FROM pat_authorization_details a
               LEFT OUTER JOIN app.clm_authorization_details x on (a.pat_auth_seq_id = x.pat_auth_seq_id) -----PROD FIXING 
               WHERE A.Member_Seq_Id = v_member_seq_id 
                 AND A.PAT_ENHANCED_YN = 'N'    -----NEWLY ADDED FOR PREAUTH ENHANCEMENT
                 AND a.benifit_type = v_benifit_type
               --  AND a.claim_seq_id IS NULL -----PROD FIXING 
               ) r
          FULL OUTER JOIN
           ( SELECT CASE WHEN A.PAT_AUTH_SEQ_ID IS NOT NULL AND A.clm_status_type_id IN ('INP','REQ') THEN NULL
                    ELSE CASE WHEN NVL(A.PAT_AUTH_SEQ_ID,0) = 0 THEN A.FINAL_APP_AMOUNT 
                             WHEN A.PAT_AUTH_SEQ_ID IS NOT NULL AND A.clm_status_type_id IN ('APR') THEN  A.FINAL_APP_AMOUNT  END
                    END AS used_amount /*(A.FINAL_APP_AMOUNT) AS used_amount*/ , a.claim_seq_id,A.Pat_Auth_Seq_Id  -----PROD FIXING 
               FROM clm_authorization_details A 
               WHERE A.Member_Seq_Id = v_member_seq_id  
                 AND a.benifit_type = v_benifit_type
               ) s
               ON ( r.claim_seq_id = s.claim_seq_id )
               WHERE ( v_module_flag = 'P' AND NVL(r.Pat_Auth_Seq_Id,0) != NVL(v_seq_id,0) AND NVL(S.Pat_Auth_Seq_Id,0) != NVL(v_seq_id,0)
                   OR  v_module_flag = 'C' AND NVL(s.claim_seq_id,0) != v_seq_id 
                   OR  v_module_flag = 'A'))
         UNION ALL
         
        (SELECT NVL(SUM(nvl(s.used_amount, r.used_amount)),0) AS utilised_amount FROM
         ( SELECT CASE WHEN A.PAT_STATUS_TYPE_ID IN ('APR') THEN  (a.tot_allowed_amount) ELSE NULL END  AS used_amount , a.Pat_Auth_Seq_Id, a.claim_seq_id 
               FROM pat_authorization_details a
               WHERE A.Member_Seq_Id = v_member_seq_id 
                 AND a.benifit_type = v_benifit_type
               ---  AND a.claim_seq_id IS NULL
               ) r
          FULL OUTER JOIN
           ( SELECT CASE WHEN A.CLM_STATUS_TYPE_ID IN ('APR') THEN (A.FINAL_APP_AMOUNT) ELSE NULL END  AS used_amount , a.claim_seq_id,A.Pat_Auth_Seq_Id
               FROM clm_authorization_details A 
               WHERE A.Member_Seq_Id = v_member_seq_id  
                 AND a.benifit_type = v_benifit_type
               ) s
               ON ( r.claim_seq_id = s.claim_seq_id )
               WHERE ( v_module_flag = 'P' AND NVL(r.Pat_Auth_Seq_Id,0) = NVL(v_seq_id,0) -----AND NVL(S.Pat_Auth_Seq_Id,0) != NVL(v_seq_id,0)
                   OR  v_module_flag = 'C' AND NVL(s.claim_seq_id,0) = v_seq_id 
                   OR  v_module_flag = 'A'))) ; 
 
----------*****7******---                   

  CURSOR per_policy_ovral_ped_cur IS
  SELECT SUM(utilised_amount)
  FROM
    (
       (SELECT NVL(SUM(nvl(s.used_amount, r.used_amount)),0) AS utilised_amount FROM
         ( SELECT CASE WHEN  a.claim_seq_id IS NOT NULL AND x.clm_status_type_id in ('INP','REQ') THEN  
                  a.tot_allowed_amount 
                  ELSE CASE WHEN NVL(A.CLAIM_SEQ_ID,0) = 0 THEN a.tot_allowed_amount END
                  END AS used_amount/* (a.tot_allowed_amount) AS used_amount*/ , a.Pat_Auth_Seq_Id, a.claim_seq_id  -----PROD FIXING 
               FROM pat_authorization_details a
                LEFT OUTER JOIN app.clm_authorization_details x on (a.pat_auth_seq_id = x.pat_auth_seq_id) -----PROD FIXING                
               WHERE A.Member_Seq_Id = v_member_seq_id 
                 AND A.PAT_ENHANCED_YN = 'N'    -----NEWLY ADDED FOR PREAUTH ENHANCEMENT
                 AND a.ped_app_yn = 'Y'
              ---   AND a.claim_seq_id IS NULL -----PROD FIXING 
               ) r
          FULL OUTER JOIN
           ( SELECT CASE WHEN A.PAT_AUTH_SEQ_ID IS NOT NULL AND A.clm_status_type_id IN ('INP','REQ') THEN NULL
                    ELSE CASE WHEN NVL(A.PAT_AUTH_SEQ_ID,0) = 0 THEN A.FINAL_APP_AMOUNT 
                             WHEN A.PAT_AUTH_SEQ_ID IS NOT NULL AND A.clm_status_type_id IN ('APR') THEN  A.FINAL_APP_AMOUNT  END
                    END AS used_amount/*(A.FINAL_APP_AMOUNT) AS used_amount*/ , a.claim_seq_id,A.Pat_Auth_Seq_Id -----PROD FIXING 
               FROM clm_authorization_details A 
               WHERE A.Member_Seq_Id = v_member_seq_id  
                 AND a.ped_app_yn = 'Y'
               ) s
               ON ( r.claim_seq_id = s.claim_seq_id )
               WHERE ( v_module_flag = 'P' AND NVL(r.Pat_Auth_Seq_Id,0) != NVL(v_seq_id,0) AND NVL(S.Pat_Auth_Seq_Id,0) != NVL(v_seq_id,0)
                   OR  v_module_flag = 'C' AND NVL(s.claim_seq_id,0) != v_seq_id 
                   OR  v_module_flag = 'A'))
         UNION ALL 
        ( SELECT NVL(SUM(nvl(s.used_amount, r.used_amount)),0) AS utilised_amount FROM
         ( SELECT CASE WHEN A.PAT_STATUS_TYPE_ID IN ('APR') THEN  (a.tot_allowed_amount) ELSE NULL END  AS used_amount , a.Pat_Auth_Seq_Id, a.claim_seq_id 
               FROM pat_authorization_details a
               WHERE A.Member_Seq_Id = v_member_seq_id 
                 AND a.ped_app_yn = 'Y'
                 ---AND a.claim_seq_id IS NULL
               ) r
          FULL OUTER JOIN
           ( SELECT CASE WHEN A.CLM_STATUS_TYPE_ID IN ('APR') THEN (A.FINAL_APP_AMOUNT)  ELSE NULL END AS used_amount , a.claim_seq_id,A.Pat_Auth_Seq_Id
               FROM clm_authorization_details A 
               WHERE A.Member_Seq_Id = v_member_seq_id  
                 AND a.ped_app_yn = 'Y'
               ) s
               ON ( r.claim_seq_id = s.claim_seq_id )
               WHERE ( v_module_flag = 'P' AND NVL(r.Pat_Auth_Seq_Id,0) = NVL(v_seq_id,0) ---AND NVL(S.Pat_Auth_Seq_Id,0) != NVL(v_seq_id,0)
                   OR  v_module_flag = 'C' AND NVL(s.claim_seq_id,0) = v_seq_id 
                   OR  v_module_flag = 'A')));    
                   
  ------******8********
  CURSOR per_policy_ovral_som_cur IS
    SELECT SUM(utilised_amount)
    FROM
    (
      ( SELECT NVL(SUM(nvl(s.used_amount, r.used_amount)),0) AS utilised_amount FROM
         ( SELECT  CASE WHEN  a.claim_seq_id IS NOT NULL AND x.clm_status_type_id in ('INP','REQ') THEN  
                  a.tot_allowed_amount 
                  ELSE CASE WHEN NVL(A.CLAIM_SEQ_ID,0) = 0 THEN a.tot_allowed_amount END
                  END AS used_amount/*(a.tot_allowed_amount) AS used_amount*/ , a.Pat_Auth_Seq_Id, a.claim_seq_id  -----PROD FIXING 
               FROM pat_authorization_details a
               LEFT OUTER JOIN app.clm_authorization_details x on (a.pat_auth_seq_id = x.pat_auth_seq_id) -----PROD FIXING 
               WHERE A.Member_Seq_Id = v_member_seq_id 
                 AND A.PAT_ENHANCED_YN = 'N'    -----NEWLY ADDED FOR PREAUTH ENHANCEMENT
                 AND a.system_of_medicine_type_id != 'SAL'
              --   AND a.claim_seq_id IS NULL  -----PROD FIXING 
               ) r
          FULL OUTER JOIN
           ( SELECT CASE WHEN A.PAT_AUTH_SEQ_ID IS NOT NULL AND A.clm_status_type_id IN ('INP','REQ') THEN NULL
                    ELSE CASE WHEN NVL(A.PAT_AUTH_SEQ_ID,0) = 0 THEN A.FINAL_APP_AMOUNT 
                             WHEN A.PAT_AUTH_SEQ_ID IS NOT NULL AND A.clm_status_type_id IN ('APR') THEN  A.FINAL_APP_AMOUNT  END
                    END AS used_amount/*(A.FINAL_APP_AMOUNT) AS used_amount*/ , a.claim_seq_id,A.Pat_Auth_Seq_Id  -----PROD FIXING 
               FROM clm_authorization_details A 
               WHERE A.Member_Seq_Id = v_member_seq_id  
                 AND a.system_of_medicine_type_id != 'SAL'
               ) s
               ON ( r.claim_seq_id = s.claim_seq_id )
               WHERE ( v_module_flag = 'P' AND NVL(r.Pat_Auth_Seq_Id,0) != NVL(v_seq_id,0) AND NVL(S.Pat_Auth_Seq_Id,0) != NVL(v_seq_id,0)
                   OR  v_module_flag = 'C' AND NVL(s.claim_seq_id,0) != v_seq_id 
                   OR  v_module_flag = 'A'))
        UNION ALL
        (SELECT NVL(SUM(nvl(s.used_amount, r.used_amount)),0) AS utilised_amount FROM
         ( SELECT CASE WHEN A.PAT_STATUS_TYPE_ID IN ('APR') THEN  (a.tot_allowed_amount) ELSE NULL END  AS used_amount , a.Pat_Auth_Seq_Id, a.claim_seq_id 
               FROM pat_authorization_details a
               WHERE A.Member_Seq_Id = v_member_seq_id 
                 AND a.system_of_medicine_type_id != 'SAL'
                --- AND a.claim_seq_id IS NULL
               ) r
          FULL OUTER JOIN
           ( SELECT CASE WHEN A.CLM_STATUS_TYPE_ID IN ('APR') THEN (A.FINAL_APP_AMOUNT) ELSE NULL END  AS used_amount , a.claim_seq_id,A.Pat_Auth_Seq_Id
               FROM clm_authorization_details A 
               WHERE A.Member_Seq_Id = v_member_seq_id  
                 AND a.system_of_medicine_type_id != 'SAL'
               ) s
               ON ( r.claim_seq_id = s.claim_seq_id )
               WHERE ( v_module_flag = 'P' AND NVL(r.Pat_Auth_Seq_Id,0) = NVL(v_seq_id,0) ----AND NVL(S.Pat_Auth_Seq_Id,0) != NVL(v_seq_id,0)
                   OR  v_module_flag = 'C' AND NVL(s.claim_seq_id,0) = v_seq_id 
                   OR  v_module_flag = 'A')));  
                   
-----******9*****----                                           
  
  CURSOR per_policy_dntl_cur IS
   SELECT SUM(utilised_amount)
    FROM (
      (SELECT NVL(SUM(nvl(s.used_amount, r.used_amount)),0) AS utilised_amount FROM
         ( SELECT b.approved_amount AS used_amount, b.Pat_Auth_Seq_Id, a.claim_seq_id
               FROM pat_authorization_details a
               LEFT OUTER JOIN app.clm_authorization_details x on (a.pat_auth_seq_id = x.pat_auth_seq_id)
               JOIN pat_activity_details b ON (a.pat_auth_seq_id = b.pat_auth_seq_id AND A.pat_status_type_id != 'PCN' AND A.pat_status_type_id != 'REJ' )
               LEFT JOIN APP.DENTAL_RULE_TAB D ON (B.CODE=D.CDT_CODE)
               WHERE A.Member_Seq_Id = v_member_seq_id
               AND A.PAT_ENHANCED_YN = 'N'
               AND D.SPECIFIC_SERVICE_CODE = v_mstr_code
               AND (a.claim_seq_id IS NULL OR (a.claim_seq_id IS NOT NULL AND x.clm_status_type_id IN ('INP', 'REQ') AND NVL(a.claim_seq_id, 0) != NVL(v_seq_id, 0)))-- Fixing for used amount
               ) r
          FULL OUTER JOIN
           ( SELECT b.approved_amount AS used_amount, a.claim_seq_id,A.Pat_Auth_Seq_Id
               FROM clm_authorization_details A 
               JOIN pat_activity_details b ON (a.claim_seq_id = b.claim_seq_id AND A.CLM_STATUS_TYPE_ID != 'PCN' AND A.CLM_STATUS_TYPE_ID != 'REJ' )
               LEFT JOIN APP.DENTAL_RULE_TAB D ON (B.CODE=D.CDT_CODE)
               WHERE A.Member_Seq_Id = v_member_seq_id  
               AND D.SPECIFIC_SERVICE_CODE = v_mstr_code
               AND (A.PAT_AUTH_SEQ_ID IS NULL OR (A.PAT_AUTH_SEQ_ID IS NOT NULL AND A.clm_status_type_id = 'APR'))
               ) s
               ON ( r.claim_seq_id = s.claim_seq_id )
         WHERE ( v_module_flag = 'P' AND NVL(r.Pat_Auth_Seq_Id,0) != NVL(v_seq_id,0) AND NVL(S.Pat_Auth_Seq_Id,0) != NVL(v_seq_id,0)
                   OR  v_module_flag = 'C' AND NVL(s.claim_seq_id,0) != NVL(v_seq_id, 0) 
                   OR  v_module_flag = 'A'))
    --=====
    UNION ALL
      (SELECT NVL(SUM(nvl(s.used_amount, r.used_amount)),0)  AS utilised_amount 
       FROM
         (SELECT a.pre_auth_number, b.approved_amount AS used_amount, b.Pat_Auth_Seq_Id, a.claim_seq_id, x.clm_status_type_id
           FROM pat_authorization_details a
           LEFT OUTER JOIN app.clm_authorization_details x on (a.pat_auth_seq_id = x.pat_auth_seq_id)
           JOIN pat_activity_details b ON (a.pat_auth_seq_id = b.pat_auth_seq_id AND A.pat_status_type_id != 'PCN' AND A.pat_status_type_id != 'REJ' )
           LEFT JOIN APP.DENTAL_RULE_TAB D ON (B.CODE=D.CDT_CODE)
           WHERE A.Member_Seq_Id = v_member_seq_id
           AND A.PAT_ENHANCED_YN = 'N'
           AND D.SPECIFIC_SERVICE_CODE = v_mstr_code
           AND A.PAT_STATUS_TYPE_ID = 'APR'
           AND (a.claim_seq_id IS NULL OR (x.clm_status_type_id IN ('INP', 'REQ')))-- Fixing for used amount
           AND v_module_flag != 'A'
          ) r
    FULL OUTER JOIN
         (SELECT b.approved_amount AS used_amount, a.claim_seq_id,A.Pat_Auth_Seq_Id
          FROM clm_authorization_details A 
          JOIN pat_activity_details b ON (a.claim_seq_id = b.claim_seq_id AND A.CLM_STATUS_TYPE_ID != 'PCN' AND A.CLM_STATUS_TYPE_ID != 'REJ' )
          LEFT JOIN APP.DENTAL_RULE_TAB D ON (B.CODE=D.CDT_CODE)
          WHERE A.Member_Seq_Id = v_member_seq_id
          AND D.SPECIFIC_SERVICE_CODE = v_mstr_code
          AND A.clm_status_type_id = 'APR'-- Fixing for used amount
          AND v_module_flag != 'A'
         ) s
              ON ( r.claim_seq_id = s.claim_seq_id)
    WHERE (v_module_flag = 'P' AND NVL(r.Pat_Auth_Seq_Id, 0) = NVL(v_seq_id,0) OR NVL(S.Pat_Auth_Seq_Id,0) = NVL(v_seq_id,0)
                   OR  v_module_flag = 'C' AND NVL(s.claim_seq_id, r.claim_seq_id) = NVL(v_seq_id, 0)
                   OR  v_module_flag = 'A'))); 
                   
------*****10*****--------                  
   CURSOR per_policy_ovral_dntl_cur IS
    SELECT SUM(utilised_amount)
    FROM (
      (SELECT NVL(SUM(nvl(s.used_amount, r.used_amount)),0) AS utilised_amount FROM
         ( SELECT b.approved_amount AS used_amount, b.Pat_Auth_Seq_Id, a.claim_seq_id
               FROM pat_authorization_details a
               LEFT OUTER JOIN app.clm_authorization_details x on (a.pat_auth_seq_id = x.pat_auth_seq_id)
               JOIN pat_activity_details b ON (a.pat_auth_seq_id = b.pat_auth_seq_id AND A.pat_status_type_id != 'PCN' AND A.pat_status_type_id != 'REJ' )
               LEFT JOIN APP.DENTAL_RULE_TAB D ON (B.CODE=D.CDT_CODE)
               WHERE A.Member_Seq_Id = v_member_seq_id
               AND A.PAT_ENHANCED_YN = 'N'
               AND A.BENIFIT_TYPE = 'DNTL'
               --AND D.SPECIFIC_SERVICE_CODE = v_mstr_code
               AND (a.claim_seq_id IS NULL OR (a.claim_seq_id IS NOT NULL AND x.clm_status_type_id IN ('INP', 'REQ') AND a.claim_seq_id != NVL(v_seq_id, 0)))-- Fixing for used amount
               ) r
          FULL OUTER JOIN
           ( SELECT CASE WHEN A.PAT_AUTH_SEQ_ID IS NOT NULL AND A.clm_status_type_id IN ('INP','REQ') THEN NULL
                    ELSE CASE WHEN NVL(A.PAT_AUTH_SEQ_ID,0) = 0 THEN b.approved_amount 
                             WHEN A.PAT_AUTH_SEQ_ID IS NOT NULL AND A.clm_status_type_id IN ('APR') THEN  b.approved_amount  END
                    END AS used_amount, a.claim_seq_id,A.Pat_Auth_Seq_Id
               FROM clm_authorization_details A 
               JOIN pat_activity_details b ON (a.claim_seq_id = b.claim_seq_id AND A.CLM_STATUS_TYPE_ID != 'PCN' AND A.CLM_STATUS_TYPE_ID != 'REJ' )
               LEFT JOIN APP.DENTAL_RULE_TAB D ON (B.CODE=D.CDT_CODE)
               WHERE A.Member_Seq_Id = v_member_seq_id  
               AND A.BENIFIT_TYPE = 'DNTL'
               --AND D.SPECIFIC_SERVICE_CODE = v_mstr_code
               AND (A.PAT_AUTH_SEQ_ID IS NULL OR (A.PAT_AUTH_SEQ_ID IS NOT NULL AND A.clm_status_type_id = 'APR'))
               ) s
               ON ( r.claim_seq_id = s.claim_seq_id )
         WHERE ( v_module_flag = 'P' AND NVL(r.Pat_Auth_Seq_Id,0) != NVL(v_seq_id,0) AND NVL(S.Pat_Auth_Seq_Id,0) != NVL(v_seq_id,0)
                   OR  v_module_flag = 'C' AND NVL(s.claim_seq_id,0) != NVL(v_seq_id, 0) 
                   OR  v_module_flag = 'A'))
    --===== Changed
    UNION ALL
      (SELECT NVL(SUM(nvl(s.used_amount, r.used_amount)),0)  AS utilised_amount 
       FROM
         (SELECT a.pre_auth_number, b.approved_amount AS used_amount, b.Pat_Auth_Seq_Id, a.claim_seq_id, x.clm_status_type_id
           FROM pat_authorization_details a
           LEFT OUTER JOIN app.clm_authorization_details x on (a.pat_auth_seq_id = x.pat_auth_seq_id)
           JOIN pat_activity_details b ON (a.pat_auth_seq_id = b.pat_auth_seq_id AND A.pat_status_type_id != 'PCN' AND A.pat_status_type_id != 'REJ' )
           LEFT JOIN APP.DENTAL_RULE_TAB D ON (B.CODE=D.CDT_CODE)
           WHERE A.Member_Seq_Id = v_member_seq_id
           AND A.PAT_ENHANCED_YN = 'N'
           AND A.BENIFIT_TYPE = 'DNTL'
           --AND D.SPECIFIC_SERVICE_CODE = v_mstr_code
           AND A.PAT_STATUS_TYPE_ID = 'APR'
           AND (a.claim_seq_id IS NULL OR (x.clm_status_type_id IN ('INP', 'REQ') AND NVL(a.claim_seq_id, 0) != NVL(v_seq_id, 0)))-- Fixing for used amount
           AND v_module_flag != 'A'
          ) r
    FULL OUTER JOIN
         (SELECT b.approved_amount AS used_amount, a.claim_seq_id,A.Pat_Auth_Seq_Id
          FROM clm_authorization_details A 
          JOIN pat_activity_details b ON (a.claim_seq_id = b.claim_seq_id AND A.CLM_STATUS_TYPE_ID != 'PCN' AND A.CLM_STATUS_TYPE_ID != 'REJ' )
          LEFT JOIN APP.DENTAL_RULE_TAB D ON (B.CODE=D.CDT_CODE)
          WHERE A.Member_Seq_Id = v_member_seq_id
          AND A.BENIFIT_TYPE = 'DNTL'
          --AND D.SPECIFIC_SERVICE_CODE = v_mstr_code
          AND A.clm_status_type_id = 'APR'-- Fixing for used amount
          AND v_module_flag != 'A'
         ) s
              ON ( r.claim_seq_id = s.claim_seq_id)
    WHERE (v_module_flag = 'P' AND NVL(r.Pat_Auth_Seq_Id, 0) = NVL(v_seq_id,0) OR NVL(S.Pat_Auth_Seq_Id,0) = NVL(v_seq_id,0)
                   OR  v_module_flag = 'C' AND NVL(s.claim_seq_id, r.claim_seq_id) = NVL(v_seq_id, 0)
                   OR  v_module_flag = 'A'))); 
                   
-------********11                
              
    CURSOR per_claim_ovral_dntl_cur IS
      SELECT NVL(SUM(nvl(s.used_amount, r.used_amount)),0) FROM
         ( SELECT  CASE WHEN  a.claim_seq_id IS NOT NULL AND x.clm_status_type_id in ('INP','REQ') THEN  
                  b.approved_amount 
                  ELSE CASE WHEN NVL(A.CLAIM_SEQ_ID,0) = 0 THEN b.approved_amount END
                  END AS used_amount/*(b.approved_amount) AS used_amount*/ , b.Pat_Auth_Seq_Id, a.claim_seq_id   -----PROD FIXING 
               FROM pat_authorization_details a
               LEFT OUTER JOIN app.clm_authorization_details x on (a.pat_auth_seq_id = x.pat_auth_seq_id) -----PROD FIXING 
               JOIN pat_activity_details b ON (a.pat_auth_seq_id = b.pat_auth_seq_id AND A.pat_status_type_id != 'PCN' AND A.pat_status_type_id != 'REJ' )
               JOIN APP.DENTAL_RULE_TAB D ON (B.CODE=D.CDT_CODE)
               WHERE A.Member_Seq_Id = v_member_seq_id
                  AND A.PAT_ENHANCED_YN = 'N'    -----NEWLY ADDED FOR PREAUTH ENHANCEMENT 
                  AND D.SPECIFIC_SERVICE_CODE IN (SELECT CM.MASTER_CODE FROM APP.TPA_RULE_CONDITION_MSTR CM WHERE CM.RULE_BY = 'DNT')
               ----   AND a.claim_seq_id IS NULL   -----PROD FIXING 
               ) r
          FULL OUTER JOIN
           ( SELECT CASE WHEN A.PAT_AUTH_SEQ_ID IS NOT NULL AND A.clm_status_type_id IN ('INP','REQ') THEN NULL
                    ELSE CASE WHEN NVL(A.PAT_AUTH_SEQ_ID,0) = 0 THEN b.approved_amount 
                             WHEN A.PAT_AUTH_SEQ_ID IS NOT NULL AND A.clm_status_type_id IN ('APR') THEN  b.approved_amount  END
                    END AS used_amount/*(b.approved_amount) AS used_amount*/ , a.claim_seq_id,A.Pat_Auth_Seq_Id  -----PROD FIXING 
               FROM clm_authorization_details A 
               JOIN pat_activity_details b ON (a.claim_seq_id = b.claim_seq_id AND A.CLM_STATUS_TYPE_ID != 'PCN' AND A.CLM_STATUS_TYPE_ID != 'REJ' )
               JOIN APP.DENTAL_RULE_TAB D ON (B.CODE=D.CDT_CODE)
               WHERE A.Member_Seq_Id = v_member_seq_id  
                 AND D.SPECIFIC_SERVICE_CODE IN (SELECT CM.MASTER_CODE FROM APP.TPA_RULE_CONDITION_MSTR CM WHERE CM.RULE_BY = 'DNT')
               ) s
               ON ( r.claim_seq_id = s.claim_seq_id )
         WHERE ( v_module_flag = 'P' AND NVL(r.Pat_Auth_Seq_Id,0) = NVL(v_seq_id,0) AND NVL(S.Pat_Auth_Seq_Id,0) = NVL(v_seq_id,0)
                   OR  v_module_flag = 'C' AND NVL(s.claim_seq_id,0) = v_seq_id 
                   OR  v_module_flag = 'A');                                     
    
 -------**********12*******-----------------   
CURSOR per_policy_mat_cur(v_encounter_type_id    NUMBER)  IS
   SELECT SUM(utilised_amount)      
  FROM 
   (    
  (SELECT NVL(SUM(nvl(s.used_amount, r.used_amount)),0) AS utilised_amount FROM
         ( SELECT  CASE WHEN  a.claim_seq_id IS NOT NULL AND x.clm_status_type_id in ('INP','REQ') THEN  
                  A.Tot_Allowed_Amount 
                  ELSE CASE WHEN NVL(A.CLAIM_SEQ_ID,0) = 0 THEN A.Tot_Allowed_Amount END
                  END AS used_amount/*(A.Tot_Allowed_Amount) AS used_amount*/  , A.Pat_Auth_Seq_Id, a.claim_seq_id 
           FROM pat_authorization_details a 
           LEFT OUTER JOIN app.clm_authorization_details x on (a.pat_auth_seq_id=x.pat_auth_seq_id)
            where a.pat_auth_seq_id IN
              (SELECT DISTINCT a.pat_auth_seq_id 
               FROM pat_authorization_details a
               LEFT OUTER JOIN app.clm_authorization_details x on (a.pat_auth_seq_id = x.pat_auth_seq_id) -----PROD FIXING
               JOIN diagnosys_details b ON (a.pat_auth_seq_id = b.pat_auth_seq_id AND A.pat_status_type_id != 'PCN' AND A.pat_status_type_id != 'REJ' )
               JOIN tpa_icd_codes G ON (b.diagnosys_code = g.icd_code)
               WHERE A.Member_Seq_Id = v_member_seq_id 
               AND G.MASTER_ICD_CODE = v_mstr_code
               AND a.encounter_type_id = v_encounter_type_id
               AND (a.claim_seq_id IS NULL OR (a.claim_seq_id IS NOT NULL AND x.clm_status_type_id IN ('INP', 'REQ') AND NVL(a.claim_seq_id, 0) != NVL(v_seq_id, 0)))-- Fixing for used amount
           --  AND a.claim_seq_id IS NULL   -----PROD FIXING 
               ))r
          FULL OUTER JOIN
           ( SELECT CASE WHEN A.PAT_AUTH_SEQ_ID IS NOT NULL AND A.clm_status_type_id IN ('INP','REQ') THEN NULL
                    ELSE CASE WHEN NVL(A.PAT_AUTH_SEQ_ID,0) = 0 THEN A.Tot_Allowed_Amount 
                             WHEN A.PAT_AUTH_SEQ_ID IS NOT NULL AND A.clm_status_type_id IN ('APR') THEN  A.Tot_Allowed_Amount  END
                    END AS used_amount/*(A.Tot_Allowed_Amount) AS used_amount*/ , a.claim_seq_id,A.Pat_Auth_Seq_Id  -----PROD FIXING 
               FROM clm_authorization_details A 
               where a.claim_seq_id IN
              (SELECT DISTINCT a.claim_seq_id
               FROM clm_authorization_details A  
               JOIN diagnosys_details b ON (a.claim_seq_id = b.claim_seq_id AND A.CLM_STATUS_TYPE_ID != 'PCN' AND A.CLM_STATUS_TYPE_ID != 'REJ' )
               JOIN tpa_icd_codes G ON (b.diagnosys_code = g.icd_code)
               WHERE A.Member_Seq_Id = v_member_seq_id  
               AND G.MASTER_ICD_CODE = v_mstr_code
               AND a.encounter_type_id = v_encounter_type_id)) s
               ON ( r.claim_seq_id = s.claim_seq_id )
               WHERE ( v_module_flag = 'P' AND NVL(r.Pat_Auth_Seq_Id,0) != NVL(v_seq_id,0) AND NVL(S.Pat_Auth_Seq_Id,0) != NVL(v_seq_id,0)
                   OR  v_module_flag = 'C' AND NVL(s.claim_seq_id,0) != NVL(v_seq_id, 0) 
                   OR  v_module_flag = 'A'))
       UNION ALL
        (SELECT NVL(SUM(nvl(s.used_amount, r.used_amount)),0) AS utilised_amount FROM
         ( SELECT CASE WHEN A.PAT_STATUS_TYPE_ID IN ('APR') THEN  (A.Tot_Allowed_Amount) ELSE NULL END  AS used_amount , A.Pat_Auth_Seq_Id, a.claim_seq_id 
           FROM pat_authorization_details a 
            where a.pat_auth_seq_id IN
              (SELECT DISTINCT a.pat_auth_seq_id 
               FROM pat_authorization_details a
               LEFT OUTER JOIN app.clm_authorization_details x on (a.pat_auth_seq_id = x.pat_auth_seq_id) 
               JOIN diagnosys_details b ON (a.pat_auth_seq_id = b.pat_auth_seq_id AND A.pat_status_type_id != 'PCN' AND A.pat_status_type_id != 'REJ' )
               JOIN tpa_icd_codes G ON (b.diagnosys_code = g.icd_code)
               WHERE A.Member_Seq_Id = v_member_seq_id 
               AND G.MASTER_ICD_CODE = v_mstr_code
               AND a.encounter_type_id = v_encounter_type_id
               AND (a.claim_seq_id IS NULL OR (x.clm_status_type_id IN ('INP', 'REQ') AND NVL(a.claim_seq_id, 0) != NVL(v_seq_id, 0)))-- Fixing for used amount
               ---AND a.claim_seq_id IS NULL
                )) r
          FULL OUTER JOIN
           ( SELECT CASE WHEN A.CLM_STATUS_TYPE_ID IN ('APR') THEN  (A.Tot_Allowed_Amount) ELSE NULL END  AS used_amount , a.claim_seq_id,A.Pat_Auth_Seq_Id
               FROM clm_authorization_details A 
               where a.claim_seq_id IN
              (SELECT DISTINCT a.claim_seq_id
               FROM clm_authorization_details A  
               JOIN diagnosys_details b ON (a.claim_seq_id = b.claim_seq_id AND A.CLM_STATUS_TYPE_ID != 'PCN' AND A.CLM_STATUS_TYPE_ID != 'REJ' )
               JOIN tpa_icd_codes G ON (b.diagnosys_code = g.icd_code)
               WHERE A.Member_Seq_Id = v_member_seq_id  
               AND G.MASTER_ICD_CODE = v_mstr_code
               AND a.encounter_type_id = v_encounter_type_id)) s
               ON ( r.claim_seq_id = s.claim_seq_id )
               WHERE ( v_module_flag = 'P' AND NVL(r.Pat_Auth_Seq_Id,0) != NVL(v_seq_id,0) AND NVL(S.Pat_Auth_Seq_Id,0) != NVL(v_seq_id,0)
                   OR  v_module_flag = 'C' AND NVL(s.claim_seq_id,0) != NVL(v_seq_id, 0) 
                   OR  v_module_flag = 'A')));
                   
                   
 CURSOR Get_gop_tot_utilised_amt IS
      SELECT NVL(SUM (UTIL_AMOUNT),0) FROM (
      SELECT SUM (NVL(CL.FINAL_APP_AMOUNT,PR.FINAL_APP_AMOUNT)) AS UTIL_AMOUNT
       FROM 
       (SELECT CASE WHEN P.PAT_STATUS_TYPE_ID='APR' THEN P.FINAL_APP_AMOUNT ELSE P.TOT_APPROVED_AMOUNT END  
              AS FINAL_APP_AMOUNT,P.CLAIM_SEQ_ID,P.PAT_AUTH_SEQ_ID 
         FROM PAT_AUTHORIZATION_DETAILS P
         LEFT OUTER JOIN CLM_AUTHORIZATION_DETAILS CAD ON (P.CLAIM_SEQ_ID=CAD.CLAIM_SEQ_ID)
         WHERE P.MEMBER_SEQ_ID=v_member_seq_id
         AND P.PAT_STATUS_TYPE_ID IN ('APR','REQ') AND P.BENIFIT_TYPE='OPTS' AND NVL(P.LIMIT_APPLIED_FLAG,'WOP')='WOP'
         AND NVL(P.PAT_ENHANCED_YN,'N')='N' AND (P.CLAIM_SEQ_ID IS NULL OR (P.CLAIM_SEQ_ID IS NOT NULL AND NVL(CAD.CAL_ACT_YN,'N')='N') 
         AND CAD.CLM_STATUS_TYPE_ID IN ('INP','REQ'))) PR
        FULL OUTER JOIN
        (
         SELECT CASE WHEN C.CLM_STATUS_TYPE_ID='APR' THEN C.FINAL_APP_AMOUNT ELSE C.TOT_APPROVED_AMOUNT END  
             AS FINAL_APP_AMOUNT,c.CLAIM_SEQ_ID
          FROM CLM_AUTHORIZATION_DETAILS C
          WHERE C.MEMBER_SEQ_ID=v_member_seq_id
          AND C.CLM_STATUS_TYPE_ID IN ('APR','REQ')
          AND C.BENIFIT_TYPE='OPTS' AND NVL(C.LIMIT_APPLIED_FLAG,'WOP')='WOP'
         ) CL
         ON (PR.CLAIM_SEQ_ID=CL.CLAIM_SEQ_ID) 
  WHERE ( v_module_flag= 'P' AND NVL(PR.Pat_Auth_Seq_Id,0) != NVL(v_seq_id,0)
         OR  v_module_flag = 'C' AND NVL(CL.claim_seq_id,0) != NVL(v_seq_id,0) )
       UNION ALL
       SELECT SUM (NVL(CL.FINAL_APP_AMOUNT,PR.FINAL_APP_AMOUNT)) AS UTIL_AMOUNT
       FROM 
       (SELECT CASE WHEN P.PAT_STATUS_TYPE_ID='APR' THEN P.FINAL_APP_AMOUNT ELSE P.TOT_APPROVED_AMOUNT END  
              AS FINAL_APP_AMOUNT,P.CLAIM_SEQ_ID,P.PAT_AUTH_SEQ_ID 
         FROM PAT_AUTHORIZATION_DETAILS P
         LEFT OUTER JOIN CLM_AUTHORIZATION_DETAILS CAD ON (P.CLAIM_SEQ_ID=CAD.CLAIM_SEQ_ID)
         WHERE P.MEMBER_SEQ_ID=v_member_seq_id
         AND P.PAT_STATUS_TYPE_ID IN ('APR','REQ') AND P.BENIFIT_TYPE='OPTS' AND NVL(P.LIMIT_APPLIED_FLAG,'WOP')='WOP'
         AND NVL(P.PAT_ENHANCED_YN,'N')='N' AND (P.CLAIM_SEQ_ID IS NULL OR (P.CLAIM_SEQ_ID IS NOT NULL AND NVL(CAD.CAL_ACT_YN,'N')='N') 
         AND CAD.CLM_STATUS_TYPE_ID IN ('INP','REQ'))) PR
        FULL OUTER JOIN
        (
         SELECT CASE WHEN C.CLM_STATUS_TYPE_ID='APR' THEN C.FINAL_APP_AMOUNT ELSE C.TOT_APPROVED_AMOUNT END  
             AS FINAL_APP_AMOUNT,c.CLAIM_SEQ_ID
          FROM CLM_AUTHORIZATION_DETAILS C
          WHERE C.MEMBER_SEQ_ID=v_member_seq_id
          AND C.CLM_STATUS_TYPE_ID IN ('APR','REQ')
          AND C.BENIFIT_TYPE='OPTS' AND NVL(C.LIMIT_APPLIED_FLAG,'WOP')='WOP'
         ) CL
         ON (PR.CLAIM_SEQ_ID=CL.CLAIM_SEQ_ID) 
  WHERE ( v_module_flag= 'P' AND NVL(PR.Pat_Auth_Seq_Id,0) = NVL(v_seq_id,0)
         OR  v_module_flag = 'C' AND NVL(CL.claim_seq_id,0) = NVL(v_seq_id,0) ) ); 
                               
  
  v_utilized_amount                 VARCHAR2(10);
  
     
BEGIN
  
  IF v_mstr_code_flag = 'ACT' THEN
    
     OPEN  per_policy_act_cur;
     FETCH per_policy_act_cur INTO v_utilized_amount;
     CLOSE per_policy_act_cur;
     
  ELSIF v_mstr_code_flag = 'ICD' THEN
    IF v_cond_seq_id = 168 THEN
     OPEN  per_policy_mat_cur(1);
     FETCH per_policy_mat_cur INTO v_utilized_amount;
     CLOSE per_policy_mat_cur;  
    ELSIF v_cond_seq_id = 169 THEN
     OPEN  per_policy_mat_cur(2);
     FETCH per_policy_mat_cur INTO v_utilized_amount;
     CLOSE per_policy_mat_cur;  
    ELSIF v_cond_seq_id = 170 THEN
     OPEN  per_policy_mat_cur(3);
     FETCH per_policy_mat_cur INTO v_utilized_amount;
     CLOSE per_policy_mat_cur;  
    ELSIF v_cond_seq_id = 171 THEN
     OPEN  per_policy_mat_cur(4);
     FETCH per_policy_mat_cur INTO v_utilized_amount;
     CLOSE per_policy_mat_cur;  
    ELSE
     OPEN  per_policy_icd_cur;
     FETCH per_policy_icd_cur INTO v_utilized_amount;
     CLOSE per_policy_icd_cur;    
    END IF;   
  ELSIF v_mstr_code_flag = 'DNT' THEN
    IF v_mstr_code = 'D0150' /*AND v_benefit_flag = 'PP' */THEN
      OPEN  per_policy_ovral_dntl_cur;
      FETCH per_policy_ovral_dntl_cur INTO v_utilized_amount;
      CLOSE per_policy_ovral_dntl_cur;  
    /*ELSIF v_mstr_code = 'D0150' AND v_benefit_flag = 'PC' THEN
      OPEN  per_claim_ovral_dntl_cur;
      FETCH per_claim_ovral_dntl_cur INTO v_utilized_amount;
      CLOSE per_claim_ovral_dntl_cur; */ 
    ELSE
      OPEN  per_policy_dntl_cur;
      FETCH per_policy_dntl_cur INTO v_utilized_amount;
      CLOSE per_policy_dntl_cur;  
    END IF;
       
     
  ELSIF v_mstr_code_flag = 'GRP' THEN
   --IF v_benefit_flag = 'CHR' THEN
     OPEN  per_policy_icd_cur_chronic;
     FETCH per_policy_icd_cur_chronic INTO v_utilized_amount;
     CLOSE per_policy_icd_cur_chronic; 
   --END IF;
  ELSIF v_cond_seq_id = 1 AND v_mstr_code_flag IS NULL THEN  
    OPEN  per_policy_ovral_som_cur;
    FETCH per_policy_ovral_som_cur INTO v_utilized_amount;
    CLOSE per_policy_ovral_som_cur; 
  ELSIF v_cond_seq_id = 4 AND v_mstr_code_flag IS NULL THEN  
    OPEN  per_policy_ovral_area_cur;
    FETCH per_policy_ovral_area_cur INTO v_utilized_amount;
    CLOSE per_policy_ovral_area_cur;
  ELSIF v_cond_seq_id = 5 AND v_mstr_code_flag IS NULL  THEN
    OPEN  per_policy_benf_area_cur('IPT');
    FETCH per_policy_benf_area_cur INTO v_utilized_amount;
    CLOSE per_policy_benf_area_cur;
  ELSIF v_cond_seq_id = 6 AND v_mstr_code_flag IS NULL  THEN
    OPEN  per_policy_benf_area_cur('OPTS');
    FETCH per_policy_benf_area_cur INTO v_utilized_amount;
    CLOSE per_policy_benf_area_cur;
  ELSIF v_cond_seq_id = 7 AND v_mstr_code_flag IS NULL  THEN
    OPEN  per_policy_benf_area_cur('IMTI');
    FETCH per_policy_benf_area_cur INTO v_utilized_amount;
    CLOSE per_policy_benf_area_cur;
  ELSIF v_cond_seq_id = 8 AND v_mstr_code_flag IS NULL  THEN
    OPEN  per_policy_benf_area_cur('OMTI');
    FETCH per_policy_benf_area_cur INTO v_utilized_amount;
    CLOSE per_policy_benf_area_cur;
  ELSIF v_cond_seq_id = 9 AND v_mstr_code_flag IS NULL  THEN
    OPEN  per_policy_benf_area_cur('OPTC');
    FETCH per_policy_benf_area_cur INTO v_utilized_amount;
    CLOSE per_policy_benf_area_cur;
  ELSIF v_cond_seq_id = 10 AND v_mstr_code_flag IS NULL  THEN
    OPEN  per_policy_benf_area_cur('DNTL');
    FETCH per_policy_benf_area_cur INTO v_utilized_amount;
    CLOSE per_policy_benf_area_cur; 
  ELSIF v_cond_seq_id = 139 AND v_mstr_code_flag IS NULL  THEN
    OPEN  per_policy_benf_utliz_cur('HEAC');
    FETCH per_policy_benf_utliz_cur INTO v_utilized_amount;
    CLOSE per_policy_benf_utliz_cur;  
  ELSIF v_cond_seq_id = 156 AND v_mstr_code_flag IS NULL  THEN
    OPEN  per_policy_benf_utliz_cur('IEMA');
    FETCH per_policy_benf_utliz_cur INTO v_utilized_amount;
    CLOSE per_policy_benf_utliz_cur;
  ELSIF v_cond_seq_id = 157 AND v_mstr_code_flag IS NULL  THEN
    OPEN  per_policy_benf_utliz_cur('IPRE');
    FETCH per_policy_benf_utliz_cur INTO v_utilized_amount;
    CLOSE per_policy_benf_utliz_cur;
  ELSIF v_cond_seq_id = 158 AND v_mstr_code_flag IS NULL  THEN
    OPEN  per_policy_benf_utliz_cur('PAHC');
    FETCH per_policy_benf_utliz_cur INTO v_utilized_amount;
    CLOSE per_policy_benf_utliz_cur;   
  ELSIF v_cond_seq_id = 207 AND v_mstr_code_flag IS NULL  THEN
    OPEN  per_policy_ovral_ped_cur;
    FETCH per_policy_ovral_ped_cur INTO v_utilized_amount;
    CLOSE per_policy_ovral_ped_cur;  
 ELSIF v_cond_seq_id = 216 and v_mstr_code_flag='BENF' THEN
   OPEN Get_gop_tot_utilised_amt;
     FETCH Get_gop_tot_utilised_amt INTO v_utilized_amount;
       CLOSE Get_gop_tot_utilised_amt; 
           
  END IF;


RETURN v_utilized_amount;
  
END get_utlized_amnt;
--####################################################################################################  
END DISPLAY_OF_BENEFITS;

/

--------------------------------------------------------
--  DDL for Synonymn CLM_CASH_BENEFIT_BILLS_SEQ
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."CLM_CASH_BENEFIT_BILLS_SEQ" FOR "APP"."CLM_CASH_BENEFIT_BILLS_SEQ";

--------------------------------------------------------
--  DDL for Synonymn COURIER_DISPATCH_DETAILS
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."COURIER_DISPATCH_DETAILS" FOR "INTX"."COURIER_DISPATCH_DETAILS";

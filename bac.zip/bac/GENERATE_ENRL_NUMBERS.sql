--------------------------------------------------------
--  DDL for Synonymn GENERATE_ENRL_NUMBERS
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."GENERATE_ENRL_NUMBERS" FOR "APP"."GENERATE_ENRL_NUMBERS";

--------------------------------------------------------
--  DDL for Synonymn AILMENTS_MEM_WISE
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."AILMENTS_MEM_WISE" FOR "APP"."AILMENTS_MEM_WISE";

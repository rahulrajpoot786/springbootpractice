--------------------------------------------------------
--  DDL for Synonymn CPT_CODE_MASTER
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."CPT_CODE_MASTER" FOR "APP"."CPT_CODE_MASTER";

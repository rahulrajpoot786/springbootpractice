--------------------------------------------------------
--  DDL for Synonymn HAAD_AGGREED_FACTOR_BSPY
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."HAAD_AGGREED_FACTOR_BSPY" FOR "APP"."HAAD_AGGREED_FACTOR_BSPY";

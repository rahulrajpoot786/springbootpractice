--------------------------------------------------------
--  DDL for Synonymn CITIBANK_REPORTS
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."CITIBANK_REPORTS" FOR "APP"."CITIBANK_REPORTS";

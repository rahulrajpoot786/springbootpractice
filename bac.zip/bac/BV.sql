--------------------------------------------------------
--  DDL for Procedure BV
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "VENUBABU"."BV" as
v_a number(10):=10;
v_b number(10):=20;
v_c number(10);
begin
v_c:=v_a+v_b;
end;

/

--------------------------------------------------------
--  DDL for Synonymn CLM_ASSO_ERROR_LOG
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."CLM_ASSO_ERROR_LOG" FOR "FIN_APP"."CLM_ASSO_ERROR_LOG";

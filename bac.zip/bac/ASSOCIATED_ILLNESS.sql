--------------------------------------------------------
--  DDL for Synonymn ASSOCIATED_ILLNESS
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."ASSOCIATED_ILLNESS" FOR "APP"."ASSOCIATED_ILLNESS";

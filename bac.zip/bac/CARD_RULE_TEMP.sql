--------------------------------------------------------
--  DDL for Synonymn CARD_RULE_TEMP
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."CARD_RULE_TEMP" FOR "APP"."CARD_RULE_TEMP";

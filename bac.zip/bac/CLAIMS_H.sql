--------------------------------------------------------
--  DDL for Synonymn CLAIMS_H
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."CLAIMS_H" FOR "APP"."CLAIMS_H";

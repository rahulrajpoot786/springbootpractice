--------------------------------------------------------
--  DDL for Synonymn DHPO_NEW_TRANSACTION_DOWNLOAD
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "VENUBABU"."DHPO_NEW_TRANSACTION_DOWNLOAD" FOR "APP"."DHPO_NEW_TRANSACTION_DOWNLOAD";

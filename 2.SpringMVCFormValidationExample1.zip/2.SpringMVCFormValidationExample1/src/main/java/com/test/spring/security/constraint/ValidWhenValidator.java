package com.test.spring.security.constraint;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import org.springframework.expression.Expression;
import org.springframework.expression.spel.standard.SpelExpressionParser;



public class ValidWhenValidator implements ConstraintValidator<ValidWhen, Object>{
	private ValidWhen validWhen;
	private String message;
	private String fieldName;
	@Override
	public void initialize(ValidWhen validWhen) {
		this.validWhen=validWhen;
		this.message = validWhen.message();
		this.fieldName = validWhen.fieldName();
	}

	@Override
	public boolean isValid(Object cmdObject, ConstraintValidatorContext context) {
		boolean status=true;
		try{
          String strExp=validWhen.expression();
          
			//System.out.println("             strExp  : "+strExp);

			if(strExp == null||strExp.trim().length()<1) throw new IllegalArgumentException("expression should not empty");

			Expression  expression= new SpelExpressionParser().parseExpression(strExp);
			status=expression.getValue(cmdObject,Boolean.class);
		}catch(Exception exception){
			context.disableDefaultConstraintViolation();
			context.buildConstraintViolationWithTemplate("Unkown Error Occurred Please Contact Administrator").addConstraintViolation();

			exception.printStackTrace();
			status=false;
		}
		
		if (!status){
            context.buildConstraintViolationWithTemplate(message)
                    .addPropertyNode(fieldName)
                    .addConstraintViolation()
                    .disableDefaultConstraintViolation();
        }
		return status;
	}


}

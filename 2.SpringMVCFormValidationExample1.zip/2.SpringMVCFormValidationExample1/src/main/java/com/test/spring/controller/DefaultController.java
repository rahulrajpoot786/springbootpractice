package com.test.spring.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.test.spring.dto.LoginVO;

@Controller
public class DefaultController {

	@RequestMapping(value = {"/"})
	public String defaultPage() {
		
		
		return "login";
	}
	
	@ModelAttribute("loginmodel")
	public LoginVO setup() {
		
		return new LoginVO();
	}
}

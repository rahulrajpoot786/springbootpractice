package com.test.spring.dto;

import com.test.spring.security.constraint.ValidWhen;

@ValidWhen.List({
	@ValidWhen(fieldName ="password",expression = "((password != ''))", message = "'Password' is required."),
	@ValidWhen(fieldName ="empanelId",expression = "((empanelId != ''))", message = "'Empanelment Id' is required."),
		/*
		 * @ValidWhen(fieldName ="empanelId",expression =
		 * "((empanelId != '') or (loginType !='PTR'))", message =
		 * "'Partner Id' is required."),
		 */
	@ValidWhen(fieldName ="userId",expression = "((userId != ''))", message = "'User Id' is required.")
	
})
public class LoginVO {

    private String empanelId;
	
	private String userId="";
	
	private String password="";
	
	private String loginType="";
	
	private String firstLoginYN = "";

	public String getEmpanelId() {
		return empanelId;
	}

	public void setEmpanelId(String empanelId) {
		this.empanelId = empanelId;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getLoginType() {
		return loginType;
	}

	public void setLoginType(String loginType) {
		this.loginType = loginType;
	}

	public String getFirstLoginYN() {
		return firstLoginYN;
	}

	public void setFirstLoginYN(String firstLoginYN) {
		this.firstLoginYN = firstLoginYN;
	}
	
	
	
}

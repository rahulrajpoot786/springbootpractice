package com.test.spring.controller;

import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.test.spring.dto.LoginVO;

@Controller
public class LoginController {

	@RequestMapping(value = {"/loginsubmit"})
	public String doLogin(@Valid @ModelAttribute("loginmodel") LoginVO login, BindingResult result) {

		if(result.hasErrors()) {
			
			return "login";
		}
		
		return "welcome";
	}
}

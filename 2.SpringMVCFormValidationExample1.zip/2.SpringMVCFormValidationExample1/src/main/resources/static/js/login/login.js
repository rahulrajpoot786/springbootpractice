function onlogin(){
	
	document.forms['loginForm'].action='loginsubmit';
	document.forms['loginForm'].submit();
}
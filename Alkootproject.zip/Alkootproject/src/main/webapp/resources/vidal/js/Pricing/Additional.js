function doSave()
{
    var  claimsubmisionvalue= $("#levelofcover").val();
    var  approvallimit= $("#approvallimit").val();
    var deductablecoinsurance=$("#deductiblecoinsurance").val();
    var outsidearea=$("#outsideareaofcover").val();
    var parentaccomdation=$("#inpatientdailyroomboadrd").val();
    var parentagelimt=$("#inpatientdailylimt").val();
    var companionaccomadtion=$("#parentaccomdationn").val();
    var comapionagelimit=$("#strinpatientcashd").val();
    var inpatientcash=$("#inpatientlimit").val();
    var alternatevsession=$("#alternativesessionlimit").val();
   
    if(!valiFormAdditional()){
    	return false;
    }
    
    if(claimsubmisionvalue == "" ){
        swal("Please select 'claims submission timeline'.");
        return false;
       
    }else if(approvallimit =="" ){
       
        swal("Please select 'OP Prior approval limit'.");
        return false;
    }else if(deductablecoinsurance ==""){
        swal("Please select 'Deductible/coinsurance on consultations'.");
        return false;
    }
    else if(outsidearea ==""){
        swal("Please select 'Outside area of cover'.");
        return false;
    }else if(parentaccomdation == "" ){
        swal("Please select 'Parent accomodation'.");
        return false;
    }
    else if(parentaccomdation != ""  && parentagelimt=="" && parentaccomdation !='488'){
        swal("Please select 'Parent accomodation age limit'.");
        return false;
    }else if(companionaccomadtion == "" ){
        swal("Please select 'Companion accomodation'.");
        return false;
    }
    else if(companionaccomadtion != ""  && comapionagelimit=="" && companionaccomadtion !='489'){
        swal("Please select 'Companion accomodation age limit'.");
        return false;
    }else if(inpatientcash == ""){
        swal("Please select 'Inpatient cash benefit'.");
        return false;
    }else if(alternatevsession ==""){
        swal("Please select 'Alternative/Complementary treatment sessions'.");
        return false;
    }
        else{
   
            setDescValues();
              
             swal({           
                  text: "The benefits which have not been checked will be considered as 'Not covered'. Please review the benefits carefully and click 'OK'to proceed.",
                  buttons: true,
                  infoMode: true,
                })
                .then((willDelete) => {
                  if (willDelete) {
                      document.forms["Additional"].action =contextpath+"/SoftwareInsurancePricing/AdditionalBenefitssave";
                        document.forms["Additional"].submit();
                  }
                });
           
    }
 
}

function onparentaccchange(obj){
    if(obj.value =='' ||obj.value =='488')
        {
         document.getElementById("strinpatientboadrd").disabled=true;
     document.getElementById("strinpatientboadrd").value='';
        }
    else{
         document.getElementById("strinpatientboadrd").disabled=false;
       
}
}
function oncompanionchange(obj){
    if(obj.value =='' ||obj.value =='489')
        {
         document.getElementById("strinpatientcashd").disabled=true;
     document.getElementById("strinpatientcashd").value='';
        }
    else{
         document.getElementById("strinpatientcashd").disabled=false;
       
}
}



function valiFormAdditional(){
	
	var  outsidearea = document.getElementById("outsideareaofcover").value;
	//Inpatient treatment
	var parentAcoo = document.getElementById("inpatientdailyroomboadrd").value;

	var ParentAccomodationAgeLimit =  document.getElementById("strinpatientboadrd").value;

	var CompanionAccomodation  = document.getElementById("parentaccomdationn").value;
	var CompanionAccomodationAgeLimit = document.getElementById("strinpatientcashd").value;
	var InpatientCashBenefit = document.getElementById("inpatientlimit").value;
	//Outpatient treatment
	
	var physiotherapy = document.getElementById("PhysiotherapyYN").value;
	var physiotherapylimit = document.getElementById("Physiotherepylimit").value;
/*	var physiotherapySessions = document.getElementById("PhysiotherepySession").value;*/
	var alternativeComplementary = document.getElementById("alternativetreatmentYN").value;
	var alternativeComplementaryTreatmentLimit = document.getElementById("alternativetreatmentlimit").value;
	var alternativeComplementaryTreatmentCopay = document.getElementById("alternativecopay").value;
	var alternativeComplementaryTreatmentSessions =document.getElementById("alternativesessionlimit").value;
	
	//Maternity: Pregnency and childbirth
	
	var pregnancychildbirth = document.getElementById("pregnancy").value;
	var newborncover = document.getElementById("newbornYN").value;
	var Prepostnatalcomplications = document.getElementById("PreandpostYN").value;
	var PrepostNatalcomplicationslimit = document.getElementById("Preandpostnatal").value;
	
	//Dental Prosthesis
	 
	var dentalProsthesis = document.getElementById("dentalprothis").value;
	
	// Core benefits
	
	var preexistingConditions = document.getElementById("preexistingcoadtionYN").value;
	var preexistingconditionslimit = document.getElementById("Preexistingconditon").value;
	
	var maintenanceChronicConditions = document.getElementById("maintenancecoadtionYN").value;
	var maintenancechronicConditionsLimit = document.getElementById("maintenanceofChronic").value;
	
    var hormoneReplacementTherapy =  document.getElementById("harmonereplaceYN").value;
	var hormoneReplacementTherapyLimit = document.getElementById("hormone").value;
	var inpatientRehabilitation = document.getElementById("inpatientrehabationYN").value;
	var inpatientRehabilitationLimit = document.getElementById("inpatientt").value;
	var nursingHome = document.getElementById("nursinghomeYN").value;
	var nursingHomeLimit = document.getElementById("nursingdrop").value;
	var oralmaxillofacialSurgery = document.getElementById("oralmax").value;
	var vitamins = document.getElementById("VitaminsmedYN").value;
	var vitaminsLimit = document.getElementById("Vitamins").value;
	var acutePhasechronicConditions= document.getElementById("stracute").value;
	var ambulance = document.getElementById("strambulanace").value;
	var accidentaldamageTeeth = document.getElementById("stracendental").value;
	var eviatedNasalSeptum = document.getElementById("strdevated").value;
	var reconstructiveSurgery = document.getElementById("checkconstructiveId").value;
	var organtransplant = document.getElementById("Organtransplant").value;
	var OrganTransplantLimit = document.getElementById("organlimit").value;
	
	
	//Other benefits
	
	var internationalEmergencyMedicalAssistance = document.getElementById("internationalYN").value;
	var InternationalEmergencyMedicalAssistanceLimit = document.getElementById("internationalEmergencylimit1").value;
	
	var RadiotherapychemotherapyTomography = document.getElementById("radiography1").value;
	var congenitalConditions = document.getElementById("congtal").value;
	var psychiatricTreatment  = document.getElementById("psychiatricYN").value;
	var psychiatryLimit = document.getElementById("psychiatrylimit1").value;
	var psychiatryCopay = document.getElementById("psychiatrylimitCopay2").value;
	var oncology = document.getElementById("oncology").value;
	var vaccinationEmmunization = document.getElementById("VaccinationYN").value;
	var VaccinationImmunizationLimit = document.getElementById("vaccinationslimit").value;
	var VaccinationImmunizationAgeLimit = document.getElementById("Vaccinatioage1").value;
	var RepatriationMortalRemains = document.getElementById("repatriation").value;
	var gumSurgery = document.getElementById("gumsurgery").value;
	var deductibleCoinsuranceConsultations = document.getElementById("deductiblecoinsurance").value;
	var externalProsthesis = document.getElementById("externalprothisYN").value;
	var externalProsthesisLimit = document.getElementById("ExternalProsthesisdrop").value;
	var workRelatedInjuries = document.getElementById("workrelateddrop1").value;
	var WorkRelatedInjuriesLimit = document.getElementById("workrelateddrop").value;
	var lifeThreateningDiseases = document.getElementById("lifeThreateningdiease").value;
	var lifeThreateningDiseasesLimit = document.getElementById("lifediseasecdrop").value;
	var gastricBindingsSleeving =  document.getElementById("obesitysurgryYN").value;
	var gastricBindingsSleevingLimit  =  document.getElementById("obesite").value;
	var hospicePalliativeTreatment = document.getElementById("hospiceYN").value;
	var hospicePalliativeTreatmentLimit = document.getElementById("hospiceandPalliativedrop").value;
	
	var externalMedicalAppliances =  document.getElementById("externalmedYN").value;
	var externalMedicalAppliancesLimit = document.getElementById("externalmedicaldrop").value;
	var externalMedicalAppliancesCopay = document.getElementById("externalmedicalcopay").value;
	var dietician = document.getElementById("dieticanYN").value;
	var dieticianLimit = document.getElementById("ditecianlimitdrop").value;
	var hivAids =  document.getElementById("hivYN").value;
	var hivAidsLimit = document.getElementById("hIVandaIDSLimitdrop").value;
	var circumcision = document.getElementById("circumcisionYN").value;
	var circumcisionLimit =  document.getElementById("circumcisionlimitdrop").value;
	var compassionateEmergencyvisit = document.getElementById("compassionateYN").value;
	var compassionateEmergencyVisitLimit = document.getElementById("compassionatevisitdrop").value;
	var terminalIllness = document.getElementById("terminal").value;
	var claimsSubmissionTimeline = document.getElementById("levelofcover").value;
	var oPPriorApprovalLimit = document.getElementById("approvallimit").value;
	
	var alternativeTreatments = document.getElementById("AlternativeTreatments").value;
	var reimbursmentLevel = document.getElementById("ReimbursmentLevel").value;
	
	var healthCheckYn =  document.getElementById("healthYN").value;
	var healthCheckScreeningLimit  =  document.getElementById("healthscreenlimitdrop").value;
	var healthCheckScreeningCopay =  document.getElementById("healthscreencopay").value;
	
	
	if(outsidearea == '' || outsidearea == null || outsidearea == ""){
		
		swal({								
			  text:"\'Outside area of cover\' is required.",
			  buttons: true,
			  infoMode: true,
			})
			.then((willDelete) => {
			  if (willDelete) {
				$("#outsideareaofcover").focus();
			  } 
			});
		
		return false;			
	}
		       
if(parentAcoo == '' || parentAcoo == null || parentAcoo == ""){
		
		swal({								
			  text:"\'Parent accomodation\' is required.",
			  buttons: true,
			  infoMode: true,
			})
			.then((willDelete) => {
			  if (willDelete) {
				$("#inpatientdailyroomboadrd").focus();
			  } 
			});
		
		return false;			
	}
	

if(parentAcoo !='488' && parentAcoo != ''){
	
	if(ParentAccomodationAgeLimit == null || ParentAccomodationAgeLimit == '' || ParentAccomodationAgeLimit == "") {
	swal({								
		  text:"\'Parent accomodation age limit\' is required.",
		  buttons: true,
		  infoMode: true,
		})
		.then((willDelete) => {
		  if (willDelete) {
			$("#strinpatientboadrd").focus();
		  } 
		});
	
	return false;		
	}
}
	
	
if(CompanionAccomodation == '' || CompanionAccomodation == null || CompanionAccomodation == ""){
	
	swal({								
		  text:"\'Companion accomodation\' is required.",
		  buttons: true,
		  infoMode: true,
		})
		.then((willDelete) => {
		  if (willDelete) {
			$("#parentaccomdationn").focus();
		  } 
		});
	
	return false;			
}

	
if(CompanionAccomodation !='489' && CompanionAccomodation != ''){
	
	if(CompanionAccomodationAgeLimit == null || CompanionAccomodationAgeLimit == '' || CompanionAccomodationAgeLimit == "") {
		swal({								
			  text:"\'Companion accomodation age limit\' is required.",
			  buttons: true,
			  infoMode: true,
			})
			.then((willDelete) => {
			  if (willDelete) {
				$("#strinpatientcashd").focus();
			  } 
			});
		
		return false;		
		}
}


if(InpatientCashBenefit == '' || InpatientCashBenefit == null || InpatientCashBenefit == ""){
	
	swal({								
		  text:"\'Inpatient cash benefit\' is required.",
		  buttons: true,
		  infoMode: true,
		})
		.then((willDelete) => {
		  if (willDelete) {
			$("#inpatientlimit").focus();
		  } 
		});
	
	return false;			
}




if(pregnancychildbirth == '' || pregnancychildbirth == null || pregnancychildbirth == ""){
	
	swal({								
		  text:"\'Pregnancy and childbirth\' is required.",
		  buttons: true,
		  infoMode: true,
		})
		.then((willDelete) => {
		  if (willDelete) {
			$("#pregnancy").focus();
		  } 
		});
	
	return false;			
}

/*if(newborncover == 'N'){		
	swal({								
		  text:"\'Newborn cover\' is required.",
		  buttons: true,
		  infoMode: true,
		})
		.then((willDelete) => {
		  if (willDelete) {
			$("#newbornYN").focus();
		  } 
		});
	
	return false;		
	
}
*/
if(Prepostnatalcomplications == 'Y'){
	
	if(PrepostNatalcomplicationslimit == null || PrepostNatalcomplicationslimit == '' || PrepostNatalcomplicationslimit =="") {
	swal({								
		  text:"\'Pre- and post-natal complications limit\' is required.",
		  buttons: true,
		  infoMode: true,
		})
		.then((willDelete) => {
		  if (willDelete) {
			$("#Preandpostnatal").focus();
		  } 
		});
	
	return false;		
	}
}



if(dentalProsthesis == null || dentalProsthesis == '' || dentalProsthesis =="") {
	swal({								
		  text:"\'Dental prosthesis\' is required.",
		  buttons: true,
		  infoMode: true,
		})
		.then((willDelete) => {
		  if (willDelete) {
			$("#dentalprothis").focus();
		  } 
		});
	
	return false;		
	}
	
	

if(physiotherapy == 'Y'){
	
	if(physiotherapylimit == null || physiotherapylimit == '' || physiotherapylimit =="") {
	swal({								
		  text:"\'Physiotherapy limit\' is required.",
		  buttons: true,
		  infoMode: true,
		})
		.then((willDelete) => {
		  if (willDelete) {
			$("#Physiotherepylimit").focus();
		  } 
		});
	
	return false;		
	}
}



if(alternativeComplementary == 'Y'){
	
	if(alternativeComplementaryTreatmentLimit == null || alternativeComplementaryTreatmentLimit == '' || alternativeComplementaryTreatmentLimit =="") {
	swal({								
		  text:"\'Alternative/Complementary treatment limit\' is required.",
		  buttons: true,
		  infoMode: true,
		})
		.then((willDelete) => {
		  if (willDelete) {
			$("#alternativetreatmentlimit").focus();
		  } 
		});
	
	return false;		
	}
}

if(alternativeComplementary == 'Y'){
	
	if(alternativeComplementaryTreatmentCopay == null || alternativeComplementaryTreatmentCopay == '' || alternativeComplementaryTreatmentCopay =="") {
	swal({								
		  text:"\'Alternative/Complementary treatment copay\' is required.",
		  buttons: true,
		  infoMode: true,
		})
		.then((willDelete) => {
		  if (willDelete) {
			$("#alternativecopay").focus();
		  } 
		});
	
	return false;		
	}
}



if(alternativeComplementaryTreatmentSessions == null || alternativeComplementaryTreatmentSessions == '' || alternativeComplementaryTreatmentSessions == ""){
	
	swal({								
		  text:"\'Alternative/Complementary treatment sessions\' is required.",
		  buttons: true,
		  infoMode: true,
		})
		.then((willDelete) => {
		  if (willDelete) {
			$("#alternativesessionlimit").focus();
		  } 
		});
	
	return false;		
	
} 


if(preexistingConditions == 'Y'){
	
	if(preexistingconditionslimit == null || preexistingconditionslimit == '' || preexistingconditionslimit =="") {
	swal({								
		  text:"\'Pre-existing conditions limit\' is required.",
		  buttons: true,
		  infoMode: true,
		})
		.then((willDelete) => {
		  if (willDelete) {
			$("#Preexistingconditon").focus();
		  } 
		});
	
	return false;		
	}
}

if(maintenanceChronicConditions == 'Y'){
	
	if(maintenancechronicConditionsLimit == null || maintenancechronicConditionsLimit == '' || maintenancechronicConditionsLimit =="") {
	swal({								
		  text:"\'Maintenance of chronic conditions limit\' is required.",
		  buttons: true,
		  infoMode: true,
		})
		.then((willDelete) => {
		  if (willDelete) {
			$("#maintenanceofChronic").focus();
		  } 
		});
	
	return false;		
	}
}

if(hormoneReplacementTherapy == 'Y'){
	
	if(hormoneReplacementTherapyLimit == null || hormoneReplacementTherapyLimit == '' || hormoneReplacementTherapyLimit =="") {
	swal({								
		  text:"\'Hormone replacement therapy limit\' is required.",
		  buttons: true,
		  infoMode: true,
		})
		.then((willDelete) => {
		  if (willDelete) {
			$("#hormone").focus();
		  } 
		});
	
	return false;		
	}
}

if(inpatientRehabilitation == 'Y'){
	
	if(inpatientRehabilitationLimit == null || inpatientRehabilitationLimit == '' || inpatientRehabilitationLimit =="") {
	swal({								
		  text:"\'Inpatient rehabilitation limit\' is required.",
		  buttons: true,
		  infoMode: true,
		})
		.then((willDelete) => {
		  if (willDelete) {
			$("#inpatientt").focus();
		  } 
		});
	
	return false;		
	}
}


if(nursingHome == 'Y'){
	
	if(nursingHomeLimit == null || nursingHomeLimit == '' || nursingHomeLimit =="") {
	swal({								
		  text:"\'Nursing at home limit\' is required.",
		  buttons: true,
		  infoMode: true,
		})
		.then((willDelete) => {
		  if (willDelete) {
			$("#nursingdrop").focus();
		  } 
		});
	
	return false;		
	}
}


/*if(oralmaxillofacialSurgery == 'N'){
	
	swal({								
		  text:"\'Oral and maxillofacial surgery\' is required.",
		  buttons: true,
		  infoMode: true,
		})
		.then((willDelete) => {
		  if (willDelete) {
			$("#nursingdrop").focus();
		  } 
		});
	
	return false;	
}*/


if(vitamins == 'Y'){
	
	if(vitaminsLimit == null || vitaminsLimit == '' || vitaminsLimit =="") {
	swal({								
		  text:"\'Vitamins limit\' is required.",
		  buttons: true,
		  infoMode: true,
		})
		.then((willDelete) => {
		  if (willDelete) {
			$("#Vitamins").focus();
		  } 
		});
	
	return false;		
	}
}

if(organtransplant == 'Y'){
if(OrganTransplantLimit ==null || OrganTransplantLimit =="" || OrganTransplantLimit ==''){
	swal({								
		  text:"\'Organ transplant limit\' is required.",
		  buttons: true,
		  infoMode: true,
		})
		.then((willDelete) => {
		  if (willDelete) {
			$("#organlimit").focus();
		  } 
		});
	
	return false;
}
}


if(internationalEmergencyMedicalAssistance == 'Y'){
	
	if(InternationalEmergencyMedicalAssistanceLimit == null || InternationalEmergencyMedicalAssistanceLimit == '' || InternationalEmergencyMedicalAssistanceLimit =="") {
	swal({								
		  text:"\'International emergency medical assistance limit\' is required.",
		  buttons: true,
		  infoMode: true,
		})
		.then((willDelete) => {
		  if (willDelete) {
			$("#internationalEmergencylimit1").focus();
		  } 
		});
	
	return false;		
	}
}

/*if(RadiotherapychemotherapyTomography == 'N'){
	swal({								
		  text:"\'Radiotherapy, chemotherapy and tomography \' is required.",
		  buttons: true,
		  infoMode: true,
		})
		.then((willDelete) => {
		  if (willDelete) {
			$("#radiography1").focus();
		  } 
		});
	
	return false;		
	}*/


  if(congenitalConditions == null || congenitalConditions == '' || congenitalConditions ==""){
	  swal({								
		  text:"\'Congenital conditions\' is required.",
		  buttons: true,
		  infoMode: true,
		})
		.then((willDelete) => {
		  if (willDelete) {
			$("#congtal").focus();
		  } 
		});
	
	return false;	
	  
  }
  
  if(psychiatricTreatment == 'Y'){
		
		if(psychiatryLimit == null || psychiatryLimit == '' || psychiatryLimit =="") {
		swal({								
			  text:"\'Psychiatry limit\' is required.",
			  buttons: true,
			  infoMode: true,
			})
			.then((willDelete) => {
			  if (willDelete) {
				$("#psychiatrylimit1").focus();
			  } 
			});
		
		return false;		
		}
	}
  
  if(psychiatricTreatment == 'Y'){
		
		if(psychiatryCopay == null || psychiatryCopay == '' || psychiatryCopay =="") {
		swal({								
			  text:"\'Psychiatry copay\' is required.",
			  buttons: true,
			  infoMode: true,
			})
			.then((willDelete) => {
			  if (willDelete) {
				$("#psychiatrylimitCopay2").focus();
			  } 
			});
		
		return false;		
		}
	}
  
  
  if(oncology == null || oncology =='' || oncology ==""){
	  
	  swal({								
		  text:"\'Oncology\' is required.",
		  buttons: true,
		  infoMode: true,
		})
		.then((willDelete) => {
		  if (willDelete) {
			$("#oncology").focus();
		  } 
		});
	
	return false;			  
	  
  }
	


  if(vaccinationEmmunization == 'Y'){
		
		if(VaccinationImmunizationLimit == null || VaccinationImmunizationLimit == '' || VaccinationImmunizationLimit =="") {
		swal({								
			  text:"\'Vaccination & immunization limit\' is required.",
			  buttons: true,
			  infoMode: true,
			})
			.then((willDelete) => {
			  if (willDelete) {
				$("#vaccinationslimit").focus();
			  } 
			});
		
		return false;		
		}
	}
  
  if(vaccinationEmmunization == 'Y'){
		
		if(VaccinationImmunizationAgeLimit == null || VaccinationImmunizationAgeLimit == '' || VaccinationImmunizationAgeLimit =="") {
		swal({								
			  text:"\'Vaccination & immunization age limit\' is required.",
			  buttons: true,
			  infoMode: true,
			})
			.then((willDelete) => {
			  if (willDelete) {
				$("#Vaccinatioage1").focus();
			  } 
			});
		
		return false;		
		}
	}

  if(RepatriationMortalRemains ==null || RepatriationMortalRemains =='' || RepatriationMortalRemains ==""){
	  
	  swal({								
		  text:"\'Repatriation of mortal remains\' is required.",
		  buttons: true,
		  infoMode: true,
		})
		.then((willDelete) => {
		  if (willDelete) {
			$("#repatriation").focus();
		  } 
		});
	
	return false;		 
	  
  }
  
  
/*  if(gumSurgery == 'N'){
	  swal({								
		  text:"\'Gum surgery\' is required.",
		  buttons: true,
		  infoMode: true,
		})
		.then((willDelete) => {
		  if (willDelete) {
			$("#gumsurgery").focus();
		  } 
		});
	
	return false;		  
  }*/
  
  if(deductibleCoinsuranceConsultations == null || deductibleCoinsuranceConsultations == '' || deductibleCoinsuranceConsultations ==""){
	  swal({								
		  text:"\'Deductible/coinsurance on consultations\' is required.",
		  buttons: true,
		  infoMode: true,
		})
		.then((willDelete) => {
		  if (willDelete) {
			$("#deductiblecoinsurance").focus();
		  } 
		});
	
	return false;	
  }
  
  
  if(externalProsthesis == 'Y'){
		
		if(externalProsthesisLimit == null || externalProsthesisLimit == '' || externalProsthesisLimit =="") {
		swal({								
			  text:"\'External prosthesis limit\' is required.",
			  buttons: true,
			  infoMode: true,
			})
			.then((willDelete) => {
			  if (willDelete) {
				$("#ExternalProsthesisdrop").focus();
			  } 
			});
		
		return false;		
		}
	}
  
  if(workRelatedInjuries == 'Y'){		
		if(WorkRelatedInjuriesLimit == null || WorkRelatedInjuriesLimit == '' || WorkRelatedInjuriesLimit =="") {
		swal({								
			  text:"\'Work related injuries limit\' is required.",
			  buttons: true,
			  infoMode: true,
			})
			.then((willDelete) => {
			  if (willDelete) {
				$("#workrelateddrop").focus();
			  } 
			});
		
		return false;		
		}
	}
  
  if(lifeThreateningDiseases == 'Y'){		
		if(lifeThreateningDiseasesLimit == null || lifeThreateningDiseasesLimit == '' || lifeThreateningDiseasesLimit =="") {
		swal({								
			  text:"\'Life threatening diseases limit\' is required.",
			  buttons: true,
			  infoMode: true,
			})
			.then((willDelete) => {
			  if (willDelete) {
				$("#lifediseasecdrop").focus();
			  } 
			});
		
		return false;		
		}
	}
  
  
  if(gastricBindingsSleeving == 'Y'){		
		if(gastricBindingsSleevingLimit == null || gastricBindingsSleevingLimit == '' || gastricBindingsSleevingLimit =="") {
		swal({								
			  text:"\'Gastric Bindings / Sleeving limit\' is required.",
			  buttons: true,
			  infoMode: true,
			})
			.then((willDelete) => {
			  if (willDelete) {
				$("#obesite").focus();
			  } 
			});
		
		return false;		
		}
	}
  
  if(hospicePalliativeTreatment == 'Y'){		
		if(hospicePalliativeTreatmentLimit == null || hospicePalliativeTreatmentLimit == '' || hospicePalliativeTreatmentLimit =="") {
		swal({								
			  text:"\'Hospice and palliative treatment limit\' is required.",
			  buttons: true,
			  infoMode: true,
			})
			.then((willDelete) => {
			  if (willDelete) {
				$("#hospiceandPalliativedrop").focus();
			  } 
			});
		
		return false;		
		}
	}

  
  if(externalMedicalAppliances == 'Y'){		
		if(externalMedicalAppliancesLimit == null || externalMedicalAppliancesLimit == '' || externalMedicalAppliancesLimit =="") {
		swal({								
			  text:"\'External medical appliances limit\' is required.",
			  buttons: true,
			  infoMode: true,
			})
			.then((willDelete) => {
			  if (willDelete) {
				$("#externalmedicaldrop").focus();
			  } 
			});
		
		return false;		
		}
	}
  
  if(externalMedicalAppliances == 'Y'){		
		if(externalMedicalAppliancesCopay == null || externalMedicalAppliancesCopay == '' || externalMedicalAppliancesCopay =="") {
		swal({								
			  text:"\'External medical appliances copay\' is required.",
			  buttons: true,
			  infoMode: true,
			})
			.then((willDelete) => {
			  if (willDelete) {
				$("#externalmedicalcopay").focus();
			  } 
			});
		
		return false;		
		}
	}
  
  if(dietician == 'Y'){		
		if(dieticianLimit == null || dieticianLimit == '' || dieticianLimit =="") {
		swal({								
			  text:"\'Dietician limit\' is required.",
			  buttons: true,
			  infoMode: true,
			})
			.then((willDelete) => {
			  if (willDelete) {
				$("#ditecianlimitdrop").focus();
			  } 
			});
		
		return false;		
		}
	}
  
  if(hivAids == 'Y'){		
		if(hivAidsLimit == null || hivAidsLimit == '' || hivAidsLimit =="") {
		swal({								
			  text:"\'HIV and AIDS limit\' is required.",
			  buttons: true,
			  infoMode: true,
			})
			.then((willDelete) => {
			  if (willDelete) {
				$("#hIVandaIDSLimitdrop").focus();
			  } 
			});
		
		return false;		
		}
	}
  
  if(circumcision == 'Y'){		
		if(circumcisionLimit == null || circumcisionLimit == '' || circumcisionLimit =="") {
		swal({								
			  text:"\'Circumcision limit\' is required.",
			  buttons: true,
			  infoMode: true,
			})
			.then((willDelete) => {
			  if (willDelete) {
				$("#circumcisionlimitdrop").focus();
			  } 
			});
		
		return false;		
		}
	}
  
  if(compassionateEmergencyvisit == 'Y'){		
		if(compassionateEmergencyVisitLimit == null || compassionateEmergencyVisitLimit == '' || compassionateEmergencyVisitLimit =="") {
		swal({								
			  text:"\'Compassionate emergency visit limit\' is required.",
			  buttons: true,
			  infoMode: true,
			})
			.then((willDelete) => {
			  if (willDelete) {
				$("#compassionatevisitdrop").focus();
			  } 
			});
		
		return false;		
		}
	}
  
  if(claimsSubmissionTimeline == null || claimsSubmissionTimeline =='' || claimsSubmissionTimeline ==""){
	  swal({								
		  text:"\'Claims submission timeline\' is required.",
		  buttons: true,
		  infoMode: true,
		})
		.then((willDelete) => {
		  if (willDelete) {
			$("#levelofcover").focus();
		  } 
		});
	
	return false;		
  }
  
  if(oPPriorApprovalLimit == null || oPPriorApprovalLimit =='' || oPPriorApprovalLimit ==""){
	  swal({								
		  text:"\'OP Prior approval limit\' is required.",
		  buttons: true,
		  infoMode: true,
		})
		.then((willDelete) => {
		  if (willDelete) {
			$("#approvallimit").focus();
		  } 
		});
	
	return false;		
  }
  
  if(alternativeTreatments ==null || alternativeTreatments  =='' || alternativeTreatments  ==""){
	  swal({								
		  text:"\'Alternative treatments\' is required.",
		  buttons: true,
		  infoMode: true,
		})
		.then((willDelete) => {
		  if (willDelete) {
			$("#AlternativeTreatments").focus();
		  } 
		});
	
	return false;		
  }
  
  
  if(terminalIllness == null || terminalIllness == '' || terminalIllness == ""){
		 swal({								
			  text:"\'Terminal illness\' is required.",
			  buttons: true,
			  infoMode: true,
			})
			.then((willDelete) => {
			  if (willDelete) {
				$("#terminal").focus();
			  } 
			});
		
		return false;		
	  }
  
  
  
  if(healthCheckYn == 'Y'){		
		if(healthCheckScreeningLimit == null || healthCheckScreeningLimit == '' || healthCheckScreeningLimit == "") {
		swal({								
			  text:"\'Health check-up/screening limit\' is required.",
			  buttons: true,
			  infoMode: true,
			})
			.then((willDelete) => {
			  if (willDelete) {
				$("#healthscreenlimitdrop").focus();
			  } 
			});
		
		return false;		
		}
	}
  
  
  if(healthCheckYn == 'Y'){		
		if(healthCheckScreeningCopay == null || healthCheckScreeningCopay == '' || healthCheckScreeningCopay == "") {
		swal({								
			  text:"\'Health check-up/screening copay/deductible\' is required.",
			  buttons: true,
			  infoMode: true,
			})
			.then((willDelete) => {
			  if (willDelete) {
				$("#healthscreencopay").focus();
			  } 
			});
		
		return false;		
		}
	}
  
  
 if(reimbursmentLevel == null || reimbursmentLevel == '' || reimbursmentLevel == ""){
	 swal({								
		  text:"\'Reimbursment level\' is required.",
		  buttons: true,
		  infoMode: true,
		})
		.then((willDelete) => {
		  if (willDelete) {
			$("#ReimbursmentLevel").focus();
		  } 
		});
	
	return false;		
  }
  
  
  return true;

}

function fetch(){
	 document.forms["Additional"].action =contextpath+"/SoftwareInsurancePricing/Additionalfetch";
	    document.forms["Additional"].submit();
	
}

function setDescValues(){
	  
	 var PhysiotherepylimitIndex = document.forms[1].Physiotherepylimit.selectedIndex;
	 var PhysiotherepylimitText = document.forms[1].Physiotherepylimit.options[parseInt(PhysiotherepylimitIndex)].text;
	 document.forms[1].PhysiotherepylimitDesc.value=PhysiotherepylimitText;
	
	 
	 var strinpatientboadrdIndex = document.forms[1].strinpatientboadrd.selectedIndex;
	 var strinpatientboadrdText = document.forms[1].strinpatientboadrd.options[parseInt(strinpatientboadrdIndex)].text;
	 document.forms[1].strinpatientboadrdDesc.value=strinpatientboadrdText;	
	 
	 var parentaccomdationIndex = document.forms[1].parentaccomdation.selectedIndex;
	 var parentaccomdationText = document.forms[1].parentaccomdation.options[parseInt(parentaccomdationIndex)].text;
	 document.forms[1].parentaccomdationDesc.value=parentaccomdationText;	
	 
	 var strinpatientcashIndex = document.forms[1].strinpatientcash.selectedIndex;
	 var strinpatientcashText = document.forms[1].strinpatientcash.options[parseInt(strinpatientcashIndex)].text;
	 document.forms[1].strinpatientcashDesc.value=strinpatientcashText;	
	 
	/* var PhysiotherepySessionIndex = document.forms[1].PhysiotherepySession.selectedIndex;
	 var PhysiotherepySessionText = document.forms[1].PhysiotherepySession.options[parseInt(PhysiotherepySessionIndex)].text;
	 document.forms[1].PhysiotherepySessionDesc.value=PhysiotherepySessionText;	*/
	 
	 var alternativetreatmentlimitIndex = document.forms[1].alternativetreatmentlimit.selectedIndex;
	 var alternativetreatmentlimitText = document.forms[1].alternativetreatmentlimit.options[parseInt(alternativetreatmentlimitIndex)].text;
	 document.forms[1].alternativetreatmentlimitDesc.value=alternativetreatmentlimitText;	
	 

	 var e = document.getElementById("internationalEmergencylimit1");
	 var internationalEmergencylimit = e.options[e.selectedIndex].text;
	 document.forms[1].internationalEmergencylimitDesc.value=internationalEmergencylimit;
	 
	 var e = document.getElementById("psychiatrylimit1");
	 var psychiatrylimitIndex = e.options[e.selectedIndex].text;
	 document.forms[1].psychiatrylimitDesc.value=psychiatrylimitIndex;
	 
	 var e = document.getElementById("psychiatrylimitCopay2");
	 var psychiatrylimitCopay2Index = e.options[e.selectedIndex].text;
	 document.forms[1].psychiatrylimitCopayDesc.value=psychiatrylimitCopay2Index;
	
	 var e = document.getElementById("vaccinationslimit");
	 var vaccinationslimitDescIndex = e.options[e.selectedIndex].text;
	 document.forms[1].vaccinationslimitDesc.value=vaccinationslimitDescIndex;
	 
	 var e = document.getElementById("Vaccinatioage1");
	 var vaccinationsDesccIndex = e.options[e.selectedIndex].text;
	 document.forms[1].vaccinationsDesc.value=vaccinationsDesccIndex;
	 
	 var e = document.getElementById("Preexistingconditon");
	 var PreexistingconditonIndex = e.options[e.selectedIndex].text;
	 document.forms[1].PreexistingconditionslimitDesc.value=PreexistingconditonIndex;
	 
	 var e = document.getElementById("Preandpostnatal");
	 document.forms[1].PreandpostnatalDesc.value = e.options[e.selectedIndex].text;
	 
	/* var e = document.getElementById("wellbeingbenfittdrop");
	 document.forms[1].WellbeingbenefitDesc.value = e.options[e.selectedIndex].text;*/
	 
	 var e = document.getElementById("inpatientdailyroomboadrd");
	 document.forms[1].parentacmdation.value = e.options[e.selectedIndex].text;
	 
	 var e = document.getElementById("ExternalProsthesisdrop");
	 document.forms[1].ExternalProsthesisDesc.value = e.options[e.selectedIndex].text;
	 
	 var e = document.getElementById("workrelateddrop");
	 document.forms[1].workrelatedDesc.value = e.options[e.selectedIndex].text;
	 
	 var e = document.getElementById("lifediseasecdrop");
	 document.forms[1].lifeThreateningDesc.value = e.options[e.selectedIndex].text;
	 
	 var e = document.getElementById("hospiceandPalliativedrop");
	 document.forms[1].hospiceandPalliativeDesc.value = e.options[e.selectedIndex].text;
	 
	 var e = document.getElementById("inpatientlimit");
	 document.forms[1].inpatientlimitdecs.value = e.options[e.selectedIndex].text;
	 
	 var e = document.getElementById("alternativesessionlimit");
	 document.forms[1].alternativesessiondesc.value = e.options[e.selectedIndex].text;
	 
	 var e = document.getElementById("approvallimit");
	 document.forms[1].approvaldesc.value = e.options[e.selectedIndex].text;
	 
	 var e = document.getElementById("psllimitdrop");
	 document.forms[1].psllimitdesc.value = e.options[e.selectedIndex].text;
	 
	 var e = document.getElementById("ditecianlimitdrop");
	 document.forms[1].dieticanDesc.value = e.options[e.selectedIndex].text;
	 
	 var e = document.getElementById("ditecianlimitdrop");
	 document.forms[1].ditecianlimitDesc.value = e.options[e.selectedIndex].text;
	 
	 var e = document.getElementById("hIVandaIDSLimitdrop");
	 document.forms[1].hIVandaIDSLimitDesc.value = e.options[e.selectedIndex].text;
	 
	 var e = document.getElementById("circumcisionlimitdrop");
	 document.forms[1].circumcisionlimitDesc.value = e.options[e.selectedIndex].text;
	 
	 var e = document.getElementById("compassionatevisitdrop");
	 document.forms[1].compassionatevisitDesc.value = e.options[e.selectedIndex].text;
	 
	 var e = document.getElementById("externalmedicaldrop");
	 document.forms[1].externalmedicalDesc.value = e.options[e.selectedIndex].text;
	 
	 var e = document.getElementById("healthscreenlimitdrop");
	 document.forms[1].healthscreenlimitDesc.value = e.options[e.selectedIndex].text;
	 
	/* var e = document.getElementById("healthsessions");
	 document.forms[1].healthsessionsDesc.value = e.options[e.selectedIndex].text;*/
	 
	 var e = document.getElementById("healthscreencopay");
	 document.forms[1].healthscreencopayDesc.value = e.options[e.selectedIndex].text;
	 
	 var e = document.getElementById("pregnancy");
	 document.forms[1].pregnancyDesc.value = e.options[e.selectedIndex].text;
	 
	 var e = document.getElementById("deductiblecoinsurance");
	 document.forms[1].deductiblecoinsuranceDesc.value = e.options[e.selectedIndex].text;
	 
	 var e = document.getElementById("externalmedicalcopay");
	 document.forms[1].externalmedicalcopayDesc.value = e.options[e.selectedIndex].text;
	 
	 var e = document.getElementById("workrelateddrop1");
	 document.forms[1].workrelateddrop1Desc.value = e.options[e.selectedIndex].text;
	 
	 var e = document.getElementById("lifeThreateningdiease");
	 document.forms[1].lifeThreateningdieaseDesc.value = e.options[e.selectedIndex].text;
	 
	 var e = document.getElementById("organlimit");
	 document.forms[1].organlimitDesc.value = e.options[e.selectedIndex].text;
	 
	 var e = document.getElementById("alternativecopay");
	 document.forms[1].alternativecopayDesc.value = e.options[e.selectedIndex].text;
	 
	 
	 var e = document.getElementById("obesite");
	 document.forms[1].obesityDesc.value = e.options[e.selectedIndex].text;
	 
	 
	 var e = document.getElementById("outsideareaofcover");
	 document.forms[1].outsidedesc.value = e.options[e.selectedIndex].text;
	 
	 
	 var e = document.getElementById("levelofcover");
	 document.forms[1].leveldesc.value = e.options[e.selectedIndex].text;
	 
	
	
	
	 
	 var MaintenanceofChronicIndex = document.forms[1].MaintenanceofChronic.selectedIndex;
	 var MaintenanceofChronicText = document.forms[1].MaintenanceofChronic.options[parseInt(MaintenanceofChronicIndex)].text;
	 document.forms[1].MaintenanceofChronicDesc.value=MaintenanceofChronicText;	
	 
	 var HormoneReplacementTherapylimitIndex = document.forms[1].HormoneReplacementTherapylimit.selectedIndex;
	 var HormoneReplacementTherapylimitText = document.forms[1].HormoneReplacementTherapylimit.options[parseInt(HormoneReplacementTherapylimitIndex)].text;
	 document.forms[1].HormoneReplacementTherapylimitDesc.value=HormoneReplacementTherapylimitText;	
	 
	 
	 
	 var InpatientRehabilitationtIndex = document.forms[1].InpatientRehabilitation.selectedIndex;
	 var InpatientRehabilitationtIndexText = document.forms[1].InpatientRehabilitation.options[parseInt(InpatientRehabilitationtIndex)].text;
	 document.forms[1].InpatientRehabilitationDesc.value=InpatientRehabilitationtIndexText;	
	 
	 var NursingathomelimitIndex = document.forms[1].Nursingathomelimit.selectedIndex;
	 var NursingathomelimitText = document.forms[1].Nursingathomelimit.options[parseInt(NursingathomelimitIndex)].text;
	 document.forms[1].NursingathomelimitDesc.value=NursingathomelimitText;	
	 
	 var VitaminsIndex = document.forms[1].Vitamins.selectedIndex;
	 var VitaminsText = document.forms[1].Vitamins.options[parseInt(VitaminsIndex)].text;
	 document.forms[1].VitaminsDesc.value=VitaminsText;	
	 
	 var PassiveWarIndex = document.forms[1].PassiveWar.selectedIndex;
	 var PassiveWarText = document.forms[1].PassiveWar.options[parseInt(PassiveWarIndex)].text;
	 document.forms[1].PassiveWarDesc.value=PassiveWarText;	
	 
	 document.forms[1].dentalprothisdesc.value= $("#dentalprothis option:selected").text();
	 document.forms[1].congtalDesc.value= $("#congtal option:selected").text();
	 document.forms[1].oncologydesc.value= $("#oncology option:selected").text();
	 document.forms[1].repatriationDesc.value= $("#repatriation option:selected").text();
	 document.forms[1].terminalDesc.value= $("#terminal option:selected").text();
	 
	 document.forms[1].AlternativeTreatmentsdesc.value= $("#AlternativeTreatments option:selected").text();
	 document.forms[1].ReimbursmentLeveldesc.value= $("#ReimbursmentLevel option:selected").text();
	 
	 
	 
	
	 
	
}

function onDisableInjuries(obj){
	if(obj.value =='190')
		{
		 document.getElementById("workrelateddrop").disabled=true;
	 document.getElementById("workrelateddrop").value='';
		}
	else{
		 document.getElementById("workrelateddrop").disabled=false;
		
}
}

function onTheretningDis(obj){
	if(obj.value == '199'){
		 document.getElementById("lifediseasecdrop").disabled=true;
	 document.getElementById("lifediseasecdrop").value='';}
	else{
		document.getElementById("lifediseasecdrop").disabled=false;}
	
}

function onProceedadditional(){
	 document.forms["Additional"].action =contextpath+"/SoftwareInsurancePricing/Proposal?submenulink=Proposal";
	 document.forms["Additional"].submit();
}
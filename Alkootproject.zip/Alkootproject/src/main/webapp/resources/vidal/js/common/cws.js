var sidePanelID=null;
       var sidePanelIDsArry=[];
 		 function preventBack(){window.history.forward();}
 	    setTimeout("preventBack()", 0);
 	   window.onunload=function(){null;};
 		window.onscroll = function() {scrollV3Wsr();};
 		function scrollV3Wsr() {
 		var styledivV3 = document.getElementById("styledivV3");			
 		
 		
 		if(styledivV3!=null){

 	 		var scTop=(document.documentElement.scrollTop || document.body.scrollTop);
 	 		var scLeft=(document.documentElement.scrollLeft || document.body.scrollLeft);

 	 		styledivV3.style.top=(parseInt(scTop)+(parseInt(document.documentElement.clientHeight)/2)-100)+"px";

 		styledivV3.style.left=(parseInt(scLeft)+((parseInt(document.documentElement.clientWidth)/2)-200))+"px";
 		}
 		 
 		}
 		var prevKey=0;
 		var rw=true;
 		function wsrV3(evt){	
 			var key = (window.event)? window.event.keyCode : evt.which;	
 			if(key==27){
 			closeBlackDivV3();
 			if(sidePanelID!=null){ 				
 	 			closeSidePanel();
 			}
 			
 			return true;
 			}
 			if(key==9&&!rw){//	
 			return false;
 			}
 			if(key==123||key==116){	
 			if(rw){
 			showV3Style();
 			}    
 			return false;
 			}
 			if(prevKey==17&&(key==83||key==85||key==68)){	
 			if(rw){
 			showV3Style();
 			}	
 			return false;
 			}
 			prevKey=key;	
 			return true;
 		}//end of wsrV3(evt)
 		function showV3Style() {

 		var div, text,blackdivV3;
 		blackdivV3 = document.createElement("DIV");
 		blackdivV3.setAttribute("id","blackdivV3");
 		blackdivV3.style.height=(parseInt(document.body.scrollHeight)+1)+"px";
 		blackdivV3.style.width=(parseInt(document.body.scrollWidth)+1)+"px";
 		document.body.appendChild(blackdivV3);
 		div = document.createElement("DIV");
 		div.setAttribute("id","styledivV3");
 		
 		var scTop=(document.documentElement.scrollTop || document.body.scrollTop);
	 	var scLeft=(document.documentElement.scrollLeft || document.body.scrollLeft);
 		
 		div.style.top=(parseInt(scTop)+(parseInt(document.documentElement.clientHeight)/2)-100)+"px";

 		div.style.left=(parseInt(scLeft)+((parseInt(document.documentElement.clientWidth)/2)-200))+"px";
 		
 		//text = document.createTextNode("Sorry this operation is not allowed");

 		div.appendChild(text);
 		var clsBtn=document.createElement("div");
 		clsBtn.appendChild(document.createTextNode("x"));
 		clsBtn.setAttribute("id","clsBtnIDV3");
 		clsBtn.setAttribute("title","Close");
 		clsBtn.setAttribute("style","font-size:25px;");
 		clsBtn.setAttribute("onclick","closeBlackDivV3()");
 		div.appendChild(clsBtn);
 		clsBtn.focus();

 		document.body.appendChild(div);
 		rw=false;
 		}
 		function closeBlackDivV3() {
 			var blackdivV3, styledivV3;
 			blackdivV3 = document.getElementById("blackdivV3");	
 			if(blackdivV3!=null){
 			blackdivV3.parentNode.removeChild(blackdivV3);
 			styledivV3 = document.getElementById("styledivV3");
 			styledivV3.parentNode.removeChild(styledivV3);
 			}
 			rw=true;
 		}
 		function closeSidePanel(){
      var sid=sidePanelIDsArry.pop();
 			var vSPid = document.getElementById(sid);	
 				if(vSPid!=null){
 			 $("#"+sid).click();
 				}
 		}
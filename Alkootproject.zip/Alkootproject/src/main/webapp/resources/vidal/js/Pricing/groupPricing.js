/**
 * 
 */



function isNumberKey(evt){
    var charCode = (evt.which) ? evt.which : evt.keyCode
    return !(charCode > 31 && ((charCode < 48) || (charCode > 57)));
} // isNumberKey

function calculateTargetPremium(){
	
	var targetCount;
	var grossPremiumGroupCount;
	var targetVal = document.getElementById("targerId").value;
	var grossPremiumGroup = document.getElementById("grossPremiumGroupId").innerHTML;
	
	if(targetVal == null || targetVal == ''){
		swal("Target Premium cannot be empty.");
		return false;
	}
	
	if(grossPremiumGroup !=null && grossPremiumGroup !=""){
		var grossPremiumGroupCountRep = grossPremiumGroup.replace("," , "")
		grossPremiumGroupCount = parseInt(grossPremiumGroupCountRep);
	}else{
		grossPremiumGroupCount = 0;
	}
		
	if(targetVal !=null && targetVal !=""){
	
		targetCount = parseInt(targetVal);
	}else{
		targetCount = 0;
	}
	
	/*alert("test..."+grossPremiumGroupCount);*/
	
	const preposedLoading = 1 - grossPremiumGroupCount/targetCount;
	
	if(isNaN(preposedLoading)){
		document.getElementById("proposedId").innerHTML="";
		document.getElementById("proposedId").innerHTML=0;
		document.getElementById("proposedIdhdn").value=0;
	}else if(preposedLoading =='-Infinity'){
		document.getElementById("proposedId").innerHTML='';
		document.getElementById("proposedIdhdn").value='';
		
	}else{
		document.getElementById("proposedId").innerHTML="";
		document.getElementById("proposedId").innerHTML=Math.round(preposedLoading*100)+"%";
		document.getElementById("proposedIdhdn").value=Math.round(preposedLoading*100);
		
	}

}

function savaGroupPricing(){
	
	
	   document.forms["frmGroupPricing"].action =contextpath+"/PricingDashboard/groupPricingSave";
	    document.forms["frmGroupPricing"].submit();
	
	
}

function onGroupReport(){
 
    var parameterValue =	document.getElementById("groupseqid").value;
    var groupcursor = parseInt(document.getElementById("groupcuroser").value);
    
    if(parameterValue == "" || parameterValue == null){
    	swal("Please save the group pricing.");
    	return false;
    }else{
    	
  if(groupcursor>3){
	 
    var parameter = "reportType=PDF&parameter=" +parameterValue
        + "&fileName=groupReport.jrxml&reportID=groupReport&reportType=PDF";
    var openPage = contextpath+"/PricingDashboard/grouppricing?" + parameter;
    var w = screen.availWidth - 10;
    var h = screen.availHeight - 30;
    var features = "scrollbars=0,status=1,toolbar=0,top=0,left=0,resizable=0,menubar=yes,width="
            + w + ",height=" + h;
    window.open(openPage, '', features);
   
    }else{
    	 var parameter = "reportType=PDF&parameter=" +parameterValue
         + "&fileName=groupReport.jrxml&reportID=groupReport&reportType=PDF";
     var openPage = contextpath+"/PricingDashboard/grouppricingMax?" + parameter;
     var w = screen.availWidth - 10;
     var h = screen.availHeight - 30;
     var features = "scrollbars=0,status=1,toolbar=0,top=0,left=0,resizable=0,menubar=yes,width="
             + w + ",height=" + h;
     window.open(openPage, '', features);
    	
    }}

} 

function calculateRevisedPrimium(id){
	
	var lodingvalCount;
	var discountValCount;
	var grossPremiumCount;
	var managementDisCount;
	var profitMarginCount;
	
	var splitId= id.split("~");
	var lodingVal = document.getElementById("loding~"+splitId[1]).value;
	var discountVal = document.getElementById("discountId~"+splitId[1]).value;
	var grossPremium = document.getElementById("grossPremium~"+splitId[1]).innerHTML;
	var managementDis = document.getElementById("managementDisId~"+splitId[1]).innerHTML;
	var profitMargin = document.getElementById("profitMarginId~"+splitId[1]).innerHTML;
	
	
	if(lodingVal == "" || lodingVal == null){
		lodingvalCount = 0;
	}else{
		lodingvalCount = parseInt(lodingVal);
	}
	
	if(discountVal == "" || discountVal == null){
		discountValCount = 0;
	}else{
		discountValCount = parseInt(discountVal);
	}
	
	if(grossPremium == "" || grossPremium == null){
		grossPremiumCount = 0;
	}else{
		var grossPremi = grossPremium.replace("," , "")
	
		grossPremiumCount =  parseInt(grossPremi);
	}
	
	if(managementDis == "" || managementDis == null){
		managementDisCount = 0;
	}else{
		var management = managementDis.replace("," , "")
		managementDisCount = parseInt(management)
	}
	
	if(profitMargin == "" || profitMargin == null){
		profitMarginCount = 0;
	}else{
		profitMa=profitMargin.replace("," , "")
		profitMarginCount = parseInt(profitMa)
	}
	
	
	/*const revisPrimiumTotal = grossPremiumCount * (1 - (profitMarginCount + managementDisCount)) / (1- (profitMarginCount - lodingvalCount) + (managementDisCount + discountValCount));*/
	/*alert("grossPremiumCount.."+grossPremiumCount);
	alert("profitMarginCount.."+profitMarginCount);
	
	alert("managementDisCount.."+managementDisCount);
	alert("lodingvalCount.."+lodingvalCount);
	alert("discountValCount.."+discountValCount);*/
	
	const revisPrimiumTotal = grossPremiumCount * ((1 - (profitMarginCount/100 - managementDisCount/100)) / (1- (profitMarginCount/100 + lodingvalCount/100) + (managementDisCount/100 + discountValCount/100)));
	
   /* alert("revisPrimiumTotal.."+revisPrimiumTotal)*/
	
	document.getElementById("reservePremiumId~"+splitId[1]).innerHTML=Math.round(revisPrimiumTotal);
	
	document.getElementById("reservePremiumIdhdn~"+splitId[1]).value=Math.round(revisPrimiumTotal);
	
	var coverMember0;
	var revisedMem0;
	var coverMember1;
	var revisedMem1;
	var coverMember2;
	var revisedMem2;
	var coverMember3;
	var revisedMem3;
	var coverMember4;
	var revisedMem4;
	var coverMember5;
	var revisedMem5;
	
		
		var coverMemberCount0 = document.getElementById("covermemberHdn~0").value;
		var revisedMemCount0 = document.getElementById("reservePremiumIdhdn~0").value;		
		var coverMemberCount1 = document.getElementById("covermemberHdn~1").value;
		var revisedMemCount1 = document.getElementById("reservePremiumIdhdn~1").value;		
		var coverMemberCount2 = document.getElementById("covermemberHdn~2").value;
		var revisedMemCount2 = document.getElementById("reservePremiumIdhdn~2").value;		
		var coverMemberCount3 = document.getElementById("covermemberHdn~3").value;
		var revisedMemCount3 = document.getElementById("reservePremiumIdhdn~3").value;		
		var coverMemberCount4 = document.getElementById("covermemberHdn~4").value;
		var revisedMemCount4 = document.getElementById("reservePremiumIdhdn~4").value;		
		var coverMemberCount5 = document.getElementById("covermemberHdn~5").value;
		var revisedMemCount5 = document.getElementById("reservePremiumIdhdn~5").value;	
		
		
		
		
		if(coverMemberCount0 !=null && coverMemberCount0 !=""){
			coverMember0 = parseInt(coverMemberCount0);
		}else{
			coverMember0 = 0;
		}		
		if(revisedMemCount0 !=null && revisedMemCount0 !=""){
			revisedMem0 = parseInt(revisedMemCount0);
		}else{
			revisedMem0 = 0;
		}
		
		if(coverMemberCount1 !=null && coverMemberCount1 !=""){
			coverMember1 = parseInt(coverMemberCount1);
		}else{
			coverMember1 = 0;
		}		
		if(revisedMemCount1 !=null && revisedMemCount1 !=""){
			revisedMem1 = parseInt(revisedMemCount1);
		}else{
			revisedMem1 = 0;
		}
		
		if(coverMemberCount2 !=null && coverMemberCount2 !=""){
			coverMember2 = parseInt(coverMemberCount2);
		}else{
			coverMember2 = 0;
		}		
		if(revisedMemCount2 !=null && revisedMemCount2 !=""){
			revisedMem2 = parseInt(revisedMemCount2);
		}else{
			revisedMem2 = 0;
		}
		
		if(coverMemberCount3 !=null && coverMemberCount3 !=""){
			coverMember3 = parseInt(coverMemberCount3);
		}else{
			coverMember3 = 0;
		}		
		if(revisedMemCount3 !=null && revisedMemCount3 !=""){
			revisedMem3 = parseInt(revisedMemCount3);
		}else{
			revisedMem3 = 0;
		}
		
		if(coverMemberCount4 !=null && coverMemberCount4 !=""){
			coverMember4 = parseInt(coverMemberCount4);
		}else{
			coverMember4 = 0;
		}		
		if(revisedMemCount4 !=null && revisedMemCount4 !=""){
			revisedMem4 = parseInt(revisedMemCount4);
		}else{
			revisedMem4 = 0;
		}
		
		if(coverMemberCount5 !=null && coverMemberCount5 !=""){
			coverMember5 = parseInt(coverMemberCount5);
		}else{
			coverMember5 = 0;
		}		
		if(revisedMemCount5 !=null && revisedMemCount5 !=""){
			revisedMem5 = parseInt(revisedMemCount5);
		}else{
			revisedMem5 = 0;
		}
		
		/*alert("revisedMem0.."+revisedMem0);
		alert("coverMember0.."+coverMember0);
		alert("revisedMem1.."+revisedMem1);
		alert("coverMember1.."+coverMember1);
		alert("revisedMem2.."+revisedMem2);
		alert("coverMember2.."+coverMember2);
		alert("revisedMem3.."+revisedMem3);
		alert("coverMember3.."+coverMember3);
		alert("revisedMem4.."+revisedMem4);
		alert("coverMember4.."+coverMember4);
		alert("revisedMem5.."+revisedMem5);
		alert("coverMember5.."+coverMember5);*/
		
		const revisedPremiumPerTotal = ((revisedMem0*coverMember0) + (revisedMem1*coverMember1) + (revisedMem2*coverMember2) + (revisedMem3*coverMember3)+(revisedMem4*coverMember4) + (revisedMem5*coverMember5))/(coverMember0+coverMember1+coverMember2+coverMember3+coverMember4+coverMember5);
		
		
		
		if(isNaN(revisedPremiumPerTotal)){
			document.getElementById("reservePremiumGroupId").innerHTML=0;
			document.getElementById("reservePremiumGroupIdhdn").value=0;
		}else{			
			document.getElementById("reservePremiumGroupId").innerHTML=Math.round(revisedPremiumPerTotal);
			document.getElementById("reservePremiumGroupIdhdn").value=Math.round(revisedPremiumPerTotal);
		}
		
		

	
}
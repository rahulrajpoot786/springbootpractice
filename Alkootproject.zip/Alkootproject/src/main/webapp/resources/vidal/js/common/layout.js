function modifyLinks(type, name)
{
	if(type == 'Link')
		document.forms[0].menulink.value = name;
	else if(type == 'SubLink')
		document.forms[0].sublink.value = name;
	else if(type == 'Tab')
		document.forms[0].submenulink.value = name;
	
	document.forms[0].action=contextpath+"/defaultcontroler";//"defaultcontroler.do?mode=doDefault"
	document.forms[0].submit();
}

function logout(){
	
	
	document.forms[0].action=contextpath+"/logout";
	document.forms[0].submit();
}


function home()
{
	
	
 var flag=document.getElementById("changetracker").value;
 
 var groupPricing=document.getElementById("groupPricingFlag").value;

 
 if(flag == "T"){
	 swal({
			
		  text: "Data has been modified. Do you want to discard the changes?",

		  buttons: true,
		  infoMode: true,
		})
		.then((willDelete) => {
		  if (willDelete) {
			  document.forms[0].action =contextpath+"/PricingDashboard/doDefault";
			  document.forms[0].submit();
		  } 
		});
 }else if(groupPricing != null && groupPricing !="" && groupPricing =='T'){
	 
	 swal({
			
		  text: "Are you sure you want to exit without saving?",

		  buttons: true,
		  infoMode: true,
		})
		.then((willDelete) => {
		  if (willDelete) {
			  document.forms[0].action =contextpath+"/PricingDashboard/doDefault";
			  document.forms[0].submit();
		  } 
		});
	 
 } 
 else{
	  document.forms[0].action =contextpath+"/PricingDashboard/doDefault";
	  document.forms[0].submit();
 }
}

/*window.onbeforeunload = function() {
	logout("ULGO");
	};*/
/*	
function status(str){
	    $.ajax({url: "/vingsproject/status?str="+str, success: function(response){
	        $("#curstatusId").html("<img src='/vingsproject/resources/vidal/images/"+response+".png' alt='shutdown' width='31px' height='31px'>");
	    }});
}*/


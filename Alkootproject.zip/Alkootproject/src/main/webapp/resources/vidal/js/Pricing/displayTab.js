/**
 * 
 */

 function displayGlobalTab(tabAction){
	 
	 
		document.forms[0].action=contextpath+"/"+tabAction;
		document.forms[0].submit();
 }
/**
 * 
 */

  function globalDisplay(){
	 
	  
  }
  
  
  function getClientName(val) {
	  
	  var clientStatus = document.getElementById('renewalYN').value;
	
	  document.getElementById("clientSeqId").value=$("#clientCode option:selected").text();	  
	  document.forms["frmSwPricing"].action=contextpath+"/"+"SoftwareInsurancePricing/getClientName?clientCode="+ val;
	  document.forms["frmSwPricing"].submit(); 

    } // getClientName
  
  function getPolicyNo() {
	    document.forms["frmSwPricing"].action=contextpath+"/"+"SoftwareInsurancePricing/getPolicyNo";
		document.forms["frmSwPricing"].submit(); 		

	} // getPolicyNo
	   
  
  
  function onSave(){
	   

	var pricingTemp=document.getElementById("pricingTemp").value;
	var copyType=document.getElementById("copyType").value;
	
	 var maxBenefitElement=document.getElementById('maxBenifitList').value;
	 var opticalLimitElement=document.getElementById('opticalLimitId').value;
	 var dentalLimitElement=document.getElementById('dentalLimitList').value;
	 var maternityLimitElement=document.getElementById('maternityLimitList').value;
	
	
	/*if(pricingTemp != null && pricingTemp != ''){		
		if(copyType =='I'){						
			swal("Some details above have been copied from "+pricingTemp+". Hope you have reviewed and want to proceed?")
			
		}else{
			swal("Some details above have been copied from "+pricingTemp+". Hope you have reviewed and want to proceed?")
		}
	}*/
	  
	    setDescValues();
	 
	    if(!valiForm()){
	    	return false;
	    }
	    	
	    $("#maternityPricingList").removeAttr("disabled");
	    $("#remiumOutputStructureList").removeAttr("disabled");
	    $("#allhalliClassdisable").removeAttr("disabled");
	    
	    
	   var othStatus= onSaveValOther();
	 
	   
	   if(!othStatus){
		   return false;
	   }
	 
	   
	    if(maxBenefitElement=='45'){
			 var maxBenefitOthElement=document.forms[1].maxBeneLimitOth;
			 var check=checkValue(maxBenefitOthElement);
			 if(check==false){
				 maxBenefitOthElement.focus();
					return false; 
				 }
		 }
	    if(opticalLimitElement=='45'){
			 var opticalLimitOth=document.forms[1].opticalLimitOth;
			 var check=checkValue(opticalLimitOth);
			 if(check==false){
				 opticalLimitOth.focus();
					return false; 
				 }
		 }
	    if(dentalLimitElement=='45'){
			 var dentalLimitOth=document.forms[1].dentalLimitOth;
			 var check=checkValue(dentalLimitOth);
			 if(check==false){
				 dentalLimitOth.focus();
					return false; 
				 }
		 }
	    if(maternityLimitElement=='45'){
			 var maternityLimitOth=document.forms[1].maternityLimitOth;
			 var check=checkValue(maternityLimitOth);
			 if(check==false){
				 maternityLimitOth.focus();
				return false; 
			 }
		 }
	 
	    

	 
	    if(document.getElementById("renewalYN").value == "Y" && document.getElementById("previousPolicyNo").value == ""){
	    	swal('\'Past policy number\' is required.');
		    document.getElementById("previousPolicyNo").value = "";
			document.getElementById("previousPolicyNo").focus();
			return false;
	  }
	    
	    if(pricingTemp != null && pricingTemp != ''){	
	    	
	    swal({								
			  text: "Some details above have been copied from "+pricingTemp+". Hope you have reviewed and want to proceed?",
			  buttons: true,
			  infoMode: true,
			})
			.then((willDelete) => {
			  if (willDelete) {
				  document.forms["frmSwPricing"].action=contextpath+"/"+"SoftwareInsurancePricing/saveInputScreen";
					document.forms["frmSwPricing"].submit();
			  } 
			});
	    }else{
	    	
	    	 document.forms["frmSwPricing"].action=contextpath+"/"+"SoftwareInsurancePricing/saveInputScreen";
			 document.forms["frmSwPricing"].submit();
	    	
	    }
	   
	   
  } //onSave
  
  function onProceed(){
	   
	    setDescValues();
	    
	   /* var  pricingNo = document.getElementById("groupProfileSeqID").value;*/
	    var inputScreenflag = document.getElementById("inputScreenChangeFlag").value;
	   
	   
	    
	    if(document.getElementById("renewalYN").value == "Y" && document.getElementById("previousPolicyNo").value == ""){
	    	swal('\'Past policy number\' is required.');
		    document.getElementById("previousPolicyNo").value = "";
			document.getElementById("previousPolicyNo").focus();
			return false;
	 }
	    
	    if(inputScreenflag == "T"){
	   	 swal({
	   			
	   		  text: "Data has been modified. Do you want to discard the changes?",

	   		  buttons: true,
	   		  infoMode: true,
	   		})
	   		.then((willDelete) => {
	   		  if (willDelete) {
	   			document.forms["frmSwPricing"].action=contextpath+"/"+"SoftwareInsurancePricing/proceedInputScreen";
	  			document.forms["frmSwPricing"].submit();
	   		  } 
	   		});
	    }else{
	    	document.forms["frmSwPricing"].action=contextpath+"/"+"SoftwareInsurancePricing/proceedInputScreen";
  			document.forms["frmSwPricing"].submit();
	    }
	    
	
	    
} //onSave


  function fetchScreen1()
  {	  	  
	    var renewalYN = document.getElementById("renewalYN").value;
		var clientcodeId = document.getElementById("clientCode").value;
		var clientName = document.getElementById("clientName").value;
		var coverStartDate = document.getElementById("coverStartDate").value;
		var coverEndDate = document.getElementById("datetimepicker2").value;
		var totalCovedLives = document.getElementById("totalCovedLives").value;
		var previousPolicyNo = document.getElementById("previousPolicyNo").value;
		var policyFetchFlagElem = document.getElementById("vidalPolicyId").value;
		
		
		var clientText= document.forms[1].opInvestnAlAhliDesc.value=$("#clientCode option:selected").text();		
		 if(previousPolicyNo == null || previousPolicyNo == ""){
			 swal("Please enter the past policy number to fetch the details.");
		    	return false;
		    }		
		  var  policyType = previousPolicyNo.includes("XC");
		  
		  if(policyType){
			  swal("\'Fetch key coverages\' provision is only available with past policy numbers that exists in the Vidal Health system.")
				 .then((value) => {
					$("#previousPolicyNo").focus();
				 });	
			  return false;
		  }
			if(renewalYN!='Y'){				
				if(renewalYN =='N'){
					swal('\'Fetch key coverages\' provision is only available for renewal pricing.');	
				return false;
				}else{									
			    document.forms["frmSwPricing"].action =contextpath+"/SoftwareInsurancePricing/SwInsPricingAction?previousPolicyNo="+previousPolicyNo+"&renewalYN="+renewalYN +"&clientText="+clientText+ +"&clientCode="+clientcodeId;
			    document.forms["frmSwPricing"].submit();
				}
			  /*  document.forms["frmSwPricing"].action =contextpath+"/SoftwareInsurancePricing/SwInsPricingAction?previousPolicyNo="+previousPolicyNo+"&renewalYN="+renewalYN+"&clientcodeId="+clientcodeId+"" +
				"&coverStartDate="+coverStartDate+"&coverEndDate="+coverEndDate+"&totalCovedLives="+totalCovedLives+"&clientName="+clientName; 
			    document.forms[1].submit();*/
			    
				}else{
					if(policyFetchFlagElem=='Y'){
						swal('\'Fetch key coverages\' provision is only available with past policy numbers that exists in the Vidal Health system.');
						return false;
					}else{						
						 swal({								
							  text: "The benefits will be populated for policy number "+previousPolicyNo+". Coverage start date, end date will be populated assuming renewal of the most recent policy available. Please press 'OK' to proceed.",
							  buttons: true,
							  infoMode: true,
							})
							.then((willDelete) => {
							  if (willDelete) {
								  document.forms["frmSwPricing"].action =contextpath+"/SoftwareInsurancePricing/SwInsPricingAction?previousPolicyNo="+previousPolicyNo+"&renewalYN="+renewalYN +"&clientText="+clientText;
					              document.forms["frmSwPricing"].submit();
					              
							  } else {
								  document.getElementById("previousPolicyNo").focus();
								 return false;
							  }
							});
																		
						/*
							if (confirm("The benefits will be populated for Policy Number "+previousPolicyNo+". Coverage start date, end date will be populated assuming renewal of the most recent policy available. Please press 'OK' to proceed.")) {
								 document.forms["frmSwPricing"].action =contextpath+"/SoftwareInsurancePricing/SwInsPricingAction?previousPolicyNo="+previousPolicyNo+"&renewalYN="+renewalYN +"&clientText="+clientText;
								  document.forms["frmSwPricing"].submit();
								
						    document.forms["frmSwPricing"].action =contextpath+"/SoftwareInsurancePricing/SwInsPricingAction?previousPolicyNo="+previousPolicyNo+"&renewalYN="+renewalYN+"&clientcodeId="+clientcodeId+"" +
							"&coverStartDate="+coverStartDate+"&coverEndDate="+coverEndDate+"&totalCovedLives="+totalCovedLives+"&clientName="+clientName; 
						    document.forms["frmSwPricing"].submit();
						    }else{
								document.getElementById("previousPolicyNo").focus();
								return false;
							}*/
					}
				}							   	 								     
        
  }
  // added by gyanendra


 function  opticalOtherLimitEnnable(val){		 
	 if(val == '45'){
		  $("#opticalLimitOth").attr("readonly", false);
		  $(".opticaleRequireOtherLebel").addClass("required"); 
	 }else{
		   $("#opticalLimitOth").attr("readonly", true);
		   $(".opticaleRequireOtherLebel").removeClass("required"); 
		   $("#opticalLimitOth").val('');
	 }
 }
  
  function opticalCheckStatus(){	  	  
          var isChecked = $("#opticalCheckId").is(":checked");       
          if (isChecked) {         
        	  $("#opticalYN").val('N')
        	  $(".opticalDisable").attr("disabled", true);   
        	  $('.opticalDisable').val('');
        	  $('#opticalLimitOth').val('');
        	  $("#opticalLimitOth").attr("readonly", true);
        	  $(".opticaleRequireLebel").removeClass("required"); 
        	  $(".opticaleRequireOtherLebel").removeClass("required"); 
          } else {
        	  $("#opticalYN").val('Y')        	  
        	  $(".opticalDisable").attr("disabled", false); 
        	  $(".opticaleRequireLebel").addClass("required");         	
          }     
	  
  } // opticalCheckStatus
  
 function  dentalOtherLimitEnnable(val){
	 if(val == '45'){		 
		  $(".dentalRequireOtherLebelClass").addClass("required"); 
		  $("#dentalLimitOth").attr("readonly", false);
	 }else{
		  $(".dentalRequireOtherLebelClass").removeClass("required"); 
		  $("#dentalLimitOth").attr("readonly", true);
		  $("#dentalLimitOth").val('');
	 }
 }//dentalOtherLimitEnnable
  
  function dentalCheckStatus(){  	  
      var isChecked = $("#dentalCheckId").is(":checked");
      if (isChecked) {
    	  $("#dentalYN").val('N')
          $(".dentalDisable").attr("disabled", true);
          $('.dentalDisable').val('');
    	  $('#dentalLimitOth').val('');
    	  $("#dentalLimitOth").attr("readonly", true);
    	  $(".dentalRequireLebelClass").removeClass("required"); 
    	  $(".dentalRequireOtherLebelClass").removeClass("required"); 
    	/*  document.getElementById("OrthodonticsLebelYesId").style.cursor ="none";
		  document.getElementById("OrthodonticsLebelNoId").style.cursor ="none";*/
		/*  document.getElementById("OrthodonticsLebelYesId").style.cursor ="not-allowed";
		  document.getElementById("OrthodonticsLebelNoId").style.cursor ="not-allowed";*/
		 /* document.getElementById("OrthodonticsLebelYesId").style.backgroundColor ="#C0C0C0";
		  document.getElementById("OrthodonticsLebelNoId").style.backgroundColor ="#C0C0C0";*/
    
      } else {
    	  $("#dentalYN").val('Y')
    	  $(".dentalDisable").attr("disabled", false);
    	  $(".dentalRequireLebelClass").addClass("required"); 
    	/*  document.getElementById("OrthodonticsLebelYesId").style.cursor ="pointer";
		  document.getElementById("OrthodonticsLebelNoId").style.cursor ="pointer";*/
		  
		/*  document.getElementById("OrthodonticsLebelYesId").style.backgroundColor ="White";*/
		
		/*  $('#OrthodonticsLebelYesId').prop('checked', true);*/
		  
		/*  document.getElementById("OrthodonticsLebelNoId").style.backgroundColor ="White";*/
    	
      }   
}  // dentalCheckStatus
  
 function  maternityOtherLimitEnnable(val){
	 if(val == '45'){		 
		  $("#maternityLimitOth").attr("readonly", false);
		  $(".maternityOtherRequireClass").addClass("required"); 
	 }else{		 
		   $("#maternityLimitOth").attr("readonly", true);
		   $(".maternityOtherRequireClass").removeClass("required"); 
	 }
	 
 }//maternityOtherLimitEnnable
  
function maternityCheckStatus(){		
   var isChecked = $("#maternityCheckId").is(":checked");
    if (isChecked) { 
      $("#maternityYN").val('N');
      $(".maternityDisable").attr("disabled", true);
      $('.maternityDisable').val('');
  	  $('#maternityLimitOth').val('');
  	  $('#maternityPricingList').val('1'); 	
  	  $("#maternityLimitOth").attr("readonly", true);
  	  $(".maternityRequireClass").removeClass("required"); 
  	  $(".maternityOtherRequireClass").removeClass("required");        
       /* $("#maternityLimitOth").attr("readonly", true);*/
    } else {
      $("#maternityYN").val('Y')
  	  $(".maternityDisable").attr("disabled", false);
      $(".maternityRequireClass").addClass("required"); 
  	/*  $("#maternityLimitOth").attr("readonly", false);*/
    }   
	 
} // maternityCheckStatus
  
function showTemplate(){		
	  document.forms[0].action = contextpath+"/"+"SoftwareInsurancePricing/downloadSample";
	  document.forms[0].submit();	
} // end   showTemplate

function showCensusTemplate(){	
	  var fileName = document.getElementById("censusFileUploadName").value;
	  if(fileName !=null && fileName !=""){
	  document.forms[0].action = contextpath+"/"+"SoftwareInsurancePricing/downloadCensusFile?fileName="+fileName;
	  document.forms[0].submit();
	  }else{
		  swal("No file uploaded for this pricing");
		  return false;
	  }
} // end   showTemplate


function brokerName(val){	
    if(val != '' && val != null){    		
	if(val ==='BRO'){
		 $("#brokerNameLebel").addClass("required");  
		document.getElementById("brokernameId").readOnly = false;
	}else{
		document.getElementById("brokernameId").value="";
		document.getElementById("brokernameId").readOnly = true;
		 $("#brokerNameLebel").removeClass("required");
	}
      }else{
    	  document.getElementById("brokernameId").value="";
    	  $("#brokerNameLebel").removeClass("required");
      }
	
} //end brokerName





function fileValidation(file){
 
    var filePath = file.value;
  
    var allowedExtensions = /(\.xls)$/i;
    if(!allowedExtensions.exec(filePath)){
    	swal('Please select the .XLS file.');
        $(file).val('');
        return false;
    }
   /* var FileSize = file.files[0].size / 1024 / 1024; // in MB
*/    const fsize  = file.files[0].size;
      const filesi = Math.round((fsize / 1024)); 
    
    
    if (filesi >= 51200) {
    	swal('File size exceeds 50 MB.');
        $(file).val('');
        return false;
    }        
    
   

      
      document.forms["frmSwPricing"].action = contextpath+"/"+"SoftwareInsurancePricing/doUploadMemDetails";
	  document.forms["frmSwPricing"].submit();
 
} //  end fileValidation
  
  
  
  function areaOfVariation(val){
	  var areaCover=$("#areaOfCoverList option:selected").text();
	  if(val !=null && val !=''){
		if(areaCover != val){				
		  $('#areaOfVariationFlag').val('Y');
		  $(".areaOfCoverClass").attr("readonly",false);
		  $(".lodingAreaDiv").addClass("required");
		  $(".discountAreaDiv").addClass("required");
		  $('#loadingAreaListip').val(0);
		  $('#loadingAreaListop').val(0);
		  $('#loadingAreaListopt').val(0);
		  $('#loadingAreaListdent').val(0);
		  $('#loadingAreaListmat').val(0);
		  
		  $('#discountAreaListip').val(0);
		  $('#discountAreaListop').val(0);
		  $('#discountAreaListopt').val(0);
		  $('#discountAreaListdent').val(0);
		  $('#discountAreaListmat').val(0);
			}else{
				 $('#areaOfVariationFlag').val('');
				 $(".areaOfCoverClass").attr("readonly",true);
				  $(".lodingAreaDiv").removeClass("required");
				  $(".discountAreaDiv").removeClass("required");
				  $('#loadingAreaListip').val('');
				  $('#loadingAreaListop').val('');
				  $('#loadingAreaListopt').val('');
				  $('#loadingAreaListdent').val('');
				  $('#loadingAreaListmat').val('');
				  
				  $('#discountAreaListip').val('');
				  $('#discountAreaListop').val('');
				  $('#discountAreaListopt').val('');
				  $('#discountAreaListdent').val('');
				  $('#discountAreaListmat').val('');
			}
		
	  }else{
		  $(".areaOfCoverClass").attr("readonly",true);
		  $(".lodingAreaDiv").removeClass("required");
		  $(".discountAreaDiv").removeClass("required");
		  $('#loadingAreaListip').val('');
		  $('#loadingAreaListop').val('');
		  $('#loadingAreaListopt').val('');
		  $('#loadingAreaListdent').val('');
		  $('#loadingAreaListmat').val('');
		  
		  $('#discountAreaListip').val('');
		  $('#discountAreaListop').val('');
		  $('#discountAreaListopt').val('');
		  $('#discountAreaListdent').val('');
		  $('#discountAreaListmat').val('');
	  }
	  	  
  }//areaOfVariation
  

  function onNetworkCLick(valu,focusId){
	var netval = document.getElementById("networkListId").value;
	if(netval == '5'){
		$(".networkDivClass").show();		
	}else{
		$(".networkDivClass").hide();
	}	  
	  
	  $.ajax({
			url : contextpath+"/"+"SoftwareInsurancePricing/getHospitalDetails?networkCode="+ valu +"&focusId="+focusId,
			async : false,
			success : function(response) {
				if (response != null) {														
						var spliResponse = response.split("~");
							document.getElementById("hospitalExclusionsList").innerHTML=spliResponse[0];
							document.getElementById("additionalHospitalCoverageList").innerHTML=spliResponse[1];														
							if(netval == '1' || netval =='5'){
								  $("#additionalHospitalCoverageList").val('')
								  $("#additionalHospitalCoverageList").attr("disabled", true);  	
								  if(netval == '5'){									  
									  $("#hospitalExclusionsList").val('')
									  $("#hospitalExclusionsList").attr("disabled", true);  	
								  }else{
									  $("#hospitalExclusionsList").attr("disabled",false); 
								  }								  
							}else{
								  $("#additionalHospitalCoverageList").attr("disabled",false);  
								  $("#hospitalExclusionsList").attr("disabled",false); 
							}
							
							if(netval == '3'){
								  $("#hospitalExclusionsList").val('')
								  $("#hospitalExclusionsList").attr("disabled", true);
							}else{
								  $("#hospitalExclusionsList").attr("disabled",false);
							}
							
				}

			}
		});
	  
	  
	 
	/* $('.networkDetails').val(valu);	  
	 document.forms["frmSwPricing"].action=contextpath+"/"+"SoftwareInsurancePricing/getHospitalDetails?networkCode="+ valu +"&focusId="+focusId;
	 document.forms["frmSwPricing"].submit(); */
	  	    	  
  } // close onNetworkCLick
  
  
  


  function maxBenefitsLimitOther(val){	  
	  if(val == '45'){
		  $("#maxBeneLimitOth").attr("readonly",false);
		  $(".maxBeneLimitOthDivClass").addClass("required");		  
	  }else{
		  $("#maxBeneLimitOth").attr("readonly",true);
		  $(".maxBeneLimitOthDivClass").removeClass("required");
		  $("#maxBeneLimitOth").val('');
	  }
  } // close maxBenefitsLimitOtherIP
  
  function maxBenefitsLimitOtherOP(val){	  
	  if(val == '45'){		  
		  $("#otherLimitopId").attr("readonly",false);
		  $(".otherLimitopDivClass").addClass("required")		  
	  }else{
		  $("#otherLimitopId").attr("readonly",true);
		  $(".otherLimitopDivClass").removeClass("required")
		  $("#otherLimitopId").val('');
	  } 
  } // close maxBenefitsLimitOtherOP
  
  
  function copyInputDataSelect(val){
	  document.getElementById("copyTypeId").value="";
	  document.getElementById("copyTypeId").value=val;
  }
  
  function copyInputData(){	  	  
	  var groupProfileSeqID= document.getElementById("groupProfileSeqID").value;
	 var copyType= document.getElementById("copyTypeId").value;
	 
	 	
	 if(groupProfileSeqID !=="" && groupProfileSeqID !==null && groupProfileSeqID !==''){
	 if(copyType !== "" && copyType !== null && copyType !== ''){		 
		if(copyType == 'InputCopy'){						
			swal({				
				  text: "All details under '\Input screen\' and '\Additional Benefit screen\' will be copied. Please confirm.",
				/*  icon: "warning",*/
				  buttons: true,
				  infoMode: true,
				})
				.then((willDelete) => {
				  if (willDelete) {
					  document.forms["frmSwPricing"].action=contextpath+"/"+"SoftwareInsurancePricing/copyInputData";
				      document.forms["frmSwPricing"].submit();
				  } else {
				   
				  }
				});
		
			
		/*	alert("status.."+status)*/
			/* var status = confirm("All details under Input screen and additional benefit screen will be copied. Please confirm.");*/
			/* if(status){
	          document.forms["frmSwPricing"].action=contextpath+"/"+"SoftwareInsurancePricing/copyInputData";
		      document.forms["frmSwPricing"].submit();
			 }*/
	  }else{		  
			swal({				
				  text: "All details under '\Input screen\', '\Census\' and  '\Additional Benefit\' screen will be copied. Please confirm.",
				  buttons: true,
				  infoMode: true,
				})
				.then((willDelete) => {
				  if (willDelete) {
					  document.forms["frmSwPricing"].action=contextpath+"/"+"SoftwareInsurancePricing/copyInputDataCensus";
				      document.forms["frmSwPricing"].submit();
				  } else {
				   
				  }
				});
			/* var statusflag = confirm("All details under Input screen, census and additional benefit screen will be copied. Please confirm.");
			 if(statusflag){
		      document.forms["frmSwPricing"].action=contextpath+"/"+"SoftwareInsurancePricing/copyInputDataCensus";
		      document.forms["frmSwPricing"].submit();
			 }*/
	  }
	 }else{		
		 swal("Please select copy data type.");
		 return false;
	 }	
	 }else{
		 swal("Please select pricing no.");
		 return false;
	 }
		
  }   // close copyInputData
  
  
  function copyInputDataReadOnlyMood(){	 
	  
	  $(".readonlyMode").removeAttr("disabled");
	  var groupProfileSeqID= document.getElementById("groupProfileSeqID").value;
	 var copyType= document.getElementById("copyTypeId").value;
	 	
	 
	 if(groupProfileSeqID !=="" && groupProfileSeqID !==null && groupProfileSeqID !==''){
	 if(copyType !== "" && copyType !== null && copyType !== ''){		 
		if(copyType == 'InputCopy'){						
			swal({				
				  text: "All details under '\Inputs screen\' and '\Additional Benefit screen\' will be copied. Please confirm.",
				/*  icon: "warning",*/
				  buttons: true,
				  infoMode: true,
				})
				.then((willDelete) => {
				  if (willDelete) {
					  document.forms["frmSwPricing"].action=contextpath+"/"+"SoftwareInsurancePricing/copyInputData";
				      document.forms["frmSwPricing"].submit();
				  } else {
				   
				  }
				});
		
			
		/*	alert("status.."+status)*/
			/* var status = confirm("All details under Input screen and additional benefit screen will be copied. Please confirm.");*/
			/* if(status){
	          document.forms["frmSwPricing"].action=contextpath+"/"+"SoftwareInsurancePricing/copyInputData";
		      document.forms["frmSwPricing"].submit();
			 }*/
	  }else{		  
			swal({				
				  text: "All details under '\Inputs screen\', '\Census\' and  '\Additional Benefit\' screen will be copied. Please confirm.",
				  buttons: true,
				  infoMode: true,
				})
				.then((willDelete) => {
				  if (willDelete) {
					  document.forms["frmSwPricing"].action=contextpath+"/"+"SoftwareInsurancePricing/copyInputDataCensus";
				      document.forms["frmSwPricing"].submit();
				  } else {
				   
				  }
				});
			/* var statusflag = confirm("All details under Input screen, census and additional benefit screen will be copied. Please confirm.");
			 if(statusflag){
		      document.forms["frmSwPricing"].action=contextpath+"/"+"SoftwareInsurancePricing/copyInputDataCensus";
		      document.forms["frmSwPricing"].submit();
			 }*/
	  }
	 }else{		
		 swal("Please select copy data type.");
		 return false;
	 }	
	 }else{
		 swal("Please select pricing no.");
		 return false;
	 }
		
  }   // close copyInputData
  
  function checkPolicyNo(element){	 
	    document.forms[1].action = "/clientDetailAction.do";
	    document.forms[1].submit();
  } //checkPolicyNo
  
  
  function isNumberKey(evt){
	    var charCode = (evt.which) ? evt.which : evt.keyCode
	    return !(charCode > 31 && ((charCode < 48) || (charCode > 57)));
	} // isNumberKey
	
  
  function isNumeric(field) {
      var re = /^[0-9]*\.*[0-9]*$/;
      if (!re.test(field.value)) {
    	  
    	   swal({								
 			  text: "Data entered must be numeric.",
 			  buttons: true,
 			  infoMode: true,
 			})
 			.then((willDelete) => {
 			  if (willDelete) {
 				 field.focus();
 				field.value="";
 			  } 
 			}); 	  	  			
			return false;
      }
  }
  
  function isTreandNumberKey(evt, element) {
	  var charCode = (evt.which) ? evt.which : event.keyCode
	  if (charCode > 31 && (charCode < 48 || charCode > 57) && !(charCode == 46 || charCode == 8))
	    return false;
	  else {
	    var len = $(element).val().length;
	    var index = $(element).val().indexOf('.');
	    if (index > 0 && charCode == 46) {
	      return false;
	    }
	    if (index > 0) {
	      var CharAfterdot = (len + 1) - index;
	      if (CharAfterdot > 3) {
	        return false;
	      }
	    }

	  }
	  return true;
	}
  
  
  function validateTrend(field){		  	 		 		  
		  var trendFactor = parseFloat(field.value);		  	
		  if(trendFactor < 0  || trendFactor > 14){			  
			   swal("Trend should not exceed 14%.");
			    field.focus();
				field.value="";
				return false;			  
		  }	  
  }
  
  function selectAdditionalHospital(val){
	  
	 if(val !=null && val !=''){
		 
		  $(".CoverageClass").attr("readonly",false); 
		  $(".commentClass").attr("readonly",false); 
		  $(".CoverageDivClass").addClass("required");
		  $(".commentDivClass").addClass("required");
		  
	 }else{
		  $(".CoverageClass").val('');
		  $(".commentClass").val('');
		  $(".CoverageClass").attr("readonly",true);
		  $(".commentClass").attr("readonly",true); 
		  $(".CoverageDivClass").removeClass("required");
		  $(".commentDivClass").removeClass("required");
	 } 
	  
  }
  
  function selectHospitalExcusions(val){
	  
		 if(val !=null && val !=''){
			  $(".exclusionsClass").attr("readonly",false); 
			  $(".exclusionCommentClass").attr("readonly",false); 
			  $(".exclusionsDivClass").addClass("required");
			  $(".exclusionCommentDivClass").addClass("required");
			  
		 }else{
			  $(".exclusionsClass").val('');
			  $(".exclusionCommentClass").val('');
			  $(".exclusionsClass").attr("readonly",true);
			  $(".exclusionCommentClass").attr("readonly",true);
			  $(".exclusionsDivClass").removeClass("required");
			  $(".exclusionCommentDivClass").removeClass("required");
		 } 
		  
	  }
  
  function getPolicyCategory(){	  	
/*	     var str=  document.getElementById("previousPolicyNo").value
	    var  policyType = str.includes("XC");
	 if(policyType){
		 swal("\'Fetch key coverages\' provision is only available with past policy numbers that exists in the Vidal Health system.")
		 .then((value) => {
			 document.forms["frmSwPricing"].action=contextpath+"/"+"SoftwareInsurancePricing/getPolicyStatusInfo";
				document.forms["frmSwPricing"].submit(); 
		 });		 		 		
	 }else{
		 document.forms["frmSwPricing"].action=contextpath+"/"+"SoftwareInsurancePricing/getPolicyStatusInfo";
		 document.forms["frmSwPricing"].submit(); 
	 }
	   */
	 document.forms["frmSwPricing"].action=contextpath+"/"+"SoftwareInsurancePricing/getPolicyStatusInfo";
	 document.forms["frmSwPricing"].submit(); 
  }
  
  
  function InpatientIp(val){	  
	  if(val =='Y'){
	      $("#ipCopay").attr("disabled",false);
	      $(".ipCopayDivClass ").addClass("required"); 	      
	  }else{
		  $("#ipCopay").attr("disabled",true);
		  $("#ipCopay").val('');
		  $(".ipCopayDivClass ").removeClass("required"); 		  
	  }	  
  } 
  
  function OutpatientOp(val){	 	
	  if(val =='Y'){
		  $("#opCopayList").attr("disabled",false);				 
		  $(".opCopayDivClass ").addClass("required"); 
	  }else{
		   $("#opCopayList").val('');
		   $("#opCopayList").attr("disabled",true);	  
		   $(".opCopayDivClass ").removeClass("required");
	  }	  
  } 
  
  
  function alAhlihospitalcoverage(val){	 	
	  if(val =='Y'){		
		  $(".allhalliClass").addClass("required");		 
		  $(".allhalliClassdisable").attr("disabled",false);			
	  }else{
		  $(".allhalliClassdisable").val('')
		  $(".allhalliClass").removeClass("required");	  
		  $(".allhalliClassdisable").attr("disabled",true);			
	  }	  
  } 
  
  
  
  
  function lodingResidentCountry(val){
	 
	  if(val !=null && val !=''){
		  $(".residencyCountryClass").attr("readonly",false); 
		  $(".residentCountyDivClass").addClass("required");		  
		  $('#residencyCountryIp').val(0);
		  $('#residencyCountryOp').val(0);
		  $('#residencyCountryOtp').val(0);
		  $('#residencyCountryDent').val(0);
		  $('#residencyCountryMat').val(0);		  		  
	  }else{		
		  $(".residencyCountryClass").attr("readonly",true); 
		  $(".residentCountyDivClass").removeClass("required");
		  $('#residencyCountryIp').val('');
		  $('#residencyCountryOp').val('');
		  $('#residencyCountryOtp').val('');
		  $('#residencyCountryDent').val('');
		  $('#residencyCountryMat').val('');
	  }
	  
  }
  
  function deductibleAtAlAhliApplicable(val){
		
      var AlAhlihosp = $("#alAhlihospital").val(); 
		 
	  if(val == 'N'){
		  $("#opCopyalahlihosp").attr("disabled",true);		  
		  $("#opInvestnAlAhli").attr("disabled",false);
		  $("#opInvestnAlAhli").attr("disabled",false);
		  $("#opPharmacyAlAhli").attr("disabled",false);
		  $("#opothersAlAhli").attr("disabled",false);
		  $("#opConsultAlAhli").attr("disabled",false);
		  $("#iPCopayAtAhliList").attr("disabled",false);
		  $(".opCopyalahlihospDiv").removeClass("required");
		  $(".partOfServiceRequire").addClass("required");				  		  		  		  		  
	  }else{		
		  $("#opCopyalahlihosp").attr("disabled",false); 		  
		  $("#opInvestnAlAhli").attr("disabled",true);
		  $("#opInvestnAlAhli").attr("disabled",true);
		  $("#opPharmacyAlAhli").attr("disabled",true);
		  $("#opothersAlAhli").attr("disabled",true);
		  $("#opConsultAlAhli").attr("disabled",true);
		  $("#iPCopayAtAhliList").attr("disabled",true);
		  $(".opCopyalahlihospDiv").addClass("required");
		  $(".partOfServiceRequire").removeClass("required");
	  }
	  
  }
  
  
  function setDescValues(){
	  
		 var selopCopayListIndex = document.forms[1].opCopayList.selectedIndex;
		 if(selopCopayListIndex !=null && selopCopayListIndex !=''){
		 var selopCopayListText = document.forms[1].opCopayList.options[parseInt(selopCopayListIndex)].text;
		 document.forms[1].opCopayListDesc.value=selopCopayListText;	
		 }else{
			 document.forms[1].opCopayListDesc.value='';
		 }
		 
		 var selopDentalcopayListIndex = document.forms[1].dentalcopayList.selectedIndex;
		 if(selopDentalcopayListIndex !=null && selopDentalcopayListIndex !=''){
		 var selopDentalcopayListText = document.forms[1].dentalcopayList.options[parseInt(selopDentalcopayListIndex)].text;
		 document.forms[1].dentalcopayListDesc.value=selopDentalcopayListText;
		 }else{
			 document.forms[1].dentalcopayListDesc.value='';
		 }
		 
		
	
		/* var selopOpticalCopayListIndex = document.forms[1].opticalCopayList.selectedIndex;
		 var selopOpticalCopayText = document.forms[1].opticalCopayList.options[parseInt(selopOpticalCopayListIndex)].text;
		 document.forms[1].opticalCopayListDesc.value=selopOpticalCopayText;*/
		 
		 document.forms[1].opticalCopayListDesc.value= $("#opticalCopayList option:selected").text();
		 
		 var selorthodonticsCopayIndex = document.forms[1].orthodonticsCopay.selectedIndex;
		 if(selorthodonticsCopayIndex != null && selorthodonticsCopayIndex != ''){
		 var selorthodonticsCopayText = document.forms[1].orthodonticsCopay.options[parseInt(selorthodonticsCopayIndex)].text;
		 document.forms[1].orthodonticsCopayDesc.value=selorthodonticsCopayText;
		 }else{
			 document.forms[1].orthodonticsCopayDesc.value='';
		 }
		 
	/*	 var selopCopaypharmacyIndex = document.forms[1].opCopaypharmacy.selectedIndex;
		 if(selopCopaypharmacyIndex != null && selopCopaypharmacyIndex != ''){
		 var selopCopaypharmacyText = document.forms[1].opCopaypharmacy.options[parseInt(selopCopaypharmacyIndex)].text;
		 document.forms[1].opCopaypharmacyDesc.value=selopCopaypharmacyText;
		 }else{
			 document.forms[1].opCopaypharmacyDesc.value=''; 
		 }*/
		 
		/* var selopInvestigationIndex = document.forms[1].opInvestigation.selectedIndex;
		 if(selopInvestigationIndex !=null && selopInvestigationIndex !=''){
		 var selopInvestigationText = document.forms[1].opInvestigation.options[parseInt(selopInvestigationIndex)].text;
		 document.forms[1].opInvestigationDesc.value=selopInvestigationText;
		 }else{
			 document.forms[1].opInvestigationDesc.value='';
		 }*/
		 
	/*	 var selopCopyconsultnIndex = document.forms[1].opCopyconsultnList.selectedIndex;
		 var selopCopyconsultnText = document.forms[1].opCopyconsultn.options[parseInt(selopCopyconsultnIndex)].text;
		 document.forms[1].opCopyconsultnDesc.value=selopCopyconsultnText;*/
		 /*if($("#opCopyconsultnList option:selected").text() =='Select'){
			 document.forms[1].opCopyconsultnDesc.value='';
		 }else{
			 document.forms[1].opCopyconsultnDesc.value=$("#opCopyconsultnList option:selected").text();
		 }*/
			 
		
		 
		/* var selopCopyothersIndex = document.forms[1].opCopyothers.selectedIndex;
		 if(selopCopyothersIndex !=null && selopCopyothersIndex !=''){
		 var selopCopyothersText = document.forms[1].opCopyothers.options[parseInt(selopCopyothersIndex)].text;
		 document.forms[1].opCopyothersDesc.value=selopCopyothersText;
		 }else{
			 document.forms[1].opCopyothersDesc.value='';
		 }*/
		 
		
		 var selopCopyalahlihospIndex = document.forms[1].opCopyalahlihosp.selectedIndex;
		 if(selopCopyalahlihospIndex !=null &&  selopCopyalahlihospIndex !=''){
		 var selopCopyalahlihospText = document.forms[1].opCopyalahlihosp.options[parseInt(selopCopyalahlihospIndex)].text;
		 document.forms[1].opCopyalahlihospDesc.value=selopCopyalahlihospText;
		 }else{
			 document.forms[1].opCopyalahlihospDesc.value='';
		 }
		 
		/* var selopPharmacyAlAhliIndex = document.forms[1].opPharmacyAlAhli.selectedIndex;
		 if(selopPharmacyAlAhliIndex !=null && selopPharmacyAlAhliIndex !=''){
		 var selopPharmacyAlAhliText = document.forms[1].opPharmacyAlAhli.options[parseInt(selopPharmacyAlAhliIndex)].text;
		 document.forms[1].opPharmacyAlAhliDesc.value=selopPharmacyAlAhliText;
		 }else{
			 document.forms[1].opPharmacyAlAhliDesc.value='';
		 }
		 */
		 
		/* var selopConsultAlAhliIndex = document.forms[1].opConsultAlAhli.selectedIndex;
		 if(selopConsultAlAhliIndex !=null && selopConsultAlAhliIndex !=''){
		 var selopConsultAlAhliText = document.forms[1].opConsultAlAhli.options[parseInt(selopConsultAlAhliIndex)].text;
		 document.forms[1].opConsultAlAhliDesc.value=selopConsultAlAhliText;
		 }else{
			 document.forms[1].opConsultAlAhliDesc.value=''; 
		 }*/
		 
		/* var selopInvestnAlAhliIndex = document.forms[1].opInvestnAlAhli.selectedIndex;
		 var selopInvestnAlAhliText = document.forms[1].opInvestnAlAhli.options[parseInt(selopInvestnAlAhliIndex)].text;
		 document.forms[1].opInvestnAlAhliDesc.value=selopInvestnAlAhliText;*/
	/*	 document.forms[1].opInvestnAlAhliDesc.value=$("#opInvestnAlAhli option:selected").text();
		 
		 var selopothersAlAhliIndex = document.forms[1].opothersAlAhli.selectedIndex;
		 if(selopothersAlAhliIndex !=null && selopothersAlAhliIndex !=''){
		 var selopothersAlAhliText = document.forms[1].opothersAlAhli.options[parseInt(selopothersAlAhliIndex)].text;
		 document.forms[1].opothersAlAhliDesc.value=selopothersAlAhliText;
		 }else{
			 document.forms[1].opothersAlAhliDesc.value='';
		 }*/
		 
		 var selopothersIpCopayIndex = document.forms[1].ipCopay.selectedIndex;
		 if(selopothersIpCopayIndex !=null && selopothersIpCopayIndex !=''){
		 var selopothersIpCopayText = document.forms[1].ipCopay.options[parseInt(selopothersIpCopayIndex)].text;
		 document.forms[1].ipCopayDesc.value=selopothersIpCopayText;
		 }else{
			 document.forms[1].ipCopayDesc.value='';
		 }
		 
		/* var selopothersMaternityLimitListIndex = document.forms[1].maternityCopayList.selectedIndex;
		 if(selopothersMaternityLimitListIndex !=null && selopothersMaternityLimitListIndex !=''){
		 var selopothersMaternityLimitListText = document.forms[1].maternityLimitList.options[parseInt(selopothersMaternityLimitListIndex)].text;
		 document.forms[1].maternityLimitListDesc.value=selopothersMaternityLimitListText;
		 }else{
			 document.forms[1].maternityLimitListDesc.value='';
		 }*/
		 
		 document.forms[1].maternityLimitListDesc.value= $("#maternityCopayList option:selected").text();
		 
		 var selopothersIPCopayAtAhliListIndex = document.forms[1].iPCopayAtAhliList.selectedIndex;
		 if(selopothersIPCopayAtAhliListIndex !=null && selopothersIPCopayAtAhliListIndex !=''){
		 var selopothersIPCopayAtAhliListText = document.forms[1].iPCopayAtAhliList.options[parseInt(selopothersIPCopayAtAhliListIndex)].text;
		 document.forms[1].iPCopayAtAhliListDesc.value=selopothersIPCopayAtAhliListText;
		 }else{
			 document.forms[1].iPCopayAtAhliListDesc.value=''; 
		 }
		 
		 var selopothersPremiumOutputStructureListIndex = document.forms[1].premiumOutputStructureList.selectedIndex;
		 if(selopothersPremiumOutputStructureListIndex !=null && selopothersPremiumOutputStructureListIndex !=''){
		 var selopothersPremiumOutputStructureListText = document.forms[1].premiumOutputStructureList.options[parseInt(selopothersPremiumOutputStructureListIndex)].text;
		 document.forms[1].premiumOutputStructureListDesc.value=selopothersPremiumOutputStructureListText;
		 }else{
			 document.forms[1].premiumOutputStructureListDesc.value='';
		 }
		 
		 
  }
  
  
function openToggle(){
	

	$("#toggleButtonId").addClass("openSidepanel");	
	$('.openSidepanel').click(function(){
	    $('body').addClass('sidebar');
	     var getId = $(this).attr('data-open');
	    $("#"+getId).show("slide", {
	         direction: "right"
	     }, 500);
	    $("#vd-overlay").addClass("vd-overlay-side-panel").fadeIn("slow");
	  });		 		
}




function isTotalLives(obj1,copyobj2,benvalobj3)
{
	var copyobj	=	copyobj2;
	var benvalobj = benvalobj3;
	var totalNoOfLives=document.getElementById("totalNoOfLives").value;
	var MaternitytotLives=document.getElementById("TotalMaternityLives").value;
	/*var totalNoOfLives = document.forms[1].totalNoOfLives.value;
	var MaternitytotLives = document.forms[1].TotalMaternityLives.value;*/
	var first =	 0;
	
	
	for(var i=0;i<9;i++)
	{
										
		if(benvalobj == "6"){
			var inpatientValue =  parseInt(document.getElementById("benf_typeseqid6["+i+"]").value);								 
			if (isNaN(inpatientValue) || inpatientValue == "" || inpatientValue == null || inpatientValue == '' || Number.isNaN(inpatientValue)) {				
				inpatientValue = 0;				
			}	
			
			document.getElementById("dentalTotalLivesCoverdMale["+i+"]").value="";
			document.getElementById("opticalTotalLivesCoverdMale["+i+"]").value="";
			document.getElementById("dentalTotalLivesCoverdMale["+i+"]").value=parseInt(inpatientValue);
			document.getElementById("opticalTotalLivesCoverdMale["+i+"]").value=parseInt(inpatientValue);
			first =	 parseInt(inpatientValue)+parseInt(first);				
			document.getElementById("sumTotalLives").value = first;
			document.getElementById("totalNoOfLives").value = first;
			
			
			
		}
		
		
		if(benvalobj == "1"){
			var maternityValue =  parseInt(document.getElementById("benf_typeseqid1["+i+"]").value);
		
			if ( isNaN( maternityValue ) || maternityValue == "" ) {
				maternityValue = 0;
			}			
			first =	 parseInt(maternityValue)+parseInt(first);			
			document.getElementById("sumTotalLivesMaternity").value = first;
//			document.getElementById("totalMaternityLives_id").value = first;
			document.getElementById("TotalMaternityLives").value = first;
			/*if(first>MaternitytotLives)
			{
				alert("Total covered lives-Maternity more than "+MaternitytotLives);
				document.getElementById("benf_typeseqid1["+copyobj+"]").value	=	"";
				return false;
			}*/
		}
		
											
	}

	
}

function isTotalLivesMat(obj1,copyobj2,benvalobj3){
	
	var copyobj	=	copyobj2;
	var benvalobj = benvalobj3;
	var totalNoOfLives=document.getElementById("totalNoOfLives").value;
	var MaternitytotLives=document.getElementById("TotalMaternityLives").value;
	/*var totalNoOfLives = document.forms[1].totalNoOfLives.value;
	var MaternitytotLives = document.forms[1].TotalMaternityLives.value;*/
	
	
	
	var toFemale = document.getElementsByClassName("totalLiveFemaleClass");
	var validateClassFemale = document.getElementsByClassName("validateClassFemale");
		
	var maternityAge = document.getElementById("agrSeqId["+copyobj2+"]").value;
	var maternityVal = document.getElementById("benf_typeseqid1["+copyobj2+"]").value;
	var matVa;	
	
	if(maternityVal != null && maternityVal != ''){
		matVal = parseInt(maternityVal);
	}
	
	
	for(var i=0;i < toFemale.length;i++){		
		
		var valvalidateClassFemale = validateClassFemale[i].value;
	
		if(valvalidateClassFemale == 7){
			valvalidateClassFemale = 6;
		}
		
		if(maternityAge == valvalidateClassFemale ){
			
			var tofeVal= toFemale[i].value;
		    if(tofeVal != null && tofeVal != ''){
		    var toFev = parseInt(tofeVal);
		    if(matVal > toFev){
		    	
		    	   swal({								
		 			  text:"'Maternity eligible lives' should not be more than 'Total covered lives for female' entered.",
		 			  buttons: true,
		 			  infoMode: true,
		 			})
		 			.then((willDelete) => {
		 			  if (willDelete) {
		 				
		 				document.getElementById("benf_typeseqid1["+copyobj2+"]").value='';
		 				document.getElementById("benf_typeseqid1["+copyobj2+"]").focus();
		 			  } 
		 			});
		    			    	
		    	return false;
		    }
		    	
		    }
			
			
			
		}
	 	 		 	 
	 
	}
	
	var first =	 0;	
	for(var i=0;i<4;i++)
	{
		if(benvalobj == "1"){
			var maternityValue =  parseInt(document.getElementById("benf_typeseqid1["+i+"]").value);
		
			if ( isNaN( maternityValue ) || maternityValue == "" ) {
				maternityValue = 0;
			}
			
			first =	 parseInt(maternityValue)+parseInt(first);
			
			document.getElementById("sumTotalLivesMaternity").value = first;
//			document.getElementById("totalMaternityLives_id").value = first;
			document.getElementById("TotalMaternityLives").value = first;
			/*if(first>MaternitytotLives)
			{
				alert("Total covered lives-Maternity more than "+MaternitytotLives);
				document.getElementById("benf_typeseqid1["+copyobj+"]").value	=	"";
				return false;
			}*/
		}
	}
	
}

function calCulatePer(){
	
    var totalMale= document.getElementById("sumTotalLives").value;
    var totalFemale=document.getElementById("sumTotalLivesFemale").value;   
    var totalM;
    var totalF;
    
    for(var i=0;i<9;i++){
    	var inpatientValue = document.getElementById("benf_typeseqid6["+i+"]").value; 
    	var inpatientValueFe = document.getElementById("benf_typeseqidFe6["+i+"]").value;   
    	
    
    	 
		
    	
    	if(totalMale !=null && totalMale !=''){
    		totalM = parseInt(totalMale);
    	}else{
    		totalM = 0;
    	}
    	
    	if(totalFemale !=null && totalFemale !=''){
    		totalF = parseInt(totalFemale);
    	}else{
    		totalF = 0;
    	}
    	
    	var total =  parseInt(totalM + totalF);   	
    
    	var totalPer=parseInt(inpatientValue/total*100);
	    var totalPerF=parseInt(inpatientValueFe/total*100);
    	
		 
		if (isNaN(totalPer)) {
			totalPer = 0;
		}
			
    	
    	
    	document.getElementById("userPerMale["+i+"]").innerHTML='';
    	document.getElementById("userPerMale["+i+"]").innerHTML=totalPer;  
    	
    	document.getElementById("userPerMalehdn["+i+"]").value='';
    	document.getElementById("userPerMalehdn["+i+"]").value=totalPer; 
    	
    	document.getElementById("userPerFemale["+i+"]").innerHTML='';
    	document.getElementById("userPerFemale["+i+"]").innerHTML=totalPerF; 
    	
    	document.getElementById("userPerFemalehdn["+i+"]").value='';
    	document.getElementById("userPerFemalehdn["+i+"]").value=totalPerF; 
    	
    	
    	document.getElementById("dentalUserMale["+i+"]").value='';
    	document.getElementById("dentalUserMale["+i+"]").value=totalPer; 
    	
    	document.getElementById("opticallUserMale["+i+"]").value='';
    	document.getElementById("opticallUserMale["+i+"]").value=totalPer; 
    	
    	
    	document.getElementById("dentalUserFe["+i+"]").value='';
    	document.getElementById("dentalUserFe["+i+"]").value=totalPerF; 
    	
    	document.getElementById("opticallUserFe["+i+"]").value='';
    	document.getElementById("opticallUserFe["+i+"]").value=totalPerF; 
    	   	    	   	
    	
    }    			
}

function calculatePerMat(){
		
    var totalLifeMaternity= document.getElementById("sumTotalLivesMaternity").value; 
     
    var totalMat;  
    for(var i=0;i<4;i++){
    	var inpatientValueMat = document.getElementById("benf_typeseqid1["+i+"]").value;  
    
    	if(totalLifeMaternity !=null && totalLifeMaternity !=''){    		
    		totalMat = parseInt(totalLifeMaternity);
    	}else{
    		totalMat = 0;
    	}    	
    	var totalPerMAT=parseInt(inpatientValueMat/totalMat*100);    	    	
    	document.getElementById("maternityPerId["+i+"]").innerHTML='';
    	document.getElementById("maternityPerId["+i+"]").innerHTML=totalPerMAT; 
    	
    	document.getElementById("userPerMalehdMat["+i+"]").value='';
    	document.getElementById("userPerMalehdMat["+i+"]").value=totalPerMAT; 
    	
    	
    }    			
}


function calculatePerNal(){
	
	
    var totalLifeNal= document.getElementById("sumNationalityLives").value; 
    
  
    var totalNal;  
    for(var i=0;i<6;i++){
    	var inpatientValueNal = document.getElementById("natl_typeseqid["+i+"]").value;  
    
    	if(totalLifeNal !=null && totalLifeNal !=''){    		
    		totalNal = parseInt(totalLifeNal);
    	}else{
    		totalNal = 0;
    	}    	
    	var totalPerNal=parseInt(inpatientValueNal/totalNal*100);   
    	
    	document.getElementById("nationalPerId["+i+"]").innerHTML='';
    	document.getElementById("nationalPerId["+i+"]").innerHTML=totalPerNal;  
    	
    	document.getElementById("userPerNal["+i+"]").value='';
    	document.getElementById("userPerNal["+i+"]").value=totalPerNal;  
    	
    }    			
}


function isTotalLivesFemale(obj1,copyobj2,benvalobj3)
{
	var copyobj	=	copyobj2;
	var benvalobj = benvalobj3;
	

	var totalNoOfLives = document.getElementById("totalNoOfLivesFenale").value;
	var MaternitytotLives = document.getElementById("TotalMaternityLives").value;
	

	var first =	 0;
	
	
	for(var i=0;i<9;i++)
	{										
		if(benvalobj == "6"){
			var inpatientValue =  parseInt(document.getElementById("benf_typeseqidFe6["+i+"]").value);		
			if ( isNaN( inpatientValue ) || inpatientValue == "" ) {
				inpatientValue = 0;
				
			}	
			document.getElementById("dentalTotalLivesCoverdFemale["+i+"]").value=parseInt(inpatientValue);
			document.getElementById("opticalTotalLivesCoverdFe["+i+"]").value=parseInt(inpatientValue);
			
			first =	 parseInt(inpatientValue)+parseInt(first);				
			document.getElementById("sumTotalLivesFemale").value = first;
			document.getElementById("totalNoOfLivesFenale").value = first;
		}
		
	}

	
}


function isTotalNatLives(obj1,copyobj2)
{
	var copyobj	=	copyobj2;
	/*var totalNoOfLives = document.forms[1].totalNoOfLives.value;*/
	var totalNoOfLives = document.getElementById("totalNoOfLives").value;
	var first =	 0;
	for(var i=0;i<6;i++)
	{
		var natValue =  parseInt(document.getElementById("natl_typeseqid["+i+"]").value);		
		if ( isNaN( natValue ) || natValue == "" ) {
			natValue = 0;
		}
		first =	 parseInt(natValue)+parseInt(first);
		document.getElementById("sumNationalityLives").value = first;
		/*if(first>totalNoOfLives)
		{
			alert("Lives split by nationality is more than "+totalNoOfLives);
			document.getElementById("natl_typeseqid["+copyobj+"]").value	=	"";
			return false;
		}*/
	}
}


function onSaveIncome(obj){
	
	var renevalCase = document.getElementById("renewalYN").value;
	
	/*if(renevalCase == 'Y'){
		swal("Please upload census data.");		
		return false;
		
	}*/
	
	var minMatLives=document.getElementById("minMatLives").value;
	var maxMatLives=document.getElementById("maxMatLives").value;
	
	if(minMatLives ==null || minMatLives =="" || minMatLives ==''){
		swal("Please enter minimum Maternity eligible age.")		
		return false;
	}
	
	/*if(maxMatLives ==null || maxMatLives =="" || maxMatLives ==''){
		swal("Please enter maximum Maternity eligible age.")
		return false;
	}*/
	
	var singlebutton = obj;
	//var sumTotalLivesMaternity=document.forms[1].sumTotalLivesMaternity.value;
	var sumTotalLivesMaternity=document.getElementById("sumTotalLivesMaternity").value;
	
/*	var totalNoOfLives=document.forms[1].totalNoOfLives.value;*/
	var totalNoOfLives=document.getElementById("totalNoOfLives").value;
	
	/*var totalNoOfLives=document.forms[1].totalNoOfLives.value;*/
	
	//var totalNumberOfLive=document.forms[1].numberOfLives.value;
	
	var totalNumberOfLive=document.getElementById("numberOfLives").value;
	
	
	/*var sumNationalityLives=document.forms[1].sumNationalityLives.value;*/
	
	var sumNationalityLives=document.getElementById("sumNationalityLives").value;
	
	/*var sumTotalLives=document.forms[1].sumTotalLives.value;*/
	
	var sumTotalLives=document.getElementById("sumTotalLives").value;
	
	var sumTotalLivesFemale=document.getElementById("sumTotalLivesFemale").value;
	
	var TotalLives =	 parseInt(sumTotalLives);
		TotalLives=TotalLives ? TotalLives : 0;
		
	var TotalLivesFe =	 parseInt(sumTotalLivesFemale);
	  TotalLivesFe=TotalLivesFe ? TotalLivesFe : 0;		
		
	  
    var TotalLivesMaternity =	 parseInt(sumTotalLivesMaternity);
		TotalLivesMaternity= TotalLivesMaternity ? TotalLivesMaternity : 0;	
		
	var NationalityLives =	 parseInt(sumNationalityLives);
		NationalityLives=NationalityLives ? NationalityLives : 0;	
		
	var totLives = parseFloat(sumTotalLives);
		totLives=totLives ? totLives : 0.0;		
		
	var actTotLives=parseFloat(totalNumberOfLive);
		actTotLives=actTotLives ? actTotLives : 0.0;
		
		var totalSum = TotalLives + TotalLivesFe;
		
		if(totalSum==NationalityLives){
			
			if(totalSum>=TotalLivesMaternity){
				
				
				if(sumTotalLives !=0 || sumTotalLivesFemale !=0){
			
			 document.forms["frmSwPricing"].action=contextpath+"/"+"SoftwareInsurancePricing/saveIncome";
			 document.forms["frmSwPricing"].submit();
				}else{
					
					swal('Total covered lives entered should be more than 0.');
					return false;
				}
						
			}else{
				swal(' \'Total covered lives-Maternity\' should be less than or equal to \'Total covered lives\'.');
				return false;
			}
		}else{
			
			swal('\'Total Nationality covered lives\' should equal to \'Total covered lives\'.');
			return false;
		}
			
}

function deleteFile(fileNo,FileName){
	var groupProfileSeq=document.getElementById("groupProfileSeqID").value;
	
	/*if (confirm("do you want delete this file "+FileName+" .")){
		*/
		 swal({
				
			  text: "Do you want delete "+FileName+" ?",
			  buttons: true,
			  infoMode: true,
			})
		/*	.then((willDelete) => {*/
			  if (willDelete) {
				
					$.ajax({
						url : contextpath + "/SoftwareInsurancePricing/deleteFile?fileNo=" + fileNo +"&groupProfileSeq="+groupProfileSeq,
						async : false,
						success : function(response) {
						
							if (response != null) {			
								
								if(response == 'suceess'){
									swal("File deleted succesfully.");									
									document.getElementById("fileDisId["+fileNo+"]").style.display = "none";
									document.getElementById("fileSisId["+fileNo+"]").style.display = "none";
									if(fileNo == 1){
									document.getElementById("srcDoc1Yn["+fileNo+"]").value="N";
									}else if(fileNo  == 2){
										document.getElementById("srcDoc2Yn["+fileNo+"]").value="N";	
									}else if(fileNo  == 3){
										document.getElementById("srcDoc3Yn["+fileNo+"]").value="N";
									}else if(fileNo  == 4){
										document.getElementById("srcDoc4Yn["+fileNo+"]").value="N";
									}else if(fileNo  == 5){
										document.getElementById("srcDoc5Yn["+fileNo+"]").value="N";
									}																	
								}else{
									swal("Please contact administrator.");
									return false;
								}
							} 

						}
					});
				  
			  } else {
			   
			  }
			/*});*/
		
		
	
		
/*	}*/
	
}


function onViewDocument(filename)
{

	
  /* 	var openPage = "/SwInsPricingAction.do?mode=doViewUploadDocs&filename="+filename;	 */
	var groupProfileSeq=document.getElementById("groupProfileSeqID").value;
	
	var openPage = contextpath + "/SoftwareInsurancePricing/doViewUploadDocs?fileNo=" + filename +"&groupProfileSeq="+groupProfileSeq;
   	var w = screen.availWidth - 10;
  	var h = screen.availHeight - 49;
  	var features = "scrollbars=0,status=1,toolbar=0,top=0,left=0,resizable=0,menubar=yes,width="+w+",height="+h;
  	window.open(openPage,'',features);
}


function warnFutureDate(){
	var dateString = document.getElementById('coverStartDate').value;
	
	var sDate  = dateString.split("/");
	var myDate = new Date(sDate[2] ,sDate[1]-1, sDate[0]);
	var today = new Date();
	if( myDate < today ){
		 swal({
				
			  text: " '\Coverage start date\' entered is in the past. Do you want to proceed?",

			  buttons: true,
			  infoMode: true,
			})
			.then((willDelete) => {
			  if (willDelete) {
				  document.getElementById('coverStartDate').value = dateString;
			  }else{
				  document.getElementById('coverEndDate').value="";
			  } 
			});
		
		/*if (confirm('Coverage start date entered is in the past, do you want to proceed?')) {
		
		} else {
		  document.getElementById('coverEndDate').value="";
		} */
		
		
	 }
	var startDate=document.getElementById('coverStartDate').value;
	if(startDate.length==0){
	document.getElementById('coverEndDate').value="";
	}
	var coverStartDate_check=document.getElementById('coverStartDate_check').value;
	if(coverStartDate_check!=startDate){
		document.getElementById('coverEndDate').value="";
		document.getElementById('coverStartDate_check').value=startDate;
	}
	/*if(document.lastModified){
		alert('Modified...');
	}else{
		alert('Not modified...');
	}*/
}


function proLimitApplication(val){	
	document.getElementById('proRATALimitApplicable').value="";
	document.getElementById('proRATALimitApplicable').value=val;	
}

function onClickAreaCover(){  
    var areaCover=$("#areaOfCoverList option:selected").text();
	if(areaCover !=='Select'){
		document.getElementById("areaOfCoverVariations").value="";
		document.getElementById("areaOfCoverVariations").value=areaCover;
		areaOfVariation(areaCover);
	}else{
		document.getElementById("areaOfCoverVariations").value="";	
		areaOfVariation('');
	}			

}

function onChangeTender(val){
	
	if(val !=null && val !=''){
		 var trendFactor = parseFloat(val);
		 if(trendFactor >= 0  && trendFactor < 15){	
		$("#trendFactorIp").val(val);
		$("#trendFactorOp").val(val);
		$("#trendFactorOpt").val(val);
		$("#trendFactorDent").val(val);
		$("#trendFactorMat").val(val);
		  }
	}
}

function onChangeCensusMaternityMin(){
	var minval=document.getElementById("minMatLives").value;
	 if(minval !=null && minval !=''){		
		 
	 }else{
		     document.getElementById("benf_typeseqid1[0]").readOnly = true;
			 document.getElementById("benf_typeseqid1[1]").readOnly = true;
			 document.getElementById("benf_typeseqid1[2]").readOnly = true;
			 document.getElementById("benf_typeseqid1[3]").readOnly = true;  
	 }
	  
	
}


function fileValidationInputScreen(file){	 
    var filePath = file.value;
         	 
    	const fsize  = file.files[0].size;
         const filesi = Math.round((fsize / 1024));          
         if (filesi >= 10240) { 
        	 swal("File size should not exceed 10mb "); 
             document.getElementById(file.id).value="";
             return false;            
         }
   
     
} //  end fileValidation


/*function fileValidationInputScreen(file){	 
    var filePath = file.value;
     const fileSize = file.files.length;   
     if(fileSize <= 5){
    	
    for(var i=0; i < fileSize; i++){
    	const fsize  = file.files[i].size;
         const filesi = Math.round((fsize / 1024)); 
         
         if (filesi >= 10240) { 
             alert("File too Big, please select a file less than 10mb "); 
             document.getElementById("files").value="";
             return false;
            
         }
    }  
     }else{
    	 document.getElementById("files").value="";
    	 alert("please select max 5 files");
    	 return false;
     }
} //  end fileValidation
*/

function onSearchGroupName(){	
	/*var serachPricingNo = document.getElementById("serachPricingNo").value;*/
	
	var serachPricingNo = '';
	var serachGroupId = document.getElementById("serachGroupId").value;
	var serachGroupName = document.getElementById("serachGroupName").value;	
	var serachAlkootBranch = document.getElementById("serachAlkootBranch").value;		
	var parameters="serachPricingNo="+serachPricingNo+"&serachGroupId="+serachGroupId+"&serachGroupName="+serachGroupName+"&serachAlkootBranch="+serachAlkootBranch;
	var xhttpObj=null;
	if(xhttpObj==null){	
		if (window.XMLHttpRequest) {
			// code for modern browsers
			xhttpObj = new XMLHttpRequest();
		} else {
			// code for IE6, IE5
			xhttpObj = new ActiveXObject("Microsoft.XMLHTTP");
		}
	}
	document.getElementById("policyTableGrid").innerHTML ="";
	
	if(sessionStorage.getItem("pageIndexsearch")==="pageindex"){
		xhttpObj.open("GET",contextpath+"/SoftwareInsurancePricing/serachGroupName?"+parameters+"&pageId="+sessionStorage.getItem("pageId"), false);
	}else if(sessionStorage.getItem("pageIndexsearch")==="toggle"){
		xhttpObj.open("GET",contextpath+"/SoftwareInsurancePricing/serachGroupName?"+parameters+"&sortId="+sessionStorage.getItem("sortId"), false);
	}
	else{
		xhttpObj.open("GET",contextpath+"/SoftwareInsurancePricing/serachGroupName?"+parameters, false);

	}
	xhttpObj.send();
	
	var sData=xhttpObj.responseText;
	document.getElementById("policyTableGrid").innerHTML =sData;
	sessionStorage.setItem("pageIndexsearch","");
	sessionStorage.setItem("pageId","");
	sessionStorage.setItem("sortId","");
	
	
	
}
function edit(rownum, sparam) {
	/* alert(".."+$("#policyTypeId").val()); */
	
		document.forms["frmSwPricing"].rownum.value = rownum;
		document.forms["frmSwPricing"].action = contextpath
				+ "/SoftwareInsurancePricing/selectGroupName";
		document.forms["frmSwPricing"].submit();
	
}



function pageIndex(pagenumber,sparam)
{
	sessionStorage.setItem("pageIndexsearch", "pageindex");
	sessionStorage.setItem("pageId",pagenumber);
	onSearchGroupName();
	
}//end of pageIndex


function toggle(sortid,sparam)
{	
	sessionStorage.setItem("pageIndexsearch", "toggle");
	sessionStorage.setItem("sortId",sortid);
	onSearchGroupName();	
}//end of toggle(sortid)

function onchangeNetworkFactor(){
	
  var networkVal= document.getElementById("networkListId").value;
  if(networkVal == '5'){
  var networkValip= document.getElementById("networkListip").value;
  var networkValop= document.getElementById("networkListop").value;
  var networkValopt= document.getElementById("networkListopt").value;
  var networkValdent= document.getElementById("networkListdent").value;
  var networkValmat= document.getElementById("networkListmat").value;
  
  if(networkVal != networkValip || networkVal != networkValop || networkVal != networkValopt || networkVal != networkValdent ||networkVal != networkValmat){	  
	  $("#additionalHospitalCoverageList").attr("disabled",true);
	  $("#hospitalExclusionsList").attr("disabled",true);	  	  
  }else{
	  $("#additionalHospitalCoverageList").attr("disabled",false);
	  $("#hospitalExclusionsList").attr("disabled",false);
  }
  }
	
}

function alertMsg(){
 var clientCode=document.getElementById("clientCode").value;
 
 if(clientCode == null || clientCode == ''){
	 swal("Please fill the client details prior to uploading the census details.");
	 return false;
 }else{
	
	/* $("#btnEnbId").addClass("openSidepanel");*/
	 document.getElementById("btnEnbId").setAttribute('data-open','add_claimant_info');
 }
 
}


function validateLoding(field) {
  var val = field.value;

    if(val != null || val != ''){
     if( val > 50){
    /*	var status= confirm("The loading/discount added here is more than 50%. Please confirm and click 'OK' to proceed.");*/
    	
    	 swal({ 			
   		  text: "The loading/discount added here is more than 50%. Please confirm and click 'OK' to proceed.",
   		  buttons: true,
   		  infoMode: true,
   		})
   		.then((willDelete) => {
   		  if (!willDelete) {
   			field.focus();
			field.value="";
			return false;
   		  } 
   		});   	     	    				
     }
     
     
      if(val < 0 || val > 100 ){
    	 swal("The loading/discount cannot be more than 100%.");
    	    field.focus();
			field.value="";
			return false;
     }	
     
    }
}



function checkValue(element){
	var elemName=element.name;
     var fieldId = element.id;
    
	var elemValue=0;
	if(element.value!='')
		elemValue=parseInt(element.value);
	/*else{
		if('maxBeneLimitOth'==elemName){
			swal(" 'Maximum benefit limit (Others)' cannot be empty.");
			return false;
		}
		if('opticalLimitOth'==elemName){
			swal(" 'Optical limit (Others)' cannot be empty.");
			return false;
		}
		if('dentalLimitOth'==elemName){
			swal( " 'Dental limit (Others)' cannot be empty.");
			return false;
		}
		if('maternityLimitOth'==elemName){
			swal(" 'Maternity limit (Others)' cannot be empty.");
			return false;
		}
		if('maxBeneLimitOthOp'==elemName){
			swal(" 'OP limit (Others)' cannot be empty.");
			return false;
		}
		
		element.focus();
	}*/
	if(element.value!=''){
		if('maxBeneLimitOth'==elemName){
			if(elemValue>10000000){
				element.value = '';		
			    swal({								
					  text: " 'Maximum benefit limit (Others)' cannot be higher than the maximum available option under 'Maximum benefit limit' ",
					  buttons: true,
					  infoMode: true,
					})
					.then((willDelete) => {
					  if (willDelete) {
						  $("#"+fieldId+"").focus();
						  
					  } 
					});

								
				
				return false;
			}if(elemValue==0){
				element.value = '';
				
				 swal({								
					  text: " 'Maximum benefit limit (Others)' cannot be zero.",
					  buttons: true,
					  infoMode: true,
					})
					.then((willDelete) => {
					  if (willDelete) {
						  $("#"+fieldId+"").focus();
						  
					  } 
					});
				return false;
			}
		}
		
		if('maxBeneLimitOthOp'==elemName){
			if(elemValue>80080){
				element.value = '';							
				swal({								
					  text: " 'OP limit (Others)' cannot be higher than the maximum available option under 'OP limit'. ",
					  buttons: true,
					  infoMode: true,
					})
					.then((willDelete) => {
					  if (willDelete) {
						  $("#"+fieldId+"").focus();
						  
					  } 
					});
				return false;
			}if(elemValue==0){
				element.value = '';
				
				
				swal({								
					  text: " 'OP limit (Others)' cannot be zero.",
					  buttons: true,
					  infoMode: true,
					})
					.then((willDelete) => {
					  if (willDelete) {
						  $("#"+fieldId+"").focus();
						  
					  } 
					});
				
				return false;
			}
		}
		
		if('opticalLimitOth'==elemName){
			if(elemValue>18200){
				element.value = '';
				
				swal({								
					  text: " 'Optical limit (Others)' cannot be higher than the maximum available option under 'Optical limit'. ",
					  buttons: true,
					  infoMode: true,
					})
					.then((willDelete) => {
					  if (willDelete) {
						  $("#"+fieldId+"").focus();
						  
					  } 
					});
				
				return false;
			}if(elemValue==0){
				element.value = '';
				swal({								
					  text: " 'Optical limit (Others)' cannot be zero.",
					  buttons: true,
					  infoMode: true,
					})
					.then((willDelete) => {
					  if (willDelete) {
						  $("#"+fieldId+"").focus();
						  
					  } 
					});
			
				return false;
			}
		}
		if('dentalLimitOth'==elemName){
			if(elemValue>72800){
				element.value = '';
				
				swal({								
					  text: " 'Dental limit (Others)' cannot be higher than the maximum available option under 'Dental limit'. ",
					  buttons: true,
					  infoMode: true,
					})
					.then((willDelete) => {
					  if (willDelete) {
						  $("#"+fieldId+"").focus();
						  
					  } 
					});
								
				return false;
			}if(elemValue==0){
				element.value = '';
			
				
				swal({								
					  text:  " 'Dental limit (Others)' cannot be zero.",
					  buttons: true,
					  infoMode: true,
					})
					.then((willDelete) => {
					  if (willDelete) {
						  $("#"+fieldId+"").focus();
						  
					  } 
					});
				return false;
			}
		}
	
		
		if('maternityLimitOth'==elemName){
			if(elemValue>80080){
				element.value = '';
				
				swal({								
					  text: " 'Maternity limit (Others)' cannot be higher than the maximum available option under 'Maternity limit' ",
					  buttons: true,
					  infoMode: true,
					})
					.then((willDelete) => {
					  if (willDelete) {
						  $("#"+fieldId+"").focus();
						  
					  } 
					});
				return false;
			}if(elemValue==0){
				element.value = '';
				
				swal({								
					  text:" 'Maternity limit (Others)' cannot be zero.",
					  buttons: true,
					  infoMode: true,
					})
					.then((willDelete) => {
					  if (willDelete) {
						  $("#"+fieldId+"").focus();
						  
					  } 
					});
				
			
				return false;
			}
		}
	}
	
	
}

function valiForm(){
	var clientMsg="";
	var ststus=false;
	
	var clientCode = document.getElementById("clientCode").value;
	var brokerCode = document.getElementById("brokerCode").value;
	var coverNewStartDate = document.getElementById("coverStartDate").value;
	var coverNewEndDate = document.getElementById("datetimepicker2").value;
	var maxBenifitList = document.getElementById("maxBenifitList").value;
	var areaOfCoverList = document.getElementById("areaOfCoverList").value;
	var premiumRefundApproach =  document.getElementById("premiumRefundApproach").value;             
	var brokername = document.getElementById("brokernameId").value;
	
	var outpatientBenefit = document.getElementById("outpatientBenefit").value;
	var maxBenifitListop = document.getElementById("maxBenifitListop").value;
	var opCopayList = document.getElementById("opCopayList").value;
	var inpatientBenefit = document.getElementById("inpatientBenefit").value;
	var ipCopay = document.getElementById("ipCopay").value;
	var maternityYN = document.getElementById("maternityYN").value;
	var maternityPricingList = document.getElementById("maternityPricingList").value;
	var hospitalExclusionsList = document.getElementById("hospitalExclusionsList").value;
	var discounthospitalExclusions =  document.getElementById("loadinghospitalCoverage").value;
	var discounthospitalComment =  document.getElementById("discounthospitalComment").value;
	var additionalHospitalCoverageList = document.getElementById("additionalHospitalCoverageList").value;
	var loadinghospitalCoverage = document.getElementById("loadinghospitalCoverage").value;
	var loadinghospitalComment = document.getElementById("loadinghospitalComment").value;
	var alAhlihospital = document.getElementById("alAhlihospital").value;
	var opCopyalahlihosp = document.getElementById("opCopyalahlihosp").value;
	var iPCopayAtAhliList = document.getElementById("iPCopayAtAhliList").value;
	
	var maternityYN = document.getElementById("maternityYN").value;
	var maternityLimitList = document.getElementById("maternityLimitList").value;
	var maternityCopayList = document.getElementById("maternityCopayList").value;
	var maternityLimitOth = document.getElementById("maternityLimitOth").value;
	
	var opticalYN = document.getElementById("opticalYN").value; 
	var opticalLimitList = document.getElementById("opticalLimitId").value; 
	var opticalCopayList = document.getElementById("opticalCopayList").value; 
	var opticalFrameLimitList = document.getElementById("opticalCopayList").value; 
	var opticalLimitList = document.getElementById("opticalLimitId").value;
	
	var dentalYN = document.getElementById("dentalYN").value; 
	var dentalLimitList = document.getElementById("dentalLimitList").value; 
	var dentalcopayList = document.getElementById("dentalcopayList").value; 
	var orthodonticsCopay = document.getElementById("orthodonticsCopay").value; 
	
	var dentalLimitList = document.getElementById("dentalLimitList").value; 	
	
	var renewalYN = document.getElementById("renewalYN").value;
	var previousPolicyNo = document.getElementById("previousPolicyNo").value;
	var underWritingYear = document.getElementById("underWritingYear").value;
	var policycategory = document.getElementById("policycategory").value;
	var productCategory = document.getElementById("productCategory").value;

	
	var areaOfCoverVariations = document.getElementById("areaOfCoverVariations").value;
	var areaOfVariationFlag = document.getElementById("areaOfVariationFlag").value;
	
	var loadingAreaListip = document.getElementById("loadingAreaListip").value;
	var loadingAreaListop = document.getElementById("loadingAreaListop").value;
	var loadingAreaListopt = document.getElementById("loadingAreaListopt").value;
	var loadingAreaListdent = document.getElementById("loadingAreaListdent").value;
	var loadingAreaListmat = document.getElementById("loadingAreaListmat").value;
	
	var discountAreaListip = document.getElementById("discountAreaListip").value;
	var discountAreaListop = document.getElementById("discountAreaListop").value;
	var discountAreaListopt = document.getElementById("discountAreaListopt").value;
	var discountAreaListdent = document.getElementById("discountAreaListdent").value;
	var discountAreaListmat = document.getElementById("discountAreaListmat").value;
	
	var residencyCountryList =  document.getElementById("residencyCountryList").value;
	
	var residencyCountryIp = document.getElementById("residencyCountryIp").value;
	
	var residencyCountryOp = document.getElementById("residencyCountryOp").value;
		
	var residencyCountryOtp = document.getElementById("residencyCountryOtp").value;
		
	var residencyCountryDent = document.getElementById("residencyCountryDent").value;
		
    var residencyCountryMat = 	document.getElementById("residencyCountryMat").value;	
	
	
	if(clientCode == '' || clientCode == null || clientCode == ""){
		clientMsg +="\'Client code\' is required.\n";	
		ststus = true;
		
	}
	
	if(brokerCode == '' || brokerCode == null || brokerCode == ""){
		clientMsg +="\'Direct / Broker / Tender\' is required.\n";	
		ststus = true;
			
	
		
	}
	
	if(coverNewStartDate == '' || coverNewStartDate == null || coverNewStartDate == ""){
		clientMsg +="\'Coverage start date\' is required.\n";	
		ststus = true;
			
	}
	
	if(coverNewEndDate == '' || coverNewEndDate == null || coverNewEndDate == ""){
		clientMsg +="\'Coverage end date\' is required.\n";	
		ststus = true;
		
		
	}
	
	if(maxBenifitList == '' || maxBenifitList == null || maxBenifitList == ""){
		clientMsg +="\'Maximum benefit limit\' is required.\n";	
		ststus = true;
		
		
		
	}
	
	if(areaOfCoverList == '' || areaOfCoverList == null || areaOfCoverList == ""){
		clientMsg +="\'Area of cover\' is required.\n";	
		ststus = true;
		
		
	}	
	
	if(premiumRefundApproach == '' || premiumRefundApproach == null || premiumRefundApproach == ""){
		clientMsg +="\'Premium refund approach\' is required.\n";	
		ststus = true;
	
		
	}
			
	if((brokerCode != '' &&  brokerCode != null && brokerCode != "") && brokerCode ==='BRO'){		
		if(brokername  == '' || brokername == null || brokername == ""){
		clientMsg +="\'Broker name\' is required.\n";	
		ststus = true;
	
		
		}
	}
	
	if(outpatientBenefit == 'Y') {			
		if(maxBenifitListop == '' || maxBenifitListop == '' || maxBenifitListop == "") {	
		clientMsg +="\'Op limit\' is required.\n";	
		ststus = true;
		
		
	}
	}
	
   if(outpatientBenefit == 'Y'){	   
	   if(opCopayList == '' || opCopayList == '' || opCopayList == ""){
	   clientMsg +="\'OP copay/deductible\' is required.\n";	
	   ststus = true;
		
	  
	   }
	}
   
   if(inpatientBenefit == 'Y'){		
	   if(ipCopay == '' || ipCopay == null || ipCopay == ""){
		clientMsg +="\'IP copay\' is required.\n";	
		ststus = true;
		
	   }
	}
   
   if(maternityYN == 'Y'){	
	   if(maternityPricingList == '' || maternityPricingList == null || maternityPricingList == ""){
		clientMsg +="\'Maternity pricing\' is required.\n";	
		ststus = true;
	
		
	   }
	}
	
   if(hospitalExclusionsList != '' && hospitalExclusionsList != null && discounthospitalExclusions == ''){
	   clientMsg +="\'Discount for hospital exclusions\' is required.\n";	
		ststus = true;
	
		
   }
   
   if(hospitalExclusionsList != '' && discounthospitalComment != null && discounthospitalComment == ''){
	   clientMsg +="\'Comments (discount for hospital exclusions)\' is required.\n";	
		ststus = true;
		
		
   }
	
   if(additionalHospitalCoverageList != '' && loadinghospitalCoverage != null && loadinghospitalCoverage == ''){
	   clientMsg +="\'Loading for additional hospital coverage\' is required.\n";	
		ststus = true;
		
   }
   
   if(additionalHospitalCoverageList != '' && loadinghospitalComment != null && loadinghospitalComment == ''){
	   clientMsg +="\'Comments (loading for additional hospital coverage)\' is required.\n";	
		ststus = true;
		
		
   }
   
   if(alAhlihospital == 'Y'){	
	   if(opCopyalahlihosp == '' || opCopyalahlihosp == null || opCopyalahlihosp == ""){
		clientMsg +="\'OP copay at Al Ahli\' is required.\n";	
		ststus = true;
	
		
	   }
	}
   
   if(alAhlihospital == 'Y'){	
	   if(iPCopayAtAhliList == '' || iPCopayAtAhliList == null || iPCopayAtAhliList == ""){
		clientMsg +="\'IP copay at Ahli\' is required.\n";	
		ststus = true;
		
		
	   }
	}
   
   if(maternityYN == 'Y'){	
	   if(maternityLimitList == '' || maternityLimitList == null || maternityLimitList == ""){
		clientMsg +="\'Maternity limit\' is required.\n";	
		ststus = true;
		
		
	   }
	}
   
   if(maternityYN == 'Y'){	
	   if(maternityCopayList == '' || maternityCopayList == null || maternityCopayList == ""){
		clientMsg +="\'Maternity copay\' is required.\n";	
		ststus = true;
		
	
	   }
	}
   
   if(maternityYN == 'Y' && maternityLimitList =='45'){	
	   if(maternityLimitOth == '' || maternityLimitOth == null || maternityLimitOth == ""){
		clientMsg +="\'Maternity limit (Others)\' is required.\n";	
		ststus = true;
		
		
	   }
	}
   
   
   if(opticalYN == 'Y'){	
	   if(opticalLimitList == '' || opticalLimitList == null || opticalLimitList == ""){
		clientMsg +="\'Optical limit\' is required.\n";	
		ststus = true;
		
		
	   }
	}
   
   if(opticalYN == 'Y'){	
	   if(opticalCopayList == '' || opticalCopayList == null || opticalCopayList == ""){
		clientMsg +="\'Optical copay\' is required.\n";	
		ststus = true;
		
		
	   }
	}
   
   if(opticalYN == 'Y'){	
	   if(opticalFrameLimitList == '' || opticalFrameLimitList == null || opticalFrameLimitList == ""){
		clientMsg +="\'Frames limit\' is required.\n";	
		ststus = true;
			
		
	   }
	}
   
   
   if(opticalYN == 'Y' && opticalLimitList =='45'){	
	   if(opticalLimitOth == '' || opticalLimitOth == null || opticalLimitOth == ""){
		clientMsg +="\'Optical limit (Others)\' is required.\n";	
		ststus = true;
		
		
	   }
	}
   
   
   if(dentalYN == 'Y'){	
	   if(dentalLimitList == '' || dentalLimitList == null || dentalLimitList == ""){
		clientMsg +="\'Dental limit\' is required.\n";	
		ststus = true;
	
		
	   }
	}
   
   
   if(dentalYN == 'Y'){	
	   if(dentalcopayList == '' || dentalcopayList == null || dentalcopayList == ""){
		clientMsg +="\'Dental copay/deductible\' is required.\n";	
		ststus = true;
		
		
	   }
	}
   
   if(dentalYN == 'Y'){	
	   if(orthodonticsCopay == '' || orthodonticsCopay == null || orthodonticsCopay == ""){
		clientMsg +="\'Orthodontics copay\' is required.\n";	
		ststus = true;
		
		
	   }
	}
   
   if(dentalYN == 'Y' && dentalLimitList =='45'){	
	   if(dentalLimitOth == '' || dentalLimitOth == null || dentalLimitOth == ""){
		clientMsg +="\'Dental limit (Others)\' is required.\n";	
		ststus = true;
	
	
	   }
	}
   
   
   
   if(renewalYN == 'Y'){	
	   if(previousPolicyNo == '' || previousPolicyNo == null || previousPolicyNo == ""){
		clientMsg +="\'Past policy number\' is required.\n";	
		ststus = true;
	
		
	   }
	}
   
   if(renewalYN == 'Y'){	
	   if(underWritingYear == '' || underWritingYear == null || underWritingYear == ""){
		clientMsg +="\'Underwriting year\' is required.\n";	
		ststus = true;
		
		
	   }
	}
   
   if(renewalYN == 'N'){	
	   if(productCategory == '' || productCategory == null || productCategory == ""){
		clientMsg +="\'Plan name\' is required.\n";	
		ststus = true;
	
		
	   }
	}
   
   if(areaOfCoverVariations != null && areaOfCoverVariations !='' &&  areaOfVariationFlag =='Y'){	
	   
	   if((loadingAreaListop == null || loadingAreaListop == '') && (loadingAreaListopt == null || loadingAreaListopt == '') && (loadingAreaListdent == null || loadingAreaListdent == '') && (loadingAreaListmat == null || loadingAreaListmat == '') && (loadingAreaListip == null || loadingAreaListip == '')
			&&   (discountAreaListip == null || discountAreaListip == '')  && (discountAreaListop == null || discountAreaListop == '') && (discountAreaListopt == null || discountAreaListopt == '') && (discountAreaListdent == null || discountAreaListdent == '') &&  (discountAreaListmat == null || discountAreaListmat == '')){
	   
			clientMsg +="\'Loading for area of cover variations\' is required.\n";	
		   ststus = true;
			
	   }
	}
   
  if(residencyCountryList != null && residencyCountryList !=''){	
	   
	   if((residencyCountryIp == null || residencyCountryIp == '')|| (residencyCountryOp == null || residencyCountryOp == '') || (residencyCountryOtp == null || residencyCountryOtp == '') || (residencyCountryDent == null || residencyCountryDent == '') || (residencyCountryMat == null || residencyCountryMat == '')){
	   
			clientMsg +="\'Loading for residency country\' is required.\n";	
		   ststus = true;
		
	}
   
  }
   
	if(ststus){		
		swal(clientMsg);
		return false;		
	}else{
		return true;
	}
	
	
}


function onSaveValOther(){
	
	var maxBenifitList =  document.getElementById("maxBenifitList").value;
	var maxBeneLimitOth  =  document.getElementById("maxBeneLimitOth").value;
	
	var maxBenifitListop =  document.getElementById("maxBenifitListop").value;
	var otherLimitopId  =  document.getElementById("otherLimitopId").value;
	
	var opticalLimitId = document.getElementById("opticalLimitId").value;
	var opticalLimitOth = document.getElementById("opticalLimitOth").value;
	
	var dentalLimitList = document.getElementById("dentalLimitList").value;
	var dentalLimitOth = document.getElementById("dentalLimitOth").value;
	
	var maternityLimitList = document.getElementById("maternityLimitList").value;
	var maternityLimitOth = document.getElementById("maternityLimitOth").value;
	
	
	if(maxBenifitList =='45'){		
		if(maxBeneLimitOth == null || maxBeneLimitOth == '' || maxBeneLimitOth ==""){
			
			swal({								
				  text: " 'Maximum benefit limit (Others)' cannot be empty.",
				  buttons: true,
				  infoMode: true,
				})
				.then((willDelete) => {
				  if (willDelete) {
					$("#maxBeneLimitOth").focus();
				  } 
				});			
		return false;		
		}
	}
	
	if(maxBenifitListop =='45'){
		if(otherLimitopId == null || otherLimitopId =='' || otherLimitopId == ""){
			
			swal({								
				  text: " 'OP limit (Others)' cannot be empty.",
				  buttons: true,
				  infoMode: true,
				})
				.then((willDelete) => {
				  if (willDelete) {
					$("#otherLimitopId").focus();
				  } 
				});
			
		
		return false;
		}
	}
	
	if(opticalLimitId == '45'){
		if(opticalLimitOth == null || opticalLimitOth =='' || opticalLimitOth ==""){
			
			swal({								
				  text:" 'Optical limit (Others)' cannot be empty.",
				  buttons: true,
				  infoMode: true,
				})
				.then((willDelete) => {
				  if (willDelete) {
					$("#opticalLimitOth").focus();
				  } 
				});
	
		return false;
		}
	}
	
	if(dentalLimitList == '45'){		
		if(dentalLimitOth ==null || dentalLimitOth == '' || dentalLimitOth==""){
			
			swal({								
				  text:" 'Dental limit (Others)' cannot be empty.",
				  buttons: true,
				  infoMode: true,
				})
				.then((willDelete) => {
				  if (willDelete) {
					$("#dentalLimitOth").focus();
				  } 
				});
	
		return false;
		}
	}
	
	if(maternityLimitList == '45'){
		if(maternityLimitOth == null || maternityLimitOth =='' || maternityLimitOth == ""){
			
			swal({								
				  text:" 'Maternity limit (Others)' cannot be empty.",
				  buttons: true,
				  infoMode: true,
				})
				.then((willDelete) => {
				  if (willDelete) {
					$("#maternityLimitOth").focus();
				  } 
				});
	
		return false;
		}
	}
	
	return true;
}

function valDate(){

	
	var coverNewStartDate = document.getElementById("coverStartDate").value;
	var coverNewEndDate = document.getElementById("datetimepicker2").value;
	var fixDate;
	var fixEndDate;
	if(coverNewStartDate != null && coverNewStartDate != ''){
		var splitStartDate=coverNewStartDate.split("/");
		fixStartDate =splitStartDate[1]+"/"+splitStartDate[0]+"/"+splitStartDate[2];
	
		
	}

	if(coverNewEndDate != null && coverNewEndDate != ''){
		var splitEndDate=coverNewStartDate.split("/");
		fixEndDate=	splitEndDate[1]+"/"+splitEndDate[0]+"/"+splitEndDate[2];
	
		
	}
	
	var sDate = new Date(fixDate);
	var eDate = new Date(fixEndDate);
	
	
   
	
}


function valiFormProcessButton(){
	
	
	var ststus=false;
	
	var clientCode = document.getElementById("clientCode").value;
	var brokerCode = document.getElementById("brokerCode").value;
	var coverNewStartDate = document.getElementById("coverStartDate").value;
	var coverNewEndDate = document.getElementById("datetimepicker2").value;
	var maxBenifitList = document.getElementById("maxBenifitList").value;
	var areaOfCoverList = document.getElementById("areaOfCoverList").value;
	var premiumRefundApproach =  document.getElementById("premiumRefundApproach").value;             
	var brokername = document.getElementById("brokernameId").value;
	
	var outpatientBenefit = document.getElementById("outpatientBenefit").value;
	var maxBenifitListop = document.getElementById("maxBenifitListop").value;
	var opCopayList = document.getElementById("opCopayList").value;
	var inpatientBenefit = document.getElementById("inpatientBenefit").value;
	var ipCopay = document.getElementById("ipCopay").value;
	var maternityYN = document.getElementById("maternityYN").value;
	var maternityPricingList = document.getElementById("maternityPricingList").value;
	var hospitalExclusionsList = document.getElementById("hospitalExclusionsList").value;
	var discounthospitalExclusions =  document.getElementById("loadinghospitalCoverage").value;
	var discounthospitalComment =  document.getElementById("discounthospitalComment").value;
	var additionalHospitalCoverageList = document.getElementById("additionalHospitalCoverageList").value;
	var loadinghospitalCoverage = document.getElementById("loadinghospitalCoverage").value;
	var loadinghospitalComment = document.getElementById("loadinghospitalComment").value;
	var alAhlihospital = document.getElementById("alAhlihospital").value;
	var opCopyalahlihosp = document.getElementById("opCopyalahlihosp").value;
	var iPCopayAtAhliList = document.getElementById("iPCopayAtAhliList").value;
	
	var maternityYN = document.getElementById("maternityYN").value;
	var maternityLimitList = document.getElementById("maternityLimitList").value;
	var maternityCopayList = document.getElementById("maternityCopayList").value;
	var maternityLimitOth = document.getElementById("maternityLimitOth").value;
	
	var opticalYN = document.getElementById("opticalYN").value; 
	var opticalLimitList = document.getElementById("opticalLimitId").value; 
	var opticalCopayList = document.getElementById("opticalCopayList").value; 
	var opticalFrameLimitList = document.getElementById("opticalCopayList").value; 
	var opticalLimitList = document.getElementById("opticalLimitId").value;
	
	var dentalYN = document.getElementById("dentalYN").value; 
	var dentalLimitList = document.getElementById("dentalLimitList").value; 
	var dentalcopayList = document.getElementById("dentalcopayList").value; 
	var orthodonticsCopay = document.getElementById("orthodonticsCopay").value; 
	
	var dentalLimitList = document.getElementById("dentalLimitList").value; 	
	
	var renewalYN = document.getElementById("renewalYN").value;
	var previousPolicyNo = document.getElementById("previousPolicyNo").value;
	var underWritingYear = document.getElementById("underWritingYear").value;
	var policycategory = document.getElementById("policycategory").value;
	var productCategory = document.getElementById("productCategory").value;

	
	var areaOfCoverVariations = document.getElementById("areaOfCoverVariations").value;
	var areaOfVariationFlag = document.getElementById("areaOfVariationFlag").value;
	
	var loadingAreaListip = document.getElementById("loadingAreaListip").value;
	var loadingAreaListop = document.getElementById("loadingAreaListop").value;
	var loadingAreaListopt = document.getElementById("loadingAreaListopt").value;
	var loadingAreaListdent = document.getElementById("loadingAreaListdent").value;
	var loadingAreaListmat = document.getElementById("loadingAreaListmat").value;
	
	var discountAreaListip = document.getElementById("discountAreaListip").value;
	var discountAreaListop = document.getElementById("discountAreaListop").value;
	var discountAreaListopt = document.getElementById("discountAreaListopt").value;
	var discountAreaListdent = document.getElementById("discountAreaListdent").value;
	var discountAreaListmat = document.getElementById("discountAreaListmat").value;
	
	var residencyCountryList =  document.getElementById("residencyCountryList").value;
	
	var residencyCountryIp = document.getElementById("residencyCountryIp").value;
	
	var residencyCountryOp = document.getElementById("residencyCountryOp").value;
		
	var residencyCountryOtp = document.getElementById("residencyCountryOtp").value;
		
	var residencyCountryDent = document.getElementById("residencyCountryDent").value;
		
    var residencyCountryMat = 	document.getElementById("residencyCountryMat").value;	
    
    var fetchFalgYn = 	document.getElementById("fetchFalgYn").value;	
	
	
    if(fetchFalgYn ==='Y'){
    	document.getElementById("inputScreenChangeFlag").value="";
  		document.getElementById("inputScreenChangeFlag").value="T";
    }
    
    
	if(clientCode == '' || clientCode == null || clientCode == ""){		
		ststus = true;				
	}
	
	if(brokerCode == '' || brokerCode == null || brokerCode == ""){	
		ststus = true;			
	}
	
	if(coverNewStartDate == '' || coverNewStartDate == null || coverNewStartDate == ""){		
		ststus = true;	
	}
	
	if(coverNewEndDate == '' || coverNewEndDate == null || coverNewEndDate == ""){	
		ststus = true;				
	}
	
	if(maxBenifitList == '' || maxBenifitList == null || maxBenifitList == ""){		
		ststus = true;						
	}
	
	if(areaOfCoverList == '' || areaOfCoverList == null || areaOfCoverList == ""){	
		ststus = true;				
	}	
	
	if(premiumRefundApproach == '' || premiumRefundApproach == null || premiumRefundApproach == ""){		
		ststus = true;			
	}
			
	if((brokerCode != '' &&  brokerCode != null && brokerCode != "") && brokerCode ==='BRO'){		
		if(brokername  == '' || brokername == null || brokername == ""){			
		ststus = true;	
		}
	}
	
	if(outpatientBenefit == 'Y') {			
		if(maxBenifitListop == '' || maxBenifitListop == '' || maxBenifitListop == "") {	
		ststus = true;		
	}
	}
	
   if(outpatientBenefit == 'Y'){	   
	   if(opCopayList == '' || opCopayList == '' || opCopayList == ""){	
	   ststus = true;	  	  
	   }
	}
   
   if(inpatientBenefit == 'Y'){		
	   if(ipCopay == '' || ipCopay == null || ipCopay == ""){
		ststus = true;		
	   }
	}
   
   if(maternityYN == 'Y'){	
	   if(maternityPricingList == '' || maternityPricingList == null || maternityPricingList == ""){
		ststus = true;				
	   }
	}
	
   if(hospitalExclusionsList != '' && hospitalExclusionsList != null && discounthospitalExclusions == ''){
		ststus = true;			
   }
   
   if(hospitalExclusionsList != '' && discounthospitalComment != null && discounthospitalComment == ''){
		ststus = true;				
   }
	
   if(additionalHospitalCoverageList != '' && loadinghospitalCoverage != null && loadinghospitalCoverage == ''){
		ststus = true;
		
   }
   
   if(additionalHospitalCoverageList != '' && loadinghospitalComment != null && loadinghospitalComment == ''){	
		ststus = true;				
   }
   
   if(alAhlihospital == 'Y'){	
	   if(opCopyalahlihosp == '' || opCopyalahlihosp == null || opCopyalahlihosp == ""){
		ststus = true;				
	   }
	}
   
   if(alAhlihospital == 'Y'){	
	   if(iPCopayAtAhliList == '' || iPCopayAtAhliList == null || iPCopayAtAhliList == ""){
		ststus = true;				
	   }
	}
   
   if(maternityYN == 'Y'){	
	   if(maternityLimitList == '' || maternityLimitList == null || maternityLimitList == ""){	
		ststus = true;				
	   }
	}
   
   if(maternityYN == 'Y'){	
	   if(maternityCopayList == '' || maternityCopayList == null || maternityCopayList == ""){
		ststus = true;				
	   }
	}
   
   if(maternityYN == 'Y' && maternityLimitList =='45'){	
	   if(maternityLimitOth == '' || maternityLimitOth == null || maternityLimitOth == ""){
		ststus = true;		
		
	   }
	}
   
   
   if(opticalYN == 'Y'){	
	   if(opticalLimitList == '' || opticalLimitList == null || opticalLimitList == ""){
		ststus = true;		
	   }
	}
   
   if(opticalYN == 'Y'){	
	   if(opticalCopayList == '' || opticalCopayList == null || opticalCopayList == ""){
		ststus = true;				
	   }
	}
   
   if(opticalYN == 'Y'){	
	   if(opticalFrameLimitList == '' || opticalFrameLimitList == null || opticalFrameLimitList == ""){
		ststus = true;				
	   }
	}
   
   
   if(opticalYN == 'Y' && opticalLimitList =='45'){	
	   if(opticalLimitOth == '' || opticalLimitOth == null || opticalLimitOth == ""){	
		ststus = true;			
	   }
	}
   
   
   if(dentalYN == 'Y'){	
	   if(dentalLimitList == '' || dentalLimitList == null || dentalLimitList == ""){
		ststus = true;				
	   }
	}
   
   
   if(dentalYN == 'Y'){	
	   if(dentalcopayList == '' || dentalcopayList == null || dentalcopayList == ""){
		ststus = true;			
	   }
	}
   
   if(dentalYN == 'Y'){	
	   if(orthodonticsCopay == '' || orthodonticsCopay == null || orthodonticsCopay == ""){
		ststus = true;				
	   }
	}
   
   if(dentalYN == 'Y' && dentalLimitList =='45'){	
	   if(dentalLimitOth == '' || dentalLimitOth == null || dentalLimitOth == ""){
		ststus = true;		
	   }
	}
   
   
   
   if(renewalYN == 'Y'){	
	   if(previousPolicyNo == '' || previousPolicyNo == null || previousPolicyNo == ""){
		ststus = true;			
	   }
	}
   
   if(renewalYN == 'Y'){	
	   if(underWritingYear == '' || underWritingYear == null || underWritingYear == ""){
		ststus = true;				
	   }
	}
   
   if(renewalYN == 'N'){	
	   if(productCategory == '' || productCategory == null || productCategory == ""){
		ststus = true;			
	   }
	}
   
   if(areaOfCoverVariations != null && areaOfCoverVariations !='' &&  areaOfVariationFlag =='Y'){	
	   
	   if((loadingAreaListop == null || loadingAreaListop == '') && (loadingAreaListopt == null || loadingAreaListopt == '') && (loadingAreaListdent == null || loadingAreaListdent == '') && (loadingAreaListmat == null || loadingAreaListmat == '') && (loadingAreaListip == null || loadingAreaListip == '')
			&&   (discountAreaListip == null || discountAreaListip == '')  && (discountAreaListop == null || discountAreaListop == '') && (discountAreaListopt == null || discountAreaListopt == '') && (discountAreaListdent == null || discountAreaListdent == '') &&  (discountAreaListmat == null || discountAreaListmat == ''))
		   ststus = true;
		  
	}
   
  if(residencyCountryList != null && residencyCountryList !=''){	
	   
	   if((residencyCountryIp == null || residencyCountryIp == '')|| (residencyCountryOp == null || residencyCountryOp == '') || (residencyCountryOtp == null || residencyCountryOtp == '') || (residencyCountryDent == null || residencyCountryDent == '') || (residencyCountryMat == null || residencyCountryMat == '')){	   
		   ststus = true;		  
	}
   
  }
   

if(ststus){
	
	 $(".processDis").attr("disabled",true);			
}else{
	
	 $(".processDis").removeClass("disabled");
}
	
	
}



function onlimitList(){
	var maximumLimitList = $("#maxBenifitList option:selected").text();	  
	  $.ajax({
			url : contextpath+"/"+"SoftwareInsurancePricing/getOpLimitList?maximumLimitList="+ maximumLimitList,
			async : false,
			success : function(response) {
				if (response != null) {														
						
						document.getElementById("maxBenifitListop").innerHTML=response;						
				}

			}
		});
	  	    	  
} // close onNetworkCLick



function onAdditional()
{

    document.forms["Finalpricing"].action =contextpath+"/AdditionalDashboard/Additionalpricingsearch";
    document.forms["Finalpricing"].submit();
    
}


function onViewInputSummary(){
    if ($("#lngprofileseqid").val() != null && $("#lngprofileseqid").val() != "" &&  $("#addedby").val() != null && $("#addedby").val() != "") {
	  var parameterValue = "|" + $("#lngprofileseqid").val() + "|"+ $("#addedby").val() + "|";
	  var parameter = "reportType=PDF&parameter=" + parameterValue
          + "&fileName=viewInputPricing.jrxml&reportID=ViewInputPricing&reportType=PDF";
	  var openPage = contextpath + "/SoftwareInsurancePricing/Report?" + parameter;
      var w = screen.availWidth - 10;
      var h = screen.availHeight - 30;
      var features = "scrollbars=0,status=1,toolbar=0,top=0,left=0,resizable=0,menubar=yes,width="
              + w + ",height=" + h;
      window.open(openPage, '', features);
  } else {
      alert("There is no data to generate the report");
  }
        
}
function savePropsalform(){
	var propsalval=document.getElementById("currencyval").value;
    if(propsalval == ""){
	alert("Please select the currency to proceed.");
	return false;}
    else{
    	document.forms["Propsal"].action =contextpath+"/SoftwareInsurancePricing/GenertaePropsalForm";
	    document.forms["Propsal"].submit();
    }
	
}

function onViewInputSummarybroker(){
    if ($("#lngprofileseqid").val() != null && $("#lngprofileseqid").val() != "" &&  $("#addedby").val() != null && $("#addedby").val() != "") {
	  var parameterValue = "|" + $("#lngprofileseqid").val() + "|"+ $("#addedby").val() + "|";
	  var parameter = "reportType=PDF&parameter=" + parameterValue
          + "&fileName=viewInputPricing.jrxml&reportID=ViewInputPricing&reportType=PDF";
	  var openPage = contextpath + "/SoftwareInsurancePricing/BrokerReport?" + parameter;
      var w = screen.availWidth - 10;
      var h = screen.availHeight - 30;
      var features = "scrollbars=0,status=1,toolbar=0,top=0,left=0,resizable=0,menubar=yes,width="
              + w + ",height=" + h;
      window.open(openPage, '', features);
  } else {
      alert("There is no data to generate the report");
  }
        
}
function Approval(){
	
	document.forms["Propsal"].ApprovalYN.value="Y";
	document.forms["Propsal"].action = contextpath+"/SoftwareInsurancePricing/GenertaePropsalForm";
	 document.forms["Propsal"].submit();
	}

function tobSummary(){
	
    if ($("#lngprofileseqid").val() != null && $("#lngprofileseqid").val() != "" &&  $("#addedby").val() != null && $("#addedby").val() != "") {
	  var parameterValue = "|" + $("#lngprofileseqid").val() + "|"+ $("#addedby").val() + "|";
	  var parameter = "reportType=PDF&parameter=" + parameterValue
          + "&fileName=TOB.jrxml&reportID=TOB&reportType=PDF";
	  document.forms["TOB"].action= contextpath +"/SoftwareInsurancePricing/TobReport?" + parameter;
	  document.forms["TOB"].submit(); 
    /*  var w = screen.availWidth - 10;
      var h = screen.availHeight - 30;
      var features = "scrollbars=0,status=1,toolbar=0,top=0,left=0,resizable=0,menubar=yes,width="
              + w + ",height=" + h;
      window.open(openPage, '', features);*/
  } else {
      alert("There is no data to generate the report");
  }
        
}
/*function downloadPropsal(){
	
    if ($("#lngprofileseqid").val() != null && $("#lngprofileseqid").val() != "") {
	  var parameterValue = $("#lngprofileseqid").val() ;
	  var parameter = "reportType=PDF&parameter=" + parameterValue
          + "&fileName=generalreports/PolicyCopy.jrxml&reportID=PolicyCopy&reportType=PDF";
	  document.forms["Propsal"].action= contextpath +"/SoftwareInsurancePricing/PropsalReport?" + parameter;
	  document.forms["Propsal"].submit(); 
      var w = screen.availWidth - 10;
      var h = screen.availHeight - 30;
      var features = "scrollbars=0,status=1,toolbar=0,top=0,left=0,resizable=0,menubar=yes,width="
              + w + ",height=" + h;
      window.open(openPage, '', features);
  } else {
      alert("There is no data to generate the report");
  }
        
}*/
function downloadPropsalform(){
	
    if ($("#lngprofileseqid").val() != null && $("#lngprofileseqid").val() != "") {
	  var parameterValue = $("#lngprofileseqid").val() ;
	  var parameter = "reportType=PDF&parameter=" + parameterValue
          + "&fileName=generalreports/GenerateQauotation.jrxml&reportID=GenerateQauotation&reportType=PDF";
	  document.forms["Propsal"].action= contextpath +"/SoftwareInsurancePricing/DownloadPropsalForm?" + parameter;
	  document.forms["Propsal"].submit(); 
    /*  var w = screen.availWidth - 10;
      var h = screen.availHeight - 30;
      var features = "scrollbars=0,status=1,toolbar=0,top=0,left=0,resizable=0,menubar=yes,width="
              + w + ",height=" + h;
      window.open(openPage, '', features);*/
  } else {
      alert("There is no data to generate the report");
  }
        
}
function getCountryName(val) {
	
	// document.forms["Propsal"].action=contextpath+"/"+"SoftwareInsurancePricing/getClientName?clientCode="+ val;
	 document.forms["Propsal"].action =contextpath+"/SoftwareInsurancePricing/getval?countyval="+ val;
	  document.forms["Propsal"].submit();
}

function onViewWhatIfReport(){
    var parameterValue = "|" + $("#groupProSeqId").val() + "|"+ $("#versionSeqId") .val() + "|"+ $("#addedby").val() + "|";

    var parameter = "reportType=PDF&parameter=" +parameterValue
        + "&fileName=viewInputPricing.jrxml&reportID=ViewInputPricing&reportType=PDF";
    var openPage = contextpath + "/SoftwareInsurancePricing/whatReport?" + parameter;
    var w = screen.availWidth - 10;
    var h = screen.availHeight - 30;
    var features = "scrollbars=0,status=1,toolbar=0,top=0,left=0,resizable=0,menubar=yes,width="
            + w + ",height=" + h;
    window.open(openPage, '', features);


} 












/*function onViewInputSummary(){
	   var partmeter = "?mode=doViewInputSummary&parameter=|"+document.forms[1].groupseqid.value+"|"+document.forms[1].addedBy.value+"|&fileName=generalreports/viewInputPricing.jrxml&reportID=ViewInputPricing&reportType=PDF";
	   var openPage = "/SwFinalOutputAction.do"+partmeter;
	   var w = screen.availWidth - 10;
	   var h = screen.availHeight - 49;
	   var features = "scrollbars=0,status=1,toolbar=0,top=0,left=0,resizable=0,menubar=yes,width="+w+",height="+h;
	   window.open(openPage,'',features);
	
}*/
function Whatif()
{
    document.forms["Finalpricing"].action =contextpath+"/SoftwareInsurancePricing/Whatif";
    document.forms["Finalpricing"].submit();
    
}

function onAdditional(){
	 document.forms["Finalpricing"].action =contextpath+"/SoftwareInsurancePricing/AdditionalBenefits?submenulink=Additional Benefits";
	 document.forms["Finalpricing"].submit();
}

function ongross(){
	 document.forms["Finalpricing"].action =contextpath+"/SoftwareInsurancePricing/GrossPremium-Working";
	    document.forms["Finalpricing"].submit();
}
function TOB(){
	 document.forms["Propsal"].action= contextpath +"/SoftwareInsurancePricing/TOB?submenulink=TOB";
	  document.forms["Propsal"].submit(); 	
}


function onFinalScreen(){
	  document.forms["whatif"].action =contextpath+"/SoftwareInsurancePricing/FinalPricing";
	    document.forms["whatif"].submit();
}


function saveWhatIfDetails(){
	  
	   var verSrqId = document.getElementById("versionSeqId").value;
	   if(verSrqId == null || verSrqId == '' || verSrqId == "" || verSrqId == 0){
		   swal("Please do estimate change");
		   
		   return false;
	   }
	    document.forms["whatif"].action =contextpath+"/SoftwareInsurancePricing/saveWhatIfDetails";
	    document.forms["whatif"].submit();
}

function saveWhatIfDetailsChange(){
	
	   var verSrqId = document.getElementById("versionSeqId").value;
	   if(verSrqId == null || verSrqId == '' || verSrqId == ""){
		   swal("Please do estimate change");
		   
		   return false;
	   }
	    document.forms["whatif"].action =contextpath+"/SoftwareInsurancePricing/saveWhatIfDetailsChange";
	    document.forms["whatif"].submit();
}


function estimateChange(){
	   setdiscriptionVal();
	   
	   
	    $(".disAreaofCover").removeAttr("disabled");
	    
	    if(valiFormWhatif()){
	    document.forms["whatif"].action =contextpath+"/SoftwareInsurancePricing/estimateChange";
	    document.forms["whatif"].submit();
	    }
	    
}


function setdiscriptionVal(){
	
	if($("#IPcopay option:selected").text() =='Select'){		 
		 $("#iPcopaydesc").val('');
	 }else{
		 $("#iPcopaydesc").val($("#IPcopay option:selected").text());		
	 }
	
	if($("#OPCopayDeductible option:selected").text() =='Select'){		 
		 $("#oPCopayDeductibledesc").val('');
	 }else{
		 $("#oPCopayDeductibledesc").val($("#OPCopayDeductible option:selected").text());		
	 }
	
	/*if($("#OPpharmacycopay option:selected").text() =='Select'){		 
		 $("#oPpharmacycopaydesc").val('');
	 }else{
		 $("#oPpharmacycopaydesc").val($("#OPpharmacycopay option:selected").text());		
	 }*/
	
	/*if($("#OPinvestigationcopay option:selected").text() =='Select'){		 
		 $("#oPinvestigationcopaydesc").val('');
	 }else{
		 $("#oPinvestigationcopaydesc").val($("#OPinvestigationcopay option:selected").text());		
	 }
	*/

	/*if($("#OPconsultationcopay option:selected").text() =='Select'){		 
		 $("#oPconsultationcopaydesc").val('');
	 }else{
		 $("#oPconsultationcopaydesc").val($("#OPconsultationcopay option:selected").text());		
	 }*/
	
	
	/*if($("#OPcopayonotherservices option:selected").text() =='Select'){		 
		 $("#oPcopayonotherservicesdesc").val('');
	 }else{
		 $("#oPcopayonotherservicesdesc").val($("#OPcopayonotherservices option:selected").text());		
	 }*/
	
	
	if($("#OPcopayatAlAhli option:selected").text() =='Not applicable'){		 
		 $("#oPcopayatAlAhlidesc").val('');
	 }else{
		 $("#oPcopayatAlAhlidesc").val($("#OPcopayatAlAhli option:selected").text());		
	 }
	
	/*if($("#OPpharmacycopayatalAhli option:selected").text() =='Not applicable'){		 
		 $("#oPpharmacycopayatalAhlidesc").val('');
	 }else{
		 $("#oPpharmacycopayatalAhlidesc").val($("#OPpharmacycopayatalAhli option:selected").text());		
	 }*/
	
	/*if($("#OPinvestigationcopayatAlAhli option:selected").text() =='Not applicable'){		 
		 $("#oPinvestigationcopayatAlAhlidesc").val('');
	 }else{
		 $("#oPinvestigationcopayatAlAhlidesc").val($("#OPinvestigationcopayatAlAhli option:selected").text());		
	 }*/
	
	/*if($("#OPinvestigationcopayatAlAhli option:selected").text() =='Not applicable'){		 
		 $("#oPinvestigationcopayatAlAhlidesc").val('');
	 }else{
		 $("#oPinvestigationcopayatAlAhlidesc").val($("#OPinvestigationcopayatAlAhli option:selected").text());		
	 }*/
	
/*	if($("#OPconsultationcopayatAlAhli option:selected").text() =='Not applicable'){		 
		 $("#oPconsultationcopayatAlAhlidesc").val('');
	 }else{
		 $("#oPconsultationcopayatAlAhlidesc").val($("#OPconsultationcopayatAlAhli option:selected").text());		
	 }*/
	
	/*if($("#OPconsultationcopayatAlAhli option:selected").text() =='Not applicable'){		 
		 $("#oPconsultationcopayatAlAhlidesc").val('');
	 }else{
		 $("#oPconsultationcopayatAlAhlidesc").val($("#OPconsultationcopayatAlAhli option:selected").text());		
	 }*/
	
	/*if($("#OPotherservicescopayatAlAhli option:selected").text() =='Not applicable'){		 
		 $("#oPotherservicescopayatAlAhlidesc").val('');
	 }else{
		 $("#oPotherservicescopayatAlAhlidesc").val($("#OPotherservicescopayatAlAhli option:selected").text());		
	 }*/
	
	if($("#IPcopayatAlAhli option:selected").text() =='Not applicable'){		 
		 $("#iPcopayatAlAhlidesc").val('');
	 }else{
		 $("#iPcopayatAlAhlidesc").val($("#IPcopayatAlAhli option:selected").text());		
	 }
	
	if($("#Opticalcopay option:selected").text() =='Not applicable'){		 
		 $("#opticalcopaydesc").val('');
	 }else{
		 $("#opticalcopaydesc").val($("#Opticalcopay option:selected").text());		
	 }
}


function isNumberKey(evt){
    var charCode = (evt.which) ? evt.which : evt.keyCode
    return !(charCode > 31 && ((charCode < 48) || (charCode > 57)));
} // isNumberKey



function onNetworkChange(val){	
	  if(val == '5'){
	  $('.networkDetails').val(val);
	  $(".networkTypeClass").show(); 
	  }else{		  
		  $(".networkTypeClass").hide();
	  }
}

function isTreandNumberKey(evt, element) {
	  var charCode = (evt.which) ? evt.which : event.keyCode
	  if (charCode > 31 && (charCode < 48 || charCode > 57) && !(charCode == 46 || charCode == 8))
	    return false;
	  else {
	    var len = $(element).val().length;
	    var index = $(element).val().indexOf('.');
	    if (index > 0 && charCode == 46) {
	      return false;
	    }
	    if (index > 0) {
	      var CharAfterdot = (len + 1) - index;
	      if (CharAfterdot > 3) {
	        return false;
	      }
	    }

	  }
	  return true;
	}

function validateTrend(field){		  	 		 		  
	  var trendFactor = parseFloat(field.value);		  	
	  if(trendFactor < 0  || trendFactor > 14){			  
		  swal("Trend should not exceed 14%");
		    field.focus();
			field.value="";
			return false;			  
	  }	  
}


function areaOfVariation(val){
	
	  if(val !=null && val !=''){
		  $(".areaOfCoverClass").attr("readonly",false);
		  $(".lodingAreaDiv").addClass("required");
		  $(".discountAreaDiv").addClass("required");
		  $('#loadingAreaListip').val(2);
		  $('#loadingAreaListop').val(5);
		  $('#loadingAreaListopt').val(1);
		  $('#loadingAreaListdent').val(2);
		  $('#loadingAreaListmat').val(3);
		  
		  $('#discountAreaListip').val(2);
		  $('#discountAreaListop').val(5);
		  $('#discountAreaListopt').val(1);
		  $('#discountAreaListdent').val(2);
		  $('#discountAreaListmat').val(3);
		
	  }else{
		  $(".areaOfCoverClass").attr("readonly",true);
		  $(".lodingAreaDiv").removeClass("required");
		  $(".discountAreaDiv").removeClass("required");
		  $('#loadingAreaListip').val('');
		  $('#loadingAreaListop').val('');
		  $('#loadingAreaListopt').val('');
		  $('#loadingAreaListdent').val('');
		  $('#loadingAreaListmat').val('');
		  
		  $('#discountAreaListip').val('');
		  $('#discountAreaListop').val('');
		  $('#discountAreaListopt').val('');
		  $('#discountAreaListdent').val('');
		  $('#discountAreaListmat').val('');
	  }
	  	  
}//areaOfVariation

 function  opticalStatus(val){	
	 
	 
	 if(val !=null && val !='' && val=='Y'){		 
		  $(".opticalclass").attr("disabled", false);   
		  $(".opticalDivClass").addClass("required");
	 }else{
		  $(".opticalclass").attr("disabled", true);  
		  $(".opticalDivClass").removeClass("required");
		  $(".opticalclass").val(''); 
	 }	 	 
 }
 
 function dentalStatus(val){
	 if(val !=null && val !='' && val=='Y'){		 
		  $(".dentalClass").attr("disabled", false);   
		  $(".dentalDivClass").addClass("required");
	 }else{
		 $(".dentalClass").val('');
		  $(".dentalClass").attr("disabled", true);  
		  $(".dentalDivClass").removeClass("required");
		  
	 }	 
 }
 
 
 function maternityStatus(val){
	 if(val !=null && val !='' && val=='Y'){
		 
		  $(".maternityClass").attr("disabled", false);
		  $(".maternityDivclass").addClass("required");
	 }else{
		 $(".maternityClass").val('');
		  $(".maternityClass").attr("disabled", true);  
		  $(".maternityDivclass").removeClass("required");
		  
	 } 
	 
 }
 
 
 function InpatientIp(val){	  
	  if(val =='Y'){
	      $("#IPcopay").attr("disabled",false);
	      $(".ipCopayDivClass").addClass("required"); 
	      
	  }else{
		  $("#ipCopay").val("");
		  $("#IPcopay").attr("disabled",true);		
		  $(".ipCopayDivClass").removeClass("required"); 
		  
	  }	  
 } 
 
 function outpatientIP(val){	  
	  if(val =='Y'){
	      $("#OPcopaydeductibleapplicable").attr("disabled",false);
	      $(".opCopayDivClass").addClass("required"); 
	      
	  }else{
		  $("#OPcopaydeductibleapplicable").attr("disabled",true);
		  $("#OPcopaydeductibleapplicable").val('');
		  $(".opCopayDivClass").removeClass("required"); 
		  
	  }	  
} 
 
 
 function opCopayDectable(val){	 
	 if(val =='Y'){
		 $(".opCopayClassY").attr("disabled",false);
		 $(".opCopayClassN").attr("disabled",true);
		 $(".opCopayDeduDivClass").addClass("required"); 
		 $(".opCopayPhaDivClass").removeClass("required"); 
		 
		 
	 }else{
		 $(".opCopayClassY").attr("disabled",true);
		 $(".opCopayClassN").attr("disabled",false);
		 $(".opCopayDeduDivClass").removeClass("required"); 
		 $(".opCopayPhaDivClass").addClass("required"); 
	 }	 
 }

 
 function alAliHospitalCoverage(val){
	 
	 if(val !='' && val == 'Y'){		 		
		 $(".opCopayDivClassY").addClass("required"); 		
		 $("#OPcopayatAlAhli").attr("disabled",false);  		
		 $("#IPcopayatAlAhli").attr("disabled",false);  		
	 }else{
		 $(".opCopayDivClassY").removeClass("required"); 
		 $("#OPcopayatAlAhli").val('')
		 $("#OPcopayatAlAhli").attr("disabled", true);  
		 $("#IPcopayatAlAhli").val('')
		 $("#IPcopayatAlAhli").attr("disabled", true); 
		 
	 }
 }
 
 function opCopayAlhali(val){	 
	 if(val  == 'Y'){
		 $(".opCopayAtAhliDivClassY").attr("disabled",false);
		 $(".opCopayAtAhliDivClassN").attr("disabled",true);
		 $(".opCopayAtAhliDivClassN").val('');
		 $(".opCopayDivClassY").addClass("required"); 
		 $(".opCopayDivClassN").removeClass("required"); 
	 }else{
		 $(".opCopayAtAhliDivClassN").attr("disabled",false);
		 $(".opCopayAtAhliDivClassY").attr("disabled",true);
		 $(".opCopayAtAhliDivClassY").val('');
		 $(".opCopayDivClassN").addClass("required"); 
		 $(".opCopayDivClassY").removeClass("required"); 
	 }
 }
 
 function countryResi(val){	 
	 if(val !=null && val !=''){		 
		  $(".countryResiClass").attr("readonly",false);
		  $('#loadingforcountryofresidenceip').val(0);
		  $('#loadingforcountryofresidenceop').val(0);
		  $('#loadingforcountryofresidenceopt').val(0);
		  $('#loadingforcountryofresidencedent').val(0);
		  $('#loadingforcountryofresidencemat').val(0);
	 }else{
		  $(".countryResiClass").attr("readonly",true);
		  $('#loadingforcountryofresidenceip').val('');
		  $('#loadingforcountryofresidenceop').val('');
		  $('#loadingforcountryofresidenceopt').val('');
		  $('#loadingforcountryofresidencedent').val('');
		  $('#loadingforcountryofresidencemat').val('');
	 }
	 
 }
 
 function additionalHospitalChange(val){
	

	
	 if(val !=null && val !=''){
		
		  $("#Loadingforadditionalhospitalcoverage").attr("readonly",false);
		/*  $("#Commentsloadingforadditional").attr("readonly",false);*/
		  
	 }else{
		 $("#Loadingforadditionalhospitalcoverage").val('');
		  $("#Loadingforadditionalhospitalcoverage").attr("readonly",true);
		/*  $("#Commentsloadingforadditional").attr("readonly",true);*/
	 }
 }
 
 
 function HospitalExclusiveChange(val){		
	 if(val !=null && val !=''){
		  $("#Discountforhospitalexclusions").attr("readonly",false);
		/*  $("#Commentsdiscountforhospital").attr("readonly",false);		  */
	 }else{
		/*  $("#Commentsdiscountforhospital").attr("readonly",true);*/
		 $("#Discountforhospitalexclusions").val('');
		  $("#Discountforhospitalexclusions").attr("readonly",true);
	 }
 }
 
 
 function dynamicTab() {
	 var tabCountVal = document.getElementById("tabCount").value;	
	/* alert("tabCountVal .."+tabCountVal)*/
	 if(tabCountVal =='1'){
	        document.getElementById("tabCount").value='2';	    
	        $(".verClass2").show();	 
	        $(".varLinkClass1").removeClass("active");
	        $(".varLinkClass2").addClass("active");
	        document.forms["whatif"].action =contextpath+"/SoftwareInsurancePricing/activeTabVal?tabval="+"2";
		    document.forms["whatif"].submit();
	     
	        
	 }else if(tabCountVal =='2'){
		   document.getElementById("tabCount").value='3';
		   $(".verClass3").show();
		   $(".varLinkClass1").removeClass("active");
		   $(".varLinkClass2").removeClass("active");
		   $(".varLinkClass3").addClass("active");
		    document.forms["whatif"].action =contextpath+"/SoftwareInsurancePricing/activeTabVal?tabval="+"3";
		    document.forms["whatif"].submit();
	 }
	 
	
	}
 
 function whatIfTab(tabNum){
	 
	 var tabFinalCount = document.getElementById("tabFinalCount").value;
		
	/* alert("tabNum.."+tabNum)
	alert("tabFinalCount..."+tabFinalCount)	*/
	/*if(tabFinalCount > 1){
		tabNum = tabFinalCount;
	}*/
	 
	 if(tabNum =='1'){
		      document.getElementById("tabCount").value='1';
		  	  $(".verClass1").show();	 		 
		      $(".varLinkClass3").removeClass("active");
		      $(".varLinkClass2").removeClass("active");
		      $(".varLinkClass1").addClass("active");
		 }else if(tabNum =='2'){
			  document.getElementById("tabCount").value='2';
			  $(".verClass2").show();	 
			  $(".varLinkClass1").removeClass("active");
			  $(".varLinkClass3").removeClass("active");
			  $(".varLinkClass2").addClass("active");
		 }else if(tabNum =='3'){
			  document.getElementById("tabCount").value='3';
			  $(".verClass3").show();	 
			  $(".varLinkClass1").removeClass("active");
			  $(".varLinkClass2").removeClass("active");
			  $(".varLinkClass3").addClass("active");
		 }
	    document.forms["whatif"].action =contextpath+"/SoftwareInsurancePricing/activeTabVal?tabval="+tabNum;
	    document.forms["whatif"].submit();
 }
 
 function displayLoding(text){

	 
	
	/* var  lodingAreaOfCoverSpanVal = document.getElementById("lodingAreaOfCoverSpanId").innerHTML;*/
	 
if(text === 'plus'){
	
	  $("#lodingId").hide();
	  $(".minusClass").show();
	  $(".plusClass").hide();	  
	  $(".lodingAreaDivClass").show();
}else{

	var ip=document.getElementById("loadingAreaListip").value;
	var op=document.getElementById("loadingAreaListop").value;
	var opt=document.getElementById("loadingAreaListopt").value;
	var dent=document.getElementById("loadingAreaListdent").value;
	var mat=document.getElementById("loadingAreaListmat").value;
	
 	var test="IP:"+ip+"%,OP:"+op+"%, OPT:"+opt+"%, DENT:"+dent+"%, MAT:"+mat+"%";
	document.getElementById("lodingId").innerHTML='';
 	document.getElementById("lodingId").innerHTML=test;
 	
      $("#lodingId").show();
	  $(".lodingAreaDivClass").hide();
	  $(".minusClass").hide();
	  $(".plusClass").show();
}	  
 }
 
 function displayDiscount(text){
	 if(text === 'plus'){
		 $("#discountId").hide();
	 	  $(".minusDiscountClass").show();
	 	  $(".plusDiscountClass").hide();	  
	 	  $(".DiscountDivClass").show();
	 }else{		 		 
			var ip=document.getElementById("discountAreaListip").value;
			var op=document.getElementById("discountAreaListop").value;
			var opt=document.getElementById("discountAreaListopt").value;
			var dent=document.getElementById("discountAreaListdent").value;
			var mat=document.getElementById("discountAreaListmat").value;
			
		 	var test="IP:"+ip+"%,OP:"+op+"%, OPT:"+opt+"%, DENT:"+dent+"%, MAT:"+mat+"%";
			document.getElementById("discountId").innerHTML='';
		 	document.getElementById("discountId").innerHTML=test;
		 	 $("#discountId").show();
	 	  $(".DiscountDivClass").hide();
	 	  $(".minusDiscountClass").hide();
	 	  $(".plusDiscountClass").show();
	 }	  
	  }
 
	  
 function maternitOtherLimitChange(val){
		 	 
	 if(val == '45'){				
		 var testVal= document.getElementById("maternityOtherLimitIdval").value;
		 $('#maternityOtherLimit').val(testVal);
	 }else{		
		 document.getElementById("maternityOtherLimitIdval").value=document.getElementById("maternityOtherLimit").value;
		 $('#maternityOtherLimit').val('0');
		 
	 }
	 
 }

 function maximumOtherLimitChange(val){
 	 
	 if(val == '45'){				
		 var testVal= document.getElementById("maximumBenefitsOtherLimitIdval").value;
		 $('#maximumOtherLimit').val(testVal);
	 }else{		
		 document.getElementById("maximumBenefitsOtherLimitIdval").value=document.getElementById("maximumOtherLimit").value;
		 $('#maximumOtherLimit').val('0');
		 
	 }
	 
 }
 
 function oplimitOtherLimitChange(val){
 	 
	 if(val == '45'){				
		 var testVal= document.getElementById("opLimitOtherLimitIdval").value;
		 $('#opLimitOtherLimit').val(testVal);
	 }else{		
		 document.getElementById("opLimitOtherLimitIdval").value=document.getElementById("opLimitOtherLimit").value;
		 $('#opLimitOtherLimit').val('0');
		 
	 }
	 
 }
 
 function opticalOtherLimitChange(val){ 
	 if(val == '45'){				
		 var testVal= document.getElementById("opticalOtherLimitIdval").value;
		 $('#opticalOtherLimit').val(testVal);
	 }else{		
		 document.getElementById("opticalOtherLimitIdval").value=document.getElementById("opticalOtherLimit").value;
		 $('#opticalOtherLimit').val('0');
		 
	 }
	 
 }
 
 function opticalOtherLimitChange(val){	 
	 if(val == '45'){				
		 var testVal= document.getElementById("dentalOtherLimitIdval").value;
		 $('#dentalOtherLimit').val(testVal);
	 }else{		
		 document.getElementById("dentalOtherLimitIdval").value=document.getElementById("dentalOtherLimit").value;
		 $('#dentalOtherLimit').val('0');
		 
	 }
	 
 }
 
 function changeLoVal(val,type){
	
		 if(type === 'ip'){
			 document.getElementById("iplotemp").value=(val != null)?val:0;
	    }
		 else if(type === 'op'){
			 document.getElementById("oplotemp").value=(val != null)?val:0;
	    }
		 else if(type === 'opt'){
			 document.getElementById("oplottemp").value=(val != null)?val:0;
	    }
		 else if(type === 'dent'){
			 document.getElementById("denlottemp").value=(val != null)?val:0;
	    }
		 else if(type === 'mat'){
			 document.getElementById("matlotemp").value=(val != null)?val:0;
	    }
 }
 
 
 function changeDiVal(val,type){
	
		 if(type === 'ip'){
			 document.getElementById("ipditemp").value=(val != null)?val:0;
	    }
		 else if(type === 'op'){
			 document.getElementById("opditemp").value=(val != null)?val:0;
	    }
		 else if(type === 'opt'){
			 document.getElementById("opldittemp").value=(val != null)?val:0;
	    }
		 else if(type === 'dent'){
			 document.getElementById("dendittemp").value=(val != null)?val:0;
	    }
		 else if(type === 'mat'){
			 document.getElementById("matditemp").value=(val != null)?val:0;
	    }
 }
 
 
 function refreshWhatIf(){
	 
	 swal({			
		  text: "The screen will move back to a 'no change' scenario. Do you want to refresh?",
		  buttons: true,
		  infoMode: true,
		})
		.then((willDelete) => {
		  if (willDelete) {
			  document.forms["whatif"].action =contextpath+"/SoftwareInsurancePricing/refress";
			  document.forms["whatif"].submit();
		  } 
		});
	 
	   
 }
 
 
 function onViewWhatIfReport(){
	 if($("#versionSeqId") .val() != null && $("#versionSeqId") .val() != '0')
	         {
	        
	    var parameterValue = "|" + $("#groupProSeqId").val() + "|"+ $("#versionSeqId") .val() + "|"+ $("#addedby").val() + "|";

	     var parameter = "reportType=PDF&parameter=" +parameterValue
	         + "&fileName=viewInputPricing.jrxml&reportID=ViewInputPricing&reportType=PDF";
	     var openPage = contextpath + "/SoftwareInsurancePricing/whatReport?" + parameter;
	     var w = screen.availWidth - 10;
	     var h = screen.availHeight - 30;
	     var features = "scrollbars=0,status=1,toolbar=0,top=0,left=0,resizable=0,menubar=yes,width="
	             + w + ",height=" + h;
	     window.open(openPage, '', features);
	         }else{
	        	 swal("No Data to display");
	        	 return false;
	        	 
	         }


	 } 
 
 function valiFormWhatif(){
		var clientMsg="";
		var ststus=false;
		
		
		var coverNewStartDate = document.getElementById("coverStartDate").value;
		var coverNewEndDate = document.getElementById("coverEndDate").value;
		var areaofcover = document.getElementById("Areaofcover").value;
		var inpatientip = document.getElementById("Inpatientip").value;
		var outpatientop = document.getElementById("Outpatientop").value;
		var maximumbenefitlimit = document.getElementById("Maximumbenefitlimit").value;
		var opLimit = document.getElementById("opLimit").value;
		var opticalYN = document.getElementById("Optical").value;
		var opticallimit = document.getElementById("Opticallimit").value;
		var opticalcopay = document.getElementById("Opticalcopay").value;
		var frameslimit = document.getElementById("Frameslimit").value;
		var dentalYN = document.getElementById("Dental").value;
		var dentallimit = document.getElementById("Dentallimit").value;
		var dentalcopaydeductible = document.getElementById("Dentalcopaydeductible").value;
		var orthodonticscopay = document.getElementById("Orthodonticscopay").value;
		
		var maternity = document.getElementById("Maternity").value;
		var maternitylimit = document.getElementById("Maternitylimit").value;
		var maternitycopaydeductible = document.getElementById("Maternitycopaydeductible").value;
		
		var alAhliHospitalcoverage = document.getElementById("AlAhliHospitalcoverage").value;
		var oPcopayatAlAhli= document.getElementById("OPcopayatAlAhli").value;
		var iPcopayatAlAhli= document.getElementById("IPcopayatAlAhli").value;
		
		var proratalimitapplicable= document.getElementById("Proratalimitapplicable").value;
		var premumrefundapproach= document.getElementById("Premumrefundapproach").value;
		var trend= document.getElementById("Trend").value;
		
		if(coverNewStartDate == '' || coverNewStartDate == null || coverNewStartDate == ""){
			clientMsg +="\'Coverage start date\' is required.\n";	
			ststus = true;
			
		}
		
		if(coverNewEndDate == '' || coverNewEndDate == null || coverNewEndDate == ""){
			clientMsg +="\'Coverage end date\' is required.\n";	
			ststus = true;
			
		}
					
		if(areaofcover == '' || areaofcover == null || areaofcover == ""){
			clientMsg +="\'Area of cover\' is required.\n";	
			ststus = true;
			
		}	
							
		if(inpatientip == '' || inpatientip == null || inpatientip == ""){
			clientMsg +="\'Inpatient (IP)\' is required.\n";	
			ststus = true;
			
		}	
		
		if(outpatientop == '' || outpatientop == null || outpatientop == ""){
			clientMsg +="\'Outpatient (OP)\' is required.\n";	
			ststus = true;
			
		}	
		
		if(maximumbenefitlimit == '' || maximumbenefitlimit == null || maximumbenefitlimit == ""){
			clientMsg +="\'Maximum benefit limit\' is required.\n";	
			ststus = true;			
		}	
		
		if(opLimit == '' || opLimit == null || opLimit == ""){
			clientMsg +="\'OP Limit\' is required.\n";	
			ststus = true;			
		}	
	   
		
		if(opticalYN == 'Y'){	
			   if(opticallimit == '' || opticallimit == null || opticallimit == ""){
				clientMsg +="\'Optical limit\' is required.\n";	
				ststus = true;
				
			   }
			}
		
		if(opticalYN == 'Y'){	
			   if(opticalcopay == '' || opticalcopay == null || opticalcopay == ""){
				clientMsg +="\'Optical copay\' is required.\n";	
				ststus = true;
				
			   }
			}
		
		if(opticalYN == 'Y'){	
			   if(frameslimit == '' || frameslimit == null || frameslimit == ""){
				clientMsg +="\'Frames limit\' is required.\n";	
				ststus = true;
				
			   }
			}
		
		 if(dentalYN == 'Y'){	
			   if(dentallimit == '' || dentallimit == null || dentallimit == ""){
				clientMsg +="\'Dental limit\' is required.\n";	
				ststus = true;
				
			   }
			}
		 
		 if(dentalYN == 'Y'){	
			   if(dentalcopaydeductible == '' || dentalcopaydeductible == null || dentalcopaydeductible == ""){
				clientMsg +="\'Dental copay/deductible\' is required.\n";	
				ststus = true;
				
			   }
			}
		 
		 
		 if(dentalYN == 'Y'){	
			   if(orthodonticscopay == '' || orthodonticscopay == null || orthodonticscopay == ""){
				clientMsg +="\'Orthodontics copay\' is required.\n";	
				ststus = true;
				
			   }
			}
		
		 if(maternity == 'Y'){	
			   if(maternitylimit == '' || maternitylimit == null || maternitylimit == ""){
				clientMsg +="\'Maternity limit\' is required.\n";	
				ststus = true;
				
			   }
			}
		 
		 if(maternity == 'Y'){	
			   if(maternitycopaydeductible == '' || maternitycopaydeductible == null || maternitycopaydeductible == ""){
				clientMsg +="\'Maternity copay/deductible\' is required.\n";	
				ststus = true;
				
			   }
			}
		 
		 if(alAhliHospitalcoverage == null || alAhliHospitalcoverage == '' || alAhliHospitalcoverage ==""){
			 
			   clientMsg +="\'Al Ahli Hospital coverage\' is required.\n";	
				ststus = true;
		 }
		 
		 if(alAhliHospitalcoverage == 'Y'){	
			   if(oPcopayatAlAhli == '' || oPcopayatAlAhli == null || oPcopayatAlAhli == ""){
				clientMsg +="\'OP copay at Al Ahli\' is required.\n";	
				ststus = true;
				
			   }
			}
		 
		 if(alAhliHospitalcoverage == 'Y'){	
			   if(iPcopayatAlAhli == '' || iPcopayatAlAhli == null || iPcopayatAlAhli == ""){
				clientMsg +="\'IP copay at Al Ahli\' is required.\n";	
				ststus = true;
				
			   }
			}
		 
		 
		 if(proratalimitapplicable == null || proratalimitapplicable == '' || proratalimitapplicable ==""){
			 
			   clientMsg +="\'Pro-rata limit applicable\' is required.\n";	
				ststus = true;
		 }
		 
		 if(premumrefundapproach == null || premumrefundapproach == '' || premumrefundapproach ==""){
			 
			   clientMsg +="\'Premum refund approach\' is required.\n";	
				ststus = true;
		 }
		 
		 if(trend == null || trend == '' || trend ==""){
			 
			   clientMsg +="\'Trend\' is required.\n";	
				ststus = true;
		 }
		 
		 
		if(ststus){		
			swal(clientMsg);
			return false;		
		}else{
			return true;
		}
		
		
	}



function oncalculate()
{
		var fieldvalue =parseFloat(document.getElementById("deductTypePercentage0").value);
		var ContingencyLd =parseFloat(document.getElementById("deductTypePercentage1").value);
		var ManagementDisc =parseFloat(document.getElementById("deductTypePercentage3").value);
		
		
		if(fieldvalue > 20){
			swal("Broking commission should not exceed 20%");
			field.focus();
			return false;
		}
		
		var comments = document.getElementById("loadComments").value;
		if(comments == "" && (ContingencyLd > 0 || ManagementDisc >0))
			{
			swal("Please feed in relevant comments.");
			document.getElementById("loadComments").focus();
			return false;
			}
	
			
		if(!JS_SecondSubmit)
		{
			 document.forms["Grosspremium"].action =contextpath+"/SoftwareInsurancePricing/GrossPremium-Working-calculate";
			   
		    JS_SecondSubmit=true;
		    document.forms["Grosspremium"].submit();
		}//end of if(!JS_SecondSubmit)
}//end of onSave()


function isNumberKey(evt,fValue)
{ 
   var charCode = (evt.which) ? evt.which : evt.keyCode;
   if((fValue.indexOf(".")!=-1)&&charCode == 46){
       return false;
       }
   if (charCode != 46 && charCode > 31 
     && (charCode < 48 || charCode > 57))
      return false;

   return true;
}

function onProcced(){
	
	  document.forms["Grosspremium"].action =contextpath+"/SoftwareInsurancePricing/FinalPricing?submenulink=Final Pricing";
	    document.forms["Grosspremium"].submit();
	
}
function onBack(){
	
	  document.forms["Grosspremium"].action =contextpath+"/SoftwareInsurancePricing/RiskPremium-Working";
	    document.forms["Grosspremium"].submit();
	
}

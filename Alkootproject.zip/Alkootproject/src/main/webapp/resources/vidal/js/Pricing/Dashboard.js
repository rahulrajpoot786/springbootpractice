
   function onAlertSearch()
   {
	   

      document.forms["DashboardForm"].action = "/Alkootproject/PricingDashboard/Search";
      document.getElementById("dashsearch").innerHTML="Please Wait...";
      document.forms["DashboardForm"].submit();
    }
   
 
   
   function onBack()
   {
	  
      document.forms["Delete"].action = "/Alkootproject/PricingDashboard/doBack";
         document.forms["Delete"].submit();
    }

   

/*   function onApproved(){
		
	   document.forms["DashboardForm"].approvedYN.value="Y";
	   document.forms["DashboardForm"].action = "/Alkootproject/PricingDashboard/Search";
	    document.forms["DashboardForm"].submit();
	   } */


         
            
        
function pendingApproval(){
	
document.forms["DashboardForm"].pendingApprovalYN.value="Y";
document.forms["DashboardForm"].action = "/Alkootproject/PricingDashboard/Search";
 document.forms["DashboardForm"].submit();
}

function pageIndex(pagenumber, str) {
	
	if(str =='politableData'){
		sessionStorage.setItem("pageIndexsearch", "pageindex");
		sessionStorage.setItem("pageId",pagenumber);
		onSearchGroupName();
	}else{
		document.forms["DashboardForm"].pageId.value = pagenumber;
		document.forms["DashboardForm"].action ="/Alkootproject/PricingDashboard/Search";
		document.forms["DashboardForm"].submit();
	}
	
	
}


function PressForward()
	{
	  
	document.forms["DashboardForm"].action="/Alkootproject/PricingDashboard/forwardpricingsearch";
	document.forms["DashboardForm"].submit();	
}
function PressBackWard(){
		
		document.forms["DashboardForm"].action="/Alkootproject/PricingDashboard/backwardpricingsearch";
		document.forms["DashboardForm"].submit();	
	}



function toggle(sortid)

{	
	
    $('#sortId').val(sortid);
    document.getElementById('sortId').value = sortid;
    $("#DashboardForm").submit();
      document.forms["DashboardForm"].action =contextpath+"/PricingDashboard/Search";	  
	   JS_SecondSubmit=true;
	    document.forms["DashboardForm"].submit();

  
}//end of toggle(sortid) 

function displayInputScreen(){

	document.forms[0].action=contextpath+"/displayTab?status=New";
	document.forms[0].submit();
	
}
function ondelete_icon(rownum)
{
	document.forms["DashboardForm"].rownum.value=rownum;

    document.forms["DashboardForm"].action =contextpath+"/PricingDashboard/doDelete";
    document.forms["DashboardForm"].submit();
	  
}

function doDeleteSave()

{
	
	 swal({
			
		  text: "Please confirm if you want to delete this pricing.",

		  buttons: true,
		  infoMode: true,
		})
		.then((willDelete) => {
		  if (willDelete) {
			  var remark=$("#logDesc").val();
				if(remark !=null && remark != "" && remark !=''){
					document.forms["Delete"].action =contextpath+"/PricingDashboard/doDeleteSave";
					  $('.disableAttribute').removeAttr("disabled");
			      	  document.getElementById("Delete").disabled = true; 
			      	 if(!JS_SecondSubmit){
			      		JS_SecondSubmit=true;
			      		 document.forms["Delete"].submit();
			      	 }
				}else{
					swal("Enter the Reason For Deletion");
					return false;
				}
		  } 
		});
	
	
	/*var checkbox=confirm("Please confirm if you want to delete this pricing.");
	if(checkbox){
	var remark=$("#logDesc").val();
	if(remark !=null && remark != "" && remark !=''){
		document.forms["Delete"].action =contextpath+"/PricingDashboard/doDeleteSave";
		  $('.disableAttribute').removeAttr("disabled");
      	  document.getElementById("Delete").disabled = true; 
      	 if(!JS_SecondSubmit){
      		JS_SecondSubmit=true;
      		 document.forms["Delete"].submit();
      	 }
	}else{
		swal("Enter the Reason For Deletion");
		return false;
	}
	}*/
    
   
    
}

function checkBox() {
	
	var approved = document.getElementById("ApprovedId");
	if(approved.checked){
		document.getElementById("ApprovedId").value="N";
	}else{
		document.getElementById("ApprovedId").value="Y";
	}
	
	
/*document.forms["DashboardForm"].rownum.value=rownum;

    document.forms["DashboardForm"].action =contextpath+"/PricingDashboard/inputpricingsearch";
    document.forms["DashboardForm"].submit();*/
    
}
function edit(rownum,type)
{
    if(type =='politableData'){
    	    	
    	$.ajax({
    		url : contextpath + "/PricingDashboard/selectGroupPricingClientName?rownum=" + rownum,
    		async : false,
    		success : function(response) {    			           
              if(response !="" && response != null){            	  
            	  var spitVal = response.split("~");            	              	
            	  document.getElementById("groupclientCode").value=spitVal[0];
            	  document.getElementById("groupclientName").value=spitVal[1];
            	  $(".closeGroupPricingClass").click();
            	  
              }
    		}
    	});
    	
    }else{
    	document.forms[1].rownum.value=rownum;
   		 document.forms[1].action =contextpath+"/SoftwareInsurancePricing/EditInputs-Screen?edit="+"N";
    	document.forms[1].submit();

    }
} 

function onedit_icon(rownum)
{

    document.forms[1].rownum.value=rownum;
    document.forms[1].action =contextpath+"/SoftwareInsurancePricing/EditInputs-Screen?edit="+"Y";
    document.forms[1].submit();

}
 


function checkBox1() {
	
	var approved = document.getElementById("PendingId");
	if(approved.checked){
		document.getElementById("PendingId").value="N";
	}else{
		document.getElementById("PendingId").value="Y";
	}
	

     } 

function checkBox2() {
	var approved = document.getElementById("RejectId");
	if(approved.checked){
		document.getElementById("RejectId").value="N";
	}else{
		document.getElementById("RejectId").value="Y";
	}
	

     } 

function osSerchGroupricing(){
		
	 var clientCode = $("#groupclientCode").val();
	 var clientName = document.getElementById("groupclientName").value;
	 var startDate = document.getElementById("datetimepicker3").value;
	 var endDate = document.getElementById("datetimepicker4").value;	
	 
	 if(clientCode ==null || clientCode ==""){	
		
		 swal("'Client Code' is required.");		 
		 return false;
	 }if(clientName ==null || clientName ==""){		 
		 swal("'Client Name' is required");		 
		 return false;
	 }if(startDate ==null || startDate ==""){		 
		 swal("'Coverage start date' is required");		 
		 return false;
	 }if(endDate ==null || endDate ==""){		 
		 swal("'Coverage end date' is required");		 
		 return false;
	 }	 
	 
	$.ajax({
		url : contextpath + "/PricingDashboard/serchGroupPricing?clientCode=" +clientCode +"&clientName="+clientName +"&startDate="+startDate +"&endDate="+endDate,
		async : false,
		success : function(response) {	
			
			document.getElementById("groupPricingGrid").innerHTML=response;

		}
	});
	
}



function getClientName(val) {
	
	$.ajax({
		url : contextpath + "/PricingDashboard/getClientNamegroup?clientCode=" + val,
		async : false,
		success : function(response) {
			if (response != null) {			
								
			document.getElementById("groupclientName").value = response;
			} else {
				document.getElementById("groupclientName").value = "";
			}

		}
	});
	  
} // getClientName


function fetchGroupDetails(){
	
	
	var chechStatus= parseInt(document.getElementById("checkSize").value);
	
	if(chechStatus != null && chechStatus > 0){
	var groupPriCla = document.getElementsByClassName("groupCheckClass");	
	
	var groupPricing="||";
	var count=0;
	
	var statusFlag1 = 0;
	var statusFlag2 = 0;
	var flag = true;
	var flag1 = true;

	 let arr=[];
	for (i = 0; i < groupPriCla.length; i++)  
	{ 		
		var checkstatus = document.getElementById("groupPricing["+i+"]").checked;		
		
	
	   if(checkstatus){	
		   
		   
		   var status = document.getElementById("groupSelectionId["+i+"]").value;
		   
		  arr.push(status);
				  		   
				 		   		   		 		  		  
		   groupPricing += document.getElementById("groupProSeqId["+i+"]").value+"||";
		   count ++;		   
	   }
	   			 	  
	} 

	   if(parseInt(count) == 0){
		   swal("No PRC selected.");
		   return false;
	   }
	   
	
	
	   if(parseInt(count) > 6 ){
		   swal("Please select maximum of 6 pricings.");
		   return false;
	   }
	   
	 
	
	 
	 if(find_duplicate_in_array(arr)){
		 swal("Please note more than one PRC has been selected for the same plan. Please review.");
		 return false;
	 }
	 
	 
	    
	 
	 var fetchType = getFetchFalg(groupPricing);
	 
	
	 
	 if(fetchType === 'TRUE'){
		 swal("Please note there are more plans to be considered for the group pricing to be complete.");
		 return false;
	 }
	 
	    document.forms[1].rownum.value=rownum;
	    document.forms[1].action =contextpath+"/PricingDashboard/groupPricingDisplay?groupPricing="+groupPricing;
	    document.forms[1].submit();
	    
	}else{
		swal("Please note the tool currently allows a maximum of 6 PRC's to be fetched.");
		return false;
	}  
	
}


function find_duplicate_in_array(a) {
	
	for(var i = 0; i <= a.length; i++) {
        for(var j = i; j <= a.length; j++) {
            if(i != j && a[i] == a[j]) {
                return true;
            }
        }
    }
    return false;

    }

function onserach(){
	var approved = document.getElementById("ApprovedId").value;
	var Pending = document.getElementById("PendingId").value;
	var Reject = document.getElementById("RejectId").value;
	var parameter="";
	
		parameter ="?approved="+approved+"&Pending="+Pending+"&Reject="+Reject;
	document.forms["DashboardForm"].action = "/Alkootproject/PricingDashboard/SearchwithStatus"+parameter;
    document.forms["DashboardForm"].submit();
}


function onSearchGroupName(){	
	/*var serachPricingNo = document.getElementById("serachPricingNo").value;*/
	var serachGroupId = document.getElementById("serachGroupId").value;
	var serachGroupName = document.getElementById("serachGroupName").value;	
	var serachAlkootBranch = document.getElementById("serachAlkootBranch").value;
	var serachPricingNo = '';
	
	var parameters="serachPricingNo="+serachPricingNo+"&serachGroupId="+serachGroupId+"&serachGroupName="+serachGroupName+"&serachAlkootBranch="+serachAlkootBranch;
	var xhttpObj=null;
	if(xhttpObj==null){	
		if (window.XMLHttpRequest) {
			// code for modern browsers
			xhttpObj = new XMLHttpRequest();
		} else {
			// code for IE6, IE5
			xhttpObj = new ActiveXObject("Microsoft.XMLHTTP");
		}
	}
	document.getElementById("policyTableGrid").innerHTML ="";
	
	if(sessionStorage.getItem("pageIndexsearch")==="pageindex"){
		xhttpObj.open("GET",contextpath+"/SoftwareInsurancePricing/serachGroupName?"+parameters+"&pageId="+sessionStorage.getItem("pageId"), false);
	}else if(sessionStorage.getItem("pageIndexsearch")==="toggle"){
		xhttpObj.open("GET",contextpath+"/SoftwareInsurancePricing/serachGroupName?"+parameters+"&sortId="+sessionStorage.getItem("sortId"), false);
	}
	else{
		xhttpObj.open("GET",contextpath+"/SoftwareInsurancePricing/serachGroupName?"+parameters, false);

	}
	xhttpObj.send();
	
	var sData=xhttpObj.responseText;
	document.getElementById("policyTableGrid").innerHTML =sData;
	sessionStorage.setItem("pageIndexsearch","");
	sessionStorage.setItem("pageId","");
	sessionStorage.setItem("sortId","");
	
	
	
}

function getFetchFalg(val) {
	var flag;
		
	$.ajax({
		url : contextpath + "/PricingDashboard/getFeatchFlag?fetchseqId=" + val,
		async : false,
		success : function(response) {
			
		
			flag = response;
		}
	});
	  
	return flag;
} // getClientName


/**
 * 
 */

  function isNumberKey(evt){
	    var charCode = (evt.which) ? evt.which : evt.keyCode
	    return !(charCode > 31 && ((charCode < 48) || (charCode > 57)));
	} // isNumberKey
	

function calCulateRiskprimium(){
	
	var totaliterate = document.getElementById("totaliterate").value;
	var prpINPCPM = document.getElementById("prpINPCPM").value;
	var prpOUTCPM = document.getElementById("prpOUTCPM").value;
	var prpMATCPM = document.getElementById("prpMATCPM").value;
	var prpOPTCPM = document.getElementById("prpOPTCPM").value;
	var prpDENTCPM = document.getElementById("prpDENTCPM").value;
	var isDurationComp = document.getElementById("durationcheckId").value;
	
	
	
	if ( isNaN( prpINPCPM ) || prpINPCPM === "" ) {
		prpINPCPM = 0;
	}
	if ( isNaN( prpOUTCPM ) || prpOUTCPM === "" ) {
		prpOUTCPM = 0;
	}
	if ( isNaN( prpMATCPM ) || prpMATCPM === "" ) {
		prpMATCPM = 0;
	}
	if ( isNaN( prpOPTCPM ) || prpOPTCPM === "" ) {
		prpOPTCPM = 0;
	}
	if ( isNaN( prpDENTCPM ) || prpDENTCPM === "" ) {
		prpDENTCPM = 0;
	}
	
	var increditfirstvalue = 0;
	var outpatientfirstvalue = 0;
	var maternityfirstvalue = 0;
	var opticalfirstvalue = 0;
	var dentalfirstvalue = 0;
	
	for(var i=0;i<totaliterate;i++)
	{
		var inpatientcrediblty = document.getElementById("inpatientcrediblty["+i+"]").value;
		var outpatientcrediblty = document.getElementById("outpatientcrediblty["+i+"]").value;
		var maternitycrediblty = document.getElementById("maternitycrediblty["+i+"]").value;
		var opticalcrediblty = document.getElementById("opticalcrediblty["+i+"]").value;
		var dentalcrediblty = document.getElementById("dentalcrediblty["+i+"]").value;
		
	/*	alert("inpatientcrediblty...."+inpatientcrediblty);
		alert("outpatientcrediblty...."+outpatientcrediblty);
		alert("maternitycrediblty...."+maternitycrediblty);
		alert("opticalcrediblty...."+opticalcrediblty);
		alert("dentalcrediblty...."+dentalcrediblty);*/
		
		if ( isNaN( inpatientcrediblty ) || inpatientcrediblty == "" ) {
			inpatientcrediblty = 0;
		}
		if ( isNaN( outpatientcrediblty ) || outpatientcrediblty == "" ) {
			outpatientcrediblty = 0;
		}
		if ( isNaN( maternitycrediblty ) || maternitycrediblty == "" ) {
			maternitycrediblty = 0;
		}
		if ( isNaN( opticalcrediblty ) || opticalcrediblty == "" ) {
			opticalcrediblty = 0;
		}
		if ( isNaN( dentalcrediblty ) || dentalcrediblty == "" ) {
			dentalcrediblty = 0;
		}
		increditfirstvalue =	 parseFloat(inpatientcrediblty)+parseFloat(increditfirstvalue);
		outpatientfirstvalue =	 parseFloat(outpatientcrediblty)+parseFloat(outpatientfirstvalue);
		maternityfirstvalue =	 parseFloat(maternitycrediblty)+parseFloat(maternityfirstvalue);
		opticalfirstvalue =	     parseFloat(opticalcrediblty)+parseFloat(opticalfirstvalue);
		dentalfirstvalue =	     parseFloat(dentalcrediblty)+parseFloat(dentalfirstvalue);
		
		

	}
	 /* var riskipval=document.getElementById("Miscellaneous.1");
      if(riskipval.readonly){
    	  
      }else{
    	  alert("Inpatient credibility numbers should add up to 100%");
  		return false;
      }*/
	

	var ipClassElement=document.getElementsByClassName('validateIpClass');
	for(var inc=0;inc<ipClassElement.length;inc++){
		var dataElement=ipClassElement[inc];
		if(dataElement.readOnly){
			if(dataElement.readOnly==true){
			/*	alert("Element value::"+dataElement.value);*/
			}
				
			}
	}
	

	/*alert("prpINPCPM..."+prpINPCPM + "..." +increditfirstvalue);
	alert("prpOUTCPM..."+prpOUTCPM + "..." +outpatientfirstvalue);
	alert("prpMATCPM..."+prpMATCPM + "..." +maternityfirstvalue);
	alert("prpOPTCPM..."+prpOPTCPM + "..." +opticalfirstvalue);
	alert("prpDENTCPM..."+prpDENTCPM + "..." +dentalfirstvalue);*/
	
	
	if(prpINPCPM > 0 && increditfirstvalue != 100)
	{
		swal("Inpatient credibility numbers should add up to 100%.");
		return false;
	}
	
	if(prpOUTCPM > 0 && outpatientfirstvalue != 100)
	{
		swal("Outpatient credibility numbers should add up to 100%.");
		return false;
	}
	
	
	if(prpOPTCPM > 0 && opticalfirstvalue != 100)
	{
		swal("Optical credibility numbers should add up to 100%.");
		return false;
	}
	
	if(prpDENTCPM > 0 && dentalfirstvalue != 100)
	{
		swal("Dental credibility numbers should add up to 100%.");
		return false;
	}
	
	if(prpMATCPM > 0 && maternityfirstvalue != 100)
	{
		swal("Maternity credibility numbers should add up to 100%.");
		return false;
	}
	
	
	if(isDurationComp=='false'){
		 swal('Policy duration for one or more past policies here is not exactly 12 months. Please note this while finalizing credibility(%), as the cost shown is for the respective policy period and is not annualized.')
		 .then((value) => {
			 document.forms[1].action=contextpath+"/"+"SoftwareInsurancePricing/doSaveCalculate?focusId=riskPrimiumCalId";
			 document.forms[1].submit();
		 });
		
		/* window.alert("Policy duration for one or more past policies here is not exactly 12 months. Please note this while finalizing credibility(%), as the cost shown is for the respective policy period and is not annualized.");*/
	}else{

		   document.forms[1].action=contextpath+"/"+"SoftwareInsurancePricing/doSaveCalculate?focusId=riskPrimiumCalId";
		   document.forms[1].submit();
	}
	

	

}

function back()
{

   
    document.forms[1].action =contextpath+"/SoftwareInsurancePricing/Inputs-Screen";
    document.forms[1].submit();

} 


function calCulatedProjectedClaims(){
	
	  var preposeFlag = document.getElementById("proposedFlag").value;
	  if(preposeFlag === 'N'){
		  swal("Please Calculate Preposed Policy");
		  return false;
	  }
	  var claimComment = document.getElementById("projectClaimComment").value;
	  document.forms[1].action=contextpath+"/"+"SoftwareInsurancePricing/doSaveCalculateClaimCost?claimComment="+claimComment +"&focusId=calulateLodingID";
	   document.forms[1].submit();
	  
}

function onSaveIncome(){	
	   document.forms["frmSwPolicyConfig"].action=contextpath+"/"+"SoftwareInsurancePricing/saveRiskPrimium";
	   document.forms["frmSwPolicyConfig"].submit();
}


function onbenefitvalueCheck(objvalue1,credibility){
	
	if(credibility == "inpatient")
		{
			if(document.getElementById("inPatientCPMvalue").value == ""){
				swal("Please enter inpatient current policy experience");
				objvalue1.value = "";
				return false;
			}
		}

	if(credibility == "outpatient")
		{
			if(document.getElementById("outPatientCPMvalue").value == ""){
				swal("Please enter outpatient current policy experience.");
				objvalue1.value = "";
				return false;
			}
		}
		
	if(credibility == "maternity")
		{
			if(document.getElementById("maternityCPMvalue").value == ""){
				swal("Please enter maternity current policy experience.");
				objvalue1.value = "";
				return false;
			}
		}
	if(credibility == "optical")
		{
			if(document.getElementById("opticalCPMvalue").value == ""){
				swal("Please enter optical current policy experience.");
				objvalue1.value = "";
				return false;
			}
		}	
	if(credibility == "dental")
		{
			if(document.getElementById("dentalCPMvalue").value == ""){
				swal("Please enter dental current policy experience.");
				objvalue1.value = "";
				return false;
			}
		}
	
	  
	
}

   function onViewGrosspremium(){	   
	   document.forms[1].action=contextpath+"/"+"SoftwareInsurancePricing/GrossPremiumWorkingProcess";
	   document.forms[1].submit();	
   }


   function isNumeric(field) {
       var re = /^[0-9]*\.*[0-9]*$/;
       if (!re.test(field.value)) {
    	   swal("Data entered must be numeric.");
			field.focus();
			field.value="";
			return false;
       }
   }

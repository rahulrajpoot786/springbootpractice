package com.vidal.common.annotation.validator;

import java.util.regex.Pattern;

import org.springframework.expression.spel.standard.SpelExpressionParser;

public class ValidatorConstants {
	public static String strEmail="^[(a-zA-Z-0-9-\\_\\+\\.)]+@[(a-z-A-z)]+\\.[(a-zA-z)]{2,3}$";
	public static Pattern emailRegexPattern=Pattern.compile(strEmail);
	public static SpelExpressionParser splExpr=new SpelExpressionParser();
	
}

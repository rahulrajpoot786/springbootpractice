package com.vidal.common.annotation.validator;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import org.springframework.beans.BeanWrapperImpl;
import org.springframework.expression.spel.standard.SpelExpressionParser;

import com.vidal.common.annotation.RegulerExpresion;
/**
 * This is Used to check the RegulerExpresion validation
 * @author sangamesh
 *
 */
public class RegulerExpresionValidater implements ConstraintValidator<RegulerExpresion, Object>{
	
	private String objField;
	private String regExp;
	
	@Override
	public void initialize(RegulerExpresion constraintAnnotation) {
		this.objField = constraintAnnotation.objField();
		this.regExp = constraintAnnotation.regExp();
		
	}
	@Override
	public boolean isValid(Object value, ConstraintValidatorContext ctx) {
		boolean status = true;
		Object field = new BeanWrapperImpl(value).getPropertyValue(objField);
		if(field != null&&!"".equals(field)){
			try{
				status = new SpelExpressionParser().parseExpression("'"+field.toString()+"' matches '"+regExp+"'").getValue(Boolean.class);
			}catch(Exception e){
				ctx.disableDefaultConstraintViolation();
				ctx.buildConstraintViolationWithTemplate("Unkown Error Occurred Please Contact Administrator").addConstraintViolation();

				e.printStackTrace();
				status=false;
			}
		}
		/*else{
			throw new IllegalArgumentException("objField and regExp should not empty");
		}*/
		return status;
	}
	
	

}

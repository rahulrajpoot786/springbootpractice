package com.vidal.common.helper;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.dom4j.Node;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.vidal.command.usermanagement.UserSecurityProfile;
import com.vidal.common.UXUtility;
import com.vidal.common.exception.VidalException;
import com.vidal.common.security.SecurityProfile;
import com.vidal.controllers.HomeController;

public class SecurityManagerHelper implements Serializable{
	
	private static final Logger logger = LoggerFactory.getLogger(SecurityManagerHelper.class);
	private static final String strIndLogin="OIN";
    private static final String strEmpLogin="OCO";
    private static final String strCitibankLogin="OCI";
    private static final String strHRLogin="OHR";
    private static final String strBrokerLogin="OBR";
    private static final String strCignaEmpLogin="CIGNAOCO";
    
    
    public static UserSecurityProfile getUserSecurityProfile(Document userProfileDoc)throws VidalException
    {
        UserSecurityProfile userSecurityProfile=null;
        try
        {
            if(userProfileDoc!=null)
            {
                //declrations of the variables used
                userSecurityProfile=new UserSecurityProfile();
                //WorkflowVO workflowVO=null;
                //EventVO eventVO=null;
                //GroupVO groupVO=null;
                Document userDoc=null;     //contains the user information
                Document rolePrivilegeDoc=null; //contains the Role Privilege information
                Element workFlowElement=null;
                Element eventElement=null;
                Element groupElement=null;
                ArrayList alWorkFlowNodes=null;
                List eventList=null;
                ArrayList alGroupNodes=null;
                String strWorkFlowSeqID="";

                userDoc=DocumentHelper.parseText(((Node)userProfileDoc.selectSingleNode("/usersecurityprofile/user")).asXML()); 
                rolePrivilegeDoc=DocumentHelper.parseText(((Node)userProfileDoc.selectSingleNode("/usersecurityprofile/SecurityProfile")).asXML()); 
                Element userElement=userDoc.getRootElement();     //get the user Element from the userDocument

                //set the available user information to UserSecurityProfileObject
                userSecurityProfile.setUSER_SEQ_ID(UXUtility.getLong(userElement.valueOf("@contactseqid")));
                userSecurityProfile.setUserName(userElement.valueOf("@name"));
                userSecurityProfile.setUserTypeId(userElement.valueOf("@usertype"));
                userSecurityProfile.setBranchID(UXUtility.getLong(userElement.valueOf("@branchid")));
                userSecurityProfile.setBranchName(userElement.valueOf("@branchname"));
                userSecurityProfile.setContactTypeID(UXUtility.getLong(userElement.valueOf("@contacttypeid")));
                userSecurityProfile.setActiveYN(userElement.valueOf("@active"));
                userSecurityProfile.setEMAIL_ID(userElement.valueOf("@email"));
                userSecurityProfile.setMobileNo(userElement.valueOf("@mobile"));
                userSecurityProfile.setUSER_ID(userElement.valueOf("@userid"));
                userSecurityProfile.setLoginDate(userElement.valueOf("@logindate"));
                userSecurityProfile.setFirstLoginYN(userElement.valueOf("@showpwdalert"));
                userSecurityProfile.setLocalIPAddress(userElement.valueOf("@localIPAddress"));
				userSecurityProfile.setPswdExpiryYN(userElement.valueOf("@pwd_alert"));
                userSecurityProfile.setPwdValidYN(userElement.valueOf("@expiry_flag_YN")); 
                userSecurityProfile.setCurrentStatus(userElement.valueOf("@userstatus"));
               // userSecurityProfile.setCorpClaimFlag(userElement.valueOf("@corp_clm_allowed_yn"));
				
                //get the Role information of the User
                Element roleElement=(Element)userDoc.selectSingleNode("/user/role");
                userSecurityProfile.setRoleSeqId(UXUtility.getLong(roleElement.valueOf("@seqid")));
                userSecurityProfile.setRoleName(roleElement.valueOf("@name"));

                //get the WorkFlow Event Details of the Role if any
                if(userDoc.selectSingleNode("/user/role/workflow")!=null)
                {
                    alWorkFlowNodes=(ArrayList)userDoc.selectNodes("/user/role/workflow");
                }//end of if(userDoc.selectSingleNode("/user/role/workflow")!=null)

                /*if(alWorkFlowNodes!=null && alWorkFlowNodes.size()>0)
                {
                    HashMap<Long,WorkflowVO> hmWorkFlow=new HashMap<Long,WorkflowVO>();
                    for(int iWorkFlowcnt=0;iWorkFlowcnt<alWorkFlowNodes.size();iWorkFlowcnt++)
                    {
                        workflowVO=new WorkflowVO();
                        workFlowElement=((Element)alWorkFlowNodes.get(iWorkFlowcnt));
                        strWorkFlowSeqID=workFlowElement.valueOf("@seqid");
                        workflowVO.setWorkflowSeqID(TTKCommon.getLong(strWorkFlowSeqID));
                        workflowVO.setWorkflowName(workFlowElement.valueOf("@name"));

                        eventList=userDoc.selectNodes("/user/role/workflow[@seqid='"+strWorkFlowSeqID+"']/event");
                        if(eventList!=null && eventList.size()>0)
                        {
                            ArrayList<EventVO> alEventList=new ArrayList<EventVO>();
                            for(int iEventNodeCnt=0;iEventNodeCnt<eventList.size();iEventNodeCnt++)
                            {
                                eventVO=new EventVO();
                                eventElement=((Element)eventList.get(iEventNodeCnt));
                                eventVO.setEventSeqID(TTKCommon.getLong(eventElement.valueOf("@seqid")));
                                eventVO.setEventName(eventElement.valueOf("@name"));
                                alEventList.add(eventVO);
                            }//end of for(int iEventNodeCnt=0;iEventNodeCnt<alEventNodes.size();iEventNodeCnt++)
                            workflowVO.setEventVO(alEventList);     //add the events to the corresponding workflow object
                        }//end of if(alEventNodes!=null && alEventNodes.size()>0)
                        hmWorkFlow.put(workflowVO.getWorkflowSeqID(),workflowVO); //add the WorkFlow object to the HashMap
                    }//end of for(int iWorkFlowcnt=0;iWorkFlowcnt<alWorkFlowNodes.size();iWorkFlowcnt++)
                    userSecurityProfile.setWorkFlowMap(hmWorkFlow);     //set the Hashmap of workflow events of the User
                }*/

                //get the Group information of the user from the userProfile if any
                if (userDoc.selectSingleNode("/user/groups/group")!= null )
                {
                    alGroupNodes=(ArrayList)userDoc.selectNodes("/user/groups/group");
                }//end of if (userDoc.selectSingleNode("/user/groups/group")!= null )
               /* if(alGroupNodes!=null && alGroupNodes.size()>0)
                {
                    ArrayList<GroupVO> alGroups=new ArrayList<GroupVO>();
                    for(int iGroupNodeCnt=0;iGroupNodeCnt<alGroupNodes.size();iGroupNodeCnt++)
                    {
                        groupVO=new GroupVO();
                        groupElement=(Element)alGroupNodes.get(iGroupNodeCnt);
                        groupVO.setGroupSeqID(TTKCommon.getLong(groupElement.valueOf("@seqid")));
                        groupVO.setGroupName(groupElement.valueOf("@name"));
                        groupVO.setProductSeqID(TTKCommon.getLong(groupElement.valueOf("@productseqid")));
                        groupVO.setGroupBranchSeqID(TTKCommon.getLong(groupElement.valueOf("@branchid")));
                        alGroups.add(groupVO);      //add the groupVO Object to List
                    }//end of for(int iGroupNodeCnt=0;iGroupNodeCnt<alGroupNodes.size();iGroupNodeCnt++)

                    userSecurityProfile.setGroupList(alGroups);     //set the groups information of the user to userSecurityProfile
                }*/

                //put the rolePrivilegeDoc into SecurityProfile
                SecurityProfile securityProfile=new SecurityProfile();
                securityProfile.setUserProfileXML(rolePrivilegeDoc);
                //set the SecurityProfile object in userSecurityProfileObject
                userSecurityProfile.setSecurityProfile(securityProfile);
            }//end of if(userProfileDoc!=null)
        }//end of try
        catch (DocumentException exp)
        {
            throw new VidalException("error.login.document");
        }//end of catch
        return userSecurityProfile;
    }//end of getUserSecurityProfile(Document userProfileDoc)

}

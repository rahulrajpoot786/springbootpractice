/**
 * 
 */
package com.vidal.common.annotation.validator;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import org.apache.commons.beanutils.BeanUtils;

import com.vidal.common.annotation.Length;

/**
 * @author Nagababu
 *
 */
public class LengthValidator implements ConstraintValidator<Length, Object>{
	
	private Length length;
	@Override
	public void initialize(Length length) {
		this.length=length;
	}

	@Override
	public boolean isValid(Object cmdObject, ConstraintValidatorContext context) {
		boolean status=true;
		try{
		
			String fieldName=length.fieldName();
			int min=length.min();
			int max=length.max();
			
		String value=	BeanUtils.getProperty(cmdObject, fieldName);
		if(value!=null&&value!=""){		
		status=((value.length()>=min)&&(value.length()<=max));
		}
		}catch(Exception exception){
			context.disableDefaultConstraintViolation();
			context.buildConstraintViolationWithTemplate("Unkown Error Occurred Please Contact Administrator").addConstraintViolation();
			exception.printStackTrace();
			status=false;
		}
		return status;
	}


}

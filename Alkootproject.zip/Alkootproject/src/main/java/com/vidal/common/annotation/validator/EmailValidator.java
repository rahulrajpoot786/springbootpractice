/**
 * 
 */
package com.vidal.common.annotation.validator;

import java.util.regex.Matcher;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import org.apache.commons.beanutils.BeanUtils;

import com.vidal.common.annotation.Email;

/**
 * @author Nagababu
 *
 */
public class EmailValidator implements ConstraintValidator<Email, Object>{
	
	private Email email;
	@Override
	public void initialize(Email email) {
		this.email=email;
	}

	@Override
	public boolean isValid(Object cmdObject, ConstraintValidatorContext context) {
		boolean status=true;
		try{
		
			String fieldName=email.fieldName();
		String value=	BeanUtils.getProperty(cmdObject, fieldName);
		if(value!=null&&value!=""){		
		Matcher regMatcher   = ValidatorConstants.emailRegexPattern.matcher(value);
		status=regMatcher.matches();
		if(!status){
			if("".equals(email.message())||email.message()==null){
				context.disableDefaultConstraintViolation();
				context.buildConstraintViolationWithTemplate(fieldName+" is not valid email address").addConstraintViolation();
				
			}
		}
		}
		}catch(Exception exception){
			context.disableDefaultConstraintViolation();
			context.buildConstraintViolationWithTemplate("Unkown Error Occurred Please Contact Administrator").addConstraintViolation();
			exception.printStackTrace();
			status=false;
		}
		return status;
	}


}

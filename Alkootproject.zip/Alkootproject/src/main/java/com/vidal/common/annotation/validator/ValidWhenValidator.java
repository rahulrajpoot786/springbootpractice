/**
 * 
 */
package com.vidal.common.annotation.validator;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import org.springframework.expression.Expression;
import org.springframework.expression.spel.standard.SpelExpressionParser;

import com.vidal.common.annotation.ValidWhen;

/**
 * @author sangamesh
 *
 */
public class ValidWhenValidator implements ConstraintValidator<ValidWhen, Object>{
	private ValidWhen validWhen;
	@Override
	public void initialize(ValidWhen validWhen) {
		this.validWhen=validWhen;
	}

	@Override
	public boolean isValid(Object cmdObject, ConstraintValidatorContext context) {
		boolean status=true;
		try{
			String strExp=validWhen.expression();
			
			//System.out.println("             strExp  : "+strExp);

			if(strExp == null||strExp.trim().length()<1) throw new IllegalArgumentException("expression should not empty");

			Expression  expression= new SpelExpressionParser().parseExpression(strExp);
			status=expression.getValue(cmdObject,Boolean.class);
		}catch(Exception exception){
			context.disableDefaultConstraintViolation();
			context.buildConstraintViolationWithTemplate("Unkown Error Occurred Please Contact Administrator").addConstraintViolation();

			exception.printStackTrace();
			status=false;
		}
		return status;
	}


}

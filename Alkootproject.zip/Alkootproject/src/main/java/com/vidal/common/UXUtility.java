package com.vidal.common;

import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.nio.file.FileSystems;
import java.nio.file.Path;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Properties;
import java.util.StringTokenizer;
import java.util.TimeZone;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import javax.activation.DataHandler;
import javax.activation.FileDataSource;
import javax.imageio.ImageIO;
//email related libraries
import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.PasswordAuthentication;
import javax.mail.SendFailedException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.dom4j.Node;
import org.dom4j.io.DOMReader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.support.PropertiesLoaderUtils;
import org.springframework.web.multipart.MultipartFile;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.WriterException;
import com.google.zxing.client.j2se.MatrixToImageWriter;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;
import com.vidal.command.pricing.InsPricingVO;
import com.vidal.command.usermanagement.UserSecurityProfile;
import com.vidal.common.exception.VidalException;





public class UXUtility {
    private static final Logger logger = LoggerFactory.getLogger(UXUtility.class);

    public static String checkNullAndTrim(String strObj){
        return (strObj==null?"":strObj.trim());
    }
    //added for authgencontroller
    public static String getActiveLink(HttpServletRequest request) throws VidalException
    {
        String strLink = "";
        strLink=((UserSecurityProfile)request.getSession().getAttribute("userAccessSecurityProfile")).getSecurityProfile().getActiveLink();
        return strLink;
    }
    public static String getActiveTab(HttpServletRequest request) throws VidalException
    {
        String strTabLink = "";
        strTabLink=((UserSecurityProfile)request.getSession().getAttribute("userAccessSecurityProfile")).getSecurityProfile().getActiveTab();
        return strTabLink;
    }//end of getActiveTab(HttpServletRequest request)
    public static Long getUserSeqId(HttpServletRequest request)
    {
        return ((UserSecurityProfile)request.getSession().getAttribute("userAccessSecurityProfile")).getUSER_SEQ_ID();
    }//end of getWebBoardId(HttpServletRequest request)
    
    
    
    
    public static boolean isAuthorized(HttpServletRequest request, String strPermission) throws VidalException
    {
        StringBuffer sbfPermisson=new StringBuffer();
        sbfPermisson.append(((UserSecurityProfile) request.getSession().getAttribute("UserSecurityProfile")).getSecurityProfile().getActiveLink()).append(".");
        sbfPermisson.append(((UserSecurityProfile) request.getSession().getAttribute("UserSecurityProfile")).getSecurityProfile().getActiveSubLink()).append(".");
        sbfPermisson.append(((UserSecurityProfile) request.getSession().getAttribute("UserSecurityProfile")).getSecurityProfile().getActiveTab()).append(".").append(strPermission);

        return ((UserSecurityProfile)request.getSession().getAttribute("UserSecurityProfile")).getSecurityProfile().isAuthorized(sbfPermisson.toString());
    }//end of isAuthorized(HttpServletRequest request)

    /**
     * This method checks it the string contains null
     *
     * @param strIn String
     * @return String
     */
    public static String checkNull(String strIn)
    {
        if(strIn == null)
        {
            strIn = "";
        }// if(strIn == null)
        return strIn;
    }//checkNull(String strIn)

    /**
     * This method checks it the Object contains null
     *
     * @param oIn String
     * @return Object
     */
    public static Object checkNull(Object oIn)
    {
        if(oIn == null)
        {
            oIn = "";
        }// if(oIn == null)
        return oIn;
    }//checkNull(Object oIn)

    /**
     * this method takes String values and return Long value
     * @param strLong
     * @return Long
     */
    public static Long getLong(String strLong)throws VidalException
    {
        Long value=null;

        if(strLong!=null && !strLong.equals(""))
        {
            value=Long.parseLong(strLong);
        }//end of if(strLong!=null && !strLong.equals(""))
        return value;
    }//end of getLong(String strLong)

  /*  public static String getString(String strString)throws TTKException
    {
        String value=null;

        if(strString!=null && !strString.equals(""))
        {
            value=String.valueOf(strString);
        }//end of if(strLong!=null && !strLong.equals(""))
        return value;
    }//end of getLong(String strLong)
*/

    public static String getValue(Document doc, String name)
    {
        Document userDoc=null;
        Element userElement=null;
        try{
            if(doc!=null)
            {
userDoc=DocumentHelper.parseText(((Node)doc.selectSingleNode("/usersecurityprofile/user")).asXML());
                userElement=userDoc.getRootElement();
            }
        }catch(Exception e){e.printStackTrace();}
        return UXUtility.checkNullAndTrim(userDoc.getRootElement().valueOf("@"+name)).toString();
    }
    /**
     * this method takes String values and return int value
     * @param strInt
     * @return int
     */
/*    public static int getInt(String strInt)throws TTKException
    {
        int value=0;

        if(strInt!=null && !strInt.equals(""))
        {
            value=Integer.parseInt(strInt);
        }//end of if(strInt!=null && !strInt.equals(""))
        return value;
    }//end of getInt(String strInt)
*/
    /**
     * this method takes String values and return Double value
     * @param strDouble
     * @return Double
     */
/*    public static Double getDouble(String strDouble)throws TTKException
    {
        Double value=null;
        if(strDouble!=null && !strDouble.equals(""))
        {
            value=Double.parseDouble(strDouble);
        }//end of if(strDouble!=null && !strDouble.equals(""))
        return value;
    }//end of getDouble(String strDouble)
*/
    /**
     * this method takes String values and return BigDecimal value
     * @param strBigDecimal
     * @return BigDecimal
     */
    public static BigDecimal getBigDecimal(String strBigDecimal)throws Exception
    {
        BigDecimal bdValue = null;
        if(!UXUtility.checkNull(strBigDecimal).equals(""))
        {
            bdValue = new BigDecimal(strBigDecimal);
        }//end of if(!TTKCommon.checkNull(strBigDecimal).equals(""))
        return bdValue;
    }//end of getDouble(String strDouble)


    /**
     * this method checks for the which item should be selected in combo box
     * @param strId1 String
     * @param strId2 String
     * @return String
     * @throws DocumentException
     */

 /*   public static String isSelected(String strId1 ,String strId2)
    {
if(TTKCommon.checkNull(strId1).equals(TTKCommon.checkNull(strId2)))
        {
            return "SELECTED";
        }//end of if(TTKCommon.checkNull(strId1).equals(TTKCommon.checkNull(strId2)))
        else
        {
            return "";
        }//end of else
    }*///end of isSelected(String strId1 ,String strId2)

    public static String getUserID(Document doc) throws VidalException, DocumentException
    {
        Document userDoc=null;
        String userId ="";
            if(doc!=null)
            {
userDoc=DocumentHelper.parseText(((Node)doc.selectSingleNode("/usersecurityprofile/user")).asXML());
                userId = UXUtility.checkNullAndTrim(userDoc.getRootElement().valueOf("@userid")).toString();
            }
        return userId;
    }

    public static Long getPolicySeqId(Document doc) throws VidalException, DocumentException
    {
        Document userDoc=null;
        String policySeqId ="";
            if(doc!=null)
            {
userDoc=DocumentHelper.parseText(((Node)doc.selectSingleNode("/usersecurityprofile/user")).asXML());
                policySeqId = UXUtility.checkNullAndTrim(userDoc.getRootElement().valueOf("@polseqid")).toString();
            }
        return UXUtility.getLong(policySeqId);
    }
    //Need to write NumberFormat exception cler logic
    public static Long getPolicyGreSeqId(Document doc) throws VidalException, DocumentException
    {
        Document userDoc=null;
        String policygrpseqid ="";
            if(doc!=null)
            {
userDoc=DocumentHelper.parseText(((Node)doc.selectSingleNode("/usersecurityprofile/user")).asXML());
                policygrpseqid = UXUtility.checkNullAndTrim(userDoc.getRootElement().valueOf("@policygrpseqid")).toString();
            }
        return UXUtility.getLong(policygrpseqid);
    }


    public static String getConvertDateToString(Date date) throws VidalException
    {
        String stringDate="";
        SimpleDateFormat dateFormat= new SimpleDateFormat("dd/MM/yyyy");
        stringDate=dateFormat.format(date);
        return stringDate;
    }

    public static Date getConvertStringToDate(String stringDate) throws ParseException, VidalException
    {
        String[] s=UXUtility.checkNull(stringDate).split(" ");
        SimpleDateFormat dateFormat = null;
        Date date = null;
        if(s != null && s.length > 1)
            dateFormat= new SimpleDateFormat("dd/MM/yyyy hh:mm a");
        else
            dateFormat= new SimpleDateFormat("dd/MM/yyyy");

        date=dateFormat.parse(stringDate.trim());
        return date;
    }
    



    /*****************************************************
    Method : getHtmlString(String AsciiString)
    Added by: Anilkumar
    Date: 19th November 2002

    Input: String containing Ascii characters
    Output: String which can be displayed on HTML

    ******************************************************/
   public static String getHtmlString(String AsciiString)
   {
       AsciiString = checkNull(AsciiString);
       try{

           if(AsciiString.length() != 0)
           {
               char[] ac = AsciiString.toCharArray();
               int iValue;
               StringBuffer sb = new StringBuffer();

               for( int ndx = 0; ndx < ac.length; ndx++ )
               {
                   iValue = ac[ndx];
                   if( (iValue < 48 && iValue > 0 )|| (iValue > 57 &&  iValue < 65) || (iValue > 126 &&  iValue < 260) )
                   {
                       sb.append("&#"+ Integer.toString( iValue )+";");
                   }//end of if( (iValue < 48 && iValue > 0 )|| (iValue > 57 &&  iValue < 65) || (iValue > 126 &&  iValue < 260) )
                   else
                   {
                       sb.append(ac[ndx]);
                   }//end of else
               }//end of for( int ndx = 0; ndx < ac.length; ndx++ )
               return sb.toString();
           }//end of if(AsciiString.length() != 0)
           else
           {
               return AsciiString;
           }//end of else
       }//end of try
       catch(Exception exp)
       {
           logger.error("Inside getHtmlString.....Throwing IO Exception...");

       }
       return AsciiString;
   }//end of getHtmlString(String AsciiString)
   
   /**
    * This method returns the Date Object by appending the Date & Time & MeriDian
    * @param strDate The String Containing the date value In Format DD//MM/YY
    * @param strTime The String Containing the Time value In Format HH:mm
    * @param strMeridian The String Containing The Meridian Value AM/PM
    * @return The Date In the Format DD/MM/YY HH:mm AM
    */
   public static Date getOracleDateWithTime(String strDate,String strTime,String strMeridian)
   {
       DateFormat formatter = null;
       String strCompleteDate = null;
       Date date = null;
       try{
           if(strDate != null && strDate.trim().length()>0)
           {
               strCompleteDate = strDate ;
               formatter = new SimpleDateFormat("dd/MM/yyyy hh:mm a");
               if(strTime != null && strTime.trim().length()>0)
               {
                   strCompleteDate = strDate+" "+strTime;
               }//end of if(strTime != null && strTime.trim().length()>0)
               else
               {
                   formatter = new SimpleDateFormat("dd/MM/yyyy");
                   date = (Date)formatter.parse(strCompleteDate);
                   return date;
               }//end of else
               if (strMeridian != null && strMeridian.trim().length()>0)
               {
                   strCompleteDate =  strCompleteDate+" "+strMeridian;
               }//end of if (strMeridian != null && strMeridian.trim().length()>0)
               date = (Date)formatter.parse(strCompleteDate);
               return date;
           }//end of if(strDate != null && strDate.trim().length()>0)
       }//end of try
       catch (ParseException parserException)
       {
    	   logger.error("Inside getHtmlString.....Throwing parserException...");
       }//end of Catach
       return date;
   }//getOracleDateWithTime(String strDate,String strTime,String strMeridian)
   
   /**
    * This method will take xml file name as input,Read it and builds
    * the DOm4j document object and returns it to called method
    * @param strXmlFileName String name of the XML file
    * @return doc Dom4j Document object
    * @throws VidalException if any Error occures
    */
   public static Document getDocument(String strXmlFileName)throws VidalException
   {
	     Document doc=null;
       try{
           //TODO now XML files Read from Jboss/bin later it will be read from Properties file
           File inputFile = new File(strXmlFileName);
           //create a document builder object
           DocumentBuilderFactory fact = DocumentBuilderFactory.newInstance();
           DocumentBuilder db = fact.newDocumentBuilder();
           //create a dom reader object
           DOMReader domReader = new DOMReader();
           //covert the w3c document object obtained from document builder to dom4j document
           doc = domReader.read(db.parse(inputFile));//read method take w3c document and returns dom4j document
           logger.debug("Document Read Sucessfully...");
       }//end of try
       catch(Exception exp)
       {
           exp.printStackTrace();
          // throw new VidalException( exp,"");
       }//end of catch(Exception exp)
       return doc;
   }
   private static Properties prop = null;
   public static String getPropertyValue(String strPropertyName) throws IOException
    {
        String strPropertyValue="";

            if (prop == null)
            {
                prop = PropertiesLoaderUtils.loadProperties(new ClassPathResource("resources/files/vidal.properties"));
            }
            strPropertyValue  = (String)prop.get(strPropertyName);

        return strPropertyValue;
    }

   /**
    * This method replaces the single quotes with '' for display method
    *
    * @param sValue String
    * @return String
    */
   public static String replaceSingleQots(String sValue)
   {
       if(sValue==null)
       {
           return "";
       }//end of if(sValue==null)
       else
       {
           sValue = sValue.trim();
           String sTemp = "";
           int i=0;
           while(sValue.length() > 0 && i !=-1)
           {
               i =  sValue.indexOf('\'');
               if(i!=-1)
               {
                   sTemp+= sValue.substring(0,i)+"''";
                   sValue = sValue.substring(i+1,sValue.length());
               }//if(i!=-1)
               else
               {
                   sTemp+= sValue;
               }//end of else
           }//end of while(sValue.length() > 0 && i !=-1)
           return sTemp;
       }//end of else
   }//end of replaceDoubleQotsWithSlash(String sValue)
   
   

	 public static String getFormattedDate( String strDate )
	    {
	        StringTokenizer strDateTknzr = new StringTokenizer( strDate, "/" );
	        String strMonth = "";
	        String strDay = "";
	        String strYear = "";
	        if( strDateTknzr.hasMoreTokens() )
	        {
	            strMonth = strDateTknzr.nextToken();
	            if( strMonth.trim() == ""  )
	            {
	                return "";
	            }//end of if( strMonth.trim() == ""  )c
	            else if( strMonth.trim().length() == 1 )
	            {
	                strMonth = "0"+strMonth;
	            }//end of else if( strMonth.trim().length() == 1 )
	            else if( strMonth.trim().length() > 2)
	            {
	                return "";
	            }//end of else if( strMonth.trim().length() > 2)
	        }//end of if( strDateTknzr.hasMoreTokens() )
	        else
	        {
	            return "";
	        }//end of else
	        if( strDateTknzr.hasMoreTokens() )
	        {
	            strDay = strDateTknzr.nextToken();
	            if( strDay.trim() == ""  )
	            {
	                return "";
	            }//end of if( strDay.trim() == ""  )
	            else if( strDay.trim().length() == 1 )
	            {
	                strDay = "0"+strDay;
	            }//end of else if( strDay.trim().length() == 1 )
	            else if( strDay.trim().length() > 2)
	            {
	                return "";
	            }//end of else if( strDay.trim().length() > 2)
	        }//end of if( strDateTknzr.hasMoreTokens() )
	        else
	        {
	            return "";
	        }//end of else
	        if( strDateTknzr.hasMoreTokens() )
	        {
	            strYear = strDateTknzr.nextToken();
	        }//end of if( strDateTknzr.hasMoreTokens() )
	        else
	        {
	            return "";
	        }//end of else

	        if( strYear.trim().equals("") )
	        {
	            return "";
	        }//end of if( strYear.trim().equals("") )

	        return strMonth+"/"+strDay+"/"+strYear;
	    }
	 
	 public synchronized static String getFormattedDate(Date date)
	    {
	        if(date!=null)
	        {
	            SimpleDateFormat sdFormat=new SimpleDateFormat("dd/MM/yyyy");
	            return sdFormat.format(date.getTime());
	        }//end of if(date!=null)
	        return "";

	    }
	 
	 public synchronized static String getFormattedDateHour(Date date)
	    {
	        if(date!=null)
	        {
	            SimpleDateFormat sdFormat=new SimpleDateFormat("dd/MM/yyyy h:mm a");
	            return sdFormat.format(date.getTime());
	        }//end of if(date!=null)
	        return "";
	    }
   
	/*
	 * public static String getCacheDescription(String strCasheId,String strCache)
	 * throws Exception {
	 * 
	 * if(strCasheId==null||strCache==null) { return null; }//end of
	 * if(strCasheId==null||strCache==null)
	 * 
	 * CacheObject cacheObject=null;
	 * 
	 * ArrayList alCache=(ArrayList)Cache.getCacheObject(strCache);
	 * 
	 * if(alCache!=null&&alCache.size()>0) { for(int
	 * iCache=0;iCache<alCache.size();iCache++) { cacheObject =
	 * (CacheObject)alCache.get(iCache);
	 * if(strCasheId.equals(cacheObject.getCacheId())) { return
	 * cacheObject.getCacheDesc(); }//end of
	 * if(strCasheId.equals(cacheObject.getCacheId())) }//end of for(int
	 * iCache=0;iCache<alCache.size();iCache++) }//end of
	 * if(alCache!=null&&alCache.size()>0) return ""; }//end of
	 * getCacheDescription(String strCasheId,String strCache) throws TTKException
	 * 
	 * 
	 */
	  
	  public static String buildDisplayRemarks(Element eleDisplay,String strFieldName,String strFieldValue,String strPermission,String strMandatoryID)
	    {
	        StringBuffer sbfDisplayElement=new StringBuffer();
	       // String r="remarks";
	        if(eleDisplay!=null)
	        {
	              if(eleDisplay.valueOf("@control").equalsIgnoreCase("textArea"))
	            {
	               // sbfDisplayElement.append("<textarea name=\"").append(strFieldName).append("\" ");
	                    sbfDisplayElement.append("<textarea name=\"").append(strFieldName).append("\" ");
	                sbfDisplayElement.append("class=\"textBox textAreaLong\" ");

	                if(strMandatoryID!=null && !strMandatoryID.equals(""))
	                {
	                    sbfDisplayElement.append(" id=\""+strMandatoryID+"\" ");
	                }//end of if(strMandatoryID!=null && !strMandatoryID.equals(""))
	                else
	                {
	                    sbfDisplayElement.append(" id=\""+eleDisplay.valueOf("@id")+"\" ");
	                }//end of else
	                sbfDisplayElement.append(eleDisplay.valueOf("@jscall"));
	                                           
	                if(strPermission.equals("") || eleDisplay.valueOf("@disabled").equals("true"))
	                {
	                  
	                    sbfDisplayElement.append(" ").append("readonly=\"true\"");
	                }//end of if(strPermission.equals("") && eleDisplay.valueOf("@disabled").equals("true"))
	              /*  else
	                {
	                    sbfDisplayElement.append(" ");
	                    sbfDisplayElement.append("disabled=\""+strPermission+"\" ");
	                    //sbfDisplayElement.append("readonly=\"readonly\" ");
	                }//end of else
	                
	*/             
	               // sbfDisplayElement.append(" ").append("maxlength=\"250\"");
	                sbfDisplayElement.append(" >");
	                if(strFieldName.equalsIgnoreCase("Others.1"))
	                {
	                   sbfDisplayElement.append(strFieldValue.replaceAll("</br>"," "));
	                }//end of if(strFieldName.equalsIgnoreCase("Others.1"))
	                else
	                {
	                  // Unni Added for fixing Bug ID 42647
	                  if(strFieldValue.indexOf("\r") != -1 || strFieldValue == "\n" || strFieldValue.indexOf("\r\n") != -1){
	                     sbfDisplayElement.append(strFieldValue.replaceAll("~", "\n"));
	                     }//end of if(strFieldValue.indexOf("\r") != -1 || strFieldValue == "\n" || strFieldValue.indexOf("\r\n") != -1){
	                     else if(strFieldValue.indexOf("~") != -1)
	                     {
	                         sbfDisplayElement.append(strFieldValue.replaceAll("~", "\n"));
	                     }//end of else if(strFieldValue.indexOf("~") != -1)
	                     else
	                     {
	                         sbfDisplayElement.append(strFieldValue);
//	                         
	                     }//end of else
	                //sbfDisplayElement.append(strFieldValue);
	                // End of Adding
	                }//end of else
	                sbfDisplayElement.append("</textarea>");
	            }//end of else if(eleDisplay.valueOf("@control").equalsIgnoreCase("textArea"))
	        }
	        else
	        {
	            //log.error("Element to Displayed is null");
	        }//end of else
	        return sbfDisplayElement.toString();
	        }
	  
   
	 public static Long[] stringArrayToLongArray(String[] numbers) {
		  Long[] result = new Long[numbers.length];
		  for (int i = 0; i < numbers.length; i++){
			  if(numbers[i] != null && !numbers[i].equals(""))
				  result[i] = Long.parseLong(numbers[i]);
			  else
				  result[i] = 0L;
		  }
		  return result;
		}
	 
	 	    
	    public static String replaceInString(String str, String pattern, String replace)
        {
         int s = 0;
            int e = 0;
            StringBuffer result = new StringBuffer();

            while ((e = str.indexOf(pattern, s)) >= 0) {
                str.substring(s, e);
                result.append(str.substring(s, e));
                result.append(replace);
                s = e+pattern.length();
            }//end of while ((e = str.indexOf(pattern, s)) >= 0)
            result.append(str.substring(s));
            return result.toString();
        // TODO Auto-generated method stub
   
    }
	    


public static void sendEmail(List<MultipartFile> files , String to, String cc, String subj, String msg) {    
//         final String user="sajith.sidharthan@vidalheathtpa.com";//change accordingly
//         final String password="P@ssw0rd@123";//change accordingly
           
           
           try 
			{
        	   Properties properties = new Properties();
               properties.put("mail.smtp.host",UXUtility.getPropertyValue("emailHost"));
               properties.put("mail.smtp.sendpartial", "true");
               properties.put("mail.smtp.port", "25");
               
               //properties.put("mail.smtp.auth", "true");
               final String user = UXUtility.getPropertyValue("user");
               final String userPassword = UXUtility.getPropertyValue("userPassword") ;
               
        	   Session session = Session.getInstance(properties);
              Message message = new MimeMessage(session);
              // Set From: header field of the header.
              message.setFrom(new InternetAddress(UXUtility.getPropertyValue("user")));
              // Set To: header field of the header.
              String[] doMailList=to.split(";");
              InternetAddress[] toAddrList=new InternetAddress[doMailList.length];
              
              for(int i=0;i<doMailList.length;i++){
            	  toAddrList[i]=new InternetAddress(doMailList[i].trim());
              }
             
              
              message.setRecipients(Message.RecipientType.TO, toAddrList);
              if (!(cc==null || "".equals(cc))){
            	 
            	  String[] ccMailList=cc.split(";");
                  InternetAddress[] ccAddrList=new InternetAddress[ccMailList.length];
                  
                  for(int i=0;i<ccMailList.length;i++){
                	  ccAddrList[i]=new InternetAddress(ccMailList[i].trim());
                  }
                 
            	  
            	  
            	  message.setRecipients(Message.RecipientType.CC, ccAddrList);
              }
              // Set Subject: header field
              message.setSubject(subj);
              // This mail has 2 part, the BODY and the embedded image
              MimeMultipart multipart = new MimeMultipart();
              // first part (the html)
              BodyPart messageBodyPart = new MimeBodyPart();
              //String htmlText = "<H1>Hello</H1><img src=\"cid:image\">";
              //String htmlText = "<img src=\"cid:image\">";
              messageBodyPart.setContent(msg, "text/html");
              // add it
              multipart.addBodyPart(messageBodyPart);

              // second part (the image)
//              messageBodyPart = new MimeBodyPart();
//              DataSource fds = new FileDataSource(filePath);
//              messageBodyPart.setDataHandler(new DataHandler(fds));
//              messageBodyPart.setHeader("Content-ID", "<image>");
              // add image to the multipart
//              multipart.addBodyPart(messageBodyPart);

 

              MimeBodyPart attachmentBodyPart = new MimeBodyPart();
              if(files != null && files.size() > 0){
				   
				   for(int i=0;i<files.size();i++){
					   MultipartFile mpf =files.get(i);
					   attachmentBodyPart = new MimeBodyPart();
					   //DataHandler dataHandler = new DataSource(mpf.getInputStream());
					   byte[] bytes= mpf.getBytes();
					   Pattern pattern = Pattern.compile( "[^a-zA-Z0-9_\\.\\-\\s*]" );
					   Matcher matcher = pattern.matcher( mpf.getOriginalFilename());
					   if(!mpf.getOriginalFilename().equals("")){
						   if(!matcher.find()){
							   File filepath =new File(UXUtility.getPropertyValue("vingsdir")+"/"+mpf.getOriginalFilename());
							   if(!filepath.exists())
								   filepath.createNewFile();
							   FileUtils.writeByteArrayToFile(filepath, bytes);
							   attachmentBodyPart.setDataHandler(new DataHandler(new FileDataSource(filepath)));
							   attachmentBodyPart.setFileName(mpf.getOriginalFilename());
							   multipart.addBodyPart(attachmentBodyPart);
						   }else{
							   throw new VidalException("error.invalid.file.name");
						   }
					   }
					   
				   }
			   }
              
              // put everything together
              message.setContent(multipart);
              // Send message
              Transport.send(message);
              logger.info("Sent message successfully....");
           }
           catch(VidalException sfe){
        	   throw new VidalException(sfe.getErrorKey());
           }
           catch(SendFailedException sfe){
        	   sfe.printStackTrace();
        	   throw new VidalException("error.invalid.recipient.address");
           }
           catch (Exception e) {
        	   throw new RuntimeException(e);

           }

	}




public static void sendEmail1(File[] files , String to, String cc, String subj, String msg,HttpServletResponse response,String refNo) {    
//         final String user="sajith.sidharthan@vidalheathtpa.com";//change accordingly
//         final String password="P@ssw0rd@123";//change accordingly
           
           
           try 
			{
        	   Properties properties = new Properties();
               properties.put("mail.smtp.host",UXUtility.getPropertyValue("emailHost"));
               properties.put("mail.smtp.sendpartial", "true");
               properties.put("mail.smtp.port", "25");
               
               //properties.put("mail.smtp.auth", "true");
               final String user = UXUtility.getPropertyValue("user");
               final String userPassword = UXUtility.getPropertyValue("userPassword") ;
               
        	   Session session = Session.getInstance(properties);
              Message message = new MimeMessage(session);
              // Set From: header field of the header.
              message.setFrom(new InternetAddress(UXUtility.getPropertyValue("user")));
              // Set To: header field of the header.
              String[] doMailList=to.split(";");
              InternetAddress[] toAddrList=new InternetAddress[doMailList.length];
              
              for(int i=0;i<doMailList.length;i++){
            	  toAddrList[i]=new InternetAddress(doMailList[i].trim());
              }
             
              
              message.setRecipients(Message.RecipientType.TO, toAddrList);
              if (!(cc==null || "".equals(cc))){
            	 
            	  String[] ccMailList=cc.split(";");
                  InternetAddress[] ccAddrList=new InternetAddress[ccMailList.length];
                  
                  for(int i=0;i<ccMailList.length;i++){
                	  ccAddrList[i]=new InternetAddress(ccMailList[i].trim());
                  }
                 
            	  
            	  
            	  message.setRecipients(Message.RecipientType.CC, ccAddrList);
              }
              // Set Subject: header field
              message.setSubject(subj);
              // This mail has 2 part, the BODY and the embedded image
              MimeMultipart multipart = new MimeMultipart();
              // first part (the html)
              BodyPart messageBodyPart = new MimeBodyPart();
              //String htmlText = "<H1>Hello</H1><img src=\"cid:image\">";
              //String htmlText = "<img src=\"cid:image\">";
              messageBodyPart.setContent(msg, "text/html");
              // add it
              multipart.addBodyPart(messageBodyPart);

              // second part (the image)
//              messageBodyPart = new MimeBodyPart();
//              DataSource fds = new FileDataSource(filePath);
//              messageBodyPart.setDataHandler(new DataHandler(fds));
//              messageBodyPart.setHeader("Content-ID", "<image>");
              // add image to the multipart
//              multipart.addBodyPart(messageBodyPart);

 

              MimeBodyPart attachmentBodyPart = new MimeBodyPart();
              if(files != null && files.length > 0){
            	  File f1 = new File(UXUtility.getPropertyValue("vingsdir")+"/"+refNo+".zip");
            	  ZipOutputStream out = new ZipOutputStream(new FileOutputStream(f1));
				   for(int i=0;i<files.length;i++){
					 /*  MultipartFile mpf =files.get(i);*/
					   File f=files[i];
					   attachmentBodyPart = new MimeBodyPart();
					   //DataHandler dataHandler = new DataSource(mpf.getInputStream());
										
					/*   Pattern pattern = Pattern.compile( "[^a-zA-Z0-9_\\.\\-\\s*]" );*/
					  /* Matcher matcher = pattern.matcher(f.getName());*/
					   
					 
					   if(!f.getName().equals("")){
						  /* if(!matcher.find()){*/
						   
						  /* File f1 = new File(UXUtility.getPropertyValue("vingsdir")+"/REF01021900035.zip");*/
						
						   
						   
						
						   ZipEntry e = new ZipEntry(f.getName());
						   out.putNextEntry(e);

						   byte[] data = FileUtils.readFileToByteArray(f);
						   
						   out.write(data, 0, data.length);
						   out.closeEntry();

						 
						   
							/*   File filepath =new File(UXUtility.getPropertyValue("vingsdir")+"/"+f.getName());*/
							   
							   
							  /* if(!filepath.exists())
								   filepath.createNewFile();*/
							   
							   
							   /*  FileUtils.writeByteArrayToFile(filepath,FileUtils.readFileToByteArray(f));*/
							     FileUtils.writeByteArrayToFile(f1,FileUtils.readFileToByteArray(f1));
							   				   							  
							  
			//C1				   attachmentBodyPart.setDataHandler(new DataHandler(new FileDataSource(f1)));
							 /*  attachmentBodyPart.setFileName(f.getName());*/
				// C2			   attachmentBodyPart.setFileName(f1.getName());
				//C3			   multipart.addBodyPart(attachmentBodyPart);
						 /*  }else{
							   throw new VidalException("error.invalid.file.name");
						   }*/
					   }
					   
				   }
				   out.close();
				   attachmentBodyPart.setDataHandler(new DataHandler(new FileDataSource(f1)));
				   attachmentBodyPart.setFileName(f1.getName());
				   multipart.addBodyPart(attachmentBodyPart);
			   }
              
              // put everything together
              message.setContent(multipart);
              // Send message
              Transport.send(message);
              logger.info("Sent message successfully....");
           }
           catch(VidalException sfe){
        	   throw new VidalException(sfe.getErrorKey());
           }
           catch(SendFailedException sfe){
        	   sfe.printStackTrace();
        	   throw new VidalException("error.invalid.recipient.address");
           }
           catch (Exception e) {
        	   throw new RuntimeException(e);

           }

	}






public static void generateQRCodeImage(String contents, int width, int height, String filePath) throws WriterException, IOException {
	File folder=new File(filePath);
	if(!folder.exists()){
		folder.mkdirs();
	}
	QRCodeWriter qrCodeWriter = new QRCodeWriter();
	BitMatrix bitMatrix = qrCodeWriter.encode(contents, BarcodeFormat.QR_CODE, width, height);
	Path path = FileSystems.getDefault().getPath(filePath+"/"+contents+".JPG");
	MatrixToImageWriter.writeToPath(bitMatrix, "JPG", path);
}

public static byte[] generateQRCodeImage(String contents, int width, int height) throws WriterException, IOException {
	
	QRCodeWriter qrCodeWriter = new QRCodeWriter();
	BitMatrix bitMatrix = qrCodeWriter.encode(contents, BarcodeFormat.QR_CODE, width, height);	
	BufferedImage image = MatrixToImageWriter.toBufferedImage(bitMatrix);
    ByteArrayOutputStream out = new ByteArrayOutputStream();
  ImageIO.write(image, "JPG", out);
  out.close();
  
 return  out.toByteArray();
}


public static boolean isNull(ArrayList<InsPricingVO> al) {
	
	boolean status=false;
	if(al !=null) {
		
		for(InsPricingVO ins:al) {
			
			if(ins !=null) {
				
				status= false;
			}else {
				status= true;
			}
			
		}
	}else {
		status= true;
	}
	
   return status;
}

public static Timestamp getConvertStringToDateTimestamp(String stringDate) throws Exception,ParseException
{
 
    SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
    Date parsedDate = dateFormat.parse(stringDate.trim());
    Timestamp timestamp = new java.sql.Timestamp(parsedDate.getTime());
	return timestamp;
}	 

}

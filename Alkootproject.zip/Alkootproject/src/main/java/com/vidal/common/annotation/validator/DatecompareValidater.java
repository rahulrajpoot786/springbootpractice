/**
 * 
 */
package com.vidal.common.annotation.validator;

import java.text.SimpleDateFormat;
import java.util.Date;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import org.apache.log4j.Logger;
import org.springframework.beans.BeanWrapperImpl;

import com.vidal.common.annotation.Datecompare;

/**
 * @author sangamesh
 *
 */
public class DatecompareValidater implements ConstraintValidator<Datecompare, Object>{
	private static Logger logger = Logger.getLogger( DatecompareValidater.class );
	private String datefield1;
	private String datefield2;
	private String format;
	private String operator;
	
	@Override
	public void initialize(Datecompare constraintAnnotation) {
		this.datefield1 = constraintAnnotation.datefield1();
		this.datefield2 = constraintAnnotation.datefield2();
		this.format = constraintAnnotation.format();
		this.operator = constraintAnnotation.operator();
		
	}

	@Override
	public boolean isValid(Object value, ConstraintValidatorContext ctx) {
		boolean status = true;
		Object field1 = new BeanWrapperImpl(value).getPropertyValue(datefield1);
		Object field2 = new BeanWrapperImpl(value).getPropertyValue(datefield2);

		if(field1 != null && field2 != null){
			try{
				SimpleDateFormat sdf = new SimpleDateFormat(format);
				Date date1 = sdf.parse(field1.toString());
				Date date2 = sdf.parse(field2.toString());
			
				if(operator.equals("gt")){
					if(date1.compareTo(date2) > 0 )
						logger.info("Date1 is after Date2");
					else
						status = false;
				}
				else if(operator.equals("lt")){
					if(date1.compareTo(date2) < 0 )
						logger.info("Date1 is before Date2");
					else
						status = false;
				}
				else if(operator.equals("el")){
					if(date1.compareTo(date2) == 0 )
						logger.info("Date1 is equal to Date2");
					else
						status = false;
				}
				
			}catch(Exception e){
				ctx.disableDefaultConstraintViolation();
				ctx.buildConstraintViolationWithTemplate("Unkown Error Occurred Please Contact Administrator").addConstraintViolation();

				e.printStackTrace();
				status=false;
			}
		}
		else{
			throw new IllegalArgumentException("datefield1 and datefield2 should not empty");
		}
		return status;
		
		
	}

}

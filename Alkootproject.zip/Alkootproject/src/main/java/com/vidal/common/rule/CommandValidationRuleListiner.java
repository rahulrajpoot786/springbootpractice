/**
 * @ (#) RuleEngineServlet.java MAY 22, 2018
 * Project      : VINGS
 * File         : RuleEngineServlet.java
 * Author       : RISHABH KESHARI
 * Company      : VIDAL HEALTH
 * Date Created : MAY 22, 2018
 *
 * @author       :  RISHABH KESHARI
 * Modified by   :
 * Modified date :
 * Reason        : TO DISPLAY EXECUTED RULE DATA
 */


package com.vidal.common.rule;

import java.util.HashMap;
import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import org.apache.log4j.Logger;
import org.dom4j.Document;
import org.dom4j.Node;
import org.dom4j.io.SAXReader;

import com.vidal.common.CommandRuleValidations;

public class CommandValidationRuleListiner implements ServletContextListener  {
	
	
	private static Logger log = Logger.getLogger( CommandValidationRuleListiner.class );
	
	@Override
	public void contextDestroyed(ServletContextEvent scEvent) {
		
		CommandRuleValidations.load(null);
	}

	@SuppressWarnings("unchecked")
	@Override
	public void contextInitialized(ServletContextEvent scEvent) {
		try{
			ServletContext context=scEvent.getServletContext();
			
			SAXReader saxReader=new SAXReader();
			HashMap<String, List<Node>> commandValidationsMap=new HashMap<>();
			
			Document document=saxReader.read(context.getResourceAsStream("/WEB-INF/spring/appServlet/command-validations.xml"));
			
			List<Node> nodeList=document.selectNodes("command-validations/command");
			if(nodeList!=null){
				for(Node node:nodeList){					
					commandValidationsMap.put(node.valueOf("@name"), node.selectNodes("./field"));
				}
			}
			CommandRuleValidations.load(commandValidationsMap);
			log.info("Validation rules loaded in command-validations.xml file successfully");
		}catch(Exception exception){
			log.error("Validation rules not loaded in command-validations.xml file please check");
			exception.printStackTrace();
		}
	}
}//end of RuleEngineServlet

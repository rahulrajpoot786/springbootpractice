package com.vidal.common.reports;


import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;



import com.vidal.common.UXUtility;

public class BinaryStreamServlet extends HttpServlet{
	private static final long serialVersionUID = 1L;

	public void service(HttpServletRequest req, HttpServletResponse res)throws IOException
	{
		
		Boolean isGenerateReportNewWindow = false;
		String mode = req.getParameter("mode");
		if(mode != null)
		{
			if(mode.equals("doReportLink")||mode.equals("doGoBack"))	
			{
				isGenerateReportNewWindow = true;
			}//end of if(mode.equals("doReportLink")||mode.equals("doGoBack"))
		}//end of if(mode != null)
		if(isGenerateReportNewWindow){
			try{
				ByteArrayOutputStream baos = new ByteArrayOutputStream();
				OutputStream sos = res.getOutputStream();
				String openingWindow = null;
				String reportID = req.getParameter("reportID");
				//String fileName = req.getParameter("fileName");
				//String parameter = req.getParameter("parameter");
				if((reportID.equals("EndorsementList")||reportID.equals("PreAuthHistoryList")||reportID.equals("PreAuthHistoryInvestigationList") ||reportID.equals("ClaimHistoryList") || reportID.equals("ClaimHistoryInvestigationList")||reportID.equals("InvestigationDetails")||reportID.equals("BufferList")||reportID.equals("BufferDetails")) && mode.equals("doDefault"))
				{
					openingWindow = "location.href('/CustomerCareReportsAction.do?mode=doDefault"+"&reportID=" +
					req.getParameter("reportID") +
					"&parameter=" +
					req.getParameter("parameter") +
					"&reportType=pdf" +
					"&fileName=" +
					req.getParameter("fileName") +		
					"');";
				}
				else  if(reportID.equals("EndorsementList")||reportID.equals("PreAuthHistoryList")||reportID.equals("PreAuthHistoryInvestigationList") ||reportID.equals("ClaimHistoryList") || reportID.equals("ClaimHistoryInvestigationList")||reportID.equals("BufferList")||reportID.equals("BufferDetails"))
				{
					openingWindow = "window.open('/CustomerCareReportsAction.do?mode=doDefault"+"&reportID=" +
					req.getParameter("reportID") +
					"&parameter=" +
					req.getParameter("parameter") +
					"&reportType=pdf" +
					"&fileName=" +
					req.getParameter("fileName") +
					"','','" +
					"scrollbars=0,status=1,toolbar=1,top=0,left=0,resizable=1,menubar=yes,width="+"1024 - 15"+",height="+"715 - 65" +
					"');";
				}
				else if(reportID.equals("DisallowedBillList"))
				{
					openingWindow = "window.open('/CustomerCareReportsAction.do?mode=doDefault"+"&reportID=" +
					req.getParameter("reportID") +
					"&parameter=" +
					req.getParameter("parameter") +
					"&reportType=pdf" +
					"&fileName=" + 	  req.getParameter("fileName") +
					"&enrollmentID="+ req.getParameter("enrollmentID")+
					"&claimNumber="+  req.getParameter("claimNumber")+
					"&claimSettlNumber="+  req.getParameter("claimSettlNumber")+
					"','','" +
					"scrollbars=0,status=1,toolbar=1,top=0,left=0,resizable=1,menubar=yes,width="+"1024 - 15"+",height="+"715 - 65" +
					"');";
				}
				else if(reportID.equals("ClaAssDocList"))
				{
					openingWindow = "window.open('/ReportsAction.do?mode=doWebdoc"+"&module=associate" +
					"&fileName=" + 	  req.getParameter("fileName").replace("\\\\", "\\\\\\\\")+
					"','','" +
					"scrollbars=0,status=1,toolbar=1,top=0,left=0,resizable=1,menubar=yes,width="+"1024 - 15"+",height="+"715 - 65" +
					"');";
				}
				else if(reportID.equals("ShortfallQuestions") && mode.equals("doDefault"))
				{
					openingWindow = "location.href('/CustomerCareReportsAction.do?mode=doDefault"+"&reportID=" +
					req.getParameter("reportID") +
					"&parameter=" +
					req.getParameter("parameter") +
					"&reportType=pdf" +
					"&fileName=" +
					req.getParameter("fileName") +
					"');";
				}
				String str = 
					"<HTML><HEAD><title>another pdf report</title><SCRIPT LANGUAGE=JavaScript>function callAction() {" + openingWindow +
					"history.back();"+
					
					" }</SCRIPT></HEAD><BODY><SCRIPT LANGUAGE=JavaScript>callAction();</SCRIPT></BODY></HTML>";
				
				if(reportID.equals("GoBack"))
				{
					str = 
						"<HTML><HEAD><title>another pdf report</title><SCRIPT LANGUAGE=JavaScript>function callAction() {" + 
						"history.go(-2);"+						
						" }</SCRIPT></HEAD><BODY><SCRIPT LANGUAGE=JavaScript>callAction();</SCRIPT></BODY></HTML>";
				}		
				baos.write(str.getBytes());
				baos.writeTo(sos);
			}//end of try
			catch(IOException ioExp)
			{
				ioExp.printStackTrace();
			}//end of catch(IOException ioExp)
			catch(Exception exp)
			{
				exp.printStackTrace();
			}//end of catch(Exception e)
		} //end of if(isGenerateReportNewWindow){
		else   {
			try{
				String strReport="";
				ByteArrayOutputStream baos = null;
				String strFileName = req.getParameter("displayFile");
				if(req.getParameter("reportType")!=null)
				{
					strReport=req.getParameter("reportType");
				}//end of if(req.getParameter("reportType")!=null)
				else
				{
					strReport=(String)req.getAttribute("reportType");
				}//end of else

				if(UXUtility.checkNull(strReport).equals("EXL") || (strFileName != null && !strFileName.equals("")))
				{
					res.setContentType("application/vnd.ms-excel");
					if(req.getParameter("displayFile") != null)
					{
						String strFilName = req.getParameter("displayFile").toString();
						int FlieName=strFilName.lastIndexOf("/");
						strFilName = strFilName.substring(FlieName+1);
					//	strFilName = strFilName.substring(Integer.parseInt(TTKPropertiesReader.getPropertyValue("invdirno")));
						res.addHeader("Content-Disposition","attachment; filename="+strFilName);
					}//end of if(req.getParameter("displayFile") != null)
				}//end of if(TTKCommon.checkNull(strReport).equals("EXL")|| (strFileName != null && !strFileName.equals("")))
				//KOC 1353 for payment report
				else if(UXUtility.checkNull(strReport).equals("TXT") || (strFileName != null && !strFileName.equals("")))
				{
					
					res.setContentType("application/json"); 
					res.setHeader("Content-Disposition", "attachment; filename=Dashboard Report.txt");
					
				
				}
				//KOC 1353 for payment report
				else 
				{
					res.setContentType("application/pdf");				
				}//end of else

				if(req.getParameter("displayFile")!=null)
				{
					FileInputStream fis = new FileInputStream(req.getParameter("displayFile"));
					BufferedInputStream bis = new BufferedInputStream(fis);
					baos=new ByteArrayOutputStream();
					int ch;
					while ((ch = bis.read()) != -1)
					{
						baos.write(ch);
					}//end of while ((ch = bis.read()) != -1)
				}//end of if(req.getParameter("displayFile")!=null)
				else
				{
					baos = (ByteArrayOutputStream)req.getAttribute("boas");
				}//end of else

				if(baos==null)
				{
					baos = (ByteArrayOutputStream)req.getSession().getAttribute("boas");
				}//end of if(baos==null)
				OutputStream sos = res.getOutputStream();
				 baos.writeTo(sos);
				 
				req.getSession().removeAttribute("boas");
			}//end of try
			catch(IOException ioExp)
			{
				ioExp.printStackTrace();
			}//end of catch(IOException ioExp)
			catch(Exception exp)
			{
				exp.printStackTrace();
			}//end of catch(Exception e)
		}// end of if(!req.getParameter("mode").equalsIgnoreCase("GenerateReportNewWindow"))
		
	}//end of service(HttpServletRequest req, HttpServletResponse res)
}

package com.vidal.common.annotation.validator;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import org.springframework.beans.BeanWrapperImpl;


import com.vidal.common.annotation.DateFormate;

public class DateFormateValidator implements ConstraintValidator<DateFormate,Object>{

	private String dateField;
	@Override
	public void initialize(DateFormate constraintAnnotation) {
		// TODO Auto-generated method stub
		this.dateField=constraintAnnotation.dateField();
		
	}

	@Override
	public boolean isValid(Object value, ConstraintValidatorContext ctx) {
		// TODO Auto-generated method stub
		boolean status=false;
		Object field1 = new BeanWrapperImpl(value).getPropertyValue(dateField);
		if(field1 !=null && field1 !="") {
			String val=field1.toString();
			status =isValidDate(val);		
		}
		return status;
	}

	public static boolean isValidDate(String d)
    {
        String regex = "^(1[0-2]|0[1-9])/(3[01]"
				+ "|[12][0-9]|0[1-9])/[0-9]{4} (2[0-3]|[01]?[0-9]):([0-5]?[0-9] (AM|am|PM|pm))$";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher((CharSequence)d);
        return matcher.matches();
    }

}

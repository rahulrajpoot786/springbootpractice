package com.vidal.common.annotation.validator;

import java.text.SimpleDateFormat;
import java.util.Date;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import org.springframework.beans.BeanWrapperImpl;

import com.vidal.common.annotation.CurrentDate;

public class CurrentDateValidator implements ConstraintValidator<CurrentDate, Object>{

	private String datefield1;
	private String format;

	@Override
	public void initialize(CurrentDate constraintAnnotation) {
		// TODO Auto-generated method stub
		this.datefield1 = constraintAnnotation.datefield1();
		this.format = constraintAnnotation.format();
		
	}

	@Override
	public boolean isValid(Object value, ConstraintValidatorContext ctx) {
		boolean status = true;
		Object field1 = new BeanWrapperImpl(value).getPropertyValue(datefield1);
		if (field1 != null && field1 != "") {
			try {
				Date date = new Date();
				SimpleDateFormat sdf = new SimpleDateFormat(format);
				Date date1 = sdf.parse(field1.toString());
				 if (date1.after(date)) {
					 status = false;
			        }


			} catch (Exception e) {
				ctx.buildConstraintViolationWithTemplate("Unkown Error Occurred Please Contact Administrator")
						.addConstraintViolation();

				e.printStackTrace();
				status = false;
			}
		}
		return status;
	}

}

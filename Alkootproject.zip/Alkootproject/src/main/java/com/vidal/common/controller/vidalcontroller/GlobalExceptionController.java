package com.vidal.common.controller.vidalcontroller;

import java.sql.BatchUpdateException;
import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.ModelAndView;

import com.vidal.common.UXUtility;
import com.vidal.common.VidalCommon;
import com.vidal.common.exception.GetErrorMessage;
import com.vidal.common.exception.VidalException;

@Controller
@ControllerAdvice
public class GlobalExceptionController {

	@ExceptionHandler(Throwable.class)
	public ModelAndView globalException(HttpServletRequest request,Throwable throwable) {

		ModelAndView mav;
		VidalCommon.exceptionStackTrace(throwable,"vingsexceptionttkstackTrace.log");
		String strErrorPageView= (String)request.getAttribute("errorPageView");

		if(strErrorPageView!=null){
			mav = new ModelAndView(strErrorPageView);

			Model modelObj=(Model)request.getAttribute("modelObj");

			if(modelObj!=null)mav.addAllObjects(modelObj.asMap());
		}
		else mav = new ModelAndView("DefaultErrorPage");
		//    String strCommandName=request.getParameter("commandName");
		//Object commandObj=request.getAttribute(strCommandName);

		//    if(strCommandName!=null&&commandObj!=null){
		//    mav.addObject(request.getParameter("commandName"), commandObj);
		//}

		request.setAttribute("GLOBAL_ERROR", getErrorDetails(throwable));

		return mav;
	} 
	private String getErrorDetails(Throwable throwable){
		String errorDetails="";
		throwable.printStackTrace();
		String errorKey="error.general";

		if(throwable instanceof VidalException){
			errorKey=(((VidalException)throwable).getErrorKey());
		}else if(throwable instanceof BatchUpdateException){
			SQLException sqlException = (SQLException)throwable;
			errorDetails=GetErrorMessage.getErrorMessage(sqlException.getMessage());
		}else if(throwable instanceof SQLException){
			SQLException sqlException=((SQLException)throwable);
			//errorDetails=GetErrorMessage.getValue(sqlException.getErrorCode());
			errorDetails=GetErrorMessage.getValue(sqlException.getErrorCode() );
			if(sqlException.getErrorCode()==20285){
			String inputscreenerror[]=sqlException.getMessage().split("ORA-");
			String a=(String) inputscreenerror[1];
			return errorDetails=a.substring(6);
			}
			
		}
		if(errorDetails.equals(""))
		errorDetails= GetErrorMessage.getValue(errorKey);
		return errorDetails;
	}
}

package com.vidal.common;


import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import javax.servlet.ServletContext;
import javax.sql.DataSource;

import com.vidal.command.common.CacheVO;
import com.vidal.common.exception.VidalException;



public class PopulateFields {
	
	
	private static final String strapproval="select  INFO_SEQ_ID ,INFO_DESC from app.PRIC_ADDIT_BENF_GENERAL_DTL a where a.lable_seq_id =83";
	 private static final String stralternativesession="select  INFO_SEQ_ID ,INFO_DESC from app.PRIC_ADDIT_BENF_GENERAL_DTL a where a.lable_seq_id =82";
	
	
	private static final String strpsllimit="select  INFO_SEQ_ID ,INFO_DESC from app.PRIC_ADDIT_BENF_GENERAL_DTL a where a.lable_seq_id =92";
	 private static final String strparentacmdation="select  INFO_SEQ_ID ,INFO_DESC from app.PRIC_ADDIT_BENF_GENERAL_DTL a where a.lable_seq_id =5";
	 private static final String strenwal="select  flag,descr  from( select 'New Client' descr, 'N' flag from dual union all select 'Renewal' ,'Y' from dual)";
	 
	 
	 private static final String strinpatientlimit = "select  INFO_SEQ_ID ,INFO_DESC from app.PRIC_ADDIT_BENF_GENERAL_DTL a where a.lable_seq_id =6";
    private static final String strNetworkList = "SELECT A.NWK_TYPE_SEQ_ID,A.NWK_NAME FROM APP.TPA_NETWORK_TYPE_MASTER_SPR A  WHERE A.NWK_TYPE_SEQ_ID IN(1,2,3,5) ORDER BY A.NWK_TYPE_SEQ_ID";
    private static final String strOpticalLimitList = "SELECT LIMIT_TYPE_SEQ_ID,MAX_LIMIT FROM((SELECT A.LIMIT_TYPE_SEQ_ID,A.SORT_NO,TO_CHAR(A.MAX_LIMIT,'FM999G999G999G999G999G999G999G999G999') AS MAX_LIMIT FROM APP.TPA_MAX_LIMIT_TYPE_MASTER A WHERE A.LIMIT_TYPE_SEQ_ID IN (1,2,3,4,5,6,7,8,10,12,13,14,16,18,21,55) UNION ALL SELECT A.LIMIT_TYPE_SEQ_ID,A.SORT_NO,A.MAX_LIMIT AS MAX_LIMIT FROM APP.TPA_MAX_LIMIT_TYPE_MASTER A WHERE A.LIMIT_TYPE_SEQ_ID IN (45)) ORDER BY SORT_NO)";
    
    private static final String strClientCodeList = "SELECT A.group_reg_seq_id,DECODE(NVL(a.office_number,'000'),'000',a.group_id,a.group_id||'-'||a.office_number) group_id FROM tpa_group_registration A JOIN tpa_office_info B ON (A.tpa_office_seq_id = B.tpa_office_seq_id) order by group_id";
    
    
    private static final String strBrokerCodeList = "SELECT 'DIR' abb, 'Direct' as descr from dual union select 'BRO', 'Broker' from dual  union  select 'TEN', 'Tender' from dual";
    private static final String strMaxBenifitListIp = "SELECT LIMIT_TYPE_SEQ_ID,MAX_LIMIT FROM ( SELECT A.LIMIT_TYPE_SEQ_ID,A.SORT_NO,TO_CHAR(A.MAX_LIMIT,'FM999G999G999G999G999G999G999G999G999') AS MAX_LIMIT FROM APP.TPA_MAX_LIMIT_TYPE_MASTER A WHERE A.LIMIT_TYPE_SEQ_ID IN (31,32,33,34,35,36,37,38,39,40,41,42,43,44,46,47,53,48,49) UNION ALL SELECT A.LIMIT_TYPE_SEQ_ID,A.SORT_NO,A.MAX_LIMIT AS MAX_LIMIT FROM APP.TPA_MAX_LIMIT_TYPE_MASTER A WHERE A.LIMIT_TYPE_SEQ_ID IN (45))  ORDER BY SORT_NO ";
    private static final String strMaxBenifitListOpLimitIp = "SELECT LIMIT_TYPE_SEQ_ID,MAX_LIMIT FROM ( SELECT A.LIMIT_TYPE_SEQ_ID,A.SORT_NO,TO_CHAR(A.MAX_LIMIT,'FM999G999G999G999G999G999G999G999G999') AS MAX_LIMIT FROM APP.TPA_MAX_LIMIT_TYPE_MASTER_SPR A WHERE A.LIMIT_TYPE_SEQ_ID IN (31,32,33,34,35,36,37,38,39,40,41,42,43,44,46,47,53,48,49) UNION ALL SELECT A.LIMIT_TYPE_SEQ_ID,A.SORT_NO,A.MAX_LIMIT AS MAX_LIMIT FROM APP.TPA_MAX_LIMIT_TYPE_MASTER_SPR A WHERE A.LIMIT_TYPE_SEQ_ID IN (45,58,59,60))  ORDER BY SORT_NO";
   /* private static final String strAreaOfCoverList = "SELECT A.AREA_TYPE_SEQ_ID,A.AREA_NAME FROM APP.TPA_AREA_TYPE_MASTER_SPR A ORDER BY A.SORT_NO";*/
    private static final String strAreaOfCoverList = "SELECT A.AREA_TYPE_SEQ_ID,A.AREA_NAME FROM APP.TPA_AREA_TYPE_MASTER_SPR A where area_type_seq_id not in(11,21,20) ORDER BY A.SORT_NO";
    private static final String strOpCopaypharmacyList = "SELECT COPAY_TYPE_SEQ_ID,COPAY_PERC FROM ((SELECT A.COPAY_TYPE_SEQ_ID,A.SORT_NO, A.COPAY_PERC  AS COPAY_PERC FROM APP.TPA_COPAY_TYPE_MASTER A WHERE A.COPAY_TYPE_SEQ_ID IN (1, 2, 3, 4, 5,16,17) UNION ALL SELECT A.COPAY_TYPE_SEQ_ID,A.SORT_NO, A.COPAY_PERC FROM APP.TPA_COPAY_TYPE_MASTER A WHERE A.COPAY_TYPE_SEQ_ID = 6) ORDER BY SORT_NO)";
    private static final String strOpInvestigationList = "SELECT COPAY_TYPE_SEQ_ID,COPAY_PERC FROM ((SELECT A.COPAY_TYPE_SEQ_ID,A.SORT_NO, A.COPAY_PERC  AS COPAY_PERC FROM APP.TPA_COPAY_TYPE_MASTER A WHERE A.COPAY_TYPE_SEQ_ID IN (1, 2, 3, 4, 5,16,17) UNION ALL SELECT A.COPAY_TYPE_SEQ_ID,A.SORT_NO, A.COPAY_PERC FROM APP.TPA_COPAY_TYPE_MASTER A WHERE A.COPAY_TYPE_SEQ_ID = 6) ORDER BY SORT_NO)";
    private static final String strOpCopyothersList = "SELECT COPAY_TYPE_SEQ_ID,COPAY_PERC FROM ((SELECT A.COPAY_TYPE_SEQ_ID,A.SORT_NO, A.COPAY_PERC  AS COPAY_PERC FROM APP.TPA_COPAY_TYPE_MASTER A WHERE A.COPAY_TYPE_SEQ_ID IN (1, 2, 3, 4, 5,16,17) UNION ALL SELECT A.COPAY_TYPE_SEQ_ID,A.SORT_NO, A.COPAY_PERC FROM APP.TPA_COPAY_TYPE_MASTER A WHERE A.COPAY_TYPE_SEQ_ID = 6) ORDER BY SORT_NO)";
    private static final String strOpticalCopayList = "SELECT COPAY_TYPE_SEQ_ID,COPAY_PERC FROM ((SELECT A.COPAY_TYPE_SEQ_ID, A.SORT_NO,A.COPAY_PERC  AS COPAY_PERC FROM APP.TPA_COPAY_TYPE_MASTER_SPR A WHERE A.COPAY_TYPE_SEQ_ID IN (1, 2, 3, 4, 5, 9) UNION ALL SELECT A.COPAY_TYPE_SEQ_ID,A.SORT_NO, A.COPAY_PERC FROM APP.TPA_COPAY_TYPE_MASTER_SPR A WHERE A.COPAY_TYPE_SEQ_ID = 6) ORDER BY SORT_NO)";
    private static final String strOpticalFrameLimitList = "SELECT M.OPTCL_FRAMES_LIMIT_SEQ_ID,M.OPTICAL_FRAME_LIMIT FROM APP.TPA_OPTCL_FRME_LMT_MSTR_SPR M ORDER BY M.OPTCL_FRAMES_LIMIT_SEQ_ID";
    private static final String strDentalLimitList = "SELECT LIMIT_TYPE_SEQ_ID,MAX_LIMIT FROM((SELECT A.LIMIT_TYPE_SEQ_ID,A.SORT_NO,TO_CHAR(A.MAX_LIMIT,'FM999G999G999G999G999G999G999G999G999') AS MAX_LIMIT FROM APP.TPA_MAX_LIMIT_TYPE_MASTER A WHERE A.LIMIT_TYPE_SEQ_ID IN (1,2,3,5,6,9,10,11,12,14,15,16,17,18,19,20,22,24,29,50,56) UNION ALL SELECT A.LIMIT_TYPE_SEQ_ID,A.SORT_NO,A.MAX_LIMIT AS MAX_LIMIT FROM APP.TPA_MAX_LIMIT_TYPE_MASTER A WHERE A.LIMIT_TYPE_SEQ_ID IN (45)) ORDER BY SORT_NO)";
    private static final String strDentalcopayList = "SELECT COPAY_TYPE_SEQ_ID,COPAY_PERC FROM ((SELECT A.COPAY_TYPE_SEQ_ID,A.SORT_NO, A.COPAY_PERC  AS COPAY_PERC FROM APP.TPA_COPAY_TYPE_MASTER_SPR A WHERE A.COPAY_TYPE_SEQ_ID IN (1, 2, 3, 4, 5, 9) UNION ALL SELECT A.COPAY_TYPE_SEQ_ID,A.SORT_NO, A.COPAY_PERC FROM APP.TPA_COPAY_TYPE_MASTER_SPR A WHERE A.COPAY_TYPE_SEQ_ID IN (10,11) UNION ALL SELECT A.COPAY_TYPE_SEQ_ID,A.SORT_NO, A.COPAY_PERC||'/deductible' FROM APP.TPA_COPAY_TYPE_MASTER_SPR A WHERE A.COPAY_TYPE_SEQ_ID IN (6)) ORDER BY SORT_NO)";
    private static final String strOrthodonticsCopay ="SELECT COPAY_TYPE_SEQ_ID,COPAY_PERC FROM ((SELECT A.COPAY_TYPE_SEQ_ID,A.SORT_NO, A.COPAY_PERC AS COPAY_PERC FROM APP.TPA_COPAY_TYPE_MASTER_SPR A WHERE A.COPAY_TYPE_SEQ_ID IN (1, 2, 3, 4, 5,9,18,30,39) UNION ALL SELECT A.COPAY_TYPE_SEQ_ID, A.SORT_NO,A.COPAY_PERC FROM APP.TPA_COPAY_TYPE_MASTER_SPR A WHERE A.COPAY_TYPE_SEQ_ID = 6) ORDER BY SORT_NO)";
    private static final String strMaternityLimitList = "SELECT LIMIT_TYPE_SEQ_ID,MAX_LIMIT FROM ((SELECT A.LIMIT_TYPE_SEQ_ID,A.SORT_NO,TO_CHAR(A.MAX_LIMIT,'FM999G999G999G999G999G999G999G999G999') AS MAX_LIMIT FROM APP.TPA_MAX_LIMIT_TYPE_MASTER A WHERE A.LIMIT_TYPE_SEQ_ID IN (20,22,23,24,25,26,27,28,30,52,57) UNION ALL SELECT A.LIMIT_TYPE_SEQ_ID,A.SORT_NO,A.MAX_LIMIT AS MAX_LIMIT FROM APP.TPA_MAX_LIMIT_TYPE_MASTER A WHERE A.LIMIT_TYPE_SEQ_ID IN (45)) ORDER BY SORT_NO)";
    
    private static final String stropCopyalahlihospList =    "SELECT COPAY_TYPE_SEQ_ID,COPAY_PERC FROM((SELECT A.COPAY_TYPE_SEQ_ID,A.SORT_NO, A.COPAY_PERC  AS COPAY_PERC FROM APP.TPA_COPAY_TYPE_MASTER_SPR A WHERE A.COPAY_TYPE_SEQ_ID IN (1,2,9,3,5,19,20,31,32) UNION ALL SELECT A.COPAY_TYPE_SEQ_ID,A.SORT_NO, A.COPAY_PERC||'/deductible' as COPAY_PERC FROM APP.TPA_COPAY_TYPE_MASTER_SPR A WHERE A.COPAY_TYPE_SEQ_ID = 6))";   
    private static final String strOpPharmacyAlAhliList =    "(SELECT A.COPAY_TYPE_SEQ_ID, A.COPAY_PERC  AS COPAY_PERC FROM APP.TPA_COPAY_TYPE_MASTER A WHERE A.COPAY_TYPE_SEQ_ID IN (1, 2, 3, 4, 5) UNION ALL SELECT A.COPAY_TYPE_SEQ_ID, A.COPAY_PERC FROM APP.TPA_COPAY_TYPE_MASTER A WHERE A.COPAY_TYPE_SEQ_ID = 6) ORDER BY COPAY_TYPE_SEQ_ID";
    private static final String strOpInvestnAlAhliList =    "(SELECT A.COPAY_TYPE_SEQ_ID, A.COPAY_PERC  AS COPAY_PERC FROM APP.TPA_COPAY_TYPE_MASTER A WHERE A.COPAY_TYPE_SEQ_ID IN (1, 2, 3, 4, 5) UNION ALL SELECT A.COPAY_TYPE_SEQ_ID, A.COPAY_PERC FROM APP.TPA_COPAY_TYPE_MASTER A WHERE A.COPAY_TYPE_SEQ_ID = 6) ORDER BY COPAY_TYPE_SEQ_ID";
    private static final String strOpothersAlAhliList =    "(SELECT A.COPAY_TYPE_SEQ_ID, A.COPAY_PERC  AS COPAY_PERC FROM APP.TPA_COPAY_TYPE_MASTER A WHERE A.COPAY_TYPE_SEQ_ID IN (1, 2, 3, 4, 5) UNION ALL SELECT A.COPAY_TYPE_SEQ_ID, A.COPAY_PERC FROM APP.TPA_COPAY_TYPE_MASTER A WHERE A.COPAY_TYPE_SEQ_ID = 6) ORDER BY COPAY_TYPE_SEQ_ID";
    private static final String strOpConsultAlAhliList =    "SELECT COPAY_TYPE_SEQ_ID,COPAY_PERC FROM((SELECT A.COPAY_TYPE_SEQ_ID,A.SORT_NO, A.COPAY_PERC  AS COPAY_PERC FROM APP.TPA_COPAY_TYPE_MASTER A WHERE A.COPAY_TYPE_SEQ_ID IN (1, 2, 3, 4, 5,9) UNION ALL SELECT A.COPAY_TYPE_SEQ_ID,A.SORT_NO, A.COPAY_PERC FROM APP.TPA_COPAY_TYPE_MASTER A WHERE A.COPAY_TYPE_SEQ_ID = 6) ORDER BY SORT_NO)";    private static final String strChronicLimitList = "(SELECT A.COPAY_TYPE_SEQ_ID, A.COPAY_PERC  AS COPAY_PERC FROM APP.TPA_COPAY_TYPE_MASTER A WHERE A.COPAY_TYPE_SEQ_ID IN ( 5) UNION ALL SELECT A.COPAY_TYPE_SEQ_ID, A.COPAY_PERC FROM APP.TPA_COPAY_TYPE_MASTER A WHERE A.COPAY_TYPE_SEQ_ID = 6) ORDER BY COPAY_TYPE_SEQ_ID";
     
    private static final String strIpCopayList = "SELECT B.COPAY_TYPE_SEQ_ID,B.COPAY_PERC FROM(SELECT A.COPAY_TYPE_SEQ_ID, A.SORT_NO, A.COPAY_PERC AS COPAY_PERC FROM APP.TPA_COPAY_TYPE_MASTER_SPR A WHERE A.COPAY_TYPE_SEQ_ID IN(2,17,36,16) UNION ALL SELECT A.COPAY_TYPE_SEQ_ID, A.SORT_NO, A.COPAY_PERC AS COPAY_PERC FROM APP.TPA_COPAY_TYPE_MASTER_SPR A WHERE A.COPAY_TYPE_SEQ_ID=6) B";  
   /* private static final String strIpCopayList = "SELECT B.COPAY_TYPE_SEQ_ID,B.COPAY_PERC FROM(SELECT A.COPAY_TYPE_SEQ_ID, A.SORT_NO, A.COPAY_PERC AS COPAY_PERC FROM APP.TPA_COPAY_TYPE_MASTER A WHERE A.COPAY_TYPE_SEQ_ID IN(16,17) UNION ALL SELECT A.COPAY_TYPE_SEQ_ID, A.SORT_NO, A.COPAY_PERC AS COPAY_PERC FROM APP.TPA_COPAY_TYPE_MASTER A WHERE A.COPAY_TYPE_SEQ_ID=6) B";*/
    private static final String strIPCopayAtAhliList = "SELECT B.COPAY_TYPE_SEQ_ID,B.COPAY_PERC FROM(SELECT A.COPAY_TYPE_SEQ_ID, A.SORT_NO, A.COPAY_PERC AS COPAY_PERC FROM APP.TPA_COPAY_TYPE_MASTER_SPR A WHERE A.COPAY_TYPE_SEQ_ID IN(1,2,9) UNION ALL SELECT A.COPAY_TYPE_SEQ_ID, A.SORT_NO, A.COPAY_PERC AS COPAY_PERC FROM APP.TPA_COPAY_TYPE_MASTER_SPR A WHERE A.COPAY_TYPE_SEQ_ID=6) B";    
    private static final String strAdditionalHospitalCoverageList ="";   
    private static final String strResidencyCountryList ="select 0 COUNTRY_ID,'Miscellaneous' COUNTRY_NAME FROM DUAL UNION ALL select * from (select COUNTRY_ID, COUNTRY_NAME from app.tpa_country_code order by country_name asc )";  
    private static final String strMaternityPricingList ="select 1 mat_pric_Seq, 'As a part of overall pricing' mat_pric_desc from dual union all select 2 , 'To be calculated and displayed separately' from dual";
    private static final String strRemiumOutputStructureList ="select 1 Premium_output_seq_, 'Overall' Premium_output_desc from dual  union select 2 , 'By Age Band' from dual union select 3 , 'By Age Band and Gender' from dual";
  /*  private static final String strMaternityCopayList ="SELECT B.COPAY_TYPE_SEQ_ID, B.COPAY_PERC FROM (SELECT A.COPAY_TYPE_SEQ_ID, A.SORT_NO, A.COPAY_PERC AS COPAY_PERC FROM APP.TPA_COPAY_TYPE_MASTER_SPR A WHERE A.COPAY_TYPE_SEQ_ID IN (1, 2, 9,3,4,5,15) UNION ALL SELECT A.COPAY_TYPE_SEQ_ID, A.SORT_NO, A.COPAY_PERC||'/deductible'  AS COPAY_PERC FROM APP.TPA_COPAY_TYPE_MASTER_SPR A WHERE A.COPAY_TYPE_SEQ_ID = 6) B";*/

    private static final String strMaternityCopayList ="SELECT B.COPAY_TYPE_SEQ_ID, B.COPAY_PERC FROM (SELECT A.COPAY_TYPE_SEQ_ID, A.SORT_NO, A.COPAY_PERC AS COPAY_PERC FROM APP.TPA_COPAY_TYPE_MASTER_SPR A WHERE A.COPAY_TYPE_SEQ_ID IN (1, 2, 9,3,4,5,15,35) UNION ALL SELECT A.COPAY_TYPE_SEQ_ID, A.SORT_NO, A.COPAY_PERC AS COPAY_PERC FROM APP.TPA_COPAY_TYPE_MASTER_SPR A WHERE A.COPAY_TYPE_SEQ_ID = 6) B";
    private static final String strOpCopyconsultnList ="SELECT COPAY_TYPE_SEQ_ID,COPAY_PERC FROM ((SELECT A.COPAY_TYPE_SEQ_ID,A.SORT_NO,A.COPAY_PERC  COPAY_PERC FROM APP.TPA_COPAY_TYPE_MASTER A WHERE A.COPAY_TYPE_SEQ_ID IN (1, 2, 3, 4,5,10,11,12,13,14,15) UNION ALL SELECT A.COPAY_TYPE_SEQ_ID,A.SORT_NO,A.COPAY_PERC FROM APP.TPA_COPAY_TYPE_MASTER A WHERE A.COPAY_TYPE_SEQ_ID = 6) ORDER BY SORT_NO)";  // siva

   // private static final String strOpCopayList = "SELECT COPAY_TYPE_SEQ_ID,COPAY_PERC FROM((SELECT A.COPAY_TYPE_SEQ_ID,A.SORT_NO, A.COPAY_PERC  AS COPAY_PERC FROM APP.TPA_COPAY_TYPE_MASTER A WHERE A.COPAY_TYPE_SEQ_ID IN (1, 2, 3, 4, 5) UNION ALL SELECT A.COPAY_TYPE_SEQ_ID,A.SORT_NO, A.COPAY_PERC FROM APP.TPA_COPAY_TYPE_MASTER A WHERE A.COPAY_TYPE_SEQ_ID = 6) ORDER BY SORT_NO)";
    private static final String strOpCopayList = "SELECT COPAY_TYPE_SEQ_ID,COPAY_PERC FROM (SELECT COPAY_TYPE_SEQ_ID, COPAY_PERC FROM APP.TPA_COPAY_TYPE_MASTER_SPR WHERE copay_type_seq_id IN (1,2,3,5,10,11,15,23,21,24,25,26,27,28,37,29,16,33,34,38) UNION ALL SELECT COPAY_TYPE_SEQ_ID, COPAY_PERC||'/deductible' FROM APP.TPA_COPAY_TYPE_MASTER_SPR WHERE copay_type_seq_id IN(6))";
    
    private static final String strPremiumRefundApproachList = "SELECT G.GENERAL_TYPE_ID,G.DESCRIPTION FROM APP.TPA_PRIC_GENERAL_CODE G WHERE G.HEADER_TYPE = 'CREDIT_NOTE_LOGIC' ORDER BY G.SORT_NO";
    private static final String strOPDSPECIALITY = "SELECT H.GENERAL_TYPE_ID,H.DESCRIPTION  FROM   APP.TPA_GENERAL_CODE H WHERE H.HEADER_TYPE ='OPD_PAT_SPECIALTY' ORDER BY H.SORT_NO";


    private static final String strACCOUNT_HEAD_OPDTYPE = "SELECT WARD_TYPE_ID,WARD_DESCRIPTION FROM TPA_HOSP_WARD_CODE WHERE NVL(ACTIVE_YN,'N')!='X' and WARD_TYPE_ID IN('OTR','CON','LAI','MED') ORDER BY WARD_DESCRIPTION";


    private static final String strprobmaticResign = "select GENERAL_TYPE_ID,DESCRIPTION  from app.tpa_general_code  where header_type in ('PRBLM_CUS_TYPE','PRBLM_PARAM_TYPE')";


    private static final String strprobmaticLocation = "select TPA_OFFICE_SEQ_ID,OFFICE_NAME from app.tpa_office_info where PROBLEMATIC_YN = 'Y' ";

    
    private static final String strlifeThreateningdiease ="SELECT A.INFO_SEQ_ID, A.INFO_DESC FROM PRIC_ADDIT_BENF_GENERAL_DTL A  WHERE A.LABLE_SEQ_ID =61 and a.info_seq_id not in (200) ORDER BY  A.INFO_SEQ_ID "; 
    private static final String strworkrelateddrop1 ="SELECT A.INFO_SEQ_ID, A.INFO_DESC FROM PRIC_ADDIT_BENF_GENERAL_DTL A  WHERE A.LABLE_SEQ_ID =59 and a.info_seq_id not in(189) ORDER BY  A.INFO_SEQ_ID"; 
    private static final String strorganlimit ="SELECT A.INFO_SEQ_ID, A.INFO_DESC FROM PRIC_ADDIT_BENF_GENERAL_DTL A  WHERE A.LABLE_SEQ_ID =32 ORDER BY  A.INFO_SEQ_ID";
  
    //additional
    private static final String strinpatientroom = "select  INFO_SEQ_ID ,INFO_DESC from app.PRIC_ADDIT_BENF_GENERAL_DTL a where a.lable_seq_id =79"; 
    private static final String strinpatientaccomdation = "select  INFO_SEQ_ID ,INFO_DESC from app.PRIC_ADDIT_BENF_GENERAL_DTL a where a.lable_seq_id =80";
    private static final String strinpatientcash = "select  INFO_SEQ_ID ,INFO_DESC from app.PRIC_ADDIT_BENF_GENERAL_DTL a where a.lable_seq_id =81"; 
    private static final String strPhysiotherepy = "SELECT A.INFO_SEQ_ID, A.INFO_DESC FROM PRIC_ADDIT_BENF_GENERAL_DTL A  WHERE A.LABLE_SEQ_ID =11 ORDER BY  A.INFO_SEQ_ID"; 
    private static final String strPhysiotherepysession = "SELECT A.INFO_SEQ_ID, A.INFO_DESC FROM PRIC_ADDIT_BENF_GENERAL_DTL A  WHERE A.LABLE_SEQ_ID =12 ORDER BY  A.INFO_SEQ_ID"; 
    private static final String stralternativecmplimit = "SELECT A.INFO_SEQ_ID, A.INFO_DESC FROM PRIC_ADDIT_BENF_GENERAL_DTL A  WHERE A.LABLE_SEQ_ID =14 ORDER BY  A.INFO_SEQ_ID"; 
    private static final String strinternationalasslimit = "SELECT A.INFO_SEQ_ID, A.INFO_DESC FROM PRIC_ADDIT_BENF_GENERAL_DTL A  WHERE A.LABLE_SEQ_ID =38 ORDER BY  A.INFO_SEQ_ID"; 
    private static final String strpsychiatrylimitt = "SELECT A.INFO_SEQ_ID, A.INFO_DESC FROM PRIC_ADDIT_BENF_GENERAL_DTL A  WHERE A.LABLE_SEQ_ID =41 ORDER BY  A.INFO_SEQ_ID";
    private static final String strpsychiatcopayt = "SELECT A.INFO_SEQ_ID, A.INFO_DESC FROM PRIC_ADDIT_BENF_GENERAL_DTL A  WHERE A.LABLE_SEQ_ID =42 ORDER BY  A.INFO_SEQ_ID";
    private static final String strvacationlimit = "SELECT A.INFO_SEQ_ID, A.INFO_DESC FROM PRIC_ADDIT_BENF_GENERAL_DTL A  WHERE A.LABLE_SEQ_ID =44 ORDER BY  A.INFO_SEQ_ID"; 
    private static final String strvacation = "SELECT A.INFO_SEQ_ID, A.INFO_DESC FROM PRIC_ADDIT_BENF_GENERAL_DTL A  WHERE A.LABLE_SEQ_ID =45 ORDER BY  A.INFO_SEQ_ID"; 
    private static final String strpreexist = "SELECT A.INFO_SEQ_ID, A.INFO_DESC FROM PRIC_ADDIT_BENF_GENERAL_DTL A  WHERE A.LABLE_SEQ_ID =17 ORDER BY  A.INFO_SEQ_ID";
    private static final String strmaintance = "SELECT A.INFO_SEQ_ID, A.INFO_DESC FROM PRIC_ADDIT_BENF_GENERAL_DTL A  WHERE A.LABLE_SEQ_ID =19 ORDER BY  A.INFO_SEQ_ID"; 
    private static final String strhormonelimit = "SELECT A.INFO_SEQ_ID, A.INFO_DESC FROM PRIC_ADDIT_BENF_GENERAL_DTL A  WHERE A.LABLE_SEQ_ID =25 ORDER BY  A.INFO_SEQ_ID"; 
    private static final String strinpatientt = "SELECT A.INFO_SEQ_ID, A.INFO_DESC FROM PRIC_ADDIT_BENF_GENERAL_DTL A  WHERE A.LABLE_SEQ_ID =27 ORDER BY  A.INFO_SEQ_ID";
    private static final String strnursingdrop = "SELECT A.INFO_SEQ_ID, A.INFO_DESC FROM PRIC_ADDIT_BENF_GENERAL_DTL A  WHERE A.LABLE_SEQ_ID =29 ORDER BY  A.INFO_SEQ_ID"; 
    private static final String strVitamins = "SELECT A.INFO_SEQ_ID, A.INFO_DESC FROM PRIC_ADDIT_BENF_GENERAL_DTL A  WHERE A.LABLE_SEQ_ID =36 ORDER BY  A.INFO_SEQ_ID "; 
    private static final String strPassiveWar = "SELECT A.INFO_SEQ_ID, A.INFO_DESC FROM PRIC_ADDIT_BENF_GENERAL_DTL A  WHERE A.LABLE_SEQ_ID =33 ORDER BY  A.INFO_SEQ_ID";
    private static final String strPreandpostnatal = "SELECT A.INFO_SEQ_ID, A.INFO_DESC FROM PRIC_ADDIT_BENF_GENERAL_DTL A  WHERE A.LABLE_SEQ_ID =48 ORDER BY  A.INFO_SEQ_ID"; 
    private static final String strwellbeingbenfittdrop = "SELECT A.INFO_SEQ_ID, A.INFO_DESC FROM PRIC_ADDIT_BENF_GENERAL_DTL A  WHERE A.LABLE_SEQ_ID =50 ORDER BY  A.INFO_SEQ_ID"; 
    private static final String strExternalProsthesisdrop ="SELECT A.INFO_SEQ_ID, A.INFO_DESC FROM PRIC_ADDIT_BENF_GENERAL_DTL A  WHERE A.LABLE_SEQ_ID =58 ORDER BY  A.INFO_SEQ_ID";
    private static final String strworkrelateddrop = "SELECT A.INFO_SEQ_ID, A.INFO_DESC FROM PRIC_ADDIT_BENF_GENERAL_DTL A  WHERE A.LABLE_SEQ_ID =60 ORDER BY  A.INFO_SEQ_ID" ;
    private static final String strlifediseasecdrop = "SELECT A.INFO_SEQ_ID, A.INFO_DESC FROM PRIC_ADDIT_BENF_GENERAL_DTL A  WHERE A.LABLE_SEQ_ID =63 ORDER BY  A.INFO_SEQ_ID"; 
    private static final String strobesite = "SELECT A.INFO_SEQ_ID, A.INFO_DESC FROM PRIC_ADDIT_BENF_GENERAL_DTL A  WHERE A.LABLE_SEQ_ID =65 ORDER BY  A.INFO_SEQ_ID";
    private static final String strhospiceandPalliativedrop = "SELECT A.INFO_SEQ_ID, A.INFO_DESC FROM PRIC_ADDIT_BENF_GENERAL_DTL A  WHERE A.LABLE_SEQ_ID =67 ORDER BY  A.INFO_SEQ_ID";
    private static final String strditecianlimitdrop = "SELECT A.INFO_SEQ_ID, A.INFO_DESC FROM PRIC_ADDIT_BENF_GENERAL_DTL A  WHERE A.LABLE_SEQ_ID =72 ORDER BY  A.INFO_SEQ_ID";
    private static final String strhIVandaIDSLimitdrop = "SELECT A.INFO_SEQ_ID, A.INFO_DESC FROM PRIC_ADDIT_BENF_GENERAL_DTL A  WHERE A.LABLE_SEQ_ID =74 ORDER BY  A.INFO_SEQ_ID"; 
    private static final String strcircumcisionlimitdrop = "SELECT A.INFO_SEQ_ID, A.INFO_DESC FROM PRIC_ADDIT_BENF_GENERAL_DTL A  WHERE A.LABLE_SEQ_ID =76 ORDER BY  A.INFO_SEQ_ID"; 
    private static final String strcompassionatevisitdrop = "SELECT A.INFO_SEQ_ID, A.INFO_DESC FROM PRIC_ADDIT_BENF_GENERAL_DTL A  WHERE A.LABLE_SEQ_ID =69 ORDER BY  A.INFO_SEQ_ID"; 
    private static final String strexternalmedicaldrop = "SELECT A.INFO_SEQ_ID, A.INFO_DESC FROM PRIC_ADDIT_BENF_GENERAL_DTL A  WHERE A.LABLE_SEQ_ID =69 ORDER BY  A.INFO_SEQ_ID"; 
    private static final String strhealthscreenlimitdrop = "SELECT A.INFO_SEQ_ID, A.INFO_DESC FROM PRIC_ADDIT_BENF_GENERAL_DTL A  WHERE A.LABLE_SEQ_ID =52 ORDER BY  A.INFO_SEQ_ID";
    private static final String strhealthsessions = "SELECT A.INFO_SEQ_ID, A.INFO_DESC FROM PRIC_ADDIT_BENF_GENERAL_DTL A  WHERE A.LABLE_SEQ_ID =53 ORDER BY  A.INFO_SEQ_ID"; 
    private static final String strhealthscreencopay = "SELECT A.INFO_SEQ_ID, A.INFO_DESC FROM PRIC_ADDIT_BENF_GENERAL_DTL A  WHERE A.LABLE_SEQ_ID =54 ORDER BY  A.INFO_SEQ_ID "; 
    private static final String strpregnancy = "SELECT A.INFO_SEQ_ID, A.INFO_DESC FROM PRIC_ADDIT_BENF_GENERAL_DTL A  WHERE A.LABLE_SEQ_ID =46 ORDER BY  A.INFO_SEQ_ID"; 
    private static final String strdeductiblecoinsurance ="SELECT A.INFO_SEQ_ID, A.INFO_DESC FROM PRIC_ADDIT_BENF_GENERAL_DTL A  WHERE A.LABLE_SEQ_ID =56 ORDER BY  A.INFO_SEQ_ID"; 
    private static final String strexternalmedicalcopay ="SELECT A.INFO_SEQ_ID, A.INFO_DESC FROM PRIC_ADDIT_BENF_GENERAL_DTL A  WHERE A.LABLE_SEQ_ID =70 ORDER BY  A.INFO_SEQ_ID";
    private static final String stralternativecopay ="SELECT A.INFO_SEQ_ID, A.INFO_DESC FROM PRIC_ADDIT_BENF_GENERAL_DTL A  WHERE A.LABLE_SEQ_ID =15 ORDER BY  A.INFO_SEQ_ID";
    private static final String strcurrency ="SELECT DISTINCT CURRENCY_ID, CURRENCY_ID CURRENCY FROM TPA_CURRENCY_CODE order by CURRENCY_ID";
    private static final String strnetworkListFactor ="SELECT A.NWK_TYPE_SEQ_ID,A.NWK_NAME FROM APP.TPA_NETWORK_TYPE_MASTER_SPR A  WHERE A.NWK_TYPE_SEQ_ID IN(1,2,3) ORDER BY A.NWK_TYPE_SEQ_ID";
    private static final String stroutside="SELECT A.INFO_SEQ_ID, A.INFO_DESC FROM PRIC_ADDIT_BENF_GENERAL_DTL A  WHERE A.LABLE_SEQ_ID =1 ORDER BY A.INFO_SEQ_ID"; 
    private static final String strreimbursement="SELECT A.INFO_SEQ_ID, A.INFO_DESC FROM PRIC_ADDIT_BENF_GENERAL_DTL A  WHERE A.LABLE_SEQ_ID =2 ORDER BY  A.INFO_SEQ_ID"; 
    
    private static final String strMaternityCopayListWhatis ="SELECT LIMIT_TYPE_SEQ_ID,MAX_LIMIT FROM ((SELECT A.LIMIT_TYPE_SEQ_ID,A.SORT_NO,TO_CHAR(A.MAX_LIMIT,'FM999G999G999G999G999G999G999G999G999') AS MAX_LIMIT FROM APP.TPA_MAX_LIMIT_TYPE_MASTER A WHERE A.LIMIT_TYPE_SEQ_ID IN (20,22,23,24,25,26,27,28,30,52,57) ) ORDER BY SORT_NO)";
    
    private static final String strMaxBenifitListIpWhatif = "SELECT LIMIT_TYPE_SEQ_ID,MAX_LIMIT FROM ( SELECT A.LIMIT_TYPE_SEQ_ID,A.SORT_NO,TO_CHAR(A.MAX_LIMIT,'FM999G999G999G999G999G999G999G999G999') AS MAX_LIMIT FROM APP.TPA_MAX_LIMIT_TYPE_MASTER A WHERE A.LIMIT_TYPE_SEQ_ID IN (31,32,33,34,35,36,37,38,39,40,41,42,43,44,46,47,53,48,49) ) ORDER BY SORT_NO ";
    private static final String strOpticalLimitListWhatif = "SELECT LIMIT_TYPE_SEQ_ID,MAX_LIMIT FROM((SELECT A.LIMIT_TYPE_SEQ_ID,A.SORT_NO,TO_CHAR(A.MAX_LIMIT,'FM999G999G999G999G999G999G999G999G999') AS MAX_LIMIT FROM APP.TPA_MAX_LIMIT_TYPE_MASTER A WHERE A.LIMIT_TYPE_SEQ_ID IN (1,2,3,4,5,6,7,8,10,12,13,14,16,18,21,55) ) ORDER BY SORT_NO)"; 
    
    private static final String strDentalLimitListWhatif = "SELECT LIMIT_TYPE_SEQ_ID,MAX_LIMIT FROM((SELECT A.LIMIT_TYPE_SEQ_ID,A.SORT_NO,TO_CHAR(A.MAX_LIMIT,'FM999G999G999G999G999G999G999G999G999') AS MAX_LIMIT FROM APP.TPA_MAX_LIMIT_TYPE_MASTER A WHERE A.LIMIT_TYPE_SEQ_ID IN (1,2,3,5,6,9,10,11,12,14,15,16,17,18,19,20,22,24,29,50,56) ) ORDER BY SORT_NO)";
    
    // after change
    private static final String strDentalProthesis = "SELECT A.INFO_SEQ_ID, A.INFO_DESC FROM PRIC_ADDIT_BENF_GENERAL_DTL A  WHERE A.LABLE_SEQ_ID =3 ORDER BY  A.INFO_SEQ_ID";
    
    private static final String strCongential = "SELECT A.INFO_SEQ_ID, A.INFO_DESC FROM PRIC_ADDIT_BENF_GENERAL_DTL A  WHERE A.LABLE_SEQ_ID =7 ORDER BY  A.INFO_SEQ_ID";
    
    private static final String strOncology = "SELECT A.INFO_SEQ_ID, A.INFO_DESC FROM PRIC_ADDIT_BENF_GENERAL_DTL A  WHERE A.LABLE_SEQ_ID =8 ORDER BY  A.INFO_SEQ_ID";
    
    private static final String strRepartionofMortal  = "SELECT A.INFO_SEQ_ID, A.INFO_DESC FROM PRIC_ADDIT_BENF_GENERAL_DTL A  WHERE A.LABLE_SEQ_ID =9 ORDER BY  A.INFO_SEQ_ID";
    
    private static final String strTerminal  = "SELECT A.INFO_SEQ_ID, A.INFO_DESC FROM PRIC_ADDIT_BENF_GENERAL_DTL A  WHERE A.LABLE_SEQ_ID =10 ORDER BY  A.INFO_SEQ_ID";
    
    private static final String strAlternativeTreatment = "select info_Seq_id, info_desc from APP.PRIC_ADDIT_BENF_GENERAL_DTL a where a.lable_seq_id=95";
    private static final String strReiumbursementLevel  = "select info_Seq_id, info_desc from APP.PRIC_ADDIT_BENF_GENERAL_DTL a where a.lable_seq_id=96";
    private static final String strMaxBenifitListOpLimitIpWhatif = "SELECT LIMIT_TYPE_SEQ_ID,MAX_LIMIT FROM ( SELECT A.LIMIT_TYPE_SEQ_ID,A.SORT_NO,TO_CHAR(A.MAX_LIMIT,'FM999G999G999G999G999G999G999G999G999') AS MAX_LIMIT FROM APP.TPA_MAX_LIMIT_TYPE_MASTER_SPR A WHERE A.LIMIT_TYPE_SEQ_ID IN (31,32,33,34,35,36,37,38,39,40,41,42,43,44,46,47,53,48,49) UNION ALL SELECT A.LIMIT_TYPE_SEQ_ID,A.SORT_NO,A.MAX_LIMIT AS MAX_LIMIT FROM APP.TPA_MAX_LIMIT_TYPE_MASTER_SPR A WHERE A.LIMIT_TYPE_SEQ_ID IN (45,58,59,60))  ORDER BY SORT_NO";
    
    
    public static void getPopulate(String[]identifierList,DataSource dataSource,String jspIdentifier) throws Exception{
         
        try(Connection con=dataSource.getConnection();
        		Statement stm=con.createStatement()){
            if(identifierList!=null&&identifierList.length>0){
            	ServletContext context=VidalCommon.getCurentRequestObject().getServletContext();
               
                for(String strIdentfier:identifierList){
             if( context.getAttribute(strIdentfier)==null){
                    ResultSet rs=stm.executeQuery(getQueryString(strIdentfier));
                   ArrayList<CacheVO> cachedAL=null;
                   if(rs!=null){
                	   cachedAL=new ArrayList<>();
                    while(rs.next()){
                    	CacheVO cacheVO = new CacheVO();
                    	cacheVO.setCacheId(rs.getString(1));
                    	cacheVO.setCacheDesc(rs.getString(2));
                    	cachedAL.add(cacheVO);
                    }
                    context.setAttribute(strIdentfier, cachedAL);
                   }
                    if(rs!=null)rs.close();
                }// for(String strIdentfier:identifierList){
                }
            }
        popIdentifiers.add(jspIdentifier);
        }
    }
    public static void refreshPopulateData(DataSource dataSource,String Identifier) throws Exception{
        
        try(Connection con=dataSource.getConnection();
        		Statement stm=con.createStatement()){
            if(Identifier!=null&&Identifier.length()>0){
            	ServletContext context=VidalCommon.getCurentRequestObject().getServletContext();
                   ResultSet rs=stm.executeQuery(getQueryString(Identifier));
                   ArrayList<CacheVO> cachedAL=null;
                   if(rs!=null){
                	   cachedAL=new ArrayList<>();
                    while(rs.next()){
                    	CacheVO cacheVO = new CacheVO();
                    	cacheVO.setCacheId(rs.getString(1));
                    	cacheVO.setCacheDesc(rs.getString(2));
                    	cachedAL.add(cacheVO);
                    }
                    context.setAttribute(Identifier, cachedAL);
                    if(rs!=null)rs.close();
                }// for(String strIdentfier:identifierList){
            }
        }
    }
    
    private static String getQueryString(String strIdentfier){
        
    	
 
        
        if("renewal".equals(strIdentfier)) {
        	return strenwal;
        }
        
        else if("psllimit".equals(strIdentfier)) 
       {
       	return strpsllimit;   
       }//end of 
        else if("approval".equals(strIdentfier)) 
        {
        	return strapproval;   
        }//end of 
        else if("alternativesession".equals(strIdentfier)) 
        {
        	return stralternativesession;   
        }//end of 
        
         else if("opdSpecialityTypes".equals(strIdentfier)) 
        {
        	return strOPDSPECIALITY;   
        }//end of else if(strIdentifier.equals("opdmedicineSystem"))
        else if("accountopdHead".equals(strIdentfier)) 
        {
        	return strACCOUNT_HEAD_OPDTYPE;   
        }//end of else if(strIdentifier.equals("accountopdHead"))
        else if("resign".equals(strIdentfier)) {
        	return strprobmaticResign;
        }else if("proLocation".equals(strIdentfier)) {
        	return strprobmaticLocation;
        }else if("networkList".equals(strIdentfier))
        {
            return strNetworkList;
        }else if("opticalLimitList".equals(strIdentfier))
        {
            return strOpticalLimitList;
        }else if("clientCodeList".equals(strIdentfier))
        {
            return strClientCodeList;
        }else if("externalmedicalcopay".equals(strIdentfier))
        {
            return strexternalmedicalcopay;
        }
        
        
        
        else if("brokerCodeList".equals(strIdentfier))
        {
            return strBrokerCodeList;
        }else if("maxBenifitListIp".equals(strIdentfier))
        {
            return strMaxBenifitListIp;
        }else if("PassiveWar".equals(strIdentfier))
        {
            return strPassiveWar;
        }
        else if("inpatientlimit".equals(strIdentfier))
        {
            return strinpatientlimit;
        }
        
        else if("outside".equals(strIdentfier))
        {
            return stroutside;
        }
        
        else if("reimbursement".equals(strIdentfier))
        {
            return strreimbursement;
        }
        
        
        
        else if("areaOfCoverList".equals(strIdentfier))
        {
            return strAreaOfCoverList;
        }else if("opCopaypharmacyList".equals(strIdentfier))
        {
            return strOpCopaypharmacyList;
        }else if("opInvestigationList".equals(strIdentfier))
        {
            return strOpInvestigationList;
        }else if("opCopyothersList".equals(strIdentfier))
        {
            return strOpCopyothersList;
        }
        else if("opticalCopayList".equals(strIdentfier))
        {
            return strOpticalCopayList;
        } else if("opticalFrameLimitList".equals(strIdentfier))
        {
            return strOpticalFrameLimitList;
        }
        else if("dentalLimitList".equals(strIdentfier))
        {
            return strDentalLimitList;
        }else if("dentalcopayList".equals(strIdentfier))
        {
            return strDentalcopayList;
        }
        else if("orthodonticsCopay".equals(strIdentfier))
        {
            return strOrthodonticsCopay;
        }    else if("maternityLimitList".equals(strIdentfier))
        {
            return strMaternityLimitList;
        } else if("opCopyalahlihospList".equals(strIdentfier))
        {
            return stropCopyalahlihospList;
        }
        else if("ExternalProsthesisdrop".equals(strIdentfier))
        {
            return strExternalProsthesisdrop;
        }
        
        
        
        else if("opInvestnAlAhliList".equals(strIdentfier))
        {
            return strOpInvestnAlAhliList;
        }else if("opPharmacyAlAhliList".equals(strIdentfier))
        {
            return strOpPharmacyAlAhliList;
        }else if("opothersAlAhliList".equals(strIdentfier))
        {
            return strOpothersAlAhliList;
        }else if("opConsultAlAhliList".equals(strIdentfier))
        {
            return strOpConsultAlAhliList;
        }else if("ipCopayList".equals(strIdentfier))
        {
            return strIpCopayList;
        }else if("iPCopayAtAhliList".equals(strIdentfier))
        {
            return strIPCopayAtAhliList;
        }
       
        else if("preexist".equals(strIdentfier))
        {
            return strpreexist;
        }
        
        
        
        else if("additionalHospitalCoverageList".equals(strIdentfier))
        {
            return strAdditionalHospitalCoverageList;
        }else if("residencyCountryList".equals(strIdentfier))
        {
            return strResidencyCountryList;
        }else if("remiumOutputStructureList".equals(strIdentfier))
        {
            return strRemiumOutputStructureList;
        }else if("maternityPricingList".equals(strIdentfier))
        {
            return strMaternityPricingList;
        }else if("maternityCopayList".equals(strIdentfier))
        {
            return strMaternityCopayList;
        }else if("opCopyconsultnList".equals(strIdentfier))
        {
            return strOpCopyconsultnList;
        }else if("opCopayList".equals(strIdentfier))
        {
            return strOpCopayList ;
        }else if("premiumRefundApproachList".equals(strIdentfier))
        {
            return strPremiumRefundApproachList ;
        }
        else if("inpatientroom".equals(strIdentfier))
        {
            return strinpatientroom ;
        }
        else if("inpatientaccomdation".equals(strIdentfier))
        {
            return strinpatientaccomdation ;
        }
        else if("inpatientcash".equals(strIdentfier))
        {
            return strinpatientcash ;
        }
        else if("Physiotherepy".equals(strIdentfier))
        {
            return strPhysiotherepy ;
        }
        else if("Physiotherepysession".equals(strIdentfier))
        {
            return strPhysiotherepysession ;
        }
        else if("alternativecmplimit".equals(strIdentfier))
        {
            return stralternativecmplimit ;
        }
        else if("internationalasslimit".equals(strIdentfier))
        {
            return strinternationalasslimit ;
        }
        else if("psychiatrylimitt".equals(strIdentfier))
        {
            return strpsychiatrylimitt ;
        }
        else if("psychiatcopayt".equals(strIdentfier))
        {
            return strpsychiatcopayt ;
        }
        else if("vacationlimit".equals(strIdentfier))
        {
            return strvacationlimit ;
        }
        else if("vacation".equals(strIdentfier))
        {
            return strvacation;
        }
        else if("maintance".equals(strIdentfier))
        {
            return strmaintance ;
        }
        else if("hormonelimit".equals(strIdentfier))
        {
            return strhormonelimit ;
        }
        else if("inpatientt".equals(strIdentfier))
        {
            return strinpatientt ;
        }  else if("nursingdrop".equals(strIdentfier))
        {
            return strnursingdrop ;
        }
        else if("Vitamins".equals(strIdentfier))
        {
            return strVitamins ;
        }
        else if("Preandpostnatal".equals(strIdentfier))
        {
            return strPreandpostnatal ;
        }
        
        else if("wellbeingbenfittdrop".equals(strIdentfier))
        {
            return strwellbeingbenfittdrop ;
        }
        else if("workrelateddrop".equals(strIdentfier))
        {
            return strworkrelateddrop ;
        }
        else if("lifediseasecdrop".equals(strIdentfier))
        {
            return strlifediseasecdrop ;
        }
        else if("obesite".equals(strIdentfier))
        {
            return strobesite ;
        }
        else if("hospiceandPalliativedrop".equals(strIdentfier))
        {
            return strhospiceandPalliativedrop ;
        }
        else if("ditecianlimitdrop".equals(strIdentfier))
        {
            return strditecianlimitdrop ;
        }
        else if("hIVandaIDSLimitdrop".equals(strIdentfier))
        {
            return strhIVandaIDSLimitdrop ;
        }
        else if("circumcisionlimitdrop".equals(strIdentfier))
        {
            return strcircumcisionlimitdrop ;
        }
        else if("compassionatevisitdrop".equals(strIdentfier))
        {
            return strcompassionatevisitdrop ;
        }
        else if("externalmedicaldrop".equals(strIdentfier))
        {
            return strexternalmedicaldrop;
        }  else if("healthscreenlimitdrop".equals(strIdentfier))
        {
            return strhealthscreenlimitdrop ;
        }
        else if("healthsessions".equals(strIdentfier))
        {
            return strhealthsessions ;
        }
        else if("healthscreencopay".equals(strIdentfier))
        {
            return strhealthscreencopay ;
        }
        else if("pregnancy".equals(strIdentfier))
        {
            return strpregnancy ;
        }
        else if("deductiblecoinsurance".equals(strIdentfier))
        {
            return strdeductiblecoinsurance ;
        }
        else if("lifeThreateningdiease".equals(strIdentfier))
        {
            return strlifeThreateningdiease ;
        }
        else if("workrelateddrop1".equals(strIdentfier))
        {
            return strworkrelateddrop1 ;
        }
        else if("alternativecopay".equals(strIdentfier))
        {
            return stralternativecopay;
        }
        else if("organlimit".equals(strIdentfier))
        {
            return strorganlimit;
        }
        else if("currency".equals(strIdentfier))
        {
            return strcurrency;
        }
        else if("parentacmdation".equals(strIdentfier))
        {
        	
            return strparentacmdation;
        } else if("networkListFactor".equals(strIdentfier))
        {
        	
            return strnetworkListFactor;
        }
        else if("maternityCopayListWhatif".equals(strIdentfier))
        {
        	
            return strMaternityCopayListWhatis;
        } else if("maxBenifitListIpWhatif".equals(strIdentfier))
        {
        	
            return strMaxBenifitListIpWhatif;
        }else if("opticalLimitListWhatif".equals(strIdentfier))
        {
        	
            return strOpticalLimitListWhatif;
        }
        else if("opticalLimitListWhatif".equals(strIdentfier))
        {
        	
            return strOpticalLimitListWhatif;
        } else if("dentalLimitListWhatif".equals(strIdentfier))
        {
        	
            return strDentalLimitListWhatif;
        }
        
        else if("dentalprothis".equals(strIdentfier))
        {
        	
            return strDentalProthesis;
        }
        
        else if("congtal".equals(strIdentfier))
        {
        	
            return strCongential;
        }
        else if("oncology".equals(strIdentfier))
        {
        	
            return strOncology;
        }
        
        else if("repatriation".equals(strIdentfier))
        {
        	
            return strRepartionofMortal;
        }
        else if("terminal".equals(strIdentfier))
        {
        	
            return strTerminal;
        }
        else if("alternativeTreatment".equals(strIdentfier))
        {
        	
            return strAlternativeTreatment;
        }
        else if("reimbursmentLevel".equals(strIdentfier))
        {
        	
            return strReiumbursementLevel;
        } else if("maxBenifitListOpLimitIp".equals(strIdentfier))
        {
        	
            return strMaxBenifitListOpLimitIp;
        }else if("maxBenifitListOpLimitIpWhatif".equals(strIdentfier))
        {
        	
            return strMaxBenifitListOpLimitIpWhatif;
        }
        
        
        
        
        
        else {
        	throw new VidalException("Query identifier not found");//Query identifier not found
        }
    }
    
    
    private PopulateFields() {
    }
    
     
    public static boolean isPopulated(String identifier){
        return popIdentifiers.contains(identifier);
    }
 private final static ArrayList<String> popIdentifiers=new ArrayList<>();
}


package com.vidal.common.reports;
import java.util.Properties;

import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.support.PropertiesLoaderUtils;
public class TTKPropertiesReader {


	
	 private static Properties prop = null; //Properties
	/**
	 * This method takes the property name and returns the value of it in the properties file.
	 * @param strPropertyName String The property name
	 * @return strPropertyValue String The property value
	 */    
	public static String getPropertyValue(String strPropertyName)
	{
		String strPropertyValue="";
		try
		{
		    if (prop == null)
		    {
		        prop=new Properties();
		        prop = PropertiesLoaderUtils.loadProperties(new ClassPathResource("resources/files/vidal.properties"));
			  /*  prop.load(new ClassPathResource("resources/files/vidal.properties"));*/
			}
			strPropertyValue  = (String)prop.get(strPropertyName);
		}// end of try
		
		catch(Exception exp){
			exp.printStackTrace();
		}
		return strPropertyValue;
	}//end of getPropertyValue(String strPropertyName)
	
	
}

/**
 * 
 */
package com.vidal.common.annotation.validator;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import org.apache.commons.beanutils.BeanUtils;

import com.vidal.common.annotation.Required;

/**
 * @author Nagababu
 *
 */
public class RequiredValidator implements ConstraintValidator<Required, Object>{
	
	private Required required;
	@Override
	public void initialize(Required required) {
		this.required=required;
	}

	@Override
	public boolean isValid(Object cmdObject, ConstraintValidatorContext context) {
		boolean status=true;
		try{
		
			String fieldName=required.fieldName();
			String label=required.label();
			String message=required.message();
		String value=	BeanUtils.getProperty(cmdObject, fieldName);
		if(value==null||value.trim().length()<1){
		String msg;
		if(message!=null&&message.length()>0) msg=message;
		else if(label==null||label.length()<1){
			msg=fieldName+" is rquired";
		}else msg=label+" is rquired";
		context.disableDefaultConstraintViolation();
		context.buildConstraintViolationWithTemplate(msg).addConstraintViolation();
		return false;
		}
		
		
		}catch(Exception exception){
			context.disableDefaultConstraintViolation();
			context.buildConstraintViolationWithTemplate("Unkown Error Occurred Please Contact Administrator").addConstraintViolation();

			exception.printStackTrace();
			status=false;
		}
		return status;
	}


}

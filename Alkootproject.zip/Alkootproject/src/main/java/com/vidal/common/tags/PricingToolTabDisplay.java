package com.vidal.common.tags;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.TagSupport;

import org.apache.log4j.Logger;

import com.vidal.command.menu.Link;
import com.vidal.command.usermanagement.UserSecurityProfile;
import com.vidal.common.security.SecurityProfile;
public class PricingToolTabDisplay extends TagSupport{
	private static final long serialVersionUID = 1L;
	private static Logger log = Logger.getLogger(PricingToolTabDisplay.class);
	  public int doStartTag() throws JspException{
		  HttpServletRequest request=(HttpServletRequest)pageContext.getRequest();
		  JspWriter out = pageContext.getOut();//Writer object to write the file
		  try{
			  out.print("<section class='content'>");
			  out.print("<div class='container-fluid'>");
			  out.print(" <div class=\"menu-bar\">");
			  out.print(" <div class='nav-flex d-flex justify-content-between align-items-center mt-1 mb-4'>");
			  out.print("<div class='vd-tab-nav'>");
			  out.print(" <ul class='nav nav-tabs'>");
			 
			 	UserSecurityProfile userAccessSecurityProfile=(UserSecurityProfile)request.getSession().getAttribute("userAccessSecurityProfile");
			 	String renevalFlag = (String) request.getSession().getAttribute("renevalFlag");
			    String refNo=(String)request.getSession().getAttribute("pricingRefNo");
			    
			    System.out.println("test.....refNo..."+refNo);
			 	
                SecurityProfile spx=null;
                if(userAccessSecurityProfile!=null && userAccessSecurityProfile.getSecurityProfile()!=null){
              	  spx = userAccessSecurityProfile.getSecurityProfile();
                }
                
                ArrayList alSubLinks = new ArrayList();
                alSubLinks = spx.getTabs();
                
                if(alSubLinks != null && alSubLinks.size() > 0){
                	for(int j=0; j < alSubLinks.size(); j++)
					{
                		  Link subLink= (Link)alSubLinks.get(j);
                		  if(spx.isActiveTab(subLink.getName()))
							{
                			 
                			  out.print("<li class='nav-item'>");
                			  out.print("<a class='nav-link active' href=\"#\">"); 
                			   out.print(subLink.getName());
                			  out.print("</a>"); 
                			  out.print("</li>");									 					   
							}else {
								  out.print("<li class='nav-item'>");
	                			  out.print("<a class='nav-link ' href=\"javascript:modifyLinks('Tab','"+subLink.getName()+"')\">"); 
	                			   out.print(subLink.getName());
	                			  out.print("</a>"); 
	                			  out.print("</li>");
								}
					}
                	
                }
                out.print("</ul>"); 
                out.print("</div>"); 
                
                out.print("<div class=\"request-status\">");
                
                
                out.print("<span class=\"c-number\">"+request.getSession().getAttribute("pricingRefNo")+"&nbsp;</span>");
                
                if(!refNo.equals("")) {
                if(renevalFlag.equals("Y")) {	
             
                out.print("<span class=\"badge vd-badge-inprogress\">Renewal</span>");
                }else {
                 out.print("<span class=\"badge vd-badge-approved\">New</span>");
                }
                }
                out.print("</div>");
                out.print("</div>");
                out.print("</div>"); 
                out.print("</div>"); 
               
//                out.print("</section>");               	  
	        } catch(Exception exp)
		    {
	            exp.printStackTrace();
	            log.debug("error occured in ClaimsDetails Tag Library!!!!! ");
	        }//end of catch block
		  
		  return SKIP_BODY;
	  }
	  
	  public int doEndTag() throws JspException {
		    return EVAL_PAGE;//to process the rest of the page
		}//end doEndTag()

}

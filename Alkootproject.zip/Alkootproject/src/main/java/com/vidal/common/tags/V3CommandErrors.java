package com.vidal.common.tags;


import java.util.Collection;
import java.util.HashMap;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.TagSupport;

import org.apache.log4j.Logger;


public class V3CommandErrors extends TagSupport {

	  /**
	 * 
	 */
	private static final long serialVersionUID = 4647868429193719820L;
	private static Logger log = Logger.getLogger( V3CommandErrors.class );
    String name = "";
    
    public void setName(String name) {
        this.name = name;
    }//end of setName(String name)
    
   
    public int doStartTag() throws JspException {
		try
		{
			
			 JspWriter out=pageContext.getOut();
			 
			 @SuppressWarnings("unchecked")
			HashMap<String, String> hmFieldErrors=( HashMap<String, String>)pageContext.getRequest().getAttribute("V3FE-"+name);
			 if(hmFieldErrors!=null&&hmFieldErrors.size()>0){
				 out.print("<ol class=\"error-msg\" style=\"font-size: 14px;\">");
				 Collection<String> errorMsg=hmFieldErrors.values();
				 
				 for(String strMsg:errorMsg){
					out.print("<li>"); 
					out.print(strMsg); 
					out.print("</li>"); 
				 }
				 out.print("</ol>");
			 }
			 
		}
		catch(Exception exp)
		{
			exp.printStackTrace();
			log.debug("error occured in V3CommandErrors !!!!! ");
		}//end of catch block
		return SKIP_BODY;
	}//end of doStartTag()


	public int doEndTag() throws JspException {
		return EVAL_PAGE;//to process the rest of the page
	}//end doEndTag()
}//end of V3CommandErrors

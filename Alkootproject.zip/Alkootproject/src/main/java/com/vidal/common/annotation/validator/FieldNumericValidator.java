package com.vidal.common.annotation.validator;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import org.springframework.beans.BeanWrapperImpl;

import com.vidal.common.annotation.FieldNumeric;

public class FieldNumericValidator implements ConstraintValidator<FieldNumeric,Object>{

	private String agefield;
	@Override
	public void initialize(FieldNumeric constraintAnnotation) {
		// TODO Auto-generated method stub
		this.agefield=constraintAnnotation.agefield();
		
	}
	@Override
	public boolean isValid(Object value, ConstraintValidatorContext ctx) {
		// TODO Auto-generated method stub
		boolean status=false;
		Object field1 = new BeanWrapperImpl(value).getPropertyValue(agefield);
		if(field1 !=null && field1 !="") {
			String val=field1.toString();
			status=val.matches("^[a-zA-Z0-9]{1}[a-zA-Z0-9\\s\\-\\/\\\\]*$");	
		}
		return status;
	}

	

}

package com.vidal.common.tags;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.TagSupport;

import org.apache.log4j.Logger;

import com.vidal.command.pricing.InsPricingVO;

public class InputScreenGrid extends TagSupport{
	private static final long serialVersionUID = 1L;
	private static Logger log = Logger.getLogger(InputScreenGrid.class);
	  public int doStartTag() throws JspException{
		  HttpServletRequest request=(HttpServletRequest)pageContext.getRequest();
		  JspWriter out = pageContext.getOut();//Writer object to write the file
		  ArrayList<InsPricingVO> alprofileIncomeList=null;
		  ArrayList<InsPricingVO> profileNationalityList = null;
		  String minMatLives="";
		  String maxMatLives="";
		  
		  int copyobj = 0;
		  try{
			  
			  System.out.println("..cencer data copy ..."+request.getSession().getAttribute("editflag"));
			  System.out.println(" reneval flag"+request.getSession().getAttribute("renevalFlag"));
			 
			  
			  alprofileIncomeList = (ArrayList<InsPricingVO>) request.getSession().getAttribute("profileBenefitList");		
			  String renevalFlag = (String) request.getSession().getAttribute("renevalFlag");
			 
			/*  System.out.println("alprofileIncomeList..."+alprofileIncomeList);*/
			  
			  profileNationalityList = (ArrayList<InsPricingVO>) request.getSession().getAttribute("profileNationalityList");
			  String  sumTotalLives= (String) request.getSession().getAttribute("sumTotalLives");
			  String  sumTotalLivesMale= (String) request.getSession().getAttribute("sumTotalLivesMale") !=null ? (String) request.getSession().getAttribute("sumTotalLivesMale"):"";
			  String  sumTotalLivesFemale= (String) request.getSession().getAttribute("sumTotalLivesFemale") !=null ?(String) request.getSession().getAttribute("sumTotalLivesFemale"):"";
			  String  sumTotalLivesMaleUserPer= (String) request.getSession().getAttribute("sumTotalLivesMaleUserPer") !=null ?(String) request.getSession().getAttribute("sumTotalLivesMaleUserPer"):"50";
			  String  sumTotalLivesFemaleUserPer= (String) request.getSession().getAttribute("sumTotalLivesFemaleUserPer") !=null ?(String) request.getSession().getAttribute("sumTotalLivesFemaleUserPer"):"50";
			  
			  String  sumTotalLivesMaternity = (String) request.getSession().getAttribute("sumTotalLivesMaternity"); 
			  String  sumTotalLivesOptical	= (String) request.getSession().getAttribute("sumTotalLivesOptical");
			  String  sumTotalLivesDental	= (String) request.getSession().getAttribute("sumTotalLivesDental"); 
			  String  sumNationalityLives	= (String) request.getSession().getAttribute("sumNationalityLives"); 
			
			  String  totalNoOfLives	= (String) request.getSession().getAttribute("totalNoOfLives"); 
			 
			  String  TotalMaternityLives	= (String) request.getSession().getAttribute("TotalMaternityLives");
			 
			  
			     if((String) request.getSession().getAttribute("minMaternityLives") != null){
				  minMatLives=(String) request.getSession().getAttribute("minMaternityLives"); 
				  maxMatLives=(String) request.getSession().getAttribute("maxMaternityLives"); 
			     }
				/* if(minMatLives.equalsIgnoreCase(null)){
					 minMatLives="";
				 }
				 if(maxMatLives.equalsIgnoreCase(null)){
					 maxMatLives="";
				 }*/
			 /* System.out.println("minMatLives...."+minMatLives);
			  System.out.println("maxMatLives..."+maxMatLives);*/
			 
			  
			String clientName = (String) request.getSession().getAttribute("clientName");  
			  						  	
			
		
			  ArrayList<String> al=new ArrayList<>();
			  ArrayList<InsPricingVO> al1=new ArrayList<>();
			  ArrayList<InsPricingVO> al2=new ArrayList<>();
			  ArrayList<InsPricingVO> al3=new ArrayList<>();
			  ArrayList<InsPricingVO> al4=new ArrayList<>();
			  ArrayList<InsPricingVO> al5=new ArrayList<>();
			  ArrayList<InsPricingVO> al6=new ArrayList<>();
			  
			  out.print(" <div class=\"covered-member mt-3\">");
			  out.print("<ul class=\"tb-legends\">");
			  out.print(" <li class=\"lgd-1\">");
			  out.print(clientName);
			  out.print("</li>");
			  out.print("<li class=\"lgd-2\">");
			  out.print("OVERALL PORTFOLIO DISTRIBUTION");
			  out.print("</li>");
			  out.print("</ul>");
			  
			 /* out.print("<span style=\"margin-left: 20%;\"> <b>Covered members by age band and gender</b></span>");*/
			  out.print("<div class=\"d-flex justify-content-between align-items-center\">");
			  out.print("<h6 class=\"card-title\">");
			  out.print("Covered members by age band and gender");
			  out.print("</h6>");
			 /* out.print("<h6 class=\"card-title\">");
			  out.print("Total covered members");
			  out.print("</h6>");*/
			  out.print("<p class=\"ct-sub\">");
			  out.print("Total covered members: ");
			/*  out.print("<strong>");*/
			  out.print(sumTotalLives);
			/*  out.print("</strong>");*/			  
			  out.print("</p>");
			  out.print("</div>");
			  
		  	
			  //table grid div
			  
			  out.print("<div class=\"vd-grid-style-basic\">");
			  out.print("<table class=\"table table-basic modal-table mb-0\">");
			  out.print("<thead>");
			  out.print("<tr>");			 
			  out.print("<th></th>");		
			  out.print("<th>Male</th>");		
			  out.print("<th colspan=\"2\"></th>");		
			  out.print("<th>Female</th>");		
			  out.print("<th colspan=\"2\"></th>");					 								
			  out.print("</tr>");
			  			  
			  out.print("</thead>");
			  
			  out.print("<tbody>");
			  
			 
			 
			  
			  if(alprofileIncomeList !=null) {
			/*	  System.out.println("alprofileIncomeList.size()..."+alprofileIncomeList.size());*/
			  
			  for(int i=0;i< alprofileIncomeList.size();i++) {
				  
				  if((alprofileIncomeList.get(i).getGndrdesc1().equals("Male")) && (alprofileIncomeList.get(i).getBenfdesc1().equalsIgnoreCase("Inpatient And Outpatient")) ) {
				  al.add(alprofileIncomeList.get(i).getAge_range1());
				 /*  System.out.println("male..."+i+"......"+alprofileIncomeList.get(i).getBenf_typeseqid1());*/
				  
				  }
				  else if((alprofileIncomeList.get(i).getGndrdesc1().equals("Female")) && (alprofileIncomeList.get(i).getBenfdesc1().equalsIgnoreCase("Inpatient And Outpatient")) ) {
				 
				  
					
				/*	  System.out.println("Female..."+i+"......"+alprofileIncomeList.get(i).getBenf_typeseqid1());*/
					  InsPricingVO insvo=new InsPricingVO();
					  insvo.setGndrdesc1_f(alprofileIncomeList.get(i).getGndrdesc1());
					  insvo.setGndrtypeseqid1_f(alprofileIncomeList.get(i).getGndrtypeseqid1());
					  insvo.setOvrprtflio_dstr1_f(alprofileIncomeList.get(i).getOvrprtflio_dstr1());
					  insvo.setAge_range1_f(alprofileIncomeList.get(i).getAge_range1());
				      insvo.setBenf_typeseqid1_f(alprofileIncomeList.get(i).getBenf_typeseqid1());
					  insvo.setAge_rngseqid1_f(alprofileIncomeList.get(i).getAge_rngseqid1());
					  insvo.setBenf_lives_seq_id1_f(alprofileIncomeList.get(i).getBenf_lives_seq_id1());
					  insvo.setOvrprtflio_dstr1_f(alprofileIncomeList.get(i).getOvrprtflio_dstr1());
					  insvo.setOvrprtflio_dstr2_f(alprofileIncomeList.get(i).getOvrprtflio_dstr2());
					  
					  insvo.setTotalCoverdLives1_f(alprofileIncomeList.get(i).getTotalCoverdLives1());
					  al1.add(insvo);
					 
					  
				  }else if(alprofileIncomeList.get(i).getBenfdesc1().equalsIgnoreCase("Maternity")){
					 /* System.out.println("maternity....");*/
					  InsPricingVO insvoMeternityVo=new InsPricingVO();									  
					  insvoMeternityVo.setGndrdesc1_f(alprofileIncomeList.get(i).getGndrdesc1());
					  insvoMeternityVo.setGndrtypeseqid1_f(alprofileIncomeList.get(i).getGndrtypeseqid1());
					  insvoMeternityVo.setOvrprtflio_dstr1_f(alprofileIncomeList.get(i).getOvrprtflio_dstr1());
					  insvoMeternityVo.setAge_range1_f(alprofileIncomeList.get(i).getAge_range1());
					  insvoMeternityVo.setBenf_typeseqid1_f(alprofileIncomeList.get(i).getBenf_typeseqid1());
					  insvoMeternityVo.setAge_rngseqid1_f(alprofileIncomeList.get(i).getAge_rngseqid1());
					  insvoMeternityVo.setBenf_lives_seq_id1_f(alprofileIncomeList.get(i).getBenf_lives_seq_id1());
					  insvoMeternityVo.setOvrprtflio_dstr1_f(alprofileIncomeList.get(i).getOvrprtflio_dstr1());
					  insvoMeternityVo.setOvrprtflio_dstr2_f(alprofileIncomeList.get(i).getOvrprtflio_dstr2());
					  insvoMeternityVo.setTotalCoverdLives1_f(alprofileIncomeList.get(i).getTotalCoverdLives1());
					  al2.add(insvoMeternityVo);
					
				  }else if((alprofileIncomeList.get(i).getGndrdesc1().equals("Male")) && (alprofileIncomeList.get(i).getBenfdesc1().equalsIgnoreCase("Dental"))){
					  
					  InsPricingVO insvoDentalVo=new InsPricingVO();									  
					  insvoDentalVo.setGndrdesc1_f(alprofileIncomeList.get(i).getGndrdesc1());
					  insvoDentalVo.setGndrtypeseqid1_f(alprofileIncomeList.get(i).getGndrtypeseqid1());
					  insvoDentalVo.setOvrprtflio_dstr1_f(alprofileIncomeList.get(i).getOvrprtflio_dstr1());
					  insvoDentalVo.setAge_range1_f(alprofileIncomeList.get(i).getAge_range1());
					  insvoDentalVo.setBenf_typeseqid1_f(alprofileIncomeList.get(i).getBenf_typeseqid1());
					  insvoDentalVo.setAge_rngseqid1_f(alprofileIncomeList.get(i).getAge_rngseqid1());
					  insvoDentalVo.setBenf_lives_seq_id1_f(alprofileIncomeList.get(i).getBenf_lives_seq_id1());
					  insvoDentalVo.setOvrprtflio_dstr1_f(alprofileIncomeList.get(i).getOvrprtflio_dstr1());
					  insvoDentalVo.setOvrprtflio_dstr2_f(alprofileIncomeList.get(i).getOvrprtflio_dstr2());
					  insvoDentalVo.setTotalCoverdLives1_f(alprofileIncomeList.get(i).getTotalCoverdLives1());
					  al3.add(insvoDentalVo);
					  
				  }else if((alprofileIncomeList.get(i).getGndrdesc1().equals("Female")) && (alprofileIncomeList.get(i).getBenfdesc1().equalsIgnoreCase("Dental"))){
					  
					  InsPricingVO insvoDentalVo1=new InsPricingVO();									  
					  insvoDentalVo1.setGndrdesc1_f(alprofileIncomeList.get(i).getGndrdesc1());
					  insvoDentalVo1.setGndrtypeseqid1_f(alprofileIncomeList.get(i).getGndrtypeseqid1());
					  insvoDentalVo1.setOvrprtflio_dstr1_f(alprofileIncomeList.get(i).getOvrprtflio_dstr1());
					  insvoDentalVo1.setAge_range1_f(alprofileIncomeList.get(i).getAge_range1());
					  insvoDentalVo1.setBenf_typeseqid1_f(alprofileIncomeList.get(i).getBenf_typeseqid1());
					  insvoDentalVo1.setAge_rngseqid1_f(alprofileIncomeList.get(i).getAge_rngseqid1());
					  insvoDentalVo1.setBenf_lives_seq_id1_f(alprofileIncomeList.get(i).getBenf_lives_seq_id1());
					  insvoDentalVo1.setOvrprtflio_dstr1_f(alprofileIncomeList.get(i).getOvrprtflio_dstr1());
					  insvoDentalVo1.setOvrprtflio_dstr2_f(alprofileIncomeList.get(i).getOvrprtflio_dstr2());
					  insvoDentalVo1.setTotalCoverdLives1_f(alprofileIncomeList.get(i).getTotalCoverdLives1());
					  al5.add(insvoDentalVo1);
					  
				  }
				  
				  else if((alprofileIncomeList.get(i).getGndrdesc1().equals("Male")) && (alprofileIncomeList.get(i).getBenfdesc1().equalsIgnoreCase("Optical"))){
					  
					  InsPricingVO insvoOpticalVo=new InsPricingVO();									  
					  insvoOpticalVo.setGndrdesc1_f(alprofileIncomeList.get(i).getGndrdesc1());
					  insvoOpticalVo.setGndrtypeseqid1_f(alprofileIncomeList.get(i).getGndrtypeseqid1());
					  insvoOpticalVo.setOvrprtflio_dstr1_f(alprofileIncomeList.get(i).getOvrprtflio_dstr1());
					  insvoOpticalVo.setAge_range1_f(alprofileIncomeList.get(i).getAge_range1());
					  insvoOpticalVo.setBenf_typeseqid1_f(alprofileIncomeList.get(i).getBenf_typeseqid1());
					  insvoOpticalVo.setAge_rngseqid1_f(alprofileIncomeList.get(i).getAge_rngseqid1());
					  insvoOpticalVo.setBenf_lives_seq_id1_f(alprofileIncomeList.get(i).getBenf_lives_seq_id1());
					  insvoOpticalVo.setOvrprtflio_dstr1_f(alprofileIncomeList.get(i).getOvrprtflio_dstr1());
					  insvoOpticalVo.setOvrprtflio_dstr2_f(alprofileIncomeList.get(i).getOvrprtflio_dstr2());
					  insvoOpticalVo.setTotalCoverdLives1_f(alprofileIncomeList.get(i).getTotalCoverdLives1());
					  al4.add(insvoOpticalVo);
					  
				  } else if((alprofileIncomeList.get(i).getGndrdesc1().equals("Female")) && (alprofileIncomeList.get(i).getBenfdesc1().equalsIgnoreCase("Optical"))){
					  
					  InsPricingVO insvoOpticalVo1=new InsPricingVO();									  
					  insvoOpticalVo1.setGndrdesc1_f(alprofileIncomeList.get(i).getGndrdesc1());
					  insvoOpticalVo1.setGndrtypeseqid1_f(alprofileIncomeList.get(i).getGndrtypeseqid1());
					  insvoOpticalVo1.setOvrprtflio_dstr1_f(alprofileIncomeList.get(i).getOvrprtflio_dstr1());
					  insvoOpticalVo1.setAge_range1_f(alprofileIncomeList.get(i).getAge_range1());
					  insvoOpticalVo1.setBenf_typeseqid1_f(alprofileIncomeList.get(i).getBenf_typeseqid1());
					  insvoOpticalVo1.setAge_rngseqid1_f(alprofileIncomeList.get(i).getAge_rngseqid1());
					  insvoOpticalVo1.setBenf_lives_seq_id1_f(alprofileIncomeList.get(i).getBenf_lives_seq_id1());
					  insvoOpticalVo1.setOvrprtflio_dstr1_f(alprofileIncomeList.get(i).getOvrprtflio_dstr1());
					  insvoOpticalVo1.setOvrprtflio_dstr2_f(alprofileIncomeList.get(i).getOvrprtflio_dstr2());
					  insvoOpticalVo1.setTotalCoverdLives1_f(alprofileIncomeList.get(i).getTotalCoverdLives1());
					  al6.add(insvoOpticalVo1);
					  
				  }
				 
			  }
		
		
			  
			  }
			  
			 for(int i=0;i<9;i++) {					
				 
				
					 out.print("<tr>");
					 out.print("<td>");			 
			         out.print(al.get(i));
					 out.print("</td>");					
			
					 out.print("<td>");
					 
					 out.print("<div class=\"vd-form-control\">");					 
					 out.print("<input type=\"text\"  name=\"totalCoverdLives\" id=\"benf_typeseqid"+alprofileIncomeList.get(i).getBenf_typeseqid1()+"["+copyobj+"]\" class=\"form-control readonlyclass\" onchange=\"isTotalLives(this,"+copyobj+","+ alprofileIncomeList.get(i).getBenf_typeseqid1()+");calCulatePer();\" onkeypress=\"return isNumberKey(event);\"  value=\""+alprofileIncomeList.get(i).getTotalCoverdLives1()+"\" >");										 					 					 					 
					 out.print("</div>");					 
					 out.print("<input type=\"hidden\" name=\"gndrdesc\" value=\""+alprofileIncomeList.get(i).getGndrdesc1()+"\"> ");
					 out.print("<input type=\"hidden\" name=\"age_range\" value=\""+ alprofileIncomeList.get(i).getAge_range1()+"\"> ");
					 out.print("<input type=\"hidden\" name=\"ovrprtflio_dstr\" value=\""+alprofileIncomeList.get(i).getOvrprtflio_dstr1()+"\">");
					 out.print("<input type=\"hidden\" name=\"benf_typeseqid\" value=\""+alprofileIncomeList.get(i).getBenf_typeseqid1()+"\">");
					 out.print("<input type=\"hidden\" name=\"gndrtypeseqid\" value=\""+alprofileIncomeList.get(i).getGndrtypeseqid1()+"\"> "); 
					 out.print("<input type=\"hidden\" name=\"age_rngseqid\" value=\""+alprofileIncomeList.get(i).getAge_rngseqid1()+"\"> ");
					 out.print("<input type=\"hidden\" id=\"userPerMalehdn["+i+"]\" name=\"ovrprtflio_dstrUser\" value=\""+alprofileIncomeList.get(i).getOvrprtflio_dstr2()+"\"> ");
					 if(alprofileIncomeList.get(i).getBenf_lives_seq_id1() !=null) {
						 out.print("<input type=\"hidden\" name=\"benf_lives_seq_id\" value=\""+alprofileIncomeList.get(i).getBenf_lives_seq_id1()+"\"> ");
					 }else {
						 out.print("<input type=\"hidden\" name=\"benf_lives_seq_id\" value=\" \">");
					 }
					
					 out.print("<input type=\"hidden\" name=\"benfdesc\" value=\"Inpatient And Outpatient\"> ");					 
					 out.print("</td>");				
					 out.print("<td  id=\"userPerMale["+i+"]\" class=\"highlight1\">");
					 out.print(alprofileIncomeList.get(i).getOvrprtflio_dstr2() +"%");
					 out.print("</td>");
					 out.print(" <td class=\"highlight2\">");
					 out.print(alprofileIncomeList.get(i).getOvrprtflio_dstr1() +"%");
					 out.print("</td>");								
					 out.print("<td>");
					 out.print("<div class=\"vd-form-control\">");					 
					 out.print("<input type=\"text\" name=\"totalCoverdLives\" id=\"benf_typeseqidFe"+al1.get(i).getBenf_typeseqid1_f()+"["+copyobj+"]\" class=\"form-control readonlyclass totalLiveFemaleClass\"  onchange=\"isTotalLivesFemale(this,"+copyobj+","+ al1.get(i).getBenf_typeseqid1_f()+");calCulatePer();\" onkeypress=\"return isNumberKey(event);\" value=\""+al1.get(i).getTotalCoverdLives1_f()+"\" >");					   					 
					  
					     out.print("<input type=\"hidden\" name=\"gndrdesc\" value=\""+al1.get(i).getGndrdesc1_f()+"\"> ");
						 out.print("<input type=\"hidden\" name=\"age_range\" value=\""+al1.get(i).getAge_range1_f()+"\"> ");
						 out.print("<input type=\"hidden\" name=\"ovrprtflio_dstr\" value=\""+al1.get(i).getOvrprtflio_dstr1_f()+"\">");
						 out.print("<input type=\"hidden\" name=\"benf_typeseqid\" value=\""+al1.get(i).getBenf_typeseqid1_f()+"\">");
						 out.print("<input type=\"hidden\" name=\"gndrtypeseqid\"  value=\""+al1.get(i).getGndrtypeseqid1_f()+"\"> ");
						 out.print("<input type=\"hidden\" name=\"age_rngseqid\" class=\"validateClassFemale\" value=\""+al1.get(i).getAge_rngseqid1_f()+"\"> ");
						
						 out.print("<input type=\"hidden\" id=\"userPerFemalehdn["+i+"]\" name=\"ovrprtflio_dstrUser\" value=\""+al1.get(i).getOvrprtflio_dstr2_f()+"\"> ");
						
						 if(al1.get(i).getBenf_lives_seq_id1_f() !=null) {
							 out.print("<input type=\"hidden\" name=\"benf_lives_seq_id\" value=\""+al1.get(i).getBenf_lives_seq_id1_f()+"\"> "); 
						 }else {
							 out.print("<input type=\"hidden\" name=\"benf_lives_seq_id\" value=\" \"> ");
						 }
												 
						 out.print("<input type=\"hidden\" name=\"benfdesc\" value=\"Inpatient And Outpatient\"> ");
						 
					 out.print("</div>");
					 out.print("</td>");
					
					 out.print(" <td id=\"userPerFemale["+i+"]\" class=\"highlight1\">");
					 out.print(al1.get(i).getOvrprtflio_dstr2_f()+"%");
					 out.print("</td>");
					 
					
					 out.print("<td class=\"highlight2\">");
					 out.print(al1.get(i).getOvrprtflio_dstr1_f()+"%");
					 out.print("</td>");
					  out.print("</tr>");
					
					  copyobj ++;
			 }
			
							
			  out.print(" </tbody>");			  
			 out.print("</table>");
			 
			 int dentalCount = 0;
			 
			 for(int i=0;i< al3.size();i++) {	
				 out.print("<div id=\"dentalDivId["+dentalCount+"]\">");
				 out.print(" <input type=\"hidden\" name=\"totalCoverdLives\" id=\"dentalTotalLivesCoverdMale["+dentalCount+"]\" class=\"form-control\"  value=\""+al3.get(i).getTotalCoverdLives1_f()+"\" >");
				 out.print("<input type=\"hidden\" name=\"gndrdesc\" value=\""+al3.get(i).getGndrdesc1_f()+"\"> ");
				 out.print("<input type=\"hidden\" name=\"age_range\" value=\""+al3.get(i).getAge_range1_f()+"\"> ");
				 out.print("<input type=\"hidden\" name=\"ovrprtflio_dstr\" value=\""+al3.get(i).getOvrprtflio_dstr1_f()+"\">");
				 out.print("<input type=\"hidden\" name=\"benf_typeseqid\" value=\""+al3.get(i).getBenf_typeseqid1_f()+"\">");
				 out.print("<input type=\"hidden\" name=\"gndrtypeseqid\" value=\""+al3.get(i).getGndrtypeseqid1_f()+"\"> ");
				 out.print("<input type=\"hidden\" name=\"age_rngseqid\" value=\""+al3.get(i).getAge_rngseqid1_f()+"\"> ");	
				 out.print("<input type=\"hidden\" id=\"dentalUserMale["+dentalCount+"]\" name=\"ovrprtflio_dstrUser\" value=\""+al3.get(i).getOvrprtflio_dstr2_f()+"\"> ");
				 if(al3.get(i).getBenf_lives_seq_id1_f() !=null) {
					 out.print("<input type=\"hidden\" name=\"benf_lives_seq_id\" value=\""+al3.get(i).getBenf_lives_seq_id1_f()+"\"> ");
					 }else {
						 out.print("<input type=\"hidden\" name=\"benf_lives_seq_id\" value=\" \"> ");
					 }
					 out.print("<input type=\"hidden\" name=\"benfdesc\" value=\"Dental\"> ");
				 out.print("</div>");
				 dentalCount ++;				 
			 }
			 
          int dentalCountFe = 0;
			 
			 for(int i=0;i< al5.size();i++) {	
				 out.print("<div id=\"dentalDivIdFe["+dentalCountFe+"]\">");
				 out.print(" <input type=\"hidden\" name=\"totalCoverdLives\"  id=\"dentalTotalLivesCoverdFemale["+dentalCountFe+"]\"  class=\"form-control\"  value=\""+al5.get(i).getTotalCoverdLives1_f()+"\" >");
				 out.print("<input type=\"hidden\" name=\"gndrdesc\" value=\""+al5.get(i).getGndrdesc1_f()+"\"> ");
				 out.print("<input type=\"hidden\" name=\"age_range\" value=\""+al5.get(i).getAge_range1_f()+"\"> ");
				 out.print("<input type=\"hidden\" name=\"ovrprtflio_dstr\" value=\""+al5.get(i).getOvrprtflio_dstr1_f()+"\">");
				 out.print("<input type=\"hidden\" name=\"benf_typeseqid\" value=\""+al5.get(i).getBenf_typeseqid1_f()+"\">");
				 out.print("<input type=\"hidden\" name=\"gndrtypeseqid\" value=\""+al5.get(i).getGndrtypeseqid1_f()+"\"> ");
				 out.print("<input type=\"hidden\" name=\"age_rngseqid\" value=\""+al5.get(i).getAge_rngseqid1_f()+"\"> ");	
				 out.print("<input type=\"hidden\" id=\"dentalUserFe["+dentalCountFe+"]\" name=\"ovrprtflio_dstrUser\" value=\""+al5.get(i).getOvrprtflio_dstr2_f()+"\"> ");
				 if(al5.get(i).getBenf_lives_seq_id1_f() !=null) {
					 out.print("<input type=\"hidden\" name=\"benf_lives_seq_id\" value=\""+al5.get(i).getBenf_lives_seq_id1_f()+"\"> ");
					 }else {
						 out.print("<input type=\"hidden\" name=\"benf_lives_seq_id\" value=\" \"> ");
					 }
					 out.print("<input type=\"hidden\" name=\"benfdesc\" value=\"Dental\"> ");
				 out.print("</div>");
				 dentalCountFe ++;				 
			 }
			 
			 int opticalCount=0;
			 
			 for(int i=0;i< al4.size();i++) {
				 out.print("<div id=\"opticalDivId["+opticalCount+"]\">");
				 out.print(" <input type=\"hidden\" name=\"totalCoverdLives\"  id=\"opticalTotalLivesCoverdMale["+opticalCount+"]\" class=\"form-control\"  value=\""+al4.get(i).getTotalCoverdLives1_f()+"\" >");
				 out.print("<input type=\"hidden\" name=\"gndrdesc\" value=\""+al4.get(i).getGndrdesc1_f()+"\"> ");
				 out.print("<input type=\"hidden\" name=\"age_range\" value=\""+al4.get(i).getAge_range1_f()+"\"> ");
				 out.print("<input type=\"hidden\" name=\"ovrprtflio_dstr\" value=\""+al4.get(i).getOvrprtflio_dstr1_f()+"\">");
				 out.print("<input type=\"hidden\" name=\"benf_typeseqid\" value=\""+al4.get(i).getBenf_typeseqid1_f()+"\">");
				 out.print("<input type=\"hidden\" name=\"gndrtypeseqid\" value=\""+al4.get(i).getGndrtypeseqid1_f()+"\"> ");
				 out.print("<input type=\"hidden\" name=\"age_rngseqid\" value=\""+al4.get(i).getAge_rngseqid1_f()+"\"> ");	
				 out.print("<input type=\"hidden\" id=\"opticallUserMale["+opticalCount+"]\" name=\"ovrprtflio_dstrUser\" value=\""+al4.get(i).getOvrprtflio_dstr2_f()+"\"> ");
				 if(al4.get(i).getBenf_lives_seq_id1_f() !=null) {
					 out.print("<input type=\"hidden\" name=\"benf_lives_seq_id\" value=\""+al4.get(i).getBenf_lives_seq_id1_f()+"\"> ");
					 }else {
						 out.print("<input type=\"hidden\" name=\"benf_lives_seq_id\" value=\" \"> ");
					 }
					 out.print("<input type=\"hidden\" name=\"benfdesc\" value=\"Optical\"> ");
				 out.print("</div>");
				 opticalCount ++;				 
			 }
			 
              int opticalCountFe=0;
			 
			 for(int i=0;i< al6.size();i++) {
				 out.print("<div id=\"opticalDivIdFe["+opticalCountFe+"]\">");
				 out.print(" <input type=\"hidden\" name=\"totalCoverdLives\"  id=\"opticalTotalLivesCoverdFe["+opticalCountFe+"]\" class=\"form-control\"  value=\""+al6.get(i).getTotalCoverdLives1_f()+"\" >");
				 out.print("<input type=\"hidden\" name=\"gndrdesc\" value=\""+al6.get(i).getGndrdesc1_f()+"\"> ");
				 out.print("<input type=\"hidden\" name=\"age_range\" value=\""+al6.get(i).getAge_range1_f()+"\"> ");
				 out.print("<input type=\"hidden\" name=\"ovrprtflio_dstr\" value=\""+al6.get(i).getOvrprtflio_dstr1_f()+"\">");
				 out.print("<input type=\"hidden\" name=\"benf_typeseqid\" value=\""+al6.get(i).getBenf_typeseqid1_f()+"\">");
				 out.print("<input type=\"hidden\" name=\"gndrtypeseqid\" value=\""+al6.get(i).getGndrtypeseqid1_f()+"\"> ");
				 out.print("<input type=\"hidden\" name=\"age_rngseqid\" value=\""+al6.get(i).getAge_rngseqid1_f()+"\"> ");	
				 out.print("<input type=\"hidden\" id=\"opticallUserFe["+opticalCountFe+"]\" name=\"ovrprtflio_dstrUser\" value=\""+al6.get(i).getOvrprtflio_dstr2_f()+"\"> ");
				 if(al6.get(i).getBenf_lives_seq_id1_f() !=null) {
					 out.print("<input type=\"hidden\" name=\"benf_lives_seq_id\" value=\""+al6.get(i).getBenf_lives_seq_id1_f()+"\"> ");
					 }else {
						 out.print("<input type=\"hidden\" name=\"benf_lives_seq_id\" value=\" \"> ");
					 }
					 out.print("<input type=\"hidden\" name=\"benfdesc\" value=\"Optical\"> ");
				 out.print("</div>");
				 opticalCountFe ++;				 
			 }
			 
			 
			 out.print("<table class=\"table table-basic modal-table total-table\">");
			 out.print("<thead>");
			 out.print("<tr>");
			 out.print("<th></th>");
			 out.print("<th colspan=\"3\">");
			 out.print("</th>");
			 out.print("<th colspan=\"3\">");
			 out.print("</th>");			 
			 out.print("</tr>");
			 out.print("</thead>");
			 
			 out.print("<tbody>");
			 out.print("<tr class=\"total-display\">");
			 out.print("<td>Total</td>");
			 out.print("<td>");
			 
			 out.print("<div class=\"vd-form-control\">");
			 out.print("<input type=\"text\" class=\"form-control bordered-colored\" id=\"sumTotalLives\" readonly=\"true\" value=\""+sumTotalLivesMale+"\">");
			 out.print("</div>");
			 out.print("</td>");
			 out.print("<td id=\"\" class=\"highlight1\">");
			 out.print(""+sumTotalLivesMaleUserPer+"%");
			 out.print("</td>");
			 out.print("<td class=\"highlight2\">");
			 out.print("54%");
			 out.print("</td>");
			 out.print(" <td>");
			 out.print("<div class=\"vd-form-control\">");
			 out.print("<input type=\"text\" class=\"form-control bordered-colored\" name=\"\" id=\"sumTotalLivesFemale\" readonly=\"true\" value=\""+sumTotalLivesFemale+"\">");
			 out.print("</div>");
			 out.print("</td>");
			 out.print(" <td class=\"highlight1\">");
			 out.print(""+sumTotalLivesFemaleUserPer+"%");
			 out.print("</td>");
			 out.print("<td class=\"highlight2\">");
			 out.print("46%");
			 out.print("</td>");
			 out.print("</tr>");
			 out.print("</tbody>");
			 out.print("</table>");
			 			  
			  out.print("</div>");
			  
	
			  out.print("<div class=\"vd-form-control mt-2\" style=\"\">");
			  out.print("<label for=\"Treating\">Maternity eligible age:</label>");
			  out.print(" <div class=\"form-flex\">");
			  
			  out.print("<div class=\"formgroup\">");
			  out.print("<label for=\"\" class=\"label-2\">Min</label>");
			  
			  out.print("<input type=\"text\" name=\"minMaternity\" class=\"form-control readonlyclass\" placeholder=\"\" id=\"minMatLives\" onkeypress=\"return isNumberKey(event);\"  value=\""+minMatLives+"\" onblur=\"onChangeCensusMaternityMin()\">");
			  out.print(" </div>");
			  out.print("<div class=\"formgroup\">");
			  out.print("<label for=\"\" class=\"label-2\">Max</label>");
			  
			  out.print("<input type=\"text\" name=\"maxMaternity\" class=\"form-control readonlyclass\" placeholder=\"\" id=\"maxMatLives\" onkeypress=\"return isNumberKey(event);\"  value=\""+maxMatLives+"\" onblur=\"onChangeCensusMaternityMax()\">");
			  out.print(" </div>");
			  
			  out.print("</div>");
			  out.print("</div>");
			 /* out.print("<h6 class=\"card-title mt-4\">");*/
			  
			  out.append("<h6 class=\"card-title mt-4\">");
			  out.print("Maternity eligible members by age band");
			  out.print("</h6>");
		 
			  
			  out.print("<div class=\"vd-grid-style-basic\">");
			  out.print("<table class=\"table table-basic modal-table mb-0\">");
			  
			  out.print("<thead>");
			  out.print("<tr>");
			  out.print("<th></th>");
			  out.print("<th>Female</th>");
			  out.print("<th colspan=\"2\"></th>");
			  out.print("<th></th>");
			  out.print("<th colspan=\"2\"></th>");			  
			  out.print("</tr>");
			  
			  out.print("</thead>");
			  out.print("<tbody>");
			  
			  int coppyObjeMate=0;
			  for(int i=0;i< al2.size();i++) {
				  
			  out.print(" <tr>");			  
			  out.print("<td>");			  
			  out.print(al2.get(i).getAge_range1_f());			  			
			  out.print("</td>");
			  out.print(" <td style=\"width: 25%;\">");
			  out.print("<div class=\"vd-form-control\">");
			  out.print(" <input type=\"text\" name=\"totalCoverdLives\"  class=\"form-control readonlyclassmaternity\" id=\"benf_typeseqid"+al2.get(i).getBenf_typeseqid1_f()+"["+coppyObjeMate+"]\" onchange=\"isTotalLivesMat(this,"+coppyObjeMate+","+ al2.get(i).getBenf_typeseqid1_f()+");calculatePerMat();\" value=\""+al2.get(i).getTotalCoverdLives1_f()+"\"  onkeypress=\"return isNumberKey(event);\" readonly=\"true\">");
			  out.print("</div>");
			    out.print("<input type=\"hidden\" name=\"gndrdesc\" value=\""+al2.get(i).getGndrdesc1_f()+"\"> ");
				 out.print("<input type=\"hidden\" name=\"age_range\" value=\""+al2.get(i).getAge_range1_f()+"\"> ");
				 out.print("<input type=\"hidden\" name=\"ovrprtflio_dstr\" value=\""+al2.get(i).getOvrprtflio_dstr1_f()+"\">");
				 out.print("<input type=\"hidden\" name=\"benf_typeseqid\" value=\""+al2.get(i).getBenf_typeseqid1_f()+"\">");
				 out.print("<input type=\"hidden\" name=\"gndrtypeseqid\" value=\""+al2.get(i).getGndrtypeseqid1_f()+"\"> ");
				 out.print("<input type=\"hidden\" name=\"age_rngseqid\" id=\"agrSeqId["+coppyObjeMate+"]\" value=\""+al2.get(i).getAge_rngseqid1_f()+"\"> ");
				 out.print("<input type=\"hidden\" id=\"userPerMalehdMat["+coppyObjeMate+"]\" name=\"ovrprtflio_dstrUser\" value=\""+al2.get(i).getOvrprtflio_dstr2_f()+"\"> ");
				 if(al2.get(i).getBenf_lives_seq_id1_f() !=null) {
				 out.print("<input type=\"hidden\" name=\"benf_lives_seq_id\" value=\""+al2.get(i).getBenf_lives_seq_id1_f()+"\"> ");
				 }else {
					 out.print("<input type=\"hidden\" name=\"benf_lives_seq_id\" value=\" \"> ");
				 }
				 out.print("<input type=\"hidden\" name=\"benfdesc\" value=\"Maternity\"> ");
			  out.print(" </td>");
			  out.print("<td id=\"maternityPerId["+coppyObjeMate+"]\" class=\"highlight1\" style=\"width:10%;\">");
			  out.print(al2.get(i).getOvrprtflio_dstr2_f()+"%");
			  out.print("</td>");
			  out.print("<td class=\"highlight2\" style=\"width:10%;\">");
			  out.print(al2.get(i).getOvrprtflio_dstr1_f()+"%"); 
			  out.print("</td>");
			  out.print(" <td class=\"\">");
			  out.print("</td>");
			  out.print(" <td class=\"\">");
			  out.print("</td>");			  
			  out.print(" <td class=\"\">");
			
			  out.print("</td>");
			 
			  out.print(" </tr>");
			  
			  coppyObjeMate ++;
			  }
			  
			
			  
			  
			  
			  out.print("</tbody>");
			  out.print("</table>");
			  
			  out.print(" <table class=\"table table-basic modal-table total-table\">");
			  out.print(" <thead >");
			  out.print(" <tr>");
			  out.print(" <th></th>");
			  out.print(" <th colspan=\"3\">");
			  out.print("</th>");
			  out.print(" <th colspan=\"3\">");
			  out.print("</th>");
			  out.print("  </tr>");
			  out.print(" </thead>");
			  out.print(" <tbody>");
			  out.print(" <tr class=\"total-display\">");
			  out.print(" <td>Total</td>");
			  
			  out.print("<td>");
			  
			  out.print("  <div class=\"vd-form-control\">");
			  out.print(" <input type=\"text\" name=\"sumTotalLivesMaternity\" id=\"sumTotalLivesMaternity\" class=\"form-control bordered-colored\" style=\"width:100px;\" readonly=\"true\" value=\""+sumTotalLivesMaternity+"\">");
			  out.print(" </div>");
			  
			  out.print(" </td>");
			  
			  out.print("<td class=\"highlight1\">");			  
			  out.print("100%");
			  out.print("</td>");
			  
			  out.print("<td class=\"highlight2\">");
			  
			  out.print("100%");
			  
			  out.print("</td>");
			  
			  out.print("<td class=\"\">");
			  
			  out.print("<div class=\"vd-form-control\">");
			  
			  out.print("<input type=\"text\" class=\"form-control bordered-colored\" disabled>");
			  
			  out.print("</div>");
			  out.print(" </td>");
			  out.print(" <td class=\"\">");
			  out.print("</td>");
			 /* out.print("<td class=\"\">");
			  out.print("</td>");*/
			  out.print(" </tr>");
			  out.print(" </tbody>");
			  out.print(" </table>");
						  			  
			  out.print("</div>");
			  
			  out.print("<h6 class=\"card-title mt-4\">Covered members by nationality</h6>");
			  out.print(" <div class=\"vd-grid-style-basic\">");
			  
			  out.print("<table class=\"table table-basic modal-table mb-0\">");
			  
			  out.print("<tbody>");
			  
			  int countNat=0;
			  for(int i=0;i<profileNationalityList.size();i++) {
			  out.print(" <tr>");
			  out.print(" <td>"+profileNationalityList.get(i).getNatl_name1()+"</td>");
			  out.print("  <td style=\"width: 25%;\">");
			  out.print(" <div class=\"vd-form-control\">");
			  out.print(" <input type=\"text\" name=\"natCoverdLives\" class=\"form-control readonlyclass\" id=\"natl_typeseqid["+countNat+"]\" onkeypress=\"return isNumberKey(event);\" value=\""+profileNationalityList.get(i).getNatCoverdLives1()+"\" onchange=\"isTotalNatLives(this,"+countNat+");calculatePerNal();\" >");
			  out.print(" </div>");
			  if(profileNationalityList.get(i).getNatl_seqid1() !=null) {
				  out.print("<input type=\"hidden\" name=\"natl_seqid\" value=\""+profileNationalityList.get(i).getNatl_seqid1()+"\">");
			  }else {
				  out.print("<input type=\"hidden\" name=\"natl_seqid\" value=\" \">");
			  }
			 
			  out.print("<input type=\"hidden\" name=\"natl_name\" value=\""+profileNationalityList.get(i).getNatl_name1()+"\">");
			  out.print("<input type=\"hidden\" name=\"natovrprtflio_dstr\" value=\""+profileNationalityList.get(i).getNatovrprtflio_dstr1()+"\">");
			  out.print("<input type=\"hidden\" name=\"natl_typeseqid\" value=\""+profileNationalityList.get(i).getNatl_typeseqid1()+"\">");
			  out.print("<input type=\"hidden\" id=\"userPerNal["+countNat+"]\" name=\"ovrprtflio_dstrUserNal\" value=\""+profileNationalityList.get(i).getNatovrprtflio_dstr2()+"\"> ");
			  			  			  
			  out.print("</td>");
			  out.print("<td id=\"nationalPerId["+countNat+"]\" class=\"highlight1\" style=\"width: 10%;\">");
			  out.print(profileNationalityList.get(i).getNatovrprtflio_dstr2()+"%");
			  out.print("</td>");
			  out.print(" <td class=\"highlight2\" style=\"width:10%;\">");
			  out.print(profileNationalityList.get(i).getNatovrprtflio_dstr1()+"%");
			  out.print("</td>");
			  out.print(" <td class=\"\">");
			  out.print("  </td>");
			  out.print(" <td class=\"\">");
			  out.print("</td>");
			  out.print("<td class=\"\">");
			  out.print("</td>");
			  out.print("  </tr>");
			  
			  countNat++;
			  }
			  out.print(" </tbody>");
			  
			  out.print("  </table>");
			  
			  
			  out.print(" <table class=\"table table-basic modal-table total-table\">");
			  out.print("  <thead >");
			  out.print("<tr>");
			  out.print("  <th></th>");
			  out.print(" <th colspan=\"3\">");
			  out.print("</th>");
			  out.print(" <th colspan=\"3\">");
			  out.print("</th>");
			  out.print("</tr>");
			  out.print(" </thead>");
			  out.print(" <tbody>");
			  out.print("  <tr class=\"total-display\">");
			  out.print("<td>Total</td>");
			  out.print("<td>");
			  out.print("<div class=\"vd-form-control\">");
			  out.print("<input type=\"text\" class=\"form-control bordered-colored\" readonly=\"true\" name=\"sumNationalityLives\" style=\"width:100px;\" id=\"sumNationalityLives\"  value=\""+sumNationalityLives+"\">");
			  out.print(" </div>");
			  out.print(" </td>");
			  out.print(" <td class=\"highlight1\">");
			  out.print("100%");
			  out.print("</td>");
			  out.print("<td class=\"highlight2\">");
			  out.print("100%");
			  out.print("</td>");
			  out.print(" <td class=\"\">");
			  out.print(" <div class=\"vd-form-control\">");
			  out.print(" <input type=\"text\" class=\"form-control bordered-colored\" disabled>");
			  out.print(" </div>");
			  out.print("</td>");
			  out.print(" <td class=\"\"></td>");
			 /* out.print(" <td class=\"\"></td>");*/
			  out.print(" </tr>");
			  out.print(" </tbody>");
			  out.print(" </table>");
			  out.print("</div>");
			  out.print("<div class=\"vd-form-control text-right\">");
			/*  out.print("<button type=\"button\" class=\"btn vd-btn-primary\" onclick=\"onSaveIncome('save');\">Save & Proceed</button>");*/
			 /* if(!"N".equals(request.getSession().getAttribute("editflag"))){
				  out.print("<button type=\"button\" class=\"btn vd-btn-primary\"  onclick=\"onSaveIncome('save');\">Save</button>");
			  }	
			  */
			  /*String statusFlag =(String) request.getSession().getAttribute("editflag");
			  
			  if(statusFlag.equals("N") || renevalFlag.equals("Y")) {
			  out.print("<button type=\"button\" class=\"btn vd-btn-primary\" disabled=\"disabled\"  onclick=\"onSaveIncome('save');\">Save</button>");
			  }else {
				  out.print("<button type=\"button\" class=\"btn vd-btn-primary\"  onclick=\"onSaveIncome('save');\">Save</button>");
			  }*/
			  
			  out.print("<button type=\"button\" class=\"btn vd-btn-primary disableCensorbtn\"  onclick=\"onSaveIncome('save');\">Save</button>");
			  
			  out.print("</div>");
			  
			  out.print("<input type=\"hidden\" id=\"TotalMaternityLives\" name=\"TotalMaternityLives\" value=\""+TotalMaternityLives+"\">");
			  out.print(" <input type=\"hidden\" value=\""+totalNoOfLives+"\" id=\"totalNoOfLives\" name=\"totalNoOfLives\">");
			  out.print(" <input type=\"hidden\" value=\"\" id=\"totalNoOfLivesFenale\" name=\"totalNoOfLivesFenale\" >");
			/*  out.print("<input type=\"hidden\" name=\"totalNoOfLives\" id=\"totalNoOfLives\" value=\"\">");*/
			  out.print("<input type=\"hidden\" name=\"policyNumber\" id=\"policyNumber\" value=\"\">");
			  out.print("<input type=\"hidden\" name=\"numberOfLives\" id=\"numberOfLives\" value=\"0.0\">");
			  
		  out.print("</div>");
	
		  }catch(Exception exp) {
			   exp.printStackTrace();
	            log.debug("error occured in ClaimsDetails Tag Library!!!!! ");
			  
		  }
		  return SKIP_BODY;
	  }
	  
	  public int doEndTag() throws JspException {
		    return EVAL_PAGE;//to process the rest of the page
		}//end doEndTag()
}

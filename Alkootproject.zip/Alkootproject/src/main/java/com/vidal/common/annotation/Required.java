/**
 * 
 */
package com.vidal.common.annotation;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import javax.validation.Constraint;
import javax.validation.Payload;

import com.vidal.common.annotation.validator.RequiredValidator;

/**
 * @author nagababu
 *
 */
@Documented
@Constraint(validatedBy = RequiredValidator.class)
@Target({ElementType.TYPE })
@Retention(RetentionPolicy.RUNTIME)
public @interface Required {
	String message() default "";
	String fieldName();
    String label() default "";
    Class<?>[] groups() default {};
     
    Class<? extends Payload>[] payload() default {}; 
    
    @Target({ ElementType.TYPE })
    @Retention(RetentionPolicy.RUNTIME)
    @interface List {
    	Required[] value();
    }
}

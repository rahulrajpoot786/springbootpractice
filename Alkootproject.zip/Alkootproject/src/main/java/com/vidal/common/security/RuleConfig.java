/**
 * @ (#) RuleEngineServlet.java MAY 22, 2018
 * Project      : VINGS
 * File         : RuleEngineServlet.java
 * Author       : RISHABH KESHARI
 * Company      : VIDAL HEALTH
 * Date Created : MAY 22, 2018
 *
 * @author       :  RISHABH KESHARI
 * Modified by   :
 * Modified date :
 * Reason        : 
 */

package com.vidal.common.security;

import org.dom4j.Document;
import org.dom4j.Element;

import com.vidal.common.UXUtility;

/**
 *
 *
 */
public class RuleConfig {
    private static Document ruleConfigDoc=null;

    public static Element getOperatorElement(String strOperator)throws Exception
    {
        if(ruleConfigDoc==null)
            ruleConfigDoc=UXUtility.getDocument(UXUtility.getPropertyValue("ruleconfigdir")+"ruleconfig.xml");
        Element eleOperator=(Element)ruleConfigDoc.selectSingleNode("/configuration/operator[@type='"+strOperator+"']/display");
        return eleOperator;
    }//end of getOperatorElement(String strOperator)
    public static Element getLookupElement(String strLookupName)throws Exception
    {
        if(ruleConfigDoc==null)
            ruleConfigDoc=UXUtility.getDocument(UXUtility.getPropertyValue("ruleconfigdir")+"ruleconfig.xml");
        Element eleLookup=(Element)ruleConfigDoc.selectSingleNode("/configuration/lookup[@name='"+strLookupName+"']/display");
        return eleLookup;
    }//end of getOperatorElement(String strOperator)
    public static String getOperatorText(String strOperator,String strOptVal)throws Exception
    {
        if(!strOperator.equals(""))
        {
            Element eleOperator=getOperatorElement(strOperator);
            if(eleOperator!=null)
            {
                String [] strOpValues = eleOperator.valueOf("@optVal").split(",");
                String [] strAltText = eleOperator.valueOf("@altText").split(",");
                for(int iCnt=0;iCnt<strOpValues.length;iCnt++)
                {
                    if(strOptVal.equals(strOpValues[iCnt]))
                        return strAltText[iCnt];
                }//end of for(int iCnt=0;iCnt<strOpValues.length;iCnt++)
            }//end of if(eleOperator!=null)
        }//end of if(!strOperator.equals(""))
        return "";
    }
    public static String getLookupText(String strLookupName,String strOptVal)throws Exception
    {
        if(!strLookupName.equals(""))
        {
            Element eleLookup=getLookupElement(strLookupName);
            if(eleLookup!=null)
            {
                String [] strOptValues = eleLookup.valueOf("@optVal").split(",");
                String [] strAltText = eleLookup.valueOf("@altText").split(",");
                for(int iCnt=0;iCnt<strOptValues.length;iCnt++)
                {
                    if(strOptVal.equals(strOptValues[iCnt]))
                        return strAltText[iCnt];
                }//end of for(int iCnt=0;iCnt<strOpValues.length;iCnt++)
            }//end of if(eleLookup!=null)
        }//end of if(!strOperator.equals(""))
        return "";
    }

}

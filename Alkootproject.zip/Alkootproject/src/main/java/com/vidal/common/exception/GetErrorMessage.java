package com.vidal.common.exception;
/**
 * This class is used to get the error message
 */
import java.util.ResourceBundle;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.itextpdf.text.log.SysoCounter;

public class GetErrorMessage {
	private static final Logger logger = LoggerFactory.getLogger(GetErrorMessage.class);
	private static final ResourceBundle bundle=ResourceBundle.getBundle("resources.files/dbErrors");

	
	
	public static String getValue(String key){
		if(!bundle.containsKey(key)){
			logger.info("Key Not Found ::"+key);
			
			return "Key Not Found "+key;
		}
		return bundle.getString(key);
	}
	public static String getErrorMessage(String errorMessage){
		String erroKey="";
		if(errorMessage.contains("ORA-20118"))
        {
			erroKey="error.preauth.preauthdetails.authorise";
        }
		if(errorMessage.contains("ORA-20863"))
		{
			erroKey="error.preauth.claims.modification.not.allowed";
		}
		else if(errorMessage.contains("ORA-20107"))
        {
			erroKey="error.preauth.preauthdetails.review";
        }
		
		else if(errorMessage.contains("ORA-20108"))
        {
			erroKey="error.preauth.assignto.reassign";
        }
		else if(errorMessage.contains("ORA-20901"))//Maternity_limit_restriction
        {
			erroKey="error.claims.viewbillssummary.save";
        }
		else if(errorMessage.contains("ORA-20943"))//Maternity_limit_restriction
        {
			erroKey="error.event.quotation.generate";
        }
		else if(errorMessage.contains("ORA-20046"))//Maternity_limit_restriction
        {
			erroKey="error.risk.calculate.project.claim.msg";
        }
		else if(errorMessage.contains("ORA-20277"))//Maternity_limit_restriction
        {
			erroKey="error.risk.calculate.project.claim.msg.totalLive";
        }
		else if(errorMessage.contains("ORA-01476"))//Maternity_limit_restriction
        {
			erroKey="error.risk.calculate.project.claim.msg.totalLive";
        }
		
		else
		{
			erroKey="error.general";
		}
		if(!bundle.containsKey(erroKey))logger.info("Key Not Found ::"+erroKey);
		return bundle.getString(erroKey);
	}
	public static String getValue(int key){
		logger.info("  key : "+key);
		switch(key){
		case 1:return bundle.getString("add.duplicate");
		case 1400:return bundle.getString("error.empty");
		case 1401:return bundle.getString("error.huge");
	
		case 20943:return bundle.getString("error.event.quotation.generate");
		case 20108:return bundle.getString("error.event.quotation.delete");
		case 20285:return bundle.getString("error.save.inputscreen.maximumLimit");
		case 20048:return bundle.getString("error.usermanagement.login.userinvalid");
		case 20924:return bundle.getString("error.sava.inputscreen.oldPricing");
		case 20278:return bundle.getString("error.sava.inputscreen.pastPolicyDetails");	
		case 1476:return bundle.getString("error.risk.calculate.common.msg");	
		
		
		default:return bundle.getString("error.softcopy.database");		
		}
	}

}

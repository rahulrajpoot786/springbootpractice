package com.vidal.common;

import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.sql.BatchUpdateException;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.StringTokenizer;

import javax.servlet.http.HttpServletRequest;
import javax.sql.DataSource;

import org.dom4j.Element;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.vidal.command.common.CacheObject;
import com.vidal.command.common.Toolbar;
import com.vidal.command.usermanagement.UserSecurityProfile;
import com.vidal.common.exception.GetErrorMessage;
import com.vidal.common.exception.VidalException;
import com.vidal.common.security.Cache;
import com.vidal.controllers.table.TableData;

public class VidalCommon {
	private static final Logger logger = LoggerFactory.getLogger(VidalCommon.class);
	
	/**
     * this method takes java.util.Date and returns the date in dd/MM/yyyy h:mm a format
     * @param date java.util.Date
     * @return String in format dd/MM/yyyy h:mm a
     */
    public synchronized static String getFormattedDateHour(Date date)
    {
        if(date!=null)
        {
            SimpleDateFormat sdFormat=new SimpleDateFormat("dd/MM/yyyy h:mm a");
            return sdFormat.format(date.getTime());
        }//end of if(date!=null)
        return "";
    }//end of getFormattedDateHour(Date date)
    
    private void getPopulateDropdown(){
    	
    }
	 public static Timestamp getConvertStringToDateTimestamp(String stringDate) throws Exception,ParseException
	    {
		 
		    SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
		    Date parsedDate = dateFormat.parse(stringDate.trim());
		    Timestamp timestamp = new java.sql.Timestamp(parsedDate.getTime());
	    	return timestamp;
	    }	
    
    public static String replaceSingleQots(String sValue)
    {
        if(sValue==null)
        {
            return "";
        }//end of if(sValue==null)
        else
        {
            sValue = sValue.trim();
            String sTemp = "";
            int i=0;
            while(sValue.length() > 0 && i !=-1)
            {
                i =  sValue.indexOf('\'');
                if(i!=-1)
                {
                    sTemp+= sValue.substring(0,i)+"''";
                    sValue = sValue.substring(i+1,sValue.length());
                }//if(i!=-1)
                else
                {
                    sTemp+= sValue;
                }//end of else
            }//end of while(sValue.length() > 0 && i !=-1)
            return sTemp;
        }//end of else
    }//end of replaceDoubleQotsWithSlash(String sValue)
    
   public static HttpServletRequest getCurentRequestObject(){
	   return ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();
   }
   
   public static TableData getTableData(HttpServletRequest request)
   {
       TableData tableConfig = null;
       if((request.getSession()).getAttribute("tableData") == null)
       {
           tableConfig = new TableData();
       }//end of if((request.getSession()).getAttribute("tableData") == null)
       else
       {
           tableConfig = (TableData)(request.getSession()).getAttribute("tableData");
       }//end of else

       return tableConfig;
   }
   
   public static boolean isDataFound(HttpServletRequest request, String strIdentifier) throws Exception
   {
       boolean bFlag=false;
       if((request.getSession().getAttribute(strIdentifier))!=null)
       {
           TableData tableData=(TableData)request.getSession().getAttribute(strIdentifier);
           
           ArrayList alData=(ArrayList)tableData.getData();
           if(alData!=null && alData.size()!=0)
               bFlag=true;
       }//end of if((request.getSession().getAttribute(strIdentifier))!=null)
       return bFlag;
   }
   
   public static boolean isAuthorized(HttpServletRequest request, String strPermission) throws Exception
   {
       StringBuffer sbfPermisson=new StringBuffer();
       sbfPermisson.append(((UserSecurityProfile) request.getSession().getAttribute("userAccessSecurityProfile")).getSecurityProfile().getActiveLink()).append(".");
       sbfPermisson.append(((UserSecurityProfile) request.getSession().getAttribute("userAccessSecurityProfile")).getSecurityProfile().getActiveSubLink()).append(".");
       sbfPermisson.append(((UserSecurityProfile) request.getSession().getAttribute("userAccessSecurityProfile")).getSecurityProfile().getActiveTab()).append(".").append(strPermission);

       return ((UserSecurityProfile)request.getSession().getAttribute("userAccessSecurityProfile")).getSecurityProfile().isAuthorized(sbfPermisson.toString());
   }
   
   public static boolean isAuthorizedLST(HttpServletRequest request, String strLST) throws Exception
   {

       return ((UserSecurityProfile)request.getSession().getAttribute("userAccessSecurityProfile")).getSecurityProfile().isAuthorized(strLST);
   }
   public static boolean isDataFound() throws Exception
   {
       boolean bFlag=false;
      
       return bFlag;
   }
   public static TableData getTableData(HttpServletRequest request,String identifier)
   {
       TableData tableConfig = null;
       Object obj=request.getSession().getAttribute(identifier);
       if(obj == null)
       {
           tableConfig = new TableData();
       }
       else
       {
           tableConfig = (TableData)obj;
       }//end of else
       return tableConfig;
   }
   /**
    * user id will come
    * @param request
    * @return
    */
   public static long getUserSeqID(HttpServletRequest request)
   {
       return ((UserSecurityProfile)request.getSession().getAttribute("userAccessSecurityProfile")).getUSER_SEQ_ID();
   }
   
   /**
    * this method takes java.util.Date and returns the date in dd/mm//yyyy format
    * @param date java.util.Date
    * @return String in the format dd/mm//yyyy
    */
   public synchronized static String getFormattedDate(Date date)
   {
       if(date!=null)
       {
           SimpleDateFormat sdFormat=new SimpleDateFormat("dd/MM/yyyy");
           return sdFormat.format(date.getTime());
       }//end of if(date!=null)
       return "";

   }//end of getFormattedDate(Date date)
   
   public static Long getLong(String strLong)
   {
       Long value=null;

       if(strLong!=null && !strLong.equals(""))
       {
           value=Long.parseLong(strLong);
       }//end of if(strLong!=null && !strLong.equals(""))
       return value;
   }//end of getLong(String strLong)
	

public static String getActiveLink(HttpServletRequest request) throws Exception
   {
       String strLink = "";
strLink=((UserSecurityProfile)request.getSession().getAttribute("userAccessSecurityProfile")).getSecurityProfile().getActiveLink();
       return strLink;
   }
   public static String getActiveTab(HttpServletRequest request) throws Exception
   {
       String strTabLink = "";
strTabLink=((UserSecurityProfile)request.getSession().getAttribute("userAccessSecurityProfile")).getSecurityProfile().getActiveTab();
       return strTabLink;
   }
   public static String getActiveSubLink(HttpServletRequest request) throws Exception
   {
       String strSubLink = "";
strSubLink=((UserSecurityProfile)request.getSession().getAttribute("userAccessSecurityProfile")).getSecurityProfile().getActiveSubLink();
       return strSubLink;
   } 
   
   public static Date getDate() {
	     java.util.Date dtdate = new java.util.Date();
	     return dtdate;
	}
   
   /**
    * This method sets the webboard id
    *
    * @param HttpServletRequest request
    * @return strCacheId String the webboard id
    */
   public static void setWebBoardId(HttpServletRequest request)
   {
       Toolbar toolbar = (Toolbar) request.getSession().getAttribute("toolbar");
       String strCacheId = UXUtility.checkNull(request.getParameter("webBoard"));
       //set the web board id if the parameter is found
           if(!strCacheId.equals(""))
           {
               toolbar.getWebBoard().setCurrentId(strCacheId);
           }//end of if(strCacheId.equals(""))
   }
   
   /**
    * This method is used to build the Element to be displayed from the XML
    * @param eleDisplay Element to be displayed
    * @param strFieldName String field name of the Element
    * @param strFieldValue String current value of the element
    * @param strPermission String to disable element or to makeReadOnly
    * @param strMandatoryID String to give unique id for element if it is a mandatory field
    * @return String
    */
   public static String buildDisplayElement(Element eleDisplay,String strFieldName,String strFieldValue,String strPermission,String strMandatoryID)
   {
       StringBuffer sbfDisplayElement=new StringBuffer();

       if(eleDisplay!=null)
       {
           if(eleDisplay.valueOf("@control").equalsIgnoreCase("input"))
           {
               sbfDisplayElement.append("<input type=\"").append(eleDisplay.valueOf("@type")).append("\" ");
               sbfDisplayElement.append(" name=\"").append(strFieldName).append("\" ");
               if(eleDisplay.valueOf("@type").equalsIgnoreCase("text"))
               {
               	String strMaxLength = UXUtility.checkNull(eleDisplay.valueOf("@maxlength"));
                   if(eleDisplay.valueOf("@class").equals(""))
                   {
                       sbfDisplayElement.append(" class=\"textBox textBoxTiny\" ");
                   }//end of if(eleDisplay.valueOf("@class").equals(""))
                   else
                   {
                       sbfDisplayElement.append(" class=\"").append(eleDisplay.valueOf("@class")).append("\" ");
                   }//end of else
                   sbfDisplayElement.append(" value=\"").append(strFieldValue.equals("null")? "":strFieldValue).append("\" ");
                   if(strMaxLength.equals(""))
                   {
                   	sbfDisplayElement.append(" maxlength=\"250\" ");
                   }//end of if(strMaxLength.equals(""))
                   else
                   {
                   	sbfDisplayElement.append(" maxlength=\""+strMaxLength+"\" ");
                   	
                   }//end of else
                   
                   if(strMandatoryID!=null && !strMandatoryID.equals(""))
                   {
                       sbfDisplayElement.append(" id=\""+strMandatoryID+"\" ");
                   }//end of if(strMandatoryID!=null && !strMandatoryID.equals(""))
                   else
                   {
                       sbfDisplayElement.append(" id=\""+eleDisplay.valueOf("@id")+"\" ");
                   }//end of else

               }//end of if(eleDisplay.valueOf("@type").equalsIgnoreCase("text"))
               else if(eleDisplay.valueOf("@type").equalsIgnoreCase("checkbox"))
               {
                   sbfDisplayElement.append(" value=\"").append(eleDisplay.valueOf("@value")).append("\" ");
                   sbfDisplayElement.append(" id=\""+eleDisplay.valueOf("@id")+"\" ");
                   if(eleDisplay.valueOf("@value").equalsIgnoreCase(strFieldValue))
                   {
                       sbfDisplayElement.append(" checked ");
                   }//end of if(eleDisplay.valueOf("@value").equals(strFieldValue))
               }//end of else if(eleDisplay.valueOf("@type").equalsIgnoreCase("checkbox"))
               else if(eleDisplay.valueOf("@type").equalsIgnoreCase("option"))
               {
                   sbfDisplayElement.append(" value=\"").append(eleDisplay.valueOf("@value")).append("\" ");
                   sbfDisplayElement.append(" id=\""+eleDisplay.valueOf("@id")+"\" ");
                   if(eleDisplay.valueOf("@value").equals(strFieldValue))
                   {
                       sbfDisplayElement.append(" selected ");
                   }//end of if(eleDisplay.valueOf("@value").equals(strFieldValue))
               }//end of else if(eleDisplay.valueOf("@type").equalsIgnoreCase("option"))
               sbfDisplayElement.append(eleDisplay.valueOf("@jscall"));
               if(strPermission.equals("") && eleDisplay.valueOf("@disabled").equals("true"))
               {
                   sbfDisplayElement.append(" ").append("readOnly");
               }//end of if(strPermission.equals("") && eleDisplay.valueOf("@disabled").equals("true"))
               else
               {
                   sbfDisplayElement.append(" ").append(strPermission);
               }//end of else
               if(eleDisplay.valueOf("@type").equalsIgnoreCase("text"))
               {
               	sbfDisplayElement.append(" onkeypress = \"javascript:ConvertToUpperCase()\" onblur = \"javascript:toUpperCase(this.value,this.id,this.name)\" >");
               }//end of if(eleDisplay.valueOf("@type").equalsIgnoreCase("text"))
               else {
               	sbfDisplayElement.append(" >");
               }//end of else
           }//end of if(eleDisplay.valueOf("@control").equalsIgnoreCase("input"))

           else if(eleDisplay.valueOf("@control").equalsIgnoreCase("date"))
           {
               sbfDisplayElement.append("<input type=\"text\" class=\"textBox textDate\" ");
               sbfDisplayElement.append(" name=\"").append(strFieldName).append("\" ");
               sbfDisplayElement.append(" value=\"").append(strFieldValue).append("\" ");
               if(strMandatoryID!=null && !strMandatoryID.equals(""))
               {
                   sbfDisplayElement.append(" id=\""+strMandatoryID+"\" ");
               }//end of if(strMandatoryID!=null && !strMandatoryID.equals(""))
               else
               {
                   sbfDisplayElement.append(" id=\""+eleDisplay.valueOf("@id")+"\" ");
               }//end of else
               sbfDisplayElement.append(strPermission);
               sbfDisplayElement.append(" maxlength=\"10\" >");
               if(strPermission.equals(""))
               {
                   sbfDisplayElement.append("<a name=\"CalendarObject").append(strFieldName).append("\" ").append("id=\"CalendarObject").append(strFieldName).append("\" ");
                   sbfDisplayElement.append(" href=\"#\" onClick=\"javascript:show_calendar('CalendarObject").append(strFieldName).append("','forms[1].").append(strFieldName).append("',document.forms[1].").append(strFieldName).append(".value,'',event,148,178);return false;\"");
                   sbfDisplayElement.append(" onMouseOver=\"window.status='Calendar';return true;\" onMouseOut=\"window.status='';return true;\"><img src=\"/ttk/images/CalendarIcon.gif\" alt=\"Calendar\"");
                   sbfDisplayElement.append(" name=\"img").append(strFieldName).append("\" width=\"24\" height=\"17\" border=\"0\" align=\"absmiddle\"></a> ");
               }//end of if(strPermission.equals(""))
           }//end of else if(eleDisplay.valueOf("@control").equalsIgnoreCase("date"))

           else if(eleDisplay.valueOf("@control").equalsIgnoreCase("textArea"))
           {
               sbfDisplayElement.append("<textarea name=\"").append(strFieldName).append("\" ");
               sbfDisplayElement.append("class=\"textBox textAreaLarge10Lines\" ");

               if(strMandatoryID!=null && !strMandatoryID.equals(""))
               {
                   sbfDisplayElement.append(" id=\""+strMandatoryID+"\" ");
               }//end of if(strMandatoryID!=null && !strMandatoryID.equals(""))
               else
               {
                   sbfDisplayElement.append(" id=\""+eleDisplay.valueOf("@id")+"\" ");
               }//end of else
               sbfDisplayElement.append(eleDisplay.valueOf("@jscall"));
               if(strPermission.equals("") && eleDisplay.valueOf("@disabled").equals("true"))
               {
                   sbfDisplayElement.append(" ").append("readOnly");
               }//end of if(strPermission.equals("") && eleDisplay.valueOf("@disabled").equals("true"))
               else
               {
                   sbfDisplayElement.append(" ").append(strPermission);
               }//end of else
               sbfDisplayElement.append(" >");
               if(strFieldName.equalsIgnoreCase("Others.1"))
               {
               	 sbfDisplayElement.append(strFieldValue.replaceAll("</br>"," "));
               }//end of if(strFieldName.equalsIgnoreCase("Others.1"))
               else
               {
               	// Unni Added for fixing Bug ID 42647
               	if(strFieldValue.indexOf("\r") != -1 || strFieldValue == "\n" || strFieldValue.indexOf("\r\n") != -1){
                	    sbfDisplayElement.append(strFieldValue.replaceAll("~", "\n"));
                    }//end of if(strFieldValue.indexOf("\r") != -1 || strFieldValue == "\n" || strFieldValue.indexOf("\r\n") != -1){
                    else if(strFieldValue.indexOf("~") != -1)
                    {
                        sbfDisplayElement.append(strFieldValue.replaceAll("~", "\n"));
                    }//end of else if(strFieldValue.indexOf("~") != -1)
                    else
                    {
                   	 sbfDisplayElement.append(strFieldValue);
                    }//end of else
               //sbfDisplayElement.append(strFieldValue);
               // End of Adding
               }//end of else
               sbfDisplayElement.append("</textarea>");
           }//end of else if(eleDisplay.valueOf("@control").equalsIgnoreCase("textArea"))

           else if(eleDisplay.valueOf("@control").equalsIgnoreCase("select"))
           {
               sbfDisplayElement.append("<select name=\"").append(strFieldName).append("\" ");
               if(eleDisplay.valueOf("@source").equalsIgnoreCase("OnlinAccessManager"))
               {
               	if(eleDisplay.valueOf("@style").equalsIgnoreCase("marginTop"))
               	{
               		sbfDisplayElement.append("class=\"selectBoxWeblogin selectBoxLargestWeblogin\" style=\"margin-top:5px;\" ");
               	}//end of if(eleDisplay.valueOf("@style").equalsIgnoreCase("marginTop"))
               	else if(eleDisplay.valueOf("@style").equalsIgnoreCase("marginBottom"))
               	{
               		sbfDisplayElement.append("class=\"selectBoxWeblogin selectBoxLargestWeblogin\" style=\"margin-bottom:5px;\" ");
               	}//end of else
               }//end of if(eleDisplay.valueOf("@source").equalsIgnoreCase("OnlinAccessManager"))
               else
               {
               	sbfDisplayElement.append("class=\"selectBox\" ");
               }//end of else
               sbfDisplayElement.append(eleDisplay.valueOf("@jscall"));
               sbfDisplayElement.append(" ").append(eleDisplay.valueOf("@type"));
               if(strMandatoryID!=null && !strMandatoryID.equals(""))
               {
                   sbfDisplayElement.append(" id=\""+strMandatoryID+"\" ");
               }//end of if(strMandatoryID!=null && !strMandatoryID.equals(""))
               else
               {
                   sbfDisplayElement.append(" id=\""+eleDisplay.valueOf("@id")+"\" ");
               }//end of else

               if(strPermission.equals("") && eleDisplay.valueOf("@disabled").equals("true"))
               {
                   sbfDisplayElement.append(" ").append("Disabled");
               }//end of if(strPermission.equals("") && eleDisplay.valueOf("@disabled").equals("true"))
               else
               {
                   sbfDisplayElement.append(" ").append(strPermission);
               }//end of else
               sbfDisplayElement.append(" >");
               sbfDisplayElement.append(buildOptions(eleDisplay,strFieldValue));
               sbfDisplayElement.append("</select>");
           }//end of else if(eleDisplay.valueOf("@control").equalsIgnoreCase("select"))

           else if(eleDisplay.valueOf("@control").equalsIgnoreCase("image"))  //to display the image
           {
               sbfDisplayElement.append("<a href=\"#\" ");
               sbfDisplayElement.append(eleDisplay.valueOf("@jscall")).append(" >");
               if(eleDisplay.valueOf("@imagepath").equals(""))
               {
               	sbfDisplayElement.append("<img src=\"/ttk/images/EditIcon.gif\" width=\"16\" height=\"16\"");
               }//end of if(eleDisplay.valueOf("@imagepath").equals(""))
               else
               {
               	sbfDisplayElement.append("<img src=\"/ttk/images/"+eleDisplay.valueOf("@imagepath")+"\" width=\"16\" height=\"16\"");
               }//end of else
               sbfDisplayElement.append(" alt=\""+eleDisplay.valueOf("@alt")+"\" border=\"0\" align=\"absmiddle\"></a>");
           }//eleDisplay.valueOf("@control").equalsIgnoreCase("image")

           else if(eleDisplay.valueOf("@control").equalsIgnoreCase("radiogroup"))  //to display the radio buttons
           {
               try
               {
                   String[] strOptText=eleDisplay.valueOf("@optText").split(",");
                   String[] strOptValue=eleDisplay.valueOf("@optVal").split(",");
                   if(strFieldValue.trim().equals("")||strFieldValue.equals("~"))
                   {
                       strFieldValue=eleDisplay.valueOf("@default");
                   }//end of if(strFieldValue.trim().equals("")||strFieldValue.equals("~"))
                   if(strOptText.length==strOptValue.length)
                   {
                       for(int iOptTextCnt=0;iOptTextCnt<strOptText.length;iOptTextCnt++)
                       {
                           sbfDisplayElement.append("<input type=\"radio\" ");
                           sbfDisplayElement.append(" name=\"").append(strFieldName).append("\" ");
                           sbfDisplayElement.append("id=\"").append(strFieldName).append("rad").append(iOptTextCnt).append("\"");
                           sbfDisplayElement.append(" value=\"").append(strOptValue[iOptTextCnt]).append("\" ");

                           if(eleDisplay.valueOf("@class").equals(""))
                           {
                               sbfDisplayElement.append(" class=\"\" ");
                           }//end of if(eleDisplay.valueOf("@class").equals(""))
                           else
                           {
                               sbfDisplayElement.append(" class=\"").append(eleDisplay.valueOf("@class")).append("\" ");
                           }//end of else
                           if(strOptValue[iOptTextCnt].equals(strFieldValue))
                           {
                               sbfDisplayElement.append(" checked ");
                           }//end of if(eleDisplay.valueOf("@value").equals(strFieldValue))
                           sbfDisplayElement.append(" ").append(strPermission).append(" ");
                           sbfDisplayElement.append(eleDisplay.valueOf("@jscall")).append(" /> ");
                           sbfDisplayElement.append("<label for=\"").append(strFieldName).append("rad").
                                                                   append(iOptTextCnt).append("\">");
                           sbfDisplayElement.append(strOptText[iOptTextCnt]);
                           sbfDisplayElement.append("</label>");
                           if(iOptTextCnt!=strOptText.length-1)
                           {
                               sbfDisplayElement.append(" &nbsp;&nbsp; ");
                           }//end of if(iOptTextCnt!=strOptText.length-1)
                       }//end of for(int iOptTextCnt=0;iOptTextCnt<strOptText.length;iOptTextCnt++)
                   }//end of if(strOptText.length==strOptValue.length)
               }//end of try
               catch(ArrayIndexOutOfBoundsException e)
               {
            	   logger.error("ArrayIndexOutOfBoundsException .....method.........."+eleDisplay.valueOf("@id"));
               }//end of catch(ArrayIndexOutOfBoundsException e)
           }//end of else if(eleDisplay.valueOf("@control").equalsIgnoreCase("radiogroup"))
       }//end of if(eleDisplay!=null)
       else
       {
    	   logger.error("Element to Displayed is null");
       }//end of else
       return sbfDisplayElement.toString();
   }//end of buildDisplayElement(Element eleDisplay,String strFieldName,String strFieldValue)
   
   /**
    * This method is used to build the options for the select box
    * @param eleDisplay Element, node to be displayed
    * @param strFieldValue String, Current value of the element
    * @return sbfBuildOption String
    */
   private static String buildOptions(Element eleDisplay,String strFieldValue)
   {
       StringBuffer sbfBuildOption=new StringBuffer();
       String strOptValues[] =eleDisplay.valueOf("@optVal").split(",");
       String strOptTexts[] =eleDisplay.valueOf("@optText").split(",");
       if(strOptValues!=null && strOptTexts!=null && strOptValues.length==strOptTexts.length)
       {
           for(int ioptValCnt=0;ioptValCnt<strOptValues.length;ioptValCnt++)
           {
               sbfBuildOption.append("<option value=\"").append(strOptValues[ioptValCnt]).append("\"");
               if(strOptValues[ioptValCnt].equals(strFieldValue))
               {
                   sbfBuildOption.append(" selected ");
               }
               sbfBuildOption.append(">");
               sbfBuildOption.append(strOptTexts[ioptValCnt]).append("</option>");
           }//end of for(int ioptValCnt=0;ioptValCnt<strOptValues.length;ioptValCnt++)
       }//end of if(strOptValues!=null && strOptTexts!=null && strOptValues.length==strOptTexts.length)
       return sbfBuildOption.toString();
   }//end of buildoptions(Element eleDisplay,String strFieldValue)

   /**
    * this method takes date in dd/mm//yyyy and returns java.util.Date
    * month takes the values 1-12
    * @param strDate in the format dd/mm//yyyy
    * @return date java.util.Date
    */
   public synchronized static java.util.Date getUtilDate(String strDate)throws Exception
   {
       /*java.util.Date date=null;

        if(!strDate.equals(""))
        {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        try
        {
        date=sdf.parse(strDate);
        }
        catch (ParseException exp)
        {
        throw new TTKException(exp,"error.date.format");
        }
        }
        return date;
        */
       java.util.Calendar calendar = java.util.Calendar.getInstance();
       if (strDate!=null && !strDate.equals(""))
       {
//           java.sql.Timestamp timeStamp = null;
           StringTokenizer strTokenDate = new StringTokenizer(strDate, "/");
           int intYear = 0;
           int intHH = 0;
           int intMM = 0;
           int intDay = Integer.parseInt(strTokenDate.nextToken());
           int intMonth = Integer.parseInt(strTokenDate.nextToken());
           String strYear = strTokenDate.nextToken(); // for tokenizing yyyy hh:mm
           //log.info("Day =="+intDay+"Month=="+intMonth+"Year=="+strYear);
           boolean bolFormat1 = strDate.matches("\\d{2}/\\d{2}/\\d{4}"); // check the dd/mm/yyyy format
           boolean bolFormat2 = strDate.matches("\\d{2}/\\d{2}/\\d{4} \\d{2}:\\d{2}"); // check the dd/mm/yyyy HH:MM format

           if (!(bolFormat1 | bolFormat2)) // NOTE : Returns true if bolFormat1 and bolFormat2 are both true; always evaluates bolFormat1 and bolFormat2
           {
               ParseException exp = new ParseException("Invalid Date Format",0);
               throw new Exception( "error.date.format");
           }// end of if(!(bolFormat1 | bolFormat2))

           StringTokenizer strTokenYear = new StringTokenizer(strYear);
           if (strTokenYear != null && strTokenYear.countTokens() > 1)
           {
               intYear = Integer.parseInt(strTokenYear.nextToken());
               String strTime = strTokenYear.nextToken();
               StringTokenizer strTokenTime = new StringTokenizer(strTime, ":");
               if (strTokenTime != null && strTokenTime.countTokens() > 1)
               {
                   intHH = Integer.parseInt(strTokenTime.nextToken());
                   intMM = Integer.parseInt(strTokenTime.nextToken());
               }//end of if (strTokenTime != null && strTokenTime.countTokens() > 1)
           }//end of if (strTokenYear != null && strTokenYear.countTokens() > 1)
           else
           {
               intYear = Integer.parseInt(strYear);
           }// end if(strTokenYear.countTokens()>1)
           calendar.clear();
           calendar.set(intYear, intMonth-1, intDay, intHH, intMM,0); // calendar will take month from 0-11 in script we get 1-12

//           timeStamp = new java.sql.Timestamp(calendar.getTimeInMillis());

           return calendar.getTime();
       }
       else
       {
           return null;
       }

   }//end of getUtilDate(String strDate)
   
   /**
    * This menthod for returns the cache description.
    * @param String strCasheId which holds cacheId value.
    * @param String strCache which holds the cache value.
    * @param String which returns cache description.
    * @exception throws TTKException
    */

   public static String getCacheDescription(String strCasheId,String strCache) throws Exception
   {
       if(strCasheId==null||strCache==null)
       {
           return null;
       }//end of if(strCasheId==null||strCache==null)

       CacheObject cacheObject=null;
       ArrayList alCache=(ArrayList)Cache.getCacheObject(strCache);

       if(alCache!=null&&alCache.size()>0)
       {
           for(int iCache=0;iCache<alCache.size();iCache++)
           {
               cacheObject = (CacheObject)alCache.get(iCache);
               if(strCasheId.equals(cacheObject.getCacheId()))
               {
                   return  cacheObject.getCacheDesc();
               }//end of if(strCasheId.equals(cacheObject.getCacheId()))
           }//end of for(int iCache=0;iCache<alCache.size();iCache++)
       }//end of if(alCache!=null&&alCache.size()>0)
       return "";
   }//end of getCacheDescription(String strCasheId,String strCache) throws TTKException

   public static ArrayList getUserGroupList(HttpServletRequest request)
   {
       return ((UserSecurityProfile)request.getSession().getAttribute("UserSecurityProfile")).getGroupList();
   }//end of getWebBoardId(HttpServletRequest request)
   
   public static int getInt(String strInt)throws Exception
   {
       int value=0;

       if(strInt!=null && !strInt.equals(""))
       {
           value=Integer.parseInt(strInt);
       }//end of if(strInt!=null && !strInt.equals(""))
       return value;
   }//end of getInt(String strInt)
   
   public static DataSource getDataSource(){
	   return (DataSource) WebApplicationContextUtils.getRequiredWebApplicationContext(getCurentRequestObject().getServletContext()).getBean("dbDataSource");
   }
   
   public static DataSource getDataSource2(){
	  
	   return (DataSource) WebApplicationContextUtils.getRequiredWebApplicationContext(getCurentRequestObject().getServletContext()).getBean("dbDataSource");
   }
   public static String getErrorDetails(Throwable throwable){
		String errorDetails="";
		throwable.printStackTrace();
		String errorKey="error.general";

		if(throwable instanceof VidalException){
			errorKey=(((VidalException)throwable).getErrorKey());
		}else if(throwable instanceof BatchUpdateException){
			SQLException sqlException = (SQLException)throwable;
			errorDetails=GetErrorMessage.getErrorMessage(sqlException.getMessage());
		}else if(throwable instanceof SQLException){
			SQLException sqlException=((SQLException)throwable);
			errorDetails=GetErrorMessage.getValue(sqlException.getErrorCode());
		}
		if(errorDetails==null||errorDetails.equals(""))
		errorDetails= GetErrorMessage.getValue(errorKey);
		return errorDetails;
	}
   public static synchronized  boolean exceptionStackTrace(Throwable exp,String filename)
   {
       try
       {
       	File ftest=new File(filename);
			if(!ftest.exists())
				ftest.createNewFile();
       	exp.printStackTrace();
           PrintWriter pw;
           pw = new PrintWriter( new FileWriter(filename,true) );//"//10.1.2.229/rcs/loginfo/exceptionttkstackTrace.log"
			pw.write("\n");
           pw.write("*****Start*****"+new Date()+"******************************");
           exp.printStackTrace( pw );
			pw.write("\n");
           pw.write("*****************************************************************End*"+new Date()+"+<BR>");
           pw.flush();
           pw.close();
       }//end of try
       catch(Throwable ex)
       {
          ex.printStackTrace();
       }//end of catch(Exception ex)
       return true;
    }//end of exceptionStackTrace()
   public static String getUserID(HttpServletRequest request)
   {
	  
       return ((UserSecurityProfile)request.getSession().getAttribute("userAccessSecurityProfile")).getUSER_ID();
   }
   public static Long getUserSeqId(HttpServletRequest request)
   {
       return ((UserSecurityProfile)request.getSession().getAttribute("userAccessSecurityProfile")).getUSER_SEQ_ID();
   }//end of getWebBoardId(HttpServletRequest request)
}

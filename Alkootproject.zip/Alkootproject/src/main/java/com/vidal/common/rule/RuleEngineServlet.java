/**
 * @ (#) RuleEngineServlet.java MAY 22, 2018
 * Project      : VINGS
 * File         : RuleEngineServlet.java
 * Author       : RISHABH KESHARI
 * Company      : VIDAL HEALTH
 * Date Created : MAY 22, 2018
 *
 * @author       :  RISHABH KESHARI
 * Modified by   :
 * Modified date :
 * Reason        : TO DISPLAY EXECUTED RULE DATA
 */


package com.vidal.common.rule;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;

import com.vidal.common.UXUtility;
import com.vidal.common.security.RuleXMLHelper;

public class RuleEngineServlet extends HttpServlet {
	
	/**
	* Comment for <code>serialVersionUID</code>
	*/
	private static final long serialVersionUID = 1L;
	
	private static Logger log = Logger.getLogger( RuleEngineServlet.class );
	RuleXMLHelper ruleXMLHelper = null;
	
	public void init(ServletConfig config) 
	{
		try
		{
			ServletContext context = config.getServletContext();
			String masterBaseRuleXmlFilePath = context.getRealPath("/WEB-INF/rules/MasterBaseRules.xml");
			String ruleconfigXmlFilePath = context.getRealPath("/WEB-INF/rules/ruleconfig.xml");
			
			File source = new File(ruleconfigXmlFilePath);
			
			File dest = new File(UXUtility.getPropertyValue("ruleconfigdir")+"ruleconfig.xml");
			try {
				String srcDirGeneralreports = context.getRealPath("/WEB-INF/reportsjrxml/reports/pricingreport");
				String destDirgeneralreports = UXUtility.getPropertyValue("generalreports");
				FileUtils.copyDirectory(new File(srcDirGeneralreports), new File(destDirgeneralreports));
				String srcDirrules = context.getRealPath("/WEB-INF/rules");
				String destDirrules = UXUtility.getPropertyValue("ruleconfigdir");
				FileUtils.copyDirectory(new File(srcDirrules), new File(destDirrules));
				String srcDirimages = context.getRealPath("/resources/vidal/images");
				String destDirimages = UXUtility.getPropertyValue("SignatureImgPath");
				FileUtils.copyDirectory(new File(srcDirimages), new File(destDirimages));
			//	String srcDirshortfallqueries = context.getRealPath("/WEB-INF/reportsjrxml/shortfallqueries");
			//String destDirshortfallqueries = UXUtility.getPropertyValue("shortfallrptQuestiondir");
			//	FileUtils.copyDirectory(new File(srcDirshortfallqueries), new File(destDirshortfallqueries));
				log.info("Copy done  RuleEngineServlet..Succesful..");//System.getProperty("user.dir")
			} catch (Exception e) {
			    e.printStackTrace();
			}
			
			
			
			log.info("Inside RuleEngineServlet....");
			ruleXMLHelper=new RuleXMLHelper();
			HashMap hmDisplayNodes=null;
			HashMap hmCopayResultNodes=null;
			//load the display nodes.
			//hmDisplayNodes=ruleXMLHelper.loadDisplayNodes(UXUtility.getDocument(masterBaseRuleXmlFilePath));
		//	hmCopayResultNodes=ruleXMLHelper.loadCopayResultNodes(UXUtility.getDocument(masterBaseRuleXmlFilePath));
			config.getServletContext().setAttribute("RULE_DISPLAY_NODES",hmDisplayNodes);
			config.getServletContext().setAttribute("RULE_COPAY_RESULT_NODES",hmCopayResultNodes);
		}//end of try
		catch (Exception e) {
			log.info("Scheduler failed to start cleanly: " + e.toString());
			e.printStackTrace();
		}//end of catch (Exception e)
	}//end of init()
	
	public void service(HttpServletRequest req, HttpServletResponse res)throws ServletException, IOException
	{
		log.info("Inside scheduler service method");
	}//end of service(HttpServletRequest req, HttpServletResponse res)
	
	public void destroy() {		
		try {
			if(ruleXMLHelper != null)
			{
				ruleXMLHelper = null;
			}//end of if(schedularServlet != null)
		}//end of try
		catch (Exception e) {
			log.info("Scheduler failed to shutdown cleanly: " + e.toString());
			e.printStackTrace();
		}//end of catch (Exception e)
		finally
		{
			ruleXMLHelper = null;
		}//end of finally
		log.info("Scheduler successful shutdown.");
	}//end of destroy()
}//end of RuleEngineServlet

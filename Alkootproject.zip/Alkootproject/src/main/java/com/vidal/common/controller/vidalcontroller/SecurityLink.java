package com.vidal.common.controller.vidalcontroller;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.vidal.command.usermanagement.UserSecurityProfile;
import com.vidal.common.UXUtility;
import com.vidal.common.exception.VidalException;

@Controller
public class SecurityLink {
	private static final Logger logger = LoggerFactory.getLogger(SecurityLink.class);
	
	@RequestMapping(value = "/defaultcontroler",method = RequestMethod.POST)
	public String doDefault(HttpServletRequest request){
		try {
			setLinks(request);
		} catch (VidalException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String home="home";
		
		StringBuffer sbfForwardPath=new StringBuffer();
		UserSecurityProfile userSecurityProfile=(UserSecurityProfile)request.getSession().getAttribute("userAccessSecurityProfile");
		
		sbfForwardPath.append(userSecurityProfile.getSecurityProfile().getActiveLink().replaceAll("\\s", "")).append("/");
        //sbfForwardPath.append(userSecurityProfile.getSecurityProfile().getActiveSubLink().replaceAll("\\s", "")).append("/");
        sbfForwardPath.append(userSecurityProfile.getSecurityProfile().getActiveTab().replaceAll("\\s", ""));
        logger.info("sbfForwardPath :"+sbfForwardPath.toString());
		return "forward:/"+sbfForwardPath+"";
	}

	protected void setLinks(HttpServletRequest request) throws VidalException{
		 	String strMenuLink = UXUtility.checkNull(request.getParameter("menulink"));
	        String strSubLink = UXUtility.checkNull(request.getParameter("sublink"));
	        String strSubMenuLink = UXUtility.checkNull(request.getParameter("submenulink"));
	        if(request.getSession().getAttribute("userAccessSecurityProfile")!=null)
	        {
	        	UserSecurityProfile userSecurityProfile=(UserSecurityProfile)request.getSession().getAttribute("userAccessSecurityProfile");
	        	if(userSecurityProfile.getSecurityProfile().getActiveLink().equals(""))
                {
                    userSecurityProfile.getSecurityProfile().setDefaultActiveLink();
                }//end of if(userSecurityProfile.getSecurityProfile().getActiveLink().equals(""))
                else
                {
                    userSecurityProfile.getSecurityProfile().setLinks(strMenuLink,strSubLink,strSubMenuLink);
                }
	        }
	        else
	        {
	            //vidalException.setMessage("error.session");
	            throw new VidalException("error.session.setlinks");
	        }
	}
}

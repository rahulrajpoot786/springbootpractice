package com.vidal.common.annotation;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import javax.validation.Constraint;
import javax.validation.Payload;

import com.vidal.common.annotation.validator.FieldNumericValidator;

@Documented
@Constraint(validatedBy = FieldNumericValidator.class)
@Target({ ElementType.METHOD, ElementType.FIELD, ElementType.TYPE})
@Retention(RetentionPolicy.RUNTIME)
public @interface FieldNumeric {
	String message() default "Numeric value require.";
	String agefield();
	
	Class<?>[] groups() default {};
	
	Class<? extends Payload>[] payload() default {};

	@Target({ ElementType.TYPE })
	@Retention(RetentionPolicy.RUNTIME)
	@interface List {
		FieldNumeric [] value();
	}

}

package com.vidal.common;

import java.util.HashMap;
import java.util.List;
import java.util.regex.Matcher;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.log4j.Logger;
import org.dom4j.Node;

import com.vidal.common.annotation.validator.ValidatorConstants;

public class CommandRuleValidations {
	private static Logger log = Logger.getLogger( CommandRuleValidations.class );
	private static HashMap<String, List<Node>> commandValidationsMap=null;
	private CommandRuleValidations() {
		
	}
	public static void load( HashMap<String, List<Node>> hmCommandValidations){
		commandValidationsMap=hmCommandValidations;
	}
	public static boolean hasFormErrors(String commandName,Object commandObject)throws Exception{
		try{
			
			
			if(commandValidationsMap==null||commandValidationsMap.isEmpty()) throw new Exception("command-validations.xml file not loaded properly please check log");

			List<Node> fieldNodeList=commandValidationsMap.get(commandName);
			
			if(fieldNodeList==null||fieldNodeList.isEmpty()) throw new Exception(commandName+" ,command name not found in command-validations.xml file please check log");
		
			HashMap<String, String> hmFielderrors=addErrors(commandObject,commandName,fieldNodeList);
			if(hmFielderrors!=null&&hmFielderrors.size()>0){
				HttpServletRequest request =VidalCommon.getCurentRequestObject();
				
				request.setAttribute("formErrors","true");
				request.setAttribute("V3FE-"+commandName, hmFielderrors);
				return true;
			}
			
		}catch(Exception exception){
			exception.printStackTrace();
			throw exception;
		}
		
		return false;
	}
	
	
	
	private static HashMap<String, String> addErrors(Object commandObject,String commandName,List<Node> fieldNodeList)throws Exception{
		
		HashMap<String, String> hmFielderrors=new HashMap<>();
		if(fieldNodeList!=null&&fieldNodeList.size()>0){
			
			
			for(Node fieldNode:fieldNodeList){
				String strFieldName=fieldNode.valueOf("@name");
				@SuppressWarnings("unchecked")
				List<Node> ruleNodeList=fieldNode.selectNodes("./rule");
				
				if(ruleNodeList!=null&&ruleNodeList.size()>0){
					
					for(Node ruleNode:ruleNodeList){
						
						if(hasFieldError(commandObject,commandName,strFieldName,ruleNode)){
							hmFielderrors.put(strFieldName, ruleNode.valueOf("@msg"));
							 break;
						}
						
					
					}//for(Node fieldNode:fieldNodeList){
					
				}//if(ruleNodeList!=null&&ruleNodeList.size()>0){
			}//for(Node fieldNode:fieldNodeList){
			
		}//if(fieldNodeList!=null&&fieldNodeList.size()>0){
		return hmFielderrors;
	}//private static HashMap<String, String> addErrors(Object commandObject,Node commandNode)throws Exception{
	
	private static boolean hasFieldError(Object commandObject,String strCommandName,String strFieldName,Node ruleNode)throws Exception{
		try{
		String fieldValu=	BeanUtils.getProperty(commandObject, strFieldName);
		String strRuleName=ruleNode.valueOf("@name");
		boolean valid=false;
		switch (strRuleName) {
		case "required":{
			if(fieldValu==null||fieldValu.trim().length()<1){
				valid=true;
			}
				break;	
		  }//required
		case "length":{
			
		if(fieldValu!=null&&fieldValu!=""){		
			String strMin=ruleNode.valueOf("@min");
			String strMax=ruleNode.valueOf("@max");
			if(strMin==null||strMin=="")strMin="0";
			if(strMax==null||strMax=="")strMax="0";
			int min=Integer.parseInt(strMin);
			int max=Integer.parseInt(strMax);
			
			valid=!((fieldValu.length()>=min)&&(fieldValu.length()<=max));
		}
				break;	
		}//length
		case "email":{
			if(fieldValu!=null&&fieldValu!=""){					
			Matcher regMatcher   = ValidatorConstants.emailRegexPattern.matcher(fieldValu);
			valid=!regMatcher.matches();
			}
			break;	
		}//email
		case "regExp":{
			if(fieldValu!=null&&fieldValu!=""){	
				String strRegExp=ruleNode.valueOf("@regExp");
			valid=!ValidatorConstants.splExpr.parseExpression("'"+fieldValu+"' matches '"+strRegExp+"'").getValue(Boolean.class);
			}
			break;	
		}//regExp
		case "validWhen":{
			if(fieldValu!=null&&fieldValu!=""){	
				String expression=ruleNode.valueOf("@expression");
			valid=!ValidatorConstants.splExpr.parseExpression(expression).getValue(commandObject,Boolean.class);
			}
			break;	
		}//regExp
		
		default:{
			throw new Exception("Rule name not defined please add/correct the name");			
		}
			
		}//switch (strRuleName) {
		return valid;
		}catch(Exception exception){
			log.error("Error while validatting command -"+strCommandName+"- field name -"+strFieldName+"- rule name -"+ruleNode.valueOf("@name"));
		throw exception;
		}
	
	}//private static boolean hasFieldError(Object commandObject,String strCommandName,String strFieldName,String strRuleName)throws Exception{
	
	
	
}

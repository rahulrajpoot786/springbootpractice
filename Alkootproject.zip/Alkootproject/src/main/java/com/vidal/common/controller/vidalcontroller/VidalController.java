package com.vidal.common.controller.vidalcontroller;

import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.ui.Model;
import org.springframework.web.servlet.ModelAndView;

import com.vidal.command.common.Toolbar;
import com.vidal.command.usermanagement.UserSecurityProfile;
import com.vidal.common.CommandRuleValidations;
import com.vidal.common.PopulateFields;
import com.vidal.common.UXUtility;
import com.vidal.common.VidalCommon;
import com.vidal.common.exception.GetErrorMessage;
import com.vidal.common.exception.VidalException;
import com.vidal.services.business.common.CacheService;
@Component
public class VidalController {
	private static Logger logger = Logger.getLogger( VidalController.class );
	 
	public static final String GLOBAL_ERROR="GLOBAL_ERROR";
	public static final String GLOBAL_ERROR_KEY="error.sc.global";
	public static final String SUCCESS_MESSAGE="SuccessMessage";
	
	protected ModelAndView processErrorView(HttpServletRequest request,String viewName,String errorKey,Map<String,Object> model,VidalException vidalExp){
		ModelAndView modelAndView=new ModelAndView(viewName);
		if(model!=null&&!model.isEmpty()&&model.size()>=1){ 
       	 Set<Entry<String, Object>> set=model.entrySet();
       	 for(Entry<String, Object> entry:set)modelAndView.addObject(entry.getKey(), entry.getValue());     	
       }       
       errorKey=(errorKey==null||errorKey.length()<1)?((vidalExp.getMessage() == null || vidalExp.getMessage().length() < 1 ) ? GLOBAL_ERROR_KEY : vidalExp.getMessage()):errorKey;
       request.setAttribute(GLOBAL_ERROR, GetErrorMessage.getValue(errorKey));
       return modelAndView;  
	}
	
	protected void setErrorPageData(String viewname,Model model){
		HttpServletRequest request =VidalCommon.getCurentRequestObject();
		request.setAttribute("errorPageView",viewname);
		request.setAttribute("modelObj", model);
	}
	
protected void populateData(String[] identfierList,String jspIdentifier)throws Exception{
	if(!PopulateFields.isPopulated(jspIdentifier)){
		cacheService.populateData(identfierList, jspIdentifier);
	}
}
protected void refreshPopulateData(String Identifier)throws Exception{

		cacheService.refreshPopulateData(Identifier);
	
}
protected void setLinks(HttpServletRequest request) throws Exception{
	String strSubMenuLink = UXUtility.checkNull(request.getParameter("tab")); 
//	logger.info(" strSubMenuLink : "+strSubMenuLink);
	if(request.getSession().getAttribute("userAccessSecurityProfile")!=null)
	{
		UserSecurityProfile userSecurityProfile=(UserSecurityProfile)request.getSession().getAttribute("userAccessSecurityProfile");
		if(userSecurityProfile.getSecurityProfile().getActiveLink().equals(""))
		{
			userSecurityProfile.getSecurityProfile().setDefaultActiveLink();
		}//end of if(userSecurityProfile.getSecurityProfile().getActiveLink().equals(""))
		else
		{
			userSecurityProfile.getSecurityProfile().setLinks(VidalCommon.getActiveLink(request),VidalCommon.getActiveSubLink(request),strSubMenuLink);
		}
	}
	else
	{
		//vidalException.setMessage("error.session");
		throw new VidalException("error.session.setlinks");
	}
	
	 if(request.getSession().getAttribute("toolbar")!=null)
     {
         StringBuffer sbfLinkPath=new StringBuffer();
         UserSecurityProfile userSecurityProfile=(UserSecurityProfile)request.getSession().
                                                 getAttribute("userAccessSecurityProfile");
         sbfLinkPath.append(userSecurityProfile.getSecurityProfile().getActiveLink()).append(".");
         sbfLinkPath.append(userSecurityProfile.getSecurityProfile().getActiveSubLink()).append(".");
         sbfLinkPath.append(userSecurityProfile.getSecurityProfile().getActiveTab());

         ((Toolbar)request.getSession().getAttribute("toolbar")).updateVisibility(sbfLinkPath.toString());
     }//end of if(request.getSession().getAttribute("toolbar")!=null)
}
protected ModelAndView processErrorView(String viewName,Throwable throwable){
	if("true".equals(VidalCommon.getCurentRequestObject().getAttribute("formErrors")))
		return new ModelAndView(viewName);
   else if("true".equals(VidalCommon.getCurentRequestObject().getAttribute("failurePage")))
	return new ModelAndView("failure").addObject("GLOBAL_ERROR", VidalCommon.getErrorDetails(throwable)); 
  else 
   return new ModelAndView(viewName).addObject("GLOBAL_ERROR", VidalCommon.getErrorDetails(throwable));  
}
protected void hasFormErrors(Object comandObject,String commandName)throws Exception {
	if(CommandRuleValidations.hasFormErrors(commandName, comandObject)){
		throw new VidalException("v3.form.errors");
	}
}
@Autowired
private CacheService cacheService;
}

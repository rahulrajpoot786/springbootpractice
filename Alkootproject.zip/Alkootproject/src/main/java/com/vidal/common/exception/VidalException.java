package com.vidal.common.exception;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class VidalException extends RuntimeException{
	
	/**
	 * 
	 */

	private static final long serialVersionUID = 1L;
	private static final Logger logger = LoggerFactory.getLogger(VidalException.class);

	/*public VidalException(Throwable rootCause,String strIdentifier){
		this.rootCause = rootCause;
		this.setIdentfier(strIdentifier);
		rootCause.printStackTrace();
		
		if(rootCause instanceof SQLException)
		{
			SQLException sqlExp = (SQLException)rootCause;
			this.setErrorKey(sqlExp.getErrorCode());
		}
		else if(rootCause instanceof NullPointerException)
		{

			this.setMessage("error.nullpointer");
		}
		else if(rootCause instanceof ArithmeticException)
		{

			this.setMessage("error.arithmeticexception");
		}
	}*/
	public VidalException(String errorKey)
	{
		super(errorKey);
		this.errorKey=errorKey;
	}
	
	
	/*protected Throwable rootCause = null;
	private String strMessage = null;
	private String strIdentfier = null;
	private int errorKey = 0;
	
	
	public int getErrorKey() {
		return errorKey;
	}
	public void setErrorKey(int errorKey) {
		this.errorKey = errorKey;
	}
	public void setMessage(String strMessage)
	{
		this.strMessage = strMessage;
	}
	public String getMessage()
	{
		return strMessage;
	}
	public void setIdentfier(String strIdentfier)
	{
		this.strIdentfier = strIdentfier;
	}
	public String getIdentfier()
	{
		return strIdentfier;
	}
	public Throwable getRootCause()
	{
		return rootCause;
	}*/
	
	private String errorKey = null;
		
	public void setErrorKey(String errorKey) {
		this.errorKey = errorKey;
	}
	public String getErrorKey() {
		return errorKey;
	}
	
}

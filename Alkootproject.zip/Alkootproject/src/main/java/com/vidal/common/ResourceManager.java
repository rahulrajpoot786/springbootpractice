package com.vidal.common;


import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

import com.vidal.common.reports.TTKPropertiesReader;

public class ResourceManager {
	/**
     * get a connection from the pool
     * @return Connection
     * @throws SQLException
     * @throws Exception
     */
	 private static DataSource ds = null;
	static{
		try{
		final Context context =(Context) new InitialContext();
		ds=(DataSource) context.lookup(TTKPropertiesReader.getPropertyValue("database.jndiName"));
		}catch(Exception e){
			e.printStackTrace();
		}
	}
    public  static DataSource getDataSource() throws Exception {

        return ds;
    }//end of getDataSource()
}

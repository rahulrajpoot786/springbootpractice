package com.vidal.common.listener;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

public class UXLoaderListener implements ServletContextListener{

	@Override
	public void contextDestroyed(ServletContextEvent servletContextEvent) {
		servletContextEvent.getServletContext().removeAttribute(servletContextEvent.getServletContext().getContextPath());
	}

	@Override
	public void contextInitialized(ServletContextEvent servletContextEvent) {
		servletContextEvent.getServletContext().setAttribute("rootPath", servletContextEvent.getServletContext().getContextPath());
	}

}

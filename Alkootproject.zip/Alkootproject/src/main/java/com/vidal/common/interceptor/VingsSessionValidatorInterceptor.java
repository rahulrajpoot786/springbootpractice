package com.vidal.common.interceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

public class VingsSessionValidatorInterceptor extends HandlerInterceptorAdapter{
	private static final Logger log = LoggerFactory.getLogger(VingsSessionValidatorInterceptor.class);
	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
		//log.info("Inside VingsSessionValidatorInterceptor preHandle() "+request.getServletContext());
		if(request.getSession().getAttribute("userAccessSecurityProfile") != null)return true;
		else{
			request.getSession().invalidate();response.sendRedirect((String)request.getServletContext().getContextPath()+"/forwardpath");
			return false;
		}
	}
}

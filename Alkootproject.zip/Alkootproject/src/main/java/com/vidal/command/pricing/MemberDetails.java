package com.vidal.command.pricing;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;

public class MemberDetails {
	
	private MemberData memberData;

	private String uploadstatus;
	public MemberDetails() {}
	
	public MemberDetails(String uploadstatus, MemberData payments) {
		super();	
		this.uploadstatus=uploadstatus;
		this.memberData=memberData;	
		}
	
	@XmlElement
	public MemberData getMemberData() {
		return memberData;
	}

	public void setMemberData(MemberData memberData) {
		this.memberData = memberData;
	}
	@XmlAttribute
	public String getUploadstatus() {
		return uploadstatus;
	}
	public void setUploadstatus(String uploadstatus) {
		this.uploadstatus = uploadstatus;
	}

}

package com.vidal.command;

import java.util.Date;

public interface Bean {
	/**
     * gets id
     * @return id int
     */
    public int getId();

    /**
     * sets id
     * @param id int
     */
    public void setId(int id);

    /**
     * gets timestamp
     * @return timestamp Date
     */
    public Date getTimestamp();

    /**
     * sets timestamp
     * @param timestamp Date
     */
    public void setTimestamp(Date timestamp);
}

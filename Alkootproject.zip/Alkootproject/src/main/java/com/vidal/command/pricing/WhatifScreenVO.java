package com.vidal.command.pricing;

import java.util.Date;

import com.vidal.command.base.BaseVO;
import com.vidal.common.annotation.ValidWhen;

/**
 * @author gyanendra.srivastava
 *
 */
@ValidWhen.List({	
	@ValidWhen(expression = "((coverageStartDatestr != ''))", message = "'Coverage start date' is required."),	
	@ValidWhen(expression = "((coverageEndDatestr != ''))", message = "'Coverage end date' is required."),		
	@ValidWhen(expression = "((areaofcover != null))", message = "'Area of cover' is required."),	
	@ValidWhen(expression = "((Inpatientip != ''))", message = "'Inpatient (IP)' is required."),
	@ValidWhen(expression = "((Outpatientop != ''))", message = "'Outpatient (OP)' is required."),
	@ValidWhen(expression = "((Maximumbenefitlimit != null))", message = "'Maximum benefit limit' is required."),
	@ValidWhen(expression = "((opLimit != null))", message = "'OP Limit' is required."),
	
	@ValidWhen(expression = "( (optical != 'Y') or (opticallimit != null))", message = "'Optical limit' is required."),
	@ValidWhen(expression = "( (optical != 'Y') or (opticalcopay != null))", message = "'Optical copay' is required."),
	@ValidWhen(expression = "( (optical != 'Y') or (frameslimit != null))", message = "'Frames limit' is required."),
	
	@ValidWhen(expression = "( (dental != 'Y') or (dentallimit != null))", message = "'Dental limit' is required."),
	@ValidWhen(expression = "( (dental != 'Y') or (dentalcopaydeductible != null))", message = "'Dental copay/deductible' is required."),
	@ValidWhen(expression = "( (dental != 'Y') or (orthodonticscopay != null))", message = "'Orthodontics copay' is required."),
	@ValidWhen(expression = "((alAhliHospitalcoverage != ''))", message = "'Al Ahli Hospital coverage' is required."),	
	
	
	@ValidWhen(expression = "( (maternity != 'Y') or (maternitylimit != null))", message = "'Maternity limit' is required."),
	@ValidWhen(expression = "( (maternity != 'Y') or (maternitycopaydeductible != null))", message = "'Maternity copay/deductible' is required."),
	
	@ValidWhen(expression = "( (alAhliHospitalcoverage != 'Y') or (oPcopayatAlAhli != null))", message = "'OP copay at Al Ahli' is required."),	
	@ValidWhen(expression = "((alAhliHospitalcoverage != 'Y') or (iPcopayatAlAhli != null))", message = "'IP copay at Al Ahli' is required."),
	
	/*@ValidWhen(expression = "((countryofresidence != null))", message = "'Country of residence' is required."),*/
	@ValidWhen(expression = "((proratalimitapplicable != ''))", message = "'Pro-rata limit applicable' is required."),
	@ValidWhen(expression = "((premumrefundapproach != ''))", message = "'Premum refund approach' is required."),
	@ValidWhen(expression = "((trend != null))", message = "'Trend' is required."),
	
	
	
})

public class WhatifScreenVO extends BaseVO {
	
	
	
	 /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String inpatientip = "";
	 private String outpatientop = "";
	 private Long maximumbenefitlimit = null;
	 private Long opLimit = null;
	 
	 private Long areaofcover = null;
	 private Long networkcommon = null;
	 private String networkip = "";
	 private String networkop = "";
	 private String networkopt = "";
	 private String networkdnt = "";
	 private String networkmat = "";
	 private String areaofcovernext = "";
	 private String loadingforareaofcover = "";
	 
	 private Long loadingforareaofcoverip = null;
	 private Long loadingforareaofcoverop = null;
	 private Long loadingforareaofcoveropt = null;
	 private Long loadingforareaofcoverdent = null;
	 private Long loadingforareaofcovermat = null;
	 
	 private Long loadingforareaofcoveriptemp = null;
	 private Long loadingforareaofcoveroptemp = null;
	 private Long loadingforareaofcoveropttemp = null;
	 private Long loadingforareaofcoverdenttemp = null;
	 private Long loadingforareaofcovermattemp = null;
	 
	 private Long discountforareaofcoverip = null;
	 private Long discountforareaofcoverop = null;
	 private Long discountforareaofcoveropt = null;
	 private Long discountforareaofcoverdent = null;
	 private Long discountforareaofcovermat = null;
	 
	 private Long discountforareaofcoveriptemp = null;
	 private Long discountforareaofcoveroptemp = null;
	 private Long discountforareaofcoveropttemp = null;
	 private Long discountforareaofcoverdenttemp = null;
	 private Long discountforareaofcovermattemp = null;
	 
	 private Long iPcopay = null;
	 private String iPcopaydesc="";
	
	 private String oPcopaydeductibleapplicable = "";
	 
	 private Long oPCopayDeductible = null;
	 private String oPCopayDeductibledesc = "";
	 
	 private Long oPpharmacycopay = null;	 
	 private String oPpharmacycopaydesc = "";
	 
	 private Long oPinvestigationcopay = null;	 
	 private String oPinvestigationcopaydesc = "";
	 
	 private Long oPconsultationcopay = null;
	 private String oPconsultationcopaydesc = "";
	 
	 private Long oPcopayonotherservices = null;
	 private String oPcopayonotherservicesdesc = "";
	 
	 
	 private String alAhliHospitalcoverage = "";
	 private String oPcopaydeductibleatAlAhli = "";
	 
	 private Long oPcopayatAlAhli = null;
	 private String oPcopayatAlAhlidesc = "";
	 
	 
	 private Long oPpharmacycopayatalAhli = null;
	 private String oPpharmacycopayatalAhlidesc = "";
	 
	 private Long oPinvestigationcopayatAlAhli = null;
	 private String oPinvestigationcopayatAlAhlidesc = "";
	 
	 private Long oPconsultationcopayatAlAhli = null;
	 
	 private String oPconsultationcopayatAlAhlidesc = "";
	 
	 
	 private Long oPotherservicescopayatAlAhli = null;
	 
	 private String oPotherservicescopayatAlAhlidesc="";
	 
	 
	 private Long iPcopayatAlAhli = null;
	 private String iPcopayatAlAhlidesc ="";
	 
	 
	 private String additionalhospitalcoverage = "";
	 private String additionalhospitalcoveragedesc = "";
	 
	 private Long loadingforadditionalhospitalcoverage = null;
	 
	 private String commentsloadingforadditional = "";
	 private String hospitalexclusions = "";
	 private String hospitalexclusionsdesc = "";
	 
	 private Long discountforhospitalexclusions = null;
	 
	 
	 private String commentsdiscountforhospital = "";
	 private String optical = "";
	 private Long opticallimit = null;
	 private Long opticalcopay = null;
	 private String opticalcopaydesc = "";
	 
	 private Long frameslimit = null;
	 
	 private String dental = "";
	 
	 private Long dentallimit = null;
	 
	 private Long dentalcopaydeductible = null;
	 private String dentalcopaydeductibledesc = "";
	 
	 private String orthodontics = "";
	 
	 private Long orthodonticscopay = null;
	 private String orthodonticscopaydesc = "";
	 
	 private String maternity = "";
	 private Long maternitylimit = null;
	 private Long maternitycopaydeductible = null;
	 private String maternitycopaydeductibledesc = "";
	 
	 private Long countryofresidence = null;
	 
	 private Long loadingforcountryofresidenceip = null;
	 private Long loadingforcountryofresidenceop = null;
	 private Long loadingforcountryofresidenceopt = null;
	 private Long loadingforcountryofresidencedent = null;
	 private Long loadingforcountryofresidencemat = null;
	 
	 private Long trend = null;
	 
	 private String proratalimitapplicable = "";
	 private String premumrefundapproach = "";
	 private String tableInpatient = "";
	 private String tableoutpatient = "";
	 private String tableOptical = "";
	 private String tableDental = "";
	 private String tableMaternity = "";
	 private String tableOverall = "";
	 
	 private Long versionSeqId = null;
	 private Long groupProSeqId=null;
	 private Long versionVal=null;
	 private Date coverageStartDate=null;
	 private Date coverageEndDate=null;
	 
	 private String coverageStartDatestr=null;
	 private String coverageEndDatestr=null;
	 
	 private String tabCount="";
	 private String finalCount="";
	 
	 private String maternityOtherLimit="";
	 private String maxiMumBenefitOtherLimit="";
	
	 private String opLimitOtherLimit="";
	 private String opticalOtherLimit="";
	 private String dentalOtherLimit="";
	 
	 
	 
	 //..............display .............
	 
	 private String coverdStartDatedes="";
	 private String coverdEndDatedes="";
	 
	 private String inpatientipdes = "";
	 private String outpatientopdes = "";
	 private String maximumbenefitlimitdes = "";
	 private String maxiOpLimitdes = "";
	 private String areaofcoverdes = "";
	 private String networkcommondes = "";
	 private String networkcommonBenefitsdes="";
	 private String networkipdes = "";
	 private String networkopdes = "";
	 private String networkoptdes = "";
	 private String networkdntdes = "";
	 private String networkmatdes = "";
	 private String areaofcovernextdes = "";
	 private String loadingforareaofcoverdes = "";
	 private String discountforareaofcoverdes = "";
	 
	 private String loadingforareaofcoveripdes = "";
	 private String loadingforareaofcoveropdes = "";
	 private String loadingforareaofcoveroptdes = "";
	 private String loadingforareaofcoverdentdes = "";
	 private String loadingforareaofcovermatdes = "";
	 private String iPcopaydes = "";
	
	 private String oPcopaydeductibleapplicabledes = "";
	 private String oPCopayDeductibledes = "";
	 private String oPpharmacycopaydes = "";
	 private String oPinvestigationcopaydes = "";
	 private String oPconsultationcopaydes = "";
	 private String oPcopayonotherservicesdes = "";
	 
	 private String alAhliHospitalcoveragedes = "";
	 
	 private String oPcopaydeductibleatAlAhlides = "";
	 private String oPcopayatAlAhlides = "";
	 private String oPpharmacycopayatalAhlides = "";
	 private String oPinvestigationcopayatAlAhlides = "";
	 
	 private String oPconsultationcopayatAlAhlides = "";
	 
	 private String oPotherservicescopayatAlAhlides = "";
	 
	 private String iPcopayatAlAhlides = "";
	 private String additionalhospitalcoveragedes = "";
	 private String loadingforadditionalhospitalcoveragedes = "";
	 private String commentsloadingforadditionaldes = "";
	 private String hospitalexclusionsdes = "";
	 private String discountforhospitalexclusionsdes = "";
	 private String commentsdiscountforhospitaldes = "";
	 private String opticaldes = "";
	 private String opticallimitdes = "";
	 private String opticalCopaydes="";

	 private String frameslimitdes = "";
	 private String dentaldes = "";
	 private String dentallimitdes = "";
	 private String dentalcopaydeductibledes = "";
	 private String orthodonticsdes = "";
	 private String orthodonticscopaydes = "";
	 private String maternitydes = "";
	 private String maternitylimitdes = "";
	 private String maternitycopaydeductibledes = "";
	 
	 private String countryofresidencedes = "";
	 private String loadingforcountryofresidencedes = "";
	 private String trenddes = "";
	 
	 private String proratalimitapplicabledes = "";
	 private String premumrefundapproachdes = "";
	 private String tableInpatientdes = "";
	 private String tableoutpatientdes = "";
	 private String tableOpticaldes = "";
	 private String tableDentaldes = "";
	 private String tableMaternitydes = "";
	 private String tableOveralldes = "";
	 
	 private String estimateChangeip="";
	 private String estimateChangeOp="";
	 private String estimateChangeOpt="";
	 private String estimateChangeDen="";
	 private String estimateChangeMen="";
	 private String estimateChangeOverAll="";
	 
	 private String estimateChangeipmark="";
	 private String estimateChangeOpmark="";
	 private String estimateChangeOptmark="";
	 private String estimateChangeDenmark="";
	 private String estimateChangeMenmark="";
	 private String estimateChangeOverAllmark="";
	 private String areaCoverFlag="";
	 
	// ........color dispaly...........
	
		private String inpatientipColor = "";
		 private String outpatientopColor = "";
		 private String maximumbenefitlimitColor = null;
		 private String opLimitColor = null;
		 
		 private String areaofcoverColor = null;
		 private String networkcommonColor = null;
		 private String networkipColor = "";
		 private String networkopColor = "";
		 private String networkoptColor = "";
		 private String networkdntColor = "";
		 private String networkmatColor = "";
		 private String areaofcovernextColor = "";
		 private String loadingforareaofcoverColor = "";
		 
		 private String loadingforareaofcoveripColor = null;
		 private String loadingforareaofcoveropColor = null;
		 private String loadingforareaofcoveroptColor = null;
		 private String loadingforareaofcoverdentColor = null;
		 private String loadingforareaofcovermatColor = null;
		 
		 private String discountforareaofcoveripColor = null;
		 private String discountforareaofcoveropColor = null;
		 private String discountforareaofcoveroptColor = null;
		 private String discountforareaofcoverdentColor = null;
		 private String discountforareaofcovermatColor = null;
		 
		 private String iPcopayColor = null;
		 private String iPcopaydescColor="";
		
		 private String oPcopaydeductibleapplicableColor = "";
		 
		 private String oPCopayDeductibleColor = null;
		 private String oPCopayDeductibledescColor = "";
		 
		 private String oPpharmacycopayColor = null;	 
		 private String oPpharmacycopaydescColor = "";
		 
		 private String oPinvestigationcopayColor = null;	 
		 private String oPinvestigationcopaydescColor = "";
		 
		 private String oPconsultationcopayColor = null;
		 private String oPconsultationcopaydescColor = "";
		 
		 private String oPcopayonotherservicesColor = null;
		 private String oPcopayonotherservicesdescColor = "";
		 
		 
		 private String alAhliHospitalcoverageColor = "";
		 private String oPcopaydeductibleatAlAhliColor = "";
		 
		 private String oPcopayatAlAhliColor = null;
		 private String oPcopayatAlAhlidescColor = "";
		 
		 
		 private String oPpharmacycopayatalAhliColor = null;
		 private String oPpharmacycopayatalAhlidescColor = "";
		 
		 private String oPinvestigationcopayatAlAhliColor = null;
		 private String oPinvestigationcopayatAlAhlidescColor = "";
		 
		 private String oPconsultationcopayatAlAhliColor = null;
		 
		 private String oPconsultationcopayatAlAhlidescColor = "";
		 
		 
		 private String oPotherservicescopayatAlAhliColor = null;
		 
		 private String oPotherservicescopayatAlAhlidescColor="";
		 
		 
		 private String iPcopayatAlAhliColor = null;
		 private String iPcopayatAlAhlidescColor ="";
		 
		 
		 private String additionalhospitalcoverageColor = "";
		 private String additionalhospitalcoveragedescColor = "";
		 
		 private String loadingforadditionalhospitalcoverageColor = null;
		 
		 private String commentsloadingforadditionalColor = "";
		 private String hospitalexclusionsColor = "";
		 private String hospitalexclusionsdescColor = "";
		 
		 private String discountforhospitalexclusionsColor = null;
		 
		 
		 private String commentsdiscountforhospitalColor = "";
		 private String opticalColor = "";
		 private String opticallimitColor = null;
		 private String opticalcopayColor = null;
		 private String opticalcopaydescColor = "";
		 
		 private String frameslimitColor = null;
		 
		 private String dentalColor = "";
		 
		 private String dentallimitColor = null;
		 
		 private String dentalcopaydeductibleColor = null;
		 private String dentalcopaydeductibledescColor = "";
		 
		 private String orthodonticsColor = "";
		 
		 private String orthodonticscopayColor = null;
		 private String orthodonticscopaydescColor = "";
		 
		 private String maternityColor = "";
		 private String maternitylimitColor = null;
		 private String maternitycopaydeductibleColor = null;
		 private String maternitycopaydeductibledescColor = "";
		 
		 private String countryofresidenceColor = null;
		 
		 private String loadingforcountryofresidenceipColor = null;
		 private String loadingforcountryofresidenceopColor = null;
		 private String loadingforcountryofresidenceoptColor = null;
		 private String loadingforcountryofresidencedentColor = null;
		 private String loadingforcountryofresidencematColor = null;
		 
		 private String trendColor = null;
		 
		 private String proratalimitapplicableColor = "";
		 private String premumrefundapproachColor = "";
		 private String tableInpatientColor = "";
		 private String tableoutpatientColor = "";
		 private String tableOpticalColor = "";
		 private String tableDentalColor = "";
		 private String tableMaternityColor = "";
		 private String tableOverallColor = "";
		 
		 private String versionSeqIdColor = null;
		 private String groupProSeqIdColor=null;
		 private String versionValColor=null;
		
		 
		 private String coverageStartDatestrColor=null;
		 private String coverageEndDatestrColor=null;
		 
 	 
	    private Long result=null;
	 
	    private String lastSaveDate="";
	 
	    private String saveYn="";
	    
	    private Integer versionCount;
	    
	 
	 
	public String getMaternityOtherLimit() {
			return maternityOtherLimit;
		}
		public void setMaternityOtherLimit(String maternityOtherLimit) {
			this.maternityOtherLimit = maternityOtherLimit;
		}
	public String getLastSaveDate() {
		return lastSaveDate;
	}
	public void setLastSaveDate(String lastSaveDate) {
		this.lastSaveDate = lastSaveDate;
	}
	public Long getResult() {
		return result;
	}
	public void setResult(Long result) {
		this.result = result;
	}

	public String getInpatientip() {
		return inpatientip;
	}
	public void setInpatientip(String inpatientip) {
		this.inpatientip = inpatientip;
	}
	public String getOutpatientop() {
		return outpatientop;
	}
	public void setOutpatientop(String outpatientop) {
		this.outpatientop = outpatientop;
	}
	

	

	public String getNetworkip() {
		return networkip;
	}
	public void setNetworkip(String networkip) {
		this.networkip = networkip;
	}
	public String getNetworkop() {
		return networkop;
	}
	public void setNetworkop(String networkop) {
		this.networkop = networkop;
	}
	public String getNetworkopt() {
		return networkopt;
	}
	public void setNetworkopt(String networkopt) {
		this.networkopt = networkopt;
	}
	public String getNetworkdnt() {
		return networkdnt;
	}
	public void setNetworkdnt(String networkdnt) {
		this.networkdnt = networkdnt;
	}
	public String getNetworkmat() {
		return networkmat;
	}
	public void setNetworkmat(String networkmat) {
		this.networkmat = networkmat;
	}
	public String getAreaofcovernext() {
		return areaofcovernext;
	}
	public void setAreaofcovernext(String areaofcovernext) {
		this.areaofcovernext = areaofcovernext;
	}
	public String getLoadingforareaofcover() {
		return loadingforareaofcover;
	}
	public void setLoadingforareaofcover(String loadingforareaofcover) {
		this.loadingforareaofcover = loadingforareaofcover;
	}
	
	

	
	

	public Long getiPcopay() {
		return iPcopay;
	}
	public void setiPcopay(Long iPcopay) {
		this.iPcopay = iPcopay;
	}
	public String getiPcopaydesc() {
		return iPcopaydesc;
	}
	public void setiPcopaydesc(String iPcopaydesc) {
		this.iPcopaydesc = iPcopaydesc;
	}
	public String getoPcopaydeductibleapplicable() {
		return oPcopaydeductibleapplicable;
	}
	public void setoPcopaydeductibleapplicable(String oPcopaydeductibleapplicable) {
		this.oPcopaydeductibleapplicable = oPcopaydeductibleapplicable;
	}
		
	
	public Long getoPcopayonotherservices() {
		return oPcopayonotherservices;
	}
	public void setoPcopayonotherservices(Long oPcopayonotherservices) {
		this.oPcopayonotherservices = oPcopayonotherservices;
	}
	public String getoPcopayonotherservicesdesc() {
		return oPcopayonotherservicesdesc;
	}
	public void setoPcopayonotherservicesdesc(String oPcopayonotherservicesdesc) {
		this.oPcopayonotherservicesdesc = oPcopayonotherservicesdesc;
	}
	public String getAlAhliHospitalcoverage() {
		return alAhliHospitalcoverage;
	}
	public void setAlAhliHospitalcoverage(String alAhliHospitalcoverage) {
		this.alAhliHospitalcoverage = alAhliHospitalcoverage;
	}
	public String getoPcopaydeductibleatAlAhli() {
		return oPcopaydeductibleatAlAhli;
	}
	public void setoPcopaydeductibleatAlAhli(String oPcopaydeductibleatAlAhli) {
		this.oPcopaydeductibleatAlAhli = oPcopaydeductibleatAlAhli;
	}
		


	
	public String getAdditionalhospitalcoverage() {
		return additionalhospitalcoverage;
	}
	public void setAdditionalhospitalcoverage(String additionalhospitalcoverage) {
		this.additionalhospitalcoverage = additionalhospitalcoverage;
	}
	

	
	public String getCommentsloadingforadditional() {
		return commentsloadingforadditional;
	}
	public void setCommentsloadingforadditional(String commentsloadingforadditional) {
		this.commentsloadingforadditional = commentsloadingforadditional;
	}
	public String getHospitalexclusions() {
		return hospitalexclusions;
	}
	public void setHospitalexclusions(String hospitalexclusions) {
		this.hospitalexclusions = hospitalexclusions;
	}
	
	
	public String getCommentsdiscountforhospital() {
		return commentsdiscountforhospital;
	}
	public void setCommentsdiscountforhospital(String commentsdiscountforhospital) {
		this.commentsdiscountforhospital = commentsdiscountforhospital;
	}
	public String getOptical() {
		return optical;
	}
	public void setOptical(String optical) {
		this.optical = optical;
	}


	public String getDental() {
		return dental;
	}
	public void setDental(String dental) {
		this.dental = dental;
	}
	
	public String getOrthodontics() {
		return orthodontics;
	}
	public void setOrthodontics(String orthodontics) {
		this.orthodontics = orthodontics;
	}
	
	public String getMaternity() {
		return maternity;
	}
	public void setMaternity(String maternity) {
		this.maternity = maternity;
	}
		
	
	public Long getMaternitycopaydeductible() {
		return maternitycopaydeductible;
	}
	public void setMaternitycopaydeductible(Long maternitycopaydeductible) {
		this.maternitycopaydeductible = maternitycopaydeductible;
	}
	public String getMaternitycopaydeductibledesc() {
		return maternitycopaydeductibledesc;
	}
	public void setMaternitycopaydeductibledesc(String maternitycopaydeductibledesc) {
		this.maternitycopaydeductibledesc = maternitycopaydeductibledesc;
	}
	

	
	public Long getCountryofresidence() {
		return countryofresidence;
	}
	public void setCountryofresidence(Long countryofresidence) {
		this.countryofresidence = countryofresidence;
	}

	

	public Long getLoadingforcountryofresidenceip() {
		return loadingforcountryofresidenceip;
	}
	public void setLoadingforcountryofresidenceip(Long loadingforcountryofresidenceip) {
		this.loadingforcountryofresidenceip = loadingforcountryofresidenceip;
	}
	public Long getLoadingforcountryofresidenceop() {
		return loadingforcountryofresidenceop;
	}
	public void setLoadingforcountryofresidenceop(Long loadingforcountryofresidenceop) {
		this.loadingforcountryofresidenceop = loadingforcountryofresidenceop;
	}
	public Long getLoadingforcountryofresidenceopt() {
		return loadingforcountryofresidenceopt;
	}
	public void setLoadingforcountryofresidenceopt(Long loadingforcountryofresidenceopt) {
		this.loadingforcountryofresidenceopt = loadingforcountryofresidenceopt;
	}
	public Long getLoadingforcountryofresidencedent() {
		return loadingforcountryofresidencedent;
	}
	public void setLoadingforcountryofresidencedent(Long loadingforcountryofresidencedent) {
		this.loadingforcountryofresidencedent = loadingforcountryofresidencedent;
	}
	public Long getLoadingforcountryofresidencemat() {
		return loadingforcountryofresidencemat;
	}
	public void setLoadingforcountryofresidencemat(Long loadingforcountryofresidencemat) {
		this.loadingforcountryofresidencemat = loadingforcountryofresidencemat;
	}
	public String getProratalimitapplicable() {
		return proratalimitapplicable;
	}
	public void setProratalimitapplicable(String proratalimitapplicable) {
		this.proratalimitapplicable = proratalimitapplicable;
	}
	public String getPremumrefundapproach() {
		return premumrefundapproach;
	}
	public void setPremumrefundapproach(String premumrefundapproach) {
		this.premumrefundapproach = premumrefundapproach;
	}
	public String getTableInpatient() {
		return tableInpatient;
	}
	public void setTableInpatient(String tableInpatient) {
		this.tableInpatient = tableInpatient;
	}
	public String getTableoutpatient() {
		return tableoutpatient;
	}
	public void setTableoutpatient(String tableoutpatient) {
		this.tableoutpatient = tableoutpatient;
	}
	public String getTableOptical() {
		return tableOptical;
	}
	public void setTableOptical(String tableOptical) {
		this.tableOptical = tableOptical;
	}
	public String getTableDental() {
		return tableDental;
	}
	public void setTableDental(String tableDental) {
		this.tableDental = tableDental;
	}
	public String getTableMaternity() {
		return tableMaternity;
	}
	public void setTableMaternity(String tableMaternity) {
		this.tableMaternity = tableMaternity;
	}
	public String getTableOverall() {
		return tableOverall;
	}
	public void setTableOverall(String tableOverall) {
		this.tableOverall = tableOverall;
	}
	public String getInpatientipdes() {
		return inpatientipdes;
	}
	public void setInpatientipdes(String inpatientipdes) {
		this.inpatientipdes = inpatientipdes;
	}
	public String getOutpatientopdes() {
		return outpatientopdes;
	}
	public void setOutpatientopdes(String outpatientopdes) {
		this.outpatientopdes = outpatientopdes;
	}
	public String getMaximumbenefitlimitdes() {
		return maximumbenefitlimitdes;
	}
	public void setMaximumbenefitlimitdes(String maximumbenefitlimitdes) {
		this.maximumbenefitlimitdes = maximumbenefitlimitdes;
	}
	public String getAreaofcoverdes() {
		return areaofcoverdes;
	}
	public void setAreaofcoverdes(String areaofcoverdes) {
		this.areaofcoverdes = areaofcoverdes;
	}
	public String getNetworkcommondes() {
		return networkcommondes;
	}
	public void setNetworkcommondes(String networkcommondes) {
		this.networkcommondes = networkcommondes;
	}
	public String getNetworkipdes() {
		return networkipdes;
	}
	public void setNetworkipdes(String networkipdes) {
		this.networkipdes = networkipdes;
	}
	public String getNetworkopdes() {
		return networkopdes;
	}
	public void setNetworkopdes(String networkopdes) {
		this.networkopdes = networkopdes;
	}
	public String getNetworkoptdes() {
		return networkoptdes;
	}
	public void setNetworkoptdes(String networkoptdes) {
		this.networkoptdes = networkoptdes;
	}
	public String getNetworkdntdes() {
		return networkdntdes;
	}
	public void setNetworkdntdes(String networkdntdes) {
		this.networkdntdes = networkdntdes;
	}
	public String getNetworkmatdes() {
		return networkmatdes;
	}
	public void setNetworkmatdes(String networkmatdes) {
		this.networkmatdes = networkmatdes;
	}
	public String getAreaofcovernextdes() {
		return areaofcovernextdes;
	}
	public void setAreaofcovernextdes(String areaofcovernextdes) {
		this.areaofcovernextdes = areaofcovernextdes;
	}
	public String getLoadingforareaofcoverdes() {
		return loadingforareaofcoverdes;
	}
	public void setLoadingforareaofcoverdes(String loadingforareaofcoverdes) {
		this.loadingforareaofcoverdes = loadingforareaofcoverdes;
	}
	public String getLoadingforareaofcoveripdes() {
		return loadingforareaofcoveripdes;
	}
	public void setLoadingforareaofcoveripdes(String loadingforareaofcoveripdes) {
		this.loadingforareaofcoveripdes = loadingforareaofcoveripdes;
	}
	public String getLoadingforareaofcoveropdes() {
		return loadingforareaofcoveropdes;
	}
	public void setLoadingforareaofcoveropdes(String loadingforareaofcoveropdes) {
		this.loadingforareaofcoveropdes = loadingforareaofcoveropdes;
	}
	public String getLoadingforareaofcoveroptdes() {
		return loadingforareaofcoveroptdes;
	}
	public void setLoadingforareaofcoveroptdes(String loadingforareaofcoveroptdes) {
		this.loadingforareaofcoveroptdes = loadingforareaofcoveroptdes;
	}
	public String getLoadingforareaofcoverdentdes() {
		return loadingforareaofcoverdentdes;
	}
	public void setLoadingforareaofcoverdentdes(String loadingforareaofcoverdentdes) {
		this.loadingforareaofcoverdentdes = loadingforareaofcoverdentdes;
	}
	public String getLoadingforareaofcovermatdes() {
		return loadingforareaofcovermatdes;
	}
	public void setLoadingforareaofcovermatdes(String loadingforareaofcovermatdes) {
		this.loadingforareaofcovermatdes = loadingforareaofcovermatdes;
	}
	public String getiPcopaydes() {
		return iPcopaydes;
	}
	public void setiPcopaydes(String iPcopaydes) {
		this.iPcopaydes = iPcopaydes;
	}
	public String getoPcopaydeductibleapplicabledes() {
		return oPcopaydeductibleapplicabledes;
	}
	public void setoPcopaydeductibleapplicabledes(String oPcopaydeductibleapplicabledes) {
		this.oPcopaydeductibleapplicabledes = oPcopaydeductibleapplicabledes;
	}
	public String getoPCopayDeductibledes() {
		return oPCopayDeductibledes;
	}
	public void setoPCopayDeductibledes(String oPCopayDeductibledes) {
		this.oPCopayDeductibledes = oPCopayDeductibledes;
	}
	public String getoPpharmacycopaydes() {
		return oPpharmacycopaydes;
	}
	public void setoPpharmacycopaydes(String oPpharmacycopaydes) {
		this.oPpharmacycopaydes = oPpharmacycopaydes;
	}
	public String getoPinvestigationcopaydes() {
		return oPinvestigationcopaydes;
	}
	public void setoPinvestigationcopaydes(String oPinvestigationcopaydes) {
		this.oPinvestigationcopaydes = oPinvestigationcopaydes;
	}
	public String getoPconsultationcopaydes() {
		return oPconsultationcopaydes;
	}
	public void setoPconsultationcopaydes(String oPconsultationcopaydes) {
		this.oPconsultationcopaydes = oPconsultationcopaydes;
	}
	public String getoPcopayonotherservicesdes() {
		return oPcopayonotherservicesdes;
	}
	public void setoPcopayonotherservicesdes(String oPcopayonotherservicesdes) {
		this.oPcopayonotherservicesdes = oPcopayonotherservicesdes;
	}
	public String getAlAhliHospitalcoveragedes() {
		return alAhliHospitalcoveragedes;
	}
	public void setAlAhliHospitalcoveragedes(String alAhliHospitalcoveragedes) {
		this.alAhliHospitalcoveragedes = alAhliHospitalcoveragedes;
	}
	public String getoPcopaydeductibleatAlAhlides() {
		return oPcopaydeductibleatAlAhlides;
	}
	public void setoPcopaydeductibleatAlAhlides(String oPcopaydeductibleatAlAhlides) {
		this.oPcopaydeductibleatAlAhlides = oPcopaydeductibleatAlAhlides;
	}
	public String getoPcopayatAlAhlides() {
		return oPcopayatAlAhlides;
	}
	public void setoPcopayatAlAhlides(String oPcopayatAlAhlides) {
		this.oPcopayatAlAhlides = oPcopayatAlAhlides;
	}
	public String getoPpharmacycopayatalAhlides() {
		return oPpharmacycopayatalAhlides;
	}
	public void setoPpharmacycopayatalAhlides(String oPpharmacycopayatalAhlides) {
		this.oPpharmacycopayatalAhlides = oPpharmacycopayatalAhlides;
	}
	public String getoPinvestigationcopayatAlAhlides() {
		return oPinvestigationcopayatAlAhlides;
	}
	public void setoPinvestigationcopayatAlAhlides(String oPinvestigationcopayatAlAhlides) {
		this.oPinvestigationcopayatAlAhlides = oPinvestigationcopayatAlAhlides;
	}
	public String getoPconsultationcopayatAlAhlides() {
		return oPconsultationcopayatAlAhlides;
	}
	public void setoPconsultationcopayatAlAhlides(String oPconsultationcopayatAlAhlides) {
		this.oPconsultationcopayatAlAhlides = oPconsultationcopayatAlAhlides;
	}
	public String getoPotherservicescopayatAlAhlides() {
		return oPotherservicescopayatAlAhlides;
	}
	public void setoPotherservicescopayatAlAhlides(String oPotherservicescopayatAlAhlides) {
		this.oPotherservicescopayatAlAhlides = oPotherservicescopayatAlAhlides;
	}
	public String getiPcopayatAlAhlides() {
		return iPcopayatAlAhlides;
	}
	public void setiPcopayatAlAhlides(String iPcopayatAlAhlides) {
		this.iPcopayatAlAhlides = iPcopayatAlAhlides;
	}
	public String getAdditionalhospitalcoveragedes() {
		return additionalhospitalcoveragedes;
	}
	public void setAdditionalhospitalcoveragedes(String additionalhospitalcoveragedes) {
		this.additionalhospitalcoveragedes = additionalhospitalcoveragedes;
	}
	public String getLoadingforadditionalhospitalcoveragedes() {
		return loadingforadditionalhospitalcoveragedes;
	}
	public void setLoadingforadditionalhospitalcoveragedes(String loadingforadditionalhospitalcoveragedes) {
		this.loadingforadditionalhospitalcoveragedes = loadingforadditionalhospitalcoveragedes;
	}
	public String getCommentsloadingforadditionaldes() {
		return commentsloadingforadditionaldes;
	}
	public void setCommentsloadingforadditionaldes(String commentsloadingforadditionaldes) {
		this.commentsloadingforadditionaldes = commentsloadingforadditionaldes;
	}
	public String getHospitalexclusionsdes() {
		return hospitalexclusionsdes;
	}
	public void setHospitalexclusionsdes(String hospitalexclusionsdes) {
		this.hospitalexclusionsdes = hospitalexclusionsdes;
	}
	public String getDiscountforhospitalexclusionsdes() {
		return discountforhospitalexclusionsdes;
	}
	public void setDiscountforhospitalexclusionsdes(String discountforhospitalexclusionsdes) {
		this.discountforhospitalexclusionsdes = discountforhospitalexclusionsdes;
	}
	public String getCommentsdiscountforhospitaldes() {
		return commentsdiscountforhospitaldes;
	}
	public void setCommentsdiscountforhospitaldes(String commentsdiscountforhospitaldes) {
		this.commentsdiscountforhospitaldes = commentsdiscountforhospitaldes;
	}
	public String getOpticaldes() {
		return opticaldes;
	}
	public void setOpticaldes(String opticaldes) {
		this.opticaldes = opticaldes;
	}
	public String getOpticallimitdes() {
		return opticallimitdes;
	}
	public void setOpticallimitdes(String opticallimitdes) {
		this.opticallimitdes = opticallimitdes;
	}
	
	public String getFrameslimitdes() {
		return frameslimitdes;
	}
	public void setFrameslimitdes(String frameslimitdes) {
		this.frameslimitdes = frameslimitdes;
	}
	public String getDentaldes() {
		return dentaldes;
	}
	public void setDentaldes(String dentaldes) {
		this.dentaldes = dentaldes;
	}
	public String getDentallimitdes() {
		return dentallimitdes;
	}
	public void setDentallimitdes(String dentallimitdes) {
		this.dentallimitdes = dentallimitdes;
	}
	public String getDentalcopaydeductibledes() {
		return dentalcopaydeductibledes;
	}
	public void setDentalcopaydeductibledes(String dentalcopaydeductibledes) {
		this.dentalcopaydeductibledes = dentalcopaydeductibledes;
	}
	public String getOrthodonticsdes() {
		return orthodonticsdes;
	}
	public void setOrthodonticsdes(String orthodonticsdes) {
		this.orthodonticsdes = orthodonticsdes;
	}
	public String getOrthodonticscopaydes() {
		return orthodonticscopaydes;
	}
	public void setOrthodonticscopaydes(String orthodonticscopaydes) {
		this.orthodonticscopaydes = orthodonticscopaydes;
	}
	public String getMaternitydes() {
		return maternitydes;
	}
	public void setMaternitydes(String maternitydes) {
		this.maternitydes = maternitydes;
	}
	public String getMaternitylimitdes() {
		return maternitylimitdes;
	}
	public void setMaternitylimitdes(String maternitylimitdes) {
		this.maternitylimitdes = maternitylimitdes;
	}
	public String getMaternitycopaydeductibledes() {
		return maternitycopaydeductibledes;
	}
	public void setMaternitycopaydeductibledes(String maternitycopaydeductibledes) {
		this.maternitycopaydeductibledes = maternitycopaydeductibledes;
	}
	public String getCountryofresidencedes() {
		return countryofresidencedes;
	}
	public void setCountryofresidencedes(String countryofresidencedes) {
		this.countryofresidencedes = countryofresidencedes;
	}
	public String getLoadingforcountryofresidencedes() {
		return loadingforcountryofresidencedes;
	}
	public void setLoadingforcountryofresidencedes(String loadingforcountryofresidencedes) {
		this.loadingforcountryofresidencedes = loadingforcountryofresidencedes;
	}
	public String getTrenddes() {
		return trenddes;
	}
	public void setTrenddes(String trenddes) {
		this.trenddes = trenddes;
	}
	public String getProratalimitapplicabledes() {
		return proratalimitapplicabledes;
	}
	public void setProratalimitapplicabledes(String proratalimitapplicabledes) {
		this.proratalimitapplicabledes = proratalimitapplicabledes;
	}
	public String getPremumrefundapproachdes() {
		return premumrefundapproachdes;
	}
	public void setPremumrefundapproachdes(String premumrefundapproachdes) {
		this.premumrefundapproachdes = premumrefundapproachdes;
	}
	public String getTableInpatientdes() {
		return tableInpatientdes;
	}
	public void setTableInpatientdes(String tableInpatientdes) {
		this.tableInpatientdes = tableInpatientdes;
	}
	public String getTableoutpatientdes() {
		return tableoutpatientdes;
	}
	public void setTableoutpatientdes(String tableoutpatientdes) {
		this.tableoutpatientdes = tableoutpatientdes;
	}
	public String getTableOpticaldes() {
		return tableOpticaldes;
	}
	public void setTableOpticaldes(String tableOpticaldes) {
		this.tableOpticaldes = tableOpticaldes;
	}
	public String getTableDentaldes() {
		return tableDentaldes;
	}
	public void setTableDentaldes(String tableDentaldes) {
		this.tableDentaldes = tableDentaldes;
	}
	public String getTableMaternitydes() {
		return tableMaternitydes;
	}
	public void setTableMaternitydes(String tableMaternitydes) {
		this.tableMaternitydes = tableMaternitydes;
	}
	public String getTableOveralldes() {
		return tableOveralldes;
	}
	public void setTableOveralldes(String tableOveralldes) {
		this.tableOveralldes = tableOveralldes;
	}
	public String getCoverdStartDatedes() {
		return coverdStartDatedes;
	}
	public void setCoverdStartDatedes(String coverdStartDatedes) {
		this.coverdStartDatedes = coverdStartDatedes;
	}
	public String getCoverdEndDatedes() {
		return coverdEndDatedes;
	}
	public void setCoverdEndDatedes(String coverdEndDatedes) {
		this.coverdEndDatedes = coverdEndDatedes;
	}
	public String getNetworkcommonBenefitsdes() {
		return networkcommonBenefitsdes;
	}
	public void setNetworkcommonBenefitsdes(String networkcommonBenefitsdes) {
		this.networkcommonBenefitsdes = networkcommonBenefitsdes;
	}
	public Long getVersionSeqId() {
		return versionSeqId;
	}
	public void setVersionSeqId(Long versionSeqId) {
		this.versionSeqId = versionSeqId;
	}
	public Long getGroupProSeqId() {
		return groupProSeqId;
	}
	public void setGroupProSeqId(Long groupProSeqId) {
		this.groupProSeqId = groupProSeqId;
	}
	public Long getVersionVal() {
		return versionVal;
	}
	public void setVersionVal(Long versionVal) {
		this.versionVal = versionVal;
	}
	public Date getCoverageStartDate() {
		return coverageStartDate;
	}
	public void setCoverageStartDate(Date coverageStartDate) {
		this.coverageStartDate = coverageStartDate;
	}
	public Date getCoverageEndDate() {
		return coverageEndDate;
	}
	public void setCoverageEndDate(Date coverageEndDate) {
		this.coverageEndDate = coverageEndDate;
	}
	public Long getMaximumbenefitlimit() {
		return maximumbenefitlimit;
	}
	public void setMaximumbenefitlimit(Long maximumbenefitlimit) {
		this.maximumbenefitlimit = maximumbenefitlimit;
	}
	public Long getOpLimit() {
		return opLimit;
	}
	public void setOpLimit(Long opLimit) {
		this.opLimit = opLimit;
	}
	public Long getAreaofcover() {
		return areaofcover;
	}
	public void setAreaofcover(Long areaofcover) {
		this.areaofcover = areaofcover;
	}
	public Long getLoadingforareaofcoverip() {
		return loadingforareaofcoverip;
	}
	public void setLoadingforareaofcoverip(Long loadingforareaofcoverip) {
		this.loadingforareaofcoverip = loadingforareaofcoverip;
	}
	public Long getLoadingforareaofcoverop() {
		return loadingforareaofcoverop;
	}
	public void setLoadingforareaofcoverop(Long loadingforareaofcoverop) {
		this.loadingforareaofcoverop = loadingforareaofcoverop;
	}
	public Long getLoadingforareaofcoveropt() {
		return loadingforareaofcoveropt;
	}
	public void setLoadingforareaofcoveropt(Long loadingforareaofcoveropt) {
		this.loadingforareaofcoveropt = loadingforareaofcoveropt;
	}
	public Long getLoadingforareaofcoverdent() {
		return loadingforareaofcoverdent;
	}
	public void setLoadingforareaofcoverdent(Long loadingforareaofcoverdent) {
		this.loadingforareaofcoverdent = loadingforareaofcoverdent;
	}
	public Long getLoadingforareaofcovermat() {
		return loadingforareaofcovermat;
	}
	public void setLoadingforareaofcovermat(Long loadingforareaofcovermat) {
		this.loadingforareaofcovermat = loadingforareaofcovermat;
	}
	public Long getNetworkcommon() {
		return networkcommon;
	}
	public void setNetworkcommon(Long networkcommon) {
		this.networkcommon = networkcommon;
	}
	public Long getoPCopayDeductible() {
		return oPCopayDeductible;
	}
	public void setoPCopayDeductible(Long oPCopayDeductible) {
		this.oPCopayDeductible = oPCopayDeductible;
	}
	public String getoPCopayDeductibledesc() {
		return oPCopayDeductibledesc;
	}
	public void setoPCopayDeductibledesc(String oPCopayDeductibledesc) {
		this.oPCopayDeductibledesc = oPCopayDeductibledesc;
	}
	public Long getoPpharmacycopay() {
		return oPpharmacycopay;
	}
	public void setoPpharmacycopay(Long oPpharmacycopay) {
		this.oPpharmacycopay = oPpharmacycopay;
	}
	public String getoPpharmacycopaydesc() {
		return oPpharmacycopaydesc;
	}
	public void setoPpharmacycopaydesc(String oPpharmacycopaydesc) {
		this.oPpharmacycopaydesc = oPpharmacycopaydesc;
	}
	public Long getoPinvestigationcopay() {
		return oPinvestigationcopay;
	}
	public void setoPinvestigationcopay(Long oPinvestigationcopay) {
		this.oPinvestigationcopay = oPinvestigationcopay;
	}
	public String getoPinvestigationcopaydesc() {
		return oPinvestigationcopaydesc;
	}
	public void setoPinvestigationcopaydesc(String oPinvestigationcopaydesc) {
		this.oPinvestigationcopaydesc = oPinvestigationcopaydesc;
	}
	public Long getoPconsultationcopay() {
		return oPconsultationcopay;
	}
	public void setoPconsultationcopay(Long oPconsultationcopay) {
		this.oPconsultationcopay = oPconsultationcopay;
	}
	public String getoPconsultationcopaydesc() {
		return oPconsultationcopaydesc;
	}
	public void setoPconsultationcopaydesc(String oPconsultationcopaydesc) {
		this.oPconsultationcopaydesc = oPconsultationcopaydesc;
	}
	public Long getoPcopayatAlAhli() {
		return oPcopayatAlAhli;
	}
	public void setoPcopayatAlAhli(Long oPcopayatAlAhli) {
		this.oPcopayatAlAhli = oPcopayatAlAhli;
	}
	public String getoPcopayatAlAhlidesc() {
		return oPcopayatAlAhlidesc;
	}
	public void setoPcopayatAlAhlidesc(String oPcopayatAlAhlidesc) {
		this.oPcopayatAlAhlidesc = oPcopayatAlAhlidesc;
	}
	public Long getoPpharmacycopayatalAhli() {
		return oPpharmacycopayatalAhli;
	}
	public void setoPpharmacycopayatalAhli(Long oPpharmacycopayatalAhli) {
		this.oPpharmacycopayatalAhli = oPpharmacycopayatalAhli;
	}
	public String getoPpharmacycopayatalAhlidesc() {
		return oPpharmacycopayatalAhlidesc;
	}
	public void setoPpharmacycopayatalAhlidesc(String oPpharmacycopayatalAhlidesc) {
		this.oPpharmacycopayatalAhlidesc = oPpharmacycopayatalAhlidesc;
	}
	public Long getoPinvestigationcopayatAlAhli() {
		return oPinvestigationcopayatAlAhli;
	}
	public void setoPinvestigationcopayatAlAhli(Long oPinvestigationcopayatAlAhli) {
		this.oPinvestigationcopayatAlAhli = oPinvestigationcopayatAlAhli;
	}
	public String getoPinvestigationcopayatAlAhlidesc() {
		return oPinvestigationcopayatAlAhlidesc;
	}
	public void setoPinvestigationcopayatAlAhlidesc(String oPinvestigationcopayatAlAhlidesc) {
		this.oPinvestigationcopayatAlAhlidesc = oPinvestigationcopayatAlAhlidesc;
	}
	public Long getoPconsultationcopayatAlAhli() {
		return oPconsultationcopayatAlAhli;
	}
	public void setoPconsultationcopayatAlAhli(Long oPconsultationcopayatAlAhli) {
		this.oPconsultationcopayatAlAhli = oPconsultationcopayatAlAhli;
	}
	public String getoPconsultationcopayatAlAhlidesc() {
		return oPconsultationcopayatAlAhlidesc;
	}
	public void setoPconsultationcopayatAlAhlidesc(String oPconsultationcopayatAlAhlidesc) {
		this.oPconsultationcopayatAlAhlidesc = oPconsultationcopayatAlAhlidesc;
	}
	public Long getoPotherservicescopayatAlAhli() {
		return oPotherservicescopayatAlAhli;
	}
	public void setoPotherservicescopayatAlAhli(Long oPotherservicescopayatAlAhli) {
		this.oPotherservicescopayatAlAhli = oPotherservicescopayatAlAhli;
	}
	public String getoPotherservicescopayatAlAhlidesc() {
		return oPotherservicescopayatAlAhlidesc;
	}
	public void setoPotherservicescopayatAlAhlidesc(String oPotherservicescopayatAlAhlidesc) {
		this.oPotherservicescopayatAlAhlidesc = oPotherservicescopayatAlAhlidesc;
	}
	public Long getiPcopayatAlAhli() {
		return iPcopayatAlAhli;
	}
	public void setiPcopayatAlAhli(Long iPcopayatAlAhli) {
		this.iPcopayatAlAhli = iPcopayatAlAhli;
	}
	public String getiPcopayatAlAhlidesc() {
		return iPcopayatAlAhlidesc;
	}
	public void setiPcopayatAlAhlidesc(String iPcopayatAlAhlidesc) {
		this.iPcopayatAlAhlidesc = iPcopayatAlAhlidesc;
	}
	public Long getLoadingforadditionalhospitalcoverage() {
		return loadingforadditionalhospitalcoverage;
	}
	public void setLoadingforadditionalhospitalcoverage(Long loadingforadditionalhospitalcoverage) {
		this.loadingforadditionalhospitalcoverage = loadingforadditionalhospitalcoverage;
	}
	public Long getDiscountforhospitalexclusions() {
		return discountforhospitalexclusions;
	}
	public void setDiscountforhospitalexclusions(Long discountforhospitalexclusions) {
		this.discountforhospitalexclusions = discountforhospitalexclusions;
	}
	public Long getOpticallimit() {
		return opticallimit;
	}
	public void setOpticallimit(Long opticallimit) {
		this.opticallimit = opticallimit;
	}
	public Long getOpticalcopay() {
		return opticalcopay;
	}
	public void setOpticalcopay(Long opticalcopay) {
		this.opticalcopay = opticalcopay;
	}
	public String getOpticalcopaydesc() {
		return opticalcopaydesc;
	}
	public void setOpticalcopaydesc(String opticalcopaydesc) {
		this.opticalcopaydesc = opticalcopaydesc;
	}
	public Long getFrameslimit() {
		return frameslimit;
	}
	public void setFrameslimit(Long frameslimit) {
		this.frameslimit = frameslimit;
	}
	public Long getDentallimit() {
		return dentallimit;
	}
	public void setDentallimit(Long dentallimit) {
		this.dentallimit = dentallimit;
	}
	public Long getDentalcopaydeductible() {
		return dentalcopaydeductible;
	}
	public void setDentalcopaydeductible(Long dentalcopaydeductible) {
		this.dentalcopaydeductible = dentalcopaydeductible;
	}
	public Long getOrthodonticscopay() {
		return orthodonticscopay;
	}
	public void setOrthodonticscopay(Long orthodonticscopay) {
		this.orthodonticscopay = orthodonticscopay;
	}
	public Long getMaternitylimit() {
		return maternitylimit;
	}
	public void setMaternitylimit(Long maternitylimit) {
		this.maternitylimit = maternitylimit;
	}
	public Long getTrend() {
		return trend;
	}
	public void setTrend(Long trend) {
		this.trend = trend;
	}
	public Long getDiscountforareaofcoverip() {
		return discountforareaofcoverip;
	}
	public void setDiscountforareaofcoverip(Long discountforareaofcoverip) {
		this.discountforareaofcoverip = discountforareaofcoverip;
	}
	public Long getDiscountforareaofcoverop() {
		return discountforareaofcoverop;
	}
	public void setDiscountforareaofcoverop(Long discountforareaofcoverop) {
		this.discountforareaofcoverop = discountforareaofcoverop;
	}
	public Long getDiscountforareaofcoveropt() {
		return discountforareaofcoveropt;
	}
	public void setDiscountforareaofcoveropt(Long discountforareaofcoveropt) {
		this.discountforareaofcoveropt = discountforareaofcoveropt;
	}
	public Long getDiscountforareaofcoverdent() {
		return discountforareaofcoverdent;
	}
	public void setDiscountforareaofcoverdent(Long discountforareaofcoverdent) {
		this.discountforareaofcoverdent = discountforareaofcoverdent;
	}
	public Long getDiscountforareaofcovermat() {
		return discountforareaofcovermat;
	}
	public void setDiscountforareaofcovermat(Long discountforareaofcovermat) {
		this.discountforareaofcovermat = discountforareaofcovermat;
	}
	public String getAdditionalhospitalcoveragedesc() {
		return additionalhospitalcoveragedesc;
	}
	public void setAdditionalhospitalcoveragedesc(String additionalhospitalcoveragedesc) {
		this.additionalhospitalcoveragedesc = additionalhospitalcoveragedesc;
	}
	public String getHospitalexclusionsdesc() {
		return hospitalexclusionsdesc;
	}
	public void setHospitalexclusionsdesc(String hospitalexclusionsdesc) {
		this.hospitalexclusionsdesc = hospitalexclusionsdesc;
	}
	public String getDentalcopaydeductibledesc() {
		return dentalcopaydeductibledesc;
	}
	public void setDentalcopaydeductibledesc(String dentalcopaydeductibledesc) {
		this.dentalcopaydeductibledesc = dentalcopaydeductibledesc;
	}
	public String getOrthodonticscopaydesc() {
		return orthodonticscopaydesc;
	}
	public void setOrthodonticscopaydesc(String orthodonticscopaydesc) {
		this.orthodonticscopaydesc = orthodonticscopaydesc;
	}
	public String getCoverageStartDatestr() {
		return coverageStartDatestr;
	}
	public void setCoverageStartDatestr(String coverageStartDatestr) {
		this.coverageStartDatestr = coverageStartDatestr;
	}
	public String getCoverageEndDatestr() {
		return coverageEndDatestr;
	}
	public void setCoverageEndDatestr(String coverageEndDatestr) {
		this.coverageEndDatestr = coverageEndDatestr;
	}
	public String getDiscountforareaofcoverdes() {
		return discountforareaofcoverdes;
	}
	public void setDiscountforareaofcoverdes(String discountforareaofcoverdes) {
		this.discountforareaofcoverdes = discountforareaofcoverdes;
	}
	public String getEstimateChangeip() {
		return estimateChangeip;
	}
	public void setEstimateChangeip(String estimateChangeip) {
		this.estimateChangeip = estimateChangeip;
	}
	public String getEstimateChangeOp() {
		return estimateChangeOp;
	}
	public void setEstimateChangeOp(String estimateChangeOp) {
		this.estimateChangeOp = estimateChangeOp;
	}
	public String getEstimateChangeOpt() {
		return estimateChangeOpt;
	}
	public void setEstimateChangeOpt(String estimateChangeOpt) {
		this.estimateChangeOpt = estimateChangeOpt;
	}
	public String getEstimateChangeDen() {
		return estimateChangeDen;
	}
	public void setEstimateChangeDen(String estimateChangeDen) {
		this.estimateChangeDen = estimateChangeDen;
	}
	public String getEstimateChangeMen() {
		return estimateChangeMen;
	}
	public void setEstimateChangeMen(String estimateChangeMen) {
		this.estimateChangeMen = estimateChangeMen;
	}
	public String getEstimateChangeOverAll() {
		return estimateChangeOverAll;
	}
	public void setEstimateChangeOverAll(String estimateChangeOverAll) {
		this.estimateChangeOverAll = estimateChangeOverAll;
	}
	public String getEstimateChangeipmark() {
		return estimateChangeipmark;
	}
	public void setEstimateChangeipmark(String estimateChangeipmark) {
		this.estimateChangeipmark = estimateChangeipmark;
	}
	public String getEstimateChangeOpmark() {
		return estimateChangeOpmark;
	}
	public void setEstimateChangeOpmark(String estimateChangeOpmark) {
		this.estimateChangeOpmark = estimateChangeOpmark;
	}
	public String getEstimateChangeOptmark() {
		return estimateChangeOptmark;
	}
	public void setEstimateChangeOptmark(String estimateChangeOptmark) {
		this.estimateChangeOptmark = estimateChangeOptmark;
	}
	public String getEstimateChangeDenmark() {
		return estimateChangeDenmark;
	}
	public void setEstimateChangeDenmark(String estimateChangeDenmark) {
		this.estimateChangeDenmark = estimateChangeDenmark;
	}
	public String getEstimateChangeMenmark() {
		return estimateChangeMenmark;
	}
	public void setEstimateChangeMenmark(String estimateChangeMenmark) {
		this.estimateChangeMenmark = estimateChangeMenmark;
	}
	public String getEstimateChangeOverAllmark() {
		return estimateChangeOverAllmark;
	}
	public void setEstimateChangeOverAllmark(String estimateChangeOverAllmark) {
		this.estimateChangeOverAllmark = estimateChangeOverAllmark;
	}
	public String getTabCount() {
		return tabCount;
	}
	public void setTabCount(String tabCount) {
		this.tabCount = tabCount;
	}
	public String getInpatientipColor() {
		return inpatientipColor;
	}
	public void setInpatientipColor(String inpatientipColor) {
		this.inpatientipColor = inpatientipColor;
	}
	public String getOutpatientopColor() {
		return outpatientopColor;
	}
	public void setOutpatientopColor(String outpatientopColor) {
		this.outpatientopColor = outpatientopColor;
	}
	public String getMaximumbenefitlimitColor() {
		return maximumbenefitlimitColor;
	}
	public void setMaximumbenefitlimitColor(String maximumbenefitlimitColor) {
		this.maximumbenefitlimitColor = maximumbenefitlimitColor;
	}
	public String getOpLimitColor() {
		return opLimitColor;
	}
	public void setOpLimitColor(String opLimitColor) {
		this.opLimitColor = opLimitColor;
	}
	public String getAreaofcoverColor() {
		return areaofcoverColor;
	}
	public void setAreaofcoverColor(String areaofcoverColor) {
		this.areaofcoverColor = areaofcoverColor;
	}
	public String getNetworkcommonColor() {
		return networkcommonColor;
	}
	public void setNetworkcommonColor(String networkcommonColor) {
		this.networkcommonColor = networkcommonColor;
	}
	public String getNetworkipColor() {
		return networkipColor;
	}
	public void setNetworkipColor(String networkipColor) {
		this.networkipColor = networkipColor;
	}
	public String getNetworkopColor() {
		return networkopColor;
	}
	public void setNetworkopColor(String networkopColor) {
		this.networkopColor = networkopColor;
	}
	public String getNetworkoptColor() {
		return networkoptColor;
	}
	public void setNetworkoptColor(String networkoptColor) {
		this.networkoptColor = networkoptColor;
	}
	public String getNetworkdntColor() {
		return networkdntColor;
	}
	public void setNetworkdntColor(String networkdntColor) {
		this.networkdntColor = networkdntColor;
	}
	public String getNetworkmatColor() {
		return networkmatColor;
	}
	public void setNetworkmatColor(String networkmatColor) {
		this.networkmatColor = networkmatColor;
	}
	public String getAreaofcovernextColor() {
		return areaofcovernextColor;
	}
	public void setAreaofcovernextColor(String areaofcovernextColor) {
		this.areaofcovernextColor = areaofcovernextColor;
	}
	public String getLoadingforareaofcoverColor() {
		return loadingforareaofcoverColor;
	}
	public void setLoadingforareaofcoverColor(String loadingforareaofcoverColor) {
		this.loadingforareaofcoverColor = loadingforareaofcoverColor;
	}
	public String getLoadingforareaofcoveripColor() {
		return loadingforareaofcoveripColor;
	}
	public void setLoadingforareaofcoveripColor(String loadingforareaofcoveripColor) {
		this.loadingforareaofcoveripColor = loadingforareaofcoveripColor;
	}
	public String getLoadingforareaofcoveropColor() {
		return loadingforareaofcoveropColor;
	}
	public void setLoadingforareaofcoveropColor(String loadingforareaofcoveropColor) {
		this.loadingforareaofcoveropColor = loadingforareaofcoveropColor;
	}
	public String getLoadingforareaofcoveroptColor() {
		return loadingforareaofcoveroptColor;
	}
	public void setLoadingforareaofcoveroptColor(String loadingforareaofcoveroptColor) {
		this.loadingforareaofcoveroptColor = loadingforareaofcoveroptColor;
	}
	public String getLoadingforareaofcoverdentColor() {
		return loadingforareaofcoverdentColor;
	}
	public void setLoadingforareaofcoverdentColor(String loadingforareaofcoverdentColor) {
		this.loadingforareaofcoverdentColor = loadingforareaofcoverdentColor;
	}
	public String getLoadingforareaofcovermatColor() {
		return loadingforareaofcovermatColor;
	}
	public void setLoadingforareaofcovermatColor(String loadingforareaofcovermatColor) {
		this.loadingforareaofcovermatColor = loadingforareaofcovermatColor;
	}
	public String getDiscountforareaofcoveripColor() {
		return discountforareaofcoveripColor;
	}
	public void setDiscountforareaofcoveripColor(String discountforareaofcoveripColor) {
		this.discountforareaofcoveripColor = discountforareaofcoveripColor;
	}
	public String getDiscountforareaofcoveropColor() {
		return discountforareaofcoveropColor;
	}
	public void setDiscountforareaofcoveropColor(String discountforareaofcoveropColor) {
		this.discountforareaofcoveropColor = discountforareaofcoveropColor;
	}
	public String getDiscountforareaofcoveroptColor() {
		return discountforareaofcoveroptColor;
	}
	public void setDiscountforareaofcoveroptColor(String discountforareaofcoveroptColor) {
		this.discountforareaofcoveroptColor = discountforareaofcoveroptColor;
	}
	public String getDiscountforareaofcoverdentColor() {
		return discountforareaofcoverdentColor;
	}
	public void setDiscountforareaofcoverdentColor(String discountforareaofcoverdentColor) {
		this.discountforareaofcoverdentColor = discountforareaofcoverdentColor;
	}
	public String getDiscountforareaofcovermatColor() {
		return discountforareaofcovermatColor;
	}
	public void setDiscountforareaofcovermatColor(String discountforareaofcovermatColor) {
		this.discountforareaofcovermatColor = discountforareaofcovermatColor;
	}
	public String getiPcopayColor() {
		return iPcopayColor;
	}
	public void setiPcopayColor(String iPcopayColor) {
		this.iPcopayColor = iPcopayColor;
	}
	public String getiPcopaydescColor() {
		return iPcopaydescColor;
	}
	public void setiPcopaydescColor(String iPcopaydescColor) {
		this.iPcopaydescColor = iPcopaydescColor;
	}
	public String getoPcopaydeductibleapplicableColor() {
		return oPcopaydeductibleapplicableColor;
	}
	public void setoPcopaydeductibleapplicableColor(String oPcopaydeductibleapplicableColor) {
		this.oPcopaydeductibleapplicableColor = oPcopaydeductibleapplicableColor;
	}
	public String getoPCopayDeductibleColor() {
		return oPCopayDeductibleColor;
	}
	public void setoPCopayDeductibleColor(String oPCopayDeductibleColor) {
		this.oPCopayDeductibleColor = oPCopayDeductibleColor;
	}
	public String getoPCopayDeductibledescColor() {
		return oPCopayDeductibledescColor;
	}
	public void setoPCopayDeductibledescColor(String oPCopayDeductibledescColor) {
		this.oPCopayDeductibledescColor = oPCopayDeductibledescColor;
	}
	public String getoPpharmacycopayColor() {
		return oPpharmacycopayColor;
	}
	public void setoPpharmacycopayColor(String oPpharmacycopayColor) {
		this.oPpharmacycopayColor = oPpharmacycopayColor;
	}
	public String getoPpharmacycopaydescColor() {
		return oPpharmacycopaydescColor;
	}
	public void setoPpharmacycopaydescColor(String oPpharmacycopaydescColor) {
		this.oPpharmacycopaydescColor = oPpharmacycopaydescColor;
	}
	public String getoPinvestigationcopayColor() {
		return oPinvestigationcopayColor;
	}
	public void setoPinvestigationcopayColor(String oPinvestigationcopayColor) {
		this.oPinvestigationcopayColor = oPinvestigationcopayColor;
	}
	public String getoPinvestigationcopaydescColor() {
		return oPinvestigationcopaydescColor;
	}
	public void setoPinvestigationcopaydescColor(String oPinvestigationcopaydescColor) {
		this.oPinvestigationcopaydescColor = oPinvestigationcopaydescColor;
	}
	public String getoPconsultationcopayColor() {
		return oPconsultationcopayColor;
	}
	public void setoPconsultationcopayColor(String oPconsultationcopayColor) {
		this.oPconsultationcopayColor = oPconsultationcopayColor;
	}
	public String getoPconsultationcopaydescColor() {
		return oPconsultationcopaydescColor;
	}
	public void setoPconsultationcopaydescColor(String oPconsultationcopaydescColor) {
		this.oPconsultationcopaydescColor = oPconsultationcopaydescColor;
	}
	public String getoPcopayonotherservicesColor() {
		return oPcopayonotherservicesColor;
	}
	public void setoPcopayonotherservicesColor(String oPcopayonotherservicesColor) {
		this.oPcopayonotherservicesColor = oPcopayonotherservicesColor;
	}
	public String getoPcopayonotherservicesdescColor() {
		return oPcopayonotherservicesdescColor;
	}
	public void setoPcopayonotherservicesdescColor(String oPcopayonotherservicesdescColor) {
		this.oPcopayonotherservicesdescColor = oPcopayonotherservicesdescColor;
	}
	public String getAlAhliHospitalcoverageColor() {
		return alAhliHospitalcoverageColor;
	}
	public void setAlAhliHospitalcoverageColor(String alAhliHospitalcoverageColor) {
		this.alAhliHospitalcoverageColor = alAhliHospitalcoverageColor;
	}
	public String getoPcopaydeductibleatAlAhliColor() {
		return oPcopaydeductibleatAlAhliColor;
	}
	public void setoPcopaydeductibleatAlAhliColor(String oPcopaydeductibleatAlAhliColor) {
		this.oPcopaydeductibleatAlAhliColor = oPcopaydeductibleatAlAhliColor;
	}
	public String getoPcopayatAlAhliColor() {
		return oPcopayatAlAhliColor;
	}
	public void setoPcopayatAlAhliColor(String oPcopayatAlAhliColor) {
		this.oPcopayatAlAhliColor = oPcopayatAlAhliColor;
	}
	public String getoPcopayatAlAhlidescColor() {
		return oPcopayatAlAhlidescColor;
	}
	public void setoPcopayatAlAhlidescColor(String oPcopayatAlAhlidescColor) {
		this.oPcopayatAlAhlidescColor = oPcopayatAlAhlidescColor;
	}
	public String getoPpharmacycopayatalAhliColor() {
		return oPpharmacycopayatalAhliColor;
	}
	public void setoPpharmacycopayatalAhliColor(String oPpharmacycopayatalAhliColor) {
		this.oPpharmacycopayatalAhliColor = oPpharmacycopayatalAhliColor;
	}
	public String getoPpharmacycopayatalAhlidescColor() {
		return oPpharmacycopayatalAhlidescColor;
	}
	public void setoPpharmacycopayatalAhlidescColor(String oPpharmacycopayatalAhlidescColor) {
		this.oPpharmacycopayatalAhlidescColor = oPpharmacycopayatalAhlidescColor;
	}
	public String getoPinvestigationcopayatAlAhliColor() {
		return oPinvestigationcopayatAlAhliColor;
	}
	public void setoPinvestigationcopayatAlAhliColor(String oPinvestigationcopayatAlAhliColor) {
		this.oPinvestigationcopayatAlAhliColor = oPinvestigationcopayatAlAhliColor;
	}
	public String getoPinvestigationcopayatAlAhlidescColor() {
		return oPinvestigationcopayatAlAhlidescColor;
	}
	public void setoPinvestigationcopayatAlAhlidescColor(String oPinvestigationcopayatAlAhlidescColor) {
		this.oPinvestigationcopayatAlAhlidescColor = oPinvestigationcopayatAlAhlidescColor;
	}
	public String getoPconsultationcopayatAlAhliColor() {
		return oPconsultationcopayatAlAhliColor;
	}
	public void setoPconsultationcopayatAlAhliColor(String oPconsultationcopayatAlAhliColor) {
		this.oPconsultationcopayatAlAhliColor = oPconsultationcopayatAlAhliColor;
	}
	public String getoPconsultationcopayatAlAhlidescColor() {
		return oPconsultationcopayatAlAhlidescColor;
	}
	public void setoPconsultationcopayatAlAhlidescColor(String oPconsultationcopayatAlAhlidescColor) {
		this.oPconsultationcopayatAlAhlidescColor = oPconsultationcopayatAlAhlidescColor;
	}
	public String getoPotherservicescopayatAlAhliColor() {
		return oPotherservicescopayatAlAhliColor;
	}
	public void setoPotherservicescopayatAlAhliColor(String oPotherservicescopayatAlAhliColor) {
		this.oPotherservicescopayatAlAhliColor = oPotherservicescopayatAlAhliColor;
	}
	public String getoPotherservicescopayatAlAhlidescColor() {
		return oPotherservicescopayatAlAhlidescColor;
	}
	public void setoPotherservicescopayatAlAhlidescColor(String oPotherservicescopayatAlAhlidescColor) {
		this.oPotherservicescopayatAlAhlidescColor = oPotherservicescopayatAlAhlidescColor;
	}
	public String getiPcopayatAlAhliColor() {
		return iPcopayatAlAhliColor;
	}
	public void setiPcopayatAlAhliColor(String iPcopayatAlAhliColor) {
		this.iPcopayatAlAhliColor = iPcopayatAlAhliColor;
	}
	public String getiPcopayatAlAhlidescColor() {
		return iPcopayatAlAhlidescColor;
	}
	public void setiPcopayatAlAhlidescColor(String iPcopayatAlAhlidescColor) {
		this.iPcopayatAlAhlidescColor = iPcopayatAlAhlidescColor;
	}
	public String getAdditionalhospitalcoverageColor() {
		return additionalhospitalcoverageColor;
	}
	public void setAdditionalhospitalcoverageColor(String additionalhospitalcoverageColor) {
		this.additionalhospitalcoverageColor = additionalhospitalcoverageColor;
	}
	public String getAdditionalhospitalcoveragedescColor() {
		return additionalhospitalcoveragedescColor;
	}
	public void setAdditionalhospitalcoveragedescColor(String additionalhospitalcoveragedescColor) {
		this.additionalhospitalcoveragedescColor = additionalhospitalcoveragedescColor;
	}
	public String getLoadingforadditionalhospitalcoverageColor() {
		return loadingforadditionalhospitalcoverageColor;
	}
	public void setLoadingforadditionalhospitalcoverageColor(String loadingforadditionalhospitalcoverageColor) {
		this.loadingforadditionalhospitalcoverageColor = loadingforadditionalhospitalcoverageColor;
	}
	public String getCommentsloadingforadditionalColor() {
		return commentsloadingforadditionalColor;
	}
	public void setCommentsloadingforadditionalColor(String commentsloadingforadditionalColor) {
		this.commentsloadingforadditionalColor = commentsloadingforadditionalColor;
	}
	public String getHospitalexclusionsColor() {
		return hospitalexclusionsColor;
	}
	public void setHospitalexclusionsColor(String hospitalexclusionsColor) {
		this.hospitalexclusionsColor = hospitalexclusionsColor;
	}
	public String getHospitalexclusionsdescColor() {
		return hospitalexclusionsdescColor;
	}
	public void setHospitalexclusionsdescColor(String hospitalexclusionsdescColor) {
		this.hospitalexclusionsdescColor = hospitalexclusionsdescColor;
	}
	public String getDiscountforhospitalexclusionsColor() {
		return discountforhospitalexclusionsColor;
	}
	public void setDiscountforhospitalexclusionsColor(String discountforhospitalexclusionsColor) {
		this.discountforhospitalexclusionsColor = discountforhospitalexclusionsColor;
	}
	public String getCommentsdiscountforhospitalColor() {
		return commentsdiscountforhospitalColor;
	}
	public void setCommentsdiscountforhospitalColor(String commentsdiscountforhospitalColor) {
		this.commentsdiscountforhospitalColor = commentsdiscountforhospitalColor;
	}
	public String getOpticalColor() {
		return opticalColor;
	}
	public void setOpticalColor(String opticalColor) {
		this.opticalColor = opticalColor;
	}
	public String getOpticallimitColor() {
		return opticallimitColor;
	}
	public void setOpticallimitColor(String opticallimitColor) {
		this.opticallimitColor = opticallimitColor;
	}
	public String getOpticalcopayColor() {
		return opticalcopayColor;
	}
	public void setOpticalcopayColor(String opticalcopayColor) {
		this.opticalcopayColor = opticalcopayColor;
	}
	public String getOpticalcopaydescColor() {
		return opticalcopaydescColor;
	}
	public void setOpticalcopaydescColor(String opticalcopaydescColor) {
		this.opticalcopaydescColor = opticalcopaydescColor;
	}
	public String getFrameslimitColor() {
		return frameslimitColor;
	}
	public void setFrameslimitColor(String frameslimitColor) {
		this.frameslimitColor = frameslimitColor;
	}
	public String getDentalColor() {
		return dentalColor;
	}
	public void setDentalColor(String dentalColor) {
		this.dentalColor = dentalColor;
	}
	public String getDentallimitColor() {
		return dentallimitColor;
	}
	public void setDentallimitColor(String dentallimitColor) {
		this.dentallimitColor = dentallimitColor;
	}
	public String getDentalcopaydeductibleColor() {
		return dentalcopaydeductibleColor;
	}
	public void setDentalcopaydeductibleColor(String dentalcopaydeductibleColor) {
		this.dentalcopaydeductibleColor = dentalcopaydeductibleColor;
	}
	public String getDentalcopaydeductibledescColor() {
		return dentalcopaydeductibledescColor;
	}
	public void setDentalcopaydeductibledescColor(String dentalcopaydeductibledescColor) {
		this.dentalcopaydeductibledescColor = dentalcopaydeductibledescColor;
	}
	public String getOrthodonticsColor() {
		return orthodonticsColor;
	}
	public void setOrthodonticsColor(String orthodonticsColor) {
		this.orthodonticsColor = orthodonticsColor;
	}
	public String getOrthodonticscopayColor() {
		return orthodonticscopayColor;
	}
	public void setOrthodonticscopayColor(String orthodonticscopayColor) {
		this.orthodonticscopayColor = orthodonticscopayColor;
	}
	public String getOrthodonticscopaydescColor() {
		return orthodonticscopaydescColor;
	}
	public void setOrthodonticscopaydescColor(String orthodonticscopaydescColor) {
		this.orthodonticscopaydescColor = orthodonticscopaydescColor;
	}
	public String getMaternityColor() {
		return maternityColor;
	}
	public void setMaternityColor(String maternityColor) {
		this.maternityColor = maternityColor;
	}
	public String getMaternitylimitColor() {
		return maternitylimitColor;
	}
	public void setMaternitylimitColor(String maternitylimitColor) {
		this.maternitylimitColor = maternitylimitColor;
	}
	public String getMaternitycopaydeductibleColor() {
		return maternitycopaydeductibleColor;
	}
	public void setMaternitycopaydeductibleColor(String maternitycopaydeductibleColor) {
		this.maternitycopaydeductibleColor = maternitycopaydeductibleColor;
	}
	public String getMaternitycopaydeductibledescColor() {
		return maternitycopaydeductibledescColor;
	}
	public void setMaternitycopaydeductibledescColor(String maternitycopaydeductibledescColor) {
		this.maternitycopaydeductibledescColor = maternitycopaydeductibledescColor;
	}
	public String getCountryofresidenceColor() {
		return countryofresidenceColor;
	}
	public void setCountryofresidenceColor(String countryofresidenceColor) {
		this.countryofresidenceColor = countryofresidenceColor;
	}
	public String getLoadingforcountryofresidenceipColor() {
		return loadingforcountryofresidenceipColor;
	}
	public void setLoadingforcountryofresidenceipColor(String loadingforcountryofresidenceipColor) {
		this.loadingforcountryofresidenceipColor = loadingforcountryofresidenceipColor;
	}
	public String getLoadingforcountryofresidenceopColor() {
		return loadingforcountryofresidenceopColor;
	}
	public void setLoadingforcountryofresidenceopColor(String loadingforcountryofresidenceopColor) {
		this.loadingforcountryofresidenceopColor = loadingforcountryofresidenceopColor;
	}
	public String getLoadingforcountryofresidenceoptColor() {
		return loadingforcountryofresidenceoptColor;
	}
	public void setLoadingforcountryofresidenceoptColor(String loadingforcountryofresidenceoptColor) {
		this.loadingforcountryofresidenceoptColor = loadingforcountryofresidenceoptColor;
	}
	public String getLoadingforcountryofresidencedentColor() {
		return loadingforcountryofresidencedentColor;
	}
	public void setLoadingforcountryofresidencedentColor(String loadingforcountryofresidencedentColor) {
		this.loadingforcountryofresidencedentColor = loadingforcountryofresidencedentColor;
	}
	public String getLoadingforcountryofresidencematColor() {
		return loadingforcountryofresidencematColor;
	}
	public void setLoadingforcountryofresidencematColor(String loadingforcountryofresidencematColor) {
		this.loadingforcountryofresidencematColor = loadingforcountryofresidencematColor;
	}
	public String getTrendColor() {
		return trendColor;
	}
	public void setTrendColor(String trendColor) {
		this.trendColor = trendColor;
	}
	public String getProratalimitapplicableColor() {
		return proratalimitapplicableColor;
	}
	public void setProratalimitapplicableColor(String proratalimitapplicableColor) {
		this.proratalimitapplicableColor = proratalimitapplicableColor;
	}
	public String getPremumrefundapproachColor() {
		return premumrefundapproachColor;
	}
	public void setPremumrefundapproachColor(String premumrefundapproachColor) {
		this.premumrefundapproachColor = premumrefundapproachColor;
	}
	public String getTableInpatientColor() {
		return tableInpatientColor;
	}
	public void setTableInpatientColor(String tableInpatientColor) {
		this.tableInpatientColor = tableInpatientColor;
	}
	public String getTableoutpatientColor() {
		return tableoutpatientColor;
	}
	public void setTableoutpatientColor(String tableoutpatientColor) {
		this.tableoutpatientColor = tableoutpatientColor;
	}
	public String getTableOpticalColor() {
		return tableOpticalColor;
	}
	public void setTableOpticalColor(String tableOpticalColor) {
		this.tableOpticalColor = tableOpticalColor;
	}
	public String getTableDentalColor() {
		return tableDentalColor;
	}
	public void setTableDentalColor(String tableDentalColor) {
		this.tableDentalColor = tableDentalColor;
	}
	public String getTableMaternityColor() {
		return tableMaternityColor;
	}
	public void setTableMaternityColor(String tableMaternityColor) {
		this.tableMaternityColor = tableMaternityColor;
	}
	public String getTableOverallColor() {
		return tableOverallColor;
	}
	public void setTableOverallColor(String tableOverallColor) {
		this.tableOverallColor = tableOverallColor;
	}
	public String getVersionSeqIdColor() {
		return versionSeqIdColor;
	}
	public void setVersionSeqIdColor(String versionSeqIdColor) {
		this.versionSeqIdColor = versionSeqIdColor;
	}
	public String getGroupProSeqIdColor() {
		return groupProSeqIdColor;
	}
	public void setGroupProSeqIdColor(String groupProSeqIdColor) {
		this.groupProSeqIdColor = groupProSeqIdColor;
	}
	public String getFinalCount() {
		return finalCount;
	}
	public void setFinalCount(String finalCount) {
		this.finalCount = finalCount;
	}
	public String getMaxiMumBenefitOtherLimit() {
		return maxiMumBenefitOtherLimit;
	}
	public void setMaxiMumBenefitOtherLimit(String maxiMumBenefitOtherLimit) {
		this.maxiMumBenefitOtherLimit = maxiMumBenefitOtherLimit;
	}
	public String getOpLimitOtherLimit() {
		return opLimitOtherLimit;
	}
	public void setOpLimitOtherLimit(String opLimitOtherLimit) {
		this.opLimitOtherLimit = opLimitOtherLimit;
	}
	public String getOpticalOtherLimit() {
		return opticalOtherLimit;
	}
	public void setOpticalOtherLimit(String opticalOtherLimit) {
		this.opticalOtherLimit = opticalOtherLimit;
	}
	public String getDentalOtherLimit() {
		return dentalOtherLimit;
	}
	public void setDentalOtherLimit(String dentalOtherLimit) {
		this.dentalOtherLimit = dentalOtherLimit;
	}
	public String getVersionValColor() {
		return versionValColor;
	}
	public void setVersionValColor(String versionValColor) {
		this.versionValColor = versionValColor;
	}
	public String getCoverageStartDatestrColor() {
		return coverageStartDatestrColor;
	}
	public void setCoverageStartDatestrColor(String coverageStartDatestrColor) {
		this.coverageStartDatestrColor = coverageStartDatestrColor;
	}
	public String getCoverageEndDatestrColor() {
		return coverageEndDatestrColor;
	}
	public void setCoverageEndDatestrColor(String coverageEndDatestrColor) {
		this.coverageEndDatestrColor = coverageEndDatestrColor;
	}
	public String getMaxiOpLimitdes() {
		return maxiOpLimitdes;
	}
	public void setMaxiOpLimitdes(String maxiOpLimitdes) {
		this.maxiOpLimitdes = maxiOpLimitdes;
	}
	public String getAreaCoverFlag() {
		return areaCoverFlag;
	}
	public void setAreaCoverFlag(String areaCoverFlag) {
		this.areaCoverFlag = areaCoverFlag;
	}
	public Long getLoadingforareaofcoveriptemp() {
		return loadingforareaofcoveriptemp;
	}
	public void setLoadingforareaofcoveriptemp(Long loadingforareaofcoveriptemp) {
		this.loadingforareaofcoveriptemp = loadingforareaofcoveriptemp;
	}
	public Long getLoadingforareaofcoveroptemp() {
		return loadingforareaofcoveroptemp;
	}
	public void setLoadingforareaofcoveroptemp(Long loadingforareaofcoveroptemp) {
		this.loadingforareaofcoveroptemp = loadingforareaofcoveroptemp;
	}
	public Long getLoadingforareaofcoveropttemp() {
		return loadingforareaofcoveropttemp;
	}
	public void setLoadingforareaofcoveropttemp(Long loadingforareaofcoveropttemp) {
		this.loadingforareaofcoveropttemp = loadingforareaofcoveropttemp;
	}
	public Long getLoadingforareaofcoverdenttemp() {
		return loadingforareaofcoverdenttemp;
	}
	public void setLoadingforareaofcoverdenttemp(Long loadingforareaofcoverdenttemp) {
		this.loadingforareaofcoverdenttemp = loadingforareaofcoverdenttemp;
	}
	public Long getLoadingforareaofcovermattemp() {
		return loadingforareaofcovermattemp;
	}
	public void setLoadingforareaofcovermattemp(Long loadingforareaofcovermattemp) {
		this.loadingforareaofcovermattemp = loadingforareaofcovermattemp;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	public Long getDiscountforareaofcoveriptemp() {
		return discountforareaofcoveriptemp;
	}
	public void setDiscountforareaofcoveriptemp(Long discountforareaofcoveriptemp) {
		this.discountforareaofcoveriptemp = discountforareaofcoveriptemp;
	}
	public Long getDiscountforareaofcoveroptemp() {
		return discountforareaofcoveroptemp;
	}
	public void setDiscountforareaofcoveroptemp(Long discountforareaofcoveroptemp) {
		this.discountforareaofcoveroptemp = discountforareaofcoveroptemp;
	}
	public Long getDiscountforareaofcoveropttemp() {
		return discountforareaofcoveropttemp;
	}
	public void setDiscountforareaofcoveropttemp(Long discountforareaofcoveropttemp) {
		this.discountforareaofcoveropttemp = discountforareaofcoveropttemp;
	}
	public Long getDiscountforareaofcoverdenttemp() {
		return discountforareaofcoverdenttemp;
	}
	public void setDiscountforareaofcoverdenttemp(Long discountforareaofcoverdenttemp) {
		this.discountforareaofcoverdenttemp = discountforareaofcoverdenttemp;
	}
	public Long getDiscountforareaofcovermattemp() {
		return discountforareaofcovermattemp;
	}
	public void setDiscountforareaofcovermattemp(Long discountforareaofcovermattemp) {
		this.discountforareaofcovermattemp = discountforareaofcovermattemp;
	}
	public String getSaveYn() {
		return saveYn;
	}
	public void setSaveYn(String saveYn) {
		this.saveYn = saveYn;
	}
	public Integer getVersionCount() {
		return versionCount;
	}
	public void setVersionCount(Integer versionCount) {
		this.versionCount = versionCount;
	}
	public String getOpticalCopaydes() {
		return opticalCopaydes;
	}
	public void setOpticalCopaydes(String opticalCopaydes) {
		this.opticalCopaydes = opticalCopaydes;
	}
	
	
	
	
}


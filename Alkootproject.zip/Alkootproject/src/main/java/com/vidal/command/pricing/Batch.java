package com.vidal.command.pricing;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="batch")
public class Batch {
	private FileDetail fileDetail;

	private List<Policy> policy;
	
	
	@XmlElement
	public List<Policy> getPolicy() {
		return policy;
	}

	public void setPolicy(List<Policy> policy) {
		this.policy = policy;
	}
	
	private List<MemberDetails> memberDetails;
	
	private List<MaternityDetails> maternityDetails;
	
	@XmlElement
	public List<MemberDetails> getMemberDetails() {
		return memberDetails;
	}

	public void setMemberDetails(List<MemberDetails> memberDetails) {
		this.memberDetails = memberDetails;
	}
	
	
	@XmlElement
	public List<MaternityDetails> getMaternityDetails() {
		return maternityDetails;
	}

	public void setMaternityDetails(List<MaternityDetails> maternityDetails) {
		this.maternityDetails = maternityDetails;
	}

	@XmlElement(name="filedetail")
	public FileDetail getFileDetail() {
		return fileDetail;
	}

	public void setFileDetail(FileDetail fileDetail) {
		this.fileDetail = fileDetail;
	}
}

package com.vidal.command.pricing;

import com.vidal.command.base.BaseVO;

public class AdditionalVO extends BaseVO{
	private Long additionalseqId;
	private Long pricingno;
	private String additionalbenseqId="";
    private String pricingseqId="";
    private String pricingRefno=""; 
	

		
		
	 public String getAdditionalbenseqId() {
		return additionalbenseqId;
	}
	public void setAdditionalbenseqId(String additionalbenseqId) {
		this.additionalbenseqId = additionalbenseqId;
	}
	public String getPricingseqId() {
		return pricingseqId;
	}
	public void setPricingseqId(String pricingseqId) {
		this.pricingseqId = pricingseqId;
	}
	private String outsideareaofcover="";
	    private String levelofcover ="";
	    private String inpatientandDaycaretreatment ="";
	    private String physiotherapy="";
	    private String alternativetreatment="";
	    private String diagnostics="";
	    private String doctorConsultation="";
	    private String 	prescribedDrug="";
	    private String internationalEmergencyMedicalAssistance="";
	    private String radiotherapy="";
	    private String psychiatric="";
	    private String vaccination="";
	    private String preexistingconditionslimit="";
	    private String hormoneReplacementTherapylimit="";
	    private String nursingathomelimit="";
	    private String vitamins="";
	    private String passiveWar="";
	    private String maintenanceofChronic="";
	    private String outsidedesc="";
	    private String leveldesc="";
	    private String fetch="";
	    public String getOutsidedesc() {
			return outsidedesc;
		}
		public void setOutsidedesc(String outsidedesc) {
			this.outsidedesc = outsidedesc;
		}
		public String getLeveldesc() {
			return leveldesc;
		}
		public void setLeveldesc(String leveldesc) {
			this.leveldesc = leveldesc;
		}
		private String inpatientRehabilitation="";
	    private String preandpostnatal="";
	    private String externalProsthesis="";
	    private String lifeThreatening="";
	    private String hospiceandPalliative="";
	    private String hIVandaIDSLimit="";
	    private String compassionatevisit="";
	    private String healthscreenlimit="";
	    private String externalmedical="";
	    private String wellbeingbenefit="";
	    private String workrelated="";
	    private String obesity="";
	    private String dieticianlimit="";
	    private String circumcisionlimit="";
	    private String externalmedicalcopay="";
	    private String healthsessions="";
	    private String healthscreencopay="";
	    private String deductiblecoinsurance="";
	    private String comments="";
	    private String pregnancy="";
	    private String vaccinations="";
	    private String vaccinationslimit="";
	    private String vaccinations1="";
	    private String Physiotherepylimit="";
	    private String PhysiotherepySession="";
	    private String alternativetreatmentlimit="";
	    private String internationalEmergency="";
	    private String internationalEmergencylimit="";
	    private String lifeThreateningdiease="";
	    private String workrelateddrop1Desc="";
	    private String lifeThreateningdieaseDesc="";
	    
	    private String AlternativeTreatments = "";
	    private String AlternativeTreatmentsdesc = "";
	    private String ReimbursmentLevel = "";
	    private String ReimbursmentLeveldesc = "";
	    
	    
	    public String getWorkrelateddrop1Desc() {
			return workrelateddrop1Desc;
		}
		public void setWorkrelateddrop1Desc(String workrelateddrop1Desc) {
			this.workrelateddrop1Desc = workrelateddrop1Desc;
		}
		public String getLifeThreateningdieaseDesc() {
			return lifeThreateningdieaseDesc;
		}
		public void setLifeThreateningdieaseDesc(String lifeThreateningdieaseDesc) {
			this.lifeThreateningdieaseDesc = lifeThreateningdieaseDesc;
		}
		private String workrelateddrop1="";
	    public String getLifeThreateningdiease() {
			return lifeThreateningdiease;
		}
		public void setLifeThreateningdiease(String lifeThreateningdiease) {
			this.lifeThreateningdiease = lifeThreateningdiease;
		}
		public String getWorkrelateddrop1() {
			return workrelateddrop1;
		}
		public void setWorkrelateddrop1(String workrelateddrop1) {
			this.workrelateddrop1 = workrelateddrop1;
		}
		private String preexistingcoadtion="";
	    private String harmonereplace="";
	    private String inpatientrehabationtreatment="";
	    private String externalprothis="";
	    private String workinjury="";
	    private String wellbeingbenfit="";
	    private String Vitaminsmed="";
	    private String maintenancecoadtion="";
	    private String obesitysurgry="";
	    private String lifedisease="";
	    private String ditecianlimit="";
	    private String dietican="";
	    private String stracute="";
	    private String hospice="";
	    private String strhiv="";
	    private String nursinghome="";
	    private String circumcision="";
	    private String compassionate="";
	    private String externalmed="";
	    private String health="";
	    private String strinpatientboadrd="";
	    private String parentaccomdation="";
	    private String strinpatientcash="";
	    private String strdiagnostics="";
	    private String prescribed="";
	    private String doctriaya="";
	    private String radiography="";
	    private String oralmax="";
	    private String organtransplant="";
	    private String organlimit="";
	    private String organlimitDesc="";
	    private String alternativecopay="";
	    private String alternativecopayDesc="";
	    private String inpatntflag="";
	    private String checkconstructive="";
	    //new change
	    private String congtal="";
	    private String congtalDesc="";
	    private String oncology="";
	    private String oncologydesc="";
	    private String repatriation="";
	    private String repatriationDesc="";
	    private String terminal="";
	    private String terminalDesc="";
	    private String pslYN="";
	    private String psllimit="";
	    private String home="";
	    private String inpatientlimit="";
	    private String approval="";
	    private String alternativesession="";
	    private String newborn="";
	    private String dentalprothis="";
	    private String dentalprothisdesc="";
	    
	    private String parentacmdation="";
	    private String alternativesessiondesc="";
	    private String approvaldesc="";
	    private String psllimitdesc="";
	    private String inpatientlimitdecs="";
	    private String renewalYNadd="";
	    private String renewalYN="";
	    private String prevespolno="";
	    public String getRenewalYN() {
			return renewalYN;
		}
		public void setRenewalYN(String renewalYN) {
			this.renewalYN = renewalYN;
		}
		public String getPrevespolno() {
			return prevespolno;
		}
		public void setPrevespolno(String prevespolno) {
			this.prevespolno = prevespolno;
		}
		public String getRenewalYNadd() {
	 			return renewalYNadd;
	 		}

	 		public void setRenewalYNadd(String renewalYNadd) {
	 			this.renewalYNadd = renewalYNadd;
	 		}

	 		public String getPrevpolno() {
	 			return prevpolno;
	 		}

	 		public void setPrevpolno(String prevpolno) {
	 			this.prevpolno = prevpolno;
	 		}

	 		private String prevpolno="";
	    
	    public String getPslYN() {
			return pslYN;
		}
		public void setPslYN(String pslYN) {
			this.pslYN = pslYN;
		}
		public String getPsllimit() {
			return psllimit;
		}
		public void setPsllimit(String psllimit) {
			this.psllimit = psllimit;
		}
		public String getAlternativecopay() {
			return alternativecopay;
		}
		public void setAlternativecopay(String alternativecopay) {
			this.alternativecopay = alternativecopay;
		}
		public String getAlternativecopayDesc() {
			return alternativecopayDesc;
		}
		public void setAlternativecopayDesc(String alternativecopayDesc) {
			this.alternativecopayDesc = alternativecopayDesc;
		}
		private String chiropractic="";
	    public String getChiropractic() {
			return chiropractic;
		}
		public void setChiropractic(String chiropractic) {
			this.chiropractic = chiropractic;
		}
		public String getOrganlimitDesc() {
			return organlimitDesc;
		}
		public void setOrganlimitDesc(String organlimitDesc) {
			this.organlimitDesc = organlimitDesc;
		}
		public String getOrganlimit() {
			return organlimit;
		}
		public void setOrganlimit(String organlimit) {
			this.organlimit = organlimit;
		}
		private String strambulanace="";
	    private String stracendental="";
	    private String strdevated="";
	    private String strreconstructive="";
	    private String gumsurgery="";
	    private String reconstructive="";
	    private String secondmedical="";
	    private String PhysiotherepylimitDesc="";
	    private String strinpatientboadrdDesc="";
	    private String parentaccomdationDesc="";
	    private String strinpatientcashDesc="";
	    private String PhysiotherepySessionDesc="";
	    private String alternativetreatmentlimitDesc="";
	    private String internationalEmergencylimitDesc="";
	    private String psychiatrylimitDesc="";
	    private String psychiatrylimitCopayDesc="";
	    private String vaccinationslimitDesc="";
	    private String vaccinationsDesc="";
	    private String PreexistingconditionslimitDesc="";
	    private String MaintenanceofChronicDesc="";
	    private String HormoneReplacementTherapylimitDesc="";
	    private String InpatientRehabilitationDesc="";
	    private String NursingathomelimitDesc="";
	    private String VitaminsDesc="";
	    private String PassiveWarDesc="";
	    private String PreandpostnatalDesc="";
	    private String WellbeingbenefitDesc="";
	    private String ExternalProsthesisDesc="";
	    private String workrelatedDesc="";
	    private String lifeThreateningDesc="";
	    private String obesityDesc="";
	    private String hospiceDesc="";
	    private String hospiceandPalliativeDesc="";
	    private String dieticanDesc="";
	    private String ditecianlimitDesc="";
	    private String hIVandaIDSLimitDesc="";
	    private String circumcisionlimitDesc="";
	    private String compassionatevisitDesc="";
	    private String externalmedicalDesc="";
	    private String healthscreenlimitDesc="";
	    private String healthsessionsDesc="";
	    private String healthscreencopayDesc="";
	    private String pregnancyDesc=""; 
	    private String deductiblecoinsuranceDesc="";
	    private String externalmedicalcopayDesc="";
	    private String vaccinationage="";
	    private String strintcheck="";
	    
	    public String getStrintcheck() {
			return strintcheck;
		}
		public void setStrintcheck(String strintcheck) {
			this.strintcheck = strintcheck;
		}
		public String getVaccinationage() {
			return vaccinationage;
		}
		public void setVaccinationage(String vaccinationage) {
			this.vaccinationage = vaccinationage;
		}
		public String getPreandpostnatalDesc() {
			return PreandpostnatalDesc;
		}
		public void setPreandpostnatalDesc(String preandpostnatalDesc) {
			PreandpostnatalDesc = preandpostnatalDesc;
		}
		public String getWellbeingbenefitDesc() {
			return WellbeingbenefitDesc;
		}
		public void setWellbeingbenefitDesc(String wellbeingbenefitDesc) {
			WellbeingbenefitDesc = wellbeingbenefitDesc;
		}
		public String getExternalProsthesisDesc() {
			return ExternalProsthesisDesc;
		}
		public void setExternalProsthesisDesc(String externalProsthesisDesc) {
			ExternalProsthesisDesc = externalProsthesisDesc;
		}
		public String getWorkrelatedDesc() {
			return workrelatedDesc;
		}
		public void setWorkrelatedDesc(String workrelatedDesc) {
			this.workrelatedDesc = workrelatedDesc;
		}
		public String getLifeThreateningDesc() {
			return lifeThreateningDesc;
		}
		public void setLifeThreateningDesc(String lifeThreateningDesc) {
			this.lifeThreateningDesc = lifeThreateningDesc;
		}
		public String getObesityDesc() {
			return obesityDesc;
		}
		public void setObesityDesc(String obesityDesc) {
			this.obesityDesc = obesityDesc;
		}
		public String getHospiceDesc() {
			return hospiceDesc;
		}
		public void setHospiceDesc(String hospiceDesc) {
			this.hospiceDesc = hospiceDesc;
		}
		public String getHospiceandPalliativeDesc() {
			return hospiceandPalliativeDesc;
		}
		public void setHospiceandPalliativeDesc(String hospiceandPalliativeDesc) {
			this.hospiceandPalliativeDesc = hospiceandPalliativeDesc;
		}
		public String getDieticanDesc() {
			return dieticanDesc;
		}
		public void setDieticanDesc(String dieticanDesc) {
			this.dieticanDesc = dieticanDesc;
		}
		public String getDitecianlimitDesc() {
			return ditecianlimitDesc;
		}
		public void setDitecianlimitDesc(String ditecianlimitDesc) {
			this.ditecianlimitDesc = ditecianlimitDesc;
		}
		public String gethIVandaIDSLimitDesc() {
			return hIVandaIDSLimitDesc;
		}
		public void sethIVandaIDSLimitDesc(String hIVandaIDSLimitDesc) {
			this.hIVandaIDSLimitDesc = hIVandaIDSLimitDesc;
		}
		public String getCircumcisionlimitDesc() {
			return circumcisionlimitDesc;
		}
		public void setCircumcisionlimitDesc(String circumcisionlimitDesc) {
			this.circumcisionlimitDesc = circumcisionlimitDesc;
		}
		public String getCompassionatevisitDesc() {
			return compassionatevisitDesc;
		}
		public void setCompassionatevisitDesc(String compassionatevisitDesc) {
			this.compassionatevisitDesc = compassionatevisitDesc;
		}
		public String getExternalmedicalDesc() {
			return externalmedicalDesc;
		}
		public void setExternalmedicalDesc(String externalmedicalDesc) {
			this.externalmedicalDesc = externalmedicalDesc;
		}
		public String getHealthscreenlimitDesc() {
			return healthscreenlimitDesc;
		}
		public void setHealthscreenlimitDesc(String healthscreenlimitDesc) {
			this.healthscreenlimitDesc = healthscreenlimitDesc;
		}
		public String getHealthsessionsDesc() {
			return healthsessionsDesc;
		}
		public void setHealthsessionsDesc(String healthsessionsDesc) {
			this.healthsessionsDesc = healthsessionsDesc;
		}
		public String getHealthscreencopayDesc() {
			return healthscreencopayDesc;
		}
		public void setHealthscreencopayDesc(String healthscreencopayDesc) {
			this.healthscreencopayDesc = healthscreencopayDesc;
		}
		public String getPregnancyDesc() {
			return pregnancyDesc;
		}
		public void setPregnancyDesc(String pregnancyDesc) {
			this.pregnancyDesc = pregnancyDesc;
		}
		public String getDeductiblecoinsuranceDesc() {
			return deductiblecoinsuranceDesc;
		}
		public void setDeductiblecoinsuranceDesc(String deductiblecoinsuranceDesc) {
			this.deductiblecoinsuranceDesc = deductiblecoinsuranceDesc;
		}
		public String getExternalmedicalcopayDesc() {
			return externalmedicalcopayDesc;
		}
		public void setExternalmedicalcopayDesc(String externalmedicalcopayDesc) {
			this.externalmedicalcopayDesc = externalmedicalcopayDesc;
		}
		public String getPreexistingconditionslimitDesc() {
			return PreexistingconditionslimitDesc;
		}
		public void setPreexistingconditionslimitDesc(
				String preexistingconditionslimitDesc) {
			PreexistingconditionslimitDesc = preexistingconditionslimitDesc;
		}
		public String getMaintenanceofChronicDesc() {
			return MaintenanceofChronicDesc;
		}
		public void setMaintenanceofChronicDesc(String maintenanceofChronicDesc) {
			MaintenanceofChronicDesc = maintenanceofChronicDesc;
		}
		public String getHormoneReplacementTherapylimitDesc() {
			return HormoneReplacementTherapylimitDesc;
		}
		public void setHormoneReplacementTherapylimitDesc(
				String hormoneReplacementTherapylimitDesc) {
			HormoneReplacementTherapylimitDesc = hormoneReplacementTherapylimitDesc;
		}
		public String getInpatientRehabilitationDesc() {
			return InpatientRehabilitationDesc;
		}
		public void setInpatientRehabilitationDesc(String inpatientRehabilitationDesc) {
			InpatientRehabilitationDesc = inpatientRehabilitationDesc;
		}
		public String getNursingathomelimitDesc() {
			return NursingathomelimitDesc;
		}
		public void setNursingathomelimitDesc(String nursingathomelimitDesc) {
			NursingathomelimitDesc = nursingathomelimitDesc;
		}
		public String getVitaminsDesc() {
			return VitaminsDesc;
		}
		public void setVitaminsDesc(String vitaminsDesc) {
			VitaminsDesc = vitaminsDesc;
		}
		public String getPassiveWarDesc() {
			return PassiveWarDesc;
		}
		public void setPassiveWarDesc(String passiveWarDesc) {
			PassiveWarDesc = passiveWarDesc;
		}
		public String getStrinpatientboadrdDesc() {
			return strinpatientboadrdDesc;
		}
		public void setStrinpatientboadrdDesc(String strinpatientboadrdDesc) {
			this.strinpatientboadrdDesc = strinpatientboadrdDesc;
		}
		public String getParentaccomdationDesc() {
			return parentaccomdationDesc;
		}
		public void setParentaccomdationDesc(String parentaccomdationDesc) {
			this.parentaccomdationDesc = parentaccomdationDesc;
		}
		public String getStrinpatientcashDesc() {
			return strinpatientcashDesc;
		}
		public void setStrinpatientcashDesc(String strinpatientcashDesc) {
			this.strinpatientcashDesc = strinpatientcashDesc;
		}
		public String getPhysiotherepySessionDesc() {
			return PhysiotherepySessionDesc;
		}
		public void setPhysiotherepySessionDesc(String physiotherepySessionDesc) {
			PhysiotherepySessionDesc = physiotherepySessionDesc;
		}
		public String getAlternativetreatmentlimitDesc() {
			return alternativetreatmentlimitDesc;
		}
		public void setAlternativetreatmentlimitDesc(
				String alternativetreatmentlimitDesc) {
			this.alternativetreatmentlimitDesc = alternativetreatmentlimitDesc;
		}
		public String getInternationalEmergencylimitDesc() {
			return internationalEmergencylimitDesc;
		}
		public void setInternationalEmergencylimitDesc(
				String internationalEmergencylimitDesc) {
			this.internationalEmergencylimitDesc = internationalEmergencylimitDesc;
		}
		public String getPsychiatrylimitDesc() {
			return psychiatrylimitDesc;
		}
		public void setPsychiatrylimitDesc(String psychiatrylimitDesc) {
			this.psychiatrylimitDesc = psychiatrylimitDesc;
		}
		public String getPsychiatrylimitCopayDesc() {
			return psychiatrylimitCopayDesc;
		}
		public void setPsychiatrylimitCopayDesc(String psychiatrylimitCopayDesc) {
			this.psychiatrylimitCopayDesc = psychiatrylimitCopayDesc;
		}
		public String getVaccinationslimitDesc() {
			return vaccinationslimitDesc;
		}
		public void setVaccinationslimitDesc(String vaccinationslimitDesc) {
			this.vaccinationslimitDesc = vaccinationslimitDesc;
		}
		public String getVaccinationsDesc() {
			return vaccinationsDesc;
		}
		public void setVaccinationsDesc(String vaccinationsDesc) {
			this.vaccinationsDesc = vaccinationsDesc;
		}
		public String getGumsurgery() {
			return gumsurgery;
		}
		public void setGumsurgery(String gumsurgery) {
			this.gumsurgery = gumsurgery;
		}
		public String getReconstructive() {
			return reconstructive;
		}
		public void setReconstructive(String reconstructive) {
			this.reconstructive = reconstructive;
		}
		public String getSecondmedical() {
			return secondmedical;
		}
		public void setSecondmedical(String secondmedical) {
			this.secondmedical = secondmedical;
		}
		public String getStrinpatientboadrd() {
			return strinpatientboadrd;
		}
		public void setStrinpatientboadrd(String strinpatientboadrd) {
			this.strinpatientboadrd = strinpatientboadrd;
		}
		public String getParentaccomdation() {
			return parentaccomdation;
		}
		public void setParentaccomdation(String parentaccomdation) {
			this.parentaccomdation = parentaccomdation;
		}
		public String getStrinpatientcash() {
			return strinpatientcash;
		}
		public void setStrinpatientcash(String strinpatientcash) {
			this.strinpatientcash = strinpatientcash;
		}
		public String getStrdiagnostics() {
			return strdiagnostics;
		}
		public void setStrdiagnostics(String strdiagnostics) {
			this.strdiagnostics = strdiagnostics;
		}
		public String getPrescribed() {
			return prescribed;
		}
		public void setPrescribed(String prescribed) {
			this.prescribed = prescribed;
		}
		public String getDoctriaya() {
			return doctriaya;
		}
		public void setDoctriaya(String doctriaya) {
			this.doctriaya = doctriaya;
		}
		public String getRadiography() {
			return radiography;
		}
		public void setRadiography(String radiography) {
			this.radiography = radiography;
		}
		public String getOralmax() {
			return oralmax;
		}
		public void setOralmax(String oralmax) {
			this.oralmax = oralmax;
		}
		public String getOrgantransplant() {
			return organtransplant;
		}
		public void setOrgantransplant(String organtransplant) {
			this.organtransplant = organtransplant;
		}
		public String getStrambulanace() {
			return strambulanace;
		}
		public void setStrambulanace(String strambulanace) {
			this.strambulanace = strambulanace;
		}
		public String getStracendental() {
			return stracendental;
		}
		public void setStracendental(String stracendental) {
			this.stracendental = stracendental;
		}
		public String getStrdevated() {
			return strdevated;
		}
		public void setStrdevated(String strdevated) {
			this.strdevated = strdevated;
		}
		public String getStrreconstructive() {
			return strreconstructive;
		}
		public void setStrreconstructive(String strreconstructive) {
			this.strreconstructive = strreconstructive;
		}
		public String getPsychiatrylimitCopay() {
			return psychiatrylimitCopay;
		}
		public void setPsychiatrylimitCopay(String psychiatrylimitCopay) {
			this.psychiatrylimitCopay = psychiatrylimitCopay;
		}
		public String getPsychiatrylimit() {
			return psychiatrylimit;
		}
		public void setPsychiatrylimit(String psychiatrylimit) {
			this.psychiatrylimit = psychiatrylimit;
		}
		private String psychiatrylimitCopay="";
	    private String psychiatrylimit="";
	 
	    
	    public String getInternationalEmergency() {
			return internationalEmergency;
		}
		public void setInternationalEmergency(String internationalEmergency) {
			this.internationalEmergency = internationalEmergency;
		}
		public String getInternationalEmergencylimit() {
			return internationalEmergencylimit;
		}
		public void setInternationalEmergencylimit(String internationalEmergencylimit) {
			this.internationalEmergencylimit = internationalEmergencylimit;
		}
		private String Preandpost="";
		public String getOutsideareaofcover() {
			return outsideareaofcover;
		}
		public void setOutsideareaofcover(String outsideareaofcover) {
			this.outsideareaofcover = outsideareaofcover;
		}
		public String getLevelofcover() {
			return levelofcover;
		}
		public void setLevelofcover(String levelofcover) {
			this.levelofcover = levelofcover;
		}
		public String getInpatientandDaycaretreatment() {
			return inpatientandDaycaretreatment;
		}
		public void setInpatientandDaycaretreatment(String inpatientandDaycaretreatment) {
			this.inpatientandDaycaretreatment = inpatientandDaycaretreatment;
		}
		public String getPhysiotherapy() {
			return physiotherapy;
		}
		public void setPhysiotherapy(String physiotherapy) {
			this.physiotherapy = physiotherapy;
		}
		public String getAlternativetreatment() {
			return alternativetreatment;
		}
		public void setAlternativetreatment(String alternativetreatment) {
			this.alternativetreatment = alternativetreatment;
		}
		public String getDiagnostics() {
			return diagnostics;
		}
		public void setDiagnostics(String diagnostics) {
			this.diagnostics = diagnostics;
		}
		public String getDoctorConsultation() {
			return doctorConsultation;
		}
		public void setDoctorConsultation(String doctorConsultation) {
			this.doctorConsultation = doctorConsultation;
		}
		public String getPrescribedDrug() {
			return prescribedDrug;
		}
		public void setPrescribedDrug(String prescribedDrug) {
			this.prescribedDrug = prescribedDrug;
		}
		public String getInternationalEmergencyMedicalAssistance() {
			return internationalEmergencyMedicalAssistance;
		}
		public void setInternationalEmergencyMedicalAssistance(
				String internationalEmergencyMedicalAssistance) {
			this.internationalEmergencyMedicalAssistance = internationalEmergencyMedicalAssistance;
		}
		public String getRadiotherapy() {
			return radiotherapy;
		}
		public void setRadiotherapy(String radiotherapy) {
			this.radiotherapy = radiotherapy;
		}
		public String getPsychiatric() {
			return psychiatric;
		}
		public void setPsychiatric(String psychiatric) {
			this.psychiatric = psychiatric;
		}
		public String getVaccination() {
			return vaccination;
		}
		public void setVaccination(String vaccination) {
			this.vaccination = vaccination;
		}
		public String getPreexistingconditionslimit() {
			return preexistingconditionslimit;
		}
		public void setPreexistingconditionslimit(String preexistingconditionslimit) {
			this.preexistingconditionslimit = preexistingconditionslimit;
		}
		public String getHormoneReplacementTherapylimit() {
			return hormoneReplacementTherapylimit;
		}
		public void setHormoneReplacementTherapylimit(
				String hormoneReplacementTherapylimit) {
			this.hormoneReplacementTherapylimit = hormoneReplacementTherapylimit;
		}
		public String getNursingathomelimit() {
			return nursingathomelimit;
		}
		public void setNursingathomelimit(String nursingathomelimit) {
			this.nursingathomelimit = nursingathomelimit;
		}
		public String getVitamins() {
			return vitamins;
		}
		public void setVitamins(String vitamins) {
			this.vitamins = vitamins;
		}
		public String getPassiveWar() {
			return passiveWar;
		}
		public void setPassiveWar(String passiveWar) {
			this.passiveWar = passiveWar;
		}
		public String getMaintenanceofChronic() {
			return maintenanceofChronic;
		}
		public void setMaintenanceofChronic(String maintenanceofChronic) {
			this.maintenanceofChronic = maintenanceofChronic;
		}
		public String getInpatientRehabilitation() {
			return inpatientRehabilitation;
		}
		public void setInpatientRehabilitation(String inpatientRehabilitation) {
			this.inpatientRehabilitation = inpatientRehabilitation;
		}
		public String getPreandpostnatal() {
			return preandpostnatal;
		}
		public void setPreandpostnatal(String preandpostnatal) {
			this.preandpostnatal = preandpostnatal;
		}
		public String getExternalProsthesis() {
			return externalProsthesis;
		}
		public void setExternalProsthesis(String externalProsthesis) {
			this.externalProsthesis = externalProsthesis;
		}
		public String getLifeThreatening() {
			return lifeThreatening;
		}
		public void setLifeThreatening(String lifeThreatening) {
			this.lifeThreatening = lifeThreatening;
		}
		public String getHospiceandPalliative() {
			return hospiceandPalliative;
		}
		public void setHospiceandPalliative(String hospiceandPalliative) {
			this.hospiceandPalliative = hospiceandPalliative;
		}
		public String gethIVandaIDSLimit() {
			return hIVandaIDSLimit;
		}
		public void sethIVandaIDSLimit(String hIVandaIDSLimit) {
			this.hIVandaIDSLimit = hIVandaIDSLimit;
		}
		public String getCompassionatevisit() {
			return compassionatevisit;
		}
		public void setCompassionatevisit(String compassionatevisit) {
			this.compassionatevisit = compassionatevisit;
		}
		public String getHealthscreenlimit() {
			return healthscreenlimit;
		}
		public void setHealthscreenlimit(String healthscreenlimit) {
			this.healthscreenlimit = healthscreenlimit;
		}
		public String getExternalmedical() {
			return externalmedical;
		}
		public void setExternalmedical(String externalmedical) {
			this.externalmedical = externalmedical;
		}
		public String getWellbeingbenefit() {
			return wellbeingbenefit;
		}
		public void setWellbeingbenefit(String wellbeingbenefit) {
			this.wellbeingbenefit = wellbeingbenefit;
		}
		public String getWorkrelated() {
			return workrelated;
		}
		public void setWorkrelated(String workrelated) {
			this.workrelated = workrelated;
		}
		public String getObesity() {
			return obesity;
		}
		public void setObesity(String obesity) {
			this.obesity = obesity;
		}
		public String getDieticianlimit() {
			return dieticianlimit;
		}
		public void setDieticianlimit(String dieticianlimit) {
			this.dieticianlimit = dieticianlimit;
		}
		public String getCircumcisionlimit() {
			return circumcisionlimit;
		}
		public void setCircumcisionlimit(String circumcisionlimit) {
			this.circumcisionlimit = circumcisionlimit;
		}
		public String getExternalmedicalcopay() {
			return externalmedicalcopay;
		}
		public void setExternalmedicalcopay(String externalmedicalcopay) {
			this.externalmedicalcopay = externalmedicalcopay;
		}
		public String getHealthsessions() {
			return healthsessions;
		}
		public void setHealthsessions(String healthsessions) {
			this.healthsessions = healthsessions;
		}
		public String getHealthscreencopay() {
			return healthscreencopay;
		}
		public void setHealthscreencopay(String healthscreencopay) {
			this.healthscreencopay = healthscreencopay;
		}
		public String getDeductiblecoinsurance() {
			return deductiblecoinsurance;
		}
		public void setDeductiblecoinsurance(String deductiblecoinsurance) {
			this.deductiblecoinsurance = deductiblecoinsurance;
		}
		public String getComments() {
			return comments;
		}
		public void setComments(String comments) {
			this.comments = comments;
		}
		public String getPregnancy() {
			return pregnancy;
		}
		public void setPregnancy(String pregnancy) {
			this.pregnancy = pregnancy;
		}
		public String getVaccinations() {
			return vaccinations;
		}
		public void setVaccinations(String vaccinations) {
			this.vaccinations = vaccinations;
		}
		public String getPreandpost() {
			return Preandpost;
		}
		public void setPreandpost(String preandpost) {
			Preandpost = preandpost;
		}
		public String getVaccinations1() {
			return vaccinations1;
		}
		public void setVaccinations1(String vaccinations1) {
			this.vaccinations1 = vaccinations1;
		}
		public String getVaccinationslimit() {
			return vaccinationslimit;
		}
		public void setVaccinationslimit(String vaccinationslimit) {
			this.vaccinationslimit = vaccinationslimit;
		}
		public String getPhysiotherepylimit() {
			return Physiotherepylimit;
		}
		public void setPhysiotherepylimit(String physiotherepylimit) {
			Physiotherepylimit = physiotherepylimit;
		}
		public String getPhysiotherepySession() {
			return PhysiotherepySession;
		}
		public void setPhysiotherepySession(String physiotherepySession) {
			PhysiotherepySession = physiotherepySession;
		}
		public String getAlternativetreatmentlimit() {
			return alternativetreatmentlimit;
		}
		public void setAlternativetreatmentlimit(
				String alternativetreatmentlimit) {
			this.alternativetreatmentlimit = alternativetreatmentlimit;
		}
		public String getPreexistingcoadtion() {
			return preexistingcoadtion;
		}
		public void setPreexistingcoadtion(String preexistingcoadtion) {
			this.preexistingcoadtion = preexistingcoadtion;
		}
		public String getMaintenancecoadtion() {
			return maintenancecoadtion;
		}
		public void setMaintenancecoadtion(String maintenancecoadtion) {
			this.maintenancecoadtion = maintenancecoadtion;
		}
		public String getHarmonereplace() {
			return harmonereplace;
		}
		public void setHarmonereplace(String harmonereplace) {
			this.harmonereplace = harmonereplace;
		}
		public String getInpatientrehabationtreatment() {
			return inpatientrehabationtreatment;
		}
		public void setInpatientrehabationtreatment(
				String inpatientrehabationtreatment) {
			this.inpatientrehabationtreatment = inpatientrehabationtreatment;
		}
		public String getNursinghome() {
			return nursinghome;
		}
		public void setNursinghome(String nursinghome) {
			this.nursinghome = nursinghome;
		}
		public String getVitaminsmed() {
			return Vitaminsmed;
		}
		public void setVitaminsmed(String vitaminsmed) {
			Vitaminsmed = vitaminsmed;
		}
		public String getWellbeingbenfit() {
			return wellbeingbenfit;
		}
		public void setWellbeingbenfit(String wellbeingbenfit) {
			this.wellbeingbenfit = wellbeingbenfit;
		}
		public String getExternalprothis() {
			return externalprothis;
		}
		public void setExternalprothis(String externalprothis) {
			this.externalprothis = externalprothis;
		}
		public String getWorkinjury() {
			return workinjury;
		}
		public void setWorkinjury(String workinjury) {
			this.workinjury = workinjury;
		}

		public String getLifedisease() {
			return lifedisease;
		}
		public void setLifedisease(String lifedisease) {
			this.lifedisease = lifedisease;
		}
		public String getObesitysurgry() {
			return obesitysurgry;
		}
		public void setObesitysurgry(String obesitysurgry) {
			this.obesitysurgry = obesitysurgry;
		}
		public String getHospice() {
			return hospice;
		}
		public void setHospice(String hospice) {
			this.hospice = hospice;
		}
		public String getDitecianlimit() {
			return ditecianlimit;
		}
		public void setDitecianlimit(String ditecianlimit) {
			this.ditecianlimit = ditecianlimit;
		}
		public String getDietican() {
			return dietican;
		}
		public void setDietican(String dietican) {
			this.dietican = dietican;
		}
		public String getStrhiv() {
			return strhiv;
		}
		public void setStrhiv(String strhiv) {
			this.strhiv = strhiv;
		}
		public String getCircumcision() {
			return circumcision;
		}
		public void setCircumcision(String circumcision) {
			this.circumcision = circumcision;
		}
		public String getCompassionate() {
			return compassionate;
		}
		public void setCompassionate(String compassionate) {
			this.compassionate = compassionate;
		}
		public String getExternalmed() {
			return externalmed;
		}
		public void setExternalmed(String externalmed) {
			this.externalmed = externalmed;
		}
		public String getHealth() {
			return health;
		}
		public void setHealth(String health) {
			this.health = health;
		}
		public String getStracute() {
			return stracute;
		}
		public void setStracute(String stracute) {
			this.stracute = stracute;
		}
		public String getPhysiotherepylimitDesc() {
			return PhysiotherepylimitDesc;
		}
		public void setPhysiotherepylimitDesc(String physiotherepylimitDesc) {
			PhysiotherepylimitDesc = physiotherepylimitDesc;
		}
		public Long getAdditionalseqId() {
			return additionalseqId;
		}
		public void setAdditionalseqId(Long additionalseqId) {
			this.additionalseqId = additionalseqId;
		}
		public Long getPricingno() {
			return pricingno;
		}
		public void setPricingno(Long pricingno) {
			this.pricingno = pricingno;
		}
		@Override
		public String toString() {
			return "AdditionalVO [additionalseqId=" + additionalseqId
					+ ", pricingno=" + pricingno + ", outsideareaofcover="
					+ outsideareaofcover + ", levelofcover=" + levelofcover
					+ ", inpatientandDaycaretreatment="
					+ inpatientandDaycaretreatment + ", physiotherapy="
					+ physiotherapy + ", alternativetreatment="
					+ alternativetreatment + ", diagnostics=" + diagnostics
					+ ", doctorConsultation=" + doctorConsultation
					+ ", prescribedDrug=" + prescribedDrug
					+ ", internationalEmergencyMedicalAssistance="
					+ internationalEmergencyMedicalAssistance
					+ ", radiotherapy=" + radiotherapy + ", psychiatric="
					+ psychiatric + ", vaccination=" + vaccination
					+ ", preexistingconditionslimit="
					+ preexistingconditionslimit
					+ ", hormoneReplacementTherapylimit="
					+ hormoneReplacementTherapylimit + ", nursingathomelimit="
					+ nursingathomelimit + ", vitamins=" + vitamins
					+ ", passiveWar=" + passiveWar + ", maintenanceofChronic="
					+ maintenanceofChronic + ", inpatientRehabilitation="
					+ inpatientRehabilitation + ", preandpostnatal="
					+ preandpostnatal + ", externalProsthesis="
					+ externalProsthesis + ", lifeThreatening="
					+ lifeThreatening + ", hospiceandPalliative="
					+ hospiceandPalliative + ", hIVandaIDSLimit="
					+ hIVandaIDSLimit + ", compassionatevisit="
					+ compassionatevisit + ", healthscreenlimit="
					+ healthscreenlimit + ", externalmedical="
					+ externalmedical + ", wellbeingbenefit="
					+ wellbeingbenefit + ", workrelated=" + workrelated
					+ ", obesity=" + obesity + ", dieticianlimit="
					+ dieticianlimit + ", circumcisionlimit="
					+ circumcisionlimit + ", externalmedicalcopay="
					+ externalmedicalcopay + ", healthsessions="
					+ healthsessions + ", healthscreencopay="
					+ healthscreencopay + ", deductiblecoinsurance="
					+ deductiblecoinsurance + ", comments=" + comments
					+ ", pregnancy=" + pregnancy + ", vaccinations="
					+ vaccinations + ", vaccinationslimit=" + vaccinationslimit
					+ ", vaccinations1=" + vaccinations1
					+ ", Physiotherepylimit=" + Physiotherepylimit
					+ ", PhysiotherepySession=" + PhysiotherepySession
					+ ", alternativetreatmentlimit="
					+ alternativetreatmentlimit + ", internationalEmergency="
					+ internationalEmergency + ", internationalEmergencylimit="
					+ internationalEmergencylimit + ", lifeThreateningdiease="
					+ lifeThreateningdiease + ", workrelateddrop1Desc="
					+ workrelateddrop1Desc + ", lifeThreateningdieaseDesc="
					+ lifeThreateningdieaseDesc + ", workrelateddrop1="
					+ workrelateddrop1 + ", preexistingcoadtion="
					+ preexistingcoadtion + ", harmonereplace="
					+ harmonereplace + ", inpatientrehabationtreatment="
					+ inpatientrehabationtreatment + ", externalprothis="
					+ externalprothis + ", workinjury=" + workinjury
					+ ", wellbeingbenfit=" + wellbeingbenfit + ", Vitaminsmed="
					+ Vitaminsmed + ", maintenancecoadtion="
					+ maintenancecoadtion + ", obesitysurgry=" + obesitysurgry
					+ ", lifedisease=" + lifedisease + ", ditecianlimit="
					+ ditecianlimit + ", dietican=" + dietican + ", stracute="
					+ stracute + ", hospice=" + hospice + ", strhiv=" + strhiv
					+ ", nursinghome=" + nursinghome + ", circumcision="
					+ circumcision + ", compassionate=" + compassionate
					+ ", externalmed=" + externalmed + ", health=" + health
					+ ", strinpatientboadrd=" + strinpatientboadrd
					+ ", parentaccomdation=" + parentaccomdation
					+ ", strinpatientcash=" + strinpatientcash
					+ ", strdiagnostics=" + strdiagnostics + ", prescribed="
					+ prescribed + ", doctriaya=" + doctriaya
					+ ", radiography=" + radiography + ", oralmax=" + oralmax
					+ ", organtransplant=" + organtransplant + ", organlimit="
					+ organlimit + ", organlimitDesc=" + organlimitDesc
					+ ", alternativecopay=" + alternativecopay
					+ ", alternativecopayDesc=" + alternativecopayDesc
					+ ", chiropractic=" + chiropractic + ", strambulanace="
					+ strambulanace + ", stracendental=" + stracendental
					+ ", strdevated=" + strdevated + ", strreconstructive="
					+ strreconstructive + ", gumsurgery=" + gumsurgery
					+ ", reconstructive=" + reconstructive + ", secondmedical="
					+ secondmedical + ", PhysiotherepylimitDesc="
					+ PhysiotherepylimitDesc + ", strinpatientboadrdDesc="
					+ strinpatientboadrdDesc + ", parentaccomdationDesc="
					+ parentaccomdationDesc + ", strinpatientcashDesc="
					+ strinpatientcashDesc + ", PhysiotherepySessionDesc="
					+ PhysiotherepySessionDesc
					+ ", alternativetreatmentlimitDesc="
					+ alternativetreatmentlimitDesc
					+ ", internationalEmergencylimitDesc="
					+ internationalEmergencylimitDesc
					+ ", psychiatrylimitDesc=" + psychiatrylimitDesc
					+ ", psychiatrylimitCopayDesc=" + psychiatrylimitCopayDesc
					+ ", vaccinationslimitDesc=" + vaccinationslimitDesc
					+ ", vaccinationsDesc=" + vaccinationsDesc
					+ ", PreexistingconditionslimitDesc="
					+ PreexistingconditionslimitDesc
					+ ", MaintenanceofChronicDesc=" + MaintenanceofChronicDesc
					+ ", HormoneReplacementTherapylimitDesc="
					+ HormoneReplacementTherapylimitDesc
					+ ", InpatientRehabilitationDesc="
					+ InpatientRehabilitationDesc + ", NursingathomelimitDesc="
					+ NursingathomelimitDesc + ", VitaminsDesc=" + VitaminsDesc
					+ ", PassiveWarDesc=" + PassiveWarDesc
					+ ", PreandpostnatalDesc=" + PreandpostnatalDesc
					+ ", WellbeingbenefitDesc=" + WellbeingbenefitDesc
					+ ", ExternalProsthesisDesc=" + ExternalProsthesisDesc
					+ ", workrelatedDesc=" + workrelatedDesc
					+ ", lifeThreateningDesc=" + lifeThreateningDesc
					+ ", obesityDesc=" + obesityDesc + ", hospiceDesc="
					+ hospiceDesc + ", hospiceandPalliativeDesc="
					+ hospiceandPalliativeDesc + ", dieticanDesc="
					+ dieticanDesc + ", ditecianlimitDesc=" + ditecianlimitDesc
					+ ", hIVandaIDSLimitDesc=" + hIVandaIDSLimitDesc
					+ ", circumcisionlimitDesc=" + circumcisionlimitDesc
					+ ", compassionatevisitDesc=" + compassionatevisitDesc
					+ ", externalmedicalDesc=" + externalmedicalDesc
					+ ", healthscreenlimitDesc=" + healthscreenlimitDesc
					+ ", healthsessionsDesc=" + healthsessionsDesc
					+ ", healthscreencopayDesc=" + healthscreencopayDesc
					+ ", pregnancyDesc=" + pregnancyDesc
					+ ", deductiblecoinsuranceDesc="
					+ deductiblecoinsuranceDesc + ", externalmedicalcopayDesc="
					+ externalmedicalcopayDesc + ", psychiatrylimitCopay="
					+ psychiatrylimitCopay + ", psychiatrylimit="
					+ psychiatrylimit + ", Preandpost=" + Preandpost
					+ ", getWorkrelateddrop1Desc()="
					+ getWorkrelateddrop1Desc()
					+ ", getLifeThreateningdieaseDesc()="
					+ getLifeThreateningdieaseDesc()
					+ ", getLifeThreateningdiease()="
					+ getLifeThreateningdiease() + ", getWorkrelateddrop1()="
					+ getWorkrelateddrop1() + ", getAlternativecopay()="
					+ getAlternativecopay() + ", getAlternativecopayDesc()="
					+ getAlternativecopayDesc() + ", getChiropractic()="
					+ getChiropractic() + ", getOrganlimitDesc()="
					+ getOrganlimitDesc() + ", getOrganlimit()="
					+ getOrganlimit() + ", getPreandpostnatalDesc()="
					+ getPreandpostnatalDesc() + ", getWellbeingbenefitDesc()="
					+ getWellbeingbenefitDesc()
					+ ", getExternalProsthesisDesc()="
					+ getExternalProsthesisDesc() + ", getWorkrelatedDesc()="
					+ getWorkrelatedDesc() + ", getLifeThreateningDesc()="
					+ getLifeThreateningDesc() + ", getObesityDesc()="
					+ getObesityDesc() + ", getHospiceDesc()="
					+ getHospiceDesc() + ", getHospiceandPalliativeDesc()="
					+ getHospiceandPalliativeDesc() + ", getDieticanDesc()="
					+ getDieticanDesc() + ", getDitecianlimitDesc()="
					+ getDitecianlimitDesc() + ", gethIVandaIDSLimitDesc()="
					+ gethIVandaIDSLimitDesc()
					+ ", getCircumcisionlimitDesc()="
					+ getCircumcisionlimitDesc()
					+ ", getCompassionatevisitDesc()="
					+ getCompassionatevisitDesc()
					+ ", getExternalmedicalDesc()=" + getExternalmedicalDesc()
					+ ", getHealthscreenlimitDesc()="
					+ getHealthscreenlimitDesc() + ", getHealthsessionsDesc()="
					+ getHealthsessionsDesc() + ", getHealthscreencopayDesc()="
					+ getHealthscreencopayDesc() + ", getPregnancyDesc()="
					+ getPregnancyDesc() + ", getDeductiblecoinsuranceDesc()="
					+ getDeductiblecoinsuranceDesc()
					+ ", getExternalmedicalcopayDesc()="
					+ getExternalmedicalcopayDesc()
					+ ", getPreexistingconditionslimitDesc()="
					+ getPreexistingconditionslimitDesc()
					+ ", getMaintenanceofChronicDesc()="
					+ getMaintenanceofChronicDesc()
					+ ", getHormoneReplacementTherapylimitDesc()="
					+ getHormoneReplacementTherapylimitDesc()
					+ ", getInpatientRehabilitationDesc()="
					+ getInpatientRehabilitationDesc()
					+ ", getNursingathomelimitDesc()="
					+ getNursingathomelimitDesc() + ", getVitaminsDesc()="
					+ getVitaminsDesc() + ", getPassiveWarDesc()="
					+ getPassiveWarDesc() + ", getStrinpatientboadrdDesc()="
					+ getStrinpatientboadrdDesc()
					+ ", getParentaccomdationDesc()="
					+ getParentaccomdationDesc()
					+ ", getStrinpatientcashDesc()="
					+ getStrinpatientcashDesc()
					+ ", getPhysiotherepySessionDesc()="
					+ getPhysiotherepySessionDesc()
					+ ", getAlternativetreatmentlimitDesc()="
					+ getAlternativetreatmentlimitDesc()
					+ ", getInternationalEmergencylimitDesc()="
					+ getInternationalEmergencylimitDesc()
					+ ", getPsychiatrylimitDesc()=" + getPsychiatrylimitDesc()
					+ ", getPsychiatrylimitCopayDesc()="
					+ getPsychiatrylimitCopayDesc()
					+ ", getVaccinationslimitDesc()="
					+ getVaccinationslimitDesc() + ", getVaccinationsDesc()="
					+ getVaccinationsDesc() + ", getGumsurgery()="
					+ getGumsurgery() + ", getReconstructive()="
					+ getReconstructive() + ", getSecondmedical()="
					+ getSecondmedical() + ", getStrinpatientboadrd()="
					+ getStrinpatientboadrd() + ", getParentaccomdation()="
					+ getParentaccomdation() + ", getStrinpatientcash()="
					+ getStrinpatientcash() + ", getStrdiagnostics()="
					+ getStrdiagnostics() + ", getPrescribed()="
					+ getPrescribed() + ", getDoctriaya()=" + getDoctriaya()
					+ ", getRadiography()=" + getRadiography()
					+ ", getOralmax()=" + getOralmax()
					+ ", getOrgantransplant()=" + getOrgantransplant()
					+ ", getStrambulanace()=" + getStrambulanace()
					+ ", getStracendental()=" + getStracendental()
					+ ", getStrdevated()=" + getStrdevated()
					+ ", getStrreconstructive()=" + getStrreconstructive()
					+ ", getPsychiatrylimitCopay()="
					+ getPsychiatrylimitCopay() + ", getPsychiatrylimit()="
					+ getPsychiatrylimit() + ", getInternationalEmergency()="
					+ getInternationalEmergency()
					+ ", getInternationalEmergencylimit()="
					+ getInternationalEmergencylimit()
					+ ", getOutsideareaofcover()=" + getOutsideareaofcover()
					+ ", getLevelofcover()=" + getLevelofcover()
					+ ", getInpatientandDaycaretreatment()="
					+ getInpatientandDaycaretreatment()
					+ ", getPhysiotherapy()=" + getPhysiotherapy()
					+ ", getAlternativetreatment()="
					+ getAlternativetreatment() + ", getDiagnostics()="
					+ getDiagnostics() + ", getDoctorConsultation()="
					+ getDoctorConsultation() + ", getPrescribedDrug()="
					+ getPrescribedDrug()
					+ ", getInternationalEmergencyMedicalAssistance()="
					+ getInternationalEmergencyMedicalAssistance()
					+ ", getRadiotherapy()=" + getRadiotherapy()
					+ ", getPsychiatric()=" + getPsychiatric()
					+ ", getVaccination()=" + getVaccination()
					+ ", getPreexistingconditionslimit()="
					+ getPreexistingconditionslimit()
					+ ", getHormoneReplacementTherapylimit()="
					+ getHormoneReplacementTherapylimit()
					+ ", getNursingathomelimit()=" + getNursingathomelimit()
					+ ", getVitamins()=" + getVitamins() + ", getPassiveWar()="
					+ getPassiveWar() + ", getMaintenanceofChronic()="
					+ getMaintenanceofChronic()
					+ ", getInpatientRehabilitation()="
					+ getInpatientRehabilitation() + ", getPreandpostnatal()="
					+ getPreandpostnatal() + ", getExternalProsthesis()="
					+ getExternalProsthesis() + ", getLifeThreatening()="
					+ getLifeThreatening() + ", getHospiceandPalliative()="
					+ getHospiceandPalliative() + ", gethIVandaIDSLimit()="
					+ gethIVandaIDSLimit() + ", getCompassionatevisit()="
					+ getCompassionatevisit() + ", getHealthscreenlimit()="
					+ getHealthscreenlimit() + ", getExternalmedical()="
					+ getExternalmedical() + ", getWellbeingbenefit()="
					+ getWellbeingbenefit() + ", getWorkrelated()="
					+ getWorkrelated() + ", getObesity()=" + getObesity()
					+ ", getDieticianlimit()=" + getDieticianlimit()
					+ ", getCircumcisionlimit()=" + getCircumcisionlimit()
					+ ", getExternalmedicalcopay()="
					+ getExternalmedicalcopay() + ", getHealthsessions()="
					+ getHealthsessions() + ", getHealthscreencopay()="
					+ getHealthscreencopay() + ", getDeductiblecoinsurance()="
					+ getDeductiblecoinsurance() + ", getComments()="
					+ getComments() + ", getPregnancy()=" + getPregnancy()
					+ ", getVaccinations()=" + getVaccinations()
					+ ", getPreandpost()=" + getPreandpost()
					+ ", getVaccinations1()=" + getVaccinations1()
					+ ", getVaccinationslimit()=" + getVaccinationslimit()
					+ ", getPhysiotherepylimit()=" + getPhysiotherepylimit()
					+ ", getPhysiotherepySession()="
					+ getPhysiotherepySession()
					+ ", getAlternativetreatmentlimit()="
					+ getAlternativetreatmentlimit()
					+ ", getPreexistingcoadtion()=" + getPreexistingcoadtion()
					+ ", getMaintenancecoadtion()=" + getMaintenancecoadtion()
					+ ", getHarmonereplace()=" + getHarmonereplace()
					+ ", getInpatientrehabationtreatment()="
					+ getInpatientrehabationtreatment() + ", getNursinghome()="
					+ getNursinghome() + ", getVitaminsmed()="
					+ getVitaminsmed() + ", getWellbeingbenfit()="
					+ getWellbeingbenfit() + ", getExternalprothis()="
					+ getExternalprothis() + ", getWorkinjury()="
					+ getWorkinjury() + ", getLifedisease()="
					+ getLifedisease() + ", getObesitysurgry()="
					+ getObesitysurgry() + ", getHospice()=" + getHospice()
					+ ", getDitecianlimit()=" + getDitecianlimit()
					+ ", getDietican()=" + getDietican() + ", getStrhiv()="
					+ getStrhiv() + ", getCircumcision()=" + getCircumcision()
					+ ", getCompassionate()=" + getCompassionate()
					+ ", getExternalmed()=" + getExternalmed()
					+ ", getHealth()=" + getHealth() + ", getStracute()="
					+ getStracute() + ", getPhysiotherepylimitDesc()="
					+ getPhysiotherepylimitDesc() + ", getAdditionalseqId()="
					+ getAdditionalseqId() + ", getPricingno()="
					+ getPricingno() + ", getAddedDate()=" + getAddedDate()
					+ ", getUpdatedDate()=" + getUpdatedDate()
					+ ", getAddedBy()=" + getAddedBy() + ", getUpdatedBy()="
					+ getUpdatedBy() + ", getTimestamp()=" + getTimestamp()
					+ ", getId()=" + getId() + ", getVidalBranchSeqID()="
					+ getVidalBranchSeqID() + ", getVidalBranchName()="
					+ getVidalBranchName() + ", getCaption()=" + getCaption()
					+ ", getClass()=" + getClass() + ", hashCode()="
					+ hashCode() + ", toString()=" + super.toString() + "]";
		}
		public String getInpatntflag() {
			return inpatntflag;
		}
		public void setInpatntflag(String inpatntflag) {
			this.inpatntflag = inpatntflag;
		}
		public String getCheckconstructive() {
			return checkconstructive;
		}
		public void setCheckconstructive(String checkconstructive) {
			this.checkconstructive = checkconstructive;
		}
		public String getPricingRefno() {
			return pricingRefno;
		}
		public void setPricingRefno(String pricingRefno) {
			this.pricingRefno = pricingRefno;
		}
		public String getCongtal() {
			return congtal;
		}
		public void setCongtal(String congtal) {
			this.congtal = congtal;
		}
		public String getOncology() {
			return oncology;
		}
		public void setOncology(String oncology) {
			this.oncology = oncology;
		}
		public String getRepatriation() {
			return repatriation;
		}
		public void setRepatriation(String repatriation) {
			this.repatriation = repatriation;
		}
		public String getTerminal() {
			return terminal;
		}
		public void setTerminal(String terminal) {
			this.terminal = terminal;
		}
		public String getHome() {
			return home;
		}
		public void setHome(String home) {
			this.home = home;
		}
		public String getInpatientlimit() {
			return inpatientlimit;
		}
		public void setInpatientlimit(String inpatientlimit) {
			this.inpatientlimit = inpatientlimit;
		}
		public String getAlternativesession() {
			return alternativesession;
		}
		public void setAlternativesession(String alternativesession) {
			this.alternativesession = alternativesession;
		}
		public String getApproval() {
			return approval;
		}
		public void setApproval(String approval) {
			this.approval = approval;
		}
		public String getNewborn() {
			return newborn;
		}
		public void setNewborn(String newborn) {
			this.newborn = newborn;
		}
		public String getDentalprothis() {
			return dentalprothis;
		}
		public void setDentalprothis(String dentalprothis) {
			this.dentalprothis = dentalprothis;
		}
		public String getParentacmdation() {
			return parentacmdation;
		}
		public void setParentacmdation(String parentacmdation) {
			this.parentacmdation = parentacmdation;
		}
		public String getAlternativesessiondesc() {
			return alternativesessiondesc;
		}
		public void setAlternativesessiondesc(String alternativesessiondesc) {
			this.alternativesessiondesc = alternativesessiondesc;
		}
		public String getApprovaldesc() {
			return approvaldesc;
		}
		public void setApprovaldesc(String approvaldesc) {
			this.approvaldesc = approvaldesc;
		}
		public String getPsllimitdesc() {
			return psllimitdesc;
		}
		public void setPsllimitdesc(String psllimitdesc) {
			this.psllimitdesc = psllimitdesc;
		}
		public String getInpatientlimitdecs() {
			return inpatientlimitdecs;
		}
		public void setInpatientlimitdecs(String inpatientlimitdecs) {
			this.inpatientlimitdecs = inpatientlimitdecs;
		}
		public String getFetch() {
			return fetch;
		}
		public void setFetch(String fetch) {
			this.fetch = fetch;
		}
		public String getCongtalDesc() {
			return congtalDesc;
		}
		public void setCongtalDesc(String congtalDesc) {
			this.congtalDesc = congtalDesc;
		}
		public String getOncologydesc() {
			return oncologydesc;
		}
		public void setOncologydesc(String oncologydesc) {
			this.oncologydesc = oncologydesc;
		}
		public String getRepatriationDesc() {
			return repatriationDesc;
		}
		public void setRepatriationDesc(String repatriationDesc) {
			this.repatriationDesc = repatriationDesc;
		}
		public String getTerminalDesc() {
			return terminalDesc;
		}
		public void setTerminalDesc(String terminalDesc) {
			this.terminalDesc = terminalDesc;
		}
		public String getDentalprothisdesc() {
			return dentalprothisdesc;
		}
		public void setDentalprothisdesc(String dentalprothisdesc) {
			this.dentalprothisdesc = dentalprothisdesc;
		}
		public String getAlternativeTreatments() {
			return AlternativeTreatments;
		}
		public void setAlternativeTreatments(String alternativeTreatments) {
			AlternativeTreatments = alternativeTreatments;
		}
		public String getAlternativeTreatmentsdesc() {
			return AlternativeTreatmentsdesc;
		}
		public void setAlternativeTreatmentsdesc(String alternativeTreatmentsdesc) {
			AlternativeTreatmentsdesc = alternativeTreatmentsdesc;
		}
		public String getReimbursmentLevel() {
			return ReimbursmentLevel;
		}
		public void setReimbursmentLevel(String reimbursmentLevel) {
			ReimbursmentLevel = reimbursmentLevel;
		}
		public String getReimbursmentLeveldesc() {
			return ReimbursmentLeveldesc;
		}
		public void setReimbursmentLeveldesc(String reimbursmentLeveldesc) {
			ReimbursmentLeveldesc = reimbursmentLeveldesc;
		}
		
		
	    
}

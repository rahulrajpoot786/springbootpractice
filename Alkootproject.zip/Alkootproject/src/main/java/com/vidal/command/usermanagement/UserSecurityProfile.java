package com.vidal.command.usermanagement;

import java.sql.CallableStatement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSessionBindingEvent;
import javax.servlet.http.HttpSessionBindingListener;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import com.sun.corba.se.pept.transport.Connection;
import com.vidal.common.ResourceManager;
import com.vidal.common.UXUtility;
import com.vidal.common.VidalCommon;
import com.vidal.common.security.SecurityProfile;
import com.vidal.services.authentication.AuthenticationService;

import oracle.jdbc.OracleTypes;


public class UserSecurityProfile extends UserVO implements HttpSessionBindingListener{

	
	private static final Logger logger = LoggerFactory.getLogger(UserSecurityProfile.class);
	@Override
	public void valueBound(HttpSessionBindingEvent arg0) {
		// TODO Auto-generated method stub
		

	
	}

	@Override
	public void valueUnbound(HttpSessionBindingEvent arg0) {
		
		// TODO Auto-generated method stub
		
		
	

		
							
			  int iResult = 0; 
			  try( java.sql.Connection conn= ResourceManager.getDataSource().getConnection();
			  CallableStatement cStmtObject =	(java.sql.CallableStatement)conn.prepareCall( "{CALL AUTHENTICATION_PKG.LOGOUT(?,?,?)}}");)
			   {
				  //cStmtObject.setLong(1, Long.parseLong(UXUtility.checkNull(this.getUSER_SEQ_ID()).toString()));
				//cStmtObject.registerOutParameter(2,OracleTypes.INTEGER);
				//cStmtObject.execute();
				//iResult = cStmtObject.getInt(2);
	
		
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		
							
		
	}
	
	    private SecurityProfile securityProfileObj = null;
	    private String strActiveYN = "";
	    private String strUserName="";
	    private Long lUserSeqId = null;
	    private String strLoginType="";
	    private String strUserTypeId = "";
	    private String strEMAIL_ID="";
	    private Long lngBranchID=null;
	    private String strBranchName="";
	    private Long lngContactTypeID=null;
	    private String strMobileNo="";
	    private Long lngRoleSeqId=null;
	    private String strRoleName="";
	    private String strLoginDate="";
	    private HashMap hmWorkFlow=null;
	    private ArrayList alGroupList=null;
	    private Long lngPolicyGrpSeqID = null;
	    private String strTPAEnrolNbr = "";
	    private Long lngPolicySeqID = null;
	    private String strIntAccessTypeID = ""; //INTIMATION_ACCESS_GEN_TYPE_ID
	    private String strOnlineAssTypeID = ""; //ONLINE_ASSISTANCE_GEN_TYPE_ID
	    private String strTemplateName = "";
	    private String strWellnessAssTypeID = ""; //Wellness_GEN_TYPE_ID
	    private String strEnrollmentAccessTypeID = "";

		private String strEmployeeCredentialYN="";
	    private String strClmRegdYN="";
	    private String strBiilsPendYN="";
	    private String strListEmpDepPeriodYN="";
	    private String strListEmpDepTillYN="";
	    private String strOnlinePreAuthRptYN="";
	    private String strClmRegSummaryYN="";
	    private String strClmRegDetailYN="";
	    private String strCustomerCode = "";
	    private String strOnlineRatingTypeID="";
	    private String strFirstLoginYN ="";
	    private Long lngContactSeqID = null;
	    private Long lngMemSeqID = null;
	    private Long teppolicygrpseqid = null;
	    private String tempStrTemplate="";
	    private String strClmIntimationYN="";
	    private String PswdExpiryYN = "";
	    private String PwdValidYN = "";
		
	    private String lCashBenefitSeqID = "HCB";
	    private String lCashBenefitID = "CONV_BENEF";
	    private String strRandomNo = "";
		
	    private String lCriticalBenefitID = "CRITICAL_BENEFIT";
	    
	    private String strINSPaymentReportYN="";
	   
	    private String strEmpanelNumber = "";
	    private Long lngHospSeqId=null;
	    private Long lngHosContactSeqID = null;
	    private String strHospitalName = "";
	    private String strClaimSubmissionAllow = "";
	    private String strCignaAbbre="";
	    private String strHomeAllow="";
	    private String strPreAuthAllow="";
	    private String strMyProfileAllow="";
	    private String currentStatus ="";
	    
	    private String corpClaimFlag="";
	    /**
		 * @return the strCignaAbbre
		 */
		public String getCignaAbbre() {
			return strCignaAbbre;
		}

		/**
		 * @param strCignaAbbre the strCignaAbbre to set
		 */
		public void setCignaAbbre(String strCignaAbbre) {
			this.strCignaAbbre = strCignaAbbre;
		}

	    
	    public String getMyProfileAllow() {
			return strMyProfileAllow;
		}

		public void setMyProfileAllow(String strMyProfileAllow) {
			this.strMyProfileAllow = strMyProfileAllow;
		}

		public String getHomeAllow() {
			return strHomeAllow;
		}

		public void setHomeAllow(String strHomeAllow) {
			this.strHomeAllow = strHomeAllow;
		}

		public String getPreAuthAllow() {
			return strPreAuthAllow;
		}

		public void setPreAuthAllow(String strPreAuthAllow) {
			this.strPreAuthAllow = strPreAuthAllow;
		}

		public String getEnrollmentAccessTypeID() {
			return strEnrollmentAccessTypeID;
		}

		public void setEnrollmentAccessTypeID(String strEnrollmentAccessTypeID) {
			this.strEnrollmentAccessTypeID = strEnrollmentAccessTypeID;
		}
		/**
		 * @return the strClaimSubmissionAllow
		 */
		public String getClaimSubmissionAllow() {
			return strClaimSubmissionAllow;
		}

		/**
		 * @param strClaimSubmissionAllow the strClaimSubmissionAllow to set
		 */
		public void setClaimSubmissionAllow(String strClaimSubmissionAllow) {
			this.strClaimSubmissionAllow = strClaimSubmissionAllow;
		}

		public void setHospitalName(String hospitalName) {
			strHospitalName = hospitalName;
		}

		public String getHospitalName() {
			return strHospitalName;
		}

		public void setHosContactSeqID(Long hosContactSeqID) {
			lngHosContactSeqID = hosContactSeqID;
		}

		public Long getHosContactSeqID() {
			return lngHosContactSeqID;
		}

		public void setHospSeqId(Long hospSeqId) {
			lngHospSeqId = hospSeqId;
		}

		public Long getHospSeqId() {
			return lngHospSeqId;
		}

		public void setEmpanelNumber(String empanelNumber) {
			strEmpanelNumber = empanelNumber;
		}

		public String getEmpanelNumber() {
			return strEmpanelNumber;
		}
		 //added as per hospital Login
		
		public void setCashBenefitID(String lCashBenefitID)
	    {
	        this.lCashBenefitID = lCashBenefitID;
	    }//end of setUSER_SEQ_ID(String strUserSeqId)

	    /**
	     * Retrieve the user sequence id
	     * @return lUserSeqId Long user sequence id
	     */
	    public String getCashBenefitID()
	    {
	        return lCashBenefitID ;
	    }//end of getUSER_SEQ_ID()
	    
	    public void setCashBenefitSeqID(String lCashBenefitSeqID)
	    {
	        this.lCashBenefitSeqID = lCashBenefitSeqID;
	    }//end of setUSER_SEQ_ID(String strUserSeqId)

	    
	    
	  //KOC-1273 FOR PRAVEEN CRITICAL BENEFIT
	    public void setCriticalBenefitID(String lCriticalBenefitID)
	    {
	        this.lCriticalBenefitID = lCriticalBenefitID;
	    }//end of setUSER_SEQ_ID(String strUserSeqId)

	    /**
	     * Retrieve the user sequence id
	     * @return lUserSeqId Long user sequence id
	     */
	    public String getCashBenefitSeqID()
	    {
	        return lCashBenefitSeqID ;
	    }//end of getUSER_SEQ_ID()
		
		//KOC 1270 for hospital cash benefit
	    
	    /**
	     * Retrieve the user sequence id
	     * @return lUserSeqId Long user sequence id
	     */
	    public String getCriticalBenefitID()
	    {
	        return lCriticalBenefitID ;
	    }//end of getUSER_SEQ_ID()
	  //KOC-1273 FOR PRAVEEN CRITICAL BENEFIT

	    
	    /**
		 * @param pwdValidYN the pwdValidYN to set
		 */
		public void setPwdValidYN(String pwdValidYN) {
			this.PwdValidYN = pwdValidYN;
		}

		/**
		 * @return the pwdValidYN
		 */
		public String getPwdValidYN() {
			return PwdValidYN;
		}

		/**
		 * @param strPswdExpiryYN the strPswdExpiryYN to set
		 */
		public void setPswdExpiryYN(String PswdExpiryYN) {
			this.PswdExpiryYN = PswdExpiryYN;
		}

		/**
		 * @return the strPswdExpiryYN
		 */
		public String getPswdExpiryYN() {
			return PswdExpiryYN;
		}
		//End changes for Password Policy CR KOC 1235

	    /** Retrieve the FirstLoginYN
		 * @return the strFirstLoginYN
		 */
		public String getStrTemplateName() {
			return tempStrTemplate;
		}//end of getFirstLoginYN()

		/** Sets the FirstLoginYN
		 * @param strFirstLoginYN the strFirstLoginYN to set
		 */
		public void setStrTemplateName(String tempStrTemplate) {
			this.tempStrTemplate = tempStrTemplate;
		}//sets the setFirstLoginYN(String strFirstLoginYN)

	    
	    /** Retrieve the policy grop seqSeqID
		 * @return the lpolicy grop seqSeqID
		 */
		public Long getTempPolaciGrpSeqID() {
			return teppolicygrpseqid;
		}//end of getContactSeqID()
		
		/** Sets the policy grop seqSeqID
		 * @param teppolicygrpseqid the teppolicygrpseqid to set
		 */
		public void setTempPolaciGrpSeqID(Long teppolicygrpseqid) {
			this.teppolicygrpseqid = teppolicygrpseqid;
		}//end of setTempPolaciGrpSeqID(Long lngContactSeqID)
	    
	    /** Retrieve the ContactSeqID
		 * @return the lngContactSeqID
		 */
		public Long getMemSeqID() {
			return lngMemSeqID;
		}//end of getContactSeqID()
		
		/** Sets the ContactSeqID
		 * @param lngContactSeqID the lngContactSeqID to set
		 */
		public void setMemSeqID(Long lngMemSeqID) {
			this.lngMemSeqID = lngMemSeqID;
		}//end of setContactSeqID(Long lngContactSeqID)
	    
	    /** Retrieve the ContactSeqID
		 * @return the lngContactSeqID
		 */
		public Long getContactSeqID() {
			return lngContactSeqID;
		}//end of getContactSeqID()

		/** Sets the ContactSeqID
		 * @param lngContactSeqID the lngContactSeqID to set
		 */
		public void setContactSeqID(Long lngContactSeqID) {
			this.lngContactSeqID = lngContactSeqID;
		}//end of setContactSeqID(Long lngContactSeqID)

		/** Retrieve the FirstLoginYN
		 * @return the strFirstLoginYN
		 */
		public String getFirstLoginYN() {
			return strFirstLoginYN;
		}//end of getFirstLoginYN()

		/** Sets the FirstLoginYN
		 * @param strFirstLoginYN the strFirstLoginYN to set
		 */
		public void setFirstLoginYN(String strFirstLoginYN) {
			this.strFirstLoginYN = strFirstLoginYN;
		}//sets the setFirstLoginYN(String strFirstLoginYN)

		/** Retrieve the OnlineRatingTypeID
		 * @return the strOnlineRatingTypeID
		 */
		public String getOnlineRatingTypeID() {
			return strOnlineRatingTypeID;
		}//end of getOnlineRatingTypeID()

		/** Sets the OnlineRatingTypeID
		 * @param strOnlineRatingTypeID the strOnlineRatingTypeID to set
		 */
		public void setOnlineRatingTypeID(String strOnlineRatingTypeID) {
			this.strOnlineRatingTypeID = strOnlineRatingTypeID;
		}//end of setOnlineRatingTypeID(String strOnlineRatingTypeID)

		/** Retrieve the Online Assistance TypeID
		 * @return Returns the strOnlineAssTypeID.
		 */
		public String getOnlineAssTypeID() {
			return strOnlineAssTypeID;
		}//end of getOnlineAssTypeID()

		/** Sets the Online Assistance TypeID
		 * @param strOnlineAssTypeID The strOnlineAssTypeID to set.
		 */
		public void setOnlineAssTypeID(String strOnlineAssTypeID) {
			this.strOnlineAssTypeID = strOnlineAssTypeID;
		}//end of setOnlineAssTypeID(String strOnlineAssTypeID)

		/** Retrieve the CustomerCode
		 * @return Returns the strCustomerCode.
		 */
		public String getCustomerCode() {
			return strCustomerCode;
		}//end of getCustomerCode()

		/** Sets the CustomerCode
		 * @param strCustomerCode The strCustomerCode to set.
		 */
		public void setCustomerCode(String strCustomerCode) {
			this.strCustomerCode = strCustomerCode;
		}//end of setCustomerCode(String strCustomerCode)
	    
	    /** Retrieve the TemplateName
		 * @return Returns the strTemplateName.
		 */
		public String getTemplateName() {
			return strTemplateName;
		}//end of getTemplateName()

		/** Sets the TemplateName
		 * @param strTemplateName The strTemplateName to set.
		 */
		public void setTemplateName(String strTemplateName) {
			this.strTemplateName = strTemplateName;
		}//end of setTemplateName(String strTemplateName)

		/** Retrieve the IntAccessTypeID
		 * @return Returns the strIntAccessTypeID.
		 */
		public String getIntAccessTypeID() {
			return strIntAccessTypeID;
		}//end of getIntAccessTypeID()

		/** Sets the IntAccessTypeID
		 * @param strIntAccessTypeID The strIntAccessTypeID to set.
		 */
		public void setIntAccessTypeID(String strIntAccessTypeID) {
			this.strIntAccessTypeID = strIntAccessTypeID;
		}//end of setIntAccessTypeID(String strIntAccessTypeID)

		/** Retrieve the attribute based on the reportID passed
		 * @return Returns the lngPolicySeqID.
		 */
	    public String getReportDisplayFlag(String strReportID) {
			if(strReportID.equals("EmpCredential")){
				return strEmployeeCredentialYN;
			}//end of if(strReportID.equals("EmpCredential"))
			else if(strReportID.equals("ClmRegd")){
				return strClmRegdYN;
			}//end of else if(strReportID.equals("ClmRegd"))
			else if(strReportID.equals("BiilsPend")){
				return strBiilsPendYN;
			}//end of else if(strReportID.equals("BiilsPend"))
			else if(strReportID.equals("ListEmpDepPeriod")){
				return strListEmpDepPeriodYN;
			}//end of else if(strReportID.equals("ListEmpDepPeriod"))
			else if(strReportID.equals("ListEmpDepTill")){
				return strListEmpDepTillYN;
			}//end of else if(strReportID.equals("ListEmpDepTill"))
			else if(strReportID.equals("OnlinePreAuthRpt")){
				return strOnlinePreAuthRptYN;
			}//end of else if(strReportID.equals("OnlinePreAuthRpt"))
			else if(strReportID.equals("ClmRegSummary")){
				return strClmRegSummaryYN;
			}//end of else if(strReportID.equals("ClmRegSummary"))
			else if(strReportID.equals("ClmRegDetail")){
				return strClmRegDetailYN;
			}//end of else if(strReportID.equals("ClmRegDetail"))
			//KOC 1339 for mail
			
			else if(strReportID.equals("ClaimsIntimations")){
				return strClmIntimationYN;
			}//end of else if(strReportID.equals("ClaimsIntimations"))
			
			//KOC 1339 for mail
			//KOC 1353 for payment report
			else if(strReportID.equals("INSPaymentReport")){
				return strINSPaymentReportYN;
			}//end of else if(strReportID.equals("INSPaymentReport"))
			//KOC 1353 for payment report
			else 
				return "";
		}//end of getReportDisplayFlag(String strReportID)
	    
	    /** Retrieve the PolicySeqID
		 * @return Returns the lngPolicySeqID.
		 */
		public Long getPolicySeqID() {
			return lngPolicySeqID;
		}//end of getPolicySeqID()

		/** Sets the PolicySeqID
		 * @param lngPolicySeqID The lngPolicySeqID to set.
		 */
		public void setPolicySeqID(Long lngPolicySeqID) {
			this.lngPolicySeqID = lngPolicySeqID;
		}//end of setPolicySeqID(Long lngPolicySeqID)

		/** Retrieve the PolicyGrpSeqID
		 * @return Returns the lngPolicyGrpSeqID.
		 */
		public Long getPolicyGrpSeqID() {
			return lngPolicyGrpSeqID;
		}//end of getPolicyGrpSeqID()

		/** Sets the PolicyGrpSeqID
		 * @param lngPolicyGrpSeqID The lngPolicyGrpSeqID to set.
		 */
		public void setPolicyGrpSeqID(Long lngPolicyGrpSeqID) {
			this.lngPolicyGrpSeqID = lngPolicyGrpSeqID;
		}//end of setPolicyGrpSeqID(Long lngPolicyGrpSeqID)

		/** Retrieve the TPAEnrolNbr
		 * @return Returns the strTPAEnrolNbr.
		 */
		public String getTPAEnrolNbr() {
			return strTPAEnrolNbr;
		}//end of getTPAEnrolNbr()

		/** Sets the TPAEnrolNbr
		 * @param strTPAEnrolNbr The strTPAEnrolNbr to set.
		 */
		public void setTPAEnrolNbr(String strTPAEnrolNbr) {
			this.strTPAEnrolNbr = strTPAEnrolNbr;
		}//end of setTPAEnrolNbr(String strTPAEnrolNbr)

		

	    
	    
	    /**
	     * Retrieve Login Type Identifier
	     * @return  strLoginType String
	     */
	    public String getLoginType() {
	        return strLoginType;
	    }//end of getLoginType()

	    /**
	     * Sets the Login Type Identifier
	     * @param  strLoginType String
	     */
	    public void setLoginType(String strLoginType) {
	        this.strLoginType = strLoginType;
	    }//end of setLoginType(String strLoginType)

	    /**
	     * Retrieve the Login Date
	     * @return  strLoginDate String
	     */
	    public String getLoginDate() {
	        return strLoginDate;
	    }//end of getLoginDate()

	    /**
	     * Sets the Login Date
	     * @param  strLoginDate String
	     */
	    public void setLoginDate(String strLoginDate) {
	        this.strLoginDate = strLoginDate;
	    }//end of setLoginDate(String strLoginDate)

	    /**
	     * Sets the user sequence id
	     * @param lUserSeqId Long user sequence id
	     */
	    public void setUSER_SEQ_ID(Long lUserSeqId)
	    {
	        this.lUserSeqId = lUserSeqId;
	    }//end of setUSER_SEQ_ID(String strUserSeqId)

	    /**
	     * Retrieve the user sequence id
	     * @return lUserSeqId Long user sequence id
	     */
	    public Long getUSER_SEQ_ID()
	    {
	        return lUserSeqId ;
	    }//end of getUSER_SEQ_ID()

	    /**
	     * Sets the SecurityProfile object
	     * @param securityProfileObj SecurityProfile the security profile object
	     */
	    public void setSecurityProfile(SecurityProfile securityProfileObj)
	    {
	        this.securityProfileObj = securityProfileObj;
	    }//end of setSecurityProfile(SecurityProfile securityProfileObj)

	    /**
	     * Retreive the SecurityProfile object
	     * @return securityProfileObj SecurityProfile the security profile object
	     */
	    public SecurityProfile getSecurityProfile()
	    {
	        return securityProfileObj;
	    }//end of getSecurityProfile()

	    /**
	     * Retrieve the ArrayList of Groups for which user belongs
	     * @return  alGroupList ArrayList
	     */
	    public ArrayList getGroupList() {
	        return alGroupList;
	    }//end of getGroupList()

	    /**
	     * Sets the ArrayList of Groups for which user belongs
	     * @param  alGroupList ArrayList
	     */
	    public void setGroupList(ArrayList alGroupList) {
	        this.alGroupList = alGroupList;
	    }//end of setGroupVO(ArrayList alGroupList)

	    /**
	     * Retrieve the Branch ID
	     * @return  lngBranchID Long
	     */
	    public Long getBranchID() {
	        return lngBranchID;
	    }//end of getBranchID()

	    /**
	     * Sets the the Branch ID
	     * @param  lngBranchID Long
	     */
	    public void setBranchID(Long lngBranchID) {
	        this.lngBranchID = lngBranchID;
	    }//end of setBranchID(Long lngBranchID)

	    /**
	     * Retrieve the Branch Name
	     * @return  strBranchName String
	     */
	    public String getBranchName() {
	        return strBranchName;
	    }//end of getBranchName()

	    /**
	     * Sets the Branch Name
	     * @param  strBranchName String
	     */
	    public void setBranchName(String strBranchName) {
	        this.strBranchName = strBranchName;
	    }//end of setBranchName(String strBranchName)

	    /**
	     * Retrieve the Contact Type ID
	     * @return  lngContactTypeID Long
	     */
	    public Long getContactTypeID() {
	        return lngContactTypeID;
	    }//end of getContactTypeID()

	    /**
	     * Sets the the Contact Type ID
	     * @param  lngContactTypeID Long
	     */
	    public void setContactTypeID(Long lngContactTypeID) {
	        this.lngContactTypeID = lngContactTypeID;
	    }//end of setContactTypeID(Long lngContactTypeID)

	    /**
	     * Retrieve the Role Sequence Id
	     * @return  lngRoleSeqId Long
	     */
	    public Long getRoleSeqId() {
	        return lngRoleSeqId;
	    }//end of getRoleSeqId()

	    /**
	     * Sets the Role Sequence Id
	     * @param  lngRoleSeqId Long
	     */
	    public void setRoleSeqId(Long lngRoleSeqId) {
	        this.lngRoleSeqId = lngRoleSeqId;
	    }//end of setRoleSeqId(Long lngRoleSeqId)

	    /**
	     * Retrieve the status of the User
	     * @return  strActiveYN String
	     */
	    public String getActiveYN() {
	        return strActiveYN;
	    }//end of getActiveYN()

	    /**
	     * Sets the status of the User
	     * @param  strActiveYN String
	     */
	    public void setActiveYN(String strActiveYN) {
	        this.strActiveYN = strActiveYN;
	    }//end of setActiveYN(String strActiveYN)

	    /**
	     * Retrieve the EMAIL ID
	     * @return  strEMAIL_ID String
	     */
	    public String getEMAIL_ID() {
	        return strEMAIL_ID;
	    }//end of getEMAIL_ID()

	    /**
	     * Sets the  the EMAIL ID
	     * @param  strEMAIL_ID String
	     */
	    public void setEMAIL_ID(String strEMAIL_ID) {
	        this.strEMAIL_ID = strEMAIL_ID;
	    }//end of setMAIL_ID(String strEMAIL_ID)

	    /**
	     * Retrieve the Mobile Number
	     * @return  strMobileNo String
	     */
	    public String getMobileNo() {
	        return strMobileNo;
	    }//end of getMobileNo()

	    /**
	     * Sets the Mobile Number
	     * @param  strMobileNo String
	     */
	    public void setMobileNo(String strMobileNo) {
	        this.strMobileNo = strMobileNo;
	    }//end of setMobileNo(String strMobileNo)

	    /**
	     * Retrieve the Role Name
	     * @return  strRoleName String
	     */
	    public String getRoleName() {
	        return strRoleName;
	    }//end of getRoleName()

	    /**
	     * Sets the Role Name
	     * @param  strRoleName String
	     */
	    public void setRoleName(String strRoleName) {
	        this.strRoleName = strRoleName;
	    }//end of setRoleName(String strRoleName)

	    /**
	     * Retrieve User Name
	     * @return  strUserName String
	     */
	    public String getUserName() {
	        return strUserName;
	    }//end of getUserName()

	    /**
	     * Sets User Name
	     * @param  strUserName String
	     */
	    public void setUserName(String strUserName) {
	        this.strUserName = strUserName;
	    }//end of setUserName(String strUserName)

	    /**
	     * Retrieve the User Type Id
	     * @return  strUserTypeId String
	     */
	    public String getUserTypeId() {
	        return strUserTypeId;
	    }//end of getUserTypeId()

	    /**
	     * Sets the User Type Id
	     * @param  strUserTypeId String
	     */
	    public void setUserTypeId(String strUserTypeId) {
	        this.strUserTypeId = strUserTypeId;
	    }//end of setUserTypeId(String strUserTypeId)

	    /**
	     * Retrieve the HashMap of WorkFlow Events of the User
	     * @return  hmWorkFlow HashMap
	     */
	    public HashMap getWorkFlowMap() {
	        return hmWorkFlow;
	    }//end of getWorkFlowMap()

	    /**
	     * Sets the HashMap of WorkFlow Events of the User
	     * @param  hmWorkFlow HashMap
	     */
	    public void setWorkFlowMap(HashMap hmWorkFlow) {
	        this.hmWorkFlow = hmWorkFlow;
	    }//end of setWorkFlowMap(HashMap hmWorkFlow)

	    
	    //added for koc 1349
	    public String getRandomNo() {
			return strRandomNo;
		}

		/**
		 * @param strPswdExpiryYN the strPswdExpiryYN to set
		 */
		public void setRandomNo(String strRandomNo) {
			this.strRandomNo = strRandomNo;
		}
		//added for koc 1349
		public String getWellnessAccessTypeID() {
			return strWellnessAssTypeID;
		}//end of getOnlineAssTypeID()

		/** Sets the Online Assistance TypeID
		 * @param strOnlineAssTypeID The strOnlineAssTypeID to set.
		 */
		public void setWellnessAccessTypeID(String strWellnessAssTypeID) {
			this.strWellnessAssTypeID = strWellnessAssTypeID;
		}//end of setOnlineAssTypeID(String strOnlineAssTypeID)
		//end added for koc 1349

		public String getCurrentStatus() {
			return currentStatus;
		}

		public void setCurrentStatus(String currentStatus) {
			this.currentStatus = currentStatus;
		}

		/**
	     * This method checks whether the user has got previlege for the specific flow/operation
	     * The method checks on the ACL's in the SecurityProfileXML object (access control list's) for the
	     * specified previlege and returns true/false accordingly
	     * @param strPath String which contains the path information
	     * @return boolean true/false based on the check on ACL's
	     * @exception throws TTKException
	     */
/*	    public boolean hasPermission(String strPath) throws TTKException
	    {
//	        boolean bAuthorized = false;
	        List permissions = (List)this.getSecurityProfile().getUserProfileXML().selectNodes("/SecurityProfile/Link[@name='"+getSecurityProfile().getActiveLink()+"']/SubLink[@name='"+getSecurityProfile().getActiveSubLink()+"']/Tab[@name='"+getSecurityProfile().getActiveTab()+"']/ACL/permission[@name='"+strPath+"'] ");

	        if(permissions != null)
	        {
	            if(permissions.size() > 0)
	            {
	                return true;
	            }//end of if(permissions.size() > 0)
	            else
	            {
	                return false;
	            }//end of else
	        }//end if()
	        else
	        {
	            return false;
	        }//end of else
	    }*/

}

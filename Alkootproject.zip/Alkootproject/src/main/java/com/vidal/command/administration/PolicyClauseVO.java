package com.vidal.command.administration;

import java.util.ArrayList;

//import org.apache.struts.upload.FormFile;

import com.vidal.command.base.BaseVO;



public class PolicyClauseVO extends BaseVO{
	
	private Long lngProdPolicySeqID=null;   //PROD_POLICY_SEQ_ID
	private Long lngClauseSeqID = null;     //CLAUSE_SEQ_ID
	private String strClauseNbr = "";       //CLAUSE_NUMBER
	private String strClauseDesc = "";      //CLAUSE_DESCRIPTION
	private String strSelectedYN = "";      //SELECTED_YN
	private String strClauseYN = "";        //CLAUSE_YN
	private String strActiveYN = "";        //ACTIVE_YN
	private String strClauseImageName="ICDIcon";
	private String strClauseImageTitle="Associate Disease";
		
	//added as per Shortfall cr
	private String strClauseSubType="";
	private String ClauseFor="";
	private String strClauseSubTypeDesc="";
	private String ClauseForDesc="";
	private String strItemList ="";
	private String strHospNotWarranted="";
	private String strDenialReasonGroupList="";
	private String strDenialReasonList = "";
	private String strDenialClauses = "";
	private String strReasonDesc ="";
	private Long lngReasonId = null;  
	private String strClausesAvailable ="";
	private Long lngReasonCount =null;
	private String strGroupDesc ="";
	private String strReasonUpdateYN ="";
	private String strAddClauseRestrictYN ="";
	private String strClauseNbrPre = ""; 
	private String strClauseDescPre = ""; 
	private String rejectiongroupseqId = ""; 
	private String rejectiongroupName = ""; 
	private String rejectionReasonSeqId = "";
	private String rejectionReasonName = "";
	private String clauseSeqId = "";
	private String rejectiongroup = "";
	private String rejectionReason = "";
	private String logStartDate = "";
	private String logEndDate = "";
	//private	FormFile file = null;
	private String rejectionReasonId = "";
	private ArrayList alClause = null;
	private Long insuranceSeqID= null;
	private Long productSeqID = null;
	private Long productPolicySeqID = null;
	private String addedName = "";
	private String dateAdded = "";
	private String flag = "";
	private String status = "";
	
	/** Retrieve the ClauseDescPrePre
	 * @return Returns the strClauseDescPrePre.
	 */
	public String getClauseDescPre() {
		return strClauseDescPre;
	}
	/** Sets the ClauseDescPrePre
	 * @param strClauseDescPrePre The strClauseDescPrePre to set.
	 */
	public void setClauseDescPre(String strClauseDescPre) {
		this.strClauseDescPre = strClauseDescPre;
	}
	/** Retrieve the ClauseNbrPr
	 * @return Returns the strClauseNbrPre.
	 */
	public String getClauseNbrPre() {
		return strClauseNbrPre;
	}
	/** Sets the ClauseNbrPr
	 * @param strClauseNbrPre The strClauseNbrPre to set.
	 */
	public void setClauseNbrPre(String strClauseNbrPre) {
		this.strClauseNbrPre = strClauseNbrPre;
	}
	/** Retrieve the AddClauseRestrictYN
	 * @return Returns the strAddClauseRestrictYN.
	 */
	public String getAddClauseRestrictYN() {
		return strAddClauseRestrictYN;
	}
	/** Sets the AddClauseRestrictYN
	 * @param strAddClauseRestrictYN The strAddClauseRestrictYN to set.
	 */
	public void setAddClauseRestrictYN(String strAddClauseRestrictYN) {
		this.strAddClauseRestrictYN = strAddClauseRestrictYN;
	}
	/** Retrieve the ReasonUpdateYN
	 * @return Returns the strReasonUpdateYN.
	 */
	public String getReasonUpdateYN() {
		return strReasonUpdateYN;
	}
	/** Sets the ReasonUpdateYN
	 * @param strReasonUpdateYN The strReasonUpdateYN to set.
	 */
	public void setReasonUpdateYN(String strReasonUpdateYN) {
		this.strReasonUpdateYN = strReasonUpdateYN;
	}
	/** Retrieve the GroupDesc
	 * @return Returns the strGroupDesc.
	 */
	public String getGroupDesc() {
		return strGroupDesc;
	}
	/** Sets the GroupDesc
	 * @param strGroupDesc The strGroupDesc to set.
	 */
	public void setGroupDesc(String strGroupDesc) {
		this.strGroupDesc = strGroupDesc;
	}
	/** Retrieve the ReasonCount
	 * @return Returns the lngReasonCount.
	 */
	public Long getReasonCount() {
		return lngReasonCount;
	}
	/** Sets the ReasonCount
	 * @param lngReasonCount The lngReasonCount to set.
	 */
	public void setReasonCount(Long lngReasonCount) {
		this.lngReasonCount = lngReasonCount;
	}
	/** Retrieve the ClausesAvailable
	 * @return Returns the strClausesAvailable.
	 */
	public String getClausesAvailable() {
		return strClausesAvailable;
	}
	/** Sets the ClausesAvailable
	 * @param strClausesAvailable The strClausesAvailable to set.
	 */
	public void setClausesAvailable(String strClausesAvailable) {
		this.strClausesAvailable = strClausesAvailable;
	}
	/** Retrieve the ReasonId
	 * @return Returns the lngReasonId.
	 */
	public Long getReasonId() {
		return lngReasonId;
	}//end of getClauseSeqID()
	
	/** Sets the ReasonId
	 * @param lngReasonId The lngReasonId to set.
	 */
	public void setReasonId(Long lngReasonId) {
		this.lngReasonId = lngReasonId;
	}//end of setClauseSeqID(Long lngClauseSeqID)

	public String getHospNotWarranted() {
		return strHospNotWarranted;
	}

	public void setHospNotWarranted(String strHospNotWarranted) {
		this.strHospNotWarranted = strHospNotWarranted;
	}

	/**
	 * @return the ReasonDesc
	 */
	public String getReasonDesc() {
		return strReasonDesc;
	}
	
	/**
	 * @param ReasonDesc the ReasonDesc to set
	 */
	public void setReasonDesc(String strReasonDesc) {
		this.strReasonDesc = strReasonDesc;
	}

	/**
	 * @return the DenialClauses
	 */
	public String getDenialClauses() {
		return strDenialClauses;
	}
	
	/**
	 * @param DenialClauses the DenialClauses to set
	 */
	public void setDenialClauses(String strDenialClauses) {
		this.strDenialClauses = strDenialClauses;
	}

	/**
	 * @return the DenialReasonList
	 */
	public String getDenialReasonList() {
		return strDenialReasonList;
	}
	
	/**
	 * @param DenialReasonList the DenialReasonList to set
	 */
	public void setDenialReasonList(String strDenialReasonList) {
		this.strDenialReasonList = strDenialReasonList;
	}

	/**
	 * @return the DenialReasonGroupList
	 */
	public String getDenialReasonGroupList() {
		return strDenialReasonGroupList;
	}
	
	/**
	 * @param DenialReasonGroupList the DenialReasonGroupList to set
	 */
	public void setDenialReasonGroupList(String strDenialReasonGroupList) {
		this.strDenialReasonGroupList = strDenialReasonGroupList;
	}

	/**
	 * @return the ItemList
	 */
	public String getItemList() {
		return strItemList;
	}
	
	/**
	 * @param ItemList the ItemList to set
	 */
	public void setItemList(String strItemList) {
		this.strItemList = strItemList;
	}
	
	/**
	 * @param clauseForDesc the clauseForDesc to set
	 */
	public void setClauseForDesc(String clauseForDesc) {
		this.ClauseForDesc = clauseForDesc;
	}

	/**
	 * @return the clauseForDesc
	 */
	public String getClauseForDesc() {
		return ClauseForDesc;
	}

	/**
	 * @param clauseSubTypeDesc the clauseSubTypeDesc to set
	 */
	public void setClauseSubTypeDesc(String clauseSubTypeDesc) {
		this.strClauseSubTypeDesc = clauseSubTypeDesc;
	}

	/**
	 * @return the clauseSubTypeDesc
	 */
	public String getClauseSubTypeDesc() {
		return strClauseSubTypeDesc;
	}

	/**
	 * @param clauseFor the clauseFor to set
	 */
	public void setClauseFor(String clauseFor) {
		this.ClauseFor = clauseFor;
	}

	/**
	 * @return the clauseFor
	 */
	public String getClauseFor() {
		return ClauseFor;
	}

	/**
	 * @param clauseSubType the clauseSubType to set
	 */
	public void setClauseSubType(String clauseSubType) {
		this.strClauseSubType = clauseSubType;
	}

	/**
	 * @return the clauseSubType
	 */
	public String getClauseSubType() {
		return strClauseSubType;
	}

	//added as per shortfall cr
	/** Retrieve the ActiveYN
	 * @return Returns the strActiveYN.
	 */
	public String getActiveYN() {
		return strActiveYN;
	}//end of getActiveYN()

	/** Sets the ActiveYN
	 * @param strActiveYN The strActiveYN to set.
	 */
	public void setActiveYN(String strActiveYN) {
		this.strActiveYN = strActiveYN;
	}//end of setActiveYN(String strActiveYN)

	/** Retrieve the ClauseYN
	 * @return Returns the strClauseYN.
	 */
	public String getClauseYN() {
		return strClauseYN;
	}//end of getClauseYN()

	/** Sets the ClauseYN
	 * @param strClauseYN The strClauseYN to set.
	 */
	public void setClauseYN(String strClauseYN) {
		this.strClauseYN = strClauseYN;
	}//end of setClauseYN(String strClauseYN)

	/** Retrieve the ClauseSeqID
	 * @return Returns the lngClauseSeqID.
	 */
	public Long getClauseSeqID() {
		return lngClauseSeqID;
	}//end of getClauseSeqID()
	
	/** Sets the ClauseSeqID
	 * @param lngClauseSeqID The lngClauseSeqID to set.
	 */
	public void setClauseSeqID(Long lngClauseSeqID) {
		this.lngClauseSeqID = lngClauseSeqID;
	}//end of setClauseSeqID(Long lngClauseSeqID)
	
	/** Retrieve the ProdPolicySeqID
	 * @return Returns the lngProdPolicySeqID.
	 */
	public Long getProdPolicySeqID() {
		return lngProdPolicySeqID;
	}//end of getProdPolicySeqID()
	
	/** Sets the ProdPolicySeqID
	 * @param lngProdPolicySeqID The lngProdPolicySeqID to set.
	 */
	public void setProdPolicySeqID(Long lngProdPolicySeqID) {
		this.lngProdPolicySeqID = lngProdPolicySeqID;
	}//end of setProdPolicySeqID(Long lngProdPolicySeqID)
	
	/** Retrieve the Clause Description
	 * @return Returns the strClauseDesc.
	 */
	public String getClauseDesc() {
		return strClauseDesc;
	}//end of getClauseDesc()
	
	/** Sets the Clause Description
	 * @param strClauseDesc The strClauseDesc to set.
	 */
	public void setClauseDesc(String strClauseDesc) {
		this.strClauseDesc = strClauseDesc;
	}//end of setClauseDesc(String strClauseDesc)
	
	/** Retrieve the ClauseNbr
	 * @return Returns the strClauseNbr.
	 */
	public String getClauseNbr() {
		return strClauseNbr;
	}//end of getClauseNbr()
	
	/** Sets the ClauseNbr
	 * @param strClauseNbr The strClauseNbr to set.
	 */
	public void setClauseNbr(String strClauseNbr) {
		this.strClauseNbr = strClauseNbr;
	}//end of setClauseNbr(String strClauseNbr)

	/** Retrieve the SelectedYN
	 * @return Returns the strSelectedYN.
	 */
	public String getSelectedYN() {
		return strSelectedYN;
	}//end of getSelectedYN()

	/** Sets the SelectedYN
	 * @param strSelectedYN The strSelectedYN to set.
	 */
	public void setSelectedYN(String strSelectedYN) {
		this.strSelectedYN = strSelectedYN;
	}//end of setSelectedYN(String strSelectedYN)

	/** Retrieve the ClauseImageName
	 * @return the strClauseImageName
	 */
	public String getClauseImageName() {
		return strClauseImageName;
	}//end of getClauseImageName()

	/** Sets the ClauseImageName
	 * @param strClauseImageName the strClauseImageName to set
	 */
	public void setClauseImageName(String strClauseImageName) {
		this.strClauseImageName = strClauseImageName;
	}//end of setClauseImageName(String strClauseImageName)

	/** Retrieve the ClauseImageTitle
	 * @return the strClauseImageTitle
	 */
	public String getClauseImageTitle() {
		return strClauseImageTitle;
	}//end of getClauseImageTitle()

	/** Sets the ClauseImageTitle
	 * @param strClauseImageTitle the strClauseImageTitle to set
	 */
	public void setClauseImageTitle(String strClauseImageTitle) {
		this.strClauseImageTitle = strClauseImageTitle;
	}//end of setClauseImageTitle(String strClauseImageTitle)
	/**
	 * @return the rejectiongroupseqId
	 */
	public String getRejectiongroupseqId() {
		return rejectiongroupseqId;
	}
	/**
	 * @param rejectiongroupseqId the rejectiongroupseqId to set
	 */
	public void setRejectiongroupseqId(String rejectiongroupseqId) {
		this.rejectiongroupseqId = rejectiongroupseqId;
	}
	/**
	 * @return the rejectiongroupName
	 */
	public String getRejectiongroupName() {
		return rejectiongroupName;
	}
	/**
	 * @param rejectiongroupName the rejectiongroupName to set
	 */
	public void setRejectiongroupName(String rejectiongroupName) {
		this.rejectiongroupName = rejectiongroupName;
	}
	/**
	 * @return the rejectionReasonSeqId
	 */
	public String getRejectionReasonSeqId() {
		return rejectionReasonSeqId;
	}
	/**
	 * @param rejectionReasonSeqId the rejectionReasonSeqId to set
	 */
	public void setRejectionReasonSeqId(String rejectionReasonSeqId) {
		this.rejectionReasonSeqId = rejectionReasonSeqId;
	}
	/**
	 * @return the rejectionReasonName
	 */
	public String getRejectionReasonName() {
		return rejectionReasonName;
	}
	/**
	 * @param rejectionReasonName the rejectionReasonName to set
	 */
	public void setRejectionReasonName(String rejectionReasonName) {
		this.rejectionReasonName = rejectionReasonName;
	}
	/**
	 * @return the clauseSeqId
	 */
	public String getClauseSeqId() {
		return clauseSeqId;
	}
	/**
	 * @param clauseSeqId the clauseSeqId to set
	 */
	public void setClauseSeqId(String clauseSeqId) {
		this.clauseSeqId = clauseSeqId;
	}
	/**
	 * @return the rejectiongroup
	 */
	public String getRejectiongroup() {
		return rejectiongroup;
	}
	/**
	 * @param rejectiongroup the rejectiongroup to set
	 */
	public void setRejectiongroup(String rejectiongroup) {
		this.rejectiongroup = rejectiongroup;
	}
	/**
	 * @return the rejectionReason
	 */
	public String getRejectionReason() {
		return rejectionReason;
	}
	/**
	 * @param rejectionReason the rejectionReason to set
	 */
	public void setRejectionReason(String rejectionReason) {
		this.rejectionReason = rejectionReason;
	}
	/**
	 * @return the logStartDate
	 */
	public String getLogStartDate() {
		return logStartDate;
	}
	/**
	 * @param logStartDate the logStartDate to set
	 */
	public void setLogStartDate(String logStartDate) {
		this.logStartDate = logStartDate;
	}
	/**
	 * @return the logEndDate
	 */
	public String getLogEndDate() {
		return logEndDate;
	}
	/**
	 * @param logEndDate the logEndDate to set
	 */
	public void setLogEndDate(String logEndDate) {
		this.logEndDate = logEndDate;
	}
	/**
	 * @return the file
	 */
	//public FormFile getFile() {
	//	return file;
	//}
	/**
	 * @param file the file to set
	 */
//	public void setFile(FormFile file) {
	//	this.file = file;
	//}
	/**
	 * @return the rejectionReasonId
	 */
	public String getRejectionReasonId() {
		return rejectionReasonId;
	}
	/**
	 * @param rejectionReasonId the rejectionReasonId to set
	 */
	public void setRejectionReasonId(String rejectionReasonId) {
		this.rejectionReasonId = rejectionReasonId;
	}
	/**
	 * @return the alClause
	 */
	public ArrayList getAlClause() {
		return alClause;
	}
	/**
	 * @param alClause the alClause to set
	 */
	public void setAlClause(ArrayList alClause) {
		this.alClause = alClause;
	}
	/**
	 * @return the insuranceSeqID
	 */
	public Long getInsuranceSeqID() {
		return insuranceSeqID;
	}
	/**
	 * @param insuranceSeqID the insuranceSeqID to set
	 */
	public void setInsuranceSeqID(Long insuranceSeqID) {
		this.insuranceSeqID = insuranceSeqID;
	}
	/**
	 * @return the productSeqID
	 */
	public Long getProductSeqID() {
		return productSeqID;
	}
	/**
	 * @param productSeqID the productSeqID to set
	 */
	public void setProductSeqID(Long productSeqID) {
		this.productSeqID = productSeqID;
	}
	/**
	 * @return the productPolicySeqID
	 */
	public Long getProductPolicySeqID() {
		return productPolicySeqID;
	}
	/**
	 * @param productPolicySeqID the productPolicySeqID to set
	 */
	public void setProductPolicySeqID(Long productPolicySeqID) {
		this.productPolicySeqID = productPolicySeqID;
	}
	/**
	 * @return the addedName
	 */
	public String getAddedName() {
		return addedName;
	}
	/**
	 * @param addedName the addedName to set
	 */
	public void setAddedName(String addedName) {
		this.addedName = addedName;
	}
	/**
	 * @return the dateAdded
	 */
	public String getDateAdded() {
		return dateAdded;
	}
	/**
	 * @param dateAdded the dateAdded to set
	 */
	public void setDateAdded(String dateAdded) {
		this.dateAdded = dateAdded;
	}
	/**
	 * @return the flag
	 */
	public String getFlag() {
		return flag;
	}
	/**
	 * @param flag the flag to set
	 */
	public void setFlag(String flag) {
		this.flag = flag;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
}//end of PolicyClauseVO

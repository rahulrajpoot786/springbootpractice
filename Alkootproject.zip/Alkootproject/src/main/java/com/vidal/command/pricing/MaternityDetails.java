package com.vidal.command.pricing;

import javax.xml.bind.annotation.XmlElement;

public class MaternityDetails {

	private MaternityData maternityData;
	
	public MaternityDetails() {
		
	}

	public MaternityDetails(MaternityData maternityData) {
		super();
		this.maternityData = maternityData;
	}

	@XmlElement
	public MaternityData getMaternityData() {
		return maternityData;
	}

	public void setMaternityData(MaternityData maternityData) {
		this.maternityData = maternityData;
	}
	
	
}

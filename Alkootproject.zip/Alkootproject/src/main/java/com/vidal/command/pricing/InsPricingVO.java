package com.vidal.command.pricing;



import java.io.InputStream;
import java.util.Date;
import java.util.List;


import org.springframework.web.multipart.MultipartFile;

import com.vidal.command.base.BaseVO;
import com.vidal.common.annotation.ValidWhen;
/**
 * @author gyanendra.srivastava
 *
 */
/**
 * @author gyanendra.srivastava
 *
 */
@ValidWhen.List({
	
/*	@ValidWhen(expression = "((clientCode != ''))", message = " 'Client Code' is required."),	
	@ValidWhen(expression = "((brokerCode != ''))", message = "'Direct / Broker / Tender' is required."),	
	@ValidWhen(expression = "((brokerCode == '')  or (brokerCode != 'BRO') or (brokername != ''))", message = " 'Broker name' is required."),
	@ValidWhen(expression = "((coverNewStartDate != ''))", message = "'Coverage start date' is required."),	
	@ValidWhen(expression = "((coverNewEndDate != ''))", message = "'Coverage end date' is required."),	
	@ValidWhen(expression = "((maxBenifitList != ''))", message = "'Maximum benefit limit' is required."),
	@ValidWhen(expression = "((outpatientBenefit != 'Y')  or (maxBenifitListop != ''))", message = "'Op limit' is required."),	
	@ValidWhen(expression = "((areaOfCoverList != ''))", message = "'Area of cover' is required."),	
	@ValidWhen(expression = "((inpatientBenefit != 'Y')  or (ipCopay != null))", message = "IP copay' is required."),
	@ValidWhen(expression = "((outpatientBenefit != 'Y')  or (opCopayList != ''))", message = "OP copay/deductible' is required."),
	
	@ValidWhen(expression = "((areaOfCoverVariations == '')  or (areaOfVariationFlag != 'Y') or (loadingAreaListop != '')  or (loadingAreaListopt != '') or (loadingAreaListdent != '') or (loadingAreaListmat != '') or (discountAreaListip != '') or  (discountAreaListop != '') or (discountAreaListopt != '') or (discountAreaListdent != '') or (discountAreaListmat != '') or (loadingAreaListip != ''))", message = "'Loading for area of cover variations ' is required."),
	
	@ValidWhen(expression = "((maternityYN != 'Y')  or (maternityPricingList != ''))", message = "'Maternity pricing' is required."),	
	@ValidWhen(expression = "((premiumOutputStructureList != null))", message = "'Premium output structure' is required."),	
	@ValidWhen(expression = "((premiumRefundApproach != ''))", message = "'Premium refund approach' is required."),	
	@ValidWhen(expression = "((hospitalExclusionsList == '')  or (discounthospitalExclusions != null))", message = "'Discount for hospital exclusions' is required."),
	@ValidWhen(expression = "((hospitalExclusionsList == '')  or (discounthospitalComment != ''))", message = "' Comments (discount for hospital exclusions)' is required."),
	@ValidWhen(expression = "((additionalHospitalCoverageList == '')  or (loadinghospitalCoverage != null))", message = "'Loading for additional hospital coverage' is required."),
	@ValidWhen(expression = "((additionalHospitalCoverageList == '')  or (loadinghospitalComment != ''))", message = "'Comments (loading for additional hospital coverage)' is required."),	
	
	@ValidWhen(expression = "((alAhlihospital != 'Y') or (opCopyalahlihosp != ''))", message = "'OP copay at Al Ahli' is required."),
	@ValidWhen(expression = "((alAhlihospital != 'Y') or (iPCopayAtAhliList != null))", message = "'IP copay at Ahli' is required."),
	
	
	@ValidWhen(expression = "((alAhlihospital != 'Y')  or (alAhlihospOPservices != 'N') or (opInvestnAlAhli != ''))", message = "'OP investigation copay At Ahli ' is required."),
	@ValidWhen(expression = "((alAhlihospital != 'Y')  or (alAhlihospOPservices != 'N') or (opPharmacyAlAhli != ''))", message = "'OP pharmacy copay at Al Ahli' is required."),
	@ValidWhen(expression = "((alAhlihospital != 'Y')  or (alAhlihospOPservices != 'N') or (opothersAlAhli != ''))", message = "'OP other services copay at Al Ahli ' is required."),
	@ValidWhen(expression = "((alAhlihospital != 'Y')  or (alAhlihospOPservices != 'N') or (opConsultAlAhli != ''))", message = "'OP consultation copay at Al Ahli' is required."),
	@ValidWhen(expression = "((alAhlihospital != 'Y')  or (alAhlihospOPservices != 'N') or (iPCopayAtAhliList != ''))", message = "'IP copay at Ahli' is required."),

	@ValidWhen(expression = "((residencyCountryList == '') or (residencyCountryIp != '')  or (residencyCountryOp != '') or (residencyCountryOtp != '') or (residencyCountryDent != '')  or (residencyCountryMat != ''))", message = "'Loading for residency country' is required."),
	@ValidWhen(expression = "((maternityYN != 'Y')  or (maternityLimitList != null))", message = "'Maternity limit' is required."),
	@ValidWhen(expression = "((maternityYN != 'Y')  or (maternityCopayList != null))", message = "'Maternity copay' is required."),
	@ValidWhen(expression = "((maternityYN != 'Y')  or (maternityCopayList != null))", message = "'Maternity copay' is required."),
	@ValidWhen(expression = "((maternityYN != 'Y') or  (maternityLimitList != 45) or (maternityLimitOth != ''))", message = "'Maternity limit (Others)' is required."),
	
	@ValidWhen(expression = "((opticalYN != 'Y')  or (opticalLimitList != ''))", message = "'Optical limit' is required."),
	@ValidWhen(expression = "((opticalYN != 'Y')  or (opticalCopayList != ''))", message = "'Optical copay' is required."),
	@ValidWhen(expression = "((opticalYN != 'Y')  or (opticalFrameLimitList != ''))", message = "'Frames limit' is required."),
	@ValidWhen(expression = "((opticalYN != 'Y') or  (opticalLimitList != '45') or (opticalLimitOth != ''))", message = "'Optical limit (Others)' is required."),
	
	@ValidWhen(expression = "((dentalYN != 'Y')  or (dentalLimitList != ''))", message = "'Dental limit' is required."),
	@ValidWhen(expression = "((dentalYN != 'Y')  or (dentalcopayList != ''))", message = "'Dental copay/deductible' is required."),
	@ValidWhen(expression = "((dentalYN != 'Y')  or (orthodonticsCopay != ''))", message = "'Orthodontics copay' is required."),
	@ValidWhen(expression = "((dentalYN != 'Y')   or (dentalLimitList != '45') or (dentalLimitOth != ''))", message = "'Dental limit (Others)' is required."),
	@ValidWhen(expression = "((renewalYN != 'Y')  or (previousPolicyNo != ''))", message = "'Past policy number' is required."),
	@ValidWhen(expression = "((renewalYN != 'Y')  or (underWritingYear != ''))", message = "'Underwriting year' is required."),
	@ValidWhen(expression = "((renewalYN != 'Y')  or (policycategory != ''))", message = "'Product name' is required."),
	
	@ValidWhen(expression = "((renewalYN != 'N')  or (productCategory != ''))", message = "'Plan name' is required."),
	
	*/
	
})


public class InsPricingVO extends BaseVO{

	
	private static final long serialVersionUID = 1L;
	    private Long finaldataSeqID=null;
	    private String country="";
	    private String currency="";
	    private String groupName="";
	    private String noofEmployees="";
	    private String additionalPremium="";
	    private String averageAge="";
	    private String employeeGender="";
	    private String familyCoverage="";
	    private String globalCoverge="";
	    private Long groupProfileSeqID= null;
	    private Long groupProfileSeqID_f= null;	    
 		private String grossclaulation="";
	    private String[] profileID=null;
	    private String[] profileValue=null;
	    private String[] profileGroup=null;
	    private String[] profilePercentage=null;
	    private Long incomeProfileSeqID= null;
	    private String profileID1=null;
	    private String profileValue1=null;
	    private String profileGroup1=null;
	    private String profilePercentage1=null;
	    private Long transProfileSeqID1= null;
	    private Long[] transProfileSeqID= null;
	    private String profileGroupValue1=null;
	    private String[] profileGroupValue=null;
	    private String nameOfInsurer="";
	    private String nameOfTPA="";
	    private String eligibility="";
	    private String takafulQuote="";
	    private String planName="";
	    private String prmiumtablevalue="";
	    private String maternitytablevalue="";
	    private String premiumvalue;
	    private String maternityvalue;
        private String noCoverdLives="";
        private String renewalYNadd="";
        private String pricingTempNo="";
        private String copyType="";
        private String totalClaimDate="";
        private String groupPricingNewFlag="";
        private String brokerflag="";
        private String copydataflag="";
        private String maximumBenefitsLimitsDesc="";
        
        private String censusSavaYn="";
        
        public String getRenewalYNadd() {
			return renewalYNadd;
		}

		public void setRenewalYNadd(String renewalYNadd) {
			this.renewalYNadd = renewalYNadd;
		}

		public String getPrevpolno() {
			return prevpolno;
		}

		public void setPrevpolno(String prevpolno) {
			this.prevpolno = prevpolno;
		}

		private String prevpolno="";

		private String benecoverFlagYN = "";
	    private String calCPMFlagYN = "";
	    //private ArrayList profileIncomeList = null;
	    
	    private String areaOfCover="";
	    private String newdataentry = "";
	    private String pricingNumberAlert = "";
	    
	    private String notifyerror="";   // added by govind
	    private String successMsg = "";  // added by govind
	    
	    //sw pricing start
	    private Date coverStartDate=null;
	    private Date coverEndDate=null;
	    
	   
	
	    private String clientCode="";	    
	    private String clientCodeDesc="";
	    
	    private String previousPolicyNo="";
	    private String pricingRefno="";    
	    private String totalCovedLives="";
	    private String totalLivesMaternity="";
	    private String trendFactor="";
	    private String comments = "";
	    private String finalTotalLives="";
	    
	    
	    private Long[] benf_typeseqid= null;
	    private String[] benfdesc=null;
	    private Long[] gndrtypeseqid= null;
	    private String[] gndrdesc=null;
	    private Long[] age_rngseqid= null;
	    private String[] age_range=null;
	    private String[] ovrprtflio_dstr= null;
	    private Long[] ovrprtflio_dstrUser= null;
	    private Long[] ovrprtflio_dstrUserNal= null;
	   
	    private Long[] natl_typeseqid= null;
	    private String[] natl_name=null;
	    private String[] totalCoverdLives=null;
	    private Long[] benf_lives_seq_id=null;
	    private String[] natCoverdLives=null;
	    private Long[] natl_seqid= null;
	    private String[] natovrprtflio_dstr= null;

	    
	    

	    private Long benf_lives_seq_id1 = null;
	    private Long benf_lives_seq_id1_f = null;
	    
	    private Long benf_typeseqid1= null;
	    private Long benf_typeseqid1_f= null;
	    private String benfdesc1 ="";
	    private String benfdesc1_f ="";
	    private Long gndrtypeseqid1= null;
	    private Long gndrtypeseqid1_f= null;
	    private String gndrdesc1="";
	    private String gndrdesc1_f="";
	    private Long age_rngseqid1= null;
	    private Long age_rngseqid1_f= null;
	    private String age_range1="";
	    private String age_range1_f="";
	    private String ovrprtflio_dstr1=null;
	    private String ovrprtflio_dstr2=null;
	    private String ovrprtflio_dstr2_f=null;
	    private String ovrprtflio_dstr1_f=null;
	    private Long natl_typeseqid1= null;
	    private String natl_name1="";
	    private String totalCoverdLives1="";
	    private String totalCoverdLives1_f="";
	    private String natCoverdLives1="";
	    
	    private Long grpProfSeqId = null;
	    private String groupRefNo="";
	    private String groupStatus="";
	    private String groupiniatedDate="";
	    private String groupProductName="";
	    private String groupSelectionNo="";
	    
	    
	 
		private Long natl_seqid1=null;
	    private String natovrprtflio_dstr1=null;
	    private String natovrprtflio_dstr2=null;
	    

	    
	    
	    private String renewalYN = "";
	    private String maternityYN = "";
	    private String  natcategorylist="";
	 	private String areaOfCoverList="";
	    private String networkList="";
	    private String  maxBenifitList="";
	    private String  dentalLimitList="";
	    private Long maternityLimitList= null;
	    
	    private String opticalLimitList="";
	    private String opCopayList="";
	    private String opCopayListDesc="";
	    private String dentalcopayListDesc="";
	    private String opticalCopayListDesc="";
	    private String opDeductableListDesc="";
	    
	    private String opDeductableList="";
	    private String  dentalcopayList="";
	    private String  opticalCopayList="";
	    private String  opticalFrameLimitList="";
	    private String  physiocoverage="";
	    private String vitDcoverage="";
	    private String vaccImmuCoverage="";
	    private String matComplicationCoverage="";
	    private String  psychiatrycoverage="";
	    private String deviatedNasalSeptum="";
	    private String obesityTreatment="";
		
	    private String dentalYN ="";
	    private String dentalLivesYN="";
	    private String opticalYN="";
	    private String opticalLivesYN="";
	    private String  maxBeneLimitOth = "";
	    private String  dentalLimitOth = "";
	    private String  opticalLimitOth = "";
	    private String maternityLimitOth = "";
	  
	    private String loadingFlagYN = "";
	    private String pricingDocs = "";
	    private String strPolicyNumberFlag = "";    
	    private String sumTotalLives = "";
	    private String sumTotalLivesFemale = "";
	    private String sumTotalLivesMale = "";
	    
	    private String sumTotalLivesFemaleUserPer = "";
	    private String sumTotalLivesMaleUserPer = "";
	    
	    private String sumTotalLivesMaternity = "";
	    private String sumTotalLivesDental = "";
	    private String sumTotalLivesOptical = "";
	    private String sumNationalityLives = "";
	    private String policyNumber = "";
	    private String clientName="";
	    private String completeSaveYN="";
	   
	    
	 /*   private FormFile sourceAttchments1; 
	    private FormFile sourceAttchments2; 
	    private FormFile sourceAttchments3; 
	    private FormFile sourceAttchments4; 
	    private FormFile sourceAttchments5; 
	    
	    private InputStream inputstreamdoc1 = null;
	    private InputStream inputstreamdoc2 = null;
	    private InputStream inputstreamdoc3 = null;
	    private InputStream inputstreamdoc4 = null;
	    private InputStream inputstreamdoc5 = null;
	    */
	    private String attachmentname1="";
	    private String attachmentname2="";
	    private String attachmentname3="";
	    private String attachmentname4="";
	    private String attachmentname5="";    
	  
		private String inpatientBenefit="";
	    private String outpatientBenefit="";
	    private String gastricBinding="";
	    private String healthScreen="";
	    private String chronicLimit="";
	    private String orthodonticsCopay="";
	    private String orthodonticsCopayDesc="";
	    private String opCopaypharmacy="";
	    private String opCopaypharmacyDesc="";
	    private String opInvestigation="";
	    private String opInvestigationDesc="";
	    private String opCopyconsultn="";
	    private String opCopyconsultnDesc="";
	    private String opCopyothers = "";
	    private String opCopyothersDesc = "";
	    private String  alAhlihospital="";
	    private String opCopyalahlihosp="";
	    private String opCopyalahlihospDesc="";
	    private String opPharmacyAlAhli="";
	    private String opPharmacyAlAhliDesc="";
	    private String  opConsultAlAhli="";
	    private String  opConsultAlAhliDesc="";
	    private String  opInvestnAlAhli="";
	    private String  opInvestnAlAhliDesc="";
	    private String opothersAlAhli = "";  
	    private String opothersAlAhliDesc = "";  
	    private String alAhlihospOPservices = "";

	    private String  chronicLimitOth="";
	    private String opdeductableserviceYN= "";
	    private String demographicflagYN= "";
	    private String alertmsgscreen1 = "";
	    private String pricingmodifyYN = "";

	 
	    private String policycategory = "";  
	    
	    private String productName="";
	   
	    private String inpAccomodation="";
	    private Long inpAccmdlimit=null;
	    private String inpAccmdCopay="";
	    private String inpAccmdDeductable="";
	    private double numberOfLives=0.0d;
	    private String completeSaveYNInSc2="";
	    private String riskPremiumDate="";

	    // new fild created 
	    
	    private MultipartFile file1;
	    private MultipartFile file2;
	    private MultipartFile file3;
	    private MultipartFile file4;
	    private MultipartFile file5;
	    private  MultipartFile excelFile;
	  /*  private List<MultipartFile> files = null;*/
	    
	    private MultipartFile[] files;
	    

		private String fileName="";
	    private String coverNewStartDate = "";
	    private String coverNewEndDate = "";
	    private String brokerCode = "";
	    private String brokername = "";
	    private String  maxBenifitListip="";
	    private String maxBenifitListop="";
	    
	    private String loadingAreaListip="";
	    private String loadingAreaListop="";
	    private String loadingAreaListopt="";
	    private String loadingAreaListdent="";
	    private String loadingAreaListmat="";
	    
	    private String discountAreaListip="";
	    private String discountAreaListop="";
	    private String discountAreaListopt="";
	    private String discountAreaListdent="";
	    private String discountAreaListmat="";
	    
	    private String networkListip="";
	    private String networkListop="";
	    private String networkListopt="";
	    private String networkListdent="";
	    private String networkListmat="";
	    private String  maxBeneLimitOthIp = "";
	    private String  maxBeneLimitOthOp = "";
		private String areaOfCoverVariations="";
		
		private String copyInputDataRadio = "";
		private String copyInputDataRadioCensus = "";
	    
		private String underWritingYear ="";
		
		private Long ipCopay = null;
		
		private Long iPCopayAtAhliList = null;
		   
		private String additionalHospitalCoverageList = "";
		private String residencyCountryList ="";
		private String maternityPricingList ="";
	    private Long premiumOutputStructureList =null; 
	    
	 
	    
	    private Long maternityCopayList = null;
	    
	    private String opCopyconsultnList ="";
	    private String trendFactorIp="";
	    private String trendFactorOp="";
	    private String trendFactorOpt="";
	    private String trendFactorDent="";
	    private String trendFactorMat="";
	    private String hospitalExclusionsList="";
	    private Long loadinghospitalCoverage =null;
	    private String loadinghospitalComment ="";
	    private Long discounthospitalExclusions =null;
	    private String discounthospitalComment ="";
	    
	    private String residencyCountryIp ="";
	    private String residencyCountryOp ="";
	    private String residencyCountryOtp ="";
	    private String residencyCountryDent ="";
	    private String residencyCountryMat ="";
		private String proRATALimitApplicable ="";
		
		
		private String ipCopayDesc="";
		private String ipCopayListDesc="";
		
		
		private String maternityLimitListDesc ="";
		private String iPCopayAtAhliListDesc ="";
        private String premiumOutputStructureListDesc =""; 

        
        private String loadingResiCntry ="";
        private String otherKeyComents ="";
        
        private String premiumPerMember ="";
        private String projectedLossRatio="";
        private String loadsChangesBenef="";
        private String discountChangBenef="";
        private String loadAntiSelection="";
        private String brokingCommission="";
        private String contingencyLoading="";
        private String overheadCost="";
        private String managementDiscount ="";
        private String profitMargin ="";
        private String grossPremiumMember=""; 
        
        private String grossPremiumMemberGroupLevel="";
        
        private String minMaternity=null;
        private String maxMaternity=null;
        
        private String groupRegSeqId ="";
        
        private String statusCheck="";
                                            
        
        private String productCategory="";
        
        private String srcDoc1Yn ="";
        private String srcDoc2Yn ="";
        private String srcDoc3Yn ="";
        private String srcDoc4Yn ="";
        private String srcDoc5Yn ="";
        
        
        
        
        private InputStream inputstreamdoc1 = null;
        private InputStream inputstreamdoc2 = null;
        private InputStream inputstreamdoc3 = null;
        private InputStream inputstreamdoc4 = null;
        private InputStream inputstreamdoc5 = null;
        
        private Long groupProfilePricingSeqid;
        private Long groupProfileSeqid;
        private String groupProfileRefNo="";
        private Long groupPricingSeqId[]=null;
        private Long lodingPricingVal[]=null;
        private Long discountPricingVal[]=null;
        private Long revisedPrimiumVal[]=null;
        private Long ldsSeqIdVal[]=null;
        private Long revisedPrimiumGroupVal;
        private Long targetPrimiumVal;
        private Long proposedVal;
        private String pricingList="";
        
        
        private String loding="";
        private String discount="";
        private String revisedPremiumPerMember="";
        private String ldsSeqId="";
        private String revisedPremiumPerMemberGroupAll="";
        private String targetVal="";
        private String proposedLoding="";
        
        
        private String serachPricingNo="";
        private String serachGroupId="";
        private String serachGroupName="";
        private String serachAlkootBranch="";
        
        
        private String policyDuration="";
        private String groupPolicyCoverStartDate="";
        private String groupPolicyCoverEndDate="";
        
        private String censusFileUploadName="";
        
        private String lastSaveDateGroupPricing="";
        
        private String renevalFlag="";
        private String totalClaimDes="";
        private String ultimateLossDes="";
        private String lossrationDes="";
        private String premiumPerMemDes="";
        
        private String areaOfVariationFlag="";
        
        private Integer fileCount;
        
        private String areaOfCoverDesc="";
        
        private String initiatedDate="";
        		
        private String exprienceDscDate="";
        
        
        
        
		public String getAreaOfCoverDesc() {
			return areaOfCoverDesc;
		}

		public void setAreaOfCoverDesc(String areaOfCoverDesc) {
			this.areaOfCoverDesc = areaOfCoverDesc;
		}

		public Integer getFileCount() {
			return fileCount;
		}

		public void setFileCount(Integer fileCount) {
			this.fileCount = fileCount;
		}

		public String getAreaOfVariationFlag() {
			return areaOfVariationFlag;
		}

		public void setAreaOfVariationFlag(String areaOfVariationFlag) {
			this.areaOfVariationFlag = areaOfVariationFlag;
		}

		public String getRenevalFlag() {
			return renevalFlag;
		}

		public void setRenevalFlag(String renevalFlag) {
			this.renevalFlag = renevalFlag;
		}

		public String getTargetVal() {
			return targetVal;
		}

		public void setTargetVal(String targetVal) {
			this.targetVal = targetVal;
		}

		public String getRevisedPremiumPerMemberGroupAll() {
			return revisedPremiumPerMemberGroupAll;
		}

		public void setRevisedPremiumPerMemberGroupAll(String revisedPremiumPerMemberGroupAll) {
			this.revisedPremiumPerMemberGroupAll = revisedPremiumPerMemberGroupAll;
		}

		public Long[] getLdsSeqIdVal() {
			return ldsSeqIdVal;
		}

		public void setLdsSeqIdVal(Long[] ldsSeqIdVal) {
			this.ldsSeqIdVal = ldsSeqIdVal;
		}

		public String getLdsSeqId() {
			return ldsSeqId;
		}

		public void setLdsSeqId(String ldsSeqId) {
			this.ldsSeqId = ldsSeqId;
		}

		public String getLoding() {
			return loding;
		}

		public void setLoding(String loding) {
			this.loding = loding;
		}

		public String getDiscount() {
			return discount;
		}

		public void setDiscount(String discount) {
			this.discount = discount;
		}

		public String getRevisedPremiumPerMember() {
			return revisedPremiumPerMember;
		}

		public void setRevisedPremiumPerMember(String revisedPremiumPerMember) {
			this.revisedPremiumPerMember = revisedPremiumPerMember;
		}

		public String getSerachPricingNo() {
			return serachPricingNo;
		}

		public void setSerachPricingNo(String serachPricingNo) {
			this.serachPricingNo = serachPricingNo;
		}

		public String getSerachGroupId() {
			return serachGroupId;
		}

		public void setSerachGroupId(String serachGroupId) {
			this.serachGroupId = serachGroupId;
		}

		public String getSerachGroupName() {
			return serachGroupName;
		}

		public void setSerachGroupName(String serachGroupName) {
			this.serachGroupName = serachGroupName;
		}

		public String getSerachAlkootBranch() {
			return serachAlkootBranch;
		}

		public void setSerachAlkootBranch(String serachAlkootBranch) {
			this.serachAlkootBranch = serachAlkootBranch;
		}

		public String getPricingList() {
			return pricingList;
		}

		public void setPricingList(String pricingList) {
			this.pricingList = pricingList;
		}

		public Long getGroupProfilePricingSeqid() {
			return groupProfilePricingSeqid;
		}

		public void setGroupProfilePricingSeqid(Long groupProfilePricingSeqid) {
			this.groupProfilePricingSeqid = groupProfilePricingSeqid;
		}

		public String getProductCategory() {
			return productCategory;
		}

		public void setProductCategory(String productCategory) {
			this.productCategory = productCategory;
		}

		public String getClientCodeDesc() {
			return clientCodeDesc;
		}

		public void setClientCodeDesc(String clientCodeDesc) {
			this.clientCodeDesc = clientCodeDesc;
		}

		public String getSumTotalLivesFemaleUserPer() {
			return sumTotalLivesFemaleUserPer;
		}

		public void setSumTotalLivesFemaleUserPer(String sumTotalLivesFemaleUserPer) {
			this.sumTotalLivesFemaleUserPer = sumTotalLivesFemaleUserPer;
		}

		public String getSumTotalLivesMaleUserPer() {
			return sumTotalLivesMaleUserPer;
		}

		public void setSumTotalLivesMaleUserPer(String sumTotalLivesMaleUserPer) {
			this.sumTotalLivesMaleUserPer = sumTotalLivesMaleUserPer;
		}

		public String getSumTotalLivesFemale() {
			return sumTotalLivesFemale;
		}

		public void setSumTotalLivesFemale(String sumTotalLivesFemale) {
			this.sumTotalLivesFemale = sumTotalLivesFemale;
		}

		public String getMinMaternity() {
			return minMaternity;
		}

		public void setMinMaternity(String minMaternity) {
			this.minMaternity = minMaternity;
		}

		public String getMaxMaternity() {
			return maxMaternity;
		}

		public void setMaxMaternity(String maxMaternity) {
			this.maxMaternity = maxMaternity;
		}

		public Long[] getOvrprtflio_dstrUserNal() {
			return ovrprtflio_dstrUserNal;
		}

		public void setOvrprtflio_dstrUserNal(Long[] ovrprtflio_dstrUserNal) {
			this.ovrprtflio_dstrUserNal = ovrprtflio_dstrUserNal;
		}

		public String getNatovrprtflio_dstr2() {
			return natovrprtflio_dstr2;
		}

		public void setNatovrprtflio_dstr2(String natovrprtflio_dstr2) {
			this.natovrprtflio_dstr2 = natovrprtflio_dstr2;
		}

		public String getOvrprtflio_dstr2_f() {
			return ovrprtflio_dstr2_f;
		}

		public void setOvrprtflio_dstr2_f(String ovrprtflio_dstr2_f) {
			this.ovrprtflio_dstr2_f = ovrprtflio_dstr2_f;
		}

		
		

		public Long[] getOvrprtflio_dstrUser() {
			return ovrprtflio_dstrUser;
		}

		public void setOvrprtflio_dstrUser(Long[] ovrprtflio_dstrUser) {
			this.ovrprtflio_dstrUser = ovrprtflio_dstrUser;
		}

		public String getOvrprtflio_dstr2() {
			return ovrprtflio_dstr2;
		}

		public void setOvrprtflio_dstr2(String ovrprtflio_dstr2) {
			this.ovrprtflio_dstr2 = ovrprtflio_dstr2;
		}

	

		/*public MultipartFile[] getFiles() {
			return files;
		}

		public void setFiles(MultipartFile[] files) {
			this.files = files;
		}
*/
		public String getGrossPremiumMemberGroupLevel() {
			return grossPremiumMemberGroupLevel;
		}

		public void setGrossPremiumMemberGroupLevel(String grossPremiumMemberGroupLevel) {
			this.grossPremiumMemberGroupLevel = grossPremiumMemberGroupLevel;
		}

		public String getLoadingResiCntry() {
			return loadingResiCntry;
		}

		public void setLoadingResiCntry(String loadingResiCntry) {
			this.loadingResiCntry = loadingResiCntry;
		}

		public String getOtherKeyComents() {
			return otherKeyComents;
		}

		public void setOtherKeyComents(String otherKeyComents) {
			this.otherKeyComents = otherKeyComents;
		}

		public String getPremiumPerMember() {
			return premiumPerMember;
		}

		public void setPremiumPerMember(String premiumPerMember) {
			this.premiumPerMember = premiumPerMember;
		}

		public String getProjectedLossRatio() {
			return projectedLossRatio;
		}

		public void setProjectedLossRatio(String projectedLossRatio) {
			this.projectedLossRatio = projectedLossRatio;
		}

		public String getLoadsChangesBenef() {
			return loadsChangesBenef;
		}

		public void setLoadsChangesBenef(String loadsChangesBenef) {
			this.loadsChangesBenef = loadsChangesBenef;
		}

		public String getDiscountChangBenef() {
			return discountChangBenef;
		}

		public void setDiscountChangBenef(String discountChangBenef) {
			this.discountChangBenef = discountChangBenef;
		}

		public String getLoadAntiSelection() {
			return loadAntiSelection;
		}

		public void setLoadAntiSelection(String loadAntiSelection) {
			this.loadAntiSelection = loadAntiSelection;
		}

		public String getBrokingCommission() {
			return brokingCommission;
		}

		public void setBrokingCommission(String brokingCommission) {
			this.brokingCommission = brokingCommission;
		}

		public String getContingencyLoading() {
			return contingencyLoading;
		}

		public void setContingencyLoading(String contingencyLoading) {
			this.contingencyLoading = contingencyLoading;
		}

		public String getOverheadCost() {
			return overheadCost;
		}

		public void setOverheadCost(String overheadCost) {
			this.overheadCost = overheadCost;
		}

		public String getManagementDiscount() {
			return managementDiscount;
		}

		public void setManagementDiscount(String managementDiscount) {
			this.managementDiscount = managementDiscount;
		}

		public String getProfitMargin() {
			return profitMargin;
		}

		public void setProfitMargin(String profitMargin) {
			this.profitMargin = profitMargin;
		}

	

		public String getGrossPremiumMember() {
			return grossPremiumMember;
		}

		public void setGrossPremiumMember(String grossPremiumMember) {
			this.grossPremiumMember = grossPremiumMember;
		}

		public String getProductName() {
			return productName;
		}

		public void setProductName(String productName) {
			this.productName = productName;
		}

	/*	public List<MultipartFile> getFiles() {
			return files;
		}

		public void setFiles(List<MultipartFile> files) {
			this.files = files;
		}*/

		public MultipartFile getExcelFile() {
			return excelFile;
		}

		public void setExcelFile(MultipartFile excelFile) {
			this.excelFile = excelFile;
		}

		private String orthodontiCscoverage = "";
	    private String premiumRefundApproach ="";
	  
	    
	    public String getPremiumRefundApproach() {
			return premiumRefundApproach;
		}

		public void setPremiumRefundApproach(String premiumRefundApproach) {
			this.premiumRefundApproach = premiumRefundApproach;
		}

		public String getOrthodontiCscoverage() {
			return orthodontiCscoverage;
		}

		public void setOrthodontiCscoverage(String orthodontiCscoverage) {
			this.orthodontiCscoverage = orthodontiCscoverage;
		}

		public MultipartFile getFile2() {
			return file2;
		}

		public void setFile2(MultipartFile file2) {
			this.file2 = file2;
		}

		public MultipartFile getFile3() {
			return file3;
		}

		public void setFile3(MultipartFile file3) {
			this.file3 = file3;
		}

		public MultipartFile getFile4() {
			return file4;
		}

		public void setFile4(MultipartFile file4) {
			this.file4 = file4;
		}

		public MultipartFile getFile5() {
			return file5;
		}

		public void setFile5(MultipartFile file5) {
			this.file5 = file5;
		}


		public String getProRATALimitApplicable() {
			return proRATALimitApplicable;
		}

		public void setProRATALimitApplicable(String proRATALimitApplicable) {
			this.proRATALimitApplicable = proRATALimitApplicable;
		}

		public String getResidencyCountryIp() {
			return residencyCountryIp;
		}

		public void setResidencyCountryIp(String residencyCountryIp) {
			this.residencyCountryIp = residencyCountryIp;
		}

		public String getResidencyCountryOp() {
			return residencyCountryOp;
		}

		public void setResidencyCountryOp(String residencyCountryOp) {
			this.residencyCountryOp = residencyCountryOp;
		}

		public String getResidencyCountryOtp() {
			return residencyCountryOtp;
		}

		public void setResidencyCountryOtp(String residencyCountryOtp) {
			this.residencyCountryOtp = residencyCountryOtp;
		}

		public String getResidencyCountryDent() {
			return residencyCountryDent;
		}

		public void setResidencyCountryDent(String residencyCountryDent) {
			this.residencyCountryDent = residencyCountryDent;
		}

		public String getResidencyCountryMat() {
			return residencyCountryMat;
		}

		public void setResidencyCountryMat(String residencyCountryMat) {
			this.residencyCountryMat = residencyCountryMat;
		}

		
		public Long getDiscounthospitalExclusions() {
			return discounthospitalExclusions;
		}

		public void setDiscounthospitalExclusions(Long discounthospitalExclusions) {
			this.discounthospitalExclusions = discounthospitalExclusions;
		}

		public String getDiscounthospitalComment() {
			return discounthospitalComment;
		}

		public void setDiscounthospitalComment(String discounthospitalComment) {
			this.discounthospitalComment = discounthospitalComment;
		}

		

		public Long getLoadinghospitalCoverage() {
			return loadinghospitalCoverage;
		}

		public void setLoadinghospitalCoverage(Long loadinghospitalCoverage) {
			this.loadinghospitalCoverage = loadinghospitalCoverage;
		}

		public String getLoadinghospitalComment() {
			return loadinghospitalComment;
		}

		public void setLoadinghospitalComment(String loadinghospitalComment) {
			this.loadinghospitalComment = loadinghospitalComment;
		}

		public String getHospitalExclusionsList() {
			return hospitalExclusionsList;
		}

		public void setHospitalExclusionsList(String hospitalExclusionsList) {
			this.hospitalExclusionsList = hospitalExclusionsList;
		}

		public String getTrendFactorIp() {
			return trendFactorIp;
		}

		public void setTrendFactorIp(String trendFactorIp) {
			this.trendFactorIp = trendFactorIp;
		}

		public String getTrendFactorOp() {
			return trendFactorOp;
		}

		public void setTrendFactorOp(String trendFactorOp) {
			this.trendFactorOp = trendFactorOp;
		}

		public String getTrendFactorOpt() {
			return trendFactorOpt;
		}

		public void setTrendFactorOpt(String trendFactorOpt) {
			this.trendFactorOpt = trendFactorOpt;
		}

		public String getTrendFactorDent() {
			return trendFactorDent;
		}

		public void setTrendFactorDent(String trendFactorDent) {
			this.trendFactorDent = trendFactorDent;
		}

		public String getTrendFactorMat() {
			return trendFactorMat;
		}

		public void setTrendFactorMat(String trendFactorMat) {
			this.trendFactorMat = trendFactorMat;
		}

		public String getOpCopyconsultnList() {
			return opCopyconsultnList;
		}

		public void setOpCopyconsultnList(String opCopyconsultnList) {
			this.opCopyconsultnList = opCopyconsultnList;
		}

	

	

		public Long getMaternityCopayList() {
			return maternityCopayList;
		}

		public void setMaternityCopayList(Long maternityCopayList) {
			this.maternityCopayList = maternityCopayList;
		}

		public Long getPremiumOutputStructureList() {
			return premiumOutputStructureList;
		}

		public void setPremiumOutputStructureList(Long premiumOutputStructureList) {
			this.premiumOutputStructureList = premiumOutputStructureList;
		}

		public String getMaternityPricingList() {
			return maternityPricingList;
		}

		public void setMaternityPricingList(String maternityPricingList) {
			this.maternityPricingList = maternityPricingList;
		}


		public String getResidencyCountryList() {
			return residencyCountryList;
		}

		public void setResidencyCountryList(String residencyCountryList) {
			this.residencyCountryList = residencyCountryList;
		}

		public String getAdditionalHospitalCoverageList() {
			return additionalHospitalCoverageList;
		}

		public void setAdditionalHospitalCoverageList(String additionalHospitalCoverageList) {
			this.additionalHospitalCoverageList = additionalHospitalCoverageList;
		}

		public Long getiPCopayAtAhliList() {
			return iPCopayAtAhliList;
		}

		public void setiPCopayAtAhliList(Long iPCopayAtAhliList) {
			this.iPCopayAtAhliList = iPCopayAtAhliList;
		}

		public Long getIpCopay() {
			return ipCopay;
		}

		public void setIpCopay(Long ipCopay) {
			this.ipCopay = ipCopay;
		}

		public String getUnderWritingYear() {
			return underWritingYear;
		}

		public void setUnderWritingYear(String underWritingYear) {
			this.underWritingYear = underWritingYear;
		}

		public String getCopyInputDataRadioCensus() {
			return copyInputDataRadioCensus;
		}

		public void setCopyInputDataRadioCensus(String copyInputDataRadioCensus) {
			this.copyInputDataRadioCensus = copyInputDataRadioCensus;
		}

		public String getCopyInputDataRadio() {
			return copyInputDataRadio;
		}

		public void setCopyInputDataRadio(String copyInputDataRadio) {
			this.copyInputDataRadio = copyInputDataRadio;
		}

		public String getAreaOfCoverVariations() {
			return areaOfCoverVariations;
		}

		public void setAreaOfCoverVariations(String areaOfCoverVariations) {
			this.areaOfCoverVariations = areaOfCoverVariations;
		}

		public String getMaxBeneLimitOthOp() {
			return maxBeneLimitOthOp;
		}

		public void setMaxBeneLimitOthOp(String maxBeneLimitOthOp) {
			this.maxBeneLimitOthOp = maxBeneLimitOthOp;
		}

		public String getMaxBeneLimitOthIp() {
			return maxBeneLimitOthIp;
		}

		public void setMaxBeneLimitOthIp(String maxBeneLimitOthIp) {
			this.maxBeneLimitOthIp = maxBeneLimitOthIp;
		}

	

		public String getNetworkListip() {
			return networkListip;
		}

		public void setNetworkListip(String networkListip) {
			this.networkListip = networkListip;
		}

		public String getNetworkListop() {
			return networkListop;
		}

		public void setNetworkListop(String networkListop) {
			this.networkListop = networkListop;
		}

		public String getNetworkListopt() {
			return networkListopt;
		}

		public void setNetworkListopt(String networkListopt) {
			this.networkListopt = networkListopt;
		}

		public String getNetworkListdent() {
			return networkListdent;
		}

		public void setNetworkListdent(String networkListdent) {
			this.networkListdent = networkListdent;
		}

		public String getNetworkListmat() {
			return networkListmat;
		}

		public void setNetworkListmat(String networkListmat) {
			this.networkListmat = networkListmat;
		}

		public String getDiscountAreaListip() {
			return discountAreaListip;
		}

		public void setDiscountAreaListip(String discountAreaListip) {
			this.discountAreaListip = discountAreaListip;
		}

		public String getDiscountAreaListop() {
			return discountAreaListop;
		}

		public void setDiscountAreaListop(String discountAreaListop) {
			this.discountAreaListop = discountAreaListop;
		}

		public String getDiscountAreaListopt() {
			return discountAreaListopt;
		}

		public void setDiscountAreaListopt(String discountAreaListopt) {
			this.discountAreaListopt = discountAreaListopt;
		}

		public String getDiscountAreaListdent() {
			return discountAreaListdent;
		}

		public void setDiscountAreaListdent(String discountAreaListdent) {
			this.discountAreaListdent = discountAreaListdent;
		}

		public String getDiscountAreaListmat() {
			return discountAreaListmat;
		}

		public void setDiscountAreaListmat(String discountAreaListmat) {
			this.discountAreaListmat = discountAreaListmat;
		}

		public String getLoadingAreaListip() {
			return loadingAreaListip;
		}

		public void setLoadingAreaListip(String loadingAreaListip) {
			this.loadingAreaListip = loadingAreaListip;
		}

		public String getLoadingAreaListop() {
			return loadingAreaListop;
		}

		public void setLoadingAreaListop(String loadingAreaListop) {
			this.loadingAreaListop = loadingAreaListop;
		}

		public String getLoadingAreaListopt() {
			return loadingAreaListopt;
		}

		public void setLoadingAreaListopt(String loadingAreaListopt) {
			this.loadingAreaListopt = loadingAreaListopt;
		}

		public String getLoadingAreaListdent() {
			return loadingAreaListdent;
		}

		public void setLoadingAreaListdent(String loadingAreaListdent) {
			this.loadingAreaListdent = loadingAreaListdent;
		}

		public String getLoadingAreaListmat() {
			return loadingAreaListmat;
		}

		public void setLoadingAreaListmat(String loadingAreaListmat) {
			this.loadingAreaListmat = loadingAreaListmat;
		}

		public String getMaxBenifitListip() {
			return maxBenifitListip;
		}

		public void setMaxBenifitListip(String maxBenifitListip) {
			this.maxBenifitListip = maxBenifitListip;
		}

		public String getMaxBenifitListop() {
			return maxBenifitListop;
		}

		public void setMaxBenifitListop(String maxBenifitListop) {
			this.maxBenifitListop = maxBenifitListop;
		}

		public String getBrokerCode() {
			return brokerCode;
		}

		public void setBrokerCode(String brokerCode) {
			this.brokerCode = brokerCode;
		}

		public String getBrokername() {
			return brokername;
		}

		public void setBrokername(String brokername) {
			this.brokername = brokername;
		}

		public String getCoverNewStartDate() {
			return coverNewStartDate;
		}

		public void setCoverNewStartDate(String coverNewStartDate) {
			this.coverNewStartDate = coverNewStartDate;
		}

		public String getCoverNewEndDate() {
			return coverNewEndDate;
		}

		public void setCoverNewEndDate(String coverNewEndDate) {
			this.coverNewEndDate = coverNewEndDate;
		}

		public String getFileName() {
			return fileName;
		}

		public void setFileName(String fileName) {
			this.fileName = fileName;
		}

		public MultipartFile getFile1() {
			return file1;
		}

		public void setFile1(MultipartFile file1) {
			this.file1 = file1;
		}

		public String getSuccessMsg() {
			return successMsg;
		}

		public void setSuccessMsg(String successMsg) {
			this.successMsg = successMsg;
		}

		public String getNotifyerror() {
			return notifyerror;
		}

		public void setNotifyerror(String notifyerror) {
			this.notifyerror = notifyerror;
		}
	/*    
	    public InputStream getInputstreamdoc1() {
			return inputstreamdoc1;
		}

		public void setInputstreamdoc1(InputStream inputstreamdoc1) {
			this.inputstreamdoc1 = inputstreamdoc1;
		}

		public InputStream getInputstreamdoc2() {
			return inputstreamdoc2;
		}

		public void setInputstreamdoc2(InputStream inputstreamdoc2) {
			this.inputstreamdoc2 = inputstreamdoc2;
		}

		public InputStream getInputstreamdoc3() {
			return inputstreamdoc3;
		}

		public void setInputstreamdoc3(InputStream inputstreamdoc3) {
			this.inputstreamdoc3 = inputstreamdoc3;
		}

		public InputStream getInputstreamdoc4() {
			return inputstreamdoc4;
		}

		public void setInputstreamdoc4(InputStream inputstreamdoc4) {
			this.inputstreamdoc4 = inputstreamdoc4;
		}

		public InputStream getInputstreamdoc5() {
			return inputstreamdoc5;
		}

		public void setInputstreamdoc5(InputStream inputstreamdoc5) {
			this.inputstreamdoc5 = inputstreamdoc5;
		}*/

		
	    
	    public String getAttachmentname1() {
			return attachmentname1;
		}

		public void setAttachmentname1(String attachmentname1) {
			this.attachmentname1 = attachmentname1;
		}

		public String getAttachmentname2() {
			return attachmentname2;
		}

		public void setAttachmentname2(String attachmentname2) {
			this.attachmentname2 = attachmentname2;
		}

		public String getAttachmentname3() {
			return attachmentname3;
		}

		public void setAttachmentname3(String attachmentname3) {
			this.attachmentname3 = attachmentname3;
		}

		public String getAttachmentname4() {
			return attachmentname4;
		}

		public void setAttachmentname4(String attachmentname4) {
			this.attachmentname4 = attachmentname4;
		}

		public String getAttachmentname5() {
			return attachmentname5;
		}

		public void setAttachmentname5(String attachmentname5) {
			this.attachmentname5 = attachmentname5;
		}

		
	    
	    
	    public String getStrPolicyNumberFlag() {
			return strPolicyNumberFlag;
		}

		public void setStrPolicyNumberFlag(String strPolicyNumberFlag) {
			this.strPolicyNumberFlag = strPolicyNumberFlag;
		}
/*
		public FormFile getSourceAttchments1() {
			return sourceAttchments1;
		}

		public void setSourceAttchments1(FormFile sourceAttchments1) {
			this.sourceAttchments1 = sourceAttchments1;
		}

		public FormFile getSourceAttchments2() {
			return sourceAttchments2;
		}

		public void setSourceAttchments2(FormFile sourceAttchments2) {
			this.sourceAttchments2 = sourceAttchments2;
		}

		public FormFile getSourceAttchments3() {
			return sourceAttchments3;
		}

		public void setSourceAttchments3(FormFile sourceAttchments3) {
			this.sourceAttchments3 = sourceAttchments3;
		}

		public FormFile getSourceAttchments4() {
			return sourceAttchments4;
		}

		public void setSourceAttchments4(FormFile sourceAttchments4) {
			this.sourceAttchments4 = sourceAttchments4;
		}

		public FormFile getSourceAttchments5() {
			return sourceAttchments5;
		}

		public void setSourceAttchments5(FormFile sourceAttchments5) {
			this.sourceAttchments5 = sourceAttchments5;
		}
*/
		
		/**
		 * @return the country
		 */
		public String getCountry() {
			return country;
		}

		/**
		 * @param country the country to set
		 */
		public void setCountry(String country) {
			this.country = country;
		}

		/**
		 * @return the currency
		 */
		public String getCurrency() {
			return currency;
		}

		/**
		 * @param currency the currency to set
		 */
		public void setCurrency(String currency) {
			this.currency = currency;
		}

		/**
		 * @return the groupName
		 */
		public String getGroupName() {
			return groupName;
		}

		/**
		 * @param groupName the groupName to set
		 */
		public void setGroupName(String groupName) {
			this.groupName = groupName;
		}

		/**
		 * @return the noofEmployees
		 */
		public String getNoofEmployees() {
			return noofEmployees;
		}

		/**
		 * @param noofEmployees the noofEmployees to set
		 */
		public void setNoofEmployees(String noofEmployees) {
			this.noofEmployees = noofEmployees;
		}

		/**
		 * @return the additionalPremium
		 */
		public String getAdditionalPremium() {
			return additionalPremium;
		}

		/**
		 * @param additionalPremium the additionalPremium to set
		 */
		public void setAdditionalPremium(String additionalPremium) {
			this.additionalPremium = additionalPremium;
		}

		/**
		 * @return the averageAge
		 */
		public String getAverageAge() {
			return averageAge;
		}

		/**
		 * @param averageAge the averageAge to set
		 */
		public void setAverageAge(String averageAge) {
			this.averageAge = averageAge;
		}

		/**
		 * @return the employeeGender
		 */
		public String getEmployeeGender() {
			return employeeGender;
		}

		/**
		 * @param employeeGender the employeeGender to set
		 */
		public void setEmployeeGender(String employeeGender) {
			this.employeeGender = employeeGender;
		}

		/**
		 * @return the familyCoverage
		 */
		public String getFamilyCoverage() {
			return familyCoverage;
		}

		/**
		 * @param familyCoverage the familyCoverage to set
		 */
		public void setFamilyCoverage(String familyCoverage) {
			this.familyCoverage = familyCoverage;
		}

		/**
		 * @return the globalCoverge
		 */
		public String getGlobalCoverge() {
			return globalCoverge;
		}

		/**
		 * @param globalCoverge the globalCoverge to set
		 */
		public void setGlobalCoverge(String globalCoverge) {
			this.globalCoverge = globalCoverge;
		}

		/**
		 * @return the groupProfileSeqID
		 */
		public Long getGroupProfileSeqID() {
			return groupProfileSeqID;
		}

		/**
		 * @param groupProfileSeqID the groupProfileSeqID to set
		 */
		public void setGroupProfileSeqID(Long groupProfileSeqID) {
			this.groupProfileSeqID = groupProfileSeqID;
		}

		

		/**
		 * @return the incomeProfileSeqID
		 */
		public Long getIncomeProfileSeqID() {
			return incomeProfileSeqID;
		}

		/**
		 * @param incomeProfileSeqID the incomeProfileSeqID to set
		 */
		public void setIncomeProfileSeqID(Long incomeProfileSeqID) {
			this.incomeProfileSeqID = incomeProfileSeqID;
		}

		/**
		 * @return the profileID
		 */
		public String[] getProfileID() {
			return profileID;
		}

		/**
		 * @param profileID the profileID to set
		 */
		public void setProfileID(String[] profileID) {
			this.profileID = profileID;
		}

		/**
		 * @return the profileValue
		 */
		public String[] getProfileValue() {
			return profileValue;
		}

		/**
		 * @param profileValue the profileValue to set
		 */
		public void setProfileValue(String[] profileValue) {
			this.profileValue = profileValue;
		}

		/**
		 * @return the profileGroup
		 */
		public String[] getProfileGroup() {
			return profileGroup;
		}

		/**
		 * @param profileGroup the profileGroup to set
		 */
		public void setProfileGroup(String[] profileGroup) {
			this.profileGroup = profileGroup;
		}

		/**
		 * @return the profilePercentage
		 */
		public String[] getProfilePercentage() {
			return profilePercentage;
		}

		/**
		 * @param profilePercentage the profilePercentage to set
		 */
		public void setProfilePercentage(String[] profilePercentage) {
			this.profilePercentage = profilePercentage;
		}

		/**
		 * @return the profileID1
		 */
		public String getProfileID1() {
			return profileID1;
		}

		/**
		 * @param profileID1 the profileID1 to set
		 */
		public void setProfileID1(String profileID1) {
			this.profileID1 = profileID1;
		}

		/**
		 * @return the profileValue1
		 */
		public String getProfileValue1() {
			return profileValue1;
		}

		/**
		 * @param profileValue1 the profileValue1 to set
		 */
		public void setProfileValue1(String profileValue1) {
			this.profileValue1 = profileValue1;
		}

		/**
		 * @return the profileGroup1
		 */
		public String getProfileGroup1() {
			return profileGroup1;
		}

		/**
		 * @param profileGroup1 the profileGroup1 to set
		 */
		public void setProfileGroup1(String profileGroup1) {
			this.profileGroup1 = profileGroup1;
		}

		/**
		 * @return the profilePercentage1
		 */
		public String getProfilePercentage1() {
			return profilePercentage1;
		}

		/**
		 * @param profilePercentage1 the profilePercentage1 to set
		 */
		public void setProfilePercentage1(String profilePercentage1) {
			this.profilePercentage1 = profilePercentage1;
		}

		/**
		 * @return the transProfileSeqID1
		 */
		public Long getTransProfileSeqID1() {
			return transProfileSeqID1;
		}

		/**
		 * @param transProfileSeqID1 the transProfileSeqID1 to set
		 */
		public void setTransProfileSeqID1(Long transProfileSeqID1) {
			this.transProfileSeqID1 = transProfileSeqID1;
		}

		/**
		 * @return the transProfileSeqID
		 */
		public Long[] getTransProfileSeqID() {
			return transProfileSeqID;
		}

		/**
		 * @param transProfileSeqID the transProfileSeqID to set
		 */
		public void setTransProfileSeqID(Long[] transProfileSeqID) {
			this.transProfileSeqID = transProfileSeqID;
		}

		/**
		 * @return the profileGroupValue1
		 */
		public String getProfileGroupValue1() {
			return profileGroupValue1;
		}

		/**
		 * @param profileGroupValue1 the profileGroupValue1 to set
		 */
		public void setProfileGroupValue1(String profileGroupValue1) {
			this.profileGroupValue1 = profileGroupValue1;
		}

		/**
		 * @return the profileGroupValue
		 */
		public String[] getProfileGroupValue() {
			return profileGroupValue;
		}

		/**
		 * @param profileGroupValue the profileGroupValue to set
		 */
		public void setProfileGroupValue(String[] profileGroupValue) {
			this.profileGroupValue = profileGroupValue;
		}

		/**
		 * @return the nameOfInsurer
		 */
		public String getNameOfInsurer() {
			return nameOfInsurer;
		}

		/**
		 * @param nameOfInsurer the nameOfInsurer to set
		 */
		public void setNameOfInsurer(String nameOfInsurer) {
			this.nameOfInsurer = nameOfInsurer;
		}

		/**
		 * @return the nameOfTPA
		 */
		public String getNameOfTPA() {
			return nameOfTPA;
		}

		/**
		 * @param nameOfTPA the nameOfTPA to set
		 */
		public void setNameOfTPA(String nameOfTPA) {
			this.nameOfTPA = nameOfTPA;
		}

		/**
		 * @return the eligibility
		 */
		public String getEligibility() {
			return eligibility;
		}

		/**
		 * @param eligibility the eligibility to set
		 */
		public void setEligibility(String eligibility) {
			this.eligibility = eligibility;
		}

		/**
		 * @return the takafulQuote
		 */
		public String getTakafulQuote() {
			return takafulQuote;
		}

		/**
		 * @param takafulQuote the takafulQuote to set
		 */
		public void setTakafulQuote(String takafulQuote) {
			this.takafulQuote = takafulQuote;
		}

		/**
		 * @return the planName
		 */
		public String getPlanName() {
			return planName;
		}

		/**
		 * @param planName the planName to set
		 */
		public void setPlanName(String planName) {
			this.planName = planName;
		}

		public String getAreaOfCover() {
			return areaOfCover;
		}

		public void setAreaOfCover(String areaOfCover) {
			this.areaOfCover = areaOfCover;
		}

		public Date getCoverStartDate() {
			return coverStartDate;
		}

		public void setCoverStartDate(Date coverStartDate) {
			this.coverStartDate = coverStartDate;
		}

		public Date getCoverEndDate() {
			return coverEndDate;
		}

		public void setCoverEndDate(Date coverEndDate) {
			this.coverEndDate = coverEndDate;
		}

		public String getClientCode() {
			return clientCode;
		}

		public void setClientCode(String clientCode) {
			this.clientCode = clientCode;
		}

		public String getPreviousPolicyNo() {
			return previousPolicyNo;
		}

		public void setPreviousPolicyNo(String previousPolicyNo) {
			this.previousPolicyNo = previousPolicyNo;
		}

		public String getTotalCovedLives() {
			return totalCovedLives;
		}

		public void setTotalCovedLives(String totalCovedLives) {
			this.totalCovedLives = totalCovedLives;
		}

		public String getTotalLivesMaternity() {
			return totalLivesMaternity;
		}

		public void setTotalLivesMaternity(String totalLivesMaternity) {
			this.totalLivesMaternity = totalLivesMaternity;
		}

		public String getTrendFactor() {
			return trendFactor;
		}

		public void setTrendFactor(String trendFactor) {
			this.trendFactor = trendFactor;
		}

	/*	*//**
		 * @return the profileIncomeList
		 *//*
		public ArrayList getProfileIncomeList() {
			return profileIncomeList;
		}

		*//**
		 * @param profileIncomeList the profileIncomeList to set
		 *//*
		public void setProfileIncomeList(ArrayList profileIncomeList) {
			this.profileIncomeList = profileIncomeList;
		}
	*/
		
		 public Long[] getBenf_typeseqid() {
				return benf_typeseqid;
			}

			public void setBenf_typeseqid(Long[] benf_typeseqid) {
				this.benf_typeseqid = benf_typeseqid;
			}

			public String[] getBenfdesc() {
				return benfdesc;
			}

			public void setBenfdesc(String[] benfdesc) {
				this.benfdesc = benfdesc;
			}

			public Long[] getGndrtypeseqid() {
				return gndrtypeseqid;
			}

			public void setGndrtypeseqid(Long[] gndrtypeseqid) {
				this.gndrtypeseqid = gndrtypeseqid;
			}

			public String[] getGndrdesc() {
				return gndrdesc;
			}

			public void setGndrdesc(String[] gndrdesc) {
				this.gndrdesc = gndrdesc;
			}

			public Long[] getAge_rngseqid() {
				return age_rngseqid;
			}

			public void setAge_rngseqid(Long[] age_rngseqid) {
				this.age_rngseqid = age_rngseqid;
			}

			public String[] getAge_range() {
				return age_range;
			}

			public void setAge_range(String[] age_range) {
				this.age_range = age_range;
			}

			public String[] getOvrprtflio_dstr() {
				return ovrprtflio_dstr;
			}

			public void setOvrprtflio_dstr(String[] ovrprtflio_dstr) {
				this.ovrprtflio_dstr = ovrprtflio_dstr;
			}

			public Long[] getNatl_typeseqid() {
				return natl_typeseqid;
			}

			public void setNatl_typeseqid(Long[] natl_typeseqid) {
				this.natl_typeseqid = natl_typeseqid;
			}

			public String[] getNatl_name() {
				return natl_name;
			}

			public void setNatl_name(String[] natl_name) {
				this.natl_name = natl_name;
			}

			public Long getBenf_typeseqid1() {
				return benf_typeseqid1;
			}

			public void setBenf_typeseqid1(Long benf_typeseqid1) {
				this.benf_typeseqid1 = benf_typeseqid1;
			}

			public String getBenfdesc1() {
				return benfdesc1;
			}

			public void setBenfdesc1(String benfdesc1) {
				this.benfdesc1 = benfdesc1;
			}

			public Long getGndrtypeseqid1() {
				return gndrtypeseqid1;
			}

			public void setGndrtypeseqid1(Long gndrtypeseqid1) {
				this.gndrtypeseqid1 = gndrtypeseqid1;
			}

			public String getGndrdesc1() {
				return gndrdesc1;
			}

			public void setGndrdesc1(String gndrdesc1) {
				this.gndrdesc1 = gndrdesc1;
			}

			public Long getAge_rngseqid1() {
				return age_rngseqid1;
			}

			public void setAge_rngseqid1(Long age_rngseqid1) {
				this.age_rngseqid1 = age_rngseqid1;
			}

			public String getAge_range1() {
				return age_range1;
			}

			public void setAge_range1(String age_range1) {
				this.age_range1 = age_range1;
			}

			public String getOvrprtflio_dstr1() {
				return ovrprtflio_dstr1;
			}

			public void setOvrprtflio_dstr1(String ovrprtflio_dstr1) {
				this.ovrprtflio_dstr1 = ovrprtflio_dstr1;
			}

			public Long getNatl_typeseqid1() {
				return natl_typeseqid1;
			}

			public void setNatl_typeseqid1(Long natl_typeseqid1) {
				this.natl_typeseqid1 = natl_typeseqid1;
			}

			public String getNatl_name1() {
				return natl_name1;
			}

			public void setNatl_name1(String natl_name1) {
				this.natl_name1 = natl_name1;
			}

			public String[] getTotalCoverdLives() {
				return totalCoverdLives;
			}

			public void setTotalCoverdLives(String[] totalCoverdLives) {
				this.totalCoverdLives = totalCoverdLives;
			}

			public String getTotalCoverdLives1() {
				return totalCoverdLives1;
			}

			public void setTotalCoverdLives1(String totalCoverdLives1) {
				this.totalCoverdLives1 = totalCoverdLives1;
			}

			   public String getNatcategorylist() {
					return natcategorylist;
				}

				public void setNatcategorylist(String natcategorylist) {
					this.natcategorylist = natcategorylist;
				}

				public String getAreaOfCoverList() {
					return areaOfCoverList;
				}

				public void setAreaOfCoverList(String areaOfCoverList) {
					this.areaOfCoverList = areaOfCoverList;
				}

				public String getNetworkList() {
					return networkList;
				}

				public void setNetworkList(String networkList) {
					this.networkList = networkList;
				}

				public String getMaxBenifitList() {
					return maxBenifitList;
				}

				public void setMaxBenifitList(String maxBenifitList) {
					this.maxBenifitList = maxBenifitList;
				}

				public String getDentalLimitList() {
					return dentalLimitList;
				}

				public void setDentalLimitList(String dentalLimitList) {
					this.dentalLimitList = dentalLimitList;
				}

				public Long getMaternityLimitList() {
					return maternityLimitList;
				}

				public void setMaternityLimitList(Long maternityLimitList) {
					this.maternityLimitList = maternityLimitList;
				}

				public String getOpticalLimitList() {
					return opticalLimitList;
				}

				public void setOpticalLimitList(String opticalLimitList) {
					this.opticalLimitList = opticalLimitList;
				}

				public String getOpCopayList() {
					return opCopayList;
				}

				public void setOpCopayList(String opCopayList) {
					this.opCopayList = opCopayList;
				}

				public String getOpDeductableList() {
					return opDeductableList;
				}

				public void setOpDeductableList(String opDeductableList) {
					this.opDeductableList = opDeductableList;
				}

				public String getDentalcopayList() {
					return dentalcopayList;
				}

				public void setDentalcopayList(String dentalcopayList) {
					this.dentalcopayList = dentalcopayList;
				}

				public String getOpticalCopayList() {
					return opticalCopayList;
				}

				public void setOpticalCopayList(String opticalCopayList) {
					this.opticalCopayList = opticalCopayList;
				}

				public String getPhysiocoverage() {
					return physiocoverage;
				}

				public void setPhysiocoverage(String physiocoverage) {
					this.physiocoverage = physiocoverage;
				}

				public String getVitDcoverage() {
					return vitDcoverage;
				}

				public void setVitDcoverage(String vitDcoverage) {
					this.vitDcoverage = vitDcoverage;
				}

				public String getVaccImmuCoverage() {
					return vaccImmuCoverage;
				}

				public void setVaccImmuCoverage(String vaccImmuCoverage) {
					this.vaccImmuCoverage = vaccImmuCoverage;
				}

				public String getMatComplicationCoverage() {
					return matComplicationCoverage;
				}

				public void setMatComplicationCoverage(String matComplicationCoverage) {
					this.matComplicationCoverage = matComplicationCoverage;
				}

				public String getPsychiatrycoverage() {
					return psychiatrycoverage;
				}

				public void setPsychiatrycoverage(String psychiatrycoverage) {
					this.psychiatrycoverage = psychiatrycoverage;
				}

				public String getDeviatedNasalSeptum() {
					return deviatedNasalSeptum;
				}

				public void setDeviatedNasalSeptum(String deviatedNasalSeptum) {
					this.deviatedNasalSeptum = deviatedNasalSeptum;
				}

				public String getObesityTreatment() {
					return obesityTreatment;
				}

				public void setObesityTreatment(String obesityTreatment) {
					this.obesityTreatment = obesityTreatment;
				}

				public String getMaternityYN() {
					return maternityYN;
				}

				public void setMaternityYN(String maternityYN) {
					this.maternityYN = maternityYN;
				}

				public String getDentalYN() {
					return dentalYN;
				}

				public void setDentalYN(String dentalYN) {
					this.dentalYN = dentalYN;
				}

				public String getDentalLivesYN() {
					return dentalLivesYN;
				}

				public void setDentalLivesYN(String dentalLivesYN) {
					this.dentalLivesYN = dentalLivesYN;
				}

				public String getOpticalYN() {
					return opticalYN;
				}

				public void setOpticalYN(String opticalYN) {
					this.opticalYN = opticalYN;
				}

				public String getOpticalLivesYN() {
					return opticalLivesYN;
				}

				public void setOpticalLivesYN(String opticalLivesYN) {
					this.opticalLivesYN = opticalLivesYN;
				}

				public String getRenewalYN() {
					return renewalYN;
				}

				public void setRenewalYN(String renewalYN) {
					this.renewalYN = renewalYN;
				}

				public String getMaxBeneLimitOth() {
					return maxBeneLimitOth;
				}

				public void setMaxBeneLimitOth(String maxBeneLimitOth) {
					this.maxBeneLimitOth = maxBeneLimitOth;
				}

				public String getDentalLimitOth() {
					return dentalLimitOth;
				}

				public void setDentalLimitOth(String dentalLimitOth) {
					this.dentalLimitOth = dentalLimitOth;
				}

				public String getOpticalLimitOth() {
					return opticalLimitOth;
				}

				public void setOpticalLimitOth(String opticalLimitOth) {
					this.opticalLimitOth = opticalLimitOth;
				}

				public String getMaternityLimitOth() {
					return maternityLimitOth;
				}

				public void setMaternityLimitOth(String maternityLimitOth) {
					this.maternityLimitOth = maternityLimitOth;
				}

				public String getOpCopayListDesc() {
					return opCopayListDesc;
				}

				public void setOpCopayListDesc(String opCopayListDesc) {
					this.opCopayListDesc = opCopayListDesc;
				}

				public Long[] getBenf_lives_seq_id() {
					return benf_lives_seq_id;
				}

				public void setBenf_lives_seq_id(Long[] benf_lives_seq_id) {
					this.benf_lives_seq_id = benf_lives_seq_id;
				}

				public Long getBenf_lives_seq_id1() {
					return benf_lives_seq_id1;
				}

				public void setBenf_lives_seq_id1(Long benf_lives_seq_id1) {
					this.benf_lives_seq_id1 = benf_lives_seq_id1;
				}

				public String getDentalcopayListDesc() {
					return dentalcopayListDesc;
				}

				public void setDentalcopayListDesc(String dentalcopayListDesc) {
					this.dentalcopayListDesc = dentalcopayListDesc;
				}

				public String getOpticalCopayListDesc() {
					return opticalCopayListDesc;
				}

				public void setOpticalCopayListDesc(String opticalCopayListDesc) {
					this.opticalCopayListDesc = opticalCopayListDesc;
				}

				public String getOpDeductableListDesc() {
					return opDeductableListDesc;
				}

				public void setOpDeductableListDesc(String opDeductableListDesc) {
					this.opDeductableListDesc = opDeductableListDesc;
				}

			

				public String getBenecoverFlagYN() {
					return benecoverFlagYN;
				}

				public void setBenecoverFlagYN(String benecoverFlagYN) {
					this.benecoverFlagYN = benecoverFlagYN;
				}

				public String getCalCPMFlagYN() {
					return calCPMFlagYN;
				}

				public void setCalCPMFlagYN(String calCPMFlagYN) {
					this.calCPMFlagYN = calCPMFlagYN;
				}

				

				public String getNatCoverdLives1() {
					return natCoverdLives1;
				}

				public void setNatCoverdLives1(String natCoverdLives1) {
					this.natCoverdLives1 = natCoverdLives1;
				}

				public Long[] getNatl_seqid() {
					return natl_seqid;
				}

				public void setNatl_seqid(Long[] natl_seqid) {
					this.natl_seqid = natl_seqid;
				}

				

				public String[] getNatCoverdLives() {
					return natCoverdLives;
				}

				public void setNatCoverdLives(String[] natCoverdLives) {
					this.natCoverdLives = natCoverdLives;
				}

				public Long getNatl_seqid1() {
					return natl_seqid1;
				}

				public void setNatl_seqid1(Long natl_seqid1) {
					this.natl_seqid1 = natl_seqid1;
				}

				public String getComments() {
					return comments;
				}

				public void setComments(String comments) {
					this.comments = comments;
				}

				
				public String getLoadingFlagYN() {
					return loadingFlagYN;
				}

				public void setLoadingFlagYN(String loadingFlagYN) {
					this.loadingFlagYN = loadingFlagYN;
				}

				public String getPricingDocs() {
					return pricingDocs;
				}

				public void setPricingDocs(String pricingDocs) {
					this.pricingDocs = pricingDocs;
				}

				

				public String getPricingRefno() {
					return pricingRefno;
				}

				public void setPricingRefno(String pricingRefno) {
					this.pricingRefno = pricingRefno;
				}

				public Long getFinaldataSeqID() {
					return finaldataSeqID;
				}

				public void setFinaldataSeqID(Long finaldataSeqID) {
					this.finaldataSeqID = finaldataSeqID;
				}

				public String getSumTotalLives() {
					return sumTotalLives;
				}

				public void setSumTotalLives(String sumTotalLives) {
					this.sumTotalLives = sumTotalLives;
				}

				public String getSumTotalLivesMaternity() {
					return sumTotalLivesMaternity;
				}

				public void setSumTotalLivesMaternity(String sumTotalLivesMaternity) {
					this.sumTotalLivesMaternity = sumTotalLivesMaternity;
				}

				public String getSumTotalLivesDental() {
					return sumTotalLivesDental;
				}

				public void setSumTotalLivesDental(String sumTotalLivesDental) {
					this.sumTotalLivesDental = sumTotalLivesDental;
				}

				public String getSumTotalLivesOptical() {
					return sumTotalLivesOptical;
				}

				public void setSumTotalLivesOptical(String sumTotalLivesOptical) {
					this.sumTotalLivesOptical = sumTotalLivesOptical;
				}

				/**
				 * @return the strPolicyNumberFlag
				 */
				public String getPolicyNumberFlag() {
					return strPolicyNumberFlag;
				}

				/**
				 * @param strPolicyNumberFlag the strPolicyNumberFlag to set
				 */
				public void setPolicyNumberFlag(String strPolicyNumberFlag) {
					this.strPolicyNumberFlag = strPolicyNumberFlag;
				}

				public String getPolicyNumber() {
					return policyNumber;
				}

				public void setPolicyNumber(String policyNumber) {
					this.policyNumber = policyNumber;
				}

				public String getSumNationalityLives() {
					return sumNationalityLives;
				}

				public void setSumNationalityLives(String sumNationalityLives) {
					this.sumNationalityLives = sumNationalityLives;
				}

				public String getClientName() {
					return clientName;
				}

				public void setClientName(String clientName) {
					this.clientName = clientName;
				}

				public String getNewdataentry() {
					return newdataentry;
				}

				public void setNewdataentry(String newdataentry) {
					this.newdataentry = newdataentry;
				}

				public String getPricingNumberAlert() {
					return pricingNumberAlert;
				}

				public void setPricingNumberAlert(String pricingNumberAlert) {
					this.pricingNumberAlert = pricingNumberAlert;
				}

				public String[] getNatovrprtflio_dstr() {
					return natovrprtflio_dstr;
				}

				public void setNatovrprtflio_dstr(String[] natovrprtflio_dstr) {
					this.natovrprtflio_dstr = natovrprtflio_dstr;
				}

				public String getNatovrprtflio_dstr1() {
					return natovrprtflio_dstr1;
				}

				public void setNatovrprtflio_dstr1(String natovrprtflio_dstr1) {
					this.natovrprtflio_dstr1 = natovrprtflio_dstr1;
				}

				public String getCompleteSaveYN() {
					return completeSaveYN;
				}

				public void setCompleteSaveYN(String completeSaveYN) {
					this.completeSaveYN = completeSaveYN;
				}

				  public String getInpatientBenefit() {
						return inpatientBenefit;
					}

				public String getInpAccomodation() {
					return inpAccomodation;
				}

				public void setInpAccomodation(String inpAccomodation) {
					this.inpAccomodation = inpAccomodation;
				}

				public Long getInpAccmdlimit() {
					return inpAccmdlimit;
				}

				public void setInpAccmdlimit(Long inpAccmdlimit) {
					this.inpAccmdlimit = inpAccmdlimit;
				}

				public String getInpAccmdCopay() {
					return inpAccmdCopay;
				}

				public void setInpAccmdCopay(String inpAccmdCopay) {
					this.inpAccmdCopay = inpAccmdCopay;
				}

				public String getInpAccmdDeductable() {
					return inpAccmdDeductable;
				}

				public void setInpAccmdDeductable(String inpAccmdDeductable) {
					this.inpAccmdDeductable = inpAccmdDeductable;
				}

				public String getPricingmodifyYN() {
					return pricingmodifyYN;
				}

				public void setPricingmodifyYN(String pricingmodifyYN) {
					this.pricingmodifyYN = pricingmodifyYN;
				}

				
				

					public void setInpatientBenefit(String inpatientBenefit) {
						this.inpatientBenefit = inpatientBenefit;
					}

					public String getOutpatientBenefit() {
						return outpatientBenefit;
					}

					public void setOutpatientBenefit(String outpatientBenefit) {
						this.outpatientBenefit = outpatientBenefit;
					}

					public String getGastricBinding() {
						return gastricBinding;
					}

					public void setGastricBinding(String gastricBinding) {
						this.gastricBinding = gastricBinding;
					}

					public String getHealthScreen() {
						return healthScreen;
					}

					public void setHealthScreen(String healthScreen) {
						this.healthScreen = healthScreen;
					}

					public String getChronicLimit() {
						return chronicLimit;
					}

					public void setChronicLimit(String chronicLimit) {
						this.chronicLimit = chronicLimit;
					}

					public String getOrthodonticsCopay() {
						return orthodonticsCopay;
					}

					public void setOrthodonticsCopay(String orthodonticsCopay) {
						this.orthodonticsCopay = orthodonticsCopay;
					}

					public String getOpCopaypharmacy() {
						return opCopaypharmacy;
					}

					public void setOpCopaypharmacy(String opCopaypharmacy) {
						this.opCopaypharmacy = opCopaypharmacy;
					}

					public String getOpInvestigation() {
						return opInvestigation;
					}

					public void setOpInvestigation(String opInvestigation) {
						this.opInvestigation = opInvestigation;
					}

					public String getOpCopyconsultn() {
						return opCopyconsultn;
					}

					public void setOpCopyconsultn(String opCopyconsultn) {
						this.opCopyconsultn = opCopyconsultn;
					}

					public String getAlAhlihospital() {
						return alAhlihospital;
					}

					public void setAlAhlihospital(String alAhlihospital) {
						this.alAhlihospital = alAhlihospital;
					}

					public String getOpCopyalahlihosp() {
						return opCopyalahlihosp;
					}

					public void setOpCopyalahlihosp(String opCopyalahlihosp) {
						this.opCopyalahlihosp = opCopyalahlihosp;
					}

					public String getOpPharmacyAlAhli() {
						return opPharmacyAlAhli;
					}

					public void setOpPharmacyAlAhli(String opPharmacyAlAhli) {
						this.opPharmacyAlAhli = opPharmacyAlAhli;
					}

					public String getOpConsultAlAhli() {
						return opConsultAlAhli;
					}

					public void setOpConsultAlAhli(String opConsultAlAhli) {
						this.opConsultAlAhli = opConsultAlAhli;
					}

					public String getOpInvestnAlAhli() {
						return opInvestnAlAhli;
					}

					public void setOpInvestnAlAhli(String opInvestnAlAhli) {
						this.opInvestnAlAhli = opInvestnAlAhli;
					}

					public String getChronicLimitOth() {
						return chronicLimitOth;
					}

					public void setChronicLimitOth(String chronicLimitOth) {
						this.chronicLimitOth = chronicLimitOth;
					}

					public String getOpdeductableserviceYN() {
						return opdeductableserviceYN;
					}

					public void setOpdeductableserviceYN(
							String opdeductableserviceYN) {
						this.opdeductableserviceYN = opdeductableserviceYN;
					}

					public String getOpCopyothers() {
						return opCopyothers;
					}

					public void setOpCopyothers(String opCopyothers) {
						this.opCopyothers = opCopyothers;
					}

					public String getPolicycategory() {
						return policycategory;
					}

					public void setPolicycategory(String policycategory) {
						this.policycategory = policycategory;
					}

					public String getOpothersAlAhli() {
						return opothersAlAhli;
					}

					public void setOpothersAlAhli(String opothersAlAhli) {
						this.opothersAlAhli = opothersAlAhli;
					}

					public String getOrthodonticsCopayDesc() {
						return orthodonticsCopayDesc;
					}

					public void setOrthodonticsCopayDesc(
							String orthodonticsCopayDesc) {
						this.orthodonticsCopayDesc = orthodonticsCopayDesc;
					}

					public String getOpCopaypharmacyDesc() {
						return opCopaypharmacyDesc;
					}

					public void setOpCopaypharmacyDesc(String opCopaypharmacyDesc) {
						this.opCopaypharmacyDesc = opCopaypharmacyDesc;
					}

					public String getOpCopyconsultnDesc() {
						return opCopyconsultnDesc;
					}

					public void setOpCopyconsultnDesc(String opCopyconsultnDesc) {
						this.opCopyconsultnDesc = opCopyconsultnDesc;
					}

					public String getOpInvestigationDesc() {
						return opInvestigationDesc;
					}

					public void setOpInvestigationDesc(String opInvestigationDesc) {
						this.opInvestigationDesc = opInvestigationDesc;
					}

					public String getOpCopyalahlihospDesc() {
						return opCopyalahlihospDesc;
					}

					public void setOpCopyalahlihospDesc(String opCopyalahlihospDesc) {
						this.opCopyalahlihospDesc = opCopyalahlihospDesc;
					}

					public String getOpPharmacyAlAhliDesc() {
						return opPharmacyAlAhliDesc;
					}

					public void setOpPharmacyAlAhliDesc(String opPharmacyAlAhliDesc) {
						this.opPharmacyAlAhliDesc = opPharmacyAlAhliDesc;
					}

					public String getOpConsultAlAhliDesc() {
						return opConsultAlAhliDesc;
					}

					public void setOpConsultAlAhliDesc(String opConsultAlAhliDesc) {
						this.opConsultAlAhliDesc = opConsultAlAhliDesc;
					}

					public String getOpInvestnAlAhliDesc() {
						return opInvestnAlAhliDesc;
					}

					public void setOpInvestnAlAhliDesc(String opInvestnAlAhliDesc) {
						this.opInvestnAlAhliDesc = opInvestnAlAhliDesc;
					}

					public String getOpothersAlAhliDesc() {
						return opothersAlAhliDesc;
					}

					public void setOpothersAlAhliDesc(String opothersAlAhliDesc) {
						this.opothersAlAhliDesc = opothersAlAhliDesc;
					}

					public String getOpCopyothersDesc() {
						return opCopyothersDesc;
					}

					public void setOpCopyothersDesc(String opCopyothersDesc) {
						this.opCopyothersDesc = opCopyothersDesc;
					}

					public String getDemographicflagYN() {
						return demographicflagYN;
					}

					public void setDemographicflagYN(String demographicflagYN) {
						this.demographicflagYN = demographicflagYN;
					}

					public String getAlAhlihospOPservices() {
						return alAhlihospOPservices;
					}

					public void setAlAhlihospOPservices(String alAhlihospOPservices) {
						this.alAhlihospOPservices = alAhlihospOPservices;
					}

					public String getAlertmsgscreen1() {
						return alertmsgscreen1;
					}

					public void setAlertmsgscreen1(String alertmsgscreen1) {
						this.alertmsgscreen1 = alertmsgscreen1;
					}

					public String getOpticalFrameLimitList() {
						return opticalFrameLimitList;
					}

					public void setOpticalFrameLimitList(String opticalFrameLimitList) {
						this.opticalFrameLimitList = opticalFrameLimitList;
					}

					public double getNumberOfLives() {
						return numberOfLives;
					}

					public void setNumberOfLives(double numberOfLives) {
						this.numberOfLives = numberOfLives;
					}

					public String getCompleteSaveYNInSc2() {
						return completeSaveYNInSc2;
					}

					public void setCompleteSaveYNInSc2(String completeSaveYNInSc2) {
						this.completeSaveYNInSc2 = completeSaveYNInSc2;
					}

					public String getRiskPremiumDate() {
						return riskPremiumDate;
					}

					public void setRiskPremiumDate(String riskPremiumDate) {
						this.riskPremiumDate = riskPremiumDate;
					}

					public String getPrmiumtablevalue() {
						return prmiumtablevalue;
					}

					public void setPrmiumtablevalue(String prmiumtablevalue) {
						this.prmiumtablevalue = prmiumtablevalue;
					}

					public String getMaternitytablevalue() {
						return maternitytablevalue;
					}

					public void setMaternitytablevalue(
							String maternitytablevalue) {
						this.maternitytablevalue = maternitytablevalue;
					}

					public String getPremiumvalue() {
						return premiumvalue;
					}

					public void setPremiumvalue(String premiumvalue) {
						this.premiumvalue = premiumvalue;
					}

					public String getMaternityvalue() {
						return maternityvalue;
					}

					public void setMaternityvalue(String maternityvalue) {
						this.maternityvalue = maternityvalue;
					}
                    public String getIpCopayDesc() {
						return ipCopayDesc;
					}

					public void setIpCopayDesc(String ipCopayDesc) {
						this.ipCopayDesc = ipCopayDesc;
					}

					public String getMaternityLimitListDesc() {
						return maternityLimitListDesc;
					}

					public void setMaternityLimitListDesc(String maternityLimitListDesc) {
						this.maternityLimitListDesc = maternityLimitListDesc;
					}

					public String getiPCopayAtAhliListDesc() {
						return iPCopayAtAhliListDesc;
					}

					public void setiPCopayAtAhliListDesc(String iPCopayAtAhliListDesc) {
						this.iPCopayAtAhliListDesc = iPCopayAtAhliListDesc;
					}

					public String getPremiumOutputStructureListDesc() {
						return premiumOutputStructureListDesc;
					}

					public void setPremiumOutputStructureListDesc(String premiumOutputStructureListDesc) {
						this.premiumOutputStructureListDesc = premiumOutputStructureListDesc;
					}
					

				    
				    public Long getGrpProfSeqId() {
						return grpProfSeqId;
					}

					public void setGrpProfSeqId(Long grpProfSeqId) {
						this.grpProfSeqId = grpProfSeqId;
					}

					public String getGroupRefNo() {
						return groupRefNo;
					}

					public void setGroupRefNo(String groupRefNo) {
						this.groupRefNo = groupRefNo;
					}

					public String getGroupStatus() {
						return groupStatus;
					}

					public void setGroupStatus(String groupStatus) {
						this.groupStatus = groupStatus;
					}

					public Long getGroupProfileSeqID_f() {
						return groupProfileSeqID_f;
					}

					public void setGroupProfileSeqID_f(Long groupProfileSeqID_f) {
						this.groupProfileSeqID_f = groupProfileSeqID_f;
					}

					public Long getBenf_lives_seq_id1_f() {
						return benf_lives_seq_id1_f;
					}

					public void setBenf_lives_seq_id1_f(Long benf_lives_seq_id1_f) {
						this.benf_lives_seq_id1_f = benf_lives_seq_id1_f;
					}

					public Long getBenf_typeseqid1_f() {
						return benf_typeseqid1_f;
					}

					public void setBenf_typeseqid1_f(Long benf_typeseqid1_f) {
						this.benf_typeseqid1_f = benf_typeseqid1_f;
					}

					public String getBenfdesc1_f() {
						return benfdesc1_f;
					}

					public void setBenfdesc1_f(String benfdesc1_f) {
						this.benfdesc1_f = benfdesc1_f;
					}

					public Long getGndrtypeseqid1_f() {
						return gndrtypeseqid1_f;
					}

					public void setGndrtypeseqid1_f(Long gndrtypeseqid1_f) {
						this.gndrtypeseqid1_f = gndrtypeseqid1_f;
					}

					public String getGndrdesc1_f() {
						return gndrdesc1_f;
					}

					public void setGndrdesc1_f(String gndrdesc1_f) {
						this.gndrdesc1_f = gndrdesc1_f;
					}

					public Long getAge_rngseqid1_f() {
						return age_rngseqid1_f;
					}

					public void setAge_rngseqid1_f(Long age_rngseqid1_f) {
						this.age_rngseqid1_f = age_rngseqid1_f;
					}

					public String getAge_range1_f() {
						return age_range1_f;
					}

					public void setAge_range1_f(String age_range1_f) {
						this.age_range1_f = age_range1_f;
					}

					public String getOvrprtflio_dstr1_f() {
						return ovrprtflio_dstr1_f;
					}

					public void setOvrprtflio_dstr1_f(String ovrprtflio_dstr1_f) {
						this.ovrprtflio_dstr1_f = ovrprtflio_dstr1_f;
					}

					public String getTotalCoverdLives1_f() {
						return totalCoverdLives1_f;
					}

					public void setTotalCoverdLives1_f(String totalCoverdLives1_f) {
						this.totalCoverdLives1_f = totalCoverdLives1_f;
					}

					public String getSumTotalLivesMale() {
						return sumTotalLivesMale;
					}

					public void setSumTotalLivesMale(String sumTotalLivesMale) {
						this.sumTotalLivesMale = sumTotalLivesMale;
					}

					public String getGroupRegSeqId() {
						return groupRegSeqId;
					}

					public void setGroupRegSeqId(String groupRegSeqId) {
						this.groupRegSeqId = groupRegSeqId;
					}

					public String getGrossclaulation() {
						return grossclaulation;
					}

					public void setGrossclaulation(String grossclaulation) {
						this.grossclaulation = grossclaulation;
					}

					public String getStatusCheck() {
						return statusCheck;
					}

					public void setStatusCheck(String statusCheck) {
						this.statusCheck = statusCheck;
					}

					public String getNoCoverdLives() {
						return noCoverdLives;
					}

					public void setNoCoverdLives(String noCoverdLives) {
						this.noCoverdLives = noCoverdLives;
					}

					public String getSrcDoc1Yn() {
						return srcDoc1Yn;
					}

					public void setSrcDoc1Yn(String srcDoc1Yn) {
						this.srcDoc1Yn = srcDoc1Yn;
					}

					public String getSrcDoc2Yn() {
						return srcDoc2Yn;
					}

					public void setSrcDoc2Yn(String srcDoc2Yn) {
						this.srcDoc2Yn = srcDoc2Yn;
					}

					public String getSrcDoc3Yn() {
						return srcDoc3Yn;
					}

					public void setSrcDoc3Yn(String srcDoc3Yn) {
						this.srcDoc3Yn = srcDoc3Yn;
					}

					public String getSrcDoc4Yn() {
						return srcDoc4Yn;
					}

					public void setSrcDoc4Yn(String srcDoc4Yn) {
						this.srcDoc4Yn = srcDoc4Yn;
					}

					public String getSrcDoc5Yn() {
						return srcDoc5Yn;
					}

					public void setSrcDoc5Yn(String srcDoc5Yn) {
						this.srcDoc5Yn = srcDoc5Yn;
					}

					public InputStream getInputstreamdoc1() {
						return inputstreamdoc1;
					}

					public void setInputstreamdoc1(InputStream inputstreamdoc1) {
						this.inputstreamdoc1 = inputstreamdoc1;
					}

					public InputStream getInputstreamdoc2() {
						return inputstreamdoc2;
					}

					public void setInputstreamdoc2(InputStream inputstreamdoc2) {
						this.inputstreamdoc2 = inputstreamdoc2;
					}

					public InputStream getInputstreamdoc3() {
						return inputstreamdoc3;
					}

					public void setInputstreamdoc3(InputStream inputstreamdoc3) {
						this.inputstreamdoc3 = inputstreamdoc3;
					}

					public InputStream getInputstreamdoc4() {
						return inputstreamdoc4;
					}

					public void setInputstreamdoc4(InputStream inputstreamdoc4) {
						this.inputstreamdoc4 = inputstreamdoc4;
					}

					public InputStream getInputstreamdoc5() {
						return inputstreamdoc5;
					}

					public void setInputstreamdoc5(InputStream inputstreamdoc5) {
						this.inputstreamdoc5 = inputstreamdoc5;
					}

					public Long[] getGroupPricingSeqId() {
						return groupPricingSeqId;
					}

					public void setGroupPricingSeqId(Long[] groupPricingSeqId) {
						this.groupPricingSeqId = groupPricingSeqId;
					}

					public Long getGroupProfileSeqid() {
						return groupProfileSeqid;
					}

					public void setGroupProfileSeqid(Long groupProfileSeqid) {
						this.groupProfileSeqid = groupProfileSeqid;
					}

				

					public Long[] getLodingPricingVal() {
						return lodingPricingVal;
					}

					public void setLodingPricingVal(Long[] lodingPricingVal) {
						this.lodingPricingVal = lodingPricingVal;
					}

					public Long[] getDiscountPricingVal() {
						return discountPricingVal;
					}

					public void setDiscountPricingVal(Long[] discountPricingVal) {
						this.discountPricingVal = discountPricingVal;
					}

					

					public Long[] getRevisedPrimiumVal() {
						return revisedPrimiumVal;
					}

					public void setRevisedPrimiumVal(Long[] revisedPrimiumVal) {
						this.revisedPrimiumVal = revisedPrimiumVal;
					}

					public Long getRevisedPrimiumGroupVal() {
						return revisedPrimiumGroupVal;
					}

					public void setRevisedPrimiumGroupVal(Long revisedPrimiumGroupVal) {
						this.revisedPrimiumGroupVal = revisedPrimiumGroupVal;
					}

					public Long getTargetPrimiumVal() {
						return targetPrimiumVal;
					}

					public void setTargetPrimiumVal(Long targetPrimiumVal) {
						this.targetPrimiumVal = targetPrimiumVal;
					}

					public Long getProposedVal() {
						return proposedVal;
					}

					public void setProposedVal(Long proposedVal) {
						this.proposedVal = proposedVal;
					}

					public String getGroupProfileRefNo() {
						return groupProfileRefNo;
					}

					public void setGroupProfileRefNo(String groupProfileRefNo) {
						this.groupProfileRefNo = groupProfileRefNo;
					}

					public String getPolicyDuration() {
						return policyDuration;
					}

					public void setPolicyDuration(String policyDuration) {
						this.policyDuration = policyDuration;
					}

					public String getGroupPolicyCoverStartDate() {
						return groupPolicyCoverStartDate;
					}

					public void setGroupPolicyCoverStartDate(String groupPolicyCoverStartDate) {
						this.groupPolicyCoverStartDate = groupPolicyCoverStartDate;
					}

					public String getGroupPolicyCoverEndDate() {
						return groupPolicyCoverEndDate;
					}

					public void setGroupPolicyCoverEndDate(String groupPolicyCoverEndDate) {
						this.groupPolicyCoverEndDate = groupPolicyCoverEndDate;
					}

					public String getProposedLoding() {
						return proposedLoding;
					}

					public void setProposedLoding(String proposedLoding) {
						this.proposedLoding = proposedLoding;
					}

					public String getCensusFileUploadName() {
						return censusFileUploadName;
					}

					public void setCensusFileUploadName(String censusFileUploadName) {
						this.censusFileUploadName = censusFileUploadName;
					}

					public String getLastSaveDateGroupPricing() {
						return lastSaveDateGroupPricing;
					}

					public void setLastSaveDateGroupPricing(String lastSaveDateGroupPricing) {
						this.lastSaveDateGroupPricing = lastSaveDateGroupPricing;
					}

					public String getTotalClaimDes() {
						return totalClaimDes;
					}

					public void setTotalClaimDes(String totalClaimDes) {
						this.totalClaimDes = totalClaimDes;
					}

					public String getUltimateLossDes() {
						return ultimateLossDes;
					}

					public void setUltimateLossDes(String ultimateLossDes) {
						this.ultimateLossDes = ultimateLossDes;
					}

					public String getLossrationDes() {
						return lossrationDes;
					}

					public void setLossrationDes(String lossrationDes) {
						this.lossrationDes = lossrationDes;
					}

					public String getPremiumPerMemDes() {
						return premiumPerMemDes;
					}

					public void setPremiumPerMemDes(String premiumPerMemDes) {
						this.premiumPerMemDes = premiumPerMemDes;
					}

				

					public static long getSerialversionuid() {
						return serialVersionUID;
					}

					public MultipartFile[] getFiles() {
						return files;
					}

					public void setFiles(MultipartFile[] files) {
						this.files = files;
					}

					public String getGroupiniatedDate() {
						return groupiniatedDate;
					}

					public void setGroupiniatedDate(String groupiniatedDate) {
						this.groupiniatedDate = groupiniatedDate;
					}

					public String getGroupProductName() {
						return groupProductName;
					}

					public void setGroupProductName(String groupProductName) {
						this.groupProductName = groupProductName;
					}

					public String getGroupSelectionNo() {
						return groupSelectionNo;
					}

					public void setGroupSelectionNo(String groupSelectionNo) {
						this.groupSelectionNo = groupSelectionNo;
					}

					public String getInitiatedDate() {
						return initiatedDate;
					}

					public void setInitiatedDate(String initiatedDate) {
						this.initiatedDate = initiatedDate;
					}

					public String getPricingTempNo() {
						return pricingTempNo;
					}

					public void setPricingTempNo(String pricingTempNo) {
						this.pricingTempNo = pricingTempNo;
					}

					public String getCopyType() {
						return copyType;
					}

					public void setCopyType(String copyType) {
						this.copyType = copyType;
					}

					public String getFinalTotalLives() {
						return finalTotalLives;
					}

					public void setFinalTotalLives(String finalTotalLives) {
						this.finalTotalLives = finalTotalLives;
					}

					public String getExprienceDscDate() {
						return exprienceDscDate;
					}

					public void setExprienceDscDate(String exprienceDscDate) {
						this.exprienceDscDate = exprienceDscDate;
					}

					public String getIpCopayListDesc() {
						return ipCopayListDesc;
					}

					public void setIpCopayListDesc(String ipCopayListDesc) {
						this.ipCopayListDesc = ipCopayListDesc;
					}

					public String getTotalClaimDate() {
						return totalClaimDate;
					}

					public void setTotalClaimDate(String totalClaimDate) {
						this.totalClaimDate = totalClaimDate;
					}

					public String getGroupPricingNewFlag() {
						return groupPricingNewFlag;
					}

					public void setGroupPricingNewFlag(String groupPricingNewFlag) {
						this.groupPricingNewFlag = groupPricingNewFlag;
					}

					public String getCensusSavaYn() {
						return censusSavaYn;
					}

					public void setCensusSavaYn(String censusSavaYn) {
						this.censusSavaYn = censusSavaYn;
					}

					public String getBrokerflag() {
						return brokerflag;
					}

					public void setBrokerflag(String brokerflag) {
						this.brokerflag = brokerflag;
					}

					public String getCopydataflag() {
						return copydataflag;
					}

					public void setCopydataflag(String copydataflag) {
						this.copydataflag = copydataflag;
					}

					public String getMaximumBenefitsLimitsDesc() {
						return maximumBenefitsLimitsDesc;
					}

					public void setMaximumBenefitsLimitsDesc(String maximumBenefitsLimitsDesc) {
						this.maximumBenefitsLimitsDesc = maximumBenefitsLimitsDesc;
					}
                															
             
}

/**
 * Date Mar 09 2018
 * This class is used for Get the Login details 
 * @author sangamesh
 */
package com.vidal.command.usermanagement;

import java.util.Date;

import org.hibernate.validator.constraints.NotEmpty;

import com.vidal.command.base.BaseVO;
import com.vidal.common.VidalCommon;


public class UserVO extends BaseVO{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String strUserId="";
	private String strPassword="";
    private String strPolicyNo="";
    private String strEnrollmentID="";
    private String strGroupID="";
    private String strLoginType="";
    private String strGroupName = "";
    private String strCertificateNbr= "";
    private String strCustomerCode = "";
	private String HostIPAddress = null;
	private Date dtLastLoginDate=null; 
	private String LocalIPAddress = null;
	@NotEmpty
	private String username="";
	@NotEmpty
	private String pwd="";
    /**
	 * @param ipAddress the hostIPAddress to set
	 */
	public void setHostIPAddress(String ipAddress) {
		HostIPAddress = ipAddress;
	}

	/**
	 * @return the hostIPAddress
	 */
	public String getHostIPAddress() {
		return HostIPAddress;
	}
  
    /** Retrieve the CustomerCode
	 * @return Returns the strCustomerCode.
	 */
	public String getCustomerCode() {
		return strCustomerCode;
	}//end of getCustomerCode()

	/** Sets the CustomerCode
	 * @param strCustomerCode The strCustomerCode to set.
	 */
	public void setCustomerCode(String strCustomerCode) {
		this.strCustomerCode = strCustomerCode;
	}//end of setCustomerCode(String strCustomerCode)

	/**
     * Retrieve the Certificate Number
     * @return  strCertificateNbr String
     */
    public String getCertificateNbr() {
        return strCertificateNbr;
    }//end of getCertificateNbr()

    /**
     * Sets the Certificate Number
     * @param  strCertificateNbr String
     */
    public void setCertificateNbr(String strCertificateNbr) {
        this.strCertificateNbr = strCertificateNbr;
    }//end of setCertificateNbr(String strCertificateNbr)
    
    /** Retrieve the GroupName
	 * @return Returns the strGroupName.
	 */
	public String getGroupName() {
		return strGroupName;
	}//end of getGroupName()

	/** Sets the GroupName
	 * @param strGroupName The strGroupName to set.
	 */
	public void setGroupName(String strGroupName) {
		this.strGroupName = strGroupName;
	}//end of setGroupName(String strGroupName)

	/**
     * Retrieve the Enrollment ID
     * @return  strEnrollmentID String
     */
    public String getEnrollmentID() {
        return strEnrollmentID;
    }//end of getEnrollmentID()

    /**
     * Sets the Enrollment ID
     * @param  strEnrollmentID String
     */
    public void setEnrollmentID(String strEnrollmentID) {
        this.strEnrollmentID = strEnrollmentID;
    }//end of setEnrollmentID(String strEnrollmentID)

    /**
     * Retrieve the Group ID
     * @return  strGroupID String
     */
    public String getGroupID() {
        return strGroupID;
    }//end of getGroupID()

    /**
     * Sets the Group ID
     * @param  strGroupID String
     */
    public void setGroupID(String strGroupID) {
        this.strGroupID = strGroupID;
    }//end of setGroupID(String strGroupID)

    /**
     * Retrieve the Login Type
     * @return  strLoginType String
     */
    public String getLoginType() {
        return strLoginType;
    }//end of getLoginType()

    /**
     * Sets the Login Type
     * @param  strLoginType String
     */
    public void setLoginType(String strLoginType) {
        this.strLoginType = strLoginType;
    }//end of setLoginType(String strLoginType)

    /**
     * Retrieve the Policy No
     * @return  strPolicyNo String
     */
    public String getPolicyNo() {
        return strPolicyNo;
    }//end of getPolicyNo()

    /**
     * Sets the Policy No
     * @param  strPolicyNo String
     */
    public void setPolicyNo(String strPolicyNo) {
        this.strPolicyNo = strPolicyNo;
    }//end of setPolicyNo(String strPolicyNo)

    /**
	 * Store the user id
	 * @param strUserId String the user id
	 */
	public void setUSER_ID(String strUserId)
	{
		this.strUserId = strUserId;
	}//end of setUSER_ID(String strUserId)

	/**
	 * Retrieve the user id
	 * @return strUserId String the user id
	 */
	public String getUSER_ID()
	{
		return strUserId;
	}//end of getUSER_ID()

	/**
	 * Sets the password
	 * @param strPassword String the password
	 */
	public void setPassword(String strPassword)
	{
		this.strPassword = strPassword;
	}//end of setPassword(String strPassword)

	/**
	 * Retrieve the password
	 * @return strPassword String the password
	 */
	public String getPassword()
	{
		return strPassword;
	}//end of getPassword()

	/** Retrieve the Authorized Date
	 * @return Returns the dtAuthorizedDate.
	 */
	public Date getLastLoginDate() {
		return dtLastLoginDate;
	}//end of getAuthorizedDate()
	
	/** Retrieve the Authorized Date
	 * @return Returns the dtAuthorizedDate.
	 */
	public String getLastLoginDateTime() {
		return VidalCommon.getFormattedDateHour(dtLastLoginDate);
	}//end of getAuthorizedDateTime()

	/** Sets the Authorized Date
	 * @param dtAuthorizedDate The dtAuthorizedDate to set.
	 */
	public void setLastLoginDate(Date dtLastLoginDate) {
		this.dtLastLoginDate = dtLastLoginDate;
	}//end of setAuthorizedDate(Date dtAuthorizedDate)

	/**
	 * @return the localIPAddress
	 */
	public String getLocalIPAddress() {
		return LocalIPAddress;
	}

	/**
	 * @param localIPAddress the localIPAddress to set
	 */
	public void setLocalIPAddress(String localIPAddress) {
		LocalIPAddress = localIPAddress;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPwd() {
		return pwd;
	}

	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
}

package com.vidal.command.pricing;

import javax.xml.bind.annotation.XmlAttribute;

public class MaternityData {
	
	private String maatgender;
	private String matminage;
	private String matmaxage;
	private String matrelation;
	private String maritalstat;
	
	public MaternityData() {
		
	}

	public MaternityData(String maatgender, String matminage, String matmaxage, String matrelation,
			String maritalstat) {
		super();
		this.maatgender = maatgender;
		this.matminage = matminage;
		this.matmaxage = matmaxage;
		this.matrelation = matrelation;
		this.maritalstat = maritalstat;
	}

	@XmlAttribute
	public String getMaatgender() {
		return maatgender;
	}

	public void setMaatgender(String maatgender) {
		this.maatgender = maatgender;
	}

	@XmlAttribute
	public String getMatminage() {
		return matminage;
	}

	public void setMatminage(String matminage) {
		this.matminage = matminage;
	}

	@XmlAttribute
	public String getMatmaxage() {
		return matmaxage;
	}

	public void setMatmaxage(String matmaxage) {
		this.matmaxage = matmaxage;
	}

	@XmlAttribute
	public String getMatrelation() {
		return matrelation;
	}

	public void setMatrelation(String matrelation) {
		this.matrelation = matrelation;
	}

	@XmlAttribute
	public String getMaritalstat() {
		return maritalstat;
	}

	public void setMaritalstat(String maritalstat) {
		this.maritalstat = maritalstat;
	}
	
	
	
	
	

}

package com.vidal.command.common;

import com.vidal.command.base.BaseVO;

public class CacheVO extends BaseVO{
	private String cacheId="";
	private String cacheDesc="";
	public String getCacheId() {
		return cacheId;
	}
	public void setCacheId(String cacheId) {
		this.cacheId = cacheId;
	}
	public String getCacheDesc() {
		return cacheDesc;
	}
	public void setCacheDesc(String cacheDesc) {
		this.cacheDesc = cacheDesc;
	}
}

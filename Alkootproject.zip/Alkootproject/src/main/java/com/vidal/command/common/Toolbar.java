/**
 * @ (#) Toolbar.java Oct 10, 2005
 * Project      :
 * File         : Toolbar.java
 * Author       : Nagaraj D V
 * Company      :
 * Date Created : Oct 10, 2005
 *
 * @author       : Nagaraj D V
 * Modified by   :p
 * Modified date :
 * Reason        :
 */
package com.vidal.command.common;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
//import org.apache.log4j.Logger;

public class Toolbar implements Serializable{
//    private static Logger log = Logger.getLogger( Toolbar.class );
    IconObject conflictIcon = new IconObject();
    IconObject docViewIcon = new IconObject();
    HashMap<Object, Object> hm = null;
    WebBoard webBoard = new WebBoard();
    ArrayList<String> alConflictVisibility = null;
    ArrayList<String> alDocViewVisibility = null;
    ArrayList<String> alWebBoardVisibility = null;
    private ArrayList<String> alDocViewParams=null;
    private String strUrl = "";
    private String strHost = "";

    /**
     * @return Returns the alDocViewParams.
     */
    public ArrayList<String> getDocViewParams()
    {
        return alDocViewParams;
    }//end of ArrayList<String> getDocViewParams()

    /**
     * @param alDocViewParams The alDocViewParams to set.
     */
    public void setDocViewParams(ArrayList<String> alDocViewParams)
    {
        this.alDocViewParams = alDocViewParams;
    }//end of setDocViewParams(ArrayList<String> alDocViewParams)

    /**
     * @return Returns the strUrl.
     */
    public String getUrl()
    {
        return strUrl;
    }//end of getUrl()
    /**
     * @param strUrl The strUrl to set.
     */
    public void setUrl(String strUrl)
    {
        this.strUrl = strUrl;
    }//end of setUrl(String strUrl)

    /**
     * @return Returns the strHost.
     */
    public String getHost()
    {
        return strHost;
    }//end of getHost()
    /**
     * @param strHost The strHost to set.
     */
    public void setHost(String strHost)
    {
        this.strHost = strHost;
    }//end of setHost(String strHost)

    public String getQueryString()
    {
        String strQueryString="";
        if(alDocViewParams!=null && alDocViewParams.size()>0)
        {
            for(int i=0;i<alDocViewParams.size();i++)
            {
                if(i<alDocViewParams.size()-1)
                {
                    strQueryString=strQueryString+alDocViewParams.get(i)+"&amp;";
                }//end of if(i<alDocViewParams.size()-1)
                else
                {
                    strQueryString=strQueryString+alDocViewParams.get(i);
                }//end of else
            }//end of for(int i=0;i<alDocViewParams.size();i++)
        }//end of if(alDocViewParams!=null && alDocViewParams.size()>0)
        return strQueryString;
    }//end of getQueryString()
    public Toolbar()
    {
    	 
    }
    public Toolbar(IconObject conflictIcon, IconObject docViewIcon, String strLink)
    {
        this.conflictIcon = conflictIcon;
        this.docViewIcon  = docViewIcon;
        this.updateVisibility(strLink);
    }
    /**
     * @return Returns the conflictIcon object.
     */
    public IconObject getConflictIcon()
    {
        return this.conflictIcon;
    }//end of getConflictIcon()

    /**
     * @return Returns the docViewIcon object.
     */
    public IconObject getDocViewIcon()
    {
        return this.docViewIcon;
    }//end of getDocViewIcon()

    /**
     * @return Returns the webBoard object.
     */
    public WebBoard getWebBoard()
    {
    	 return this.webBoard;
    }//end of getDocViewIcon()

    /**
     * updates the visibility links
     */
    public void setLinks(String strLink)
    {
        this.updateVisibility(strLink);
    }//end of setLinks(String strLink)

    /**
     * @return Returns the webBoard object based on the appropriate identifier
     */
    public WebBoard currentWebBoard(String strId)
    {
        if(hm == null)
            this.loadWebBoard();
        webBoard = (WebBoard)hm.get(strId);

        if(webBoard == null)
            webBoard = new WebBoard();

        return webBoard;
    }//end of currentWebBoard(String strId)

    /**
     * loads the hash map object with web board objects
     */
    private void loadWebBoard()
    {
        /*
        ArrayList alCacheObjects = new ArrayList();
        CacheObject cacheObject = new CacheObject();
        cacheObject.setCacheDesc("User Management.Users");
        alCacheObjects.add(cacheObject);
        WebBoard webBoard = new WebBoard();
        webBoard.setWebboardList(alCacheObjects);
        */
        hm = new HashMap<Object, Object>();
       
        hm.put("Pre-Authorization.Processing", new WebBoard());
        hm.put("Claims.Processing", new WebBoard());
        hm.put("OPD Pre-Authorization.Processing",new WebBoard());
     
    }//end of loadWebBoard()

    /**
     * loads the arraylist object's with the links
     */
    private void loadVisibilityInfo()
    {
        //construct the links where conflict icon's has to be displayed
        alConflictVisibility = new ArrayList<String>();
        alConflictVisibility.add("Pre-Authorization.Processing.General");
        alConflictVisibility.add("Pre-Authorization.Processing.Authorization");
        alConflictVisibility.add("Claims.Processing.General");
        alConflictVisibility.add("Claims.Processing.Settlement");

//      construct the links where document viewer icon's has to be displayed
        alDocViewVisibility = new ArrayList<String>();
       
        alDocViewVisibility.add("Pre-Authorization.Processing.General");
        alDocViewVisibility.add("Pre-Authorization.Processing.Medical");
        alDocViewVisibility.add("Pre-Authorization.Processing.Tariff");
        alDocViewVisibility.add("Pre-Authorization.Processing.Authorization");
        alDocViewVisibility.add("Pre-Authorization.Processing.History");
        alDocViewVisibility.add("Pre-Authorization.Processing.Support Doc");
        alDocViewVisibility.add("Pre-Authorization.Processing.General.Discrepancy");
        alDocViewVisibility.add("Pre-Authorization.Processing.Alert");
        alDocViewVisibility.add("Claims.Processing.General");
        alDocViewVisibility.add("Claims.Processing.Medical");
        alDocViewVisibility.add("Claims.Processing.Bills");
        alDocViewVisibility.add("Claims.Processing.Benefit Calculation");
        alDocViewVisibility.add("Claims.Processing.Support Doc");
        alDocViewVisibility.add("Claims.Processing.Settlement");
        alDocViewVisibility.add("Claims.Processing.History");
        alDocViewVisibility.add("Claims.Processing.Alert");
       
		

        //construct the links where webboard icon's has to be displayed
        alWebBoardVisibility = new ArrayList<String>();
        


        //links related to Pre-Authorization module
        alWebBoardVisibility.add("Pre-Authorization.Processing.Search");
        alWebBoardVisibility.add("Pre-Authorization.Processing.General");
        alWebBoardVisibility.add("Pre-Authorization.Processing.Medical");
        alWebBoardVisibility.add("Pre-Authorization.Processing.Tariff");
        alWebBoardVisibility.add("Pre-Authorization.Processing.Rule Data");
        alWebBoardVisibility.add("Pre-Authorization.Processing.Authorization");
        alWebBoardVisibility.add("Pre-Authorization.Processing.Alert");
        alWebBoardVisibility.add("Pre-Authorization.Processing.History");
        alWebBoardVisibility.add("Pre-Authorization.Processing.Support Doc");
        
        //links related to OPD Pre-Authorization module
        alWebBoardVisibility.add("OPD Pre-Authorization.Processing.Search");
        alWebBoardVisibility.add("OPD Pre-Authorization.Processing.General");
        alWebBoardVisibility.add("OPD Pre-Authorization.Rule Data");

        //links related to Claims module
        alWebBoardVisibility.add("Claims.Processing.Search");
        alWebBoardVisibility.add("Claims.Processing.General");
        alWebBoardVisibility.add("Claims.Processing.Medical");
        alWebBoardVisibility.add("Claims.Processing.Bills");
        alWebBoardVisibility.add("Claims.Processing.Benefit Calculation");
        alWebBoardVisibility.add("Claims.Processing.Rule Data");
        alWebBoardVisibility.add("Claims.Processing.Support Doc");
        alWebBoardVisibility.add("Claims.Processing.Settlement");
        alWebBoardVisibility.add("Claims.Processing.History");
        alWebBoardVisibility.add("Claims.Processing.Alert");
		
    }//end of loadWebBoard()

    public void updateVisibility(String strLink)
    {
    	
        if(webBoard == null)
            this.currentWebBoard(strLink);

        if(alConflictVisibility == null || alDocViewVisibility == null || alWebBoardVisibility == null)
            this.loadVisibilityInfo();

        this.getConflictIcon().setVisible(alConflictVisibility.contains(strLink));
        this.getDocViewIcon().setVisible(alDocViewVisibility.contains(strLink));
        this.webBoard = this.currentWebBoard(strLink.substring(0,strLink.lastIndexOf(".")));//main link.sub link value
       
        this.webBoard.setVisible(alWebBoardVisibility.contains(strLink));

    }//end of updateVisibility(String strLink)

    public String getDocUrl(){
        String strURL = "http://172.16.1.70/view?";
        return strURL;
    }//end of getDocUrl()
    
	public String getPreauthDocUrl(){
        String strURL ="http://172.16.1.209:3000/view?"; 
        return strURL;
    }//end of getPreauthDocUrl()
	
    public String getWebDocUrl(){
        String strURL ="http://172.16.1.70/view?"; 
        return strURL;
    }//end of getDocUrl()

}//end of Toolbar

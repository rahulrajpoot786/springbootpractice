package com.vidal.dao.pricing;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;

import javax.sql.DataSource;

import oracle.jdbc.OracleTypes;

import org.apache.pdfbox.contentstream.operator.color.SetColor;
import org.apache.pdfbox.contentstream.operator.state.SetRenderingIntent;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.itextpdf.text.log.SysoCounter;
import com.vidal.command.common.CacheObject;
import com.vidal.command.pricing.DashboardVO;
import com.vidal.command.pricing.InsPricingVO;
import com.vidal.common.UXUtility;
import com.vidal.common.VidalCommon;
@Repository
public class DashboardDAOimpl  implements DashboardDAO{
	@Autowired
	private DataSource dataSource;
	private static final String strSwInsuranceProfileList="{CALL PRICING_APP_PKG.select_client_prof_list(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}";
	private static final String strSwInsuranceDelete="{CALL PRICING_APP_PKG.delete_client_pricing(?,?,?,?,?)}";
	private static final String strUserName = "select a.group_name from app.tpa_group_registration  a where a.group_reg_seq_id= ?";
	private static final String strGroupPricingList ="{Call PRICING_APP_PKG.select_group_prof_list(?,?,?,?,?)}";
	
	private static final String strGroupPricingDisplayList ="{Call PRICING_APP_PKG.get_group_profile_details(?,?,?,?,?)}";
	private static final String strGroupPricingSaveDetails ="{Call PRICING_APP_PKG.save_group_pric_details(?,?,?,?,?,?,?,?,?,?)}";
	private static final String strGroupPricingsGenerateSeqId ="{Call PRICING_APP_PKG.generate_pricing_num(?,?,?,?,?)}";
	private static final String strgetFetchFlag ="{Call PRICING_APP_PKG.group_pric_err_proc(?,?)}";
	
   
	/* (non-Javadoc)
	 * @see com.vidal.dao.pricing.DashboardDAO#getSwInsuranceProfileList(java.util.ArrayList)
	 */
	@Override
	 public Object[] getSwInsuranceProfileList(ArrayList alSearchObjects)throws Exception {
		// TODO Auto-generated method stub
		ArrayList<Object> alResultList = new ArrayList<Object>();
	
		 DashboardVO dashboardVO = null;
		  //ResultSet rs = null;
		Object[] objects=new Object[2];
		try (Connection con = dataSource.getConnection();
				CallableStatement cStmtObject = (java.sql.CallableStatement) con.prepareCall(strSwInsuranceProfileList);) {
			
			
		    	cStmtObject.setString(1,(String) alSearchObjects.get(0));
		    	cStmtObject.setString(2,(String) alSearchObjects.get(1));
		    	cStmtObject.setString(3,(String) alSearchObjects.get(2));
		    	cStmtObject.setString(4,(String)alSearchObjects.get(3));
		    	cStmtObject.setString(5,(String)alSearchObjects.get(4));// group name
				cStmtObject.setString(6,(String)alSearchObjects.get(5));
				cStmtObject.setString(7,(String)alSearchObjects.get(6));
				cStmtObject.setString(8,(String)alSearchObjects.get(7));
	            cStmtObject.setString(9,(String)alSearchObjects.get(8));
			    cStmtObject.setString(10,(String)alSearchObjects.get(9));
				cStmtObject.setString(11,(String)alSearchObjects.get(10));
				cStmtObject.setString(12,(String)alSearchObjects.get(11));
				cStmtObject.setString(13,(String)alSearchObjects.get(12));
				cStmtObject.setString(14,(String)alSearchObjects.get(13));
				cStmtObject.setString(15,(String)alSearchObjects.get(14));
				cStmtObject.setString(16,(String)alSearchObjects.get(15));
				cStmtObject.setString(17,(String)alSearchObjects.get(16));
			
			

				cStmtObject.registerOutParameter(18,OracleTypes.CURSOR);
				cStmtObject.registerOutParameter(19,OracleTypes.CURSOR);
				cStmtObject.execute();
		//ResultSet rs = (java.sql.ResultSet)cStmtObject.getObject(18);
	//	ResultSet tableMetadataResultset = (java.sql.ResultSet)cStmtObject.getObject(19);
		try(ResultSet rs = (java.sql.ResultSet)cStmtObject.getObject(18); ResultSet tableMetadataResultset = (java.sql.ResultSet)cStmtObject.getObject(19);){
		
		if(rs != null)
		{
			while (rs.next()) {
				dashboardVO=new DashboardVO();
				
				if(rs.getString("CLIENT_CODE")!=null){
				dashboardVO.setClientCode(UXUtility.checkNull(rs.getString("CLIENT_CODE")));
				}
				if(rs.getString("REF_NO")!=null){
				dashboardVO.setPricingRefno(UXUtility.checkNull(rs.getString("REF_NO")));
				}
				if(rs.getString("PREV_POLICY_NO")!=null){
				dashboardVO.setPreviousPolicyNo(UXUtility.checkNull(rs.getString("PREV_POLICY_NO")));
				}
				if(rs.getString("GRP_PROF_SEQ_ID")!=null){
				
					dashboardVO.setStrImageName("dotted_drop_down");
					dashboardVO.setStrImagetitle("ondropdown");
				}
				if(rs.getString("GROUP_NAME")!=null){
				dashboardVO.setGroupName(UXUtility.checkNull(rs.getString("GROUP_NAME")));
				}
				if(rs.getString("PLAN_TYPE")!=null){
					dashboardVO.setPlantype(UXUtility.checkNull(rs.getString("PLAN_TYPE")));
				}
				if(rs.getString("INITIATED_DATE")!=null){
				dashboardVO.setPricinginitiateddate(UXUtility.checkNull(rs.getString("INITIATED_DATE")));
				}
				if(rs.getString("NEW_RENW")!=null){
					dashboardVO.setClientType("");
					
					
				if ("New".equals(rs.getString("NEW_RENW"))) {
					dashboardVO.setsStatusImageName("Newimage");
					dashboardVO.setStatusImageTitle("Newimage");
				}
				if ("Renewal".equals(rs.getString("NEW_RENW"))) {
					dashboardVO.setsStatusImageName("Renewal");
					dashboardVO.setStatusImageTitle("Renewal");
					
				}
				}else {
					
					dashboardVO.setClientType("");
					dashboardVO.setsStatusImageName("");
					dashboardVO.setStatusImageTitle("");
				}
				if(rs.getString("covrg_start_date")!=null){
				dashboardVO.setCoveragestartdate(UXUtility.checkNull(rs.getString("covrg_start_date")));
				}
				if(rs.getString("covrg_end_date")!=null){
				dashboardVO.setCoverageenddate(UXUtility.checkNull(rs.getString("covrg_end_date")));
				}
				if(rs.getString("BROKER_NAME")!=null){
				dashboardVO.setBrokername(UXUtility.checkNull(rs.getString("BROKER_NAME")));
				}else {
					dashboardVO.setBrokername("NA");
				}
				if(rs.getString("apr_pend")!=null){
					
				dashboardVO.setApprpending(UXUtility.checkNull(rs.getString("apr_pend")));
			
				if("APPROVED".equals(rs.getString("apr_pend"))){
					dashboardVO.setPricingStatusImage("Approved");
					dashboardVO.setPricingStatusTittle("Approved");
				}else if ("DRAFT".equals(rs.getString("apr_pend"))){
					dashboardVO.setPricingStatusImage("Draft");
					dashboardVO.setPricingStatusTittle("Draft");
				
				}else if ("PENDING APPROVAL".equals(rs.getString("apr_pend"))) {
					dashboardVO.setPricingStatusImage("Pendingapproval");
					dashboardVO.setPricingStatusTittle("Pendingapproval");
				}else if ("IMG".equalsIgnoreCase(rs.getString("apr_pend"))) {
					
					dashboardVO.setPricingStatusImage("Grouppricing");
					dashboardVO.setPricingStatusTittle("Grouppricing");
				}
				}
				if(rs.getString("GRP_PROF_SEQ_ID")!=null)
				{
					dashboardVO.setGroupProfileSeqID(new Long(rs.getLong("GRP_PROF_SEQ_ID")));
				}
				dashboardVO.setLastModifiedBy(UXUtility.checkNull(rs.getString("last_modified_Date")));
				
				
				
				alResultList.add(dashboardVO);
				}//end of if(strIdentifier.equalsIgnoreCase("Administration"))
			
			}// End of   while (rs.next())
		 
		objects[0]=alResultList;
		objects[1]="";
				if(tableMetadataResultset != null)
				{
					tableMetadataResultset.next();
					
					objects[1]=UXUtility.checkNull(tableMetadataResultset.getString("PENDING_CNT_STR"));
				}
		
		}
	
	
	}
		return objects;		

}

	public int getDelete(ArrayList delet) throws Exception {
		ArrayList<Object> alResultList = new ArrayList<Object>();
		
		    int iResult =0;
		  //ResultSet rs = null;
		   
		
		try (Connection con = dataSource.getConnection();
				CallableStatement cStmtObject = (java.sql.CallableStatement) con.prepareCall(strSwInsuranceDelete);) {
			
			
		    cStmtObject.setLong(1,(Long) delet.get(0));
		    cStmtObject.setString(2,(String) delet.get(1));
		    cStmtObject.setLong(3,(Long) delet.get(2));
		    if(((String) delet.get(3)).contains("GRP")){
		    	 cStmtObject.setString(4,"GRP");
		    }else{
		    	 cStmtObject.setString(4,"PRC");
		    }
		    cStmtObject.registerOutParameter(5,Types.INTEGER);
		    cStmtObject.execute();
		    iResult = cStmtObject.getInt(5);
		// TODO Auto-generated method stub
		  
	}
		  return iResult;
			
	}

	@Override
	public String getClientName(String clientCode) throws Exception {
		// TODO Auto-generated method stub
		
		String result="";
		try(Connection con = dataSource.getConnection();
				PreparedStatement pStmtObject = con.prepareStatement(strUserName);){
			
			pStmtObject.setString(1,clientCode);
			
			try(ResultSet rs = pStmtObject.executeQuery();){
				if(rs != null){
					while(rs.next())
					{
						
						result=	UXUtility.checkNull(rs.getString("group_name"));
					}//end of while(rs.next())
				}
			}
			
		}
				
							       					
		return result;
	}

	@Override
	public ArrayList<InsPricingVO> groupList(ArrayList al) throws Exception {
		// TODO Auto-generated method stub
		ArrayList<InsPricingVO> groupList=new ArrayList<>();
		InsPricingVO insPricingVO=null;
		try (Connection con = dataSource.getConnection();
				CallableStatement cStmtObject = (java.sql.CallableStatement) con.prepareCall(strGroupPricingList);) {			
			
			  cStmtObject.setString(1,(String) al.get(0));
			  cStmtObject.setString(2,(String) al.get(1));
			  cStmtObject.setTimestamp(3,new Timestamp(((Date)al.get(2)).getTime()));
			  cStmtObject.setTimestamp(4,new Timestamp(((Date)al.get(3)).getTime()));	
			  
			 
			  cStmtObject.registerOutParameter(5,OracleTypes.CURSOR);
			  cStmtObject.execute(); 
			  try(ResultSet rs = (java.sql.ResultSet)cStmtObject.getObject(5);){
					if(rs != null){
						while(rs.next())
						{
							insPricingVO = new InsPricingVO();
							
							insPricingVO.setGroupProfileSeqID(rs.getLong("grp_prof_seq_id"));
							insPricingVO.setGroupRefNo(UXUtility.checkNull(rs.getString("ref_no")));
							insPricingVO.setGroupStatus(UXUtility.checkNull(rs.getString("apr_pend")));
							insPricingVO.setGroupiniatedDate(UXUtility.checkNull(rs.getString("initiated_date")));
							insPricingVO.setGroupProductName(UXUtility.checkNull(rs.getString("PLAN_TYPE")));
							insPricingVO.setGroupSelectionNo(UXUtility.checkNull(rs.getString("selection")));
							
													
							groupList.add(insPricingVO);
							
						}
					}
			  }
			  
			
		}
		return groupList;
	}

	@Override
	public ArrayList getGroupPricingDisplayList(Long grouppricingSeqid,String groupSeqId) throws Exception {
		// TODO Auto-generated method stub
		
		
		Collection<Object> alResultList = new ArrayList<Object>();
		
		Collection<Object> alGroupPicingList = new ArrayList<Object>();
		
		
		Collection<Object> alGroupPicingListCoverage1 = new ArrayList<Object>();
		Collection<Object> alGroupPicingListCoverage2 = new ArrayList<Object>();
		Collection<Object> alGroupPicingListCoverage3 = new ArrayList<Object>();
		Collection<Object> alGroupPicingListCoverage4 = new ArrayList<Object>();
		Collection<Object> alGroupPicingListCoverage5 = new ArrayList<Object>();
		Collection<Object> alGroupPicingListCoverage6 = new ArrayList<Object>();
		Collection<Object> alGroupPicingListCoverage7 = new ArrayList<Object>();
		Collection<Object> alGroupPicingListCoverage8 = new ArrayList<Object>();
		Collection<Object> alGroupPicingListCoverage9 = new ArrayList<Object>();
		Collection<Object> alGroupPicingListCoverage10 = new ArrayList<Object>();
		
		
		
	/*	Collection<Object> alGroupPicingListProvider1 = new ArrayList<Object>();
		Collection<Object> alGroupPicingListProvider2 = new ArrayList<Object>();
		Collection<Object> alGroupPicingListProvider3 = new ArrayList<Object>();
		Collection<Object> alGroupPicingListProvider4 = new ArrayList<Object>();
		Collection<Object> alGroupPicingListProvider5 = new ArrayList<Object>();
		Collection<Object> alGroupPicingListProvider6 = new ArrayList<Object>();
		Collection<Object> alGroupPicingListProvider7 = new ArrayList<Object>();
		Collection<Object> alGroupPicingListProvider8 = new ArrayList<Object>();
		Collection<Object> alGroupPicingListProvider9 = new ArrayList<Object>();
		Collection<Object> alGroupPicingListProvider10 = new ArrayList<Object>();*/
		

		/*Collection<Object> alGroupPicingListOptical1 = new ArrayList<Object>();
		Collection<Object> alGroupPicingListOptical2 = new ArrayList<Object>();
		Collection<Object> alGroupPicingListOptical3 = new ArrayList<Object>();
		Collection<Object> alGroupPicingListOptical4 = new ArrayList<Object>();
		Collection<Object> alGroupPicingListOptical5 = new ArrayList<Object>();
		Collection<Object> alGroupPicingListOptical6 = new ArrayList<Object>();
		Collection<Object> alGroupPicingListOptical7 = new ArrayList<Object>();
		Collection<Object> alGroupPicingListOptical8 = new ArrayList<Object>();
		Collection<Object> alGroupPicingListOptical9 = new ArrayList<Object>();
		Collection<Object> alGroupPicingListOptical10 = new ArrayList<Object>();*/
		
		
	/*	Collection<Object> alGroupPicingListOther1 = new ArrayList<Object>();
		Collection<Object> alGroupPicingListOther2 = new ArrayList<Object>();
		Collection<Object> alGroupPicingListOther3 = new ArrayList<Object>();
		Collection<Object> alGroupPicingListOther4 = new ArrayList<Object>();
		Collection<Object> alGroupPicingListOther5 = new ArrayList<Object>();
		Collection<Object> alGroupPicingListOther6 = new ArrayList<Object>();
		Collection<Object> alGroupPicingListOther7 = new ArrayList<Object>();
		Collection<Object> alGroupPicingListOther8 = new ArrayList<Object>();
		Collection<Object> alGroupPicingListOther9 = new ArrayList<Object>();
		Collection<Object> alGroupPicingListOther10 = new ArrayList<Object>();*/
		
		Collection<Object> alGroupPicingListExperinceSummery1 = new ArrayList<Object>();
		Collection<Object> alGroupPicingListExperinceSummery2 = new ArrayList<Object>();
		Collection<Object> alGroupPicingListExperinceSummery3 = new ArrayList<Object>();
		Collection<Object> alGroupPicingListExperinceSummery4 = new ArrayList<Object>();
		Collection<Object> alGroupPicingListExperinceSummery5 = new ArrayList<Object>();
		Collection<Object> alGroupPicingListExperinceSummery6 = new ArrayList<Object>();
		Collection<Object> alGroupPicingListExperinceSummery7 = new ArrayList<Object>();
		Collection<Object> alGroupPicingListExperinceSummery8 = new ArrayList<Object>();
		Collection<Object> alGroupPicingListExperinceSummery9 = new ArrayList<Object>();
		Collection<Object> alGroupPicingListExperinceSummery10 = new ArrayList<Object>();
		
		
		
		
		InsPricingVO insPricingVO=null;
		InsPricingVO insPricingVOCoverage1=null;
		InsPricingVO insPricingVOCoverage2 = null;
		InsPricingVO insPricingVOCoverage3 = null;
		InsPricingVO insPricingVOCoverage4 = null;
		InsPricingVO insPricingVOCoverage5 = null;
		InsPricingVO insPricingVOCoverage6 = null;
		InsPricingVO insPricingVOCoverage7 = null;
		InsPricingVO insPricingVOCoverage8 = null;
		InsPricingVO insPricingVOCoverage9 = null;
		InsPricingVO insPricingVOCoverage10 = null;
		
	/*	InsPricingVO insPricingVOProvider1=null;
		InsPricingVO insPricingVOProvider2 = null;
		InsPricingVO insPricingVOProvider3 = null;
		InsPricingVO insPricingVOProvider4 = null;
		InsPricingVO insPricingVOProvider5 = null;
		InsPricingVO insPricingVOProvider6 = null;
		InsPricingVO insPricingVOProvider7 = null;
		InsPricingVO insPricingVOProvider8 = null;
		InsPricingVO insPricingVOProvider9 = null;
		InsPricingVO insPricingVOProvider10 = null;*/
		
		
		/*InsPricingVO insPricingVOOptical1=null;
		InsPricingVO insPricingVOOptical2=null;
		InsPricingVO insPricingVOOptical3=null;
		InsPricingVO insPricingVOOptical4=null;
		InsPricingVO insPricingVOOptical5=null;
		InsPricingVO insPricingVOOptical6=null;
		InsPricingVO insPricingVOOptical7=null;
		InsPricingVO insPricingVOOptical8=null;
		InsPricingVO insPricingVOOptical9=null;
		InsPricingVO insPricingVOOptical10=null;*/
		
		
	/*	InsPricingVO insPricingVOOther1=null;
		InsPricingVO insPricingVOOther2=null;
		InsPricingVO insPricingVOOther3=null;
		InsPricingVO insPricingVOOther4=null;
		InsPricingVO insPricingVOOther5=null;
		InsPricingVO insPricingVOOther6=null;
		InsPricingVO insPricingVOOther7=null;
		InsPricingVO insPricingVOOther8=null;
		InsPricingVO insPricingVOOther9=null;
		InsPricingVO insPricingVOOther10=null;*/
		
		InsPricingVO insPricingVOExperinceSummery1=null;
		InsPricingVO insPricingVOExperinceSummery2=null;
		InsPricingVO insPricingVOExperinceSummery3=null;
		InsPricingVO insPricingVOExperinceSummery4=null;
		InsPricingVO insPricingVOExperinceSummery5=null;
		InsPricingVO insPricingVOExperinceSummery6=null;
		InsPricingVO insPricingVOExperinceSummery7=null;
		InsPricingVO insPricingVOExperinceSummery8=null;
		InsPricingVO insPricingVOExperinceSummery9=null;
		InsPricingVO insPricingVOExperinceSummery10=null;
		
	
		
		
		InsPricingVO grossPremiumMemberGroupLevel=null;
		InsPricingVO groupPolicyDuration =null;
		
	
		
		
		try (Connection con = dataSource.getConnection();
				CallableStatement cStmtObject = (java.sql.CallableStatement) con.prepareCall(strGroupPricingDisplayList);) {
			  		cStmtObject.setLong(1,grouppricingSeqid);
			  		cStmtObject.setString(2,groupSeqId);
			  		cStmtObject.registerOutParameter(3,OracleTypes.CURSOR);
			  		cStmtObject.registerOutParameter(4,OracleTypes.CURSOR);
			  		cStmtObject.registerOutParameter(5,OracleTypes.CURSOR);
			  
			  cStmtObject.execute(); 
			  
			  int i = 0;
			  try(ResultSet rs = (java.sql.ResultSet)cStmtObject.getObject(3);){
					if(rs != null){
						while(rs.next())
						{
							insPricingVO = new InsPricingVO();
							
											
							
							
							insPricingVO.setGroupProfileSeqID(rs.getLong("GRP_PROF_SEQ_ID"));
							insPricingVO.setPricingRefno(UXUtility.checkNull(rs.getString("REF_NO")));
							insPricingVO.setProductName(UXUtility.checkNull(rs.getString("product_name")));
							insPricingVO.setLoding(UXUtility.checkNull(rs.getString("prov_load_val")));
							insPricingVO.setDiscount(UXUtility.checkNull(rs.getString("prov_disc_val")));
							insPricingVO.setRevisedPremiumPerMember(UXUtility.checkNull(rs.getString("grs_premium")));
							insPricingVO.setRevisedPremiumPerMemberGroupAll(UXUtility.checkNull(rs.getString("REV_GROSS_PREMIUM")));
							insPricingVO.setTargetVal(UXUtility.checkNull(rs.getString("TARGET_PREMIUM")));
							insPricingVO.setProposedLoding(UXUtility.checkNull(rs.getString("PROP_LOD_DIS")));
							
							insPricingVO.setLdsSeqId(UXUtility.checkNull(rs.getString("LDS_SEQ_ID")));
							
						
							
							
							
							 if(i== 0) {
								 insPricingVOCoverage1 = new InsPricingVO();		
								/* insPricingVOProvider1 = new InsPricingVO();
								 insPricingVOOptical1  = new InsPricingVO();
								 insPricingVOOther1  = new InsPricingVO();*/
								 insPricingVOExperinceSummery1 = new InsPricingVO();
								 
							
								 
								 insPricingVOCoverage1.setTotalCovedLives(UXUtility.checkNull(rs.getString("tot_cov_lives")));
								 insPricingVOCoverage1.setFinalTotalLives(UXUtility.checkNull(rs.getString("TOT_LIVES")));
								 
								 insPricingVOCoverage1.setAverageAge(UXUtility.checkNull(rs.getString("avg_age")));
								 insPricingVOCoverage1.setTotalLivesMaternity(UXUtility.checkNull(rs.getString("tot_cov_lives_matrnty")));
								
								 insPricingVOCoverage1.setIpCopayListDesc(UXUtility.checkNull(rs.getString("ip_cov_yn")));
								 insPricingVOCoverage1.setOpCopayListDesc(UXUtility.checkNull(rs.getString("op_cov_yn")));
								 insPricingVOCoverage1.setMaxBeneLimitOthIp(UXUtility.checkNull(rs.getString("max_benf_limit")));
								 insPricingVOCoverage1.setAreaOfCover(UXUtility.checkNull(rs.getString("Area_of_cover")));
								 insPricingVOCoverage1.setAreaOfCoverVariations(UXUtility.checkNull(rs.getString("AREA_COV_VARIATION")));
								 insPricingVOCoverage1.setLoadingAreaListopt(UXUtility.checkNull(rs.getString("area_cov_loading")));
								 insPricingVOCoverage1.setNetworkList(UXUtility.checkNull(rs.getString("nwk_type")));
								 // after change design ................
								 insPricingVOCoverage1.setAlAhlihospital(UXUtility.checkNull(rs.getString("alahli_cover")));
								 insPricingVOCoverage1.setAdditionalHospitalCoverageList(UXUtility.checkNull(rs.getString("ADDI_HOSP_COV_NAME")));								 
								 insPricingVOCoverage1.setHospitalExclusionsList(UXUtility.checkNull(rs.getString("exclu_hosp_cov_name")));
								 insPricingVOCoverage1.setResidencyCountryList(UXUtility.checkNull(rs.getString("Residency_country")));
								 insPricingVOCoverage1.setProRATALimitApplicable(UXUtility.checkNull(rs.getString("Prorata_limits")));
								 insPricingVOCoverage1.setPremiumRefundApproach(UXUtility.checkNull(rs.getString("Premium_refund_logic")));	
								 
								 /*insPricingVOCoverage1.setOtherKeyComents(UXUtility.checkNull(rs.getString("Loading_resi_cntry")));*/
								 insPricingVOCoverage1.setOtherKeyComents(UXUtility.checkNull(rs.getString("Other_key_coments")));
								 
								 
								 insPricingVOCoverage1.setPremiumPerMember(UXUtility.checkNull(rs.getString("Premium_per_member")));
								 insPricingVOCoverage1.setProjectedLossRatio(UXUtility.checkNull(rs.getString("Projected_loss_ratio")));
								 insPricingVOCoverage1.setLoadAntiSelection(UXUtility.checkNull(rs.getString("Load_anti_selection")));
								 insPricingVOCoverage1.setBrokingCommission(UXUtility.checkNull(rs.getString("Broking_commission")));
								 insPricingVOCoverage1.setContingencyLoading(UXUtility.checkNull(rs.getString("Contingency_loading")));						         
								 insPricingVOCoverage1.setManagementDiscount(UXUtility.checkNull(rs.getString("Management_discount")));
								 insPricingVOCoverage1.setProfitMargin(UXUtility.checkNull(rs.getString("Profit_margin")));
								 insPricingVOCoverage1.setComments(UXUtility.checkNull(rs.getString("comments")));
								 insPricingVOCoverage1.setGrossPremiumMember(UXUtility.checkNull(rs.getString("Gross_premium_member")));
								 insPricingVOCoverage1.setOpticalYN(UXUtility.checkNull(rs.getString("optcl_cover")));
								 insPricingVOCoverage1.setDentalYN(UXUtility.checkNull(rs.getString("dntl_cover")));
								 insPricingVOCoverage1.setMaternityYN(UXUtility.checkNull(rs.getString("Maternity_coverage")));
								 insPricingVOCoverage1.setNatcategorylist(UXUtility.checkNull(rs.getString("nat_distr")));
								 insPricingVOCoverage1.setOverheadCost(UXUtility.checkNull(rs.getString("Overhead_cost")));
								 // close after change design ................
								 
								 
								/* insPricingVOCoverage1.setIpCopay(rs.getLong("IP_COPAY"));	
								 * 					*/		 								 
								 insPricingVOCoverage1.setIpCopayDesc(UXUtility.checkNull(rs.getString("IP_COPAY")));
					             insPricingVOCoverage1.setOpticalCopayListDesc(UXUtility.checkNull(rs.getString("opt_copay_perc")));
								 					             
					          /*   insPricingVOProvider1.setAlAhlihospital(UXUtility.checkNull(rs.getString("alahli_cover")));
					             insPricingVOProvider1.setOpCopyalahlihosp(UXUtility.checkNull(rs.getString("op_copay_alh_perc")));
					             insPricingVOProvider1.setiPCopayAtAhliListDesc(UXUtility.checkNull(rs.getString("IP_COPAY_ALH_PERC")));
					             insPricingVOProvider1.setAdditionalHospitalCoverageList(UXUtility.checkNull(rs.getString("ADDI_HOSP_COV_NAME")));
					             insPricingVOProvider1.setLoadinghospitalCoverage(rs.getLong("load_addi_hosp_cov"));
					             insPricingVOProvider1.setHospitalExclusionsList(UXUtility.checkNull(rs.getString("exclu_hosp_cov_name")));
					             */
					             
					         /*    insPricingVOOptical1.setOpticalYN(UXUtility.checkNull(rs.getString("optcl_cover")));
					             insPricingVOOptical1.setOpticalCopayList(UXUtility.checkNull(rs.getString("optical_limit")));
					             insPricingVOOptical1.setOpticalCopayListDesc(UXUtility.checkNull(rs.getString("opt_copay_perc")));
					             insPricingVOOptical1.setOpticalFrameLimitList(UXUtility.checkNull(rs.getString("frame_limit")));					             
					             insPricingVOOptical1.setDentalYN(UXUtility.checkNull(rs.getString("dntl_cover")));
					             insPricingVOOptical1.setDentalLimitList(UXUtility.checkNull(rs.getString("dntl_limit")));
					             insPricingVOOptical1.setDentalcopayList(UXUtility.checkNull(rs.getString("dent_cpy_ded")));
					             insPricingVOOptical1.setOrthodontiCscoverage(UXUtility.checkNull(rs.getString("orthod_cov")));
					             insPricingVOOptical1.setOrthodonticsCopay(UXUtility.checkNull(rs.getString("Orthod_copay")));					             
					             insPricingVOOptical1.setMaternityYN(UXUtility.checkNull(rs.getString("Maternity_coverage")));
					             insPricingVOOptical1.setMaternityLimitList(rs.getLong("Maternity_limit"));*/
					       
					           /*  insPricingVOOptical1.setMaternityCopayList(rs.getLong("Maternity_cpy_ded"));*/
					             
					           /*  
					             insPricingVOOther1.setResidencyCountryList(UXUtility.checkNull(rs.getString("Residency_country")));
					             
					             insPricingVOOther1.setLoadingResiCntry(UXUtility.checkNull(rs.getString("Loading_resi_cntry")));
					             
					             insPricingVOOther1.setOtherKeyComents(UXUtility.checkNull(rs.getString("Loading_resi_cntry")));
					             
					             insPricingVOOther1.setProRATALimitApplicable(UXUtility.checkNull(rs.getString("Prorata_limits")));
					             
					             insPricingVOOther1.setPremiumRefundApproach(UXUtility.checkNull(rs.getString("Premium_refund_logic")));	
					             
					             insPricingVOOther1.setPremiumPerMember(UXUtility.checkNull(rs.getString("Premium_per_member")));
					             
					             insPricingVOOther1.setProjectedLossRatio(UXUtility.checkNull(rs.getString("Projected_loss_ratio")));
					             
					             insPricingVOOther1.setLoadsChangesBenef(UXUtility.checkNull(rs.getString("Loads_changes_benef")));
					             insPricingVOOther1.setDiscountChangBenef(UXUtility.checkNull(rs.getString("Discount_chang_benef")));
					             
					             insPricingVOOther1.setLoadAntiSelection(UXUtility.checkNull(rs.getString("Load_anti_selection")));
					             
					             insPricingVOOther1.setBrokingCommission(UXUtility.checkNull(rs.getString("Broking_commission")));
					             insPricingVOOther1.setContingencyLoading(UXUtility.checkNull(rs.getString("Contingency_loading")));
					             insPricingVOOther1.setOverheadCost(UXUtility.checkNull(rs.getString("Overhead_cost")));
					             insPricingVOOther1.setManagementDiscount(UXUtility.checkNull(rs.getString("Management_discount")));
					             insPricingVOOther1.setProfitMargin(UXUtility.checkNull(rs.getString("Profit_margin")));
					             insPricingVOOther1.setComments(UXUtility.checkNull(rs.getString("comments")));
					             					             					        
					           
					             insPricingVOOther1.setGrossPremiumMember(UXUtility.checkNull(rs.getString("Gross_premium_member")));*/
					           
					             insPricingVOExperinceSummery1.setTotalClaimDes(UXUtility.checkNull(rs.getString("total_claims")));
					             insPricingVOExperinceSummery1.setUltimateLossDes(UXUtility.checkNull(rs.getString("ultmte_loss_grp_level")));
					             insPricingVOExperinceSummery1.setLossrationDes(UXUtility.checkNull(rs.getString("loss_ratio_grp_level")));
					             insPricingVOExperinceSummery1.setPremiumPerMemDes(UXUtility.checkNull(rs.getString("prem_mem_grp_level")));
					             					           					             					             					             					             					             
					             

							 }
							 else if(i == 1) {
								 insPricingVOCoverage2 = new InsPricingVO();
								/* insPricingVOProvider2 = new InsPricingVO();
								 insPricingVOOptical2 = new InsPricingVO();
								 insPricingVOOther2  = new InsPricingVO();*/
								 insPricingVOExperinceSummery2 = new InsPricingVO();
								 
							
								 insPricingVOCoverage2.setTotalCovedLives(UXUtility.checkNull(rs.getString("tot_cov_lives")));
								 insPricingVOCoverage2.setFinalTotalLives(UXUtility.checkNull(rs.getString("TOT_LIVES")));
								 insPricingVOCoverage2.setAverageAge(UXUtility.checkNull(rs.getString("avg_age")));
								 insPricingVOCoverage2.setTotalLivesMaternity(UXUtility.checkNull(rs.getString("tot_cov_lives_matrnty")));
								 insPricingVOCoverage2.setIpCopayListDesc(UXUtility.checkNull(rs.getString("ip_cov_yn")));
								 insPricingVOCoverage2.setOpCopayListDesc(UXUtility.checkNull(rs.getString("op_cov_yn")));
								 insPricingVOCoverage2.setMaxBeneLimitOthIp(UXUtility.checkNull(rs.getString("max_benf_limit")));
								 insPricingVOCoverage2.setAreaOfCover(UXUtility.checkNull(rs.getString("Area_of_cover")));
								 insPricingVOCoverage2.setAreaOfCoverVariations(UXUtility.checkNull(rs.getString("AREA_COV_VARIATION")));
								 insPricingVOCoverage2.setLoadingAreaListopt(UXUtility.checkNull(rs.getString("area_cov_loading")));
								 insPricingVOCoverage2.setNetworkList(UXUtility.checkNull(rs.getString("nwk_type")));
								 
								 // after change design ................
								 insPricingVOCoverage2.setAlAhlihospital(UXUtility.checkNull(rs.getString("alahli_cover")));
								 insPricingVOCoverage2.setAdditionalHospitalCoverageList(UXUtility.checkNull(rs.getString("ADDI_HOSP_COV_NAME")));								 
								 insPricingVOCoverage2.setHospitalExclusionsList(UXUtility.checkNull(rs.getString("exclu_hosp_cov_name")));
								 insPricingVOCoverage2.setResidencyCountryList(UXUtility.checkNull(rs.getString("Residency_country")));
								 insPricingVOCoverage2.setProRATALimitApplicable(UXUtility.checkNull(rs.getString("Prorata_limits")));
								 insPricingVOCoverage2.setPremiumRefundApproach(UXUtility.checkNull(rs.getString("Premium_refund_logic")));	
								/* insPricingVOCoverage2.setOtherKeyComents(UXUtility.checkNull(rs.getString("Loading_resi_cntry")));*/
								 insPricingVOCoverage2.setOtherKeyComents(UXUtility.checkNull(rs.getString("Other_key_coments")));
								 insPricingVOCoverage2.setPremiumPerMember(UXUtility.checkNull(rs.getString("Premium_per_member")));
								 insPricingVOCoverage2.setProjectedLossRatio(UXUtility.checkNull(rs.getString("Projected_loss_ratio")));
								 insPricingVOCoverage2.setLoadAntiSelection(UXUtility.checkNull(rs.getString("Load_anti_selection")));
								 insPricingVOCoverage2.setBrokingCommission(UXUtility.checkNull(rs.getString("Broking_commission")));
								 insPricingVOCoverage2.setContingencyLoading(UXUtility.checkNull(rs.getString("Contingency_loading")));						         
								 insPricingVOCoverage2.setManagementDiscount(UXUtility.checkNull(rs.getString("Management_discount")));
								 insPricingVOCoverage2.setProfitMargin(UXUtility.checkNull(rs.getString("Profit_margin")));
								 insPricingVOCoverage2.setComments(UXUtility.checkNull(rs.getString("comments")));
								 insPricingVOCoverage2.setGrossPremiumMember(UXUtility.checkNull(rs.getString("Gross_premium_member")));
								 insPricingVOCoverage2.setOpticalYN(UXUtility.checkNull(rs.getString("optcl_cover")));
								 insPricingVOCoverage2.setDentalYN(UXUtility.checkNull(rs.getString("dntl_cover")));
								 insPricingVOCoverage2.setMaternityYN(UXUtility.checkNull(rs.getString("Maternity_coverage")));
								 insPricingVOCoverage2.setNatcategorylist(UXUtility.checkNull(rs.getString("nat_distr")));
								 insPricingVOCoverage2.setOverheadCost(UXUtility.checkNull(rs.getString("Overhead_cost")));
								 // close after change design ................
								 
								 insPricingVOCoverage2.setIpCopayDesc(UXUtility.checkNull(rs.getString("IP_COPAY")));
/*								 insPricingVOCoverage2.setIpCopay(rs.getLong("IP_COPAY"));*/
								 insPricingVOCoverage2.setOpticalCopayListDesc(UXUtility.checkNull(rs.getString("opt_copay_perc")));
								 
								/* insPricingVOProvider2.setAlAhlihospital(UXUtility.checkNull(rs.getString("alahli_cover")));
								 insPricingVOProvider2.setOpCopyalahlihosp(UXUtility.checkNull(rs.getString("op_copay_alh_perc")));
								 insPricingVOProvider2.setiPCopayAtAhliListDesc(UXUtility.checkNull(rs.getString("IP_COPAY_ALH_PERC")));
								 insPricingVOProvider2.setAdditionalHospitalCoverageList(UXUtility.checkNull(rs.getString("ADDI_HOSP_COV_NAME")));
								 insPricingVOProvider2.setLoadinghospitalCoverage(rs.getLong("load_addi_hosp_cov"));
								 insPricingVOProvider2.setHospitalExclusionsList(UXUtility.checkNull(rs.getString("exclu_hosp_cov_name")));*/
								 
								 
								/* insPricingVOOptical2.setOpticalYN(UXUtility.checkNull(rs.getString("optcl_cover")));
								 insPricingVOOptical2.setOpticalCopayList(UXUtility.checkNull(rs.getString("optical_limit")));
								 insPricingVOOptical2.setOpticalCopayListDesc(UXUtility.checkNull(rs.getString("opt_copay_perc")));
								 insPricingVOOptical2.setOpticalFrameLimitList(UXUtility.checkNull(rs.getString("frame_limit")));					             
								 insPricingVOOptical2.setDentalYN(UXUtility.checkNull(rs.getString("dntl_cover")));
								 insPricingVOOptical2.setDentalLimitList(UXUtility.checkNull(rs.getString("dntl_limit")));
								 insPricingVOOptical2.setDentalcopayList(UXUtility.checkNull(rs.getString("dent_cpy_ded")));
								 insPricingVOOptical2.setOrthodontiCscoverage(UXUtility.checkNull(rs.getString("orthod_cov")));
								 insPricingVOOptical2.setOrthodonticsCopay(UXUtility.checkNull(rs.getString("Orthod_copay")));					             
								 insPricingVOOptical2.setMaternityYN(UXUtility.checkNull(rs.getString("Maternity_coverage")));
								 insPricingVOOptical2.setMaternityLimitList(rs.getLong("Maternity_limit"));*/
							
								/* insPricingVOOptical2.setMaternityCopayList(rs.getLong("Maternity_cpy_ded"));
								 */
								 
								 
							/*	 insPricingVOOther2.setResidencyCountryList(UXUtility.checkNull(rs.getString("Residency_country")));
								 insPricingVOOther2.setLoadingResiCntry(UXUtility.checkNull(rs.getString("Loading_resi_cntry")));
								 insPricingVOOther2.setOtherKeyComents(UXUtility.checkNull(rs.getString("Loading_resi_cntry")));
								 insPricingVOOther2.setProRATALimitApplicable(UXUtility.checkNull(rs.getString("Prorata_limits")));
								 insPricingVOOther2.setPremiumRefundApproach(UXUtility.checkNull(rs.getString("Premium_refund_logic")));					             
								 insPricingVOOther2.setPremiumPerMember(UXUtility.checkNull(rs.getString("Premium_per_member")));
								 insPricingVOOther2.setProjectedLossRatio(UXUtility.checkNull(rs.getString("Projected_loss_ratio")));
								 insPricingVOOther2.setLoadsChangesBenef(UXUtility.checkNull(rs.getString("Loads_changes_benef")));
								 insPricingVOOther2.setDiscountChangBenef(UXUtility.checkNull(rs.getString("Discount_chang_benef")));
								 insPricingVOOther2.setLoadAntiSelection(UXUtility.checkNull(rs.getString("Load_anti_selection")));
								 insPricingVOOther2.setBrokingCommission(UXUtility.checkNull(rs.getString("Broking_commission")));
								 insPricingVOOther2.setContingencyLoading(UXUtility.checkNull(rs.getString("Contingency_loading")));
								 insPricingVOOther2.setOverheadCost(UXUtility.checkNull(rs.getString("Overhead_cost")));
								 insPricingVOOther2.setManagementDiscount(UXUtility.checkNull(rs.getString("Management_discount")));
								 insPricingVOOther2.setProfitMargin(UXUtility.checkNull(rs.getString("Profit_margin")));
								 insPricingVOOther2.setComments(UXUtility.checkNull(rs.getString("comments")));
								 insPricingVOOther2.setGrossPremiumMember(UXUtility.checkNull(rs.getString("Gross_premium_member")));*/
								 
								/* insPricingVOExperinceSummery2.setTotalClaimDes(UXUtility.checkNull(rs.getString("total_claims")));
								 insPricingVOExperinceSummery2.setUltimateLossDes(UXUtility.checkNull(rs.getString("ultmte_loss_grp_level")));
								 insPricingVOExperinceSummery2.setLossrationDes(UXUtility.checkNull(rs.getString("loss_ratio_grp_level")));
								 insPricingVOExperinceSummery2.setPremiumPerMemDes(UXUtility.checkNull(rs.getString("prem_mem_grp_level")));*/
								 							 
							 }else if(i == 2) {
								 insPricingVOCoverage3 = new InsPricingVO();
								/* insPricingVOProvider3 = new InsPricingVO();
								 insPricingVOOptical3  = new InsPricingVO();
								 insPricingVOOther3  = new InsPricingVO();*/
								 insPricingVOExperinceSummery3 = new InsPricingVO();
							
								 insPricingVOCoverage3.setTotalCovedLives(UXUtility.checkNull(rs.getString("tot_cov_lives")));
								 insPricingVOCoverage3.setFinalTotalLives(UXUtility.checkNull(rs.getString("TOT_LIVES")));
								 insPricingVOCoverage3.setAverageAge(UXUtility.checkNull(rs.getString("avg_age")));
								 insPricingVOCoverage3.setTotalLivesMaternity(UXUtility.checkNull(rs.getString("tot_cov_lives_matrnty")));
								 insPricingVOCoverage3.setIpCopayListDesc(UXUtility.checkNull(rs.getString("ip_cov_yn")));
								 insPricingVOCoverage3.setOpCopayListDesc(UXUtility.checkNull(rs.getString("op_cov_yn")));
								 insPricingVOCoverage3.setMaxBeneLimitOthIp(UXUtility.checkNull(rs.getString("max_benf_limit")));
								 insPricingVOCoverage3.setAreaOfCover(UXUtility.checkNull(rs.getString("Area_of_cover")));
								 insPricingVOCoverage3.setAreaOfCoverVariations(UXUtility.checkNull(rs.getString("AREA_COV_VARIATION")));
								 insPricingVOCoverage3.setLoadingAreaListopt(UXUtility.checkNull(rs.getString("area_cov_loading")));
								 insPricingVOCoverage3.setNetworkList(UXUtility.checkNull(rs.getString("nwk_type")));
								 
								 // after change design ................
								 insPricingVOCoverage3.setAlAhlihospital(UXUtility.checkNull(rs.getString("alahli_cover")));
								 insPricingVOCoverage3.setAdditionalHospitalCoverageList(UXUtility.checkNull(rs.getString("ADDI_HOSP_COV_NAME")));								 
								 insPricingVOCoverage3.setHospitalExclusionsList(UXUtility.checkNull(rs.getString("exclu_hosp_cov_name")));
								 insPricingVOCoverage3.setResidencyCountryList(UXUtility.checkNull(rs.getString("Residency_country")));
								 insPricingVOCoverage3.setProRATALimitApplicable(UXUtility.checkNull(rs.getString("Prorata_limits")));
								 insPricingVOCoverage3.setPremiumRefundApproach(UXUtility.checkNull(rs.getString("Premium_refund_logic")));	
								/* insPricingVOCoverage3.setOtherKeyComents(UXUtility.checkNull(rs.getString("Loading_resi_cntry")));*/
								 insPricingVOCoverage3.setOtherKeyComents(UXUtility.checkNull(rs.getString("Other_key_coments")));
								 insPricingVOCoverage3.setPremiumPerMember(UXUtility.checkNull(rs.getString("Premium_per_member")));
								 insPricingVOCoverage3.setProjectedLossRatio(UXUtility.checkNull(rs.getString("Projected_loss_ratio")));
								 insPricingVOCoverage3.setLoadAntiSelection(UXUtility.checkNull(rs.getString("Load_anti_selection")));
								 insPricingVOCoverage3.setBrokingCommission(UXUtility.checkNull(rs.getString("Broking_commission")));
								 insPricingVOCoverage3.setContingencyLoading(UXUtility.checkNull(rs.getString("Contingency_loading")));						         
								 insPricingVOCoverage3.setManagementDiscount(UXUtility.checkNull(rs.getString("Management_discount")));
								 insPricingVOCoverage3.setProfitMargin(UXUtility.checkNull(rs.getString("Profit_margin")));
								 insPricingVOCoverage3.setComments(UXUtility.checkNull(rs.getString("comments")));
								 insPricingVOCoverage3.setGrossPremiumMember(UXUtility.checkNull(rs.getString("Gross_premium_member")));
								 insPricingVOCoverage3.setOpticalYN(UXUtility.checkNull(rs.getString("optcl_cover")));
								 insPricingVOCoverage3.setDentalYN(UXUtility.checkNull(rs.getString("dntl_cover")));
								 insPricingVOCoverage3.setMaternityYN(UXUtility.checkNull(rs.getString("Maternity_coverage")));
								 insPricingVOCoverage3.setNatcategorylist(UXUtility.checkNull(rs.getString("nat_distr")));
								 insPricingVOCoverage3.setOverheadCost(UXUtility.checkNull(rs.getString("Overhead_cost")));
								 // close after change design ................
								 
								 
							
								/* insPricingVOCoverage3.setIpCopay(rs.getLong("IP_COPAY"));*/
								 insPricingVOCoverage3.setIpCopayDesc(UXUtility.checkNull(rs.getString("IP_COPAY")));
								 
								 insPricingVOCoverage3.setOpticalCopayListDesc(UXUtility.checkNull(rs.getString("opt_copay_perc")));
								 
							/*	 insPricingVOProvider3.setAlAhlihospital(UXUtility.checkNull(rs.getString("alahli_cover")));
								 insPricingVOProvider3.setOpCopyalahlihosp(UXUtility.checkNull(rs.getString("op_copay_alh_perc")));
								 insPricingVOProvider3.setiPCopayAtAhliListDesc(UXUtility.checkNull(rs.getString("IP_COPAY_ALH_PERC")));
								 insPricingVOProvider3.setAdditionalHospitalCoverageList(UXUtility.checkNull(rs.getString("ADDI_HOSP_COV_NAME")));
								 insPricingVOProvider3.setLoadinghospitalCoverage(rs.getLong("load_addi_hosp_cov"));
								 insPricingVOProvider3.setHospitalExclusionsList(UXUtility.checkNull(rs.getString("exclu_hosp_cov_name")));*/
								 
								 
								/* insPricingVOOptical3.setOpticalYN(UXUtility.checkNull(rs.getString("optcl_cover")));
								 insPricingVOOptical3.setOpticalCopayList(UXUtility.checkNull(rs.getString("optical_limit")));
								 insPricingVOOptical3.setOpticalCopayListDesc(UXUtility.checkNull(rs.getString("opt_copay_perc")));
								 insPricingVOOptical3.setOpticalFrameLimitList(UXUtility.checkNull(rs.getString("frame_limit")));					             
								 insPricingVOOptical3.setDentalYN(UXUtility.checkNull(rs.getString("dntl_cover")));
								 insPricingVOOptical3.setDentalLimitList(UXUtility.checkNull(rs.getString("dntl_limit")));
								 insPricingVOOptical3.setDentalcopayList(UXUtility.checkNull(rs.getString("dent_cpy_ded")));
								 insPricingVOOptical3.setOrthodontiCscoverage(UXUtility.checkNull(rs.getString("orthod_cov")));
								 insPricingVOOptical3.setOrthodonticsCopay(UXUtility.checkNull(rs.getString("Orthod_copay")));					             
								 insPricingVOOptical3.setMaternityYN(UXUtility.checkNull(rs.getString("Maternity_coverage")));
								 insPricingVOOptical3.setMaternityLimitList(rs.getLong("Maternity_limit"));*/
								/* insPricingVOOptical3.setMaternityCopayList(rs.getLong("Maternity_cpy_ded"));*/
								 
								 
							/*	 insPricingVOOther3.setResidencyCountryList(UXUtility.checkNull(rs.getString("Residency_country")));
								 insPricingVOOther3.setLoadingResiCntry(UXUtility.checkNull(rs.getString("Loading_resi_cntry")));
								 insPricingVOOther3.setOtherKeyComents(UXUtility.checkNull(rs.getString("Loading_resi_cntry")));
								 insPricingVOOther3.setProRATALimitApplicable(UXUtility.checkNull(rs.getString("Prorata_limits")));
								 insPricingVOOther3.setPremiumRefundApproach(UXUtility.checkNull(rs.getString("Premium_refund_logic")));					             
								 insPricingVOOther3.setPremiumPerMember(UXUtility.checkNull(rs.getString("Premium_per_member")));
								 insPricingVOOther3.setProjectedLossRatio(UXUtility.checkNull(rs.getString("Projected_loss_ratio")));
								 insPricingVOOther3.setLoadsChangesBenef(UXUtility.checkNull(rs.getString("Loads_changes_benef")));
								 insPricingVOOther3.setDiscountChangBenef(UXUtility.checkNull(rs.getString("Discount_chang_benef")));
								 insPricingVOOther3.setLoadAntiSelection(UXUtility.checkNull(rs.getString("Load_anti_selection")));
								 insPricingVOOther3.setBrokingCommission(UXUtility.checkNull(rs.getString("Broking_commission")));
								 insPricingVOOther3.setContingencyLoading(UXUtility.checkNull(rs.getString("Contingency_loading")));
								 insPricingVOOther3.setOverheadCost(UXUtility.checkNull(rs.getString("Overhead_cost")));
								 insPricingVOOther3.setManagementDiscount(UXUtility.checkNull(rs.getString("Management_discount")));
								 insPricingVOOther3.setProfitMargin(UXUtility.checkNull(rs.getString("Profit_margin")));
								 insPricingVOOther3.setComments(UXUtility.checkNull(rs.getString("comments")));
								 insPricingVOOther3.setGrossPremiumMember(UXUtility.checkNull(rs.getString("Gross_premium_member")));*/
								 
							/*	 insPricingVOExperinceSummery3.setTotalClaimDes(UXUtility.checkNull(rs.getString("total_claims")));
								 insPricingVOExperinceSummery3.setUltimateLossDes(UXUtility.checkNull(rs.getString("ultmte_loss_grp_level")));
								 insPricingVOExperinceSummery3.setLossrationDes(UXUtility.checkNull(rs.getString("loss_ratio_grp_level")));
								 insPricingVOExperinceSummery3.setPremiumPerMemDes(UXUtility.checkNull(rs.getString("prem_mem_grp_level")));*/
								 
							 }else if (i == 3) {
								 insPricingVOCoverage4 = new InsPricingVO();
							/*	 insPricingVOProvider4 = new InsPricingVO();
								 insPricingVOOptical4  = new InsPricingVO();
								 insPricingVOOther4  = new InsPricingVO();*/
								 insPricingVOExperinceSummery4 = new InsPricingVO();
								 
								
								 insPricingVOCoverage4.setTotalCovedLives(UXUtility.checkNull(rs.getString("tot_cov_lives")));
								 insPricingVOCoverage4.setFinalTotalLives(UXUtility.checkNull(rs.getString("TOT_LIVES")));
								 insPricingVOCoverage4.setAverageAge(UXUtility.checkNull(rs.getString("avg_age")));
								 insPricingVOCoverage4.setTotalLivesMaternity(UXUtility.checkNull(rs.getString("tot_cov_lives_matrnty")));
								 insPricingVOCoverage4.setIpCopayListDesc(UXUtility.checkNull(rs.getString("ip_cov_yn")));
								 insPricingVOCoverage4.setOpCopayListDesc(UXUtility.checkNull(rs.getString("op_cov_yn")));
								 insPricingVOCoverage4.setMaxBeneLimitOthIp(UXUtility.checkNull(rs.getString("max_benf_limit")));
								 insPricingVOCoverage4.setAreaOfCover(UXUtility.checkNull(rs.getString("Area_of_cover")));
								 insPricingVOCoverage4.setAreaOfCoverVariations(UXUtility.checkNull(rs.getString("AREA_COV_VARIATION")));
								 insPricingVOCoverage4.setLoadingAreaListopt(UXUtility.checkNull(rs.getString("area_cov_loading")));
								 insPricingVOCoverage4.setNetworkList(UXUtility.checkNull(rs.getString("nwk_type")));
								 
								// after change design ................
								 insPricingVOCoverage4.setAlAhlihospital(UXUtility.checkNull(rs.getString("alahli_cover")));
								 insPricingVOCoverage4.setAdditionalHospitalCoverageList(UXUtility.checkNull(rs.getString("ADDI_HOSP_COV_NAME")));								 
								 insPricingVOCoverage4.setHospitalExclusionsList(UXUtility.checkNull(rs.getString("exclu_hosp_cov_name")));
								 insPricingVOCoverage4.setResidencyCountryList(UXUtility.checkNull(rs.getString("Residency_country")));
								 insPricingVOCoverage4.setProRATALimitApplicable(UXUtility.checkNull(rs.getString("Prorata_limits")));
								 insPricingVOCoverage4.setPremiumRefundApproach(UXUtility.checkNull(rs.getString("Premium_refund_logic")));	
								/* insPricingVOCoverage4.setOtherKeyComents(UXUtility.checkNull(rs.getString("Loading_resi_cntry")));*/
								 
								 insPricingVOCoverage4.setOtherKeyComents(UXUtility.checkNull(rs.getString("Other_key_coments")));
								 insPricingVOCoverage4.setPremiumPerMember(UXUtility.checkNull(rs.getString("Premium_per_member")));
								 insPricingVOCoverage4.setProjectedLossRatio(UXUtility.checkNull(rs.getString("Projected_loss_ratio")));
								 insPricingVOCoverage4.setLoadAntiSelection(UXUtility.checkNull(rs.getString("Load_anti_selection")));
								 insPricingVOCoverage4.setBrokingCommission(UXUtility.checkNull(rs.getString("Broking_commission")));
								 insPricingVOCoverage4.setContingencyLoading(UXUtility.checkNull(rs.getString("Contingency_loading")));						         
								 insPricingVOCoverage4.setManagementDiscount(UXUtility.checkNull(rs.getString("Management_discount")));
								 insPricingVOCoverage4.setProfitMargin(UXUtility.checkNull(rs.getString("Profit_margin")));
								 insPricingVOCoverage4.setComments(UXUtility.checkNull(rs.getString("comments")));
								 insPricingVOCoverage4.setGrossPremiumMember(UXUtility.checkNull(rs.getString("Gross_premium_member")));
								 insPricingVOCoverage4.setOpticalYN(UXUtility.checkNull(rs.getString("optcl_cover")));
								 insPricingVOCoverage4.setDentalYN(UXUtility.checkNull(rs.getString("dntl_cover")));
								 insPricingVOCoverage4.setMaternityYN(UXUtility.checkNull(rs.getString("Maternity_coverage")));
								 insPricingVOCoverage4.setNatcategorylist(UXUtility.checkNull(rs.getString("nat_distr")));
								 insPricingVOCoverage4.setOverheadCost(UXUtility.checkNull(rs.getString("Overhead_cost")));
								 // close after change design ................
								 
								 insPricingVOCoverage4.setIpCopayDesc(UXUtility.checkNull(rs.getString("IP_COPAY")));
								/* insPricingVOCoverage4.setIpCopay(rs.getLong("IP_COPAY"));*/
								 insPricingVOCoverage4.setOpticalCopayListDesc(UXUtility.checkNull(rs.getString("opt_copay_perc")));
								 
							/*	 insPricingVOProvider4.setAlAhlihospital(UXUtility.checkNull(rs.getString("alahli_cover")));
								 insPricingVOProvider4.setOpCopyalahlihosp(UXUtility.checkNull(rs.getString("op_copay_alh_perc")));
								 insPricingVOProvider4.setiPCopayAtAhliListDesc(UXUtility.checkNull(rs.getString("IP_COPAY_ALH_PERC")));
								 insPricingVOProvider4.setAdditionalHospitalCoverageList(UXUtility.checkNull(rs.getString("ADDI_HOSP_COV_NAME")));
								 insPricingVOProvider4.setLoadinghospitalCoverage(rs.getLong("load_addi_hosp_cov"));
								 insPricingVOProvider4.setHospitalExclusionsList(UXUtility.checkNull(rs.getString("exclu_hosp_cov_name")));*/
								 
								 
							/*	 insPricingVOOptical4.setOpticalYN(UXUtility.checkNull(rs.getString("optcl_cover")));
								 insPricingVOOptical4.setOpticalCopayList(UXUtility.checkNull(rs.getString("optical_limit")));
								 insPricingVOOptical4.setOpticalCopayListDesc(UXUtility.checkNull(rs.getString("opt_copay_perc")));
								 insPricingVOOptical4.setOpticalFrameLimitList(UXUtility.checkNull(rs.getString("frame_limit")));					             
								 insPricingVOOptical4.setDentalYN(UXUtility.checkNull(rs.getString("dntl_cover")));
								 insPricingVOOptical4.setDentalLimitList(UXUtility.checkNull(rs.getString("dntl_limit")));
								 insPricingVOOptical4.setDentalcopayList(UXUtility.checkNull(rs.getString("dent_cpy_ded")));
								 insPricingVOOptical4.setOrthodontiCscoverage(UXUtility.checkNull(rs.getString("orthod_cov")));
								 insPricingVOOptical4.setOrthodonticsCopay(UXUtility.checkNull(rs.getString("Orthod_copay")));					             
								 insPricingVOOptical4.setMaternityYN(UXUtility.checkNull(rs.getString("Maternity_coverage")));
								 insPricingVOOptical4.setMaternityLimitList(rs.getLong("Maternity_limit"));*/
							/*	 insPricingVOOptical4.setMaternityCopayList(rs.getLong("Maternity_cpy_ded"));*/
								 
								 
							/*	 insPricingVOOther4.setResidencyCountryList(UXUtility.checkNull(rs.getString("Residency_country")));
								 insPricingVOOther4.setLoadingResiCntry(UXUtility.checkNull(rs.getString("Loading_resi_cntry")));
								 insPricingVOOther4.setOtherKeyComents(UXUtility.checkNull(rs.getString("Loading_resi_cntry")));
								 insPricingVOOther4.setProRATALimitApplicable(UXUtility.checkNull(rs.getString("Prorata_limits")));
								 insPricingVOOther4.setPremiumRefundApproach(UXUtility.checkNull(rs.getString("Premium_refund_logic")));					             
								 insPricingVOOther4.setPremiumPerMember(UXUtility.checkNull(rs.getString("Premium_per_member")));
								 insPricingVOOther4.setProjectedLossRatio(UXUtility.checkNull(rs.getString("Projected_loss_ratio")));
								 insPricingVOOther4.setLoadsChangesBenef(UXUtility.checkNull(rs.getString("Loads_changes_benef")));
								 insPricingVOOther4.setDiscountChangBenef(UXUtility.checkNull(rs.getString("Discount_chang_benef")));
								 insPricingVOOther4.setLoadAntiSelection(UXUtility.checkNull(rs.getString("Load_anti_selection")));
								 insPricingVOOther4.setBrokingCommission(UXUtility.checkNull(rs.getString("Broking_commission")));
								 insPricingVOOther4.setContingencyLoading(UXUtility.checkNull(rs.getString("Contingency_loading")));
								 insPricingVOOther4.setOverheadCost(UXUtility.checkNull(rs.getString("Overhead_cost")));
								 insPricingVOOther4.setManagementDiscount(UXUtility.checkNull(rs.getString("Management_discount")));
								 insPricingVOOther4.setProfitMargin(UXUtility.checkNull(rs.getString("Profit_margin")));
								 insPricingVOOther4.setComments(UXUtility.checkNull(rs.getString("comments")));
								 insPricingVOOther4.setGrossPremiumMember(UXUtility.checkNull(rs.getString("Gross_premium_member")));*/
								 
								/* insPricingVOExperinceSummery4.setTotalClaimDes(UXUtility.checkNull(rs.getString("total_claims")));
								 insPricingVOExperinceSummery4.setUltimateLossDes(UXUtility.checkNull(rs.getString("ultmte_loss_grp_level")));
								 insPricingVOExperinceSummery4.setLossrationDes(UXUtility.checkNull(rs.getString("loss_ratio_grp_level")));
								 insPricingVOExperinceSummery4.setPremiumPerMemDes(UXUtility.checkNull(rs.getString("prem_mem_grp_level")));*/
								 
							 }else if(i == 4) {
								 insPricingVOCoverage5 = new InsPricingVO();
							/*	 insPricingVOProvider5 = new InsPricingVO();
								 insPricingVOOptical5  = new InsPricingVO();
								 insPricingVOOther5  = new InsPricingVO();*/
								 insPricingVOExperinceSummery5 = new InsPricingVO();
								 
								
								 insPricingVOCoverage5.setTotalCovedLives(UXUtility.checkNull(rs.getString("tot_cov_lives")));
								 insPricingVOCoverage5.setFinalTotalLives(UXUtility.checkNull(rs.getString("TOT_LIVES")));
								 insPricingVOCoverage5.setAverageAge(UXUtility.checkNull(rs.getString("avg_age")));
								 insPricingVOCoverage5.setTotalLivesMaternity(UXUtility.checkNull(rs.getString("tot_cov_lives_matrnty")));
								 insPricingVOCoverage5.setIpCopayListDesc(UXUtility.checkNull(rs.getString("ip_cov_yn")));
								 insPricingVOCoverage5.setOpCopayListDesc(UXUtility.checkNull(rs.getString("op_cov_yn")));
								 insPricingVOCoverage5.setMaxBeneLimitOthIp(UXUtility.checkNull(rs.getString("max_benf_limit")));
								 insPricingVOCoverage5.setAreaOfCover(UXUtility.checkNull(rs.getString("Area_of_cover")));
								 insPricingVOCoverage5.setAreaOfCoverVariations(UXUtility.checkNull(rs.getString("AREA_COV_VARIATION")));
								 insPricingVOCoverage5.setLoadingAreaListopt(UXUtility.checkNull(rs.getString("area_cov_loading")));
								 insPricingVOCoverage5.setNetworkList(UXUtility.checkNull(rs.getString("nwk_type")));
								 
									// after change design ................
								 insPricingVOCoverage5.setAlAhlihospital(UXUtility.checkNull(rs.getString("alahli_cover")));
								 insPricingVOCoverage5.setAdditionalHospitalCoverageList(UXUtility.checkNull(rs.getString("ADDI_HOSP_COV_NAME")));								 
								 insPricingVOCoverage5.setHospitalExclusionsList(UXUtility.checkNull(rs.getString("exclu_hosp_cov_name")));
								 insPricingVOCoverage5.setResidencyCountryList(UXUtility.checkNull(rs.getString("Residency_country")));
								 insPricingVOCoverage5.setProRATALimitApplicable(UXUtility.checkNull(rs.getString("Prorata_limits")));
								 insPricingVOCoverage5.setPremiumRefundApproach(UXUtility.checkNull(rs.getString("Premium_refund_logic")));	
								/* insPricingVOCoverage5.setOtherKeyComents(UXUtility.checkNull(rs.getString("Loading_resi_cntry")));*/
								 insPricingVOCoverage5.setOtherKeyComents(UXUtility.checkNull(rs.getString("Other_key_coments")));
								 
								 insPricingVOCoverage5.setPremiumPerMember(UXUtility.checkNull(rs.getString("Premium_per_member")));
								 insPricingVOCoverage5.setProjectedLossRatio(UXUtility.checkNull(rs.getString("Projected_loss_ratio")));
								 insPricingVOCoverage5.setLoadAntiSelection(UXUtility.checkNull(rs.getString("Load_anti_selection")));
								 insPricingVOCoverage5.setBrokingCommission(UXUtility.checkNull(rs.getString("Broking_commission")));
								 insPricingVOCoverage5.setContingencyLoading(UXUtility.checkNull(rs.getString("Contingency_loading")));						         
								 insPricingVOCoverage5.setManagementDiscount(UXUtility.checkNull(rs.getString("Management_discount")));
								 insPricingVOCoverage5.setProfitMargin(UXUtility.checkNull(rs.getString("Profit_margin")));
								 insPricingVOCoverage5.setComments(UXUtility.checkNull(rs.getString("comments")));
								 insPricingVOCoverage5.setGrossPremiumMember(UXUtility.checkNull(rs.getString("Gross_premium_member")));
								 insPricingVOCoverage5.setOpticalYN(UXUtility.checkNull(rs.getString("optcl_cover")));
								 insPricingVOCoverage5.setDentalYN(UXUtility.checkNull(rs.getString("dntl_cover")));
								 insPricingVOCoverage5.setMaternityYN(UXUtility.checkNull(rs.getString("Maternity_coverage")));
								 insPricingVOCoverage5.setNatcategorylist(UXUtility.checkNull(rs.getString("nat_distr")));
								 insPricingVOCoverage5.setOverheadCost(UXUtility.checkNull(rs.getString("Overhead_cost")));
								 // close after change design ................
								 
								 insPricingVOCoverage5.setIpCopayDesc(UXUtility.checkNull(rs.getString("IP_COPAY")));
								 /*insPricingVOCoverage5.setIpCopay(rs.getLong("IP_COPAY"));*/
								 insPricingVOCoverage5.setOpticalCopayListDesc(UXUtility.checkNull(rs.getString("opt_copay_perc")));
								 
								/* insPricingVOProvider5.setAlAhlihospital(UXUtility.checkNull(rs.getString("alahli_cover")));
								 insPricingVOProvider5.setOpCopyalahlihosp(UXUtility.checkNull(rs.getString("op_copay_alh_perc")));
								 insPricingVOProvider5.setiPCopayAtAhliListDesc(UXUtility.checkNull(rs.getString("IP_COPAY_ALH_PERC")));
								 insPricingVOProvider5.setAdditionalHospitalCoverageList(UXUtility.checkNull(rs.getString("ADDI_HOSP_COV_NAME")));
								 insPricingVOProvider5.setLoadinghospitalCoverage(rs.getLong("load_addi_hosp_cov"));
								 insPricingVOProvider5.setHospitalExclusionsList(UXUtility.checkNull(rs.getString("exclu_hosp_cov_name")));*/
								 
								 
						/*		 insPricingVOOptical5.setOpticalYN(UXUtility.checkNull(rs.getString("optcl_cover")));
								 insPricingVOOptical5.setOpticalCopayList(UXUtility.checkNull(rs.getString("optical_limit")));
								 insPricingVOOptical5.setOpticalCopayListDesc(UXUtility.checkNull(rs.getString("opt_copay_perc")));
								 insPricingVOOptical5.setOpticalFrameLimitList(UXUtility.checkNull(rs.getString("frame_limit")));					             
								 insPricingVOOptical5.setDentalYN(UXUtility.checkNull(rs.getString("dntl_cover")));
								 insPricingVOOptical5.setDentalLimitList(UXUtility.checkNull(rs.getString("dntl_limit")));
								 insPricingVOOptical5.setDentalcopayList(UXUtility.checkNull(rs.getString("dent_cpy_ded")));
								 insPricingVOOptical5.setOrthodontiCscoverage(UXUtility.checkNull(rs.getString("orthod_cov")));
								 insPricingVOOptical5.setOrthodonticsCopay(UXUtility.checkNull(rs.getString("Orthod_copay")));					             
								 insPricingVOOptical5.setMaternityYN(UXUtility.checkNull(rs.getString("Maternity_coverage")));
								 insPricingVOOptical5.setMaternityLimitList(rs.getLong("Maternity_limit"));*/
								/* insPricingVOOptical5.setMaternityCopayList(rs.getLong("Maternity_cpy_ded"));*/
								 
								 
								/* insPricingVOOther5.setResidencyCountryList(UXUtility.checkNull(rs.getString("Residency_country")));
								 insPricingVOOther5.setLoadingResiCntry(UXUtility.checkNull(rs.getString("Loading_resi_cntry")));
								 insPricingVOOther5.setOtherKeyComents(UXUtility.checkNull(rs.getString("Loading_resi_cntry")));
								 insPricingVOOther5.setProRATALimitApplicable(UXUtility.checkNull(rs.getString("Prorata_limits")));
								 insPricingVOOther5.setPremiumRefundApproach(UXUtility.checkNull(rs.getString("Premium_refund_logic")));					             
								 insPricingVOOther5.setPremiumPerMember(UXUtility.checkNull(rs.getString("Premium_per_member")));
								 insPricingVOOther5.setProjectedLossRatio(UXUtility.checkNull(rs.getString("Projected_loss_ratio")));
								 insPricingVOOther5.setLoadsChangesBenef(UXUtility.checkNull(rs.getString("Loads_changes_benef")));
								 insPricingVOOther5.setDiscountChangBenef(UXUtility.checkNull(rs.getString("Discount_chang_benef")));
								 insPricingVOOther5.setLoadAntiSelection(UXUtility.checkNull(rs.getString("Load_anti_selection")));
								 insPricingVOOther5.setBrokingCommission(UXUtility.checkNull(rs.getString("Broking_commission")));
								 insPricingVOOther5.setContingencyLoading(UXUtility.checkNull(rs.getString("Contingency_loading")));
								 insPricingVOOther5.setOverheadCost(UXUtility.checkNull(rs.getString("Overhead_cost")));
								 insPricingVOOther5.setManagementDiscount(UXUtility.checkNull(rs.getString("Management_discount")));
								 insPricingVOOther5.setProfitMargin(UXUtility.checkNull(rs.getString("Profit_margin")));
								 insPricingVOOther5.setComments(UXUtility.checkNull(rs.getString("comments")));
								 insPricingVOOther5.setGrossPremiumMember(UXUtility.checkNull(rs.getString("Gross_premium_member")));*/
								 
							/*	 insPricingVOExperinceSummery5.setTotalClaimDes(UXUtility.checkNull(rs.getString("total_claims")));
								 insPricingVOExperinceSummery5.setUltimateLossDes(UXUtility.checkNull(rs.getString("ultmte_loss_grp_level")));
								 insPricingVOExperinceSummery5.setLossrationDes(UXUtility.checkNull(rs.getString("loss_ratio_grp_level")));
								 insPricingVOExperinceSummery5.setPremiumPerMemDes(UXUtility.checkNull(rs.getString("prem_mem_grp_level")));*/
								 
							 }else if (i == 5) {
								 insPricingVOCoverage6 = new InsPricingVO();
								/* insPricingVOProvider6 = new InsPricingVO();
								 insPricingVOOptical6  = new InsPricingVO();
								 insPricingVOOther6  = new InsPricingVO();*/
								 insPricingVOExperinceSummery6 = new InsPricingVO();
								 
							
								 insPricingVOCoverage6.setTotalCovedLives(UXUtility.checkNull(rs.getString("tot_cov_lives")));
								 insPricingVOCoverage6.setFinalTotalLives(UXUtility.checkNull(rs.getString("TOT_LIVES")));
								 insPricingVOCoverage6.setAverageAge(UXUtility.checkNull(rs.getString("avg_age")));
								 insPricingVOCoverage6.setTotalLivesMaternity(UXUtility.checkNull(rs.getString("tot_cov_lives_matrnty")));
								 insPricingVOCoverage6.setIpCopayListDesc(UXUtility.checkNull(rs.getString("ip_cov_yn")));
								 insPricingVOCoverage6.setOpCopayListDesc(UXUtility.checkNull(rs.getString("op_cov_yn")));
								 insPricingVOCoverage6.setMaxBeneLimitOthIp(UXUtility.checkNull(rs.getString("max_benf_limit")));
								 insPricingVOCoverage6.setAreaOfCover(UXUtility.checkNull(rs.getString("Area_of_cover")));
								 insPricingVOCoverage6.setAreaOfCoverVariations(UXUtility.checkNull(rs.getString("AREA_COV_VARIATION")));
								 insPricingVOCoverage6.setLoadingAreaListopt(UXUtility.checkNull(rs.getString("area_cov_loading")));
								 insPricingVOCoverage6.setNetworkList(UXUtility.checkNull(rs.getString("nwk_type")));
									// after change design ................
								 insPricingVOCoverage6.setAlAhlihospital(UXUtility.checkNull(rs.getString("alahli_cover")));
								 insPricingVOCoverage6.setAdditionalHospitalCoverageList(UXUtility.checkNull(rs.getString("ADDI_HOSP_COV_NAME")));								 
								 insPricingVOCoverage6.setHospitalExclusionsList(UXUtility.checkNull(rs.getString("exclu_hosp_cov_name")));
								 insPricingVOCoverage6.setResidencyCountryList(UXUtility.checkNull(rs.getString("Residency_country")));
								 insPricingVOCoverage6.setProRATALimitApplicable(UXUtility.checkNull(rs.getString("Prorata_limits")));
								 insPricingVOCoverage6.setPremiumRefundApproach(UXUtility.checkNull(rs.getString("Premium_refund_logic")));	
								/* insPricingVOCoverage6.setOtherKeyComents(UXUtility.checkNull(rs.getString("Loading_resi_cntry")));*/
								 insPricingVOCoverage6.setOtherKeyComents(UXUtility.checkNull(rs.getString("Other_key_coments")));
								 insPricingVOCoverage6.setPremiumPerMember(UXUtility.checkNull(rs.getString("Premium_per_member")));
								 insPricingVOCoverage6.setProjectedLossRatio(UXUtility.checkNull(rs.getString("Projected_loss_ratio")));
								 insPricingVOCoverage6.setLoadAntiSelection(UXUtility.checkNull(rs.getString("Load_anti_selection")));
								 insPricingVOCoverage6.setBrokingCommission(UXUtility.checkNull(rs.getString("Broking_commission")));
								 insPricingVOCoverage6.setContingencyLoading(UXUtility.checkNull(rs.getString("Contingency_loading")));						         
								 insPricingVOCoverage6.setManagementDiscount(UXUtility.checkNull(rs.getString("Management_discount")));
								 insPricingVOCoverage6.setProfitMargin(UXUtility.checkNull(rs.getString("Profit_margin")));
								 insPricingVOCoverage6.setComments(UXUtility.checkNull(rs.getString("comments")));
								 insPricingVOCoverage6.setGrossPremiumMember(UXUtility.checkNull(rs.getString("Gross_premium_member")));
								 insPricingVOCoverage6.setOpticalYN(UXUtility.checkNull(rs.getString("optcl_cover")));
								 insPricingVOCoverage6.setDentalYN(UXUtility.checkNull(rs.getString("dntl_cover")));
								 insPricingVOCoverage6.setMaternityYN(UXUtility.checkNull(rs.getString("Maternity_coverage")));
								 insPricingVOCoverage6.setNatcategorylist(UXUtility.checkNull(rs.getString("nat_distr")));
								 insPricingVOCoverage6.setOverheadCost(UXUtility.checkNull(rs.getString("Overhead_cost")));
								 // close after change design ................
								 
							/*	 insPricingVOCoverage6.setIpCopay(rs.getLong("IP_COPAY"));*/
								 insPricingVOCoverage6.setIpCopayDesc(UXUtility.checkNull(rs.getString("IP_COPAY")));
								 insPricingVOCoverage6.setOpticalCopayListDesc(UXUtility.checkNull(rs.getString("opt_copay_perc")));
								 
								 
								/* insPricingVOProvider6.setAlAhlihospital(UXUtility.checkNull(rs.getString("alahli_cover")));
								 insPricingVOProvider6.setOpCopyalahlihosp(UXUtility.checkNull(rs.getString("op_copay_alh_perc")));
								 insPricingVOProvider6.setiPCopayAtAhliListDesc(UXUtility.checkNull(rs.getString("IP_COPAY_ALH_PERC")));
								 insPricingVOProvider6.setAdditionalHospitalCoverageList(UXUtility.checkNull(rs.getString("ADDI_HOSP_COV_NAME")));
								 insPricingVOProvider6.setLoadinghospitalCoverage(rs.getLong("load_addi_hosp_cov"));
								 insPricingVOProvider6.setHospitalExclusionsList(UXUtility.checkNull(rs.getString("exclu_hosp_cov_name")));*/
								 
							/*	 insPricingVOOptical6.setOpticalYN(UXUtility.checkNull(rs.getString("optcl_cover")));
								 insPricingVOOptical6.setOpticalCopayList(UXUtility.checkNull(rs.getString("optical_limit")));
								 insPricingVOOptical6.setOpticalCopayListDesc(UXUtility.checkNull(rs.getString("opt_copay_perc")));
								 insPricingVOOptical6.setOpticalFrameLimitList(UXUtility.checkNull(rs.getString("frame_limit")));					             
								 insPricingVOOptical6.setDentalYN(UXUtility.checkNull(rs.getString("dntl_cover")));
								 insPricingVOOptical6.setDentalLimitList(UXUtility.checkNull(rs.getString("dntl_limit")));
								 insPricingVOOptical6.setDentalcopayList(UXUtility.checkNull(rs.getString("dent_cpy_ded")));
								 insPricingVOOptical6.setOrthodontiCscoverage(UXUtility.checkNull(rs.getString("orthod_cov")));
								 insPricingVOOptical6.setOrthodonticsCopay(UXUtility.checkNull(rs.getString("Orthod_copay")));					             
								 insPricingVOOptical6.setMaternityYN(UXUtility.checkNull(rs.getString("Maternity_coverage")));
								 insPricingVOOptical6.setMaternityLimitList(rs.getLong("Maternity_limit"));*/
								/* insPricingVOOptical6.setMaternityCopayList(rs.getLong("Maternity_cpy_ded"));*/
								 
								 
							/*	 insPricingVOOther6.setResidencyCountryList(UXUtility.checkNull(rs.getString("Residency_country")));
								 insPricingVOOther6.setLoadingResiCntry(UXUtility.checkNull(rs.getString("Loading_resi_cntry")));
								 insPricingVOOther6.setOtherKeyComents(UXUtility.checkNull(rs.getString("Loading_resi_cntry")));
								 insPricingVOOther6.setProRATALimitApplicable(UXUtility.checkNull(rs.getString("Prorata_limits")));
								 insPricingVOOther6.setPremiumRefundApproach(UXUtility.checkNull(rs.getString("Premium_refund_logic")));					             
								 insPricingVOOther6.setPremiumPerMember(UXUtility.checkNull(rs.getString("Premium_per_member")));
								 insPricingVOOther6.setProjectedLossRatio(UXUtility.checkNull(rs.getString("Projected_loss_ratio")));
								 insPricingVOOther6.setLoadsChangesBenef(UXUtility.checkNull(rs.getString("Loads_changes_benef")));
								 insPricingVOOther6.setDiscountChangBenef(UXUtility.checkNull(rs.getString("Discount_chang_benef")));
								 insPricingVOOther6.setLoadAntiSelection(UXUtility.checkNull(rs.getString("Load_anti_selection")));
								 insPricingVOOther6.setBrokingCommission(UXUtility.checkNull(rs.getString("Broking_commission")));
								 insPricingVOOther6.setContingencyLoading(UXUtility.checkNull(rs.getString("Contingency_loading")));
								 insPricingVOOther6.setOverheadCost(UXUtility.checkNull(rs.getString("Overhead_cost")));
								 insPricingVOOther6.setManagementDiscount(UXUtility.checkNull(rs.getString("Management_discount")));
								 insPricingVOOther6.setProfitMargin(UXUtility.checkNull(rs.getString("Profit_margin")));
								 insPricingVOOther6.setComments(UXUtility.checkNull(rs.getString("comments")));
								 insPricingVOOther6.setGrossPremiumMember(UXUtility.checkNull(rs.getString("Gross_premium_member")));
								 */
								/* insPricingVOExperinceSummery6.setTotalClaimDes(UXUtility.checkNull(rs.getString("total_claims")));
								 insPricingVOExperinceSummery6.setUltimateLossDes(UXUtility.checkNull(rs.getString("ultmte_loss_grp_level")));
								 insPricingVOExperinceSummery6.setLossrationDes(UXUtility.checkNull(rs.getString("loss_ratio_grp_level")));
								 insPricingVOExperinceSummery6.setPremiumPerMemDes(UXUtility.checkNull(rs.getString("prem_mem_grp_level")));*/
								 
							 } else if (i == 6) {
								 insPricingVOCoverage7 = new InsPricingVO();
								 
								/* insPricingVOProvider7 = new InsPricingVO();
								 insPricingVOOptical7  = new InsPricingVO();
								 insPricingVOOther7  = new InsPricingVO();*/
								 insPricingVOExperinceSummery7 = new InsPricingVO();
								 
								
								 insPricingVOCoverage7.setTotalCovedLives(UXUtility.checkNull(rs.getString("tot_cov_lives")));
								 insPricingVOCoverage7.setFinalTotalLives(UXUtility.checkNull(rs.getString("TOT_LIVES")));
								 insPricingVOCoverage7.setAverageAge(UXUtility.checkNull(rs.getString("avg_age")));
								 insPricingVOCoverage7.setTotalLivesMaternity(UXUtility.checkNull(rs.getString("tot_cov_lives_matrnty")));
								 insPricingVOCoverage7.setIpCopayListDesc(UXUtility.checkNull(rs.getString("ip_cov_yn")));
								 insPricingVOCoverage7.setOpCopayListDesc(UXUtility.checkNull(rs.getString("op_cov_yn")));
								 insPricingVOCoverage7.setMaxBeneLimitOthIp(UXUtility.checkNull(rs.getString("max_benf_limit")));
								 insPricingVOCoverage7.setAreaOfCover(UXUtility.checkNull(rs.getString("Area_of_cover")));
								 insPricingVOCoverage7.setAreaOfCoverVariations(UXUtility.checkNull(rs.getString("AREA_COV_VARIATION")));
								 insPricingVOCoverage7.setLoadingAreaListopt(UXUtility.checkNull(rs.getString("area_cov_loading")));
								 insPricingVOCoverage7.setNetworkList(UXUtility.checkNull(rs.getString("nwk_type")));
								/* insPricingVOCoverage7.setIpCopay(rs.getLong("IP_COPAY"));*/
								 insPricingVOCoverage7.setIpCopayDesc(UXUtility.checkNull(rs.getString("IP_COPAY")));
								 insPricingVOCoverage7.setOpticalCopayListDesc(UXUtility.checkNull(rs.getString("opt_copay_perc")));
								/* 
								 insPricingVOProvider7.setAlAhlihospital(UXUtility.checkNull(rs.getString("alahli_cover")));
								 insPricingVOProvider7.setOpCopyalahlihosp(UXUtility.checkNull(rs.getString("op_copay_alh_perc")));
								 insPricingVOProvider7.setiPCopayAtAhliListDesc(UXUtility.checkNull(rs.getString("IP_COPAY_ALH_PERC")));
								 insPricingVOProvider7.setAdditionalHospitalCoverageList(UXUtility.checkNull(rs.getString("ADDI_HOSP_COV_NAME")));
								 insPricingVOProvider7.setLoadinghospitalCoverage(rs.getLong("load_addi_hosp_cov"));
								 insPricingVOProvider7.setHospitalExclusionsList(UXUtility.checkNull(rs.getString("exclu_hosp_cov_name")));
								 */
								 
								/* insPricingVOOptical7.setOpticalYN(UXUtility.checkNull(rs.getString("optcl_cover")));
								 insPricingVOOptical7.setOpticalCopayList(UXUtility.checkNull(rs.getString("optical_limit")));
								 insPricingVOOptical7.setOpticalCopayListDesc(UXUtility.checkNull(rs.getString("opt_copay_perc")));
								 insPricingVOOptical7.setOpticalFrameLimitList(UXUtility.checkNull(rs.getString("frame_limit")));					             
								 insPricingVOOptical7.setDentalYN(UXUtility.checkNull(rs.getString("dntl_cover")));
								 insPricingVOOptical7.setDentalLimitList(UXUtility.checkNull(rs.getString("dntl_limit")));
								 insPricingVOOptical7.setDentalcopayList(UXUtility.checkNull(rs.getString("dent_cpy_ded")));
								 insPricingVOOptical7.setOrthodontiCscoverage(UXUtility.checkNull(rs.getString("orthod_cov")));
								 insPricingVOOptical7.setOrthodonticsCopay(UXUtility.checkNull(rs.getString("Orthod_copay")));					             
								 insPricingVOOptical7.setMaternityYN(UXUtility.checkNull(rs.getString("Maternity_coverage")));
								 insPricingVOOptical7.setMaternityLimitList(rs.getLong("Maternity_limit"));*/
								/* insPricingVOOptical7.setMaternityCopayList(rs.getLong("Maternity_cpy_ded"));*/
								 
								 
								/* insPricingVOOther7.setResidencyCountryList(UXUtility.checkNull(rs.getString("Residency_country")));
								 insPricingVOOther7.setLoadingResiCntry(UXUtility.checkNull(rs.getString("Loading_resi_cntry")));
								 insPricingVOOther7.setOtherKeyComents(UXUtility.checkNull(rs.getString("Loading_resi_cntry")));
								 insPricingVOOther7.setProRATALimitApplicable(UXUtility.checkNull(rs.getString("Prorata_limits")));
								 insPricingVOOther7.setPremiumRefundApproach(UXUtility.checkNull(rs.getString("Premium_refund_logic")));					             
								 insPricingVOOther7.setPremiumPerMember(UXUtility.checkNull(rs.getString("Premium_per_member")));
								 insPricingVOOther7.setProjectedLossRatio(UXUtility.checkNull(rs.getString("Projected_loss_ratio")));
								 insPricingVOOther7.setLoadsChangesBenef(UXUtility.checkNull(rs.getString("Loads_changes_benef")));
								 insPricingVOOther7.setDiscountChangBenef(UXUtility.checkNull(rs.getString("Discount_chang_benef")));
								 insPricingVOOther7.setLoadAntiSelection(UXUtility.checkNull(rs.getString("Load_anti_selection")));
								 insPricingVOOther7.setBrokingCommission(UXUtility.checkNull(rs.getString("Broking_commission")));
								 insPricingVOOther7.setContingencyLoading(UXUtility.checkNull(rs.getString("Contingency_loading")));
								 insPricingVOOther7.setOverheadCost(UXUtility.checkNull(rs.getString("Overhead_cost")));
								 insPricingVOOther7.setManagementDiscount(UXUtility.checkNull(rs.getString("Management_discount")));
								 insPricingVOOther7.setProfitMargin(UXUtility.checkNull(rs.getString("Profit_margin")));
								 insPricingVOOther7.setComments(UXUtility.checkNull(rs.getString("comments")));
								 insPricingVOOther7.setGrossPremiumMember(UXUtility.checkNull(rs.getString("Gross_premium_member")));*/
								 
							/*	 insPricingVOExperinceSummery7.setTotalClaimDes(UXUtility.checkNull(rs.getString("total_claims")));
								 insPricingVOExperinceSummery7.setUltimateLossDes(UXUtility.checkNull(rs.getString("ultmte_loss_grp_level")));
								 insPricingVOExperinceSummery7.setLossrationDes(UXUtility.checkNull(rs.getString("loss_ratio_grp_level")));
								 insPricingVOExperinceSummery7.setPremiumPerMemDes(UXUtility.checkNull(rs.getString("prem_mem_grp_level")));*/
								 
								 
							 } else if (i == 7) {
								 
								 insPricingVOCoverage8 = new InsPricingVO();
							/*	 insPricingVOProvider8 = new InsPricingVO();
								 insPricingVOOptical8  = new InsPricingVO();
								 insPricingVOOther8  = new InsPricingVO();*/
								 insPricingVOExperinceSummery8 = new InsPricingVO();
								 
								
								 insPricingVOCoverage8.setTotalCovedLives(UXUtility.checkNull(rs.getString("tot_cov_lives")));
								 insPricingVOCoverage8.setFinalTotalLives(UXUtility.checkNull(rs.getString("TOT_LIVES")));
								 insPricingVOCoverage8.setAverageAge(UXUtility.checkNull(rs.getString("avg_age")));
								 insPricingVOCoverage8.setTotalLivesMaternity(UXUtility.checkNull(rs.getString("tot_cov_lives_matrnty")));
								 insPricingVOCoverage8.setIpCopayListDesc(UXUtility.checkNull(rs.getString("ip_cov_yn")));
								 insPricingVOCoverage8.setOpCopayListDesc(UXUtility.checkNull(rs.getString("op_cov_yn")));
								 insPricingVOCoverage8.setMaxBeneLimitOthIp(UXUtility.checkNull(rs.getString("max_benf_limit")));
								 insPricingVOCoverage8.setAreaOfCover(UXUtility.checkNull(rs.getString("Area_of_cover")));
								 insPricingVOCoverage8.setAreaOfCoverVariations(UXUtility.checkNull(rs.getString("AREA_COV_VARIATION")));
								 insPricingVOCoverage8.setLoadingAreaListopt(UXUtility.checkNull(rs.getString("area_cov_loading")));
								 insPricingVOCoverage8.setNetworkList(UXUtility.checkNull(rs.getString("nwk_type")));
							/*	 insPricingVOCoverage8.setIpCopay(rs.getLong("IP_COPAY"));*/
								 insPricingVOCoverage8.setIpCopayDesc(UXUtility.checkNull(rs.getString("IP_COPAY")));
								 insPricingVOCoverage8.setOpticalCopayListDesc(UXUtility.checkNull(rs.getString("opt_copay_perc")));
								 /*
								 insPricingVOProvider8.setAlAhlihospital(UXUtility.checkNull(rs.getString("alahli_cover")));
								 insPricingVOProvider8.setOpCopyalahlihosp(UXUtility.checkNull(rs.getString("op_copay_alh_perc")));
								 insPricingVOProvider8.setiPCopayAtAhliListDesc(UXUtility.checkNull(rs.getString("IP_COPAY_ALH_PERC")));
								 insPricingVOProvider8.setAdditionalHospitalCoverageList(UXUtility.checkNull(rs.getString("ADDI_HOSP_COV_NAME")));
								 insPricingVOProvider8.setLoadinghospitalCoverage(rs.getLong("load_addi_hosp_cov"));
								 insPricingVOProvider8.setHospitalExclusionsList(UXUtility.checkNull(rs.getString("exclu_hosp_cov_name")));*/
								 
								 
								 
							/*	 insPricingVOOptical8.setOpticalYN(UXUtility.checkNull(rs.getString("optcl_cover")));
								 insPricingVOOptical8.setOpticalCopayList(UXUtility.checkNull(rs.getString("optical_limit")));
								 insPricingVOOptical8.setOpticalCopayListDesc(UXUtility.checkNull(rs.getString("opt_copay_perc")));
								 insPricingVOOptical8.setOpticalFrameLimitList(UXUtility.checkNull(rs.getString("frame_limit")));					             
								 insPricingVOOptical8.setDentalYN(UXUtility.checkNull(rs.getString("dntl_cover")));
								 insPricingVOOptical8.setDentalLimitList(UXUtility.checkNull(rs.getString("dntl_limit")));
								 insPricingVOOptical8.setDentalcopayList(UXUtility.checkNull(rs.getString("dent_cpy_ded")));
								 insPricingVOOptical8.setOrthodontiCscoverage(UXUtility.checkNull(rs.getString("orthod_cov")));
								 insPricingVOOptical8.setOrthodonticsCopay(UXUtility.checkNull(rs.getString("Orthod_copay")));					             
								 insPricingVOOptical8.setMaternityYN(UXUtility.checkNull(rs.getString("Maternity_coverage")));
								 insPricingVOOptical8.setMaternityLimitList(rs.getLong("Maternity_limit"));*/
								/* insPricingVOOptical8.setMaternityCopayList(rs.getLong("Maternity_cpy_ded"));*/
								 
								 
								/* insPricingVOOther8.setResidencyCountryList(UXUtility.checkNull(rs.getString("Residency_country")));
								 insPricingVOOther8.setLoadingResiCntry(UXUtility.checkNull(rs.getString("Loading_resi_cntry")));
								 insPricingVOOther8.setOtherKeyComents(UXUtility.checkNull(rs.getString("Loading_resi_cntry")));
								 insPricingVOOther8.setProRATALimitApplicable(UXUtility.checkNull(rs.getString("Prorata_limits")));
								 insPricingVOOther8.setPremiumRefundApproach(UXUtility.checkNull(rs.getString("Premium_refund_logic")));					             
								 insPricingVOOther8.setPremiumPerMember(UXUtility.checkNull(rs.getString("Premium_per_member")));
								 insPricingVOOther8.setProjectedLossRatio(UXUtility.checkNull(rs.getString("Projected_loss_ratio")));
								 insPricingVOOther8.setLoadsChangesBenef(UXUtility.checkNull(rs.getString("Loads_changes_benef")));
								 insPricingVOOther8.setDiscountChangBenef(UXUtility.checkNull(rs.getString("Discount_chang_benef")));
								 insPricingVOOther8.setLoadAntiSelection(UXUtility.checkNull(rs.getString("Load_anti_selection")));
								 insPricingVOOther8.setBrokingCommission(UXUtility.checkNull(rs.getString("Broking_commission")));
								 insPricingVOOther8.setContingencyLoading(UXUtility.checkNull(rs.getString("Contingency_loading")));
								 insPricingVOOther8.setOverheadCost(UXUtility.checkNull(rs.getString("Overhead_cost")));
								 insPricingVOOther8.setManagementDiscount(UXUtility.checkNull(rs.getString("Management_discount")));
								 insPricingVOOther8.setProfitMargin(UXUtility.checkNull(rs.getString("Profit_margin")));
								 insPricingVOOther8.setComments(UXUtility.checkNull(rs.getString("comments")));
								 insPricingVOOther8.setGrossPremiumMember(UXUtility.checkNull(rs.getString("Gross_premium_member")));*/
								 
								/* insPricingVOExperinceSummery8.setTotalClaimDes(UXUtility.checkNull(rs.getString("total_claims")));
								 insPricingVOExperinceSummery8.setUltimateLossDes(UXUtility.checkNull(rs.getString("ultmte_loss_grp_level")));
								 insPricingVOExperinceSummery8.setLossrationDes(UXUtility.checkNull(rs.getString("loss_ratio_grp_level")));
								 insPricingVOExperinceSummery8.setPremiumPerMemDes(UXUtility.checkNull(rs.getString("prem_mem_grp_level")));*/
								 
							 }else if (i == 8) {
								 insPricingVOCoverage9 = new InsPricingVO();
								/* insPricingVOProvider9 = new InsPricingVO();
								 insPricingVOOptical9  = new InsPricingVO();
								 insPricingVOOther9  = new InsPricingVO();*/
								 insPricingVOExperinceSummery9 = new InsPricingVO();
								 
								
								 insPricingVOCoverage9.setTotalCovedLives(UXUtility.checkNull(rs.getString("tot_cov_lives")));
								 insPricingVOCoverage9.setFinalTotalLives(UXUtility.checkNull(rs.getString("TOT_LIVES")));
								 insPricingVOCoverage9.setAverageAge(UXUtility.checkNull(rs.getString("avg_age")));
								 insPricingVOCoverage9.setTotalLivesMaternity(UXUtility.checkNull(rs.getString("tot_cov_lives_matrnty")));
								 insPricingVOCoverage9.setIpCopayListDesc(UXUtility.checkNull(rs.getString("ip_cov_yn")));
								 insPricingVOCoverage9.setOpCopayListDesc(UXUtility.checkNull(rs.getString("op_cov_yn")));
								 insPricingVOCoverage9.setMaxBeneLimitOthIp(UXUtility.checkNull(rs.getString("max_benf_limit")));
								 insPricingVOCoverage9.setAreaOfCover(UXUtility.checkNull(rs.getString("Area_of_cover")));
								 insPricingVOCoverage9.setAreaOfCoverVariations(UXUtility.checkNull(rs.getString("AREA_COV_VARIATION")));
								 insPricingVOCoverage9.setLoadingAreaListopt(UXUtility.checkNull(rs.getString("area_cov_loading")));
								 insPricingVOCoverage9.setNetworkList(UXUtility.checkNull(rs.getString("nwk_type")));
							/*	 insPricingVOCoverage9.setIpCopay(rs.getLong("IP_COPAY"));*/
								 insPricingVOCoverage9.setIpCopayDesc(UXUtility.checkNull(rs.getString("IP_COPAY")));
								 insPricingVOCoverage9.setOpticalCopayListDesc(UXUtility.checkNull(rs.getString("opt_copay_perc")));
								 
								/* 
								 insPricingVOProvider9.setAlAhlihospital(UXUtility.checkNull(rs.getString("alahli_cover")));
								 insPricingVOProvider9.setOpCopyalahlihosp(UXUtility.checkNull(rs.getString("op_copay_alh_perc")));
								 insPricingVOProvider9.setiPCopayAtAhliListDesc(UXUtility.checkNull(rs.getString("IP_COPAY_ALH_PERC")));
								 insPricingVOProvider9.setAdditionalHospitalCoverageList(UXUtility.checkNull(rs.getString("ADDI_HOSP_COV_NAME")));
								 insPricingVOProvider9.setLoadinghospitalCoverage(rs.getLong("load_addi_hosp_cov"));
								 insPricingVOProvider9.setHospitalExclusionsList(UXUtility.checkNull(rs.getString("exclu_hosp_cov_name")));*/
								 
								 
								 
								/* insPricingVOOptical9.setOpticalYN(UXUtility.checkNull(rs.getString("optcl_cover")));
								 insPricingVOOptical9.setOpticalCopayList(UXUtility.checkNull(rs.getString("optical_limit")));
								 insPricingVOOptical9.setOpticalCopayListDesc(UXUtility.checkNull(rs.getString("opt_copay_perc")));
								 insPricingVOOptical9.setOpticalFrameLimitList(UXUtility.checkNull(rs.getString("frame_limit")));					             
								 insPricingVOOptical9.setDentalYN(UXUtility.checkNull(rs.getString("dntl_cover")));
								 insPricingVOOptical9.setDentalLimitList(UXUtility.checkNull(rs.getString("dntl_limit")));
								 insPricingVOOptical9.setDentalcopayList(UXUtility.checkNull(rs.getString("dent_cpy_ded")));
								 insPricingVOOptical9.setOrthodontiCscoverage(UXUtility.checkNull(rs.getString("orthod_cov")));
								 insPricingVOOptical9.setOrthodonticsCopay(UXUtility.checkNull(rs.getString("Orthod_copay")));					             
								 insPricingVOOptical9.setMaternityYN(UXUtility.checkNull(rs.getString("Maternity_coverage")));
								 insPricingVOOptical9.setMaternityLimitList(rs.getLong("Maternity_limit"));*/
								/* insPricingVOOptical9.setMaternityCopayList(rs.getLong("Maternity_cpy_ded"));
								 */
								 
							/*	 insPricingVOOther9.setResidencyCountryList(UXUtility.checkNull(rs.getString("Residency_country")));
								 insPricingVOOther9.setLoadingResiCntry(UXUtility.checkNull(rs.getString("Loading_resi_cntry")));
								 insPricingVOOther9.setOtherKeyComents(UXUtility.checkNull(rs.getString("Loading_resi_cntry")));
								 insPricingVOOther9.setProRATALimitApplicable(UXUtility.checkNull(rs.getString("Prorata_limits")));
								 insPricingVOOther9.setPremiumRefundApproach(UXUtility.checkNull(rs.getString("Premium_refund_logic")));					             
								 insPricingVOOther9.setPremiumPerMember(UXUtility.checkNull(rs.getString("Premium_per_member")));
								 insPricingVOOther9.setProjectedLossRatio(UXUtility.checkNull(rs.getString("Projected_loss_ratio")));
								 insPricingVOOther9.setLoadsChangesBenef(UXUtility.checkNull(rs.getString("Loads_changes_benef")));
								 insPricingVOOther9.setDiscountChangBenef(UXUtility.checkNull(rs.getString("Discount_chang_benef")));
								 insPricingVOOther9.setLoadAntiSelection(UXUtility.checkNull(rs.getString("Load_anti_selection")));
								 insPricingVOOther9.setBrokingCommission(UXUtility.checkNull(rs.getString("Broking_commission")));
								 insPricingVOOther9.setContingencyLoading(UXUtility.checkNull(rs.getString("Contingency_loading")));
								 insPricingVOOther9.setOverheadCost(UXUtility.checkNull(rs.getString("Overhead_cost")));
								 insPricingVOOther9.setManagementDiscount(UXUtility.checkNull(rs.getString("Management_discount")));
								 insPricingVOOther9.setProfitMargin(UXUtility.checkNull(rs.getString("Profit_margin")));
								 insPricingVOOther9.setComments(UXUtility.checkNull(rs.getString("comments")));
								 insPricingVOOther9.setGrossPremiumMember(UXUtility.checkNull(rs.getString("Gross_premium_member")));*/
								 
								/* insPricingVOExperinceSummery9.setTotalClaimDes(UXUtility.checkNull(rs.getString("total_claims")));
								 insPricingVOExperinceSummery9.setUltimateLossDes(UXUtility.checkNull(rs.getString("ultmte_loss_grp_level")));
								 insPricingVOExperinceSummery9.setLossrationDes(UXUtility.checkNull(rs.getString("loss_ratio_grp_level")));
								 insPricingVOExperinceSummery9.setPremiumPerMemDes(UXUtility.checkNull(rs.getString("prem_mem_grp_level")));*/
								 
								 
							 }else if(i == 9) {
								 insPricingVOCoverage10 = new InsPricingVO();
								/* insPricingVOProvider10 = new InsPricingVO();
								 insPricingVOOptical10  = new InsPricingVO();
								 insPricingVOOther10  = new InsPricingVO();*/
								 insPricingVOExperinceSummery10 = new InsPricingVO();
								 
								
								 insPricingVOCoverage10.setTotalCovedLives(UXUtility.checkNull(rs.getString("tot_cov_lives")));
								 insPricingVOCoverage10.setFinalTotalLives(UXUtility.checkNull(rs.getString("TOT_LIVES")));
								 insPricingVOCoverage10.setAverageAge(UXUtility.checkNull(rs.getString("avg_age")));
								 insPricingVOCoverage9.setTotalLivesMaternity(UXUtility.checkNull(rs.getString("tot_cov_lives_matrnty")));
								 insPricingVOCoverage10.setIpCopayListDesc(UXUtility.checkNull(rs.getString("ip_cov_yn")));
								 insPricingVOCoverage10.setOpCopayListDesc(UXUtility.checkNull(rs.getString("op_cov_yn")));
								 insPricingVOCoverage10.setMaxBeneLimitOthIp(UXUtility.checkNull(rs.getString("max_benf_limit")));
								 insPricingVOCoverage10.setAreaOfCover(UXUtility.checkNull(rs.getString("Area_of_cover")));
								 insPricingVOCoverage10.setAreaOfCoverVariations(UXUtility.checkNull(rs.getString("AREA_COV_VARIATION")));
								 insPricingVOCoverage10.setLoadingAreaListopt(UXUtility.checkNull(rs.getString("area_cov_loading")));
								 insPricingVOCoverage10.setNetworkList(UXUtility.checkNull(rs.getString("nwk_type")));
							/*	 insPricingVOCoverage10.setIpCopay(rs.getLong("IP_COPAY"));*/
								 insPricingVOCoverage10.setIpCopayDesc(UXUtility.checkNull(rs.getString("IP_COPAY")));
								 insPricingVOCoverage10.setOpticalCopayListDesc(UXUtility.checkNull(rs.getString("opt_copay_perc")));
								 
							/*	 
								 insPricingVOProvider10.setAlAhlihospital(UXUtility.checkNull(rs.getString("alahli_cover")));
								 insPricingVOProvider10.setOpCopyalahlihosp(UXUtility.checkNull(rs.getString("op_copay_alh_perc")));
								 insPricingVOProvider10.setiPCopayAtAhliListDesc(UXUtility.checkNull(rs.getString("IP_COPAY_ALH_PERC")));
								 insPricingVOProvider10.setAdditionalHospitalCoverageList(UXUtility.checkNull(rs.getString("ADDI_HOSP_COV_NAME")));
								 insPricingVOProvider10.setLoadinghospitalCoverage(rs.getLong("load_addi_hosp_cov"));
								 insPricingVOProvider10.setHospitalExclusionsList(UXUtility.checkNull(rs.getString("exclu_hosp_cov_name")));*/
								 
								 
								 
								/* insPricingVOOptical10.setOpticalYN(UXUtility.checkNull(rs.getString("optcl_cover")));
								 insPricingVOOptical10.setOpticalCopayList(UXUtility.checkNull(rs.getString("optical_limit")));
								 insPricingVOOptical10.setOpticalCopayListDesc(UXUtility.checkNull(rs.getString("opt_copay_perc")));
								 insPricingVOOptical10.setOpticalFrameLimitList(UXUtility.checkNull(rs.getString("frame_limit")));					             
								 insPricingVOOptical10.setDentalYN(UXUtility.checkNull(rs.getString("dntl_cover")));
								 insPricingVOOptical10.setDentalLimitList(UXUtility.checkNull(rs.getString("dntl_limit")));
								 insPricingVOOptical10.setDentalcopayList(UXUtility.checkNull(rs.getString("dent_cpy_ded")));
								 insPricingVOOptical10.setOrthodontiCscoverage(UXUtility.checkNull(rs.getString("orthod_cov")));
								 insPricingVOOptical10.setOrthodonticsCopay(UXUtility.checkNull(rs.getString("Orthod_copay")));					             
								 insPricingVOOptical10.setMaternityYN(UXUtility.checkNull(rs.getString("Maternity_coverage")));
								 insPricingVOOptical10.setMaternityLimitList(rs.getLong("Maternity_limit"));*/
								/* insPricingVOOptical10.setMaternityCopayList(rs.getLong("Maternity_cpy_ded"));*/
								 
								 
						/*		 insPricingVOOther10.setResidencyCountryList(UXUtility.checkNull(rs.getString("Residency_country")));
								 insPricingVOOther10.setLoadingResiCntry(UXUtility.checkNull(rs.getString("Loading_resi_cntry")));
								 insPricingVOOther10.setOtherKeyComents(UXUtility.checkNull(rs.getString("Loading_resi_cntry")));
								 insPricingVOOther10.setProRATALimitApplicable(UXUtility.checkNull(rs.getString("Prorata_limits")));
								 insPricingVOOther10.setPremiumRefundApproach(UXUtility.checkNull(rs.getString("Premium_refund_logic")));					             
								 insPricingVOOther10.setPremiumPerMember(UXUtility.checkNull(rs.getString("Premium_per_member")));
								 insPricingVOOther10.setProjectedLossRatio(UXUtility.checkNull(rs.getString("Projected_loss_ratio")));
								 insPricingVOOther10.setLoadsChangesBenef(UXUtility.checkNull(rs.getString("Loads_changes_benef")));
								 insPricingVOOther10.setDiscountChangBenef(UXUtility.checkNull(rs.getString("Discount_chang_benef")));
								 insPricingVOOther10.setLoadAntiSelection(UXUtility.checkNull(rs.getString("Load_anti_selection")));
								 insPricingVOOther10.setBrokingCommission(UXUtility.checkNull(rs.getString("Broking_commission")));
								 insPricingVOOther10.setContingencyLoading(UXUtility.checkNull(rs.getString("Contingency_loading")));
								 insPricingVOOther10.setOverheadCost(UXUtility.checkNull(rs.getString("Overhead_cost")));
								 insPricingVOOther10.setManagementDiscount(UXUtility.checkNull(rs.getString("Management_discount")));
								 insPricingVOOther10.setProfitMargin(UXUtility.checkNull(rs.getString("Profit_margin")));
								 insPricingVOOther10.setComments(UXUtility.checkNull(rs.getString("comments")));
								 */
								/* System.out.println("Gross_premium_member...."+rs.getLong("Gross_premium_member"));*/
								 
							/*	 insPricingVOOther10.setGrossPremiumMember(rs.getLong("Gross_premium_member"));*/
								 
								/* insPricingVOExperinceSummery10.setTotalClaimDes(UXUtility.checkNull(rs.getString("total_claims")));
								 insPricingVOExperinceSummery10.setUltimateLossDes(UXUtility.checkNull(rs.getString("ultmte_loss_grp_level")));
								 insPricingVOExperinceSummery10.setLossrationDes(UXUtility.checkNull(rs.getString("loss_ratio_grp_level")));
								 insPricingVOExperinceSummery10.setPremiumPerMemDes(UXUtility.checkNull(rs.getString("prem_mem_grp_level")));*/
								 
								 
							 }
							 
							
							
							i++;																											
							alGroupPicingList.add(insPricingVO);
						
						
						}
						
						alGroupPicingListCoverage1.add(insPricingVOCoverage1);
						alGroupPicingListCoverage2.add(insPricingVOCoverage2);
						alGroupPicingListCoverage3.add(insPricingVOCoverage3);
						alGroupPicingListCoverage4.add(insPricingVOCoverage4);
						alGroupPicingListCoverage5.add(insPricingVOCoverage5);
						alGroupPicingListCoverage6.add(insPricingVOCoverage6);
						alGroupPicingListCoverage7.add(insPricingVOCoverage7);
						alGroupPicingListCoverage8.add(insPricingVOCoverage8);
						alGroupPicingListCoverage9.add(insPricingVOCoverage9);
						alGroupPicingListCoverage10.add(insPricingVOCoverage10);
						
						
						
						/*alGroupPicingListProvider1.add(insPricingVOProvider1);
						alGroupPicingListProvider2.add(insPricingVOProvider2);
						alGroupPicingListProvider3.add(insPricingVOProvider3);
						alGroupPicingListProvider4.add(insPricingVOProvider4);
						alGroupPicingListProvider5.add(insPricingVOProvider5);
						alGroupPicingListProvider6.add(insPricingVOProvider6);
						alGroupPicingListProvider7.add(insPricingVOProvider7);
						alGroupPicingListProvider8.add(insPricingVOProvider8);
						alGroupPicingListProvider9.add(insPricingVOProvider9);
						alGroupPicingListProvider10.add(insPricingVOProvider10);*/
						
						
						
						/*alGroupPicingListOptical1.add(insPricingVOOptical1);
						alGroupPicingListOptical2.add(insPricingVOOptical2);
						alGroupPicingListOptical3.add(insPricingVOOptical3);
						alGroupPicingListOptical4.add(insPricingVOOptical4);
						alGroupPicingListOptical5.add(insPricingVOOptical5);
						alGroupPicingListOptical6.add(insPricingVOOptical6);
						alGroupPicingListOptical7.add(insPricingVOOptical7);
						alGroupPicingListOptical8.add(insPricingVOOptical8);
						alGroupPicingListOptical9.add(insPricingVOOptical9);
						alGroupPicingListOptical10.add(insPricingVOOptical10);*/
						
				/*		alGroupPicingListOther1.add(insPricingVOOther1);
						alGroupPicingListOther2.add(insPricingVOOther2);
						alGroupPicingListOther3.add(insPricingVOOther3);
						alGroupPicingListOther4.add(insPricingVOOther4);
						alGroupPicingListOther5.add(insPricingVOOther5);
						alGroupPicingListOther6.add(insPricingVOOther6);
						alGroupPicingListOther7.add(insPricingVOOther7);
						alGroupPicingListOther8.add(insPricingVOOther8);
						alGroupPicingListOther9.add(insPricingVOOther9);
						alGroupPicingListOther10.add(insPricingVOOther10);*/
						
						alGroupPicingListExperinceSummery1.add(insPricingVOExperinceSummery1);
						
						
					
					
						
					}
			  } try(ResultSet rs = (java.sql.ResultSet)cStmtObject.getObject(4);){
					if(rs != null){
						while(rs.next())
						{
							grossPremiumMemberGroupLevel = new InsPricingVO();							
							
							grossPremiumMemberGroupLevel.setGrossPremiumMemberGroupLevel(UXUtility.checkNull(rs.getString("tot_sum")));
							
							
						}
					}
			  }try(ResultSet rs = (java.sql.ResultSet)cStmtObject.getObject(5);){
					if(rs != null){
						while(rs.next())
						{
							
							groupPolicyDuration = new InsPricingVO();
							
						
							
							groupPolicyDuration.setPolicyDuration(UXUtility.checkNull(rs.getString("POL_DURATION")));
							groupPolicyDuration.setGroupPolicyCoverStartDate(UXUtility.checkNull(rs.getString("COV_START_DATE")));
							groupPolicyDuration.setGroupPolicyCoverEndDate(UXUtility.checkNull(rs.getString("COV_END_DATE")));
							groupPolicyDuration.setLastSaveDateGroupPricing(UXUtility.checkNull(rs.getString("last_refreshed_date")));
							groupPolicyDuration.setExprienceDscDate(UXUtility.checkNull(rs.getString("cur_pol_period")));
							groupPolicyDuration.setClientCodeDesc(UXUtility.checkNull(rs.getString("client_code")));
							groupPolicyDuration.setTotalClaimDate(UXUtility.checkNull(rs.getString("as_on_run_date")));
							groupPolicyDuration.setGroupPricingNewFlag(UXUtility.checkNull(rs.getString("new_renew_yn")));
							
							
							
							
							
							
						}
					}
			  }
						
			
			
			
		}
		
		
		alResultList.add(alGroupPicingList);
		alResultList.add(alGroupPicingListCoverage1);
		alResultList.add(alGroupPicingListCoverage2);
		alResultList.add(alGroupPicingListCoverage3);
		alResultList.add(alGroupPicingListCoverage4);
		alResultList.add(alGroupPicingListCoverage5);
		alResultList.add(alGroupPicingListCoverage6);
		alResultList.add(alGroupPicingListCoverage7);
		alResultList.add(alGroupPicingListCoverage8);
		alResultList.add(alGroupPicingListCoverage9);
		alResultList.add(alGroupPicingListCoverage10);
						
		
	/*	alResultList.add(alGroupPicingListProvider1);
		alResultList.add(alGroupPicingListProvider2);
		alResultList.add(alGroupPicingListProvider3);
		alResultList.add(alGroupPicingListProvider4);
		alResultList.add(alGroupPicingListProvider5);
		alResultList.add(alGroupPicingListProvider6);
		alResultList.add(alGroupPicingListProvider7);
		alResultList.add(alGroupPicingListProvider8);
		alResultList.add(alGroupPicingListProvider9);
		alResultList.add(alGroupPicingListProvider10);
			*/
		
		/*alResultList.add(alGroupPicingListOptical1);
		alResultList.add(alGroupPicingListOptical2);
		alResultList.add(alGroupPicingListOptical3);
		alResultList.add(alGroupPicingListOptical4);
		alResultList.add(alGroupPicingListOptical5);
		alResultList.add(alGroupPicingListOptical6);
		alResultList.add(alGroupPicingListOptical7);
		alResultList.add(alGroupPicingListOptical8);
		alResultList.add(alGroupPicingListOptical9);
		alResultList.add(alGroupPicingListOptical10);
		*/
		
	/*	alResultList.add(alGroupPicingListOther1);
		alResultList.add(alGroupPicingListOther2);
		alResultList.add(alGroupPicingListOther3);
		alResultList.add(alGroupPicingListOther4);
		alResultList.add(alGroupPicingListOther5);
		alResultList.add(alGroupPicingListOther6);
		alResultList.add(alGroupPicingListOther7);
		alResultList.add(alGroupPicingListOther8);
		alResultList.add(alGroupPicingListOther9);
		alResultList.add(alGroupPicingListOther10);*/
		
		alResultList.add(grossPremiumMemberGroupLevel);
		
		alResultList.add(groupPolicyDuration);
		alResultList.add(alGroupPicingListExperinceSummery1);
		
		
		return (ArrayList) alResultList;
	}

	@Override
	public Long saveGroupPricingDetails(InsPricingVO insPricingVO) throws Exception {
		// TODO Auto-generated method stub
		Long iResult = 0l; 
		Long groupProSeqid =null;
		Long groupProRefNo =null;
		Long revisedPrimiumGroupVal =null;
		Long targetPrimiumVal =null;
	    Long proposedVal =null;
	    
	    
	    Long groupSeq = null;
	    Long lodingVal=null;
	    Long discountVal=null;
	    Long revisedVal=null;
	    Long ldsVal=null;
		try(Connection con = dataSource.getConnection();
				CallableStatement cStmtObject = (java.sql.CallableStatement)con.prepareCall(strGroupPricingSaveDetails);){
			
			
			
			if(insPricingVO.getGroupProfilePricingSeqid() !=null) {
				groupProSeqid = insPricingVO.getGroupProfilePricingSeqid();
			}else {
				groupProSeqid = 0l;
			}
							
		
			if(insPricingVO.getTargetPrimiumVal() !=null) {
				targetPrimiumVal = insPricingVO.getTargetPrimiumVal();
			}else {
				targetPrimiumVal = null;
			}
			
			if(insPricingVO.getProposedVal() !=null) {
				proposedVal = insPricingVO.getProposedVal();
			}else {
				proposedVal = null;
			}
			
			if(insPricingVO.getRevisedPrimiumGroupVal() !=null) {
				revisedPrimiumGroupVal = insPricingVO.getRevisedPrimiumGroupVal();
			}else {
				revisedPrimiumGroupVal = null;
			}
			
			if(insPricingVO.getGroupPricingSeqId() !=null) {
				
				
				
				for(int i=0;i<insPricingVO.getGroupPricingSeqId().length;i++) {
					
				
					
				
					if(insPricingVO.getGroupPricingSeqId()[i] !=null) {
						groupSeq = insPricingVO.getGroupPricingSeqId()[i];
					}else {
						groupSeq = null;
					}
					if(insPricingVO.getLodingPricingVal().length > 0) {
					if(insPricingVO.getLodingPricingVal()[i] !=null ) {
						lodingVal = insPricingVO.getLodingPricingVal()[i];
					}else {
						lodingVal = null;
					}
					}else {
						lodingVal = null;
					}
					
					if(insPricingVO.getDiscountPricingVal().length > 0) {
					if(insPricingVO.getDiscountPricingVal()[i] !=null ) {
						discountVal = insPricingVO.getDiscountPricingVal()[i];
					}else {
						discountVal = null;
					}
					}else {
						discountVal = null;
					}
					if(insPricingVO.getRevisedPrimiumVal().length > 0) {
					if(insPricingVO.getRevisedPrimiumVal()[i] !=null) {
						revisedVal = insPricingVO.getRevisedPrimiumVal()[i];
					}else {
						revisedVal = null;
					}
					}else {
						revisedVal = null;
					}
		
				
					if(insPricingVO.getLdsSeqIdVal().length > 0) {
					if(insPricingVO.getLdsSeqIdVal()[i] !=null ) {
						ldsVal = insPricingVO.getLdsSeqIdVal()[i];
					}else {
						ldsVal = null;
					}
					}else {
						ldsVal = null;
					}
				
				
					if(ldsVal !=null) {
						
						cStmtObject.setLong(1,ldsVal);
						}else {
							
							cStmtObject.setLong(1,0);
						}
					
				
					
					if(groupProSeqid !=null) {
					
						cStmtObject.setLong(2,groupProSeqid);
						}else {
							
							cStmtObject.setLong(2,0);
						}
					if(groupSeq !=null) {
					
						cStmtObject.setLong(3,groupSeq);
						}else {
							
							cStmtObject.setLong(3,0);
						}
					
					if(lodingVal !=null) {
					
						cStmtObject.setLong(4,lodingVal);
						}else {
							
							cStmtObject.setLong(4,0);
						}
					
					if(discountVal !=null) {
						
						cStmtObject.setLong(5,discountVal);
						}else {
							
							cStmtObject.setLong(5,0);
						}
					
					    if(revisedVal !=null) {
					    	
						cStmtObject.setLong(6,revisedVal);
						}else {
							
							cStmtObject.setLong(6,0);
						}
					    
					    if(revisedPrimiumGroupVal != null) {
					    	
							cStmtObject.setLong(7,revisedPrimiumGroupVal);
							}else {
							
								cStmtObject.setLong(7,0);
							}
					    if(targetPrimiumVal !=null) {
					    	
							cStmtObject.setLong(8,targetPrimiumVal);
							}else {
							
								cStmtObject.setLong(8,0);
							}
					    
					    if(proposedVal !=null) {
					    
							cStmtObject.setLong(9,proposedVal);
							}else {
								
								cStmtObject.setLong(9,0);
							}
						cStmtObject.setLong(10,insPricingVO.getUpdatedBy());
					 /*   cStmtObject.registerOutParameter(10,Types.INTEGER);*/
					    
					    cStmtObject.addBatch();
					
				}
			}
			
   iResult = 1l;
        	
        	cStmtObject.executeBatch();
		}
		
		return iResult;
	}

	@Override
	public InsPricingVO generateGroupSeqId(Long groupProfileSeqId,Long UserSeqid,String pricingList)
			throws Exception {
		// TODO Auto-generated method stub
		InsPricingVO insPricingVO =new InsPricingVO();
		try(Connection con = dataSource.getConnection();
				CallableStatement cStmtObject = (java.sql.CallableStatement)con.prepareCall(strGroupPricingsGenerateSeqId);){
			
				  cStmtObject.setLong(1,UserSeqid);
				  cStmtObject.setString(2,"GRP");
			  cStmtObject.setString(3,pricingList);
			  cStmtObject.registerOutParameter(4,Types.INTEGER);
			  cStmtObject.registerOutParameter(5,Types.VARCHAR);	
			  cStmtObject.execute();
				
			  insPricingVO.setGroupProfilePricingSeqid((Long)cStmtObject.getLong(4));
			  insPricingVO.setGroupProfileRefNo((String)cStmtObject.getString(5));
			/* insPricingVO.setGroupProfileRefNo((Long)cStmtObject.getLong(2));*/
			  
		
		return insPricingVO;
	}
}

	@Override
	public String getFetchFlag(String clientCode) throws Exception {
		// TODO Auto-generated method stub
		
		
		try(Connection con = dataSource.getConnection();
				CallableStatement cStmtObject = (java.sql.CallableStatement)con.prepareCall(strgetFetchFlag);){		
			
				  cStmtObject.setString(1,clientCode);				 			 
			      cStmtObject.registerOutParameter(2,Types.VARCHAR);	
			      cStmtObject.execute();
			      return  (String)cStmtObject.getString(2);			  				
	}

	}
}


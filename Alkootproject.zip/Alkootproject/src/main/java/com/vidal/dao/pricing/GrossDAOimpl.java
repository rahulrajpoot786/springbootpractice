package com.vidal.dao.pricing;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;

import javax.sql.DataSource;

import oracle.jdbc.OracleTypes;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.itextpdf.text.log.SysoCounter;
import com.vidal.command.pricing.InsPricingVO;
import com.vidal.command.pricing.SwPolicyConfigVO;
import com.vidal.command.pricing.SwPricingSummaryVO;
import com.vidal.command.pricing.WhatifScreenVO;
import com.vidal.common.UXUtility;
import com.vidal.common.VidalCommon;
@Repository
public class GrossDAOimpl implements GrossDAO {
	@Autowired
	private DataSource dataSource;
	private static final String strSaveLoading="{CALL PRICING_APP_PKG.save_loadings (?,?,?,?,?)}";
	private static final String strPricingFlag ="SELECT DISTINCT G.BENF_COV_SVE_YN,G.CAL_CPM_SVE_YN,nvl(CAL_LODING_SVE_YN,'N')CAL_LODING_SVE_YN ,NVL(cal_load_display_yn,'N') cal_load_display_yn ,DMGRPHC_SAVE_YN,TRND_FACTOR_PERC,NVL(F.MODIFY_YN,'Y') AS MODIFY_YN,case when (select  count(*) from APP.TPA_GROPU_BNF_LIVS_DTLS_SPR s where s.grp_prof_seq_id=g.grp_prof_seq_id and nvl(s.tot_cov_lives,0)>0)>0 then 'Y' else nvl(h.census_save_yn,'N') end AS CENSUS_SAVE_YN, G.PAST_POLICY_RUN_DATE,to_char(NVL(nvl(G.PAST_POLICY_RUN_DATE,NVL(D.ADDED_DATE,D.UPDATED_DATE)),G.ADDED_DATE),'dd-mm-yyyy') AS ADDED_DATE,G.MAT_PRICING_DISPLAY,G.PREMIUM_OUTPUT_STRU,G.RENEWAL_YN,G.PREV_POLICY_NO,G.BROKERING_TYPE FROM APP.TPA_GROUP_PROFILE_DETAILS_SPR G LEFT OUTER JOIN APP.TPA_GROUP_FNL_CPM_DETAILS_SPR F ON (G.GRP_PROF_SEQ_ID=F.GRP_PROF_SEQ_ID) LEFT JOIN APP.TPA_PAST_POLICY_PRICING_DATA D ON (D.POLICY_NUMBER=G.PREV_POLICY_NO) LEFT OUTER JOIN APP.TPA_GROPU_BNF_LIVS_DTLS_SPR H ON (G.GRP_PROF_SEQ_ID =H.GRP_PROF_SEQ_ID) WHERE G.GRP_PROF_SEQ_ID =?"; 

	private static final String strCPMAfterCalLoading="{CALL PRICING_APP_PKG.get_final_premium(?,?,?,?,?,?,?)}";
	private static final String strLoadingAfterCalc="{CALL PRICING_APP_PKG.GET_LODING_DETAILS(?,?)}";
	private static final String strMasterListValue="{CALL PRICING_APP_PKG.GET_IP_MSTR_DETAILS(?,?,?,?)}";//Master Details
	//private static final String strCPMAfterCal="{CALL POLICY_COPY_ISSUE_AUTOMATION.GET_CPM_ON_CALC(?,?)}";
	private static final String strCalculateLoading="{CALL PRICING_APP_PKG.LOADINGS_CAL(?,?,?,?)}";
	private static final String strPricingFlagtable="select G.PREMIUM_OUTPUT_STRU, G.MAT_PRICING_DISPLAY from APP.TPA_GROUP_PROFILE_DETAILS G where G.GRP_PROF_SEQ_ID=?";
	private static final String strGetWhatifDetails="{CALL PRICING_APP_PKG.select_whatif_details(?,?,?,?,?,?,?,?)}";
	private static final String strSaveEstimateChange="{CALL PRICING_APP_PKG.estimate_what_if_revision(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}";
	private static final String strSaveWhatIfDetails="{CALL PRICING_APP_PKG.save_what_if_Details(?,?,?,?)}";
	private static final String strSaveWhatIfDetailsChange="{CALL PRICING_APP_PKG.reflect_whatif_changes (?,?,?,?)}";
	
	private static final String strGetVersion="select a.version_seq_id  as  version_seq_id  , nvl(a.version_save_yn, 'N') version_save_yn, nvl(a.estm_cost_yn,'N')  estmt_chng_yn  from app.TPA_WHATIF_PROFILE_SAVE a where a.grp_prof_seq_id =? and a.version_value =?";
	
	public void saveLoading(SwPricingSummaryVO swPricingSummaryVO) throws Exception{
		try (
				Connection con = dataSource.getConnection();
				CallableStatement cStmtObject = (java.sql.CallableStatement) con.prepareCall(strSaveLoading);
				) {
				
				String dctTypePercentages[]=swPricingSummaryVO.getDeductTypePercentages();
				Long[] dctgropseqid= swPricingSummaryVO.getGrpLoadSeqIds();
				
				Long[] dctTypePercentageSeqIDs=swPricingSummaryVO.getDeductTypeSeqIds();
				for (int i=0;i<dctTypePercentages.length;i++){
					
					  if(dctgropseqid[i]==null) {
						/*  cStmtObject.setString(1,null);*/
						  cStmtObject.setLong(1,0);
					  }
			            else{
			            	cStmtObject.setLong(1,dctgropseqid[i]);
			            }
		            if(swPricingSummaryVO.getLngGroupProfileSeqID()!= null)
		            {
		            cStmtObject.setLong(2,swPricingSummaryVO.getLngGroupProfileSeqID());
		         
		            }else{
		            cStmtObject.setLong(2,0);
		            }
		           
		            if(dctTypePercentageSeqIDs[i]==null)  	cStmtObject.setLong(3,0);
		            else{
		            	
		            	cStmtObject.setLong(3,dctTypePercentageSeqIDs[i]);
		            }
		          
		            if(dctTypePercentages[i] != null &&  !"".equals(dctTypePercentages[i])){		           
		           
			               cStmtObject.setBigDecimal(4, new BigDecimal(dctTypePercentages[i])); 
			            }else{
				            	cStmtObject.setBigDecimal(4,null);
				         }
		            
		            
		           cStmtObject.setLong(5,swPricingSummaryVO.getAddedBy());
		            cStmtObject.addBatch();
				}
		              cStmtObject.executeBatch();
				    }//try 
	
			
		
			 
			
	}
	
	public int calculateLoading(SwPricingSummaryVO swPricingSummaryVO) throws Exception
	{
		int iResult=0;
		Connection conn = null;
	
		
		     try (Connection con = dataSource.getConnection();
						CallableStatement cStmtObject = (java.sql.CallableStatement) con.prepareCall(strCalculateLoading);) {
		    	 if(swPricingSummaryVO.getFinaldataSeqID()!= null)
		            {
		            cStmtObject.setLong(1,swPricingSummaryVO.getFinaldataSeqID());
		         
		            }else{
		            cStmtObject.setLong(1,0);
		            }
				
				
				  if(swPricingSummaryVO.getLngGroupProfileSeqID()!= null)
		            {
		            cStmtObject.setLong(2,swPricingSummaryVO.getLngGroupProfileSeqID());
		         
		            }else{
		            cStmtObject.setLong(2,0);
		            }
		           cStmtObject.setLong(3,swPricingSummaryVO.getAddedBy());
		           cStmtObject.setString(4,swPricingSummaryVO.getLoadComments());
				   cStmtObject.execute(); 
				 
				   iResult = 1;      
			}
		     return iResult;
		  
		     }
	
	 public ArrayList getAfterLoadingData(InsPricingVO insPricingVO)  throws Exception {
		   Collection<Object> alResultList = new ArrayList<Object>();
	    	
		
	    
	       /* JdbcRowSet rowSet = RowSetProvider.newFactory().createJdbcRowSet(); */
	      
	  
	        SwPricingSummaryVO swPricingSummaryVO = null;
	        try (Connection con = dataSource.getConnection();
					CallableStatement cStmtObject = (java.sql.CallableStatement) con.prepareCall(strLoadingAfterCalc);) {
	        	cStmtObject.setLong(1,insPricingVO.getGroupProfileSeqID());
				cStmtObject.registerOutParameter(2,OracleTypes.CURSOR);
				cStmtObject.execute();
			   try(ResultSet rs1 = (java.sql.ResultSet)cStmtObject.getObject(2);){
		            if(rs1 != null){
		            	
		                while (rs1.next()) {
		                
		                	
		                	
		                 swPricingSummaryVO = new SwPricingSummaryVO();	
		                
		             
		           
		                	swPricingSummaryVO.setGrp_load_SeqId(rs1.getLong("grp_ld_seq_id"));
		                   swPricingSummaryVO.setLngGroupProfileSeqID(rs1.getLong("grp_prof_seq_id"));
		                	swPricingSummaryVO.setAddedBy(insPricingVO.getAddedBy());		                
		                	swPricingSummaryVO.setLoad_DeductTypeSeqId(rs1.getLong("LOADING_TYPE_SEQ_ID"));	
		                	
		                	swPricingSummaryVO.setLoad_DeductType(UXUtility.checkNull(rs1.getString("LOATING_DEDUCT_TYPE")));
		                	
		                	if(rs1.getString("loading_perc") !=null){
		                		
		                		swPricingSummaryVO.setLoad_DeductTypePercentage(UXUtility.checkNull(rs1.getString("LOADING_PERC")));
		                		
		                	}
		                	swPricingSummaryVO.setLoadComments(UXUtility.checkNull(rs1.getString("LODING_REMARKS")));
		                	
		                	alResultList.add(swPricingSummaryVO);
		                	
		                	
	    							}
		            	
		               
		            }
		          
	        }    
		     
				return (ArrayList)alResultList;	
	    	}//end of try
	        }
	 
	 public ArrayList getBeforeLoadingData(InsPricingVO insPricingVO)  throws Exception {
	    	
		    Collection<Object> alResultList = new ArrayList<Object>();
	    	
			Connection conn = null;
	    	
	      
	      
	        SwPricingSummaryVO swPricingSummaryVO = null;
	        try (Connection con = dataSource.getConnection();
					CallableStatement cStmtObject = (java.sql.CallableStatement) con.prepareCall(strMasterListValue);) {
	        	
	        	cStmtObject.registerOutParameter(1,OracleTypes.CURSOR);
				cStmtObject.registerOutParameter(2,OracleTypes.CURSOR);
				cStmtObject.registerOutParameter(3,OracleTypes.CURSOR);//loading
				cStmtObject.registerOutParameter(4,OracleTypes.CURSOR);//IP OP sum

				cStmtObject.execute();
			try(ResultSet rs1 = (java.sql.ResultSet)cStmtObject.getObject(3);){
			
		            if(rs1 != null){
		                while (rs1.next()) {
		                	swPricingSummaryVO = new SwPricingSummaryVO();
		                
		        
		                	
		                	swPricingSummaryVO.setGrp_load_SeqId(null);
		                	swPricingSummaryVO.setLngGroupProfileSeqID(insPricingVO.getGroupProfileSeqID());
		                	swPricingSummaryVO.setAddedBy(insPricingVO.getAddedBy());
		            
		                	swPricingSummaryVO.setLoad_DeductTypeSeqId(rs1.getLong("LOADING_TYPE_SEQ_ID"));
		                	swPricingSummaryVO.setLoad_DeductType(UXUtility.checkNull(rs1.getString("LOATING_DEDUCT_TYPE")));
		                	swPricingSummaryVO.setLoad_DeductTypePercentage(rs1.getString("PERC"));//default value is 10
		                
		                	swPricingSummaryVO.setLoadComments("");
		                  	alResultList.add(swPricingSummaryVO);
	    							}
		            }
			}
		          
		           
		     
				return (ArrayList)alResultList;	
	    	}//end of try
	 }
/*	 public ArrayList getcpmAfterCalcultion(InsPricingVO insPricingVO)  throws Exception {
	    	
		    Collection<Object> alResultList = new ArrayList<Object>();
	    	
			Connection conn = null;
	    
	        ResultSet rs1 = null;
	        ResultSet rs2 = null;
	        SwPolicyConfigVO swPolicyConfigVO = null;
	        try (Connection con = dataSource.getConnection();
					CallableStatement cStmtObject = (java.sql.CallableStatement) con.prepareCall(strCPMAfterCal);) {
	        	
	        	cStmtObject.setLong(1,insPricingVO.getGroupProfileSeqID());
				cStmtObject.registerOutParameter(2,OracleTypes.CURSOR);
				cStmtObject.execute();
				rs1 = (java.sql.ResultSet)cStmtObject.getObject(2);
			
			
		            if(rs1 != null){
		                while (rs1.next()) {
		                	swPolicyConfigVO = new SwPolicyConfigVO();
		                	
		                	
		                	swPolicyConfigVO.setLngGroupProfileSeqID(rs1.getLong("GRP_PROF_SEQ_ID"));
		                	swPolicyConfigVO.setCpmSeqID(rs1.getLong("CPM_SEQ_ID"));
		                	swPolicyConfigVO.setAddedBy(insPricingVO.getAddedBy());
		                	swPolicyConfigVO.setSlNo(UXUtility.checkNull(rs1.getString("SL_NO")));
		                	
		                	swPolicyConfigVO.setDataType(UXUtility.checkNull(rs1.getString("DATA_TYPE")));
		                	swPolicyConfigVO.setPolicyNo(UXUtility.checkNull(rs1.getString("POLICY_NO")));
		                	swPolicyConfigVO.setClientCode(UXUtility.checkNull(rs1.getString("CLIENT_CODE")));
		                	swPolicyConfigVO.setEffectiveYear(UXUtility.checkNull(rs1.getString("EFFECTIVE_YEAR"))); 
                		  
		                	if(rs1.getDate("POL_EFFECTIVE_DATE") != null){
				                swPolicyConfigVO.setPolicyEffDate(new Date(TTKCommon.getFormattedDate(rs1.getDate("POL_EFFECTIVE_DATE"))));
			                
		                	swPolicyConfigVO.setPolicyEffDate(new Date(rs1.getTimestamp("POL_EFFECTIVE_DATE").getTime()));
			                swPolicyConfigVO.setStrpolicyEffDate(UXUtility.getFormattedDate(rs1.getDate("POL_EFFECTIVE_DATE")));

		                	}
		                	if(rs1.getDate("POL_EXPIRE_DATE") != null){
		                	swPolicyConfigVO.setPolicyExpDate(new Date(rs1.getTimestamp("POL_EXPIRE_DATE").getTime()));
			                swPolicyConfigVO.setStrpolicyExpDate(UXUtility.getFormattedDate(rs1.getDate("POL_EXPIRE_DATE")));
		                	}
		                	
		                	swPolicyConfigVO.setPolicyDurationPerMonth(rs1.getLong("POL_DURATION_MONTH"));
		                	swPolicyConfigVO.setNoOfLives(rs1.getLong("NO_LIVES"));
		                	if(rs1.getString("IP_CPM") != null){
		                		swPolicyConfigVO.setInPatientCPM(UXUtility.checkNull(rs1.getString("IP_CPM"))); 
		    				}
		                	if(rs1.getString("OP_CPM") != null){
		                		swPolicyConfigVO.setOutPatientCPM(UXUtility.checkNull(rs1.getString("OP_CPM"))); 
		    				}
		                	
		                	if(rs1.getString("OPL_CPM") != null){
		                		swPolicyConfigVO.setOpticalCPM(UXUtility.checkNull(rs1.getString("OPL_CPM"))); 
		    				}
		                	if(rs1.getString("DNT_CPM") != null){
		                		swPolicyConfigVO.setDentalCPM(UXUtility.checkNull(rs1.getString("DNT_CPM"))); 
		    				}
		                	if(rs1.getString("EXCPT_MAT_CPM") != null){
			                	swPolicyConfigVO.setAllExlMaternity(UXUtility.checkNull(rs1.getString("EXCPT_MAT_CPM"))); 
		    				}
		                	if(rs1.getString("MAT_CPM") != null){
			                	swPolicyConfigVO.setMaternityCPM(UXUtility.checkNull(rs1.getString("MAT_CPM"))); 
		    				}
		              
		                	if(rs1.getString("WEIGHTAGE") != null){
			                	//swPolicyConfigVO.setFinalweightage(new BigDecimal(rs1.getString("WEIGHTAGE"))); 
		                		swPolicyConfigVO.setFinalweightage(TTKCommon.checkNull(rs1.getString("WEIGHTAGE"))); 
		    				}
		            
		                	
		                	if(rs1.getString("IP_WEIGHTAGE") != null){
		                		swPolicyConfigVO.setInpatientcrediblty(UXUtility.checkNull(rs1.getString("IP_WEIGHTAGE"))); 
		    				}
		                	if(rs1.getString("OP_WEIGHTAGE") != null){
		                		swPolicyConfigVO.setOutpatientcrediblty(UXUtility.checkNull(rs1.getString("OP_WEIGHTAGE"))); 
		    				}
		                	if(rs1.getString("MAT_WEIGHTAGE") != null){
		                		swPolicyConfigVO.setMaternitycrediblty(UXUtility.checkNull(rs1.getString("MAT_WEIGHTAGE"))); 
		    				}
		                	if(rs1.getString("OPTL_WEIGHTAGE") != null){
		                		swPolicyConfigVO.setOpticalcrediblty(UXUtility.checkNull(rs1.getString("OPTL_WEIGHTAGE"))); 
		    				}
		                	if(rs1.getString("DNT_WEIGHTAGE") != null){
		                		swPolicyConfigVO.setDentalcrediblty(UXUtility.checkNull(rs1.getString("DNT_WEIGHTAGE"))); 
		    				}
		                   
		                	alResultList.add(swPolicyConfigVO);
	    				}
		            }
		          
		           
		     
				return (ArrayList)alResultList;	
	    	}//end of try
	 }
	 */
	/*	public SwPolicyConfigVO getcpmAfterLoading(InsPricingVO insPricingVO)  throws Exception {
	    	
	    	
			Connection conn = null;
	    
	        ResultSet rs1 = null;
	        ResultSet rs2 = null;
	      
	        SwPolicyConfigVO swPolicyConfigVO = null;
	        try (Connection con = dataSource.getConnection();
					CallableStatement cStmtObject = (java.sql.CallableStatement) con.prepareCall(strCPMAfterCalLoading);) {
	        	
	        	 if(insPricingVO.getFinaldataSeqID()!= null)
		            {
		            cStmtObject.setLong(1,insPricingVO.getFinaldataSeqID());
		         
		            }else{
		            cStmtObject.setLong(1,0);
		            }
				
				cStmtObject.setLong(1,insPricingVO.getGroupProfileSeqID());
				cStmtObject.setLong(2,insPricingVO.getAddedBy());
				cStmtObject.registerOutParameter(3,OracleTypes.CURSOR);
				cStmtObject.execute();
				rs1 = (java.sql.ResultSet)cStmtObject.getObject(3);
			
			
		            if(rs1 != null){
		                if (rs1.next()) {
		                	swPolicyConfigVO = new SwPolicyConfigVO();
		                	
		                	swPolicyConfigVO.setLngGroupProfileSeqID(rs1.getLong("GRP_PROF_SEQ_ID"));
		                	swPolicyConfigVO.setFinaldataSeqID(rs1.getLong("FNL_CPM_SEQ_ID"));
		                	swPolicyConfigVO.setAddedBy(insPricingVO.getAddedBy());
		                	
		                	swPolicyConfigVO.setFindataType(UXUtility.checkNull(rs1.getString("DATA_TYPE")));
		                	swPolicyConfigVO.setFinpolicyNo(UXUtility.checkNull(rs1.getString("POLICY_NO")));
		                	swPolicyConfigVO.setFinclientCode(UXUtility.checkNull(rs1.getString("CLIENT_CODE")));
		                	swPolicyConfigVO.setFineffectiveYear(UXUtility.checkNull(rs1.getString("EFFECTIVE_YEAR"))); 
		                	if(rs1.getDate("POL_EFFECTIVE_DATE") != null){
		                	swPolicyConfigVO.setFinpolicyEffDate(new Date(rs1.getTimestamp("POL_EFFECTIVE_DATE").getTime()));
		                	}
		                	if(rs1.getDate("POL_EXPIRE_DATE") != null){
		                	swPolicyConfigVO.setFinpolicyExpDate(new Date(rs1.getTimestamp("POL_EXPIRE_DATE").getTime()));
		                	}
		                	swPolicyConfigVO.setFinpolicyDurationPerMonth(rs1.getLong("POL_DURATION_MONTH"));
		                	swPolicyConfigVO.setFinnoOfLives(rs1.getLong("NO_LIVES"));
		                	if(rs1.getString("MODIFY_YN").equalsIgnoreCase("N")){
		                	
		                	if(rs1.getString("IP_CPM") != null){
		                		swPolicyConfigVO.setFininPatientCPM(UXUtility.checkNull(rs1.getString("IP_CPM"))); 
		    				}
		                	
		                	if(rs1.getString("OP_CPM") != null){
		                		swPolicyConfigVO.setFinoutPatientCPM(UXUtility.checkNull(rs1.getString("OP_CPM"))); 
		    				}
		                	
		                	if(rs1.getString("OPL_CPM") != null){
		                		swPolicyConfigVO.setFinopticalCPM(UXUtility.checkNull(rs1.getString("OPL_CPM"))); 
		    				}
		                	if(rs1.getString("DNT_CPM") != null){
		                		swPolicyConfigVO.setFindentalCPM(UXUtility.checkNull(rs1.getString("DNT_CPM"))); 
		    				}
		                	if(rs1.getString("EXCPT_MAT_CPM") != null){
			                	swPolicyConfigVO.setFinallExlMaternity(UXUtility.checkNull(rs1.getString("EXCPT_MAT_CPM"))); 
		    				}
		                	if(rs1.getString("MAT_CPM") != null){
			                	swPolicyConfigVO.setFinmaternityCPM(UXUtility.checkNull(rs1.getString("MAT_CPM"))); 
		    				}
	                	
		                	
		                	}else if(rs1.getString("MODIFY_YN").equalsIgnoreCase("Y")){
		                		swPolicyConfigVO.setFininPatientCPM(""); 
		                		swPolicyConfigVO.setFinoutPatientCPM(""); 
		                		swPolicyConfigVO.setFinopticalCPM(""); 
		                		swPolicyConfigVO.setFindentalCPM(""); 
		                		swPolicyConfigVO.setFinallExlMaternity(""); 
		                		swPolicyConfigVO.setFinmaternityCPM(""); 
		                		swPolicyConfigVO.setFinfinalweightage("");  
		                
			                	}
		                	
		                }// end if next() loop
		           
	                	
	                }
		          
		           
		     
				return swPolicyConfigVO;	
	    	}//end of try
		}*/
		/*public int saveLoading(SwPricingSummaryVO swPricingSummaryVO) throws Exception
		{
			int iResult=0;
			Connection conn = null;
		
			ArrayList alLoadinglist = new ArrayList();
			  try (Connection con = dataSource.getConnection();
						CallableStatement cStmtObject = (java.sql.CallableStatement) con.prepareCall(strSaveLoading);) {
				  
				  alLoadinglist = 	swPricingSummaryVO.getAlLoadingGrosspremium();
					int i= 0;
					    if(!(alLoadinglist.isEmpty())){
			                for(Object object:alLoadinglist){
			                i++;//condition is required to write
			            swPricingSummaryVO = (SwPricingSummaryVO)object;
			          System.out.println("swPricingSummaryVO.getGrp_load_SeqId()....."+swPricingSummaryVO.getGrp_load_SeqId());
			            if(swPricingSummaryVO.getGrp_load_SeqId()!= null)
			            {
			            cStmtObject.setLong(1,swPricingSummaryVO.getGrp_load_SeqId());
			         
			            }else{
			            cStmtObject.setLong(1,0);
			            }
			            System.out.println("swPricingSummaryVO.getLngGroupProfileSeqID()...."+swPricingSummaryVO.getLngGroupProfileSeqID());
			            
			            if(swPricingSummaryVO.getLngGroupProfileSeqID()!= null)
			            {
			            cStmtObject.setLong(2,swPricingSummaryVO.getLngGroupProfileSeqID());
			         
			            }else{
			            cStmtObject.setLong(2,0);
			            }
			            System.out.println("swPricingSummaryVO.getLoad_DeductTypeSeqId()....."+swPricingSummaryVO.getLoad_DeductTypeSeqId());
			            
			            cStmtObject.setLong(3,swPricingSummaryVO.getLoad_DeductTypeSeqId());
			            System.out.println("swPricingSummaryVO.getLoad_DeductTypePercentage()........"+swPricingSummaryVO.getLoad_DeductTypePercentage());
			            
			            if(swPricingSummaryVO.getLoad_DeductTypePercentage() != null && swPricingSummaryVO.getLoad_DeductTypePercentage() != ""){
			               cStmtObject.setBigDecimal(4,new BigDecimal(swPricingSummaryVO.getLoad_DeductTypePercentage())); 
			            }else{
				            	cStmtObject.setBigDecimal(4,null);
				         }
			            System.out.println("swPricingSummaryVO.getAddedBy()......."+swPricingSummaryVO.getAddedBy());
			            
			           cStmtObject.setLong(5,swPricingSummaryVO.getAddedBy());
			            cStmtObject.addBatch();
					}
			                cStmtObject.executeBatch(); 
					}//end of try
					     iResult=i;
					  
					     
				}
				return iResult;
		}
	        
	 */
		/*public ArrayList calculatePlanDesignConfig(SwPolicyConfigVO swpolicyConfigVO) throws Exception
		{
			int iResult=0;
			Connection conn = null;
			
			ArrayList arraylist = new ArrayList();
			ArrayList alPastdatalist = new ArrayList();
			   try (Connection con = dataSource.getConnection();
						CallableStatement cStmtObject = (java.sql.CallableStatement) con.prepareCall(strCPMAfterCalLoading);) {
				   alPastdatalist = 	swpolicyConfigVO.getAlPastData();
					int i= 0;
					    if(!(alPastdatalist.isEmpty())){
			                for(Object object:alPastdatalist){
			                i++;
			            swpolicyConfigVO = (SwPolicyConfigVO)object;
			           
			            if(swpolicyConfigVO.getCpmSeqID()!= null)
			            {
			            cStmtObject.setLong(1,swpolicyConfigVO.getCpmSeqID());
			         
			            }else{
			            cStmtObject.setLong(1,0);
			            }
			            
			            if(swpolicyConfigVO.getLngGroupProfileSeqID()!= null)
			            {
			            cStmtObject.setLong(2,swpolicyConfigVO.getLngGroupProfileSeqID());
			         
			            }else{
			            cStmtObject.setLong(2,0);
			            }
			  
			            cStmtObject.setString(3,swpolicyConfigVO.getDataType()); 
			            cStmtObject.setString(4,swpolicyConfigVO.getPolicyNo());

			            if(swpolicyConfigVO.getEffectiveYear() != null){
			            cStmtObject.setString(5,swpolicyConfigVO.getEffectiveYear());
			            }else{
			            	cStmtObject.setLong(5,0);
			            }
			           
			            if(!swpolicyConfigVO.getDataType().equalsIgnoreCase("USR_IP_YR")){
				            if(swpolicyConfigVO.getPolicyEffDate() != null){
							cStmtObject.setTimestamp(6,new Timestamp(swpolicyConfigVO.getPolicyEffDate().getTime()));//LETTER_DATE
				            }else{
				            	cStmtObject.setTimestamp(6,null);
				            }
				    
				            if(swpolicyConfigVO.getPolicyExpDate() != null){
							cStmtObject.setTimestamp(7,new Timestamp(swpolicyConfigVO.getPolicyExpDate().getTime()));//LETTER_DATE
					        }else{
					        cStmtObject.setTimestamp(7,null);
					        }
				            
			            }else if (swpolicyConfigVO.getDataType().equalsIgnoreCase("USR_IP_YR")){
			           
			            	if(swpolicyConfigVO.getStrpolicyEffDate() != "" && swpolicyConfigVO.getStrpolicyEffDate() != null){
							cStmtObject.setTimestamp(6,VidalCommon.getConvertStringToDateTimestamp(swpolicyConfigVO.getStrpolicyEffDate()));//LETTER_DATE
							 
				            }else{
				            	cStmtObject.setTimestamp(6,null);
				            }
							
				            if(swpolicyConfigVO.getStrpolicyExpDate() != "" && swpolicyConfigVO.getStrpolicyExpDate() != null){
							cStmtObject.setTimestamp(7,VidalCommon.getConvertStringToDateTimestamp(swpolicyConfigVO.getStrpolicyExpDate()));//LETTER_DATE
					        }else{
					        cStmtObject.setTimestamp(7,null);
					        }
			            }
			            
			            if(swpolicyConfigVO.getPolicyDurationPerMonth() != null){
				            cStmtObject.setLong(8,swpolicyConfigVO.getPolicyDurationPerMonth());
				            }else{
				            	cStmtObject.setLong(8,0);
				            }
			            
			            if(swpolicyConfigVO.getNoOfLives() != null){
				            cStmtObject.setLong(9,swpolicyConfigVO.getNoOfLives());
				            }else{
				            	cStmtObject.setLong(9,0);
				            }
			          
			            if(swpolicyConfigVO.getInPatientCPM() != null  && swpolicyConfigVO.getInPatientCPM() !=""){
				            cStmtObject.setBigDecimal(10, new BigDecimal(swpolicyConfigVO.getInPatientCPM()));
				            }else{
				            	cStmtObject.setBigDecimal(10,null);
				            }
				
			            if(swpolicyConfigVO.getOutPatientCPM() != null && swpolicyConfigVO.getOutPatientCPM() !=""){
				            cStmtObject.setBigDecimal(11,new BigDecimal(swpolicyConfigVO.getOutPatientCPM()));
				            }else{
				            	cStmtObject.setBigDecimal(11,null);
				            }
			            
			            if(swpolicyConfigVO.getMaternityCPM() != null && swpolicyConfigVO.getMaternityCPM() !=""){
				            cStmtObject.setBigDecimal(12,new BigDecimal(swpolicyConfigVO.getMaternityCPM()));
				            }else{
				            	cStmtObject.setBigDecimal(12,null);
				            }
			            
			            
			            if(swpolicyConfigVO.getOpticalCPM() != null && swpolicyConfigVO.getOpticalCPM() !=""){
				            cStmtObject.setBigDecimal(13,new BigDecimal(swpolicyConfigVO.getOpticalCPM()));
				            }else{
				            	cStmtObject.setBigDecimal(13,null);
				            }
			            
			            
			            if(swpolicyConfigVO.getDentalCPM() != null && swpolicyConfigVO.getDentalCPM() !=""){
				            cStmtObject.setBigDecimal(14,new BigDecimal(swpolicyConfigVO.getDentalCPM()));
				            }else{
				            	cStmtObject.setBigDecimal(14,null);
				            }
			            
			            if(swpolicyConfigVO.getFinalweightage() != null &&  swpolicyConfigVO.getFinalweightage()!= ""){
				          //  cStmtObject.setBigDecimal(15,swpolicyConfigVO.getFinalweightage());
			            	cStmtObject.setBigDecimal(15,new BigDecimal(swpolicyConfigVO.getFinalweightage()));
				            }else{
				            	cStmtObject.setBigDecimal(15,null);
				            }
			            
			            if(swpolicyConfigVO.getInpatientcrediblty() != null &&  swpolicyConfigVO.getInpatientcrediblty()!= ""){
				            	cStmtObject.setBigDecimal(15,new BigDecimal(swpolicyConfigVO.getInpatientcrediblty()));
					            }else{
					            	cStmtObject.setBigDecimal(15,null);
					            }
			            if(swpolicyConfigVO.getOutpatientcrediblty() != null &&  swpolicyConfigVO.getOutpatientcrediblty()!= ""){
				            	cStmtObject.setBigDecimal(16,new BigDecimal(swpolicyConfigVO.getOutpatientcrediblty()));
					            }else{
					            	cStmtObject.setBigDecimal(16,null);
					            }
			            if(swpolicyConfigVO.getMaternitycrediblty() != null &&  swpolicyConfigVO.getMaternitycrediblty()!= ""){
				            	cStmtObject.setBigDecimal(17,new BigDecimal(swpolicyConfigVO.getMaternitycrediblty()));
					            }else{
					            	cStmtObject.setBigDecimal(17,null);
					            }
			            if(swpolicyConfigVO.getOpticalcrediblty() != null &&  swpolicyConfigVO.getOpticalcrediblty()!= ""){
				            	cStmtObject.setBigDecimal(18,new BigDecimal(swpolicyConfigVO.getOpticalcrediblty()));
					            }else{
					            	cStmtObject.setBigDecimal(18,null);
					            }
			            if(swpolicyConfigVO.getDentalcrediblty() != null &&  swpolicyConfigVO.getDentalcrediblty()!= ""){
				            	cStmtObject.setBigDecimal(19,new BigDecimal(swpolicyConfigVO.getDentalcrediblty()));
					            }else{
					            	cStmtObject.setBigDecimal(19,null);
					            }
			            
			            cStmtObject.setLong(20,swpolicyConfigVO.getAddedBy());
			            cStmtObject.setString(21,swpolicyConfigVO.getSlNo());
			            cStmtObject.addBatch();
					}
			                cStmtObject.executeBatch(); 
					}//end of try
					    iResult=i;
					     arraylist.add(iResult);
			   }
			   return arraylist;
		}
	        */

		


	@Override
	
	public ArrayList[] getcpmAfterLoadingPricing(
			InsPricingVO insPricingVO) throws Exception {
	    Collection<Object> alResultList = new ArrayList<Object>();
	    ArrayList table[]=new ArrayList[5];
	   
				
		    	
		       /**/
		        int inPatientSum=0;
		        int outPatientSum=0;
		        int opticalSum=0;
		        int dentalsum=0;
		        int explicitSum=0;
		        int maternitytable=0;
		        int maternitytablevalues=0;
		        int maternityIncludetablevalues=0;
		        Integer sumotherlives=0;
				Integer totalsumInpatientother=0;
				Integer totalsumoutpatientother=0;
				Integer totaloptical=0;
				Integer totaldental=0;
				Integer summatlives=0;
				Integer maternitysum=0;
				Integer summatlives2=0;
				Integer maternitysum2=0;
				Integer sumotherlives1=0;
				Integer sumotherlives2=0;
				Integer sumotherlives3=0;
				Integer sumotherlives4=0;
				StringBuilder builder=null;
		   
		        try (Connection con = dataSource.getConnection();
						CallableStatement cStmtObject = (java.sql.CallableStatement) con.prepareCall(strCPMAfterCalLoading);) {
		        	if(insPricingVO.getGroupProfileSeqID()!= null)
		            {
		        		cStmtObject.setLong(1,insPricingVO.getGroupProfileSeqID());
		        	
		         
		            }else{
		            cStmtObject.setLong(1,0);
		        	
		            }
				
			
			

				cStmtObject.setLong(2,insPricingVO.getAddedBy());
				cStmtObject.registerOutParameter(3,OracleTypes.CURSOR);
				cStmtObject.registerOutParameter(4,OracleTypes.CURSOR);
				cStmtObject.registerOutParameter(5,OracleTypes.CURSOR);
				cStmtObject.registerOutParameter(6,OracleTypes.NUMBER);
				cStmtObject.registerOutParameter(7,OracleTypes.NUMBER);
				cStmtObject.execute();
				
				
				
			    int premium=cStmtObject.getInt(6);
			    int maternity=	cStmtObject.getInt(7);
			  
			    
				
				ArrayList<HashMap<String,String>> alTable1=new ArrayList<>();
				ArrayList<HashMap<String,String>> alTable2=new ArrayList<>();
				ArrayList<HashMap<String,String>> alTable3=new ArrayList<>();
				ArrayList<String> tableDetails=new ArrayList<>();
				tableDetails.add(String.valueOf(premium));
				tableDetails.add(String.valueOf(maternity));
				ArrayList resultvalues=new ArrayList<>();
				
				
				try (ResultSet rs1 = (java.sql.ResultSet)cStmtObject.getObject(3);ResultSet femaleMaternity = (java.sql.ResultSet)cStmtObject.getObject(4);ResultSet overallvalue = (java.sql.ResultSet)cStmtObject.getObject(5);){
				
		            if(rs1 != null){
		                while(rs1.next()) {
		                	HashMap<String, String> tablevalues = new HashMap<String, String>();
		                	if(((premium==1 && (maternity ==1 ||maternity == 2)) || (premium ==2 &&  (maternity ==1 || maternity==2)) || (premium==3 && (maternity==1||maternity==2)) )) {
		           
		          
		            
		                	
		                
		                		
		                	tablevalues.put("LngGroupProfileSeqID",(UXUtility.checkNull(String.valueOf(rs1.getString("GRP_PROF_SEQ_ID")))));
		                	tablevalues.put("FinaldataSeqID",(UXUtility.checkNull(String.valueOf(rs1.getString("FNL_CPM_SEQ_ID")))));
		                	tablevalues.put("FindataType", (UXUtility.checkNull(String.valueOf(rs1.getString("DATA_TYPE")))));
		                	tablevalues.put("FinpolicyNo", (UXUtility.checkNull(String.valueOf(rs1.getString("POLICY_NO")))));
		                	tablevalues.put("FinclientCode", (UXUtility.checkNull(String.valueOf(rs1.getString("CLIENT_CODE")))));
		                	tablevalues.put("FineffectiveYear", (UXUtility.checkNull(String.valueOf(rs1.getString("EFFECTIVE_YEAR")))));
		                	tablevalues.put("FinpolicyEffDate", (UXUtility.checkNull(String.valueOf(rs1.getString("POL_EFFECTIVE_DATE")))));
		                	tablevalues.put("FinpolicyExpDate", (UXUtility.checkNull(String.valueOf(rs1.getString("POL_EXPIRE_DATE")))));
		                	tablevalues.put("FinpolicyExpDate", (UXUtility.checkNull(String.valueOf(rs1.getString("POL_DURATION_MONTH")))));
		                	tablevalues.put("FinnoOfLives", (UXUtility.checkNull(String.valueOf(rs1.getString("NO_LIVES")))));
		                	tablevalues.put("modify", (UXUtility.checkNull(String.valueOf(rs1.getString("MODIFY_YN")))));
		                	tablevalues.put("FininPatientCPM", (UXUtility.checkNull(String.valueOf(rs1.getString("IP_CPM")))));
		                	tablevalues.put("FinoutPatientCPM", (UXUtility.checkNull(String.valueOf(rs1.getString("OP_CPM")))));
		                	tablevalues.put("FinopticalCPM", (UXUtility.checkNull(String.valueOf(rs1.getString("OPL_CPM")))));
		                	tablevalues.put("FindentalCPM", (UXUtility.checkNull(String.valueOf(rs1.getString("DNT_CPM")))));
		                	tablevalues.put("FinallExlMaternity", (UXUtility.checkNull(String.valueOf(rs1.getString("EXCPT_MAT_CPM")))));
		                	tablevalues.put("FinmaternityCPM", (UXUtility.checkNull(String.valueOf(rs1.getString("MAT_CPM")))));
		                	tablevalues.put("InclmaternityCPM", (UXUtility.checkNull(String.valueOf(rs1.getString("INCLU_MAT_CPM")))));
		                	tablevalues.put("Agerangetable", (UXUtility.checkNull(String.valueOf(rs1.getString("AGE_RANGE")))));
		                	tablevalues.put("Genders", (UXUtility.checkNull(String.valueOf(rs1.getString("GNDR_DESC")))));
		                	tablevalues.put("Maternityage", (UXUtility.checkNull(String.valueOf(rs1.getString("MAT_AGE_RANGE")))));
		                	tablevalues.put("Otherlives", (UXUtility.checkNull(String.valueOf(rs1.getString("OTH_LIVES")))));
		                	tablevalues.put("matlives", (UXUtility.checkNull(String.valueOf(rs1.getString("MAT_LIVES")))));
		                	
		                	  String maternityval=   rs1.getString("MAT_CPM");
		                	  Integer matlives=0;
		                	  if(maternityval != null && !"NA".equals(maternityval) && !"".equals(maternityval)){
		                     String maternityv=rs1.getString("MAT_CPM");
		                     maternityv= maternityv.replaceAll(",", "");
		                     Integer maternityvalue=Integer.parseInt(maternityv);
		                     if(rs1.getString("MAT_LIVES")!=null){
		                     String str_matlives=rs1.getString("MAT_LIVES");
		                     str_matlives= str_matlives.replaceAll(",", "");
		                     matlives=Integer.parseInt(str_matlives);
		                     }
		                    Integer summatentiy=0;
		                    summatentiy= summatentiy+(maternityvalue*matlives);
		                    summatlives = summatlives+matlives;
		                    maternitysum = maternitysum+summatentiy;}
		                	
		                	
		                	
		                	
		                	  String inpatientval=   rs1.getString("IP_CPM");
		                	  Integer otherlives=0;
		                	  if(inpatientval != null && !"NA".equals(inpatientval) && !"".equals(inpatientval)){
		                     String str_inpatient=rs1.getString("IP_CPM");
		                     str_inpatient= str_inpatient.replaceAll(",", "");
		                     Integer inpatient=Integer.parseInt(str_inpatient);
		                     if(rs1.getString("OTH_LIVES")!=null){
		                     String str_otherlives=rs1.getString("OTH_LIVES");
		                     str_otherlives= str_otherlives.replaceAll(",", "");
		                      otherlives=Integer.parseInt(str_otherlives);
		                     }
		                    Integer sumInpatientother=0;
		                    sumInpatientother= sumInpatientother+(inpatient*otherlives);
		                   sumotherlives1 = sumotherlives1+otherlives;
		                    totalsumInpatientother = totalsumInpatientother+sumInpatientother;
		                    }
		                	
		                	  
		                    /*	if(inpatient != null && !"NA".equals(inpatient) && !"".equals(inpatient)){
		                    	inpatient=inpatient.replaceAll(",", "");
		                        double test= Double.valueOf(UXUtility.checkNull(inpatient));*/
		                	  String outpatientval=   rs1.getString("OP_CPM");
		                	  Integer otherlives1=0;
		                	  if(outpatientval != null && !"NA".equals(outpatientval) && !"".equals(outpatientval)){
		                     String str_outpatient=rs1.getString("OP_CPM");
		                     str_outpatient= str_outpatient.replaceAll(",", "");
		                     Integer outpatient=Integer.parseInt(str_outpatient);
		                     if(rs1.getString("OTH_LIVES")!=null){
		                     String str_otherlives2=rs1.getString("OTH_LIVES");
		                     str_otherlives2= str_otherlives2.replaceAll(",", "");
		                      otherlives1=Integer.parseInt(str_otherlives2);
		                     }
		                    Integer sumInpatientother1=0;
		                    sumInpatientother1= sumInpatientother1+(outpatient*otherlives1);
		                   sumotherlives2 = sumotherlives2+otherlives1;
		                    totalsumoutpatientother = totalsumoutpatientother+sumInpatientother1;
		                    }
		                	  
		                	  
		                	 /* 
		                	  String outpatientval=   rs1.getString("OP_CPM");
		                	  if(outpatientval != null && !"NA".equals(outpatientval) && !"".equals(outpatientval)){
		                     String str_outpatient=rs1.getString("OP_CPM");
		                     str_outpatient= str_outpatient.replaceAll(",", "");
		                     Integer outpatient=Integer.parseInt(str_outpatient);
		                    Integer sum_outpatientother=0;
		                    sum_outpatientother= sum_outpatientother+(outpatient*otherlives);
		                    System.out.println("sum_outpatientother..."+sum_outpatientother);
		                    sumotherlives = sumotherlives+otherlives;
		                    totalsumoutpatientother = totalsumoutpatientother+sum_outpatientother;
		                	  }*/
		                	  String opticalpatientval=   rs1.getString("OPL_CPM");
		                	  Integer otherlives3=0;
		                	  if(opticalpatientval != null && !"NA".equals(opticalpatientval) && !"".equals(opticalpatientval)){
		                     String str_opticalpatient=rs1.getString("OPL_CPM");
		                     str_opticalpatient= str_opticalpatient.replaceAll(",", "");
		                     Integer opticalpatient=Integer.parseInt(str_opticalpatient);
		                     if(rs1.getString("OTH_LIVES")!=null){
		                     String str_otherlives3=rs1.getString("OTH_LIVES");
		                     str_otherlives3= str_otherlives3.replaceAll(",", "");
		                      otherlives3=Integer.parseInt(str_otherlives3);
		                     }
		                    Integer sumoptical=0;
		                    sumoptical= sumoptical+(opticalpatient*otherlives3);
		                   sumotherlives3 = sumotherlives3+otherlives3;
		                    totaloptical = totaloptical+sumoptical;
		                    }
		                	  String dentalval=   rs1.getString("DNT_CPM");
		                	  Integer otherlives4=0;
		                	  if(dentalval != null && !"NA".equals(dentalval) && !"".equals(dentalval)){
		                     String str_dentalpatient=rs1.getString("DNT_CPM");
		                     str_dentalpatient= str_dentalpatient.replaceAll(",", "");
		                     Integer dentalpatint=Integer.parseInt(str_dentalpatient);
		                     if(rs1.getString("OTH_LIVES")!=null){
		                     String str_otherlives4=rs1.getString("OTH_LIVES");
		                     str_otherlives4= str_otherlives4.replaceAll(",", "");
		                      otherlives4=Integer.parseInt(str_otherlives4);
		                     }
		                    Integer sumdental=0;
		                    sumdental= sumdental+(dentalpatint*otherlives4);
		                   sumotherlives4 = sumotherlives4+otherlives4;
		                    totaldental = totaldental+sumdental;
		                    }
		                	  
		                 	  
		                	/*  String opticalpatientval=   rs1.getString("OPL_CPM");
		                	  if(opticalpatientval != null && !"NA".equals(opticalpatientval) && !"".equals(opticalpatientval)){
		                     String str_opticalpatient=rs1.getString("OPL_CPM");
		                     str_opticalpatient= str_opticalpatient.replaceAll(",", "");
		                     Integer optcalpatient=Integer.parseInt(str_opticalpatient);
		                    Integer sum_opticalpatient=0;
		                    sum_opticalpatient= sum_opticalpatient+(optcalpatient*otherlives);
		                    System.out.println("sum_outpatientother..."+sum_opticalpatient);
		                    sumotherlives = sumotherlives+otherlives;
		                    totaloptical = totaloptical+sum_opticalpatient;
		                	  }
		                	  */
		                	 /* String dental=   rs1.getString("DNT_CPM");
			                    if(dental != null && !"NA".equals(dental) && !"".equals(dental)){
		                     String str_dentalalpatient=rs1.getString("DNT_CPM");
		                     str_dentalalpatient= str_dentalalpatient.replaceAll(",", "");
		                     Integer dentalpatient=Integer.parseInt(str_dentalalpatient);
		                    Integer sum_dentalpatient=0;
		                    sum_dentalpatient= sum_dentalpatient+(dentalpatient*otherlives);
		                    System.out.println("sum_dentalpatient..."+sum_dentalpatient);
		                    sumotherlives = sumotherlives+otherlives;
		                    totaldental = totaldental+sum_dentalpatient;
		                	  }
		                	  
		                	  */
		                      
		                    
		                   /* String outpatient=   rs1.getString("OP_CPM");
		                    if(outpatient != null && !"NA".equals(outpatient) && !"".equals(outpatient)){
		                    	outpatient=outpatient.replaceAll(",", "");
		                        double test= Double.valueOf(UXUtility.checkNull(outpatient));
		                        outPatientSum=outPatientSum+test;
		                    }*/
		                /*    String optical=   rs1.getString("OPL_CPM");
		                    if(optical != null && !"NA".equals(optical) && !"".equals(optical)){
		                    	optical=optical.replaceAll(",", "");
		                        double test= Double.valueOf(UXUtility.checkNull(optical));
		                        opticalSum=opticalSum+test;
		                    }*/
		                   /* String dental=   rs1.getString("DNT_CPM");
		                    if(dental != null && !"NA".equals(dental) && !"".equals(dental)){
		                    	dental=dental.replaceAll(",", "");
		                        double test= Double.valueOf(UXUtility.checkNull(dental));
		                        dentalsum=dentalsum+test;
		                    }*/
		                   /* String Explicit=   rs1.getString("EXCPT_MAT_CPM");
		                    if(Explicit != null && !"NA".equals(Explicit) && !"".equals(Explicit)){
		                    	Explicit=Explicit.replaceAll(",", "");
		                        double test= Double.valueOf(UXUtility.checkNull(Explicit));
		                        explicitSum=explicitSum+test;
		                    }*/
		                    /*String maternitytableval=  rs1.getString("MAT_CPM");
		                    if(maternitytableval != null && !"NA".equals(maternitytableval) && !"".equals(maternitytableval)){
		                    	maternitytableval=maternitytableval.replaceAll(",", "");
		                        double test= Double.valueOf(UXUtility.checkNull(maternitytableval));
		                        maternitytablevalues=maternitytablevalues+test;
		                    }*/
		               /*     String includetableval=   rs1.getString("INCLU_MAT_CPM");
		                    if(includetableval != null && !"NA".equals(includetableval) && !"".equals(includetableval)){
		                    	includetableval=includetableval.replaceAll(",", "");
		                        double test= Double.valueOf(UXUtility.checkNull(includetableval));
		                        maternityIncludetablevalues=maternityIncludetablevalues+test;
		                    }
		                	*/
		                	
		                	
		                	
		  		          
		                	alTable1.add(tablevalues);
		                	}}
		          
		                
		            }
		                if(femaleMaternity != null){
			                while(femaleMaternity.next()){
			                	HashMap<String, String> tablevalues = new HashMap<String, String>();
			                	if((premium ==2 && maternity ==2)  || (premium ==3 && maternity ==2)){
			                	tablevalues.put("AgerangeId", (UXUtility.checkNull(String.valueOf(femaleMaternity.getString("AGE_RNG_SEQ_ID")))));
			                	tablevalues.put("Agerange", (UXUtility.checkNull(String.valueOf(femaleMaternity.getString("AGE_RANGE")))));
			                	tablevalues.put("Maternity", (UXUtility.checkNull(String.valueOf(femaleMaternity.getString("MAT_CPM")))));
			                	tablevalues.put("Gendersmaternity", (UXUtility.checkNull(String.valueOf(femaleMaternity.getString("GNDR_DESC")))));
			                	tablevalues.put("matlives", (UXUtility.checkNull(String.valueOf(femaleMaternity.getString("MAT_LIVES")))));
			                	
			                	 String maternit=  femaleMaternity.getString("MAT_CPM");
			                	  Integer matlives2=0;
				                    if(maternit != null || maternit != "NA"){
				                    	String maternityval2=femaleMaternity.getString("MAT_CPM");
				                    	maternityval2= maternityval2.replaceAll(",", "");
					                     Integer maternityvalue2=Integer.parseInt(maternityval2);
					                     String str_matlives2=femaleMaternity.getString("MAT_LIVES");
					                     str_matlives2= str_matlives2.replaceAll(",", "");
					                     matlives2=Integer.parseInt(str_matlives2);
					                    Integer summatentiy2=0;
					                    
					                    summatentiy2= summatentiy2+(maternityvalue2*matlives2);
					                    summatlives2 = summatlives2+matlives2;
					                    maternitysum2 = maternitysum2+summatentiy2;}
					                	
			                	alTable2.add(tablevalues);
			                	}
			                	
			                	
			                	
			                	
			                }
		            }
		                if(overallvalue != null){
			                while(overallvalue.next()){
			                	HashMap<String, String> tablevalues = new HashMap<String, String>();
			                	tablevalues.put("mainoverall", (UXUtility.checkNull(String.valueOf(overallvalue.getString("PREMIUM_PER_MEMBER")))));
			                	tablevalues.put("cpmseqid", (UXUtility.checkNull(String.valueOf(overallvalue.getString("FNL_CPM_SEQ_ID")))));
			                	tablevalues.put("maxageband", (UXUtility.checkNull(String.valueOf(overallvalue.getString("mat_ageband_max")))));
			                	alTable3.add(tablevalues);
			                	
			                	
			                }
		                }    
		                
		           }
			      
	             
		                if(sumotherlives1 != 0){
		                inPatientSum=totalsumInpatientother/sumotherlives1;
		                }
		                if(sumotherlives2!=0){
		   	           outPatientSum=totalsumoutpatientother/sumotherlives2;
		                }
		                if(sumotherlives3!=0){
		   	           opticalSum=totaloptical/sumotherlives3;
		                }
		                if(sumotherlives4!=0){
		   	           dentalsum=totaldental/sumotherlives4;
		                }
		              
		              
		                //opticalSum=totaloptical/sumotherlives;
		               // dentalsum=totaldental/sumotherlives;
		              
		                explicitSum=inPatientSum+outPatientSum+opticalSum+dentalsum;
		                
		                if(summatlives!=0){
		                	maternitytablevalues=maternitysum/summatlives;
		                	
		                	
		                }
		                maternityIncludetablevalues=inPatientSum+outPatientSum+opticalSum+dentalsum+maternitytablevalues;
		                if(summatlives2!=0){
		                	maternitytable=maternitysum2/summatlives2;
		                	
		                }
		              
		                
		                
		             
		               
		               String inPatientSumwithcomma= GrossDAOimpl.totalAmountWithComma(inPatientSum);
		               String outPatientSumSumwithcomma= GrossDAOimpl.totalAmountWithComma(outPatientSum);
		               String opticalSumwithcomma= GrossDAOimpl.totalAmountWithComma(opticalSum);
		               String dentalsumwithcomma= GrossDAOimpl.totalAmountWithComma(dentalsum);
		               String explicitSumwithcomma= GrossDAOimpl.totalAmountWithComma(explicitSum);
		               String maternitytablevaluesSumwithcomma= GrossDAOimpl.totalAmountWithComma(maternitytablevalues);
		               String maternitytableSumwithcomma= GrossDAOimpl.totalAmountWithComma(maternitytable);
		               String maternityIncludetablevaluesSumwithcomma= GrossDAOimpl.totalAmountWithComma(maternityIncludetablevalues);
		              
		               
		           
		            resultvalues.add(inPatientSumwithcomma);
		            resultvalues.add(outPatientSumSumwithcomma);
		            resultvalues.add(opticalSumwithcomma);
		            resultvalues.add(dentalsumwithcomma);
		            resultvalues.add(explicitSumwithcomma);
		            resultvalues.add(maternitytableSumwithcomma);
		        /*    resultvalues.add(maternitytablevalues);*/
		            resultvalues.add(maternitytablevaluesSumwithcomma);
		            resultvalues.add(maternityIncludetablevaluesSumwithcomma);
		            
		            table[0] =alTable1;
		            table[1] =alTable2;
		            table[2] =alTable3;
		            table[3] =tableDetails;
		            table[4] =resultvalues;
				return table;	
	    	}//end of try
		        }
		        
		
	public static String totalAmountWithComma(int amount){
		String val = String.valueOf(amount);
        
        
     StringBuilder   builder = new StringBuilder();
       
        for(int i=0; i< val.length(); i++) {
           
            if(val.length()==4) {
                if(i==0) {
                builder =    builder.append(val.charAt(i)).append(",");
                }else {
                    builder =    builder.append(val.charAt(i));
                }
            }
            else if(val.length()==5) {
                if(i==1) {
                builder =    builder.append(val.charAt(i)).append(",");
                }else {
                    builder =    builder.append(val.charAt(i));
                }
            }else if(val.length()==6) {
                if(i==0 || i==2) {
                builder =    builder.append(val.charAt(i)).append(",");
                }else {
                    builder =    builder.append(val.charAt(i));
                }
            }else if(val.length()==7) {
                if(i==1 || i==3) {
                builder =    builder.append(val.charAt(i)).append(",");
                }else {
                    builder =    builder.append(val.charAt(i));
                }
            }else if(val.length()==8) {
                if(i==0 || i==2 || i==4) {
                builder =    builder.append(val.charAt(i)).append(",");
                }else {
                    builder =    builder.append(val.charAt(i));
                }
            }else if(val.length()==9) {
                if(i==1 || i==3 || i==5) {
                builder =    builder.append(val.charAt(i)).append(",");
                }else {
                    builder =    builder.append(val.charAt(i));
                }
            }
           
            else {
                builder =    builder.append(val.charAt(i));
            }
        }
        return builder.toString();
	}
	


	@Override
	public InsPricingVO getfalgPricingvalue(long lpricingSeqId) throws Exception {
		Connection conn = null;
        PreparedStatement pStmt = null;
      
		InsPricingVO  insPricingVO =new InsPricingVO();
		try (Connection con = dataSource.getConnection();
				CallableStatement cStmtObject = (java.sql.CallableStatement) con.prepareCall(strPricingFlag);) {
			cStmtObject.setLong(1,lpricingSeqId);
			try(ResultSet  rs = cStmtObject.executeQuery();){
	          
	            if(rs != null){
	                while(rs.next()){
	                	insPricingVO =  new InsPricingVO();
	                	insPricingVO.setGroupProfileSeqID(lpricingSeqId);
	                	insPricingVO.setBenecoverFlagYN(UXUtility.checkNull(rs.getString("BENF_COV_SVE_YN")));
	                	insPricingVO.setCalCPMFlagYN(UXUtility.checkNull(rs.getString("CAL_CPM_SVE_YN")));
	                	insPricingVO.setLoadingFlagYN(UXUtility.checkNull(rs.getString("CAL_LODING_SVE_YN")));
	                	insPricingVO.setDemographicflagYN(UXUtility.checkNull(rs.getString("DMGRPHC_SAVE_YN")));
	                	insPricingVO.setPricingmodifyYN(UXUtility.checkNull(rs.getString("MODIFY_YN")));
	                	insPricingVO.setCompleteSaveYNInSc2(UXUtility.checkNull(rs.getString("CENSUS_SAVE_YN")));
	                	insPricingVO.setRiskPremiumDate(UXUtility.checkNull(rs.getString("ADDED_DATE")));
	                	insPricingVO.setBrokerflag(UXUtility.checkNull(rs.getString("BROKERING_TYPE")));
	                
	                	insPricingVO.setGrossclaulation(UXUtility.checkNull(rs.getString("cal_load_display_yn")));
	                	int trendfactor =  rs.getInt("TRND_FACTOR_PERC");
	                	
	                	if(trendfactor < 6){
	                		insPricingVO.setTrendFactor("Y");
	                	}else{
	                		insPricingVO.setTrendFactor("N");
	                	}
	              
	                
	                }//end of while(rs.next())
	            }//end of if(rs != null)
			}
	            return insPricingVO;
	        }//end of try
			
		
	
	}




public InsPricingVO getfalgPricingvaluetable(long lpricingSeqId) throws Exception {
	Connection conn = null;
    PreparedStatement pStmt = null;
    
	InsPricingVO  insPricingVO =new InsPricingVO();
	try (Connection con = dataSource.getConnection();
			CallableStatement cStmtObject = (java.sql.CallableStatement) con.prepareCall(strPricingFlagtable);) {
		cStmtObject.setLong(1,lpricingSeqId);
           try(ResultSet rs = cStmtObject.executeQuery();){
            if(rs != null){
                while(rs.next()){
                	insPricingVO =  new InsPricingVO();
                	insPricingVO.setGroupProfileSeqID(lpricingSeqId);
                	insPricingVO.setPrmiumtablevalue(UXUtility.checkNull(rs.getString("PREMIUM_OUTPUT_STRU")));
                	insPricingVO.setMaternitytablevalue(UXUtility.checkNull(rs.getString("MAT_PRICING_DISPLAY")));
               
                
                }//end of while(rs.next())
            }//end of if(rs != null)
           }
            return insPricingVO;
        }//end of try
		
	

}

@Override
public WhatifScreenVO getWhatifDetails(Long groupSeqId,Long varSeqId,Long verNo,String vrsionFlag) throws Exception {
	// TODO Auto-generated method stub
	
	WhatifScreenVO whatifScreenVO= new WhatifScreenVO();
	try (Connection con = dataSource.getConnection();
			CallableStatement cStmtObject = (java.sql.CallableStatement) con.prepareCall(strGetWhatifDetails);) {
		
		
		
		cStmtObject.setLong(1,groupSeqId);
		if(varSeqId == 0) {
			cStmtObject.setString(2,null);
		}else {
			cStmtObject.setLong(2,varSeqId);
		}
		
		cStmtObject.setLong(3,verNo);
		cStmtObject.setString(4,vrsionFlag);		
		cStmtObject.registerOutParameter(5,OracleTypes.CURSOR);
		cStmtObject.registerOutParameter(6,OracleTypes.CURSOR);
		cStmtObject.registerOutParameter(7,OracleTypes.CURSOR);
		cStmtObject.registerOutParameter(8,OracleTypes.CURSOR);
		cStmtObject.execute();
		try(ResultSet rs = (java.sql.ResultSet)cStmtObject.getObject(5);){
			if(rs != null){
				while(rs.next())
				{
					
					whatifScreenVO.setCoverdStartDatedes(UXUtility.checkNull(rs.getString("covrg_start_date")));
					whatifScreenVO.setCoverdEndDatedes(UXUtility.checkNull(rs.getString("covrg_end_date")));
					whatifScreenVO.setInpatientipdes(UXUtility.checkNull(rs.getString("ip_cov_yn")));
					whatifScreenVO.setOutpatientopdes(UXUtility.checkNull(rs.getString("op_cov_yn")));
					whatifScreenVO.setMaximumbenefitlimitdes(UXUtility.checkNull(rs.getString("ip_benf_limit")));
					whatifScreenVO.setMaxiOpLimitdes(UXUtility.checkNull(rs.getString("op_benf_limit")));
					
					
					whatifScreenVO.setAreaofcoverdes(UXUtility.checkNull(rs.getString("area_of_cover")));
					whatifScreenVO.setNetworkcommondes(UXUtility.checkNull(rs.getString("network")));
					whatifScreenVO.setNetworkcommonBenefitsdes(UXUtility.checkNull(rs.getString("NETWORK_BENF")));
					
					whatifScreenVO.setAreaofcovernextdes(UXUtility.checkNull(rs.getString("area_cov_variation")));
					whatifScreenVO.setLoadingforareaofcoverdes(UXUtility.checkNull(rs.getString("AREA_COV_LOAD")));
					whatifScreenVO.setDiscountforareaofcoverdes (UXUtility.checkNull(rs.getString("AREA_DISC_LOAD")));
					
					whatifScreenVO.setiPcopaydes(UXUtility.checkNull(rs.getString("ip_copay_perc")));
					whatifScreenVO.setoPcopaydeductibleapplicabledes(UXUtility.checkNull(rs.getString("op_cpy_dedct_all_op_yn")));
					whatifScreenVO.setoPCopayDeductibledes(UXUtility.checkNull(rs.getString("opt_copay_perc")));
					whatifScreenVO.setoPpharmacycopaydes(UXUtility.checkNull(rs.getString("op_copay_phm_perc")));
					whatifScreenVO.setoPinvestigationcopaydes(UXUtility.checkNull(rs.getString("op_copay_invst_perc")));
					whatifScreenVO.setoPconsultationcopaydes(UXUtility.checkNull(rs.getString("op_copay_con_perc")));					
					whatifScreenVO.setoPcopayonotherservicesdes(UXUtility.checkNull(rs.getString("op_copay_oth_perc")));
					
					
					whatifScreenVO.setOpticaldes(UXUtility.checkNull(rs.getString("optcl_cov_yn")));
					whatifScreenVO.setOpticallimitdes(UXUtility.checkNull(rs.getString("optical_limit")));
					whatifScreenVO.setOpticalCopaydes(UXUtility.checkNull(rs.getString("optcl_copay_perc")));
					
					whatifScreenVO.setFrameslimitdes(UXUtility.checkNull(rs.getString("optcl_frame_limit")));
					whatifScreenVO.setDentaldes(UXUtility.checkNull(rs.getString("dntl_cov_yn")));
					whatifScreenVO.setDentallimitdes(UXUtility.checkNull(rs.getString("dental_limit")));
					whatifScreenVO.setDentalcopaydeductibledes(UXUtility.checkNull(rs.getString("dnt_copay_perc")));
					
					whatifScreenVO.setAlAhliHospitalcoveragedes(UXUtility.checkNull(rs.getString("alhalli_cov_yn")));
					whatifScreenVO.setoPcopaydeductibleatAlAhlides(UXUtility.checkNull(rs.getString("op_cpy_alhalli_all_op_yn")));
					whatifScreenVO.setoPcopayatAlAhlides(UXUtility.checkNull(rs.getString("op_copay_alh_perc")));
					whatifScreenVO.setoPpharmacycopayatalAhlides(UXUtility.checkNull(rs.getString("op_copay_phm_alh_perc")));					
					whatifScreenVO.setoPinvestigationcopayatAlAhlides(UXUtility.checkNull(rs.getString("op_copay_invst_alh_perc")));
					whatifScreenVO.setoPconsultationcopayatAlAhlides(UXUtility.checkNull(rs.getString("op_copay_con_alh_perc")));
					whatifScreenVO.setoPotherservicescopayatAlAhlides(UXUtility.checkNull(rs.getString("op_copay_oth_alh_perc")));
					
					
					whatifScreenVO.setiPcopayatAlAhlides(UXUtility.checkNull(rs.getString("ip_copay_alh_perc")));
					whatifScreenVO.setAdditionalhospitalcoveragedes(UXUtility.checkNull(rs.getString("addi_hosp_cov_name")));
					whatifScreenVO.setLoadingforadditionalhospitalcoveragedes(UXUtility.checkNull(rs.getString("addi_hosp_load")));
					whatifScreenVO.setCommentsloadingforadditionaldes(UXUtility.checkNull(rs.getString("addi_hosp_cov_comment")));
					whatifScreenVO.setHospitalexclusionsdes(UXUtility.checkNull(rs.getString("exclu_hosp_cov_name")));
					whatifScreenVO.setDiscountforhospitalexclusionsdes(UXUtility.checkNull(rs.getString("exclu_hosp_disc")));
					whatifScreenVO.setCommentsdiscountforhospitaldes(UXUtility.checkNull(rs.getString("exclu_hosp_cov_comment")));
					
					
					whatifScreenVO.setCountryofresidencedes(UXUtility.checkNull(rs.getString("resident_country")));
					whatifScreenVO.setLoadingforcountryofresidencedes(UXUtility.checkNull(rs.getString("RES_CON_LOAD")));
					
					whatifScreenVO.setTrenddes(UXUtility.checkNull(rs.getString("trnd_factor_perc")));
					whatifScreenVO.setProratalimitapplicabledes(UXUtility.checkNull(rs.getString("pro_rata_limit_applica")));
					
					whatifScreenVO.setMaternitydes(UXUtility.checkNull(rs.getString("mat_cov_yn")));
					whatifScreenVO.setMaternitylimitdes (UXUtility.checkNull(rs.getString("maternity_limit")));
					whatifScreenVO.setMaternitycopaydeductibledes (UXUtility.checkNull(rs.getString("mat_copay_perc")));
					whatifScreenVO.setAreaCoverFlag(UXUtility.checkNull(rs.getString("area_cover_flag")));
					whatifScreenVO.setOrthodonticsdes(UXUtility.checkNull(rs.getString("ortho_copay_perc")));
					whatifScreenVO.setPremumrefundapproachdes(UXUtility.checkNull(rs.getString("REFUND_COND")));
					
					whatifScreenVO.setVersionCount(rs.getInt("total_version_cnt"));
					
				
					
					
				
				
																																																																																	 						
				}
			}
		}	try(ResultSet rs1 = (java.sql.ResultSet)cStmtObject.getObject(6);){
			if(rs1 != null){
				while(rs1.next())
				{
					
					whatifScreenVO.setVersionSeqId(rs1.getLong("VERSION_SEQ_ID"));
					whatifScreenVO.setGroupProSeqId(rs1.getLong("GRP_PROF_SEQ_ID"));
					
					whatifScreenVO.setCoverageStartDate((rs1.getString("COVRG_START_DATE")!=null ? new Date(rs1.getTimestamp("COVRG_START_DATE").getTime()):null));
					whatifScreenVO.setCoverageEndDate((rs1.getString("COVRG_END_DATE")!=null ? new Date(rs1.getTimestamp("COVRG_END_DATE").getTime()):null));
					whatifScreenVO.setInpatientip(rs1.getString("IP_COV_YN"));
					whatifScreenVO.setOutpatientop(UXUtility.checkNull(rs1.getString("OP_COV_YN")));
					whatifScreenVO.setMaximumbenefitlimit(rs1.getLong("IP_BENF_LIMIT_SEQ_ID"));
					whatifScreenVO.setOpLimit(rs1.getLong("OP_BENF_LIMIT_SEQ_ID"));
					whatifScreenVO.setAreaofcover(rs1.getLong("AREA_TYPE_SEQ_ID"));
					whatifScreenVO.setAreaofcovernext(UXUtility.checkNull(rs1.getString("AREA_COV_VARIATION")));
					whatifScreenVO.setLoadingforareaofcoverip(rs1.getLong("AREA_LOAD_IP"));
					whatifScreenVO.setLoadingforareaofcoverop(rs1.getLong("AREA_LOAD_OPT"));
					whatifScreenVO.setLoadingforareaofcoveropt(rs1.getLong("AREA_LOAD_OPTC"));
					whatifScreenVO.setLoadingforareaofcoverdent(rs1.getLong("AREA_LOAD_DENT"));
					whatifScreenVO.setLoadingforareaofcovermat(rs1.getLong("AREA_LOAD_MAT"));
					
					
					whatifScreenVO.setLoadingforareaofcoveriptemp(rs1.getLong("AREA_LOAD_IP"));
					whatifScreenVO.setLoadingforareaofcoveroptemp(rs1.getLong("AREA_LOAD_OPT"));
					whatifScreenVO.setLoadingforareaofcoveropttemp(rs1.getLong("AREA_LOAD_OPTC"));
					whatifScreenVO.setLoadingforareaofcoverdenttemp(rs1.getLong("AREA_LOAD_DENT"));
					whatifScreenVO.setLoadingforareaofcovermattemp(rs1.getLong("AREA_LOAD_MAT"));
					
					whatifScreenVO.setDiscountforareaofcoverip(rs1.getLong("AREA_DISC_IP"));
					whatifScreenVO.setDiscountforareaofcoverop(rs1.getLong("AREA_DISC_OPT"));
					whatifScreenVO.setDiscountforareaofcoveropt(rs1.getLong("AREA_DISC_OPTC"));
					whatifScreenVO.setDiscountforareaofcoverdent(rs1.getLong("AREA_DISC_DENT"));
					whatifScreenVO.setDiscountforareaofcovermat(rs1.getLong("AREA_DISC_MAT"));
					
					
					whatifScreenVO.setDiscountforareaofcoveriptemp(rs1.getLong("AREA_DISC_IP"));
					whatifScreenVO.setDiscountforareaofcoveroptemp(rs1.getLong("AREA_DISC_OPT"));
					whatifScreenVO.setDiscountforareaofcoveropttemp(rs1.getLong("AREA_DISC_OPTC"));
					whatifScreenVO.setDiscountforareaofcoverdenttemp(rs1.getLong("AREA_DISC_DENT"));
					whatifScreenVO.setDiscountforareaofcovermattemp(rs1.getLong("AREA_DISC_MAT"));
					
					whatifScreenVO.setNetworkcommon(rs1.getLong("NWK_TYPE_SEQ_ID"));
					whatifScreenVO.setiPcopay(rs1.getLong("IP_COPAY_TYPE_SEQ_ID"));
					whatifScreenVO.setiPcopaydesc(UXUtility.checkNull(rs1.getString("IP_COPAY_PERC")));
					whatifScreenVO.setoPcopaydeductibleapplicable(UXUtility.checkNull(rs1.getString("OP_CPY_DEDCT_ALL_OP_YN")));
					whatifScreenVO.setoPCopayDeductible(rs1.getLong("OPT_COPAY_TYPE_SEQ_ID"));
					whatifScreenVO.setoPCopayDeductibledesc(UXUtility.checkNull(rs1.getString("OPT_COPAY_PERC")));
					whatifScreenVO.setoPpharmacycopay(rs1.getLong("OP_COPAY_PHM_TYPE_SEQ_ID"));
					whatifScreenVO.setoPpharmacycopaydesc(UXUtility.checkNull(rs1.getString("OP_COPAY_PHM_PERC")));
					whatifScreenVO.setoPinvestigationcopay(rs1.getLong("OP_COPAY_INVST_TYPE_SEQ_ID"));
					whatifScreenVO.setoPinvestigationcopaydesc(UXUtility.checkNull(rs1.getString("OP_COPAY_INVST_PERC")));
					whatifScreenVO.setoPconsultationcopay(rs1.getLong("OP_COPAY_CON_TYPE_SEQ_ID"));
					whatifScreenVO.setoPconsultationcopaydesc(UXUtility.checkNull(rs1.getString("OP_COPAY_CON_PERC")));
					whatifScreenVO.setoPcopayonotherservices(rs1.getLong("OP_COPAY_OTH_TYPE_SEQ_ID"));
					whatifScreenVO.setoPcopayonotherservicesdesc(UXUtility.checkNull(rs1.getString("OP_COPAY_OTH_PERC")));	
					whatifScreenVO.setAlAhliHospitalcoverage(UXUtility.checkNull(rs1.getString("ALHALLI_COV_YN")));	
					whatifScreenVO.setoPcopaydeductibleatAlAhli(UXUtility.checkNull(rs1.getString("OP_CPY_ALHALLI_ALL_OP_YN")));	
					whatifScreenVO.setoPcopayatAlAhli(rs1.getLong("OP_COPAY_ALH_TYPE_SEQ_ID"));	
					whatifScreenVO.setoPcopayatAlAhlidesc(UXUtility.checkNull(rs1.getString("OP_COPAY_ALH_TYPE_SEQ_ID")));	
					whatifScreenVO.setoPpharmacycopayatalAhli(rs1.getLong("OP_COPAY_PHM_ALH_TYPE_SEQ_ID"));	
					whatifScreenVO.setoPpharmacycopayatalAhlidesc(UXUtility.checkNull(rs1.getString("OP_COPAY_PHM_ALH_PERC")));	
				/*	
					whatifScreenVO.setoPinvestigationcopayatAlAhli(rs1.getLong("OP_COPAY_IVST_ALH_TYP_SEQ_ID"));*/
					
					whatifScreenVO.setoPinvestigationcopayatAlAhlidesc(UXUtility.checkNull(rs1.getString("OP_COPAY_INVST_ALH_PERC")));
					
					whatifScreenVO.setoPconsultationcopayatAlAhli(rs1.getLong("OP_COPAY_CON_ALH_TYPE_SEQ_ID"));
					whatifScreenVO.setoPconsultationcopayatAlAhlidesc(UXUtility.checkNull(rs1.getString("OP_COPAY_CON_ALH_PERC")));
					whatifScreenVO.setoPconsultationcopayatAlAhli(rs1.getLong("OP_COPAY_CON_ALH_TYPE_SEQ_ID"));
					whatifScreenVO.setoPconsultationcopayatAlAhlidesc(UXUtility.checkNull(rs1.getString("OP_COPAY_CON_ALH_PERC")));
					
					whatifScreenVO.setoPotherservicescopayatAlAhli(rs1.getLong("OP_COPAY_OTH_ALH_TYPE_SEQ_ID"));
					whatifScreenVO.setoPotherservicescopayatAlAhlidesc(UXUtility.checkNull(rs1.getString("OP_COPAY_OTH_ALH_PERC")));
					
					whatifScreenVO.setiPcopayatAlAhli(rs1.getLong("IP_COPAY_ALH_TYPE_SEQ_ID"));
					whatifScreenVO.setiPcopayatAlAhlidesc(UXUtility.checkNull(rs1.getString("IP_COPAY_ALH_PERC")));
					whatifScreenVO.setAdditionalhospitalcoverage(rs1.getString("ADDI_HOSP_COV_SEQ"));
					whatifScreenVO.setAdditionalhospitalcoveragedesc(UXUtility.checkNull(rs1.getString("ADDI_HOSP_COV_NAME")));
					whatifScreenVO.setLoadingforadditionalhospitalcoverage(rs1.getLong("ADDI_HOSP_LOAD"));
					whatifScreenVO.setCommentsloadingforadditional(UXUtility.checkNull(rs1.getString("ADDI_HOSP_COV_COMMENT")));
					whatifScreenVO.setHospitalexclusions(UXUtility.checkNull(rs1.getString("EXCLU_HOSP_COV_SEQ")));
					whatifScreenVO.setHospitalexclusionsdesc(UXUtility.checkNull(rs1.getString("EXCLU_HOSP_COV_NAME")));
					whatifScreenVO.setDiscountforhospitalexclusions(rs1.getLong("EXCLU_HOSP_DISC"));					
					whatifScreenVO.setCommentsdiscountforhospital(UXUtility.checkNull(rs1.getString("EXCLU_HOSP_COV_COMMENT")));
					
					whatifScreenVO.setOptical(UXUtility.checkNull(rs1.getString("OPTCL_COV_YN")));
					whatifScreenVO.setOpticallimit(rs1.getLong("OPTCL_LIMIT_SEQ_ID"));
					whatifScreenVO.setOpticalcopay(rs1.getLong("OPTCL_COPAY_TYPE_SEQ_ID"));
					whatifScreenVO.setOpticalcopaydesc(UXUtility.checkNull(rs1.getString("OPTCL_COPAY_PERC")));
					whatifScreenVO.setFrameslimit(rs1.getLong("OPTCL_FRAMES_LIMIT_SEQ_ID"));
					whatifScreenVO.setDental(UXUtility.checkNull(rs1.getString("DNTL_COV_YN")));
					whatifScreenVO.setDentallimit(rs1.getLong("DENTL_LIMIT_SEQ_ID"));
					whatifScreenVO.setDentalcopaydeductible(rs1.getLong("DNT_COPAY_TYPE_SEQ_ID"));
					whatifScreenVO.setDentalcopaydeductibledesc(UXUtility.checkNull(rs1.getString("DNT_COPAY_PERC")));
					whatifScreenVO.setOrthodontics(UXUtility.checkNull(rs1.getString("ORTHO_COV_YN")));
					
					whatifScreenVO.setOrthodonticscopay(rs1.getLong("ORTHO_COPAY_TYPE_SEQ_ID"));
					whatifScreenVO.setOrthodonticscopaydesc(UXUtility.checkNull(rs1.getString("ORTHO_COPAY_PERC")));
					whatifScreenVO.setMaternity(UXUtility.checkNull(rs1.getString("MAT_COV_YN")));
					whatifScreenVO.setMaternitylimit(rs1.getLong("MAT_LIMIT_SEQ_ID"));
					whatifScreenVO.setMaternitycopaydeductible(rs1.getLong("MAT_COPAY_TYPE_SEQ_ID"));
					whatifScreenVO.setMaternitycopaydeductibledesc(UXUtility.checkNull(rs1.getString("MAT_COPAY_PERC")));
					
				
					
					if(rs1.getString("RES_CON_DESC") != null) {
					if(rs1.getString("RES_CON_DESC").equalsIgnoreCase("All")) {
						
						whatifScreenVO.setCountryofresidence(null);
					}else {
						whatifScreenVO.setCountryofresidence(rs1.getLong("RES_CONT_SEQ_ID"));
					}
					}else {
						whatifScreenVO.setCountryofresidence(rs1.getLong("RES_CONT_SEQ_ID"));
					}
					
					whatifScreenVO.setLoadingforcountryofresidenceip(rs1.getLong("RES_CONT_LOAD_IP"));
					whatifScreenVO.setLoadingforcountryofresidenceop(rs1.getLong("RES_CONT_LOAD_OPT"));
					whatifScreenVO.setLoadingforcountryofresidenceopt(rs1.getLong("RES_CONT_LOAD_OPTC"));
					whatifScreenVO.setLoadingforcountryofresidencedent(rs1.getLong("RES_CONT_LOAD_DENT"));
					whatifScreenVO.setLoadingforcountryofresidencemat(rs1.getLong("RES_CONT_LOAD_MAT"));
					
					whatifScreenVO.setTrend(rs1.getLong("TRND_FACTOR_PERC"));
					
					whatifScreenVO.setProratalimitapplicable(UXUtility.checkNull(rs1.getString("PRO_RATA_LIMIT_APPLICA")));
					whatifScreenVO.setPremumrefundapproach(UXUtility.checkNull(rs1.getString("REFUND_COND")));
					whatifScreenVO.setLastSaveDate(UXUtility.checkNull(rs1.getString("last_saved_date")));
					
					whatifScreenVO.setMaternityOtherLimit(UXUtility.checkNull(rs1.getString("MAT_OTH_LIMIT")));
										
					whatifScreenVO.setMaxiMumBenefitOtherLimit(UXUtility.checkNull(rs1.getString("IP_BENF_OTH_LIMIT")));
					whatifScreenVO.setOpLimitOtherLimit(UXUtility.checkNull(rs1.getString("OP_BENF_OTH_LIMIT")));
					whatifScreenVO.setOpticalOtherLimit(UXUtility.checkNull(rs1.getString("OPTCL_OTH_LIMIT")));
					whatifScreenVO.setDentalOtherLimit(UXUtility.checkNull(rs1.getString("DENTL_OTH_LIMIT")));
					
					
			
					
				}
			}
		}
		
		
		try(ResultSet rs2 = (java.sql.ResultSet)cStmtObject.getObject(7);){
			if(rs2 != null){
				while(rs2.next())
				{
		
				
				whatifScreenVO.setEstimateChangeip(UXUtility.checkNull(rs2.getString("ip_est_chng")));
				whatifScreenVO.setEstimateChangeOp(UXUtility.checkNull(rs2.getString("op_est_chng")));
				whatifScreenVO.setEstimateChangeOpt(UXUtility.checkNull(rs2.getString("optcl_est_chng")));
				whatifScreenVO.setEstimateChangeMen(UXUtility.checkNull(rs2.getString("mat_est_chng")));
				whatifScreenVO.setEstimateChangeDen(UXUtility.checkNull(rs2.getString("dntl_est_chng")));
				whatifScreenVO.setEstimateChangeOverAll(UXUtility.checkNull(rs2.getString("ovrl_est_chng")));
				whatifScreenVO.setEstimateChangeipmark(UXUtility.checkNull(rs2.getString("ip_est_mark")));
				whatifScreenVO.setEstimateChangeOpmark(UXUtility.checkNull(rs2.getString("op_est_mark")));
				whatifScreenVO.setEstimateChangeOptmark(UXUtility.checkNull(rs2.getString("optcl_est_mark")));
				whatifScreenVO.setEstimateChangeMenmark(UXUtility.checkNull(rs2.getString("mat_est_mark")));
				whatifScreenVO.setEstimateChangeDenmark(UXUtility.checkNull(rs2.getString("dntl_est_mark")));
				whatifScreenVO.setEstimateChangeOverAllmark(UXUtility.checkNull(rs2.getString("ovrl_est_mark")));
					
																																																																																	 						
				}
			}
		}try(ResultSet rs3 = (java.sql.ResultSet)cStmtObject.getObject(8);){
			if(rs3 != null){
				while(rs3.next())
				{
			
					
					
				
					
					whatifScreenVO.setCoverageStartDatestrColor(UXUtility.checkNull(rs3.getString("COVRG_START_DATE")));
					whatifScreenVO.setCoverageEndDatestrColor(UXUtility.checkNull(rs3.getString("COVRG_END_DATE")));
					whatifScreenVO.setInpatientipColor(UXUtility.checkNull(rs3.getString("IP_COV_YN")));
					whatifScreenVO.setOutpatientopColor(UXUtility.checkNull(rs3.getString("OP_COV_YN")));
					whatifScreenVO.setMaximumbenefitlimitColor(UXUtility.checkNull(rs3.getString("IP_BENF_LIMIT_SEQ_ID")));
					whatifScreenVO.setOpLimitColor(UXUtility.checkNull(rs3.getString("OP_BENF_LIMIT_SEQ_ID")));
					whatifScreenVO.setAreaofcoverColor(UXUtility.checkNull(rs3.getString("AREA_TYPE_SEQ_ID")));
					whatifScreenVO.setAreaofcovernextColor(UXUtility.checkNull(rs3.getString("AREA_COV_VARIATION")));
					whatifScreenVO.setLoadingforareaofcoveripColor(UXUtility.checkNull(rs3.getString("AREA_LOAD_IP")));
					whatifScreenVO.setLoadingforareaofcoveropColor(UXUtility.checkNull(rs3.getString("AREA_LOAD_OPT")));
					whatifScreenVO.setLoadingforareaofcoveroptColor(UXUtility.checkNull(rs3.getString("AREA_LOAD_OPTC")));
					whatifScreenVO.setLoadingforareaofcoverdentColor(UXUtility.checkNull(rs3.getString("AREA_LOAD_DENT")));
					whatifScreenVO.setLoadingforareaofcovermatColor(UXUtility.checkNull(rs3.getString("AREA_LOAD_MAT")));
					
					
					
					whatifScreenVO.setDiscountforareaofcoveripColor(UXUtility.checkNull(rs3.getString("AREA_DISC_IP")));
					whatifScreenVO.setDiscountforareaofcoveropColor(UXUtility.checkNull(rs3.getString("AREA_DISC_OPT")));
					whatifScreenVO.setDiscountforareaofcoveroptColor(UXUtility.checkNull(rs3.getString("AREA_DISC_OPTC")));
					whatifScreenVO.setDiscountforareaofcoverdentColor(UXUtility.checkNull(rs3.getString("AREA_DISC_DENT")));
					whatifScreenVO.setDiscountforareaofcovermatColor(UXUtility.checkNull(rs3.getString("AREA_DISC_MAT")));
					
					whatifScreenVO.setNetworkcommonColor(UXUtility.checkNull(rs3.getString("NWK_TYPE_SEQ_ID")));
					whatifScreenVO.setiPcopayColor(UXUtility.checkNull(rs3.getString("IP_COPAY_TYPE_SEQ_ID")));
					whatifScreenVO.setiPcopaydescColor(UXUtility.checkNull(rs3.getString("IP_COPAY_PERC")));
					whatifScreenVO.setoPcopaydeductibleapplicableColor(UXUtility.checkNull(rs3.getString("OP_CPY_DEDCT_ALL_OP_YN")));
					whatifScreenVO.setoPCopayDeductibleColor(UXUtility.checkNull(rs3.getString("OPT_COPAY_TYPE_SEQ_ID")));
					whatifScreenVO.setoPCopayDeductibledescColor(UXUtility.checkNull(rs3.getString("OPT_COPAY_PERC")));
					whatifScreenVO.setoPpharmacycopayColor(UXUtility.checkNull(rs3.getString("OP_COPAY_PHM_TYPE_SEQ_ID")));
					whatifScreenVO.setoPpharmacycopaydescColor(UXUtility.checkNull(rs3.getString("OP_COPAY_PHM_PERC")));
					whatifScreenVO.setoPinvestigationcopayColor(UXUtility.checkNull(rs3.getString("OP_COPAY_INVST_TYPE_SEQ_ID")));
					whatifScreenVO.setoPinvestigationcopaydescColor(UXUtility.checkNull(rs3.getString("OP_COPAY_INVST_PERC")));
					whatifScreenVO.setoPconsultationcopayColor(UXUtility.checkNull(rs3.getString("OP_COPAY_CON_TYPE_SEQ_ID")));
					whatifScreenVO.setoPconsultationcopaydescColor(UXUtility.checkNull(rs3.getString("OP_COPAY_CON_PERC")));
					whatifScreenVO.setoPcopayonotherservicesColor(UXUtility.checkNull(rs3.getString("OP_COPAY_OTH_TYPE_SEQ_ID")));
					whatifScreenVO.setoPcopayonotherservicesdescColor(UXUtility.checkNull(rs3.getString("OP_COPAY_OTH_PERC")));	
					whatifScreenVO.setAlAhliHospitalcoverageColor(UXUtility.checkNull(rs3.getString("ALHALLI_COV_YN")));	
					whatifScreenVO.setoPcopaydeductibleatAlAhliColor(UXUtility.checkNull(rs3.getString("OP_CPY_ALHALLI_ALL_OP_YN")));	
					whatifScreenVO.setoPcopayatAlAhliColor(UXUtility.checkNull(rs3.getString("OP_COPAY_ALH_TYPE_SEQ_ID")));	
					whatifScreenVO.setoPcopayatAlAhlidescColor(UXUtility.checkNull(rs3.getString("OP_COPAY_ALH_TYPE_SEQ_ID")));	
					whatifScreenVO.setoPpharmacycopayatalAhliColor(UXUtility.checkNull(rs3.getString("OP_COPAY_PHM_ALH_TYPE_SEQ_ID")));	
					whatifScreenVO.setoPpharmacycopayatalAhlidescColor(UXUtility.checkNull(rs3.getString("OP_COPAY_PHM_ALH_PERC")));	
				/*	
					whatifScreenVO.setoPinvestigationcopayatAlAhli(rs1.getLong("OP_COPAY_IVST_ALH_TYP_SEQ_ID"));*/
					
					whatifScreenVO.setoPinvestigationcopayatAlAhlidescColor(UXUtility.checkNull(rs3.getString("OP_COPAY_INVST_ALH_PERC")));
					
					whatifScreenVO.setoPconsultationcopayatAlAhliColor(UXUtility.checkNull(rs3.getString("OP_COPAY_CON_ALH_TYPE_SEQ_ID")));
					whatifScreenVO.setoPconsultationcopayatAlAhlidescColor(UXUtility.checkNull(rs3.getString("OP_COPAY_CON_ALH_PERC")));
					whatifScreenVO.setoPconsultationcopayatAlAhliColor(UXUtility.checkNull(rs3.getString("OP_COPAY_CON_ALH_TYPE_SEQ_ID")));
					whatifScreenVO.setoPconsultationcopayatAlAhlidescColor(UXUtility.checkNull(rs3.getString("OP_COPAY_CON_ALH_PERC")));
					
					whatifScreenVO.setoPotherservicescopayatAlAhliColor(UXUtility.checkNull(rs3.getString("OP_COPAY_OTH_ALH_TYPE_SEQ_ID")));
					whatifScreenVO.setoPotherservicescopayatAlAhlidesc(UXUtility.checkNull(rs3.getString("OP_COPAY_OTH_ALH_PERC")));
					
					whatifScreenVO.setiPcopayatAlAhliColor(UXUtility.checkNull(rs3.getString("IP_COPAY_ALH_TYPE_SEQ_ID")));
					whatifScreenVO.setiPcopayatAlAhlidescColor(UXUtility.checkNull(rs3.getString("IP_COPAY_ALH_PERC")));
					whatifScreenVO.setAdditionalhospitalcoverageColor(UXUtility.checkNull(rs3.getString("ADDI_HOSP_COV_SEQ")));
					whatifScreenVO.setAdditionalhospitalcoveragedescColor(UXUtility.checkNull(rs3.getString("ADDI_HOSP_COV_NAME")));
					whatifScreenVO.setLoadingforadditionalhospitalcoverageColor(UXUtility.checkNull(rs3.getString("ADDI_HOSP_LOAD")));
					whatifScreenVO.setCommentsloadingforadditionalColor(UXUtility.checkNull(rs3.getString("ADDI_HOSP_COV_COMMENT")));
					whatifScreenVO.setHospitalexclusionsColor(UXUtility.checkNull(rs3.getString("EXCLU_HOSP_COV_SEQ")));
					whatifScreenVO.setHospitalexclusionsdescColor(UXUtility.checkNull(rs3.getString("EXCLU_HOSP_COV_NAME")));
					whatifScreenVO.setDiscountforhospitalexclusionsColor(UXUtility.checkNull(rs3.getString("EXCLU_HOSP_DISC")));					
					whatifScreenVO.setCommentsdiscountforhospitalColor(UXUtility.checkNull(rs3.getString("EXCLU_HOSP_COV_COMMENT")));
					
					whatifScreenVO.setOpticalColor(UXUtility.checkNull(rs3.getString("OPTCL_COV_YN")));
					whatifScreenVO.setOpticallimitColor(UXUtility.checkNull(rs3.getString("OPTCL_LIMIT_SEQ_ID")));
					whatifScreenVO.setOpticalcopayColor(UXUtility.checkNull(rs3.getString("OPTCL_COPAY_TYPE_SEQ_ID")));
					whatifScreenVO.setOpticalcopaydescColor(UXUtility.checkNull(rs3.getString("OPTCL_COPAY_PERC")));
					whatifScreenVO.setFrameslimitColor(UXUtility.checkNull(rs3.getString("OPTCL_FRAMES_LIMIT_SEQ_ID")));
					whatifScreenVO.setDentalColor(UXUtility.checkNull(rs3.getString("DNTL_COV_YN")));
					whatifScreenVO.setDentallimitColor(UXUtility.checkNull(rs3.getString("DENTL_LIMIT_SEQ_ID")));
					whatifScreenVO.setDentalcopaydeductibleColor(UXUtility.checkNull(rs3.getString("DNT_COPAY_TYPE_SEQ_ID")));
					whatifScreenVO.setDentalcopaydeductibledescColor(UXUtility.checkNull(rs3.getString("DNT_COPAY_PERC")));
					whatifScreenVO.setOrthodonticsColor(UXUtility.checkNull(rs3.getString("ORTHO_COV_YN")));
					
					whatifScreenVO.setOrthodonticscopayColor(UXUtility.checkNull(rs3.getString("ORTHO_COPAY_TYPE_SEQ_ID")));
					whatifScreenVO.setOrthodonticscopaydescColor(UXUtility.checkNull(rs3.getString("ORTHO_COPAY_PERC")));
					whatifScreenVO.setMaternityColor(UXUtility.checkNull(rs3.getString("MAT_COV_YN")));
					whatifScreenVO.setMaternitylimitColor(UXUtility.checkNull(rs3.getString("MAT_LIMIT_SEQ_ID")));
					whatifScreenVO.setMaternitycopaydeductibleColor(UXUtility.checkNull(rs3.getString("MAT_COPAY_TYPE_SEQ_ID")));
					whatifScreenVO.setMaternitycopaydeductibledescColor(UXUtility.checkNull(rs3.getString("MAT_COPAY_PERC")));
					
					whatifScreenVO.setCountryofresidenceColor(UXUtility.checkNull(rs3.getString("RES_CONT_SEQ_ID")));
					
					whatifScreenVO.setLoadingforcountryofresidenceipColor(UXUtility.checkNull(rs3.getString("RES_CONT_LOAD_IP")));
					whatifScreenVO.setLoadingforcountryofresidenceopColor(UXUtility.checkNull(rs3.getString("RES_CONT_LOAD_OPT")));
					whatifScreenVO.setLoadingforcountryofresidenceoptColor(UXUtility.checkNull(rs3.getString("RES_CONT_LOAD_OPTC")));
					whatifScreenVO.setLoadingforcountryofresidencedentColor(UXUtility.checkNull(rs3.getString("RES_CONT_LOAD_DENT")));
					whatifScreenVO.setLoadingforcountryofresidencematColor(UXUtility.checkNull(rs3.getString("RES_CONT_LOAD_MAT")));
					
					whatifScreenVO.setTrendColor(UXUtility.checkNull(rs3.getString("TRND_FACTOR_PERC")));
					
					whatifScreenVO.setProratalimitapplicableColor(UXUtility.checkNull(rs3.getString("PRO_RATA_LIMIT_APPLICA")));
					whatifScreenVO.setPremumrefundapproachColor(UXUtility.checkNull(rs3.getString("REFUND_COND")));
					
					
				}
			}
		}
	}
	
	return whatifScreenVO;
}

@Override
public WhatifScreenVO saveEstimateChange(WhatifScreenVO whatifScreenVO) throws Exception {
	// TODO Auto-generated method stub
	WhatifScreenVO WhatifScreenVO = new WhatifScreenVO();
	
	try(Connection con = dataSource.getConnection();
			CallableStatement cStmtObject = (java.sql.CallableStatement)con.prepareCall(strSaveEstimateChange);){
		
	/*	System.out.println("1......."+whatifScreenVO.getVersionSeqId());
		System.out.println("2......."+whatifScreenVO.getGroupProSeqId());
		System.out.println("3......."+whatifScreenVO.getVersionVal());*/
			/*System.out.println("1......."+whatifScreenVO.getVersionSeqId());
			System.out.println("2......."+whatifScreenVO.getGroupProSeqId());
			System.out.println("3......."+whatifScreenVO.getVersionVal());
			System.out.println("4......."+whatifScreenVO.getCoverageStartDate());
			System.out.println("5......."+whatifScreenVO.getCoverageEndDate());
			System.out.println("6......."+whatifScreenVO.getInpatientip());
			System.out.println("7......."+whatifScreenVO.getOutpatientop());
			System.out.println("8......."+whatifScreenVO.getMaximumbenefitlimit());
			System.out.println("9......."+whatifScreenVO.getOpLimit());
			System.out.println("10......."+whatifScreenVO.getAreaofcover());
			System.out.println("11......."+whatifScreenVO.getAreaofcovernext());
			System.out.println("12......."+whatifScreenVO.getLoadingforareaofcoverip());
			System.out.println("13......."+whatifScreenVO.getLoadingforareaofcoverop());
			System.out.println("14......."+whatifScreenVO.getLoadingforareaofcoveropt());
			System.out.println("15......."+whatifScreenVO.getLoadingforareaofcoverdent());
			System.out.println("16......."+whatifScreenVO.getLoadingforareaofcovermat());
			System.out.println("17......."+whatifScreenVO.getDiscountforareaofcoverip());
			System.out.println("18......."+whatifScreenVO.getDiscountforareaofcoverop());
			System.out.println("19......."+whatifScreenVO.getDiscountforareaofcoveropt());
			System.out.println("20......."+whatifScreenVO.getDiscountforareaofcoverdent());
			System.out.println("21......."+whatifScreenVO.getDiscountforareaofcovermat());
			System.out.println("22......."+whatifScreenVO.getNetworkcommon());
			System.out.println("23......."+whatifScreenVO.getiPcopay());
			System.out.println("24......."+whatifScreenVO.getiPcopaydesc());
			System.out.println("25......."+whatifScreenVO.getoPcopaydeductibleapplicable());
			System.out.println("26......."+whatifScreenVO.getoPCopayDeductible());
			System.out.println("27......."+whatifScreenVO.getoPCopayDeductibledesc());
			System.out.println("28......."+whatifScreenVO.getoPpharmacycopay());
			System.out.println("29......."+whatifScreenVO.getoPpharmacycopaydesc());
			System.out.println("30......."+whatifScreenVO.getoPinvestigationcopay());
			System.out.println("31......."+whatifScreenVO.getoPinvestigationcopaydesc());
			System.out.println("32......."+whatifScreenVO.getoPconsultationcopay());
			System.out.println("33......."+whatifScreenVO.getoPconsultationcopaydesc());
			System.out.println("34......."+whatifScreenVO.getoPcopayonotherservices());
			System.out.println("35......."+whatifScreenVO.getoPcopayonotherservicesdesc());
			System.out.println("36......."+whatifScreenVO.getAlAhliHospitalcoverage());
			System.out.println("37......."+whatifScreenVO.getoPcopaydeductibleatAlAhli());
			System.out.println("38......."+whatifScreenVO.getoPcopayatAlAhli());
			System.out.println("39......."+whatifScreenVO.getoPcopayatAlAhlidesc());
			System.out.println("40......."+whatifScreenVO.getoPpharmacycopayatalAhli());
			System.out.println("41......."+whatifScreenVO.getoPpharmacycopayatalAhlidesc());
			System.out.println("42......."+whatifScreenVO.getoPinvestigationcopayatAlAhli());
			System.out.println("43......."+whatifScreenVO.getoPinvestigationcopayatAlAhlidesc());
			System.out.println("44......."+whatifScreenVO.getoPconsultationcopayatAlAhli());
			System.out.println("45......."+whatifScreenVO.getoPconsultationcopayatAlAhlidesc());
			System.out.println("46......."+whatifScreenVO.getoPotherservicescopayatAlAhli());
			System.out.println("47......."+whatifScreenVO.getoPotherservicescopayatAlAhlidesc());
			System.out.println("48......."+whatifScreenVO.getiPcopayatAlAhli());
			System.out.println("49......."+whatifScreenVO.getiPcopayatAlAhlidesc());
			System.out.println("50......."+whatifScreenVO.getAdditionalhospitalcoverage());
			System.out.println("51......."+whatifScreenVO.getAdditionalhospitalcoveragedesc());
			System.out.println("52......."+whatifScreenVO.getLoadingforadditionalhospitalcoverage());
			System.out.println("53......."+whatifScreenVO.getCommentsloadingforadditional());
			System.out.println("54......."+whatifScreenVO.getHospitalexclusions());
			System.out.println("55......."+whatifScreenVO.getHospitalexclusionsdesc());
			System.out.println("56......."+whatifScreenVO.getDiscountforhospitalexclusions());
			System.out.println("57......."+whatifScreenVO.getCommentsdiscountforhospital());
			System.out.println("58......."+whatifScreenVO.getOptical());
			System.out.println("59......."+whatifScreenVO.getOpticallimit());
			System.out.println("60......."+whatifScreenVO.getOpticalcopay());
			System.out.println("61......."+whatifScreenVO.getOpticalcopaydesc());
			System.out.println("62......."+whatifScreenVO.getFrameslimit());
			System.out.println("63......."+whatifScreenVO.getDental());
			System.out.println("64......."+whatifScreenVO.getDentallimit());
			System.out.println("65......."+whatifScreenVO.getDentalcopaydeductible());
			System.out.println("66......."+whatifScreenVO.getDentalcopaydeductibledesc());
			System.out.println("67......."+whatifScreenVO.getOrthodontics());
			System.out.println("68......."+whatifScreenVO.getOrthodonticscopay());
			System.out.println("69......."+whatifScreenVO.getOrthodonticscopaydesc());
			System.out.println("70......."+whatifScreenVO.getMaternity());
			System.out.println("71......."+whatifScreenVO.getMaternitylimit());
			System.out.println("72......."+whatifScreenVO.getMaternitycopaydeductible());
			System.out.println("73......."+whatifScreenVO.getMaternitycopaydeductibledesc());
			System.out.println("74......."+whatifScreenVO.getCountryofresidence());
			System.out.println("75......."+whatifScreenVO.getLoadingforcountryofresidenceip());
			System.out.println("76......."+whatifScreenVO.getLoadingforcountryofresidenceop());
			System.out.println("77......."+whatifScreenVO.getLoadingforcountryofresidenceopt());
			System.out.println("78......."+whatifScreenVO.getLoadingforcountryofresidencedent());
			System.out.println("79......."+whatifScreenVO.getLoadingforcountryofresidencemat());
			System.out.println("80......."+whatifScreenVO.getTrend());
			
			*/
			
			
		
		
		if(whatifScreenVO.getVersionSeqId() != null){
			cStmtObject.setLong(1,whatifScreenVO.getVersionSeqId());
           }
           else{
			cStmtObject.setLong(1,0);
           }//end of else
		if(whatifScreenVO.getGroupProSeqId() != null){
			cStmtObject.setLong(2,whatifScreenVO.getGroupProSeqId());
           }
           else{
			cStmtObject.setLong(2,0);
           }//end of else
		if(whatifScreenVO.getVersionVal() != null){
			cStmtObject.setLong(3,whatifScreenVO.getVersionVal());
           }
           else{
			cStmtObject.setLong(3,1);
           }//end of else
		
		 if(whatifScreenVO.getCoverageStartDate() != null){

			cStmtObject.setTimestamp(4,new Timestamp(whatifScreenVO.getCoverageStartDate().getTime()));//LETTER_DATE
         }//end of if(batchVO.getLetterDate() != null)
			else{
				cStmtObject.setTimestamp(4, null);//LETTER_DATE
         }//end of else
		 if(whatifScreenVO.getCoverageEndDate() != null){

				cStmtObject.setTimestamp(5,new Timestamp(whatifScreenVO.getCoverageEndDate().getTime()));//LETTER_DATE
	       }//end of if(batchVO.getLetterDate() != null)
		else{
					cStmtObject.setTimestamp(5, null);//LETTER_DATE
	        }//end of else
		 cStmtObject.setString(6,whatifScreenVO.getInpatientip());
		 cStmtObject.setString(7,whatifScreenVO.getOutpatientop());
		 if(whatifScreenVO.getMaximumbenefitlimit()!= null){
				cStmtObject.setLong(8,whatifScreenVO.getMaximumbenefitlimit());
	       }
		else{
					cStmtObject.setLong(8,0);
	        }//end of else
		 if(whatifScreenVO.getOpLimit()!= null){
				cStmtObject.setLong(9,whatifScreenVO.getOpLimit());
	       }
		else{
					cStmtObject.setLong(9,0);
	        }//end of else
		 if(whatifScreenVO.getAreaofcover()!= null){
				cStmtObject.setLong(10,whatifScreenVO.getAreaofcover());
	       }
		else{
					cStmtObject.setLong(10,0);
	        }//end of else
		 
		 cStmtObject.setString(11,whatifScreenVO.getAreaofcovernext());
		 
		 if(whatifScreenVO.getLoadingforareaofcoverip()!= null){
				cStmtObject.setLong(12,whatifScreenVO.getLoadingforareaofcoveriptemp());
	       }
		else{
					cStmtObject.setLong(12,0);
	        }//end of else
		 if(whatifScreenVO.getLoadingforareaofcoverop()!= null){
				cStmtObject.setLong(13,whatifScreenVO.getLoadingforareaofcoveroptemp());
	       }
		else{
					cStmtObject.setLong(13,0);
	        }//end of else
		 if(whatifScreenVO.getLoadingforareaofcoveropt()!= null){
				cStmtObject.setLong(14,whatifScreenVO.getLoadingforareaofcoveropttemp());
	       }
		else{
					cStmtObject.setLong(14,0);
	        }//end of else
		 if(whatifScreenVO.getLoadingforareaofcoverdent()!= null){
				cStmtObject.setLong(15,whatifScreenVO.getLoadingforareaofcoverdenttemp());
	       }
		else{
					cStmtObject.setLong(15,0);
	        }//end of else
		 if(whatifScreenVO.getLoadingforareaofcovermat()!= null){
				cStmtObject.setLong(16,whatifScreenVO.getLoadingforareaofcovermattemp());
	       }
		else{
					cStmtObject.setLong(16,0);
	        }//end of else
		 
		 if(whatifScreenVO.getDiscountforareaofcoverip()!= null){
				cStmtObject.setLong(17,whatifScreenVO.getDiscountforareaofcoveriptemp());
	       }
		else{
					cStmtObject.setLong(17,0);
	        }//end of else
		 
		 if(whatifScreenVO.getDiscountforareaofcoverop()!= null){
				cStmtObject.setLong(18,whatifScreenVO.getDiscountforareaofcoveroptemp());
	       }
		else{
					cStmtObject.setLong(18,0);
	        }//end of else
		 if(whatifScreenVO.getDiscountforareaofcoveropt()!= null){
				cStmtObject.setLong(19,whatifScreenVO.getDiscountforareaofcoveropttemp());
	       }
		else{
					cStmtObject.setLong(19,0);
	        }//end of else
		 if(whatifScreenVO.getDiscountforareaofcoverdent()!= null){
				cStmtObject.setLong(20,whatifScreenVO.getDiscountforareaofcoverdenttemp());
	       }
		else{
					cStmtObject.setLong(20,0);
	        }//end of else
		 
		 if(whatifScreenVO.getDiscountforareaofcovermat()!= null){
				cStmtObject.setLong(21,whatifScreenVO.getDiscountforareaofcovermattemp());
	       }
		else{
					cStmtObject.setLong(21,0);
	        }//end of else
		 
		 if(whatifScreenVO.getNetworkcommon()!= null){
				cStmtObject.setLong(22,whatifScreenVO.getNetworkcommon());
	       }
		else{
					cStmtObject.setLong(22,0);
	        }//end of else
		 
		 if(whatifScreenVO.getiPcopay()!= null){
				cStmtObject.setLong(23,whatifScreenVO.getiPcopay());
	       }
		else{
					cStmtObject.setLong(23,0);
	        }//end of else
		 
		 cStmtObject.setString(24,whatifScreenVO.getiPcopaydesc());
		 cStmtObject.setString(25,whatifScreenVO.getoPcopaydeductibleapplicable());
		 
		 if(whatifScreenVO.getoPCopayDeductible()!= null){
				cStmtObject.setLong(26,whatifScreenVO.getoPCopayDeductible());
	       }
		else{
					cStmtObject.setLong(26,0);
	        }//end of else
		 
		 cStmtObject.setString(27,whatifScreenVO.getoPCopayDeductibledesc());
		 
		 if(whatifScreenVO.getoPpharmacycopay()!= null){
				cStmtObject.setLong(28,whatifScreenVO.getoPpharmacycopay());
	       }
		else{
					cStmtObject.setLong(28,0);
	        }//end of else
		 
		 cStmtObject.setString(29,whatifScreenVO.getoPpharmacycopaydesc());
		 
		 if(whatifScreenVO.getoPinvestigationcopay()!= null){
				cStmtObject.setLong(30,whatifScreenVO.getoPinvestigationcopay());
	       }
		else{
					cStmtObject.setLong(30,0);
	        }//end of else
		 cStmtObject.setString(31,whatifScreenVO.getoPinvestigationcopaydesc());
		 
		 if(whatifScreenVO.getoPconsultationcopay()!= null){
				cStmtObject.setLong(32,whatifScreenVO.getoPconsultationcopay());
	       }
		else{
					cStmtObject.setLong(32,0);
	        }//end of else
		 cStmtObject.setString(33,whatifScreenVO.getoPconsultationcopaydesc());
		 
		 if(whatifScreenVO.getoPcopayonotherservices()!= null){
				cStmtObject.setLong(34,whatifScreenVO.getoPcopayonotherservices());
	       }
		else{
					cStmtObject.setLong(34,0);
	        }//end of else
		 
		 cStmtObject.setString(35,whatifScreenVO.getoPcopayonotherservicesdesc());
		 cStmtObject.setString(36,whatifScreenVO.getAlAhliHospitalcoverage());
		 cStmtObject.setString(37,whatifScreenVO.getoPcopaydeductibleatAlAhli());
		 
		 if(whatifScreenVO.getoPcopayatAlAhli()!= null){
				cStmtObject.setLong(38,whatifScreenVO.getoPcopayatAlAhli());
	       }
		else{
					cStmtObject.setLong(38,0);
	        }//end of else
		 cStmtObject.setString(39,whatifScreenVO.getoPcopayatAlAhlidesc());
		 
		 if(whatifScreenVO.getoPpharmacycopayatalAhli()!= null){
				cStmtObject.setLong(40,whatifScreenVO.getoPpharmacycopayatalAhli());
	       }
		else{
					cStmtObject.setLong(40,0);
	        }//end of else
		 cStmtObject.setString(41,whatifScreenVO.getoPpharmacycopayatalAhlidesc());
		 
		 if(whatifScreenVO.getoPinvestigationcopayatAlAhli()!= null){
				cStmtObject.setLong(42,whatifScreenVO.getoPinvestigationcopayatAlAhli());
	       }
		else{
					cStmtObject.setLong(42,0);
	        }//end of else
		 cStmtObject.setString(43,whatifScreenVO.getoPinvestigationcopayatAlAhlidesc());
		 
		 if(whatifScreenVO.getoPconsultationcopayatAlAhli()!= null){
				cStmtObject.setLong(44,whatifScreenVO.getoPconsultationcopayatAlAhli());
	       }
		else{
					cStmtObject.setLong(44,0);
	        }//end of else
		 
		 cStmtObject.setString(45,whatifScreenVO.getoPconsultationcopayatAlAhlidesc());
		 
		 if(whatifScreenVO.getoPotherservicescopayatAlAhli()!= null){
				cStmtObject.setLong(46,whatifScreenVO.getoPotherservicescopayatAlAhli());
	       }
		else{
					cStmtObject.setLong(46,0);
	        }//end of else
		 cStmtObject.setString(47,whatifScreenVO.getoPotherservicescopayatAlAhlidesc());
		 
		 if(whatifScreenVO.getiPcopayatAlAhli()!= null){
				cStmtObject.setLong(48,whatifScreenVO.getiPcopayatAlAhli());
	       }
		else{
					cStmtObject.setLong(48,0);
	        }//end of else
		 cStmtObject.setString(49,whatifScreenVO.getiPcopayatAlAhlidesc());
		 cStmtObject.setString(50,whatifScreenVO.getAdditionalhospitalcoverage());
		 cStmtObject.setString(51,whatifScreenVO.getAdditionalhospitalcoveragedesc());
		 
		 if(whatifScreenVO.getLoadingforadditionalhospitalcoverage()!= null){
				cStmtObject.setLong(52,whatifScreenVO.getLoadingforadditionalhospitalcoverage());
	       }
		else{
					cStmtObject.setLong(52,0);
	        }//end of else
		 cStmtObject.setString(53,whatifScreenVO.getCommentsloadingforadditional()); 
		 cStmtObject.setString(54,whatifScreenVO.getHospitalexclusions()); 		 
		 cStmtObject.setString(55,whatifScreenVO.getHospitalexclusionsdesc()); 
		 
		 if(whatifScreenVO.getDiscountforhospitalexclusions()!= null){
				cStmtObject.setLong(56,whatifScreenVO.getDiscountforhospitalexclusions());
	       }
		else{
					cStmtObject.setLong(56,0);
	        }//end of else
		 cStmtObject.setString(57,whatifScreenVO.getCommentsdiscountforhospital()); 
		 cStmtObject.setString(58,whatifScreenVO.getOptical()); 
		 
		 if(whatifScreenVO.getOpticallimit()!= null){
				cStmtObject.setLong(59,whatifScreenVO.getOpticallimit());
	       }
		else{
					cStmtObject.setString(59,null);
	        }//end of else
		 
		 if(whatifScreenVO.getOpticalcopay()!= null){
				cStmtObject.setLong(60,whatifScreenVO.getOpticalcopay());
	       }
		else{
					cStmtObject.setString(60,null);
	        }//end of else
		 cStmtObject.setString(61,whatifScreenVO.getOpticalcopaydesc()); 
		 
		 if(whatifScreenVO.getFrameslimit()!= null){
				cStmtObject.setLong(62,whatifScreenVO.getFrameslimit());
	       }
		else{
					cStmtObject.setString(62,null);
	        }//end of else
		 cStmtObject.setString(63,whatifScreenVO.getDental()); 
		 
		 if(whatifScreenVO.getDentallimit()!= null){
				cStmtObject.setLong(64,whatifScreenVO.getDentallimit());
	       }
		else{
					cStmtObject.setString(64,null);
	        }//end of else
		 if(whatifScreenVO.getDentalcopaydeductible()!= null){
				cStmtObject.setLong(65,whatifScreenVO.getDentalcopaydeductible());
	       }
		else{
					cStmtObject.setLong(65,0);
	        }//end of else
		 cStmtObject.setString(66,whatifScreenVO.getDentalcopaydeductibledesc()); 
		 cStmtObject.setString(67,whatifScreenVO.getOrthodontics()); 
		 if(whatifScreenVO.getOrthodonticscopay()!= null){
				cStmtObject.setLong(68,whatifScreenVO.getOrthodonticscopay());
	       }
		else{
					cStmtObject.setString(68,null);
	        }//end of else
		 cStmtObject.setString(69,whatifScreenVO.getOrthodonticscopaydesc()); 
		 cStmtObject.setString(70,whatifScreenVO.getMaternity()); 
		 if(whatifScreenVO.getMaternitylimit()!= null){
				cStmtObject.setLong(71,whatifScreenVO.getMaternitylimit());
	       }
		else{
					cStmtObject.setString(71,null);
	        }//end of else
		 if(whatifScreenVO.getMaternitycopaydeductible()!= null){
				cStmtObject.setLong(72,whatifScreenVO.getMaternitycopaydeductible());
	       }
		else{
					cStmtObject.setString(72,null);
	        }//end of else
		 cStmtObject.setString(73,whatifScreenVO.getMaternitycopaydeductibledesc()); 
		 
		 if(whatifScreenVO.getCountryofresidence()!= null){
				cStmtObject.setLong(74,whatifScreenVO.getCountryofresidence());
	       }
		else{
					cStmtObject.setString(74,null);//
	        }//end of else
		 
		 if(whatifScreenVO.getLoadingforcountryofresidenceip()!= null){
				cStmtObject.setLong(75,whatifScreenVO.getLoadingforcountryofresidenceip());
	       }
		else{
					cStmtObject.setString(75,null);//
					
	        }//end of else
		 if(whatifScreenVO.getLoadingforcountryofresidenceop()!= null){
				cStmtObject.setLong(76,whatifScreenVO.getLoadingforcountryofresidenceop());
	       }
		else{
					cStmtObject.setLong(76,0);
	        }//end of else
		 if(whatifScreenVO.getLoadingforcountryofresidenceopt()!= null){
				cStmtObject.setLong(77,whatifScreenVO.getLoadingforcountryofresidenceopt());
	       }
		else{
					cStmtObject.setLong(77,0);
	        }//end of else
		 if(whatifScreenVO.getLoadingforcountryofresidencedent()!= null){
				cStmtObject.setLong(78,whatifScreenVO.getLoadingforcountryofresidencedent());
	       }
		else{
					cStmtObject.setLong(78,0);
	        }//end of else
		 if(whatifScreenVO.getLoadingforcountryofresidencemat()!= null && !whatifScreenVO.getLoadingforcountryofresidencemat().equals("")){
				cStmtObject.setLong(79,whatifScreenVO.getLoadingforcountryofresidencemat());
	       }
		else{
					cStmtObject.setLong(79,0);
	        }//end of else
		 
		 if(whatifScreenVO.getTrend()!= null){
				cStmtObject.setLong(80,whatifScreenVO.getTrend());
	       }
		else{
					cStmtObject.setLong(80,0);
	        }//end of else
		 cStmtObject.setString(81,whatifScreenVO.getProratalimitapplicable()); 
		 cStmtObject.setString(82,whatifScreenVO.getPremumrefundapproach()); 
		 
		 if(whatifScreenVO.getMaternityOtherLimit() != null && !whatifScreenVO.getMaternityOtherLimit().equals("")){
				cStmtObject.setLong(83,Long.parseLong(whatifScreenVO.getMaternityOtherLimit()));
	       }
		else{
					cStmtObject.setLong(83,0);
	        }//end of else
		 
		 if(whatifScreenVO.getMaxiMumBenefitOtherLimit() != null && !whatifScreenVO.getMaxiMumBenefitOtherLimit().equals("")){
				cStmtObject.setLong(84,Long.parseLong(whatifScreenVO.getMaxiMumBenefitOtherLimit()));
	       }
		else{
					cStmtObject.setLong(84,0);
	        }//end of else
		 
		 if(whatifScreenVO.getOpLimitOtherLimit() != null && !whatifScreenVO.getOpLimitOtherLimit().equals("")){
				cStmtObject.setLong(85,Long.parseLong(whatifScreenVO.getOpLimitOtherLimit()));
	       }
		else{
					cStmtObject.setLong(85,0);
	        }//end of else
		 
		 if(whatifScreenVO.getOpticalOtherLimit() != null && !whatifScreenVO.getOpticalOtherLimit().equals("")){
				cStmtObject.setLong(86,Long.parseLong(whatifScreenVO.getOpticalOtherLimit()));
	       }
		else{
					cStmtObject.setLong(86,0);
	        }//end of else
		 if(whatifScreenVO.getDentalOtherLimit() != null && !whatifScreenVO.getOpticalOtherLimit().equals("")){
				cStmtObject.setLong(87,Long.parseLong(whatifScreenVO.getDentalOtherLimit()));
	       }
		else{
					cStmtObject.setLong(87,0);
	        }//end of else
		 
		 cStmtObject.registerOutParameter(88,Types.INTEGER);
		 cStmtObject.registerOutParameter(1,Types.INTEGER);
		 cStmtObject.registerOutParameter(3,Types.INTEGER);
		 cStmtObject.execute();
		 WhatifScreenVO.setResult(cStmtObject.getLong(88));
		 WhatifScreenVO.setVersionSeqId(cStmtObject.getLong(1));
		 WhatifScreenVO.setVersionVal(cStmtObject.getLong(3));
		
	
	    /* iResult = cStmtObject.getLong(83);	*/
	}
	return WhatifScreenVO;
}

@Override
public Long saveWhatifDetails(Long groupSeqId, Long varSeqId, Long verNo)
		throws Exception {
	// TODO Auto-generated method stub
	Long result = 0l;
	   try (Connection con = dataSource.getConnection();
				CallableStatement cStmtObject = (java.sql.CallableStatement) con.prepareCall(strSaveWhatIfDetails);) {
	
		
		 cStmtObject.setLong(1,varSeqId);
		 cStmtObject.setLong(2,groupSeqId);
		 cStmtObject.setLong(3,verNo);
		 cStmtObject.registerOutParameter(4,Types.INTEGER);
		 cStmtObject.execute();
	
		 result = cStmtObject.getLong(4);
	}
	
	return result;
}

@Override
public Long saveWhatIfDetailsChange(Long groupSeqId, Long varSeqId, Long verNo) throws Exception {
	// TODO Auto-generated method stub
	Long result = 0l;
	   try (Connection con = dataSource.getConnection();
				CallableStatement cStmtObject = (java.sql.CallableStatement) con.prepareCall(strSaveWhatIfDetailsChange);) {
	
		
		 cStmtObject.setLong(1,varSeqId);
		 cStmtObject.setLong(2,groupSeqId);
		 cStmtObject.setLong(3,verNo);
		 cStmtObject.registerOutParameter(4,Types.INTEGER);
		 cStmtObject.execute();
	
		 result = cStmtObject.getLong(4);
	}
	
	return result;
}

@Override
public WhatifScreenVO getVersionSeqId(Long groupSeqId,Long verNo) throws Exception {
	// TODO Auto-generated method stub
	WhatifScreenVO whatifScreenVO = null;
	try (Connection con = dataSource.getConnection();
			CallableStatement cStmtObject = (java.sql.CallableStatement) con.prepareCall(strGetVersion);) {
		
		cStmtObject.setLong(1,groupSeqId);
		cStmtObject.setLong(2,verNo);
		
		try(ResultSet  rs = cStmtObject.executeQuery();){
          
            if(rs != null){
                while(rs.next()){
                	whatifScreenVO = new WhatifScreenVO();
                	
                 
                	
                	whatifScreenVO.setVersionSeqId(rs.getLong("version_Seq_id"));
                	whatifScreenVO.setSaveYn(rs.getString("version_save_yn"));
                }
            }
		}
	
}
	return whatifScreenVO;
}
}

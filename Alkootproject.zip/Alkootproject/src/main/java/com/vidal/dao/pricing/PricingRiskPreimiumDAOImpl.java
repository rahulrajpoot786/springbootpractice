package com.vidal.dao.pricing;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.itextpdf.text.log.SysoCounter;
import com.vidal.command.pricing.InsPricingVO;
import com.vidal.command.pricing.SwPolicyConfigVO;
import com.vidal.command.pricing.SwPricingSummaryVO;
import com.vidal.common.UXUtility;

import oracle.jdbc.OracleTypes;

@Repository
public class PricingRiskPreimiumDAOImpl implements PricingRiskPreimiumDAO{

	@Autowired
	private DataSource dataSource;
	
	
	/*private static final String strPricingFlag ="SELECT DISTINCT G.BENF_COV_SVE_YN,G.CAL_CPM_SVE_YN,G.CAL_CPM_SVE1_YN,CAL_LODING_SVE_YN,DMGRPHC_SAVE_YN,TRND_FACTOR_PERC,NVL(F.MODIFY_YN,'Y') AS MODIFY_YN,NVL(CENSUS_SAVE_YN,'N') AS CENSUS_SAVE_YN,G.PAST_POLICY_RUN_DATE, to_char(NVL(nvl(G.PAST_POLICY_RUN_DATE,NVL(D.ADDED_DATE,D.UPDATED_DATE)),(select distinct nvl(d.added_date,d.updated_date) from APP.TPA_PRICING_PREV_POL_DATA d where rownum=1)),'dd-mm-yyyy') AS ADDED_DATE FROM APP.TPA_GROUP_PROFILE_DETAILS G LEFT OUTER JOIN APP.TPA_GROUP_FNL_CPM_DETAILS F ON (G.GRP_PROF_SEQ_ID=F.GRP_PROF_SEQ_ID) LEFT JOIN APP.TPA_PRICING_PREV_POL_DATA D ON (D.POLICY_NO=G.PREV_POLICY_NO) LEFT OUTER JOIN APP.TPA_GROPU_BNF_LIVS_COV_DETAILS H ON (G.GRP_PROF_SEQ_ID =H.GRP_PROF_SEQ_ID)  WHERE G.GRP_PROF_SEQ_ID =?";*/
	
	/*private static final String strPricingFlag ="SELECT DISTINCT G.BENF_COV_SVE_YN,G.CAL_CPM_SVE_YN,G.CAL_CPM_SVE1_YN,CAL_LODING_SVE_YN,DMGRPHC_SAVE_YN,TRND_FACTOR_PERC,NVL(F.MODIFY_YN,'Y') AS MODIFY_YN,CASE WHEN NVL(G.INPUT_SAVE_YN,'N')='Y' AND NVL(benf_cov_sve_yn, 'N')='Y' THEN 'Y' ELSE 'N' END AS CENSUS_SAVE_YN,G.PAST_POLICY_RUN_DATE, to_char(NVL(nvl(G.PAST_POLICY_RUN_DATE,NVL(D.ADDED_DATE,D.UPDATED_DATE)),(select distinct nvl(d.added_date,d.updated_date) from APP.TPA_PRICING_PREV_POL_DATA d where rownum=1)),'dd-mm-yyyy') AS ADDED_DATE FROM APP.TPA_GROUP_PROFILE_DETAILS G LEFT OUTER JOIN APP.TPA_GROUP_FNL_CPM_DETAILS F ON (G.GRP_PROF_SEQ_ID=F.GRP_PROF_SEQ_ID) LEFT JOIN APP.TPA_PRICING_PREV_POL_DATA D ON (D.POLICY_NO=G.PREV_POLICY_NO) LEFT OUTER JOIN APP.TPA_GROPU_BNF_LIVS_COV_DETAILS H ON (G.GRP_PROF_SEQ_ID =H.GRP_PROF_SEQ_ID)  WHERE G.GRP_PROF_SEQ_ID =?";*/
	private static final String strPricingFlag ="SELECT DISTINCT G.BENF_COV_SVE_YN, nvl(g.renewal_yn,'N') renewal_yn,G.CAL_CPM_SVE_YN,G.CAL_CPM_SVE1_YN,CAL_LODING_SVE_YN,DMGRPHC_SAVE_YN,TRND_FACTOR_PERC,NVL(F.MODIFY_YN,'Y') AS MODIFY_YN,CASE WHEN NVL(G.INPUT_SAVE_YN,'N')='Y' AND NVL(benf_cov_sve_yn, 'N')='Y' THEN 'Y' ELSE 'N' END AS CENSUS_SAVE_YN,G.PAST_POLICY_RUN_DATE, to_char(NVL(nvl(G.PAST_POLICY_RUN_DATE,NVL(D.ADDED_DATE,D.UPDATED_DATE)),(select distinct nvl(d.added_date,d.updated_date) from APP.TPA_PAST_POLICY_PRICING_DATA d where rownum=1)),'dd-mm-yyyy') AS ADDED_DATE, CASE WHEN G.PREV_POLICY_NO IS NULL THEN 'N' ELSE 'Y' END AS NOTE_FLAG FROM APP.TPA_GROUP_PROFILE_DETAILS_SPR G LEFT OUTER JOIN APP.TPA_GROUP_FNL_CPM_DETAILS F ON (G.GRP_PROF_SEQ_ID=F.GRP_PROF_SEQ_ID) LEFT JOIN APP.TPA_PAST_POLICY_PRICING_DATA D ON (D.POLICY_NUMBER=G.PREV_POLICY_NO) LEFT OUTER JOIN APP.TPA_GROPU_BNF_LIVS_DTLS_SPR  H ON (G.GRP_PROF_SEQ_ID =H.GRP_PROF_SEQ_ID)  WHERE G.GRP_PROF_SEQ_ID = ?"; 
	private static final String strDemographicOnsaveData="{CALL PRICING_APP_PKG.GET_DMGRPHC_DTLS_ON_SAVE(?,?)}";	
	private static final String strDemographicOnMasterData="{CALL PRICING_APP_PKG.GET_COV_DMGRPHC_DETAILS(?,?)}";
	private static final String strCPMAfterCal="{CALL PRICING_APP_PKG.GET_CPM_ON_CALC(?,?,?)}";
	private static final String strCPMBeforeCal="{CALL PRICING_APP_PKG.GET_PST_PROJ_DETAILS(?,?,?)}";
	private static final String strLoadingAfterCalc="{CALL PRICING_APP_PKG.GET_LODING_DETAILS(?,?)}";
	private static final String strMasterListValue="{CALL PRICING_APP_PKG.GET_IP_MSTR_DETAILS(?,?,?,?)}";//Master Details
	/*private static final String strCPMAfterCalLoading="{CALL PRICING_APP_PKG.GET_FINAL_PREMIUM(?,?,?)}";*/
	private static final String strCPMAfterCalLoading="{CALL PRICING_APP_PKG.get_risk_final_premium(?,?,?)}";
	private static final String strSaveCalulatePricingList="{CALL PRICING_APP_PKG.RATE_CALCULATION(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}";
	private static final String strSaveDemographicData="{CALL PRICING_APP_PKG.SAVE_DMGRPHC_DETAILS(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}";
	private static final String strSaveRateCalculationFnl ="{CALL PRICING_APP_PKG.rate_calculation_fnl(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}";
	
	private static final String strRateCalcProjClm ="{CALL PRICING_APP_PKG.rate_calc_proj_clm(?)}";
	private static final String strCommentSave="update app.tpa_group_profile_details a set a.risk_prem_work_comments=?where a.grp_prof_seq_id=?";
	private static final String strSelectComment="select risk_prem_work_comments, past_policy_run_date from tpa_group_profile_details_spr a where a.grp_prof_seq_id=?";
	private static final String strGetPraposedPolicyFlag="select nvl(a.cal_cpm_sve1_yn,'N') cal_cpm_sve1_yn from app.tpa_group_profile_details_spr a where A.GRP_PROF_SEQ_ID=?";
	
	
	@Override
	public InsPricingVO getfalgPricingvalue(long lpricingSeqId) throws Exception {
		// TODO Auto-generated method stub
		InsPricingVO  insPricingVO =new InsPricingVO();
		try(Connection con = dataSource.getConnection();
				PreparedStatement pStmtObject = con.prepareStatement(strPricingFlag);){
			pStmtObject.setLong(1,lpricingSeqId);
			try(ResultSet rs = pStmtObject.executeQuery();){
				if(rs != null){
					while(rs.next())
					{
						insPricingVO =  new InsPricingVO();
	                	insPricingVO.setGroupProfileSeqID(lpricingSeqId);
	                	/*System.out.println("BENF_COV_SVE_YN..."+UXUtility.checkNull(rs.getString("BENF_COV_SVE_YN")));
	                	System.out.println("CAL_CPM_SVE_YN..."+UXUtility.checkNull(rs.getString("CAL_CPM_SVE_YN")));
	                	System.out.println("CAL_LODING_SVE_YN..."+UXUtility.checkNull(rs.getString("CAL_LODING_SVE_YN")));
	                	System.out.println("DMGRPHC_SAVE_YN..."+UXUtility.checkNull(rs.getString("DMGRPHC_SAVE_YN")));
	                	System.out.println("MODIFY_YN..."+UXUtility.checkNull(rs.getString("MODIFY_YN")));
	                	System.out.println("CENSUS_SAVE_YN..."+UXUtility.checkNull(rs.getString("CENSUS_SAVE_YN")));
	                	System.out.println("ADDED_DATE..."+UXUtility.checkNull(rs.getString("ADDED_DATE")));*/
	                	
	                	
	                	insPricingVO.setBenecoverFlagYN(UXUtility.checkNull(rs.getString("BENF_COV_SVE_YN")));
	                	insPricingVO.setCalCPMFlagYN(UXUtility.checkNull(rs.getString("CAL_CPM_SVE1_YN")));
	                /*	insPricingVO.setCalCPMFlagYN(UXUtility.checkNull(rs.getString("CAL_CPM_SVE_YN")));*/
	                	insPricingVO.setLoadingFlagYN(UXUtility.checkNull(rs.getString("CAL_LODING_SVE_YN")));
	                	insPricingVO.setDemographicflagYN(UXUtility.checkNull(rs.getString("DMGRPHC_SAVE_YN")));
	                	insPricingVO.setPricingmodifyYN(UXUtility.checkNull(rs.getString("MODIFY_YN")));
	                	insPricingVO.setCompleteSaveYNInSc2(UXUtility.checkNull(rs.getString("CENSUS_SAVE_YN")));
	                	insPricingVO.setRiskPremiumDate(UXUtility.checkNull(rs.getString("ADDED_DATE")));
	                	insPricingVO.setRenevalFlag(UXUtility.checkNull(rs.getString("renewal_yn")));
	                	insPricingVO.setCopydataflag(UXUtility.checkNull(rs.getString("NOTE_FLAG")));
	                	
	                	
	                	
	                	int trendfactor =  rs.getInt("TRND_FACTOR_PERC");
	                	
	                	
	                	if(trendfactor < 6){
	                		insPricingVO.setTrendFactor("Y");
	                	}else{
	                		insPricingVO.setTrendFactor("N");
	                	}
						
					}
				}
			}
			
		}
		return insPricingVO;
	}

	@Override
	public ArrayList getdemographicData(InsPricingVO insPricingVO, String demographicDataFlag) throws Exception {
		// TODO Auto-generated method stub
		
		String Query="";
		 SwPolicyConfigVO swPolicyConfigVO = null;
		 Collection<Object> alResultList = new ArrayList<Object>();
	   if(demographicDataFlag.equalsIgnoreCase("Y")) {
		   System.out.println("test... if..");
		   Query = strDemographicOnsaveData;		   
	   }else {
		   System.out.println("test... else..");
		   Query = strDemographicOnMasterData;
	   }
		
	
		try(Connection con = dataSource.getConnection();
				CallableStatement cStmtObject = (java.sql.CallableStatement)con.prepareCall(Query);){
			
			cStmtObject.setLong(1,insPricingVO.getGroupProfileSeqID());
			cStmtObject.registerOutParameter(2,OracleTypes.CURSOR);
			cStmtObject.execute();
			try(ResultSet rs1 = (java.sql.ResultSet)cStmtObject.getObject(2);){
				if(rs1 != null){
					while(rs1.next())
					{
						/*System.out.println("data type..."+rs1.getString("DATA_TYPE"));*/
				    	swPolicyConfigVO = new SwPolicyConfigVO();
	                	swPolicyConfigVO.setLngGroupProfileSeqID(insPricingVO.getGroupProfileSeqID());
	                	swPolicyConfigVO.setAddedBy(insPricingVO.getAddedBy());	                		                	                		                	                	
	                	
	                	swPolicyConfigVO.setDemoSlNo(UXUtility.checkNull(rs1.getString("SL_NO")));
	                	
	                	swPolicyConfigVO.setDemographicSeqId(rs1.getLong("DMGRPHCS_SEQ_ID"));
	                	swPolicyConfigVO.setDemodataType(UXUtility.checkNull(rs1.getString("DATA_TYPE")));
	                	
	                	swPolicyConfigVO.setClientCode(UXUtility.checkNull(rs1.getString("CLIENT_CODE")));
	                  	swPolicyConfigVO.setDemoPolicyNo(UXUtility.checkNull(rs1.getString("POLICY_NO")));	                
	                	swPolicyConfigVO.setDemoEffectiveYear(UXUtility.checkNull(rs1.getString("EFFECTIVE_YEAR"))); 
	                	if(rs1.getString("POL_EFFECTIVE_DATE") != null){
				        swPolicyConfigVO.setDemoPolicyEffDate(UXUtility.checkNull(rs1.getString("POL_EFFECTIVE_DATE")));
			             }
			             if(rs1.getString("POL_EXPIRE_DATE") != null){
				         swPolicyConfigVO.setDemoPolicyExpDate(UXUtility.checkNull(rs1.getString("POL_EXPIRE_DATE")));
			             }			            
			             
			             if(rs1.getString("POL_DURATION_MONTH") != null){
		                		swPolicyConfigVO.setDemoPolicyDurationPerMonth(UXUtility.checkNull(rs1.getString("POL_DURATION_MONTH"))); 
		    				}
			             
			             if(rs1.getString("NO_LIVES") != null){
		                		swPolicyConfigVO.setDemoNoOfLives(UXUtility.checkNull(rs1.getString("NO_LIVES"))); 
		    				}
		             
			             
			             if(rs1.getString("tot_lives") != null){
		                		swPolicyConfigVO.setDemoNoOfLivesdesc(UXUtility.checkNull(rs1.getString("tot_lives"))); 
		    				}
	                	if(rs1.getString("ALRT_MSG") != null){
	                		swPolicyConfigVO.setDemoAlertMsg(UXUtility.checkNull(rs1.getString("ALRT_MSG"))); 
	    				}
	                	
	                	if(rs1.getString("AVG_AGE") != null){
	                		swPolicyConfigVO.setDemoAverageAge(UXUtility.checkNull(rs1.getString("AVG_AGE"))); 
	    				}
	                	
	                	if(rs1.getString("tot_mat_avg_age") != null){
	                		swPolicyConfigVO.setDemoAverageAgedesc(UXUtility.checkNull(rs1.getString("tot_mat_avg_age"))); 
	    				}
	                	if(rs1.getString("NATIONALITY") != null){
	                		swPolicyConfigVO.setDemoNationality(UXUtility.checkNull(rs1.getString("NATIONALITY"))); 
	    				}
	                	
	                	if(rs1.getString("AREA_COV") != null){
	                		swPolicyConfigVO.setDemoAreaOfCover(UXUtility.checkNull(rs1.getString("AREA_COV"))); 
	    				}
	                	if(rs1.getString("NWK_TYPE") != null){
	                		swPolicyConfigVO.setDemoNetwork(UXUtility.checkNull(rs1.getString("NWK_TYPE"))); 
	    				}
	                	
	                	if(rs1.getString("MBL") != null){
	                		swPolicyConfigVO.setDemoMaximumBenfitLimit(UXUtility.checkNull(rs1.getString("MBL"))); 
	    				}
	                	if(rs1.getString("OP_COPAY") != null){
		                	swPolicyConfigVO.setDemoOpCopay(UXUtility.checkNull(rs1.getString("OP_COPAY"))); 
	    				}
	                	if(rs1.getString("OP_DEDUCTBL") != null){
		                	swPolicyConfigVO.setDemoOPDeductable(UXUtility.checkNull(rs1.getString("OP_DEDUCTBL"))); 
	    				}
	              
	                	if(rs1.getString("MAT_COV") != null){
	                		swPolicyConfigVO.setDemoMaternityCoverage(UXUtility.checkNull(rs1.getString("MAT_COV"))); 
	    				}
	                	if(rs1.getString("MAT_LIMIT") != null){
	                		swPolicyConfigVO.setDemoMaternityLimit(UXUtility.checkNull(rs1.getString("MAT_LIMIT"))); 
	    				}
	                	if(rs1.getString("OPTL_COV") != null){
	                		swPolicyConfigVO.setDemoOpticalCoverage(UXUtility.checkNull(rs1.getString("OPTL_COV"))); 
	    				}
	                	if(rs1.getString("OPTL_LIMIT") != null){
	                		swPolicyConfigVO.setDemoOpticalLimit(UXUtility.checkNull(rs1.getString("OPTL_LIMIT"))); 
	    				}
	                	if(rs1.getString("OPTL_COPAY") != null){
	                		swPolicyConfigVO.setDemoOpticalCopay(UXUtility.checkNull(rs1.getString("OPTL_COPAY"))); 
	    				}
	                	if(rs1.getString("DNT_COV") != null){
	                		swPolicyConfigVO.setDemoDentalCoverage(UXUtility.checkNull(rs1.getString("DNT_COV"))); 
	    				}
	                	if(rs1.getString("DNT_LIMIT") != null){
	                		swPolicyConfigVO.setDemoDentalLimit(UXUtility.checkNull(rs1.getString("DNT_LIMIT"))); 
	    				}
	                	if(rs1.getString("DNT_COPAY") != null){
	                		swPolicyConfigVO.setDemoDentalCopay(UXUtility.checkNull(rs1.getString("DNT_COPAY"))); 
	    				}
	                   
	                	if(rs1.getString("ALHALLI_COV") != null){
	                		swPolicyConfigVO.setDemoAlahli(UXUtility.checkNull(rs1.getString("ALHALLI_COV"))); 
	    				}
	                	
	                	swPolicyConfigVO.setMaternityEligibleMembers(UXUtility.checkNull(rs1.getString("MAT_COV_LIVES"))); 
	                	/*swPolicyConfigVO.setOpLimit(UXUtility.checkNull(rs1.getString("OP_LIMIT"))); */
	                	
	                	swPolicyConfigVO.setArealOfVariations(UXUtility.checkNull(rs1.getString("AREA_COV_VARIATION"))); 
	                	
	                	swPolicyConfigVO.setLoadingForAreaOfCoverVariations(UXUtility.checkNull(rs1.getString("AREA_COV_LOAD"))); 
	                	
	                	swPolicyConfigVO.setDiscountForAreavariations(UXUtility.checkNull(rs1.getString("AREA_COV_DESC"))); 
	                	
	                	swPolicyConfigVO.setiPCopay(UXUtility.checkNull(rs1.getString("IP_COPAY_PREC"))); 
	                	swPolicyConfigVO.setAlAhliHospitalcoverage(UXUtility.checkNull(rs1.getString("ALAHLI_COV_DESC"))); 
	                	swPolicyConfigVO.setiPCopayAtAlAhli(UXUtility.checkNull(rs1.getString("IP_COPAY_ALH_PERC"))); 
	                	
	                	swPolicyConfigVO.setAdditionalHospitalCoverage(UXUtility.checkNull(rs1.getString("ADDI_HOSP_COV_NAME"))); 
	                	swPolicyConfigVO.setLoadingForAdditionalHospitalCoverage(UXUtility.checkNull(rs1.getString("ADDI_HOSP_LOAD")));
	                	swPolicyConfigVO.setHospitalExclusions(UXUtility.checkNull(rs1.getString("EXCLU_HOSP_COV_NAME")));
	                	swPolicyConfigVO.setDiscountForHospitalExclusions(UXUtility.checkNull(rs1.getString("EXCLU_HOSP_DISC")));
	                	swPolicyConfigVO.setOpticalCoverage(UXUtility.checkNull(rs1.getString("OPTCL_COV_DESC")));
	                	swPolicyConfigVO.setFramesLimit(UXUtility.checkNull(rs1.getString("OPTICAL_FRAME_LIMIT")));
	                	swPolicyConfigVO.setDentalCoverage(UXUtility.checkNull(rs1.getString("DNTL_COV_DESC")));
	                	swPolicyConfigVO.setOrthodonticsCoverage(UXUtility.checkNull(rs1.getString("ORTHO_COV_DESC")));
	                	swPolicyConfigVO.setOrthodonticsCopay(UXUtility.checkNull(rs1.getString("ORTHO_COPAY_PERC")));
	                	swPolicyConfigVO.setMaternityCoverage(UXUtility.checkNull(rs1.getString("MAT_COV_DESC")));
	                	swPolicyConfigVO.setResidencyCountry(UXUtility.checkNull(rs1.getString("COUNTRY_NAME")));
	                	swPolicyConfigVO.setLoadingForResidencyCountry(UXUtility.checkNull(rs1.getString("RES_CONT_LOAD")));
	                	swPolicyConfigVO.setOtherKeyCoveragesComments(UXUtility.checkNull(rs1.getString("COVRG_REMARKS")));
	                 	swPolicyConfigVO.setProrataLimits(UXUtility.checkNull(rs1.getString("PRO_RATA_LIMIT")));
	                	swPolicyConfigVO.setPremiumRefundLogic(UXUtility.checkNull(rs1.getString("PREM_LOG_REFUND")));
	                	swPolicyConfigVO.setDemoInpatientcoverage(UXUtility.checkNull(rs1.getString("IP_COV_DESC")));
	                	swPolicyConfigVO.setDemoOutpatientcoverage(UXUtility.checkNull(rs1.getString("OP_COV_DESC")));
	                	
	                	System.out.println("...in patent ..."+rs1.getString("IP_COV_DESC"));
	                	System.out.println("...out patent ..."+rs1.getString("OP_COV_DESC"));
	                	
	                	
	                	System.out.println("Duration (mnths)..."+rs1.getString("POL_DURATION_MONTH"));
	                	System.out.println("Lives....."+rs1.getString("tot_lives"));
	                	System.out.println("Avg age ..."+rs1.getString("tot_mat_avg_age"));
	                	
	                	System.out.println("Nationality..."+rs1.getString("NATIONALITY"));
	                	System.out.println("Network..."+rs1.getString("NWK_TYPE"));
	                	System.out.println("Inpatient..."+rs1.getString("IP_COV_DESC"));
	                	System.out.println("Outpatient..."+rs1.getString("OP_COV_DESC"));
	                	System.out.println("Optical..."+rs1.getString("OPTCL_COV_DESC"));
	                	System.out.println("Dental..."+rs1.getString("DNTL_COV_DESC"));
	                	System.out.println("Maternity..."+rs1.getString("MAT_COV_DESC"));
	                	System.out.println("Area of cover..."+rs1.getString("AREA_COV_VARIATION"));
	                	System.out.println("Loading/Discount..."+rs1.getString("AREA_COV_LOAD"));
	                	System.out.println("Al Ahli hospital..."+rs1.getString("ALAHLI_COV_DESC"));
	                	System.out.println("Additional hospital..."+rs1.getString("ADDI_HOSP_COV_NAME"));
	                	System.out.println("Hospital exclusions ..."+rs1.getString("EXCLU_HOSP_COV_NAME"));
	                	
	                	System.out.println("Residency Country ..."+rs1.getString("COUNTRY_NAME"));
	                	System.out.println("Pro-rata limit ..."+rs1.getString("PRO_RATA_LIMIT"));
	                	System.out.println("Premium refund logic ..."+rs1.getString("PREM_LOG_REFUND"));
	                	
	                   
	                	alResultList.add(swPolicyConfigVO);
						
					}
				}
			}
		}
		
		
		
		return (ArrayList)alResultList;
	}

	@Override
	public ArrayList getcpmAfterCalcultion(InsPricingVO insPricingVO) throws Exception {
		// TODO Auto-generated method stub
		  SwPolicyConfigVO swPolicyConfigVO = null;
		  Collection<Object> alResultList = new ArrayList<Object>();
		  Collection<Object> alResultList1 = new ArrayList<Object>();
		  ArrayList result=new ArrayList();
		try(Connection con = dataSource.getConnection();
				CallableStatement cStmtObject = (java.sql.CallableStatement)con.prepareCall(strCPMAfterCal);){
			cStmtObject.setLong(1,insPricingVO.getGroupProfileSeqID());
			cStmtObject.registerOutParameter(2,OracleTypes.CURSOR);
			cStmtObject.registerOutParameter(3,OracleTypes.CURSOR);
			cStmtObject.execute();
			try(ResultSet rs1 = (java.sql.ResultSet)cStmtObject.getObject(2);){
				if(rs1 != null){
					while(rs1.next())
					{
						swPolicyConfigVO = new SwPolicyConfigVO();
	                    System.out.println("DATA_TYPE....1.."+rs1.getString("DATA_TYPE"));  																							                
	                	
	                	swPolicyConfigVO.setLngGroupProfileSeqID(rs1.getLong("GRP_PROF_SEQ_ID"));
	                	swPolicyConfigVO.setCpmSeqID(rs1.getLong("CPM_SEQ_ID"));
	                	swPolicyConfigVO.setAddedBy(insPricingVO.getAddedBy());
	                	swPolicyConfigVO.setSlNo(UXUtility.checkNull(rs1.getString("SL_NO")));
	                	
	                	swPolicyConfigVO.setDataType(UXUtility.checkNull(rs1.getString("DATA_TYPE")));
	                	swPolicyConfigVO.setPolicyNo(UXUtility.checkNull(rs1.getString("POLICY_NO")));
	                	swPolicyConfigVO.setClientCode(UXUtility.checkNull(rs1.getString("CLIENT_CODE")));
	                	swPolicyConfigVO.setEffectiveYear(UXUtility.checkNull(rs1.getString("EFFECTIVE_YEAR"))); 
            		  
	                	if(rs1.getDate("POL_EFFECTIVE_DATE") != null){
/*				                swPolicyConfigVO.setPolicyEffDate(new Date(TTKCommon.getFormattedDate(rs1.getDate("POL_EFFECTIVE_DATE"))));
*/			               
	                	swPolicyConfigVO.setPolicyEffDate(new Date(rs1.getTimestamp("POL_EFFECTIVE_DATE").getTime()));
	                	
	                	System.out.println("rs1.getDate(\"POL_EFFECTIVE_DATE\")..."+rs1.getDate("POL_EFFECTIVE_DATE"));
		                swPolicyConfigVO.setStrpolicyEffDate(UXUtility.getFormattedDate(rs1.getDate("POL_EFFECTIVE_DATE")));

	                	}
	                	if(rs1.getDate("POL_EXPIRE_DATE") != null){
	                	swPolicyConfigVO.setPolicyExpDate(new Date(rs1.getTimestamp("POL_EXPIRE_DATE").getTime()));
		                swPolicyConfigVO.setStrpolicyExpDate(UXUtility.getFormattedDate(rs1.getDate("POL_EXPIRE_DATE")));
	                	}
	                	
	                	swPolicyConfigVO.setPolicyDurationPerMonth(rs1.getLong("POL_DURATION_MONTH"));
	                	swPolicyConfigVO.setNoOfLives(rs1.getLong("NO_LIVES"));
	                	if(rs1.getString("IP_CPM") != null){
	                		swPolicyConfigVO.setInPatientCPM(UXUtility.checkNull(rs1.getString("IP_CPM"))); 
	    				}
	                	if(rs1.getString("OP_CPM") != null){
	                		swPolicyConfigVO.setOutPatientCPM(UXUtility.checkNull(rs1.getString("OP_CPM"))); 
	    				}
	                	
	                	if(rs1.getString("OPL_CPM") != null){
	                		swPolicyConfigVO.setOpticalCPM(UXUtility.checkNull(rs1.getString("OPL_CPM"))); 
	    				}
	                	if(rs1.getString("DNT_CPM") != null){
	                		swPolicyConfigVO.setDentalCPM(UXUtility.checkNull(rs1.getString("DNT_CPM"))); 
	    				}
	                	if(rs1.getString("EXCPT_MAT_CPM") != null){
		                	swPolicyConfigVO.setAllExlMaternity(UXUtility.checkNull(rs1.getString("EXCPT_MAT_CPM"))); 
	    				}
	                	if(rs1.getString("MAT_CPM") != null){
	                		System.out.println("mat..ff.."+rs1.getString("MAT_CPM"));
		                	swPolicyConfigVO.setMaternityCPM(UXUtility.checkNull(rs1.getString("MAT_CPM"))); 
	    				}
	              
	                	/*if(rs1.getString("WEIGHTAGE") != null){
		                	//swPolicyConfigVO.setFinalweightage(new BigDecimal(rs1.getString("WEIGHTAGE"))); 
	                		swPolicyConfigVO.setFinalweightage(TTKCommon.checkNull(rs1.getString("WEIGHTAGE"))); 
	    				}*/
	            
	                	if(rs1.getString("premium_per_member") != null){
	                		
		                	swPolicyConfigVO.setAllExcludingMaternity(UXUtility.checkNull(rs1.getString("premium_per_member"))); 
	    				}
	                	if(rs1.getString("mat_prem_per_mem") != null){
	                	
		                	swPolicyConfigVO.setMaternity(UXUtility.checkNull(rs1.getString("mat_prem_per_mem"))); 
	    				}
	                	if(rs1.getString("Tot_Prem_Per_Mem") != null){
	                		System.out.println("mat..ff.."+rs1.getString("MAT_CPM"));
		                	swPolicyConfigVO.setOverallAllIncludingMaternity(UXUtility.checkNull(rs1.getString("Tot_Prem_Per_Mem"))); 
	    				}
	                	
	                	if(rs1.getString("loss_ratio") != null){
	                		System.out.println("mat..ff.."+rs1.getString("MAT_CPM"));
		                	swPolicyConfigVO.setLossRatio(UXUtility.checkNull(rs1.getString("loss_ratio"))); 
	    				}
	                   
	                	if(rs1.getString("total") != null){
	                		System.out.println("mat..ff.."+rs1.getString("MAT_CPM"));
		                	swPolicyConfigVO.setTotal(UXUtility.checkNull(rs1.getString("total"))); 
	    				}
	                	
	                	
	                	if(rs1.getString("IP_WEIGHTAGE") != null){
	                		
	                		swPolicyConfigVO.setInpatientcrediblty(UXUtility.checkNull(rs1.getString("IP_WEIGHTAGE"))); 
	    				}
	                	if(rs1.getString("OP_WEIGHTAGE") != null){
	                		swPolicyConfigVO.setOutpatientcrediblty(UXUtility.checkNull(rs1.getString("OP_WEIGHTAGE"))); 
	    				}
	                	if(rs1.getString("MAT_WEIGHTAGE") != null){
	                		swPolicyConfigVO.setMaternitycrediblty(UXUtility.checkNull(rs1.getString("MAT_WEIGHTAGE"))); 
	    				}
	                	if(rs1.getString("OPTL_WEIGHTAGE") != null){
	                		swPolicyConfigVO.setOpticalcrediblty(UXUtility.checkNull(rs1.getString("OPTL_WEIGHTAGE"))); 
	    				}
	                	if(rs1.getString("DNT_WEIGHTAGE") != null){
	                		swPolicyConfigVO.setDentalcrediblty(UXUtility.checkNull(rs1.getString("DNT_WEIGHTAGE"))); 
	    				}
	                   
	                	alResultList.add(swPolicyConfigVO);
						
					}
				}
			}	try(ResultSet rs2 = (java.sql.ResultSet)cStmtObject.getObject(3);){
				if(rs2 != null){
					while(rs2.next())
					{
						swPolicyConfigVO = new SwPolicyConfigVO();
	                    System.out.println("DATA_TYPE..2..."+rs2.getString("DATA_TYPE"));  																							                
	                	
	                	swPolicyConfigVO.setLngGroupProfileSeqID(rs2.getLong("GRP_PROF_SEQ_ID"));
	                	swPolicyConfigVO.setCpmSeqID(rs2.getLong("CPM_SEQ_ID"));
	                	swPolicyConfigVO.setAddedBy(insPricingVO.getAddedBy());
	                	swPolicyConfigVO.setSlNo(UXUtility.checkNull(rs2.getString("SL_NO")));
	                	
	                	swPolicyConfigVO.setDataType(UXUtility.checkNull(rs2.getString("DATA_TYPE")));
	                	swPolicyConfigVO.setPolicyNo(UXUtility.checkNull(rs2.getString("POLICY_NO")));
	                	swPolicyConfigVO.setClientCode(UXUtility.checkNull(rs2.getString("CLIENT_CODE")));
	                	swPolicyConfigVO.setEffectiveYear(UXUtility.checkNull(rs2.getString("EFFECTIVE_YEAR"))); 
            		  
	                	if(rs2.getDate("POL_EFFECTIVE_DATE") != null){
/*				                swPolicyConfigVO.setPolicyEffDate(new Date(TTKCommon.getFormattedDate(rs1.getDate("POL_EFFECTIVE_DATE"))));
*/			              
	                	swPolicyConfigVO.setPolicyEffDate(new Date(rs2.getTimestamp("POL_EFFECTIVE_DATE").getTime()));
		                swPolicyConfigVO.setStrpolicyEffDate(UXUtility.getFormattedDate(rs2.getDate("POL_EFFECTIVE_DATE")));

	                	}
	                	if(rs2.getDate("POL_EXPIRE_DATE") != null){
	                	swPolicyConfigVO.setPolicyExpDate(new Date(rs2.getTimestamp("POL_EXPIRE_DATE").getTime()));
		                swPolicyConfigVO.setStrpolicyExpDate(UXUtility.getFormattedDate(rs2.getDate("POL_EXPIRE_DATE")));
	                	}
	                	
	                	swPolicyConfigVO.setPolicyDurationPerMonth(rs2.getLong("POL_DURATION_MONTH"));
	                	swPolicyConfigVO.setNoOfLives(rs2.getLong("NO_LIVES"));
	                	
	                	System.out.println("IP_CPM check flag.."+rs2.getString("IP_CPM"));
	                	System.out.println("IP_CPM check flag.."+rs2.getString("OP_CPM"));
	                	System.out.println("IP_CPM check flag.."+rs2.getString("OPL_CPM"));
	                	System.out.println("IP_CPM check flag.."+rs2.getString("DNT_CPM"));
	                	System.out.println("IP_CPM check flag.."+rs2.getString("MAT_CPM"));
	                	
	                	if(rs2.getString("IP_CPM") != null){
	                		swPolicyConfigVO.setInPatientCPM(UXUtility.checkNull(rs2.getString("IP_CPM"))); 
	    				}
	                	if(rs2.getString("OP_CPM") != null){
	                		swPolicyConfigVO.setOutPatientCPM(UXUtility.checkNull(rs2.getString("OP_CPM"))); 
	    				}
	                	
	                	if(rs2.getString("OPL_CPM") != null){
	                		swPolicyConfigVO.setOpticalCPM(UXUtility.checkNull(rs2.getString("OPL_CPM"))); 
	    				}
	                	if(rs2.getString("DNT_CPM") != null){
	                		swPolicyConfigVO.setDentalCPM(UXUtility.checkNull(rs2.getString("DNT_CPM"))); 
	    				}
	                	if(rs2.getString("EXCPT_MAT_CPM") != null){
		                	swPolicyConfigVO.setAllExlMaternity(UXUtility.checkNull(rs2.getString("EXCPT_MAT_CPM"))); 
	    				}
	                	if(rs2.getString("MAT_CPM") != null){
	                		System.out.println("mattotal...."+rs2.getString("MAT_CPM"));
		                	swPolicyConfigVO.setMaternityCPM(UXUtility.checkNull(rs2.getString("MAT_CPM"))); 
	    				}
	                	
	                	if(rs2.getString("TOTAL") != null){
	                		System.out.println("risktotal...."+rs2.getString("TOTAL"));
		                	swPolicyConfigVO.setTotalCPM(UXUtility.checkNull(rs2.getString("TOTAL"))); 
	    				}
	                	
	              
	                	/*if(rs1.getString("WEIGHTAGE") != null){
		                	//swPolicyConfigVO.setFinalweightage(new BigDecimal(rs1.getString("WEIGHTAGE"))); 
	                		swPolicyConfigVO.setFinalweightage(TTKCommon.checkNull(rs1.getString("WEIGHTAGE"))); 
	    				}*/
	            
	                	
	                	if(rs2.getString("IP_WEIGHTAGE") != null){
	                		
	                		swPolicyConfigVO.setInpatientcrediblty(UXUtility.checkNull(rs2.getString("IP_WEIGHTAGE"))); 
	    				}
	                	if(rs2.getString("OP_WEIGHTAGE") != null){
	                		swPolicyConfigVO.setOutpatientcrediblty(UXUtility.checkNull(rs2.getString("OP_WEIGHTAGE"))); 
	    				}
	                	if(rs2.getString("MAT_WEIGHTAGE") != null){
	                		swPolicyConfigVO.setMaternitycrediblty(UXUtility.checkNull(rs2.getString("MAT_WEIGHTAGE"))); 
	    				}
	                	if(rs2.getString("OPTL_WEIGHTAGE") != null){
	                		swPolicyConfigVO.setOpticalcrediblty(UXUtility.checkNull(rs2.getString("OPTL_WEIGHTAGE"))); 
	    				}
	                	if(rs2.getString("DNT_WEIGHTAGE") != null){
	                		swPolicyConfigVO.setDentalcrediblty(UXUtility.checkNull(rs2.getString("DNT_WEIGHTAGE"))); 
	    				}
	                   
	                	alResultList1.add(swPolicyConfigVO);
						
					}
				}
			}
			
			
		}
		result.add(alResultList);
		result.add(alResultList1);
		return result;
		/*return (ArrayList)alResultList;	*/
	}

	@Override
	public ArrayList getcpmBeforeCalcultion(InsPricingVO insPricingVO) throws Exception {
		// TODO Auto-generated method stub
		 SwPolicyConfigVO swPolicyConfigVO = null;
		  Collection<Object> alResultList = new ArrayList<Object>();
		  Collection<Object> alResultList1 = new ArrayList<Object>();
		  ArrayList result=new ArrayList();
		try(Connection con = dataSource.getConnection();
				CallableStatement cStmtObject = (java.sql.CallableStatement)con.prepareCall(strCPMBeforeCal);){
			System.out.println("grop seq id.."+insPricingVO.getGroupProfileSeqID());
			cStmtObject.setLong(1,insPricingVO.getGroupProfileSeqID());
			cStmtObject.registerOutParameter(2,OracleTypes.CURSOR);
			cStmtObject.registerOutParameter(3,OracleTypes.CURSOR);
			cStmtObject.execute();
			
			try(ResultSet rs1 = (java.sql.ResultSet)cStmtObject.getObject(2);){
				if(rs1 != null){
					while(rs1.next())
					{
						swPolicyConfigVO = new SwPolicyConfigVO();
	                	
						System.out.println("DATA_TYPE..."+rs1.getString("DATA_TYPE"));
	                	swPolicyConfigVO.setLngGroupProfileSeqID(insPricingVO.getGroupProfileSeqID());
	                	if(rs1.getString("CPM_SEQ_ID") != null){
	                	swPolicyConfigVO.setCpmSeqID(rs1.getLong("CPM_SEQ_ID"));
	                	}else{
	                		swPolicyConfigVO.setCpmSeqID(0l);
	                	}
	                	
	                	swPolicyConfigVO.setAddedBy(insPricingVO.getAddedBy());
	                	
	                	swPolicyConfigVO.setSlNo(UXUtility.checkNull(rs1.getString("SL_NO")));
	                	swPolicyConfigVO.setDataType(UXUtility.checkNull(rs1.getString("DATA_TYPE")));
	                	swPolicyConfigVO.setPolicyNo(UXUtility.checkNull(rs1.getString("POLICY_NO")));
	                	swPolicyConfigVO.setClientCode(UXUtility.checkNull(rs1.getString("CLIENT_CODE")));
	                	swPolicyConfigVO.setEffectiveYear(UXUtility.checkNull(rs1.getString("EFFECTIVE_YEAR"))); 
	                	if(rs1.getDate("POL_EFFECTIVE_DATE") != null){
/*				                swPolicyConfigVO.setPolicyEffDate(new Date(TTKCommon.getFormattedDate(rs1.getDate("POL_EFFECTIVE_DATE"))));
*/			                	
		                swPolicyConfigVO.setPolicyEffDate(new Date(rs1.getTimestamp("POL_EFFECTIVE_DATE").getTime()));
		                
		                swPolicyConfigVO.setStrpolicyEffDate(UXUtility.getFormattedDate(rs1.getDate("POL_EFFECTIVE_DATE")));
	              

	                	}
	                	if(rs1.getDate("POL_EXPIRE_DATE") != null){
	                	swPolicyConfigVO.setPolicyExpDate(new Date(rs1.getTimestamp("POL_EXPIRE_DATE").getTime()));
		                swPolicyConfigVO.setStrpolicyExpDate(UXUtility.getFormattedDate(rs1.getDate("POL_EXPIRE_DATE")));

	                	}
	                	swPolicyConfigVO.setPolicyDurationPerMonth(rs1.getLong("POL_DURATION_MONTH"));
	                	swPolicyConfigVO.setNoOfLives(rs1.getLong("NO_LIVES"));
	                	
	                	
                       if(rs1.getString("premium_per_member") != null){
	                		
		                	swPolicyConfigVO.setAllExcludingMaternity(UXUtility.checkNull(rs1.getString("premium_per_member"))); 
	    				}
	                	if(rs1.getString("mat_prem_per_mem") != null){
	                	
		                	swPolicyConfigVO.setMaternity(UXUtility.checkNull(rs1.getString("mat_prem_per_mem"))); 
	    				}
	                	if(rs1.getString("Tot_Prem_Per_Mem") != null){
	                		System.out.println("mat..ff.."+rs1.getString("MAT_CPM"));
		                	swPolicyConfigVO.setOverallAllIncludingMaternity(UXUtility.checkNull(rs1.getString("Tot_Prem_Per_Mem"))); 
	    				}
	                	
	                	if(rs1.getString("loss_ratio") != null){
	                		System.out.println("mat..ff.."+rs1.getString("MAT_CPM"));
		                	swPolicyConfigVO.setLossRatio(UXUtility.checkNull(rs1.getString("loss_ratio"))); 
	    				}
	                   
	                	if(rs1.getString("total") != null){
	                		System.out.println("mat..ff.."+rs1.getString("MAT_CPM"));
		                	swPolicyConfigVO.setTotal(UXUtility.checkNull(rs1.getString("total"))); 
	    				}
	                	
	                	if(rs1.getString("IP_CPM") != null){
	                		swPolicyConfigVO.setInPatientCPM(UXUtility.checkNull(rs1.getString("IP_CPM"))); 
	    				}
	                	if(rs1.getString("OP_CPM") != null){
	                		swPolicyConfigVO.setOutPatientCPM(UXUtility.checkNull(rs1.getString("OP_CPM"))); 
	    				}
	                	
	                	if(rs1.getString("OPL_CPM") != null){
	                		swPolicyConfigVO.setOpticalCPM(UXUtility.checkNull(rs1.getString("OPL_CPM"))); 
	    				}
	                	if(rs1.getString("DNT_CPM") != null){
	                		swPolicyConfigVO.setDentalCPM(UXUtility.checkNull(rs1.getString("DNT_CPM"))); 
	    				}
	                	if(rs1.getString("ALL_EXCL_MAT") != null){
	                		swPolicyConfigVO.setAllExlMaternity(UXUtility.checkNull(rs1.getString("ALL_EXCL_MAT"))); 
	    				}
	                	if(rs1.getString("MAT_CPM") != null){
		                	swPolicyConfigVO.setMaternityCPM(UXUtility.checkNull(rs1.getString("MAT_CPM"))); 
	    				}
	              
	                	
	                	if(rs1.getString("ALRT_MSG") != null){
	                		swPolicyConfigVO.setAlertMsg(UXUtility.checkNull(rs1.getString("ALRT_MSG"))); 
	                		
	    				}
	                	
	                	alResultList.add(swPolicyConfigVO);
						
					}
				}
			}try(ResultSet rs2 = (java.sql.ResultSet)cStmtObject.getObject(3);){
				if(rs2 != null){
					while(rs2.next())
					{
						swPolicyConfigVO = new SwPolicyConfigVO();
	                	
						System.out.println("DATA_TYPE..."+rs2.getString("DATA_TYPE"));
	                	swPolicyConfigVO.setLngGroupProfileSeqID(insPricingVO.getGroupProfileSeqID());
	                	if(rs2.getString("CPM_SEQ_ID") != null){
	                	swPolicyConfigVO.setCpmSeqID(rs2.getLong("CPM_SEQ_ID"));
	                	}else{
	                		swPolicyConfigVO.setCpmSeqID(0l);
	                	}
	                	
	                	swPolicyConfigVO.setAddedBy(insPricingVO.getAddedBy());
	                	
	                	swPolicyConfigVO.setSlNo(UXUtility.checkNull(rs2.getString("SL_NO")));
	                	swPolicyConfigVO.setDataType(UXUtility.checkNull(rs2.getString("DATA_TYPE")));
	                	swPolicyConfigVO.setPolicyNo(UXUtility.checkNull(rs2.getString("POLICY_NO")));
	                	swPolicyConfigVO.setClientCode(UXUtility.checkNull(rs2.getString("CLIENT_CODE")));
	                	swPolicyConfigVO.setEffectiveYear(UXUtility.checkNull(rs2.getString("EFFECTIVE_YEAR"))); 
	                	if(rs2.getDate("POL_EFFECTIVE_DATE") != null){
/*				                swPolicyConfigVO.setPolicyEffDate(new Date(TTKCommon.getFormattedDate(rs1.getDate("POL_EFFECTIVE_DATE"))));
*/			                	
		                swPolicyConfigVO.setPolicyEffDate(new Date(rs2.getTimestamp("POL_EFFECTIVE_DATE").getTime()));
		                swPolicyConfigVO.setStrpolicyEffDate(UXUtility.getFormattedDate(rs2.getDate("POL_EFFECTIVE_DATE")));
	              

	                	}
	                	if(rs2.getDate("POL_EXPIRE_DATE") != null){
	                	swPolicyConfigVO.setPolicyExpDate(new Date(rs2.getTimestamp("POL_EXPIRE_DATE").getTime()));
		                swPolicyConfigVO.setStrpolicyExpDate(UXUtility.getFormattedDate(rs2.getDate("POL_EXPIRE_DATE")));

	                	}
	                	swPolicyConfigVO.setPolicyDurationPerMonth(rs2.getLong("POL_DURATION_MONTH"));
	                	swPolicyConfigVO.setNoOfLives(rs2.getLong("NO_LIVES"));
	                	if(rs2.getString("IP_CPM") != null){
	                		swPolicyConfigVO.setInPatientCPM(UXUtility.checkNull(rs2.getString("IP_CPM"))); 
	    				}
	                	if(rs2.getString("OP_CPM") != null){
	                		swPolicyConfigVO.setOutPatientCPM(UXUtility.checkNull(rs2.getString("OP_CPM"))); 
	    				}
	                	
	                	if(rs2.getString("OPL_CPM") != null){
	                		swPolicyConfigVO.setOpticalCPM(UXUtility.checkNull(rs2.getString("OPL_CPM"))); 
	    				}
	                	if(rs2.getString("DNT_CPM") != null){
	                		swPolicyConfigVO.setDentalCPM(UXUtility.checkNull(rs2.getString("DNT_CPM"))); 
	    				}
	                	if(rs2.getString("ALL_EXCL_MAT") != null){
	                		swPolicyConfigVO.setAllExlMaternity(UXUtility.checkNull(rs2.getString("ALL_EXCL_MAT"))); 
	    				}
	                	if(rs2.getString("MAT_CPM") != null){
		                	swPolicyConfigVO.setMaternityCPM(UXUtility.checkNull(rs2.getString("MAT_CPM"))); 
	    				}
	              
	                	
	                	if(rs2.getString("ALRT_MSG") != null){
	                		swPolicyConfigVO.setAlertMsg(UXUtility.checkNull(rs2.getString("ALRT_MSG"))); 
	                		
	    				}
	                	
	                	alResultList1.add(swPolicyConfigVO);
						
					}
				}
			}
			
			
			
		}
		result.add(alResultList);
		result.add(alResultList1);
	/*	return (ArrayList)alResultList;	*/
		return result;	
	}

	@Override
	public ArrayList getAfterLoadingData(InsPricingVO insPricingVO) throws Exception {
		// TODO Auto-generated method stub
		  Collection<Object> alResultList = new ArrayList<Object>();
		   SwPricingSummaryVO swPricingSummaryVO = null;
		try(Connection con = dataSource.getConnection();
				CallableStatement cStmtObject = (java.sql.CallableStatement)con.prepareCall(strLoadingAfterCalc);){
			cStmtObject.setLong(1,insPricingVO.getGroupProfileSeqID());
			cStmtObject.registerOutParameter(2,OracleTypes.CURSOR);
			cStmtObject.execute();
			try(ResultSet rs1 = (java.sql.ResultSet)cStmtObject.getObject(2);){
				if(rs1 != null){
					while(rs1.next())
					{
						swPricingSummaryVO = new SwPricingSummaryVO();
			              
	                	swPricingSummaryVO.setGrp_load_SeqId(rs1.getLong("grp_ld_seq_id"));
	                	swPricingSummaryVO.setLngGroupProfileSeqID(rs1.getLong("grp_prof_seq_id"));
	                	swPricingSummaryVO.setAddedBy(insPricingVO.getAddedBy());
	                	
	                	swPricingSummaryVO.setLoad_DeductTypeSeqId(rs1.getLong("LOADING_TYPE_SEQ_ID"));
	                	swPricingSummaryVO.setLoad_DeductType(UXUtility.checkNull(rs1.getString("LOATING_DEDUCT_TYPE")));
	                	if(rs1.getString("loading_perc") !=null){
	                		swPricingSummaryVO.setLoad_DeductTypePercentage(UXUtility.checkNull(rs1.getString("LOADING_PERC")));
	                	}
	                	swPricingSummaryVO.setLoadComments(UXUtility.checkNull(rs1.getString("LODING_REMARKS")));
	                	
	                	alResultList.add(swPricingSummaryVO);
					}
				}
			}
			
		}
		return (ArrayList)alResultList;	
	}

	@Override
	public ArrayList getBeforeLoadingData(InsPricingVO insPricingVO) throws Exception {
		// TODO Auto-generated method stub
		   SwPricingSummaryVO swPricingSummaryVO = null;
		   Collection<Object> alResultList = new ArrayList<Object>();
	    	
		try(Connection con = dataSource.getConnection();
				CallableStatement cStmtObject = (java.sql.CallableStatement)con.prepareCall(strMasterListValue);){
			cStmtObject.registerOutParameter(1,OracleTypes.CURSOR);
			cStmtObject.registerOutParameter(2,OracleTypes.CURSOR);
			cStmtObject.registerOutParameter(3,OracleTypes.CURSOR);//loading
			cStmtObject.registerOutParameter(4,OracleTypes.CURSOR);//IP OP sum
			cStmtObject.execute();
			try(ResultSet rs1 = (java.sql.ResultSet)cStmtObject.getObject(3);){
				if(rs1 != null){
					while(rs1.next())
					{
						swPricingSummaryVO = new SwPricingSummaryVO();
		                
				        
	                	
	                	swPricingSummaryVO.setGrp_load_SeqId(null);
	                	swPricingSummaryVO.setLngGroupProfileSeqID(insPricingVO.getGroupProfileSeqID());
	                	swPricingSummaryVO.setAddedBy(insPricingVO.getAddedBy());
	            
	                	swPricingSummaryVO.setLoad_DeductTypeSeqId(rs1.getLong("LOADING_TYPE_SEQ_ID"));
	                	swPricingSummaryVO.setLoad_DeductType(UXUtility.checkNull(rs1.getString("LOATING_DEDUCT_TYPE")));
	                	swPricingSummaryVO.setLoad_DeductTypePercentage(rs1.getString("PERC"));//default value is 10
	                	swPricingSummaryVO.setLoadComments("");
	                  	alResultList.add(swPricingSummaryVO);
					}
				}
			}
			
			
			
			
		}
		return (ArrayList)alResultList;	
	}

	@Override
	public SwPolicyConfigVO getcpmAfterLoading(InsPricingVO insPricingVO) throws Exception {
		// TODO Auto-generated method stub
		   SwPolicyConfigVO swPolicyConfigVO = null;
		try(Connection con = dataSource.getConnection();
			
				CallableStatement cStmtObject = (java.sql.CallableStatement)con.prepareCall(strCPMAfterCalLoading);){
			System.out.println("final risk primium....."+strCPMAfterCalLoading);
			 if(insPricingVO.getFinaldataSeqID()!= null)
	            {
			
	            cStmtObject.setLong(1,insPricingVO.getFinaldataSeqID());
	         
	            }else{
	            	
	            cStmtObject.setLong(1,0);
	            }
	
			cStmtObject.setLong(1,insPricingVO.getGroupProfileSeqID());
			cStmtObject.setLong(2,insPricingVO.getAddedBy());
			cStmtObject.registerOutParameter(3,OracleTypes.CURSOR);
			cStmtObject.execute();
			try(ResultSet rs1 = (java.sql.ResultSet)cStmtObject.getObject(3);){
				if(rs1 != null){
					while(rs1.next())
					{
						
					 	swPolicyConfigVO = new SwPolicyConfigVO();
	                	
					 	
					
					 
					 	
	                	swPolicyConfigVO.setLngGroupProfileSeqID(rs1.getLong("GRP_PROF_SEQ_ID"));
	                	swPolicyConfigVO.setFinaldataSeqID(rs1.getLong("FNL_CPM_SEQ_ID"));
	                	swPolicyConfigVO.setAddedBy(insPricingVO.getAddedBy());
	                	
	                	swPolicyConfigVO.setFindataType(UXUtility.checkNull(rs1.getString("DATA_TYPE")));
	                	swPolicyConfigVO.setFinpolicyNo(UXUtility.checkNull(rs1.getString("POLICY_NO")));
	                	swPolicyConfigVO.setFinclientCode(UXUtility.checkNull(rs1.getString("CLIENT_CODE")));
	                	swPolicyConfigVO.setFineffectiveYear(UXUtility.checkNull(rs1.getString("EFFECTIVE_YEAR"))); 
	                	if(rs1.getDate("POL_EFFECTIVE_DATE") != null){
	                	swPolicyConfigVO.setFinpolicyEffDate(new Date(rs1.getTimestamp("POL_EFFECTIVE_DATE").getTime()));
	                	}
	                	if(rs1.getDate("POL_EXPIRE_DATE") != null){
	                	swPolicyConfigVO.setFinpolicyExpDate(new Date(rs1.getTimestamp("POL_EXPIRE_DATE").getTime()));
	                	}
	                	swPolicyConfigVO.setFinpolicyDurationPerMonth(rs1.getLong("POL_DURATION_MONTH"));
	                	swPolicyConfigVO.setFinnoOfLives(rs1.getLong("NO_LIVES"));
	                	if(rs1.getString("MODIFY_YN").equalsIgnoreCase("N")){
	                	
	                	System.out.println("IP_CPM..."+rs1.getString("IP_CPM"));	
	                	System.out.println("OP_CPM..."+rs1.getString("OP_CPM"));	
	                	System.out.println("OPL_CPM..."+rs1.getString("OPL_CPM"));	
	                	System.out.println("DNT_CPM..."+rs1.getString("DNT_CPM"));	
	                
	                	
	                		
	                	if(rs1.getString("IP_CPM") != null){
	                		swPolicyConfigVO.setFininPatientCPM(UXUtility.checkNull(rs1.getString("IP_CPM"))); 
	    				}
	                	
	                	if(rs1.getString("OP_CPM") != null){
	                		swPolicyConfigVO.setFinoutPatientCPM(UXUtility.checkNull(rs1.getString("OP_CPM"))); 
	    				}
	                	
	                	if(rs1.getString("OPL_CPM") != null){
	                		swPolicyConfigVO.setFinopticalCPM(UXUtility.checkNull(rs1.getString("OPL_CPM"))); 
	    				}
	                	if(rs1.getString("DNT_CPM") != null){
	                		swPolicyConfigVO.setFindentalCPM(UXUtility.checkNull(rs1.getString("DNT_CPM"))); 
	    				}
	                	if(rs1.getString("EXCPT_MAT_CPM") != null){
		                	swPolicyConfigVO.setFinallExlMaternity(UXUtility.checkNull(rs1.getString("EXCPT_MAT_CPM"))); 
	    				}
	                	if(rs1.getString("MAT_CPM") != null){
	                		System.out.println("mat....."+rs1.getString("MAT_CPM"));
		                	swPolicyConfigVO.setFinmaternityCPM(UXUtility.checkNull(rs1.getString("MAT_CPM"))); 
	    				}
                	
	                	
	                	}else if(rs1.getString("MODIFY_YN").equalsIgnoreCase("Y")){
	                		swPolicyConfigVO.setFininPatientCPM(""); 
	                		swPolicyConfigVO.setFinoutPatientCPM(""); 
	                		swPolicyConfigVO.setFinopticalCPM(""); 
	                		swPolicyConfigVO.setFindentalCPM(""); 
	                		swPolicyConfigVO.setFinallExlMaternity(""); 
	                		swPolicyConfigVO.setFinmaternityCPM(""); 
	                		swPolicyConfigVO.setFinfinalweightage("");  
	                
		                	}
	                	
					}
				}
			}
		}
		return swPolicyConfigVO;
	}

	@Override
	public ArrayList calculatePlanDesignConfig(SwPolicyConfigVO swpolicyConfigVO,Long userSeqId) throws Exception {
		// TODO Auto-generated method stub
		ArrayList<SwPolicyConfigVO> alPastdatalist = new ArrayList<>();
		int iResult=0;
		ArrayList arraylist = new ArrayList<>();
		
		try(Connection con = dataSource.getConnection();
				CallableStatement cStmtObject = (java.sql.CallableStatement)con.prepareCall(strSaveCalulatePricingList);){
			
			System.out.println("strSaveCalulatePricingList..."+strSaveCalulatePricingList);
			
			alPastdatalist = swpolicyConfigVO.getAlResultpastYear();
		
			System.out.println("alPastdatalist.."+alPastdatalist.size());
			int i= 0;

		
		    if(!(alPastdatalist.isEmpty())){
               for(Object object:alPastdatalist){
//            	 		    	          	            		               	
                i++;
             
            swpolicyConfigVO = (SwPolicyConfigVO) object;
            
          
           System.out.println("swpolicyConfigVO...."+i+"..."+swpolicyConfigVO.getLngGroupProfileSeqID());
      
            System.out.println("swpolicyConfigVO.getCpmSeqID()..111."+swpolicyConfigVO.getCpmSeqID());
            if(swpolicyConfigVO.getCpmSeqID()!= null)
            {
            cStmtObject.setLong(1,swpolicyConfigVO.getCpmSeqID());
         
            }else{
            cStmtObject.setLong(1,0);
            }
            
            System.out.println("swpolicyConfigVO.getLngGroupProfileSeqID()..222."+swpolicyConfigVO.getLngGroupProfileSeqID());
            if(swpolicyConfigVO.getLngGroupProfileSeqID()!= null)
            {
            	
            cStmtObject.setLong(2,swpolicyConfigVO.getLngGroupProfileSeqID());
         
            }else{
            	
            cStmtObject.setLong(2,0);
            }
            System.out.println("swpolicyConfigVO.getDataType()..333."+swpolicyConfigVO.getDataType());
            cStmtObject.setString(3,swpolicyConfigVO.getDataType()); 
            System.out.println("swpolicyConfigVO.getPolicyNo().444."+swpolicyConfigVO.getPolicyNo());
            cStmtObject.setString(4,swpolicyConfigVO.getPolicyNo());
            System.out.println("swpolicyConfigVO.getEffectiveYear()..555."+swpolicyConfigVO.getEffectiveYear());
            if(swpolicyConfigVO.getEffectiveYear() != null){
            cStmtObject.setString(5,swpolicyConfigVO.getEffectiveYear());
            }else{
            	cStmtObject.setLong(5,0);
            }
           
            if(!swpolicyConfigVO.getDataType().equalsIgnoreCase("USR_IP_YR")){
            	System.out.println("start date..."+swpolicyConfigVO.getPolicyEffDate());
            	System.out.println("start date..."+swpolicyConfigVO.getPolicyExpDate());
            	
	           /* if(swpolicyConfigVO.getPolicyEffDate() != null){
				cStmtObject.setTimestamp(6,new Timestamp(swpolicyConfigVO.getPolicyEffDate().getTime()));//LETTER_DATE
	            }else{
	            	cStmtObject.setTimestamp(6,null);
	            }
	            System.out.println();
	            if(swpolicyConfigVO.getPolicyExpDate() != null){
				cStmtObject.setTimestamp(7,new Timestamp(swpolicyConfigVO.getPolicyExpDate().getTime()));//LETTER_DATE
		        }else{
		        cStmtObject.setTimestamp(7,null);
		        }*/
            	
            	if(swpolicyConfigVO.getStrpolicyEffDate() != "" && swpolicyConfigVO.getStrpolicyEffDate() != null && !swpolicyConfigVO.getStrpolicyEffDate().equals("")){
    				cStmtObject.setTimestamp(6,UXUtility.getConvertStringToDateTimestamp(swpolicyConfigVO.getStrpolicyEffDate()));//LETTER_DATE
    				 
    	            }else{
    	            	cStmtObject.setTimestamp(6,null);
    	            }
    				
    	            if(swpolicyConfigVO.getStrpolicyExpDate() != "" && swpolicyConfigVO.getStrpolicyExpDate() != null && !swpolicyConfigVO.getStrpolicyExpDate().equals("")){
    				cStmtObject.setTimestamp(7,UXUtility.getConvertStringToDateTimestamp(swpolicyConfigVO.getStrpolicyExpDate()));//LETTER_DATE
    		        }else{
    		        cStmtObject.setTimestamp(7,null);
    		        }
	            
            }else if (swpolicyConfigVO.getDataType().equalsIgnoreCase("USR_IP_YR")){
            	System.out.println("start date..user ...."+swpolicyConfigVO.getStrpolicyEffDate());
            	System.out.println("start date..user......"+swpolicyConfigVO.getStrpolicyExpDate());
            	
           
            	if(swpolicyConfigVO.getStrpolicyEffDate() != "" && swpolicyConfigVO.getStrpolicyEffDate() != null && !swpolicyConfigVO.getStrpolicyEffDate().equals("")){
				cStmtObject.setTimestamp(6,UXUtility.getConvertStringToDateTimestamp(swpolicyConfigVO.getStrpolicyEffDate()));//LETTER_DATE
				 
	            }else{
	            	cStmtObject.setTimestamp(6,null);
	            }
				
	            if(swpolicyConfigVO.getStrpolicyExpDate() != "" && swpolicyConfigVO.getStrpolicyExpDate() != null && !swpolicyConfigVO.getStrpolicyExpDate().equals("")){
				cStmtObject.setTimestamp(7,UXUtility.getConvertStringToDateTimestamp(swpolicyConfigVO.getStrpolicyExpDate()));//LETTER_DATE
		        }else{
		        cStmtObject.setTimestamp(7,null);
		        }
            }
            System.out.println("swpolicyConfigVO.getPolicyDurationPerMonth().888."+swpolicyConfigVO.getPolicyDurationPerMonth());
            if(swpolicyConfigVO.getPolicyDurationPerMonth() != null){
	            cStmtObject.setLong(8,swpolicyConfigVO.getPolicyDurationPerMonth());
	            }else{
	            	cStmtObject.setLong(8,0);
	            }
            System.out.println("swpolicyConfigVO.getNoOfLives()...9.."+swpolicyConfigVO.getNoOfLives());
            if(swpolicyConfigVO.getNoOfLives() != null){
	            cStmtObject.setLong(9,swpolicyConfigVO.getNoOfLives());
	            }else{
	            	cStmtObject.setLong(9,0);
	            }
            System.out.println("swpolicyConfigVO.getInPatientCPM()..10."+swpolicyConfigVO.getInPatientCPM());
            if(swpolicyConfigVO.getInPatientCPM() != null  && swpolicyConfigVO.getInPatientCPM() !="" && !swpolicyConfigVO.getInPatientCPM().equals("") && !swpolicyConfigVO.getInPatientCPM().equals(",")){
            	System.out.println("i..."+i+"..test..."+swpolicyConfigVO.getInPatientCPM());
	            cStmtObject.setBigDecimal(10, new BigDecimal(swpolicyConfigVO.getInPatientCPM()));
	            }else{
	            	cStmtObject.setBigDecimal(10,null);
	            }
            System.out.println("swpolicyConfigVO.getOutPatientCPM()..11."+swpolicyConfigVO.getOutPatientCPM());
            if(swpolicyConfigVO.getOutPatientCPM() != null && swpolicyConfigVO.getOutPatientCPM() !="" && !swpolicyConfigVO.getOutPatientCPM().equals("")&& !swpolicyConfigVO.getOutPatientCPM().equals(",")){
            	System.out.println("i..."+i+"..."+swpolicyConfigVO.getOutPatientCPM());
	            cStmtObject.setBigDecimal(11,new BigDecimal(swpolicyConfigVO.getOutPatientCPM()));
	            }else{
	            	cStmtObject.setBigDecimal(11,null);
	            }
          
            if(swpolicyConfigVO.getMaternityCPM() != null && swpolicyConfigVO.getMaternityCPM() !="" && !swpolicyConfigVO.getMaternityCPM().equals("") && !swpolicyConfigVO.getMaternityCPM().equals(",")){
            	
            	  System.out.println("swpolicyConfigVO.getMaternityCPM()..12."+swpolicyConfigVO.getMaternityCPM());
	           cStmtObject.setBigDecimal(12,new BigDecimal(swpolicyConfigVO.getMaternityCPM()));
	           // cStmtObject.setBigDecimal(12,swpolicyConfigVO.getMaternityCPM());
	            }else{
	            	  System.out.println("swpolicyConfigVO.getMaternityCPM().12..else");
	            	cStmtObject.setBigDecimal(12,null);
	            }
            System.out.println("swpolicyConfigVO.getOpticalCPM()..13."+swpolicyConfigVO.getOpticalCPM());  
            
            if(swpolicyConfigVO.getOpticalCPM() != null && swpolicyConfigVO.getOpticalCPM() !="" && !swpolicyConfigVO.getOpticalCPM().equals("") && !swpolicyConfigVO.getOpticalCPM().equals(",")){
            	
	            cStmtObject.setBigDecimal(13,new BigDecimal(swpolicyConfigVO.getOpticalCPM()));
	            }else{
	            	cStmtObject.setBigDecimal(13,null);
	            }
            
            System.out.println("swpolicyConfigVO.getDentalCPM()..14."+swpolicyConfigVO.getDentalCPM());
            if(swpolicyConfigVO.getDentalCPM() != null && swpolicyConfigVO.getDentalCPM() !="" && !swpolicyConfigVO.getDentalCPM().equals("") && !swpolicyConfigVO.getDentalCPM().equals(",")){
          
	            cStmtObject.setBigDecimal(14,new BigDecimal(swpolicyConfigVO.getDentalCPM()));
	            }else{
	            	cStmtObject.setBigDecimal(14,null);
	            }
         
           /* if(swpolicyConfigVO.getFinalweightage() != null &&  swpolicyConfigVO.getFinalweightage()!= ""){
	          //  cStmtObject.setBigDecimal(15,swpolicyConfigVO.getFinalweightage());
            	cStmtObject.setBigDecimal(15,new BigDecimal(swpolicyConfigVO.getFinalweightage()));
	            }else{
	            	cStmtObject.setBigDecimal(15,null);
	            }*/
            
         
            System.out.println("swpolicyConfigVO.getInpatientcrediblty().."+swpolicyConfigVO.getInpatientcrediblty());
            if(swpolicyConfigVO.getInpatientcrediblty() != null &&  swpolicyConfigVO.getInpatientcrediblty()!= "" && !swpolicyConfigVO.getInpatientcrediblty().equals("")){
            	
            	    System.out.println("test..15."+swpolicyConfigVO.getInpatientcrediblty());
	            	cStmtObject.setBigDecimal(15,new BigDecimal(swpolicyConfigVO.getInpatientcrediblty()));
		            }else{
		            	cStmtObject.setBigDecimal(15,null);
		            }
            System.out.println("swpolicyConfigVO.getOutpatientcrediblty()..16."+swpolicyConfigVO.getOutpatientcrediblty());
            if(swpolicyConfigVO.getOutpatientcrediblty() != null &&  swpolicyConfigVO.getOutpatientcrediblty()!= "" && !swpolicyConfigVO.getOutpatientcrediblty().equals("")){
            	
	            	cStmtObject.setBigDecimal(16,new BigDecimal(swpolicyConfigVO.getOutpatientcrediblty()));
		            }else{
		            	cStmtObject.setBigDecimal(16,null);
		            }
            System.out.println("swpolicyConfigVO.getMaternitycrediblty()..17."+swpolicyConfigVO.getMaternitycrediblty());
            if(swpolicyConfigVO.getMaternitycrediblty() != null &&  swpolicyConfigVO.getMaternitycrediblty()!= "" && !swpolicyConfigVO.getMaternitycrediblty().equals("")){
           
	            	cStmtObject.setBigDecimal(17,new BigDecimal(swpolicyConfigVO.getMaternitycrediblty()));
		            }else{
		            	cStmtObject.setBigDecimal(17,null);
		            }
            System.out.println("swpolicyConfigVO.getOpticalcrediblty()..18."+swpolicyConfigVO.getOpticalcrediblty());
            if(swpolicyConfigVO.getOpticalcrediblty() != null &&  swpolicyConfigVO.getOpticalcrediblty()!= "" && !swpolicyConfigVO.getOpticalcrediblty().equals("")){
            	
	            	cStmtObject.setBigDecimal(18,new BigDecimal(swpolicyConfigVO.getOpticalcrediblty()));
		            }else{
		            	cStmtObject.setBigDecimal(18,null);
		            }
            System.out.println("swpolicyConfigVO.getDentalcrediblty()..19."+swpolicyConfigVO.getDentalcrediblty());
            if(swpolicyConfigVO.getDentalcrediblty() != null &&  swpolicyConfigVO.getDentalcrediblty()!= "" && !swpolicyConfigVO.getDentalcrediblty().equals("")){
            	
	            	cStmtObject.setBigDecimal(19,new BigDecimal(swpolicyConfigVO.getDentalcrediblty()));
		            }else{
		            	cStmtObject.setBigDecimal(19,null);
		            }
            System.out.println("userSeqId...20..."+userSeqId);
//            cStmtObject.setLong(20,swpolicyConfigVO.getAddedBy());
            cStmtObject.setLong(20,userSeqId);
            System.out.println("swpolicyConfigVO.getSlNo()..21"+swpolicyConfigVO.getSlNo());
            cStmtObject.setString(21,swpolicyConfigVO.getSlNo());
           
        	
            if(swpolicyConfigVO.getTotal() != null &&  swpolicyConfigVO.getTotal()!= "" && !swpolicyConfigVO.getTotal().equals("")){   
            	   System.out.println("swpolicyConfigVO.getTotal() ..."+swpolicyConfigVO.getTotal());
            	   cStmtObject.setBigDecimal(22,new BigDecimal(swpolicyConfigVO.getTotal()));           
            }else{
            	cStmtObject.setBigDecimal(22,null);
            }
            
            
            System.out.println("all exclusive.."+swpolicyConfigVO.getAllExcludingMaternity());
            System.out.println("maternity......"+swpolicyConfigVO.getMaternity());
            System.out.println("over all......."+swpolicyConfigVO.getOverallAllIncludingMaternity());
            System.out.println("actual project.."+swpolicyConfigVO.getLossRatio());
            cStmtObject.setString(23,swpolicyConfigVO.getAllExcludingMaternity());
            cStmtObject.setString(24,swpolicyConfigVO.getLossRatio());
            cStmtObject.setString(25,swpolicyConfigVO.getMaternity());
            cStmtObject.setString(26,swpolicyConfigVO.getOverallAllIncludingMaternity());
            
           /* cStmtObject.setString(23,swpolicyConfigVO.getAllExcludingMaternity());
            cStmtObject.setString(24,swpolicyConfigVO.getMaternity());
            cStmtObject.setString(25,swpolicyConfigVO.getOverallAllIncludingMaternity());
            cStmtObject.setString(26,swpolicyConfigVO.getLossRatio());*/
            
            cStmtObject.addBatch();
		}
                cStmtObject.executeBatch(); 
			
		}
		     iResult=i;
		     arraylist.add(iResult);
		}
		     
		return arraylist;
	}

	@Override
	public ArrayList saveDemographicData(SwPolicyConfigVO swpolicyConfigVO,Long userSeqId) throws Exception {
		// TODO Auto-generated method stub
		int iResult=0;
		ArrayList arraylist = new ArrayList();
		ArrayList alDemoPastdatalist = new ArrayList();
		try(Connection con = dataSource.getConnection();
				CallableStatement cStmtObject = (java.sql.CallableStatement)con.prepareCall(strSaveDemographicData);){
			alDemoPastdatalist = 	swpolicyConfigVO.getAlResultpastYear();
			int i= 0;
			
		    if(!(alDemoPastdatalist.isEmpty())){
                for(Object object:alDemoPastdatalist){
                i++;
            swpolicyConfigVO = (SwPolicyConfigVO)object;
                    
         
            System.out.println("1...."+swpolicyConfigVO.getDemographicSeqId());
            System.out.println("2...."+swpolicyConfigVO.getLngGroupProfileSeqID());
            System.out.println("3...."+swpolicyConfigVO.getDemodataType());
            System.out.println("4...."+swpolicyConfigVO.getDemoClientCode());
            System.out.println("5...."+swpolicyConfigVO.getDemoPolicyNo());
            System.out.println("6...."+swpolicyConfigVO.getDemoEffectiveYear());
            System.out.println("7...."+swpolicyConfigVO.getDemoPolicyEffDate());
            System.out.println("8...."+swpolicyConfigVO.getDemoPolicyExpDate());
            System.out.println("9...."+swpolicyConfigVO.getDemoPolicyDurationPerMonth());
            System.out.println("10..."+swpolicyConfigVO.getDemoNoOfLives());
            System.out.println("11..."+swpolicyConfigVO.getDemoAverageAge());
            System.out.println("12..."+swpolicyConfigVO.getDemoNationality());
            System.out.println("13..."+swpolicyConfigVO.getDemoAreaOfCover());
            System.out.println("14..."+swpolicyConfigVO.getDemoNetwork());
            System.out.println("15..."+swpolicyConfigVO.getDemoMaximumBenfitLimit());
            System.out.println("16..."+swpolicyConfigVO.getDemoOpCopay());
            System.out.println("17..."+swpolicyConfigVO.getDemoOPDeductable());
            System.out.println("18..."+swpolicyConfigVO.getDemoMaternityCoverage());
            System.out.println("19..."+swpolicyConfigVO.getDemoMaternityLimit());
            System.out.println("20..."+swpolicyConfigVO.getDemoOpticalCoverage());
            System.out.println("21..."+swpolicyConfigVO.getDemoOpticalLimit());
            System.out.println("22..."+swpolicyConfigVO.getDemoOpticalCopay());
            System.out.println("23..."+swpolicyConfigVO.getDemoDentalCoverage());
            System.out.println("24..."+swpolicyConfigVO.getDemoDentalLimit());
            System.out.println("25..."+swpolicyConfigVO.getDemoDentalCopay());
            System.out.println("26..."+swpolicyConfigVO.getDemoSlNo());
            System.out.println("27..."+swpolicyConfigVO.getDemoAlahli());
            System.out.println("28..."+userSeqId);
            System.out.println("29..."+swpolicyConfigVO.getMaternityEligibleMembers());
            System.out.println("30..."+swpolicyConfigVO.getDemoInpatientcoverage());
            System.out.println("31..."+swpolicyConfigVO.getDemoOutpatientcoverage());
            System.out.println("32..."+swpolicyConfigVO.getAlAhliHospitalcoverage());
            System.out.println("33..."+swpolicyConfigVO.getOpticalCoverage());
            System.out.println("34..."+swpolicyConfigVO.getDentalCoverage());
            System.out.println("35..."+swpolicyConfigVO.getOrthodonticsCoverage());
            System.out.println("36..."+swpolicyConfigVO.getMaternityCoverage());
            System.out.println("37..."+swpolicyConfigVO.getFramesLimit());
            System.out.println("38..."+swpolicyConfigVO.getiPCopay());
            System.out.println("39..."+swpolicyConfigVO.getiPCopayAtAlAhli());
            System.out.println("40..."+swpolicyConfigVO.getOrthodonticsCopay());
            System.out.println("41...");
            System.out.println("42..."+swpolicyConfigVO.getLoadingForAreaOfCoverVariations());
            System.out.println("43..."+swpolicyConfigVO.getDiscountForAreavariations());
            System.out.println("44..."+swpolicyConfigVO.getLoadingForAdditionalHospitalCoverage());
            System.out.println("45..."+swpolicyConfigVO.getDiscountForHospitalExclusions());
            System.out.println("46..."+swpolicyConfigVO.getLoadingForResidencyCountry());
            System.out.println("47..."+swpolicyConfigVO.getAdditionalHospitalCoverage());
            System.out.println("48..."+swpolicyConfigVO.getHospitalExclusions());
            System.out.println("49..."+swpolicyConfigVO.getArealOfVariations());
            System.out.println("50..."+swpolicyConfigVO.getResidencyCountry());
            System.out.println("51..."+swpolicyConfigVO.getOtherKeyCoveragesComments());
            System.out.println("52..."+swpolicyConfigVO.getOpLimit());
            System.out.println("53..."+swpolicyConfigVO.getProrataLimits());
            System.out.println("54..."+swpolicyConfigVO.getPremiumRefundLogic());
        
            
            if(swpolicyConfigVO.getDemographicSeqId()!= null)
            {
            cStmtObject.setLong(1,swpolicyConfigVO.getDemographicSeqId());
         
            }else{
            cStmtObject.setLong(1,0);
            }
            
            if(swpolicyConfigVO.getLngGroupProfileSeqID()!= null)
            {
            cStmtObject.setLong(2,swpolicyConfigVO.getLngGroupProfileSeqID());
         
            }else{
            cStmtObject.setLong(2,0);
            }
  
            cStmtObject.setString(3,swpolicyConfigVO.getDemodataType()); 
            cStmtObject.setString(4,swpolicyConfigVO.getDemoClientCode()); 
          
            cStmtObject.setString(5,swpolicyConfigVO.getDemoPolicyNo());
         

            if(swpolicyConfigVO.getDemoEffectiveYear() != null){
            cStmtObject.setString(6,swpolicyConfigVO.getDemoEffectiveYear());
            }else{
            	cStmtObject.setLong(6,0);
            }
            if(swpolicyConfigVO.getDemoPolicyEffDate() != null){
			cStmtObject.setString(7,swpolicyConfigVO.getDemoPolicyEffDate());//LETTER_DATE
            }else{
            	cStmtObject.setString(7,null);
            }
			
            if(swpolicyConfigVO.getDemoPolicyExpDate() != null && !swpolicyConfigVO.getDemoPolicyExpDate().equals(",")){
				cStmtObject.setString(8,swpolicyConfigVO.getDemoPolicyExpDate());//LETTER_DATE
	        }else{
	        cStmtObject.setTimestamp(8,null);
	        }
            
            if(swpolicyConfigVO.getDemoPolicyDurationPerMonth() != null && !swpolicyConfigVO.getDemoPolicyDurationPerMonth().equals(",")){
	            cStmtObject.setString(9,swpolicyConfigVO.getDemoPolicyDurationPerMonth());
	            }else{
	            	cStmtObject.setLong(9,0);
	            }
            
            if(swpolicyConfigVO.getDemoNoOfLives() != null && !swpolicyConfigVO.getDemoNoOfLives().equals(",")){
	            cStmtObject.setString(10,swpolicyConfigVO.getDemoNoOfLives());
	            }else{
	            	cStmtObject.setLong(10,0);
	            }
          
           
            if(swpolicyConfigVO.getDemoAverageAge() != null && swpolicyConfigVO.getDemoAverageAge() !="" && !swpolicyConfigVO.getDemoAverageAge().equals("")  && !swpolicyConfigVO.getDemoAverageAge().equals(",")){
	            cStmtObject.setBigDecimal(11,new BigDecimal(swpolicyConfigVO.getDemoAverageAge()));
	            }else{
	            	cStmtObject.setBigDecimal(11,null);
	            }
	      

            cStmtObject.setString(12,UXUtility.checkNull(swpolicyConfigVO.getDemoNationality()));
	        cStmtObject.setString(13,UXUtility.checkNull(swpolicyConfigVO.getDemoAreaOfCover()));
	        cStmtObject.setString(14,UXUtility.checkNull(swpolicyConfigVO.getDemoNetwork()));
            
          /*  if(swpolicyConfigVO.getDemoMaximumBenfitLimit() != null && swpolicyConfigVO.getDemoMaximumBenfitLimit() !=""){
	            cStmtObject.setBigDecimal(15,new BigDecimal(swpolicyConfigVO.getDemoMaximumBenfitLimit()));
	            }else{
	            	cStmtObject.setBigDecimal(15,null);
	            }*/
            cStmtObject.setString(15,UXUtility.checkNull(swpolicyConfigVO.getDemoMaximumBenfitLimit()));
            
            cStmtObject.setString(16,UXUtility.checkNull(swpolicyConfigVO.getDemoOpCopay()));
            cStmtObject.setString(17,UXUtility.checkNull(swpolicyConfigVO.getDemoOPDeductable()));
            cStmtObject.setString(18,UXUtility.checkNull(swpolicyConfigVO.getDemoMaternityCoverage()));
           
            
          /*  if(swpolicyConfigVO.getDemoMaternityLimit() != null &&  swpolicyConfigVO.getDemoMaternityLimit()!= ""){
	            	cStmtObject.setBigDecimal(19,new BigDecimal(swpolicyConfigVO.getDemoMaternityLimit()));
		            }else{
		            	cStmtObject.setBigDecimal(19,null);
		            }*/
            cStmtObject.setString(19,UXUtility.checkNull(swpolicyConfigVO.getDemoMaternityLimit()));
            cStmtObject.setString(20,UXUtility.checkNull(swpolicyConfigVO.getDemoOpticalCoverage()));

            
        /*  if(swpolicyConfigVO.getDemoOpticalLimit() != null &&  swpolicyConfigVO.getDemoOpticalLimit()!= ""){
		         cStmtObject.setBigDecimal(21,new BigDecimal(swpolicyConfigVO.getDemoOpticalLimit()));
			        }else{
			         cStmtObject.setBigDecimal(21,null);
			        }*/
            cStmtObject.setString(21,UXUtility.checkNull(swpolicyConfigVO.getDemoOpticalLimit()));

            cStmtObject.setString(22,UXUtility.checkNull(swpolicyConfigVO.getDemoOpticalCopay()));
            cStmtObject.setString(23,UXUtility.checkNull(swpolicyConfigVO.getDemoDentalCoverage()));
         
        /*  if(swpolicyConfigVO.getDemoDentalLimit() != null &&  swpolicyConfigVO.getDemoDentalLimit()!= ""){
            	cStmtObject.setBigDecimal(24,new BigDecimal(swpolicyConfigVO.getDemoDentalLimit()));
	            }else{
	            	cStmtObject.setBigDecimal(24,null);
	            }*/
            cStmtObject.setString(24,UXUtility.checkNull(swpolicyConfigVO.getDemoDentalLimit()));

           cStmtObject.setString(25,UXUtility.checkNull(swpolicyConfigVO.getDemoDentalCopay()));
        
          if(swpolicyConfigVO.getDemoSlNo() != null &&  swpolicyConfigVO.getDemoSlNo()!= "" && !swpolicyConfigVO.getDemoSlNo().equals("") && !swpolicyConfigVO.getDemoSlNo().equals(",")){
            	cStmtObject.setBigDecimal(26,new BigDecimal(swpolicyConfigVO.getDemoSlNo()));
	            }else{
	            	cStmtObject.setBigDecimal(26,null);
	            }
          
            cStmtObject.setString(27,UXUtility.checkNull(swpolicyConfigVO.getDemoAlahli()));
        /*    cStmtObject.setLong(28,swpolicyConfigVO.getAddedBy());*/
            cStmtObject.setLong(28,userSeqId);

            if(swpolicyConfigVO.getMaternityEligibleMembers() != null &&  swpolicyConfigVO.getMaternityEligibleMembers()!= "" && !swpolicyConfigVO.getMaternityEligibleMembers().equals("") && !swpolicyConfigVO.getMaternityEligibleMembers().equals(",")){
              	cStmtObject.setBigDecimal(29,new BigDecimal(swpolicyConfigVO.getMaternityEligibleMembers()));
  	            }else{
  	            	cStmtObject.setBigDecimal(29,null);
  	            }
            cStmtObject.setString(30,UXUtility.checkNull(swpolicyConfigVO.getDemoInpatientcoverage()));
            cStmtObject.setString(31,UXUtility.checkNull(swpolicyConfigVO.getDemoOutpatientcoverage()));
            cStmtObject.setString(32,UXUtility.checkNull(swpolicyConfigVO.getAlAhliHospitalcoverage()));
            cStmtObject.setString(33,UXUtility.checkNull(swpolicyConfigVO.getOpticalCoverage()));
            cStmtObject.setString(34,UXUtility.checkNull(swpolicyConfigVO.getDentalCoverage()));
            cStmtObject.setString(35,UXUtility.checkNull(swpolicyConfigVO.getOrthodonticsCoverage()));
            cStmtObject.setString(36,UXUtility.checkNull(swpolicyConfigVO.getMaternityCoverage()));
            cStmtObject.setString(37,UXUtility.checkNull(swpolicyConfigVO.getFramesLimit()));
            cStmtObject.setString(38,UXUtility.checkNull(swpolicyConfigVO.getiPCopay()));
            cStmtObject.setString(39,UXUtility.checkNull(swpolicyConfigVO.getiPCopayAtAlAhli()));
            cStmtObject.setString(40,UXUtility.checkNull(swpolicyConfigVO.getOrthodonticsCopay()));
            cStmtObject.setString(41,UXUtility.checkNull(""));
            cStmtObject.setString(42,UXUtility.checkNull(swpolicyConfigVO.getLoadingForAreaOfCoverVariations()));
            cStmtObject.setString(43,UXUtility.checkNull(swpolicyConfigVO.getDiscountForAreavariations()));
            cStmtObject.setString(44,UXUtility.checkNull(swpolicyConfigVO.getLoadingForAdditionalHospitalCoverage()));
            cStmtObject.setString(45,UXUtility.checkNull(swpolicyConfigVO.getDiscountForHospitalExclusions()));
            cStmtObject.setString(46,UXUtility.checkNull(swpolicyConfigVO.getLoadingForResidencyCountry()));
            cStmtObject.setString(47,UXUtility.checkNull(swpolicyConfigVO.getAdditionalHospitalCoverage()));
            cStmtObject.setString(48,UXUtility.checkNull(swpolicyConfigVO.getHospitalExclusions()));
            cStmtObject.setString(49,UXUtility.checkNull(swpolicyConfigVO.getArealOfVariations()));
            cStmtObject.setString(50,UXUtility.checkNull(swpolicyConfigVO.getResidencyCountry()));
            cStmtObject.setString(51,UXUtility.checkNull(swpolicyConfigVO.getOtherKeyCoveragesComments()));
            cStmtObject.setString(52,UXUtility.checkNull(swpolicyConfigVO.getOpLimit()));
            cStmtObject.setString(53,UXUtility.checkNull(swpolicyConfigVO.getProrataLimits()));
            cStmtObject.setString(54,UXUtility.checkNull(swpolicyConfigVO.getPremiumRefundLogic()));
            cStmtObject.setString(55,UXUtility.checkNull(swpolicyConfigVO.getDemoNoOfLivesdesc()));
            cStmtObject.setString(56,UXUtility.checkNull(swpolicyConfigVO.getDemoAverageAgedesc()));
            
			//cStmtObject.registerOutParameter(27, Types.INTEGER);//out parameter which gives the number 
            cStmtObject.addBatch();
		}
                cStmtObject.executeBatch(); 
		}//
		    
		     iResult=i;
		     arraylist.add(iResult);
			
		}
			
		return arraylist;
	}

	@Override
	public ArrayList calRateCalculationFnl(SwPolicyConfigVO swpolicyConfigVO, Long userSeqId) throws Exception {
		// TODO Auto-generated method stub
		ArrayList<SwPolicyConfigVO> alPastdatalist = new ArrayList<>();
		int iResult=0;
		ArrayList arraylist = new ArrayList<>();
		try(Connection con = dataSource.getConnection();
				CallableStatement cStmtObject = (java.sql.CallableStatement)con.prepareCall(strSaveRateCalculationFnl);){
	System.out.println("strSaveCalulatePricingList..."+strSaveRateCalculationFnl);
			
			alPastdatalist = swpolicyConfigVO.getAlProjectClaim();
		
			int i= 0;

		
		    if(!(alPastdatalist.isEmpty())){
               for(Object object:alPastdatalist){
//            	 
		    	
            	
                	
                	
                i++;
             
            swpolicyConfigVO = (SwPolicyConfigVO) object;
            
            System.out.println("i...."+i+"..."+swpolicyConfigVO.getDataType());
      
            if(swpolicyConfigVO.getCpmSeqID()!= null)
            {
            cStmtObject.setLong(1,swpolicyConfigVO.getCpmSeqID());
         
            }else{
            cStmtObject.setLong(1,0);
            }
            
            if(swpolicyConfigVO.getLngGroupProfileSeqID()!= null)
            {
            	
            cStmtObject.setLong(2,swpolicyConfigVO.getLngGroupProfileSeqID());
         
            }else{
            	
            cStmtObject.setLong(2,0);
            }
  
            cStmtObject.setString(3,swpolicyConfigVO.getDataType()); 
            cStmtObject.setString(4,swpolicyConfigVO.getPolicyNo());

            if(swpolicyConfigVO.getEffectiveYear() != null){
            cStmtObject.setString(5,swpolicyConfigVO.getEffectiveYear());
            }else{
            	cStmtObject.setLong(5,0);
            }
           
            if(!swpolicyConfigVO.getDataType().equalsIgnoreCase("USR_IP_YR")){
	            if(swpolicyConfigVO.getPolicyEffDate() != null){
				cStmtObject.setTimestamp(6,new Timestamp(swpolicyConfigVO.getPolicyEffDate().getTime()));//LETTER_DATE
	            }else{
	            	cStmtObject.setTimestamp(6,null);
	            }
	    
	            if(swpolicyConfigVO.getPolicyExpDate() != null){
				cStmtObject.setTimestamp(7,new Timestamp(swpolicyConfigVO.getPolicyExpDate().getTime()));//LETTER_DATE
		        }else{
		        cStmtObject.setTimestamp(7,null);
		        }
	            
            }else if (swpolicyConfigVO.getDataType().equalsIgnoreCase("USR_IP_YR")){
           
            	if(swpolicyConfigVO.getStrpolicyEffDate() != "" && swpolicyConfigVO.getStrpolicyEffDate() != null){
				cStmtObject.setTimestamp(6,UXUtility.getConvertStringToDateTimestamp(swpolicyConfigVO.getStrpolicyEffDate()));//LETTER_DATE
				 
	            }else{
	            	cStmtObject.setTimestamp(6,null);
	            }
				
	            if(swpolicyConfigVO.getStrpolicyExpDate() != "" && swpolicyConfigVO.getStrpolicyExpDate() != null){
				cStmtObject.setTimestamp(7,UXUtility.getConvertStringToDateTimestamp(swpolicyConfigVO.getStrpolicyExpDate()));//LETTER_DATE
		        }else{
		        cStmtObject.setTimestamp(7,null);
		        }
            }
            
            if(swpolicyConfigVO.getPolicyDurationPerMonth() != null){
	            cStmtObject.setLong(8,swpolicyConfigVO.getPolicyDurationPerMonth());
	            }else{
	            	cStmtObject.setLong(8,0);
	            }
            
            if(swpolicyConfigVO.getNoOfLives() != null){
	            cStmtObject.setLong(9,swpolicyConfigVO.getNoOfLives());
	            }else{
	            	cStmtObject.setLong(9,0);
	            }
          
            if(swpolicyConfigVO.getInPatientCPM() != null  && swpolicyConfigVO.getInPatientCPM() !="" && !swpolicyConfigVO.getInPatientCPM().equals("")){
            	           	
            
	            cStmtObject.setBigDecimal(10, new BigDecimal(swpolicyConfigVO.getInPatientCPM()));
	            }else{
	            	cStmtObject.setBigDecimal(10,null);
	            }
	
            if(swpolicyConfigVO.getOutPatientCPM() != null && swpolicyConfigVO.getOutPatientCPM() !="" && !swpolicyConfigVO.getOutPatientCPM().equals("")){
            
	            cStmtObject.setBigDecimal(11,new BigDecimal(swpolicyConfigVO.getOutPatientCPM()));
	            }else{
	            	cStmtObject.setBigDecimal(11,null);
	            }
            
            if(swpolicyConfigVO.getMaternityCPM() != null && swpolicyConfigVO.getMaternityCPM() !="" && !swpolicyConfigVO.getMaternityCPM().equals("")){
            	
	            cStmtObject.setBigDecimal(12,new BigDecimal(swpolicyConfigVO.getMaternityCPM()));
	            }else{
	            	cStmtObject.setBigDecimal(12,null);
	            }
            
            
            if(swpolicyConfigVO.getOpticalCPM() != null && swpolicyConfigVO.getOpticalCPM() !="" && !swpolicyConfigVO.getOpticalCPM().equals("")){
            	
	            cStmtObject.setBigDecimal(13,new BigDecimal(swpolicyConfigVO.getOpticalCPM()));
	            }else{
	            	cStmtObject.setBigDecimal(13,null);
	            }
            
            
            if(swpolicyConfigVO.getDentalCPM() != null && swpolicyConfigVO.getDentalCPM() !="" && !swpolicyConfigVO.getDentalCPM().equals("")){
            	
	            cStmtObject.setBigDecimal(14,new BigDecimal(swpolicyConfigVO.getDentalCPM()));
	            }else{
	            	cStmtObject.setBigDecimal(14,null);
	            }
            
           /* if(swpolicyConfigVO.getFinalweightage() != null &&  swpolicyConfigVO.getFinalweightage()!= ""){
	          //  cStmtObject.setBigDecimal(15,swpolicyConfigVO.getFinalweightage());
            	cStmtObject.setBigDecimal(15,new BigDecimal(swpolicyConfigVO.getFinalweightage()));
	            }else{
	            	cStmtObject.setBigDecimal(15,null);
	            }*/
            
            System.out.println("test inpec.."+swpolicyConfigVO.getInpatientcrediblty());
            
            if(swpolicyConfigVO.getInpatientcrediblty() != null &&  swpolicyConfigVO.getInpatientcrediblty()!= "" && !swpolicyConfigVO.getInpatientcrediblty().equals("")){
            
	            	cStmtObject.setBigDecimal(15,new BigDecimal(swpolicyConfigVO.getInpatientcrediblty()));
		            }else{
		            	cStmtObject.setBigDecimal(15,null);
		            }
            if(swpolicyConfigVO.getOutpatientcrediblty() != null &&  swpolicyConfigVO.getOutpatientcrediblty()!= "" && !swpolicyConfigVO.getOutpatientcrediblty().equals("")){
            	
	            	cStmtObject.setBigDecimal(16,new BigDecimal(swpolicyConfigVO.getOutpatientcrediblty()));
		            }else{
		            	cStmtObject.setBigDecimal(16,null);
		            }
            if(swpolicyConfigVO.getMaternitycrediblty() != null &&  swpolicyConfigVO.getMaternitycrediblty()!= "" && !swpolicyConfigVO.getMaternitycrediblty().equals("")){
            	
	            	cStmtObject.setBigDecimal(17,new BigDecimal(swpolicyConfigVO.getMaternitycrediblty()));
		            }else{
		            	cStmtObject.setBigDecimal(17,null);
		            }
            if(swpolicyConfigVO.getOpticalcrediblty() != null &&  swpolicyConfigVO.getOpticalcrediblty()!= "" && !swpolicyConfigVO.getOpticalcrediblty().equals("")){
            
	            	cStmtObject.setBigDecimal(18,new BigDecimal(swpolicyConfigVO.getOpticalcrediblty()));
		            }else{
		            	cStmtObject.setBigDecimal(18,null);
		            }
            if(swpolicyConfigVO.getDentalcrediblty() != null &&  swpolicyConfigVO.getDentalcrediblty()!= "" && !swpolicyConfigVO.getDentalcrediblty().equals("")){
            
	            	cStmtObject.setBigDecimal(19,new BigDecimal(swpolicyConfigVO.getDentalcrediblty()));
	            	
		            }else{
		            	cStmtObject.setBigDecimal(19,null);
		            }
            
//            cStmtObject.setLong(20,swpolicyConfigVO.getAddedBy());
            cStmtObject.setLong(20,userSeqId);
            cStmtObject.setString(21,swpolicyConfigVO.getSlNo());
            if(swpolicyConfigVO.getTotalCPM() != null &&  swpolicyConfigVO.getTotalCPM()!= "" && !swpolicyConfigVO.getTotalCPM().equals("")){
            	System.out.println("tatol...."+swpolicyConfigVO.getTotalCPM());
            	cStmtObject.setBigDecimal(22,new BigDecimal(swpolicyConfigVO.getTotalCPM()));
	            }else{
	            	cStmtObject.setBigDecimal(22,null);
	            }
          
            cStmtObject.setString(23,null);
            cStmtObject.setString(24,null);
            cStmtObject.setString(25,null);
            cStmtObject.setString(26,null);
            cStmtObject.addBatch();
		}
                cStmtObject.executeBatch(); 
			
		}
		    iResult=i;
		     arraylist.add(iResult);
			
		}
		
		return arraylist;
	}

	@Override
	public void rateCalcProjClm(Long groupSeqId) throws Exception {
		// TODO Auto-generated method stub
		try(Connection con = dataSource.getConnection();
				CallableStatement cStmtObject = (java.sql.CallableStatement)con.prepareCall(strRateCalcProjClm);){			   
			cStmtObject.setLong(1,groupSeqId);		
			cStmtObject.execute();
		}
		
	}

	@Override
	public int saveRiskClaimCostComment(String comment, Long groupSeqId) throws Exception {
		// TODO Auto-generated method stub
		int result=0;
		
		try(Connection con = dataSource.getConnection();
				PreparedStatement pStmtObject = con.prepareStatement(strCommentSave);){
			pStmtObject.setString(1,comment);
			pStmtObject.setLong(2,groupSeqId);
			result = pStmtObject.executeUpdate();						
			
		}
			
		return result;
	}

	@Override
	public SwPolicyConfigVO getComment(Long groupSeqId) throws Exception {
		// TODO Auto-generated method stub
		SwPolicyConfigVO swPolicyConfigVO=null;
		try(Connection con = dataSource.getConnection();
				PreparedStatement pStmtObject = con.prepareStatement(strSelectComment);){
			pStmtObject.setLong(1,groupSeqId);
			try(ResultSet rs = pStmtObject.executeQuery();){
				if(rs != null){
					while(rs.next())
					{
						swPolicyConfigVO = new SwPolicyConfigVO();
						System.out.println("comment daoimpl.."+rs.getString("risk_prem_work_comments"));
						System.out.println("past_policy_run_date.."+rs.getString("past_policy_run_date"));
						swPolicyConfigVO.setProjectClaimComment(UXUtility.checkNull(rs.getString("risk_prem_work_comments")));
					}
						
					}
				}
			}
		return swPolicyConfigVO;
	}

	@Override
	public String getGetProposed(Long groupSeqId) throws Exception {
		// TODO Auto-generated method stub
		
		String statusFlag="";
		try(Connection con = dataSource.getConnection();
				PreparedStatement pStmtObject = con.prepareStatement(strGetPraposedPolicyFlag);){
			pStmtObject.setLong(1,groupSeqId);
			try(ResultSet rs = pStmtObject.executeQuery();){
				if(rs != null){
					while(rs.next())
					{
						statusFlag = UXUtility.checkNull(rs.getString("cal_cpm_sve1_yn"));
					}
						
					}
				}
			}
		
		
		return statusFlag;
	}

  

}

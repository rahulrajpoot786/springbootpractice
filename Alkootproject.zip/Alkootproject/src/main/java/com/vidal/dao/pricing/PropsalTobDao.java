package com.vidal.dao.pricing;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;

import com.vidal.command.pricing.SwFinalQuoteVO;

public interface PropsalTobDao {
	public String getClientName(String clientCode) throws Exception;
	public SwFinalQuoteVO getfalgPricingvalue(Long group_seq_id) throws Exception;
	public int getsave(ArrayList formvalues) throws Exception;
	public SwFinalQuoteVO getdetails(SwFinalQuoteVO swFinalQuoteVO)throws Exception;
	 public int getsavepolicynumber(ArrayList formvalues) throws Exception;
	


}

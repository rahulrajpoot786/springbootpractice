package com.vidal.dao.pricing;

import com.vidal.command.pricing.AdditionalVO;

public interface AdditionalDAO {
	public int getsave(AdditionalVO   additionalVO) throws Exception;
	public AdditionalVO getdetails(AdditionalVO additionalVO)throws Exception;
	public AdditionalVO getfalgPricingvalue(AdditionalVO additionalVO) throws Exception;
	public AdditionalVO getdetailsfetch(AdditionalVO additionalVO)throws Exception;

}

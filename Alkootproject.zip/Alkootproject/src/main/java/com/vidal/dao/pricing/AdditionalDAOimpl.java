package com.vidal.dao.pricing;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Types;

import javax.sql.DataSource;

import oracle.jdbc.OracleTypes;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.vidal.command.pricing.AdditionalVO;
import com.vidal.common.UXUtility;

@Repository

public class AdditionalDAOimpl implements AdditionalDAO {
	@Autowired
	private DataSource dataSource;
	
	private static final String strSwInsuranceProfileList = "{CALL PRICING_APP_PKG.save_additional_benefits(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}";
    private static final String stradditionalFlag="SELECT DISTINCT G.BENF_COV_SVE_YN,G.CAL_CPM_SVE_YN,nvl(CAL_LODING_SVE_YN,'N')CAL_LODING_SVE_YN ,NVL(cal_load_display_yn,'N') cal_load_display_yn ,DMGRPHC_SAVE_YN,TRND_FACTOR_PERC,NVL(F.MODIFY_YN,'Y') AS MODIFY_YN,case when (select  count(*) from APP.TPA_GROPU_BNF_LIVS_DTLS_SPR s where s.grp_prof_seq_id=g.grp_prof_seq_id and nvl(s.tot_cov_lives,0)>0)>0 then 'Y' else nvl(h.census_save_yn,'N') end AS CENSUS_SAVE_YN, G.PAST_POLICY_RUN_DATE,to_char(NVL(nvl(G.PAST_POLICY_RUN_DATE,NVL(D.ADDED_DATE,D.UPDATED_DATE)),G.ADDED_DATE),'dd-mm-yyyy') AS ADDED_DATE,G.MAT_PRICING_DISPLAY,G.PREMIUM_OUTPUT_STRU,G.RENEWAL_YN,G.PREV_POLICY_NO FROM APP.TPA_GROUP_PROFILE_DETAILS_SPR G LEFT OUTER JOIN APP.TPA_GROUP_FNL_CPM_DETAILS_SPR F ON (G.GRP_PROF_SEQ_ID=F.GRP_PROF_SEQ_ID) LEFT JOIN APP.TPA_PAST_POLICY_PRICING_DATA D ON (D.POLICY_NUMBER=G.PREV_POLICY_NO) LEFT OUTER JOIN APP.TPA_GROPU_BNF_LIVS_DTLS_SPR H ON (G.GRP_PROF_SEQ_ID =H.GRP_PROF_SEQ_ID) WHERE G.GRP_PROF_SEQ_ID =?";
   public int getsave(AdditionalVO additionalVO) throws Exception {
          int iResult =0;
        
       try (Connection con = dataSource.getConnection();
               CallableStatement cStmtObject = (java.sql.CallableStatement) con.prepareCall(strSwInsuranceProfileList);) {
           if(additionalVO.getAdditionalseqId() != null){
           cStmtObject.setLong(1,additionalVO.getAdditionalseqId());}
           else{
               cStmtObject.setLong(1,0);
           }
           cStmtObject.setLong(2,additionalVO.getPricingno());
           /*System.out.println("3.."+additionalVO.getOutsideareaofcover());
           cStmtObject.setString(3,additionalVO.getOutsideareaofcover());*/
           cStmtObject.setString(3, ("Select".equalsIgnoreCase(additionalVO.getOutsidedesc())?null:additionalVO.getOutsidedesc()));
           cStmtObject.setString(4, ("Select".equalsIgnoreCase(additionalVO.getLeveldesc())?null:additionalVO.getLeveldesc()));
           /*cStmtObject.setString(4,null);*/
          
           cStmtObject.setString(5, null);
      
           cStmtObject.setString(6, null);
          
      
           cStmtObject.setString(7, null);
          
          
           cStmtObject.setString(8, additionalVO.getInpatientandDaycaretreatment());
           cStmtObject.setString(9, ("Select".equalsIgnoreCase(additionalVO.getParentacmdation())?null:additionalVO.getParentacmdation()));
          
      
           cStmtObject.setString(10, additionalVO.getInpatientlimit());
          
           cStmtObject.setString(11, ("Select".equalsIgnoreCase(additionalVO.getInpatientlimitdecs())?null:additionalVO.getInpatientlimitdecs()));
          
           cStmtObject.setString(12,additionalVO.getStrdiagnostics());
           cStmtObject.setString(13, additionalVO.getDoctriaya());
           cStmtObject.setString(14, additionalVO.getPrescribed());
           cStmtObject.setString(15, additionalVO.getPhysiotherapy());
           cStmtObject.setString(16, additionalVO.getPhysiotherepylimit());
           cStmtObject.setString(17, ("Select".equalsIgnoreCase(additionalVO.getPhysiotherepylimitDesc())?null:additionalVO.getPhysiotherepylimitDesc()));
           cStmtObject.setString(18, additionalVO.getPhysiotherepySession());
           cStmtObject.setString(19, ("Select".equalsIgnoreCase(additionalVO.getPhysiotherepySessionDesc())?null:additionalVO.getPhysiotherepySessionDesc()));
           cStmtObject.setString(20, additionalVO.getAlternativetreatment());
           cStmtObject.setString(21, additionalVO.getAlternativetreatmentlimit());
           cStmtObject.setString(22, ("Select".equalsIgnoreCase(additionalVO.getAlternativetreatmentlimitDesc())?null:additionalVO.getAlternativetreatmentlimitDesc()));
           cStmtObject.setString(23, null);
           cStmtObject.setString(24, additionalVO.getAlternativecopay());
           cStmtObject.setString(25, ("Select".equalsIgnoreCase(additionalVO.getAlternativecopayDesc())?null:additionalVO.getAlternativecopayDesc()));
           cStmtObject.setString(26, additionalVO.getPreexistingcoadtion());
           cStmtObject.setString(27, additionalVO.getPreexistingconditionslimit());
           cStmtObject.setString(28, ("Select".equalsIgnoreCase(additionalVO.getPreexistingconditionslimitDesc())?null:additionalVO.getPreexistingconditionslimitDesc()));
           cStmtObject.setString(29, additionalVO.getMaintenancecoadtion());
           cStmtObject.setString(30, additionalVO.getMaintenanceofChronic());
           cStmtObject.setString(31, ("Select".equalsIgnoreCase(additionalVO.getMaintenanceofChronicDesc())?null:additionalVO.getMaintenanceofChronicDesc()));
           cStmtObject.setString(32, additionalVO.getStracute());
           cStmtObject.setString(33, additionalVO.getStrambulanace());
           cStmtObject.setString(34, additionalVO.getStracendental());
           cStmtObject.setString(35, additionalVO.getStrdevated());
           cStmtObject.setString(36, additionalVO.getHarmonereplace());
           cStmtObject.setString(37, additionalVO.getHormoneReplacementTherapylimit());
           cStmtObject.setString(38, ("Select".equalsIgnoreCase(additionalVO.getHormoneReplacementTherapylimitDesc())?null:additionalVO.getHormoneReplacementTherapylimitDesc()));
           cStmtObject.setString(39, additionalVO.getInpatientrehabationtreatment());
           cStmtObject.setString(40, additionalVO.getInpatientRehabilitation());
           cStmtObject.setString(41, ("Select".equalsIgnoreCase(additionalVO.getInpatientRehabilitationDesc())?null:additionalVO.getInpatientRehabilitationDesc()));
           cStmtObject.setString(42, additionalVO.getNursinghome());
           cStmtObject.setString(43, additionalVO.getNursingathomelimit());
           cStmtObject.setString(44, ("Select".equalsIgnoreCase(additionalVO.getNursingathomelimitDesc())?null:additionalVO.getNursingathomelimitDesc()));
           cStmtObject.setString(45, additionalVO.getOralmax());
           cStmtObject.setString(46, additionalVO.getOrgantransplant());
           cStmtObject.setString(47, additionalVO.getOrganlimit());
           cStmtObject.setString(48, ("Select".equalsIgnoreCase(additionalVO.getOrganlimitDesc())?null:additionalVO.getOrganlimitDesc()));
           cStmtObject.setString(49, additionalVO.getPassiveWar());
           cStmtObject.setString(50, ("Select".equalsIgnoreCase(additionalVO.getPassiveWarDesc())?null:additionalVO.getPassiveWarDesc()));
           cStmtObject.setString(51, additionalVO.getCheckconstructive());
           cStmtObject.setString(52, additionalVO.getVitaminsmed());
           cStmtObject.setString(53, additionalVO.getVitamins());
           cStmtObject.setString(54, ("Select".equalsIgnoreCase(additionalVO.getVitaminsDesc())?null:additionalVO.getVitaminsDesc()));
           cStmtObject.setString(55, additionalVO.getInternationalEmergency());
           cStmtObject.setString(56, additionalVO.getInternationalEmergencylimit());
           cStmtObject.setString(57, ("Select".equalsIgnoreCase(additionalVO.getInternationalEmergencylimitDesc())?null:additionalVO.getInternationalEmergencylimitDesc()));
           cStmtObject.setString(58, additionalVO.getRadiography());
           cStmtObject.setString(59, additionalVO.getPsychiatric());
           cStmtObject.setString(60, additionalVO.getPsychiatrylimit());
           cStmtObject.setString(61, ("Select".equalsIgnoreCase(additionalVO.getPsychiatrylimitDesc())?null:additionalVO.getPsychiatrylimitDesc()));
           cStmtObject.setString(62, additionalVO.getPsychiatrylimitCopay());
           cStmtObject.setString(63, ("Select".equalsIgnoreCase(additionalVO.getPsychiatrylimitCopayDesc())?null:additionalVO.getPsychiatrylimitCopayDesc()));
           cStmtObject.setString(64, additionalVO.getVaccination());
           cStmtObject.setString(65, additionalVO.getVaccinationslimit());
           cStmtObject.setString(66, ("Select".equalsIgnoreCase(additionalVO.getVaccinationslimitDesc())?null:additionalVO.getVaccinationslimitDesc()));
           cStmtObject.setString(67, additionalVO.getVaccinationage());
           cStmtObject.setString(68, ("Select".equalsIgnoreCase(additionalVO.getVaccinationsDesc())?null:additionalVO.getVaccinationsDesc()));
           cStmtObject.setString(69, additionalVO.getPregnancy());
           cStmtObject.setString(70, ("Select".equalsIgnoreCase(additionalVO.getPregnancyDesc())?null:additionalVO.getPregnancyDesc()));
           cStmtObject.setString(71, additionalVO.getPreandpost());
           cStmtObject.setString(72, additionalVO.getPreandpostnatal());
           cStmtObject.setString(73, ("Select".equalsIgnoreCase(additionalVO.getPreandpostnatalDesc())?null:additionalVO.getPreandpostnatalDesc()));
      
           cStmtObject.setString(74, null);
          
           cStmtObject.setString(75, null);
           cStmtObject.setString(76, null);
      
           cStmtObject.setString(77, additionalVO.getHealth());
           cStmtObject.setString(78, additionalVO.getHealthscreenlimit());
           cStmtObject.setString(79, ("Select".equalsIgnoreCase(additionalVO.getHealthscreenlimitDesc())?null:additionalVO.getHealthscreenlimitDesc()));
           cStmtObject.setString(80, additionalVO.getHealthsessions());
           cStmtObject.setString(81, ("Select".equalsIgnoreCase(additionalVO.getHealthsessionsDesc())?null:additionalVO.getHealthsessionsDesc()));
           cStmtObject.setString(82, additionalVO.getHealthscreencopay());
           cStmtObject.setString(83, ("Select".equalsIgnoreCase(additionalVO.getHealthscreencopayDesc())?null:additionalVO.getHealthscreencopayDesc()));
           cStmtObject.setString(84, additionalVO.getGumsurgery());
           cStmtObject.setString(85, additionalVO.getDeductiblecoinsurance());
           cStmtObject.setString(86, ("Select".equalsIgnoreCase(additionalVO.getDeductiblecoinsuranceDesc())?null:additionalVO.getDeductiblecoinsuranceDesc()));
           cStmtObject.setString(87, additionalVO.getExternalprothis());
           cStmtObject.setString(88, additionalVO.getExternalProsthesis());
           cStmtObject.setString(89, ("Select".equalsIgnoreCase(additionalVO.getExternalProsthesisDesc())?null:additionalVO.getExternalProsthesisDesc()));
           cStmtObject.setString(90, additionalVO.getWorkrelateddrop1());
           cStmtObject.setString(91, ("Select".equalsIgnoreCase(additionalVO.getWorkrelateddrop1Desc())?null:additionalVO.getWorkrelateddrop1Desc()));
           cStmtObject.setString(92, additionalVO.getWorkrelated());
           cStmtObject.setString(93, ("Select".equalsIgnoreCase(additionalVO.getWorkrelatedDesc())?null:additionalVO.getWorkrelatedDesc()));
           cStmtObject.setString(94, additionalVO.getLifeThreateningdiease());
           cStmtObject.setString(95, ("Select".equalsIgnoreCase(additionalVO.getLifeThreateningdieaseDesc())?null:additionalVO.getLifeThreateningdieaseDesc()));
           cStmtObject.setString(96, additionalVO.getLifeThreatening());
           cStmtObject.setString(97, ("Select".equalsIgnoreCase(additionalVO.getLifeThreateningDesc())?null:additionalVO.getLifeThreateningDesc()));
           cStmtObject.setString(98, additionalVO.getObesitysurgry());
           cStmtObject.setString(99, additionalVO.getObesity());
           cStmtObject.setString(100, ("Select".equalsIgnoreCase(additionalVO.getObesityDesc())?null:additionalVO.getObesityDesc()));
           cStmtObject.setString(101, additionalVO.getHospice());
           cStmtObject.setString(102, additionalVO.getHospiceandPalliative());
           cStmtObject.setString(103, ("Select".equalsIgnoreCase(additionalVO.getHospiceandPalliativeDesc())?null:additionalVO.getHospiceandPalliativeDesc()));
           cStmtObject.setString(104, additionalVO.getExternalmed());
           cStmtObject.setString(105, additionalVO.getExternalmedical());
           cStmtObject.setString(106, ("Select".equalsIgnoreCase(additionalVO.getExternalmedicalDesc())?null:additionalVO.getExternalmedicalDesc()));
           cStmtObject.setString(107, additionalVO.getExternalmedicalcopay());
           cStmtObject.setString(108, ("Select".equalsIgnoreCase(additionalVO.getExternalmedicalcopayDesc())?null:additionalVO.getExternalmedicalcopayDesc()));
           cStmtObject.setString(109, additionalVO.getDietican());
           cStmtObject.setString(110, additionalVO.getDitecianlimit());
           cStmtObject.setString(111, ("Select".equalsIgnoreCase(additionalVO.getDitecianlimitDesc())?null:additionalVO.getDitecianlimitDesc()));
           cStmtObject.setString(112, additionalVO.getStrhiv());
           cStmtObject.setString(113, additionalVO.gethIVandaIDSLimit());
           cStmtObject.setString(114, ("Select".equalsIgnoreCase(additionalVO.gethIVandaIDSLimitDesc())?null:additionalVO.gethIVandaIDSLimitDesc()));
           cStmtObject.setString(115, additionalVO.getCircumcision());
           cStmtObject.setString(116, additionalVO.getCircumcisionlimit());
           cStmtObject.setString(117, ("Select".equalsIgnoreCase(additionalVO.getCircumcisionlimitDesc())?null:additionalVO.getCircumcisionlimitDesc()));
           cStmtObject.setString(118, additionalVO.getCompassionate());
           cStmtObject.setString(119, additionalVO.getCompassionatevisit());
           cStmtObject.setString(120, ("Select".equalsIgnoreCase(additionalVO.getCompassionatevisitDesc())?null:additionalVO.getCompassionatevisitDesc()));
           cStmtObject.setString(121, additionalVO.getComments());
      
           cStmtObject.setString(122, null);
           cStmtObject.setString(123, additionalVO.getStrinpatientboadrd());
           if("Select".equals(additionalVO.getStrinpatientboadrdDesc())){
           cStmtObject.setString(124, null);
           }else{
               cStmtObject.setString(124, additionalVO.getStrinpatientboadrdDesc());
           }
           cStmtObject.setString(125, additionalVO.getParentaccomdation());
           if("Select".equals(additionalVO.getParentaccomdationDesc())){
               cStmtObject.setString(126, null);
               }else{
           cStmtObject.setString(126, additionalVO.getParentaccomdationDesc());
               }
           cStmtObject.setString(127, additionalVO.getStrinpatientcash());
           cStmtObject.setString(128, ("Select".equalsIgnoreCase(additionalVO.getStrinpatientcashDesc())?null:additionalVO.getStrinpatientcashDesc()));
           cStmtObject.setString(129, additionalVO.getAlternativesession());
           cStmtObject.setString(130, ("Select".equalsIgnoreCase(additionalVO.getAlternativesessiondesc())?null:additionalVO.getAlternativesessiondesc()));
           cStmtObject.setString(131, additionalVO.getApproval());
           cStmtObject.setString(132, ("Select".equalsIgnoreCase(additionalVO.getApprovaldesc())?null:additionalVO.getApprovaldesc()));
          
           cStmtObject.setString(133, additionalVO.getNewborn());
           cStmtObject.setString(134, additionalVO.getDentalprothis());
           cStmtObject.setString(135, additionalVO.getDentalprothisdesc());
           
         
           cStmtObject.setString(136, additionalVO.getCongtal());
           cStmtObject.setString(137, additionalVO.getCongtalDesc());
          
           cStmtObject.setString(138, additionalVO.getOncology());
           cStmtObject.setString(139, additionalVO.getOncologydesc());
          
           cStmtObject.setString(140, additionalVO.getRepatriation());
           cStmtObject.setString(141, additionalVO.getRepatriationDesc());
          
           cStmtObject.setString(142, additionalVO.getTerminal());
           cStmtObject.setString(143, additionalVO.getTerminalDesc());
          
           cStmtObject.setString(144, additionalVO.getHome());
       
           cStmtObject.setString(145, additionalVO.getPslYN());
          
           if(additionalVO.getPsllimit() != null && !additionalVO.getPsllimit().equals("")) {
        	   cStmtObject.setLong(146,Long.parseLong( additionalVO.getPsllimit()));
           }else {
        	   cStmtObject.setString(146,null);
           }
        
           
           cStmtObject.setString(147, additionalVO.getPsllimitdesc());
           cStmtObject.setString(148, additionalVO.getOutsideareaofcover());
           cStmtObject.setString(149, additionalVO.getLevelofcover());
           cStmtObject.setString(150, additionalVO.getAlternativeTreatments());
           cStmtObject.setString(151, additionalVO.getAlternativeTreatmentsdesc());
           cStmtObject.setString(152, additionalVO.getReimbursmentLevel());
           cStmtObject.setString(153, additionalVO.getReimbursmentLeveldesc());
          
          
            cStmtObject.registerOutParameter(154,Types.INTEGER);
               cStmtObject.execute();
               iResult = cStmtObject.getInt(154);
           // TODO Auto-generated method stub
            
       }
             return iResult;
}
	@Override
	public AdditionalVO getdetails(AdditionalVO additionalVO) throws Exception {
		try (Connection con = dataSource.getConnection();
				CallableStatement cStmtObject = (java.sql.CallableStatement) con
						.prepareCall("{CALL PRICING_APP_PKG.select_additional_benefits(?,?)}");) {
			if(additionalVO.getPricingno() != null){
				
				cStmtObject.setLong(1,additionalVO.getPricingno());}
			else{
				cStmtObject.setLong(1,0);
			}
			cStmtObject.registerOutParameter(2,OracleTypes.CURSOR);
			cStmtObject.execute(); 
			try(ResultSet rs = (java.sql.ResultSet)cStmtObject.getObject(2);){
				if(rs != null){
					while(rs.next())
					{
						additionalVO.setFetch(UXUtility.checkNull(rs.getString("RENEWAL_YN")));
						additionalVO.setAdditionalseqId(new Long(rs.getLong("benf_seq_id")));
						additionalVO.setPricingno(new Long(rs.getLong("pric_seq_id")));
						additionalVO.setOutsideareaofcover(UXUtility.checkNull(rs.getString("out_area_cov")));
						additionalVO.setLevelofcover(UXUtility.checkNull(rs.getString("level_of_cov")));
						additionalVO.setInpatientandDaycaretreatment(UXUtility.checkNull(rs.getString("prnt_accom_seq")));
						additionalVO.setParentaccomdation(UXUtility.checkNull(rs.getString("compn_accom_seq")));
						additionalVO.setStrinpatientboadrd(UXUtility.checkNull(rs.getString("prnt_accom_age_lmt_seq")));
						additionalVO.setStrinpatientcash(UXUtility.checkNull(rs.getString("compn_accom_age_lmt_seq")));
						additionalVO.setStrdiagnostics(UXUtility.checkNull(rs.getString("diagnosys_yn")));
						additionalVO.setDoctriaya(UXUtility.checkNull(rs.getString("dctr_consl_yn")));
						additionalVO.setPrescribed(UXUtility.checkNull(rs.getString("prcbd_drugs_yn")));
						/*additionalVO.setPhysiotherapy(UXUtility.checkNull(rs.getString("Y")));*/
						additionalVO.setPhysiotherapy(UXUtility.checkNull(rs.getString("phystepy_yn")));
						additionalVO.setPhysiotherepylimit(UXUtility.checkNull(rs.getString("phystepy_lmt_seq")));
						additionalVO.setPhysiotherepySession(UXUtility.checkNull(rs.getString("phystepy_sessn_seq")));
						additionalVO.setAlternativetreatment(UXUtility.checkNull(rs.getString("altnt_cmpl_yn")));
						additionalVO.setAlternativetreatmentlimit(UXUtility.checkNull(rs.getString("altnt_cmpl_lmt_seq")));
						additionalVO.setChiropractic(UXUtility.checkNull(rs.getString("op_trtmnt_text")));
						additionalVO.setAlternativecopay(UXUtility.checkNull(rs.getString("altnt_cmpl_cpy_seq")));
						additionalVO.setPreexistingcoadtion(UXUtility.checkNull(rs.getString("preext_cond_yn")));
						additionalVO.setPreexistingconditionslimit(UXUtility.checkNull(rs.getString("preext_cond_lmt_seq")));
						additionalVO.setMaintenancecoadtion(UXUtility.checkNull(rs.getString("mntnc_crnc_yn")));
						additionalVO.setMaintenanceofChronic(UXUtility.checkNull(rs.getString("mntnc_crnc_lmt_seq")));
						additionalVO.setStracute(UXUtility.checkNull(rs.getString("acut_crnc_cond_yn")));
						additionalVO.setStrambulanace(UXUtility.checkNull(rs.getString("ambulance_yn")));
						additionalVO.setStracendental(UXUtility.checkNull(rs.getString("accd_dmg_teeth_yn")));
						additionalVO.setStrdevated(UXUtility.checkNull(rs.getString("dvtd_nssl_sptm_yn")));
						additionalVO.setHarmonereplace(UXUtility.checkNull(rs.getString("hrmn_rplmt_yn")));
						additionalVO.setHormoneReplacementTherapylimit(UXUtility.checkNull(rs.getString("hrmn_rplmt_lmt_seq")));
						additionalVO.setInpatientrehabationtreatment(UXUtility.checkNull(rs.getString("ip_rhbltn_yn")));
						additionalVO.setInpatientRehabilitation(UXUtility.checkNull(rs.getString("ip_rhbltn_lmt_seq")));
						additionalVO.setNursinghome(UXUtility.checkNull(rs.getString("nrsng_home_yn")));
						additionalVO.setNursingathomelimit(UXUtility.checkNull(rs.getString("nrsng_home_lmt_Seq")));
						additionalVO.setOralmax(UXUtility.checkNull(rs.getString("oral_maxilfcl_yn")));
						additionalVO.setOrgantransplant(UXUtility.checkNull(rs.getString("orgn_trnplnt_yn")));
						additionalVO.setOrganlimit(UXUtility.checkNull(rs.getString("orgn_trnplnt_lmt_seq")));
						additionalVO.setPassiveWar(UXUtility.checkNull(rs.getString("pssv_war_trrsm_seq")));
						additionalVO.setOutsideareaofcover(UXUtility.checkNull(rs.getString("OUT_AREA_COV_SEQ")));
						additionalVO.setLevelofcover(UXUtility.checkNull(rs.getString("LEVEL_OF_COV_SEQ")));
						
						additionalVO.setCheckconstructive(UXUtility.checkNull(rs.getString("recnstctv_srgry_yn")));
						additionalVO.setVitaminsmed(UXUtility.checkNull(rs.getString("vitamins_yn")));
						additionalVO.setVitamins(UXUtility.checkNull(rs.getString("vitamins_lmt_seq")));
						additionalVO.setInternationalEmergency(UXUtility.checkNull(rs.getString("iema_yn")));
						additionalVO.setInternationalEmergencylimit(UXUtility.checkNull(rs.getString("iema_lmt_seq")));
						additionalVO.setRadiography(UXUtility.checkNull(rs.getString("rcct_incl_mag_yn")));
						additionalVO.setPsychiatric(UXUtility.checkNull(rs.getString("phys_trtment_yn")));
						additionalVO.setPsychiatrylimit(UXUtility.checkNull(rs.getString("phys_lmt_seq")));
						additionalVO.setPsychiatrylimitCopay(UXUtility.checkNull(rs.getString("phys_cpy_seq")));
						additionalVO.setVaccination(UXUtility.checkNull(rs.getString("Vaccin_yn")));
						additionalVO.setVaccinationage(UXUtility.checkNull(rs.getString("vaccin_age_lmt_seq")));
						additionalVO.setVaccinationslimit(UXUtility.checkNull(rs.getString("vaccin_lmt_seq")));
						additionalVO.setHealthsessions(UXUtility.checkNull(rs.getString("Hlth_scrn_sess_seq")));
						additionalVO.setPregnancy(UXUtility.checkNull(rs.getString("prgn_chldbrth_seq")));
						additionalVO.setPreandpost(UXUtility.checkNull(rs.getString("prepost_cmpl_yn")));
						additionalVO.setPreandpostnatal(UXUtility.checkNull(rs.getString("prepost_cmpl_lmt_seq")));
						additionalVO.setWellbeingbenfit(UXUtility.checkNull(rs.getString("wlbng_benf_yn")));
						additionalVO.setWellbeingbenefit(UXUtility.checkNull(rs.getString("wlbng_benf_lmt_seq")));
						additionalVO.setHealth(UXUtility.checkNull(rs.getString("Hlth_scrn_yn")));
						additionalVO.setHealthscreenlimit(UXUtility.checkNull(rs.getString("Hlth_scrn_lmt_seq")));
						additionalVO.setHealthscreencopay(UXUtility.checkNull(rs.getString("Hlth_scrn_cpy_ded_seq")));
						additionalVO.setGumsurgery(UXUtility.checkNull(rs.getString("gum_surg_yn")));
						additionalVO.setDeductiblecoinsurance(UXUtility.checkNull(rs.getString("ded_coins_con_seq")));
						additionalVO.setExternalprothis(UXUtility.checkNull(rs.getString("extnl_prstss_yn")));
						additionalVO.setExternalProsthesis(UXUtility.checkNull(rs.getString("extnl_prstss_lmt_seq")));
						additionalVO.setWorkrelateddrop1(UXUtility.checkNull(rs.getString("wrk_rltd_inj_seq")));
						additionalVO.setWorkrelated(UXUtility.checkNull(rs.getString("wrk_rltd_inj_lmt_seq")));
						additionalVO.setLifeThreateningdiease(UXUtility.checkNull(rs.getString("lfe_thrtn_des_seq")));
						additionalVO.setLifeThreatening(UXUtility.checkNull(rs.getString("lfe_thrtn_lmt_seq")));
						additionalVO.setObesitysurgry(UXUtility.checkNull(rs.getString("Gstrc_bislv_yn")));
						additionalVO.setObesity(UXUtility.checkNull(rs.getString("Gstrc_bislv_lmt_seq")));
						additionalVO.setHospice(UXUtility.checkNull(rs.getString("hosp_pltv_yn")));
						additionalVO.setHospiceandPalliative(UXUtility.checkNull(rs.getString("hosp_pltv_lmt_seq")));
						additionalVO.setExternalmed(UXUtility.checkNull(rs.getString("ext_med_apl_yn")));
						additionalVO.setExternalmedical(UXUtility.checkNull(rs.getString("ext_med_apl_lmt_seq")));
						additionalVO.setExternalmedicalcopay(UXUtility.checkNull(rs.getString("ext_med_apl_cpy_Seq")));
						additionalVO.setDietican(UXUtility.checkNull(rs.getString("Dietician_yn")));
						additionalVO.setDitecianlimit(UXUtility.checkNull(rs.getString("Dietician_lmt_seq")));
						additionalVO.setStrhiv(UXUtility.checkNull(rs.getString("hiv_aids_yn")));
						additionalVO.sethIVandaIDSLimit(UXUtility.checkNull(rs.getString("hiv_aids_lmt_seq")));
						additionalVO.setCircumcision(UXUtility.checkNull(rs.getString("Crcmson_yn")));
						additionalVO.setCircumcisionlimit(UXUtility.checkNull(rs.getString("Crcmson_lmt_seq")));
						additionalVO.setCompassionate(UXUtility.checkNull(rs.getString("cmpsson_emeg_yn")));
						additionalVO.setCompassionatevisit(UXUtility.checkNull(rs.getString("cmpsson_emeg_lmt_seq")));
						additionalVO.setComments(UXUtility.checkNull(rs.getString("additional_cmnts")));
						additionalVO.setSecondmedical(UXUtility.checkNull(rs.getString("sec_med_option")));
						
						//new 
						additionalVO.setNewborn(UXUtility.checkNull(rs.getString("newborn_cover_yn")));
						additionalVO.setDentalprothis(UXUtility.checkNull(rs.getString("dent_prosth_seq")));
						additionalVO.setDentalprothisdesc(UXUtility.checkNull(rs.getString("dent_prosth_desc")));
						additionalVO.setAlternativesession(UXUtility.checkNull(rs.getString("altnt_cmpl_sess_seq")));
						additionalVO.setApproval(UXUtility.checkNull(rs.getString("approval_lmt_seq")));
						additionalVO.setCongtal(UXUtility.checkNull(rs.getString("congen_cond_seq")));
						additionalVO.setCongtalDesc(UXUtility.checkNull(rs.getString("congen_cond_desc")));
						additionalVO.setOncology(UXUtility.checkNull(rs.getString("oncology_seq")));
						additionalVO.setOncologydesc(UXUtility.checkNull(rs.getString("oncology_desc")));
						additionalVO.setRepatriation(UXUtility.checkNull(rs.getString("repatr_mrtl_remns_seq")));
						additionalVO.setRepatriationDesc(UXUtility.checkNull(rs.getString("repatr_mrtl_remns_desc")));
						additionalVO.setTerminal(UXUtility.checkNull(rs.getString("trminl_illness_seq")));
						additionalVO.setTerminalDesc(UXUtility.checkNull(rs.getString("trminl_illness_desc")));
						additionalVO.setHome(UXUtility.checkNull(rs.getString("at_home_doc_yn")));
						additionalVO.setPslYN(UXUtility.checkNull(rs.getString("psl_wellness_yn")));
						additionalVO.setPsllimit(UXUtility.checkNull(rs.getString("psl_wellness_lmt_seq")));
						additionalVO.setInpatientlimit(UXUtility.checkNull(rs.getString("ip_cash_benf_seq")));
						
						additionalVO.setAlternativeTreatments(UXUtility.checkNull(rs.getString("altnt_trmt_seq")));
						additionalVO.setAlternativeTreatmentsdesc(UXUtility.checkNull(rs.getString("altnt_trmt_desc")));
						additionalVO.setReimbursmentLevel(UXUtility.checkNull(rs.getString("rembrsmnt_lvl_seq")));
						additionalVO.setReimbursmentLeveldesc(UXUtility.checkNull(rs.getString("rembrsmnt_lvl_desc")));
						
					}
					}
			
			
			
		}
		
		return additionalVO;
	}}
	
	@Override
	public AdditionalVO getdetailsfetch(AdditionalVO additionalVO) throws Exception {
		try (Connection con = dataSource.getConnection();
				CallableStatement cStmtObject = (java.sql.CallableStatement) con
						.prepareCall("{CALL PRICING_APP_PKG.fetch_past_additional_benf(?,?,?)}");) {
                  if(additionalVO.getPrevespolno() != null){
				
				cStmtObject.setString(1,additionalVO.getPrevespolno());}
			else{
				cStmtObject.setString(1,null);
			}
			if(additionalVO.getRenewalYN() != null){
				
				cStmtObject.setString(2,additionalVO.getRenewalYN());}
			else{
				cStmtObject.setString(2,null);
			}
               
			cStmtObject.registerOutParameter(3,OracleTypes.CURSOR);
			cStmtObject.execute(); 
			try(ResultSet rs = (java.sql.ResultSet)cStmtObject.getObject(3);){
				if(rs != null){
					while(rs.next())
					{
						if((rs.getString("OUT_AREA_COV_SEQ")!=null)){
						additionalVO.setOutsideareaofcover(UXUtility.checkNull(rs.getString("OUT_AREA_COV_SEQ").trim()));
						}
						additionalVO.setLevelofcover(UXUtility.checkNull(rs.getString("LEVEL_OF_COV_SEQ")));
						
						//additionalVO.setAdditionalseqId(new Long(rs.getLong("benf_seq_id")));
						//additionalVO.setPricingno(new Long(rs.getLong("pric_seq_id")));
						additionalVO.setRenewalYNadd(UXUtility.checkNull(rs.getString("RENEWAL_YN")));
						//additionalVO.setOutsideareaofcover(UXUtility.checkNull(rs.getString("out_area_cov")));
						//additionalVO.setLevelofcover(UXUtility.checkNull(rs.getString("level_of_cov")));
						additionalVO.setInpatientandDaycaretreatment(UXUtility.checkNull(rs.getString("prnt_accom_seq")));
						additionalVO.setParentaccomdation(UXUtility.checkNull(rs.getString("compn_accom_seq")));
						additionalVO.setStrinpatientboadrd(UXUtility.checkNull(rs.getString("prnt_accom_age_lmt_seq")));
						additionalVO.setStrinpatientcash(UXUtility.checkNull(rs.getString("compn_accom_age_lmt_seq")));
						additionalVO.setStrdiagnostics(UXUtility.checkNull(rs.getString("diagnosys_yn")));
						additionalVO.setDoctriaya(UXUtility.checkNull(rs.getString("dctr_consl_yn")));
						additionalVO.setPrescribed(UXUtility.checkNull(rs.getString("prcbd_drugs_yn")));
						/*additionalVO.setPhysiotherapy(UXUtility.checkNull(rs.getString("Y")));*/
						additionalVO.setPhysiotherapy(UXUtility.checkNull(rs.getString("phystepy_yn")));
						additionalVO.setPhysiotherepylimit(UXUtility.checkNull(rs.getString("phystepy_lmt_seq")));
						additionalVO.setPhysiotherepySession(UXUtility.checkNull(rs.getString("phystepy_sessn_seq")));
						additionalVO.setAlternativetreatment(UXUtility.checkNull(rs.getString("altnt_cmpl_yn")));
						additionalVO.setAlternativetreatmentlimit(UXUtility.checkNull(rs.getString("altnt_cmpl_lmt_seq")));
						//additionalVO.setChiropractic(UXUtility.checkNull(rs.getString("op_trtmnt_text")));
						additionalVO.setAlternativecopay(UXUtility.checkNull(rs.getString("altnt_cmpl_cpy_seq")));
						additionalVO.setPreexistingcoadtion(UXUtility.checkNull(rs.getString("preext_cond_yn")));
						additionalVO.setPreexistingconditionslimit(UXUtility.checkNull(rs.getString("preext_cond_lmt_seq")));
						additionalVO.setMaintenancecoadtion(UXUtility.checkNull(rs.getString("mntnc_crnc_yn")));
						additionalVO.setMaintenanceofChronic(UXUtility.checkNull(rs.getString("mntnc_crnc_lmt_seq")));
						additionalVO.setStracute(UXUtility.checkNull(rs.getString("acut_crnc_cond_yn")));
						additionalVO.setStrambulanace(UXUtility.checkNull(rs.getString("ambulance_yn")));
						additionalVO.setStracendental(UXUtility.checkNull(rs.getString("accd_dmg_teeth_yn")));
						additionalVO.setStrdevated(UXUtility.checkNull(rs.getString("dvtd_nssl_sptm_yn")));
						additionalVO.setHarmonereplace(UXUtility.checkNull(rs.getString("hrmn_rplmt_yn")));
						additionalVO.setHormoneReplacementTherapylimit(UXUtility.checkNull(rs.getString("hrmn_rplmt_lmt_seq")));
						additionalVO.setInpatientrehabationtreatment(UXUtility.checkNull(rs.getString("ip_rhbltn_yn")));
						additionalVO.setInpatientRehabilitation(UXUtility.checkNull(rs.getString("ip_rhbltn_lmt_seq")));
						additionalVO.setNursinghome(UXUtility.checkNull(rs.getString("nrsng_home_yn")));
						additionalVO.setNursingathomelimit(UXUtility.checkNull(rs.getString("nrsng_home_lmt_Seq")));
						additionalVO.setOralmax(UXUtility.checkNull(rs.getString("oral_maxilfcl_yn")));
						additionalVO.setOrgantransplant(UXUtility.checkNull(rs.getString("orgn_trnplnt_yn")));
						additionalVO.setOrganlimit(UXUtility.checkNull(rs.getString("orgn_trnplnt_lmt_seq")));
						additionalVO.setPassiveWar(UXUtility.checkNull(rs.getString("pssv_war_trrsm_seq")));
						
						additionalVO.setCheckconstructive(UXUtility.checkNull(rs.getString("recnstctv_srgry_yn")));
						additionalVO.setVitaminsmed(UXUtility.checkNull(rs.getString("vitamins_yn")));
						additionalVO.setVitamins(UXUtility.checkNull(rs.getString("vitamins_lmt_seq")));
						additionalVO.setInternationalEmergency(UXUtility.checkNull(rs.getString("iema_yn")));
						additionalVO.setInternationalEmergencylimit(UXUtility.checkNull(rs.getString("iema_lmt_seq")));
						additionalVO.setRadiography(UXUtility.checkNull(rs.getString("rcct_incl_mag_yn")));
						additionalVO.setPsychiatric(UXUtility.checkNull(rs.getString("phys_trtment_yn")));
						additionalVO.setPsychiatrylimit(UXUtility.checkNull(rs.getString("phys_lmt_seq")));
						additionalVO.setPsychiatrylimitCopay(UXUtility.checkNull(rs.getString("phys_cpy_seq")));
						additionalVO.setVaccination(UXUtility.checkNull(rs.getString("Vaccin_yn")));
						additionalVO.setVaccinationage(UXUtility.checkNull(rs.getString("vaccin_age_lmt_seq")));
						additionalVO.setVaccinationslimit(UXUtility.checkNull(rs.getString("vaccin_lmt_seq")));
						additionalVO.setHealthsessions(UXUtility.checkNull(rs.getString("Hlth_scrn_sess_seq")));
						additionalVO.setPregnancy(UXUtility.checkNull(rs.getString("prgn_chldbrth_seq")));
						additionalVO.setPreandpost(UXUtility.checkNull(rs.getString("prepost_cmpl_yn")));
						additionalVO.setPreandpostnatal(UXUtility.checkNull(rs.getString("prepost_cmpl_lmt_seq")));
						//additionalVO.setWellbeingbenfit(UXUtility.checkNull(rs.getString("wlbng_benf_yn")));
						//additionalVO.setWellbeingbenefit(UXUtility.checkNull(rs.getString("wlbng_benf_lmt_seq")));
						additionalVO.setHealth(UXUtility.checkNull(rs.getString("Hlth_scrn_yn")));
						additionalVO.setHealthscreenlimit(UXUtility.checkNull(rs.getString("Hlth_scrn_lmt_seq")));
						additionalVO.setHealthscreencopay(UXUtility.checkNull(rs.getString("Hlth_scrn_cpy_ded_seq")));
						additionalVO.setGumsurgery(UXUtility.checkNull(rs.getString("gum_surg_yn")));
						additionalVO.setDeductiblecoinsurance(UXUtility.checkNull(rs.getString("ded_coins_con_seq")));
						additionalVO.setExternalprothis(UXUtility.checkNull(rs.getString("extnl_prstss_yn")));
						additionalVO.setExternalProsthesis(UXUtility.checkNull(rs.getString("extnl_prstss_lmt_seq")));
						additionalVO.setWorkrelateddrop1(UXUtility.checkNull(rs.getString("wrk_rltd_inj_seq")));
						additionalVO.setWorkrelated(UXUtility.checkNull(rs.getString("wrk_rltd_inj_lmt_seq")));
						additionalVO.setLifeThreateningdiease(UXUtility.checkNull(rs.getString("lfe_thrtn_des_seq")));
						additionalVO.setLifeThreatening(UXUtility.checkNull(rs.getString("lfe_thrtn_lmt_seq")));
						additionalVO.setObesitysurgry(UXUtility.checkNull(rs.getString("Gstrc_bislv_yn")));
						additionalVO.setObesity(UXUtility.checkNull(rs.getString("Gstrc_bislv_lmt_seq")));
						additionalVO.setHospice(UXUtility.checkNull(rs.getString("hosp_pltv_yn")));
						additionalVO.setHospiceandPalliative(UXUtility.checkNull(rs.getString("hosp_pltv_lmt_seq")));
						additionalVO.setExternalmed(UXUtility.checkNull(rs.getString("ext_med_apl_yn")));
						additionalVO.setExternalmedical(UXUtility.checkNull(rs.getString("ext_med_apl_lmt_seq")));
						additionalVO.setExternalmedicalcopay(UXUtility.checkNull(rs.getString("ext_med_apl_cpy_Seq")));
						additionalVO.setDietican(UXUtility.checkNull(rs.getString("Dietician_yn")));
						additionalVO.setDitecianlimit(UXUtility.checkNull(rs.getString("Dietician_lmt_seq")));
						additionalVO.setStrhiv(UXUtility.checkNull(rs.getString("hiv_aids_yn")));
						additionalVO.sethIVandaIDSLimit(UXUtility.checkNull(rs.getString("hiv_aids_lmt_seq")));
						additionalVO.setCircumcision(UXUtility.checkNull(rs.getString("Crcmson_yn")));
						additionalVO.setCircumcisionlimit(UXUtility.checkNull(rs.getString("Crcmson_lmt_seq")));
						additionalVO.setCompassionate(UXUtility.checkNull(rs.getString("cmpsson_emeg_yn")));
						additionalVO.setCompassionatevisit(UXUtility.checkNull(rs.getString("cmpsson_emeg_lmt_seq")));
						additionalVO.setComments(UXUtility.checkNull(rs.getString("additional_cmnts")));
						//additionalVO.setSecondmedical(UXUtility.checkNull(rs.getString("sec_med_option")));
						
						//new 
						additionalVO.setNewborn(UXUtility.checkNull(rs.getString("newborn_cover_yn")));
						
						additionalVO.setDentalprothis(UXUtility.checkNull(rs.getString("dent_prosth_seq")));
						additionalVO.setDentalprothisdesc(UXUtility.checkNull(rs.getString("dent_prosth_desc")));
						
						additionalVO.setAlternativesession(UXUtility.checkNull(rs.getString("altnt_cmpl_sess_seq")));
						additionalVO.setApproval(UXUtility.checkNull(rs.getString("approval_lmt_seq")));
						additionalVO.setCongtal(UXUtility.checkNull(rs.getString("congen_cond_seq")));
						additionalVO.setCongtalDesc(UXUtility.checkNull(rs.getString("congen_cond_desc")));
						
						additionalVO.setOncology(UXUtility.checkNull(rs.getString("oncology_seq")));
						additionalVO.setOncologydesc(UXUtility.checkNull(rs.getString("oncology_desc")));
						
						additionalVO.setRepatriation(UXUtility.checkNull(rs.getString("repatr_mrtl_remns_seq")));
						additionalVO.setRepatriationDesc(UXUtility.checkNull(rs.getString("repatr_mrtl_remns_desc")));
						
						additionalVO.setTerminal(UXUtility.checkNull(rs.getString("trminl_illness_seq")));
						additionalVO.setTerminalDesc(UXUtility.checkNull(rs.getString("trminl_illness_desc")));
						
						additionalVO.setHome(UXUtility.checkNull(rs.getString("at_home_doc_yn")));
						additionalVO.setPslYN(UXUtility.checkNull(rs.getString("psl_wellness_yn")));
						additionalVO.setPsllimit(UXUtility.checkNull(rs.getString("psl_wellness_lmt_seq")));
						additionalVO.setInpatientlimit(UXUtility.checkNull(rs.getString("ip_cash_benf_seq")));

						additionalVO.setAlternativeTreatments(UXUtility.checkNull(rs.getString("altnt_trmt_seq")));
						additionalVO.setAlternativeTreatmentsdesc(UXUtility.checkNull(rs.getString("altnt_trmt_desc")));
						additionalVO.setReimbursmentLevel(UXUtility.checkNull(rs.getString("rembrsmnt_lvl_seq")));
						additionalVO.setReimbursmentLeveldesc(UXUtility.checkNull(rs.getString("rembrsmnt_lvl_desc")));
						
					}
					}
			
			
			
		}
		
		return additionalVO;
	}}
	
	@Override
	public AdditionalVO getfalgPricingvalue(AdditionalVO additionalVO)throws Exception {
		Connection conn = null;
        PreparedStatement pStmt = null;
       
	
		try (Connection con = dataSource.getConnection();
				CallableStatement cStmtObject = (java.sql.CallableStatement) con.prepareCall(stradditionalFlag);) {
			cStmtObject.setLong(1,additionalVO.getPricingno());
	           try( ResultSet rs = cStmtObject.executeQuery();){
	            if(rs != null){
	                while(rs.next()){
	                	additionalVO.setRenewalYNadd(UXUtility.checkNull(rs.getString("RENEWAL_YN")));
	                	additionalVO.setPrevpolno(UXUtility.checkNull(rs.getString("PREV_POLICY_NO")));
	                
	                	//additionalVO.setInpatntflag(UXUtility.checkNull(rs.getString("IP_COV_YN")));
	                	
	                
	                }//end of while(rs.next())
	            }//end of if(rs != null)
	           }
	            return additionalVO;
	        }//end of try
			
		
	
	}
	





}

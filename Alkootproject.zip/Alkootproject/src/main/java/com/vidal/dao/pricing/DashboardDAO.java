package com.vidal.dao.pricing;

import java.util.ArrayList;

import com.vidal.command.pricing.InsPricingVO;

public interface DashboardDAO {
	 public Object[] getSwInsuranceProfileList(ArrayList alSearchObjects) throws Exception;

	 public String getClientName(String clientCode) throws Exception;
	 
	 public String getFetchFlag(String clientCode) throws Exception;
	 
	  public ArrayList<InsPricingVO> groupList(ArrayList al) throws Exception;
	  
	  public ArrayList getGroupPricingDisplayList(Long grouppricingSeqid,String groupSeqId) throws Exception;
	  
	  public Long saveGroupPricingDetails(InsPricingVO insPricingVO) throws Exception;
	  
	  public InsPricingVO generateGroupSeqId(Long groupProfileSeqId,Long UserSeqid,String pricingList) throws Exception;
}

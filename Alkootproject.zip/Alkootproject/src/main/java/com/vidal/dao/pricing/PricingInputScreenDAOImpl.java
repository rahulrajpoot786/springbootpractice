package com.vidal.dao.pricing;

import java.io.ByteArrayInputStream;
import java.io.FileReader;
import java.io.InputStream;
import java.sql.Blob;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;

import javax.sql.DataSource;

import org.apache.commons.io.IOUtils;
import org.dom4j.Document;
import org.dom4j.io.SAXReader;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.web.multipart.MultipartFile;

import com.itextpdf.text.log.SysoCounter;
import com.vidal.command.common.CacheObject;
import com.vidal.command.pricing.InsPricingVO;
import com.vidal.command.pricing.PolicyGroupVO;
import com.vidal.common.UXUtility;

import oracle.jdbc.OracleTypes;

@Repository
public class PricingInputScreenDAOImpl implements PricingInputScreenDAO{

	@Autowired
	private DataSource dataSource;
	
	private static final String strUserName = "select a.group_name from app.tpa_group_registration  a where a.group_reg_seq_id= ?"; 
/*	private static final String strUnderWritting ="SELECT  distinct(extract(year from d.pol_effective_date)) as underwrit_year FROM APP.TPA_PRICING_PREV_POL_DATA D  WHERE UPPER(D.VDL_GROUP_NAME)=?";*/	
	private static final String strUnderWritting ="SELECT DISTINCT(D.UNDERWRITING_YEAR) AS UNDERWRIT_YEAR FROM APP.TPA_PAST_POLICY_PRICING_DATA D WHERE UPPER(D.CLIENT_NAME) = ?  ORDER BY TO_NUMBER(D.UNDERWRITING_YEAR) ASC"; 
	/*private static final String getPolicyNo ="SELECT  D.POLICY_NO,D.VDL_GROUP_NAME FROM APP.TPA_PRICING_PREV_POL_DATA D  WHERE UPPER(D.VDL_GROUP_NAME)= ? and extract(year from d.pol_effective_date)= ?";*/
	private static final String getPolicyNo ="SELECT D.POLICY_NUMBER AS POLICY_NO, D.CLIENT_NAME AS VDL_GROUP_NAME FROM APP.TPA_PAST_POLICY_PRICING_DATA D WHERE UPPER(D.CLIENT_NAME) = ? AND D.UNDERWRITING_YEAR = ?";  
	private static final String getHospitalList ="SELECT DISTINCT B.HOSP_SEQ_ID, B.HOSP_NAME FROM (SELECT MAX(A.HOSP_SEQ_ID) OVER (PARTITION BY HOSP_NAME ORDER BY A.HOSP_NAME ASC ) HOSP_SEQ_ID,A.HOSP_NAME, A.PRIMARY_NETWORK, CASE A.PRIMARY_NETWORK WHEN 'EN' THEN 1 WHEN 'PE' THEN 2 WHEN 'PN' THEN  3 ELSE 4 END SEQ_ID FROM APP.TPA_HOSP_INFO A JOIN APP.TPA_HOSP_EMPANEL_STATUS B ON (A.HOSP_SEQ_ID = B.HOSP_SEQ_ID) WHERE A.EMPANEL_NUMBER IS NOT NULL AND A.HOSP_NAME NOT LIKE '%AL AHLI%' AND B.EMPANEL_STATUS_TYPE_ID = 'EMP' ORDER BY A.HOSP_SEQ_ID) B WHERE SEQ_ID BETWEEN ? AND 3";
	private static final String getAdditionalHospitalList ="SELECT DISTINCT B.HOSP_SEQ_ID, B.HOSP_NAME FROM(SELECT * FROM (SELECT MAX(A.HOSP_SEQ_ID) OVER (PARTITION BY HOSP_NAME ORDER BY A.HOSP_NAME ASC ) HOSP_SEQ_ID,A.HOSP_NAME, A.PRIMARY_NETWORK, CASE A.PRIMARY_NETWORK WHEN 'EN' THEN 1 WHEN 'PE' THEN 2 WHEN 'PN' THEN  3 ELSE 4 END SEQ_ID FROM APP.TPA_HOSP_INFO A JOIN APP.TPA_HOSP_EMPANEL_STATUS B ON (A.HOSP_SEQ_ID = B.HOSP_SEQ_ID) WHERE A.EMPANEL_NUMBER IS NOT NULL AND A.HOSP_NAME NOT LIKE '%AL AHLI%' AND B.EMPANEL_STATUS_TYPE_ID = 'EMP' ORDER BY A.HOSP_SEQ_ID) B WHERE SEQ_ID BETWEEN 1 AND 3) B WHERE SEQ_ID < ?";
	private static final String strPolicyStatusInfo="SELECT DISTINCT D.POLICY_NUMBER POLICY_NO ,(D.COVERAGE_END_DATE+1) AS START_DATE,(ADD_MONTHS((D.COVERAGE_END_DATE+1),12)-1) AS END_DATE, CASE WHEN UPPER(NVL(D.AXA_VIDAL_IND,'AXA'))='AXA' THEN 'Y' ELSE 'N' END AS FLAG, CASE WHEN UPPER(NVL(D.AXA_VIDAL_IND,'AXA'))='AXA' THEN 'FETCH KEY COVERAGES PROVISION IS ONLY AVAILABLE WITH PAST POLICY NUMBERS THAT EXISTS IN THE VIDAL HEALTH SYSTEM.' ELSE NULL END AS ALERT_MSG, INTX.POLICY_COPY_ISSUE_AUTOMATION.GET_PRODUCT_NAME('?') AS POLICY_CATEGORY FROM APP.TPA_PAST_POLICY_PRICING_DATA D WHERE D.POLICY_NUMBER = ?";
	private static final String strPolicyDateInfo="{CALL PRICING_APP_PKG.get_poliy_dates(?,?,?,?)}";
	private static final String strswSavePricingList ="{CALL PRICING_APP_PKG.save_profile_details(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?,?,?,?)}";
	//private static final String strswSelectPricingList="{CALL PRICING_APP_PKG.select_profile_details (?,?)}";
	private static final String strswSelectPricingList="{CALL PRICING_APP_PKG.select_profile_details(?,?)}";
	private static final String strswProfileIncomeListValue="{CALL PRICING_APP_PKG.SELECT_BENF_COVR_DETAILS(?,?,?,?,?,?)}";
	
	private static final String strSwSaveIncomeProfile="{CALL PRICING_APP_PKG.save_benf_covr_details(?,?,?,?,?,?,?,?,?)}";
	
	private static final String strSwSaveIncomeNatProfile="{CALL PRICING_APP_PKG.SAVE_NATLITS_COVR_DETAILS(?,?,?,?,?,?)}";
	
	private static final String strSavememberXml = "{CALL PRICING_APP_PKG.UPLOAD_CENSUS(?,?,?,?,?,?,?,?,?)}";
	
	private static final String strGeneratePricingNo ="{Call PRICING_APP_PKG.generate_pricing_num(?,?,?)}";
	
	private static final String strMasterListValue="{CALL PRICING_APP_PKG.GET_IP_MSTR_DETAILS(?,?,?,?)}";//Master Details
	
	private static final String strFetchDetails="{CALL PRICING_APP_PKG.FETCH_PAST_POLICY_DETAILS(?,?,?)}";
	
	private static final String strDeleteFile="{CALL PRICING_APP_PKG.DELETE_SOURCE_DOCS (?,?,?,?)}";
	
	private static final String strPricingFlag = "SELECT DISTINCT G.BENF_COV_SVE_YN,G.CAL_CPM_SVE_YN,CAL_LODING_SVE_YN,DMGRPHC_SAVE_YN,TRND_FACTOR_PERC,NVL(F.MODIFY_YN,'Y') AS MODIFY_YN,NVL(CENSUS_SAVE_YN,'N') AS CENSUS_SAVE_YN,G.PAST_POLICY_RUN_DATE, to_char(NVL(nvl(G.PAST_POLICY_RUN_DATE,NVL(D.ADDED_DATE,D.UPDATED_DATE)),(select distinct nvl(d.added_date,d.updated_date) from APP.TPA_PAST_POLICY_PRICING_DATA d where rownum=1)),'dd-mm-yyyy') AS ADDED_DATE FROM APP.TPA_GROUP_PROFILE_DETAILS_SPR G LEFT OUTER JOIN APP.TPA_GROUP_FNL_CPM_DETAILS_SPR F ON (G.GRP_PROF_SEQ_ID=F.GRP_PROF_SEQ_ID) LEFT JOIN APP.TPA_PAST_POLICY_PRICING_DATA D ON (D.POLICY_NUMBER=G.PREV_POLICY_NO) LEFT OUTER JOIN APP.TPA_GROPU_BNF_LIVS_DTLS_SPR H ON (G.GRP_PROF_SEQ_ID =H.GRP_PROF_SEQ_ID) WHERE G.GRP_PROF_SEQ_ID =?";

	
	
	private static final String strSaveMaternity="{CALL PRICING_APP_PKG.save_census_mat_ageband (?,?,?)}";
	
	private static final String strBeforeSaveCensus="{CALL PRICING_APP_PKG.generate_pricing_seq (?,?,?)}";
	
	private static final String strDoViewUploadFile ="{CALL PRICING_APP_PKG.FETCH_SOURCE_DOCS (?,?,?,?)}";
	
	private static String strGroupList = "{CALL PRICING_APP_PKG.SELECT_GROUP_LIST(?,?,?,?,?,?,?)}";
	
	private static String oplimitList = "SELECT A.LIMIT_TYPE_SEQ_ID,A.SORT_NO,a.max_limit_desc, MAX_LIMIT FROM APP.TPA_MAX_LIMIT_TYPE_MASTER_SPR A WHERE A.LIMIT_TYPE_SEQ_ID IN (31,32,33,34,35,36,37,38,39,40,41,42,43,44,46,47,53,48,49,58,59,60)  AND TO_NUMBER(A.MAX_LIMIT)<=CASE WHEN TO_NUMBER(REPLACE(?,',')) IS NULL THEN (SELECT MAX(TO_NUMBER(A.MAX_LIMIT)) FROM APP.TPA_MAX_LIMIT_TYPE_MASTER_SPR A WHERE A.LIMIT_TYPE_SEQ_ID IN (31,32,33,34,35,36,37,38,39,40,41,42,43,44,46,47,53,48,49,58,59,60)) ELSE TO_NUMBER(REPLACE(?,',')) END ORDER BY SORT_NO";
	
	@Override
	public Long swSavePricingList(InsPricingVO insPricingVO) throws Exception {
		// TODO Auto-generated method stub
		Long iResult=null;
			
				try(Connection con = dataSource.getConnection();
						CallableStatement cStmtObject = (java.sql.CallableStatement)con.prepareCall(strswSavePricingList);){
					System.out.println("grop doi ....seq id...."+insPricingVO.getGroupProfileSeqID());
				
			if(insPricingVO.getGroupProfileSeqID() != null){
				cStmtObject.setLong(1,insPricingVO.getGroupProfileSeqID());
	           }
               else{
				cStmtObject.setLong(1,0);
	           }//end of else
			cStmtObject.setString(2,insPricingVO.getRenewalYN());
	      /*  cStmtObject.setString(3,insPricingVO.getClientCode());	*/
	        cStmtObject.setString(3,insPricingVO.getGroupRegSeqId());	
            cStmtObject.setString(4,insPricingVO.getPreviousPolicyNo());
            if(insPricingVO.getCoverStartDate() != null){
				/*cStmtObject.setTimestamp(5,new Timestamp(insPricingVO.getCoverStartDate().getTime()));//LETTER_DATE
*/				cStmtObject.setTimestamp(5,new Timestamp(insPricingVO.getCoverStartDate().getTime()));//LETTER_DATE
            }//end of if(batchVO.getLetterDate() != null)
			else{
				cStmtObject.setTimestamp(5, null);//LETTER_DATE
            }//end of else
			if(insPricingVO.getCoverEndDate() != null){
				/*cStmtObject.setTimestamp(6,new Timestamp(insPricingVO.getCoverEndDate().getTime()));//LETTER_DATE
*/				cStmtObject.setTimestamp(6,new Timestamp(insPricingVO.getCoverEndDate().getTime()));//LETTER_DATE
            }//end of if(batchVO.getLetterDate() != null)
			else{
				cStmtObject.setTimestamp(6, null);//LETTER_DATE
            }//end of else
			
			cStmtObject.setString(7,insPricingVO.getTotalCovedLives());
			
		 if(!("").equals(insPricingVO.getTotalLivesMaternity()))
			{
			cStmtObject.setString(8,insPricingVO.getTotalLivesMaternity());
			}else{
			cStmtObject.setString(8,null);
			}
		            
		       
				cStmtObject.setString(9,insPricingVO.getTrendFactor());
		        cStmtObject.setString(10,insPricingVO.getMaternityYN());
			    cStmtObject.setString(11,insPricingVO.getDentalYN());
				cStmtObject.setString(12,insPricingVO.getDentalLivesYN());	
				cStmtObject.setString(13,insPricingVO.getOpticalYN());
				cStmtObject.setString(14,insPricingVO.getOpticalLivesYN());
				cStmtObject.setString(15,insPricingVO.getPhysiocoverage());
				cStmtObject.setString(16,insPricingVO.getVitDcoverage());
				cStmtObject.setString(17,insPricingVO.getVaccImmuCoverage());
				cStmtObject.setString(18,insPricingVO.getMatComplicationCoverage());
				cStmtObject.setString(19,insPricingVO.getPsychiatrycoverage());
				cStmtObject.setString(20,insPricingVO.getDeviatedNasalSeptum());
				cStmtObject.setString(21,insPricingVO.getObesityTreatment());
				cStmtObject.setString(22,insPricingVO.getAreaOfCoverList());
				cStmtObject.setString(23,insPricingVO.getNetworkList());					
				cStmtObject.setString(24,insPricingVO.getMaxBenifitList());
				//cStmtObject.setString(24,"45");
				
			if(!("").equals(insPricingVO.getMaxBeneLimitOth()))
			{
			cStmtObject.setString(25,insPricingVO.getMaxBeneLimitOth());
			}else{
			cStmtObject.setString(25,null);
			}
			
			/*cStmtObject.setString(25,"");*/
			cStmtObject.setString(26,insPricingVO.getDentalLimitList());
		 
		   if(!("").equals(insPricingVO.getDentalLimitOth())){
				cStmtObject.setString(27,insPricingVO.getDentalLimitOth());
			}
			else{
				cStmtObject.setString(27,null);
			}
		  
		   if(insPricingVO.getMaternityLimitList() !=null) {
			  
			   cStmtObject.setLong(28,insPricingVO.getMaternityLimitList());
		   }else {
			 
			   cStmtObject.setString(28,null);
		   }
			
			
			if(!insPricingVO.getMaternityLimitOth().equals("")){
			cStmtObject.setString(29,insPricingVO.getMaternityLimitOth());
			}else{
				cStmtObject.setString(29,null);

			}
			cStmtObject.setString(30,insPricingVO.getOpticalLimitList());
				if(!insPricingVO.getOpticalLimitOth().equals("")){
			cStmtObject.setString(31,insPricingVO.getOpticalLimitOth());
			}else{
				cStmtObject.setString(31,null);

			}
			cStmtObject.setString(32,insPricingVO.getOpCopayList());
			cStmtObject.setString(33,insPricingVO.getOpCopayListDesc());
			cStmtObject.setString(34,insPricingVO.getDentalcopayList());
			cStmtObject.setString(35,insPricingVO.getDentalcopayListDesc());
			
			cStmtObject.setString(36,insPricingVO.getOpticalCopayList());
			cStmtObject.setString(36,insPricingVO.getOpticalCopayList());
			
			cStmtObject.setString(37,insPricingVO.getOpticalCopayListDesc());
			cStmtObject.setString(38,insPricingVO.getOpDeductableList());
		
			cStmtObject.setString(39,insPricingVO.getOpDeductableListDesc());
			cStmtObject.setLong(40,insPricingVO.getAddedBy());
			cStmtObject.setString(41,insPricingVO.getComments());
			//System.out.println("attachement name----"+insPricingVO.getAttachmentname1());
			
			
			/*
				System.out.println("file 0.."+insPricingVO.getFiles()[0].getOriginalFilename());
				System.out.println("file 1.."+insPricingVO.getFiles()[1].getOriginalFilename());
				System.out.println("file 2.."+insPricingVO.getFiles()[2].getOriginalFilename());
				System.out.println("file 3.."+insPricingVO.getFiles()[3].getOriginalFilename());
				System.out.println("file 4.."+insPricingVO.getFiles()[4].getOriginalFilename());*/
		/*	
			int size=insPricingVO.getFiles().length;
			System.out.println("size..."+size);*/
			
			
			
			
			
			if(insPricingVO.getSrcDoc1Yn().equals("N") || insPricingVO.getSrcDoc1Yn().equals("")) {															
				cStmtObject.setString(42,insPricingVO.getFile1().getOriginalFilename());
				byte[] iStream1	= insPricingVO.getFile1().getBytes();
				cStmtObject.setBytes(43, iStream1);	
				
			}else {
				cStmtObject.setString(42,insPricingVO.getAttachmentname1());
				InputStream ins1=insPricingVO.getInputstreamdoc1();	
				if(ins1 !=null) {
				byte[] targetArray = IOUtils.toByteArray(ins1);
				cStmtObject.setBytes(43,targetArray);
				}else {
					cStmtObject.setBytes(43,null);
				}
			}
			
			
			if(insPricingVO.getSrcDoc2Yn().equals("N") || insPricingVO.getSrcDoc2Yn().equals("")) {															
				cStmtObject.setString(44,insPricingVO.getFile2().getOriginalFilename());
				byte[] iStream2	=	insPricingVO.getFile2().getBytes();
				cStmtObject.setBytes(45, iStream2);
			}else {
				cStmtObject.setString(44,insPricingVO.getAttachmentname2());
				InputStream ins2=insPricingVO.getInputstreamdoc2();	
			   if(ins2 !=null) {
				byte[] targetArray = IOUtils.toByteArray(ins2);
				cStmtObject.setBytes(45,targetArray);
			   }else {
					cStmtObject.setBytes(45,null);
			   }
			   
			}
			
			
			if(insPricingVO.getSrcDoc3Yn().equals("N") || insPricingVO.getSrcDoc3Yn().equals("")) {
				
				cStmtObject.setString(46,insPricingVO.getFile3().getOriginalFilename());
				byte[] iStream3	= insPricingVO.getFile3().getBytes();
				cStmtObject.setBytes(47, iStream3);
			}else {
				
				cStmtObject.setString(46,insPricingVO.getAttachmentname3());
				InputStream ins3=insPricingVO.getInputstreamdoc3();						
				if(ins3 !=null) {
				byte[] targetArray = IOUtils.toByteArray(ins3);
				cStmtObject.setBytes(47,targetArray);
				}else {
					cStmtObject.setBytes(47,null);
				}
			}
			
			if(insPricingVO.getSrcDoc4Yn().equals("N") || insPricingVO.getSrcDoc4Yn().equals("")) {
				cStmtObject.setString(48,insPricingVO.getFile4().getOriginalFilename());
				byte[] iStream4	=	insPricingVO.getFile4().getBytes();
				cStmtObject.setBytes(49, iStream4);
			}else {
				cStmtObject.setString(48,insPricingVO.getAttachmentname4());
				InputStream ins4=insPricingVO.getInputstreamdoc4();	
				
				if(ins4 !=null) {
				byte[] targetArray = IOUtils.toByteArray(ins4);
				cStmtObject.setBytes(49,targetArray);
				}else {
					cStmtObject.setBytes(49,null);
				}
			}
			
			
			if(insPricingVO.getSrcDoc5Yn().equals("N") || insPricingVO.getSrcDoc5Yn().equals("")) {
				cStmtObject.setString(50,insPricingVO.getFile5().getOriginalFilename());
				byte[] iStream5	=	insPricingVO.getFile5().getBytes();
				cStmtObject.setBytes(51, iStream5);
			}else {
				cStmtObject.setString(50,insPricingVO.getAttachmentname5());
				InputStream ins5=insPricingVO.getInputstreamdoc5();	
				
				if(ins5 !=null) {
				byte[] targetArray = IOUtils.toByteArray(ins5);
				cStmtObject.setBytes(51,targetArray);
				}else {
					cStmtObject.setBytes(51,null);
				}
			}
			
		/*	if(insPricingVO.getFiles() !=null) {
			
			for(int i=0;i<size;i++) {
				System.out.println("iii..."+i);
				
				if(i == 0) {
					
					if(i == 0 && insPricingVO.getSrcDoc1Yn().equals("N")) {															
						cStmtObject.setString(42,insPricingVO.getFiles()[i].getOriginalFilename());
						byte[] iStream1	= insPricingVO.getFiles()[i].getBytes();
						cStmtObject.setBytes(43, iStream1);	
						
					}else {
						cStmtObject.setString(42,insPricingVO.getAttachmentname1());
						InputStream ins1=insPricingVO.getInputstreamdoc1();	
						if(ins1 !=null) {
						byte[] targetArray = IOUtils.toByteArray(ins1);
						cStmtObject.setBytes(43,targetArray);
						}else {
							cStmtObject.setBytes(43,null);
						}
					}
					}
				
					if(i == 1) {
						
					if(i == 1 && insPricingVO.getSrcDoc2Yn().equals("N")) {															
						cStmtObject.setString(44,insPricingVO.getFiles()[i].getOriginalFilename());
						byte[] iStream2	=	insPricingVO.getFiles()[i].getBytes();
						cStmtObject.setBytes(45, iStream2);
					}else {
						cStmtObject.setString(44,insPricingVO.getAttachmentname2());
						InputStream ins2=insPricingVO.getInputstreamdoc2();	
					   if(ins2 !=null) {
						byte[] targetArray = IOUtils.toByteArray(ins2);
						cStmtObject.setBytes(45,targetArray);
					   }else {
							cStmtObject.setBytes(45,null);
					   }
					   
					}
					}
					
					if(i == 2) {
					
					if(i == 2 && insPricingVO.getSrcDoc3Yn().equals("N")) {
						cStmtObject.setString(46,insPricingVO.getFiles()[i].getOriginalFilename());
						byte[] iStream3	=	insPricingVO.getFiles()[i].getBytes();
						cStmtObject.setBytes(47, iStream3);
					}else {
						cStmtObject.setString(46,insPricingVO.getAttachmentname3());
						InputStream ins3=insPricingVO.getInputstreamdoc3();						
						if(ins3 !=null) {
						byte[] targetArray = IOUtils.toByteArray(ins3);
						cStmtObject.setBytes(47,targetArray);
						}else {
							cStmtObject.setBytes(47,null);
						}
					}
					}
					
					if(i == 3) {
					if(i == 3 && insPricingVO.getSrcDoc4Yn().equals("N")) {
						cStmtObject.setString(48,insPricingVO.getFiles()[i].getOriginalFilename());
						byte[] iStream4	=	insPricingVO.getFiles()[i].getBytes();
						cStmtObject.setBytes(49, iStream4);
					}else {
						cStmtObject.setString(48,insPricingVO.getAttachmentname4());
						InputStream ins4=insPricingVO.getInputstreamdoc4();	
						
						if(ins4 !=null) {
						byte[] targetArray = IOUtils.toByteArray(ins4);
						cStmtObject.setBytes(49,targetArray);
						}else {
							cStmtObject.setBytes(49,null);
						}
					}
					}
					
					if(i == 4) {
					if(i == 4 && insPricingVO.getSrcDoc5Yn().equals("N")) {
						cStmtObject.setString(50,insPricingVO.getFiles()[i].getOriginalFilename());
						byte[] iStream5	=	insPricingVO.getFiles()[i].getBytes();
						cStmtObject.setBytes(51, iStream5);
					}else {
						cStmtObject.setString(50,insPricingVO.getAttachmentname5());
						InputStream ins5=insPricingVO.getInputstreamdoc5();	
						
						if(ins5 !=null) {
						byte[] targetArray = IOUtils.toByteArray(ins5);
						cStmtObject.setBytes(51,targetArray);
						}else {
							cStmtObject.setBytes(51,null);
						}
					}
					}
				
				
				if(i == 0) {
					
				if(i == 0 && insPricingVO.getSrcDoc1Yn().equals("N")) {															
					cStmtObject.setString(42,insPricingVO.getFiles()[i].getOriginalFilename());
					byte[] iStream1	= insPricingVO.getFiles()[i].getBytes();
					cStmtObject.setBytes(43, iStream1);	
					
				}else {
					cStmtObject.setString(42,insPricingVO.getAttachmentname1());
					InputStream ins1=insPricingVO.getInputstreamdoc1();	
					if(ins1 !=null) {
					byte[] targetArray = IOUtils.toByteArray(ins1);
					cStmtObject.setBytes(43,targetArray);
					}else {
						cStmtObject.setBytes(43,null);
					}
				}
				}
			
				if(i == 1) {
					
				if(i == 1 && insPricingVO.getSrcDoc2Yn().equals("N")) {															
					cStmtObject.setString(44,insPricingVO.getFiles().get(i).getOriginalFilename());
					byte[] iStream2	=	insPricingVO.getFiles().get(i).getBytes();
					cStmtObject.setBytes(45, iStream2);
				}else {
					cStmtObject.setString(44,insPricingVO.getAttachmentname2());
					InputStream ins2=insPricingVO.getInputstreamdoc2();	
				   if(ins2 !=null) {
					byte[] targetArray = IOUtils.toByteArray(ins2);
					cStmtObject.setBytes(45,targetArray);
				   }else {
						cStmtObject.setBytes(45,null);
				   }
				   
				}
				}
				
				if(i == 2) {
				
				if(i == 2 && insPricingVO.getSrcDoc3Yn().equals("N")) {
					cStmtObject.setString(46,insPricingVO.getFiles().get(i).getOriginalFilename());
					byte[] iStream3	=	insPricingVO.getFiles().get(i).getBytes();
					cStmtObject.setBytes(47, iStream3);
				}else {
					cStmtObject.setString(46,insPricingVO.getAttachmentname3());
					InputStream ins3=insPricingVO.getInputstreamdoc3();						
					if(ins3 !=null) {
					byte[] targetArray = IOUtils.toByteArray(ins3);
					cStmtObject.setBytes(47,targetArray);
					}else {
						cStmtObject.setBytes(47,null);
					}
				}
				}
				
				if(i == 3) {
				if(i == 3 && insPricingVO.getSrcDoc4Yn().equals("N")) {
					cStmtObject.setString(48,insPricingVO.getFiles().get(i).getOriginalFilename());
					byte[] iStream4	=	insPricingVO.getFiles().get(i).getBytes();
					cStmtObject.setBytes(49, iStream4);
				}else {
					cStmtObject.setString(48,insPricingVO.getAttachmentname4());
					InputStream ins4=insPricingVO.getInputstreamdoc4();	
					
					if(ins4 !=null) {
					byte[] targetArray = IOUtils.toByteArray(ins4);
					cStmtObject.setBytes(49,targetArray);
					}else {
						cStmtObject.setBytes(49,null);
					}
				}
				}
				
				if(i == 4) {
				if(i == 4 && insPricingVO.getSrcDoc5Yn().equals("N")) {
					cStmtObject.setString(50,insPricingVO.getFiles().get(i).getOriginalFilename());
					byte[] iStream5	=	insPricingVO.getFiles().get(i).getBytes();
					cStmtObject.setBytes(51, iStream5);
				}else {
					cStmtObject.setString(50,insPricingVO.getAttachmentname5());
					InputStream ins5=insPricingVO.getInputstreamdoc5();	
					
					if(ins5 !=null) {
					byte[] targetArray = IOUtils.toByteArray(ins5);
					cStmtObject.setBytes(51,targetArray);
					}else {
						cStmtObject.setBytes(51,null);
					}
				}
				}
				
			}
				 for(int j=size;j<5;j++) {
					 
						System.out.println("jjj..."+j);
					   if(j==0) {
							cStmtObject.setString(42,insPricingVO.getAttachmentname1());
							InputStream ins1=insPricingVO.getInputstreamdoc1();	
							if(ins1 !=null) {
							byte[] targetArray = IOUtils.toByteArray(ins1);
							cStmtObject.setBytes(43,targetArray);
							}else {
								cStmtObject.setBytes(43,null);	
							}						  				  		   									
					   }
				
					   if(j==1) {						   						 
					cStmtObject.setString(44,insPricingVO.getAttachmentname2());
					InputStream ins2=insPricingVO.getInputstreamdoc2();					
					
					if(ins2 !=null) {
					byte[] targetArray = IOUtils.toByteArray(ins2);
					cStmtObject.setBytes(45,targetArray);
					}else {
						cStmtObject.setBytes(45,null);
					}
					
					
					   } if(j==2) {
					
					cStmtObject.setString(46,insPricingVO.getAttachmentname3());
					InputStream ins3=insPricingVO.getInputstreamdoc3();	
					if(ins3 !=null) {
						byte[] targetArray = IOUtils.toByteArray(ins3);
						cStmtObject.setBytes(47,targetArray);
						}else {
							cStmtObject.setBytes(47,null);
						}
					
					
					   }
					   if(j==3) {
				
					cStmtObject.setString(48,insPricingVO.getAttachmentname4());
					InputStream ins4=insPricingVO.getInputstreamdoc4();	
				
					if(ins4 !=null) {
						byte[] targetArray = IOUtils.toByteArray(ins4);
						cStmtObject.setBytes(49,targetArray);
						}else {
							cStmtObject.setBytes(49,null);
						}
					   }
					   if(j==4) {
						   
						   cStmtObject.setString(50,insPricingVO.getAttachmentname5());
						   InputStream ins5=insPricingVO.getInputstreamdoc5();	
						   if(ins5 !=null) {
								byte[] targetArray = IOUtils.toByteArray(ins5);
								cStmtObject.setBytes(51,targetArray);
								}else {
									cStmtObject.setBytes(51,null);
								}

					   }
				   }

			}*//*else {
				
				   for(int j=size;j<5;j++) {
					   if(j==0) {
					cStmtObject.setString(42,"");
				
					cStmtObject.setBytes(43,null);	
					   }
				
					   if(j==1) {
					cStmtObject.setString(44,"");
				
					cStmtObject.setBytes(45,null);
					   } if(j==2) {
			
					cStmtObject.setString(46,"");
				
					cStmtObject.setBytes(47,null);
					   }
					   if(j==3) {
				
					cStmtObject.setString(48,"");
				
					cStmtObject.setBytes(49,null);
				
					   }
					   if(j==4) {
					cStmtObject.setString(50,"");
				
					cStmtObject.setBytes(51,null);
					   }
				   }
				
			}*/
			
				
		/*	if(insPricingVO.getFiles()[0] !=null) {
				
				cStmtObject.setString(42,insPricingVO.getFiles()[0].getOriginalFilename());
				byte[] iStream1	= insPricingVO.getFiles()[0].getBytes();
				cStmtObject.setBytes(43, iStream1);	
			}else {
				cStmtObject.setString(42,"");
				
				cStmtObject.setBytes(43,null);	
			}
																				   
			if(insPricingVO.getFiles()[1] !=null) {
			cStmtObject.setString(44,insPricingVO.getFiles()[1].getOriginalFilename());
			byte[] iStream2	=	insPricingVO.getFiles()[1].getBytes();
			cStmtObject.setBytes(45, iStream2);
			}else {
				cStmtObject.setString(44,"");			
				cStmtObject.setBytes(45,null);
			}
			if(insPricingVO.getFiles()[2] !=null) {
			cStmtObject.setString(46,insPricingVO.getFiles()[2].getOriginalFilename());
			byte[] iStream3	=	insPricingVO.getFiles()[2].getBytes();
			cStmtObject.setBytes(47, iStream3);
			}else {
				cStmtObject.setString(46,"");
				
				cStmtObject.setBytes(47,null);	
			}
			
			cStmtObject.setString(48,insPricingVO.getFiles()[3].getOriginalFilename());
			byte[] iStream4	=	insPricingVO.getFiles()[3].getBytes();
			cStmtObject.setBytes(49, iStream4);
			
			cStmtObject.setString(50,insPricingVO.getFiles()[4].getOriginalFilename());
			byte[] iStream5	=	insPricingVO.getFiles()[4].getBytes();
			cStmtObject.setBytes(51, iStream5);*/
		
			
			
			
				//2nd phase
			cStmtObject.setString(52,insPricingVO.getInpatientBenefit());
			cStmtObject.setString(53,insPricingVO.getOutpatientBenefit());
			cStmtObject.setString(54,insPricingVO.getGastricBinding());
			//cStmtObject.setString(55,insPricingVO.getHealthScreen());
			cStmtObject.setString(55,"");
			cStmtObject.setString(56,insPricingVO.getOrthodonticsCopay());
			cStmtObject.setString(57,insPricingVO.getOrthodonticsCopayDesc());
			cStmtObject.setString(58,insPricingVO.getOpdeductableserviceYN());
			cStmtObject.setString(59,insPricingVO.getOpCopaypharmacy());
			cStmtObject.setString(60,insPricingVO.getOpCopaypharmacyDesc());
			cStmtObject.setString(61,insPricingVO.getOpCopyconsultn());
			cStmtObject.setString(62,insPricingVO.getOpCopyconsultnDesc());
			cStmtObject.setString(63,insPricingVO.getOpInvestigation());
			cStmtObject.setString(64,insPricingVO.getOpInvestigationDesc());
			cStmtObject.setString(65,insPricingVO.getOpCopyothers());
			cStmtObject.setString(66,insPricingVO.getOpCopyothersDesc());					
			cStmtObject.setString(67,insPricingVO.getAlAhlihospital());
			cStmtObject.setString(68,insPricingVO.getAlAhlihospOPservices());
			cStmtObject.setString(69,insPricingVO.getOpCopyalahlihosp());
			cStmtObject.setString(70,insPricingVO.getOpCopyalahlihospDesc());
			cStmtObject.setString(71,insPricingVO.getOpPharmacyAlAhli());
			cStmtObject.setString(72,insPricingVO.getOpPharmacyAlAhliDesc());
			cStmtObject.setString(73,insPricingVO.getOpConsultAlAhli());
			cStmtObject.setString(74,insPricingVO.getOpConsultAlAhliDesc());				
			cStmtObject.setString(75,insPricingVO.getOpInvestnAlAhli());
			cStmtObject.setString(76,insPricingVO.getOpInvestnAlAhliDesc());
			cStmtObject.setString(77,insPricingVO.getOpothersAlAhli());
			cStmtObject.setString(78,insPricingVO.getOpothersAlAhliDesc());
			cStmtObject.setString(79,insPricingVO.getOpticalFrameLimitList());
			cStmtObject.setString(80,insPricingVO.getBrokerCode());
			cStmtObject.setString(81,insPricingVO.getBrokername());
			
			cStmtObject.setString(82,insPricingVO.getMaxBenifitList());
			
			cStmtObject.setString(83,insPricingVO.getMaxBeneLimitOth());
			
			
			cStmtObject.setString(84,insPricingVO.getMaxBenifitListop());
			cStmtObject.setString(85,insPricingVO.getMaxBeneLimitOthOp());
			
			cStmtObject.setString(86,insPricingVO.getAreaOfCoverVariations());
			
			if (insPricingVO.getIpCopay() != null) {
				cStmtObject.setLong(87, insPricingVO.getIpCopay());
			} else {
				cStmtObject.setString(87,null);
			} // end of else

			cStmtObject.setString(88, insPricingVO.getIpCopayDesc());
			cStmtObject.setString(89, insPricingVO.getOpdeductableserviceYN());
			
			if (insPricingVO.getMaternityLimitList() != null) {
				cStmtObject.setLong(90, insPricingVO.getMaternityCopayList());
			} else {
				cStmtObject.setLong(90, 0);
			} // end of else

			cStmtObject.setString(91, insPricingVO.getMaternityLimitListDesc());

			if (insPricingVO.getiPCopayAtAhliList() != null) {
				cStmtObject.setLong(92, insPricingVO.getiPCopayAtAhliList());
			} else {
				cStmtObject.setString(92,null);
			} // end of else
											
			cStmtObject.setString(93,insPricingVO.getiPCopayAtAhliListDesc());
			cStmtObject.setString(94,insPricingVO.getAdditionalHospitalCoverageList());
			cStmtObject.setString(95,"");
			cStmtObject.setString(96,insPricingVO.getLoadinghospitalComment());
			cStmtObject.setString(97,insPricingVO.getHospitalExclusionsList());
			cStmtObject.setString(98,"");
			cStmtObject.setString(99,insPricingVO.getDiscounthospitalComment());
			cStmtObject.setString(100,insPricingVO.getResidencyCountryList());
			cStmtObject.setString(101,insPricingVO.getProRATALimitApplicable());
			
			cStmtObject.setString(102,insPricingVO.getMaternityPricingList());
			
			if (insPricingVO.getPremiumOutputStructureList() != null) {
				cStmtObject.setLong(103, insPricingVO.getPremiumOutputStructureList());
			} else {
				cStmtObject.setLong(103, 0);
			} // end of else
		
			
			cStmtObject.setString(104,insPricingVO.getPremiumRefundApproach());
			
			cStmtObject.setString(105,insPricingVO.getLoadingAreaListip());
			cStmtObject.setString(106,insPricingVO.getLoadingAreaListop());
			cStmtObject.setString(107,insPricingVO.getLoadingAreaListopt());
			cStmtObject.setString(108,insPricingVO.getLoadingAreaListdent());
			cStmtObject.setString(109,insPricingVO.getLoadingAreaListmat());
			
			cStmtObject.setString(110,insPricingVO.getDiscountAreaListip());
			cStmtObject.setString(111,insPricingVO.getDiscountAreaListop());
			cStmtObject.setString(112,insPricingVO.getDiscountAreaListopt());
			cStmtObject.setString(113,insPricingVO.getDiscountAreaListdent());
			cStmtObject.setString(114,insPricingVO.getDiscountAreaListmat());
			
			cStmtObject.setString(115,insPricingVO.getNetworkListip());
			cStmtObject.setString(116,insPricingVO.getNetworkListop());
			cStmtObject.setString(117,insPricingVO.getNetworkListopt());
			cStmtObject.setString(118,insPricingVO.getNetworkListdent());
			cStmtObject.setString(119,insPricingVO.getNetworkListmat());
			
			cStmtObject.setString(120,insPricingVO.getResidencyCountryIp());
			cStmtObject.setString(121,insPricingVO.getResidencyCountryOp());
			cStmtObject.setString(122,insPricingVO.getResidencyCountryOtp());
			cStmtObject.setString(123,insPricingVO.getResidencyCountryDent());
			cStmtObject.setString(124,insPricingVO.getResidencyCountryMat());
			cStmtObject.setString(125,insPricingVO.getTrendFactorIp());
			cStmtObject.setString(126,insPricingVO.getTrendFactorOp());
			cStmtObject.setString(127,insPricingVO.getTrendFactorOpt());
			cStmtObject.setString(128,insPricingVO.getTrendFactorDent());
			cStmtObject.setString(129,insPricingVO.getTrendFactorMat());
			if(insPricingVO.getLoadinghospitalCoverage() !=null) {
				cStmtObject.setLong(130,insPricingVO.getLoadinghospitalCoverage());
			}else {
				cStmtObject.setLong(130,0);
			}
											
			if(insPricingVO.getDiscounthospitalExclusions() !=null) {
				cStmtObject.setLong(131,insPricingVO.getDiscounthospitalExclusions());
			
			}else {
				cStmtObject.setLong(131,0);
			}
			
			
			
			cStmtObject.setString(132,insPricingVO.getUnderWritingYear());
			cStmtObject.setString(133,insPricingVO.getProductCategory());
			cStmtObject.registerOutParameter(134,Types.INTEGER);
			cStmtObject.registerOutParameter(1,Types.INTEGER);
			cStmtObject.execute();	
			iResult = cStmtObject.getLong(1);	
						
				}					
				
			
	
		return iResult;
	}

	@Override
	public String getClientName(String clientCode) throws Exception {
		// TODO Auto-generated method stub
	
		
		String result="";
		try(Connection con = dataSource.getConnection();
				PreparedStatement pStmtObject = con.prepareStatement(strUserName);){
			
			pStmtObject.setString(1,clientCode);
			
			try(ResultSet rs = pStmtObject.executeQuery();){
				if(rs != null){
					while(rs.next())
					{
						
						result=	UXUtility.checkNull(rs.getString("group_name"));
					}//end of while(rs.next())
				}
			}
			
		}
				
							       					
		return result;
	}

	@Override
	public ArrayList getUnderWrittingYear(String groupName) throws Exception {
		// TODO Auto-generated method stub
		CacheObject cacheObject = null;
		ArrayList<CacheObject> alUnderWrittingYear = new ArrayList<>();
		try(Connection con = dataSource.getConnection();
				PreparedStatement pStmtObject = con.prepareStatement(strUnderWritting);){
		
			pStmtObject.setString(1,groupName);
			
			try(ResultSet rs = pStmtObject.executeQuery();){
				if(rs != null){
					while(rs.next())
					{
						cacheObject = new CacheObject();
						
						cacheObject.setCacheId(UXUtility.checkNull(rs.getString("underwrit_year")));
						cacheObject.setCacheDesc(UXUtility.checkNull(rs.getString("underwrit_year")));
						alUnderWrittingYear.add(cacheObject);
					}//end of while(rs.next())
				}
			}
			
		}	
		
		return alUnderWrittingYear;
		
	}

	@Override
	public ArrayList getPolicyNo(String groupName, String underWrittingYear) throws Exception {
		// TODO Auto-generated method stub
		CacheObject cacheObject = null;
		ArrayList<CacheObject> alPolicyNo = new ArrayList<>();
		try(Connection con = dataSource.getConnection();
				PreparedStatement pStmtObject = con.prepareStatement(getPolicyNo);){
			pStmtObject.setString(1,groupName);
			pStmtObject.setString(2,underWrittingYear);
			
			try(ResultSet rs = pStmtObject.executeQuery();){
				if(rs != null){
					while(rs.next())
					{
						cacheObject = new CacheObject();
						
						cacheObject.setCacheId(UXUtility.checkNull(rs.getString("POLICY_NO")));
						cacheObject.setCacheDesc(UXUtility.checkNull(rs.getString("POLICY_NO")));
						alPolicyNo.add(cacheObject);
					}//end of while(rs.next())
				}
			}
			
		}	
		
		return alPolicyNo;
	}

	@Override
	public ArrayList getHospitalList(String networkCode) throws Exception {
		CacheObject cacheObject = null;
		ArrayList<CacheObject> alHospitalList = new ArrayList<>();
		try(Connection con = dataSource.getConnection();
				PreparedStatement pStmtObject = con.prepareStatement(getHospitalList);){	
			pStmtObject.setString(1,networkCode);					
			try(ResultSet rs = pStmtObject.executeQuery();){
				if(rs != null){
					while(rs.next())
					{
						cacheObject = new CacheObject();						
						cacheObject.setCacheId(UXUtility.checkNull(rs.getString("HOSP_SEQ_ID")));
						cacheObject.setCacheDesc(UXUtility.checkNull(rs.getString("HOSP_NAME")));
						alHospitalList.add(cacheObject);
					}//end of while(rs.next())
				}
			}
			
		}	
		
		return alHospitalList;
	}

	@Override
	public InsPricingVO getPolicyStatusInfo(ArrayList dataList) throws Exception {
		// TODO Auto-generated method stub
		InsPricingVO insPricingVO=new InsPricingVO();
		try(Connection conn = dataSource.getConnection();
			    PreparedStatement pStmt = conn.prepareStatement(strPolicyStatusInfo);
				CallableStatement cStmtObject = conn.prepareCall(strPolicyDateInfo)){
		
			if(dataList.get(0)!=null)
				pStmt.setString(1, (String) dataList.get(0));
				else
					pStmt.setString(1, null);
				if(dataList.get(0)!=null)
				cStmtObject.setString(1, (String) dataList.get(0));
				else
					pStmt.setString(1, null);
				if(dataList.get(1)!=null)
				cStmtObject.setString(2, (String) dataList.get(1));
				else
					pStmt.setString(2, null);
				if(dataList.get(2)!=null)
				cStmtObject.setString(3, (String) dataList.get(2));
				else
					pStmt.setString(3, null);
				cStmtObject.registerOutParameter(4,OracleTypes.CURSOR);
				cStmtObject.execute();
			    try(ResultSet rs = pStmt.executeQuery()){
			    	if(rs != null){
		                while(rs.next()){
		                	insPricingVO.setPolicyNumberFlag(UXUtility.checkNull(rs.getString("FLAG")));	
//		                	insPricingVO.setPolicycategory(TTKCommon.checkNull(rs.getString("POLICY_CATEGORY")));	
		                }}	
			    }
			    try(ResultSet rs1 = (java.sql.ResultSet)cStmtObject.getObject(4)){
			    	if(rs1 != null){
		                while(rs1.next()){
		                	
		                	insPricingVO.setCoverStartDate(rs1.getString("START_DATE")!=null ? new Date(rs1.getTimestamp("START_DATE").getTime()):null);
							insPricingVO.setCoverEndDate(rs1.getString("END_DATE")!=null ? new Date(rs1.getTimestamp("END_DATE").getTime()):null);
							insPricingVO.setPolicycategory(UXUtility.checkNull(rs1.getString("POLCIY_CATEGORY")));
							insPricingVO.setAlertmsgscreen1(UXUtility.checkNull(rs1.getString("POL_CNT_MSG")));
							System.out.println("V_TOTAL_LIVES..."+rs1.getDouble("V_TOTAL_LIVES"));
							insPricingVO.setNumberOfLives(rs1.getDouble("V_TOTAL_LIVES"));
		            }}	
			    }
			
		}
		return insPricingVO;
	}

	@Override
	public InsPricingVO swSelectPricingList(Long lpricingSeqId) throws Exception {
		// TODO Auto-generated method stub
		InsPricingVO  insPricingVO =new InsPricingVO();
	
		Blob blob1	=	null;
		InputStream iStream1	=	new ByteArrayInputStream(new String("").getBytes());
		Blob blob2	=	null;
		InputStream iStream2	=	new ByteArrayInputStream(new String("").getBytes());
		
		Blob blob3	=	null;
		InputStream iStream3	=	new ByteArrayInputStream(new String("").getBytes());
		
		Blob blob4	=	null;
		InputStream iStream4	=	new ByteArrayInputStream(new String("").getBytes());
		
		Blob blob5	=	null;
		InputStream iStream5	=	new ByteArrayInputStream(new String("").getBytes());
		
		try(Connection con = dataSource.getConnection();
				CallableStatement cStmtObject = (java.sql.CallableStatement)con.prepareCall(strswSelectPricingList);){
		
			cStmtObject.setLong(1,lpricingSeqId);
			cStmtObject.registerOutParameter(2,OracleTypes.CURSOR);
			cStmtObject.execute(); 
			try(ResultSet rs = (java.sql.ResultSet)cStmtObject.getObject(2);){
				if(rs != null){
					while(rs.next())
					{
						
						insPricingVO.setGroupProfileSeqID(lpricingSeqId);
						insPricingVO.setRenewalYN(UXUtility.checkNull(rs.getString("RENEWAL_YN")));	
						System.out.println("pricing no..."+rs.getString("REF_NO"));
						insPricingVO.setPricingRefno(UXUtility.checkNull(rs.getString("REF_NO")));	
						insPricingVO.setClientCode(UXUtility.checkNull(rs.getString("group_reg_seq_id")));
						insPricingVO.setGroupRegSeqId(UXUtility.checkNull(rs.getString("CLIENT_CODE")));
						System.out.println("client name.."+rs.getString("GROUP_NAME"));
						insPricingVO.setClientName(UXUtility.checkNull(rs.getString("GROUP_NAME")));
						insPricingVO.setPreviousPolicyNo(UXUtility.checkNull(rs.getString("PREV_POLICY_NO")));
						System.out.println("coverd...."+(rs.getString("tot_cov_lives")));
						insPricingVO.setNoCoverdLives(UXUtility.checkNull(rs.getString("tot_cov_lives")));
																													
						
						insPricingVO.setCoverStartDate(rs.getString("COVRG_START_DATE")!=null ? new Date(rs.getTimestamp("COVRG_START_DATE").getTime()):null);
						insPricingVO.setCoverEndDate(rs.getString("COVRG_END_DATE")!=null ? new Date(rs.getTimestamp("COVRG_END_DATE").getTime()):null);

						//insPricingVO.setCoverStartDate(new Date(rs.getTimestamp("COVRG_START_DATE").getTime()));
						//insPricingVO.setCoverEndDate(new Date(rs.getTimestamp("COVRG_END_DATE").getTime()));
						
						insPricingVO.setTotalCovedLives(UXUtility.checkNull(rs.getString("TOT_COV_LIVES")));
												
						insPricingVO.setTotalLivesMaternity(UXUtility.checkNull(rs.getString("TOT_COV_LIVES_MATRNTY")));	
						
					

						insPricingVO.setTrendFactor(UXUtility.checkNull(rs.getString("TRND_FACTOR_PERC")));
						insPricingVO.setMaternityYN(UXUtility.checkNull(rs.getString("MAT_COV_YN")));						
						insPricingVO.setDentalYN(UXUtility.checkNull(rs.getString("DNTL_COV_YN")));
						insPricingVO.setDentalLivesYN(UXUtility.checkNull(rs.getString("DNTL_COV_ALL_LIVES_YN")));
					
						insPricingVO.setOpticalYN(UXUtility.checkNull(rs.getString("OPTCL_COV_YN")));				
						insPricingVO.setOpticalLivesYN(UXUtility.checkNull(rs.getString("OPTCL_COV_ALL_LIVES_YN")));
						insPricingVO.setPhysiocoverage(UXUtility.checkNull(rs.getString("PSYTHRPY_COV_YN")));
						insPricingVO.setVitDcoverage(UXUtility.checkNull(rs.getString("VITAMIN_D_COV_YN")));
						
						insPricingVO.setVaccImmuCoverage(UXUtility.checkNull(rs.getString("VACC_IMMUN_COV_YN")));
						insPricingVO.setMatComplicationCoverage(UXUtility.checkNull(rs.getString("MAT_COMPLCTION_COV_YN")));
						insPricingVO.setPsychiatrycoverage(UXUtility.checkNull(rs.getString("PSYCHRTRY_COV_YN")));				
						insPricingVO.setDeviatedNasalSeptum(UXUtility.checkNull(rs.getString("DEVTD_NASL_SEPTM_COV_YN")));
						insPricingVO.setObesityTreatment(UXUtility.checkNull(rs.getString("OBSTY_TRTMNT_COV_YN")));
						insPricingVO.setAreaOfCoverList(UXUtility.checkNull(rs.getString("AREA_TYPE_SEQ_ID")));
						
						insPricingVO.setNetworkList(UXUtility.checkNull(rs.getString("NWK_TYPE_SEQ_ID")));
						insPricingVO.setMaxBenifitList(UXUtility.checkNull(rs.getString("MAX_BENF_LIMIT_SEQ_ID")));
						insPricingVO.setMaxBeneLimitOth(UXUtility.checkNull(rs.getString("MAX_BENF_OTH_LIMIT")));				
						insPricingVO.setDentalLimitList(UXUtility.checkNull(rs.getString("DENTL_LIMIT_SEQ_ID")));
						
						insPricingVO.setDentalLimitOth(UXUtility.checkNull(rs.getString("DENTL_OTH_LIMIT")));
					/*	insPricingVO.setMaternityLimitList(UXUtility.checkNull(rs.getString("MAT_LIMIT_SEQ_ID")));*/
						
						insPricingVO.setMaternityLimitList(rs.getLong("MAT_LIMIT_SEQ_ID"));
						
						insPricingVO.setMaternityLimitOth(UXUtility.checkNull(rs.getString("MAT_OTH_LIMIT")));
					
						insPricingVO.setOpticalLimitList(UXUtility.checkNull(rs.getString("OPTCL_LIMIT_SEQ_ID")));
						insPricingVO.setOpticalLimitOth(UXUtility.checkNull(rs.getString("OPTCL_OTH_LIMIT")));				
				
						insPricingVO.setOpCopayList(UXUtility.checkNull(rs.getString("OPT_COPAY_TYPE_SEQ_ID")));
						insPricingVO.setOpCopayListDesc(UXUtility.checkNull(rs.getString("OPT_COPAY_PERC")));
						insPricingVO.setDentalcopayList(UXUtility.checkNull(rs.getString("DNT_COPAY_TYPE_SEQ_ID")));
						insPricingVO.setDentalcopayListDesc(UXUtility.checkNull(rs.getString("DNT_COPAY_PERC")));				
						insPricingVO.setOpticalCopayList(UXUtility.checkNull(rs.getString("OPTCL_COPAY_TYPE_SEQ_ID")));
						insPricingVO.setOpticalCopayListDesc(UXUtility.checkNull(rs.getString("OPTCL_COPAY_PERC")));
						insPricingVO.setOpDeductableList(UXUtility.checkNull(rs.getString("OPT_DEDUCT_TYPE_SEQ_ID")));
						insPricingVO.setOpDeductableListDesc(UXUtility.checkNull(rs.getString("OPT_DEDUCTBLE")));
						insPricingVO.setComments(rs.getString("COVRG_REMARKS"));
						
						
						
					/*	
						if(rs.getBlob("INPT_SRC_DOC1") != null){
							insPricingVO.setPricingDocs("Y");
							
						}else{
							insPricingVO.setPricingDocs("N");
						}*/
						
						blob1	=	rs.getBlob("INPT_SRC_DOC1") ;
						if(blob1!= null){
							iStream1	=	blob1.getBinaryStream();
							insPricingVO.setInputstreamdoc1(iStream1);
						}
						blob2	=	rs.getBlob("INPT_SRC_DOC2") ;
						if(blob2!= null){
							iStream2	=	blob2.getBinaryStream();
							insPricingVO.setInputstreamdoc2(iStream2);
						}
						
						blob3	=	rs.getBlob("INPT_SRC_DOC3") ;
						if(blob3!= null){
							iStream3	=	blob3.getBinaryStream();
							insPricingVO.setInputstreamdoc3(iStream3);
						}
						
						
						blob4	=	rs.getBlob("INPT_SRC_DOC4") ;
						if(blob4!= null){
							iStream4	=	blob4.getBinaryStream();
							insPricingVO.setInputstreamdoc4(iStream4);
						}
						
						blob5	=	rs.getBlob("INPT_SRC_DOC5") ;
						if(blob5!= null){
							iStream5	=	blob5.getBinaryStream();
							insPricingVO.setInputstreamdoc5(iStream5);
						}
						
						
						
						insPricingVO.setAttachmentname1(UXUtility.checkNull(rs.getString("INPT_SRC_DOC1_NAME")));
						insPricingVO.setAttachmentname2(UXUtility.checkNull(rs.getString("INPT_SRC_DOC2_NAME")));
						insPricingVO.setAttachmentname3(UXUtility.checkNull(rs.getString("INPT_SRC_DOC3_NAME")));
						insPricingVO.setAttachmentname4(UXUtility.checkNull(rs.getString("INPT_SRC_DOC4_NAME")));
						insPricingVO.setAttachmentname5(UXUtility.checkNull(rs.getString("INPT_SRC_DOC5_NAME")));
						insPricingVO.setCompleteSaveYN(UXUtility.checkNull(rs.getString("COMP_SAVE_YN")));//complete save = Y ; else N
						//2nd phase
						insPricingVO.setPolicycategory(UXUtility.checkNull(rs.getString("PREV_POL_PRODUCT_NAME")));
						insPricingVO.setInpatientBenefit(UXUtility.checkNull(rs.getString("IP_COV_YN")));
						insPricingVO.setOutpatientBenefit(UXUtility.checkNull(rs.getString("OP_COV_YN")));
						insPricingVO.setGastricBinding(UXUtility.checkNull(rs.getString("GASTRC_COV_YN")));
						insPricingVO.setHealthScreen(UXUtility.checkNull(rs.getString("HLTH_COV_YN")));
						insPricingVO.setOrthodonticsCopay(UXUtility.checkNull(rs.getString("ORTHO_COPAY_TYPE_SEQ_ID")));
						insPricingVO.setOrthodonticsCopayDesc(UXUtility.checkNull(rs.getString("ORTHO_COPAY_PERC")));
						insPricingVO.setOpdeductableserviceYN(UXUtility.checkNull(rs.getString("OP_CPY_DEDCT_ALL_OP_YN")));
						insPricingVO.setOpCopaypharmacy(UXUtility.checkNull(rs.getString("OP_COPAY_PHM_TYPE_SEQ_ID")));
						insPricingVO.setOpCopaypharmacyDesc(UXUtility.checkNull(rs.getString("OP_COPAY_PHM_PERC")));
						insPricingVO.setOpCopyconsultn(UXUtility.checkNull(rs.getString("OP_COPAY_CON_TYPE_SEQ_ID")));
						insPricingVO.setOpCopyconsultnDesc(UXUtility.checkNull(rs.getString("OP_COPAY_CON_PERC")));
						insPricingVO.setOpInvestigation(UXUtility.checkNull(rs.getString("OP_COPAY_INVST_TYPE_SEQ_ID")));
						insPricingVO.setOpInvestigationDesc(UXUtility.checkNull(rs.getString("OP_COPAY_INVST_PERC")));
						insPricingVO.setOpCopyothers(UXUtility.checkNull(rs.getString("OP_COPAY_OTH_TYPE_SEQ_ID")));
						insPricingVO.setOpCopyothersDesc(UXUtility.checkNull(rs.getString("OP_COPAY_OTH_PERC")));
						insPricingVO.setAlAhlihospital(UXUtility.checkNull(rs.getString("ALHALLI_COV_YN")));
						insPricingVO.setAlAhlihospOPservices(UXUtility.checkNull(rs.getString("OP_CPY_ALHALLI_ALL_OP_YN")));
						insPricingVO.setOpCopyalahlihosp(UXUtility.checkNull(rs.getString("OP_COPAY_ALH_TYPE_SEQ_ID")));
						insPricingVO.setOpCopyalahlihospDesc(UXUtility.checkNull(rs.getString("OP_COPAY_ALH_PERC")));
						insPricingVO.setOpPharmacyAlAhli(UXUtility.checkNull(rs.getString("OP_COPAY_PHM_ALH_TYPE_SEQ_ID")));
						insPricingVO.setOpPharmacyAlAhliDesc(UXUtility.checkNull(rs.getString("OP_COPAY_PHM_ALH_PERC")));
						insPricingVO.setOpConsultAlAhli(UXUtility.checkNull(rs.getString("OP_COPAY_CON_ALH_TYPE_SEQ_ID")));
						insPricingVO.setOpConsultAlAhliDesc(UXUtility.checkNull(rs.getString("OP_COPAY_CON_ALH_PERC")));
						insPricingVO.setOpInvestnAlAhli(UXUtility.checkNull(rs.getString("OP_COPAY_INVST_ALH_TYPE_SEQ_ID")));
						insPricingVO.setOpInvestnAlAhliDesc(UXUtility.checkNull(rs.getString("OP_COPAY_INVST_ALH_PERC")));
						insPricingVO.setOpothersAlAhli(UXUtility.checkNull(rs.getString("OP_COPAY_OTH_ALH_TYPE_SEQ_ID")));
						insPricingVO.setOpothersAlAhliDesc(UXUtility.checkNull(rs.getString("OP_COPAY_OTH_ALH_PERC")));
						insPricingVO.setAlertmsgscreen1(UXUtility.checkNull(rs.getString("POL_CNT_MSG")));
						insPricingVO.setOpticalFrameLimitList(UXUtility.checkNull(rs.getString("OPTCL_FRAMES_LIMIT_SEQ_ID")));
						
					
						insPricingVO.setBrokerCode(UXUtility.checkNull(rs.getString("brokering_type")));
						insPricingVO.setBrokername(UXUtility.checkNull(rs.getString("broker_name")));
						
						
						insPricingVO.setMaxBenifitListip(UXUtility.checkNull(rs.getString("ip_benf_limit_seq_id")));
						//insPricingVO.setMaxBeneLimitOthIp(UXUtility.checkNull(rs.getString("ip_benf_oth_limit")));
						
						insPricingVO.setMaxBenifitListop(UXUtility.checkNull(rs.getString("op_benf_limit_seq_id")));
						insPricingVO.setMaxBeneLimitOthOp(UXUtility.checkNull(rs.getString("op_benf_oth_limit")));
						
					
						insPricingVO.setAreaOfCoverVariations(UXUtility.checkNull(rs.getString("area_cov_variation")));
						insPricingVO.setOrthodontiCscoverage(UXUtility.checkNull(rs.getString("ortho_cov_yn")));
						
						
						insPricingVO.setIpCopay(rs.getLong("ip_copay_type_seq_id"));
						insPricingVO.setIpCopayDesc("ip_copay_perc");
						
						insPricingVO.setiPCopayAtAhliList(rs.getLong("ip_copay_alh_type_seq_id"));
						insPricingVO.setiPCopayAtAhliListDesc(UXUtility.checkNull(rs.getString("ip_copay_alh_perc")));
						
						
						insPricingVO.setAdditionalHospitalCoverageList(UXUtility.checkNull(rs.getString("addi_hosp_cov_seq")));
						insPricingVO.setLoadinghospitalCoverage(rs.getLong("addi_hosp_load"));
						insPricingVO.setLoadinghospitalComment(UXUtility.checkNull(rs.getString("addi_hosp_cov_comment")));
						
						
						
						insPricingVO.setHospitalExclusionsList(UXUtility.checkNull(rs.getString("exclu_hosp_cov_seq")));
						insPricingVO.setDiscounthospitalExclusions(rs.getLong("exclu_hosp_disc"));
						insPricingVO.setDiscounthospitalComment(UXUtility.checkNull(rs.getString("exclu_hosp_cov_comment")));
						
						insPricingVO.setResidencyCountryList(UXUtility.checkNull(rs.getString("res_cont_seq_id")));
						
						insPricingVO.setProRATALimitApplicable(UXUtility.checkNull(rs.getString("pro_rata_limit_applica")));
						
						insPricingVO.setMaternityPricingList(UXUtility.checkNull(rs.getString("mat_pricing_display")));
						
						insPricingVO.setPremiumOutputStructureList(rs.getLong("premium_output_stru"));
						
					   //  insPricingVO.setMaternityCopayList(UXUtility.checkNull(rs.getString("mat_copay_type_seq_id")));
					     
					     insPricingVO.setMaternityCopayList(rs.getLong("mat_copay_type_seq_id"));
					     
					     insPricingVO.setMaternityLimitListDesc(UXUtility.checkNull(rs.getString("mat_copay_perc")));
							
					    
					     
					
						insPricingVO.setLoadingAreaListip(UXUtility.checkNull(rs.getString("area_load_ip")));
						insPricingVO.setLoadingAreaListop(UXUtility.checkNull(rs.getString("area_load_opt")));
						insPricingVO.setLoadingAreaListopt(UXUtility.checkNull(rs.getString("area_load_optc")));
						insPricingVO.setLoadingAreaListdent(UXUtility.checkNull(rs.getString("area_load_dent")));
						insPricingVO.setLoadingAreaListmat(UXUtility.checkNull(rs.getString("area_load_mat")));
						
						insPricingVO.setDiscountAreaListip(UXUtility.checkNull(rs.getString("area_disc_ip")));
						insPricingVO.setDiscountAreaListop(UXUtility.checkNull(rs.getString("area_disc_opt")));
						insPricingVO.setDiscountAreaListopt(UXUtility.checkNull(rs.getString("area_disc_optc")));
						insPricingVO.setDiscountAreaListdent(UXUtility.checkNull(rs.getString("area_disc_dent")));
						insPricingVO.setDiscountAreaListmat(UXUtility.checkNull(rs.getString("area_disc_mat")));
						
						
						insPricingVO.setNetworkListip(UXUtility.checkNull(rs.getString("nwk_type_ip")));
						insPricingVO.setNetworkListop(UXUtility.checkNull(rs.getString("nwk_type_opt")));
						insPricingVO.setNetworkListopt(UXUtility.checkNull(rs.getString("nwk_type_optc")));
						insPricingVO.setNetworkListdent(UXUtility.checkNull(rs.getString("nwk_type_dent")));
						insPricingVO.setNetworkListmat(UXUtility.checkNull(rs.getString("nwk_type_mat")));
						
						
						insPricingVO.setResidencyCountryIp(UXUtility.checkNull(rs.getString("res_cont_load_ip")));
						insPricingVO.setResidencyCountryOp(UXUtility.checkNull(rs.getString("res_cont_load_opt")));
						insPricingVO.setResidencyCountryOtp(UXUtility.checkNull(rs.getString("res_cont_load_optc")));
						insPricingVO.setResidencyCountryDent(UXUtility.checkNull(rs.getString("res_cont_load_dent")));
						insPricingVO.setResidencyCountryMat(UXUtility.checkNull(rs.getString("res_cont_load_mat")));
					
						
						insPricingVO.setTrendFactorIp((UXUtility.checkNull(rs.getString("trnd_factor_perc_ip"))));
						insPricingVO.setTrendFactorOp(UXUtility.checkNull(rs.getString("trnd_factor_perc_opt")));
						insPricingVO.setTrendFactorOpt(UXUtility.checkNull(rs.getString("trnd_factor_perc_optc")));
						insPricingVO.setTrendFactorDent(UXUtility.checkNull(rs.getString("trnd_factor_perc_dent")));
						insPricingVO.setTrendFactorMat(UXUtility.checkNull(rs.getString("trnd_factor_perc_mat")));
						
						insPricingVO.setPremiumRefundApproach(UXUtility.checkNull(rs.getString("refund_cond")));
						
					
						insPricingVO.setUnderWritingYear(UXUtility.checkNull(rs.getString("underwriting_year")));
						insPricingVO.setProductCategory(UXUtility.checkNull(rs.getString("product_catogory")));																																																																																																																																											
						
						insPricingVO.setSrcDoc1Yn(UXUtility.checkNull(rs.getString("src_doc1_yn")));
						insPricingVO.setSrcDoc2Yn(UXUtility.checkNull(rs.getString("src_doc2_yn")));
						insPricingVO.setSrcDoc3Yn(UXUtility.checkNull(rs.getString("src_doc3_yn")));
						insPricingVO.setSrcDoc4Yn(UXUtility.checkNull(rs.getString("src_doc4_yn")));
						insPricingVO.setSrcDoc5Yn(UXUtility.checkNull(rs.getString("src_doc5_yn")));
			            insPricingVO.setCensusFileUploadName(UXUtility.checkNull(rs.getString("MEM_TEMPLET_NAME")));						
						insPricingVO.setAreaOfCoverDesc(UXUtility.checkNull(rs.getString("area_of_cov_desc")));
						insPricingVO.setInitiatedDate(UXUtility.checkNull(rs.getString("pric_intiated_date")));
						insPricingVO.setCensusSavaYn(UXUtility.checkNull(rs.getString("CENSUS_SAVE_YN")));
						insPricingVO.setMaximumBenefitsLimitsDesc((UXUtility.checkNull(rs.getString("max_benf_fnl_limit_desc"))));
						
						System.out.println("maximum benefits ...."+UXUtility.checkNull(rs.getString("max_benf_fnl_limit_desc")));
						System.out.println("CENSUS_SAVE_YN ...."+UXUtility.checkNull(rs.getString("CENSUS_SAVE_YN")));
						
																							
												
					}//end of while(rs.next())
				}
			}
			
		}
		return insPricingVO;
	}

	@Override
	public ArrayList getBenefitvalueAfter(Long lpricingSeqId) throws Exception {
		// TODO Auto-generated method stub
		
		Collection<Object> alResultList = new ArrayList<Object>();
		
    	Collection<Object> alProfileGroupList = new ArrayList<Object>();
    	Collection<Object> alnationalityList = new ArrayList<Object>();
    	   
	        InsPricingVO insPricingVO = null;
	        InsPricingVO insPricingVOtotal = null;
    	try(Connection con = dataSource.getConnection();
				CallableStatement cStmtObject = (java.sql.CallableStatement)con.prepareCall(strswProfileIncomeListValue);){
    		    		
    		/*System.out.println("pricing seq id....."+lpricingSeqId);*/
			cStmtObject.setLong(1, lpricingSeqId);
    		
//			cStmtObject.setString(1,"");
		
			cStmtObject.registerOutParameter(2, OracleTypes.CURSOR);
			cStmtObject.registerOutParameter(3, OracleTypes.CURSOR);
			cStmtObject.registerOutParameter(4, OracleTypes.CURSOR);
			cStmtObject.registerOutParameter(5, OracleTypes.CURSOR);
			cStmtObject.registerOutParameter(6, OracleTypes.CURSOR);
			cStmtObject.execute();
			
			
			try(ResultSet rs = (java.sql.ResultSet)cStmtObject.getObject(2);){
				if(rs != null){
					while(rs.next())
					{
					  	insPricingVO = new InsPricingVO();
						
					
						
						
				/*	System.out.println("BENF_LIVES_SEQ_ID........"+rs.getLong("BENF_LIVES_SEQ_ID"));
					System.out.println("GRP_PROF_SEQ_ID........"+rs.getLong("GRP_PROF_SEQ_ID"));
					System.out.println("BENF_DESC.........."+rs.getString("BENF_DESC"));
					System.out.println("BENF_TYPE_SEQ_ID.........."+rs.getLong("BENF_TYPE_SEQ_ID"));
					System.out.println("GNDR_TYPE_SEQ_ID..........."+rs.getLong("GNDR_TYPE_SEQ_ID"));
					System.out.println("GNDR_DESC........."+rs.getString("GNDR_DESC"));
					System.out.println("AGE_RNG_SEQ_ID........."+rs.getLong("AGE_RNG_SEQ_ID"));*/
			
				
				/*	System.out.println("OVR_PRTFLIO_DSTR........"+rs.getString("OVR_PRTFLIO_DSTR"));*/
					

						
	                	insPricingVO.setBenf_lives_seq_id1(rs.getLong("BENF_LIVES_SEQ_ID"));	                	
	                	insPricingVO.setGroupProfileSeqID(rs.getLong("GRP_PROF_SEQ_ID")); 
	                	insPricingVO.setBenfdesc1(UXUtility.checkNull(rs.getString("BENF_DESC"))); 
	                	insPricingVO.setBenf_typeseqid1(rs.getLong("BENF_TYPE_SEQ_ID"));
	                	insPricingVO.setGndrtypeseqid1(rs.getLong("GNDR_TYPE_SEQ_ID"));
	                  	insPricingVO.setGndrdesc1(UXUtility.checkNull(rs.getString("GNDR_DESC")));
	                	insPricingVO.setAge_rngseqid1(rs.getLong("AGE_RNG_SEQ_ID"));
	                	insPricingVO.setAge_range1(UXUtility.checkNull(rs.getString("AGE_RANGE")));
	                	insPricingVO.setTotalCoverdLives1(UXUtility.checkNull(rs.getString("TOT_COV_LIVES")));
	                	insPricingVO.setOvrprtflio_dstr1(UXUtility.checkNull(rs.getString("OVR_PRTFLIO_DSTR")));	
	                	insPricingVO.setOvrprtflio_dstr2(UXUtility.checkNull(rs.getString("MEM_DSTR")));
	                							
					    alProfileGroupList.add(insPricingVO);						
					}
					
				}
			}
			
			try(ResultSet rs2 = (java.sql.ResultSet)cStmtObject.getObject(3);){
            	if(rs2 != null){
	                while (rs2.next()) {
	                	insPricingVO = new InsPricingVO();
	           
	                	/*System.out.println("TOT_LIVES_COV.."+rs2.getLong("TOT_LIVES_COV"));*/
	                	
	                	insPricingVO.setNatl_seqid1(rs2.getLong("GRP_NAT_SEQ_ID"));
	                	insPricingVO.setNatl_typeseqid1(rs2.getLong("NATL_TYPE_SEQ_ID"));
	                	insPricingVO.setNatl_name1(UXUtility.checkNull(rs2.getString("NATL_NAME"))); 
	                	insPricingVO.setNatCoverdLives1(UXUtility.checkNull(rs2.getString("TOT_LIVES_COV"))); 
	                	insPricingVO.setNatovrprtflio_dstr1(UXUtility.checkNull(rs2.getString("OVR_PRTFLIO_DSTR"))); 
	                	insPricingVO.setNatovrprtflio_dstr2(UXUtility.checkNull(rs2.getString("MEM_DSTR"))); 
	                	alnationalityList.add(insPricingVO);
	                
	                	
	                }
	            }
            	}try(ResultSet rs3 = (java.sql.ResultSet)cStmtObject.getObject(4);){
            		 if(rs3 != null){
			                while (rs3.next()) {
			                	insPricingVOtotal = new InsPricingVO();
			                	
			                /*	System.out.println("IOPT_TOT_LIVES...."+rs3.getString("IOPT_TOT_LIVES"));
			                	System.out.println("OPL_TOT_LIVES..."+rs3.getString("OPL_TOT_LIVES"));
			                	System.out.println("DNT_TOT_LIVES...."+rs3.getString("DNT_TOT_LIVES"));
			                	System.out.println("MAT_TOT_LIVES...."+rs3.getString("MAT_TOT_LIVES"));*/
			                	
			                	
			                	
			                	insPricingVOtotal.setSumTotalLives(UXUtility.checkNull(rs3.getString("IOPT_TOT_LIVES"))); 
			                	
			                	insPricingVOtotal.setSumTotalLivesMale(UXUtility.checkNull(rs3.getString("MAL_TOT_LIVES")));
			                   	insPricingVOtotal.setSumTotalLivesFemale(UXUtility.checkNull(rs3.getString("FEM_TOT_LIVES")));
			                   	
			                   	insPricingVOtotal.setSumTotalLivesMaleUserPer(UXUtility.checkNull(rs3.getString("MAL_DSTR_TOT_LIVES")));
			                   	insPricingVOtotal.setSumTotalLivesFemaleUserPer(UXUtility.checkNull(rs3.getString("FEM_DSTR_TOT_LIVES")));
			                   	
			                   	
			                	insPricingVOtotal.setSumTotalLivesOptical(UXUtility.checkNull(rs3.getString("OPL_TOT_LIVES"))); 
			                	insPricingVOtotal.setSumTotalLivesDental(UXUtility.checkNull(rs3.getString("DNT_TOT_LIVES"))); 
			                	insPricingVOtotal.setSumTotalLivesMaternity(UXUtility.checkNull(rs3.getString("MAT_TOT_LIVES"))); 
			                	//insPricingVOtotal.setSumTotalLivesMaternity(UXUtility.checkNull(rs3.getString("tot_male_lives"))); 
			                	
			                	
			                	
			                	//altotalLives.add(insPricingVOtotal);
			                }
			            }
                	}
            	try(ResultSet rs4 = (java.sql.ResultSet)cStmtObject.getObject(5);){
            		
            		if(rs4 != null){
		                while (rs4.next()) {
		                	//insPricingVOtotal = new InsPricingVO();
		                /*	System.out.println("rs4.getString(1).."+rs4.getString(1));*/
		                	insPricingVOtotal.setSumNationalityLives(UXUtility.checkNull(rs4.getString(1))); 
		                	//almaternityTotalLives.add(insPricingVO);
		                }
		            }
               	}
    		
    		
              try(ResultSet rs5 = (java.sql.ResultSet)cStmtObject.getObject(6);){
            		
            	  if(rs5!=null){
		            	while (rs5.next()) {
		            		insPricingVO = new InsPricingVO();
		            		
		            		System.out.println("Mat_Ageband_Min...."+rs5.getString("Mat_Ageband_Min"));
		            		System.out.println("mat_ageband_max...."+rs5.getString("mat_ageband_max"));
		            		
		                	insPricingVO.setTotalCovedLives(UXUtility.checkNull(rs5.getString("TOTALNOOFLIVES")));
		                	insPricingVO.setTotalLivesMaternity(UXUtility.checkNull(rs5.getString("TOTALMATERNITYLIVES")));
		                	insPricingVO.setMinMaternity(UXUtility.checkNull(rs5.getString("Mat_Ageband_Min")));
		                	insPricingVO.setMaxMaternity( UXUtility.checkNull(rs5.getString("mat_ageband_max")));
		                }
		            } 
               	}
    	}
    	
    	
    	 alResultList.add(alProfileGroupList);
         alResultList.add(alnationalityList);
         alResultList.add(insPricingVOtotal);
         alResultList.add(insPricingVO);
         
		return (ArrayList)alResultList;
	}

	@Override
	public int swSaveIncomeProfile(InsPricingVO insPricingVO) throws Exception {
		
		// TODO Auto-generated method stub
		    int iResult = 0; 
		    Long gndrtypeseqid= null;
	        Long benf_typeseqid= null;
	        String totalCoverdLives = "";
	        Long  benf_lives_seq_id = null;
	        Long  age_range_seq_id = null;
	        Long  ovrprtflio_dstr = null;
	        String clientCode = "";
		
		try(Connection con = dataSource.getConnection();
				CallableStatement cStmtObject = (java.sql.CallableStatement)con.prepareCall(strSwSaveIncomeProfile);){
			int j = 0;
			
        	if(insPricingVO.getGroupProfileSeqID() != null) {
        		
        		
               for(int i=0;i<insPricingVO.getGndrtypeseqid().length;i++){
                  
                	j++;
                	
                    if(!insPricingVO.getBenf_typeseqid()[i].equals(""))//to
                    {
                    	
                    	benf_typeseqid =insPricingVO.getBenf_typeseqid()[i];
                    	                   	                   
                    }
                    else
                    {                   	
                    	benf_typeseqid = null;	                   

                    }
                  
                    if(!insPricingVO.getBenf_lives_seq_id().equals(""))
                    {
                    	benf_lives_seq_id =insPricingVO.getBenf_lives_seq_id()[i]; 
                    }
                    else
                    {
                    	benf_lives_seq_id = null;
                    }                
                    
                    if(!insPricingVO.getGndrtypeseqid().equals(""))
                    {
                    	
                    	gndrtypeseqid =insPricingVO.getGndrtypeseqid()[i]; 
                    }
                    else
                    {
                    	gndrtypeseqid = null;
                    }
                    
                    if(!insPricingVO.getAge_rngseqid().equals(""))
                    {
                    	
                   	age_range_seq_id =insPricingVO.getAge_rngseqid()[i]; 
                    	                    	
                    }
                    else
                    {
                    	age_range_seq_id = null;
                    }
                    
                    
                    if(!insPricingVO.getTotalCoverdLives().equals(""))
                    {
                    	
                    	totalCoverdLives =insPricingVO.getTotalCoverdLives()[i]; 
                    }
                    else
                    {
                    	
                    	totalCoverdLives = null;
                    }
                    
                    if(insPricingVO.getTotalCoverdLives() !=null) {
                    	
                    	
                    	ovrprtflio_dstr = insPricingVO.getOvrprtflio_dstrUser()[i];
                    }else {
                    	ovrprtflio_dstr = 0l;
                    }

    	        	
    	            if(benf_lives_seq_id != null){
    					cStmtObject.setLong(1,benf_lives_seq_id);
    				}
    				else{
    					cStmtObject.setLong(1,0);
    				}
                    
                  
    	            if(insPricingVO.getGroupProfileSeqID() !=null) {
    	            	   cStmtObject.setLong(2,insPricingVO.getGroupProfileSeqID()); 
    	            }else {
    	            	   cStmtObject.setLong(2,0); 
    	            }
    	         
    	            
    	            
    	            if(benf_typeseqid != null){
    	            	
    					cStmtObject.setLong(3,benf_typeseqid);
    				}
    				else{
    					cStmtObject.setLong(3,0);
    				}
    	            
    	            
    	            if(gndrtypeseqid != null){
    					cStmtObject.setLong(4,gndrtypeseqid);
    				}
    				else{
    					cStmtObject.setLong(4,0);
    				}
    	     
    	            
    	            if(age_range_seq_id != null){
    					cStmtObject.setLong(5,age_range_seq_id);
    				}
    				else{
    					cStmtObject.setLong(5,0);
    				}
    	     
    	            if(totalCoverdLives != null){
    					cStmtObject.setString(6,totalCoverdLives);
    				}
    				else{
    					cStmtObject.setString(6,null);
    				}
    	     
    	           
    	            cStmtObject.setLong(7,insPricingVO.getAddedBy()); 
    	          
    	            if(ovrprtflio_dstr != null){
    	            	
    					cStmtObject.setLong(8,ovrprtflio_dstr);
    				}
    				else{
    					cStmtObject.setLong(8,0);
    				}
    	        	cStmtObject.setString(9,insPricingVO.getGroupRegSeqId());
    	            
    	           /* cStmtObject.registerOutParameter(2,Types.INTEGER);*/
    	        
    	            cStmtObject.addBatch();
    	            
        }}
        
        	iResult = 1;
        	
        	cStmtObject.executeBatch();	
        	
        /*	System.out.println("cStmtObject..."+cStmtObject.getLong(2));*/
			
          	      	
        	
		}
		return iResult;
	}

	@Override
	public int swSaveIncomeNatProfile(InsPricingVO insPricingVO) throws Exception {
		// TODO Auto-generated method stub
		int iResult = 0; 
		Long nationality_seqId= null;
	    Long nationality_TypeseqId= null;
	    String nationCoverdLives = null;
	    
	    Long ovrprtflio_dstrUserN = null;
		
		try(Connection con = dataSource.getConnection();
				CallableStatement cStmtObject = (java.sql.CallableStatement)con.prepareCall(strSwSaveIncomeNatProfile);){
			int j = 0;
			
			if(insPricingVO.getGroupProfileSeqID() != null) {
	               for(int i=0;i<insPricingVO.getNatl_typeseqid().length;i++){
	                	j++;
	                    if(!insPricingVO.getNatl_typeseqid()[i].equals(""))//to
	                    {
		                	nationality_TypeseqId =insPricingVO.getNatl_typeseqid()[i]; 

	                    }
	                    else
	                    {
	                    	nationality_TypeseqId = null;

	                    }
	                    
	                    if(!insPricingVO.getNatl_seqid().equals(""))
	                    {
	                    	nationality_seqId =insPricingVO.getNatl_seqid()[i]; 
	                    }
	                    else
	                    {
	                    	nationality_seqId = null;
	                    }
	                    
	                    if(!insPricingVO.getNatCoverdLives().equals(""))
	                    {
	                    	nationCoverdLives =insPricingVO.getNatCoverdLives()[i]; 
	                    }
	                    else
	                    {
	                    	nationCoverdLives = null;
	                    }
	                    
	                    if(insPricingVO.getOvrprtflio_dstrUserNal() != null)
	                    {
	                    	ovrprtflio_dstrUserN = insPricingVO.getOvrprtflio_dstrUserNal()[i]; 
	                    }
	                    else
	                    {
	                    	ovrprtflio_dstrUserN = 0l;
	                    }
	                    
	    	        	
	    	            if(nationality_seqId != null){
	    					cStmtObject.setLong(1,nationality_seqId);
	    				}
	    				else{
	    					cStmtObject.setLong(1,0);
	    				}
	                    
	           
	    	            cStmtObject.setLong(2,insPricingVO.getGroupProfileSeqID()); 
	    	            
	    	            
	    	            if(nationality_TypeseqId != null){
	    					cStmtObject.setLong(3,nationality_TypeseqId);
	    				}
	    				else{
	    					cStmtObject.setLong(3,0);
	    				}
	    	            
	    	     
	    	            if(nationCoverdLives != null){
	    					cStmtObject.setString(4,nationCoverdLives);
	    				}
	    				else{
	    					cStmtObject.setLong(4,0);
	    				}
	    	     
	    	           
	    	            cStmtObject.setLong(5,insPricingVO.getAddedBy()); 
	    	            
	    	            
	    	            if(ovrprtflio_dstrUserN != null){
	    					cStmtObject.setLong(6,ovrprtflio_dstrUserN);
	    				}
	    				else{
	    					  cStmtObject.setLong(6,0); 
	    				}
	    	          
	    	            
	    	       
	    	          
	    	           
	    	            cStmtObject.addBatch();
	        }
	        	}
			 cStmtObject.executeBatch(); 
       	  
	        	iResult = 1;
			
		}
		return iResult;
	}

	@Override
	public String PricingUploadExcel(ArrayList inputData) throws Exception {
		// TODO Auto-generated method stub
		 String status="";      
		try(Connection con = dataSource.getConnection();
				CallableStatement cStmtObject = (java.sql.CallableStatement)con.prepareCall(strSavememberXml);){
			
			 SAXReader saxReader=new SAXReader(); 
             
             Document document=saxReader.read((FileReader)inputData.get(1));
             
           
         
             
             cStmtObject.setLong(1,(Long)inputData.get(3));
           /*  cStmtObject.setObject(2,document.asXML());            */ 
             cStmtObject.setString(2,document.asXML());             
             cStmtObject.setLong(3,(Long)inputData.get(4));  // added by govind
             cStmtObject.setString(6,(String)inputData.get(5)); 
             cStmtObject.setString(7,(String)inputData.get(6)); 
             cStmtObject.setString(8,(String)inputData.get(7)); 
             cStmtObject.setString(9,(String)inputData.get(8));
             cStmtObject.registerOutParameter(4,Types.VARCHAR);//success/error message
             cStmtObject.registerOutParameter(5,Types.INTEGER);
             cStmtObject.execute();	
             
			 status= cStmtObject.getString(4);
			 
			
			
			
		}
		return status;
	}

	@Override
	public InsPricingVO generatePricingNo(Long addedBy) throws Exception {
		// TODO Auto-generated method stub
		InsPricingVO insPricingVO = new InsPricingVO();
		try(Connection con = dataSource.getConnection();
				CallableStatement cStmtObject = (java.sql.CallableStatement)con.prepareCall(strGeneratePricingNo);){
			    cStmtObject.setLong(1,addedBy);
			    cStmtObject.registerOutParameter(2,Types.INTEGER);
			    cStmtObject.registerOutParameter(3,Types.VARCHAR);
			    cStmtObject.execute();	
			    
			  
			    
			    if((Long)cStmtObject.getLong(2) !=null) {
			    	insPricingVO.setGroupProfileSeqID(cStmtObject.getLong(2));			    	
			    }
			    insPricingVO.setPricingRefno(UXUtility.checkNull(cStmtObject.getString(3)));
			    
		return insPricingVO;
	}
	}

	@Override
	public ArrayList getBenefitvalueBefore(Long lpricingSeqId) throws Exception {
		// TODO Auto-generated method stub
		
		Collection<Object> alResultList1 = new ArrayList<Object>();
    	Collection<Object> alResultList2 = new ArrayList<Object>();
    	Collection<Object> alFinalResultList = new ArrayList<Object>();
    
	      Collection<Object> resultList = new ArrayList<Object>();
	        InsPricingVO insPricingVO = null;
	        InsPricingVO insPricingVOtotal = null;
	        try(Connection con = dataSource.getConnection();
					CallableStatement cStmtObject = (java.sql.CallableStatement)con.prepareCall(strMasterListValue);){
	        	    cStmtObject.registerOutParameter(1,OracleTypes.CURSOR);
				    cStmtObject.registerOutParameter(2,OracleTypes.CURSOR);
				    cStmtObject.registerOutParameter(3,OracleTypes.CURSOR);// loading details
				    cStmtObject.registerOutParameter(4,OracleTypes.CURSOR);// IPOP sum details
					cStmtObject.execute();
				    try(ResultSet rs1 = (java.sql.ResultSet)cStmtObject.getObject(1);){
						if(rs1 != null){
							while(rs1.next())
							{
								insPricingVO = new InsPricingVO();
								/*System.out.println("BENF_TYPE_SEQ_ID....."+rs1.getLong("BENF_TYPE_SEQ_ID"));*/
								/*System.out.println("BENF_DESC....."+rs1.getString("BENF_DESC"));*/
							/*	System.out.println("GNDR_TYPE_SEQ_ID....."+rs1.getLong("GNDR_TYPE_SEQ_ID"));
								System.out.println("GNDR_DESC....."+rs1.getString("GNDR_DESC"));
								System.out.println("AGE_RNG_SEQ_ID....."+rs1.getLong("AGE_RNG_SEQ_ID"));
								System.out.println("AGE_RANGE....."+rs1.getString("AGE_RANGE"));
								System.out.println("OVR_PRTFLIO_DSTR....."+rs1.getString("OVR_PRTFLIO_DSTR"));
								System.out.println("MEM_DSTR....."+rs1.getString("MEM_DSTR"));
								*/
								
								
			                	insPricingVO.setBenf_typeseqid1(rs1.getLong("BENF_TYPE_SEQ_ID"));			                	
			                	insPricingVO.setBenfdesc1(UXUtility.checkNull(rs1.getString("BENF_DESC"))); 
			                	insPricingVO.setGndrtypeseqid1(rs1.getLong("GNDR_TYPE_SEQ_ID"));			                	
			                	insPricingVO.setGndrdesc1(UXUtility.checkNull(rs1.getString("GNDR_DESC")));
			                	insPricingVO.setAge_rngseqid1(rs1.getLong("AGE_RNG_SEQ_ID"));
			                	insPricingVO.setAge_range1(UXUtility.checkNull(rs1.getString("AGE_RANGE")));
			                	insPricingVO.setOvrprtflio_dstr1(UXUtility.checkNull(rs1.getString("OVR_PRTFLIO_DSTR")));
			                	insPricingVO.setOvrprtflio_dstr2(UXUtility.checkNull(rs1.getString("MEM_DSTR")));
			                	
			                	alResultList1.add(insPricingVO);
								
							}
						}
				    }
				    
				    try(ResultSet rs2 = (java.sql.ResultSet)cStmtObject.getObject(2);){
						if(rs2 != null){
							while(rs2.next())
							{
								insPricingVO = new InsPricingVO();
								
			                	insPricingVO.setNatl_typeseqid1(rs2.getLong("NATL_TYPE_SEQ_ID"));
			                	insPricingVO.setNatl_name1(UXUtility.checkNull(rs2.getString("NATL_NAME"))); 
			                	insPricingVO.setNatovrprtflio_dstr1(UXUtility.checkNull(rs2.getString("OVR_PRTFLIO_DSTR"))); 
			                	insPricingVO.setNatovrprtflio_dstr2(UXUtility.checkNull(rs2.getString("MEM_DSTR"))); 

			                	alResultList2.add(insPricingVO);
								
							}
						}
				    }
				    
				    try(ResultSet rs3 = (java.sql.ResultSet)cStmtObject.getObject(3);){
						if(rs3 != null){
							while(rs3.next())
							{
								
								
							}
						}
				    }
				    
				    try(ResultSet rs4 = (java.sql.ResultSet)cStmtObject.getObject(4);){
						if(rs4 != null){
							while(rs4.next())
							{
								
								insPricingVOtotal = new InsPricingVO();
			                	
			                	insPricingVOtotal.setSumTotalLives(UXUtility.checkNull(rs4.getString("IOPT_TOT_LIVES"))); 
			                	insPricingVOtotal.setSumTotalLivesOptical(UXUtility.checkNull(rs4.getString("OPL_TOT_LIVES"))); 
			                	insPricingVOtotal.setSumTotalLivesDental(UXUtility.checkNull(rs4.getString("DNT_TOT_LIVES"))); 
			                	insPricingVOtotal.setSumTotalLivesMaternity(UXUtility.checkNull(rs4.getString("MAT_TOT_LIVES"))); 
			                 	insPricingVOtotal.setSumNationalityLives(UXUtility.checkNull(rs4.getString("NAT_TOT_LIVES"))); 
			                 	
								
							}
						}
				    }
				    
				    
	        	
	        }
	        alFinalResultList.add(alResultList1);
            alFinalResultList.add(alResultList2);
            alFinalResultList.add(insPricingVOtotal);
	      
            return (ArrayList)alFinalResultList;	
	}

	@Override
	public InsPricingVO swFetchScreen1(InsPricingVO insPricingVO) throws Exception {
		// TODO Auto-generated method stub
		try(Connection con = dataSource.getConnection();
				CallableStatement cStmtObject = (java.sql.CallableStatement)con.prepareCall(strFetchDetails);){

			if(insPricingVO.getPreviousPolicyNo()!=null)
			{
			
				cStmtObject.setString(1,insPricingVO.getPreviousPolicyNo());
			}if(insPricingVO.getRenewalYN()!=null)
			{
				
				cStmtObject.setString(2,insPricingVO.getRenewalYN());
			}
			
	
			cStmtObject.registerOutParameter(3,OracleTypes.CURSOR);
			cStmtObject.execute();
			
			   try(ResultSet rs = (java.sql.ResultSet)cStmtObject.getObject(3);){
					if(rs != null){
						while(rs.next())
						{

						

							insPricingVO.setMaternityYN(UXUtility.checkNull(rs.getString("MAT_COV_YN")));						
							insPricingVO.setDentalYN(UXUtility.checkNull(rs.getString("DNTL_COV_YN")));
						/*	insPricingVO.setDentalLivesYN(UXUtility.checkNull(rs.getString("DNTL_COV_ALL_LIVES_YN")));*/
							insPricingVO.setOpticalYN(UXUtility.checkNull(rs.getString("OPTCL_COV_YN")));				
							/*insPricingVO.setOpticalLivesYN(UXUtility.checkNull(rs.getString("OPTCL_COV_ALL_LIVES_YN")));*/
							/*insPricingVO.setPhysiocoverage(UXUtility.checkNull(rs.getString("PSYTHRPY_COV_YN")));*/
							/*insPricingVO.setVitDcoverage(UXUtility.checkNull(rs.getString("VITAMIN_D_COV_YN")));*/
							
						/*	insPricingVO.setVaccImmuCoverage(UXUtility.checkNull(rs.getString("VACC_IMMUN_COV_YN")));*/
							/*insPricingVO.setMatComplicationCoverage(UXUtility.checkNull(rs.getString("MAT_COMPLCTION_COV_YN")));*/
							/*insPricingVO.setPsychiatrycoverage(UXUtility.checkNull(rs.getString("PSYCHRTRY_COV_YN")));				*/
						/*	insPricingVO.setDeviatedNasalSeptum(UXUtility.checkNull(rs.getString("DEVTD_NASL_SEPTM_COV_YN")));
							insPricingVO.setObesityTreatment(UXUtility.checkNull(rs.getString("OBSTY_TRTMNT_COV_YN")));*/
							insPricingVO.setAreaOfCoverList(UXUtility.checkNull(rs.getString("AREA_TYPE_SEQ_ID")));
							
							insPricingVO.setNetworkList(UXUtility.checkNull(rs.getString("NWK_TYPE_SEQ_ID")));
							insPricingVO.setMaxBenifitList(UXUtility.checkNull(rs.getString("MAX_BENF_LIMIT_SEQ_ID")));
							insPricingVO.setMaxBeneLimitOth(UXUtility.checkNull(rs.getString("MAX_BENF_OTH_LIMIT")));				
							insPricingVO.setDentalLimitList(UXUtility.checkNull(rs.getString("DENTL_LIMIT_SEQ_ID")));
							
							insPricingVO.setDentalLimitOth(UXUtility.checkNull(rs.getString("DENTL_OTH_LIMIT")));
							insPricingVO.setMaternityLimitList(rs.getLong("MAT_LIMIT_SEQ_ID"));
							insPricingVO.setMaternityLimitOth(UXUtility.checkNull(rs.getString("MAT_OTH_LIMIT")));
						
							insPricingVO.setOpticalLimitList(UXUtility.checkNull(rs.getString("OPTCL_LIMIT_SEQ_ID")));
							insPricingVO.setOpticalLimitOth(UXUtility.checkNull(rs.getString("OPTCL_OTH_LIMIT")));				
					
							insPricingVO.setOpCopayList(UXUtility.checkNull(rs.getString("OPT_COPAY_TYPE_SEQ_ID")));
							insPricingVO.setOpCopayListDesc(UXUtility.checkNull(rs.getString("OPT_COPAY_PERC")));
							insPricingVO.setDentalcopayList(UXUtility.checkNull(rs.getString("DNT_COPAY_TYPE_SEQ_ID")));
							insPricingVO.setDentalcopayListDesc(UXUtility.checkNull(rs.getString("DNT_COPAY_PERC")));				
							insPricingVO.setOpticalCopayList(UXUtility.checkNull(rs.getString("OPTCL_COPAY_TYPE_SEQ_ID")));
							insPricingVO.setOpticalCopayListDesc(UXUtility.checkNull(rs.getString("OPTCL_COPAY_PERC")));
						/*	insPricingVO.setOpDeductableList(UXUtility.checkNull(rs.getString("OPT_DEDUCT_TYPE_SEQ_ID")));
							insPricingVO.setOpDeductableListDesc(UXUtility.checkNull(rs.getString("OPT_DEDUCTBLE")));*/
							/////////////////////// comments and document fetch removed///////////////////////////
				/*			insPricingVO.setAttachmentname1(TTKCommon.checkNull(rs.getString("INPT_SRC_DOC1_NAME")));
							insPricingVO.setAttachmentname2(TTKCommon.checkNull(rs.getString("INPT_SRC_DOC2_NAME")));
							insPricingVO.setAttachmentname3(TTKCommon.checkNull(rs.getString("INPT_SRC_DOC3_NAME")));
							insPricingVO.setAttachmentname4(TTKCommon.checkNull(rs.getString("INPT_SRC_DOC4_NAME")));
							insPricingVO.setAttachmentname5(TTKCommon.checkNull(rs.getString("INPT_SRC_DOC5_NAME")));*/
					//		insPricingVO.setCompleteSaveYN(TTKCommon.checkNull(rs.getString("COMP_SAVE_YN")));//complete save = Y ; else N
							//2nd phase
						/*	insPricingVO.setPolicycategory(UXUtility.checkNull(rs.getString("PREV_POL_PRODUCT_NAME")));*/
							insPricingVO.setInpatientBenefit(UXUtility.checkNull(rs.getString("IP_COV_YN")));
							insPricingVO.setOutpatientBenefit(UXUtility.checkNull(rs.getString("OP_COV_YN")));
						/*	insPricingVO.setGastricBinding(UXUtility.checkNull(rs.getString("GASTRC_COV_YN")));*/
							/*insPricingVO.setHealthScreen(UXUtility.checkNull(rs.getString("HLTH_COV_YN")));*/
							insPricingVO.setOrthodonticsCopay(UXUtility.checkNull(rs.getString("ORTHO_COPAY_TYPE_SEQ_ID")));
							insPricingVO.setOrthodonticsCopayDesc(UXUtility.checkNull(rs.getString("ORTHO_COPAY_PERC")));
						/*	insPricingVO.setOpdeductableserviceYN(UXUtility.checkNull(rs.getString("OP_CPY_DEDCT_ALL_OP_YN")));*/
						/*	insPricingVO.setOpCopaypharmacy(UXUtility.checkNull(rs.getString("OP_COPAY_PHM_TYPE_SEQ_ID")));*/
						/*	insPricingVO.setOpCopaypharmacyDesc(UXUtility.checkNull(rs.getString("OP_COPAY_PHM_PERC")));*/
							/*insPricingVO.setOpCopyconsultn(UXUtility.checkNull(rs.getString("OP_COPAY_CON_TYPE_SEQ_ID")));*/
						/*	insPricingVO.setOpCopyconsultnDesc(UXUtility.checkNull(rs.getString("OP_COPAY_CON_PERC")));*/
						/*	insPricingVO.setOpInvestigation(UXUtility.checkNull(rs.getString("OP_COPAY_INVST_TYPE_SEQ_ID")));
							insPricingVO.setOpInvestigationDesc(UXUtility.checkNull(rs.getString("OP_COPAY_INVST_PERC")));
							insPricingVO.setOpCopyothers(UXUtility.checkNull(rs.getString("OP_COPAY_OTH_TYPE_SEQ_ID")));*/
							/*insPricingVO.setOpCopyothersDesc(UXUtility.checkNull(rs.getString("OP_COPAY_OTH_PERC")));*/
							insPricingVO.setAlAhlihospital(UXUtility.checkNull(rs.getString("ALHALLI_COV_YN")));
						/*	insPricingVO.setAlAhlihospOPservices(UXUtility.checkNull(rs.getString("OP_CPY_ALHALLI_ALL_OP_YN")));*/
							insPricingVO.setOpCopyalahlihosp(UXUtility.checkNull(rs.getString("OP_COPAY_ALH_TYPE_SEQ_ID")));
							insPricingVO.setOpCopyalahlihospDesc(UXUtility.checkNull(rs.getString("OP_COPAY_ALH_PERC")));
							/*insPricingVO.setOpPharmacyAlAhli(UXUtility.checkNull(rs.getString("OP_COPAY_PHM_ALH_TYPE_SEQ_ID")));*/
						/*	insPricingVO.setOpPharmacyAlAhliDesc(UXUtility.checkNull(rs.getString("OP_COPAY_PHM_ALH_PERC")));*/
							/*insPricingVO.setOpConsultAlAhli(UXUtility.checkNull(rs.getString("OP_COPAY_CON_ALH_TYPE_SEQ_ID")));
							insPricingVO.setOpConsultAlAhliDesc(UXUtility.checkNull(rs.getString("OP_COPAY_CON_ALH_PERC")));
							insPricingVO.setOpInvestnAlAhli(UXUtility.checkNull(rs.getString("OP_COPAY_INVST_ALH_TYPE_SEQ_ID")));
							insPricingVO.setOpInvestnAlAhliDesc(UXUtility.checkNull(rs.getString("OP_COPAY_INVST_ALH_PERC")));
							insPricingVO.setOpothersAlAhli(UXUtility.checkNull(rs.getString("OP_COPAY_OTH_ALH_TYPE_SEQ_ID")));
							insPricingVO.setOpothersAlAhliDesc(UXUtility.checkNull(rs.getString("OP_COPAY_OTH_ALH_PERC")));*/
							insPricingVO.setOpticalFrameLimitList(UXUtility.checkNull(rs.getString("OPTCL_FRAMES_LIMIT_SEQ_ID")));
							
			
							
							insPricingVO.setMaxBenifitListop(UXUtility.checkNull(rs.getString("op_benf_limit_seq_id")));
							insPricingVO.setMaxBeneLimitOthOp(UXUtility.checkNull(rs.getString("op_benf_oth_limit")));
							
							
						/*	insPricingVO.setLoadingAreaListip(UXUtility.checkNull(rs.getString("area_of_cover_loading_ip")));
							insPricingVO.setLoadingAreaListop(UXUtility.checkNull(rs.getString("area_of_cover_loading_opt")));
							insPricingVO.setLoadingAreaListopt(UXUtility.checkNull(rs.getString("area_of_cover_loading_opcl")));
							insPricingVO.setLoadingAreaListdent(UXUtility.checkNull(rs.getString("area_of_cover_loading_mat")));
							insPricingVO.setLoadingAreaListmat(UXUtility.checkNull(rs.getString("area_of_cover_loading_dent")));
							*/
							insPricingVO.setIpCopay(rs.getLong("ip_copay_type_seq_id"));
							insPricingVO.setIpCopayDesc("ip_copay_perc");
							insPricingVO.setiPCopayAtAhliList(rs.getLong("ip_copay_alh_type_seq_id"));
							insPricingVO.setiPCopayAtAhliListDesc(UXUtility.checkNull(rs.getString("ip_copay_alh_perc")));
							
						/*	insPricingVO.setResidencyCountryList(UXUtility.checkNull(rs.getString("residency_country_seq_id")));
							insPricingVO.setResidencyCountryIp(UXUtility.checkNull(rs.getString("residency_count_loading_ip")));
							insPricingVO.setResidencyCountryOp(UXUtility.checkNull(rs.getString("residency_count_loading_op")));
							insPricingVO.setResidencyCountryOtp(UXUtility.checkNull(rs.getString("residency_count_loading_opcl")));
							insPricingVO.setResidencyCountryDent(UXUtility.checkNull(rs.getString("residency_count_loading_mat")));
							insPricingVO.setResidencyCountryMat(UXUtility.checkNull(rs.getString("residency_count_loading_dent")));*/
							
							
							insPricingVO.setMaternityPricingList(UXUtility.checkNull(rs.getString("mat_pric_type_id")));
							insPricingVO.setPremiumOutputStructureList(rs.getLong("prem_stru_type_id"));
							insPricingVO.setProRATALimitApplicable(UXUtility.checkNull(rs.getString("pro_rata_limit_applicable")));
							
							
							insPricingVO.setPremiumRefundApproach(UXUtility.checkNull(rs.getString("premium_refund_aproach")));
							
						/*	insPricingVO.setDiscountAreaListip(UXUtility.checkNull(rs.getString("area_of_cover_discount_ip")));
							insPricingVO.setDiscountAreaListop(UXUtility.checkNull(rs.getString("area_of_cover_discount_opt")));
							insPricingVO.setDiscountAreaListopt(UXUtility.checkNull(rs.getString("area_of_cover_discount_opcl")));
							insPricingVO.setDiscountAreaListdent(UXUtility.checkNull(rs.getString("area_of_cover_discount_mat")));
							insPricingVO.setDiscountAreaListmat(UXUtility.checkNull(rs.getString("area_of_cover_discount_dent")));*/
							insPricingVO.setNotifyerror(UXUtility.checkNull(rs.getString("ALERT")));
							//insPricingVO.setAlertmsgscreen1(TTKCommon.checkNull(rs.getString("POL_CNT_MSG")));
							insPricingVO.setMaternityCopayList(rs.getLong("mat_copay_type_seq_id"));
							
							
							
						}
					}
			   }
			
		}
		return insPricingVO;
	}

	@Override
	public Long deleteFile(Long FileNo,Long groupProSeqId) throws Exception {
		// TODO Auto-generated method stub
		Long status=0l;
		try(Connection con = dataSource.getConnection();
				CallableStatement cStmtObject = (java.sql.CallableStatement)con.prepareCall(strDeleteFile);){
			cStmtObject.setLong(1,groupProSeqId);
			cStmtObject.setLong(2,FileNo);
			cStmtObject.setString(3,"");
			cStmtObject.registerOutParameter(4,Types.INTEGER);
			cStmtObject.execute();
			status = (Long)cStmtObject.getLong(4);
		
		}
		return status;
	}

	@Override
	public InsPricingVO getfalgPricingvalue(long lpricingSeqId) throws Exception {
		// TODO Auto-generated method stub
		
		InsPricingVO  insPricingVO =new InsPricingVO();
		try(Connection con = dataSource.getConnection();
				PreparedStatement pStmtObject = con.prepareStatement(strPricingFlag);){
			pStmtObject.setLong(1,lpricingSeqId);
			try(ResultSet rs = pStmtObject.executeQuery();){
				if(rs != null){
					while(rs.next())
					{
						insPricingVO =  new InsPricingVO();
	                	insPricingVO.setGroupProfileSeqID(lpricingSeqId);
	                	
	                	
	                	
	                	insPricingVO.setBenecoverFlagYN(UXUtility.checkNull(rs.getString("BENF_COV_SVE_YN")));
	                	insPricingVO.setCalCPMFlagYN(UXUtility.checkNull(rs.getString("CAL_CPM_SVE_YN")));
	                	insPricingVO.setLoadingFlagYN(UXUtility.checkNull(rs.getString("CAL_LODING_SVE_YN")));
	                	insPricingVO.setDemographicflagYN(UXUtility.checkNull(rs.getString("DMGRPHC_SAVE_YN")));
	                	insPricingVO.setPricingmodifyYN(UXUtility.checkNull(rs.getString("MODIFY_YN")));
	                	insPricingVO.setCompleteSaveYNInSc2(UXUtility.checkNull(rs.getString("CENSUS_SAVE_YN")));
	                	insPricingVO.setRiskPremiumDate(UXUtility.checkNull(rs.getString("ADDED_DATE")));
	                	int trendfactor =  rs.getInt("TRND_FACTOR_PERC");
	                	
	                	if(trendfactor < 6){
	                		insPricingVO.setTrendFactor("Y");
	                	}else{
	                		insPricingVO.setTrendFactor("N");
	                	}
						
					}
				}
			}
			
		}
		return insPricingVO;
		
	}

	@Override
	public int swsaveCensusMatAgeband(InsPricingVO insPricingVO) throws Exception {
		// TODO Auto-generated method stub
		
		try(Connection con = dataSource.getConnection();
				CallableStatement cStmtObject = (java.sql.CallableStatement)con.prepareCall(strSaveMaternity);){
			if(insPricingVO.getGroupProfileSeqID() !=null) {
				cStmtObject.setLong(1,insPricingVO.getGroupProfileSeqID());
			}else {
				cStmtObject.setLong(1,0l);
			}
			
			
			if(insPricingVO.getMinMaternity() !=null) {
				cStmtObject.setLong(2,Long.valueOf(insPricingVO.getMinMaternity()));
			}else {
				cStmtObject.setLong(2,0l);
			}
			
			if(insPricingVO.getMaxMaternity() !=null) {
				cStmtObject.setLong(3,Long.valueOf(insPricingVO.getMaxMaternity()));
			}else {
				cStmtObject.setLong(3,0l);
			}
		
			
			cStmtObject.execute();
		}
		return 0;
	}

	@Override
	public InsPricingVO beforeSeveCensusData(Long groupProSeqId, Long addedBy)  throws Exception {
		// TODO Auto-generated method stub
		InsPricingVO insPricingVOCessus=new InsPricingVO();
		try(Connection con = dataSource.getConnection();
				CallableStatement cStmtObject = (java.sql.CallableStatement)con.prepareCall(strBeforeSaveCensus);){	
			
			
			      
				cStmtObject.setLong(1,groupProSeqId);
				cStmtObject.setLong(3,addedBy);
				cStmtObject.registerOutParameter(1,Types.INTEGER);
				cStmtObject.registerOutParameter(2,Types.VARCHAR);
				cStmtObject.execute();
				
				
				
				insPricingVOCessus.setGroupProfileSeqID((Long)cStmtObject.getLong(1));
				insPricingVOCessus.setPricingRefno((String)cStmtObject.getString(2));
				 
		}				                     
		return insPricingVOCessus;
	}

	@Override
	public InsPricingVO doViewUploadDocs(Long groupProSeqId, String fileType) throws Exception {
		// TODO Auto-generated method stub
		InsPricingVO insPricingVO = new InsPricingVO();
		Blob blob1	=	null;
		InputStream iStream1	=	new ByteArrayInputStream(new String("").getBytes());
		try(Connection con = dataSource.getConnection();
				CallableStatement cStmtObject = (java.sql.CallableStatement)con.prepareCall(strDoViewUploadFile);){
			
			
			cStmtObject.setLong(1,groupProSeqId);
			cStmtObject.setLong(2,Long.parseLong(fileType));
			cStmtObject.setString(3,"");
			cStmtObject.registerOutParameter(4,OracleTypes.CURSOR);
			cStmtObject.execute();
			
			   try(ResultSet rs = (java.sql.ResultSet)cStmtObject.getObject(4);){
					if(rs != null){
						while(rs.next())
						{
							blob1	= rs.getBlob("DOC") ;
							if(blob1!= null){
								iStream1	=	blob1.getBinaryStream();
								insPricingVO.setInputstreamdoc1(iStream1);
							}
							
							insPricingVO.setAttachmentname1(UXUtility.checkNull(rs.getString("DOC_NAME")));
							
						}
					}		

			   }
		} 
		
		return insPricingVO;
	}

	@Override
	public ArrayList getGroupList(ArrayList alSearchCriteria) throws Exception {
		// TODO Auto-generated method stub
		PolicyGroupVO policyGroupVO = null;
		Collection<Object> alResultList = new ArrayList<Object>();
		try(Connection con = dataSource.getConnection();
				CallableStatement cStmtObject = (java.sql.CallableStatement)con.prepareCall(strGroupList);){
			
		
			
			cStmtObject.setString(1,(String)alSearchCriteria.get(0));
			cStmtObject.setString(2,(String)alSearchCriteria.get(1));
			cStmtObject.setString(3,(String)alSearchCriteria.get(2));
			cStmtObject.setString(4,(String)alSearchCriteria.get(3));
			cStmtObject.setString(5,(String)alSearchCriteria.get(4));
			cStmtObject.setString(6,(String)alSearchCriteria.get(5));
			cStmtObject.registerOutParameter(7,OracleTypes.CURSOR);
			cStmtObject.execute();
			
			   try(ResultSet rs = (java.sql.ResultSet)cStmtObject.getObject(7);){
					if(rs != null){
						while(rs.next())
						{
							policyGroupVO = new PolicyGroupVO();
							if(rs.getString("GROUP_REG_SEQ_ID") != null){
								policyGroupVO.setGroupRegnSeqID(new Long(rs.getLong("group_reg_seq_id")));
							}//end of if(rs.getString("GROUP_REG_SEQ_ID") != null)
							policyGroupVO.setGroupID(UXUtility.checkNull(rs.getString("GROUP_ID")));
							policyGroupVO.setGroupName(UXUtility.checkNull(rs.getString("GROUP_NAME")));
							policyGroupVO.setBranchName(UXUtility.checkNull(rs.getString("OFFICE_NAME")));
							alResultList.add(policyGroupVO);
							
						}
					}
			   }		
		}
		return (ArrayList)alResultList;
	}

	@Override
	public ArrayList getAdditionalHospitalList(String networkCode) throws Exception {
		CacheObject cacheObject = null;
		ArrayList<CacheObject> alHospitalList = new ArrayList<>();
		try(Connection con = dataSource.getConnection();
				PreparedStatement pStmtObject = con.prepareStatement(getAdditionalHospitalList);){	
			pStmtObject.setString(1,networkCode);					
			try(ResultSet rs = pStmtObject.executeQuery();){
				if(rs != null){
					while(rs.next())
					{
						cacheObject = new CacheObject();						
						cacheObject.setCacheId(UXUtility.checkNull(rs.getString("HOSP_SEQ_ID")));
						cacheObject.setCacheDesc(UXUtility.checkNull(rs.getString("HOSP_NAME")));
						alHospitalList.add(cacheObject);
					}//end of while(rs.next())
				}
			}
			
		}	
		
		return alHospitalList;
	}

	@Override
	public ArrayList getOpLimitlist(String maximumLimitdesc) throws Exception {
		// TODO Auto-generated method stub
		
		CacheObject cacheObject = null;
		ArrayList<CacheObject> olLimitList = new ArrayList<>();
		try(Connection con = dataSource.getConnection();
				PreparedStatement pStmtObject = con.prepareStatement(oplimitList);){	
			pStmtObject.setString(1,maximumLimitdesc);	
			pStmtObject.setString(2,maximumLimitdesc);	
			
			try(ResultSet rs = pStmtObject.executeQuery();){
				if(rs != null){
					while(rs.next())
					{
						cacheObject = new CacheObject();	
						
					
						
						cacheObject.setCacheId(UXUtility.checkNull(rs.getString("LIMIT_TYPE_SEQ_ID")));
						cacheObject.setCacheDesc(UXUtility.checkNull(rs.getString("max_limit_desc")));
						olLimitList.add(cacheObject);
					}//end of while(rs.next())
				}
			}
			
		}	
		
		return olLimitList;
		
	}
	

	
	

}

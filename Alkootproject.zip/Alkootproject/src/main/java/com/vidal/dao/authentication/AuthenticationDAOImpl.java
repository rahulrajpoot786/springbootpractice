/***
 * Date 15/03/2018
 * @author sangamesh
 * AuthenticationDAOImpl.java
 * 
 */
package com.vidal.dao.authentication;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.ArrayList;

import javax.sql.DataSource;

import oracle.jdbc.OracleTypes;

import org.apache.log4j.Logger;
import org.dom4j.Document;
import org.dom4j.io.DOMReader;
import org.dom4j.io.SAXReader;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.vidal.command.usermanagement.UserVO;
import com.vidal.common.UXUtility;


@Repository
public class AuthenticationDAOImpl{
	private static Logger logger = Logger.getLogger( AuthenticationDAOImpl.class );

	// private static final String strUserValidation="{CALL AUTHENTICATION_PKG.pr_user_validation_pricing(?,?,?,?)}";	
	 private static final String strUserValidation="{CALL PRICING_APP_PKG.pr_user_validation_pricing(?,?,?,?)}";	

	/***
	 * This is used for Authorization
	 * @param userVO
	 * @return
	 * @throws Exception
	 */
	public Document doAuthentication(UserVO userVO) throws Exception{

		Document doc = null;
		           
	
		try(Connection con = dataSource.getConnection();
				CallableStatement cStmtObject =con.prepareCall(strUserValidation);)
				{
			            DatabaseMetaData data=con.getMetaData();
					String HostIPAddress=userVO.getHostIPAddress()+"-"+userVO.getLocalIPAddress();
					System.out.println("HostIPAddress..."+HostIPAddress);
					logger.info("   HostIPAddress "+HostIPAddress);
					
					cStmtObject.setString(1,userVO.getUSER_ID());
					cStmtObject.setString(2,userVO.getPassword());
					cStmtObject.setString(3,HostIPAddress);
					//cStmtObject.registerOutParameter(4,OracleTypes.OPAQUE,"SYS.XMLTYPE");
					cStmtObject.registerOutParameter(4, OracleTypes.CLOB);
					cStmtObject.execute();	
					//xml = XMLType.createXML(((Object) cStmtObject).getOPAQUE(4));
					if(cStmtObject.getCharacterStream(4) != null){
						doc =new SAXReader().read(cStmtObject.getCharacterStream(4));
		             }
					
				}
		//System.out.println("doc..."+doc.asXML());
		return doc;
	}
	/**
	 * This is logout method
	 * @param al
	 * @return
	 * @throws Exception
	 */
	public int doLogout(String UserID) throws Exception{
		int iResult = 0; 
               System.out.println("UserID......."+UserID);
			try(Connection con = dataSource.getConnection();
					CallableStatement cStmtObject =	(java.sql.CallableStatement)con.prepareCall( "{CALL AUTHENTICATION_PKG.LOGOUT(?,?,?)}");){
				cStmtObject.setString(1,UserID);//ADDED_BY
	            cStmtObject.setString(2,null);//ADDED_BY
	            cStmtObject.registerOutParameter(3, Types.INTEGER);//ROWS_PROCESSED
	            cStmtObject.execute();
	            iResult = cStmtObject.getInt(3);//ROWS_PROCESSED
			
		}
	
		return iResult;
	}
	/*public String doUserStatus(ArrayList al) throws Exception{
		String status=null;
		try(Connection con = dataSource.getConnection();
				PreparedStatement pStmtObject = con.prepareStatement("select user_status from app.tpa_login_info where contact_seq_id=?");){
			pStmtObject.setLong(1, Long.parseLong(UXUtility.checkNull(al.get(0)).toString()));
			try(ResultSet rs = pStmtObject.executeQuery();){
				if(rs != null){
					while(rs.next())
					{
						status = UXUtility.checkNull(rs.getString("user_status"));
					}
				}

			}
			return status;
		}
	}*/
	@Autowired
	private DataSource dataSource;
}

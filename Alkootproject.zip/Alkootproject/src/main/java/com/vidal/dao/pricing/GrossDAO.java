package com.vidal.dao.pricing;

import java.util.ArrayList;

import com.vidal.command.pricing.InsPricingVO;
import com.vidal.command.pricing.SwPricingSummaryVO;
import com.vidal.command.pricing.WhatifScreenVO;

public interface GrossDAO {
	//public int getSave(ArrayList Grosscalculate) throws Exception;
	public ArrayList[] getcpmAfterLoadingPricing(InsPricingVO insPricingVO) throws Exception;
	public InsPricingVO getfalgPricingvalue(long group_seq_id) throws Exception;
	
	public  WhatifScreenVO getWhatifDetails(Long groupSeqId,Long varSeqId,Long verNo,String vrsionFlag) throws Exception;
	
	public WhatifScreenVO saveEstimateChange(WhatifScreenVO shatifScreenVO) throws Exception;
	
	public Long saveWhatifDetails(Long groupSeqId,Long varSeqId,Long verNo) throws Exception;
	
	public Long saveWhatIfDetailsChange(Long groupSeqId,Long varSeqId,Long verNo) throws Exception;
	
	public WhatifScreenVO getVersionSeqId(Long groupSeqId,Long verNo) throws Exception;
}

/**
 * @ (#) CacheDAO.java MAY 22, 2018
 * Project      : VINGS
 * File         : CacheDAO.java
 * Author       : RISHABH KESHARI
 * Company      : VIDAL HEALTH
 * Date Created : MAY 22, 2018
 *
 * @author       :  RISHABH KESHARI
 * Modified by   :
 * Modified date :
 * Reason        : 
 */

package com.vidal.dao.business.common;

import java.util.ArrayList;


public interface CacheDAO {

	public void populateData(String[] identfierList,String jspIdentifier)throws Exception;
	public void refreshPopulateData(String Identifier) throws Exception;

	public ArrayList loadObjects(String strIdentifier) throws Exception;

	public ArrayList loadObjects1(String strIdentifier,Long strClaimSeqId) throws Exception;
}

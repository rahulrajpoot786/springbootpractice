package com.vidal.dao.pricing;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.ArrayList;

import javax.sql.DataSource;

import oracle.jdbc.OracleTypes;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.vidal.command.pricing.InsPricingVO;
import com.vidal.command.pricing.SwFinalQuoteVO;
import com.vidal.common.UXUtility;
import com.vidal.common.VidalCommon;

@Repository
public class PropsalTOBDAOImpl implements PropsalTobDao{
	private static String strsavePropsal="{CALL PRICING_APP_PKG.save_pol_copies(?,?,?,?,?,?,?,?,?,?,?,?,?)}";
	private static String strpolicynumber="{CALL PRICING_APP_PKG.save_policy_info(?,?,?,?)}";
	private static final String strpropsalcounty = "select qar_per_unit  units_per_qar from app.tpa_currency_conv_rates a where trunc(a.uploaded_date) = trunc(sysdate) and a.currency_code=?";
   private static final String strPropsalFlag="select  nvl(a.additnl_benf_save_yn,'N') additnl_benf_save_yn, NVL(a.genrate_proposal_yn,'N') genrate_proposal_yn, NVL(a.prpsl_send_apprvl_yn,'N') prpsl_send_apprvl_yn, NVL(a.prpsl_acpy_rjct_yn,'N') prpsl_acpy_rjct_yn, a.policy_number, case when policy_number is null then 'Y' ELSE 'N' END AS policy_yn from app.tpa_group_profile_details_spr a where a.grp_prof_seq_id=?";
	@Override
	public String getClientName(String countyval) throws Exception {
		
		String result="";
		try(Connection con = dataSource.getConnection();
				PreparedStatement pStmtObject = con.prepareStatement(strpropsalcounty);){
			pStmtObject.setString(1,countyval);
			
			try(ResultSet rs = pStmtObject.executeQuery();){
				if(rs != null){
					while(rs.next())
					{
						
						result=	UXUtility.checkNull(rs.getString("units_per_qar"));
					}//end of while(rs.next())
				}
			}
			
		}
				
							       					
		return result;
	}
	
	

	@Override
	public SwFinalQuoteVO getfalgPricingvalue(Long group_seq_id)throws Exception {
		Connection conn = null;
        PreparedStatement pStmt = null;
       
        SwFinalQuoteVO  swFinalQuoteVO =new SwFinalQuoteVO();
		try (Connection con = dataSource.getConnection();
				CallableStatement cStmtObject = (java.sql.CallableStatement) con.prepareCall(strPropsalFlag);) {
			cStmtObject.setLong(1,group_seq_id);
	           try(ResultSet rs = cStmtObject.executeQuery();){
	            if(rs != null){
	                while(rs.next()){
	                	swFinalQuoteVO =  new SwFinalQuoteVO();
	                	swFinalQuoteVO.setGroupseqid(group_seq_id);
	                	swFinalQuoteVO.setAddtionalflag(UXUtility.checkNull(rs.getString("additnl_benf_save_yn")));
	                	swFinalQuoteVO.setGenratepropsalflag(UXUtility.checkNull(rs.getString("genrate_proposal_yn")));
	                	swFinalQuoteVO.setApprovalYN(UXUtility.checkNull(rs.getString("prpsl_send_apprvl_yn")));
	                	swFinalQuoteVO.setRejectYN(UXUtility.checkNull(rs.getString("prpsl_acpy_rjct_yn")));
	                	swFinalQuoteVO.setPolicynumber(UXUtility.checkNull(rs.getString("policy_number")));
	                	swFinalQuoteVO.setPolicyflag(UXUtility.checkNull(rs.getString("policy_yn")));
	                	
	                	
	                
	                }//end of while(rs.next())
	            }//end of if(rs != null)
	           }
	           
	        }//end of try
			
		 return swFinalQuoteVO;
	
	}
		
	
@Autowired
private DataSource dataSource;



@Override
public int getsave(ArrayList formvalues) throws Exception {
	int iResult;
	try (Connection con = dataSource.getConnection();
			CallableStatement cStmtObject = (java.sql.CallableStatement) con.prepareCall(strsavePropsal);) {
		if( formvalues.get(0) != null){
			 cStmtObject.setLong(1,(long)formvalues.get(0));
		}else{
			 cStmtObject.setLong(1,0);
		}
	    cStmtObject.setLong(2,(long) formvalues.get(1));
	  /*  cStmtObject.setString(3,null);*/
	    cStmtObject.setString(3,null);
	    cStmtObject.setLong(4,(long) formvalues.get(4));
	    cStmtObject.setString(5,null);
	   /* cStmtObject.setString(7,null);*/
	    cStmtObject.setString(6,null);
	    cStmtObject.setString(7,null);
	    cStmtObject.setString(8,"Y");
	    cStmtObject.setString(9,(String) formvalues.get(5));
	    cStmtObject.setString(10,null);
	    cStmtObject.setString(11,(String) formvalues.get(2));
	    cStmtObject.setDouble(12, (double) formvalues.get(3));
	    cStmtObject.registerOutParameter(13,Types.INTEGER);
	    cStmtObject.execute();
	    iResult = cStmtObject.getInt(13);
	// TODO Auto-generated method stub
	  
}
	  return iResult;
		
}



@Override
public SwFinalQuoteVO getdetails(SwFinalQuoteVO swFinalQuoteVO)
		throws Exception {
	try (Connection con = dataSource.getConnection();
			CallableStatement cStmtObject = (java.sql.CallableStatement) con.prepareCall("{CALL PRICING_APP_PKG.select_pol_copies(?,?)}");) {
		if(swFinalQuoteVO.getPricingseqid() != null){
			
			cStmtObject.setLong(1,swFinalQuoteVO.getPricingseqid());}
		else{
			cStmtObject.setLong(1,0);
		}
		cStmtObject.registerOutParameter(2,OracleTypes.CURSOR);
		cStmtObject.execute(); 
		
		try(ResultSet rs = (java.sql.ResultSet)cStmtObject.getObject(2);){
				while(rs.next())
				{
					
					swFinalQuoteVO.setPropsalseqid(new Long(rs.getLong("pol_cpy_seq_id")));
					swFinalQuoteVO.setCurrencyconvesrion(UXUtility.checkNull(rs.getString("currency_code")));
					swFinalQuoteVO.setCurrencyvalue(UXUtility.checkNull(rs.getString("currecy_rate")));
				
					
				}
			
		}
	}
	
	return swFinalQuoteVO;
}



@Override
public int getsavepolicynumber(ArrayList formvalues) throws Exception {
	ArrayList<Object> alResultList = new ArrayList<Object>();
	    int iResult =0;
	  //ResultSet rs = null;
	
	try (Connection con = dataSource.getConnection();
			CallableStatement cStmtObject = (java.sql.CallableStatement) con.prepareCall(strpolicynumber);) {
		
		
	    cStmtObject.setLong(1,(Long) formvalues.get(0));
	    cStmtObject.setString(2,(String) formvalues.get(1));
	    cStmtObject.setLong(3,(Long) formvalues.get(2));
	    cStmtObject.registerOutParameter(4,Types.INTEGER);
	    cStmtObject.execute();
	    iResult = cStmtObject.getInt(4);
	// TODO Auto-generated method stub
	  
}
	  return iResult;
}
}

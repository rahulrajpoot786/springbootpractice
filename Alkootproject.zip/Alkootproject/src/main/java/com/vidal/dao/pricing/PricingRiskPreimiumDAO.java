package com.vidal.dao.pricing;

import java.util.ArrayList;

import com.vidal.command.pricing.InsPricingVO;
import com.vidal.command.pricing.SwPolicyConfigVO;

public interface PricingRiskPreimiumDAO {

	public InsPricingVO getfalgPricingvalue(long lpricingSeqId) throws Exception;
	
	public ArrayList getdemographicData(InsPricingVO insPricingVO,String demographicDataFlag)  throws Exception;
	
	 public ArrayList getcpmAfterCalcultion(InsPricingVO insPricingVO)  throws Exception;
	 
	 public ArrayList getcpmBeforeCalcultion(InsPricingVO insPricingVO) throws Exception;
	 
	 public ArrayList getAfterLoadingData(InsPricingVO insPricingVO) throws Exception;
	 
	 public ArrayList getBeforeLoadingData(InsPricingVO insPricingVO) throws Exception;
	 
	 public SwPolicyConfigVO getcpmAfterLoading(InsPricingVO insPricingVO) throws Exception;
	 
	 public ArrayList calculatePlanDesignConfig(SwPolicyConfigVO swpolicyConfigVO,Long userSeqId)throws Exception;
	 
	 public ArrayList saveDemographicData(SwPolicyConfigVO swpolicyConfigVO,Long userSeqId) throws Exception;
	 
	 public ArrayList calRateCalculationFnl(SwPolicyConfigVO swpolicyConfigVO,Long userSeqId) throws Exception;
	 
	 public void rateCalcProjClm(Long groupSeqId) throws Exception; 
	 
	 public int saveRiskClaimCostComment(String comment,Long groupSeqId)throws Exception;
	 
	 public SwPolicyConfigVO getComment(Long groupSeqId) throws Exception;
	 
	 public String getGetProposed(Long groupSeqId) throws Exception;
	 
}


package com.vidal.controllers;

import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.dom4j.io.SAXReader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.vidal.command.common.IconObject;
import com.vidal.command.common.Toolbar;
import com.vidal.command.usermanagement.UserSecurityProfile;
import com.vidal.command.usermanagement.UserVO;
import com.vidal.common.UXUtility;
import com.vidal.common.VidalCommon;
import com.vidal.common.controller.vidalcontroller.VidalController;
import com.vidal.common.security.SecurityProfile;
import com.vidal.services.authentication.AuthenticationService;


/**
 * This program demonstrates login page
 * 
 *
 * @author sangamesh
 *
 */
@Controller
public class HomeController extends  VidalController{
	
	private static final Logger logger = LoggerFactory.getLogger(HomeController.class);
	
	/**
	 * login validation will done here
	 * @param userVO
	 * @param locale
	 * @param model
	 * @param request
	 * @return forwarded jsp 
	 * @throws Exception
	 */
	@RequestMapping(value = {"/home"}, method = {RequestMethod.GET,RequestMethod.POST}) 
	public String home(@Valid @ModelAttribute("userVO") UserVO userVO,BindingResult result,Locale locale, Model model, HttpServletRequest request) throws Exception{
		logger.debug("Welcome home! The client locale is {}.", locale);
		String viewname = request.getServletPath();
		ModelAndView modelAndView = new ModelAndView(viewname);
		setErrorPageData("login",model);
		if(result.hasErrors())
		{
			
			return "login";
		}
		
		Date date = new Date(); 
		DateFormat dateFormat = DateFormat.getDateTimeInstance(DateFormat.LONG, DateFormat.LONG, locale);
		String formattedDate = dateFormat.format(date);
		model.addAttribute("serverTime", formattedDate );
		//UserVO userVO = new UserVO();
		String user = request.getParameter("username");
		String pwd = request.getParameter("pwd");
		userVO.setUSER_ID(user); //VIJA79031  Vijaya@123
        userVO.setPassword(pwd);//agk
        logger.info(user+"  ************************** "+pwd);
        userVO.setHostIPAddress(request.getRemoteHost());
        userVO.setLocalIPAddress(request.getLocalAddr());	

//		SAXReader reader = new SAXReader();

		request.getSession().removeAttribute("userAccessSecurityProfile");
		
		UserSecurityProfile userAccessSecurityProfile = authenticationServiceImpl.doAuthentication(userVO);
		
		
		request.getSession().setAttribute("userAccessSecurityProfile", userAccessSecurityProfile);
		userAccessSecurityProfile.getSecurityProfile().setDefaultActiveLink(); 
//		userAccessSecurityProfile.getSecurityProfile().set

        String strLink = ((UserSecurityProfile)request.getSession().getAttribute("userAccessSecurityProfile")).getSecurityProfile().getActiveLink()+"."+((UserSecurityProfile)request.getSession().getAttribute("userAccessSecurityProfile")).getSecurityProfile().getActiveSubLink()+"."+((UserSecurityProfile)request.getSession().getAttribute("userAccessSecurityProfile")).getSecurityProfile().getActiveTab();         
        setLinks(request);   
        this.loadToolBar(request,strLink);
        
		String frdpath = VidalCommon.getActiveLink(request)+"/"+VidalCommon.getActiveTab(request); 
		
		
		String isdebug = UXUtility.checkNullAndTrim(request.getParameter("isdebug"));
		
		if("isdebugtrue".equals(isdebug))request.getSession().setAttribute("WS_RC", "true");
		else request.getSession().setAttribute("WS_RC", "true");
		
		//System.out.println("KKK:"+new UserSecurityProfile().getSecurityProfile().getTabs());
		
		return "forward:PricingDashboard/doDefault"; //home
	}
	
	@RequestMapping(value = "/emp/get/{id}", method = RequestMethod.GET)
	public String getEmployee(Locale locale, Model model,@PathVariable("id") int id) {
		logger.debug("Welcome user! Requested Emp ID is: "+id);
		Date date = new Date();
		DateFormat dateFormat = DateFormat.getDateTimeInstance(DateFormat.LONG, DateFormat.LONG, locale);
		
		String formattedDate = dateFormat.format(date);
		
		model.addAttribute("serverTime", formattedDate );
		model.addAttribute("id", id);
		model.addAttribute("name", "Pankaj");
		
		return "employee";
	}
	/**
	 * login page will come
	 * @param request
	 * @param model
	 * @param userVO
	 * @return
	 */
	@RequestMapping(value="/login")
	public String login(HttpServletRequest request, Model model,@ModelAttribute("userVO") UserVO userVO){
		return "login";
	}
	
	/**
	 * logout will happen
	 * @param model
	 * @param request
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/logout")
	public String doLogout(Model model,HttpServletRequest request) throws Exception{
		
	
		 if(request.getSession().getAttribute("userAccessSecurityProfile")!=null)
         {
		int iResult = authenticationServiceImpl.doLogout(VidalCommon.getUserID(request));
		if(iResult > 0) logger.info(" logout succeful ");
		if(request.getSession(false)!=null)  //invalidate the session
        {
			request.getSession().removeAttribute("userAccessSecurityProfile");
		request.getSession().setAttribute("userAccessSecurityProfile",null);
		request.setAttribute(GLOBAL_ERROR,"Logout succesfully.");
        	//request.getSession().invalidate();
        }
		
         }
		
		model.addAttribute("userVO", new UserVO());
		return "login";
	}
	
	@RequestMapping(value="/denied")
	public String denied(){
		return "denied";
	}
	/**
	 * All request will handle by this
	 * @param locale
	 * @param model
	 * @param request
	 * @return
	 */
	@RequestMapping(value = {"/"}, method = RequestMethod.GET)
	public String welcome(Locale locale, Model model, HttpServletRequest request) {
		logger.info("Welcome home! The client locale is {}.", locale);
		Date date = new Date();
		DateFormat dateFormat = DateFormat.getDateTimeInstance(DateFormat.LONG, DateFormat.LONG, locale);
		 
		String formattedDate = dateFormat.format(date);
		UserVO userVO=new UserVO();
		
		model.addAttribute("serverTime", formattedDate );
		model.addAttribute("userVO", userVO);
		return "login";
	}
	
	

	private void loadToolBar(HttpServletRequest request, String strLink)
	{
		/*Toolbar toolBar = null;
		toolBar = new Toolbar();
		request.getSession().setAttribute("toolbar", toolBar); //set the tool bar to the session
		*/
		Toolbar toolBar = null;
        IconObject conflictIcon = new IconObject();
        conflictIcon.setImageURL("ErrorIcon");
        IconObject docViewIcon = new IconObject();
        docViewIcon.setImageURL("DocViewIcon");

        toolBar = new Toolbar(conflictIcon, docViewIcon, strLink);
        request.getSession().setAttribute("toolbar", toolBar); //set the tool bar to the session
	}
	
	@RequestMapping(value="/forwardpath", method = {RequestMethod.POST,RequestMethod.GET})
	String forwardPath(Model model,HttpServletRequest request)
	{
		request.setAttribute(GLOBAL_ERROR,"Your session has expired. Please re-login.");
		/*AuthenticationVO authenticationVO = new AuthenticationVO();
        model.addAttribute("authenticationVO", authenticationVO);
        model.addAttribute("memberVO", new MemberVO());*/
		model.addAttribute("userVO", new UserVO());
		return "login";
		//return "redirect:/profileview.htm";
		//return "redirect:profileview.htm";
	}
	@Autowired
	AuthenticationService authenticationServiceImpl;
	
	
	
	
	
}

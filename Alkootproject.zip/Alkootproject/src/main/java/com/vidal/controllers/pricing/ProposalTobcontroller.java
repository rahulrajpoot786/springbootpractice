package com.vidal.controllers.pricing;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.sql.DataSource;

import net.sf.jasperreports.engine.JREmptyDataSource;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.itextpdf.text.log.SysoCounter;
import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.pdf.PdfContentByte;
import com.lowagie.text.pdf.PdfImportedPage;
import com.lowagie.text.pdf.PdfReader;
import com.lowagie.text.pdf.PdfWriter;
import com.reports.TTKReportDataSource;
import com.vidal.command.common.CacheObject;
import com.vidal.command.pricing.DashboardVO;
import com.vidal.command.pricing.InsPricingVO;
import com.vidal.command.pricing.SwFinalQuoteVO;
import com.vidal.command.usermanagement.UserSecurityProfile;
import com.vidal.common.UXUtility;
import com.vidal.common.VidalCommon;
import com.vidal.common.controller.vidalcontroller.VidalController;
import com.vidal.common.exception.GetErrorMessage;
import com.vidal.common.reports.TTKPropertiesReader;
import com.vidal.services.authentication.GrossService;
import com.vidal.services.authentication.PropsalTOBervice;
import com.vidal.services.pricing.PricingRiskPreimiumService;
@Controller
@RequestMapping("SoftwareInsurancePricing")

public class ProposalTobcontroller extends VidalController{
	
	@Autowired
	PropsalTOBervice propsalTOBservice;
	private static Logger logger = Logger.getLogger( ProposalTobcontroller.class );
	private static final String strPropsalPricing="pricing.Propsal";
	private static final String strTobPricing="pricing.TOB";
	private static final String strReportdisplay = "/binaryFile";
	
	@Autowired
	public PricingRiskPreimiumService pricingRiskPreimiumService;
	
	@RequestMapping(value ="Proposal", method = RequestMethod.POST)
	public ModelAndView doPropsalpricing(@ModelAttribute("SwFinalQuoteVO") SwFinalQuoteVO swFinalQuoteVO, HttpServletRequest request,
			HttpServletResponse response, HttpSession session, Model model) throws Exception {
		setLinks(request);
		ModelAndView modelAndView = new ModelAndView(strPropsalPricing);
		UserSecurityProfile userAccessSecurityProfile = (UserSecurityProfile) request.getSession().getAttribute("userAccessSecurityProfile");
		userAccessSecurityProfile.getSecurityProfile().setActiveTab("Proposal");

		
		
		String completeSaveYN = (String)request.getSession().getAttribute("completeSaveYN");
		if(completeSaveYN.equals("N"))
			 return new ModelAndView("failure","GLOBAL_ERROR",GetErrorMessage.getValue("error.pricing.complete.screen"));
		 request.setAttribute("lngGroupProfileSeqID",(Long) request.getSession().getAttribute("groupPricingSeqId"));
			long	GroupProfileSeqID=((Long) request.getSession().getAttribute("groupPricingSeqId"));
		
		InsPricingVO insPricingVO2  =  grossService.getfalgPricingvalue(GroupProfileSeqID);
		String loadingFlagYN = insPricingVO2.getLoadingFlagYN();
		 String calCPM_FlagYN = insPricingVO2.getCalCPMFlagYN();
		 String gross_calualtion=insPricingVO2.getGrossclaulation().trim();
		 if(calCPM_FlagYN.equals("N") || calCPM_FlagYN.equals("")){
				return new ModelAndView("failure","GLOBAL_ERROR",GetErrorMessage.getValue("error.pricing.complete.screen.riskpremium"));
			}
			InsPricingVO insPricingVO  = new InsPricingVO();
			 insPricingVO  =  pricingRiskPreimiumService.getfalgPricingvalue(GroupProfileSeqID);
			  
			  
			  if(insPricingVO.getCompleteSaveYNInSc2().equalsIgnoreCase("N") || insPricingVO.getCompleteSaveYNInSc2().equalsIgnoreCase("")) {
					 return new ModelAndView("failure","GLOBAL_ERROR",GetErrorMessage.getValue("error.pricing.complete.screen"));			
				}
			  if(gross_calualtion.equals("N") || gross_calualtion.equals("")){
					return new ModelAndView("failure","GLOBAL_ERROR",GetErrorMessage.getValue("error.pricing.complete.screen.gross"));
				}
		
		
		
		 SwFinalQuoteVO propsalflag  =  propsalTOBservice.getfalgPricingvalue(GroupProfileSeqID);
		 
		 modelAndView.addObject("Previwreportflag", propsalflag.getGenratepropsalflag());
		 model.addAttribute("propsal_Flag" , propsalflag.getGenratepropsalflag());
		 
		 if("N".equals(propsalflag.getAddtionalflag())){
			 return new ModelAndView("failure","GLOBAL_ERROR",GetErrorMessage.getValue("error.pricing.complete.additional.screen")); 
		 }
		  swFinalQuoteVO.setPricingseqid((Long)request.getSession().getAttribute("groupPricingSeqId"));
		  swFinalQuoteVO=propsalTOBservice.getdetails(swFinalQuoteVO);
		  if(swFinalQuoteVO.getPropsalseqid()==null){
			  swFinalQuoteVO.setCurrencyconvesrion("QAR");
			  swFinalQuoteVO.setCurrencyvalue("1");
		  }
		 
		 
		try{
		
		String[] identfierList = new String[] {"currency"}; 
        
		populateData(identfierList, "propsalDropdowns");
		
		swFinalQuoteVO.setAddedBy(VidalCommon.getUserSeqId(request));
		 modelAndView.addObject("SwFinalQuoteVO",swFinalQuoteVO);
		 modelAndView.addObject("seqid", swFinalQuoteVO.getPropsalseqid());
			
		 
		 
return modelAndView;
	}
		catch(Throwable throwable){
			return processErrorView(strPropsalPricing, throwable);
		}
	}
	@Autowired
	GrossService grossService;
	
	@RequestMapping(value = {"getval"},method={RequestMethod.POST})
	public ModelAndView  getcurrencyvaluecounty(@ModelAttribute("SwFinalQuoteVO") SwFinalQuoteVO swFinalQuoteVO,@RequestParam("countyval") String Countrycode, HttpServletRequest  request,HttpServletResponse response) throws Exception{
		ModelAndView modelAndView = new ModelAndView(strPropsalPricing);	
		String countycurrency="";
		  ArrayList<CacheObject> alPricingUnderWrittingList= null;
		  StringBuilder sb= new StringBuilder();
		  
		try {
			
			 
		countycurrency = propsalTOBservice.getClientName(Countrycode);
		swFinalQuoteVO.setCurrencyvalue(countycurrency);
		  request.setAttribute("lngGroupProfileSeqID",(Long) request.getSession().getAttribute("groupPricingSeqId"));

		}catch(Throwable throwable){
			return processErrorView(strPropsalPricing, throwable);
		}
		     
		modelAndView.addObject("SwFinalQuoteVO",swFinalQuoteVO);	
		  return modelAndView;
		 
	}
	@RequestMapping(value = {"Policysave" },  method = { RequestMethod.GET, RequestMethod.POST })
	public ModelAndView dopolicysave(@ModelAttribute("SwFinalQuoteVO") SwFinalQuoteVO swFinalQuoteVO, HttpServletRequest request,
		 HttpServletResponse response, Model model) throws Exception {
		ModelAndView modelAndView = new ModelAndView(strTobPricing);
		 int propsalflag=0;
		  try{
			  Long GroupProfileSeqID=(Long)request.getSession().getAttribute("groupPricingSeqId");
			  ArrayList formvalues=new ArrayList<>();
			 
			  formvalues.add(GroupProfileSeqID);
			  formvalues.add(swFinalQuoteVO.getPolicynumber());
			  formvalues.add(VidalCommon.getUserSeqId(request));
			  int delete=	propsalTOBservice.getsavepolicynumber(formvalues);
				 SwFinalQuoteVO propsalflag1  =  propsalTOBservice.getfalgPricingvalue(GroupProfileSeqID);
				 modelAndView.addObject("Previwreportflag", propsalflag1.getGenratepropsalflag());
				 if("N" .equalsIgnoreCase(propsalflag1.getPolicyflag())){
					
					 request.getSession().setAttribute("diableflag","T");
						
					}else{
						request.getSession().setAttribute("diableflag","F" );
					}
			
				modelAndView.addObject("SwFinalQuoteVO", propsalflag1);
			  
		
			  return modelAndView;
			}
				catch(Throwable throwable){
					return processErrorView(strTobPricing, throwable);
				}
			}
	
	@RequestMapping(value = {"GenertaePropsalForm" },  method = { RequestMethod.GET, RequestMethod.POST })
	public ModelAndView doGenratepropsalform(@ModelAttribute("SwFinalQuoteVO") SwFinalQuoteVO swFinalQuoteVO,
			HttpServletRequest request, HttpServletResponse response, Model model) throws Exception {
		ModelAndView modelAndView = new ModelAndView(strPropsalPricing);
		 int propsalflag=0;
		  try{
			  Long GroupProfileSeqID=(Long)request.getSession().getAttribute("groupPricingSeqId");
			  ArrayList formvalues=new ArrayList<>();
			  formvalues.add(swFinalQuoteVO.getPropsalseqid());
			  formvalues.add(GroupProfileSeqID);
			  formvalues.add(swFinalQuoteVO.getCurrencyconvesrion());
			  swFinalQuoteVO.setPricingseqid((Long)request.getSession().getAttribute("groupPricingSeqId"));
			
			double currenyvalue=Double.parseDouble(swFinalQuoteVO.getCurrencyvalue());  
			  formvalues.add(currenyvalue);
			  formvalues.add(VidalCommon.getUserSeqID(request));
			  if("Y".equals(request.getParameter("ApprovalYN").trim())){
				  formvalues.add("Y");
				}else{
					formvalues.add("N");
				}
			  
			   propsalflag  =  propsalTOBservice.getsave(formvalues);
			  if(propsalflag>0){
				
				  swFinalQuoteVO=propsalTOBservice.getdetails(swFinalQuoteVO);
				 
			  }
			
			  modelAndView.addObject("seqid", swFinalQuoteVO.getPropsalseqid());
				 SwFinalQuoteVO propsalflag1  =  propsalTOBservice.getfalgPricingvalue(GroupProfileSeqID);
				  modelAndView.addObject("Previwreportflag", propsalflag1.getGenratepropsalflag());
				 model.addAttribute("propsal_Flag" , propsalflag1.getGenratepropsalflag());
			  request.setAttribute("lngGroupProfileSeqID",(Long) request.getSession().getAttribute("groupPricingSeqId"));
				modelAndView.addObject("SwFinalQuoteVO", swFinalQuoteVO);
			  
		
			  return modelAndView;
			}
				catch(Throwable throwable){
					return processErrorView(strPropsalPricing, throwable);
				}
			}
	@RequestMapping(value = {"DownloadPropsalForm" },  method = { RequestMethod.GET, RequestMethod.POST })
	public ModelAndView doPropsalform(@ModelAttribute("SwFinalQuoteVO") SwFinalQuoteVO swFinalQuoteVO,
			HttpServletRequest request, HttpServletResponse response, Model model) throws Exception {
		ModelAndView modelAndView = new ModelAndView(strPropsalPricing);
		 int iNoOfCursor = 8;
			String shortDirectory = UXUtility.getPropertyValue("generalreports");
		 String jrxmlfile = shortDirectory + request.getParameter("fileName");
		 
		 JasperReport jasperReport[] =new JasperReport[iNoOfCursor];
		 JasperReport emptyReport;
		 JasperPrint jasperPrint[] = new JasperPrint[iNoOfCursor];
			
		 swFinalQuoteVO.setAddedBy((VidalCommon.getUserSeqId(request)));
		
		 String QuotationNo= "";
		 List<InputStream> fileData = new ArrayList<InputStream>();
		// long group_seq_id=(long)request.getSession().getAttribute("GroupProfileSeqID");
		 long group_seq_id=(long) request.getSession().getAttribute("groupPricingSeqId");
		 String strParameter = request.getParameter("parameter");
			emptyReport = JasperCompileManager.compileReport(""+shortDirectory+"/EmptyReprot.jrxml");
		 HashMap<String, Object> hashMap = new HashMap<String, Object>();

		 String jrxmlFiles[] = new String[]
              {
			
				 shortDirectory+"/quotation/GenerateQauotationfrontpage1.jrxml",
				 shortDirectory+"/quotation/GenerateQauotationpage2.jrxml",
				 shortDirectory+"/quotation/GenerateQauotationpage3.jrxml",
				 shortDirectory+"/quotation/GenerateQauotationpage4.jrxml",
				 shortDirectory+"/quotation/GenerateQauotationpage5.jrxml",
				 shortDirectory+"/quotation/GenerateQauotationpage6.jrxml",
				 shortDirectory+"/quotation/GenerateQauotationpage7.jrxml",
				 shortDirectory+"/quotation/GenerateQauotationpage8.jrxml",
                  };
		 try
		 {
			 
			 for(int i=0;i<iNoOfCursor;i++)
				{
				
			 ByteArrayOutputStream boasi=new ByteArrayOutputStream();// i is the number of cursors in boasi
			 				 
			 TTKReportDataSource ttkReportDataSource = new TTKReportDataSource(request.getParameter("reportID"),strParameter,dataSource);			
			 jasperReport[i] = JasperCompileManager.compileReport(jrxmlFiles[i]); 
			 if(ttkReportDataSource.getResultData().next()){
				 Date date = new Date();
					SimpleDateFormat fnDateFormat=new SimpleDateFormat("ddMMyyyyHHmmss");
					
				
				 QuotationNo =fnDateFormat.format(date); 
				 ttkReportDataSource.getResultData().beforeFirst();
				 jasperPrint[i] = JasperFillManager.fillReport(jasperReport[i], hashMap, ttkReportDataSource);
			 }
			 JasperExportManager.exportReportToPdfStream(jasperPrint[i],boasi);
			// JasperExportManager.exportReportToPdfFile(jasperPrint[i],"E:\\gurupdf.pdf");
			 ByteArrayInputStream isi = new ByteArrayInputStream(boasi.toByteArray());
			 //keep the byte array out stream in request scope to write in the BinaryStreamServlet
			 fileData.add(isi);// i is the number of cursors in isi
		 }
		 
		 String path=UXUtility.checkNull(TTKPropertiesReader.getPropertyValue("quotationdir"));
		 path = path+"QUO_"+QuotationNo+".pdf";

		 response.setContentType("application/pdf"); 
		 response.setHeader("Content-Disposition", "attachment;filename=\""+QuotationNo+"\".pdf");
			 ServletOutputStream servletOutputStream=response.getOutputStream();
		     doPdfMergeBytes(request,fileData,servletOutputStream);
			

			 servletOutputStream.flush();
			 servletOutputStream.close();
		 
	return null;
}//end of try
catch(Throwable throwable){
	return processErrorView(strPropsalPricing, throwable);
}
}
	@RequestMapping(value = {"PreviewProposalForm" },method = { RequestMethod.GET, RequestMethod.POST })
	public ModelAndView doPreviewPropsalform(@ModelAttribute("SwFinalQuoteVO") SwFinalQuoteVO swFinalQuoteVO,
	HttpServletRequest request, HttpServletResponse response, Model model) throws Exception {
	ModelAndView modelAndView = new ModelAndView(strPropsalPricing);
	int iNoOfCursor = 8;
	String shortDirectory = UXUtility.getPropertyValue("generalreports");
	String jrxmlfile = shortDirectory + request.getParameter("fileName");

	JasperReport jasperReport[] =new JasperReport[iNoOfCursor];
	JasperReport emptyReport;
	JasperPrint jasperPrint[] = new JasperPrint[iNoOfCursor];

	swFinalQuoteVO.setAddedBy((VidalCommon.getUserSeqId(request)));

	String QuotationNo= "";
	List<InputStream> fileData = new ArrayList<InputStream>();
	// long group_seq_id=(long)request.getSession().getAttribute("GroupProfileSeqID");
	long group_seq_id=(long) request.getSession().getAttribute("groupPricingSeqId");
	String strParameter = request.getParameter("parameter");
	emptyReport = JasperCompileManager.compileReport(""+shortDirectory+"/EmptyReprot.jrxml");
	HashMap<String, Object> hashMap = new HashMap<String, Object>();

	String jrxmlFiles[] = new String[]
	  {
		 shortDirectory+"/quotation/GenerateQauotationfrontpage1.jrxml",
		 shortDirectory+"/quotation/GenerateQauotationpage2.jrxml",
		 shortDirectory+"/quotation/GenerateQauotationpage3.jrxml",
		 shortDirectory+"/quotation/GenerateQauotationpage4.jrxml",
		 shortDirectory+"/quotation/GenerateQauotationpage5.jrxml",
		 shortDirectory+"/quotation/GenerateQauotationpage6.jrxml",
		 shortDirectory+"/quotation/GenerateQauotationpage7.jrxml",
		 shortDirectory+"/quotation/GenerateQauotationpage8.jrxml",
	      };
	try
	{
	 
	 for(int i=0;i<iNoOfCursor;i++)
		{
		
	 ByteArrayOutputStream boasi=new ByteArrayOutputStream();// i is the number of cursors in boasi
	 				 
	 TTKReportDataSource ttkReportDataSource = new TTKReportDataSource(request.getParameter("reportID"),strParameter,dataSource);			
	 jasperReport[i] = JasperCompileManager.compileReport(jrxmlFiles[i]); 
	 if(ttkReportDataSource.getResultData().next()){
		 Date date = new Date();
			SimpleDateFormat fnDateFormat=new SimpleDateFormat("ddMMyyyyHHmmss");
			
		
		 QuotationNo =fnDateFormat.format(date); 
		 ttkReportDataSource.getResultData().beforeFirst();
		 jasperPrint[i] = JasperFillManager.fillReport(jasperReport[i], hashMap, ttkReportDataSource);
	 }
	 JasperExportManager.exportReportToPdfStream(jasperPrint[i],boasi);
	// JasperExportManager.exportReportToPdfFile(jasperPrint[i],"E:\\gurupdf.pdf");
	 ByteArrayInputStream isi = new ByteArrayInputStream(boasi.toByteArray());
	 //keep the byte array out stream in request scope to write in the BinaryStreamServlet
	 fileData.add(isi);// i is the number of cursors in isi
	}

	String path=UXUtility.checkNull(TTKPropertiesReader.getPropertyValue("quotationdir"));
	path = path+"QUO_"+QuotationNo+".pdf";

	//response.setContentType("application/pdf"); 
	//response.setHeader("Content-Disposition", "attachment;filename=\""+QuotationNo+"\".pdf");
	 ServletOutputStream servletOutputStream=response.getOutputStream();
	 doPdfMergeBytes(request,fileData,servletOutputStream);


	 servletOutputStream.flush();
	 servletOutputStream.close();

	return null;
	}//end of try
	catch(Throwable throwable){
	return processErrorView(strPropsalPricing, throwable);
	}
	}
	
	
	  public static void doPdfMergeBytes(HttpServletRequest request,List<InputStream> list, OutputStream outputStream){

	        Document document = new Document();
	       try{

	        PdfWriter writer = PdfWriter.getInstance(document, outputStream);
	        writer.open();
	        document.open();
	        PdfContentByte cb = writer.getDirectContent();

	        for (InputStream inputStream : list) {
	            PdfReader reader = new PdfReader(inputStream);
	          
	            for (int i = 1; i <=reader.getNumberOfPages(); i++){
	                document.newPage();
	                //import the page from source pdf
	                PdfImportedPage page = writer.getImportedPage(reader, i);
	                //add the page to the destination pdf
	                cb.addTemplate(page, 0, 0);
	            }//end of for (int i = 1; i <=reader.getNumberOfPages(); i++)
	        }//end of for (InputStream inputStream : list)
	       }//end of try
	       catch(Exception exception){
	           logger.error("PDF merging some Problem Occured "+exception);;
	       }//end of catch(Exception exception){
	       finally{
	        if(document != null)document.close();
	          
	       }//end of finally

	   }//end of public static void doPdfMerge(HttpServletRequest request,List<InputStream> list, OutputStream outputStream)

	    
	    
    
    public static void doMergePDF(List<InputStream> list, OutputStream outputStream)
			throws DocumentException, IOException {
				Document document = new Document();
				PdfWriter writer = PdfWriter.getInstance(document, outputStream);
				writer.open();
				document.open();

				PdfContentByte cb = writer.getDirectContent();
			
				for (InputStream in : list) {
				
					PdfReader reader = new PdfReader(in);
					
					for (int i = 1; i <=reader.getNumberOfPages(); i++) {
						
						document.newPage();
						//import the page from source pdf
						PdfImportedPage page = writer.getImportedPage(reader, i);
						//add the page to the destination pdf
						cb.addTemplate(page, 0, 0);
					}
				}
				outputStream.flush();
				document.close();
				outputStream.close();
			}

	
	@RequestMapping(value ="TOB", method = RequestMethod.POST)
	public ModelAndView doTobpricing(@ModelAttribute("SwFinalQuoteVO") SwFinalQuoteVO swFinalQuoteVO, HttpServletRequest request,
			HttpServletResponse response, HttpSession session, Model model) throws Exception {
		setLinks(request);
		UserSecurityProfile userAccessSecurityProfile = (UserSecurityProfile) request.getSession().getAttribute("userAccessSecurityProfile");
		userAccessSecurityProfile.getSecurityProfile().setActiveTab(request.getParameter("submenulink"));
		
		ModelAndView modelAndView = new ModelAndView(strTobPricing);
		String completeSaveYN = (String)request.getSession().getAttribute("completeSaveYN");
		if(completeSaveYN.equals("N"))
			 return new ModelAndView("failure","GLOBAL_ERROR",GetErrorMessage.getValue("error.pricing.complete.screen"));	
		long	GroupProfileSeqID=((Long) request.getSession().getAttribute("groupPricingSeqId"));
		 SwFinalQuoteVO propsalflag  =  propsalTOBservice.getfalgPricingvalue(GroupProfileSeqID);
		if("N".equalsIgnoreCase(propsalflag.getGenratepropsalflag()))
			 return new ModelAndView("failure","GLOBAL_ERROR",GetErrorMessage.getValue("error.pricing.complete.propsal.screen"));	
	
		 request.setAttribute("lngGroupProfileSeqID",(Long) request.getSession().getAttribute("groupPricingSeqId"));
		
		
		 modelAndView.addObject("Previwreportflag", propsalflag.getGenratepropsalflag());
		 model.addAttribute("propsal_Flag" , propsalflag.getGenratepropsalflag());
		// SwFinalQuoteVO propsalflag1  =  propsalTOBservice.getfalgPricingvalue(GroupProfileSeqID);
		 if("N" .equalsIgnoreCase(propsalflag.getPolicyflag())){
			 request.getSession().setAttribute("diableflag","T");
				
			}else{
				request.getSession().setAttribute("diableflag","F" );
			}
	  
	
		modelAndView.addObject("SwFinalQuoteVO", propsalflag);
		 
		 if("N".equals(propsalflag.getAddtionalflag())){
			 return new ModelAndView("failure","GLOBAL_ERROR",GetErrorMessage.getValue("error.pricing.complete.additional.screen")); 
		 }
		 InsPricingVO insPricingVO  = new InsPricingVO();
		 insPricingVO  =  pricingRiskPreimiumService.getfalgPricingvalue(GroupProfileSeqID);
		  
		  
		  if(insPricingVO.getCompleteSaveYNInSc2().equalsIgnoreCase("N") || insPricingVO.getCompleteSaveYNInSc2().equalsIgnoreCase("")) {
				 return new ModelAndView("failure","GLOBAL_ERROR",GetErrorMessage.getValue("error.pricing.complete.screen"));			
			}
	
		//dashboardVO.setPricingnumber((String) request.getSession().getAttribute("pricingRefNo"));
	
		InsPricingVO insPricingVO2  =  grossService.getfalgPricingvalue(GroupProfileSeqID);
		String loadingFlagYN = insPricingVO2.getLoadingFlagYN();
		 String calCPM_FlagYN = insPricingVO2.getCalCPMFlagYN();
		 String gross_calualtion=insPricingVO2.getGrossclaulation().trim();
		
		 if(gross_calualtion.equals("N") || gross_calualtion.equals("")){
				return new ModelAndView("failure","GLOBAL_ERROR",GetErrorMessage.getValue("error.pricing.complete.screen.gross"));
			}
		 if(calCPM_FlagYN.equals("N") || calCPM_FlagYN.equals("")){
				return new ModelAndView("failure","GLOBAL_ERROR",GetErrorMessage.getValue("error.pricing.complete.screen.riskpremium"));
			}
		  request.setAttribute("lngGroupProfileSeqID", request.getSession().getAttribute("groupPricingSeqId"));
		
	
		
return modelAndView;
    	
	}
/*	@RequestMapping(value = {"TobReport"},  method = { RequestMethod.GET, RequestMethod.POST })
	public ModelAndView doGenerateXmlReport(@ModelAttribute("DashboardVO") DashboardVO dashboardVO,
			HttpServletRequest request, HttpServletResponse response, Model model) throws Exception {
		ModelAndView modelAndView = new ModelAndView(strTobPricing);

		JasperReport jasperReport, xmljasperReport, emptyReport;
		JasperPrint jasperPrint;
		String strPath = "";
		 ResultSet rs = null; 
		String shortDirectory = UXUtility.getPropertyValue("generalreports");
		String strPdfFile = TTKPropertiesReader.getPropertyValue("shortfallrptdir")
				+ request.getParameter("lngprofileseqid") + ".pdf";
		

		TTKReportDataSource ttkReportDataSource = null;


	
		emptyReport = JasperCompileManager.compileReport("" + shortDirectory + "/EmptyReprot.jrxml");
		String jrxmlfile = shortDirectory + request.getParameter("fileName");
		try {
                jasperReport = JasperCompileManager.compileReport(jrxmlfile);
			
			xmljasperReport = JasperCompileManager.compileReport("" + shortDirectory + "/TOB.jrxml");
			HashMap<String, Object> hashMap = new HashMap<String, Object>();
			ByteArrayOutputStream boas = new ByteArrayOutputStream();
			ttkReportDataSource = new TTKReportDataSource(request.getParameter("reportID"),request.getParameter("parameter"),dataSource);
			  rs = ttkReportDataSource.getResultData(); 
			  if(rs.next())
              {
                  rs.beforeFirst(); 
                  jasperReport = JasperCompileManager.compileReport(jrxmlfile);
                  jasperPrint = JasperFillManager.fillReport(jasperReport, hashMap, ttkReportDataSource);
              }
              else
              {
                  jasperPrint = JasperFillManager.fillReport(emptyReport,hashMap, new JREmptyDataSource());
              }
				
				//JasperExportManager.exportReportToPdfFile(jasperPrint, strPdfFile);
				response.setContentType("application/pdf"); 
	              response.setHeader("Content-Disposition", "attachment;filename=TOB.pdf");
	              ServletOutputStream servletOutputStream=response.getOutputStream();
	              JasperExportManager.exportReportToPdfStream(jasperPrint, servletOutputStream);
	              boas.writeTo(servletOutputStream);
	              boas.flush();
	              servletOutputStream.flush();
	              servletOutputStream.close();
			
			return null;
	}//end of try
	catch(Throwable throwable){
		return processErrorView(strTobPricing, throwable);
	}

		return "forward:/" + strReportdisplay + "";
	}
	*/
	@RequestMapping(value = {"TobReport"},  method = { RequestMethod.GET, RequestMethod.POST })
	public ModelAndView doGenerateXmlReport(@ModelAttribute("DashboardVO") DashboardVO dashboardVO,
			HttpServletRequest request, HttpServletResponse response, Model model) throws Exception {
		ModelAndView modelAndView = new ModelAndView(strTobPricing);

		//JasperReport jasperReport, xmljasperReport, emptyReport;
		//JasperPrint jasperPrint;
		int iNoOfCursor = 13;
		String strPath = "";
		 ResultSet rs = null; 
		String shortDirectory = UXUtility.getPropertyValue("generalreports");
		String strPdfFile = TTKPropertiesReader.getPropertyValue("shortfallrptdir")
				+ request.getParameter("lngprofileseqid") + ".pdf";
				JasperReport jasperReport[] =new JasperReport[iNoOfCursor];
	JasperReport emptyReport;
	JasperPrint jasperPrint[] = new JasperPrint[iNoOfCursor];

	//swFinalQuoteVO.setAddedBy((VidalCommon.getUserSeqId(request)));
    String QuotationNo= "";
	List<InputStream> fileData = new ArrayList<InputStream>();
	// long group_seq_id=(long)request.getSession().getAttribute("GroupProfileSeqID");
	long group_seq_id=(long) request.getSession().getAttribute("groupPricingSeqId");
	String strParameter = request.getParameter("parameter");
	emptyReport = JasperCompileManager.compileReport(""+shortDirectory+"/EmptyReprot.jrxml");
	HashMap<String, Object> hashMap = new HashMap<String, Object>();
	String jrxmlFiles[] = new String[]
	  {
		 shortDirectory+"/TOB/TOB1.jrxml",
		 shortDirectory+"/TOB/TOB2.jrxml",
		 shortDirectory+"/TOB/TOB3.jrxml",
		 shortDirectory+"/TOB/TOB4.jrxml",
		 shortDirectory+"/TOB/TOB5.jrxml",
		 shortDirectory+"/TOB/TOB6.jrxml",
		 shortDirectory+"/TOB/TOB7.jrxml",
		 shortDirectory+"/TOB/TOB8.jrxml",
		 shortDirectory+"/TOB/TOB9.jrxml",
		 shortDirectory+"/TOB/TOB10.jrxml",
		 shortDirectory+"/TOB/TOB11.jrxml",
		 shortDirectory+"/TOB/TOB12.jrxml",
		 shortDirectory+"/TOB/TOB13.jrxml",
		 
		
	      };
	try
	{
	 
	 for(int i=0;i<iNoOfCursor;i++)
		{
		
	 ByteArrayOutputStream boasi=new ByteArrayOutputStream();// i is the number of cursors in boasi
	 				 
	 TTKReportDataSource ttkReportDataSource = new TTKReportDataSource(request.getParameter("reportID"),strParameter,dataSource);			
	 jasperReport[i] = JasperCompileManager.compileReport(jrxmlFiles[i]); 
	 if(ttkReportDataSource.getResultData().next()){
		 Date date = new Date();
			SimpleDateFormat fnDateFormat=new SimpleDateFormat("ddMMyyyyHHmmss");
			
		
		 QuotationNo =fnDateFormat.format(date); 
		 ttkReportDataSource.getResultData().beforeFirst();
		 jasperPrint[i] = JasperFillManager.fillReport(jasperReport[i], hashMap, ttkReportDataSource);
	 }
	 JasperExportManager.exportReportToPdfStream(jasperPrint[i],boasi);
	// JasperExportManager.exportReportToPdfFile(jasperPrint[i],"E:\\gurupdf.pdf");
	 ByteArrayInputStream isi = new ByteArrayInputStream(boasi.toByteArray());
	 //keep the byte array out stream in request scope to write in the BinaryStreamServlet
	 fileData.add(isi);// i is the number of cursors in isi
	}
	 String path=UXUtility.checkNull(TTKPropertiesReader.getPropertyValue("quotationdir"));
	 path = "TOB.pdf";
	 

	 response.setContentType("application/pdf"); 
	response.setHeader("Content-Disposition", "attachment;filename=\""+QuotationNo+"\".pdf");
		 ServletOutputStream servletOutputStream=response.getOutputStream();
	     doPdfMergeBytes(request,fileData,servletOutputStream);
	 servletOutputStream.flush();
	 servletOutputStream.close();
 
return null;
}//end of try
catch(Throwable throwable){
return processErrorView(strPropsalPricing, throwable);
}
}
	
	@RequestMapping(value = {"TobPreviewReport"},  method = { RequestMethod.GET, RequestMethod.POST })
	public  ModelAndView doPreviewGenerateXmlReport(@ModelAttribute("DashboardVO") DashboardVO dashboardVO,
			HttpServletRequest request, HttpServletResponse response, Model model) throws Exception {
		ModelAndView modelAndView = new ModelAndView(strTobPricing);
		//JasperReport jasperReport, xmljasperReport, emptyReport;
		//JasperPrint jasperPrint;
		int iNoOfCursor = 13;
		String strPath = "";
		 ResultSet rs = null; 
		String shortDirectory = UXUtility.getPropertyValue("generalreports");
		String strPdfFile = TTKPropertiesReader.getPropertyValue("shortfallrptdir")
				+ request.getParameter("lngprofileseqid") + ".pdf";
				JasperReport jasperReport[] =new JasperReport[iNoOfCursor];
	JasperReport emptyReport;
	JasperPrint jasperPrint[] = new JasperPrint[iNoOfCursor];

	//swFinalQuoteVO.setAddedBy((VidalCommon.getUserSeqId(request)));
    String QuotationNo= "";
	List<InputStream> fileData = new ArrayList<InputStream>();
	// long group_seq_id=(long)request.getSession().getAttribute("GroupProfileSeqID");
	long group_seq_id=(long) request.getSession().getAttribute("groupPricingSeqId");
	String strParameter="|"+request.getSession().getAttribute("groupPricingSeqId")+"|"+VidalCommon.getUserSeqId(request) +"|";
	emptyReport = JasperCompileManager.compileReport(""+shortDirectory+"/EmptyReprot.jrxml");
	HashMap<String, Object> hashMap = new HashMap<String, Object>();
	String jrxmlFiles[] = new String[]
	  {
		 shortDirectory+"/TOB/TOB1.jrxml",
		 shortDirectory+"/TOB/TOB2.jrxml",
		 shortDirectory+"/TOB/TOB3.jrxml",
		 shortDirectory+"/TOB/TOB4.jrxml",
		 shortDirectory+"/TOB/TOB5.jrxml",
		 shortDirectory+"/TOB/TOB6.jrxml",
		 shortDirectory+"/TOB/TOB7.jrxml",
		 shortDirectory+"/TOB/TOB8.jrxml",
		 shortDirectory+"/TOB/TOB9.jrxml",
		 shortDirectory+"/TOB/TOB10.jrxml",
		 shortDirectory+"/TOB/TOB11.jrxml",
		 shortDirectory+"/TOB/TOB12.jrxml",
		 shortDirectory+"/TOB/TOB13.jrxml",
		 
		
	      };
	try
	{
	 
	 for(int i=0;i<iNoOfCursor;i++)
		{
		
	 ByteArrayOutputStream boasi=new ByteArrayOutputStream();// i is the number of cursors in boasi
	 				 
	 TTKReportDataSource ttkReportDataSource = new TTKReportDataSource(request.getParameter("reportID"),strParameter,dataSource);			
	 jasperReport[i] = JasperCompileManager.compileReport(jrxmlFiles[i]); 
	 if(ttkReportDataSource.getResultData().next()){
		 Date date = new Date();
			SimpleDateFormat fnDateFormat=new SimpleDateFormat("ddMMyyyyHHmmss");
			
		
		 QuotationNo =fnDateFormat.format(date); 
		 ttkReportDataSource.getResultData().beforeFirst();
		 jasperPrint[i] = JasperFillManager.fillReport(jasperReport[i], hashMap, ttkReportDataSource);
	 }
	 JasperExportManager.exportReportToPdfStream(jasperPrint[i],boasi);
	// JasperExportManager.exportReportToPdfFile(jasperPrint[i],"E:\\gurupdf.pdf");
	 ByteArrayInputStream isi = new ByteArrayInputStream(boasi.toByteArray());
	 //keep the byte array out stream in request scope to write in the BinaryStreamServlet
	 fileData.add(isi);// i is the number of cursors in isi
	}
	 String path=UXUtility.checkNull(TTKPropertiesReader.getPropertyValue("quotationdir"));
	 path = "TOB.pdf";

	// response.setContentType("application/pdf"); 
	 
	//response.setHeader("Content-Disposition", "attachment;filename=\""+QuotationNo+"\".pdf");
		 ServletOutputStream servletOutputStream=response.getOutputStream();
	     doPdfMergeBytes(request,fileData,servletOutputStream);
	 servletOutputStream.flush();
	 servletOutputStream.close();
	 modelAndView.addObject("servletOutputStream",servletOutputStream);
return null;
}//end of try
catch(Throwable throwable){
return processErrorView(strPropsalPricing, throwable);
}
}
		
	
	

	@Autowired
	private DataSource dataSource;
	
}
	



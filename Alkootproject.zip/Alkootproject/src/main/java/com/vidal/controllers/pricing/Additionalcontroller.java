package com.vidal.controllers.pricing;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.vidal.command.pricing.AdditionalVO;
import com.vidal.command.pricing.DashboardVO;
import com.vidal.command.pricing.InsPricingVO;
import com.vidal.command.usermanagement.UserSecurityProfile;
import com.vidal.common.PreAuthWebBoardHelper;
import com.vidal.common.UXUtility;
import com.vidal.common.VidalCommon;
import com.vidal.common.controller.vidalcontroller.VidalController;
import com.vidal.common.exception.GetErrorMessage;
import com.vidal.controllers.table.TableData;
import com.vidal.services.authentication.Additionalservice;
import com.vidal.services.authentication.DashboardGeneralService;
import com.vidal.services.authentication.GrossService;
import com.vidal.services.pricing.PricingRiskPreimiumService;

import org.apache.log4j.Logger;

import com.vidal.common.controller.vidalcontroller.VidalController;


@Controller
@RequestMapping("SoftwareInsurancePricing")




public class Additionalcontroller extends VidalController {
	@Autowired
	GrossService grossService;
	private static Logger logger = Logger.getLogger( Additionalcontroller.class );
	

	private static final String strAdditionalPricing="pricing.Additional";
	
	@RequestMapping(value ="AdditionalBenefits", method = RequestMethod.POST)
	public ModelAndView doAdditionalpricing(@ModelAttribute("additionalVO") AdditionalVO additionalVO, HttpServletRequest request,
			HttpServletResponse response, HttpSession session, Model model) throws Exception {
		setLinks(request);
		ModelAndView modelAndView = new ModelAndView(strAdditionalPricing);
		setErrorPageData(strAdditionalPricing, model);
		String completeSaveYN = (String)request.getSession().getAttribute("completeSaveYN");
		if(completeSaveYN.equals("N"))
			 return new ModelAndView("failure","GLOBAL_ERROR",GetErrorMessage.getValue("error.pricing.complete.screen"));	
	      long GroupProfileSeqID=((Long) request.getSession().getAttribute("groupPricingSeqId"));
		InsPricingVO insPricingVO2  =  grossService.getfalgPricingvalue(GroupProfileSeqID);
		String loadingFlagYN = insPricingVO2.getLoadingFlagYN();
		 String calCPM_FlagYN = insPricingVO2.getCalCPMFlagYN();
		 String gross_calualtion=insPricingVO2.getGrossclaulation().trim();
		 if(calCPM_FlagYN.equals("N") || calCPM_FlagYN.equals("")){
				return new ModelAndView("failure","GLOBAL_ERROR",GetErrorMessage.getValue("error.pricing.complete.screen.riskpremium"));
			}
			InsPricingVO insPricingVO  = new InsPricingVO();
		 insPricingVO  =  pricingRiskPreimiumService.getfalgPricingvalue(GroupProfileSeqID);
		  
		  
		  if(insPricingVO.getCompleteSaveYNInSc2().equalsIgnoreCase("N") || insPricingVO.getCompleteSaveYNInSc2().equalsIgnoreCase("")) {
				 return new ModelAndView("failure","GLOBAL_ERROR",GetErrorMessage.getValue("error.pricing.complete.screen"));			
			}
		  if(gross_calualtion.equals("N") || gross_calualtion.equals("")){
				return new ModelAndView("failure","GLOBAL_ERROR",GetErrorMessage.getValue("error.pricing.complete.screen.gross"));
			}

		try{
		String[] identfierList = new String[] {"inpatientroom","inpatientaccomdation","inpatientcash","Physiotherepy","outside","reimbursement",
				"Physiotherepysession","alternativecmplimit","internationalasslimit","psychiatrylimitt","psychiatcopayt",
				"vacationlimit","vacation","maintance","hormonelimit","inpatientt","PassiveWar","ExternalProsthesisdrop",
				"nursingdrop","Vitamins","Preandpostnatal","wellbeingbenfittdrop","workrelateddrop","externalmedicalcopay","organlimit","alternativecopay",
				"lifediseasecdrop","obesite","hospiceandPalliativedrop","ditecianlimitdrop","hIVandaIDSLimitdrop","workrelateddrop1","lifeThreateningdiease",
				"circumcisionlimitdrop","compassionatevisitdrop","approval",  "alternativesession","psllimit" ,"externalmedicaldrop","preexist","inpatientlimit",
				"healthscreenlimitdrop","parentacmdation","healthsessions","healthscreencopay","pregnancy","deductiblecoinsurance","dentalprothis","congtal","oncology",
				"repatriation","terminal","alternativeTreatment","reimbursmentLevel"};
		populateData(identfierList,"additionalscreen");
		additionalVO.setPricingno((Long) request.getSession().getAttribute("groupPricingSeqId"));
		
		additionalVO   =  additionalservice.getfalgPricingvalue(additionalVO);
		if("Y" .equalsIgnoreCase(additionalVO.getInpatntflag())){
			request.getSession().setAttribute("InPatientFlag","" );
		}else{
			request.getSession().setAttribute("InPatientFlag","inpatient" );
		}
		if("Y".equalsIgnoreCase(additionalVO.getRenewalYNadd())){
			modelAndView.addObject("renewal", "Y");
		}else{
			modelAndView.addObject("renewal", "N");
		}
		
		
		
		additionalVO.setPricingRefno((String) request.getSession().getAttribute("pricingRefNo"));
		
		
		additionalVO.setPricingno((Long) request.getSession().getAttribute("groupPricingSeqId"));
		additionalVO=additionalservice.getdetails(additionalVO);
		
		 if(additionalVO.getAdditionalseqId()==null && "N".equalsIgnoreCase(additionalVO.getRenewalYNadd()) ){
	           
	             additionalVO.setInpatientandDaycaretreatment("13");
	                additionalVO.setStrdiagnostics("Y");
	                additionalVO.setPrescribed("Y");
	                additionalVO.setDoctriaya("Y");
	                additionalVO.setPhysiotherapy("Y");
	                additionalVO.setPhysiotherepylimit("35");
	                additionalVO.setAlternativetreatment("Y");
	                additionalVO.setAlternativetreatmentlimit("60");
	                additionalVO.setAlternativecopay("70");
	                additionalVO.setPreexistingcoadtion("Y");
	                additionalVO.setPreexistingconditionslimit("84");
	                additionalVO.setMaintenancecoadtion("Y");
	                additionalVO.setMaintenanceofChronic("97");
	                additionalVO.setStrambulanace("Y");
	                additionalVO.setStracendental("Y");
	                additionalVO.setStrdevated("Y");
	                additionalVO.setHarmonereplace("Y");
	                additionalVO.setHormoneReplacementTherapylimit("103");
	                additionalVO.setInpatientrehabationtreatment("Y");
	                additionalVO.setInpatientRehabilitation("106");
	                additionalVO.setNursinghome("Y");
	                additionalVO.setNursingathomelimit("118");
	                additionalVO.setOralmax("Y");
	                additionalVO.setOrgantransplant("Y");
	                additionalVO.setOrganlimit("121");
	                additionalVO.setPassiveWar("122");
	                additionalVO.setCheckconstructive("Y");
	                additionalVO.setVitaminsmed("Y");
	                additionalVO.setVitamins("126");
	                additionalVO.setPreandpost("Y");
	                additionalVO.setPreandpostnatal("156");
	                additionalVO.setInternationalEmergency("Y");
	                additionalVO.setInternationalEmergencylimit("130");
	                additionalVO.setPsychiatric("Y");
	                additionalVO.setPsychiatrylimit("135");
	                additionalVO.setPsychiatrylimitCopay("143");
	                additionalVO.setVaccination("Y");
	                additionalVO.setVaccinationslimit("149");
	                additionalVO.setVaccinationage("152");
	                additionalVO.setHealth("Y");
	                additionalVO.setHealthscreenlimit("162");
	                additionalVO.setGumsurgery("Y");
	                additionalVO.setInpatientlimit("27");
	                additionalVO.setOutsideareaofcover("281");
	                additionalVO.setStrinpatientboadrd("252");
	                additionalVO.setParentaccomdation("489");
	                additionalVO.setStrinpatientcash("264");      
	                additionalVO.setAlternativesession("267");
	                //27/2/2020
	                additionalVO.setStracute("Y");
	                additionalVO.setAlternativeTreatments("514");
	                additionalVO.setPregnancy("154");
	                additionalVO.setDentalprothis("495");
	                additionalVO.setRadiography("Y");
	                additionalVO.setCongtal("497");
	                additionalVO.setOncology("499");
	                additionalVO.setRepatriation("535");
	                additionalVO.setDeductiblecoinsurance("490");
	                additionalVO.setWorkrelateddrop1("190");
	                additionalVO.setLifeThreateningdiease("199");
	                additionalVO.setHealthscreencopay("176");
	                additionalVO.setLevelofcover("277");
	                additionalVO.setReimbursmentLevel("525");
	                additionalVO.setApproval("271");
	                additionalVO.setTerminal("536");
	       
	        }
		
		
		
		UserSecurityProfile userAccessSecurityProfile = (UserSecurityProfile) request.getSession().getAttribute("userAccessSecurityProfile");
		userAccessSecurityProfile.getSecurityProfile().setActiveTab(request.getParameter("submenulink"));
		modelAndView.addObject("renewalYN", additionalVO.getRenewalYNadd());
		modelAndView.addObject("prevespolno", additionalVO.getPrevpolno());
		
		modelAndView.addObject("additionalVO", additionalVO);
	
		
return modelAndView;
		}catch(Throwable throwable){
			return processErrorView(strAdditionalPricing, throwable);
		}
    	
    	
	}
	@Autowired
	public PricingRiskPreimiumService pricingRiskPreimiumService;
	
	@RequestMapping(value ="AdditionalBenefitssave", method = RequestMethod.POST)
	public ModelAndView doAdditionalpricingSave(@ModelAttribute("additionalVO") AdditionalVO additionalVO, HttpServletRequest request,
			HttpServletResponse response, HttpSession session, Model model) throws Exception {
		setLinks(request);
		ModelAndView modelAndView = new ModelAndView(strAdditionalPricing);
		setErrorPageData(strAdditionalPricing, model);
		try{
			additionalVO.setPricingno((Long) request.getSession().getAttribute("groupPricingSeqId"));
			
		int save=additionalservice.getsave(additionalVO);
		if(save>0){
			modelAndView.addObject("successMsg", "Details Added Successfully");
			additionalVO=additionalservice.getdetails(additionalVO);
		}
		if("Y".equalsIgnoreCase(additionalVO.getFetch())){
			modelAndView.addObject("renewal", "Y");
		}else{
			modelAndView.addObject("renewal", "N");
		}
		modelAndView.addObject("renewalYN", additionalVO.getRenewalYNadd());
		modelAndView.addObject("additionalVO", additionalVO);
      /*   return modelAndView;*/
         return new ModelAndView("forward:/SoftwareInsurancePricing/Proposal?submenulink=Proposal");
	   }catch(Throwable throwable){
		return processErrorView(strAdditionalPricing, throwable);
	     }
	
	
	}
	
	@RequestMapping(value ="Additionalfetch", method = RequestMethod.POST)
	public ModelAndView doAdditionalfetch(@ModelAttribute("additionalVO") AdditionalVO additionalVO, HttpServletRequest request,
			HttpServletResponse response, HttpSession session, Model model) throws Exception {
		setLinks(request);
		ModelAndView modelAndView = new ModelAndView(strAdditionalPricing);
		setErrorPageData(strAdditionalPricing, model);
		try{
		
			additionalVO=additionalservice.getdetailsfetch(additionalVO);
			if("Y".equalsIgnoreCase(additionalVO.getRenewalYNadd())){
				modelAndView.addObject("renewal", "Y");
			}else{
				modelAndView.addObject("renewal", "N");
			}
			
		
		modelAndView.addObject("additionalVO", additionalVO);
         return modelAndView;
    	
	   }catch(Throwable throwable){
		return processErrorView(strAdditionalPricing, throwable);
	     }
	
	
	}
	
	@Autowired
	Additionalservice additionalservice;
	
}


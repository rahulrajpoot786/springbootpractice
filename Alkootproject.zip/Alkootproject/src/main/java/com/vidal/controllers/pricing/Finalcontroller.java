package com.vidal.controllers.pricing;


import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.sql.DataSource;
import javax.validation.Valid;

import net.sf.jasperreports.engine.JRDataSource;
import net.sf.jasperreports.engine.JREmptyDataSource;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JRResultSetDataSource;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.data.JRXmlDataSource;
import net.sf.jasperreports.engine.util.JRXmlUtils;
import oracle.jdbc.rowset.OracleCachedRowSet;

import org.apache.log4j.Logger;
import org.jfree.util.Log;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.reports.TTKReportDataSource;
import com.vidal.command.common.CacheObject;
import com.vidal.command.pricing.DashboardVO;
import com.vidal.command.pricing.GrosspremiumVO;
import com.vidal.command.pricing.InsPricingVO;
import com.vidal.command.pricing.SwPricingSummaryVO;
import com.vidal.command.pricing.WhatifScreenVO;
import com.vidal.command.usermanagement.UserSecurityProfile;
import com.vidal.common.PreAuthWebBoardHelper;
import com.vidal.common.UXUtility;
import com.vidal.common.VidalCommon;
import com.vidal.common.controller.vidalcontroller.VidalController;
import com.vidal.common.exception.GetErrorMessage;
import com.vidal.common.reports.TTKPropertiesReader;
import com.vidal.controllers.table.TableData;
import com.vidal.services.authentication.DashboardGeneralService;
import com.vidal.services.authentication.GrossService;
import com.vidal.services.pricing.PricingInputScreenService;
import com.vidal.services.pricing.PricingRiskPreimiumService;


@Controller
@RequestMapping("SoftwareInsurancePricing")


public class Finalcontroller extends VidalController {
	private static Logger logger = Logger.getLogger( Finalcontroller.class );
	private static final String strFinalPricingGross="pricing.Final";
	private static final String Whatif="pricing.Whatif";
	private static final String strReportdisplay="/binaryFile";
	
	@Autowired
	public PricingRiskPreimiumService pricingRiskPreimiumService;
	@RequestMapping(value ="FinalPricing",  method = { RequestMethod.GET, RequestMethod.POST })
	
	public ModelAndView doDefault(@Valid @ModelAttribute("SwPricingSummaryVO") SwPricingSummaryVO swPricingSummaryVO,BindingResult result, HttpServletRequest request,
			HttpServletResponse response, HttpSession session, Model model) throws Exception {
		try{
		request.getSession().removeAttribute("table1data");
		ModelAndView modelAndView = new ModelAndView(strFinalPricingGross);
		setLinks(request);
		InsPricingVO insPricingVO  = new InsPricingVO();
//		UserSecurityProfile userAccessSecurityProfile = (UserSecurityProfile) request.getSession().getAttribute("userAccessSecurityProfile");
//		userAccessSecurityProfile.getSecurityProfile().setDefaultActiveLink();
		setErrorPageData(strFinalPricingGross, model);
			String completeSaveYN = (String)request.getSession().getAttribute("completeSaveYN");
			//long GroupProfileSeqID = (long)request.getSession().getAttribute("GroupProfileSeqID");
			if(completeSaveYN.equals("N"))
				 return new ModelAndView("failure","GLOBAL_ERROR",GetErrorMessage.getValue("error.pricing.complete.screen"));	
		
			long GroupProfileSeqID=(Long) request.getSession().getAttribute("groupPricingSeqId");
			 insPricingVO  =  pricingRiskPreimiumService.getfalgPricingvalue(GroupProfileSeqID);
			  
			  System.out.println("insPricingVO.getCompleteSaveYNInSc2()..."+insPricingVO.getCompleteSaveYNInSc2());
			  
			  if(insPricingVO.getCompleteSaveYNInSc2().equalsIgnoreCase("N") || insPricingVO.getCompleteSaveYNInSc2().equalsIgnoreCase("")) {
				
					 return new ModelAndView("failure","GLOBAL_ERROR",GetErrorMessage.getValue("error.pricing.complete.screen"));			
				}
			 


		
		ArrayList finaltable1data[] = null;
		//insPricingVO.setGroupProfileSeqID(GroupProfileSeqID);
		//insPricingVO.setAddedBy((VidalCommon.getUserSeqId(request)));
		insPricingVO.setGroupProfileSeqID((Long) request.getSession().getAttribute("groupPricingSeqId"));
		insPricingVO.setAddedBy(VidalCommon.getUserSeqId(request));
		InsPricingVO insPricingVO2  =  grossService.getfalgPricingvalue(GroupProfileSeqID);
		modelAndView.addObject("brokerflag", insPricingVO2.getBrokerflag());
		
		String loadingFlagYN = insPricingVO2.getLoadingFlagYN();
		 String calCPM_FlagYN = insPricingVO2.getCalCPMFlagYN();
		 String gross_calualtion=insPricingVO2.getGrossclaulation().trim();
		 
		 String modify_flag=insPricingVO2.getPricingmodifyYN();
		 System.out.println("gross_calualtion..."+gross_calualtion);
		 System.out.println("calCPM_FlagYN..."+calCPM_FlagYN);
		 if(calCPM_FlagYN.equals("N") || calCPM_FlagYN.equals("")){
				return new ModelAndView("failure","GLOBAL_ERROR",GetErrorMessage.getValue("error.pricing.complete.screen.riskpremium"));
			}
		 if(gross_calualtion.equals("N") || gross_calualtion.equals("")){
				return new ModelAndView("failure","GLOBAL_ERROR",GetErrorMessage.getValue("error.pricing.complete.screen.gross"));
			}
              
		/*swPricingSummaryVO.setAddedBy(VidalCommon.getUserSeqId(request));
		swPricingSummaryVO.setAddedBy(VidalCommon.getUserSeqId(request));
		swPricingSummaryVO.setLngGroupProfileSeqID((Long) request.getSession().getAttribute("groupPricingSeqId"));
		InsPricingVO insPricingVO2  =  grossService.getfalgPricingvaluetable(GroupProfileSeqID);*/
		//String pricingModifiedYN = insPricingVO2.getPricingmodifyYN();
		swPricingSummaryVO.setPricingRefno((String) request.getSession().getAttribute("pricingRefNo"));
		String pricingModifiedYN ="N";
		if(GroupProfileSeqID > 0  && completeSaveYN.equalsIgnoreCase("Y") && pricingModifiedYN.equals("N") ){
			finaltable1data= grossService.getcpmAfterLoadingPricing(insPricingVO);
		}
		
		if("Y".equals(gross_calualtion)){
		  request.getSession().setAttribute("finaltable1data",finaltable1data);
	      if(request.getSession().getAttribute("finaltable1data")!=null){
              ArrayList arr[] =(ArrayList[]) request.getSession().getAttribute("finaltable1data");
                if(arr.length>0){
                ArrayList<HashMap<String, String>> al = arr[0];
                ArrayList<HashMap<String, String>> maternity = arr[1];
                ArrayList<HashMap<String, String>> Overall = arr[2];
                ArrayList<String> tabledetals = arr[3];
                ArrayList tabletotalvalues = arr[4];
               String value1= tabledetals.get(0);
               String value2= tabledetals.get(1);
             
          
             /*  request.getSession().setAttribute("inpatientsum", Double.parseDouble(String.valueOf(tabletotalvalues.get(0)).replaceAll(",", "")));
               request.getSession().setAttribute("outpatientsum", Double.parseDouble(String.valueOf(tabletotalvalues.get(1)).replaceAll(",", "")));
               request.getSession().setAttribute("opticalsum", Double.parseDouble(String.valueOf(tabletotalvalues.get(2)).replaceAll(",", "")));  
               request.getSession().setAttribute("dentalsum", Double.parseDouble(String.valueOf(tabletotalvalues.get(3)).replaceAll(",", "")));
               request.getSession().setAttribute("excludingmaternitysum", Double.parseDouble(String.valueOf(tabletotalvalues.get(4)).replaceAll(",", "")));
               request.getSession().setAttribute("smallmeternitysum", Double.parseDouble(String.valueOf(tabletotalvalues.get(5)).replaceAll(",", "")));
               request.getSession().setAttribute("maternitysum", Double.parseDouble(String.valueOf(tabletotalvalues.get(6)).replaceAll(",", "")));
               request.getSession().setAttribute("includematernitysum", Double.parseDouble(String.valueOf(tabletotalvalues.get(7)).replaceAll(",", "")));
              */
               request.getSession().setAttribute("inpatientsum", tabletotalvalues.get(0));
               request.getSession().setAttribute("outpatientsum", (tabletotalvalues.get(1)));
               request.getSession().setAttribute("opticalsum",(tabletotalvalues.get(2)));  
               request.getSession().setAttribute("dentalsum",(tabletotalvalues.get(3)));
               request.getSession().setAttribute("excludingmaternitysum",(tabletotalvalues.get(4)));
               request.getSession().setAttribute("smallmeternitysum",(tabletotalvalues.get(5)));
               request.getSession().setAttribute("maternitysum", (tabletotalvalues.get(6)));
               request.getSession().setAttribute("includematernitysum",(tabletotalvalues.get(7)));
             
             
              
              
               

	ArrayList<HashMap<String, String>> allist = finaltable1data[2];
	HashMap<String, String> hmap =allist.get(0);
	String strmainoverall =hmap.get("mainoverall");
	request.getSession().setAttribute("strmainoverall", strmainoverall);
	HashMap<String, String> cpmseq =null;

	 cpmseq =allist.get(0);
	String cpmseqid =cpmseq.get("cpmseqid");
	String mainoverall =cpmseq.get("mainoverall");
	String maxageband=cpmseq.get("maxageband");
	
	request.setAttribute("maxage",maxageband);
	
                }}}
		model.addAttribute("grosscal", gross_calualtion);
	  modelAndView.addObject("SwPricingSummaryVO",   swPricingSummaryVO);
	  request.setAttribute("lngGroupProfileSeqID", insPricingVO.getGroupProfileSeqID());
		UserSecurityProfile userAccessSecurityProfile = (UserSecurityProfile) request.getSession().getAttribute("userAccessSecurityProfile");
		
		userAccessSecurityProfile.getSecurityProfile().setActiveTab("Final Pricing");
	
	
		return modelAndView;
		}catch(Throwable throwable){
			return processErrorView(strFinalPricingGross, throwable);
		}
	}
	
	  @RequestMapping(value ="whatReport",  method = RequestMethod.GET)
	    public String doWhatReport(HttpServletRequest request,
	            HttpServletResponse response, HttpSession session, Model model) throws Exception {

//	        JasperReport emptyReport;
	        JasperPrint jasperPrint;
	        int iNoOfCursor = 3;
//	        JasperPrint objJasperPrint[] = new JasperPrint[iNoOfCursor];
//	        ArrayList<Object> alJasperPrintList = new ArrayList<Object>();
//	        String strPath = "";
	       String shortDirectory = UXUtility.getPropertyValue("generalreports");
	        TTKReportDataSource ttkReportDataSource = null;
	        String jrxmlfile = shortDirectory + request.getParameter("fileName");
	    /*    String strPdfFile = TTKPropertiesReader.getPropertyValue("shortfallrptdir")+ request.getParameter("lngprofileseqid") + ".pdf";*/

	        try {
//	            System.out.println("jrxmlfile....."+jrxmlfile);

//	            xmljasperReport = JasperCompileManager.compileReport("" + shortDirectory + "/viewInputPricing.jrxml");
	            HashMap<String, Object> hashMap = new HashMap<String, Object>();
	            ByteArrayOutputStream boas = new ByteArrayOutputStream();
	            ttkReportDataSource = new TTKReportDataSource("whatReportId",request.getParameter("parameter"),dataSource,iNoOfCursor);
	            ArrayList resultSetList=ttkReportDataSource.getResultSetList();
	            OracleCachedRowSet[] arrResulSet=new OracleCachedRowSet[3];
	            arrResulSet[0]=(OracleCachedRowSet) resultSetList.get(0);
	            arrResulSet[1]=(OracleCachedRowSet) resultSetList.get(1);
	            arrResulSet[2]=(OracleCachedRowSet) resultSetList.get(2);

	            JasperReport SpringWhatifReport = null;
	            JasperReport SpringWhatifSubReport1 = null;
	            JasperReport SpringWhatifSubReport2= null;

	            //JasperReport premiumJasperReport = null;
	            JasperReport emptyReport=null;
//	            JasperPrint generalJasperPrint = null;

	            ResultSet resultSet1 =arrResulSet[1];

	            while(resultSet1.next())
	            {
	                for(int i=1;i<=resultSet1.getMetaData().getColumnCount();i++)
	                {
	                    logger.info("index ::"+i+":: "+resultSet1.getMetaData().getColumnName(i) +":::"+resultSet1.getString(i));

	                }
	logger.info("----------------------------------------------//-----------");
	            }
	            resultSet1.beforeFirst();
	            JRDataSource myResultSetDS0 = new JRResultSetDataSource(arrResulSet[0]);
	            JRDataSource myResultSetDS1 = new JRResultSetDataSource(arrResulSet[1]);
	            JRDataSource myResultSetDS2 = new JRResultSetDataSource(arrResulSet[2]);




	            ttkReportDataSource.setResultData(arrResulSet);
	            if(!arrResulSet[0].next())
	            {
	                System.out.println("m1");
	                emptyReport = JasperCompileManager.compileReport(""+shortDirectory+"/EmptyReprot.jrxml");
	                jasperPrint = JasperFillManager.fillReport(emptyReport,hashMap,new JREmptyDataSource());

	JasperExportManager.exportReportToPdfStream(jasperPrint, boas);
	              // JasperExportManager.exportReportToPdfFile(jasperPrint,"E:\\reportgenerate\\test.pdf");
	/*JasperExportManager.exportReportToPdfFile(jasperPrint, strPdfFile);*/
	                request.getSession().setAttribute("boas", boas);
//	                alJasperPrintList.add(jasperPrint);
	            }
	         else
	         {

	                SpringWhatifReport = JasperCompileManager.compileReport(shortDirectory+"/Spring_What_if_Report.jrxml");

	                SpringWhatifSubReport1 = JasperCompileManager.compileReport(shortDirectory+"/Spring_What_if_Report_subreport1.jrxml");
	                SpringWhatifSubReport2 = JasperCompileManager.compileReport(shortDirectory+"/Spring_What_if_Report_subreport2.jrxml");


	                /*premiumJasperReport= JasperCompileManager.compileReport("");*/
	                hashMap.put("SpringWhatifSubDataSource1", myResultSetDS1);
	                hashMap.put("SpringWhatifSubReport1", SpringWhatifSubReport1);



	                hashMap.put("SpringWhatifSubDataSourc2", myResultSetDS2);
	                hashMap.put("SpringWhatifSubReport2", SpringWhatifSubReport2);
	              

	              

	                /*hsashMap.put("premiumDataSource", myResultSetDS3);
	                hashMap.put("premiumReport", premiumJasperReport);*/



	                arrResulSet[0].beforeFirst();
	                System.out.println("tttt..."+hashMap);
	             if (arrResulSet[0].next())
	             {
	                 arrResulSet[0].beforeFirst();
	                 System.out.println("main");
	             jasperPrint = JasperFillManager.fillReport(SpringWhatifReport,hashMap, myResultSetDS0);

	             } else
	             {
	                 System.out.println("empty");
	                 emptyReport =JasperCompileManager.compileReport(""+shortDirectory+"/EmptyReprot.jrxml");
	                 jasperPrint = JasperFillManager.fillReport( emptyReport, hashMap,new JREmptyDataSource());
	             }

	JasperExportManager.exportReportToPdfStream(jasperPrint, boas);
	          // JasperExportManager.exportReportToPdfFile(jasperPrint,"E:\\reportgenerate\\test.pdf");
	//JasperExportManager.exportReportToPdfFile(jasperPrint, strPdfFile);
	            request.getSession().setAttribute("boas", boas);
	        } // end of try
	        }
	        catch (Exception e) {
	            e.printStackTrace();
	        }


	        return "forward:/" + strReportdisplay + "";
	    }



	

	



		
	
		

	
	@RequestMapping(value ="Report",  method = RequestMethod.GET)
	public String doReport(@ModelAttribute("GrosspremiumVO") GrosspremiumVO grossVO, HttpServletRequest request,
			HttpServletResponse response, HttpSession session, Model model) throws Exception {
	
//		JasperReport emptyReport;
		JasperPrint jasperPrint;
		int iNoOfCursor = 6;
//		JasperPrint objJasperPrint[] = new JasperPrint[iNoOfCursor];
//		ArrayList<Object> alJasperPrintList = new ArrayList<Object>();
//		String strPath = "";
	String shortDirectory = UXUtility.getPropertyValue("generalreports");
		TTKReportDataSource ttkReportDataSource = null;
		String jrxmlfile = shortDirectory + request.getParameter("fileName");
	/*	String strPdfFile = TTKPropertiesReader.getPropertyValue("shortfallrptdir")+ request.getParameter("lngprofileseqid") + ".pdf";*/
		
		try {
//			System.out.println("jrxmlfile....."+jrxmlfile);
			
//			xmljasperReport = JasperCompileManager.compileReport("" + shortDirectory + "/viewInputPricing.jrxml");
			HashMap<String, Object> hashMap = new HashMap<String, Object>();
			ByteArrayOutputStream boas = new ByteArrayOutputStream();
			ttkReportDataSource = new TTKReportDataSource(request.getParameter("reportID"),request.getParameter("parameter"),dataSource,iNoOfCursor);
			ArrayList resultSetList=ttkReportDataSource.getResultSetList();
			OracleCachedRowSet[] arrResulSet=new OracleCachedRowSet[4];
			arrResulSet[0]=(OracleCachedRowSet) resultSetList.get(0);
			arrResulSet[1]=(OracleCachedRowSet) resultSetList.get(1);
			arrResulSet[2]=(OracleCachedRowSet) resultSetList.get(2);
			arrResulSet[3]=(OracleCachedRowSet) resultSetList.get(3);
														
			JasperReport generalJasperReport = null;
			JasperReport benefitJasperReport = null;
			JasperReport maternityJasperReport = null;
			JasperReport QarDataSourceReport = null;
			JasperReport QarDataSourceReportmat = null;
			//JasperReport premiumJasperReport = null;
			JasperReport emptyReport=null;
//			JasperPrint generalJasperPrint = null;
			
			/*ResultSet resultSet1 =arrResulSet[1];
			
			while(resultSet1.next())
			{
				for(int i=1;i<=resultSet1.getMetaData().getColumnCount();i++)
				{
					logger.info("index ::"+i+":: "+resultSet1.getMetaData().getColumnName(i) +":::"+resultSet1.getString(i));
					
				}
				logger.info("----------------------------------------------//-----------");
			}
			resultSet1.beforeFirst();*/
			JRDataSource myResultSetDS0 = new JRResultSetDataSource(arrResulSet[0]);		
			JRDataSource myResultSetDS1 = new JRResultSetDataSource(arrResulSet[1]);
			JRDataSource myResultSetDS2 = new JRResultSetDataSource(arrResulSet[2]);
			OracleCachedRowSet cachedRowSet1= (OracleCachedRowSet) arrResulSet[1].clone();
			OracleCachedRowSet cachedRowSet2 =(OracleCachedRowSet) arrResulSet[2].clone();
			JRDataSource QarDataSource = new JRResultSetDataSource(cachedRowSet1);
			JRDataSource QarDataSourceMat = new JRResultSetDataSource(cachedRowSet2);
			//JRDataSource myResultSetDS3 = new JRResultSetDataSource(arrResulSet[3]);
			
			//OracleCachedRowSet rowSet = arrResulSet[0];
			/*while(rowSet.next()){
				rowSet.beforeFirst();
				System.out.println("tettt..."+rowSet.getRow());
			}*/
			System.out.println("rs..."+arrResulSet[2]);
			
			ttkReportDataSource.setResultData(arrResulSet);
			if(!arrResulSet[0].next())
			{
				System.out.println("m1");
				emptyReport = JasperCompileManager.compileReport(""+shortDirectory+"/EmptyReprot.jrxml");
				jasperPrint = JasperFillManager.fillReport(emptyReport,hashMap,new JREmptyDataSource());
				
	            JasperExportManager.exportReportToPdfStream(jasperPrint, boas);
	          //  JasperExportManager.exportReportToPdfFile(jasperPrint,"E:\\reportgenerate\\test.pdf");
				/*JasperExportManager.exportReportToPdfFile(jasperPrint, strPdfFile);*/
				request.getSession().setAttribute("boas", boas);
//				alJasperPrintList.add(jasperPrint);
			}
		 else
		 {
			 /*ResultSetMetaData rsm=arrResulSet[2].getMetaData();
			 int count=rsm.getColumnCount();
			 for(int i=1;i<count+1;i++){
				 System.out.println("Column Name::"+rsm.getColumnName(i)+"----Data is::"+arrResulSet[2].getObject(i));
			 }*/
			 
		/*	 ResultSetMetaData rsm1=arrResulSet[3].getMetaData();
			 int count1=rsm1.getColumnCount();
			 System.out.println("count1 ;;;;;;;;;;;;;;;;;;;"+count1);
			 for(int i=1;i<count1+1;i++){
				 System.out.println("Column Name:wdfwe:"+rsm1.getColumnName(i)+"----Data is::"+arrResulSet[3].getObject(i));
			
				 
			 }*/
			 
			 int dataSourceIndex =(int) resultSetList.get(4);
			
			 System.out.println("dataSourceIndex...."+dataSourceIndex);
				System.out.println("m2");
				 if((dataSourceIndex==11)||(dataSourceIndex==12)){
					 generalJasperReport = JasperCompileManager.compileReport(""+shortDirectory+"/Spring_View_Inputoverall.jrxml"); 
				 }else{
			    generalJasperReport = JasperCompileManager.compileReport(""+shortDirectory+"/Spring_View_Input.jrxml");
				 }
                if((dataSourceIndex==12))
                {
                	
    				benefitJasperReport = JasperCompileManager.compileReport(""+shortDirectory+"/Spring_View_Input_subreport0.jrxml");
                } 
                if(dataSourceIndex==11){
                	benefitJasperReport = JasperCompileManager.compileReport(""+shortDirectory+"/Spring_View_Input_subreport11.jrxml");
                }
                if(dataSourceIndex==22){
    				benefitJasperReport = JasperCompileManager.compileReport(""+shortDirectory+"/Spring_View_Input_subreport1.jrxml");
    				maternityJasperReport = JasperCompileManager.compileReport(""+shortDirectory+"/Spring_View_Input_subreportmat.jrxml");
    				QarDataSourceReport = JasperCompileManager.compileReport(""+shortDirectory+"/Spring_View_Input_subreport1qar.jrxml");
    				QarDataSourceReportmat=JasperCompileManager.compileReport(""+shortDirectory+"/Spring_View_Input_subrept1matqar.jrxml");
                }
                if(dataSourceIndex==21){
                
                	benefitJasperReport = JasperCompileManager.compileReport(""+shortDirectory+"/Spring_View_Input_subreport2.jrxml");
                	QarDataSourceReport = JasperCompileManager.compileReport(""+shortDirectory+"/Spring_View_Input_subreport2qar.jrxml");
                }
                if(dataSourceIndex==31){
                	
                	benefitJasperReport = JasperCompileManager.compileReport(""+shortDirectory+"/Spring_View_Input_subreport31.jrxml");
                	QarDataSourceReport = JasperCompileManager.compileReport(""+shortDirectory+"/Spring_View_Input_subreport31qar.jrxml");
                }
                  if(dataSourceIndex==32){
                	
                	benefitJasperReport = JasperCompileManager.compileReport(""+shortDirectory+"/Spring_View_Input_subreport32.jrxml");
                	maternityJasperReport = JasperCompileManager.compileReport(""+shortDirectory+"/Spring_View_Input_subreportmat32.jrxml");
                	QarDataSourceReport = JasperCompileManager.compileReport(""+shortDirectory+"/Spring_View_Input_subreport32qar.jrxml");
                	QarDataSourceReportmat=JasperCompileManager.compileReport(""+shortDirectory+"/Spring_View_Input_subrept32matqar.jrxml");
                }
				/*premiumJasperReport= JasperCompileManager.compileReport("");*/
				hashMap.put("benefitDataSource", myResultSetDS1);
				hashMap.put("benfitsubReport", benefitJasperReport);
				
				
				hashMap.put("QarDataSource", QarDataSource);
				hashMap.put("QarDataSourceReport", QarDataSourceReport);
				
				hashMap.put("QarDataSourcemat", QarDataSourceMat);
				hashMap.put("QarDataSourceReportmat", QarDataSourceReportmat);
			
				hashMap.put("maternityDataSource", myResultSetDS2);
				hashMap.put("maternityReport", maternityJasperReport);
				
				hashMap.put("finalinpatient_sum", request.getSession().getAttribute("inpatientsum"));
				hashMap.put("outpatientsum", request.getSession().getAttribute("outpatientsum"));
				hashMap.put("opticalsum", request.getSession().getAttribute("opticalsum"));
				hashMap.put("dentalsum", request.getSession().getAttribute("dentalsum"));
				hashMap.put("excludingmaternitysum", request.getSession().getAttribute("excludingmaternitysum"));
				hashMap.put("smallmeternitysum", request.getSession().getAttribute("smallmeternitysum"));
				hashMap.put("maternitysum", request.getSession().getAttribute("maternitysum"));
				hashMap.put("includematernitysum", request.getSession().getAttribute("includematernitysum"));
				
				
				/*hsashMap.put("premiumDataSource", myResultSetDS3);
				hashMap.put("premiumReport", premiumJasperReport);*/
				
				hashMap.put("firstFlag",String.valueOf(resultSetList.get(4)));
				hashMap.put("secondFlag", resultSetList.get(5));
				
				
			    arrResulSet[0].beforeFirst();
			 if (arrResulSet[0].next()) 
			 {
				 arrResulSet[0].beforeFirst();
			 jasperPrint = JasperFillManager.fillReport(generalJasperReport,hashMap, myResultSetDS0);
			
			 } else
			 {
				 emptyReport =JasperCompileManager.compileReport(""+shortDirectory+"/EmptyReprot.jrxml");
				 jasperPrint = JasperFillManager.fillReport( emptyReport, hashMap,new JREmptyDataSource());
			 }
					
            JasperExportManager.exportReportToPdfStream(jasperPrint, boas);
          //  JasperExportManager.exportReportToPdfFile(jasperPrint,"E:\\reportgenerate\\test.pdf");
			//JasperExportManager.exportReportToPdfFile(jasperPrint, strPdfFile);
			request.getSession().setAttribute("boas", boas);
		} // end of try
		}
		catch (Exception e) {
			e.printStackTrace();
		}


		return "forward:/" + strReportdisplay + "";
	}
	
	@RequestMapping(value ="BrokerReport",  method = RequestMethod.GET)
	public String dobrokerReport(@ModelAttribute("GrosspremiumVO") GrosspremiumVO grossVO, HttpServletRequest request,
			HttpServletResponse response, HttpSession session, Model model) throws Exception {
	
//		JasperReport emptyReport;
		JasperPrint jasperPrint;
		int iNoOfCursor = 6;
//		JasperPrint objJasperPrint[] = new JasperPrint[iNoOfCursor];
//		ArrayList<Object> alJasperPrintList = new ArrayList<Object>();
//		String strPath = "";
	String shortDirectory = UXUtility.getPropertyValue("generalreports");
		TTKReportDataSource ttkReportDataSource = null;
		String jrxmlfile = shortDirectory + request.getParameter("fileName");
		String strPdfFile = TTKPropertiesReader.getPropertyValue("shortfallrptdir")+ request.getParameter("lngprofileseqid") + ".pdf";
		
		try {
//			System.out.println("jrxmlfile....."+jrxmlfile);
			
//			xmljasperReport = JasperCompileManager.compileReport("" + shortDirectory + "/viewInputPricing.jrxml");
			HashMap<String, Object> hashMap = new HashMap<String, Object>();
			ByteArrayOutputStream boas = new ByteArrayOutputStream();
			ttkReportDataSource = new TTKReportDataSource(request.getParameter("reportID"),request.getParameter("parameter"),dataSource,iNoOfCursor);
			ArrayList resultSetList=ttkReportDataSource.getResultSetList();
			OracleCachedRowSet[] arrResulSet=new OracleCachedRowSet[4];
			arrResulSet[0]=(OracleCachedRowSet) resultSetList.get(0);
			arrResulSet[1]=(OracleCachedRowSet) resultSetList.get(1);
			arrResulSet[2]=(OracleCachedRowSet) resultSetList.get(2);
			arrResulSet[3]=(OracleCachedRowSet) resultSetList.get(3);
														
			JasperReport generalJasperReport = null;
			JasperReport benefitJasperReport = null;
			JasperReport maternityJasperReport = null;
			JasperReport QarDataSourceReport = null;
			JasperReport QarDataSourceReportmat = null;
			//JasperReport premiumJasperReport = null;
			JasperReport emptyReport=null;
//			JasperPrint generalJasperPrint = null;
			
			/*ResultSet resultSet1 =arrResulSet[1];
			
			while(resultSet1.next())
			{
				for(int i=1;i<=resultSet1.getMetaData().getColumnCount();i++)
				{
					logger.info("index ::"+i+":: "+resultSet1.getMetaData().getColumnName(i) +":::"+resultSet1.getString(i));
					
				}
				logger.info("----------------------------------------------//-----------");
			}
			resultSet1.beforeFirst();*/
			JRDataSource myResultSetDS0 = new JRResultSetDataSource(arrResulSet[0]);		
			JRDataSource myResultSetDS1 = new JRResultSetDataSource(arrResulSet[1]);
			JRDataSource myResultSetDS2 = new JRResultSetDataSource(arrResulSet[2]);
			OracleCachedRowSet cachedRowSet1= (OracleCachedRowSet) arrResulSet[1].clone();
			OracleCachedRowSet cachedRowSet2 =(OracleCachedRowSet) arrResulSet[2].clone();
			JRDataSource QarDataSource = new JRResultSetDataSource(cachedRowSet1);
			JRDataSource QarDataSourceMat = new JRResultSetDataSource(cachedRowSet2);
			//JRDataSource myResultSetDS3 = new JRResultSetDataSource(arrResulSet[3]);
			
			//OracleCachedRowSet rowSet = arrResulSet[0];
			/*while(rowSet.next()){
				rowSet.beforeFirst();
				System.out.println("tettt..."+rowSet.getRow());
			}*/
			
			ttkReportDataSource.setResultData(arrResulSet);
			if(!arrResulSet[0].next())
			{
				emptyReport = JasperCompileManager.compileReport(""+shortDirectory+"/EmptyReprot.jrxml");
				jasperPrint = JasperFillManager.fillReport(emptyReport,hashMap,new JREmptyDataSource());
				
	            JasperExportManager.exportReportToPdfStream(jasperPrint, boas);
	          //  JasperExportManager.exportReportToPdfFile(jasperPrint,"E:\\reportgenerate\\test.pdf");
				//JasperExportManager.exportReportToPdfFile(jasperPrint, strPdfFile);
				request.getSession().setAttribute("boas", boas);
//				alJasperPrintList.add(jasperPrint);
			}
		 else
		 {
			 /*ResultSetMetaData rsm=arrResulSet[2].getMetaData();
			 int count=rsm.getColumnCount();
			 for(int i=1;i<count+1;i++){
				 System.out.println("Column Name::"+rsm.getColumnName(i)+"----Data is::"+arrResulSet[2].getObject(i));
			 }*/
			 
		/*	 ResultSetMetaData rsm1=arrResulSet[3].getMetaData();
			 int count1=rsm1.getColumnCount();
			 System.out.println("count1 ;;;;;;;;;;;;;;;;;;;"+count1);
			 for(int i=1;i<count1+1;i++){
				 System.out.println("Column Name:wdfwe:"+rsm1.getColumnName(i)+"----Data is::"+arrResulSet[3].getObject(i));
			
				 
			 }*/
			 
			 int dataSourceIndex =(int) resultSetList.get(4);
			
			 
			    if((dataSourceIndex==11)||(dataSourceIndex==12)){
					 generalJasperReport = JasperCompileManager.compileReport(""+shortDirectory+"/Spring_Viewbroker_Inputoverall.jrxml"); 
				 }else{
					   generalJasperReport = JasperCompileManager.compileReport(""+shortDirectory+"/Spring_View_Inputbroker.jrxml");
				 }
			    if((dataSourceIndex==12))
                {
                	
                	
    				benefitJasperReport = JasperCompileManager.compileReport(""+shortDirectory+"/Spring_View_Input_subreport0.jrxml");
                } 
                if(dataSourceIndex==11){
                	benefitJasperReport = JasperCompileManager.compileReport(""+shortDirectory+"/Spring_View_Input_subreport11.jrxml");
                }
                if(dataSourceIndex==22){
    				benefitJasperReport = JasperCompileManager.compileReport(""+shortDirectory+"/Spring_View_Input_subreport1.jrxml");
    				maternityJasperReport = JasperCompileManager.compileReport(""+shortDirectory+"/Spring_View_Input_subreportmat.jrxml");
    				QarDataSourceReport = JasperCompileManager.compileReport(""+shortDirectory+"/Spring_View_Input_subreport1qar.jrxml");
    				QarDataSourceReportmat=JasperCompileManager.compileReport(""+shortDirectory+"/Spring_View_Input_subrept1matqar.jrxml");
                }
                if(dataSourceIndex==21){
                
                	benefitJasperReport = JasperCompileManager.compileReport(""+shortDirectory+"/Spring_View_Input_subreport2.jrxml");
                	QarDataSourceReport = JasperCompileManager.compileReport(""+shortDirectory+"/Spring_View_Input_subreport2qar.jrxml");
                }
                if(dataSourceIndex==31){
                	
                	benefitJasperReport = JasperCompileManager.compileReport(""+shortDirectory+"/Spring_View_Input_subreport31.jrxml");
                	QarDataSourceReport = JasperCompileManager.compileReport(""+shortDirectory+"/Spring_View_Input_subreport31qar.jrxml");
                }
                  if(dataSourceIndex==32){
                	
                	benefitJasperReport = JasperCompileManager.compileReport(""+shortDirectory+"/Spring_View_Input_subreport32.jrxml");
                	maternityJasperReport = JasperCompileManager.compileReport(""+shortDirectory+"/Spring_View_Input_subreportmat32.jrxml");
                	QarDataSourceReport = JasperCompileManager.compileReport(""+shortDirectory+"/Spring_View_Input_subreport32qar.jrxml");
    				QarDataSourceReportmat=JasperCompileManager.compileReport(""+shortDirectory+"/Spring_View_Input_subrept32matqar.jrxml");
                }
				/*premiumJasperReport= JasperCompileManager.compileReport("");*/
				hashMap.put("benefitDataSource", myResultSetDS1);
				hashMap.put("benfitsubReport", benefitJasperReport);
				
				
				hashMap.put("QarDataSource", QarDataSource);
				hashMap.put("QarDataSourceReport", QarDataSourceReport);
				
				hashMap.put("QarDataSourcemat", QarDataSourceMat);
				hashMap.put("QarDataSourceReportmat", QarDataSourceReportmat);
			
				hashMap.put("maternityDataSource", myResultSetDS2);
				hashMap.put("maternityReport", maternityJasperReport);
				
				
				/*hashMap.put("premiumDataSource", myResultSetDS3);
				hashMap.put("premiumReport", premiumJasperReport);*/
				
				hashMap.put("firstFlag",String.valueOf(resultSetList.get(4)));
				hashMap.put("secondFlag", resultSetList.get(5));
				hashMap.put("finalinpatient_sum", request.getSession().getAttribute("inpatientsum"));
				hashMap.put("outpatientsum", request.getSession().getAttribute("outpatientsum"));
				hashMap.put("opticalsum", request.getSession().getAttribute("opticalsum"));
				hashMap.put("dentalsum", request.getSession().getAttribute("dentalsum"));
				hashMap.put("excludingmaternitysum", request.getSession().getAttribute("excludingmaternitysum"));
				hashMap.put("smallmeternitysum", request.getSession().getAttribute("smallmeternitysum"));
				hashMap.put("maternitysum", request.getSession().getAttribute("maternitysum"));
				hashMap.put("includematernitysum", request.getSession().getAttribute("includematernitysum"));
				
				
			    arrResulSet[0].beforeFirst();
			 if (arrResulSet[0].next()) 
			 {
				 arrResulSet[0].beforeFirst();
			 jasperPrint = JasperFillManager.fillReport(generalJasperReport,hashMap, myResultSetDS0);
			
			 } else
			 {
				 emptyReport =JasperCompileManager.compileReport(""+shortDirectory+"/EmptyReprot.jrxml");
				 jasperPrint = JasperFillManager.fillReport( emptyReport, hashMap,new JREmptyDataSource());
			 }
					
            JasperExportManager.exportReportToPdfStream(jasperPrint, boas);
          //  JasperExportManager.exportReportToPdfFile(jasperPrint,"E:\\reportgenerate\\test.pdf");
			//JasperExportManager.exportReportToPdfFile(jasperPrint, strPdfFile);
			request.getSession().setAttribute("boas", boas);
		} // end of try
		}
		catch (Exception e) {
			e.printStackTrace();
		}


		return "forward:/" + strReportdisplay + "";
	}
	
	@RequestMapping(value ="Whatif",  method = { RequestMethod.GET, RequestMethod.POST })
	public ModelAndView doWhatif(@ModelAttribute("whatifScreenVO") WhatifScreenVO whatifVO, HttpServletRequest request,
			HttpServletResponse response, HttpSession session, Model model) throws Exception {
		ModelAndView modelandview=new ModelAndView(Whatif);
		UserSecurityProfile userAccessSecurityProfile = (UserSecurityProfile) request.getSession()
				.getAttribute("userAccessSecurityProfile");			
		String[] identfierList = new String[] {"maternityCopayListWhatif","maxBenifitListIpWhatif","opticalLimitListWhatif","dentalLimitListWhatif","maxBenifitListOpLimitIpWhatif"};		
		populateData(identfierList,Whatif);
		long userseqid = userAccessSecurityProfile.getUSER_SEQ_ID();		
		long GroupProfileSeqID = (long)request.getSession().getAttribute("groupPricingSeqId");
		
		WhatifScreenVO whatifScreenVOYn= grossService.getVersionSeqId(GroupProfileSeqID,1l);
		if(whatifScreenVOYn != null) {
			
		whatifVO = grossService.getWhatifDetails(GroupProfileSeqID,whatifScreenVOYn.getVersionSeqId(),1l,whatifScreenVOYn.getSaveYn());
		}else {
			
			whatifVO = grossService.getWhatifDetails(GroupProfileSeqID,0l,1l,"Y");
		}
	       SimpleDateFormat sd=new SimpleDateFormat("dd/MM/yyyy");
		
		if(whatifVO.getCoverageStartDate() !=null) {
			whatifVO.setCoverageStartDatestr(sd.format(whatifVO.getCoverageStartDate()));
		}
		
		if(whatifVO.getCoverageEndDate() !=null) {
			whatifVO.setCoverageEndDatestr(sd.format(whatifVO.getCoverageEndDate()));
		}
		
		if(whatifVO.getVersionCount() !=null && whatifVO.getVersionCount() != 0) {
			request.setAttribute("tabval",whatifVO.getVersionCount());
		}else {
			request.setAttribute("tabval",1);
		}
		ArrayList<CacheObject> alPricingNetworkList = pricingInputScreenService.getHospitalList("1");		 
		request.getSession().setAttribute("alPricingNetworkList", alPricingNetworkList);
		
		/*request.getSession().setAttribute("whatifScreenVO",whatifVO);*/
		whatifVO.setVersionVal(1l);
	   
		
		whatifVO.setGroupProSeqId(GroupProfileSeqID);
		request.getSession().setAttribute("finalCount",whatifVO.getVersionCount());
		modelandview.addObject("whatStatusVar","Ver");
		modelandview.addObject("whatifScreenVO",whatifVO);
		return modelandview;
	}
	
	@RequestMapping(value ="refress",  method = { RequestMethod.GET, RequestMethod.POST })
	public ModelAndView doRefress(@ModelAttribute("whatifScreenVO") WhatifScreenVO whatifVO, HttpServletRequest request,
			HttpServletResponse response, HttpSession session, Model model) throws Exception {
		ModelAndView modelandview=new ModelAndView(Whatif);
		UserSecurityProfile userAccessSecurityProfile = (UserSecurityProfile) request.getSession()
				.getAttribute("userAccessSecurityProfile");			
		String[] identfierList = new String[] {"maternityCopayListWhatif","maxBenifitListIpWhatif","opticalLimitListWhatif","dentalLimitListWhatif","maxBenifitListOpLimitIpWhatif"};		
		populateData(identfierList,Whatif);
		long userseqid = userAccessSecurityProfile.getUSER_SEQ_ID();		
		long GroupProfileSeqID = (long)request.getSession().getAttribute("groupPricingSeqId");	
	    Long varVal=whatifVO.getVersionVal();
	
		WhatifScreenVO whatifScreenVOYn= grossService.getVersionSeqId(GroupProfileSeqID,whatifVO.getVersionVal());
		
		if(whatifScreenVOYn != null) {			
			
		whatifVO = grossService.getWhatifDetails(GroupProfileSeqID,whatifScreenVOYn.getVersionSeqId(),whatifVO.getVersionVal(),"Y");
		}else {			
			whatifVO = grossService.getWhatifDetails(GroupProfileSeqID,0l,1l,"Y");
		}
		
		 
		
		
	/*	whatifVO = grossService.getWhatifDetails(GroupProfileSeqID,0l,1l,"Y");*/
		
		
	
	    SimpleDateFormat sd=new SimpleDateFormat("dd/MM/yyyy");
		
		if(whatifVO.getCoverageStartDate() !=null) {
			whatifVO.setCoverageStartDatestr(sd.format(whatifVO.getCoverageStartDate()));
		}
		
		if(whatifVO.getCoverageEndDate() !=null) {
			whatifVO.setCoverageEndDatestr(sd.format(whatifVO.getCoverageEndDate()));
		}
		
		ArrayList<CacheObject> alPricingNetworkList = pricingInputScreenService.getHospitalList("1");		 
		request.getSession().setAttribute("alPricingNetworkList", alPricingNetworkList);
		
		/*request.getSession().setAttribute("whatifScreenVO",whatifVO);*/
		
	
		
		request.setAttribute("tabval",varVal);
	/*	request.setAttribute("tabval",whatifVO.getVersionCount());*/
		whatifVO.setGroupProSeqId(GroupProfileSeqID);		
		whatifVO.setVersionSeqId(whatifScreenVOYn.getVersionSeqId());
		whatifVO.setVersionVal(varVal);
		modelandview.addObject("whatifScreenVO",whatifVO);
		return modelandview;
	}
	
	
	
	@RequestMapping(value ="estimateChange",  method = { RequestMethod.GET, RequestMethod.POST })
	public ModelAndView doEstimateChange(@Valid @ModelAttribute("whatifScreenVO") WhatifScreenVO whatifVO,BindingResult result, HttpServletRequest request,
			HttpServletResponse response, HttpSession session, Model model) throws Exception {
		ModelAndView modelandview=new ModelAndView(Whatif);
		 setErrorPageData(Whatif, model);
		 
         if(result.hasErrors()){				
			return modelandview;
		}	
     
		UserSecurityProfile userAccessSecurityProfile = (UserSecurityProfile) request.getSession()
				.getAttribute("userAccessSecurityProfile");				
		long userseqid = userAccessSecurityProfile.getUSER_SEQ_ID();		
		/*long GroupProfileSeqID = (long)request.getSession().getAttribute("groupPricingSeqId");*/		
		
		long GroupProfileSeqID = (long)request.getSession().getAttribute("groupPricingSeqId");
			
		SimpleDateFormat sd=new SimpleDateFormat("dd/MM/yyyy");		
		if(whatifVO.getCoverageStartDatestr() !=null && ! whatifVO.getCoverageStartDatestr().equals("")) {
			whatifVO.setCoverageStartDate(sd.parse(whatifVO.getCoverageStartDatestr()));	
			
		}		
		
		if(whatifVO.getCoverageEndDatestr() !=null && !whatifVO.getCoverageEndDatestr().equals("")) {
			whatifVO.setCoverageEndDate((sd.parse(whatifVO.getCoverageEndDatestr())));	
		}
		
		if(whatifVO.getNetworkcommon() != 4) {			
			whatifVO.setNetworkip(whatifVO.getNetworkcommon().toString());
			whatifVO.setNetworkop(whatifVO.getNetworkcommon().toString());
			whatifVO.setNetworkopt(whatifVO.getNetworkcommon().toString());
			whatifVO.setNetworkdnt(whatifVO.getNetworkcommon().toString());
			whatifVO.setNetworkmat(whatifVO.getNetworkcommon().toString());						
		}
		
		WhatifScreenVO whatifVO1= grossService.saveEstimateChange(whatifVO);		
	/*	whatifVO = grossService.getWhatifDetails(GroupProfileSeqID);*/
		if(whatifVO1.getResult() > 0) {
			modelandview.addObject("successMsg", "Details added successfully");
			WhatifScreenVO whatifScreenVOYn= grossService.getVersionSeqId(GroupProfileSeqID,whatifVO1.getVersionVal());
			
		
		whatifVO = grossService.getWhatifDetails(GroupProfileSeqID,whatifVO1.getVersionSeqId(),whatifVO1.getVersionVal(),whatifScreenVOYn.getSaveYn());
		
		whatifVO.setVersionVal(whatifVO1.getVersionVal());
		
		if(whatifVO.getCoverageStartDate() !=null) {
			whatifVO.setCoverageStartDatestr(sd.format(whatifVO.getCoverageStartDate()));
		}
		
		if(whatifVO.getCoverageEndDate() !=null) {
			whatifVO.setCoverageEndDatestr(sd.format(whatifVO.getCoverageEndDate()));
		}
		}else {
			
           WhatifScreenVO whatifScreenVOYn= grossService.getVersionSeqId(GroupProfileSeqID,whatifVO1.getVersionVal());
			
	
			
			whatifVO = grossService.getWhatifDetails(GroupProfileSeqID,whatifScreenVOYn.getVersionSeqId(),whatifVO1.getVersionVal(),whatifScreenVOYn.getSaveYn());
			if(whatifVO.getCoverageStartDate() !=null) {
				whatifVO.setCoverageStartDatestr(sd.format(whatifVO.getCoverageStartDate()));
			}
			
			if(whatifVO.getCoverageEndDate() !=null) {
				whatifVO.setCoverageEndDatestr(sd.format(whatifVO.getCoverageEndDate()));
			}
		}
		
	/*	request.setAttribute("tabval",whatifVO.getVersionCount());*/
		request.setAttribute("tabval",whatifVO.getVersionVal());
		modelandview.addObject("whatifScreenVO",whatifVO);
		return modelandview;
	}
	
	

	@RequestMapping(value ="saveWhatIfDetails",  method = { RequestMethod.GET, RequestMethod.POST })
	public ModelAndView saveWhatIfDetails(@ModelAttribute("whatifScreenVO") WhatifScreenVO whatifVO, HttpServletRequest request,
			HttpServletResponse response, HttpSession session, Model model) throws Exception {
		ModelAndView modelandview=new ModelAndView(Whatif);
		UserSecurityProfile userAccessSecurityProfile = (UserSecurityProfile) request.getSession()
				.getAttribute("userAccessSecurityProfile");				
		long userseqid = userAccessSecurityProfile.getUSER_SEQ_ID();		
				
		
		long GroupProfileSeqID = (long)request.getSession().getAttribute("groupPricingSeqId");
		request.setAttribute("tabval",whatifVO.getTabCount());
		SimpleDateFormat sd=new SimpleDateFormat("dd/MM/yyyy");
		Long saveStatus = grossService.saveWhatifDetails(GroupProfileSeqID,whatifVO.getVersionSeqId(),whatifVO.getVersionVal());
		
		if(saveStatus > 0) {
			modelandview.addObject("successMsg", "Details added successfully");
			
			 WhatifScreenVO whatifScreenVOYn= grossService.getVersionSeqId(GroupProfileSeqID,whatifVO.getVersionVal());
				
		whatifVO = grossService.getWhatifDetails(GroupProfileSeqID,whatifVO.getVersionSeqId(),whatifVO.getVersionVal(),whatifScreenVOYn.getSaveYn());
		if(whatifVO.getCoverageStartDate() !=null) {
			whatifVO.setCoverageStartDatestr(sd.format(whatifVO.getCoverageStartDate()));
		}
		
		if(whatifVO.getCoverageEndDate() !=null) {
			whatifVO.setCoverageEndDatestr(sd.format(whatifVO.getCoverageEndDate()));
		}
		}else {
			 WhatifScreenVO whatifScreenVOYn= grossService.getVersionSeqId(GroupProfileSeqID,whatifVO.getVersionVal());
			whatifVO = grossService.getWhatifDetails(GroupProfileSeqID,whatifScreenVOYn.getVersionSeqId(),whatifVO.getVersionVal(),whatifScreenVOYn.getSaveYn());
			if(whatifVO.getCoverageStartDate() !=null) {
				whatifVO.setCoverageStartDatestr(sd.format(whatifVO.getCoverageStartDate()));
			}
			
			if(whatifVO.getCoverageEndDate() !=null) {
				whatifVO.setCoverageEndDatestr(sd.format(whatifVO.getCoverageEndDate()));
			}
		}
		
		
		modelandview.addObject("whatifScreenVO",whatifVO);
		return modelandview;
	}
	

	@RequestMapping(value ="saveWhatIfDetailsChange",  method = { RequestMethod.GET, RequestMethod.POST })
	public ModelAndView saveWhatIfDetailsChage(@ModelAttribute("whatifScreenVO") WhatifScreenVO whatifVO, HttpServletRequest request,
			HttpServletResponse response, HttpSession session, Model model) throws Exception {
		ModelAndView modelandview=new ModelAndView(Whatif);
		UserSecurityProfile userAccessSecurityProfile = (UserSecurityProfile) request.getSession()
				.getAttribute("userAccessSecurityProfile");				
		long userseqid = userAccessSecurityProfile.getUSER_SEQ_ID();		
				
		
		long GroupProfileSeqID = (long)request.getSession().getAttribute("groupPricingSeqId");
		request.setAttribute("tabval",whatifVO.getTabCount());
		
		SimpleDateFormat sd=new SimpleDateFormat("dd/MM/yyyy");
		Long saveStatus = grossService.saveWhatIfDetailsChange(GroupProfileSeqID,whatifVO.getVersionSeqId(),whatifVO.getVersionVal());
		
		if(saveStatus > 0) {
			modelandview.addObject("successMsg", "Details added successfully");
			WhatifScreenVO whatifScreenVOYn= grossService.getVersionSeqId(GroupProfileSeqID,whatifVO.getVersionVal());
			
		
		whatifVO = grossService.getWhatifDetails(GroupProfileSeqID,whatifVO.getVersionSeqId(),whatifVO.getVersionVal(),whatifScreenVOYn.getSaveYn());
		if(whatifVO.getCoverageStartDate() !=null) {
			whatifVO.setCoverageStartDatestr(sd.format(whatifVO.getCoverageStartDate()));
		}
		
		if(whatifVO.getCoverageEndDate() !=null) {
			whatifVO.setCoverageEndDatestr(sd.format(whatifVO.getCoverageEndDate()));
		}
		}else {
	WhatifScreenVO whatifScreenVOYn= grossService.getVersionSeqId(GroupProfileSeqID,whatifVO.getVersionVal());
			
			whatifVO = grossService.getWhatifDetails(GroupProfileSeqID,whatifScreenVOYn.getVersionSeqId(),whatifVO.getVersionVal(),whatifScreenVOYn.getSaveYn());
			if(whatifVO.getCoverageStartDate() !=null) {
				whatifVO.setCoverageStartDatestr(sd.format(whatifVO.getCoverageStartDate()));
			}
			
			if(whatifVO.getCoverageEndDate() !=null) {
				whatifVO.setCoverageEndDatestr(sd.format(whatifVO.getCoverageEndDate()));
			}
		}
		
		modelandview.addObject("whatifScreenVO",whatifVO);
		return modelandview;
	}
	
	@RequestMapping(value ="activeTabVal",  method = { RequestMethod.GET, RequestMethod.POST })
	public ModelAndView getActiveTabDetails(@ModelAttribute("whatifScreenVO") WhatifScreenVO whatifVO,@RequestParam("tabval") String tabval, HttpServletRequest request,
			HttpServletResponse response, HttpSession session,  Model model) throws Exception {		
		ModelAndView modelandview=new ModelAndView(Whatif);		
		
		
		UserSecurityProfile userAccessSecurityProfile = (UserSecurityProfile) request.getSession()
				.getAttribute("userAccessSecurityProfile");	
		
		long userseqid = userAccessSecurityProfile.getUSER_SEQ_ID();
		
		long GroupProfileSeqID = (long)request.getSession().getAttribute("groupPricingSeqId");
		
		request.setAttribute("tabval",tabval);
		
		if(tabval.equals("1")) {
			    WhatifScreenVO whatifScreenVOYn= grossService.getVersionSeqId(GroupProfileSeqID,1l);				
			    if(whatifScreenVOYn != null) {
					
			    	   whatifVO = grossService.getWhatifDetails(GroupProfileSeqID,whatifScreenVOYn.getVersionSeqId(),1l,whatifScreenVOYn.getSaveYn());
					}else {
						whatifVO = grossService.getWhatifDetails(GroupProfileSeqID,0l,1l,"Y");
					}
				
		
		   
		   whatifVO.setVersionVal(1l);
		}else if(tabval.equals("2")) {
		    WhatifScreenVO whatifScreenVOYn= grossService.getVersionSeqId(GroupProfileSeqID,2l);				
					
		    if(whatifScreenVOYn != null) {
				
		    	   whatifVO = grossService.getWhatifDetails(GroupProfileSeqID,whatifScreenVOYn.getVersionSeqId(),2l,whatifScreenVOYn.getSaveYn());
				}else {
					whatifVO = grossService.getWhatifDetails(GroupProfileSeqID,0l,2l,"Y");
				}
		
			whatifVO.setVersionVal(2l);
			if(!request.getSession().getAttribute("finalCount").equals("")) {
			
			Integer tabCou = (Integer)request.getSession().getAttribute("finalCount"); 	
				if(tabCou != 3 ) {
					request.getSession().setAttribute("finalCount",2);
				}
		
			}
			
		}else if(tabval.equals("3")) {
			    WhatifScreenVO whatifScreenVOYn= grossService.getVersionSeqId(GroupProfileSeqID,3l);				
			    if(whatifScreenVOYn != null) {
					
			    	whatifVO = grossService.getWhatifDetails(GroupProfileSeqID,whatifScreenVOYn.getVersionSeqId(),3l,whatifScreenVOYn.getSaveYn());
					}else {
						whatifVO = grossService.getWhatifDetails(GroupProfileSeqID,0l,3l,"y");
					}
			
		
			whatifVO.setVersionVal(3l);
			request.getSession().setAttribute("finalCount",3);
		/*	request.setAttribute("finalCount","3");*/
		}
		 SimpleDateFormat sd=new SimpleDateFormat("dd/MM/yyyy");			
			if(whatifVO.getCoverageStartDate() !=null) {
				whatifVO.setCoverageStartDatestr(sd.format(whatifVO.getCoverageStartDate()));
			}
			
			if(whatifVO.getCoverageEndDate() !=null) {
				whatifVO.setCoverageEndDatestr(sd.format(whatifVO.getCoverageEndDate()));
			}
			
			ArrayList<CacheObject> alPricingNetworkList = pricingInputScreenService.getHospitalList("1");		 
			request.getSession().setAttribute("alPricingNetworkList", alPricingNetworkList);
			
			/*request.getSession().setAttribute("whatifScreenVO",whatifVO);*/
		
			whatifVO.setGroupProSeqId(GroupProfileSeqID);
			modelandview.addObject("whatifScreenVO",whatifVO);
		
		request.setAttribute("tabval",tabval);
		
		return modelandview;		
	}
	
	
	@Autowired
	private DataSource dataSource;
	
	
	
	@Autowired
	GrossService grossService;
	@Autowired
	public PricingInputScreenService pricingInputScreenService;
	
	

}

package com.vidal.controllers;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

import net.sf.jasperreports.engine.JREmptyDataSource;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JRExporterParameter;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.export.JRPdfExporter;
import net.sf.jasperreports.engine.export.JRXlsExporter;
import net.sf.jasperreports.engine.export.JRXlsExporterParameter;

import org.apache.log4j.Logger;
import org.apache.pdfbox.multipdf.PDFMergerUtility;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.reports.TTKReportDataSource;
import com.vidal.command.usermanagement.UserSecurityProfile;
import com.vidal.common.UXUtility;
import com.vidal.common.VidalCommon;
import com.vidal.common.controller.vidalcontroller.VidalController;
import com.vidal.common.reports.TTKPropertiesReader;
@Controller
@RequestMapping("Reports")
public class ReportController extends VidalController{
	 private static final Logger log = Logger.getLogger( ReportController.class );
	 
	 private static final String strPreAuth="Pre-Authorization";
	 private static final String strOPDPreAuth="OPD Pre-Authorization";
/*	@RequestMapping("doGenerateReport")
	 public ModelAndView doGenerateReport(HttpServletRequest request,HttpServletResponse response) throws Exception{

		 try{
			 String strActiveLink=VidalCommon.getActiveLink(request);
			 
			 UserSecurityProfile userSecurityProfile = (UserSecurityProfile)request.getSession().getAttribute("userAccessSecurityProfile");
			
			 JasperReport jasperReport,jasperReport1,jasperReport2,emptyReport;
			 JasperPrint jasperPrint;
			 JasperPrint jasperPrint1=null;
			 JasperPrint jasperPrint2=null;
			 String strPath = "";
			 String strPdfFile="";
			 String strUserID="";//added for KOC-1267
			 TTKReportDataSource ttkReportDataSource = null;
			 TTKReportDataSource ttkReportDataSource1 = null;
			 TTKReportDataSource ttkReportDataSource2 = null;
			 String strParam = "";
			 String strFinParam = "";
			 if(request.getParameter("reportID").equalsIgnoreCase("SupDispRpt"))
			 {
				 strParam = request.getParameter("parameter").replaceAll("__","&");
			 }//end of if(request.getParameter("reportID").equalsIgnoreCase("SupDispRpt"))
			 else if(request.getSession().getAttribute("parameter") != null)
			 {
				 strParam =(String) request.getSession().getAttribute("parameter");
			 }
			 else {
				 strParam = request.getParameter("parameter");
			 }//end of else
			 if(request.getSession().getAttribute("parameter") != null)
			 {
				 strFinParam = request.getSession().getAttribute("parameter")+"F|";
			 }
			 else
			 {
			 strFinParam = request.getParameter("parameter")+"F|";
			 }
			 String jrxmlfile=request.getParameter("fileName");
			 String strComplete = request.getParameter("completedYN");
			 if(request.getParameter("reportID").equalsIgnoreCase("SupDispRpt"))
			 {
				 ttkReportDataSource = new TTKReportDataSource(request.getParameter("reportID"),strParam,dataSource);
			 }//end of if(request.getParameter("reportID").equalsIgnoreCase("SupDispRpt"))
			 else if(request.getParameter("reportID").equalsIgnoreCase("76ColPend") || request.getParameter("reportID").equalsIgnoreCase("FinPenRpt"))
			 {
				 log.debug("76 column report parameter"+strFinParam);
				 ttkReportDataSource = new TTKReportDataSource(request.getParameter("reportID"),strFinParam,dataSource);
			 }//end of else if(request.getParameter("reportID").equalsIgnoreCase("76ColPend") || request.getParameter("reportID").equalsIgnoreCase("FinPenRpt"))
			 else if(request.getParameter("reportID").equalsIgnoreCase("CitiFinDetRpt"))
			 {
				if(request.getParameter("reportType").equals("EXL"))
				 {
					 jrxmlfile = "reports/finance/CitibankClaimsDetailEXL.jrxml";
				 }//end of if(request.getParameter("reportType").equals("EXL"))
				 else if(request.getParameter("reportType").equals("PDF"))
				 {
					 jrxmlfile = "reports/finance/CitibankClaimsDetail.jrxml";
				 }//end of else if(request.getParameter("reportType").equals("PDF"))
				 ttkReportDataSource = new TTKReportDataSource(request.getParameter("reportID"),strParam,dataSource);
			 }//end of if(request.getParameter("reportID").equalsIgnoreCase("CitiFinDetRpt"))
			 
			 
			 else if(request.getParameter("reportID").equalsIgnoreCase("HospitalPODMISreport"))
			 {

				 
				 jrxmlfile = "reports/claims/HospitalPODMISreport.jrxml";
				 ttkReportDataSource = new TTKReportDataSource(request.getParameter("reportID"),strParam,dataSource);
			 }
			 else if(request.getParameter("reportID").equalsIgnoreCase("FurGenRpt"))
			 {
				 jrxmlfile = "reports/finance/FutureGeneraliReport.jrxml";
				 ttkReportDataSource = new TTKReportDataSource(request.getParameter("reportID"),strParam,dataSource);
			 }//end of if(request.getParameter("reportID").equalsIgnoreCase("FurGenRpt"))
			  //Added for KOC-1267
			 else if(request.getParameter("reportID").equalsIgnoreCase("ClaimViewHis"))
			 {		
				 
				 strUserID = userSecurityProfile.getUSER_ID();
				 strParam = strParam.concat((new StringBuffer(strUserID+"|")).toString());
				 ttkReportDataSource = new TTKReportDataSource(request.getParameter("reportID"),strParam,dataSource);
			 }
			 else if(request.getParameter("reportID").equalsIgnoreCase("HospitalLoginLogRpt"))
			 {
				 jrxmlfile = request.getParameter("fileName");
				 ttkReportDataSource = new TTKReportDataSource(request.getParameter("reportID"),strParam,dataSource);
			 }//added by suman hospital report changes
			 else if(request.getParameter("reportID").equalsIgnoreCase("HospitalWebLoginRpt"))
			 {
				 jrxmlfile = request.getParameter("fileName");
				 ttkReportDataSource = new TTKReportDataSource(request.getParameter("reportID"),strParam,dataSource);
			 }
			 else if(request.getParameter("reportID").equalsIgnoreCase("HospitalWebLoginSummaryRpt"))
			 {
				 jrxmlfile = request.getParameter("fileName");
				 ttkReportDataSource = new TTKReportDataSource(request.getParameter("reportID"),strParam,dataSource);
			 }//Ended
			 else if(request.getParameter("reportID").equalsIgnoreCase("AuthRejLetter"))
			 {				 
				 strUserID = userSecurityProfile.getUSER_ID();
				 strParam = strParam.concat((new StringBuffer(strUserID+"|")).toString());
				 ttkReportDataSource = new TTKReportDataSource("AuthLetter",strParam,dataSource);
			 }
			 else if(request.getParameter("reportID").equalsIgnoreCase("AuthCanLetter"))
			 {				 
				 ttkReportDataSource = new TTKReportDataSource(request.getParameter("reportID"),request.getParameter("parameter"),dataSource);
			 }
			 else
			 {
				 ttkReportDataSource = new TTKReportDataSource(request.getParameter("reportID"),strParam,dataSource);
				 if((request.getParameter("reportID").equalsIgnoreCase("AuthLetter"))){
				 ttkReportDataSource1 = new TTKReportDataSource("ClaimFormB",request.getParameter("parameter"),dataSource);
				 ttkReportDataSource2 = new TTKReportDataSource("AuthAprLetterLineItems",request.getParameter("parameter"),dataSource);
				 }
			 }//end of else
			 if(PreAuthWebBoardHelper.getWebBoardDesc(request) != null){
				
			   String filename = UXUtility.checkNull(PreAuthWebBoardHelper.getWebBoardDesc(request));
			   String preauthQrCodePath = UXUtility.getPropertyValue("preauthqrpath");
			   UXUtility.generateQRCodeImage(filename, 100, 100, preauthQrCodePath);
			 }
			 
			   strPdfFile = TTKPropertiesReader.getPropertyValue("authorizationrptdir")+request.getParameter("authorizationNo")+".pdf";
			   String strPdfFile2 = TTKPropertiesReader.getPropertyValue("authorizationrptdir")+"computation/"+request.getParameter("authorizationNo")+".pdf";
			  
			 String strPdfFile1 = TTKPropertiesReader.getPropertyValue("authorizationrptdir")+"claimformb/"+request.getParameter("authorizationNo")+".pdf";
			 try
			 {
				
				 jasperReport = JasperCompileManager.compileReport(jrxmlfile);
				 jasperReport2 = JasperCompileManager.compileReport("product/generalreports/AuthAprLetterSub.jrxml");
				 jasperReport1 = JasperCompileManager.compileReport("product/generalreports/Claim_Form_B.jrxml");
				 emptyReport = JasperCompileManager.compileReport("product/generalreports/EmptyReprot.jrxml");
				HashMap<String, Object> hashMap = new HashMap<String, Object>();
				HashMap<String, Object> hashMap2 = new HashMap<String, Object>();
				 ByteArrayOutputStream boas=new ByteArrayOutputStream();
				 hashMap.put("Start Date",request.getParameter("startDate"));
				 hashMap.put("End Date",request.getParameter("endDate"));
				 if(request.getParameter("reportID").equals("GenRenMemXLs")) {
					 hashMap.put("parameter",strParam);
				 }//end of if(request.getParameter("reportID").equals("GenRenMemXLs")
				 else if(request.getParameter("reportID").equals("EnrDaiBOI")){
					 hashMap.put("Policy Number",request.getParameter("policyNumber"));					 
				 }//end of else if(request.getParameter("reportID").equals("")){
				 else if(request.getParameter("reportID").equals("SoftCopyUploadError"))
				 {
					 hashMap.put("Status", request.getParameter("status"));
				 }//end of else if(request.getParameter("reportID").equals("SoftCopyUploadError"))
				 else {
					 hashMap.put("parameter",strParam.substring(2,strParam.length()));
				 }//end of else
				 
				 strPath = TTKPropertiesReader.getPropertyValue("SignatureImgPath");
				 
				 ////////////////////////ADDED FOR CLAIM FORM B//////////////////////////
				 if((request.getParameter("reportID").equalsIgnoreCase("AuthLetter"))){
				 HashMap<String, String> hashMap1 = new HashMap<String, String>();
				 ResultSet rs = ttkReportDataSource1.getResultData();
				 if(rs != null)
				 {
					 if(rs.next())
					{
					 //Hospital Name Start
					String hname1 =rs.getString("hosp_name");
					if(hname1 != null)
					{
					char[] hName=hname1.toCharArray();
					
						for(int i=0;i<hName.length;i++)
						{
							hashMap1.put("HpName"+i,(Character.toString(hName[i])).toUpperCase());	
							if(i==75)
								 break;					
						}
					 }
					//Hospital Name End
					//Hospital Id Start
					String hpId1 = rs.getString("empanel_number");
					if(hpId1 != null)
					{					
						String hpId2 = hpId1.replaceAll("-","");
					
						char[] hpId=hpId2.toCharArray();
						for(int i=0;i<hpId.length;i++)
						{
							hashMap1.put("HpId"+i,(Character.toString(hpId[i])));	
							if(i==11)
							break;					
						}
					}					
					//Hospital Id End
					//Patient Name start
					String pName1 =rs.getString("patient_name");
					if(pName1 != null)
					{
					char[] pName=pName1.toCharArray();
					
						for(int i=0;i<pName.length;i++)
						{
							hashMap1.put("PatName"+i,(Character.toString(pName[i])).toUpperCase());	
							if(i==37)
								 break;					
						}
					 }
					//Patient Name End
					//Date Of Admission Start
					String authDate1 = rs.getString("date_of_admission");
					if(authDate1 != null)
					{	
					String authDate2 = authDate1.replaceAll("/","");
					String authDate3 = authDate2.replaceAll(":","");
					String authDate4 = authDate3.replaceAll(" ","");
					char[] authDate=authDate4.toCharArray();
					
						for(int j=0;j<authDate.length;j++)
						{
							hashMap1.put("DoA"+j,(Character.toString(authDate[j])));	
						}
					}
					//Date Of Admission End
					//Date Of Discharge Start
					String dischargeDate1 = rs.getString("probable_date_of_discharge");
					if(dischargeDate1 != null)
					{
					String dischargeDate2 = dischargeDate1.replaceAll("/","");
					String dischargeDate3 = dischargeDate2.replaceAll(":","");
					String dischargeDate4 = dischargeDate3.replaceAll(" ","");
					char[] dischargeDate=dischargeDate4.toCharArray();
					
						for(int j=0;j<dischargeDate.length;j++)
						{
							hashMap1.put("DoD"+j,(Character.toString(dischargeDate[j])));	
						}
					}
					//Date Of Discharge End
					//Autherized Amount Start
					String amount1=rs.getString("final_approved_amt");
					if(amount1 != null)
					{
					String amount = amount1.replaceAll(",","");
					 char[] authAmount=amount.toCharArray();
					 
						 for(int i=0;i<authAmount.length;i++)
						 {
							 hashMap1.put("TClAmount"+i,(Character.toString(authAmount[i])));
							 if(i==6)
								 break;
						 }
					 }
					//Autherized Amount End
					//Primary Diagnosis  Start
					String primarydig=rs.getString("provisional_diagnosis");
					if(primarydig != null)
					{
						hashMap1.put("PrimaryDig",primarydig);
					}
					//Primary Diagnosis End
					//Address Start
					String address1=rs.getString("address");
					if(address1 != null)
					{
					char[] address=address1.toCharArray();
					
						for(int i=0;i<address.length;i++)
						{
							hashMap1.put("Address"+i,(Character.toString(address[i])).toUpperCase());	
							if(i==75)
								 break;					
						}
					 }
					//Address End
					//City Start
					String city1=rs.getString("city");
					if(city1 != null)
					{
					char[] city=city1.toCharArray();
					
						for(int i=0;i<city.length;i++)
						{
							hashMap1.put("City"+i,(Character.toString(city[i])).toUpperCase());	
							if(i==16)
								 break;					
						}
					 }
					//City End
					//State Start
					String state1=rs.getString("state");
					if(state1 != null)
					{
					char[] state=state1.toCharArray();
					
						for(int i=0;i<state.length;i++)
						{
							hashMap1.put("State"+i,(Character.toString(state[i])).toUpperCase());	
							if(i==17)
								 break;					
						}
					 }
				
					//State End
					//Pincode Start
					String pin=rs.getString("pin_code");
					if(pin != null)
					{
					char[] pincode=pin.toCharArray();
					
						for(int i=0;i<pincode.length;i++)
						{
							hashMap1.put("Pincode"+i,(Character.toString(pincode[i])));	
							if(i==5)
								 break;					
						}
					}
			
					//Pincode End
					 String strpreauthno=ttkReportDataSource1.getResultData().getString("preauthorisation_no");
						
						byte[] qrCodeBytes=UXUtility.generateQRCodeImage(strpreauthno, 100, 100);
						 hashMap.put("qrCodeImage", new ByteArrayInputStream(qrCodeBytes));
					ttkReportDataSource1.getResultData().beforeFirst();
					jasperPrint1 = JasperFillManager.fillReport(jasperReport1, hashMap1,ttkReportDataSource1);
				
					}
				 }
				 }
				 	
				 
				 hashMap.put("SigPath",strPath);
				 String finalapprovalYN ="";
				 if((request.getParameter("reportID").equalsIgnoreCase("AuthLetter"))){
					  finalapprovalYN = request.getParameter("finalapprovalYN");
					  if(finalapprovalYN == null)
					  {
						  finalapprovalYN="N";
					  }
					  if(finalapprovalYN.equalsIgnoreCase("Y") && strComplete.equalsIgnoreCase("Y"))
					  {
						  String strpreauthno=ttkReportDataSource2.getResultData().getString("preauthorisation_no");
							
							byte[] qrCodeBytes=UXUtility.generateQRCodeImage(strpreauthno, 100, 100);
							 hashMap.put("qrCodeImage", new ByteArrayInputStream(qrCodeBytes));
					 ttkReportDataSource2.getResultData().beforeFirst();
						jasperPrint2 = JasperFillManager.fillReport(jasperReport2,hashMap2,ttkReportDataSource2);
					  }
					 }
				 if(ttkReportDataSource.getResultData().next())
				 {
					 String strpreauthno=ttkReportDataSource.getResultData().getString("preauthorisation_no");
						
						byte[] qrCodeBytes=UXUtility.generateQRCodeImage(strpreauthno, 100, 100);
						 hashMap.put("qrCodeImage", new ByteArrayInputStream(qrCodeBytes));

					 ttkReportDataSource.getResultData().beforeFirst();
					 jasperPrint = JasperFillManager.fillReport( jasperReport, hashMap,ttkReportDataSource);					 
				 }//end of if(ttkReportDataSource.getResultData().next()))
				 else
				 {		 
					 jasperPrint = JasperFillManager.fillReport( emptyReport, hashMap,new JREmptyDataSource());
					 if(request.getParameter("reportID").equalsIgnoreCase("76ColPend") || request.getParameter("reportID").equalsIgnoreCase("FinPenRpt"))
					 {
						 log.debug("76 column report parameter jasperPrint    ::::::::::"+strFinParam);
						 jasperPrint = JasperFillManager.fillReport( jasperReport, hashMap,new TTKReportDataSource(request.getParameter("reportID"),strFinParam));
					 }//end of if(request.getParameter("reportID").equalsIgnoreCase("76ColPend") || request.getParameter("reportID").equalsIgnoreCase("FinPenRpt"))
					 else if(request.getParameter("reportID").equalsIgnoreCase("SupDispRpt"))
					 {
						 jasperPrint = JasperFillManager.fillReport( jasperReport, hashMap,new TTKReportDataSource(request.getParameter("reportID"),strParam));
					 }//end of if(request.getParameter("reportID").equalsIgnoreCase("SupDispRpt"))
					 else
					 {
						 jasperPrint = JasperFillManager.fillReport( jasperReport, hashMap,new TTKReportDataSource(request.getParameter("reportID"),request.getParameter("parameter")));
					 }//end of else
					 
				 }//end of if(ttkReportDataSource.getResultData().next())
				 

				 if(request.getParameter("reportType").equals("EXL"))//if the report type is Excel
				 {
					 JRXlsExporter jExcelApiExporter = new JRXlsExporter();
					 jExcelApiExporter.setParameter(JRXlsExporterParameter.JASPER_PRINT,jasperPrint);
					 jExcelApiExporter.setParameter(JRXlsExporterParameter.OUTPUT_STREAM, boas);
					 jExcelApiExporter.setParameter(JRXlsExporterParameter.IS_ONE_PAGE_PER_SHEET, Boolean.FALSE);
					 jExcelApiExporter.setParameter(JRXlsExporterParameter.IS_DETECT_CELL_TYPE, Boolean.TRUE);
					 jExcelApiExporter.setParameter(JRXlsExporterParameter.IS_WHITE_PAGE_BACKGROUND, Boolean.FALSE);
					 jExcelApiExporter.setParameter(JRXlsExporterParameter.IS_REMOVE_EMPTY_SPACE_BETWEEN_ROWS, Boolean.TRUE);
					 jExcelApiExporter.exportReport();
				 }//end of if(request.getParameter("reportType").equals("EXL"))
				 else//if report type if PDF
				 {
					 if(request.getParameter("reportID").equalsIgnoreCase("AuthLetter"))
					 {
						 if((strActiveLink.equals(strPreAuth) && strComplete.equals("Y")) || (strActiveLink.equals(strOPDPreAuth) && strComplete.equals("Y")))
						 {
						 List<JasperPrint> jasperPrints = new ArrayList<JasperPrint>();
						 jasperPrints.add(jasperPrint);
						  if(finalapprovalYN.equalsIgnoreCase("Y") && strComplete.equalsIgnoreCase("Y"))
						  {
						 jasperPrints.add(jasperPrint2);
						  }
						 jasperPrints.add(jasperPrint1);
						 
						 JasperExportManager.exportReportToPdfFile(jasperPrint,strPdfFile);
						 if(finalapprovalYN.equalsIgnoreCase("Y") && strComplete.equalsIgnoreCase("Y"))
						  {
						 JasperExportManager.exportReportToPdfFile(jasperPrint2,strPdfFile2);
						  }
						 JasperExportManager.exportReportToPdfFile(jasperPrint1,strPdfFile1);
						 
						 PDFMergerUtility ut = new PDFMergerUtility();
						 ut.addSource(strPdfFile);
						 if(finalapprovalYN.equalsIgnoreCase("Y") && strComplete.equalsIgnoreCase("Y"))
						  {
						 ut.addSource(strPdfFile2);
						  }
						 ut.addSource(strPdfFile1);
						 ut.setDestinationFileName(strPdfFile1);
						 ut.mergeDocuments();
						 
						 JRPdfExporter exporter = new JRPdfExporter();
						 exporter.setParameter(JRExporterParameter.JASPER_PRINT_LIST, jasperPrints);
						 exporter.setParameter(JRExporterParameter.OUTPUT_STREAM, boas);
						 exporter.exportReport();
						 
						//To save the preauth approval letter and computation letter merged file in the below specified path
						 
				     		 if(finalapprovalYN.equalsIgnoreCase("Y") && strComplete.equalsIgnoreCase("Y"))
				     		 { 
								 PDFMergerUtility ut1 = new PDFMergerUtility();
								 ut1.addSource(strPdfFile); 
								 ut1.addSource(strPdfFile2); 
								 ut1.setDestinationFileName(strPdfFile);
								 ut1.mergeDocuments(); 
				     		 }
				     	 
						 } 
					 }//end of if((request.getParameter("reportID").equalsIgnoreCase("AuthLetter")) && (strActiveLink.equals(strPreAuth)
					 else
					 {
						 JasperExportManager.exportReportToPdfStream(jasperPrint,boas);
					 }
					 
					 if(request.getParameter("reportID").equalsIgnoreCase("AuthRejLetter"))
					 {
						 if((strActiveLink.equals(strPreAuth) && strComplete.equals("Y")) || (strActiveLink.equals(strOPDPreAuth) && strComplete.equals("Y")))
						 {
							 JasperExportManager.exportReportToPdfFile(jasperPrint,strPdfFile);
						 }
					 }//end of  if((request.getParameter("reportID").equalsIgnoreCase("AuthRejLetter")) && (strActiveLink.equals(strPreAuth)

					 if((request.getParameter("reportID").equalsIgnoreCase("AuthCanLetter")) && (strActiveLink.equals(strPreAuth) 
							 && strComplete.equals("Y")))
					 {
						 JasperExportManager.exportReportToPdfFile(jasperPrint,strPdfFile);
					 }//end of  if((request.getParameter("reportID").equalsIgnoreCase("AuthRejLetter")) && (strActiveLink.equals(strPreAuth)

				 }//end of else
				 request.setAttribute("boas",boas);
			 }//end of try
			 catch (JRException e)
			 {
				 e.printStackTrace();
			 }//end of catch(JRException e)
			 catch (Exception e)
			 {
				 e.printStackTrace();
			 }//end of catch (Exception e)
			 return new ModelAndView("forward:/binaryFile");
		 }//end of try
	    catch(Throwable throwable){
	    	request.setAttribute("failurePage","true");
		return processErrorView("failure",throwable);
	  }
		 
	 }
	*/

	@Autowired
	public DataSource dataSource;
}

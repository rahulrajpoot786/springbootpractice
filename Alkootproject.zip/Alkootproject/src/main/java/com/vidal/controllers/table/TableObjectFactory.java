package com.vidal.controllers.table;

import java.io.Serializable;

import com.vidal.controllers.table.Pricing.PolicyGroupTable;
import com.vidal.controllers.table.Pricing.SwInsurancePricingTable;
import com.vidal.controllers.table.preauth.preauthDashboard.DataEntryActiveUsers;



/**
 *   This creates the appropriate table object based
 *   on the specified indicator
 *
 */
public class TableObjectFactory implements Serializable
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * This creates the appropriate table objects based
	 * on the specified indicator
	 *
	 * @param sIndicator String identifier to create table
	 * @return Table object
	 */
	//public static TableObjectInterface getTableObject(String sIndicator)
	public static Table getTableObject(String sIndicator)
	{
	    
	     
	   if(sIndicator.equalsIgnoreCase("SwInsurancePricingTable")){
	    	return new SwInsurancePricingTable();
	    }else if (sIndicator.equalsIgnoreCase("PolicyGroupTable")) {
	    	
	    	 return new PolicyGroupTable();
	    }
	  	     	   
		else
		{
			return null;
		}//end of if
	}//end of getTableObject method
}//end of class TableObjectFactory

package com.vidal.controllers.pricing;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;


import com.vidal.command.pricing.InsPricingVO;
import com.vidal.command.pricing.SwPolicyConfigVO;
import com.vidal.command.usermanagement.UserSecurityProfile;
import com.vidal.common.UXUtility;
import com.vidal.common.VidalCommon;
import com.vidal.common.controller.vidalcontroller.VidalController;
import com.vidal.common.exception.GetErrorMessage;
import com.vidal.common.exception.VidalException;
import com.vidal.services.pricing.PricingRiskPreimiumService;

@Controller
public class RiskPreimiumController extends VidalController{
	private static Logger logger = Logger.getLogger(RiskPreimiumController.class);
	@Autowired
	public PricingRiskPreimiumService pricingRiskPreimiumService;
	
	private static final String strRiskPremiumScreen = "riskprimimumscreen";
	private static final String strPricingGross="pricing.Gross";
	
	@RequestMapping(value ="/SoftwareInsurancePricing/RiskPremium-Working" , method = RequestMethod.POST) 
	public ModelAndView defaltRiskPremium(@ModelAttribute("swPolicyConfigVO") SwPolicyConfigVO swPolicyConfigVO,HttpServletRequest request,BindingResult result,Model model)throws Exception{		
		setLinks(request);
		ModelAndView modelAndView = new ModelAndView(strRiskPremiumScreen);	
		setErrorPageData(strRiskPremiumScreen, model);	
											
		Long GroupProfileSeqID = null;
				
		String completeSaveYN = (String)request.getSession().getAttribute("completeSaveYN");
		if(completeSaveYN.equals("N"))
			 return new ModelAndView("failure","GLOBAL_ERROR",GetErrorMessage.getValue("error.pricing.complete.screen"));	
		UserSecurityProfile userAccessSecurityProfile = (UserSecurityProfile) request.getSession()
				.getAttribute("userAccessSecurityProfile");	
		userAccessSecurityProfile.getSecurityProfile().setActiveTab("Risk Premium-Working");
		
		long userseqid = userAccessSecurityProfile.getUSER_SEQ_ID();		
		
		if(!request.getSession().getAttribute("groupPricingSeqId").equals("")) {
			GroupProfileSeqID = (long)request.getSession().getAttribute("groupPricingSeqId");
		}else {		
			return new ModelAndView("failure","GLOBAL_ERROR",GetErrorMessage.getValue("error.pricing.complete.screen"));
		}
		
		request.getSession().setAttribute("savePropflag","");		
		request.getSession().setAttribute("durationcheck","");	
		
		request.getSession().setAttribute("alResultpastYear","");		
		request.getSession().setAttribute("alProClaimData","");	
		
		request.getSession().setAttribute("addedDateForRiskPremium","");		
		request.getSession().setAttribute("alDemographicData","");	
	
/*		String completeSaveYN = (String)request.getSession().getAttribute("completeSaveYN");*/
		
		ArrayList  alplanDesignList = new ArrayList();
		ArrayList  alLoadDesignList = new ArrayList();
		ArrayList  alLoadDesignList1 = new ArrayList();
		ArrayList  alLoadDesignList2 = new ArrayList();
		ArrayList aldemographicDataList = new ArrayList();
		InsPricingVO insPricingVO = new InsPricingVO();
		boolean durationcheck=true;
		String addedDate=null;
		swPolicyConfigVO =  new SwPolicyConfigVO();
		
		  insPricingVO  =  pricingRiskPreimiumService.getfalgPricingvalue(GroupProfileSeqID);		  			  		 		  
		  if(insPricingVO.getCompleteSaveYNInSc2().equalsIgnoreCase("N") || insPricingVO.getCompleteSaveYNInSc2().equalsIgnoreCase("")) {
				 return new ModelAndView("failure","GLOBAL_ERROR",GetErrorMessage.getValue("error.pricing.complete.screen"));			
			}
		  
		  modelAndView.addObject("copydataflag",insPricingVO.getCopydataflag());
		   request.getSession().setAttribute("renevalFlag",insPricingVO.getRenevalFlag()); 		  
		  String demographicDataFlag = insPricingVO.getDemographicflagYN();
		  addedDate=insPricingVO.getRiskPremiumDate();
		  String calCPM_FlagYN = insPricingVO.getCalCPMFlagYN();
		  String loadingFlagYN = insPricingVO.getLoadingFlagYN();
		
		  insPricingVO.setGroupProfileSeqID(GroupProfileSeqID);
		  insPricingVO.setAddedBy((userseqid));
		/*  try {	*/
		  if(insPricingVO.getCompleteSaveYNInSc2().equalsIgnoreCase("Y"))
			  aldemographicDataList= pricingRiskPreimiumService.getdemographicData(insPricingVO,demographicDataFlag);
		  
			if(GroupProfileSeqID > 0  && completeSaveYN.equalsIgnoreCase("Y") && insPricingVO.getCompleteSaveYNInSc2().equalsIgnoreCase("Y"))
			{
				if(calCPM_FlagYN.equalsIgnoreCase("Y")){
					alplanDesignList= pricingRiskPreimiumService.getcpmAfterCalcultion(insPricingVO);	
					alLoadDesignList1 = (ArrayList) alplanDesignList.get(0);
					alLoadDesignList2 = (ArrayList) alplanDesignList.get(1);
					}else{
					alplanDesignList= pricingRiskPreimiumService.getcpmBeforeCalcultion(insPricingVO);//to get CPM Data							
					alLoadDesignList1 = (ArrayList) alplanDesignList.get(0);
					alLoadDesignList2 = (ArrayList) alplanDesignList.get(1);
					}
				
				if(loadingFlagYN.equalsIgnoreCase("Y"))
				{
					alLoadDesignList= pricingRiskPreimiumService.getAfterLoadingData(insPricingVO);	
				}else{
					alLoadDesignList= pricingRiskPreimiumService.getBeforeLoadingData(insPricingVO);//to get Loading data	
				}				
			}		  
			SwPolicyConfigVO  swPolicyConfigVOfinalDesign= pricingRiskPreimiumService.getcpmAfterLoading(insPricingVO);// final Data so no Flag condition required			
			if(swPolicyConfigVOfinalDesign != null){							 
			   request.setAttribute("frmSwPolicyConfig", swPolicyConfigVOfinalDesign);
			}		
			
			for(Object swPolicyConfig:aldemographicDataList){
				SwPolicyConfigVO swPolicyConfigVO2=(SwPolicyConfigVO) swPolicyConfig;				
				if(!swPolicyConfigVO2.getDataType().equals("USR_IP_YR") && !swPolicyConfigVO2.getDataType().equals("PROJ_DTA")) {
				if(!swPolicyConfigVO2.getDemoPolicyDurationPerMonth().trim().equals("12") && !swPolicyConfigVO2.getDemoPolicyDurationPerMonth().equals("")) {					
					durationcheck = false;
					break;					
				}
				}
			}
			
			/*for(Object swPolicyConfig:alLoadDesignList1){
				SwPolicyConfigVO swPolicyConfigVO2=(SwPolicyConfigVO) swPolicyConfig;
				System.out.println("swPolicyConfig..doc type...."+swPolicyConfigVO2.getDataType());
				System.out.println("maternityCPM::"+swPolicyConfigVO2.getMaternityCPM());
				
				
				
				
				
				Date coverageStartDate=swPolicyConfigVO2.getPolicyEffDate();
				Date coverageEndDate=swPolicyConfigVO2.getPolicyExpDate();
				
				
				if(!swPolicyConfigVO2.getDataType().equals("USR_IP_YR") && !swPolicyConfigVO2.getDataType().equals("PROJ_DTA")) {
				if(coverageEndDate!=null && coverageStartDate!=null){
					
					System.out.println("swPolicyConfigVO2. duration month.."+swPolicyConfigVO2.getDemoPolicyDurationPerMonth());
				durationcheck=getDiffYears(coverageStartDate,coverageEndDate);
				System.out.println("coverageStartDate::"+coverageStartDate+"coverageEndDate::"+coverageEndDate+"---durationcheck::"+durationcheck);
				if(durationcheck==false){	
					break;
				}
				}
				}
			}*/
			
			
			
			SwPolicyConfigVO  swCommentDetails=pricingRiskPreimiumService.getComment(GroupProfileSeqID);
			
		
			
			modelAndView.addObject("projectClaimComment", swCommentDetails.getProjectClaimComment());
			
			String savePropFlag = pricingRiskPreimiumService.getGetProposed(GroupProfileSeqID);
			/*request.setAttribute("alDemographicData",aldemographicDataList);
		
			request.setAttribute("alResultpastYear", alplanDesignList);
			request.setAttribute("addedDateForRiskPremium", addedDate);
		    //frmSwPolicyConfig.set("alLoadingData", alLoadDesignList);
			request.setAttribute("alertMsg", (((SwPolicyConfigVO)alplanDesignList.get(0)).getAlertMsg()));
			request.setAttribute("pricingNumberAlert", pricingNumberAlert);
	       	request.getSession().setAttribute("GroupProfileSeqID", GroupProfileSeqID); 
	      	request.getSession().setAttribute("durationcheck", durationcheck); 		*/
			
			request.getSession().setAttribute("savePropflag", savePropFlag);		
			request.getSession().setAttribute("durationcheck", durationcheck);	
			
			request.getSession().setAttribute("alResultpastYear", alLoadDesignList1);		
			request.getSession().setAttribute("alProClaimData", alLoadDesignList2);	
			
			request.getSession().setAttribute("addedDateForRiskPremium", insPricingVO.getRiskPremiumDate());		
			request.getSession().setAttribute("alDemographicData", aldemographicDataList);	
			
			/*request.setAttribute("alResultpastYear", alLoadDesignList1);
			request.setAttribute("alProClaimData", alLoadDesignList2);
		    model.addAttribute("addedDateForRiskPremium",insPricingVO.getRiskPremiumDate());		
		    request.setAttribute("alDemographicData",aldemographicDataList);*/
		    modelAndView.addObject("swPolicyConfigVO", new SwPolicyConfigVO());		
		
		return modelAndView;
	/*	}catch(Throwable throwable) {
			request.getSession().setAttribute("savePropflag","");		
			request.getSession().setAttribute("durationcheck","");	
			
			request.getSession().setAttribute("alResultpastYear","");		
			request.getSession().setAttribute("alProClaimData","");	
			
			request.getSession().setAttribute("addedDateForRiskPremium","");		
			request.getSession().setAttribute("alDemographicData","");	
								
			return processErrorView(strRiskPremiumScreen, throwable);												
		}*/
	}

	@RequestMapping(value ="/SoftwareInsurancePricing/doSaveCalculate" , method = RequestMethod.POST)
	public ModelAndView doSaveCalculate(@ModelAttribute("swPolicyConfigVO") SwPolicyConfigVO swPolicyConfigVO,@RequestParam("focusId")String focusId, HttpServletRequest request,Model model,BindingResult result) throws Exception{		
		ModelAndView modelAndView = new ModelAndView(strRiskPremiumScreen);	
		setLinks(request);	
		setErrorPageData(strRiskPremiumScreen, model);			
		
		if(result.hasErrors()){				
			return modelAndView;
		}	
		ArrayList  alLoadDesignList1 = new ArrayList();
		ArrayList  alLoadDesignList2 = new ArrayList();
		UserSecurityProfile userAccessSecurityProfile = (UserSecurityProfile) request.getSession()
				.getAttribute("userAccessSecurityProfile");				
		long userseqid = userAccessSecurityProfile.getUSER_SEQ_ID();		
		long GroupProfileSeqID = (long)request.getSession().getAttribute("groupPricingSeqId");
		swPolicyConfigVO.setLngGroupProfileSeqID(GroupProfileSeqID);
		InsPricingVO insPricingVO  = new InsPricingVO();
		swPolicyConfigVO.setAddedBy(userseqid);	
		insPricingVO.setGroupProfileSeqID(GroupProfileSeqID);
		insPricingVO.setAddedBy(userseqid);
		/*ArrayList<SwPolicyConfigVO> alpastData =  (ArrayList<SwPolicyConfigVO>) swPolicyConfigVO.getAlResultpastYear();
		
		System.out.println("alpastData..."+alpastData.size());*/
		
		ArrayList  iResultarray = pricingRiskPreimiumService.calculatePlanDesignConfig(swPolicyConfigVO,userseqid);
		
		int re=(int)iResultarray.get(0);
		/*if(re > 0) {
			modelAndView.addObject("successMsg", "Details Added Successfully");
		}*/
		
		pricingRiskPreimiumService.rateCalcProjClm(GroupProfileSeqID);
                  
		InsPricingVO insPricingVO2  =  pricingRiskPreimiumService.getfalgPricingvalue(GroupProfileSeqID);// address changing insPricingVO2
		
		String loadingFlagYN = insPricingVO2.getLoadingFlagYN();
	    String demographicDataFlag = insPricingVO2.getDemographicflagYN();
		 
		 ArrayList  aldemographicDataList= pricingRiskPreimiumService.getdemographicData(insPricingVO,demographicDataFlag);

		ArrayList  alplanDesignList= pricingRiskPreimiumService.getcpmAfterCalcultion(insPricingVO);
		
		alLoadDesignList1 = (ArrayList) alplanDesignList.get(0);
		alLoadDesignList2 = (ArrayList) alplanDesignList.get(1);
		
		SwPolicyConfigVO  swPolicyConfigVOfinalDesign= pricingRiskPreimiumService.getcpmAfterLoading(insPricingVO);// final Data so no Flag condition required
		if(swPolicyConfigVOfinalDesign != null){
			 request.setAttribute("frmSwPolicyConfig", swPolicyConfigVOfinalDesign);
		}
	
         SwPolicyConfigVO  swCommentDetails=pricingRiskPreimiumService.getComment(GroupProfileSeqID);
		
		modelAndView.addObject("projectClaimComment", swCommentDetails.getProjectClaimComment());
		String savePropFlag = pricingRiskPreimiumService.getGetProposed(GroupProfileSeqID);
		request.getSession().setAttribute("savePropflag", savePropFlag);
		
		request.getSession().setAttribute("alResultpastYear", alLoadDesignList1);		
		request.getSession().setAttribute("alProClaimData", alLoadDesignList2);	
		
		request.getSession().setAttribute("addedDateForRiskPremium", insPricingVO2.getRiskPremiumDate());		
		request.getSession().setAttribute("alDemographicData", aldemographicDataList);	
		
	   System.out.println("test..............asdal....."+focusId);
		request.setAttribute("focusId",focusId);
		/*request.setAttribute("alResultpastYear", alLoadDesignList1);
		request.setAttribute("alProClaimData", alLoadDesignList2);
	    request.setAttribute("alDemographicData",aldemographicDataList);
	    model.addAttribute("addedDateForRiskPremium",insPricingVO2.getRiskPremiumDate());		*/
	    request.setAttribute("swPolicyConfigVO",new SwPolicyConfigVO());			
		return modelAndView;
	}
	
	
	@RequestMapping(value ="/SoftwareInsurancePricing/doSaveCalculateClaimCost" , method = RequestMethod.POST)
	public ModelAndView doSaveCalculateClaimCost(@ModelAttribute("swPolicyConfigVO") SwPolicyConfigVO swPolicyConfigVO,@RequestParam("claimComment")String claimComment,@RequestParam("focusId")String focusId, HttpServletRequest request,Model model,BindingResult result) throws Exception{		
		
		ModelAndView modelAndView = new ModelAndView(strRiskPremiumScreen);	
		setLinks(request);	
		setErrorPageData(strRiskPremiumScreen, model);		
		if(result.hasErrors()){				
			return modelAndView;
		}
		ArrayList  alLoadDesignList1 = new ArrayList();
		ArrayList  alLoadDesignList2 = new ArrayList();
		UserSecurityProfile userAccessSecurityProfile = (UserSecurityProfile) request.getSession()
				.getAttribute("userAccessSecurityProfile");				
		long userseqid = userAccessSecurityProfile.getUSER_SEQ_ID();		
		long GroupProfileSeqID = (long)request.getSession().getAttribute("groupPricingSeqId");
		swPolicyConfigVO.setLngGroupProfileSeqID(GroupProfileSeqID);
		InsPricingVO insPricingVO  = new InsPricingVO();
		swPolicyConfigVO.setAddedBy(userseqid);	
		insPricingVO.setGroupProfileSeqID(GroupProfileSeqID);
		insPricingVO.setAddedBy(userseqid);
			
		
		ArrayList  iResultarray = pricingRiskPreimiumService.calRateCalculationFnl(swPolicyConfigVO,userseqid);
		
		
		
		int result1 = pricingRiskPreimiumService.saveRiskClaimCostComment(claimComment, GroupProfileSeqID);
		/*if(result1 > 0) {
			
		modelAndView.addObject("successMsg", "Details Added Successfully");
		}*/
		SwPolicyConfigVO  swCommentDetails=pricingRiskPreimiumService.getComment(GroupProfileSeqID);
			
		modelAndView.addObject("projectClaimComment", swCommentDetails.getProjectClaimComment());
		
		/*pricingRiskPreimiumService.rateCalcProjClm(GroupProfileSeqID);*/
                  
		InsPricingVO insPricingVO2  =  pricingRiskPreimiumService.getfalgPricingvalue(GroupProfileSeqID);// address changing insPricingVO2
		
		String loadingFlagYN = insPricingVO2.getLoadingFlagYN();
	    String demographicDataFlag = insPricingVO2.getDemographicflagYN();
		 
		 ArrayList  aldemographicDataList= pricingRiskPreimiumService.getdemographicData(insPricingVO,demographicDataFlag);

		ArrayList  alplanDesignList= pricingRiskPreimiumService.getcpmAfterCalcultion(insPricingVO);
		
		alLoadDesignList1 = (ArrayList) alplanDesignList.get(0);
		alLoadDesignList2 = (ArrayList) alplanDesignList.get(1);
		
		SwPolicyConfigVO  swPolicyConfigVOfinalDesign= pricingRiskPreimiumService.getcpmAfterLoading(insPricingVO);// final Data so no Flag condition required
		if(swPolicyConfigVOfinalDesign != null){
			 request.setAttribute("frmSwPolicyConfig", swPolicyConfigVOfinalDesign);
		}
	
		String savePropFlag = pricingRiskPreimiumService.getGetProposed(GroupProfileSeqID);
		request.getSession().setAttribute("savePropflag", savePropFlag);
		/*request.setAttribute("alResultpastYear", alLoadDesignList1);
		request.setAttribute("alProClaimData", alLoadDesignList2);
	    request.setAttribute("alDemographicData",aldemographicDataList);
	    model.addAttribute("addedDateForRiskPremium",insPricingVO2.getRiskPremiumDate());	*/	
		
		request.getSession().setAttribute("alResultpastYear", alLoadDesignList1);		
		request.getSession().setAttribute("alProClaimData", alLoadDesignList2);	
		
		request.getSession().setAttribute("addedDateForRiskPremium", insPricingVO2.getRiskPremiumDate());		
		request.getSession().setAttribute("alDemographicData", aldemographicDataList);	
		modelAndView.addObject("swPolicyConfigVO",new SwPolicyConfigVO());	
		request.setAttribute("focusId",focusId);
		return modelAndView;
	}
	
	
	@RequestMapping(value ="/SoftwareInsurancePricing/saveRiskPrimium" , method = RequestMethod.POST)
	public ModelAndView doSaveIncome(@ModelAttribute("swPolicyConfigVO") SwPolicyConfigVO swPolicyConfigVO,HttpServletRequest request,Model model) throws Exception{		
		setLinks(request);
		setErrorPageData(strRiskPremiumScreen, model);		
		ModelAndView modelAndView = new ModelAndView(strRiskPremiumScreen);	
		UserSecurityProfile userAccessSecurityProfile = (UserSecurityProfile) request.getSession()
				.getAttribute("userAccessSecurityProfile");			
		InsPricingVO insPricingVO  = new InsPricingVO();
		ArrayList alLoadDesignList = new ArrayList();
		ArrayList  alplanDesignList =  new ArrayList();
		ArrayList  alLoadDesignList1 = new ArrayList();
		ArrayList  alLoadDesignList2 = new ArrayList();
		ArrayList aldemographicDataList = new ArrayList();
		long userseqid = userAccessSecurityProfile.getUSER_SEQ_ID();	
		long GroupProfileSeqID = (long)request.getSession().getAttribute("groupPricingSeqId");
		
		swPolicyConfigVO.setLngGroupProfileSeqID(GroupProfileSeqID);
		insPricingVO.setGroupProfileSeqID(GroupProfileSeqID);
		insPricingVO.setAddedBy((userseqid));
		ArrayList  iResultarray = pricingRiskPreimiumService.saveDemographicData(swPolicyConfigVO,userseqid);//only save has writtern
		
		int re=(int)iResultarray.get(0);
		if(re > 0) {
			modelAndView.addObject("successMsg", "Details added successfully");
		}
		InsPricingVO insPricingVO2  =  pricingRiskPreimiumService.getfalgPricingvalue(GroupProfileSeqID);// itshoud be after save data,Once data saved flag will be correct
		
		String loadingFlagYN = insPricingVO2.getLoadingFlagYN();
		String calCPM_FlagYN = insPricingVO2.getCalCPMFlagYN();
		String demographicDataFlag = insPricingVO2.getDemographicflagYN();
		
		aldemographicDataList= pricingRiskPreimiumService.getdemographicData(insPricingVO,demographicDataFlag);
		
		 if(calCPM_FlagYN.equalsIgnoreCase("Y")){
			  alplanDesignList= pricingRiskPreimiumService.getcpmAfterCalcultion(insPricingVO);	
				alLoadDesignList1 = (ArrayList) alplanDesignList.get(0);
				alLoadDesignList2 = (ArrayList) alplanDesignList.get(1);
				}else{
				alplanDesignList= pricingRiskPreimiumService.getcpmBeforeCalcultion(insPricingVO);//to get CPM Data	
				alLoadDesignList1 = (ArrayList) alplanDesignList.get(0);
				alLoadDesignList2 = (ArrayList) alplanDesignList.get(1);
				}
		
		 if(loadingFlagYN.equalsIgnoreCase("Y"))
			{
				alLoadDesignList= pricingRiskPreimiumService.getAfterLoadingData(insPricingVO);	
			}else{
				alLoadDesignList= pricingRiskPreimiumService.getBeforeLoadingData(insPricingVO);//to get Loading data	
			}
		 
		 
			SwPolicyConfigVO  swPolicyConfigVOfinalDesign= pricingRiskPreimiumService.getcpmAfterLoading(insPricingVO);// final Data so no Flag condition required
			SwPolicyConfigVO  swCommentDetails=pricingRiskPreimiumService.getComment(GroupProfileSeqID);
			modelAndView.addObject("projectClaimComment", swCommentDetails.getProjectClaimComment());
						
			String savePropFlag = pricingRiskPreimiumService.getGetProposed(GroupProfileSeqID);
			request.getSession().setAttribute("savePropflag", savePropFlag);
			/*request.setAttribute("alResultpastYear", alLoadDesignList1);
			request.setAttribute("alProClaimData", alLoadDesignList2);
		    request.setAttribute("alDemographicData",aldemographicDataList);
		    model.addAttribute("addedDateForRiskPremium",insPricingVO2.getRiskPremiumDate());	*/	
			request.getSession().setAttribute("alResultpastYear", alLoadDesignList1);		
			request.getSession().setAttribute("alProClaimData", alLoadDesignList2);	
			
			request.getSession().setAttribute("addedDateForRiskPremium", insPricingVO2.getRiskPremiumDate());		
			request.getSession().setAttribute("alDemographicData", aldemographicDataList);	
			
		modelAndView.addObject("insPricingVO",new InsPricingVO());			
		return modelAndView;
	}
	
	
	
	@RequestMapping(value ="/SoftwareInsurancePricing/GrossPremiumWorkingProcess" , method = RequestMethod.POST)
	public ModelAndView processRiskPrimium(HttpServletRequest request,Model model) throws Exception{
									       
		UserSecurityProfile userAccessSecurityProfile = (UserSecurityProfile) request.getSession()
				.getAttribute("userAccessSecurityProfile");
		long userseqid = userAccessSecurityProfile.getUSER_SEQ_ID();		
		 userAccessSecurityProfile.getSecurityProfile().setActiveTab("Gross Premium-Working");		
		 return new ModelAndView("forward:/SoftwareInsurancePricing/GrossPremium-Working");				
	}
	
	protected void setLinks(HttpServletRequest request) throws VidalException{
		
		
	
	 	String strMenuLink = UXUtility.checkNull(request.getParameter("menulink"));
        String strSubLink = UXUtility.checkNull(request.getParameter("sublink"));
        String strSubMenuLink = UXUtility.checkNull(request.getParameter("submenulink"));
        if(request.getSession().getAttribute("userAccessSecurityProfile")!=null)
        {
        	UserSecurityProfile userSecurityProfile=(UserSecurityProfile)request.getSession().getAttribute("userAccessSecurityProfile");
        	if(userSecurityProfile.getSecurityProfile().getActiveLink().equals(""))
            {
                userSecurityProfile.getSecurityProfile().setDefaultActiveLink();
            }//end of if(userSecurityProfile.getSecurityProfile().getActiveLink().equals(""))
            else
            {
                userSecurityProfile.getSecurityProfile().setLinks(strMenuLink,strSubLink,strSubMenuLink);
            }
        }
        else
        {
            //vidalException.setMessage("error.session");
            throw new VidalException("error.session.setlinks");
        }
}
	
	public static boolean getDiffYears(Date first, Date last) {
		Calendar a = getCalendar(first);
		Calendar b = getCalendar(last);
		int dif = 0;		
		boolean checkPolicy=true;
		
						
	
		int diff = b.get(Calendar.YEAR) - a.get(Calendar.YEAR);
		
		int diffMonth = diff * 12 + b.get(Calendar.MONTH) - a.get(Calendar.MONTH);		
		
		if(diff == 0) {
			 dif= diffMonth + 1;
		}else {
			dif = diffMonth;
		}
		
	if(dif !=12) {
		checkPolicy = false;
	}else {
		checkPolicy = true;
	}
	

		
	/*	if (diff <= 1) {
			long days = getDifferenceDays(last, first);
			
			System.out.println("days..."+days);
			if (b.get(Calendar.YEAR) % 4 == 0 || a.get(Calendar.YEAR) % 4 == 0) {
				if (days == 365) {
					if (diff == 0){
						diff++;
						checkPolicy=false;
						
					}
				} else {
					if (diff == 1){
						diff--;
						checkPolicy=true;
					}
				}
			} else {
				if (days == 364) {
					if (diff == 0){
						diff++;
						checkPolicy=true;
					}
				} else {
					if (diff == 1){
						diff--;
						checkPolicy=false;
					}
				}
			}
		}
		if(diff != 1){
			checkPolicy=false;
		}*/
		/*if (a.get(Calendar.DAY_OF_YEAR) > b.get(Calendar.DAY_OF_YEAR)) {
			diff--;
		}*/
		
		
		return checkPolicy;
	}
	
	public static Calendar getCalendar(Date date) {
		Calendar cal = Calendar.getInstance(Locale.US);
		cal.setTime(date);
		return cal;
	}

	public static long getDifferenceDays(Date d1, Date d2) {
		long diff = d1.getTime() - d2.getTime();
		return TimeUnit.DAYS.convert(diff, TimeUnit.MILLISECONDS);
	}
	
	protected void setErrorPageData(String viewname,Model model){
		HttpServletRequest request =VidalCommon.getCurentRequestObject();
		request.setAttribute("errorPageView",viewname);
		request.setAttribute("modelObj", model);
	}
	

}


package com.vidal.controllers;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 * This program demonstrates login page
 * 
 *
 * @author nagababu
 *
 */
@Controller
@RequestMapping("utility")
public class UtilityController {
	
	private static final Logger logger = LoggerFactory.getLogger(UtilityController.class);
	
	
	
	@RequestMapping(value = "/isFutureDate", method = {RequestMethod.GET,RequestMethod.POST})
	@ResponseBody
	public String getEmployee(@RequestParam(value="rDate",required=false) String rData) {
		String strFlag="N";
		try{
		
      SimpleDateFormat sdf=new SimpleDateFormat("dd/MM/yyyy hh:mm a");
		
		//String strDate=sdf.format(new Date());
		Date date=sdf.parse(rData);
		if((date.getTime())>(new Date().getTime()+(600*1000))){
			strFlag="Y";
		}
		}catch(Exception exception){
			exception.printStackTrace();
		}
		
		return strFlag;
	}
	
	
	
	
	
	
	
}
